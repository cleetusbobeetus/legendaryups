setblock 69 36 598 minecraft:calcite
fill 70 36 558 70 39 558 minecraft:cobbled_deepslate
setblock 70 36 597 minecraft:calcite
fill 70 36 598 70 39 598 minecraft:cobbled_deepslate
setblock 71 36 596 minecraft:calcite
fill 71 36 597 71 39 597 minecraft:cobbled_deepslate
setblock 74 36 558 minecraft:calcite
setblock 74 36 598 minecraft:calcite
fill 75 36 558 75 39 558 minecraft:cobbled_deepslate
setblock 75 36 597 minecraft:calcite
fill 75 36 598 78 36 598 minecraft:cobbled_deepslate
fill 76 36 597 79 36 597 minecraft:cobbled_deepslate
setblock 79 36 558 minecraft:calcite
setblock 79 36 598 minecraft:calcite
fill 80 36 558 80 39 558 minecraft:cobbled_deepslate
setblock 80 36 597 minecraft:calcite
fill 80 36 598 80 39 598 minecraft:cobbled_deepslate
setblock 81 36 596 minecraft:calcite
fill 81 36 597 81 39 597 minecraft:cobbled_deepslate
fill 82 36 596 82 39 596 minecraft:cobbled_deepslate
fill 83 36 595 83 39 595 minecraft:cobbled_deepslate
setblock 84 36 558 minecraft:calcite
setblock 84 36 598 minecraft:calcite
fill 85 36 558 85 39 558 minecraft:cobbled_deepslate
setblock 85 36 591 minecraft:cobbled_deepslate
setblock 85 36 592 minecraft:calcite
fill 85 36 593 85 39 593 minecraft:cobbled_deepslate
setblock 85 36 596 minecraft:cobbled_deepslate
setblock 85 36 597 minecraft:calcite
fill 85 36 598 85 39 598 minecraft:cobbled_deepslate
setblock 86 36 570 minecraft:cobbled_deepslate
setblock 86 36 571 minecraft:calcite
fill 86 36 572 86 37 572 minecraft:cobbled_deepslate
setblock 86 36 586 minecraft:calcite
fill 86 36 587 86 38 587 minecraft:cobbled_deepslate
setblock 86 36 591 minecraft:calcite
fill 86 36 592 86 39 592 minecraft:cobbled_deepslate
setblock 86 36 596 minecraft:calcite
fill 86 36 597 86 39 597 minecraft:cobbled_deepslate
setblock 87 36 565 minecraft:calcite
setblock 87 36 566 minecraft:cobbled_deepslate
setblock 87 36 570 minecraft:calcite
fill 87 36 571 87 39 571 minecraft:cobbled_deepslate
fill 87 36 573 87 36 574 minecraft:cobbled_deepslate
setblock 87 36 575 minecraft:calcite
fill 87 36 576 87 39 576 minecraft:cobbled_deepslate
fill 87 36 578 87 36 579 minecraft:cobbled_deepslate
setblock 87 36 580 minecraft:calcite
fill 87 36 581 87 39 581 minecraft:cobbled_deepslate
setblock 87 36 585 minecraft:calcite
fill 87 36 586 87 39 586 minecraft:cobbled_deepslate
setblock 87 36 590 minecraft:calcite
fill 87 36 591 87 39 591 minecraft:cobbled_deepslate
setblock 87 36 595 minecraft:calcite
fill 87 36 596 87 39 596 minecraft:cobbled_deepslate
setblock 88 36 559 minecraft:calcite
fill 88 36 560 88 38 560 minecraft:cobbled_deepslate
setblock 88 36 564 minecraft:calcite
fill 88 36 565 88 38 565 minecraft:cobbled_deepslate
setblock 88 36 569 minecraft:calcite
fill 88 36 570 88 39 570 minecraft:cobbled_deepslate
setblock 88 36 574 minecraft:calcite
fill 88 36 575 88 39 575 minecraft:cobbled_deepslate
setblock 88 36 579 minecraft:calcite
fill 88 36 580 88 39 580 minecraft:cobbled_deepslate
setblock 88 36 584 minecraft:calcite
fill 88 36 585 88 39 585 minecraft:cobbled_deepslate
setblock 88 36 589 minecraft:calcite
fill 88 36 590 88 39 590 minecraft:cobbled_deepslate
setblock 88 36 594 minecraft:calcite
fill 88 36 595 88 39 595 minecraft:cobbled_deepslate
setblock 48 37 558 minecraft:calcite
setblock 48 37 563 minecraft:calcite
fill 48 37 564 48 37 567 minecraft:cobbled_deepslate
setblock 48 37 568 minecraft:calcite
fill 48 37 569 48 40 569 minecraft:cobbled_deepslate
setblock 48 37 573 minecraft:calcite
fill 48 37 574 48 40 574 minecraft:cobbled_deepslate
setblock 48 37 578 minecraft:calcite
fill 48 37 579 48 40 579 minecraft:cobbled_deepslate
setblock 48 37 583 minecraft:calcite
fill 48 37 584 48 40 584 minecraft:cobbled_deepslate
setblock 48 37 588 minecraft:calcite
fill 48 37 589 48 40 589 minecraft:cobbled_deepslate
setblock 48 37 593 minecraft:calcite
fill 48 37 594 48 40 594 minecraft:cobbled_deepslate
setblock 48 37 598 minecraft:calcite
setblock 49 37 567 minecraft:calcite
fill 49 37 568 49 39 568 minecraft:cobbled_deepslate
setblock 49 37 572 minecraft:calcite
fill 49 37 573 49 40 573 minecraft:cobbled_deepslate
setblock 49 37 576 minecraft:cobbled_deepslate
setblock 49 37 577 minecraft:calcite
fill 49 37 578 49 40 578 minecraft:cobbled_deepslate
setblock 49 37 582 minecraft:calcite
fill 49 37 583 49 39 583 minecraft:cobbled_deepslate
setblock 49 37 587 minecraft:calcite
fill 49 37 588 49 39 588 minecraft:cobbled_deepslate
setblock 49 37 592 minecraft:calcite
fill 49 37 593 49 40 593 minecraft:cobbled_deepslate
setblock 49 37 596 minecraft:cobbled_deepslate
setblock 49 37 597 minecraft:calcite
fill 49 37 598 49 40 598 minecraft:cobbled_deepslate
setblock 50 37 571 minecraft:calcite
fill 50 37 572 50 39 572 minecraft:cobbled_deepslate
setblock 50 37 576 minecraft:calcite
fill 50 37 577 50 40 577 minecraft:cobbled_deepslate
setblock 50 37 587 minecraft:cobbled_deepslate
setblock 50 37 591 minecraft:calcite
fill 50 37 592 50 38 592 minecraft:cobbled_deepslate
fill 50 37 597 50 38 597 minecraft:cobbled_deepslate
setblock 62 37 598 minecraft:cobbled_deepslate
setblock 63 37 558 minecraft:calcite
setblock 63 37 598 minecraft:calcite
fill 64 37 558 64 40 558 minecraft:cobbled_deepslate
setblock 64 37 597 minecraft:calcite
fill 64 37 598 67 37 598 minecraft:cobbled_deepslate
fill 65 37 597 68 37 597 minecraft:cobbled_deepslate
fill 66 37 596 66 40 596 minecraft:cobbled_deepslate
setblock 67 37 559 minecraft:calcite
setblock 68 37 558 minecraft:calcite
fill 68 37 559 68 40 559 minecraft:cobbled_deepslate
fill 68 37 596 69 37 596 minecraft:cobbled_deepslate
setblock 68 37 598 minecraft:calcite
fill 69 37 558 69 40 558 minecraft:cobbled_deepslate
setblock 69 37 597 minecraft:calcite
fill 69 37 598 69 40 598 minecraft:cobbled_deepslate
setblock 70 37 596 minecraft:calcite
fill 70 37 597 70 40 597 minecraft:cobbled_deepslate
setblock 71 37 596 minecraft:cobbled_deepslate
setblock 72 37 559 minecraft:calcite
setblock 73 37 558 minecraft:calcite
setblock 73 37 597 minecraft:cobbled_deepslate
setblock 73 37 598 minecraft:calcite
fill 74 37 558 74 40 558 minecraft:cobbled_deepslate
setblock 74 37 597 minecraft:calcite
fill 74 37 598 77 37 598 minecraft:cobbled_deepslate
fill 75 37 597 78 37 597 minecraft:cobbled_deepslate
setblock 78 37 558 minecraft:calcite
setblock 78 37 598 minecraft:calcite
fill 79 37 558 79 40 558 minecraft:cobbled_deepslate
setblock 79 37 597 minecraft:calcite
fill 79 37 598 79 40 598 minecraft:cobbled_deepslate
setblock 80 37 596 minecraft:calcite
fill 80 37 597 80 40 597 minecraft:cobbled_deepslate
fill 81 37 596 81 40 596 minecraft:cobbled_deepslate
setblock 83 37 558 minecraft:calcite
setblock 83 37 598 minecraft:calcite
fill 84 37 558 84 40 558 minecraft:cobbled_deepslate
setblock 84 37 597 minecraft:calcite
fill 84 37 598 84 40 598 minecraft:cobbled_deepslate
setblock 85 37 591 minecraft:calcite
fill 85 37 592 85 40 592 minecraft:cobbled_deepslate
setblock 85 37 596 minecraft:calcite
fill 85 37 597 85 40 597 minecraft:cobbled_deepslate
setblock 86 37 571 minecraft:cobbled_deepslate
fill 86 37 573 87 37 573 minecraft:cobbled_deepslate
setblock 86 37 586 minecraft:cobbled_deepslate
setblock 86 37 590 minecraft:calcite
fill 86 37 591 86 40 591 minecraft:cobbled_deepslate
setblock 86 37 595 minecraft:calcite
fill 86 37 596 86 40 596 minecraft:cobbled_deepslate
setblock 87 37 569 minecraft:calcite
fill 87 37 570 87 39 570 minecraft:cobbled_deepslate
setblock 87 37 574 minecraft:calcite
fill 87 37 575 87 40 575 minecraft:cobbled_deepslate
setblock 87 37 578 minecraft:cobbled_deepslate
setblock 87 37 579 minecraft:calcite
fill 87 37 580 87 40 580 minecraft:cobbled_deepslate
setblock 87 37 584 minecraft:calcite
fill 87 37 585 87 40 585 minecraft:cobbled_deepslate
setblock 87 37 589 minecraft:calcite
fill 87 37 590 87 40 590 minecraft:cobbled_deepslate
setblock 87 37 594 minecraft:calcite
fill 87 37 595 87 40 595 minecraft:cobbled_deepslate
setblock 88 37 558 minecraft:calcite
fill 88 37 559 88 39 559 minecraft:cobbled_deepslate
setblock 88 37 563 minecraft:calcite
setblock 88 37 564 minecraft:cobbled_deepslate
setblock 88 37 568 minecraft:calcite
fill 88 37 569 88 40 569 minecraft:cobbled_deepslate
setblock 88 37 573 minecraft:calcite
fill 88 37 574 88 40 574 minecraft:cobbled_deepslate
setblock 88 37 578 minecraft:calcite
fill 88 37 579 88 40 579 minecraft:cobbled_deepslate
setblock 88 37 583 minecraft:calcite
fill 88 37 584 88 40 584 minecraft:cobbled_deepslate
setblock 88 37 588 minecraft:calcite
fill 88 37 589 88 40 589 minecraft:cobbled_deepslate
setblock 88 37 593 minecraft:calcite
fill 88 37 594 88 40 594 minecraft:cobbled_deepslate
setblock 88 37 598 minecraft:calcite
fill 48 38 564 48 38 566 minecraft:cobbled_deepslate
setblock 48 38 567 minecraft:calcite
fill 48 38 568 48 41 568 minecraft:cobbled_deepslate
setblock 48 38 572 minecraft:calcite
fill 48 38 573 48 41 573 minecraft:cobbled_deepslate
setblock 48 38 577 minecraft:calcite
fill 48 38 578 48 41 578 minecraft:cobbled_deepslate
setblock 48 38 582 minecraft:calcite
fill 48 38 583 48 41 583 minecraft:cobbled_deepslate
setblock 48 38 587 minecraft:calcite
fill 48 38 588 48 41 588 minecraft:cobbled_deepslate
setblock 48 38 592 minecraft:calcite
fill 48 38 593 48 41 593 minecraft:cobbled_deepslate
setblock 48 38 597 minecraft:calcite
fill 48 38 598 48 41 598 minecraft:cobbled_deepslate
setblock 49 38 567 minecraft:cobbled_deepslate
setblock 49 38 571 minecraft:calcite
fill 49 38 572 49 41 572 minecraft:cobbled_deepslate
setblock 49 38 576 minecraft:calcite
fill 49 38 577 49 41 577 minecraft:cobbled_deepslate
setblock 49 38 581 minecraft:calcite
fill 49 38 582 49 39 582 minecraft:cobbled_deepslate
setblock 49 38 586 minecraft:calcite
fill 49 38 587 49 39 587 minecraft:cobbled_deepslate
setblock 49 38 591 minecraft:calcite
fill 49 38 592 49 40 592 minecraft:cobbled_deepslate
setblock 49 38 596 minecraft:calcite
fill 49 38 597 49 39 597 minecraft:cobbled_deepslate
setblock 50 38 570 minecraft:calcite
fill 50 38 571 50 39 571 minecraft:cobbled_deepslate
setblock 50 38 575 minecraft:calcite
fill 50 38 576 50 41 576 minecraft:cobbled_deepslate
setblock 50 38 591 minecraft:cobbled_deepslate
setblock 61 38 558 minecraft:cobbled_deepslate
setblock 61 38 598 minecraft:cobbled_deepslate
setblock 62 38 558 minecraft:calcite
setblock 62 38 598 minecraft:calcite
fill 63 38 558 63 40 559 minecraft:cobbled_deepslate
setblock 63 38 597 minecraft:calcite
fill 63 38 598 66 38 598 minecraft:cobbled_deepslate
fill 64 38 597 67 38 597 minecraft:cobbled_deepslate
setblock 66 38 559 minecraft:calcite
setblock 67 38 558 minecraft:calcite
fill 67 38 559 67 41 559 minecraft:cobbled_deepslate
setblock 67 38 598 minecraft:calcite
fill 68 38 558 68 41 558 minecraft:cobbled_deepslate
setblock 68 38 596 minecraft:cobbled_deepslate
setblock 68 38 597 minecraft:calcite
fill 68 38 598 68 41 598 minecraft:cobbled_deepslate
setblock 69 38 596 minecraft:calcite
fill 69 38 597 69 41 597 minecraft:cobbled_deepslate
setblock 70 38 596 minecraft:cobbled_deepslate
setblock 71 38 559 minecraft:calcite
setblock 72 38 558 minecraft:calcite
setblock 72 38 598 minecraft:calcite
fill 73 38 558 73 41 558 minecraft:cobbled_deepslate
setblock 73 38 597 minecraft:calcite
fill 73 38 598 76 38 598 minecraft:cobbled_deepslate
fill 74 38 597 77 38 597 minecraft:cobbled_deepslate
setblock 77 38 598 minecraft:calcite
fill 78 38 558 78 41 558 minecraft:cobbled_deepslate
setblock 78 38 597 minecraft:calcite
fill 78 38 598 78 41 598 minecraft:cobbled_deepslate
fill 79 38 597 79 41 597 minecraft:cobbled_deepslate
fill 80 38 596 80 41 596 minecraft:cobbled_deepslate
fill 81 38 561 81 40 561 minecraft:deepslate
setblock 82 38 558 minecraft:calcite
fill 82 38 560 82 40 560 minecraft:deepslate
fill 82 38 562 82 40 562 minecraft:deepslate
fill 82 38 595 82 40 595 minecraft:cobbled_deepslate
setblock 82 38 598 minecraft:calcite
fill 83 38 558 83 41 558 minecraft:cobbled_deepslate
fill 83 38 561 83 40 561 minecraft:deepslate
setblock 83 38 597 minecraft:calcite
fill 83 38 598 83 41 598 minecraft:cobbled_deepslate
setblock 84 38 596 minecraft:calcite
fill 84 38 597 84 41 597 minecraft:cobbled_deepslate
setblock 85 38 590 minecraft:calcite
fill 85 38 591 85 39 591 minecraft:cobbled_deepslate
setblock 85 38 595 minecraft:calcite
fill 85 38 596 85 41 596 minecraft:cobbled_deepslate
setblock 86 38 573 minecraft:cobbled_deepslate
fill 86 38 586 86 49 586 minecraft:calcite
setblock 86 38 589 minecraft:calcite
fill 86 38 590 86 41 590 minecraft:cobbled_deepslate
setblock 86 38 594 minecraft:calcite
fill 86 38 595 86 41 595 minecraft:cobbled_deepslate
setblock 87 38 558 minecraft:calcite
setblock 87 38 568 minecraft:calcite
setblock 87 38 569 minecraft:cobbled_deepslate
setblock 87 38 573 minecraft:calcite
fill 87 38 574 87 41 574 minecraft:cobbled_deepslate
setblock 87 38 578 minecraft:calcite
fill 87 38 579 87 41 579 minecraft:cobbled_deepslate
setblock 87 38 583 minecraft:calcite
fill 87 38 584 87 39 584 minecraft:cobbled_deepslate
setblock 87 38 588 minecraft:calcite
fill 87 38 589 87 41 589 minecraft:cobbled_deepslate
setblock 87 38 593 minecraft:calcite
fill 87 38 594 87 41 594 minecraft:cobbled_deepslate
setblock 87 38 598 minecraft:calcite
fill 88 38 558 88 41 558 minecraft:cobbled_deepslate
setblock 88 38 567 minecraft:calcite
fill 88 38 568 88 39 568 minecraft:cobbled_deepslate
setblock 88 38 572 minecraft:calcite
fill 88 38 573 88 41 573 minecraft:cobbled_deepslate
setblock 88 38 577 minecraft:calcite
fill 88 38 578 88 41 578 minecraft:cobbled_deepslate
setblock 88 38 582 minecraft:calcite
fill 88 38 583 88 41 583 minecraft:cobbled_deepslate
setblock 88 38 587 minecraft:calcite
fill 88 38 588 88 41 588 minecraft:cobbled_deepslate
setblock 88 38 592 minecraft:calcite
fill 88 38 593 88 41 593 minecraft:cobbled_deepslate
setblock 88 38 597 minecraft:calcite
fill 88 38 598 88 41 598 minecraft:cobbled_deepslate
setblock 48 39 566 minecraft:calcite
fill 48 39 567 48 40 567 minecraft:cobbled_deepslate
setblock 48 39 571 minecraft:calcite
fill 48 39 572 48 42 572 minecraft:cobbled_deepslate
setblock 48 39 576 minecraft:calcite
fill 48 39 577 48 42 577 minecraft:cobbled_deepslate
setblock 48 39 581 minecraft:calcite
fill 48 39 582 48 42 582 minecraft:cobbled_deepslate
setblock 48 39 586 minecraft:calcite
fill 48 39 587 48 41 587 minecraft:cobbled_deepslate
setblock 48 39 591 minecraft:calcite
fill 48 39 592 48 42 592 minecraft:cobbled_deepslate
setblock 48 39 596 minecraft:calcite
fill 48 39 597 48 42 597 minecraft:cobbled_deepslate
setblock 49 39 570 minecraft:calcite
fill 49 39 571 49 42 571 minecraft:cobbled_deepslate
setblock 49 39 575 minecraft:calcite
fill 49 39 576 49 42 576 minecraft:cobbled_deepslate
setblock 49 39 580 minecraft:calcite
fill 49 39 581 49 41 581 minecraft:cobbled_deepslate
setblock 49 39 590 minecraft:calcite
fill 49 39 591 49 40 591 minecraft:cobbled_deepslate
setblock 49 39 595 minecraft:calcite
fill 49 39 596 49 40 596 minecraft:cobbled_deepslate
setblock 50 39 574 minecraft:calcite
fill 50 39 575 50 41 575 minecraft:cobbled_deepslate
setblock 51 39 598 minecraft:calcite
setblock 61 39 558 minecraft:calcite
setblock 61 39 598 minecraft:calcite
fill 62 39 558 62 42 558 minecraft:cobbled_deepslate
fill 62 39 598 65 39 598 minecraft:cobbled_deepslate
fill 63 39 597 66 39 597 minecraft:cobbled_deepslate
setblock 65 39 559 minecraft:calcite
setblock 66 39 558 minecraft:calcite
fill 66 39 559 66 42 559 minecraft:cobbled_deepslate
setblock 66 39 598 minecraft:calcite
fill 67 39 558 67 42 558 minecraft:cobbled_deepslate
setblock 67 39 597 minecraft:calcite
fill 67 39 598 67 42 598 minecraft:cobbled_deepslate
setblock 68 39 596 minecraft:calcite
fill 68 39 597 68 42 597 minecraft:cobbled_deepslate
setblock 69 39 596 minecraft:cobbled_deepslate
setblock 70 39 559 minecraft:calcite
setblock 71 39 558 minecraft:calcite
setblock 71 39 598 minecraft:calcite
fill 72 39 558 72 42 558 minecraft:cobbled_deepslate
setblock 72 39 597 minecraft:calcite
fill 72 39 598 75 39 598 minecraft:cobbled_deepslate
fill 73 39 597 76 39 597 minecraft:cobbled_deepslate
setblock 76 39 598 minecraft:calcite
setblock 77 39 597 minecraft:calcite
fill 77 39 598 77 42 598 minecraft:cobbled_deepslate
fill 78 39 597 78 42 597 minecraft:cobbled_deepslate
setblock 81 39 558 minecraft:calcite
setblock 81 39 598 minecraft:calcite
fill 82 39 558 82 42 558 minecraft:cobbled_deepslate
setblock 82 39 597 minecraft:calcite
fill 82 39 598 82 42 598 minecraft:cobbled_deepslate
setblock 83 39 596 minecraft:calcite
fill 83 39 597 83 42 597 minecraft:cobbled_deepslate
setblock 84 39 595 minecraft:calcite
fill 84 39 596 84 42 596 minecraft:cobbled_deepslate
setblock 85 39 594 minecraft:calcite
fill 85 39 595 85 42 595 minecraft:cobbled_deepslate
setblock 86 39 558 minecraft:calcite
setblock 86 39 588 minecraft:calcite
fill 86 39 589 86 40 589 minecraft:cobbled_deepslate
setblock 86 39 593 minecraft:calcite
fill 86 39 594 86 42 594 minecraft:cobbled_deepslate
setblock 86 39 598 minecraft:calcite
fill 87 39 558 87 42 558 minecraft:cobbled_deepslate
setblock 87 39 572 minecraft:calcite
fill 87 39 573 87 42 573 minecraft:cobbled_deepslate
setblock 87 39 577 minecraft:calcite
fill 87 39 578 87 42 578 minecraft:cobbled_deepslate
setblock 87 39 582 minecraft:calcite
setblock 87 39 583 minecraft:cobbled_deepslate
setblock 87 39 587 minecraft:calcite
fill 87 39 588 87 41 588 minecraft:cobbled_deepslate
setblock 87 39 592 minecraft:calcite
fill 87 39 593 87 42 593 minecraft:cobbled_deepslate
setblock 87 39 597 minecraft:calcite
fill 87 39 598 87 42 598 minecraft:cobbled_deepslate
setblock 88 39 567 minecraft:cobbled_deepslate
setblock 88 39 571 minecraft:calcite
fill 88 39 572 88 42 572 minecraft:cobbled_deepslate
setblock 88 39 576 minecraft:calcite
fill 88 39 577 88 42 577 minecraft:cobbled_deepslate
setblock 88 39 581 minecraft:calcite
fill 88 39 582 88 42 582 minecraft:cobbled_deepslate
setblock 88 39 586 minecraft:calcite
fill 88 39 587 88 42 587 minecraft:cobbled_deepslate
setblock 88 39 591 minecraft:calcite
fill 88 39 592 88 42 592 minecraft:cobbled_deepslate
setblock 88 39 596 minecraft:calcite
fill 88 39 597 88 42 597 minecraft:cobbled_deepslate
setblock 48 40 570 minecraft:calcite
fill 48 40 571 48 43 571 minecraft:cobbled_deepslate
setblock 48 40 575 minecraft:calcite
fill 48 40 576 48 43 576 minecraft:cobbled_deepslate
setblock 48 40 580 minecraft:calcite
fill 48 40 581 48 43 581 minecraft:cobbled_deepslate
setblock 48 40 585 minecraft:calcite
fill 48 40 586 48 42 586 minecraft:cobbled_deepslate
setblock 48 40 590 minecraft:calcite
fill 48 40 591 48 42 591 minecraft:cobbled_deepslate
setblock 48 40 595 minecraft:calcite
fill 48 40 596 48 43 596 minecraft:cobbled_deepslate
setblock 49 40 569 minecraft:calcite
setblock 49 40 570 minecraft:cobbled_deepslate
setblock 49 40 574 minecraft:calcite
fill 49 40 575 49 43 575 minecraft:cobbled_deepslate
setblock 49 40 579 minecraft:calcite
fill 49 40 580 49 43 580 minecraft:cobbled_deepslate
setblock 49 40 594 minecraft:calcite
setblock 49 40 595 minecraft:cobbled_deepslate
setblock 50 40 560 minecraft:light[level=14]
setblock 50 40 568 minecraft:light[level=14]
setblock 50 40 573 minecraft:calcite
setblock 50 40 574 minecraft:cobbled_deepslate
setblock 50 40 584 minecraft:light[level=14]
setblock 50 40 592 minecraft:light[level=14]
setblock 50 40 598 minecraft:calcite
setblock 58 40 560 minecraft:light[level=14]
setblock 58 40 568 minecraft:light[level=14]
setblock 58 40 576 minecraft:light[level=14]
setblock 58 40 584 minecraft:light[level=14]
setblock 58 40 592 minecraft:light[level=14]
setblock 60 40 558 minecraft:calcite
setblock 60 40 598 minecraft:calcite
fill 61 40 558 61 43 558 minecraft:cobbled_deepslate
fill 61 40 598 64 40 598 minecraft:cobbled_deepslate
fill 62 40 559 62 41 559 minecraft:cobbled_deepslate
fill 62 40 597 65 40 597 minecraft:cobbled_deepslate
setblock 64 40 559 minecraft:calcite
setblock 65 40 558 minecraft:calcite
fill 65 40 559 65 43 559 minecraft:cobbled_deepslate
setblock 65 40 598 minecraft:calcite
fill 66 40 558 66 43 558 minecraft:cobbled_deepslate
setblock 66 40 560 minecraft:light[level=14]
setblock 66 40 568 minecraft:light[level=14]
setblock 66 40 576 minecraft:light[level=14]
setblock 66 40 584 minecraft:light[level=14]
setblock 66 40 592 minecraft:light[level=14]
setblock 66 40 597 minecraft:calcite
fill 66 40 598 66 43 598 minecraft:cobbled_deepslate
setblock 67 40 596 minecraft:calcite
fill 67 40 597 67 43 597 minecraft:cobbled_deepslate
setblock 69 40 559 minecraft:calcite
setblock 70 40 558 minecraft:calcite
setblock 70 40 559 minecraft:cobbled_deepslate
setblock 70 40 598 minecraft:calcite
fill 71 40 558 71 43 558 minecraft:cobbled_deepslate
setblock 71 40 597 minecraft:calcite
fill 71 40 598 74 40 598 minecraft:cobbled_deepslate
fill 72 40 597 75 40 597 minecraft:cobbled_deepslate
setblock 74 40 560 minecraft:light[level=14]
setblock 74 40 568 minecraft:light[level=14]
setblock 74 40 576 minecraft:light[level=14]
setblock 74 40 584 minecraft:light[level=14]
setblock 74 40 592 minecraft:light[level=14]
setblock 75 40 558 minecraft:calcite
setblock 75 40 598 minecraft:calcite
setblock 76 40 597 minecraft:calcite
fill 76 40 598 76 43 598 minecraft:cobbled_deepslate
fill 77 40 597 77 43 597 minecraft:cobbled_deepslate
setblock 80 40 558 minecraft:calcite
setblock 80 40 598 minecraft:calcite
fill 81 40 558 81 43 558 minecraft:cobbled_deepslate
setblock 81 40 597 minecraft:calcite
fill 81 40 598 81 43 598 minecraft:cobbled_deepslate
setblock 82 40 568 minecraft:light[level=14]
setblock 82 40 576 minecraft:light[level=14]
setblock 82 40 584 minecraft:light[level=14]
setblock 82 40 592 minecraft:light[level=14]
setblock 82 40 596 minecraft:calcite
fill 82 40 597 82 43 597 minecraft:cobbled_deepslate
setblock 83 40 595 minecraft:calcite
fill 83 40 596 83 43 596 minecraft:cobbled_deepslate
fill 84 40 595 84 42 595 minecraft:cobbled_deepslate
setblock 85 40 558 minecraft:calcite
setblock 85 40 593 minecraft:calcite
fill 85 40 594 85 41 594 minecraft:cobbled_deepslate
setblock 85 40 598 minecraft:calcite
fill 86 40 558 86 43 558 minecraft:cobbled_deepslate
setblock 86 40 592 minecraft:calcite
fill 86 40 593 86 43 593 minecraft:cobbled_deepslate
setblock 86 40 597 minecraft:calcite
fill 86 40 598 86 43 598 minecraft:cobbled_deepslate
setblock 87 40 571 minecraft:calcite
fill 87 40 572 87 41 572 minecraft:cobbled_deepslate
setblock 87 40 576 minecraft:calcite
fill 87 40 577 87 43 577 minecraft:cobbled_deepslate
setblock 87 40 581 minecraft:calcite
fill 87 40 582 87 43 582 minecraft:cobbled_deepslate
fill 87 40 584 87 43 584 minecraft:calcite
setblock 87 40 586 minecraft:calcite
fill 87 40 587 87 41 587 minecraft:cobbled_deepslate
setblock 87 40 591 minecraft:calcite
fill 87 40 592 87 43 592 minecraft:cobbled_deepslate
setblock 87 40 596 minecraft:calcite
fill 87 40 597 87 43 597 minecraft:cobbled_deepslate
setblock 88 40 570 minecraft:calcite
fill 88 40 571 88 42 571 minecraft:cobbled_deepslate
setblock 88 40 575 minecraft:calcite
fill 88 40 576 88 43 576 minecraft:cobbled_deepslate
setblock 88 40 580 minecraft:calcite
fill 88 40 581 88 43 581 minecraft:cobbled_deepslate
setblock 88 40 585 minecraft:calcite
fill 88 40 586 88 43 586 minecraft:cobbled_deepslate
setblock 88 40 590 minecraft:calcite
fill 88 40 591 88 43 591 minecraft:cobbled_deepslate
setblock 88 40 595 minecraft:calcite
fill 88 40 596 88 43 596 minecraft:cobbled_deepslate
setblock 48 41 569 minecraft:calcite
fill 48 41 570 48 44 570 minecraft:cobbled_deepslate
setblock 48 41 574 minecraft:calcite
fill 48 41 575 48 44 575 minecraft:cobbled_deepslate
setblock 48 41 579 minecraft:calcite
fill 48 41 580 48 44 580 minecraft:cobbled_deepslate
setblock 48 41 584 minecraft:calcite
fill 48 41 585 48 43 585 minecraft:cobbled_deepslate
setblock 48 41 589 minecraft:calcite
fill 48 41 590 48 42 590 minecraft:cobbled_deepslate
setblock 48 41 594 minecraft:calcite
fill 48 41 595 48 44 595 minecraft:cobbled_deepslate
setblock 49 41 573 minecraft:calcite
fill 49 41 574 49 44 574 minecraft:cobbled_deepslate
setblock 49 41 578 minecraft:calcite
fill 49 41 579 49 44 579 minecraft:cobbled_deepslate
setblock 49 41 598 minecraft:calcite
setblock 59 41 558 minecraft:calcite
fill 60 41 558 60 44 558 minecraft:cobbled_deepslate
fill 60 41 598 63 41 598 minecraft:cobbled_deepslate
fill 62 41 597 64 41 597 minecraft:cobbled_deepslate
setblock 63 41 558 minecraft:cobbled_deepslate
setblock 63 41 559 minecraft:calcite
setblock 64 41 558 minecraft:calcite
fill 64 41 559 64 44 559 minecraft:cobbled_deepslate
setblock 64 41 598 minecraft:calcite
fill 65 41 558 65 44 558 minecraft:cobbled_deepslate
setblock 65 41 597 minecraft:calcite
fill 65 41 598 65 44 598 minecraft:cobbled_deepslate
fill 66 41 597 66 44 597 minecraft:cobbled_deepslate
setblock 68 41 559 minecraft:calcite
setblock 69 41 558 minecraft:calcite
fill 69 41 559 69 44 559 minecraft:cobbled_deepslate
setblock 69 41 598 minecraft:calcite
fill 70 41 558 70 44 558 minecraft:cobbled_deepslate
setblock 70 41 597 minecraft:calcite
fill 70 41 598 73 41 598 minecraft:cobbled_deepslate
fill 71 41 597 72 42 597 minecraft:cobbled_deepslate
setblock 74 41 558 minecraft:calcite
setblock 74 41 598 minecraft:calcite
fill 75 41 558 75 44 558 minecraft:cobbled_deepslate
setblock 75 41 597 minecraft:calcite
fill 75 41 598 75 44 598 minecraft:cobbled_deepslate
fill 76 41 596 78 43 596 minecraft:light_blue_stained_glass
fill 76 41 597 76 44 597 minecraft:cobbled_deepslate
fill 77 41 558 77 42 558 minecraft:cobbled_deepslate
setblock 79 41 558 minecraft:calcite
fill 79 41 596 79 42 596 minecraft:cobbled_deepslate
setblock 79 41 598 minecraft:calcite
fill 80 41 558 80 44 558 minecraft:cobbled_deepslate
setblock 80 41 597 minecraft:calcite
fill 80 41 598 80 44 598 minecraft:cobbled_deepslate
setblock 81 41 596 minecraft:calcite
fill 81 41 597 81 44 597 minecraft:cobbled_deepslate
fill 82 41 596 82 44 596 minecraft:cobbled_deepslate
fill 83 41 595 83 42 595 minecraft:cobbled_deepslate
setblock 84 41 558 minecraft:calcite
setblock 84 41 598 minecraft:calcite
fill 85 41 558 85 44 558 minecraft:cobbled_deepslate
setblock 85 41 597 minecraft:calcite
fill 85 41 598 85 44 598 minecraft:cobbled_deepslate
setblock 86 41 591 minecraft:calcite
fill 86 41 592 86 42 592 minecraft:cobbled_deepslate
setblock 86 41 596 minecraft:calcite
fill 86 41 597 86 44 597 minecraft:cobbled_deepslate
setblock 87 41 575 minecraft:calcite
fill 87 41 576 87 44 576 minecraft:cobbled_deepslate
setblock 87 41 580 minecraft:calcite
fill 87 41 581 87 44 581 minecraft:cobbled_deepslate
fill 87 41 585 87 44 585 minecraft:calcite
setblock 87 41 590 minecraft:calcite
fill 87 41 591 87 44 591 minecraft:cobbled_deepslate
setblock 87 41 595 minecraft:calcite
fill 87 41 596 87 44 596 minecraft:cobbled_deepslate
setblock 88 41 570 minecraft:cobbled_deepslate
setblock 88 41 574 minecraft:calcite
fill 88 41 575 88 44 575 minecraft:cobbled_deepslate
setblock 88 41 579 minecraft:calcite
fill 88 41 580 88 44 580 minecraft:cobbled_deepslate
setblock 88 41 584 minecraft:calcite
fill 88 41 585 88 44 585 minecraft:cobbled_deepslate
setblock 88 41 589 minecraft:calcite
fill 88 41 590 88 44 590 minecraft:cobbled_deepslate
setblock 88 41 594 minecraft:calcite
fill 88 41 595 88 44 595 minecraft:cobbled_deepslate
fill 48 42 569 48 43 569 minecraft:cobbled_deepslate
setblock 48 42 573 minecraft:calcite
fill 48 42 574 48 45 574 minecraft:cobbled_deepslate
setblock 48 42 578 minecraft:calcite
fill 48 42 579 48 45 579 minecraft:cobbled_deepslate
setblock 48 42 583 minecraft:calcite
fill 48 42 584 48 45 584 minecraft:cobbled_deepslate
setblock 48 42 589 minecraft:cobbled_deepslate
setblock 48 42 593 minecraft:calcite
fill 48 42 594 48 43 594 minecraft:cobbled_deepslate
setblock 48 42 598 minecraft:calcite
setblock 49 42 572 minecraft:calcite
fill 49 42 573 49 45 573 minecraft:cobbled_deepslate
setblock 49 42 577 minecraft:calcite
fill 49 42 578 49 45 578 minecraft:cobbled_deepslate
fill 49 42 598 49 43 598 minecraft:cobbled_deepslate
setblock 58 42 558 minecraft:calcite
fill 59 42 558 59 45 558 minecraft:cobbled_deepslate
fill 59 42 598 62 42 598 minecraft:cobbled_deepslate
setblock 61 42 559 minecraft:cobbled_deepslate
fill 61 42 597 63 42 597 minecraft:cobbled_deepslate
setblock 62 42 559 minecraft:calcite
setblock 63 42 558 minecraft:calcite
fill 63 42 559 63 45 559 minecraft:cobbled_deepslate
setblock 63 42 598 minecraft:calcite
fill 64 42 558 64 45 558 minecraft:cobbled_deepslate
setblock 64 42 597 minecraft:calcite
fill 64 42 598 64 45 598 minecraft:cobbled_deepslate
fill 65 42 597 65 45 597 minecraft:cobbled_deepslate
setblock 67 42 559 minecraft:calcite
setblock 68 42 558 minecraft:calcite
fill 68 42 559 68 45 559 minecraft:cobbled_deepslate
setblock 68 42 598 minecraft:calcite
fill 69 42 558 69 45 558 minecraft:cobbled_deepslate
setblock 69 42 597 minecraft:calcite
fill 69 42 598 72 42 598 minecraft:cobbled_deepslate
fill 70 42 597 70 45 597 minecraft:cobbled_deepslate
setblock 73 42 558 minecraft:calcite
setblock 73 42 598 minecraft:calcite
fill 74 42 558 74 45 558 minecraft:cobbled_deepslate
fill 74 42 598 74 45 598 minecraft:cobbled_deepslate
fill 75 42 596 75 45 596 minecraft:light_blue_stained_glass
fill 75 42 597 75 45 597 minecraft:cobbled_deepslate
fill 76 42 558 76 43 558 minecraft:cobbled_deepslate
fill 76 42 595 78 46 595 minecraft:light_blue_stained_glass
setblock 78 42 558 minecraft:calcite
setblock 78 42 598 minecraft:calcite
fill 79 42 558 79 45 558 minecraft:cobbled_deepslate
setblock 79 42 597 minecraft:calcite
fill 79 42 598 79 45 598 minecraft:cobbled_deepslate
setblock 80 42 596 minecraft:calcite
fill 80 42 597 80 45 597 minecraft:cobbled_deepslate
fill 81 42 596 81 45 596 minecraft:cobbled_deepslate
setblock 83 42 558 minecraft:calcite
setblock 83 42 598 minecraft:calcite
fill 84 42 558 84 45 558 minecraft:cobbled_deepslate
setblock 84 42 597 minecraft:calcite
fill 84 42 598 84 45 598 minecraft:cobbled_deepslate
setblock 85 42 596 minecraft:calcite
fill 85 42 597 85 45 597 minecraft:cobbled_deepslate
setblock 86 42 595 minecraft:calcite
fill 86 42 596 86 45 596 minecraft:cobbled_deepslate
setblock 87 42 574 minecraft:calcite
fill 87 42 575 87 45 575 minecraft:cobbled_deepslate
setblock 87 42 579 minecraft:calcite
fill 87 42 580 87 45 580 minecraft:cobbled_deepslate
setblock 87 42 589 minecraft:calcite
fill 87 42 590 87 43 590 minecraft:cobbled_deepslate
setblock 87 42 594 minecraft:calcite
fill 87 42 595 87 45 595 minecraft:cobbled_deepslate
setblock 88 42 558 minecraft:calcite
setblock 88 42 573 minecraft:calcite
fill 88 42 574 88 45 574 minecraft:cobbled_deepslate
setblock 88 42 578 minecraft:calcite
fill 88 42 579 88 45 579 minecraft:cobbled_deepslate
setblock 88 42 583 minecraft:calcite
fill 88 42 584 88 45 584 minecraft:cobbled_deepslate
setblock 88 42 588 minecraft:calcite
fill 88 42 589 88 45 589 minecraft:cobbled_deepslate
setblock 88 42 593 minecraft:calcite
fill 88 42 594 88 45 594 minecraft:cobbled_deepslate
setblock 88 42 598 minecraft:calcite
setblock 48 43 572 minecraft:calcite
fill 48 43 573 48 46 573 minecraft:cobbled_deepslate
setblock 48 43 577 minecraft:calcite
fill 48 43 578 48 46 578 minecraft:cobbled_deepslate
setblock 48 43 582 minecraft:calcite
fill 48 43 583 48 46 583 minecraft:cobbled_deepslate
setblock 48 43 593 minecraft:cobbled_deepslate
setblock 48 43 597 minecraft:calcite
fill 48 43 598 48 46 598 minecraft:cobbled_deepslate
setblock 49 43 572 minecraft:cobbled_deepslate
setblock 49 43 576 minecraft:calcite
fill 49 43 577 49 46 577 minecraft:cobbled_deepslate
setblock 57 43 558 minecraft:calcite
fill 58 43 558 58 46 558 minecraft:cobbled_deepslate
fill 58 43 598 61 43 598 minecraft:cobbled_deepslate
setblock 60 43 559 minecraft:cobbled_deepslate
setblock 61 43 559 minecraft:calcite
fill 61 43 597 62 43 597 minecraft:cobbled_deepslate
setblock 62 43 558 minecraft:calcite
fill 62 43 559 62 46 559 minecraft:cobbled_deepslate
setblock 62 43 598 minecraft:calcite
fill 63 43 558 63 46 558 minecraft:cobbled_deepslate
fill 63 43 560 64 43 560 minecraft:cobbled_deepslate
setblock 63 43 597 minecraft:calcite
fill 63 43 598 63 46 598 minecraft:cobbled_deepslate
fill 64 43 597 64 46 597 minecraft:cobbled_deepslate
setblock 65 43 560 minecraft:calcite
setblock 66 43 559 minecraft:calcite
setblock 67 43 558 minecraft:calcite
fill 67 43 559 67 46 559 minecraft:cobbled_deepslate
setblock 67 43 598 minecraft:calcite
fill 68 43 558 68 46 558 minecraft:cobbled_deepslate
setblock 68 43 597 minecraft:calcite
fill 68 43 598 71 43 598 minecraft:cobbled_deepslate
fill 69 43 597 69 46 597 minecraft:cobbled_deepslate
fill 71 43 597 71 44 597 minecraft:cobbled_deepslate
setblock 72 43 558 minecraft:calcite
setblock 72 43 598 minecraft:calcite
fill 73 43 558 73 46 558 minecraft:cobbled_deepslate
fill 73 43 598 73 46 598 minecraft:cobbled_deepslate
fill 75 43 595 75 45 595 minecraft:light_blue_stained_glass
fill 76 43 594 78 46 594 minecraft:light_blue_stained_glass
setblock 77 43 558 minecraft:calcite
setblock 77 43 598 minecraft:calcite
fill 78 43 558 78 46 558 minecraft:cobbled_deepslate
fill 78 43 591 78 44 591 minecraft:light_blue_stained_glass
setblock 78 43 597 minecraft:calcite
fill 78 43 598 78 46 598 minecraft:cobbled_deepslate
fill 79 43 595 79 45 595 minecraft:light_blue_stained_glass
setblock 79 43 596 minecraft:calcite
fill 79 43 597 79 46 597 minecraft:cobbled_deepslate
fill 80 43 596 80 46 596 minecraft:cobbled_deepslate
setblock 82 43 558 minecraft:calcite
setblock 82 43 598 minecraft:calcite
fill 83 43 558 83 46 558 minecraft:cobbled_deepslate
setblock 83 43 597 minecraft:calcite
fill 83 43 598 83 46 598 minecraft:cobbled_deepslate
setblock 84 43 596 minecraft:calcite
fill 84 43 597 84 46 597 minecraft:cobbled_deepslate
fill 85 43 596 85 46 596 minecraft:cobbled_deepslate
setblock 86 43 594 minecraft:calcite
fill 86 43 595 86 45 595 minecraft:cobbled_deepslate
setblock 87 43 558 minecraft:calcite
fill 87 43 574 87 46 574 minecraft:cobbled_deepslate
setblock 87 43 578 minecraft:calcite
fill 87 43 579 87 46 579 minecraft:cobbled_deepslate
setblock 87 43 583 minecraft:calcite
setblock 87 43 593 minecraft:calcite
fill 87 43 594 87 46 594 minecraft:cobbled_deepslate
setblock 87 43 598 minecraft:calcite
fill 88 43 558 88 46 558 minecraft:cobbled_deepslate
setblock 88 43 572 minecraft:calcite
fill 88 43 573 88 46 573 minecraft:cobbled_deepslate
setblock 88 43 577 minecraft:calcite
fill 88 43 578 88 46 578 minecraft:cobbled_deepslate
setblock 88 43 582 minecraft:calcite
fill 88 43 583 88 46 583 minecraft:cobbled_deepslate
setblock 88 43 587 minecraft:calcite
fill 88 43 588 88 46 588 minecraft:cobbled_deepslate
setblock 88 43 592 minecraft:calcite
fill 88 43 593 88 46 593 minecraft:cobbled_deepslate
setblock 88 43 597 minecraft:calcite
fill 88 43 598 88 46 598 minecraft:cobbled_deepslate
setblock 48 44 571 minecraft:calcite
fill 48 44 572 48 47 572 minecraft:cobbled_deepslate
setblock 48 44 576 minecraft:calcite
fill 48 44 577 48 47 577 minecraft:cobbled_deepslate
setblock 48 44 581 minecraft:calcite
fill 48 44 582 48 47 582 minecraft:cobbled_deepslate
setblock 48 44 596 minecraft:calcite
fill 48 44 597 48 45 597 minecraft:cobbled_deepslate
setblock 49 44 575 minecraft:calcite
fill 49 44 576 49 47 576 minecraft:cobbled_deepslate
setblock 49 44 580 minecraft:calcite
fill 49 44 581 49 47 581 minecraft:cobbled_deepslate
setblock 56 44 558 minecraft:calcite
fill 57 44 558 57 47 558 minecraft:cobbled_deepslate
fill 57 44 598 60 44 598 minecraft:cobbled_deepslate
fill 58 44 559 59 44 559 minecraft:cobbled_deepslate
setblock 60 44 559 minecraft:calcite
fill 60 44 597 61 44 597 minecraft:cobbled_deepslate
setblock 61 44 558 minecraft:calcite
fill 61 44 559 61 46 560 minecraft:cobbled_deepslate
setblock 61 44 598 minecraft:calcite
fill 62 44 558 62 47 558 minecraft:cobbled_deepslate
fill 62 44 560 63 44 560 minecraft:cobbled_deepslate
setblock 62 44 597 minecraft:calcite
fill 62 44 598 62 47 598 minecraft:cobbled_deepslate
fill 63 44 597 63 47 597 minecraft:cobbled_deepslate
setblock 64 44 560 minecraft:calcite
setblock 65 44 559 minecraft:calcite
fill 65 44 560 66 46 560 minecraft:cobbled_deepslate
setblock 66 44 558 minecraft:calcite
fill 66 44 559 66 47 559 minecraft:cobbled_deepslate
setblock 66 44 598 minecraft:calcite
fill 67 44 558 67 47 558 minecraft:cobbled_deepslate
setblock 67 44 597 minecraft:calcite
fill 67 44 598 70 44 598 minecraft:cobbled_deepslate
fill 68 44 597 68 47 597 minecraft:cobbled_deepslate
setblock 70 44 559 minecraft:calcite
setblock 71 44 558 minecraft:calcite
setblock 71 44 598 minecraft:calcite
fill 72 44 558 72 47 558 minecraft:cobbled_deepslate
setblock 72 44 597 minecraft:calcite
fill 72 44 598 72 47 598 minecraft:cobbled_deepslate
fill 73 44 597 74 46 597 minecraft:cobbled_deepslate
setblock 76 44 558 minecraft:calcite
fill 76 44 596 77 45 596 minecraft:light_blue_stained_glass
setblock 76 44 598 minecraft:calcite
fill 77 44 558 77 47 558 minecraft:cobbled_deepslate
setblock 77 44 597 minecraft:calcite
fill 77 44 598 77 47 598 minecraft:cobbled_deepslate
setblock 78 44 596 minecraft:calcite
fill 78 44 597 78 47 597 minecraft:cobbled_deepslate
fill 79 44 596 79 47 596 minecraft:cobbled_deepslate
setblock 80 44 559 minecraft:calcite
setblock 81 44 558 minecraft:calcite
fill 81 44 559 84 44 559 minecraft:cobbled_deepslate
setblock 81 44 598 minecraft:calcite
fill 82 44 558 82 47 558 minecraft:cobbled_deepslate
setblock 82 44 597 minecraft:calcite
fill 82 44 598 82 47 598 minecraft:cobbled_deepslate
setblock 83 44 596 minecraft:calcite
fill 83 44 597 83 47 597 minecraft:cobbled_deepslate
fill 84 44 596 84 47 596 minecraft:cobbled_deepslate
setblock 86 44 558 minecraft:calcite
setblock 86 44 577 minecraft:cobbled_deepslate
setblock 86 44 578 minecraft:calcite
fill 86 44 579 86 46 580 minecraft:cobbled_deepslate
setblock 86 44 594 minecraft:cobbled_deepslate
setblock 86 44 598 minecraft:calcite
fill 87 44 558 87 47 558 minecraft:cobbled_deepslate
setblock 87 44 577 minecraft:calcite
fill 87 44 578 87 47 578 minecraft:cobbled_deepslate
setblock 87 44 582 minecraft:calcite
fill 87 44 583 87 46 584 minecraft:cobbled_deepslate
setblock 87 44 592 minecraft:calcite
fill 87 44 593 87 45 593 minecraft:cobbled_deepslate
setblock 87 44 597 minecraft:calcite
fill 87 44 598 87 47 598 minecraft:cobbled_deepslate
fill 88 44 572 88 45 572 minecraft:cobbled_deepslate
setblock 88 44 576 minecraft:calcite
fill 88 44 577 88 47 577 minecraft:cobbled_deepslate
setblock 88 44 581 minecraft:calcite
fill 88 44 582 88 47 582 minecraft:cobbled_deepslate
setblock 88 44 586 minecraft:calcite
fill 88 44 587 88 47 587 minecraft:cobbled_deepslate
setblock 88 44 591 minecraft:calcite
fill 88 44 592 88 47 592 minecraft:cobbled_deepslate
setblock 88 44 596 minecraft:calcite
fill 88 44 597 88 47 597 minecraft:cobbled_deepslate
fill 48 45 558 48 46 558 minecraft:cobbled_deepslate
setblock 48 45 570 minecraft:calcite
fill 48 45 571 48 48 571 minecraft:cobbled_deepslate
setblock 48 45 575 minecraft:calcite
fill 48 45 576 48 48 576 minecraft:cobbled_deepslate
setblock 48 45 580 minecraft:calcite
fill 48 45 581 48 48 581 minecraft:cobbled_deepslate
setblock 48 45 585 minecraft:calcite
setblock 48 45 596 minecraft:cobbled_deepslate
setblock 49 45 574 minecraft:calcite
fill 49 45 575 49 48 575 minecraft:cobbled_deepslate
setblock 49 45 579 minecraft:calcite
fill 49 45 580 49 48 580 minecraft:cobbled_deepslate
setblock 54 45 558 minecraft:cobbled_deepslate
setblock 55 45 558 minecraft:calcite
fill 56 45 558 56 48 558 minecraft:cobbled_deepslate
fill 56 45 598 59 45 598 minecraft:cobbled_deepslate
fill 57 45 559 58 45 559 minecraft:cobbled_deepslate
setblock 59 45 559 minecraft:calcite
fill 59 45 597 60 45 597 minecraft:cobbled_deepslate
setblock 60 45 558 minecraft:calcite
fill 60 45 559 60 47 560 minecraft:cobbled_deepslate
setblock 60 45 598 minecraft:calcite
fill 61 45 558 61 48 558 minecraft:cobbled_deepslate
setblock 61 45 597 minecraft:calcite
fill 61 45 598 61 48 598 minecraft:cobbled_deepslate
setblock 62 45 560 minecraft:cobbled_deepslate
fill 62 45 597 62 48 597 minecraft:cobbled_deepslate
setblock 63 45 560 minecraft:calcite
setblock 64 45 559 minecraft:calcite
fill 64 45 560 64 48 560 minecraft:cobbled_deepslate
setblock 65 45 558 minecraft:calcite
fill 65 45 559 65 48 559 minecraft:cobbled_deepslate
setblock 65 45 598 minecraft:calcite
fill 66 45 558 66 48 558 minecraft:cobbled_deepslate
setblock 66 45 597 minecraft:calcite
fill 66 45 598 69 45 598 minecraft:cobbled_deepslate
fill 67 45 597 67 48 597 minecraft:cobbled_deepslate
setblock 69 45 559 minecraft:calcite
setblock 70 45 558 minecraft:calcite
fill 70 45 559 70 48 559 minecraft:cobbled_deepslate
setblock 70 45 598 minecraft:calcite
fill 71 45 558 71 48 558 minecraft:cobbled_deepslate
setblock 71 45 597 minecraft:calcite
fill 71 45 598 71 48 598 minecraft:cobbled_deepslate
fill 72 45 597 72 48 597 minecraft:cobbled_deepslate
setblock 75 45 558 minecraft:calcite
setblock 75 45 598 minecraft:calcite
fill 76 45 558 76 48 558 minecraft:cobbled_deepslate
fill 76 45 593 78 46 593 minecraft:light_blue_stained_glass
setblock 76 45 597 minecraft:calcite
fill 76 45 598 76 48 598 minecraft:cobbled_deepslate
fill 77 45 597 77 48 597 minecraft:cobbled_deepslate
setblock 78 45 559 minecraft:cobbled_deepslate
fill 78 45 591 78 54 591 minecraft:deepslate
fill 78 45 596 78 48 596 minecraft:cobbled_deepslate
setblock 79 45 559 minecraft:calcite
setblock 80 45 558 minecraft:calcite
fill 80 45 559 83 45 559 minecraft:cobbled_deepslate
setblock 80 45 598 minecraft:calcite
fill 81 45 558 81 48 558 minecraft:cobbled_deepslate
setblock 81 45 597 minecraft:calcite
fill 81 45 598 81 48 598 minecraft:cobbled_deepslate
setblock 82 45 596 minecraft:calcite
fill 82 45 597 82 48 597 minecraft:cobbled_deepslate
fill 83 45 596 83 48 596 minecraft:cobbled_deepslate
setblock 84 45 559 minecraft:calcite
setblock 85 45 558 minecraft:calcite
fill 85 45 559 85 48 559 minecraft:cobbled_deepslate
setblock 85 45 598 minecraft:calcite
fill 86 45 558 86 48 558 minecraft:cobbled_deepslate
setblock 86 45 576 minecraft:cobbled_deepslate
setblock 86 45 577 minecraft:calcite
fill 86 45 578 86 48 578 minecraft:cobbled_deepslate
setblock 86 45 581 minecraft:cobbled_deepslate
setblock 86 45 582 minecraft:calcite
setblock 86 45 597 minecraft:calcite
fill 86 45 598 86 48 598 minecraft:cobbled_deepslate
setblock 87 45 576 minecraft:calcite
fill 87 45 577 87 48 577 minecraft:cobbled_deepslate
setblock 87 45 581 minecraft:calcite
fill 87 45 582 87 48 582 minecraft:cobbled_deepslate
setblock 87 45 585 minecraft:cobbled_deepslate
setblock 87 45 592 minecraft:cobbled_deepslate
setblock 87 45 596 minecraft:calcite
fill 87 45 597 87 48 597 minecraft:cobbled_deepslate
setblock 88 45 575 minecraft:calcite
fill 88 45 576 88 48 576 minecraft:cobbled_deepslate
setblock 88 45 580 minecraft:calcite
fill 88 45 581 88 48 581 minecraft:cobbled_deepslate
setblock 88 45 585 minecraft:calcite
fill 88 45 586 88 48 586 minecraft:cobbled_deepslate
setblock 88 45 590 minecraft:calcite
fill 88 45 591 88 47 591 minecraft:cobbled_deepslate
setblock 88 45 595 minecraft:calcite
fill 88 45 596 88 48 596 minecraft:cobbled_deepslate
setblock 48 46 559 minecraft:calcite
fill 48 46 560 48 49 560 minecraft:cobbled_deepslate
fill 48 46 570 48 49 570 minecraft:cobbled_deepslate
setblock 48 46 574 minecraft:calcite
fill 48 46 575 48 49 575 minecraft:cobbled_deepslate
setblock 48 46 579 minecraft:calcite
fill 48 46 580 48 49 580 minecraft:cobbled_deepslate
setblock 48 46 584 minecraft:calcite
fill 48 46 585 48 49 585 minecraft:cobbled_deepslate
setblock 49 46 558 minecraft:calcite
setblock 49 46 573 minecraft:calcite
fill 49 46 574 49 48 574 minecraft:cobbled_deepslate
setblock 49 46 578 minecraft:calcite
fill 49 46 579 49 49 579 minecraft:cobbled_deepslate
setblock 49 46 582 minecraft:cobbled_deepslate
fill 50 46 558 53 46 558 minecraft:cobbled_deepslate
setblock 54 46 558 minecraft:calcite
fill 55 46 558 55 49 558 minecraft:cobbled_deepslate
fill 56 46 559 57 46 559 minecraft:cobbled_deepslate
fill 56 46 598 58 46 598 minecraft:cobbled_deepslate
setblock 58 46 559 minecraft:calcite
fill 58 46 560 59 48 560 minecraft:cobbled_deepslate
setblock 59 46 558 minecraft:calcite
fill 59 46 559 59 49 559 minecraft:cobbled_deepslate
setblock 59 46 597 minecraft:cobbled_deepslate
setblock 59 46 598 minecraft:calcite
fill 60 46 558 60 49 558 minecraft:cobbled_deepslate
setblock 60 46 597 minecraft:calcite
fill 60 46 598 60 49 598 minecraft:cobbled_deepslate
fill 61 46 597 61 49 597 minecraft:cobbled_deepslate
setblock 62 46 560 minecraft:calcite
fill 62 46 561 62 49 561 minecraft:cobbled_deepslate
setblock 63 46 559 minecraft:calcite
fill 63 46 560 63 49 560 minecraft:cobbled_deepslate
setblock 64 46 558 minecraft:calcite
fill 64 46 559 64 49 559 minecraft:cobbled_deepslate
setblock 64 46 598 minecraft:calcite
fill 65 46 558 65 49 558 minecraft:cobbled_deepslate
setblock 65 46 597 minecraft:calcite
fill 65 46 598 68 46 598 minecraft:cobbled_deepslate
fill 66 46 597 66 49 597 minecraft:cobbled_deepslate
setblock 67 46 560 minecraft:calcite
setblock 68 46 559 minecraft:calcite
setblock 69 46 558 minecraft:calcite
fill 69 46 559 69 49 559 minecraft:cobbled_deepslate
setblock 69 46 598 minecraft:calcite
fill 70 46 558 70 49 558 minecraft:cobbled_deepslate
setblock 70 46 597 minecraft:calcite
fill 70 46 598 70 49 598 minecraft:cobbled_deepslate
fill 71 46 559 72 46 559 minecraft:cobbled_deepslate
fill 71 46 597 71 49 597 minecraft:cobbled_deepslate
setblock 74 46 558 minecraft:calcite
fill 74 46 559 77 46 559 minecraft:cobbled_deepslate
setblock 74 46 598 minecraft:calcite
fill 75 46 558 75 49 558 minecraft:cobbled_deepslate
setblock 75 46 597 minecraft:calcite
fill 75 46 598 75 49 598 minecraft:cobbled_deepslate
setblock 76 46 596 minecraft:light_blue_stained_glass
fill 76 46 597 76 49 597 minecraft:cobbled_deepslate
fill 77 46 592 77 47 592 minecraft:light_blue_stained_glass
fill 77 46 596 77 49 596 minecraft:cobbled_deepslate
setblock 78 46 559 minecraft:calcite
setblock 79 46 558 minecraft:calcite
fill 79 46 559 82 46 559 minecraft:cobbled_deepslate
setblock 79 46 598 minecraft:calcite
fill 80 46 558 80 49 558 minecraft:cobbled_deepslate
setblock 80 46 597 minecraft:calcite
fill 80 46 598 80 49 598 minecraft:cobbled_deepslate
setblock 81 46 596 minecraft:calcite
fill 81 46 597 81 49 597 minecraft:cobbled_deepslate
fill 82 46 596 82 49 596 minecraft:cobbled_deepslate
setblock 83 46 559 minecraft:calcite
setblock 84 46 558 minecraft:calcite
fill 84 46 559 84 49 559 minecraft:cobbled_deepslate
setblock 84 46 598 minecraft:calcite
fill 85 46 558 85 49 558 minecraft:cobbled_deepslate
setblock 85 46 597 minecraft:calcite
fill 85 46 598 85 49 598 minecraft:cobbled_deepslate
setblock 86 46 576 minecraft:calcite
fill 86 46 577 86 49 577 minecraft:cobbled_deepslate
setblock 86 46 581 minecraft:calcite
fill 86 46 582 86 48 583 minecraft:cobbled_deepslate
fill 86 46 584 86 46 585 minecraft:calcite
fill 86 46 597 86 49 597 minecraft:cobbled_deepslate
setblock 87 46 575 minecraft:calcite
fill 87 46 576 87 49 576 minecraft:cobbled_deepslate
setblock 87 46 580 minecraft:calcite
fill 87 46 581 87 49 581 minecraft:cobbled_deepslate
setblock 87 46 585 minecraft:calcite
fill 87 46 586 87 49 586 minecraft:cobbled_deepslate
setblock 87 46 595 minecraft:calcite
fill 87 46 596 87 47 596 minecraft:cobbled_deepslate
setblock 88 46 559 minecraft:calcite
setblock 88 46 574 minecraft:calcite
fill 88 46 575 88 49 575 minecraft:cobbled_deepslate
setblock 88 46 579 minecraft:calcite
fill 88 46 580 88 49 580 minecraft:cobbled_deepslate
setblock 88 46 584 minecraft:calcite
fill 88 46 585 88 49 585 minecraft:cobbled_deepslate
setblock 88 46 589 minecraft:calcite
fill 88 46 590 88 49 590 minecraft:cobbled_deepslate
setblock 88 46 594 minecraft:calcite
fill 88 46 595 88 48 595 minecraft:cobbled_deepslate
setblock 48 47 558 minecraft:calcite
fill 48 47 559 48 50 559 minecraft:cobbled_deepslate
fill 48 47 561 48 47 562 minecraft:cobbled_deepslate
setblock 48 47 573 minecraft:calcite
fill 48 47 574 48 50 574 minecraft:cobbled_deepslate
setblock 48 47 578 minecraft:calcite
fill 48 47 579 48 50 579 minecraft:cobbled_deepslate
setblock 48 47 583 minecraft:calcite
fill 48 47 584 48 50 584 minecraft:cobbled_deepslate
fill 48 47 586 48 48 586 minecraft:cobbled_deepslate
setblock 48 47 598 minecraft:calcite
fill 49 47 558 52 47 558 minecraft:cobbled_deepslate
setblock 49 47 577 minecraft:calcite
fill 49 47 578 49 50 578 minecraft:cobbled_deepslate
setblock 49 47 582 minecraft:calcite
setblock 53 47 558 minecraft:calcite
fill 54 47 558 54 49 559 minecraft:cobbled_deepslate
fill 55 47 559 56 47 559 minecraft:cobbled_deepslate
fill 55 47 598 57 47 598 minecraft:cobbled_deepslate
setblock 56 47 560 minecraft:calcite
setblock 57 47 559 minecraft:calcite
fill 57 47 560 57 50 560 minecraft:cobbled_deepslate
setblock 58 47 558 minecraft:calcite
fill 58 47 559 58 50 559 minecraft:cobbled_deepslate
setblock 58 47 597 minecraft:cobbled_deepslate
setblock 58 47 598 minecraft:calcite
fill 59 47 558 59 50 558 minecraft:cobbled_deepslate
setblock 59 47 561 minecraft:cobbled_deepslate
setblock 59 47 597 minecraft:calcite
fill 59 47 598 59 50 598 minecraft:cobbled_deepslate
setblock 60 47 561 minecraft:calcite
fill 60 47 597 60 50 597 minecraft:cobbled_deepslate
setblock 61 47 559 minecraft:cobbled_deepslate
setblock 61 47 560 minecraft:calcite
fill 61 47 561 61 50 561 minecraft:cobbled_deepslate
setblock 62 47 559 minecraft:calcite
fill 62 47 560 62 50 560 minecraft:cobbled_deepslate
setblock 63 47 558 minecraft:calcite
fill 63 47 559 63 50 559 minecraft:cobbled_deepslate
fill 63 47 561 64 47 561 minecraft:cobbled_deepslate
setblock 63 47 598 minecraft:calcite
fill 64 47 558 64 50 558 minecraft:cobbled_deepslate
setblock 64 47 597 minecraft:calcite
fill 64 47 598 67 47 598 minecraft:cobbled_deepslate
setblock 65 47 560 minecraft:cobbled_deepslate
fill 65 47 597 65 50 597 minecraft:cobbled_deepslate
setblock 66 47 560 minecraft:calcite
setblock 67 47 559 minecraft:calcite
fill 67 47 560 68 49 560 minecraft:cobbled_deepslate
setblock 68 47 558 minecraft:calcite
fill 68 47 559 68 50 559 minecraft:cobbled_deepslate
setblock 68 47 598 minecraft:calcite
fill 69 47 558 69 50 558 minecraft:cobbled_deepslate
setblock 69 47 597 minecraft:calcite
fill 69 47 598 69 50 598 minecraft:cobbled_deepslate
fill 70 47 597 70 49 597 minecraft:cobbled_deepslate
setblock 71 47 559 minecraft:cobbled_deepslate
setblock 72 47 559 minecraft:calcite
setblock 73 47 558 minecraft:calcite
fill 73 47 559 76 47 559 minecraft:cobbled_deepslate
setblock 73 47 597 minecraft:cobbled_deepslate
setblock 73 47 598 minecraft:calcite
fill 74 47 558 74 50 558 minecraft:cobbled_deepslate
setblock 74 47 597 minecraft:calcite
fill 74 47 598 74 50 598 minecraft:cobbled_deepslate
fill 75 47 597 75 50 597 minecraft:cobbled_deepslate
fill 76 47 596 76 50 596 minecraft:cobbled_deepslate
setblock 77 47 559 minecraft:calcite
fill 77 47 591 77 54 591 minecraft:deepslate
setblock 77 47 593 minecraft:light_blue_stained_glass
setblock 78 47 558 minecraft:calcite
fill 78 47 559 81 47 559 minecraft:cobbled_deepslate
fill 78 47 592 78 54 592 minecraft:deepslate
setblock 78 47 598 minecraft:calcite
fill 79 47 558 79 50 558 minecraft:cobbled_deepslate
fill 79 47 591 79 54 591 minecraft:deepslate
setblock 79 47 597 minecraft:calcite
fill 79 47 598 79 50 598 minecraft:cobbled_deepslate
setblock 80 47 560 minecraft:cobbled_deepslate
setblock 80 47 596 minecraft:calcite
fill 80 47 597 80 50 597 minecraft:cobbled_deepslate
setblock 81 47 560 minecraft:calcite
fill 81 47 579 83 48 579 minecraft:light_blue_stained_glass
fill 81 47 596 81 50 596 minecraft:cobbled_deepslate
setblock 82 47 559 minecraft:calcite
setblock 83 47 558 minecraft:calcite
fill 83 47 559 83 50 559 minecraft:cobbled_deepslate
setblock 83 47 598 minecraft:calcite
fill 84 47 558 84 50 558 minecraft:cobbled_deepslate
setblock 84 47 597 minecraft:calcite
fill 84 47 598 84 50 598 minecraft:cobbled_deepslate
setblock 85 47 580 minecraft:cobbled_deepslate
setblock 85 47 581 minecraft:calcite
setblock 85 47 596 minecraft:calcite
fill 85 47 597 85 50 597 minecraft:cobbled_deepslate
setblock 86 47 559 minecraft:cobbled_deepslate
setblock 86 47 576 minecraft:cobbled_deepslate
setblock 86 47 579 minecraft:cobbled_deepslate
setblock 86 47 580 minecraft:calcite
fill 86 47 581 86 50 581 minecraft:cobbled_deepslate
setblock 86 47 584 minecraft:cobbled_deepslate
setblock 86 47 585 minecraft:calcite
setblock 87 47 574 minecraft:calcite
fill 87 47 575 87 49 575 minecraft:cobbled_deepslate
setblock 87 47 579 minecraft:calcite
fill 87 47 580 87 50 580 minecraft:cobbled_deepslate
setblock 87 47 583 minecraft:cobbled_deepslate
setblock 87 47 584 minecraft:calcite
fill 87 47 585 87 50 585 minecraft:cobbled_deepslate
fill 87 47 587 87 48 587 minecraft:cobbled_deepslate
setblock 87 47 595 minecraft:cobbled_deepslate
setblock 88 47 558 minecraft:calcite
fill 88 47 559 88 49 560 minecraft:cobbled_deepslate
setblock 88 47 573 minecraft:calcite
fill 88 47 574 88 50 574 minecraft:cobbled_deepslate
setblock 88 47 578 minecraft:calcite
fill 88 47 579 88 50 579 minecraft:cobbled_deepslate
setblock 88 47 583 minecraft:calcite
fill 88 47 584 88 50 584 minecraft:cobbled_deepslate
setblock 88 47 588 minecraft:calcite
fill 88 47 589 88 50 589 minecraft:cobbled_deepslate
setblock 88 47 593 minecraft:calcite
fill 88 47 594 88 48 594 minecraft:cobbled_deepslate
setblock 88 47 598 minecraft:calcite
fill 48 48 558 51 48 558 minecraft:cobbled_deepslate
setblock 48 48 561 minecraft:cobbled_deepslate
setblock 48 48 562 minecraft:calcite
fill 48 48 563 48 50 564 minecraft:cobbled_deepslate
setblock 48 48 572 minecraft:calcite
fill 48 48 573 48 51 573 minecraft:cobbled_deepslate
setblock 48 48 577 minecraft:calcite
fill 48 48 578 48 51 578 minecraft:cobbled_deepslate
setblock 48 48 582 minecraft:calcite
fill 48 48 583 49 50 583 minecraft:cobbled_deepslate
setblock 49 48 576 minecraft:calcite
fill 49 48 577 49 51 577 minecraft:cobbled_deepslate
setblock 49 48 581 minecraft:calcite
fill 49 48 582 49 51 582 minecraft:cobbled_deepslate
setblock 50 48 560 minecraft:light[level=14]
setblock 50 48 568 minecraft:light[level=14]
setblock 50 48 576 minecraft:light[level=14]
setblock 50 48 584 minecraft:light[level=14]
setblock 50 48 592 minecraft:light[level=14]
setblock 52 48 558 minecraft:calcite
fill 53 48 558 53 50 559 minecraft:cobbled_deepslate
fill 54 48 598 56 48 598 minecraft:cobbled_deepslate
setblock 55 48 559 minecraft:cobbled_deepslate
setblock 55 48 560 minecraft:calcite
setblock 56 48 559 minecraft:calcite
fill 56 48 560 56 51 560 minecraft:cobbled_deepslate
setblock 57 48 558 minecraft:calcite
fill 57 48 559 57 51 559 minecraft:cobbled_deepslate
setblock 57 48 597 minecraft:cobbled_deepslate
setblock 57 48 598 minecraft:calcite
fill 58 48 558 58 51 558 minecraft:cobbled_deepslate
setblock 58 48 561 minecraft:cobbled_deepslate
setblock 58 48 568 minecraft:light[level=14]
setblock 58 48 576 minecraft:light[level=14]
setblock 58 48 584 minecraft:light[level=14]
setblock 58 48 592 minecraft:light[level=14]
setblock 58 48 597 minecraft:calcite
fill 58 48 598 58 51 598 minecraft:cobbled_deepslate
setblock 59 48 561 minecraft:calcite
fill 59 48 597 59 51 597 minecraft:cobbled_deepslate
setblock 60 48 559 minecraft:cobbled_deepslate
setblock 60 48 560 minecraft:calcite
fill 60 48 561 60 51 561 minecraft:cobbled_deepslate
setblock 61 48 559 minecraft:calcite
fill 61 48 560 61 51 560 minecraft:cobbled_deepslate
setblock 62 48 558 minecraft:calcite
fill 62 48 559 62 51 559 minecraft:cobbled_deepslate
setblock 62 48 598 minecraft:calcite
fill 63 48 558 63 51 558 minecraft:cobbled_deepslate
setblock 63 48 561 minecraft:cobbled_deepslate
setblock 63 48 597 minecraft:calcite
fill 63 48 598 66 48 598 minecraft:cobbled_deepslate
setblock 64 48 561 minecraft:calcite
fill 64 48 597 64 51 597 minecraft:cobbled_deepslate
setblock 65 48 560 minecraft:calcite
fill 65 48 561 65 50 561 minecraft:cobbled_deepslate
setblock 66 48 559 minecraft:calcite
fill 66 48 560 66 51 560 minecraft:cobbled_deepslate
setblock 66 48 568 minecraft:light[level=14]
setblock 66 48 576 minecraft:light[level=14]
setblock 66 48 584 minecraft:light[level=14]
setblock 66 48 592 minecraft:light[level=14]
setblock 67 48 558 minecraft:calcite
fill 67 48 559 67 51 559 minecraft:cobbled_deepslate
setblock 67 48 598 minecraft:calcite
fill 68 48 558 68 51 558 minecraft:cobbled_deepslate
setblock 68 48 597 minecraft:calcite
fill 68 48 598 68 51 598 minecraft:cobbled_deepslate
fill 69 48 597 69 49 597 minecraft:cobbled_deepslate
setblock 71 48 559 minecraft:calcite
setblock 72 48 558 minecraft:calcite
fill 72 48 559 75 48 559 minecraft:cobbled_deepslate
setblock 72 48 598 minecraft:calcite
fill 73 48 558 73 51 558 minecraft:cobbled_deepslate
setblock 73 48 597 minecraft:calcite
fill 73 48 598 73 51 598 minecraft:cobbled_deepslate
setblock 74 48 560 minecraft:light[level=14]
setblock 74 48 568 minecraft:light[level=14]
setblock 74 48 576 minecraft:light[level=14]
setblock 74 48 584 minecraft:light[level=14]
setblock 74 48 592 minecraft:light[level=14]
fill 74 48 597 74 51 597 minecraft:cobbled_deepslate
setblock 76 48 559 minecraft:calcite
setblock 77 48 558 minecraft:calcite
fill 77 48 559 79 48 560 minecraft:cobbled_deepslate
fill 77 48 590 79 54 590 minecraft:deepslate
fill 77 48 592 77 54 592 minecraft:deepslate
setblock 77 48 598 minecraft:calcite
fill 78 48 558 78 51 558 minecraft:cobbled_deepslate
setblock 78 48 597 minecraft:calcite
fill 78 48 598 78 51 598 minecraft:cobbled_deepslate
fill 79 48 592 79 54 592 minecraft:deepslate
setblock 79 48 596 minecraft:calcite
fill 79 48 597 79 51 597 minecraft:cobbled_deepslate
setblock 80 48 559 minecraft:cobbled_deepslate
setblock 80 48 560 minecraft:calcite
fill 80 48 596 80 51 596 minecraft:cobbled_deepslate
setblock 81 48 559 minecraft:calcite
fill 81 48 560 82 50 560 minecraft:cobbled_deepslate
setblock 82 48 558 minecraft:calcite
fill 82 48 559 82 51 559 minecraft:cobbled_deepslate
setblock 82 48 568 minecraft:light[level=14]
setblock 82 48 576 minecraft:light[level=14]
fill 82 48 578 85 48 578 minecraft:light_blue_stained_glass
fill 82 48 580 84 48 580 minecraft:light_blue_stained_glass
setblock 82 48 584 minecraft:light[level=14]
setblock 82 48 592 minecraft:light[level=14]
setblock 82 48 598 minecraft:calcite
fill 83 48 558 83 51 558 minecraft:cobbled_deepslate
setblock 83 48 597 minecraft:calcite
fill 83 48 598 83 51 598 minecraft:cobbled_deepslate
fill 84 48 579 84 50 579 minecraft:light_blue_stained_glass
setblock 84 48 596 minecraft:calcite
fill 84 48 597 84 51 597 minecraft:cobbled_deepslate
setblock 85 48 579 minecraft:cobbled_deepslate
setblock 85 48 580 minecraft:calcite
fill 85 48 581 85 50 582 minecraft:cobbled_deepslate
setblock 86 48 559 minecraft:calcite
setblock 86 48 579 minecraft:calcite
fill 86 48 580 86 51 580 minecraft:cobbled_deepslate
setblock 86 48 584 minecraft:calcite
fill 86 48 585 86 51 585 minecraft:cobbled_deepslate
setblock 87 48 558 minecraft:calcite
setblock 87 48 578 minecraft:calcite
fill 87 48 579 87 51 579 minecraft:cobbled_deepslate
setblock 87 48 583 minecraft:calcite
fill 87 48 584 87 51 584 minecraft:cobbled_deepslate
setblock 87 48 598 minecraft:calcite
fill 88 48 558 88 50 558 minecraft:cobbled_deepslate
setblock 88 48 561 minecraft:cobbled_deepslate
fill 88 48 573 88 49 573 minecraft:cobbled_deepslate
setblock 88 48 577 minecraft:calcite
fill 88 48 578 88 51 578 minecraft:cobbled_deepslate
setblock 88 48 582 minecraft:calcite
fill 88 48 583 88 51 583 minecraft:cobbled_deepslate
setblock 88 48 587 minecraft:calcite
fill 88 48 588 88 51 588 minecraft:cobbled_deepslate
setblock 88 48 593 minecraft:cobbled_deepslate
setblock 88 48 597 minecraft:calcite
fill 88 48 598 88 50 598 minecraft:cobbled_deepslate
fill 48 49 558 50 49 558 minecraft:cobbled_deepslate
setblock 48 49 561 minecraft:calcite
fill 48 49 562 48 52 562 minecraft:cobbled_deepslate
setblock 48 49 565 minecraft:cobbled_deepslate
setblock 48 49 566 minecraft:calcite
fill 48 49 567 48 52 567 minecraft:cobbled_deepslate
setblock 48 49 571 minecraft:calcite
fill 48 49 572 48 51 572 minecraft:cobbled_deepslate
setblock 48 49 576 minecraft:calcite
fill 48 49 577 48 52 577 minecraft:cobbled_deepslate
setblock 48 49 581 minecraft:calcite
fill 48 49 582 48 52 582 minecraft:cobbled_deepslate
setblock 48 49 586 minecraft:calcite
setblock 49 49 575 minecraft:calcite
fill 49 49 576 49 50 576 minecraft:cobbled_deepslate
setblock 49 49 580 minecraft:calcite
fill 49 49 581 49 52 581 minecraft:cobbled_deepslate
setblock 51 49 558 minecraft:calcite
fill 51 49 559 52 51 559 minecraft:cobbled_deepslate
fill 52 49 558 52 52 558 minecraft:cobbled_deepslate
setblock 54 49 560 minecraft:calcite
fill 54 49 598 55 49 598 minecraft:cobbled_deepslate
setblock 55 49 559 minecraft:calcite
fill 55 49 560 55 52 560 minecraft:cobbled_deepslate
setblock 56 49 558 minecraft:calcite
fill 56 49 559 56 52 559 minecraft:cobbled_deepslate
fill 56 49 561 57 49 561 minecraft:cobbled_deepslate
setblock 56 49 598 minecraft:calcite
fill 57 49 558 57 52 558 minecraft:cobbled_deepslate
setblock 57 49 597 minecraft:calcite
fill 57 49 598 57 52 598 minecraft:cobbled_deepslate
setblock 58 49 560 minecraft:cobbled_deepslate
setblock 58 49 561 minecraft:calcite
fill 58 49 597 58 52 597 minecraft:cobbled_deepslate
setblock 59 49 560 minecraft:calcite
fill 59 49 561 59 52 561 minecraft:cobbled_deepslate
setblock 60 49 559 minecraft:calcite
fill 60 49 560 60 52 560 minecraft:cobbled_deepslate
setblock 61 49 558 minecraft:calcite
fill 61 49 559 61 52 559 minecraft:cobbled_deepslate
setblock 61 49 598 minecraft:calcite
fill 62 49 558 62 52 558 minecraft:cobbled_deepslate
setblock 62 49 597 minecraft:calcite
fill 62 49 598 65 49 598 minecraft:cobbled_deepslate
setblock 63 49 561 minecraft:calcite
fill 63 49 597 63 52 597 minecraft:cobbled_deepslate
setblock 64 49 560 minecraft:calcite
fill 64 49 561 64 51 561 minecraft:cobbled_deepslate
setblock 65 49 559 minecraft:calcite
fill 65 49 560 65 52 560 minecraft:cobbled_deepslate
setblock 66 49 558 minecraft:calcite
fill 66 49 559 66 52 559 minecraft:cobbled_deepslate
setblock 66 49 598 minecraft:calcite
fill 67 49 558 67 52 558 minecraft:cobbled_deepslate
setblock 67 49 597 minecraft:calcite
fill 67 49 598 67 52 598 minecraft:cobbled_deepslate
setblock 68 49 597 minecraft:cobbled_deepslate
setblock 70 49 559 minecraft:calcite
setblock 71 49 558 minecraft:calcite
fill 71 49 559 74 49 559 minecraft:cobbled_deepslate
setblock 71 49 598 minecraft:calcite
fill 72 49 558 72 52 558 minecraft:cobbled_deepslate
setblock 72 49 597 minecraft:calcite
fill 72 49 598 72 52 598 minecraft:cobbled_deepslate
fill 73 49 597 73 52 597 minecraft:cobbled_deepslate
setblock 75 49 559 minecraft:calcite
setblock 76 49 558 minecraft:calcite
fill 76 49 559 78 49 560 minecraft:cobbled_deepslate
fill 76 49 591 76 54 592 minecraft:deepslate
setblock 76 49 598 minecraft:calcite
fill 77 49 558 77 52 558 minecraft:cobbled_deepslate
fill 77 49 593 79 54 593 minecraft:deepslate
setblock 77 49 597 minecraft:calcite
fill 77 49 598 77 52 598 minecraft:cobbled_deepslate
setblock 78 49 596 minecraft:calcite
fill 78 49 597 78 52 597 minecraft:cobbled_deepslate
setblock 79 49 559 minecraft:cobbled_deepslate
setblock 79 49 560 minecraft:calcite
fill 79 49 596 79 52 596 minecraft:cobbled_deepslate
setblock 80 49 559 minecraft:calcite
fill 80 49 560 80 52 560 minecraft:cobbled_deepslate
fill 80 49 591 80 54 591 minecraft:deepslate
setblock 81 49 558 minecraft:calcite
fill 81 49 559 81 52 559 minecraft:cobbled_deepslate
setblock 81 49 598 minecraft:calcite
fill 82 49 558 82 52 558 minecraft:cobbled_deepslate
fill 82 49 579 83 49 579 minecraft:light_blue_stained_glass
setblock 82 49 597 minecraft:calcite
fill 82 49 598 82 52 598 minecraft:cobbled_deepslate
fill 83 49 578 85 49 578 minecraft:light_blue_stained_glass
fill 83 49 580 84 49 580 minecraft:light_blue_stained_glass
setblock 83 49 596 minecraft:calcite
fill 83 49 597 83 51 597 minecraft:cobbled_deepslate
fill 84 49 583 84 74 586 minecraft:calcite
setblock 85 49 559 minecraft:calcite
setblock 85 49 579 minecraft:calcite
fill 85 49 580 85 50 580 minecraft:cobbled_deepslate
setblock 85 49 583 minecraft:cobbled_deepslate
fill 85 49 584 85 74 586 minecraft:calcite
setblock 86 49 558 minecraft:calcite
setblock 86 49 559 minecraft:cobbled_deepslate
setblock 86 49 578 minecraft:calcite
fill 86 49 579 86 51 579 minecraft:cobbled_deepslate
setblock 86 49 582 minecraft:cobbled_deepslate
setblock 86 49 583 minecraft:calcite
fill 86 49 584 86 52 584 minecraft:cobbled_deepslate
setblock 86 49 598 minecraft:calcite
fill 87 49 558 87 51 558 minecraft:cobbled_deepslate
setblock 87 49 577 minecraft:calcite
fill 87 49 578 87 52 578 minecraft:cobbled_deepslate
setblock 87 49 582 minecraft:calcite
fill 87 49 583 87 52 583 minecraft:cobbled_deepslate
setblock 87 49 587 minecraft:calcite
fill 87 49 598 87 50 598 minecraft:cobbled_deepslate
setblock 88 49 561 minecraft:calcite
setblock 88 49 576 minecraft:calcite
fill 88 49 577 88 52 577 minecraft:cobbled_deepslate
setblock 88 49 581 minecraft:calcite
fill 88 49 582 88 52 582 minecraft:cobbled_deepslate
setblock 88 49 586 minecraft:calcite
fill 88 49 587 88 52 587 minecraft:cobbled_deepslate
setblock 88 49 596 minecraft:calcite
setblock 88 49 597 minecraft:cobbled_deepslate
fill 48 50 558 49 50 558 minecraft:cobbled_deepslate
setblock 48 50 560 minecraft:calcite
fill 48 50 561 49 52 561 minecraft:cobbled_deepslate
setblock 48 50 565 minecraft:calcite
fill 48 50 566 48 53 566 minecraft:cobbled_deepslate
fill 48 50 568 48 50 569 minecraft:cobbled_deepslate
setblock 48 50 570 minecraft:calcite
setblock 48 50 571 minecraft:cobbled_deepslate
setblock 48 50 575 minecraft:calcite
fill 48 50 576 48 52 576 minecraft:cobbled_deepslate
setblock 48 50 580 minecraft:calcite
fill 48 50 581 48 53 581 minecraft:cobbled_deepslate
setblock 48 50 585 minecraft:calcite
fill 48 50 586 48 53 586 minecraft:cobbled_deepslate
fill 49 50 560 49 51 560 minecraft:cobbled_deepslate
fill 49 50 562 49 51 562 minecraft:cobbled_deepslate
setblock 49 50 579 minecraft:calcite
fill 49 50 580 49 52 580 minecraft:cobbled_deepslate
setblock 50 50 558 minecraft:calcite
fill 50 50 559 50 51 559 minecraft:cobbled_deepslate
fill 51 50 558 51 53 558 minecraft:cobbled_deepslate
setblock 53 50 560 minecraft:calcite
setblock 54 50 558 minecraft:cobbled_deepslate
setblock 54 50 559 minecraft:calcite
fill 54 50 560 54 53 560 minecraft:cobbled_deepslate
setblock 54 50 598 minecraft:cobbled_deepslate
setblock 55 50 558 minecraft:calcite
fill 55 50 559 55 53 559 minecraft:cobbled_deepslate
fill 55 50 561 56 50 561 minecraft:cobbled_deepslate
setblock 55 50 598 minecraft:calcite
fill 56 50 558 56 53 558 minecraft:cobbled_deepslate
fill 56 50 598 56 53 598 minecraft:cobbled_deepslate
setblock 57 50 561 minecraft:calcite
fill 57 50 597 57 51 597 minecraft:cobbled_deepslate
setblock 58 50 560 minecraft:calcite
fill 58 50 561 58 53 561 minecraft:cobbled_deepslate
setblock 59 50 559 minecraft:calcite
fill 59 50 560 59 53 560 minecraft:cobbled_deepslate
fill 59 50 562 60 50 562 minecraft:cobbled_deepslate
setblock 60 50 558 minecraft:calcite
fill 60 50 559 60 53 559 minecraft:cobbled_deepslate
setblock 60 50 598 minecraft:calcite
fill 61 50 558 61 53 558 minecraft:cobbled_deepslate
setblock 61 50 562 minecraft:calcite
setblock 61 50 597 minecraft:calcite
fill 61 50 598 64 50 598 minecraft:cobbled_deepslate
setblock 62 50 561 minecraft:calcite
fill 62 50 597 62 52 597 minecraft:cobbled_deepslate
setblock 63 50 560 minecraft:calcite
fill 63 50 561 63 52 561 minecraft:cobbled_deepslate
setblock 64 50 559 minecraft:calcite
fill 64 50 560 64 53 560 minecraft:cobbled_deepslate
setblock 65 50 558 minecraft:calcite
fill 65 50 559 65 53 559 minecraft:cobbled_deepslate
setblock 65 50 598 minecraft:calcite
fill 66 50 558 66 53 558 minecraft:cobbled_deepslate
setblock 66 50 597 minecraft:calcite
fill 66 50 598 66 53 598 minecraft:cobbled_deepslate
setblock 67 50 560 minecraft:cobbled_deepslate
setblock 67 50 597 minecraft:cobbled_deepslate
setblock 68 50 560 minecraft:calcite
setblock 69 50 559 minecraft:calcite
setblock 70 50 558 minecraft:calcite
fill 70 50 559 73 50 559 minecraft:cobbled_deepslate
setblock 70 50 598 minecraft:calcite
fill 71 50 558 71 53 558 minecraft:cobbled_deepslate
setblock 71 50 597 minecraft:calcite
fill 71 50 598 71 53 598 minecraft:cobbled_deepslate
fill 72 50 597 72 51 597 minecraft:cobbled_deepslate
setblock 74 50 559 minecraft:calcite
setblock 75 50 558 minecraft:calcite
fill 75 50 559 77 50 560 minecraft:cobbled_deepslate
setblock 75 50 598 minecraft:calcite
fill 76 50 558 76 53 558 minecraft:cobbled_deepslate
fill 76 50 590 76 54 590 minecraft:deepslate
fill 76 50 593 76 54 593 minecraft:deepslate
setblock 76 50 597 minecraft:calcite
fill 76 50 598 76 53 598 minecraft:cobbled_deepslate
fill 77 50 589 79 54 589 minecraft:deepslate
setblock 77 50 596 minecraft:calcite
fill 77 50 597 77 53 597 minecraft:cobbled_deepslate
setblock 78 50 559 minecraft:cobbled_deepslate
setblock 78 50 560 minecraft:calcite
fill 78 50 596 78 52 596 minecraft:cobbled_deepslate
setblock 79 50 559 minecraft:calcite
fill 79 50 560 79 52 560 minecraft:cobbled_deepslate
setblock 80 50 558 minecraft:calcite
fill 80 50 559 80 53 559 minecraft:cobbled_deepslate
fill 80 50 590 80 54 590 minecraft:deepslate
fill 80 50 592 80 54 592 minecraft:deepslate
setblock 80 50 598 minecraft:calcite
fill 81 50 558 81 53 558 minecraft:cobbled_deepslate
setblock 81 50 597 minecraft:calcite
fill 81 50 598 81 53 598 minecraft:cobbled_deepslate
setblock 82 50 596 minecraft:calcite
fill 82 50 597 82 52 597 minecraft:cobbled_deepslate
setblock 84 50 559 minecraft:calcite
fill 84 50 578 85 50 578 minecraft:light_blue_stained_glass
setblock 84 50 580 minecraft:light_blue_stained_glass
setblock 85 50 558 minecraft:calcite
setblock 85 50 559 minecraft:cobbled_deepslate
fill 85 50 579 85 51 579 minecraft:light_blue_stained_glass
setblock 85 50 583 minecraft:calcite
setblock 85 50 598 minecraft:calcite
fill 86 50 558 86 51 558 minecraft:cobbled_deepslate
setblock 86 50 577 minecraft:light_blue_stained_glass
setblock 86 50 578 minecraft:cobbled_deepslate
setblock 86 50 582 minecraft:calcite
fill 86 50 583 86 53 583 minecraft:cobbled_deepslate
setblock 86 50 586 minecraft:cobbled_deepslate
fill 86 50 598 86 51 598 minecraft:cobbled_deepslate
setblock 87 50 576 minecraft:calcite
fill 87 50 577 87 51 577 minecraft:cobbled_deepslate
setblock 87 50 581 minecraft:calcite
fill 87 50 582 87 53 582 minecraft:cobbled_deepslate
setblock 87 50 586 minecraft:calcite
fill 87 50 587 87 52 587 minecraft:cobbled_deepslate
setblock 88 50 559 minecraft:cobbled_deepslate
setblock 88 50 560 minecraft:calcite
fill 88 50 561 88 52 562 minecraft:cobbled_deepslate
setblock 88 50 575 minecraft:calcite
fill 88 50 576 88 52 576 minecraft:cobbled_deepslate
setblock 88 50 580 minecraft:calcite
fill 88 50 581 88 53 581 minecraft:cobbled_deepslate
setblock 88 50 585 minecraft:calcite
fill 88 50 586 88 53 586 minecraft:cobbled_deepslate
setblock 48 51 558 minecraft:cobbled_deepslate
setblock 48 51 559 minecraft:calcite
fill 48 51 560 48 54 560 minecraft:cobbled_deepslate
setblock 48 51 563 minecraft:cobbled_deepslate
setblock 48 51 564 minecraft:calcite
fill 48 51 565 48 54 565 minecraft:cobbled_deepslate
setblock 48 51 568 minecraft:cobbled_deepslate
setblock 48 51 569 minecraft:calcite
setblock 48 51 574 minecraft:calcite
fill 48 51 575 48 52 575 minecraft:cobbled_deepslate
setblock 48 51 579 minecraft:calcite
fill 48 51 580 48 54 580 minecraft:cobbled_deepslate
setblock 48 51 583 minecraft:cobbled_deepslate
setblock 48 51 584 minecraft:calcite
fill 48 51 585 48 54 585 minecraft:cobbled_deepslate
setblock 49 51 558 minecraft:calcite
setblock 49 51 563 minecraft:calcite
setblock 49 51 578 minecraft:calcite
fill 49 51 579 49 52 579 minecraft:cobbled_deepslate
setblock 49 51 583 minecraft:calcite
fill 50 51 558 50 54 558 minecraft:cobbled_deepslate
setblock 53 51 558 minecraft:cobbled_deepslate
setblock 53 51 559 minecraft:calcite
fill 53 51 560 53 54 560 minecraft:cobbled_deepslate
setblock 54 51 558 minecraft:calcite
fill 54 51 559 54 54 559 minecraft:cobbled_deepslate
setblock 54 51 598 minecraft:calcite
fill 55 51 558 55 54 558 minecraft:cobbled_deepslate
setblock 55 51 561 minecraft:cobbled_deepslate
fill 55 51 598 55 54 598 minecraft:cobbled_deepslate
setblock 56 51 561 minecraft:calcite
setblock 57 51 560 minecraft:calcite
fill 57 51 561 57 54 561 minecraft:cobbled_deepslate
setblock 58 51 559 minecraft:calcite
fill 58 51 560 58 54 560 minecraft:cobbled_deepslate
fill 58 51 562 59 51 562 minecraft:cobbled_deepslate
setblock 59 51 558 minecraft:calcite
fill 59 51 559 59 54 559 minecraft:cobbled_deepslate
setblock 59 51 598 minecraft:calcite
fill 60 51 558 60 54 558 minecraft:cobbled_deepslate
setblock 60 51 562 minecraft:calcite
setblock 60 51 597 minecraft:calcite
fill 60 51 598 63 51 598 minecraft:cobbled_deepslate
setblock 61 51 561 minecraft:calcite
fill 61 51 597 61 52 597 minecraft:cobbled_deepslate
setblock 62 51 560 minecraft:calcite
fill 62 51 561 62 53 561 minecraft:cobbled_deepslate
setblock 63 51 559 minecraft:calcite
fill 63 51 560 63 54 560 minecraft:cobbled_deepslate
setblock 64 51 558 minecraft:calcite
fill 64 51 559 64 54 559 minecraft:cobbled_deepslate
setblock 64 51 598 minecraft:calcite
fill 65 51 558 65 54 558 minecraft:cobbled_deepslate
setblock 65 51 597 minecraft:calcite
fill 65 51 598 65 53 598 minecraft:cobbled_deepslate
setblock 67 51 560 minecraft:calcite
setblock 68 51 559 minecraft:calcite
fill 68 51 560 70 53 560 minecraft:light_blue_stained_glass
setblock 69 51 558 minecraft:calcite
fill 69 51 559 72 51 559 minecraft:cobbled_deepslate
setblock 69 51 598 minecraft:calcite
fill 70 51 558 70 54 558 minecraft:cobbled_deepslate
fill 70 51 598 70 54 598 minecraft:cobbled_deepslate
setblock 73 51 559 minecraft:calcite
setblock 74 51 558 minecraft:calcite
fill 74 51 559 77 51 559 minecraft:cobbled_deepslate
setblock 74 51 598 minecraft:calcite
fill 75 51 558 75 54 558 minecraft:cobbled_deepslate
fill 75 51 560 76 51 560 minecraft:cobbled_deepslate
fill 75 51 591 75 54 592 minecraft:deepslate
setblock 75 51 597 minecraft:calcite
fill 75 51 598 75 54 598 minecraft:cobbled_deepslate
fill 76 51 589 76 54 589 minecraft:deepslate
setblock 76 51 596 minecraft:calcite
fill 76 51 597 76 54 597 minecraft:cobbled_deepslate
setblock 77 51 560 minecraft:calcite
fill 77 51 594 79 54 594 minecraft:deepslate
setblock 77 51 596 minecraft:cobbled_deepslate
setblock 78 51 559 minecraft:calcite
fill 78 51 560 78 52 560 minecraft:cobbled_deepslate
setblock 79 51 558 minecraft:calcite
fill 79 51 559 79 54 559 minecraft:cobbled_deepslate
setblock 79 51 598 minecraft:calcite
fill 80 51 558 80 54 558 minecraft:cobbled_deepslate
fill 80 51 589 80 54 589 minecraft:deepslate
fill 80 51 593 80 54 593 minecraft:deepslate
setblock 80 51 597 minecraft:calcite
fill 80 51 598 80 54 598 minecraft:cobbled_deepslate
setblock 81 51 560 minecraft:cobbled_deepslate
fill 81 51 591 81 54 591 minecraft:deepslate
setblock 81 51 596 minecraft:calcite
fill 81 51 597 81 53 597 minecraft:cobbled_deepslate
setblock 83 51 559 minecraft:calcite
setblock 84 51 558 minecraft:calcite
setblock 84 51 559 minecraft:cobbled_deepslate
setblock 84 51 598 minecraft:calcite
fill 85 51 558 85 52 558 minecraft:cobbled_deepslate
setblock 85 51 582 minecraft:calcite
setblock 85 51 583 minecraft:cobbled_deepslate
fill 85 51 598 85 52 598 minecraft:cobbled_deepslate
setblock 86 51 578 minecraft:light_blue_stained_glass
setblock 86 51 581 minecraft:calcite
fill 86 51 582 86 53 582 minecraft:cobbled_deepslate
fill 86 51 586 86 74 586 minecraft:calcite
setblock 87 51 580 minecraft:calcite
fill 87 51 581 87 54 581 minecraft:cobbled_deepslate
setblock 87 51 585 minecraft:calcite
fill 87 51 586 87 54 586 minecraft:cobbled_deepslate
setblock 88 51 559 minecraft:calcite
setblock 88 51 560 minecraft:cobbled_deepslate
setblock 88 51 574 minecraft:calcite
fill 88 51 575 88 52 575 minecraft:cobbled_deepslate
setblock 88 51 579 minecraft:calcite
fill 88 51 580 88 54 580 minecraft:cobbled_deepslate
setblock 88 51 584 minecraft:calcite
fill 88 51 585 88 54 585 minecraft:cobbled_deepslate
setblock 88 51 589 minecraft:calcite
setblock 48 52 558 minecraft:calcite
fill 48 52 559 48 53 559 minecraft:cobbled_deepslate
setblock 48 52 563 minecraft:calcite
fill 48 52 564 49 54 564 minecraft:cobbled_deepslate
setblock 48 52 568 minecraft:calcite
setblock 48 52 574 minecraft:cobbled_deepslate
setblock 48 52 578 minecraft:calcite
fill 48 52 579 48 54 579 minecraft:cobbled_deepslate
setblock 48 52 583 minecraft:calcite
fill 48 52 584 48 55 584 minecraft:cobbled_deepslate
fill 49 52 558 49 53 558 minecraft:cobbled_deepslate
setblock 49 52 562 minecraft:calcite
fill 49 52 563 49 55 563 minecraft:cobbled_deepslate
setblock 49 52 582 minecraft:calcite
setblock 51 52 559 minecraft:cobbled_deepslate
setblock 52 52 559 minecraft:calcite
setblock 53 52 558 minecraft:calcite
fill 53 52 559 53 55 559 minecraft:cobbled_deepslate
fill 54 52 558 54 55 558 minecraft:cobbled_deepslate
setblock 54 52 598 minecraft:cobbled_deepslate
setblock 55 52 561 minecraft:calcite
setblock 56 52 560 minecraft:calcite
fill 56 52 561 56 55 561 minecraft:cobbled_deepslate
setblock 57 52 559 minecraft:calcite
fill 57 52 560 57 55 560 minecraft:cobbled_deepslate
setblock 58 52 558 minecraft:calcite
fill 58 52 559 58 55 559 minecraft:cobbled_deepslate
setblock 58 52 562 minecraft:cobbled_deepslate
setblock 58 52 598 minecraft:calcite
fill 59 52 558 59 55 558 minecraft:cobbled_deepslate
setblock 59 52 562 minecraft:calcite
setblock 59 52 597 minecraft:calcite
fill 59 52 598 62 52 598 minecraft:cobbled_deepslate
setblock 60 52 561 minecraft:calcite
setblock 60 52 562 minecraft:cobbled_deepslate
setblock 60 52 597 minecraft:cobbled_deepslate
setblock 61 52 560 minecraft:calcite
fill 61 52 561 61 54 561 minecraft:cobbled_deepslate
setblock 62 52 559 minecraft:calcite
fill 62 52 560 62 54 560 minecraft:cobbled_deepslate
setblock 63 52 558 minecraft:calcite
fill 63 52 559 63 55 559 minecraft:cobbled_deepslate
setblock 63 52 598 minecraft:calcite
fill 64 52 558 64 55 558 minecraft:cobbled_deepslate
fill 64 52 598 64 54 598 minecraft:cobbled_deepslate
setblock 66 52 560 minecraft:calcite
setblock 67 52 559 minecraft:calcite
setblock 68 52 558 minecraft:calcite
fill 68 52 559 71 52 559 minecraft:cobbled_deepslate
setblock 68 52 598 minecraft:calcite
fill 69 52 558 69 54 558 minecraft:cobbled_deepslate
fill 69 52 561 69 54 561 minecraft:light_blue_stained_glass
fill 69 52 598 69 53 598 minecraft:cobbled_deepslate
setblock 72 52 559 minecraft:calcite
setblock 73 52 558 minecraft:calcite
fill 73 52 559 76 52 559 minecraft:cobbled_deepslate
setblock 73 52 598 minecraft:calcite
fill 74 52 558 74 55 558 minecraft:cobbled_deepslate
setblock 74 52 597 minecraft:calcite
fill 74 52 598 74 55 598 minecraft:cobbled_deepslate
setblock 75 52 560 minecraft:cobbled_deepslate
fill 75 52 590 75 54 590 minecraft:deepslate
fill 75 52 593 75 54 593 minecraft:deepslate
fill 75 52 597 75 54 597 minecraft:cobbled_deepslate
setblock 76 52 560 minecraft:calcite
fill 76 52 594 76 54 594 minecraft:deepslate
setblock 77 52 559 minecraft:calcite
fill 77 52 560 77 53 560 minecraft:cobbled_deepslate
fill 77 52 588 79 54 588 minecraft:deepslate
setblock 78 52 558 minecraft:calcite
fill 78 52 559 78 54 559 minecraft:cobbled_deepslate
setblock 78 52 598 minecraft:calcite
fill 79 52 558 79 55 558 minecraft:cobbled_deepslate
setblock 79 52 597 minecraft:calcite
fill 79 52 598 79 55 598 minecraft:cobbled_deepslate
fill 80 52 594 80 54 594 minecraft:deepslate
fill 80 52 597 80 53 597 minecraft:cobbled_deepslate
fill 81 52 590 81 54 590 minecraft:deepslate
fill 81 52 592 81 54 593 minecraft:deepslate
setblock 82 52 559 minecraft:calcite
setblock 83 52 558 minecraft:calcite
setblock 83 52 559 minecraft:cobbled_deepslate
setblock 83 52 598 minecraft:calcite
fill 84 52 558 84 53 558 minecraft:cobbled_deepslate
setblock 84 52 598 minecraft:cobbled_deepslate
fill 85 52 583 85 74 583 minecraft:calcite
setblock 86 52 580 minecraft:calcite
setblock 86 52 581 minecraft:cobbled_deepslate
fill 86 52 585 86 74 585 minecraft:calcite
setblock 87 52 579 minecraft:calcite
fill 87 52 580 87 53 580 minecraft:cobbled_deepslate
setblock 87 52 584 minecraft:calcite
fill 87 52 585 87 55 585 minecraft:cobbled_deepslate
setblock 88 52 578 minecraft:calcite
fill 88 52 579 88 55 579 minecraft:cobbled_deepslate
setblock 88 52 583 minecraft:calcite
fill 88 52 584 88 55 584 minecraft:cobbled_deepslate
setblock 88 52 588 minecraft:calcite
setblock 88 52 589 minecraft:cobbled_deepslate
setblock 48 53 561 minecraft:cobbled_deepslate
setblock 48 53 562 minecraft:calcite
fill 48 53 563 48 56 563 minecraft:cobbled_deepslate
setblock 48 53 567 minecraft:calcite
fill 48 53 568 48 56 568 minecraft:cobbled_deepslate
setblock 48 53 577 minecraft:calcite
setblock 48 53 578 minecraft:cobbled_deepslate
setblock 48 53 582 minecraft:calcite
fill 48 53 583 48 55 583 minecraft:cobbled_deepslate
setblock 49 53 561 minecraft:calcite
fill 49 53 562 49 56 562 minecraft:cobbled_deepslate
setblock 49 53 565 minecraft:cobbled_deepslate
setblock 51 53 559 minecraft:calcite
setblock 52 53 558 minecraft:calcite
fill 52 53 559 52 56 559 minecraft:cobbled_deepslate
fill 53 53 558 53 56 558 minecraft:cobbled_deepslate
setblock 55 53 560 minecraft:calcite
fill 55 53 561 55 55 561 minecraft:cobbled_deepslate
setblock 56 53 559 minecraft:calcite
fill 56 53 560 56 56 560 minecraft:cobbled_deepslate
setblock 57 53 558 minecraft:calcite
fill 57 53 559 57 56 559 minecraft:cobbled_deepslate
setblock 57 53 598 minecraft:calcite
fill 58 53 558 58 56 558 minecraft:cobbled_deepslate
fill 58 53 598 61 53 598 minecraft:cobbled_deepslate
setblock 59 53 561 minecraft:calcite
setblock 60 53 560 minecraft:calcite
fill 60 53 561 60 54 561 minecraft:cobbled_deepslate
setblock 61 53 559 minecraft:calcite
fill 61 53 560 61 55 560 minecraft:cobbled_deepslate
setblock 62 53 558 minecraft:calcite
fill 62 53 559 62 56 559 minecraft:cobbled_deepslate
setblock 62 53 598 minecraft:calcite
fill 63 53 558 63 56 558 minecraft:cobbled_deepslate
fill 63 53 598 63 54 598 minecraft:cobbled_deepslate
setblock 66 53 559 minecraft:calcite
setblock 67 53 558 minecraft:calcite
fill 67 53 559 68 53 559 minecraft:cobbled_deepslate
setblock 67 53 598 minecraft:calcite
fill 68 53 558 68 54 558 minecraft:cobbled_deepslate
setblock 68 53 561 minecraft:light_blue_stained_glass
setblock 68 53 598 minecraft:cobbled_deepslate
fill 69 53 559 70 53 559 minecraft:light_blue_stained_glass
fill 69 53 562 69 54 562 minecraft:light_blue_stained_glass
setblock 70 53 561 minecraft:light_blue_stained_glass
setblock 71 53 559 minecraft:calcite
setblock 72 53 558 minecraft:calcite
fill 72 53 559 75 53 559 minecraft:cobbled_deepslate
setblock 72 53 598 minecraft:calcite
fill 73 53 558 73 56 558 minecraft:cobbled_deepslate
fill 73 53 598 73 56 598 minecraft:cobbled_deepslate
fill 74 53 591 74 54 592 minecraft:deepslate
setblock 74 53 597 minecraft:cobbled_deepslate
fill 75 53 589 75 54 589 minecraft:deepslate
fill 75 53 594 75 54 594 minecraft:deepslate
setblock 76 53 559 minecraft:calcite
fill 76 53 588 76 54 588 minecraft:deepslate
setblock 77 53 558 minecraft:calcite
fill 77 53 559 77 55 559 minecraft:cobbled_deepslate
fill 77 53 595 79 54 595 minecraft:deepslate
setblock 77 53 598 minecraft:calcite
fill 78 53 558 78 56 558 minecraft:cobbled_deepslate
setblock 78 53 597 minecraft:calcite
fill 78 53 598 78 56 598 minecraft:cobbled_deepslate
fill 79 53 597 79 54 597 minecraft:cobbled_deepslate
fill 80 53 588 80 54 588 minecraft:deepslate
setblock 81 53 559 minecraft:calcite
fill 81 53 589 81 54 589 minecraft:deepslate
setblock 82 53 558 minecraft:calcite
fill 82 53 591 82 54 591 minecraft:deepslate
setblock 82 53 598 minecraft:calcite
setblock 83 53 558 minecraft:cobbled_deepslate
setblock 83 53 598 minecraft:cobbled_deepslate
fill 86 53 584 86 74 584 minecraft:calcite
setblock 87 53 579 minecraft:cobbled_deepslate
setblock 87 53 583 minecraft:calcite
fill 87 53 584 87 55 584 minecraft:cobbled_deepslate
setblock 88 53 577 minecraft:calcite
fill 88 53 578 88 54 578 minecraft:cobbled_deepslate
setblock 88 53 582 minecraft:calcite
fill 88 53 583 88 56 583 minecraft:cobbled_deepslate
setblock 88 53 587 minecraft:calcite
fill 88 53 588 88 56 588 minecraft:cobbled_deepslate
setblock 48 54 561 minecraft:calcite
fill 48 54 562 48 57 562 minecraft:cobbled_deepslate
setblock 48 54 566 minecraft:calcite
fill 48 54 567 48 57 567 minecraft:cobbled_deepslate
setblock 48 54 581 minecraft:calcite
fill 48 54 582 48 55 582 minecraft:cobbled_deepslate
setblock 49 54 565 minecraft:calcite
setblock 51 54 558 minecraft:calcite
setblock 51 54 559 minecraft:cobbled_deepslate
fill 52 54 558 52 57 558 minecraft:cobbled_deepslate
setblock 54 54 560 minecraft:calcite
setblock 55 54 559 minecraft:calcite
fill 55 54 560 55 57 560 minecraft:cobbled_deepslate
setblock 56 54 558 minecraft:calcite
fill 56 54 559 56 57 559 minecraft:cobbled_deepslate
setblock 56 54 598 minecraft:calcite
fill 57 54 558 57 57 558 minecraft:cobbled_deepslate
fill 57 54 598 60 54 598 minecraft:cobbled_deepslate
setblock 58 54 561 minecraft:calcite
setblock 59 54 560 minecraft:calcite
fill 59 54 561 59 55 561 minecraft:cobbled_deepslate
setblock 60 54 559 minecraft:calcite
fill 60 54 560 60 56 560 minecraft:cobbled_deepslate
setblock 61 54 558 minecraft:calcite
fill 61 54 559 61 57 559 minecraft:cobbled_deepslate
setblock 61 54 598 minecraft:calcite
fill 62 54 558 62 57 558 minecraft:cobbled_deepslate
fill 62 54 598 62 55 598 minecraft:cobbled_deepslate
setblock 65 54 559 minecraft:calcite
setblock 66 54 558 minecraft:calcite
fill 67 54 558 67 55 558 minecraft:cobbled_deepslate
setblock 69 54 560 minecraft:light_blue_stained_glass
setblock 71 54 558 minecraft:calcite
setblock 71 54 598 minecraft:calcite
fill 72 54 558 72 56 558 minecraft:cobbled_deepslate
fill 72 54 598 72 57 598 minecraft:cobbled_deepslate
fill 73 54 559 74 54 559 minecraft:cobbled_deepslate
fill 74 54 589 74 54 590 minecraft:deepslate
setblock 74 54 593 minecraft:deepslate
setblock 75 54 559 minecraft:calcite
setblock 75 54 588 minecraft:deepslate
setblock 76 54 558 minecraft:calcite
fill 76 54 559 76 55 559 minecraft:cobbled_deepslate
setblock 76 54 595 minecraft:deepslate
setblock 76 54 598 minecraft:calcite
fill 77 54 558 77 57 558 minecraft:cobbled_deepslate
fill 77 54 587 79 54 587 minecraft:deepslate
setblock 77 54 597 minecraft:calcite
fill 77 54 598 77 57 598 minecraft:cobbled_deepslate
setblock 78 54 597 minecraft:cobbled_deepslate
setblock 80 54 559 minecraft:calcite
setblock 80 54 595 minecraft:deepslate
setblock 81 54 558 minecraft:calcite
setblock 81 54 588 minecraft:deepslate
setblock 81 54 594 minecraft:deepslate
setblock 81 54 598 minecraft:calcite
setblock 82 54 558 minecraft:cobbled_deepslate
setblock 82 54 590 minecraft:deepslate
fill 82 54 592 82 54 593 minecraft:deepslate
setblock 82 54 598 minecraft:cobbled_deepslate
fill 86 54 583 86 74 583 minecraft:calcite
setblock 87 54 582 minecraft:calcite
fill 87 54 583 87 55 583 minecraft:cobbled_deepslate
setblock 88 54 581 minecraft:calcite
fill 88 54 582 88 57 582 minecraft:cobbled_deepslate
setblock 88 54 586 minecraft:calcite
fill 88 54 587 88 57 587 minecraft:cobbled_deepslate
setblock 48 55 560 minecraft:calcite
fill 48 55 561 48 58 561 minecraft:cobbled_deepslate
setblock 48 55 564 minecraft:cobbled_deepslate
setblock 48 55 565 minecraft:calcite
fill 48 55 566 49 57 566 minecraft:cobbled_deepslate
setblock 48 55 569 minecraft:cobbled_deepslate
setblock 49 55 564 minecraft:calcite
fill 49 55 565 49 58 565 minecraft:cobbled_deepslate
fill 51 55 558 51 58 558 minecraft:cobbled_deepslate
setblock 53 55 560 minecraft:calcite
setblock 54 55 559 minecraft:calcite
fill 54 55 560 54 58 560 minecraft:cobbled_deepslate
setblock 55 55 558 minecraft:calcite
fill 55 55 559 55 58 559 minecraft:cobbled_deepslate
setblock 55 55 598 minecraft:calcite
fill 56 55 558 56 58 558 minecraft:cobbled_deepslate
fill 56 55 598 59 55 598 minecraft:cobbled_deepslate
setblock 57 55 561 minecraft:calcite
setblock 58 55 560 minecraft:calcite
setblock 58 55 561 minecraft:cobbled_deepslate
setblock 59 55 559 minecraft:calcite
fill 59 55 560 59 57 560 minecraft:cobbled_deepslate
setblock 60 55 558 minecraft:calcite
fill 60 55 559 60 58 559 minecraft:cobbled_deepslate
setblock 60 55 598 minecraft:calcite
fill 61 55 558 61 58 558 minecraft:cobbled_deepslate
setblock 61 55 598 minecraft:cobbled_deepslate
setblock 65 55 558 minecraft:calcite
setblock 66 55 558 minecraft:cobbled_deepslate
setblock 70 55 558 minecraft:calcite
setblock 71 55 558 minecraft:cobbled_deepslate
setblock 71 55 598 minecraft:cobbled_deepslate
setblock 75 55 558 minecraft:calcite
setblock 75 55 559 minecraft:cobbled_deepslate
setblock 75 55 598 minecraft:calcite
fill 76 55 558 76 57 558 minecraft:cobbled_deepslate
setblock 76 55 597 minecraft:calcite
fill 76 55 598 76 58 598 minecraft:cobbled_deepslate
fill 77 55 591 78 55 592 minecraft:light_blue_stained_glass
setblock 77 55 597 minecraft:cobbled_deepslate
setblock 78 55 590 minecraft:light_blue_stained_glass
setblock 79 55 591 minecraft:light_blue_stained_glass
setblock 80 55 558 minecraft:calcite
setblock 80 55 598 minecraft:calcite
setblock 87 55 582 minecraft:cobbled_deepslate
setblock 88 55 580 minecraft:calcite
fill 88 55 581 88 58 581 minecraft:cobbled_deepslate
setblock 88 55 585 minecraft:calcite
fill 88 55 586 88 58 586 minecraft:cobbled_deepslate
setblock 48 56 564 minecraft:calcite
fill 48 56 565 48 59 565 minecraft:cobbled_deepslate
setblock 48 56 569 minecraft:calcite
setblock 49 56 563 minecraft:calcite
fill 49 56 564 49 59 564 minecraft:cobbled_deepslate
setblock 49 56 567 minecraft:cobbled_deepslate
setblock 50 56 560 minecraft:light[level=14]
setblock 50 56 568 minecraft:light[level=14]
setblock 50 56 576 minecraft:light[level=14]
setblock 50 56 584 minecraft:light[level=14]
setblock 50 56 592 minecraft:light[level=14]
setblock 53 56 559 minecraft:calcite
setblock 53 56 560 minecraft:cobbled_deepslate
setblock 54 56 558 minecraft:calcite
fill 54 56 559 54 59 559 minecraft:cobbled_deepslate
fill 55 56 558 55 59 558 minecraft:cobbled_deepslate
setblock 56 56 561 minecraft:calcite
fill 56 56 598 58 56 598 minecraft:cobbled_deepslate
setblock 57 56 560 minecraft:calcite
setblock 57 56 561 minecraft:cobbled_deepslate
setblock 58 56 559 minecraft:calcite
fill 58 56 560 58 58 560 minecraft:cobbled_deepslate
setblock 58 56 568 minecraft:light[level=14]
setblock 58 56 576 minecraft:light[level=14]
setblock 58 56 584 minecraft:light[level=14]
setblock 58 56 592 minecraft:light[level=14]
setblock 59 56 558 minecraft:calcite
fill 59 56 559 59 59 559 minecraft:cobbled_deepslate
setblock 59 56 598 minecraft:calcite
fill 60 56 558 60 59 558 minecraft:cobbled_deepslate
setblock 60 56 598 minecraft:cobbled_deepslate
setblock 64 56 558 minecraft:calcite
setblock 66 56 560 minecraft:light[level=14]
setblock 66 56 568 minecraft:light[level=14]
setblock 66 56 576 minecraft:light[level=14]
setblock 66 56 584 minecraft:light[level=14]
setblock 66 56 592 minecraft:light[level=14]
setblock 74 56 558 minecraft:calcite
setblock 74 56 560 minecraft:light[level=14]
setblock 74 56 568 minecraft:light[level=14]
setblock 74 56 576 minecraft:light[level=14]
setblock 74 56 584 minecraft:light[level=14]
setblock 74 56 592 minecraft:light[level=14]
setblock 74 56 598 minecraft:calcite
fill 75 56 558 75 58 558 minecraft:cobbled_deepslate
fill 75 56 598 75 59 598 minecraft:cobbled_deepslate
fill 77 56 591 78 56 591 minecraft:light_blue_stained_glass
setblock 78 56 592 minecraft:light_blue_stained_glass
setblock 79 56 598 minecraft:calcite
setblock 82 56 560 minecraft:light[level=14]
setblock 82 56 568 minecraft:light[level=14]
setblock 82 56 576 minecraft:light[level=14]
setblock 82 56 584 minecraft:light[level=14]
setblock 82 56 592 minecraft:light[level=14]
fill 87 56 584 87 74 585 minecraft:calcite
setblock 88 56 580 minecraft:cobbled_deepslate
setblock 88 56 584 minecraft:calcite
fill 88 56 585 88 59 585 minecraft:cobbled_deepslate
setblock 48 57 563 minecraft:calcite
fill 48 57 564 48 60 564 minecraft:cobbled_deepslate
setblock 48 57 568 minecraft:calcite
fill 48 57 569 48 59 570 minecraft:cobbled_deepslate
setblock 49 57 562 minecraft:calcite
fill 49 57 563 49 60 563 minecraft:cobbled_deepslate
setblock 49 57 567 minecraft:calcite
fill 49 57 568 49 60 568 minecraft:cobbled_deepslate
setblock 52 57 559 minecraft:calcite
setblock 53 57 558 minecraft:calcite
fill 53 57 559 53 60 559 minecraft:cobbled_deepslate
fill 54 57 558 54 60 558 minecraft:cobbled_deepslate
fill 55 57 598 57 57 598 minecraft:cobbled_deepslate
setblock 56 57 560 minecraft:calcite
setblock 57 57 559 minecraft:calcite
fill 57 57 560 57 59 560 minecraft:cobbled_deepslate
setblock 58 57 558 minecraft:calcite
fill 58 57 559 58 60 559 minecraft:cobbled_deepslate
setblock 58 57 598 minecraft:calcite
fill 59 57 558 59 60 558 minecraft:cobbled_deepslate
fill 59 57 598 59 60 598 minecraft:cobbled_deepslate
setblock 63 57 558 minecraft:calcite
setblock 73 57 558 minecraft:calcite
setblock 73 57 598 minecraft:calcite
fill 74 57 558 74 60 558 minecraft:cobbled_deepslate
fill 74 57 598 74 60 598 minecraft:cobbled_deepslate
fill 78 57 591 78 59 591 minecraft:light_blue_stained_glass
setblock 78 57 598 minecraft:calcite
fill 88 57 565 88 57 567 minecraft:cobbled_deepslate
setblock 88 57 568 minecraft:calcite
setblock 88 57 583 minecraft:calcite
fill 88 57 584 88 60 584 minecraft:cobbled_deepslate
setblock 88 57 588 minecraft:calcite
setblock 48 58 562 minecraft:calcite
fill 48 58 563 48 61 563 minecraft:cobbled_deepslate
setblock 48 58 566 minecraft:cobbled_deepslate
setblock 48 58 567 minecraft:calcite
fill 48 58 568 48 61 568 minecraft:cobbled_deepslate
setblock 48 58 571 minecraft:cobbled_deepslate
fill 49 58 562 49 61 562 minecraft:cobbled_deepslate
setblock 49 58 566 minecraft:calcite
fill 49 58 567 50 60 567 minecraft:cobbled_deepslate
fill 49 58 569 49 59 569 minecraft:cobbled_deepslate
setblock 50 58 564 minecraft:cobbled_deepslate
setblock 50 58 565 minecraft:calcite
fill 50 58 566 50 61 566 minecraft:cobbled_deepslate
setblock 52 58 558 minecraft:calcite
fill 52 58 559 52 61 559 minecraft:cobbled_deepslate
fill 53 58 558 53 61 558 minecraft:cobbled_deepslate
fill 53 58 560 53 59 560 minecraft:cobbled_deepslate
setblock 55 58 560 minecraft:calcite
fill 55 58 598 56 58 598 minecraft:cobbled_deepslate
setblock 56 58 559 minecraft:calcite
fill 56 58 560 56 61 560 minecraft:cobbled_deepslate
setblock 57 58 558 minecraft:calcite
fill 57 58 559 57 61 559 minecraft:cobbled_deepslate
setblock 57 58 598 minecraft:calcite
fill 58 58 558 58 61 558 minecraft:cobbled_deepslate
fill 58 58 598 58 61 598 minecraft:cobbled_deepslate
setblock 62 58 558 minecraft:calcite
setblock 71 58 598 minecraft:cobbled_deepslate
setblock 72 58 598 minecraft:calcite
fill 73 58 598 73 61 598 minecraft:cobbled_deepslate
setblock 77 58 598 minecraft:calcite
fill 88 58 564 88 58 566 minecraft:cobbled_deepslate
setblock 88 58 567 minecraft:calcite
fill 88 58 568 88 59 570 minecraft:cobbled_deepslate
setblock 88 58 582 minecraft:calcite
fill 88 58 583 88 61 583 minecraft:cobbled_deepslate
setblock 88 58 587 minecraft:calcite
fill 88 58 588 88 60 589 minecraft:cobbled_deepslate
setblock 48 59 560 minecraft:cobbled_deepslate
setblock 48 59 561 minecraft:calcite
fill 48 59 562 48 62 562 minecraft:cobbled_deepslate
setblock 48 59 566 minecraft:calcite
fill 48 59 567 48 62 567 minecraft:cobbled_deepslate
setblock 48 59 571 minecraft:calcite
fill 48 59 572 48 61 573 minecraft:cobbled_deepslate
setblock 49 59 565 minecraft:calcite
fill 49 59 566 49 62 566 minecraft:cobbled_deepslate
setblock 49 59 570 minecraft:calcite
fill 49 59 571 49 62 571 minecraft:cobbled_deepslate
setblock 50 59 558 minecraft:cobbled_deepslate
setblock 50 59 563 minecraft:cobbled_deepslate
setblock 50 59 564 minecraft:calcite
fill 50 59 565 50 62 565 minecraft:cobbled_deepslate
setblock 50 59 568 minecraft:cobbled_deepslate
setblock 50 59 569 minecraft:calcite
setblock 51 59 558 minecraft:calcite
fill 51 59 559 51 62 559 minecraft:cobbled_deepslate
fill 52 59 558 52 62 558 minecraft:cobbled_deepslate
setblock 54 59 560 minecraft:calcite
fill 54 59 598 55 59 598 minecraft:cobbled_deepslate
setblock 55 59 559 minecraft:calcite
fill 55 59 560 55 62 560 minecraft:cobbled_deepslate
setblock 56 59 558 minecraft:calcite
fill 56 59 559 56 62 559 minecraft:cobbled_deepslate
setblock 56 59 598 minecraft:calcite
fill 57 59 558 57 62 558 minecraft:cobbled_deepslate
fill 57 59 598 57 62 598 minecraft:cobbled_deepslate
setblock 61 59 558 minecraft:calcite
setblock 70 59 598 minecraft:cobbled_deepslate
setblock 71 59 598 minecraft:calcite
fill 72 59 598 72 62 598 minecraft:cobbled_deepslate
setblock 76 59 598 minecraft:calcite
fill 77 59 598 77 62 598 minecraft:cobbled_deepslate
fill 88 59 563 88 59 565 minecraft:cobbled_deepslate
setblock 88 59 566 minecraft:calcite
fill 88 59 567 88 62 567 minecraft:cobbled_deepslate
setblock 88 59 571 minecraft:calcite
fill 88 59 572 88 61 573 minecraft:cobbled_deepslate
setblock 88 59 581 minecraft:calcite
fill 88 59 582 88 62 582 minecraft:cobbled_deepslate
setblock 88 59 586 minecraft:calcite
fill 88 59 587 88 62 587 minecraft:cobbled_deepslate
setblock 88 59 590 minecraft:cobbled_deepslate
setblock 48 60 560 minecraft:calcite
fill 48 60 561 49 62 561 minecraft:cobbled_deepslate
setblock 48 60 565 minecraft:calcite
fill 48 60 566 48 63 566 minecraft:cobbled_deepslate
setblock 48 60 569 minecraft:cobbled_deepslate
setblock 48 60 570 minecraft:calcite
fill 48 60 571 48 63 571 minecraft:cobbled_deepslate
setblock 48 60 574 minecraft:cobbled_deepslate
fill 48 60 586 48 60 589 minecraft:cobbled_deepslate
setblock 49 60 558 minecraft:cobbled_deepslate
setblock 49 60 564 minecraft:calcite
fill 49 60 565 49 63 565 minecraft:cobbled_deepslate
setblock 49 60 569 minecraft:calcite
fill 49 60 570 50 62 570 minecraft:cobbled_deepslate
fill 49 60 572 49 61 572 minecraft:cobbled_deepslate
setblock 50 60 558 minecraft:calcite
setblock 50 60 562 minecraft:cobbled_deepslate
setblock 50 60 563 minecraft:calcite
fill 50 60 564 50 63 564 minecraft:cobbled_deepslate
setblock 50 60 568 minecraft:calcite
fill 50 60 569 50 63 569 minecraft:cobbled_deepslate
fill 51 60 558 51 63 558 minecraft:cobbled_deepslate
fill 51 60 565 51 60 566 minecraft:cobbled_deepslate
setblock 51 60 567 minecraft:calcite
fill 51 60 568 51 63 568 minecraft:cobbled_deepslate
fill 52 60 598 54 60 598 minecraft:cobbled_deepslate
setblock 53 60 560 minecraft:calcite
setblock 54 60 559 minecraft:calcite
fill 54 60 560 54 63 560 minecraft:cobbled_deepslate
setblock 55 60 558 minecraft:calcite
fill 55 60 559 55 63 559 minecraft:cobbled_deepslate
setblock 55 60 598 minecraft:calcite
fill 56 60 558 56 63 558 minecraft:cobbled_deepslate
fill 56 60 598 56 63 598 minecraft:cobbled_deepslate
setblock 60 60 558 minecraft:calcite
setblock 60 60 598 minecraft:calcite
setblock 69 60 598 minecraft:cobbled_deepslate
setblock 70 60 598 minecraft:calcite
fill 71 60 598 71 63 598 minecraft:cobbled_deepslate
fill 72 60 597 75 60 597 minecraft:cobbled_deepslate
fill 73 60 558 73 61 558 minecraft:cobbled_deepslate
setblock 75 60 598 minecraft:calcite
fill 76 60 598 76 63 598 minecraft:cobbled_deepslate
fill 87 60 567 87 61 569 minecraft:cobbled_deepslate
fill 88 60 563 88 60 564 minecraft:cobbled_deepslate
setblock 88 60 565 minecraft:calcite
fill 88 60 566 88 63 566 minecraft:cobbled_deepslate
fill 88 60 568 88 60 569 minecraft:cobbled_deepslate
setblock 88 60 570 minecraft:calcite
fill 88 60 571 88 63 571 minecraft:cobbled_deepslate
setblock 88 60 574 minecraft:cobbled_deepslate
setblock 88 60 575 minecraft:calcite
fill 88 60 581 88 63 581 minecraft:cobbled_deepslate
setblock 88 60 585 minecraft:calcite
fill 88 60 586 88 63 586 minecraft:cobbled_deepslate
setblock 88 60 590 minecraft:calcite
fill 88 60 591 88 63 591 minecraft:cobbled_deepslate
setblock 48 61 559 minecraft:calcite
fill 48 61 560 49 63 560 minecraft:cobbled_deepslate
setblock 48 61 564 minecraft:calcite
fill 48 61 565 48 64 565 minecraft:cobbled_deepslate
setblock 48 61 569 minecraft:calcite
fill 48 61 570 48 64 570 minecraft:cobbled_deepslate
setblock 48 61 574 minecraft:calcite
fill 48 61 575 48 64 575 minecraft:cobbled_deepslate
fill 48 61 585 48 61 588 minecraft:cobbled_deepslate
setblock 48 61 589 minecraft:calcite
fill 48 61 590 48 62 592 minecraft:cobbled_deepslate
setblock 49 61 558 minecraft:calcite
setblock 49 61 563 minecraft:calcite
fill 49 61 564 49 64 564 minecraft:cobbled_deepslate
setblock 49 61 567 minecraft:cobbled_deepslate
setblock 49 61 568 minecraft:calcite
fill 49 61 569 49 64 569 minecraft:cobbled_deepslate
setblock 49 61 573 minecraft:calcite
fill 50 61 558 50 63 559 minecraft:cobbled_deepslate
setblock 50 61 562 minecraft:calcite
fill 50 61 563 50 64 563 minecraft:cobbled_deepslate
setblock 50 61 567 minecraft:calcite
fill 50 61 568 50 64 568 minecraft:cobbled_deepslate
setblock 50 61 571 minecraft:cobbled_deepslate
fill 51 61 564 51 61 565 minecraft:cobbled_deepslate
setblock 51 61 566 minecraft:calcite
fill 51 61 567 51 64 567 minecraft:cobbled_deepslate
fill 51 61 569 51 62 569 minecraft:cobbled_deepslate
fill 51 61 598 53 61 598 minecraft:cobbled_deepslate
setblock 52 61 560 minecraft:calcite
setblock 53 61 559 minecraft:calcite
fill 53 61 560 53 64 560 minecraft:cobbled_deepslate
setblock 54 61 558 minecraft:calcite
fill 54 61 559 54 64 559 minecraft:cobbled_deepslate
setblock 54 61 597 minecraft:cobbled_deepslate
setblock 54 61 598 minecraft:calcite
fill 55 61 558 55 64 558 minecraft:cobbled_deepslate
setblock 55 61 597 minecraft:calcite
fill 55 61 598 55 64 598 minecraft:cobbled_deepslate
fill 56 61 597 56 64 597 minecraft:cobbled_deepslate
setblock 58 61 559 minecraft:calcite
setblock 59 61 558 minecraft:calcite
setblock 59 61 598 minecraft:calcite
fill 60 61 558 60 64 558 minecraft:cobbled_deepslate
fill 60 61 598 61 63 598 minecraft:cobbled_deepslate
fill 67 61 598 68 61 598 minecraft:cobbled_deepslate
setblock 69 61 598 minecraft:calcite
setblock 70 61 597 minecraft:calcite
fill 70 61 598 70 64 598 minecraft:cobbled_deepslate
fill 71 61 558 72 62 558 minecraft:cobbled_deepslate
fill 71 61 597 74 61 597 minecraft:cobbled_deepslate
setblock 74 61 558 minecraft:calcite
setblock 74 61 598 minecraft:calcite
setblock 75 61 597 minecraft:calcite
fill 75 61 598 75 64 598 minecraft:cobbled_deepslate
fill 76 61 597 76 64 597 minecraft:cobbled_deepslate
setblock 87 61 565 minecraft:calcite
fill 87 61 566 87 64 566 minecraft:cobbled_deepslate
setblock 87 61 570 minecraft:calcite
fill 87 61 571 87 63 572 minecraft:cobbled_deepslate
fill 87 61 587 87 62 588 minecraft:cobbled_deepslate
fill 88 61 562 88 61 563 minecraft:cobbled_deepslate
setblock 88 61 564 minecraft:calcite
fill 88 61 565 88 64 565 minecraft:cobbled_deepslate
setblock 88 61 568 minecraft:cobbled_deepslate
setblock 88 61 569 minecraft:calcite
fill 88 61 570 88 64 570 minecraft:cobbled_deepslate
setblock 88 61 574 minecraft:calcite
fill 88 61 575 88 61 578 minecraft:cobbled_deepslate
setblock 88 61 579 minecraft:calcite
fill 88 61 580 88 64 580 minecraft:cobbled_deepslate
setblock 88 61 584 minecraft:calcite
fill 88 61 585 88 64 585 minecraft:cobbled_deepslate
setblock 88 61 588 minecraft:cobbled_deepslate
setblock 88 61 589 minecraft:calcite
fill 88 61 590 88 64 590 minecraft:cobbled_deepslate
fill 88 61 592 88 62 592 minecraft:cobbled_deepslate
setblock 48 62 558 minecraft:calcite
fill 48 62 559 49 64 559 minecraft:cobbled_deepslate
setblock 48 62 563 minecraft:calcite
fill 48 62 564 48 65 564 minecraft:cobbled_deepslate
setblock 48 62 568 minecraft:calcite
fill 48 62 569 48 65 569 minecraft:cobbled_deepslate
setblock 48 62 572 minecraft:cobbled_deepslate
setblock 48 62 573 minecraft:calcite
fill 48 62 574 49 64 574 minecraft:cobbled_deepslate
fill 48 62 576 48 62 577 minecraft:cobbled_deepslate
fill 48 62 585 48 62 587 minecraft:cobbled_deepslate
setblock 48 62 588 minecraft:calcite
fill 48 62 589 49 64 589 minecraft:cobbled_deepslate
setblock 48 62 593 minecraft:calcite
fill 48 62 594 48 64 595 minecraft:cobbled_deepslate
fill 49 62 558 49 65 558 minecraft:cobbled_deepslate
setblock 49 62 562 minecraft:calcite
fill 49 62 563 49 65 563 minecraft:cobbled_deepslate
setblock 49 62 567 minecraft:calcite
fill 49 62 568 49 65 568 minecraft:cobbled_deepslate
setblock 49 62 572 minecraft:calcite
fill 49 62 573 50 64 573 minecraft:cobbled_deepslate
fill 49 62 588 49 65 588 minecraft:cobbled_deepslate
fill 49 62 590 49 62 591 minecraft:cobbled_deepslate
setblock 49 62 592 minecraft:calcite
setblock 50 62 561 minecraft:calcite
fill 50 62 562 50 65 562 minecraft:cobbled_deepslate
setblock 50 62 566 minecraft:calcite
fill 50 62 567 50 65 567 minecraft:cobbled_deepslate
setblock 50 62 571 minecraft:calcite
fill 50 62 572 50 65 572 minecraft:cobbled_deepslate
fill 50 62 598 52 62 598 minecraft:cobbled_deepslate
setblock 51 62 560 minecraft:calcite
setblock 51 62 564 minecraft:cobbled_deepslate
setblock 51 62 565 minecraft:calcite
fill 51 62 566 51 65 566 minecraft:cobbled_deepslate
setblock 51 62 570 minecraft:calcite
setblock 52 62 559 minecraft:calcite
fill 52 62 560 52 65 560 minecraft:cobbled_deepslate
fill 52 62 597 53 62 597 minecraft:cobbled_deepslate
setblock 53 62 558 minecraft:calcite
fill 53 62 559 53 65 559 minecraft:cobbled_deepslate
setblock 53 62 598 minecraft:calcite
fill 54 62 558 54 65 558 minecraft:cobbled_deepslate
setblock 54 62 597 minecraft:calcite
fill 54 62 598 54 65 598 minecraft:cobbled_deepslate
fill 55 62 597 55 65 597 minecraft:cobbled_deepslate
setblock 57 62 559 minecraft:calcite
fill 57 62 597 58 62 597 minecraft:cobbled_deepslate
setblock 58 62 558 minecraft:calcite
setblock 58 62 559 minecraft:cobbled_deepslate
setblock 58 62 598 minecraft:calcite
fill 59 62 558 59 65 558 minecraft:cobbled_deepslate
fill 59 62 598 59 65 598 minecraft:cobbled_deepslate
setblock 62 62 598 minecraft:cobbled_deepslate
setblock 63 62 598 minecraft:calcite
fill 64 62 598 67 62 598 minecraft:cobbled_deepslate
setblock 68 62 597 minecraft:cobbled_deepslate
setblock 68 62 598 minecraft:calcite
setblock 69 62 597 minecraft:calcite
fill 69 62 598 69 65 598 minecraft:cobbled_deepslate
fill 70 62 558 70 64 558 minecraft:cobbled_deepslate
setblock 70 62 596 minecraft:calcite
fill 70 62 597 73 62 597 minecraft:cobbled_deepslate
fill 71 62 596 74 62 596 minecraft:cobbled_deepslate
setblock 73 62 558 minecraft:calcite
setblock 73 62 598 minecraft:calcite
fill 74 62 558 74 64 558 minecraft:cobbled_deepslate
setblock 74 62 597 minecraft:calcite
fill 74 62 598 74 65 598 minecraft:cobbled_deepslate
setblock 75 62 596 minecraft:calcite
fill 75 62 597 75 65 597 minecraft:cobbled_deepslate
fill 87 62 565 87 65 565 minecraft:cobbled_deepslate
fill 87 62 567 87 62 568 minecraft:cobbled_deepslate
setblock 87 62 569 minecraft:calcite
fill 87 62 570 87 65 570 minecraft:cobbled_deepslate
setblock 87 62 573 minecraft:cobbled_deepslate
setblock 87 62 574 minecraft:calcite
fill 87 62 586 87 64 586 minecraft:cobbled_deepslate
setblock 87 62 589 minecraft:calcite
fill 87 62 590 87 65 590 minecraft:cobbled_deepslate
fill 88 62 561 88 62 562 minecraft:cobbled_deepslate
setblock 88 62 563 minecraft:calcite
fill 88 62 564 88 65 564 minecraft:cobbled_deepslate
setblock 88 62 568 minecraft:calcite
fill 88 62 569 88 65 569 minecraft:cobbled_deepslate
setblock 88 62 572 minecraft:cobbled_deepslate
setblock 88 62 573 minecraft:calcite
fill 88 62 574 88 62 577 minecraft:cobbled_deepslate
setblock 88 62 578 minecraft:calcite
fill 88 62 579 88 65 579 minecraft:cobbled_deepslate
setblock 88 62 583 minecraft:calcite
fill 88 62 584 88 65 584 minecraft:cobbled_deepslate
setblock 88 62 588 minecraft:calcite
fill 88 62 589 88 65 589 minecraft:cobbled_deepslate
setblock 88 62 593 minecraft:calcite
fill 88 62 594 88 65 594 minecraft:cobbled_deepslate
fill 48 63 558 48 66 558 minecraft:cobbled_deepslate
setblock 48 63 561 minecraft:cobbled_deepslate
setblock 48 63 562 minecraft:calcite
fill 48 63 563 48 66 563 minecraft:cobbled_deepslate
setblock 48 63 567 minecraft:calcite
fill 48 63 568 48 66 568 minecraft:cobbled_deepslate
setblock 48 63 572 minecraft:calcite
fill 48 63 573 48 66 573 minecraft:cobbled_deepslate
setblock 48 63 576 minecraft:cobbled_deepslate
setblock 48 63 577 minecraft:calcite
fill 48 63 578 48 66 578 minecraft:cobbled_deepslate
fill 48 63 584 48 63 586 minecraft:cobbled_deepslate
setblock 48 63 587 minecraft:calcite
fill 48 63 588 48 66 588 minecraft:cobbled_deepslate
fill 48 63 590 48 63 591 minecraft:cobbled_deepslate
setblock 48 63 592 minecraft:calcite
fill 48 63 593 49 65 593 minecraft:cobbled_deepslate
setblock 48 63 596 minecraft:cobbled_deepslate
setblock 48 63 597 minecraft:calcite
fill 48 63 598 51 63 598 minecraft:cobbled_deepslate
setblock 49 63 561 minecraft:calcite
fill 49 63 562 49 66 562 minecraft:cobbled_deepslate
setblock 49 63 566 minecraft:calcite
fill 49 63 567 49 66 567 minecraft:cobbled_deepslate
setblock 49 63 570 minecraft:cobbled_deepslate
setblock 49 63 571 minecraft:calcite
fill 49 63 572 49 66 572 minecraft:cobbled_deepslate
setblock 49 63 575 minecraft:cobbled_deepslate
fill 49 63 587 49 64 587 minecraft:cobbled_deepslate
setblock 49 63 590 minecraft:cobbled_deepslate
setblock 49 63 591 minecraft:calcite
fill 49 63 592 49 66 592 minecraft:cobbled_deepslate
fill 49 63 594 49 63 595 minecraft:cobbled_deepslate
fill 50 63 561 50 66 561 minecraft:cobbled_deepslate
setblock 50 63 565 minecraft:calcite
fill 50 63 566 50 66 566 minecraft:cobbled_deepslate
setblock 50 63 570 minecraft:calcite
fill 50 63 571 51 65 571 minecraft:cobbled_deepslate
setblock 50 63 574 minecraft:cobbled_deepslate
fill 50 63 597 52 63 597 minecraft:cobbled_deepslate
setblock 51 63 559 minecraft:calcite
fill 51 63 560 51 66 560 minecraft:cobbled_deepslate
setblock 51 63 563 minecraft:cobbled_deepslate
setblock 51 63 564 minecraft:calcite
fill 51 63 565 51 65 565 minecraft:cobbled_deepslate
setblock 51 63 569 minecraft:calcite
fill 51 63 570 51 66 570 minecraft:cobbled_deepslate
setblock 52 63 558 minecraft:calcite
fill 52 63 559 52 66 559 minecraft:cobbled_deepslate
setblock 52 63 598 minecraft:calcite
fill 53 63 558 53 66 558 minecraft:cobbled_deepslate
setblock 53 63 596 minecraft:cobbled_deepslate
setblock 53 63 597 minecraft:calcite
fill 53 63 598 53 66 598 minecraft:cobbled_deepslate
setblock 54 63 596 minecraft:calcite
fill 54 63 597 54 66 597 minecraft:cobbled_deepslate
setblock 55 63 560 minecraft:calcite
fill 55 63 596 55 66 596 minecraft:cobbled_deepslate
setblock 56 63 559 minecraft:calcite
setblock 57 63 558 minecraft:calcite
fill 57 63 559 57 64 559 minecraft:cobbled_deepslate
setblock 57 63 597 minecraft:cobbled_deepslate
setblock 57 63 598 minecraft:calcite
fill 58 63 558 58 66 558 minecraft:cobbled_deepslate
setblock 58 63 597 minecraft:calcite
fill 58 63 598 58 66 598 minecraft:cobbled_deepslate
fill 59 63 597 59 66 597 minecraft:cobbled_deepslate
setblock 62 63 598 minecraft:calcite
fill 63 63 598 66 63 598 minecraft:cobbled_deepslate
fill 66 63 597 67 63 597 minecraft:cobbled_deepslate
setblock 67 63 598 minecraft:calcite
setblock 68 63 596 minecraft:cobbled_deepslate
setblock 68 63 597 minecraft:calcite
fill 68 63 598 68 66 598 minecraft:cobbled_deepslate
fill 69 63 558 69 65 558 minecraft:cobbled_deepslate
setblock 69 63 596 minecraft:calcite
fill 69 63 597 72 63 597 minecraft:cobbled_deepslate
fill 70 63 596 73 63 596 minecraft:cobbled_deepslate
setblock 71 63 558 minecraft:cobbled_deepslate
fill 71 63 595 73 64 595 minecraft:cobbled_deepslate
setblock 72 63 558 minecraft:calcite
setblock 72 63 598 minecraft:calcite
fill 73 63 558 73 66 558 minecraft:cobbled_deepslate
setblock 73 63 597 minecraft:calcite
fill 73 63 598 73 66 598 minecraft:cobbled_deepslate
setblock 74 63 596 minecraft:calcite
fill 74 63 597 74 66 597 minecraft:cobbled_deepslate
fill 75 63 596 75 66 596 minecraft:cobbled_deepslate
setblock 77 63 598 minecraft:calcite
fill 78 63 598 78 64 598 minecraft:cobbled_deepslate
setblock 86 63 568 minecraft:cobbled_deepslate
setblock 86 63 569 minecraft:calcite
fill 86 63 570 86 64 572 minecraft:cobbled_deepslate
fill 87 63 564 87 66 564 minecraft:cobbled_deepslate
setblock 87 63 567 minecraft:cobbled_deepslate
setblock 87 63 568 minecraft:calcite
fill 87 63 569 87 66 569 minecraft:cobbled_deepslate
setblock 87 63 573 minecraft:calcite
fill 87 63 574 88 63 576 minecraft:cobbled_deepslate
setblock 87 63 587 minecraft:cobbled_deepslate
setblock 87 63 588 minecraft:calcite
fill 87 63 589 87 66 589 minecraft:cobbled_deepslate
fill 87 63 591 87 64 591 minecraft:cobbled_deepslate
setblock 88 63 561 minecraft:cobbled_deepslate
setblock 88 63 562 minecraft:calcite
fill 88 63 563 88 66 563 minecraft:cobbled_deepslate
setblock 88 63 567 minecraft:calcite
fill 88 63 568 88 66 568 minecraft:cobbled_deepslate
schedule function dropper:buildpart/133_3 1t
