fill 167 269 356 167 270 356 minecraft:dark_prismarine
fill 167 269 358 167 270 358 minecraft:dark_prismarine
fill 167 269 360 167 270 360 minecraft:dark_prismarine
fill 167 269 362 167 270 362 minecraft:dark_prismarine
fill 167 269 363 168 270 363 minecraft:blue_terracotta
setblock 168 269 324 minecraft:blue_terracotta
setblock 168 269 325 minecraft:light[level=13]
setblock 168 269 333 minecraft:light[level=13]
setblock 168 269 341 minecraft:light[level=13]
setblock 168 269 349 minecraft:light[level=13]
fill 168 269 353 168 270 353 minecraft:dark_prismarine
fill 168 269 355 168 270 355 minecraft:dark_prismarine
fill 168 269 357 170 270 357 minecraft:dark_prismarine
fill 168 269 359 168 270 359 minecraft:dark_prismarine
fill 168 269 361 168 270 361 minecraft:dark_prismarine
setblock 169 269 324 minecraft:dark_prismarine
fill 169 269 350 169 270 352 minecraft:purple_concrete
fill 169 269 354 169 270 354 minecraft:dark_prismarine
fill 169 269 356 169 270 356 minecraft:dark_prismarine
fill 169 269 358 169 270 358 minecraft:magenta_terracotta
fill 169 269 360 169 270 360 minecraft:dark_prismarine
fill 169 269 362 170 269 362 minecraft:blue_terracotta
setblock 170 269 323 minecraft:dark_prismarine
fill 170 269 324 170 272 324 minecraft:blue_terracotta
fill 170 269 349 171 269 349 minecraft:purple_concrete
fill 170 269 353 170 270 353 minecraft:dark_prismarine
fill 170 269 355 170 270 355 minecraft:dark_prismarine
fill 170 269 359 170 270 359 minecraft:dark_prismarine
setblock 170 269 361 minecraft:dark_prismarine
setblock 170 269 363 minecraft:dark_prismarine
fill 171 269 323 171 272 323 minecraft:blue_terracotta
fill 171 269 325 171 270 325 minecraft:blue_terracotta
fill 171 269 350 172 269 350 minecraft:purple_concrete
fill 171 269 352 172 269 352 minecraft:purple_concrete
fill 171 269 354 171 270 354 minecraft:dark_prismarine
fill 171 269 356 171 270 356 minecraft:dark_prismarine
fill 171 269 358 171 270 358 minecraft:dark_prismarine
fill 171 269 360 171 270 360 minecraft:dark_prismarine
setblock 171 269 362 minecraft:dark_prismarine
fill 171 269 363 172 270 363 minecraft:blue_terracotta
setblock 172 269 332 minecraft:light[level=12]
setblock 172 269 339 minecraft:light[level=12]
setblock 172 269 346 minecraft:light[level=12]
fill 172 269 351 172 270 351 minecraft:purple_concrete
fill 172 269 353 172 270 353 minecraft:dark_prismarine
fill 172 269 355 172 270 355 minecraft:dark_prismarine
fill 172 269 357 172 270 357 minecraft:dark_prismarine
fill 172 269 359 172 270 359 minecraft:dark_prismarine
setblock 172 269 361 minecraft:dark_prismarine
fill 172 269 362 175 269 362 minecraft:blue_terracotta
fill 173 269 354 173 270 354 minecraft:dark_prismarine
fill 173 269 356 173 270 356 minecraft:dark_prismarine
fill 173 269 358 173 270 358 minecraft:dark_prismarine
fill 173 269 360 173 270 360 minecraft:dark_prismarine
fill 173 269 361 175 270 361 minecraft:blue_terracotta
setblock 174 269 324 minecraft:dark_prismarine
setblock 175 269 323 minecraft:dark_prismarine
fill 175 269 324 175 271 324 minecraft:blue_terracotta
setblock 175 269 363 minecraft:dark_prismarine
fill 176 269 323 176 272 323 minecraft:blue_terracotta
setblock 176 269 325 minecraft:light[level=13]
setblock 176 269 333 minecraft:light[level=13]
setblock 176 269 341 minecraft:light[level=13]
setblock 176 269 349 minecraft:light[level=13]
setblock 176 269 357 minecraft:light[level=13]
setblock 176 269 362 minecraft:dark_prismarine
fill 176 269 363 176 272 363 minecraft:blue_terracotta
fill 177 269 362 178 271 362 minecraft:blue_terracotta
setblock 179 269 325 minecraft:light[level=12]
setblock 179 269 332 minecraft:light[level=12]
setblock 179 269 339 minecraft:light[level=12]
setblock 179 269 346 minecraft:light[level=12]
setblock 179 269 353 minecraft:light[level=12]
setblock 179 269 360 minecraft:light[level=12]
setblock 180 269 363 minecraft:dark_prismarine
setblock 181 269 352 minecraft:dark_prismarine
fill 181 269 353 181 272 353 minecraft:blue_terracotta
fill 181 269 355 181 269 356 minecraft:blue_terracotta
setblock 181 269 357 minecraft:dark_prismarine
fill 181 269 358 181 271 359 minecraft:blue_terracotta
fill 181 269 363 181 272 363 minecraft:blue_terracotta
setblock 182 269 339 minecraft:purple_concrete
setblock 182 269 351 minecraft:dark_prismarine
fill 182 269 352 182 272 352 minecraft:blue_terracotta
setblock 182 269 356 minecraft:dark_prismarine
fill 182 269 357 182 272 357 minecraft:blue_terracotta
setblock 182 269 361 minecraft:dark_prismarine
fill 182 269 362 182 272 362 minecraft:blue_terracotta
fill 183 269 341 183 308 341 minecraft:blue_concrete
setblock 183 269 342 minecraft:light_blue_wool
fill 142 270 332 142 270 334 minecraft:blue_terracotta
setblock 142 270 335 minecraft:dark_prismarine
fill 142 270 336 142 270 339 minecraft:blue_terracotta
fill 142 270 347 142 272 347 minecraft:blue_terracotta
setblock 142 270 350 minecraft:dark_prismarine
fill 142 270 351 142 272 351 minecraft:blue_terracotta
setblock 142 270 355 minecraft:dark_prismarine
fill 142 270 356 142 272 356 minecraft:blue_terracotta
setblock 142 270 360 minecraft:dark_prismarine
fill 142 270 361 142 272 361 minecraft:blue_terracotta
fill 143 270 350 143 271 350 minecraft:blue_terracotta
setblock 143 270 354 minecraft:dark_prismarine
fill 143 270 355 144 272 355 minecraft:blue_terracotta
setblock 143 270 358 minecraft:blue_terracotta
fill 144 270 354 144 272 354 minecraft:blue_terracotta
fill 145 270 358 145 272 358 minecraft:dark_prismarine
fill 146 270 357 146 272 357 minecraft:dark_prismarine
fill 146 270 359 146 272 359 minecraft:dark_prismarine
fill 147 270 358 147 272 358 minecraft:dark_prismarine
setblock 148 270 323 minecraft:purple_concrete
setblock 148 270 363 minecraft:blue_terracotta
setblock 149 270 363 minecraft:dark_prismarine
fill 150 270 363 150 272 363 minecraft:blue_terracotta
fill 151 270 323 153 270 323 minecraft:blue_terracotta
fill 152 270 340 152 270 345 minecraft:dark_prismarine
fill 153 270 336 153 270 337 minecraft:purple_concrete
fill 153 270 338 153 270 340 minecraft:dark_prismarine
fill 153 270 345 153 270 347 minecraft:dark_prismarine
fill 153 270 348 153 270 349 minecraft:purple_concrete
setblock 153 270 363 minecraft:blue_terracotta
setblock 154 270 323 minecraft:dark_prismarine
setblock 154 270 340 minecraft:dark_prismarine
setblock 154 270 345 minecraft:dark_prismarine
setblock 154 270 363 minecraft:dark_prismarine
fill 155 270 323 155 272 323 minecraft:blue_terracotta
setblock 157 270 363 minecraft:purple_concrete
fill 160 270 348 160 271 349 minecraft:purple_concrete
fill 161 270 347 162 271 347 minecraft:purple_concrete
fill 161 270 350 162 270 350 minecraft:purple_concrete
fill 165 270 323 165 272 323 minecraft:blue_terracotta
setblock 166 270 363 minecraft:blue_terracotta
setblock 167 270 324 minecraft:blue_terracotta
setblock 168 270 324 minecraft:dark_prismarine
fill 168 270 362 169 270 362 minecraft:blue_terracotta
setblock 169 270 323 minecraft:dark_prismarine
fill 169 270 324 169 272 324 minecraft:blue_terracotta
fill 169 270 359 169 277 359 minecraft:magenta_terracotta
setblock 169 270 363 minecraft:dark_prismarine
fill 170 270 323 170 272 323 minecraft:blue_terracotta
fill 170 270 325 170 271 325 minecraft:blue_terracotta
setblock 170 270 361 minecraft:blue_terracotta
setblock 170 270 362 minecraft:dark_prismarine
setblock 170 270 363 minecraft:blue_terracotta
fill 171 270 350 171 271 350 minecraft:purple_concrete
fill 171 270 352 171 271 352 minecraft:purple_concrete
fill 171 270 362 174 270 362 minecraft:blue_terracotta
setblock 172 270 325 minecraft:dark_prismarine
setblock 172 270 361 minecraft:blue_terracotta
setblock 173 270 324 minecraft:dark_prismarine
setblock 174 270 323 minecraft:dark_prismarine
fill 174 270 324 174 272 324 minecraft:blue_terracotta
setblock 174 270 363 minecraft:dark_prismarine
fill 175 270 323 175 272 323 minecraft:blue_terracotta
setblock 175 270 362 minecraft:dark_prismarine
fill 175 270 363 175 272 363 minecraft:blue_terracotta
setblock 176 270 361 minecraft:dark_prismarine
fill 176 270 362 176 272 362 minecraft:blue_terracotta
setblock 179 270 362 minecraft:blue_terracotta
setblock 179 270 363 minecraft:dark_prismarine
setblock 180 270 356 minecraft:blue_terracotta
setblock 180 270 357 minecraft:dark_prismarine
fill 180 270 363 180 272 363 minecraft:blue_terracotta
fill 181 270 352 181 271 352 minecraft:blue_terracotta
setblock 181 270 355 minecraft:blue_terracotta
setblock 181 270 356 minecraft:dark_prismarine
fill 181 270 357 181 272 357 minecraft:blue_terracotta
setblock 181 270 360 minecraft:blue_terracotta
setblock 181 270 361 minecraft:dark_prismarine
setblock 182 270 333 minecraft:purple_concrete
setblock 182 270 350 minecraft:dark_prismarine
fill 182 270 351 182 272 351 minecraft:blue_terracotta
setblock 182 270 355 minecraft:dark_prismarine
fill 182 270 356 182 272 356 minecraft:blue_terracotta
setblock 182 270 359 minecraft:blue_terracotta
setblock 182 270 360 minecraft:dark_prismarine
fill 182 270 361 182 272 361 minecraft:blue_terracotta
fill 182 270 363 182 271 363 minecraft:blue_terracotta
fill 183 270 342 183 273 342 minecraft:blue_concrete
fill 142 271 332 142 271 333 minecraft:blue_terracotta
setblock 142 271 334 minecraft:dark_prismarine
fill 142 271 335 142 271 338 minecraft:blue_terracotta
setblock 142 271 339 minecraft:dark_prismarine
fill 142 271 340 142 272 342 minecraft:blue_terracotta
setblock 142 271 349 minecraft:dark_prismarine
fill 142 271 350 142 272 350 minecraft:blue_terracotta
setblock 142 271 354 minecraft:dark_prismarine
fill 142 271 355 142 272 355 minecraft:blue_terracotta
setblock 142 271 358 minecraft:blue_terracotta
setblock 142 271 359 minecraft:dark_prismarine
fill 142 271 360 142 272 360 minecraft:blue_terracotta
fill 143 271 335 143 271 337 minecraft:blue_terracotta
setblock 143 271 338 minecraft:dark_prismarine
setblock 143 271 353 minecraft:dark_prismarine
fill 143 271 354 143 272 354 minecraft:blue_terracotta
setblock 143 271 358 minecraft:dark_prismarine
fill 143 271 359 143 272 359 minecraft:blue_terracotta
setblock 144 271 356 minecraft:blue_terracotta
fill 145 271 357 145 272 357 minecraft:dark_prismarine
fill 145 271 359 145 272 359 minecraft:dark_prismarine
fill 146 271 363 147 271 363 minecraft:blue_terracotta
fill 147 271 357 147 272 357 minecraft:dark_prismarine
fill 147 271 359 147 272 359 minecraft:dark_prismarine
setblock 148 271 363 minecraft:dark_prismarine
fill 149 271 323 152 271 323 minecraft:blue_terracotta
setblock 149 271 362 minecraft:dark_prismarine
fill 149 271 363 149 272 363 minecraft:blue_terracotta
fill 150 271 362 151 272 362 minecraft:blue_terracotta
setblock 153 271 323 minecraft:dark_prismarine
fill 153 271 338 153 271 347 minecraft:purple_concrete
setblock 153 271 363 minecraft:dark_prismarine
fill 154 271 323 154 272 323 minecraft:blue_terracotta
fill 154 271 363 155 272 363 minecraft:blue_terracotta
setblock 161 271 323 minecraft:purple_concrete
setblock 163 271 348 minecraft:purple_concrete
setblock 163 271 354 minecraft:sea_lantern
setblock 163 271 356 minecraft:sea_lantern
setblock 163 271 358 minecraft:sea_lantern
setblock 163 271 360 minecraft:sea_lantern
setblock 163 271 362 minecraft:sea_lantern
setblock 163 271 363 minecraft:purple_concrete
fill 164 271 323 164 272 323 minecraft:blue_terracotta
setblock 164 271 353 minecraft:sea_lantern
setblock 164 271 355 minecraft:sea_lantern
setblock 164 271 357 minecraft:sea_lantern
setblock 164 271 359 minecraft:sea_lantern
setblock 164 271 361 minecraft:sea_lantern
setblock 164 271 363 minecraft:sea_lantern
setblock 165 271 354 minecraft:sea_lantern
setblock 165 271 356 minecraft:sea_lantern
setblock 165 271 358 minecraft:sea_lantern
setblock 165 271 360 minecraft:sea_lantern
setblock 165 271 362 minecraft:sea_lantern
fill 165 271 363 165 272 363 minecraft:blue_terracotta
setblock 166 271 324 minecraft:blue_terracotta
setblock 166 271 353 minecraft:sea_lantern
setblock 166 271 355 minecraft:sea_lantern
setblock 166 271 357 minecraft:sea_lantern
setblock 166 271 359 minecraft:sea_lantern
setblock 166 271 361 minecraft:sea_lantern
setblock 166 271 363 minecraft:sea_lantern
setblock 167 271 324 minecraft:dark_prismarine
setblock 167 271 354 minecraft:sea_lantern
setblock 167 271 356 minecraft:sea_lantern
setblock 167 271 358 minecraft:sea_lantern
setblock 167 271 360 minecraft:sea_lantern
setblock 167 271 362 minecraft:sea_lantern
setblock 167 271 363 minecraft:blue_terracotta
setblock 168 271 323 minecraft:dark_prismarine
fill 168 271 324 168 272 324 minecraft:blue_terracotta
setblock 168 271 353 minecraft:sea_lantern
setblock 168 271 355 minecraft:sea_lantern
setblock 168 271 357 minecraft:sea_lantern
setblock 168 271 359 minecraft:sea_lantern
setblock 168 271 361 minecraft:sea_lantern
setblock 168 271 362 minecraft:blue_terracotta
setblock 168 271 363 minecraft:sea_lantern
fill 169 271 323 169 272 323 minecraft:blue_terracotta
setblock 169 271 351 minecraft:purple_concrete
setblock 169 271 354 minecraft:sea_lantern
setblock 169 271 356 minecraft:sea_lantern
fill 169 271 357 169 272 357 minecraft:dark_prismarine
setblock 169 271 358 minecraft:sea_lantern
setblock 169 271 360 minecraft:sea_lantern
setblock 169 271 361 minecraft:blue_terracotta
setblock 169 271 362 minecraft:sea_lantern
fill 169 271 363 169 272 363 minecraft:blue_terracotta
setblock 170 271 353 minecraft:sea_lantern
setblock 170 271 355 minecraft:sea_lantern
setblock 170 271 357 minecraft:sea_lantern
setblock 170 271 359 minecraft:sea_lantern
setblock 170 271 361 minecraft:sea_lantern
fill 170 271 362 170 272 362 minecraft:blue_terracotta
setblock 170 271 363 minecraft:sea_lantern
setblock 171 271 325 minecraft:dark_prismarine
setblock 171 271 354 minecraft:sea_lantern
setblock 171 271 356 minecraft:sea_lantern
setblock 171 271 358 minecraft:sea_lantern
setblock 171 271 360 minecraft:sea_lantern
fill 171 271 361 171 272 361 minecraft:blue_terracotta
setblock 171 271 362 minecraft:sea_lantern
fill 171 271 363 171 272 363 minecraft:blue_terracotta
setblock 172 271 324 minecraft:dark_prismarine
setblock 172 271 353 minecraft:sea_lantern
setblock 172 271 355 minecraft:sea_lantern
setblock 172 271 357 minecraft:sea_lantern
setblock 172 271 359 minecraft:sea_lantern
fill 172 271 360 172 272 360 minecraft:blue_terracotta
setblock 172 271 361 minecraft:sea_lantern
fill 172 271 362 172 272 362 minecraft:blue_terracotta
setblock 172 271 363 minecraft:sea_lantern
setblock 173 271 323 minecraft:dark_prismarine
fill 173 271 324 173 272 324 minecraft:blue_terracotta
setblock 173 271 354 minecraft:sea_lantern
setblock 173 271 356 minecraft:sea_lantern
setblock 173 271 358 minecraft:sea_lantern
setblock 173 271 360 minecraft:sea_lantern
fill 173 271 361 174 271 361 minecraft:blue_terracotta
setblock 173 271 362 minecraft:sea_lantern
setblock 173 271 363 minecraft:dark_prismarine
fill 174 271 323 174 272 323 minecraft:blue_terracotta
fill 174 271 360 174 272 360 minecraft:blue_terracotta
setblock 174 271 362 minecraft:dark_prismarine
fill 174 271 363 174 272 363 minecraft:blue_terracotta
setblock 175 271 361 minecraft:dark_prismarine
fill 175 271 362 175 272 362 minecraft:blue_terracotta
fill 176 271 361 177 272 361 minecraft:blue_terracotta
setblock 178 271 363 minecraft:dark_prismarine
setblock 179 271 362 minecraft:dark_prismarine
fill 179 271 363 179 272 363 minecraft:blue_terracotta
setblock 180 271 355 minecraft:blue_terracotta
setblock 180 271 356 minecraft:dark_prismarine
fill 180 271 357 180 272 358 minecraft:blue_terracotta
fill 180 271 362 180 272 362 minecraft:blue_terracotta
setblock 181 271 355 minecraft:dark_prismarine
fill 181 271 356 181 272 356 minecraft:blue_terracotta
setblock 181 271 360 minecraft:dark_prismarine
fill 181 271 361 181 272 361 minecraft:blue_terracotta
setblock 182 271 327 minecraft:purple_concrete
setblock 182 271 334 minecraft:dark_prismarine
fill 182 271 335 182 272 335 minecraft:blue_terracotta
setblock 182 271 346 minecraft:purple_concrete
fill 182 271 350 182 272 350 minecraft:blue_terracotta
setblock 182 271 354 minecraft:dark_prismarine
fill 182 271 355 182 272 355 minecraft:blue_terracotta
setblock 182 271 359 minecraft:dark_prismarine
fill 182 271 360 182 272 360 minecraft:blue_terracotta
setblock 142 272 332 minecraft:blue_terracotta
setblock 142 272 333 minecraft:dark_prismarine
fill 142 272 334 142 272 337 minecraft:blue_terracotta
setblock 142 272 338 minecraft:dark_prismarine
fill 142 272 339 143 272 339 minecraft:blue_terracotta
setblock 142 272 343 minecraft:dark_prismarine
fill 142 272 344 142 272 346 minecraft:blue_terracotta
setblock 142 272 348 minecraft:dark_prismarine
setblock 142 272 349 minecraft:blue_terracotta
setblock 142 272 353 minecraft:dark_prismarine
setblock 142 272 354 minecraft:blue_terracotta
setblock 142 272 357 minecraft:blue_terracotta
setblock 142 272 358 minecraft:dark_prismarine
setblock 142 272 359 minecraft:blue_terracotta
setblock 142 272 362 minecraft:blue_terracotta
fill 143 272 334 143 272 336 minecraft:blue_terracotta
setblock 143 272 337 minecraft:dark_prismarine
setblock 143 272 338 minecraft:blue_terracotta
fill 143 272 340 143 272 341 minecraft:blue_terracotta
setblock 143 272 352 minecraft:dark_prismarine
setblock 143 272 353 minecraft:blue_terracotta
setblock 143 272 357 minecraft:dark_prismarine
setblock 143 272 358 minecraft:blue_terracotta
setblock 143 272 360 minecraft:blue_terracotta
setblock 144 272 356 minecraft:dark_prismarine
setblock 144 272 357 minecraft:blue_terracotta
setblock 144 272 358 minecraft:dark_prismarine
setblock 144 272 363 minecraft:purple_concrete
fill 145 272 363 146 272 363 minecraft:blue_terracotta
setblock 146 272 356 minecraft:dark_prismarine
setblock 146 272 360 minecraft:dark_prismarine
setblock 147 272 362 minecraft:blue_terracotta
setblock 147 272 363 minecraft:dark_prismarine
fill 148 272 323 151 272 323 minecraft:blue_terracotta
setblock 148 272 358 minecraft:dark_prismarine
setblock 148 272 362 minecraft:dark_prismarine
setblock 148 272 363 minecraft:blue_terracotta
setblock 149 272 362 minecraft:blue_terracotta
setblock 151 272 363 minecraft:blue_terracotta
setblock 152 272 323 minecraft:dark_prismarine
setblock 152 272 362 minecraft:blue_terracotta
setblock 152 272 363 minecraft:dark_prismarine
setblock 153 272 323 minecraft:blue_terracotta
setblock 153 272 363 minecraft:blue_terracotta
setblock 156 272 323 minecraft:blue_terracotta
setblock 163 272 323 minecraft:blue_terracotta
setblock 163 272 354 minecraft:dark_prismarine
setblock 163 272 356 minecraft:dark_prismarine
setblock 163 272 358 minecraft:dark_prismarine
setblock 163 272 360 minecraft:dark_prismarine
setblock 163 272 362 minecraft:dark_prismarine
fill 163 272 363 164 272 363 minecraft:blue_terracotta
setblock 164 272 353 minecraft:dark_prismarine
setblock 164 272 355 minecraft:dark_prismarine
setblock 164 272 357 minecraft:dark_prismarine
setblock 164 272 359 minecraft:dark_prismarine
setblock 164 272 361 minecraft:dark_prismarine
setblock 165 272 354 minecraft:dark_prismarine
setblock 165 272 356 minecraft:dark_prismarine
setblock 165 272 358 minecraft:dark_prismarine
setblock 165 272 360 minecraft:dark_prismarine
fill 165 272 362 167 272 362 minecraft:blue_terracotta
setblock 166 272 324 minecraft:dark_prismarine
setblock 166 272 353 minecraft:dark_prismarine
setblock 166 272 355 minecraft:dark_prismarine
setblock 166 272 357 minecraft:dark_prismarine
setblock 166 272 359 minecraft:dark_prismarine
setblock 166 272 361 minecraft:dark_prismarine
setblock 166 272 363 minecraft:blue_terracotta
setblock 167 272 323 minecraft:dark_prismarine
setblock 167 272 324 minecraft:blue_terracotta
setblock 167 272 354 minecraft:dark_prismarine
setblock 167 272 356 minecraft:dark_prismarine
setblock 167 272 358 minecraft:dark_prismarine
setblock 167 272 360 minecraft:dark_prismarine
fill 167 272 361 168 272 361 minecraft:blue_terracotta
setblock 167 272 363 minecraft:dark_prismarine
setblock 168 272 323 minecraft:blue_terracotta
setblock 168 272 353 minecraft:dark_prismarine
setblock 168 272 355 minecraft:dark_prismarine
setblock 168 272 357 minecraft:dark_prismarine
setblock 168 272 359 minecraft:dark_prismarine
setblock 168 272 362 minecraft:dark_prismarine
setblock 168 272 363 minecraft:blue_terracotta
setblock 169 272 325 minecraft:blue_terracotta
setblock 169 272 354 minecraft:dark_prismarine
setblock 169 272 356 minecraft:dark_prismarine
fill 169 272 358 169 277 358 minecraft:magenta_terracotta
setblock 169 272 360 minecraft:blue_terracotta
setblock 169 272 361 minecraft:dark_prismarine
setblock 169 272 362 minecraft:blue_terracotta
setblock 170 272 325 minecraft:dark_prismarine
setblock 170 272 353 minecraft:dark_prismarine
setblock 170 272 355 minecraft:dark_prismarine
setblock 170 272 357 minecraft:dark_prismarine
setblock 170 272 359 minecraft:dark_prismarine
setblock 170 272 361 minecraft:blue_terracotta
setblock 170 272 363 minecraft:blue_terracotta
setblock 171 272 324 minecraft:dark_prismarine
setblock 171 272 325 minecraft:blue_terracotta
setblock 171 272 354 minecraft:dark_prismarine
setblock 171 272 356 minecraft:dark_prismarine
setblock 171 272 358 minecraft:dark_prismarine
setblock 171 272 360 minecraft:blue_terracotta
setblock 171 272 362 minecraft:blue_terracotta
setblock 172 272 323 minecraft:dark_prismarine
setblock 172 272 324 minecraft:blue_terracotta
setblock 172 272 353 minecraft:dark_prismarine
setblock 172 272 355 minecraft:dark_prismarine
setblock 172 272 357 minecraft:dark_prismarine
setblock 172 272 359 minecraft:dark_prismarine
fill 172 272 361 173 272 361 minecraft:blue_terracotta
setblock 172 272 363 minecraft:dark_prismarine
setblock 173 272 323 minecraft:blue_terracotta
setblock 173 272 354 minecraft:dark_prismarine
setblock 173 272 356 minecraft:dark_prismarine
setblock 173 272 358 minecraft:dark_prismarine
setblock 173 272 360 minecraft:blue_terracotta
setblock 173 272 362 minecraft:dark_prismarine
setblock 173 272 363 minecraft:blue_terracotta
setblock 174 272 361 minecraft:dark_prismarine
setblock 174 272 362 minecraft:blue_terracotta
setblock 175 272 360 minecraft:dark_prismarine
setblock 175 272 361 minecraft:blue_terracotta
setblock 177 272 323 minecraft:dark_prismarine
setblock 177 272 362 minecraft:blue_terracotta
setblock 177 272 363 minecraft:dark_prismarine
setblock 178 272 362 minecraft:dark_prismarine
setblock 178 272 363 minecraft:blue_terracotta
setblock 179 272 362 minecraft:blue_terracotta
setblock 180 272 323 minecraft:purple_concrete
setblock 180 272 356 minecraft:blue_terracotta
setblock 180 272 359 minecraft:blue_terracotta
setblock 181 272 354 minecraft:dark_prismarine
setblock 181 272 355 minecraft:blue_terracotta
setblock 181 272 358 minecraft:blue_terracotta
setblock 181 272 359 minecraft:dark_prismarine
setblock 181 272 360 minecraft:blue_terracotta
setblock 181 272 362 minecraft:blue_terracotta
setblock 182 272 334 minecraft:blue_terracotta
fill 182 272 336 182 272 337 minecraft:blue_terracotta
setblock 182 272 338 minecraft:dark_prismarine
setblock 182 272 340 minecraft:purple_concrete
setblock 182 272 353 minecraft:dark_prismarine
setblock 182 272 354 minecraft:blue_terracotta
setblock 182 272 358 minecraft:dark_prismarine
setblock 182 272 359 minecraft:blue_terracotta
setblock 182 272 363 minecraft:dark_prismarine
setblock 164 273 364 minecraft:light_blue_wool
fill 155 274 327 155 277 327 minecraft:magenta_terracotta
fill 155 274 364 156 279 364 minecraft:blue_concrete
setblock 157 274 364 minecraft:light_blue_wool
fill 164 274 364 164 308 364 minecraft:blue_concrete
setblock 166 274 364 minecraft:cyan_concrete
setblock 172 274 364 minecraft:cyan_concrete
fill 173 274 364 174 308 364 minecraft:blue_concrete
setblock 183 274 342 minecraft:light_blue_wool
setblock 144 275 325 minecraft:light[level=12]
setblock 144 275 332 minecraft:light[level=12]
setblock 144 275 339 minecraft:light[level=12]
setblock 144 275 346 minecraft:light[level=12]
setblock 144 275 353 minecraft:light[level=12]
setblock 144 275 360 minecraft:light[level=12]
setblock 151 275 325 minecraft:light[level=12]
setblock 151 275 332 minecraft:light[level=12]
setblock 151 275 339 minecraft:light[level=12]
setblock 151 275 346 minecraft:light[level=12]
setblock 151 275 353 minecraft:light[level=12]
setblock 151 275 360 minecraft:light[level=12]
fill 157 275 364 157 308 364 minecraft:blue_concrete
setblock 158 275 325 minecraft:light[level=12]
setblock 158 275 332 minecraft:light[level=12]
setblock 158 275 339 minecraft:light[level=12]
setblock 158 275 346 minecraft:light[level=12]
setblock 158 275 353 minecraft:light[level=12]
setblock 158 275 360 minecraft:light[level=12]
setblock 165 275 325 minecraft:light[level=12]
setblock 165 275 332 minecraft:light[level=12]
setblock 165 275 339 minecraft:light[level=12]
setblock 165 275 346 minecraft:light[level=12]
setblock 165 275 353 minecraft:light[level=12]
setblock 165 275 360 minecraft:light[level=12]
fill 166 275 364 166 308 364 minecraft:blue_concrete
setblock 172 275 325 minecraft:light[level=12]
setblock 172 275 332 minecraft:light[level=12]
setblock 172 275 339 minecraft:light[level=12]
setblock 172 275 346 minecraft:light[level=12]
setblock 172 275 353 minecraft:light[level=12]
setblock 172 275 360 minecraft:light[level=12]
fill 172 275 364 172 308 364 minecraft:blue_concrete
setblock 179 275 325 minecraft:light[level=12]
setblock 179 275 332 minecraft:light[level=12]
setblock 179 275 339 minecraft:light[level=12]
setblock 179 275 346 minecraft:light[level=12]
setblock 179 275 353 minecraft:light[level=12]
setblock 179 275 360 minecraft:light[level=12]
fill 183 275 342 183 308 342 minecraft:blue_concrete
fill 148 276 342 148 277 342 minecraft:magenta_terracotta
setblock 144 277 325 minecraft:light[level=13]
setblock 144 277 333 minecraft:light[level=13]
setblock 144 277 341 minecraft:light[level=13]
setblock 144 277 349 minecraft:light[level=13]
setblock 144 277 357 minecraft:light[level=13]
setblock 152 277 325 minecraft:light[level=13]
setblock 152 277 333 minecraft:light[level=13]
setblock 152 277 341 minecraft:light[level=13]
setblock 152 277 349 minecraft:light[level=13]
setblock 152 277 357 minecraft:light[level=13]
setblock 160 277 325 minecraft:light[level=13]
setblock 160 277 333 minecraft:light[level=13]
setblock 160 277 349 minecraft:light[level=13]
setblock 160 277 357 minecraft:light[level=13]
setblock 168 277 325 minecraft:light[level=13]
setblock 168 277 333 minecraft:light[level=13]
setblock 168 277 341 minecraft:light[level=13]
setblock 168 277 349 minecraft:light[level=13]
setblock 168 277 357 minecraft:light[level=13]
setblock 176 277 325 minecraft:light[level=13]
setblock 176 277 333 minecraft:light[level=13]
setblock 176 277 341 minecraft:light[level=13]
setblock 176 277 349 minecraft:light[level=13]
setblock 176 277 357 minecraft:light[level=13]
fill 183 277 337 183 308 337 minecraft:blue_concrete
setblock 183 277 338 minecraft:light_blue_wool
fill 183 277 339 183 308 339 minecraft:blue_concrete
fill 142 278 323 144 279 363 minecraft:spruce_planks
fill 145 278 323 145 279 363 minecraft:dark_oak_planks
fill 146 278 323 148 279 363 minecraft:spruce_planks
fill 149 278 323 149 279 363 minecraft:dark_oak_planks
fill 150 278 323 152 278 363 minecraft:spruce_planks
fill 153 278 323 153 278 363 minecraft:dark_oak_planks
fill 154 278 323 156 278 363 minecraft:spruce_planks
fill 157 278 323 157 278 363 minecraft:dark_oak_planks
fill 158 278 323 158 278 363 minecraft:spruce_planks
fill 159 278 323 159 278 340 minecraft:spruce_planks
fill 159 278 342 159 278 363 minecraft:spruce_planks
fill 160 278 323 160 278 338 minecraft:spruce_planks
fill 160 278 344 160 278 363 minecraft:spruce_planks
fill 161 278 323 161 278 338 minecraft:dark_oak_planks
fill 161 278 344 161 278 363 minecraft:dark_oak_planks
fill 162 278 323 164 278 337 minecraft:spruce_planks
fill 162 278 345 164 278 363 minecraft:spruce_planks
fill 163 278 338 164 278 338 minecraft:spruce_planks
fill 163 278 344 164 278 344 minecraft:spruce_planks
fill 165 278 323 165 278 340 minecraft:dark_oak_planks
fill 165 278 342 165 278 363 minecraft:dark_oak_planks
fill 166 278 323 168 278 363 minecraft:spruce_planks
fill 169 278 323 169 278 363 minecraft:dark_oak_planks
fill 170 278 323 172 278 363 minecraft:spruce_planks
fill 173 278 323 173 278 363 minecraft:dark_oak_planks
fill 174 278 323 176 278 363 minecraft:spruce_planks
fill 177 278 323 177 278 363 minecraft:dark_oak_planks
fill 178 278 323 180 278 363 minecraft:spruce_planks
fill 181 278 323 181 278 363 minecraft:dark_oak_planks
fill 182 278 323 182 279 363 minecraft:spruce_planks
fill 183 278 338 183 308 338 minecraft:blue_concrete
fill 183 278 348 183 285 350 minecraft:blue_concrete
setblock 183 278 351 minecraft:cyan_concrete
fill 183 278 352 183 299 352 minecraft:blue_concrete
fill 150 279 323 151 279 363 minecraft:spruce_planks
fill 152 279 323 152 279 356 minecraft:spruce_planks
fill 152 279 357 153 281 359 minecraft:magenta_terracotta
fill 152 279 360 152 279 363 minecraft:spruce_planks
fill 153 279 323 153 279 326 minecraft:dark_oak_planks
fill 153 279 327 154 281 328 minecraft:magenta_terracotta
fill 153 279 329 153 279 348 minecraft:dark_oak_planks
fill 153 279 349 154 281 356 minecraft:magenta_terracotta
fill 153 279 360 153 279 363 minecraft:dark_oak_planks
fill 154 279 323 156 279 326 minecraft:spruce_planks
fill 154 279 329 157 281 329 minecraft:magenta_terracotta
fill 154 279 330 154 279 346 minecraft:spruce_planks
fill 154 279 347 155 281 348 minecraft:magenta_terracotta
fill 154 279 357 154 281 358 minecraft:magenta_terracotta
fill 154 279 359 156 279 363 minecraft:spruce_planks
fill 155 279 327 156 279 327 minecraft:spruce_planks
fill 155 279 328 155 291 328 minecraft:magenta_terracotta
fill 155 279 330 158 281 330 minecraft:magenta_terracotta
fill 155 279 331 156 279 346 minecraft:spruce_planks
fill 155 279 349 155 281 350 minecraft:magenta_terracotta
fill 155 279 351 156 279 358 minecraft:spruce_planks
setblock 156 279 328 minecraft:spruce_planks
fill 156 279 347 156 279 350 minecraft:spruce_planks
fill 157 279 323 157 279 328 minecraft:dark_oak_planks
fill 157 279 331 159 281 331 minecraft:magenta_terracotta
fill 157 279 332 157 279 363 minecraft:dark_oak_planks
fill 158 279 323 160 279 329 minecraft:spruce_planks
fill 158 279 332 161 281 332 minecraft:magenta_terracotta
fill 158 279 333 158 279 339 minecraft:spruce_planks
fill 158 279 340 158 279 342 minecraft:ochre_froglight
fill 158 279 343 158 279 363 minecraft:spruce_planks
fill 159 279 330 160 279 330 minecraft:spruce_planks
fill 159 279 333 162 281 333 minecraft:magenta_terracotta
fill 159 279 334 160 279 337 minecraft:spruce_planks
fill 159 279 338 159 279 340 minecraft:ochre_froglight
fill 159 279 342 159 279 344 minecraft:ochre_froglight
fill 159 279 345 160 279 363 minecraft:spruce_planks
setblock 160 279 331 minecraft:spruce_planks
fill 160 279 338 161 279 338 minecraft:ochre_froglight
fill 160 279 344 161 279 344 minecraft:ochre_froglight
fill 161 279 323 161 279 331 minecraft:dark_oak_planks
fill 161 279 334 163 281 334 minecraft:magenta_terracotta
fill 161 279 335 161 279 336 minecraft:dark_oak_planks
fill 161 279 337 163 279 337 minecraft:ochre_froglight
fill 161 279 345 163 279 345 minecraft:ochre_froglight
fill 161 279 346 161 279 363 minecraft:dark_oak_planks
fill 162 279 323 164 279 332 minecraft:spruce_planks
fill 162 279 335 162 281 335 minecraft:magenta_terracotta
fill 162 279 336 164 279 336 minecraft:spruce_planks
fill 162 279 346 164 279 363 minecraft:spruce_planks
fill 163 279 333 164 279 333 minecraft:spruce_planks
fill 163 279 335 164 279 335 minecraft:spruce_planks
fill 163 279 338 165 279 338 minecraft:ochre_froglight
fill 163 279 344 165 279 344 minecraft:ochre_froglight
setblock 164 279 334 minecraft:spruce_planks
setblock 164 279 337 minecraft:spruce_planks
setblock 164 279 345 minecraft:spruce_planks
fill 165 279 323 165 279 337 minecraft:dark_oak_planks
fill 165 279 339 165 279 340 minecraft:ochre_froglight
fill 165 279 342 165 279 343 minecraft:ochre_froglight
fill 165 279 345 165 279 363 minecraft:dark_oak_planks
fill 166 279 323 168 279 339 minecraft:spruce_planks
fill 166 279 340 166 279 342 minecraft:ochre_froglight
fill 166 279 343 168 279 363 minecraft:spruce_planks
fill 167 279 340 168 279 342 minecraft:spruce_planks
fill 169 279 323 169 279 346 minecraft:dark_oak_planks
fill 169 279 347 173 281 347 minecraft:magenta_terracotta
fill 169 279 348 169 279 363 minecraft:dark_oak_planks
fill 170 279 323 170 279 346 minecraft:spruce_planks
fill 170 279 348 171 281 348 minecraft:magenta_terracotta
fill 170 279 349 172 279 363 minecraft:spruce_planks
fill 171 279 323 172 279 345 minecraft:spruce_planks
fill 171 279 346 175 281 346 minecraft:magenta_terracotta
setblock 172 279 348 minecraft:spruce_planks
fill 173 279 323 173 279 344 minecraft:dark_oak_planks
fill 173 279 345 178 281 345 minecraft:magenta_terracotta
fill 173 279 348 173 279 363 minecraft:dark_oak_planks
fill 174 279 323 174 279 344 minecraft:spruce_planks
fill 174 279 347 176 279 363 minecraft:spruce_planks
fill 175 279 323 176 279 343 minecraft:spruce_planks
fill 175 279 344 180 281 344 minecraft:magenta_terracotta
setblock 176 279 346 minecraft:spruce_planks
fill 177 279 323 177 279 343 minecraft:dark_oak_planks
fill 177 279 346 177 279 363 minecraft:dark_oak_planks
fill 178 279 323 179 279 342 minecraft:spruce_planks
fill 178 279 343 181 281 343 minecraft:magenta_terracotta
fill 178 279 346 180 279 363 minecraft:spruce_planks
fill 179 279 345 180 279 345 minecraft:spruce_planks
fill 180 279 323 180 279 341 minecraft:spruce_planks
fill 180 279 342 180 281 342 minecraft:magenta_terracotta
fill 181 279 323 181 279 342 minecraft:dark_oak_planks
fill 181 279 344 181 279 363 minecraft:dark_oak_planks
setblock 183 279 340 minecraft:cyan_concrete
fill 183 279 351 183 308 351 minecraft:blue_concrete
fill 148 280 342 148 286 343 minecraft:magenta_terracotta
fill 152 280 327 152 280 328 minecraft:magenta_terracotta
fill 152 280 354 152 280 356 minecraft:magenta_terracotta
setblock 153 280 326 minecraft:magenta_terracotta
setblock 153 280 329 minecraft:magenta_terracotta
fill 153 280 347 153 280 348 minecraft:magenta_terracotta
setblock 153 280 360 minecraft:magenta_terracotta
setblock 154 280 359 minecraft:magenta_terracotta
fill 155 280 327 155 298 327 minecraft:magenta_terracotta
fill 155 280 351 155 280 353 minecraft:magenta_terracotta
fill 155 280 358 155 298 358 minecraft:magenta_terracotta
fill 155 280 364 155 308 364 minecraft:blue_concrete
setblock 156 280 328 minecraft:magenta_terracotta
setblock 156 280 331 minecraft:magenta_terracotta
setblock 156 280 364 minecraft:light_blue_wool
setblock 157 280 332 minecraft:magenta_terracotta
setblock 159 280 330 minecraft:magenta_terracotta
setblock 160 280 331 minecraft:magenta_terracotta
setblock 160 280 334 minecraft:magenta_terracotta
setblock 161 280 335 minecraft:magenta_terracotta
setblock 163 280 333 minecraft:magenta_terracotta
setblock 163 280 335 minecraft:magenta_terracotta
fill 169 280 327 169 280 328 minecraft:magenta_terracotta
setblock 169 280 348 minecraft:magenta_terracotta
fill 169 280 358 169 289 359 minecraft:magenta_terracotta
fill 170 280 328 170 297 328 minecraft:magenta_terracotta
setblock 170 280 346 minecraft:magenta_terracotta
setblock 172 280 345 minecraft:magenta_terracotta
setblock 172 280 348 minecraft:magenta_terracotta
setblock 174 280 344 minecraft:magenta_terracotta
setblock 174 280 347 minecraft:magenta_terracotta
fill 176 280 343 177 280 343 minecraft:magenta_terracotta
setblock 176 280 346 minecraft:magenta_terracotta
setblock 179 280 342 minecraft:magenta_terracotta
setblock 179 280 345 minecraft:magenta_terracotta
setblock 181 280 342 minecraft:magenta_terracotta
setblock 181 280 344 minecraft:magenta_terracotta
fill 183 280 340 183 308 340 minecraft:blue_concrete
setblock 141 281 348 minecraft:light_blue_wool
fill 141 281 349 141 308 349 minecraft:blue_concrete
setblock 144 281 325 minecraft:light[level=12]
setblock 144 281 332 minecraft:light[level=12]
setblock 144 281 339 minecraft:light[level=12]
setblock 144 281 346 minecraft:light[level=12]
setblock 144 281 353 minecraft:light[level=12]
setblock 144 281 360 minecraft:light[level=12]
setblock 151 281 325 minecraft:light[level=12]
setblock 151 281 332 minecraft:light[level=12]
setblock 151 281 339 minecraft:light[level=12]
setblock 151 281 346 minecraft:light[level=12]
setblock 151 281 353 minecraft:light[level=12]
setblock 151 281 360 minecraft:light[level=12]
fill 156 281 364 156 308 364 minecraft:blue_concrete
setblock 158 281 325 minecraft:light[level=12]
setblock 158 281 339 minecraft:light[level=12]
setblock 158 281 346 minecraft:light[level=12]
setblock 158 281 353 minecraft:light[level=12]
setblock 158 281 360 minecraft:light[level=12]
setblock 165 281 325 minecraft:light[level=12]
setblock 165 281 332 minecraft:light[level=12]
setblock 165 281 339 minecraft:light[level=12]
setblock 165 281 346 minecraft:light[level=12]
setblock 165 281 353 minecraft:light[level=12]
setblock 165 281 360 minecraft:light[level=12]
fill 169 281 328 169 298 328 minecraft:magenta_terracotta
setblock 172 281 325 minecraft:light[level=12]
setblock 172 281 332 minecraft:light[level=12]
setblock 172 281 339 minecraft:light[level=12]
setblock 172 281 353 minecraft:light[level=12]
setblock 172 281 360 minecraft:light[level=12]
fill 176 281 343 176 289 343 minecraft:magenta_terracotta
setblock 179 281 325 minecraft:light[level=12]
setblock 179 281 332 minecraft:light[level=12]
setblock 179 281 339 minecraft:light[level=12]
setblock 179 281 346 minecraft:light[level=12]
setblock 179 281 353 minecraft:light[level=12]
setblock 179 281 360 minecraft:light[level=12]
fill 141 282 348 141 308 348 minecraft:blue_concrete
fill 176 282 344 176 298 344 minecraft:magenta_terracotta
fill 142 283 323 142 283 326 minecraft:blue_terracotta
setblock 142 283 327 minecraft:dark_prismarine
fill 142 283 328 142 283 331 minecraft:blue_terracotta
setblock 142 283 332 minecraft:dark_prismarine
fill 142 283 333 142 283 336 minecraft:blue_terracotta
setblock 142 283 337 minecraft:dark_prismarine
fill 142 283 338 142 283 341 minecraft:blue_terracotta
setblock 142 283 342 minecraft:dark_prismarine
fill 142 283 343 142 283 346 minecraft:blue_terracotta
setblock 142 283 347 minecraft:dark_prismarine
fill 142 283 348 142 283 351 minecraft:blue_terracotta
setblock 142 283 352 minecraft:dark_prismarine
fill 142 283 353 142 283 356 minecraft:blue_terracotta
setblock 142 283 357 minecraft:dark_prismarine
fill 142 283 358 142 283 361 minecraft:blue_terracotta
setblock 142 283 362 minecraft:dark_prismarine
fill 142 283 363 145 283 363 minecraft:blue_terracotta
fill 143 283 323 143 283 325 minecraft:blue_terracotta
setblock 143 283 326 minecraft:dark_prismarine
fill 143 283 327 143 283 330 minecraft:blue_terracotta
setblock 143 283 331 minecraft:dark_prismarine
fill 143 283 332 143 283 335 minecraft:blue_terracotta
setblock 143 283 336 minecraft:dark_prismarine
fill 143 283 337 143 283 340 minecraft:blue_terracotta
setblock 143 283 341 minecraft:dark_prismarine
fill 143 283 342 143 283 345 minecraft:blue_terracotta
setblock 143 283 346 minecraft:dark_prismarine
fill 143 283 347 143 283 350 minecraft:blue_terracotta
setblock 143 283 351 minecraft:dark_prismarine
setblock 143 283 361 minecraft:dark_prismarine
fill 143 283 362 146 283 362 minecraft:blue_terracotta
fill 144 283 323 144 283 324 minecraft:blue_terracotta
setblock 144 283 325 minecraft:dark_prismarine
fill 144 283 332 144 285 334 minecraft:purple_concrete
fill 144 283 336 144 283 339 minecraft:blue_terracotta
setblock 144 283 340 minecraft:dark_prismarine
fill 144 283 341 144 283 344 minecraft:blue_terracotta
setblock 144 283 345 minecraft:dark_prismarine
fill 144 283 346 144 284 348 minecraft:blue_terracotta
setblock 145 283 323 minecraft:blue_terracotta
setblock 145 283 324 minecraft:dark_prismarine
fill 145 283 325 148 283 325 minecraft:blue_terracotta
fill 145 283 333 145 286 333 minecraft:purple_concrete
setblock 145 283 339 minecraft:dark_prismarine
fill 145 283 340 145 283 343 minecraft:blue_terracotta
setblock 145 283 344 minecraft:dark_prismarine
fill 145 283 345 145 285 346 minecraft:blue_terracotta
setblock 146 283 323 minecraft:dark_prismarine
fill 146 283 324 149 283 324 minecraft:blue_terracotta
setblock 146 283 363 minecraft:dark_prismarine
fill 147 283 323 150 283 323 minecraft:blue_terracotta
setblock 147 283 362 minecraft:dark_prismarine
fill 147 283 363 150 283 363 minecraft:blue_terracotta
setblock 150 283 324 minecraft:dark_prismarine
fill 150 283 336 151 283 337 minecraft:black_concrete
setblock 151 283 323 minecraft:dark_prismarine
fill 151 283 324 154 283 324 minecraft:blue_terracotta
fill 151 283 354 153 283 355 minecraft:black_concrete
fill 151 283 359 151 285 359 minecraft:dark_prismarine
setblock 151 283 363 minecraft:dark_prismarine
fill 152 283 323 155 283 323 minecraft:blue_terracotta
fill 152 283 356 153 283 356 minecraft:black_concrete
fill 152 283 363 155 283 363 minecraft:blue_terracotta
fill 153 283 351 156 287 351 minecraft:black_concrete
fill 154 283 350 155 287 350 minecraft:black_concrete
fill 154 283 352 156 287 352 minecraft:black_concrete
setblock 155 283 324 minecraft:dark_prismarine
fill 155 283 357 155 298 357 minecraft:magenta_terracotta
setblock 156 283 323 minecraft:dark_prismarine
fill 156 283 324 159 283 324 minecraft:blue_terracotta
setblock 156 283 363 minecraft:dark_prismarine
fill 157 283 323 160 283 323 minecraft:blue_terracotta
fill 157 283 355 159 300 357 minecraft:dark_prismarine
fill 157 283 363 160 283 363 minecraft:blue_terracotta
fill 158 283 358 159 300 358 minecraft:dark_prismarine
setblock 159 283 325 minecraft:dark_prismarine
fill 159 283 362 161 283 362 minecraft:blue_terracotta
setblock 160 283 324 minecraft:dark_prismarine
fill 160 283 325 163 283 325 minecraft:blue_terracotta
fill 160 283 356 160 300 357 minecraft:dark_prismarine
setblock 161 283 323 minecraft:dark_prismarine
fill 161 283 324 164 283 324 minecraft:blue_terracotta
setblock 161 283 363 minecraft:dark_prismarine
fill 162 283 323 165 283 323 minecraft:blue_terracotta
setblock 162 283 361 minecraft:blue_terracotta
setblock 162 283 362 minecraft:dark_prismarine
fill 162 283 363 165 283 363 minecraft:blue_terracotta
setblock 163 283 361 minecraft:dark_prismarine
fill 163 283 362 166 283 362 minecraft:blue_terracotta
setblock 164 283 325 minecraft:dark_prismarine
fill 164 283 361 167 283 361 minecraft:blue_terracotta
setblock 165 283 324 minecraft:dark_prismarine
fill 165 283 325 168 283 325 minecraft:blue_terracotta
setblock 166 283 323 minecraft:dark_prismarine
fill 166 283 324 169 283 324 minecraft:blue_terracotta
setblock 166 283 363 minecraft:dark_prismarine
fill 167 283 323 170 283 323 minecraft:blue_terracotta
setblock 167 283 362 minecraft:dark_prismarine
fill 167 283 363 170 283 363 minecraft:blue_terracotta
setblock 168 283 361 minecraft:dark_prismarine
fill 168 283 362 171 283 362 minecraft:blue_terracotta
fill 169 283 361 170 283 361 minecraft:blue_terracotta
setblock 170 283 324 minecraft:dark_prismarine
setblock 171 283 323 minecraft:dark_prismarine
fill 171 283 324 171 286 324 minecraft:blue_terracotta
setblock 171 283 363 minecraft:dark_prismarine
fill 172 283 323 175 283 323 minecraft:blue_terracotta
setblock 172 283 362 minecraft:dark_prismarine
fill 172 283 363 175 283 363 minecraft:blue_terracotta
fill 173 283 352 180 285 361 minecraft:dark_prismarine
fill 173 283 362 176 283 362 minecraft:blue_terracotta
setblock 176 283 323 minecraft:dark_prismarine
setblock 176 283 363 minecraft:dark_prismarine
fill 177 283 323 180 283 323 minecraft:blue_terracotta
setblock 177 283 362 minecraft:dark_prismarine
fill 177 283 363 180 283 363 minecraft:blue_terracotta
fill 178 283 362 181 283 362 minecraft:blue_terracotta
fill 180 283 342 180 283 343 minecraft:blue_terracotta
setblock 180 283 344 minecraft:dark_prismarine
fill 180 283 345 181 283 347 minecraft:blue_terracotta
setblock 181 283 323 minecraft:dark_prismarine
fill 181 283 339 181 283 342 minecraft:blue_terracotta
setblock 181 283 343 minecraft:dark_prismarine
fill 181 283 344 182 285 344 minecraft:blue_terracotta
setblock 181 283 348 minecraft:dark_prismarine
fill 181 283 349 181 283 352 minecraft:blue_terracotta
fill 181 283 353 181 283 356 minecraft:dark_prismarine
setblock 181 283 357 minecraft:blue_terracotta
setblock 181 283 358 minecraft:dark_prismarine
fill 181 283 359 182 283 361 minecraft:blue_terracotta
setblock 181 283 363 minecraft:dark_prismarine
setblock 182 283 322 minecraft:light_blue_wool
fill 182 283 323 182 283 326 minecraft:blue_terracotta
setblock 182 283 327 minecraft:dark_prismarine
fill 182 283 335 182 283 336 minecraft:blue_terracotta
setblock 182 283 337 minecraft:dark_prismarine
fill 182 283 338 182 283 341 minecraft:blue_terracotta
setblock 182 283 342 minecraft:dark_prismarine
fill 182 283 343 182 286 343 minecraft:blue_terracotta
fill 182 283 345 182 283 346 minecraft:blue_terracotta
setblock 182 283 347 minecraft:dark_prismarine
fill 182 283 348 182 283 351 minecraft:blue_terracotta
setblock 182 283 352 minecraft:dark_prismarine
fill 182 283 353 182 283 356 minecraft:blue_terracotta
setblock 182 283 357 minecraft:dark_prismarine
fill 182 283 358 182 286 358 minecraft:blue_terracotta
setblock 182 283 362 minecraft:dark_prismarine
fill 182 283 363 182 286 363 minecraft:blue_terracotta
fill 142 284 323 142 284 325 minecraft:blue_terracotta
setblock 142 284 326 minecraft:dark_prismarine
fill 142 284 327 142 284 330 minecraft:blue_terracotta
setblock 142 284 331 minecraft:dark_prismarine
fill 142 284 332 142 284 335 minecraft:blue_terracotta
setblock 142 284 336 minecraft:dark_prismarine
fill 142 284 337 142 284 340 minecraft:blue_terracotta
setblock 142 284 341 minecraft:dark_prismarine
fill 142 284 342 142 284 345 minecraft:blue_terracotta
setblock 142 284 346 minecraft:dark_prismarine
fill 142 284 347 142 284 350 minecraft:blue_terracotta
setblock 142 284 351 minecraft:dark_prismarine
fill 142 284 352 142 284 355 minecraft:blue_terracotta
setblock 142 284 356 minecraft:dark_prismarine
fill 142 284 357 142 284 360 minecraft:blue_terracotta
setblock 142 284 361 minecraft:dark_prismarine
fill 142 284 362 144 284 363 minecraft:blue_terracotta
fill 143 284 323 143 284 324 minecraft:blue_terracotta
setblock 143 284 325 minecraft:dark_prismarine
fill 143 284 326 143 284 329 minecraft:blue_terracotta
setblock 143 284 330 minecraft:dark_prismarine
fill 143 284 331 143 284 334 minecraft:blue_terracotta
setblock 143 284 335 minecraft:dark_prismarine
fill 143 284 336 143 284 339 minecraft:blue_terracotta
setblock 143 284 340 minecraft:dark_prismarine
fill 143 284 341 143 284 344 minecraft:blue_terracotta
setblock 143 284 345 minecraft:dark_prismarine
fill 143 284 346 143 284 349 minecraft:blue_terracotta
setblock 143 284 350 minecraft:dark_prismarine
fill 143 284 351 143 286 352 minecraft:blue_terracotta
fill 143 284 361 143 285 361 minecraft:blue_terracotta
setblock 144 284 323 minecraft:blue_terracotta
setblock 144 284 324 minecraft:dark_prismarine
fill 144 284 325 144 284 328 minecraft:blue_terracotta
fill 144 284 335 144 284 338 minecraft:blue_terracotta
setblock 144 284 339 minecraft:dark_prismarine
fill 144 284 340 144 284 343 minecraft:blue_terracotta
setblock 144 284 344 minecraft:dark_prismarine
fill 144 284 345 144 287 345 minecraft:blue_terracotta
setblock 144 284 349 minecraft:dark_prismarine
setblock 145 284 323 minecraft:dark_prismarine
fill 145 284 324 147 284 325 minecraft:blue_terracotta
fill 145 284 332 145 286 332 minecraft:purple_concrete
fill 145 284 334 145 286 334 minecraft:purple_concrete
fill 145 284 339 145 284 342 minecraft:blue_terracotta
setblock 145 284 343 minecraft:dark_prismarine
fill 145 284 344 145 287 344 minecraft:blue_terracotta
setblock 145 284 362 minecraft:blue_terracotta
setblock 145 284 363 minecraft:dark_prismarine
fill 146 284 323 149 284 323 minecraft:blue_terracotta
setblock 146 284 362 minecraft:dark_prismarine
fill 146 284 363 149 284 363 minecraft:blue_terracotta
setblock 148 284 324 minecraft:blue_terracotta
setblock 148 284 325 minecraft:dark_prismarine
setblock 149 284 324 minecraft:dark_prismarine
fill 149 284 325 149 287 325 minecraft:blue_terracotta
setblock 150 284 323 minecraft:dark_prismarine
fill 150 284 324 153 284 324 minecraft:blue_terracotta
fill 150 284 359 150 285 359 minecraft:dark_prismarine
setblock 150 284 363 minecraft:dark_prismarine
fill 151 284 323 154 284 323 minecraft:blue_terracotta
fill 151 284 354 151 288 356 minecraft:black_concrete
fill 151 284 358 151 285 358 minecraft:dark_prismarine
fill 151 284 360 151 285 360 minecraft:dark_prismarine
fill 151 284 363 154 284 363 minecraft:blue_terracotta
fill 152 284 353 154 288 354 minecraft:black_concrete
fill 152 284 355 154 300 357 minecraft:dark_prismarine
fill 152 284 359 152 285 359 minecraft:dark_prismarine
fill 153 284 350 153 287 350 minecraft:black_concrete
fill 153 284 352 153 288 352 minecraft:black_concrete
setblock 154 284 324 minecraft:dark_prismarine
setblock 155 284 323 minecraft:dark_prismarine
fill 155 284 324 158 284 324 minecraft:blue_terracotta
fill 155 284 353 155 288 353 minecraft:black_concrete
setblock 155 284 363 minecraft:dark_prismarine
fill 156 284 323 159 284 323 minecraft:blue_terracotta
fill 156 284 350 156 287 350 minecraft:black_concrete
fill 156 284 355 156 285 358 minecraft:black_concrete
fill 156 284 363 159 284 363 minecraft:blue_terracotta
setblock 157 284 325 minecraft:blue_terracotta
fill 157 284 354 159 285 354 minecraft:black_concrete
fill 157 284 358 157 285 358 minecraft:black_concrete
setblock 158 284 325 minecraft:dark_prismarine
fill 158 284 359 158 285 359 minecraft:black_concrete
fill 158 284 362 160 284 362 minecraft:blue_terracotta
setblock 159 284 324 minecraft:dark_prismarine
fill 159 284 325 162 284 325 minecraft:blue_terracotta
setblock 160 284 323 minecraft:dark_prismarine
fill 160 284 324 163 284 324 minecraft:blue_terracotta
fill 160 284 355 160 285 355 minecraft:black_concrete
fill 160 284 358 160 285 358 minecraft:black_concrete
setblock 160 284 363 minecraft:dark_prismarine
fill 161 284 323 164 284 323 minecraft:blue_terracotta
setblock 161 284 361 minecraft:blue_terracotta
setblock 161 284 362 minecraft:dark_prismarine
fill 161 284 363 164 284 363 minecraft:blue_terracotta
setblock 162 284 326 minecraft:dark_prismarine
setblock 162 284 361 minecraft:dark_prismarine
fill 162 284 362 165 284 362 minecraft:blue_terracotta
setblock 163 284 325 minecraft:dark_prismarine
fill 163 284 326 164 286 326 minecraft:blue_terracotta
fill 163 284 361 166 284 361 minecraft:blue_terracotta
setblock 164 284 324 minecraft:dark_prismarine
fill 164 284 325 167 284 325 minecraft:blue_terracotta
setblock 165 284 323 minecraft:dark_prismarine
fill 165 284 324 168 284 324 minecraft:blue_terracotta
setblock 165 284 363 minecraft:dark_prismarine
fill 166 284 323 169 284 323 minecraft:blue_terracotta
setblock 166 284 362 minecraft:dark_prismarine
fill 166 284 363 169 284 363 minecraft:blue_terracotta
setblock 167 284 361 minecraft:dark_prismarine
fill 167 284 362 170 284 362 minecraft:blue_terracotta
setblock 168 284 325 minecraft:dark_prismarine
fill 168 284 361 169 285 361 minecraft:blue_terracotta
setblock 169 284 324 minecraft:dark_prismarine
setblock 170 284 323 minecraft:dark_prismarine
fill 170 284 324 170 287 324 minecraft:blue_terracotta
setblock 170 284 363 minecraft:dark_prismarine
fill 171 284 323 174 284 323 minecraft:blue_terracotta
setblock 171 284 362 minecraft:dark_prismarine
fill 171 284 363 174 284 363 minecraft:blue_terracotta
fill 172 284 362 175 284 362 minecraft:blue_terracotta
setblock 175 284 323 minecraft:dark_prismarine
setblock 175 284 363 minecraft:dark_prismarine
fill 176 284 323 179 284 323 minecraft:blue_terracotta
setblock 176 284 362 minecraft:dark_prismarine
fill 176 284 363 179 284 363 minecraft:blue_terracotta
fill 177 284 362 180 284 362 minecraft:blue_terracotta
setblock 180 284 323 minecraft:dark_prismarine
fill 180 284 324 182 285 324 minecraft:blue_terracotta
fill 180 284 341 180 284 342 minecraft:blue_terracotta
setblock 180 284 343 minecraft:dark_prismarine
fill 180 284 344 180 284 347 minecraft:blue_terracotta
setblock 180 284 348 minecraft:dark_prismarine
fill 180 284 349 182 284 350 minecraft:blue_terracotta
setblock 180 284 363 minecraft:dark_prismarine
fill 181 284 323 182 286 323 minecraft:blue_terracotta
fill 181 284 325 182 284 325 minecraft:blue_terracotta
fill 181 284 338 181 284 341 minecraft:blue_terracotta
setblock 181 284 342 minecraft:dark_prismarine
fill 181 284 343 181 287 343 minecraft:blue_terracotta
fill 181 284 345 181 284 346 minecraft:blue_terracotta
setblock 181 284 347 minecraft:dark_prismarine
fill 181 284 348 182 286 348 minecraft:blue_terracotta
setblock 181 284 351 minecraft:blue_terracotta
setblock 181 284 352 minecraft:dark_prismarine
fill 181 284 353 181 284 356 minecraft:blue_terracotta
setblock 181 284 357 minecraft:dark_prismarine
fill 181 284 358 181 284 361 minecraft:blue_terracotta
setblock 181 284 362 minecraft:dark_prismarine
fill 181 284 363 181 287 363 minecraft:blue_terracotta
fill 182 284 322 182 308 322 minecraft:blue_concrete
setblock 182 284 326 minecraft:dark_prismarine
fill 182 284 327 182 284 330 minecraft:blue_terracotta
setblock 182 284 331 minecraft:dark_prismarine
fill 182 284 332 182 284 335 minecraft:blue_terracotta
setblock 182 284 336 minecraft:dark_prismarine
fill 182 284 337 182 284 340 minecraft:blue_terracotta
setblock 182 284 341 minecraft:dark_prismarine
fill 182 284 342 182 287 342 minecraft:blue_terracotta
setblock 182 284 345 minecraft:blue_terracotta
setblock 182 284 346 minecraft:dark_prismarine
fill 182 284 347 182 287 347 minecraft:blue_terracotta
setblock 182 284 351 minecraft:dark_prismarine
fill 182 284 352 182 284 355 minecraft:blue_terracotta
setblock 182 284 356 minecraft:dark_prismarine
fill 182 284 357 182 285 357 minecraft:blue_terracotta
fill 182 284 359 182 284 360 minecraft:blue_terracotta
setblock 182 284 361 minecraft:dark_prismarine
fill 182 284 362 182 287 362 minecraft:blue_terracotta
fill 142 285 323 142 285 324 minecraft:blue_terracotta
setblock 142 285 325 minecraft:dark_prismarine
fill 142 285 326 142 285 329 minecraft:blue_terracotta
setblock 142 285 330 minecraft:dark_prismarine
fill 142 285 331 142 285 334 minecraft:blue_terracotta
setblock 142 285 335 minecraft:dark_prismarine
fill 142 285 336 142 285 339 minecraft:blue_terracotta
setblock 142 285 340 minecraft:dark_prismarine
fill 142 285 341 142 285 344 minecraft:blue_terracotta
setblock 142 285 345 minecraft:dark_prismarine
fill 142 285 346 142 285 349 minecraft:blue_terracotta
setblock 142 285 350 minecraft:dark_prismarine
fill 142 285 351 142 285 354 minecraft:blue_terracotta
setblock 142 285 355 minecraft:dark_prismarine
fill 142 285 356 142 285 359 minecraft:blue_terracotta
setblock 142 285 360 minecraft:dark_prismarine
fill 142 285 361 142 286 363 minecraft:blue_terracotta
setblock 143 285 323 minecraft:blue_terracotta
setblock 143 285 324 minecraft:dark_prismarine
fill 143 285 325 143 285 328 minecraft:blue_terracotta
setblock 143 285 329 minecraft:dark_prismarine
fill 143 285 330 143 285 333 minecraft:blue_terracotta
setblock 143 285 334 minecraft:dark_prismarine
fill 143 285 335 143 285 338 minecraft:blue_terracotta
setblock 143 285 339 minecraft:dark_prismarine
fill 143 285 340 143 285 343 minecraft:blue_terracotta
setblock 143 285 344 minecraft:dark_prismarine
fill 143 285 345 143 285 348 minecraft:blue_terracotta
setblock 143 285 349 minecraft:dark_prismarine
fill 143 285 350 144 287 350 minecraft:blue_terracotta
setblock 143 285 353 minecraft:blue_terracotta
fill 143 285 362 143 285 363 minecraft:blue_terracotta
setblock 144 285 323 minecraft:dark_prismarine
fill 144 285 324 144 285 327 minecraft:blue_terracotta
setblock 144 285 328 minecraft:dark_prismarine
fill 144 285 329 144 286 331 minecraft:blue_terracotta
fill 144 285 335 144 285 337 minecraft:blue_terracotta
setblock 144 285 338 minecraft:dark_prismarine
fill 144 285 339 144 285 342 minecraft:blue_terracotta
setblock 144 285 343 minecraft:dark_prismarine
fill 144 285 344 144 288 344 minecraft:blue_terracotta
fill 144 285 346 144 285 347 minecraft:blue_terracotta
setblock 144 285 348 minecraft:dark_prismarine
fill 144 285 349 144 288 349 minecraft:blue_terracotta
setblock 144 285 357 minecraft:light[level=13]
setblock 144 285 362 minecraft:blue_terracotta
setblock 144 285 363 minecraft:dark_prismarine
fill 145 285 323 146 285 325 minecraft:blue_terracotta
fill 145 285 340 145 285 341 minecraft:blue_terracotta
setblock 145 285 342 minecraft:dark_prismarine
fill 145 285 343 145 287 343 minecraft:blue_terracotta
setblock 145 285 347 minecraft:dark_prismarine
setblock 145 285 362 minecraft:dark_prismarine
fill 145 285 363 148 285 363 minecraft:blue_terracotta
fill 146 285 333 146 286 333 minecraft:purple_concrete
setblock 146 285 362 minecraft:blue_terracotta
fill 147 285 323 147 285 324 minecraft:blue_terracotta
setblock 147 285 325 minecraft:dark_prismarine
setblock 148 285 323 minecraft:blue_terracotta
setblock 148 285 324 minecraft:dark_prismarine
fill 148 285 325 148 288 325 minecraft:blue_terracotta
setblock 149 285 323 minecraft:dark_prismarine
fill 149 285 324 152 285 324 minecraft:blue_terracotta
setblock 149 285 363 minecraft:dark_prismarine
fill 150 285 323 153 285 323 minecraft:blue_terracotta
fill 150 285 325 150 286 325 minecraft:blue_terracotta
fill 150 285 354 150 288 356 minecraft:black_concrete
fill 150 285 363 153 285 363 minecraft:blue_terracotta
fill 151 285 353 151 288 353 minecraft:black_concrete
fill 151 285 357 151 288 357 minecraft:black_concrete
setblock 152 285 325 minecraft:light[level=13]
setblock 152 285 333 minecraft:light[level=13]
setblock 152 285 341 minecraft:light[level=13]
setblock 152 285 349 minecraft:light[level=13]
fill 152 285 351 152 288 351 minecraft:black_concrete
fill 152 285 358 154 286 358 minecraft:black_concrete
setblock 153 285 324 minecraft:dark_prismarine
setblock 154 285 323 minecraft:dark_prismarine
fill 154 285 324 157 285 324 minecraft:blue_terracotta
fill 154 285 349 155 287 349 minecraft:black_concrete
setblock 154 285 363 minecraft:dark_prismarine
fill 155 285 323 158 285 323 minecraft:blue_terracotta
fill 155 285 325 156 285 325 minecraft:blue_terracotta
fill 155 285 355 155 288 356 minecraft:black_concrete
fill 155 285 363 158 285 363 minecraft:blue_terracotta
fill 156 285 353 156 285 354 minecraft:black_concrete
fill 156 285 359 157 285 359 minecraft:black_concrete
setblock 157 285 325 minecraft:dark_prismarine
fill 157 285 351 157 287 353 minecraft:black_concrete
setblock 158 285 324 minecraft:dark_prismarine
fill 158 285 325 161 285 325 minecraft:blue_terracotta
fill 158 285 353 159 285 353 minecraft:black_concrete
fill 158 285 362 159 285 362 minecraft:blue_terracotta
setblock 159 285 323 minecraft:dark_prismarine
fill 159 285 324 162 285 324 minecraft:blue_terracotta
fill 159 285 359 160 285 359 minecraft:black_concrete
setblock 159 285 363 minecraft:dark_prismarine
fill 160 285 323 163 285 323 minecraft:blue_terracotta
setblock 160 285 326 minecraft:blue_terracotta
setblock 160 285 333 minecraft:light[level=13]
setblock 160 285 341 minecraft:light[level=13]
setblock 160 285 349 minecraft:light[level=13]
setblock 160 285 354 minecraft:black_concrete
setblock 160 285 362 minecraft:dark_prismarine
fill 160 285 363 163 285 363 minecraft:blue_terracotta
setblock 161 285 326 minecraft:dark_prismarine
fill 161 285 355 161 285 358 minecraft:black_concrete
setblock 161 285 361 minecraft:dark_prismarine
fill 161 285 362 164 285 362 minecraft:blue_terracotta
setblock 162 285 325 minecraft:dark_prismarine
fill 162 285 326 162 288 326 minecraft:blue_terracotta
fill 162 285 361 165 285 361 minecraft:blue_terracotta
setblock 163 285 324 minecraft:dark_prismarine
fill 163 285 325 166 285 325 minecraft:blue_terracotta
setblock 164 285 323 minecraft:dark_prismarine
fill 164 285 324 167 285 324 minecraft:blue_terracotta
setblock 164 285 363 minecraft:dark_prismarine
fill 165 285 323 168 285 323 minecraft:blue_terracotta
setblock 165 285 326 minecraft:blue_terracotta
setblock 165 285 362 minecraft:dark_prismarine
fill 165 285 363 168 285 363 minecraft:blue_terracotta
setblock 166 285 361 minecraft:dark_prismarine
fill 166 285 362 169 285 362 minecraft:blue_terracotta
setblock 167 285 325 minecraft:dark_prismarine
fill 167 285 361 167 286 361 minecraft:blue_terracotta
setblock 168 285 324 minecraft:dark_prismarine
fill 168 285 325 168 287 325 minecraft:blue_terracotta
setblock 168 285 333 minecraft:light[level=13]
setblock 168 285 341 minecraft:light[level=13]
setblock 168 285 349 minecraft:light[level=13]
setblock 168 285 357 minecraft:light[level=13]
setblock 169 285 323 minecraft:dark_prismarine
fill 169 285 324 169 288 324 minecraft:blue_terracotta
setblock 169 285 363 minecraft:dark_prismarine
fill 170 285 323 173 285 323 minecraft:blue_terracotta
setblock 170 285 362 minecraft:dark_prismarine
fill 170 285 363 173 285 363 minecraft:blue_terracotta
fill 171 285 362 174 285 362 minecraft:blue_terracotta
setblock 174 285 323 minecraft:dark_prismarine
setblock 174 285 363 minecraft:dark_prismarine
fill 175 285 323 178 285 323 minecraft:blue_terracotta
setblock 175 285 362 minecraft:dark_prismarine
fill 175 285 363 178 285 363 minecraft:blue_terracotta
setblock 176 285 325 minecraft:light[level=13]
setblock 176 285 333 minecraft:light[level=13]
setblock 176 285 341 minecraft:light[level=13]
setblock 176 285 349 minecraft:light[level=13]
fill 176 285 362 179 285 362 minecraft:blue_terracotta
setblock 179 285 323 minecraft:dark_prismarine
fill 179 285 324 179 288 324 minecraft:blue_terracotta
fill 179 285 346 180 285 346 minecraft:blue_terracotta
setblock 179 285 363 minecraft:dark_prismarine
fill 180 285 323 180 288 323 minecraft:blue_terracotta
setblock 180 285 341 minecraft:blue_terracotta
setblock 180 285 342 minecraft:dark_prismarine
fill 180 285 343 180 286 345 minecraft:blue_terracotta
setblock 180 285 347 minecraft:dark_prismarine
fill 180 285 348 180 285 351 minecraft:blue_terracotta
setblock 180 285 362 minecraft:dark_prismarine
fill 180 285 363 180 288 363 minecraft:blue_terracotta
setblock 181 285 325 minecraft:blue_terracotta
setblock 181 285 326 minecraft:dark_prismarine
fill 181 285 327 182 287 327 minecraft:blue_terracotta
fill 181 285 337 181 285 340 minecraft:blue_terracotta
setblock 181 285 341 minecraft:dark_prismarine
fill 181 285 342 181 288 342 minecraft:blue_terracotta
setblock 181 285 345 minecraft:blue_terracotta
setblock 181 285 346 minecraft:dark_prismarine
fill 181 285 347 181 288 347 minecraft:blue_terracotta
fill 181 285 349 181 285 350 minecraft:blue_terracotta
setblock 181 285 351 minecraft:dark_prismarine
fill 181 285 352 181 285 355 minecraft:blue_terracotta
setblock 181 285 356 minecraft:dark_prismarine
fill 181 285 357 181 285 360 minecraft:blue_terracotta
setblock 181 285 361 minecraft:dark_prismarine
setblock 181 285 362 minecraft:blue_terracotta
setblock 182 285 325 minecraft:dark_prismarine
fill 182 285 326 182 288 326 minecraft:blue_terracotta
fill 182 285 328 182 285 329 minecraft:blue_terracotta
setblock 182 285 330 minecraft:dark_prismarine
fill 182 285 331 182 285 334 minecraft:blue_terracotta
setblock 182 285 335 minecraft:dark_prismarine
fill 182 285 336 182 285 339 minecraft:blue_terracotta
setblock 182 285 340 minecraft:dark_prismarine
fill 182 285 341 182 288 341 minecraft:blue_terracotta
setblock 182 285 345 minecraft:dark_prismarine
fill 182 285 346 182 288 346 minecraft:blue_terracotta
setblock 182 285 349 minecraft:blue_terracotta
setblock 182 285 350 minecraft:dark_prismarine
fill 182 285 351 182 285 354 minecraft:blue_terracotta
setblock 182 285 355 minecraft:dark_prismarine
fill 182 285 356 182 288 356 minecraft:blue_terracotta
setblock 182 285 359 minecraft:blue_terracotta
setblock 182 285 360 minecraft:dark_prismarine
setblock 182 285 361 minecraft:blue_terracotta
setblock 142 286 323 minecraft:blue_terracotta
setblock 142 286 324 minecraft:dark_prismarine
fill 142 286 325 142 286 328 minecraft:blue_terracotta
setblock 142 286 329 minecraft:dark_prismarine
fill 142 286 330 142 286 333 minecraft:blue_terracotta
setblock 142 286 334 minecraft:dark_prismarine
fill 142 286 335 142 286 338 minecraft:blue_terracotta
setblock 142 286 339 minecraft:dark_prismarine
fill 142 286 340 142 286 343 minecraft:blue_terracotta
setblock 142 286 344 minecraft:dark_prismarine
fill 142 286 345 142 286 348 minecraft:blue_terracotta
setblock 142 286 349 minecraft:dark_prismarine
fill 142 286 350 142 286 353 minecraft:blue_terracotta
setblock 142 286 354 minecraft:dark_prismarine
fill 142 286 355 142 286 358 minecraft:blue_terracotta
setblock 142 286 359 minecraft:dark_prismarine
fill 142 286 360 142 288 360 minecraft:blue_terracotta
setblock 143 286 323 minecraft:dark_prismarine
fill 143 286 324 143 286 327 minecraft:blue_terracotta
setblock 143 286 328 minecraft:dark_prismarine
fill 143 286 329 143 286 332 minecraft:blue_terracotta
setblock 143 286 333 minecraft:dark_prismarine
fill 143 286 334 143 286 337 minecraft:blue_terracotta
setblock 143 286 338 minecraft:dark_prismarine
fill 143 286 339 143 286 342 minecraft:blue_terracotta
setblock 143 286 343 minecraft:dark_prismarine
fill 143 286 344 143 286 347 minecraft:blue_terracotta
setblock 143 286 348 minecraft:dark_prismarine
fill 143 286 349 143 289 349 minecraft:blue_terracotta
setblock 143 286 353 minecraft:dark_prismarine
setblock 143 286 362 minecraft:blue_terracotta
setblock 143 286 363 minecraft:dark_prismarine
fill 144 286 323 144 286 326 minecraft:blue_terracotta
setblock 144 286 327 minecraft:dark_prismarine
fill 144 286 328 144 289 328 minecraft:blue_terracotta
setblock 144 286 332 minecraft:dark_prismarine
fill 144 286 333 144 286 336 minecraft:blue_terracotta
setblock 144 286 337 minecraft:dark_prismarine
fill 144 286 338 144 286 341 minecraft:blue_terracotta
setblock 144 286 342 minecraft:dark_prismarine
fill 144 286 343 144 289 343 minecraft:blue_terracotta
setblock 144 286 346 minecraft:blue_terracotta
setblock 144 286 347 minecraft:dark_prismarine
fill 144 286 348 144 289 348 minecraft:blue_terracotta
setblock 144 286 362 minecraft:dark_prismarine
fill 144 286 363 147 286 363 minecraft:blue_terracotta
fill 145 286 323 145 286 325 minecraft:blue_terracotta
setblock 145 286 326 minecraft:dark_prismarine
fill 145 286 327 145 288 327 minecraft:blue_terracotta
setblock 145 286 331 minecraft:purple_concrete
setblock 145 286 335 minecraft:purple_concrete
setblock 145 286 341 minecraft:dark_prismarine
setblock 145 286 342 minecraft:blue_terracotta
setblock 145 286 345 minecraft:blue_terracotta
setblock 145 286 346 minecraft:dark_prismarine
setblock 145 286 347 minecraft:blue_terracotta
setblock 145 286 362 minecraft:blue_terracotta
fill 146 286 323 146 286 324 minecraft:blue_terracotta
setblock 146 286 325 minecraft:dark_prismarine
fill 146 286 326 146 287 326 minecraft:blue_terracotta
setblock 146 286 332 minecraft:purple_concrete
setblock 146 286 334 minecraft:purple_concrete
setblock 147 286 323 minecraft:blue_terracotta
setblock 147 286 324 minecraft:dark_prismarine
fill 147 286 325 147 289 325 minecraft:blue_terracotta
setblock 148 286 323 minecraft:dark_prismarine
fill 148 286 324 151 286 324 minecraft:blue_terracotta
setblock 148 286 363 minecraft:dark_prismarine
fill 149 286 323 152 286 323 minecraft:blue_terracotta
fill 149 286 363 152 286 363 minecraft:blue_terracotta
fill 150 286 353 150 288 353 minecraft:black_concrete
setblock 151 286 325 minecraft:dark_prismarine
fill 151 286 352 152 288 352 minecraft:black_concrete
fill 151 286 358 151 288 358 minecraft:black_concrete
setblock 152 286 324 minecraft:dark_prismarine
fill 152 286 325 155 286 325 minecraft:blue_terracotta
fill 152 286 350 152 287 350 minecraft:black_concrete
setblock 153 286 323 minecraft:dark_prismarine
fill 153 286 324 156 286 324 minecraft:blue_terracotta
fill 153 286 349 153 287 349 minecraft:black_concrete
fill 153 286 359 154 286 359 minecraft:black_concrete
setblock 153 286 363 minecraft:dark_prismarine
fill 154 286 323 157 286 323 minecraft:blue_terracotta
fill 154 286 363 157 286 363 minecraft:blue_terracotta
fill 155 286 354 155 288 354 minecraft:black_concrete
setblock 156 286 325 minecraft:dark_prismarine
fill 156 286 349 156 287 349 minecraft:black_concrete
fill 156 286 353 156 287 353 minecraft:black_concrete
fill 156 286 355 156 286 357 minecraft:black_concrete
setblock 157 286 324 minecraft:dark_prismarine
fill 157 286 325 160 286 325 minecraft:blue_terracotta
fill 157 286 350 157 287 350 minecraft:black_concrete
fill 157 286 362 158 286 362 minecraft:blue_terracotta
setblock 158 286 323 minecraft:dark_prismarine
fill 158 286 324 161 286 324 minecraft:blue_terracotta
fill 158 286 326 159 286 326 minecraft:blue_terracotta
setblock 158 286 363 minecraft:dark_prismarine
fill 159 286 323 162 286 323 minecraft:blue_terracotta
setblock 159 286 362 minecraft:dark_prismarine
fill 159 286 363 162 286 363 minecraft:blue_terracotta
setblock 160 286 326 minecraft:dark_prismarine
setblock 160 286 361 minecraft:dark_prismarine
fill 160 286 362 163 286 362 minecraft:blue_terracotta
setblock 161 286 325 minecraft:dark_prismarine
fill 161 286 326 161 289 326 minecraft:blue_terracotta
fill 161 286 361 164 286 361 minecraft:blue_terracotta
setblock 162 286 324 minecraft:dark_prismarine
fill 162 286 325 165 286 325 minecraft:blue_terracotta
setblock 163 286 323 minecraft:dark_prismarine
fill 163 286 324 166 286 324 minecraft:blue_terracotta
setblock 163 286 363 minecraft:dark_prismarine
fill 164 286 323 167 286 323 minecraft:blue_terracotta
setblock 164 286 362 minecraft:dark_prismarine
fill 164 286 363 167 286 363 minecraft:blue_terracotta
setblock 165 286 326 minecraft:dark_prismarine
setblock 165 286 361 minecraft:dark_prismarine
fill 165 286 362 168 286 362 minecraft:blue_terracotta
setblock 166 286 325 minecraft:dark_prismarine
fill 166 286 361 166 287 361 minecraft:blue_terracotta
setblock 167 286 324 minecraft:dark_prismarine
fill 167 286 325 167 288 325 minecraft:blue_terracotta
setblock 168 286 323 minecraft:dark_prismarine
fill 168 286 324 168 289 324 minecraft:blue_terracotta
setblock 168 286 361 minecraft:blue_terracotta
setblock 168 286 363 minecraft:dark_prismarine
fill 169 286 323 172 286 323 minecraft:blue_terracotta
setblock 169 286 362 minecraft:dark_prismarine
fill 169 286 363 172 286 363 minecraft:blue_terracotta
fill 170 286 359 170 297 359 minecraft:magenta_terracotta
fill 170 286 362 172 286 362 minecraft:blue_terracotta
setblock 173 286 323 minecraft:dark_prismarine
setblock 173 286 352 minecraft:sea_lantern
fill 173 286 353 173 300 353 minecraft:dark_prismarine
setblock 173 286 354 minecraft:sea_lantern
fill 173 286 355 173 300 355 minecraft:dark_prismarine
setblock 173 286 356 minecraft:sea_lantern
fill 173 286 357 173 300 357 minecraft:dark_prismarine
setblock 173 286 358 minecraft:sea_lantern
fill 173 286 359 173 300 359 minecraft:dark_prismarine
setblock 173 286 360 minecraft:sea_lantern
fill 173 286 361 173 300 361 minecraft:dark_prismarine
setblock 173 286 362 minecraft:sea_lantern
setblock 173 286 363 minecraft:dark_prismarine
fill 174 286 323 177 286 323 minecraft:blue_terracotta
fill 174 286 352 174 300 352 minecraft:dark_prismarine
setblock 174 286 353 minecraft:sea_lantern
fill 174 286 354 174 300 354 minecraft:dark_prismarine
setblock 174 286 355 minecraft:sea_lantern
fill 174 286 356 174 300 356 minecraft:dark_prismarine
setblock 174 286 357 minecraft:sea_lantern
fill 174 286 358 174 300 358 minecraft:dark_prismarine
setblock 174 286 359 minecraft:sea_lantern
fill 174 286 360 174 300 360 minecraft:dark_prismarine
setblock 174 286 361 minecraft:sea_lantern
fill 174 286 362 174 299 362 minecraft:dark_prismarine
fill 174 286 363 177 286 363 minecraft:blue_terracotta
setblock 175 286 352 minecraft:sea_lantern
fill 175 286 353 175 300 353 minecraft:dark_prismarine
setblock 175 286 354 minecraft:sea_lantern
fill 175 286 355 175 300 355 minecraft:dark_prismarine
setblock 175 286 356 minecraft:sea_lantern
fill 175 286 357 175 300 357 minecraft:dark_prismarine
setblock 175 286 358 minecraft:sea_lantern
fill 175 286 359 175 300 359 minecraft:dark_prismarine
setblock 175 286 360 minecraft:sea_lantern
fill 175 286 361 175 300 361 minecraft:dark_prismarine
setblock 175 286 362 minecraft:sea_lantern
fill 176 286 352 176 300 352 minecraft:dark_prismarine
setblock 176 286 353 minecraft:sea_lantern
fill 176 286 354 176 300 354 minecraft:dark_prismarine
setblock 176 286 355 minecraft:sea_lantern
fill 176 286 356 176 300 356 minecraft:dark_prismarine
setblock 176 286 357 minecraft:sea_lantern
fill 176 286 358 176 300 358 minecraft:dark_prismarine
setblock 176 286 359 minecraft:sea_lantern
fill 176 286 360 176 300 360 minecraft:dark_prismarine
setblock 176 286 361 minecraft:sea_lantern
setblock 176 286 362 minecraft:blue_terracotta
setblock 177 286 352 minecraft:sea_lantern
fill 177 286 353 177 300 353 minecraft:dark_prismarine
setblock 177 286 354 minecraft:sea_lantern
fill 177 286 355 177 300 355 minecraft:dark_prismarine
setblock 177 286 356 minecraft:sea_lantern
fill 177 286 357 177 300 357 minecraft:dark_prismarine
setblock 177 286 358 minecraft:sea_lantern
fill 177 286 359 177 300 359 minecraft:dark_prismarine
setblock 177 286 360 minecraft:sea_lantern
fill 177 286 361 177 300 361 minecraft:dark_prismarine
setblock 177 286 362 minecraft:sea_lantern
setblock 178 286 323 minecraft:dark_prismarine
fill 178 286 324 178 289 324 minecraft:blue_terracotta
fill 178 286 352 178 300 352 minecraft:dark_prismarine
setblock 178 286 353 minecraft:sea_lantern
fill 178 286 354 178 300 354 minecraft:dark_prismarine
setblock 178 286 355 minecraft:sea_lantern
fill 178 286 356 178 300 356 minecraft:dark_prismarine
setblock 178 286 357 minecraft:sea_lantern
fill 178 286 358 178 300 358 minecraft:dark_prismarine
setblock 178 286 359 minecraft:sea_lantern
fill 178 286 360 178 300 360 minecraft:dark_prismarine
setblock 178 286 361 minecraft:sea_lantern
setblock 178 286 362 minecraft:blue_terracotta
setblock 178 286 363 minecraft:dark_prismarine
fill 179 286 323 179 289 323 minecraft:blue_terracotta
fill 179 286 344 179 286 346 minecraft:blue_terracotta
setblock 179 286 347 minecraft:dark_prismarine
fill 179 286 348 180 287 349 minecraft:blue_terracotta
setblock 179 286 352 minecraft:sea_lantern
fill 179 286 353 179 300 353 minecraft:dark_prismarine
setblock 179 286 354 minecraft:sea_lantern
fill 179 286 355 179 300 355 minecraft:dark_prismarine
setblock 179 286 356 minecraft:sea_lantern
fill 179 286 357 179 300 357 minecraft:dark_prismarine
setblock 179 286 358 minecraft:sea_lantern
fill 179 286 359 179 300 359 minecraft:dark_prismarine
setblock 179 286 360 minecraft:sea_lantern
fill 179 286 361 179 300 361 minecraft:dark_prismarine
setblock 179 286 362 minecraft:sea_lantern
fill 179 286 363 179 289 363 minecraft:blue_terracotta
fill 180 286 324 181 286 324 minecraft:blue_terracotta
setblock 180 286 340 minecraft:blue_terracotta
setblock 180 286 341 minecraft:dark_prismarine
fill 180 286 342 180 289 342 minecraft:blue_terracotta
setblock 180 286 346 minecraft:dark_prismarine
fill 180 286 347 180 289 347 minecraft:blue_terracotta
setblock 180 286 350 minecraft:blue_terracotta
setblock 180 286 351 minecraft:dark_prismarine
fill 180 286 352 180 289 352 minecraft:blue_terracotta
setblock 180 286 353 minecraft:sea_lantern
setblock 180 286 354 minecraft:dark_prismarine
setblock 180 286 355 minecraft:sea_lantern
fill 180 286 356 180 300 356 minecraft:dark_prismarine
setblock 180 286 357 minecraft:sea_lantern
fill 180 286 358 180 300 358 minecraft:dark_prismarine
setblock 180 286 359 minecraft:sea_lantern
fill 180 286 360 180 300 360 minecraft:dark_prismarine
setblock 180 286 361 minecraft:sea_lantern
fill 180 286 362 180 288 362 minecraft:blue_terracotta
setblock 181 286 325 minecraft:dark_prismarine
fill 181 286 326 181 289 326 minecraft:blue_terracotta
fill 181 286 328 181 286 329 minecraft:blue_terracotta
fill 181 286 337 181 286 339 minecraft:blue_terracotta
setblock 181 286 340 minecraft:dark_prismarine
fill 181 286 341 181 289 341 minecraft:blue_terracotta
setblock 181 286 344 minecraft:blue_terracotta
setblock 181 286 345 minecraft:dark_prismarine
fill 181 286 346 181 289 346 minecraft:blue_terracotta
setblock 181 286 349 minecraft:blue_terracotta
setblock 181 286 350 minecraft:dark_prismarine
fill 181 286 351 182 288 351 minecraft:blue_terracotta
setblock 181 286 352 minecraft:sea_lantern
fill 181 286 353 181 287 353 minecraft:blue_terracotta
setblock 181 286 354 minecraft:sea_lantern
setblock 181 286 355 minecraft:dark_prismarine
setblock 181 286 356 minecraft:sea_lantern
fill 181 286 357 181 288 357 minecraft:blue_terracotta
setblock 181 286 358 minecraft:sea_lantern
setblock 181 286 359 minecraft:blue_terracotta
setblock 181 286 360 minecraft:sea_lantern
fill 181 286 361 181 288 361 minecraft:blue_terracotta
setblock 181 286 362 minecraft:sea_lantern
setblock 182 286 324 minecraft:dark_prismarine
fill 182 286 325 182 289 325 minecraft:blue_terracotta
setblock 182 286 328 minecraft:blue_terracotta
setblock 182 286 329 minecraft:dark_prismarine
fill 182 286 330 182 286 333 minecraft:blue_terracotta
setblock 182 286 334 minecraft:dark_prismarine
fill 182 286 335 182 286 338 minecraft:blue_terracotta
setblock 182 286 339 minecraft:dark_prismarine
fill 182 286 340 182 289 340 minecraft:blue_terracotta
setblock 182 286 344 minecraft:dark_prismarine
fill 182 286 345 182 289 345 minecraft:blue_terracotta
setblock 182 286 349 minecraft:dark_prismarine
fill 182 286 350 182 289 350 minecraft:blue_terracotta
fill 182 286 352 182 287 352 minecraft:blue_terracotta
setblock 182 286 353 minecraft:sea_lantern
setblock 182 286 354 minecraft:dark_prismarine
setblock 182 286 355 minecraft:sea_lantern
setblock 182 286 357 minecraft:sea_lantern
setblock 182 286 359 minecraft:sea_lantern
fill 182 286 360 182 289 360 minecraft:blue_terracotta
setblock 182 286 361 minecraft:sea_lantern
fill 183 286 348 183 308 349 minecraft:blue_concrete
setblock 183 286 350 minecraft:light_blue_wool
setblock 142 287 323 minecraft:dark_prismarine
fill 142 287 324 142 287 327 minecraft:blue_terracotta
setblock 142 287 328 minecraft:dark_prismarine
fill 142 287 329 142 287 332 minecraft:blue_terracotta
setblock 142 287 333 minecraft:dark_prismarine
fill 142 287 334 142 287 337 minecraft:blue_terracotta
setblock 142 287 338 minecraft:dark_prismarine
fill 142 287 339 142 287 342 minecraft:blue_terracotta
setblock 142 287 343 minecraft:dark_prismarine
fill 142 287 344 142 287 347 minecraft:blue_terracotta
setblock 142 287 348 minecraft:dark_prismarine
fill 142 287 349 142 287 352 minecraft:blue_terracotta
setblock 142 287 353 minecraft:dark_prismarine
fill 142 287 354 142 287 357 minecraft:blue_terracotta
setblock 142 287 358 minecraft:dark_prismarine
fill 142 287 359 142 288 359 minecraft:blue_terracotta
fill 142 287 361 142 287 362 minecraft:blue_terracotta
setblock 142 287 363 minecraft:dark_prismarine
fill 143 287 323 143 287 326 minecraft:blue_terracotta
setblock 143 287 327 minecraft:dark_prismarine
fill 143 287 328 143 287 331 minecraft:blue_terracotta
setblock 143 287 332 minecraft:dark_prismarine
fill 143 287 333 143 287 336 minecraft:blue_terracotta
setblock 143 287 337 minecraft:dark_prismarine
fill 143 287 338 143 287 341 minecraft:blue_terracotta
setblock 143 287 342 minecraft:dark_prismarine
fill 143 287 343 143 287 346 minecraft:blue_terracotta
setblock 143 287 347 minecraft:dark_prismarine
fill 143 287 348 143 290 348 minecraft:blue_terracotta
setblock 143 287 351 minecraft:blue_terracotta
setblock 143 287 352 minecraft:dark_prismarine
fill 143 287 353 143 289 353 minecraft:blue_terracotta
fill 143 287 363 146 287 363 minecraft:blue_terracotta
fill 144 287 323 144 287 325 minecraft:blue_terracotta
setblock 144 287 326 minecraft:dark_prismarine
fill 144 287 327 144 290 327 minecraft:blue_terracotta
fill 144 287 329 144 287 330 minecraft:blue_terracotta
fill 144 287 331 147 287 331 minecraft:dark_prismarine
fill 144 287 332 144 287 335 minecraft:blue_terracotta
fill 144 287 336 147 288 336 minecraft:dark_prismarine
fill 144 287 337 144 287 340 minecraft:blue_terracotta
setblock 144 287 341 minecraft:dark_prismarine
fill 144 287 342 144 289 342 minecraft:blue_terracotta
setblock 144 287 346 minecraft:dark_prismarine
fill 144 287 347 144 290 347 minecraft:blue_terracotta
setblock 144 287 353 minecraft:light[level=12]
setblock 144 287 360 minecraft:light[level=12]
fill 145 287 323 145 287 324 minecraft:blue_terracotta
setblock 145 287 325 minecraft:dark_prismarine
fill 145 287 326 145 288 326 minecraft:blue_terracotta
fill 145 287 328 145 288 328 minecraft:blue_terracotta
fill 145 287 330 147 288 330 minecraft:dark_prismarine
fill 145 287 332 147 288 335 minecraft:dark_prismarine
setblock 145 287 345 minecraft:dark_prismarine
setblock 145 287 346 minecraft:blue_terracotta
setblock 146 287 323 minecraft:blue_terracotta
setblock 146 287 324 minecraft:dark_prismarine
fill 146 287 325 146 290 325 minecraft:blue_terracotta
setblock 147 287 323 minecraft:dark_prismarine
fill 147 287 324 150 287 324 minecraft:blue_terracotta
setblock 147 287 363 minecraft:dark_prismarine
fill 148 287 323 151 287 323 minecraft:blue_terracotta
fill 148 287 342 148 297 342 minecraft:magenta_terracotta
fill 148 287 363 149 287 363 minecraft:blue_terracotta
fill 149 287 354 149 288 356 minecraft:black_concrete
setblock 150 287 325 minecraft:dark_prismarine
fill 150 287 357 150 288 357 minecraft:black_concrete
setblock 151 287 324 minecraft:dark_prismarine
fill 151 287 325 154 287 325 minecraft:blue_terracotta
setblock 151 287 332 minecraft:light[level=12]
setblock 151 287 339 minecraft:light[level=12]
setblock 151 287 346 minecraft:light[level=12]
setblock 151 287 360 minecraft:light[level=12]
setblock 152 287 323 minecraft:dark_prismarine
fill 152 287 324 155 287 324 minecraft:blue_terracotta
setblock 152 287 349 minecraft:black_concrete
fill 152 287 358 153 288 358 minecraft:black_concrete
setblock 152 287 363 minecraft:purple_concrete
fill 153 287 323 156 287 323 minecraft:blue_terracotta
fill 153 287 363 156 287 363 minecraft:blue_terracotta
fill 154 287 348 155 287 348 minecraft:black_concrete
setblock 155 287 325 minecraft:dark_prismarine
setblock 156 287 324 minecraft:dark_prismarine
fill 156 287 325 159 287 325 minecraft:blue_terracotta
setblock 156 287 354 minecraft:black_concrete
setblock 157 287 323 minecraft:dark_prismarine
fill 157 287 324 160 287 324 minecraft:blue_terracotta
fill 157 287 326 158 287 326 minecraft:blue_terracotta
setblock 157 287 349 minecraft:black_concrete
setblock 157 287 362 minecraft:blue_terracotta
setblock 157 287 363 minecraft:dark_prismarine
fill 158 287 323 161 287 323 minecraft:blue_terracotta
setblock 158 287 332 minecraft:light[level=12]
setblock 158 287 339 minecraft:light[level=12]
setblock 158 287 346 minecraft:light[level=12]
setblock 158 287 351 minecraft:black_concrete
setblock 158 287 353 minecraft:light[level=12]
setblock 158 287 360 minecraft:light[level=12]
setblock 158 287 362 minecraft:dark_prismarine
fill 158 287 363 161 287 363 minecraft:blue_terracotta
setblock 159 287 326 minecraft:dark_prismarine
fill 159 287 362 162 287 362 minecraft:blue_terracotta
setblock 160 287 325 minecraft:dark_prismarine
fill 160 287 326 160 290 326 minecraft:blue_terracotta
fill 160 287 361 163 287 361 minecraft:blue_terracotta
setblock 161 287 324 minecraft:dark_prismarine
fill 161 287 325 164 287 325 minecraft:blue_terracotta
setblock 162 287 323 minecraft:dark_prismarine
fill 162 287 324 165 287 324 minecraft:blue_terracotta
setblock 162 287 363 minecraft:dark_prismarine
fill 163 287 323 166 287 323 minecraft:blue_terracotta
setblock 163 287 326 minecraft:blue_terracotta
setblock 163 287 362 minecraft:dark_prismarine
fill 163 287 363 166 287 363 minecraft:blue_terracotta
setblock 164 287 326 minecraft:dark_prismarine
setblock 164 287 361 minecraft:dark_prismarine
fill 164 287 362 167 287 362 minecraft:blue_terracotta
setblock 165 287 325 minecraft:dark_prismarine
setblock 165 287 326 minecraft:blue_terracotta
setblock 165 287 332 minecraft:light[level=12]
setblock 165 287 339 minecraft:light[level=12]
setblock 165 287 346 minecraft:light[level=12]
setblock 165 287 353 minecraft:light[level=12]
setblock 165 287 360 minecraft:light[level=12]
fill 165 287 361 165 288 361 minecraft:blue_terracotta
setblock 166 287 324 minecraft:dark_prismarine
fill 166 287 325 166 289 325 minecraft:blue_terracotta
setblock 167 287 323 minecraft:dark_prismarine
fill 167 287 324 167 289 324 minecraft:blue_terracotta
setblock 167 287 363 minecraft:dark_prismarine
fill 168 287 323 171 287 323 minecraft:blue_terracotta
setblock 168 287 362 minecraft:dark_prismarine
fill 168 287 363 171 287 363 minecraft:blue_terracotta
fill 169 287 362 170 287 362 minecraft:blue_terracotta
setblock 172 287 323 minecraft:dark_prismarine
setblock 172 287 325 minecraft:light[level=12]
setblock 172 287 332 minecraft:light[level=12]
setblock 172 287 339 minecraft:light[level=12]
setblock 172 287 346 minecraft:light[level=12]
setblock 172 287 353 minecraft:light[level=12]
setblock 172 287 360 minecraft:light[level=12]
setblock 172 287 363 minecraft:dark_prismarine
fill 173 287 323 176 287 323 minecraft:blue_terracotta
fill 173 287 352 173 288 352 minecraft:dark_prismarine
fill 173 287 354 173 288 354 minecraft:dark_prismarine
fill 173 287 356 173 288 356 minecraft:dark_prismarine
fill 173 287 358 173 288 358 minecraft:dark_prismarine
fill 173 287 360 173 288 360 minecraft:dark_prismarine
fill 173 287 362 173 288 362 minecraft:dark_prismarine
fill 173 287 363 176 287 363 minecraft:blue_terracotta
fill 174 287 353 174 288 353 minecraft:dark_prismarine
fill 174 287 355 174 288 355 minecraft:dark_prismarine
fill 174 287 357 174 288 357 minecraft:dark_prismarine
fill 174 287 359 174 288 359 minecraft:dark_prismarine
fill 174 287 361 174 288 361 minecraft:dark_prismarine
fill 175 287 352 175 288 352 minecraft:dark_prismarine
fill 175 287 354 175 288 354 minecraft:dark_prismarine
fill 175 287 356 175 288 356 minecraft:dark_prismarine
fill 175 287 358 175 288 358 minecraft:dark_prismarine
fill 175 287 360 175 288 360 minecraft:dark_prismarine
fill 175 287 362 176 288 362 minecraft:dark_prismarine
fill 176 287 353 176 288 353 minecraft:dark_prismarine
fill 176 287 355 176 288 355 minecraft:dark_prismarine
fill 176 287 357 176 288 357 minecraft:dark_prismarine
fill 176 287 359 176 288 359 minecraft:dark_prismarine
fill 176 287 361 176 288 361 minecraft:dark_prismarine
setblock 177 287 323 minecraft:dark_prismarine
setblock 177 287 324 minecraft:blue_terracotta
fill 177 287 352 177 288 352 minecraft:dark_prismarine
fill 177 287 354 177 288 354 minecraft:dark_prismarine
fill 177 287 356 177 288 356 minecraft:dark_prismarine
fill 177 287 358 177 288 358 minecraft:dark_prismarine
fill 177 287 360 177 288 360 minecraft:dark_prismarine
setblock 177 287 362 minecraft:blue_terracotta
setblock 177 287 363 minecraft:dark_prismarine
fill 178 287 323 178 290 323 minecraft:blue_terracotta
fill 178 287 353 178 288 353 minecraft:dark_prismarine
fill 178 287 355 178 288 355 minecraft:dark_prismarine
fill 178 287 357 178 288 357 minecraft:dark_prismarine
fill 178 287 359 178 288 359 minecraft:dark_prismarine
fill 178 287 361 178 288 362 minecraft:dark_prismarine
fill 178 287 363 178 290 363 minecraft:blue_terracotta
setblock 179 287 325 minecraft:light[level=12]
setblock 179 287 332 minecraft:light[level=12]
setblock 179 287 339 minecraft:light[level=12]
fill 179 287 344 179 287 345 minecraft:blue_terracotta
setblock 179 287 346 minecraft:dark_prismarine
fill 179 287 347 179 290 347 minecraft:blue_terracotta
setblock 179 287 350 minecraft:blue_terracotta
fill 179 287 352 179 288 352 minecraft:dark_prismarine
fill 179 287 354 179 288 354 minecraft:dark_prismarine
fill 179 287 356 179 288 356 minecraft:dark_prismarine
fill 179 287 358 179 288 358 minecraft:dark_prismarine
fill 179 287 360 179 288 360 minecraft:dark_prismarine
fill 179 287 362 179 288 362 minecraft:blue_terracotta
setblock 180 287 324 minecraft:blue_terracotta
setblock 180 287 340 minecraft:dark_prismarine
fill 180 287 341 180 289 341 minecraft:blue_terracotta
fill 180 287 343 180 287 344 minecraft:blue_terracotta
setblock 180 287 345 minecraft:dark_prismarine
fill 180 287 346 180 290 346 minecraft:blue_terracotta
setblock 180 287 350 minecraft:dark_prismarine
fill 180 287 351 180 290 351 minecraft:blue_terracotta
fill 180 287 353 180 287 354 minecraft:blue_terracotta
fill 180 287 355 180 288 355 minecraft:dark_prismarine
fill 180 287 357 180 288 357 minecraft:dark_prismarine
fill 180 287 359 181 287 359 minecraft:dark_prismarine
fill 180 287 361 180 288 361 minecraft:dark_prismarine
setblock 181 287 323 minecraft:blue_terracotta
setblock 181 287 324 minecraft:dark_prismarine
fill 181 287 325 181 290 325 minecraft:blue_terracotta
setblock 181 287 328 minecraft:blue_terracotta
setblock 181 287 329 minecraft:dark_prismarine
fill 181 287 330 182 288 331 minecraft:blue_terracotta
fill 181 287 336 181 287 338 minecraft:blue_terracotta
setblock 181 287 339 minecraft:dark_prismarine
fill 181 287 340 181 290 340 minecraft:blue_terracotta
setblock 181 287 344 minecraft:dark_prismarine
fill 181 287 345 181 290 345 minecraft:blue_terracotta
setblock 181 287 348 minecraft:blue_terracotta
setblock 181 287 349 minecraft:dark_prismarine
fill 181 287 350 181 290 350 minecraft:blue_terracotta
fill 181 287 352 181 288 352 minecraft:blue_terracotta
setblock 181 287 354 minecraft:dark_prismarine
fill 181 287 355 181 288 356 minecraft:blue_terracotta
setblock 181 287 358 minecraft:blue_terracotta
fill 181 287 360 181 288 360 minecraft:blue_terracotta
fill 181 287 362 181 288 362 minecraft:blue_terracotta
setblock 182 287 323 minecraft:dark_prismarine
fill 182 287 324 182 290 324 minecraft:blue_terracotta
setblock 182 287 328 minecraft:dark_prismarine
fill 182 287 329 182 290 329 minecraft:blue_terracotta
setblock 182 287 332 minecraft:blue_terracotta
setblock 182 287 333 minecraft:dark_prismarine
fill 182 287 334 182 287 337 minecraft:blue_terracotta
setblock 182 287 338 minecraft:dark_prismarine
fill 182 287 339 182 290 339 minecraft:blue_terracotta
setblock 182 287 343 minecraft:dark_prismarine
fill 182 287 344 182 290 344 minecraft:blue_terracotta
setblock 182 287 348 minecraft:dark_prismarine
fill 182 287 349 182 290 349 minecraft:blue_terracotta
setblock 182 287 353 minecraft:dark_prismarine
fill 182 287 354 182 288 355 minecraft:blue_terracotta
setblock 182 287 357 minecraft:blue_terracotta
setblock 182 287 358 minecraft:dark_prismarine
fill 182 287 359 182 288 359 minecraft:blue_terracotta
fill 182 287 361 182 288 361 minecraft:blue_terracotta
setblock 182 287 363 minecraft:dark_prismarine
fill 183 287 350 183 308 350 minecraft:blue_concrete
setblock 141 288 339 minecraft:cyan_concrete
fill 141 288 340 141 308 342 minecraft:blue_concrete
fill 142 288 323 142 288 326 minecraft:blue_terracotta
setblock 142 288 327 minecraft:dark_prismarine
fill 142 288 328 142 288 331 minecraft:blue_terracotta
setblock 142 288 332 minecraft:dark_prismarine
fill 142 288 333 142 288 336 minecraft:blue_terracotta
setblock 142 288 337 minecraft:dark_prismarine
fill 142 288 338 142 288 341 minecraft:blue_terracotta
setblock 142 288 342 minecraft:dark_prismarine
fill 142 288 343 142 288 346 minecraft:blue_terracotta
setblock 142 288 347 minecraft:dark_prismarine
fill 142 288 348 142 288 351 minecraft:blue_terracotta
setblock 142 288 352 minecraft:dark_prismarine
fill 142 288 353 142 288 356 minecraft:blue_terracotta
setblock 142 288 357 minecraft:dark_prismarine
setblock 142 288 358 minecraft:blue_terracotta
setblock 142 288 361 minecraft:blue_terracotta
setblock 142 288 362 minecraft:dark_prismarine
fill 142 288 363 145 288 363 minecraft:blue_terracotta
fill 143 288 323 143 288 325 minecraft:blue_terracotta
setblock 143 288 326 minecraft:dark_prismarine
fill 143 288 327 143 288 330 minecraft:blue_terracotta
setblock 143 288 331 minecraft:dark_prismarine
fill 143 288 332 143 288 335 minecraft:blue_terracotta
setblock 143 288 336 minecraft:dark_prismarine
fill 143 288 337 143 288 340 minecraft:blue_terracotta
setblock 143 288 341 minecraft:dark_prismarine
fill 143 288 342 143 288 345 minecraft:blue_terracotta
setblock 143 288 346 minecraft:dark_prismarine
fill 143 288 347 143 291 347 minecraft:blue_terracotta
setblock 143 288 350 minecraft:blue_terracotta
setblock 143 288 351 minecraft:dark_prismarine
fill 143 288 352 143 291 352 minecraft:blue_terracotta
fill 144 288 323 144 288 324 minecraft:blue_terracotta
setblock 144 288 325 minecraft:dark_prismarine
fill 144 288 326 144 291 326 minecraft:blue_terracotta
setblock 144 288 329 minecraft:blue_terracotta
setblock 144 288 330 minecraft:dark_prismarine
fill 144 288 331 144 288 334 minecraft:blue_terracotta
setblock 144 288 335 minecraft:dark_prismarine
setblock 144 288 339 minecraft:blue_terracotta
setblock 144 288 340 minecraft:dark_prismarine
setblock 144 288 341 minecraft:blue_terracotta
setblock 144 288 345 minecraft:dark_prismarine
fill 144 288 346 144 290 346 minecraft:blue_terracotta
setblock 144 288 350 minecraft:dark_prismarine
setblock 145 288 323 minecraft:blue_terracotta
setblock 145 288 324 minecraft:dark_prismarine
fill 145 288 325 145 290 325 minecraft:blue_terracotta
fill 145 288 331 147 288 331 minecraft:dark_prismarine
setblock 146 288 323 minecraft:dark_prismarine
fill 146 288 324 149 288 324 minecraft:blue_terracotta
setblock 146 288 363 minecraft:dark_prismarine
fill 147 288 323 150 288 323 minecraft:blue_terracotta
fill 147 288 342 147 295 342 minecraft:magenta_terracotta
setblock 147 288 363 minecraft:blue_terracotta
setblock 149 288 325 minecraft:dark_prismarine
setblock 149 288 353 minecraft:black_concrete
setblock 149 288 357 minecraft:black_concrete
setblock 150 288 324 minecraft:dark_prismarine
fill 150 288 325 153 288 325 minecraft:blue_terracotta
setblock 150 288 352 minecraft:black_concrete
setblock 150 288 358 minecraft:black_concrete
setblock 151 288 323 minecraft:dark_prismarine
fill 151 288 324 154 288 324 minecraft:blue_terracotta
fill 152 288 323 155 288 323 minecraft:blue_terracotta
setblock 153 288 351 minecraft:black_concrete
setblock 154 288 325 minecraft:dark_prismarine
fill 154 288 350 154 289 350 minecraft:dark_prismarine
setblock 154 288 352 minecraft:black_concrete
setblock 154 288 358 minecraft:black_concrete
fill 154 288 363 155 288 363 minecraft:blue_terracotta
setblock 155 288 324 minecraft:dark_prismarine
fill 155 288 325 158 288 325 minecraft:blue_terracotta
setblock 156 288 323 minecraft:dark_prismarine
fill 156 288 324 159 288 324 minecraft:blue_terracotta
fill 156 288 352 156 290 352 minecraft:dark_prismarine
setblock 156 288 355 minecraft:black_concrete
setblock 156 288 363 minecraft:dark_prismarine
fill 157 288 323 160 288 323 minecraft:blue_terracotta
setblock 157 288 326 minecraft:blue_terracotta
setblock 157 288 362 minecraft:dark_prismarine
fill 157 288 363 160 288 363 minecraft:blue_terracotta
setblock 158 288 326 minecraft:dark_prismarine
fill 158 288 362 161 288 362 minecraft:blue_terracotta
setblock 159 288 325 minecraft:dark_prismarine
fill 159 288 326 159 291 326 minecraft:blue_terracotta
setblock 160 288 324 minecraft:dark_prismarine
fill 160 288 325 163 288 325 minecraft:blue_terracotta
setblock 161 288 323 minecraft:dark_prismarine
fill 161 288 324 164 288 324 minecraft:blue_terracotta
fill 161 288 361 162 288 361 minecraft:blue_terracotta
setblock 161 288 363 minecraft:dark_prismarine
fill 162 288 323 165 288 323 minecraft:blue_terracotta
setblock 162 288 362 minecraft:dark_prismarine
fill 162 288 363 165 288 363 minecraft:blue_terracotta
setblock 163 288 326 minecraft:dark_prismarine
setblock 163 288 361 minecraft:dark_prismarine
fill 163 288 362 166 288 362 minecraft:blue_terracotta
setblock 164 288 325 minecraft:dark_prismarine
setblock 164 288 326 minecraft:blue_terracotta
setblock 164 288 361 minecraft:blue_terracotta
setblock 165 288 324 minecraft:dark_prismarine
fill 165 288 325 165 289 325 minecraft:blue_terracotta
setblock 166 288 323 minecraft:dark_prismarine
fill 166 288 324 166 290 324 minecraft:blue_terracotta
setblock 166 288 363 minecraft:dark_prismarine
fill 167 288 323 170 288 323 minecraft:blue_terracotta
setblock 167 288 362 minecraft:dark_prismarine
fill 167 288 363 170 288 363 minecraft:blue_terracotta
fill 168 288 362 169 288 362 minecraft:blue_terracotta
setblock 171 288 323 minecraft:dark_prismarine
setblock 171 288 363 minecraft:dark_prismarine
fill 172 288 323 175 288 323 minecraft:blue_terracotta
fill 172 288 363 175 288 363 minecraft:blue_terracotta
setblock 176 288 323 minecraft:dark_prismarine
setblock 176 288 363 minecraft:dark_prismarine
fill 177 288 323 177 291 323 minecraft:blue_terracotta
setblock 177 288 362 minecraft:dark_prismarine
fill 177 288 363 177 290 363 minecraft:blue_terracotta
setblock 179 288 344 minecraft:blue_terracotta
setblock 179 288 345 minecraft:dark_prismarine
fill 179 288 346 179 291 346 minecraft:blue_terracotta
fill 179 288 348 179 288 349 minecraft:blue_terracotta
setblock 179 288 350 minecraft:dark_prismarine
fill 179 288 351 179 291 351 minecraft:blue_terracotta
setblock 180 288 324 minecraft:dark_prismarine
setblock 180 288 343 minecraft:blue_terracotta
setblock 180 288 344 minecraft:dark_prismarine
fill 180 288 345 180 291 345 minecraft:blue_terracotta
setblock 180 288 348 minecraft:blue_terracotta
setblock 180 288 349 minecraft:dark_prismarine
fill 180 288 350 180 291 350 minecraft:blue_terracotta
setblock 180 288 353 minecraft:blue_terracotta
setblock 180 288 354 minecraft:dark_prismarine
setblock 180 288 359 minecraft:dark_prismarine
setblock 181 288 323 minecraft:dark_prismarine
fill 181 288 324 181 291 324 minecraft:blue_terracotta
setblock 181 288 327 minecraft:blue_terracotta
setblock 181 288 328 minecraft:dark_prismarine
fill 181 288 329 181 291 329 minecraft:blue_terracotta
setblock 181 288 332 minecraft:blue_terracotta
setblock 181 288 333 minecraft:dark_prismarine
fill 181 288 334 181 288 337 minecraft:blue_terracotta
setblock 181 288 338 minecraft:dark_prismarine
fill 181 288 339 181 291 339 minecraft:blue_terracotta
setblock 181 288 343 minecraft:dark_prismarine
fill 181 288 344 181 291 344 minecraft:blue_terracotta
setblock 181 288 348 minecraft:dark_prismarine
fill 181 288 349 181 291 349 minecraft:blue_terracotta
setblock 181 288 353 minecraft:dark_prismarine
setblock 181 288 354 minecraft:blue_terracotta
setblock 181 288 358 minecraft:dark_prismarine
setblock 181 288 359 minecraft:blue_terracotta
setblock 181 288 363 minecraft:dark_prismarine
fill 182 288 323 182 291 323 minecraft:blue_terracotta
setblock 182 288 327 minecraft:dark_prismarine
fill 182 288 328 182 291 328 minecraft:blue_terracotta
setblock 182 288 332 minecraft:dark_prismarine
fill 182 288 333 182 288 336 minecraft:blue_terracotta
setblock 182 288 337 minecraft:dark_prismarine
fill 182 288 338 182 291 338 minecraft:blue_terracotta
setblock 182 288 342 minecraft:dark_prismarine
fill 182 288 343 182 291 343 minecraft:blue_terracotta
setblock 182 288 347 minecraft:dark_prismarine
fill 182 288 348 182 291 348 minecraft:blue_terracotta
setblock 182 288 352 minecraft:dark_prismarine
setblock 182 288 353 minecraft:blue_terracotta
setblock 182 288 357 minecraft:dark_prismarine
fill 182 288 358 182 291 358 minecraft:blue_terracotta
setblock 182 288 362 minecraft:dark_prismarine
fill 182 288 363 182 290 363 minecraft:blue_terracotta
fill 141 289 339 141 308 339 minecraft:blue_concrete
fill 142 289 323 142 289 325 minecraft:blue_terracotta
setblock 142 289 326 minecraft:dark_prismarine
fill 142 289 327 142 289 330 minecraft:blue_terracotta
setblock 142 289 331 minecraft:sea_lantern
fill 142 289 332 142 292 332 minecraft:blue_terracotta
setblock 142 289 333 minecraft:sea_lantern
fill 142 289 334 142 290 334 minecraft:blue_terracotta
setblock 142 289 335 minecraft:sea_lantern
setblock 142 289 336 minecraft:dark_prismarine
fill 142 289 337 142 289 340 minecraft:blue_terracotta
setblock 142 289 341 minecraft:dark_prismarine
fill 142 289 342 142 289 345 minecraft:blue_terracotta
setblock 142 289 346 minecraft:dark_prismarine
fill 142 289 347 142 289 350 minecraft:blue_terracotta
setblock 142 289 351 minecraft:dark_prismarine
fill 142 289 352 142 289 355 minecraft:blue_terracotta
setblock 142 289 356 minecraft:dark_prismarine
fill 142 289 362 142 289 363 minecraft:blue_terracotta
fill 143 289 323 143 289 324 minecraft:blue_terracotta
setblock 143 289 325 minecraft:dark_prismarine
fill 143 289 326 143 289 329 minecraft:blue_terracotta
setblock 143 289 330 minecraft:sea_lantern
fill 143 289 331 143 292 331 minecraft:blue_terracotta
setblock 143 289 332 minecraft:sea_lantern
fill 143 289 333 143 290 333 minecraft:blue_terracotta
setblock 143 289 334 minecraft:sea_lantern
setblock 143 289 335 minecraft:dark_prismarine
setblock 143 289 336 minecraft:sea_lantern
fill 143 289 337 143 289 339 minecraft:blue_terracotta
setblock 143 289 340 minecraft:dark_prismarine
fill 143 289 341 143 289 344 minecraft:blue_terracotta
setblock 143 289 345 minecraft:dark_prismarine
fill 143 289 346 143 292 346 minecraft:blue_terracotta
setblock 143 289 350 minecraft:dark_prismarine
fill 143 289 351 143 292 351 minecraft:blue_terracotta
fill 143 289 363 144 289 363 minecraft:blue_terracotta
setblock 144 289 323 minecraft:blue_terracotta
setblock 144 289 324 minecraft:dark_prismarine
fill 144 289 325 144 291 325 minecraft:blue_terracotta
setblock 144 289 329 minecraft:dark_prismarine
fill 144 289 330 144 292 330 minecraft:blue_terracotta
setblock 144 289 331 minecraft:sea_lantern
fill 144 289 332 144 290 332 minecraft:blue_terracotta
setblock 144 289 333 minecraft:sea_lantern
fill 144 289 334 144 300 334 minecraft:dark_prismarine
setblock 144 289 335 minecraft:sea_lantern
fill 144 289 336 144 300 336 minecraft:dark_prismarine
setblock 144 289 344 minecraft:dark_prismarine
setblock 144 289 345 minecraft:blue_terracotta
setblock 144 289 349 minecraft:dark_prismarine
setblock 145 289 323 minecraft:dark_prismarine
fill 145 289 324 148 289 324 minecraft:blue_terracotta
setblock 145 289 330 minecraft:sea_lantern
fill 145 289 331 145 300 331 minecraft:dark_prismarine
setblock 145 289 332 minecraft:sea_lantern
fill 145 289 333 145 300 333 minecraft:dark_prismarine
setblock 145 289 334 minecraft:sea_lantern
fill 145 289 335 145 300 335 minecraft:dark_prismarine
setblock 145 289 336 minecraft:sea_lantern
setblock 145 289 363 minecraft:dark_prismarine
fill 146 289 323 149 289 323 minecraft:blue_terracotta
fill 146 289 330 146 300 330 minecraft:dark_prismarine
setblock 146 289 331 minecraft:sea_lantern
fill 146 289 332 146 300 332 minecraft:dark_prismarine
setblock 146 289 333 minecraft:sea_lantern
fill 146 289 334 146 300 334 minecraft:dark_prismarine
setblock 146 289 335 minecraft:sea_lantern
fill 146 289 336 146 300 336 minecraft:dark_prismarine
setblock 147 289 330 minecraft:sea_lantern
fill 147 289 331 147 300 331 minecraft:dark_prismarine
setblock 147 289 332 minecraft:sea_lantern
fill 147 289 333 147 300 333 minecraft:dark_prismarine
setblock 147 289 334 minecraft:sea_lantern
fill 147 289 335 147 300 335 minecraft:dark_prismarine
setblock 147 289 336 minecraft:sea_lantern
setblock 148 289 325 minecraft:dark_prismarine
setblock 149 289 324 minecraft:dark_prismarine
setblock 150 289 323 minecraft:dark_prismarine
fill 150 289 324 153 289 324 minecraft:blue_terracotta
fill 151 289 323 154 289 323 minecraft:blue_terracotta
fill 151 289 356 151 291 356 minecraft:dark_prismarine
fill 152 289 353 152 292 353 minecraft:dark_prismarine
setblock 153 289 325 minecraft:dark_prismarine
fill 153 289 352 153 291 352 minecraft:dark_prismarine
setblock 154 289 324 minecraft:dark_prismarine
fill 154 289 325 157 289 325 minecraft:blue_terracotta
setblock 154 289 363 minecraft:blue_terracotta
setblock 155 289 323 minecraft:dark_prismarine
fill 155 289 324 158 289 324 minecraft:blue_terracotta
setblock 155 289 363 minecraft:dark_prismarine
fill 156 289 323 159 289 323 minecraft:blue_terracotta
fill 156 289 363 159 289 363 minecraft:blue_terracotta
setblock 157 289 326 minecraft:dark_prismarine
fill 157 289 362 160 289 362 minecraft:blue_terracotta
setblock 158 289 325 minecraft:dark_prismarine
fill 158 289 326 158 290 326 minecraft:blue_terracotta
setblock 159 289 324 minecraft:dark_prismarine
fill 159 289 325 162 289 325 minecraft:blue_terracotta
setblock 160 289 323 minecraft:dark_prismarine
fill 160 289 324 163 289 324 minecraft:blue_terracotta
setblock 160 289 363 minecraft:dark_prismarine
fill 161 289 323 164 289 323 minecraft:blue_terracotta
setblock 161 289 362 minecraft:dark_prismarine
fill 161 289 363 164 289 363 minecraft:blue_terracotta
setblock 162 289 326 minecraft:dark_prismarine
setblock 162 289 361 minecraft:dark_prismarine
fill 162 289 362 165 289 362 minecraft:blue_terracotta
setblock 163 289 325 minecraft:dark_prismarine
setblock 163 289 326 minecraft:blue_terracotta
setblock 164 289 324 minecraft:dark_prismarine
fill 164 289 325 164 290 325 minecraft:blue_terracotta
setblock 165 289 323 minecraft:dark_prismarine
fill 165 289 324 165 291 324 minecraft:blue_terracotta
setblock 165 289 363 minecraft:dark_prismarine
fill 166 289 323 169 289 323 minecraft:blue_terracotta
setblock 166 289 362 minecraft:dark_prismarine
fill 166 289 363 169 289 363 minecraft:blue_terracotta
setblock 167 289 362 minecraft:blue_terracotta
setblock 170 289 323 minecraft:dark_prismarine
setblock 170 289 363 minecraft:dark_prismarine
setblock 171 289 323 minecraft:blue_terracotta
fill 171 289 363 174 289 363 minecraft:blue_terracotta
setblock 173 289 352 minecraft:sea_lantern
setblock 173 289 354 minecraft:sea_lantern
setblock 173 289 356 minecraft:sea_lantern
setblock 173 289 358 minecraft:sea_lantern
setblock 173 289 360 minecraft:sea_lantern
setblock 173 289 362 minecraft:sea_lantern
setblock 174 289 323 minecraft:blue_terracotta
setblock 174 289 353 minecraft:sea_lantern
setblock 174 289 355 minecraft:sea_lantern
setblock 174 289 357 minecraft:sea_lantern
setblock 174 289 359 minecraft:sea_lantern
setblock 174 289 361 minecraft:sea_lantern
setblock 175 289 323 minecraft:dark_prismarine
setblock 175 289 352 minecraft:sea_lantern
setblock 175 289 354 minecraft:sea_lantern
setblock 175 289 356 minecraft:sea_lantern
setblock 175 289 358 minecraft:sea_lantern
setblock 175 289 360 minecraft:sea_lantern
setblock 175 289 362 minecraft:sea_lantern
setblock 175 289 363 minecraft:dark_prismarine
fill 176 289 323 176 290 323 minecraft:blue_terracotta
setblock 176 289 353 minecraft:sea_lantern
setblock 176 289 355 minecraft:sea_lantern
setblock 176 289 357 minecraft:sea_lantern
setblock 176 289 359 minecraft:sea_lantern
setblock 176 289 361 minecraft:sea_lantern
fill 176 289 362 176 299 362 minecraft:dark_prismarine
fill 176 289 363 176 290 363 minecraft:blue_terracotta
setblock 177 289 352 minecraft:sea_lantern
setblock 177 289 354 minecraft:sea_lantern
setblock 177 289 356 minecraft:sea_lantern
setblock 177 289 358 minecraft:sea_lantern
setblock 177 289 360 minecraft:sea_lantern
setblock 177 289 362 minecraft:sea_lantern
setblock 178 289 353 minecraft:sea_lantern
setblock 178 289 355 minecraft:sea_lantern
setblock 178 289 357 minecraft:sea_lantern
setblock 178 289 359 minecraft:sea_lantern
setblock 178 289 361 minecraft:sea_lantern
fill 178 289 362 178 300 362 minecraft:dark_prismarine
setblock 179 289 324 minecraft:dark_prismarine
setblock 179 289 344 minecraft:dark_prismarine
fill 179 289 345 179 290 345 minecraft:blue_terracotta
setblock 179 289 348 minecraft:blue_terracotta
setblock 179 289 349 minecraft:dark_prismarine
fill 179 289 350 179 292 350 minecraft:blue_terracotta
setblock 179 289 352 minecraft:sea_lantern
setblock 179 289 354 minecraft:sea_lantern
setblock 179 289 356 minecraft:sea_lantern
setblock 179 289 358 minecraft:sea_lantern
setblock 179 289 360 minecraft:sea_lantern
setblock 179 289 362 minecraft:sea_lantern
setblock 180 289 323 minecraft:dark_prismarine
fill 180 289 324 180 291 324 minecraft:blue_terracotta
setblock 180 289 343 minecraft:dark_prismarine
fill 180 289 344 180 292 344 minecraft:blue_terracotta
setblock 180 289 348 minecraft:dark_prismarine
fill 180 289 349 180 292 349 minecraft:blue_terracotta
setblock 180 289 353 minecraft:sea_lantern
fill 180 289 354 180 292 354 minecraft:blue_terracotta
setblock 180 289 355 minecraft:sea_lantern
setblock 180 289 357 minecraft:sea_lantern
setblock 180 289 359 minecraft:sea_lantern
setblock 180 289 361 minecraft:sea_lantern
fill 180 289 362 180 289 363 minecraft:dark_prismarine
fill 181 289 323 181 292 323 minecraft:blue_terracotta
setblock 181 289 327 minecraft:dark_prismarine
fill 181 289 328 181 292 328 minecraft:blue_terracotta
fill 181 289 330 181 289 331 minecraft:blue_terracotta
setblock 181 289 332 minecraft:dark_prismarine
fill 181 289 333 181 289 336 minecraft:blue_terracotta
setblock 181 289 337 minecraft:dark_prismarine
fill 181 289 338 181 291 338 minecraft:blue_terracotta
setblock 181 289 342 minecraft:dark_prismarine
fill 181 289 343 181 292 343 minecraft:blue_terracotta
setblock 181 289 347 minecraft:dark_prismarine
fill 181 289 348 181 292 348 minecraft:blue_terracotta
setblock 181 289 351 minecraft:blue_terracotta
setblock 181 289 352 minecraft:sea_lantern
fill 181 289 353 181 292 353 minecraft:blue_terracotta
setblock 181 289 354 minecraft:sea_lantern
fill 181 289 355 181 290 355 minecraft:blue_terracotta
setblock 181 289 356 minecraft:sea_lantern
fill 181 289 357 181 297 357 minecraft:dark_prismarine
setblock 181 289 358 minecraft:sea_lantern
fill 181 289 359 181 300 359 minecraft:dark_prismarine
setblock 181 289 360 minecraft:sea_lantern
fill 181 289 361 181 300 361 minecraft:dark_prismarine
setblock 181 289 362 minecraft:sea_lantern
fill 181 289 363 181 291 363 minecraft:blue_terracotta
setblock 182 289 326 minecraft:dark_prismarine
fill 182 289 327 182 292 327 minecraft:blue_terracotta
setblock 182 289 330 minecraft:blue_terracotta
setblock 182 289 331 minecraft:dark_prismarine
fill 182 289 332 182 289 335 minecraft:blue_terracotta
setblock 182 289 336 minecraft:dark_prismarine
fill 182 289 337 182 292 337 minecraft:blue_terracotta
setblock 182 289 341 minecraft:dark_prismarine
fill 182 289 342 182 292 342 minecraft:blue_terracotta
setblock 182 289 346 minecraft:dark_prismarine
fill 182 289 347 182 292 347 minecraft:blue_terracotta
setblock 182 289 351 minecraft:dark_prismarine
fill 182 289 352 182 292 352 minecraft:blue_terracotta
setblock 182 289 353 minecraft:sea_lantern
fill 182 289 354 182 290 354 minecraft:blue_terracotta
setblock 182 289 355 minecraft:sea_lantern
setblock 182 289 356 minecraft:dark_prismarine
setblock 182 289 357 minecraft:sea_lantern
setblock 182 289 359 minecraft:sea_lantern
setblock 182 289 361 minecraft:sea_lantern
fill 182 289 362 182 290 362 minecraft:blue_terracotta
fill 142 290 323 142 290 324 minecraft:blue_terracotta
setblock 142 290 325 minecraft:dark_prismarine
fill 142 290 326 142 290 329 minecraft:blue_terracotta
setblock 142 290 330 minecraft:dark_prismarine
fill 142 290 331 142 291 331 minecraft:blue_terracotta
fill 142 290 333 142 291 333 minecraft:blue_terracotta
setblock 142 290 335 minecraft:dark_prismarine
fill 142 290 336 142 290 339 minecraft:blue_terracotta
setblock 142 290 340 minecraft:dark_prismarine
fill 142 290 341 142 290 344 minecraft:blue_terracotta
setblock 142 290 345 minecraft:dark_prismarine
fill 142 290 346 142 290 349 minecraft:blue_terracotta
setblock 142 290 350 minecraft:dark_prismarine
fill 142 290 351 142 290 354 minecraft:blue_terracotta
setblock 142 290 355 minecraft:dark_prismarine
setblock 142 290 356 minecraft:blue_terracotta
setblock 142 290 363 minecraft:blue_terracotta
setblock 143 290 323 minecraft:blue_terracotta
setblock 143 290 324 minecraft:dark_prismarine
fill 143 290 325 143 290 328 minecraft:blue_terracotta
setblock 143 290 329 minecraft:dark_prismarine
fill 143 290 330 143 291 330 minecraft:blue_terracotta
fill 143 290 332 143 291 332 minecraft:blue_terracotta
setblock 143 290 334 minecraft:dark_prismarine
fill 143 290 335 143 290 338 minecraft:blue_terracotta
setblock 143 290 339 minecraft:dark_prismarine
fill 143 290 340 143 290 343 minecraft:blue_terracotta
setblock 143 290 344 minecraft:dark_prismarine
fill 143 290 345 143 292 345 minecraft:blue_terracotta
setblock 143 290 349 minecraft:dark_prismarine
fill 143 290 350 143 292 350 minecraft:blue_terracotta
setblock 144 290 323 minecraft:dark_prismarine
fill 144 290 324 147 290 324 minecraft:blue_terracotta
setblock 144 290 328 minecraft:dark_prismarine
fill 144 290 329 144 293 329 minecraft:blue_terracotta
fill 144 290 331 144 291 331 minecraft:blue_terracotta
fill 144 290 333 144 291 333 minecraft:dark_prismarine
fill 144 290 335 144 291 335 minecraft:dark_prismarine
setblock 144 290 348 minecraft:dark_prismarine
fill 145 290 323 148 290 323 minecraft:blue_terracotta
fill 145 290 330 145 291 330 minecraft:dark_prismarine
fill 145 290 332 145 291 332 minecraft:dark_prismarine
fill 145 290 334 145 291 334 minecraft:dark_prismarine
fill 145 290 336 145 291 336 minecraft:dark_prismarine
fill 146 290 331 146 291 331 minecraft:dark_prismarine
fill 146 290 333 146 291 333 minecraft:dark_prismarine
fill 146 290 335 146 291 335 minecraft:dark_prismarine
fill 147 290 330 147 291 330 minecraft:dark_prismarine
fill 147 290 332 147 291 332 minecraft:dark_prismarine
fill 147 290 334 147 291 334 minecraft:dark_prismarine
fill 147 290 336 147 291 336 minecraft:dark_prismarine
setblock 148 290 324 minecraft:dark_prismarine
setblock 149 290 323 minecraft:dark_prismarine
fill 149 290 324 152 290 324 minecraft:blue_terracotta
fill 150 290 323 153 290 323 minecraft:blue_terracotta
setblock 151 290 363 minecraft:purple_concrete
setblock 153 290 324 minecraft:dark_prismarine
setblock 154 290 323 minecraft:dark_prismarine
fill 154 290 324 156 290 325 minecraft:blue_terracotta
fill 155 290 323 158 290 323 minecraft:blue_terracotta
fill 155 290 363 158 290 363 minecraft:blue_terracotta
setblock 157 290 324 minecraft:blue_terracotta
setblock 157 290 325 minecraft:dark_prismarine
setblock 157 290 326 minecraft:blue_terracotta
setblock 158 290 324 minecraft:dark_prismarine
fill 158 290 325 161 290 325 minecraft:blue_terracotta
fill 158 290 362 159 290 362 minecraft:blue_terracotta
setblock 159 290 323 minecraft:dark_prismarine
fill 159 290 324 162 290 324 minecraft:blue_terracotta
setblock 159 290 363 minecraft:dark_prismarine
fill 160 290 323 163 290 323 minecraft:blue_terracotta
setblock 160 290 362 minecraft:dark_prismarine
fill 160 290 363 163 290 363 minecraft:blue_terracotta
setblock 161 290 326 minecraft:dark_prismarine
fill 161 290 362 164 290 362 minecraft:blue_terracotta
setblock 162 290 325 minecraft:dark_prismarine
setblock 162 290 326 minecraft:blue_terracotta
setblock 163 290 324 minecraft:dark_prismarine
fill 163 290 325 163 291 325 minecraft:blue_terracotta
setblock 164 290 323 minecraft:dark_prismarine
fill 164 290 324 164 292 324 minecraft:blue_terracotta
setblock 164 290 363 minecraft:dark_prismarine
fill 165 290 323 168 290 323 minecraft:blue_terracotta
setblock 165 290 362 minecraft:dark_prismarine
fill 165 290 363 168 290 363 minecraft:blue_terracotta
setblock 169 290 323 minecraft:dark_prismarine
fill 169 290 359 169 298 359 minecraft:magenta_terracotta
setblock 169 290 363 minecraft:dark_prismarine
setblock 170 290 363 minecraft:purple_concrete
setblock 173 290 323 minecraft:purple_concrete
fill 173 290 352 173 291 352 minecraft:dark_prismarine
fill 173 290 354 173 291 354 minecraft:dark_prismarine
fill 173 290 356 173 291 356 minecraft:dark_prismarine
fill 173 290 358 173 291 358 minecraft:dark_prismarine
fill 173 290 360 173 291 360 minecraft:dark_prismarine
fill 173 290 362 173 291 362 minecraft:dark_prismarine
fill 174 290 353 174 291 353 minecraft:dark_prismarine
fill 174 290 355 174 291 355 minecraft:dark_prismarine
fill 174 290 357 174 291 357 minecraft:dark_prismarine
fill 174 290 359 174 291 359 minecraft:dark_prismarine
fill 174 290 361 174 291 361 minecraft:dark_prismarine
fill 175 290 352 175 291 352 minecraft:dark_prismarine
fill 175 290 354 175 291 354 minecraft:dark_prismarine
fill 175 290 356 175 291 356 minecraft:dark_prismarine
fill 175 290 358 175 291 358 minecraft:dark_prismarine
fill 175 290 360 175 291 360 minecraft:dark_prismarine
fill 175 290 362 175 291 362 minecraft:dark_prismarine
fill 176 290 353 176 291 353 minecraft:dark_prismarine
fill 176 290 355 176 291 355 minecraft:dark_prismarine
fill 176 290 357 176 291 357 minecraft:dark_prismarine
fill 176 290 359 176 291 359 minecraft:dark_prismarine
fill 176 290 361 176 291 361 minecraft:dark_prismarine
fill 177 290 352 177 291 352 minecraft:dark_prismarine
fill 177 290 354 177 291 354 minecraft:dark_prismarine
fill 177 290 356 177 291 356 minecraft:dark_prismarine
fill 177 290 358 177 291 358 minecraft:dark_prismarine
fill 177 290 360 177 291 360 minecraft:dark_prismarine
fill 177 290 362 177 291 362 minecraft:dark_prismarine
fill 178 290 353 178 291 353 minecraft:dark_prismarine
fill 178 290 355 178 291 355 minecraft:dark_prismarine
fill 178 290 357 178 291 357 minecraft:dark_prismarine
fill 178 290 359 178 291 359 minecraft:dark_prismarine
fill 178 290 361 178 291 361 minecraft:dark_prismarine
setblock 179 290 323 minecraft:dark_prismarine
setblock 179 290 324 minecraft:blue_terracotta
setblock 179 290 348 minecraft:dark_prismarine
fill 179 290 349 179 293 349 minecraft:blue_terracotta
fill 179 290 352 180 290 352 minecraft:dark_prismarine
fill 179 290 354 179 291 354 minecraft:dark_prismarine
fill 179 290 356 179 291 356 minecraft:dark_prismarine
fill 179 290 358 179 291 358 minecraft:dark_prismarine
fill 179 290 360 179 291 360 minecraft:dark_prismarine
fill 179 290 362 179 290 363 minecraft:dark_prismarine
fill 180 290 323 180 292 323 minecraft:blue_terracotta
setblock 180 290 342 minecraft:dark_prismarine
fill 180 290 343 180 291 343 minecraft:blue_terracotta
setblock 180 290 347 minecraft:dark_prismarine
fill 180 290 348 180 293 348 minecraft:blue_terracotta
fill 180 290 353 180 291 353 minecraft:blue_terracotta
fill 180 290 355 180 291 355 minecraft:dark_prismarine
fill 180 290 357 180 291 357 minecraft:dark_prismarine
fill 180 290 359 180 291 359 minecraft:dark_prismarine
fill 180 290 361 180 291 362 minecraft:dark_prismarine
fill 180 290 363 180 291 363 minecraft:blue_terracotta
setblock 181 290 326 minecraft:dark_prismarine
fill 181 290 327 181 293 327 minecraft:blue_terracotta
setblock 181 290 330 minecraft:blue_terracotta
setblock 181 290 331 minecraft:dark_prismarine
fill 181 290 332 181 290 335 minecraft:blue_terracotta
setblock 181 290 336 minecraft:dark_prismarine
fill 181 290 337 181 291 337 minecraft:blue_terracotta
setblock 181 290 341 minecraft:dark_prismarine
fill 181 290 342 181 293 342 minecraft:blue_terracotta
setblock 181 290 346 minecraft:dark_prismarine
fill 181 290 347 181 293 347 minecraft:blue_terracotta
setblock 181 290 351 minecraft:dark_prismarine
fill 181 290 352 181 291 352 minecraft:blue_terracotta
fill 181 290 354 181 291 354 minecraft:blue_terracotta
setblock 181 290 356 minecraft:dark_prismarine
fill 181 290 358 181 291 358 minecraft:dark_prismarine
fill 181 290 360 182 291 360 minecraft:dark_prismarine
fill 181 290 362 181 291 362 minecraft:dark_prismarine
setblock 182 290 325 minecraft:dark_prismarine
fill 182 290 326 182 293 326 minecraft:blue_terracotta
setblock 182 290 330 minecraft:dark_prismarine
fill 182 290 331 182 290 334 minecraft:blue_terracotta
setblock 182 290 335 minecraft:dark_prismarine
fill 182 290 336 182 293 336 minecraft:blue_terracotta
setblock 182 290 340 minecraft:dark_prismarine
fill 182 290 341 182 293 341 minecraft:blue_terracotta
setblock 182 290 345 minecraft:dark_prismarine
fill 182 290 346 182 293 346 minecraft:blue_terracotta
setblock 182 290 350 minecraft:dark_prismarine
fill 182 290 351 182 293 351 minecraft:blue_terracotta
fill 182 290 353 182 291 353 minecraft:blue_terracotta
setblock 182 290 355 minecraft:dark_prismarine
fill 182 290 356 182 291 357 minecraft:blue_terracotta
setblock 182 290 359 minecraft:blue_terracotta
setblock 182 290 361 minecraft:blue_terracotta
setblock 142 291 323 minecraft:blue_terracotta
setblock 142 291 324 minecraft:dark_prismarine
fill 142 291 325 142 291 328 minecraft:blue_terracotta
setblock 142 291 329 minecraft:dark_prismarine
fill 142 291 330 142 294 330 minecraft:blue_terracotta
setblock 142 291 334 minecraft:dark_prismarine
fill 142 291 335 142 291 338 minecraft:blue_terracotta
setblock 142 291 339 minecraft:dark_prismarine
fill 142 291 340 142 291 343 minecraft:blue_terracotta
setblock 142 291 344 minecraft:dark_prismarine
fill 142 291 345 142 291 348 minecraft:blue_terracotta
setblock 142 291 349 minecraft:dark_prismarine
fill 142 291 350 142 291 353 minecraft:blue_terracotta
setblock 142 291 354 minecraft:dark_prismarine
fill 142 291 355 142 294 355 minecraft:blue_terracotta
setblock 143 291 323 minecraft:dark_prismarine
fill 143 291 324 143 291 327 minecraft:blue_terracotta
setblock 143 291 328 minecraft:dark_prismarine
fill 143 291 329 143 294 329 minecraft:blue_terracotta
setblock 143 291 333 minecraft:dark_prismarine
fill 143 291 334 143 291 337 minecraft:blue_terracotta
fill 143 291 341 143 291 342 minecraft:blue_terracotta
setblock 143 291 343 minecraft:dark_prismarine
setblock 143 291 344 minecraft:blue_terracotta
setblock 143 291 348 minecraft:dark_prismarine
fill 143 291 349 143 292 349 minecraft:blue_terracotta
fill 144 291 323 146 291 324 minecraft:blue_terracotta
fill 144 291 327 154 291 327 minecraft:dark_prismarine
fill 144 291 328 144 293 328 minecraft:blue_terracotta
fill 144 291 332 144 297 332 minecraft:dark_prismarine
fill 145 291 326 151 292 326 minecraft:dark_prismarine
setblock 147 291 323 minecraft:blue_terracotta
setblock 147 291 324 minecraft:dark_prismarine
setblock 148 291 323 minecraft:dark_prismarine
fill 149 291 323 152 291 323 minecraft:blue_terracotta
setblock 152 291 324 minecraft:dark_prismarine
setblock 153 291 322 minecraft:cyan_concrete
setblock 153 291 323 minecraft:dark_prismarine
fill 153 291 324 156 291 324 minecraft:blue_terracotta
fill 154 291 323 157 291 323 minecraft:blue_terracotta
setblock 155 291 325 minecraft:blue_terracotta
fill 155 291 363 157 291 363 minecraft:blue_terracotta
setblock 156 291 325 minecraft:dark_prismarine
fill 156 291 327 180 292 327 minecraft:dark_prismarine
setblock 157 291 324 minecraft:dark_prismarine
fill 157 291 325 160 291 325 minecraft:blue_terracotta
setblock 158 291 323 minecraft:dark_prismarine
fill 158 291 324 161 291 324 minecraft:blue_terracotta
setblock 158 291 362 minecraft:blue_terracotta
setblock 158 291 363 minecraft:dark_prismarine
fill 159 291 323 162 291 323 minecraft:blue_terracotta
setblock 159 291 362 minecraft:dark_prismarine
fill 159 291 363 162 291 363 minecraft:blue_terracotta
setblock 160 291 326 minecraft:dark_prismarine
fill 160 291 362 163 291 362 minecraft:blue_terracotta
setblock 161 291 325 minecraft:dark_prismarine
setblock 162 291 324 minecraft:dark_prismarine
fill 162 291 325 162 292 325 minecraft:blue_terracotta
setblock 163 291 323 minecraft:dark_prismarine
fill 163 291 324 163 292 324 minecraft:blue_terracotta
setblock 163 291 363 minecraft:dark_prismarine
fill 164 291 323 167 291 323 minecraft:blue_terracotta
setblock 164 291 362 minecraft:dark_prismarine
fill 164 291 363 167 291 363 minecraft:blue_terracotta
fill 169 291 329 169 297 329 minecraft:magenta_terracotta
fill 171 291 334 171 292 334 minecraft:dark_prismarine
setblock 176 291 363 minecraft:purple_concrete
setblock 178 291 323 minecraft:dark_prismarine
setblock 178 291 363 minecraft:dark_prismarine
fill 179 291 323 179 292 323 minecraft:blue_terracotta
setblock 179 291 347 minecraft:dark_prismarine
fill 179 291 348 179 293 348 minecraft:blue_terracotta
setblock 179 291 352 minecraft:dark_prismarine
setblock 179 291 362 minecraft:dark_prismarine
setblock 179 291 363 minecraft:blue_terracotta
setblock 180 291 346 minecraft:dark_prismarine
fill 180 291 347 180 294 347 minecraft:blue_terracotta
setblock 180 291 351 minecraft:dark_prismarine
fill 180 291 352 180 294 352 minecraft:blue_terracotta
setblock 181 291 322 minecraft:light_blue_wool
setblock 181 291 325 minecraft:dark_prismarine
fill 181 291 326 181 293 326 minecraft:blue_terracotta
setblock 181 291 330 minecraft:dark_prismarine
fill 181 291 331 181 291 334 minecraft:blue_terracotta
setblock 181 291 335 minecraft:dark_prismarine
fill 181 291 336 181 294 336 minecraft:blue_terracotta
setblock 181 291 340 minecraft:dark_prismarine
fill 181 291 341 181 293 341 minecraft:blue_terracotta
setblock 181 291 345 minecraft:dark_prismarine
fill 181 291 346 181 294 346 minecraft:blue_terracotta
setblock 181 291 350 minecraft:dark_prismarine
fill 181 291 351 181 294 351 minecraft:blue_terracotta
setblock 181 291 355 minecraft:dark_prismarine
setblock 181 291 356 minecraft:blue_terracotta
setblock 182 291 324 minecraft:dark_prismarine
fill 182 291 325 182 294 325 minecraft:blue_terracotta
setblock 182 291 329 minecraft:dark_prismarine
fill 182 291 330 182 291 333 minecraft:blue_terracotta
setblock 182 291 334 minecraft:dark_prismarine
fill 182 291 335 182 294 335 minecraft:blue_terracotta
setblock 182 291 339 minecraft:dark_prismarine
fill 182 291 340 182 294 340 minecraft:blue_terracotta
setblock 182 291 344 minecraft:dark_prismarine
fill 182 291 345 182 294 345 minecraft:blue_terracotta
setblock 182 291 349 minecraft:dark_prismarine
fill 182 291 350 182 294 350 minecraft:blue_terracotta
setblock 182 291 354 minecraft:dark_prismarine
setblock 182 291 355 minecraft:blue_terracotta
setblock 182 291 359 minecraft:dark_prismarine
fill 182 291 361 182 291 362 minecraft:dark_prismarine
schedule function dropper:buildpart/75_14 1t
