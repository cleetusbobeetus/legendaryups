fill 239 128 539 239 129 539 minecraft:bone_block
fill 241 128 524 241 130 526 minecraft:bone_block
fill 241 128 552 242 128 552 minecraft:crying_obsidian
fill 242 128 527 244 132 527 minecraft:bone_block
fill 243 128 522 245 128 522 minecraft:bone_block
fill 245 128 523 245 129 523 minecraft:bone_block
fill 246 128 552 246 143 552 minecraft:obsidian
fill 271 128 552 271 150 552 minecraft:obsidian
fill 235 129 518 235 135 518 minecraft:obsidian
fill 235 129 534 235 135 534 minecraft:obsidian
fill 235 129 550 235 135 550 minecraft:obsidian
fill 239 129 510 239 135 510 minecraft:obsidian
fill 239 129 523 240 130 523 minecraft:bone_block
fill 239 129 538 240 130 538 minecraft:bone_block
setblock 239 129 540 minecraft:bone_block
setblock 240 129 522 minecraft:bone_block
fill 241 129 527 241 133 528 minecraft:bone_block
fill 241 129 552 242 138 552 minecraft:obsidian
fill 242 129 523 242 129 524 minecraft:bone_block
fill 242 129 528 243 134 528 minecraft:bone_block
fill 243 129 522 244 129 522 minecraft:bone_block
setblock 245 129 526 minecraft:bone_block
fill 249 129 552 249 135 552 minecraft:obsidian
fill 255 129 510 255 135 510 minecraft:obsidian
fill 265 129 552 265 135 552 minecraft:obsidian
setblock 268 129 552 minecraft:crying_obsidian
fill 271 129 510 271 135 510 minecraft:obsidian
fill 277 129 520 277 135 520 minecraft:obsidian
fill 277 129 536 277 135 536 minecraft:obsidian
fill 239 130 524 240 130 524 minecraft:bone_block
fill 239 130 537 240 130 537 minecraft:bone_block
fill 240 130 525 240 131 528 minecraft:bone_block
fill 240 130 536 240 131 536 minecraft:bone_block
fill 241 130 529 243 135 529 minecraft:bone_block
fill 242 130 524 242 131 524 minecraft:bone_block
setblock 243 130 523 minecraft:bone_block
fill 243 130 525 244 131 525 minecraft:bone_block
setblock 244 130 524 minecraft:bone_block
fill 244 130 528 244 133 528 minecraft:bone_block
setblock 266 130 510 minecraft:amethyst_block
fill 268 130 552 268 154 552 minecraft:obsidian
setblock 274 130 552 minecraft:amethyst_block
setblock 277 130 529 minecraft:crying_obsidian
setblock 238 131 513 minecraft:light[level=12]
setblock 238 131 521 minecraft:light[level=12]
setblock 238 131 529 minecraft:light[level=12]
setblock 238 131 537 minecraft:light[level=12]
setblock 238 131 545 minecraft:light[level=12]
setblock 239 131 536 minecraft:bone_block
setblock 240 131 524 minecraft:bone_block
fill 240 131 529 240 135 529 minecraft:bone_block
fill 240 131 535 240 132 535 minecraft:bone_block
setblock 240 131 537 minecraft:bone_block
fill 241 131 525 241 131 526 minecraft:bone_block
fill 241 131 530 243 136 530 minecraft:bone_block
setblock 246 131 513 minecraft:light[level=12]
setblock 246 131 521 minecraft:light[level=12]
setblock 246 131 529 minecraft:light[level=12]
setblock 246 131 537 minecraft:light[level=12]
setblock 246 131 545 minecraft:light[level=12]
setblock 254 131 513 minecraft:light[level=12]
setblock 254 131 521 minecraft:light[level=12]
setblock 254 131 529 minecraft:light[level=12]
setblock 254 131 537 minecraft:light[level=12]
setblock 254 131 545 minecraft:light[level=12]
setblock 257 131 552 minecraft:amethyst_block
setblock 262 131 513 minecraft:light[level=12]
setblock 262 131 521 minecraft:light[level=12]
setblock 262 131 529 minecraft:light[level=12]
setblock 262 131 537 minecraft:light[level=12]
setblock 262 131 545 minecraft:light[level=12]
setblock 266 131 510 minecraft:crying_obsidian
setblock 270 131 513 minecraft:light[level=12]
setblock 270 131 521 minecraft:light[level=12]
setblock 270 131 529 minecraft:light[level=12]
setblock 270 131 537 minecraft:light[level=12]
setblock 270 131 545 minecraft:light[level=12]
fill 274 131 552 274 154 552 minecraft:obsidian
fill 277 131 529 277 150 529 minecraft:obsidian
fill 240 132 526 240 132 528 minecraft:bone_block
fill 240 132 530 240 136 530 minecraft:bone_block
fill 240 132 533 241 132 534 minecraft:bone_block
setblock 241 132 526 minecraft:bone_block
fill 241 132 531 243 137 531 minecraft:bone_block
setblock 241 132 535 minecraft:bone_block
fill 243 132 525 243 132 526 minecraft:bone_block
fill 244 132 529 244 133 529 minecraft:bone_block
fill 257 132 552 257 154 552 minecraft:obsidian
fill 266 132 510 266 154 510 minecraft:obsidian
setblock 277 132 544 minecraft:amethyst_block
fill 240 133 528 240 134 528 minecraft:bone_block
fill 240 133 531 240 133 533 minecraft:bone_block
fill 241 133 532 241 133 534 minecraft:bone_block
fill 242 133 526 242 133 527 minecraft:bone_block
fill 242 133 532 243 138 532 minecraft:bone_block
setblock 243 133 527 minecraft:bone_block
setblock 276 133 510 minecraft:white_concrete
fill 277 133 544 277 154 544 minecraft:obsidian
fill 240 134 531 240 137 532 minecraft:bone_block
setblock 240 134 552 minecraft:white_concrete
setblock 241 134 528 minecraft:bone_block
fill 241 134 532 241 138 533 minecraft:bone_block
setblock 242 134 527 minecraft:bone_block
fill 242 134 533 243 139 533 minecraft:bone_block
setblock 270 134 510 minecraft:white_concrete
fill 276 134 510 276 154 510 minecraft:obsidian
setblock 277 134 534 minecraft:white_concrete
fill 240 135 533 240 138 533 minecraft:bone_block
setblock 240 135 552 minecraft:amethyst_block
fill 241 135 534 243 140 534 minecraft:bone_block
setblock 242 135 528 minecraft:bone_block
setblock 266 135 552 minecraft:amethyst_block
setblock 269 135 552 minecraft:crying_obsidian
fill 270 135 510 270 154 510 minecraft:obsidian
fill 277 135 534 277 145 534 minecraft:obsidian
fill 235 136 518 235 137 518 minecraft:purple_concrete
setblock 235 136 524 minecraft:amethyst_block
fill 235 136 534 235 137 534 minecraft:purple_concrete
fill 235 136 550 235 137 550 minecraft:purple_concrete
setblock 237 136 510 minecraft:white_concrete
fill 237 136 533 237 137 533 minecraft:bone_block
fill 239 136 510 239 137 510 minecraft:purple_concrete
fill 240 136 534 240 139 534 minecraft:bone_block
fill 240 136 552 240 154 552 minecraft:obsidian
fill 241 136 535 243 141 535 minecraft:bone_block
fill 244 136 532 244 136 533 minecraft:bone_block
fill 249 136 552 249 137 552 minecraft:purple_concrete
fill 255 136 510 255 137 510 minecraft:purple_concrete
fill 265 136 552 265 137 552 minecraft:purple_concrete
fill 266 136 552 266 154 552 minecraft:obsidian
fill 269 136 552 269 138 552 minecraft:obsidian
fill 271 136 510 271 137 510 minecraft:purple_concrete
fill 277 136 520 277 137 520 minecraft:purple_concrete
fill 277 136 536 277 137 536 minecraft:purple_concrete
fill 235 137 524 235 150 524 minecraft:obsidian
setblock 236 137 533 minecraft:bone_block
fill 237 137 510 237 150 510 minecraft:obsidian
fill 237 137 534 238 138 534 minecraft:bone_block
fill 240 137 535 240 139 535 minecraft:bone_block
fill 241 137 536 243 141 536 minecraft:bone_block
fill 244 137 533 244 137 535 minecraft:bone_block
fill 247 137 547 247 137 549 minecraft:bone_block
setblock 247 137 552 minecraft:crying_obsidian
setblock 248 137 548 minecraft:bone_block
fill 256 137 552 256 138 552 minecraft:crying_obsidian
setblock 277 137 517 minecraft:amethyst_block
setblock 235 138 516 minecraft:white_concrete
fill 235 138 518 235 144 518 minecraft:obsidian
fill 235 138 534 235 144 534 minecraft:obsidian
fill 235 138 550 235 141 550 minecraft:obsidian
fill 238 138 535 239 139 535 minecraft:bone_block
fill 239 138 510 239 144 510 minecraft:obsidian
setblock 239 138 534 minecraft:bone_block
fill 241 138 537 244 141 537 minecraft:bone_block
setblock 243 138 552 minecraft:amethyst_block
fill 244 138 534 244 139 536 minecraft:bone_block
fill 246 138 545 246 138 547 minecraft:bone_block
fill 247 138 546 247 138 548 minecraft:bone_block
fill 247 138 552 247 154 552 minecraft:obsidian
fill 249 138 552 249 144 552 minecraft:obsidian
fill 255 138 510 255 144 510 minecraft:obsidian
fill 265 138 552 265 144 552 minecraft:obsidian
fill 271 138 510 271 144 510 minecraft:obsidian
fill 277 138 517 277 150 517 minecraft:obsidian
fill 277 138 520 277 144 520 minecraft:obsidian
fill 277 138 536 277 144 536 minecraft:obsidian
fill 235 139 516 235 154 516 minecraft:obsidian
setblock 238 139 513 minecraft:light[level=12]
setblock 238 139 521 minecraft:light[level=12]
setblock 238 139 529 minecraft:light[level=12]
setblock 238 139 537 minecraft:light[level=12]
setblock 238 139 545 minecraft:light[level=12]
fill 239 139 536 240 139 536 minecraft:bone_block
setblock 241 139 533 minecraft:bone_block
fill 241 139 538 244 141 538 minecraft:bone_block
setblock 241 139 552 minecraft:crying_obsidian
fill 242 139 552 243 154 552 minecraft:obsidian
setblock 246 139 513 minecraft:light[level=12]
setblock 246 139 521 minecraft:light[level=12]
setblock 246 139 529 minecraft:light[level=12]
setblock 246 139 537 minecraft:light[level=12]
fill 246 139 544 246 139 546 minecraft:bone_block
setblock 247 139 546 minecraft:bone_block
setblock 254 139 513 minecraft:light[level=12]
setblock 254 139 521 minecraft:light[level=12]
setblock 254 139 529 minecraft:light[level=12]
setblock 254 139 537 minecraft:light[level=12]
setblock 254 139 545 minecraft:light[level=12]
fill 256 139 552 256 142 552 minecraft:obsidian
setblock 262 139 513 minecraft:light[level=12]
setblock 262 139 521 minecraft:light[level=12]
setblock 262 139 529 minecraft:light[level=12]
setblock 262 139 537 minecraft:light[level=12]
setblock 262 139 545 minecraft:light[level=12]
setblock 269 139 552 minecraft:white_concrete
setblock 270 139 513 minecraft:light[level=12]
setblock 270 139 521 minecraft:light[level=12]
setblock 270 139 529 minecraft:light[level=12]
setblock 270 139 537 minecraft:light[level=12]
setblock 270 139 545 minecraft:light[level=12]
setblock 235 140 512 minecraft:white_concrete
setblock 237 140 552 minecraft:crying_obsidian
fill 240 140 536 240 140 537 minecraft:bone_block
fill 241 140 552 241 154 552 minecraft:obsidian
fill 242 140 539 245 143 539 minecraft:bone_block
fill 244 140 535 244 141 536 minecraft:bone_block
fill 245 140 537 245 143 538 minecraft:bone_block
fill 245 140 542 245 140 544 minecraft:bone_block
fill 246 140 543 246 140 545 minecraft:bone_block
setblock 248 140 510 minecraft:amethyst_block
fill 249 140 510 250 144 510 minecraft:obsidian
fill 264 140 543 264 141 544 minecraft:amethyst_block
fill 269 140 552 269 154 552 minecraft:obsidian
setblock 272 140 552 minecraft:crying_obsidian
setblock 273 140 510 minecraft:crying_obsidian
fill 235 141 512 235 154 512 minecraft:obsidian
fill 237 141 552 237 143 552 minecraft:obsidian
fill 243 141 540 245 145 540 minecraft:bone_block
setblock 245 141 536 minecraft:bone_block
fill 245 141 541 245 141 543 minecraft:bone_block
setblock 246 141 543 minecraft:bone_block
fill 248 141 510 248 154 510 minecraft:obsidian
setblock 264 141 552 minecraft:crying_obsidian
fill 272 141 552 272 152 552 minecraft:obsidian
fill 273 141 510 273 155 510 minecraft:obsidian
setblock 235 142 550 minecraft:crying_obsidian
fill 242 142 536 244 142 538 minecraft:bone_block
fill 242 142 540 242 143 540 minecraft:bone_block
fill 243 142 541 246 145 541 minecraft:bone_block
fill 245 142 542 245 147 542 minecraft:bone_block
fill 246 142 538 246 144 540 minecraft:bone_block
fill 264 142 552 264 154 552 minecraft:obsidian
setblock 272 142 510 minecraft:amethyst_block
setblock 235 143 532 minecraft:crying_obsidian
setblock 235 143 542 minecraft:amethyst_block
fill 235 143 550 235 144 550 minecraft:obsidian
fill 242 143 537 244 143 538 minecraft:bone_block
fill 244 143 542 244 146 542 minecraft:bone_block
fill 246 143 542 246 147 542 minecraft:bone_block
fill 247 143 540 247 147 541 minecraft:bone_block
setblock 255 143 552 minecraft:crying_obsidian
setblock 256 143 552 minecraft:amethyst_block
fill 272 143 510 272 145 510 minecraft:obsidian
setblock 277 143 547 minecraft:amethyst_block
fill 235 144 532 235 154 532 minecraft:obsidian
fill 235 144 542 235 151 542 minecraft:obsidian
setblock 237 144 552 minecraft:white_concrete
fill 243 144 538 245 144 539 minecraft:bone_block
fill 245 144 543 247 147 543 minecraft:bone_block
setblock 246 144 552 minecraft:amethyst_block
setblock 247 144 539 minecraft:bone_block
fill 247 144 542 247 147 542 minecraft:bone_block
setblock 254 144 510 minecraft:crying_obsidian
fill 255 144 552 256 154 552 minecraft:obsidian
fill 277 144 547 277 154 547 minecraft:obsidian
fill 235 145 518 235 146 518 minecraft:purple_concrete
fill 235 145 534 235 146 534 minecraft:purple_concrete
fill 235 145 550 235 146 550 minecraft:purple_concrete
fill 237 145 552 237 152 552 minecraft:obsidian
fill 239 145 510 239 146 510 minecraft:purple_concrete
fill 241 145 544 242 146 544 minecraft:bone_block
fill 243 145 539 246 145 539 minecraft:bone_block
setblock 245 145 538 minecraft:bone_block
setblock 246 145 510 minecraft:amethyst_block
fill 246 145 540 246 147 540 minecraft:bone_block
fill 246 145 552 246 154 552 minecraft:obsidian
fill 248 145 541 248 147 543 minecraft:bone_block
setblock 249 145 510 minecraft:white_concrete
fill 249 145 552 249 146 552 minecraft:purple_concrete
fill 250 145 510 250 154 510 minecraft:obsidian
fill 254 145 510 254 155 510 minecraft:obsidian
fill 255 145 510 255 146 510 minecraft:purple_concrete
fill 259 145 550 259 145 551 minecraft:bone_block
fill 265 145 552 265 146 552 minecraft:purple_concrete
fill 271 145 510 271 146 510 minecraft:purple_concrete
setblock 277 145 511 minecraft:amethyst_block
fill 277 145 520 277 146 520 minecraft:purple_concrete
fill 277 145 522 277 152 522 minecraft:obsidian
setblock 277 145 523 minecraft:white_concrete
fill 277 145 536 277 146 536 minecraft:purple_concrete
setblock 235 146 540 minecraft:white_concrete
fill 243 146 544 243 146 545 minecraft:bone_block
fill 244 146 540 245 146 541 minecraft:bone_block
fill 244 146 544 244 147 544 minecraft:bone_block
fill 245 146 539 246 146 539 minecraft:bone_block
fill 246 146 510 246 154 510 minecraft:obsidian
fill 246 146 541 246 147 541 minecraft:bone_block
fill 246 146 544 249 147 544 minecraft:bone_block
fill 249 146 510 249 154 510 minecraft:obsidian
fill 249 146 542 249 147 543 minecraft:bone_block
fill 257 146 549 258 147 549 minecraft:bone_block
fill 258 146 550 259 146 550 minecraft:bone_block
setblock 272 146 510 minecraft:crying_obsidian
fill 277 146 511 277 154 511 minecraft:obsidian
fill 277 146 523 277 154 523 minecraft:obsidian
setblock 277 146 534 minecraft:crying_obsidian
fill 235 147 518 235 154 518 minecraft:obsidian
fill 235 147 534 235 154 534 minecraft:obsidian
fill 235 147 540 235 150 540 minecraft:obsidian
fill 235 147 550 235 154 550 minecraft:obsidian
setblock 238 147 513 minecraft:light[level=12]
setblock 238 147 521 minecraft:light[level=12]
setblock 238 147 529 minecraft:light[level=12]
setblock 238 147 537 minecraft:light[level=12]
setblock 238 147 545 minecraft:light[level=12]
fill 239 147 510 239 151 510 minecraft:obsidian
fill 242 147 510 242 154 510 minecraft:obsidian
setblock 243 147 510 minecraft:amethyst_block
setblock 243 147 544 minecraft:bone_block
fill 244 147 545 245 147 545 minecraft:bone_block
fill 245 147 540 245 147 541 minecraft:bone_block
setblock 245 147 544 minecraft:bone_block
setblock 246 147 513 minecraft:light[level=12]
setblock 246 147 521 minecraft:light[level=12]
setblock 246 147 529 minecraft:light[level=12]
setblock 246 147 537 minecraft:light[level=12]
setblock 246 147 545 minecraft:light[level=12]
fill 247 147 545 249 147 545 minecraft:bone_block
setblock 249 147 541 minecraft:bone_block
fill 249 147 552 249 154 552 minecraft:obsidian
fill 250 147 543 250 147 544 minecraft:bone_block
setblock 250 147 552 minecraft:crying_obsidian
setblock 254 147 513 minecraft:light[level=12]
setblock 254 147 521 minecraft:light[level=12]
setblock 254 147 529 minecraft:light[level=12]
setblock 254 147 537 minecraft:light[level=12]
setblock 254 147 545 minecraft:light[level=12]
fill 255 147 510 255 154 510 minecraft:obsidian
fill 256 147 548 256 147 549 minecraft:bone_block
setblock 257 147 548 minecraft:bone_block
setblock 262 147 513 minecraft:light[level=12]
setblock 262 147 521 minecraft:light[level=12]
setblock 262 147 529 minecraft:light[level=12]
setblock 262 147 537 minecraft:light[level=12]
setblock 262 147 545 minecraft:light[level=12]
fill 265 147 552 265 154 552 minecraft:obsidian
setblock 270 147 513 minecraft:light[level=12]
setblock 270 147 521 minecraft:light[level=12]
setblock 270 147 529 minecraft:light[level=12]
setblock 270 147 537 minecraft:light[level=12]
setblock 270 147 545 minecraft:light[level=12]
fill 271 147 510 272 152 510 minecraft:obsidian
fill 277 147 520 277 152 520 minecraft:obsidian
fill 277 147 534 277 154 534 minecraft:obsidian
fill 277 147 536 277 151 536 minecraft:obsidian
fill 243 148 510 243 153 510 minecraft:obsidian
fill 250 148 552 250 154 552 minecraft:obsidian
setblock 235 149 541 minecraft:amethyst_block
setblock 260 149 510 minecraft:white_concrete
fill 261 149 510 261 154 510 minecraft:obsidian
fill 235 150 541 235 156 541 minecraft:obsidian
setblock 235 150 551 minecraft:white_concrete
fill 260 150 510 260 152 510 minecraft:obsidian
setblock 277 150 519 minecraft:crying_obsidian
fill 235 151 524 235 152 524 minecraft:black_concrete
setblock 235 151 526 minecraft:black_concrete
setblock 235 151 529 minecraft:black_concrete
setblock 235 151 540 minecraft:black_concrete
fill 235 151 547 235 151 548 minecraft:black_concrete
fill 235 151 551 235 154 551 minecraft:obsidian
setblock 237 151 510 minecraft:black_concrete
fill 239 151 552 239 152 552 minecraft:black_concrete
setblock 240 151 510 minecraft:black_concrete
setblock 253 151 510 minecraft:black_concrete
fill 254 151 529 255 151 531 minecraft:amethyst_block
setblock 254 151 552 minecraft:black_concrete
fill 255 151 528 257 151 528 minecraft:amethyst_block
fill 255 151 532 257 151 532 minecraft:amethyst_block
fill 256 151 531 258 151 531 minecraft:amethyst_block
fill 258 151 529 258 151 530 minecraft:amethyst_block
setblock 263 151 552 minecraft:black_concrete
setblock 265 151 510 minecraft:black_concrete
setblock 271 151 552 minecraft:black_concrete
fill 277 151 517 277 152 517 minecraft:black_concrete
setblock 277 151 519 minecraft:black_concrete
setblock 277 151 527 minecraft:black_concrete
setblock 277 151 528 minecraft:crying_obsidian
setblock 277 151 529 minecraft:black_concrete
setblock 277 151 549 minecraft:black_concrete
fill 277 151 551 277 153 551 minecraft:black_concrete
setblock 235 152 513 minecraft:black_concrete
setblock 235 152 520 minecraft:black_concrete
fill 235 152 526 235 154 526 minecraft:obsidian
setblock 235 152 529 minecraft:obsidian
setblock 235 152 530 minecraft:black_concrete
setblock 235 152 538 minecraft:black_concrete
fill 235 152 540 235 154 540 minecraft:obsidian
setblock 235 152 542 minecraft:crying_obsidian
setblock 235 152 547 minecraft:black_concrete
fill 235 152 548 235 154 548 minecraft:obsidian
setblock 237 152 510 minecraft:obsidian
setblock 239 152 510 minecraft:black_concrete
fill 240 152 510 240 154 510 minecraft:obsidian
fill 252 152 529 253 152 531 minecraft:amethyst_block
fill 253 152 510 253 154 510 minecraft:obsidian
fill 253 152 527 254 152 528 minecraft:amethyst_block
fill 253 152 532 254 152 533 minecraft:amethyst_block
fill 254 152 530 254 161 531 minecraft:crying_obsidian
fill 254 152 552 254 155 552 minecraft:obsidian
fill 255 152 526 255 152 527 minecraft:amethyst_block
fill 255 152 531 255 161 532 minecraft:crying_obsidian
fill 255 152 533 257 152 534 minecraft:amethyst_block
fill 256 152 526 257 152 526 minecraft:amethyst_block
fill 256 152 532 257 163 532 minecraft:crying_obsidian
fill 257 152 527 259 152 527 minecraft:amethyst_block
fill 257 152 531 258 161 531 minecraft:crying_obsidian
fill 258 152 528 259 152 528 minecraft:amethyst_block
fill 258 152 530 258 161 530 minecraft:crying_obsidian
fill 258 152 532 259 152 533 minecraft:amethyst_block
fill 259 152 529 260 152 531 minecraft:amethyst_block
setblock 260 152 552 minecraft:black_concrete
fill 263 152 552 263 154 552 minecraft:obsidian
fill 265 152 510 265 154 510 minecraft:obsidian
setblock 267 152 552 minecraft:white_concrete
fill 271 152 552 271 154 552 minecraft:obsidian
setblock 277 152 513 minecraft:black_concrete
fill 277 152 519 277 154 519 minecraft:obsidian
fill 277 152 527 277 154 530 minecraft:obsidian
setblock 277 152 531 minecraft:black_concrete
fill 277 152 532 277 154 533 minecraft:obsidian
setblock 277 152 536 minecraft:black_concrete
fill 277 152 537 277 154 537 minecraft:obsidian
setblock 277 152 538 minecraft:black_concrete
setblock 277 152 545 minecraft:black_concrete
fill 277 152 549 277 154 549 minecraft:obsidian
fill 235 153 513 235 154 513 minecraft:obsidian
fill 235 153 520 235 154 520 minecraft:obsidian
fill 235 153 521 235 153 522 minecraft:black_concrete
setblock 235 153 523 minecraft:white_concrete
fill 235 153 524 235 154 524 minecraft:obsidian
setblock 235 153 525 minecraft:black_concrete
fill 235 153 527 235 153 529 minecraft:black_concrete
fill 235 153 530 235 154 530 minecraft:obsidian
fill 235 153 538 235 154 538 minecraft:obsidian
fill 235 153 542 235 154 542 minecraft:obsidian
fill 235 153 547 235 154 547 minecraft:obsidian
setblock 235 153 549 minecraft:crying_obsidian
setblock 235 153 552 minecraft:black_concrete
setblock 237 153 510 minecraft:black_concrete
setblock 237 153 552 minecraft:black_concrete
fill 239 153 510 239 154 510 minecraft:obsidian
fill 239 153 552 239 154 552 minecraft:obsidian
setblock 245 153 552 minecraft:black_concrete
fill 251 153 529 251 153 531 minecraft:amethyst_block
setblock 251 153 552 minecraft:black_concrete
fill 252 153 527 252 153 528 minecraft:amethyst_block
fill 252 153 529 253 162 531 minecraft:crying_obsidian
fill 252 153 532 252 153 533 minecraft:amethyst_block
fill 253 153 526 254 153 526 minecraft:amethyst_block
fill 253 153 527 254 161 528 minecraft:crying_obsidian
fill 253 153 532 254 162 533 minecraft:crying_obsidian
fill 253 153 534 254 153 534 minecraft:amethyst_block
fill 255 153 525 257 153 525 minecraft:amethyst_block
fill 255 153 526 255 161 527 minecraft:crying_obsidian
fill 255 153 533 257 162 534 minecraft:crying_obsidian
fill 255 153 535 257 153 535 minecraft:amethyst_block
fill 256 153 526 257 162 526 minecraft:crying_obsidian
fill 257 153 527 259 161 527 minecraft:crying_obsidian
fill 258 153 526 259 153 526 minecraft:amethyst_block
fill 258 153 528 259 161 528 minecraft:crying_obsidian
fill 258 153 532 259 162 533 minecraft:crying_obsidian
fill 258 153 534 259 153 534 minecraft:amethyst_block
fill 259 153 529 260 162 531 minecraft:crying_obsidian
setblock 260 153 510 minecraft:black_concrete
fill 260 153 527 260 153 528 minecraft:amethyst_block
fill 260 153 532 260 153 533 minecraft:amethyst_block
fill 260 153 552 260 154 552 minecraft:obsidian
fill 261 153 529 261 153 531 minecraft:amethyst_block
fill 267 153 552 267 154 552 minecraft:obsidian
setblock 270 153 552 minecraft:black_concrete
setblock 271 153 510 minecraft:black_concrete
fill 272 153 510 272 154 510 minecraft:obsidian
setblock 272 153 552 minecraft:black_concrete
fill 277 153 513 277 154 513 minecraft:obsidian
fill 277 153 517 277 154 517 minecraft:obsidian
setblock 277 153 520 minecraft:amethyst_block
setblock 277 153 521 minecraft:crying_obsidian
setblock 277 153 522 minecraft:black_concrete
fill 277 153 531 277 154 531 minecraft:obsidian
fill 277 153 536 277 154 536 minecraft:obsidian
fill 277 153 538 277 154 538 minecraft:obsidian
setblock 277 153 540 minecraft:black_concrete
fill 277 153 545 277 154 545 minecraft:obsidian
fill 235 154 521 235 154 523 minecraft:obsidian
setblock 235 154 525 minecraft:obsidian
fill 235 154 527 235 154 529 minecraft:obsidian
setblock 235 154 549 minecraft:obsidian
setblock 235 154 552 minecraft:obsidian
setblock 237 154 510 minecraft:obsidian
setblock 237 154 552 minecraft:obsidian
setblock 243 154 510 minecraft:white_concrete
setblock 245 154 552 minecraft:obsidian
fill 250 154 530 250 161 530 minecraft:amethyst_block
fill 251 154 527 251 154 529 minecraft:amethyst_block
fill 251 154 530 251 161 530 minecraft:crying_obsidian
fill 251 154 531 251 154 533 minecraft:amethyst_block
setblock 251 154 552 minecraft:obsidian
setblock 252 154 526 minecraft:amethyst_block
fill 252 154 527 252 161 528 minecraft:crying_obsidian
fill 252 154 532 252 161 533 minecraft:crying_obsidian
setblock 252 154 534 minecraft:amethyst_block
fill 253 154 525 255 154 525 minecraft:amethyst_block
fill 253 154 526 254 161 526 minecraft:crying_obsidian
fill 253 154 534 254 161 534 minecraft:crying_obsidian
fill 253 154 535 255 154 535 minecraft:amethyst_block
fill 256 154 524 256 161 524 minecraft:amethyst_block
fill 256 154 525 256 161 525 minecraft:crying_obsidian
fill 256 154 535 256 161 535 minecraft:crying_obsidian
fill 256 154 536 256 161 536 minecraft:amethyst_block
fill 257 154 525 259 154 525 minecraft:amethyst_block
fill 257 154 535 259 154 535 minecraft:amethyst_block
fill 258 154 526 259 161 526 minecraft:crying_obsidian
fill 258 154 534 259 161 534 minecraft:crying_obsidian
setblock 260 154 510 minecraft:obsidian
setblock 260 154 526 minecraft:amethyst_block
fill 260 154 527 260 161 528 minecraft:crying_obsidian
fill 260 154 532 260 161 533 minecraft:crying_obsidian
setblock 260 154 534 minecraft:amethyst_block
fill 261 154 527 261 154 529 minecraft:amethyst_block
fill 261 154 530 261 161 530 minecraft:crying_obsidian
fill 261 154 531 261 154 533 minecraft:amethyst_block
fill 262 154 530 262 161 530 minecraft:amethyst_block
setblock 270 154 552 minecraft:obsidian
setblock 271 154 510 minecraft:obsidian
setblock 272 154 552 minecraft:obsidian
fill 277 154 520 277 154 522 minecraft:obsidian
setblock 277 154 540 minecraft:obsidian
setblock 277 154 546 minecraft:crying_obsidian
fill 277 154 551 277 155 551 minecraft:obsidian
fill 235 155 510 235 162 514 minecraft:black_concrete
fill 235 155 516 235 249 516 minecraft:black_concrete
fill 235 155 518 235 155 528 minecraft:black_concrete
setblock 235 155 529 minecraft:obsidian
fill 235 155 530 235 155 540 minecraft:black_concrete
fill 235 155 542 235 155 544 minecraft:black_concrete
fill 235 155 546 235 155 552 minecraft:black_concrete
fill 236 155 510 253 156 510 minecraft:black_concrete
fill 236 155 552 253 155 552 minecraft:black_concrete
setblock 238 155 513 minecraft:light[level=12]
setblock 238 155 521 minecraft:light[level=12]
setblock 238 155 529 minecraft:light[level=12]
setblock 238 155 537 minecraft:light[level=12]
setblock 238 155 545 minecraft:light[level=12]
setblock 246 155 513 minecraft:light[level=12]
setblock 246 155 521 minecraft:light[level=12]
setblock 246 155 529 minecraft:light[level=12]
setblock 246 155 537 minecraft:light[level=12]
setblock 246 155 545 minecraft:light[level=12]
fill 250 155 528 250 160 529 minecraft:amethyst_block
fill 250 155 531 250 160 532 minecraft:amethyst_block
fill 251 155 526 251 155 527 minecraft:amethyst_block
fill 251 155 528 251 160 529 minecraft:crying_obsidian
fill 251 155 531 251 160 532 minecraft:crying_obsidian
fill 251 155 533 251 155 534 minecraft:amethyst_block
fill 252 155 525 253 155 525 minecraft:amethyst_block
fill 252 155 526 252 160 526 minecraft:crying_obsidian
fill 252 155 534 252 160 534 minecraft:crying_obsidian
fill 252 155 535 253 155 535 minecraft:amethyst_block
setblock 254 155 513 minecraft:light[level=12]
setblock 254 155 521 minecraft:light[level=12]
fill 254 155 524 255 160 524 minecraft:amethyst_block
fill 254 155 525 255 160 525 minecraft:crying_obsidian
fill 254 155 535 255 160 535 minecraft:crying_obsidian
fill 254 155 536 255 160 536 minecraft:amethyst_block
setblock 254 155 537 minecraft:light[level=12]
setblock 254 155 545 minecraft:light[level=12]
fill 255 155 510 259 155 510 minecraft:black_concrete
fill 255 155 552 255 156 552 minecraft:black_concrete
setblock 256 155 552 minecraft:obsidian
fill 257 155 524 258 160 524 minecraft:amethyst_block
fill 257 155 525 258 160 525 minecraft:crying_obsidian
fill 257 155 535 258 160 535 minecraft:crying_obsidian
fill 257 155 536 258 160 536 minecraft:amethyst_block
fill 257 155 552 275 155 552 minecraft:black_concrete
fill 259 155 525 260 155 525 minecraft:amethyst_block
fill 259 155 535 260 155 535 minecraft:amethyst_block
setblock 260 155 510 minecraft:crying_obsidian
fill 260 155 526 260 160 526 minecraft:crying_obsidian
fill 260 155 534 260 160 534 minecraft:crying_obsidian
fill 261 155 510 261 171 510 minecraft:black_concrete
fill 261 155 526 261 155 527 minecraft:amethyst_block
fill 261 155 528 261 160 529 minecraft:crying_obsidian
fill 261 155 531 261 160 532 minecraft:crying_obsidian
fill 261 155 533 261 155 534 minecraft:amethyst_block
setblock 262 155 513 minecraft:light[level=12]
setblock 262 155 521 minecraft:light[level=12]
fill 262 155 528 262 160 529 minecraft:amethyst_block
fill 262 155 531 262 160 532 minecraft:amethyst_block
setblock 262 155 537 minecraft:light[level=12]
setblock 262 155 545 minecraft:light[level=12]
fill 263 155 510 272 158 510 minecraft:black_concrete
setblock 270 155 513 minecraft:light[level=12]
setblock 270 155 521 minecraft:light[level=12]
setblock 270 155 529 minecraft:light[level=12]
setblock 270 155 537 minecraft:light[level=12]
setblock 270 155 545 minecraft:light[level=12]
fill 275 155 510 277 156 510 minecraft:black_concrete
fill 277 155 511 277 155 517 minecraft:black_concrete
setblock 277 155 519 minecraft:black_concrete
setblock 277 155 520 minecraft:obsidian
fill 277 155 521 277 156 521 minecraft:black_concrete
setblock 277 155 522 minecraft:obsidian
fill 277 155 523 277 156 532 minecraft:black_concrete
setblock 277 155 533 minecraft:obsidian
fill 277 155 534 277 155 539 minecraft:black_concrete
setblock 277 155 540 minecraft:amethyst_block
fill 277 155 541 277 155 550 minecraft:black_concrete
setblock 235 156 515 minecraft:black_concrete
fill 235 156 517 235 156 524 minecraft:black_concrete
setblock 235 156 525 minecraft:obsidian
fill 235 156 526 235 157 529 minecraft:black_concrete
setblock 235 156 530 minecraft:obsidian
fill 235 156 531 235 161 534 minecraft:black_concrete
fill 235 156 535 235 156 536 minecraft:obsidian
fill 235 156 537 235 156 540 minecraft:black_concrete
setblock 235 156 542 minecraft:obsidian
fill 235 156 543 235 175 545 minecraft:black_concrete
setblock 235 156 546 minecraft:obsidian
fill 235 156 547 235 156 550 minecraft:black_concrete
fill 235 156 551 235 156 552 minecraft:obsidian
fill 236 156 552 249 156 552 minecraft:black_concrete
fill 250 156 527 250 159 527 minecraft:amethyst_block
fill 250 156 533 250 159 533 minecraft:amethyst_block
setblock 250 156 552 minecraft:obsidian
fill 251 156 526 251 160 526 minecraft:amethyst_block
fill 251 156 527 251 159 527 minecraft:crying_obsidian
fill 251 156 533 251 159 533 minecraft:crying_obsidian
fill 251 156 534 251 160 534 minecraft:amethyst_block
fill 251 156 552 254 156 552 minecraft:black_concrete
fill 252 156 525 252 160 525 minecraft:amethyst_block
fill 252 156 535 252 160 535 minecraft:amethyst_block
fill 253 156 524 253 159 524 minecraft:amethyst_block
fill 253 156 525 253 159 525 minecraft:crying_obsidian
fill 253 156 535 253 159 535 minecraft:crying_obsidian
fill 253 156 536 253 159 536 minecraft:amethyst_block
fill 254 156 510 257 156 510 minecraft:black_concrete
fill 256 156 552 258 190 552 minecraft:black_concrete
setblock 258 156 510 minecraft:obsidian
fill 259 156 510 260 227 510 minecraft:black_concrete
fill 259 156 524 259 159 524 minecraft:amethyst_block
fill 259 156 525 259 159 525 minecraft:crying_obsidian
fill 259 156 535 259 159 535 minecraft:crying_obsidian
fill 259 156 536 259 159 536 minecraft:amethyst_block
setblock 259 156 552 minecraft:obsidian
fill 260 156 525 260 160 525 minecraft:amethyst_block
fill 260 156 535 260 160 535 minecraft:amethyst_block
fill 260 156 552 277 156 552 minecraft:black_concrete
fill 261 156 526 261 160 526 minecraft:amethyst_block
fill 261 156 527 261 159 527 minecraft:crying_obsidian
fill 261 156 533 261 159 533 minecraft:crying_obsidian
fill 261 156 534 261 160 534 minecraft:amethyst_block
fill 262 156 510 262 237 510 minecraft:black_concrete
fill 262 156 527 262 159 527 minecraft:amethyst_block
fill 262 156 533 262 159 533 minecraft:amethyst_block
fill 273 156 510 274 201 510 minecraft:black_concrete
setblock 277 156 511 minecraft:obsidian
fill 277 156 512 277 156 518 minecraft:black_concrete
setblock 277 156 519 minecraft:obsidian
fill 277 156 520 277 170 520 minecraft:black_concrete
fill 277 156 522 277 226 522 minecraft:black_concrete
setblock 277 156 533 minecraft:black_concrete
setblock 277 156 534 minecraft:obsidian
fill 277 156 535 277 156 544 minecraft:black_concrete
setblock 277 156 545 minecraft:obsidian
fill 277 156 546 277 176 551 minecraft:black_concrete
setblock 235 157 515 minecraft:obsidian
fill 235 157 517 235 307 517 minecraft:black_concrete
setblock 235 157 518 minecraft:obsidian
fill 235 157 519 235 159 521 minecraft:black_concrete
setblock 235 157 522 minecraft:obsidian
fill 235 157 523 235 187 525 minecraft:black_concrete
fill 235 157 530 235 297 530 minecraft:black_concrete
fill 235 157 535 235 159 538 minecraft:black_concrete
setblock 235 157 539 minecraft:obsidian
fill 235 157 540 235 232 542 minecraft:black_concrete
fill 235 157 546 235 190 547 minecraft:black_concrete
setblock 235 157 548 minecraft:obsidian
fill 235 157 549 235 160 551 minecraft:black_concrete
setblock 235 157 552 minecraft:obsidian
fill 236 157 510 247 160 510 minecraft:black_concrete
fill 236 157 552 237 179 552 minecraft:black_concrete
setblock 238 157 552 minecraft:obsidian
fill 239 157 552 251 166 552 minecraft:black_concrete
setblock 248 157 510 minecraft:obsidian
fill 249 157 510 250 195 510 minecraft:black_concrete
setblock 251 157 510 minecraft:obsidian
fill 252 157 510 254 161 510 minecraft:black_concrete
fill 252 157 552 253 157 552 minecraft:obsidian
fill 254 157 552 254 194 552 minecraft:black_concrete
fill 255 157 510 257 157 510 minecraft:obsidian
setblock 255 157 552 minecraft:obsidian
fill 258 157 510 258 307 510 minecraft:black_concrete
fill 259 157 552 264 171 552 minecraft:black_concrete
fill 265 157 552 266 157 552 minecraft:obsidian
fill 267 157 552 267 177 552 minecraft:black_concrete
setblock 268 157 552 minecraft:obsidian
fill 269 157 552 270 192 552 minecraft:black_concrete
setblock 271 157 552 minecraft:obsidian
fill 272 157 552 277 157 552 minecraft:black_concrete
fill 275 157 510 276 200 510 minecraft:black_concrete
setblock 277 157 510 minecraft:obsidian
fill 277 157 511 277 198 513 minecraft:black_concrete
setblock 277 157 514 minecraft:obsidian
fill 277 157 515 277 224 516 minecraft:black_concrete
setblock 277 157 517 minecraft:obsidian
fill 277 157 518 277 264 519 minecraft:black_concrete
setblock 277 157 521 minecraft:obsidian
fill 277 157 523 277 184 525 minecraft:black_concrete
setblock 277 157 526 minecraft:crying_obsidian
fill 277 157 527 277 157 528 minecraft:black_concrete
setblock 277 157 529 minecraft:obsidian
fill 277 157 530 277 177 532 minecraft:black_concrete
setblock 277 157 533 minecraft:obsidian
fill 277 157 534 277 167 538 minecraft:black_concrete
setblock 277 157 539 minecraft:obsidian
fill 277 157 540 277 176 544 minecraft:black_concrete
setblock 277 157 545 minecraft:amethyst_block
fill 235 158 515 235 251 515 minecraft:black_concrete
fill 235 158 518 235 170 518 minecraft:black_concrete
fill 235 158 522 235 219 522 minecraft:black_concrete
fill 235 158 526 235 189 526 minecraft:black_concrete
setblock 235 158 527 minecraft:amethyst_block
fill 235 158 528 235 166 529 minecraft:black_concrete
fill 235 158 539 235 184 539 minecraft:black_concrete
fill 235 158 548 235 203 548 minecraft:black_concrete
fill 235 158 552 235 307 552 minecraft:black_concrete
fill 238 158 552 238 244 552 minecraft:black_concrete
fill 248 158 510 248 164 510 minecraft:black_concrete
fill 251 158 510 251 198 510 minecraft:black_concrete
fill 252 158 552 253 170 552 minecraft:black_concrete
fill 255 158 510 255 170 510 minecraft:black_concrete
setblock 255 158 552 minecraft:amethyst_block
setblock 256 158 510 minecraft:crying_obsidian
fill 257 158 510 257 197 510 minecraft:black_concrete
fill 265 158 552 266 170 552 minecraft:black_concrete
setblock 268 158 552 minecraft:crying_obsidian
setblock 271 158 552 minecraft:amethyst_block
fill 272 158 552 274 192 552 minecraft:black_concrete
setblock 275 158 552 minecraft:crying_obsidian
fill 276 158 552 277 197 552 minecraft:black_concrete
fill 277 158 510 277 307 510 minecraft:black_concrete
fill 277 158 514 277 180 514 minecraft:black_concrete
fill 277 158 517 277 191 517 minecraft:black_concrete
fill 277 158 521 277 182 521 minecraft:black_concrete
fill 277 158 526 277 191 526 minecraft:black_concrete
setblock 277 158 527 minecraft:white_concrete
fill 277 158 528 277 180 529 minecraft:black_concrete
fill 277 158 533 277 184 533 minecraft:black_concrete
fill 277 158 539 277 282 539 minecraft:black_concrete
fill 277 158 545 277 240 545 minecraft:black_concrete
fill 235 159 527 235 214 527 minecraft:black_concrete
fill 255 159 552 255 267 552 minecraft:black_concrete
fill 256 159 510 256 198 510 minecraft:black_concrete
fill 263 159 510 266 180 510 minecraft:black_concrete
setblock 267 159 510 minecraft:crying_obsidian
fill 268 159 510 272 170 510 minecraft:black_concrete
fill 268 159 552 268 307 552 minecraft:black_concrete
fill 271 159 552 271 172 552 minecraft:black_concrete
fill 275 159 552 275 291 552 minecraft:black_concrete
fill 277 159 527 277 168 527 minecraft:black_concrete
setblock 235 160 519 minecraft:amethyst_block
fill 235 160 520 235 171 521 minecraft:black_concrete
fill 235 160 535 235 178 536 minecraft:black_concrete
setblock 235 160 537 minecraft:crying_obsidian
fill 235 160 538 235 198 538 minecraft:black_concrete
fill 251 160 527 251 161 527 minecraft:amethyst_block
fill 251 160 533 251 161 533 minecraft:amethyst_block
fill 253 160 525 253 161 525 minecraft:amethyst_block
fill 253 160 535 253 161 535 minecraft:amethyst_block
fill 259 160 525 259 161 525 minecraft:amethyst_block
fill 259 160 535 259 161 535 minecraft:amethyst_block
fill 261 160 527 261 161 527 minecraft:amethyst_block
fill 261 160 533 261 161 533 minecraft:amethyst_block
fill 267 160 510 267 229 510 minecraft:black_concrete
fill 235 161 519 235 165 519 minecraft:black_concrete
fill 235 161 537 235 196 537 minecraft:black_concrete
setblock 235 161 549 minecraft:white_concrete
fill 235 161 550 235 170 551 minecraft:black_concrete
fill 236 161 510 246 170 510 minecraft:black_concrete
setblock 247 161 510 minecraft:amethyst_block
fill 251 161 528 251 161 529 minecraft:amethyst_block
fill 251 161 531 251 161 532 minecraft:amethyst_block
setblock 252 161 526 minecraft:amethyst_block
setblock 252 161 534 minecraft:amethyst_block
fill 254 161 525 255 161 525 minecraft:amethyst_block
fill 254 161 535 255 161 535 minecraft:amethyst_block
fill 257 161 525 258 161 525 minecraft:amethyst_block
fill 257 161 535 258 161 535 minecraft:amethyst_block
setblock 260 161 526 minecraft:amethyst_block
setblock 260 161 534 minecraft:amethyst_block
fill 261 161 528 261 161 529 minecraft:amethyst_block
fill 261 161 531 261 161 532 minecraft:amethyst_block
fill 235 162 531 235 180 533 minecraft:black_concrete
setblock 235 162 534 minecraft:crying_obsidian
fill 235 162 549 235 226 549 minecraft:black_concrete
fill 236 162 511 250 162 551 minecraft:obsidian
fill 247 162 510 247 165 510 minecraft:black_concrete
fill 251 162 511 251 162 528 minecraft:obsidian
fill 251 162 529 251 162 531 minecraft:amethyst_block
fill 251 162 532 251 162 551 minecraft:obsidian
fill 252 162 510 253 177 510 minecraft:black_concrete
fill 252 162 511 252 162 526 minecraft:obsidian
fill 252 162 527 252 162 528 minecraft:amethyst_block
fill 252 162 532 252 162 533 minecraft:amethyst_block
fill 252 162 534 252 162 551 minecraft:obsidian
fill 253 162 511 254 162 525 minecraft:obsidian
fill 253 162 526 254 162 526 minecraft:amethyst_block
fill 253 162 527 253 162 528 minecraft:crying_obsidian
fill 253 162 534 254 162 534 minecraft:amethyst_block
fill 253 162 535 254 162 551 minecraft:obsidian
setblock 254 162 510 minecraft:crying_obsidian
fill 254 162 527 254 162 528 minecraft:shroomlight
fill 254 162 530 254 162 531 minecraft:shroomlight
fill 255 162 511 276 162 524 minecraft:obsidian
fill 255 162 525 257 162 525 minecraft:amethyst_block
setblock 255 162 526 minecraft:crying_obsidian
setblock 255 162 527 minecraft:shroomlight
setblock 255 162 531 minecraft:shroomlight
fill 255 162 532 255 163 532 minecraft:crying_obsidian
fill 255 162 535 257 162 535 minecraft:amethyst_block
fill 255 162 536 276 162 551 minecraft:obsidian
fill 257 162 527 258 162 527 minecraft:shroomlight
fill 257 162 531 258 162 531 minecraft:shroomlight
fill 258 162 525 276 162 525 minecraft:obsidian
fill 258 162 526 259 162 526 minecraft:amethyst_block
setblock 258 162 528 minecraft:shroomlight
setblock 258 162 530 minecraft:shroomlight
fill 258 162 534 259 162 534 minecraft:amethyst_block
fill 258 162 535 276 162 535 minecraft:obsidian
fill 259 162 527 259 162 528 minecraft:crying_obsidian
fill 260 162 526 276 162 526 minecraft:obsidian
fill 260 162 527 260 162 528 minecraft:amethyst_block
fill 260 162 532 260 162 533 minecraft:amethyst_block
fill 260 162 534 276 162 534 minecraft:obsidian
fill 261 162 527 276 162 528 minecraft:obsidian
fill 261 162 529 261 162 531 minecraft:amethyst_block
fill 261 162 532 276 162 533 minecraft:obsidian
fill 262 162 529 276 162 531 minecraft:obsidian
fill 235 163 510 235 307 510 minecraft:black_concrete
setblock 235 163 511 minecraft:white_concrete
fill 235 163 512 235 207 514 minecraft:black_concrete
fill 235 163 534 235 170 534 minecraft:black_concrete
fill 236 163 517 237 163 541 minecraft:basalt
setblock 237 163 516 minecraft:basalt
fill 237 163 542 240 163 542 minecraft:basalt
setblock 238 163 513 minecraft:light[level=12]
fill 238 163 514 240 163 515 minecraft:basalt
setblock 238 163 516 minecraft:magma_block
fill 238 163 517 240 165 518 minecraft:basalt
setblock 238 163 519 minecraft:magma_block
fill 238 163 520 240 166 521 minecraft:basalt
setblock 238 163 522 minecraft:magma_block
fill 238 163 523 240 168 524 minecraft:basalt
setblock 238 163 525 minecraft:magma_block
fill 238 163 526 240 168 527 minecraft:basalt
setblock 238 163 528 minecraft:magma_block
fill 238 163 529 240 168 530 minecraft:basalt
setblock 238 163 531 minecraft:magma_block
fill 238 163 532 240 168 533 minecraft:basalt
setblock 238 163 534 minecraft:magma_block
fill 238 163 535 240 167 536 minecraft:basalt
setblock 238 163 537 minecraft:magma_block
fill 238 163 538 240 165 539 minecraft:basalt
setblock 238 163 540 minecraft:magma_block
fill 238 163 541 243 165 541 minecraft:basalt
setblock 238 163 543 minecraft:magma_block
fill 238 163 544 243 163 544 minecraft:basalt
setblock 238 163 545 minecraft:light[level=12]
fill 239 163 513 246 163 513 minecraft:basalt
fill 239 163 516 246 164 516 minecraft:basalt
fill 239 163 519 245 167 519 minecraft:basalt
fill 239 163 522 243 163 522 minecraft:basalt
fill 239 163 525 241 169 525 minecraft:basalt
fill 239 163 528 241 170 528 minecraft:basalt
fill 239 163 531 241 170 531 minecraft:basalt
fill 239 163 534 242 169 534 minecraft:basalt
fill 239 163 537 243 168 537 minecraft:basalt
fill 239 163 540 246 166 540 minecraft:basalt
fill 239 163 543 246 164 543 minecraft:basalt
fill 239 163 545 240 163 545 minecraft:basalt
setblock 240 163 512 minecraft:basalt
fill 240 163 546 246 163 546 minecraft:basalt
fill 241 163 511 243 163 511 minecraft:basalt
setblock 241 163 512 minecraft:magma_block
fill 241 163 514 243 165 514 minecraft:basalt
setblock 241 163 515 minecraft:magma_block
fill 241 163 517 243 167 517 minecraft:basalt
setblock 241 163 518 minecraft:magma_block
fill 241 163 520 243 169 520 minecraft:basalt
setblock 241 163 521 minecraft:magma_block
fill 241 163 523 242 171 523 minecraft:basalt
setblock 241 163 524 minecraft:magma_block
fill 241 163 526 241 172 526 minecraft:basalt
setblock 241 163 527 minecraft:magma_block
fill 241 163 529 241 172 529 minecraft:basalt
setblock 241 163 530 minecraft:magma_block
fill 241 163 532 241 172 532 minecraft:basalt
setblock 241 163 533 minecraft:magma_block
fill 241 163 535 242 171 535 minecraft:basalt
setblock 241 163 536 minecraft:magma_block
fill 241 163 538 243 169 538 minecraft:basalt
setblock 241 163 539 minecraft:magma_block
setblock 241 163 542 minecraft:magma_block
setblock 241 163 545 minecraft:magma_block
fill 241 163 547 243 163 547 minecraft:basalt
fill 242 163 512 249 164 512 minecraft:basalt
fill 242 163 515 249 167 515 minecraft:basalt
fill 242 163 518 246 169 518 minecraft:basalt
fill 242 163 521 243 171 521 minecraft:basalt
fill 242 163 524 242 172 524 minecraft:basalt
fill 242 163 536 243 172 536 minecraft:basalt
fill 242 163 539 245 170 539 minecraft:basalt
fill 242 163 542 249 168 542 minecraft:basalt
fill 242 163 545 249 164 545 minecraft:basalt
fill 243 163 548 249 163 548 minecraft:basalt
setblock 244 163 511 minecraft:magma_block
setblock 244 163 514 minecraft:magma_block
setblock 244 163 517 minecraft:magma_block
setblock 244 163 520 minecraft:magma_block
setblock 244 163 538 minecraft:magma_block
setblock 244 163 541 minecraft:magma_block
setblock 244 163 544 minecraft:magma_block
setblock 244 163 547 minecraft:magma_block
fill 244 163 549 246 163 549 minecraft:basalt
fill 245 163 511 252 164 511 minecraft:basalt
fill 245 163 514 252 168 514 minecraft:basalt
fill 245 163 517 247 171 517 minecraft:basalt
fill 245 163 541 247 171 541 minecraft:basalt
fill 245 163 544 252 168 544 minecraft:basalt
fill 245 163 547 252 164 547 minecraft:basalt
setblock 246 163 521 minecraft:light[level=12]
setblock 246 163 529 minecraft:light[level=12]
setblock 246 163 537 minecraft:light[level=12]
fill 246 163 550 252 163 550 minecraft:basalt
setblock 247 163 513 minecraft:magma_block
setblock 247 163 516 minecraft:magma_block
setblock 247 163 543 minecraft:magma_block
setblock 247 163 546 minecraft:magma_block
setblock 247 163 549 minecraft:magma_block
fill 248 163 513 255 169 513 minecraft:basalt
fill 248 163 516 249 172 516 minecraft:basalt
fill 248 163 543 251 171 543 minecraft:basalt
fill 248 163 546 255 168 546 minecraft:basalt
fill 248 163 549 255 164 549 minecraft:basalt
fill 248 163 551 249 163 551 minecraft:basalt
setblock 250 163 512 minecraft:magma_block
setblock 250 163 515 minecraft:magma_block
setblock 250 163 545 minecraft:magma_block
setblock 250 163 548 minecraft:magma_block
setblock 250 163 551 minecraft:magma_block
fill 251 163 512 258 169 512 minecraft:basalt
fill 251 163 515 251 172 515 minecraft:basalt
fill 251 163 545 258 170 545 minecraft:basalt
fill 251 163 548 258 166 548 minecraft:basalt
fill 251 163 551 258 163 551 minecraft:basalt
fill 252 163 529 253 163 531 minecraft:amethyst_block
setblock 253 163 511 minecraft:magma_block
setblock 253 163 514 minecraft:magma_block
fill 253 163 527 254 163 528 minecraft:amethyst_block
fill 253 163 532 254 163 533 minecraft:amethyst_block
setblock 253 163 544 minecraft:magma_block
setblock 253 163 547 minecraft:magma_block
setblock 253 163 550 minecraft:magma_block
fill 254 163 510 254 196 510 minecraft:black_concrete
fill 254 163 511 261 167 511 minecraft:basalt
fill 254 163 514 261 171 514 minecraft:basalt
setblock 254 163 521 minecraft:light[level=12]
fill 254 163 530 254 163 531 minecraft:crying_obsidian
setblock 254 163 537 minecraft:light[level=12]
fill 254 163 544 261 171 544 minecraft:basalt
fill 254 163 547 261 167 547 minecraft:basalt
fill 254 163 550 261 164 550 minecraft:basalt
fill 255 163 526 255 163 527 minecraft:amethyst_block
setblock 255 163 531 minecraft:crying_obsidian
fill 255 163 533 257 163 534 minecraft:amethyst_block
setblock 256 163 513 minecraft:magma_block
fill 256 163 526 257 163 526 minecraft:amethyst_block
setblock 256 163 546 minecraft:magma_block
setblock 256 163 549 minecraft:magma_block
fill 257 163 513 264 169 513 minecraft:basalt
fill 257 163 527 259 163 527 minecraft:amethyst_block
fill 257 163 546 264 167 546 minecraft:basalt
fill 257 163 549 264 165 549 minecraft:basalt
fill 258 163 528 259 163 528 minecraft:amethyst_block
fill 258 163 530 258 163 531 minecraft:crying_obsidian
fill 258 163 532 259 163 533 minecraft:amethyst_block
setblock 259 163 512 minecraft:magma_block
fill 259 163 529 260 163 531 minecraft:amethyst_block
setblock 259 163 545 minecraft:magma_block
setblock 259 163 548 minecraft:magma_block
setblock 259 163 551 minecraft:magma_block
fill 260 163 512 267 166 512 minecraft:basalt
fill 260 163 545 267 167 545 minecraft:basalt
fill 260 163 548 267 164 548 minecraft:basalt
fill 260 163 551 264 163 551 minecraft:basalt
fill 261 163 515 267 169 515 minecraft:basalt
fill 261 163 543 264 163 543 minecraft:basalt
setblock 262 163 511 minecraft:magma_block
setblock 262 163 514 minecraft:magma_block
setblock 262 163 521 minecraft:light[level=12]
setblock 262 163 529 minecraft:light[level=12]
setblock 262 163 537 minecraft:light[level=12]
setblock 262 163 544 minecraft:magma_block
setblock 262 163 547 minecraft:magma_block
setblock 262 163 550 minecraft:magma_block
fill 263 163 511 270 163 511 minecraft:basalt
fill 263 163 514 270 166 514 minecraft:basalt
fill 263 163 516 264 172 516 minecraft:basalt
fill 263 163 542 267 169 542 minecraft:basalt
fill 263 163 544 270 166 544 minecraft:basalt
fill 263 163 547 270 163 547 minecraft:basalt
fill 263 163 550 266 163 550 minecraft:basalt
setblock 265 163 513 minecraft:magma_block
setblock 265 163 516 minecraft:magma_block
fill 265 163 517 270 168 517 minecraft:basalt
fill 265 163 541 270 168 541 minecraft:basalt
setblock 265 163 543 minecraft:magma_block
setblock 265 163 546 minecraft:magma_block
setblock 265 163 549 minecraft:magma_block
fill 266 163 513 273 163 513 minecraft:basalt
fill 266 163 516 273 165 516 minecraft:basalt
fill 266 163 518 267 172 518 minecraft:basalt
fill 266 163 540 273 166 540 minecraft:basalt
fill 266 163 543 273 164 543 minecraft:basalt
fill 266 163 546 272 163 546 minecraft:basalt
fill 266 163 549 268 163 549 minecraft:basalt
fill 267 163 519 273 167 519 minecraft:basalt
fill 267 163 539 267 172 539 minecraft:basalt
setblock 268 163 512 minecraft:magma_block
setblock 268 163 515 minecraft:magma_block
setblock 268 163 518 minecraft:magma_block
fill 268 163 520 270 169 520 minecraft:basalt
fill 268 163 538 270 169 538 minecraft:basalt
setblock 268 163 539 minecraft:magma_block
setblock 268 163 542 minecraft:magma_block
setblock 268 163 545 minecraft:magma_block
setblock 268 163 548 minecraft:magma_block
fill 269 163 512 272 163 512 minecraft:basalt
fill 269 163 515 274 163 515 minecraft:basalt
fill 269 163 518 276 163 518 minecraft:basalt
fill 269 163 521 273 168 522 minecraft:basalt
fill 269 163 536 273 168 537 minecraft:basalt
fill 269 163 539 276 164 539 minecraft:basalt
fill 269 163 542 275 163 542 minecraft:basalt
fill 269 163 545 273 163 545 minecraft:basalt
setblock 269 163 548 minecraft:basalt
fill 270 163 523 270 172 524 minecraft:basalt
setblock 270 163 529 minecraft:light[level=12]
fill 270 163 534 270 163 535 minecraft:basalt
setblock 271 163 511 minecraft:magma_block
setblock 271 163 514 minecraft:magma_block
setblock 271 163 517 minecraft:magma_block
setblock 271 163 520 minecraft:magma_block
setblock 271 163 523 minecraft:magma_block
fill 271 163 524 273 169 525 minecraft:basalt
setblock 271 163 526 minecraft:magma_block
fill 271 163 527 273 169 528 minecraft:basalt
setblock 271 163 529 minecraft:magma_block
fill 271 163 530 273 169 531 minecraft:basalt
setblock 271 163 532 minecraft:magma_block
fill 271 163 533 273 169 534 minecraft:basalt
setblock 271 163 535 minecraft:magma_block
setblock 271 163 538 minecraft:magma_block
setblock 271 163 541 minecraft:magma_block
setblock 271 163 544 minecraft:magma_block
setblock 271 163 547 minecraft:magma_block
fill 272 163 514 274 163 514 minecraft:basalt
fill 272 163 517 276 163 517 minecraft:basalt
fill 272 163 520 276 163 520 minecraft:basalt
fill 272 163 523 276 166 523 minecraft:basalt
fill 272 163 526 276 166 526 minecraft:basalt
fill 272 163 529 276 167 529 minecraft:basalt
fill 272 163 532 276 166 532 minecraft:basalt
fill 272 163 535 276 166 535 minecraft:basalt
fill 272 163 538 276 163 538 minecraft:basalt
fill 272 163 541 276 163 541 minecraft:basalt
fill 272 163 544 274 163 544 minecraft:basalt
setblock 274 163 516 minecraft:magma_block
setblock 274 163 519 minecraft:magma_block
fill 274 163 521 276 165 521 minecraft:basalt
setblock 274 163 522 minecraft:magma_block
fill 274 163 524 276 166 524 minecraft:basalt
setblock 274 163 525 minecraft:magma_block
fill 274 163 527 276 166 527 minecraft:basalt
setblock 274 163 528 minecraft:magma_block
fill 274 163 530 276 167 530 minecraft:basalt
setblock 274 163 531 minecraft:magma_block
fill 274 163 533 276 166 533 minecraft:basalt
setblock 274 163 534 minecraft:magma_block
fill 274 163 536 276 165 536 minecraft:basalt
setblock 274 163 537 minecraft:magma_block
setblock 274 163 540 minecraft:magma_block
setblock 274 163 543 minecraft:magma_block
setblock 275 163 516 minecraft:basalt
fill 275 163 519 276 164 519 minecraft:basalt
fill 275 163 522 276 165 522 minecraft:basalt
fill 275 163 525 276 166 525 minecraft:basalt
fill 275 163 528 276 166 528 minecraft:basalt
fill 275 163 531 276 166 531 minecraft:basalt
fill 275 163 534 276 166 534 minecraft:basalt
fill 275 163 537 276 165 537 minecraft:basalt
fill 275 163 540 276 163 540 minecraft:basalt
fill 235 164 511 235 218 511 minecraft:black_concrete
fill 236 164 519 237 164 539 minecraft:basalt
setblock 237 164 517 minecraft:basalt
setblock 237 164 518 minecraft:magma_block
fill 237 164 540 237 164 541 minecraft:basalt
setblock 238 164 516 minecraft:basalt
fill 238 164 519 238 166 519 minecraft:basalt
fill 238 164 522 242 167 522 minecraft:basalt
fill 238 164 525 238 168 525 minecraft:basalt
fill 238 164 528 238 169 528 minecraft:basalt
fill 238 164 531 238 169 531 minecraft:basalt
fill 238 164 534 238 168 534 minecraft:basalt
fill 238 164 537 238 167 537 minecraft:basalt
fill 238 164 540 238 165 540 minecraft:basalt
fill 238 164 542 241 164 542 minecraft:basalt
fill 239 164 514 239 164 515 minecraft:basalt
setblock 239 164 544 minecraft:basalt
fill 240 164 513 247 164 513 minecraft:basalt
setblock 240 164 514 minecraft:magma_block
fill 240 164 515 241 165 515 minecraft:basalt
setblock 240 164 544 minecraft:magma_block
fill 240 164 545 241 164 545 minecraft:basalt
setblock 241 164 512 minecraft:basalt
fill 241 164 518 241 168 518 minecraft:basalt
fill 241 164 521 241 170 521 minecraft:basalt
fill 241 164 524 241 171 524 minecraft:basalt
fill 241 164 527 242 164 527 minecraft:basalt
fill 241 164 530 241 171 530 minecraft:basalt
fill 241 164 533 242 171 533 minecraft:basalt
fill 241 164 536 241 171 536 minecraft:basalt
fill 241 164 539 241 169 539 minecraft:basalt
fill 241 164 544 244 165 544 minecraft:basalt
fill 241 164 546 247 164 546 minecraft:basalt
fill 242 164 525 242 173 526 minecraft:basalt
fill 242 164 531 242 173 532 minecraft:basalt
fill 243 164 511 244 164 511 minecraft:basalt
setblock 243 164 522 minecraft:magma_block
fill 243 164 523 243 173 523 minecraft:basalt
fill 243 164 535 243 173 535 minecraft:basalt
fill 243 164 547 244 164 547 minecraft:basalt
fill 244 164 514 244 167 514 minecraft:basalt
fill 244 164 517 244 170 517 minecraft:basalt
fill 244 164 520 244 171 521 minecraft:basalt
fill 244 164 537 244 171 538 minecraft:basalt
fill 244 164 541 244 170 541 minecraft:basalt
fill 244 164 548 250 164 548 minecraft:basalt
fill 245 164 520 245 173 520 minecraft:basalt
fill 245 164 538 245 173 538 minecraft:basalt
fill 246 164 519 246 173 519 minecraft:basalt
setblock 246 164 539 minecraft:magma_block
fill 246 164 549 247 164 549 minecraft:basalt
fill 247 164 516 247 171 516 minecraft:basalt
fill 247 164 518 247 173 518 minecraft:basalt
fill 247 164 540 247 173 540 minecraft:basalt
fill 247 164 543 247 170 543 minecraft:basalt
fill 248 164 517 248 173 517 minecraft:basalt
fill 248 164 541 248 173 541 minecraft:basalt
setblock 248 164 550 minecraft:basalt
setblock 249 164 550 minecraft:magma_block
fill 250 164 512 250 169 512 minecraft:basalt
fill 250 164 515 250 171 516 minecraft:basalt
fill 250 164 542 250 173 542 minecraft:basalt
fill 250 164 545 250 170 545 minecraft:basalt
fill 250 164 550 253 164 550 minecraft:basalt
fill 251 164 551 254 164 551 minecraft:basalt
fill 252 164 515 254 173 515 minecraft:basalt
setblock 252 164 543 minecraft:magma_block
fill 253 164 511 253 169 511 minecraft:basalt
fill 253 164 514 253 171 514 minecraft:basalt
fill 253 164 543 253 171 544 minecraft:basalt
fill 253 164 547 253 169 547 minecraft:basalt
fill 254 164 530 254 164 531 minecraft:amethyst_block
fill 254 164 543 254 173 543 minecraft:basalt
fill 255 164 531 255 164 532 minecraft:amethyst_block
setblock 255 164 551 minecraft:magma_block
fill 256 164 513 256 171 513 minecraft:basalt
fill 256 164 532 257 164 532 minecraft:amethyst_block
fill 256 164 546 256 170 546 minecraft:basalt
fill 256 164 549 256 167 549 minecraft:basalt
fill 256 164 551 261 164 551 minecraft:basalt
fill 258 164 515 260 173 515 minecraft:basalt
fill 258 164 530 258 164 531 minecraft:amethyst_block
fill 258 164 543 260 173 543 minecraft:basalt
fill 259 164 512 259 170 512 minecraft:basalt
fill 259 164 545 259 171 545 minecraft:basalt
fill 259 164 548 259 167 548 minecraft:basalt
setblock 261 164 543 minecraft:magma_block
fill 262 164 511 269 164 511 minecraft:basalt
fill 262 164 514 262 171 514 minecraft:basalt
fill 262 164 516 262 173 516 minecraft:basalt
fill 262 164 542 262 171 544 minecraft:basalt
fill 262 164 547 269 164 547 minecraft:basalt
fill 262 164 550 264 164 550 minecraft:basalt
fill 263 164 543 265 170 543 minecraft:basalt
fill 264 164 517 264 173 517 minecraft:basalt
fill 264 164 541 264 173 541 minecraft:basalt
fill 265 164 513 272 164 513 minecraft:basalt
fill 265 164 516 265 171 516 minecraft:basalt
fill 265 164 518 265 173 518 minecraft:basalt
fill 265 164 540 265 173 540 minecraft:basalt
fill 265 164 546 269 165 546 minecraft:basalt
fill 265 164 549 266 164 549 minecraft:basalt
fill 266 164 519 266 173 519 minecraft:basalt
fill 266 164 539 266 173 539 minecraft:basalt
setblock 267 164 520 minecraft:magma_block
setblock 267 164 538 minecraft:magma_block
fill 268 164 512 271 164 512 minecraft:basalt
fill 268 164 515 272 165 515 minecraft:basalt
fill 268 164 518 275 164 518 minecraft:basalt
fill 268 164 521 268 173 521 minecraft:basalt
fill 268 164 537 268 173 537 minecraft:basalt
fill 268 164 539 268 171 539 minecraft:basalt
fill 268 164 542 274 164 542 minecraft:basalt
fill 268 164 545 272 164 545 minecraft:basalt
setblock 268 164 548 minecraft:basalt
fill 269 164 523 269 173 523 minecraft:basalt
fill 269 164 535 271 171 535 minecraft:basalt
setblock 270 164 525 minecraft:magma_block
fill 270 164 526 270 173 527 minecraft:basalt
setblock 270 164 531 minecraft:magma_block
fill 270 164 532 270 173 533 minecraft:basalt
setblock 270 164 534 minecraft:magma_block
setblock 270 164 546 minecraft:magma_block
fill 271 164 514 273 164 514 minecraft:basalt
fill 271 164 517 275 164 517 minecraft:basalt
fill 271 164 520 275 165 520 minecraft:basalt
fill 271 164 523 271 171 523 minecraft:basalt
fill 271 164 526 271 171 526 minecraft:basalt
fill 271 164 529 271 171 529 minecraft:basalt
fill 271 164 532 271 171 532 minecraft:basalt
fill 271 164 538 275 165 538 minecraft:basalt
fill 271 164 541 275 164 541 minecraft:basalt
fill 271 164 544 273 164 544 minecraft:basalt
setblock 271 164 546 minecraft:basalt
setblock 273 164 515 minecraft:magma_block
setblock 274 164 516 minecraft:basalt
fill 274 164 519 274 166 519 minecraft:basalt
fill 274 164 522 274 167 522 minecraft:basalt
fill 274 164 525 274 168 525 minecraft:basalt
fill 274 164 528 274 169 528 minecraft:basalt
fill 274 164 531 274 169 531 minecraft:basalt
fill 274 164 534 274 168 534 minecraft:basalt
fill 274 164 537 274 167 537 minecraft:basalt
fill 274 164 540 275 164 540 minecraft:basalt
setblock 276 164 520 minecraft:magma_block
setblock 276 164 538 minecraft:magma_block
fill 236 165 521 237 165 522 minecraft:basalt
setblock 236 165 523 minecraft:magma_block
fill 236 165 524 237 166 534 minecraft:basalt
setblock 236 165 535 minecraft:magma_block
fill 236 165 536 237 165 537 minecraft:basalt
fill 237 165 519 237 165 520 minecraft:basalt
fill 237 165 523 237 166 523 minecraft:basalt
fill 237 165 535 237 166 535 minecraft:basalt
fill 237 165 538 237 165 539 minecraft:basalt
setblock 239 165 516 minecraft:magma_block
fill 239 165 542 241 165 542 minecraft:basalt
fill 240 165 516 246 166 516 minecraft:basalt
fill 240 165 543 246 165 543 minecraft:basalt
fill 241 165 527 241 171 527 minecraft:basalt
fill 242 165 513 247 165 513 minecraft:basalt
setblock 242 165 527 minecraft:magma_block
fill 242 165 528 242 173 529 minecraft:basalt
setblock 242 165 530 minecraft:magma_block
setblock 242 165 545 minecraft:magma_block
fill 243 165 512 249 165 512 minecraft:basalt
fill 243 165 522 244 172 522 minecraft:basalt
fill 243 165 524 243 174 525 minecraft:basalt
fill 243 165 533 243 172 534 minecraft:basalt
fill 243 165 545 247 165 546 minecraft:basalt
setblock 244 165 511 minecraft:basalt
fill 244 165 536 244 174 536 minecraft:basalt
setblock 244 165 547 minecraft:basalt
setblock 245 165 511 minecraft:magma_block
fill 245 165 521 245 174 521 minecraft:basalt
fill 245 165 537 245 174 537 minecraft:basalt
setblock 245 165 547 minecraft:magma_block
fill 246 165 511 252 166 511 minecraft:basalt
fill 246 165 520 246 174 520 minecraft:basalt
fill 246 165 538 246 172 539 minecraft:basalt
fill 246 165 547 250 165 548 minecraft:basalt
fill 247 165 519 247 174 519 minecraft:basalt
setblock 247 165 539 minecraft:basalt
setblock 248 165 510 minecraft:amethyst_block
fill 248 165 518 248 174 518 minecraft:basalt
setblock 248 165 540 minecraft:magma_block
fill 248 165 545 249 169 545 minecraft:basalt
setblock 248 165 549 minecraft:magma_block
fill 249 165 517 249 174 517 minecraft:basalt
fill 249 165 541 249 174 541 minecraft:basalt
fill 249 165 549 255 165 549 minecraft:basalt
fill 251 165 516 252 174 516 minecraft:basalt
setblock 251 165 542 minecraft:magma_block
fill 251 165 547 252 167 547 minecraft:basalt
fill 251 165 550 253 165 550 minecraft:basalt
fill 252 165 542 252 172 543 minecraft:basalt
setblock 254 165 550 minecraft:magma_block
fill 255 165 515 257 172 515 minecraft:basalt
fill 255 165 543 256 173 543 minecraft:basalt
fill 255 165 550 261 165 550 minecraft:basalt
setblock 257 165 543 minecraft:magma_block
fill 260 165 516 261 172 516 minecraft:basalt
setblock 260 165 542 minecraft:magma_block
fill 260 165 548 266 165 548 minecraft:basalt
fill 261 165 542 261 172 543 minecraft:basalt
fill 262 165 511 268 165 511 minecraft:basalt
fill 262 165 547 268 165 547 minecraft:basalt
setblock 263 165 517 minecraft:magma_block
setblock 263 165 541 minecraft:magma_block
fill 264 165 518 264 174 518 minecraft:basalt
fill 264 165 540 264 174 540 minecraft:basalt
fill 265 165 513 270 165 513 minecraft:basalt
fill 265 165 519 265 174 519 minecraft:basalt
setblock 265 165 539 minecraft:basalt
fill 266 165 520 267 172 520 minecraft:basalt
fill 266 165 538 267 172 538 minecraft:basalt
fill 266 165 543 272 165 543 minecraft:basalt
fill 267 165 521 267 174 521 minecraft:basalt
fill 267 165 537 267 174 537 minecraft:basalt
fill 268 165 512 268 166 512 minecraft:basalt
fill 268 165 518 274 165 518 minecraft:basalt
fill 268 165 522 268 174 522 minecraft:basalt
fill 268 165 536 268 174 536 minecraft:basalt
fill 268 165 542 273 165 542 minecraft:basalt
fill 268 165 545 270 165 545 minecraft:basalt
setblock 269 165 512 minecraft:magma_block
setblock 269 165 524 minecraft:magma_block
fill 269 165 525 270 172 525 minecraft:basalt
setblock 269 165 533 minecraft:magma_block
fill 269 165 534 270 172 534 minecraft:basalt
fill 269 165 539 275 165 539 minecraft:basalt
fill 270 165 528 270 172 531 minecraft:basalt
setblock 271 165 514 minecraft:basalt
fill 271 165 517 274 165 517 minecraft:basalt
fill 271 165 541 274 165 541 minecraft:basalt
setblock 271 165 544 minecraft:basalt
setblock 274 165 540 minecraft:basalt
setblock 275 165 519 minecraft:magma_block
setblock 235 166 519 minecraft:crying_obsidian
setblock 236 166 523 minecraft:basalt
setblock 236 166 535 minecraft:basalt
fill 237 166 521 237 166 522 minecraft:basalt
fill 237 166 536 237 166 537 minecraft:basalt
fill 238 166 538 240 166 538 minecraft:basalt
setblock 238 166 539 minecraft:magma_block
fill 239 166 517 240 166 518 minecraft:basalt
fill 239 166 539 240 167 539 minecraft:basalt
fill 239 166 541 243 166 541 minecraft:basalt
fill 240 166 542 241 166 542 minecraft:basalt
setblock 241 166 515 minecraft:basalt
fill 241 166 543 246 166 543 minecraft:basalt
fill 242 166 514 243 166 514 minecraft:basalt
fill 242 166 527 243 166 527 minecraft:basalt
fill 242 166 530 243 166 530 minecraft:basalt
fill 242 166 544 244 166 544 minecraft:basalt
fill 243 166 513 247 166 513 minecraft:basalt
fill 243 166 526 243 174 526 minecraft:basalt
fill 243 166 528 243 175 529 minecraft:basalt
fill 243 166 531 243 174 532 minecraft:basalt
fill 243 166 545 247 166 545 minecraft:basalt
fill 244 166 512 249 166 512 minecraft:basalt
fill 244 166 523 244 174 524 minecraft:basalt
setblock 244 166 534 minecraft:magma_block
fill 244 166 535 244 174 535 minecraft:basalt
setblock 244 166 546 minecraft:magma_block
fill 245 166 522 245 175 522 minecraft:basalt
fill 245 166 536 245 175 536 minecraft:basalt
fill 245 166 546 247 166 546 minecraft:basalt
fill 246 166 547 250 166 547 minecraft:basalt
setblock 247 166 510 minecraft:crying_obsidian
setblock 247 166 539 minecraft:magma_block
fill 248 166 510 248 290 510 minecraft:black_concrete
fill 248 166 540 249 173 540 minecraft:basalt
fill 248 166 548 250 166 548 minecraft:basalt
fill 249 166 518 249 175 518 minecraft:basalt
setblock 250 166 517 minecraft:magma_block
setblock 250 166 541 minecraft:magma_block
fill 250 166 549 252 166 549 minecraft:basalt
fill 251 166 517 251 175 517 minecraft:basalt
fill 251 166 541 251 173 542 minecraft:basalt
setblock 253 166 516 minecraft:magma_block
fill 253 166 542 255 174 542 minecraft:basalt
setblock 253 166 549 minecraft:magma_block
fill 254 166 516 259 166 516 minecraft:basalt
fill 254 166 549 255 166 549 minecraft:basalt
setblock 256 166 542 minecraft:magma_block
fill 257 166 542 257 173 543 minecraft:basalt
fill 257 166 549 261 166 549 minecraft:basalt
fill 258 166 542 260 173 542 minecraft:basalt
fill 260 166 518 261 166 519 minecraft:obsidian
fill 260 166 548 264 166 548 minecraft:basalt
fill 261 166 517 263 173 517 minecraft:basalt
fill 261 166 541 263 173 541 minecraft:basalt
fill 262 166 511 266 166 511 minecraft:basalt
fill 262 166 547 266 166 547 minecraft:basalt
setblock 262 166 549 minecraft:magma_block
fill 263 166 518 263 175 518 minecraft:basalt
fill 263 166 540 263 175 540 minecraft:basalt
fill 265 166 513 269 166 513 minecraft:basalt
setblock 265 166 539 minecraft:magma_block
fill 265 166 546 268 166 546 minecraft:basalt
fill 266 166 516 272 166 516 minecraft:basalt
fill 266 166 543 270 167 543 minecraft:basalt
fill 267 166 522 267 175 522 minecraft:basalt
fill 267 166 536 267 175 536 minecraft:basalt
fill 268 166 515 271 166 515 minecraft:basalt
fill 268 166 518 273 166 518 minecraft:basalt
setblock 268 166 523 minecraft:magma_block
fill 268 166 524 269 173 524 minecraft:basalt
fill 268 166 534 268 175 534 minecraft:basalt
setblock 268 166 535 minecraft:magma_block
fill 268 166 542 272 166 542 minecraft:basalt
fill 268 166 545 269 166 545 minecraft:basalt
fill 269 166 526 269 173 533 minecraft:basalt
fill 269 166 539 273 167 539 minecraft:basalt
fill 271 166 517 273 166 517 minecraft:basalt
fill 271 166 520 274 166 520 minecraft:basalt
fill 271 166 538 274 166 538 minecraft:basalt
fill 271 166 541 273 166 541 minecraft:basalt
setblock 271 166 543 minecraft:magma_block
fill 274 166 521 275 166 521 minecraft:basalt
fill 274 166 536 275 166 536 minecraft:basalt
setblock 274 166 539 minecraft:magma_block
setblock 275 166 522 minecraft:basalt
setblock 275 166 537 minecraft:basalt
fill 235 167 519 235 177 519 minecraft:black_concrete
setblock 235 167 528 minecraft:amethyst_block
fill 235 167 529 235 307 529 minecraft:black_concrete
fill 236 167 528 237 167 530 minecraft:basalt
setblock 237 167 523 minecraft:magma_block
fill 237 167 524 237 167 525 minecraft:basalt
setblock 237 167 526 minecraft:magma_block
fill 237 167 527 237 168 527 minecraft:basalt
fill 237 167 531 237 168 531 minecraft:basalt
setblock 237 167 532 minecraft:magma_block
fill 237 167 533 237 167 534 minecraft:basalt
setblock 237 167 535 minecraft:magma_block
fill 238 167 521 240 167 521 minecraft:basalt
fill 239 167 520 240 167 520 minecraft:basalt
fill 239 167 538 240 167 538 minecraft:basalt
fill 239 167 552 250 168 552 minecraft:black_concrete
fill 240 167 517 240 167 518 minecraft:basalt
setblock 240 167 540 minecraft:magma_block
fill 240 167 541 243 167 541 minecraft:basalt
fill 241 167 516 246 167 516 minecraft:basalt
fill 241 167 540 246 168 540 minecraft:basalt
setblock 241 167 542 minecraft:basalt
fill 242 167 527 242 173 527 minecraft:basalt
fill 242 167 530 242 173 530 minecraft:basalt
fill 242 167 543 246 167 543 minecraft:basalt
setblock 243 167 514 minecraft:basalt
setblock 243 167 527 minecraft:magma_block
setblock 243 167 530 minecraft:magma_block
fill 243 167 544 244 167 544 minecraft:basalt
fill 244 167 513 247 167 513 minecraft:basalt
fill 244 167 525 244 174 526 minecraft:basalt
fill 244 167 532 244 174 534 minecraft:basalt
fill 244 167 545 247 167 545 minecraft:basalt
fill 245 167 523 245 175 523 minecraft:basalt
fill 245 167 535 245 175 535 minecraft:basalt
fill 246 167 512 249 167 512 minecraft:basalt
fill 246 167 521 246 175 522 minecraft:basalt
fill 246 167 536 246 175 537 minecraft:basalt
fill 246 167 546 247 167 546 minecraft:basalt
fill 247 167 510 247 233 510 minecraft:black_concrete
fill 247 167 520 247 175 520 minecraft:basalt
fill 247 167 538 247 174 539 minecraft:basalt
fill 248 167 511 252 167 511 minecraft:basalt
fill 248 167 519 248 175 519 minecraft:basalt
fill 248 167 539 249 175 539 minecraft:basalt
fill 248 167 547 250 167 547 minecraft:basalt
setblock 249 167 519 minecraft:magma_block
fill 250 167 517 250 174 518 minecraft:basalt
fill 250 167 540 250 174 541 minecraft:basalt
fill 250 167 548 251 167 548 minecraft:basalt
setblock 251 167 552 minecraft:white_concrete
fill 252 167 517 253 175 517 minecraft:basalt
fill 252 167 541 253 175 541 minecraft:basalt
setblock 252 167 548 minecraft:magma_block
fill 253 167 516 257 173 516 minecraft:basalt
fill 253 167 548 258 167 548 minecraft:basalt
setblock 255 167 549 minecraft:basalt
fill 256 167 542 256 174 542 minecraft:basalt
setblock 257 167 549 minecraft:basalt
setblock 258 167 516 minecraft:magma_block
fill 259 167 516 259 174 517 minecraft:basalt
fill 259 167 541 260 174 541 minecraft:basalt
fill 260 167 512 266 167 512 minecraft:basalt
fill 260 167 517 260 175 517 minecraft:basalt
setblock 260 167 548 minecraft:basalt
setblock 261 167 548 minecraft:magma_block
fill 262 167 511 263 167 511 minecraft:basalt
fill 262 167 518 262 175 518 minecraft:basalt
fill 262 167 540 262 174 540 minecraft:basalt
fill 262 167 547 262 167 548 minecraft:basalt
fill 263 167 514 269 167 514 minecraft:basalt
fill 263 167 519 264 167 519 minecraft:basalt
fill 263 167 539 265 174 539 minecraft:basalt
fill 263 167 544 269 167 544 minecraft:basalt
setblock 263 167 547 minecraft:basalt
setblock 264 167 511 minecraft:magma_block
setblock 264 167 547 minecraft:magma_block
fill 265 167 513 266 168 513 minecraft:basalt
fill 265 167 520 265 175 520 minecraft:basalt
fill 265 167 538 265 175 538 minecraft:basalt
fill 265 167 546 266 167 546 minecraft:basalt
fill 266 167 516 271 167 516 minecraft:basalt
fill 266 167 521 266 175 522 minecraft:basalt
fill 266 167 536 266 167 537 minecraft:basalt
fill 266 167 540 272 167 540 minecraft:basalt
setblock 267 167 513 minecraft:magma_block
fill 267 167 523 268 174 523 minecraft:basalt
fill 267 167 535 268 174 535 minecraft:basalt
setblock 268 167 513 minecraft:basalt
fill 268 167 515 269 168 515 minecraft:basalt
fill 268 167 518 272 167 518 minecraft:basalt
fill 268 167 525 268 174 526 minecraft:basalt
fill 268 167 532 268 174 533 minecraft:basalt
fill 268 167 542 271 167 542 minecraft:basalt
setblock 268 167 545 minecraft:basalt
setblock 270 167 515 minecraft:magma_block
fill 271 167 517 272 167 517 minecraft:basalt
fill 271 167 520 272 168 520 minecraft:basalt
fill 271 167 538 272 168 538 minecraft:basalt
fill 271 167 541 272 167 541 minecraft:basalt
fill 272 167 523 275 167 523 minecraft:basalt
fill 272 167 526 275 167 526 minecraft:basalt
fill 272 167 532 275 167 532 minecraft:basalt
fill 272 167 535 275 167 535 minecraft:basalt
setblock 273 167 520 minecraft:magma_block
setblock 273 167 538 minecraft:magma_block
setblock 274 167 521 minecraft:basalt
fill 274 167 524 275 167 524 minecraft:basalt
fill 274 167 527 275 167 527 minecraft:basalt
fill 274 167 533 275 167 533 minecraft:basalt
setblock 274 167 536 minecraft:basalt
setblock 275 167 525 minecraft:basalt
fill 275 167 528 275 168 528 minecraft:basalt
fill 275 167 531 275 168 531 minecraft:basalt
setblock 275 167 534 minecraft:basalt
setblock 276 167 528 minecraft:magma_block
fill 235 168 528 235 171 528 minecraft:black_concrete
fill 237 168 528 237 168 530 minecraft:basalt
fill 238 168 535 240 168 535 minecraft:basalt
setblock 239 168 521 minecraft:magma_block
fill 239 168 522 242 168 522 minecraft:basalt
setblock 239 168 536 minecraft:magma_block
fill 240 168 519 240 168 521 minecraft:basalt
fill 240 168 536 240 169 536 minecraft:basalt
fill 240 168 538 240 168 539 minecraft:basalt
fill 241 168 519 245 168 519 minecraft:basalt
fill 242 168 516 246 168 516 minecraft:basalt
setblock 242 168 517 minecraft:magma_block
setblock 242 168 541 minecraft:magma_block
fill 243 168 515 249 168 515 minecraft:basalt
fill 243 168 517 243 169 517 minecraft:basalt
fill 243 168 527 244 174 527 minecraft:basalt
fill 243 168 530 244 175 530 minecraft:basalt
fill 243 168 541 243 169 541 minecraft:basalt
fill 243 168 543 246 168 543 minecraft:basalt
fill 244 168 528 244 176 529 minecraft:basalt
fill 244 168 531 244 174 531 minecraft:basalt
fill 245 168 524 245 176 524 minecraft:basalt
setblock 245 168 525 minecraft:magma_block
fill 245 168 533 245 176 533 minecraft:basalt
setblock 245 168 534 minecraft:magma_block
fill 246 168 513 247 168 513 minecraft:basalt
fill 246 168 523 246 175 523 minecraft:basalt
fill 246 168 535 246 175 535 minecraft:basalt
fill 246 168 545 247 168 545 minecraft:basalt
fill 247 168 521 247 176 521 minecraft:basalt
fill 247 168 537 247 176 537 minecraft:basalt
setblock 248 168 512 minecraft:magma_block
fill 248 168 520 248 176 520 minecraft:basalt
fill 248 168 538 248 176 538 minecraft:basalt
setblock 249 168 512 minecraft:basalt
fill 249 168 519 250 168 519 minecraft:basalt
setblock 250 168 511 minecraft:basalt
fill 250 168 539 250 176 539 minecraft:basalt
setblock 250 168 547 minecraft:basalt
setblock 251 168 511 minecraft:magma_block
fill 251 168 518 252 175 518 minecraft:basalt
fill 251 168 540 252 176 540 minecraft:basalt
setblock 251 168 547 minecraft:magma_block
fill 251 168 552 251 307 552 minecraft:black_concrete
setblock 252 168 511 minecraft:basalt
setblock 252 168 547 minecraft:basalt
fill 254 168 511 259 168 511 minecraft:basalt
fill 254 168 517 258 175 517 minecraft:basalt
fill 254 168 541 258 175 541 minecraft:basalt
fill 254 168 547 256 168 548 minecraft:basalt
fill 257 168 546 259 169 547 minecraft:basalt
setblock 257 168 548 minecraft:magma_block
fill 258 168 516 258 174 516 minecraft:basalt
setblock 258 168 548 minecraft:basalt
setblock 260 168 511 minecraft:magma_block
fill 260 168 512 264 168 512 minecraft:basalt
fill 260 168 518 261 175 518 minecraft:basalt
fill 260 168 540 261 176 540 minecraft:basalt
fill 260 168 545 262 169 546 minecraft:basalt
setblock 260 168 547 minecraft:magma_block
fill 261 168 511 262 168 511 minecraft:basalt
fill 261 168 547 262 168 547 minecraft:basalt
fill 262 168 519 262 176 519 minecraft:basalt
setblock 262 168 539 minecraft:basalt
fill 263 168 514 267 168 514 minecraft:basalt
setblock 263 168 519 minecraft:magma_block
fill 263 168 544 265 168 545 minecraft:basalt
setblock 263 168 546 minecraft:magma_block
fill 264 168 519 264 175 520 minecraft:basalt
fill 264 168 538 264 175 538 minecraft:basalt
setblock 264 168 546 minecraft:basalt
fill 265 168 521 265 176 521 minecraft:basalt
fill 265 168 537 266 175 537 minecraft:basalt
fill 266 168 516 270 168 516 minecraft:basalt
fill 266 168 523 266 176 523 minecraft:basalt
fill 266 168 535 266 176 535 minecraft:basalt
setblock 266 168 536 minecraft:magma_block
fill 266 168 540 271 168 540 minecraft:basalt
fill 266 168 543 267 168 544 minecraft:basalt
setblock 266 168 545 minecraft:magma_block
fill 267 168 519 271 169 519 minecraft:basalt
fill 267 168 524 267 175 525 minecraft:basalt
fill 267 168 533 267 175 534 minecraft:basalt
fill 268 168 518 271 168 518 minecraft:basalt
fill 268 168 527 268 176 531 minecraft:basalt
fill 268 168 542 269 168 543 minecraft:basalt
fill 269 168 539 272 168 539 minecraft:basalt
setblock 270 168 542 minecraft:basalt
setblock 272 168 519 minecraft:magma_block
fill 272 168 523 274 168 523 minecraft:basalt
fill 272 168 526 274 168 526 minecraft:basalt
fill 272 168 529 275 168 529 minecraft:basalt
fill 272 168 532 274 168 532 minecraft:basalt
fill 272 168 535 274 168 535 minecraft:basalt
setblock 274 168 524 minecraft:basalt
fill 274 168 527 274 169 527 minecraft:basalt
fill 274 168 530 274 169 530 minecraft:basalt
setblock 274 168 533 minecraft:basalt
setblock 275 168 527 minecraft:magma_block
setblock 275 168 530 minecraft:magma_block
fill 277 168 534 277 267 534 minecraft:black_concrete
setblock 277 168 535 minecraft:white_concrete
fill 277 168 536 277 170 538 minecraft:black_concrete
setblock 238 169 526 minecraft:magma_block
fill 238 169 527 240 169 527 minecraft:basalt
setblock 238 169 529 minecraft:magma_block
fill 238 169 530 240 169 530 minecraft:basalt
setblock 238 169 532 minecraft:magma_block
fill 239 169 523 240 169 524 minecraft:basalt
fill 239 169 526 240 170 526 minecraft:basalt
fill 239 169 529 240 170 529 minecraft:basalt
fill 239 169 532 240 169 533 minecraft:basalt
fill 239 169 535 240 169 535 minecraft:basalt
fill 239 169 552 240 184 552 minecraft:black_concrete
fill 240 169 521 240 169 522 minecraft:basalt
fill 240 169 537 243 169 537 minecraft:basalt
setblock 241 169 519 minecraft:magma_block
fill 241 169 522 242 171 522 minecraft:basalt
setblock 241 169 552 minecraft:amethyst_block
fill 242 169 519 245 170 519 minecraft:basalt
fill 242 169 540 246 169 540 minecraft:basalt
fill 242 169 552 250 170 552 minecraft:black_concrete
fill 244 169 516 246 169 516 minecraft:basalt
setblock 244 169 542 minecraft:magma_block
fill 245 169 515 249 169 515 minecraft:basalt
fill 245 169 525 245 176 532 minecraft:basalt
fill 245 169 534 246 169 534 minecraft:basalt
fill 245 169 542 246 169 543 minecraft:basalt
setblock 246 169 514 minecraft:basalt
fill 246 169 524 246 177 524 minecraft:basalt
setblock 246 169 544 minecraft:basalt
setblock 247 169 514 minecraft:magma_block
fill 247 169 522 247 176 522 minecraft:basalt
fill 247 169 536 247 176 536 minecraft:basalt
fill 247 169 542 249 171 542 minecraft:basalt
setblock 247 169 544 minecraft:magma_block
fill 248 169 514 252 170 514 minecraft:basalt
fill 248 169 521 248 176 521 minecraft:basalt
fill 248 169 537 248 176 537 minecraft:basalt
fill 248 169 544 252 170 544 minecraft:basalt
fill 249 169 519 249 175 520 minecraft:basalt
fill 249 169 538 249 176 538 minecraft:basalt
setblock 250 169 519 minecraft:magma_block
setblock 250 169 546 minecraft:magma_block
fill 251 169 519 251 177 519 minecraft:basalt
fill 251 169 539 251 177 539 minecraft:basalt
fill 251 169 546 255 169 546 minecraft:basalt
setblock 253 169 518 minecraft:magma_block
fill 253 169 540 258 169 540 minecraft:basalt
fill 254 169 511 255 169 511 minecraft:basalt
fill 254 169 518 259 169 518 minecraft:basalt
fill 254 169 547 255 169 547 minecraft:basalt
setblock 256 169 511 minecraft:magma_block
setblock 256 169 547 minecraft:magma_block
fill 257 169 511 259 169 511 minecraft:basalt
setblock 259 169 540 minecraft:magma_block
fill 260 169 512 261 169 512 minecraft:basalt
fill 261 169 519 261 177 519 minecraft:basalt
fill 261 169 539 261 177 539 minecraft:basalt
setblock 262 169 512 minecraft:magma_block
setblock 262 169 539 minecraft:magma_block
fill 263 169 514 264 170 514 minecraft:basalt
fill 263 169 519 263 175 520 minecraft:basalt
fill 263 169 538 263 176 538 minecraft:basalt
fill 263 169 544 264 169 545 minecraft:basalt
fill 264 169 521 264 176 521 minecraft:basalt
fill 264 169 537 264 176 537 minecraft:basalt
setblock 265 169 514 minecraft:magma_block
fill 265 169 517 269 169 517 minecraft:basalt
fill 265 169 522 265 176 522 minecraft:basalt
fill 265 169 536 266 175 536 minecraft:basalt
fill 265 169 541 269 169 541 minecraft:basalt
setblock 265 169 544 minecraft:magma_block
setblock 266 169 514 minecraft:basalt
fill 266 169 516 267 170 516 minecraft:basalt
fill 266 169 524 266 176 524 minecraft:basalt
fill 266 169 534 266 177 534 minecraft:basalt
fill 266 169 540 270 169 540 minecraft:basalt
fill 266 169 543 266 169 544 minecraft:basalt
fill 267 169 526 267 169 532 minecraft:basalt
setblock 267 169 543 minecraft:basalt
setblock 268 169 516 minecraft:magma_block
fill 268 169 518 270 169 518 minecraft:basalt
setblock 268 169 542 minecraft:basalt
fill 269 169 521 272 169 522 minecraft:basalt
fill 269 169 536 272 169 537 minecraft:basalt
fill 269 169 539 270 170 539 minecraft:basalt
setblock 271 169 520 minecraft:basalt
setblock 271 169 538 minecraft:basalt
setblock 271 169 539 minecraft:magma_block
fill 272 169 523 273 169 523 minecraft:basalt
fill 272 169 526 273 170 526 minecraft:basalt
fill 272 169 529 273 170 529 minecraft:basalt
fill 272 169 532 273 170 532 minecraft:basalt
fill 272 169 535 273 169 535 minecraft:basalt
setblock 274 169 526 minecraft:magma_block
setblock 274 169 529 minecraft:magma_block
setblock 274 169 532 minecraft:magma_block
setblock 277 169 527 minecraft:crying_obsidian
fill 277 169 535 277 177 535 minecraft:black_concrete
fill 239 170 527 240 170 527 minecraft:basalt
fill 239 170 530 240 170 530 minecraft:basalt
fill 239 170 532 240 170 532 minecraft:basalt
setblock 240 170 523 minecraft:basalt
setblock 240 170 524 minecraft:magma_block
fill 240 170 525 241 171 525 minecraft:basalt
setblock 240 170 533 minecraft:magma_block
fill 240 170 534 240 170 535 minecraft:basalt
fill 241 170 534 242 171 534 minecraft:basalt
fill 241 170 537 243 170 537 minecraft:basalt
fill 241 170 552 241 269 552 minecraft:black_concrete
fill 242 170 520 243 170 520 minecraft:basalt
fill 242 170 538 243 170 538 minecraft:basalt
fill 243 170 518 246 170 518 minecraft:basalt
fill 243 170 540 246 170 540 minecraft:basalt
fill 245 170 516 246 170 516 minecraft:basalt
fill 245 170 534 245 176 534 minecraft:basalt
fill 245 170 542 246 170 542 minecraft:basalt
fill 246 170 515 249 170 515 minecraft:basalt
setblock 246 170 525 minecraft:magma_block
fill 246 170 526 246 177 526 minecraft:basalt
fill 246 170 532 246 177 533 minecraft:basalt
setblock 246 170 534 minecraft:magma_block
setblock 246 170 543 minecraft:magma_block
fill 247 170 523 247 177 523 minecraft:basalt
fill 247 170 535 247 177 535 minecraft:basalt
fill 248 170 522 248 177 522 minecraft:basalt
fill 248 170 536 248 176 536 minecraft:basalt
setblock 249 170 521 minecraft:magma_block
fill 249 170 537 249 177 537 minecraft:basalt
fill 250 170 513 255 170 513 minecraft:basalt
fill 250 170 519 250 176 520 minecraft:basalt
fill 250 170 538 250 177 538 minecraft:basalt
fill 252 170 519 253 177 519 minecraft:basalt
fill 252 170 539 253 177 539 minecraft:basalt
fill 253 170 512 257 170 512 minecraft:basalt
fill 253 170 518 257 176 518 minecraft:basalt
fill 253 170 540 254 176 540 minecraft:basalt
fill 253 170 546 254 170 546 minecraft:basalt
setblock 255 170 540 minecraft:magma_block
setblock 255 170 546 minecraft:magma_block
fill 256 170 540 259 176 540 minecraft:basalt
fill 257 170 513 262 170 513 minecraft:basalt
fill 257 170 546 259 170 546 minecraft:basalt
setblock 258 170 512 minecraft:magma_block
setblock 258 170 518 minecraft:magma_block
fill 259 170 518 259 176 519 minecraft:basalt
fill 259 170 539 260 177 539 minecraft:basalt
fill 260 170 519 260 177 519 minecraft:basalt
fill 260 170 545 262 170 545 minecraft:basalt
fill 261 170 515 266 170 515 minecraft:basalt
fill 262 170 520 262 177 520 minecraft:basalt
fill 262 170 538 262 176 539 minecraft:basalt
fill 263 170 521 263 177 521 minecraft:basalt
fill 263 170 537 263 176 537 minecraft:basalt
fill 263 170 542 266 171 542 minecraft:basalt
fill 263 170 544 264 170 544 minecraft:basalt
setblock 264 170 522 minecraft:magma_block
fill 264 170 536 264 177 536 minecraft:basalt
fill 265 170 517 268 170 517 minecraft:basalt
fill 265 170 523 265 177 523 minecraft:basalt
fill 265 170 535 265 177 535 minecraft:basalt
fill 265 170 541 268 170 541 minecraft:basalt
fill 266 170 525 266 170 526 minecraft:basalt
fill 266 170 532 266 170 533 minecraft:basalt
fill 266 170 540 269 170 540 minecraft:basalt
setblock 266 170 543 minecraft:basalt
fill 267 170 519 270 170 519 minecraft:basalt
fill 267 170 526 267 176 526 minecraft:basalt
setblock 267 170 527 minecraft:magma_block
fill 267 170 528 267 177 529 minecraft:basalt
setblock 267 170 530 minecraft:magma_block
fill 267 170 531 267 176 532 minecraft:basalt
setblock 267 170 542 minecraft:magma_block
fill 268 170 518 269 170 518 minecraft:basalt
fill 268 170 520 269 171 520 minecraft:basalt
fill 268 170 538 269 171 538 minecraft:basalt
fill 269 170 521 271 170 522 minecraft:basalt
fill 269 170 536 271 170 537 minecraft:basalt
setblock 269 170 541 minecraft:bone_block
setblock 270 170 520 minecraft:magma_block
setblock 270 170 538 minecraft:magma_block
setblock 270 170 540 minecraft:bone_block
fill 271 170 524 272 170 525 minecraft:basalt
fill 271 170 527 272 170 528 minecraft:basalt
fill 271 170 530 272 170 531 minecraft:basalt
fill 271 170 533 272 170 534 minecraft:basalt
fill 271 170 538 271 172 538 minecraft:bone_block
setblock 272 170 523 minecraft:basalt
setblock 272 170 535 minecraft:basalt
setblock 273 170 527 minecraft:basalt
setblock 273 170 528 minecraft:magma_block
setblock 273 170 530 minecraft:basalt
setblock 273 170 531 minecraft:magma_block
fill 277 170 527 277 216 527 minecraft:black_concrete
fill 235 171 518 235 173 518 minecraft:purple_concrete
fill 235 171 534 235 173 534 minecraft:purple_concrete
fill 235 171 550 235 173 550 minecraft:purple_concrete
fill 235 171 551 235 237 551 minecraft:black_concrete
fill 236 171 510 238 191 510 minecraft:black_concrete
setblock 238 171 513 minecraft:light[level=12]
setblock 238 171 521 minecraft:light[level=12]
setblock 238 171 529 minecraft:light[level=12]
setblock 238 171 537 minecraft:light[level=12]
setblock 238 171 545 minecraft:light[level=12]
fill 239 171 510 239 173 510 minecraft:purple_concrete
fill 240 171 510 240 240 510 minecraft:black_concrete
fill 240 171 526 240 171 533 minecraft:basalt
setblock 241 171 510 minecraft:amethyst_block
fill 241 171 528 241 172 528 minecraft:basalt
fill 241 171 531 241 172 531 minecraft:basalt
fill 242 171 510 246 173 510 minecraft:black_concrete
setblock 242 171 537 minecraft:magma_block
fill 242 171 552 248 176 552 minecraft:black_concrete
fill 243 171 519 243 171 520 minecraft:basalt
fill 243 171 537 243 171 539 minecraft:basalt
fill 244 171 518 245 171 519 minecraft:basalt
fill 244 171 539 245 171 540 minecraft:basalt
setblock 246 171 513 minecraft:light[level=12]
setblock 246 171 516 minecraft:basalt
fill 246 171 518 246 172 518 minecraft:basalt
fill 246 171 525 247 171 525 minecraft:basalt
fill 246 171 527 246 178 531 minecraft:basalt
fill 246 171 534 247 177 534 minecraft:basalt
fill 246 171 540 246 172 540 minecraft:basalt
setblock 246 171 542 minecraft:basalt
setblock 246 171 545 minecraft:light[level=12]
fill 247 171 524 247 178 524 minecraft:basalt
fill 247 171 533 247 178 533 minecraft:basalt
fill 248 171 515 249 171 515 minecraft:basalt
setblock 248 171 523 minecraft:magma_block
setblock 248 171 535 minecraft:magma_block
fill 249 171 514 252 171 514 minecraft:basalt
fill 249 171 521 249 177 522 minecraft:basalt
fill 249 171 536 249 178 536 minecraft:basalt
fill 249 171 544 252 171 544 minecraft:basalt
fill 249 171 552 249 173 552 minecraft:purple_concrete
fill 250 171 521 250 178 521 minecraft:basalt
fill 250 171 537 250 177 537 minecraft:basalt
setblock 250 171 552 minecraft:amethyst_block
fill 251 171 520 252 178 520 minecraft:basalt
fill 251 171 538 252 178 538 minecraft:basalt
fill 252 171 513 255 171 513 minecraft:basalt
fill 252 171 545 253 171 545 minecraft:basalt
fill 252 171 552 252 175 552 minecraft:black_concrete
setblock 253 171 552 minecraft:crying_obsidian
fill 254 171 519 258 171 519 minecraft:basalt
setblock 254 171 521 minecraft:light[level=12]
setblock 254 171 529 minecraft:light[level=12]
setblock 254 171 537 minecraft:light[level=12]
setblock 254 171 539 minecraft:magma_block
setblock 254 171 545 minecraft:magma_block
fill 255 171 510 255 173 510 minecraft:purple_concrete
fill 255 171 539 255 177 540 minecraft:basalt
fill 255 171 545 258 171 545 minecraft:basalt
fill 256 171 539 258 178 539 minecraft:basalt
fill 257 171 513 259 171 513 minecraft:basalt
fill 258 171 518 258 177 518 minecraft:basalt
setblock 260 171 513 minecraft:magma_block
fill 260 171 520 261 178 520 minecraft:basalt
fill 260 171 538 261 178 538 minecraft:basalt
setblock 260 171 545 minecraft:basalt
fill 261 171 515 264 171 515 minecraft:basalt
setblock 262 171 513 minecraft:light[level=12]
fill 262 171 521 262 177 521 minecraft:basalt
setblock 262 171 529 minecraft:light[level=12]
fill 262 171 537 262 178 537 minecraft:basalt
setblock 262 171 545 minecraft:light[level=12]
setblock 263 171 514 minecraft:basalt
fill 263 171 522 264 177 522 minecraft:basalt
setblock 263 171 536 minecraft:magma_block
fill 263 171 543 263 171 544 minecraft:basalt
fill 264 171 523 264 178 523 minecraft:basalt
fill 264 171 535 264 178 535 minecraft:basalt
setblock 264 171 543 minecraft:basalt
fill 265 171 517 267 171 517 minecraft:basalt
fill 265 171 524 265 171 525 minecraft:basalt
fill 265 171 533 265 178 534 minecraft:basalt
fill 265 171 541 267 171 541 minecraft:basalt
fill 265 171 552 265 173 552 minecraft:purple_concrete
setblock 266 171 516 minecraft:basalt
fill 266 171 525 266 177 525 minecraft:basalt
setblock 266 171 526 minecraft:magma_block
fill 266 171 527 266 178 528 minecraft:basalt
setblock 266 171 529 minecraft:magma_block
fill 266 171 530 266 178 531 minecraft:basalt
setblock 266 171 532 minecraft:magma_block
fill 266 171 533 266 176 533 minecraft:basalt
fill 266 171 540 268 171 540 minecraft:basalt
fill 266 171 552 266 307 552 minecraft:black_concrete
fill 267 171 519 268 172 519 minecraft:basalt
fill 267 171 527 267 177 527 minecraft:basalt
fill 267 171 530 267 177 530 minecraft:basalt
fill 268 171 510 270 171 510 minecraft:black_concrete
setblock 268 171 518 minecraft:basalt
setblock 269 171 519 minecraft:magma_block
fill 269 171 521 270 171 522 minecraft:basalt
fill 269 171 536 270 171 537 minecraft:basalt
setblock 269 171 539 minecraft:basalt
setblock 269 171 540 minecraft:bone_block
setblock 270 171 513 minecraft:light[level=12]
fill 270 171 538 270 172 539 minecraft:bone_block
setblock 270 171 545 minecraft:light[level=12]
fill 271 171 510 271 173 510 minecraft:purple_concrete
setblock 271 171 522 minecraft:basalt
fill 271 171 524 271 171 525 minecraft:basalt
fill 271 171 527 271 172 528 minecraft:basalt
fill 271 171 530 271 172 531 minecraft:basalt
fill 271 171 533 271 171 534 minecraft:basalt
setblock 271 171 536 minecraft:basalt
fill 271 171 537 271 174 537 minecraft:bone_block
fill 272 171 510 272 236 510 minecraft:black_concrete
fill 272 171 525 272 171 526 minecraft:basalt
setblock 272 171 527 minecraft:magma_block
fill 272 171 528 272 171 529 minecraft:basalt
setblock 272 171 530 minecraft:magma_block
fill 272 171 531 272 171 532 minecraft:basalt
setblock 272 171 533 minecraft:magma_block
fill 272 171 540 273 172 540 minecraft:bone_block
fill 273 171 522 273 172 523 minecraft:bone_block
setblock 273 171 541 minecraft:bone_block
setblock 274 171 522 minecraft:bone_block
fill 277 171 520 277 173 520 minecraft:purple_concrete
fill 277 171 536 277 173 536 minecraft:purple_concrete
fill 277 171 537 277 193 538 minecraft:black_concrete
fill 235 172 520 235 189 520 minecraft:black_concrete
setblock 235 172 521 minecraft:amethyst_block
setblock 235 172 528 minecraft:amethyst_block
fill 241 172 510 241 180 510 minecraft:black_concrete
setblock 241 172 525 minecraft:basalt
setblock 241 172 527 minecraft:magma_block
setblock 241 172 530 minecraft:magma_block
setblock 241 172 533 minecraft:magma_block
fill 242 172 522 242 172 523 minecraft:basalt
fill 242 172 533 242 172 535 minecraft:basalt
fill 243 172 521 244 172 521 minecraft:basalt
fill 243 172 537 244 172 537 minecraft:basalt
fill 244 172 519 245 172 519 minecraft:basalt
setblock 244 172 520 minecraft:magma_block
setblock 244 172 538 minecraft:magma_block
fill 244 172 539 245 172 539 minecraft:basalt
setblock 245 172 518 minecraft:basalt
setblock 245 172 540 minecraft:basalt
fill 246 172 517 247 172 517 minecraft:basalt
fill 246 172 525 246 177 525 minecraft:basalt
fill 246 172 541 247 172 541 minecraft:basalt
fill 246 172 544 246 173 544 minecraft:white_concrete
setblock 247 172 525 minecraft:magma_block
fill 247 172 526 247 177 527 minecraft:basalt
setblock 247 172 531 minecraft:magma_block
fill 247 172 532 247 177 532 minecraft:basalt
fill 248 172 523 248 178 524 minecraft:basalt
fill 248 172 534 248 178 535 minecraft:basalt
fill 248 172 542 249 172 542 minecraft:basalt
setblock 249 172 515 minecraft:basalt
fill 249 172 523 249 178 523 minecraft:basalt
fill 249 172 535 249 178 535 minecraft:basalt
fill 249 172 543 251 172 543 minecraft:basalt
setblock 250 172 515 minecraft:magma_block
fill 250 172 516 250 173 516 minecraft:basalt
fill 250 172 522 250 177 522 minecraft:basalt
setblock 250 172 536 minecraft:magma_block
fill 250 172 552 250 244 552 minecraft:black_concrete
fill 251 172 521 251 178 521 minecraft:basalt
fill 251 172 537 251 178 537 minecraft:basalt
setblock 252 172 514 minecraft:basalt
setblock 252 172 544 minecraft:basalt
setblock 253 172 514 minecraft:magma_block
setblock 253 172 520 minecraft:magma_block
setblock 253 172 538 minecraft:magma_block
fill 253 172 543 253 173 543 minecraft:basalt
setblock 253 172 544 minecraft:magma_block
fill 253 172 552 253 177 552 minecraft:black_concrete
fill 254 172 514 260 172 514 minecraft:basalt
fill 254 172 519 254 178 520 minecraft:basalt
fill 254 172 538 254 178 539 minecraft:basalt
fill 254 172 544 260 172 544 minecraft:basalt
fill 255 172 519 255 178 519 minecraft:basalt
setblock 256 172 519 minecraft:magma_block
fill 257 172 519 258 178 519 minecraft:basalt
fill 258 172 520 259 172 520 minecraft:basalt
fill 258 172 538 259 172 538 minecraft:basalt
fill 259 172 552 259 238 552 minecraft:black_concrete
setblock 260 172 552 minecraft:crying_obsidian
setblock 261 172 510 minecraft:white_concrete
fill 261 172 515 263 172 515 minecraft:basalt
fill 261 172 521 261 178 521 minecraft:basalt
fill 261 172 537 261 178 537 minecraft:basalt
fill 261 172 552 264 188 552 minecraft:black_concrete
fill 262 172 522 262 178 522 minecraft:basalt
fill 262 172 536 263 177 536 minecraft:basalt
fill 262 172 542 263 172 543 minecraft:basalt
fill 263 172 523 263 178 523 minecraft:basalt
fill 263 172 535 263 178 535 minecraft:basalt
fill 264 172 524 265 178 524 minecraft:basalt
fill 264 172 534 264 178 534 minecraft:basalt
setblock 264 172 542 minecraft:basalt
fill 265 172 517 266 172 517 minecraft:basalt
setblock 265 172 525 minecraft:magma_block
fill 265 172 526 265 177 527 minecraft:basalt
setblock 265 172 531 minecraft:magma_block
fill 265 172 532 266 177 532 minecraft:basalt
fill 265 172 541 266 172 541 minecraft:basalt
fill 266 172 526 266 177 526 minecraft:basalt
fill 266 172 529 266 178 529 minecraft:basalt
fill 266 172 540 267 172 540 minecraft:basalt
fill 268 172 510 269 243 510 minecraft:black_concrete
setblock 268 172 520 minecraft:basalt
setblock 268 172 538 minecraft:basalt
setblock 268 172 539 minecraft:magma_block
fill 269 172 521 269 172 522 minecraft:basalt
fill 269 172 535 269 172 537 minecraft:basalt
fill 269 172 538 269 172 539 minecraft:bone_block
setblock 270 172 510 minecraft:white_concrete
setblock 270 172 522 minecraft:basalt
fill 270 172 535 270 172 536 minecraft:basalt
fill 270 172 537 270 174 537 minecraft:bone_block
setblock 271 172 525 minecraft:basalt
setblock 271 172 526 minecraft:magma_block
setblock 271 172 529 minecraft:magma_block
setblock 271 172 532 minecraft:magma_block
setblock 271 172 533 minecraft:basalt
fill 271 172 534 271 175 536 minecraft:bone_block
fill 272 172 524 273 173 524 minecraft:bone_block
fill 272 172 538 273 172 539 minecraft:bone_block
fill 235 173 521 235 307 521 minecraft:black_concrete
fill 235 173 528 235 176 528 minecraft:black_concrete
fill 242 173 533 243 173 533 minecraft:basalt
setblock 243 173 522 minecraft:magma_block
setblock 243 173 534 minecraft:magma_block
setblock 243 173 536 minecraft:basalt
fill 244 173 521 244 173 522 minecraft:basalt
setblock 244 173 537 minecraft:basalt
fill 246 173 538 246 174 538 minecraft:basalt
setblock 246 173 539 minecraft:magma_block
fill 247 173 525 248 178 525 minecraft:basalt
fill 247 173 528 247 177 531 minecraft:basalt
fill 248 173 526 248 178 526 minecraft:basalt
fill 248 173 532 248 178 533 minecraft:basalt
setblock 249 173 516 minecraft:basalt
fill 249 173 524 249 178 524 minecraft:basalt
fill 249 173 534 249 178 534 minecraft:basalt
setblock 249 173 542 minecraft:basalt
fill 250 173 523 250 178 523 minecraft:basalt
fill 250 173 535 250 178 536 minecraft:basalt
fill 251 173 522 251 178 522 minecraft:basalt
setblock 251 173 536 minecraft:basalt
fill 252 173 521 253 177 521 minecraft:basalt
setblock 252 173 537 minecraft:magma_block
fill 252 173 542 252 174 542 minecraft:basalt
setblock 252 173 543 minecraft:magma_block
fill 253 173 520 253 178 520 minecraft:basalt
fill 253 173 537 253 178 538 minecraft:basalt
setblock 255 173 515 minecraft:magma_block
fill 255 173 520 257 177 520 minecraft:basalt
fill 255 173 538 257 177 538 minecraft:basalt
fill 256 173 515 257 173 515 minecraft:basalt
fill 256 173 519 256 178 519 minecraft:basalt
setblock 258 173 520 minecraft:magma_block
setblock 258 173 538 minecraft:magma_block
fill 259 173 520 259 178 521 minecraft:basalt
fill 259 173 537 259 177 538 minecraft:basalt
fill 260 173 516 260 174 516 minecraft:basalt
fill 260 173 521 260 178 521 minecraft:basalt
fill 260 173 537 260 178 537 minecraft:basalt
fill 260 173 552 260 199 552 minecraft:black_concrete
fill 261 173 510 261 211 510 minecraft:black_concrete
setblock 261 173 516 minecraft:magma_block
setblock 261 173 522 minecraft:magma_block
fill 261 173 536 261 178 536 minecraft:basalt
fill 261 173 542 263 173 542 minecraft:basalt
fill 262 173 523 262 178 523 minecraft:basalt
fill 262 173 535 262 178 535 minecraft:basalt
setblock 263 173 516 minecraft:basalt
fill 263 173 524 263 178 524 minecraft:basalt
fill 263 173 534 263 178 534 minecraft:basalt
fill 264 173 525 264 178 526 minecraft:basalt
fill 264 173 532 264 178 532 minecraft:basalt
setblock 264 173 533 minecraft:magma_block
fill 265 173 525 265 178 525 minecraft:basalt
fill 265 173 528 265 177 531 minecraft:basalt
fill 266 173 520 266 174 520 minecraft:basalt
fill 266 173 538 266 174 538 minecraft:basalt
setblock 267 173 520 minecraft:magma_block
setblock 267 173 538 minecraft:magma_block
fill 268 173 538 270 173 538 minecraft:bone_block
setblock 269 173 522 minecraft:basalt
fill 269 173 525 269 174 525 minecraft:basalt
fill 269 173 534 269 173 536 minecraft:basalt
fill 269 173 537 269 174 537 minecraft:bone_block
fill 270 173 510 270 200 510 minecraft:black_concrete
setblock 270 173 525 minecraft:magma_block
setblock 270 173 528 minecraft:magma_block
fill 270 173 529 270 173 530 minecraft:basalt
setblock 270 173 531 minecraft:magma_block
fill 270 173 534 270 175 536 minecraft:bone_block
fill 271 173 533 271 178 533 minecraft:bone_block
setblock 271 173 552 minecraft:amethyst_block
fill 272 173 525 272 174 526 minecraft:bone_block
fill 272 173 534 272 173 538 minecraft:bone_block
setblock 273 173 525 minecraft:bone_block
setblock 273 173 538 minecraft:bone_block
fill 235 174 518 235 179 518 minecraft:black_concrete
fill 235 174 534 235 177 534 minecraft:black_concrete
fill 235 174 550 235 179 550 minecraft:black_concrete
fill 239 174 510 239 179 510 minecraft:black_concrete
fill 242 174 510 242 217 510 minecraft:black_concrete
setblock 243 174 510 minecraft:amethyst_block
fill 243 174 533 243 174 534 minecraft:basalt
setblock 244 174 510 minecraft:white_concrete
setblock 244 174 522 minecraft:basalt
fill 245 174 510 246 184 510 minecraft:black_concrete
fill 248 174 527 248 178 527 minecraft:basalt
setblock 248 174 528 minecraft:magma_block
fill 248 174 529 248 178 530 minecraft:basalt
setblock 248 174 531 minecraft:magma_block
setblock 248 174 540 minecraft:magma_block
fill 249 174 525 249 178 525 minecraft:basalt
fill 249 174 533 249 178 533 minecraft:basalt
fill 249 174 540 249 175 540 minecraft:basalt
fill 249 174 552 249 179 552 minecraft:black_concrete
setblock 251 174 536 minecraft:magma_block
fill 251 174 541 251 175 541 minecraft:basalt
setblock 251 174 542 minecraft:magma_block
fill 252 174 522 252 178 522 minecraft:basalt
fill 252 174 536 252 178 537 minecraft:basalt
fill 253 174 516 256 174 516 minecraft:basalt
fill 254 174 521 258 174 521 minecraft:basalt
fill 254 174 537 256 178 537 minecraft:basalt
fill 255 174 510 255 179 510 minecraft:black_concrete
setblock 257 174 516 minecraft:magma_block
setblock 257 174 537 minecraft:magma_block
fill 257 174 542 259 174 542 minecraft:basalt
fill 258 174 520 258 178 520 minecraft:basalt
fill 258 174 537 258 178 538 minecraft:basalt
fill 260 174 522 261 178 522 minecraft:basalt
setblock 260 174 536 minecraft:magma_block
setblock 260 174 542 minecraft:magma_block
fill 261 174 516 261 174 517 minecraft:basalt
fill 261 174 541 261 174 542 minecraft:basalt
setblock 262 174 517 minecraft:basalt
setblock 262 174 541 minecraft:basalt
setblock 263 174 517 minecraft:magma_block
fill 263 174 525 263 178 525 minecraft:basalt
fill 263 174 533 264 178 533 minecraft:basalt
setblock 263 174 541 minecraft:magma_block
fill 264 174 527 264 178 531 minecraft:basalt
fill 265 174 552 265 179 552 minecraft:black_concrete
fill 268 174 524 268 175 524 minecraft:basalt
setblock 269 174 524 minecraft:magma_block
setblock 269 174 526 minecraft:basalt
setblock 269 174 527 minecraft:magma_block
fill 269 174 528 269 175 529 minecraft:basalt
setblock 269 174 530 minecraft:magma_block
fill 269 174 531 269 174 532 minecraft:basalt
setblock 269 174 533 minecraft:magma_block
setblock 269 174 534 minecraft:basalt
fill 269 174 535 269 175 536 minecraft:bone_block
fill 270 174 531 270 178 533 minecraft:bone_block
fill 271 174 510 271 179 510 minecraft:black_concrete
fill 271 174 527 272 175 527 minecraft:bone_block
fill 271 174 532 272 178 532 minecraft:bone_block
fill 271 174 552 271 307 552 minecraft:black_concrete
fill 272 174 528 272 175 528 minecraft:bone_block
fill 272 174 533 272 174 537 minecraft:bone_block
fill 277 174 520 277 179 520 minecraft:black_concrete
fill 277 174 536 277 179 536 minecraft:black_concrete
fill 243 175 510 244 177 510 minecraft:black_concrete
setblock 244 175 524 minecraft:basalt
setblock 244 175 525 minecraft:magma_block
fill 244 175 526 244 175 527 minecraft:basalt
setblock 244 175 531 minecraft:magma_block
fill 244 175 532 244 175 533 minecraft:basalt
setblock 244 175 534 minecraft:magma_block
setblock 247 175 538 minecraft:basalt
fill 248 175 528 248 178 528 minecraft:basalt
fill 248 175 531 249 175 531 minecraft:basalt
fill 249 175 526 249 178 527 minecraft:basalt
fill 249 175 532 249 178 532 minecraft:basalt
setblock 250 175 518 minecraft:basalt
fill 250 175 524 250 177 525 minecraft:basalt
fill 250 175 533 250 177 534 minecraft:basalt
setblock 250 175 540 minecraft:basalt
fill 251 175 523 252 178 523 minecraft:basalt
fill 251 175 535 251 178 536 minecraft:basalt
fill 252 175 535 252 178 535 minecraft:basalt
setblock 253 175 522 minecraft:magma_block
fill 253 175 536 254 177 536 minecraft:basalt
fill 254 175 521 254 178 522 minecraft:basalt
fill 255 175 516 257 175 516 minecraft:basalt
fill 255 175 521 255 178 521 minecraft:basalt
setblock 255 175 542 minecraft:basalt
setblock 256 175 521 minecraft:magma_block
setblock 256 175 542 minecraft:magma_block
fill 257 175 521 258 178 521 minecraft:basalt
fill 257 175 537 257 178 537 minecraft:basalt
setblock 257 175 542 minecraft:basalt
fill 258 175 522 259 175 522 minecraft:basalt
fill 258 175 536 260 178 536 minecraft:basalt
setblock 259 175 517 minecraft:magma_block
setblock 259 175 541 minecraft:magma_block
fill 260 175 523 261 178 523 minecraft:basalt
fill 260 175 535 261 178 535 minecraft:basalt
fill 260 175 541 261 175 541 minecraft:basalt
setblock 261 175 517 minecraft:basalt
fill 262 175 524 262 177 524 minecraft:basalt
setblock 262 175 525 minecraft:magma_block
fill 262 175 533 262 177 533 minecraft:basalt
setblock 262 175 534 minecraft:magma_block
setblock 262 175 540 minecraft:magma_block
fill 263 175 526 263 178 527 minecraft:basalt
fill 263 175 531 263 178 532 minecraft:basalt
fill 263 175 539 264 175 539 minecraft:basalt
setblock 267 175 523 minecraft:basalt
setblock 267 175 535 minecraft:basalt
setblock 268 175 525 minecraft:basalt
setblock 268 175 526 minecraft:magma_block
setblock 268 175 532 minecraft:magma_block
setblock 268 175 533 minecraft:basalt
setblock 268 175 535 minecraft:bone_block
setblock 269 175 530 minecraft:basalt
fill 269 175 531 269 177 534 minecraft:bone_block
fill 270 175 530 271 181 530 minecraft:bone_block
fill 271 175 528 271 175 529 minecraft:bone_block
fill 271 175 531 272 179 531 minecraft:bone_block
setblock 272 175 529 minecraft:bone_block
fill 272 175 533 272 175 535 minecraft:bone_block
fill 235 176 543 235 212 544 minecraft:black_concrete
setblock 235 176 545 minecraft:crying_obsidian
setblock 244 176 527 minecraft:basalt
fill 244 176 530 244 176 531 minecraft:basalt
setblock 246 176 523 minecraft:magma_block
setblock 246 176 535 minecraft:magma_block
fill 248 176 531 248 178 531 minecraft:basalt
setblock 249 176 520 minecraft:basalt
setblock 249 176 528 minecraft:magma_block
fill 249 176 529 249 178 530 minecraft:basalt
setblock 249 176 531 minecraft:magma_block
fill 250 176 526 250 178 526 minecraft:basalt
fill 250 176 532 250 178 532 minecraft:basalt
setblock 251 176 518 minecraft:basalt
fill 251 176 524 251 178 524 minecraft:basalt
fill 251 176 534 251 178 534 minecraft:basalt
setblock 252 176 518 minecraft:magma_block
setblock 252 176 552 minecraft:white_concrete
fill 253 176 522 253 178 523 minecraft:basalt
fill 253 176 535 253 178 535 minecraft:basalt
setblock 254 176 517 minecraft:basalt
setblock 254 176 541 minecraft:basalt
setblock 255 176 517 minecraft:magma_block
fill 255 176 522 257 178 522 minecraft:basalt
fill 255 176 536 257 178 536 minecraft:basalt
setblock 255 176 541 minecraft:magma_block
fill 256 176 517 258 176 517 minecraft:basalt
fill 256 176 521 256 178 521 minecraft:basalt
fill 256 176 541 258 176 541 minecraft:basalt
setblock 258 176 522 minecraft:magma_block
fill 259 176 522 259 177 523 minecraft:basalt
fill 259 176 535 259 178 535 minecraft:basalt
setblock 260 176 518 minecraft:basalt
setblock 261 176 518 minecraft:magma_block
setblock 261 176 524 minecraft:magma_block
fill 261 176 534 262 178 534 minecraft:basalt
fill 262 176 525 262 178 526 minecraft:basalt
fill 262 176 532 262 178 532 minecraft:basalt
setblock 263 176 520 minecraft:basalt
fill 263 176 528 263 178 530 minecraft:basalt
setblock 264 176 520 minecraft:magma_block
setblock 264 176 538 minecraft:magma_block
fill 265 176 536 265 176 537 minecraft:basalt
setblock 267 176 524 minecraft:basalt
setblock 267 176 525 minecraft:magma_block
setblock 267 176 533 minecraft:basalt
setblock 267 176 534 minecraft:magma_block
fill 268 176 532 268 176 533 minecraft:bone_block
fill 269 176 530 269 180 530 minecraft:bone_block
fill 269 176 535 271 176 535 minecraft:bone_block
fill 270 176 529 271 182 529 minecraft:bone_block
fill 270 176 534 272 176 534 minecraft:bone_block
fill 272 176 530 272 180 530 minecraft:bone_block
fill 272 176 533 272 177 533 minecraft:bone_block
setblock 235 177 528 minecraft:white_concrete
fill 235 177 545 235 187 545 minecraft:black_concrete
fill 242 177 552 243 227 552 minecraft:black_concrete
setblock 244 177 552 minecraft:white_concrete
setblock 245 177 527 minecraft:basalt
setblock 245 177 528 minecraft:magma_block
fill 245 177 529 245 177 530 minecraft:basalt
setblock 245 177 531 minecraft:magma_block
fill 245 177 552 248 199 552 minecraft:black_concrete
setblock 248 177 536 minecraft:magma_block
fill 249 177 528 250 177 528 minecraft:basalt
fill 249 177 531 250 177 531 minecraft:basalt
setblock 250 177 520 minecraft:basalt
fill 250 177 527 250 178 527 minecraft:basalt
fill 250 177 529 250 177 530 minecraft:basalt
fill 251 177 525 251 178 525 minecraft:basalt
fill 251 177 533 251 178 533 minecraft:basalt
fill 252 177 524 252 178 524 minecraft:basalt
fill 252 177 534 252 178 534 minecraft:basalt
fill 252 177 552 252 259 552 minecraft:black_concrete
fill 254 177 518 256 177 518 minecraft:basalt
fill 254 177 523 258 177 523 minecraft:basalt
fill 254 177 535 258 177 535 minecraft:basalt
setblock 254 177 540 minecraft:magma_block
fill 256 177 540 258 177 540 minecraft:basalt
setblock 257 177 518 minecraft:magma_block
fill 258 177 522 258 178 522 minecraft:basalt
setblock 259 177 519 minecraft:basalt
fill 260 177 524 261 178 524 minecraft:basalt
fill 260 177 534 260 178 534 minecraft:basalt
fill 261 177 525 261 178 525 minecraft:basalt
fill 261 177 533 261 178 533 minecraft:basalt
fill 262 177 527 262 177 531 minecraft:basalt
setblock 262 177 538 minecraft:basalt
setblock 263 177 537 minecraft:magma_block
setblock 266 177 524 minecraft:magma_block
setblock 266 177 533 minecraft:magma_block
setblock 267 177 531 minecraft:basalt
fill 269 177 529 269 182 529 minecraft:bone_block
fill 270 177 528 271 182 528 minecraft:bone_block
fill 270 177 534 271 177 534 minecraft:bone_block
fill 272 177 529 272 181 529 minecraft:bone_block
fill 277 177 540 277 179 541 minecraft:black_concrete
setblock 277 177 542 minecraft:crying_obsidian
fill 277 177 543 277 211 544 minecraft:black_concrete
fill 277 177 546 277 183 548 minecraft:black_concrete
setblock 277 177 549 minecraft:amethyst_block
fill 277 177 550 277 210 551 minecraft:black_concrete
setblock 235 178 519 minecraft:amethyst_block
fill 235 178 528 235 233 528 minecraft:black_concrete
setblock 235 178 534 minecraft:white_concrete
setblock 243 178 510 minecraft:amethyst_block
setblock 244 178 510 minecraft:crying_obsidian
fill 244 178 552 244 197 552 minecraft:black_concrete
setblock 247 178 526 minecraft:magma_block
fill 247 178 527 247 178 528 minecraft:basalt
setblock 247 178 529 minecraft:magma_block
fill 247 178 530 247 178 531 minecraft:basalt
setblock 247 178 532 minecraft:magma_block
setblock 247 178 534 minecraft:basalt
setblock 249 178 522 minecraft:basalt
setblock 249 178 528 minecraft:basalt
setblock 249 178 531 minecraft:basalt
setblock 250 178 522 minecraft:magma_block
setblock 250 178 524 minecraft:basalt
setblock 250 178 525 minecraft:magma_block
fill 250 178 528 250 178 531 minecraft:magma_block
setblock 250 178 533 minecraft:basalt
setblock 250 178 534 minecraft:magma_block
setblock 250 178 537 minecraft:magma_block
fill 251 178 526 251 178 528 minecraft:magma_block
fill 251 178 530 251 178 532 minecraft:magma_block
setblock 252 178 510 minecraft:amethyst_block
setblock 252 178 521 minecraft:basalt
setblock 252 178 525 minecraft:magma_block
setblock 252 178 533 minecraft:magma_block
fill 253 178 510 253 188 510 minecraft:black_concrete
setblock 253 178 521 minecraft:magma_block
fill 253 178 524 255 178 524 minecraft:magma_block
fill 253 178 534 255 178 534 minecraft:magma_block
setblock 253 178 536 minecraft:magma_block
setblock 253 178 552 minecraft:crying_obsidian
setblock 254 178 523 minecraft:basalt
fill 254 178 535 254 178 536 minecraft:basalt
setblock 255 178 520 minecraft:basalt
fill 255 178 523 257 178 523 minecraft:magma_block
fill 255 178 535 257 178 535 minecraft:magma_block
fill 255 178 538 255 178 539 minecraft:basalt
setblock 256 178 520 minecraft:magma_block
setblock 256 178 538 minecraft:magma_block
setblock 257 178 520 minecraft:basalt
fill 257 178 524 259 178 524 minecraft:magma_block
fill 257 178 534 259 178 534 minecraft:magma_block
setblock 257 178 538 minecraft:basalt
fill 258 178 523 259 178 523 minecraft:basalt
setblock 258 178 535 minecraft:basalt
setblock 259 178 522 minecraft:magma_block
setblock 259 178 537 minecraft:magma_block
setblock 259 178 538 minecraft:basalt
setblock 260 178 525 minecraft:magma_block
setblock 260 178 533 minecraft:magma_block
fill 261 178 526 261 178 528 minecraft:magma_block
fill 261 178 530 261 178 532 minecraft:magma_block
setblock 262 178 521 minecraft:magma_block
setblock 262 178 524 minecraft:magma_block
fill 262 178 527 262 178 530 minecraft:magma_block
setblock 262 178 531 minecraft:basalt
setblock 262 178 533 minecraft:magma_block
setblock 262 178 536 minecraft:magma_block
setblock 263 178 522 minecraft:basalt
setblock 263 178 536 minecraft:basalt
setblock 265 178 526 minecraft:magma_block
fill 265 178 527 265 178 528 minecraft:basalt
setblock 265 178 529 minecraft:magma_block
fill 265 178 530 265 178 531 minecraft:basalt
setblock 265 178 532 minecraft:magma_block
setblock 267 178 552 minecraft:crying_obsidian
setblock 268 178 530 minecraft:bone_block
fill 269 178 528 269 183 528 minecraft:bone_block
fill 269 178 531 269 178 532 minecraft:bone_block
fill 270 178 527 271 183 527 minecraft:bone_block
fill 272 178 528 272 181 528 minecraft:bone_block
fill 277 178 530 277 190 530 minecraft:black_concrete
setblock 277 178 531 minecraft:white_concrete
fill 277 178 532 277 199 532 minecraft:black_concrete
setblock 277 178 535 minecraft:amethyst_block
fill 277 178 542 277 257 542 minecraft:black_concrete
fill 277 178 549 277 192 549 minecraft:black_concrete
fill 235 179 519 235 189 519 minecraft:black_concrete
fill 235 179 534 235 179 535 minecraft:black_concrete
setblock 235 179 536 minecraft:crying_obsidian
setblock 238 179 513 minecraft:light[level=12]
setblock 238 179 521 minecraft:light[level=12]
setblock 238 179 529 minecraft:light[level=12]
setblock 238 179 537 minecraft:light[level=12]
setblock 238 179 545 minecraft:light[level=12]
fill 243 179 510 244 187 510 minecraft:black_concrete
setblock 246 179 513 minecraft:light[level=12]
setblock 246 179 521 minecraft:light[level=12]
setblock 246 179 529 minecraft:light[level=12]
setblock 246 179 537 minecraft:light[level=12]
setblock 246 179 545 minecraft:light[level=12]
fill 252 179 510 252 180 510 minecraft:black_concrete
fill 253 179 552 253 197 552 minecraft:black_concrete
setblock 254 179 513 minecraft:light[level=12]
setblock 254 179 521 minecraft:light[level=12]
setblock 254 179 529 minecraft:light[level=12]
setblock 254 179 537 minecraft:light[level=12]
setblock 254 179 545 minecraft:light[level=12]
fill 260 179 550 260 182 550 minecraft:amethyst_block
fill 261 179 546 261 180 547 minecraft:white_concrete
setblock 262 179 513 minecraft:light[level=12]
setblock 262 179 521 minecraft:light[level=12]
setblock 262 179 529 minecraft:light[level=12]
setblock 262 179 537 minecraft:light[level=12]
setblock 262 179 545 minecraft:light[level=12]
fill 265 179 513 265 180 514 minecraft:bone_block
fill 267 179 552 267 195 552 minecraft:black_concrete
fill 268 179 528 268 180 529 minecraft:bone_block
fill 269 179 526 269 184 527 minecraft:bone_block
fill 269 179 531 270 179 531 minecraft:bone_block
setblock 270 179 513 minecraft:light[level=12]
setblock 270 179 521 minecraft:light[level=12]
fill 270 179 526 271 184 526 minecraft:bone_block
fill 270 179 532 271 179 532 minecraft:bone_block
setblock 270 179 537 minecraft:light[level=12]
setblock 270 179 545 minecraft:light[level=12]
fill 272 179 527 272 182 527 minecraft:bone_block
fill 275 179 529 276 180 529 minecraft:bone_block
fill 277 179 531 277 207 531 minecraft:black_concrete
fill 277 179 535 277 183 535 minecraft:black_concrete
fill 235 180 518 235 182 518 minecraft:purple_concrete
fill 235 180 534 235 182 534 minecraft:purple_concrete
fill 235 180 535 235 260 536 minecraft:black_concrete
fill 235 180 550 235 182 550 minecraft:purple_concrete
fill 236 180 552 236 307 552 minecraft:black_concrete
schedule function dropper:buildpart/125_2 1t
