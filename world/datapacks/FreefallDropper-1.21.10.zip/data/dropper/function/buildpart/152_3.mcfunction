fill 391 168 604 392 169 604 minecraft:red_concrete
fill 391 168 645 393 168 645 minecraft:polished_blackstone
fill 393 168 605 395 168 605 minecraft:polished_blackstone
fill 395 168 645 397 168 645 minecraft:polished_blackstone
fill 397 168 604 398 173 604 minecraft:purple_terracotta
fill 397 168 605 399 168 605 minecraft:polished_blackstone
fill 398 168 646 399 168 646 minecraft:red_concrete
fill 399 168 604 400 168 604 minecraft:red_concrete
fill 399 168 645 401 168 645 minecraft:polished_blackstone
fill 400 168 646 401 173 646 minecraft:purple_terracotta
fill 401 168 605 403 168 605 minecraft:polished_blackstone
fill 403 168 645 405 168 645 minecraft:polished_blackstone
fill 405 168 605 407 168 605 minecraft:polished_blackstone
fill 407 168 645 409 168 645 minecraft:polished_blackstone
fill 407 168 646 407 169 646 minecraft:red_concrete
fill 408 168 646 409 173 646 minecraft:purple_terracotta
fill 409 168 604 410 173 604 minecraft:purple_terracotta
fill 409 168 605 411 168 605 minecraft:polished_blackstone
setblock 410 168 646 minecraft:red_concrete
fill 411 168 604 412 169 604 minecraft:red_concrete
fill 411 168 645 413 168 645 minecraft:polished_blackstone
fill 412 168 646 412 173 646 minecraft:purple_terracotta
fill 413 168 605 415 168 605 minecraft:polished_blackstone
fill 415 168 645 417 168 645 minecraft:polished_blackstone
fill 417 168 605 417 168 607 minecraft:polished_blackstone
fill 417 168 609 417 168 611 minecraft:polished_blackstone
fill 417 168 613 417 168 615 minecraft:polished_blackstone
fill 417 168 617 417 168 619 minecraft:polished_blackstone
fill 417 168 621 417 168 623 minecraft:polished_blackstone
fill 417 168 625 417 168 627 minecraft:polished_blackstone
fill 417 168 629 417 168 631 minecraft:polished_blackstone
fill 417 168 633 417 168 635 minecraft:polished_blackstone
fill 417 168 637 417 168 639 minecraft:polished_blackstone
fill 417 168 641 417 168 643 minecraft:polished_blackstone
fill 418 168 604 418 173 604 minecraft:purple_terracotta
fill 418 168 605 418 168 606 minecraft:red_concrete
fill 418 168 607 418 169 608 minecraft:purple_terracotta
fill 418 168 609 418 169 609 minecraft:red_concrete
fill 418 168 615 418 173 616 minecraft:purple_terracotta
fill 418 168 617 418 169 618 minecraft:red_concrete
setblock 418 168 626 minecraft:red_concrete
fill 418 168 627 418 173 628 minecraft:purple_terracotta
fill 418 168 629 418 169 630 minecraft:red_concrete
fill 418 168 635 418 173 636 minecraft:purple_terracotta
fill 418 168 637 418 168 638 minecraft:red_concrete
fill 418 168 639 418 173 639 minecraft:purple_terracotta
fill 418 168 646 418 169 646 minecraft:red_concrete
fill 376 169 612 376 169 613 minecraft:red_concrete
setblock 376 169 616 minecraft:red_concrete
fill 376 169 617 376 172 617 minecraft:purple_terracotta
fill 376 169 628 376 172 628 minecraft:purple_terracotta
setblock 376 169 633 minecraft:red_concrete
setblock 376 169 644 minecraft:red_concrete
fill 378 169 646 379 172 646 minecraft:purple_terracotta
setblock 383 169 604 minecraft:red_concrete
fill 384 169 604 384 171 604 minecraft:purple_terracotta
fill 388 169 604 388 172 604 minecraft:purple_terracotta
setblock 395 169 646 minecraft:red_concrete
setblock 398 169 646 minecraft:red_concrete
fill 399 169 604 399 172 604 minecraft:purple_terracotta
fill 399 169 646 399 172 646 minecraft:purple_terracotta
setblock 400 169 604 minecraft:red_concrete
setblock 403 169 604 minecraft:red_concrete
setblock 406 169 646 minecraft:red_concrete
fill 410 169 646 410 172 646 minecraft:purple_terracotta
fill 418 169 605 418 172 606 minecraft:purple_terracotta
setblock 418 169 610 minecraft:red_concrete
setblock 418 169 621 minecraft:red_concrete
fill 418 169 626 418 172 626 minecraft:purple_terracotta
fill 418 169 637 418 172 637 minecraft:purple_terracotta
setblock 418 169 638 minecraft:red_concrete
fill 418 169 641 418 169 642 minecraft:red_concrete
fill 376 170 604 376 175 605 minecraft:purple_terracotta
fill 376 170 611 376 171 611 minecraft:red_concrete
fill 376 170 612 376 175 613 minecraft:purple_terracotta
setblock 376 170 614 minecraft:red_concrete
fill 376 170 616 376 175 616 minecraft:purple_terracotta
fill 376 170 622 376 171 623 minecraft:red_concrete
fill 376 170 624 376 175 625 minecraft:purple_terracotta
fill 376 170 633 376 175 633 minecraft:purple_terracotta
fill 376 170 634 376 170 635 minecraft:red_concrete
fill 376 170 636 376 175 637 minecraft:purple_terracotta
fill 376 170 642 376 171 643 minecraft:red_concrete
fill 376 170 644 376 175 645 minecraft:purple_terracotta
setblock 376 170 646 minecraft:red_concrete
fill 377 170 646 377 173 646 minecraft:purple_terracotta
fill 379 170 604 380 175 604 minecraft:purple_terracotta
setblock 379 170 607 minecraft:light[level=12]
setblock 379 170 615 minecraft:light[level=12]
setblock 379 170 623 minecraft:light[level=12]
setblock 379 170 631 minecraft:light[level=12]
setblock 379 170 639 minecraft:light[level=12]
fill 381 170 604 382 170 604 minecraft:red_concrete
fill 383 170 604 383 171 604 minecraft:purple_terracotta
fill 384 170 646 385 171 646 minecraft:red_concrete
fill 386 170 646 387 175 646 minecraft:purple_terracotta
setblock 387 170 607 minecraft:light[level=12]
setblock 387 170 615 minecraft:light[level=12]
setblock 387 170 623 minecraft:light[level=12]
setblock 387 170 631 minecraft:light[level=12]
setblock 387 170 639 minecraft:light[level=12]
fill 390 170 613 390 171 613 minecraft:magma_block
fill 391 170 604 392 175 604 minecraft:purple_terracotta
fill 393 170 604 394 171 604 minecraft:red_concrete
fill 393 170 646 393 171 646 minecraft:red_concrete
setblock 395 170 607 minecraft:light[level=12]
setblock 395 170 615 minecraft:light[level=12]
setblock 395 170 623 minecraft:light[level=12]
setblock 395 170 631 minecraft:light[level=12]
setblock 395 170 639 minecraft:light[level=12]
fill 395 170 646 395 175 646 minecraft:purple_terracotta
fill 396 170 646 397 170 646 minecraft:red_concrete
fill 398 170 646 398 175 646 minecraft:purple_terracotta
fill 400 170 604 400 175 604 minecraft:purple_terracotta
fill 401 170 604 402 170 604 minecraft:red_concrete
fill 403 170 604 403 175 604 minecraft:purple_terracotta
setblock 403 170 607 minecraft:light[level=12]
setblock 403 170 615 minecraft:light[level=12]
setblock 403 170 623 minecraft:light[level=12]
setblock 403 170 631 minecraft:light[level=12]
setblock 403 170 639 minecraft:light[level=12]
fill 404 170 646 405 171 646 minecraft:red_concrete
fill 405 170 604 405 171 604 minecraft:red_concrete
fill 406 170 646 407 175 646 minecraft:purple_terracotta
fill 411 170 604 412 175 604 minecraft:purple_terracotta
setblock 411 170 607 minecraft:light[level=12]
setblock 411 170 615 minecraft:light[level=12]
setblock 411 170 623 minecraft:light[level=12]
setblock 411 170 631 minecraft:light[level=12]
setblock 411 170 639 minecraft:light[level=12]
fill 413 170 604 414 171 604 minecraft:red_concrete
fill 416 170 646 417 170 646 minecraft:red_concrete
fill 418 170 607 418 173 607 minecraft:purple_terracotta
setblock 418 170 608 minecraft:red_concrete
fill 418 170 609 418 175 610 minecraft:purple_terracotta
fill 418 170 611 418 171 612 minecraft:red_concrete
fill 418 170 617 418 175 618 minecraft:purple_terracotta
fill 418 170 619 418 170 620 minecraft:red_concrete
fill 418 170 621 418 175 621 minecraft:purple_terracotta
fill 418 170 629 418 175 630 minecraft:purple_terracotta
fill 418 170 631 418 171 632 minecraft:red_concrete
fill 418 170 638 418 175 638 minecraft:purple_terracotta
setblock 418 170 640 minecraft:red_concrete
fill 418 170 641 418 175 642 minecraft:purple_terracotta
fill 418 170 643 418 171 643 minecraft:red_concrete
fill 418 170 646 418 175 646 minecraft:purple_terracotta
setblock 376 171 610 minecraft:red_concrete
fill 376 171 614 376 174 614 minecraft:purple_terracotta
fill 376 171 630 376 171 631 minecraft:red_concrete
setblock 376 171 634 minecraft:red_concrete
fill 376 171 635 376 174 635 minecraft:purple_terracotta
fill 376 171 646 376 174 646 minecraft:purple_terracotta
fill 381 171 604 381 174 604 minecraft:purple_terracotta
fill 381 171 621 384 178 623 minecraft:orange_concrete
setblock 381 171 646 minecraft:red_concrete
setblock 382 171 604 minecraft:red_concrete
fill 382 171 624 384 178 624 minecraft:orange_concrete
fill 383 171 620 383 178 620 minecraft:orange_concrete
fill 385 171 604 386 171 604 minecraft:red_concrete
fill 385 171 622 385 178 623 minecraft:orange_concrete
setblock 392 171 646 minecraft:red_concrete
fill 396 171 646 397 174 646 minecraft:purple_terracotta
fill 401 171 604 402 173 604 minecraft:purple_terracotta
setblock 406 171 604 minecraft:red_concrete
setblock 413 171 646 minecraft:red_concrete
setblock 416 171 646 minecraft:red_concrete
setblock 417 171 604 minecraft:red_concrete
fill 417 171 646 417 174 646 minecraft:purple_terracotta
fill 418 171 608 418 174 608 minecraft:purple_terracotta
fill 418 171 619 418 174 619 minecraft:purple_terracotta
setblock 418 171 620 minecraft:red_concrete
fill 418 171 623 418 171 624 minecraft:red_concrete
fill 418 171 640 418 174 640 minecraft:purple_terracotta
setblock 418 171 644 minecraft:red_concrete
fill 376 172 608 376 173 609 minecraft:red_concrete
fill 376 172 610 376 177 611 minecraft:purple_terracotta
fill 376 172 620 376 172 621 minecraft:red_concrete
fill 376 172 622 376 177 623 minecraft:purple_terracotta
fill 376 172 629 376 173 629 minecraft:red_concrete
fill 376 172 630 376 177 631 minecraft:purple_terracotta
setblock 376 172 632 minecraft:red_concrete
fill 376 172 634 376 177 634 minecraft:purple_terracotta
fill 376 172 640 376 173 641 minecraft:red_concrete
fill 376 172 642 376 177 643 minecraft:purple_terracotta
fill 380 172 621 380 177 624 minecraft:orange_concrete
fill 381 172 620 382 177 620 minecraft:orange_concrete
fill 381 172 624 381 177 625 minecraft:orange_concrete
fill 381 172 646 381 177 646 minecraft:purple_terracotta
fill 382 172 604 382 177 604 minecraft:purple_terracotta
fill 382 172 625 385 177 625 minecraft:orange_concrete
fill 382 172 646 383 172 646 minecraft:red_concrete
fill 383 172 604 384 172 604 minecraft:red_concrete
fill 383 172 619 383 177 619 minecraft:orange_concrete
fill 384 172 620 385 177 620 minecraft:orange_concrete
fill 384 172 646 385 177 646 minecraft:purple_terracotta
fill 385 172 604 386 173 604 minecraft:purple_terracotta
fill 385 172 621 386 177 621 minecraft:orange_concrete
fill 385 172 624 385 177 624 minecraft:orange_concrete
fill 386 172 622 386 177 623 minecraft:orange_concrete
fill 387 172 604 387 173 604 minecraft:red_concrete
fill 390 172 646 391 173 646 minecraft:red_concrete
fill 392 172 646 393 177 646 minecraft:purple_terracotta
fill 393 172 604 394 177 604 minecraft:purple_terracotta
fill 393 172 637 394 199 639 minecraft:polished_blackstone
setblock 394 172 646 minecraft:red_concrete
fill 395 172 604 396 173 604 minecraft:red_concrete
fill 395 172 638 395 199 638 minecraft:polished_blackstone
fill 402 172 646 403 173 646 minecraft:red_concrete
setblock 404 172 604 minecraft:red_concrete
fill 404 172 646 405 177 646 minecraft:purple_terracotta
fill 405 172 604 406 177 604 minecraft:purple_terracotta
fill 407 172 604 408 173 604 minecraft:red_concrete
fill 411 172 646 411 173 646 minecraft:red_concrete
fill 413 172 604 414 177 604 minecraft:purple_terracotta
fill 413 172 646 413 177 646 minecraft:purple_terracotta
fill 414 172 646 415 172 646 minecraft:red_concrete
fill 415 172 604 416 172 604 minecraft:red_concrete
fill 416 172 646 416 177 646 minecraft:purple_terracotta
fill 417 172 604 417 177 604 minecraft:purple_terracotta
fill 418 172 611 418 177 612 minecraft:purple_terracotta
fill 418 172 613 418 173 614 minecraft:red_concrete
fill 418 172 620 418 177 620 minecraft:purple_terracotta
setblock 418 172 622 minecraft:red_concrete
fill 418 172 623 418 177 624 minecraft:purple_terracotta
fill 418 172 625 418 173 625 minecraft:red_concrete
fill 418 172 631 418 177 632 minecraft:purple_terracotta
fill 418 172 633 418 172 634 minecraft:red_concrete
fill 418 172 643 418 177 644 minecraft:purple_terracotta
fill 418 172 645 418 173 645 minecraft:red_concrete
setblock 376 173 617 minecraft:red_concrete
setblock 376 173 620 minecraft:red_concrete
fill 376 173 621 376 176 621 minecraft:purple_terracotta
setblock 376 173 628 minecraft:red_concrete
fill 376 173 632 376 176 632 minecraft:purple_terracotta
fill 378 173 646 379 173 646 minecraft:red_concrete
fill 379 173 622 379 176 622 minecraft:orange_concrete
fill 380 173 620 380 176 620 minecraft:orange_concrete
fill 380 173 625 380 176 625 minecraft:orange_concrete
fill 381 173 619 382 176 619 minecraft:orange_concrete
fill 382 173 626 384 176 626 minecraft:orange_concrete
setblock 382 173 646 minecraft:red_concrete
fill 383 173 604 384 175 604 minecraft:purple_terracotta
fill 383 173 646 383 176 646 minecraft:purple_terracotta
fill 384 173 619 385 176 619 minecraft:orange_concrete
fill 386 173 620 386 176 620 minecraft:orange_concrete
fill 386 173 624 386 176 624 minecraft:orange_concrete
setblock 388 173 604 minecraft:red_concrete
fill 392 173 637 392 174 639 minecraft:black_concrete
fill 393 173 640 394 174 640 minecraft:black_concrete
fill 394 173 646 394 176 646 minecraft:purple_terracotta
fill 395 173 637 395 174 637 minecraft:black_concrete
fill 395 173 639 395 174 639 minecraft:black_concrete
setblock 399 173 604 minecraft:red_concrete
setblock 399 173 646 minecraft:red_concrete
fill 404 173 604 404 175 604 minecraft:purple_terracotta
setblock 410 173 646 minecraft:red_concrete
fill 414 173 646 415 176 646 minecraft:purple_terracotta
fill 415 173 604 415 176 604 minecraft:purple_terracotta
setblock 416 173 604 minecraft:red_concrete
fill 418 173 605 418 173 606 minecraft:red_concrete
fill 418 173 622 418 176 622 minecraft:purple_terracotta
setblock 418 173 626 minecraft:red_concrete
fill 418 173 633 418 176 633 minecraft:purple_terracotta
setblock 418 173 634 minecraft:red_concrete
setblock 418 173 637 minecraft:red_concrete
fill 376 174 606 376 175 607 minecraft:red_concrete
fill 376 174 608 376 179 609 minecraft:purple_terracotta
fill 376 174 615 376 175 615 minecraft:red_concrete
fill 376 174 617 376 179 617 minecraft:purple_terracotta
fill 376 174 618 376 174 619 minecraft:red_concrete
fill 376 174 620 376 179 620 minecraft:purple_terracotta
fill 376 174 626 376 175 627 minecraft:red_concrete
fill 376 174 628 376 179 629 minecraft:purple_terracotta
fill 376 174 638 376 174 639 minecraft:red_concrete
fill 376 174 640 376 179 641 minecraft:purple_terracotta
fill 377 174 604 378 175 604 minecraft:red_concrete
fill 377 174 605 379 174 605 minecraft:polished_blackstone
fill 377 174 607 377 174 609 minecraft:polished_blackstone
fill 377 174 611 377 174 613 minecraft:polished_blackstone
fill 377 174 615 377 174 617 minecraft:polished_blackstone
fill 377 174 619 377 174 621 minecraft:polished_blackstone
fill 377 174 623 377 174 625 minecraft:polished_blackstone
fill 377 174 627 377 174 629 minecraft:polished_blackstone
fill 377 174 631 377 174 633 minecraft:polished_blackstone
fill 377 174 635 377 174 637 minecraft:polished_blackstone
fill 377 174 639 377 174 641 minecraft:polished_blackstone
fill 377 174 643 377 174 645 minecraft:polished_blackstone
fill 377 174 646 377 175 646 minecraft:red_concrete
fill 378 174 646 379 179 646 minecraft:purple_terracotta
fill 379 174 621 379 175 621 minecraft:orange_concrete
fill 379 174 623 379 175 623 minecraft:orange_concrete
fill 379 174 645 381 174 645 minecraft:polished_blackstone
setblock 380 174 646 minecraft:red_concrete
fill 381 174 605 383 174 605 minecraft:polished_blackstone
fill 381 174 626 381 175 626 minecraft:orange_concrete
fill 382 174 646 382 179 646 minecraft:purple_terracotta
fill 383 174 645 385 174 645 minecraft:polished_blackstone
fill 385 174 604 385 177 604 minecraft:purple_terracotta
fill 385 174 605 387 174 605 minecraft:polished_blackstone
fill 385 174 626 385 175 626 minecraft:orange_concrete
setblock 386 174 604 minecraft:red_concrete
fill 386 174 625 386 175 625 minecraft:orange_concrete
fill 387 174 604 388 179 604 minecraft:purple_terracotta
fill 387 174 622 387 175 623 minecraft:orange_concrete
fill 387 174 645 389 174 645 minecraft:polished_blackstone
fill 388 174 646 389 175 646 minecraft:red_concrete
fill 389 174 604 390 175 604 minecraft:red_concrete
fill 389 174 605 391 174 605 minecraft:polished_blackstone
fill 390 174 646 391 179 646 minecraft:purple_terracotta
fill 391 174 645 393 174 645 minecraft:polished_blackstone
setblock 392 174 640 minecraft:black_concrete
fill 393 174 605 395 174 605 minecraft:polished_blackstone
fill 393 174 636 395 174 636 minecraft:black_concrete
fill 395 174 604 396 176 604 minecraft:purple_terracotta
setblock 395 174 640 minecraft:black_concrete
fill 395 174 645 397 174 645 minecraft:polished_blackstone
fill 396 174 638 396 174 639 minecraft:black_concrete
fill 397 174 604 398 174 604 minecraft:red_concrete
fill 397 174 605 399 174 605 minecraft:polished_blackstone
fill 399 174 604 399 179 604 minecraft:purple_terracotta
fill 399 174 645 401 174 645 minecraft:polished_blackstone
fill 399 174 646 399 179 646 minecraft:purple_terracotta
fill 400 174 646 401 174 646 minecraft:red_concrete
fill 401 174 604 401 175 604 minecraft:red_concrete
fill 401 174 605 403 174 605 minecraft:polished_blackstone
setblock 402 174 604 minecraft:purple_terracotta
fill 402 174 646 403 179 646 minecraft:purple_terracotta
fill 403 174 645 405 174 645 minecraft:polished_blackstone
fill 405 174 605 407 174 605 minecraft:polished_blackstone
fill 407 174 604 408 179 604 minecraft:purple_terracotta
fill 407 174 645 409 174 645 minecraft:polished_blackstone
fill 408 174 646 409 175 646 minecraft:red_concrete
fill 409 174 604 410 175 604 minecraft:red_concrete
fill 409 174 605 411 174 605 minecraft:polished_blackstone
fill 410 174 646 411 179 646 minecraft:purple_terracotta
fill 411 174 645 413 174 645 minecraft:polished_blackstone
setblock 412 174 646 minecraft:red_concrete
fill 413 174 605 415 174 605 minecraft:polished_blackstone
fill 415 174 645 417 174 645 minecraft:polished_blackstone
fill 416 174 604 416 179 604 minecraft:purple_terracotta
fill 417 174 605 417 174 607 minecraft:polished_blackstone
fill 417 174 609 417 174 611 minecraft:polished_blackstone
fill 417 174 613 417 174 615 minecraft:polished_blackstone
fill 417 174 617 417 174 619 minecraft:polished_blackstone
fill 417 174 621 417 174 623 minecraft:polished_blackstone
fill 417 174 625 417 174 627 minecraft:polished_blackstone
fill 417 174 629 417 174 631 minecraft:polished_blackstone
fill 417 174 633 417 174 635 minecraft:polished_blackstone
fill 417 174 637 417 174 639 minecraft:polished_blackstone
fill 417 174 641 417 174 643 minecraft:polished_blackstone
setblock 418 174 604 minecraft:red_concrete
fill 418 174 605 418 179 606 minecraft:purple_terracotta
fill 418 174 607 418 175 607 minecraft:red_concrete
fill 418 174 613 418 179 614 minecraft:purple_terracotta
fill 418 174 615 418 174 616 minecraft:red_concrete
fill 418 174 625 418 179 626 minecraft:purple_terracotta
fill 418 174 627 418 175 628 minecraft:red_concrete
fill 418 174 634 418 179 634 minecraft:purple_terracotta
fill 418 174 635 418 174 636 minecraft:red_concrete
fill 418 174 637 418 179 637 minecraft:purple_terracotta
fill 418 174 639 418 175 639 minecraft:red_concrete
fill 418 174 645 418 179 645 minecraft:purple_terracotta
setblock 376 175 614 minecraft:red_concrete
fill 376 175 618 376 178 619 minecraft:purple_terracotta
setblock 376 175 635 minecraft:red_concrete
setblock 376 175 638 minecraft:red_concrete
fill 376 175 639 376 178 639 minecraft:purple_terracotta
setblock 376 175 646 minecraft:red_concrete
fill 380 175 646 380 178 646 minecraft:purple_terracotta
setblock 381 175 604 minecraft:red_concrete
fill 386 175 604 386 177 604 minecraft:purple_terracotta
fill 396 175 646 397 175 646 minecraft:red_concrete
fill 397 175 604 397 178 604 minecraft:purple_terracotta
setblock 398 175 604 minecraft:red_concrete
setblock 400 175 646 minecraft:red_concrete
fill 401 175 646 401 178 646 minecraft:purple_terracotta
setblock 402 175 604 minecraft:red_concrete
fill 412 175 646 412 178 646 minecraft:purple_terracotta
setblock 417 175 646 minecraft:red_concrete
fill 418 175 604 418 178 604 minecraft:purple_terracotta
setblock 418 175 608 minecraft:red_concrete
fill 418 175 615 418 178 615 minecraft:purple_terracotta
setblock 418 175 616 minecraft:red_concrete
setblock 418 175 619 minecraft:red_concrete
fill 418 175 635 418 178 636 minecraft:purple_terracotta
setblock 418 175 640 minecraft:red_concrete
fill 376 176 604 376 176 605 minecraft:red_concrete
fill 376 176 606 376 181 607 minecraft:purple_terracotta
fill 376 176 612 376 177 613 minecraft:red_concrete
fill 376 176 614 376 181 615 minecraft:purple_terracotta
setblock 376 176 616 minecraft:red_concrete
fill 376 176 624 376 177 625 minecraft:red_concrete
fill 376 176 626 376 181 627 minecraft:purple_terracotta
fill 376 176 633 376 177 633 minecraft:red_concrete
fill 376 176 635 376 181 635 minecraft:purple_terracotta
fill 376 176 636 376 176 637 minecraft:red_concrete
fill 376 176 638 376 181 638 minecraft:purple_terracotta
fill 376 176 644 376 177 645 minecraft:red_concrete
fill 376 176 646 377 181 646 minecraft:purple_terracotta
fill 377 176 604 378 178 604 minecraft:purple_terracotta
fill 379 176 604 380 176 604 minecraft:red_concrete
fill 381 176 604 381 181 604 minecraft:purple_terracotta
fill 383 176 604 383 177 604 minecraft:red_concrete
setblock 384 176 604 minecraft:purple_terracotta
fill 386 176 646 387 176 646 minecraft:red_concrete
fill 388 176 646 389 181 646 minecraft:purple_terracotta
fill 389 176 604 390 181 604 minecraft:purple_terracotta
fill 391 176 604 392 177 604 minecraft:red_concrete
fill 395 176 646 395 177 646 minecraft:red_concrete
fill 396 176 646 397 181 646 minecraft:purple_terracotta
fill 398 176 604 398 178 604 minecraft:purple_terracotta
setblock 398 176 646 minecraft:red_concrete
setblock 400 176 604 minecraft:red_concrete
fill 400 176 646 400 181 646 minecraft:purple_terracotta
fill 401 176 604 402 181 604 minecraft:purple_terracotta
fill 403 176 604 404 177 604 minecraft:red_concrete
fill 406 176 646 407 177 646 minecraft:red_concrete
fill 408 176 646 409 181 646 minecraft:purple_terracotta
fill 409 176 604 410 181 604 minecraft:purple_terracotta
fill 411 176 604 412 176 604 minecraft:red_concrete
fill 417 176 646 417 181 646 minecraft:purple_terracotta
fill 418 176 607 418 181 608 minecraft:purple_terracotta
fill 418 176 609 418 177 610 minecraft:red_concrete
fill 418 176 616 418 181 616 minecraft:purple_terracotta
fill 418 176 617 418 176 618 minecraft:red_concrete
fill 418 176 619 418 181 619 minecraft:purple_terracotta
fill 418 176 621 418 177 621 minecraft:red_concrete
fill 418 176 627 418 181 628 minecraft:purple_terracotta
fill 418 176 629 418 177 630 minecraft:red_concrete
setblock 418 176 638 minecraft:red_concrete
fill 418 176 639 418 181 640 minecraft:purple_terracotta
fill 418 176 641 418 177 642 minecraft:red_concrete
fill 418 176 646 418 177 646 minecraft:red_concrete
setblock 376 177 604 minecraft:red_concrete
fill 376 177 605 376 180 605 minecraft:purple_terracotta
fill 376 177 616 376 180 616 minecraft:purple_terracotta
setblock 376 177 621 minecraft:red_concrete
setblock 376 177 632 minecraft:red_concrete
fill 376 177 636 376 180 637 minecraft:purple_terracotta
fill 379 177 604 379 180 604 minecraft:purple_terracotta
setblock 380 177 604 minecraft:red_concrete
setblock 383 177 646 minecraft:red_concrete
setblock 384 177 604 minecraft:red_concrete
setblock 386 177 646 minecraft:red_concrete
fill 387 177 646 387 180 646 minecraft:purple_terracotta
setblock 394 177 646 minecraft:red_concrete
setblock 395 177 604 minecraft:red_concrete
fill 396 177 604 396 179 604 minecraft:purple_terracotta
fill 398 177 646 398 180 646 minecraft:purple_terracotta
fill 400 177 604 400 180 604 minecraft:purple_terracotta
fill 411 177 604 411 180 604 minecraft:purple_terracotta
setblock 412 177 604 minecraft:red_concrete
fill 414 177 646 415 177 646 minecraft:red_concrete
setblock 415 177 604 minecraft:red_concrete
fill 418 177 617 418 180 618 minecraft:purple_terracotta
setblock 418 177 622 minecraft:red_concrete
setblock 418 177 633 minecraft:red_concrete
fill 418 177 638 418 180 638 minecraft:purple_terracotta
fill 376 178 604 376 183 604 minecraft:purple_terracotta
fill 376 178 610 376 179 611 minecraft:red_concrete
fill 376 178 612 376 183 613 minecraft:purple_terracotta
fill 376 178 621 376 183 621 minecraft:purple_terracotta
fill 376 178 622 376 178 623 minecraft:red_concrete
fill 376 178 624 376 183 625 minecraft:purple_terracotta
fill 376 178 630 376 179 631 minecraft:red_concrete
fill 376 178 632 376 183 633 minecraft:purple_terracotta
setblock 376 178 634 minecraft:red_concrete
fill 376 178 642 376 179 643 minecraft:red_concrete
fill 376 178 644 376 183 645 minecraft:purple_terracotta
setblock 379 178 607 minecraft:light[level=12]
setblock 379 178 615 minecraft:light[level=12]
setblock 379 178 623 minecraft:light[level=12]
setblock 379 178 631 minecraft:light[level=12]
setblock 379 178 639 minecraft:light[level=12]
fill 380 178 604 380 180 604 minecraft:purple_terracotta
fill 381 178 646 381 179 646 minecraft:red_concrete
setblock 382 178 604 minecraft:red_concrete
fill 383 178 604 384 183 604 minecraft:purple_terracotta
fill 383 178 646 383 183 646 minecraft:purple_terracotta
fill 384 178 646 385 178 646 minecraft:red_concrete
fill 385 178 604 386 179 604 minecraft:red_concrete
fill 386 178 646 386 183 646 minecraft:purple_terracotta
setblock 387 178 607 minecraft:light[level=12]
setblock 387 178 615 minecraft:light[level=12]
setblock 387 178 623 minecraft:light[level=12]
setblock 387 178 631 minecraft:light[level=12]
setblock 387 178 639 minecraft:light[level=12]
fill 391 178 604 392 183 604 minecraft:purple_terracotta
fill 392 178 646 393 179 646 minecraft:red_concrete
fill 393 178 604 394 178 604 minecraft:red_concrete
fill 394 178 646 395 183 646 minecraft:purple_terracotta
fill 395 178 604 395 179 604 minecraft:purple_terracotta
setblock 395 178 607 minecraft:light[level=12]
setblock 395 178 615 minecraft:light[level=12]
setblock 395 178 623 minecraft:light[level=12]
setblock 395 178 631 minecraft:light[level=12]
setblock 395 178 639 minecraft:light[level=12]
fill 403 178 604 404 183 604 minecraft:purple_terracotta
setblock 403 178 607 minecraft:light[level=12]
setblock 403 178 615 minecraft:light[level=12]
setblock 403 178 623 minecraft:light[level=12]
setblock 403 178 631 minecraft:light[level=12]
setblock 403 178 639 minecraft:light[level=12]
fill 404 178 635 405 179 635 minecraft:blackstone
fill 404 178 646 405 178 646 minecraft:red_concrete
fill 405 178 604 406 179 604 minecraft:red_concrete
fill 406 178 646 407 183 646 minecraft:purple_terracotta
setblock 411 178 607 minecraft:light[level=12]
setblock 411 178 615 minecraft:light[level=12]
setblock 411 178 623 minecraft:light[level=12]
setblock 411 178 631 minecraft:light[level=12]
setblock 411 178 639 minecraft:light[level=12]
fill 412 178 604 412 183 604 minecraft:purple_terracotta
fill 413 178 604 414 178 604 minecraft:red_concrete
fill 413 178 646 413 179 646 minecraft:red_concrete
fill 414 178 646 415 183 646 minecraft:purple_terracotta
fill 415 178 604 415 183 604 minecraft:purple_terracotta
setblock 416 178 646 minecraft:red_concrete
fill 417 178 604 417 179 604 minecraft:red_concrete
fill 418 178 609 418 183 610 minecraft:purple_terracotta
fill 418 178 611 418 179 612 minecraft:red_concrete
setblock 418 178 620 minecraft:red_concrete
fill 418 178 621 418 183 622 minecraft:purple_terracotta
fill 418 178 623 418 179 624 minecraft:red_concrete
fill 418 178 629 418 183 630 minecraft:purple_terracotta
fill 418 178 631 418 178 632 minecraft:red_concrete
fill 418 178 633 418 183 633 minecraft:purple_terracotta
fill 418 178 641 418 183 642 minecraft:purple_terracotta
fill 418 178 643 418 179 644 minecraft:red_concrete
fill 418 178 646 418 183 646 minecraft:purple_terracotta
fill 376 179 618 376 179 619 minecraft:red_concrete
setblock 376 179 622 minecraft:red_concrete
fill 376 179 623 376 182 623 minecraft:purple_terracotta
fill 376 179 634 376 182 634 minecraft:purple_terracotta
setblock 376 179 639 minecraft:red_concrete
setblock 377 179 604 minecraft:red_concrete
fill 378 179 604 378 181 604 minecraft:purple_terracotta
setblock 380 179 646 minecraft:red_concrete
fill 382 179 604 382 182 604 minecraft:purple_terracotta
fill 384 179 646 385 182 646 minecraft:purple_terracotta
fill 393 179 604 393 182 604 minecraft:purple_terracotta
setblock 394 179 604 minecraft:red_concrete
fill 396 179 637 396 180 637 minecraft:red_concrete
fill 397 179 604 398 179 604 minecraft:red_concrete
setblock 401 179 646 minecraft:red_concrete
setblock 404 179 646 minecraft:red_concrete
fill 405 179 646 405 182 646 minecraft:purple_terracotta
setblock 412 179 646 minecraft:red_concrete
fill 413 179 604 414 181 604 minecraft:purple_terracotta
fill 416 179 646 416 182 646 minecraft:purple_terracotta
setblock 418 179 604 minecraft:red_concrete
setblock 418 179 615 minecraft:red_concrete
fill 418 179 620 418 182 620 minecraft:purple_terracotta
fill 418 179 631 418 182 631 minecraft:purple_terracotta
setblock 418 179 632 minecraft:red_concrete
fill 418 179 635 418 179 636 minecraft:red_concrete
fill 376 180 608 376 180 609 minecraft:red_concrete
fill 376 180 610 376 185 611 minecraft:purple_terracotta
fill 376 180 617 376 181 617 minecraft:red_concrete
fill 376 180 618 376 185 619 minecraft:purple_terracotta
setblock 376 180 620 minecraft:red_concrete
fill 376 180 622 376 185 622 minecraft:purple_terracotta
fill 376 180 628 376 181 629 minecraft:red_concrete
fill 376 180 630 376 185 631 minecraft:purple_terracotta
fill 376 180 639 376 185 639 minecraft:purple_terracotta
fill 376 180 640 376 180 641 minecraft:red_concrete
fill 376 180 642 376 185 643 minecraft:purple_terracotta
fill 377 180 604 377 185 604 minecraft:purple_terracotta
fill 377 180 605 379 180 605 minecraft:polished_blackstone
fill 377 180 607 377 180 609 minecraft:polished_blackstone
fill 377 180 611 377 180 613 minecraft:polished_blackstone
fill 377 180 615 377 180 617 minecraft:polished_blackstone
fill 377 180 619 377 180 621 minecraft:polished_blackstone
fill 377 180 623 377 180 625 minecraft:polished_blackstone
fill 377 180 627 377 180 629 minecraft:polished_blackstone
fill 377 180 631 377 180 633 minecraft:polished_blackstone
fill 377 180 635 377 180 637 minecraft:polished_blackstone
fill 377 180 639 377 180 641 minecraft:polished_blackstone
fill 377 180 643 377 180 645 minecraft:polished_blackstone
fill 378 180 646 379 181 646 minecraft:red_concrete
fill 379 180 645 381 180 645 minecraft:polished_blackstone
fill 380 180 646 381 185 646 minecraft:purple_terracotta
fill 381 180 605 383 180 605 minecraft:polished_blackstone
setblock 382 180 646 minecraft:red_concrete
fill 383 180 645 385 180 645 minecraft:polished_blackstone
fill 385 180 604 386 185 604 minecraft:purple_terracotta
fill 385 180 605 387 180 605 minecraft:polished_blackstone
fill 387 180 604 388 181 604 minecraft:red_concrete
fill 387 180 645 389 180 645 minecraft:polished_blackstone
fill 389 180 605 391 180 605 minecraft:polished_blackstone
fill 390 180 646 391 181 646 minecraft:red_concrete
fill 391 180 645 393 180 645 minecraft:polished_blackstone
fill 392 180 646 393 185 646 minecraft:purple_terracotta
fill 393 180 605 395 180 605 minecraft:polished_blackstone
fill 394 180 604 394 185 604 minecraft:purple_terracotta
fill 395 180 604 396 180 604 minecraft:red_concrete
fill 395 180 645 397 180 645 minecraft:polished_blackstone
fill 397 180 604 398 181 604 minecraft:purple_terracotta
fill 397 180 605 399 180 605 minecraft:polished_blackstone
fill 399 180 604 399 181 604 minecraft:red_concrete
fill 399 180 645 401 180 645 minecraft:polished_blackstone
fill 399 180 646 399 181 646 minecraft:red_concrete
fill 401 180 605 403 180 605 minecraft:polished_blackstone
fill 401 180 646 401 185 646 minecraft:purple_terracotta
fill 402 180 646 403 180 646 minecraft:red_concrete
fill 403 180 645 405 180 645 minecraft:polished_blackstone
fill 404 180 646 404 185 646 minecraft:purple_terracotta
fill 405 180 604 406 185 604 minecraft:purple_terracotta
fill 405 180 605 407 180 605 minecraft:polished_blackstone
fill 407 180 604 408 181 604 minecraft:red_concrete
fill 407 180 645 409 180 645 minecraft:polished_blackstone
fill 409 180 605 411 180 605 minecraft:polished_blackstone
fill 410 180 646 411 181 646 minecraft:red_concrete
fill 411 180 645 413 180 645 minecraft:polished_blackstone
fill 412 180 646 413 185 646 minecraft:purple_terracotta
fill 413 180 605 415 180 605 minecraft:polished_blackstone
fill 415 180 645 417 180 645 minecraft:polished_blackstone
setblock 416 180 604 minecraft:red_concrete
fill 417 180 604 418 185 604 minecraft:purple_terracotta
fill 417 180 605 417 180 607 minecraft:polished_blackstone
fill 417 180 609 417 180 611 minecraft:polished_blackstone
fill 417 180 613 417 180 615 minecraft:polished_blackstone
fill 417 180 617 417 180 619 minecraft:polished_blackstone
fill 417 180 621 417 180 623 minecraft:polished_blackstone
fill 417 180 625 417 180 627 minecraft:polished_blackstone
fill 417 180 629 417 180 631 minecraft:polished_blackstone
fill 417 180 633 417 180 635 minecraft:polished_blackstone
fill 417 180 637 417 180 639 minecraft:polished_blackstone
fill 417 180 641 417 180 643 minecraft:polished_blackstone
fill 418 180 605 418 181 606 minecraft:red_concrete
fill 418 180 611 418 185 612 minecraft:purple_terracotta
fill 418 180 613 418 180 614 minecraft:red_concrete
fill 418 180 615 418 185 615 minecraft:purple_terracotta
fill 418 180 623 418 185 624 minecraft:purple_terracotta
fill 418 180 625 418 181 626 minecraft:red_concrete
fill 418 180 632 418 185 632 minecraft:purple_terracotta
setblock 418 180 634 minecraft:red_concrete
fill 418 180 635 418 185 636 minecraft:purple_terracotta
fill 418 180 637 418 181 637 minecraft:red_concrete
fill 418 180 643 418 185 644 minecraft:purple_terracotta
setblock 418 180 645 minecraft:red_concrete
setblock 376 181 605 minecraft:red_concrete
setblock 376 181 608 minecraft:red_concrete
fill 376 181 609 376 184 609 minecraft:purple_terracotta
setblock 376 181 616 minecraft:red_concrete
fill 376 181 620 376 184 620 minecraft:purple_terracotta
fill 376 181 636 376 181 637 minecraft:red_concrete
setblock 376 181 640 minecraft:red_concrete
fill 376 181 641 376 184 641 minecraft:purple_terracotta
fill 379 181 604 380 181 604 minecraft:red_concrete
fill 382 181 646 382 184 646 minecraft:purple_terracotta
setblock 387 181 646 minecraft:red_concrete
fill 395 181 604 396 183 604 minecraft:purple_terracotta
setblock 398 181 646 minecraft:red_concrete
setblock 400 181 604 minecraft:red_concrete
fill 402 181 646 403 184 646 minecraft:purple_terracotta
setblock 411 181 604 minecraft:red_concrete
fill 416 181 604 416 183 604 minecraft:purple_terracotta
fill 418 181 613 418 184 613 minecraft:purple_terracotta
setblock 418 181 614 minecraft:red_concrete
fill 418 181 617 418 181 618 minecraft:red_concrete
fill 418 181 634 418 184 634 minecraft:purple_terracotta
setblock 418 181 638 minecraft:red_concrete
fill 418 181 645 418 184 645 minecraft:purple_terracotta
fill 376 182 605 376 187 605 minecraft:purple_terracotta
fill 376 182 606 376 182 607 minecraft:red_concrete
fill 376 182 608 376 187 608 minecraft:purple_terracotta
fill 376 182 614 376 183 615 minecraft:red_concrete
fill 376 182 616 376 187 617 minecraft:purple_terracotta
fill 376 182 626 376 182 627 minecraft:red_concrete
fill 376 182 628 376 187 629 minecraft:purple_terracotta
fill 376 182 635 376 183 635 minecraft:red_concrete
fill 376 182 636 376 187 637 minecraft:purple_terracotta
setblock 376 182 638 minecraft:red_concrete
fill 376 182 640 376 187 640 minecraft:purple_terracotta
fill 376 182 646 377 183 646 minecraft:red_concrete
setblock 378 182 604 minecraft:red_concrete
fill 378 182 646 379 187 646 minecraft:purple_terracotta
fill 379 182 604 380 187 604 minecraft:purple_terracotta
fill 381 182 604 381 183 604 minecraft:red_concrete
fill 387 182 604 388 187 604 minecraft:purple_terracotta
fill 387 182 646 387 187 646 minecraft:purple_terracotta
fill 388 182 646 389 182 646 minecraft:red_concrete
fill 389 182 604 390 183 604 minecraft:red_concrete
fill 390 182 646 391 187 646 minecraft:purple_terracotta
fill 396 182 646 397 183 646 minecraft:red_concrete
fill 397 182 604 397 185 604 minecraft:purple_terracotta
setblock 398 182 604 minecraft:red_concrete
fill 398 182 646 399 187 646 minecraft:purple_terracotta
fill 399 182 604 400 187 604 minecraft:purple_terracotta
setblock 400 182 646 minecraft:red_concrete
fill 401 182 604 402 183 604 minecraft:red_concrete
fill 407 182 604 408 184 604 minecraft:purple_terracotta
fill 408 182 646 409 183 646 minecraft:red_concrete
fill 409 182 604 410 182 604 minecraft:red_concrete
fill 410 182 646 411 187 646 minecraft:purple_terracotta
fill 411 182 604 411 187 604 minecraft:purple_terracotta
fill 413 182 604 413 183 604 minecraft:red_concrete
setblock 414 182 604 minecraft:purple_terracotta
fill 417 182 646 417 183 646 minecraft:red_concrete
fill 418 182 605 418 187 606 minecraft:purple_terracotta
fill 418 182 607 418 183 608 minecraft:red_concrete
fill 418 182 614 418 187 614 minecraft:purple_terracotta
setblock 418 182 616 minecraft:red_concrete
fill 418 182 617 418 187 618 minecraft:purple_terracotta
fill 418 182 619 418 183 619 minecraft:red_concrete
fill 418 182 625 418 187 626 minecraft:purple_terracotta
fill 418 182 627 418 182 628 minecraft:red_concrete
fill 418 182 637 418 187 638 minecraft:purple_terracotta
fill 418 182 639 418 183 640 minecraft:red_concrete
fill 376 183 606 376 186 607 minecraft:purple_terracotta
setblock 376 183 623 minecraft:red_concrete
setblock 376 183 626 minecraft:red_concrete
fill 376 183 627 376 186 627 minecraft:purple_terracotta
setblock 376 183 634 minecraft:red_concrete
fill 376 183 638 376 186 638 minecraft:purple_terracotta
fill 378 183 604 378 186 604 minecraft:purple_terracotta
setblock 382 183 604 minecraft:red_concrete
fill 384 183 646 385 183 646 minecraft:red_concrete
setblock 388 183 646 minecraft:red_concrete
fill 389 183 646 389 186 646 minecraft:purple_terracotta
setblock 393 183 604 minecraft:red_concrete
fill 398 183 604 398 185 604 minecraft:purple_terracotta
fill 400 183 646 400 186 646 minecraft:purple_terracotta
setblock 405 183 646 minecraft:red_concrete
fill 409 183 604 409 186 604 minecraft:purple_terracotta
setblock 410 183 604 minecraft:red_concrete
setblock 414 183 604 minecraft:red_concrete
setblock 416 183 646 minecraft:red_concrete
fill 418 183 616 418 186 616 minecraft:purple_terracotta
setblock 418 183 620 minecraft:red_concrete
fill 418 183 627 418 186 627 minecraft:purple_terracotta
setblock 418 183 628 minecraft:red_concrete
setblock 418 183 631 minecraft:red_concrete
setblock 376 184 604 minecraft:red_concrete
fill 376 184 612 376 185 613 minecraft:red_concrete
fill 376 184 614 376 189 615 minecraft:purple_terracotta
fill 376 184 621 376 185 621 minecraft:red_concrete
fill 376 184 623 376 189 623 minecraft:purple_terracotta
fill 376 184 624 376 184 625 minecraft:red_concrete
fill 376 184 626 376 189 626 minecraft:purple_terracotta
fill 376 184 632 376 185 633 minecraft:red_concrete
fill 376 184 634 376 189 635 minecraft:purple_terracotta
fill 376 184 644 376 184 645 minecraft:red_concrete
fill 376 184 646 377 189 646 minecraft:purple_terracotta
fill 381 184 604 382 189 604 minecraft:purple_terracotta
fill 383 184 604 384 185 604 minecraft:red_concrete
fill 383 184 646 383 185 646 minecraft:red_concrete
fill 384 184 646 385 189 646 minecraft:purple_terracotta
setblock 386 184 646 minecraft:red_concrete
fill 388 184 646 388 189 646 minecraft:purple_terracotta
fill 389 184 604 390 186 604 minecraft:purple_terracotta
fill 391 184 604 392 184 604 minecraft:red_concrete
fill 393 184 604 393 189 604 minecraft:purple_terracotta
fill 394 184 646 395 185 646 minecraft:red_concrete
fill 395 184 604 395 185 604 minecraft:red_concrete
setblock 396 184 604 minecraft:purple_terracotta
fill 396 184 646 397 189 646 minecraft:purple_terracotta
fill 397 184 634 398 185 635 minecraft:blackstone
fill 401 184 604 402 189 604 minecraft:purple_terracotta
fill 403 184 604 404 185 604 minecraft:red_concrete
fill 405 184 646 405 189 646 minecraft:purple_terracotta
fill 406 184 646 407 184 646 minecraft:red_concrete
fill 408 184 646 409 189 646 minecraft:purple_terracotta
fill 410 184 604 410 186 604 minecraft:purple_terracotta
setblock 412 184 604 minecraft:red_concrete
fill 413 184 604 414 189 604 minecraft:purple_terracotta
fill 414 184 646 415 185 646 minecraft:red_concrete
fill 415 184 604 416 185 604 minecraft:red_concrete
fill 416 184 646 417 189 646 minecraft:purple_terracotta
fill 418 184 607 418 189 608 minecraft:purple_terracotta
fill 418 184 609 418 184 610 minecraft:red_concrete
fill 418 184 619 418 189 620 minecraft:purple_terracotta
fill 418 184 621 418 185 622 minecraft:red_concrete
fill 418 184 628 418 189 628 minecraft:purple_terracotta
fill 418 184 629 418 184 630 minecraft:red_concrete
fill 418 184 631 418 189 631 minecraft:purple_terracotta
fill 418 184 633 418 185 633 minecraft:red_concrete
fill 418 184 639 418 189 640 minecraft:purple_terracotta
fill 418 184 641 418 185 642 minecraft:red_concrete
setblock 418 184 646 minecraft:red_concrete
fill 376 185 604 376 188 604 minecraft:purple_terracotta
setblock 376 185 609 minecraft:red_concrete
setblock 376 185 620 minecraft:red_concrete
fill 376 185 624 376 188 625 minecraft:purple_terracotta
setblock 376 185 641 minecraft:red_concrete
setblock 376 185 644 minecraft:red_concrete
fill 376 185 645 376 188 645 minecraft:purple_terracotta
setblock 382 185 646 minecraft:red_concrete
fill 386 185 646 386 188 646 minecraft:purple_terracotta
fill 391 185 604 391 188 604 minecraft:purple_terracotta
setblock 392 185 604 minecraft:red_concrete
setblock 396 185 604 minecraft:red_concrete
fill 402 185 646 403 185 646 minecraft:red_concrete
setblock 406 185 646 minecraft:red_concrete
setblock 407 185 604 minecraft:red_concrete
fill 407 185 646 407 188 646 minecraft:purple_terracotta
fill 408 185 604 408 187 604 minecraft:purple_terracotta
fill 412 185 604 412 188 604 minecraft:purple_terracotta
fill 418 185 609 418 188 609 minecraft:purple_terracotta
setblock 418 185 610 minecraft:red_concrete
setblock 418 185 613 minecraft:red_concrete
fill 418 185 629 418 188 630 minecraft:purple_terracotta
setblock 418 185 634 minecraft:red_concrete
setblock 418 185 645 minecraft:red_concrete
fill 418 185 646 418 188 646 minecraft:purple_terracotta
fill 376 186 609 376 191 609 minecraft:purple_terracotta
fill 376 186 610 376 186 611 minecraft:red_concrete
fill 376 186 612 376 191 613 minecraft:purple_terracotta
fill 376 186 618 376 187 619 minecraft:red_concrete
fill 376 186 620 376 191 621 minecraft:purple_terracotta
setblock 376 186 622 minecraft:red_concrete
fill 376 186 630 376 187 631 minecraft:red_concrete
fill 376 186 632 376 191 633 minecraft:purple_terracotta
fill 376 186 639 376 187 639 minecraft:red_concrete
fill 376 186 641 376 191 641 minecraft:purple_terracotta
fill 376 186 642 376 186 643 minecraft:red_concrete
fill 376 186 644 376 191 644 minecraft:purple_terracotta
fill 377 186 604 377 187 604 minecraft:red_concrete
fill 377 186 605 379 186 605 minecraft:polished_blackstone
fill 377 186 607 377 186 609 minecraft:polished_blackstone
fill 377 186 611 377 186 613 minecraft:polished_blackstone
fill 377 186 615 377 186 617 minecraft:polished_blackstone
fill 377 186 619 377 186 621 minecraft:polished_blackstone
fill 377 186 623 377 186 625 minecraft:polished_blackstone
fill 377 186 627 377 186 629 minecraft:polished_blackstone
fill 377 186 631 377 186 633 minecraft:polished_blackstone
fill 377 186 635 377 186 637 minecraft:polished_blackstone
fill 377 186 639 377 186 641 minecraft:polished_blackstone
fill 377 186 643 377 186 645 minecraft:polished_blackstone
setblock 379 186 607 minecraft:light[level=12]
setblock 379 186 615 minecraft:light[level=12]
setblock 379 186 623 minecraft:light[level=12]
setblock 379 186 631 minecraft:light[level=12]
setblock 379 186 639 minecraft:light[level=12]
fill 379 186 645 381 186 645 minecraft:polished_blackstone
fill 380 186 646 381 187 646 minecraft:red_concrete
fill 381 186 605 383 186 605 minecraft:polished_blackstone
fill 382 186 646 383 191 646 minecraft:purple_terracotta
fill 383 186 604 384 191 604 minecraft:purple_terracotta
fill 383 186 645 385 186 645 minecraft:polished_blackstone
fill 385 186 604 386 187 604 minecraft:red_concrete
fill 385 186 605 387 186 605 minecraft:polished_blackstone
setblock 387 186 607 minecraft:light[level=12]
setblock 387 186 615 minecraft:light[level=12]
setblock 387 186 623 minecraft:light[level=12]
setblock 387 186 631 minecraft:light[level=12]
setblock 387 186 639 minecraft:light[level=12]
fill 387 186 645 389 186 645 minecraft:polished_blackstone
fill 389 186 605 391 186 605 minecraft:polished_blackstone
fill 391 186 645 393 186 645 minecraft:polished_blackstone
fill 392 186 604 392 188 604 minecraft:purple_terracotta
fill 392 186 646 393 186 646 minecraft:red_concrete
fill 393 186 605 395 186 605 minecraft:polished_blackstone
setblock 394 186 604 minecraft:red_concrete
fill 394 186 646 395 191 646 minecraft:purple_terracotta
fill 395 186 604 396 191 604 minecraft:purple_terracotta
setblock 395 186 607 minecraft:light[level=12]
setblock 395 186 615 minecraft:light[level=12]
setblock 395 186 623 minecraft:light[level=12]
setblock 395 186 631 minecraft:light[level=12]
setblock 395 186 639 minecraft:light[level=12]
fill 395 186 645 397 186 645 minecraft:polished_blackstone
fill 397 186 604 398 187 604 minecraft:red_concrete
fill 397 186 605 399 186 605 minecraft:polished_blackstone
fill 399 186 645 401 186 645 minecraft:polished_blackstone
fill 401 186 605 403 186 605 minecraft:polished_blackstone
fill 401 186 646 401 187 646 minecraft:red_concrete
fill 402 186 646 403 191 646 minecraft:purple_terracotta
fill 403 186 604 404 191 604 minecraft:purple_terracotta
setblock 403 186 607 minecraft:light[level=12]
setblock 403 186 615 minecraft:light[level=12]
setblock 403 186 623 minecraft:light[level=12]
setblock 403 186 631 minecraft:light[level=12]
setblock 403 186 639 minecraft:light[level=12]
fill 403 186 645 405 186 645 minecraft:polished_blackstone
setblock 404 186 646 minecraft:red_concrete
fill 405 186 604 406 186 604 minecraft:red_concrete
fill 405 186 605 407 186 605 minecraft:polished_blackstone
fill 406 186 646 406 191 646 minecraft:purple_terracotta
fill 407 186 604 407 187 604 minecraft:purple_terracotta
fill 407 186 645 409 186 645 minecraft:polished_blackstone
fill 409 186 605 411 186 605 minecraft:polished_blackstone
setblock 411 186 607 minecraft:light[level=12]
setblock 411 186 615 minecraft:light[level=12]
setblock 411 186 623 minecraft:light[level=12]
setblock 411 186 631 minecraft:light[level=12]
setblock 411 186 639 minecraft:light[level=12]
fill 411 186 645 413 186 645 minecraft:polished_blackstone
fill 412 186 646 413 187 646 minecraft:red_concrete
fill 413 186 605 415 186 605 minecraft:polished_blackstone
fill 414 186 646 415 191 646 minecraft:purple_terracotta
fill 415 186 604 416 191 604 minecraft:purple_terracotta
fill 415 186 645 417 186 645 minecraft:polished_blackstone
fill 417 186 604 418 187 604 minecraft:red_concrete
fill 417 186 605 417 186 607 minecraft:polished_blackstone
fill 417 186 609 417 186 611 minecraft:polished_blackstone
fill 417 186 613 417 186 615 minecraft:polished_blackstone
fill 417 186 617 417 186 619 minecraft:polished_blackstone
fill 417 186 621 417 186 623 minecraft:polished_blackstone
fill 417 186 625 417 186 627 minecraft:polished_blackstone
fill 417 186 629 417 186 631 minecraft:polished_blackstone
fill 417 186 633 417 186 635 minecraft:polished_blackstone
fill 417 186 637 417 186 639 minecraft:polished_blackstone
fill 417 186 641 417 186 643 minecraft:polished_blackstone
fill 418 186 610 418 191 610 minecraft:purple_terracotta
fill 418 186 611 418 186 612 minecraft:red_concrete
fill 418 186 613 418 191 613 minecraft:purple_terracotta
fill 418 186 615 418 187 615 minecraft:red_concrete
fill 418 186 621 418 191 622 minecraft:purple_terracotta
fill 418 186 623 418 187 624 minecraft:red_concrete
setblock 418 186 632 minecraft:red_concrete
fill 418 186 633 418 191 634 minecraft:purple_terracotta
fill 418 186 635 418 187 636 minecraft:red_concrete
fill 418 186 641 418 191 642 minecraft:purple_terracotta
fill 418 186 643 418 186 644 minecraft:red_concrete
fill 418 186 645 418 191 645 minecraft:purple_terracotta
fill 376 187 606 376 187 607 minecraft:red_concrete
setblock 376 187 610 minecraft:red_concrete
fill 376 187 611 376 190 611 minecraft:purple_terracotta
fill 376 187 622 376 190 622 minecraft:purple_terracotta
setblock 376 187 627 minecraft:red_concrete
setblock 376 187 638 minecraft:red_concrete
fill 376 187 642 376 190 643 minecraft:purple_terracotta
setblock 378 187 604 minecraft:red_concrete
setblock 389 187 604 minecraft:red_concrete
setblock 389 187 646 minecraft:red_concrete
fill 390 187 604 390 189 604 minecraft:purple_terracotta
setblock 392 187 646 minecraft:red_concrete
fill 393 187 646 393 190 646 minecraft:purple_terracotta
fill 394 187 604 394 190 604 minecraft:purple_terracotta
setblock 400 187 646 minecraft:red_concrete
fill 404 187 646 404 190 646 minecraft:purple_terracotta
fill 405 187 604 405 190 604 minecraft:purple_terracotta
setblock 406 187 604 minecraft:red_concrete
fill 409 187 604 410 187 604 minecraft:red_concrete
fill 418 187 611 418 189 612 minecraft:purple_terracotta
setblock 418 187 616 minecraft:red_concrete
setblock 418 187 627 minecraft:red_concrete
fill 418 187 632 418 190 632 minecraft:purple_terracotta
fill 418 187 643 418 190 643 minecraft:purple_terracotta
setblock 418 187 644 minecraft:red_concrete
fill 376 188 605 376 189 605 minecraft:red_concrete
fill 376 188 606 376 193 607 minecraft:purple_terracotta
setblock 376 188 608 minecraft:red_concrete
fill 376 188 610 376 193 610 minecraft:purple_terracotta
fill 376 188 616 376 189 617 minecraft:red_concrete
fill 376 188 618 376 193 619 minecraft:purple_terracotta
fill 376 188 627 376 193 627 minecraft:purple_terracotta
fill 376 188 628 376 188 629 minecraft:red_concrete
fill 376 188 630 376 193 631 minecraft:purple_terracotta
fill 376 188 636 376 189 637 minecraft:red_concrete
fill 376 188 638 376 193 639 minecraft:purple_terracotta
setblock 376 188 640 minecraft:red_concrete
fill 377 188 604 378 193 604 minecraft:purple_terracotta
fill 378 188 646 379 189 646 minecraft:red_concrete
fill 379 188 604 380 189 604 minecraft:red_concrete
fill 380 188 646 381 193 646 minecraft:purple_terracotta
fill 385 188 604 386 193 604 minecraft:purple_terracotta
fill 387 188 604 388 188 604 minecraft:red_concrete
fill 387 188 646 387 189 646 minecraft:red_concrete
fill 389 188 604 389 193 604 minecraft:purple_terracotta
fill 389 188 646 389 193 646 minecraft:purple_terracotta
fill 390 188 646 391 188 646 minecraft:red_concrete
fill 392 188 646 392 193 646 minecraft:purple_terracotta
fill 397 188 604 398 193 604 minecraft:purple_terracotta
fill 398 188 646 399 189 646 minecraft:red_concrete
fill 399 188 604 400 189 604 minecraft:red_concrete
fill 400 188 646 401 193 646 minecraft:purple_terracotta
fill 406 188 604 406 193 604 minecraft:purple_terracotta
fill 407 188 604 408 188 604 minecraft:red_concrete
fill 409 188 604 410 189 604 minecraft:purple_terracotta
fill 410 188 646 411 188 646 minecraft:red_concrete
fill 411 188 604 411 189 604 minecraft:red_concrete
fill 412 188 646 413 193 646 minecraft:purple_terracotta
fill 417 188 604 418 193 604 minecraft:purple_terracotta
fill 418 188 605 418 189 606 minecraft:red_concrete
setblock 418 188 614 minecraft:red_concrete
fill 418 188 615 418 193 616 minecraft:purple_terracotta
fill 418 188 617 418 189 618 minecraft:red_concrete
fill 418 188 623 418 193 624 minecraft:purple_terracotta
fill 418 188 625 418 188 626 minecraft:red_concrete
fill 418 188 627 418 193 627 minecraft:purple_terracotta
fill 418 188 635 418 193 636 minecraft:purple_terracotta
fill 418 188 637 418 189 638 minecraft:red_concrete
fill 418 188 644 418 193 644 minecraft:purple_terracotta
setblock 376 189 604 minecraft:red_concrete
fill 376 189 608 376 192 608 minecraft:purple_terracotta
fill 376 189 624 376 189 625 minecraft:red_concrete
setblock 376 189 628 minecraft:red_concrete
fill 376 189 629 376 192 629 minecraft:purple_terracotta
fill 376 189 640 376 192 640 minecraft:purple_terracotta
setblock 376 189 645 minecraft:red_concrete
setblock 386 189 646 minecraft:red_concrete
fill 387 189 604 387 192 604 minecraft:purple_terracotta
setblock 388 189 604 minecraft:red_concrete
fill 390 189 646 391 192 646 minecraft:purple_terracotta
fill 391 189 604 392 189 604 minecraft:red_concrete
fill 403 189 609 403 190 610 minecraft:red_concrete
fill 407 189 604 408 191 604 minecraft:purple_terracotta
setblock 407 189 646 minecraft:red_concrete
setblock 410 189 646 minecraft:red_concrete
fill 411 189 646 411 192 646 minecraft:purple_terracotta
setblock 412 189 604 minecraft:red_concrete
setblock 418 189 609 minecraft:red_concrete
fill 418 189 614 418 191 614 minecraft:purple_terracotta
fill 418 189 625 418 192 625 minecraft:purple_terracotta
setblock 418 189 626 minecraft:red_concrete
fill 418 189 629 418 189 630 minecraft:red_concrete
setblock 418 189 646 minecraft:red_concrete
fill 376 190 604 376 195 605 minecraft:purple_terracotta
fill 376 190 614 376 190 615 minecraft:red_concrete
fill 376 190 616 376 195 617 minecraft:purple_terracotta
fill 376 190 623 376 191 623 minecraft:red_concrete
fill 376 190 624 376 195 625 minecraft:purple_terracotta
setblock 376 190 626 minecraft:red_concrete
fill 376 190 628 376 195 628 minecraft:purple_terracotta
fill 376 190 634 376 191 635 minecraft:red_concrete
fill 376 190 636 376 195 637 minecraft:purple_terracotta
fill 376 190 645 376 195 645 minecraft:purple_terracotta
fill 376 190 646 377 190 646 minecraft:red_concrete
fill 378 190 646 379 195 646 minecraft:purple_terracotta
fill 379 190 604 380 195 604 minecraft:purple_terracotta
fill 381 190 604 382 191 604 minecraft:red_concrete
fill 384 190 646 385 191 646 minecraft:red_concrete
fill 386 190 646 387 195 646 minecraft:purple_terracotta
fill 388 190 604 388 195 604 minecraft:purple_terracotta
setblock 388 190 646 minecraft:red_concrete
setblock 390 190 604 minecraft:red_concrete
fill 391 190 604 392 195 604 minecraft:purple_terracotta
fill 393 190 604 393 191 604 minecraft:red_concrete
fill 396 190 646 397 191 646 minecraft:red_concrete
fill 398 190 646 399 195 646 minecraft:purple_terracotta
fill 399 190 604 400 195 604 minecraft:purple_terracotta
fill 401 190 604 402 191 604 minecraft:red_concrete
fill 405 190 629 405 191 630 minecraft:magma_block
fill 405 190 646 405 191 646 minecraft:red_concrete
fill 407 190 646 407 195 646 minecraft:purple_terracotta
fill 408 190 646 409 190 646 minecraft:red_concrete
fill 409 190 604 409 193 604 minecraft:purple_terracotta
setblock 410 190 604 minecraft:red_concrete
fill 410 190 646 410 195 646 minecraft:purple_terracotta
fill 411 190 604 412 195 604 minecraft:purple_terracotta
fill 413 190 604 414 191 604 minecraft:red_concrete
fill 416 190 646 417 191 646 minecraft:red_concrete
fill 418 190 605 418 192 606 minecraft:purple_terracotta
fill 418 190 607 418 190 608 minecraft:red_concrete
fill 418 190 609 418 195 609 minecraft:purple_terracotta
fill 418 190 611 418 191 611 minecraft:red_concrete
setblock 418 190 612 minecraft:purple_terracotta
fill 418 190 617 418 195 618 minecraft:purple_terracotta
fill 418 190 619 418 191 620 minecraft:red_concrete
fill 418 190 626 418 195 626 minecraft:purple_terracotta
setblock 418 190 628 minecraft:red_concrete
fill 418 190 629 418 195 630 minecraft:purple_terracotta
fill 418 190 631 418 191 631 minecraft:red_concrete
fill 418 190 637 418 195 638 minecraft:purple_terracotta
fill 418 190 639 418 190 640 minecraft:red_concrete
fill 418 190 646 418 195 646 minecraft:purple_terracotta
setblock 376 191 611 minecraft:red_concrete
setblock 376 191 614 minecraft:red_concrete
fill 376 191 615 376 194 615 minecraft:purple_terracotta
setblock 376 191 622 minecraft:red_concrete
fill 376 191 626 376 194 626 minecraft:purple_terracotta
fill 376 191 642 376 191 643 minecraft:red_concrete
setblock 376 191 646 minecraft:red_concrete
fill 377 191 646 377 194 646 minecraft:purple_terracotta
fill 388 191 646 388 194 646 minecraft:purple_terracotta
fill 390 191 604 390 194 604 minecraft:purple_terracotta
setblock 393 191 646 minecraft:red_concrete
setblock 394 191 604 minecraft:red_concrete
setblock 404 191 646 minecraft:red_concrete
setblock 405 191 604 minecraft:red_concrete
fill 408 191 646 409 194 646 minecraft:purple_terracotta
fill 410 191 604 410 193 604 minecraft:purple_terracotta
fill 418 191 607 418 194 607 minecraft:purple_terracotta
setblock 418 191 608 minecraft:red_concrete
setblock 418 191 612 minecraft:red_concrete
fill 418 191 628 418 194 628 minecraft:purple_terracotta
setblock 418 191 632 minecraft:red_concrete
fill 418 191 639 418 194 639 minecraft:purple_terracotta
setblock 418 191 640 minecraft:red_concrete
setblock 418 191 643 minecraft:red_concrete
fill 376 192 609 376 193 609 minecraft:red_concrete
fill 376 192 611 376 197 611 minecraft:purple_terracotta
fill 376 192 612 376 192 613 minecraft:red_concrete
fill 376 192 614 376 197 614 minecraft:purple_terracotta
fill 376 192 620 376 193 621 minecraft:red_concrete
fill 376 192 622 376 197 623 minecraft:purple_terracotta
fill 376 192 632 376 192 633 minecraft:red_concrete
fill 376 192 634 376 197 635 minecraft:purple_terracotta
fill 376 192 641 376 193 641 minecraft:red_concrete
fill 376 192 642 376 197 643 minecraft:purple_terracotta
setblock 376 192 644 minecraft:red_concrete
fill 376 192 646 376 197 646 minecraft:purple_terracotta
fill 377 192 605 379 192 605 minecraft:polished_blackstone
fill 377 192 607 377 192 609 minecraft:polished_blackstone
fill 377 192 611 377 192 613 minecraft:polished_blackstone
fill 377 192 615 377 192 617 minecraft:polished_blackstone
fill 377 192 619 377 192 621 minecraft:polished_blackstone
fill 377 192 623 377 192 625 minecraft:polished_blackstone
fill 377 192 627 377 192 629 minecraft:polished_blackstone
fill 377 192 631 377 192 633 minecraft:polished_blackstone
fill 377 192 635 377 192 637 minecraft:polished_blackstone
fill 377 192 639 377 192 641 minecraft:polished_blackstone
fill 377 192 643 377 192 645 minecraft:polished_blackstone
fill 379 192 645 381 192 645 minecraft:polished_blackstone
fill 381 192 604 382 197 604 minecraft:purple_terracotta
fill 381 192 605 383 192 605 minecraft:polished_blackstone
fill 382 192 646 383 193 646 minecraft:red_concrete
fill 383 192 604 384 192 604 minecraft:red_concrete
fill 383 192 645 385 192 645 minecraft:polished_blackstone
fill 384 192 646 385 197 646 minecraft:purple_terracotta
fill 385 192 605 387 192 605 minecraft:polished_blackstone
fill 387 192 645 389 192 645 minecraft:polished_blackstone
fill 389 192 605 391 192 605 minecraft:polished_blackstone
fill 391 192 645 393 192 645 minecraft:polished_blackstone
fill 393 192 604 394 197 604 minecraft:purple_terracotta
fill 393 192 605 395 192 605 minecraft:polished_blackstone
fill 393 192 643 395 193 643 minecraft:red_concrete
fill 393 192 646 393 197 646 minecraft:purple_terracotta
fill 394 192 642 394 193 642 minecraft:red_concrete
fill 394 192 646 395 192 646 minecraft:red_concrete
fill 395 192 604 396 193 604 minecraft:red_concrete
fill 395 192 645 397 192 645 minecraft:polished_blackstone
fill 396 192 646 397 197 646 minecraft:purple_terracotta
fill 397 192 605 399 192 605 minecraft:polished_blackstone
fill 399 192 645 401 192 645 minecraft:polished_blackstone
fill 401 192 604 402 194 604 minecraft:purple_terracotta
fill 401 192 605 403 192 605 minecraft:polished_blackstone
fill 402 192 646 403 193 646 minecraft:red_concrete
fill 403 192 604 404 192 604 minecraft:red_concrete
fill 403 192 645 405 192 645 minecraft:polished_blackstone
fill 404 192 646 405 197 646 minecraft:purple_terracotta
fill 405 192 604 405 197 604 minecraft:purple_terracotta
fill 405 192 605 407 192 605 minecraft:polished_blackstone
fill 406 192 635 406 193 635 minecraft:crying_obsidian
setblock 406 192 646 minecraft:red_concrete
fill 407 192 604 407 193 604 minecraft:red_concrete
fill 407 192 645 409 192 645 minecraft:polished_blackstone
setblock 408 192 604 minecraft:purple_terracotta
fill 409 192 605 411 192 605 minecraft:polished_blackstone
fill 411 192 645 413 192 645 minecraft:polished_blackstone
fill 413 192 604 414 197 604 minecraft:purple_terracotta
fill 413 192 605 415 192 605 minecraft:polished_blackstone
fill 414 192 646 415 193 646 minecraft:red_concrete
fill 415 192 604 416 193 604 minecraft:red_concrete
fill 415 192 645 417 192 645 minecraft:polished_blackstone
fill 416 192 646 417 197 646 minecraft:purple_terracotta
fill 417 192 605 417 192 607 minecraft:polished_blackstone
fill 417 192 609 417 192 611 minecraft:polished_blackstone
fill 417 192 613 417 192 615 minecraft:polished_blackstone
fill 417 192 617 417 192 619 minecraft:polished_blackstone
fill 417 192 621 417 192 623 minecraft:polished_blackstone
fill 417 192 625 417 192 627 minecraft:polished_blackstone
fill 417 192 629 417 192 631 minecraft:polished_blackstone
fill 417 192 633 417 192 635 minecraft:polished_blackstone
fill 417 192 637 417 192 639 minecraft:polished_blackstone
fill 417 192 641 417 192 643 minecraft:polished_blackstone
fill 418 192 608 418 194 608 minecraft:purple_terracotta
setblock 418 192 610 minecraft:red_concrete
fill 418 192 611 418 197 612 minecraft:purple_terracotta
fill 418 192 613 418 193 614 minecraft:red_concrete
fill 418 192 619 418 197 620 minecraft:purple_terracotta
fill 418 192 621 418 192 622 minecraft:red_concrete
fill 418 192 631 418 197 632 minecraft:purple_terracotta
fill 418 192 633 418 193 634 minecraft:red_concrete
fill 418 192 640 418 197 640 minecraft:purple_terracotta
fill 418 192 641 418 192 642 minecraft:red_concrete
fill 418 192 643 418 197 643 minecraft:purple_terracotta
fill 418 192 645 418 193 645 minecraft:red_concrete
setblock 376 193 608 minecraft:red_concrete
fill 376 193 612 376 196 613 minecraft:purple_terracotta
setblock 376 193 629 minecraft:red_concrete
setblock 376 193 632 minecraft:red_concrete
fill 376 193 633 376 196 633 minecraft:purple_terracotta
setblock 376 193 640 minecraft:red_concrete
fill 376 193 644 376 196 644 minecraft:purple_terracotta
fill 383 193 604 383 196 604 minecraft:purple_terracotta
setblock 384 193 604 minecraft:red_concrete
setblock 387 193 604 minecraft:red_concrete
fill 390 193 646 391 193 646 minecraft:red_concrete
setblock 394 193 646 minecraft:red_concrete
fill 395 193 646 395 196 646 minecraft:purple_terracotta
fill 403 193 604 403 196 604 minecraft:purple_terracotta
setblock 404 193 604 minecraft:red_concrete
fill 406 193 634 408 193 634 minecraft:crying_obsidian
fill 406 193 646 406 196 646 minecraft:purple_terracotta
setblock 407 193 635 minecraft:crying_obsidian
setblock 408 193 604 minecraft:red_concrete
setblock 411 193 646 minecraft:red_concrete
setblock 418 193 605 minecraft:red_concrete
fill 418 193 606 418 195 606 minecraft:purple_terracotta
fill 418 193 610 418 196 610 minecraft:purple_terracotta
fill 418 193 621 418 196 621 minecraft:purple_terracotta
setblock 418 193 622 minecraft:red_concrete
setblock 418 193 625 minecraft:red_concrete
fill 418 193 641 418 196 642 minecraft:purple_terracotta
fill 376 194 606 376 195 607 minecraft:red_concrete
fill 376 194 608 376 203 609 minecraft:purple_terracotta
setblock 376 194 610 minecraft:red_concrete
fill 376 194 618 376 195 619 minecraft:red_concrete
fill 376 194 620 376 204 621 minecraft:purple_terracotta
fill 376 194 627 376 195 627 minecraft:red_concrete
fill 376 194 629 376 205 629 minecraft:purple_terracotta
fill 376 194 630 376 194 631 minecraft:red_concrete
fill 376 194 632 376 207 632 minecraft:purple_terracotta
fill 376 194 638 376 195 639 minecraft:red_concrete
fill 376 194 640 376 203 641 minecraft:purple_terracotta
fill 377 194 604 378 195 604 minecraft:red_concrete
setblock 379 194 607 minecraft:light[level=12]
setblock 379 194 615 minecraft:light[level=12]
setblock 379 194 623 minecraft:light[level=12]
setblock 379 194 631 minecraft:light[level=12]
setblock 379 194 639 minecraft:light[level=12]
fill 380 194 646 381 194 646 minecraft:red_concrete
fill 382 194 646 383 207 646 minecraft:purple_terracotta
fill 384 194 604 384 207 604 minecraft:purple_terracotta
fill 385 194 604 386 194 604 minecraft:red_concrete
fill 387 194 604 387 207 604 minecraft:purple_terracotta
setblock 387 194 607 minecraft:light[level=12]
setblock 387 194 615 minecraft:light[level=12]
setblock 387 194 623 minecraft:light[level=12]
setblock 387 194 631 minecraft:light[level=12]
setblock 387 194 639 minecraft:light[level=12]
fill 389 194 604 389 195 604 minecraft:red_concrete
fill 389 194 646 389 195 646 minecraft:red_concrete
fill 390 194 611 392 195 611 minecraft:blackstone
fill 390 194 646 391 207 646 minecraft:purple_terracotta
fill 391 194 612 392 195 612 minecraft:blackstone
setblock 392 194 646 minecraft:red_concrete
fill 394 194 646 394 207 646 minecraft:purple_terracotta
fill 395 194 604 396 204 604 minecraft:purple_terracotta
setblock 395 194 607 minecraft:light[level=12]
setblock 395 194 615 minecraft:light[level=12]
setblock 395 194 623 minecraft:light[level=12]
setblock 395 194 631 minecraft:light[level=12]
setblock 395 194 639 minecraft:light[level=12]
fill 397 194 604 398 195 604 minecraft:red_concrete
fill 400 194 646 401 195 646 minecraft:red_concrete
fill 402 194 646 403 207 646 minecraft:purple_terracotta
setblock 403 194 607 minecraft:light[level=12]
setblock 403 194 615 minecraft:light[level=12]
setblock 403 194 623 minecraft:light[level=12]
setblock 403 194 631 minecraft:light[level=12]
setblock 403 194 639 minecraft:light[level=12]
fill 404 194 604 404 196 604 minecraft:purple_terracotta
setblock 406 194 604 minecraft:red_concrete
fill 407 194 604 408 203 604 minecraft:purple_terracotta
fill 407 194 634 409 194 634 minecraft:crying_obsidian
fill 409 194 604 410 195 604 minecraft:red_concrete
setblock 411 194 607 minecraft:light[level=12]
setblock 411 194 615 minecraft:light[level=12]
setblock 411 194 623 minecraft:light[level=12]
setblock 411 194 631 minecraft:light[level=12]
setblock 411 194 639 minecraft:light[level=12]
fill 411 194 646 411 205 646 minecraft:purple_terracotta
fill 412 194 646 413 194 646 minecraft:red_concrete
fill 414 194 622 416 195 622 minecraft:red_concrete
fill 414 194 646 415 203 646 minecraft:purple_terracotta
fill 415 194 604 416 203 604 minecraft:purple_terracotta
fill 415 194 621 415 195 621 minecraft:red_concrete
fill 415 194 623 415 195 623 minecraft:red_concrete
fill 417 194 604 418 194 604 minecraft:red_concrete
fill 418 194 605 418 195 605 minecraft:purple_terracotta
fill 418 194 613 418 207 614 minecraft:purple_terracotta
fill 418 194 615 418 195 616 minecraft:red_concrete
fill 418 194 622 418 207 622 minecraft:purple_terracotta
fill 418 194 623 418 194 624 minecraft:red_concrete
fill 418 194 625 418 207 625 minecraft:purple_terracotta
fill 418 194 627 418 195 627 minecraft:red_concrete
fill 418 194 633 418 207 634 minecraft:purple_terracotta
fill 418 194 635 418 195 636 minecraft:red_concrete
setblock 418 194 644 minecraft:red_concrete
fill 418 194 645 418 204 645 minecraft:purple_terracotta
fill 376 195 610 376 198 610 minecraft:purple_terracotta
setblock 376 195 615 minecraft:red_concrete
setblock 376 195 626 minecraft:red_concrete
fill 376 195 630 376 198 631 minecraft:purple_terracotta
setblock 377 195 646 minecraft:red_concrete
setblock 380 195 646 minecraft:red_concrete
fill 381 195 646 381 198 646 minecraft:purple_terracotta
fill 385 195 604 386 198 604 minecraft:purple_terracotta
setblock 388 195 646 minecraft:red_concrete
setblock 390 195 604 minecraft:red_concrete
fill 392 195 646 392 198 646 minecraft:purple_terracotta
setblock 401 195 604 minecraft:red_concrete
fill 402 195 604 402 197 604 minecraft:purple_terracotta
fill 406 195 604 406 198 604 minecraft:purple_terracotta
fill 408 195 646 409 195 646 minecraft:red_concrete
fill 409 195 634 411 195 634 minecraft:crying_obsidian
setblock 410 195 633 minecraft:crying_obsidian
setblock 412 195 646 minecraft:red_concrete
fill 413 195 646 413 198 646 minecraft:purple_terracotta
fill 417 195 604 417 198 604 minecraft:purple_terracotta
setblock 418 195 604 minecraft:red_concrete
fill 418 195 607 418 195 608 minecraft:red_concrete
fill 418 195 623 418 197 624 minecraft:purple_terracotta
setblock 418 195 628 minecraft:red_concrete
setblock 418 195 639 minecraft:red_concrete
fill 418 195 644 418 198 644 minecraft:purple_terracotta
fill 376 196 604 376 197 605 minecraft:red_concrete
fill 376 196 606 376 207 607 minecraft:purple_terracotta
fill 376 196 615 376 207 615 minecraft:purple_terracotta
fill 376 196 616 376 196 617 minecraft:red_concrete
fill 376 196 618 376 205 619 minecraft:purple_terracotta
fill 376 196 624 376 197 625 minecraft:red_concrete
fill 376 196 626 376 207 627 minecraft:purple_terracotta
setblock 376 196 628 minecraft:red_concrete
fill 376 196 636 376 197 637 minecraft:red_concrete
fill 376 196 638 376 205 639 minecraft:purple_terracotta
fill 376 196 645 376 197 645 minecraft:red_concrete
fill 377 196 604 378 207 604 minecraft:purple_terracotta
fill 377 196 646 377 209 646 minecraft:purple_terracotta
fill 378 196 646 379 196 646 minecraft:red_concrete
fill 379 196 604 380 197 604 minecraft:red_concrete
fill 380 196 646 380 203 646 minecraft:purple_terracotta
fill 386 196 646 387 197 646 minecraft:red_concrete
setblock 388 196 604 minecraft:red_concrete
fill 388 196 646 389 204 646 minecraft:purple_terracotta
fill 389 196 604 390 204 604 minecraft:purple_terracotta
fill 391 196 604 392 197 604 minecraft:red_concrete
fill 391 196 638 392 196 638 minecraft:red_concrete
fill 392 196 636 392 196 637 minecraft:red_concrete
fill 392 196 639 392 196 640 minecraft:red_concrete
fill 393 196 636 395 196 636 minecraft:red_concrete
fill 393 196 640 395 196 640 minecraft:red_concrete
fill 395 196 637 396 196 637 minecraft:red_concrete
fill 395 196 639 396 196 639 minecraft:red_concrete
setblock 396 196 638 minecraft:red_concrete
fill 397 196 604 398 204 604 minecraft:purple_terracotta
fill 398 196 646 399 196 646 minecraft:red_concrete
fill 399 196 604 400 196 604 minecraft:red_concrete
fill 400 196 646 401 207 646 minecraft:purple_terracotta
fill 401 196 604 401 204 604 minecraft:purple_terracotta
fill 407 196 646 407 197 646 minecraft:red_concrete
fill 408 196 646 409 203 646 minecraft:purple_terracotta
fill 409 196 604 410 207 604 minecraft:purple_terracotta
setblock 410 196 646 minecraft:red_concrete
fill 411 196 604 412 197 604 minecraft:red_concrete
fill 411 196 633 412 196 634 minecraft:crying_obsidian
fill 412 196 640 412 196 643 minecraft:red_concrete
fill 412 196 646 412 207 646 minecraft:purple_terracotta
fill 413 196 633 413 197 633 minecraft:crying_obsidian
fill 413 196 640 415 197 640 minecraft:red_concrete
fill 413 196 643 415 197 643 minecraft:red_concrete
setblock 414 196 644 minecraft:red_concrete
fill 415 196 641 416 196 642 minecraft:red_concrete
fill 418 196 604 418 207 604 minecraft:purple_terracotta
fill 418 196 605 418 196 606 minecraft:red_concrete
fill 418 196 607 418 197 608 minecraft:purple_terracotta
fill 418 196 609 418 197 609 minecraft:red_concrete
fill 418 196 615 418 205 616 minecraft:purple_terracotta
fill 418 196 617 418 197 618 minecraft:red_concrete
setblock 418 196 626 minecraft:red_concrete
fill 418 196 627 418 207 628 minecraft:purple_terracotta
fill 418 196 629 418 197 630 minecraft:red_concrete
fill 418 196 635 418 203 636 minecraft:purple_terracotta
fill 418 196 637 418 196 638 minecraft:red_concrete
fill 418 196 639 418 207 639 minecraft:purple_terracotta
fill 418 196 646 418 197 646 minecraft:red_concrete
fill 376 197 612 376 197 613 minecraft:red_concrete
setblock 376 197 616 minecraft:red_concrete
fill 376 197 617 376 207 617 minecraft:purple_terracotta
fill 376 197 628 376 203 628 minecraft:purple_terracotta
setblock 376 197 633 minecraft:red_concrete
setblock 376 197 644 minecraft:red_concrete
fill 378 197 646 379 203 646 minecraft:purple_terracotta
setblock 383 197 604 minecraft:red_concrete
fill 388 197 604 388 207 604 minecraft:purple_terracotta
fill 392 197 637 392 197 639 minecraft:red_concrete
fill 393 197 636 394 197 636 minecraft:red_concrete
fill 393 197 640 394 197 640 minecraft:red_concrete
fill 395 197 637 395 198 637 minecraft:red_concrete
fill 395 197 639 395 198 639 minecraft:red_concrete
setblock 395 197 646 minecraft:red_concrete
setblock 398 197 646 minecraft:red_concrete
fill 399 197 604 399 204 604 minecraft:purple_terracotta
fill 399 197 646 399 204 646 minecraft:purple_terracotta
setblock 400 197 604 minecraft:red_concrete
fill 403 197 604 404 197 604 minecraft:red_concrete
setblock 406 197 646 minecraft:red_concrete
fill 410 197 646 410 207 646 minecraft:purple_terracotta
setblock 412 197 633 minecraft:crying_obsidian
fill 412 197 641 412 197 642 minecraft:red_concrete
fill 414 197 633 414 198 633 minecraft:crying_obsidian
fill 415 197 641 415 198 642 minecraft:red_concrete
fill 418 197 605 418 207 606 minecraft:purple_terracotta
setblock 418 197 610 minecraft:red_concrete
setblock 418 197 621 minecraft:red_concrete
fill 418 197 626 418 207 626 minecraft:purple_terracotta
fill 418 197 637 418 207 637 minecraft:purple_terracotta
setblock 418 197 638 minecraft:red_concrete
fill 418 197 641 418 197 642 minecraft:red_concrete
fill 376 198 604 376 207 605 minecraft:purple_terracotta
fill 376 198 611 376 199 611 minecraft:red_concrete
fill 376 198 612 376 205 613 minecraft:purple_terracotta
setblock 376 198 614 minecraft:red_concrete
fill 376 198 616 376 205 616 minecraft:purple_terracotta
fill 376 198 622 376 199 623 minecraft:red_concrete
fill 376 198 624 376 204 625 minecraft:purple_terracotta
fill 376 198 633 376 207 633 minecraft:purple_terracotta
fill 376 198 634 376 198 635 minecraft:red_concrete
fill 376 198 636 376 207 637 minecraft:purple_terracotta
fill 376 198 642 376 199 643 minecraft:red_concrete
fill 376 198 644 376 204 645 minecraft:purple_terracotta
setblock 376 198 646 minecraft:red_concrete
fill 377 198 605 379 198 605 minecraft:polished_blackstone
fill 377 198 607 377 198 609 minecraft:polished_blackstone
fill 377 198 611 377 198 613 minecraft:polished_blackstone
fill 377 198 615 377 198 617 minecraft:polished_blackstone
fill 377 198 619 377 198 621 minecraft:polished_blackstone
fill 377 198 623 377 198 625 minecraft:polished_blackstone
fill 377 198 627 377 198 629 minecraft:polished_blackstone
fill 377 198 631 377 198 633 minecraft:polished_blackstone
fill 377 198 635 377 198 637 minecraft:polished_blackstone
fill 377 198 639 377 198 641 minecraft:polished_blackstone
fill 377 198 643 377 198 645 minecraft:polished_blackstone
fill 379 198 604 380 204 604 minecraft:purple_terracotta
fill 379 198 645 381 198 645 minecraft:polished_blackstone
fill 381 198 604 382 198 604 minecraft:red_concrete
fill 381 198 605 383 198 605 minecraft:polished_blackstone
fill 383 198 604 383 207 604 minecraft:purple_terracotta
fill 383 198 645 385 198 645 minecraft:polished_blackstone
fill 384 198 613 384 199 613 minecraft:blackstone
fill 384 198 646 385 199 646 minecraft:red_concrete
fill 385 198 605 387 198 605 minecraft:polished_blackstone
fill 386 198 646 387 207 646 minecraft:purple_terracotta
fill 387 198 645 389 198 645 minecraft:polished_blackstone
fill 389 198 605 391 198 605 minecraft:polished_blackstone
fill 391 198 604 392 204 604 minecraft:purple_terracotta
fill 391 198 645 393 198 645 minecraft:polished_blackstone
fill 392 198 638 392 198 639 minecraft:red_concrete
fill 393 198 604 394 199 604 minecraft:red_concrete
fill 393 198 605 395 198 605 minecraft:polished_blackstone
fill 393 198 646 393 199 646 minecraft:red_concrete
fill 395 198 645 397 198 645 minecraft:polished_blackstone
fill 395 198 646 395 207 646 minecraft:purple_terracotta
fill 396 198 646 397 198 646 minecraft:red_concrete
fill 397 198 605 399 198 605 minecraft:polished_blackstone
fill 398 198 646 398 207 646 minecraft:purple_terracotta
fill 399 198 645 401 198 645 minecraft:polished_blackstone
fill 400 198 604 400 204 604 minecraft:purple_terracotta
fill 401 198 605 403 198 605 minecraft:polished_blackstone
setblock 402 198 604 minecraft:red_concrete
fill 403 198 604 404 203 604 minecraft:purple_terracotta
fill 403 198 645 405 198 645 minecraft:polished_blackstone
fill 404 198 646 405 199 646 minecraft:red_concrete
fill 405 198 604 405 199 604 minecraft:red_concrete
fill 405 198 605 407 198 605 minecraft:polished_blackstone
fill 406 198 646 407 205 646 minecraft:purple_terracotta
fill 407 198 645 409 198 645 minecraft:polished_blackstone
fill 409 198 605 411 198 605 minecraft:polished_blackstone
fill 411 198 604 412 207 604 minecraft:purple_terracotta
fill 411 198 645 413 198 645 minecraft:polished_blackstone
fill 413 198 604 414 199 604 minecraft:red_concrete
fill 413 198 605 415 198 605 minecraft:polished_blackstone
fill 413 198 640 414 198 640 minecraft:red_concrete
fill 413 198 643 414 198 643 minecraft:red_concrete
fill 415 198 645 417 198 645 minecraft:polished_blackstone
fill 416 198 646 417 198 646 minecraft:red_concrete
fill 417 198 605 417 198 607 minecraft:polished_blackstone
fill 417 198 609 417 198 611 minecraft:polished_blackstone
fill 417 198 613 417 198 615 minecraft:polished_blackstone
fill 417 198 617 417 198 619 minecraft:polished_blackstone
fill 417 198 621 417 198 623 minecraft:polished_blackstone
fill 417 198 625 417 198 627 minecraft:polished_blackstone
fill 417 198 629 417 198 631 minecraft:polished_blackstone
fill 417 198 633 417 198 635 minecraft:polished_blackstone
fill 417 198 637 417 198 639 minecraft:polished_blackstone
fill 417 198 641 417 198 643 minecraft:polished_blackstone
fill 418 198 607 418 203 607 minecraft:purple_terracotta
setblock 418 198 608 minecraft:red_concrete
fill 418 198 609 418 207 610 minecraft:purple_terracotta
fill 418 198 611 418 199 612 minecraft:red_concrete
fill 418 198 617 418 203 618 minecraft:purple_terracotta
fill 418 198 619 418 198 620 minecraft:red_concrete
fill 418 198 621 418 207 621 minecraft:purple_terracotta
fill 418 198 623 418 199 623 minecraft:red_concrete
setblock 418 198 624 minecraft:purple_terracotta
fill 418 198 629 418 207 630 minecraft:purple_terracotta
fill 418 198 631 418 199 632 minecraft:red_concrete
fill 418 198 638 418 207 638 minecraft:purple_terracotta
setblock 418 198 640 minecraft:red_concrete
fill 418 198 641 418 207 642 minecraft:purple_terracotta
fill 418 198 643 418 199 643 minecraft:red_concrete
fill 418 198 646 418 204 646 minecraft:purple_terracotta
setblock 376 199 610 minecraft:red_concrete
fill 376 199 614 376 207 614 minecraft:purple_terracotta
fill 376 199 630 376 199 631 minecraft:red_concrete
setblock 376 199 634 minecraft:red_concrete
fill 376 199 635 376 207 635 minecraft:purple_terracotta
fill 376 199 646 376 208 646 minecraft:purple_terracotta
fill 381 199 604 381 207 604 minecraft:purple_terracotta
setblock 381 199 646 minecraft:red_concrete
setblock 382 199 604 minecraft:red_concrete
fill 385 199 604 386 199 604 minecraft:red_concrete
setblock 392 199 646 minecraft:red_concrete
fill 396 199 646 397 205 646 minecraft:purple_terracotta
fill 402 199 604 402 204 604 minecraft:purple_terracotta
setblock 406 199 604 minecraft:red_concrete
setblock 413 199 646 minecraft:red_concrete
setblock 416 199 646 minecraft:red_concrete
setblock 417 199 604 minecraft:red_concrete
fill 417 199 646 417 203 646 minecraft:purple_terracotta
fill 418 199 608 418 208 608 minecraft:purple_terracotta
fill 418 199 619 418 207 619 minecraft:purple_terracotta
setblock 418 199 620 minecraft:red_concrete
setblock 418 199 624 minecraft:red_concrete
fill 418 199 640 418 205 640 minecraft:purple_terracotta
setblock 418 199 644 minecraft:red_concrete
fill 376 200 610 376 207 611 minecraft:purple_terracotta
fill 376 200 622 376 207 623 minecraft:purple_terracotta
fill 376 200 630 376 207 631 minecraft:purple_terracotta
fill 376 200 634 376 208 634 minecraft:purple_terracotta
fill 376 200 642 376 207 643 minecraft:purple_terracotta
fill 381 200 646 381 207 646 minecraft:purple_terracotta
fill 382 200 604 382 207 604 minecraft:purple_terracotta
fill 384 200 646 385 207 646 minecraft:purple_terracotta
fill 385 200 604 386 203 604 minecraft:purple_terracotta
fill 392 200 646 393 205 646 minecraft:purple_terracotta
fill 393 200 604 394 204 604 minecraft:purple_terracotta
fill 404 200 646 405 207 646 minecraft:purple_terracotta
fill 405 200 604 406 203 604 minecraft:purple_terracotta
fill 413 200 604 414 205 604 minecraft:purple_terracotta
fill 413 200 646 413 207 646 minecraft:purple_terracotta
fill 416 200 646 416 204 646 minecraft:purple_terracotta
fill 417 200 604 417 208 604 minecraft:purple_terracotta
fill 418 200 611 418 207 612 minecraft:purple_terracotta
fill 418 200 620 418 207 620 minecraft:purple_terracotta
fill 418 200 623 418 203 624 minecraft:purple_terracotta
fill 418 200 631 418 207 632 minecraft:purple_terracotta
fill 418 200 643 418 203 644 minecraft:purple_terracotta
setblock 379 202 607 minecraft:light[level=12]
setblock 379 202 615 minecraft:light[level=12]
setblock 379 202 623 minecraft:light[level=12]
setblock 379 202 631 minecraft:light[level=12]
setblock 379 202 639 minecraft:light[level=12]
setblock 387 202 607 minecraft:light[level=12]
setblock 387 202 615 minecraft:light[level=12]
setblock 387 202 623 minecraft:light[level=12]
setblock 387 202 631 minecraft:light[level=12]
setblock 387 202 639 minecraft:light[level=12]
setblock 395 202 607 minecraft:light[level=12]
setblock 395 202 615 minecraft:light[level=12]
setblock 395 202 623 minecraft:light[level=12]
setblock 395 202 631 minecraft:light[level=12]
setblock 395 202 639 minecraft:light[level=12]
setblock 403 202 607 minecraft:light[level=12]
setblock 403 202 615 minecraft:light[level=12]
setblock 403 202 623 minecraft:light[level=12]
setblock 403 202 631 minecraft:light[level=12]
setblock 403 202 639 minecraft:light[level=12]
setblock 411 202 607 minecraft:light[level=12]
setblock 411 202 615 minecraft:light[level=12]
setblock 411 202 623 minecraft:light[level=12]
setblock 411 202 631 minecraft:light[level=12]
setblock 411 202 639 minecraft:light[level=12]
setblock 376 204 608 minecraft:black_concrete
fill 376 204 609 376 207 609 minecraft:purple_terracotta
setblock 376 204 628 minecraft:black_concrete
setblock 376 204 640 minecraft:black_concrete
fill 376 204 641 376 208 641 minecraft:purple_terracotta
setblock 378 204 646 minecraft:purple_terracotta
fill 379 204 646 380 204 646 minecraft:black_concrete
setblock 385 204 604 minecraft:black_concrete
fill 386 204 604 386 207 604 minecraft:purple_terracotta
fill 392 204 624 394 204 626 minecraft:redstone_block
fill 399 204 625 401 204 627 minecraft:redstone_block
fill 400 204 618 402 204 620 minecraft:redstone_block
fill 403 204 604 404 204 604 minecraft:black_concrete
setblock 405 204 604 minecraft:purple_terracotta
setblock 406 204 604 minecraft:black_concrete
fill 407 204 604 407 207 604 minecraft:purple_terracotta
setblock 408 204 604 minecraft:black_concrete
fill 408 204 646 409 204 646 minecraft:black_concrete
setblock 414 204 646 minecraft:purple_terracotta
setblock 415 204 604 minecraft:black_concrete
setblock 415 204 646 minecraft:black_concrete
fill 416 204 604 416 205 604 minecraft:purple_terracotta
fill 417 204 646 417 205 646 minecraft:black_concrete
setblock 418 204 607 minecraft:black_concrete
setblock 418 204 617 minecraft:black_concrete
fill 418 204 618 418 208 618 minecraft:purple_terracotta
fill 418 204 623 418 207 623 minecraft:purple_terracotta
fill 418 204 624 418 205 624 minecraft:black_concrete
setblock 418 204 635 minecraft:purple_terracotta
setblock 418 204 636 minecraft:black_concrete
fill 418 204 643 418 204 644 minecraft:black_concrete
fill 376 205 608 376 207 608 minecraft:purple_terracotta
setblock 376 205 620 minecraft:black_concrete
fill 376 205 621 376 207 621 minecraft:purple_terracotta
fill 376 205 624 376 207 624 minecraft:purple_terracotta
fill 376 205 625 376 206 625 minecraft:black_concrete
fill 376 205 628 376 207 628 minecraft:purple_terracotta
fill 376 205 640 376 207 640 minecraft:purple_terracotta
fill 376 205 644 376 207 644 minecraft:purple_terracotta
setblock 376 205 645 minecraft:black_concrete
fill 377 205 622 395 205 622 minecraft:blackstone
fill 378 205 616 395 205 621 minecraft:blackstone
fill 378 205 623 391 205 628 minecraft:blackstone
setblock 378 205 646 minecraft:black_concrete
setblock 379 205 604 minecraft:black_concrete
fill 379 205 614 415 205 615 minecraft:blackstone
fill 379 205 629 415 205 630 minecraft:blackstone
fill 379 205 646 380 207 646 minecraft:purple_terracotta
fill 380 205 604 380 207 604 minecraft:purple_terracotta
fill 380 205 612 414 205 613 minecraft:blackstone
fill 380 205 631 414 205 632 minecraft:blackstone
fill 381 205 610 413 205 611 minecraft:blackstone
fill 381 205 633 413 205 634 minecraft:blackstone
fill 382 205 609 412 205 609 minecraft:blackstone
fill 382 205 635 412 205 635 minecraft:blackstone
fill 383 205 608 411 205 608 minecraft:blackstone
fill 383 205 636 411 205 636 minecraft:blackstone
fill 384 205 607 410 205 607 minecraft:blackstone
fill 384 205 637 410 205 637 minecraft:blackstone
fill 385 205 604 385 207 604 minecraft:purple_terracotta
fill 385 205 606 409 205 606 minecraft:blackstone
fill 385 205 638 409 205 638 minecraft:blackstone
fill 387 205 605 407 205 605 minecraft:blackstone
fill 387 205 639 407 205 639 minecraft:blackstone
fill 388 205 646 388 207 646 minecraft:purple_terracotta
fill 389 205 604 405 205 604 minecraft:blackstone
fill 389 205 640 405 205 640 minecraft:blackstone
setblock 389 205 646 minecraft:black_concrete
fill 391 205 641 403 205 641 minecraft:blackstone
fill 392 205 623 395 205 623 minecraft:blackstone
fill 392 205 627 398 205 628 minecraft:blackstone
fill 395 205 624 398 205 626 minecraft:blackstone
fill 396 205 616 399 205 620 minecraft:blackstone
fill 397 205 642 397 212 642 minecraft:blackstone
fill 399 205 621 416 205 624 minecraft:blackstone
fill 399 205 628 416 205 628 minecraft:blackstone
fill 399 205 646 399 206 646 minecraft:black_concrete
fill 400 205 616 416 205 617 minecraft:blackstone
fill 402 205 625 416 205 627 minecraft:blackstone
fill 403 205 618 416 205 620 minecraft:blackstone
fill 406 205 604 406 207 604 minecraft:purple_terracotta
fill 408 205 604 408 207 604 minecraft:purple_terracotta
setblock 408 205 646 minecraft:black_concrete
fill 409 205 646 409 207 646 minecraft:purple_terracotta
setblock 414 205 646 minecraft:black_concrete
fill 415 205 604 415 207 604 minecraft:purple_terracotta
fill 415 205 646 415 207 646 minecraft:purple_terracotta
setblock 416 205 646 minecraft:black_concrete
fill 417 205 622 417 212 622 minecraft:blackstone
fill 418 205 607 418 207 607 minecraft:purple_terracotta
setblock 418 205 617 minecraft:purple_terracotta
fill 418 205 635 418 206 635 minecraft:black_concrete
fill 418 205 636 418 207 636 minecraft:purple_terracotta
fill 418 205 643 418 207 644 minecraft:purple_terracotta
fill 418 205 645 418 205 646 minecraft:black_concrete
fill 376 206 612 376 207 612 minecraft:purple_terracotta
fill 376 206 613 379 206 613 minecraft:black_concrete
fill 376 206 616 377 206 616 minecraft:black_concrete
fill 376 206 618 377 206 618 minecraft:black_concrete
fill 376 206 619 376 207 620 minecraft:purple_terracotta
fill 376 206 629 378 206 629 minecraft:black_concrete
fill 376 206 638 376 207 638 minecraft:purple_terracotta
fill 376 206 639 386 206 639 minecraft:black_concrete
fill 376 206 645 376 207 645 minecraft:purple_terracotta
fill 377 206 605 379 206 612 minecraft:black_concrete
fill 377 206 614 378 206 615 minecraft:black_concrete
setblock 377 206 617 minecraft:black_concrete
fill 377 206 619 377 206 621 minecraft:black_concrete
fill 377 206 622 391 208 622 minecraft:blackstone
fill 377 206 623 377 206 628 minecraft:black_concrete
fill 377 206 630 378 206 638 minecraft:black_concrete
fill 377 206 640 388 206 645 minecraft:black_concrete
fill 378 206 616 378 212 621 minecraft:blackstone
fill 378 206 623 379 212 628 minecraft:blackstone
fill 378 206 646 378 207 646 minecraft:purple_terracotta
fill 379 206 604 379 208 604 minecraft:purple_terracotta
fill 379 206 614 379 212 619 minecraft:blackstone
fill 379 206 620 379 212 620 minecraft:red_concrete
fill 379 206 621 389 209 621 minecraft:blackstone
fill 379 206 629 379 212 629 minecraft:red_concrete
fill 379 206 630 397 209 630 minecraft:blackstone
fill 379 206 631 379 206 638 minecraft:black_concrete
fill 380 206 605 380 206 611 minecraft:black_concrete
fill 380 206 612 381 212 618 minecraft:blackstone
fill 380 206 619 381 212 619 minecraft:red_concrete
fill 380 206 620 392 208 620 minecraft:blackstone
fill 380 206 623 380 212 627 minecraft:blackstone
fill 380 206 628 380 212 628 minecraft:red_concrete
fill 380 206 629 385 211 629 minecraft:blackstone
fill 380 206 631 384 212 632 minecraft:blackstone
fill 380 206 633 380 206 638 minecraft:black_concrete
fill 381 206 605 381 206 609 minecraft:black_concrete
fill 381 206 610 392 210 611 minecraft:blackstone
fill 381 206 623 381 212 625 minecraft:blackstone
fill 381 206 626 381 212 626 minecraft:red_concrete
fill 381 206 627 386 210 628 minecraft:blackstone
fill 381 206 633 383 212 634 minecraft:blackstone
fill 381 206 635 381 206 638 minecraft:black_concrete
fill 382 206 605 382 206 608 minecraft:black_concrete
fill 382 206 609 391 211 609 minecraft:blackstone
fill 382 206 612 384 212 612 minecraft:red_concrete
fill 382 206 613 382 212 619 minecraft:blackstone
fill 382 206 623 382 211 624 minecraft:blackstone
fill 382 206 625 382 212 625 minecraft:red_concrete
fill 382 206 626 387 210 626 minecraft:blackstone
fill 382 206 635 383 212 635 minecraft:blackstone
fill 382 206 636 382 206 638 minecraft:black_concrete
fill 383 206 605 383 206 607 minecraft:black_concrete
fill 383 206 608 397 211 608 minecraft:blackstone
fill 383 206 613 387 210 617 minecraft:blackstone
fill 383 206 618 384 211 618 minecraft:red_concrete
fill 383 206 619 392 208 619 minecraft:blackstone
fill 383 206 623 384 211 623 minecraft:blackstone
fill 383 206 624 383 211 624 minecraft:red_concrete
fill 383 206 625 388 209 625 minecraft:blackstone
fill 383 206 636 383 212 636 minecraft:blackstone
fill 383 206 637 383 206 638 minecraft:black_concrete
fill 384 206 605 384 206 606 minecraft:black_concrete
fill 384 206 607 387 212 607 minecraft:blackstone
fill 384 206 624 390 208 624 minecraft:blackstone
fill 384 206 633 389 211 633 minecraft:blackstone
fill 384 206 634 384 212 637 minecraft:red_concrete
setblock 384 206 638 minecraft:black_concrete
fill 385 206 605 386 206 605 minecraft:black_concrete
fill 385 206 606 386 212 606 minecraft:red_concrete
fill 385 206 612 394 210 612 minecraft:blackstone
fill 385 206 618 390 209 618 minecraft:blackstone
fill 385 206 623 385 210 623 minecraft:red_concrete
fill 385 206 631 385 211 631 minecraft:red_concrete
fill 385 206 632 389 211 632 minecraft:blackstone
fill 385 206 634 389 211 638 minecraft:blackstone
fill 386 206 623 390 208 623 minecraft:blackstone
fill 386 206 629 386 211 629 minecraft:red_concrete
fill 386 206 631 404 209 631 minecraft:blackstone
fill 387 206 605 395 212 606 minecraft:blackstone
fill 387 206 627 387 210 627 minecraft:red_concrete
fill 387 206 628 397 208 629 minecraft:blackstone
fill 387 206 639 390 212 639 minecraft:blackstone
fill 388 206 607 389 212 607 minecraft:red_concrete
fill 388 206 613 389 210 613 minecraft:red_concrete
fill 388 206 614 390 209 617 minecraft:blackstone
fill 388 206 626 388 209 626 minecraft:red_concrete
fill 388 206 627 390 209 627 minecraft:blackstone
fill 389 206 604 394 212 604 minecraft:blackstone
fill 389 206 625 389 209 625 minecraft:red_concrete
fill 389 206 626 390 209 626 minecraft:blackstone
fill 389 206 640 390 212 640 minecraft:blackstone
fill 389 206 641 390 206 645 minecraft:black_concrete
fill 389 206 646 389 207 646 minecraft:purple_terracotta
fill 390 206 607 409 211 607 minecraft:blackstone
fill 390 206 613 408 209 613 minecraft:blackstone
fill 390 206 621 390 208 621 minecraft:red_concrete
fill 390 206 625 390 208 625 minecraft:blackstone
fill 390 206 632 390 210 636 minecraft:red_concrete
fill 390 206 637 396 211 638 minecraft:blackstone
fill 391 206 614 391 209 614 minecraft:red_concrete
fill 391 206 615 395 208 617 minecraft:blackstone
fill 391 206 618 391 208 618 minecraft:red_concrete
fill 391 206 621 391 208 621 minecraft:blackstone
fill 391 206 623 391 206 627 minecraft:shroomlight
fill 391 206 632 394 210 636 minecraft:blackstone
fill 391 206 639 391 212 640 minecraft:red_concrete
fill 391 206 641 399 212 641 minecraft:blackstone
fill 391 206 642 396 206 645 minecraft:black_concrete
fill 392 206 609 392 211 609 minecraft:red_concrete
fill 392 206 614 395 209 614 minecraft:blackstone
fill 392 206 618 393 208 618 minecraft:blackstone
fill 392 206 621 394 207 622 minecraft:magma_block
fill 392 206 623 395 206 623 minecraft:shroomlight
fill 392 206 624 394 206 626 minecraft:black_concrete
fill 392 206 627 395 206 627 minecraft:shroomlight
fill 392 206 639 397 212 640 minecraft:blackstone
fill 392 206 646 393 206 646 minecraft:black_concrete
fill 393 206 609 403 211 609 minecraft:blackstone
fill 393 206 610 393 210 610 minecraft:red_concrete
fill 393 206 611 393 210 611 minecraft:blackstone
fill 393 206 619 394 207 620 minecraft:magma_block
fill 394 206 610 398 210 610 minecraft:blackstone
fill 394 206 611 394 210 611 minecraft:red_concrete
fill 394 206 618 398 207 618 minecraft:magma_block
fill 395 206 604 395 213 604 minecraft:red_concrete
fill 395 206 611 398 210 611 minecraft:blackstone
fill 395 206 612 395 209 612 minecraft:red_concrete
fill 395 206 619 398 207 619 minecraft:magma_block
fill 395 206 620 395 206 622 minecraft:shroomlight
fill 395 206 624 395 206 626 minecraft:shroomlight
fill 395 206 632 398 209 632 minecraft:blackstone
fill 395 206 633 395 210 634 minecraft:red_concrete
fill 395 206 635 395 211 636 minecraft:blackstone
fill 396 206 604 402 212 604 minecraft:blackstone
fill 396 206 605 396 212 605 minecraft:red_concrete
fill 396 206 606 396 212 606 minecraft:blackstone
fill 396 206 612 403 209 612 minecraft:blackstone
fill 396 206 614 396 209 614 minecraft:red_concrete
fill 396 206 615 407 208 616 minecraft:blackstone
fill 396 206 617 398 207 617 minecraft:magma_block
fill 396 206 620 399 206 620 minecraft:shroomlight
fill 396 206 624 402 206 624 minecraft:shroomlight
fill 396 206 625 397 207 627 minecraft:magma_block
fill 396 206 633 399 210 635 minecraft:blackstone
fill 396 206 636 396 211 636 minecraft:red_concrete
setblock 396 206 646 minecraft:black_concrete
fill 397 206 605 402 212 605 minecraft:blackstone
fill 397 206 606 397 212 606 minecraft:red_concrete
fill 397 206 614 415 209 614 minecraft:blackstone
fill 397 206 636 404 211 637 minecraft:blackstone
fill 397 206 638 397 212 638 minecraft:red_concrete
fill 397 206 643 417 206 645 minecraft:black_concrete
fill 397 206 646 397 207 646 minecraft:purple_terracotta
fill 398 206 606 409 212 606 minecraft:blackstone
fill 398 206 608 398 211 608 minecraft:red_concrete
fill 398 206 625 398 206 628 minecraft:shroomlight
fill 398 206 629 415 208 629 minecraft:blackstone
fill 398 206 630 398 209 630 minecraft:red_concrete
fill 398 206 638 407 212 638 minecraft:blackstone
fill 398 206 639 398 212 639 minecraft:red_concrete
fill 398 206 640 398 212 640 minecraft:blackstone
fill 398 206 642 417 206 642 minecraft:black_concrete
fill 399 206 608 403 211 608 minecraft:blackstone
fill 399 206 610 399 210 611 minecraft:red_concrete
fill 399 206 617 399 206 619 minecraft:shroomlight
fill 399 206 621 399 206 623 minecraft:shroomlight
fill 399 206 625 401 206 627 minecraft:black_concrete
fill 399 206 628 402 206 628 minecraft:shroomlight
fill 399 206 630 402 209 630 minecraft:blackstone
fill 399 206 632 399 209 632 minecraft:red_concrete
fill 399 206 639 407 212 639 minecraft:blackstone
fill 399 206 640 399 212 640 minecraft:red_concrete
fill 400 206 610 403 210 611 minecraft:blackstone
fill 400 206 617 403 206 617 minecraft:shroomlight
fill 400 206 618 402 206 620 minecraft:black_concrete
fill 400 206 621 403 206 621 minecraft:shroomlight
fill 400 206 622 402 207 623 minecraft:magma_block
fill 400 206 632 409 210 632 minecraft:blackstone
fill 400 206 633 400 210 633 minecraft:red_concrete
fill 400 206 634 400 210 635 minecraft:blackstone
fill 400 206 640 405 212 640 minecraft:blackstone
fill 400 206 641 400 212 641 minecraft:red_concrete
fill 401 206 633 413 210 633 minecraft:blackstone
fill 401 206 634 401 210 634 minecraft:red_concrete
fill 401 206 635 401 211 635 minecraft:blackstone
fill 401 206 641 403 212 641 minecraft:blackstone
fill 402 206 625 402 206 627 minecraft:shroomlight
fill 402 206 634 413 211 634 minecraft:blackstone
fill 402 206 635 402 211 635 minecraft:red_concrete
fill 403 206 604 403 212 605 minecraft:red_concrete
fill 403 206 618 403 206 620 minecraft:shroomlight
fill 403 206 622 403 208 625 minecraft:blackstone
fill 403 206 626 403 208 626 minecraft:red_concrete
fill 403 206 627 416 209 628 minecraft:blackstone
fill 403 206 630 403 209 630 minecraft:red_concrete
fill 403 206 635 412 211 635 minecraft:blackstone
fill 404 206 604 405 212 605 minecraft:blackstone
fill 404 206 608 404 210 612 minecraft:red_concrete
fill 404 206 617 404 208 622 minecraft:blackstone
fill 404 206 623 404 208 623 minecraft:red_concrete
fill 404 206 624 409 208 626 minecraft:blackstone
fill 404 206 630 415 210 630 minecraft:blackstone
fill 404 206 641 417 206 641 minecraft:black_concrete
fill 405 206 608 409 211 612 minecraft:blackstone
fill 405 206 617 405 209 618 minecraft:blackstone
fill 405 206 619 405 209 619 minecraft:red_concrete
fill 405 206 620 408 209 623 minecraft:blackstone
fill 405 206 631 406 210 631 minecraft:red_concrete
fill 405 206 636 411 212 636 minecraft:blackstone
fill 405 206 637 406 212 637 minecraft:red_concrete
fill 406 206 605 407 212 605 minecraft:blackstone
fill 406 206 617 406 210 617 minecraft:blackstone
fill 406 206 618 406 209 618 minecraft:red_concrete
fill 406 206 619 411 209 619 minecraft:blackstone
fill 406 206 640 418 206 640 minecraft:black_concrete
fill 406 206 646 406 207 646 minecraft:purple_terracotta
fill 407 206 617 407 210 617 minecraft:red_concrete
fill 407 206 618 412 210 618 minecraft:blackstone
fill 407 206 631 414 211 631 minecraft:blackstone
fill 407 206 637 410 212 637 minecraft:blackstone
setblock 407 206 646 minecraft:black_concrete
fill 408 206 605 417 206 605 minecraft:black_concrete
fill 408 206 615 408 211 615 minecraft:red_concrete
fill 408 206 616 413 210 617 minecraft:blackstone
fill 408 206 638 409 212 638 minecraft:red_concrete
fill 408 206 639 417 206 639 minecraft:black_concrete
fill 408 206 646 408 207 646 minecraft:purple_terracotta
fill 409 206 613 409 211 613 minecraft:red_concrete
fill 409 206 615 414 211 615 minecraft:blackstone
fill 409 206 620 410 210 620 minecraft:blackstone
fill 409 206 621 409 210 621 minecraft:red_concrete
fill 409 206 622 416 210 623 minecraft:blackstone
fill 410 206 606 417 206 606 minecraft:black_concrete
fill 410 206 607 410 212 610 minecraft:red_concrete
fill 410 206 611 413 212 613 minecraft:blackstone
fill 410 206 621 416 211 621 minecraft:blackstone
fill 410 206 624 412 211 625 minecraft:blackstone
fill 410 206 626 411 211 626 minecraft:red_concrete
fill 410 206 632 412 212 632 minecraft:red_concrete
fill 410 206 638 417 206 638 minecraft:black_concrete
fill 411 206 607 417 206 607 minecraft:black_concrete
fill 411 206 608 411 212 610 minecraft:blackstone
fill 411 206 620 411 211 620 minecraft:red_concrete
fill 411 206 637 417 206 637 minecraft:black_concrete
setblock 411 206 646 minecraft:black_concrete
fill 412 206 608 417 206 608 minecraft:black_concrete
fill 412 206 609 412 212 610 minecraft:blackstone
fill 412 206 619 412 212 619 minecraft:red_concrete
fill 412 206 620 416 211 620 minecraft:blackstone
fill 412 206 626 416 212 626 minecraft:blackstone
fill 412 206 636 417 206 636 minecraft:black_concrete
setblock 413 206 604 minecraft:black_concrete
fill 413 206 609 417 206 609 minecraft:black_concrete
fill 413 206 610 413 212 610 minecraft:blackstone
fill 413 206 618 413 212 618 minecraft:red_concrete
fill 413 206 619 416 212 619 minecraft:blackstone
fill 413 206 624 414 212 624 minecraft:blackstone
fill 413 206 625 414 212 625 minecraft:red_concrete
fill 413 206 632 414 212 632 minecraft:blackstone
fill 413 206 635 417 206 635 minecraft:black_concrete
fill 414 206 604 414 207 604 minecraft:purple_terracotta
fill 414 206 610 417 206 611 minecraft:black_concrete
fill 414 206 612 414 212 613 minecraft:blackstone
fill 414 206 616 414 212 616 minecraft:red_concrete
fill 414 206 617 416 212 618 minecraft:blackstone
fill 414 206 633 417 206 634 minecraft:black_concrete
fill 414 206 646 414 207 646 minecraft:purple_terracotta
fill 415 206 612 417 206 613 minecraft:black_concrete
fill 415 206 615 415 212 615 minecraft:red_concrete
fill 415 206 616 416 212 616 minecraft:blackstone
fill 415 206 624 415 212 624 minecraft:red_concrete
fill 415 206 625 416 212 625 minecraft:blackstone
fill 415 206 631 417 206 632 minecraft:black_concrete
setblock 416 206 604 minecraft:black_concrete
fill 416 206 614 417 206 615 minecraft:black_concrete
fill 416 206 624 416 212 624 minecraft:blackstone
fill 416 206 629 417 206 630 minecraft:black_concrete
fill 416 206 646 418 207 646 minecraft:purple_terracotta
fill 417 206 616 417 206 621 minecraft:black_concrete
fill 417 206 623 417 206 628 minecraft:black_concrete
fill 418 206 615 418 207 615 minecraft:purple_terracotta
fill 418 206 616 418 206 617 minecraft:black_concrete
fill 418 206 624 418 207 624 minecraft:purple_terracotta
fill 418 206 645 418 208 645 minecraft:purple_terracotta
fill 376 207 613 376 208 613 minecraft:purple_terracotta
setblock 376 207 616 minecraft:purple_terracotta
setblock 376 207 618 minecraft:purple_terracotta
setblock 376 207 625 minecraft:purple_terracotta
setblock 376 207 629 minecraft:purple_terracotta
setblock 376 207 639 minecraft:purple_terracotta
fill 391 207 623 391 208 627 minecraft:blackstone
fill 392 207 623 394 207 623 minecraft:magma_block
fill 392 207 624 392 208 627 minecraft:blackstone
fill 392 207 646 393 207 646 minecraft:purple_terracotta
fill 393 207 624 395 207 625 minecraft:magma_block
fill 393 207 626 393 208 627 minecraft:blackstone
fill 394 207 626 395 207 626 minecraft:magma_block
fill 394 207 627 395 208 627 minecraft:blackstone
setblock 395 207 620 minecraft:magma_block
setblock 396 207 646 minecraft:purple_terracotta
fill 398 207 625 398 207 627 minecraft:magma_block
fill 398 207 628 402 208 628 minecraft:blackstone
fill 399 207 617 403 208 617 minecraft:blackstone
fill 399 207 618 400 207 620 minecraft:magma_block
fill 399 207 624 400 207 626 minecraft:magma_block
fill 399 207 627 402 208 627 minecraft:blackstone
setblock 399 207 646 minecraft:purple_terracotta
fill 400 207 621 402 207 621 minecraft:magma_block
fill 401 207 618 403 208 618 minecraft:blackstone
fill 401 207 619 401 207 620 minecraft:magma_block
fill 401 207 624 401 207 625 minecraft:magma_block
fill 401 207 626 402 208 626 minecraft:blackstone
fill 402 207 619 403 208 620 minecraft:blackstone
fill 402 207 624 402 208 625 minecraft:blackstone
fill 403 207 621 403 208 621 minecraft:blackstone
fill 407 207 646 407 208 646 minecraft:purple_terracotta
setblock 411 207 646 minecraft:purple_terracotta
setblock 413 207 604 minecraft:purple_terracotta
setblock 416 207 604 minecraft:purple_terracotta
fill 418 207 616 418 207 617 minecraft:purple_terracotta
fill 418 207 635 418 209 635 minecraft:purple_terracotta
setblock 418 207 640 minecraft:purple_terracotta
fill 376 208 604 376 209 609 minecraft:black_concrete
setblock 376 208 610 minecraft:purple_terracotta
fill 376 208 611 376 208 612 minecraft:black_concrete
fill 376 208 614 376 208 626 minecraft:black_concrete
setblock 376 208 627 minecraft:purple_terracotta
fill 376 208 628 376 208 633 minecraft:black_concrete
fill 376 208 635 376 208 640 minecraft:black_concrete
fill 376 208 642 376 211 645 minecraft:black_concrete
fill 377 208 604 378 209 604 minecraft:black_concrete
fill 378 208 646 399 208 646 minecraft:black_concrete
fill 380 208 604 388 208 604 minecraft:black_concrete
setblock 400 208 646 minecraft:purple_terracotta
fill 401 208 646 406 209 646 minecraft:black_concrete
fill 406 208 604 409 209 604 minecraft:black_concrete
fill 408 208 646 417 209 646 minecraft:black_concrete
fill 410 208 604 410 209 604 minecraft:purple_terracotta
fill 411 208 604 411 215 604 minecraft:black_concrete
setblock 412 208 604 minecraft:purple_terracotta
fill 413 208 604 416 208 604 minecraft:black_concrete
fill 418 208 604 418 208 607 minecraft:black_concrete
fill 418 208 609 418 211 609 minecraft:black_concrete
setblock 418 208 610 minecraft:purple_terracotta
fill 418 208 611 418 209 617 minecraft:black_concrete
fill 418 208 619 418 209 630 minecraft:black_concrete
setblock 418 208 631 minecraft:purple_terracotta
fill 418 208 632 418 210 634 minecraft:black_concrete
fill 418 208 636 418 208 644 minecraft:black_concrete
setblock 418 208 646 minecraft:purple_terracotta
fill 376 209 610 376 213 611 minecraft:black_concrete
setblock 376 209 612 minecraft:purple_terracotta
fill 376 209 613 376 209 614 minecraft:black_concrete
fill 376 209 615 376 209 616 minecraft:purple_terracotta
fill 376 209 617 376 211 621 minecraft:black_concrete
fill 376 209 622 376 209 623 minecraft:purple_terracotta
fill 376 209 624 376 209 627 minecraft:black_concrete
setblock 376 209 628 minecraft:purple_terracotta
fill 376 209 629 376 209 630 minecraft:black_concrete
fill 376 209 631 376 209 632 minecraft:purple_terracotta
fill 376 209 633 376 210 634 minecraft:black_concrete
setblock 376 209 635 minecraft:purple_terracotta
fill 376 209 636 376 209 641 minecraft:black_concrete
setblock 376 209 646 minecraft:black_concrete
fill 377 209 622 389 209 622 minecraft:blackstone
fill 378 209 646 387 209 646 minecraft:black_concrete
fill 379 209 604 385 209 604 minecraft:black_concrete
fill 380 209 620 389 209 620 minecraft:blackstone
fill 383 209 619 389 209 619 minecraft:blackstone
fill 384 209 624 389 209 624 minecraft:blackstone
fill 386 209 604 386 210 604 minecraft:purple_terracotta
fill 386 209 623 389 209 623 minecraft:blackstone
fill 387 209 604 388 215 604 minecraft:black_concrete
fill 387 209 628 392 209 629 minecraft:blackstone
setblock 388 209 646 minecraft:purple_terracotta
fill 389 209 646 400 209 646 minecraft:black_concrete
fill 391 209 615 391 209 617 minecraft:blackstone
setblock 391 209 627 minecraft:blackstone
fill 392 209 615 392 209 616 minecraft:blackstone
setblock 393 209 615 minecraft:blackstone
setblock 393 209 629 minecraft:blackstone
fill 401 209 615 407 209 615 minecraft:blackstone
fill 401 209 629 415 209 629 minecraft:blackstone
fill 402 209 616 407 209 616 minecraft:blackstone
setblock 402 209 628 minecraft:blackstone
fill 403 209 617 404 209 617 minecraft:blackstone
setblock 404 209 618 minecraft:blackstone
fill 404 209 626 409 209 626 minecraft:blackstone
fill 405 209 624 409 209 625 minecraft:blackstone
fill 407 209 646 407 211 646 minecraft:black_concrete
fill 412 209 604 414 209 604 minecraft:black_concrete
setblock 415 209 604 minecraft:purple_terracotta
fill 416 209 604 417 211 604 minecraft:black_concrete
setblock 418 209 604 minecraft:purple_terracotta
fill 418 209 605 418 209 608 minecraft:black_concrete
fill 418 209 610 418 211 610 minecraft:black_concrete
fill 418 209 618 418 215 618 minecraft:black_concrete
fill 418 209 631 418 210 631 minecraft:black_concrete
fill 418 209 636 418 209 640 minecraft:black_concrete
setblock 418 209 641 minecraft:purple_terracotta
fill 418 209 642 418 209 646 minecraft:black_concrete
fill 376 210 604 376 211 605 minecraft:black_concrete
fill 376 210 606 376 210 607 minecraft:red_concrete
setblock 376 210 608 minecraft:purple_terracotta
fill 376 210 609 376 212 609 minecraft:black_concrete
fill 376 210 612 376 211 613 minecraft:black_concrete
fill 376 210 614 376 211 615 minecraft:red_concrete
fill 376 210 616 376 215 616 minecraft:black_concrete
fill 376 210 622 376 210 625 minecraft:black_concrete
fill 376 210 626 376 210 627 minecraft:red_concrete
fill 376 210 628 376 215 628 minecraft:black_concrete
setblock 376 210 629 minecraft:purple_terracotta
fill 376 210 630 376 211 632 minecraft:black_concrete
fill 376 210 635 376 211 635 minecraft:red_concrete
fill 376 210 636 376 215 637 minecraft:black_concrete
setblock 376 210 638 minecraft:red_concrete
fill 376 210 639 376 213 640 minecraft:black_concrete
setblock 376 210 641 minecraft:purple_terracotta
fill 376 210 646 377 211 646 minecraft:red_concrete
fill 377 210 604 377 213 604 minecraft:black_concrete
fill 377 210 605 379 210 605 minecraft:polished_blackstone
fill 377 210 607 377 210 609 minecraft:polished_blackstone
fill 377 210 611 377 210 613 minecraft:polished_blackstone
fill 377 210 615 377 210 617 minecraft:polished_blackstone
fill 377 210 619 377 210 621 minecraft:polished_blackstone
fill 377 210 622 386 210 622 minecraft:blackstone
fill 377 210 623 377 210 625 minecraft:polished_blackstone
fill 377 210 627 377 210 629 minecraft:polished_blackstone
fill 377 210 631 377 210 633 minecraft:polished_blackstone
fill 377 210 635 377 210 637 minecraft:polished_blackstone
fill 377 210 639 377 210 641 minecraft:polished_blackstone
fill 377 210 643 377 210 645 minecraft:polished_blackstone
setblock 378 210 604 minecraft:red_concrete
fill 378 210 646 382 212 646 minecraft:black_concrete
fill 379 210 604 380 210 604 minecraft:purple_terracotta
setblock 379 210 607 minecraft:light[level=12]
fill 379 210 621 386 210 621 minecraft:blackstone
fill 379 210 630 390 210 630 minecraft:blackstone
setblock 379 210 631 minecraft:light[level=12]
setblock 379 210 639 minecraft:light[level=12]
fill 379 210 645 381 210 645 minecraft:polished_blackstone
fill 380 210 620 386 210 620 minecraft:blackstone
fill 381 210 604 381 211 604 minecraft:red_concrete
fill 381 210 605 383 210 605 minecraft:polished_blackstone
setblock 382 210 604 minecraft:purple_terracotta
fill 383 210 604 385 211 604 minecraft:black_concrete
fill 383 210 619 387 210 619 minecraft:blackstone
fill 383 210 625 387 210 625 minecraft:blackstone
fill 383 210 645 385 210 645 minecraft:polished_blackstone
setblock 383 210 646 minecraft:purple_terracotta
fill 384 210 624 386 210 624 minecraft:blackstone
fill 384 210 646 386 210 646 minecraft:black_concrete
fill 385 210 605 386 210 605 minecraft:polished_blackstone
fill 385 210 618 387 210 618 minecraft:blackstone
setblock 386 210 623 minecraft:blackstone
fill 386 210 631 392 210 631 minecraft:blackstone
setblock 387 210 623 minecraft:light[level=12]
fill 387 210 628 388 210 629 minecraft:blackstone
fill 387 210 645 389 210 645 minecraft:polished_blackstone
setblock 387 210 646 minecraft:purple_terracotta
fill 388 210 614 388 210 617 minecraft:blackstone
setblock 388 210 627 minecraft:blackstone
fill 388 210 646 389 210 646 minecraft:red_concrete
fill 389 210 614 389 210 615 minecraft:blackstone
setblock 389 210 629 minecraft:blackstone
fill 390 210 613 390 210 614 minecraft:blackstone
setblock 390 210 646 minecraft:purple_terracotta
fill 391 210 613 392 210 613 minecraft:blackstone
fill 391 210 645 393 210 645 minecraft:polished_blackstone
fill 391 210 646 395 211 646 minecraft:black_concrete
setblock 395 210 615 minecraft:light[level=12]
setblock 395 210 623 minecraft:light[level=12]
setblock 395 210 631 minecraft:light[level=12]
fill 395 210 645 397 210 645 minecraft:polished_blackstone
fill 396 210 646 397 211 646 minecraft:red_concrete
fill 398 210 646 399 215 646 minecraft:black_concrete
fill 399 210 645 401 210 645 minecraft:polished_blackstone
fill 400 210 612 403 210 612 minecraft:blackstone
setblock 400 210 646 minecraft:red_concrete
fill 401 210 646 404 212 646 minecraft:black_concrete
fill 402 210 613 408 210 613 minecraft:blackstone
fill 402 210 631 404 210 631 minecraft:blackstone
setblock 403 210 615 minecraft:light[level=12]
setblock 403 210 623 minecraft:light[level=12]
fill 403 210 645 405 210 645 minecraft:polished_blackstone
fill 404 210 614 415 210 614 minecraft:blackstone
fill 405 210 615 407 210 615 minecraft:blackstone
fill 405 210 629 415 210 629 minecraft:blackstone
setblock 405 210 646 minecraft:purple_terracotta
setblock 406 210 604 minecraft:purple_terracotta
fill 406 210 616 407 210 616 minecraft:blackstone
fill 406 210 627 416 210 628 minecraft:blackstone
fill 406 210 646 406 211 646 minecraft:black_concrete
fill 407 210 604 408 212 604 minecraft:black_concrete
fill 407 210 619 411 210 619 minecraft:blackstone
fill 407 210 625 409 210 626 minecraft:blackstone
fill 407 210 645 409 210 645 minecraft:polished_blackstone
fill 408 210 620 408 210 624 minecraft:blackstone
fill 408 210 646 409 211 646 minecraft:red_concrete
fill 409 210 604 410 210 604 minecraft:red_concrete
fill 409 210 605 411 210 605 minecraft:polished_blackstone
setblock 409 210 624 minecraft:blackstone
fill 410 210 646 416 210 646 minecraft:black_concrete
setblock 411 210 607 minecraft:light[level=12]
setblock 411 210 639 minecraft:light[level=12]
fill 411 210 645 413 210 645 minecraft:polished_blackstone
fill 412 210 604 412 211 604 minecraft:black_concrete
fill 413 210 604 413 211 604 minecraft:red_concrete
fill 413 210 605 415 210 605 minecraft:polished_blackstone
fill 414 210 604 415 210 604 minecraft:black_concrete
fill 415 210 645 417 210 645 minecraft:polished_blackstone
fill 417 210 605 417 210 607 minecraft:polished_blackstone
fill 417 210 609 417 210 611 minecraft:polished_blackstone
fill 417 210 613 417 210 615 minecraft:polished_blackstone
fill 417 210 617 417 210 619 minecraft:polished_blackstone
setblock 417 210 621 minecraft:polished_blackstone
setblock 417 210 623 minecraft:polished_blackstone
fill 417 210 625 417 210 627 minecraft:polished_blackstone
fill 417 210 629 417 210 631 minecraft:polished_blackstone
fill 417 210 633 417 210 635 minecraft:polished_blackstone
fill 417 210 637 417 210 639 minecraft:polished_blackstone
fill 417 210 641 417 210 643 minecraft:polished_blackstone
fill 417 210 646 417 211 646 minecraft:red_concrete
fill 418 210 604 418 213 604 minecraft:black_concrete
setblock 418 210 605 minecraft:purple_terracotta
fill 418 210 606 418 215 606 minecraft:black_concrete
fill 418 210 607 418 211 608 minecraft:red_concrete
fill 418 210 611 418 210 615 minecraft:black_concrete
setblock 418 210 616 minecraft:red_concrete
fill 418 210 617 418 215 617 minecraft:black_concrete
fill 418 210 619 418 211 620 minecraft:red_concrete
fill 418 210 621 418 211 626 minecraft:black_concrete
fill 418 210 627 418 210 628 minecraft:red_concrete
setblock 418 210 629 minecraft:purple_terracotta
fill 418 210 630 418 211 630 minecraft:black_concrete
fill 418 210 635 418 213 637 minecraft:black_concrete
setblock 418 210 638 minecraft:purple_terracotta
fill 418 210 639 418 211 640 minecraft:red_concrete
fill 418 210 641 418 211 641 minecraft:black_concrete
setblock 418 210 642 minecraft:purple_terracotta
fill 418 210 643 418 211 646 minecraft:black_concrete
fill 376 211 606 376 214 608 minecraft:black_concrete
fill 376 211 622 376 213 622 minecraft:black_concrete
setblock 376 211 623 minecraft:red_concrete
fill 376 211 624 376 211 625 minecraft:black_concrete
setblock 376 211 626 minecraft:red_concrete
fill 376 211 627 376 214 627 minecraft:black_concrete
fill 376 211 629 376 215 629 minecraft:black_concrete
setblock 376 211 633 minecraft:black_concrete
setblock 376 211 634 minecraft:red_concrete
fill 376 211 638 376 214 638 minecraft:black_concrete
fill 376 211 641 376 212 641 minecraft:black_concrete
fill 377 211 622 384 211 622 minecraft:blackstone
fill 378 211 604 380 214 604 minecraft:black_concrete
fill 379 211 621 384 211 621 minecraft:blackstone
fill 379 211 630 387 211 630 minecraft:blackstone
fill 380 211 620 384 211 620 minecraft:blackstone
fill 381 211 610 390 211 611 minecraft:blackstone
fill 381 211 627 385 211 628 minecraft:blackstone
setblock 382 211 604 minecraft:red_concrete
fill 382 211 626 384 211 626 minecraft:blackstone
fill 383 211 613 385 211 617 minecraft:blackstone
fill 383 211 619 384 211 619 minecraft:blackstone
fill 383 211 625 384 211 625 minecraft:blackstone
setblock 383 211 646 minecraft:black_concrete
setblock 384 211 624 minecraft:blackstone
fill 384 211 646 385 211 646 minecraft:red_concrete
fill 385 211 612 389 211 612 minecraft:blackstone
fill 386 211 604 386 213 604 minecraft:black_concrete
fill 386 211 613 386 211 615 minecraft:blackstone
fill 386 211 631 387 211 631 minecraft:blackstone
fill 386 211 646 387 211 646 minecraft:black_concrete
fill 387 211 613 387 211 614 minecraft:blackstone
setblock 388 211 646 minecraft:red_concrete
fill 389 211 646 390 214 646 minecraft:black_concrete
fill 390 211 633 390 211 636 minecraft:red_concrete
fill 391 211 610 392 211 610 minecraft:blackstone
fill 391 211 634 392 211 636 minecraft:blackstone
fill 393 211 635 394 211 636 minecraft:blackstone
fill 396 211 635 400 211 635 minecraft:blackstone
fill 400 211 646 400 214 646 minecraft:black_concrete
fill 402 211 610 403 211 610 minecraft:blackstone
fill 404 211 608 404 211 611 minecraft:red_concrete
fill 404 211 633 413 211 633 minecraft:blackstone
fill 405 211 632 409 211 632 minecraft:blackstone
setblock 405 211 646 minecraft:red_concrete
fill 406 211 604 406 213 604 minecraft:black_concrete
fill 407 211 613 408 211 614 minecraft:blackstone
fill 407 211 630 415 211 630 minecraft:blackstone
fill 408 211 629 415 211 629 minecraft:blackstone
fill 409 211 604 410 214 604 minecraft:black_concrete
fill 409 211 614 415 211 614 minecraft:blackstone
fill 409 211 616 413 211 617 minecraft:blackstone
fill 409 211 627 416 211 628 minecraft:blackstone
fill 410 211 618 410 211 620 minecraft:blackstone
fill 410 211 622 416 211 623 minecraft:blackstone
fill 410 211 646 415 211 646 minecraft:black_concrete
fill 411 211 618 411 211 619 minecraft:blackstone
fill 412 211 618 412 212 618 minecraft:blackstone
setblock 414 211 604 minecraft:red_concrete
setblock 415 211 604 minecraft:black_concrete
setblock 416 211 646 minecraft:red_concrete
fill 418 211 605 418 215 605 minecraft:black_concrete
setblock 418 211 611 minecraft:red_concrete
fill 418 211 612 418 212 616 minecraft:black_concrete
fill 418 211 627 418 214 627 minecraft:black_concrete
setblock 418 211 628 minecraft:red_concrete
setblock 418 211 629 minecraft:black_concrete
fill 418 211 631 418 211 632 minecraft:red_concrete
fill 418 211 633 418 211 634 minecraft:black_concrete
fill 418 211 638 418 215 638 minecraft:black_concrete
setblock 418 211 642 minecraft:black_concrete
setblock 376 212 604 minecraft:red_concrete
fill 376 212 605 376 215 605 minecraft:black_concrete
fill 376 212 612 376 213 613 minecraft:red_concrete
fill 376 212 614 376 217 615 minecraft:black_concrete
fill 376 212 617 376 212 620 minecraft:black_concrete
fill 376 212 621 376 213 621 minecraft:red_concrete
fill 376 212 623 376 217 623 minecraft:black_concrete
fill 376 212 624 376 212 625 minecraft:red_concrete
fill 376 212 626 376 217 626 minecraft:black_concrete
fill 376 212 630 376 213 631 minecraft:black_concrete
fill 376 212 632 376 213 633 minecraft:red_concrete
fill 376 212 634 376 217 635 minecraft:black_concrete
fill 376 212 642 376 213 643 minecraft:black_concrete
fill 376 212 644 376 212 645 minecraft:red_concrete
fill 376 212 646 377 217 646 minecraft:black_concrete
fill 377 212 622 381 212 622 minecraft:blackstone
fill 379 212 621 381 212 621 minecraft:blackstone
fill 379 212 630 384 212 630 minecraft:blackstone
fill 380 212 620 381 212 620 minecraft:blackstone
fill 380 212 629 383 212 629 minecraft:blackstone
fill 381 212 604 382 217 604 minecraft:black_concrete
fill 381 212 610 386 212 611 minecraft:blackstone
fill 381 212 627 382 212 628 minecraft:blackstone
fill 382 212 609 389 212 609 minecraft:blackstone
setblock 382 212 626 minecraft:blackstone
fill 383 212 604 384 213 604 minecraft:red_concrete
fill 383 212 608 390 212 608 minecraft:blackstone
fill 383 212 613 383 212 615 minecraft:blackstone
fill 383 212 646 383 213 646 minecraft:red_concrete
fill 384 212 613 384 212 614 minecraft:blackstone
fill 384 212 633 386 212 633 minecraft:blackstone
fill 384 212 646 385 217 646 minecraft:black_concrete
fill 385 212 604 385 213 604 minecraft:black_concrete
setblock 385 212 612 minecraft:blackstone
setblock 385 212 632 minecraft:blackstone
fill 385 212 634 387 212 638 minecraft:blackstone
setblock 386 212 646 minecraft:red_concrete
setblock 387 212 610 minecraft:blackstone
fill 387 212 646 388 215 646 minecraft:black_concrete
fill 388 212 635 389 212 638 minecraft:blackstone
fill 390 212 607 394 212 607 minecraft:blackstone
setblock 390 212 636 minecraft:red_concrete
fill 390 212 637 394 212 638 minecraft:blackstone
fill 391 212 646 393 213 646 minecraft:black_concrete
fill 394 212 646 395 213 646 minecraft:red_concrete
fill 395 212 638 396 212 638 minecraft:blackstone
fill 396 212 646 397 217 646 minecraft:black_concrete
fill 400 212 607 409 212 607 minecraft:blackstone
fill 400 212 637 404 212 637 minecraft:blackstone
setblock 404 212 608 minecraft:red_concrete
setblock 404 212 636 minecraft:blackstone
fill 405 212 608 409 212 609 minecraft:blackstone
fill 405 212 635 412 212 635 minecraft:blackstone
fill 405 212 646 405 217 646 minecraft:black_concrete
fill 406 212 646 407 212 646 minecraft:red_concrete
fill 407 212 610 409 212 610 minecraft:blackstone
fill 407 212 634 413 212 634 minecraft:blackstone
fill 408 212 611 409 212 611 minecraft:blackstone
fill 408 212 633 413 212 633 minecraft:blackstone
fill 408 212 646 413 213 646 minecraft:black_concrete
setblock 409 212 612 minecraft:blackstone
setblock 409 212 632 minecraft:blackstone
fill 410 212 614 415 212 614 minecraft:blackstone
fill 410 212 630 414 212 631 minecraft:blackstone
fill 411 212 615 414 212 615 minecraft:blackstone
fill 411 212 629 415 212 629 minecraft:blackstone
setblock 412 212 604 minecraft:red_concrete
fill 412 212 616 413 212 617 minecraft:blackstone
setblock 412 212 625 minecraft:blackstone
fill 412 212 627 416 212 628 minecraft:blackstone
fill 413 212 604 414 217 604 minecraft:black_concrete
fill 413 212 620 416 212 623 minecraft:blackstone
fill 414 212 646 415 213 646 minecraft:red_concrete
fill 415 212 604 416 213 604 minecraft:red_concrete
setblock 415 212 630 minecraft:blackstone
fill 416 212 646 417 217 646 minecraft:black_concrete
fill 417 212 604 417 213 604 minecraft:black_concrete
fill 418 212 607 418 217 608 minecraft:black_concrete
fill 418 212 609 418 212 610 minecraft:red_concrete
fill 418 212 611 418 217 611 minecraft:black_concrete
fill 418 212 619 418 217 620 minecraft:black_concrete
fill 418 212 621 418 213 622 minecraft:red_concrete
fill 418 212 623 418 213 626 minecraft:black_concrete
fill 418 212 628 418 217 628 minecraft:black_concrete
fill 418 212 629 418 212 630 minecraft:red_concrete
fill 418 212 631 418 213 632 minecraft:black_concrete
fill 418 212 633 418 213 633 minecraft:red_concrete
setblock 418 212 634 minecraft:black_concrete
fill 418 212 639 418 217 640 minecraft:black_concrete
fill 418 212 641 418 213 642 minecraft:red_concrete
fill 418 212 643 418 212 645 minecraft:black_concrete
setblock 418 212 646 minecraft:red_concrete
fill 376 213 604 376 216 604 minecraft:black_concrete
setblock 376 213 609 minecraft:red_concrete
fill 376 213 617 376 213 619 minecraft:black_concrete
setblock 376 213 620 minecraft:red_concrete
fill 376 213 624 376 216 625 minecraft:black_concrete
setblock 376 213 641 minecraft:red_concrete
setblock 376 213 644 minecraft:red_concrete
fill 376 213 645 376 216 645 minecraft:black_concrete
fill 378 213 646 381 213 646 minecraft:black_concrete
setblock 382 213 646 minecraft:red_concrete
fill 386 213 646 386 216 646 minecraft:black_concrete
fill 389 213 604 394 213 604 minecraft:black_concrete
setblock 396 213 604 minecraft:red_concrete
fill 397 213 604 402 213 604 minecraft:black_concrete
setblock 401 213 646 minecraft:black_concrete
fill 402 213 646 403 213 646 minecraft:red_concrete
fill 403 213 604 404 213 604 minecraft:red_concrete
setblock 404 213 646 minecraft:black_concrete
setblock 405 213 604 minecraft:black_concrete
setblock 406 213 646 minecraft:red_concrete
setblock 407 213 604 minecraft:red_concrete
fill 407 213 646 407 216 646 minecraft:black_concrete
fill 408 213 604 408 215 604 minecraft:black_concrete
fill 412 213 604 412 216 604 minecraft:black_concrete
fill 418 213 609 418 216 609 minecraft:black_concrete
setblock 418 213 610 minecraft:red_concrete
setblock 418 213 612 minecraft:black_concrete
fill 418 213 613 418 213 614 minecraft:red_concrete
fill 418 213 615 418 213 616 minecraft:black_concrete
fill 418 213 629 418 215 630 minecraft:black_concrete
setblock 418 213 634 minecraft:red_concrete
fill 418 213 643 418 213 644 minecraft:black_concrete
setblock 418 213 645 minecraft:red_concrete
fill 418 213 646 418 215 646 minecraft:black_concrete
fill 376 214 609 376 219 609 minecraft:black_concrete
fill 376 214 610 376 214 611 minecraft:red_concrete
fill 376 214 612 376 219 613 minecraft:black_concrete
fill 376 214 617 376 215 617 minecraft:black_concrete
fill 376 214 618 376 215 619 minecraft:red_concrete
fill 376 214 620 376 219 621 minecraft:black_concrete
setblock 376 214 622 minecraft:red_concrete
fill 376 214 630 376 215 631 minecraft:red_concrete
fill 376 214 632 376 219 633 minecraft:black_concrete
fill 376 214 639 376 215 639 minecraft:red_concrete
fill 376 214 640 376 215 641 minecraft:black_concrete
fill 376 214 642 376 214 643 minecraft:red_concrete
fill 376 214 644 376 219 644 minecraft:black_concrete
fill 377 214 604 377 215 604 minecraft:red_concrete
fill 378 214 646 379 215 646 minecraft:black_concrete
fill 380 214 646 381 215 646 minecraft:red_concrete
fill 382 214 646 383 219 646 minecraft:black_concrete
fill 383 214 604 384 219 604 minecraft:black_concrete
fill 385 214 604 386 215 604 minecraft:red_concrete
fill 389 214 604 393 214 604 minecraft:black_concrete
fill 391 214 646 391 215 646 minecraft:black_concrete
fill 392 214 646 393 214 646 minecraft:red_concrete
setblock 394 214 604 minecraft:red_concrete
fill 394 214 646 395 219 646 minecraft:black_concrete
fill 395 214 604 396 219 604 minecraft:black_concrete
fill 397 214 604 398 215 604 minecraft:red_concrete
fill 399 214 604 404 215 604 minecraft:black_concrete
fill 401 214 646 401 215 646 minecraft:red_concrete
fill 402 214 646 403 219 646 minecraft:black_concrete
setblock 404 214 646 minecraft:red_concrete
fill 405 214 604 406 214 604 minecraft:red_concrete
fill 406 214 646 406 219 646 minecraft:black_concrete
fill 407 214 604 407 219 604 minecraft:black_concrete
fill 408 214 646 411 215 646 minecraft:black_concrete
fill 412 214 646 413 215 646 minecraft:red_concrete
fill 414 214 646 415 219 646 minecraft:black_concrete
fill 415 214 604 416 219 604 minecraft:black_concrete
fill 417 214 604 418 215 604 minecraft:red_concrete
fill 418 214 610 418 219 610 minecraft:black_concrete
setblock 418 214 612 minecraft:red_concrete
fill 418 214 613 418 219 614 minecraft:black_concrete
fill 418 214 615 418 215 615 minecraft:red_concrete
setblock 418 214 616 minecraft:black_concrete
fill 418 214 621 418 219 622 minecraft:black_concrete
fill 418 214 623 418 215 624 minecraft:red_concrete
fill 418 214 625 418 215 626 minecraft:black_concrete
fill 418 214 631 418 217 631 minecraft:black_concrete
setblock 418 214 632 minecraft:red_concrete
fill 418 214 633 418 219 634 minecraft:black_concrete
fill 418 214 635 418 215 636 minecraft:red_concrete
fill 418 214 637 418 215 637 minecraft:black_concrete
fill 418 214 641 418 216 642 minecraft:black_concrete
fill 418 214 643 418 214 644 minecraft:red_concrete
fill 418 214 645 418 219 645 minecraft:black_concrete
fill 376 215 606 376 215 607 minecraft:red_concrete
setblock 376 215 608 minecraft:black_concrete
setblock 376 215 610 minecraft:red_concrete
fill 376 215 611 376 218 611 minecraft:black_concrete
fill 376 215 622 376 218 622 minecraft:black_concrete
setblock 376 215 627 minecraft:red_concrete
setblock 376 215 638 minecraft:red_concrete
fill 376 215 642 376 218 643 minecraft:black_concrete
setblock 378 215 604 minecraft:red_concrete
fill 379 215 604 380 215 604 minecraft:black_concrete
setblock 389 215 604 minecraft:red_concrete
setblock 389 215 646 minecraft:red_concrete
fill 390 215 604 394 216 604 minecraft:black_concrete
setblock 390 215 646 minecraft:black_concrete
setblock 392 215 646 minecraft:red_concrete
fill 393 215 646 393 218 646 minecraft:black_concrete
setblock 400 215 646 minecraft:red_concrete
fill 404 215 646 404 218 646 minecraft:black_concrete
fill 405 215 604 405 218 604 minecraft:black_concrete
setblock 406 215 604 minecraft:red_concrete
fill 409 215 604 410 215 604 minecraft:red_concrete
fill 418 215 612 418 218 612 minecraft:black_concrete
setblock 418 215 616 minecraft:red_concrete
setblock 418 215 627 minecraft:red_concrete
fill 418 215 632 418 217 632 minecraft:black_concrete
fill 418 215 643 418 218 643 minecraft:black_concrete
setblock 418 215 644 minecraft:red_concrete
fill 376 216 605 376 217 605 minecraft:red_concrete
fill 376 216 606 376 221 607 minecraft:black_concrete
setblock 376 216 608 minecraft:red_concrete
fill 376 216 610 376 221 610 minecraft:black_concrete
fill 376 216 616 376 217 617 minecraft:red_concrete
fill 376 216 618 376 221 619 minecraft:black_concrete
fill 376 216 627 376 221 627 minecraft:black_concrete
fill 376 216 628 376 216 629 minecraft:red_concrete
fill 376 216 630 376 221 631 minecraft:black_concrete
fill 376 216 636 376 217 637 minecraft:red_concrete
fill 376 216 638 376 221 639 minecraft:black_concrete
setblock 376 216 640 minecraft:red_concrete
fill 376 216 641 376 219 641 minecraft:black_concrete
fill 377 216 604 378 221 604 minecraft:black_concrete
fill 377 216 605 379 216 605 minecraft:polished_blackstone
fill 377 216 607 377 216 609 minecraft:polished_blackstone
fill 377 216 611 377 216 613 minecraft:polished_blackstone
fill 377 216 615 377 216 617 minecraft:polished_blackstone
fill 377 216 619 377 216 621 minecraft:polished_blackstone
fill 377 216 623 377 216 625 minecraft:polished_blackstone
fill 377 216 627 377 216 629 minecraft:polished_blackstone
fill 377 216 631 377 216 633 minecraft:polished_blackstone
fill 377 216 635 377 216 637 minecraft:polished_blackstone
fill 377 216 639 377 216 641 minecraft:polished_blackstone
fill 377 216 643 377 216 645 minecraft:polished_blackstone
fill 378 216 646 379 217 646 minecraft:red_concrete
fill 379 216 604 380 217 604 minecraft:red_concrete
schedule function dropper:buildpart/152_4 1t
