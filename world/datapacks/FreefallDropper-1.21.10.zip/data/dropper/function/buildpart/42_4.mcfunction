setblock 283 73 211 minecraft:polished_blackstone
fill 283 73 212 283 76 212 minecraft:red_nether_bricks
setblock 283 73 216 minecraft:polished_blackstone
setblock 283 73 221 minecraft:polished_blackstone
fill 283 73 222 286 73 222 minecraft:red_nether_bricks
setblock 284 73 185 minecraft:polished_blackstone
fill 284 73 186 284 75 186 minecraft:red_nether_bricks
setblock 284 73 190 minecraft:polished_blackstone
fill 284 73 191 284 76 191 minecraft:red_nether_bricks
setblock 284 73 210 minecraft:polished_blackstone
fill 284 73 211 284 76 211 minecraft:red_nether_bricks
setblock 284 73 215 minecraft:polished_blackstone
fill 284 73 216 285 75 216 minecraft:red_nether_bricks
fill 284 73 218 284 73 219 minecraft:red_nether_bricks
setblock 285 73 185 minecraft:red_nether_bricks
setblock 285 73 189 minecraft:polished_blackstone
fill 285 73 210 285 75 210 minecraft:red_nether_bricks
setblock 285 73 213 minecraft:red_nether_bricks
setblock 285 73 214 minecraft:polished_blackstone
fill 285 73 215 285 76 215 minecraft:red_nether_bricks
fill 285 73 221 287 73 221 minecraft:red_nether_bricks
fill 286 73 181 286 73 182 minecraft:red_nether_bricks
setblock 286 73 183 minecraft:polished_blackstone
setblock 286 73 184 minecraft:red_nether_bricks
fill 287 73 181 296 185 181 minecraft:red_nether_bricks
setblock 287 73 182 minecraft:polished_blackstone
fill 287 73 183 287 74 183 minecraft:red_nether_bricks
setblock 287 73 222 minecraft:polished_blackstone
fill 288 73 182 288 76 182 minecraft:red_nether_bricks
setblock 288 73 221 minecraft:polished_blackstone
fill 288 73 222 288 76 222 minecraft:red_nether_bricks
setblock 289 73 220 minecraft:polished_blackstone
fill 289 73 221 289 76 221 minecraft:red_nether_bricks
setblock 291 73 183 minecraft:polished_blackstone
fill 291 73 223 291 190 223 minecraft:red_nether_bricks
setblock 292 73 182 minecraft:polished_blackstone
setblock 292 73 221 minecraft:red_nether_bricks
setblock 292 73 222 minecraft:polished_blackstone
setblock 293 73 182 minecraft:red_nether_bricks
fill 293 73 222 293 74 222 minecraft:red_nether_bricks
fill 296 73 223 307 185 223 minecraft:red_nether_bricks
setblock 297 73 181 minecraft:blackstone
fill 298 73 181 300 185 181 minecraft:red_nether_bricks
setblock 301 73 181 minecraft:blackstone
setblock 306 73 182 minecraft:red_nether_bricks
setblock 307 73 182 minecraft:polished_blackstone
fill 308 73 182 308 74 182 minecraft:red_nether_bricks
setblock 308 73 223 minecraft:blackstone
fill 309 73 181 309 189 181 minecraft:red_nether_bricks
fill 309 73 223 316 185 223 minecraft:red_nether_bricks
setblock 311 73 183 minecraft:polished_blackstone
fill 311 73 184 312 93 184 minecraft:gilded_blackstone
setblock 312 73 182 minecraft:polished_blackstone
setblock 312 73 183 minecraft:red_nether_bricks
setblock 313 73 182 minecraft:red_nether_bricks
fill 316 73 181 316 187 181 minecraft:red_nether_bricks
setblock 317 73 181 minecraft:blackstone
setblock 317 73 223 minecraft:blackstone
fill 318 73 181 320 186 181 minecraft:red_nether_bricks
fill 318 73 223 318 187 223 minecraft:red_nether_bricks
setblock 321 73 181 minecraft:blackstone
setblock 321 73 188 minecraft:polished_blackstone
setblock 321 73 189 minecraft:red_nether_bricks
fill 322 73 181 324 187 181 minecraft:red_nether_bricks
setblock 322 73 182 minecraft:polished_blackstone
setblock 322 73 186 minecraft:red_nether_bricks
setblock 322 73 187 minecraft:polished_blackstone
fill 322 73 188 323 75 188 minecraft:red_nether_bricks
setblock 322 73 191 minecraft:red_nether_bricks
setblock 322 73 192 minecraft:polished_blackstone
fill 322 73 193 322 76 193 minecraft:red_nether_bricks
fill 323 73 182 323 76 182 minecraft:red_nether_bricks
setblock 323 73 186 minecraft:polished_blackstone
fill 323 73 187 323 76 187 minecraft:red_nether_bricks
setblock 323 73 191 minecraft:polished_blackstone
fill 323 73 192 323 76 192 minecraft:red_nether_bricks
setblock 323 73 196 minecraft:polished_blackstone
setblock 323 73 210 minecraft:red_nether_bricks
setblock 323 73 211 minecraft:polished_blackstone
fill 323 73 212 323 76 212 minecraft:red_nether_bricks
setblock 323 73 215 minecraft:red_nether_bricks
setblock 324 73 182 minecraft:blackstone
setblock 324 73 188 minecraft:blackstone
fill 324 73 203 324 185 204 minecraft:red_nether_bricks
setblock 324 73 205 minecraft:blackstone
fill 324 73 206 324 186 208 minecraft:red_nether_bricks
fill 324 73 216 324 185 217 minecraft:red_nether_bricks
fill 324 73 218 324 73 219 minecraft:blackstone
fill 324 73 220 324 73 222 minecraft:red_nether_bricks
fill 282 74 191 283 77 191 minecraft:red_nether_bricks
setblock 282 74 192 minecraft:blackstone
fill 282 74 208 282 189 208 minecraft:red_nether_bricks
fill 282 74 213 282 185 213 minecraft:red_nether_bricks
fill 282 74 214 282 74 215 minecraft:blackstone
fill 282 74 223 287 189 223 minecraft:red_nether_bricks
fill 283 74 181 284 74 183 minecraft:red_nether_bricks
setblock 283 74 185 minecraft:polished_blackstone
fill 283 74 186 283 77 186 minecraft:red_nether_bricks
setblock 283 74 190 minecraft:polished_blackstone
setblock 283 74 210 minecraft:polished_blackstone
fill 283 74 211 283 77 211 minecraft:red_nether_bricks
setblock 283 74 214 minecraft:red_nether_bricks
setblock 283 74 215 minecraft:polished_blackstone
fill 283 74 216 283 77 216 minecraft:red_nether_bricks
setblock 283 74 219 minecraft:red_nether_bricks
setblock 283 74 220 minecraft:polished_blackstone
fill 283 74 221 285 74 222 minecraft:red_nether_bricks
setblock 284 74 184 minecraft:polished_blackstone
fill 284 74 185 284 75 185 minecraft:red_nether_bricks
setblock 284 74 189 minecraft:polished_blackstone
fill 284 74 190 284 77 190 minecraft:red_nether_bricks
setblock 284 74 209 minecraft:polished_blackstone
fill 284 74 210 284 77 210 minecraft:red_nether_bricks
setblock 284 74 214 minecraft:polished_blackstone
fill 284 74 215 284 77 215 minecraft:red_nether_bricks
setblock 284 74 218 minecraft:red_nether_bricks
setblock 284 74 219 minecraft:polished_blackstone
fill 284 74 220 284 77 220 minecraft:red_nether_bricks
fill 285 74 181 285 74 182 minecraft:red_nether_bricks
setblock 285 74 183 minecraft:polished_blackstone
setblock 285 74 213 minecraft:polished_blackstone
fill 285 74 214 285 77 214 minecraft:red_nether_bricks
setblock 285 74 217 minecraft:red_nether_bricks
fill 286 74 181 286 189 181 minecraft:red_nether_bricks
setblock 286 74 182 minecraft:polished_blackstone
setblock 286 74 183 minecraft:red_nether_bricks
fill 286 74 213 286 76 213 minecraft:red_nether_bricks
setblock 286 74 221 minecraft:red_nether_bricks
setblock 286 74 222 minecraft:polished_blackstone
fill 287 74 182 287 77 182 minecraft:red_nether_bricks
setblock 287 74 221 minecraft:polished_blackstone
fill 287 74 222 287 77 222 minecraft:red_nether_bricks
fill 288 74 221 288 77 221 minecraft:red_nether_bricks
setblock 288 74 223 minecraft:blackstone
fill 289 74 223 290 189 223 minecraft:red_nether_bricks
setblock 290 74 222 minecraft:red_nether_bricks
setblock 291 74 182 minecraft:polished_blackstone
setblock 291 74 222 minecraft:polished_blackstone
fill 292 74 222 292 75 222 minecraft:red_nether_bricks
fill 297 74 181 297 189 181 minecraft:red_nether_bricks
fill 301 74 181 302 189 181 minecraft:red_nether_bricks
setblock 307 74 182 minecraft:red_nether_bricks
fill 308 74 223 308 189 223 minecraft:red_nether_bricks
setblock 310 74 181 minecraft:blackstone
fill 311 74 181 315 185 181 minecraft:red_nether_bricks
setblock 311 74 182 minecraft:polished_blackstone
setblock 312 74 182 minecraft:red_nether_bricks
fill 312 74 183 312 87 183 minecraft:gilded_blackstone
fill 317 74 181 317 189 181 minecraft:red_nether_bricks
fill 317 74 223 317 185 223 minecraft:red_nether_bricks
fill 319 74 223 319 189 223 minecraft:red_nether_bricks
fill 321 74 181 321 189 181 minecraft:red_nether_bricks
setblock 321 74 182 minecraft:polished_blackstone
fill 322 74 182 322 77 182 minecraft:red_nether_bricks
setblock 322 74 186 minecraft:polished_blackstone
fill 322 74 187 322 77 187 minecraft:red_nether_bricks
setblock 322 74 191 minecraft:polished_blackstone
fill 322 74 192 322 77 192 minecraft:red_nether_bricks
fill 322 74 194 322 75 194 minecraft:red_nether_bricks
setblock 323 74 185 minecraft:polished_blackstone
fill 323 74 186 323 77 186 minecraft:red_nether_bricks
setblock 323 74 190 minecraft:polished_blackstone
fill 323 74 191 323 77 191 minecraft:red_nether_bricks
setblock 323 74 195 minecraft:polished_blackstone
fill 323 74 196 323 77 196 minecraft:red_nether_bricks
setblock 323 74 210 minecraft:polished_blackstone
fill 323 74 211 323 77 211 minecraft:red_nether_bricks
fill 323 74 213 323 74 214 minecraft:red_nether_bricks
setblock 323 74 215 minecraft:polished_blackstone
fill 323 74 216 323 77 216 minecraft:red_nether_bricks
fill 324 74 182 324 190 182 minecraft:red_nether_bricks
fill 324 74 188 324 189 188 minecraft:red_nether_bricks
fill 324 74 205 324 186 205 minecraft:red_nether_bricks
setblock 324 74 213 minecraft:blackstone
fill 324 74 214 324 189 214 minecraft:red_nether_bricks
fill 324 74 218 324 189 219 minecraft:red_nether_bricks
setblock 324 74 220 minecraft:blackstone
fill 324 74 221 324 189 222 minecraft:red_nether_bricks
fill 282 75 192 282 185 192 minecraft:red_nether_bricks
fill 282 75 206 282 189 206 minecraft:red_nether_bricks
fill 282 75 214 282 187 216 minecraft:red_nether_bricks
fill 282 75 218 282 189 218 minecraft:red_nether_bricks
fill 283 75 181 283 75 183 minecraft:red_nether_bricks
setblock 283 75 184 minecraft:polished_blackstone
fill 283 75 185 283 78 185 minecraft:red_nether_bricks
setblock 283 75 189 minecraft:polished_blackstone
fill 283 75 190 283 78 190 minecraft:red_nether_bricks
setblock 283 75 193 minecraft:red_nether_bricks
setblock 283 75 194 minecraft:polished_blackstone
fill 283 75 195 283 78 195 minecraft:red_nether_bricks
setblock 283 75 209 minecraft:polished_blackstone
fill 283 75 210 283 78 210 minecraft:red_nether_bricks
setblock 283 75 214 minecraft:polished_blackstone
fill 283 75 215 283 78 215 minecraft:red_nether_bricks
setblock 283 75 219 minecraft:polished_blackstone
fill 283 75 220 283 76 222 minecraft:red_nether_bricks
fill 284 75 181 284 75 182 minecraft:red_nether_bricks
setblock 284 75 188 minecraft:polished_blackstone
fill 284 75 189 284 77 189 minecraft:red_nether_bricks
fill 284 75 209 284 78 209 minecraft:red_nether_bricks
setblock 284 75 212 minecraft:red_nether_bricks
setblock 284 75 213 minecraft:polished_blackstone
fill 284 75 214 284 78 214 minecraft:red_nether_bricks
setblock 284 75 218 minecraft:polished_blackstone
fill 284 75 219 284 78 219 minecraft:red_nether_bricks
fill 284 75 221 284 75 222 minecraft:red_nether_bricks
fill 285 75 181 285 189 181 minecraft:red_nether_bricks
setblock 285 75 182 minecraft:polished_blackstone
setblock 285 75 212 minecraft:polished_blackstone
fill 285 75 213 285 78 213 minecraft:red_nether_bricks
setblock 285 75 217 minecraft:polished_blackstone
fill 285 75 218 285 78 218 minecraft:red_nether_bricks
setblock 285 75 221 minecraft:red_nether_bricks
setblock 285 75 222 minecraft:polished_blackstone
fill 286 75 182 286 78 182 minecraft:red_nether_bricks
fill 286 75 214 286 76 214 minecraft:red_nether_bricks
setblock 286 75 221 minecraft:polished_blackstone
fill 286 75 222 286 78 222 minecraft:red_nether_bricks
fill 287 75 221 287 78 221 minecraft:red_nether_bricks
fill 288 75 223 288 189 223 minecraft:red_nether_bricks
setblock 290 75 182 minecraft:polished_blackstone
setblock 290 75 222 minecraft:polished_blackstone
fill 291 75 222 291 77 222 minecraft:red_nether_bricks
fill 310 75 181 310 190 181 minecraft:red_nether_bricks
setblock 310 75 182 minecraft:polished_blackstone
setblock 322 75 185 minecraft:polished_blackstone
fill 322 75 186 322 76 186 minecraft:red_nether_bricks
setblock 322 75 190 minecraft:polished_blackstone
fill 322 75 191 322 78 191 minecraft:red_nether_bricks
setblock 323 75 184 minecraft:polished_blackstone
fill 323 75 185 323 78 185 minecraft:red_nether_bricks
setblock 323 75 189 minecraft:polished_blackstone
fill 323 75 190 323 78 190 minecraft:red_nether_bricks
setblock 323 75 194 minecraft:polished_blackstone
fill 323 75 195 323 78 195 minecraft:red_nether_bricks
fill 323 75 210 323 76 210 minecraft:red_nether_bricks
fill 323 75 213 324 75 213 minecraft:red_nether_bricks
setblock 323 75 214 minecraft:polished_blackstone
fill 323 75 215 323 78 215 minecraft:red_nether_bricks
fill 323 75 217 323 75 218 minecraft:red_nether_bricks
fill 324 75 220 324 185 220 minecraft:red_nether_bricks
fill 282 76 207 282 185 207 minecraft:red_nether_bricks
fill 283 76 181 283 76 182 minecraft:red_nether_bricks
setblock 283 76 183 minecraft:polished_blackstone
fill 283 76 184 283 79 184 minecraft:red_nether_bricks
setblock 283 76 188 minecraft:polished_blackstone
fill 283 76 189 283 79 189 minecraft:red_nether_bricks
setblock 283 76 193 minecraft:polished_blackstone
fill 283 76 194 283 79 194 minecraft:red_nether_bricks
setblock 283 76 208 minecraft:polished_blackstone
fill 283 76 209 283 79 209 minecraft:red_nether_bricks
setblock 283 76 213 minecraft:polished_blackstone
fill 283 76 214 283 79 214 minecraft:red_nether_bricks
setblock 283 76 218 minecraft:polished_blackstone
fill 283 76 219 283 79 219 minecraft:red_nether_bricks
fill 284 76 181 284 187 181 minecraft:red_nether_bricks
setblock 284 76 182 minecraft:polished_blackstone
setblock 284 76 187 minecraft:polished_blackstone
setblock 284 76 188 minecraft:red_nether_bricks
setblock 284 76 192 minecraft:polished_blackstone
setblock 284 76 212 minecraft:polished_blackstone
fill 284 76 213 284 79 213 minecraft:red_nether_bricks
setblock 284 76 216 minecraft:red_nether_bricks
setblock 284 76 217 minecraft:polished_blackstone
fill 284 76 218 284 79 218 minecraft:red_nether_bricks
setblock 284 76 221 minecraft:red_nether_bricks
setblock 284 76 222 minecraft:polished_blackstone
fill 285 76 182 285 79 182 minecraft:red_nether_bricks
setblock 285 76 184 minecraft:light[level=14]
setblock 285 76 192 minecraft:light[level=14]
setblock 285 76 200 minecraft:light[level=14]
setblock 285 76 208 minecraft:light[level=14]
setblock 285 76 211 minecraft:polished_blackstone
fill 285 76 212 285 79 212 minecraft:red_nether_bricks
setblock 285 76 216 minecraft:polished_blackstone
fill 285 76 217 285 79 217 minecraft:red_nether_bricks
setblock 285 76 221 minecraft:polished_blackstone
fill 285 76 222 285 79 222 minecraft:red_nether_bricks
setblock 286 76 215 minecraft:polished_blackstone
fill 286 76 221 286 79 221 minecraft:red_nether_bricks
setblock 289 76 222 minecraft:polished_blackstone
fill 290 76 222 290 79 222 minecraft:red_nether_bricks
setblock 293 76 184 minecraft:light[level=14]
setblock 293 76 192 minecraft:light[level=14]
setblock 293 76 200 minecraft:light[level=14]
setblock 293 76 208 minecraft:light[level=14]
setblock 293 76 216 minecraft:light[level=14]
setblock 301 76 184 minecraft:light[level=14]
setblock 301 76 192 minecraft:light[level=14]
setblock 301 76 200 minecraft:light[level=14]
setblock 301 76 208 minecraft:light[level=14]
setblock 301 76 216 minecraft:light[level=14]
setblock 309 76 184 minecraft:light[level=14]
setblock 309 76 192 minecraft:light[level=14]
setblock 309 76 200 minecraft:light[level=14]
setblock 309 76 208 minecraft:light[level=14]
setblock 309 76 216 minecraft:light[level=14]
setblock 311 76 183 minecraft:polished_blackstone
setblock 311 76 185 minecraft:polished_blackstone
setblock 313 76 183 minecraft:polished_blackstone
setblock 313 76 185 minecraft:polished_blackstone
setblock 317 76 184 minecraft:light[level=14]
setblock 317 76 192 minecraft:light[level=14]
setblock 317 76 200 minecraft:light[level=14]
setblock 317 76 208 minecraft:light[level=14]
setblock 317 76 216 minecraft:light[level=14]
setblock 322 76 188 minecraft:red_nether_bricks
setblock 322 76 189 minecraft:polished_blackstone
fill 322 76 190 322 79 190 minecraft:red_nether_bricks
setblock 322 76 194 minecraft:polished_blackstone
setblock 323 76 183 minecraft:polished_blackstone
fill 323 76 184 323 79 184 minecraft:red_nether_bricks
setblock 323 76 188 minecraft:polished_blackstone
fill 323 76 189 323 79 189 minecraft:red_nether_bricks
setblock 323 76 193 minecraft:polished_blackstone
fill 323 76 194 323 79 194 minecraft:red_nether_bricks
setblock 323 76 197 minecraft:red_nether_bricks
setblock 323 76 213 minecraft:polished_blackstone
fill 323 76 214 323 79 214 minecraft:red_nether_bricks
setblock 323 76 217 minecraft:red_nether_bricks
setblock 323 76 218 minecraft:polished_blackstone
fill 323 76 219 323 79 219 minecraft:red_nether_bricks
fill 324 76 183 324 189 183 minecraft:red_nether_bricks
fill 324 76 193 324 185 193 minecraft:red_nether_bricks
fill 324 76 213 324 189 213 minecraft:red_nether_bricks
fill 282 77 217 282 189 217 minecraft:red_nether_bricks
fill 283 77 181 283 189 181 minecraft:red_nether_bricks
setblock 283 77 182 minecraft:polished_blackstone
fill 283 77 183 283 80 183 minecraft:red_nether_bricks
setblock 283 77 187 minecraft:polished_blackstone
fill 283 77 188 283 80 188 minecraft:red_nether_bricks
setblock 283 77 192 minecraft:polished_blackstone
fill 283 77 193 284 79 193 minecraft:red_nether_bricks
setblock 283 77 196 minecraft:red_nether_bricks
fill 283 77 208 283 80 208 minecraft:red_nether_bricks
setblock 283 77 212 minecraft:polished_blackstone
fill 283 77 213 283 80 213 minecraft:red_nether_bricks
setblock 283 77 217 minecraft:polished_blackstone
fill 283 77 218 283 80 218 minecraft:red_nether_bricks
fill 283 77 220 283 77 221 minecraft:red_nether_bricks
setblock 283 77 222 minecraft:polished_blackstone
fill 284 77 182 284 80 182 minecraft:red_nether_bricks
setblock 284 77 191 minecraft:polished_blackstone
fill 284 77 192 284 80 192 minecraft:red_nether_bricks
setblock 284 77 211 minecraft:polished_blackstone
fill 284 77 212 284 80 212 minecraft:red_nether_bricks
setblock 284 77 216 minecraft:polished_blackstone
fill 284 77 217 284 80 217 minecraft:red_nether_bricks
setblock 284 77 221 minecraft:polished_blackstone
fill 284 77 222 284 80 222 minecraft:red_nether_bricks
fill 285 77 211 285 80 211 minecraft:red_nether_bricks
setblock 285 77 215 minecraft:polished_blackstone
fill 285 77 216 286 79 216 minecraft:red_nether_bricks
setblock 285 77 219 minecraft:red_nether_bricks
fill 285 77 221 285 80 221 minecraft:red_nether_bricks
setblock 286 77 214 minecraft:polished_blackstone
fill 286 77 215 286 80 215 minecraft:red_nether_bricks
setblock 288 77 222 minecraft:polished_blackstone
setblock 289 77 221 minecraft:polished_blackstone
fill 289 77 222 289 80 222 minecraft:red_nether_bricks
setblock 322 77 188 minecraft:polished_blackstone
fill 322 77 189 322 80 189 minecraft:red_nether_bricks
setblock 322 77 193 minecraft:polished_blackstone
fill 322 77 194 322 80 194 minecraft:red_nether_bricks
setblock 323 77 182 minecraft:polished_blackstone
fill 323 77 183 323 80 183 minecraft:red_nether_bricks
setblock 323 77 187 minecraft:polished_blackstone
fill 323 77 188 323 80 188 minecraft:red_nether_bricks
setblock 323 77 192 minecraft:polished_blackstone
fill 323 77 193 323 80 193 minecraft:red_nether_bricks
setblock 323 77 197 minecraft:polished_blackstone
setblock 323 77 212 minecraft:polished_blackstone
fill 323 77 213 323 80 213 minecraft:red_nether_bricks
setblock 323 77 217 minecraft:polished_blackstone
fill 323 77 218 323 80 218 minecraft:red_nether_bricks
fill 323 77 220 323 77 221 minecraft:red_nether_bricks
setblock 323 77 222 minecraft:polished_blackstone
fill 282 78 191 282 189 191 minecraft:red_nether_bricks
fill 283 78 182 283 81 182 minecraft:red_nether_bricks
setblock 283 78 186 minecraft:polished_blackstone
fill 283 78 187 283 81 187 minecraft:red_nether_bricks
setblock 283 78 191 minecraft:polished_blackstone
fill 283 78 192 283 81 192 minecraft:red_nether_bricks
setblock 283 78 196 minecraft:polished_blackstone
fill 283 78 197 283 81 197 minecraft:red_nether_bricks
setblock 283 78 211 minecraft:polished_blackstone
fill 283 78 212 283 81 212 minecraft:red_nether_bricks
setblock 283 78 216 minecraft:polished_blackstone
fill 283 78 217 283 81 217 minecraft:red_nether_bricks
setblock 283 78 220 minecraft:red_nether_bricks
setblock 283 78 221 minecraft:polished_blackstone
fill 283 78 222 283 81 222 minecraft:red_nether_bricks
setblock 284 78 190 minecraft:polished_blackstone
fill 284 78 191 284 81 191 minecraft:red_nether_bricks
setblock 284 78 210 minecraft:polished_blackstone
fill 284 78 211 284 81 211 minecraft:red_nether_bricks
setblock 284 78 215 minecraft:polished_blackstone
fill 284 78 216 284 81 216 minecraft:red_nether_bricks
setblock 284 78 220 minecraft:polished_blackstone
fill 284 78 221 284 81 221 minecraft:red_nether_bricks
setblock 285 78 214 minecraft:polished_blackstone
fill 285 78 215 285 81 215 minecraft:red_nether_bricks
setblock 285 78 219 minecraft:polished_blackstone
fill 285 78 220 287 79 220 minecraft:red_nether_bricks
fill 286 78 214 286 81 214 minecraft:red_nether_bricks
setblock 286 78 217 minecraft:red_nether_bricks
setblock 287 78 222 minecraft:polished_blackstone
setblock 288 78 221 minecraft:polished_blackstone
fill 288 78 222 288 81 222 minecraft:red_nether_bricks
fill 289 78 221 289 81 221 minecraft:red_nether_bricks
fill 292 78 203 293 79 204 minecraft:blackstone
fill 299 78 217 299 78 219 minecraft:polished_blackstone
fill 300 78 217 301 78 217 minecraft:polished_blackstone
fill 300 78 219 301 78 219 minecraft:polished_blackstone
setblock 301 78 218 minecraft:polished_blackstone
setblock 322 78 182 minecraft:polished_blackstone
setblock 322 78 187 minecraft:polished_blackstone
fill 322 78 188 322 81 188 minecraft:red_nether_bricks
setblock 322 78 192 minecraft:polished_blackstone
fill 322 78 193 322 81 193 minecraft:red_nether_bricks
fill 322 78 195 322 79 195 minecraft:red_nether_bricks
setblock 322 78 222 minecraft:polished_blackstone
fill 323 78 182 323 81 182 minecraft:red_nether_bricks
setblock 323 78 186 minecraft:polished_blackstone
fill 323 78 187 323 81 187 minecraft:red_nether_bricks
setblock 323 78 191 minecraft:polished_blackstone
fill 323 78 192 323 81 192 minecraft:red_nether_bricks
setblock 323 78 196 minecraft:polished_blackstone
fill 323 78 197 323 80 198 minecraft:red_nether_bricks
setblock 323 78 211 minecraft:polished_blackstone
fill 323 78 212 323 81 212 minecraft:red_nether_bricks
setblock 323 78 216 minecraft:polished_blackstone
fill 323 78 217 323 81 217 minecraft:red_nether_bricks
setblock 323 78 220 minecraft:red_nether_bricks
setblock 323 78 221 minecraft:polished_blackstone
fill 323 78 222 323 81 222 minecraft:red_nether_bricks
setblock 283 79 185 minecraft:polished_blackstone
fill 283 79 186 283 82 186 minecraft:red_nether_bricks
setblock 283 79 190 minecraft:polished_blackstone
fill 283 79 191 283 82 191 minecraft:red_nether_bricks
setblock 283 79 195 minecraft:polished_blackstone
fill 283 79 196 283 82 196 minecraft:red_nether_bricks
fill 283 79 198 283 80 198 minecraft:red_nether_bricks
setblock 283 79 210 minecraft:polished_blackstone
fill 283 79 211 283 82 211 minecraft:red_nether_bricks
setblock 283 79 215 minecraft:polished_blackstone
fill 283 79 216 283 82 216 minecraft:red_nether_bricks
setblock 283 79 220 minecraft:polished_blackstone
fill 283 79 221 283 82 221 minecraft:red_nether_bricks
setblock 284 79 194 minecraft:polished_blackstone
fill 284 79 195 284 82 195 minecraft:red_nether_bricks
setblock 284 79 209 minecraft:polished_blackstone
fill 284 79 210 284 82 210 minecraft:red_nether_bricks
setblock 284 79 214 minecraft:polished_blackstone
fill 284 79 215 284 82 215 minecraft:red_nether_bricks
setblock 284 79 219 minecraft:polished_blackstone
fill 284 79 220 284 82 220 minecraft:red_nether_bricks
setblock 285 79 213 minecraft:polished_blackstone
fill 285 79 214 285 82 214 minecraft:red_nether_bricks
setblock 285 79 218 minecraft:polished_blackstone
fill 285 79 219 285 82 219 minecraft:red_nether_bricks
setblock 286 79 182 minecraft:polished_blackstone
setblock 286 79 217 minecraft:polished_blackstone
fill 286 79 218 286 82 218 minecraft:red_nether_bricks
setblock 286 79 222 minecraft:polished_blackstone
setblock 287 79 221 minecraft:polished_blackstone
fill 287 79 222 287 82 222 minecraft:red_nether_bricks
fill 288 79 221 288 82 221 minecraft:red_nether_bricks
setblock 321 79 182 minecraft:polished_blackstone
setblock 321 79 222 minecraft:polished_blackstone
fill 322 79 182 322 82 182 minecraft:red_nether_bricks
fill 322 79 187 322 82 187 minecraft:red_nether_bricks
setblock 322 79 191 minecraft:polished_blackstone
fill 322 79 192 322 82 192 minecraft:red_nether_bricks
setblock 322 79 196 minecraft:polished_blackstone
setblock 322 79 215 minecraft:red_nether_bricks
setblock 322 79 216 minecraft:polished_blackstone
fill 322 79 217 322 80 219 minecraft:red_nether_bricks
fill 322 79 222 322 82 222 minecraft:red_nether_bricks
setblock 323 79 185 minecraft:polished_blackstone
fill 323 79 186 323 82 186 minecraft:red_nether_bricks
setblock 323 79 190 minecraft:polished_blackstone
fill 323 79 191 323 82 191 minecraft:red_nether_bricks
setblock 323 79 195 minecraft:polished_blackstone
fill 323 79 196 323 82 196 minecraft:red_nether_bricks
setblock 323 79 199 minecraft:red_nether_bricks
setblock 323 79 210 minecraft:polished_blackstone
fill 323 79 211 323 82 211 minecraft:red_nether_bricks
setblock 323 79 215 minecraft:polished_blackstone
fill 323 79 216 323 82 216 minecraft:red_nether_bricks
setblock 323 79 220 minecraft:polished_blackstone
fill 323 79 221 323 82 221 minecraft:red_nether_bricks
setblock 283 80 184 minecraft:polished_blackstone
fill 283 80 185 283 83 185 minecraft:red_nether_bricks
setblock 283 80 189 minecraft:polished_blackstone
fill 283 80 190 283 83 190 minecraft:red_nether_bricks
setblock 283 80 193 minecraft:red_nether_bricks
setblock 283 80 194 minecraft:polished_blackstone
fill 283 80 195 283 83 195 minecraft:red_nether_bricks
setblock 283 80 199 minecraft:polished_blackstone
fill 283 80 200 283 83 200 minecraft:red_nether_bricks
fill 283 80 207 283 81 207 minecraft:red_nether_bricks
setblock 283 80 209 minecraft:polished_blackstone
fill 283 80 210 283 83 210 minecraft:red_nether_bricks
setblock 283 80 214 minecraft:polished_blackstone
fill 283 80 215 283 83 215 minecraft:red_nether_bricks
setblock 283 80 219 minecraft:polished_blackstone
fill 283 80 220 283 83 220 minecraft:red_nether_bricks
setblock 284 80 193 minecraft:polished_blackstone
fill 284 80 194 284 83 194 minecraft:red_nether_bricks
fill 284 80 196 284 80 197 minecraft:red_nether_bricks
fill 284 80 209 284 83 209 minecraft:red_nether_bricks
setblock 284 80 213 minecraft:polished_blackstone
fill 284 80 214 284 83 214 minecraft:red_nether_bricks
setblock 284 80 218 minecraft:polished_blackstone
fill 284 80 219 284 83 219 minecraft:red_nether_bricks
setblock 285 80 182 minecraft:polished_blackstone
setblock 285 80 212 minecraft:polished_blackstone
fill 285 80 213 285 83 213 minecraft:red_nether_bricks
setblock 285 80 216 minecraft:red_nether_bricks
setblock 285 80 217 minecraft:polished_blackstone
fill 285 80 218 285 83 218 minecraft:red_nether_bricks
fill 285 80 220 286 80 220 minecraft:red_nether_bricks
setblock 285 80 222 minecraft:polished_blackstone
fill 286 80 182 286 83 182 minecraft:red_nether_bricks
setblock 286 80 216 minecraft:polished_blackstone
fill 286 80 217 286 83 217 minecraft:red_nether_bricks
fill 286 80 219 286 81 219 minecraft:red_nether_bricks
setblock 286 80 221 minecraft:polished_blackstone
fill 286 80 222 286 83 222 minecraft:red_nether_bricks
setblock 287 80 220 minecraft:polished_blackstone
fill 287 80 221 287 83 221 minecraft:red_nether_bricks
fill 288 80 220 288 83 220 minecraft:red_nether_bricks
setblock 290 80 222 minecraft:polished_blackstone
fill 291 80 222 291 83 222 minecraft:red_nether_bricks
setblock 304 80 222 minecraft:red_nether_bricks
setblock 305 80 222 minecraft:polished_blackstone
setblock 320 80 182 minecraft:polished_blackstone
setblock 320 80 222 minecraft:polished_blackstone
fill 321 80 182 321 83 182 minecraft:red_nether_bricks
fill 321 80 222 321 83 222 minecraft:red_nether_bricks
setblock 322 80 190 minecraft:polished_blackstone
fill 322 80 191 322 83 191 minecraft:red_nether_bricks
setblock 322 80 195 minecraft:polished_blackstone
fill 322 80 196 322 82 197 minecraft:red_nether_bricks
setblock 322 80 214 minecraft:red_nether_bricks
setblock 322 80 215 minecraft:polished_blackstone
fill 322 80 216 322 83 216 minecraft:red_nether_bricks
setblock 322 80 220 minecraft:polished_blackstone
fill 322 80 221 322 83 221 minecraft:red_nether_bricks
setblock 323 80 184 minecraft:polished_blackstone
fill 323 80 185 323 83 185 minecraft:red_nether_bricks
setblock 323 80 189 minecraft:polished_blackstone
fill 323 80 190 323 83 190 minecraft:red_nether_bricks
setblock 323 80 194 minecraft:polished_blackstone
fill 323 80 195 323 83 195 minecraft:red_nether_bricks
setblock 323 80 199 minecraft:polished_blackstone
fill 323 80 200 323 83 200 minecraft:red_nether_bricks
fill 323 80 210 323 83 210 minecraft:red_nether_bricks
setblock 323 80 214 minecraft:polished_blackstone
fill 323 80 215 323 83 215 minecraft:red_nether_bricks
setblock 323 80 219 minecraft:polished_blackstone
fill 323 80 220 323 83 220 minecraft:red_nether_bricks
setblock 283 81 183 minecraft:polished_blackstone
fill 283 81 184 283 84 184 minecraft:red_nether_bricks
setblock 283 81 188 minecraft:polished_blackstone
fill 283 81 189 283 84 189 minecraft:red_nether_bricks
setblock 283 81 193 minecraft:polished_blackstone
fill 283 81 194 283 84 194 minecraft:red_nether_bricks
setblock 283 81 198 minecraft:polished_blackstone
fill 283 81 199 284 83 199 minecraft:red_nether_bricks
fill 283 81 201 283 81 202 minecraft:red_nether_bricks
setblock 283 81 203 minecraft:polished_blackstone
fill 283 81 204 283 82 206 minecraft:red_nether_bricks
setblock 283 81 208 minecraft:polished_blackstone
fill 283 81 209 283 84 209 minecraft:red_nether_bricks
setblock 283 81 213 minecraft:polished_blackstone
fill 283 81 214 283 84 214 minecraft:red_nether_bricks
setblock 283 81 218 minecraft:polished_blackstone
fill 283 81 219 283 84 219 minecraft:red_nether_bricks
setblock 284 81 182 minecraft:polished_blackstone
setblock 284 81 192 minecraft:polished_blackstone
fill 284 81 193 284 84 193 minecraft:red_nether_bricks
setblock 284 81 196 minecraft:red_nether_bricks
setblock 284 81 197 minecraft:polished_blackstone
fill 284 81 198 284 84 198 minecraft:red_nether_bricks
setblock 284 81 212 minecraft:polished_blackstone
fill 284 81 213 284 84 213 minecraft:red_nether_bricks
setblock 284 81 217 minecraft:polished_blackstone
fill 284 81 218 284 84 218 minecraft:red_nether_bricks
setblock 284 81 222 minecraft:polished_blackstone
fill 285 81 182 285 84 182 minecraft:red_nether_bricks
setblock 285 81 211 minecraft:polished_blackstone
fill 285 81 212 285 84 212 minecraft:red_nether_bricks
setblock 285 81 216 minecraft:polished_blackstone
fill 285 81 217 285 84 217 minecraft:red_nether_bricks
setblock 285 81 220 minecraft:red_nether_bricks
setblock 285 81 221 minecraft:polished_blackstone
fill 285 81 222 285 84 222 minecraft:red_nether_bricks
setblock 286 81 215 minecraft:polished_blackstone
fill 286 81 216 286 84 216 minecraft:red_nether_bricks
setblock 286 81 220 minecraft:polished_blackstone
fill 286 81 221 286 84 221 minecraft:red_nether_bricks
setblock 287 81 219 minecraft:polished_blackstone
fill 287 81 220 287 84 220 minecraft:red_nether_bricks
setblock 289 81 222 minecraft:polished_blackstone
setblock 290 81 221 minecraft:polished_blackstone
fill 290 81 222 290 84 222 minecraft:red_nether_bricks
fill 301 81 222 303 81 222 minecraft:red_nether_bricks
setblock 304 81 182 minecraft:polished_blackstone
setblock 304 81 222 minecraft:polished_blackstone
fill 305 81 182 308 81 182 minecraft:red_nether_bricks
fill 305 81 222 307 82 222 minecraft:red_nether_bricks
setblock 318 81 182 minecraft:red_nether_bricks
setblock 318 81 222 minecraft:red_nether_bricks
setblock 319 81 182 minecraft:polished_blackstone
setblock 319 81 222 minecraft:polished_blackstone
fill 320 81 182 320 84 182 minecraft:red_nether_bricks
setblock 320 81 221 minecraft:polished_blackstone
fill 320 81 222 320 84 222 minecraft:red_nether_bricks
fill 321 81 221 321 84 221 minecraft:red_nether_bricks
setblock 322 81 183 minecraft:red_nether_bricks
setblock 322 81 184 minecraft:polished_blackstone
fill 322 81 185 322 83 186 minecraft:red_nether_bricks
setblock 322 81 189 minecraft:polished_blackstone
fill 322 81 190 322 84 190 minecraft:red_nether_bricks
setblock 322 81 194 minecraft:polished_blackstone
fill 322 81 195 322 84 195 minecraft:red_nether_bricks
setblock 322 81 198 minecraft:red_nether_bricks
setblock 322 81 213 minecraft:red_nether_bricks
setblock 322 81 214 minecraft:polished_blackstone
fill 322 81 215 322 84 215 minecraft:red_nether_bricks
fill 322 81 217 322 81 218 minecraft:red_nether_bricks
setblock 322 81 219 minecraft:polished_blackstone
fill 322 81 220 322 84 220 minecraft:red_nether_bricks
setblock 323 81 183 minecraft:polished_blackstone
fill 323 81 184 323 84 184 minecraft:red_nether_bricks
setblock 323 81 188 minecraft:polished_blackstone
fill 323 81 189 323 84 189 minecraft:red_nether_bricks
setblock 323 81 193 minecraft:polished_blackstone
fill 323 81 194 323 84 194 minecraft:red_nether_bricks
setblock 323 81 197 minecraft:red_nether_bricks
setblock 323 81 198 minecraft:polished_blackstone
fill 323 81 199 323 84 199 minecraft:red_nether_bricks
fill 323 81 201 323 82 201 minecraft:red_nether_bricks
setblock 323 81 213 minecraft:polished_blackstone
fill 323 81 214 323 84 214 minecraft:red_nether_bricks
setblock 323 81 218 minecraft:polished_blackstone
fill 323 81 219 323 84 219 minecraft:red_nether_bricks
setblock 283 82 182 minecraft:polished_blackstone
fill 283 82 183 283 85 183 minecraft:red_nether_bricks
setblock 283 82 187 minecraft:polished_blackstone
fill 283 82 188 283 85 188 minecraft:red_nether_bricks
setblock 283 82 192 minecraft:polished_blackstone
fill 283 82 193 283 85 193 minecraft:red_nether_bricks
setblock 283 82 197 minecraft:polished_blackstone
fill 283 82 198 283 85 198 minecraft:red_nether_bricks
setblock 283 82 201 minecraft:red_nether_bricks
setblock 283 82 202 minecraft:polished_blackstone
fill 283 82 203 283 85 203 minecraft:red_nether_bricks
setblock 283 82 207 minecraft:polished_blackstone
fill 283 82 208 284 84 208 minecraft:red_nether_bricks
setblock 283 82 212 minecraft:polished_blackstone
fill 283 82 213 283 85 213 minecraft:red_nether_bricks
setblock 283 82 217 minecraft:polished_blackstone
fill 283 82 218 283 85 218 minecraft:red_nether_bricks
setblock 283 82 222 minecraft:polished_blackstone
fill 284 82 182 284 85 182 minecraft:red_nether_bricks
setblock 284 82 191 minecraft:polished_blackstone
fill 284 82 192 284 84 192 minecraft:red_nether_bricks
setblock 284 82 196 minecraft:polished_blackstone
fill 284 82 197 284 85 197 minecraft:red_nether_bricks
setblock 284 82 200 minecraft:red_nether_bricks
setblock 284 82 201 minecraft:polished_blackstone
setblock 284 82 211 minecraft:polished_blackstone
fill 284 82 212 284 85 212 minecraft:red_nether_bricks
setblock 284 82 216 minecraft:polished_blackstone
fill 284 82 217 284 85 217 minecraft:red_nether_bricks
setblock 284 82 221 minecraft:polished_blackstone
fill 284 82 222 284 85 222 minecraft:red_nether_bricks
fill 285 82 211 285 84 211 minecraft:red_nether_bricks
setblock 285 82 215 minecraft:polished_blackstone
fill 285 82 216 285 85 216 minecraft:red_nether_bricks
setblock 285 82 220 minecraft:polished_blackstone
fill 285 82 221 285 85 221 minecraft:red_nether_bricks
setblock 286 82 214 minecraft:polished_blackstone
fill 286 82 215 286 84 215 minecraft:red_nether_bricks
setblock 286 82 219 minecraft:polished_blackstone
fill 286 82 220 286 85 220 minecraft:red_nether_bricks
setblock 287 82 182 minecraft:red_nether_bricks
fill 287 82 219 287 85 219 minecraft:red_nether_bricks
setblock 288 82 222 minecraft:polished_blackstone
setblock 289 82 220 minecraft:red_nether_bricks
setblock 289 82 221 minecraft:polished_blackstone
fill 289 82 222 289 85 222 minecraft:red_nether_bricks
fill 290 82 221 290 85 221 minecraft:red_nether_bricks
setblock 292 82 222 minecraft:red_nether_bricks
fill 299 82 222 302 82 222 minecraft:red_nether_bricks
setblock 302 82 182 minecraft:red_nether_bricks
fill 302 82 221 303 82 221 minecraft:red_nether_bricks
setblock 303 82 182 minecraft:polished_blackstone
setblock 303 82 222 minecraft:polished_blackstone
fill 304 82 182 307 82 182 minecraft:red_nether_bricks
setblock 304 82 221 minecraft:polished_blackstone
fill 304 82 222 304 85 222 minecraft:red_nether_bricks
fill 305 82 221 306 84 221 minecraft:red_nether_bricks
setblock 308 82 182 minecraft:polished_blackstone
setblock 308 82 222 minecraft:polished_blackstone
fill 309 82 182 309 85 182 minecraft:red_nether_bricks
fill 309 82 222 309 85 222 minecraft:red_nether_bricks
fill 316 82 182 317 82 182 minecraft:red_nether_bricks
fill 316 82 222 317 82 222 minecraft:red_nether_bricks
setblock 318 82 182 minecraft:polished_blackstone
setblock 318 82 222 minecraft:polished_blackstone
fill 319 82 182 319 85 182 minecraft:red_nether_bricks
setblock 319 82 221 minecraft:polished_blackstone
fill 319 82 222 319 85 222 minecraft:red_nether_bricks
fill 320 82 183 321 82 183 minecraft:red_nether_bricks
setblock 320 82 220 minecraft:polished_blackstone
fill 320 82 221 320 85 221 minecraft:red_nether_bricks
fill 321 82 192 321 82 193 minecraft:red_nether_bricks
setblock 321 82 194 minecraft:polished_blackstone
fill 321 82 195 321 84 196 minecraft:red_nether_bricks
fill 321 82 216 321 82 218 minecraft:red_nether_bricks
setblock 321 82 219 minecraft:polished_blackstone
fill 321 82 220 321 85 220 minecraft:red_nether_bricks
setblock 322 82 183 minecraft:polished_blackstone
fill 322 82 184 322 85 184 minecraft:red_nether_bricks
setblock 322 82 188 minecraft:polished_blackstone
fill 322 82 189 322 85 189 minecraft:red_nether_bricks
setblock 322 82 193 minecraft:polished_blackstone
fill 322 82 194 322 85 194 minecraft:red_nether_bricks
setblock 322 82 198 minecraft:polished_blackstone
fill 322 82 199 322 85 199 minecraft:red_nether_bricks
setblock 322 82 212 minecraft:red_nether_bricks
setblock 322 82 213 minecraft:polished_blackstone
fill 322 82 214 322 85 214 minecraft:red_nether_bricks
setblock 322 82 217 minecraft:red_nether_bricks
setblock 322 82 218 minecraft:polished_blackstone
fill 322 82 219 322 85 219 minecraft:red_nether_bricks
setblock 323 82 182 minecraft:polished_blackstone
fill 323 82 183 323 85 183 minecraft:red_nether_bricks
setblock 323 82 187 minecraft:polished_blackstone
fill 323 82 188 323 85 188 minecraft:red_nether_bricks
setblock 323 82 192 minecraft:polished_blackstone
fill 323 82 193 323 85 193 minecraft:red_nether_bricks
setblock 323 82 197 minecraft:polished_blackstone
fill 323 82 198 323 85 198 minecraft:red_nether_bricks
setblock 323 82 202 minecraft:polished_blackstone
fill 323 82 203 323 85 203 minecraft:red_nether_bricks
fill 323 82 209 323 84 209 minecraft:red_nether_bricks
setblock 323 82 212 minecraft:polished_blackstone
fill 323 82 213 323 85 213 minecraft:red_nether_bricks
setblock 323 82 217 minecraft:polished_blackstone
fill 323 82 218 323 85 218 minecraft:red_nether_bricks
setblock 323 82 222 minecraft:polished_blackstone
fill 283 83 182 283 86 182 minecraft:red_nether_bricks
setblock 283 83 186 minecraft:polished_blackstone
fill 283 83 187 283 86 187 minecraft:red_nether_bricks
setblock 283 83 191 minecraft:polished_blackstone
fill 283 83 192 283 86 192 minecraft:red_nether_bricks
setblock 283 83 196 minecraft:polished_blackstone
fill 283 83 197 283 86 197 minecraft:red_nether_bricks
setblock 283 83 201 minecraft:polished_blackstone
fill 283 83 202 284 85 202 minecraft:red_nether_bricks
fill 283 83 204 283 83 205 minecraft:red_nether_bricks
setblock 283 83 206 minecraft:polished_blackstone
fill 283 83 207 284 85 207 minecraft:red_nether_bricks
setblock 283 83 211 minecraft:polished_blackstone
fill 283 83 212 283 86 212 minecraft:red_nether_bricks
setblock 283 83 216 minecraft:polished_blackstone
fill 283 83 217 283 86 217 minecraft:red_nether_bricks
setblock 283 83 221 minecraft:polished_blackstone
fill 283 83 222 283 86 222 minecraft:red_nether_bricks
setblock 284 83 195 minecraft:polished_blackstone
fill 284 83 196 284 86 196 minecraft:red_nether_bricks
setblock 284 83 200 minecraft:polished_blackstone
fill 284 83 201 284 86 201 minecraft:red_nether_bricks
fill 284 83 203 284 83 204 minecraft:red_nether_bricks
setblock 284 83 205 minecraft:polished_blackstone
fill 284 83 206 284 86 206 minecraft:red_nether_bricks
setblock 284 83 210 minecraft:polished_blackstone
fill 284 83 211 284 86 211 minecraft:red_nether_bricks
setblock 284 83 215 minecraft:polished_blackstone
fill 284 83 216 284 86 216 minecraft:red_nether_bricks
setblock 284 83 220 minecraft:polished_blackstone
fill 284 83 221 284 86 221 minecraft:red_nether_bricks
fill 285 83 197 285 83 198 minecraft:red_nether_bricks
setblock 285 83 214 minecraft:polished_blackstone
fill 285 83 215 285 86 215 minecraft:red_nether_bricks
setblock 285 83 219 minecraft:polished_blackstone
fill 285 83 220 285 86 220 minecraft:red_nether_bricks
setblock 286 83 214 minecraft:red_nether_bricks
setblock 286 83 218 minecraft:polished_blackstone
fill 286 83 219 286 86 219 minecraft:red_nether_bricks
setblock 287 83 182 minecraft:polished_blackstone
setblock 287 83 222 minecraft:polished_blackstone
setblock 288 83 221 minecraft:polished_blackstone
fill 288 83 222 288 86 222 minecraft:red_nether_bricks
setblock 289 83 220 minecraft:polished_blackstone
fill 289 83 221 289 86 221 minecraft:red_nether_bricks
fill 291 83 221 291 84 221 minecraft:red_nether_bricks
setblock 292 83 222 minecraft:polished_blackstone
fill 293 83 222 293 86 222 minecraft:red_nether_bricks
setblock 296 83 222 minecraft:red_nether_bricks
setblock 297 83 222 minecraft:polished_blackstone
fill 298 83 222 301 83 222 minecraft:red_nether_bricks
fill 299 83 221 302 83 221 minecraft:red_nether_bricks
fill 300 83 182 301 83 182 minecraft:red_nether_bricks
setblock 302 83 182 minecraft:polished_blackstone
setblock 302 83 222 minecraft:polished_blackstone
fill 303 83 182 306 83 182 minecraft:red_nether_bricks
setblock 303 83 221 minecraft:polished_blackstone
fill 303 83 222 303 86 222 minecraft:red_nether_bricks
fill 304 83 221 304 86 221 minecraft:red_nether_bricks
fill 305 83 222 306 83 222 minecraft:red_nether_bricks
setblock 307 83 182 minecraft:polished_blackstone
setblock 307 83 221 minecraft:red_nether_bricks
setblock 307 83 222 minecraft:polished_blackstone
fill 308 83 182 308 86 182 minecraft:red_nether_bricks
fill 308 83 222 308 86 222 minecraft:red_nether_bricks
fill 310 83 182 311 83 182 minecraft:red_nether_bricks
fill 310 83 222 310 84 222 minecraft:red_nether_bricks
setblock 311 83 183 minecraft:polished_blackstone
setblock 311 83 185 minecraft:polished_blackstone
setblock 312 83 182 minecraft:polished_blackstone
fill 313 83 182 316 83 182 minecraft:red_nether_bricks
setblock 313 83 183 minecraft:polished_blackstone
setblock 313 83 185 minecraft:polished_blackstone
fill 314 83 222 316 83 222 minecraft:red_nether_bricks
setblock 317 83 182 minecraft:polished_blackstone
setblock 317 83 221 minecraft:red_nether_bricks
setblock 317 83 222 minecraft:polished_blackstone
fill 318 83 182 318 85 183 minecraft:red_nether_bricks
setblock 318 83 221 minecraft:polished_blackstone
fill 318 83 222 318 86 222 minecraft:red_nether_bricks
fill 319 83 183 320 83 183 minecraft:red_nether_bricks
setblock 319 83 220 minecraft:polished_blackstone
fill 319 83 221 319 86 221 minecraft:red_nether_bricks
fill 320 83 220 320 86 220 minecraft:red_nether_bricks
setblock 321 83 183 minecraft:polished_blackstone
setblock 321 83 192 minecraft:red_nether_bricks
setblock 321 83 193 minecraft:polished_blackstone
fill 321 83 194 321 85 194 minecraft:red_nether_bricks
setblock 321 83 197 minecraft:red_nether_bricks
fill 321 83 215 321 83 217 minecraft:red_nether_bricks
setblock 321 83 218 minecraft:polished_blackstone
fill 321 83 219 321 86 219 minecraft:red_nether_bricks
setblock 322 83 182 minecraft:polished_blackstone
fill 322 83 183 322 86 183 minecraft:red_nether_bricks
setblock 322 83 187 minecraft:polished_blackstone
fill 322 83 188 322 86 188 minecraft:red_nether_bricks
setblock 322 83 192 minecraft:polished_blackstone
fill 322 83 193 322 86 193 minecraft:red_nether_bricks
setblock 322 83 196 minecraft:red_nether_bricks
setblock 322 83 197 minecraft:polished_blackstone
fill 322 83 198 322 86 198 minecraft:red_nether_bricks
fill 322 83 200 322 83 201 minecraft:red_nether_bricks
setblock 322 83 212 minecraft:polished_blackstone
fill 322 83 213 322 86 213 minecraft:red_nether_bricks
setblock 322 83 217 minecraft:polished_blackstone
fill 322 83 218 322 86 218 minecraft:red_nether_bricks
setblock 322 83 222 minecraft:polished_blackstone
fill 323 83 182 323 86 182 minecraft:red_nether_bricks
setblock 323 83 186 minecraft:polished_blackstone
fill 323 83 187 323 86 187 minecraft:red_nether_bricks
setblock 323 83 191 minecraft:polished_blackstone
fill 323 83 192 323 86 192 minecraft:red_nether_bricks
setblock 323 83 196 minecraft:polished_blackstone
fill 323 83 197 323 86 197 minecraft:red_nether_bricks
setblock 323 83 201 minecraft:polished_blackstone
fill 323 83 202 323 86 202 minecraft:red_nether_bricks
fill 323 83 204 323 83 205 minecraft:red_nether_bricks
fill 323 83 208 323 85 208 minecraft:red_nether_bricks
setblock 323 83 211 minecraft:polished_blackstone
fill 323 83 212 323 86 212 minecraft:red_nether_bricks
setblock 323 83 216 minecraft:polished_blackstone
fill 323 83 217 323 86 217 minecraft:red_nether_bricks
setblock 323 83 221 minecraft:polished_blackstone
fill 323 83 222 323 86 222 minecraft:red_nether_bricks
setblock 283 84 185 minecraft:polished_blackstone
fill 283 84 186 283 87 186 minecraft:red_nether_bricks
setblock 283 84 190 minecraft:polished_blackstone
fill 283 84 191 283 86 191 minecraft:red_nether_bricks
setblock 283 84 195 minecraft:polished_blackstone
fill 283 84 196 283 87 196 minecraft:red_nether_bricks
setblock 283 84 199 minecraft:red_nether_bricks
setblock 283 84 200 minecraft:polished_blackstone
fill 283 84 201 283 87 201 minecraft:red_nether_bricks
setblock 283 84 204 minecraft:red_nether_bricks
setblock 283 84 205 minecraft:polished_blackstone
fill 283 84 206 283 87 206 minecraft:red_nether_bricks
setblock 283 84 210 minecraft:polished_blackstone
fill 283 84 211 283 87 211 minecraft:red_nether_bricks
setblock 283 84 215 minecraft:polished_blackstone
fill 283 84 216 283 87 216 minecraft:red_nether_bricks
setblock 283 84 220 minecraft:polished_blackstone
fill 283 84 221 283 87 221 minecraft:red_nether_bricks
setblock 284 84 183 minecraft:red_nether_bricks
setblock 284 84 194 minecraft:polished_blackstone
fill 284 84 195 284 87 195 minecraft:red_nether_bricks
setblock 284 84 199 minecraft:polished_blackstone
fill 284 84 200 285 86 200 minecraft:red_nether_bricks
setblock 284 84 203 minecraft:red_nether_bricks
setblock 284 84 204 minecraft:polished_blackstone
fill 284 84 205 284 87 205 minecraft:red_nether_bricks
setblock 284 84 209 minecraft:polished_blackstone
fill 284 84 210 284 87 210 minecraft:red_nether_bricks
setblock 284 84 214 minecraft:polished_blackstone
fill 284 84 215 284 87 215 minecraft:red_nether_bricks
setblock 284 84 219 minecraft:polished_blackstone
fill 284 84 220 284 87 220 minecraft:red_nether_bricks
setblock 285 84 184 minecraft:light[level=14]
setblock 285 84 192 minecraft:light[level=14]
fill 285 84 196 285 84 197 minecraft:red_nether_bricks
setblock 285 84 198 minecraft:polished_blackstone
fill 285 84 199 285 87 199 minecraft:red_nether_bricks
setblock 285 84 208 minecraft:light[level=14]
setblock 285 84 213 minecraft:polished_blackstone
fill 285 84 214 285 86 214 minecraft:red_nether_bricks
setblock 285 84 218 minecraft:polished_blackstone
fill 285 84 219 285 87 219 minecraft:red_nether_bricks
setblock 286 84 182 minecraft:polished_blackstone
setblock 286 84 217 minecraft:polished_blackstone
fill 286 84 218 286 86 218 minecraft:red_nether_bricks
setblock 286 84 222 minecraft:polished_blackstone
fill 287 84 182 287 87 182 minecraft:red_nether_bricks
setblock 287 84 221 minecraft:polished_blackstone
fill 287 84 222 287 87 222 minecraft:red_nether_bricks
setblock 288 84 220 minecraft:polished_blackstone
fill 288 84 221 288 87 221 minecraft:red_nether_bricks
fill 289 84 220 289 85 220 minecraft:red_nether_bricks
setblock 291 84 222 minecraft:polished_blackstone
fill 292 84 222 292 87 222 minecraft:red_nether_bricks
setblock 293 84 184 minecraft:light[level=14]
setblock 293 84 192 minecraft:light[level=14]
setblock 293 84 200 minecraft:light[level=14]
setblock 293 84 208 minecraft:light[level=14]
setblock 293 84 216 minecraft:light[level=14]
fill 294 84 222 295 84 222 minecraft:red_nether_bricks
setblock 296 84 222 minecraft:polished_blackstone
fill 297 84 222 300 84 222 minecraft:red_nether_bricks
fill 298 84 221 301 84 221 minecraft:red_nether_bricks
fill 299 84 182 300 84 182 minecraft:red_nether_bricks
setblock 301 84 182 minecraft:polished_blackstone
setblock 301 84 184 minecraft:light[level=14]
setblock 301 84 192 minecraft:light[level=14]
setblock 301 84 200 minecraft:light[level=14]
setblock 301 84 208 minecraft:light[level=14]
setblock 301 84 216 minecraft:light[level=14]
fill 301 84 220 302 84 220 minecraft:red_nether_bricks
setblock 301 84 222 minecraft:polished_blackstone
fill 302 84 182 304 84 183 minecraft:red_nether_bricks
setblock 302 84 221 minecraft:polished_blackstone
fill 302 84 222 302 87 222 minecraft:red_nether_bricks
setblock 303 84 220 minecraft:polished_blackstone
fill 303 84 221 303 87 221 minecraft:red_nether_bricks
fill 304 84 220 304 85 220 minecraft:red_nether_bricks
setblock 305 84 182 minecraft:red_nether_bricks
setblock 305 84 183 minecraft:polished_blackstone
setblock 305 84 222 minecraft:red_nether_bricks
setblock 306 84 182 minecraft:polished_blackstone
fill 306 84 183 306 87 183 minecraft:red_nether_bricks
setblock 306 84 222 minecraft:polished_blackstone
fill 307 84 182 307 87 182 minecraft:red_nether_bricks
setblock 307 84 221 minecraft:polished_blackstone
fill 307 84 222 307 87 222 minecraft:red_nether_bricks
setblock 309 84 184 minecraft:light[level=14]
setblock 309 84 192 minecraft:light[level=14]
setblock 309 84 200 minecraft:light[level=14]
setblock 309 84 208 minecraft:light[level=14]
setblock 309 84 216 minecraft:light[level=14]
setblock 310 84 182 minecraft:red_nether_bricks
setblock 311 84 182 minecraft:polished_blackstone
setblock 311 84 222 minecraft:polished_blackstone
fill 312 84 182 315 84 182 minecraft:red_nether_bricks
fill 312 84 222 315 84 222 minecraft:red_nether_bricks
setblock 316 84 182 minecraft:polished_blackstone
setblock 316 84 221 minecraft:red_nether_bricks
setblock 316 84 222 minecraft:polished_blackstone
fill 317 84 182 317 86 183 minecraft:red_nether_bricks
setblock 317 84 184 minecraft:light[level=14]
setblock 317 84 192 minecraft:light[level=14]
setblock 317 84 200 minecraft:light[level=14]
setblock 317 84 208 minecraft:light[level=14]
setblock 317 84 216 minecraft:light[level=14]
setblock 317 84 221 minecraft:polished_blackstone
fill 317 84 222 317 87 222 minecraft:red_nether_bricks
setblock 318 84 220 minecraft:polished_blackstone
fill 318 84 221 318 87 221 minecraft:red_nether_bricks
setblock 319 84 183 minecraft:red_nether_bricks
fill 319 84 220 319 87 220 minecraft:red_nether_bricks
setblock 320 84 183 minecraft:polished_blackstone
fill 320 84 219 320 87 219 minecraft:red_nether_bricks
setblock 321 84 182 minecraft:polished_blackstone
fill 321 84 183 321 86 184 minecraft:red_nether_bricks
setblock 321 84 192 minecraft:polished_blackstone
fill 321 84 193 321 85 193 minecraft:red_nether_bricks
setblock 321 84 197 minecraft:polished_blackstone
fill 321 84 198 321 87 198 minecraft:red_nether_bricks
fill 321 84 215 321 84 216 minecraft:red_nether_bricks
setblock 321 84 217 minecraft:polished_blackstone
fill 321 84 218 321 87 218 minecraft:red_nether_bricks
setblock 321 84 222 minecraft:polished_blackstone
fill 322 84 182 322 87 182 minecraft:red_nether_bricks
setblock 322 84 185 minecraft:red_nether_bricks
setblock 322 84 186 minecraft:polished_blackstone
fill 322 84 187 322 87 187 minecraft:red_nether_bricks
setblock 322 84 191 minecraft:polished_blackstone
fill 322 84 192 322 87 192 minecraft:red_nether_bricks
setblock 322 84 196 minecraft:polished_blackstone
fill 322 84 197 322 87 197 minecraft:red_nether_bricks
setblock 322 84 200 minecraft:red_nether_bricks
setblock 322 84 201 minecraft:polished_blackstone
fill 322 84 202 322 87 202 minecraft:red_nether_bricks
fill 322 84 212 322 87 212 minecraft:red_nether_bricks
setblock 322 84 216 minecraft:polished_blackstone
fill 322 84 217 322 87 217 minecraft:red_nether_bricks
setblock 322 84 221 minecraft:polished_blackstone
fill 322 84 222 322 87 222 minecraft:red_nether_bricks
setblock 323 84 185 minecraft:polished_blackstone
fill 323 84 186 323 87 186 minecraft:red_nether_bricks
setblock 323 84 190 minecraft:polished_blackstone
fill 323 84 191 323 87 191 minecraft:red_nether_bricks
setblock 323 84 195 minecraft:polished_blackstone
fill 323 84 196 323 87 196 minecraft:red_nether_bricks
setblock 323 84 200 minecraft:polished_blackstone
fill 323 84 201 323 87 201 minecraft:red_nether_bricks
setblock 323 84 204 minecraft:red_nether_bricks
setblock 323 84 205 minecraft:polished_blackstone
fill 323 84 206 323 86 207 minecraft:red_nether_bricks
setblock 323 84 210 minecraft:polished_blackstone
fill 323 84 211 323 87 211 minecraft:red_nether_bricks
setblock 323 84 215 minecraft:polished_blackstone
fill 323 84 216 323 87 216 minecraft:red_nether_bricks
setblock 323 84 220 minecraft:polished_blackstone
fill 323 84 221 323 87 221 minecraft:red_nether_bricks
setblock 283 85 184 minecraft:polished_blackstone
fill 283 85 185 283 88 185 minecraft:red_nether_bricks
setblock 283 85 189 minecraft:polished_blackstone
fill 283 85 190 283 86 190 minecraft:red_nether_bricks
setblock 283 85 194 minecraft:polished_blackstone
fill 283 85 195 283 88 195 minecraft:red_nether_bricks
setblock 283 85 199 minecraft:polished_blackstone
fill 283 85 200 283 88 200 minecraft:red_nether_bricks
setblock 283 85 204 minecraft:polished_blackstone
fill 283 85 205 283 88 205 minecraft:red_nether_bricks
setblock 283 85 208 minecraft:red_nether_bricks
setblock 283 85 209 minecraft:polished_blackstone
fill 283 85 210 283 88 210 minecraft:red_nether_bricks
setblock 283 85 214 minecraft:polished_blackstone
fill 283 85 215 283 88 215 minecraft:red_nether_bricks
setblock 283 85 219 minecraft:polished_blackstone
fill 283 85 220 283 88 220 minecraft:red_nether_bricks
setblock 284 85 183 minecraft:polished_blackstone
setblock 284 85 193 minecraft:polished_blackstone
fill 284 85 194 284 86 194 minecraft:red_nether_bricks
setblock 284 85 198 minecraft:polished_blackstone
fill 284 85 199 284 88 199 minecraft:red_nether_bricks
setblock 284 85 203 minecraft:polished_blackstone
fill 284 85 204 284 88 204 minecraft:red_nether_bricks
setblock 284 85 208 minecraft:polished_blackstone
fill 284 85 209 284 88 209 minecraft:red_nether_bricks
setblock 284 85 213 minecraft:polished_blackstone
fill 284 85 214 284 88 214 minecraft:red_nether_bricks
setblock 284 85 218 minecraft:polished_blackstone
fill 284 85 219 284 88 219 minecraft:red_nether_bricks
setblock 285 85 182 minecraft:polished_blackstone
setblock 285 85 197 minecraft:polished_blackstone
fill 285 85 198 285 86 198 minecraft:red_nether_bricks
setblock 285 85 201 minecraft:red_nether_bricks
setblock 285 85 202 minecraft:polished_blackstone
setblock 285 85 212 minecraft:polished_blackstone
fill 285 85 213 285 86 213 minecraft:red_nether_bricks
setblock 285 85 217 minecraft:polished_blackstone
fill 285 85 218 285 88 218 minecraft:red_nether_bricks
setblock 285 85 222 minecraft:polished_blackstone
fill 286 85 182 286 88 182 minecraft:red_nether_bricks
setblock 286 85 216 minecraft:polished_blackstone
setblock 286 85 217 minecraft:red_nether_bricks
setblock 286 85 221 minecraft:polished_blackstone
fill 286 85 222 286 88 222 minecraft:red_nether_bricks
setblock 287 85 220 minecraft:polished_blackstone
fill 287 85 221 287 88 221 minecraft:red_nether_bricks
fill 288 85 220 288 86 220 minecraft:red_nether_bricks
setblock 290 85 222 minecraft:polished_blackstone
setblock 291 85 221 minecraft:polished_blackstone
fill 291 85 222 291 88 222 minecraft:red_nether_bricks
setblock 294 85 222 minecraft:red_nether_bricks
setblock 295 85 222 minecraft:polished_blackstone
setblock 296 85 221 minecraft:polished_blackstone
fill 296 85 222 299 85 222 minecraft:red_nether_bricks
fill 297 85 221 300 85 221 minecraft:red_nether_bricks
fill 298 85 182 299 85 182 minecraft:red_nether_bricks
setblock 300 85 182 minecraft:polished_blackstone
fill 300 85 220 301 85 220 minecraft:red_nether_bricks
setblock 300 85 222 minecraft:polished_blackstone
fill 301 85 182 303 85 183 minecraft:red_nether_bricks
setblock 301 85 221 minecraft:polished_blackstone
fill 301 85 222 301 88 222 minecraft:red_nether_bricks
setblock 302 85 220 minecraft:polished_blackstone
fill 302 85 221 302 88 221 minecraft:red_nether_bricks
fill 303 85 220 303 86 220 minecraft:red_nether_bricks
setblock 304 85 182 minecraft:red_nether_bricks
setblock 304 85 183 minecraft:polished_blackstone
setblock 305 85 182 minecraft:polished_blackstone
fill 305 85 183 305 88 183 minecraft:red_nether_bricks
setblock 305 85 221 minecraft:red_nether_bricks
setblock 305 85 222 minecraft:polished_blackstone
fill 306 85 182 306 88 182 minecraft:red_nether_bricks
setblock 306 85 221 minecraft:polished_blackstone
fill 306 85 222 306 88 222 minecraft:red_nether_bricks
fill 307 85 183 307 86 183 minecraft:red_nether_bricks
fill 307 85 221 308 85 221 minecraft:red_nether_bricks
setblock 310 85 182 minecraft:polished_blackstone
setblock 310 85 222 minecraft:polished_blackstone
fill 311 85 182 314 85 182 minecraft:red_nether_bricks
fill 311 85 222 314 85 222 minecraft:red_nether_bricks
fill 314 85 221 315 85 221 minecraft:red_nether_bricks
setblock 315 85 182 minecraft:polished_blackstone
fill 315 85 183 316 87 183 minecraft:red_nether_bricks
setblock 315 85 222 minecraft:polished_blackstone
fill 316 85 182 316 88 182 minecraft:red_nether_bricks
setblock 316 85 221 minecraft:polished_blackstone
fill 316 85 222 316 88 222 minecraft:red_nether_bricks
setblock 317 85 220 minecraft:polished_blackstone
fill 317 85 221 317 88 221 minecraft:red_nether_bricks
fill 318 85 220 318 88 220 minecraft:red_nether_bricks
setblock 319 85 183 minecraft:polished_blackstone
setblock 320 85 182 minecraft:polished_blackstone
fill 320 85 183 320 87 184 minecraft:red_nether_bricks
fill 320 85 218 320 87 218 minecraft:red_nether_bricks
setblock 320 85 222 minecraft:polished_blackstone
fill 321 85 182 321 88 182 minecraft:red_nether_bricks
setblock 321 85 195 minecraft:red_nether_bricks
setblock 321 85 196 minecraft:polished_blackstone
fill 321 85 197 321 87 197 minecraft:red_nether_bricks
fill 321 85 199 321 86 199 minecraft:red_nether_bricks
setblock 321 85 215 minecraft:red_nether_bricks
setblock 321 85 216 minecraft:polished_blackstone
fill 321 85 217 321 88 217 minecraft:red_nether_bricks
setblock 321 85 221 minecraft:polished_blackstone
fill 321 85 222 321 88 222 minecraft:red_nether_bricks
setblock 322 85 185 minecraft:polished_blackstone
fill 322 85 186 322 88 186 minecraft:red_nether_bricks
setblock 322 85 190 minecraft:polished_blackstone
fill 322 85 191 322 86 191 minecraft:red_nether_bricks
setblock 322 85 195 minecraft:polished_blackstone
fill 322 85 196 322 88 196 minecraft:red_nether_bricks
setblock 322 85 200 minecraft:polished_blackstone
fill 322 85 201 322 88 201 minecraft:red_nether_bricks
fill 322 85 203 322 86 203 minecraft:red_nether_bricks
setblock 322 85 215 minecraft:polished_blackstone
fill 322 85 216 322 88 216 minecraft:red_nether_bricks
setblock 322 85 220 minecraft:polished_blackstone
fill 322 85 221 322 88 221 minecraft:red_nether_bricks
setblock 323 85 184 minecraft:polished_blackstone
fill 323 85 185 323 88 185 minecraft:red_nether_bricks
setblock 323 85 189 minecraft:polished_blackstone
fill 323 85 190 323 88 190 minecraft:red_nether_bricks
setblock 323 85 194 minecraft:polished_blackstone
fill 323 85 195 323 88 195 minecraft:red_nether_bricks
setblock 323 85 199 minecraft:polished_blackstone
fill 323 85 200 323 88 200 minecraft:red_nether_bricks
setblock 323 85 204 minecraft:polished_blackstone
fill 323 85 205 323 88 205 minecraft:red_nether_bricks
setblock 323 85 209 minecraft:polished_blackstone
fill 323 85 210 323 88 210 minecraft:red_nether_bricks
setblock 323 85 214 minecraft:polished_blackstone
fill 323 85 215 323 88 215 minecraft:red_nether_bricks
setblock 323 85 219 minecraft:polished_blackstone
fill 323 85 220 323 88 220 minecraft:red_nether_bricks
setblock 283 86 183 minecraft:polished_blackstone
fill 283 86 184 283 89 184 minecraft:red_nether_bricks
setblock 283 86 188 minecraft:polished_blackstone
setblock 283 86 189 minecraft:red_nether_bricks
setblock 283 86 193 minecraft:polished_blackstone
fill 283 86 194 283 88 194 minecraft:red_nether_bricks
setblock 283 86 198 minecraft:polished_blackstone
fill 283 86 199 283 89 199 minecraft:red_nether_bricks
setblock 283 86 202 minecraft:red_nether_bricks
setblock 283 86 203 minecraft:polished_blackstone
fill 283 86 204 283 89 204 minecraft:red_nether_bricks
setblock 283 86 207 minecraft:red_nether_bricks
setblock 283 86 208 minecraft:polished_blackstone
fill 283 86 209 283 89 209 minecraft:red_nether_bricks
setblock 283 86 213 minecraft:polished_blackstone
fill 283 86 214 283 89 214 minecraft:red_nether_bricks
setblock 283 86 218 minecraft:polished_blackstone
fill 283 86 219 283 89 219 minecraft:red_nether_bricks
setblock 284 86 182 minecraft:polished_blackstone
setblock 284 86 183 minecraft:red_nether_bricks
setblock 284 86 197 minecraft:polished_blackstone
fill 284 86 198 284 89 198 minecraft:red_nether_bricks
setblock 284 86 202 minecraft:polished_blackstone
fill 284 86 203 285 87 203 minecraft:red_nether_bricks
setblock 284 86 207 minecraft:polished_blackstone
fill 284 86 208 284 89 208 minecraft:red_nether_bricks
setblock 284 86 212 minecraft:polished_blackstone
fill 284 86 213 284 88 213 minecraft:red_nether_bricks
setblock 284 86 217 minecraft:polished_blackstone
fill 284 86 218 284 89 218 minecraft:red_nether_bricks
setblock 284 86 222 minecraft:polished_blackstone
fill 285 86 182 285 89 182 minecraft:red_nether_bricks
setblock 285 86 201 minecraft:polished_blackstone
fill 285 86 202 285 88 202 minecraft:red_nether_bricks
setblock 285 86 216 minecraft:polished_blackstone
fill 285 86 217 285 88 217 minecraft:red_nether_bricks
setblock 285 86 221 minecraft:polished_blackstone
fill 285 86 222 285 89 222 minecraft:red_nether_bricks
setblock 286 86 220 minecraft:polished_blackstone
fill 286 86 221 286 89 221 minecraft:red_nether_bricks
fill 287 86 220 287 87 220 minecraft:red_nether_bricks
setblock 289 86 222 minecraft:polished_blackstone
setblock 290 86 221 minecraft:polished_blackstone
fill 290 86 222 290 89 222 minecraft:red_nether_bricks
setblock 291 86 221 minecraft:red_nether_bricks
setblock 294 86 222 minecraft:polished_blackstone
setblock 295 86 221 minecraft:polished_blackstone
fill 295 86 222 298 86 222 minecraft:red_nether_bricks
fill 296 86 221 299 86 221 minecraft:red_nether_bricks
fill 297 86 182 298 86 182 minecraft:red_nether_bricks
setblock 299 86 182 minecraft:polished_blackstone
fill 299 86 217 299 86 219 minecraft:polished_blackstone
fill 299 86 220 300 86 220 minecraft:red_nether_bricks
setblock 299 86 222 minecraft:polished_blackstone
fill 300 86 182 302 86 183 minecraft:red_nether_bricks
fill 300 86 217 301 86 217 minecraft:polished_blackstone
fill 300 86 219 301 86 219 minecraft:polished_blackstone
setblock 300 86 221 minecraft:polished_blackstone
fill 300 86 222 300 89 222 minecraft:red_nether_bricks
setblock 301 86 218 minecraft:polished_blackstone
setblock 301 86 220 minecraft:polished_blackstone
fill 301 86 221 301 89 221 minecraft:red_nether_bricks
fill 302 86 220 302 87 220 minecraft:red_nether_bricks
setblock 303 86 182 minecraft:red_nether_bricks
setblock 303 86 183 minecraft:polished_blackstone
setblock 304 86 182 minecraft:polished_blackstone
fill 304 86 183 304 89 183 minecraft:red_nether_bricks
setblock 304 86 222 minecraft:polished_blackstone
fill 305 86 182 305 89 182 minecraft:red_nether_bricks
setblock 305 86 221 minecraft:polished_blackstone
fill 305 86 222 305 89 222 minecraft:red_nether_bricks
fill 306 86 221 307 86 221 minecraft:red_nether_bricks
setblock 308 86 183 minecraft:polished_blackstone
setblock 309 86 182 minecraft:polished_blackstone
setblock 309 86 222 minecraft:polished_blackstone
fill 310 86 182 313 86 182 minecraft:red_nether_bricks
fill 310 86 222 313 86 222 minecraft:red_nether_bricks
setblock 314 86 182 minecraft:polished_blackstone
fill 314 86 183 314 89 183 minecraft:red_nether_bricks
setblock 314 86 221 minecraft:red_nether_bricks
setblock 314 86 222 minecraft:polished_blackstone
fill 315 86 182 315 89 182 minecraft:red_nether_bricks
setblock 315 86 221 minecraft:polished_blackstone
fill 315 86 222 315 89 222 minecraft:red_nether_bricks
fill 316 86 221 316 89 221 minecraft:red_nether_bricks
fill 317 86 220 317 89 220 minecraft:red_nether_bricks
setblock 318 86 182 minecraft:red_nether_bricks
setblock 318 86 183 minecraft:polished_blackstone
setblock 319 86 182 minecraft:polished_blackstone
fill 319 86 183 319 88 184 minecraft:red_nether_bricks
fill 319 86 219 319 88 219 minecraft:red_nether_bricks
setblock 319 86 222 minecraft:polished_blackstone
fill 320 86 182 320 89 182 minecraft:red_nether_bricks
setblock 320 86 221 minecraft:polished_blackstone
fill 320 86 222 320 89 222 minecraft:red_nether_bricks
setblock 321 86 185 minecraft:polished_blackstone
setblock 321 86 195 minecraft:polished_blackstone
setblock 321 86 196 minecraft:red_nether_bricks
setblock 321 86 200 minecraft:polished_blackstone
setblock 321 86 215 minecraft:polished_blackstone
fill 321 86 216 321 88 216 minecraft:red_nether_bricks
setblock 321 86 220 minecraft:polished_blackstone
fill 321 86 221 321 89 221 minecraft:red_nether_bricks
setblock 322 86 184 minecraft:polished_blackstone
fill 322 86 185 322 89 185 minecraft:red_nether_bricks
setblock 322 86 189 minecraft:polished_blackstone
setblock 322 86 190 minecraft:red_nether_bricks
setblock 322 86 194 minecraft:polished_blackstone
fill 322 86 195 322 88 195 minecraft:red_nether_bricks
setblock 322 86 199 minecraft:polished_blackstone
fill 322 86 200 322 89 200 minecraft:red_nether_bricks
setblock 322 86 204 minecraft:polished_blackstone
setblock 322 86 214 minecraft:polished_blackstone
fill 322 86 215 322 89 215 minecraft:red_nether_bricks
setblock 322 86 219 minecraft:polished_blackstone
fill 322 86 220 322 89 220 minecraft:red_nether_bricks
setblock 323 86 183 minecraft:polished_blackstone
fill 323 86 184 323 89 184 minecraft:red_nether_bricks
setblock 323 86 188 minecraft:polished_blackstone
fill 323 86 189 323 88 189 minecraft:red_nether_bricks
setblock 323 86 193 minecraft:polished_blackstone
fill 323 86 194 323 88 194 minecraft:red_nether_bricks
setblock 323 86 198 minecraft:polished_blackstone
fill 323 86 199 323 89 199 minecraft:red_nether_bricks
setblock 323 86 203 minecraft:polished_blackstone
fill 323 86 204 323 89 204 minecraft:red_nether_bricks
setblock 323 86 208 minecraft:polished_blackstone
fill 323 86 209 323 89 209 minecraft:red_nether_bricks
setblock 323 86 213 minecraft:polished_blackstone
fill 323 86 214 323 89 214 minecraft:red_nether_bricks
setblock 323 86 218 minecraft:polished_blackstone
fill 323 86 219 323 89 219 minecraft:red_nether_bricks
setblock 283 87 182 minecraft:polished_blackstone
fill 283 87 183 283 90 183 minecraft:red_nether_bricks
setblock 283 87 192 minecraft:polished_blackstone
fill 283 87 193 283 88 193 minecraft:red_nether_bricks
setblock 283 87 197 minecraft:polished_blackstone
fill 283 87 198 283 90 198 minecraft:red_nether_bricks
setblock 283 87 202 minecraft:polished_blackstone
fill 283 87 203 283 90 203 minecraft:red_nether_bricks
setblock 283 87 207 minecraft:polished_blackstone
fill 283 87 208 283 90 208 minecraft:red_nether_bricks
setblock 283 87 212 minecraft:polished_blackstone
fill 283 87 213 283 90 213 minecraft:red_nether_bricks
setblock 283 87 217 minecraft:polished_blackstone
fill 283 87 218 283 90 218 minecraft:red_nether_bricks
setblock 283 87 222 minecraft:polished_blackstone
fill 284 87 182 284 90 182 minecraft:red_nether_bricks
setblock 284 87 196 minecraft:polished_blackstone
fill 284 87 197 284 88 197 minecraft:red_nether_bricks
setblock 284 87 200 minecraft:red_nether_bricks
setblock 284 87 201 minecraft:polished_blackstone
fill 284 87 202 284 90 202 minecraft:red_nether_bricks
setblock 284 87 206 minecraft:polished_blackstone
fill 284 87 207 284 90 207 minecraft:red_nether_bricks
setblock 284 87 211 minecraft:polished_blackstone
fill 284 87 212 284 88 212 minecraft:red_nether_bricks
setblock 284 87 216 minecraft:polished_blackstone
fill 284 87 217 284 90 217 minecraft:red_nether_bricks
setblock 284 87 221 minecraft:polished_blackstone
fill 284 87 222 284 90 222 minecraft:red_nether_bricks
setblock 285 87 200 minecraft:polished_blackstone
fill 285 87 201 285 88 201 minecraft:red_nether_bricks
setblock 285 87 215 minecraft:polished_blackstone
setblock 285 87 216 minecraft:red_nether_bricks
setblock 285 87 220 minecraft:polished_blackstone
fill 285 87 221 285 90 221 minecraft:red_nether_bricks
fill 286 87 220 286 88 220 minecraft:red_nether_bricks
setblock 288 87 222 minecraft:polished_blackstone
setblock 289 87 221 minecraft:polished_blackstone
fill 289 87 222 289 89 222 minecraft:red_nether_bricks
setblock 293 87 222 minecraft:polished_blackstone
fill 294 87 222 297 87 222 minecraft:red_nether_bricks
fill 296 87 182 297 87 182 minecraft:red_nether_bricks
fill 296 87 221 298 87 221 minecraft:red_nether_bricks
setblock 298 87 182 minecraft:polished_blackstone
setblock 298 87 222 minecraft:polished_blackstone
fill 299 87 182 301 87 183 minecraft:red_nether_bricks
setblock 299 87 221 minecraft:polished_blackstone
fill 299 87 222 299 90 222 minecraft:red_nether_bricks
setblock 300 87 220 minecraft:polished_blackstone
fill 300 87 221 300 90 221 minecraft:red_nether_bricks
setblock 301 87 220 minecraft:red_nether_bricks
setblock 302 87 182 minecraft:red_nether_bricks
setblock 302 87 183 minecraft:polished_blackstone
setblock 303 87 182 minecraft:polished_blackstone
fill 303 87 183 303 90 183 minecraft:red_nether_bricks
setblock 303 87 222 minecraft:polished_blackstone
fill 304 87 182 304 90 182 minecraft:red_nether_bricks
setblock 304 87 221 minecraft:polished_blackstone
fill 304 87 222 304 90 222 minecraft:red_nether_bricks
fill 305 87 221 306 87 221 minecraft:red_nether_bricks
setblock 307 87 183 minecraft:polished_blackstone
setblock 308 87 182 minecraft:polished_blackstone
setblock 308 87 183 minecraft:red_nether_bricks
setblock 308 87 222 minecraft:polished_blackstone
fill 309 87 182 312 87 182 minecraft:red_nether_bricks
fill 309 87 222 312 87 222 minecraft:red_nether_bricks
setblock 313 87 182 minecraft:polished_blackstone
fill 313 87 183 313 90 183 minecraft:red_nether_bricks
setblock 313 87 221 minecraft:red_nether_bricks
setblock 313 87 222 minecraft:polished_blackstone
fill 314 87 182 314 90 182 minecraft:red_nether_bricks
setblock 314 87 221 minecraft:polished_blackstone
fill 314 87 222 314 90 222 minecraft:red_nether_bricks
fill 315 87 221 315 90 221 minecraft:red_nether_bricks
fill 316 87 220 316 88 220 minecraft:red_nether_bricks
setblock 317 87 182 minecraft:red_nether_bricks
setblock 317 87 183 minecraft:polished_blackstone
setblock 318 87 182 minecraft:polished_blackstone
fill 318 87 183 318 89 184 minecraft:red_nether_bricks
setblock 318 87 222 minecraft:polished_blackstone
fill 319 87 182 319 90 182 minecraft:red_nether_bricks
setblock 319 87 221 minecraft:polished_blackstone
fill 319 87 222 319 90 222 minecraft:red_nether_bricks
setblock 320 87 220 minecraft:polished_blackstone
fill 320 87 221 320 90 221 minecraft:red_nether_bricks
setblock 321 87 183 minecraft:red_nether_bricks
setblock 321 87 184 minecraft:polished_blackstone
fill 321 87 185 321 88 185 minecraft:red_nether_bricks
setblock 321 87 199 minecraft:polished_blackstone
setblock 321 87 200 minecraft:red_nether_bricks
setblock 321 87 215 minecraft:red_nether_bricks
setblock 321 87 219 minecraft:polished_blackstone
fill 321 87 220 321 90 220 minecraft:red_nether_bricks
setblock 322 87 183 minecraft:polished_blackstone
fill 322 87 184 322 90 184 minecraft:red_nether_bricks
setblock 322 87 188 minecraft:polished_blackstone
setblock 322 87 193 minecraft:polished_blackstone
setblock 322 87 194 minecraft:red_nether_bricks
setblock 322 87 198 minecraft:polished_blackstone
fill 322 87 199 322 89 199 minecraft:red_nether_bricks
setblock 322 87 203 minecraft:polished_blackstone
fill 322 87 204 322 89 205 minecraft:red_nether_bricks
setblock 322 87 213 minecraft:polished_blackstone
fill 322 87 214 322 89 214 minecraft:red_nether_bricks
setblock 322 87 218 minecraft:polished_blackstone
fill 322 87 219 322 90 219 minecraft:red_nether_bricks
setblock 323 87 182 minecraft:polished_blackstone
fill 323 87 183 323 90 183 minecraft:red_nether_bricks
setblock 323 87 187 minecraft:polished_blackstone
fill 323 87 188 323 89 188 minecraft:red_nether_bricks
setblock 323 87 192 minecraft:polished_blackstone
fill 323 87 193 323 88 193 minecraft:red_nether_bricks
setblock 323 87 197 minecraft:polished_blackstone
fill 323 87 198 323 90 198 minecraft:red_nether_bricks
setblock 323 87 202 minecraft:polished_blackstone
fill 323 87 203 323 90 203 minecraft:red_nether_bricks
setblock 323 87 206 minecraft:red_nether_bricks
setblock 323 87 207 minecraft:polished_blackstone
fill 323 87 208 323 90 208 minecraft:red_nether_bricks
setblock 323 87 212 minecraft:polished_blackstone
fill 323 87 213 323 90 213 minecraft:red_nether_bricks
setblock 323 87 217 minecraft:polished_blackstone
fill 323 87 218 323 90 218 minecraft:red_nether_bricks
setblock 323 87 222 minecraft:polished_blackstone
fill 283 88 182 283 91 182 minecraft:red_nether_bricks
setblock 283 88 196 minecraft:polished_blackstone
fill 283 88 197 283 90 197 minecraft:red_nether_bricks
setblock 283 88 201 minecraft:polished_blackstone
fill 283 88 202 283 91 202 minecraft:red_nether_bricks
setblock 283 88 206 minecraft:polished_blackstone
fill 283 88 207 283 91 207 minecraft:red_nether_bricks
setblock 283 88 211 minecraft:polished_blackstone
fill 283 88 212 283 91 212 minecraft:red_nether_bricks
setblock 283 88 216 minecraft:polished_blackstone
fill 283 88 217 283 91 217 minecraft:red_nether_bricks
setblock 283 88 221 minecraft:polished_blackstone
fill 283 88 222 283 91 222 minecraft:red_nether_bricks
setblock 284 88 200 minecraft:polished_blackstone
fill 284 88 201 284 91 201 minecraft:red_nether_bricks
fill 284 88 203 284 89 203 minecraft:red_nether_bricks
setblock 284 88 205 minecraft:polished_blackstone
fill 284 88 206 284 91 206 minecraft:red_nether_bricks
setblock 284 88 210 minecraft:polished_blackstone
setblock 284 88 211 minecraft:red_nether_bricks
setblock 284 88 215 minecraft:polished_blackstone
fill 284 88 216 284 89 216 minecraft:red_nether_bricks
setblock 284 88 220 minecraft:polished_blackstone
fill 284 88 221 284 91 221 minecraft:red_nether_bricks
setblock 285 88 219 minecraft:polished_blackstone
setblock 285 88 220 minecraft:red_nether_bricks
setblock 287 88 222 minecraft:polished_blackstone
setblock 288 88 221 minecraft:polished_blackstone
fill 288 88 222 288 90 222 minecraft:red_nether_bricks
setblock 292 88 222 minecraft:polished_blackstone
fill 293 88 222 296 88 222 minecraft:red_nether_bricks
fill 295 88 182 296 88 182 minecraft:red_nether_bricks
fill 296 88 221 297 88 221 minecraft:red_nether_bricks
setblock 297 88 182 minecraft:polished_blackstone
setblock 297 88 222 minecraft:polished_blackstone
fill 298 88 182 300 88 183 minecraft:red_nether_bricks
setblock 298 88 221 minecraft:polished_blackstone
fill 298 88 222 298 91 222 minecraft:red_nether_bricks
fill 299 88 221 299 90 221 minecraft:red_nether_bricks
setblock 301 88 182 minecraft:red_nether_bricks
setblock 301 88 183 minecraft:polished_blackstone
setblock 302 88 182 minecraft:polished_blackstone
fill 302 88 183 302 91 183 minecraft:red_nether_bricks
setblock 302 88 222 minecraft:polished_blackstone
fill 303 88 182 303 91 182 minecraft:red_nether_bricks
setblock 303 88 221 minecraft:polished_blackstone
fill 303 88 222 303 91 222 minecraft:red_nether_bricks
fill 304 88 221 305 88 221 minecraft:red_nether_bricks
setblock 306 88 183 minecraft:polished_blackstone
setblock 307 88 182 minecraft:polished_blackstone
fill 307 88 183 307 89 183 minecraft:red_nether_bricks
setblock 307 88 222 minecraft:polished_blackstone
fill 308 88 182 311 88 182 minecraft:red_nether_bricks
fill 308 88 222 311 88 222 minecraft:red_nether_bricks
setblock 312 88 182 minecraft:polished_blackstone
fill 312 88 183 312 91 183 minecraft:red_nether_bricks
setblock 312 88 222 minecraft:polished_blackstone
fill 313 88 182 313 91 182 minecraft:red_nether_bricks
fill 313 88 222 313 91 222 minecraft:red_nether_bricks
fill 314 88 221 314 91 221 minecraft:red_nether_bricks
setblock 315 88 183 minecraft:red_nether_bricks
setblock 316 88 183 minecraft:polished_blackstone
setblock 317 88 182 minecraft:polished_blackstone
fill 317 88 183 317 90 184 minecraft:red_nether_bricks
setblock 317 88 222 minecraft:polished_blackstone
fill 318 88 182 318 91 182 minecraft:red_nether_bricks
setblock 318 88 221 minecraft:polished_blackstone
fill 318 88 222 318 91 222 minecraft:red_nether_bricks
setblock 319 88 220 minecraft:polished_blackstone
fill 319 88 221 319 91 221 minecraft:red_nether_bricks
setblock 320 88 183 minecraft:red_nether_bricks
setblock 320 88 184 minecraft:polished_blackstone
setblock 320 88 219 minecraft:polished_blackstone
fill 320 88 220 320 91 220 minecraft:red_nether_bricks
setblock 321 88 183 minecraft:polished_blackstone
fill 321 88 184 321 91 184 minecraft:red_nether_bricks
setblock 321 88 218 minecraft:polished_blackstone
fill 321 88 219 321 91 219 minecraft:red_nether_bricks
setblock 322 88 182 minecraft:polished_blackstone
fill 322 88 183 322 91 183 minecraft:red_nether_bricks
setblock 322 88 187 minecraft:polished_blackstone
setblock 322 88 197 minecraft:polished_blackstone
fill 322 88 198 322 89 198 minecraft:red_nether_bricks
setblock 322 88 202 minecraft:polished_blackstone
fill 322 88 203 322 91 203 minecraft:red_nether_bricks
setblock 322 88 213 minecraft:red_nether_bricks
setblock 322 88 217 minecraft:polished_blackstone
fill 322 88 218 322 91 218 minecraft:red_nether_bricks
setblock 322 88 222 minecraft:polished_blackstone
fill 323 88 182 323 91 182 minecraft:red_nether_bricks
setblock 323 88 186 minecraft:polished_blackstone
fill 323 88 187 323 90 187 minecraft:red_nether_bricks
setblock 323 88 191 minecraft:polished_blackstone
setblock 323 88 192 minecraft:red_nether_bricks
setblock 323 88 196 minecraft:polished_blackstone
fill 323 88 197 323 90 197 minecraft:red_nether_bricks
setblock 323 88 201 minecraft:polished_blackstone
fill 323 88 202 323 91 202 minecraft:red_nether_bricks
setblock 323 88 206 minecraft:polished_blackstone
fill 323 88 207 323 91 207 minecraft:red_nether_bricks
setblock 323 88 211 minecraft:polished_blackstone
fill 323 88 212 323 90 212 minecraft:red_nether_bricks
setblock 323 88 216 minecraft:polished_blackstone
fill 323 88 217 323 91 217 minecraft:red_nether_bricks
setblock 323 88 221 minecraft:polished_blackstone
fill 323 88 222 323 91 222 minecraft:red_nether_bricks
setblock 283 89 185 minecraft:polished_blackstone
setblock 283 89 195 minecraft:polished_blackstone
fill 283 89 196 283 90 196 minecraft:red_nether_bricks
setblock 283 89 200 minecraft:polished_blackstone
fill 283 89 201 283 92 201 minecraft:red_nether_bricks
setblock 283 89 205 minecraft:polished_blackstone
fill 283 89 206 283 92 206 minecraft:red_nether_bricks
setblock 283 89 210 minecraft:polished_blackstone
fill 283 89 211 283 92 211 minecraft:red_nether_bricks
setblock 283 89 215 minecraft:polished_blackstone
fill 283 89 216 283 92 216 minecraft:red_nether_bricks
setblock 283 89 220 minecraft:polished_blackstone
fill 283 89 221 283 92 221 minecraft:red_nether_bricks
setblock 284 89 199 minecraft:polished_blackstone
fill 284 89 200 284 91 200 minecraft:red_nether_bricks
setblock 284 89 204 minecraft:polished_blackstone
fill 284 89 205 284 92 205 minecraft:red_nether_bricks
setblock 284 89 214 minecraft:polished_blackstone
setblock 284 89 215 minecraft:red_nether_bricks
setblock 284 89 219 minecraft:polished_blackstone
fill 284 89 220 284 91 220 minecraft:red_nether_bricks
setblock 286 89 182 minecraft:polished_blackstone
setblock 286 89 222 minecraft:polished_blackstone
setblock 287 89 221 minecraft:polished_blackstone
fill 287 89 222 287 91 222 minecraft:red_nether_bricks
setblock 291 89 222 minecraft:polished_blackstone
fill 292 89 222 295 89 222 minecraft:red_nether_bricks
setblock 295 89 182 minecraft:red_nether_bricks
setblock 296 89 182 minecraft:polished_blackstone
setblock 296 89 222 minecraft:polished_blackstone
fill 297 89 182 300 89 182 minecraft:red_nether_bricks
setblock 297 89 221 minecraft:polished_blackstone
fill 297 89 222 297 92 222 minecraft:red_nether_bricks
fill 298 89 183 299 89 183 minecraft:red_nether_bricks
fill 298 89 221 298 90 221 minecraft:red_nether_bricks
setblock 300 89 183 minecraft:polished_blackstone
setblock 301 89 182 minecraft:polished_blackstone
fill 301 89 183 301 92 183 minecraft:red_nether_bricks
setblock 301 89 222 minecraft:polished_blackstone
fill 302 89 182 302 92 182 minecraft:red_nether_bricks
setblock 302 89 221 minecraft:polished_blackstone
fill 302 89 222 302 92 222 minecraft:red_nether_bricks
setblock 303 89 221 minecraft:red_nether_bricks
setblock 305 89 183 minecraft:polished_blackstone
setblock 306 89 182 minecraft:polished_blackstone
fill 306 89 183 306 92 183 minecraft:red_nether_bricks
setblock 306 89 222 minecraft:polished_blackstone
fill 307 89 182 310 89 182 minecraft:red_nether_bricks
fill 307 89 222 310 89 222 minecraft:red_nether_bricks
setblock 311 89 182 minecraft:polished_blackstone
setblock 311 89 222 minecraft:polished_blackstone
fill 312 89 182 312 92 182 minecraft:red_nether_bricks
fill 312 89 222 312 92 222 minecraft:red_nether_bricks
setblock 315 89 183 minecraft:polished_blackstone
setblock 316 89 182 minecraft:polished_blackstone
fill 316 89 183 316 92 183 minecraft:red_nether_bricks
setblock 316 89 222 minecraft:polished_blackstone
fill 317 89 182 317 92 182 minecraft:red_nether_bricks
setblock 317 89 221 minecraft:polished_blackstone
fill 317 89 222 317 92 222 minecraft:red_nether_bricks
setblock 318 89 220 minecraft:polished_blackstone
fill 318 89 221 318 92 221 minecraft:red_nether_bricks
setblock 319 89 183 minecraft:red_nether_bricks
setblock 319 89 184 minecraft:polished_blackstone
fill 319 89 220 319 92 220 minecraft:red_nether_bricks
setblock 320 89 183 minecraft:polished_blackstone
fill 320 89 184 320 92 184 minecraft:red_nether_bricks
setblock 321 89 182 minecraft:polished_blackstone
fill 321 89 183 321 92 183 minecraft:red_nether_bricks
setblock 321 89 217 minecraft:polished_blackstone
fill 321 89 218 321 90 218 minecraft:red_nether_bricks
setblock 321 89 222 minecraft:polished_blackstone
fill 322 89 182 322 92 182 minecraft:red_nether_bricks
setblock 322 89 186 minecraft:polished_blackstone
setblock 322 89 201 minecraft:polished_blackstone
fill 322 89 202 322 91 202 minecraft:red_nether_bricks
setblock 322 89 216 minecraft:polished_blackstone
fill 322 89 217 322 91 217 minecraft:red_nether_bricks
setblock 322 89 221 minecraft:polished_blackstone
fill 322 89 222 322 92 222 minecraft:red_nether_bricks
setblock 323 89 185 minecraft:polished_blackstone
fill 323 89 186 323 92 186 minecraft:red_nether_bricks
setblock 323 89 195 minecraft:polished_blackstone
setblock 323 89 196 minecraft:red_nether_bricks
setblock 323 89 200 minecraft:polished_blackstone
fill 323 89 201 323 92 201 minecraft:red_nether_bricks
setblock 323 89 205 minecraft:polished_blackstone
fill 323 89 206 323 92 206 minecraft:red_nether_bricks
setblock 323 89 210 minecraft:polished_blackstone
fill 323 89 211 323 90 211 minecraft:red_nether_bricks
setblock 323 89 215 minecraft:polished_blackstone
fill 323 89 216 323 92 216 minecraft:red_nether_bricks
setblock 323 89 220 minecraft:polished_blackstone
fill 323 89 221 323 92 221 minecraft:red_nether_bricks
setblock 283 90 184 minecraft:polished_blackstone
setblock 283 90 199 minecraft:polished_blackstone
fill 283 90 200 283 93 200 minecraft:red_nether_bricks
setblock 283 90 204 minecraft:polished_blackstone
fill 283 90 205 283 93 205 minecraft:red_nether_bricks
setblock 283 90 209 minecraft:polished_blackstone
fill 283 90 210 283 93 210 minecraft:red_nether_bricks
setblock 283 90 214 minecraft:polished_blackstone
fill 283 90 215 283 92 215 minecraft:red_nether_bricks
setblock 283 90 219 minecraft:polished_blackstone
fill 283 90 220 283 93 220 minecraft:red_nether_bricks
setblock 284 90 199 minecraft:red_nether_bricks
setblock 284 90 203 minecraft:polished_blackstone
fill 284 90 204 284 93 204 minecraft:red_nether_bricks
setblock 284 90 208 minecraft:polished_blackstone
setblock 284 90 218 minecraft:polished_blackstone
setblock 284 90 219 minecraft:red_nether_bricks
setblock 285 90 182 minecraft:polished_blackstone
setblock 285 90 222 minecraft:polished_blackstone
fill 286 90 222 286 91 222 minecraft:red_nether_bricks
fill 293 90 222 294 90 222 minecraft:red_nether_bricks
setblock 294 90 182 minecraft:red_nether_bricks
setblock 295 90 182 minecraft:polished_blackstone
setblock 295 90 222 minecraft:polished_blackstone
fill 296 90 182 299 90 182 minecraft:red_nether_bricks
fill 296 90 222 296 93 222 minecraft:red_nether_bricks
fill 297 90 183 298 90 183 minecraft:red_nether_bricks
setblock 299 90 183 minecraft:polished_blackstone
setblock 300 90 182 minecraft:polished_blackstone
fill 300 90 183 300 93 183 minecraft:red_nether_bricks
setblock 300 90 222 minecraft:polished_blackstone
fill 301 90 182 301 93 182 minecraft:red_nether_bricks
setblock 301 90 221 minecraft:polished_blackstone
fill 301 90 222 301 93 222 minecraft:red_nether_bricks
setblock 304 90 183 minecraft:polished_blackstone
setblock 305 90 182 minecraft:polished_blackstone
fill 305 90 183 305 93 183 minecraft:red_nether_bricks
setblock 305 90 222 minecraft:polished_blackstone
fill 306 90 182 309 90 182 minecraft:red_nether_bricks
fill 306 90 222 309 90 222 minecraft:red_nether_bricks
setblock 310 90 182 minecraft:polished_blackstone
setblock 310 90 222 minecraft:polished_blackstone
fill 311 90 182 311 92 183 minecraft:red_nether_bricks
setblock 311 90 185 minecraft:polished_blackstone
fill 311 90 222 311 93 222 minecraft:red_nether_bricks
setblock 313 90 185 minecraft:polished_blackstone
setblock 314 90 183 minecraft:polished_blackstone
setblock 315 90 182 minecraft:polished_blackstone
fill 315 90 183 315 93 183 minecraft:red_nether_bricks
setblock 315 90 222 minecraft:polished_blackstone
fill 316 90 182 316 93 182 minecraft:red_nether_bricks
fill 316 90 184 316 91 184 minecraft:red_nether_bricks
setblock 316 90 221 minecraft:polished_blackstone
fill 316 90 222 316 93 222 minecraft:red_nether_bricks
setblock 317 90 220 minecraft:polished_blackstone
fill 317 90 221 317 93 221 minecraft:red_nether_bricks
setblock 318 90 183 minecraft:red_nether_bricks
setblock 318 90 184 minecraft:polished_blackstone
fill 318 90 220 318 93 220 minecraft:red_nether_bricks
setblock 319 90 183 minecraft:polished_blackstone
fill 319 90 184 319 93 184 minecraft:red_nether_bricks
setblock 320 90 182 minecraft:polished_blackstone
fill 320 90 183 320 93 183 minecraft:red_nether_bricks
setblock 320 90 222 minecraft:polished_blackstone
fill 321 90 182 321 93 182 minecraft:red_nether_bricks
setblock 321 90 221 minecraft:polished_blackstone
fill 321 90 222 321 93 222 minecraft:red_nether_bricks
setblock 322 90 185 minecraft:polished_blackstone
setblock 322 90 186 minecraft:red_nether_bricks
setblock 322 90 200 minecraft:polished_blackstone
setblock 322 90 201 minecraft:red_nether_bricks
setblock 322 90 204 minecraft:red_nether_bricks
setblock 322 90 205 minecraft:polished_blackstone
setblock 322 90 216 minecraft:red_nether_bricks
setblock 322 90 220 minecraft:polished_blackstone
fill 322 90 221 322 93 221 minecraft:red_nether_bricks
setblock 323 90 184 minecraft:polished_blackstone
fill 323 90 185 323 93 185 minecraft:red_nether_bricks
setblock 323 90 199 minecraft:polished_blackstone
fill 323 90 200 323 92 200 minecraft:red_nether_bricks
setblock 323 90 204 minecraft:polished_blackstone
fill 323 90 205 323 93 205 minecraft:red_nether_bricks
setblock 323 90 209 minecraft:polished_blackstone
fill 323 90 210 323 93 210 minecraft:red_nether_bricks
setblock 323 90 214 minecraft:polished_blackstone
fill 323 90 215 323 92 215 minecraft:red_nether_bricks
setblock 323 90 219 minecraft:polished_blackstone
fill 323 90 220 323 93 220 minecraft:red_nether_bricks
setblock 283 91 183 minecraft:polished_blackstone
setblock 283 91 184 minecraft:red_nether_bricks
setblock 283 91 198 minecraft:polished_blackstone
fill 283 91 199 283 93 199 minecraft:red_nether_bricks
setblock 283 91 203 minecraft:polished_blackstone
fill 283 91 204 283 94 204 minecraft:red_nether_bricks
setblock 283 91 208 minecraft:polished_blackstone
fill 283 91 209 283 94 209 minecraft:red_nether_bricks
setblock 283 91 213 minecraft:polished_blackstone
fill 283 91 214 283 92 214 minecraft:red_nether_bricks
setblock 283 91 218 minecraft:polished_blackstone
fill 283 91 219 283 93 219 minecraft:red_nether_bricks
setblock 284 91 182 minecraft:polished_blackstone
setblock 284 91 202 minecraft:polished_blackstone
fill 284 91 203 284 94 203 minecraft:red_nether_bricks
setblock 284 91 207 minecraft:polished_blackstone
setblock 284 91 222 minecraft:polished_blackstone
fill 285 91 222 285 92 222 minecraft:red_nether_bricks
setblock 294 91 182 minecraft:polished_blackstone
setblock 294 91 222 minecraft:polished_blackstone
fill 295 91 182 298 91 182 minecraft:red_nether_bricks
fill 295 91 222 295 94 222 minecraft:red_nether_bricks
setblock 297 91 183 minecraft:red_nether_bricks
setblock 298 91 183 minecraft:polished_blackstone
setblock 299 91 182 minecraft:polished_blackstone
fill 299 91 183 299 94 183 minecraft:red_nether_bricks
setblock 299 91 222 minecraft:polished_blackstone
fill 300 91 182 300 94 182 minecraft:red_nether_bricks
fill 300 91 219 300 92 221 minecraft:gilded_blackstone
fill 300 91 222 300 94 222 minecraft:red_nether_bricks
setblock 303 91 183 minecraft:polished_blackstone
setblock 304 91 182 minecraft:polished_blackstone
fill 304 91 183 304 94 183 minecraft:red_nether_bricks
setblock 304 91 222 minecraft:polished_blackstone
fill 305 91 182 308 91 182 minecraft:red_nether_bricks
setblock 305 91 222 minecraft:red_nether_bricks
setblock 309 91 182 minecraft:polished_blackstone
fill 310 91 182 310 94 182 minecraft:red_nether_bricks
setblock 310 91 222 minecraft:red_nether_bricks
setblock 313 91 183 minecraft:polished_blackstone
setblock 314 91 182 minecraft:polished_blackstone
fill 314 91 183 314 94 183 minecraft:red_nether_bricks
setblock 314 91 222 minecraft:polished_blackstone
fill 315 91 182 315 94 182 minecraft:red_nether_bricks
fill 315 91 184 315 92 184 minecraft:red_nether_bricks
setblock 315 91 221 minecraft:polished_blackstone
fill 315 91 222 315 94 222 minecraft:red_nether_bricks
fill 316 91 221 316 94 221 minecraft:red_nether_bricks
setblock 317 91 183 minecraft:red_nether_bricks
setblock 317 91 184 minecraft:polished_blackstone
fill 317 91 220 317 92 220 minecraft:red_nether_bricks
setblock 318 91 183 minecraft:polished_blackstone
fill 318 91 184 318 94 184 minecraft:red_nether_bricks
setblock 319 91 182 minecraft:polished_blackstone
fill 319 91 183 319 94 183 minecraft:red_nether_bricks
setblock 319 91 222 minecraft:polished_blackstone
fill 320 91 182 320 94 182 minecraft:red_nether_bricks
setblock 320 91 221 minecraft:polished_blackstone
fill 320 91 222 320 94 222 minecraft:red_nether_bricks
setblock 321 91 220 minecraft:polished_blackstone
fill 321 91 221 321 94 221 minecraft:red_nether_bricks
setblock 322 91 184 minecraft:polished_blackstone
fill 322 91 185 322 94 185 minecraft:red_nether_bricks
setblock 322 91 204 minecraft:polished_blackstone
setblock 322 91 219 minecraft:polished_blackstone
fill 322 91 220 322 94 220 minecraft:red_nether_bricks
setblock 323 91 183 minecraft:polished_blackstone
fill 323 91 184 323 94 184 minecraft:red_nether_bricks
setblock 323 91 199 minecraft:red_nether_bricks
setblock 323 91 203 minecraft:polished_blackstone
fill 323 91 204 323 94 204 minecraft:red_nether_bricks
setblock 323 91 208 minecraft:polished_blackstone
fill 323 91 209 323 94 209 minecraft:red_nether_bricks
setblock 323 91 213 minecraft:polished_blackstone
setblock 323 91 214 minecraft:red_nether_bricks
setblock 323 91 218 minecraft:polished_blackstone
fill 323 91 219 323 94 219 minecraft:red_nether_bricks
setblock 283 92 182 minecraft:polished_blackstone
fill 283 92 183 283 93 183 minecraft:red_nether_bricks
setblock 283 92 198 minecraft:red_nether_bricks
setblock 283 92 202 minecraft:polished_blackstone
fill 283 92 203 283 95 203 minecraft:red_nether_bricks
setblock 283 92 207 minecraft:polished_blackstone
fill 283 92 208 283 95 208 minecraft:red_nether_bricks
setblock 283 92 212 minecraft:polished_blackstone
fill 283 92 213 283 95 213 minecraft:red_nether_bricks
setblock 283 92 217 minecraft:polished_blackstone
fill 283 92 218 283 93 218 minecraft:red_nether_bricks
setblock 283 92 222 minecraft:polished_blackstone
setblock 284 92 201 minecraft:polished_blackstone
fill 284 92 202 284 94 202 minecraft:red_nether_bricks
setblock 284 92 206 minecraft:polished_blackstone
fill 284 92 207 284 95 207 minecraft:red_nether_bricks
fill 284 92 222 284 93 222 minecraft:red_nether_bricks
setblock 285 92 184 minecraft:light[level=14]
setblock 285 92 192 minecraft:light[level=14]
setblock 285 92 200 minecraft:light[level=14]
setblock 285 92 208 minecraft:light[level=14]
setblock 285 92 216 minecraft:light[level=14]
setblock 293 92 182 minecraft:polished_blackstone
setblock 293 92 184 minecraft:light[level=14]
setblock 293 92 192 minecraft:light[level=14]
setblock 293 92 200 minecraft:light[level=14]
setblock 293 92 208 minecraft:light[level=14]
setblock 293 92 216 minecraft:light[level=14]
fill 294 92 182 297 92 182 minecraft:red_nether_bricks
fill 294 92 222 294 95 222 minecraft:red_nether_bricks
setblock 296 92 183 minecraft:red_nether_bricks
setblock 297 92 183 minecraft:polished_blackstone
setblock 298 92 182 minecraft:polished_blackstone
fill 298 92 183 298 95 183 minecraft:red_nether_bricks
setblock 298 92 222 minecraft:polished_blackstone
fill 299 92 182 299 95 182 minecraft:red_nether_bricks
fill 299 92 222 299 95 222 minecraft:red_nether_bricks
setblock 300 92 217 minecraft:shroomlight
setblock 301 92 184 minecraft:light[level=14]
setblock 301 92 192 minecraft:light[level=14]
setblock 301 92 200 minecraft:light[level=14]
setblock 301 92 208 minecraft:light[level=14]
setblock 301 92 216 minecraft:light[level=14]
setblock 302 92 183 minecraft:polished_blackstone
setblock 303 92 182 minecraft:polished_blackstone
fill 303 92 183 303 95 183 minecraft:red_nether_bricks
setblock 303 92 222 minecraft:polished_blackstone
fill 304 92 182 307 92 182 minecraft:red_nether_bricks
setblock 304 92 222 minecraft:red_nether_bricks
setblock 308 92 182 minecraft:polished_blackstone
fill 309 92 182 309 95 182 minecraft:red_nether_bricks
setblock 309 92 184 minecraft:light[level=14]
setblock 309 92 192 minecraft:light[level=14]
setblock 309 92 200 minecraft:light[level=14]
setblock 309 92 208 minecraft:light[level=14]
setblock 309 92 216 minecraft:light[level=14]
fill 310 92 183 310 93 183 minecraft:red_nether_bricks
setblock 312 92 183 minecraft:polished_blackstone
setblock 313 92 182 minecraft:polished_blackstone
fill 313 92 183 313 95 183 minecraft:red_nether_bricks
setblock 313 92 222 minecraft:polished_blackstone
fill 314 92 182 314 95 182 minecraft:red_nether_bricks
setblock 314 92 221 minecraft:polished_blackstone
fill 314 92 222 314 95 222 minecraft:red_nether_bricks
fill 315 92 221 315 95 221 minecraft:red_nether_bricks
setblock 316 92 184 minecraft:polished_blackstone
setblock 317 92 183 minecraft:polished_blackstone
fill 317 92 184 317 95 184 minecraft:red_nether_bricks
setblock 317 92 192 minecraft:light[level=14]
setblock 317 92 200 minecraft:light[level=14]
setblock 317 92 208 minecraft:light[level=14]
setblock 317 92 216 minecraft:light[level=14]
setblock 318 92 182 minecraft:polished_blackstone
fill 318 92 183 318 95 183 minecraft:red_nether_bricks
setblock 318 92 222 minecraft:polished_blackstone
fill 319 92 182 319 95 182 minecraft:red_nether_bricks
setblock 319 92 221 minecraft:polished_blackstone
fill 319 92 222 319 95 222 minecraft:red_nether_bricks
setblock 320 92 220 minecraft:polished_blackstone
fill 320 92 221 320 95 221 minecraft:red_nether_bricks
setblock 321 92 220 minecraft:red_nether_bricks
setblock 322 92 183 minecraft:polished_blackstone
fill 322 92 184 322 95 184 minecraft:red_nether_bricks
setblock 322 92 218 minecraft:polished_blackstone
fill 322 92 219 322 94 219 minecraft:red_nether_bricks
setblock 323 92 182 minecraft:polished_blackstone
fill 323 92 183 323 95 183 minecraft:red_nether_bricks
setblock 323 92 202 minecraft:polished_blackstone
fill 323 92 203 323 95 203 minecraft:red_nether_bricks
setblock 323 92 207 minecraft:polished_blackstone
fill 323 92 208 323 95 208 minecraft:red_nether_bricks
setblock 323 92 217 minecraft:polished_blackstone
fill 323 92 218 323 95 218 minecraft:red_nether_bricks
setblock 323 92 222 minecraft:polished_blackstone
fill 283 93 182 283 94 182 minecraft:red_nether_bricks
setblock 283 93 201 minecraft:polished_blackstone
fill 283 93 202 283 96 202 minecraft:red_nether_bricks
setblock 283 93 206 minecraft:polished_blackstone
fill 283 93 207 283 96 207 minecraft:red_nether_bricks
setblock 283 93 211 minecraft:polished_blackstone
fill 283 93 212 283 96 212 minecraft:red_nether_bricks
setblock 283 93 221 minecraft:polished_blackstone
fill 283 93 222 283 95 222 minecraft:red_nether_bricks
setblock 284 93 205 minecraft:polished_blackstone
fill 284 93 206 284 96 206 minecraft:red_nether_bricks
fill 284 93 208 284 94 208 minecraft:red_nether_bricks
fill 293 93 182 296 93 182 minecraft:red_nether_bricks
setblock 295 93 183 minecraft:red_nether_bricks
setblock 296 93 183 minecraft:polished_blackstone
setblock 297 93 182 minecraft:polished_blackstone
fill 297 93 183 297 96 183 minecraft:red_nether_bricks
setblock 297 93 222 minecraft:polished_blackstone
fill 298 93 182 298 96 182 minecraft:red_nether_bricks
fill 298 93 184 299 93 184 minecraft:red_nether_bricks
fill 298 93 222 298 96 222 minecraft:red_nether_bricks
setblock 300 93 184 minecraft:polished_blackstone
setblock 301 93 183 minecraft:polished_blackstone
setblock 302 93 182 minecraft:polished_blackstone
fill 302 93 183 302 96 183 minecraft:red_nether_bricks
setblock 302 93 222 minecraft:polished_blackstone
fill 303 93 182 306 93 182 minecraft:red_nether_bricks
setblock 306 93 183 minecraft:polished_blackstone
setblock 307 93 182 minecraft:polished_blackstone
fill 308 93 182 308 95 183 minecraft:red_nether_bricks
fill 309 93 183 309 94 183 minecraft:red_nether_bricks
setblock 311 93 182 minecraft:red_nether_bricks
setblock 311 93 183 minecraft:polished_blackstone
setblock 312 93 182 minecraft:polished_blackstone
fill 312 93 183 312 96 183 minecraft:red_nether_bricks
setblock 312 93 222 minecraft:polished_blackstone
fill 313 93 182 313 96 182 minecraft:red_nether_bricks
fill 313 93 222 313 96 222 minecraft:red_nether_bricks
setblock 314 93 184 minecraft:red_nether_bricks
fill 314 93 221 314 96 221 minecraft:red_nether_bricks
setblock 315 93 184 minecraft:polished_blackstone
setblock 316 93 183 minecraft:polished_blackstone
fill 316 93 184 316 96 184 minecraft:red_nether_bricks
setblock 317 93 182 minecraft:polished_blackstone
fill 317 93 183 317 96 183 minecraft:red_nether_bricks
setblock 317 93 222 minecraft:polished_blackstone
fill 318 93 182 318 96 182 minecraft:red_nether_bricks
setblock 318 93 221 minecraft:polished_blackstone
fill 318 93 222 318 96 222 minecraft:red_nether_bricks
setblock 319 93 220 minecraft:polished_blackstone
fill 319 93 221 319 96 221 minecraft:red_nether_bricks
setblock 320 93 184 minecraft:polished_blackstone
setblock 320 93 220 minecraft:red_nether_bricks
setblock 321 93 183 minecraft:polished_blackstone
setblock 322 93 182 minecraft:polished_blackstone
fill 322 93 183 322 96 183 minecraft:red_nether_bricks
setblock 322 93 222 minecraft:polished_blackstone
fill 323 93 182 323 96 182 minecraft:red_nether_bricks
setblock 323 93 186 minecraft:polished_blackstone
setblock 323 93 201 minecraft:polished_blackstone
fill 323 93 202 323 96 202 minecraft:red_nether_bricks
setblock 323 93 206 minecraft:polished_blackstone
fill 323 93 207 323 96 207 minecraft:red_nether_bricks
setblock 323 93 211 minecraft:polished_blackstone
setblock 323 93 216 minecraft:polished_blackstone
fill 323 93 217 323 96 217 minecraft:red_nether_bricks
setblock 323 93 221 minecraft:polished_blackstone
fill 323 93 222 323 96 222 minecraft:red_nether_bricks
setblock 283 94 200 minecraft:polished_blackstone
fill 283 94 201 283 97 201 minecraft:red_nether_bricks
setblock 283 94 205 minecraft:polished_blackstone
fill 283 94 206 283 97 206 minecraft:red_nether_bricks
setblock 283 94 210 minecraft:polished_blackstone
fill 283 94 211 283 97 211 minecraft:red_nether_bricks
setblock 283 94 220 minecraft:polished_blackstone
setblock 283 94 221 minecraft:red_nether_bricks
setblock 284 94 204 minecraft:polished_blackstone
fill 284 94 205 284 97 205 minecraft:red_nether_bricks
fill 292 94 182 295 94 182 minecraft:red_nether_bricks
setblock 294 94 183 minecraft:red_nether_bricks
setblock 295 94 183 minecraft:polished_blackstone
setblock 296 94 182 minecraft:polished_blackstone
fill 296 94 183 296 97 183 minecraft:red_nether_bricks
setblock 296 94 222 minecraft:polished_blackstone
fill 297 94 182 297 97 182 minecraft:red_nether_bricks
fill 297 94 184 298 94 184 minecraft:red_nether_bricks
fill 297 94 222 297 97 222 minecraft:red_nether_bricks
setblock 299 94 184 minecraft:polished_blackstone
fill 299 94 217 299 94 219 minecraft:polished_blackstone
setblock 300 94 183 minecraft:polished_blackstone
fill 300 94 184 301 96 184 minecraft:red_nether_bricks
fill 300 94 217 301 94 217 minecraft:polished_blackstone
fill 300 94 219 301 94 219 minecraft:polished_blackstone
setblock 301 94 182 minecraft:polished_blackstone
fill 301 94 183 301 97 183 minecraft:red_nether_bricks
setblock 301 94 218 minecraft:polished_blackstone
setblock 301 94 222 minecraft:polished_blackstone
fill 302 94 182 305 94 182 minecraft:red_nether_bricks
setblock 305 94 183 minecraft:polished_blackstone
setblock 306 94 182 minecraft:polished_blackstone
fill 306 94 183 307 96 183 minecraft:red_nether_bricks
fill 307 94 182 307 97 182 minecraft:red_nether_bricks
setblock 310 94 183 minecraft:polished_blackstone
setblock 310 94 222 minecraft:red_nether_bricks
setblock 311 94 182 minecraft:polished_blackstone
fill 311 94 183 311 97 183 minecraft:red_nether_bricks
setblock 311 94 184 minecraft:gilded_blackstone
setblock 311 94 222 minecraft:polished_blackstone
fill 312 94 182 312 97 182 minecraft:red_nether_bricks
fill 312 94 184 313 94 184 minecraft:red_nether_bricks
fill 312 94 222 312 97 222 minecraft:red_nether_bricks
fill 313 94 221 313 97 221 minecraft:red_nether_bricks
setblock 314 94 184 minecraft:polished_blackstone
setblock 315 94 183 minecraft:polished_blackstone
fill 315 94 184 315 97 184 minecraft:red_nether_bricks
setblock 316 94 182 minecraft:polished_blackstone
fill 316 94 183 316 97 183 minecraft:red_nether_bricks
setblock 316 94 222 minecraft:polished_blackstone
fill 317 94 182 317 97 182 minecraft:red_nether_bricks
setblock 317 94 221 minecraft:polished_blackstone
fill 317 94 222 317 97 222 minecraft:red_nether_bricks
setblock 318 94 220 minecraft:polished_blackstone
fill 318 94 221 318 97 221 minecraft:red_nether_bricks
setblock 319 94 184 minecraft:polished_blackstone
setblock 319 94 220 minecraft:red_nether_bricks
setblock 320 94 183 minecraft:polished_blackstone
fill 320 94 184 320 97 184 minecraft:red_nether_bricks
setblock 321 94 182 minecraft:polished_blackstone
fill 321 94 183 321 97 183 minecraft:red_nether_bricks
setblock 321 94 222 minecraft:polished_blackstone
fill 322 94 182 322 97 182 minecraft:red_nether_bricks
setblock 322 94 205 minecraft:red_nether_bricks
setblock 322 94 206 minecraft:polished_blackstone
fill 322 94 207 322 97 207 minecraft:red_nether_bricks
setblock 322 94 221 minecraft:polished_blackstone
fill 322 94 222 322 97 222 minecraft:red_nether_bricks
setblock 323 94 185 minecraft:polished_blackstone
fill 323 94 186 323 97 186 minecraft:red_nether_bricks
setblock 323 94 205 minecraft:polished_blackstone
fill 323 94 206 323 97 206 minecraft:red_nether_bricks
setblock 323 94 210 minecraft:polished_blackstone
fill 323 94 211 323 96 212 minecraft:red_nether_bricks
fill 323 94 216 323 97 216 minecraft:red_nether_bricks
setblock 323 94 220 minecraft:polished_blackstone
fill 323 94 221 323 97 221 minecraft:red_nether_bricks
fill 283 95 200 283 98 200 minecraft:red_nether_bricks
setblock 283 95 204 minecraft:polished_blackstone
fill 283 95 205 283 98 205 minecraft:red_nether_bricks
setblock 283 95 209 minecraft:polished_blackstone
fill 283 95 210 283 98 210 minecraft:red_nether_bricks
setblock 284 95 203 minecraft:polished_blackstone
fill 284 95 204 284 98 204 minecraft:red_nether_bricks
setblock 284 95 208 minecraft:polished_blackstone
fill 284 95 209 284 98 209 minecraft:red_nether_bricks
fill 291 95 182 294 95 182 minecraft:red_nether_bricks
setblock 293 95 183 minecraft:red_nether_bricks
setblock 294 95 183 minecraft:polished_blackstone
setblock 295 95 182 minecraft:polished_blackstone
fill 295 95 183 295 97 184 minecraft:red_nether_bricks
setblock 295 95 222 minecraft:polished_blackstone
fill 296 95 182 296 98 182 minecraft:red_nether_bricks
fill 296 95 184 297 95 184 minecraft:red_nether_bricks
fill 296 95 222 296 98 222 minecraft:red_nether_bricks
setblock 298 95 184 minecraft:polished_blackstone
setblock 299 95 183 minecraft:polished_blackstone
fill 299 95 184 299 98 184 minecraft:red_nether_bricks
setblock 300 95 182 minecraft:polished_blackstone
fill 300 95 183 300 98 183 minecraft:red_nether_bricks
setblock 300 95 222 minecraft:polished_blackstone
fill 301 95 182 304 95 182 minecraft:red_nether_bricks
setblock 301 95 222 minecraft:red_nether_bricks
setblock 302 95 184 minecraft:red_nether_bricks
setblock 304 95 183 minecraft:polished_blackstone
setblock 305 95 182 minecraft:polished_blackstone
fill 305 95 183 305 98 183 minecraft:red_nether_bricks
fill 306 95 182 306 98 182 minecraft:red_nether_bricks
setblock 309 95 183 minecraft:polished_blackstone
setblock 310 95 182 minecraft:polished_blackstone
fill 310 95 183 310 98 183 minecraft:red_nether_bricks
setblock 310 95 222 minecraft:polished_blackstone
fill 311 95 182 311 98 182 minecraft:red_nether_bricks
fill 311 95 184 312 95 184 minecraft:red_nether_bricks
fill 311 95 222 311 98 222 minecraft:red_nether_bricks
setblock 313 95 184 minecraft:polished_blackstone
setblock 314 95 183 minecraft:polished_blackstone
fill 314 95 184 314 98 184 minecraft:red_nether_bricks
setblock 315 95 182 minecraft:polished_blackstone
fill 315 95 183 315 98 183 minecraft:red_nether_bricks
setblock 315 95 222 minecraft:polished_blackstone
fill 316 95 182 316 98 182 minecraft:red_nether_bricks
setblock 316 95 221 minecraft:polished_blackstone
fill 316 95 222 316 98 222 minecraft:red_nether_bricks
fill 317 95 221 317 98 221 minecraft:red_nether_bricks
setblock 318 95 184 minecraft:polished_blackstone
fill 318 95 209 320 96 209 minecraft:magma_block
setblock 319 95 183 minecraft:polished_blackstone
fill 319 95 184 319 98 184 minecraft:red_nether_bricks
fill 319 95 208 320 96 208 minecraft:magma_block
setblock 320 95 182 minecraft:polished_blackstone
fill 320 95 183 320 98 183 minecraft:red_nether_bricks
setblock 320 95 222 minecraft:polished_blackstone
fill 321 95 182 321 98 182 minecraft:red_nether_bricks
setblock 321 95 221 minecraft:polished_blackstone
fill 321 95 222 321 98 222 minecraft:red_nether_bricks
setblock 322 95 185 minecraft:polished_blackstone
setblock 322 95 205 minecraft:polished_blackstone
fill 322 95 206 322 98 206 minecraft:red_nether_bricks
fill 322 95 208 322 95 209 minecraft:red_nether_bricks
setblock 322 95 220 minecraft:polished_blackstone
fill 322 95 221 322 96 221 minecraft:red_nether_bricks
setblock 323 95 184 minecraft:polished_blackstone
fill 323 95 185 323 98 185 minecraft:red_nether_bricks
setblock 323 95 204 minecraft:polished_blackstone
fill 323 95 205 323 98 205 minecraft:red_nether_bricks
setblock 323 95 209 minecraft:polished_blackstone
fill 323 95 210 323 98 210 minecraft:red_nether_bricks
setblock 323 95 213 minecraft:red_nether_bricks
setblock 323 95 214 minecraft:polished_blackstone
setblock 323 95 219 minecraft:polished_blackstone
fill 323 95 220 323 98 220 minecraft:red_nether_bricks
setblock 283 96 203 minecraft:polished_blackstone
fill 283 96 204 283 99 204 minecraft:red_nether_bricks
setblock 283 96 208 minecraft:polished_blackstone
fill 283 96 209 283 99 209 minecraft:red_nether_bricks
setblock 283 96 213 minecraft:polished_blackstone
fill 283 96 214 283 99 214 minecraft:red_nether_bricks
fill 284 96 203 284 99 203 minecraft:red_nether_bricks
setblock 284 96 207 minecraft:polished_blackstone
fill 284 96 208 284 99 208 minecraft:red_nether_bricks
fill 284 96 210 284 97 210 minecraft:red_nether_bricks
fill 290 96 182 293 96 182 minecraft:red_nether_bricks
setblock 292 96 183 minecraft:red_nether_bricks
setblock 293 96 183 minecraft:polished_blackstone
setblock 293 96 222 minecraft:red_nether_bricks
setblock 294 96 182 minecraft:polished_blackstone
fill 294 96 183 294 98 184 minecraft:red_nether_bricks
setblock 294 96 222 minecraft:polished_blackstone
fill 295 96 182 295 99 182 minecraft:red_nether_bricks
fill 295 96 222 295 99 222 minecraft:red_nether_bricks
setblock 296 96 184 minecraft:red_nether_bricks
setblock 297 96 184 minecraft:polished_blackstone
setblock 298 96 183 minecraft:polished_blackstone
fill 298 96 184 298 99 184 minecraft:red_nether_bricks
setblock 299 96 182 minecraft:polished_blackstone
fill 299 96 183 299 99 183 minecraft:red_nether_bricks
setblock 299 96 222 minecraft:polished_blackstone
fill 300 96 182 303 96 182 minecraft:red_nether_bricks
fill 300 96 222 300 97 222 minecraft:red_nether_bricks
setblock 302 96 184 minecraft:polished_blackstone
setblock 303 96 183 minecraft:polished_blackstone
setblock 304 96 182 minecraft:polished_blackstone
fill 304 96 183 304 99 183 minecraft:red_nether_bricks
fill 305 96 182 305 99 182 minecraft:red_nether_bricks
setblock 308 96 182 minecraft:red_nether_bricks
setblock 308 96 183 minecraft:polished_blackstone
setblock 309 96 182 minecraft:polished_blackstone
fill 309 96 183 309 98 184 minecraft:red_nether_bricks
setblock 309 96 222 minecraft:polished_blackstone
fill 310 96 182 310 99 182 minecraft:red_nether_bricks
fill 310 96 184 311 96 184 minecraft:red_nether_bricks
fill 310 96 222 310 99 222 minecraft:red_nether_bricks
setblock 312 96 184 minecraft:polished_blackstone
fill 312 96 221 312 98 221 minecraft:red_nether_bricks
setblock 313 96 183 minecraft:polished_blackstone
fill 313 96 184 313 99 184 minecraft:red_nether_bricks
setblock 314 96 182 minecraft:polished_blackstone
fill 314 96 183 314 99 183 minecraft:red_nether_bricks
fill 314 96 185 315 96 185 minecraft:red_nether_bricks
setblock 314 96 222 minecraft:polished_blackstone
fill 315 96 182 315 99 182 minecraft:red_nether_bricks
setblock 315 96 221 minecraft:polished_blackstone
fill 315 96 222 315 99 222 minecraft:red_nether_bricks
setblock 316 96 185 minecraft:polished_blackstone
fill 316 96 221 316 99 221 minecraft:red_nether_bricks
setblock 317 96 184 minecraft:polished_blackstone
fill 317 96 185 317 99 185 minecraft:red_nether_bricks
fill 317 96 220 317 99 220 minecraft:red_nether_bricks
setblock 318 96 183 minecraft:polished_blackstone
fill 318 96 184 318 99 184 minecraft:red_nether_bricks
setblock 319 96 182 minecraft:polished_blackstone
fill 319 96 183 319 99 183 minecraft:red_nether_bricks
setblock 319 96 222 minecraft:polished_blackstone
fill 320 96 182 320 99 182 minecraft:red_nether_bricks
setblock 320 96 221 minecraft:polished_blackstone
fill 320 96 222 320 99 222 minecraft:red_nether_bricks
fill 321 96 221 321 98 221 minecraft:red_nether_bricks
setblock 322 96 184 minecraft:polished_blackstone
fill 322 96 185 322 98 185 minecraft:red_nether_bricks
setblock 322 96 204 minecraft:polished_blackstone
fill 322 96 205 322 99 205 minecraft:red_nether_bricks
setblock 322 96 208 minecraft:red_nether_bricks
setblock 322 96 209 minecraft:polished_blackstone
fill 322 96 210 322 98 211 minecraft:red_nether_bricks
setblock 323 96 183 minecraft:polished_blackstone
fill 323 96 184 323 99 184 minecraft:red_nether_bricks
setblock 323 96 187 minecraft:red_nether_bricks
setblock 323 96 203 minecraft:polished_blackstone
fill 323 96 204 323 99 204 minecraft:red_nether_bricks
setblock 323 96 208 minecraft:polished_blackstone
fill 323 96 209 323 99 209 minecraft:red_nether_bricks
setblock 323 96 213 minecraft:polished_blackstone
fill 323 96 214 323 98 215 minecraft:red_nether_bricks
setblock 323 96 218 minecraft:polished_blackstone
fill 323 96 219 323 99 219 minecraft:red_nether_bricks
fill 283 97 184 283 97 186 minecraft:red_nether_bricks
setblock 283 97 202 minecraft:polished_blackstone
fill 283 97 203 283 100 203 minecraft:red_nether_bricks
setblock 283 97 207 minecraft:polished_blackstone
fill 283 97 208 283 100 208 minecraft:red_nether_bricks
setblock 283 97 212 minecraft:polished_blackstone
fill 283 97 213 283 100 213 minecraft:red_nether_bricks
setblock 284 97 206 minecraft:polished_blackstone
fill 284 97 207 284 100 207 minecraft:red_nether_bricks
setblock 284 97 211 minecraft:polished_blackstone
fill 289 97 182 292 97 182 minecraft:red_nether_bricks
setblock 291 97 183 minecraft:red_nether_bricks
setblock 292 97 183 minecraft:polished_blackstone
setblock 293 97 182 minecraft:polished_blackstone
fill 293 97 183 293 99 184 minecraft:red_nether_bricks
setblock 293 97 222 minecraft:polished_blackstone
fill 294 97 182 294 100 182 minecraft:red_nether_bricks
fill 294 97 222 294 100 222 minecraft:red_nether_bricks
setblock 295 97 185 minecraft:polished_blackstone
setblock 296 97 184 minecraft:polished_blackstone
fill 296 97 185 299 97 185 minecraft:red_nether_bricks
setblock 297 97 183 minecraft:polished_blackstone
fill 297 97 184 297 100 184 minecraft:red_nether_bricks
setblock 298 97 182 minecraft:polished_blackstone
fill 298 97 183 298 100 183 minecraft:red_nether_bricks
setblock 298 97 222 minecraft:polished_blackstone
fill 299 97 182 302 97 182 minecraft:red_nether_bricks
fill 299 97 222 299 98 222 minecraft:red_nether_bricks
setblock 300 97 184 minecraft:red_nether_bricks
setblock 301 97 184 minecraft:polished_blackstone
setblock 302 97 183 minecraft:polished_blackstone
fill 302 97 184 303 99 184 minecraft:red_nether_bricks
setblock 303 97 182 minecraft:polished_blackstone
fill 303 97 183 303 100 183 minecraft:red_nether_bricks
fill 304 97 182 304 100 182 minecraft:red_nether_bricks
setblock 306 97 183 minecraft:red_nether_bricks
setblock 307 97 183 minecraft:polished_blackstone
setblock 308 97 182 minecraft:polished_blackstone
fill 308 97 183 308 99 184 minecraft:red_nether_bricks
setblock 308 97 222 minecraft:polished_blackstone
fill 309 97 182 309 100 182 minecraft:red_nether_bricks
fill 309 97 222 309 100 222 minecraft:red_nether_bricks
setblock 310 97 184 minecraft:red_nether_bricks
fill 311 97 184 311 97 185 minecraft:polished_blackstone
setblock 312 97 183 minecraft:polished_blackstone
fill 312 97 184 312 99 185 minecraft:red_nether_bricks
setblock 313 97 182 minecraft:polished_blackstone
fill 313 97 183 313 100 183 minecraft:red_nether_bricks
fill 313 97 185 314 97 185 minecraft:red_nether_bricks
setblock 313 97 222 minecraft:polished_blackstone
fill 314 97 182 314 100 182 minecraft:red_nether_bricks
setblock 314 97 221 minecraft:polished_blackstone
fill 314 97 222 314 100 222 minecraft:red_nether_bricks
setblock 315 97 185 minecraft:polished_blackstone
fill 315 97 221 315 100 221 minecraft:red_nether_bricks
setblock 316 97 184 minecraft:polished_blackstone
fill 316 97 185 316 100 185 minecraft:red_nether_bricks
fill 316 97 220 316 100 220 minecraft:red_nether_bricks
setblock 317 97 183 minecraft:polished_blackstone
fill 317 97 184 317 100 184 minecraft:red_nether_bricks
setblock 318 97 182 minecraft:polished_blackstone
fill 318 97 183 318 100 183 minecraft:red_nether_bricks
setblock 318 97 222 minecraft:polished_blackstone
fill 319 97 182 319 100 182 minecraft:red_nether_bricks
setblock 319 97 221 minecraft:polished_blackstone
fill 319 97 222 319 100 222 minecraft:red_nether_bricks
fill 320 97 221 320 99 221 minecraft:red_nether_bricks
setblock 322 97 183 minecraft:polished_blackstone
fill 322 97 184 322 98 184 minecraft:red_nether_bricks
setblock 322 97 204 minecraft:red_nether_bricks
setblock 322 97 208 minecraft:polished_blackstone
fill 322 97 209 322 100 209 minecraft:red_nether_bricks
setblock 322 97 212 minecraft:red_nether_bricks
setblock 322 97 213 minecraft:polished_blackstone
setblock 323 97 182 minecraft:polished_blackstone
fill 323 97 183 323 100 183 minecraft:red_nether_bricks
setblock 323 97 187 minecraft:polished_blackstone
setblock 323 97 202 minecraft:polished_blackstone
fill 323 97 203 323 100 203 minecraft:red_nether_bricks
setblock 323 97 207 minecraft:polished_blackstone
fill 323 97 208 323 100 208 minecraft:red_nether_bricks
setblock 323 97 211 minecraft:red_nether_bricks
setblock 323 97 212 minecraft:polished_blackstone
fill 323 97 213 323 100 213 minecraft:red_nether_bricks
setblock 323 97 217 minecraft:polished_blackstone
fill 323 97 218 323 100 218 minecraft:red_nether_bricks
setblock 323 97 222 minecraft:polished_blackstone
fill 283 98 184 283 98 185 minecraft:red_nether_bricks
setblock 283 98 186 minecraft:polished_blackstone
fill 283 98 187 283 100 188 minecraft:red_nether_bricks
setblock 283 98 201 minecraft:polished_blackstone
fill 283 98 202 283 101 202 minecraft:red_nether_bricks
setblock 283 98 206 minecraft:polished_blackstone
fill 283 98 207 283 101 207 minecraft:red_nether_bricks
setblock 283 98 211 minecraft:polished_blackstone
fill 283 98 212 284 100 212 minecraft:red_nether_bricks
setblock 283 98 215 minecraft:red_nether_bricks
setblock 284 98 205 minecraft:polished_blackstone
fill 284 98 206 285 99 206 minecraft:red_nether_bricks
setblock 284 98 210 minecraft:polished_blackstone
fill 284 98 211 284 101 211 minecraft:red_nether_bricks
fill 285 98 207 285 98 208 minecraft:red_nether_bricks
fill 289 98 182 291 98 182 minecraft:red_nether_bricks
setblock 290 98 183 minecraft:red_nether_bricks
setblock 291 98 183 minecraft:polished_blackstone
setblock 292 98 182 minecraft:polished_blackstone
fill 292 98 183 292 100 184 minecraft:red_nether_bricks
setblock 292 98 222 minecraft:polished_blackstone
fill 293 98 182 293 101 182 minecraft:red_nether_bricks
fill 293 98 222 293 101 222 minecraft:red_nether_bricks
setblock 294 98 185 minecraft:polished_blackstone
setblock 295 98 183 minecraft:red_nether_bricks
setblock 295 98 184 minecraft:polished_blackstone
fill 295 98 185 298 98 185 minecraft:red_nether_bricks
setblock 296 98 183 minecraft:polished_blackstone
fill 296 98 184 296 101 184 minecraft:red_nether_bricks
setblock 297 98 182 minecraft:polished_blackstone
fill 297 98 183 297 101 183 minecraft:red_nether_bricks
setblock 297 98 222 minecraft:polished_blackstone
fill 298 98 182 301 98 182 minecraft:red_nether_bricks
fill 298 98 222 298 99 222 minecraft:red_nether_bricks
setblock 299 98 185 minecraft:polished_blackstone
setblock 300 98 184 minecraft:polished_blackstone
setblock 301 98 183 minecraft:polished_blackstone
fill 301 98 184 301 100 184 minecraft:red_nether_bricks
setblock 302 98 182 minecraft:polished_blackstone
fill 302 98 183 302 101 183 minecraft:red_nether_bricks
fill 303 98 182 303 101 182 minecraft:red_nether_bricks
setblock 306 98 183 minecraft:polished_blackstone
fill 306 98 184 307 100 184 minecraft:red_nether_bricks
setblock 307 98 182 minecraft:polished_blackstone
fill 307 98 183 307 101 183 minecraft:red_nether_bricks
fill 308 98 182 308 101 182 minecraft:red_nether_bricks
fill 308 98 222 308 101 222 minecraft:red_nether_bricks
setblock 310 98 184 minecraft:polished_blackstone
setblock 311 98 183 minecraft:polished_blackstone
fill 311 98 184 311 100 185 minecraft:red_nether_bricks
fill 311 98 221 311 99 221 minecraft:red_nether_bricks
setblock 312 98 182 minecraft:polished_blackstone
fill 312 98 183 312 101 183 minecraft:red_nether_bricks
setblock 312 98 222 minecraft:polished_blackstone
fill 313 98 182 313 101 182 minecraft:red_nether_bricks
setblock 313 98 185 minecraft:red_nether_bricks
setblock 313 98 221 minecraft:polished_blackstone
fill 313 98 222 313 101 222 minecraft:red_nether_bricks
setblock 314 98 185 minecraft:polished_blackstone
fill 314 98 221 314 101 221 minecraft:red_nether_bricks
setblock 315 98 184 minecraft:polished_blackstone
fill 315 98 185 315 101 185 minecraft:red_nether_bricks
fill 315 98 220 315 101 220 minecraft:red_nether_bricks
setblock 316 98 183 minecraft:polished_blackstone
fill 316 98 184 316 101 184 minecraft:red_nether_bricks
setblock 317 98 182 minecraft:polished_blackstone
fill 317 98 183 317 101 183 minecraft:red_nether_bricks
setblock 317 98 222 minecraft:polished_blackstone
fill 318 98 182 318 101 182 minecraft:red_nether_bricks
setblock 318 98 221 minecraft:polished_blackstone
fill 318 98 222 318 101 222 minecraft:red_nether_bricks
fill 319 98 221 319 100 221 minecraft:red_nether_bricks
setblock 320 98 184 minecraft:polished_blackstone
setblock 321 98 183 minecraft:polished_blackstone
setblock 321 98 207 minecraft:red_nether_bricks
setblock 321 98 208 minecraft:polished_blackstone
fill 321 98 209 321 100 210 minecraft:red_nether_bricks
setblock 322 98 182 minecraft:polished_blackstone
setblock 322 98 183 minecraft:red_nether_bricks
setblock 322 98 207 minecraft:polished_blackstone
fill 322 98 208 322 101 208 minecraft:red_nether_bricks
setblock 322 98 212 minecraft:polished_blackstone
fill 322 98 213 322 100 214 minecraft:red_nether_bricks
setblock 322 98 222 minecraft:polished_blackstone
fill 323 98 182 323 99 182 minecraft:red_nether_bricks
setblock 323 98 186 minecraft:polished_blackstone
fill 323 98 187 323 100 188 minecraft:red_nether_bricks
setblock 323 98 206 minecraft:polished_blackstone
fill 323 98 207 323 101 207 minecraft:red_nether_bricks
setblock 323 98 211 minecraft:polished_blackstone
fill 323 98 212 323 101 212 minecraft:red_nether_bricks
setblock 323 98 216 minecraft:polished_blackstone
fill 323 98 217 323 101 217 minecraft:red_nether_bricks
setblock 323 98 221 minecraft:polished_blackstone
fill 323 98 222 323 99 222 minecraft:red_nether_bricks
setblock 283 99 185 minecraft:polished_blackstone
fill 283 99 186 283 101 186 minecraft:red_nether_bricks
setblock 283 99 189 minecraft:red_nether_bricks
setblock 283 99 200 minecraft:polished_blackstone
fill 283 99 201 283 101 201 minecraft:red_nether_bricks
setblock 283 99 205 minecraft:polished_blackstone
fill 283 99 206 283 102 206 minecraft:red_nether_bricks
setblock 283 99 210 minecraft:polished_blackstone
fill 283 99 211 283 102 211 minecraft:red_nether_bricks
setblock 283 99 215 minecraft:polished_blackstone
setblock 284 99 204 minecraft:polished_blackstone
fill 284 99 205 284 102 205 minecraft:red_nether_bricks
setblock 284 99 209 minecraft:polished_blackstone
fill 284 99 210 284 102 210 minecraft:red_nether_bricks
setblock 285 99 207 minecraft:red_nether_bricks
setblock 285 99 208 minecraft:polished_blackstone
fill 285 99 209 285 101 209 minecraft:red_nether_bricks
fill 288 99 182 290 99 182 minecraft:red_nether_bricks
setblock 290 99 183 minecraft:polished_blackstone
setblock 291 99 182 minecraft:polished_blackstone
fill 291 99 183 291 101 184 minecraft:red_nether_bricks
fill 292 99 182 292 102 182 minecraft:red_nether_bricks
fill 292 99 222 292 101 222 minecraft:red_nether_bricks
setblock 293 99 185 minecraft:polished_blackstone
setblock 294 99 183 minecraft:red_nether_bricks
setblock 294 99 184 minecraft:polished_blackstone
fill 294 99 185 297 99 185 minecraft:red_nether_bricks
setblock 295 99 183 minecraft:polished_blackstone
fill 295 99 184 295 102 184 minecraft:red_nether_bricks
setblock 296 99 182 minecraft:polished_blackstone
fill 296 99 183 296 102 183 minecraft:red_nether_bricks
setblock 296 99 222 minecraft:polished_blackstone
fill 297 99 182 300 99 182 minecraft:red_nether_bricks
fill 297 99 222 297 100 222 minecraft:red_nether_bricks
setblock 298 99 185 minecraft:polished_blackstone
setblock 299 99 184 minecraft:polished_blackstone
setblock 299 99 185 minecraft:red_nether_bricks
setblock 300 99 183 minecraft:polished_blackstone
fill 300 99 184 300 101 184 minecraft:red_nether_bricks
setblock 301 99 182 minecraft:polished_blackstone
fill 301 99 183 301 101 183 minecraft:red_nether_bricks
fill 302 99 182 302 102 182 minecraft:red_nether_bricks
setblock 305 99 183 minecraft:polished_blackstone
setblock 306 99 182 minecraft:polished_blackstone
fill 306 99 183 306 102 183 minecraft:red_nether_bricks
fill 307 99 182 307 102 182 minecraft:red_nether_bricks
setblock 309 99 183 minecraft:red_nether_bricks
setblock 309 99 184 minecraft:polished_blackstone
setblock 310 99 183 minecraft:polished_blackstone
fill 310 99 184 310 101 185 minecraft:red_nether_bricks
setblock 311 99 182 minecraft:polished_blackstone
fill 311 99 183 311 102 183 minecraft:red_nether_bricks
setblock 311 99 222 minecraft:polished_blackstone
fill 312 99 182 312 102 182 minecraft:red_nether_bricks
setblock 312 99 221 minecraft:polished_blackstone
fill 312 99 222 312 102 222 minecraft:red_nether_bricks
setblock 313 99 185 minecraft:polished_blackstone
fill 313 99 221 313 102 221 minecraft:red_nether_bricks
setblock 314 99 184 minecraft:polished_blackstone
fill 314 99 185 314 101 185 minecraft:red_nether_bricks
fill 314 99 220 314 101 220 minecraft:red_nether_bricks
setblock 315 99 183 minecraft:polished_blackstone
fill 315 99 184 315 102 184 minecraft:red_nether_bricks
setblock 316 99 182 minecraft:polished_blackstone
fill 316 99 183 316 102 183 minecraft:red_nether_bricks
setblock 316 99 222 minecraft:polished_blackstone
fill 317 99 182 317 102 182 minecraft:red_nether_bricks
setblock 317 99 221 minecraft:polished_blackstone
fill 317 99 222 317 102 222 minecraft:red_nether_bricks
fill 318 99 221 318 101 221 minecraft:red_nether_bricks
setblock 319 99 184 minecraft:polished_blackstone
setblock 320 99 183 minecraft:polished_blackstone
setblock 321 99 182 minecraft:polished_blackstone
setblock 321 99 183 minecraft:red_nether_bricks
setblock 321 99 207 minecraft:polished_blackstone
fill 321 99 208 321 100 208 minecraft:red_nether_bricks
setblock 321 99 211 minecraft:red_nether_bricks
setblock 321 99 212 minecraft:polished_blackstone
setblock 321 99 222 minecraft:polished_blackstone
fill 322 99 182 322 100 182 minecraft:red_nether_bricks
setblock 322 99 206 minecraft:polished_blackstone
fill 322 99 207 322 102 207 minecraft:red_nether_bricks
setblock 322 99 210 minecraft:red_nether_bricks
setblock 322 99 211 minecraft:polished_blackstone
fill 322 99 212 322 102 212 minecraft:red_nether_bricks
setblock 322 99 215 minecraft:red_nether_bricks
fill 322 99 222 322 100 222 minecraft:red_nether_bricks
setblock 323 99 185 minecraft:polished_blackstone
fill 323 99 186 323 101 186 minecraft:red_nether_bricks
setblock 323 99 205 minecraft:polished_blackstone
fill 323 99 206 323 102 206 minecraft:red_nether_bricks
setblock 323 99 210 minecraft:polished_blackstone
fill 323 99 211 323 102 211 minecraft:red_nether_bricks
setblock 323 99 214 minecraft:red_nether_bricks
setblock 323 99 215 minecraft:polished_blackstone
fill 323 99 216 323 102 216 minecraft:red_nether_bricks
setblock 323 99 220 minecraft:polished_blackstone
setblock 323 99 221 minecraft:red_nether_bricks
setblock 283 100 189 minecraft:polished_blackstone
fill 283 100 190 283 102 191 minecraft:red_nether_bricks
setblock 283 100 204 minecraft:polished_blackstone
fill 283 100 205 283 103 205 minecraft:red_nether_bricks
setblock 283 100 209 minecraft:polished_blackstone
fill 283 100 210 283 103 210 minecraft:red_nether_bricks
setblock 283 100 214 minecraft:polished_blackstone
fill 283 100 215 283 103 215 minecraft:red_nether_bricks
setblock 284 100 203 minecraft:polished_blackstone
fill 284 100 204 284 101 204 minecraft:red_nether_bricks
fill 284 100 206 284 101 206 minecraft:red_nether_bricks
setblock 284 100 208 minecraft:polished_blackstone
fill 284 100 209 284 103 209 minecraft:red_nether_bricks
setblock 284 100 213 minecraft:polished_blackstone
setblock 285 100 184 minecraft:light[level=14]
setblock 285 100 192 minecraft:light[level=14]
setblock 285 100 200 minecraft:light[level=14]
setblock 285 100 207 minecraft:polished_blackstone
fill 285 100 208 285 101 208 minecraft:red_nether_bricks
setblock 285 100 216 minecraft:light[level=14]
fill 288 100 182 289 100 182 minecraft:red_nether_bricks
setblock 290 100 182 minecraft:polished_blackstone
fill 290 100 183 290 102 183 minecraft:red_nether_bricks
fill 291 100 182 291 103 182 minecraft:red_nether_bricks
setblock 293 100 183 minecraft:red_nether_bricks
setblock 293 100 184 minecraft:polished_blackstone
fill 293 100 185 296 100 185 minecraft:red_nether_bricks
setblock 293 100 192 minecraft:light[level=14]
setblock 293 100 200 minecraft:light[level=14]
schedule function dropper:buildpart/42_5 1t
