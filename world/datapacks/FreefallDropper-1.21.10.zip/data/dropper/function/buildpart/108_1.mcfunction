fill 23 92 486 24 92 487 minecraft:black_concrete
fill 24 92 480 32 92 480 minecraft:black_concrete
fill 24 92 488 32 92 488 minecraft:black_concrete
fill 25 92 479 26 92 479 minecraft:black_concrete
setblock 25 92 481 minecraft:black_concrete
setblock 25 92 487 minecraft:black_concrete
fill 25 92 489 26 92 489 minecraft:black_concrete
fill 27 92 478 29 92 478 minecraft:black_concrete
fill 28 92 479 31 92 479 minecraft:black_concrete
setblock 28 92 489 minecraft:black_concrete
fill 30 92 489 31 92 489 minecraft:black_concrete
fill 31 92 481 33 92 481 minecraft:black_concrete
fill 31 92 487 33 92 487 minecraft:black_concrete
fill 32 92 482 32 92 486 minecraft:black_concrete
setblock 33 92 482 minecraft:black_concrete
fill 33 92 484 33 92 486 minecraft:black_concrete
setblock 34 92 485 minecraft:black_concrete
setblock 1 95 466 minecraft:bookshelf
fill 1 95 469 1 158 469 minecraft:bookshelf
setblock 1 95 473 minecraft:bookshelf
fill 1 95 476 1 158 476 minecraft:bookshelf
setblock 1 95 480 minecraft:bookshelf
fill 1 95 483 1 158 483 minecraft:bookshelf
setblock 1 95 487 minecraft:bookshelf
fill 1 95 490 1 158 490 minecraft:bookshelf
setblock 1 95 494 minecraft:bookshelf
fill 1 95 497 1 158 497 minecraft:bookshelf
setblock 1 95 501 minecraft:bookshelf
fill 1 95 504 1 158 504 minecraft:bookshelf
fill 3 95 464 3 158 464 minecraft:bookshelf
setblock 5 95 504 minecraft:bookshelf
fill 6 95 464 20 95 464 minecraft:bookshelf
fill 7 95 465 19 116 469 minecraft:bookshelf
fill 8 95 504 8 158 504 minecraft:bookshelf
setblock 12 95 504 minecraft:bookshelf
fill 15 95 504 15 158 504 minecraft:bookshelf
setblock 19 95 504 minecraft:bookshelf
fill 22 95 504 22 158 504 minecraft:bookshelf
fill 24 95 464 24 158 464 minecraft:bookshelf
fill 26 95 468 27 95 469 minecraft:blue_wool
setblock 26 95 504 minecraft:bookshelf
setblock 27 95 464 minecraft:bookshelf
fill 29 95 504 29 158 504 minecraft:bookshelf
fill 31 95 464 31 158 464 minecraft:bookshelf
fill 32 95 497 41 96 504 minecraft:bookshelf
setblock 34 95 464 minecraft:bookshelf
fill 38 95 464 38 158 464 minecraft:bookshelf
fill 39 95 481 41 95 485 minecraft:bookshelf
setblock 41 95 464 minecraft:bookshelf
fill 41 95 468 41 158 468 minecraft:bookshelf
setblock 41 95 471 minecraft:bookshelf
fill 41 95 475 41 158 475 minecraft:bookshelf
setblock 41 95 478 minecraft:bookshelf
fill 41 95 489 41 158 489 minecraft:bookshelf
setblock 41 95 492 minecraft:bookshelf
fill 41 95 496 41 158 496 minecraft:bookshelf
setblock 1 96 467 minecraft:bookshelf
setblock 1 96 474 minecraft:bookshelf
setblock 1 96 481 minecraft:bookshelf
setblock 1 96 488 minecraft:bookshelf
setblock 1 96 495 minecraft:bookshelf
setblock 1 96 502 minecraft:bookshelf
setblock 5 96 464 minecraft:bookshelf
setblock 6 96 504 minecraft:bookshelf
fill 7 96 464 19 116 464 minecraft:bookshelf
setblock 13 96 504 minecraft:bookshelf
setblock 20 96 504 minecraft:bookshelf
setblock 26 96 464 minecraft:bookshelf
setblock 27 96 504 minecraft:bookshelf
setblock 33 96 464 minecraft:bookshelf
fill 39 96 484 41 96 488 minecraft:bookshelf
setblock 40 96 464 minecraft:bookshelf
setblock 41 96 470 minecraft:bookshelf
setblock 41 96 477 minecraft:bookshelf
fill 41 96 482 41 158 482 minecraft:bookshelf
fill 41 96 491 41 98 491 minecraft:bookshelf
setblock 1 97 468 minecraft:bookshelf
setblock 1 97 475 minecraft:bookshelf
setblock 1 97 482 minecraft:bookshelf
setblock 1 97 489 minecraft:bookshelf
setblock 1 97 496 minecraft:bookshelf
setblock 1 97 503 minecraft:bookshelf
setblock 3 97 466 minecraft:light[level=12]
setblock 3 97 474 minecraft:light[level=12]
setblock 3 97 482 minecraft:light[level=12]
setblock 3 97 490 minecraft:light[level=12]
setblock 3 97 498 minecraft:light[level=12]
setblock 4 97 464 minecraft:bookshelf
setblock 7 97 504 minecraft:bookshelf
setblock 11 97 474 minecraft:light[level=12]
setblock 11 97 482 minecraft:light[level=12]
setblock 11 97 490 minecraft:light[level=12]
setblock 11 97 498 minecraft:light[level=12]
setblock 14 97 504 minecraft:bookshelf
setblock 19 97 474 minecraft:light[level=12]
setblock 19 97 482 minecraft:light[level=12]
setblock 19 97 490 minecraft:light[level=12]
setblock 19 97 498 minecraft:light[level=12]
setblock 21 97 504 minecraft:bookshelf
setblock 25 97 464 minecraft:bookshelf
setblock 27 97 466 minecraft:light[level=12]
setblock 27 97 474 minecraft:light[level=12]
setblock 27 97 482 minecraft:light[level=12]
setblock 27 97 490 minecraft:light[level=12]
setblock 27 97 498 minecraft:light[level=12]
setblock 28 97 504 minecraft:bookshelf
setblock 32 97 464 minecraft:bookshelf
setblock 32 97 497 minecraft:ochre_froglight
fill 32 97 498 32 109 498 minecraft:bookshelf
setblock 32 97 499 minecraft:ochre_froglight
fill 32 97 500 32 109 500 minecraft:bookshelf
setblock 32 97 501 minecraft:ochre_froglight
fill 32 97 502 32 109 502 minecraft:bookshelf
setblock 32 97 503 minecraft:ochre_froglight
fill 32 97 504 32 110 504 minecraft:bookshelf
fill 33 97 497 33 109 497 minecraft:bookshelf
setblock 33 97 498 minecraft:ochre_froglight
fill 33 97 499 33 109 499 minecraft:bookshelf
setblock 33 97 500 minecraft:ochre_froglight
fill 33 97 501 33 109 501 minecraft:bookshelf
setblock 33 97 502 minecraft:ochre_froglight
fill 33 97 503 33 109 503 minecraft:bookshelf
setblock 33 97 504 minecraft:ochre_froglight
setblock 34 97 497 minecraft:ochre_froglight
fill 34 97 498 34 109 498 minecraft:bookshelf
setblock 34 97 499 minecraft:ochre_froglight
fill 34 97 500 34 109 500 minecraft:bookshelf
setblock 34 97 501 minecraft:ochre_froglight
fill 34 97 502 34 109 502 minecraft:bookshelf
setblock 34 97 503 minecraft:ochre_froglight
fill 34 97 504 34 110 504 minecraft:bookshelf
setblock 35 97 466 minecraft:light[level=12]
setblock 35 97 474 minecraft:light[level=12]
setblock 35 97 482 minecraft:light[level=12]
setblock 35 97 490 minecraft:light[level=12]
fill 35 97 497 35 109 497 minecraft:bookshelf
setblock 35 97 498 minecraft:ochre_froglight
fill 35 97 499 35 109 499 minecraft:bookshelf
setblock 35 97 500 minecraft:ochre_froglight
fill 35 97 501 35 109 501 minecraft:bookshelf
setblock 35 97 502 minecraft:ochre_froglight
fill 35 97 503 35 109 503 minecraft:bookshelf
setblock 35 97 504 minecraft:ochre_froglight
setblock 36 97 497 minecraft:ochre_froglight
fill 36 97 498 36 109 498 minecraft:bookshelf
setblock 36 97 499 minecraft:ochre_froglight
fill 36 97 500 36 109 500 minecraft:bookshelf
setblock 36 97 501 minecraft:ochre_froglight
fill 36 97 502 36 109 502 minecraft:bookshelf
setblock 36 97 503 minecraft:ochre_froglight
fill 36 97 504 36 158 504 minecraft:bookshelf
fill 37 97 497 37 109 497 minecraft:bookshelf
setblock 37 97 498 minecraft:ochre_froglight
fill 37 97 499 37 109 499 minecraft:bookshelf
setblock 37 97 500 minecraft:ochre_froglight
fill 37 97 501 37 109 501 minecraft:bookshelf
setblock 37 97 502 minecraft:ochre_froglight
fill 37 97 503 37 109 503 minecraft:bookshelf
setblock 37 97 504 minecraft:ochre_froglight
setblock 38 97 497 minecraft:ochre_froglight
fill 38 97 498 38 109 498 minecraft:bookshelf
setblock 38 97 499 minecraft:ochre_froglight
fill 38 97 500 38 109 500 minecraft:bookshelf
setblock 38 97 501 minecraft:ochre_froglight
fill 38 97 502 38 109 502 minecraft:bookshelf
setblock 38 97 503 minecraft:ochre_froglight
fill 38 97 504 38 110 504 minecraft:bookshelf
setblock 39 97 464 minecraft:bookshelf
fill 39 97 487 40 97 491 minecraft:bookshelf
fill 39 97 497 39 109 497 minecraft:bookshelf
setblock 39 97 498 minecraft:ochre_froglight
fill 39 97 499 39 109 499 minecraft:bookshelf
setblock 39 97 500 minecraft:ochre_froglight
fill 39 97 501 39 109 501 minecraft:bookshelf
setblock 39 97 502 minecraft:ochre_froglight
fill 39 97 503 39 109 503 minecraft:bookshelf
setblock 39 97 504 minecraft:ochre_froglight
setblock 40 97 497 minecraft:ochre_froglight
fill 40 97 498 40 109 498 minecraft:bookshelf
setblock 40 97 499 minecraft:ochre_froglight
fill 40 97 500 40 109 500 minecraft:bookshelf
setblock 40 97 501 minecraft:ochre_froglight
fill 40 97 502 40 109 502 minecraft:bookshelf
setblock 40 97 503 minecraft:ochre_froglight
fill 40 97 504 40 110 504 minecraft:bookshelf
setblock 41 97 469 minecraft:bookshelf
setblock 41 97 476 minecraft:bookshelf
setblock 41 97 483 minecraft:bookshelf
fill 41 97 487 41 97 488 minecraft:bookshelf
setblock 41 97 490 minecraft:bookshelf
fill 41 97 492 41 98 492 minecraft:bookshelf
fill 41 97 497 41 111 497 minecraft:bookshelf
setblock 41 97 498 minecraft:ochre_froglight
fill 41 97 499 41 110 499 minecraft:bookshelf
setblock 41 97 500 minecraft:ochre_froglight
fill 41 97 501 41 110 501 minecraft:bookshelf
setblock 41 97 502 minecraft:ochre_froglight
fill 41 97 503 41 158 503 minecraft:bookshelf
setblock 41 97 504 minecraft:ochre_froglight
fill 42 97 464 42 97 496 minecraft:dark_oak_planks
setblock 42 97 497 minecraft:ochre_froglight
fill 42 97 498 42 101 498 minecraft:dark_oak_planks
setblock 42 97 499 minecraft:ochre_froglight
fill 42 97 500 42 101 500 minecraft:dark_oak_planks
setblock 42 97 501 minecraft:ochre_froglight
fill 42 97 502 42 101 502 minecraft:dark_oak_planks
setblock 42 97 503 minecraft:ochre_froglight
fill 42 97 504 42 101 504 minecraft:dark_oak_planks
fill 0 98 463 5 101 463 minecraft:dark_oak_planks
setblock 0 98 464 minecraft:bookshelf
fill 0 98 465 0 98 482 minecraft:dark_oak_planks
setblock 0 98 483 minecraft:bookshelf
fill 0 98 484 0 98 492 minecraft:dark_oak_planks
setblock 0 98 493 minecraft:bookshelf
fill 0 98 494 0 98 505 minecraft:dark_oak_planks
fill 1 98 505 22 98 505 minecraft:dark_oak_planks
setblock 6 98 463 minecraft:bookshelf
fill 7 98 463 13 98 463 minecraft:dark_oak_planks
setblock 14 98 463 minecraft:bookshelf
fill 15 98 463 26 98 463 minecraft:dark_oak_planks
setblock 23 98 505 minecraft:bookshelf
fill 24 98 505 26 101 505 minecraft:dark_oak_planks
setblock 27 98 463 minecraft:bookshelf
setblock 27 98 505 minecraft:bookshelf
fill 28 98 463 32 98 463 minecraft:dark_oak_planks
fill 28 98 505 32 101 505 minecraft:dark_oak_planks
fill 32 98 497 32 99 497 minecraft:bookshelf
fill 32 98 499 32 99 499 minecraft:bookshelf
fill 32 98 501 32 99 501 minecraft:bookshelf
fill 32 98 503 32 99 503 minecraft:bookshelf
setblock 33 98 463 minecraft:bookshelf
fill 33 98 498 33 99 498 minecraft:bookshelf
fill 33 98 500 33 99 500 minecraft:bookshelf
fill 33 98 502 33 99 502 minecraft:bookshelf
fill 33 98 504 33 98 505 minecraft:bookshelf
fill 34 98 463 38 98 463 minecraft:dark_oak_planks
fill 34 98 497 34 99 497 minecraft:bookshelf
fill 34 98 499 34 99 499 minecraft:bookshelf
fill 34 98 501 34 99 501 minecraft:bookshelf
fill 34 98 503 34 99 503 minecraft:bookshelf
fill 34 98 505 35 101 505 minecraft:dark_oak_planks
fill 35 98 498 35 99 498 minecraft:bookshelf
fill 35 98 500 35 99 500 minecraft:bookshelf
fill 35 98 502 35 99 502 minecraft:bookshelf
fill 35 98 504 35 99 504 minecraft:bookshelf
fill 36 98 497 36 99 497 minecraft:bookshelf
fill 36 98 499 36 99 499 minecraft:bookshelf
fill 36 98 501 36 99 501 minecraft:bookshelf
fill 36 98 503 36 99 503 minecraft:bookshelf
setblock 36 98 505 minecraft:bookshelf
fill 37 98 498 37 99 498 minecraft:bookshelf
fill 37 98 500 37 99 500 minecraft:bookshelf
fill 37 98 502 37 99 502 minecraft:bookshelf
fill 37 98 504 37 99 504 minecraft:bookshelf
fill 37 98 505 42 98 505 minecraft:dark_oak_planks
fill 38 98 485 40 99 485 minecraft:gold_block
fill 38 98 497 38 99 497 minecraft:bookshelf
fill 38 98 499 38 99 499 minecraft:bookshelf
fill 38 98 501 38 99 501 minecraft:bookshelf
fill 38 98 503 38 99 503 minecraft:bookshelf
setblock 39 98 463 minecraft:bookshelf
fill 39 98 490 40 98 495 minecraft:bookshelf
fill 39 98 498 39 99 498 minecraft:bookshelf
fill 39 98 500 39 99 500 minecraft:bookshelf
fill 39 98 502 39 99 502 minecraft:bookshelf
fill 39 98 504 39 99 504 minecraft:bookshelf
fill 40 98 463 42 101 463 minecraft:dark_oak_planks
fill 40 98 497 40 99 497 minecraft:bookshelf
fill 40 98 499 40 99 499 minecraft:bookshelf
fill 40 98 501 40 99 501 minecraft:bookshelf
fill 40 98 503 40 99 503 minecraft:bookshelf
fill 41 98 493 41 98 495 minecraft:bookshelf
fill 41 98 498 41 99 498 minecraft:bookshelf
fill 41 98 500 41 99 500 minecraft:bookshelf
fill 41 98 502 41 99 502 minecraft:bookshelf
fill 41 98 504 41 99 504 minecraft:bookshelf
fill 42 98 464 42 99 466 minecraft:dark_oak_planks
setblock 42 98 467 minecraft:bookshelf
fill 42 98 468 42 101 470 minecraft:dark_oak_planks
fill 42 98 471 42 99 471 minecraft:bookshelf
fill 42 98 472 42 98 491 minecraft:dark_oak_planks
setblock 42 98 492 minecraft:bookshelf
fill 42 98 493 42 99 493 minecraft:dark_oak_planks
setblock 42 98 494 minecraft:bookshelf
fill 42 98 495 42 99 497 minecraft:dark_oak_planks
setblock 42 98 499 minecraft:dark_oak_planks
fill 42 98 501 42 99 501 minecraft:dark_oak_planks
fill 42 98 503 42 99 503 minecraft:dark_oak_planks
fill 0 99 464 0 99 475 minecraft:dark_oak_planks
fill 0 99 476 0 100 476 minecraft:bookshelf
fill 0 99 477 0 99 490 minecraft:dark_oak_planks
fill 0 99 491 1 99 491 minecraft:bookshelf
fill 0 99 492 0 101 496 minecraft:dark_oak_planks
setblock 0 99 497 minecraft:bookshelf
fill 0 99 498 0 101 505 minecraft:dark_oak_planks
fill 1 99 470 1 100 470 minecraft:bookshelf
fill 1 99 477 1 100 477 minecraft:bookshelf
fill 1 99 484 1 100 484 minecraft:bookshelf
fill 1 99 498 1 100 498 minecraft:bookshelf
fill 1 99 505 10 101 505 minecraft:dark_oak_planks
fill 2 99 464 2 100 464 minecraft:bookshelf
fill 2 99 504 2 100 504 minecraft:bookshelf
fill 6 99 463 10 101 463 minecraft:dark_oak_planks
fill 9 99 504 9 100 504 minecraft:bookshelf
fill 11 99 463 12 99 463 minecraft:bookshelf
setblock 11 99 505 minecraft:bookshelf
fill 12 99 505 17 99 505 minecraft:dark_oak_planks
fill 13 99 463 18 101 463 minecraft:dark_oak_planks
fill 16 99 504 16 100 504 minecraft:bookshelf
fill 18 99 505 18 100 505 minecraft:bookshelf
setblock 19 99 463 minecraft:bookshelf
fill 19 99 505 23 99 505 minecraft:dark_oak_planks
fill 20 99 463 21 101 463 minecraft:dark_oak_planks
fill 20 99 501 21 100 501 minecraft:green_wool
fill 21 99 500 21 100 500 minecraft:green_wool
fill 22 99 463 23 99 463 minecraft:bookshelf
fill 23 99 464 23 100 464 minecraft:bookshelf
fill 23 99 504 23 100 504 minecraft:bookshelf
fill 24 99 463 31 101 463 minecraft:dark_oak_planks
fill 27 99 505 27 101 505 minecraft:dark_oak_planks
fill 30 99 464 30 100 464 minecraft:bookshelf
fill 30 99 504 30 100 504 minecraft:bookshelf
setblock 32 99 463 minecraft:bookshelf
fill 33 99 463 36 101 463 minecraft:dark_oak_planks
setblock 33 99 504 minecraft:bookshelf
setblock 33 99 505 minecraft:dark_oak_planks
fill 36 99 505 40 101 505 minecraft:dark_oak_planks
fill 37 99 463 37 99 464 minecraft:bookshelf
setblock 38 99 463 minecraft:bookshelf
fill 39 99 463 39 101 463 minecraft:dark_oak_planks
fill 39 99 493 39 99 496 minecraft:bookshelf
fill 40 99 494 40 99 496 minecraft:bookshelf
fill 41 99 467 41 100 467 minecraft:bookshelf
fill 41 99 474 41 100 474 minecraft:bookshelf
fill 41 99 481 41 100 481 minecraft:bookshelf
fill 41 99 488 42 99 488 minecraft:bookshelf
fill 41 99 494 41 100 495 minecraft:bookshelf
setblock 41 99 505 minecraft:bookshelf
fill 42 99 467 42 101 467 minecraft:dark_oak_planks
fill 42 99 472 42 99 487 minecraft:dark_oak_planks
fill 42 99 489 42 99 492 minecraft:dark_oak_planks
fill 42 99 494 42 101 494 minecraft:dark_oak_planks
setblock 42 99 499 minecraft:bookshelf
setblock 42 99 505 minecraft:dark_oak_planks
fill 0 100 464 0 101 469 minecraft:dark_oak_planks
setblock 0 100 470 minecraft:bookshelf
fill 0 100 471 0 101 475 minecraft:dark_oak_planks
fill 0 100 477 0 101 479 minecraft:dark_oak_planks
fill 0 100 480 1 100 480 minecraft:bookshelf
fill 0 100 481 0 101 484 minecraft:dark_oak_planks
fill 0 100 485 1 100 485 minecraft:bookshelf
fill 0 100 486 0 101 487 minecraft:dark_oak_planks
fill 0 100 488 1 100 488 minecraft:bookshelf
fill 0 100 489 0 101 491 minecraft:dark_oak_planks
fill 0 100 497 0 103 497 minecraft:dark_oak_planks
fill 1 100 464 1 100 468 minecraft:bookshelf
fill 1 100 471 1 100 475 minecraft:bookshelf
fill 1 100 478 1 100 479 minecraft:bookshelf
fill 1 100 481 1 100 482 minecraft:bookshelf
fill 1 100 486 1 100 487 minecraft:bookshelf
setblock 1 100 489 minecraft:bookshelf
fill 1 100 491 1 100 496 minecraft:bookshelf
fill 1 100 499 1 100 503 minecraft:bookshelf
fill 3 100 504 7 100 504 minecraft:bookshelf
fill 4 100 464 6 100 464 minecraft:bookshelf
fill 10 100 504 14 100 504 minecraft:bookshelf
fill 11 100 463 12 101 463 minecraft:dark_oak_planks
fill 11 100 505 13 101 505 minecraft:dark_oak_planks
setblock 14 100 505 minecraft:bookshelf
fill 15 100 505 15 101 505 minecraft:dark_oak_planks
setblock 16 100 505 minecraft:bookshelf
fill 17 100 504 21 100 504 minecraft:bookshelf
fill 17 100 505 17 101 505 minecraft:dark_oak_planks
fill 19 100 463 19 101 463 minecraft:dark_oak_planks
fill 19 100 505 21 101 505 minecraft:dark_oak_planks
fill 20 100 464 22 100 464 minecraft:bookshelf
fill 22 100 463 23 101 463 minecraft:dark_oak_planks
setblock 22 100 505 minecraft:bookshelf
fill 23 100 505 23 102 505 minecraft:dark_oak_planks
fill 24 100 504 28 100 504 minecraft:bookshelf
fill 25 100 464 29 100 464 minecraft:bookshelf
setblock 31 100 504 minecraft:bookshelf
fill 32 100 463 32 102 463 minecraft:dark_oak_planks
fill 32 100 464 37 100 464 minecraft:bookshelf
setblock 32 100 497 minecraft:ochre_froglight
setblock 32 100 499 minecraft:ochre_froglight
setblock 32 100 501 minecraft:ochre_froglight
setblock 32 100 503 minecraft:ochre_froglight
setblock 33 100 498 minecraft:ochre_froglight
setblock 33 100 500 minecraft:ochre_froglight
setblock 33 100 502 minecraft:ochre_froglight
setblock 33 100 504 minecraft:ochre_froglight
setblock 33 100 505 minecraft:bookshelf
setblock 34 100 497 minecraft:ochre_froglight
setblock 34 100 499 minecraft:ochre_froglight
setblock 34 100 501 minecraft:ochre_froglight
setblock 34 100 503 minecraft:ochre_froglight
setblock 35 100 498 minecraft:ochre_froglight
setblock 35 100 500 minecraft:ochre_froglight
setblock 35 100 502 minecraft:ochre_froglight
setblock 35 100 504 minecraft:ochre_froglight
setblock 36 100 497 minecraft:ochre_froglight
setblock 36 100 499 minecraft:ochre_froglight
setblock 36 100 501 minecraft:ochre_froglight
setblock 36 100 503 minecraft:ochre_froglight
fill 37 100 463 38 101 463 minecraft:dark_oak_planks
setblock 37 100 498 minecraft:ochre_froglight
setblock 37 100 500 minecraft:ochre_froglight
setblock 37 100 502 minecraft:ochre_froglight
setblock 37 100 504 minecraft:ochre_froglight
setblock 38 100 497 minecraft:ochre_froglight
setblock 38 100 499 minecraft:ochre_froglight
setblock 38 100 501 minecraft:ochre_froglight
setblock 38 100 503 minecraft:ochre_froglight
fill 39 100 464 42 100 464 minecraft:bookshelf
setblock 39 100 498 minecraft:ochre_froglight
setblock 39 100 500 minecraft:ochre_froglight
setblock 39 100 502 minecraft:ochre_froglight
setblock 39 100 504 minecraft:ochre_froglight
setblock 40 100 497 minecraft:ochre_froglight
setblock 40 100 499 minecraft:ochre_froglight
setblock 40 100 501 minecraft:ochre_froglight
setblock 40 100 503 minecraft:ochre_froglight
fill 41 100 465 41 100 466 minecraft:bookshelf
fill 41 100 469 41 100 473 minecraft:bookshelf
fill 41 100 476 41 100 480 minecraft:bookshelf
fill 41 100 483 41 100 488 minecraft:bookshelf
fill 41 100 490 41 100 493 minecraft:bookshelf
setblock 41 100 498 minecraft:ochre_froglight
setblock 41 100 500 minecraft:ochre_froglight
setblock 41 100 502 minecraft:ochre_froglight
setblock 41 100 504 minecraft:ochre_froglight
fill 41 100 505 41 101 505 minecraft:dark_oak_planks
setblock 42 100 465 minecraft:bookshelf
fill 42 100 466 42 101 466 minecraft:dark_oak_planks
fill 42 100 471 42 102 471 minecraft:dark_oak_planks
setblock 42 100 472 minecraft:bookshelf
fill 42 100 473 42 101 480 minecraft:dark_oak_planks
setblock 42 100 481 minecraft:bookshelf
fill 42 100 482 42 102 483 minecraft:dark_oak_planks
setblock 42 100 484 minecraft:bookshelf
fill 42 100 485 42 102 485 minecraft:dark_oak_planks
setblock 42 100 486 minecraft:bookshelf
fill 42 100 487 42 101 488 minecraft:dark_oak_planks
setblock 42 100 489 minecraft:bookshelf
fill 42 100 490 42 101 491 minecraft:dark_oak_planks
fill 42 100 492 42 100 493 minecraft:bookshelf
fill 42 100 495 42 101 496 minecraft:dark_oak_planks
setblock 42 100 497 minecraft:ochre_froglight
setblock 42 100 499 minecraft:ochre_froglight
setblock 42 100 501 minecraft:ochre_froglight
setblock 42 100 503 minecraft:ochre_froglight
setblock 42 100 505 minecraft:bookshelf
setblock 0 101 470 minecraft:dark_oak_planks
setblock 0 101 476 minecraft:dark_oak_planks
fill 0 101 480 0 103 480 minecraft:dark_oak_planks
setblock 0 101 485 minecraft:dark_oak_planks
setblock 0 101 488 minecraft:dark_oak_planks
setblock 1 101 465 minecraft:bookshelf
setblock 1 101 472 minecraft:bookshelf
setblock 1 101 479 minecraft:bookshelf
setblock 1 101 486 minecraft:bookshelf
setblock 1 101 493 minecraft:bookshelf
setblock 1 101 500 minecraft:bookshelf
setblock 4 101 504 minecraft:bookshelf
setblock 11 101 504 minecraft:bookshelf
setblock 14 101 505 minecraft:dark_oak_planks
fill 16 101 505 16 102 505 minecraft:dark_oak_planks
setblock 18 101 504 minecraft:bookshelf
setblock 18 101 505 minecraft:dark_oak_planks
setblock 21 101 464 minecraft:bookshelf
setblock 22 101 505 minecraft:dark_oak_planks
setblock 25 101 504 minecraft:bookshelf
setblock 28 101 464 minecraft:bookshelf
fill 32 101 497 32 102 497 minecraft:bookshelf
fill 32 101 499 32 102 499 minecraft:bookshelf
fill 32 101 501 32 102 501 minecraft:bookshelf
fill 32 101 503 32 102 503 minecraft:bookshelf
fill 33 101 498 33 102 498 minecraft:bookshelf
fill 33 101 500 33 102 500 minecraft:bookshelf
fill 33 101 502 33 102 502 minecraft:bookshelf
fill 33 101 504 33 102 504 minecraft:bookshelf
setblock 33 101 505 minecraft:dark_oak_planks
fill 34 101 497 34 102 497 minecraft:bookshelf
fill 34 101 499 34 102 499 minecraft:bookshelf
fill 34 101 501 34 102 501 minecraft:bookshelf
fill 34 101 503 34 102 503 minecraft:bookshelf
setblock 35 101 464 minecraft:bookshelf
fill 35 101 498 35 102 498 minecraft:bookshelf
fill 35 101 500 35 102 500 minecraft:bookshelf
fill 35 101 502 35 102 502 minecraft:bookshelf
fill 35 101 504 35 102 504 minecraft:bookshelf
fill 36 101 497 36 102 497 minecraft:bookshelf
fill 36 101 499 36 102 499 minecraft:bookshelf
fill 36 101 501 36 102 501 minecraft:bookshelf
fill 36 101 503 36 102 503 minecraft:bookshelf
fill 37 101 498 37 102 498 minecraft:bookshelf
fill 37 101 500 37 102 500 minecraft:bookshelf
fill 37 101 502 37 102 502 minecraft:bookshelf
fill 37 101 504 37 102 504 minecraft:bookshelf
fill 38 101 497 38 102 497 minecraft:bookshelf
fill 38 101 499 38 102 499 minecraft:bookshelf
fill 38 101 501 38 102 501 minecraft:bookshelf
fill 38 101 503 38 102 503 minecraft:bookshelf
fill 39 101 498 39 102 498 minecraft:bookshelf
fill 39 101 500 39 102 500 minecraft:bookshelf
fill 39 101 502 39 102 502 minecraft:bookshelf
fill 39 101 504 39 102 504 minecraft:bookshelf
fill 40 101 497 40 102 497 minecraft:bookshelf
fill 40 101 499 40 102 499 minecraft:bookshelf
fill 40 101 501 40 102 501 minecraft:bookshelf
fill 40 101 503 40 102 503 minecraft:bookshelf
setblock 41 101 465 minecraft:bookshelf
setblock 41 101 472 minecraft:bookshelf
setblock 41 101 479 minecraft:bookshelf
setblock 41 101 486 minecraft:bookshelf
setblock 41 101 493 minecraft:bookshelf
fill 41 101 498 41 102 498 minecraft:bookshelf
fill 41 101 500 41 102 500 minecraft:bookshelf
fill 41 101 502 41 102 502 minecraft:bookshelf
fill 41 101 504 41 102 504 minecraft:bookshelf
fill 42 101 464 42 101 465 minecraft:dark_oak_planks
setblock 42 101 472 minecraft:dark_oak_planks
setblock 42 101 481 minecraft:dark_oak_planks
setblock 42 101 484 minecraft:dark_oak_planks
setblock 42 101 486 minecraft:dark_oak_planks
setblock 42 101 489 minecraft:dark_oak_planks
fill 42 101 492 42 101 493 minecraft:dark_oak_planks
setblock 42 101 497 minecraft:dark_oak_planks
fill 42 101 499 42 102 499 minecraft:dark_oak_planks
setblock 42 101 501 minecraft:dark_oak_planks
setblock 42 101 503 minecraft:dark_oak_planks
setblock 42 101 505 minecraft:dark_oak_planks
fill 0 102 463 0 103 479 minecraft:bookshelf
fill 0 102 481 0 102 493 minecraft:bookshelf
setblock 0 102 494 minecraft:dark_oak_planks
fill 0 102 495 0 204 496 minecraft:bookshelf
fill 0 102 498 0 103 505 minecraft:bookshelf
fill 1 102 463 8 102 463 minecraft:bookshelf
setblock 1 102 466 minecraft:bookshelf
setblock 1 102 473 minecraft:bookshelf
setblock 1 102 480 minecraft:bookshelf
setblock 1 102 487 minecraft:bookshelf
setblock 1 102 494 minecraft:bookshelf
setblock 1 102 501 minecraft:bookshelf
fill 1 102 505 1 103 505 minecraft:bookshelf
fill 2 102 505 2 103 505 minecraft:dark_oak_planks
fill 3 102 505 15 102 505 minecraft:bookshelf
setblock 5 102 504 minecraft:bookshelf
setblock 6 102 464 minecraft:bookshelf
fill 9 102 463 10 102 463 minecraft:dark_oak_planks
fill 11 102 463 14 102 463 minecraft:bookshelf
setblock 12 102 504 minecraft:bookshelf
setblock 15 102 463 minecraft:dark_oak_planks
fill 16 102 463 27 102 463 minecraft:bookshelf
fill 17 102 505 22 102 505 minecraft:bookshelf
setblock 19 102 504 minecraft:bookshelf
setblock 20 102 464 minecraft:bookshelf
setblock 24 102 505 minecraft:dark_oak_planks
fill 25 102 505 31 103 505 minecraft:bookshelf
fill 26 102 504 26 104 504 minecraft:bookshelf
setblock 27 102 464 minecraft:bookshelf
setblock 28 102 463 minecraft:dark_oak_planks
fill 29 102 463 29 103 463 minecraft:bookshelf
fill 29 102 502 31 102 503 minecraft:bookshelf
setblock 30 102 463 minecraft:dark_oak_planks
fill 30 102 504 31 103 504 minecraft:bookshelf
fill 31 102 463 31 204 463 minecraft:bookshelf
setblock 32 102 505 minecraft:dark_oak_planks
fill 33 102 463 42 102 463 minecraft:bookshelf
fill 33 102 505 42 102 505 minecraft:bookshelf
setblock 34 102 464 minecraft:bookshelf
fill 41 102 464 42 102 464 minecraft:bookshelf
setblock 41 102 471 minecraft:bookshelf
fill 41 102 478 42 102 478 minecraft:bookshelf
setblock 41 102 485 minecraft:bookshelf
fill 41 102 492 42 102 492 minecraft:bookshelf
fill 42 102 465 42 102 468 minecraft:bookshelf
fill 42 102 469 42 102 470 minecraft:dark_oak_planks
fill 42 102 472 42 103 477 minecraft:bookshelf
fill 42 102 479 42 102 481 minecraft:bookshelf
fill 42 102 484 42 200 484 minecraft:bookshelf
setblock 42 102 486 minecraft:bookshelf
setblock 42 102 487 minecraft:dark_oak_planks
fill 42 102 488 42 200 491 minecraft:bookshelf
fill 42 102 493 42 102 494 minecraft:bookshelf
setblock 42 102 495 minecraft:dark_oak_planks
fill 42 102 496 42 102 498 minecraft:bookshelf
fill 42 102 500 42 102 504 minecraft:bookshelf
setblock 0 103 481 minecraft:dark_oak_planks
fill 0 103 482 0 200 494 minecraft:bookshelf
fill 1 103 463 7 103 463 minecraft:bookshelf
setblock 1 103 467 minecraft:bookshelf
setblock 1 103 474 minecraft:bookshelf
setblock 1 103 481 minecraft:bookshelf
setblock 1 103 488 minecraft:bookshelf
setblock 1 103 495 minecraft:bookshelf
setblock 1 103 502 minecraft:bookshelf
setblock 3 103 505 minecraft:dark_oak_planks
fill 4 103 505 6 200 505 minecraft:bookshelf
setblock 5 103 464 minecraft:bookshelf
setblock 6 103 504 minecraft:bookshelf
setblock 7 103 505 minecraft:dark_oak_planks
setblock 8 103 463 minecraft:dark_oak_planks
fill 8 103 505 21 103 505 minecraft:bookshelf
fill 9 103 463 12 103 463 minecraft:bookshelf
setblock 13 103 463 minecraft:dark_oak_planks
setblock 13 103 504 minecraft:bookshelf
fill 14 103 463 19 103 463 minecraft:bookshelf
setblock 20 103 463 minecraft:dark_oak_planks
setblock 20 103 504 minecraft:bookshelf
fill 21 103 463 28 200 463 minecraft:bookshelf
setblock 22 103 505 minecraft:dark_oak_planks
fill 23 103 505 24 202 505 minecraft:bookshelf
setblock 26 103 464 minecraft:bookshelf
fill 26 103 502 30 103 503 minecraft:bookshelf
fill 27 103 504 28 104 504 minecraft:bookshelf
setblock 30 103 463 minecraft:bookshelf
setblock 31 103 503 minecraft:bookshelf
fill 32 103 463 35 200 463 minecraft:bookshelf
setblock 32 103 497 minecraft:ochre_froglight
setblock 32 103 499 minecraft:ochre_froglight
setblock 32 103 501 minecraft:ochre_froglight
setblock 32 103 503 minecraft:ochre_froglight
fill 32 103 505 33 204 505 minecraft:bookshelf
setblock 33 103 464 minecraft:bookshelf
setblock 33 103 498 minecraft:ochre_froglight
setblock 33 103 500 minecraft:ochre_froglight
setblock 33 103 502 minecraft:ochre_froglight
setblock 33 103 504 minecraft:ochre_froglight
setblock 34 103 497 minecraft:ochre_froglight
setblock 34 103 499 minecraft:ochre_froglight
setblock 34 103 501 minecraft:ochre_froglight
setblock 34 103 503 minecraft:ochre_froglight
setblock 34 103 505 minecraft:dark_oak_planks
setblock 35 103 498 minecraft:ochre_froglight
setblock 35 103 500 minecraft:ochre_froglight
setblock 35 103 502 minecraft:ochre_froglight
setblock 35 103 504 minecraft:ochre_froglight
fill 35 103 505 42 103 505 minecraft:bookshelf
setblock 36 103 463 minecraft:dark_oak_planks
setblock 36 103 497 minecraft:ochre_froglight
setblock 36 103 499 minecraft:ochre_froglight
setblock 36 103 501 minecraft:ochre_froglight
setblock 36 103 503 minecraft:ochre_froglight
fill 37 103 463 42 103 463 minecraft:bookshelf
setblock 37 103 498 minecraft:ochre_froglight
setblock 37 103 500 minecraft:ochre_froglight
setblock 37 103 502 minecraft:ochre_froglight
setblock 37 103 504 minecraft:ochre_froglight
fill 38 103 489 40 104 489 minecraft:gold_block
setblock 38 103 497 minecraft:ochre_froglight
setblock 38 103 499 minecraft:ochre_froglight
setblock 38 103 501 minecraft:ochre_froglight
setblock 38 103 503 minecraft:ochre_froglight
setblock 39 103 498 minecraft:ochre_froglight
setblock 39 103 500 minecraft:ochre_froglight
setblock 39 103 502 minecraft:ochre_froglight
setblock 39 103 504 minecraft:ochre_froglight
setblock 40 103 464 minecraft:bookshelf
setblock 40 103 497 minecraft:ochre_froglight
setblock 40 103 499 minecraft:ochre_froglight
setblock 40 103 501 minecraft:ochre_froglight
setblock 40 103 503 minecraft:ochre_froglight
fill 41 103 470 42 103 470 minecraft:bookshelf
setblock 41 103 477 minecraft:bookshelf
setblock 41 103 484 minecraft:bookshelf
setblock 41 103 491 minecraft:bookshelf
setblock 41 103 498 minecraft:ochre_froglight
setblock 41 103 500 minecraft:ochre_froglight
setblock 41 103 502 minecraft:ochre_froglight
setblock 41 103 504 minecraft:ochre_froglight
fill 42 103 464 42 204 464 minecraft:bookshelf
setblock 42 103 465 minecraft:dark_oak_planks
fill 42 103 466 42 201 469 minecraft:bookshelf
fill 42 103 471 42 204 471 minecraft:bookshelf
fill 42 103 478 42 103 479 minecraft:bookshelf
setblock 42 103 480 minecraft:dark_oak_planks
fill 42 103 481 42 103 483 minecraft:bookshelf
fill 42 103 485 42 200 485 minecraft:bookshelf
setblock 42 103 486 minecraft:dark_oak_planks
fill 42 103 487 42 204 487 minecraft:bookshelf
fill 42 103 492 42 204 492 minecraft:bookshelf
setblock 42 103 493 minecraft:dark_oak_planks
fill 42 103 494 42 200 496 minecraft:bookshelf
setblock 42 103 497 minecraft:ochre_froglight
fill 42 103 498 42 204 498 minecraft:bookshelf
setblock 42 103 499 minecraft:ochre_froglight
fill 42 103 500 42 204 500 minecraft:bookshelf
setblock 42 103 501 minecraft:ochre_froglight
fill 42 103 502 42 201 502 minecraft:bookshelf
setblock 42 103 503 minecraft:ochre_froglight
setblock 42 103 504 minecraft:dark_oak_planks
fill 0 104 463 0 201 470 minecraft:bookshelf
setblock 0 104 471 minecraft:dark_oak_planks
fill 0 104 472 0 200 481 minecraft:bookshelf
fill 0 104 497 0 204 497 minecraft:bookshelf
setblock 0 104 498 minecraft:dark_oak_planks
fill 0 104 499 0 200 505 minecraft:bookshelf
setblock 1 104 463 minecraft:dark_oak_planks
setblock 1 104 468 minecraft:bookshelf
setblock 1 104 475 minecraft:bookshelf
setblock 1 104 482 minecraft:bookshelf
setblock 1 104 489 minecraft:bookshelf
setblock 1 104 496 minecraft:bookshelf
setblock 1 104 503 minecraft:bookshelf
setblock 1 104 505 minecraft:dark_oak_planks
fill 2 104 463 4 204 463 minecraft:bookshelf
fill 2 104 505 3 204 505 minecraft:bookshelf
setblock 4 104 464 minecraft:bookshelf
setblock 5 104 463 minecraft:dark_oak_planks
fill 6 104 463 9 201 463 minecraft:bookshelf
fill 7 104 504 7 104 505 minecraft:bookshelf
fill 8 104 505 11 201 505 minecraft:bookshelf
setblock 10 104 463 minecraft:dark_oak_planks
fill 11 104 463 15 201 463 minecraft:bookshelf
setblock 12 104 505 minecraft:dark_oak_planks
fill 13 104 505 22 200 505 minecraft:bookshelf
setblock 14 104 504 minecraft:bookshelf
fill 16 104 463 17 104 463 minecraft:dark_oak_planks
fill 18 104 463 20 201 463 minecraft:bookshelf
fill 21 104 504 21 106 504 minecraft:bookshelf
fill 23 104 502 25 104 504 minecraft:bookshelf
setblock 25 104 464 minecraft:bookshelf
fill 25 104 505 25 200 505 minecraft:bookshelf
fill 26 104 502 27 104 503 minecraft:bookshelf
setblock 26 104 505 minecraft:dark_oak_planks
fill 27 104 505 31 201 505 minecraft:bookshelf
fill 29 104 463 30 104 463 minecraft:dark_oak_planks
setblock 32 104 464 minecraft:bookshelf
fill 32 104 497 32 105 497 minecraft:bookshelf
fill 32 104 499 32 105 499 minecraft:bookshelf
fill 32 104 501 32 105 501 minecraft:bookshelf
fill 32 104 503 32 105 503 minecraft:bookshelf
fill 33 104 498 33 105 498 minecraft:bookshelf
fill 33 104 500 33 105 500 minecraft:bookshelf
fill 33 104 502 33 105 502 minecraft:bookshelf
fill 33 104 504 33 105 504 minecraft:bookshelf
fill 34 104 497 34 105 497 minecraft:bookshelf
fill 34 104 499 34 105 499 minecraft:bookshelf
fill 34 104 501 34 105 501 minecraft:bookshelf
fill 34 104 503 34 105 503 minecraft:bookshelf
fill 34 104 505 41 200 505 minecraft:bookshelf
fill 35 104 498 35 105 498 minecraft:bookshelf
fill 35 104 500 35 105 500 minecraft:bookshelf
fill 35 104 502 35 105 502 minecraft:bookshelf
fill 35 104 504 35 105 504 minecraft:bookshelf
fill 36 104 463 37 204 463 minecraft:bookshelf
fill 36 104 497 36 105 497 minecraft:bookshelf
fill 36 104 499 36 105 499 minecraft:bookshelf
fill 36 104 501 36 105 501 minecraft:bookshelf
fill 36 104 503 36 105 503 minecraft:bookshelf
fill 37 104 498 37 105 498 minecraft:bookshelf
fill 37 104 500 37 105 500 minecraft:bookshelf
fill 37 104 502 37 105 502 minecraft:bookshelf
fill 37 104 504 37 105 504 minecraft:bookshelf
setblock 38 104 463 minecraft:dark_oak_planks
fill 38 104 497 38 105 497 minecraft:bookshelf
fill 38 104 499 38 105 499 minecraft:bookshelf
fill 38 104 501 38 105 501 minecraft:bookshelf
fill 38 104 503 38 105 503 minecraft:bookshelf
fill 39 104 463 39 104 464 minecraft:bookshelf
fill 39 104 498 39 105 498 minecraft:bookshelf
fill 39 104 500 39 105 500 minecraft:bookshelf
fill 39 104 502 39 105 502 minecraft:bookshelf
fill 39 104 504 39 105 504 minecraft:bookshelf
fill 40 104 463 42 202 463 minecraft:bookshelf
fill 40 104 497 40 105 497 minecraft:bookshelf
fill 40 104 499 40 105 499 minecraft:bookshelf
fill 40 104 501 40 105 501 minecraft:bookshelf
fill 40 104 503 40 105 503 minecraft:bookshelf
setblock 41 104 469 minecraft:bookshelf
fill 41 104 476 42 104 476 minecraft:bookshelf
fill 41 104 483 42 104 483 minecraft:bookshelf
setblock 41 104 490 minecraft:bookshelf
fill 41 104 498 41 105 498 minecraft:bookshelf
fill 41 104 500 41 105 500 minecraft:bookshelf
fill 41 104 502 41 105 502 minecraft:bookshelf
fill 41 104 504 42 105 504 minecraft:bookshelf
fill 42 104 465 42 204 465 minecraft:bookshelf
fill 42 104 470 42 204 470 minecraft:bookshelf
fill 42 104 472 42 201 475 minecraft:bookshelf
setblock 42 104 477 minecraft:dark_oak_planks
fill 42 104 478 42 205 478 minecraft:bookshelf
setblock 42 104 479 minecraft:dark_oak_planks
fill 42 104 480 42 204 480 minecraft:bookshelf
setblock 42 104 481 minecraft:dark_oak_planks
fill 42 104 482 42 201 482 minecraft:bookshelf
fill 42 104 486 42 201 486 minecraft:bookshelf
fill 42 104 493 42 204 493 minecraft:bookshelf
fill 42 104 497 42 105 497 minecraft:bookshelf
fill 42 104 499 42 105 499 minecraft:bookshelf
fill 42 104 501 42 105 501 minecraft:bookshelf
setblock 42 104 503 minecraft:dark_oak_planks
setblock 42 104 505 minecraft:dark_oak_planks
fill 0 105 471 0 201 471 minecraft:bookshelf
fill 0 105 498 0 204 498 minecraft:bookshelf
fill 1 105 463 1 204 463 minecraft:bookshelf
fill 1 105 505 1 204 505 minecraft:bookshelf
setblock 3 105 466 minecraft:light[level=12]
setblock 3 105 474 minecraft:light[level=12]
setblock 3 105 482 minecraft:light[level=12]
setblock 3 105 490 minecraft:light[level=12]
setblock 3 105 498 minecraft:light[level=12]
fill 5 105 463 5 201 463 minecraft:bookshelf
fill 7 105 505 7 204 505 minecraft:bookshelf
fill 10 105 463 10 204 463 minecraft:bookshelf
setblock 11 105 474 minecraft:light[level=12]
setblock 11 105 482 minecraft:light[level=12]
setblock 11 105 490 minecraft:light[level=12]
setblock 11 105 498 minecraft:light[level=12]
fill 12 105 505 12 204 505 minecraft:bookshelf
fill 16 105 463 17 204 463 minecraft:bookshelf
setblock 19 105 474 minecraft:light[level=12]
setblock 19 105 482 minecraft:light[level=12]
setblock 19 105 490 minecraft:light[level=12]
setblock 19 105 498 minecraft:light[level=12]
fill 20 105 502 20 106 504 minecraft:bookshelf
fill 21 105 502 24 105 503 minecraft:bookshelf
fill 23 105 504 24 105 504 minecraft:bookshelf
fill 26 105 505 26 202 505 minecraft:bookshelf
setblock 27 105 466 minecraft:light[level=12]
setblock 27 105 474 minecraft:light[level=12]
setblock 27 105 482 minecraft:light[level=12]
setblock 27 105 490 minecraft:light[level=12]
setblock 27 105 498 minecraft:light[level=12]
fill 29 105 463 30 201 463 minecraft:bookshelf
setblock 35 105 466 minecraft:light[level=12]
setblock 35 105 474 minecraft:light[level=12]
setblock 35 105 482 minecraft:light[level=12]
setblock 35 105 490 minecraft:light[level=12]
fill 38 105 463 39 204 463 minecraft:bookshelf
fill 42 105 476 42 204 477 minecraft:bookshelf
fill 42 105 479 42 202 479 minecraft:bookshelf
fill 42 105 481 42 204 481 minecraft:bookshelf
fill 42 105 483 42 204 483 minecraft:bookshelf
setblock 42 105 503 minecraft:bookshelf
fill 42 105 505 42 201 505 minecraft:bookshelf
setblock 1 106 470 minecraft:bookshelf
setblock 1 106 477 minecraft:bookshelf
setblock 1 106 484 minecraft:bookshelf
setblock 1 106 491 minecraft:bookshelf
setblock 1 106 498 minecraft:bookshelf
setblock 2 106 464 minecraft:bookshelf
setblock 2 106 504 minecraft:bookshelf
setblock 9 106 504 minecraft:bookshelf
fill 16 106 504 19 106 504 minecraft:bookshelf
fill 17 106 502 19 106 503 minecraft:bookshelf
fill 21 106 502 21 106 503 minecraft:bookshelf
setblock 23 106 464 minecraft:bookshelf
setblock 23 106 504 minecraft:bookshelf
setblock 30 106 464 minecraft:bookshelf
setblock 30 106 504 minecraft:bookshelf
setblock 32 106 497 minecraft:ochre_froglight
setblock 32 106 499 minecraft:ochre_froglight
setblock 32 106 501 minecraft:ochre_froglight
setblock 32 106 503 minecraft:ochre_froglight
setblock 33 106 498 minecraft:ochre_froglight
setblock 33 106 500 minecraft:ochre_froglight
setblock 33 106 502 minecraft:ochre_froglight
setblock 33 106 504 minecraft:ochre_froglight
setblock 34 106 497 minecraft:ochre_froglight
setblock 34 106 499 minecraft:ochre_froglight
setblock 34 106 501 minecraft:ochre_froglight
setblock 34 106 503 minecraft:ochre_froglight
setblock 35 106 498 minecraft:ochre_froglight
setblock 35 106 500 minecraft:ochre_froglight
setblock 35 106 502 minecraft:ochre_froglight
setblock 35 106 504 minecraft:ochre_froglight
setblock 36 106 497 minecraft:ochre_froglight
setblock 36 106 499 minecraft:ochre_froglight
setblock 36 106 501 minecraft:ochre_froglight
setblock 36 106 503 minecraft:ochre_froglight
setblock 37 106 464 minecraft:bookshelf
setblock 37 106 498 minecraft:ochre_froglight
setblock 37 106 500 minecraft:ochre_froglight
setblock 37 106 502 minecraft:ochre_froglight
setblock 37 106 504 minecraft:ochre_froglight
setblock 38 106 497 minecraft:ochre_froglight
setblock 38 106 499 minecraft:ochre_froglight
setblock 38 106 501 minecraft:ochre_froglight
setblock 38 106 503 minecraft:ochre_froglight
setblock 39 106 498 minecraft:ochre_froglight
setblock 39 106 500 minecraft:ochre_froglight
setblock 39 106 502 minecraft:ochre_froglight
setblock 39 106 504 minecraft:ochre_froglight
setblock 40 106 497 minecraft:ochre_froglight
setblock 40 106 499 minecraft:ochre_froglight
setblock 40 106 501 minecraft:ochre_froglight
setblock 40 106 503 minecraft:ochre_froglight
setblock 41 106 467 minecraft:bookshelf
setblock 41 106 474 minecraft:bookshelf
setblock 41 106 481 minecraft:bookshelf
setblock 41 106 488 minecraft:bookshelf
setblock 41 106 495 minecraft:bookshelf
setblock 41 106 498 minecraft:ochre_froglight
setblock 41 106 500 minecraft:ochre_froglight
setblock 41 106 502 minecraft:ochre_froglight
setblock 41 106 504 minecraft:ochre_froglight
setblock 42 106 497 minecraft:ochre_froglight
setblock 42 106 499 minecraft:ochre_froglight
setblock 42 106 501 minecraft:ochre_froglight
setblock 42 106 503 minecraft:ochre_froglight
fill 42 106 504 42 204 504 minecraft:bookshelf
setblock 1 107 464 minecraft:bookshelf
setblock 1 107 471 minecraft:bookshelf
setblock 1 107 478 minecraft:bookshelf
setblock 1 107 485 minecraft:bookshelf
setblock 1 107 492 minecraft:bookshelf
setblock 1 107 499 minecraft:bookshelf
setblock 3 107 504 minecraft:bookshelf
fill 10 107 504 10 110 504 minecraft:bookshelf
fill 13 107 504 14 108 504 minecraft:bookshelf
fill 14 107 502 18 107 503 minecraft:bookshelf
fill 16 107 504 18 107 504 minecraft:bookshelf
setblock 22 107 464 minecraft:bookshelf
setblock 24 107 504 minecraft:bookshelf
setblock 29 107 464 minecraft:bookshelf
setblock 31 107 504 minecraft:bookshelf
fill 32 107 497 32 109 497 minecraft:bookshelf
fill 32 107 499 32 109 499 minecraft:bookshelf
fill 32 107 501 32 109 501 minecraft:bookshelf
fill 32 107 503 32 109 503 minecraft:bookshelf
fill 33 107 498 33 109 498 minecraft:bookshelf
fill 33 107 500 33 109 500 minecraft:bookshelf
fill 33 107 502 33 109 502 minecraft:bookshelf
fill 33 107 504 33 110 504 minecraft:bookshelf
fill 34 107 497 34 109 497 minecraft:bookshelf
fill 34 107 499 34 109 499 minecraft:bookshelf
fill 34 107 501 34 109 501 minecraft:bookshelf
fill 34 107 503 34 109 503 minecraft:bookshelf
fill 35 107 498 35 109 498 minecraft:bookshelf
fill 35 107 500 35 109 500 minecraft:bookshelf
fill 35 107 502 35 109 502 minecraft:bookshelf
fill 35 107 504 35 111 504 minecraft:bookshelf
setblock 36 107 464 minecraft:bookshelf
fill 36 107 497 36 109 497 minecraft:bookshelf
fill 36 107 499 36 109 499 minecraft:bookshelf
fill 36 107 501 36 109 501 minecraft:bookshelf
fill 36 107 503 36 109 503 minecraft:bookshelf
fill 37 107 498 37 109 498 minecraft:bookshelf
fill 37 107 500 37 109 500 minecraft:bookshelf
fill 37 107 502 37 109 502 minecraft:bookshelf
fill 37 107 504 37 110 504 minecraft:bookshelf
fill 38 107 497 38 109 497 minecraft:bookshelf
fill 38 107 499 38 109 499 minecraft:bookshelf
fill 38 107 501 38 109 501 minecraft:bookshelf
fill 38 107 503 38 109 503 minecraft:bookshelf
fill 39 107 498 39 109 498 minecraft:bookshelf
fill 39 107 500 39 109 500 minecraft:bookshelf
fill 39 107 502 39 109 502 minecraft:bookshelf
fill 39 107 504 39 110 504 minecraft:bookshelf
fill 40 107 497 40 109 497 minecraft:bookshelf
fill 40 107 499 40 109 499 minecraft:bookshelf
fill 40 107 501 40 109 501 minecraft:bookshelf
fill 40 107 503 40 109 503 minecraft:bookshelf
setblock 41 107 466 minecraft:bookshelf
setblock 41 107 473 minecraft:bookshelf
setblock 41 107 480 minecraft:bookshelf
setblock 41 107 487 minecraft:bookshelf
setblock 41 107 494 minecraft:bookshelf
fill 41 107 498 41 110 498 minecraft:bookshelf
fill 41 107 500 41 110 500 minecraft:bookshelf
fill 41 107 502 41 110 502 minecraft:bookshelf
fill 41 107 504 41 110 504 minecraft:bookshelf
fill 42 107 497 42 202 497 minecraft:bookshelf
fill 42 107 499 42 204 499 minecraft:bookshelf
fill 42 107 501 42 200 501 minecraft:bookshelf
fill 42 107 503 42 204 503 minecraft:bookshelf
setblock 1 108 465 minecraft:bookshelf
setblock 1 108 472 minecraft:bookshelf
setblock 1 108 479 minecraft:bookshelf
setblock 1 108 486 minecraft:bookshelf
setblock 1 108 493 minecraft:bookshelf
setblock 1 108 500 minecraft:bookshelf
fill 4 108 504 4 110 504 minecraft:bookshelf
fill 9 108 504 9 110 504 minecraft:bookshelf
fill 10 108 502 15 108 503 minecraft:bookshelf
fill 11 108 504 12 110 504 minecraft:bookshelf
fill 14 108 475 15 109 475 minecraft:white_wool
setblock 18 108 504 minecraft:bookshelf
setblock 21 108 464 minecraft:bookshelf
setblock 25 108 504 minecraft:bookshelf
setblock 28 108 464 minecraft:bookshelf
setblock 35 108 464 minecraft:bookshelf
setblock 41 108 465 minecraft:bookshelf
setblock 41 108 472 minecraft:bookshelf
setblock 41 108 479 minecraft:bookshelf
setblock 41 108 486 minecraft:bookshelf
setblock 41 108 493 minecraft:bookshelf
fill 1 109 466 1 110 466 minecraft:bookshelf
fill 1 109 473 1 110 473 minecraft:bookshelf
fill 1 109 480 1 110 480 minecraft:bookshelf
fill 1 109 487 1 110 487 minecraft:bookshelf
fill 1 109 494 1 110 494 minecraft:bookshelf
fill 1 109 501 1 111 501 minecraft:bookshelf
fill 5 109 503 7 110 504 minecraft:bookshelf
fill 6 109 464 6 110 464 minecraft:bookshelf
fill 6 109 502 12 109 502 minecraft:bookshelf
fill 8 109 503 11 109 503 minecraft:bookshelf
fill 19 109 504 19 110 504 minecraft:bookshelf
fill 20 109 464 20 110 464 minecraft:bookshelf
fill 26 109 504 26 110 504 minecraft:bookshelf
fill 27 109 464 27 110 464 minecraft:bookshelf
fill 34 109 464 34 110 464 minecraft:bookshelf
fill 41 109 464 41 110 464 minecraft:bookshelf
fill 41 109 471 41 110 471 minecraft:bookshelf
fill 41 109 478 41 110 478 minecraft:bookshelf
fill 41 109 485 41 110 485 minecraft:bookshelf
fill 41 109 492 41 110 492 minecraft:bookshelf
fill 1 110 464 1 110 465 minecraft:bookshelf
fill 1 110 467 1 110 468 minecraft:bookshelf
fill 1 110 470 1 110 472 minecraft:bookshelf
fill 1 110 474 1 110 475 minecraft:bookshelf
fill 1 110 477 1 110 479 minecraft:bookshelf
fill 1 110 481 1 110 482 minecraft:bookshelf
fill 1 110 484 1 110 486 minecraft:bookshelf
fill 1 110 488 1 110 489 minecraft:bookshelf
fill 1 110 491 1 110 493 minecraft:bookshelf
fill 1 110 495 1 110 496 minecraft:bookshelf
fill 1 110 498 1 111 500 minecraft:bookshelf
fill 1 110 502 4 110 503 minecraft:bookshelf
setblock 2 110 464 minecraft:bookshelf
fill 2 110 501 3 111 501 minecraft:bookshelf
fill 2 110 504 3 110 504 minecraft:bookshelf
fill 3 110 500 3 111 500 minecraft:bookshelf
fill 4 110 464 5 110 464 minecraft:bookshelf
fill 5 110 502 8 110 502 minecraft:bookshelf
fill 13 110 504 14 110 504 minecraft:bookshelf
fill 16 110 504 18 110 504 minecraft:bookshelf
fill 20 110 504 21 110 504 minecraft:bookshelf
fill 21 110 464 23 110 464 minecraft:bookshelf
fill 23 110 504 25 110 504 minecraft:bookshelf
fill 25 110 464 26 110 464 minecraft:bookshelf
fill 27 110 504 28 110 504 minecraft:bookshelf
fill 28 110 464 30 110 464 minecraft:bookshelf
fill 30 110 504 31 110 504 minecraft:bookshelf
fill 32 110 464 33 110 464 minecraft:bookshelf
fill 35 110 464 37 110 464 minecraft:bookshelf
fill 39 110 464 40 110 464 minecraft:bookshelf
fill 41 110 465 41 110 467 minecraft:bookshelf
fill 41 110 469 41 110 470 minecraft:bookshelf
fill 41 110 472 41 110 474 minecraft:bookshelf
fill 41 110 476 41 110 477 minecraft:bookshelf
fill 41 110 479 41 110 481 minecraft:bookshelf
fill 41 110 483 41 110 484 minecraft:bookshelf
fill 41 110 486 41 110 488 minecraft:bookshelf
fill 41 110 490 41 110 491 minecraft:bookshelf
fill 41 110 493 41 110 495 minecraft:bookshelf
setblock 1 111 468 minecraft:bookshelf
setblock 1 111 475 minecraft:bookshelf
setblock 1 111 482 minecraft:bookshelf
setblock 1 111 489 minecraft:bookshelf
fill 1 111 496 3 112 496 minecraft:bookshelf
fill 1 111 502 2 111 503 minecraft:bookshelf
fill 2 111 497 2 111 500 minecraft:bookshelf
fill 3 111 497 3 111 499 minecraft:bookshelf
setblock 3 111 502 minecraft:bookshelf
setblock 4 111 464 minecraft:bookshelf
fill 7 111 496 7 112 496 minecraft:green_wool
setblock 7 111 504 minecraft:bookshelf
setblock 14 111 504 minecraft:bookshelf
setblock 21 111 504 minecraft:bookshelf
setblock 25 111 464 minecraft:bookshelf
setblock 28 111 504 minecraft:bookshelf
setblock 32 111 464 minecraft:bookshelf
setblock 39 111 464 minecraft:bookshelf
setblock 41 111 469 minecraft:bookshelf
setblock 41 111 476 minecraft:bookshelf
setblock 41 111 483 minecraft:bookshelf
setblock 41 111 490 minecraft:bookshelf
fill 1 112 493 3 112 495 minecraft:bookshelf
fill 1 112 498 1 112 499 minecraft:bookshelf
fill 2 112 492 3 113 492 minecraft:bookshelf
fill 2 112 497 2 112 498 minecraft:bookshelf
setblock 3 112 497 minecraft:bookshelf
setblock 1 113 470 minecraft:bookshelf
setblock 1 113 477 minecraft:bookshelf
setblock 1 113 484 minecraft:bookshelf
fill 1 113 489 3 114 489 minecraft:bookshelf
fill 1 113 491 1 113 494 minecraft:bookshelf
setblock 1 113 498 minecraft:bookshelf
setblock 2 113 464 minecraft:bookshelf
fill 2 113 490 3 113 491 minecraft:bookshelf
fill 2 113 493 2 113 494 minecraft:bookshelf
setblock 2 113 504 minecraft:bookshelf
setblock 3 113 466 minecraft:light[level=12]
setblock 3 113 474 minecraft:light[level=12]
setblock 3 113 482 minecraft:light[level=12]
setblock 3 113 493 minecraft:bookshelf
setblock 3 113 498 minecraft:light[level=12]
setblock 9 113 504 minecraft:bookshelf
setblock 11 113 474 minecraft:light[level=12]
setblock 11 113 482 minecraft:light[level=12]
setblock 11 113 490 minecraft:light[level=12]
setblock 11 113 498 minecraft:light[level=12]
setblock 16 113 504 minecraft:bookshelf
setblock 19 113 474 minecraft:light[level=12]
setblock 19 113 482 minecraft:light[level=12]
setblock 19 113 490 minecraft:light[level=12]
setblock 19 113 498 minecraft:light[level=12]
setblock 23 113 464 minecraft:bookshelf
setblock 23 113 504 minecraft:bookshelf
setblock 27 113 466 minecraft:light[level=12]
setblock 27 113 474 minecraft:light[level=12]
setblock 27 113 482 minecraft:light[level=12]
setblock 27 113 490 minecraft:light[level=12]
setblock 27 113 498 minecraft:light[level=12]
setblock 30 113 464 minecraft:bookshelf
setblock 30 113 504 minecraft:bookshelf
setblock 35 113 466 minecraft:light[level=12]
setblock 35 113 474 minecraft:light[level=12]
setblock 35 113 482 minecraft:light[level=12]
setblock 35 113 490 minecraft:light[level=12]
setblock 35 113 498 minecraft:light[level=12]
setblock 37 113 464 minecraft:bookshelf
setblock 37 113 504 minecraft:bookshelf
setblock 41 113 467 minecraft:bookshelf
setblock 41 113 474 minecraft:bookshelf
setblock 41 113 481 minecraft:bookshelf
setblock 41 113 488 minecraft:bookshelf
setblock 41 113 495 minecraft:bookshelf
setblock 41 113 502 minecraft:bookshelf
setblock 1 114 464 minecraft:bookshelf
setblock 1 114 471 minecraft:bookshelf
setblock 1 114 478 minecraft:bookshelf
fill 1 114 485 1 114 488 minecraft:bookshelf
setblock 1 114 492 minecraft:bookshelf
setblock 1 114 499 minecraft:bookshelf
fill 2 114 486 3 114 488 minecraft:bookshelf
fill 2 114 490 3 114 490 minecraft:bookshelf
setblock 3 114 504 minecraft:bookshelf
setblock 10 114 504 minecraft:bookshelf
setblock 17 114 504 minecraft:bookshelf
setblock 22 114 464 minecraft:bookshelf
setblock 24 114 504 minecraft:bookshelf
setblock 29 114 464 minecraft:bookshelf
fill 29 114 469 31 115 470 minecraft:white_wool
setblock 31 114 504 minecraft:bookshelf
setblock 36 114 464 minecraft:bookshelf
setblock 38 114 504 minecraft:bookshelf
setblock 41 114 466 minecraft:bookshelf
setblock 41 114 473 minecraft:bookshelf
setblock 41 114 480 minecraft:bookshelf
setblock 41 114 487 minecraft:bookshelf
setblock 41 114 494 minecraft:bookshelf
setblock 41 114 501 minecraft:bookshelf
setblock 1 115 465 minecraft:bookshelf
setblock 1 115 472 minecraft:bookshelf
setblock 1 115 479 minecraft:bookshelf
fill 1 115 484 3 115 487 minecraft:bookshelf
setblock 1 115 493 minecraft:bookshelf
setblock 1 115 500 minecraft:bookshelf
fill 2 115 483 3 116 483 minecraft:bookshelf
setblock 4 115 504 minecraft:bookshelf
setblock 11 115 504 minecraft:bookshelf
setblock 18 115 504 minecraft:bookshelf
setblock 21 115 464 minecraft:bookshelf
setblock 25 115 504 minecraft:bookshelf
setblock 28 115 464 minecraft:bookshelf
setblock 32 115 504 minecraft:bookshelf
setblock 35 115 464 minecraft:bookshelf
setblock 39 115 504 minecraft:bookshelf
setblock 41 115 465 minecraft:bookshelf
setblock 41 115 472 minecraft:bookshelf
setblock 41 115 479 minecraft:bookshelf
setblock 41 115 486 minecraft:bookshelf
setblock 41 115 493 minecraft:bookshelf
setblock 41 115 500 minecraft:bookshelf
setblock 1 116 466 minecraft:bookshelf
setblock 1 116 473 minecraft:bookshelf
fill 1 116 480 3 116 482 minecraft:bookshelf
fill 1 116 484 3 116 484 minecraft:bookshelf
setblock 1 116 487 minecraft:bookshelf
setblock 1 116 494 minecraft:bookshelf
setblock 1 116 501 minecraft:bookshelf
setblock 5 116 504 minecraft:bookshelf
setblock 6 116 464 minecraft:bookshelf
setblock 12 116 504 minecraft:bookshelf
setblock 19 116 504 minecraft:bookshelf
setblock 20 116 464 minecraft:bookshelf
setblock 26 116 504 minecraft:bookshelf
setblock 27 116 464 minecraft:bookshelf
setblock 33 116 504 minecraft:bookshelf
setblock 34 116 464 minecraft:bookshelf
setblock 40 116 504 minecraft:bookshelf
setblock 41 116 464 minecraft:bookshelf
setblock 41 116 471 minecraft:bookshelf
setblock 41 116 478 minecraft:bookshelf
setblock 41 116 485 minecraft:bookshelf
setblock 41 116 492 minecraft:bookshelf
setblock 41 116 499 minecraft:bookshelf
setblock 1 117 467 minecraft:bookshelf
fill 1 117 474 1 120 474 minecraft:bookshelf
fill 1 117 477 3 117 481 minecraft:bookshelf
setblock 1 117 488 minecraft:bookshelf
setblock 1 117 495 minecraft:bookshelf
setblock 1 117 502 minecraft:bookshelf
setblock 5 117 464 minecraft:bookshelf
setblock 6 117 504 minecraft:bookshelf
fill 10 117 464 10 158 464 minecraft:bookshelf
setblock 12 117 464 minecraft:bookshelf
setblock 13 117 504 minecraft:bookshelf
fill 17 117 464 17 158 464 minecraft:bookshelf
setblock 19 117 464 minecraft:bookshelf
setblock 20 117 504 minecraft:bookshelf
setblock 26 117 464 minecraft:bookshelf
setblock 27 117 504 minecraft:bookshelf
setblock 33 117 464 minecraft:bookshelf
setblock 34 117 504 minecraft:bookshelf
setblock 40 117 464 minecraft:bookshelf
setblock 41 117 470 minecraft:bookshelf
setblock 41 117 477 minecraft:bookshelf
setblock 41 117 484 minecraft:bookshelf
setblock 41 117 491 minecraft:bookshelf
setblock 41 117 498 minecraft:bookshelf
setblock 41 117 504 minecraft:bookshelf
fill 1 118 468 1 120 468 minecraft:bookshelf
fill 1 118 472 1 120 473 minecraft:bookshelf
fill 1 118 475 3 118 475 minecraft:bookshelf
fill 1 118 477 3 118 477 minecraft:bookshelf
setblock 1 118 482 minecraft:bookshelf
setblock 1 118 489 minecraft:bookshelf
setblock 1 118 496 minecraft:bookshelf
setblock 1 118 503 minecraft:bookshelf
fill 2 118 473 3 119 474 minecraft:bookshelf
fill 2 118 476 3 118 476 minecraft:bookshelf
fill 2 118 478 3 118 478 minecraft:bookshelf
setblock 4 118 464 minecraft:bookshelf
setblock 7 118 504 minecraft:bookshelf
setblock 11 118 464 minecraft:bookshelf
setblock 14 118 504 minecraft:bookshelf
setblock 18 118 464 minecraft:bookshelf
setblock 21 118 504 minecraft:bookshelf
setblock 25 118 464 minecraft:bookshelf
setblock 28 118 504 minecraft:bookshelf
setblock 32 118 464 minecraft:bookshelf
setblock 35 118 504 minecraft:bookshelf
setblock 39 118 464 minecraft:bookshelf
setblock 41 118 469 minecraft:bookshelf
setblock 41 118 476 minecraft:bookshelf
setblock 41 118 483 minecraft:bookshelf
setblock 41 118 490 minecraft:bookshelf
setblock 41 118 497 minecraft:bookshelf
fill 1 119 467 1 120 467 minecraft:bookshelf
fill 1 119 470 3 119 471 minecraft:bookshelf
fill 2 119 468 2 120 469 minecraft:bookshelf
fill 2 119 472 3 119 472 minecraft:bookshelf
fill 3 119 469 3 120 469 minecraft:bookshelf
setblock 3 119 475 minecraft:bookshelf
fill 1 120 464 2 120 466 minecraft:bookshelf
fill 1 120 470 1 120 471 minecraft:bookshelf
setblock 1 120 475 minecraft:bookshelf
fill 1 120 477 1 120 482 minecraft:bookshelf
fill 1 120 484 1 120 489 minecraft:bookshelf
fill 1 120 491 1 120 496 minecraft:bookshelf
fill 1 120 498 1 120 503 minecraft:bookshelf
fill 2 120 467 3 120 467 minecraft:bookshelf
fill 2 120 470 3 120 470 minecraft:bookshelf
fill 2 120 504 7 120 504 minecraft:bookshelf
fill 3 120 465 4 121 466 minecraft:bookshelf
setblock 3 120 468 minecraft:bookshelf
setblock 3 120 471 minecraft:bookshelf
fill 4 120 464 9 120 464 minecraft:bookshelf
fill 5 120 466 5 121 466 minecraft:bookshelf
fill 9 120 504 14 120 504 minecraft:bookshelf
fill 11 120 464 16 120 464 minecraft:bookshelf
fill 16 120 504 21 120 504 minecraft:bookshelf
fill 18 120 464 23 120 464 minecraft:bookshelf
fill 23 120 504 28 120 504 minecraft:bookshelf
fill 25 120 464 30 120 464 minecraft:bookshelf
fill 30 120 504 35 120 504 minecraft:bookshelf
fill 32 120 464 37 120 464 minecraft:bookshelf
fill 37 120 504 41 120 504 minecraft:bookshelf
fill 39 120 464 41 120 464 minecraft:bookshelf
fill 41 120 465 41 120 467 minecraft:bookshelf
fill 41 120 469 41 120 474 minecraft:bookshelf
fill 41 120 476 41 120 481 minecraft:bookshelf
fill 41 120 483 41 120 488 minecraft:bookshelf
fill 41 120 490 41 120 495 minecraft:bookshelf
fill 41 120 497 41 120 502 minecraft:bookshelf
fill 1 121 464 2 121 464 minecraft:bookshelf
setblock 1 121 471 minecraft:bookshelf
setblock 1 121 478 minecraft:bookshelf
setblock 1 121 485 minecraft:bookshelf
setblock 1 121 492 minecraft:bookshelf
setblock 1 121 499 minecraft:bookshelf
setblock 2 121 465 minecraft:bookshelf
setblock 3 121 474 minecraft:light[level=12]
setblock 3 121 482 minecraft:light[level=12]
setblock 3 121 490 minecraft:light[level=12]
setblock 3 121 498 minecraft:light[level=12]
setblock 3 121 504 minecraft:bookshelf
fill 4 121 464 8 121 464 minecraft:bookshelf
fill 5 121 465 9 121 465 minecraft:bookshelf
fill 6 121 466 9 121 466 minecraft:bookshelf
fill 7 121 475 8 122 476 minecraft:white_wool
fill 8 121 474 8 122 474 minecraft:white_wool
setblock 10 121 504 minecraft:bookshelf
setblock 11 121 466 minecraft:light[level=12]
setblock 11 121 474 minecraft:light[level=12]
setblock 11 121 482 minecraft:light[level=12]
setblock 11 121 490 minecraft:light[level=12]
setblock 11 121 498 minecraft:light[level=12]
setblock 15 121 464 minecraft:bookshelf
setblock 17 121 504 minecraft:bookshelf
setblock 19 121 466 minecraft:light[level=12]
setblock 19 121 474 minecraft:light[level=12]
setblock 19 121 482 minecraft:light[level=12]
setblock 19 121 490 minecraft:light[level=12]
setblock 19 121 498 minecraft:light[level=12]
setblock 22 121 464 minecraft:bookshelf
setblock 24 121 504 minecraft:bookshelf
setblock 27 121 466 minecraft:light[level=12]
setblock 27 121 474 minecraft:light[level=12]
setblock 27 121 482 minecraft:light[level=12]
setblock 27 121 490 minecraft:light[level=12]
setblock 27 121 498 minecraft:light[level=12]
setblock 29 121 464 minecraft:bookshelf
setblock 31 121 504 minecraft:bookshelf
setblock 35 121 466 minecraft:light[level=12]
setblock 35 121 474 minecraft:light[level=12]
setblock 35 121 482 minecraft:light[level=12]
setblock 35 121 490 minecraft:light[level=12]
setblock 35 121 498 minecraft:light[level=12]
setblock 36 121 464 minecraft:bookshelf
setblock 38 121 504 minecraft:bookshelf
setblock 41 121 466 minecraft:bookshelf
setblock 41 121 473 minecraft:bookshelf
setblock 41 121 480 minecraft:bookshelf
setblock 41 121 487 minecraft:bookshelf
setblock 41 121 494 minecraft:bookshelf
setblock 41 121 501 minecraft:bookshelf
setblock 1 122 465 minecraft:bookshelf
setblock 1 122 472 minecraft:bookshelf
setblock 1 122 479 minecraft:bookshelf
setblock 1 122 486 minecraft:bookshelf
setblock 1 122 493 minecraft:bookshelf
setblock 1 122 500 minecraft:bookshelf
setblock 4 122 504 minecraft:bookshelf
fill 6 122 464 9 122 464 minecraft:bookshelf
fill 7 122 465 13 122 465 minecraft:bookshelf
fill 8 122 466 13 122 466 minecraft:bookshelf
fill 11 122 464 12 123 464 minecraft:bookshelf
setblock 11 122 504 minecraft:bookshelf
fill 14 122 464 14 123 464 minecraft:bookshelf
setblock 18 122 504 minecraft:bookshelf
setblock 21 122 464 minecraft:bookshelf
setblock 25 122 504 minecraft:bookshelf
setblock 28 122 464 minecraft:bookshelf
setblock 32 122 504 minecraft:bookshelf
setblock 35 122 464 minecraft:bookshelf
setblock 39 122 504 minecraft:bookshelf
setblock 41 122 465 minecraft:bookshelf
setblock 41 122 472 minecraft:bookshelf
setblock 41 122 479 minecraft:bookshelf
setblock 41 122 486 minecraft:bookshelf
setblock 41 122 493 minecraft:bookshelf
setblock 41 122 500 minecraft:bookshelf
setblock 1 123 466 minecraft:bookshelf
setblock 1 123 473 minecraft:bookshelf
setblock 1 123 480 minecraft:bookshelf
setblock 1 123 487 minecraft:bookshelf
setblock 1 123 494 minecraft:bookshelf
setblock 1 123 501 minecraft:bookshelf
setblock 5 123 504 minecraft:bookshelf
setblock 6 123 464 minecraft:bookshelf
fill 11 123 465 16 123 465 minecraft:bookshelf
fill 12 123 466 16 123 466 minecraft:bookshelf
setblock 12 123 504 minecraft:bookshelf
setblock 13 123 464 minecraft:bookshelf
fill 15 123 464 16 124 464 minecraft:bookshelf
setblock 19 123 504 minecraft:bookshelf
setblock 20 123 464 minecraft:bookshelf
setblock 26 123 504 minecraft:bookshelf
setblock 27 123 464 minecraft:bookshelf
setblock 33 123 504 minecraft:bookshelf
setblock 34 123 464 minecraft:bookshelf
setblock 40 123 504 minecraft:bookshelf
setblock 41 123 464 minecraft:bookshelf
setblock 41 123 471 minecraft:bookshelf
setblock 41 123 478 minecraft:bookshelf
setblock 41 123 485 minecraft:bookshelf
setblock 41 123 492 minecraft:bookshelf
setblock 41 123 499 minecraft:bookshelf
setblock 1 124 467 minecraft:bookshelf
setblock 1 124 474 minecraft:bookshelf
setblock 1 124 481 minecraft:bookshelf
setblock 1 124 488 minecraft:bookshelf
setblock 1 124 495 minecraft:bookshelf
setblock 1 124 502 minecraft:bookshelf
setblock 5 124 464 minecraft:bookshelf
setblock 6 124 504 minecraft:bookshelf
setblock 12 124 464 minecraft:bookshelf
setblock 13 124 504 minecraft:bookshelf
fill 15 124 465 19 124 466 minecraft:bookshelf
fill 18 124 464 19 125 464 minecraft:bookshelf
setblock 20 124 504 minecraft:bookshelf
setblock 26 124 464 minecraft:bookshelf
setblock 27 124 504 minecraft:bookshelf
setblock 33 124 464 minecraft:bookshelf
setblock 34 124 504 minecraft:bookshelf
setblock 40 124 464 minecraft:bookshelf
setblock 41 124 470 minecraft:bookshelf
setblock 41 124 477 minecraft:bookshelf
setblock 41 124 484 minecraft:bookshelf
setblock 41 124 491 minecraft:bookshelf
setblock 41 124 498 minecraft:bookshelf
setblock 41 124 504 minecraft:bookshelf
setblock 1 125 468 minecraft:bookshelf
setblock 1 125 475 minecraft:bookshelf
setblock 1 125 482 minecraft:bookshelf
setblock 1 125 489 minecraft:bookshelf
setblock 1 125 496 minecraft:bookshelf
setblock 1 125 503 minecraft:bookshelf
setblock 4 125 464 minecraft:bookshelf
setblock 7 125 504 minecraft:bookshelf
setblock 11 125 464 minecraft:bookshelf
setblock 14 125 504 minecraft:bookshelf
fill 18 125 465 22 125 466 minecraft:bookshelf
fill 20 125 464 22 125 464 minecraft:bookshelf
setblock 21 125 504 minecraft:bookshelf
fill 25 125 464 25 127 464 minecraft:bookshelf
setblock 28 125 504 minecraft:bookshelf
setblock 32 125 464 minecraft:bookshelf
setblock 35 125 504 minecraft:bookshelf
setblock 39 125 464 minecraft:bookshelf
setblock 41 125 469 minecraft:bookshelf
setblock 41 125 476 minecraft:bookshelf
setblock 41 125 483 minecraft:bookshelf
setblock 41 125 490 minecraft:bookshelf
setblock 41 125 497 minecraft:bookshelf
fill 4 126 484 4 127 484 minecraft:blue_wool
fill 21 126 464 23 126 466 minecraft:bookshelf
fill 24 126 465 25 127 466 minecraft:bookshelf
setblock 1 127 470 minecraft:bookshelf
setblock 1 127 477 minecraft:bookshelf
setblock 1 127 484 minecraft:bookshelf
setblock 1 127 491 minecraft:bookshelf
setblock 1 127 498 minecraft:bookshelf
setblock 2 127 464 minecraft:bookshelf
setblock 2 127 504 minecraft:bookshelf
setblock 9 127 464 minecraft:bookshelf
setblock 9 127 504 minecraft:bookshelf
setblock 16 127 464 minecraft:bookshelf
setblock 16 127 504 minecraft:bookshelf
setblock 23 127 464 minecraft:bookshelf
setblock 23 127 504 minecraft:bookshelf
fill 26 127 464 28 127 466 minecraft:bookshelf
fill 29 127 464 30 128 464 minecraft:bookshelf
setblock 30 127 504 minecraft:bookshelf
setblock 37 127 464 minecraft:bookshelf
setblock 37 127 504 minecraft:bookshelf
setblock 41 127 467 minecraft:bookshelf
setblock 41 127 474 minecraft:bookshelf
setblock 41 127 481 minecraft:bookshelf
setblock 41 127 488 minecraft:bookshelf
setblock 41 127 495 minecraft:bookshelf
setblock 41 127 502 minecraft:bookshelf
setblock 1 128 464 minecraft:bookshelf
setblock 1 128 471 minecraft:bookshelf
setblock 1 128 478 minecraft:bookshelf
setblock 1 128 485 minecraft:bookshelf
setblock 1 128 492 minecraft:bookshelf
setblock 1 128 499 minecraft:bookshelf
setblock 3 128 504 minecraft:bookshelf
setblock 8 128 464 minecraft:bookshelf
setblock 10 128 504 minecraft:bookshelf
setblock 15 128 464 minecraft:bookshelf
setblock 17 128 504 minecraft:bookshelf
setblock 22 128 464 minecraft:bookshelf
setblock 24 128 504 minecraft:bookshelf
fill 27 128 465 32 128 466 minecraft:bookshelf
fill 28 128 464 28 130 464 minecraft:bookshelf
setblock 31 128 504 minecraft:bookshelf
fill 32 128 464 33 130 464 minecraft:bookshelf
fill 36 128 464 36 130 464 minecraft:bookshelf
setblock 38 128 504 minecraft:bookshelf
setblock 41 128 466 minecraft:bookshelf
setblock 41 128 473 minecraft:bookshelf
setblock 41 128 480 minecraft:bookshelf
setblock 41 128 487 minecraft:bookshelf
setblock 41 128 494 minecraft:bookshelf
setblock 41 128 501 minecraft:bookshelf
fill 1 129 465 1 130 465 minecraft:bookshelf
fill 1 129 472 1 130 472 minecraft:bookshelf
fill 1 129 479 1 130 479 minecraft:bookshelf
fill 1 129 486 1 130 486 minecraft:bookshelf
fill 1 129 493 1 130 493 minecraft:bookshelf
fill 1 129 500 1 130 500 minecraft:bookshelf
setblock 3 129 466 minecraft:light[level=12]
setblock 3 129 474 minecraft:light[level=12]
setblock 3 129 482 minecraft:light[level=12]
setblock 3 129 490 minecraft:light[level=12]
setblock 3 129 498 minecraft:light[level=12]
fill 4 129 504 4 130 504 minecraft:bookshelf
fill 7 129 464 7 130 464 minecraft:bookshelf
setblock 11 129 466 minecraft:light[level=12]
setblock 11 129 474 minecraft:light[level=12]
setblock 11 129 482 minecraft:light[level=12]
setblock 11 129 490 minecraft:light[level=12]
setblock 11 129 498 minecraft:light[level=12]
fill 11 129 504 11 130 504 minecraft:bookshelf
fill 14 129 464 14 130 464 minecraft:bookshelf
fill 18 129 504 18 130 504 minecraft:bookshelf
setblock 19 129 466 minecraft:light[level=12]
setblock 19 129 474 minecraft:light[level=12]
setblock 19 129 482 minecraft:light[level=12]
setblock 19 129 490 minecraft:light[level=12]
setblock 19 129 498 minecraft:light[level=12]
fill 21 129 464 21 130 464 minecraft:bookshelf
fill 25 129 504 25 130 504 minecraft:bookshelf
setblock 27 129 466 minecraft:light[level=12]
setblock 27 129 474 minecraft:light[level=12]
setblock 27 129 482 minecraft:light[level=12]
setblock 27 129 490 minecraft:light[level=12]
setblock 27 129 498 minecraft:light[level=12]
fill 30 129 466 36 129 466 minecraft:bookshelf
fill 31 129 465 37 129 465 minecraft:bookshelf
fill 32 129 504 32 130 504 minecraft:bookshelf
fill 34 129 464 35 130 464 minecraft:bookshelf
setblock 35 129 474 minecraft:light[level=12]
setblock 35 129 482 minecraft:light[level=12]
setblock 35 129 490 minecraft:light[level=12]
setblock 35 129 498 minecraft:light[level=12]
fill 37 129 464 37 130 464 minecraft:bookshelf
fill 39 129 504 39 130 504 minecraft:bookshelf
fill 41 129 465 41 131 465 minecraft:bookshelf
fill 41 129 472 41 130 472 minecraft:bookshelf
fill 41 129 479 41 130 479 minecraft:bookshelf
fill 41 129 486 41 130 486 minecraft:bookshelf
fill 41 129 493 41 130 493 minecraft:bookshelf
fill 41 129 500 41 130 500 minecraft:bookshelf
fill 1 130 464 2 130 464 minecraft:bookshelf
fill 1 130 466 1 130 468 minecraft:bookshelf
fill 1 130 470 1 130 471 minecraft:bookshelf
fill 1 130 473 1 130 475 minecraft:bookshelf
fill 1 130 477 1 130 478 minecraft:bookshelf
fill 1 130 480 1 130 482 minecraft:bookshelf
fill 1 130 484 1 130 485 minecraft:bookshelf
fill 1 130 487 1 130 489 minecraft:bookshelf
fill 1 130 491 1 130 492 minecraft:bookshelf
fill 1 130 494 1 130 496 minecraft:bookshelf
fill 1 130 498 1 130 499 minecraft:bookshelf
fill 1 130 501 1 130 503 minecraft:bookshelf
fill 2 130 504 3 130 504 minecraft:bookshelf
fill 4 130 464 6 130 464 minecraft:bookshelf
fill 5 130 504 7 130 504 minecraft:bookshelf
fill 8 130 464 9 130 464 minecraft:bookshelf
fill 9 130 504 10 130 504 minecraft:bookshelf
fill 11 130 464 13 130 464 minecraft:bookshelf
fill 12 130 504 14 130 504 minecraft:bookshelf
fill 15 130 464 16 130 464 minecraft:bookshelf
fill 16 130 504 17 130 504 minecraft:bookshelf
fill 18 130 464 20 130 464 minecraft:bookshelf
fill 19 130 504 21 130 504 minecraft:bookshelf
fill 22 130 464 23 130 464 minecraft:bookshelf
fill 23 130 504 24 130 504 minecraft:bookshelf
fill 25 130 464 27 130 464 minecraft:bookshelf
fill 26 130 504 28 130 504 minecraft:bookshelf
fill 29 130 464 30 130 464 minecraft:bookshelf
fill 30 130 504 31 130 504 minecraft:bookshelf
fill 33 130 504 35 130 504 minecraft:bookshelf
fill 34 130 466 41 130 466 minecraft:bookshelf
fill 35 130 465 40 130 465 minecraft:bookshelf
fill 37 130 504 38 130 504 minecraft:bookshelf
fill 39 130 464 41 130 464 minecraft:bookshelf
fill 39 130 467 39 131 468 minecraft:bookshelf
fill 40 130 467 41 131 467 minecraft:bookshelf
fill 40 130 504 41 130 504 minecraft:bookshelf
fill 41 130 469 41 132 471 minecraft:bookshelf
fill 41 130 473 41 130 474 minecraft:bookshelf
fill 41 130 476 41 130 478 minecraft:bookshelf
fill 41 130 480 41 130 481 minecraft:bookshelf
fill 41 130 483 41 130 485 minecraft:bookshelf
fill 41 130 487 41 130 488 minecraft:bookshelf
fill 41 130 490 41 130 492 minecraft:bookshelf
fill 41 130 494 41 130 495 minecraft:bookshelf
fill 41 130 497 41 130 499 minecraft:bookshelf
fill 41 130 501 41 130 502 minecraft:bookshelf
setblock 1 131 467 minecraft:bookshelf
setblock 1 131 474 minecraft:bookshelf
setblock 1 131 481 minecraft:bookshelf
setblock 1 131 488 minecraft:bookshelf
setblock 1 131 495 minecraft:bookshelf
setblock 1 131 502 minecraft:bookshelf
setblock 5 131 464 minecraft:bookshelf
setblock 6 131 504 minecraft:bookshelf
setblock 12 131 464 minecraft:bookshelf
setblock 13 131 504 minecraft:bookshelf
setblock 19 131 464 minecraft:bookshelf
setblock 20 131 504 minecraft:bookshelf
setblock 26 131 464 minecraft:bookshelf
setblock 27 131 504 minecraft:bookshelf
setblock 33 131 464 minecraft:bookshelf
setblock 34 131 504 minecraft:bookshelf
fill 39 131 466 41 131 466 minecraft:bookshelf
fill 39 131 469 40 131 472 minecraft:bookshelf
fill 40 131 464 40 131 465 minecraft:bookshelf
setblock 40 131 468 minecraft:bookshelf
setblock 41 131 464 minecraft:bookshelf
setblock 41 131 477 minecraft:bookshelf
setblock 41 131 484 minecraft:bookshelf
setblock 41 131 491 minecraft:bookshelf
setblock 41 131 498 minecraft:bookshelf
setblock 41 131 504 minecraft:bookshelf
setblock 1 132 468 minecraft:bookshelf
setblock 1 132 475 minecraft:bookshelf
setblock 1 132 482 minecraft:bookshelf
setblock 1 132 489 minecraft:bookshelf
setblock 1 132 496 minecraft:bookshelf
setblock 1 132 503 minecraft:bookshelf
setblock 4 132 464 minecraft:bookshelf
setblock 7 132 504 minecraft:bookshelf
setblock 11 132 464 minecraft:bookshelf
setblock 14 132 504 minecraft:bookshelf
setblock 18 132 464 minecraft:bookshelf
setblock 21 132 504 minecraft:bookshelf
setblock 25 132 464 minecraft:bookshelf
setblock 28 132 504 minecraft:bookshelf
setblock 32 132 464 minecraft:bookshelf
fill 32 132 497 32 133 497 minecraft:red_wool
setblock 35 132 504 minecraft:bookshelf
setblock 39 132 464 minecraft:bookshelf
fill 39 132 471 40 132 476 minecraft:bookshelf
setblock 40 132 470 minecraft:bookshelf
fill 41 132 472 41 132 474 minecraft:bookshelf
fill 41 132 476 41 133 476 minecraft:bookshelf
setblock 41 132 483 minecraft:bookshelf
setblock 41 132 490 minecraft:bookshelf
setblock 41 132 497 minecraft:bookshelf
fill 39 133 475 40 133 479 minecraft:bookshelf
fill 40 133 474 41 133 474 minecraft:bookshelf
fill 41 133 477 41 133 479 minecraft:bookshelf
setblock 1 134 470 minecraft:bookshelf
setblock 1 134 477 minecraft:bookshelf
setblock 1 134 484 minecraft:bookshelf
setblock 1 134 491 minecraft:bookshelf
setblock 1 134 498 minecraft:bookshelf
setblock 2 134 464 minecraft:bookshelf
setblock 2 134 504 minecraft:bookshelf
setblock 9 134 464 minecraft:bookshelf
setblock 9 134 504 minecraft:bookshelf
setblock 16 134 464 minecraft:bookshelf
setblock 16 134 504 minecraft:bookshelf
setblock 23 134 464 minecraft:bookshelf
setblock 23 134 504 minecraft:bookshelf
setblock 30 134 464 minecraft:bookshelf
setblock 30 134 504 minecraft:bookshelf
setblock 37 134 464 minecraft:bookshelf
setblock 37 134 504 minecraft:bookshelf
fill 39 134 478 40 134 482 minecraft:bookshelf
setblock 41 134 467 minecraft:bookshelf
setblock 41 134 474 minecraft:bookshelf
fill 41 134 478 41 134 481 minecraft:bookshelf
setblock 41 134 488 minecraft:bookshelf
setblock 41 134 495 minecraft:bookshelf
setblock 41 134 502 minecraft:bookshelf
setblock 1 135 464 minecraft:bookshelf
setblock 1 135 471 minecraft:bookshelf
setblock 1 135 478 minecraft:bookshelf
setblock 1 135 485 minecraft:bookshelf
setblock 1 135 492 minecraft:bookshelf
setblock 1 135 499 minecraft:bookshelf
setblock 3 135 504 minecraft:bookshelf
setblock 8 135 464 minecraft:bookshelf
setblock 10 135 504 minecraft:bookshelf
setblock 15 135 464 minecraft:bookshelf
setblock 17 135 504 minecraft:bookshelf
setblock 22 135 464 minecraft:bookshelf
setblock 24 135 504 minecraft:bookshelf
setblock 29 135 464 minecraft:bookshelf
setblock 31 135 504 minecraft:bookshelf
setblock 36 135 464 minecraft:bookshelf
setblock 38 135 504 minecraft:bookshelf
fill 39 135 481 40 135 485 minecraft:bookshelf
setblock 41 135 466 minecraft:bookshelf
setblock 41 135 473 minecraft:bookshelf
fill 41 135 480 41 135 481 minecraft:bookshelf
fill 41 135 483 41 135 485 minecraft:bookshelf
fill 41 135 487 41 137 487 minecraft:bookshelf
setblock 41 135 494 minecraft:bookshelf
setblock 41 135 501 minecraft:bookshelf
setblock 1 136 465 minecraft:bookshelf
setblock 1 136 472 minecraft:bookshelf
setblock 1 136 479 minecraft:bookshelf
setblock 1 136 486 minecraft:bookshelf
setblock 1 136 493 minecraft:bookshelf
setblock 1 136 500 minecraft:bookshelf
setblock 4 136 504 minecraft:bookshelf
setblock 7 136 464 minecraft:bookshelf
setblock 11 136 504 minecraft:bookshelf
setblock 14 136 464 minecraft:bookshelf
fill 15 136 467 16 137 468 minecraft:white_wool
fill 16 136 466 16 137 466 minecraft:white_wool
setblock 18 136 504 minecraft:bookshelf
setblock 21 136 464 minecraft:bookshelf
setblock 25 136 504 minecraft:bookshelf
setblock 28 136 464 minecraft:bookshelf
setblock 32 136 504 minecraft:bookshelf
setblock 35 136 464 minecraft:bookshelf
fill 39 136 484 40 136 488 minecraft:bookshelf
setblock 39 136 504 minecraft:bookshelf
setblock 41 136 465 minecraft:bookshelf
setblock 41 136 472 minecraft:bookshelf
setblock 41 136 479 minecraft:bookshelf
fill 41 136 484 41 136 486 minecraft:bookshelf
fill 41 136 488 41 137 488 minecraft:bookshelf
setblock 41 136 493 minecraft:bookshelf
setblock 41 136 500 minecraft:bookshelf
setblock 1 137 466 minecraft:bookshelf
setblock 1 137 473 minecraft:bookshelf
setblock 1 137 480 minecraft:bookshelf
setblock 1 137 487 minecraft:bookshelf
setblock 1 137 494 minecraft:bookshelf
setblock 1 137 501 minecraft:bookshelf
setblock 3 137 466 minecraft:light[level=12]
setblock 3 137 474 minecraft:light[level=12]
setblock 3 137 482 minecraft:light[level=12]
setblock 3 137 490 minecraft:light[level=12]
setblock 3 137 498 minecraft:light[level=12]
setblock 5 137 504 minecraft:bookshelf
setblock 6 137 464 minecraft:bookshelf
setblock 11 137 466 minecraft:light[level=12]
setblock 11 137 474 minecraft:light[level=12]
setblock 11 137 482 minecraft:light[level=12]
setblock 11 137 490 minecraft:light[level=12]
setblock 11 137 498 minecraft:light[level=12]
setblock 12 137 504 minecraft:bookshelf
setblock 13 137 464 minecraft:bookshelf
setblock 19 137 466 minecraft:light[level=12]
setblock 19 137 474 minecraft:light[level=12]
setblock 19 137 482 minecraft:light[level=12]
setblock 19 137 490 minecraft:light[level=12]
setblock 19 137 498 minecraft:light[level=12]
setblock 19 137 504 minecraft:bookshelf
setblock 20 137 464 minecraft:bookshelf
setblock 26 137 504 minecraft:bookshelf
setblock 27 137 464 minecraft:bookshelf
setblock 27 137 466 minecraft:light[level=12]
setblock 27 137 474 minecraft:light[level=12]
setblock 27 137 482 minecraft:light[level=12]
setblock 27 137 490 minecraft:light[level=12]
setblock 27 137 498 minecraft:light[level=12]
setblock 33 137 504 minecraft:bookshelf
setblock 34 137 464 minecraft:bookshelf
setblock 35 137 466 minecraft:light[level=12]
setblock 35 137 474 minecraft:light[level=12]
setblock 35 137 482 minecraft:light[level=12]
setblock 35 137 490 minecraft:light[level=12]
setblock 35 137 498 minecraft:light[level=12]
fill 39 137 487 40 137 491 minecraft:bookshelf
setblock 40 137 504 minecraft:bookshelf
setblock 41 137 464 minecraft:bookshelf
setblock 41 137 471 minecraft:bookshelf
setblock 41 137 478 minecraft:bookshelf
setblock 41 137 485 minecraft:bookshelf
fill 41 137 490 41 137 492 minecraft:bookshelf
setblock 41 137 499 minecraft:bookshelf
setblock 1 138 467 minecraft:bookshelf
setblock 1 138 474 minecraft:bookshelf
setblock 1 138 481 minecraft:bookshelf
setblock 1 138 488 minecraft:bookshelf
setblock 1 138 495 minecraft:bookshelf
setblock 1 138 502 minecraft:bookshelf
setblock 5 138 464 minecraft:bookshelf
setblock 6 138 504 minecraft:bookshelf
setblock 12 138 464 minecraft:bookshelf
setblock 13 138 504 minecraft:bookshelf
setblock 19 138 464 minecraft:bookshelf
setblock 20 138 504 minecraft:bookshelf
setblock 26 138 464 minecraft:bookshelf
setblock 27 138 504 minecraft:bookshelf
setblock 33 138 464 minecraft:bookshelf
setblock 34 138 504 minecraft:bookshelf
fill 39 138 490 40 138 495 minecraft:bookshelf
setblock 40 138 464 minecraft:bookshelf
setblock 41 138 470 minecraft:bookshelf
setblock 41 138 477 minecraft:bookshelf
setblock 41 138 484 minecraft:bookshelf
fill 41 138 491 41 138 495 minecraft:bookshelf
fill 41 138 498 41 140 498 minecraft:bookshelf
setblock 41 138 504 minecraft:bookshelf
fill 1 139 468 1 140 468 minecraft:bookshelf
fill 1 139 475 1 140 475 minecraft:bookshelf
fill 1 139 482 1 140 482 minecraft:bookshelf
fill 1 139 489 1 140 489 minecraft:bookshelf
fill 1 139 496 1 140 496 minecraft:bookshelf
fill 1 139 503 1 140 503 minecraft:bookshelf
fill 4 139 464 4 140 464 minecraft:bookshelf
fill 7 139 504 7 140 504 minecraft:bookshelf
fill 11 139 464 11 140 464 minecraft:bookshelf
fill 14 139 504 14 140 504 minecraft:bookshelf
fill 18 139 464 18 140 464 minecraft:bookshelf
fill 21 139 504 21 140 504 minecraft:bookshelf
fill 25 139 464 25 140 464 minecraft:bookshelf
fill 28 139 504 28 140 504 minecraft:bookshelf
fill 32 139 464 32 140 464 minecraft:bookshelf
fill 35 139 504 35 142 504 minecraft:bookshelf
fill 39 139 464 39 140 464 minecraft:bookshelf
fill 39 139 493 39 139 499 minecraft:bookshelf
fill 40 139 494 40 139 500 minecraft:bookshelf
fill 41 139 469 41 140 469 minecraft:bookshelf
fill 41 139 476 41 140 476 minecraft:bookshelf
fill 41 139 483 41 140 483 minecraft:bookshelf
fill 41 139 490 41 140 490 minecraft:bookshelf
fill 41 139 494 41 140 495 minecraft:bookshelf
fill 41 139 497 41 140 497 minecraft:bookshelf
fill 41 139 499 41 140 501 minecraft:bookshelf
fill 1 140 464 1 140 467 minecraft:bookshelf
fill 1 140 470 1 140 474 minecraft:bookshelf
fill 1 140 477 1 140 481 minecraft:bookshelf
fill 1 140 484 1 140 488 minecraft:bookshelf
fill 1 140 491 1 140 495 minecraft:bookshelf
fill 1 140 498 1 140 502 minecraft:bookshelf
fill 2 140 464 2 141 464 minecraft:bookshelf
fill 2 140 504 6 140 504 minecraft:bookshelf
fill 5 140 464 9 140 464 minecraft:bookshelf
fill 9 140 504 13 140 504 minecraft:bookshelf
fill 12 140 464 16 140 464 minecraft:bookshelf
fill 16 140 504 20 140 504 minecraft:bookshelf
fill 19 140 464 23 140 464 minecraft:bookshelf
fill 23 140 504 27 140 504 minecraft:bookshelf
fill 26 140 464 30 140 464 minecraft:bookshelf
fill 30 140 504 34 140 504 minecraft:bookshelf
fill 33 140 464 37 140 464 minecraft:bookshelf
fill 37 140 502 41 140 502 minecraft:bookshelf
fill 37 140 504 41 141 504 minecraft:bookshelf
fill 38 140 503 40 141 503 minecraft:bookshelf
fill 39 140 497 39 140 501 minecraft:bookshelf
fill 40 140 464 41 140 464 minecraft:bookshelf
fill 40 140 498 40 140 501 minecraft:bookshelf
fill 41 140 465 41 140 467 minecraft:bookshelf
fill 41 140 470 41 140 474 minecraft:bookshelf
fill 41 140 477 41 140 481 minecraft:bookshelf
fill 41 140 484 41 140 488 minecraft:bookshelf
fill 41 140 491 41 140 493 minecraft:bookshelf
setblock 1 141 470 minecraft:bookshelf
setblock 1 141 477 minecraft:bookshelf
setblock 1 141 484 minecraft:bookshelf
setblock 1 141 491 minecraft:bookshelf
setblock 1 141 498 minecraft:bookshelf
setblock 2 141 504 minecraft:bookshelf
setblock 9 141 464 minecraft:bookshelf
setblock 9 141 504 minecraft:bookshelf
setblock 16 141 464 minecraft:bookshelf
setblock 16 141 504 minecraft:bookshelf
setblock 23 141 464 minecraft:bookshelf
setblock 23 141 504 minecraft:bookshelf
setblock 30 141 464 minecraft:bookshelf
fill 30 141 504 30 143 504 minecraft:bookshelf
fill 33 141 502 37 141 503 minecraft:bookshelf
fill 34 141 504 34 142 504 minecraft:bookshelf
setblock 37 141 464 minecraft:bookshelf
fill 38 141 502 39 141 502 minecraft:bookshelf
setblock 41 141 467 minecraft:bookshelf
setblock 41 141 474 minecraft:bookshelf
setblock 41 141 481 minecraft:bookshelf
setblock 41 141 488 minecraft:bookshelf
setblock 41 141 495 minecraft:bookshelf
setblock 41 141 502 minecraft:bookshelf
setblock 1 142 464 minecraft:bookshelf
setblock 1 142 471 minecraft:bookshelf
setblock 1 142 478 minecraft:bookshelf
setblock 1 142 485 minecraft:bookshelf
setblock 1 142 492 minecraft:bookshelf
setblock 1 142 499 minecraft:bookshelf
setblock 3 142 504 minecraft:bookshelf
setblock 8 142 464 minecraft:bookshelf
fill 8 142 483 9 143 484 minecraft:white_wool
setblock 10 142 504 minecraft:bookshelf
setblock 15 142 464 minecraft:bookshelf
setblock 17 142 504 minecraft:bookshelf
setblock 22 142 464 minecraft:bookshelf
setblock 24 142 504 minecraft:bookshelf
setblock 29 142 464 minecraft:bookshelf
fill 29 142 502 34 142 503 minecraft:bookshelf
fill 31 142 504 33 142 504 minecraft:bookshelf
setblock 35 142 503 minecraft:bookshelf
setblock 36 142 464 minecraft:bookshelf
setblock 38 142 504 minecraft:bookshelf
setblock 41 142 466 minecraft:bookshelf
setblock 41 142 473 minecraft:bookshelf
setblock 41 142 480 minecraft:bookshelf
setblock 41 142 487 minecraft:bookshelf
setblock 41 142 494 minecraft:bookshelf
setblock 41 142 501 minecraft:bookshelf
setblock 1 143 465 minecraft:bookshelf
setblock 1 143 472 minecraft:bookshelf
setblock 1 143 479 minecraft:bookshelf
setblock 1 143 486 minecraft:bookshelf
setblock 1 143 493 minecraft:bookshelf
setblock 1 143 500 minecraft:bookshelf
setblock 4 143 504 minecraft:bookshelf
setblock 7 143 464 minecraft:bookshelf
setblock 11 143 504 minecraft:bookshelf
setblock 14 143 464 minecraft:bookshelf
setblock 18 143 504 minecraft:bookshelf
setblock 21 143 464 minecraft:bookshelf
fill 25 143 504 28 143 504 minecraft:bookshelf
fill 26 143 502 30 143 503 minecraft:bookshelf
setblock 28 143 464 minecraft:bookshelf
fill 31 143 503 31 143 504 minecraft:bookshelf
setblock 32 143 504 minecraft:bookshelf
setblock 35 143 464 minecraft:bookshelf
setblock 39 143 504 minecraft:bookshelf
setblock 41 143 465 minecraft:bookshelf
setblock 41 143 472 minecraft:bookshelf
setblock 41 143 479 minecraft:bookshelf
setblock 41 143 486 minecraft:bookshelf
setblock 41 143 493 minecraft:bookshelf
setblock 41 143 500 minecraft:bookshelf
setblock 1 144 466 minecraft:bookshelf
setblock 1 144 473 minecraft:bookshelf
setblock 1 144 480 minecraft:bookshelf
setblock 1 144 487 minecraft:bookshelf
setblock 1 144 494 minecraft:bookshelf
setblock 1 144 501 minecraft:bookshelf
setblock 5 144 504 minecraft:bookshelf
setblock 6 144 464 minecraft:bookshelf
setblock 12 144 504 minecraft:bookshelf
setblock 13 144 464 minecraft:bookshelf
setblock 19 144 504 minecraft:bookshelf
setblock 20 144 464 minecraft:bookshelf
fill 23 144 502 27 144 504 minecraft:bookshelf
setblock 27 144 464 minecraft:bookshelf
setblock 33 144 504 minecraft:bookshelf
setblock 34 144 464 minecraft:bookshelf
setblock 40 144 504 minecraft:bookshelf
setblock 41 144 464 minecraft:bookshelf
setblock 41 144 471 minecraft:bookshelf
setblock 41 144 478 minecraft:bookshelf
setblock 41 144 485 minecraft:bookshelf
setblock 41 144 492 minecraft:bookshelf
setblock 41 144 499 minecraft:bookshelf
setblock 1 145 467 minecraft:bookshelf
setblock 1 145 474 minecraft:bookshelf
setblock 1 145 481 minecraft:bookshelf
setblock 1 145 488 minecraft:bookshelf
setblock 1 145 495 minecraft:bookshelf
setblock 1 145 502 minecraft:bookshelf
setblock 3 145 466 minecraft:light[level=12]
setblock 3 145 474 minecraft:light[level=12]
setblock 3 145 482 minecraft:light[level=12]
setblock 3 145 490 minecraft:light[level=12]
setblock 3 145 498 minecraft:light[level=12]
setblock 5 145 464 minecraft:bookshelf
setblock 6 145 504 minecraft:bookshelf
setblock 11 145 466 minecraft:light[level=12]
setblock 11 145 474 minecraft:light[level=12]
setblock 11 145 482 minecraft:light[level=12]
setblock 11 145 490 minecraft:light[level=12]
setblock 11 145 498 minecraft:light[level=12]
setblock 12 145 464 minecraft:bookshelf
setblock 13 145 504 minecraft:bookshelf
setblock 19 145 464 minecraft:bookshelf
setblock 19 145 466 minecraft:light[level=12]
setblock 19 145 474 minecraft:light[level=12]
setblock 19 145 482 minecraft:light[level=12]
setblock 19 145 490 minecraft:light[level=12]
setblock 19 145 498 minecraft:light[level=12]
fill 20 145 502 21 146 504 minecraft:bookshelf
fill 22 145 502 24 145 503 minecraft:bookshelf
fill 23 145 504 24 145 504 minecraft:bookshelf
setblock 26 145 464 minecraft:bookshelf
setblock 27 145 466 minecraft:light[level=12]
setblock 27 145 474 minecraft:light[level=12]
setblock 27 145 482 minecraft:light[level=12]
setblock 27 145 490 minecraft:light[level=12]
setblock 27 145 498 minecraft:light[level=12]
setblock 27 145 504 minecraft:bookshelf
setblock 33 145 464 minecraft:bookshelf
setblock 34 145 504 minecraft:bookshelf
setblock 35 145 466 minecraft:light[level=12]
setblock 35 145 474 minecraft:light[level=12]
setblock 35 145 482 minecraft:light[level=12]
setblock 35 145 490 minecraft:light[level=12]
setblock 35 145 498 minecraft:light[level=12]
setblock 40 145 464 minecraft:bookshelf
setblock 41 145 470 minecraft:bookshelf
setblock 41 145 477 minecraft:bookshelf
setblock 41 145 484 minecraft:bookshelf
setblock 41 145 491 minecraft:bookshelf
setblock 41 145 498 minecraft:bookshelf
setblock 41 145 504 minecraft:bookshelf
setblock 1 146 468 minecraft:bookshelf
setblock 1 146 475 minecraft:bookshelf
setblock 1 146 482 minecraft:bookshelf
setblock 1 146 489 minecraft:bookshelf
setblock 1 146 496 minecraft:bookshelf
setblock 1 146 503 minecraft:bookshelf
setblock 4 146 464 minecraft:bookshelf
setblock 7 146 504 minecraft:bookshelf
setblock 11 146 464 minecraft:bookshelf
fill 14 146 504 14 148 504 minecraft:bookshelf
fill 17 146 502 19 146 504 minecraft:bookshelf
setblock 18 146 464 minecraft:bookshelf
setblock 25 146 464 minecraft:bookshelf
setblock 28 146 504 minecraft:bookshelf
setblock 32 146 464 minecraft:bookshelf
setblock 35 146 504 minecraft:bookshelf
setblock 39 146 464 minecraft:bookshelf
setblock 41 146 469 minecraft:bookshelf
setblock 41 146 476 minecraft:bookshelf
setblock 41 146 483 minecraft:bookshelf
setblock 41 146 490 minecraft:bookshelf
setblock 41 146 497 minecraft:bookshelf
fill 13 147 504 13 148 504 minecraft:bookshelf
fill 14 147 502 18 147 503 minecraft:bookshelf
fill 16 147 504 18 147 504 minecraft:bookshelf
setblock 1 148 470 minecraft:bookshelf
setblock 1 148 477 minecraft:bookshelf
setblock 1 148 484 minecraft:bookshelf
setblock 1 148 491 minecraft:bookshelf
setblock 1 148 498 minecraft:bookshelf
setblock 2 148 464 minecraft:bookshelf
setblock 2 148 504 minecraft:bookshelf
setblock 9 148 464 minecraft:bookshelf
fill 9 148 504 12 148 504 minecraft:bookshelf
fill 10 148 502 15 148 503 minecraft:bookshelf
setblock 16 148 464 minecraft:bookshelf
setblock 16 148 504 minecraft:bookshelf
setblock 23 148 464 minecraft:bookshelf
setblock 23 148 504 minecraft:bookshelf
setblock 30 148 464 minecraft:bookshelf
setblock 30 148 504 minecraft:bookshelf
setblock 37 148 464 minecraft:bookshelf
setblock 37 148 504 minecraft:bookshelf
setblock 41 148 467 minecraft:bookshelf
setblock 41 148 474 minecraft:bookshelf
setblock 41 148 481 minecraft:bookshelf
setblock 41 148 488 minecraft:bookshelf
setblock 41 148 495 minecraft:bookshelf
setblock 41 148 502 minecraft:bookshelf
fill 1 149 464 1 150 464 minecraft:bookshelf
fill 1 149 471 1 150 471 minecraft:bookshelf
fill 1 149 478 1 150 478 minecraft:bookshelf
fill 1 149 485 1 150 485 minecraft:bookshelf
fill 1 149 492 1 150 492 minecraft:bookshelf
fill 1 149 499 1 152 499 minecraft:bookshelf
fill 3 149 504 7 150 504 minecraft:bookshelf
fill 5 149 503 11 149 503 minecraft:bookshelf
fill 6 149 502 12 149 502 minecraft:bookshelf
fill 8 149 464 8 150 464 minecraft:bookshelf
fill 9 149 504 11 150 504 minecraft:bookshelf
fill 14 149 497 15 150 497 minecraft:green_wool
fill 15 149 464 15 150 464 minecraft:bookshelf
fill 17 149 504 17 150 504 minecraft:bookshelf
fill 22 149 464 22 150 464 minecraft:bookshelf
fill 24 149 504 24 150 504 minecraft:bookshelf
fill 29 149 464 29 150 464 minecraft:bookshelf
fill 31 149 504 31 150 504 minecraft:bookshelf
fill 36 149 464 36 150 464 minecraft:bookshelf
fill 38 149 504 38 150 504 minecraft:bookshelf
fill 41 149 466 41 150 466 minecraft:bookshelf
fill 41 149 473 41 150 473 minecraft:bookshelf
fill 41 149 480 41 150 480 minecraft:bookshelf
fill 41 149 487 41 150 487 minecraft:bookshelf
fill 41 149 494 41 150 494 minecraft:bookshelf
fill 41 149 501 41 150 501 minecraft:bookshelf
fill 1 150 465 1 150 468 minecraft:bookshelf
setblock 1 150 470 minecraft:bookshelf
fill 1 150 472 1 150 475 minecraft:bookshelf
setblock 1 150 477 minecraft:bookshelf
fill 1 150 479 1 150 482 minecraft:bookshelf
setblock 1 150 484 minecraft:bookshelf
fill 1 150 486 1 150 489 minecraft:bookshelf
setblock 1 150 491 minecraft:bookshelf
fill 1 150 493 1 150 496 minecraft:bookshelf
fill 1 150 498 1 152 498 minecraft:bookshelf
fill 1 150 500 1 151 503 minecraft:bookshelf
setblock 2 150 464 minecraft:bookshelf
fill 2 150 501 2 150 504 minecraft:bookshelf
fill 3 150 500 3 150 503 minecraft:bookshelf
fill 4 150 464 7 150 464 minecraft:bookshelf
fill 4 150 502 7 150 503 minecraft:bookshelf
setblock 8 150 502 minecraft:bookshelf
setblock 9 150 464 minecraft:bookshelf
fill 11 150 464 14 150 464 minecraft:bookshelf
fill 12 150 504 14 150 504 minecraft:bookshelf
setblock 16 150 464 minecraft:bookshelf
setblock 16 150 504 minecraft:bookshelf
fill 18 150 464 21 150 464 minecraft:bookshelf
fill 18 150 504 21 150 504 minecraft:bookshelf
setblock 23 150 464 minecraft:bookshelf
setblock 23 150 504 minecraft:bookshelf
fill 25 150 464 28 150 464 minecraft:bookshelf
fill 25 150 504 28 150 504 minecraft:bookshelf
fill 26 150 499 27 151 500 minecraft:white_wool
setblock 30 150 464 minecraft:bookshelf
setblock 30 150 504 minecraft:bookshelf
fill 32 150 464 35 150 464 minecraft:bookshelf
fill 32 150 504 35 150 504 minecraft:bookshelf
setblock 37 150 464 minecraft:bookshelf
setblock 37 150 504 minecraft:bookshelf
fill 39 150 464 41 150 464 minecraft:bookshelf
fill 39 150 504 41 150 504 minecraft:bookshelf
setblock 41 150 465 minecraft:bookshelf
setblock 41 150 467 minecraft:bookshelf
fill 41 150 469 41 150 472 minecraft:bookshelf
setblock 41 150 474 minecraft:bookshelf
fill 41 150 476 41 150 479 minecraft:bookshelf
setblock 41 150 481 minecraft:bookshelf
fill 41 150 483 41 150 486 minecraft:bookshelf
setblock 41 150 488 minecraft:bookshelf
fill 41 150 490 41 150 493 minecraft:bookshelf
setblock 41 150 495 minecraft:bookshelf
fill 41 150 497 41 150 500 minecraft:bookshelf
setblock 41 150 502 minecraft:bookshelf
setblock 1 151 466 minecraft:bookshelf
setblock 1 151 473 minecraft:bookshelf
setblock 1 151 480 minecraft:bookshelf
setblock 1 151 487 minecraft:bookshelf
fill 1 151 494 1 153 494 minecraft:bookshelf
fill 2 151 496 2 151 503 minecraft:bookshelf
fill 3 151 496 3 151 502 minecraft:bookshelf
setblock 5 151 504 minecraft:bookshelf
setblock 6 151 464 minecraft:bookshelf
setblock 12 151 504 minecraft:bookshelf
setblock 13 151 464 minecraft:bookshelf
setblock 19 151 504 minecraft:bookshelf
setblock 20 151 464 minecraft:bookshelf
setblock 26 151 504 minecraft:bookshelf
setblock 27 151 464 minecraft:bookshelf
setblock 33 151 504 minecraft:bookshelf
setblock 34 151 464 minecraft:bookshelf
setblock 40 151 504 minecraft:bookshelf
setblock 41 151 464 minecraft:bookshelf
setblock 41 151 471 minecraft:bookshelf
setblock 41 151 478 minecraft:bookshelf
setblock 41 151 485 minecraft:bookshelf
setblock 41 151 492 minecraft:bookshelf
setblock 41 151 499 minecraft:bookshelf
setblock 1 152 467 minecraft:bookshelf
setblock 1 152 474 minecraft:bookshelf
setblock 1 152 481 minecraft:bookshelf
setblock 1 152 488 minecraft:bookshelf
fill 1 152 493 3 153 493 minecraft:bookshelf
fill 1 152 495 3 152 496 minecraft:bookshelf
setblock 1 152 502 minecraft:bookshelf
fill 2 152 492 3 153 492 minecraft:bookshelf
fill 2 152 494 3 152 494 minecraft:bookshelf
fill 2 152 497 2 152 498 minecraft:bookshelf
setblock 3 152 497 minecraft:bookshelf
setblock 5 152 464 minecraft:bookshelf
setblock 6 152 504 minecraft:bookshelf
setblock 12 152 464 minecraft:bookshelf
setblock 13 152 504 minecraft:bookshelf
setblock 19 152 464 minecraft:bookshelf
fill 19 152 496 19 153 496 minecraft:white_wool
setblock 20 152 504 minecraft:bookshelf
setblock 26 152 464 minecraft:bookshelf
setblock 27 152 504 minecraft:bookshelf
setblock 33 152 464 minecraft:bookshelf
setblock 34 152 504 minecraft:bookshelf
setblock 40 152 464 minecraft:bookshelf
setblock 41 152 470 minecraft:bookshelf
setblock 41 152 477 minecraft:bookshelf
setblock 41 152 484 minecraft:bookshelf
setblock 41 152 491 minecraft:bookshelf
setblock 41 152 498 minecraft:bookshelf
setblock 41 152 504 minecraft:bookshelf
setblock 1 153 468 minecraft:bookshelf
setblock 1 153 475 minecraft:bookshelf
setblock 1 153 482 minecraft:bookshelf
fill 1 153 489 3 154 489 minecraft:bookshelf
fill 1 153 491 1 153 492 minecraft:bookshelf
setblock 1 153 496 minecraft:bookshelf
setblock 1 153 503 minecraft:bookshelf
fill 2 153 490 3 153 491 minecraft:bookshelf
setblock 2 153 494 minecraft:bookshelf
setblock 3 153 466 minecraft:light[level=12]
setblock 3 153 474 minecraft:light[level=12]
setblock 3 153 482 minecraft:light[level=12]
setblock 3 153 498 minecraft:light[level=12]
setblock 4 153 464 minecraft:bookshelf
setblock 7 153 504 minecraft:bookshelf
setblock 11 153 464 minecraft:bookshelf
setblock 11 153 466 minecraft:light[level=12]
setblock 11 153 474 minecraft:light[level=12]
setblock 11 153 482 minecraft:light[level=12]
setblock 11 153 490 minecraft:light[level=12]
setblock 11 153 498 minecraft:light[level=12]
setblock 14 153 504 minecraft:bookshelf
setblock 18 153 464 minecraft:bookshelf
setblock 19 153 466 minecraft:light[level=12]
setblock 19 153 474 minecraft:light[level=12]
setblock 19 153 482 minecraft:light[level=12]
setblock 19 153 490 minecraft:light[level=12]
setblock 19 153 498 minecraft:light[level=12]
setblock 21 153 504 minecraft:bookshelf
setblock 25 153 464 minecraft:bookshelf
setblock 27 153 466 minecraft:light[level=12]
setblock 27 153 474 minecraft:light[level=12]
setblock 27 153 482 minecraft:light[level=12]
setblock 27 153 490 minecraft:light[level=12]
setblock 27 153 498 minecraft:light[level=12]
setblock 28 153 504 minecraft:bookshelf
fill 31 153 469 31 154 471 minecraft:blue_wool
setblock 32 153 464 minecraft:bookshelf
fill 32 153 469 32 154 470 minecraft:blue_wool
setblock 35 153 466 minecraft:light[level=12]
setblock 35 153 474 minecraft:light[level=12]
setblock 35 153 482 minecraft:light[level=12]
setblock 35 153 490 minecraft:light[level=12]
setblock 35 153 498 minecraft:light[level=12]
setblock 35 153 504 minecraft:bookshelf
setblock 39 153 464 minecraft:bookshelf
setblock 41 153 469 minecraft:bookshelf
setblock 41 153 476 minecraft:bookshelf
setblock 41 153 483 minecraft:bookshelf
setblock 41 153 490 minecraft:bookshelf
setblock 41 153 497 minecraft:bookshelf
fill 1 154 486 3 154 488 minecraft:bookshelf
fill 2 154 490 3 154 490 minecraft:bookshelf
setblock 1 155 470 minecraft:bookshelf
setblock 1 155 477 minecraft:bookshelf
fill 1 155 484 3 155 487 minecraft:bookshelf
setblock 1 155 491 minecraft:bookshelf
setblock 1 155 498 minecraft:bookshelf
setblock 2 155 464 minecraft:bookshelf
fill 2 155 483 3 156 483 minecraft:bookshelf
setblock 2 155 504 minecraft:bookshelf
setblock 9 155 464 minecraft:bookshelf
setblock 9 155 504 minecraft:bookshelf
setblock 16 155 464 minecraft:bookshelf
setblock 16 155 504 minecraft:bookshelf
setblock 23 155 464 minecraft:bookshelf
setblock 23 155 504 minecraft:bookshelf
setblock 30 155 464 minecraft:bookshelf
setblock 30 155 504 minecraft:bookshelf
setblock 37 155 464 minecraft:bookshelf
setblock 37 155 504 minecraft:bookshelf
setblock 41 155 467 minecraft:bookshelf
setblock 41 155 474 minecraft:bookshelf
setblock 41 155 481 minecraft:bookshelf
setblock 41 155 488 minecraft:bookshelf
setblock 41 155 495 minecraft:bookshelf
setblock 41 155 502 minecraft:bookshelf
setblock 1 156 464 minecraft:bookshelf
setblock 1 156 471 minecraft:bookshelf
fill 1 156 478 1 157 478 minecraft:bookshelf
fill 1 156 480 3 156 482 minecraft:bookshelf
fill 1 156 484 1 156 485 minecraft:bookshelf
setblock 1 156 492 minecraft:bookshelf
setblock 1 156 499 minecraft:bookshelf
fill 2 156 484 3 156 484 minecraft:bookshelf
setblock 3 156 504 minecraft:bookshelf
setblock 8 156 464 minecraft:bookshelf
setblock 10 156 504 minecraft:bookshelf
setblock 15 156 464 minecraft:bookshelf
setblock 17 156 504 minecraft:bookshelf
setblock 22 156 464 minecraft:bookshelf
setblock 24 156 504 minecraft:bookshelf
setblock 29 156 464 minecraft:bookshelf
setblock 31 156 504 minecraft:bookshelf
setblock 36 156 464 minecraft:bookshelf
setblock 38 156 504 minecraft:bookshelf
setblock 41 156 466 minecraft:bookshelf
setblock 41 156 473 minecraft:bookshelf
setblock 41 156 480 minecraft:bookshelf
setblock 41 156 487 minecraft:bookshelf
setblock 41 156 494 minecraft:bookshelf
setblock 41 156 501 minecraft:bookshelf
setblock 1 157 465 minecraft:bookshelf
fill 1 157 472 1 158 472 minecraft:bookshelf
fill 1 157 477 3 158 477 minecraft:bookshelf
fill 1 157 479 3 157 481 minecraft:bookshelf
setblock 1 157 486 minecraft:bookshelf
setblock 1 157 493 minecraft:bookshelf
setblock 1 157 500 minecraft:bookshelf
fill 2 157 478 3 158 478 minecraft:bookshelf
setblock 4 157 504 minecraft:bookshelf
setblock 7 157 464 minecraft:bookshelf
setblock 11 157 504 minecraft:bookshelf
setblock 14 157 464 minecraft:bookshelf
setblock 18 157 504 minecraft:bookshelf
setblock 21 157 464 minecraft:bookshelf
setblock 25 157 504 minecraft:bookshelf
setblock 28 157 464 minecraft:bookshelf
setblock 32 157 504 minecraft:bookshelf
setblock 35 157 464 minecraft:bookshelf
setblock 39 157 504 minecraft:bookshelf
setblock 41 157 465 minecraft:bookshelf
setblock 41 157 472 minecraft:bookshelf
setblock 41 157 479 minecraft:bookshelf
setblock 41 157 486 minecraft:bookshelf
setblock 41 157 493 minecraft:bookshelf
setblock 41 157 500 minecraft:bookshelf
setblock 1 158 466 minecraft:bookshelf
fill 1 158 473 3 158 475 minecraft:bookshelf
setblock 1 158 480 minecraft:bookshelf
setblock 1 158 487 minecraft:bookshelf
setblock 1 158 494 minecraft:bookshelf
setblock 1 158 501 minecraft:bookshelf
fill 2 158 476 3 158 476 minecraft:bookshelf
setblock 5 158 504 minecraft:bookshelf
setblock 6 158 464 minecraft:bookshelf
setblock 12 158 504 minecraft:bookshelf
setblock 13 158 464 minecraft:bookshelf
setblock 19 158 504 minecraft:bookshelf
setblock 20 158 464 minecraft:bookshelf
setblock 26 158 504 minecraft:bookshelf
setblock 27 158 464 minecraft:bookshelf
setblock 33 158 504 minecraft:bookshelf
setblock 34 158 464 minecraft:bookshelf
setblock 40 158 504 minecraft:bookshelf
setblock 41 158 464 minecraft:bookshelf
setblock 41 158 471 minecraft:bookshelf
setblock 41 158 478 minecraft:bookshelf
setblock 41 158 485 minecraft:bookshelf
setblock 41 158 492 minecraft:bookshelf
setblock 41 158 499 minecraft:bookshelf
setblock 3 161 466 minecraft:light[level=12]
setblock 3 161 474 minecraft:light[level=12]
setblock 3 161 482 minecraft:light[level=12]
setblock 3 161 490 minecraft:light[level=12]
setblock 3 161 498 minecraft:light[level=12]
setblock 11 161 466 minecraft:light[level=12]
setblock 11 161 474 minecraft:light[level=12]
setblock 11 161 482 minecraft:light[level=12]
setblock 11 161 490 minecraft:light[level=12]
setblock 11 161 498 minecraft:light[level=12]
setblock 19 161 466 minecraft:light[level=12]
setblock 19 161 474 minecraft:light[level=12]
setblock 19 161 482 minecraft:light[level=12]
setblock 19 161 490 minecraft:light[level=12]
setblock 19 161 498 minecraft:light[level=12]
setblock 27 161 466 minecraft:light[level=12]
setblock 27 161 474 minecraft:light[level=12]
setblock 27 161 482 minecraft:light[level=12]
setblock 27 161 490 minecraft:light[level=12]
setblock 27 161 498 minecraft:light[level=12]
setblock 35 161 466 minecraft:light[level=12]
setblock 35 161 474 minecraft:light[level=12]
setblock 35 161 482 minecraft:light[level=12]
setblock 35 161 490 minecraft:light[level=12]
setblock 35 161 498 minecraft:light[level=12]
fill 14 164 484 22 164 484 minecraft:white_wool
fill 15 164 480 23 164 483 minecraft:white_wool
fill 15 164 485 23 164 488 minecraft:white_wool
fill 16 164 478 34 164 479 minecraft:white_wool
fill 16 164 489 34 164 490 minecraft:white_wool
fill 17 164 477 33 164 477 minecraft:white_wool
fill 17 164 491 33 164 491 minecraft:white_wool
fill 18 164 476 32 164 476 minecraft:white_wool
fill 18 164 492 32 164 492 minecraft:white_wool
fill 19 164 475 31 164 475 minecraft:white_wool
fill 19 164 493 31 164 493 minecraft:white_wool
fill 21 164 474 29 164 474 minecraft:white_wool
fill 21 164 494 29 164 494 minecraft:white_wool
fill 24 164 480 24 164 482 minecraft:white_wool
fill 24 164 486 24 164 488 minecraft:white_wool
setblock 25 164 473 minecraft:white_wool
fill 25 164 480 35 164 481 minecraft:white_wool
fill 25 164 487 35 164 488 minecraft:white_wool
setblock 25 164 495 minecraft:white_wool
fill 26 164 482 35 164 482 minecraft:white_wool
fill 26 164 486 35 164 486 minecraft:white_wool
fill 27 164 483 35 164 483 minecraft:white_wool
fill 27 164 485 35 164 485 minecraft:white_wool
fill 28 164 484 36 164 484 minecraft:white_wool
fill 1 165 464 13 165 504 minecraft:dark_oak_planks
fill 14 165 464 14 165 483 minecraft:dark_oak_planks
fill 14 165 484 15 165 484 minecraft:brown_wool
fill 14 165 485 14 165 504 minecraft:dark_oak_planks
fill 15 165 464 15 165 479 minecraft:dark_oak_planks
fill 15 165 480 15 165 483 minecraft:brown_wool
fill 15 165 485 15 165 488 minecraft:brown_wool
fill 15 165 489 15 165 504 minecraft:dark_oak_planks
fill 16 165 464 16 165 477 minecraft:dark_oak_planks
fill 16 165 478 16 165 480 minecraft:brown_wool
fill 16 165 481 18 165 487 minecraft:white_wool
fill 16 165 488 16 165 490 minecraft:brown_wool
fill 16 165 491 16 165 504 minecraft:dark_oak_planks
fill 17 165 464 17 165 476 minecraft:dark_oak_planks
fill 17 165 477 17 165 478 minecraft:brown_wool
fill 17 165 479 19 165 480 minecraft:white_wool
fill 17 165 488 19 165 489 minecraft:white_wool
fill 17 165 490 17 165 491 minecraft:brown_wool
fill 17 165 492 17 165 504 minecraft:dark_oak_planks
fill 18 165 464 18 165 475 minecraft:dark_oak_planks
fill 18 165 476 18 165 477 minecraft:brown_wool
fill 18 165 478 22 165 478 minecraft:white_wool
fill 18 165 490 22 165 490 minecraft:white_wool
fill 18 165 491 18 165 492 minecraft:brown_wool
fill 18 165 493 18 165 504 minecraft:dark_oak_planks
fill 19 165 464 20 165 474 minecraft:dark_oak_planks
fill 19 165 475 19 165 476 minecraft:brown_wool
fill 19 165 477 31 165 477 minecraft:white_wool
setblock 19 165 481 minecraft:white_wool
fill 19 165 482 22 165 486 minecraft:mossy_stone_bricks
setblock 19 165 487 minecraft:white_wool
fill 19 165 491 31 165 491 minecraft:white_wool
fill 19 165 492 19 165 493 minecraft:brown_wool
fill 19 165 494 20 165 504 minecraft:dark_oak_planks
fill 20 165 475 21 165 475 minecraft:brown_wool
fill 20 165 476 30 165 476 minecraft:white_wool
setblock 20 165 479 minecraft:white_wool
fill 20 165 480 30 165 481 minecraft:mossy_stone_bricks
fill 20 165 487 30 165 488 minecraft:mossy_stone_bricks
setblock 20 165 489 minecraft:white_wool
fill 20 165 492 30 165 492 minecraft:white_wool
fill 20 165 493 21 165 493 minecraft:brown_wool
fill 21 165 464 24 165 473 minecraft:dark_oak_planks
fill 21 165 474 29 165 474 minecraft:brown_wool
fill 21 165 479 29 165 479 minecraft:mossy_stone_bricks
fill 21 165 489 29 165 489 minecraft:mossy_stone_bricks
fill 21 165 494 29 165 494 minecraft:brown_wool
fill 21 165 495 24 165 504 minecraft:dark_oak_planks
fill 22 165 475 28 165 475 minecraft:white_wool
fill 22 165 493 28 165 493 minecraft:white_wool
fill 23 165 478 27 165 478 minecraft:mossy_stone_bricks
fill 23 165 482 23 165 483 minecraft:mossy_stone_bricks
fill 23 165 485 23 165 486 minecraft:mossy_stone_bricks
fill 23 165 490 27 165 490 minecraft:mossy_stone_bricks
setblock 24 165 482 minecraft:mossy_stone_bricks
setblock 24 165 486 minecraft:mossy_stone_bricks
fill 25 165 464 41 165 472 minecraft:dark_oak_planks
setblock 25 165 473 minecraft:brown_wool
setblock 25 165 495 minecraft:brown_wool
fill 25 165 496 41 165 504 minecraft:dark_oak_planks
fill 26 165 473 41 165 473 minecraft:dark_oak_planks
fill 26 165 482 31 165 482 minecraft:mossy_stone_bricks
fill 26 165 486 31 165 486 minecraft:mossy_stone_bricks
fill 26 165 495 41 165 495 minecraft:dark_oak_planks
fill 27 165 483 31 165 483 minecraft:mossy_stone_bricks
fill 27 165 485 31 165 485 minecraft:mossy_stone_bricks
fill 28 165 478 32 165 478 minecraft:white_wool
fill 28 165 484 31 165 484 minecraft:mossy_stone_bricks
fill 28 165 490 32 165 490 minecraft:white_wool
fill 29 165 475 31 165 475 minecraft:brown_wool
fill 29 165 493 31 165 493 minecraft:brown_wool
fill 30 165 474 41 165 474 minecraft:dark_oak_planks
fill 30 165 479 33 165 479 minecraft:white_wool
fill 30 165 489 33 165 489 minecraft:white_wool
fill 30 165 494 41 165 494 minecraft:dark_oak_planks
fill 31 165 476 32 165 476 minecraft:brown_wool
fill 31 165 480 33 165 481 minecraft:white_wool
fill 31 165 487 33 165 488 minecraft:white_wool
fill 31 165 492 32 165 492 minecraft:brown_wool
fill 32 165 475 41 165 475 minecraft:dark_oak_planks
fill 32 165 477 33 165 477 minecraft:brown_wool
fill 32 165 482 34 165 486 minecraft:white_wool
fill 32 165 491 33 165 491 minecraft:brown_wool
fill 32 165 493 41 165 493 minecraft:dark_oak_planks
fill 33 165 476 41 165 476 minecraft:dark_oak_planks
fill 33 165 478 34 165 478 minecraft:brown_wool
fill 33 165 490 34 165 490 minecraft:brown_wool
fill 33 165 492 41 165 492 minecraft:dark_oak_planks
fill 34 165 477 41 165 477 minecraft:dark_oak_planks
fill 34 165 479 34 165 480 minecraft:brown_wool
setblock 34 165 481 minecraft:white_wool
setblock 34 165 487 minecraft:white_wool
fill 34 165 488 34 165 489 minecraft:brown_wool
fill 34 165 491 41 165 491 minecraft:dark_oak_planks
fill 35 165 478 41 165 479 minecraft:dark_oak_planks
fill 35 165 480 35 165 488 minecraft:brown_wool
fill 35 165 489 41 165 490 minecraft:dark_oak_planks
fill 36 165 480 41 165 483 minecraft:dark_oak_planks
setblock 36 165 484 minecraft:brown_wool
fill 36 165 485 41 165 488 minecraft:dark_oak_planks
fill 37 165 484 41 165 484 minecraft:dark_oak_planks
fill 17 166 482 18 175 486 minecraft:stone_bricks
fill 18 166 477 20 178 480 minecraft:cobblestone
fill 18 166 481 19 175 481 minecraft:stone_bricks
fill 18 166 487 19 176 487 minecraft:stone_bricks
fill 18 166 488 20 178 491 minecraft:cobblestone
fill 21 166 477 21 178 479 minecraft:cobblestone
fill 21 166 489 21 178 491 minecraft:cobblestone
fill 22 166 477 22 175 478 minecraft:stone_bricks
fill 22 166 490 22 175 491 minecraft:stone_bricks
fill 23 166 476 27 175 477 minecraft:stone_bricks
fill 23 166 491 27 175 492 minecraft:stone_bricks
fill 28 166 477 28 175 478 minecraft:stone_bricks
fill 28 166 490 28 176 491 minecraft:stone_bricks
fill 29 166 477 32 178 479 minecraft:cobblestone
fill 29 166 489 32 178 491 minecraft:cobblestone
fill 30 166 480 32 178 480 minecraft:cobblestone
fill 30 166 488 32 178 488 minecraft:cobblestone
fill 31 166 481 32 176 481 minecraft:stone_bricks
fill 31 166 487 32 175 487 minecraft:stone_bricks
fill 32 166 482 33 175 486 minecraft:stone_bricks
fill 1 169 469 1 170 470 minecraft:bookshelf
fill 1 169 476 1 170 477 minecraft:bookshelf
fill 1 169 483 1 170 484 minecraft:bookshelf
fill 1 169 490 1 170 491 minecraft:bookshelf
fill 1 169 497 1 170 498 minecraft:bookshelf
fill 1 169 504 2 170 504 minecraft:bookshelf
fill 2 169 464 3 170 464 minecraft:bookshelf
setblock 3 169 466 minecraft:light[level=12]
setblock 3 169 474 minecraft:light[level=12]
setblock 3 169 482 minecraft:light[level=12]
setblock 3 169 490 minecraft:light[level=12]
setblock 3 169 498 minecraft:light[level=12]
fill 8 169 504 9 170 504 minecraft:bookshelf
fill 9 169 464 10 170 464 minecraft:bookshelf
setblock 11 169 466 minecraft:light[level=12]
setblock 11 169 474 minecraft:light[level=12]
setblock 11 169 482 minecraft:light[level=12]
schedule function dropper:buildpart/108_2 1t
