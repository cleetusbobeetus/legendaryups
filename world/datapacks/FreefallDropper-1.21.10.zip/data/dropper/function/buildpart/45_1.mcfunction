fill 437 150 197 437 151 197 minecraft:chiseled_sandstone
fill 437 150 198 437 152 200 minecraft:terracotta
fill 437 150 201 437 151 201 minecraft:chiseled_sandstone
fill 437 150 202 437 150 203 minecraft:terracotta
fill 438 150 194 438 150 195 minecraft:terracotta
fill 438 150 203 438 150 204 minecraft:terracotta
fill 439 150 193 440 150 193 minecraft:terracotta
fill 439 150 194 439 151 194 minecraft:chiseled_sandstone
fill 439 150 204 439 151 204 minecraft:chiseled_sandstone
fill 439 150 205 440 150 205 minecraft:terracotta
fill 440 150 192 441 150 192 minecraft:terracotta
fill 440 150 206 441 150 206 minecraft:terracotta
fill 442 150 192 442 151 192 minecraft:chiseled_sandstone
fill 442 150 206 442 151 206 minecraft:chiseled_sandstone
fill 443 150 192 445 152 192 minecraft:terracotta
fill 443 150 206 445 152 206 minecraft:terracotta
fill 446 150 192 446 151 192 minecraft:chiseled_sandstone
fill 446 150 206 446 151 206 minecraft:chiseled_sandstone
fill 447 150 192 448 150 192 minecraft:terracotta
fill 447 150 206 448 150 206 minecraft:terracotta
fill 448 150 193 449 150 193 minecraft:terracotta
fill 448 150 205 449 150 205 minecraft:terracotta
fill 449 150 194 449 151 194 minecraft:chiseled_sandstone
fill 449 150 204 449 151 204 minecraft:chiseled_sandstone
fill 450 150 194 450 150 195 minecraft:terracotta
fill 450 150 203 450 150 204 minecraft:terracotta
fill 451 150 195 451 150 196 minecraft:terracotta
fill 451 150 197 451 151 197 minecraft:chiseled_sandstone
fill 451 150 198 451 152 200 minecraft:terracotta
fill 451 150 201 451 151 201 minecraft:chiseled_sandstone
fill 451 150 202 451 150 203 minecraft:terracotta
fill 438 151 195 438 152 203 minecraft:terracotta
fill 439 151 195 439 152 197 minecraft:terracotta
fill 439 151 201 439 152 203 minecraft:terracotta
fill 440 151 193 442 152 194 minecraft:terracotta
setblock 440 151 195 minecraft:chiseled_sandstone
setblock 440 151 203 minecraft:chiseled_sandstone
fill 440 151 204 442 152 205 minecraft:terracotta
fill 443 151 193 448 152 193 minecraft:terracotta
fill 443 151 205 448 152 205 minecraft:terracotta
fill 446 151 194 448 152 194 minecraft:terracotta
fill 446 151 204 448 152 204 minecraft:terracotta
setblock 448 151 195 minecraft:chiseled_sandstone
setblock 448 151 203 minecraft:chiseled_sandstone
fill 449 151 195 450 152 197 minecraft:terracotta
fill 449 151 201 450 152 203 minecraft:terracotta
fill 450 151 198 450 152 200 minecraft:terracotta
fill 424 152 182 434 152 222 minecraft:smooth_sandstone
fill 435 152 182 435 152 195 minecraft:smooth_sandstone
fill 435 152 196 436 152 202 minecraft:terracotta
fill 435 152 203 435 152 222 minecraft:smooth_sandstone
fill 436 152 182 436 152 193 minecraft:smooth_sandstone
fill 436 152 194 437 152 195 minecraft:terracotta
fill 436 152 203 437 152 204 minecraft:terracotta
fill 436 152 205 436 152 222 minecraft:smooth_sandstone
fill 437 152 182 437 152 192 minecraft:smooth_sandstone
fill 437 152 193 439 152 193 minecraft:terracotta
fill 437 152 196 437 152 197 minecraft:terracotta
fill 437 152 201 437 152 202 minecraft:terracotta
fill 437 152 205 439 152 205 minecraft:terracotta
fill 437 152 206 437 152 222 minecraft:smooth_sandstone
fill 438 152 182 438 152 191 minecraft:smooth_sandstone
fill 438 152 192 442 152 192 minecraft:terracotta
fill 438 152 194 439 152 194 minecraft:terracotta
fill 438 152 204 439 152 204 minecraft:terracotta
fill 438 152 206 442 152 206 minecraft:terracotta
fill 438 152 207 438 152 222 minecraft:smooth_sandstone
fill 439 152 182 440 152 190 minecraft:smooth_sandstone
fill 439 152 191 449 152 191 minecraft:terracotta
fill 439 152 198 439 152 200 minecraft:terracotta
fill 439 152 207 449 152 207 minecraft:terracotta
fill 439 152 208 440 152 222 minecraft:smooth_sandstone
fill 440 152 195 440 152 197 minecraft:terracotta
fill 440 152 198 440 152 200 minecraft:lantern
fill 440 152 201 440 152 203 minecraft:terracotta
fill 441 152 182 464 152 189 minecraft:smooth_sandstone
fill 441 152 190 447 152 190 minecraft:terracotta
fill 441 152 195 442 152 195 minecraft:terracotta
fill 441 152 196 441 152 198 minecraft:lantern
fill 441 152 200 441 152 202 minecraft:lantern
fill 441 152 203 442 152 203 minecraft:terracotta
fill 441 152 208 447 152 208 minecraft:terracotta
fill 441 152 209 464 152 222 minecraft:smooth_sandstone
fill 442 152 196 443 152 196 minecraft:lantern
fill 442 152 202 443 152 202 minecraft:lantern
fill 443 152 194 445 152 194 minecraft:terracotta
fill 443 152 195 445 152 195 minecraft:lantern
fill 443 152 203 445 152 203 minecraft:lantern
fill 443 152 204 445 152 204 minecraft:terracotta
fill 445 152 196 447 152 196 minecraft:lantern
fill 445 152 202 447 152 202 minecraft:lantern
fill 446 152 192 450 152 192 minecraft:terracotta
fill 446 152 195 448 152 195 minecraft:terracotta
fill 446 152 203 448 152 203 minecraft:terracotta
fill 446 152 206 450 152 206 minecraft:terracotta
fill 447 152 197 447 152 198 minecraft:lantern
fill 447 152 200 447 152 201 minecraft:lantern
fill 448 152 190 464 152 190 minecraft:smooth_sandstone
fill 448 152 196 448 152 197 minecraft:terracotta
fill 448 152 198 448 152 200 minecraft:lantern
fill 448 152 201 448 152 202 minecraft:terracotta
fill 448 152 208 464 152 208 minecraft:smooth_sandstone
fill 449 152 193 451 152 194 minecraft:terracotta
fill 449 152 198 449 152 200 minecraft:terracotta
fill 449 152 204 451 152 205 minecraft:terracotta
fill 450 152 191 464 152 191 minecraft:smooth_sandstone
fill 450 152 207 464 152 207 minecraft:smooth_sandstone
fill 451 152 192 464 152 192 minecraft:smooth_sandstone
fill 451 152 195 452 152 197 minecraft:terracotta
fill 451 152 201 452 152 203 minecraft:terracotta
fill 451 152 206 464 152 206 minecraft:smooth_sandstone
fill 452 152 193 464 152 193 minecraft:smooth_sandstone
setblock 452 152 194 minecraft:terracotta
fill 452 152 198 453 152 200 minecraft:terracotta
setblock 452 152 204 minecraft:terracotta
fill 452 152 205 464 152 205 minecraft:smooth_sandstone
fill 453 152 194 464 152 195 minecraft:smooth_sandstone
fill 453 152 196 453 152 197 minecraft:terracotta
fill 453 152 201 453 152 202 minecraft:terracotta
fill 453 152 203 464 152 204 minecraft:smooth_sandstone
fill 454 152 196 464 152 202 minecraft:smooth_sandstone
setblock 426 153 184 minecraft:light[level=13]
setblock 426 153 192 minecraft:light[level=13]
setblock 426 153 200 minecraft:light[level=13]
setblock 426 153 208 minecraft:light[level=13]
setblock 426 153 216 minecraft:light[level=13]
setblock 434 153 184 minecraft:light[level=13]
setblock 434 153 192 minecraft:light[level=13]
setblock 434 153 200 minecraft:light[level=13]
setblock 434 153 208 minecraft:light[level=13]
setblock 434 153 216 minecraft:light[level=13]
setblock 441 153 198 minecraft:terracotta
setblock 441 153 200 minecraft:terracotta
setblock 442 153 184 minecraft:light[level=13]
setblock 442 153 192 minecraft:light[level=13]
setblock 442 153 208 minecraft:light[level=13]
setblock 442 153 216 minecraft:light[level=13]
setblock 443 153 196 minecraft:terracotta
setblock 443 153 202 minecraft:terracotta
setblock 445 153 196 minecraft:terracotta
setblock 445 153 202 minecraft:terracotta
setblock 447 153 198 minecraft:terracotta
setblock 447 153 200 minecraft:terracotta
setblock 450 153 184 minecraft:light[level=13]
setblock 450 153 192 minecraft:light[level=13]
setblock 450 153 200 minecraft:light[level=13]
setblock 450 153 208 minecraft:light[level=13]
setblock 450 153 216 minecraft:light[level=13]
setblock 458 153 184 minecraft:light[level=13]
setblock 458 153 192 minecraft:light[level=13]
setblock 458 153 200 minecraft:light[level=13]
setblock 458 153 208 minecraft:light[level=13]
setblock 458 153 216 minecraft:light[level=13]
fill 424 156 188 424 216 189 minecraft:smooth_sandstone
fill 424 156 196 424 216 197 minecraft:smooth_sandstone
fill 424 156 204 424 216 205 minecraft:smooth_sandstone
fill 424 156 212 424 216 213 minecraft:smooth_sandstone
fill 424 156 220 424 216 221 minecraft:smooth_sandstone
fill 425 156 182 426 216 182 minecraft:smooth_sandstone
fill 430 156 222 431 216 222 minecraft:smooth_sandstone
fill 433 156 182 434 216 182 minecraft:smooth_sandstone
fill 434 156 197 434 156 206 minecraft:terracotta
fill 438 156 222 439 216 222 minecraft:smooth_sandstone
fill 441 156 182 442 216 182 minecraft:smooth_sandstone
fill 446 156 222 450 156 222 minecraft:smooth_sandstone
fill 448 156 182 450 156 183 minecraft:smooth_sandstone
fill 448 156 220 450 156 221 minecraft:smooth_sandstone
fill 449 156 184 449 159 184 minecraft:smooth_sandstone
fill 449 156 219 449 159 219 minecraft:smooth_sandstone
fill 454 156 222 455 216 222 minecraft:smooth_sandstone
fill 457 156 182 458 216 182 minecraft:smooth_sandstone
fill 462 156 222 463 216 222 minecraft:smooth_sandstone
fill 464 156 183 464 216 184 minecraft:smooth_sandstone
fill 464 156 191 464 216 192 minecraft:smooth_sandstone
fill 464 156 199 464 216 200 minecraft:smooth_sandstone
fill 464 156 207 464 216 208 minecraft:smooth_sandstone
fill 464 156 215 464 216 216 minecraft:smooth_sandstone
fill 446 157 222 447 216 222 minecraft:smooth_sandstone
fill 448 157 183 448 157 184 minecraft:smooth_sandstone
fill 448 157 219 448 157 220 minecraft:smooth_sandstone
fill 449 157 182 450 157 183 minecraft:smooth_sandstone
fill 449 157 185 449 159 185 minecraft:smooth_sandstone
fill 449 157 218 449 159 218 minecraft:smooth_sandstone
fill 449 157 220 449 157 221 minecraft:smooth_sandstone
setblock 449 157 222 minecraft:terracotta
fill 450 157 184 450 158 184 minecraft:smooth_sandstone
fill 450 157 219 450 157 220 minecraft:smooth_sandstone
fill 423 158 186 423 163 186 minecraft:lantern
fill 423 158 194 423 163 194 minecraft:lantern
fill 423 158 202 423 163 202 minecraft:lantern
fill 423 158 210 423 163 210 minecraft:lantern
fill 423 158 218 423 163 218 minecraft:lantern
fill 426 158 223 426 163 223 minecraft:lantern
fill 430 158 181 430 163 181 minecraft:lantern
fill 434 158 223 434 163 223 minecraft:lantern
fill 438 158 181 438 163 181 minecraft:lantern
fill 442 158 223 442 163 223 minecraft:lantern
fill 446 158 181 446 163 181 minecraft:lantern
fill 448 158 184 448 158 186 minecraft:smooth_sandstone
fill 448 158 217 448 158 219 minecraft:smooth_sandstone
fill 449 158 182 449 158 183 minecraft:smooth_sandstone
fill 449 158 186 450 159 186 minecraft:smooth_sandstone
fill 449 158 217 450 159 217 minecraft:smooth_sandstone
setblock 449 158 220 minecraft:smooth_sandstone
setblock 449 158 221 minecraft:terracotta
fill 450 158 182 450 216 182 minecraft:smooth_sandstone
fill 450 158 185 450 159 185 minecraft:smooth_sandstone
fill 450 158 218 450 158 219 minecraft:smooth_sandstone
fill 450 158 223 450 163 223 minecraft:lantern
fill 454 158 181 454 163 181 minecraft:lantern
fill 458 158 223 458 163 223 minecraft:lantern
fill 462 158 181 462 163 181 minecraft:lantern
fill 465 158 186 465 163 186 minecraft:lantern
fill 465 158 194 465 163 194 minecraft:lantern
fill 465 158 202 465 163 202 minecraft:lantern
fill 465 158 210 465 163 210 minecraft:lantern
fill 465 158 218 465 163 218 minecraft:lantern
fill 448 159 185 448 159 187 minecraft:smooth_sandstone
fill 448 159 216 448 159 218 minecraft:smooth_sandstone
fill 449 159 182 449 216 182 minecraft:smooth_sandstone
setblock 449 159 183 minecraft:terracotta
fill 449 159 187 449 160 188 minecraft:smooth_sandstone
fill 449 159 215 449 161 216 minecraft:smooth_sandstone
setblock 449 159 220 minecraft:terracotta
fill 450 159 187 450 160 187 minecraft:smooth_sandstone
fill 450 159 216 450 160 216 minecraft:smooth_sandstone
setblock 450 159 218 minecraft:smooth_sandstone
fill 448 160 187 448 160 188 minecraft:smooth_sandstone
fill 448 160 215 448 160 216 minecraft:smooth_sandstone
setblock 449 160 185 minecraft:terracotta
setblock 449 160 186 minecraft:smooth_sandstone
fill 449 160 189 449 162 189 minecraft:smooth_sandstone
fill 449 160 214 449 162 214 minecraft:smooth_sandstone
setblock 449 160 217 minecraft:smooth_sandstone
setblock 449 160 218 minecraft:terracotta
fill 450 160 188 450 161 188 minecraft:smooth_sandstone
fill 450 160 215 450 161 215 minecraft:smooth_sandstone
setblock 426 161 184 minecraft:light[level=13]
setblock 426 161 192 minecraft:light[level=13]
setblock 426 161 200 minecraft:light[level=13]
setblock 426 161 208 minecraft:light[level=13]
setblock 426 161 216 minecraft:light[level=13]
setblock 434 161 184 minecraft:light[level=13]
setblock 434 161 192 minecraft:light[level=13]
setblock 434 161 200 minecraft:light[level=13]
setblock 434 161 208 minecraft:light[level=13]
setblock 434 161 216 minecraft:light[level=13]
setblock 442 161 184 minecraft:light[level=13]
setblock 442 161 192 minecraft:light[level=13]
setblock 442 161 200 minecraft:light[level=13]
setblock 442 161 208 minecraft:light[level=13]
setblock 442 161 216 minecraft:light[level=13]
fill 448 161 188 448 161 190 minecraft:smooth_sandstone
fill 448 161 213 448 161 215 minecraft:smooth_sandstone
fill 449 161 186 449 161 187 minecraft:terracotta
setblock 449 161 188 minecraft:smooth_sandstone
fill 449 161 190 449 163 191 minecraft:smooth_sandstone
fill 449 161 212 449 163 213 minecraft:smooth_sandstone
setblock 449 161 217 minecraft:terracotta
setblock 450 161 184 minecraft:light[level=13]
fill 450 161 189 450 161 190 minecraft:smooth_sandstone
setblock 450 161 192 minecraft:light[level=13]
setblock 450 161 200 minecraft:light[level=13]
setblock 450 161 208 minecraft:light[level=13]
fill 450 161 213 450 161 214 minecraft:smooth_sandstone
setblock 450 161 216 minecraft:light[level=13]
setblock 458 161 184 minecraft:light[level=13]
setblock 458 161 192 minecraft:light[level=13]
setblock 458 161 200 minecraft:light[level=13]
setblock 458 161 208 minecraft:light[level=13]
setblock 458 161 216 minecraft:light[level=13]
fill 448 162 190 448 162 192 minecraft:smooth_sandstone
fill 448 162 211 448 162 213 minecraft:smooth_sandstone
setblock 449 162 188 minecraft:terracotta
fill 449 162 192 449 163 193 minecraft:smooth_sandstone
fill 449 162 210 449 164 211 minecraft:smooth_sandstone
setblock 449 162 215 minecraft:terracotta
fill 450 162 190 450 162 192 minecraft:smooth_sandstone
fill 450 162 211 450 162 213 minecraft:smooth_sandstone
fill 448 163 191 448 163 194 minecraft:smooth_sandstone
fill 448 163 209 448 163 212 minecraft:smooth_sandstone
setblock 449 163 189 minecraft:terracotta
fill 449 163 194 449 165 195 minecraft:smooth_sandstone
fill 449 163 208 449 165 209 minecraft:smooth_sandstone
setblock 449 163 214 minecraft:terracotta
fill 450 163 191 450 163 194 minecraft:smooth_sandstone
fill 450 163 209 450 163 212 minecraft:smooth_sandstone
fill 423 164 186 423 171 186 minecraft:cut_sandstone
fill 423 164 194 423 171 194 minecraft:cut_sandstone
fill 423 164 202 423 171 202 minecraft:cut_sandstone
fill 423 164 210 423 171 210 minecraft:cut_sandstone
fill 423 164 218 423 171 218 minecraft:cut_sandstone
fill 426 164 223 426 171 223 minecraft:cut_sandstone
fill 430 164 181 430 171 181 minecraft:cut_sandstone
fill 434 164 223 434 171 223 minecraft:cut_sandstone
fill 438 164 181 438 171 181 minecraft:cut_sandstone
fill 442 164 223 442 171 223 minecraft:cut_sandstone
fill 446 164 181 446 171 181 minecraft:cut_sandstone
fill 448 164 193 448 164 196 minecraft:smooth_sandstone
fill 448 164 207 448 164 210 minecraft:smooth_sandstone
fill 449 164 191 449 164 192 minecraft:terracotta
fill 449 164 193 450 164 193 minecraft:smooth_sandstone
fill 449 164 196 449 165 200 minecraft:smooth_sandstone
fill 449 164 203 449 165 207 minecraft:smooth_sandstone
setblock 449 164 212 minecraft:terracotta
fill 450 164 194 450 164 196 minecraft:smooth_sandstone
fill 450 164 207 450 164 210 minecraft:smooth_sandstone
fill 450 164 223 450 171 223 minecraft:cut_sandstone
fill 454 164 181 454 171 181 minecraft:cut_sandstone
fill 458 164 223 458 171 223 minecraft:cut_sandstone
fill 462 164 181 462 171 181 minecraft:cut_sandstone
fill 465 164 186 465 171 186 minecraft:cut_sandstone
fill 465 164 194 465 171 194 minecraft:cut_sandstone
fill 465 164 202 465 171 202 minecraft:cut_sandstone
fill 465 164 210 465 171 210 minecraft:cut_sandstone
fill 465 164 218 465 171 218 minecraft:cut_sandstone
fill 448 165 196 448 165 197 minecraft:smooth_sandstone
fill 448 165 203 448 165 207 minecraft:smooth_sandstone
fill 449 165 192 449 165 193 minecraft:terracotta
fill 449 165 201 450 166 202 minecraft:smooth_sandstone
fill 449 165 210 449 165 211 minecraft:terracotta
fill 450 165 196 450 165 200 minecraft:smooth_sandstone
fill 450 165 203 450 165 207 minecraft:smooth_sandstone
fill 448 166 203 450 166 203 minecraft:smooth_sandstone
fill 449 166 195 449 166 196 minecraft:terracotta
fill 449 166 197 449 166 199 minecraft:smooth_sandstone
fill 449 166 204 449 166 206 minecraft:smooth_sandstone
fill 449 166 207 449 166 208 minecraft:terracotta
setblock 450 166 200 minecraft:smooth_sandstone
fill 449 167 197 449 167 199 minecraft:terracotta
fill 449 167 201 449 167 206 minecraft:terracotta
fill 424 168 182 424 169 187 minecraft:smooth_sandstone
fill 424 168 190 425 168 195 minecraft:smooth_sandstone
fill 424 168 198 425 168 203 minecraft:smooth_sandstone
fill 424 168 206 425 168 211 minecraft:smooth_sandstone
fill 424 168 214 425 168 219 minecraft:smooth_sandstone
fill 424 168 222 429 169 222 minecraft:smooth_sandstone
fill 425 168 183 425 168 189 minecraft:smooth_sandstone
fill 425 168 196 425 168 197 minecraft:smooth_sandstone
fill 425 168 204 425 168 205 minecraft:smooth_sandstone
fill 425 168 212 425 168 213 minecraft:smooth_sandstone
fill 425 168 220 425 168 221 minecraft:smooth_sandstone
fill 426 168 183 463 168 183 minecraft:smooth_sandstone
fill 426 168 221 464 168 221 minecraft:smooth_sandstone
fill 427 168 182 432 169 182 minecraft:smooth_sandstone
fill 432 168 222 437 169 222 minecraft:smooth_sandstone
fill 435 168 182 440 169 182 minecraft:smooth_sandstone
fill 440 168 222 445 169 222 minecraft:smooth_sandstone
fill 443 168 182 448 169 182 minecraft:smooth_sandstone
fill 448 168 222 453 169 222 minecraft:smooth_sandstone
fill 451 168 182 456 169 182 minecraft:smooth_sandstone
fill 456 168 222 461 169 222 minecraft:smooth_sandstone
fill 459 168 182 464 169 182 minecraft:smooth_sandstone
fill 463 168 184 463 168 220 minecraft:smooth_sandstone
fill 464 168 185 464 169 190 minecraft:smooth_sandstone
fill 464 168 193 464 169 198 minecraft:smooth_sandstone
fill 464 168 201 464 169 206 minecraft:smooth_sandstone
fill 464 168 209 464 169 214 minecraft:smooth_sandstone
fill 464 168 217 464 169 220 minecraft:smooth_sandstone
fill 464 168 222 464 169 222 minecraft:smooth_sandstone
fill 424 169 190 424 169 195 minecraft:smooth_sandstone
fill 424 169 198 424 169 203 minecraft:smooth_sandstone
fill 424 169 206 424 169 211 minecraft:smooth_sandstone
fill 424 169 214 424 169 219 minecraft:smooth_sandstone
setblock 426 169 184 minecraft:light[level=13]
setblock 426 169 192 minecraft:light[level=13]
setblock 426 169 200 minecraft:light[level=13]
setblock 426 169 208 minecraft:light[level=13]
setblock 426 169 216 minecraft:light[level=13]
setblock 434 169 184 minecraft:light[level=13]
setblock 434 169 192 minecraft:light[level=13]
setblock 434 169 200 minecraft:light[level=13]
setblock 434 169 208 minecraft:light[level=13]
setblock 434 169 216 minecraft:light[level=13]
setblock 442 169 184 minecraft:light[level=13]
setblock 442 169 192 minecraft:light[level=13]
setblock 442 169 200 minecraft:light[level=13]
setblock 442 169 208 minecraft:light[level=13]
setblock 442 169 216 minecraft:light[level=13]
fill 447 169 211 449 216 212 minecraft:smooth_sandstone
fill 448 169 213 448 216 213 minecraft:smooth_sandstone
setblock 450 169 184 minecraft:light[level=13]
setblock 450 169 192 minecraft:light[level=13]
setblock 450 169 200 minecraft:light[level=13]
setblock 450 169 208 minecraft:light[level=13]
setblock 450 169 216 minecraft:light[level=13]
setblock 458 169 184 minecraft:light[level=13]
setblock 458 169 192 minecraft:light[level=13]
setblock 458 169 200 minecraft:light[level=13]
setblock 458 169 208 minecraft:light[level=13]
setblock 458 169 216 minecraft:light[level=13]
setblock 464 169 221 minecraft:smooth_sandstone
fill 447 170 213 447 171 213 minecraft:brown_terracotta
fill 448 170 210 448 171 210 minecraft:brown_terracotta
fill 449 170 213 449 171 213 minecraft:brown_terracotta
fill 450 170 212 450 171 212 minecraft:brown_terracotta
fill 446 171 192 449 216 192 minecraft:smooth_sandstone
fill 446 171 211 446 171 213 minecraft:brown_terracotta
fill 447 171 191 449 216 191 minecraft:smooth_sandstone
fill 447 171 193 449 216 193 minecraft:smooth_sandstone
setblock 447 171 210 minecraft:brown_terracotta
fill 447 171 214 449 171 214 minecraft:brown_terracotta
fill 448 171 194 448 216 194 minecraft:smooth_sandstone
setblock 449 171 210 minecraft:brown_terracotta
setblock 450 171 211 minecraft:brown_terracotta
setblock 450 171 213 minecraft:brown_terracotta
fill 423 172 186 423 177 186 minecraft:lantern
fill 423 172 194 423 177 194 minecraft:lantern
fill 423 172 202 423 177 202 minecraft:lantern
fill 423 172 210 423 177 210 minecraft:lantern
fill 423 172 218 423 177 218 minecraft:lantern
fill 426 172 223 426 177 223 minecraft:lantern
fill 430 172 181 430 177 181 minecraft:lantern
fill 434 172 223 434 177 223 minecraft:lantern
fill 438 172 181 438 177 181 minecraft:lantern
fill 442 172 223 442 177 223 minecraft:lantern
fill 446 172 181 446 177 181 minecraft:lantern
fill 446 172 191 446 173 191 minecraft:brown_terracotta
fill 446 172 193 446 173 194 minecraft:brown_terracotta
fill 447 172 190 449 173 190 minecraft:brown_terracotta
fill 447 172 194 447 173 194 minecraft:brown_terracotta
fill 449 172 194 449 173 194 minecraft:brown_terracotta
fill 450 172 191 450 173 193 minecraft:brown_terracotta
fill 450 172 223 450 177 223 minecraft:lantern
fill 454 172 181 454 177 181 minecraft:lantern
fill 458 172 223 458 177 223 minecraft:lantern
fill 462 172 181 462 177 181 minecraft:lantern
fill 465 172 186 465 177 186 minecraft:lantern
fill 465 172 194 465 177 194 minecraft:lantern
fill 465 172 202 465 177 202 minecraft:lantern
fill 465 172 210 465 177 210 minecraft:lantern
fill 465 172 218 465 177 218 minecraft:lantern
fill 445 173 191 445 173 193 minecraft:brown_terracotta
setblock 446 173 190 minecraft:brown_terracotta
fill 446 173 195 449 173 195 minecraft:brown_terracotta
fill 447 173 189 448 173 189 minecraft:brown_terracotta
setblock 450 173 190 minecraft:brown_terracotta
setblock 450 173 194 minecraft:brown_terracotta
fill 451 173 192 451 173 193 minecraft:brown_terracotta
fill 454 174 197 457 216 198 minecraft:smooth_sandstone
fill 455 174 196 457 216 196 minecraft:smooth_sandstone
fill 455 174 199 457 216 199 minecraft:smooth_sandstone
fill 457 174 213 461 175 217 minecraft:brown_terracotta
fill 462 174 215 463 174 215 minecraft:brown_terracotta
fill 453 175 198 453 176 198 minecraft:brown_terracotta
fill 454 175 196 454 176 196 minecraft:brown_terracotta
fill 454 175 199 454 176 200 minecraft:brown_terracotta
fill 455 175 195 456 176 195 minecraft:brown_terracotta
fill 455 175 200 457 176 200 minecraft:brown_terracotta
fill 458 175 196 458 176 199 minecraft:brown_terracotta
fill 453 176 196 453 176 197 minecraft:brown_terracotta
fill 453 176 199 453 176 200 minecraft:brown_terracotta
setblock 454 176 195 minecraft:brown_terracotta
fill 454 176 201 457 176 201 minecraft:brown_terracotta
setblock 456 176 194 minecraft:brown_terracotta
fill 457 176 195 458 176 195 minecraft:brown_terracotta
setblock 458 176 200 minecraft:brown_terracotta
fill 458 176 214 460 177 216 minecraft:smooth_sandstone
fill 459 176 196 459 176 199 minecraft:brown_terracotta
setblock 426 177 184 minecraft:light[level=13]
setblock 426 177 192 minecraft:light[level=13]
setblock 426 177 200 minecraft:light[level=13]
setblock 426 177 208 minecraft:light[level=13]
setblock 426 177 216 minecraft:light[level=13]
setblock 434 177 184 minecraft:light[level=13]
setblock 434 177 192 minecraft:light[level=13]
setblock 434 177 200 minecraft:light[level=13]
setblock 434 177 208 minecraft:light[level=13]
setblock 434 177 216 minecraft:light[level=13]
setblock 442 177 184 minecraft:light[level=13]
setblock 442 177 192 minecraft:light[level=13]
setblock 442 177 200 minecraft:light[level=13]
setblock 442 177 208 minecraft:light[level=13]
setblock 442 177 216 minecraft:light[level=13]
setblock 450 177 184 minecraft:light[level=13]
setblock 450 177 192 minecraft:light[level=13]
setblock 450 177 200 minecraft:light[level=13]
setblock 450 177 208 minecraft:light[level=13]
setblock 450 177 216 minecraft:light[level=13]
setblock 458 177 184 minecraft:light[level=13]
setblock 458 177 192 minecraft:light[level=13]
setblock 458 177 200 minecraft:light[level=13]
setblock 458 177 208 minecraft:light[level=13]
fill 423 178 186 423 185 186 minecraft:cut_sandstone
fill 423 178 194 423 185 194 minecraft:cut_sandstone
fill 423 178 202 423 185 202 minecraft:cut_sandstone
fill 423 178 210 423 185 210 minecraft:cut_sandstone
fill 423 178 218 423 185 218 minecraft:cut_sandstone
fill 426 178 223 426 185 223 minecraft:cut_sandstone
fill 430 178 181 430 185 181 minecraft:cut_sandstone
fill 434 178 223 434 185 223 minecraft:cut_sandstone
fill 438 178 181 438 185 181 minecraft:cut_sandstone
fill 442 178 223 442 185 223 minecraft:cut_sandstone
fill 446 178 181 446 185 181 minecraft:cut_sandstone
fill 450 178 223 450 185 223 minecraft:cut_sandstone
fill 454 178 181 454 185 181 minecraft:cut_sandstone
fill 458 178 215 460 180 215 minecraft:smooth_sandstone
fill 458 178 223 458 185 223 minecraft:cut_sandstone
fill 459 178 214 459 180 214 minecraft:smooth_sandstone
fill 459 178 216 459 180 216 minecraft:smooth_sandstone
fill 462 178 181 462 185 181 minecraft:cut_sandstone
fill 465 178 186 465 185 186 minecraft:cut_sandstone
fill 465 178 194 465 185 194 minecraft:cut_sandstone
fill 465 178 202 465 185 202 minecraft:cut_sandstone
fill 465 178 210 465 185 210 minecraft:cut_sandstone
fill 465 178 218 465 185 218 minecraft:cut_sandstone
fill 459 181 215 459 185 215 minecraft:smooth_sandstone
fill 424 182 182 424 183 187 minecraft:smooth_sandstone
fill 424 182 190 425 182 195 minecraft:smooth_sandstone
fill 424 182 198 425 182 203 minecraft:smooth_sandstone
fill 424 182 206 425 182 211 minecraft:smooth_sandstone
fill 424 182 214 425 182 219 minecraft:smooth_sandstone
fill 424 182 222 429 183 222 minecraft:smooth_sandstone
fill 425 182 183 425 182 189 minecraft:smooth_sandstone
fill 425 182 196 425 182 197 minecraft:smooth_sandstone
fill 425 182 204 425 182 205 minecraft:smooth_sandstone
fill 425 182 212 425 182 213 minecraft:smooth_sandstone
fill 425 182 220 425 182 221 minecraft:smooth_sandstone
fill 426 182 183 463 182 183 minecraft:smooth_sandstone
fill 426 182 221 464 182 221 minecraft:smooth_sandstone
fill 427 182 182 432 183 182 minecraft:smooth_sandstone
fill 432 182 222 437 183 222 minecraft:smooth_sandstone
fill 435 182 182 440 183 182 minecraft:smooth_sandstone
fill 440 182 222 445 183 222 minecraft:smooth_sandstone
fill 443 182 182 448 183 182 minecraft:smooth_sandstone
fill 448 182 222 453 183 222 minecraft:smooth_sandstone
fill 451 182 182 456 183 182 minecraft:smooth_sandstone
fill 456 182 222 461 183 222 minecraft:smooth_sandstone
fill 459 182 182 464 183 182 minecraft:smooth_sandstone
fill 463 182 184 463 182 220 minecraft:smooth_sandstone
fill 464 182 185 464 183 190 minecraft:smooth_sandstone
fill 464 182 193 464 183 198 minecraft:smooth_sandstone
fill 464 182 201 464 183 206 minecraft:smooth_sandstone
fill 464 182 209 464 183 214 minecraft:smooth_sandstone
fill 464 182 217 464 183 220 minecraft:smooth_sandstone
fill 464 182 222 464 183 222 minecraft:smooth_sandstone
fill 424 183 190 424 183 195 minecraft:smooth_sandstone
fill 424 183 198 424 183 203 minecraft:smooth_sandstone
fill 424 183 206 424 183 211 minecraft:smooth_sandstone
fill 424 183 214 424 183 219 minecraft:smooth_sandstone
setblock 464 183 221 minecraft:smooth_sandstone
setblock 426 185 184 minecraft:light[level=13]
setblock 426 185 192 minecraft:light[level=13]
setblock 426 185 200 minecraft:light[level=13]
setblock 426 185 208 minecraft:light[level=13]
setblock 426 185 216 minecraft:light[level=13]
setblock 434 185 184 minecraft:light[level=13]
setblock 434 185 192 minecraft:light[level=13]
setblock 434 185 200 minecraft:light[level=13]
setblock 434 185 208 minecraft:light[level=13]
setblock 434 185 216 minecraft:light[level=13]
setblock 442 185 184 minecraft:light[level=13]
setblock 442 185 192 minecraft:light[level=13]
setblock 442 185 200 minecraft:light[level=13]
setblock 442 185 208 minecraft:light[level=13]
setblock 442 185 216 minecraft:light[level=13]
setblock 450 185 184 minecraft:light[level=13]
setblock 450 185 192 minecraft:light[level=13]
setblock 450 185 200 minecraft:light[level=13]
setblock 450 185 208 minecraft:light[level=13]
setblock 450 185 216 minecraft:light[level=13]
setblock 458 185 184 minecraft:light[level=13]
setblock 458 185 192 minecraft:light[level=13]
setblock 458 185 200 minecraft:light[level=13]
setblock 458 185 208 minecraft:light[level=13]
setblock 458 185 216 minecraft:light[level=13]
fill 423 186 186 423 191 186 minecraft:lantern
fill 423 186 194 423 191 194 minecraft:lantern
fill 423 186 202 423 191 202 minecraft:lantern
fill 423 186 210 423 191 210 minecraft:lantern
fill 423 186 218 423 191 218 minecraft:lantern
fill 426 186 223 426 191 223 minecraft:lantern
fill 430 186 181 430 191 181 minecraft:lantern
fill 434 186 223 434 191 223 minecraft:lantern
fill 438 186 181 438 191 181 minecraft:lantern
fill 442 186 223 442 191 223 minecraft:lantern
fill 446 186 181 446 191 181 minecraft:lantern
fill 450 186 223 450 191 223 minecraft:lantern
fill 454 186 181 454 191 181 minecraft:lantern
fill 458 186 223 458 191 223 minecraft:lantern
setblock 459 186 215 minecraft:lantern
fill 462 186 181 462 191 181 minecraft:lantern
fill 465 186 186 465 191 186 minecraft:lantern
fill 465 186 194 465 191 194 minecraft:lantern
fill 465 186 202 465 191 202 minecraft:lantern
fill 465 186 210 465 191 210 minecraft:lantern
fill 465 186 218 465 191 218 minecraft:lantern
fill 423 192 186 423 199 186 minecraft:cut_sandstone
fill 423 192 194 423 199 194 minecraft:cut_sandstone
fill 423 192 202 423 199 202 minecraft:cut_sandstone
fill 423 192 210 423 199 210 minecraft:cut_sandstone
fill 423 192 218 423 199 218 minecraft:cut_sandstone
fill 426 192 223 426 199 223 minecraft:cut_sandstone
fill 430 192 181 430 199 181 minecraft:cut_sandstone
fill 434 192 223 434 199 223 minecraft:cut_sandstone
fill 438 192 181 438 199 181 minecraft:cut_sandstone
fill 442 192 223 442 199 223 minecraft:cut_sandstone
fill 446 192 181 446 199 181 minecraft:cut_sandstone
fill 450 192 223 450 199 223 minecraft:cut_sandstone
fill 454 192 181 454 199 181 minecraft:cut_sandstone
fill 458 192 223 458 198 223 minecraft:cut_sandstone
fill 462 192 181 462 199 181 minecraft:cut_sandstone
fill 465 192 186 465 199 186 minecraft:cut_sandstone
fill 465 192 194 465 199 194 minecraft:cut_sandstone
fill 465 192 202 465 199 202 minecraft:cut_sandstone
fill 465 192 210 465 199 210 minecraft:cut_sandstone
fill 465 192 218 465 199 218 minecraft:cut_sandstone
setblock 426 193 184 minecraft:light[level=13]
setblock 426 193 192 minecraft:light[level=13]
setblock 426 193 200 minecraft:light[level=13]
setblock 426 193 208 minecraft:light[level=13]
setblock 426 193 216 minecraft:light[level=13]
setblock 434 193 184 minecraft:light[level=13]
setblock 434 193 192 minecraft:light[level=13]
setblock 434 193 200 minecraft:light[level=13]
setblock 434 193 208 minecraft:light[level=13]
setblock 434 193 216 minecraft:light[level=13]
setblock 442 193 184 minecraft:light[level=13]
setblock 442 193 192 minecraft:light[level=13]
setblock 442 193 200 minecraft:light[level=13]
setblock 442 193 208 minecraft:light[level=13]
setblock 442 193 216 minecraft:light[level=13]
setblock 450 193 184 minecraft:light[level=13]
setblock 450 193 192 minecraft:light[level=13]
setblock 450 193 200 minecraft:light[level=13]
setblock 450 193 208 minecraft:light[level=13]
setblock 450 193 216 minecraft:light[level=13]
setblock 458 193 184 minecraft:light[level=13]
setblock 458 193 192 minecraft:light[level=13]
setblock 458 193 200 minecraft:light[level=13]
setblock 458 193 208 minecraft:light[level=13]
setblock 458 193 216 minecraft:light[level=13]
fill 424 196 182 424 197 187 minecraft:smooth_sandstone
fill 424 196 190 425 196 195 minecraft:smooth_sandstone
fill 424 196 198 425 196 203 minecraft:smooth_sandstone
fill 424 196 206 425 196 211 minecraft:smooth_sandstone
fill 424 196 214 425 196 219 minecraft:smooth_sandstone
fill 424 196 222 429 197 222 minecraft:smooth_sandstone
fill 425 196 183 425 196 189 minecraft:smooth_sandstone
fill 425 196 196 425 196 197 minecraft:smooth_sandstone
fill 425 196 204 425 196 205 minecraft:smooth_sandstone
fill 425 196 212 425 196 213 minecraft:smooth_sandstone
fill 425 196 220 425 196 221 minecraft:smooth_sandstone
fill 426 196 183 463 196 183 minecraft:smooth_sandstone
fill 426 196 221 464 196 221 minecraft:smooth_sandstone
fill 427 196 182 432 197 182 minecraft:smooth_sandstone
fill 432 196 222 437 197 222 minecraft:smooth_sandstone
fill 435 196 182 440 197 182 minecraft:smooth_sandstone
fill 440 196 222 445 197 222 minecraft:smooth_sandstone
fill 443 196 182 448 197 182 minecraft:smooth_sandstone
fill 448 196 222 453 197 222 minecraft:smooth_sandstone
fill 451 196 182 456 197 182 minecraft:smooth_sandstone
fill 456 196 222 461 197 222 minecraft:smooth_sandstone
fill 459 196 182 464 197 182 minecraft:smooth_sandstone
fill 463 196 184 463 196 220 minecraft:smooth_sandstone
fill 464 196 185 464 197 190 minecraft:smooth_sandstone
fill 464 196 193 464 197 198 minecraft:smooth_sandstone
fill 464 196 201 464 197 206 minecraft:smooth_sandstone
fill 464 196 209 464 197 214 minecraft:smooth_sandstone
fill 464 196 217 464 197 220 minecraft:smooth_sandstone
fill 464 196 222 464 197 222 minecraft:smooth_sandstone
fill 424 197 190 424 197 195 minecraft:smooth_sandstone
fill 424 197 198 424 197 203 minecraft:smooth_sandstone
fill 424 197 206 424 197 211 minecraft:smooth_sandstone
fill 424 197 214 424 197 219 minecraft:smooth_sandstone
setblock 464 197 221 minecraft:smooth_sandstone
fill 423 199 181 423 200 181 minecraft:sandstone
fill 423 199 182 423 202 183 minecraft:cut_sandstone
setblock 423 199 189 minecraft:sandstone
fill 423 199 190 423 200 190 minecraft:cut_sandstone
fill 423 199 203 423 202 205 minecraft:cut_sandstone
fill 423 199 206 423 200 206 minecraft:sandstone
fill 423 199 211 423 202 211 minecraft:cut_sandstone
setblock 423 199 212 minecraft:sandstone
fill 423 199 213 423 200 217 minecraft:cut_sandstone
setblock 423 199 219 minecraft:sandstone
fill 423 199 220 423 200 223 minecraft:cut_sandstone
fill 424 199 223 424 202 223 minecraft:cut_sandstone
setblock 425 199 223 minecraft:sandstone
fill 427 199 223 429 199 223 minecraft:cut_sandstone
setblock 430 199 223 minecraft:sandstone
fill 431 199 223 433 202 223 minecraft:cut_sandstone
setblock 432 199 181 minecraft:sandstone
fill 435 199 223 436 199 223 minecraft:cut_sandstone
setblock 437 199 223 minecraft:sandstone
fill 438 199 223 438 203 223 minecraft:cut_sandstone
fill 439 199 181 439 202 181 minecraft:cut_sandstone
setblock 439 199 223 minecraft:sandstone
fill 440 199 181 441 199 181 minecraft:sandstone
fill 440 199 223 440 202 223 minecraft:cut_sandstone
setblock 441 199 223 minecraft:sandstone
setblock 442 199 181 minecraft:cut_sandstone
setblock 444 199 181 minecraft:sandstone
fill 445 199 181 445 200 181 minecraft:cut_sandstone
fill 445 199 223 446 199 223 minecraft:cut_sandstone
setblock 447 199 223 minecraft:sandstone
fill 448 199 223 448 202 223 minecraft:cut_sandstone
fill 453 199 223 454 200 223 minecraft:cut_sandstone
fill 455 199 181 457 200 181 minecraft:cut_sandstone
setblock 455 199 223 minecraft:sandstone
fill 456 199 223 457 202 223 minecraft:cut_sandstone
setblock 458 199 181 minecraft:sandstone
fill 458 199 223 459 199 223 minecraft:sandstone
fill 459 199 181 461 202 181 minecraft:cut_sandstone
fill 465 199 181 465 199 182 minecraft:sandstone
fill 465 199 187 465 202 187 minecraft:cut_sandstone
fill 465 199 188 465 199 189 minecraft:sandstone
fill 465 199 190 465 202 190 minecraft:cut_sandstone
setblock 465 199 203 minecraft:sandstone
fill 465 199 204 465 200 206 minecraft:cut_sandstone
setblock 465 199 207 minecraft:sandstone
fill 465 199 208 465 202 208 minecraft:cut_sandstone
setblock 465 199 209 minecraft:sandstone
fill 423 200 186 423 205 186 minecraft:lantern
fill 423 200 189 423 202 189 minecraft:cut_sandstone
fill 423 200 194 423 205 194 minecraft:lantern
fill 423 200 202 423 205 202 minecraft:lantern
fill 423 200 210 423 205 210 minecraft:lantern
fill 423 200 212 423 202 212 minecraft:cut_sandstone
fill 423 200 218 423 205 218 minecraft:lantern
fill 423 200 219 423 202 219 minecraft:cut_sandstone
fill 425 200 223 425 202 223 minecraft:cut_sandstone
fill 426 200 223 426 205 223 minecraft:lantern
fill 427 200 223 427 202 223 minecraft:cut_sandstone
setblock 428 200 223 minecraft:sandstone
fill 429 200 223 430 202 223 minecraft:cut_sandstone
fill 430 200 181 430 205 181 minecraft:lantern
setblock 431 200 181 minecraft:sandstone
fill 432 200 181 432 202 181 minecraft:cut_sandstone
fill 434 200 223 434 205 223 minecraft:lantern
fill 435 200 223 435 202 223 minecraft:cut_sandstone
fill 436 200 223 436 201 223 minecraft:sandstone
fill 437 200 223 437 202 223 minecraft:cut_sandstone
fill 438 200 181 438 205 181 minecraft:lantern
fill 439 200 223 439 202 223 minecraft:cut_sandstone
fill 440 200 181 441 202 181 minecraft:cut_sandstone
fill 441 200 223 441 202 223 minecraft:cut_sandstone
setblock 442 200 181 minecraft:sandstone
fill 442 200 223 442 205 223 minecraft:lantern
fill 444 200 181 444 202 181 minecraft:cut_sandstone
fill 445 200 182 447 201 182 minecraft:smooth_sandstone
fill 445 200 221 445 201 222 minecraft:smooth_sandstone
setblock 445 200 223 minecraft:sandstone
fill 446 200 181 446 205 181 minecraft:lantern
fill 446 200 221 447 201 221 minecraft:smooth_sandstone
fill 446 200 223 447 202 223 minecraft:cut_sandstone
setblock 450 200 181 minecraft:sandstone
fill 450 200 223 450 205 223 minecraft:lantern
fill 454 200 181 454 205 181 minecraft:lantern
fill 455 200 223 455 202 223 minecraft:cut_sandstone
fill 458 200 181 458 202 181 minecraft:cut_sandstone
fill 458 200 223 458 205 223 minecraft:lantern
fill 459 200 223 462 202 223 minecraft:cut_sandstone
fill 462 200 181 462 205 181 minecraft:lantern
setblock 463 200 223 minecraft:sandstone
fill 465 200 181 465 202 182 minecraft:cut_sandstone
fill 465 200 186 465 205 186 minecraft:lantern
setblock 465 200 188 minecraft:sandstone
fill 465 200 189 465 202 189 minecraft:cut_sandstone
fill 465 200 194 465 205 194 minecraft:lantern
fill 465 200 202 465 205 202 minecraft:lantern
fill 465 200 203 465 202 203 minecraft:cut_sandstone
fill 465 200 207 465 203 207 minecraft:cut_sandstone
fill 465 200 209 465 202 209 minecraft:cut_sandstone
fill 465 200 210 465 205 210 minecraft:lantern
fill 465 200 218 465 205 218 minecraft:lantern
setblock 465 200 219 minecraft:sandstone
fill 465 200 220 465 202 222 minecraft:cut_sandstone
setblock 465 200 223 minecraft:sandstone
fill 423 201 181 423 202 181 minecraft:cut_sandstone
fill 423 201 190 423 201 191 minecraft:sandstone
fill 423 201 192 423 202 193 minecraft:cut_sandstone
fill 423 201 206 423 202 206 minecraft:cut_sandstone
fill 423 201 213 423 202 214 minecraft:cut_sandstone
setblock 423 201 215 minecraft:sandstone
fill 423 201 216 423 202 217 minecraft:cut_sandstone
setblock 423 201 220 minecraft:sandstone
fill 423 201 221 423 202 223 minecraft:cut_sandstone
setblock 425 201 181 minecraft:sandstone
setblock 426 201 184 minecraft:light[level=13]
setblock 426 201 192 minecraft:light[level=13]
setblock 426 201 200 minecraft:light[level=13]
setblock 426 201 208 minecraft:light[level=13]
setblock 426 201 216 minecraft:light[level=13]
setblock 427 201 181 minecraft:sandstone
fill 428 201 181 429 202 181 minecraft:cut_sandstone
fill 428 201 223 428 202 223 minecraft:cut_sandstone
fill 431 201 181 431 202 181 minecraft:cut_sandstone
setblock 434 201 184 minecraft:light[level=13]
setblock 434 201 192 minecraft:light[level=13]
setblock 434 201 200 minecraft:light[level=13]
setblock 434 201 208 minecraft:light[level=13]
setblock 434 201 216 minecraft:light[level=13]
fill 442 201 181 442 202 181 minecraft:cut_sandstone
setblock 442 201 184 minecraft:light[level=13]
setblock 442 201 192 minecraft:light[level=13]
setblock 442 201 200 minecraft:light[level=13]
setblock 442 201 208 minecraft:light[level=13]
setblock 442 201 216 minecraft:light[level=13]
fill 443 201 223 444 201 223 minecraft:sandstone
setblock 445 201 181 minecraft:sandstone
fill 445 201 183 447 202 183 minecraft:smooth_sandstone
fill 445 201 220 447 202 220 minecraft:smooth_sandstone
fill 445 201 223 445 202 223 minecraft:cut_sandstone
fill 446 201 184 446 204 184 minecraft:smooth_sandstone
fill 446 201 219 446 204 219 minecraft:smooth_sandstone
fill 450 201 181 450 202 181 minecraft:cut_sandstone
setblock 450 201 184 minecraft:light[level=13]
setblock 450 201 192 minecraft:light[level=13]
setblock 450 201 200 minecraft:light[level=13]
setblock 450 201 208 minecraft:light[level=13]
setblock 450 201 216 minecraft:light[level=13]
fill 453 201 223 453 202 223 minecraft:cut_sandstone
setblock 454 201 223 minecraft:sandstone
fill 455 201 181 455 202 181 minecraft:cut_sandstone
setblock 456 201 181 minecraft:sandstone
fill 457 201 181 457 202 181 minecraft:cut_sandstone
setblock 458 201 184 minecraft:light[level=13]
setblock 458 201 192 minecraft:light[level=13]
setblock 458 201 200 minecraft:light[level=13]
setblock 458 201 208 minecraft:light[level=13]
setblock 458 201 216 minecraft:light[level=13]
fill 463 201 223 463 202 223 minecraft:cut_sandstone
fill 465 201 188 465 204 188 minecraft:cut_sandstone
setblock 465 201 195 minecraft:sandstone
fill 465 201 204 465 202 205 minecraft:cut_sandstone
setblock 465 201 206 minecraft:sandstone
fill 465 201 219 465 202 219 minecraft:cut_sandstone
fill 465 201 223 465 203 223 minecraft:cut_sandstone
fill 423 202 190 423 202 191 minecraft:cut_sandstone
setblock 423 202 215 minecraft:cut_sandstone
setblock 423 202 220 minecraft:cut_sandstone
setblock 425 202 181 minecraft:cut_sandstone
setblock 427 202 181 minecraft:cut_sandstone
setblock 436 202 223 minecraft:cut_sandstone
fill 443 202 223 444 202 223 minecraft:cut_sandstone
setblock 445 202 181 minecraft:cut_sandstone
fill 445 202 184 445 203 184 minecraft:smooth_sandstone
fill 445 202 219 445 203 219 minecraft:smooth_sandstone
setblock 446 202 182 minecraft:smooth_sandstone
fill 446 202 185 446 204 185 minecraft:smooth_sandstone
fill 446 202 218 446 204 218 minecraft:smooth_sandstone
setblock 446 202 221 minecraft:smooth_sandstone
fill 447 202 184 447 203 184 minecraft:smooth_sandstone
fill 447 202 219 447 203 219 minecraft:smooth_sandstone
setblock 454 202 223 minecraft:cut_sandstone
setblock 456 202 181 minecraft:cut_sandstone
setblock 465 202 195 minecraft:cut_sandstone
setblock 465 202 206 minecraft:cut_sandstone
fill 423 203 181 423 204 185 minecraft:sandstone
fill 423 203 187 423 204 191 minecraft:sandstone
fill 423 203 192 423 204 192 minecraft:cut_sandstone
fill 423 203 193 423 307 193 minecraft:sandstone
setblock 423 203 195 minecraft:cut_sandstone
fill 423 203 196 423 307 201 minecraft:sandstone
fill 423 203 203 423 203 209 minecraft:sandstone
fill 423 203 211 423 203 217 minecraft:sandstone
fill 423 203 219 423 203 222 minecraft:sandstone
setblock 423 203 223 minecraft:cut_sandstone
fill 424 203 223 425 203 223 minecraft:sandstone
fill 425 203 181 429 204 181 minecraft:sandstone
fill 427 203 223 433 204 223 minecraft:sandstone
fill 431 203 181 437 307 181 minecraft:sandstone
fill 435 203 223 437 203 223 minecraft:sandstone
fill 439 203 181 445 307 181 minecraft:sandstone
fill 439 203 223 441 203 223 minecraft:sandstone
fill 443 203 223 449 203 223 minecraft:sandstone
fill 445 203 185 445 204 186 minecraft:smooth_sandstone
fill 445 203 217 445 204 218 minecraft:smooth_sandstone
setblock 446 203 182 minecraft:terracotta
setblock 446 203 183 minecraft:smooth_sandstone
fill 446 203 186 447 204 186 minecraft:smooth_sandstone
fill 446 203 217 447 204 217 minecraft:smooth_sandstone
setblock 446 203 220 minecraft:smooth_sandstone
setblock 446 203 221 minecraft:terracotta
fill 447 203 181 453 203 181 minecraft:sandstone
fill 447 203 185 447 204 185 minecraft:smooth_sandstone
fill 447 203 218 447 204 218 minecraft:smooth_sandstone
fill 451 203 223 457 203 223 minecraft:sandstone
fill 455 203 181 461 203 181 minecraft:sandstone
fill 459 203 223 464 204 223 minecraft:sandstone
fill 463 203 181 465 203 181 minecraft:sandstone
setblock 465 203 182 minecraft:cut_sandstone
fill 465 203 183 465 203 185 minecraft:sandstone
fill 465 203 187 465 307 187 minecraft:sandstone
fill 465 203 189 465 203 193 minecraft:sandstone
fill 465 203 195 465 307 201 minecraft:sandstone
fill 465 203 203 465 204 206 minecraft:sandstone
fill 465 203 208 465 203 209 minecraft:sandstone
fill 465 203 211 465 204 217 minecraft:sandstone
fill 465 203 219 465 203 220 minecraft:sandstone
setblock 465 203 221 minecraft:cut_sandstone
fill 465 203 222 465 307 222 minecraft:sandstone
fill 423 204 195 423 307 195 minecraft:sandstone
fill 423 204 203 423 204 207 minecraft:sandstone
setblock 423 204 208 minecraft:cut_sandstone
fill 423 204 209 423 307 209 minecraft:sandstone
fill 423 204 211 423 204 212 minecraft:sandstone
setblock 423 204 213 minecraft:cut_sandstone
fill 423 204 214 423 307 217 minecraft:sandstone
fill 423 204 219 423 307 221 minecraft:sandstone
setblock 423 204 222 minecraft:cut_sandstone
fill 423 204 223 424 204 223 minecraft:sandstone
fill 424 204 181 424 307 181 minecraft:sandstone
fill 425 204 223 425 205 223 minecraft:cut_sandstone
fill 435 204 223 435 307 223 minecraft:sandstone
setblock 436 204 223 minecraft:cut_sandstone
fill 437 204 223 440 204 223 minecraft:sandstone
setblock 441 204 223 minecraft:cut_sandstone
fill 443 204 223 447 307 223 minecraft:sandstone
fill 445 204 187 447 205 187 minecraft:smooth_sandstone
fill 445 204 216 447 205 216 minecraft:smooth_sandstone
setblock 446 204 183 minecraft:terracotta
fill 446 204 188 446 206 188 minecraft:smooth_sandstone
fill 446 204 215 446 206 215 minecraft:smooth_sandstone
setblock 446 204 220 minecraft:terracotta
fill 447 204 181 451 204 181 minecraft:sandstone
setblock 448 204 223 minecraft:cut_sandstone
fill 449 204 223 449 307 223 minecraft:sandstone
fill 451 204 223 452 204 223 minecraft:cut_sandstone
fill 452 204 181 452 205 181 minecraft:cut_sandstone
fill 453 204 181 453 307 181 minecraft:sandstone
fill 453 204 223 453 307 223 minecraft:sandstone
setblock 454 204 223 minecraft:cut_sandstone
setblock 455 204 181 minecraft:cut_sandstone
fill 455 204 223 457 307 223 minecraft:sandstone
fill 456 204 181 461 204 181 minecraft:sandstone
fill 463 204 181 464 307 181 minecraft:sandstone
fill 465 204 181 465 205 181 minecraft:cut_sandstone
fill 465 204 182 465 307 182 minecraft:sandstone
setblock 465 204 183 minecraft:cut_sandstone
fill 465 204 184 465 307 185 minecraft:sandstone
fill 465 204 189 465 307 191 minecraft:sandstone
fill 465 204 192 465 205 192 minecraft:cut_sandstone
fill 465 204 193 465 307 193 minecraft:sandstone
fill 465 204 207 465 307 207 minecraft:sandstone
setblock 465 204 208 minecraft:cut_sandstone
fill 465 204 209 465 307 209 minecraft:sandstone
setblock 465 204 219 minecraft:cut_sandstone
fill 465 204 220 465 307 221 minecraft:sandstone
fill 465 204 223 465 307 223 minecraft:sandstone
setblock 423 205 181 minecraft:cut_sandstone
fill 423 205 182 423 307 183 minecraft:sandstone
setblock 423 205 184 minecraft:cut_sandstone
fill 423 205 185 423 307 185 minecraft:sandstone
fill 423 205 187 423 205 188 minecraft:cut_sandstone
fill 423 205 189 423 307 192 minecraft:sandstone
fill 423 205 203 423 307 204 minecraft:sandstone
setblock 423 205 205 minecraft:cut_sandstone
fill 423 205 206 423 307 206 minecraft:sandstone
setblock 423 205 207 minecraft:cut_sandstone
fill 423 205 208 423 307 208 minecraft:sandstone
fill 423 205 211 423 307 211 minecraft:sandstone
setblock 423 205 212 minecraft:cut_sandstone
fill 423 205 213 423 307 213 minecraft:sandstone
fill 423 205 222 423 307 222 minecraft:sandstone
setblock 423 205 223 minecraft:cut_sandstone
fill 424 205 223 424 307 223 minecraft:sandstone
fill 425 205 181 425 307 181 minecraft:sandstone
setblock 426 205 181 minecraft:cut_sandstone
fill 427 205 181 427 307 181 minecraft:sandstone
fill 427 205 223 431 307 223 minecraft:sandstone
fill 428 205 181 429 205 181 minecraft:cut_sandstone
setblock 432 205 223 minecraft:cut_sandstone
fill 433 205 223 433 307 223 minecraft:sandstone
fill 436 205 223 437 307 223 minecraft:sandstone
setblock 438 205 223 minecraft:cut_sandstone
fill 439 205 223 441 307 223 minecraft:sandstone
fill 445 205 188 445 206 188 minecraft:smooth_sandstone
fill 445 205 215 445 206 215 minecraft:smooth_sandstone
setblock 446 205 185 minecraft:terracotta
setblock 446 205 186 minecraft:smooth_sandstone
fill 446 205 189 446 207 189 minecraft:smooth_sandstone
fill 446 205 214 446 207 214 minecraft:smooth_sandstone
setblock 446 205 217 minecraft:smooth_sandstone
setblock 446 205 218 minecraft:terracotta
fill 447 205 181 450 307 181 minecraft:sandstone
fill 447 205 188 447 206 188 minecraft:smooth_sandstone
fill 447 205 215 447 206 215 minecraft:smooth_sandstone
fill 448 205 223 448 307 223 minecraft:sandstone
setblock 451 205 181 minecraft:cut_sandstone
fill 451 205 223 452 307 223 minecraft:sandstone
fill 454 205 223 454 307 223 minecraft:sandstone
fill 455 205 181 457 307 181 minecraft:sandstone
setblock 458 205 181 minecraft:cut_sandstone
fill 459 205 181 460 307 181 minecraft:sandstone
fill 459 205 223 462 307 223 minecraft:sandstone
setblock 461 205 181 minecraft:cut_sandstone
setblock 463 205 223 minecraft:cut_sandstone
fill 464 205 223 464 307 223 minecraft:sandstone
fill 465 205 183 465 307 183 minecraft:sandstone
fill 465 205 188 465 307 188 minecraft:sandstone
fill 465 205 203 465 307 203 minecraft:sandstone
setblock 465 205 204 minecraft:cut_sandstone
fill 465 205 205 465 307 206 minecraft:sandstone
fill 465 205 208 465 307 208 minecraft:sandstone
fill 465 205 211 465 307 213 minecraft:sandstone
fill 465 205 214 465 205 215 minecraft:cut_sandstone
fill 465 205 216 465 307 217 minecraft:sandstone
fill 465 205 219 465 307 219 minecraft:sandstone
fill 423 206 181 423 307 181 minecraft:sandstone
fill 423 206 184 423 307 184 minecraft:sandstone
fill 423 206 186 423 213 188 minecraft:sandstone
fill 423 206 194 423 213 194 minecraft:sandstone
fill 423 206 202 423 213 202 minecraft:sandstone
fill 423 206 205 423 307 205 minecraft:sandstone
fill 423 206 207 423 307 207 minecraft:sandstone
fill 423 206 210 423 213 210 minecraft:sandstone
fill 423 206 212 423 307 212 minecraft:sandstone
fill 423 206 218 423 213 218 minecraft:sandstone
fill 423 206 223 423 307 223 minecraft:sandstone
fill 425 206 223 426 213 223 minecraft:sandstone
fill 426 206 181 426 307 181 minecraft:sandstone
fill 428 206 181 430 213 181 minecraft:sandstone
fill 432 206 223 432 307 223 minecraft:sandstone
fill 434 206 223 434 213 223 minecraft:sandstone
fill 438 206 181 438 213 181 minecraft:sandstone
fill 438 206 223 438 307 223 minecraft:sandstone
fill 442 206 223 442 213 223 minecraft:sandstone
fill 445 206 189 445 206 190 minecraft:smooth_sandstone
fill 445 206 213 445 206 214 minecraft:smooth_sandstone
fill 446 206 181 446 213 181 minecraft:sandstone
setblock 446 206 186 minecraft:terracotta
setblock 446 206 187 minecraft:smooth_sandstone
fill 446 206 190 446 208 191 minecraft:smooth_sandstone
fill 446 206 212 446 208 213 minecraft:smooth_sandstone
setblock 446 206 216 minecraft:smooth_sandstone
setblock 446 206 217 minecraft:terracotta
fill 447 206 189 447 206 190 minecraft:smooth_sandstone
fill 447 206 213 447 206 214 minecraft:smooth_sandstone
fill 450 206 223 450 213 223 minecraft:sandstone
fill 451 206 181 452 307 181 minecraft:sandstone
fill 454 206 181 454 213 181 minecraft:sandstone
fill 458 206 181 458 307 181 minecraft:sandstone
fill 458 206 223 458 213 223 minecraft:sandstone
fill 461 206 181 462 213 181 minecraft:sandstone
fill 463 206 223 463 307 223 minecraft:sandstone
fill 465 206 181 465 307 181 minecraft:sandstone
fill 465 206 186 465 213 186 minecraft:sandstone
fill 465 206 192 465 307 192 minecraft:sandstone
fill 465 206 194 465 213 194 minecraft:sandstone
fill 465 206 202 465 213 202 minecraft:sandstone
fill 465 206 204 465 307 204 minecraft:sandstone
fill 465 206 210 465 213 210 minecraft:sandstone
fill 465 206 214 465 307 215 minecraft:sandstone
fill 465 206 218 465 213 218 minecraft:sandstone
fill 445 207 190 445 207 192 minecraft:smooth_sandstone
fill 445 207 211 445 207 213 minecraft:smooth_sandstone
setblock 446 207 188 minecraft:terracotta
fill 446 207 193 446 209 193 minecraft:smooth_sandstone
fill 446 207 210 446 209 211 minecraft:smooth_sandstone
setblock 446 207 215 minecraft:terracotta
setblock 447 207 190 minecraft:smooth_sandstone
setblock 447 207 213 minecraft:smooth_sandstone
fill 445 208 191 445 208 194 minecraft:smooth_sandstone
fill 445 208 209 445 208 212 minecraft:smooth_sandstone
setblock 446 208 189 minecraft:terracotta
fill 446 208 194 446 210 195 minecraft:smooth_sandstone
fill 446 208 208 446 210 209 minecraft:smooth_sandstone
setblock 446 208 214 minecraft:terracotta
fill 447 208 194 447 209 194 minecraft:smooth_sandstone
fill 447 208 209 447 209 210 minecraft:smooth_sandstone
setblock 426 209 184 minecraft:light[level=13]
setblock 426 209 192 minecraft:light[level=13]
setblock 426 209 200 minecraft:light[level=13]
setblock 426 209 208 minecraft:light[level=13]
setblock 426 209 216 minecraft:light[level=13]
setblock 434 209 184 minecraft:light[level=13]
setblock 434 209 192 minecraft:light[level=13]
setblock 434 209 200 minecraft:light[level=13]
setblock 434 209 208 minecraft:light[level=13]
setblock 434 209 216 minecraft:light[level=13]
setblock 442 209 184 minecraft:light[level=13]
setblock 442 209 192 minecraft:light[level=13]
setblock 442 209 200 minecraft:light[level=13]
setblock 442 209 208 minecraft:light[level=13]
setblock 442 209 216 minecraft:light[level=13]
fill 445 209 193 445 209 196 minecraft:smooth_sandstone
fill 445 209 207 445 209 210 minecraft:smooth_sandstone
setblock 446 209 191 minecraft:terracotta
fill 446 209 196 446 210 198 minecraft:smooth_sandstone
fill 446 209 206 446 210 207 minecraft:smooth_sandstone
setblock 446 209 212 minecraft:terracotta
fill 447 209 195 447 210 196 minecraft:smooth_sandstone
fill 447 209 207 447 210 208 minecraft:smooth_sandstone
setblock 450 209 184 minecraft:light[level=13]
setblock 450 209 192 minecraft:light[level=13]
setblock 450 209 200 minecraft:light[level=13]
setblock 450 209 208 minecraft:light[level=13]
setblock 450 209 216 minecraft:light[level=13]
setblock 458 209 184 minecraft:light[level=13]
setblock 458 209 192 minecraft:light[level=13]
setblock 458 209 200 minecraft:light[level=13]
setblock 458 209 208 minecraft:light[level=13]
setblock 458 209 216 minecraft:light[level=13]
fill 424 210 182 424 211 187 minecraft:smooth_sandstone
fill 424 210 190 425 210 195 minecraft:smooth_sandstone
fill 424 210 198 425 210 203 minecraft:smooth_sandstone
fill 424 210 206 425 210 211 minecraft:smooth_sandstone
fill 424 210 214 425 210 219 minecraft:smooth_sandstone
fill 424 210 222 429 211 222 minecraft:smooth_sandstone
fill 425 210 183 425 210 189 minecraft:smooth_sandstone
fill 425 210 196 425 210 197 minecraft:smooth_sandstone
fill 425 210 204 425 210 205 minecraft:smooth_sandstone
fill 425 210 212 425 210 213 minecraft:smooth_sandstone
fill 425 210 220 425 210 221 minecraft:smooth_sandstone
fill 426 210 183 463 210 183 minecraft:smooth_sandstone
fill 426 210 221 464 210 221 minecraft:smooth_sandstone
fill 427 210 182 432 211 182 minecraft:smooth_sandstone
fill 432 210 222 437 211 222 minecraft:smooth_sandstone
fill 435 210 182 440 211 182 minecraft:smooth_sandstone
fill 440 210 222 445 211 222 minecraft:smooth_sandstone
fill 443 210 182 448 211 182 minecraft:smooth_sandstone
fill 445 210 195 445 210 199 minecraft:smooth_sandstone
fill 445 210 206 445 210 208 minecraft:smooth_sandstone
setblock 446 210 193 minecraft:terracotta
fill 446 210 210 446 210 211 minecraft:terracotta
fill 447 210 197 447 210 198 minecraft:smooth_sandstone
setblock 447 210 206 minecraft:smooth_sandstone
fill 448 210 222 453 211 222 minecraft:smooth_sandstone
fill 451 210 182 456 211 182 minecraft:smooth_sandstone
fill 456 210 222 461 211 222 minecraft:smooth_sandstone
fill 459 210 182 464 211 182 minecraft:smooth_sandstone
fill 463 210 184 463 210 220 minecraft:smooth_sandstone
fill 464 210 185 464 211 190 minecraft:smooth_sandstone
fill 464 210 193 464 211 198 minecraft:smooth_sandstone
fill 464 210 201 464 211 206 minecraft:smooth_sandstone
fill 464 210 209 464 211 214 minecraft:smooth_sandstone
fill 464 210 217 464 211 220 minecraft:smooth_sandstone
fill 464 210 222 464 211 222 minecraft:smooth_sandstone
fill 424 211 190 424 211 195 minecraft:smooth_sandstone
fill 424 211 198 424 211 203 minecraft:smooth_sandstone
fill 424 211 206 424 211 211 minecraft:smooth_sandstone
fill 424 211 214 424 211 219 minecraft:smooth_sandstone
setblock 445 211 199 minecraft:smooth_sandstone
fill 446 211 194 446 211 196 minecraft:terracotta
fill 446 211 197 446 211 198 minecraft:smooth_sandstone
setblock 446 211 206 minecraft:smooth_sandstone
fill 446 211 207 446 211 209 minecraft:terracotta
setblock 464 211 221 minecraft:smooth_sandstone
fill 446 212 197 446 212 198 minecraft:terracotta
setblock 446 212 206 minecraft:terracotta
fill 445 213 191 445 213 194 minecraft:terracotta
fill 446 213 190 446 214 191 minecraft:terracotta
fill 446 213 193 446 213 195 minecraft:terracotta
fill 446 213 211 446 213 213 minecraft:terracotta
fill 447 213 189 449 213 190 minecraft:terracotta
fill 447 213 194 447 214 195 minecraft:terracotta
fill 447 213 210 450 213 210 minecraft:terracotta
fill 447 213 213 447 213 214 minecraft:terracotta
fill 448 213 195 450 213 195 minecraft:terracotta
fill 448 213 214 449 213 214 minecraft:terracotta
fill 449 213 194 450 214 194 minecraft:terracotta
fill 449 213 213 450 214 213 minecraft:terracotta
fill 450 213 190 450 213 193 minecraft:terracotta
fill 450 213 211 450 214 212 minecraft:terracotta
fill 451 213 191 451 213 193 minecraft:terracotta
fill 452 213 197 453 213 198 minecraft:terracotta
fill 453 213 195 454 213 196 minecraft:terracotta
fill 453 213 199 454 213 200 minecraft:terracotta
fill 454 213 201 458 213 201 minecraft:terracotta
fill 455 213 194 457 213 195 minecraft:terracotta
fill 455 213 200 459 213 200 minecraft:terracotta
fill 458 213 195 458 213 199 minecraft:terracotta
fill 459 213 196 459 213 199 minecraft:terracotta
fill 423 214 186 423 216 186 minecraft:lantern
fill 423 214 187 423 307 188 minecraft:sandstone
fill 423 214 194 423 216 194 minecraft:lantern
fill 423 214 202 423 216 202 minecraft:lantern
fill 423 214 210 423 216 210 minecraft:lantern
fill 423 214 218 423 216 218 minecraft:lantern
fill 425 214 223 425 307 223 minecraft:sandstone
fill 426 214 223 426 216 223 minecraft:lantern
fill 428 214 181 429 307 181 minecraft:sandstone
fill 430 214 181 430 216 181 minecraft:lantern
fill 434 214 223 434 216 223 minecraft:lantern
fill 438 214 181 438 216 181 minecraft:lantern
fill 442 214 223 442 216 223 minecraft:lantern
fill 445 214 192 445 214 193 minecraft:terracotta
fill 446 214 181 446 216 181 minecraft:lantern
fill 446 214 193 446 214 194 minecraft:terracotta
fill 446 214 211 446 214 212 minecraft:terracotta
fill 447 214 190 449 214 190 minecraft:terracotta
fill 447 214 210 449 214 210 minecraft:terracotta
fill 447 214 213 447 215 213 minecraft:terracotta
setblock 448 214 195 minecraft:terracotta
setblock 448 214 214 minecraft:terracotta
fill 450 214 191 450 214 193 minecraft:terracotta
fill 450 214 223 450 216 223 minecraft:lantern
fill 453 214 197 453 214 199 minecraft:terracotta
fill 454 214 181 454 216 181 minecraft:lantern
fill 454 214 195 454 214 196 minecraft:terracotta
fill 454 214 199 454 214 200 minecraft:terracotta
fill 455 214 195 457 214 195 minecraft:terracotta
fill 455 214 200 458 214 200 minecraft:terracotta
setblock 456 214 201 minecraft:terracotta
fill 458 214 196 458 214 199 minecraft:terracotta
fill 458 214 223 458 216 223 minecraft:lantern
fill 459 214 197 459 214 199 minecraft:terracotta
fill 461 214 181 461 307 181 minecraft:sandstone
fill 462 214 181 462 216 181 minecraft:lantern
fill 465 214 186 465 216 186 minecraft:lantern
fill 465 214 194 465 216 194 minecraft:lantern
fill 465 214 202 465 216 202 minecraft:lantern
fill 465 214 210 465 216 210 minecraft:lantern
fill 465 214 218 465 216 218 minecraft:lantern
setblock 446 215 191 minecraft:terracotta
setblock 446 215 193 minecraft:terracotta
fill 447 215 190 448 215 190 minecraft:terracotta
setblock 447 215 194 minecraft:terracotta
setblock 448 215 210 minecraft:terracotta
setblock 449 215 194 minecraft:terracotta
setblock 449 215 213 minecraft:terracotta
fill 450 215 192 450 215 193 minecraft:terracotta
setblock 454 215 196 minecraft:terracotta
setblock 454 215 199 minecraft:terracotta
fill 455 215 200 457 215 200 minecraft:terracotta
fill 458 215 197 458 215 199 minecraft:terracotta
fill 423 217 186 423 227 186 minecraft:sandstone
fill 423 217 194 423 227 194 minecraft:sandstone
fill 423 217 202 423 227 202 minecraft:sandstone
fill 423 217 210 423 227 210 minecraft:sandstone
fill 423 217 218 423 227 218 minecraft:sandstone
setblock 426 217 184 minecraft:light[level=13]
setblock 426 217 192 minecraft:light[level=13]
setblock 426 217 200 minecraft:light[level=13]
setblock 426 217 208 minecraft:light[level=13]
setblock 426 217 216 minecraft:light[level=13]
fill 426 217 223 426 227 223 minecraft:sandstone
fill 430 217 181 430 227 181 minecraft:sandstone
setblock 434 217 184 minecraft:light[level=13]
setblock 434 217 192 minecraft:light[level=13]
setblock 434 217 200 minecraft:light[level=13]
setblock 434 217 208 minecraft:light[level=13]
setblock 434 217 216 minecraft:light[level=13]
fill 434 217 223 434 227 223 minecraft:sandstone
fill 438 217 181 438 227 181 minecraft:sandstone
setblock 442 217 184 minecraft:light[level=13]
setblock 442 217 192 minecraft:light[level=13]
setblock 442 217 200 minecraft:light[level=13]
setblock 442 217 208 minecraft:light[level=13]
setblock 442 217 216 minecraft:light[level=13]
fill 442 217 223 442 227 223 minecraft:sandstone
fill 446 217 181 446 227 181 minecraft:sandstone
setblock 450 217 184 minecraft:light[level=13]
setblock 450 217 192 minecraft:light[level=13]
setblock 450 217 200 minecraft:light[level=13]
setblock 450 217 208 minecraft:light[level=13]
setblock 450 217 216 minecraft:light[level=13]
fill 450 217 223 450 227 223 minecraft:sandstone
fill 454 217 181 454 227 181 minecraft:sandstone
setblock 458 217 184 minecraft:light[level=13]
setblock 458 217 192 minecraft:light[level=13]
setblock 458 217 200 minecraft:light[level=13]
setblock 458 217 208 minecraft:light[level=13]
setblock 458 217 216 minecraft:light[level=13]
fill 458 217 223 458 227 223 minecraft:sandstone
fill 462 217 181 462 227 181 minecraft:sandstone
fill 465 217 186 465 227 186 minecraft:sandstone
fill 465 217 194 465 227 194 minecraft:sandstone
fill 465 217 202 465 227 202 minecraft:sandstone
fill 465 217 210 465 227 210 minecraft:sandstone
fill 465 217 218 465 227 218 minecraft:sandstone
fill 424 222 182 427 224 192 minecraft:brown_terracotta
fill 424 222 193 464 224 193 minecraft:chiseled_sandstone
fill 424 222 194 427 224 204 minecraft:brown_terracotta
fill 424 222 205 446 223 205 minecraft:chiseled_sandstone
fill 424 222 206 427 224 216 minecraft:brown_terracotta
fill 424 222 217 464 224 217 minecraft:chiseled_sandstone
fill 424 222 218 427 224 222 minecraft:brown_terracotta
fill 428 222 182 428 224 192 minecraft:cut_sandstone
fill 428 222 194 428 224 204 minecraft:cut_sandstone
fill 428 222 206 428 224 216 minecraft:cut_sandstone
fill 428 222 218 428 224 222 minecraft:cut_sandstone
fill 429 222 182 432 224 192 minecraft:brown_terracotta
fill 429 222 194 432 224 204 minecraft:brown_terracotta
fill 429 222 206 432 224 216 minecraft:brown_terracotta
fill 429 222 218 432 224 222 minecraft:brown_terracotta
fill 433 222 182 433 224 192 minecraft:cut_sandstone
fill 433 222 194 433 224 204 minecraft:cut_sandstone
fill 433 222 206 433 224 216 minecraft:cut_sandstone
fill 433 222 218 433 224 222 minecraft:cut_sandstone
fill 434 222 182 437 224 192 minecraft:brown_terracotta
fill 434 222 194 437 224 204 minecraft:brown_terracotta
fill 434 222 206 437 224 216 minecraft:brown_terracotta
fill 434 222 218 437 224 222 minecraft:brown_terracotta
fill 438 222 182 438 224 192 minecraft:cut_sandstone
fill 438 222 194 438 224 204 minecraft:cut_sandstone
fill 438 222 206 438 224 216 minecraft:cut_sandstone
fill 438 222 218 438 224 222 minecraft:cut_sandstone
fill 439 222 182 442 224 192 minecraft:brown_terracotta
fill 439 222 194 442 224 204 minecraft:brown_terracotta
fill 439 222 206 442 224 216 minecraft:brown_terracotta
fill 439 222 218 442 224 222 minecraft:brown_terracotta
fill 443 222 182 443 224 192 minecraft:cut_sandstone
fill 443 222 194 443 223 204 minecraft:cut_sandstone
fill 443 222 206 443 224 216 minecraft:cut_sandstone
fill 443 222 218 443 224 222 minecraft:cut_sandstone
fill 444 222 182 447 224 192 minecraft:brown_terracotta
fill 444 222 194 444 223 201 minecraft:brown_terracotta
fill 444 222 203 444 223 204 minecraft:brown_terracotta
fill 444 222 206 447 223 216 minecraft:brown_terracotta
fill 444 222 218 447 224 222 minecraft:brown_terracotta
fill 445 222 194 446 223 199 minecraft:brown_terracotta
fill 447 222 194 447 223 198 minecraft:brown_terracotta
fill 448 222 182 448 224 192 minecraft:cut_sandstone
fill 448 222 194 448 223 199 minecraft:cut_sandstone
fill 448 222 205 464 223 205 minecraft:chiseled_sandstone
fill 448 222 206 448 223 216 minecraft:cut_sandstone
fill 448 222 218 448 224 222 minecraft:cut_sandstone
fill 449 222 182 452 224 192 minecraft:brown_terracotta
fill 449 222 194 452 223 199 minecraft:brown_terracotta
fill 449 222 206 452 224 216 minecraft:brown_terracotta
fill 449 222 218 452 224 222 minecraft:brown_terracotta
fill 450 222 200 452 223 201 minecraft:brown_terracotta
fill 450 222 203 452 223 204 minecraft:brown_terracotta
fill 451 222 202 452 223 202 minecraft:brown_terracotta
fill 453 222 182 453 224 192 minecraft:cut_sandstone
fill 453 222 194 453 224 204 minecraft:cut_sandstone
fill 453 222 206 453 224 216 minecraft:cut_sandstone
fill 453 222 218 453 224 222 minecraft:cut_sandstone
fill 454 222 182 457 224 192 minecraft:brown_terracotta
fill 454 222 194 457 224 204 minecraft:brown_terracotta
fill 454 222 206 457 224 216 minecraft:brown_terracotta
fill 454 222 218 457 224 222 minecraft:brown_terracotta
fill 458 222 182 458 224 192 minecraft:cut_sandstone
fill 458 222 194 458 224 204 minecraft:cut_sandstone
fill 458 222 206 458 224 216 minecraft:cut_sandstone
fill 458 222 218 458 224 222 minecraft:cut_sandstone
fill 459 222 182 462 224 192 minecraft:brown_terracotta
fill 459 222 194 462 224 204 minecraft:brown_terracotta
fill 459 222 206 462 224 216 minecraft:brown_terracotta
fill 459 222 218 462 224 222 minecraft:brown_terracotta
fill 463 222 182 463 224 192 minecraft:cut_sandstone
fill 463 222 194 463 224 204 minecraft:cut_sandstone
fill 463 222 206 463 224 216 minecraft:cut_sandstone
fill 463 222 218 463 224 222 minecraft:cut_sandstone
fill 464 222 182 464 224 192 minecraft:brown_terracotta
fill 464 222 194 464 224 204 minecraft:brown_terracotta
fill 464 222 206 464 224 216 minecraft:brown_terracotta
fill 464 222 218 464 224 222 minecraft:brown_terracotta
fill 424 224 205 443 224 205 minecraft:chiseled_sandstone
fill 443 224 194 443 224 200 minecraft:cut_sandstone
fill 443 224 201 443 224 203 minecraft:lantern
setblock 443 224 204 minecraft:cut_sandstone
fill 444 224 194 445 224 198 minecraft:brown_terracotta
fill 444 224 199 444 224 201 minecraft:lantern
fill 444 224 203 444 224 205 minecraft:lantern
fill 444 224 206 445 224 216 minecraft:brown_terracotta
fill 445 224 199 446 224 199 minecraft:lantern
fill 445 224 205 446 224 205 minecraft:lantern
fill 446 224 194 447 224 197 minecraft:brown_terracotta
fill 446 224 198 448 224 198 minecraft:lantern
fill 446 224 206 448 224 206 minecraft:lantern
fill 446 224 207 447 224 216 minecraft:brown_terracotta
fill 448 224 194 448 224 197 minecraft:cut_sandstone
fill 448 224 199 450 224 199 minecraft:lantern
fill 448 224 205 450 224 205 minecraft:lantern
fill 448 224 207 448 224 216 minecraft:cut_sandstone
fill 449 224 194 452 224 198 minecraft:brown_terracotta
fill 450 224 200 450 224 201 minecraft:lantern
fill 450 224 203 450 224 204 minecraft:lantern
fill 451 224 199 452 224 200 minecraft:brown_terracotta
fill 451 224 201 451 224 203 minecraft:lantern
fill 451 224 204 452 224 204 minecraft:brown_terracotta
fill 451 224 205 464 224 205 minecraft:chiseled_sandstone
fill 452 224 201 452 224 203 minecraft:brown_terracotta
setblock 426 225 184 minecraft:light[level=13]
setblock 426 225 192 minecraft:light[level=13]
setblock 426 225 200 minecraft:light[level=13]
setblock 426 225 208 minecraft:light[level=13]
setblock 426 225 216 minecraft:light[level=13]
setblock 434 225 184 minecraft:light[level=13]
setblock 434 225 192 minecraft:light[level=13]
setblock 434 225 200 minecraft:light[level=13]
setblock 434 225 208 minecraft:light[level=13]
setblock 434 225 216 minecraft:light[level=13]
setblock 442 225 184 minecraft:light[level=13]
setblock 442 225 192 minecraft:light[level=13]
setblock 442 225 200 minecraft:light[level=13]
setblock 442 225 208 minecraft:light[level=13]
setblock 442 225 216 minecraft:light[level=13]
setblock 450 225 184 minecraft:light[level=13]
setblock 450 225 192 minecraft:light[level=13]
setblock 450 225 200 minecraft:light[level=13]
setblock 450 225 208 minecraft:light[level=13]
setblock 450 225 216 minecraft:light[level=13]
setblock 458 225 184 minecraft:light[level=13]
setblock 458 225 192 minecraft:light[level=13]
setblock 458 225 200 minecraft:light[level=13]
setblock 458 225 208 minecraft:light[level=13]
setblock 458 225 216 minecraft:light[level=13]
fill 423 228 186 423 233 186 minecraft:lantern
fill 423 228 194 423 233 194 minecraft:lantern
fill 423 228 202 423 233 202 minecraft:lantern
fill 423 228 210 423 233 210 minecraft:lantern
fill 423 228 218 423 233 218 minecraft:lantern
fill 424 228 188 424 272 189 minecraft:smooth_sandstone
fill 424 228 196 424 272 197 minecraft:smooth_sandstone
fill 424 228 204 424 272 205 minecraft:smooth_sandstone
fill 424 228 212 424 272 213 minecraft:smooth_sandstone
fill 424 228 220 424 272 221 minecraft:smooth_sandstone
fill 425 228 182 426 272 182 minecraft:smooth_sandstone
fill 426 228 223 426 233 223 minecraft:lantern
fill 430 228 181 430 233 181 minecraft:lantern
fill 430 228 222 431 272 222 minecraft:smooth_sandstone
fill 433 228 182 434 272 182 minecraft:smooth_sandstone
fill 434 228 223 434 233 223 minecraft:lantern
fill 438 228 181 438 233 181 minecraft:lantern
fill 438 228 222 439 272 222 minecraft:smooth_sandstone
fill 441 228 182 442 272 182 minecraft:smooth_sandstone
fill 442 228 223 442 233 223 minecraft:lantern
fill 446 228 181 446 233 181 minecraft:lantern
fill 446 228 222 447 272 222 minecraft:smooth_sandstone
fill 449 228 182 450 272 182 minecraft:smooth_sandstone
fill 450 228 223 450 233 223 minecraft:lantern
fill 454 228 181 454 233 181 minecraft:lantern
fill 454 228 222 455 272 222 minecraft:smooth_sandstone
fill 457 228 182 458 272 182 minecraft:smooth_sandstone
fill 458 228 223 458 233 223 minecraft:lantern
fill 462 228 181 462 233 181 minecraft:lantern
fill 462 228 222 463 272 222 minecraft:smooth_sandstone
fill 464 228 183 464 272 184 minecraft:smooth_sandstone
fill 464 228 191 464 272 192 minecraft:smooth_sandstone
fill 464 228 199 464 272 200 minecraft:smooth_sandstone
fill 464 228 207 464 272 208 minecraft:smooth_sandstone
fill 464 228 215 464 272 216 minecraft:smooth_sandstone
fill 465 228 186 465 233 186 minecraft:lantern
fill 465 228 194 465 233 194 minecraft:lantern
fill 465 228 202 465 233 202 minecraft:lantern
fill 465 228 210 465 233 210 minecraft:lantern
fill 465 228 218 465 233 218 minecraft:lantern
fill 448 229 216 451 272 217 minecraft:smooth_sandstone
fill 449 229 215 451 272 215 minecraft:smooth_sandstone
fill 449 229 218 451 272 218 minecraft:smooth_sandstone
fill 427 230 212 429 272 213 minecraft:smooth_sandstone
fill 428 230 214 429 272 214 minecraft:smooth_sandstone
fill 447 230 216 447 231 217 minecraft:brown_terracotta
fill 448 230 215 448 231 215 minecraft:brown_terracotta
fill 448 230 218 448 231 219 minecraft:brown_terracotta
fill 449 230 214 451 231 214 minecraft:brown_terracotta
fill 449 230 219 451 231 219 minecraft:brown_terracotta
fill 452 230 215 452 231 218 minecraft:brown_terracotta
fill 425 231 197 430 231 197 minecraft:brown_terracotta
fill 426 231 195 430 232 196 minecraft:brown_terracotta
fill 426 231 198 430 232 199 minecraft:brown_terracotta
fill 426 231 213 426 232 213 minecraft:brown_terracotta
fill 427 231 214 427 232 214 minecraft:brown_terracotta
fill 428 231 211 429 232 211 minecraft:brown_terracotta
fill 430 231 213 430 232 213 minecraft:brown_terracotta
fill 446 231 216 446 231 217 minecraft:brown_terracotta
fill 447 231 214 447 231 215 minecraft:brown_terracotta
fill 447 231 218 447 231 219 minecraft:brown_terracotta
setblock 448 231 214 minecraft:brown_terracotta
fill 448 231 220 451 231 220 minecraft:brown_terracotta
fill 449 231 213 450 231 213 minecraft:brown_terracotta
setblock 452 231 214 minecraft:brown_terracotta
setblock 452 231 219 minecraft:brown_terracotta
fill 453 231 215 453 231 218 minecraft:brown_terracotta
fill 426 232 197 430 232 197 minecraft:brown_terracotta
setblock 426 232 212 minecraft:brown_terracotta
setblock 426 232 214 minecraft:brown_terracotta
setblock 427 232 211 minecraft:brown_terracotta
fill 427 232 215 429 232 215 minecraft:brown_terracotta
fill 430 232 211 430 232 212 minecraft:brown_terracotta
setblock 430 232 214 minecraft:brown_terracotta
setblock 426 233 184 minecraft:light[level=13]
setblock 426 233 192 minecraft:light[level=13]
setblock 426 233 200 minecraft:light[level=13]
setblock 426 233 208 minecraft:light[level=13]
setblock 426 233 216 minecraft:light[level=13]
fill 427 233 196 429 234 198 minecraft:smooth_sandstone
setblock 434 233 184 minecraft:light[level=13]
setblock 434 233 192 minecraft:light[level=13]
setblock 434 233 200 minecraft:light[level=13]
setblock 434 233 208 minecraft:light[level=13]
setblock 434 233 216 minecraft:light[level=13]
setblock 442 233 184 minecraft:light[level=13]
setblock 442 233 192 minecraft:light[level=13]
setblock 442 233 200 minecraft:light[level=13]
setblock 442 233 208 minecraft:light[level=13]
setblock 442 233 216 minecraft:light[level=13]
setblock 450 233 184 minecraft:light[level=13]
setblock 450 233 192 minecraft:light[level=13]
setblock 450 233 200 minecraft:light[level=13]
setblock 450 233 208 minecraft:light[level=13]
setblock 458 233 184 minecraft:light[level=13]
setblock 458 233 192 minecraft:light[level=13]
setblock 458 233 200 minecraft:light[level=13]
setblock 458 233 208 minecraft:light[level=13]
setblock 458 233 216 minecraft:light[level=13]
fill 423 234 186 423 241 186 minecraft:sandstone
fill 423 234 194 423 241 194 minecraft:sandstone
fill 423 234 202 423 241 202 minecraft:sandstone
fill 423 234 210 423 241 210 minecraft:sandstone
fill 423 234 218 423 241 218 minecraft:sandstone
fill 426 234 223 426 241 223 minecraft:sandstone
fill 430 234 181 430 241 181 minecraft:sandstone
fill 434 234 223 434 241 223 minecraft:sandstone
fill 438 234 181 438 241 181 minecraft:sandstone
fill 442 234 223 442 241 223 minecraft:sandstone
fill 446 234 181 446 241 181 minecraft:sandstone
fill 450 234 223 450 241 223 minecraft:sandstone
fill 454 234 181 454 241 181 minecraft:sandstone
fill 458 234 223 458 241 223 minecraft:sandstone
fill 462 234 181 462 241 181 minecraft:sandstone
fill 465 234 186 465 241 186 minecraft:sandstone
fill 465 234 194 465 241 194 minecraft:sandstone
fill 465 234 202 465 241 202 minecraft:sandstone
fill 465 234 210 465 241 210 minecraft:sandstone
fill 465 234 218 465 241 218 minecraft:sandstone
fill 427 235 197 429 237 197 minecraft:smooth_sandstone
fill 428 235 196 428 237 196 minecraft:smooth_sandstone
fill 428 235 198 428 237 198 minecraft:smooth_sandstone
fill 450 236 200 454 272 200 minecraft:smooth_sandstone
fill 451 236 199 453 272 199 minecraft:smooth_sandstone
fill 451 236 201 453 272 201 minecraft:smooth_sandstone
fill 452 236 202 452 272 202 minecraft:smooth_sandstone
fill 450 237 199 450 238 199 minecraft:brown_terracotta
fill 450 237 201 450 238 202 minecraft:brown_terracotta
fill 451 237 198 454 238 198 minecraft:brown_terracotta
fill 451 237 202 451 238 202 minecraft:brown_terracotta
fill 453 237 202 454 238 202 minecraft:brown_terracotta
fill 454 237 199 454 238 199 minecraft:brown_terracotta
fill 454 237 201 454 238 201 minecraft:brown_terracotta
fill 424 238 182 424 239 187 minecraft:smooth_sandstone
fill 424 238 190 425 238 195 minecraft:smooth_sandstone
fill 424 238 198 425 238 203 minecraft:smooth_sandstone
fill 424 238 206 425 238 211 minecraft:smooth_sandstone
fill 424 238 214 425 238 219 minecraft:smooth_sandstone
fill 424 238 222 429 239 222 minecraft:smooth_sandstone
fill 425 238 183 425 238 189 minecraft:smooth_sandstone
fill 425 238 196 425 238 197 minecraft:smooth_sandstone
fill 425 238 204 425 238 205 minecraft:smooth_sandstone
fill 425 238 212 425 238 213 minecraft:smooth_sandstone
fill 425 238 220 425 238 221 minecraft:smooth_sandstone
fill 426 238 183 463 238 183 minecraft:smooth_sandstone
fill 426 238 221 464 238 221 minecraft:smooth_sandstone
fill 427 238 182 432 239 182 minecraft:smooth_sandstone
fill 427 238 192 430 272 194 minecraft:smooth_sandstone
fill 428 238 191 430 272 191 minecraft:smooth_sandstone
fill 428 238 197 428 242 197 minecraft:smooth_sandstone
fill 429 238 195 429 272 195 minecraft:smooth_sandstone
fill 431 238 193 431 272 193 minecraft:smooth_sandstone
fill 432 238 222 437 239 222 minecraft:smooth_sandstone
fill 435 238 182 440 239 182 minecraft:smooth_sandstone
fill 440 238 222 445 239 222 minecraft:smooth_sandstone
fill 443 238 182 448 239 182 minecraft:smooth_sandstone
fill 448 238 222 453 239 222 minecraft:smooth_sandstone
fill 449 238 198 449 238 201 minecraft:brown_terracotta
setblock 450 238 198 minecraft:brown_terracotta
fill 450 238 203 454 238 203 minecraft:brown_terracotta
fill 451 238 182 456 239 182 minecraft:smooth_sandstone
fill 451 238 197 454 238 197 minecraft:brown_terracotta
fill 455 238 198 455 238 202 minecraft:brown_terracotta
fill 456 238 222 461 239 222 minecraft:smooth_sandstone
fill 459 238 182 464 239 182 minecraft:smooth_sandstone
fill 463 238 184 463 238 220 minecraft:smooth_sandstone
fill 464 238 185 464 239 190 minecraft:smooth_sandstone
fill 464 238 193 464 239 198 minecraft:smooth_sandstone
fill 464 238 201 464 239 206 minecraft:smooth_sandstone
fill 464 238 209 464 239 214 minecraft:smooth_sandstone
fill 464 238 217 464 239 220 minecraft:smooth_sandstone
fill 464 238 222 464 239 222 minecraft:smooth_sandstone
fill 424 239 190 424 239 195 minecraft:smooth_sandstone
fill 424 239 198 424 239 203 minecraft:smooth_sandstone
fill 424 239 206 424 239 211 minecraft:smooth_sandstone
fill 424 239 214 424 239 219 minecraft:smooth_sandstone
fill 426 239 192 426 240 194 minecraft:brown_terracotta
fill 427 239 191 427 240 191 minecraft:brown_terracotta
fill 427 239 195 428 240 195 minecraft:brown_terracotta
fill 428 239 190 430 240 190 minecraft:brown_terracotta
fill 430 239 195 431 240 195 minecraft:brown_terracotta
fill 431 239 191 431 240 192 minecraft:brown_terracotta
fill 431 239 194 431 240 194 minecraft:brown_terracotta
setblock 464 239 221 minecraft:smooth_sandstone
fill 425 240 192 425 240 194 minecraft:brown_terracotta
fill 426 240 190 426 240 191 minecraft:brown_terracotta
setblock 426 240 195 minecraft:brown_terracotta
setblock 427 240 190 minecraft:brown_terracotta
fill 427 240 196 431 240 196 minecraft:brown_terracotta
fill 428 240 189 430 240 189 minecraft:brown_terracotta
setblock 431 240 190 minecraft:brown_terracotta
fill 432 240 191 432 240 195 minecraft:brown_terracotta
setblock 426 241 184 minecraft:light[level=13]
setblock 426 241 192 minecraft:light[level=13]
setblock 426 241 200 minecraft:light[level=13]
setblock 426 241 208 minecraft:light[level=13]
setblock 426 241 216 minecraft:light[level=13]
setblock 434 241 184 minecraft:light[level=13]
setblock 434 241 192 minecraft:light[level=13]
setblock 434 241 200 minecraft:light[level=13]
setblock 434 241 208 minecraft:light[level=13]
setblock 434 241 216 minecraft:light[level=13]
setblock 442 241 184 minecraft:light[level=13]
setblock 442 241 192 minecraft:light[level=13]
setblock 442 241 200 minecraft:light[level=13]
setblock 442 241 208 minecraft:light[level=13]
setblock 442 241 216 minecraft:light[level=13]
setblock 450 241 184 minecraft:light[level=13]
setblock 450 241 192 minecraft:light[level=13]
setblock 450 241 208 minecraft:light[level=13]
setblock 458 241 184 minecraft:light[level=13]
setblock 458 241 192 minecraft:light[level=13]
setblock 458 241 200 minecraft:light[level=13]
setblock 458 241 208 minecraft:light[level=13]
setblock 458 241 216 minecraft:light[level=13]
fill 423 242 186 423 247 186 minecraft:lantern
fill 423 242 194 423 247 194 minecraft:lantern
fill 423 242 202 423 247 202 minecraft:lantern
fill 423 242 210 423 247 210 minecraft:lantern
fill 423 242 218 423 247 218 minecraft:lantern
fill 426 242 223 426 247 223 minecraft:lantern
fill 430 242 181 430 247 181 minecraft:lantern
fill 434 242 223 434 247 223 minecraft:lantern
fill 438 242 181 438 247 181 minecraft:lantern
fill 442 242 223 442 247 223 minecraft:lantern
fill 446 242 181 446 247 181 minecraft:lantern
fill 450 242 223 450 247 223 minecraft:lantern
fill 454 242 181 454 247 181 minecraft:lantern
fill 458 242 223 458 247 223 minecraft:lantern
fill 462 242 181 462 247 181 minecraft:lantern
fill 465 242 186 465 247 186 minecraft:lantern
fill 465 242 194 465 247 194 minecraft:lantern
fill 465 242 202 465 247 202 minecraft:lantern
fill 465 242 210 465 247 210 minecraft:lantern
fill 465 242 218 465 247 218 minecraft:lantern
setblock 428 243 197 minecraft:lantern
fill 423 248 186 423 255 186 minecraft:sandstone
fill 423 248 194 423 255 194 minecraft:sandstone
fill 423 248 202 423 255 202 minecraft:sandstone
fill 423 248 210 423 255 210 minecraft:sandstone
fill 423 248 218 423 255 218 minecraft:sandstone
fill 426 248 223 426 255 223 minecraft:sandstone
fill 430 248 181 430 255 181 minecraft:sandstone
fill 434 248 223 434 255 223 minecraft:sandstone
fill 438 248 181 438 255 181 minecraft:sandstone
fill 442 248 223 442 255 223 minecraft:sandstone
fill 446 248 181 446 255 181 minecraft:sandstone
fill 450 248 223 450 255 223 minecraft:sandstone
fill 454 248 181 454 255 181 minecraft:sandstone
fill 458 248 223 458 255 223 minecraft:sandstone
fill 462 248 181 462 255 181 minecraft:sandstone
fill 465 248 186 465 255 186 minecraft:sandstone
fill 465 248 194 465 255 194 minecraft:sandstone
fill 465 248 202 465 255 202 minecraft:sandstone
fill 465 248 210 465 255 210 minecraft:sandstone
fill 465 248 218 465 255 218 minecraft:sandstone
setblock 426 249 184 minecraft:light[level=13]
setblock 426 249 192 minecraft:light[level=13]
setblock 426 249 200 minecraft:light[level=13]
setblock 426 249 208 minecraft:light[level=13]
setblock 426 249 216 minecraft:light[level=13]
setblock 434 249 184 minecraft:light[level=13]
setblock 434 249 192 minecraft:light[level=13]
setblock 434 249 200 minecraft:light[level=13]
setblock 434 249 208 minecraft:light[level=13]
setblock 434 249 216 minecraft:light[level=13]
setblock 442 249 184 minecraft:light[level=13]
setblock 442 249 192 minecraft:light[level=13]
setblock 442 249 200 minecraft:light[level=13]
setblock 442 249 208 minecraft:light[level=13]
setblock 442 249 216 minecraft:light[level=13]
setblock 450 249 184 minecraft:light[level=13]
setblock 450 249 192 minecraft:light[level=13]
setblock 450 249 208 minecraft:light[level=13]
setblock 458 249 184 minecraft:light[level=13]
setblock 458 249 192 minecraft:light[level=13]
setblock 458 249 200 minecraft:light[level=13]
setblock 458 249 208 minecraft:light[level=13]
setblock 458 249 216 minecraft:light[level=13]
fill 424 252 182 424 253 187 minecraft:smooth_sandstone
fill 424 252 190 425 252 195 minecraft:smooth_sandstone
fill 424 252 198 425 252 203 minecraft:smooth_sandstone
fill 424 252 206 425 252 211 minecraft:smooth_sandstone
fill 424 252 214 425 252 219 minecraft:smooth_sandstone
fill 424 252 222 429 253 222 minecraft:smooth_sandstone
fill 425 252 183 425 252 189 minecraft:smooth_sandstone
fill 425 252 196 425 252 197 minecraft:smooth_sandstone
fill 425 252 204 425 252 205 minecraft:smooth_sandstone
fill 425 252 212 425 252 213 minecraft:smooth_sandstone
fill 425 252 220 425 252 221 minecraft:smooth_sandstone
fill 426 252 183 463 252 183 minecraft:smooth_sandstone
fill 426 252 221 464 252 221 minecraft:smooth_sandstone
fill 427 252 182 432 253 182 minecraft:smooth_sandstone
fill 432 252 222 437 253 222 minecraft:smooth_sandstone
fill 435 252 182 440 253 182 minecraft:smooth_sandstone
fill 440 252 222 445 253 222 minecraft:smooth_sandstone
fill 443 252 182 448 253 182 minecraft:smooth_sandstone
fill 448 252 222 453 253 222 minecraft:smooth_sandstone
fill 451 252 182 456 253 182 minecraft:smooth_sandstone
fill 456 252 222 461 253 222 minecraft:smooth_sandstone
fill 459 252 182 464 253 182 minecraft:smooth_sandstone
fill 463 252 184 463 252 220 minecraft:smooth_sandstone
fill 464 252 185 464 253 190 minecraft:smooth_sandstone
fill 464 252 193 464 253 198 minecraft:smooth_sandstone
fill 464 252 201 464 253 206 minecraft:smooth_sandstone
fill 464 252 209 464 253 214 minecraft:smooth_sandstone
fill 464 252 217 464 253 220 minecraft:smooth_sandstone
fill 464 252 222 464 253 222 minecraft:smooth_sandstone
fill 424 253 190 424 253 195 minecraft:smooth_sandstone
fill 424 253 198 424 253 203 minecraft:smooth_sandstone
fill 424 253 206 424 253 211 minecraft:smooth_sandstone
fill 424 253 214 424 253 219 minecraft:smooth_sandstone
setblock 464 253 221 minecraft:smooth_sandstone
fill 423 256 186 423 261 186 minecraft:lantern
fill 423 256 194 423 261 194 minecraft:lantern
fill 423 256 202 423 261 202 minecraft:lantern
fill 423 256 210 423 261 210 minecraft:lantern
fill 423 256 218 423 261 218 minecraft:lantern
fill 426 256 223 426 261 223 minecraft:lantern
fill 430 256 181 430 261 181 minecraft:lantern
fill 434 256 223 434 261 223 minecraft:lantern
fill 438 256 181 438 261 181 minecraft:lantern
fill 442 256 223 442 261 223 minecraft:lantern
fill 446 256 181 446 261 181 minecraft:lantern
fill 450 256 223 450 261 223 minecraft:lantern
fill 454 256 181 454 261 181 minecraft:lantern
fill 458 256 223 458 261 223 minecraft:lantern
fill 462 256 181 462 261 181 minecraft:lantern
fill 465 256 186 465 261 186 minecraft:lantern
fill 465 256 194 465 261 194 minecraft:lantern
fill 465 256 202 465 261 202 minecraft:lantern
fill 465 256 210 465 261 210 minecraft:lantern
fill 465 256 218 465 261 218 minecraft:lantern
setblock 426 257 184 minecraft:light[level=13]
setblock 426 257 192 minecraft:light[level=13]
setblock 426 257 200 minecraft:light[level=13]
setblock 426 257 208 minecraft:light[level=13]
setblock 426 257 216 minecraft:light[level=13]
setblock 434 257 184 minecraft:light[level=13]
setblock 434 257 192 minecraft:light[level=13]
setblock 434 257 200 minecraft:light[level=13]
setblock 434 257 208 minecraft:light[level=13]
setblock 434 257 216 minecraft:light[level=13]
setblock 442 257 184 minecraft:light[level=13]
setblock 442 257 192 minecraft:light[level=13]
setblock 442 257 200 minecraft:light[level=13]
setblock 442 257 208 minecraft:light[level=13]
setblock 442 257 216 minecraft:light[level=13]
setblock 450 257 184 minecraft:light[level=13]
setblock 450 257 192 minecraft:light[level=13]
setblock 450 257 208 minecraft:light[level=13]
setblock 458 257 184 minecraft:light[level=13]
setblock 458 257 192 minecraft:light[level=13]
setblock 458 257 200 minecraft:light[level=13]
setblock 458 257 208 minecraft:light[level=13]
setblock 458 257 216 minecraft:light[level=13]
fill 423 262 186 423 269 186 minecraft:sandstone
fill 423 262 194 423 269 194 minecraft:sandstone
fill 423 262 202 423 269 202 minecraft:sandstone
fill 423 262 210 423 269 210 minecraft:sandstone
fill 423 262 218 423 269 218 minecraft:sandstone
fill 426 262 223 426 269 223 minecraft:sandstone
fill 430 262 181 430 269 181 minecraft:sandstone
fill 434 262 223 434 269 223 minecraft:sandstone
fill 438 262 181 438 269 181 minecraft:sandstone
fill 442 262 223 442 269 223 minecraft:sandstone
fill 446 262 181 446 269 181 minecraft:sandstone
fill 450 262 223 450 269 223 minecraft:sandstone
fill 454 262 181 454 269 181 minecraft:sandstone
fill 458 262 223 458 269 223 minecraft:sandstone
fill 462 262 181 462 269 181 minecraft:sandstone
fill 465 262 186 465 269 186 minecraft:sandstone
fill 465 262 194 465 269 194 minecraft:sandstone
fill 465 262 202 465 269 202 minecraft:sandstone
fill 465 262 210 465 269 210 minecraft:sandstone
fill 465 262 218 465 269 218 minecraft:sandstone
setblock 426 265 184 minecraft:light[level=13]
setblock 426 265 192 minecraft:light[level=13]
setblock 426 265 200 minecraft:light[level=13]
setblock 426 265 208 minecraft:light[level=13]
setblock 426 265 216 minecraft:light[level=13]
setblock 434 265 184 minecraft:light[level=13]
setblock 434 265 192 minecraft:light[level=13]
setblock 434 265 200 minecraft:light[level=13]
setblock 434 265 208 minecraft:light[level=13]
setblock 434 265 216 minecraft:light[level=13]
setblock 442 265 184 minecraft:light[level=13]
setblock 442 265 192 minecraft:light[level=13]
setblock 442 265 200 minecraft:light[level=13]
setblock 442 265 208 minecraft:light[level=13]
setblock 442 265 216 minecraft:light[level=13]
fill 444 265 184 448 266 188 minecraft:brown_terracotta
fill 446 265 182 446 265 183 minecraft:brown_terracotta
setblock 450 265 184 minecraft:light[level=13]
setblock 450 265 192 minecraft:light[level=13]
setblock 450 265 208 minecraft:light[level=13]
setblock 458 265 184 minecraft:light[level=13]
setblock 458 265 192 minecraft:light[level=13]
setblock 458 265 200 minecraft:light[level=13]
setblock 458 265 208 minecraft:light[level=13]
setblock 458 265 216 minecraft:light[level=13]
fill 424 266 182 424 267 187 minecraft:smooth_sandstone
fill 424 266 190 425 266 195 minecraft:smooth_sandstone
fill 424 266 198 425 266 203 minecraft:smooth_sandstone
fill 424 266 206 425 266 211 minecraft:smooth_sandstone
fill 424 266 214 425 266 219 minecraft:smooth_sandstone
fill 424 266 222 429 267 222 minecraft:smooth_sandstone
fill 425 266 183 425 266 189 minecraft:smooth_sandstone
fill 425 266 196 425 266 197 minecraft:smooth_sandstone
fill 425 266 204 425 266 205 minecraft:smooth_sandstone
fill 425 266 212 425 266 213 minecraft:smooth_sandstone
fill 425 266 220 425 266 221 minecraft:smooth_sandstone
fill 426 266 183 463 266 183 minecraft:smooth_sandstone
fill 426 266 221 464 266 221 minecraft:smooth_sandstone
fill 427 266 182 432 267 182 minecraft:smooth_sandstone
fill 432 266 222 437 267 222 minecraft:smooth_sandstone
fill 435 266 182 440 267 182 minecraft:smooth_sandstone
fill 440 266 222 445 267 222 minecraft:smooth_sandstone
fill 443 266 182 448 267 182 minecraft:smooth_sandstone
fill 448 266 222 453 267 222 minecraft:smooth_sandstone
fill 451 266 182 456 267 182 minecraft:smooth_sandstone
fill 456 266 222 461 267 222 minecraft:smooth_sandstone
fill 459 266 182 464 267 182 minecraft:smooth_sandstone
fill 463 266 184 463 266 220 minecraft:smooth_sandstone
fill 464 266 185 464 267 190 minecraft:smooth_sandstone
fill 464 266 193 464 267 198 minecraft:smooth_sandstone
fill 464 266 201 464 267 206 minecraft:smooth_sandstone
fill 464 266 209 464 267 214 minecraft:smooth_sandstone
fill 464 266 217 464 267 220 minecraft:smooth_sandstone
fill 464 266 222 464 267 222 minecraft:smooth_sandstone
fill 424 267 190 424 267 195 minecraft:smooth_sandstone
fill 424 267 198 424 267 203 minecraft:smooth_sandstone
fill 424 267 206 424 267 211 minecraft:smooth_sandstone
fill 424 267 214 424 267 219 minecraft:smooth_sandstone
fill 445 267 185 447 268 187 minecraft:smooth_sandstone
setblock 464 267 221 minecraft:smooth_sandstone
fill 425 269 191 426 269 194 minecraft:terracotta
fill 426 269 190 431 269 190 minecraft:terracotta
fill 426 269 195 428 270 195 minecraft:terracotta
fill 426 269 211 426 269 214 minecraft:terracotta
fill 427 269 189 430 269 189 minecraft:terracotta
fill 427 269 191 427 271 191 minecraft:terracotta
fill 427 269 196 431 269 196 minecraft:terracotta
fill 427 269 211 430 269 211 minecraft:terracotta
fill 427 269 214 427 270 215 minecraft:terracotta
fill 428 269 215 429 270 215 minecraft:terracotta
setblock 429 269 197 minecraft:terracotta
fill 430 269 195 432 269 195 minecraft:terracotta
fill 430 269 212 430 270 214 minecraft:terracotta
fill 431 269 191 432 269 192 minecraft:terracotta
fill 431 269 194 432 270 194 minecraft:terracotta
fill 432 269 193 433 269 193 minecraft:terracotta
fill 445 269 186 447 271 186 minecraft:smooth_sandstone
fill 446 269 185 446 271 185 minecraft:smooth_sandstone
fill 446 269 187 446 271 187 minecraft:smooth_sandstone
fill 446 269 215 447 269 218 minecraft:terracotta
fill 447 269 214 452 269 214 minecraft:terracotta
fill 447 269 219 452 269 219 minecraft:terracotta
fill 448 269 213 451 269 213 minecraft:terracotta
fill 448 269 215 448 271 215 minecraft:terracotta
fill 448 269 218 448 271 218 minecraft:terracotta
fill 448 269 220 451 269 220 minecraft:terracotta
fill 449 269 198 449 269 202 minecraft:terracotta
fill 450 269 197 450 269 199 minecraft:terracotta
fill 450 269 201 450 269 203 minecraft:terracotta
fill 451 269 197 454 269 198 minecraft:terracotta
fill 451 269 202 451 270 203 minecraft:terracotta
fill 452 269 203 452 269 204 minecraft:terracotta
fill 452 269 215 453 269 218 minecraft:terracotta
fill 453 269 202 454 269 203 minecraft:terracotta
fill 454 269 199 455 270 199 minecraft:terracotta
fill 454 269 201 455 270 201 minecraft:terracotta
setblock 455 269 198 minecraft:terracotta
fill 455 269 200 455 270 200 minecraft:terracotta
setblock 455 269 202 minecraft:terracotta
fill 423 270 186 423 272 186 minecraft:lantern
fill 423 270 194 423 272 194 minecraft:lantern
fill 423 270 202 423 272 202 minecraft:lantern
fill 423 270 210 423 272 210 minecraft:lantern
fill 423 270 218 423 272 218 minecraft:lantern
fill 426 270 191 426 270 194 minecraft:terracotta
fill 426 270 212 426 270 214 minecraft:terracotta
fill 426 270 223 426 272 223 minecraft:lantern
fill 427 270 190 430 270 190 minecraft:terracotta
fill 427 270 211 429 270 211 minecraft:terracotta
fill 428 270 196 430 270 196 minecraft:terracotta
fill 430 270 181 430 272 181 minecraft:lantern
fill 430 270 195 431 270 195 minecraft:terracotta
fill 431 270 191 431 271 192 minecraft:terracotta
fill 432 270 192 432 270 193 minecraft:terracotta
fill 434 270 223 434 272 223 minecraft:lantern
fill 438 270 181 438 272 181 minecraft:lantern
fill 442 270 223 442 272 223 minecraft:lantern
fill 446 270 181 446 272 181 minecraft:lantern
fill 447 270 215 447 270 218 minecraft:terracotta
fill 448 270 214 451 270 214 minecraft:terracotta
fill 448 270 219 451 270 219 minecraft:terracotta
fill 449 270 199 449 270 201 minecraft:terracotta
fill 450 270 198 450 270 199 minecraft:terracotta
fill 450 270 201 450 270 202 minecraft:terracotta
fill 450 270 223 450 272 223 minecraft:lantern
fill 451 270 197 453 270 198 minecraft:terracotta
fill 452 270 203 453 270 203 minecraft:terracotta
fill 452 270 215 452 270 218 minecraft:terracotta
fill 453 270 202 454 270 202 minecraft:terracotta
fill 454 270 181 454 272 181 minecraft:lantern
setblock 454 270 198 minecraft:terracotta
fill 458 270 223 458 272 223 minecraft:lantern
fill 462 270 181 462 272 181 minecraft:lantern
fill 465 270 186 465 272 186 minecraft:lantern
fill 465 270 194 465 272 194 minecraft:lantern
fill 465 270 202 465 272 202 minecraft:lantern
fill 465 270 210 465 272 210 minecraft:lantern
fill 465 270 218 465 272 218 minecraft:lantern
setblock 426 271 193 minecraft:terracotta
fill 427 271 195 428 271 195 minecraft:terracotta
setblock 427 271 214 minecraft:terracotta
setblock 428 271 211 minecraft:terracotta
setblock 429 271 190 minecraft:terracotta
setblock 430 271 195 minecraft:terracotta
setblock 430 271 213 minecraft:terracotta
setblock 431 271 194 minecraft:terracotta
fill 447 271 216 447 271 217 minecraft:terracotta
fill 449 271 214 450 271 214 minecraft:terracotta
fill 449 271 219 450 271 219 minecraft:terracotta
setblock 450 271 199 minecraft:terracotta
setblock 450 271 201 minecraft:terracotta
fill 451 271 198 453 271 198 minecraft:terracotta
setblock 451 271 202 minecraft:terracotta
fill 452 271 216 452 271 217 minecraft:terracotta
setblock 453 271 202 minecraft:terracotta
setblock 454 271 199 minecraft:terracotta
setblock 454 271 201 minecraft:terracotta
setblock 446 272 186 minecraft:smooth_sandstone
fill 423 273 186 423 283 186 minecraft:sandstone
fill 423 273 194 423 283 194 minecraft:sandstone
fill 423 273 202 423 283 202 minecraft:sandstone
fill 423 273 210 423 283 210 minecraft:sandstone
fill 423 273 218 423 283 218 minecraft:sandstone
setblock 426 273 184 minecraft:light[level=13]
setblock 426 273 192 minecraft:light[level=13]
setblock 426 273 200 minecraft:light[level=13]
setblock 426 273 208 minecraft:light[level=13]
setblock 426 273 216 minecraft:light[level=13]
fill 426 273 223 426 283 223 minecraft:sandstone
fill 430 273 181 430 283 181 minecraft:sandstone
setblock 434 273 184 minecraft:light[level=13]
setblock 434 273 192 minecraft:light[level=13]
setblock 434 273 200 minecraft:light[level=13]
setblock 434 273 208 minecraft:light[level=13]
setblock 434 273 216 minecraft:light[level=13]
fill 434 273 223 434 283 223 minecraft:sandstone
fill 438 273 181 438 283 181 minecraft:sandstone
setblock 442 273 184 minecraft:light[level=13]
setblock 442 273 192 minecraft:light[level=13]
setblock 442 273 200 minecraft:light[level=13]
setblock 442 273 208 minecraft:light[level=13]
setblock 442 273 216 minecraft:light[level=13]
fill 442 273 223 442 283 223 minecraft:sandstone
fill 446 273 181 446 283 181 minecraft:sandstone
setblock 450 273 184 minecraft:light[level=13]
setblock 450 273 192 minecraft:light[level=13]
setblock 450 273 200 minecraft:light[level=13]
setblock 450 273 208 minecraft:light[level=13]
setblock 450 273 216 minecraft:light[level=13]
fill 450 273 223 450 283 223 minecraft:sandstone
fill 454 273 181 454 283 181 minecraft:sandstone
setblock 458 273 184 minecraft:light[level=13]
setblock 458 273 192 minecraft:light[level=13]
setblock 458 273 200 minecraft:light[level=13]
setblock 458 273 208 minecraft:light[level=13]
setblock 458 273 216 minecraft:light[level=13]
fill 458 273 223 458 283 223 minecraft:sandstone
fill 462 273 181 462 283 181 minecraft:sandstone
fill 465 273 186 465 283 186 minecraft:sandstone
fill 465 273 194 465 283 194 minecraft:sandstone
fill 465 273 202 465 283 202 minecraft:sandstone
fill 465 273 210 465 283 210 minecraft:sandstone
fill 465 273 218 465 283 218 minecraft:sandstone
fill 431 278 191 432 278 219 minecraft:chiseled_sandstone
fill 433 278 191 459 278 192 minecraft:chiseled_sandstone
fill 433 278 193 441 278 217 minecraft:brown_terracotta
fill 433 278 218 459 278 219 minecraft:chiseled_sandstone
fill 442 278 193 442 278 204 minecraft:brown_terracotta
fill 442 278 206 442 278 217 minecraft:brown_terracotta
fill 443 278 193 444 278 202 minecraft:brown_terracotta
fill 443 278 208 444 278 217 minecraft:brown_terracotta
fill 445 278 193 457 278 201 minecraft:brown_terracotta
fill 445 278 209 457 278 217 minecraft:brown_terracotta
fill 446 278 202 457 278 202 minecraft:brown_terracotta
fill 446 278 208 457 278 208 minecraft:brown_terracotta
fill 448 278 203 457 278 204 minecraft:brown_terracotta
fill 448 278 206 457 278 207 minecraft:brown_terracotta
fill 449 278 205 457 278 205 minecraft:brown_terracotta
fill 458 278 193 459 278 217 minecraft:chiseled_sandstone
fill 424 279 182 430 279 222 minecraft:smooth_sandstone
fill 431 279 182 464 279 190 minecraft:smooth_sandstone
fill 431 279 191 431 279 192 minecraft:chiseled_sandstone
setblock 431 279 193 minecraft:glowstone
fill 431 279 194 431 279 196 minecraft:chiseled_sandstone
setblock 431 279 197 minecraft:glowstone
fill 431 279 198 431 279 200 minecraft:chiseled_sandstone
setblock 431 279 201 minecraft:glowstone
fill 431 279 202 431 279 204 minecraft:chiseled_sandstone
setblock 431 279 205 minecraft:glowstone
fill 431 279 206 431 279 208 minecraft:chiseled_sandstone
setblock 431 279 209 minecraft:glowstone
fill 431 279 210 431 279 212 minecraft:chiseled_sandstone
setblock 431 279 213 minecraft:glowstone
fill 431 279 214 431 279 216 minecraft:chiseled_sandstone
setblock 431 279 217 minecraft:glowstone
fill 431 279 218 432 279 219 minecraft:chiseled_sandstone
fill 431 279 220 464 279 222 minecraft:smooth_sandstone
fill 432 279 191 432 283 191 minecraft:chiseled_sandstone
setblock 432 279 192 minecraft:glowstone
fill 432 279 193 432 279 195 minecraft:chiseled_sandstone
setblock 432 279 196 minecraft:glowstone
fill 432 279 197 432 279 199 minecraft:chiseled_sandstone
setblock 432 279 200 minecraft:glowstone
fill 432 279 201 432 279 203 minecraft:chiseled_sandstone
setblock 432 279 204 minecraft:glowstone
fill 432 279 205 432 279 207 minecraft:chiseled_sandstone
setblock 432 279 208 minecraft:glowstone
fill 432 279 209 432 279 211 minecraft:chiseled_sandstone
setblock 432 279 212 minecraft:glowstone
fill 432 279 213 432 279 215 minecraft:chiseled_sandstone
setblock 432 279 216 minecraft:glowstone
fill 432 279 217 432 283 217 minecraft:chiseled_sandstone
setblock 433 279 191 minecraft:glowstone
fill 433 279 192 435 279 192 minecraft:chiseled_sandstone
fill 433 279 193 440 279 217 minecraft:brown_terracotta
fill 433 279 218 433 283 218 minecraft:chiseled_sandstone
setblock 433 279 219 minecraft:glowstone
fill 434 279 191 436 279 191 minecraft:chiseled_sandstone
setblock 434 279 218 minecraft:glowstone
fill 434 279 219 436 279 219 minecraft:chiseled_sandstone
fill 435 279 218 437 279 218 minecraft:chiseled_sandstone
setblock 436 279 192 minecraft:glowstone
setblock 437 279 191 minecraft:glowstone
fill 437 279 192 439 279 192 minecraft:chiseled_sandstone
setblock 437 279 219 minecraft:glowstone
fill 438 279 191 440 279 191 minecraft:chiseled_sandstone
setblock 438 279 218 minecraft:glowstone
fill 438 279 219 440 279 219 minecraft:chiseled_sandstone
fill 439 279 218 441 279 218 minecraft:chiseled_sandstone
setblock 440 279 192 minecraft:glowstone
setblock 441 279 191 minecraft:glowstone
fill 441 279 192 443 279 192 minecraft:chiseled_sandstone
fill 441 279 193 441 279 203 minecraft:brown_terracotta
fill 441 279 204 441 279 206 minecraft:lantern
fill 441 279 207 441 279 217 minecraft:brown_terracotta
setblock 441 279 219 minecraft:glowstone
fill 442 279 191 444 279 191 minecraft:chiseled_sandstone
fill 442 279 193 443 279 201 minecraft:brown_terracotta
fill 442 279 202 442 279 204 minecraft:lantern
fill 442 279 206 442 279 208 minecraft:lantern
fill 442 279 209 443 279 217 minecraft:brown_terracotta
setblock 442 279 218 minecraft:glowstone
fill 442 279 219 444 279 219 minecraft:chiseled_sandstone
fill 443 279 202 444 279 202 minecraft:lantern
fill 443 279 208 444 279 208 minecraft:lantern
fill 443 279 218 445 279 218 minecraft:chiseled_sandstone
setblock 444 279 192 minecraft:glowstone
fill 444 279 193 457 279 200 minecraft:brown_terracotta
fill 444 279 201 446 279 201 minecraft:lantern
fill 444 279 209 446 279 209 minecraft:lantern
fill 444 279 210 457 279 217 minecraft:brown_terracotta
setblock 445 279 191 minecraft:glowstone
fill 445 279 192 447 279 192 minecraft:chiseled_sandstone
setblock 445 279 219 minecraft:glowstone
fill 446 279 191 448 279 191 minecraft:chiseled_sandstone
fill 446 279 202 448 279 202 minecraft:lantern
fill 446 279 208 448 279 208 minecraft:lantern
setblock 446 279 218 minecraft:glowstone
fill 446 279 219 448 279 219 minecraft:chiseled_sandstone
fill 447 279 201 457 279 201 minecraft:brown_terracotta
fill 447 279 209 457 279 209 minecraft:brown_terracotta
fill 447 279 218 449 279 218 minecraft:chiseled_sandstone
setblock 448 279 192 minecraft:glowstone
fill 448 279 203 448 279 204 minecraft:lantern
fill 448 279 206 448 279 207 minecraft:lantern
setblock 449 279 191 minecraft:glowstone
fill 449 279 192 451 279 192 minecraft:chiseled_sandstone
fill 449 279 202 457 279 203 minecraft:brown_terracotta
fill 449 279 204 449 279 206 minecraft:lantern
fill 449 279 207 457 279 208 minecraft:brown_terracotta
setblock 449 279 219 minecraft:glowstone
fill 450 279 191 452 279 191 minecraft:chiseled_sandstone
fill 450 279 204 457 279 206 minecraft:brown_terracotta
setblock 450 279 218 minecraft:glowstone
fill 450 279 219 452 279 219 minecraft:chiseled_sandstone
fill 451 279 218 453 279 218 minecraft:chiseled_sandstone
setblock 452 279 192 minecraft:glowstone
setblock 453 279 191 minecraft:glowstone
fill 453 279 192 455 279 192 minecraft:chiseled_sandstone
setblock 453 279 219 minecraft:glowstone
fill 454 279 191 456 279 191 minecraft:chiseled_sandstone
setblock 454 279 218 minecraft:glowstone
fill 454 279 219 456 279 219 minecraft:chiseled_sandstone
fill 455 279 218 457 279 218 minecraft:chiseled_sandstone
setblock 456 279 192 minecraft:glowstone
setblock 457 279 191 minecraft:glowstone
fill 457 279 192 459 283 192 minecraft:chiseled_sandstone
setblock 457 279 219 minecraft:glowstone
fill 458 279 191 459 279 191 minecraft:chiseled_sandstone
fill 458 279 193 458 283 193 minecraft:chiseled_sandstone
setblock 458 279 194 minecraft:glowstone
fill 458 279 195 458 279 197 minecraft:chiseled_sandstone
setblock 458 279 198 minecraft:glowstone
fill 458 279 199 458 279 201 minecraft:chiseled_sandstone
setblock 458 279 202 minecraft:glowstone
fill 458 279 203 458 279 205 minecraft:chiseled_sandstone
setblock 458 279 206 minecraft:glowstone
fill 458 279 207 458 279 209 minecraft:chiseled_sandstone
setblock 458 279 210 minecraft:glowstone
fill 458 279 211 458 279 213 minecraft:chiseled_sandstone
setblock 458 279 214 minecraft:glowstone
fill 458 279 215 458 279 217 minecraft:chiseled_sandstone
setblock 458 279 218 minecraft:glowstone
fill 458 279 219 459 279 219 minecraft:chiseled_sandstone
setblock 459 279 193 minecraft:glowstone
fill 459 279 194 459 279 196 minecraft:chiseled_sandstone
setblock 459 279 197 minecraft:glowstone
fill 459 279 198 459 279 200 minecraft:chiseled_sandstone
setblock 459 279 201 minecraft:glowstone
fill 459 279 202 459 279 204 minecraft:chiseled_sandstone
setblock 459 279 205 minecraft:glowstone
fill 459 279 206 459 279 208 minecraft:chiseled_sandstone
setblock 459 279 209 minecraft:glowstone
fill 459 279 210 459 279 212 minecraft:chiseled_sandstone
setblock 459 279 213 minecraft:glowstone
fill 459 279 214 459 279 216 minecraft:chiseled_sandstone
setblock 459 279 217 minecraft:glowstone
fill 459 279 218 459 283 218 minecraft:chiseled_sandstone
fill 460 279 191 464 279 219 minecraft:smooth_sandstone
fill 431 280 192 433 283 192 minecraft:chiseled_sandstone
fill 431 280 218 432 283 218 minecraft:chiseled_sandstone
fill 432 280 193 432 283 193 minecraft:chiseled_sandstone
fill 432 280 219 432 283 219 minecraft:chiseled_sandstone
fill 457 280 218 458 283 218 minecraft:chiseled_sandstone
fill 458 280 191 458 283 191 minecraft:chiseled_sandstone
fill 458 280 217 458 283 217 minecraft:chiseled_sandstone
fill 458 280 219 458 283 219 minecraft:chiseled_sandstone
setblock 426 281 184 minecraft:light[level=13]
setblock 426 281 192 minecraft:light[level=13]
setblock 426 281 200 minecraft:light[level=13]
setblock 426 281 208 minecraft:light[level=13]
setblock 426 281 216 minecraft:light[level=13]
setblock 434 281 184 minecraft:light[level=13]
setblock 434 281 192 minecraft:light[level=13]
setblock 434 281 200 minecraft:light[level=13]
setblock 434 281 208 minecraft:light[level=13]
setblock 434 281 216 minecraft:light[level=13]
setblock 442 281 184 minecraft:light[level=13]
setblock 442 281 192 minecraft:light[level=13]
setblock 442 281 200 minecraft:light[level=13]
setblock 442 281 208 minecraft:light[level=13]
setblock 442 281 216 minecraft:light[level=13]
setblock 450 281 184 minecraft:light[level=13]
setblock 450 281 192 minecraft:light[level=13]
setblock 450 281 200 minecraft:light[level=13]
setblock 450 281 208 minecraft:light[level=13]
setblock 450 281 216 minecraft:light[level=13]
setblock 458 281 184 minecraft:light[level=13]
setblock 458 281 200 minecraft:light[level=13]
setblock 458 281 208 minecraft:light[level=13]
setblock 458 281 216 minecraft:light[level=13]
fill 424 283 188 424 300 189 minecraft:smooth_sandstone
fill 424 283 196 424 300 197 minecraft:smooth_sandstone
fill 424 283 204 424 300 205 minecraft:smooth_sandstone
fill 424 283 212 424 300 213 minecraft:smooth_sandstone
fill 424 283 220 424 300 221 minecraft:smooth_sandstone
fill 425 283 182 426 300 182 minecraft:smooth_sandstone
fill 425 283 190 428 300 192 minecraft:smooth_sandstone
fill 426 283 189 427 300 189 minecraft:smooth_sandstone
fill 426 283 193 426 300 193 minecraft:smooth_sandstone
fill 430 283 222 431 300 222 minecraft:smooth_sandstone
fill 433 283 182 434 300 182 minecraft:smooth_sandstone
fill 438 283 222 439 300 222 minecraft:smooth_sandstone
fill 441 283 182 442 300 182 minecraft:smooth_sandstone
fill 446 283 222 447 300 222 minecraft:smooth_sandstone
fill 449 283 182 450 300 182 minecraft:smooth_sandstone
fill 454 283 222 455 300 222 minecraft:smooth_sandstone
fill 457 283 182 458 300 182 minecraft:smooth_sandstone
fill 462 283 222 463 300 222 minecraft:smooth_sandstone
fill 464 283 183 464 300 184 minecraft:smooth_sandstone
fill 464 283 191 464 300 192 minecraft:smooth_sandstone
fill 464 283 199 464 300 200 minecraft:smooth_sandstone
fill 464 283 207 464 300 208 minecraft:smooth_sandstone
fill 464 283 215 464 300 216 minecraft:smooth_sandstone
fill 423 284 186 423 289 186 minecraft:lantern
fill 423 284 194 423 289 194 minecraft:lantern
fill 423 284 202 423 289 202 minecraft:lantern
fill 423 284 210 423 289 210 minecraft:lantern
fill 423 284 218 423 289 218 minecraft:lantern
fill 424 284 190 424 285 192 minecraft:brown_terracotta
fill 425 284 189 425 285 189 minecraft:brown_terracotta
fill 425 284 193 425 285 193 minecraft:brown_terracotta
fill 426 284 188 426 285 188 minecraft:brown_terracotta
fill 426 284 223 426 289 223 minecraft:lantern
fill 427 284 193 428 285 193 minecraft:brown_terracotta
fill 428 284 189 428 285 189 minecraft:brown_terracotta
fill 429 284 190 429 285 192 minecraft:brown_terracotta
fill 430 284 181 430 289 181 minecraft:lantern
fill 434 284 223 434 289 223 minecraft:lantern
fill 438 284 181 438 289 181 minecraft:lantern
fill 442 284 223 442 289 223 minecraft:lantern
fill 446 284 181 446 289 181 minecraft:lantern
fill 450 284 223 450 289 223 minecraft:lantern
fill 454 284 181 454 289 181 minecraft:lantern
fill 458 284 223 458 289 223 minecraft:lantern
fill 462 284 181 462 289 181 minecraft:lantern
fill 465 284 186 465 289 186 minecraft:lantern
fill 465 284 194 465 289 194 minecraft:lantern
fill 465 284 202 465 289 202 minecraft:lantern
fill 465 284 210 465 289 210 minecraft:lantern
fill 465 284 218 465 289 218 minecraft:lantern
setblock 424 285 193 minecraft:brown_terracotta
setblock 425 285 188 minecraft:brown_terracotta
fill 425 285 194 428 285 194 minecraft:brown_terracotta
fill 427 285 188 428 285 188 minecraft:brown_terracotta
setblock 429 285 189 minecraft:brown_terracotta
setblock 429 285 193 minecraft:brown_terracotta
fill 430 285 190 430 285 192 minecraft:brown_terracotta
setblock 426 289 184 minecraft:light[level=13]
setblock 426 289 200 minecraft:light[level=13]
setblock 426 289 208 minecraft:light[level=13]
setblock 426 289 216 minecraft:light[level=13]
setblock 434 289 184 minecraft:light[level=13]
setblock 434 289 192 minecraft:light[level=13]
setblock 434 289 200 minecraft:light[level=13]
setblock 434 289 208 minecraft:light[level=13]
setblock 434 289 216 minecraft:light[level=13]
setblock 442 289 184 minecraft:light[level=13]
setblock 442 289 192 minecraft:light[level=13]
setblock 442 289 200 minecraft:light[level=13]
setblock 442 289 208 minecraft:light[level=13]
setblock 442 289 216 minecraft:light[level=13]
setblock 450 289 184 minecraft:light[level=13]
setblock 450 289 192 minecraft:light[level=13]
setblock 450 289 200 minecraft:light[level=13]
setblock 450 289 208 minecraft:light[level=13]
setblock 450 289 216 minecraft:light[level=13]
setblock 458 289 184 minecraft:light[level=13]
setblock 458 289 192 minecraft:light[level=13]
setblock 458 289 200 minecraft:light[level=13]
setblock 458 289 208 minecraft:light[level=13]
setblock 458 289 216 minecraft:light[level=13]
fill 423 290 186 423 297 186 minecraft:sandstone
fill 423 290 194 423 297 194 minecraft:sandstone
fill 423 290 202 423 297 202 minecraft:sandstone
fill 423 290 210 423 297 210 minecraft:sandstone
fill 423 290 218 423 297 218 minecraft:sandstone
fill 426 290 223 426 297 223 minecraft:sandstone
fill 430 290 181 430 297 181 minecraft:sandstone
fill 434 290 223 434 297 223 minecraft:sandstone
fill 438 290 181 438 297 181 minecraft:sandstone
fill 442 290 223 442 297 223 minecraft:sandstone
fill 446 290 181 446 297 181 minecraft:sandstone
fill 450 290 223 450 297 223 minecraft:sandstone
fill 454 290 181 454 297 181 minecraft:sandstone
fill 458 290 223 458 297 223 minecraft:sandstone
fill 462 290 181 462 297 181 minecraft:sandstone
fill 465 290 186 465 297 186 minecraft:sandstone
fill 465 290 194 465 297 194 minecraft:sandstone
fill 465 290 202 465 297 202 minecraft:sandstone
fill 465 290 210 465 297 210 minecraft:sandstone
fill 465 290 218 465 297 218 minecraft:sandstone
fill 424 294 182 424 295 187 minecraft:smooth_sandstone
fill 424 294 190 424 295 195 minecraft:smooth_sandstone
fill 424 294 198 425 294 203 minecraft:smooth_sandstone
fill 424 294 206 425 294 211 minecraft:smooth_sandstone
fill 424 294 214 425 294 219 minecraft:smooth_sandstone
fill 424 294 222 429 295 222 minecraft:smooth_sandstone
fill 425 294 183 425 294 189 minecraft:smooth_sandstone
fill 425 294 193 425 294 197 minecraft:smooth_sandstone
fill 425 294 204 425 294 205 minecraft:smooth_sandstone
fill 425 294 212 425 294 213 minecraft:smooth_sandstone
fill 425 294 220 425 294 221 minecraft:smooth_sandstone
fill 426 294 183 463 294 183 minecraft:smooth_sandstone
fill 426 294 221 464 294 221 minecraft:smooth_sandstone
fill 427 294 182 432 295 182 minecraft:smooth_sandstone
fill 432 294 222 437 295 222 minecraft:smooth_sandstone
fill 435 294 182 440 295 182 minecraft:smooth_sandstone
fill 440 294 222 445 295 222 minecraft:smooth_sandstone
fill 443 294 182 448 295 182 minecraft:smooth_sandstone
fill 448 294 222 453 295 222 minecraft:smooth_sandstone
fill 451 294 182 456 295 182 minecraft:smooth_sandstone
fill 456 294 222 461 295 222 minecraft:smooth_sandstone
fill 459 294 182 464 295 182 minecraft:smooth_sandstone
fill 463 294 184 463 294 220 minecraft:smooth_sandstone
fill 464 294 185 464 295 190 minecraft:smooth_sandstone
fill 464 294 193 464 295 198 minecraft:smooth_sandstone
fill 464 294 201 464 295 206 minecraft:smooth_sandstone
fill 464 294 209 464 295 214 minecraft:smooth_sandstone
fill 464 294 217 464 295 220 minecraft:smooth_sandstone
fill 464 294 222 464 295 222 minecraft:smooth_sandstone
fill 424 295 198 424 295 203 minecraft:smooth_sandstone
fill 424 295 206 424 295 211 minecraft:smooth_sandstone
fill 424 295 214 424 295 219 minecraft:smooth_sandstone
setblock 464 295 221 minecraft:smooth_sandstone
fill 424 297 190 424 297 194 minecraft:terracotta
fill 425 297 188 425 298 189 minecraft:terracotta
fill 425 297 193 425 298 194 minecraft:terracotta
setblock 426 297 184 minecraft:light[level=13]
fill 426 297 187 427 297 188 minecraft:terracotta
fill 426 297 194 428 297 194 minecraft:terracotta
setblock 426 297 200 minecraft:light[level=13]
setblock 426 297 208 minecraft:light[level=13]
setblock 426 297 216 minecraft:light[level=13]
fill 427 297 193 429 298 193 minecraft:terracotta
fill 428 297 188 429 297 189 minecraft:terracotta
fill 429 297 190 430 297 192 minecraft:terracotta
setblock 434 297 184 minecraft:light[level=13]
setblock 434 297 192 minecraft:light[level=13]
setblock 434 297 200 minecraft:light[level=13]
setblock 434 297 208 minecraft:light[level=13]
setblock 434 297 216 minecraft:light[level=13]
setblock 442 297 184 minecraft:light[level=13]
setblock 442 297 192 minecraft:light[level=13]
setblock 442 297 200 minecraft:light[level=13]
setblock 442 297 208 minecraft:light[level=13]
setblock 442 297 216 minecraft:light[level=13]
setblock 450 297 184 minecraft:light[level=13]
setblock 450 297 192 minecraft:light[level=13]
setblock 450 297 200 minecraft:light[level=13]
setblock 450 297 208 minecraft:light[level=13]
setblock 450 297 216 minecraft:light[level=13]
setblock 458 297 184 minecraft:light[level=13]
setblock 458 297 192 minecraft:light[level=13]
setblock 458 297 200 minecraft:light[level=13]
setblock 458 297 208 minecraft:light[level=13]
setblock 458 297 216 minecraft:light[level=13]
fill 423 298 186 423 300 186 minecraft:lantern
fill 423 298 194 423 300 194 minecraft:lantern
fill 423 298 202 423 300 202 minecraft:lantern
fill 423 298 210 423 300 210 minecraft:lantern
fill 423 298 218 423 300 218 minecraft:lantern
fill 424 298 190 424 298 193 minecraft:terracotta
fill 426 298 188 428 298 188 minecraft:terracotta
fill 426 298 194 427 298 194 minecraft:terracotta
fill 426 298 223 426 300 223 minecraft:lantern
fill 428 298 189 429 298 189 minecraft:terracotta
fill 429 298 190 429 298 192 minecraft:terracotta
fill 430 298 181 430 300 181 minecraft:lantern
fill 434 298 223 434 300 223 minecraft:lantern
fill 438 298 181 438 300 181 minecraft:lantern
fill 442 298 223 442 300 223 minecraft:lantern
fill 446 298 181 446 300 181 minecraft:lantern
fill 450 298 223 450 300 223 minecraft:lantern
fill 454 298 181 454 300 181 minecraft:lantern
fill 458 298 223 458 300 223 minecraft:lantern
fill 462 298 181 462 300 181 minecraft:lantern
fill 465 298 186 465 300 186 minecraft:lantern
fill 465 298 194 465 300 194 minecraft:lantern
fill 465 298 202 465 300 202 minecraft:lantern
fill 465 298 210 465 300 210 minecraft:lantern
fill 465 298 218 465 300 218 minecraft:lantern
fill 424 299 190 424 299 192 minecraft:terracotta
setblock 425 299 189 minecraft:terracotta
setblock 425 299 193 minecraft:terracotta
fill 427 299 193 428 299 193 minecraft:terracotta
setblock 428 299 189 minecraft:terracotta
setblock 429 299 191 minecraft:terracotta
fill 423 301 186 423 307 186 minecraft:sandstone
fill 423 301 194 423 307 194 minecraft:sandstone
fill 423 301 202 423 307 202 minecraft:sandstone
fill 423 301 210 423 307 210 minecraft:sandstone
fill 423 301 218 423 307 218 minecraft:sandstone
fill 426 301 223 426 307 223 minecraft:sandstone
fill 430 301 181 430 307 181 minecraft:sandstone
fill 434 301 223 434 307 223 minecraft:sandstone
fill 438 301 181 438 307 181 minecraft:sandstone
fill 442 301 223 442 307 223 minecraft:sandstone
fill 446 301 181 446 307 181 minecraft:sandstone
fill 450 301 223 450 307 223 minecraft:sandstone
fill 454 301 181 454 307 181 minecraft:sandstone
fill 458 301 223 458 307 223 minecraft:sandstone
fill 462 301 181 462 307 181 minecraft:sandstone
fill 465 301 186 465 307 186 minecraft:sandstone
fill 465 301 194 465 307 194 minecraft:sandstone
fill 465 301 202 465 307 202 minecraft:sandstone
fill 465 301 210 465 307 210 minecraft:sandstone
fill 465 301 218 465 307 218 minecraft:sandstone
