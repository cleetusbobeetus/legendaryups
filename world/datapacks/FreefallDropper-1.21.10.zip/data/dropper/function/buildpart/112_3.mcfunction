setblock 215 300 490 minecraft:light[level=11]
setblock 215 300 498 minecraft:light[level=11]
setblock 223 300 466 minecraft:light[level=11]
setblock 223 300 474 minecraft:light[level=11]
setblock 223 300 482 minecraft:light[level=11]
setblock 223 300 490 minecraft:light[level=11]
setblock 223 300 498 minecraft:light[level=11]
fill 188 301 468 188 307 468 minecraft:white_terracotta
fill 188 301 476 188 307 476 minecraft:white_terracotta
fill 188 301 484 188 307 484 minecraft:white_terracotta
fill 188 301 492 188 307 492 minecraft:white_terracotta
fill 188 301 500 188 307 500 minecraft:white_terracotta
fill 191 301 505 191 307 505 minecraft:white_terracotta
fill 195 301 463 195 307 463 minecraft:white_terracotta
fill 199 301 505 199 307 505 minecraft:white_terracotta
fill 203 301 463 203 307 463 minecraft:white_terracotta
fill 207 301 505 207 307 505 minecraft:white_terracotta
fill 211 301 463 211 307 463 minecraft:white_terracotta
fill 215 301 505 215 307 505 minecraft:white_terracotta
fill 219 301 463 219 307 463 minecraft:white_terracotta
fill 223 301 505 223 307 505 minecraft:white_terracotta
fill 227 301 463 227 307 463 minecraft:white_terracotta
fill 230 301 468 230 307 468 minecraft:white_terracotta
fill 230 301 476 230 307 476 minecraft:white_terracotta
fill 230 301 484 230 307 484 minecraft:white_terracotta
fill 230 301 492 230 307 492 minecraft:white_terracotta
fill 230 301 500 230 307 500 minecraft:white_terracotta
