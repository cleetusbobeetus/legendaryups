setblock 458 146 427 minecraft:light[level=12]
setblock 458 146 435 minecraft:light[level=12]
setblock 458 146 443 minecraft:light[level=12]
setblock 458 146 451 minecraft:light[level=12]
fill 459 146 458 462 151 458 minecraft:glowstone
fill 465 146 417 465 151 420 minecraft:glowstone
fill 465 146 429 465 151 432 minecraft:glowstone
fill 465 146 441 465 151 444 minecraft:glowstone
fill 465 146 453 465 151 456 minecraft:glowstone
fill 423 152 422 423 185 422 minecraft:cracked_stone_bricks
fill 423 152 423 423 152 424 minecraft:glowstone
fill 423 152 425 423 185 425 minecraft:cracked_stone_bricks
fill 423 152 434 423 185 434 minecraft:cracked_stone_bricks
fill 423 152 435 423 152 436 minecraft:glowstone
fill 423 152 437 423 178 437 minecraft:cracked_stone_bricks
fill 423 152 446 423 185 446 minecraft:cracked_stone_bricks
fill 423 152 447 423 152 448 minecraft:glowstone
fill 423 152 449 423 185 449 minecraft:cracked_stone_bricks
fill 423 152 458 423 185 458 minecraft:cracked_stone_bricks
fill 424 152 458 425 152 458 minecraft:glowstone
fill 426 152 458 426 185 458 minecraft:cracked_stone_bricks
fill 430 152 416 430 185 416 minecraft:cracked_stone_bricks
fill 431 152 416 432 152 416 minecraft:glowstone
fill 433 152 416 433 185 416 minecraft:cracked_stone_bricks
fill 435 152 458 435 185 458 minecraft:cracked_stone_bricks
fill 436 152 458 437 152 458 minecraft:glowstone
fill 438 152 458 438 185 458 minecraft:cracked_stone_bricks
fill 442 152 416 442 185 416 minecraft:cracked_stone_bricks
fill 443 152 416 444 152 416 minecraft:glowstone
fill 445 152 416 445 185 416 minecraft:cracked_stone_bricks
fill 447 152 458 447 185 458 minecraft:cracked_stone_bricks
fill 448 152 458 449 152 458 minecraft:glowstone
fill 450 152 458 450 185 458 minecraft:cracked_stone_bricks
fill 454 152 416 454 185 416 minecraft:cracked_stone_bricks
fill 455 152 416 456 152 416 minecraft:glowstone
fill 457 152 416 457 185 416 minecraft:cracked_stone_bricks
fill 459 152 438 459 155 438 minecraft:iron_bars
fill 459 152 458 459 185 458 minecraft:cracked_stone_bricks
fill 460 152 458 461 152 458 minecraft:glowstone
fill 462 152 458 462 185 458 minecraft:cracked_stone_bricks
fill 465 152 417 465 185 417 minecraft:cracked_stone_bricks
fill 465 152 418 465 152 419 minecraft:glowstone
fill 465 152 420 465 185 420 minecraft:cracked_stone_bricks
fill 465 152 429 465 185 429 minecraft:cracked_stone_bricks
fill 465 152 430 465 152 431 minecraft:glowstone
fill 465 152 432 465 185 432 minecraft:cracked_stone_bricks
fill 465 152 441 465 185 441 minecraft:cracked_stone_bricks
fill 465 152 442 465 152 443 minecraft:glowstone
fill 465 152 444 465 185 444 minecraft:cracked_stone_bricks
fill 465 152 453 465 185 453 minecraft:cracked_stone_bricks
fill 465 152 454 465 152 455 minecraft:glowstone
fill 465 152 456 465 185 456 minecraft:cracked_stone_bricks
fill 423 153 423 423 185 424 minecraft:cracked_stone_bricks
fill 423 153 435 423 178 436 minecraft:cracked_stone_bricks
fill 423 153 447 423 174 448 minecraft:cracked_stone_bricks
fill 424 153 458 425 185 458 minecraft:cracked_stone_bricks
fill 431 153 416 432 185 416 minecraft:cracked_stone_bricks
fill 436 153 458 437 185 458 minecraft:cracked_stone_bricks
fill 443 153 416 444 185 416 minecraft:cracked_stone_bricks
fill 448 153 458 449 185 458 minecraft:cracked_stone_bricks
fill 455 153 416 456 185 416 minecraft:cracked_stone_bricks
fill 460 153 458 461 185 458 minecraft:cracked_stone_bricks
fill 465 153 418 465 185 419 minecraft:cracked_stone_bricks
fill 465 153 430 465 185 431 minecraft:cracked_stone_bricks
fill 465 153 442 465 185 443 minecraft:cracked_stone_bricks
fill 465 153 454 465 185 455 minecraft:cracked_stone_bricks
setblock 426 154 419 minecraft:light[level=12]
setblock 426 154 427 minecraft:light[level=12]
setblock 426 154 435 minecraft:light[level=12]
setblock 426 154 443 minecraft:light[level=12]
setblock 426 154 451 minecraft:light[level=12]
setblock 434 154 419 minecraft:light[level=12]
setblock 434 154 427 minecraft:light[level=12]
setblock 434 154 435 minecraft:light[level=12]
setblock 434 154 443 minecraft:light[level=12]
setblock 434 154 451 minecraft:light[level=12]
setblock 442 154 419 minecraft:light[level=12]
setblock 442 154 427 minecraft:light[level=12]
setblock 442 154 435 minecraft:light[level=12]
setblock 442 154 443 minecraft:light[level=12]
setblock 442 154 451 minecraft:light[level=12]
setblock 450 154 419 minecraft:light[level=12]
setblock 450 154 427 minecraft:light[level=12]
setblock 450 154 435 minecraft:light[level=12]
setblock 450 154 443 minecraft:light[level=12]
setblock 450 154 451 minecraft:light[level=12]
setblock 458 154 419 minecraft:light[level=12]
setblock 458 154 427 minecraft:light[level=12]
setblock 458 154 435 minecraft:light[level=12]
setblock 458 154 443 minecraft:light[level=12]
setblock 458 154 451 minecraft:light[level=12]
fill 459 156 433 463 156 443 minecraft:cobblestone
fill 459 157 433 463 157 443 minecraft:iron_block
fill 459 158 433 459 158 443 minecraft:gray_concrete
fill 464 158 437 464 161 439 minecraft:glowstone
setblock 459 159 433 minecraft:iron_block
setblock 459 159 438 minecraft:iron_block
setblock 459 159 443 minecraft:iron_block
fill 425 160 426 425 162 428 minecraft:iron_block
fill 425 160 438 425 162 440 minecraft:iron_block
fill 425 160 450 425 162 452 minecraft:iron_block
fill 431 160 456 433 162 456 minecraft:iron_block
fill 435 160 418 437 162 418 minecraft:iron_block
fill 443 160 456 445 162 456 minecraft:iron_block
fill 447 160 418 449 162 418 minecraft:iron_block
fill 455 160 456 457 162 456 minecraft:iron_block
fill 459 160 418 461 162 418 minecraft:iron_block
fill 463 160 426 463 162 428 minecraft:iron_block
fill 463 160 438 463 162 440 minecraft:iron_block
fill 463 160 450 463 162 452 minecraft:iron_block
setblock 426 162 419 minecraft:light[level=12]
setblock 426 162 427 minecraft:light[level=12]
setblock 426 162 435 minecraft:light[level=12]
setblock 426 162 443 minecraft:light[level=12]
setblock 426 162 451 minecraft:light[level=12]
setblock 434 162 419 minecraft:light[level=12]
setblock 434 162 427 minecraft:light[level=12]
setblock 434 162 435 minecraft:light[level=12]
setblock 434 162 443 minecraft:light[level=12]
setblock 434 162 451 minecraft:light[level=12]
setblock 442 162 419 minecraft:light[level=12]
setblock 442 162 427 minecraft:light[level=12]
setblock 442 162 435 minecraft:light[level=12]
setblock 442 162 443 minecraft:light[level=12]
setblock 442 162 451 minecraft:light[level=12]
setblock 450 162 419 minecraft:light[level=12]
setblock 450 162 427 minecraft:light[level=12]
setblock 450 162 435 minecraft:light[level=12]
setblock 450 162 443 minecraft:light[level=12]
setblock 450 162 451 minecraft:light[level=12]
setblock 458 162 419 minecraft:light[level=12]
setblock 458 162 427 minecraft:light[level=12]
setblock 458 162 435 minecraft:light[level=12]
setblock 458 162 443 minecraft:light[level=12]
setblock 458 162 451 minecraft:light[level=12]
fill 464 162 437 464 162 439 minecraft:iron_block
fill 437 168 435 437 170 437 minecraft:iron_block
fill 438 168 433 438 170 435 minecraft:iron_block
fill 438 168 436 441 168 436 minecraft:cobblestone
fill 438 168 437 438 170 439 minecraft:iron_block
fill 439 168 431 439 170 432 minecraft:iron_block
fill 439 168 433 442 168 435 minecraft:cobblestone
fill 439 168 437 442 168 439 minecraft:cobblestone
fill 439 168 440 439 170 441 minecraft:iron_block
fill 440 168 431 440 170 431 minecraft:iron_block
fill 440 168 432 448 169 432 minecraft:cobblestone
fill 440 168 440 448 169 440 minecraft:cobblestone
fill 440 168 441 440 170 441 minecraft:iron_block
fill 441 168 430 443 170 430 minecraft:iron_block
fill 441 168 431 447 169 431 minecraft:cobblestone
fill 441 168 441 447 169 441 minecraft:cobblestone
fill 441 168 442 443 170 442 minecraft:iron_block
fill 443 168 429 445 170 429 minecraft:iron_block
fill 443 168 433 443 168 434 minecraft:cobblestone
fill 443 168 438 443 168 439 minecraft:cobblestone
fill 443 168 443 445 170 443 minecraft:iron_block
fill 444 168 430 444 169 430 minecraft:cobblestone
fill 444 168 433 449 168 433 minecraft:cobblestone
fill 444 168 439 449 168 439 minecraft:cobblestone
fill 444 168 442 444 169 442 minecraft:cobblestone
fill 445 168 430 447 170 430 minecraft:iron_block
fill 445 168 434 449 168 434 minecraft:cobblestone
fill 445 168 438 449 168 438 minecraft:cobblestone
fill 445 168 442 447 170 442 minecraft:iron_block
fill 446 168 435 449 168 435 minecraft:cobblestone
fill 446 168 437 449 168 437 minecraft:cobblestone
fill 447 168 436 450 168 436 minecraft:cobblestone
fill 448 168 431 449 170 431 minecraft:iron_block
fill 448 168 441 449 170 441 minecraft:iron_block
fill 449 168 432 449 170 432 minecraft:iron_block
fill 449 168 440 449 170 440 minecraft:iron_block
fill 450 168 433 450 170 435 minecraft:iron_block
fill 450 168 437 450 170 439 minecraft:iron_block
fill 451 168 435 451 170 437 minecraft:iron_block
fill 424 169 417 436 169 457 minecraft:cracked_stone_bricks
fill 437 169 417 437 169 433 minecraft:cracked_stone_bricks
setblock 437 169 434 minecraft:iron_block
setblock 437 169 438 minecraft:iron_block
fill 437 169 439 437 169 457 minecraft:cracked_stone_bricks
fill 438 169 417 438 169 431 minecraft:cracked_stone_bricks
setblock 438 169 432 minecraft:iron_block
fill 438 169 436 440 169 436 minecraft:cobblestone
setblock 438 169 440 minecraft:iron_block
fill 438 169 441 438 169 457 minecraft:cracked_stone_bricks
fill 439 169 417 439 169 430 minecraft:cracked_stone_bricks
fill 439 169 433 440 169 435 minecraft:cobblestone
fill 439 169 437 440 169 439 minecraft:cobblestone
fill 439 169 442 439 169 457 minecraft:cracked_stone_bricks
fill 440 169 417 441 169 429 minecraft:cracked_stone_bricks
setblock 440 169 430 minecraft:iron_block
setblock 440 169 442 minecraft:iron_block
fill 440 169 443 441 169 457 minecraft:cracked_stone_bricks
fill 441 169 433 441 169 434 minecraft:cobblestone
fill 441 169 435 441 169 437 minecraft:glowstone
fill 441 169 438 441 169 439 minecraft:cobblestone
fill 442 169 417 464 169 428 minecraft:cracked_stone_bricks
setblock 442 169 429 minecraft:iron_block
setblock 442 169 433 minecraft:cobblestone
fill 442 169 434 442 169 435 minecraft:glowstone
fill 442 169 437 442 169 438 minecraft:glowstone
setblock 442 169 439 minecraft:cobblestone
setblock 442 169 443 minecraft:iron_block
fill 442 169 444 464 169 457 minecraft:cracked_stone_bricks
fill 443 169 433 443 169 434 minecraft:glowstone
fill 443 169 438 443 169 439 minecraft:glowstone
fill 444 169 433 445 169 433 minecraft:glowstone
fill 444 169 439 445 169 439 minecraft:glowstone
fill 445 169 434 446 169 434 minecraft:glowstone
fill 445 169 438 446 169 438 minecraft:glowstone
setblock 446 169 429 minecraft:iron_block
fill 446 169 433 449 169 433 minecraft:cobblestone
fill 446 169 435 447 169 435 minecraft:glowstone
fill 446 169 437 447 169 437 minecraft:glowstone
fill 446 169 439 449 169 439 minecraft:cobblestone
setblock 446 169 443 minecraft:iron_block
fill 447 169 429 464 169 429 minecraft:cracked_stone_bricks
fill 447 169 434 449 169 434 minecraft:cobblestone
setblock 447 169 436 minecraft:glowstone
fill 447 169 438 449 169 438 minecraft:cobblestone
fill 447 169 443 464 169 443 minecraft:cracked_stone_bricks
setblock 448 169 430 minecraft:iron_block
fill 448 169 435 449 169 437 minecraft:cobblestone
setblock 448 169 442 minecraft:iron_block
fill 449 169 430 464 169 430 minecraft:cracked_stone_bricks
fill 449 169 442 464 169 442 minecraft:cracked_stone_bricks
fill 450 169 431 464 169 431 minecraft:cracked_stone_bricks
setblock 450 169 432 minecraft:iron_block
setblock 450 169 436 minecraft:cobblestone
setblock 450 169 440 minecraft:iron_block
fill 450 169 441 464 169 441 minecraft:cracked_stone_bricks
fill 451 169 432 464 169 433 minecraft:cracked_stone_bricks
setblock 451 169 434 minecraft:iron_block
setblock 451 169 438 minecraft:iron_block
fill 451 169 439 464 169 440 minecraft:cracked_stone_bricks
fill 452 169 434 464 169 438 minecraft:cracked_stone_bricks
setblock 426 170 419 minecraft:light[level=12]
setblock 426 170 427 minecraft:light[level=12]
setblock 426 170 435 minecraft:light[level=12]
setblock 426 170 443 minecraft:light[level=12]
setblock 426 170 451 minecraft:light[level=12]
setblock 434 170 419 minecraft:light[level=12]
setblock 434 170 427 minecraft:light[level=12]
setblock 434 170 435 minecraft:light[level=12]
setblock 434 170 443 minecraft:light[level=12]
setblock 434 170 451 minecraft:light[level=12]
fill 438 170 436 439 170 436 minecraft:iron_block
fill 439 170 433 439 170 435 minecraft:iron_block
fill 439 170 437 439 170 439 minecraft:iron_block
fill 440 170 432 440 170 433 minecraft:iron_block
fill 440 170 439 440 170 440 minecraft:iron_block
fill 441 170 431 441 170 432 minecraft:iron_block
fill 441 170 440 441 170 441 minecraft:iron_block
setblock 442 170 419 minecraft:light[level=12]
setblock 442 170 427 minecraft:light[level=12]
fill 442 170 431 447 170 431 minecraft:iron_block
setblock 442 170 435 minecraft:light[level=12]
fill 442 170 441 447 170 441 minecraft:iron_block
setblock 442 170 443 minecraft:light[level=12]
setblock 442 170 451 minecraft:light[level=12]
setblock 444 170 430 minecraft:iron_block
setblock 444 170 442 minecraft:iron_block
fill 447 170 432 448 170 432 minecraft:iron_block
fill 447 170 440 448 170 440 minecraft:iron_block
fill 448 170 433 449 170 433 minecraft:iron_block
fill 448 170 439 449 170 439 minecraft:iron_block
fill 449 170 434 449 170 438 minecraft:iron_block
setblock 450 170 419 minecraft:light[level=12]
setblock 450 170 427 minecraft:light[level=12]
setblock 450 170 436 minecraft:iron_block
setblock 450 170 443 minecraft:light[level=12]
setblock 450 170 451 minecraft:light[level=12]
setblock 458 170 419 minecraft:light[level=12]
setblock 458 170 427 minecraft:light[level=12]
setblock 458 170 435 minecraft:light[level=12]
setblock 458 170 443 minecraft:light[level=12]
setblock 458 170 451 minecraft:light[level=12]
fill 424 173 417 426 225 417 minecraft:iron_block
fill 424 173 427 424 225 429 minecraft:iron_block
fill 424 173 439 424 225 441 minecraft:iron_block
fill 424 173 448 433 174 457 minecraft:iron_block
fill 428 173 437 428 174 437 minecraft:iron_bars
fill 433 173 433 433 176 439 minecraft:iron_block
fill 434 173 431 434 176 432 minecraft:iron_block
fill 434 173 440 434 176 441 minecraft:iron_block
fill 435 173 429 435 176 430 minecraft:iron_block
fill 435 173 442 435 176 443 minecraft:iron_block
fill 436 173 417 438 225 417 minecraft:iron_block
fill 436 173 428 436 173 429 minecraft:iron_block
fill 436 173 443 436 173 444 minecraft:iron_block
fill 437 173 427 437 176 428 minecraft:iron_block
fill 437 173 444 437 176 445 minecraft:iron_block
fill 438 173 427 438 176 427 minecraft:iron_block
fill 438 173 445 438 176 445 minecraft:iron_block
fill 439 173 426 440 176 426 minecraft:iron_block
fill 439 173 446 440 176 446 minecraft:iron_block
fill 441 173 425 447 176 425 minecraft:iron_block
fill 441 173 447 447 176 447 minecraft:iron_block
fill 442 173 457 444 225 457 minecraft:iron_block
fill 448 173 417 450 225 417 minecraft:iron_block
fill 448 173 426 449 176 426 minecraft:iron_block
fill 448 173 446 449 176 446 minecraft:iron_block
fill 449 173 448 461 174 457 minecraft:iron_block
fill 450 173 427 451 176 427 minecraft:iron_block
fill 450 173 445 451 176 445 minecraft:iron_block
fill 451 173 428 452 173 428 minecraft:iron_block
fill 451 173 444 452 173 444 minecraft:iron_block
fill 452 173 429 453 176 429 minecraft:iron_block
fill 452 173 443 453 176 443 minecraft:iron_block
fill 453 173 430 453 176 430 minecraft:iron_block
fill 453 173 442 453 176 442 minecraft:iron_block
fill 454 173 431 454 176 432 minecraft:iron_block
fill 454 173 440 454 176 441 minecraft:iron_block
fill 455 173 433 455 176 439 minecraft:iron_block
fill 460 173 417 462 225 417 minecraft:iron_block
fill 464 173 425 464 225 427 minecraft:iron_block
fill 464 173 437 464 225 439 minecraft:iron_block
fill 464 173 449 464 225 451 minecraft:iron_block
fill 432 174 433 432 174 439 minecraft:iron_block
fill 433 174 431 433 175 432 minecraft:iron_block
fill 433 174 440 433 175 441 minecraft:iron_block
fill 434 174 429 434 175 430 minecraft:iron_block
fill 434 174 433 434 175 439 minecraft:iron_block
fill 434 174 442 434 175 443 minecraft:iron_block
fill 435 174 428 435 175 428 minecraft:iron_block
fill 435 174 431 435 175 433 minecraft:iron_block
fill 435 174 439 435 175 441 minecraft:iron_block
fill 435 174 444 435 175 444 minecraft:iron_block
fill 436 174 427 436 175 427 minecraft:iron_block
fill 436 174 428 436 175 428 minecraft:light_gray_concrete
fill 436 174 429 436 175 430 minecraft:iron_block
fill 436 174 442 436 175 443 minecraft:iron_block
fill 436 174 444 436 175 444 minecraft:light_gray_concrete
fill 436 174 445 436 175 445 minecraft:iron_block
fill 437 174 426 438 175 426 minecraft:iron_block
fill 437 174 429 437 175 429 minecraft:light_gray_concrete
fill 437 174 443 437 175 443 minecraft:light_gray_concrete
fill 437 174 446 438 175 446 minecraft:iron_block
fill 438 174 428 438 175 428 minecraft:iron_block
fill 438 174 430 438 175 430 minecraft:light_gray_concrete
fill 438 174 442 438 175 442 minecraft:light_gray_concrete
fill 438 174 444 438 175 444 minecraft:iron_block
fill 439 174 425 440 175 425 minecraft:iron_block
fill 439 174 427 441 175 427 minecraft:iron_block
fill 439 174 431 439 175 431 minecraft:light_gray_concrete
fill 439 174 441 439 175 441 minecraft:light_gray_concrete
fill 439 174 445 441 175 445 minecraft:iron_block
fill 439 174 447 440 175 447 minecraft:iron_block
fill 440 174 432 440 175 432 minecraft:light_gray_concrete
fill 440 174 434 440 175 438 minecraft:white_concrete
fill 440 174 440 440 175 440 minecraft:light_gray_concrete
fill 441 174 424 447 175 424 minecraft:iron_block
fill 441 174 426 447 175 426 minecraft:iron_block
fill 441 174 433 441 175 434 minecraft:white_concrete
fill 441 174 438 441 175 439 minecraft:white_concrete
fill 441 174 446 447 175 446 minecraft:iron_block
fill 441 174 448 447 175 448 minecraft:iron_block
fill 442 174 432 442 175 433 minecraft:white_concrete
fill 442 174 439 442 175 440 minecraft:white_concrete
fill 443 174 432 446 175 432 minecraft:white_concrete
fill 443 174 440 446 175 440 minecraft:white_concrete
fill 446 174 433 447 175 433 minecraft:white_concrete
fill 446 174 439 447 175 439 minecraft:white_concrete
fill 447 174 427 449 175 427 minecraft:iron_block
fill 447 174 434 448 175 434 minecraft:white_concrete
fill 447 174 438 448 175 438 minecraft:white_concrete
fill 447 174 445 449 175 445 minecraft:iron_block
fill 448 174 425 449 175 425 minecraft:iron_block
fill 448 174 432 448 175 432 minecraft:light_gray_concrete
fill 448 174 435 448 175 437 minecraft:white_concrete
fill 448 174 440 448 175 440 minecraft:light_gray_concrete
fill 448 174 447 449 175 447 minecraft:iron_block
fill 449 174 431 449 175 431 minecraft:light_gray_concrete
fill 449 174 441 449 175 441 minecraft:light_gray_concrete
fill 450 174 426 451 175 426 minecraft:iron_block
fill 450 174 428 451 175 428 minecraft:iron_block
fill 450 174 430 450 175 430 minecraft:light_gray_concrete
fill 450 174 442 450 175 442 minecraft:light_gray_concrete
fill 450 174 444 451 175 444 minecraft:iron_block
fill 450 174 446 451 175 446 minecraft:iron_block
fill 451 174 429 451 175 429 minecraft:light_gray_concrete
fill 451 174 443 451 175 443 minecraft:light_gray_concrete
fill 452 174 427 452 175 427 minecraft:iron_block
fill 452 174 428 452 175 428 minecraft:light_gray_concrete
fill 452 174 430 452 175 430 minecraft:iron_block
fill 452 174 442 452 175 442 minecraft:iron_block
fill 452 174 444 452 175 444 minecraft:light_gray_concrete
fill 452 174 445 452 175 445 minecraft:iron_block
fill 453 174 428 453 175 428 minecraft:iron_block
fill 453 174 431 453 175 433 minecraft:iron_block
fill 453 174 439 453 175 441 minecraft:iron_block
fill 453 174 444 453 175 444 minecraft:iron_block
fill 454 174 429 454 175 430 minecraft:iron_block
fill 454 174 433 454 175 439 minecraft:iron_block
fill 454 174 442 454 175 443 minecraft:iron_block
fill 455 174 431 455 175 432 minecraft:iron_block
fill 455 174 440 455 175 441 minecraft:iron_block
fill 456 174 433 456 174 439 minecraft:iron_block
fill 423 175 447 423 185 447 minecraft:cracked_stone_bricks
setblock 423 175 448 minecraft:glowstone
setblock 423 175 450 minecraft:glowstone
fill 423 175 451 423 207 451 minecraft:cracked_stone_bricks
setblock 423 175 452 minecraft:glowstone
fill 423 175 453 423 207 453 minecraft:cracked_stone_bricks
setblock 423 175 454 minecraft:glowstone
fill 423 175 455 423 204 455 minecraft:cracked_stone_bricks
setblock 423 175 456 minecraft:glowstone
fill 424 175 448 424 184 448 minecraft:iron_block
setblock 424 175 449 minecraft:glowstone
fill 424 175 450 424 189 450 minecraft:iron_block
setblock 424 175 451 minecraft:glowstone
fill 424 175 452 424 225 452 minecraft:iron_block
setblock 424 175 453 minecraft:glowstone
fill 424 175 454 424 189 454 minecraft:iron_block
setblock 424 175 455 minecraft:glowstone
fill 424 175 456 424 184 456 minecraft:iron_block
setblock 424 175 457 minecraft:glowstone
setblock 425 175 448 minecraft:glowstone
fill 425 175 449 425 189 449 minecraft:iron_block
setblock 425 175 450 minecraft:glowstone
fill 425 175 451 425 189 451 minecraft:iron_block
setblock 425 175 452 minecraft:glowstone
fill 425 175 453 425 189 453 minecraft:iron_block
setblock 425 175 454 minecraft:glowstone
fill 425 175 455 425 189 455 minecraft:iron_block
setblock 425 175 456 minecraft:glowstone
fill 425 175 457 425 184 457 minecraft:iron_block
fill 426 175 448 426 189 448 minecraft:iron_block
setblock 426 175 449 minecraft:glowstone
fill 426 175 450 426 189 450 minecraft:iron_block
setblock 426 175 451 minecraft:glowstone
fill 426 175 452 426 189 452 minecraft:iron_block
setblock 426 175 453 minecraft:glowstone
fill 426 175 454 426 189 454 minecraft:iron_block
setblock 426 175 455 minecraft:glowstone
fill 426 175 456 426 189 456 minecraft:iron_block
setblock 426 175 457 minecraft:glowstone
setblock 427 175 448 minecraft:glowstone
fill 427 175 449 427 189 449 minecraft:iron_block
setblock 427 175 450 minecraft:glowstone
fill 427 175 451 427 189 451 minecraft:iron_block
setblock 427 175 452 minecraft:glowstone
fill 427 175 453 427 189 453 minecraft:iron_block
setblock 427 175 454 minecraft:glowstone
fill 427 175 455 427 189 455 minecraft:iron_block
setblock 427 175 456 minecraft:glowstone
fill 427 175 457 427 184 457 minecraft:iron_block
fill 428 175 433 432 175 439 minecraft:blue_stained_glass
fill 428 175 448 428 189 448 minecraft:iron_block
setblock 428 175 449 minecraft:glowstone
fill 428 175 450 428 189 450 minecraft:iron_block
setblock 428 175 451 minecraft:glowstone
fill 428 175 452 428 189 452 minecraft:iron_block
setblock 428 175 453 minecraft:glowstone
fill 428 175 454 428 189 454 minecraft:iron_block
setblock 428 175 455 minecraft:glowstone
fill 428 175 456 428 189 456 minecraft:iron_block
setblock 428 175 457 minecraft:glowstone
setblock 429 175 448 minecraft:glowstone
fill 429 175 449 429 189 449 minecraft:iron_block
setblock 429 175 450 minecraft:glowstone
fill 429 175 451 429 189 451 minecraft:iron_block
setblock 429 175 452 minecraft:glowstone
fill 429 175 453 429 189 453 minecraft:iron_block
setblock 429 175 454 minecraft:glowstone
fill 429 175 455 429 189 455 minecraft:iron_block
setblock 429 175 456 minecraft:glowstone
fill 429 175 457 429 189 457 minecraft:iron_block
fill 430 175 448 430 189 448 minecraft:iron_block
setblock 430 175 449 minecraft:glowstone
fill 430 175 450 430 189 450 minecraft:iron_block
setblock 430 175 451 minecraft:glowstone
fill 430 175 452 430 189 452 minecraft:iron_block
setblock 430 175 453 minecraft:glowstone
fill 430 175 454 430 189 454 minecraft:iron_block
setblock 430 175 455 minecraft:glowstone
fill 430 175 456 430 189 456 minecraft:iron_block
setblock 430 175 457 minecraft:glowstone
setblock 431 175 448 minecraft:glowstone
fill 431 175 449 431 189 449 minecraft:iron_block
setblock 431 175 450 minecraft:glowstone
fill 431 175 451 431 189 451 minecraft:iron_block
setblock 431 175 452 minecraft:glowstone
fill 431 175 453 431 189 453 minecraft:iron_block
setblock 431 175 454 minecraft:glowstone
fill 431 175 455 431 189 455 minecraft:iron_block
setblock 431 175 456 minecraft:glowstone
fill 431 175 457 431 225 457 minecraft:iron_block
fill 432 175 448 432 189 448 minecraft:iron_block
setblock 432 175 449 minecraft:glowstone
fill 432 175 450 432 189 450 minecraft:iron_block
setblock 432 175 451 minecraft:glowstone
fill 432 175 452 432 189 452 minecraft:iron_block
setblock 432 175 453 minecraft:glowstone
fill 432 175 454 432 189 454 minecraft:iron_block
setblock 432 175 455 minecraft:glowstone
fill 432 175 456 432 189 456 minecraft:iron_block
setblock 432 175 457 minecraft:glowstone
setblock 433 175 448 minecraft:glowstone
fill 433 175 449 433 189 449 minecraft:iron_block
setblock 433 175 450 minecraft:glowstone
fill 433 175 451 433 189 451 minecraft:iron_block
setblock 433 175 452 minecraft:glowstone
fill 433 175 453 433 189 453 minecraft:iron_block
setblock 433 175 454 minecraft:glowstone
fill 433 175 455 433 189 455 minecraft:iron_block
setblock 433 175 456 minecraft:glowstone
fill 433 175 457 433 189 457 minecraft:iron_block
setblock 449 175 448 minecraft:glowstone
fill 449 175 449 449 199 449 minecraft:iron_block
setblock 449 175 450 minecraft:glowstone
fill 449 175 451 449 199 451 minecraft:iron_block
setblock 449 175 452 minecraft:glowstone
fill 449 175 453 449 199 453 minecraft:iron_block
setblock 449 175 454 minecraft:glowstone
fill 449 175 455 449 199 455 minecraft:iron_block
setblock 449 175 456 minecraft:glowstone
fill 449 175 457 449 184 457 minecraft:iron_block
fill 450 175 448 450 199 448 minecraft:iron_block
setblock 450 175 449 minecraft:glowstone
fill 450 175 450 450 199 450 minecraft:iron_block
setblock 450 175 451 minecraft:glowstone
fill 450 175 452 450 199 452 minecraft:iron_block
setblock 450 175 453 minecraft:glowstone
fill 450 175 454 450 199 454 minecraft:iron_block
setblock 450 175 455 minecraft:glowstone
fill 450 175 456 450 199 456 minecraft:iron_block
setblock 450 175 457 minecraft:glowstone
setblock 451 175 448 minecraft:glowstone
fill 451 175 449 451 199 449 minecraft:iron_block
setblock 451 175 450 minecraft:glowstone
fill 451 175 451 451 199 451 minecraft:iron_block
setblock 451 175 452 minecraft:glowstone
fill 451 175 453 451 199 453 minecraft:iron_block
setblock 451 175 454 minecraft:glowstone
fill 451 175 455 451 199 455 minecraft:iron_block
setblock 451 175 456 minecraft:glowstone
fill 451 175 457 451 184 457 minecraft:iron_block
fill 452 175 448 452 199 448 minecraft:iron_block
setblock 452 175 449 minecraft:glowstone
fill 452 175 450 452 199 450 minecraft:iron_block
setblock 452 175 451 minecraft:glowstone
fill 452 175 452 452 199 452 minecraft:iron_block
setblock 452 175 453 minecraft:glowstone
fill 452 175 454 452 199 454 minecraft:iron_block
setblock 452 175 455 minecraft:glowstone
fill 452 175 456 452 199 456 minecraft:iron_block
setblock 452 175 457 minecraft:glowstone
setblock 453 175 448 minecraft:glowstone
fill 453 175 449 453 199 449 minecraft:iron_block
setblock 453 175 450 minecraft:glowstone
fill 453 175 451 453 199 451 minecraft:iron_block
setblock 453 175 452 minecraft:glowstone
fill 453 175 453 453 199 453 minecraft:iron_block
setblock 453 175 454 minecraft:glowstone
fill 453 175 455 453 199 455 minecraft:iron_block
setblock 453 175 456 minecraft:glowstone
fill 453 175 457 453 199 457 minecraft:iron_block
fill 454 175 448 454 199 448 minecraft:iron_block
setblock 454 175 449 minecraft:glowstone
fill 454 175 450 454 199 450 minecraft:iron_block
setblock 454 175 451 minecraft:glowstone
fill 454 175 452 454 199 452 minecraft:iron_block
setblock 454 175 453 minecraft:glowstone
fill 454 175 454 454 199 454 minecraft:iron_block
setblock 454 175 455 minecraft:glowstone
fill 454 175 456 454 199 456 minecraft:iron_block
setblock 454 175 457 minecraft:glowstone
setblock 455 175 448 minecraft:glowstone
fill 455 175 449 455 199 449 minecraft:iron_block
setblock 455 175 450 minecraft:glowstone
fill 455 175 451 455 199 451 minecraft:iron_block
setblock 455 175 452 minecraft:glowstone
fill 455 175 453 455 199 453 minecraft:iron_block
setblock 455 175 454 minecraft:glowstone
fill 455 175 455 455 199 455 minecraft:iron_block
setblock 455 175 456 minecraft:glowstone
fill 455 175 457 455 225 457 minecraft:iron_block
fill 456 175 433 460 175 439 minecraft:blue_stained_glass
fill 456 175 448 456 199 448 minecraft:iron_block
setblock 456 175 449 minecraft:glowstone
fill 456 175 450 456 199 450 minecraft:iron_block
setblock 456 175 451 minecraft:glowstone
fill 456 175 452 456 199 452 minecraft:iron_block
setblock 456 175 453 minecraft:glowstone
fill 456 175 454 456 199 454 minecraft:iron_block
setblock 456 175 455 minecraft:glowstone
fill 456 175 456 456 205 456 minecraft:iron_block
setblock 456 175 457 minecraft:glowstone
setblock 457 175 448 minecraft:glowstone
fill 457 175 449 457 199 449 minecraft:iron_block
setblock 457 175 450 minecraft:glowstone
fill 457 175 451 457 199 451 minecraft:iron_block
setblock 457 175 452 minecraft:glowstone
fill 457 175 453 457 199 453 minecraft:iron_block
setblock 457 175 454 minecraft:glowstone
fill 457 175 455 457 199 455 minecraft:iron_block
setblock 457 175 456 minecraft:glowstone
fill 457 175 457 457 199 457 minecraft:iron_block
fill 458 175 448 458 199 448 minecraft:iron_block
setblock 458 175 449 minecraft:glowstone
fill 458 175 450 458 199 450 minecraft:iron_block
setblock 458 175 451 minecraft:glowstone
fill 458 175 452 458 199 452 minecraft:iron_block
setblock 458 175 453 minecraft:glowstone
fill 458 175 454 458 199 454 minecraft:iron_block
setblock 458 175 455 minecraft:glowstone
fill 458 175 456 458 199 456 minecraft:iron_block
setblock 458 175 457 minecraft:glowstone
setblock 459 175 448 minecraft:glowstone
fill 459 175 449 459 199 449 minecraft:iron_block
setblock 459 175 450 minecraft:glowstone
fill 459 175 451 459 199 451 minecraft:iron_block
setblock 459 175 452 minecraft:glowstone
fill 459 175 453 459 199 453 minecraft:iron_block
setblock 459 175 454 minecraft:glowstone
fill 459 175 455 459 199 455 minecraft:iron_block
setblock 459 175 456 minecraft:glowstone
fill 459 175 457 459 184 457 minecraft:iron_block
fill 460 175 448 460 199 448 minecraft:iron_block
setblock 460 175 449 minecraft:glowstone
fill 460 175 450 460 199 450 minecraft:iron_block
setblock 460 175 451 minecraft:glowstone
fill 460 175 452 460 199 452 minecraft:iron_block
setblock 460 175 453 minecraft:glowstone
fill 460 175 454 460 199 454 minecraft:iron_block
setblock 460 175 455 minecraft:glowstone
fill 460 175 456 460 199 456 minecraft:iron_block
setblock 460 175 457 minecraft:glowstone
fill 461 175 440 463 176 440 minecraft:iron_bars
setblock 461 175 448 minecraft:glowstone
fill 461 175 449 461 199 449 minecraft:iron_block
setblock 461 175 450 minecraft:glowstone
fill 461 175 451 461 199 451 minecraft:iron_block
setblock 461 175 452 minecraft:glowstone
fill 461 175 453 461 199 453 minecraft:iron_block
setblock 461 175 454 minecraft:glowstone
fill 461 175 455 461 199 455 minecraft:iron_block
setblock 461 175 456 minecraft:glowstone
fill 461 175 457 461 184 457 minecraft:iron_block
fill 423 176 448 423 177 448 minecraft:cracked_stone_bricks
fill 423 176 450 423 177 450 minecraft:cracked_stone_bricks
fill 423 176 452 423 177 452 minecraft:cracked_stone_bricks
fill 423 176 454 423 177 454 minecraft:cracked_stone_bricks
fill 423 176 456 423 177 456 minecraft:cracked_stone_bricks
fill 424 176 449 424 177 449 minecraft:iron_block
fill 424 176 451 424 177 451 minecraft:iron_block
fill 424 176 453 424 177 453 minecraft:iron_block
fill 424 176 455 424 177 455 minecraft:iron_block
fill 424 176 457 424 177 457 minecraft:iron_block
fill 425 176 448 425 177 448 minecraft:iron_block
fill 425 176 450 425 177 450 minecraft:iron_block
fill 425 176 452 425 177 452 minecraft:iron_block
fill 425 176 454 425 177 454 minecraft:iron_block
fill 425 176 456 425 177 456 minecraft:iron_block
fill 426 176 449 426 177 449 minecraft:iron_block
fill 426 176 451 426 177 451 minecraft:iron_block
fill 426 176 453 426 177 453 minecraft:iron_block
fill 426 176 455 426 177 455 minecraft:iron_block
fill 426 176 457 426 177 457 minecraft:iron_block
fill 427 176 448 427 177 448 minecraft:iron_block
fill 427 176 450 427 177 450 minecraft:iron_block
fill 427 176 452 427 177 452 minecraft:iron_block
fill 427 176 454 427 177 454 minecraft:iron_block
fill 427 176 456 427 177 456 minecraft:iron_block
setblock 428 176 437 minecraft:iron_bars
fill 428 176 449 428 177 449 minecraft:iron_block
fill 428 176 451 428 177 451 minecraft:iron_block
fill 428 176 453 428 177 453 minecraft:iron_block
fill 428 176 455 428 177 455 minecraft:iron_block
fill 428 176 457 428 177 457 minecraft:iron_block
fill 429 176 448 429 177 448 minecraft:iron_block
fill 429 176 450 429 177 450 minecraft:iron_block
fill 429 176 452 429 177 452 minecraft:iron_block
fill 429 176 454 429 177 454 minecraft:iron_block
fill 429 176 456 429 177 456 minecraft:iron_block
fill 430 176 449 430 177 449 minecraft:iron_block
fill 430 176 451 430 177 451 minecraft:iron_block
fill 430 176 453 430 177 453 minecraft:iron_block
fill 430 176 455 430 177 455 minecraft:iron_block
fill 430 176 457 430 177 457 minecraft:iron_block
fill 431 176 448 431 177 448 minecraft:iron_block
fill 431 176 450 431 177 450 minecraft:iron_block
fill 431 176 452 431 177 452 minecraft:iron_block
fill 431 176 454 431 177 454 minecraft:iron_block
fill 431 176 456 431 177 456 minecraft:iron_block
fill 432 176 449 432 177 449 minecraft:iron_block
fill 432 176 451 432 177 451 minecraft:iron_block
fill 432 176 453 432 177 453 minecraft:iron_block
fill 432 176 455 432 177 455 minecraft:iron_block
fill 432 176 457 432 177 457 minecraft:iron_block
fill 433 176 448 433 177 448 minecraft:iron_block
fill 433 176 450 433 177 450 minecraft:iron_block
fill 433 176 452 433 177 452 minecraft:iron_block
fill 433 176 454 433 177 454 minecraft:iron_block
fill 433 176 456 433 177 456 minecraft:iron_block
fill 436 176 428 436 176 429 minecraft:iron_block
fill 436 176 443 436 176 444 minecraft:iron_block
fill 449 176 448 449 177 448 minecraft:iron_block
fill 449 176 450 449 177 450 minecraft:iron_block
fill 449 176 452 449 177 452 minecraft:iron_block
fill 449 176 454 449 177 454 minecraft:iron_block
fill 449 176 456 449 177 456 minecraft:iron_block
fill 450 176 449 450 177 449 minecraft:iron_block
fill 450 176 451 450 177 451 minecraft:iron_block
fill 450 176 453 450 177 453 minecraft:iron_block
fill 450 176 455 450 177 455 minecraft:iron_block
fill 450 176 457 450 177 457 minecraft:iron_block
fill 451 176 428 452 176 428 minecraft:iron_block
fill 451 176 444 452 176 444 minecraft:iron_block
fill 451 176 448 451 177 448 minecraft:iron_block
fill 451 176 450 451 177 450 minecraft:iron_block
fill 451 176 452 451 177 452 minecraft:iron_block
fill 451 176 454 451 177 454 minecraft:iron_block
fill 451 176 456 451 177 456 minecraft:iron_block
fill 452 176 449 452 177 449 minecraft:iron_block
fill 452 176 451 452 177 451 minecraft:iron_block
fill 452 176 453 452 177 453 minecraft:iron_block
fill 452 176 455 452 177 455 minecraft:iron_block
fill 452 176 457 452 177 457 minecraft:iron_block
fill 453 176 448 453 177 448 minecraft:iron_block
fill 453 176 450 453 177 450 minecraft:iron_block
fill 453 176 452 453 177 452 minecraft:iron_block
fill 453 176 454 453 177 454 minecraft:iron_block
fill 453 176 456 453 177 456 minecraft:iron_block
fill 454 176 449 454 177 449 minecraft:iron_block
fill 454 176 451 454 177 451 minecraft:iron_block
fill 454 176 453 454 177 453 minecraft:iron_block
fill 454 176 455 454 177 455 minecraft:iron_block
fill 454 176 457 454 177 457 minecraft:iron_block
fill 455 176 448 455 177 448 minecraft:iron_block
fill 455 176 450 455 177 450 minecraft:iron_block
fill 455 176 452 455 177 452 minecraft:iron_block
fill 455 176 454 455 177 454 minecraft:iron_block
fill 455 176 456 455 177 456 minecraft:iron_block
fill 456 176 449 456 177 449 minecraft:iron_block
fill 456 176 451 456 177 451 minecraft:iron_block
fill 456 176 453 456 177 453 minecraft:iron_block
fill 456 176 455 456 177 455 minecraft:iron_block
fill 456 176 457 456 177 457 minecraft:iron_block
fill 457 176 448 457 177 448 minecraft:iron_block
fill 457 176 450 457 177 450 minecraft:iron_block
fill 457 176 452 457 177 452 minecraft:iron_block
fill 457 176 454 457 177 454 minecraft:iron_block
fill 457 176 456 457 177 456 minecraft:iron_block
fill 458 176 449 458 177 449 minecraft:iron_block
fill 458 176 451 458 177 451 minecraft:iron_block
fill 458 176 453 458 177 453 minecraft:iron_block
fill 458 176 455 458 177 455 minecraft:iron_block
fill 458 176 457 458 177 457 minecraft:iron_block
fill 459 176 448 459 177 448 minecraft:iron_block
fill 459 176 450 459 177 450 minecraft:iron_block
fill 459 176 452 459 177 452 minecraft:iron_block
fill 459 176 454 459 177 454 minecraft:iron_block
fill 459 176 456 459 177 456 minecraft:iron_block
fill 460 176 449 460 177 449 minecraft:iron_block
fill 460 176 451 460 177 451 minecraft:iron_block
fill 460 176 453 460 177 453 minecraft:iron_block
fill 460 176 455 460 177 455 minecraft:iron_block
fill 460 176 457 460 177 457 minecraft:iron_block
fill 461 176 448 461 177 448 minecraft:iron_block
fill 461 176 450 461 177 450 minecraft:iron_block
fill 461 176 452 461 177 452 minecraft:iron_block
fill 461 176 454 461 177 454 minecraft:iron_block
fill 461 176 456 461 177 456 minecraft:iron_block
fill 424 177 434 428 177 438 minecraft:cobblestone
fill 425 177 439 428 177 440 minecraft:cobblestone
setblock 423 178 448 minecraft:glowstone
setblock 423 178 450 minecraft:glowstone
setblock 423 178 452 minecraft:glowstone
setblock 423 178 454 minecraft:glowstone
setblock 423 178 456 minecraft:glowstone
fill 424 178 434 428 178 438 minecraft:iron_block
setblock 424 178 449 minecraft:glowstone
setblock 424 178 451 minecraft:glowstone
setblock 424 178 453 minecraft:glowstone
setblock 424 178 455 minecraft:glowstone
setblock 424 178 457 minecraft:glowstone
fill 425 178 439 428 178 440 minecraft:iron_block
fill 425 178 443 425 190 443 minecraft:iron_bars
setblock 425 178 448 minecraft:glowstone
setblock 425 178 450 minecraft:glowstone
setblock 425 178 452 minecraft:glowstone
setblock 425 178 454 minecraft:glowstone
setblock 425 178 456 minecraft:glowstone
setblock 426 178 419 minecraft:light[level=12]
setblock 426 178 427 minecraft:light[level=12]
setblock 426 178 443 minecraft:light[level=12]
setblock 426 178 449 minecraft:glowstone
setblock 426 178 451 minecraft:glowstone
setblock 426 178 453 minecraft:glowstone
setblock 426 178 455 minecraft:glowstone
setblock 426 178 457 minecraft:glowstone
setblock 427 178 448 minecraft:glowstone
setblock 427 178 450 minecraft:glowstone
setblock 427 178 452 minecraft:glowstone
setblock 427 178 454 minecraft:glowstone
setblock 427 178 456 minecraft:glowstone
setblock 428 178 449 minecraft:glowstone
setblock 428 178 451 minecraft:glowstone
setblock 428 178 453 minecraft:glowstone
setblock 428 178 455 minecraft:glowstone
setblock 428 178 457 minecraft:glowstone
setblock 429 178 448 minecraft:glowstone
setblock 429 178 450 minecraft:glowstone
setblock 429 178 452 minecraft:glowstone
setblock 429 178 454 minecraft:glowstone
setblock 429 178 456 minecraft:glowstone
setblock 430 178 449 minecraft:glowstone
setblock 430 178 451 minecraft:glowstone
setblock 430 178 453 minecraft:glowstone
setblock 430 178 455 minecraft:glowstone
setblock 430 178 457 minecraft:glowstone
setblock 431 178 448 minecraft:glowstone
setblock 431 178 450 minecraft:glowstone
setblock 431 178 452 minecraft:glowstone
setblock 431 178 454 minecraft:glowstone
setblock 431 178 456 minecraft:glowstone
setblock 432 178 449 minecraft:glowstone
setblock 432 178 451 minecraft:glowstone
setblock 432 178 453 minecraft:glowstone
setblock 432 178 455 minecraft:glowstone
setblock 432 178 457 minecraft:glowstone
setblock 433 178 448 minecraft:glowstone
setblock 433 178 450 minecraft:glowstone
setblock 433 178 452 minecraft:glowstone
setblock 433 178 454 minecraft:glowstone
setblock 433 178 456 minecraft:glowstone
setblock 434 178 419 minecraft:light[level=12]
setblock 434 178 427 minecraft:light[level=12]
setblock 434 178 435 minecraft:light[level=12]
setblock 434 178 443 minecraft:light[level=12]
setblock 434 178 451 minecraft:light[level=12]
setblock 442 178 419 minecraft:light[level=12]
setblock 442 178 427 minecraft:light[level=12]
setblock 442 178 435 minecraft:light[level=12]
setblock 442 178 443 minecraft:light[level=12]
setblock 442 178 451 minecraft:light[level=12]
setblock 449 178 448 minecraft:glowstone
setblock 449 178 450 minecraft:glowstone
setblock 449 178 452 minecraft:glowstone
setblock 449 178 454 minecraft:glowstone
setblock 449 178 456 minecraft:glowstone
setblock 450 178 419 minecraft:light[level=12]
setblock 450 178 427 minecraft:light[level=12]
setblock 450 178 435 minecraft:light[level=12]
setblock 450 178 443 minecraft:light[level=12]
setblock 450 178 449 minecraft:glowstone
setblock 450 178 451 minecraft:glowstone
setblock 450 178 453 minecraft:glowstone
setblock 450 178 455 minecraft:glowstone
setblock 450 178 457 minecraft:glowstone
setblock 451 178 448 minecraft:glowstone
setblock 451 178 450 minecraft:glowstone
setblock 451 178 452 minecraft:glowstone
setblock 451 178 454 minecraft:glowstone
setblock 451 178 456 minecraft:glowstone
setblock 452 178 449 minecraft:glowstone
setblock 452 178 451 minecraft:glowstone
setblock 452 178 453 minecraft:glowstone
setblock 452 178 455 minecraft:glowstone
setblock 452 178 457 minecraft:glowstone
setblock 453 178 448 minecraft:glowstone
setblock 453 178 450 minecraft:glowstone
setblock 453 178 452 minecraft:glowstone
setblock 453 178 454 minecraft:glowstone
setblock 453 178 456 minecraft:glowstone
setblock 454 178 449 minecraft:glowstone
setblock 454 178 451 minecraft:glowstone
setblock 454 178 453 minecraft:glowstone
setblock 454 178 455 minecraft:glowstone
setblock 454 178 457 minecraft:glowstone
setblock 455 178 448 minecraft:glowstone
setblock 455 178 450 minecraft:glowstone
setblock 455 178 452 minecraft:glowstone
setblock 455 178 454 minecraft:glowstone
setblock 455 178 456 minecraft:glowstone
setblock 456 178 449 minecraft:glowstone
setblock 456 178 451 minecraft:glowstone
setblock 456 178 453 minecraft:glowstone
setblock 456 178 455 minecraft:glowstone
setblock 456 178 457 minecraft:glowstone
setblock 457 178 448 minecraft:glowstone
setblock 457 178 450 minecraft:glowstone
setblock 457 178 452 minecraft:glowstone
setblock 457 178 454 minecraft:glowstone
setblock 457 178 456 minecraft:glowstone
setblock 458 178 419 minecraft:light[level=12]
setblock 458 178 427 minecraft:light[level=12]
setblock 458 178 435 minecraft:light[level=12]
setblock 458 178 443 minecraft:light[level=12]
setblock 458 178 449 minecraft:glowstone
setblock 458 178 451 minecraft:glowstone
setblock 458 178 453 minecraft:glowstone
setblock 458 178 455 minecraft:glowstone
setblock 458 178 457 minecraft:glowstone
setblock 459 178 448 minecraft:glowstone
setblock 459 178 450 minecraft:glowstone
setblock 459 178 452 minecraft:glowstone
setblock 459 178 454 minecraft:glowstone
setblock 459 178 456 minecraft:glowstone
setblock 460 178 449 minecraft:glowstone
setblock 460 178 451 minecraft:glowstone
setblock 460 178 453 minecraft:glowstone
setblock 460 178 455 minecraft:glowstone
setblock 460 178 457 minecraft:glowstone
setblock 461 178 448 minecraft:glowstone
setblock 461 178 450 minecraft:glowstone
setblock 461 178 452 minecraft:glowstone
setblock 461 178 454 minecraft:glowstone
setblock 461 178 456 minecraft:glowstone
fill 423 179 435 423 185 435 minecraft:cracked_stone_bricks
fill 423 179 436 423 182 438 minecraft:glowstone
fill 423 179 439 423 203 441 minecraft:cracked_stone_bricks
fill 423 179 448 423 180 448 minecraft:cracked_stone_bricks
fill 423 179 450 423 180 450 minecraft:cracked_stone_bricks
fill 423 179 452 423 180 452 minecraft:cracked_stone_bricks
fill 423 179 454 423 180 454 minecraft:cracked_stone_bricks
fill 423 179 456 423 180 456 minecraft:cracked_stone_bricks
fill 424 179 449 424 180 449 minecraft:iron_block
fill 424 179 451 424 180 451 minecraft:iron_block
fill 424 179 453 424 180 453 minecraft:iron_block
fill 424 179 455 424 180 455 minecraft:iron_block
fill 424 179 457 424 180 457 minecraft:iron_block
fill 425 179 448 425 180 448 minecraft:iron_block
fill 425 179 450 425 180 450 minecraft:iron_block
fill 425 179 452 425 180 452 minecraft:iron_block
fill 425 179 454 425 180 454 minecraft:iron_block
fill 425 179 456 425 180 456 minecraft:iron_block
fill 426 179 449 426 180 449 minecraft:iron_block
fill 426 179 451 426 180 451 minecraft:iron_block
fill 426 179 453 426 180 453 minecraft:iron_block
fill 426 179 455 426 180 455 minecraft:iron_block
fill 426 179 457 426 180 457 minecraft:iron_block
fill 427 179 448 427 180 448 minecraft:iron_block
fill 427 179 450 427 180 450 minecraft:iron_block
fill 427 179 452 427 180 452 minecraft:iron_block
fill 427 179 454 427 180 454 minecraft:iron_block
fill 427 179 456 427 180 456 minecraft:iron_block
fill 428 179 434 428 179 440 minecraft:gray_concrete
fill 428 179 449 428 180 449 minecraft:iron_block
fill 428 179 451 428 180 451 minecraft:iron_block
fill 428 179 453 428 180 453 minecraft:iron_block
fill 428 179 455 428 180 455 minecraft:iron_block
fill 428 179 457 428 180 457 minecraft:iron_block
fill 429 179 448 429 180 448 minecraft:iron_block
fill 429 179 450 429 180 450 minecraft:iron_block
fill 429 179 452 429 180 452 minecraft:iron_block
fill 429 179 454 429 180 454 minecraft:iron_block
fill 429 179 456 429 180 456 minecraft:iron_block
fill 430 179 449 430 180 449 minecraft:iron_block
fill 430 179 451 430 180 451 minecraft:iron_block
fill 430 179 453 430 180 453 minecraft:iron_block
fill 430 179 455 430 180 455 minecraft:iron_block
fill 430 179 457 430 180 457 minecraft:iron_block
fill 431 179 448 431 180 448 minecraft:iron_block
fill 431 179 450 431 180 450 minecraft:iron_block
fill 431 179 452 431 180 452 minecraft:iron_block
fill 431 179 454 431 180 454 minecraft:iron_block
fill 431 179 456 431 180 456 minecraft:iron_block
fill 432 179 449 432 180 449 minecraft:iron_block
fill 432 179 451 432 180 451 minecraft:iron_block
fill 432 179 453 432 180 453 minecraft:iron_block
fill 432 179 455 432 180 455 minecraft:iron_block
fill 432 179 457 432 180 457 minecraft:iron_block
fill 433 179 448 433 180 448 minecraft:iron_block
fill 433 179 450 433 180 450 minecraft:iron_block
fill 433 179 452 433 180 452 minecraft:iron_block
fill 433 179 454 433 180 454 minecraft:iron_block
fill 433 179 456 433 180 456 minecraft:iron_block
fill 449 179 448 449 180 448 minecraft:iron_block
fill 449 179 450 449 180 450 minecraft:iron_block
fill 449 179 452 449 180 452 minecraft:iron_block
fill 449 179 454 449 180 454 minecraft:iron_block
fill 449 179 456 449 180 456 minecraft:iron_block
fill 450 179 449 450 180 449 minecraft:iron_block
fill 450 179 451 450 180 451 minecraft:iron_block
fill 450 179 453 450 180 453 minecraft:iron_block
fill 450 179 455 450 180 455 minecraft:iron_block
fill 450 179 457 450 180 457 minecraft:iron_block
fill 451 179 448 451 180 448 minecraft:iron_block
fill 451 179 450 451 180 450 minecraft:iron_block
fill 451 179 452 451 180 452 minecraft:iron_block
fill 451 179 454 451 180 454 minecraft:iron_block
fill 451 179 456 451 180 456 minecraft:iron_block
fill 452 179 449 452 180 449 minecraft:iron_block
fill 452 179 451 452 180 451 minecraft:iron_block
fill 452 179 453 452 180 453 minecraft:iron_block
fill 452 179 455 452 180 455 minecraft:iron_block
fill 452 179 457 452 180 457 minecraft:iron_block
fill 453 179 448 453 180 448 minecraft:iron_block
fill 453 179 450 453 180 450 minecraft:iron_block
fill 453 179 452 453 180 452 minecraft:iron_block
fill 453 179 454 453 180 454 minecraft:iron_block
fill 453 179 456 453 180 456 minecraft:iron_block
fill 454 179 449 454 180 449 minecraft:iron_block
fill 454 179 451 454 180 451 minecraft:iron_block
fill 454 179 453 454 180 453 minecraft:iron_block
fill 454 179 455 454 180 455 minecraft:iron_block
fill 454 179 457 454 180 457 minecraft:iron_block
fill 455 179 448 455 180 448 minecraft:iron_block
fill 455 179 450 455 180 450 minecraft:iron_block
fill 455 179 452 455 180 452 minecraft:iron_block
fill 455 179 454 455 180 454 minecraft:iron_block
fill 455 179 456 455 180 456 minecraft:iron_block
fill 456 179 449 456 180 449 minecraft:iron_block
fill 456 179 451 456 180 451 minecraft:iron_block
fill 456 179 453 456 180 453 minecraft:iron_block
fill 456 179 455 456 180 455 minecraft:iron_block
fill 456 179 457 456 180 457 minecraft:iron_block
fill 457 179 448 457 180 448 minecraft:iron_block
fill 457 179 450 457 180 450 minecraft:iron_block
fill 457 179 452 457 180 452 minecraft:iron_block
fill 457 179 454 457 180 454 minecraft:iron_block
fill 457 179 456 457 180 456 minecraft:iron_block
fill 458 179 449 458 180 449 minecraft:iron_block
fill 458 179 451 458 180 451 minecraft:iron_block
fill 458 179 453 458 180 453 minecraft:iron_block
fill 458 179 455 458 180 455 minecraft:iron_block
fill 458 179 457 458 180 457 minecraft:iron_block
fill 459 179 448 459 180 448 minecraft:iron_block
fill 459 179 450 459 180 450 minecraft:iron_block
fill 459 179 452 459 180 452 minecraft:iron_block
fill 459 179 454 459 180 454 minecraft:iron_block
fill 459 179 456 459 180 456 minecraft:iron_block
fill 460 179 449 460 180 449 minecraft:iron_block
fill 460 179 451 460 180 451 minecraft:iron_block
fill 460 179 453 460 180 453 minecraft:iron_block
fill 460 179 455 460 180 455 minecraft:iron_block
fill 460 179 457 460 180 457 minecraft:iron_block
fill 461 179 448 461 180 448 minecraft:iron_block
fill 461 179 450 461 180 450 minecraft:iron_block
fill 461 179 452 461 180 452 minecraft:iron_block
fill 461 179 454 461 180 454 minecraft:iron_block
fill 461 179 456 461 180 456 minecraft:iron_block
fill 425 180 426 425 185 428 minecraft:iron_block
fill 425 180 438 425 185 440 minecraft:iron_block
setblock 428 180 434 minecraft:iron_block
setblock 428 180 437 minecraft:iron_block
setblock 428 180 440 minecraft:iron_block
fill 435 180 418 437 185 418 minecraft:iron_block
fill 443 180 456 445 185 456 minecraft:iron_block
fill 447 180 418 449 185 418 minecraft:iron_block
fill 459 180 418 461 185 418 minecraft:iron_block
fill 463 180 426 463 185 428 minecraft:iron_block
fill 463 180 438 463 185 440 minecraft:iron_block
fill 463 180 450 463 185 452 minecraft:iron_block
setblock 423 181 448 minecraft:glowstone
setblock 423 181 450 minecraft:glowstone
setblock 423 181 452 minecraft:glowstone
setblock 423 181 454 minecraft:glowstone
setblock 423 181 456 minecraft:glowstone
setblock 424 181 449 minecraft:glowstone
setblock 424 181 451 minecraft:glowstone
setblock 424 181 453 minecraft:glowstone
setblock 424 181 455 minecraft:glowstone
setblock 424 181 457 minecraft:glowstone
setblock 425 181 448 minecraft:glowstone
setblock 425 181 450 minecraft:glowstone
setblock 425 181 452 minecraft:glowstone
setblock 425 181 454 minecraft:glowstone
setblock 425 181 456 minecraft:glowstone
setblock 426 181 449 minecraft:glowstone
setblock 426 181 451 minecraft:glowstone
setblock 426 181 453 minecraft:glowstone
setblock 426 181 455 minecraft:glowstone
setblock 426 181 457 minecraft:glowstone
setblock 427 181 448 minecraft:glowstone
setblock 427 181 450 minecraft:glowstone
setblock 427 181 452 minecraft:glowstone
setblock 427 181 454 minecraft:glowstone
setblock 427 181 456 minecraft:glowstone
setblock 428 181 449 minecraft:glowstone
setblock 428 181 451 minecraft:glowstone
setblock 428 181 453 minecraft:glowstone
setblock 428 181 455 minecraft:glowstone
setblock 428 181 457 minecraft:glowstone
setblock 429 181 448 minecraft:glowstone
setblock 429 181 450 minecraft:glowstone
setblock 429 181 452 minecraft:glowstone
setblock 429 181 454 minecraft:glowstone
setblock 429 181 456 minecraft:glowstone
setblock 430 181 449 minecraft:glowstone
setblock 430 181 451 minecraft:glowstone
setblock 430 181 453 minecraft:glowstone
setblock 430 181 455 minecraft:glowstone
setblock 430 181 457 minecraft:glowstone
setblock 431 181 448 minecraft:glowstone
setblock 431 181 450 minecraft:glowstone
setblock 431 181 452 minecraft:glowstone
setblock 431 181 454 minecraft:glowstone
setblock 431 181 456 minecraft:glowstone
setblock 432 181 449 minecraft:glowstone
setblock 432 181 451 minecraft:glowstone
setblock 432 181 453 minecraft:glowstone
setblock 432 181 455 minecraft:glowstone
setblock 432 181 457 minecraft:glowstone
setblock 433 181 448 minecraft:glowstone
setblock 433 181 450 minecraft:glowstone
setblock 433 181 452 minecraft:glowstone
setblock 433 181 454 minecraft:glowstone
setblock 433 181 456 minecraft:glowstone
setblock 449 181 448 minecraft:glowstone
setblock 449 181 450 minecraft:glowstone
setblock 449 181 452 minecraft:glowstone
setblock 449 181 454 minecraft:glowstone
setblock 449 181 456 minecraft:glowstone
setblock 450 181 449 minecraft:glowstone
setblock 450 181 451 minecraft:glowstone
setblock 450 181 453 minecraft:glowstone
setblock 450 181 455 minecraft:glowstone
setblock 450 181 457 minecraft:glowstone
setblock 451 181 448 minecraft:glowstone
setblock 451 181 450 minecraft:glowstone
setblock 451 181 452 minecraft:glowstone
setblock 451 181 454 minecraft:glowstone
setblock 451 181 456 minecraft:glowstone
setblock 452 181 449 minecraft:glowstone
setblock 452 181 451 minecraft:glowstone
setblock 452 181 453 minecraft:glowstone
setblock 452 181 455 minecraft:glowstone
setblock 452 181 457 minecraft:glowstone
setblock 453 181 448 minecraft:glowstone
setblock 453 181 450 minecraft:glowstone
setblock 453 181 452 minecraft:glowstone
setblock 453 181 454 minecraft:glowstone
setblock 453 181 456 minecraft:glowstone
setblock 454 181 449 minecraft:glowstone
setblock 454 181 451 minecraft:glowstone
setblock 454 181 453 minecraft:glowstone
setblock 454 181 455 minecraft:glowstone
setblock 454 181 457 minecraft:glowstone
setblock 455 181 448 minecraft:glowstone
setblock 455 181 450 minecraft:glowstone
setblock 455 181 452 minecraft:glowstone
setblock 455 181 454 minecraft:glowstone
setblock 455 181 456 minecraft:glowstone
setblock 456 181 449 minecraft:glowstone
setblock 456 181 451 minecraft:glowstone
setblock 456 181 453 minecraft:glowstone
setblock 456 181 455 minecraft:glowstone
setblock 456 181 457 minecraft:glowstone
setblock 457 181 448 minecraft:glowstone
setblock 457 181 450 minecraft:glowstone
setblock 457 181 452 minecraft:glowstone
setblock 457 181 454 minecraft:glowstone
setblock 457 181 456 minecraft:glowstone
setblock 458 181 449 minecraft:glowstone
setblock 458 181 451 minecraft:glowstone
setblock 458 181 453 minecraft:glowstone
setblock 458 181 455 minecraft:glowstone
setblock 458 181 457 minecraft:glowstone
setblock 459 181 448 minecraft:glowstone
setblock 459 181 450 minecraft:glowstone
setblock 459 181 452 minecraft:glowstone
setblock 459 181 454 minecraft:glowstone
setblock 459 181 456 minecraft:glowstone
setblock 460 181 449 minecraft:glowstone
setblock 460 181 451 minecraft:glowstone
setblock 460 181 453 minecraft:glowstone
setblock 460 181 455 minecraft:glowstone
setblock 460 181 457 minecraft:glowstone
setblock 461 181 448 minecraft:glowstone
setblock 461 181 450 minecraft:glowstone
setblock 461 181 452 minecraft:glowstone
setblock 461 181 454 minecraft:glowstone
setblock 461 181 456 minecraft:glowstone
fill 423 182 448 423 183 448 minecraft:cracked_stone_bricks
fill 423 182 450 423 183 450 minecraft:cracked_stone_bricks
fill 423 182 452 423 183 452 minecraft:cracked_stone_bricks
fill 423 182 454 423 183 454 minecraft:cracked_stone_bricks
fill 423 182 456 423 183 456 minecraft:cracked_stone_bricks
fill 424 182 449 424 183 449 minecraft:iron_block
fill 424 182 451 424 183 451 minecraft:iron_block
fill 424 182 453 424 183 453 minecraft:iron_block
fill 424 182 455 424 183 455 minecraft:iron_block
fill 424 182 457 424 183 457 minecraft:iron_block
fill 425 182 448 425 183 448 minecraft:iron_block
fill 425 182 450 425 183 450 minecraft:iron_block
fill 425 182 452 425 183 452 minecraft:iron_block
fill 425 182 454 425 183 454 minecraft:iron_block
fill 425 182 456 425 183 456 minecraft:iron_block
fill 426 182 449 426 183 449 minecraft:iron_block
fill 426 182 451 426 183 451 minecraft:iron_block
fill 426 182 453 426 183 453 minecraft:iron_block
fill 426 182 455 426 183 455 minecraft:iron_block
fill 426 182 457 426 183 457 minecraft:iron_block
fill 427 182 448 427 183 448 minecraft:iron_block
fill 427 182 450 427 183 450 minecraft:iron_block
fill 427 182 452 427 183 452 minecraft:iron_block
fill 427 182 454 427 183 454 minecraft:iron_block
fill 427 182 456 427 183 456 minecraft:iron_block
fill 428 182 449 428 183 449 minecraft:iron_block
fill 428 182 451 428 183 451 minecraft:iron_block
fill 428 182 453 428 183 453 minecraft:iron_block
fill 428 182 455 428 183 455 minecraft:iron_block
fill 428 182 457 428 183 457 minecraft:iron_block
fill 429 182 448 429 183 448 minecraft:iron_block
fill 429 182 450 429 183 450 minecraft:iron_block
fill 429 182 452 429 183 452 minecraft:iron_block
fill 429 182 454 429 183 454 minecraft:iron_block
fill 429 182 456 429 183 456 minecraft:iron_block
fill 430 182 449 430 183 449 minecraft:iron_block
fill 430 182 451 430 183 451 minecraft:iron_block
fill 430 182 453 430 183 453 minecraft:iron_block
fill 430 182 455 430 183 455 minecraft:iron_block
fill 430 182 457 430 183 457 minecraft:iron_block
fill 431 182 448 431 183 448 minecraft:iron_block
fill 431 182 450 431 183 450 minecraft:iron_block
fill 431 182 452 431 183 452 minecraft:iron_block
fill 431 182 454 431 183 454 minecraft:iron_block
fill 431 182 456 431 183 456 minecraft:iron_block
fill 432 182 449 432 183 449 minecraft:iron_block
fill 432 182 451 432 183 451 minecraft:iron_block
fill 432 182 453 432 183 453 minecraft:iron_block
fill 432 182 455 432 183 455 minecraft:iron_block
fill 432 182 457 432 183 457 minecraft:iron_block
fill 433 182 448 433 183 448 minecraft:iron_block
fill 433 182 450 433 183 450 minecraft:iron_block
fill 433 182 452 433 183 452 minecraft:iron_block
fill 433 182 454 433 183 454 minecraft:iron_block
fill 433 182 456 433 183 456 minecraft:iron_block
fill 449 182 448 449 183 448 minecraft:iron_block
fill 449 182 450 449 183 450 minecraft:iron_block
fill 449 182 452 449 183 452 minecraft:iron_block
fill 449 182 454 449 183 454 minecraft:iron_block
fill 449 182 456 449 183 456 minecraft:iron_block
fill 450 182 449 450 183 449 minecraft:iron_block
fill 450 182 451 450 183 451 minecraft:iron_block
fill 450 182 453 450 183 453 minecraft:iron_block
fill 450 182 455 450 183 455 minecraft:iron_block
fill 450 182 457 450 183 457 minecraft:iron_block
fill 451 182 448 451 183 448 minecraft:iron_block
fill 451 182 450 451 183 450 minecraft:iron_block
fill 451 182 452 451 183 452 minecraft:iron_block
fill 451 182 454 451 183 454 minecraft:iron_block
fill 451 182 456 451 183 456 minecraft:iron_block
fill 452 182 449 452 183 449 minecraft:iron_block
fill 452 182 451 452 183 451 minecraft:iron_block
fill 452 182 453 452 183 453 minecraft:iron_block
fill 452 182 455 452 183 455 minecraft:iron_block
fill 452 182 457 452 183 457 minecraft:iron_block
fill 453 182 448 453 183 448 minecraft:iron_block
fill 453 182 450 453 183 450 minecraft:iron_block
fill 453 182 452 453 183 452 minecraft:iron_block
fill 453 182 454 453 183 454 minecraft:iron_block
fill 453 182 456 453 183 456 minecraft:iron_block
fill 454 182 449 454 183 449 minecraft:iron_block
fill 454 182 451 454 183 451 minecraft:iron_block
fill 454 182 453 454 183 453 minecraft:iron_block
fill 454 182 455 454 183 455 minecraft:iron_block
fill 454 182 457 454 183 457 minecraft:iron_block
fill 455 182 448 455 183 448 minecraft:iron_block
fill 455 182 450 455 183 450 minecraft:iron_block
fill 455 182 452 455 183 452 minecraft:iron_block
fill 455 182 454 455 183 454 minecraft:iron_block
fill 455 182 456 455 183 456 minecraft:iron_block
fill 456 182 449 456 183 449 minecraft:iron_block
fill 456 182 451 456 183 451 minecraft:iron_block
fill 456 182 453 456 183 453 minecraft:iron_block
fill 456 182 455 456 183 455 minecraft:iron_block
fill 456 182 457 456 183 457 minecraft:iron_block
fill 457 182 448 457 183 448 minecraft:iron_block
fill 457 182 450 457 183 450 minecraft:iron_block
fill 457 182 452 457 183 452 minecraft:iron_block
fill 457 182 454 457 183 454 minecraft:iron_block
fill 457 182 456 457 183 456 minecraft:iron_block
fill 458 182 449 458 183 449 minecraft:iron_block
fill 458 182 451 458 183 451 minecraft:iron_block
fill 458 182 453 458 183 453 minecraft:iron_block
fill 458 182 455 458 183 455 minecraft:iron_block
fill 458 182 457 458 183 457 minecraft:iron_block
fill 459 182 448 459 183 448 minecraft:iron_block
fill 459 182 450 459 183 450 minecraft:iron_block
fill 459 182 452 459 183 452 minecraft:iron_block
fill 459 182 454 459 183 454 minecraft:iron_block
fill 459 182 456 459 183 456 minecraft:iron_block
fill 460 182 449 460 183 449 minecraft:iron_block
fill 460 182 451 460 183 451 minecraft:iron_block
fill 460 182 453 460 183 453 minecraft:iron_block
fill 460 182 455 460 183 455 minecraft:iron_block
fill 460 182 457 460 183 457 minecraft:iron_block
fill 461 182 448 461 183 448 minecraft:iron_block
fill 461 182 450 461 183 450 minecraft:iron_block
fill 461 182 452 461 183 452 minecraft:iron_block
fill 461 182 454 461 183 454 minecraft:iron_block
fill 461 182 456 461 183 456 minecraft:iron_block
fill 423 183 436 423 185 438 minecraft:cracked_stone_bricks
setblock 423 184 448 minecraft:glowstone
setblock 423 184 450 minecraft:glowstone
setblock 423 184 452 minecraft:glowstone
setblock 423 184 454 minecraft:glowstone
setblock 423 184 456 minecraft:glowstone
setblock 424 184 449 minecraft:glowstone
setblock 424 184 451 minecraft:glowstone
setblock 424 184 453 minecraft:glowstone
setblock 424 184 455 minecraft:glowstone
setblock 424 184 457 minecraft:glowstone
setblock 425 184 448 minecraft:glowstone
setblock 425 184 450 minecraft:glowstone
setblock 425 184 452 minecraft:glowstone
setblock 425 184 454 minecraft:glowstone
setblock 425 184 456 minecraft:glowstone
setblock 426 184 449 minecraft:glowstone
setblock 426 184 451 minecraft:glowstone
setblock 426 184 453 minecraft:glowstone
setblock 426 184 455 minecraft:glowstone
setblock 426 184 457 minecraft:glowstone
setblock 427 184 448 minecraft:glowstone
setblock 427 184 450 minecraft:glowstone
setblock 427 184 452 minecraft:glowstone
setblock 427 184 454 minecraft:glowstone
setblock 427 184 456 minecraft:glowstone
setblock 428 184 449 minecraft:glowstone
setblock 428 184 451 minecraft:glowstone
setblock 428 184 453 minecraft:glowstone
setblock 428 184 455 minecraft:glowstone
setblock 428 184 457 minecraft:glowstone
setblock 429 184 448 minecraft:glowstone
setblock 429 184 450 minecraft:glowstone
setblock 429 184 452 minecraft:glowstone
setblock 429 184 454 minecraft:glowstone
setblock 429 184 456 minecraft:glowstone
setblock 430 184 449 minecraft:glowstone
setblock 430 184 451 minecraft:glowstone
setblock 430 184 453 minecraft:glowstone
setblock 430 184 455 minecraft:glowstone
setblock 430 184 457 minecraft:glowstone
setblock 431 184 448 minecraft:glowstone
setblock 431 184 450 minecraft:glowstone
setblock 431 184 452 minecraft:glowstone
setblock 431 184 454 minecraft:glowstone
setblock 431 184 456 minecraft:glowstone
setblock 432 184 449 minecraft:glowstone
setblock 432 184 451 minecraft:glowstone
setblock 432 184 453 minecraft:glowstone
setblock 432 184 455 minecraft:glowstone
setblock 432 184 457 minecraft:glowstone
setblock 433 184 448 minecraft:glowstone
setblock 433 184 450 minecraft:glowstone
setblock 433 184 452 minecraft:glowstone
setblock 433 184 454 minecraft:glowstone
setblock 433 184 456 minecraft:glowstone
setblock 449 184 448 minecraft:glowstone
setblock 449 184 450 minecraft:glowstone
setblock 449 184 452 minecraft:glowstone
setblock 449 184 454 minecraft:glowstone
setblock 449 184 456 minecraft:glowstone
setblock 450 184 449 minecraft:glowstone
setblock 450 184 451 minecraft:glowstone
setblock 450 184 453 minecraft:glowstone
setblock 450 184 455 minecraft:glowstone
setblock 450 184 457 minecraft:glowstone
setblock 451 184 448 minecraft:glowstone
setblock 451 184 450 minecraft:glowstone
setblock 451 184 452 minecraft:glowstone
setblock 451 184 454 minecraft:glowstone
setblock 451 184 456 minecraft:glowstone
setblock 452 184 449 minecraft:glowstone
setblock 452 184 451 minecraft:glowstone
setblock 452 184 453 minecraft:glowstone
setblock 452 184 455 minecraft:glowstone
setblock 452 184 457 minecraft:glowstone
setblock 453 184 448 minecraft:glowstone
setblock 453 184 450 minecraft:glowstone
setblock 453 184 452 minecraft:glowstone
setblock 453 184 454 minecraft:glowstone
setblock 453 184 456 minecraft:glowstone
setblock 454 184 449 minecraft:glowstone
setblock 454 184 451 minecraft:glowstone
setblock 454 184 453 minecraft:glowstone
setblock 454 184 455 minecraft:glowstone
setblock 454 184 457 minecraft:glowstone
setblock 455 184 448 minecraft:glowstone
setblock 455 184 450 minecraft:glowstone
setblock 455 184 452 minecraft:glowstone
setblock 455 184 454 minecraft:glowstone
setblock 455 184 456 minecraft:glowstone
setblock 456 184 449 minecraft:glowstone
setblock 456 184 451 minecraft:glowstone
setblock 456 184 453 minecraft:glowstone
setblock 456 184 455 minecraft:glowstone
setblock 456 184 457 minecraft:glowstone
setblock 457 184 448 minecraft:glowstone
setblock 457 184 450 minecraft:glowstone
setblock 457 184 452 minecraft:glowstone
setblock 457 184 454 minecraft:glowstone
setblock 457 184 456 minecraft:glowstone
setblock 458 184 449 minecraft:glowstone
setblock 458 184 451 minecraft:glowstone
setblock 458 184 453 minecraft:glowstone
setblock 458 184 455 minecraft:glowstone
setblock 458 184 457 minecraft:glowstone
setblock 459 184 448 minecraft:glowstone
setblock 459 184 450 minecraft:glowstone
setblock 459 184 452 minecraft:glowstone
setblock 459 184 454 minecraft:glowstone
setblock 459 184 456 minecraft:glowstone
setblock 460 184 449 minecraft:glowstone
setblock 460 184 451 minecraft:glowstone
setblock 460 184 453 minecraft:glowstone
setblock 460 184 455 minecraft:glowstone
setblock 460 184 457 minecraft:glowstone
setblock 461 184 448 minecraft:glowstone
setblock 461 184 450 minecraft:glowstone
setblock 461 184 452 minecraft:glowstone
setblock 461 184 454 minecraft:glowstone
setblock 461 184 456 minecraft:glowstone
setblock 423 185 448 minecraft:cracked_stone_bricks
fill 423 185 450 423 186 450 minecraft:cracked_stone_bricks
fill 423 185 452 423 186 452 minecraft:cracked_stone_bricks
fill 423 185 454 423 186 454 minecraft:cracked_stone_bricks
fill 423 185 456 423 186 456 minecraft:cracked_stone_bricks
fill 424 185 420 424 185 425 minecraft:cobblestone
fill 424 185 432 424 185 437 minecraft:cobblestone
fill 424 185 444 424 185 449 minecraft:cobblestone
fill 424 185 451 424 186 451 minecraft:iron_block
fill 424 185 453 424 186 453 minecraft:iron_block
fill 424 185 455 424 186 455 minecraft:iron_block
fill 424 185 456 424 185 457 minecraft:cobblestone
fill 425 185 448 425 186 448 minecraft:iron_block
fill 425 185 450 425 186 450 minecraft:iron_block
fill 425 185 452 425 186 452 minecraft:iron_block
fill 425 185 454 425 186 454 minecraft:iron_block
fill 425 185 456 425 186 456 minecraft:iron_block
fill 425 185 457 428 185 457 minecraft:cobblestone
fill 426 185 449 426 186 449 minecraft:iron_block
fill 426 185 451 426 186 451 minecraft:iron_block
fill 426 185 453 426 186 453 minecraft:iron_block
fill 426 185 455 426 186 455 minecraft:iron_block
fill 427 185 448 427 186 448 minecraft:iron_block
fill 427 185 450 427 186 450 minecraft:iron_block
fill 427 185 452 427 186 452 minecraft:iron_block
fill 427 185 454 427 186 454 minecraft:iron_block
fill 427 185 456 427 186 456 minecraft:iron_block
fill 428 185 417 433 185 417 minecraft:cobblestone
fill 428 185 449 428 186 449 minecraft:iron_block
fill 428 185 451 428 186 451 minecraft:iron_block
fill 428 185 453 428 186 453 minecraft:iron_block
fill 428 185 455 428 186 455 minecraft:iron_block
fill 429 185 448 429 186 448 minecraft:iron_block
fill 429 185 450 429 186 450 minecraft:iron_block
fill 429 185 452 429 186 452 minecraft:iron_block
fill 429 185 454 429 186 454 minecraft:iron_block
fill 429 185 456 429 186 456 minecraft:iron_block
fill 430 185 449 430 186 449 minecraft:iron_block
fill 430 185 451 430 186 451 minecraft:iron_block
fill 430 185 453 430 186 453 minecraft:iron_block
fill 430 185 455 430 186 455 minecraft:iron_block
fill 430 185 457 430 186 457 minecraft:iron_block
fill 431 185 448 431 186 448 minecraft:iron_block
fill 431 185 450 431 186 450 minecraft:iron_block
fill 431 185 452 431 186 452 minecraft:iron_block
fill 431 185 454 431 186 454 minecraft:iron_block
fill 431 185 456 431 186 456 minecraft:iron_block
fill 432 185 449 432 186 449 minecraft:iron_block
fill 432 185 451 432 186 451 minecraft:iron_block
fill 432 185 453 432 186 453 minecraft:iron_block
fill 432 185 455 432 186 455 minecraft:iron_block
fill 432 185 457 432 186 457 minecraft:iron_block
fill 433 185 448 433 186 448 minecraft:iron_block
fill 433 185 450 433 186 450 minecraft:iron_block
fill 433 185 452 433 186 452 minecraft:iron_block
fill 433 185 454 433 186 454 minecraft:iron_block
fill 433 185 456 433 186 456 minecraft:iron_block
fill 435 185 457 440 185 457 minecraft:cobblestone
fill 440 185 417 445 185 417 minecraft:cobblestone
fill 447 185 457 452 185 457 minecraft:cobblestone
fill 449 185 448 449 186 448 minecraft:iron_block
fill 449 185 450 449 186 450 minecraft:iron_block
fill 449 185 452 449 186 452 minecraft:iron_block
fill 449 185 454 449 186 454 minecraft:iron_block
fill 449 185 456 449 186 456 minecraft:iron_block
fill 450 185 449 450 186 449 minecraft:iron_block
fill 450 185 451 450 186 451 minecraft:iron_block
fill 450 185 453 450 186 453 minecraft:iron_block
fill 450 185 455 450 186 455 minecraft:iron_block
fill 451 185 448 451 186 448 minecraft:iron_block
fill 451 185 450 451 186 450 minecraft:iron_block
fill 451 185 452 451 186 452 minecraft:iron_block
fill 451 185 454 451 186 454 minecraft:iron_block
fill 451 185 456 451 186 456 minecraft:iron_block
fill 452 185 417 457 185 417 minecraft:cobblestone
fill 452 185 449 452 186 449 minecraft:iron_block
fill 452 185 451 452 186 451 minecraft:iron_block
fill 452 185 453 452 186 453 minecraft:iron_block
fill 452 185 455 452 186 455 minecraft:iron_block
fill 453 185 448 453 186 448 minecraft:iron_block
fill 453 185 450 453 186 450 minecraft:iron_block
fill 453 185 452 453 186 452 minecraft:iron_block
fill 453 185 454 453 186 454 minecraft:iron_block
fill 453 185 456 453 186 456 minecraft:iron_block
fill 454 185 449 454 186 449 minecraft:iron_block
fill 454 185 451 454 186 451 minecraft:iron_block
fill 454 185 453 454 186 453 minecraft:iron_block
fill 454 185 455 454 186 455 minecraft:iron_block
fill 454 185 457 454 186 457 minecraft:iron_block
fill 455 185 448 455 186 448 minecraft:iron_block
fill 455 185 450 455 186 450 minecraft:iron_block
fill 455 185 452 455 186 452 minecraft:iron_block
fill 455 185 454 455 186 454 minecraft:iron_block
fill 455 185 456 455 186 456 minecraft:iron_block
fill 456 185 449 456 186 449 minecraft:iron_block
fill 456 185 451 456 186 451 minecraft:iron_block
fill 456 185 453 456 186 453 minecraft:iron_block
fill 456 185 455 456 186 455 minecraft:iron_block
fill 456 185 457 456 186 457 minecraft:iron_block
fill 457 185 448 457 186 448 minecraft:iron_block
fill 457 185 450 457 186 450 minecraft:iron_block
fill 457 185 452 457 186 452 minecraft:iron_block
fill 457 185 454 457 186 454 minecraft:iron_block
fill 457 185 456 457 186 456 minecraft:iron_block
fill 458 185 449 458 186 449 minecraft:iron_block
fill 458 185 451 458 186 451 minecraft:iron_block
fill 458 185 453 458 186 453 minecraft:iron_block
fill 458 185 455 458 186 455 minecraft:iron_block
fill 458 185 457 458 186 457 minecraft:iron_block
fill 459 185 448 459 186 448 minecraft:iron_block
fill 459 185 450 459 186 450 minecraft:iron_block
fill 459 185 452 459 186 452 minecraft:iron_block
fill 459 185 454 459 186 454 minecraft:iron_block
fill 459 185 456 459 186 456 minecraft:iron_block
fill 459 185 457 464 185 457 minecraft:cobblestone
fill 460 185 449 460 186 449 minecraft:iron_block
fill 460 185 451 460 186 451 minecraft:iron_block
fill 460 185 453 460 186 453 minecraft:iron_block
fill 460 185 455 460 186 455 minecraft:iron_block
fill 461 185 448 461 186 448 minecraft:iron_block
fill 461 185 450 461 186 450 minecraft:iron_block
fill 461 185 452 461 186 452 minecraft:iron_block
fill 461 185 454 461 186 454 minecraft:iron_block
fill 461 185 456 461 186 456 minecraft:iron_block
fill 464 185 417 464 185 422 minecraft:cobblestone
fill 464 185 429 464 185 434 minecraft:cobblestone
fill 464 185 441 464 185 446 minecraft:cobblestone
fill 464 185 453 464 185 456 minecraft:cobblestone
fill 423 186 422 423 191 425 minecraft:glowstone
fill 423 186 434 423 191 437 minecraft:glowstone
fill 423 186 438 423 207 438 minecraft:cracked_stone_bricks
fill 423 186 446 423 191 449 minecraft:glowstone
fill 423 186 458 426 191 458 minecraft:glowstone
fill 424 186 448 424 186 449 minecraft:iron_block
fill 424 186 456 424 186 457 minecraft:iron_block
fill 425 186 457 428 186 457 minecraft:iron_block
setblock 426 186 419 minecraft:light[level=12]
setblock 426 186 427 minecraft:light[level=12]
setblock 426 186 435 minecraft:light[level=12]
setblock 426 186 443 minecraft:light[level=12]
fill 430 186 416 433 191 416 minecraft:glowstone
setblock 434 186 419 minecraft:light[level=12]
setblock 434 186 427 minecraft:light[level=12]
setblock 434 186 435 minecraft:light[level=12]
setblock 434 186 443 minecraft:light[level=12]
setblock 434 186 451 minecraft:light[level=12]
fill 435 186 458 438 191 458 minecraft:glowstone
fill 442 186 416 445 191 416 minecraft:glowstone
setblock 442 186 419 minecraft:light[level=12]
setblock 442 186 427 minecraft:light[level=12]
setblock 442 186 435 minecraft:light[level=12]
setblock 442 186 443 minecraft:light[level=12]
setblock 442 186 451 minecraft:light[level=12]
fill 447 186 458 450 191 458 minecraft:glowstone
fill 449 186 457 452 186 457 minecraft:iron_block
setblock 450 186 419 minecraft:light[level=12]
setblock 450 186 427 minecraft:light[level=12]
setblock 450 186 435 minecraft:light[level=12]
setblock 450 186 443 minecraft:light[level=12]
fill 454 186 416 457 191 416 minecraft:glowstone
setblock 458 186 419 minecraft:light[level=12]
setblock 458 186 427 minecraft:light[level=12]
setblock 458 186 435 minecraft:light[level=12]
setblock 458 186 443 minecraft:light[level=12]
fill 459 186 457 461 186 457 minecraft:iron_block
fill 459 186 458 462 191 458 minecraft:glowstone
fill 465 186 417 465 191 420 minecraft:glowstone
fill 465 186 429 465 191 432 minecraft:glowstone
fill 465 186 441 465 191 444 minecraft:glowstone
fill 465 186 453 465 191 456 minecraft:glowstone
setblock 423 187 450 minecraft:glowstone
setblock 423 187 452 minecraft:glowstone
setblock 423 187 454 minecraft:glowstone
setblock 423 187 456 minecraft:glowstone
fill 424 187 448 424 189 448 minecraft:iron_block
setblock 424 187 449 minecraft:glowstone
setblock 424 187 451 minecraft:glowstone
setblock 424 187 453 minecraft:glowstone
setblock 424 187 455 minecraft:glowstone
fill 424 187 456 424 189 456 minecraft:iron_block
setblock 424 187 457 minecraft:glowstone
setblock 425 187 448 minecraft:glowstone
setblock 425 187 450 minecraft:glowstone
setblock 425 187 452 minecraft:glowstone
setblock 425 187 454 minecraft:glowstone
setblock 425 187 456 minecraft:glowstone
fill 425 187 457 425 189 457 minecraft:iron_block
setblock 426 187 449 minecraft:glowstone
setblock 426 187 451 minecraft:glowstone
setblock 426 187 453 minecraft:glowstone
setblock 426 187 455 minecraft:glowstone
setblock 426 187 457 minecraft:glowstone
setblock 427 187 448 minecraft:glowstone
setblock 427 187 450 minecraft:glowstone
setblock 427 187 452 minecraft:glowstone
setblock 427 187 454 minecraft:glowstone
setblock 427 187 456 minecraft:glowstone
fill 427 187 457 427 189 457 minecraft:iron_block
setblock 428 187 449 minecraft:glowstone
setblock 428 187 451 minecraft:glowstone
setblock 428 187 453 minecraft:glowstone
setblock 428 187 455 minecraft:glowstone
setblock 428 187 457 minecraft:glowstone
setblock 429 187 448 minecraft:glowstone
setblock 429 187 450 minecraft:glowstone
setblock 429 187 452 minecraft:glowstone
setblock 429 187 454 minecraft:glowstone
setblock 429 187 456 minecraft:glowstone
setblock 430 187 449 minecraft:glowstone
setblock 430 187 451 minecraft:glowstone
setblock 430 187 453 minecraft:glowstone
setblock 430 187 455 minecraft:glowstone
setblock 430 187 457 minecraft:glowstone
setblock 431 187 448 minecraft:glowstone
setblock 431 187 450 minecraft:glowstone
setblock 431 187 452 minecraft:glowstone
setblock 431 187 454 minecraft:glowstone
setblock 431 187 456 minecraft:glowstone
setblock 432 187 449 minecraft:glowstone
setblock 432 187 451 minecraft:glowstone
setblock 432 187 453 minecraft:glowstone
setblock 432 187 455 minecraft:glowstone
setblock 432 187 457 minecraft:glowstone
setblock 433 187 448 minecraft:glowstone
setblock 433 187 450 minecraft:glowstone
setblock 433 187 452 minecraft:glowstone
setblock 433 187 454 minecraft:glowstone
setblock 433 187 456 minecraft:glowstone
setblock 449 187 448 minecraft:glowstone
setblock 449 187 450 minecraft:glowstone
setblock 449 187 452 minecraft:glowstone
setblock 449 187 454 minecraft:glowstone
setblock 449 187 456 minecraft:glowstone
fill 449 187 457 449 199 457 minecraft:iron_block
setblock 450 187 449 minecraft:glowstone
setblock 450 187 451 minecraft:glowstone
setblock 450 187 453 minecraft:glowstone
setblock 450 187 455 minecraft:glowstone
setblock 450 187 457 minecraft:glowstone
setblock 451 187 448 minecraft:glowstone
setblock 451 187 450 minecraft:glowstone
setblock 451 187 452 minecraft:glowstone
setblock 451 187 454 minecraft:glowstone
setblock 451 187 456 minecraft:glowstone
fill 451 187 457 451 199 457 minecraft:iron_block
setblock 452 187 449 minecraft:glowstone
setblock 452 187 451 minecraft:glowstone
setblock 452 187 453 minecraft:glowstone
setblock 452 187 455 minecraft:glowstone
setblock 452 187 457 minecraft:glowstone
setblock 453 187 448 minecraft:glowstone
setblock 453 187 450 minecraft:glowstone
setblock 453 187 452 minecraft:glowstone
setblock 453 187 454 minecraft:glowstone
setblock 453 187 456 minecraft:glowstone
setblock 454 187 449 minecraft:glowstone
setblock 454 187 451 minecraft:glowstone
setblock 454 187 453 minecraft:glowstone
setblock 454 187 455 minecraft:glowstone
setblock 454 187 457 minecraft:glowstone
setblock 455 187 448 minecraft:glowstone
setblock 455 187 450 minecraft:glowstone
setblock 455 187 452 minecraft:glowstone
setblock 455 187 454 minecraft:glowstone
setblock 455 187 456 minecraft:glowstone
setblock 456 187 449 minecraft:glowstone
setblock 456 187 451 minecraft:glowstone
setblock 456 187 453 minecraft:glowstone
setblock 456 187 455 minecraft:glowstone
setblock 456 187 457 minecraft:glowstone
setblock 457 187 448 minecraft:glowstone
setblock 457 187 450 minecraft:glowstone
setblock 457 187 452 minecraft:glowstone
setblock 457 187 454 minecraft:glowstone
setblock 457 187 456 minecraft:glowstone
setblock 458 187 449 minecraft:glowstone
setblock 458 187 451 minecraft:glowstone
setblock 458 187 453 minecraft:glowstone
setblock 458 187 455 minecraft:glowstone
setblock 458 187 457 minecraft:glowstone
setblock 459 187 448 minecraft:glowstone
setblock 459 187 450 minecraft:glowstone
setblock 459 187 452 minecraft:glowstone
setblock 459 187 454 minecraft:glowstone
setblock 459 187 456 minecraft:glowstone
fill 459 187 457 459 199 457 minecraft:iron_block
setblock 460 187 449 minecraft:glowstone
setblock 460 187 451 minecraft:glowstone
setblock 460 187 453 minecraft:glowstone
setblock 460 187 455 minecraft:glowstone
setblock 460 187 457 minecraft:glowstone
setblock 461 187 448 minecraft:glowstone
setblock 461 187 450 minecraft:glowstone
setblock 461 187 452 minecraft:glowstone
setblock 461 187 454 minecraft:glowstone
setblock 461 187 456 minecraft:glowstone
fill 461 187 457 461 199 457 minecraft:iron_block
fill 423 188 450 423 207 450 minecraft:cracked_stone_bricks
fill 423 188 452 423 203 452 minecraft:cracked_stone_bricks
fill 423 188 454 423 208 454 minecraft:cracked_stone_bricks
fill 423 188 456 423 207 456 minecraft:cracked_stone_bricks
fill 424 188 449 424 189 449 minecraft:iron_block
fill 424 188 451 424 225 451 minecraft:iron_block
fill 424 188 453 424 225 453 minecraft:iron_block
fill 424 188 455 424 189 455 minecraft:iron_block
fill 424 188 457 424 189 457 minecraft:iron_block
fill 425 188 448 425 189 448 minecraft:iron_block
fill 425 188 450 425 189 450 minecraft:iron_block
fill 425 188 452 425 189 452 minecraft:iron_block
fill 425 188 454 425 189 454 minecraft:iron_block
fill 425 188 456 425 189 456 minecraft:iron_block
fill 426 188 449 426 189 449 minecraft:iron_block
fill 426 188 451 426 189 451 minecraft:iron_block
fill 426 188 453 426 189 453 minecraft:iron_block
fill 426 188 455 426 189 455 minecraft:iron_block
fill 426 188 457 426 189 457 minecraft:iron_block
fill 427 188 448 427 189 448 minecraft:iron_block
fill 427 188 450 427 189 450 minecraft:iron_block
fill 427 188 452 427 189 452 minecraft:iron_block
fill 427 188 454 427 189 454 minecraft:iron_block
fill 427 188 456 427 189 456 minecraft:iron_block
fill 428 188 449 428 189 449 minecraft:iron_block
fill 428 188 451 428 189 451 minecraft:iron_block
fill 428 188 453 428 189 453 minecraft:iron_block
fill 428 188 455 428 189 455 minecraft:iron_block
fill 428 188 457 428 189 457 minecraft:iron_block
fill 429 188 448 429 189 448 minecraft:iron_block
fill 429 188 450 429 189 450 minecraft:iron_block
fill 429 188 452 429 189 452 minecraft:iron_block
fill 429 188 454 429 189 454 minecraft:iron_block
fill 429 188 456 429 189 456 minecraft:iron_block
fill 430 188 449 430 189 449 minecraft:iron_block
fill 430 188 451 430 189 451 minecraft:iron_block
fill 430 188 453 430 189 453 minecraft:iron_block
fill 430 188 455 430 189 455 minecraft:iron_block
fill 430 188 457 430 225 457 minecraft:iron_block
fill 431 188 448 431 189 448 minecraft:iron_block
fill 431 188 450 431 189 450 minecraft:iron_block
fill 431 188 452 431 189 452 minecraft:iron_block
fill 431 188 454 431 189 454 minecraft:iron_block
fill 431 188 456 431 189 456 minecraft:iron_block
fill 432 188 449 432 189 449 minecraft:iron_block
fill 432 188 451 432 189 451 minecraft:iron_block
fill 432 188 453 432 189 453 minecraft:iron_block
fill 432 188 455 432 189 455 minecraft:iron_block
fill 432 188 457 432 225 457 minecraft:iron_block
fill 433 188 448 433 189 448 minecraft:iron_block
fill 433 188 450 433 189 450 minecraft:iron_block
fill 433 188 452 433 189 452 minecraft:iron_block
fill 433 188 454 433 189 454 minecraft:iron_block
fill 433 188 456 433 189 456 minecraft:iron_block
fill 449 188 448 449 189 448 minecraft:iron_block
fill 449 188 450 449 189 450 minecraft:iron_block
fill 449 188 452 449 189 452 minecraft:iron_block
fill 449 188 454 449 189 454 minecraft:iron_block
fill 449 188 456 449 189 456 minecraft:iron_block
fill 450 188 449 450 189 449 minecraft:iron_block
fill 450 188 451 450 189 451 minecraft:iron_block
fill 450 188 453 450 189 453 minecraft:iron_block
fill 450 188 455 450 189 455 minecraft:iron_block
fill 450 188 457 450 189 457 minecraft:iron_block
fill 451 188 448 451 189 448 minecraft:iron_block
fill 451 188 450 451 189 450 minecraft:iron_block
fill 451 188 452 451 189 452 minecraft:iron_block
fill 451 188 454 451 189 454 minecraft:iron_block
fill 451 188 456 451 189 456 minecraft:iron_block
fill 452 188 449 452 189 449 minecraft:iron_block
fill 452 188 451 452 189 451 minecraft:iron_block
fill 452 188 453 452 189 453 minecraft:iron_block
fill 452 188 455 452 189 455 minecraft:iron_block
fill 452 188 457 452 189 457 minecraft:iron_block
fill 453 188 448 453 189 448 minecraft:iron_block
fill 453 188 450 453 189 450 minecraft:iron_block
fill 453 188 452 453 189 452 minecraft:iron_block
fill 453 188 454 453 189 454 minecraft:iron_block
fill 453 188 456 453 189 456 minecraft:iron_block
fill 454 188 449 454 189 449 minecraft:iron_block
fill 454 188 451 454 189 451 minecraft:iron_block
fill 454 188 453 454 189 453 minecraft:iron_block
fill 454 188 455 454 189 455 minecraft:iron_block
fill 454 188 457 454 189 457 minecraft:iron_block
fill 455 188 448 455 189 448 minecraft:iron_block
fill 455 188 450 455 189 450 minecraft:iron_block
fill 455 188 452 455 189 452 minecraft:iron_block
fill 455 188 454 455 189 454 minecraft:iron_block
fill 455 188 456 455 189 456 minecraft:iron_block
fill 456 188 449 456 189 449 minecraft:iron_block
fill 456 188 451 456 189 451 minecraft:iron_block
fill 456 188 453 456 189 453 minecraft:iron_block
fill 456 188 455 456 189 455 minecraft:iron_block
fill 456 188 457 456 189 457 minecraft:iron_block
fill 457 188 448 457 189 448 minecraft:iron_block
fill 457 188 450 457 189 450 minecraft:iron_block
fill 457 188 452 457 189 452 minecraft:iron_block
fill 457 188 454 457 189 454 minecraft:iron_block
fill 457 188 456 457 189 456 minecraft:iron_block
fill 458 188 449 458 189 449 minecraft:iron_block
fill 458 188 451 458 189 451 minecraft:iron_block
fill 458 188 453 458 189 453 minecraft:iron_block
fill 458 188 455 458 189 455 minecraft:iron_block
fill 458 188 457 458 189 457 minecraft:iron_block
fill 459 188 448 459 189 448 minecraft:iron_block
fill 459 188 450 459 189 450 minecraft:iron_block
fill 459 188 452 459 189 452 minecraft:iron_block
fill 459 188 454 459 189 454 minecraft:iron_block
fill 459 188 456 459 189 456 minecraft:iron_block
fill 460 188 449 460 189 449 minecraft:iron_block
fill 460 188 451 460 189 451 minecraft:iron_block
fill 460 188 453 460 189 453 minecraft:iron_block
fill 460 188 455 460 189 455 minecraft:iron_block
fill 460 188 457 460 189 457 minecraft:iron_block
fill 461 188 448 461 189 448 minecraft:iron_block
fill 461 188 450 461 189 450 minecraft:iron_block
fill 461 188 452 461 189 452 minecraft:iron_block
fill 461 188 454 461 189 454 minecraft:iron_block
fill 461 188 456 461 189 456 minecraft:iron_block
fill 433 190 453 433 200 453 minecraft:iron_bars
setblock 449 190 448 minecraft:glowstone
setblock 449 190 450 minecraft:glowstone
setblock 449 190 452 minecraft:glowstone
setblock 449 190 454 minecraft:glowstone
setblock 449 190 456 minecraft:glowstone
setblock 450 190 449 minecraft:glowstone
setblock 450 190 451 minecraft:glowstone
setblock 450 190 453 minecraft:glowstone
setblock 450 190 455 minecraft:glowstone
setblock 450 190 457 minecraft:glowstone
setblock 451 190 448 minecraft:glowstone
setblock 451 190 450 minecraft:glowstone
setblock 451 190 452 minecraft:glowstone
setblock 451 190 454 minecraft:glowstone
setblock 451 190 456 minecraft:glowstone
setblock 452 190 449 minecraft:glowstone
setblock 452 190 451 minecraft:glowstone
setblock 452 190 453 minecraft:glowstone
setblock 452 190 455 minecraft:glowstone
setblock 452 190 457 minecraft:glowstone
setblock 453 190 448 minecraft:glowstone
setblock 453 190 450 minecraft:glowstone
setblock 453 190 452 minecraft:glowstone
setblock 453 190 454 minecraft:glowstone
setblock 453 190 456 minecraft:glowstone
setblock 454 190 449 minecraft:glowstone
setblock 454 190 451 minecraft:glowstone
setblock 454 190 453 minecraft:glowstone
setblock 454 190 455 minecraft:glowstone
setblock 454 190 457 minecraft:glowstone
setblock 455 190 448 minecraft:glowstone
setblock 455 190 450 minecraft:glowstone
setblock 455 190 452 minecraft:glowstone
setblock 455 190 454 minecraft:glowstone
setblock 455 190 456 minecraft:glowstone
setblock 456 190 449 minecraft:glowstone
setblock 456 190 451 minecraft:glowstone
setblock 456 190 453 minecraft:glowstone
setblock 456 190 455 minecraft:glowstone
setblock 456 190 457 minecraft:glowstone
setblock 457 190 448 minecraft:glowstone
setblock 457 190 450 minecraft:glowstone
setblock 457 190 452 minecraft:glowstone
setblock 457 190 454 minecraft:glowstone
setblock 457 190 456 minecraft:glowstone
setblock 458 190 449 minecraft:glowstone
setblock 458 190 451 minecraft:glowstone
setblock 458 190 453 minecraft:glowstone
setblock 458 190 455 minecraft:glowstone
setblock 458 190 457 minecraft:glowstone
setblock 459 190 448 minecraft:glowstone
setblock 459 190 450 minecraft:glowstone
setblock 459 190 452 minecraft:glowstone
setblock 459 190 454 minecraft:glowstone
setblock 459 190 456 minecraft:glowstone
setblock 460 190 449 minecraft:glowstone
setblock 460 190 451 minecraft:glowstone
setblock 460 190 453 minecraft:glowstone
setblock 460 190 455 minecraft:glowstone
setblock 460 190 457 minecraft:glowstone
setblock 461 190 448 minecraft:glowstone
setblock 461 190 450 minecraft:glowstone
setblock 461 190 452 minecraft:glowstone
setblock 461 190 454 minecraft:glowstone
setblock 461 190 456 minecraft:glowstone
fill 449 191 448 449 192 448 minecraft:iron_block
fill 449 191 450 449 192 450 minecraft:iron_block
fill 449 191 452 449 192 452 minecraft:iron_block
fill 449 191 454 449 192 454 minecraft:iron_block
fill 449 191 456 449 192 456 minecraft:iron_block
fill 450 191 449 450 192 449 minecraft:iron_block
fill 450 191 451 450 192 451 minecraft:iron_block
fill 450 191 453 450 192 453 minecraft:iron_block
fill 450 191 455 450 192 455 minecraft:iron_block
fill 450 191 457 450 192 457 minecraft:iron_block
fill 451 191 448 451 192 448 minecraft:iron_block
fill 451 191 450 451 192 450 minecraft:iron_block
fill 451 191 452 451 192 452 minecraft:iron_block
fill 451 191 454 451 192 454 minecraft:iron_block
fill 451 191 456 451 192 456 minecraft:iron_block
fill 452 191 449 452 192 449 minecraft:iron_block
fill 452 191 451 452 192 451 minecraft:iron_block
fill 452 191 453 452 192 453 minecraft:iron_block
fill 452 191 455 452 192 455 minecraft:iron_block
fill 452 191 457 452 192 457 minecraft:iron_block
fill 453 191 448 453 192 448 minecraft:iron_block
fill 453 191 450 453 192 450 minecraft:iron_block
fill 453 191 452 453 192 452 minecraft:iron_block
fill 453 191 454 453 192 454 minecraft:iron_block
fill 453 191 456 453 192 456 minecraft:iron_block
fill 454 191 449 454 192 449 minecraft:iron_block
fill 454 191 451 454 192 451 minecraft:iron_block
fill 454 191 453 454 192 453 minecraft:iron_block
fill 454 191 455 454 192 455 minecraft:iron_block
fill 454 191 457 454 192 457 minecraft:iron_block
fill 455 191 448 455 192 448 minecraft:iron_block
fill 455 191 450 455 192 450 minecraft:iron_block
fill 455 191 452 455 192 452 minecraft:iron_block
fill 455 191 454 455 192 454 minecraft:iron_block
fill 455 191 456 455 192 456 minecraft:iron_block
fill 456 191 449 456 192 449 minecraft:iron_block
fill 456 191 451 456 192 451 minecraft:iron_block
fill 456 191 453 456 192 453 minecraft:iron_block
fill 456 191 455 456 192 455 minecraft:iron_block
fill 456 191 457 456 192 457 minecraft:iron_block
fill 457 191 448 457 192 448 minecraft:iron_block
fill 457 191 450 457 192 450 minecraft:iron_block
fill 457 191 452 457 192 452 minecraft:iron_block
fill 457 191 454 457 192 454 minecraft:iron_block
fill 457 191 456 457 192 456 minecraft:iron_block
fill 458 191 449 458 192 449 minecraft:iron_block
fill 458 191 451 458 192 451 minecraft:iron_block
fill 458 191 453 458 192 453 minecraft:iron_block
fill 458 191 455 458 192 455 minecraft:iron_block
fill 458 191 457 458 192 457 minecraft:iron_block
fill 459 191 448 459 192 448 minecraft:iron_block
fill 459 191 450 459 192 450 minecraft:iron_block
fill 459 191 452 459 192 452 minecraft:iron_block
fill 459 191 454 459 192 454 minecraft:iron_block
fill 459 191 456 459 192 456 minecraft:iron_block
fill 460 191 449 460 192 449 minecraft:iron_block
fill 460 191 451 460 192 451 minecraft:iron_block
fill 460 191 453 460 192 453 minecraft:iron_block
fill 460 191 455 460 192 455 minecraft:iron_block
fill 460 191 457 460 192 457 minecraft:iron_block
fill 461 191 448 461 192 448 minecraft:iron_block
fill 461 191 450 461 192 450 minecraft:iron_block
fill 461 191 452 461 192 452 minecraft:iron_block
fill 461 191 454 461 192 454 minecraft:iron_block
fill 461 191 456 461 192 456 minecraft:iron_block
fill 423 192 422 423 203 422 minecraft:cracked_stone_bricks
fill 423 192 423 423 192 424 minecraft:glowstone
fill 423 192 425 423 205 425 minecraft:cracked_stone_bricks
fill 423 192 434 423 205 434 minecraft:cracked_stone_bricks
fill 423 192 435 423 192 436 minecraft:glowstone
fill 423 192 437 423 205 437 minecraft:cracked_stone_bricks
fill 423 192 446 423 205 446 minecraft:cracked_stone_bricks
fill 423 192 447 423 192 448 minecraft:glowstone
fill 423 192 449 423 205 449 minecraft:cracked_stone_bricks
fill 423 192 458 423 203 458 minecraft:cracked_stone_bricks
fill 424 192 458 425 192 458 minecraft:glowstone
fill 426 192 458 426 205 458 minecraft:cracked_stone_bricks
fill 430 192 416 430 205 416 minecraft:cracked_stone_bricks
fill 431 192 416 432 192 416 minecraft:glowstone
fill 433 192 416 433 205 416 minecraft:cracked_stone_bricks
fill 435 192 458 435 205 458 minecraft:cracked_stone_bricks
fill 436 192 458 437 192 458 minecraft:glowstone
fill 438 192 458 438 205 458 minecraft:cracked_stone_bricks
fill 442 192 416 442 205 416 minecraft:cracked_stone_bricks
fill 443 192 416 444 192 416 minecraft:glowstone
fill 445 192 416 445 205 416 minecraft:cracked_stone_bricks
fill 447 192 458 447 205 458 minecraft:cracked_stone_bricks
fill 448 192 458 449 192 458 minecraft:glowstone
fill 450 192 458 450 205 458 minecraft:cracked_stone_bricks
fill 454 192 416 454 205 416 minecraft:cracked_stone_bricks
fill 455 192 416 456 192 416 minecraft:glowstone
fill 457 192 416 457 205 416 minecraft:cracked_stone_bricks
fill 459 192 458 459 205 458 minecraft:cracked_stone_bricks
fill 460 192 458 461 192 458 minecraft:glowstone
fill 462 192 458 462 203 458 minecraft:cracked_stone_bricks
fill 465 192 417 465 205 417 minecraft:cracked_stone_bricks
fill 465 192 418 465 192 419 minecraft:glowstone
fill 465 192 420 465 205 420 minecraft:cracked_stone_bricks
fill 465 192 429 465 205 429 minecraft:cracked_stone_bricks
fill 465 192 430 465 192 431 minecraft:glowstone
fill 465 192 432 465 205 432 minecraft:cracked_stone_bricks
fill 465 192 441 465 205 441 minecraft:cracked_stone_bricks
fill 465 192 442 465 192 443 minecraft:glowstone
fill 465 192 444 465 203 444 minecraft:cracked_stone_bricks
fill 465 192 453 465 205 453 minecraft:cracked_stone_bricks
fill 465 192 454 465 192 455 minecraft:glowstone
fill 465 192 456 465 204 456 minecraft:cracked_stone_bricks
fill 423 193 423 423 205 424 minecraft:cracked_stone_bricks
fill 423 193 435 423 204 436 minecraft:cracked_stone_bricks
fill 423 193 447 423 205 448 minecraft:cracked_stone_bricks
fill 424 193 458 425 205 458 minecraft:cracked_stone_bricks
fill 431 193 416 432 205 416 minecraft:cracked_stone_bricks
fill 436 193 458 437 204 458 minecraft:cracked_stone_bricks
fill 443 193 416 444 205 416 minecraft:cracked_stone_bricks
fill 448 193 458 449 205 458 minecraft:cracked_stone_bricks
setblock 449 193 448 minecraft:glowstone
setblock 449 193 450 minecraft:glowstone
setblock 449 193 452 minecraft:glowstone
setblock 449 193 454 minecraft:glowstone
setblock 449 193 456 minecraft:glowstone
setblock 450 193 449 minecraft:glowstone
setblock 450 193 451 minecraft:glowstone
setblock 450 193 453 minecraft:glowstone
setblock 450 193 455 minecraft:glowstone
setblock 450 193 457 minecraft:glowstone
setblock 451 193 448 minecraft:glowstone
setblock 451 193 450 minecraft:glowstone
setblock 451 193 452 minecraft:glowstone
setblock 451 193 454 minecraft:glowstone
setblock 451 193 456 minecraft:glowstone
setblock 452 193 449 minecraft:glowstone
setblock 452 193 451 minecraft:glowstone
setblock 452 193 453 minecraft:glowstone
setblock 452 193 455 minecraft:glowstone
setblock 452 193 457 minecraft:glowstone
setblock 453 193 448 minecraft:glowstone
setblock 453 193 450 minecraft:glowstone
setblock 453 193 452 minecraft:glowstone
setblock 453 193 454 minecraft:glowstone
setblock 453 193 456 minecraft:glowstone
setblock 454 193 449 minecraft:glowstone
setblock 454 193 451 minecraft:glowstone
setblock 454 193 453 minecraft:glowstone
setblock 454 193 455 minecraft:glowstone
setblock 454 193 457 minecraft:glowstone
fill 455 193 416 456 205 416 minecraft:cracked_stone_bricks
setblock 455 193 448 minecraft:glowstone
setblock 455 193 450 minecraft:glowstone
setblock 455 193 452 minecraft:glowstone
setblock 455 193 454 minecraft:glowstone
setblock 455 193 456 minecraft:glowstone
setblock 456 193 449 minecraft:glowstone
setblock 456 193 451 minecraft:glowstone
setblock 456 193 453 minecraft:glowstone
setblock 456 193 455 minecraft:glowstone
setblock 456 193 457 minecraft:glowstone
setblock 457 193 448 minecraft:glowstone
setblock 457 193 450 minecraft:glowstone
setblock 457 193 452 minecraft:glowstone
setblock 457 193 454 minecraft:glowstone
setblock 457 193 456 minecraft:glowstone
setblock 458 193 449 minecraft:glowstone
setblock 458 193 451 minecraft:glowstone
setblock 458 193 453 minecraft:glowstone
setblock 458 193 455 minecraft:glowstone
setblock 458 193 457 minecraft:glowstone
setblock 459 193 448 minecraft:glowstone
setblock 459 193 450 minecraft:glowstone
setblock 459 193 452 minecraft:glowstone
setblock 459 193 454 minecraft:glowstone
setblock 459 193 456 minecraft:glowstone
setblock 460 193 449 minecraft:glowstone
setblock 460 193 451 minecraft:glowstone
setblock 460 193 453 minecraft:glowstone
setblock 460 193 455 minecraft:glowstone
setblock 460 193 457 minecraft:glowstone
fill 460 193 458 461 205 458 minecraft:cracked_stone_bricks
setblock 461 193 448 minecraft:glowstone
setblock 461 193 450 minecraft:glowstone
setblock 461 193 452 minecraft:glowstone
setblock 461 193 454 minecraft:glowstone
setblock 461 193 456 minecraft:glowstone
fill 465 193 418 465 205 419 minecraft:cracked_stone_bricks
fill 465 193 430 465 205 431 minecraft:cracked_stone_bricks
fill 465 193 442 465 203 443 minecraft:cracked_stone_bricks
fill 465 193 454 465 204 455 minecraft:cracked_stone_bricks
setblock 426 194 419 minecraft:light[level=12]
setblock 426 194 427 minecraft:light[level=12]
setblock 426 194 435 minecraft:light[level=12]
setblock 426 194 443 minecraft:light[level=12]
setblock 426 194 451 minecraft:light[level=12]
setblock 434 194 419 minecraft:light[level=12]
setblock 434 194 427 minecraft:light[level=12]
setblock 434 194 435 minecraft:light[level=12]
setblock 434 194 443 minecraft:light[level=12]
setblock 434 194 451 minecraft:light[level=12]
setblock 442 194 419 minecraft:light[level=12]
setblock 442 194 427 minecraft:light[level=12]
setblock 442 194 435 minecraft:light[level=12]
setblock 442 194 443 minecraft:light[level=12]
setblock 442 194 451 minecraft:light[level=12]
fill 449 194 448 449 195 448 minecraft:iron_block
fill 449 194 450 449 195 450 minecraft:iron_block
fill 449 194 452 449 195 452 minecraft:iron_block
fill 449 194 454 449 195 454 minecraft:iron_block
fill 449 194 456 449 195 456 minecraft:iron_block
setblock 450 194 419 minecraft:light[level=12]
setblock 450 194 427 minecraft:light[level=12]
setblock 450 194 435 minecraft:light[level=12]
setblock 450 194 443 minecraft:light[level=12]
fill 450 194 449 450 195 449 minecraft:iron_block
fill 450 194 451 450 195 451 minecraft:iron_block
fill 450 194 453 450 195 453 minecraft:iron_block
fill 450 194 455 450 195 455 minecraft:iron_block
fill 450 194 457 450 195 457 minecraft:iron_block
fill 451 194 448 451 195 448 minecraft:iron_block
fill 451 194 450 451 195 450 minecraft:iron_block
fill 451 194 452 451 195 452 minecraft:iron_block
fill 451 194 454 451 195 454 minecraft:iron_block
fill 451 194 456 451 195 456 minecraft:iron_block
fill 452 194 449 452 195 449 minecraft:iron_block
fill 452 194 451 452 195 451 minecraft:iron_block
fill 452 194 453 452 195 453 minecraft:iron_block
fill 452 194 455 452 195 455 minecraft:iron_block
fill 452 194 457 452 195 457 minecraft:iron_block
fill 453 194 448 453 195 448 minecraft:iron_block
fill 453 194 450 453 195 450 minecraft:iron_block
fill 453 194 452 453 195 452 minecraft:iron_block
fill 453 194 454 453 195 454 minecraft:iron_block
fill 453 194 456 453 195 456 minecraft:iron_block
fill 454 194 449 454 195 449 minecraft:iron_block
fill 454 194 451 454 195 451 minecraft:iron_block
fill 454 194 453 454 195 453 minecraft:iron_block
fill 454 194 455 454 195 455 minecraft:iron_block
fill 454 194 457 454 195 457 minecraft:iron_block
fill 455 194 448 455 195 448 minecraft:iron_block
fill 455 194 450 455 195 450 minecraft:iron_block
fill 455 194 452 455 195 452 minecraft:iron_block
fill 455 194 454 455 195 454 minecraft:iron_block
fill 455 194 456 455 195 456 minecraft:iron_block
fill 456 194 449 456 195 449 minecraft:iron_block
fill 456 194 451 456 195 451 minecraft:iron_block
fill 456 194 453 456 195 453 minecraft:iron_block
fill 456 194 455 456 195 455 minecraft:iron_block
fill 456 194 457 456 195 457 minecraft:iron_block
fill 457 194 448 457 195 448 minecraft:iron_block
fill 457 194 450 457 195 450 minecraft:iron_block
fill 457 194 452 457 195 452 minecraft:iron_block
fill 457 194 454 457 195 454 minecraft:iron_block
fill 457 194 456 457 195 456 minecraft:iron_block
setblock 458 194 419 minecraft:light[level=12]
setblock 458 194 427 minecraft:light[level=12]
setblock 458 194 435 minecraft:light[level=12]
setblock 458 194 443 minecraft:light[level=12]
fill 458 194 449 458 195 449 minecraft:iron_block
fill 458 194 451 458 195 451 minecraft:iron_block
fill 458 194 453 458 195 453 minecraft:iron_block
fill 458 194 455 458 195 455 minecraft:iron_block
fill 458 194 457 458 195 457 minecraft:iron_block
fill 459 194 448 459 195 448 minecraft:iron_block
fill 459 194 450 459 195 450 minecraft:iron_block
fill 459 194 452 459 195 452 minecraft:iron_block
fill 459 194 454 459 195 454 minecraft:iron_block
fill 459 194 456 459 195 456 minecraft:iron_block
fill 460 194 449 460 195 449 minecraft:iron_block
fill 460 194 451 460 195 451 minecraft:iron_block
fill 460 194 453 460 195 453 minecraft:iron_block
fill 460 194 455 460 195 455 minecraft:iron_block
fill 460 194 457 460 195 457 minecraft:iron_block
fill 461 194 448 461 195 448 minecraft:iron_block
fill 461 194 450 461 195 450 minecraft:iron_block
fill 461 194 452 461 195 452 minecraft:iron_block
fill 461 194 454 461 195 454 minecraft:iron_block
fill 461 194 456 461 195 456 minecraft:iron_block
setblock 449 196 448 minecraft:glowstone
setblock 449 196 450 minecraft:glowstone
setblock 449 196 452 minecraft:glowstone
setblock 449 196 454 minecraft:glowstone
setblock 449 196 456 minecraft:glowstone
setblock 450 196 449 minecraft:glowstone
setblock 450 196 451 minecraft:glowstone
setblock 450 196 453 minecraft:glowstone
setblock 450 196 455 minecraft:glowstone
setblock 450 196 457 minecraft:glowstone
setblock 451 196 448 minecraft:glowstone
setblock 451 196 450 minecraft:glowstone
setblock 451 196 452 minecraft:glowstone
setblock 451 196 454 minecraft:glowstone
setblock 451 196 456 minecraft:glowstone
setblock 452 196 449 minecraft:glowstone
setblock 452 196 451 minecraft:glowstone
setblock 452 196 453 minecraft:glowstone
setblock 452 196 455 minecraft:glowstone
setblock 452 196 457 minecraft:glowstone
setblock 453 196 448 minecraft:glowstone
setblock 453 196 450 minecraft:glowstone
setblock 453 196 452 minecraft:glowstone
setblock 453 196 454 minecraft:glowstone
setblock 453 196 456 minecraft:glowstone
setblock 454 196 449 minecraft:glowstone
setblock 454 196 451 minecraft:glowstone
setblock 454 196 453 minecraft:glowstone
setblock 454 196 455 minecraft:glowstone
setblock 454 196 457 minecraft:glowstone
setblock 455 196 448 minecraft:glowstone
setblock 455 196 450 minecraft:glowstone
setblock 455 196 452 minecraft:glowstone
setblock 455 196 454 minecraft:glowstone
setblock 455 196 456 minecraft:glowstone
setblock 456 196 449 minecraft:glowstone
setblock 456 196 451 minecraft:glowstone
setblock 456 196 453 minecraft:glowstone
setblock 456 196 455 minecraft:glowstone
setblock 456 196 457 minecraft:glowstone
setblock 457 196 448 minecraft:glowstone
setblock 457 196 450 minecraft:glowstone
setblock 457 196 452 minecraft:glowstone
setblock 457 196 454 minecraft:glowstone
setblock 457 196 456 minecraft:glowstone
setblock 458 196 449 minecraft:glowstone
setblock 458 196 451 minecraft:glowstone
setblock 458 196 453 minecraft:glowstone
setblock 458 196 455 minecraft:glowstone
setblock 458 196 457 minecraft:glowstone
setblock 459 196 448 minecraft:glowstone
setblock 459 196 450 minecraft:glowstone
setblock 459 196 452 minecraft:glowstone
setblock 459 196 454 minecraft:glowstone
setblock 459 196 456 minecraft:glowstone
setblock 460 196 449 minecraft:glowstone
setblock 460 196 451 minecraft:glowstone
setblock 460 196 453 minecraft:glowstone
setblock 460 196 455 minecraft:glowstone
setblock 460 196 457 minecraft:glowstone
setblock 461 196 448 minecraft:glowstone
setblock 461 196 450 minecraft:glowstone
setblock 461 196 452 minecraft:glowstone
setblock 461 196 454 minecraft:glowstone
setblock 461 196 456 minecraft:glowstone
fill 449 197 448 449 199 448 minecraft:iron_block
fill 449 197 450 449 199 450 minecraft:iron_block
fill 449 197 452 449 199 452 minecraft:iron_block
fill 449 197 454 449 199 454 minecraft:iron_block
fill 449 197 456 449 199 456 minecraft:iron_block
fill 450 197 449 450 199 449 minecraft:iron_block
fill 450 197 451 450 199 451 minecraft:iron_block
fill 450 197 453 450 199 453 minecraft:iron_block
fill 450 197 455 450 199 455 minecraft:iron_block
fill 450 197 457 450 199 457 minecraft:iron_block
fill 451 197 448 451 199 448 minecraft:iron_block
fill 451 197 450 451 199 450 minecraft:iron_block
fill 451 197 452 451 199 452 minecraft:iron_block
fill 451 197 454 451 199 454 minecraft:iron_block
fill 451 197 456 451 199 456 minecraft:iron_block
fill 452 197 449 452 199 449 minecraft:iron_block
fill 452 197 451 452 199 451 minecraft:iron_block
fill 452 197 453 452 199 453 minecraft:iron_block
fill 452 197 455 452 199 455 minecraft:iron_block
fill 452 197 457 452 199 457 minecraft:iron_block
fill 453 197 448 453 199 448 minecraft:iron_block
fill 453 197 450 453 199 450 minecraft:iron_block
fill 453 197 452 453 199 452 minecraft:iron_block
fill 453 197 454 453 199 454 minecraft:iron_block
fill 453 197 456 453 199 456 minecraft:iron_block
fill 454 197 449 454 199 449 minecraft:iron_block
fill 454 197 451 454 199 451 minecraft:iron_block
fill 454 197 453 454 199 453 minecraft:iron_block
fill 454 197 455 454 199 455 minecraft:iron_block
fill 454 197 457 454 225 457 minecraft:iron_block
fill 455 197 448 455 199 448 minecraft:iron_block
fill 455 197 450 455 199 450 minecraft:iron_block
fill 455 197 452 455 199 452 minecraft:iron_block
fill 455 197 454 455 199 454 minecraft:iron_block
fill 455 197 456 455 205 456 minecraft:iron_block
fill 456 197 449 456 199 449 minecraft:iron_block
fill 456 197 451 456 199 451 minecraft:iron_block
fill 456 197 453 456 199 453 minecraft:iron_block
fill 456 197 455 456 199 455 minecraft:iron_block
fill 456 197 457 456 225 457 minecraft:iron_block
fill 457 197 448 457 199 448 minecraft:iron_block
fill 457 197 450 457 199 450 minecraft:iron_block
fill 457 197 452 457 199 452 minecraft:iron_block
fill 457 197 454 457 199 454 minecraft:iron_block
fill 457 197 456 457 205 456 minecraft:iron_block
fill 458 197 449 458 199 449 minecraft:iron_block
fill 458 197 451 458 199 451 minecraft:iron_block
fill 458 197 453 458 199 453 minecraft:iron_block
fill 458 197 455 458 199 455 minecraft:iron_block
fill 458 197 457 458 199 457 minecraft:iron_block
fill 459 197 448 459 199 448 minecraft:iron_block
fill 459 197 450 459 199 450 minecraft:iron_block
fill 459 197 452 459 199 452 minecraft:iron_block
fill 459 197 454 459 199 454 minecraft:iron_block
fill 459 197 456 459 199 456 minecraft:iron_block
fill 460 197 449 460 199 449 minecraft:iron_block
fill 460 197 451 460 199 451 minecraft:iron_block
fill 460 197 453 460 199 453 minecraft:iron_block
fill 460 197 455 460 199 455 minecraft:iron_block
fill 460 197 457 460 199 457 minecraft:iron_block
fill 461 197 448 461 199 448 minecraft:iron_block
fill 461 197 450 461 199 450 minecraft:iron_block
fill 461 197 452 461 199 452 minecraft:iron_block
fill 461 197 454 461 199 454 minecraft:iron_block
fill 461 197 456 461 199 456 minecraft:iron_block
fill 425 200 426 425 205 428 minecraft:iron_block
fill 425 200 438 425 205 440 minecraft:iron_block
fill 425 200 450 425 205 452 minecraft:iron_block
fill 431 200 456 433 205 456 minecraft:iron_block
fill 435 200 418 437 205 418 minecraft:iron_block
fill 443 200 456 445 205 456 minecraft:iron_block
fill 447 200 418 449 205 418 minecraft:iron_block
fill 459 200 418 461 205 418 minecraft:iron_block
fill 463 200 426 463 205 428 minecraft:iron_block
fill 463 200 438 463 205 440 minecraft:iron_block
fill 463 200 450 463 205 452 minecraft:iron_block
setblock 426 202 419 minecraft:light[level=12]
setblock 426 202 427 minecraft:light[level=12]
setblock 426 202 435 minecraft:light[level=12]
setblock 426 202 443 minecraft:light[level=12]
setblock 426 202 451 minecraft:light[level=12]
setblock 434 202 419 minecraft:light[level=12]
setblock 434 202 427 minecraft:light[level=12]
setblock 434 202 435 minecraft:light[level=12]
setblock 434 202 443 minecraft:light[level=12]
setblock 434 202 451 minecraft:light[level=12]
setblock 442 202 419 minecraft:light[level=12]
setblock 442 202 427 minecraft:light[level=12]
setblock 442 202 435 minecraft:light[level=12]
setblock 442 202 443 minecraft:light[level=12]
setblock 442 202 451 minecraft:light[level=12]
setblock 450 202 419 minecraft:light[level=12]
setblock 450 202 427 minecraft:light[level=12]
setblock 450 202 435 minecraft:light[level=12]
setblock 450 202 443 minecraft:light[level=12]
setblock 450 202 451 minecraft:light[level=12]
setblock 458 202 419 minecraft:light[level=12]
setblock 458 202 427 minecraft:light[level=12]
setblock 458 202 435 minecraft:light[level=12]
setblock 458 202 443 minecraft:light[level=12]
setblock 458 202 451 minecraft:light[level=12]
fill 423 204 419 423 207 419 minecraft:cracked_stone_bricks
fill 423 204 420 423 205 420 minecraft:stone_bricks
fill 423 204 421 423 207 421 minecraft:cracked_stone_bricks
setblock 423 204 422 minecraft:stone_bricks
setblock 423 204 429 minecraft:stone_bricks
fill 423 204 430 423 205 432 minecraft:cracked_stone_bricks
fill 423 204 439 423 207 439 minecraft:cracked_stone_bricks
setblock 423 204 440 minecraft:stone_bricks
fill 423 204 441 423 207 441 minecraft:cracked_stone_bricks
setblock 423 204 452 minecraft:stone_bricks
setblock 423 204 458 minecraft:stone_bricks
fill 434 204 416 436 205 416 minecraft:cracked_stone_bricks
setblock 437 204 416 minecraft:stone_bricks
fill 438 204 416 440 207 416 minecraft:cracked_stone_bricks
setblock 441 204 416 minecraft:stone_bricks
fill 444 204 458 444 205 458 minecraft:stone_bricks
setblock 446 204 458 minecraft:stone_bricks
fill 455 204 458 457 205 458 minecraft:cracked_stone_bricks
setblock 458 204 458 minecraft:stone_bricks
setblock 462 204 458 minecraft:stone_bricks
fill 465 204 421 465 205 423 minecraft:cracked_stone_bricks
setblock 465 204 424 minecraft:stone_bricks
fill 465 204 425 465 207 425 minecraft:cracked_stone_bricks
fill 465 204 427 465 204 428 minecraft:stone_bricks
fill 465 204 442 465 205 442 minecraft:cracked_stone_bricks
fill 465 204 443 465 204 444 minecraft:stone_bricks
fill 465 204 458 465 205 458 minecraft:stone_bricks
setblock 423 205 422 minecraft:cracked_stone_bricks
fill 423 205 429 423 207 429 minecraft:cracked_stone_bricks
setblock 423 205 435 minecraft:cracked_stone_bricks
setblock 423 205 436 minecraft:stone_bricks
fill 423 205 440 423 207 440 minecraft:cracked_stone_bricks
fill 423 205 443 423 207 443 minecraft:cracked_stone_bricks
setblock 423 205 444 minecraft:stone_bricks
fill 423 205 445 423 207 445 minecraft:cracked_stone_bricks
fill 423 205 452 423 207 452 minecraft:cracked_stone_bricks
setblock 423 205 455 minecraft:stone_bricks
setblock 423 205 458 minecraft:cracked_stone_bricks
fill 424 205 416 426 207 416 minecraft:cracked_stone_bricks
fill 424 205 420 424 205 425 minecraft:cobblestone
fill 424 205 432 424 205 437 minecraft:cobblestone
fill 424 205 444 424 205 449 minecraft:cobblestone
fill 424 205 456 424 205 457 minecraft:cobblestone
fill 425 205 457 428 205 457 minecraft:cobblestone
fill 427 205 416 427 206 416 minecraft:stone_bricks
setblock 427 205 458 minecraft:stone_bricks
fill 428 205 416 428 207 416 minecraft:cracked_stone_bricks
fill 428 205 417 433 205 417 minecraft:cobblestone
fill 429 205 416 429 206 416 minecraft:stone_bricks
fill 435 205 457 440 205 457 minecraft:cobblestone
setblock 436 205 458 minecraft:stone_bricks
fill 437 205 416 437 207 416 minecraft:cracked_stone_bricks
setblock 437 205 458 minecraft:cracked_stone_bricks
fill 440 205 417 445 205 417 minecraft:cobblestone
fill 441 205 416 441 207 416 minecraft:cracked_stone_bricks
setblock 446 205 416 minecraft:stone_bricks
fill 446 205 458 446 207 458 minecraft:cracked_stone_bricks
fill 447 205 457 452 205 457 minecraft:cobblestone
fill 452 205 417 457 205 417 minecraft:cobblestone
fill 458 205 458 458 207 458 minecraft:cracked_stone_bricks
fill 459 205 457 464 205 457 minecraft:cobblestone
setblock 462 205 458 minecraft:cracked_stone_bricks
fill 464 205 417 464 205 422 minecraft:cobblestone
fill 464 205 429 464 205 434 minecraft:cobblestone
fill 464 205 441 464 205 446 minecraft:cobblestone
fill 464 205 453 464 205 456 minecraft:cobblestone
setblock 464 205 458 minecraft:stone_bricks
fill 465 205 424 465 207 424 minecraft:cracked_stone_bricks
fill 465 205 427 465 208 428 minecraft:cracked_stone_bricks
fill 465 205 443 465 205 444 minecraft:cracked_stone_bricks
setblock 465 205 446 minecraft:stone_bricks
fill 465 205 454 465 205 456 minecraft:stone_bricks
fill 423 206 420 423 208 420 minecraft:cracked_stone_bricks
fill 423 206 422 423 211 425 minecraft:glowstone
fill 423 206 430 423 206 431 minecraft:stone_bricks
fill 423 206 432 423 207 432 minecraft:cracked_stone_bricks
fill 423 206 434 423 211 437 minecraft:glowstone
fill 423 206 444 423 207 444 minecraft:cracked_stone_bricks
fill 423 206 446 423 211 449 minecraft:glowstone
fill 423 206 455 423 207 455 minecraft:cracked_stone_bricks
setblock 423 206 457 minecraft:stone_bricks
fill 423 206 458 426 211 458 minecraft:glowstone
fill 427 206 458 427 207 458 minecraft:cracked_stone_bricks
setblock 428 206 458 minecraft:stone_bricks
fill 429 206 458 432 207 458 minecraft:cracked_stone_bricks
fill 430 206 416 433 211 416 minecraft:glowstone
setblock 434 206 416 minecraft:stone_bricks
fill 435 206 416 436 207 416 minecraft:cracked_stone_bricks
fill 435 206 458 438 211 458 minecraft:glowstone
fill 442 206 416 445 211 416 minecraft:glowstone
fill 444 206 458 444 207 458 minecraft:cracked_stone_bricks
fill 446 206 416 446 208 416 minecraft:cracked_stone_bricks
fill 447 206 458 450 211 458 minecraft:glowstone
fill 451 206 416 451 207 416 minecraft:cracked_stone_bricks
setblock 452 206 416 minecraft:stone_bricks
fill 453 206 416 453 207 416 minecraft:cracked_stone_bricks
fill 454 206 416 457 211 416 minecraft:glowstone
fill 455 206 458 456 207 458 minecraft:cracked_stone_bricks
setblock 457 206 458 minecraft:stone_bricks
fill 459 206 458 462 211 458 minecraft:glowstone
fill 464 206 416 464 207 416 minecraft:cracked_stone_bricks
fill 464 206 458 465 207 458 minecraft:cracked_stone_bricks
setblock 465 206 416 minecraft:stone_bricks
fill 465 206 417 465 211 420 minecraft:glowstone
fill 465 206 421 465 207 422 minecraft:cracked_stone_bricks
setblock 465 206 423 minecraft:stone_bricks
fill 465 206 429 465 211 432 minecraft:glowstone
fill 465 206 441 465 211 444 minecraft:glowstone
fill 465 206 446 465 207 447 minecraft:cracked_stone_bricks
setblock 465 206 448 minecraft:stone_bricks
fill 465 206 449 465 207 452 minecraft:cracked_stone_bricks
fill 465 206 453 465 211 456 minecraft:glowstone
fill 423 207 430 423 207 431 minecraft:cracked_stone_bricks
setblock 423 207 457 minecraft:cracked_stone_bricks
setblock 427 207 416 minecraft:cracked_stone_bricks
setblock 428 207 458 minecraft:cracked_stone_bricks
setblock 429 207 416 minecraft:cracked_stone_bricks
setblock 434 207 416 minecraft:cracked_stone_bricks
setblock 452 207 416 minecraft:cracked_stone_bricks
setblock 457 207 458 minecraft:cracked_stone_bricks
setblock 465 207 416 minecraft:cracked_stone_bricks
fill 465 207 423 465 208 423 minecraft:cracked_stone_bricks
setblock 465 207 448 minecraft:cracked_stone_bricks
fill 423 208 416 423 208 419 minecraft:stone_bricks
fill 423 208 421 423 307 421 minecraft:stone_bricks
fill 423 208 426 423 208 433 minecraft:stone_bricks
fill 423 208 438 423 208 445 minecraft:stone_bricks
fill 423 208 450 423 209 453 minecraft:stone_bricks
fill 423 208 455 423 208 457 minecraft:stone_bricks
fill 424 208 416 429 208 416 minecraft:stone_bricks
fill 427 208 458 434 208 458 minecraft:stone_bricks
fill 434 208 416 441 208 416 minecraft:stone_bricks
fill 439 208 458 446 307 458 minecraft:stone_bricks
fill 447 208 416 453 208 416 minecraft:stone_bricks
fill 451 208 458 451 209 458 minecraft:stone_bricks
fill 452 208 458 452 209 458 minecraft:cracked_stone_bricks
fill 453 208 458 458 209 458 minecraft:stone_bricks
fill 458 208 416 465 208 416 minecraft:stone_bricks
fill 463 208 458 465 208 458 minecraft:stone_bricks
setblock 465 208 421 minecraft:cracked_stone_bricks
fill 465 208 422 465 209 422 minecraft:stone_bricks
fill 465 208 424 465 209 426 minecraft:stone_bricks
fill 465 208 433 465 209 436 minecraft:stone_bricks
setblock 465 208 437 minecraft:cracked_stone_bricks
fill 465 208 438 465 209 440 minecraft:stone_bricks
fill 465 208 445 465 208 452 minecraft:stone_bricks
setblock 465 208 457 minecraft:stone_bricks
setblock 423 209 416 minecraft:cracked_stone_bricks
fill 423 209 417 423 209 420 minecraft:stone_bricks
fill 423 209 426 423 307 426 minecraft:stone_bricks
setblock 423 209 427 minecraft:cracked_stone_bricks
fill 423 209 428 423 307 428 minecraft:stone_bricks
fill 423 209 429 423 209 430 minecraft:cracked_stone_bricks
fill 423 209 431 423 307 433 minecraft:stone_bricks
fill 423 209 438 423 209 441 minecraft:stone_bricks
setblock 423 209 442 minecraft:cracked_stone_bricks
fill 423 209 443 423 307 445 minecraft:stone_bricks
fill 423 209 454 423 307 455 minecraft:stone_bricks
setblock 423 209 456 minecraft:cracked_stone_bricks
fill 423 209 457 423 307 457 minecraft:stone_bricks
fill 424 209 416 425 307 416 minecraft:stone_bricks
setblock 426 209 416 minecraft:cracked_stone_bricks
fill 427 209 416 429 307 416 minecraft:stone_bricks
fill 427 209 458 431 307 458 minecraft:stone_bricks
fill 432 209 458 433 209 458 minecraft:cracked_stone_bricks
fill 434 209 416 434 307 416 minecraft:stone_bricks
fill 434 209 458 434 307 458 minecraft:stone_bricks
setblock 435 209 416 minecraft:cracked_stone_bricks
fill 436 209 416 441 209 416 minecraft:stone_bricks
fill 446 209 416 448 307 416 minecraft:stone_bricks
setblock 449 209 416 minecraft:cracked_stone_bricks
schedule function dropper:buildpart/105_2 1t
