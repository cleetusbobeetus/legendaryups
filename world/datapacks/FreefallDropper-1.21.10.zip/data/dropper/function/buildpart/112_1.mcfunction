fill 197 155 472 197 156 472 minecraft:light_gray_concrete
fill 197 155 474 197 156 474 minecraft:light_gray_concrete
fill 197 155 476 197 156 476 minecraft:light_gray_concrete
setblock 229 155 503 minecraft:light_gray_concrete
setblock 191 156 466 minecraft:light[level=11]
setblock 191 156 482 minecraft:light[level=11]
setblock 191 156 490 minecraft:light[level=11]
setblock 191 156 498 minecraft:light[level=11]
setblock 199 156 466 minecraft:light[level=11]
setblock 199 156 474 minecraft:light[level=11]
setblock 199 156 482 minecraft:light[level=11]
setblock 199 156 490 minecraft:light[level=11]
setblock 199 156 498 minecraft:light[level=11]
setblock 207 156 466 minecraft:light[level=11]
setblock 207 156 474 minecraft:light[level=11]
setblock 207 156 490 minecraft:light[level=11]
setblock 207 156 498 minecraft:light[level=11]
setblock 215 156 466 minecraft:light[level=11]
setblock 215 156 474 minecraft:light[level=11]
setblock 215 156 482 minecraft:light[level=11]
setblock 215 156 490 minecraft:light[level=11]
setblock 223 156 466 minecraft:light[level=11]
setblock 223 156 474 minecraft:light[level=11]
setblock 223 156 482 minecraft:light[level=11]
setblock 223 156 490 minecraft:light[level=11]
setblock 223 156 498 minecraft:light[level=11]
setblock 189 157 472 minecraft:pearlescent_froglight
setblock 189 157 474 minecraft:pearlescent_froglight
setblock 189 157 476 minecraft:pearlescent_froglight
setblock 190 157 471 minecraft:pearlescent_froglight
setblock 190 157 473 minecraft:pearlescent_froglight
setblock 190 157 475 minecraft:pearlescent_froglight
setblock 190 157 477 minecraft:pearlescent_froglight
setblock 191 157 472 minecraft:pearlescent_froglight
setblock 191 157 474 minecraft:pearlescent_froglight
setblock 191 157 476 minecraft:pearlescent_froglight
setblock 192 157 471 minecraft:pearlescent_froglight
setblock 192 157 473 minecraft:pearlescent_froglight
setblock 192 157 475 minecraft:pearlescent_froglight
setblock 192 157 477 minecraft:pearlescent_froglight
setblock 193 157 472 minecraft:pearlescent_froglight
setblock 193 157 474 minecraft:pearlescent_froglight
setblock 193 157 476 minecraft:pearlescent_froglight
setblock 194 157 471 minecraft:pearlescent_froglight
setblock 194 157 473 minecraft:pearlescent_froglight
setblock 194 157 475 minecraft:pearlescent_froglight
setblock 194 157 477 minecraft:pearlescent_froglight
setblock 195 157 472 minecraft:pearlescent_froglight
setblock 195 157 474 minecraft:pearlescent_froglight
setblock 195 157 476 minecraft:pearlescent_froglight
setblock 196 157 471 minecraft:pearlescent_froglight
setblock 196 157 473 minecraft:pearlescent_froglight
setblock 196 157 475 minecraft:pearlescent_froglight
setblock 196 157 477 minecraft:pearlescent_froglight
setblock 197 157 472 minecraft:pearlescent_froglight
setblock 197 157 474 minecraft:pearlescent_froglight
setblock 197 157 476 minecraft:pearlescent_froglight
fill 188 158 468 188 163 468 minecraft:pearlescent_froglight
fill 188 158 476 188 163 476 minecraft:pearlescent_froglight
fill 188 158 484 188 163 484 minecraft:pearlescent_froglight
fill 188 158 492 188 163 492 minecraft:pearlescent_froglight
fill 188 158 500 188 163 500 minecraft:pearlescent_froglight
fill 189 158 472 189 159 472 minecraft:light_gray_concrete
fill 189 158 474 189 159 474 minecraft:light_gray_concrete
fill 189 158 476 189 159 476 minecraft:light_gray_concrete
fill 190 158 471 190 159 471 minecraft:light_gray_concrete
fill 190 158 473 190 159 473 minecraft:light_gray_concrete
fill 190 158 475 190 159 475 minecraft:light_gray_concrete
fill 190 158 477 190 159 477 minecraft:light_gray_concrete
fill 191 158 472 191 159 472 minecraft:light_gray_concrete
fill 191 158 474 191 159 474 minecraft:light_gray_concrete
fill 191 158 476 191 159 476 minecraft:light_gray_concrete
fill 191 158 505 191 163 505 minecraft:pearlescent_froglight
fill 192 158 471 192 159 471 minecraft:light_gray_concrete
fill 192 158 473 192 159 473 minecraft:light_gray_concrete
fill 192 158 475 192 159 475 minecraft:light_gray_concrete
fill 192 158 477 192 159 477 minecraft:light_gray_concrete
fill 193 158 472 193 159 472 minecraft:light_gray_concrete
fill 193 158 474 193 159 474 minecraft:light_gray_concrete
fill 193 158 476 193 159 476 minecraft:light_gray_concrete
fill 194 158 471 194 159 471 minecraft:light_gray_concrete
fill 194 158 473 194 159 473 minecraft:light_gray_concrete
fill 194 158 475 194 159 475 minecraft:light_gray_concrete
fill 194 158 477 194 159 477 minecraft:light_gray_concrete
fill 195 158 463 195 163 463 minecraft:pearlescent_froglight
fill 195 158 472 195 159 472 minecraft:light_gray_concrete
fill 195 158 474 195 159 474 minecraft:light_gray_concrete
fill 195 158 476 195 159 476 minecraft:light_gray_concrete
fill 196 158 471 196 159 471 minecraft:light_gray_concrete
fill 196 158 473 196 159 473 minecraft:light_gray_concrete
fill 196 158 475 196 159 475 minecraft:light_gray_concrete
fill 196 158 477 196 159 477 minecraft:light_gray_concrete
fill 197 158 472 197 159 472 minecraft:light_gray_concrete
fill 197 158 474 197 159 474 minecraft:light_gray_concrete
fill 197 158 476 197 159 476 minecraft:light_gray_concrete
fill 199 158 505 199 163 505 minecraft:pearlescent_froglight
fill 203 158 463 203 163 463 minecraft:pearlescent_froglight
fill 207 158 505 207 163 505 minecraft:pearlescent_froglight
fill 211 158 463 211 163 463 minecraft:pearlescent_froglight
fill 215 158 505 215 163 505 minecraft:pearlescent_froglight
fill 219 158 463 219 163 463 minecraft:pearlescent_froglight
fill 223 158 505 223 163 505 minecraft:pearlescent_froglight
fill 227 158 463 227 163 463 minecraft:pearlescent_froglight
fill 230 158 468 230 163 468 minecraft:pearlescent_froglight
fill 230 158 476 230 163 476 minecraft:pearlescent_froglight
fill 230 158 484 230 163 484 minecraft:pearlescent_froglight
fill 230 158 492 230 163 492 minecraft:pearlescent_froglight
fill 230 158 500 230 163 500 minecraft:pearlescent_froglight
setblock 189 160 472 minecraft:pearlescent_froglight
setblock 189 160 474 minecraft:pearlescent_froglight
setblock 189 160 476 minecraft:pearlescent_froglight
setblock 190 160 471 minecraft:pearlescent_froglight
setblock 190 160 473 minecraft:pearlescent_froglight
setblock 190 160 475 minecraft:pearlescent_froglight
setblock 190 160 477 minecraft:pearlescent_froglight
setblock 191 160 472 minecraft:pearlescent_froglight
setblock 191 160 474 minecraft:pearlescent_froglight
setblock 191 160 476 minecraft:pearlescent_froglight
setblock 192 160 471 minecraft:pearlescent_froglight
setblock 192 160 473 minecraft:pearlescent_froglight
setblock 192 160 475 minecraft:pearlescent_froglight
setblock 192 160 477 minecraft:pearlescent_froglight
setblock 193 160 472 minecraft:pearlescent_froglight
setblock 193 160 474 minecraft:pearlescent_froglight
setblock 193 160 476 minecraft:pearlescent_froglight
setblock 194 160 471 minecraft:pearlescent_froglight
setblock 194 160 473 minecraft:pearlescent_froglight
setblock 194 160 475 minecraft:pearlescent_froglight
setblock 194 160 477 minecraft:pearlescent_froglight
setblock 195 160 472 minecraft:pearlescent_froglight
setblock 195 160 474 minecraft:pearlescent_froglight
setblock 195 160 476 minecraft:pearlescent_froglight
setblock 196 160 471 minecraft:pearlescent_froglight
setblock 196 160 473 minecraft:pearlescent_froglight
setblock 196 160 475 minecraft:pearlescent_froglight
setblock 196 160 477 minecraft:pearlescent_froglight
setblock 197 160 472 minecraft:pearlescent_froglight
setblock 197 160 474 minecraft:pearlescent_froglight
setblock 197 160 476 minecraft:pearlescent_froglight
fill 220 160 500 220 160 502 minecraft:light_gray_concrete
fill 221 160 500 222 160 500 minecraft:light_gray_concrete
fill 221 160 502 222 160 502 minecraft:light_gray_concrete
setblock 222 160 501 minecraft:light_gray_concrete
fill 189 161 472 189 162 472 minecraft:light_gray_concrete
fill 189 161 474 189 162 474 minecraft:light_gray_concrete
fill 189 161 476 189 162 476 minecraft:light_gray_concrete
fill 190 161 471 190 162 471 minecraft:light_gray_concrete
fill 190 161 473 190 162 473 minecraft:light_gray_concrete
fill 190 161 475 190 162 475 minecraft:light_gray_concrete
fill 190 161 477 190 162 477 minecraft:light_gray_concrete
fill 191 161 472 191 162 472 minecraft:light_gray_concrete
fill 191 161 474 191 162 474 minecraft:light_gray_concrete
fill 191 161 476 191 162 476 minecraft:light_gray_concrete
fill 192 161 471 192 162 471 minecraft:light_gray_concrete
fill 192 161 473 192 162 473 minecraft:light_gray_concrete
fill 192 161 475 192 162 475 minecraft:light_gray_concrete
fill 192 161 477 192 162 477 minecraft:light_gray_concrete
fill 193 161 472 193 162 472 minecraft:light_gray_concrete
fill 193 161 474 193 162 474 minecraft:light_gray_concrete
fill 193 161 476 193 162 476 minecraft:light_gray_concrete
fill 194 161 471 194 162 471 minecraft:light_gray_concrete
fill 194 161 473 194 162 473 minecraft:light_gray_concrete
fill 194 161 475 194 162 475 minecraft:light_gray_concrete
fill 194 161 477 194 162 477 minecraft:light_gray_concrete
fill 195 161 472 195 162 472 minecraft:light_gray_concrete
fill 195 161 474 195 162 474 minecraft:light_gray_concrete
fill 195 161 476 195 162 476 minecraft:light_gray_concrete
fill 196 161 471 196 162 471 minecraft:light_gray_concrete
fill 196 161 473 196 162 473 minecraft:light_gray_concrete
fill 196 161 475 196 162 475 minecraft:light_gray_concrete
fill 196 161 477 196 162 477 minecraft:light_gray_concrete
fill 197 161 472 197 162 472 minecraft:light_gray_concrete
fill 197 161 474 197 162 474 minecraft:light_gray_concrete
fill 197 161 476 197 162 476 minecraft:light_gray_concrete
setblock 189 163 472 minecraft:pearlescent_froglight
setblock 189 163 474 minecraft:pearlescent_froglight
setblock 189 163 476 minecraft:pearlescent_froglight
setblock 190 163 471 minecraft:pearlescent_froglight
setblock 190 163 473 minecraft:pearlescent_froglight
setblock 190 163 475 minecraft:pearlescent_froglight
setblock 190 163 477 minecraft:pearlescent_froglight
setblock 191 163 472 minecraft:pearlescent_froglight
setblock 191 163 474 minecraft:pearlescent_froglight
setblock 191 163 476 minecraft:pearlescent_froglight
setblock 192 163 471 minecraft:pearlescent_froglight
setblock 192 163 473 minecraft:pearlescent_froglight
setblock 192 163 475 minecraft:pearlescent_froglight
setblock 192 163 477 minecraft:pearlescent_froglight
setblock 193 163 472 minecraft:pearlescent_froglight
setblock 193 163 474 minecraft:pearlescent_froglight
setblock 193 163 476 minecraft:pearlescent_froglight
setblock 194 163 471 minecraft:pearlescent_froglight
setblock 194 163 473 minecraft:pearlescent_froglight
setblock 194 163 475 minecraft:pearlescent_froglight
setblock 194 163 477 minecraft:pearlescent_froglight
setblock 195 163 472 minecraft:pearlescent_froglight
setblock 195 163 474 minecraft:pearlescent_froglight
setblock 195 163 476 minecraft:pearlescent_froglight
setblock 196 163 471 minecraft:pearlescent_froglight
setblock 196 163 473 minecraft:pearlescent_froglight
setblock 196 163 475 minecraft:pearlescent_froglight
setblock 196 163 477 minecraft:pearlescent_froglight
setblock 197 163 472 minecraft:pearlescent_froglight
setblock 197 163 474 minecraft:pearlescent_froglight
setblock 197 163 476 minecraft:pearlescent_froglight
fill 211 163 504 212 185 504 minecraft:light_gray_concrete
fill 219 163 504 220 185 504 minecraft:light_gray_concrete
fill 188 164 468 188 171 468 minecraft:light_gray_terracotta
fill 188 164 476 188 171 476 minecraft:light_gray_terracotta
fill 188 164 484 188 171 484 minecraft:light_gray_terracotta
fill 188 164 492 188 171 492 minecraft:light_gray_terracotta
fill 188 164 500 188 171 500 minecraft:light_gray_terracotta
fill 189 164 472 189 165 472 minecraft:light_gray_concrete
fill 189 164 474 189 165 474 minecraft:light_gray_concrete
fill 189 164 476 189 165 476 minecraft:light_gray_concrete
fill 190 164 471 190 165 471 minecraft:light_gray_concrete
fill 190 164 473 190 165 473 minecraft:light_gray_concrete
fill 190 164 475 190 165 475 minecraft:light_gray_concrete
fill 190 164 477 190 165 477 minecraft:light_gray_concrete
setblock 191 164 466 minecraft:light[level=11]
fill 191 164 472 191 165 472 minecraft:light_gray_concrete
fill 191 164 474 191 165 474 minecraft:light_gray_concrete
fill 191 164 476 191 165 476 minecraft:light_gray_concrete
setblock 191 164 482 minecraft:light[level=11]
setblock 191 164 490 minecraft:light[level=11]
setblock 191 164 498 minecraft:light[level=11]
fill 191 164 505 191 171 505 minecraft:light_gray_terracotta
fill 192 164 471 192 165 471 minecraft:light_gray_concrete
fill 192 164 473 192 165 473 minecraft:light_gray_concrete
fill 192 164 475 192 165 475 minecraft:light_gray_concrete
fill 192 164 477 192 165 477 minecraft:light_gray_concrete
fill 193 164 472 193 165 472 minecraft:light_gray_concrete
fill 193 164 474 193 165 474 minecraft:light_gray_concrete
fill 193 164 476 193 165 476 minecraft:light_gray_concrete
fill 194 164 471 194 165 471 minecraft:light_gray_concrete
fill 194 164 473 194 165 473 minecraft:light_gray_concrete
fill 194 164 475 194 165 475 minecraft:light_gray_concrete
fill 194 164 477 194 165 477 minecraft:light_gray_concrete
fill 195 164 463 195 171 463 minecraft:light_gray_terracotta
fill 195 164 472 195 165 472 minecraft:light_gray_concrete
fill 195 164 474 195 165 474 minecraft:light_gray_concrete
fill 195 164 476 195 165 476 minecraft:light_gray_concrete
fill 196 164 471 196 165 471 minecraft:light_gray_concrete
fill 196 164 473 196 165 473 minecraft:light_gray_concrete
fill 196 164 475 196 165 475 minecraft:light_gray_concrete
fill 196 164 477 196 165 477 minecraft:light_gray_concrete
fill 197 164 472 197 165 472 minecraft:light_gray_concrete
fill 197 164 474 197 165 474 minecraft:light_gray_concrete
fill 197 164 476 197 165 476 minecraft:light_gray_concrete
setblock 199 164 466 minecraft:light[level=11]
setblock 199 164 474 minecraft:light[level=11]
setblock 199 164 482 minecraft:light[level=11]
setblock 199 164 490 minecraft:light[level=11]
setblock 199 164 498 minecraft:light[level=11]
fill 199 164 505 199 171 505 minecraft:light_gray_terracotta
fill 203 164 463 203 171 463 minecraft:light_gray_terracotta
setblock 207 164 466 minecraft:light[level=11]
setblock 207 164 474 minecraft:light[level=11]
setblock 207 164 490 minecraft:light[level=11]
setblock 207 164 498 minecraft:light[level=11]
fill 207 164 505 207 171 505 minecraft:light_gray_terracotta
fill 211 164 463 211 171 463 minecraft:light_gray_terracotta
setblock 215 164 466 minecraft:light[level=11]
setblock 215 164 474 minecraft:light[level=11]
setblock 215 164 482 minecraft:light[level=11]
setblock 215 164 490 minecraft:light[level=11]
setblock 215 164 498 minecraft:light[level=11]
fill 215 164 505 215 171 505 minecraft:light_gray_terracotta
fill 219 164 463 219 171 463 minecraft:light_gray_terracotta
setblock 223 164 466 minecraft:light[level=11]
setblock 223 164 474 minecraft:light[level=11]
setblock 223 164 482 minecraft:light[level=11]
setblock 223 164 490 minecraft:light[level=11]
setblock 223 164 498 minecraft:light[level=11]
fill 223 164 505 223 171 505 minecraft:light_gray_terracotta
fill 227 164 463 227 171 463 minecraft:light_gray_terracotta
fill 230 164 468 230 171 468 minecraft:light_gray_terracotta
fill 230 164 476 230 171 476 minecraft:light_gray_terracotta
fill 230 164 484 230 171 484 minecraft:light_gray_terracotta
fill 230 164 492 230 171 492 minecraft:light_gray_terracotta
fill 230 164 500 230 171 500 minecraft:light_gray_terracotta
fill 189 166 478 189 185 479 minecraft:light_gray_concrete
fill 206 167 494 207 168 495 minecraft:white_wool
fill 189 168 464 189 169 469 minecraft:light_gray_concrete
fill 189 168 472 190 168 477 minecraft:light_gray_concrete
fill 189 168 480 190 168 485 minecraft:light_gray_concrete
fill 189 168 488 190 168 493 minecraft:light_gray_concrete
fill 189 168 496 190 168 501 minecraft:light_gray_concrete
fill 189 168 504 194 169 504 minecraft:light_gray_concrete
fill 190 168 465 190 168 471 minecraft:light_gray_concrete
fill 190 168 478 190 168 479 minecraft:light_gray_concrete
fill 190 168 486 190 168 487 minecraft:light_gray_concrete
fill 190 168 494 190 168 495 minecraft:light_gray_concrete
fill 190 168 502 190 168 503 minecraft:light_gray_concrete
fill 191 168 465 228 168 465 minecraft:light_gray_concrete
fill 191 168 503 229 168 503 minecraft:light_gray_concrete
fill 192 168 464 197 169 464 minecraft:light_gray_concrete
fill 197 168 504 202 169 504 minecraft:light_gray_concrete
fill 200 168 464 205 169 464 minecraft:light_gray_concrete
fill 205 168 504 210 169 504 minecraft:light_gray_concrete
fill 208 168 464 213 169 464 minecraft:light_gray_concrete
fill 213 168 504 218 169 504 minecraft:light_gray_concrete
fill 216 168 464 221 169 464 minecraft:light_gray_concrete
fill 217 168 486 217 169 486 minecraft:red_concrete
fill 220 168 500 220 168 502 minecraft:light_gray_concrete
fill 221 168 500 222 168 500 minecraft:light_gray_concrete
fill 221 168 502 222 168 502 minecraft:light_gray_concrete
fill 221 168 504 226 169 504 minecraft:light_gray_concrete
setblock 222 168 501 minecraft:light_gray_concrete
fill 224 168 464 229 169 464 minecraft:light_gray_concrete
fill 228 168 466 228 168 502 minecraft:light_gray_concrete
fill 229 168 467 229 169 472 minecraft:light_gray_concrete
fill 229 168 475 229 169 480 minecraft:light_gray_concrete
fill 229 168 483 229 169 488 minecraft:light_gray_concrete
fill 229 168 491 229 169 496 minecraft:light_gray_concrete
fill 229 168 499 229 169 502 minecraft:light_gray_concrete
fill 229 168 504 229 169 504 minecraft:light_gray_concrete
fill 189 169 472 189 169 477 minecraft:light_gray_concrete
fill 189 169 480 189 169 485 minecraft:light_gray_concrete
fill 189 169 488 189 169 493 minecraft:light_gray_concrete
fill 189 169 496 189 169 501 minecraft:light_gray_concrete
setblock 229 169 503 minecraft:light_gray_concrete
fill 213 171 502 215 172 502 minecraft:white_wool
fill 214 171 501 214 172 501 minecraft:white_wool
fill 214 171 503 214 172 503 minecraft:white_wool
fill 188 172 468 188 177 468 minecraft:pearlescent_froglight
fill 188 172 476 188 177 476 minecraft:pearlescent_froglight
fill 188 172 484 188 177 484 minecraft:pearlescent_froglight
fill 188 172 492 188 177 492 minecraft:pearlescent_froglight
fill 188 172 500 188 177 500 minecraft:pearlescent_froglight
setblock 191 172 466 minecraft:light[level=11]
setblock 191 172 474 minecraft:light[level=11]
setblock 191 172 482 minecraft:light[level=11]
setblock 191 172 490 minecraft:light[level=11]
setblock 191 172 498 minecraft:light[level=11]
fill 191 172 505 191 177 505 minecraft:pearlescent_froglight
fill 195 172 463 195 177 463 minecraft:pearlescent_froglight
setblock 199 172 466 minecraft:light[level=11]
setblock 199 172 474 minecraft:light[level=11]
setblock 199 172 482 minecraft:light[level=11]
setblock 199 172 490 minecraft:light[level=11]
setblock 199 172 498 minecraft:light[level=11]
fill 199 172 505 199 177 505 minecraft:pearlescent_froglight
fill 203 172 463 203 177 463 minecraft:pearlescent_froglight
setblock 207 172 466 minecraft:light[level=11]
setblock 207 172 474 minecraft:light[level=11]
setblock 207 172 490 minecraft:light[level=11]
setblock 207 172 498 minecraft:light[level=11]
fill 207 172 505 207 177 505 minecraft:pearlescent_froglight
fill 211 172 463 211 177 463 minecraft:pearlescent_froglight
setblock 215 172 466 minecraft:light[level=11]
setblock 215 172 474 minecraft:light[level=11]
setblock 215 172 482 minecraft:light[level=11]
setblock 215 172 490 minecraft:light[level=11]
setblock 215 172 498 minecraft:light[level=11]
fill 215 172 505 215 177 505 minecraft:pearlescent_froglight
fill 219 172 463 219 177 463 minecraft:pearlescent_froglight
setblock 223 172 466 minecraft:light[level=11]
setblock 223 172 474 minecraft:light[level=11]
setblock 223 172 482 minecraft:light[level=11]
setblock 223 172 490 minecraft:light[level=11]
setblock 223 172 498 minecraft:light[level=11]
fill 223 172 505 223 177 505 minecraft:pearlescent_froglight
fill 227 172 463 227 177 463 minecraft:pearlescent_froglight
fill 230 172 468 230 177 468 minecraft:pearlescent_froglight
fill 230 172 476 230 177 476 minecraft:pearlescent_froglight
fill 230 172 484 230 177 484 minecraft:pearlescent_froglight
fill 230 172 492 230 177 492 minecraft:pearlescent_froglight
fill 230 172 500 230 177 500 minecraft:pearlescent_froglight
fill 220 176 500 220 176 502 minecraft:light_gray_concrete
fill 221 176 500 222 176 500 minecraft:light_gray_concrete
fill 221 176 502 222 176 502 minecraft:light_gray_concrete
setblock 222 176 501 minecraft:light_gray_concrete
fill 188 178 468 188 199 468 minecraft:light_gray_terracotta
fill 188 178 476 188 199 476 minecraft:light_gray_terracotta
fill 188 178 484 188 199 484 minecraft:light_gray_terracotta
fill 188 178 492 188 199 492 minecraft:light_gray_terracotta
fill 188 178 500 188 199 500 minecraft:light_gray_terracotta
fill 191 178 505 191 199 505 minecraft:light_gray_terracotta
fill 195 178 463 195 199 463 minecraft:light_gray_terracotta
fill 197 178 478 199 179 478 minecraft:red_concrete
fill 198 178 477 198 179 477 minecraft:red_concrete
fill 199 178 505 199 199 505 minecraft:light_gray_terracotta
fill 203 178 463 203 199 463 minecraft:light_gray_terracotta
fill 207 178 505 207 199 505 minecraft:light_gray_terracotta
fill 211 178 463 211 199 463 minecraft:light_gray_terracotta
fill 215 178 505 215 199 505 minecraft:light_gray_terracotta
fill 219 178 463 219 199 463 minecraft:light_gray_terracotta
fill 223 178 505 223 199 505 minecraft:light_gray_terracotta
fill 227 178 463 227 199 463 minecraft:light_gray_terracotta
fill 230 178 468 230 199 468 minecraft:light_gray_terracotta
fill 230 178 476 230 199 476 minecraft:light_gray_terracotta
fill 230 178 484 230 199 484 minecraft:light_gray_terracotta
fill 230 178 492 230 199 492 minecraft:light_gray_terracotta
fill 230 178 500 230 199 500 minecraft:light_gray_terracotta
setblock 191 180 466 minecraft:light[level=11]
setblock 191 180 474 minecraft:light[level=11]
setblock 191 180 482 minecraft:light[level=11]
setblock 191 180 490 minecraft:light[level=11]
setblock 191 180 498 minecraft:light[level=11]
setblock 199 180 466 minecraft:light[level=11]
setblock 199 180 474 minecraft:light[level=11]
setblock 199 180 482 minecraft:light[level=11]
setblock 199 180 490 minecraft:light[level=11]
setblock 199 180 498 minecraft:light[level=11]
setblock 207 180 466 minecraft:light[level=11]
setblock 207 180 474 minecraft:light[level=11]
setblock 207 180 490 minecraft:light[level=11]
setblock 207 180 498 minecraft:light[level=11]
setblock 215 180 466 minecraft:light[level=11]
setblock 215 180 474 minecraft:light[level=11]
setblock 215 180 482 minecraft:light[level=11]
setblock 215 180 490 minecraft:light[level=11]
setblock 215 180 498 minecraft:light[level=11]
setblock 223 180 466 minecraft:light[level=11]
setblock 223 180 474 minecraft:light[level=11]
setblock 223 180 482 minecraft:light[level=11]
setblock 223 180 490 minecraft:light[level=11]
setblock 223 180 498 minecraft:light[level=11]
fill 189 182 464 189 183 469 minecraft:light_gray_concrete
fill 189 182 472 190 182 477 minecraft:light_gray_concrete
fill 189 182 480 190 182 485 minecraft:light_gray_concrete
fill 189 182 488 190 182 493 minecraft:light_gray_concrete
fill 189 182 496 190 182 501 minecraft:light_gray_concrete
fill 189 182 504 194 183 504 minecraft:light_gray_concrete
fill 190 182 465 190 182 471 minecraft:light_gray_concrete
fill 190 182 478 190 182 479 minecraft:light_gray_concrete
fill 190 182 486 190 182 487 minecraft:light_gray_concrete
fill 190 182 494 190 182 495 minecraft:light_gray_concrete
fill 190 182 502 190 182 503 minecraft:light_gray_concrete
fill 191 182 465 228 182 465 minecraft:light_gray_concrete
fill 191 182 503 229 182 503 minecraft:light_gray_concrete
fill 192 182 464 197 183 464 minecraft:light_gray_concrete
fill 197 182 504 202 183 504 minecraft:light_gray_concrete
fill 200 182 464 205 183 464 minecraft:light_gray_concrete
fill 205 182 504 210 183 504 minecraft:light_gray_concrete
fill 208 182 464 213 183 464 minecraft:light_gray_concrete
fill 213 182 504 218 183 504 minecraft:light_gray_concrete
fill 216 182 464 221 183 464 minecraft:light_gray_concrete
fill 221 182 504 226 183 504 minecraft:light_gray_concrete
fill 224 182 464 229 183 464 minecraft:light_gray_concrete
fill 228 182 466 228 182 502 minecraft:light_gray_concrete
fill 229 182 467 229 183 472 minecraft:light_gray_concrete
fill 229 182 475 229 183 480 minecraft:light_gray_concrete
fill 229 182 483 229 183 488 minecraft:light_gray_concrete
fill 229 182 491 229 183 496 minecraft:light_gray_concrete
fill 229 182 499 229 183 502 minecraft:light_gray_concrete
fill 229 182 504 229 183 504 minecraft:light_gray_concrete
fill 189 183 472 189 183 477 minecraft:light_gray_concrete
fill 189 183 480 189 183 485 minecraft:light_gray_concrete
fill 189 183 488 189 183 493 minecraft:light_gray_concrete
fill 189 183 496 189 183 501 minecraft:light_gray_concrete
setblock 229 183 503 minecraft:light_gray_concrete
fill 220 184 500 220 184 502 minecraft:light_gray_concrete
fill 221 184 500 222 184 500 minecraft:light_gray_concrete
fill 221 184 502 222 184 502 minecraft:light_gray_concrete
fill 221 184 503 221 185 504 minecraft:iron_block
setblock 222 184 501 minecraft:light_gray_concrete
setblock 221 185 500 minecraft:pearlescent_froglight
setblock 221 185 502 minecraft:iron_block
setblock 191 188 466 minecraft:light[level=11]
setblock 191 188 474 minecraft:light[level=11]
setblock 191 188 482 minecraft:light[level=11]
setblock 191 188 490 minecraft:light[level=11]
setblock 191 188 498 minecraft:light[level=11]
setblock 199 188 466 minecraft:light[level=11]
setblock 199 188 474 minecraft:light[level=11]
setblock 199 188 482 minecraft:light[level=11]
setblock 199 188 490 minecraft:light[level=11]
setblock 199 188 498 minecraft:light[level=11]
setblock 207 188 466 minecraft:light[level=11]
setblock 207 188 474 minecraft:light[level=11]
setblock 207 188 490 minecraft:light[level=11]
setblock 207 188 498 minecraft:light[level=11]
setblock 215 188 466 minecraft:light[level=11]
setblock 215 188 474 minecraft:light[level=11]
setblock 215 188 482 minecraft:light[level=11]
setblock 215 188 490 minecraft:light[level=11]
setblock 215 188 498 minecraft:light[level=11]
setblock 223 188 466 minecraft:light[level=11]
setblock 223 188 474 minecraft:light[level=11]
setblock 223 188 482 minecraft:light[level=11]
setblock 223 188 490 minecraft:light[level=11]
setblock 223 188 498 minecraft:light[level=11]
fill 202 190 484 204 190 486 minecraft:redstone_block
fill 210 190 478 212 190 480 minecraft:redstone_block
fill 210 190 484 212 190 486 minecraft:redstone_block
fill 189 191 464 191 192 504 minecraft:light_gray_concrete
fill 192 191 464 192 192 504 minecraft:iron_block
fill 193 191 464 195 192 504 minecraft:light_gray_concrete
fill 196 191 464 196 192 504 minecraft:iron_block
fill 197 191 464 199 192 504 minecraft:light_gray_concrete
fill 200 191 464 200 192 504 minecraft:iron_block
fill 201 191 464 201 191 504 minecraft:light_gray_concrete
fill 202 191 464 203 191 483 minecraft:light_gray_concrete
fill 202 191 487 203 191 504 minecraft:light_gray_concrete
fill 204 191 464 204 191 483 minecraft:iron_block
fill 204 191 487 204 191 504 minecraft:iron_block
fill 205 191 464 205 191 504 minecraft:light_gray_concrete
fill 206 191 464 207 191 480 minecraft:light_gray_concrete
fill 206 191 484 207 191 504 minecraft:light_gray_concrete
fill 208 191 464 208 191 480 minecraft:iron_block
fill 208 191 484 208 191 504 minecraft:iron_block
fill 209 191 464 209 191 504 minecraft:light_gray_concrete
fill 210 191 464 211 191 477 minecraft:light_gray_concrete
fill 210 191 481 211 191 483 minecraft:light_gray_concrete
fill 210 191 487 211 191 504 minecraft:light_gray_concrete
fill 212 191 464 212 191 477 minecraft:iron_block
fill 212 191 481 212 191 483 minecraft:iron_block
fill 212 191 487 212 191 504 minecraft:iron_block
fill 213 191 464 215 191 504 minecraft:light_gray_concrete
fill 216 191 464 216 192 504 minecraft:iron_block
fill 217 191 464 219 192 504 minecraft:light_gray_concrete
fill 220 191 464 220 192 504 minecraft:iron_block
fill 221 191 464 223 192 504 minecraft:light_gray_concrete
fill 224 191 464 224 192 504 minecraft:iron_block
fill 225 191 464 227 192 504 minecraft:light_gray_concrete
fill 228 191 464 228 192 504 minecraft:iron_block
fill 229 191 464 229 192 504 minecraft:light_gray_concrete
fill 201 192 464 203 192 482 minecraft:light_gray_concrete
fill 201 192 483 201 192 487 minecraft:pearlescent_froglight
fill 201 192 488 203 192 504 minecraft:light_gray_concrete
fill 202 192 483 203 192 483 minecraft:pearlescent_froglight
fill 202 192 484 204 192 486 minecraft:iron_block
fill 202 192 487 205 192 487 minecraft:pearlescent_froglight
fill 204 192 464 204 192 480 minecraft:iron_block
fill 204 192 481 204 192 483 minecraft:red_nether_bricks
fill 204 192 488 204 192 504 minecraft:iron_block
fill 205 192 464 207 192 479 minecraft:light_gray_concrete
setblock 205 192 480 minecraft:red_nether_bricks
fill 205 192 481 205 192 483 minecraft:shroomlight
setblock 205 192 484 minecraft:red_nether_bricks
fill 205 192 485 205 192 486 minecraft:pearlescent_froglight
fill 205 192 488 207 192 504 minecraft:light_gray_concrete
fill 206 192 480 208 192 480 minecraft:shroomlight
fill 206 192 484 208 192 484 minecraft:shroomlight
fill 206 192 485 207 192 487 minecraft:light_gray_concrete
fill 208 192 464 208 192 479 minecraft:iron_block
fill 208 192 485 208 192 504 minecraft:iron_block
fill 209 192 464 211 192 476 minecraft:light_gray_concrete
fill 209 192 477 209 192 479 minecraft:pearlescent_froglight
setblock 209 192 480 minecraft:red_nether_bricks
fill 209 192 481 209 192 483 minecraft:shroomlight
setblock 209 192 484 minecraft:red_nether_bricks
fill 209 192 485 209 192 487 minecraft:pearlescent_froglight
fill 209 192 488 211 192 504 minecraft:light_gray_concrete
fill 210 192 477 213 192 477 minecraft:pearlescent_froglight
fill 210 192 478 212 192 480 minecraft:iron_block
fill 210 192 481 210 192 483 minecraft:red_nether_bricks
fill 210 192 484 212 192 486 minecraft:iron_block
fill 210 192 487 213 192 487 minecraft:pearlescent_froglight
fill 211 192 481 213 192 481 minecraft:pearlescent_froglight
setblock 211 192 482 minecraft:light_gray_concrete
fill 211 192 483 213 192 483 minecraft:pearlescent_froglight
fill 212 192 464 212 192 476 minecraft:iron_block
setblock 212 192 482 minecraft:iron_block
fill 212 192 488 212 192 504 minecraft:iron_block
fill 213 192 464 215 192 476 minecraft:light_gray_concrete
fill 213 192 478 213 192 480 minecraft:pearlescent_froglight
fill 213 192 482 215 192 482 minecraft:light_gray_concrete
fill 213 192 484 213 192 486 minecraft:pearlescent_froglight
fill 213 192 488 215 192 504 minecraft:light_gray_concrete
fill 214 192 477 215 192 481 minecraft:light_gray_concrete
fill 214 192 483 215 192 487 minecraft:light_gray_concrete
fill 201 193 482 203 193 482 minecraft:red_nether_bricks
fill 202 193 480 204 193 481 minecraft:red_nether_bricks
fill 202 193 483 204 193 484 minecraft:red_nether_bricks
fill 203 193 479 206 193 479 minecraft:red_nether_bricks
fill 203 193 485 206 193 485 minecraft:red_nether_bricks
fill 204 193 478 210 193 478 minecraft:red_nether_bricks
fill 204 193 482 205 193 482 minecraft:quartz_block
fill 204 193 486 210 193 486 minecraft:red_nether_bricks
fill 205 193 480 205 194 481 minecraft:quartz_block
fill 205 193 483 205 194 484 minecraft:quartz_block
fill 206 193 480 209 193 480 minecraft:quartz_block
fill 206 193 484 207 193 484 minecraft:quartz_block
fill 207 193 479 207 194 479 minecraft:quartz_block
fill 207 193 485 207 194 485 minecraft:quartz_block
fill 208 193 479 211 193 479 minecraft:red_nether_bricks
fill 208 193 485 211 193 485 minecraft:red_nether_bricks
fill 209 193 481 209 193 484 minecraft:quartz_block
fill 210 193 480 212 193 481 minecraft:red_nether_bricks
fill 210 193 482 210 194 482 minecraft:quartz_block
fill 210 193 483 212 193 484 minecraft:red_nether_bricks
fill 211 193 482 213 193 482 minecraft:red_nether_bricks
fill 200 194 480 202 202 484 minecraft:red_nether_bricks
fill 201 194 479 204 200 479 minecraft:red_nether_bricks
fill 201 194 485 204 200 485 minecraft:red_nether_bricks
fill 202 194 478 206 199 478 minecraft:red_nether_bricks
fill 202 194 486 206 199 486 minecraft:red_nether_bricks
fill 203 194 477 211 201 477 minecraft:red_nether_bricks
fill 203 194 480 203 199 481 minecraft:red_nether_bricks
fill 203 194 482 204 194 482 minecraft:quartz_block
fill 203 194 483 203 199 484 minecraft:red_nether_bricks
fill 203 194 487 211 201 487 minecraft:red_nether_bricks
fill 204 194 480 204 194 481 minecraft:quartz_block
fill 204 194 483 204 194 484 minecraft:quartz_block
fill 205 194 479 206 194 479 minecraft:quartz_block
fill 205 194 485 206 194 485 minecraft:quartz_block
fill 206 194 476 208 203 476 minecraft:red_nether_bricks
setblock 206 194 480 minecraft:quartz_block
setblock 206 194 484 minecraft:quartz_block
fill 206 194 488 208 203 488 minecraft:red_nether_bricks
setblock 207 194 478 minecraft:quartz_block
setblock 207 194 486 minecraft:quartz_block
fill 208 194 478 212 199 478 minecraft:red_nether_bricks
fill 208 194 479 209 194 480 minecraft:quartz_block
fill 208 194 485 209 194 485 minecraft:quartz_block
fill 208 194 486 212 199 486 minecraft:red_nether_bricks
fill 209 194 481 210 194 481 minecraft:quartz_block
fill 209 194 483 210 194 484 minecraft:quartz_block
fill 210 194 479 213 194 479 minecraft:red_nether_bricks
setblock 210 194 480 minecraft:quartz_block
fill 210 194 485 213 194 485 minecraft:red_nether_bricks
fill 211 194 480 211 194 481 minecraft:red_nether_bricks
setblock 211 194 482 minecraft:quartz_block
fill 211 194 483 211 194 484 minecraft:red_nether_bricks
setblock 212 194 480 minecraft:red_nether_bricks
fill 212 194 481 218 200 483 minecraft:nether_bricks
setblock 212 194 484 minecraft:red_nether_bricks
fill 213 194 480 217 200 480 minecraft:nether_bricks
fill 213 194 484 217 200 484 minecraft:nether_bricks
fill 199 195 480 199 202 484 minecraft:red_nether_bricks
fill 200 195 479 200 203 479 minecraft:red_nether_bricks
fill 200 195 485 200 203 485 minecraft:red_nether_bricks
fill 201 195 478 201 203 478 minecraft:red_nether_bricks
fill 201 195 486 201 203 486 minecraft:red_nether_bricks
fill 202 195 477 202 203 477 minecraft:red_nether_bricks
fill 202 195 487 202 203 487 minecraft:red_nether_bricks
fill 203 195 476 205 202 476 minecraft:red_nether_bricks
fill 203 195 482 204 196 482 minecraft:red_nether_bricks
fill 203 195 488 205 202 488 minecraft:red_nether_bricks
fill 204 195 480 204 196 481 minecraft:red_nether_bricks
fill 204 195 483 204 196 484 minecraft:red_nether_bricks
fill 205 195 479 205 195 480 minecraft:red_nether_bricks
fill 205 195 484 205 195 485 minecraft:red_nether_bricks
fill 206 195 479 211 195 479 minecraft:red_nether_bricks
fill 206 195 485 211 195 485 minecraft:red_nether_bricks
fill 207 195 478 207 199 478 minecraft:red_nether_bricks
fill 207 195 486 207 199 486 minecraft:red_nether_bricks
fill 209 195 476 211 202 476 minecraft:red_nether_bricks
fill 209 195 480 210 195 480 minecraft:red_nether_bricks
fill 209 195 484 210 195 484 minecraft:red_nether_bricks
fill 209 195 488 211 202 488 minecraft:red_nether_bricks
setblock 210 195 481 minecraft:red_nether_bricks
fill 210 195 482 211 196 482 minecraft:nether_bricks
setblock 210 195 483 minecraft:red_nether_bricks
fill 211 195 480 211 199 481 minecraft:nether_bricks
fill 211 195 483 211 199 484 minecraft:nether_bricks
fill 212 195 477 212 203 477 minecraft:red_nether_bricks
fill 212 195 479 212 199 480 minecraft:nether_bricks
fill 212 195 484 212 199 485 minecraft:nether_bricks
fill 212 195 487 212 203 487 minecraft:red_nether_bricks
setblock 213 195 478 minecraft:red_nether_bricks
fill 213 195 479 218 199 479 minecraft:nether_bricks
fill 213 195 485 218 199 485 minecraft:nether_bricks
setblock 213 195 486 minecraft:red_nether_bricks
fill 218 195 480 219 197 480 minecraft:nether_bricks
fill 218 195 484 219 197 484 minecraft:nether_bricks
fill 219 195 481 219 199 483 minecraft:nether_bricks
fill 220 195 482 220 199 482 minecraft:nether_bricks
fill 189 196 464 190 196 504 minecraft:light_gray_concrete
fill 191 196 464 229 196 465 minecraft:light_gray_concrete
setblock 191 196 466 minecraft:light[level=11]
setblock 191 196 474 minecraft:light[level=11]
setblock 191 196 482 minecraft:light[level=11]
setblock 191 196 490 minecraft:light[level=11]
setblock 191 196 498 minecraft:light[level=11]
fill 191 196 503 229 196 504 minecraft:light_gray_concrete
fill 198 196 481 198 201 483 minecraft:red_nether_bricks
setblock 199 196 466 minecraft:light[level=11]
setblock 199 196 474 minecraft:light[level=11]
fill 199 196 479 199 202 479 minecraft:red_nether_bricks
fill 199 196 485 199 202 485 minecraft:red_nether_bricks
setblock 199 196 490 minecraft:light[level=11]
setblock 199 196 498 minecraft:light[level=11]
fill 200 196 478 200 202 478 minecraft:red_nether_bricks
fill 200 196 486 200 202 486 minecraft:red_nether_bricks
fill 201 196 477 201 202 477 minecraft:red_nether_bricks
fill 201 196 487 201 202 487 minecraft:red_nether_bricks
fill 202 196 476 202 201 476 minecraft:red_nether_bricks
fill 202 196 488 202 201 488 minecraft:red_nether_bricks
fill 204 196 475 210 200 475 minecraft:red_nether_bricks
fill 204 196 489 210 200 489 minecraft:red_nether_bricks
fill 205 196 479 210 196 479 minecraft:red_nether_bricks
fill 205 196 485 210 196 485 minecraft:red_nether_bricks
setblock 207 196 466 minecraft:light[level=11]
setblock 207 196 474 minecraft:light[level=11]
setblock 207 196 490 minecraft:light[level=11]
setblock 207 196 498 minecraft:light[level=11]
fill 210 196 480 210 196 481 minecraft:nether_bricks
fill 210 196 483 210 196 484 minecraft:nether_bricks
fill 211 196 479 211 198 479 minecraft:nether_bricks
fill 211 196 485 211 198 485 minecraft:nether_bricks
fill 212 196 476 212 201 476 minecraft:red_nether_bricks
fill 212 196 488 212 201 488 minecraft:red_nether_bricks
fill 213 196 477 213 202 477 minecraft:red_nether_bricks
fill 213 196 478 217 198 478 minecraft:nether_bricks
fill 213 196 486 217 198 486 minecraft:nether_bricks
fill 213 196 487 213 202 487 minecraft:red_nether_bricks
fill 214 196 500 216 235 502 minecraft:iron_block
setblock 215 196 466 minecraft:light[level=11]
setblock 215 196 474 minecraft:light[level=11]
setblock 215 196 490 minecraft:light[level=11]
setblock 215 196 498 minecraft:light[level=11]
fill 218 196 466 229 197 470 minecraft:light_gray_concrete
fill 219 196 479 219 198 479 minecraft:nether_bricks
fill 219 196 485 219 198 485 minecraft:nether_bricks
fill 220 196 480 220 198 481 minecraft:nether_bricks
fill 220 196 483 220 198 484 minecraft:nether_bricks
fill 222 196 496 229 198 502 minecraft:light_gray_concrete
setblock 223 196 474 minecraft:light[level=11]
setblock 223 196 482 minecraft:light[level=11]
setblock 223 196 490 minecraft:light[level=11]
fill 228 196 471 229 196 495 minecraft:light_gray_concrete
fill 189 197 464 189 197 504 minecraft:light_gray_concrete
fill 190 197 464 229 197 464 minecraft:light_gray_concrete
fill 190 197 504 229 197 504 minecraft:light_gray_concrete
fill 198 197 480 198 201 480 minecraft:red_nether_bricks
fill 198 197 484 198 201 484 minecraft:red_nether_bricks
fill 199 197 478 199 201 478 minecraft:red_nether_bricks
fill 199 197 486 199 201 486 minecraft:red_nether_bricks
fill 200 197 477 200 201 477 minecraft:red_nether_bricks
fill 200 197 487 200 201 487 minecraft:red_nether_bricks
fill 201 197 476 201 200 476 minecraft:red_nether_bricks
fill 201 197 488 201 200 488 minecraft:red_nether_bricks
fill 203 197 475 203 200 475 minecraft:red_nether_bricks
fill 203 197 482 203 199 482 minecraft:red_nether_bricks
fill 203 197 489 203 200 489 minecraft:red_nether_bricks
fill 204 197 480 204 198 480 minecraft:red_nether_bricks
fill 204 197 484 204 198 484 minecraft:red_nether_bricks
fill 205 197 479 205 198 479 minecraft:red_nether_bricks
fill 205 197 485 205 198 485 minecraft:red_nether_bricks
fill 209 197 479 210 198 479 minecraft:red_nether_bricks
fill 209 197 485 210 198 485 minecraft:red_nether_bricks
fill 210 197 480 210 198 480 minecraft:nether_bricks
fill 210 197 484 210 198 484 minecraft:nether_bricks
fill 211 197 475 211 200 475 minecraft:red_nether_bricks
fill 211 197 482 211 199 482 minecraft:nether_bricks
fill 211 197 489 211 200 489 minecraft:red_nether_bricks
fill 213 197 476 213 200 476 minecraft:red_nether_bricks
fill 213 197 488 213 200 488 minecraft:red_nether_bricks
fill 214 197 477 214 201 477 minecraft:red_nether_bricks
fill 214 197 487 214 201 487 minecraft:red_nether_bricks
fill 218 197 465 229 198 465 minecraft:light_gray_concrete
fill 222 197 503 229 198 503 minecraft:light_gray_concrete
fill 229 197 471 229 197 495 minecraft:light_gray_concrete
fill 189 198 470 189 235 471 minecraft:light_gray_concrete
fill 189 198 478 189 235 479 minecraft:light_gray_concrete
fill 189 198 486 189 235 487 minecraft:light_gray_concrete
fill 189 198 494 189 235 495 minecraft:light_gray_concrete
fill 189 198 502 189 235 503 minecraft:light_gray_concrete
fill 190 198 464 191 235 464 minecraft:light_gray_concrete
fill 195 198 504 196 235 504 minecraft:light_gray_concrete
fill 198 198 464 199 235 464 minecraft:light_gray_concrete
fill 198 198 479 198 200 479 minecraft:red_nether_bricks
fill 198 198 485 198 200 485 minecraft:red_nether_bricks
fill 203 198 504 204 235 504 minecraft:light_gray_concrete
fill 206 198 464 207 235 464 minecraft:light_gray_concrete
fill 211 198 504 212 235 504 minecraft:light_gray_concrete
fill 213 198 500 213 198 502 minecraft:light_gray_concrete
fill 214 198 464 215 235 464 minecraft:light_gray_concrete
fill 214 198 499 216 198 499 minecraft:light_gray_concrete
fill 214 198 503 216 198 503 minecraft:light_gray_concrete
fill 217 198 500 217 198 502 minecraft:light_gray_concrete
fill 218 198 464 228 198 464 minecraft:light_gray_concrete
fill 218 198 466 228 198 470 minecraft:light_gray_concrete
fill 218 198 480 218 200 480 minecraft:nether_bricks
fill 218 198 484 218 200 484 minecraft:nether_bricks
fill 218 198 496 218 199 497 minecraft:white_wool
fill 219 198 480 219 199 480 minecraft:black_concrete
fill 219 198 484 219 199 484 minecraft:black_concrete
fill 219 198 504 220 235 504 minecraft:light_gray_concrete
fill 222 198 504 229 198 504 minecraft:light_gray_concrete
fill 229 198 466 229 235 466 minecraft:light_gray_concrete
fill 229 198 473 229 235 474 minecraft:light_gray_concrete
fill 229 198 481 229 235 482 minecraft:light_gray_concrete
fill 229 198 489 229 235 490 minecraft:light_gray_concrete
fill 210 199 479 211 200 479 minecraft:red_nether_bricks
fill 210 199 485 211 200 485 minecraft:red_nether_bricks
fill 213 199 478 215 201 478 minecraft:red_nether_bricks
fill 213 199 486 215 201 486 minecraft:red_nether_bricks
fill 218 199 464 218 217 464 minecraft:light_gray_concrete
setblock 218 199 465 minecraft:pearlescent_froglight
fill 218 199 466 218 217 466 minecraft:light_gray_concrete
setblock 218 199 467 minecraft:pearlescent_froglight
fill 218 199 468 218 217 468 minecraft:light_gray_concrete
setblock 218 199 469 minecraft:pearlescent_froglight
fill 218 199 470 218 217 470 minecraft:light_gray_concrete
setblock 219 199 464 minecraft:pearlescent_froglight
fill 219 199 465 219 217 465 minecraft:light_gray_concrete
setblock 219 199 466 minecraft:pearlescent_froglight
fill 219 199 467 219 217 467 minecraft:light_gray_concrete
setblock 219 199 468 minecraft:pearlescent_froglight
fill 219 199 469 219 217 469 minecraft:light_gray_concrete
setblock 219 199 470 minecraft:pearlescent_froglight
fill 220 199 464 220 217 464 minecraft:light_gray_concrete
setblock 220 199 465 minecraft:pearlescent_froglight
fill 220 199 466 220 217 466 minecraft:light_gray_concrete
setblock 220 199 467 minecraft:pearlescent_froglight
fill 220 199 468 220 217 468 minecraft:light_gray_concrete
setblock 220 199 469 minecraft:pearlescent_froglight
fill 220 199 470 220 217 470 minecraft:light_gray_concrete
setblock 220 199 481 minecraft:nether_bricks
setblock 220 199 483 minecraft:nether_bricks
setblock 221 199 464 minecraft:pearlescent_froglight
fill 221 199 465 221 217 465 minecraft:light_gray_concrete
setblock 221 199 466 minecraft:pearlescent_froglight
fill 221 199 467 221 217 467 minecraft:light_gray_concrete
setblock 221 199 468 minecraft:pearlescent_froglight
fill 221 199 469 221 217 469 minecraft:light_gray_concrete
setblock 221 199 470 minecraft:pearlescent_froglight
fill 221 199 505 221 219 505 minecraft:light_gray_terracotta
fill 222 199 464 222 235 464 minecraft:light_gray_concrete
setblock 222 199 465 minecraft:pearlescent_froglight
fill 222 199 466 222 217 466 minecraft:light_gray_concrete
setblock 222 199 467 minecraft:pearlescent_froglight
fill 222 199 468 222 217 468 minecraft:light_gray_concrete
setblock 222 199 469 minecraft:pearlescent_froglight
fill 222 199 470 222 217 470 minecraft:light_gray_concrete
fill 222 199 496 222 208 496 minecraft:light_gray_concrete
setblock 222 199 497 minecraft:pearlescent_froglight
fill 222 199 498 222 208 498 minecraft:light_gray_concrete
setblock 222 199 499 minecraft:pearlescent_froglight
fill 222 199 500 222 208 500 minecraft:light_gray_concrete
setblock 222 199 501 minecraft:pearlescent_froglight
fill 222 199 502 222 208 502 minecraft:light_gray_concrete
setblock 222 199 503 minecraft:pearlescent_froglight
fill 222 199 504 222 208 504 minecraft:light_gray_concrete
setblock 222 199 505 minecraft:pearlescent_froglight
setblock 223 199 464 minecraft:pearlescent_froglight
fill 223 199 465 223 217 465 minecraft:light_gray_concrete
setblock 223 199 466 minecraft:pearlescent_froglight
fill 223 199 467 223 217 467 minecraft:light_gray_concrete
setblock 223 199 468 minecraft:pearlescent_froglight
fill 223 199 469 223 217 469 minecraft:light_gray_concrete
setblock 223 199 470 minecraft:pearlescent_froglight
setblock 223 199 496 minecraft:pearlescent_froglight
fill 223 199 497 223 208 497 minecraft:light_gray_concrete
setblock 223 199 498 minecraft:pearlescent_froglight
fill 223 199 499 223 208 499 minecraft:light_gray_concrete
setblock 223 199 500 minecraft:pearlescent_froglight
fill 223 199 501 223 208 501 minecraft:light_gray_concrete
setblock 223 199 502 minecraft:pearlescent_froglight
fill 223 199 503 223 208 503 minecraft:light_gray_concrete
setblock 223 199 504 minecraft:pearlescent_froglight
fill 224 199 464 224 217 464 minecraft:light_gray_concrete
setblock 224 199 465 minecraft:pearlescent_froglight
fill 224 199 466 224 217 466 minecraft:light_gray_concrete
setblock 224 199 467 minecraft:pearlescent_froglight
fill 224 199 468 224 217 468 minecraft:light_gray_concrete
setblock 224 199 469 minecraft:pearlescent_froglight
fill 224 199 470 224 217 470 minecraft:light_gray_concrete
fill 224 199 496 224 208 496 minecraft:light_gray_concrete
setblock 224 199 497 minecraft:pearlescent_froglight
fill 224 199 498 224 208 498 minecraft:light_gray_concrete
setblock 224 199 499 minecraft:pearlescent_froglight
fill 224 199 500 224 208 500 minecraft:light_gray_concrete
setblock 224 199 501 minecraft:pearlescent_froglight
fill 224 199 502 224 208 502 minecraft:light_gray_concrete
setblock 224 199 503 minecraft:pearlescent_froglight
fill 224 199 504 224 208 504 minecraft:light_gray_concrete
setblock 224 199 505 minecraft:pearlescent_froglight
setblock 225 199 464 minecraft:pearlescent_froglight
fill 225 199 465 225 217 465 minecraft:light_gray_concrete
setblock 225 199 466 minecraft:pearlescent_froglight
fill 225 199 467 225 217 467 minecraft:light_gray_concrete
setblock 225 199 468 minecraft:pearlescent_froglight
fill 225 199 469 225 217 469 minecraft:light_gray_concrete
setblock 225 199 470 minecraft:pearlescent_froglight
setblock 225 199 496 minecraft:pearlescent_froglight
fill 225 199 497 225 208 497 minecraft:light_gray_concrete
setblock 225 199 498 minecraft:pearlescent_froglight
fill 225 199 499 225 208 499 minecraft:light_gray_concrete
setblock 225 199 500 minecraft:pearlescent_froglight
fill 225 199 501 225 208 501 minecraft:light_gray_concrete
setblock 225 199 502 minecraft:pearlescent_froglight
fill 225 199 503 225 208 503 minecraft:light_gray_concrete
setblock 225 199 504 minecraft:pearlescent_froglight
fill 225 199 505 225 222 505 minecraft:light_gray_terracotta
fill 226 199 464 226 217 464 minecraft:light_gray_concrete
setblock 226 199 465 minecraft:pearlescent_froglight
fill 226 199 466 226 217 466 minecraft:light_gray_concrete
setblock 226 199 467 minecraft:pearlescent_froglight
fill 226 199 468 226 217 468 minecraft:light_gray_concrete
setblock 226 199 469 minecraft:pearlescent_froglight
fill 226 199 470 226 217 470 minecraft:light_gray_concrete
fill 226 199 496 226 208 496 minecraft:light_gray_concrete
setblock 226 199 497 minecraft:pearlescent_froglight
fill 226 199 498 226 208 498 minecraft:light_gray_concrete
setblock 226 199 499 minecraft:pearlescent_froglight
fill 226 199 500 226 208 500 minecraft:light_gray_concrete
setblock 226 199 501 minecraft:pearlescent_froglight
fill 226 199 502 226 208 502 minecraft:light_gray_concrete
setblock 226 199 503 minecraft:pearlescent_froglight
fill 226 199 504 226 208 504 minecraft:light_gray_concrete
setblock 226 199 505 minecraft:pearlescent_froglight
setblock 227 199 464 minecraft:pearlescent_froglight
fill 227 199 465 227 217 465 minecraft:light_gray_concrete
setblock 227 199 466 minecraft:pearlescent_froglight
fill 227 199 467 227 217 467 minecraft:light_gray_concrete
setblock 227 199 468 minecraft:pearlescent_froglight
fill 227 199 469 227 217 469 minecraft:light_gray_concrete
setblock 227 199 470 minecraft:pearlescent_froglight
setblock 227 199 496 minecraft:pearlescent_froglight
fill 227 199 497 227 208 497 minecraft:light_gray_concrete
setblock 227 199 498 minecraft:pearlescent_froglight
fill 227 199 499 227 208 499 minecraft:light_gray_concrete
setblock 227 199 500 minecraft:pearlescent_froglight
fill 227 199 501 227 208 501 minecraft:light_gray_concrete
setblock 227 199 502 minecraft:pearlescent_froglight
fill 227 199 503 227 208 503 minecraft:light_gray_concrete
setblock 227 199 504 minecraft:pearlescent_froglight
fill 227 199 505 227 221 505 minecraft:light_gray_terracotta
fill 228 199 464 228 217 464 minecraft:light_gray_concrete
setblock 228 199 465 minecraft:pearlescent_froglight
fill 228 199 466 228 217 466 minecraft:light_gray_concrete
setblock 228 199 467 minecraft:pearlescent_froglight
fill 228 199 468 228 217 468 minecraft:light_gray_concrete
setblock 228 199 469 minecraft:pearlescent_froglight
fill 228 199 470 228 217 470 minecraft:light_gray_concrete
fill 228 199 496 228 208 496 minecraft:light_gray_concrete
setblock 228 199 497 minecraft:pearlescent_froglight
fill 228 199 498 228 208 498 minecraft:light_gray_concrete
setblock 228 199 499 minecraft:pearlescent_froglight
fill 228 199 500 228 208 500 minecraft:light_gray_concrete
setblock 228 199 501 minecraft:pearlescent_froglight
fill 228 199 502 228 208 502 minecraft:light_gray_concrete
setblock 228 199 503 minecraft:pearlescent_froglight
fill 228 199 504 228 235 504 minecraft:light_gray_concrete
setblock 228 199 505 minecraft:pearlescent_froglight
fill 229 199 465 229 235 465 minecraft:light_gray_concrete
setblock 229 199 496 minecraft:pearlescent_froglight
fill 229 199 497 229 235 497 minecraft:light_gray_concrete
setblock 229 199 498 minecraft:pearlescent_froglight
fill 229 199 499 229 208 499 minecraft:light_gray_concrete
setblock 229 199 500 minecraft:pearlescent_froglight
fill 229 199 501 229 208 501 minecraft:light_gray_concrete
setblock 229 199 502 minecraft:pearlescent_froglight
fill 229 199 503 229 208 503 minecraft:light_gray_concrete
setblock 229 199 504 minecraft:pearlescent_froglight
fill 188 200 468 188 205 468 minecraft:pearlescent_froglight
fill 188 200 476 188 205 476 minecraft:pearlescent_froglight
fill 188 200 484 188 205 484 minecraft:pearlescent_froglight
fill 188 200 492 188 205 492 minecraft:pearlescent_froglight
fill 188 200 500 188 205 500 minecraft:pearlescent_froglight
fill 191 200 505 191 205 505 minecraft:pearlescent_froglight
fill 195 200 463 195 205 463 minecraft:pearlescent_froglight
fill 199 200 505 199 205 505 minecraft:pearlescent_froglight
fill 202 200 478 205 201 478 minecraft:red_nether_bricks
fill 202 200 486 205 201 486 minecraft:red_nether_bricks
fill 203 200 463 203 205 463 minecraft:pearlescent_froglight
fill 203 200 480 203 201 480 minecraft:red_nether_bricks
fill 203 200 484 203 201 484 minecraft:red_nether_bricks
fill 207 200 505 207 205 505 minecraft:pearlescent_froglight
fill 209 200 478 212 201 478 minecraft:red_nether_bricks
fill 209 200 486 212 201 486 minecraft:red_nether_bricks
fill 211 200 463 211 205 463 minecraft:pearlescent_froglight
fill 211 200 480 211 201 480 minecraft:red_nether_bricks
fill 211 200 484 211 201 484 minecraft:red_nether_bricks
fill 212 200 479 213 203 479 minecraft:red_nether_bricks
setblock 212 200 480 minecraft:nether_bricks
setblock 212 200 484 minecraft:nether_bricks
fill 212 200 485 213 203 485 minecraft:red_nether_bricks
fill 214 200 479 216 200 479 minecraft:nether_bricks
fill 214 200 485 216 200 485 minecraft:nether_bricks
fill 215 200 505 215 205 505 minecraft:pearlescent_froglight
fill 218 200 465 218 201 465 minecraft:light_gray_concrete
fill 218 200 467 218 201 467 minecraft:light_gray_concrete
fill 218 200 469 218 201 469 minecraft:light_gray_concrete
fill 219 200 463 219 205 463 minecraft:pearlescent_froglight
fill 219 200 464 219 201 464 minecraft:light_gray_concrete
fill 219 200 466 219 201 466 minecraft:light_gray_concrete
fill 219 200 468 219 201 468 minecraft:light_gray_concrete
fill 219 200 470 219 201 470 minecraft:light_gray_concrete
setblock 219 200 482 minecraft:nether_bricks
fill 220 200 465 220 201 465 minecraft:light_gray_concrete
fill 220 200 467 220 201 467 minecraft:light_gray_concrete
fill 220 200 469 220 201 469 minecraft:light_gray_concrete
fill 221 200 464 221 201 464 minecraft:light_gray_concrete
fill 221 200 466 221 201 466 minecraft:light_gray_concrete
fill 221 200 468 221 201 468 minecraft:light_gray_concrete
fill 221 200 470 221 201 470 minecraft:light_gray_concrete
fill 222 200 465 222 201 465 minecraft:light_gray_concrete
fill 222 200 467 222 201 467 minecraft:light_gray_concrete
fill 222 200 469 222 201 469 minecraft:light_gray_concrete
fill 222 200 497 222 201 497 minecraft:light_gray_concrete
fill 222 200 499 222 201 499 minecraft:light_gray_concrete
fill 222 200 501 222 201 501 minecraft:light_gray_concrete
fill 222 200 503 222 201 503 minecraft:light_gray_concrete
fill 222 200 505 222 201 505 minecraft:light_gray_terracotta
fill 223 200 464 223 201 464 minecraft:light_gray_concrete
fill 223 200 466 223 201 466 minecraft:light_gray_concrete
fill 223 200 468 223 201 468 minecraft:light_gray_concrete
fill 223 200 470 223 201 470 minecraft:light_gray_concrete
fill 223 200 496 223 201 496 minecraft:light_gray_concrete
fill 223 200 498 223 201 498 minecraft:light_gray_concrete
fill 223 200 500 223 201 500 minecraft:light_gray_concrete
fill 223 200 502 223 201 502 minecraft:light_gray_concrete
fill 223 200 504 223 201 504 minecraft:light_gray_concrete
fill 223 200 505 223 205 505 minecraft:pearlescent_froglight
fill 224 200 465 224 201 465 minecraft:light_gray_concrete
fill 224 200 467 224 201 467 minecraft:light_gray_concrete
fill 224 200 469 224 201 469 minecraft:light_gray_concrete
fill 224 200 497 224 201 497 minecraft:light_gray_concrete
fill 224 200 499 224 201 499 minecraft:light_gray_concrete
fill 224 200 501 224 201 501 minecraft:light_gray_concrete
fill 224 200 503 224 201 503 minecraft:light_gray_concrete
fill 224 200 505 224 201 505 minecraft:light_gray_terracotta
fill 225 200 464 225 201 464 minecraft:light_gray_concrete
fill 225 200 466 225 201 466 minecraft:light_gray_concrete
fill 225 200 468 225 201 468 minecraft:light_gray_concrete
fill 225 200 470 225 201 470 minecraft:light_gray_concrete
fill 225 200 496 225 201 496 minecraft:light_gray_concrete
fill 225 200 498 225 201 498 minecraft:light_gray_concrete
fill 225 200 500 225 201 500 minecraft:light_gray_concrete
fill 225 200 502 225 201 502 minecraft:light_gray_concrete
fill 225 200 504 225 201 504 minecraft:light_gray_concrete
fill 226 200 465 226 201 465 minecraft:light_gray_concrete
fill 226 200 467 226 201 467 minecraft:light_gray_concrete
fill 226 200 469 226 201 469 minecraft:light_gray_concrete
fill 226 200 497 226 201 497 minecraft:light_gray_concrete
fill 226 200 499 226 201 499 minecraft:light_gray_concrete
fill 226 200 501 226 201 501 minecraft:light_gray_concrete
fill 226 200 503 226 201 503 minecraft:light_gray_concrete
fill 226 200 505 226 201 505 minecraft:light_gray_terracotta
fill 227 200 463 227 205 463 minecraft:pearlescent_froglight
fill 227 200 464 227 201 464 minecraft:light_gray_concrete
fill 227 200 466 227 201 466 minecraft:light_gray_concrete
fill 227 200 468 227 201 468 minecraft:light_gray_concrete
fill 227 200 470 227 201 470 minecraft:light_gray_concrete
fill 227 200 496 227 201 496 minecraft:light_gray_concrete
fill 227 200 498 227 201 498 minecraft:light_gray_concrete
fill 227 200 500 227 201 500 minecraft:light_gray_concrete
fill 227 200 502 227 201 502 minecraft:light_gray_concrete
fill 227 200 504 227 201 504 minecraft:light_gray_concrete
fill 228 200 465 228 201 465 minecraft:light_gray_concrete
fill 228 200 467 228 201 467 minecraft:light_gray_concrete
fill 228 200 469 228 201 469 minecraft:light_gray_concrete
fill 228 200 497 228 201 497 minecraft:light_gray_concrete
fill 228 200 499 228 201 499 minecraft:light_gray_concrete
fill 228 200 501 228 201 501 minecraft:light_gray_concrete
fill 228 200 503 228 201 503 minecraft:light_gray_concrete
fill 228 200 505 228 201 505 minecraft:light_gray_terracotta
fill 229 200 496 229 201 496 minecraft:light_gray_concrete
fill 229 200 498 229 201 498 minecraft:light_gray_concrete
fill 229 200 500 229 201 500 minecraft:light_gray_concrete
fill 229 200 502 229 201 502 minecraft:light_gray_concrete
fill 229 200 504 229 201 504 minecraft:light_gray_concrete
fill 230 200 468 230 205 468 minecraft:pearlescent_froglight
fill 230 200 476 230 205 476 minecraft:pearlescent_froglight
fill 230 200 484 230 205 484 minecraft:pearlescent_froglight
fill 230 200 492 230 205 492 minecraft:pearlescent_froglight
fill 230 200 500 230 205 500 minecraft:pearlescent_froglight
fill 201 201 479 203 202 479 minecraft:red_nether_bricks
fill 201 201 485 203 202 485 minecraft:red_nether_bricks
setblock 204 201 475 minecraft:red_nether_bricks
setblock 204 201 489 minecraft:red_nether_bricks
setblock 205 201 475 minecraft:black_concrete
setblock 205 201 489 minecraft:black_concrete
fill 206 201 475 210 201 475 minecraft:red_nether_bricks
fill 206 201 489 210 201 489 minecraft:red_nether_bricks
fill 211 201 479 211 202 479 minecraft:red_nether_bricks
fill 211 201 485 211 202 485 minecraft:red_nether_bricks
fill 212 201 480 213 202 484 minecraft:red_nether_bricks
fill 214 201 479 215 202 481 minecraft:red_nether_bricks
fill 214 201 482 216 201 482 minecraft:nether_bricks
fill 214 201 483 215 202 485 minecraft:red_nether_bricks
fill 216 201 480 216 201 481 minecraft:red_nether_bricks
fill 216 201 483 216 201 484 minecraft:red_nether_bricks
fill 202 202 474 205 202 474 minecraft:black_concrete
fill 202 202 478 204 202 478 minecraft:red_nether_bricks
fill 202 202 486 204 202 486 minecraft:red_nether_bricks
fill 202 202 490 205 202 490 minecraft:black_concrete
fill 203 202 477 209 202 477 minecraft:red_nether_bricks
fill 203 202 487 209 202 487 minecraft:red_nether_bricks
fill 206 202 475 208 202 475 minecraft:red_nether_bricks
fill 206 202 489 208 202 489 minecraft:red_nether_bricks
fill 210 202 477 210 202 478 minecraft:shroomlight
fill 210 202 486 210 202 487 minecraft:shroomlight
fill 211 202 477 211 202 478 minecraft:red_nether_bricks
fill 211 202 486 211 202 487 minecraft:red_nether_bricks
fill 212 202 478 214 202 478 minecraft:red_nether_bricks
fill 212 202 486 214 202 486 minecraft:red_nether_bricks
fill 214 202 482 215 203 482 minecraft:red_nether_bricks
setblock 218 202 465 minecraft:pearlescent_froglight
setblock 218 202 467 minecraft:pearlescent_froglight
setblock 218 202 469 minecraft:pearlescent_froglight
setblock 219 202 464 minecraft:pearlescent_froglight
setblock 219 202 466 minecraft:pearlescent_froglight
setblock 219 202 468 minecraft:pearlescent_froglight
setblock 219 202 470 minecraft:pearlescent_froglight
setblock 220 202 465 minecraft:pearlescent_froglight
setblock 220 202 467 minecraft:pearlescent_froglight
setblock 220 202 469 minecraft:pearlescent_froglight
setblock 221 202 464 minecraft:pearlescent_froglight
setblock 221 202 466 minecraft:pearlescent_froglight
setblock 221 202 468 minecraft:pearlescent_froglight
setblock 221 202 470 minecraft:pearlescent_froglight
setblock 222 202 465 minecraft:pearlescent_froglight
setblock 222 202 467 minecraft:pearlescent_froglight
setblock 222 202 469 minecraft:pearlescent_froglight
setblock 222 202 497 minecraft:pearlescent_froglight
setblock 222 202 499 minecraft:pearlescent_froglight
setblock 222 202 501 minecraft:pearlescent_froglight
setblock 222 202 503 minecraft:pearlescent_froglight
setblock 222 202 505 minecraft:pearlescent_froglight
setblock 223 202 464 minecraft:pearlescent_froglight
setblock 223 202 466 minecraft:pearlescent_froglight
setblock 223 202 468 minecraft:pearlescent_froglight
setblock 223 202 470 minecraft:pearlescent_froglight
setblock 223 202 496 minecraft:pearlescent_froglight
setblock 223 202 498 minecraft:pearlescent_froglight
setblock 223 202 500 minecraft:pearlescent_froglight
setblock 223 202 502 minecraft:pearlescent_froglight
setblock 223 202 504 minecraft:pearlescent_froglight
setblock 224 202 465 minecraft:pearlescent_froglight
setblock 224 202 467 minecraft:pearlescent_froglight
setblock 224 202 469 minecraft:pearlescent_froglight
setblock 224 202 497 minecraft:pearlescent_froglight
setblock 224 202 499 minecraft:pearlescent_froglight
setblock 224 202 501 minecraft:pearlescent_froglight
setblock 224 202 503 minecraft:pearlescent_froglight
setblock 224 202 505 minecraft:pearlescent_froglight
setblock 225 202 464 minecraft:pearlescent_froglight
setblock 225 202 466 minecraft:pearlescent_froglight
setblock 225 202 468 minecraft:pearlescent_froglight
setblock 225 202 470 minecraft:pearlescent_froglight
setblock 225 202 496 minecraft:pearlescent_froglight
setblock 225 202 498 minecraft:pearlescent_froglight
setblock 225 202 500 minecraft:pearlescent_froglight
setblock 225 202 502 minecraft:pearlescent_froglight
setblock 225 202 504 minecraft:pearlescent_froglight
setblock 226 202 465 minecraft:pearlescent_froglight
setblock 226 202 467 minecraft:pearlescent_froglight
setblock 226 202 469 minecraft:pearlescent_froglight
setblock 226 202 497 minecraft:pearlescent_froglight
setblock 226 202 499 minecraft:pearlescent_froglight
setblock 226 202 501 minecraft:pearlescent_froglight
setblock 226 202 503 minecraft:pearlescent_froglight
setblock 226 202 505 minecraft:pearlescent_froglight
setblock 227 202 464 minecraft:pearlescent_froglight
setblock 227 202 466 minecraft:pearlescent_froglight
setblock 227 202 468 minecraft:pearlescent_froglight
setblock 227 202 470 minecraft:pearlescent_froglight
setblock 227 202 496 minecraft:pearlescent_froglight
setblock 227 202 498 minecraft:pearlescent_froglight
setblock 227 202 500 minecraft:pearlescent_froglight
setblock 227 202 502 minecraft:pearlescent_froglight
setblock 227 202 504 minecraft:pearlescent_froglight
setblock 228 202 465 minecraft:pearlescent_froglight
setblock 228 202 467 minecraft:pearlescent_froglight
setblock 228 202 469 minecraft:pearlescent_froglight
setblock 228 202 497 minecraft:pearlescent_froglight
setblock 228 202 499 minecraft:pearlescent_froglight
setblock 228 202 501 minecraft:pearlescent_froglight
setblock 228 202 503 minecraft:pearlescent_froglight
setblock 228 202 505 minecraft:pearlescent_froglight
setblock 229 202 496 minecraft:pearlescent_froglight
setblock 229 202 498 minecraft:pearlescent_froglight
setblock 229 202 500 minecraft:pearlescent_froglight
setblock 229 202 502 minecraft:pearlescent_froglight
setblock 229 202 504 minecraft:pearlescent_froglight
fill 199 203 472 201 203 472 minecraft:black_concrete
fill 199 203 482 201 203 482 minecraft:red_nether_bricks
fill 199 203 492 201 203 492 minecraft:black_concrete
fill 200 203 473 204 203 473 minecraft:black_concrete
fill 200 203 480 202 203 481 minecraft:red_nether_bricks
fill 200 203 483 202 203 484 minecraft:red_nether_bricks
fill 200 203 491 204 203 491 minecraft:black_concrete
fill 201 203 479 202 203 479 minecraft:red_nether_bricks
fill 201 203 485 202 203 485 minecraft:red_nether_bricks
fill 202 203 478 203 203 478 minecraft:red_nether_bricks
fill 202 203 486 203 203 486 minecraft:red_nether_bricks
fill 203 203 477 206 203 477 minecraft:red_nether_bricks
fill 203 203 487 206 203 487 minecraft:red_nether_bricks
setblock 205 203 474 minecraft:black_concrete
setblock 205 203 476 minecraft:red_nether_bricks
setblock 205 203 488 minecraft:red_nether_bricks
setblock 205 203 490 minecraft:black_concrete
setblock 208 203 477 minecraft:red_nether_bricks
setblock 208 203 487 minecraft:red_nether_bricks
setblock 209 203 476 minecraft:red_nether_bricks
fill 209 203 477 211 203 477 minecraft:shroomlight
fill 209 203 487 211 203 487 minecraft:shroomlight
setblock 209 203 488 minecraft:red_nether_bricks
setblock 211 203 478 minecraft:shroomlight
setblock 211 203 486 minecraft:shroomlight
fill 212 203 478 213 203 478 minecraft:red_nether_bricks
fill 212 203 480 214 203 481 minecraft:red_nether_bricks
fill 212 203 483 214 203 484 minecraft:red_nether_bricks
fill 212 203 486 213 203 486 minecraft:red_nether_bricks
fill 213 203 482 213 204 482 minecraft:red_nether_bricks
setblock 214 203 479 minecraft:red_nether_bricks
setblock 214 203 485 minecraft:red_nether_bricks
fill 218 203 465 218 204 465 minecraft:light_gray_concrete
fill 218 203 467 218 204 467 minecraft:light_gray_concrete
fill 218 203 469 218 204 469 minecraft:light_gray_concrete
fill 219 203 464 219 204 464 minecraft:light_gray_concrete
fill 219 203 466 219 204 466 minecraft:light_gray_concrete
fill 219 203 468 219 204 468 minecraft:light_gray_concrete
fill 219 203 470 219 204 470 minecraft:light_gray_concrete
fill 220 203 465 220 204 465 minecraft:light_gray_concrete
fill 220 203 467 220 204 467 minecraft:light_gray_concrete
fill 220 203 469 220 204 469 minecraft:light_gray_concrete
fill 221 203 464 221 204 464 minecraft:light_gray_concrete
fill 221 203 466 221 204 466 minecraft:light_gray_concrete
fill 221 203 468 221 204 468 minecraft:light_gray_concrete
fill 221 203 470 221 204 470 minecraft:light_gray_concrete
fill 222 203 465 222 204 465 minecraft:light_gray_concrete
fill 222 203 467 222 204 467 minecraft:light_gray_concrete
fill 222 203 469 222 204 469 minecraft:light_gray_concrete
fill 222 203 497 222 204 497 minecraft:light_gray_concrete
fill 222 203 499 222 204 499 minecraft:light_gray_concrete
fill 222 203 501 222 204 501 minecraft:light_gray_concrete
fill 222 203 503 222 204 503 minecraft:light_gray_concrete
fill 222 203 505 222 204 505 minecraft:light_gray_terracotta
fill 223 203 464 223 204 464 minecraft:light_gray_concrete
fill 223 203 466 223 204 466 minecraft:light_gray_concrete
fill 223 203 468 223 204 468 minecraft:light_gray_concrete
fill 223 203 470 223 204 470 minecraft:light_gray_concrete
fill 223 203 496 223 204 496 minecraft:light_gray_concrete
fill 223 203 498 223 204 498 minecraft:light_gray_concrete
fill 223 203 500 223 204 500 minecraft:light_gray_concrete
fill 223 203 502 223 204 502 minecraft:light_gray_concrete
fill 223 203 504 223 204 504 minecraft:light_gray_concrete
fill 224 203 465 224 204 465 minecraft:light_gray_concrete
fill 224 203 467 224 204 467 minecraft:light_gray_concrete
fill 224 203 469 224 204 469 minecraft:light_gray_concrete
fill 224 203 497 224 204 497 minecraft:light_gray_concrete
fill 224 203 499 224 204 499 minecraft:light_gray_concrete
fill 224 203 501 224 204 501 minecraft:light_gray_concrete
fill 224 203 503 224 204 503 minecraft:light_gray_concrete
fill 224 203 505 224 204 505 minecraft:light_gray_terracotta
fill 225 203 464 225 204 464 minecraft:light_gray_concrete
fill 225 203 466 225 204 466 minecraft:light_gray_concrete
fill 225 203 468 225 204 468 minecraft:light_gray_concrete
fill 225 203 470 225 204 470 minecraft:light_gray_concrete
fill 225 203 496 225 204 496 minecraft:light_gray_concrete
fill 225 203 498 225 204 498 minecraft:light_gray_concrete
fill 225 203 500 225 204 500 minecraft:light_gray_concrete
fill 225 203 502 225 204 502 minecraft:light_gray_concrete
fill 225 203 504 225 204 504 minecraft:light_gray_concrete
fill 226 203 465 226 204 465 minecraft:light_gray_concrete
fill 226 203 467 226 204 467 minecraft:light_gray_concrete
fill 226 203 469 226 204 469 minecraft:light_gray_concrete
fill 226 203 497 226 204 497 minecraft:light_gray_concrete
fill 226 203 499 226 204 499 minecraft:light_gray_concrete
fill 226 203 501 226 204 501 minecraft:light_gray_concrete
fill 226 203 503 226 204 503 minecraft:light_gray_concrete
fill 226 203 505 226 204 505 minecraft:light_gray_terracotta
fill 227 203 464 227 204 464 minecraft:light_gray_concrete
fill 227 203 466 227 204 466 minecraft:light_gray_concrete
fill 227 203 468 227 204 468 minecraft:light_gray_concrete
fill 227 203 470 227 204 470 minecraft:light_gray_concrete
fill 227 203 496 227 204 496 minecraft:light_gray_concrete
fill 227 203 498 227 204 498 minecraft:light_gray_concrete
fill 227 203 500 227 204 500 minecraft:light_gray_concrete
fill 227 203 502 227 204 502 minecraft:light_gray_concrete
fill 227 203 504 227 204 504 minecraft:light_gray_concrete
fill 228 203 465 228 204 465 minecraft:light_gray_concrete
fill 228 203 467 228 204 467 minecraft:light_gray_concrete
fill 228 203 469 228 204 469 minecraft:light_gray_concrete
fill 228 203 497 228 204 497 minecraft:light_gray_concrete
fill 228 203 499 228 204 499 minecraft:light_gray_concrete
fill 228 203 501 228 204 501 minecraft:light_gray_concrete
fill 228 203 503 228 204 503 minecraft:light_gray_concrete
fill 228 203 505 228 204 505 minecraft:light_gray_terracotta
fill 229 203 496 229 204 496 minecraft:light_gray_concrete
fill 229 203 498 229 204 498 minecraft:light_gray_concrete
fill 229 203 500 229 204 500 minecraft:light_gray_concrete
fill 229 203 502 229 204 502 minecraft:light_gray_concrete
fill 229 203 504 229 204 504 minecraft:light_gray_concrete
setblock 191 204 466 minecraft:light[level=11]
setblock 191 204 474 minecraft:light[level=11]
setblock 191 204 482 minecraft:light[level=11]
setblock 191 204 490 minecraft:light[level=11]
setblock 191 204 498 minecraft:light[level=11]
setblock 197 204 471 minecraft:black_concrete
setblock 197 204 493 minecraft:black_concrete
setblock 199 204 466 minecraft:light[level=11]
setblock 199 204 474 minecraft:light[level=11]
setblock 199 204 482 minecraft:light[level=11]
setblock 199 204 490 minecraft:light[level=11]
setblock 199 204 498 minecraft:light[level=11]
setblock 200 204 471 minecraft:black_concrete
setblock 200 204 493 minecraft:black_concrete
fill 201 204 472 202 204 472 minecraft:black_concrete
fill 201 204 480 201 204 484 minecraft:red_nether_bricks
fill 201 204 492 202 204 492 minecraft:black_concrete
fill 202 204 479 202 204 480 minecraft:red_nether_bricks
fill 202 204 484 202 204 485 minecraft:red_nether_bricks
fill 203 204 478 203 205 478 minecraft:blackstone
fill 203 204 486 203 205 486 minecraft:blackstone
setblock 204 204 472 minecraft:black_concrete
fill 204 204 477 204 205 477 minecraft:blackstone
fill 204 204 487 204 205 487 minecraft:blackstone
setblock 204 204 492 minecraft:black_concrete
setblock 205 204 473 minecraft:black_concrete
setblock 205 204 477 minecraft:red_nether_bricks
setblock 205 204 487 minecraft:red_nether_bricks
setblock 205 204 491 minecraft:black_concrete
setblock 207 204 466 minecraft:light[level=11]
setblock 207 204 474 minecraft:light[level=11]
setblock 207 204 490 minecraft:light[level=11]
setblock 207 204 498 minecraft:light[level=11]
setblock 209 204 477 minecraft:red_nether_bricks
setblock 209 204 487 minecraft:red_nether_bricks
setblock 211 204 478 minecraft:red_nether_bricks
setblock 211 204 486 minecraft:red_nether_bricks
fill 212 204 479 212 204 480 minecraft:red_nether_bricks
fill 212 204 484 212 204 485 minecraft:red_nether_bricks
fill 213 204 480 213 204 481 minecraft:red_nether_bricks
fill 213 204 483 213 204 484 minecraft:red_nether_bricks
setblock 215 204 466 minecraft:light[level=11]
setblock 215 204 474 minecraft:light[level=11]
setblock 215 204 482 minecraft:light[level=11]
setblock 215 204 490 minecraft:light[level=11]
setblock 215 204 498 minecraft:light[level=11]
setblock 223 204 474 minecraft:light[level=11]
setblock 223 204 482 minecraft:light[level=11]
setblock 223 204 490 minecraft:light[level=11]
fill 193 205 469 194 205 469 minecraft:black_concrete
fill 193 205 495 194 205 495 minecraft:black_concrete
fill 194 205 470 195 205 470 minecraft:black_concrete
fill 194 205 494 195 205 494 minecraft:black_concrete
fill 198 205 470 199 205 470 minecraft:black_concrete
fill 198 205 494 199 205 494 minecraft:black_concrete
setblock 201 205 471 minecraft:black_concrete
setblock 201 205 493 minecraft:black_concrete
fill 203 205 471 203 206 471 minecraft:black_concrete
fill 203 205 477 203 207 477 minecraft:blackstone
fill 203 205 487 203 207 487 minecraft:blackstone
fill 203 205 493 203 206 493 minecraft:black_concrete
fill 205 205 472 205 206 472 minecraft:black_concrete
fill 205 205 492 205 206 492 minecraft:black_concrete
fill 213 205 500 213 205 502 minecraft:light_gray_concrete
fill 214 205 499 216 205 499 minecraft:light_gray_concrete
fill 214 205 503 216 205 503 minecraft:light_gray_concrete
fill 217 205 500 217 205 502 minecraft:light_gray_concrete
setblock 218 205 465 minecraft:pearlescent_froglight
setblock 218 205 467 minecraft:pearlescent_froglight
setblock 218 205 469 minecraft:pearlescent_froglight
setblock 219 205 464 minecraft:pearlescent_froglight
setblock 219 205 466 minecraft:pearlescent_froglight
setblock 219 205 468 minecraft:pearlescent_froglight
setblock 219 205 470 minecraft:pearlescent_froglight
setblock 220 205 465 minecraft:pearlescent_froglight
setblock 220 205 467 minecraft:pearlescent_froglight
setblock 220 205 469 minecraft:pearlescent_froglight
setblock 221 205 464 minecraft:pearlescent_froglight
setblock 221 205 466 minecraft:pearlescent_froglight
setblock 221 205 468 minecraft:pearlescent_froglight
setblock 221 205 470 minecraft:pearlescent_froglight
setblock 222 205 465 minecraft:pearlescent_froglight
setblock 222 205 467 minecraft:pearlescent_froglight
setblock 222 205 469 minecraft:pearlescent_froglight
setblock 222 205 497 minecraft:pearlescent_froglight
setblock 222 205 499 minecraft:pearlescent_froglight
setblock 222 205 501 minecraft:pearlescent_froglight
setblock 222 205 503 minecraft:pearlescent_froglight
setblock 222 205 505 minecraft:pearlescent_froglight
setblock 223 205 464 minecraft:pearlescent_froglight
setblock 223 205 466 minecraft:pearlescent_froglight
setblock 223 205 468 minecraft:pearlescent_froglight
setblock 223 205 470 minecraft:pearlescent_froglight
setblock 223 205 496 minecraft:pearlescent_froglight
setblock 223 205 498 minecraft:pearlescent_froglight
setblock 223 205 500 minecraft:pearlescent_froglight
setblock 223 205 502 minecraft:pearlescent_froglight
setblock 223 205 504 minecraft:pearlescent_froglight
setblock 224 205 465 minecraft:pearlescent_froglight
setblock 224 205 467 minecraft:pearlescent_froglight
setblock 224 205 469 minecraft:pearlescent_froglight
setblock 224 205 497 minecraft:pearlescent_froglight
setblock 224 205 499 minecraft:pearlescent_froglight
setblock 224 205 501 minecraft:pearlescent_froglight
setblock 224 205 503 minecraft:pearlescent_froglight
setblock 224 205 505 minecraft:pearlescent_froglight
setblock 225 205 464 minecraft:pearlescent_froglight
setblock 225 205 466 minecraft:pearlescent_froglight
setblock 225 205 468 minecraft:pearlescent_froglight
setblock 225 205 470 minecraft:pearlescent_froglight
setblock 225 205 496 minecraft:pearlescent_froglight
setblock 225 205 498 minecraft:pearlescent_froglight
setblock 225 205 500 minecraft:pearlescent_froglight
setblock 225 205 502 minecraft:pearlescent_froglight
setblock 225 205 504 minecraft:pearlescent_froglight
setblock 226 205 465 minecraft:pearlescent_froglight
setblock 226 205 467 minecraft:pearlescent_froglight
setblock 226 205 469 minecraft:pearlescent_froglight
setblock 226 205 497 minecraft:pearlescent_froglight
setblock 226 205 499 minecraft:pearlescent_froglight
setblock 226 205 501 minecraft:pearlescent_froglight
setblock 226 205 503 minecraft:pearlescent_froglight
setblock 226 205 505 minecraft:pearlescent_froglight
setblock 227 205 464 minecraft:pearlescent_froglight
setblock 227 205 466 minecraft:pearlescent_froglight
setblock 227 205 468 minecraft:pearlescent_froglight
setblock 227 205 470 minecraft:pearlescent_froglight
setblock 227 205 496 minecraft:pearlescent_froglight
setblock 227 205 498 minecraft:pearlescent_froglight
setblock 227 205 500 minecraft:pearlescent_froglight
setblock 227 205 502 minecraft:pearlescent_froglight
setblock 227 205 504 minecraft:pearlescent_froglight
setblock 228 205 465 minecraft:pearlescent_froglight
setblock 228 205 467 minecraft:pearlescent_froglight
setblock 228 205 469 minecraft:pearlescent_froglight
setblock 228 205 497 minecraft:pearlescent_froglight
setblock 228 205 499 minecraft:pearlescent_froglight
setblock 228 205 501 minecraft:pearlescent_froglight
setblock 228 205 503 minecraft:pearlescent_froglight
setblock 228 205 505 minecraft:pearlescent_froglight
setblock 229 205 496 minecraft:pearlescent_froglight
setblock 229 205 498 minecraft:pearlescent_froglight
setblock 229 205 500 minecraft:pearlescent_froglight
setblock 229 205 502 minecraft:pearlescent_froglight
setblock 229 205 504 minecraft:pearlescent_froglight
fill 188 206 468 188 213 468 minecraft:light_gray_terracotta
fill 188 206 476 188 213 476 minecraft:light_gray_terracotta
fill 188 206 484 188 213 484 minecraft:light_gray_terracotta
fill 188 206 492 188 213 492 minecraft:light_gray_terracotta
fill 188 206 500 188 213 500 minecraft:light_gray_terracotta
fill 191 206 505 191 213 505 minecraft:light_gray_terracotta
setblock 193 206 469 minecraft:black_concrete
setblock 193 206 495 minecraft:black_concrete
fill 195 206 463 195 213 463 minecraft:light_gray_terracotta
fill 196 206 468 196 207 468 minecraft:black_concrete
fill 196 206 496 196 207 496 minecraft:black_concrete
setblock 197 206 469 minecraft:black_concrete
setblock 197 206 495 minecraft:black_concrete
fill 199 206 505 199 213 505 minecraft:light_gray_terracotta
fill 200 206 470 200 207 470 minecraft:black_concrete
fill 200 206 494 200 207 494 minecraft:black_concrete
fill 202 206 476 202 208 477 minecraft:blackstone
fill 202 206 487 202 208 488 minecraft:blackstone
fill 203 206 463 203 213 463 minecraft:light_gray_terracotta
fill 203 206 470 203 207 470 minecraft:black_concrete
fill 203 206 476 203 207 476 minecraft:blackstone
fill 203 206 488 203 207 488 minecraft:blackstone
fill 203 206 494 203 207 494 minecraft:black_concrete
fill 205 206 471 205 207 471 minecraft:black_concrete
fill 205 206 493 205 207 493 minecraft:black_concrete
fill 207 206 505 207 213 505 minecraft:light_gray_terracotta
fill 211 206 463 211 213 463 minecraft:light_gray_terracotta
fill 215 206 505 215 213 505 minecraft:light_gray_terracotta
fill 218 206 465 218 207 465 minecraft:light_gray_concrete
fill 218 206 467 218 207 467 minecraft:light_gray_concrete
fill 218 206 469 218 207 469 minecraft:light_gray_concrete
fill 219 206 463 219 213 463 minecraft:light_gray_terracotta
fill 219 206 464 219 207 464 minecraft:light_gray_concrete
fill 219 206 466 219 207 466 minecraft:light_gray_concrete
fill 219 206 468 219 207 468 minecraft:light_gray_concrete
fill 219 206 470 219 207 470 minecraft:light_gray_concrete
fill 220 206 465 220 207 465 minecraft:light_gray_concrete
fill 220 206 467 220 207 467 minecraft:light_gray_concrete
fill 220 206 469 220 207 469 minecraft:light_gray_concrete
fill 221 206 464 221 207 464 minecraft:light_gray_concrete
fill 221 206 466 221 207 466 minecraft:light_gray_concrete
fill 221 206 468 221 207 468 minecraft:light_gray_concrete
fill 221 206 470 221 207 470 minecraft:light_gray_concrete
fill 222 206 465 222 207 465 minecraft:light_gray_concrete
fill 222 206 467 222 207 467 minecraft:light_gray_concrete
fill 222 206 469 222 207 469 minecraft:light_gray_concrete
fill 222 206 497 222 208 497 minecraft:light_gray_concrete
fill 222 206 499 222 208 499 minecraft:light_gray_concrete
fill 222 206 501 222 208 501 minecraft:light_gray_concrete
fill 222 206 503 222 208 503 minecraft:light_gray_concrete
fill 222 206 505 224 213 505 minecraft:light_gray_terracotta
fill 223 206 464 223 207 464 minecraft:light_gray_concrete
fill 223 206 466 223 207 466 minecraft:light_gray_concrete
fill 223 206 468 223 207 468 minecraft:light_gray_concrete
fill 223 206 470 223 207 470 minecraft:light_gray_concrete
fill 223 206 496 223 208 496 minecraft:light_gray_concrete
fill 223 206 498 223 208 498 minecraft:light_gray_concrete
fill 223 206 500 223 208 500 minecraft:light_gray_concrete
fill 223 206 502 223 208 502 minecraft:light_gray_concrete
fill 223 206 504 223 208 504 minecraft:light_gray_concrete
fill 224 206 465 224 207 465 minecraft:light_gray_concrete
fill 224 206 467 224 207 467 minecraft:light_gray_concrete
fill 224 206 469 224 207 469 minecraft:light_gray_concrete
fill 224 206 497 224 208 497 minecraft:light_gray_concrete
fill 224 206 499 224 208 499 minecraft:light_gray_concrete
fill 224 206 501 224 208 501 minecraft:light_gray_concrete
fill 224 206 503 224 208 503 minecraft:light_gray_concrete
fill 225 206 464 225 207 464 minecraft:light_gray_concrete
fill 225 206 466 225 207 466 minecraft:light_gray_concrete
fill 225 206 468 225 207 468 minecraft:light_gray_concrete
fill 225 206 470 225 207 470 minecraft:light_gray_concrete
fill 225 206 496 225 208 496 minecraft:light_gray_concrete
fill 225 206 498 225 208 498 minecraft:light_gray_concrete
fill 225 206 500 225 208 500 minecraft:light_gray_concrete
fill 225 206 502 225 208 502 minecraft:light_gray_concrete
fill 225 206 504 225 208 504 minecraft:light_gray_concrete
fill 226 206 465 226 207 465 minecraft:light_gray_concrete
fill 226 206 467 226 207 467 minecraft:light_gray_concrete
fill 226 206 469 226 207 469 minecraft:light_gray_concrete
fill 226 206 497 226 208 497 minecraft:light_gray_concrete
fill 226 206 499 226 208 499 minecraft:light_gray_concrete
fill 226 206 501 226 208 501 minecraft:light_gray_concrete
fill 226 206 503 226 208 503 minecraft:light_gray_concrete
fill 226 206 505 226 221 505 minecraft:light_gray_terracotta
fill 227 206 463 227 213 463 minecraft:light_gray_terracotta
fill 227 206 464 227 207 464 minecraft:light_gray_concrete
fill 227 206 466 227 207 466 minecraft:light_gray_concrete
fill 227 206 468 227 207 468 minecraft:light_gray_concrete
fill 227 206 470 227 207 470 minecraft:light_gray_concrete
fill 227 206 496 227 208 496 minecraft:light_gray_concrete
fill 227 206 498 227 208 498 minecraft:light_gray_concrete
fill 227 206 500 227 208 500 minecraft:light_gray_concrete
fill 227 206 502 227 208 502 minecraft:light_gray_concrete
fill 227 206 504 227 235 504 minecraft:light_gray_concrete
fill 228 206 465 228 207 465 minecraft:light_gray_concrete
fill 228 206 467 228 207 467 minecraft:light_gray_concrete
fill 228 206 469 228 207 469 minecraft:light_gray_concrete
fill 228 206 497 228 208 497 minecraft:light_gray_concrete
fill 228 206 499 228 208 499 minecraft:light_gray_concrete
fill 228 206 501 228 208 501 minecraft:light_gray_concrete
fill 228 206 503 228 208 503 minecraft:light_gray_concrete
fill 228 206 505 228 221 505 minecraft:light_gray_terracotta
fill 229 206 496 229 208 496 minecraft:light_gray_concrete
fill 229 206 498 229 235 498 minecraft:light_gray_concrete
fill 229 206 500 229 208 500 minecraft:light_gray_concrete
fill 229 206 502 229 208 502 minecraft:light_gray_concrete
fill 229 206 504 229 208 504 minecraft:light_gray_concrete
fill 230 206 468 230 213 468 minecraft:light_gray_terracotta
fill 230 206 476 230 213 476 minecraft:light_gray_terracotta
fill 230 206 484 230 213 484 minecraft:light_gray_terracotta
fill 230 206 492 230 213 492 minecraft:light_gray_terracotta
fill 230 206 500 230 213 500 minecraft:light_gray_terracotta
fill 199 207 469 199 208 469 minecraft:black_concrete
fill 199 207 495 199 208 495 minecraft:black_concrete
fill 201 207 476 201 209 476 minecraft:blackstone
fill 201 207 488 201 209 488 minecraft:blackstone
fill 201 208 475 202 208 475 minecraft:blackstone
fill 201 208 489 202 208 489 minecraft:blackstone
fill 202 208 468 202 208 469 minecraft:black_concrete
fill 202 208 495 202 208 496 minecraft:black_concrete
setblock 205 208 470 minecraft:black_concrete
setblock 205 208 494 minecraft:black_concrete
fill 214 208 503 216 209 504 minecraft:iron_block
setblock 218 208 465 minecraft:pearlescent_froglight
setblock 218 208 467 minecraft:pearlescent_froglight
setblock 218 208 469 minecraft:pearlescent_froglight
setblock 219 208 464 minecraft:pearlescent_froglight
setblock 219 208 466 minecraft:pearlescent_froglight
setblock 219 208 468 minecraft:pearlescent_froglight
setblock 219 208 470 minecraft:pearlescent_froglight
setblock 220 208 465 minecraft:pearlescent_froglight
setblock 220 208 467 minecraft:pearlescent_froglight
setblock 220 208 469 minecraft:pearlescent_froglight
setblock 221 208 464 minecraft:pearlescent_froglight
setblock 221 208 466 minecraft:pearlescent_froglight
setblock 221 208 468 minecraft:pearlescent_froglight
setblock 221 208 470 minecraft:pearlescent_froglight
setblock 222 208 465 minecraft:pearlescent_froglight
setblock 222 208 467 minecraft:pearlescent_froglight
setblock 222 208 469 minecraft:pearlescent_froglight
setblock 223 208 464 minecraft:pearlescent_froglight
setblock 223 208 466 minecraft:pearlescent_froglight
setblock 223 208 468 minecraft:pearlescent_froglight
setblock 223 208 470 minecraft:pearlescent_froglight
setblock 224 208 465 minecraft:pearlescent_froglight
setblock 224 208 467 minecraft:pearlescent_froglight
setblock 224 208 469 minecraft:pearlescent_froglight
setblock 225 208 464 minecraft:pearlescent_froglight
setblock 225 208 466 minecraft:pearlescent_froglight
setblock 225 208 468 minecraft:pearlescent_froglight
setblock 225 208 470 minecraft:pearlescent_froglight
setblock 226 208 465 minecraft:pearlescent_froglight
setblock 226 208 467 minecraft:pearlescent_froglight
setblock 226 208 469 minecraft:pearlescent_froglight
setblock 227 208 464 minecraft:pearlescent_froglight
setblock 227 208 466 minecraft:pearlescent_froglight
setblock 227 208 468 minecraft:pearlescent_froglight
setblock 227 208 470 minecraft:pearlescent_froglight
setblock 228 208 465 minecraft:pearlescent_froglight
setblock 228 208 467 minecraft:pearlescent_froglight
setblock 228 208 469 minecraft:pearlescent_froglight
fill 200 209 475 200 210 476 minecraft:blackstone
fill 200 209 488 200 210 489 minecraft:blackstone
fill 201 209 475 201 210 475 minecraft:blackstone
fill 201 209 489 201 210 489 minecraft:blackstone
setblock 202 209 468 minecraft:black_concrete
setblock 202 209 476 minecraft:blackstone
setblock 202 209 488 minecraft:blackstone
setblock 202 209 496 minecraft:black_concrete
fill 205 209 469 205 210 469 minecraft:black_concrete
fill 205 209 495 205 210 495 minecraft:black_concrete
setblock 215 209 499 minecraft:pearlescent_froglight
fill 218 209 465 218 210 465 minecraft:light_gray_concrete
fill 218 209 467 218 210 467 minecraft:light_gray_concrete
fill 218 209 469 218 210 469 minecraft:light_gray_concrete
fill 219 209 464 219 210 464 minecraft:light_gray_concrete
fill 219 209 466 219 210 466 minecraft:light_gray_concrete
fill 219 209 468 219 210 468 minecraft:light_gray_concrete
fill 219 209 470 219 210 470 minecraft:light_gray_concrete
fill 220 209 465 220 210 465 minecraft:light_gray_concrete
fill 220 209 467 220 210 467 minecraft:light_gray_concrete
fill 220 209 469 220 210 469 minecraft:light_gray_concrete
fill 221 209 464 221 210 464 minecraft:light_gray_concrete
fill 221 209 466 221 210 466 minecraft:light_gray_concrete
fill 221 209 468 221 210 468 minecraft:light_gray_concrete
fill 221 209 470 221 210 470 minecraft:light_gray_concrete
fill 222 209 465 222 210 465 minecraft:light_gray_concrete
fill 222 209 467 222 210 467 minecraft:light_gray_concrete
fill 222 209 469 222 210 469 minecraft:light_gray_concrete
fill 223 209 464 223 210 464 minecraft:light_gray_concrete
fill 223 209 466 223 210 466 minecraft:light_gray_concrete
fill 223 209 468 223 210 468 minecraft:light_gray_concrete
fill 223 209 470 223 210 470 minecraft:light_gray_concrete
fill 224 209 465 224 210 465 minecraft:light_gray_concrete
fill 224 209 467 224 210 467 minecraft:light_gray_concrete
fill 224 209 469 224 210 469 minecraft:light_gray_concrete
fill 225 209 464 225 210 464 minecraft:light_gray_concrete
fill 225 209 466 225 210 466 minecraft:light_gray_concrete
fill 225 209 468 225 210 468 minecraft:light_gray_concrete
fill 225 209 470 225 210 470 minecraft:light_gray_concrete
fill 226 209 465 226 210 465 minecraft:light_gray_concrete
fill 226 209 467 226 210 467 minecraft:light_gray_concrete
fill 226 209 469 226 210 469 minecraft:light_gray_concrete
fill 227 209 464 227 210 464 minecraft:light_gray_concrete
fill 227 209 466 227 210 466 minecraft:light_gray_concrete
fill 227 209 468 227 210 468 minecraft:light_gray_concrete
fill 227 209 470 227 210 470 minecraft:light_gray_concrete
fill 228 209 465 228 210 465 minecraft:light_gray_concrete
fill 228 209 467 228 210 467 minecraft:light_gray_concrete
fill 228 209 469 228 210 469 minecraft:light_gray_concrete
fill 189 210 464 189 211 469 minecraft:light_gray_concrete
fill 189 210 472 190 210 477 minecraft:light_gray_concrete
fill 189 210 480 190 210 485 minecraft:light_gray_concrete
fill 189 210 488 190 210 493 minecraft:light_gray_concrete
fill 189 210 496 190 210 501 minecraft:light_gray_concrete
fill 189 210 504 194 211 504 minecraft:light_gray_concrete
fill 190 210 465 190 210 471 minecraft:light_gray_concrete
fill 190 210 478 190 210 479 minecraft:light_gray_concrete
fill 190 210 486 190 210 487 minecraft:light_gray_concrete
fill 190 210 494 190 210 495 minecraft:light_gray_concrete
fill 190 210 502 190 210 503 minecraft:light_gray_concrete
fill 191 210 465 217 210 465 minecraft:light_gray_concrete
fill 191 210 503 229 210 503 minecraft:light_gray_concrete
fill 192 210 464 197 211 464 minecraft:light_gray_concrete
fill 197 210 504 202 211 504 minecraft:light_gray_concrete
fill 199 210 474 199 211 475 minecraft:blackstone
fill 199 210 489 199 211 490 minecraft:blackstone
fill 200 210 464 205 211 464 minecraft:light_gray_concrete
fill 200 210 474 200 211 474 minecraft:blackstone
fill 200 210 490 200 211 490 minecraft:blackstone
fill 205 210 504 210 211 504 minecraft:light_gray_concrete
fill 208 210 464 213 211 464 minecraft:light_gray_concrete
fill 213 210 504 218 211 504 minecraft:light_gray_concrete
fill 216 210 464 217 211 464 minecraft:light_gray_concrete
fill 221 210 504 226 211 504 minecraft:light_gray_concrete
fill 228 210 471 228 210 502 minecraft:light_gray_concrete
fill 229 210 464 229 211 464 minecraft:light_gray_concrete
fill 229 210 467 229 211 472 minecraft:light_gray_concrete
fill 229 210 475 229 211 480 minecraft:light_gray_concrete
fill 229 210 483 229 211 488 minecraft:light_gray_concrete
fill 229 210 491 229 211 496 minecraft:light_gray_concrete
fill 229 210 499 229 211 502 minecraft:light_gray_concrete
fill 229 210 504 229 211 504 minecraft:light_gray_concrete
fill 189 211 472 189 211 477 minecraft:light_gray_concrete
fill 189 211 480 189 211 485 minecraft:light_gray_concrete
fill 189 211 488 189 211 493 minecraft:light_gray_concrete
fill 189 211 496 189 211 501 minecraft:light_gray_concrete
setblock 200 211 475 minecraft:blackstone
setblock 200 211 489 minecraft:blackstone
setblock 218 211 465 minecraft:pearlescent_froglight
setblock 218 211 467 minecraft:pearlescent_froglight
setblock 218 211 469 minecraft:pearlescent_froglight
setblock 219 211 464 minecraft:pearlescent_froglight
setblock 219 211 466 minecraft:pearlescent_froglight
setblock 219 211 468 minecraft:pearlescent_froglight
setblock 219 211 470 minecraft:pearlescent_froglight
setblock 220 211 465 minecraft:pearlescent_froglight
setblock 220 211 467 minecraft:pearlescent_froglight
setblock 220 211 469 minecraft:pearlescent_froglight
setblock 221 211 464 minecraft:pearlescent_froglight
setblock 221 211 466 minecraft:pearlescent_froglight
setblock 221 211 468 minecraft:pearlescent_froglight
setblock 221 211 470 minecraft:pearlescent_froglight
setblock 222 211 465 minecraft:pearlescent_froglight
setblock 222 211 467 minecraft:pearlescent_froglight
setblock 222 211 469 minecraft:pearlescent_froglight
setblock 223 211 464 minecraft:pearlescent_froglight
setblock 223 211 466 minecraft:pearlescent_froglight
setblock 223 211 468 minecraft:pearlescent_froglight
setblock 223 211 470 minecraft:pearlescent_froglight
setblock 224 211 465 minecraft:pearlescent_froglight
setblock 224 211 467 minecraft:pearlescent_froglight
setblock 224 211 469 minecraft:pearlescent_froglight
setblock 225 211 464 minecraft:pearlescent_froglight
setblock 225 211 466 minecraft:pearlescent_froglight
setblock 225 211 468 minecraft:pearlescent_froglight
setblock 225 211 470 minecraft:pearlescent_froglight
setblock 226 211 465 minecraft:pearlescent_froglight
setblock 226 211 467 minecraft:pearlescent_froglight
setblock 226 211 469 minecraft:pearlescent_froglight
setblock 227 211 464 minecraft:pearlescent_froglight
setblock 227 211 466 minecraft:pearlescent_froglight
setblock 227 211 468 minecraft:pearlescent_froglight
setblock 227 211 470 minecraft:pearlescent_froglight
setblock 228 211 465 minecraft:pearlescent_froglight
setblock 228 211 467 minecraft:pearlescent_froglight
setblock 228 211 469 minecraft:pearlescent_froglight
setblock 229 211 503 minecraft:light_gray_concrete
setblock 191 212 466 minecraft:light[level=11]
setblock 191 212 474 minecraft:light[level=11]
setblock 191 212 482 minecraft:light[level=11]
setblock 191 212 490 minecraft:light[level=11]
setblock 191 212 498 minecraft:light[level=11]
setblock 199 212 466 minecraft:light[level=11]
setblock 199 212 474 minecraft:blackstone
setblock 199 212 482 minecraft:light[level=11]
setblock 199 212 490 minecraft:blackstone
setblock 199 212 498 minecraft:light[level=11]
setblock 207 212 466 minecraft:light[level=11]
setblock 207 212 474 minecraft:light[level=11]
setblock 207 212 482 minecraft:light[level=11]
setblock 207 212 490 minecraft:light[level=11]
setblock 207 212 498 minecraft:light[level=11]
fill 213 212 500 213 212 502 minecraft:light_gray_concrete
fill 214 212 499 216 212 499 minecraft:light_gray_concrete
fill 214 212 503 216 212 503 minecraft:light_gray_concrete
setblock 215 212 466 minecraft:light[level=11]
setblock 215 212 474 minecraft:light[level=11]
setblock 215 212 482 minecraft:light[level=11]
setblock 215 212 490 minecraft:light[level=11]
setblock 215 212 498 minecraft:light[level=11]
fill 217 212 500 217 212 502 minecraft:light_gray_concrete
fill 218 212 465 218 213 465 minecraft:light_gray_concrete
fill 218 212 467 218 213 467 minecraft:light_gray_concrete
fill 218 212 469 218 213 469 minecraft:light_gray_concrete
fill 219 212 464 219 213 464 minecraft:light_gray_concrete
fill 219 212 466 219 213 466 minecraft:light_gray_concrete
fill 219 212 468 219 213 468 minecraft:light_gray_concrete
fill 219 212 470 219 213 470 minecraft:light_gray_concrete
fill 220 212 465 220 213 465 minecraft:light_gray_concrete
fill 220 212 467 220 213 467 minecraft:light_gray_concrete
fill 220 212 469 220 213 469 minecraft:light_gray_concrete
fill 221 212 464 221 213 464 minecraft:light_gray_concrete
fill 221 212 466 221 213 466 minecraft:light_gray_concrete
fill 221 212 468 221 213 468 minecraft:light_gray_concrete
fill 221 212 470 221 213 470 minecraft:light_gray_concrete
fill 222 212 465 222 213 465 minecraft:light_gray_concrete
fill 222 212 467 222 213 467 minecraft:light_gray_concrete
fill 222 212 469 222 213 469 minecraft:light_gray_concrete
fill 223 212 464 223 213 464 minecraft:light_gray_concrete
fill 223 212 466 223 213 466 minecraft:light_gray_concrete
fill 223 212 468 223 213 468 minecraft:light_gray_concrete
fill 223 212 470 223 213 470 minecraft:light_gray_concrete
setblock 223 212 474 minecraft:light[level=11]
setblock 223 212 482 minecraft:light[level=11]
setblock 223 212 490 minecraft:light[level=11]
setblock 223 212 498 minecraft:light[level=11]
fill 224 212 465 224 213 465 minecraft:light_gray_concrete
fill 224 212 467 224 213 467 minecraft:light_gray_concrete
fill 224 212 469 224 213 469 minecraft:light_gray_concrete
fill 225 212 464 225 213 464 minecraft:light_gray_concrete
fill 225 212 466 225 213 466 minecraft:light_gray_concrete
fill 225 212 468 225 213 468 minecraft:light_gray_concrete
fill 225 212 470 225 213 470 minecraft:light_gray_concrete
fill 226 212 465 226 213 465 minecraft:light_gray_concrete
fill 226 212 467 226 213 467 minecraft:light_gray_concrete
fill 226 212 469 226 213 469 minecraft:light_gray_concrete
fill 227 212 464 227 213 464 minecraft:light_gray_concrete
fill 227 212 466 227 213 466 minecraft:light_gray_concrete
fill 227 212 468 227 213 468 minecraft:light_gray_concrete
fill 227 212 470 227 213 470 minecraft:light_gray_concrete
fill 228 212 465 228 213 465 minecraft:light_gray_concrete
fill 228 212 467 228 213 467 minecraft:light_gray_concrete
fill 228 212 469 228 213 469 minecraft:light_gray_concrete
fill 188 214 468 188 219 468 minecraft:pearlescent_froglight
fill 188 214 476 188 219 476 minecraft:pearlescent_froglight
fill 188 214 484 188 219 484 minecraft:pearlescent_froglight
fill 188 214 492 188 219 492 minecraft:pearlescent_froglight
fill 188 214 500 188 219 500 minecraft:pearlescent_froglight
fill 191 214 505 191 219 505 minecraft:pearlescent_froglight
fill 195 214 463 195 219 463 minecraft:pearlescent_froglight
fill 199 214 505 199 219 505 minecraft:pearlescent_froglight
fill 203 214 463 203 219 463 minecraft:pearlescent_froglight
fill 207 214 505 207 219 505 minecraft:pearlescent_froglight
fill 211 214 463 211 219 463 minecraft:pearlescent_froglight
fill 215 214 505 215 219 505 minecraft:pearlescent_froglight
setblock 218 214 465 minecraft:pearlescent_froglight
setblock 218 214 467 minecraft:pearlescent_froglight
setblock 218 214 469 minecraft:pearlescent_froglight
fill 219 214 463 219 214 464 minecraft:pearlescent_froglight
setblock 219 214 466 minecraft:pearlescent_froglight
setblock 219 214 468 minecraft:pearlescent_froglight
setblock 219 214 470 minecraft:pearlescent_froglight
setblock 220 214 465 minecraft:pearlescent_froglight
setblock 220 214 467 minecraft:pearlescent_froglight
setblock 220 214 469 minecraft:pearlescent_froglight
setblock 221 214 464 minecraft:pearlescent_froglight
setblock 221 214 466 minecraft:pearlescent_froglight
setblock 221 214 468 minecraft:pearlescent_froglight
setblock 221 214 470 minecraft:pearlescent_froglight
setblock 222 214 465 minecraft:pearlescent_froglight
setblock 222 214 467 minecraft:pearlescent_froglight
setblock 222 214 469 minecraft:pearlescent_froglight
fill 222 214 505 222 221 505 minecraft:light_gray_terracotta
setblock 223 214 464 minecraft:pearlescent_froglight
setblock 223 214 466 minecraft:pearlescent_froglight
setblock 223 214 468 minecraft:pearlescent_froglight
setblock 223 214 470 minecraft:pearlescent_froglight
fill 223 214 505 223 219 505 minecraft:pearlescent_froglight
setblock 224 214 465 minecraft:pearlescent_froglight
setblock 224 214 467 minecraft:pearlescent_froglight
setblock 224 214 469 minecraft:pearlescent_froglight
fill 224 214 505 224 221 505 minecraft:light_gray_terracotta
setblock 225 214 464 minecraft:pearlescent_froglight
setblock 225 214 466 minecraft:pearlescent_froglight
setblock 225 214 468 minecraft:pearlescent_froglight
setblock 225 214 470 minecraft:pearlescent_froglight
setblock 226 214 465 minecraft:pearlescent_froglight
setblock 226 214 467 minecraft:pearlescent_froglight
setblock 226 214 469 minecraft:pearlescent_froglight
fill 227 214 463 227 214 464 minecraft:pearlescent_froglight
setblock 227 214 466 minecraft:pearlescent_froglight
setblock 227 214 468 minecraft:pearlescent_froglight
setblock 227 214 470 minecraft:pearlescent_froglight
setblock 228 214 465 minecraft:pearlescent_froglight
setblock 228 214 467 minecraft:pearlescent_froglight
setblock 228 214 469 minecraft:pearlescent_froglight
fill 230 214 468 230 219 468 minecraft:pearlescent_froglight
fill 230 214 476 230 219 476 minecraft:pearlescent_froglight
fill 230 214 484 230 219 484 minecraft:pearlescent_froglight
fill 230 214 492 230 219 492 minecraft:pearlescent_froglight
fill 230 214 500 230 219 500 minecraft:pearlescent_froglight
fill 218 215 465 218 217 465 minecraft:light_gray_concrete
fill 218 215 467 218 217 467 minecraft:light_gray_concrete
fill 218 215 469 218 217 469 minecraft:light_gray_concrete
fill 219 215 463 219 219 463 minecraft:pearlescent_froglight
fill 219 215 464 219 217 464 minecraft:light_gray_concrete
fill 219 215 466 219 217 466 minecraft:light_gray_concrete
fill 219 215 468 219 217 468 minecraft:light_gray_concrete
fill 219 215 470 219 217 470 minecraft:light_gray_concrete
fill 220 215 465 220 217 465 minecraft:light_gray_concrete
fill 220 215 467 220 217 467 minecraft:light_gray_concrete
fill 220 215 469 220 217 469 minecraft:light_gray_concrete
fill 221 215 464 221 217 464 minecraft:light_gray_concrete
fill 221 215 466 221 217 466 minecraft:light_gray_concrete
fill 221 215 468 221 217 468 minecraft:light_gray_concrete
fill 221 215 470 221 217 470 minecraft:light_gray_concrete
fill 222 215 465 222 217 465 minecraft:light_gray_concrete
fill 222 215 467 222 217 467 minecraft:light_gray_concrete
fill 222 215 469 222 217 469 minecraft:light_gray_concrete
fill 223 215 464 223 235 464 minecraft:light_gray_concrete
fill 223 215 466 223 217 466 minecraft:light_gray_concrete
fill 223 215 468 223 217 468 minecraft:light_gray_concrete
fill 223 215 470 223 217 470 minecraft:light_gray_concrete
fill 224 215 465 224 217 465 minecraft:light_gray_concrete
fill 224 215 467 224 217 467 minecraft:light_gray_concrete
fill 224 215 469 224 217 469 minecraft:light_gray_concrete
fill 225 215 464 225 217 464 minecraft:light_gray_concrete
fill 225 215 466 225 217 466 minecraft:light_gray_concrete
fill 225 215 468 225 217 468 minecraft:light_gray_concrete
fill 225 215 470 225 217 470 minecraft:light_gray_concrete
fill 226 215 465 226 217 465 minecraft:light_gray_concrete
fill 226 215 467 226 217 467 minecraft:light_gray_concrete
fill 226 215 469 226 217 469 minecraft:light_gray_concrete
fill 226 215 490 227 216 491 minecraft:red_concrete
fill 227 215 463 227 219 463 minecraft:pearlescent_froglight
fill 227 215 464 227 217 464 minecraft:light_gray_concrete
fill 227 215 466 227 217 466 minecraft:light_gray_concrete
fill 227 215 468 227 217 468 minecraft:light_gray_concrete
fill 227 215 470 227 217 470 minecraft:light_gray_concrete
fill 228 215 465 228 217 465 minecraft:light_gray_concrete
fill 228 215 467 228 217 467 minecraft:light_gray_concrete
fill 228 215 469 228 217 469 minecraft:light_gray_concrete
fill 208 216 470 208 217 471 minecraft:red_concrete
fill 227 217 495 227 226 495 minecraft:light_blue_wool
fill 192 218 505 196 221 505 minecraft:light_gray_terracotta
setblock 197 218 505 minecraft:white_terracotta
fill 198 218 505 198 221 505 minecraft:light_gray_terracotta
fill 204 218 463 206 221 463 minecraft:light_gray_terracotta
setblock 207 218 463 minecraft:white_terracotta
fill 208 218 505 208 221 505 minecraft:light_gray_terracotta
fill 209 218 505 209 219 505 minecraft:white_terracotta
fill 210 218 505 213 221 505 minecraft:light_gray_terracotta
fill 218 218 505 218 221 505 minecraft:light_gray_terracotta
setblock 219 218 505 minecraft:white_terracotta
fill 227 218 493 227 226 494 minecraft:light_blue_wool
fill 227 218 496 227 226 497 minecraft:light_blue_wool
fill 230 218 485 230 218 490 minecraft:light_gray_terracotta
setblock 230 218 491 minecraft:white_terracotta
fill 230 218 493 230 221 493 minecraft:light_gray_terracotta
setblock 230 218 494 minecraft:white_terracotta
setblock 230 218 501 minecraft:white_terracotta
fill 230 218 502 230 221 503 minecraft:light_gray_terracotta
fill 230 218 504 230 219 504 minecraft:white_terracotta
fill 230 218 505 230 219 505 minecraft:light_gray_terracotta
setblock 188 219 463 minecraft:white_terracotta
fill 188 219 464 188 221 467 minecraft:light_gray_terracotta
fill 188 219 493 188 219 494 minecraft:light_gray_terracotta
setblock 188 219 495 minecraft:white_terracotta
fill 188 219 496 188 221 496 minecraft:light_gray_terracotta
fill 197 219 505 197 221 505 minecraft:light_gray_terracotta
fill 205 219 496 205 220 496 minecraft:red_concrete
fill 207 219 463 207 221 463 minecraft:light_gray_terracotta
setblock 209 219 463 minecraft:white_terracotta
fill 213 219 500 213 219 502 minecraft:light_gray_concrete
fill 214 219 499 216 219 499 minecraft:light_gray_concrete
fill 214 219 503 216 219 503 minecraft:light_gray_concrete
setblock 216 219 505 minecraft:white_terracotta
fill 217 219 500 217 219 502 minecraft:light_gray_concrete
fill 217 219 505 217 221 505 minecraft:light_gray_terracotta
fill 219 219 505 219 221 505 minecraft:light_gray_terracotta
fill 220 219 463 223 221 463 minecraft:light_gray_terracotta
fill 220 219 505 220 220 505 minecraft:white_terracotta
setblock 224 219 463 minecraft:white_terracotta
fill 225 219 463 226 221 463 minecraft:light_gray_terracotta
fill 230 219 485 230 221 486 minecraft:light_gray_terracotta
setblock 230 219 487 minecraft:white_terracotta
fill 230 219 488 230 221 491 minecraft:light_gray_terracotta
fill 230 219 494 230 221 494 minecraft:light_gray_terracotta
fill 230 219 501 230 222 501 minecraft:light_gray_terracotta
fill 188 220 463 188 221 463 minecraft:light_gray_terracotta
fill 188 220 468 188 221 468 minecraft:light_gray_terracotta
setblock 188 220 469 minecraft:white_terracotta
fill 188 220 470 188 221 473 minecraft:light_gray_terracotta
fill 188 220 476 188 222 476 minecraft:light_gray_terracotta
setblock 188 220 477 minecraft:white_terracotta
fill 188 220 478 188 221 484 minecraft:light_gray_terracotta
fill 188 220 488 188 221 488 minecraft:light_gray_terracotta
setblock 188 220 489 minecraft:white_terracotta
fill 188 220 492 188 221 492 minecraft:light_gray_terracotta
setblock 188 220 493 minecraft:white_terracotta
fill 188 220 494 188 221 495 minecraft:light_gray_terracotta
fill 188 220 500 188 221 500 minecraft:light_gray_terracotta
setblock 191 220 466 minecraft:light[level=11]
setblock 191 220 474 minecraft:light[level=11]
setblock 191 220 482 minecraft:light[level=11]
setblock 191 220 490 minecraft:light[level=11]
setblock 191 220 498 minecraft:light[level=11]
fill 191 220 505 191 221 505 minecraft:light_gray_terracotta
fill 195 220 463 195 221 463 minecraft:light_gray_terracotta
setblock 196 220 463 minecraft:white_terracotta
fill 197 220 463 198 221 463 minecraft:light_gray_terracotta
setblock 199 220 466 minecraft:light[level=11]
setblock 199 220 474 minecraft:light[level=11]
setblock 199 220 482 minecraft:light[level=11]
setblock 199 220 490 minecraft:light[level=11]
setblock 199 220 498 minecraft:light[level=11]
fill 199 220 505 199 221 505 minecraft:light_gray_terracotta
fill 203 220 463 203 221 463 minecraft:light_gray_terracotta
setblock 207 220 466 minecraft:light[level=11]
setblock 207 220 474 minecraft:light[level=11]
setblock 207 220 482 minecraft:light[level=11]
setblock 207 220 490 minecraft:light[level=11]
setblock 207 220 498 minecraft:light[level=11]
fill 207 220 505 207 221 505 minecraft:light_gray_terracotta
fill 209 220 463 209 221 463 minecraft:light_gray_terracotta
fill 209 220 505 209 221 505 minecraft:light_gray_terracotta
fill 211 220 463 211 222 463 minecraft:light_gray_terracotta
setblock 215 220 466 minecraft:light[level=11]
setblock 215 220 474 minecraft:light[level=11]
setblock 215 220 482 minecraft:light[level=11]
setblock 215 220 490 minecraft:light[level=11]
setblock 215 220 498 minecraft:light[level=11]
fill 215 220 505 216 221 505 minecraft:light_gray_terracotta
fill 219 220 463 219 221 463 minecraft:light_gray_terracotta
setblock 221 220 505 minecraft:white_terracotta
setblock 223 220 466 minecraft:light[level=11]
setblock 223 220 474 minecraft:light[level=11]
setblock 223 220 482 minecraft:light[level=11]
setblock 223 220 490 minecraft:light[level=11]
setblock 223 220 498 minecraft:light[level=11]
fill 223 220 505 223 221 505 minecraft:light_gray_terracotta
fill 224 220 463 224 221 463 minecraft:light_gray_terracotta
fill 227 220 463 227 221 463 minecraft:light_gray_terracotta
setblock 228 220 463 minecraft:white_terracotta
fill 229 220 463 229 221 463 minecraft:light_gray_terracotta
fill 230 220 463 230 220 464 minecraft:white_terracotta
fill 230 220 465 230 221 466 minecraft:light_gray_terracotta
setblock 230 220 467 minecraft:white_terracotta
fill 230 220 468 230 221 468 minecraft:light_gray_terracotta
setblock 230 220 471 minecraft:white_terracotta
fill 230 220 472 230 221 476 minecraft:light_gray_terracotta
setblock 230 220 477 minecraft:white_terracotta
fill 230 220 478 230 221 478 minecraft:light_gray_terracotta
fill 230 220 484 230 221 484 minecraft:light_gray_terracotta
fill 230 220 487 230 221 487 minecraft:light_gray_terracotta
fill 230 220 492 230 221 492 minecraft:light_gray_terracotta
fill 230 220 500 230 221 500 minecraft:light_gray_terracotta
fill 230 220 504 230 221 504 minecraft:light_gray_terracotta
setblock 230 220 505 minecraft:white_terracotta
fill 188 221 469 188 222 469 minecraft:light_gray_terracotta
setblock 188 221 477 minecraft:light_gray_terracotta
setblock 188 221 489 minecraft:light_gray_terracotta
setblock 188 221 493 minecraft:light_gray_terracotta
setblock 196 221 463 minecraft:light_gray_terracotta
fill 220 221 505 221 221 505 minecraft:light_gray_terracotta
setblock 228 221 463 minecraft:light_gray_terracotta
fill 230 221 463 230 221 464 minecraft:light_gray_terracotta
setblock 230 221 467 minecraft:light_gray_terracotta
setblock 230 221 471 minecraft:light_gray_terracotta
setblock 230 221 477 minecraft:light_gray_terracotta
fill 230 221 505 230 222 505 minecraft:light_gray_terracotta
fill 188 222 463 188 222 468 minecraft:white_terracotta
fill 188 222 470 188 222 471 minecraft:white_terracotta
fill 188 222 472 188 223 472 minecraft:light_gray_terracotta
fill 188 222 473 188 307 475 minecraft:white_terracotta
fill 188 222 477 188 222 485 minecraft:white_terracotta
fill 188 222 486 188 222 487 minecraft:light_gray_terracotta
fill 188 222 488 188 223 504 minecraft:white_terracotta
fill 189 222 463 192 222 463 minecraft:white_terracotta
fill 189 222 505 191 227 505 minecraft:white_terracotta
fill 192 222 505 193 222 505 minecraft:light_gray_terracotta
fill 194 222 463 197 227 463 minecraft:white_terracotta
fill 194 222 505 194 307 505 minecraft:white_terracotta
setblock 195 222 505 minecraft:light_gray_terracotta
fill 196 222 505 203 222 505 minecraft:white_terracotta
setblock 198 222 463 minecraft:light_gray_terracotta
fill 199 222 463 200 222 463 minecraft:white_terracotta
setblock 201 222 463 minecraft:light_gray_terracotta
fill 202 222 463 210 223 463 minecraft:white_terracotta
setblock 204 222 505 minecraft:light_gray_terracotta
setblock 205 222 505 minecraft:white_terracotta
fill 206 222 505 206 223 505 minecraft:light_gray_terracotta
fill 207 222 505 212 222 505 minecraft:white_terracotta
setblock 212 222 463 minecraft:light_gray_terracotta
fill 213 222 463 230 222 463 minecraft:white_terracotta
fill 213 222 505 213 224 505 minecraft:light_gray_terracotta
fill 214 222 505 215 223 505 minecraft:white_terracotta
setblock 216 222 505 minecraft:light_gray_terracotta
fill 217 222 505 220 307 505 minecraft:white_terracotta
setblock 221 222 505 minecraft:light_gray_terracotta
fill 222 222 505 224 223 505 minecraft:white_terracotta
fill 226 222 505 229 222 505 minecraft:white_terracotta
fill 230 222 464 230 223 468 minecraft:white_terracotta
fill 230 222 470 230 222 494 minecraft:white_terracotta
fill 230 222 496 230 307 498 minecraft:white_terracotta
fill 230 222 500 230 227 500 minecraft:white_terracotta
fill 230 222 502 230 307 504 minecraft:white_terracotta
fill 188 223 463 188 224 463 minecraft:light_gray_terracotta
fill 188 223 464 188 307 464 minecraft:white_terracotta
setblock 188 223 465 minecraft:light_gray_terracotta
fill 188 223 466 188 223 469 minecraft:white_terracotta
fill 188 223 470 188 224 470 minecraft:light_gray_terracotta
fill 188 223 471 188 307 471 minecraft:white_terracotta
fill 188 223 476 188 223 480 minecraft:white_terracotta
setblock 188 223 481 minecraft:light_gray_terracotta
fill 188 223 482 188 307 483 minecraft:white_terracotta
setblock 188 223 484 minecraft:light_gray_terracotta
fill 188 223 485 188 307 485 minecraft:white_terracotta
setblock 188 223 486 minecraft:light_gray_terracotta
fill 188 223 487 188 307 487 minecraft:white_terracotta
fill 188 223 505 188 307 505 minecraft:white_terracotta
fill 189 223 463 189 307 463 minecraft:white_terracotta
setblock 190 223 463 minecraft:light_gray_terracotta
fill 191 223 463 191 307 463 minecraft:white_terracotta
fill 192 223 463 192 224 463 minecraft:light_gray_terracotta
fill 192 223 505 193 307 505 minecraft:white_terracotta
fill 193 223 463 193 307 463 minecraft:white_terracotta
fill 195 223 505 201 227 505 minecraft:white_terracotta
fill 198 223 463 199 307 463 minecraft:white_terracotta
setblock 200 223 463 minecraft:light_gray_terracotta
fill 201 223 463 201 307 463 minecraft:white_terracotta
fill 202 223 505 203 224 505 minecraft:light_gray_terracotta
setblock 204 223 505 minecraft:white_terracotta
setblock 205 223 505 minecraft:light_gray_terracotta
setblock 207 223 505 minecraft:light_gray_terracotta
fill 208 223 505 212 307 505 minecraft:white_terracotta
fill 211 223 463 218 223 463 minecraft:white_terracotta
fill 216 223 505 216 307 505 minecraft:white_terracotta
setblock 219 223 463 minecraft:light_gray_terracotta
fill 220 223 463 229 227 463 minecraft:white_terracotta
fill 221 223 505 221 307 505 minecraft:white_terracotta
fill 225 223 505 227 307 505 minecraft:white_terracotta
setblock 228 223 505 minecraft:light_gray_terracotta
fill 229 223 505 230 307 505 minecraft:white_terracotta
setblock 230 223 463 minecraft:light_gray_terracotta
fill 230 223 469 230 307 471 minecraft:white_terracotta
setblock 230 223 472 minecraft:light_gray_terracotta
fill 230 223 473 230 227 476 minecraft:white_terracotta
setblock 230 223 477 minecraft:light_gray_terracotta
fill 230 223 478 230 223 484 minecraft:white_terracotta
setblock 230 223 485 minecraft:light_gray_terracotta
fill 230 223 486 230 223 494 minecraft:white_terracotta
fill 230 223 501 230 307 501 minecraft:white_terracotta
fill 188 224 465 188 307 465 minecraft:white_terracotta
setblock 188 224 466 minecraft:light_gray_terracotta
fill 188 224 467 188 307 467 minecraft:white_terracotta
setblock 188 224 468 minecraft:light_gray_terracotta
fill 188 224 469 188 307 469 minecraft:white_terracotta
fill 188 224 472 188 307 472 minecraft:white_terracotta
fill 188 224 476 188 227 479 minecraft:white_terracotta
setblock 188 224 480 minecraft:light_gray_terracotta
fill 188 224 481 188 307 481 minecraft:white_terracotta
fill 188 224 484 188 227 484 minecraft:white_terracotta
fill 188 224 486 188 307 486 minecraft:white_terracotta
fill 188 224 488 188 307 488 minecraft:white_terracotta
setblock 188 224 489 minecraft:light_gray_terracotta
fill 188 224 490 188 227 497 minecraft:white_terracotta
setblock 188 224 498 minecraft:light_gray_terracotta
fill 188 224 499 188 227 502 minecraft:white_terracotta
setblock 188 224 503 minecraft:light_gray_terracotta
fill 188 224 504 188 307 504 minecraft:white_terracotta
fill 189 224 464 189 225 469 minecraft:light_gray_concrete
fill 189 224 472 190 224 477 minecraft:light_gray_concrete
fill 189 224 480 190 224 485 minecraft:light_gray_concrete
fill 189 224 488 190 224 493 minecraft:light_gray_concrete
fill 189 224 496 190 224 501 minecraft:light_gray_concrete
fill 189 224 504 194 225 504 minecraft:light_gray_concrete
fill 190 224 463 190 307 463 minecraft:white_terracotta
fill 190 224 465 190 224 471 minecraft:light_gray_concrete
fill 190 224 478 190 224 479 minecraft:light_gray_concrete
fill 190 224 486 190 224 487 minecraft:light_gray_concrete
fill 190 224 494 190 224 495 minecraft:light_gray_concrete
fill 190 224 502 190 224 503 minecraft:light_gray_concrete
fill 191 224 465 228 224 465 minecraft:light_gray_concrete
fill 191 224 503 229 224 503 minecraft:light_gray_concrete
fill 192 224 464 197 225 464 minecraft:light_gray_concrete
fill 197 224 504 202 225 504 minecraft:light_gray_concrete
fill 200 224 463 200 307 463 minecraft:white_terracotta
fill 200 224 464 205 225 464 minecraft:light_gray_concrete
fill 202 224 463 202 307 463 minecraft:white_terracotta
setblock 203 224 463 minecraft:light_gray_terracotta
fill 204 224 463 214 227 463 minecraft:white_terracotta
setblock 204 224 505 minecraft:light_gray_terracotta
fill 205 224 504 210 225 504 minecraft:light_gray_concrete
fill 205 224 505 207 227 505 minecraft:white_terracotta
fill 208 224 464 213 225 464 minecraft:light_gray_concrete
fill 213 224 504 218 225 504 minecraft:light_gray_concrete
setblock 214 224 505 minecraft:light_gray_terracotta
setblock 215 224 463 minecraft:light_gray_terracotta
fill 215 224 505 215 227 505 minecraft:white_terracotta
fill 216 224 463 219 227 463 minecraft:white_terracotta
fill 216 224 464 221 225 464 minecraft:light_gray_concrete
fill 220 224 490 220 225 491 minecraft:white_wool
fill 221 224 504 226 225 504 minecraft:light_gray_concrete
fill 222 224 505 222 307 505 minecraft:white_terracotta
fill 223 224 505 224 224 505 minecraft:light_gray_terracotta
fill 224 224 464 229 225 464 minecraft:light_gray_concrete
fill 228 224 466 228 224 502 minecraft:light_gray_concrete
fill 228 224 505 228 307 505 minecraft:white_terracotta
fill 229 224 467 229 225 472 minecraft:light_gray_concrete
fill 229 224 475 229 225 480 minecraft:light_gray_concrete
fill 229 224 483 229 225 488 minecraft:light_gray_concrete
fill 229 224 491 229 225 496 minecraft:light_gray_concrete
fill 229 224 499 229 225 502 minecraft:light_gray_concrete
fill 229 224 504 229 225 504 minecraft:light_gray_concrete
fill 230 224 463 230 307 465 minecraft:white_terracotta
setblock 230 224 466 minecraft:light_gray_terracotta
fill 230 224 467 230 227 468 minecraft:white_terracotta
fill 230 224 472 230 307 472 minecraft:white_terracotta
fill 230 224 477 230 307 483 minecraft:white_terracotta
setblock 230 224 484 minecraft:light_gray_terracotta
fill 230 224 485 230 307 486 minecraft:white_terracotta
setblock 230 224 487 minecraft:light_gray_terracotta
fill 230 224 488 230 307 490 minecraft:white_terracotta
fill 230 224 491 230 224 492 minecraft:light_gray_terracotta
fill 230 224 493 230 307 495 minecraft:white_terracotta
fill 230 224 499 230 307 499 minecraft:white_terracotta
fill 188 225 463 188 307 463 minecraft:white_terracotta
fill 188 225 466 188 307 466 minecraft:white_terracotta
fill 188 225 468 188 227 468 minecraft:white_terracotta
fill 188 225 470 188 307 470 minecraft:white_terracotta
fill 188 225 480 188 307 480 minecraft:white_terracotta
fill 188 225 489 188 307 489 minecraft:white_terracotta
fill 188 225 498 188 307 498 minecraft:white_terracotta
fill 188 225 503 188 307 503 minecraft:white_terracotta
fill 189 225 472 189 225 477 minecraft:light_gray_concrete
fill 189 225 480 189 225 485 minecraft:light_gray_concrete
fill 189 225 488 189 225 493 minecraft:light_gray_concrete
fill 189 225 496 189 225 501 minecraft:light_gray_concrete
fill 192 225 463 192 307 463 minecraft:white_terracotta
fill 202 225 505 204 307 505 minecraft:white_terracotta
fill 203 225 463 203 227 463 minecraft:white_terracotta
fill 213 225 505 214 307 505 minecraft:white_terracotta
fill 215 225 463 215 307 463 minecraft:white_terracotta
fill 223 225 505 224 227 505 minecraft:white_terracotta
setblock 229 225 503 minecraft:light_gray_concrete
fill 230 225 466 230 307 466 minecraft:white_terracotta
fill 230 225 484 230 227 484 minecraft:white_terracotta
fill 230 225 487 230 307 487 minecraft:white_terracotta
fill 230 225 491 230 227 492 minecraft:white_terracotta
fill 213 226 500 213 226 502 minecraft:light_gray_concrete
fill 214 226 499 216 226 499 minecraft:light_gray_concrete
fill 214 226 503 216 226 503 minecraft:light_gray_concrete
fill 217 226 500 217 226 502 minecraft:light_gray_concrete
fill 227 227 492 227 228 498 minecraft:iron_block
fill 188 228 468 188 233 468 minecraft:pearlescent_froglight
fill 188 228 476 188 233 476 minecraft:pearlescent_froglight
fill 188 228 477 188 307 479 minecraft:white_terracotta
fill 188 228 484 188 233 484 minecraft:pearlescent_froglight
fill 188 228 490 188 307 491 minecraft:white_terracotta
fill 188 228 492 188 233 492 minecraft:pearlescent_froglight
fill 188 228 493 188 307 497 minecraft:white_terracotta
fill 188 228 499 188 307 499 minecraft:white_terracotta
fill 188 228 500 188 233 500 minecraft:pearlescent_froglight
fill 188 228 501 188 307 502 minecraft:white_terracotta
fill 189 228 505 190 307 505 minecraft:white_terracotta
setblock 191 228 466 minecraft:light[level=11]
setblock 191 228 474 minecraft:light[level=11]
setblock 191 228 482 minecraft:light[level=11]
setblock 191 228 490 minecraft:light[level=11]
setblock 191 228 498 minecraft:light[level=11]
fill 191 228 505 191 233 505 minecraft:pearlescent_froglight
fill 194 228 463 194 307 463 minecraft:white_terracotta
fill 195 228 463 195 233 463 minecraft:pearlescent_froglight
fill 195 228 505 198 307 505 minecraft:white_terracotta
fill 196 228 463 197 307 463 minecraft:white_terracotta
setblock 199 228 466 minecraft:light[level=11]
setblock 199 228 474 minecraft:light[level=11]
setblock 199 228 482 minecraft:light[level=11]
setblock 199 228 490 minecraft:light[level=11]
setblock 199 228 498 minecraft:light[level=11]
fill 199 228 505 199 233 505 minecraft:pearlescent_froglight
fill 200 228 505 201 307 505 minecraft:white_terracotta
fill 203 228 463 203 233 463 minecraft:pearlescent_froglight
fill 204 228 463 210 307 463 minecraft:white_terracotta
fill 205 228 505 206 307 505 minecraft:white_terracotta
setblock 207 228 466 minecraft:light[level=11]
setblock 207 228 474 minecraft:light[level=11]
setblock 207 228 482 minecraft:light[level=11]
setblock 207 228 490 minecraft:light[level=11]
setblock 207 228 498 minecraft:light[level=11]
fill 207 228 505 207 233 505 minecraft:pearlescent_froglight
fill 211 228 463 211 233 463 minecraft:pearlescent_froglight
fill 212 228 463 214 307 463 minecraft:white_terracotta
setblock 215 228 466 minecraft:light[level=11]
setblock 215 228 474 minecraft:light[level=11]
setblock 215 228 482 minecraft:light[level=11]
setblock 215 228 490 minecraft:light[level=11]
setblock 215 228 498 minecraft:light[level=11]
fill 215 228 505 215 233 505 minecraft:pearlescent_froglight
fill 216 228 463 218 307 463 minecraft:white_terracotta
fill 219 228 463 219 233 463 minecraft:pearlescent_froglight
fill 220 228 463 226 307 463 minecraft:white_terracotta
setblock 223 228 466 minecraft:light[level=11]
setblock 223 228 474 minecraft:light[level=11]
setblock 223 228 482 minecraft:light[level=11]
setblock 223 228 490 minecraft:light[level=11]
setblock 223 228 498 minecraft:light[level=11]
fill 223 228 505 223 233 505 minecraft:pearlescent_froglight
fill 224 228 505 224 307 505 minecraft:white_terracotta
fill 227 228 463 227 233 463 minecraft:pearlescent_froglight
fill 228 228 463 229 307 463 minecraft:white_terracotta
fill 230 228 467 230 307 467 minecraft:white_terracotta
fill 230 228 468 230 233 468 minecraft:pearlescent_froglight
fill 230 228 473 230 307 475 minecraft:white_terracotta
fill 230 228 476 230 233 476 minecraft:pearlescent_froglight
fill 230 228 484 230 233 484 minecraft:pearlescent_froglight
fill 230 228 491 230 307 491 minecraft:white_terracotta
fill 230 228 492 230 233 492 minecraft:pearlescent_froglight
fill 230 228 500 230 233 500 minecraft:pearlescent_froglight
fill 208 231 493 208 232 493 minecraft:red_concrete
fill 213 233 500 213 233 502 minecraft:light_gray_concrete
fill 214 233 499 216 233 499 minecraft:light_gray_concrete
fill 214 233 503 216 233 503 minecraft:light_gray_concrete
fill 217 233 500 217 233 502 minecraft:light_gray_concrete
fill 188 234 468 188 245 468 minecraft:white_terracotta
fill 188 234 476 188 245 476 minecraft:white_terracotta
fill 188 234 484 188 245 484 minecraft:white_terracotta
fill 188 234 492 188 245 492 minecraft:white_terracotta
fill 188 234 500 188 245 500 minecraft:white_terracotta
fill 191 234 505 191 245 505 minecraft:white_terracotta
fill 195 234 463 195 245 463 minecraft:white_terracotta
fill 199 234 505 199 245 505 minecraft:white_terracotta
fill 203 234 463 203 245 463 minecraft:white_terracotta
fill 207 234 505 207 245 505 minecraft:white_terracotta
fill 211 234 463 211 245 463 minecraft:white_terracotta
fill 215 234 505 215 245 505 minecraft:white_terracotta
fill 219 234 463 219 245 463 minecraft:white_terracotta
fill 223 234 505 223 245 505 minecraft:white_terracotta
fill 227 234 463 227 245 463 minecraft:white_terracotta
fill 230 234 468 230 245 468 minecraft:white_terracotta
fill 230 234 476 230 245 476 minecraft:white_terracotta
fill 230 234 484 230 245 484 minecraft:white_terracotta
fill 230 234 492 230 245 492 minecraft:white_terracotta
fill 230 234 500 230 245 500 minecraft:white_terracotta
setblock 191 236 466 minecraft:light[level=11]
setblock 191 236 474 minecraft:light[level=11]
setblock 191 236 482 minecraft:light[level=11]
setblock 191 236 490 minecraft:light[level=11]
setblock 191 236 498 minecraft:light[level=11]
setblock 199 236 466 minecraft:light[level=11]
setblock 199 236 474 minecraft:light[level=11]
setblock 199 236 482 minecraft:light[level=11]
setblock 199 236 490 minecraft:light[level=11]
setblock 199 236 498 minecraft:light[level=11]
setblock 207 236 466 minecraft:light[level=11]
setblock 207 236 474 minecraft:light[level=11]
setblock 207 236 482 minecraft:light[level=11]
setblock 207 236 490 minecraft:light[level=11]
setblock 207 236 498 minecraft:light[level=11]
setblock 215 236 466 minecraft:light[level=11]
setblock 215 236 474 minecraft:light[level=11]
setblock 215 236 482 minecraft:light[level=11]
setblock 215 236 490 minecraft:light[level=11]
setblock 215 236 498 minecraft:light[level=11]
setblock 223 236 466 minecraft:light[level=11]
setblock 223 236 474 minecraft:light[level=11]
setblock 223 236 482 minecraft:light[level=11]
setblock 223 236 490 minecraft:light[level=11]
setblock 223 236 498 minecraft:light[level=11]
fill 189 241 464 190 242 465 minecraft:light_gray_concrete
fill 189 241 466 190 242 467 minecraft:white_concrete
fill 189 241 468 190 242 469 minecraft:light_gray_concrete
fill 189 241 470 190 242 471 minecraft:white_concrete
fill 189 241 472 190 242 473 minecraft:light_gray_concrete
fill 189 241 474 190 242 475 minecraft:white_concrete
fill 189 241 476 190 242 477 minecraft:light_gray_concrete
fill 189 241 478 190 242 479 minecraft:white_concrete
fill 189 241 480 190 242 481 minecraft:light_gray_concrete
fill 189 241 482 190 242 483 minecraft:white_concrete
fill 189 241 484 190 242 485 minecraft:light_gray_concrete
fill 189 241 486 190 242 487 minecraft:white_concrete
fill 189 241 488 190 242 489 minecraft:light_gray_concrete
fill 189 241 490 190 242 491 minecraft:white_concrete
fill 189 241 492 190 242 493 minecraft:light_gray_concrete
fill 189 241 494 190 242 495 minecraft:white_concrete
fill 189 241 496 190 242 497 minecraft:light_gray_concrete
fill 189 241 498 190 242 499 minecraft:white_concrete
fill 189 241 500 190 242 501 minecraft:light_gray_concrete
fill 189 241 502 190 242 503 minecraft:white_concrete
fill 189 241 504 190 242 504 minecraft:light_gray_concrete
fill 191 241 464 192 242 465 minecraft:white_concrete
fill 191 241 466 192 242 467 minecraft:light_gray_concrete
fill 191 241 468 192 242 469 minecraft:white_concrete
fill 191 241 470 192 242 471 minecraft:light_gray_concrete
fill 191 241 472 192 242 473 minecraft:white_concrete
fill 191 241 474 192 242 475 minecraft:light_gray_concrete
fill 191 241 476 192 242 477 minecraft:white_concrete
fill 191 241 478 192 242 479 minecraft:light_gray_concrete
fill 191 241 480 192 242 481 minecraft:white_concrete
fill 191 241 482 192 242 483 minecraft:light_gray_concrete
fill 191 241 484 192 242 485 minecraft:white_concrete
fill 191 241 486 192 242 487 minecraft:light_gray_concrete
fill 191 241 488 192 242 489 minecraft:white_concrete
fill 191 241 490 192 242 491 minecraft:light_gray_concrete
fill 191 241 492 192 242 493 minecraft:white_concrete
fill 191 241 494 192 242 495 minecraft:light_gray_concrete
fill 191 241 496 192 242 497 minecraft:white_concrete
fill 191 241 498 192 242 499 minecraft:light_gray_concrete
fill 191 241 500 192 242 501 minecraft:white_concrete
fill 191 241 502 192 242 503 minecraft:light_gray_concrete
fill 191 241 504 192 242 504 minecraft:white_concrete
fill 193 241 464 194 242 465 minecraft:light_gray_concrete
fill 193 241 466 194 242 467 minecraft:white_concrete
fill 193 241 468 194 242 469 minecraft:light_gray_concrete
fill 193 241 470 194 242 471 minecraft:white_concrete
fill 193 241 472 194 242 473 minecraft:light_gray_concrete
fill 193 241 474 194 242 475 minecraft:white_concrete
fill 193 241 476 194 242 477 minecraft:light_gray_concrete
fill 193 241 478 194 242 479 minecraft:white_concrete
fill 193 241 480 194 242 481 minecraft:light_gray_concrete
fill 193 241 482 194 242 483 minecraft:white_concrete
fill 193 241 484 194 242 485 minecraft:light_gray_concrete
fill 193 241 486 194 242 487 minecraft:white_concrete
fill 193 241 488 194 242 489 minecraft:light_gray_concrete
fill 193 241 490 194 242 491 minecraft:white_concrete
fill 193 241 492 194 242 493 minecraft:light_gray_concrete
fill 193 241 494 194 242 495 minecraft:white_concrete
fill 193 241 496 194 242 497 minecraft:light_gray_concrete
fill 193 241 498 194 242 499 minecraft:white_concrete
fill 193 241 500 194 242 501 minecraft:light_gray_concrete
fill 193 241 502 194 242 503 minecraft:white_concrete
fill 193 241 504 194 242 504 minecraft:light_gray_concrete
fill 195 241 464 196 242 465 minecraft:white_concrete
fill 195 241 466 196 242 467 minecraft:light_gray_concrete
fill 195 241 468 196 242 469 minecraft:white_concrete
fill 195 241 470 196 242 471 minecraft:light_gray_concrete
fill 195 241 472 196 242 473 minecraft:white_concrete
fill 195 241 474 196 242 475 minecraft:light_gray_concrete
fill 195 241 476 196 242 477 minecraft:white_concrete
fill 195 241 478 196 242 479 minecraft:light_gray_concrete
fill 195 241 480 196 242 481 minecraft:white_concrete
fill 195 241 482 196 242 483 minecraft:light_gray_concrete
fill 195 241 484 196 242 485 minecraft:white_concrete
fill 195 241 486 196 242 487 minecraft:light_gray_concrete
fill 195 241 488 196 242 489 minecraft:white_concrete
fill 195 241 490 196 242 491 minecraft:light_gray_concrete
fill 195 241 492 196 242 493 minecraft:white_concrete
fill 195 241 494 196 242 495 minecraft:light_gray_concrete
fill 195 241 496 196 242 497 minecraft:white_concrete
fill 195 241 498 196 242 499 minecraft:light_gray_concrete
fill 195 241 500 196 242 501 minecraft:white_concrete
fill 195 241 502 196 242 503 minecraft:light_gray_concrete
fill 195 241 504 196 242 504 minecraft:white_concrete
fill 197 241 464 198 242 465 minecraft:light_gray_concrete
fill 197 241 466 198 242 467 minecraft:white_concrete
fill 197 241 468 198 242 469 minecraft:light_gray_concrete
fill 197 241 470 198 242 471 minecraft:white_concrete
fill 197 241 472 198 242 473 minecraft:light_gray_concrete
fill 197 241 474 198 242 475 minecraft:white_concrete
fill 197 241 476 198 242 477 minecraft:light_gray_concrete
fill 197 241 478 198 242 479 minecraft:white_concrete
fill 197 241 480 198 242 481 minecraft:light_gray_concrete
fill 197 241 482 198 242 483 minecraft:white_concrete
fill 197 241 484 198 242 485 minecraft:light_gray_concrete
fill 197 241 486 198 242 487 minecraft:white_concrete
fill 197 241 488 198 242 489 minecraft:light_gray_concrete
fill 197 241 490 198 242 491 minecraft:white_concrete
fill 197 241 492 198 242 493 minecraft:light_gray_concrete
fill 197 241 494 198 242 495 minecraft:white_concrete
fill 197 241 496 198 242 497 minecraft:light_gray_concrete
fill 197 241 498 198 242 499 minecraft:white_concrete
fill 197 241 500 198 242 501 minecraft:light_gray_concrete
fill 197 241 502 198 242 503 minecraft:white_concrete
fill 197 241 504 198 242 504 minecraft:light_gray_concrete
fill 199 241 464 200 242 465 minecraft:white_concrete
fill 199 241 466 200 242 467 minecraft:light_gray_concrete
fill 199 241 468 200 242 469 minecraft:white_concrete
fill 199 241 470 200 242 471 minecraft:light_gray_concrete
fill 199 241 472 200 242 473 minecraft:white_concrete
fill 199 241 474 200 242 475 minecraft:light_gray_concrete
fill 199 241 476 200 242 477 minecraft:white_concrete
fill 199 241 478 200 242 479 minecraft:light_gray_concrete
fill 199 241 480 200 242 481 minecraft:white_concrete
fill 199 241 482 200 242 483 minecraft:light_gray_concrete
fill 199 241 484 200 242 485 minecraft:white_concrete
fill 199 241 486 200 242 487 minecraft:light_gray_concrete
fill 199 241 488 200 242 489 minecraft:white_concrete
fill 199 241 490 200 242 491 minecraft:light_gray_concrete
fill 199 241 492 200 242 493 minecraft:white_concrete
fill 199 241 494 200 242 495 minecraft:light_gray_concrete
fill 199 241 496 200 242 497 minecraft:white_concrete
fill 199 241 498 200 242 499 minecraft:light_gray_concrete
fill 199 241 500 200 242 501 minecraft:white_concrete
fill 199 241 502 200 242 503 minecraft:light_gray_concrete
fill 199 241 504 200 242 504 minecraft:white_concrete
fill 201 241 464 202 242 465 minecraft:light_gray_concrete
fill 201 241 466 202 242 467 minecraft:white_concrete
fill 201 241 468 202 242 469 minecraft:light_gray_concrete
fill 201 241 470 202 242 471 minecraft:white_concrete
fill 201 241 472 202 242 473 minecraft:light_gray_concrete
fill 201 241 474 202 242 475 minecraft:white_concrete
fill 201 241 476 202 242 477 minecraft:light_gray_concrete
fill 201 241 478 202 242 479 minecraft:white_concrete
fill 201 241 480 202 242 481 minecraft:light_gray_concrete
fill 201 241 482 202 242 483 minecraft:white_concrete
fill 201 241 484 202 242 485 minecraft:light_gray_concrete
fill 201 241 486 202 242 487 minecraft:white_concrete
fill 201 241 488 202 242 489 minecraft:light_gray_concrete
fill 201 241 490 202 242 491 minecraft:white_concrete
fill 201 241 492 202 242 493 minecraft:light_gray_concrete
fill 201 241 494 202 242 495 minecraft:white_concrete
fill 201 241 496 202 242 497 minecraft:light_gray_concrete
fill 201 241 498 202 242 499 minecraft:white_concrete
fill 201 241 500 202 242 501 minecraft:light_gray_concrete
fill 201 241 502 202 242 503 minecraft:white_concrete
fill 201 241 504 202 242 504 minecraft:light_gray_concrete
fill 203 241 464 204 242 465 minecraft:white_concrete
fill 203 241 466 204 242 467 minecraft:light_gray_concrete
fill 203 241 468 204 242 469 minecraft:white_concrete
fill 203 241 470 204 242 471 minecraft:light_gray_concrete
fill 203 241 472 204 242 473 minecraft:white_concrete
fill 203 241 474 204 242 475 minecraft:light_gray_concrete
fill 203 241 476 204 242 477 minecraft:white_concrete
fill 203 241 478 204 242 479 minecraft:light_gray_concrete
fill 203 241 480 204 242 481 minecraft:white_concrete
fill 203 241 482 204 242 483 minecraft:light_gray_concrete
fill 203 241 484 204 242 485 minecraft:white_concrete
fill 203 241 486 204 242 487 minecraft:light_gray_concrete
fill 203 241 488 204 242 489 minecraft:white_concrete
fill 203 241 490 204 242 491 minecraft:light_gray_concrete
fill 203 241 492 204 242 493 minecraft:white_concrete
fill 203 241 494 204 242 495 minecraft:light_gray_concrete
fill 203 241 496 204 242 497 minecraft:white_concrete
fill 203 241 498 204 242 499 minecraft:light_gray_concrete
fill 203 241 500 204 242 501 minecraft:white_concrete
fill 203 241 502 204 242 503 minecraft:light_gray_concrete
fill 203 241 504 204 242 504 minecraft:white_concrete
fill 205 241 464 206 242 465 minecraft:light_gray_concrete
fill 205 241 466 206 242 467 minecraft:white_concrete
fill 205 241 468 206 242 469 minecraft:light_gray_concrete
fill 205 241 470 206 242 471 minecraft:white_concrete
fill 205 241 472 206 242 473 minecraft:light_gray_concrete
fill 205 241 474 206 242 475 minecraft:white_concrete
fill 205 241 476 206 242 477 minecraft:light_gray_concrete
fill 205 241 478 206 242 479 minecraft:white_concrete
fill 205 241 480 206 242 481 minecraft:light_gray_concrete
fill 205 241 482 206 241 483 minecraft:white_concrete
fill 205 241 484 206 241 485 minecraft:light_gray_concrete
fill 205 241 486 206 242 487 minecraft:white_concrete
fill 205 241 488 206 242 489 minecraft:light_gray_concrete
fill 205 241 490 206 242 491 minecraft:white_concrete
fill 205 241 492 206 242 493 minecraft:light_gray_concrete
fill 205 241 494 206 242 495 minecraft:white_concrete
fill 205 241 496 206 242 497 minecraft:light_gray_concrete
fill 205 241 498 206 242 499 minecraft:white_concrete
fill 205 241 500 206 242 501 minecraft:light_gray_concrete
fill 205 241 502 206 242 503 minecraft:white_concrete
fill 205 241 504 206 242 504 minecraft:light_gray_concrete
fill 207 241 464 208 242 465 minecraft:white_concrete
fill 207 241 466 208 242 467 minecraft:light_gray_concrete
fill 207 241 468 208 242 469 minecraft:white_concrete
fill 207 241 470 208 242 471 minecraft:light_gray_concrete
fill 207 241 472 208 242 473 minecraft:white_concrete
fill 207 241 474 208 242 475 minecraft:light_gray_concrete
fill 207 241 476 208 242 477 minecraft:white_concrete
fill 207 241 478 208 242 479 minecraft:light_gray_concrete
fill 207 241 480 208 241 481 minecraft:white_concrete
fill 207 241 482 207 241 483 minecraft:light_gray_concrete
setblock 207 241 485 minecraft:white_concrete
fill 207 241 486 208 241 487 minecraft:light_gray_concrete
schedule function dropper:buildpart/112_2 1t
