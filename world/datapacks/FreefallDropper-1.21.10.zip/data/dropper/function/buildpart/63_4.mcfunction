setblock 146 118 301 minecraft:snow_block
fill 146 118 302 146 119 302 minecraft:packed_ice
setblock 146 118 316 minecraft:snow_block
fill 147 118 276 150 118 276 minecraft:packed_ice
fill 147 118 278 148 118 278 minecraft:packed_ice
fill 147 118 297 148 118 297 minecraft:packed_ice
setblock 147 118 315 minecraft:snow_block
fill 147 118 316 150 118 316 minecraft:packed_ice
fill 148 118 315 150 118 315 minecraft:packed_ice
setblock 148 118 317 minecraft:white_concrete
setblock 149 118 301 minecraft:packed_ice
setblock 150 118 277 minecraft:snow_block
setblock 150 118 299 minecraft:packed_ice
setblock 151 118 276 minecraft:snow_block
setblock 151 118 277 minecraft:packed_ice
setblock 151 118 316 minecraft:snow_block
setblock 151 118 317 minecraft:white_concrete
fill 152 118 276 152 119 276 minecraft:packed_ice
fill 152 118 316 153 118 316 minecraft:packed_ice
setblock 154 118 276 minecraft:packed_ice
fill 157 118 317 157 129 317 minecraft:blue_ice
setblock 158 118 317 minecraft:light_blue_concrete
fill 159 118 276 160 118 276 minecraft:packed_ice
setblock 161 118 276 minecraft:snow_block
fill 161 118 277 164 118 277 minecraft:packed_ice
fill 161 118 310 163 160 312 minecraft:snow_block
fill 162 118 276 165 118 276 minecraft:packed_ice
fill 162 118 278 163 118 278 minecraft:packed_ice
fill 162 118 309 162 200 309 minecraft:snow_block
fill 163 118 316 165 118 316 minecraft:packed_ice
fill 164 118 275 164 161 275 minecraft:blue_ice
setblock 164 118 278 minecraft:snow_block
fill 164 118 279 167 118 279 minecraft:packed_ice
fill 164 118 311 164 200 311 minecraft:snow_block
setblock 165 118 277 minecraft:snow_block
fill 165 118 278 168 118 278 minecraft:packed_ice
setblock 166 118 276 minecraft:snow_block
fill 166 118 277 169 118 277 minecraft:packed_ice
setblock 166 118 316 minecraft:snow_block
fill 167 118 276 170 118 276 minecraft:packed_ice
fill 167 118 316 170 118 316 minecraft:packed_ice
setblock 168 118 279 minecraft:snow_block
setblock 168 118 280 minecraft:packed_ice
setblock 169 118 278 minecraft:snow_block
fill 169 118 279 169 121 279 minecraft:packed_ice
setblock 170 118 277 minecraft:snow_block
fill 170 118 278 173 118 278 minecraft:packed_ice
setblock 171 118 276 minecraft:snow_block
fill 171 118 277 174 118 277 minecraft:packed_ice
fill 171 118 279 172 118 279 minecraft:packed_ice
setblock 171 118 316 minecraft:snow_block
fill 172 118 276 175 118 276 minecraft:packed_ice
fill 172 118 316 175 118 316 minecraft:packed_ice
setblock 174 118 278 minecraft:snow_block
setblock 175 118 277 minecraft:snow_block
fill 175 118 278 178 118 278 minecraft:packed_ice
setblock 176 118 276 minecraft:snow_block
fill 176 118 277 179 118 277 minecraft:packed_ice
setblock 176 118 316 minecraft:snow_block
fill 177 118 276 180 118 276 minecraft:packed_ice
fill 177 118 316 180 118 316 minecraft:packed_ice
setblock 179 118 278 minecraft:snow_block
setblock 180 118 277 minecraft:snow_block
fill 180 118 278 180 119 280 minecraft:packed_ice
setblock 181 118 276 minecraft:snow_block
fill 181 118 277 181 121 277 minecraft:packed_ice
fill 181 118 279 181 118 280 minecraft:packed_ice
setblock 181 118 281 minecraft:snow_block
fill 181 118 282 181 121 282 minecraft:packed_ice
setblock 181 118 316 minecraft:snow_block
fill 182 118 276 182 121 276 minecraft:packed_ice
setblock 182 118 279 minecraft:packed_ice
setblock 182 118 280 minecraft:snow_block
fill 182 118 281 182 121 281 minecraft:packed_ice
setblock 182 118 285 minecraft:snow_block
fill 182 118 286 182 121 286 minecraft:packed_ice
fill 182 118 296 182 118 299 minecraft:packed_ice
setblock 182 118 300 minecraft:snow_block
fill 182 118 301 182 121 301 minecraft:packed_ice
setblock 182 118 305 minecraft:snow_block
fill 182 118 306 182 121 306 minecraft:packed_ice
setblock 182 118 309 minecraft:packed_ice
setblock 182 118 310 minecraft:snow_block
fill 182 118 311 182 121 311 minecraft:packed_ice
fill 182 118 313 182 118 314 minecraft:packed_ice
setblock 182 118 315 minecraft:snow_block
fill 182 118 316 182 121 316 minecraft:packed_ice
fill 183 118 299 183 161 299 minecraft:blue_ice
setblock 141 119 287 minecraft:light_blue_concrete
fill 142 119 276 142 119 278 minecraft:packed_ice
setblock 142 119 279 minecraft:snow_block
fill 142 119 280 142 122 280 minecraft:packed_ice
setblock 142 119 284 minecraft:snow_block
fill 142 119 285 142 122 285 minecraft:packed_ice
setblock 142 119 294 minecraft:snow_block
fill 142 119 295 142 119 298 minecraft:packed_ice
setblock 142 119 299 minecraft:snow_block
fill 142 119 300 142 119 303 minecraft:packed_ice
setblock 142 119 304 minecraft:snow_block
fill 142 119 305 142 119 308 minecraft:packed_ice
setblock 142 119 309 minecraft:snow_block
fill 142 119 310 142 119 313 minecraft:packed_ice
setblock 142 119 314 minecraft:snow_block
fill 142 119 315 144 119 316 minecraft:packed_ice
fill 143 119 276 143 119 277 minecraft:packed_ice
setblock 143 119 278 minecraft:snow_block
fill 143 119 279 143 122 279 minecraft:packed_ice
setblock 143 119 283 minecraft:snow_block
fill 143 119 295 143 119 297 minecraft:packed_ice
setblock 143 119 298 minecraft:snow_block
fill 143 119 299 143 119 302 minecraft:packed_ice
setblock 143 119 303 minecraft:snow_block
fill 143 119 304 143 119 307 minecraft:packed_ice
setblock 143 119 308 minecraft:snow_block
fill 143 119 309 143 119 312 minecraft:packed_ice
setblock 143 119 313 minecraft:snow_block
fill 143 119 314 143 121 314 minecraft:packed_ice
setblock 144 119 276 minecraft:packed_ice
setblock 144 119 277 minecraft:snow_block
setblock 144 119 278 minecraft:packed_ice
setblock 144 119 297 minecraft:snow_block
fill 144 119 298 144 119 301 minecraft:packed_ice
setblock 144 119 302 minecraft:snow_block
fill 144 119 303 144 122 303 minecraft:packed_ice
fill 144 119 305 144 119 306 minecraft:packed_ice
setblock 144 119 307 minecraft:snow_block
fill 144 119 308 144 122 308 minecraft:packed_ice
fill 144 119 310 144 120 310 minecraft:packed_ice
setblock 145 119 276 minecraft:snow_block
fill 145 119 277 148 119 277 minecraft:packed_ice
setblock 145 119 282 minecraft:snow_block
fill 145 119 298 145 119 300 minecraft:packed_ice
setblock 145 119 301 minecraft:snow_block
fill 145 119 302 145 122 302 minecraft:packed_ice
setblock 145 119 305 minecraft:packed_ice
setblock 145 119 306 minecraft:snow_block
setblock 145 119 315 minecraft:packed_ice
setblock 145 119 316 minecraft:snow_block
fill 146 119 276 149 119 276 minecraft:packed_ice
setblock 146 119 301 minecraft:packed_ice
setblock 146 119 303 minecraft:packed_ice
setblock 146 119 315 minecraft:snow_block
fill 146 119 316 149 119 316 minecraft:packed_ice
setblock 147 119 278 minecraft:packed_ice
setblock 147 119 280 minecraft:snow_block
fill 147 119 315 149 119 315 minecraft:packed_ice
fill 148 119 317 148 166 317 minecraft:blue_ice
setblock 149 119 277 minecraft:snow_block
setblock 150 119 276 minecraft:snow_block
setblock 150 119 277 minecraft:packed_ice
setblock 150 119 316 minecraft:snow_block
fill 151 119 276 151 120 276 minecraft:packed_ice
fill 151 119 302 154 200 304 minecraft:snow_block
setblock 151 119 316 minecraft:packed_ice
fill 151 119 317 151 166 317 minecraft:blue_ice
fill 152 119 305 154 200 305 minecraft:snow_block
fill 158 119 317 158 162 317 minecraft:blue_ice
setblock 159 119 276 minecraft:packed_ice
setblock 160 119 276 minecraft:snow_block
fill 160 119 310 160 120 312 minecraft:packed_ice
fill 161 119 276 163 119 277 minecraft:packed_ice
fill 161 119 309 161 120 309 minecraft:packed_ice
fill 161 119 313 163 120 313 minecraft:packed_ice
setblock 162 119 278 minecraft:packed_ice
setblock 163 119 278 minecraft:snow_block
fill 163 119 309 164 120 309 minecraft:packed_ice
fill 163 119 316 164 119 316 minecraft:packed_ice
setblock 164 119 276 minecraft:packed_ice
setblock 164 119 277 minecraft:snow_block
fill 164 119 278 166 119 279 minecraft:packed_ice
fill 164 119 310 164 120 310 minecraft:packed_ice
fill 164 119 312 164 120 312 minecraft:packed_ice
setblock 165 119 276 minecraft:snow_block
fill 165 119 277 168 119 277 minecraft:packed_ice
setblock 165 119 316 minecraft:snow_block
fill 166 119 276 169 119 276 minecraft:packed_ice
fill 166 119 316 169 119 316 minecraft:packed_ice
setblock 167 119 278 minecraft:packed_ice
setblock 167 119 279 minecraft:snow_block
setblock 168 119 278 minecraft:snow_block
fill 168 119 279 168 121 279 minecraft:packed_ice
setblock 169 119 277 minecraft:snow_block
fill 169 119 278 172 119 278 minecraft:packed_ice
setblock 170 119 276 minecraft:snow_block
fill 170 119 277 173 119 277 minecraft:packed_ice
setblock 170 119 316 minecraft:snow_block
fill 171 119 276 174 119 276 minecraft:packed_ice
setblock 171 119 279 minecraft:packed_ice
fill 171 119 316 173 119 316 minecraft:packed_ice
setblock 172 119 279 minecraft:snow_block
setblock 173 119 278 minecraft:snow_block
setblock 174 119 277 minecraft:snow_block
fill 174 119 278 176 119 278 minecraft:packed_ice
setblock 175 119 276 minecraft:snow_block
fill 175 119 277 178 119 277 minecraft:packed_ice
setblock 176 119 275 minecraft:light_blue_concrete
fill 176 119 276 179 119 276 minecraft:packed_ice
fill 177 119 316 179 119 316 minecraft:packed_ice
setblock 178 119 278 minecraft:snow_block
setblock 179 119 277 minecraft:snow_block
setblock 179 119 278 minecraft:packed_ice
fill 179 119 299 181 122 299 minecraft:blue_ice
setblock 180 119 276 minecraft:snow_block
fill 180 119 277 180 122 277 minecraft:packed_ice
fill 180 119 298 181 122 298 minecraft:blue_ice
fill 180 119 300 181 122 300 minecraft:blue_ice
setblock 180 119 316 minecraft:snow_block
fill 181 119 276 181 122 276 minecraft:packed_ice
setblock 181 119 279 minecraft:packed_ice
setblock 181 119 280 minecraft:snow_block
fill 181 119 281 181 122 281 minecraft:packed_ice
setblock 181 119 284 minecraft:packed_ice
fill 181 119 301 181 120 303 minecraft:packed_ice
fill 181 119 316 181 122 316 minecraft:packed_ice
setblock 182 119 279 minecraft:snow_block
fill 182 119 280 182 122 280 minecraft:packed_ice
setblock 182 119 283 minecraft:packed_ice
setblock 182 119 284 minecraft:snow_block
fill 182 119 285 182 122 285 minecraft:packed_ice
fill 182 119 296 182 119 298 minecraft:packed_ice
setblock 182 119 299 minecraft:snow_block
fill 182 119 300 182 122 300 minecraft:packed_ice
setblock 182 119 303 minecraft:packed_ice
setblock 182 119 304 minecraft:snow_block
fill 182 119 305 182 122 305 minecraft:packed_ice
setblock 182 119 309 minecraft:snow_block
fill 182 119 310 182 122 310 minecraft:packed_ice
setblock 182 119 313 minecraft:packed_ice
setblock 182 119 314 minecraft:snow_block
fill 182 119 315 182 122 315 minecraft:packed_ice
fill 141 120 287 141 154 287 minecraft:blue_ice
setblock 141 120 289 minecraft:light_blue_concrete
fill 142 120 276 142 120 277 minecraft:packed_ice
setblock 142 120 278 minecraft:snow_block
fill 142 120 279 142 123 279 minecraft:packed_ice
setblock 142 120 282 minecraft:packed_ice
setblock 142 120 283 minecraft:snow_block
fill 142 120 284 142 123 284 minecraft:packed_ice
fill 142 120 286 142 121 286 minecraft:packed_ice
fill 142 120 294 142 120 297 minecraft:packed_ice
setblock 142 120 298 minecraft:snow_block
fill 142 120 299 142 120 302 minecraft:packed_ice
setblock 142 120 303 minecraft:snow_block
fill 142 120 304 142 120 307 minecraft:packed_ice
setblock 142 120 308 minecraft:snow_block
fill 142 120 309 142 120 312 minecraft:packed_ice
setblock 142 120 313 minecraft:snow_block
fill 142 120 314 142 121 316 minecraft:packed_ice
setblock 143 120 276 minecraft:packed_ice
setblock 143 120 277 minecraft:snow_block
fill 143 120 278 143 122 278 minecraft:packed_ice
fill 143 120 280 143 121 280 minecraft:packed_ice
setblock 143 120 282 minecraft:snow_block
fill 143 120 283 143 123 283 minecraft:packed_ice
setblock 143 120 296 minecraft:packed_ice
setblock 143 120 297 minecraft:snow_block
fill 143 120 298 143 120 301 minecraft:packed_ice
setblock 143 120 302 minecraft:snow_block
fill 143 120 303 143 120 306 minecraft:packed_ice
setblock 143 120 307 minecraft:snow_block
fill 143 120 308 143 120 311 minecraft:packed_ice
setblock 143 120 312 minecraft:snow_block
fill 143 120 313 143 123 313 minecraft:packed_ice
fill 143 120 315 143 120 316 minecraft:packed_ice
setblock 144 120 276 minecraft:snow_block
fill 144 120 277 147 120 277 minecraft:packed_ice
setblock 144 120 278 minecraft:light[level=15]
setblock 144 120 285 minecraft:light[level=12]
setblock 144 120 286 minecraft:light[level=15]
setblock 144 120 292 minecraft:light[level=12]
setblock 144 120 294 minecraft:light[level=15]
fill 144 120 297 144 120 300 minecraft:packed_ice
setblock 144 120 301 minecraft:snow_block
fill 144 120 302 144 123 302 minecraft:packed_ice
setblock 144 120 305 minecraft:packed_ice
setblock 144 120 306 minecraft:snow_block
fill 144 120 307 145 122 307 minecraft:packed_ice
setblock 144 120 313 minecraft:light[level=12]
setblock 144 120 315 minecraft:packed_ice
setblock 144 120 316 minecraft:snow_block
fill 145 120 276 148 120 276 minecraft:packed_ice
setblock 145 120 299 minecraft:packed_ice
setblock 145 120 300 minecraft:snow_block
fill 145 120 301 145 122 301 minecraft:packed_ice
setblock 145 120 305 minecraft:snow_block
fill 145 120 306 145 123 306 minecraft:packed_ice
setblock 145 120 315 minecraft:snow_block
fill 145 120 316 148 120 316 minecraft:packed_ice
fill 146 120 315 147 120 315 minecraft:packed_ice
setblock 148 120 277 minecraft:snow_block
setblock 149 120 276 minecraft:snow_block
setblock 149 120 316 minecraft:snow_block
setblock 150 120 276 minecraft:packed_ice
fill 150 120 302 150 121 305 minecraft:packed_ice
setblock 150 120 316 minecraft:packed_ice
setblock 151 120 278 minecraft:light[level=12]
setblock 151 120 285 minecraft:light[level=12]
setblock 151 120 292 minecraft:light[level=12]
setblock 151 120 299 minecraft:light[level=12]
fill 151 120 301 154 121 301 minecraft:packed_ice
fill 151 120 305 151 121 305 minecraft:packed_ice
setblock 151 120 306 minecraft:light[level=12]
setblock 151 120 313 minecraft:light[level=12]
setblock 152 120 278 minecraft:light[level=15]
setblock 152 120 286 minecraft:light[level=15]
setblock 152 120 294 minecraft:light[level=15]
fill 152 120 306 154 121 306 minecraft:packed_ice
setblock 152 120 310 minecraft:light[level=15]
fill 155 120 302 155 121 305 minecraft:packed_ice
setblock 158 120 278 minecraft:light[level=12]
setblock 158 120 285 minecraft:light[level=12]
setblock 158 120 292 minecraft:light[level=12]
setblock 158 120 299 minecraft:light[level=12]
setblock 158 120 306 minecraft:light[level=12]
setblock 158 120 313 minecraft:light[level=12]
fill 159 120 310 159 120 311 minecraft:packed_ice
fill 160 120 276 163 120 276 minecraft:packed_ice
setblock 160 120 286 minecraft:light[level=15]
setblock 160 120 294 minecraft:light[level=15]
setblock 160 120 302 minecraft:light[level=15]
setblock 160 120 309 minecraft:packed_ice
setblock 160 120 313 minecraft:packed_ice
fill 161 120 277 162 120 277 minecraft:packed_ice
fill 161 120 308 164 120 308 minecraft:packed_ice
setblock 162 120 278 minecraft:snow_block
fill 162 120 314 163 120 314 minecraft:packed_ice
setblock 163 120 277 minecraft:snow_block
fill 163 120 278 166 120 278 minecraft:packed_ice
setblock 164 120 276 minecraft:snow_block
fill 164 120 277 167 120 277 minecraft:packed_ice
fill 164 120 279 165 120 279 minecraft:packed_ice
setblock 164 120 313 minecraft:packed_ice
setblock 164 120 316 minecraft:snow_block
fill 165 120 276 168 120 276 minecraft:packed_ice
setblock 165 120 285 minecraft:light[level=12]
setblock 165 120 292 minecraft:light[level=12]
setblock 165 120 299 minecraft:light[level=12]
setblock 165 120 306 minecraft:light[level=12]
fill 165 120 309 165 120 312 minecraft:packed_ice
setblock 165 120 313 minecraft:light[level=12]
fill 165 120 316 168 120 316 minecraft:packed_ice
setblock 166 120 279 minecraft:snow_block
setblock 167 120 278 minecraft:snow_block
fill 167 120 279 167 121 279 minecraft:packed_ice
setblock 168 120 277 minecraft:snow_block
fill 168 120 278 171 120 278 minecraft:packed_ice
setblock 168 120 286 minecraft:light[level=15]
setblock 168 120 294 minecraft:light[level=15]
setblock 168 120 302 minecraft:light[level=15]
setblock 168 120 310 minecraft:light[level=15]
setblock 169 120 276 minecraft:snow_block
fill 169 120 277 172 120 277 minecraft:packed_ice
setblock 169 120 316 minecraft:snow_block
fill 170 120 276 173 120 276 minecraft:packed_ice
fill 170 120 316 171 120 316 minecraft:packed_ice
setblock 172 120 278 minecraft:snow_block
setblock 172 120 285 minecraft:light[level=12]
setblock 172 120 292 minecraft:light[level=12]
setblock 172 120 299 minecraft:light[level=12]
setblock 172 120 306 minecraft:light[level=12]
setblock 172 120 313 minecraft:light[level=12]
setblock 173 120 277 minecraft:snow_block
setblock 173 120 278 minecraft:packed_ice
setblock 174 120 276 minecraft:snow_block
fill 174 120 277 177 120 277 minecraft:packed_ice
fill 175 120 276 178 120 276 minecraft:packed_ice
fill 176 120 275 176 131 275 minecraft:blue_ice
setblock 176 120 278 minecraft:light[level=15]
setblock 176 120 286 minecraft:light[level=15]
setblock 176 120 294 minecraft:light[level=15]
fill 176 120 299 178 122 299 minecraft:blue_ice
setblock 176 120 302 minecraft:light[level=15]
setblock 176 120 310 minecraft:light[level=15]
setblock 178 120 277 minecraft:snow_block
fill 178 120 298 179 122 298 minecraft:blue_ice
fill 178 120 300 179 122 300 minecraft:blue_ice
setblock 178 120 316 minecraft:packed_ice
setblock 179 120 276 minecraft:snow_block
fill 179 120 277 179 122 277 minecraft:packed_ice
setblock 179 120 278 minecraft:light[level=12]
setblock 179 120 285 minecraft:light[level=12]
setblock 179 120 292 minecraft:light[level=12]
setblock 179 120 306 minecraft:light[level=12]
setblock 179 120 313 minecraft:light[level=12]
setblock 179 120 316 minecraft:snow_block
fill 180 120 276 180 123 276 minecraft:packed_ice
fill 180 120 278 180 120 279 minecraft:packed_ice
setblock 180 120 280 minecraft:snow_block
fill 180 120 297 181 121 297 minecraft:blue_ice
fill 180 120 301 180 121 301 minecraft:blue_ice
fill 180 120 316 180 123 316 minecraft:packed_ice
setblock 181 120 278 minecraft:packed_ice
setblock 181 120 279 minecraft:snow_block
fill 181 120 280 181 123 280 minecraft:packed_ice
setblock 181 120 284 minecraft:snow_block
setblock 181 120 304 minecraft:snow_block
fill 181 120 305 181 123 305 minecraft:packed_ice
setblock 182 120 278 minecraft:snow_block
fill 182 120 279 182 123 279 minecraft:packed_ice
setblock 182 120 283 minecraft:snow_block
fill 182 120 284 182 123 284 minecraft:packed_ice
setblock 182 120 287 minecraft:packed_ice
setblock 182 120 297 minecraft:packed_ice
setblock 182 120 298 minecraft:snow_block
fill 182 120 299 182 123 299 minecraft:packed_ice
setblock 182 120 303 minecraft:snow_block
fill 182 120 304 182 123 304 minecraft:packed_ice
setblock 182 120 307 minecraft:packed_ice
setblock 182 120 308 minecraft:snow_block
fill 182 120 309 182 123 309 minecraft:packed_ice
setblock 182 120 313 minecraft:snow_block
fill 182 120 314 182 123 314 minecraft:packed_ice
setblock 183 120 291 minecraft:light_blue_concrete
fill 183 120 292 183 165 293 minecraft:blue_ice
fill 141 121 289 141 131 289 minecraft:blue_ice
setblock 142 121 276 minecraft:packed_ice
setblock 142 121 277 minecraft:snow_block
fill 142 121 278 142 124 278 minecraft:packed_ice
setblock 142 121 282 minecraft:snow_block
fill 142 121 283 142 124 283 minecraft:packed_ice
fill 142 121 295 142 121 296 minecraft:packed_ice
setblock 142 121 297 minecraft:snow_block
fill 142 121 298 142 121 301 minecraft:packed_ice
setblock 142 121 302 minecraft:snow_block
fill 142 121 303 142 121 306 minecraft:packed_ice
setblock 142 121 307 minecraft:snow_block
fill 142 121 308 142 121 311 minecraft:packed_ice
setblock 142 121 312 minecraft:snow_block
fill 142 121 313 142 124 313 minecraft:packed_ice
setblock 143 121 276 minecraft:snow_block
fill 143 121 277 146 121 277 minecraft:packed_ice
setblock 143 121 281 minecraft:snow_block
fill 143 121 282 143 124 282 minecraft:packed_ice
fill 143 121 284 143 122 284 minecraft:packed_ice
setblock 143 121 296 minecraft:snow_block
fill 143 121 297 143 121 300 minecraft:packed_ice
setblock 143 121 301 minecraft:snow_block
fill 143 121 302 143 121 305 minecraft:packed_ice
setblock 143 121 306 minecraft:snow_block
fill 143 121 307 143 121 310 minecraft:packed_ice
setblock 143 121 311 minecraft:snow_block
fill 143 121 312 143 124 312 minecraft:packed_ice
setblock 143 121 315 minecraft:packed_ice
setblock 143 121 316 minecraft:snow_block
fill 144 121 276 147 121 276 minecraft:packed_ice
fill 144 121 298 144 121 299 minecraft:packed_ice
setblock 144 121 300 minecraft:snow_block
fill 144 121 301 144 124 301 minecraft:packed_ice
setblock 144 121 305 minecraft:snow_block
fill 144 121 306 144 124 306 minecraft:packed_ice
setblock 144 121 310 minecraft:snow_block
setblock 144 121 315 minecraft:snow_block
fill 144 121 316 147 121 316 minecraft:packed_ice
setblock 145 121 300 minecraft:packed_ice
fill 145 121 304 146 121 304 minecraft:snow_block
fill 145 121 305 145 124 305 minecraft:packed_ice
fill 145 121 315 146 121 315 minecraft:packed_ice
setblock 148 121 276 minecraft:snow_block
setblock 148 121 316 minecraft:snow_block
setblock 149 121 276 minecraft:packed_ice
fill 149 121 302 149 121 304 minecraft:packed_ice
setblock 150 121 301 minecraft:packed_ice
fill 150 121 306 151 121 306 minecraft:packed_ice
fill 151 121 300 154 121 300 minecraft:packed_ice
fill 152 121 307 154 121 307 minecraft:packed_ice
setblock 155 121 301 minecraft:packed_ice
setblock 155 121 306 minecraft:packed_ice
fill 156 121 302 156 121 305 minecraft:packed_ice
fill 159 121 278 159 123 278 minecraft:packed_ice
fill 160 121 276 161 121 277 minecraft:packed_ice
fill 160 121 279 160 123 279 minecraft:packed_ice
fill 161 121 278 161 123 278 minecraft:packed_ice
setblock 162 121 276 minecraft:packed_ice
setblock 162 121 277 minecraft:snow_block
setblock 163 121 276 minecraft:snow_block
fill 163 121 277 165 121 278 minecraft:packed_ice
fill 164 121 276 167 121 276 minecraft:packed_ice
setblock 164 121 279 minecraft:packed_ice
setblock 165 121 279 minecraft:snow_block
fill 165 121 316 167 121 316 minecraft:packed_ice
setblock 166 121 277 minecraft:packed_ice
setblock 166 121 278 minecraft:snow_block
fill 166 121 279 166 122 279 minecraft:packed_ice
setblock 167 121 277 minecraft:snow_block
fill 167 121 278 170 121 278 minecraft:packed_ice
setblock 168 121 276 minecraft:snow_block
fill 168 121 277 171 121 277 minecraft:packed_ice
setblock 168 121 316 minecraft:snow_block
fill 169 121 276 172 121 276 minecraft:packed_ice
setblock 171 121 278 minecraft:snow_block
setblock 172 121 277 minecraft:snow_block
setblock 173 121 276 minecraft:snow_block
fill 173 121 277 176 121 277 minecraft:packed_ice
fill 174 121 276 177 121 276 minecraft:packed_ice
fill 174 121 299 175 122 299 minecraft:blue_ice
fill 176 121 298 177 121 298 minecraft:blue_ice
fill 176 121 300 177 121 300 minecraft:blue_ice
setblock 177 121 277 minecraft:snow_block
setblock 178 121 276 minecraft:snow_block
setblock 178 121 277 minecraft:packed_ice
fill 179 121 276 179 124 276 minecraft:packed_ice
fill 179 121 316 179 122 316 minecraft:packed_ice
setblock 181 121 278 minecraft:snow_block
fill 181 121 279 181 124 279 minecraft:packed_ice
setblock 181 121 283 minecraft:snow_block
fill 181 121 284 181 124 284 minecraft:packed_ice
fill 181 121 301 181 121 302 minecraft:packed_ice
setblock 181 121 303 minecraft:snow_block
fill 181 121 304 181 124 304 minecraft:packed_ice
fill 181 121 306 181 121 307 minecraft:packed_ice
setblock 182 121 277 minecraft:snow_block
fill 182 121 278 182 124 278 minecraft:packed_ice
setblock 182 121 282 minecraft:snow_block
fill 182 121 283 182 124 283 minecraft:packed_ice
setblock 182 121 287 minecraft:snow_block
setblock 182 121 297 minecraft:snow_block
fill 182 121 298 182 122 298 minecraft:packed_ice
setblock 182 121 302 minecraft:snow_block
fill 182 121 303 182 124 303 minecraft:packed_ice
setblock 182 121 307 minecraft:snow_block
fill 182 121 308 182 124 308 minecraft:packed_ice
setblock 182 121 312 minecraft:snow_block
fill 182 121 313 182 124 313 minecraft:packed_ice
fill 183 121 291 183 165 291 minecraft:blue_ice
fill 183 121 303 183 135 304 minecraft:blue_ice
setblock 183 121 305 minecraft:light_blue_concrete
setblock 183 121 306 minecraft:white_concrete
fill 183 121 307 183 146 311 minecraft:blue_ice
setblock 183 121 316 minecraft:light_blue_concrete
setblock 142 122 276 minecraft:snow_block
fill 142 122 277 142 124 277 minecraft:packed_ice
setblock 142 122 281 minecraft:snow_block
fill 142 122 282 142 125 282 minecraft:packed_ice
setblock 142 122 286 minecraft:snow_block
fill 142 122 287 142 125 287 minecraft:packed_ice
setblock 142 122 295 minecraft:packed_ice
setblock 142 122 296 minecraft:snow_block
fill 142 122 297 142 122 300 minecraft:packed_ice
setblock 142 122 301 minecraft:snow_block
fill 142 122 302 142 122 305 minecraft:packed_ice
setblock 142 122 306 minecraft:snow_block
fill 142 122 307 142 122 310 minecraft:packed_ice
setblock 142 122 311 minecraft:snow_block
fill 142 122 312 142 125 312 minecraft:packed_ice
fill 142 122 314 142 122 315 minecraft:packed_ice
setblock 142 122 316 minecraft:snow_block
fill 143 122 276 146 122 276 minecraft:packed_ice
setblock 143 122 280 minecraft:snow_block
fill 143 122 281 143 123 281 minecraft:packed_ice
fill 143 122 297 143 122 299 minecraft:packed_ice
setblock 143 122 300 minecraft:snow_block
fill 143 122 301 143 122 304 minecraft:packed_ice
setblock 143 122 305 minecraft:snow_block
fill 143 122 306 143 122 309 minecraft:packed_ice
setblock 143 122 310 minecraft:snow_block
fill 143 122 311 143 125 311 minecraft:packed_ice
fill 143 122 316 146 122 316 minecraft:packed_ice
setblock 144 122 299 minecraft:snow_block
fill 144 122 300 144 125 300 minecraft:packed_ice
setblock 144 122 304 minecraft:snow_block
fill 144 122 305 144 125 305 minecraft:packed_ice
setblock 144 122 309 minecraft:snow_block
fill 144 122 310 144 125 310 minecraft:packed_ice
setblock 145 122 303 minecraft:snow_block
fill 145 122 304 145 125 304 minecraft:packed_ice
fill 146 122 304 146 131 304 minecraft:snow_block
setblock 147 122 276 minecraft:snow_block
setblock 147 122 316 minecraft:snow_block
fill 160 122 276 160 122 277 minecraft:packed_ice
setblock 161 122 276 minecraft:packed_ice
setblock 162 122 276 minecraft:snow_block
fill 162 122 277 165 122 277 minecraft:packed_ice
fill 163 122 276 166 122 276 minecraft:packed_ice
fill 163 122 278 164 122 278 minecraft:packed_ice
setblock 165 122 278 minecraft:snow_block
setblock 166 122 277 minecraft:snow_block
fill 166 122 278 169 122 278 minecraft:packed_ice
setblock 167 122 276 minecraft:snow_block
fill 167 122 277 170 122 277 minecraft:packed_ice
fill 168 122 276 171 122 276 minecraft:packed_ice
setblock 171 122 277 minecraft:snow_block
setblock 172 122 276 minecraft:snow_block
setblock 172 122 277 minecraft:packed_ice
fill 173 122 276 176 122 276 minecraft:packed_ice
setblock 177 122 276 minecraft:snow_block
setblock 177 122 298 minecraft:blue_ice
setblock 177 122 300 minecraft:blue_ice
fill 178 122 276 178 125 276 minecraft:packed_ice
setblock 181 122 277 minecraft:snow_block
fill 181 122 278 181 124 278 minecraft:packed_ice
setblock 181 122 282 minecraft:snow_block
fill 181 122 283 181 125 283 minecraft:packed_ice
setblock 181 122 302 minecraft:snow_block
fill 181 122 303 181 125 303 minecraft:packed_ice
setblock 181 122 306 minecraft:packed_ice
setblock 181 122 307 minecraft:snow_block
fill 181 122 308 181 124 309 minecraft:packed_ice
setblock 182 122 276 minecraft:snow_block
fill 182 122 277 182 125 277 minecraft:packed_ice
setblock 182 122 281 minecraft:snow_block
fill 182 122 282 182 125 282 minecraft:packed_ice
setblock 182 122 286 minecraft:snow_block
fill 182 122 287 182 125 287 minecraft:packed_ice
setblock 182 122 301 minecraft:snow_block
fill 182 122 302 182 125 302 minecraft:packed_ice
setblock 182 122 306 minecraft:snow_block
fill 182 122 307 182 125 307 minecraft:packed_ice
setblock 182 122 311 minecraft:snow_block
fill 182 122 312 182 125 312 minecraft:packed_ice
setblock 182 122 316 minecraft:snow_block
fill 183 122 282 183 129 285 minecraft:blue_ice
setblock 183 122 286 minecraft:light_blue_concrete
fill 183 122 287 183 127 290 minecraft:blue_ice
fill 183 122 305 183 165 306 minecraft:blue_ice
fill 183 122 316 183 166 316 minecraft:blue_ice
fill 142 123 276 145 123 276 minecraft:packed_ice
setblock 142 123 280 minecraft:snow_block
fill 142 123 281 142 126 281 minecraft:packed_ice
setblock 142 123 285 minecraft:snow_block
fill 142 123 286 142 126 286 minecraft:packed_ice
fill 142 123 288 142 124 288 minecraft:packed_ice
setblock 142 123 295 minecraft:snow_block
fill 142 123 296 142 123 299 minecraft:packed_ice
setblock 142 123 300 minecraft:snow_block
fill 142 123 301 142 123 304 minecraft:packed_ice
setblock 142 123 305 minecraft:snow_block
fill 142 123 306 142 123 309 minecraft:packed_ice
setblock 142 123 310 minecraft:snow_block
fill 142 123 311 142 126 311 minecraft:packed_ice
setblock 142 123 314 minecraft:packed_ice
setblock 142 123 315 minecraft:snow_block
fill 142 123 316 145 123 316 minecraft:packed_ice
setblock 143 123 280 minecraft:packed_ice
setblock 143 123 284 minecraft:snow_block
fill 143 123 297 143 123 298 minecraft:packed_ice
setblock 143 123 299 minecraft:snow_block
fill 143 123 300 143 123 303 minecraft:packed_ice
setblock 143 123 304 minecraft:snow_block
fill 143 123 305 143 123 308 minecraft:packed_ice
setblock 143 123 309 minecraft:snow_block
fill 143 123 310 143 126 310 minecraft:packed_ice
setblock 144 123 299 minecraft:packed_ice
setblock 144 123 303 minecraft:snow_block
fill 144 123 304 144 126 304 minecraft:packed_ice
setblock 144 123 307 minecraft:packed_ice
setblock 144 123 308 minecraft:snow_block
fill 144 123 309 144 126 309 minecraft:packed_ice
setblock 145 123 302 minecraft:snow_block
fill 145 123 303 145 124 303 minecraft:packed_ice
setblock 146 123 316 minecraft:snow_block
fill 159 123 277 164 123 277 minecraft:packed_ice
setblock 159 123 279 minecraft:packed_ice
setblock 161 123 276 minecraft:snow_block
setblock 161 123 279 minecraft:packed_ice
fill 162 123 276 165 123 276 minecraft:packed_ice
setblock 164 123 278 minecraft:snow_block
setblock 165 123 277 minecraft:snow_block
fill 165 123 278 167 123 278 minecraft:packed_ice
setblock 166 123 276 minecraft:snow_block
fill 166 123 277 169 123 277 minecraft:packed_ice
fill 167 123 276 170 123 276 minecraft:packed_ice
fill 168 123 311 170 200 312 minecraft:snow_block
fill 169 123 310 169 200 310 minecraft:snow_block
fill 169 123 313 169 200 313 minecraft:snow_block
setblock 170 123 277 minecraft:snow_block
setblock 171 123 276 minecraft:snow_block
setblock 172 123 276 minecraft:packed_ice
setblock 177 123 276 minecraft:packed_ice
setblock 180 123 277 minecraft:snow_block
setblock 181 123 276 minecraft:snow_block
setblock 181 123 277 minecraft:packed_ice
setblock 181 123 281 minecraft:snow_block
fill 181 123 282 181 126 282 minecraft:packed_ice
fill 181 123 302 181 126 302 minecraft:packed_ice
setblock 181 123 306 minecraft:snow_block
fill 181 123 307 181 126 307 minecraft:packed_ice
setblock 181 123 310 minecraft:packed_ice
setblock 181 123 316 minecraft:snow_block
fill 182 123 276 182 126 276 minecraft:packed_ice
setblock 182 123 280 minecraft:snow_block
fill 182 123 281 182 126 281 minecraft:packed_ice
setblock 182 123 285 minecraft:snow_block
fill 182 123 286 182 126 286 minecraft:packed_ice
setblock 182 123 300 minecraft:snow_block
fill 182 123 301 182 126 301 minecraft:packed_ice
setblock 182 123 305 minecraft:snow_block
fill 182 123 306 182 126 306 minecraft:packed_ice
setblock 182 123 310 minecraft:snow_block
fill 182 123 311 182 126 311 minecraft:packed_ice
setblock 182 123 315 minecraft:snow_block
fill 182 123 316 182 126 316 minecraft:packed_ice
fill 183 123 286 183 163 286 minecraft:blue_ice
setblock 142 124 279 minecraft:snow_block
fill 142 124 280 142 127 280 minecraft:packed_ice
setblock 142 124 284 minecraft:snow_block
fill 142 124 285 143 126 285 minecraft:packed_ice
setblock 142 124 289 minecraft:snow_block
fill 142 124 296 142 124 298 minecraft:packed_ice
setblock 142 124 299 minecraft:snow_block
fill 142 124 300 142 124 303 minecraft:packed_ice
setblock 142 124 304 minecraft:snow_block
fill 142 124 305 142 124 308 minecraft:packed_ice
setblock 142 124 309 minecraft:snow_block
fill 142 124 310 142 127 310 minecraft:packed_ice
setblock 142 124 314 minecraft:snow_block
fill 142 124 315 142 126 316 minecraft:packed_ice
setblock 143 124 283 minecraft:snow_block
fill 143 124 284 143 127 284 minecraft:packed_ice
setblock 143 124 298 minecraft:snow_block
fill 143 124 299 143 124 302 minecraft:packed_ice
setblock 143 124 303 minecraft:snow_block
fill 143 124 304 143 124 307 minecraft:packed_ice
setblock 143 124 308 minecraft:snow_block
fill 143 124 309 143 127 309 minecraft:packed_ice
setblock 143 124 313 minecraft:snow_block
fill 143 124 316 144 124 316 minecraft:packed_ice
setblock 144 124 302 minecraft:snow_block
fill 144 124 303 144 127 303 minecraft:packed_ice
setblock 144 124 307 minecraft:snow_block
fill 144 124 308 144 127 308 minecraft:packed_ice
setblock 145 124 306 minecraft:snow_block
setblock 145 124 316 minecraft:snow_block
fill 148 124 279 148 134 279 minecraft:snow_block
setblock 153 124 317 minecraft:light_blue_concrete
fill 154 124 317 154 145 317 minecraft:blue_ice
setblock 160 124 317 minecraft:light_blue_concrete
fill 161 124 276 164 124 276 minecraft:packed_ice
fill 161 124 317 163 165 317 minecraft:blue_ice
fill 162 124 277 163 124 277 minecraft:packed_ice
setblock 164 124 277 minecraft:snow_block
setblock 165 124 276 minecraft:snow_block
fill 165 124 277 168 124 277 minecraft:packed_ice
fill 166 124 276 169 124 276 minecraft:packed_ice
fill 167 124 311 167 125 312 minecraft:packed_ice
fill 168 124 310 168 125 310 minecraft:packed_ice
fill 168 124 313 168 125 313 minecraft:packed_ice
setblock 170 124 276 minecraft:snow_block
fill 170 124 310 170 125 310 minecraft:packed_ice
fill 170 124 313 170 125 313 minecraft:packed_ice
fill 171 124 311 171 125 312 minecraft:packed_ice
setblock 179 124 316 minecraft:packed_ice
setblock 180 124 276 minecraft:snow_block
setblock 180 124 316 minecraft:snow_block
fill 181 124 276 181 127 276 minecraft:packed_ice
setblock 181 124 280 minecraft:snow_block
fill 181 124 281 181 127 281 minecraft:packed_ice
setblock 181 124 285 minecraft:snow_block
setblock 181 124 305 minecraft:snow_block
fill 181 124 306 181 127 306 minecraft:packed_ice
setblock 181 124 310 minecraft:snow_block
fill 181 124 311 181 126 312 minecraft:packed_ice
fill 181 124 316 181 127 316 minecraft:packed_ice
setblock 182 124 279 minecraft:snow_block
fill 182 124 280 182 127 280 minecraft:packed_ice
setblock 182 124 284 minecraft:snow_block
fill 182 124 285 182 127 285 minecraft:packed_ice
setblock 182 124 288 minecraft:packed_ice
setblock 182 124 299 minecraft:snow_block
fill 182 124 300 182 127 300 minecraft:packed_ice
setblock 182 124 304 minecraft:snow_block
fill 182 124 305 182 127 305 minecraft:packed_ice
setblock 182 124 309 minecraft:snow_block
fill 182 124 310 182 127 310 minecraft:packed_ice
setblock 182 124 314 minecraft:snow_block
fill 182 124 315 182 127 315 minecraft:packed_ice
setblock 142 125 278 minecraft:snow_block
fill 142 125 279 142 128 279 minecraft:packed_ice
setblock 142 125 283 minecraft:snow_block
fill 142 125 284 142 128 284 minecraft:packed_ice
setblock 142 125 288 minecraft:snow_block
fill 142 125 289 142 126 291 minecraft:packed_ice
fill 142 125 295 142 125 297 minecraft:packed_ice
setblock 142 125 298 minecraft:snow_block
fill 142 125 299 142 125 302 minecraft:packed_ice
setblock 142 125 303 minecraft:snow_block
fill 142 125 304 142 125 307 minecraft:packed_ice
setblock 142 125 308 minecraft:snow_block
fill 142 125 309 142 128 309 minecraft:packed_ice
setblock 142 125 313 minecraft:snow_block
fill 142 125 314 142 128 314 minecraft:packed_ice
setblock 143 125 282 minecraft:snow_block
fill 143 125 283 143 128 283 minecraft:packed_ice
setblock 143 125 286 minecraft:packed_ice
fill 143 125 298 143 125 301 minecraft:packed_ice
setblock 143 125 302 minecraft:snow_block
fill 143 125 303 143 125 306 minecraft:packed_ice
setblock 143 125 307 minecraft:snow_block
fill 143 125 308 143 128 308 minecraft:packed_ice
setblock 143 125 312 minecraft:snow_block
fill 143 125 313 143 128 313 minecraft:packed_ice
setblock 143 125 316 minecraft:packed_ice
fill 144 125 285 144 131 285 minecraft:packed_ice
setblock 144 125 301 minecraft:snow_block
fill 144 125 302 144 128 302 minecraft:packed_ice
setblock 144 125 306 minecraft:snow_block
fill 144 125 307 144 128 307 minecraft:packed_ice
setblock 144 125 316 minecraft:snow_block
setblock 145 125 305 minecraft:snow_block
fill 145 125 306 145 126 306 minecraft:packed_ice
fill 152 125 276 152 128 276 minecraft:blue_ice
fill 153 125 317 153 163 317 minecraft:blue_ice
fill 160 125 317 160 135 317 minecraft:blue_ice
fill 161 125 276 163 125 276 minecraft:packed_ice
setblock 162 125 277 minecraft:packed_ice
setblock 163 125 277 minecraft:snow_block
setblock 164 125 276 minecraft:snow_block
fill 164 125 277 166 125 277 minecraft:packed_ice
fill 165 125 276 168 125 276 minecraft:packed_ice
setblock 167 125 310 minecraft:packed_ice
setblock 167 125 313 minecraft:packed_ice
fill 168 125 309 170 125 309 minecraft:packed_ice
fill 168 125 314 170 125 314 minecraft:packed_ice
setblock 169 125 276 minecraft:snow_block
setblock 171 125 310 minecraft:packed_ice
setblock 171 125 313 minecraft:packed_ice
setblock 179 125 276 minecraft:snow_block
setblock 179 125 316 minecraft:snow_block
fill 180 125 276 180 128 276 minecraft:packed_ice
fill 180 125 316 180 128 316 minecraft:packed_ice
setblock 181 125 279 minecraft:snow_block
fill 181 125 280 181 128 280 minecraft:packed_ice
setblock 181 125 284 minecraft:snow_block
fill 181 125 285 181 128 285 minecraft:packed_ice
setblock 181 125 304 minecraft:snow_block
fill 181 125 305 181 128 305 minecraft:packed_ice
setblock 181 125 308 minecraft:packed_ice
setblock 181 125 309 minecraft:snow_block
fill 181 125 310 181 128 310 minecraft:packed_ice
setblock 181 125 313 minecraft:packed_ice
setblock 181 125 314 minecraft:snow_block
setblock 182 125 278 minecraft:snow_block
fill 182 125 279 182 128 279 minecraft:packed_ice
setblock 182 125 283 minecraft:snow_block
fill 182 125 284 182 128 284 minecraft:packed_ice
setblock 182 125 288 minecraft:snow_block
fill 182 125 289 182 128 289 minecraft:packed_ice
fill 182 125 299 182 128 299 minecraft:packed_ice
setblock 182 125 303 minecraft:snow_block
fill 182 125 304 182 128 304 minecraft:packed_ice
setblock 182 125 308 minecraft:snow_block
fill 182 125 309 182 128 309 minecraft:packed_ice
setblock 182 125 313 minecraft:snow_block
fill 182 125 314 182 128 314 minecraft:packed_ice
fill 183 125 313 183 161 313 minecraft:blue_ice
setblock 183 125 314 minecraft:light_blue_concrete
setblock 142 126 282 minecraft:snow_block
fill 142 126 283 142 129 283 minecraft:packed_ice
setblock 142 126 287 minecraft:snow_block
fill 142 126 288 143 128 288 minecraft:packed_ice
setblock 142 126 292 minecraft:snow_block
fill 142 126 293 142 126 296 minecraft:packed_ice
setblock 142 126 297 minecraft:snow_block
fill 142 126 298 142 126 301 minecraft:packed_ice
setblock 142 126 302 minecraft:snow_block
fill 142 126 303 142 126 306 minecraft:packed_ice
setblock 142 126 307 minecraft:snow_block
fill 142 126 308 142 129 308 minecraft:packed_ice
setblock 142 126 312 minecraft:snow_block
fill 142 126 313 142 129 313 minecraft:packed_ice
setblock 143 126 286 minecraft:snow_block
fill 143 126 287 143 129 287 minecraft:packed_ice
fill 143 126 298 143 126 300 minecraft:packed_ice
setblock 143 126 301 minecraft:snow_block
fill 143 126 302 143 126 305 minecraft:packed_ice
setblock 143 126 306 minecraft:snow_block
fill 143 126 307 143 129 307 minecraft:packed_ice
setblock 143 126 311 minecraft:snow_block
fill 143 126 312 143 129 312 minecraft:packed_ice
setblock 143 126 316 minecraft:snow_block
setblock 144 126 278 minecraft:light[level=12]
setblock 144 126 292 minecraft:light[level=12]
setblock 144 126 299 minecraft:light[level=12]
fill 144 126 301 144 127 301 minecraft:packed_ice
setblock 144 126 305 minecraft:snow_block
fill 144 126 306 144 129 306 minecraft:packed_ice
setblock 144 126 310 minecraft:snow_block
setblock 144 126 313 minecraft:light[level=12]
fill 144 126 316 144 129 316 minecraft:packed_ice
fill 145 126 304 145 131 304 minecraft:snow_block
fill 146 126 303 146 131 303 minecraft:snow_block
fill 146 126 305 146 131 305 minecraft:snow_block
fill 147 126 304 147 131 304 minecraft:snow_block
fill 151 126 276 151 127 278 minecraft:blue_ice
setblock 151 126 285 minecraft:light[level=12]
setblock 151 126 292 minecraft:light[level=12]
setblock 151 126 299 minecraft:light[level=12]
setblock 151 126 306 minecraft:light[level=12]
setblock 151 126 313 minecraft:light[level=12]
fill 152 126 277 152 127 279 minecraft:blue_ice
fill 153 126 275 153 127 278 minecraft:blue_ice
fill 154 126 275 155 161 275 minecraft:blue_ice
setblock 156 126 275 minecraft:light_blue_concrete
fill 157 126 275 157 163 275 minecraft:blue_ice
setblock 158 126 278 minecraft:light[level=12]
setblock 158 126 285 minecraft:light[level=12]
setblock 158 126 292 minecraft:light[level=12]
setblock 158 126 299 minecraft:light[level=12]
setblock 158 126 306 minecraft:light[level=12]
setblock 158 126 313 minecraft:light[level=12]
fill 160 126 276 162 126 276 minecraft:packed_ice
setblock 162 126 277 minecraft:snow_block
setblock 163 126 276 minecraft:snow_block
fill 163 126 277 165 127 277 minecraft:packed_ice
fill 164 126 276 167 126 276 minecraft:packed_ice
setblock 165 126 278 minecraft:light[level=12]
setblock 165 126 285 minecraft:light[level=12]
setblock 165 126 292 minecraft:light[level=12]
setblock 165 126 299 minecraft:light[level=12]
setblock 165 126 306 minecraft:light[level=12]
setblock 165 126 313 minecraft:light[level=12]
setblock 168 126 276 minecraft:snow_block
setblock 172 126 278 minecraft:light[level=12]
setblock 172 126 285 minecraft:light[level=12]
setblock 172 126 292 minecraft:light[level=12]
setblock 172 126 299 minecraft:light[level=12]
setblock 172 126 306 minecraft:light[level=12]
setblock 172 126 313 minecraft:light[level=12]
setblock 178 126 276 minecraft:snow_block
setblock 178 126 316 minecraft:snow_block
fill 179 126 276 179 129 276 minecraft:packed_ice
setblock 179 126 278 minecraft:light[level=12]
setblock 179 126 285 minecraft:light[level=12]
setblock 179 126 292 minecraft:light[level=12]
setblock 179 126 299 minecraft:light[level=12]
fill 179 126 301 179 132 301 minecraft:packed_ice
setblock 179 126 306 minecraft:light[level=12]
setblock 179 126 313 minecraft:light[level=12]
fill 179 126 316 179 129 316 minecraft:packed_ice
fill 180 126 306 180 126 308 minecraft:packed_ice
setblock 180 126 309 minecraft:snow_block
fill 180 126 310 180 129 310 minecraft:packed_ice
setblock 181 126 279 minecraft:packed_ice
setblock 181 126 283 minecraft:snow_block
fill 181 126 284 181 129 284 minecraft:packed_ice
fill 181 126 286 181 127 286 minecraft:packed_ice
setblock 181 126 303 minecraft:snow_block
fill 181 126 304 181 129 304 minecraft:packed_ice
setblock 181 126 308 minecraft:snow_block
fill 181 126 309 181 129 309 minecraft:packed_ice
setblock 181 126 313 minecraft:snow_block
fill 181 126 314 181 128 315 minecraft:packed_ice
setblock 182 126 277 minecraft:snow_block
fill 182 126 278 182 129 278 minecraft:packed_ice
setblock 182 126 282 minecraft:snow_block
fill 182 126 283 182 129 283 minecraft:packed_ice
setblock 182 126 287 minecraft:snow_block
fill 182 126 288 182 129 288 minecraft:packed_ice
fill 182 126 290 182 127 290 minecraft:packed_ice
setblock 182 126 302 minecraft:snow_block
fill 182 126 303 182 129 303 minecraft:packed_ice
setblock 182 126 307 minecraft:snow_block
fill 182 126 308 182 129 308 minecraft:packed_ice
setblock 182 126 312 minecraft:snow_block
fill 182 126 313 182 129 313 minecraft:packed_ice
fill 183 126 314 183 140 314 minecraft:blue_ice
setblock 142 127 281 minecraft:snow_block
fill 142 127 282 142 130 282 minecraft:packed_ice
setblock 142 127 285 minecraft:packed_ice
setblock 142 127 286 minecraft:snow_block
fill 142 127 287 142 130 287 minecraft:packed_ice
fill 142 127 289 142 127 290 minecraft:packed_ice
setblock 142 127 291 minecraft:snow_block
fill 142 127 292 142 127 295 minecraft:packed_ice
setblock 142 127 296 minecraft:snow_block
fill 142 127 297 142 127 300 minecraft:packed_ice
setblock 142 127 301 minecraft:snow_block
fill 142 127 302 142 127 305 minecraft:packed_ice
setblock 142 127 306 minecraft:snow_block
fill 142 127 307 142 130 307 minecraft:packed_ice
setblock 142 127 311 minecraft:snow_block
fill 142 127 312 142 130 312 minecraft:packed_ice
setblock 142 127 315 minecraft:packed_ice
setblock 142 127 316 minecraft:snow_block
setblock 143 127 285 minecraft:snow_block
fill 143 127 286 143 130 286 minecraft:packed_ice
setblock 143 127 289 minecraft:packed_ice
setblock 143 127 290 minecraft:snow_block
fill 143 127 291 143 130 291 minecraft:packed_ice
fill 143 127 298 143 127 299 minecraft:packed_ice
setblock 143 127 300 minecraft:snow_block
fill 143 127 301 143 127 304 minecraft:packed_ice
setblock 143 127 305 minecraft:snow_block
fill 143 127 306 143 130 306 minecraft:packed_ice
setblock 143 127 310 minecraft:snow_block
fill 143 127 311 144 129 311 minecraft:packed_ice
setblock 143 127 314 minecraft:packed_ice
fill 143 127 316 143 130 316 minecraft:packed_ice
setblock 144 127 304 minecraft:snow_block
fill 144 127 305 144 130 305 minecraft:packed_ice
setblock 144 127 309 minecraft:snow_block
fill 144 127 310 144 130 310 minecraft:packed_ice
setblock 152 127 275 minecraft:light_blue_concrete
fill 156 127 275 156 165 275 minecraft:blue_ice
fill 160 127 276 161 127 276 minecraft:packed_ice
setblock 162 127 276 minecraft:snow_block
fill 162 127 277 162 130 277 minecraft:packed_ice
setblock 163 127 275 minecraft:white_concrete
fill 163 127 276 166 127 276 minecraft:packed_ice
fill 166 127 284 167 200 285 minecraft:snow_block
fill 166 127 304 167 128 305 minecraft:snow_block
setblock 167 127 276 minecraft:snow_block
fill 168 127 276 168 130 276 minecraft:packed_ice
setblock 177 127 276 minecraft:snow_block
setblock 177 127 316 minecraft:snow_block
fill 178 127 276 178 130 276 minecraft:packed_ice
fill 178 127 316 178 130 316 minecraft:packed_ice
fill 179 127 315 180 129 315 minecraft:packed_ice
fill 180 127 305 180 127 307 minecraft:packed_ice
setblock 180 127 308 minecraft:snow_block
fill 180 127 309 180 130 309 minecraft:packed_ice
fill 180 127 311 180 127 312 minecraft:packed_ice
setblock 181 127 282 minecraft:snow_block
fill 181 127 283 181 130 283 minecraft:packed_ice
setblock 181 127 287 minecraft:snow_block
fill 181 127 288 181 130 288 minecraft:packed_ice
setblock 181 127 302 minecraft:snow_block
fill 181 127 303 181 130 303 minecraft:packed_ice
setblock 181 127 307 minecraft:snow_block
fill 181 127 308 181 130 308 minecraft:packed_ice
setblock 181 127 311 minecraft:packed_ice
setblock 181 127 312 minecraft:snow_block
fill 181 127 313 181 130 313 minecraft:packed_ice
setblock 182 127 276 minecraft:snow_block
fill 182 127 277 182 130 277 minecraft:packed_ice
setblock 182 127 281 minecraft:snow_block
fill 182 127 282 182 130 282 minecraft:packed_ice
setblock 182 127 286 minecraft:snow_block
fill 182 127 287 182 130 287 minecraft:packed_ice
setblock 182 127 291 minecraft:snow_block
setblock 182 127 301 minecraft:snow_block
fill 182 127 302 182 130 302 minecraft:packed_ice
setblock 182 127 306 minecraft:snow_block
fill 182 127 307 182 130 307 minecraft:packed_ice
setblock 182 127 311 minecraft:snow_block
fill 182 127 312 182 130 312 minecraft:packed_ice
setblock 182 127 316 minecraft:snow_block
fill 183 127 276 183 145 277 minecraft:blue_ice
setblock 183 127 278 minecraft:light_blue_concrete
fill 183 127 279 183 165 280 minecraft:blue_ice
setblock 142 128 280 minecraft:snow_block
fill 142 128 281 142 131 281 minecraft:packed_ice
setblock 142 128 285 minecraft:snow_block
fill 142 128 286 142 131 286 minecraft:packed_ice
setblock 142 128 289 minecraft:packed_ice
setblock 142 128 290 minecraft:snow_block
fill 142 128 291 142 128 294 minecraft:packed_ice
setblock 142 128 295 minecraft:snow_block
fill 142 128 296 142 128 299 minecraft:packed_ice
setblock 142 128 300 minecraft:snow_block
fill 142 128 301 142 128 304 minecraft:packed_ice
setblock 142 128 305 minecraft:snow_block
fill 142 128 306 142 131 306 minecraft:packed_ice
setblock 142 128 310 minecraft:snow_block
fill 142 128 311 142 131 311 minecraft:packed_ice
setblock 142 128 315 minecraft:snow_block
fill 142 128 316 142 131 316 minecraft:packed_ice
setblock 143 128 284 minecraft:snow_block
fill 143 128 285 143 131 285 minecraft:packed_ice
setblock 143 128 289 minecraft:snow_block
fill 143 128 290 143 131 290 minecraft:packed_ice
fill 143 128 292 143 128 293 minecraft:packed_ice
setblock 143 128 294 minecraft:snow_block
fill 143 128 295 143 128 298 minecraft:packed_ice
setblock 143 128 299 minecraft:snow_block
fill 143 128 300 143 128 303 minecraft:packed_ice
setblock 143 128 304 minecraft:snow_block
fill 143 128 305 143 131 305 minecraft:packed_ice
setblock 143 128 309 minecraft:snow_block
fill 143 128 310 143 131 310 minecraft:packed_ice
setblock 143 128 314 minecraft:snow_block
setblock 144 128 278 minecraft:light[level=15]
setblock 144 128 286 minecraft:light[level=15]
setblock 144 128 294 minecraft:light[level=15]
fill 144 128 303 145 128 303 minecraft:snow_block
fill 144 128 304 144 131 304 minecraft:packed_ice
setblock 144 128 308 minecraft:snow_block
fill 144 128 309 144 131 309 minecraft:packed_ice
fill 145 128 305 145 131 305 minecraft:snow_block
fill 147 128 303 147 131 303 minecraft:snow_block
fill 147 128 305 147 131 305 minecraft:snow_block
fill 152 128 275 153 165 275 minecraft:blue_ice
setblock 152 128 277 minecraft:blue_ice
setblock 152 128 278 minecraft:light[level=15]
setblock 152 128 286 minecraft:light[level=15]
setblock 152 128 294 minecraft:light[level=15]
setblock 152 128 310 minecraft:light[level=15]
fill 159 128 276 160 128 276 minecraft:packed_ice
setblock 160 128 278 minecraft:light[level=15]
setblock 160 128 286 minecraft:light[level=15]
setblock 160 128 294 minecraft:light[level=15]
setblock 160 128 302 minecraft:light[level=15]
setblock 160 128 310 minecraft:light[level=15]
setblock 161 128 276 minecraft:snow_block
fill 161 128 277 161 131 277 minecraft:packed_ice
setblock 161 128 316 minecraft:snow_block
fill 162 128 276 165 128 276 minecraft:packed_ice
fill 162 128 316 164 129 316 minecraft:packed_ice
fill 163 128 275 163 133 275 minecraft:blue_ice
fill 163 128 277 164 128 277 minecraft:packed_ice
setblock 165 128 277 minecraft:snow_block
fill 165 128 284 165 129 285 minecraft:packed_ice
setblock 166 128 276 minecraft:snow_block
fill 166 128 283 167 129 283 minecraft:packed_ice
fill 167 128 276 167 131 276 minecraft:packed_ice
setblock 168 128 278 minecraft:light[level=15]
setblock 168 128 286 minecraft:light[level=15]
setblock 168 128 294 minecraft:light[level=15]
setblock 168 128 302 minecraft:light[level=15]
setblock 168 128 310 minecraft:light[level=15]
setblock 175 128 316 minecraft:packed_ice
setblock 176 128 276 minecraft:snow_block
setblock 176 128 278 minecraft:light[level=15]
setblock 176 128 286 minecraft:light[level=15]
setblock 176 128 294 minecraft:light[level=15]
setblock 176 128 302 minecraft:light[level=15]
setblock 176 128 310 minecraft:light[level=15]
setblock 176 128 316 minecraft:snow_block
fill 177 128 276 177 131 276 minecraft:packed_ice
setblock 177 128 315 minecraft:snow_block
fill 177 128 316 177 131 316 minecraft:packed_ice
fill 178 128 315 178 131 315 minecraft:packed_ice
fill 179 128 295 179 134 295 minecraft:packed_ice
fill 179 128 314 180 130 314 minecraft:packed_ice
fill 180 128 304 180 128 306 minecraft:packed_ice
setblock 180 128 307 minecraft:snow_block
fill 180 128 308 180 131 308 minecraft:packed_ice
setblock 180 128 311 minecraft:packed_ice
setblock 180 128 312 minecraft:snow_block
fill 180 128 313 180 131 313 minecraft:packed_ice
setblock 181 128 276 minecraft:snow_block
setblock 181 128 281 minecraft:snow_block
fill 181 128 282 181 131 282 minecraft:packed_ice
setblock 181 128 286 minecraft:snow_block
fill 181 128 287 181 131 287 minecraft:packed_ice
fill 181 128 289 181 129 289 minecraft:packed_ice
setblock 181 128 301 minecraft:snow_block
fill 181 128 302 181 131 302 minecraft:packed_ice
setblock 181 128 306 minecraft:snow_block
fill 181 128 307 181 131 307 minecraft:packed_ice
setblock 181 128 311 minecraft:snow_block
fill 181 128 312 181 131 312 minecraft:packed_ice
setblock 181 128 316 minecraft:snow_block
fill 182 128 276 182 131 276 minecraft:packed_ice
setblock 182 128 280 minecraft:snow_block
fill 182 128 281 182 131 281 minecraft:packed_ice
setblock 182 128 285 minecraft:snow_block
fill 182 128 286 182 131 286 minecraft:packed_ice
setblock 182 128 290 minecraft:snow_block
fill 182 128 291 182 128 294 minecraft:packed_ice
fill 182 128 297 182 129 298 minecraft:packed_ice
setblock 182 128 300 minecraft:snow_block
fill 182 128 301 182 131 301 minecraft:packed_ice
setblock 182 128 305 minecraft:snow_block
fill 182 128 306 182 131 306 minecraft:packed_ice
setblock 182 128 310 minecraft:snow_block
fill 182 128 311 182 131 311 minecraft:packed_ice
setblock 182 128 315 minecraft:snow_block
fill 182 128 316 182 131 316 minecraft:packed_ice
fill 183 128 278 183 165 278 minecraft:blue_ice
fill 183 128 287 183 165 287 minecraft:blue_ice
setblock 183 128 288 minecraft:white_concrete
fill 183 128 289 183 134 290 minecraft:blue_ice
setblock 142 129 279 minecraft:snow_block
fill 142 129 280 142 131 280 minecraft:packed_ice
setblock 142 129 284 minecraft:snow_block
fill 142 129 285 142 132 285 minecraft:packed_ice
setblock 142 129 288 minecraft:packed_ice
setblock 142 129 289 minecraft:snow_block
fill 142 129 290 142 129 293 minecraft:packed_ice
setblock 142 129 294 minecraft:snow_block
fill 142 129 295 142 129 298 minecraft:packed_ice
setblock 142 129 299 minecraft:snow_block
fill 142 129 300 142 129 303 minecraft:packed_ice
setblock 142 129 304 minecraft:snow_block
fill 142 129 305 142 132 305 minecraft:packed_ice
setblock 142 129 309 minecraft:snow_block
fill 142 129 310 142 132 310 minecraft:packed_ice
setblock 142 129 314 minecraft:snow_block
fill 142 129 315 143 131 315 minecraft:packed_ice
setblock 143 129 283 minecraft:snow_block
fill 143 129 284 143 132 284 minecraft:packed_ice
setblock 143 129 288 minecraft:snow_block
fill 143 129 289 144 131 289 minecraft:packed_ice
setblock 143 129 292 minecraft:packed_ice
setblock 143 129 293 minecraft:snow_block
fill 143 129 294 143 129 297 minecraft:packed_ice
setblock 143 129 298 minecraft:snow_block
fill 143 129 299 143 129 302 minecraft:packed_ice
setblock 143 129 303 minecraft:snow_block
fill 143 129 304 143 132 304 minecraft:packed_ice
setblock 143 129 308 minecraft:snow_block
fill 143 129 309 143 132 309 minecraft:packed_ice
setblock 143 129 313 minecraft:snow_block
fill 143 129 314 143 132 314 minecraft:packed_ice
setblock 144 129 287 minecraft:snow_block
fill 144 129 288 144 132 288 minecraft:packed_ice
fill 144 129 290 144 130 290 minecraft:packed_ice
setblock 144 129 302 minecraft:snow_block
fill 144 129 303 144 130 303 minecraft:packed_ice
setblock 144 129 307 minecraft:snow_block
fill 144 129 308 144 132 308 minecraft:packed_ice
setblock 144 129 312 minecraft:snow_block
fill 145 129 303 145 131 303 minecraft:snow_block
fill 158 129 276 159 129 276 minecraft:packed_ice
setblock 159 129 316 minecraft:packed_ice
setblock 160 129 276 minecraft:snow_block
fill 160 129 277 160 132 277 minecraft:packed_ice
setblock 160 129 316 minecraft:snow_block
fill 161 129 276 164 129 276 minecraft:packed_ice
fill 161 129 316 161 132 316 minecraft:packed_ice
setblock 163 129 277 minecraft:packed_ice
setblock 164 129 277 minecraft:snow_block
setblock 165 129 276 minecraft:snow_block
fill 165 129 277 165 131 277 minecraft:packed_ice
setblock 165 129 283 minecraft:packed_ice
setblock 165 129 316 minecraft:snow_block
fill 166 129 276 166 132 276 minecraft:packed_ice
fill 166 129 286 167 129 286 minecraft:packed_ice
fill 166 129 316 166 132 316 minecraft:packed_ice
fill 168 129 283 168 129 285 minecraft:packed_ice
fill 173 129 316 174 129 316 minecraft:packed_ice
setblock 175 129 276 minecraft:snow_block
setblock 175 129 316 minecraft:snow_block
fill 176 129 276 176 132 276 minecraft:packed_ice
setblock 176 129 315 minecraft:snow_block
fill 176 129 316 176 132 316 minecraft:packed_ice
fill 177 129 315 177 132 315 minecraft:packed_ice
fill 178 129 314 178 132 314 minecraft:packed_ice
setblock 179 129 307 minecraft:snow_block
fill 179 129 308 179 129 311 minecraft:packed_ice
setblock 179 129 312 minecraft:snow_block
setblock 180 129 276 minecraft:snow_block
fill 180 129 304 180 129 305 minecraft:packed_ice
setblock 180 129 306 minecraft:snow_block
fill 180 129 307 180 132 307 minecraft:packed_ice
setblock 180 129 311 minecraft:snow_block
fill 180 129 312 180 132 312 minecraft:packed_ice
setblock 180 129 316 minecraft:snow_block
fill 181 129 276 181 132 276 minecraft:packed_ice
setblock 181 129 280 minecraft:snow_block
fill 181 129 281 181 130 281 minecraft:packed_ice
setblock 181 129 285 minecraft:snow_block
fill 181 129 286 181 132 286 minecraft:packed_ice
setblock 181 129 290 minecraft:snow_block
fill 181 129 291 182 131 291 minecraft:packed_ice
fill 181 129 301 181 132 301 minecraft:packed_ice
setblock 181 129 305 minecraft:snow_block
fill 181 129 306 181 132 306 minecraft:packed_ice
setblock 181 129 310 minecraft:snow_block
fill 181 129 311 181 132 311 minecraft:packed_ice
setblock 181 129 314 minecraft:packed_ice
setblock 181 129 315 minecraft:snow_block
fill 181 129 316 181 132 316 minecraft:packed_ice
setblock 182 129 279 minecraft:snow_block
fill 182 129 280 182 132 280 minecraft:packed_ice
setblock 182 129 284 minecraft:snow_block
fill 182 129 285 182 132 285 minecraft:packed_ice
setblock 182 129 289 minecraft:snow_block
fill 182 129 290 182 132 290 minecraft:packed_ice
fill 182 129 292 182 129 293 minecraft:packed_ice
setblock 182 129 294 minecraft:snow_block
fill 182 129 295 182 131 296 minecraft:packed_ice
setblock 182 129 299 minecraft:snow_block
fill 182 129 300 182 132 300 minecraft:packed_ice
setblock 182 129 304 minecraft:snow_block
fill 182 129 305 182 132 305 minecraft:packed_ice
setblock 182 129 309 minecraft:snow_block
fill 182 129 310 182 132 310 minecraft:packed_ice
setblock 182 129 314 minecraft:snow_block
fill 182 129 315 182 132 315 minecraft:packed_ice
fill 183 129 288 183 161 288 minecraft:blue_ice
setblock 142 130 283 minecraft:snow_block
fill 142 130 284 142 133 284 minecraft:packed_ice
setblock 142 130 288 minecraft:snow_block
fill 142 130 289 142 130 292 minecraft:packed_ice
setblock 142 130 293 minecraft:snow_block
fill 142 130 294 142 130 297 minecraft:packed_ice
setblock 142 130 298 minecraft:snow_block
fill 142 130 299 142 130 302 minecraft:packed_ice
setblock 142 130 303 minecraft:snow_block
fill 142 130 304 142 133 304 minecraft:packed_ice
setblock 142 130 308 minecraft:snow_block
fill 142 130 309 142 133 309 minecraft:packed_ice
setblock 142 130 313 minecraft:snow_block
fill 142 130 314 142 133 314 minecraft:packed_ice
setblock 143 130 283 minecraft:packed_ice
setblock 143 130 287 minecraft:snow_block
fill 143 130 288 143 133 288 minecraft:packed_ice
setblock 143 130 292 minecraft:snow_block
fill 143 130 293 143 130 296 minecraft:packed_ice
setblock 143 130 297 minecraft:snow_block
fill 143 130 298 143 130 301 minecraft:packed_ice
setblock 143 130 302 minecraft:snow_block
fill 143 130 303 143 133 303 minecraft:packed_ice
setblock 143 130 307 minecraft:snow_block
fill 143 130 308 143 133 308 minecraft:packed_ice
setblock 143 130 311 minecraft:packed_ice
setblock 143 130 312 minecraft:snow_block
fill 143 130 313 143 133 313 minecraft:packed_ice
fill 144 130 284 144 131 284 minecraft:packed_ice
fill 144 130 286 144 131 287 minecraft:packed_ice
setblock 144 130 291 minecraft:snow_block
fill 144 130 292 144 133 292 minecraft:packed_ice
setblock 144 130 306 minecraft:snow_block
fill 144 130 307 144 132 307 minecraft:packed_ice
setblock 144 130 311 minecraft:snow_block
fill 144 130 312 144 132 312 minecraft:packed_ice
setblock 144 130 316 minecraft:snow_block
fill 145 130 285 145 131 285 minecraft:packed_ice
fill 145 130 316 145 133 316 minecraft:packed_ice
fill 157 130 276 158 130 276 minecraft:packed_ice
fill 157 130 316 158 130 316 minecraft:packed_ice
setblock 157 130 317 minecraft:light_blue_concrete
setblock 159 130 276 minecraft:snow_block
fill 159 130 277 159 133 277 minecraft:packed_ice
setblock 159 130 316 minecraft:snow_block
fill 160 130 276 163 130 276 minecraft:packed_ice
setblock 160 130 315 minecraft:snow_block
fill 160 130 316 160 133 316 minecraft:packed_ice
fill 161 130 315 163 131 315 minecraft:packed_ice
fill 162 130 316 163 130 316 minecraft:packed_ice
setblock 163 130 277 minecraft:snow_block
setblock 164 130 276 minecraft:snow_block
fill 164 130 277 164 133 277 minecraft:packed_ice
setblock 164 130 316 minecraft:snow_block
fill 165 130 276 165 133 276 minecraft:packed_ice
fill 165 130 279 165 131 279 minecraft:snow_block
fill 165 130 316 165 133 316 minecraft:packed_ice
fill 167 130 316 168 130 316 minecraft:packed_ice
setblock 169 130 276 minecraft:snow_block
setblock 169 130 316 minecraft:snow_block
fill 170 130 316 173 130 316 minecraft:packed_ice
setblock 173 130 276 minecraft:packed_ice
setblock 174 130 276 minecraft:snow_block
setblock 174 130 315 minecraft:packed_ice
setblock 174 130 316 minecraft:snow_block
fill 175 130 276 175 133 276 minecraft:packed_ice
fill 175 130 311 178 131 312 minecraft:snow_block
setblock 175 130 315 minecraft:snow_block
fill 175 130 316 175 133 316 minecraft:packed_ice
fill 176 130 310 177 200 310 minecraft:snow_block
fill 176 130 313 176 130 314 minecraft:snow_block
fill 176 130 315 176 133 315 minecraft:packed_ice
setblock 177 130 313 minecraft:snow_block
fill 177 130 314 177 133 314 minecraft:packed_ice
fill 178 130 313 179 132 313 minecraft:packed_ice
setblock 179 130 276 minecraft:snow_block
setblock 179 130 306 minecraft:snow_block
fill 179 130 307 179 130 310 minecraft:packed_ice
setblock 179 130 311 minecraft:snow_block
fill 179 130 312 179 133 312 minecraft:packed_ice
setblock 179 130 315 minecraft:packed_ice
setblock 179 130 316 minecraft:snow_block
fill 180 130 276 180 133 276 minecraft:packed_ice
fill 180 130 286 180 131 288 minecraft:packed_ice
fill 180 130 303 180 130 304 minecraft:packed_ice
setblock 180 130 305 minecraft:snow_block
fill 180 130 306 180 133 306 minecraft:packed_ice
setblock 180 130 310 minecraft:snow_block
fill 180 130 311 180 133 311 minecraft:packed_ice
setblock 180 130 315 minecraft:snow_block
fill 180 130 316 180 133 316 minecraft:packed_ice
setblock 181 130 284 minecraft:snow_block
fill 181 130 285 181 133 285 minecraft:packed_ice
setblock 181 130 289 minecraft:snow_block
fill 181 130 290 181 133 290 minecraft:packed_ice
fill 181 130 292 181 130 293 minecraft:packed_ice
fill 181 130 300 181 133 300 minecraft:packed_ice
setblock 181 130 304 minecraft:snow_block
fill 181 130 305 181 133 305 minecraft:packed_ice
setblock 181 130 309 minecraft:snow_block
fill 181 130 310 181 133 310 minecraft:packed_ice
setblock 181 130 314 minecraft:snow_block
fill 181 130 315 181 133 315 minecraft:packed_ice
setblock 182 130 278 minecraft:snow_block
fill 182 130 279 182 132 279 minecraft:packed_ice
setblock 182 130 283 minecraft:snow_block
fill 182 130 284 182 133 284 minecraft:packed_ice
setblock 182 130 288 minecraft:snow_block
fill 182 130 289 182 133 289 minecraft:packed_ice
setblock 182 130 292 minecraft:packed_ice
setblock 182 130 293 minecraft:snow_block
fill 182 130 294 182 133 294 minecraft:packed_ice
setblock 182 130 297 minecraft:packed_ice
setblock 182 130 298 minecraft:snow_block
fill 182 130 299 182 133 299 minecraft:packed_ice
setblock 182 130 303 minecraft:snow_block
fill 182 130 304 182 133 304 minecraft:packed_ice
setblock 182 130 308 minecraft:snow_block
fill 182 130 309 182 133 309 minecraft:packed_ice
setblock 182 130 313 minecraft:snow_block
fill 182 130 314 182 133 314 minecraft:packed_ice
fill 183 130 282 183 150 284 minecraft:blue_ice
setblock 183 130 285 minecraft:light_blue_concrete
setblock 141 131 302 minecraft:light_blue_concrete
setblock 142 131 282 minecraft:snow_block
fill 142 131 283 142 134 283 minecraft:packed_ice
setblock 142 131 287 minecraft:snow_block
fill 142 131 288 142 131 291 minecraft:packed_ice
setblock 142 131 292 minecraft:snow_block
fill 142 131 293 142 131 296 minecraft:packed_ice
setblock 142 131 297 minecraft:snow_block
fill 142 131 298 142 131 301 minecraft:packed_ice
setblock 142 131 302 minecraft:snow_block
fill 142 131 303 142 134 303 minecraft:packed_ice
setblock 142 131 307 minecraft:snow_block
fill 142 131 308 142 134 308 minecraft:packed_ice
setblock 142 131 312 minecraft:snow_block
fill 142 131 313 142 134 313 minecraft:packed_ice
setblock 143 131 286 minecraft:snow_block
fill 143 131 287 143 134 287 minecraft:packed_ice
setblock 143 131 291 minecraft:snow_block
fill 143 131 292 143 131 295 minecraft:packed_ice
setblock 143 131 296 minecraft:snow_block
fill 143 131 297 143 131 300 minecraft:packed_ice
setblock 143 131 301 minecraft:snow_block
fill 143 131 302 143 133 302 minecraft:packed_ice
setblock 143 131 306 minecraft:snow_block
fill 143 131 307 143 134 307 minecraft:packed_ice
setblock 143 131 311 minecraft:snow_block
fill 143 131 312 143 134 312 minecraft:packed_ice
setblock 143 131 316 minecraft:snow_block
setblock 144 131 290 minecraft:snow_block
fill 144 131 291 144 134 291 minecraft:packed_ice
fill 144 131 293 144 132 293 minecraft:packed_ice
setblock 144 131 305 minecraft:snow_block
fill 144 131 306 144 132 306 minecraft:packed_ice
setblock 144 131 310 minecraft:snow_block
fill 144 131 311 144 133 311 minecraft:packed_ice
setblock 144 131 315 minecraft:snow_block
fill 144 131 316 144 134 316 minecraft:packed_ice
setblock 146 131 302 minecraft:snow_block
setblock 146 131 306 minecraft:snow_block
setblock 148 131 304 minecraft:snow_block
fill 156 131 276 157 131 276 minecraft:packed_ice
fill 156 131 316 157 131 316 minecraft:packed_ice
fill 157 131 280 157 141 280 minecraft:packed_ice
fill 157 131 317 157 165 317 minecraft:blue_ice
setblock 158 131 276 minecraft:snow_block
fill 158 131 277 158 134 277 minecraft:packed_ice
setblock 158 131 315 minecraft:packed_ice
setblock 158 131 316 minecraft:snow_block
fill 159 131 276 162 131 276 minecraft:packed_ice
setblock 159 131 315 minecraft:snow_block
fill 159 131 316 159 134 316 minecraft:packed_ice
fill 160 131 315 160 134 315 minecraft:packed_ice
setblock 162 131 277 minecraft:snow_block
setblock 162 131 316 minecraft:packed_ice
setblock 163 131 276 minecraft:snow_block
fill 163 131 277 163 134 277 minecraft:packed_ice
setblock 163 131 316 minecraft:snow_block
fill 164 131 276 164 134 276 minecraft:packed_ice
setblock 164 131 315 minecraft:snow_block
fill 164 131 316 164 134 316 minecraft:packed_ice
fill 165 131 315 165 134 315 minecraft:packed_ice
setblock 167 131 316 minecraft:packed_ice
setblock 168 131 276 minecraft:snow_block
setblock 168 131 316 minecraft:snow_block
fill 169 131 276 172 131 276 minecraft:packed_ice
fill 169 131 316 172 131 316 minecraft:packed_ice
fill 172 131 315 173 131 315 minecraft:packed_ice
setblock 173 131 276 minecraft:snow_block
setblock 173 131 316 minecraft:snow_block
fill 174 131 276 174 134 276 minecraft:packed_ice
fill 174 131 311 174 132 312 minecraft:packed_ice
setblock 174 131 314 minecraft:packed_ice
setblock 174 131 315 minecraft:snow_block
fill 174 131 316 174 134 316 minecraft:packed_ice
fill 175 131 310 175 132 310 minecraft:packed_ice
setblock 175 131 313 minecraft:packed_ice
setblock 175 131 314 minecraft:snow_block
fill 175 131 315 175 134 315 minecraft:packed_ice
fill 176 131 309 176 132 309 minecraft:packed_ice
setblock 176 131 313 minecraft:snow_block
fill 176 131 314 176 134 314 minecraft:packed_ice
fill 177 131 313 177 134 313 minecraft:packed_ice
setblock 178 131 276 minecraft:snow_block
fill 178 131 277 180 132 277 minecraft:packed_ice
fill 178 131 301 178 132 301 minecraft:packed_ice
setblock 178 131 310 minecraft:packed_ice
setblock 178 131 316 minecraft:snow_block
fill 179 131 276 179 134 276 minecraft:packed_ice
fill 179 131 300 179 132 300 minecraft:packed_ice
fill 179 131 302 179 132 302 minecraft:packed_ice
fill 179 131 306 179 131 309 minecraft:packed_ice
setblock 179 131 310 minecraft:snow_block
fill 179 131 311 179 134 311 minecraft:packed_ice
setblock 179 131 314 minecraft:packed_ice
setblock 179 131 315 minecraft:snow_block
fill 179 131 316 179 134 316 minecraft:packed_ice
setblock 180 131 289 minecraft:snow_block
fill 180 131 290 180 134 290 minecraft:packed_ice
fill 180 131 301 180 132 301 minecraft:packed_ice
setblock 180 131 303 minecraft:packed_ice
setblock 180 131 304 minecraft:snow_block
fill 180 131 305 180 134 305 minecraft:packed_ice
setblock 180 131 309 minecraft:snow_block
fill 180 131 310 180 134 310 minecraft:packed_ice
setblock 180 131 314 minecraft:snow_block
fill 180 131 315 180 134 315 minecraft:packed_ice
setblock 181 131 283 minecraft:snow_block
fill 181 131 284 181 132 284 minecraft:packed_ice
setblock 181 131 288 minecraft:snow_block
fill 181 131 289 181 134 289 minecraft:packed_ice
setblock 181 131 292 minecraft:packed_ice
setblock 181 131 293 minecraft:snow_block
fill 181 131 294 181 133 295 minecraft:packed_ice
setblock 181 131 303 minecraft:snow_block
fill 181 131 304 181 134 304 minecraft:packed_ice
setblock 181 131 308 minecraft:snow_block
fill 181 131 309 181 134 309 minecraft:packed_ice
setblock 181 131 313 minecraft:snow_block
fill 181 131 314 181 134 314 minecraft:packed_ice
setblock 182 131 277 minecraft:snow_block
fill 182 131 278 182 133 278 minecraft:packed_ice
setblock 182 131 282 minecraft:snow_block
fill 182 131 283 182 133 283 minecraft:packed_ice
setblock 182 131 287 minecraft:snow_block
fill 182 131 288 182 134 288 minecraft:packed_ice
setblock 182 131 292 minecraft:snow_block
fill 182 131 293 182 134 293 minecraft:packed_ice
setblock 182 131 297 minecraft:snow_block
fill 182 131 298 182 134 298 minecraft:packed_ice
setblock 182 131 302 minecraft:snow_block
fill 182 131 303 182 134 303 minecraft:packed_ice
setblock 182 131 307 minecraft:snow_block
fill 182 131 308 182 134 308 minecraft:packed_ice
setblock 182 131 312 minecraft:snow_block
fill 182 131 313 182 134 313 minecraft:packed_ice
fill 183 131 285 183 165 285 minecraft:blue_ice
setblock 141 132 289 minecraft:light_blue_concrete
fill 141 132 302 141 165 302 minecraft:blue_ice
setblock 142 132 281 minecraft:snow_block
fill 142 132 282 142 133 282 minecraft:packed_ice
setblock 142 132 286 minecraft:snow_block
fill 142 132 287 142 132 290 minecraft:packed_ice
setblock 142 132 291 minecraft:snow_block
fill 142 132 292 142 132 295 minecraft:packed_ice
setblock 142 132 296 minecraft:snow_block
fill 142 132 297 142 132 300 minecraft:packed_ice
setblock 142 132 301 minecraft:snow_block
fill 142 132 302 142 135 302 minecraft:packed_ice
setblock 142 132 306 minecraft:snow_block
fill 142 132 307 142 135 307 minecraft:packed_ice
setblock 142 132 311 minecraft:snow_block
fill 142 132 312 142 135 312 minecraft:packed_ice
setblock 142 132 315 minecraft:packed_ice
setblock 142 132 316 minecraft:snow_block
setblock 143 132 285 minecraft:snow_block
fill 143 132 286 143 134 286 minecraft:packed_ice
setblock 143 132 289 minecraft:packed_ice
setblock 143 132 290 minecraft:snow_block
fill 143 132 291 143 132 294 minecraft:packed_ice
setblock 143 132 295 minecraft:snow_block
fill 143 132 296 143 132 299 minecraft:packed_ice
setblock 143 132 300 minecraft:snow_block
fill 143 132 301 143 133 301 minecraft:packed_ice
setblock 143 132 305 minecraft:snow_block
fill 143 132 306 143 134 306 minecraft:packed_ice
setblock 143 132 310 minecraft:snow_block
fill 143 132 311 143 135 311 minecraft:packed_ice
setblock 143 132 315 minecraft:snow_block
fill 143 132 316 143 135 316 minecraft:packed_ice
setblock 144 132 278 minecraft:light[level=12]
setblock 144 132 285 minecraft:light[level=12]
setblock 144 132 287 minecraft:packed_ice
setblock 144 132 289 minecraft:snow_block
fill 144 132 290 144 134 290 minecraft:packed_ice
setblock 144 132 294 minecraft:snow_block
setblock 144 132 299 minecraft:light[level=12]
setblock 144 132 305 minecraft:packed_ice
setblock 144 132 309 minecraft:snow_block
fill 144 132 310 144 133 310 minecraft:packed_ice
setblock 144 132 313 minecraft:light[level=12]
setblock 144 132 315 minecraft:packed_ice
fill 147 132 279 147 134 279 minecraft:snow_block
fill 148 132 278 148 134 278 minecraft:snow_block
fill 148 132 280 148 134 280 minecraft:snow_block
fill 149 132 279 149 134 279 minecraft:snow_block
setblock 151 132 278 minecraft:light[level=12]
setblock 151 132 285 minecraft:light[level=12]
setblock 151 132 292 minecraft:light[level=12]
setblock 151 132 299 minecraft:light[level=12]
setblock 151 132 306 minecraft:light[level=12]
setblock 151 132 313 minecraft:light[level=12]
fill 155 132 276 156 132 276 minecraft:packed_ice
fill 155 132 316 156 132 316 minecraft:packed_ice
setblock 157 132 276 minecraft:snow_block
fill 157 132 277 157 135 277 minecraft:packed_ice
setblock 157 132 315 minecraft:packed_ice
setblock 157 132 316 minecraft:snow_block
fill 158 132 276 161 132 276 minecraft:packed_ice
setblock 158 132 278 minecraft:light[level=12]
setblock 158 132 285 minecraft:light[level=12]
setblock 158 132 292 minecraft:light[level=12]
setblock 158 132 299 minecraft:light[level=12]
setblock 158 132 306 minecraft:light[level=12]
setblock 158 132 313 minecraft:light[level=12]
setblock 158 132 315 minecraft:snow_block
fill 158 132 316 158 135 316 minecraft:packed_ice
fill 159 132 315 159 135 315 minecraft:packed_ice
fill 160 132 314 161 134 314 minecraft:packed_ice
setblock 161 132 277 minecraft:snow_block
fill 161 132 315 162 132 315 minecraft:packed_ice
setblock 162 132 276 minecraft:snow_block
fill 162 132 277 162 135 277 minecraft:packed_ice
setblock 162 132 316 minecraft:snow_block
fill 163 132 276 163 135 276 minecraft:packed_ice
setblock 163 132 315 minecraft:snow_block
fill 163 132 316 163 135 316 minecraft:packed_ice
fill 164 132 315 164 135 315 minecraft:packed_ice
setblock 165 132 278 minecraft:light[level=12]
setblock 165 132 285 minecraft:light[level=12]
setblock 165 132 292 minecraft:light[level=12]
setblock 165 132 299 minecraft:light[level=12]
setblock 165 132 306 minecraft:light[level=12]
setblock 165 132 313 minecraft:light[level=12]
fill 166 132 315 166 133 315 minecraft:packed_ice
setblock 167 132 276 minecraft:snow_block
setblock 167 132 316 minecraft:snow_block
fill 168 132 276 171 132 276 minecraft:packed_ice
fill 168 132 316 171 132 316 minecraft:packed_ice
fill 170 132 315 172 132 315 minecraft:packed_ice
setblock 172 132 276 minecraft:snow_block
setblock 172 132 278 minecraft:light[level=12]
setblock 172 132 285 minecraft:light[level=12]
setblock 172 132 292 minecraft:light[level=12]
setblock 172 132 299 minecraft:light[level=12]
setblock 172 132 306 minecraft:light[level=12]
setblock 172 132 313 minecraft:light[level=12]
setblock 172 132 316 minecraft:snow_block
fill 173 132 276 173 135 276 minecraft:packed_ice
setblock 173 132 314 minecraft:packed_ice
setblock 173 132 315 minecraft:snow_block
fill 173 132 316 173 135 316 minecraft:packed_ice
setblock 174 132 310 minecraft:packed_ice
setblock 174 132 313 minecraft:packed_ice
setblock 174 132 314 minecraft:snow_block
fill 174 132 315 174 135 315 minecraft:packed_ice
setblock 175 132 309 minecraft:packed_ice
fill 175 132 311 175 132 313 minecraft:snow_block
fill 175 132 314 175 135 314 minecraft:packed_ice
setblock 176 132 275 minecraft:white_concrete
fill 176 132 311 177 132 312 minecraft:snow_block
fill 176 132 313 176 135 313 minecraft:packed_ice
setblock 177 132 276 minecraft:snow_block
fill 177 132 277 177 135 277 minecraft:packed_ice
fill 177 132 309 178 132 309 minecraft:packed_ice
setblock 177 132 316 minecraft:snow_block
fill 178 132 276 178 135 276 minecraft:packed_ice
setblock 178 132 310 minecraft:snow_block
fill 178 132 311 178 134 312 minecraft:packed_ice
setblock 178 132 315 minecraft:snow_block
fill 178 132 316 178 135 316 minecraft:packed_ice
setblock 179 132 278 minecraft:light[level=12]
setblock 179 132 285 minecraft:light[level=12]
setblock 179 132 292 minecraft:light[level=12]
setblock 179 132 299 minecraft:light[level=12]
fill 179 132 306 179 132 308 minecraft:packed_ice
setblock 179 132 309 minecraft:snow_block
fill 179 132 310 179 135 310 minecraft:packed_ice
setblock 179 132 314 minecraft:snow_block
fill 179 132 315 179 135 315 minecraft:packed_ice
setblock 180 132 287 minecraft:packed_ice
setblock 180 132 288 minecraft:snow_block
fill 180 132 289 180 133 289 minecraft:packed_ice
fill 180 132 291 181 132 291 minecraft:packed_ice
setblock 180 132 303 minecraft:snow_block
fill 180 132 304 180 133 304 minecraft:packed_ice
setblock 180 132 308 minecraft:snow_block
fill 180 132 309 180 135 309 minecraft:packed_ice
setblock 180 132 313 minecraft:snow_block
fill 180 132 314 180 135 314 minecraft:packed_ice
setblock 181 132 283 minecraft:packed_ice
setblock 181 132 287 minecraft:snow_block
fill 181 132 288 181 135 288 minecraft:packed_ice
setblock 181 132 292 minecraft:snow_block
fill 181 132 293 181 135 293 minecraft:packed_ice
setblock 181 132 296 minecraft:packed_ice
setblock 181 132 297 minecraft:snow_block
fill 181 132 298 181 134 299 minecraft:packed_ice
setblock 181 132 302 minecraft:snow_block
fill 181 132 303 181 135 303 minecraft:packed_ice
setblock 181 132 307 minecraft:snow_block
fill 181 132 308 181 135 308 minecraft:packed_ice
setblock 181 132 312 minecraft:snow_block
fill 181 132 313 181 135 313 minecraft:packed_ice
setblock 182 132 276 minecraft:snow_block
fill 182 132 277 182 134 277 minecraft:packed_ice
setblock 182 132 281 minecraft:snow_block
fill 182 132 282 182 133 282 minecraft:packed_ice
setblock 182 132 286 minecraft:snow_block
fill 182 132 287 182 135 287 minecraft:packed_ice
setblock 182 132 291 minecraft:snow_block
fill 182 132 292 182 135 292 minecraft:packed_ice
setblock 182 132 295 minecraft:packed_ice
setblock 182 132 296 minecraft:snow_block
fill 182 132 297 182 135 297 minecraft:packed_ice
setblock 182 132 301 minecraft:snow_block
fill 182 132 302 182 135 302 minecraft:packed_ice
setblock 182 132 306 minecraft:snow_block
fill 182 132 307 182 135 307 minecraft:packed_ice
setblock 182 132 311 minecraft:snow_block
fill 182 132 312 182 135 312 minecraft:packed_ice
setblock 182 132 316 minecraft:snow_block
setblock 141 133 289 minecraft:blue_ice
setblock 142 133 285 minecraft:snow_block
fill 142 133 286 142 133 289 minecraft:packed_ice
setblock 142 133 290 minecraft:snow_block
fill 142 133 291 142 133 294 minecraft:packed_ice
setblock 142 133 295 minecraft:snow_block
fill 142 133 296 142 133 299 minecraft:packed_ice
setblock 142 133 300 minecraft:snow_block
fill 142 133 301 142 136 301 minecraft:packed_ice
setblock 142 133 305 minecraft:snow_block
fill 142 133 306 142 136 306 minecraft:packed_ice
setblock 142 133 310 minecraft:snow_block
fill 142 133 311 142 136 311 minecraft:packed_ice
setblock 142 133 315 minecraft:snow_block
fill 142 133 316 142 136 316 minecraft:packed_ice
setblock 143 133 285 minecraft:packed_ice
setblock 143 133 289 minecraft:snow_block
fill 143 133 290 143 133 293 minecraft:packed_ice
setblock 143 133 294 minecraft:snow_block
fill 143 133 295 143 133 298 minecraft:packed_ice
setblock 143 133 299 minecraft:snow_block
fill 143 133 300 143 134 300 minecraft:packed_ice
setblock 143 133 304 minecraft:snow_block
fill 143 133 305 143 134 305 minecraft:packed_ice
setblock 143 133 309 minecraft:snow_block
fill 143 133 310 143 135 310 minecraft:packed_ice
setblock 143 133 314 minecraft:snow_block
fill 143 133 315 143 134 315 minecraft:packed_ice
setblock 144 133 288 minecraft:snow_block
fill 144 133 289 144 134 289 minecraft:packed_ice
setblock 144 133 293 minecraft:snow_block
fill 144 133 294 144 134 294 minecraft:packed_ice
setblock 144 133 308 minecraft:snow_block
setblock 144 133 309 minecraft:packed_ice
fill 154 133 276 155 133 276 minecraft:packed_ice
fill 154 133 316 155 133 316 minecraft:packed_ice
setblock 156 133 276 minecraft:snow_block
fill 156 133 277 156 136 277 minecraft:packed_ice
setblock 156 133 315 minecraft:packed_ice
setblock 156 133 316 minecraft:snow_block
fill 157 133 276 160 133 276 minecraft:packed_ice
setblock 157 133 315 minecraft:snow_block
fill 157 133 316 157 136 316 minecraft:packed_ice
setblock 158 133 314 minecraft:snow_block
fill 158 133 315 158 136 315 minecraft:packed_ice
fill 159 133 314 159 135 314 minecraft:packed_ice
setblock 160 133 277 minecraft:snow_block
setblock 161 133 276 minecraft:snow_block
fill 161 133 277 161 136 277 minecraft:packed_ice
fill 161 133 279 162 134 279 minecraft:snow_block
setblock 161 133 315 minecraft:packed_ice
setblock 161 133 316 minecraft:snow_block
fill 162 133 276 162 136 276 minecraft:packed_ice
setblock 162 133 314 minecraft:packed_ice
setblock 162 133 315 minecraft:snow_block
fill 162 133 316 162 136 316 minecraft:packed_ice
fill 163 133 315 163 136 315 minecraft:packed_ice
setblock 166 133 276 minecraft:snow_block
setblock 166 133 316 minecraft:snow_block
fill 167 133 276 170 133 276 minecraft:packed_ice
setblock 167 133 315 minecraft:snow_block
fill 167 133 316 170 133 316 minecraft:packed_ice
fill 168 133 315 171 133 315 minecraft:packed_ice
setblock 171 133 276 minecraft:snow_block
setblock 171 133 316 minecraft:snow_block
fill 172 133 276 172 136 276 minecraft:packed_ice
setblock 172 133 314 minecraft:packed_ice
setblock 172 133 315 minecraft:snow_block
fill 172 133 316 172 136 316 minecraft:packed_ice
setblock 173 133 314 minecraft:snow_block
fill 173 133 315 173 136 315 minecraft:packed_ice
fill 174 133 314 174 136 314 minecraft:packed_ice
fill 175 133 311 176 200 312 minecraft:snow_block
fill 175 133 313 175 136 313 minecraft:packed_ice
fill 176 133 275 176 163 275 minecraft:blue_ice
setblock 176 133 276 minecraft:snow_block
fill 176 133 277 176 136 277 minecraft:packed_ice
setblock 176 133 316 minecraft:snow_block
fill 177 133 276 177 136 276 minecraft:packed_ice
fill 177 133 311 177 200 311 minecraft:snow_block
fill 177 133 312 177 134 312 minecraft:packed_ice
setblock 177 133 315 minecraft:snow_block
fill 177 133 316 177 136 316 minecraft:packed_ice
fill 178 133 277 179 133 277 minecraft:packed_ice
fill 178 133 295 178 134 295 minecraft:packed_ice
setblock 178 133 310 minecraft:packed_ice
setblock 178 133 313 minecraft:packed_ice
setblock 178 133 314 minecraft:snow_block
fill 178 133 315 178 136 315 minecraft:packed_ice
fill 179 133 294 179 134 294 minecraft:packed_ice
fill 179 133 296 179 134 296 minecraft:packed_ice
setblock 179 133 307 minecraft:packed_ice
setblock 179 133 308 minecraft:snow_block
fill 179 133 309 179 135 309 minecraft:packed_ice
setblock 179 133 313 minecraft:snow_block
fill 179 133 314 179 136 314 minecraft:packed_ice
setblock 180 133 288 minecraft:packed_ice
setblock 180 133 291 minecraft:packed_ice
setblock 180 133 292 minecraft:snow_block
fill 180 133 295 180 134 295 minecraft:packed_ice
setblock 180 133 307 minecraft:snow_block
fill 180 133 308 180 136 308 minecraft:packed_ice
setblock 180 133 312 minecraft:snow_block
fill 180 133 313 180 136 313 minecraft:packed_ice
setblock 181 133 276 minecraft:snow_block
setblock 181 133 286 minecraft:snow_block
fill 181 133 287 181 134 287 minecraft:packed_ice
setblock 181 133 291 minecraft:snow_block
fill 181 133 292 181 136 292 minecraft:packed_ice
setblock 181 133 296 minecraft:snow_block
fill 181 133 297 181 136 297 minecraft:packed_ice
setblock 181 133 301 minecraft:snow_block
fill 181 133 302 181 134 302 minecraft:packed_ice
setblock 181 133 306 minecraft:snow_block
fill 181 133 307 181 136 307 minecraft:packed_ice
setblock 181 133 311 minecraft:snow_block
fill 181 133 312 181 136 312 minecraft:packed_ice
setblock 181 133 316 minecraft:snow_block
fill 182 133 276 182 135 276 minecraft:packed_ice
setblock 182 133 285 minecraft:snow_block
fill 182 133 286 182 135 286 minecraft:packed_ice
setblock 182 133 290 minecraft:snow_block
fill 182 133 291 182 136 291 minecraft:packed_ice
setblock 182 133 295 minecraft:snow_block
fill 182 133 296 182 136 296 minecraft:packed_ice
setblock 182 133 300 minecraft:snow_block
fill 182 133 301 182 136 301 minecraft:packed_ice
setblock 182 133 305 minecraft:snow_block
fill 182 133 306 182 136 306 minecraft:packed_ice
setblock 182 133 310 minecraft:snow_block
fill 182 133 311 182 136 311 minecraft:packed_ice
setblock 182 133 315 minecraft:snow_block
fill 182 133 316 182 136 316 minecraft:packed_ice
setblock 141 134 289 minecraft:light_blue_concrete
setblock 142 134 284 minecraft:snow_block
fill 142 134 285 142 134 288 minecraft:packed_ice
setblock 142 134 289 minecraft:snow_block
fill 142 134 290 142 134 293 minecraft:packed_ice
setblock 142 134 294 minecraft:snow_block
fill 142 134 295 142 134 298 minecraft:packed_ice
setblock 142 134 299 minecraft:snow_block
fill 142 134 300 142 137 300 minecraft:packed_ice
setblock 142 134 304 minecraft:snow_block
fill 142 134 305 142 136 305 minecraft:packed_ice
setblock 142 134 309 minecraft:snow_block
fill 142 134 310 142 137 310 minecraft:packed_ice
setblock 142 134 314 minecraft:snow_block
fill 142 134 315 142 137 315 minecraft:packed_ice
setblock 143 134 288 minecraft:snow_block
fill 143 134 289 143 134 292 minecraft:packed_ice
setblock 143 134 293 minecraft:snow_block
fill 143 134 294 143 134 297 minecraft:packed_ice
setblock 143 134 298 minecraft:snow_block
setblock 143 134 299 minecraft:packed_ice
setblock 143 134 303 minecraft:snow_block
setblock 143 134 304 minecraft:packed_ice
setblock 143 134 308 minecraft:snow_block
fill 143 134 309 143 135 309 minecraft:packed_ice
setblock 143 134 313 minecraft:snow_block
fill 143 134 314 143 135 314 minecraft:packed_ice
setblock 144 134 292 minecraft:snow_block
fill 144 134 293 144 135 293 minecraft:packed_ice
fill 153 134 276 154 134 276 minecraft:packed_ice
fill 153 134 316 154 134 316 minecraft:packed_ice
setblock 155 134 276 minecraft:snow_block
setblock 155 134 315 minecraft:packed_ice
setblock 155 134 316 minecraft:snow_block
fill 156 134 276 159 134 276 minecraft:packed_ice
setblock 156 134 315 minecraft:snow_block
fill 156 134 316 156 137 316 minecraft:packed_ice
fill 157 134 315 157 137 315 minecraft:packed_ice
fill 158 134 314 158 135 314 minecraft:packed_ice
setblock 159 134 277 minecraft:snow_block
setblock 160 134 276 minecraft:snow_block
fill 160 134 277 160 137 277 minecraft:packed_ice
setblock 160 134 316 minecraft:snow_block
fill 161 134 276 161 137 276 minecraft:packed_ice
setblock 161 134 315 minecraft:snow_block
fill 161 134 316 161 137 316 minecraft:packed_ice
fill 162 134 315 162 137 315 minecraft:packed_ice
setblock 163 134 275 minecraft:light_blue_concrete
setblock 165 134 276 minecraft:snow_block
setblock 165 134 316 minecraft:snow_block
fill 166 134 276 169 134 276 minecraft:packed_ice
fill 166 134 289 168 135 289 minecraft:snow_block
setblock 166 134 315 minecraft:snow_block
fill 166 134 316 169 134 316 minecraft:packed_ice
fill 167 134 288 167 135 288 minecraft:snow_block
fill 167 134 290 167 135 290 minecraft:snow_block
fill 167 134 315 170 134 315 minecraft:packed_ice
setblock 170 134 276 minecraft:snow_block
setblock 170 134 316 minecraft:snow_block
fill 171 134 276 171 137 276 minecraft:packed_ice
setblock 171 134 315 minecraft:snow_block
fill 171 134 316 171 137 316 minecraft:packed_ice
setblock 172 134 314 minecraft:snow_block
fill 172 134 315 172 137 315 minecraft:packed_ice
fill 173 134 314 173 137 314 minecraft:packed_ice
fill 174 134 313 174 137 313 minecraft:packed_ice
setblock 175 134 276 minecraft:snow_block
setblock 175 134 316 minecraft:snow_block
fill 176 134 276 176 137 276 minecraft:packed_ice
setblock 176 134 315 minecraft:snow_block
fill 176 134 316 176 137 316 minecraft:packed_ice
setblock 177 134 314 minecraft:snow_block
fill 177 134 315 177 137 315 minecraft:packed_ice
setblock 178 134 277 minecraft:packed_ice
setblock 178 134 313 minecraft:snow_block
fill 178 134 314 178 137 314 minecraft:packed_ice
setblock 179 134 307 minecraft:snow_block
fill 179 134 308 179 135 308 minecraft:packed_ice
setblock 179 134 312 minecraft:snow_block
fill 179 134 313 179 137 313 minecraft:packed_ice
setblock 180 134 276 minecraft:snow_block
setblock 180 134 291 minecraft:snow_block
setblock 180 134 292 minecraft:packed_ice
setblock 180 134 306 minecraft:snow_block
fill 180 134 307 180 136 307 minecraft:packed_ice
setblock 180 134 311 minecraft:snow_block
fill 180 134 312 180 137 312 minecraft:packed_ice
setblock 180 134 316 minecraft:snow_block
fill 181 134 276 181 137 276 minecraft:packed_ice
setblock 181 134 290 minecraft:snow_block
fill 181 134 291 181 136 291 minecraft:packed_ice
setblock 181 134 294 minecraft:packed_ice
setblock 181 134 295 minecraft:snow_block
fill 181 134 296 181 137 296 minecraft:packed_ice
setblock 181 134 300 minecraft:snow_block
setblock 181 134 301 minecraft:packed_ice
setblock 181 134 305 minecraft:snow_block
fill 181 134 306 181 136 306 minecraft:packed_ice
setblock 181 134 310 minecraft:snow_block
fill 181 134 311 181 137 311 minecraft:packed_ice
setblock 181 134 315 minecraft:snow_block
fill 181 134 316 181 137 316 minecraft:packed_ice
setblock 182 134 284 minecraft:snow_block
setblock 182 134 285 minecraft:packed_ice
setblock 182 134 289 minecraft:snow_block
fill 182 134 290 182 137 290 minecraft:packed_ice
setblock 182 134 294 minecraft:snow_block
fill 182 134 295 182 137 295 minecraft:packed_ice
setblock 182 134 299 minecraft:snow_block
fill 182 134 300 182 137 300 minecraft:packed_ice
setblock 182 134 304 minecraft:snow_block
fill 182 134 305 182 137 305 minecraft:packed_ice
setblock 182 134 309 minecraft:snow_block
fill 182 134 310 182 137 310 minecraft:packed_ice
setblock 182 134 314 minecraft:snow_block
fill 182 134 315 182 137 315 minecraft:packed_ice
setblock 141 135 288 minecraft:light_blue_concrete
fill 141 135 289 141 165 289 minecraft:blue_ice
fill 142 135 285 142 135 287 minecraft:packed_ice
setblock 142 135 288 minecraft:snow_block
fill 142 135 289 142 135 292 minecraft:packed_ice
setblock 142 135 293 minecraft:snow_block
fill 142 135 294 142 135 297 minecraft:packed_ice
setblock 142 135 298 minecraft:snow_block
fill 142 135 299 142 138 299 minecraft:packed_ice
setblock 142 135 303 minecraft:snow_block
fill 142 135 304 142 136 304 minecraft:packed_ice
setblock 142 135 308 minecraft:snow_block
fill 142 135 309 142 137 309 minecraft:packed_ice
setblock 142 135 313 minecraft:snow_block
fill 142 135 314 142 138 314 minecraft:packed_ice
setblock 143 135 287 minecraft:snow_block
fill 143 135 288 143 135 291 minecraft:packed_ice
setblock 143 135 292 minecraft:snow_block
fill 143 135 293 143 135 296 minecraft:packed_ice
setblock 143 135 297 minecraft:snow_block
setblock 143 135 298 minecraft:packed_ice
setblock 143 135 307 minecraft:snow_block
setblock 143 135 308 minecraft:packed_ice
setblock 143 135 312 minecraft:snow_block
setblock 143 135 313 minecraft:packed_ice
setblock 144 135 291 minecraft:snow_block
setblock 144 135 292 minecraft:packed_ice
setblock 144 135 316 minecraft:snow_block
fill 152 135 316 153 135 316 minecraft:packed_ice
setblock 153 135 276 minecraft:packed_ice
setblock 154 135 276 minecraft:snow_block
setblock 154 135 315 minecraft:packed_ice
setblock 154 135 316 minecraft:snow_block
fill 155 135 276 155 137 277 minecraft:packed_ice
setblock 155 135 315 minecraft:snow_block
fill 155 135 316 155 138 316 minecraft:packed_ice
fill 156 135 276 158 135 276 minecraft:packed_ice
fill 156 135 315 156 138 315 minecraft:packed_ice
setblock 158 135 277 minecraft:snow_block
setblock 159 135 276 minecraft:snow_block
fill 159 135 277 159 138 277 minecraft:packed_ice
setblock 159 135 316 minecraft:snow_block
fill 160 135 276 160 138 276 minecraft:packed_ice
setblock 160 135 314 minecraft:packed_ice
setblock 160 135 315 minecraft:snow_block
fill 160 135 316 160 138 316 minecraft:packed_ice
fill 161 135 315 161 138 315 minecraft:packed_ice
fill 163 135 275 163 165 275 minecraft:blue_ice
setblock 163 135 277 minecraft:snow_block
setblock 164 135 276 minecraft:snow_block
setblock 164 135 316 minecraft:snow_block
fill 165 135 276 168 135 276 minecraft:packed_ice
setblock 165 135 315 minecraft:snow_block
fill 165 135 316 168 135 316 minecraft:packed_ice
fill 166 135 315 169 135 315 minecraft:packed_ice
setblock 169 135 276 minecraft:snow_block
setblock 169 135 316 minecraft:snow_block
fill 170 135 276 170 138 276 minecraft:packed_ice
setblock 170 135 315 minecraft:snow_block
fill 170 135 316 170 138 316 minecraft:packed_ice
setblock 171 135 314 minecraft:snow_block
fill 171 135 315 171 138 315 minecraft:packed_ice
fill 172 135 314 172 138 314 minecraft:packed_ice
setblock 174 135 276 minecraft:snow_block
setblock 174 135 316 minecraft:snow_block
fill 175 135 276 175 138 276 minecraft:packed_ice
setblock 175 135 315 minecraft:snow_block
fill 175 135 316 175 138 316 minecraft:packed_ice
setblock 176 135 314 minecraft:snow_block
fill 176 135 315 176 138 315 minecraft:packed_ice
fill 177 135 312 177 135 313 minecraft:snow_block
fill 177 135 314 177 138 314 minecraft:packed_ice
fill 178 135 311 178 200 312 minecraft:snow_block
fill 178 135 313 178 138 313 minecraft:packed_ice
setblock 179 135 276 minecraft:snow_block
setblock 179 135 311 minecraft:snow_block
fill 179 135 312 179 137 312 minecraft:packed_ice
setblock 179 135 316 minecraft:snow_block
fill 180 135 276 180 138 276 minecraft:packed_ice
setblock 180 135 306 minecraft:packed_ice
setblock 180 135 310 minecraft:snow_block
fill 180 135 311 180 138 311 minecraft:packed_ice
setblock 180 135 315 minecraft:snow_block
fill 180 135 316 180 138 316 minecraft:packed_ice
setblock 181 135 289 minecraft:snow_block
fill 181 135 290 181 136 290 minecraft:packed_ice
setblock 181 135 294 minecraft:snow_block
fill 181 135 295 181 138 295 minecraft:packed_ice
setblock 181 135 298 minecraft:packed_ice
setblock 181 135 304 minecraft:snow_block
fill 181 135 305 181 136 305 minecraft:packed_ice
setblock 181 135 309 minecraft:snow_block
fill 181 135 310 181 138 310 minecraft:packed_ice
setblock 181 135 314 minecraft:snow_block
fill 181 135 315 181 138 315 minecraft:packed_ice
setblock 182 135 288 minecraft:snow_block
fill 182 135 289 182 137 289 minecraft:packed_ice
setblock 182 135 293 minecraft:snow_block
fill 182 135 294 182 138 294 minecraft:packed_ice
setblock 182 135 298 minecraft:snow_block
fill 182 135 299 182 138 299 minecraft:packed_ice
setblock 182 135 303 minecraft:snow_block
fill 182 135 304 182 137 304 minecraft:packed_ice
setblock 182 135 308 minecraft:snow_block
fill 182 135 309 182 138 309 minecraft:packed_ice
setblock 182 135 313 minecraft:snow_block
fill 182 135 314 182 138 314 minecraft:packed_ice
setblock 183 135 289 minecraft:light_blue_concrete
fill 183 135 290 183 153 290 minecraft:blue_ice
setblock 141 136 288 minecraft:blue_ice
setblock 141 136 314 minecraft:white_concrete
setblock 142 136 286 minecraft:packed_ice
setblock 142 136 287 minecraft:snow_block
fill 142 136 288 142 136 291 minecraft:packed_ice
setblock 142 136 292 minecraft:snow_block
fill 142 136 293 142 136 296 minecraft:packed_ice
setblock 142 136 297 minecraft:snow_block
fill 142 136 298 142 139 298 minecraft:packed_ice
setblock 142 136 302 minecraft:snow_block
setblock 142 136 303 minecraft:packed_ice
setblock 142 136 307 minecraft:snow_block
fill 142 136 308 142 137 308 minecraft:packed_ice
setblock 142 136 312 minecraft:snow_block
fill 142 136 313 142 138 313 minecraft:packed_ice
fill 143 136 289 143 136 290 minecraft:packed_ice
setblock 143 136 291 minecraft:snow_block
fill 143 136 292 143 136 295 minecraft:packed_ice
setblock 143 136 296 minecraft:snow_block
fill 143 136 297 143 139 297 minecraft:packed_ice
setblock 143 136 316 minecraft:snow_block
setblock 144 136 278 minecraft:light[level=15]
setblock 144 136 286 minecraft:light[level=15]
setblock 144 136 294 minecraft:light[level=15]
setblock 144 136 302 minecraft:light[level=15]
setblock 144 136 310 minecraft:light[level=15]
setblock 152 136 276 minecraft:packed_ice
setblock 152 136 278 minecraft:light[level=15]
setblock 152 136 286 minecraft:light[level=15]
setblock 152 136 294 minecraft:light[level=15]
setblock 152 136 310 minecraft:light[level=15]
setblock 152 136 316 minecraft:packed_ice
setblock 153 136 276 minecraft:snow_block
setblock 153 136 316 minecraft:snow_block
fill 154 136 276 154 139 276 minecraft:packed_ice
setblock 154 136 315 minecraft:snow_block
fill 154 136 316 154 139 316 minecraft:packed_ice
fill 155 136 315 155 139 315 minecraft:packed_ice
fill 156 136 276 157 136 276 minecraft:packed_ice
fill 156 136 280 156 141 280 minecraft:packed_ice
setblock 157 136 277 minecraft:snow_block
fill 157 136 279 157 141 279 minecraft:packed_ice
fill 157 136 281 157 141 281 minecraft:packed_ice
setblock 158 136 276 minecraft:snow_block
fill 158 136 277 158 139 277 minecraft:packed_ice
fill 158 136 280 158 142 280 minecraft:packed_ice
setblock 158 136 316 minecraft:snow_block
fill 159 136 276 159 139 276 minecraft:packed_ice
setblock 159 136 315 minecraft:snow_block
fill 159 136 316 159 139 316 minecraft:packed_ice
setblock 160 136 278 minecraft:light[level=15]
setblock 160 136 286 minecraft:light[level=15]
setblock 160 136 294 minecraft:light[level=15]
setblock 160 136 302 minecraft:light[level=15]
setblock 160 136 310 minecraft:light[level=15]
fill 160 136 315 160 139 315 minecraft:packed_ice
setblock 160 136 317 minecraft:light_blue_concrete
setblock 162 136 277 minecraft:snow_block
setblock 163 136 276 minecraft:snow_block
setblock 163 136 316 minecraft:snow_block
fill 164 136 276 167 136 276 minecraft:packed_ice
setblock 164 136 315 minecraft:snow_block
fill 164 136 316 167 136 316 minecraft:packed_ice
setblock 165 136 315 minecraft:packed_ice
fill 167 136 315 168 136 315 minecraft:packed_ice
setblock 168 136 276 minecraft:snow_block
setblock 168 136 278 minecraft:light[level=15]
setblock 168 136 286 minecraft:light[level=15]
setblock 168 136 294 minecraft:light[level=15]
setblock 168 136 302 minecraft:light[level=15]
setblock 168 136 310 minecraft:light[level=15]
setblock 168 136 316 minecraft:snow_block
fill 169 136 276 169 139 276 minecraft:packed_ice
setblock 169 136 315 minecraft:snow_block
fill 169 136 316 169 139 316 minecraft:packed_ice
fill 170 136 315 170 139 315 minecraft:packed_ice
fill 171 136 314 171 139 314 minecraft:packed_ice
setblock 173 136 276 minecraft:snow_block
setblock 173 136 316 minecraft:snow_block
fill 174 136 276 174 139 276 minecraft:packed_ice
setblock 174 136 315 minecraft:snow_block
fill 174 136 316 174 139 316 minecraft:packed_ice
setblock 175 136 314 minecraft:snow_block
fill 175 136 315 175 139 315 minecraft:packed_ice
setblock 176 136 278 minecraft:light[level=15]
setblock 176 136 286 minecraft:light[level=15]
setblock 176 136 294 minecraft:light[level=15]
setblock 176 136 302 minecraft:light[level=15]
setblock 176 136 313 minecraft:snow_block
fill 176 136 314 176 139 314 minecraft:packed_ice
fill 177 136 312 177 200 312 minecraft:snow_block
fill 177 136 313 177 138 313 minecraft:packed_ice
setblock 178 136 276 minecraft:snow_block
setblock 178 136 316 minecraft:snow_block
fill 179 136 276 179 139 276 minecraft:packed_ice
setblock 179 136 310 minecraft:snow_block
setblock 179 136 311 minecraft:packed_ice
setblock 179 136 315 minecraft:snow_block
fill 179 136 316 179 139 316 minecraft:packed_ice
setblock 180 136 309 minecraft:snow_block
fill 180 136 310 180 137 310 minecraft:packed_ice
setblock 180 136 314 minecraft:snow_block
fill 180 136 315 180 139 315 minecraft:packed_ice
setblock 181 136 293 minecraft:snow_block
fill 181 136 294 181 139 294 minecraft:packed_ice
setblock 181 136 308 minecraft:snow_block
fill 181 136 309 181 138 309 minecraft:packed_ice
setblock 181 136 313 minecraft:snow_block
fill 181 136 314 181 139 314 minecraft:packed_ice
setblock 182 136 288 minecraft:packed_ice
setblock 182 136 292 minecraft:snow_block
fill 182 136 293 182 139 293 minecraft:packed_ice
setblock 182 136 297 minecraft:snow_block
fill 182 136 298 182 139 298 minecraft:packed_ice
setblock 182 136 302 minecraft:snow_block
fill 182 136 303 182 137 303 minecraft:packed_ice
setblock 182 136 307 minecraft:snow_block
fill 182 136 308 182 139 308 minecraft:packed_ice
setblock 182 136 312 minecraft:snow_block
fill 182 136 313 182 139 313 minecraft:packed_ice
fill 183 136 289 183 147 289 minecraft:blue_ice
setblock 183 136 303 minecraft:white_concrete
fill 183 136 304 183 165 304 minecraft:blue_ice
setblock 141 137 288 minecraft:white_concrete
setblock 141 137 306 minecraft:white_concrete
fill 141 137 314 141 167 314 minecraft:blue_ice
fill 142 137 287 142 137 290 minecraft:packed_ice
setblock 142 137 291 minecraft:snow_block
fill 142 137 292 142 137 295 minecraft:packed_ice
setblock 142 137 296 minecraft:snow_block
fill 142 137 297 142 140 297 minecraft:packed_ice
setblock 142 137 301 minecraft:snow_block
setblock 142 137 302 minecraft:packed_ice
setblock 142 137 307 minecraft:packed_ice
setblock 142 137 311 minecraft:snow_block
fill 142 137 312 142 138 312 minecraft:packed_ice
setblock 142 137 316 minecraft:snow_block
setblock 143 137 290 minecraft:snow_block
fill 143 137 291 143 137 294 minecraft:packed_ice
setblock 143 137 295 minecraft:snow_block
fill 143 137 296 143 140 296 minecraft:packed_ice
setblock 151 137 276 minecraft:packed_ice
setblock 151 137 316 minecraft:packed_ice
setblock 152 137 276 minecraft:snow_block
setblock 152 137 316 minecraft:snow_block
fill 153 137 276 153 140 276 minecraft:packed_ice
fill 153 137 316 153 140 316 minecraft:packed_ice
fill 154 137 277 154 138 277 minecraft:packed_ice
fill 154 137 315 154 140 315 minecraft:packed_ice
setblock 156 137 276 minecraft:packed_ice
setblock 156 137 277 minecraft:snow_block
setblock 157 137 276 minecraft:snow_block
fill 157 137 277 157 140 277 minecraft:packed_ice
setblock 157 137 316 minecraft:snow_block
fill 158 137 276 158 140 276 minecraft:packed_ice
setblock 158 137 315 minecraft:snow_block
fill 158 137 316 158 140 316 minecraft:packed_ice
fill 159 137 315 159 140 315 minecraft:packed_ice
fill 160 137 317 160 167 317 minecraft:blue_ice
setblock 161 137 277 minecraft:snow_block
setblock 162 137 276 minecraft:snow_block
setblock 162 137 277 minecraft:packed_ice
setblock 162 137 316 minecraft:snow_block
fill 163 137 276 166 137 276 minecraft:packed_ice
setblock 163 137 315 minecraft:snow_block
fill 163 137 316 166 137 316 minecraft:packed_ice
setblock 167 137 276 minecraft:snow_block
setblock 167 137 316 minecraft:snow_block
fill 168 137 276 168 140 276 minecraft:packed_ice
setblock 168 137 315 minecraft:snow_block
fill 168 137 316 168 140 316 minecraft:packed_ice
fill 169 137 315 169 140 315 minecraft:packed_ice
fill 171 137 275 171 165 275 minecraft:blue_ice
setblock 172 137 275 minecraft:white_concrete
setblock 172 137 276 minecraft:snow_block
setblock 172 137 316 minecraft:snow_block
fill 173 137 275 175 149 275 minecraft:blue_ice
fill 173 137 276 173 140 276 minecraft:packed_ice
setblock 173 137 315 minecraft:snow_block
fill 173 137 316 173 140 316 minecraft:packed_ice
setblock 174 137 314 minecraft:snow_block
fill 174 137 315 174 140 315 minecraft:packed_ice
setblock 175 137 277 minecraft:packed_ice
setblock 175 137 313 minecraft:snow_block
fill 175 137 314 175 140 314 minecraft:packed_ice
setblock 176 137 277 minecraft:snow_block
fill 176 137 313 176 139 313 minecraft:packed_ice
setblock 177 137 276 minecraft:snow_block
setblock 177 137 316 minecraft:snow_block
fill 178 137 276 178 140 276 minecraft:packed_ice
setblock 178 137 315 minecraft:snow_block
fill 178 137 316 178 140 316 minecraft:packed_ice
setblock 179 137 314 minecraft:snow_block
fill 179 137 315 179 140 315 minecraft:packed_ice
setblock 180 137 309 minecraft:packed_ice
setblock 180 137 313 minecraft:snow_block
fill 180 137 314 180 139 314 minecraft:packed_ice
setblock 181 137 292 minecraft:snow_block
fill 181 137 293 181 138 293 minecraft:packed_ice
setblock 181 137 297 minecraft:snow_block
setblock 181 137 307 minecraft:snow_block
setblock 181 137 308 minecraft:packed_ice
setblock 181 137 312 minecraft:snow_block
fill 181 137 313 181 140 313 minecraft:packed_ice
setblock 182 137 291 minecraft:snow_block
fill 182 137 292 182 140 292 minecraft:packed_ice
setblock 182 137 296 minecraft:snow_block
fill 182 137 297 182 140 297 minecraft:packed_ice
setblock 182 137 301 minecraft:snow_block
setblock 182 137 302 minecraft:packed_ice
setblock 182 137 306 minecraft:snow_block
fill 182 137 307 182 138 307 minecraft:packed_ice
setblock 182 137 311 minecraft:snow_block
fill 182 137 312 182 140 312 minecraft:packed_ice
setblock 182 137 316 minecraft:snow_block
fill 183 137 303 183 165 303 minecraft:blue_ice
fill 141 138 288 141 165 288 minecraft:blue_ice
setblock 141 138 296 minecraft:light_blue_concrete
fill 141 138 297 141 163 298 minecraft:blue_ice
fill 141 138 306 141 165 306 minecraft:blue_ice
fill 142 138 288 142 138 289 minecraft:packed_ice
setblock 142 138 290 minecraft:snow_block
fill 142 138 291 142 138 294 minecraft:packed_ice
setblock 142 138 295 minecraft:snow_block
fill 142 138 296 142 141 296 minecraft:packed_ice
setblock 142 138 300 minecraft:snow_block
setblock 142 138 301 minecraft:packed_ice
setblock 142 138 311 minecraft:packed_ice
setblock 142 138 315 minecraft:snow_block
fill 143 138 291 143 138 293 minecraft:packed_ice
setblock 143 138 294 minecraft:snow_block
fill 143 138 295 143 141 295 minecraft:packed_ice
setblock 144 138 278 minecraft:light[level=12]
setblock 144 138 285 minecraft:light[level=12]
setblock 144 138 292 minecraft:light[level=12]
setblock 144 138 299 minecraft:light[level=12]
setblock 144 138 306 minecraft:light[level=12]
setblock 144 138 313 minecraft:light[level=12]
setblock 151 138 276 minecraft:snow_block
setblock 151 138 278 minecraft:light[level=12]
setblock 151 138 285 minecraft:light[level=12]
setblock 151 138 292 minecraft:light[level=12]
setblock 151 138 299 minecraft:light[level=12]
setblock 151 138 306 minecraft:light[level=12]
setblock 151 138 313 minecraft:light[level=12]
setblock 151 138 316 minecraft:snow_block
fill 152 138 276 152 141 276 minecraft:packed_ice
fill 152 138 316 152 141 316 minecraft:packed_ice
fill 153 138 277 153 139 277 minecraft:packed_ice
setblock 155 138 276 minecraft:packed_ice
setblock 155 138 277 minecraft:snow_block
setblock 156 138 276 minecraft:snow_block
fill 156 138 277 156 141 277 minecraft:packed_ice
fill 156 138 279 156 141 279 minecraft:packed_ice
fill 156 138 281 156 141 281 minecraft:packed_ice
setblock 156 138 316 minecraft:snow_block
fill 157 138 276 157 141 276 minecraft:packed_ice
setblock 157 138 315 minecraft:snow_block
fill 157 138 316 157 141 316 minecraft:packed_ice
setblock 158 138 278 minecraft:light[level=12]
fill 158 138 279 158 143 279 minecraft:packed_ice
fill 158 138 281 158 141 281 minecraft:packed_ice
setblock 158 138 285 minecraft:light[level=12]
setblock 158 138 292 minecraft:light[level=12]
setblock 158 138 299 minecraft:light[level=12]
setblock 158 138 306 minecraft:light[level=12]
setblock 158 138 313 minecraft:light[level=12]
fill 158 138 315 158 141 315 minecraft:packed_ice
setblock 160 138 277 minecraft:snow_block
setblock 161 138 276 minecraft:snow_block
fill 161 138 277 161 141 277 minecraft:packed_ice
setblock 161 138 316 minecraft:snow_block
fill 162 138 276 165 138 276 minecraft:packed_ice
setblock 162 138 315 minecraft:snow_block
fill 162 138 316 165 138 316 minecraft:packed_ice
setblock 165 138 278 minecraft:light[level=12]
setblock 165 138 285 minecraft:light[level=12]
setblock 165 138 292 minecraft:light[level=12]
setblock 165 138 299 minecraft:light[level=12]
setblock 165 138 306 minecraft:light[level=12]
setblock 165 138 313 minecraft:light[level=12]
setblock 166 138 276 minecraft:snow_block
setblock 166 138 316 minecraft:snow_block
fill 167 138 276 167 141 276 minecraft:packed_ice
fill 167 138 316 167 141 316 minecraft:packed_ice
fill 168 138 315 168 141 315 minecraft:packed_ice
setblock 171 138 276 minecraft:snow_block
setblock 171 138 316 minecraft:snow_block
fill 172 138 275 172 165 275 minecraft:blue_ice
fill 172 138 276 172 141 276 minecraft:packed_ice
setblock 172 138 278 minecraft:light[level=12]
setblock 172 138 285 minecraft:light[level=12]
setblock 172 138 292 minecraft:light[level=12]
setblock 172 138 299 minecraft:light[level=12]
setblock 172 138 306 minecraft:light[level=12]
setblock 172 138 313 minecraft:light[level=12]
setblock 172 138 315 minecraft:snow_block
fill 172 138 316 172 141 316 minecraft:packed_ice
setblock 173 138 314 minecraft:snow_block
fill 173 138 315 173 141 315 minecraft:packed_ice
setblock 174 138 277 minecraft:packed_ice
fill 174 138 314 174 141 314 minecraft:packed_ice
setblock 175 138 277 minecraft:snow_block
fill 175 138 313 175 139 313 minecraft:packed_ice
setblock 176 138 276 minecraft:snow_block
fill 176 138 277 176 141 277 minecraft:packed_ice
setblock 176 138 316 minecraft:snow_block
fill 177 138 276 177 141 276 minecraft:packed_ice
setblock 177 138 315 minecraft:snow_block
fill 177 138 316 177 141 316 minecraft:packed_ice
setblock 178 138 314 minecraft:snow_block
fill 178 138 315 178 141 315 minecraft:packed_ice
setblock 179 138 278 minecraft:light[level=12]
setblock 179 138 285 minecraft:light[level=12]
setblock 179 138 292 minecraft:light[level=12]
setblock 179 138 299 minecraft:light[level=12]
setblock 179 138 306 minecraft:light[level=12]
setblock 179 138 313 minecraft:light[level=12]
fill 179 138 314 179 140 314 minecraft:packed_ice
setblock 180 138 312 minecraft:snow_block
setblock 180 138 313 minecraft:packed_ice
setblock 181 138 296 minecraft:snow_block
fill 181 138 297 181 141 297 minecraft:packed_ice
setblock 181 138 311 minecraft:snow_block
fill 181 138 312 181 139 312 minecraft:packed_ice
setblock 181 138 316 minecraft:snow_block
setblock 182 138 290 minecraft:snow_block
fill 182 138 291 182 139 291 minecraft:packed_ice
setblock 182 138 295 minecraft:snow_block
fill 182 138 296 182 141 296 minecraft:packed_ice
setblock 182 138 300 minecraft:snow_block
fill 182 138 301 182 141 301 minecraft:packed_ice
setblock 182 138 306 minecraft:packed_ice
setblock 182 138 310 minecraft:snow_block
fill 182 138 311 182 140 311 minecraft:packed_ice
setblock 182 138 315 minecraft:snow_block
fill 182 138 316 182 141 316 minecraft:packed_ice
setblock 183 138 302 minecraft:white_concrete
fill 141 139 296 141 165 296 minecraft:blue_ice
setblock 141 139 305 minecraft:white_concrete
setblock 142 139 289 minecraft:snow_block
fill 142 139 290 142 139 293 minecraft:packed_ice
setblock 142 139 294 minecraft:snow_block
fill 142 139 295 142 142 295 minecraft:packed_ice
setblock 142 139 299 minecraft:snow_block
fill 142 139 300 142 142 300 minecraft:packed_ice
setblock 143 139 292 minecraft:packed_ice
setblock 143 139 293 minecraft:snow_block
fill 143 139 294 143 142 294 minecraft:packed_ice
setblock 144 139 275 minecraft:light_blue_concrete
setblock 150 139 276 minecraft:snow_block
fill 151 139 276 151 142 276 minecraft:packed_ice
fill 151 139 316 151 142 316 minecraft:packed_ice
fill 152 139 277 152 140 277 minecraft:packed_ice
fill 153 139 315 153 141 315 minecraft:packed_ice
setblock 154 139 277 minecraft:snow_block
setblock 155 139 276 minecraft:snow_block
fill 155 139 277 155 142 277 minecraft:packed_ice
setblock 155 139 316 minecraft:snow_block
fill 156 139 276 156 142 276 minecraft:packed_ice
setblock 156 139 315 minecraft:snow_block
fill 156 139 316 156 142 316 minecraft:packed_ice
fill 157 139 315 157 142 315 minecraft:packed_ice
setblock 159 139 277 minecraft:snow_block
setblock 160 139 276 minecraft:snow_block
fill 160 139 277 160 142 277 minecraft:packed_ice
setblock 160 139 316 minecraft:snow_block
fill 161 139 276 164 139 276 minecraft:packed_ice
setblock 161 139 315 minecraft:snow_block
fill 161 139 316 164 139 316 minecraft:packed_ice
setblock 165 139 276 minecraft:snow_block
setblock 165 139 316 minecraft:snow_block
fill 166 139 276 166 142 276 minecraft:packed_ice
fill 166 139 316 166 142 316 minecraft:packed_ice
setblock 170 139 276 minecraft:snow_block
setblock 170 139 316 minecraft:snow_block
fill 171 139 276 171 142 276 minecraft:packed_ice
setblock 171 139 315 minecraft:snow_block
fill 171 139 316 171 142 316 minecraft:packed_ice
setblock 172 139 314 minecraft:snow_block
fill 172 139 315 172 142 315 minecraft:packed_ice
setblock 173 139 277 minecraft:packed_ice
fill 173 139 314 173 142 314 minecraft:packed_ice
setblock 174 139 277 minecraft:snow_block
setblock 175 139 276 minecraft:snow_block
fill 175 139 277 175 142 277 minecraft:packed_ice
setblock 175 139 316 minecraft:snow_block
fill 176 139 276 176 142 276 minecraft:packed_ice
setblock 176 139 315 minecraft:snow_block
fill 176 139 316 176 142 316 minecraft:packed_ice
fill 177 139 313 177 139 314 minecraft:snow_block
fill 177 139 315 177 142 315 minecraft:packed_ice
fill 178 139 314 178 141 314 minecraft:packed_ice
setblock 180 139 276 minecraft:snow_block
setblock 180 139 316 minecraft:snow_block
setblock 181 139 295 minecraft:snow_block
fill 181 139 296 181 142 296 minecraft:packed_ice
setblock 181 139 311 minecraft:packed_ice
setblock 181 139 315 minecraft:snow_block
fill 181 139 316 181 142 316 minecraft:packed_ice
setblock 182 139 294 minecraft:snow_block
fill 182 139 295 182 142 295 minecraft:packed_ice
setblock 182 139 299 minecraft:snow_block
fill 182 139 300 182 142 300 minecraft:packed_ice
setblock 182 139 309 minecraft:snow_block
fill 182 139 310 182 140 310 minecraft:packed_ice
setblock 182 139 314 minecraft:snow_block
fill 182 139 315 182 142 315 minecraft:packed_ice
fill 183 139 302 183 162 302 minecraft:blue_ice
fill 141 140 305 141 146 305 minecraft:blue_ice
fill 142 140 290 142 140 292 minecraft:packed_ice
setblock 142 140 293 minecraft:snow_block
fill 142 140 294 142 143 294 minecraft:packed_ice
setblock 142 140 298 minecraft:snow_block
fill 142 140 299 142 143 299 minecraft:packed_ice
fill 143 140 293 143 143 293 minecraft:packed_ice
setblock 143 140 297 minecraft:snow_block
fill 144 140 275 144 161 275 minecraft:blue_ice
fill 145 140 280 145 146 280 minecraft:packed_ice
setblock 149 140 276 minecraft:snow_block
fill 150 140 276 150 143 276 minecraft:packed_ice
fill 150 140 316 150 143 316 minecraft:packed_ice
fill 151 140 277 151 141 277 minecraft:packed_ice
setblock 153 140 277 minecraft:snow_block
setblock 154 140 276 minecraft:snow_block
fill 154 140 277 154 142 278 minecraft:packed_ice
setblock 154 140 316 minecraft:snow_block
fill 155 140 276 155 143 276 minecraft:packed_ice
fill 155 140 278 156 140 278 minecraft:packed_ice
setblock 155 140 315 minecraft:snow_block
fill 155 140 316 155 143 316 minecraft:packed_ice
fill 156 140 315 156 143 315 minecraft:packed_ice
setblock 157 140 278 minecraft:snow_block
setblock 158 140 277 minecraft:snow_block
setblock 159 140 276 minecraft:snow_block
fill 159 140 277 159 143 277 minecraft:packed_ice
setblock 159 140 316 minecraft:snow_block
schedule function dropper:buildpart/63_5 1t
