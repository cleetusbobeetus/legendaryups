setblock 131 247 550 minecraft:smooth_basalt
fill 131 247 551 131 250 551 minecraft:blackstone
setblock 132 247 549 minecraft:smooth_basalt
fill 132 247 550 132 250 550 minecraft:blackstone
setblock 133 247 548 minecraft:smooth_basalt
setblock 133 247 549 minecraft:blackstone
setblock 134 247 512 minecraft:smooth_basalt
setblock 134 247 547 minecraft:smooth_basalt
fill 134 247 548 134 249 548 minecraft:blackstone
setblock 135 247 511 minecraft:smooth_basalt
fill 135 247 512 135 250 512 minecraft:blackstone
setblock 135 247 522 minecraft:blackstone
setblock 135 247 526 minecraft:smooth_basalt
setblock 135 247 527 minecraft:blackstone
setblock 135 247 546 minecraft:smooth_basalt
fill 135 247 547 135 250 547 minecraft:blackstone
setblock 135 247 551 minecraft:smooth_basalt
setblock 95 248 545 minecraft:smooth_basalt
fill 95 248 546 95 251 546 minecraft:blackstone
setblock 95 248 550 minecraft:smooth_basalt
fill 95 248 551 98 248 551 minecraft:blackstone
setblock 96 248 549 minecraft:smooth_basalt
fill 96 248 550 99 248 550 minecraft:blackstone
setblock 99 248 551 minecraft:smooth_basalt
setblock 100 248 550 minecraft:smooth_basalt
fill 100 248 551 100 251 551 minecraft:blackstone
fill 101 248 550 101 251 550 minecraft:blackstone
fill 102 248 549 105 248 549 minecraft:blackstone
setblock 104 248 511 minecraft:smooth_basalt
setblock 104 248 551 minecraft:smooth_basalt
fill 105 248 511 105 251 511 minecraft:blackstone
setblock 105 248 550 minecraft:smooth_basalt
fill 105 248 551 105 251 551 minecraft:blackstone
setblock 106 248 549 minecraft:smooth_basalt
fill 106 248 550 106 251 550 minecraft:blackstone
fill 107 248 549 107 249 549 minecraft:blackstone
setblock 109 248 511 minecraft:smooth_basalt
setblock 109 248 551 minecraft:smooth_basalt
fill 110 248 511 110 251 511 minecraft:blackstone
setblock 110 248 550 minecraft:smooth_basalt
fill 110 248 551 110 251 551 minecraft:blackstone
setblock 111 248 550 minecraft:blackstone
fill 121 248 551 123 248 551 minecraft:blackstone
setblock 123 248 512 minecraft:smooth_basalt
setblock 124 248 511 minecraft:smooth_basalt
fill 124 248 512 124 251 512 minecraft:blackstone
setblock 124 248 550 minecraft:blackstone
setblock 124 248 551 minecraft:smooth_basalt
fill 125 248 511 125 251 511 minecraft:blackstone
setblock 125 248 550 minecraft:smooth_basalt
fill 125 248 551 125 251 551 minecraft:blackstone
setblock 126 248 549 minecraft:smooth_basalt
fill 126 248 550 126 251 550 minecraft:blackstone
setblock 127 248 513 minecraft:smooth_basalt
fill 127 248 549 127 250 549 minecraft:blackstone
setblock 128 248 512 minecraft:smooth_basalt
fill 128 248 513 128 251 513 minecraft:blackstone
setblock 129 248 511 minecraft:smooth_basalt
fill 129 248 512 129 251 512 minecraft:blackstone
setblock 129 248 551 minecraft:smooth_basalt
fill 130 248 511 130 251 511 minecraft:blackstone
setblock 130 248 550 minecraft:smooth_basalt
fill 130 248 551 130 251 551 minecraft:blackstone
setblock 131 248 549 minecraft:smooth_basalt
fill 131 248 550 131 251 550 minecraft:blackstone
setblock 132 248 549 minecraft:blackstone
setblock 133 248 512 minecraft:smooth_basalt
setblock 134 248 511 minecraft:smooth_basalt
setblock 134 248 547 minecraft:blackstone
setblock 134 248 551 minecraft:smooth_basalt
fill 135 248 511 135 251 511 minecraft:blackstone
setblock 135 248 545 minecraft:smooth_basalt
fill 135 248 546 135 249 546 minecraft:blackstone
setblock 135 248 550 minecraft:smooth_basalt
fill 135 248 551 135 251 551 minecraft:blackstone
setblock 95 249 544 minecraft:smooth_basalt
fill 95 249 545 95 250 545 minecraft:blackstone
setblock 95 249 549 minecraft:smooth_basalt
fill 95 249 550 97 249 551 minecraft:blackstone
setblock 96 249 548 minecraft:smooth_basalt
setblock 96 249 549 minecraft:blackstone
setblock 98 249 550 minecraft:blackstone
setblock 98 249 551 minecraft:smooth_basalt
setblock 99 249 550 minecraft:smooth_basalt
fill 99 249 551 99 252 551 minecraft:blackstone
fill 100 249 550 100 252 550 minecraft:blackstone
setblock 103 249 511 minecraft:smooth_basalt
fill 103 249 549 104 249 549 minecraft:blackstone
setblock 103 249 551 minecraft:smooth_basalt
fill 104 249 511 104 252 511 minecraft:blackstone
setblock 104 249 550 minecraft:smooth_basalt
fill 104 249 551 104 252 551 minecraft:blackstone
setblock 105 249 549 minecraft:smooth_basalt
fill 105 249 550 105 252 550 minecraft:blackstone
setblock 106 249 549 minecraft:blackstone
setblock 108 249 511 minecraft:smooth_basalt
setblock 108 249 551 minecraft:smooth_basalt
fill 109 249 511 109 252 511 minecraft:blackstone
setblock 109 249 550 minecraft:smooth_basalt
fill 109 249 551 109 252 551 minecraft:blackstone
setblock 110 249 550 minecraft:blackstone
fill 120 249 511 120 251 511 minecraft:blackstone
fill 121 249 551 122 249 551 minecraft:blackstone
setblock 123 249 511 minecraft:smooth_basalt
fill 123 249 512 123 252 512 minecraft:blackstone
setblock 123 249 550 minecraft:blackstone
setblock 123 249 551 minecraft:smooth_basalt
fill 124 249 511 124 252 511 minecraft:blackstone
setblock 124 249 550 minecraft:smooth_basalt
fill 124 249 551 124 252 551 minecraft:blackstone
fill 125 249 550 125 252 550 minecraft:blackstone
setblock 126 249 513 minecraft:smooth_basalt
fill 126 249 534 127 250 534 minecraft:gold_block
setblock 127 249 512 minecraft:smooth_basalt
fill 127 249 513 127 252 513 minecraft:blackstone
setblock 128 249 511 minecraft:smooth_basalt
fill 128 249 512 128 252 512 minecraft:blackstone
setblock 128 249 551 minecraft:smooth_basalt
fill 129 249 511 129 252 511 minecraft:blackstone
setblock 129 249 550 minecraft:smooth_basalt
fill 129 249 551 129 252 551 minecraft:blackstone
setblock 130 249 549 minecraft:smooth_basalt
fill 130 249 550 130 252 550 minecraft:blackstone
setblock 131 249 549 minecraft:blackstone
setblock 132 249 512 minecraft:smooth_basalt
setblock 133 249 511 minecraft:smooth_basalt
setblock 133 249 551 minecraft:smooth_basalt
fill 134 249 511 134 252 511 minecraft:blackstone
setblock 134 249 550 minecraft:smooth_basalt
fill 134 249 551 134 252 551 minecraft:blackstone
setblock 135 249 549 minecraft:smooth_basalt
fill 135 249 550 135 252 550 minecraft:blackstone
setblock 95 250 548 minecraft:smooth_basalt
fill 95 250 549 95 251 551 minecraft:blackstone
fill 96 250 550 96 250 551 minecraft:blackstone
setblock 97 250 551 minecraft:smooth_basalt
setblock 98 250 550 minecraft:smooth_basalt
fill 98 250 551 98 253 551 minecraft:blackstone
fill 99 250 550 99 253 550 minecraft:blackstone
setblock 102 250 551 minecraft:smooth_basalt
fill 103 250 511 103 253 511 minecraft:blackstone
setblock 103 250 550 minecraft:smooth_basalt
fill 103 250 551 103 253 551 minecraft:blackstone
setblock 104 250 549 minecraft:smooth_basalt
fill 104 250 550 104 253 550 minecraft:blackstone
setblock 105 250 549 minecraft:blackstone
setblock 107 250 511 minecraft:smooth_basalt
setblock 107 250 551 minecraft:smooth_basalt
fill 108 250 511 108 253 511 minecraft:blackstone
setblock 108 250 550 minecraft:smooth_basalt
fill 108 250 551 108 253 551 minecraft:blackstone
setblock 109 250 550 minecraft:blackstone
fill 119 250 511 119 252 511 minecraft:blackstone
setblock 121 250 551 minecraft:blackstone
setblock 122 250 511 minecraft:smooth_basalt
fill 122 250 512 122 253 512 minecraft:blackstone
setblock 122 250 551 minecraft:smooth_basalt
fill 123 250 511 123 253 511 minecraft:blackstone
setblock 123 250 550 minecraft:smooth_basalt
fill 123 250 551 123 253 551 minecraft:blackstone
fill 124 250 550 124 253 550 minecraft:blackstone
setblock 125 250 513 minecraft:smooth_basalt
setblock 126 250 512 minecraft:smooth_basalt
fill 126 250 513 126 253 513 minecraft:blackstone
setblock 127 250 511 minecraft:smooth_basalt
fill 127 250 512 127 253 512 minecraft:blackstone
setblock 127 250 551 minecraft:smooth_basalt
fill 128 250 511 128 253 511 minecraft:blackstone
setblock 128 250 550 minecraft:smooth_basalt
fill 128 250 551 128 253 551 minecraft:blackstone
fill 129 250 550 129 253 550 minecraft:blackstone
setblock 131 250 512 minecraft:smooth_basalt
setblock 132 250 511 minecraft:smooth_basalt
fill 132 250 512 132 253 512 minecraft:blackstone
setblock 132 250 551 minecraft:smooth_basalt
fill 133 250 511 133 253 511 minecraft:blackstone
setblock 133 250 550 minecraft:smooth_basalt
fill 133 250 551 133 253 551 minecraft:blackstone
setblock 134 250 549 minecraft:smooth_basalt
fill 134 250 550 134 251 550 minecraft:blackstone
setblock 135 250 548 minecraft:smooth_basalt
fill 135 250 549 135 253 549 minecraft:blackstone
setblock 95 251 547 minecraft:smooth_basalt
fill 95 251 548 95 254 548 minecraft:blackstone
setblock 96 251 551 minecraft:smooth_basalt
fill 97 251 551 97 254 551 minecraft:blackstone
setblock 101 251 551 minecraft:smooth_basalt
fill 102 251 511 102 254 511 minecraft:blackstone
setblock 102 251 550 minecraft:smooth_basalt
fill 102 251 551 102 254 551 minecraft:blackstone
fill 103 251 550 103 254 550 minecraft:blackstone
setblock 106 251 511 minecraft:smooth_basalt
setblock 106 251 551 minecraft:smooth_basalt
fill 107 251 511 107 254 511 minecraft:blackstone
setblock 107 251 550 minecraft:smooth_basalt
fill 107 251 551 107 254 551 minecraft:blackstone
setblock 108 251 550 minecraft:blackstone
setblock 111 251 551 minecraft:smooth_basalt
setblock 120 251 551 minecraft:blackstone
setblock 121 251 511 minecraft:smooth_basalt
fill 121 251 512 121 254 512 minecraft:blackstone
setblock 121 251 551 minecraft:smooth_basalt
fill 122 251 511 122 254 511 minecraft:blackstone
fill 122 251 551 122 254 551 minecraft:blackstone
fill 123 251 550 123 254 550 minecraft:blackstone
setblock 124 251 513 minecraft:smooth_basalt
setblock 125 251 512 minecraft:smooth_basalt
fill 125 251 513 125 254 513 minecraft:blackstone
setblock 126 251 511 minecraft:smooth_basalt
fill 126 251 512 126 254 512 minecraft:blackstone
setblock 126 251 551 minecraft:smooth_basalt
fill 127 251 511 127 254 511 minecraft:blackstone
setblock 127 251 550 minecraft:smooth_basalt
fill 127 251 551 127 254 551 minecraft:blackstone
fill 128 251 550 128 254 550 minecraft:blackstone
setblock 130 251 512 minecraft:smooth_basalt
setblock 131 251 511 minecraft:smooth_basalt
fill 131 251 512 131 254 512 minecraft:blackstone
setblock 131 251 551 minecraft:smooth_basalt
fill 132 251 511 132 254 511 minecraft:blackstone
setblock 132 251 550 minecraft:smooth_basalt
fill 132 251 551 132 254 551 minecraft:blackstone
fill 133 251 550 133 252 550 minecraft:blackstone
setblock 135 251 512 minecraft:smooth_basalt
setblock 135 251 547 minecraft:smooth_basalt
fill 135 251 548 135 254 548 minecraft:blackstone
fill 95 252 547 95 253 547 minecraft:blackstone
fill 95 252 549 95 252 550 minecraft:blackstone
setblock 95 252 551 minecraft:smooth_basalt
fill 96 252 551 96 255 551 minecraft:blackstone
setblock 100 252 511 minecraft:smooth_basalt
setblock 100 252 551 minecraft:smooth_basalt
fill 101 252 511 101 255 511 minecraft:blackstone
setblock 101 252 550 minecraft:smooth_basalt
fill 101 252 551 101 255 551 minecraft:blackstone
fill 102 252 550 102 255 550 minecraft:blackstone
setblock 105 252 511 minecraft:smooth_basalt
setblock 105 252 551 minecraft:smooth_basalt
fill 106 252 511 106 255 511 minecraft:blackstone
setblock 106 252 550 minecraft:smooth_basalt
fill 106 252 551 106 255 551 minecraft:blackstone
fill 107 252 550 107 253 550 minecraft:blackstone
setblock 110 252 511 minecraft:smooth_basalt
setblock 110 252 551 minecraft:smooth_basalt
fill 117 252 511 118 253 511 minecraft:blackstone
setblock 120 252 511 minecraft:smooth_basalt
fill 120 252 512 120 255 512 minecraft:blackstone
setblock 120 252 551 minecraft:smooth_basalt
fill 121 252 511 121 255 511 minecraft:blackstone
fill 121 252 551 121 255 551 minecraft:blackstone
setblock 123 252 513 minecraft:smooth_basalt
setblock 124 252 512 minecraft:smooth_basalt
fill 124 252 513 124 255 513 minecraft:blackstone
setblock 125 252 511 minecraft:smooth_basalt
fill 125 252 512 125 255 512 minecraft:blackstone
setblock 125 252 551 minecraft:smooth_basalt
fill 126 252 511 126 255 511 minecraft:blackstone
setblock 126 252 550 minecraft:smooth_basalt
fill 126 252 551 126 255 551 minecraft:blackstone
fill 127 252 550 127 255 550 minecraft:blackstone
setblock 128 252 513 minecraft:smooth_basalt
setblock 129 252 512 minecraft:smooth_basalt
setblock 130 252 511 minecraft:smooth_basalt
fill 130 252 512 130 255 512 minecraft:blackstone
setblock 130 252 551 minecraft:smooth_basalt
fill 131 252 511 131 255 511 minecraft:blackstone
setblock 131 252 550 minecraft:smooth_basalt
fill 131 252 551 131 255 551 minecraft:blackstone
fill 132 252 550 132 255 550 minecraft:blackstone
setblock 135 252 511 minecraft:smooth_basalt
fill 135 252 512 135 255 512 minecraft:blackstone
setblock 135 252 551 minecraft:smooth_basalt
fill 95 253 531 95 253 534 minecraft:blackstone
setblock 95 253 549 minecraft:blackstone
setblock 95 253 550 minecraft:smooth_basalt
fill 95 253 551 95 256 551 minecraft:blackstone
setblock 97 253 513 minecraft:light[level=12]
setblock 97 253 521 minecraft:light[level=12]
setblock 97 253 529 minecraft:light[level=12]
setblock 97 253 537 minecraft:light[level=12]
setblock 97 253 545 minecraft:light[level=12]
setblock 99 253 511 minecraft:smooth_basalt
setblock 99 253 551 minecraft:smooth_basalt
fill 100 253 511 100 256 511 minecraft:blackstone
setblock 100 253 550 minecraft:smooth_basalt
fill 100 253 551 100 256 551 minecraft:blackstone
fill 101 253 550 101 256 550 minecraft:blackstone
setblock 104 253 511 minecraft:smooth_basalt
setblock 104 253 551 minecraft:smooth_basalt
fill 105 253 511 105 255 512 minecraft:blackstone
setblock 105 253 513 minecraft:light[level=12]
setblock 105 253 521 minecraft:light[level=12]
setblock 105 253 529 minecraft:light[level=12]
setblock 105 253 537 minecraft:light[level=12]
setblock 105 253 545 minecraft:light[level=12]
setblock 105 253 550 minecraft:smooth_basalt
fill 105 253 551 105 256 551 minecraft:blackstone
fill 106 253 550 106 254 550 minecraft:blackstone
setblock 109 253 511 minecraft:smooth_basalt
setblock 109 253 551 minecraft:smooth_basalt
fill 110 253 511 111 255 511 minecraft:blackstone
setblock 113 253 513 minecraft:light[level=12]
setblock 113 253 521 minecraft:light[level=12]
setblock 113 253 529 minecraft:light[level=12]
setblock 113 253 537 minecraft:light[level=12]
setblock 113 253 545 minecraft:light[level=12]
fill 116 253 511 116 255 511 minecraft:blackstone
setblock 119 253 511 minecraft:smooth_basalt
fill 119 253 512 119 256 512 minecraft:blackstone
setblock 119 253 551 minecraft:smooth_basalt
fill 120 253 511 120 256 511 minecraft:blackstone
fill 120 253 551 120 256 551 minecraft:blackstone
setblock 121 253 513 minecraft:blackstone
setblock 121 253 529 minecraft:light[level=12]
setblock 121 253 537 minecraft:light[level=12]
setblock 121 253 545 minecraft:light[level=12]
setblock 122 253 513 minecraft:smooth_basalt
fill 122 253 550 122 255 550 minecraft:blackstone
setblock 123 253 512 minecraft:smooth_basalt
fill 123 253 513 123 256 513 minecraft:blackstone
setblock 124 253 511 minecraft:smooth_basalt
fill 124 253 512 124 256 512 minecraft:blackstone
setblock 124 253 551 minecraft:smooth_basalt
fill 125 253 511 125 256 511 minecraft:blackstone
setblock 125 253 550 minecraft:smooth_basalt
fill 125 253 551 125 256 551 minecraft:blackstone
fill 126 253 550 126 256 550 minecraft:blackstone
setblock 127 253 513 minecraft:smooth_basalt
setblock 128 253 512 minecraft:smooth_basalt
fill 128 253 513 129 255 513 minecraft:blackstone
setblock 129 253 511 minecraft:smooth_basalt
fill 129 253 512 129 256 512 minecraft:blackstone
setblock 129 253 521 minecraft:light[level=12]
setblock 129 253 529 minecraft:light[level=12]
setblock 129 253 537 minecraft:light[level=12]
setblock 129 253 545 minecraft:light[level=12]
setblock 129 253 551 minecraft:smooth_basalt
fill 130 253 511 130 256 511 minecraft:blackstone
setblock 130 253 550 minecraft:smooth_basalt
fill 130 253 551 130 256 551 minecraft:blackstone
fill 131 253 550 131 256 550 minecraft:blackstone
setblock 134 253 511 minecraft:smooth_basalt
setblock 134 253 551 minecraft:smooth_basalt
fill 135 253 511 135 256 511 minecraft:blackstone
fill 135 253 513 135 254 513 minecraft:blackstone
setblock 135 253 550 minecraft:smooth_basalt
fill 135 253 551 135 256 551 minecraft:blackstone
fill 95 254 530 95 254 533 minecraft:blackstone
setblock 95 254 534 minecraft:smooth_basalt
fill 95 254 535 95 255 537 minecraft:blackstone
setblock 95 254 549 minecraft:smooth_basalt
fill 95 254 550 95 257 550 minecraft:blackstone
setblock 97 254 511 minecraft:blackstone
setblock 98 254 511 minecraft:smooth_basalt
setblock 98 254 551 minecraft:smooth_basalt
fill 99 254 511 99 257 511 minecraft:blackstone
setblock 99 254 550 minecraft:smooth_basalt
fill 99 254 551 99 257 551 minecraft:blackstone
fill 100 254 550 100 257 550 minecraft:blackstone
setblock 102 254 512 minecraft:smooth_basalt
setblock 103 254 511 minecraft:smooth_basalt
fill 103 254 512 104 256 512 minecraft:blackstone
setblock 103 254 551 minecraft:smooth_basalt
fill 104 254 511 104 257 511 minecraft:blackstone
setblock 104 254 550 minecraft:smooth_basalt
fill 104 254 551 104 257 551 minecraft:blackstone
fill 105 254 550 105 256 550 minecraft:blackstone
setblock 106 254 512 minecraft:blackstone
setblock 107 254 512 minecraft:smooth_basalt
setblock 108 254 511 minecraft:smooth_basalt
setblock 108 254 551 minecraft:smooth_basalt
fill 109 254 511 109 257 511 minecraft:blackstone
fill 109 254 551 109 255 551 minecraft:blackstone
setblock 112 254 511 minecraft:blackstone
setblock 113 254 511 minecraft:smooth_basalt
fill 114 254 511 115 256 511 minecraft:blackstone
setblock 117 254 511 minecraft:blackstone
setblock 118 254 511 minecraft:smooth_basalt
fill 118 254 512 118 257 512 minecraft:blackstone
setblock 118 254 551 minecraft:smooth_basalt
fill 119 254 511 119 257 511 minecraft:blackstone
fill 119 254 551 119 257 551 minecraft:blackstone
setblock 120 254 513 minecraft:blackstone
setblock 121 254 513 minecraft:smooth_basalt
fill 121 254 550 121 256 550 minecraft:blackstone
setblock 122 254 512 minecraft:smooth_basalt
fill 122 254 513 122 257 513 minecraft:blackstone
setblock 123 254 511 minecraft:smooth_basalt
fill 123 254 512 123 257 512 minecraft:blackstone
setblock 123 254 551 minecraft:smooth_basalt
fill 124 254 511 124 257 511 minecraft:blackstone
setblock 124 254 514 minecraft:blackstone
setblock 124 254 550 minecraft:smooth_basalt
fill 124 254 551 124 257 551 minecraft:blackstone
setblock 125 254 514 minecraft:smooth_basalt
fill 125 254 550 125 257 550 minecraft:blackstone
setblock 126 254 513 minecraft:smooth_basalt
setblock 127 254 512 minecraft:smooth_basalt
fill 127 254 513 127 257 513 minecraft:blackstone
setblock 128 254 511 minecraft:smooth_basalt
fill 128 254 512 128 257 512 minecraft:blackstone
setblock 128 254 551 minecraft:smooth_basalt
fill 129 254 511 129 257 511 minecraft:blackstone
setblock 129 254 550 minecraft:smooth_basalt
fill 129 254 551 129 257 551 minecraft:blackstone
fill 130 254 550 130 257 550 minecraft:blackstone
setblock 132 254 512 minecraft:smooth_basalt
setblock 133 254 511 minecraft:smooth_basalt
fill 133 254 512 133 257 512 minecraft:blackstone
setblock 133 254 551 minecraft:smooth_basalt
fill 134 254 511 134 257 511 minecraft:blackstone
fill 134 254 551 134 257 551 minecraft:blackstone
setblock 135 254 549 minecraft:smooth_basalt
fill 135 254 550 135 257 550 minecraft:blackstone
fill 95 255 511 96 255 511 minecraft:blackstone
fill 95 255 530 95 255 532 minecraft:blackstone
setblock 95 255 533 minecraft:smooth_basalt
fill 95 255 534 96 257 534 minecraft:blackstone
setblock 95 255 538 minecraft:smooth_basalt
fill 95 255 539 95 257 540 minecraft:blackstone
setblock 95 255 547 minecraft:blackstone
setblock 95 255 548 minecraft:smooth_basalt
fill 95 255 549 95 258 549 minecraft:blackstone
setblock 96 255 531 minecraft:blackstone
setblock 96 255 532 minecraft:smooth_basalt
fill 96 255 533 96 258 533 minecraft:blackstone
fill 96 255 535 96 255 536 minecraft:blackstone
setblock 96 255 537 minecraft:smooth_basalt
setblock 97 255 511 minecraft:smooth_basalt
setblock 97 255 551 minecraft:smooth_basalt
fill 98 255 511 98 258 511 minecraft:blackstone
setblock 98 255 550 minecraft:smooth_basalt
fill 98 255 551 98 258 551 minecraft:blackstone
fill 99 255 550 99 258 550 minecraft:blackstone
setblock 100 255 512 minecraft:blackstone
setblock 101 255 512 minecraft:smooth_basalt
setblock 102 255 511 minecraft:smooth_basalt
fill 102 255 512 102 258 512 minecraft:blackstone
setblock 102 255 551 minecraft:smooth_basalt
fill 103 255 511 103 258 511 minecraft:blackstone
setblock 103 255 550 minecraft:smooth_basalt
fill 103 255 551 103 258 551 minecraft:blackstone
fill 104 255 550 104 257 550 minecraft:blackstone
setblock 106 255 512 minecraft:smooth_basalt
setblock 107 255 511 minecraft:smooth_basalt
fill 107 255 512 108 257 512 minecraft:blackstone
setblock 107 255 551 minecraft:smooth_basalt
fill 108 255 511 108 258 511 minecraft:blackstone
fill 108 255 551 108 257 551 minecraft:blackstone
setblock 112 255 511 minecraft:smooth_basalt
fill 113 255 511 113 258 511 minecraft:blackstone
setblock 116 255 512 minecraft:smooth_basalt
setblock 117 255 511 minecraft:smooth_basalt
fill 117 255 512 117 258 512 minecraft:blackstone
fill 118 255 511 118 258 511 minecraft:blackstone
fill 118 255 551 118 258 551 minecraft:blackstone
setblock 119 255 513 minecraft:blackstone
setblock 120 255 513 minecraft:smooth_basalt
setblock 121 255 512 minecraft:smooth_basalt
fill 121 255 513 121 257 514 minecraft:blackstone
setblock 122 255 511 minecraft:smooth_basalt
fill 122 255 512 122 258 512 minecraft:blackstone
fill 122 255 514 123 255 514 minecraft:blackstone
setblock 122 255 551 minecraft:smooth_basalt
fill 123 255 511 123 258 511 minecraft:blackstone
setblock 123 255 550 minecraft:smooth_basalt
fill 123 255 551 123 258 551 minecraft:blackstone
setblock 124 255 514 minecraft:smooth_basalt
fill 124 255 550 124 258 550 minecraft:blackstone
setblock 125 255 513 minecraft:smooth_basalt
fill 125 255 514 126 257 514 minecraft:blackstone
setblock 126 255 512 minecraft:smooth_basalt
fill 126 255 513 126 258 513 minecraft:blackstone
setblock 127 255 511 minecraft:smooth_basalt
fill 127 255 512 127 258 512 minecraft:blackstone
setblock 127 255 551 minecraft:smooth_basalt
fill 128 255 511 128 258 511 minecraft:blackstone
setblock 128 255 550 minecraft:smooth_basalt
fill 128 255 551 128 258 551 minecraft:blackstone
fill 129 255 550 129 258 550 minecraft:blackstone
setblock 131 255 512 minecraft:smooth_basalt
setblock 132 255 511 minecraft:smooth_basalt
fill 132 255 512 132 258 512 minecraft:blackstone
setblock 132 255 551 minecraft:smooth_basalt
fill 133 255 511 133 258 511 minecraft:blackstone
fill 133 255 551 133 258 551 minecraft:blackstone
fill 134 255 512 134 256 512 minecraft:blackstone
setblock 135 255 513 minecraft:smooth_basalt
fill 135 255 514 135 258 514 minecraft:blackstone
setblock 135 255 548 minecraft:smooth_basalt
fill 135 255 549 135 258 549 minecraft:blackstone
setblock 95 256 511 minecraft:blackstone
setblock 95 256 512 minecraft:smooth_basalt
fill 95 256 513 95 259 513 minecraft:blackstone
fill 95 256 529 95 256 531 minecraft:blackstone
setblock 95 256 532 minecraft:smooth_basalt
fill 95 256 533 95 259 533 minecraft:blackstone
fill 95 256 535 95 256 536 minecraft:blackstone
setblock 95 256 537 minecraft:smooth_basalt
fill 95 256 538 96 258 538 minecraft:blackstone
setblock 95 256 541 minecraft:blackstone
setblock 95 256 542 minecraft:smooth_basalt
fill 95 256 543 95 259 543 minecraft:blackstone
setblock 95 256 546 minecraft:blackstone
setblock 95 256 547 minecraft:smooth_basalt
fill 95 256 548 95 259 548 minecraft:blackstone
setblock 96 256 511 minecraft:smooth_basalt
setblock 96 256 530 minecraft:blackstone
setblock 96 256 531 minecraft:smooth_basalt
fill 96 256 532 97 258 532 minecraft:blackstone
setblock 96 256 535 minecraft:blackstone
setblock 96 256 536 minecraft:smooth_basalt
fill 96 256 537 97 258 537 minecraft:blackstone
fill 96 256 539 96 257 539 minecraft:blackstone
setblock 96 256 551 minecraft:smooth_basalt
fill 97 256 511 97 259 511 minecraft:blackstone
fill 97 256 533 97 256 534 minecraft:blackstone
setblock 97 256 535 minecraft:smooth_basalt
fill 97 256 536 97 259 536 minecraft:blackstone
setblock 97 256 550 minecraft:smooth_basalt
fill 97 256 551 97 259 551 minecraft:blackstone
fill 98 256 550 98 259 550 minecraft:blackstone
setblock 99 256 512 minecraft:blackstone
setblock 100 256 512 minecraft:smooth_basalt
setblock 101 256 511 minecraft:smooth_basalt
fill 101 256 512 101 259 512 minecraft:blackstone
setblock 101 256 551 minecraft:smooth_basalt
fill 102 256 511 102 259 511 minecraft:blackstone
setblock 102 256 550 minecraft:smooth_basalt
fill 102 256 551 102 259 551 minecraft:blackstone
fill 103 256 550 103 258 550 minecraft:blackstone
setblock 105 256 511 minecraft:blackstone
setblock 105 256 512 minecraft:smooth_basalt
setblock 106 256 511 minecraft:smooth_basalt
fill 106 256 512 106 259 512 minecraft:blackstone
setblock 106 256 551 minecraft:smooth_basalt
fill 107 256 511 107 259 511 minecraft:blackstone
fill 107 256 551 107 258 551 minecraft:blackstone
setblock 109 256 512 minecraft:blackstone
setblock 110 256 511 minecraft:blackstone
setblock 111 256 511 minecraft:smooth_basalt
fill 112 256 511 112 259 511 minecraft:blackstone
setblock 114 256 512 minecraft:blackstone
setblock 115 256 512 minecraft:smooth_basalt
setblock 116 256 511 minecraft:smooth_basalt
fill 116 256 512 116 259 512 minecraft:blackstone
fill 117 256 511 117 259 511 minecraft:blackstone
fill 117 256 513 118 256 513 minecraft:blackstone
fill 117 256 551 117 259 551 minecraft:blackstone
setblock 119 256 513 minecraft:smooth_basalt
setblock 120 256 512 minecraft:smooth_basalt
fill 120 256 513 120 258 514 minecraft:blackstone
fill 120 256 550 120 257 550 minecraft:blackstone
setblock 121 256 511 minecraft:smooth_basalt
fill 121 256 512 121 259 512 minecraft:blackstone
setblock 121 256 551 minecraft:smooth_basalt
fill 122 256 511 122 259 511 minecraft:blackstone
setblock 122 256 514 minecraft:blackstone
setblock 122 256 550 minecraft:smooth_basalt
fill 122 256 551 122 259 551 minecraft:blackstone
setblock 123 256 514 minecraft:smooth_basalt
fill 123 256 550 123 259 550 minecraft:blackstone
setblock 124 256 513 minecraft:smooth_basalt
fill 124 256 514 124 259 514 minecraft:blackstone
setblock 125 256 512 minecraft:smooth_basalt
fill 125 256 513 125 259 513 minecraft:blackstone
setblock 126 256 511 minecraft:smooth_basalt
fill 126 256 512 126 259 512 minecraft:blackstone
setblock 126 256 551 minecraft:smooth_basalt
fill 127 256 511 127 259 511 minecraft:blackstone
setblock 127 256 514 minecraft:blackstone
setblock 127 256 550 minecraft:smooth_basalt
fill 127 256 551 127 259 551 minecraft:blackstone
setblock 128 256 513 minecraft:blackstone
fill 128 256 550 128 259 550 minecraft:blackstone
setblock 129 256 513 minecraft:smooth_basalt
setblock 130 256 512 minecraft:smooth_basalt
fill 130 256 513 130 258 513 minecraft:blackstone
setblock 131 256 511 minecraft:smooth_basalt
fill 131 256 512 131 259 512 minecraft:blackstone
setblock 131 256 551 minecraft:smooth_basalt
fill 132 256 511 132 259 511 minecraft:blackstone
fill 132 256 551 132 259 551 minecraft:blackstone
setblock 134 256 513 minecraft:smooth_basalt
fill 134 256 550 134 257 550 minecraft:blackstone
setblock 135 256 512 minecraft:smooth_basalt
fill 135 256 513 135 259 513 minecraft:blackstone
fill 135 256 515 135 257 515 minecraft:blackstone
setblock 135 256 532 minecraft:smooth_basalt
fill 135 256 533 135 256 536 minecraft:blackstone
setblock 135 256 537 minecraft:smooth_basalt
fill 135 256 538 135 259 538 minecraft:blackstone
setblock 135 256 547 minecraft:smooth_basalt
fill 135 256 548 135 259 548 minecraft:blackstone
setblock 95 257 511 minecraft:smooth_basalt
fill 95 257 512 95 260 512 minecraft:blackstone
fill 95 257 514 95 257 515 minecraft:blackstone
fill 95 257 529 95 257 530 minecraft:blackstone
setblock 95 257 531 minecraft:smooth_basalt
fill 95 257 532 95 260 532 minecraft:blackstone
setblock 95 257 535 minecraft:blackstone
setblock 95 257 536 minecraft:smooth_basalt
fill 95 257 537 95 260 537 minecraft:blackstone
setblock 95 257 541 minecraft:smooth_basalt
fill 95 257 542 95 260 542 minecraft:blackstone
fill 95 257 544 95 257 545 minecraft:blackstone
setblock 95 257 546 minecraft:smooth_basalt
fill 95 257 547 95 260 547 minecraft:blackstone
setblock 95 257 551 minecraft:smooth_basalt
fill 96 257 511 96 260 511 minecraft:blackstone
setblock 96 257 530 minecraft:smooth_basalt
fill 96 257 531 97 259 531 minecraft:blackstone
setblock 96 257 535 minecraft:smooth_basalt
fill 96 257 536 96 260 536 minecraft:blackstone
setblock 96 257 540 minecraft:smooth_basalt
fill 96 257 541 96 260 541 minecraft:blackstone
fill 96 257 551 96 260 551 minecraft:blackstone
fill 97 257 512 98 257 512 minecraft:blackstone
setblock 97 257 533 minecraft:blackstone
setblock 97 257 534 minecraft:smooth_basalt
fill 97 257 535 98 259 535 minecraft:blackstone
setblock 97 257 538 minecraft:blackstone
setblock 97 257 539 minecraft:smooth_basalt
fill 97 257 550 97 258 550 minecraft:blackstone
setblock 98 257 533 minecraft:smooth_basalt
fill 98 257 534 98 260 534 minecraft:blackstone
fill 98 257 536 98 257 537 minecraft:blackstone
setblock 99 257 512 minecraft:smooth_basalt
setblock 100 257 511 minecraft:smooth_basalt
fill 100 257 512 100 260 512 minecraft:blackstone
setblock 100 257 551 minecraft:smooth_basalt
fill 101 257 511 101 260 511 minecraft:blackstone
fill 101 257 513 102 257 513 minecraft:blackstone
setblock 101 257 550 minecraft:smooth_basalt
fill 101 257 551 101 260 551 minecraft:blackstone
fill 102 257 550 102 259 550 minecraft:blackstone
setblock 103 257 512 minecraft:blackstone
setblock 103 257 513 minecraft:smooth_basalt
setblock 104 257 512 minecraft:smooth_basalt
fill 104 257 513 105 259 513 minecraft:blackstone
setblock 105 257 511 minecraft:smooth_basalt
fill 105 257 512 105 260 512 minecraft:blackstone
setblock 105 257 551 minecraft:smooth_basalt
fill 106 257 511 106 260 511 minecraft:blackstone
fill 106 257 551 106 258 551 minecraft:blackstone
setblock 109 257 512 minecraft:smooth_basalt
setblock 110 257 511 minecraft:smooth_basalt
fill 110 257 512 110 258 512 minecraft:blackstone
fill 111 257 511 111 260 511 minecraft:blackstone
setblock 113 257 512 minecraft:blackstone
setblock 114 257 511 minecraft:blackstone
setblock 114 257 512 minecraft:smooth_basalt
setblock 115 257 511 minecraft:smooth_basalt
fill 115 257 512 115 260 512 minecraft:blackstone
fill 116 257 511 116 260 511 minecraft:blackstone
fill 116 257 513 117 257 513 minecraft:blackstone
fill 116 257 551 116 260 551 minecraft:blackstone
setblock 118 257 513 minecraft:smooth_basalt
fill 118 257 514 119 259 514 minecraft:blackstone
setblock 119 257 512 minecraft:smooth_basalt
fill 119 257 513 119 260 513 minecraft:blackstone
setblock 120 257 511 minecraft:smooth_basalt
fill 120 257 512 120 260 512 minecraft:blackstone
setblock 120 257 551 minecraft:smooth_basalt
fill 121 257 511 121 260 511 minecraft:blackstone
setblock 121 257 550 minecraft:smooth_basalt
fill 121 257 551 121 260 551 minecraft:blackstone
setblock 122 257 514 minecraft:smooth_basalt
fill 122 257 550 122 260 550 minecraft:blackstone
setblock 123 257 513 minecraft:smooth_basalt
fill 123 257 514 123 260 514 minecraft:blackstone
setblock 124 257 512 minecraft:smooth_basalt
fill 124 257 513 124 260 513 minecraft:blackstone
setblock 125 257 511 minecraft:smooth_basalt
fill 125 257 512 125 260 512 minecraft:blackstone
setblock 125 257 551 minecraft:smooth_basalt
fill 126 257 511 126 260 511 minecraft:blackstone
setblock 126 257 550 minecraft:smooth_basalt
fill 126 257 551 126 260 551 minecraft:blackstone
setblock 127 257 514 minecraft:smooth_basalt
fill 127 257 550 127 259 550 minecraft:blackstone
setblock 128 257 513 minecraft:smooth_basalt
setblock 129 257 512 minecraft:smooth_basalt
fill 129 257 513 129 259 513 minecraft:blackstone
setblock 130 257 511 minecraft:smooth_basalt
fill 130 257 512 130 260 512 minecraft:blackstone
setblock 130 257 551 minecraft:smooth_basalt
fill 131 257 511 131 260 511 minecraft:blackstone
fill 131 257 551 131 260 551 minecraft:blackstone
setblock 134 257 512 minecraft:smooth_basalt
fill 134 257 513 134 259 514 minecraft:blackstone
setblock 135 257 511 minecraft:smooth_basalt
fill 135 257 512 135 260 512 minecraft:blackstone
setblock 135 257 516 minecraft:smooth_basalt
setblock 135 257 531 minecraft:smooth_basalt
fill 135 257 532 135 257 535 minecraft:blackstone
setblock 135 257 536 minecraft:smooth_basalt
fill 135 257 537 135 260 537 minecraft:blackstone
fill 135 257 539 135 257 540 minecraft:blackstone
setblock 135 257 541 minecraft:smooth_basalt
fill 135 257 542 135 260 542 minecraft:blackstone
setblock 135 257 546 minecraft:smooth_basalt
fill 135 257 547 135 260 547 minecraft:blackstone
setblock 135 257 551 minecraft:smooth_basalt
fill 95 258 511 95 261 511 minecraft:blackstone
setblock 95 258 514 minecraft:blackstone
setblock 95 258 515 minecraft:smooth_basalt
fill 95 258 516 95 261 516 minecraft:blackstone
fill 95 258 528 95 258 529 minecraft:blackstone
setblock 95 258 530 minecraft:smooth_basalt
fill 95 258 531 95 261 531 minecraft:blackstone
setblock 95 258 534 minecraft:blackstone
setblock 95 258 535 minecraft:smooth_basalt
fill 95 258 536 95 261 536 minecraft:blackstone
setblock 95 258 539 minecraft:blackstone
setblock 95 258 540 minecraft:smooth_basalt
fill 95 258 541 95 261 541 minecraft:blackstone
setblock 95 258 544 minecraft:blackstone
setblock 95 258 545 minecraft:smooth_basalt
fill 95 258 546 95 261 546 minecraft:blackstone
setblock 95 258 550 minecraft:smooth_basalt
fill 95 258 551 95 261 551 minecraft:blackstone
fill 96 258 530 96 261 530 minecraft:blackstone
setblock 96 258 534 minecraft:smooth_basalt
fill 96 258 535 96 261 535 minecraft:blackstone
setblock 96 258 539 minecraft:smooth_basalt
fill 96 258 540 97 260 540 minecraft:blackstone
fill 96 258 542 96 258 543 minecraft:blackstone
setblock 97 258 512 minecraft:blackstone
setblock 97 258 533 minecraft:smooth_basalt
fill 97 258 534 97 261 534 minecraft:blackstone
setblock 97 258 538 minecraft:smooth_basalt
fill 97 258 539 97 261 539 minecraft:blackstone
setblock 98 258 512 minecraft:smooth_basalt
setblock 98 258 532 minecraft:smooth_basalt
fill 98 258 533 98 261 533 minecraft:blackstone
setblock 98 258 536 minecraft:blackstone
setblock 98 258 537 minecraft:smooth_basalt
fill 98 258 538 98 261 538 minecraft:blackstone
setblock 99 258 511 minecraft:smooth_basalt
fill 99 258 512 99 261 512 minecraft:blackstone
setblock 99 258 535 minecraft:blackstone
setblock 99 258 551 minecraft:smooth_basalt
fill 100 258 511 100 261 511 minecraft:blackstone
fill 100 258 513 101 258 513 minecraft:blackstone
setblock 100 258 550 minecraft:smooth_basalt
fill 100 258 551 100 261 551 minecraft:blackstone
fill 101 258 550 101 259 550 minecraft:blackstone
setblock 102 258 513 minecraft:smooth_basalt
setblock 103 258 512 minecraft:smooth_basalt
fill 103 258 513 103 260 513 minecraft:blackstone
setblock 104 258 511 minecraft:smooth_basalt
fill 104 258 512 104 261 512 minecraft:blackstone
setblock 104 258 551 minecraft:smooth_basalt
fill 105 258 511 105 261 511 minecraft:blackstone
fill 105 258 551 105 259 551 minecraft:blackstone
setblock 107 258 512 minecraft:blackstone
setblock 108 258 512 minecraft:smooth_basalt
setblock 109 258 511 minecraft:smooth_basalt
fill 109 258 512 109 259 512 minecraft:blackstone
fill 110 258 511 110 261 511 minecraft:blackstone
fill 111 258 512 112 258 512 minecraft:blackstone
setblock 113 258 512 minecraft:smooth_basalt
setblock 114 258 511 minecraft:smooth_basalt
fill 114 258 512 114 261 512 minecraft:blackstone
fill 115 258 511 115 261 511 minecraft:blackstone
fill 115 258 513 116 258 513 minecraft:blackstone
setblock 117 258 513 minecraft:smooth_basalt
fill 117 258 514 117 261 514 minecraft:blackstone
setblock 118 258 512 minecraft:smooth_basalt
fill 118 258 513 118 261 513 minecraft:blackstone
setblock 119 258 511 minecraft:smooth_basalt
fill 119 258 512 119 261 512 minecraft:blackstone
setblock 119 258 550 minecraft:blackstone
setblock 119 258 551 minecraft:smooth_basalt
fill 120 258 511 120 261 511 minecraft:blackstone
setblock 120 258 515 minecraft:smooth_basalt
setblock 120 258 550 minecraft:smooth_basalt
fill 120 258 551 120 261 551 minecraft:blackstone
setblock 121 258 513 minecraft:blackstone
setblock 121 258 514 minecraft:smooth_basalt
fill 121 258 515 123 259 515 minecraft:blackstone
fill 121 258 550 121 261 550 minecraft:blackstone
setblock 122 258 513 minecraft:smooth_basalt
fill 122 258 514 122 261 514 minecraft:blackstone
setblock 123 258 512 minecraft:smooth_basalt
fill 123 258 513 123 261 513 minecraft:blackstone
setblock 124 258 511 minecraft:smooth_basalt
fill 124 258 512 124 261 512 minecraft:blackstone
setblock 124 258 551 minecraft:smooth_basalt
fill 125 258 511 125 261 511 minecraft:blackstone
setblock 125 258 514 minecraft:blackstone
setblock 125 258 550 minecraft:smooth_basalt
fill 125 258 551 125 261 551 minecraft:blackstone
setblock 126 258 514 minecraft:smooth_basalt
fill 126 258 550 126 260 550 minecraft:blackstone
setblock 127 258 513 minecraft:smooth_basalt
setblock 127 258 514 minecraft:blackstone
setblock 128 258 512 minecraft:smooth_basalt
fill 128 258 513 128 260 513 minecraft:blackstone
setblock 129 258 511 minecraft:smooth_basalt
fill 129 258 512 129 261 512 minecraft:blackstone
setblock 129 258 551 minecraft:smooth_basalt
fill 130 258 511 130 261 511 minecraft:blackstone
fill 130 258 551 130 261 551 minecraft:blackstone
setblock 133 258 512 minecraft:smooth_basalt
setblock 134 258 511 minecraft:smooth_basalt
fill 134 258 512 134 260 512 minecraft:blackstone
setblock 134 258 551 minecraft:smooth_basalt
fill 135 258 511 135 261 511 minecraft:blackstone
setblock 135 258 515 minecraft:smooth_basalt
fill 135 258 516 135 260 517 minecraft:blackstone
fill 135 258 531 135 258 534 minecraft:blackstone
setblock 135 258 535 minecraft:smooth_basalt
fill 135 258 536 135 261 536 minecraft:blackstone
setblock 135 258 539 minecraft:blackstone
setblock 135 258 540 minecraft:smooth_basalt
fill 135 258 541 135 261 541 minecraft:blackstone
fill 135 258 543 135 258 544 minecraft:blackstone
setblock 135 258 545 minecraft:smooth_basalt
fill 135 258 546 135 261 546 minecraft:blackstone
setblock 135 258 550 minecraft:smooth_basalt
fill 135 258 551 135 261 551 minecraft:blackstone
setblock 95 259 514 minecraft:smooth_basalt
fill 95 259 515 95 262 515 minecraft:blackstone
fill 95 259 517 95 259 518 minecraft:blackstone
setblock 95 259 528 minecraft:blackstone
setblock 95 259 529 minecraft:smooth_basalt
fill 95 259 530 95 262 530 minecraft:blackstone
setblock 95 259 534 minecraft:smooth_basalt
fill 95 259 535 95 262 535 minecraft:blackstone
setblock 95 259 538 minecraft:blackstone
setblock 95 259 539 minecraft:smooth_basalt
fill 95 259 540 95 262 540 minecraft:blackstone
setblock 95 259 544 minecraft:smooth_basalt
fill 95 259 545 95 262 545 minecraft:blackstone
setblock 95 259 549 minecraft:smooth_basalt
fill 95 259 550 95 261 550 minecraft:blackstone
setblock 96 259 513 minecraft:smooth_basalt
fill 96 259 514 96 261 514 minecraft:blackstone
fill 96 259 529 96 260 529 minecraft:blackstone
setblock 96 259 532 minecraft:blackstone
setblock 96 259 533 minecraft:smooth_basalt
fill 96 259 534 96 262 534 minecraft:blackstone
setblock 96 259 537 minecraft:blackstone
setblock 96 259 538 minecraft:smooth_basalt
fill 96 259 539 96 262 539 minecraft:blackstone
setblock 96 259 542 minecraft:blackstone
setblock 96 259 543 minecraft:smooth_basalt
fill 96 259 544 96 262 544 minecraft:blackstone
setblock 97 259 512 minecraft:smooth_basalt
setblock 97 259 532 minecraft:smooth_basalt
fill 97 259 533 97 262 533 minecraft:blackstone
setblock 97 259 537 minecraft:smooth_basalt
fill 97 259 538 97 262 538 minecraft:blackstone
setblock 97 259 541 minecraft:blackstone
setblock 98 259 511 minecraft:smooth_basalt
fill 98 259 512 98 262 512 minecraft:blackstone
fill 98 259 532 98 260 532 minecraft:blackstone
setblock 98 259 536 minecraft:smooth_basalt
fill 98 259 537 99 261 537 minecraft:blackstone
fill 98 259 539 98 260 539 minecraft:blackstone
setblock 98 259 551 minecraft:smooth_basalt
fill 99 259 511 99 262 511 minecraft:blackstone
setblock 99 259 534 minecraft:blackstone
setblock 99 259 535 minecraft:smooth_basalt
fill 99 259 536 99 261 536 minecraft:blackstone
setblock 99 259 550 minecraft:smooth_basalt
fill 99 259 551 99 262 551 minecraft:blackstone
setblock 100 259 513 minecraft:blackstone
setblock 100 259 550 minecraft:blackstone
setblock 101 259 513 minecraft:smooth_basalt
setblock 102 259 512 minecraft:smooth_basalt
fill 102 259 513 102 260 513 minecraft:blackstone
setblock 103 259 511 minecraft:smooth_basalt
fill 103 259 512 103 261 512 minecraft:blackstone
setblock 103 259 551 minecraft:smooth_basalt
fill 104 259 511 104 262 511 minecraft:blackstone
fill 104 259 551 104 260 551 minecraft:blackstone
setblock 107 259 512 minecraft:smooth_basalt
setblock 108 259 511 minecraft:smooth_basalt
setblock 108 259 512 minecraft:blackstone
fill 109 259 511 109 261 511 minecraft:blackstone
setblock 111 259 512 minecraft:blackstone
setblock 112 259 512 minecraft:smooth_basalt
setblock 113 259 511 minecraft:smooth_basalt
fill 113 259 512 113 262 512 minecraft:blackstone
fill 114 259 511 114 262 511 minecraft:blackstone
fill 114 259 513 115 259 513 minecraft:blackstone
setblock 116 259 513 minecraft:smooth_basalt
setblock 117 259 512 minecraft:smooth_basalt
fill 117 259 513 117 262 513 minecraft:blackstone
setblock 118 259 511 minecraft:smooth_basalt
fill 118 259 512 118 262 512 minecraft:blackstone
setblock 118 259 551 minecraft:smooth_basalt
fill 119 259 511 119 262 511 minecraft:blackstone
setblock 119 259 515 minecraft:smooth_basalt
setblock 119 259 550 minecraft:smooth_basalt
fill 119 259 551 119 262 551 minecraft:blackstone
setblock 120 259 513 minecraft:blackstone
setblock 120 259 514 minecraft:smooth_basalt
fill 120 259 515 120 261 515 minecraft:blackstone
fill 120 259 550 120 261 550 minecraft:blackstone
setblock 121 259 513 minecraft:smooth_basalt
fill 121 259 514 121 262 514 minecraft:blackstone
setblock 122 259 512 minecraft:smooth_basalt
fill 122 259 513 122 262 513 minecraft:blackstone
setblock 123 259 511 minecraft:smooth_basalt
fill 123 259 512 123 262 512 minecraft:blackstone
setblock 123 259 551 minecraft:smooth_basalt
fill 124 259 511 124 262 511 minecraft:blackstone
setblock 124 259 550 minecraft:smooth_basalt
fill 124 259 551 124 262 551 minecraft:blackstone
setblock 125 259 514 minecraft:smooth_basalt
fill 125 259 550 125 260 550 minecraft:blackstone
setblock 126 259 513 minecraft:smooth_basalt
setblock 126 259 514 minecraft:blackstone
setblock 127 259 512 minecraft:smooth_basalt
fill 127 259 513 127 261 513 minecraft:blackstone
setblock 128 259 511 minecraft:smooth_basalt
fill 128 259 512 128 261 512 minecraft:blackstone
setblock 128 259 551 minecraft:smooth_basalt
fill 129 259 511 129 262 511 minecraft:blackstone
fill 129 259 551 129 261 551 minecraft:blackstone
setblock 132 259 512 minecraft:smooth_basalt
setblock 133 259 511 minecraft:smooth_basalt
fill 133 259 512 133 260 512 minecraft:blackstone
setblock 133 259 551 minecraft:smooth_basalt
fill 134 259 511 134 262 511 minecraft:blackstone
setblock 134 259 515 minecraft:smooth_basalt
setblock 134 259 535 minecraft:smooth_basalt
fill 134 259 536 134 259 539 minecraft:blackstone
fill 134 259 551 134 262 551 minecraft:blackstone
setblock 135 259 514 minecraft:smooth_basalt
fill 135 259 515 135 262 515 minecraft:blackstone
setblock 135 259 518 minecraft:blackstone
fill 135 259 531 135 259 533 minecraft:blackstone
setblock 135 259 534 minecraft:smooth_basalt
fill 135 259 535 135 262 535 minecraft:blackstone
setblock 135 259 539 minecraft:smooth_basalt
fill 135 259 540 135 262 540 minecraft:blackstone
setblock 135 259 543 minecraft:blackstone
setblock 135 259 544 minecraft:smooth_basalt
fill 135 259 545 135 262 545 minecraft:blackstone
setblock 135 259 549 minecraft:smooth_basalt
fill 135 259 550 135 262 550 minecraft:blackstone
setblock 95 260 513 minecraft:smooth_basalt
fill 95 260 514 95 263 514 minecraft:blackstone
setblock 95 260 517 minecraft:blackstone
setblock 95 260 518 minecraft:smooth_basalt
fill 95 260 519 95 263 519 minecraft:blackstone
setblock 95 260 528 minecraft:smooth_basalt
fill 95 260 529 95 263 529 minecraft:blackstone
setblock 95 260 533 minecraft:smooth_basalt
fill 95 260 534 95 263 534 minecraft:blackstone
setblock 95 260 538 minecraft:smooth_basalt
fill 95 260 539 95 263 539 minecraft:blackstone
setblock 95 260 543 minecraft:smooth_basalt
fill 95 260 544 95 263 544 minecraft:blackstone
setblock 95 260 548 minecraft:smooth_basalt
fill 95 260 549 95 261 549 minecraft:blackstone
setblock 96 260 513 minecraft:blackstone
fill 96 260 515 96 260 516 minecraft:blackstone
setblock 96 260 531 minecraft:blackstone
setblock 96 260 532 minecraft:smooth_basalt
fill 96 260 533 96 263 533 minecraft:blackstone
setblock 96 260 537 minecraft:smooth_basalt
fill 96 260 538 96 263 538 minecraft:blackstone
setblock 96 260 542 minecraft:smooth_basalt
fill 96 260 543 96 263 543 minecraft:blackstone
setblock 97 260 511 minecraft:smooth_basalt
fill 97 260 512 97 261 512 minecraft:blackstone
setblock 97 260 531 minecraft:smooth_basalt
fill 97 260 532 97 263 532 minecraft:blackstone
setblock 97 260 535 minecraft:blackstone
setblock 97 260 536 minecraft:smooth_basalt
fill 97 260 537 97 263 537 minecraft:blackstone
setblock 97 260 541 minecraft:smooth_basalt
fill 97 260 542 97 263 542 minecraft:blackstone
setblock 97 260 551 minecraft:smooth_basalt
fill 98 260 511 98 263 511 minecraft:blackstone
setblock 98 260 535 minecraft:smooth_basalt
fill 98 260 536 98 263 536 minecraft:blackstone
setblock 98 260 540 minecraft:smooth_basalt
fill 98 260 551 98 262 551 minecraft:blackstone
setblock 99 260 535 minecraft:blackstone
setblock 100 260 513 minecraft:smooth_basalt
setblock 101 260 512 minecraft:smooth_basalt
setblock 101 260 513 minecraft:blackstone
setblock 102 260 511 minecraft:smooth_basalt
fill 102 260 512 102 262 512 minecraft:blackstone
setblock 102 260 551 minecraft:smooth_basalt
fill 103 260 511 103 262 511 minecraft:blackstone
fill 103 260 521 105 261 521 minecraft:gilded_blackstone
setblock 103 260 551 minecraft:blackstone
fill 104 260 520 104 261 520 minecraft:gilded_blackstone
fill 104 260 522 104 261 522 minecraft:gilded_blackstone
setblock 106 260 512 minecraft:smooth_basalt
setblock 107 260 511 minecraft:smooth_basalt
setblock 107 260 512 minecraft:blackstone
fill 108 260 511 108 261 511 minecraft:blackstone
setblock 112 260 511 minecraft:smooth_basalt
setblock 112 260 512 minecraft:blackstone
fill 113 260 511 113 263 511 minecraft:blackstone
setblock 114 260 513 minecraft:blackstone
setblock 115 260 513 minecraft:smooth_basalt
setblock 116 260 512 minecraft:smooth_basalt
fill 116 260 513 116 262 514 minecraft:blackstone
setblock 117 260 511 minecraft:smooth_basalt
fill 117 260 512 117 263 512 minecraft:blackstone
setblock 117 260 551 minecraft:smooth_basalt
fill 118 260 511 118 263 511 minecraft:blackstone
setblock 118 260 514 minecraft:blackstone
fill 118 260 551 118 263 551 minecraft:blackstone
setblock 119 260 514 minecraft:smooth_basalt
fill 119 260 515 119 261 515 minecraft:blackstone
setblock 119 260 550 minecraft:blackstone
setblock 120 260 513 minecraft:smooth_basalt
fill 120 260 514 120 263 514 minecraft:blackstone
setblock 121 260 512 minecraft:smooth_basalt
fill 121 260 513 121 263 513 minecraft:blackstone
fill 121 260 515 122 260 515 minecraft:blackstone
setblock 122 260 511 minecraft:smooth_basalt
fill 122 260 512 122 263 512 minecraft:blackstone
setblock 122 260 551 minecraft:smooth_basalt
fill 123 260 511 123 263 511 minecraft:blackstone
setblock 123 260 515 minecraft:smooth_basalt
fill 123 260 520 123 261 522 minecraft:gold_block
setblock 123 260 550 minecraft:smooth_basalt
fill 123 260 551 123 263 551 minecraft:blackstone
setblock 124 260 514 minecraft:smooth_basalt
fill 124 260 521 124 261 521 minecraft:gold_block
fill 124 260 550 124 261 550 minecraft:blackstone
setblock 125 260 513 minecraft:smooth_basalt
setblock 125 260 514 minecraft:blackstone
setblock 126 260 512 minecraft:smooth_basalt
fill 126 260 513 126 261 513 minecraft:blackstone
setblock 127 260 511 minecraft:smooth_basalt
fill 127 260 512 127 262 512 minecraft:blackstone
setblock 127 260 551 minecraft:smooth_basalt
fill 128 260 511 128 263 511 minecraft:blackstone
fill 128 260 551 128 262 551 minecraft:blackstone
setblock 131 260 512 minecraft:smooth_basalt
setblock 132 260 511 minecraft:smooth_basalt
setblock 132 260 512 minecraft:blackstone
setblock 132 260 551 minecraft:smooth_basalt
fill 133 260 511 133 262 511 minecraft:blackstone
fill 133 260 551 133 262 551 minecraft:blackstone
setblock 134 260 513 minecraft:blackstone
setblock 134 260 514 minecraft:smooth_basalt
setblock 134 260 515 minecraft:blackstone
fill 134 260 535 134 260 538 minecraft:blackstone
setblock 134 260 539 minecraft:smooth_basalt
fill 134 260 540 134 262 541 minecraft:blackstone
setblock 135 260 513 minecraft:smooth_basalt
fill 135 260 514 135 263 514 minecraft:blackstone
setblock 135 260 518 minecraft:smooth_basalt
fill 135 260 519 135 263 519 minecraft:blackstone
fill 135 260 531 135 260 532 minecraft:blackstone
setblock 135 260 533 minecraft:smooth_basalt
fill 135 260 534 135 263 534 minecraft:blackstone
setblock 135 260 538 minecraft:smooth_basalt
fill 135 260 539 135 263 539 minecraft:blackstone
setblock 135 260 543 minecraft:smooth_basalt
fill 135 260 544 135 263 544 minecraft:blackstone
setblock 135 260 548 minecraft:smooth_basalt
fill 135 260 549 135 263 549 minecraft:blackstone
setblock 95 261 512 minecraft:smooth_basalt
fill 95 261 513 95 263 513 minecraft:blackstone
setblock 95 261 517 minecraft:smooth_basalt
fill 95 261 518 96 263 518 minecraft:blackstone
fill 95 261 520 95 261 521 minecraft:blackstone
fill 95 261 528 95 264 528 minecraft:blackstone
setblock 95 261 532 minecraft:smooth_basalt
fill 95 261 533 95 264 533 minecraft:blackstone
setblock 95 261 537 minecraft:smooth_basalt
fill 95 261 538 95 264 538 minecraft:blackstone
setblock 95 261 542 minecraft:smooth_basalt
fill 95 261 543 95 264 543 minecraft:blackstone
setblock 95 261 547 minecraft:smooth_basalt
setblock 95 261 548 minecraft:blackstone
setblock 96 261 511 minecraft:smooth_basalt
setblock 96 261 515 minecraft:blackstone
setblock 96 261 516 minecraft:smooth_basalt
fill 96 261 517 96 264 517 minecraft:blackstone
setblock 96 261 531 minecraft:smooth_basalt
fill 96 261 532 96 264 532 minecraft:blackstone
setblock 96 261 536 minecraft:smooth_basalt
fill 96 261 537 96 264 537 minecraft:blackstone
setblock 96 261 540 minecraft:blackstone
setblock 96 261 541 minecraft:smooth_basalt
fill 96 261 542 96 264 542 minecraft:blackstone
setblock 96 261 545 minecraft:blackstone
setblock 96 261 551 minecraft:smooth_basalt
fill 97 261 511 97 263 511 minecraft:blackstone
setblock 97 261 513 minecraft:light[level=12]
setblock 97 261 521 minecraft:light[level=12]
setblock 97 261 529 minecraft:light[level=12]
setblock 97 261 531 minecraft:blackstone
setblock 97 261 535 minecraft:smooth_basalt
fill 97 261 536 97 264 536 minecraft:blackstone
setblock 97 261 540 minecraft:smooth_basalt
fill 97 261 541 97 264 541 minecraft:blackstone
setblock 97 261 545 minecraft:light[level=12]
fill 97 261 551 97 262 551 minecraft:blackstone
setblock 98 261 534 minecraft:smooth_basalt
fill 98 261 535 98 263 535 minecraft:blackstone
setblock 98 261 539 minecraft:smooth_basalt
fill 98 261 540 98 264 540 minecraft:blackstone
setblock 100 261 512 minecraft:smooth_basalt
setblock 101 261 511 minecraft:smooth_basalt
fill 101 261 512 101 262 512 minecraft:blackstone
setblock 101 261 551 minecraft:smooth_basalt
fill 102 261 511 102 263 511 minecraft:blackstone
setblock 102 261 551 minecraft:blackstone
setblock 105 261 512 minecraft:smooth_basalt
setblock 105 261 513 minecraft:light[level=12]
setblock 105 261 529 minecraft:light[level=12]
setblock 105 261 537 minecraft:light[level=12]
setblock 105 261 545 minecraft:light[level=12]
setblock 106 261 511 minecraft:smooth_basalt
setblock 107 261 511 minecraft:blackstone
setblock 111 261 511 minecraft:smooth_basalt
fill 112 261 511 112 263 511 minecraft:blackstone
setblock 113 261 513 minecraft:light[level=12]
setblock 113 261 521 minecraft:light[level=12]
setblock 113 261 529 minecraft:light[level=12]
setblock 113 261 537 minecraft:light[level=12]
setblock 113 261 545 minecraft:light[level=12]
setblock 114 261 513 minecraft:smooth_basalt
setblock 115 261 512 minecraft:smooth_basalt
fill 115 261 513 115 263 513 minecraft:blackstone
setblock 116 261 511 minecraft:smooth_basalt
fill 116 261 512 116 264 512 minecraft:blackstone
setblock 116 261 551 minecraft:smooth_basalt
fill 117 261 511 117 264 511 minecraft:blackstone
fill 117 261 551 117 264 551 minecraft:blackstone
setblock 118 261 514 minecraft:smooth_basalt
setblock 119 261 513 minecraft:smooth_basalt
fill 119 261 514 119 264 514 minecraft:blackstone
setblock 120 261 512 minecraft:smooth_basalt
fill 120 261 513 120 264 513 minecraft:blackstone
setblock 121 261 511 minecraft:smooth_basalt
fill 121 261 512 121 264 512 minecraft:blackstone
setblock 121 261 515 minecraft:blackstone
setblock 121 261 529 minecraft:light[level=12]
setblock 121 261 537 minecraft:light[level=12]
setblock 121 261 545 minecraft:light[level=12]
setblock 121 261 551 minecraft:smooth_basalt
fill 122 261 511 122 264 511 minecraft:blackstone
setblock 122 261 550 minecraft:smooth_basalt
fill 122 261 551 122 264 551 minecraft:blackstone
setblock 123 261 514 minecraft:smooth_basalt
setblock 123 261 550 minecraft:blackstone
setblock 124 261 513 minecraft:smooth_basalt
setblock 124 261 514 minecraft:blackstone
setblock 125 261 512 minecraft:smooth_basalt
fill 125 261 513 125 262 513 minecraft:blackstone
setblock 126 261 511 minecraft:smooth_basalt
fill 126 261 512 126 262 512 minecraft:blackstone
setblock 126 261 551 minecraft:smooth_basalt
fill 127 261 511 127 263 511 minecraft:blackstone
fill 127 261 551 127 262 551 minecraft:blackstone
setblock 129 261 513 minecraft:light[level=12]
setblock 129 261 521 minecraft:light[level=12]
setblock 129 261 529 minecraft:light[level=12]
setblock 129 261 537 minecraft:light[level=12]
setblock 129 261 545 minecraft:light[level=12]
setblock 131 261 511 minecraft:smooth_basalt
setblock 131 261 551 minecraft:smooth_basalt
fill 132 261 511 132 262 511 minecraft:blackstone
fill 132 261 551 132 262 551 minecraft:blackstone
setblock 134 261 513 minecraft:smooth_basalt
setblock 134 261 514 minecraft:blackstone
fill 134 261 535 134 261 537 minecraft:blackstone
setblock 134 261 538 minecraft:smooth_basalt
fill 134 261 539 134 264 539 minecraft:blackstone
setblock 134 261 542 minecraft:blackstone
setblock 134 261 543 minecraft:smooth_basalt
setblock 135 261 512 minecraft:smooth_basalt
fill 135 261 513 135 264 513 minecraft:blackstone
setblock 135 261 516 minecraft:blackstone
setblock 135 261 517 minecraft:smooth_basalt
fill 135 261 518 135 264 518 minecraft:blackstone
setblock 135 261 532 minecraft:smooth_basalt
fill 135 261 533 135 264 533 minecraft:blackstone
setblock 135 261 537 minecraft:smooth_basalt
fill 135 261 538 135 264 538 minecraft:blackstone
setblock 135 261 542 minecraft:smooth_basalt
fill 135 261 543 135 264 543 minecraft:blackstone
setblock 135 261 547 minecraft:smooth_basalt
fill 135 261 548 135 264 548 minecraft:blackstone
setblock 95 262 512 minecraft:blackstone
setblock 95 262 516 minecraft:smooth_basalt
fill 95 262 517 95 265 517 minecraft:blackstone
setblock 95 262 520 minecraft:blackstone
setblock 95 262 521 minecraft:smooth_basalt
fill 95 262 522 95 265 522 minecraft:blackstone
setblock 95 262 531 minecraft:smooth_basalt
fill 95 262 532 95 265 532 minecraft:blackstone
setblock 95 262 536 minecraft:smooth_basalt
fill 95 262 537 95 265 537 minecraft:blackstone
setblock 95 262 541 minecraft:smooth_basalt
fill 95 262 542 95 265 542 minecraft:blackstone
setblock 95 262 546 minecraft:smooth_basalt
fill 95 262 547 95 265 547 minecraft:blackstone
setblock 96 262 511 minecraft:blackstone
setblock 96 262 515 minecraft:smooth_basalt
fill 96 262 516 96 265 516 minecraft:blackstone
setblock 96 262 519 minecraft:blackstone
setblock 96 262 530 minecraft:smooth_basalt
fill 96 262 531 96 265 531 minecraft:blackstone
setblock 96 262 535 minecraft:smooth_basalt
fill 96 262 536 96 265 536 minecraft:blackstone
setblock 96 262 540 minecraft:smooth_basalt
fill 96 262 541 96 265 541 minecraft:blackstone
setblock 96 262 545 minecraft:smooth_basalt
setblock 96 262 551 minecraft:blackstone
setblock 97 262 534 minecraft:smooth_basalt
fill 97 262 535 97 265 535 minecraft:blackstone
setblock 97 262 539 minecraft:smooth_basalt
fill 97 262 540 97 265 540 minecraft:blackstone
setblock 97 262 543 minecraft:blackstone
setblock 98 262 534 minecraft:blackstone
setblock 98 262 537 minecraft:blackstone
setblock 98 262 538 minecraft:smooth_basalt
fill 98 262 539 98 265 539 minecraft:blackstone
setblock 99 262 512 minecraft:smooth_basalt
setblock 100 262 511 minecraft:smooth_basalt
setblock 100 262 512 minecraft:blackstone
setblock 100 262 551 minecraft:smooth_basalt
fill 101 262 511 101 263 511 minecraft:blackstone
setblock 105 262 511 minecraft:smooth_basalt
setblock 114 262 512 minecraft:smooth_basalt
setblock 115 262 511 minecraft:smooth_basalt
fill 115 262 512 115 265 512 minecraft:blackstone
fill 116 262 511 116 265 511 minecraft:blackstone
setblock 117 262 514 minecraft:smooth_basalt
setblock 118 262 513 minecraft:smooth_basalt
fill 118 262 514 118 264 514 minecraft:blackstone
setblock 119 262 512 minecraft:smooth_basalt
fill 119 262 513 119 265 513 minecraft:blackstone
setblock 120 262 511 minecraft:smooth_basalt
fill 120 262 512 120 265 512 minecraft:blackstone
setblock 120 262 551 minecraft:smooth_basalt
fill 121 262 511 121 265 511 minecraft:blackstone
fill 121 262 551 121 265 551 minecraft:blackstone
setblock 122 262 514 minecraft:smooth_basalt
setblock 123 262 513 minecraft:smooth_basalt
setblock 123 262 514 minecraft:blackstone
setblock 124 262 512 minecraft:smooth_basalt
fill 124 262 513 124 263 513 minecraft:blackstone
setblock 125 262 511 minecraft:smooth_basalt
fill 125 262 512 125 263 512 minecraft:blackstone
setblock 125 262 551 minecraft:smooth_basalt
fill 126 262 511 126 264 511 minecraft:blackstone
setblock 126 262 551 minecraft:blackstone
setblock 130 262 511 minecraft:smooth_basalt
setblock 131 262 511 minecraft:blackstone
fill 134 262 535 134 262 536 minecraft:blackstone
setblock 134 262 537 minecraft:smooth_basalt
fill 134 262 538 134 265 538 minecraft:blackstone
setblock 134 262 542 minecraft:smooth_basalt
fill 134 262 543 134 265 543 minecraft:blackstone
setblock 135 262 511 minecraft:smooth_basalt
fill 135 262 512 135 264 512 minecraft:blackstone
setblock 135 262 516 minecraft:smooth_basalt
fill 135 262 517 135 265 517 minecraft:blackstone
fill 135 262 532 135 263 532 minecraft:blackstone
setblock 135 262 536 minecraft:smooth_basalt
fill 135 262 537 135 265 537 minecraft:blackstone
setblock 135 262 541 minecraft:smooth_basalt
fill 135 262 542 135 265 542 minecraft:blackstone
setblock 135 262 546 minecraft:smooth_basalt
fill 135 262 547 135 265 547 minecraft:blackstone
setblock 135 262 551 minecraft:smooth_basalt
setblock 95 263 515 minecraft:smooth_basalt
fill 95 263 516 95 266 516 minecraft:blackstone
setblock 95 263 520 minecraft:smooth_basalt
fill 95 263 521 95 266 521 minecraft:blackstone
fill 95 263 523 95 263 524 minecraft:blackstone
setblock 95 263 530 minecraft:smooth_basalt
fill 95 263 531 95 266 531 minecraft:blackstone
setblock 95 263 535 minecraft:smooth_basalt
fill 95 263 536 95 266 536 minecraft:blackstone
setblock 95 263 540 minecraft:smooth_basalt
fill 95 263 541 95 266 541 minecraft:blackstone
setblock 95 263 545 minecraft:smooth_basalt
fill 95 263 546 95 266 546 minecraft:blackstone
setblock 96 263 515 minecraft:blackstone
setblock 96 263 519 minecraft:smooth_basalt
fill 96 263 520 96 266 520 minecraft:blackstone
setblock 96 263 530 minecraft:blackstone
setblock 96 263 534 minecraft:smooth_basalt
fill 96 263 535 96 266 535 minecraft:blackstone
setblock 96 263 539 minecraft:smooth_basalt
fill 96 263 540 96 266 540 minecraft:blackstone
setblock 96 263 544 minecraft:smooth_basalt
fill 96 263 545 96 266 545 minecraft:blackstone
setblock 97 263 533 minecraft:smooth_basalt
fill 97 263 534 97 265 534 minecraft:blackstone
setblock 97 263 538 minecraft:smooth_basalt
fill 97 263 539 97 266 539 minecraft:blackstone
setblock 97 263 543 minecraft:smooth_basalt
setblock 98 263 537 minecraft:smooth_basalt
fill 98 263 538 98 265 538 minecraft:blackstone
setblock 99 263 511 minecraft:smooth_basalt
setblock 100 263 511 minecraft:blackstone
setblock 114 263 511 minecraft:smooth_basalt
fill 114 263 512 114 266 512 minecraft:blackstone
fill 115 263 511 115 266 511 minecraft:blackstone
setblock 116 263 513 minecraft:blackstone
setblock 117 263 513 minecraft:smooth_basalt
setblock 117 263 514 minecraft:blackstone
setblock 118 263 512 minecraft:smooth_basalt
fill 118 263 513 118 266 513 minecraft:blackstone
setblock 119 263 511 minecraft:smooth_basalt
fill 119 263 512 119 266 512 minecraft:blackstone
setblock 119 263 551 minecraft:smooth_basalt
fill 120 263 511 120 266 511 minecraft:blackstone
fill 120 263 551 120 266 551 minecraft:blackstone
setblock 121 263 514 minecraft:smooth_basalt
setblock 122 263 513 minecraft:smooth_basalt
setblock 123 263 512 minecraft:smooth_basalt
setblock 123 263 513 minecraft:blackstone
setblock 124 263 511 minecraft:smooth_basalt
fill 124 263 512 124 264 512 minecraft:blackstone
setblock 124 263 551 minecraft:smooth_basalt
fill 125 263 511 125 264 511 minecraft:blackstone
setblock 125 263 551 minecraft:blackstone
setblock 134 263 511 minecraft:smooth_basalt
setblock 134 263 536 minecraft:smooth_basalt
fill 134 263 537 134 266 537 minecraft:blackstone
setblock 134 263 540 minecraft:blackstone
setblock 134 263 541 minecraft:smooth_basalt
fill 134 263 542 134 266 542 minecraft:blackstone
fill 134 263 544 134 264 544 minecraft:blackstone
setblock 134 263 551 minecraft:smooth_basalt
setblock 135 263 511 minecraft:blackstone
setblock 135 263 515 minecraft:smooth_basalt
fill 135 263 516 135 266 516 minecraft:blackstone
setblock 135 263 520 minecraft:smooth_basalt
setblock 135 263 535 minecraft:smooth_basalt
fill 135 263 536 135 266 536 minecraft:blackstone
setblock 135 263 540 minecraft:smooth_basalt
fill 135 263 541 135 266 541 minecraft:blackstone
setblock 135 263 545 minecraft:smooth_basalt
fill 135 263 546 135 266 546 minecraft:blackstone
setblock 135 263 550 minecraft:smooth_basalt
fill 135 263 551 135 266 551 minecraft:blackstone
setblock 95 264 514 minecraft:smooth_basalt
fill 95 264 515 95 267 515 minecraft:blackstone
setblock 95 264 518 minecraft:blackstone
setblock 95 264 519 minecraft:smooth_basalt
fill 95 264 520 95 267 520 minecraft:blackstone
setblock 95 264 523 minecraft:blackstone
setblock 95 264 524 minecraft:smooth_basalt
fill 95 264 525 95 265 527 minecraft:blackstone
setblock 95 264 529 minecraft:smooth_basalt
fill 95 264 530 95 267 530 minecraft:blackstone
setblock 95 264 534 minecraft:smooth_basalt
fill 95 264 535 95 267 535 minecraft:blackstone
setblock 95 264 539 minecraft:smooth_basalt
fill 95 264 540 95 267 540 minecraft:blackstone
setblock 95 264 544 minecraft:smooth_basalt
fill 95 264 545 95 267 545 minecraft:blackstone
setblock 96 264 518 minecraft:smooth_basalt
fill 96 264 519 96 267 519 minecraft:blackstone
fill 96 264 521 96 264 522 minecraft:blackstone
setblock 96 264 533 minecraft:smooth_basalt
fill 96 264 534 96 267 534 minecraft:blackstone
setblock 96 264 538 minecraft:smooth_basalt
fill 96 264 539 96 267 539 minecraft:blackstone
setblock 96 264 543 minecraft:smooth_basalt
fill 96 264 544 96 267 544 minecraft:blackstone
setblock 97 264 533 minecraft:blackstone
setblock 97 264 537 minecraft:smooth_basalt
fill 97 264 538 97 267 538 minecraft:blackstone
setblock 97 264 542 minecraft:smooth_basalt
fill 97 264 543 97 267 543 minecraft:blackstone
setblock 98 264 536 minecraft:smooth_basalt
setblock 98 264 537 minecraft:blackstone
setblock 113 264 511 minecraft:smooth_basalt
fill 114 264 511 114 267 511 minecraft:blackstone
setblock 116 264 513 minecraft:smooth_basalt
setblock 117 264 512 minecraft:smooth_basalt
fill 117 264 513 117 266 513 minecraft:blackstone
setblock 118 264 511 minecraft:smooth_basalt
fill 118 264 512 118 267 512 minecraft:blackstone
setblock 118 264 551 minecraft:smooth_basalt
fill 119 264 511 119 267 511 minecraft:blackstone
fill 119 264 551 119 267 551 minecraft:blackstone
setblock 121 264 513 minecraft:smooth_basalt
setblock 122 264 512 minecraft:smooth_basalt
setblock 122 264 513 minecraft:blackstone
setblock 123 264 511 minecraft:smooth_basalt
setblock 123 264 512 minecraft:blackstone
setblock 123 264 551 minecraft:smooth_basalt
fill 124 264 511 124 265 511 minecraft:blackstone
setblock 124 264 551 minecraft:blackstone
fill 134 264 536 134 267 536 minecraft:blackstone
setblock 134 264 540 minecraft:smooth_basalt
fill 134 264 541 134 267 541 minecraft:blackstone
setblock 134 264 545 minecraft:smooth_basalt
setblock 134 264 551 minecraft:blackstone
setblock 135 264 514 minecraft:smooth_basalt
fill 135 264 515 135 267 515 minecraft:blackstone
setblock 135 264 519 minecraft:smooth_basalt
fill 135 264 520 135 266 521 minecraft:blackstone
setblock 135 264 534 minecraft:smooth_basalt
fill 135 264 535 135 267 535 minecraft:blackstone
setblock 135 264 539 minecraft:smooth_basalt
fill 135 264 540 135 267 540 minecraft:blackstone
setblock 135 264 544 minecraft:smooth_basalt
fill 135 264 545 135 267 545 minecraft:blackstone
setblock 135 264 549 minecraft:smooth_basalt
fill 135 264 550 135 267 550 minecraft:blackstone
fill 95 265 514 95 268 514 minecraft:blackstone
setblock 95 265 518 minecraft:smooth_basalt
fill 95 265 519 95 268 519 minecraft:blackstone
setblock 95 265 523 minecraft:smooth_basalt
fill 95 265 524 96 267 524 minecraft:blackstone
setblock 95 265 528 minecraft:smooth_basalt
fill 95 265 529 95 268 529 minecraft:blackstone
setblock 95 265 533 minecraft:smooth_basalt
fill 95 265 534 95 268 534 minecraft:blackstone
setblock 95 265 538 minecraft:smooth_basalt
fill 95 265 539 95 268 539 minecraft:blackstone
setblock 95 265 543 minecraft:smooth_basalt
fill 95 265 544 95 268 544 minecraft:blackstone
setblock 96 265 517 minecraft:smooth_basalt
fill 96 265 518 96 268 518 minecraft:blackstone
setblock 96 265 521 minecraft:blackstone
setblock 96 265 522 minecraft:smooth_basalt
fill 96 265 523 96 268 523 minecraft:blackstone
setblock 96 265 532 minecraft:smooth_basalt
fill 96 265 533 96 268 533 minecraft:blackstone
setblock 96 265 537 minecraft:smooth_basalt
fill 96 265 538 96 268 538 minecraft:blackstone
setblock 96 265 542 minecraft:smooth_basalt
fill 96 265 543 96 268 543 minecraft:blackstone
setblock 97 265 536 minecraft:smooth_basalt
fill 97 265 537 97 268 537 minecraft:blackstone
setblock 97 265 541 minecraft:smooth_basalt
fill 97 265 542 97 268 542 minecraft:blackstone
fill 113 265 511 113 268 511 minecraft:blackstone
setblock 116 265 512 minecraft:smooth_basalt
setblock 116 265 513 minecraft:blackstone
setblock 117 265 511 minecraft:smooth_basalt
fill 117 265 512 117 268 512 minecraft:blackstone
setblock 117 265 551 minecraft:smooth_basalt
fill 118 265 511 118 268 511 minecraft:blackstone
fill 118 265 551 118 268 551 minecraft:blackstone
setblock 120 265 513 minecraft:smooth_basalt
setblock 121 265 512 minecraft:smooth_basalt
setblock 122 265 511 minecraft:smooth_basalt
setblock 122 265 512 minecraft:blackstone
setblock 122 265 551 minecraft:smooth_basalt
fill 123 265 511 123 266 511 minecraft:blackstone
setblock 134 265 539 minecraft:smooth_basalt
fill 134 265 540 134 268 540 minecraft:blackstone
setblock 134 265 544 minecraft:smooth_basalt
fill 134 265 545 134 267 546 minecraft:blackstone
setblock 135 265 513 minecraft:smooth_basalt
fill 135 265 514 135 266 514 minecraft:blackstone
setblock 135 265 518 minecraft:smooth_basalt
fill 135 265 519 135 268 519 minecraft:blackstone
setblock 135 265 522 minecraft:blackstone
setblock 135 265 533 minecraft:smooth_basalt
fill 135 265 534 135 268 534 minecraft:blackstone
setblock 135 265 538 minecraft:smooth_basalt
fill 135 265 539 135 268 539 minecraft:blackstone
setblock 135 265 543 minecraft:smooth_basalt
fill 135 265 544 135 268 544 minecraft:blackstone
setblock 135 265 548 minecraft:smooth_basalt
fill 135 265 549 135 268 549 minecraft:blackstone
setblock 95 266 517 minecraft:smooth_basalt
fill 95 266 518 95 269 518 minecraft:blackstone
setblock 95 266 522 minecraft:smooth_basalt
fill 95 266 523 95 269 523 minecraft:blackstone
fill 95 266 525 95 266 526 minecraft:blackstone
setblock 95 266 527 minecraft:smooth_basalt
fill 95 266 528 95 269 528 minecraft:blackstone
setblock 95 266 532 minecraft:smooth_basalt
fill 95 266 533 95 269 533 minecraft:blackstone
setblock 95 266 537 minecraft:smooth_basalt
fill 95 266 538 95 269 538 minecraft:blackstone
setblock 95 266 542 minecraft:smooth_basalt
fill 95 266 543 95 269 543 minecraft:blackstone
setblock 95 266 547 minecraft:smooth_basalt
fill 95 266 548 95 269 548 minecraft:blackstone
setblock 96 266 516 minecraft:smooth_basalt
fill 96 266 517 96 269 517 minecraft:blackstone
setblock 96 266 521 minecraft:smooth_basalt
fill 96 266 522 96 269 522 minecraft:blackstone
setblock 96 266 525 minecraft:blackstone
setblock 96 266 526 minecraft:smooth_basalt
setblock 96 266 531 minecraft:smooth_basalt
fill 96 266 532 96 269 532 minecraft:blackstone
setblock 96 266 536 minecraft:smooth_basalt
fill 96 266 537 96 269 537 minecraft:blackstone
setblock 96 266 541 minecraft:smooth_basalt
fill 96 266 542 96 269 542 minecraft:blackstone
setblock 96 266 546 minecraft:smooth_basalt
setblock 97 266 520 minecraft:smooth_basalt
fill 97 266 521 97 269 521 minecraft:blackstone
setblock 97 266 535 minecraft:smooth_basalt
fill 97 266 536 97 268 536 minecraft:blackstone
setblock 97 266 540 minecraft:smooth_basalt
fill 97 266 541 97 269 541 minecraft:blackstone
setblock 115 266 512 minecraft:smooth_basalt
setblock 116 266 511 minecraft:smooth_basalt
fill 116 266 512 116 269 512 minecraft:blackstone
fill 117 266 511 117 269 511 minecraft:blackstone
fill 117 266 551 117 269 551 minecraft:blackstone
setblock 119 266 513 minecraft:smooth_basalt
setblock 120 266 512 minecraft:smooth_basalt
setblock 121 266 511 minecraft:smooth_basalt
setblock 121 266 512 minecraft:blackstone
setblock 121 266 551 minecraft:smooth_basalt
fill 122 266 511 122 268 511 minecraft:blackstone
fill 122 266 551 122 269 551 minecraft:blackstone
fill 133 266 540 133 267 542 minecraft:blackstone
setblock 134 266 538 minecraft:smooth_basalt
fill 134 266 539 134 269 539 minecraft:blackstone
setblock 134 266 543 minecraft:smooth_basalt
fill 134 266 544 134 269 544 minecraft:blackstone
setblock 134 266 547 minecraft:blackstone
fill 134 266 551 134 267 551 minecraft:blackstone
setblock 135 266 517 minecraft:smooth_basalt
fill 135 266 518 135 269 518 minecraft:blackstone
setblock 135 266 522 minecraft:smooth_basalt
fill 135 266 523 135 269 523 minecraft:blackstone
fill 135 266 533 135 269 533 minecraft:blackstone
setblock 135 266 537 minecraft:smooth_basalt
fill 135 266 538 135 269 538 minecraft:blackstone
setblock 135 266 542 minecraft:smooth_basalt
fill 135 266 543 135 269 543 minecraft:blackstone
setblock 135 266 547 minecraft:smooth_basalt
fill 135 266 548 135 269 548 minecraft:blackstone
setblock 95 267 516 minecraft:smooth_basalt
fill 95 267 517 95 270 517 minecraft:blackstone
setblock 95 267 521 minecraft:smooth_basalt
fill 95 267 522 95 270 522 minecraft:blackstone
setblock 95 267 525 minecraft:blackstone
setblock 95 267 526 minecraft:smooth_basalt
fill 95 267 527 96 269 527 minecraft:blackstone
setblock 95 267 531 minecraft:smooth_basalt
fill 95 267 532 95 270 532 minecraft:blackstone
setblock 95 267 536 minecraft:smooth_basalt
fill 95 267 537 95 270 537 minecraft:blackstone
setblock 95 267 541 minecraft:smooth_basalt
fill 95 267 542 95 270 542 minecraft:blackstone
setblock 95 267 546 minecraft:smooth_basalt
fill 95 267 547 95 270 547 minecraft:blackstone
fill 96 267 516 96 270 516 minecraft:blackstone
setblock 96 267 520 minecraft:smooth_basalt
fill 96 267 521 96 270 521 minecraft:blackstone
setblock 96 267 525 minecraft:smooth_basalt
fill 96 267 526 96 270 526 minecraft:blackstone
fill 96 267 528 96 267 529 minecraft:blackstone
setblock 96 267 530 minecraft:smooth_basalt
fill 96 267 531 96 270 531 minecraft:blackstone
setblock 96 267 535 minecraft:smooth_basalt
fill 96 267 536 96 270 536 minecraft:blackstone
setblock 96 267 540 minecraft:smooth_basalt
fill 96 267 541 96 270 541 minecraft:blackstone
setblock 96 267 545 minecraft:smooth_basalt
fill 96 267 546 96 270 546 minecraft:blackstone
setblock 97 267 519 minecraft:smooth_basalt
fill 97 267 520 97 270 520 minecraft:blackstone
fill 97 267 522 97 267 523 minecraft:blackstone
setblock 97 267 524 minecraft:smooth_basalt
setblock 97 267 539 minecraft:smooth_basalt
fill 97 267 540 97 270 540 minecraft:blackstone
setblock 97 267 544 minecraft:smooth_basalt
setblock 114 267 512 minecraft:smooth_basalt
setblock 115 267 511 minecraft:smooth_basalt
fill 115 267 512 115 270 512 minecraft:blackstone
fill 116 267 511 116 270 511 minecraft:blackstone
fill 116 267 551 116 270 551 minecraft:blackstone
setblock 119 267 512 minecraft:smooth_basalt
setblock 120 267 511 minecraft:smooth_basalt
setblock 120 267 512 minecraft:blackstone
setblock 120 267 551 minecraft:smooth_basalt
fill 121 267 511 121 270 511 minecraft:blackstone
fill 121 267 551 121 270 551 minecraft:blackstone
fill 133 267 539 133 270 539 minecraft:blackstone
setblock 133 267 543 minecraft:smooth_basalt
fill 133 267 544 133 270 544 minecraft:blackstone
fill 133 267 551 133 268 551 minecraft:blackstone
setblock 134 267 537 minecraft:smooth_basalt
fill 134 267 538 134 270 538 minecraft:blackstone
setblock 134 267 542 minecraft:smooth_basalt
fill 134 267 543 134 270 543 minecraft:blackstone
setblock 134 267 547 minecraft:smooth_basalt
fill 134 267 548 134 270 548 minecraft:blackstone
setblock 135 267 516 minecraft:smooth_basalt
fill 135 267 517 135 270 517 minecraft:blackstone
setblock 135 267 520 minecraft:blackstone
setblock 135 267 521 minecraft:smooth_basalt
fill 135 267 522 135 270 522 minecraft:blackstone
fill 135 267 524 135 267 525 minecraft:blackstone
fill 135 267 532 135 270 532 minecraft:blackstone
setblock 135 267 536 minecraft:smooth_basalt
fill 135 267 537 135 270 537 minecraft:blackstone
setblock 135 267 541 minecraft:smooth_basalt
fill 135 267 542 135 270 542 minecraft:blackstone
setblock 135 267 546 minecraft:smooth_basalt
fill 135 267 547 135 270 547 minecraft:blackstone
setblock 135 267 551 minecraft:smooth_basalt
setblock 95 268 515 minecraft:smooth_basalt
fill 95 268 516 95 271 516 minecraft:blackstone
setblock 95 268 520 minecraft:smooth_basalt
fill 95 268 521 95 271 521 minecraft:blackstone
setblock 95 268 524 minecraft:blackstone
setblock 95 268 525 minecraft:smooth_basalt
fill 95 268 526 95 271 526 minecraft:blackstone
setblock 95 268 530 minecraft:smooth_basalt
fill 95 268 531 95 271 531 minecraft:blackstone
setblock 95 268 535 minecraft:smooth_basalt
fill 95 268 536 95 271 536 minecraft:blackstone
setblock 95 268 540 minecraft:smooth_basalt
fill 95 268 541 95 271 541 minecraft:blackstone
setblock 95 268 545 minecraft:smooth_basalt
fill 95 268 546 95 271 546 minecraft:blackstone
setblock 95 268 549 minecraft:blackstone
setblock 96 268 519 minecraft:smooth_basalt
fill 96 268 520 96 271 520 minecraft:blackstone
setblock 96 268 524 minecraft:smooth_basalt
fill 96 268 525 97 270 525 minecraft:blackstone
setblock 96 268 528 minecraft:blackstone
setblock 96 268 529 minecraft:smooth_basalt
fill 96 268 530 96 271 530 minecraft:blackstone
setblock 96 268 534 minecraft:smooth_basalt
fill 96 268 535 96 271 535 minecraft:blackstone
setblock 96 268 539 minecraft:smooth_basalt
fill 96 268 540 96 271 540 minecraft:blackstone
setblock 96 268 544 minecraft:smooth_basalt
fill 96 268 545 96 271 545 minecraft:blackstone
fill 96 268 547 96 269 547 minecraft:blackstone
fill 97 268 519 97 271 519 minecraft:blackstone
setblock 97 268 522 minecraft:blackstone
setblock 97 268 523 minecraft:smooth_basalt
fill 97 268 524 97 271 524 minecraft:blackstone
fill 97 268 526 97 269 526 minecraft:blackstone
setblock 97 268 538 minecraft:smooth_basalt
fill 97 268 539 97 271 539 minecraft:blackstone
setblock 97 268 543 minecraft:smooth_basalt
fill 97 268 544 97 271 544 minecraft:blackstone
fill 112 268 511 112 269 511 minecraft:blackstone
setblock 114 268 511 minecraft:smooth_basalt
fill 114 268 512 114 271 512 minecraft:blackstone
setblock 114 268 551 minecraft:smooth_basalt
fill 115 268 511 115 271 511 minecraft:blackstone
fill 115 268 551 115 271 551 minecraft:blackstone
setblock 118 268 512 minecraft:smooth_basalt
setblock 119 268 511 minecraft:smooth_basalt
fill 119 268 512 119 271 512 minecraft:blackstone
setblock 119 268 551 minecraft:smooth_basalt
fill 120 268 511 120 271 511 minecraft:blackstone
fill 120 268 551 120 271 551 minecraft:blackstone
fill 132 268 551 132 269 551 minecraft:blackstone
fill 133 268 540 133 268 541 minecraft:blackstone
setblock 133 268 542 minecraft:smooth_basalt
fill 133 268 543 133 271 543 minecraft:blackstone
fill 133 268 545 133 268 546 minecraft:blackstone
setblock 134 268 535 minecraft:blackstone
setblock 134 268 536 minecraft:smooth_basalt
fill 134 268 537 134 271 537 minecraft:blackstone
setblock 134 268 541 minecraft:smooth_basalt
fill 134 268 542 134 271 542 minecraft:blackstone
setblock 134 268 545 minecraft:blackstone
setblock 134 268 546 minecraft:smooth_basalt
fill 134 268 547 134 271 547 minecraft:blackstone
fill 134 268 549 134 269 549 minecraft:blackstone
setblock 134 268 551 minecraft:smooth_basalt
setblock 135 268 515 minecraft:smooth_basalt
fill 135 268 516 135 271 516 minecraft:blackstone
setblock 135 268 520 minecraft:smooth_basalt
fill 135 268 521 135 271 521 minecraft:blackstone
setblock 135 268 524 minecraft:blackstone
setblock 135 268 525 minecraft:smooth_basalt
fill 135 268 526 135 268 529 minecraft:blackstone
setblock 135 268 530 minecraft:smooth_basalt
fill 135 268 531 135 271 531 minecraft:blackstone
setblock 135 268 535 minecraft:smooth_basalt
fill 135 268 536 135 271 536 minecraft:blackstone
setblock 135 268 540 minecraft:smooth_basalt
fill 135 268 541 135 271 541 minecraft:blackstone
setblock 135 268 545 minecraft:smooth_basalt
fill 135 268 546 135 271 546 minecraft:blackstone
setblock 135 268 550 minecraft:smooth_basalt
fill 135 268 551 135 271 551 minecraft:blackstone
setblock 95 269 514 minecraft:smooth_basalt
fill 95 269 515 95 272 515 minecraft:blackstone
setblock 95 269 519 minecraft:smooth_basalt
fill 95 269 520 95 272 520 minecraft:blackstone
setblock 95 269 524 minecraft:smooth_basalt
fill 95 269 525 95 272 525 minecraft:blackstone
setblock 95 269 529 minecraft:smooth_basalt
fill 95 269 530 95 272 530 minecraft:blackstone
setblock 95 269 534 minecraft:smooth_basalt
fill 95 269 535 95 272 535 minecraft:blackstone
setblock 95 269 539 minecraft:smooth_basalt
fill 95 269 540 95 272 540 minecraft:blackstone
setblock 95 269 544 minecraft:smooth_basalt
fill 95 269 545 95 272 545 minecraft:blackstone
setblock 95 269 549 minecraft:smooth_basalt
fill 95 269 550 95 272 550 minecraft:blackstone
setblock 96 269 518 minecraft:smooth_basalt
fill 96 269 519 96 272 519 minecraft:blackstone
setblock 96 269 523 minecraft:smooth_basalt
fill 96 269 524 96 272 524 minecraft:blackstone
setblock 96 269 528 minecraft:smooth_basalt
fill 96 269 529 96 272 529 minecraft:blackstone
setblock 96 269 533 minecraft:smooth_basalt
fill 96 269 534 96 272 534 minecraft:blackstone
setblock 96 269 538 minecraft:smooth_basalt
fill 96 269 539 96 272 539 minecraft:blackstone
setblock 96 269 543 minecraft:smooth_basalt
fill 96 269 544 96 272 544 minecraft:blackstone
setblock 96 269 548 minecraft:smooth_basalt
setblock 97 269 513 minecraft:light[level=12]
fill 97 269 518 97 272 518 minecraft:blackstone
setblock 97 269 522 minecraft:smooth_basalt
fill 97 269 523 97 272 523 minecraft:blackstone
setblock 97 269 527 minecraft:smooth_basalt
fill 97 269 528 97 272 528 minecraft:blackstone
setblock 97 269 529 minecraft:light[level=12]
setblock 97 269 537 minecraft:smooth_basalt
fill 97 269 538 97 271 538 minecraft:blackstone
setblock 97 269 542 minecraft:smooth_basalt
fill 97 269 543 97 272 543 minecraft:blackstone
fill 97 269 545 97 270 545 minecraft:blackstone
setblock 105 269 513 minecraft:light[level=12]
setblock 105 269 521 minecraft:light[level=12]
setblock 105 269 529 minecraft:light[level=12]
setblock 105 269 537 minecraft:light[level=12]
setblock 105 269 545 minecraft:light[level=12]
fill 111 269 511 111 270 511 minecraft:blackstone
setblock 113 269 511 minecraft:smooth_basalt
fill 113 269 512 113 272 512 minecraft:blackstone
setblock 113 269 513 minecraft:light[level=12]
setblock 113 269 521 minecraft:light[level=12]
setblock 113 269 529 minecraft:light[level=12]
setblock 113 269 537 minecraft:light[level=12]
setblock 113 269 545 minecraft:light[level=12]
setblock 113 269 551 minecraft:smooth_basalt
fill 114 269 511 114 272 511 minecraft:blackstone
fill 114 269 551 114 272 551 minecraft:blackstone
fill 115 269 550 118 269 550 minecraft:blackstone
setblock 117 269 512 minecraft:smooth_basalt
setblock 118 269 511 minecraft:smooth_basalt
fill 118 269 512 118 272 512 minecraft:blackstone
setblock 118 269 551 minecraft:smooth_basalt
fill 119 269 511 119 272 511 minecraft:blackstone
setblock 119 269 550 minecraft:smooth_basalt
fill 119 269 551 119 272 551 minecraft:blackstone
fill 120 269 550 120 272 550 minecraft:blackstone
setblock 121 269 513 minecraft:light[level=12]
setblock 121 269 529 minecraft:light[level=12]
setblock 121 269 537 minecraft:light[level=12]
setblock 121 269 545 minecraft:light[level=12]
setblock 123 269 551 minecraft:smooth_basalt
setblock 129 269 513 minecraft:light[level=12]
setblock 129 269 521 minecraft:light[level=12]
setblock 129 269 529 minecraft:light[level=12]
setblock 129 269 537 minecraft:light[level=12]
setblock 129 269 545 minecraft:light[level=12]
fill 130 269 551 131 270 551 minecraft:blackstone
fill 133 269 538 133 271 538 minecraft:blackstone
setblock 133 269 540 minecraft:blackstone
setblock 133 269 541 minecraft:smooth_basalt
fill 133 269 542 133 272 542 minecraft:blackstone
setblock 133 269 545 minecraft:blackstone
setblock 133 269 546 minecraft:smooth_basalt
fill 133 269 547 133 272 547 minecraft:blackstone
setblock 133 269 550 minecraft:blackstone
setblock 133 269 551 minecraft:smooth_basalt
setblock 134 269 519 minecraft:blackstone
setblock 134 269 520 minecraft:smooth_basalt
fill 134 269 521 134 269 524 minecraft:blackstone
setblock 134 269 525 minecraft:smooth_basalt
setblock 134 269 535 minecraft:smooth_basalt
fill 134 269 536 134 272 536 minecraft:blackstone
setblock 134 269 540 minecraft:smooth_basalt
fill 134 269 541 134 272 541 minecraft:blackstone
setblock 134 269 545 minecraft:smooth_basalt
fill 134 269 546 134 272 546 minecraft:blackstone
setblock 134 269 550 minecraft:smooth_basalt
fill 134 269 551 134 272 551 minecraft:blackstone
fill 135 269 515 135 272 515 minecraft:blackstone
setblock 135 269 519 minecraft:smooth_basalt
fill 135 269 520 135 272 520 minecraft:blackstone
setblock 135 269 524 minecraft:smooth_basalt
fill 135 269 525 135 269 528 minecraft:blackstone
setblock 135 269 529 minecraft:smooth_basalt
fill 135 269 530 135 272 530 minecraft:blackstone
setblock 135 269 534 minecraft:smooth_basalt
fill 135 269 535 135 272 535 minecraft:blackstone
setblock 135 269 539 minecraft:smooth_basalt
fill 135 269 540 135 272 540 minecraft:blackstone
setblock 135 269 544 minecraft:smooth_basalt
fill 135 269 545 135 272 545 minecraft:blackstone
setblock 135 269 549 minecraft:smooth_basalt
fill 135 269 550 135 272 550 minecraft:blackstone
setblock 95 270 513 minecraft:smooth_basalt
fill 95 270 514 95 273 514 minecraft:blackstone
setblock 95 270 518 minecraft:smooth_basalt
fill 95 270 519 95 273 519 minecraft:blackstone
setblock 95 270 523 minecraft:smooth_basalt
fill 95 270 524 95 273 524 minecraft:blackstone
setblock 95 270 527 minecraft:blackstone
setblock 95 270 528 minecraft:smooth_basalt
fill 95 270 529 95 273 529 minecraft:blackstone
setblock 95 270 533 minecraft:smooth_basalt
fill 95 270 534 95 273 534 minecraft:blackstone
setblock 95 270 538 minecraft:smooth_basalt
fill 95 270 539 95 273 539 minecraft:blackstone
setblock 95 270 543 minecraft:smooth_basalt
fill 95 270 544 95 273 544 minecraft:blackstone
setblock 95 270 548 minecraft:smooth_basalt
fill 95 270 549 95 273 549 minecraft:blackstone
fill 95 270 551 96 270 551 minecraft:blackstone
setblock 96 270 517 minecraft:smooth_basalt
fill 96 270 518 96 273 518 minecraft:blackstone
setblock 96 270 522 minecraft:smooth_basalt
fill 96 270 523 96 273 523 minecraft:blackstone
setblock 96 270 527 minecraft:smooth_basalt
fill 96 270 528 96 273 528 minecraft:blackstone
setblock 96 270 532 minecraft:smooth_basalt
fill 96 270 533 96 273 533 minecraft:blackstone
setblock 96 270 537 minecraft:smooth_basalt
fill 96 270 538 96 273 538 minecraft:blackstone
setblock 96 270 542 minecraft:smooth_basalt
fill 96 270 543 96 273 543 minecraft:blackstone
setblock 96 270 547 minecraft:smooth_basalt
fill 96 270 548 96 273 548 minecraft:blackstone
setblock 97 270 521 minecraft:smooth_basalt
fill 97 270 522 98 272 522 minecraft:blackstone
setblock 97 270 526 minecraft:smooth_basalt
fill 97 270 527 97 273 527 minecraft:blackstone
fill 97 270 529 97 271 529 minecraft:blackstone
setblock 97 270 537 minecraft:blackstone
setblock 97 270 541 minecraft:smooth_basalt
fill 97 270 542 97 273 542 minecraft:blackstone
fill 98 270 521 98 272 521 minecraft:blackstone
fill 98 270 523 98 270 524 minecraft:blackstone
fill 106 270 518 107 270 522 minecraft:gold_block
fill 107 270 516 108 270 517 minecraft:gold_block
fill 107 270 523 108 271 523 minecraft:gold_block
fill 108 270 515 114 270 515 minecraft:gold_block
fill 108 270 518 110 270 519 minecraft:gold_block
fill 108 270 524 111 270 524 minecraft:gold_block
fill 109 270 514 113 270 514 minecraft:gold_block
fill 109 270 516 110 272 516 minecraft:gold_block
fill 110 270 511 110 271 511 minecraft:blackstone
fill 110 270 523 113 270 523 minecraft:gold_block
fill 111 270 518 113 273 518 minecraft:smooth_basalt
fill 111 270 519 111 270 522 minecraft:gold_block
setblock 111 270 551 minecraft:blackstone
setblock 112 270 511 minecraft:smooth_basalt
fill 112 270 512 112 273 512 minecraft:blackstone
fill 112 270 516 115 270 516 minecraft:gold_block
fill 112 270 520 112 270 522 minecraft:gold_block
setblock 112 270 551 minecraft:smooth_basalt
fill 113 270 511 113 273 511 minecraft:blackstone
fill 113 270 521 115 270 522 minecraft:gold_block
setblock 113 270 550 minecraft:smooth_basalt
fill 113 270 551 113 273 551 minecraft:blackstone
fill 114 270 517 116 270 520 minecraft:gold_block
fill 114 270 550 117 270 550 minecraft:blackstone
setblock 116 270 512 minecraft:smooth_basalt
setblock 117 270 511 minecraft:smooth_basalt
fill 117 270 512 117 273 512 minecraft:blackstone
fill 117 270 522 118 270 522 minecraft:gold_block
setblock 117 270 551 minecraft:smooth_basalt
fill 118 270 511 118 273 511 minecraft:blackstone
fill 118 270 520 118 270 521 minecraft:gold_block
fill 118 270 523 119 270 524 minecraft:gold_block
setblock 118 270 550 minecraft:smooth_basalt
fill 118 270 551 118 273 551 minecraft:blackstone
fill 119 270 519 122 270 520 minecraft:gold_block
fill 119 270 525 122 270 525 minecraft:gold_block
fill 119 270 550 119 273 550 minecraft:blackstone
fill 120 270 524 123 270 524 minecraft:gold_block
fill 121 270 550 121 271 550 minecraft:blackstone
setblock 122 270 551 minecraft:smooth_basalt
fill 123 270 520 123 270 523 minecraft:gold_block
fill 123 270 551 126 270 551 minecraft:blackstone
setblock 124 270 522 minecraft:gold_block
setblock 127 270 551 minecraft:smooth_basalt
fill 128 270 551 129 272 551 minecraft:blackstone
fill 130 270 550 132 270 550 minecraft:blackstone
setblock 132 270 541 minecraft:smooth_basalt
fill 132 270 542 132 270 545 minecraft:blackstone
setblock 132 270 551 minecraft:smooth_basalt
setblock 133 270 540 minecraft:smooth_basalt
fill 133 270 541 133 273 541 minecraft:blackstone
setblock 133 270 545 minecraft:smooth_basalt
fill 133 270 546 133 273 546 minecraft:blackstone
fill 133 270 548 133 270 549 minecraft:blackstone
setblock 133 270 550 minecraft:smooth_basalt
fill 133 270 551 133 273 551 minecraft:blackstone
setblock 134 270 518 minecraft:blackstone
setblock 134 270 519 minecraft:smooth_basalt
fill 134 270 520 134 270 523 minecraft:blackstone
setblock 134 270 524 minecraft:smooth_basalt
fill 134 270 525 134 270 528 minecraft:blackstone
setblock 134 270 533 minecraft:blackstone
setblock 134 270 534 minecraft:smooth_basalt
fill 134 270 535 134 273 535 minecraft:blackstone
setblock 134 270 539 minecraft:smooth_basalt
fill 134 270 540 134 273 540 minecraft:blackstone
setblock 134 270 544 minecraft:smooth_basalt
fill 134 270 545 134 273 545 minecraft:blackstone
setblock 134 270 549 minecraft:smooth_basalt
fill 134 270 550 134 273 550 minecraft:blackstone
fill 135 270 514 135 273 514 minecraft:blackstone
setblock 135 270 518 minecraft:smooth_basalt
fill 135 270 519 135 273 519 minecraft:blackstone
setblock 135 270 523 minecraft:smooth_basalt
fill 135 270 524 135 270 527 minecraft:blackstone
setblock 135 270 528 minecraft:smooth_basalt
fill 135 270 529 135 273 529 minecraft:blackstone
setblock 135 270 533 minecraft:smooth_basalt
fill 135 270 534 135 273 534 minecraft:blackstone
setblock 135 270 538 minecraft:smooth_basalt
fill 135 270 539 135 273 539 minecraft:blackstone
setblock 135 270 543 minecraft:smooth_basalt
fill 135 270 544 135 273 544 minecraft:blackstone
setblock 135 270 548 minecraft:smooth_basalt
fill 135 270 549 135 273 549 minecraft:blackstone
setblock 95 271 512 minecraft:smooth_basalt
fill 95 271 513 95 273 513 minecraft:blackstone
setblock 95 271 517 minecraft:smooth_basalt
fill 95 271 518 95 273 518 minecraft:blackstone
setblock 95 271 522 minecraft:smooth_basalt
fill 95 271 523 95 273 523 minecraft:blackstone
setblock 95 271 527 minecraft:smooth_basalt
fill 95 271 528 95 273 528 minecraft:blackstone
setblock 95 271 532 minecraft:smooth_basalt
fill 95 271 533 95 273 533 minecraft:blackstone
setblock 95 271 537 minecraft:smooth_basalt
fill 95 271 538 95 273 538 minecraft:blackstone
setblock 95 271 542 minecraft:smooth_basalt
fill 95 271 543 95 273 543 minecraft:blackstone
setblock 95 271 547 minecraft:smooth_basalt
fill 95 271 548 95 273 548 minecraft:blackstone
setblock 95 271 551 minecraft:blackstone
setblock 96 271 516 minecraft:smooth_basalt
fill 96 271 517 96 273 517 minecraft:blackstone
setblock 96 271 521 minecraft:smooth_basalt
fill 96 271 522 96 273 522 minecraft:blackstone
setblock 96 271 525 minecraft:blackstone
setblock 96 271 526 minecraft:smooth_basalt
fill 96 271 527 96 273 527 minecraft:blackstone
setblock 96 271 531 minecraft:smooth_basalt
fill 96 271 532 96 273 532 minecraft:blackstone
setblock 96 271 536 minecraft:smooth_basalt
fill 96 271 537 96 273 537 minecraft:blackstone
setblock 96 271 541 minecraft:smooth_basalt
fill 96 271 542 96 273 542 minecraft:blackstone
setblock 96 271 546 minecraft:smooth_basalt
fill 96 271 547 96 273 547 minecraft:blackstone
fill 96 271 549 96 272 549 minecraft:blackstone
setblock 96 271 551 minecraft:smooth_basalt
setblock 97 271 520 minecraft:smooth_basalt
fill 97 271 521 97 273 521 minecraft:blackstone
setblock 97 271 525 minecraft:smooth_basalt
fill 97 271 526 98 273 526 minecraft:blackstone
setblock 97 271 530 minecraft:smooth_basalt
setblock 97 271 540 minecraft:smooth_basalt
fill 97 271 541 97 272 541 minecraft:blackstone
setblock 97 271 545 minecraft:smooth_basalt
fill 97 271 546 97 273 546 minecraft:blackstone
fill 97 271 551 97 273 551 minecraft:blackstone
setblock 98 271 523 minecraft:blackstone
setblock 98 271 524 minecraft:smooth_basalt
fill 98 271 525 98 273 525 minecraft:blackstone
fill 107 271 518 107 271 522 minecraft:gold_block
fill 108 271 516 108 271 519 minecraft:gold_block
fill 109 271 511 109 272 511 minecraft:blackstone
fill 109 271 515 113 271 515 minecraft:gold_block
fill 109 271 518 110 273 518 minecraft:smooth_basalt
fill 109 271 519 110 271 519 minecraft:gold_block
setblock 109 271 524 minecraft:gold_block
fill 110 271 523 111 271 523 minecraft:gold_block
setblock 110 271 551 minecraft:blackstone
setblock 111 271 511 minecraft:smooth_basalt
fill 111 271 512 111 273 512 minecraft:blackstone
fill 111 271 519 111 273 519 minecraft:smooth_basalt
fill 111 271 520 111 272 522 minecraft:gold_block
setblock 111 271 551 minecraft:smooth_basalt
fill 112 271 511 112 273 511 minecraft:blackstone
fill 112 271 516 114 271 516 minecraft:gold_block
fill 112 271 520 112 273 521 minecraft:smooth_basalt
fill 112 271 522 113 271 522 minecraft:gold_block
setblock 112 271 550 minecraft:smooth_basalt
fill 112 271 551 112 273 551 minecraft:blackstone
fill 113 271 521 114 271 521 minecraft:gold_block
fill 113 271 550 116 271 550 minecraft:blackstone
setblock 114 271 513 minecraft:smooth_basalt
fill 114 271 517 115 271 520 minecraft:gold_block
fill 114 271 549 117 271 549 minecraft:blackstone
setblock 115 271 512 minecraft:smooth_basalt
fill 115 271 513 115 273 513 minecraft:blackstone
setblock 116 271 511 minecraft:smooth_basalt
fill 116 271 512 116 273 512 minecraft:blackstone
setblock 116 271 551 minecraft:smooth_basalt
fill 117 271 511 117 273 511 minecraft:blackstone
setblock 117 271 550 minecraft:smooth_basalt
fill 117 271 551 117 273 551 minecraft:blackstone
fill 118 271 521 118 271 523 minecraft:gold_block
setblock 118 271 549 minecraft:smooth_basalt
fill 118 271 550 118 273 550 minecraft:blackstone
fill 119 271 520 122 271 520 minecraft:gold_block
fill 119 271 523 119 271 524 minecraft:gold_block
fill 119 271 549 119 273 549 minecraft:blackstone
fill 120 271 519 121 271 519 minecraft:gold_block
fill 120 271 524 122 271 524 minecraft:gold_block
setblock 121 271 511 minecraft:smooth_basalt
setblock 121 271 551 minecraft:smooth_basalt
setblock 122 271 550 minecraft:smooth_basalt
fill 122 271 551 125 271 551 minecraft:blackstone
fill 123 271 521 123 271 523 minecraft:gold_block
setblock 126 271 551 minecraft:smooth_basalt
fill 127 271 551 127 273 551 minecraft:blackstone
fill 128 271 550 131 271 550 minecraft:blackstone
setblock 130 271 551 minecraft:blackstone
fill 131 271 549 132 271 549 minecraft:blackstone
setblock 131 271 551 minecraft:smooth_basalt
fill 132 271 541 132 271 544 minecraft:blackstone
setblock 132 271 545 minecraft:smooth_basalt
fill 132 271 546 132 273 547 minecraft:blackstone
setblock 132 271 550 minecraft:smooth_basalt
fill 132 271 551 132 273 551 minecraft:blackstone
fill 133 271 537 133 272 537 minecraft:blackstone
setblock 133 271 539 minecraft:smooth_basalt
fill 133 271 540 133 273 540 minecraft:blackstone
setblock 133 271 544 minecraft:smooth_basalt
fill 133 271 545 133 273 545 minecraft:blackstone
setblock 133 271 548 minecraft:blackstone
setblock 133 271 549 minecraft:smooth_basalt
fill 133 271 550 133 273 550 minecraft:blackstone
fill 134 271 511 135 271 511 minecraft:blackstone
setblock 134 271 518 minecraft:smooth_basalt
fill 134 271 519 134 271 522 minecraft:blackstone
setblock 134 271 523 minecraft:smooth_basalt
fill 134 271 524 134 271 527 minecraft:blackstone
setblock 134 271 528 minecraft:smooth_basalt
fill 134 271 529 134 271 532 minecraft:blackstone
setblock 134 271 533 minecraft:smooth_basalt
fill 134 271 534 134 273 534 minecraft:blackstone
setblock 134 271 538 minecraft:smooth_basalt
fill 134 271 539 134 273 539 minecraft:blackstone
setblock 134 271 543 minecraft:smooth_basalt
fill 134 271 544 134 273 544 minecraft:blackstone
setblock 134 271 548 minecraft:smooth_basalt
fill 134 271 549 134 273 549 minecraft:blackstone
setblock 135 271 517 minecraft:smooth_basalt
fill 135 271 518 135 273 518 minecraft:blackstone
setblock 135 271 522 minecraft:smooth_basalt
fill 135 271 523 135 271 526 minecraft:blackstone
setblock 135 271 527 minecraft:smooth_basalt
fill 135 271 528 135 273 528 minecraft:blackstone
setblock 135 271 532 minecraft:smooth_basalt
fill 135 271 533 135 273 533 minecraft:blackstone
setblock 135 271 537 minecraft:smooth_basalt
fill 135 271 538 135 273 538 minecraft:blackstone
setblock 135 271 542 minecraft:smooth_basalt
fill 135 271 543 135 273 543 minecraft:blackstone
setblock 135 271 547 minecraft:smooth_basalt
fill 135 271 548 135 273 548 minecraft:blackstone
setblock 95 272 511 minecraft:smooth_basalt
fill 95 272 512 95 273 512 minecraft:blackstone
setblock 95 272 516 minecraft:smooth_basalt
fill 95 272 517 95 273 517 minecraft:blackstone
setblock 95 272 521 minecraft:smooth_basalt
fill 95 272 522 95 273 522 minecraft:blackstone
setblock 95 272 526 minecraft:smooth_basalt
fill 95 272 527 95 273 527 minecraft:blackstone
setblock 95 272 531 minecraft:smooth_basalt
fill 95 272 532 95 273 532 minecraft:blackstone
setblock 95 272 536 minecraft:smooth_basalt
fill 95 272 537 95 273 537 minecraft:blackstone
setblock 95 272 541 minecraft:smooth_basalt
fill 95 272 542 95 273 542 minecraft:blackstone
setblock 95 272 546 minecraft:smooth_basalt
fill 95 272 547 95 273 547 minecraft:blackstone
setblock 95 272 551 minecraft:smooth_basalt
fill 96 272 511 96 273 511 minecraft:blackstone
fill 96 272 516 96 273 516 minecraft:blackstone
setblock 96 272 520 minecraft:smooth_basalt
fill 96 272 521 96 273 521 minecraft:blackstone
setblock 96 272 525 minecraft:smooth_basalt
fill 96 272 526 96 273 526 minecraft:blackstone
setblock 96 272 530 minecraft:smooth_basalt
fill 96 272 531 97 273 531 minecraft:blackstone
setblock 96 272 535 minecraft:smooth_basalt
fill 96 272 536 96 273 536 minecraft:blackstone
setblock 96 272 540 minecraft:smooth_basalt
fill 96 272 541 96 273 541 minecraft:blackstone
setblock 96 272 545 minecraft:smooth_basalt
fill 96 272 546 96 273 546 minecraft:blackstone
setblock 96 272 550 minecraft:smooth_basalt
fill 96 272 551 96 273 551 minecraft:blackstone
setblock 97 272 519 minecraft:smooth_basalt
fill 97 272 520 97 273 520 minecraft:blackstone
setblock 97 272 524 minecraft:smooth_basalt
fill 97 272 525 97 273 525 minecraft:blackstone
setblock 97 272 529 minecraft:smooth_basalt
fill 97 272 530 97 273 530 minecraft:blackstone
setblock 97 272 540 minecraft:blackstone
setblock 97 272 544 minecraft:smooth_basalt
fill 97 272 545 97 273 545 minecraft:blackstone
setblock 98 272 523 minecraft:smooth_basalt
fill 98 272 524 98 273 524 minecraft:blackstone
setblock 98 272 527 minecraft:blackstone
fill 98 272 551 98 273 551 minecraft:blackstone
fill 107 272 521 107 272 522 minecraft:gold_block
fill 108 272 511 108 273 511 minecraft:blackstone
fill 108 272 517 108 272 519 minecraft:gold_block
setblock 108 272 523 minecraft:gold_block
setblock 109 272 519 minecraft:gold_block
setblock 109 272 551 minecraft:blackstone
setblock 110 272 511 minecraft:smooth_basalt
fill 110 272 512 110 273 512 minecraft:blackstone
fill 110 272 519 110 273 519 minecraft:smooth_basalt
setblock 110 272 523 minecraft:gold_block
setblock 110 272 550 minecraft:blackstone
setblock 110 272 551 minecraft:smooth_basalt
fill 111 272 511 111 273 511 minecraft:blackstone
setblock 111 272 550 minecraft:smooth_basalt
fill 111 272 551 111 273 551 minecraft:blackstone
fill 112 272 516 113 272 516 minecraft:gold_block
setblock 112 272 522 minecraft:gold_block
setblock 112 272 549 minecraft:smooth_basalt
fill 112 272 550 115 272 550 minecraft:blackstone
setblock 113 272 513 minecraft:smooth_basalt
setblock 113 272 521 minecraft:gold_block
fill 113 272 549 116 272 549 minecraft:blackstone
setblock 114 272 512 minecraft:smooth_basalt
fill 114 272 513 114 273 513 minecraft:blackstone
fill 114 272 517 114 272 520 minecraft:gold_block
setblock 115 272 511 minecraft:smooth_basalt
fill 115 272 512 115 273 512 minecraft:blackstone
setblock 115 272 551 minecraft:smooth_basalt
fill 116 272 511 116 273 511 minecraft:blackstone
setblock 116 272 550 minecraft:smooth_basalt
fill 116 272 551 116 273 551 minecraft:blackstone
setblock 117 272 549 minecraft:smooth_basalt
fill 117 272 550 117 273 550 minecraft:blackstone
fill 118 272 549 118 273 549 minecraft:blackstone
setblock 119 272 512 minecraft:smooth_basalt
setblock 119 272 523 minecraft:gold_block
setblock 120 272 511 minecraft:smooth_basalt
fill 120 272 520 122 272 520 minecraft:gold_block
fill 120 272 524 121 272 524 minecraft:gold_block
fill 120 272 549 120 273 549 minecraft:blackstone
setblock 120 272 551 minecraft:smooth_basalt
fill 121 272 511 121 273 511 minecraft:blackstone
setblock 121 272 550 minecraft:smooth_basalt
fill 121 272 551 124 272 551 minecraft:blackstone
fill 122 272 550 125 272 550 minecraft:blackstone
setblock 125 272 551 minecraft:smooth_basalt
setblock 126 272 550 minecraft:smooth_basalt
fill 126 272 551 126 273 551 minecraft:blackstone
fill 127 272 550 130 272 550 minecraft:blackstone
fill 129 272 549 131 272 549 minecraft:blackstone
setblock 130 272 551 minecraft:smooth_basalt
fill 131 272 548 132 272 548 minecraft:blackstone
setblock 131 272 550 minecraft:smooth_basalt
fill 131 272 551 131 273 551 minecraft:blackstone
fill 132 272 511 134 272 511 minecraft:blackstone
fill 132 272 540 132 272 543 minecraft:blackstone
setblock 132 272 544 minecraft:smooth_basalt
fill 132 272 545 132 273 545 minecraft:blackstone
setblock 132 272 549 minecraft:smooth_basalt
fill 132 272 550 132 273 550 minecraft:blackstone
setblock 133 272 522 minecraft:blackstone
setblock 133 272 523 minecraft:smooth_basalt
fill 133 272 524 133 272 527 minecraft:blackstone
setblock 133 272 528 minecraft:smooth_basalt
setblock 133 272 538 minecraft:smooth_basalt
fill 133 272 539 133 273 539 minecraft:blackstone
setblock 133 272 543 minecraft:smooth_basalt
fill 133 272 544 133 273 544 minecraft:blackstone
setblock 133 272 548 minecraft:smooth_basalt
fill 133 272 549 133 273 549 minecraft:blackstone
fill 134 272 518 134 272 521 minecraft:blackstone
setblock 134 272 522 minecraft:smooth_basalt
fill 134 272 523 134 272 526 minecraft:blackstone
setblock 134 272 527 minecraft:smooth_basalt
fill 134 272 528 134 272 531 minecraft:blackstone
setblock 134 272 532 minecraft:smooth_basalt
fill 134 272 533 134 273 533 minecraft:blackstone
setblock 134 272 537 minecraft:smooth_basalt
fill 134 272 538 134 273 538 minecraft:blackstone
setblock 134 272 542 minecraft:smooth_basalt
fill 134 272 543 134 273 543 minecraft:blackstone
setblock 134 272 547 minecraft:smooth_basalt
fill 134 272 548 134 273 548 minecraft:blackstone
setblock 135 272 511 minecraft:smooth_basalt
fill 135 272 512 135 273 513 minecraft:blackstone
setblock 135 272 516 minecraft:smooth_basalt
fill 135 272 517 135 273 517 minecraft:blackstone
setblock 135 272 521 minecraft:smooth_basalt
fill 135 272 522 135 272 525 minecraft:blackstone
setblock 135 272 526 minecraft:smooth_basalt
fill 135 272 527 135 273 527 minecraft:blackstone
setblock 135 272 531 minecraft:smooth_basalt
fill 135 272 532 135 273 532 minecraft:blackstone
setblock 135 272 536 minecraft:smooth_basalt
fill 135 272 537 135 273 537 minecraft:blackstone
setblock 135 272 541 minecraft:smooth_basalt
fill 135 272 542 135 273 542 minecraft:blackstone
setblock 135 272 546 minecraft:smooth_basalt
fill 135 272 547 135 273 547 minecraft:blackstone
setblock 135 272 551 minecraft:smooth_basalt
setblock 95 273 511 minecraft:blackstone
setblock 95 273 515 minecraft:smooth_basalt
setblock 95 273 516 minecraft:blackstone
setblock 95 273 520 minecraft:smooth_basalt
setblock 95 273 521 minecraft:blackstone
setblock 95 273 525 minecraft:smooth_basalt
setblock 95 273 526 minecraft:blackstone
setblock 95 273 530 minecraft:smooth_basalt
setblock 95 273 531 minecraft:blackstone
setblock 95 273 535 minecraft:smooth_basalt
setblock 95 273 536 minecraft:blackstone
setblock 95 273 540 minecraft:smooth_basalt
setblock 95 273 541 minecraft:blackstone
setblock 95 273 545 minecraft:smooth_basalt
setblock 95 273 546 minecraft:blackstone
setblock 95 273 550 minecraft:smooth_basalt
setblock 95 273 551 minecraft:blackstone
setblock 96 273 519 minecraft:smooth_basalt
setblock 96 273 520 minecraft:blackstone
setblock 96 273 524 minecraft:smooth_basalt
setblock 96 273 525 minecraft:blackstone
setblock 96 273 529 minecraft:smooth_basalt
setblock 96 273 530 minecraft:blackstone
setblock 96 273 534 minecraft:smooth_basalt
setblock 96 273 535 minecraft:blackstone
setblock 96 273 539 minecraft:smooth_basalt
setblock 96 273 540 minecraft:blackstone
setblock 96 273 544 minecraft:smooth_basalt
setblock 96 273 545 minecraft:blackstone
setblock 96 273 549 minecraft:smooth_basalt
setblock 96 273 550 minecraft:blackstone
setblock 97 273 511 minecraft:blackstone
setblock 97 273 519 minecraft:blackstone
setblock 97 273 522 minecraft:blackstone
setblock 97 273 523 minecraft:smooth_basalt
setblock 97 273 524 minecraft:blackstone
setblock 97 273 528 minecraft:smooth_basalt
setblock 97 273 529 minecraft:blackstone
setblock 97 273 543 minecraft:smooth_basalt
setblock 97 273 544 minecraft:blackstone
setblock 98 273 522 minecraft:smooth_basalt
setblock 98 273 523 minecraft:blackstone
setblock 98 273 527 minecraft:smooth_basalt
setblock 107 273 511 minecraft:blackstone
fill 107 273 551 108 273 551 minecraft:blackstone
setblock 109 273 511 minecraft:smooth_basalt
setblock 109 273 512 minecraft:blackstone
setblock 109 273 519 minecraft:smooth_basalt
setblock 109 273 550 minecraft:blackstone
setblock 109 273 551 minecraft:smooth_basalt
setblock 110 273 511 minecraft:blackstone
setblock 110 273 550 minecraft:smooth_basalt
setblock 110 273 551 minecraft:blackstone
fill 111 273 520 111 273 521 minecraft:smooth_basalt
setblock 111 273 549 minecraft:smooth_basalt
fill 111 273 550 114 273 550 minecraft:blackstone
setblock 112 273 513 minecraft:smooth_basalt
fill 112 273 549 115 273 549 minecraft:blackstone
setblock 113 273 512 minecraft:smooth_basalt
setblock 113 273 513 minecraft:blackstone
setblock 114 273 511 minecraft:smooth_basalt
setblock 114 273 512 minecraft:blackstone
fill 114 273 548 116 273 548 minecraft:blackstone
setblock 114 273 551 minecraft:smooth_basalt
setblock 115 273 511 minecraft:blackstone
setblock 115 273 550 minecraft:smooth_basalt
setblock 115 273 551 minecraft:blackstone
setblock 116 273 549 minecraft:smooth_basalt
setblock 116 273 550 minecraft:blackstone
setblock 117 273 548 minecraft:smooth_basalt
setblock 117 273 549 minecraft:blackstone
setblock 118 273 512 minecraft:smooth_basalt
setblock 119 273 511 minecraft:smooth_basalt
setblock 119 273 551 minecraft:smooth_basalt
setblock 120 273 511 minecraft:blackstone
setblock 120 273 550 minecraft:smooth_basalt
fill 120 273 551 123 273 551 minecraft:blackstone
setblock 121 273 549 minecraft:smooth_basalt
fill 121 273 550 124 273 550 minecraft:blackstone
setblock 124 273 551 minecraft:smooth_basalt
setblock 125 273 550 minecraft:smooth_basalt
setblock 125 273 551 minecraft:blackstone
fill 126 273 550 129 273 550 minecraft:blackstone
fill 127 273 549 130 273 549 minecraft:blackstone
setblock 128 273 551 minecraft:blackstone
setblock 129 273 551 minecraft:smooth_basalt
fill 130 273 511 133 273 511 minecraft:blackstone
fill 130 273 548 131 273 548 minecraft:blackstone
setblock 130 273 550 minecraft:smooth_basalt
setblock 130 273 551 minecraft:blackstone
setblock 131 273 549 minecraft:smooth_basalt
setblock 131 273 550 minecraft:blackstone
fill 132 273 540 132 273 542 minecraft:blackstone
setblock 132 273 543 minecraft:smooth_basalt
setblock 132 273 544 minecraft:blackstone
setblock 132 273 548 minecraft:smooth_basalt
setblock 132 273 549 minecraft:blackstone
setblock 133 273 521 minecraft:blackstone
setblock 133 273 522 minecraft:smooth_basalt
fill 133 273 523 133 273 526 minecraft:blackstone
setblock 133 273 527 minecraft:smooth_basalt
fill 133 273 528 133 273 531 minecraft:blackstone
setblock 133 273 536 minecraft:blackstone
setblock 133 273 537 minecraft:smooth_basalt
setblock 133 273 538 minecraft:blackstone
setblock 133 273 542 minecraft:smooth_basalt
setblock 133 273 543 minecraft:blackstone
setblock 133 273 547 minecraft:smooth_basalt
setblock 133 273 548 minecraft:blackstone
setblock 134 273 511 minecraft:smooth_basalt
fill 134 273 518 134 273 520 minecraft:blackstone
setblock 134 273 521 minecraft:smooth_basalt
fill 134 273 522 134 273 525 minecraft:blackstone
setblock 134 273 526 minecraft:smooth_basalt
fill 134 273 527 134 273 530 minecraft:blackstone
setblock 134 273 531 minecraft:smooth_basalt
setblock 134 273 532 minecraft:blackstone
setblock 134 273 536 minecraft:smooth_basalt
setblock 134 273 537 minecraft:blackstone
setblock 134 273 541 minecraft:smooth_basalt
setblock 134 273 542 minecraft:blackstone
setblock 134 273 546 minecraft:smooth_basalt
setblock 134 273 547 minecraft:blackstone
setblock 134 273 551 minecraft:smooth_basalt
setblock 135 273 511 minecraft:blackstone
setblock 135 273 515 minecraft:smooth_basalt
setblock 135 273 516 minecraft:blackstone
setblock 135 273 520 minecraft:smooth_basalt
fill 135 273 521 135 273 524 minecraft:blackstone
setblock 135 273 525 minecraft:smooth_basalt
setblock 135 273 526 minecraft:blackstone
setblock 135 273 530 minecraft:smooth_basalt
setblock 135 273 531 minecraft:blackstone
setblock 135 273 535 minecraft:smooth_basalt
setblock 135 273 536 minecraft:blackstone
setblock 135 273 540 minecraft:smooth_basalt
setblock 135 273 541 minecraft:blackstone
setblock 135 273 545 minecraft:smooth_basalt
setblock 135 273 546 minecraft:blackstone
setblock 135 273 550 minecraft:smooth_basalt
setblock 135 273 551 minecraft:blackstone
setblock 97 277 513 minecraft:light[level=12]
setblock 97 277 521 minecraft:light[level=12]
setblock 97 277 529 minecraft:light[level=12]
setblock 97 277 537 minecraft:light[level=12]
setblock 97 277 545 minecraft:light[level=12]
setblock 105 277 513 minecraft:light[level=12]
setblock 105 277 521 minecraft:light[level=12]
setblock 105 277 529 minecraft:light[level=12]
setblock 105 277 537 minecraft:light[level=12]
setblock 105 277 545 minecraft:light[level=12]
setblock 113 277 513 minecraft:light[level=12]
setblock 113 277 521 minecraft:light[level=12]
setblock 113 277 529 minecraft:light[level=12]
setblock 113 277 537 minecraft:light[level=12]
setblock 113 277 545 minecraft:light[level=12]
setblock 121 277 513 minecraft:light[level=12]
setblock 121 277 521 minecraft:light[level=12]
setblock 121 277 529 minecraft:light[level=12]
setblock 121 277 537 minecraft:light[level=12]
setblock 121 277 545 minecraft:light[level=12]
setblock 129 277 513 minecraft:light[level=12]
setblock 129 277 521 minecraft:light[level=12]
setblock 129 277 529 minecraft:light[level=12]
setblock 129 277 537 minecraft:light[level=12]
setblock 129 277 545 minecraft:light[level=12]
fill 102 279 530 105 280 530 minecraft:light_blue_concrete
fill 103 279 525 103 280 525 minecraft:blue_concrete
fill 103 279 526 106 280 529 minecraft:light_blue_concrete
fill 103 279 531 105 280 535 minecraft:light_blue_concrete
fill 104 279 523 104 280 524 minecraft:blue_concrete
fill 104 279 525 109 280 525 minecraft:light_blue_concrete
fill 104 279 536 105 280 537 minecraft:light_blue_concrete
fill 105 279 521 105 280 523 minecraft:blue_concrete
fill 105 279 524 110 280 524 minecraft:light_blue_concrete
fill 105 279 538 106 280 539 minecraft:light_blue_concrete
fill 106 279 520 106 280 522 minecraft:blue_concrete
fill 106 279 523 112 280 523 minecraft:light_blue_concrete
fill 106 279 530 111 280 537 minecraft:blue_concrete
fill 106 279 540 107 280 540 minecraft:light_blue_concrete
fill 107 279 519 107 280 521 minecraft:blue_concrete
fill 107 279 522 122 280 522 minecraft:light_blue_concrete
fill 107 279 526 107 280 527 minecraft:light_blue_concrete
fill 107 279 528 113 280 529 minecraft:blue_concrete
fill 107 279 538 113 280 539 minecraft:blue_concrete
fill 107 279 541 107 280 541 minecraft:light_blue_concrete
fill 108 279 518 109 280 520 minecraft:blue_concrete
fill 108 279 521 121 280 521 minecraft:light_blue_concrete
fill 108 279 526 108 280 526 minecraft:light_blue_concrete
fill 108 279 527 116 280 527 minecraft:blue_concrete
fill 108 279 540 116 280 541 minecraft:blue_concrete
fill 108 279 542 108 280 542 minecraft:light_blue_concrete
fill 109 279 517 126 280 517 minecraft:blue_concrete
fill 109 279 526 120 280 526 minecraft:blue_concrete
fill 109 279 542 128 280 542 minecraft:blue_concrete
fill 109 279 543 109 280 543 minecraft:light_blue_concrete
fill 110 279 518 111 280 519 minecraft:blue_concrete
fill 110 279 520 119 280 520 minecraft:light_blue_concrete
fill 110 279 525 119 280 525 minecraft:blue_concrete
fill 110 279 543 127 280 543 minecraft:blue_concrete
fill 111 279 516 125 280 516 minecraft:blue_concrete
fill 111 279 524 118 280 524 minecraft:blue_concrete
fill 111 279 544 125 280 544 minecraft:blue_concrete
fill 112 279 518 127 280 518 minecraft:blue_concrete
fill 112 279 519 117 280 519 minecraft:light_blue_concrete
fill 112 279 530 112 280 532 minecraft:blue_concrete
fill 112 279 533 115 280 533 minecraft:light_blue_concrete
fill 112 279 534 112 280 537 minecraft:blue_concrete
fill 113 279 515 123 280 515 minecraft:blue_concrete
fill 113 279 523 116 280 523 minecraft:blue_concrete
fill 113 279 530 114 280 532 minecraft:light_blue_concrete
fill 113 279 534 115 280 536 minecraft:light_blue_concrete
fill 113 279 537 113 280 537 minecraft:blue_concrete
fill 113 279 545 123 280 545 minecraft:blue_concrete
fill 114 279 528 115 280 528 minecraft:blue_concrete
fill 114 279 529 114 280 529 minecraft:light_blue_concrete
fill 114 279 537 119 280 538 minecraft:light_blue_concrete
fill 114 279 539 114 280 539 minecraft:blue_concrete
fill 115 279 529 115 279 531 minecraft:black_concrete
fill 115 279 532 115 280 532 minecraft:light_blue_concrete
fill 115 279 539 128 280 539 minecraft:light_blue_concrete
fill 116 279 528 116 279 529 minecraft:black_concrete
fill 116 279 531 116 279 532 minecraft:black_concrete
fill 116 279 533 116 280 534 minecraft:blue_concrete
fill 116 279 535 116 280 536 minecraft:light_blue_concrete
fill 117 279 523 122 280 523 minecraft:light_blue_concrete
fill 117 279 527 117 279 528 minecraft:black_concrete
fill 117 279 532 117 279 533 minecraft:black_concrete
fill 117 279 534 126 280 535 minecraft:blue_concrete
fill 117 279 536 117 280 536 minecraft:light_blue_concrete
fill 117 279 540 126 280 540 minecraft:light_blue_concrete
fill 117 279 541 118 280 541 minecraft:blue_concrete
fill 118 279 514 118 280 514 minecraft:blue_concrete
fill 118 279 519 128 280 519 minecraft:blue_concrete
fill 118 279 527 119 279 527 minecraft:black_concrete
fill 118 279 533 119 279 533 minecraft:black_concrete
fill 118 279 536 125 280 536 minecraft:blue_concrete
fill 118 279 546 118 280 546 minecraft:blue_concrete
fill 119 279 524 123 280 524 minecraft:light_blue_concrete
fill 119 279 528 120 279 528 minecraft:black_concrete
fill 119 279 532 120 279 532 minecraft:black_concrete
fill 119 279 541 124 280 541 minecraft:light_blue_concrete
fill 120 279 520 128 280 520 minecraft:blue_concrete
fill 120 279 525 123 280 525 minecraft:light_blue_concrete
fill 120 279 527 120 280 527 minecraft:blue_concrete
fill 120 279 529 121 279 529 minecraft:black_concrete
fill 120 279 531 121 279 531 minecraft:black_concrete
fill 120 279 533 128 280 533 minecraft:blue_concrete
fill 120 279 537 123 280 537 minecraft:blue_concrete
fill 120 279 538 129 280 538 minecraft:light_blue_concrete
fill 121 279 526 123 280 528 minecraft:light_blue_concrete
setblock 121 279 530 minecraft:black_concrete
fill 121 279 532 129 280 532 minecraft:blue_concrete
fill 122 279 521 129 280 521 minecraft:blue_concrete
fill 122 279 529 122 280 531 minecraft:light_blue_concrete
fill 123 279 522 129 280 523 minecraft:blue_concrete
fill 123 279 529 123 280 530 minecraft:light_blue_concrete
fill 123 279 531 129 280 531 minecraft:blue_concrete
fill 124 279 524 130 280 526 minecraft:blue_concrete
fill 124 279 527 124 280 527 minecraft:light_blue_concrete
fill 124 279 528 130 280 530 minecraft:blue_concrete
fill 124 279 537 130 280 537 minecraft:light_blue_concrete
fill 125 279 527 130 280 527 minecraft:blue_concrete
fill 125 279 541 129 280 541 minecraft:blue_concrete
fill 126 279 536 131 280 536 minecraft:light_blue_concrete
fill 127 279 517 127 280 517 minecraft:light_blue_concrete
fill 127 279 534 127 280 534 minecraft:blue_concrete
fill 127 279 535 132 280 535 minecraft:light_blue_concrete
fill 127 279 540 130 280 540 minecraft:blue_concrete
fill 128 279 518 128 280 518 minecraft:light_blue_concrete
fill 128 279 534 133 280 534 minecraft:light_blue_concrete
fill 129 279 519 129 280 520 minecraft:light_blue_concrete
fill 129 279 533 133 280 533 minecraft:light_blue_concrete
fill 129 279 539 131 280 539 minecraft:blue_concrete
fill 130 279 520 130 280 522 minecraft:light_blue_concrete
fill 130 279 523 130 280 523 minecraft:blue_concrete
fill 130 279 531 133 280 532 minecraft:light_blue_concrete
fill 130 279 538 131 280 538 minecraft:blue_concrete
fill 131 279 521 131 280 530 minecraft:light_blue_concrete
schedule function dropper:buildpart/122_11 1t
