setblock 509 221 472 minecraft:terracotta
fill 509 221 473 509 222 474 minecraft:red_terracotta
fill 509 221 490 509 221 491 minecraft:red_terracotta
setblock 509 221 492 minecraft:terracotta
fill 509 221 493 509 222 493 minecraft:red_terracotta
setblock 509 221 497 minecraft:terracotta
fill 509 221 498 509 222 498 minecraft:red_terracotta
setblock 509 221 502 minecraft:terracotta
fill 509 221 503 509 222 503 minecraft:red_terracotta
setblock 510 221 466 minecraft:terracotta
fill 510 221 467 510 222 467 minecraft:red_terracotta
setblock 510 221 471 minecraft:terracotta
fill 510 221 472 510 222 472 minecraft:red_terracotta
setblock 510 221 476 minecraft:terracotta
setblock 510 221 491 minecraft:terracotta
fill 510 221 492 510 222 492 minecraft:red_terracotta
setblock 510 221 496 minecraft:terracotta
fill 510 221 497 510 222 497 minecraft:red_terracotta
setblock 510 221 501 minecraft:terracotta
fill 510 221 502 510 222 502 minecraft:red_terracotta
setblock 511 221 465 minecraft:terracotta
fill 511 221 466 511 222 466 minecraft:red_terracotta
setblock 511 221 470 minecraft:terracotta
fill 511 221 471 511 222 471 minecraft:red_terracotta
setblock 511 221 475 minecraft:terracotta
fill 511 221 476 511 222 476 minecraft:red_terracotta
setblock 511 221 479 minecraft:red_terracotta
fill 511 221 486 511 222 486 minecraft:red_terracotta
setblock 511 221 490 minecraft:terracotta
fill 511 221 491 511 222 491 minecraft:red_terracotta
setblock 511 221 495 minecraft:terracotta
fill 511 221 496 511 222 496 minecraft:red_terracotta
setblock 511 221 500 minecraft:terracotta
fill 511 221 501 511 222 501 minecraft:red_terracotta
setblock 471 222 469 minecraft:terracotta
setblock 471 222 470 minecraft:red_terracotta
setblock 471 222 474 minecraft:terracotta
setblock 471 222 475 minecraft:red_terracotta
setblock 471 222 479 minecraft:terracotta
setblock 471 222 480 minecraft:red_terracotta
setblock 471 222 484 minecraft:terracotta
setblock 471 222 485 minecraft:red_terracotta
setblock 471 222 489 minecraft:terracotta
setblock 471 222 490 minecraft:red_terracotta
setblock 471 222 494 minecraft:terracotta
setblock 471 222 495 minecraft:red_terracotta
setblock 471 222 499 minecraft:terracotta
setblock 471 222 500 minecraft:red_terracotta
setblock 471 222 504 minecraft:terracotta
setblock 472 222 473 minecraft:terracotta
setblock 472 222 474 minecraft:red_terracotta
fill 472 222 476 472 222 477 minecraft:red_terracotta
setblock 472 222 488 minecraft:terracotta
setblock 472 222 489 minecraft:red_terracotta
setblock 472 222 493 minecraft:terracotta
setblock 472 222 494 minecraft:red_terracotta
setblock 472 222 498 minecraft:terracotta
setblock 472 222 499 minecraft:red_terracotta
setblock 472 222 504 minecraft:red_terracotta
setblock 473 222 466 minecraft:light[level=14]
setblock 473 222 474 minecraft:light[level=14]
setblock 473 222 482 minecraft:light[level=14]
setblock 473 222 490 minecraft:light[level=14]
setblock 473 222 492 minecraft:terracotta
setblock 473 222 493 minecraft:red_terracotta
setblock 473 222 497 minecraft:terracotta
setblock 473 222 498 minecraft:red_terracotta
setblock 481 222 466 minecraft:light[level=14]
setblock 481 222 474 minecraft:light[level=14]
setblock 481 222 482 minecraft:light[level=14]
setblock 481 222 490 minecraft:light[level=14]
setblock 481 222 498 minecraft:light[level=14]
setblock 484 222 464 minecraft:red_terracotta
setblock 486 222 464 minecraft:terracotta
setblock 486 222 465 minecraft:red_terracotta
setblock 486 222 504 minecraft:terracotta
fill 487 222 464 490 222 464 minecraft:red_terracotta
fill 487 222 504 489 222 504 minecraft:red_terracotta
setblock 489 222 466 minecraft:light[level=14]
setblock 489 222 474 minecraft:light[level=14]
setblock 489 222 482 minecraft:light[level=14]
setblock 489 222 490 minecraft:light[level=14]
setblock 489 222 498 minecraft:light[level=14]
setblock 490 222 465 minecraft:terracotta
setblock 491 222 464 minecraft:terracotta
setblock 491 222 465 minecraft:red_terracotta
setblock 492 222 464 minecraft:red_terracotta
setblock 496 222 464 minecraft:terracotta
setblock 497 222 464 minecraft:red_terracotta
setblock 497 222 466 minecraft:light[level=14]
setblock 497 222 474 minecraft:light[level=14]
setblock 497 222 482 minecraft:light[level=14]
setblock 497 222 490 minecraft:light[level=14]
setblock 497 222 498 minecraft:light[level=14]
setblock 501 222 464 minecraft:terracotta
setblock 501 222 504 minecraft:terracotta
setblock 502 222 464 minecraft:red_terracotta
setblock 502 222 504 minecraft:red_terracotta
setblock 503 222 503 minecraft:red_terracotta
setblock 505 222 465 minecraft:terracotta
setblock 505 222 466 minecraft:red_terracotta
setblock 505 222 474 minecraft:light[level=14]
setblock 505 222 482 minecraft:light[level=14]
setblock 505 222 490 minecraft:light[level=14]
fill 505 222 502 507 222 502 minecraft:red_terracotta
setblock 506 222 464 minecraft:terracotta
setblock 506 222 465 minecraft:red_terracotta
setblock 506 222 504 minecraft:terracotta
setblock 507 222 464 minecraft:red_terracotta
setblock 507 222 503 minecraft:terracotta
setblock 507 222 504 minecraft:red_terracotta
fill 508 222 493 508 222 496 minecraft:red_terracotta
setblock 508 222 497 minecraft:terracotta
fill 508 222 498 508 222 500 minecraft:red_terracotta
setblock 508 222 502 minecraft:terracotta
setblock 508 222 503 minecraft:red_terracotta
setblock 509 222 471 minecraft:terracotta
setblock 509 222 472 minecraft:red_terracotta
setblock 509 222 475 minecraft:red_terracotta
setblock 509 222 491 minecraft:terracotta
setblock 509 222 492 minecraft:red_terracotta
setblock 509 222 496 minecraft:terracotta
setblock 509 222 497 minecraft:red_terracotta
fill 509 222 499 509 222 500 minecraft:red_terracotta
setblock 509 222 501 minecraft:terracotta
setblock 509 222 502 minecraft:red_terracotta
setblock 510 222 465 minecraft:terracotta
setblock 510 222 466 minecraft:red_terracotta
setblock 510 222 470 minecraft:terracotta
setblock 510 222 471 minecraft:red_terracotta
setblock 510 222 474 minecraft:red_terracotta
setblock 510 222 475 minecraft:terracotta
fill 510 222 476 510 222 477 minecraft:red_terracotta
setblock 510 222 490 minecraft:terracotta
setblock 510 222 491 minecraft:red_terracotta
setblock 510 222 495 minecraft:terracotta
setblock 510 222 496 minecraft:red_terracotta
setblock 510 222 500 minecraft:terracotta
setblock 510 222 501 minecraft:red_terracotta
setblock 511 222 464 minecraft:terracotta
setblock 511 222 465 minecraft:red_terracotta
setblock 511 222 469 minecraft:terracotta
setblock 511 222 470 minecraft:red_terracotta
setblock 511 222 474 minecraft:terracotta
setblock 511 222 475 minecraft:red_terracotta
setblock 511 222 479 minecraft:terracotta
setblock 511 222 480 minecraft:red_terracotta
setblock 511 222 489 minecraft:terracotta
setblock 511 222 490 minecraft:red_terracotta
setblock 511 222 494 minecraft:terracotta
setblock 511 222 495 minecraft:red_terracotta
setblock 511 222 499 minecraft:terracotta
setblock 511 222 500 minecraft:red_terracotta
setblock 511 222 504 minecraft:terracotta
setblock 470 226 489 minecraft:orange_terracotta
setblock 473 226 505 minecraft:orange_terracotta
fill 474 226 505 478 229 505 minecraft:red_terracotta
setblock 479 226 505 minecraft:orange_terracotta
fill 480 226 505 480 229 505 minecraft:red_terracotta
fill 482 226 505 488 227 505 minecraft:red_terracotta
setblock 489 226 505 minecraft:orange_terracotta
fill 490 226 505 500 227 505 minecraft:red_terracotta
fill 494 226 463 495 227 463 minecraft:red_terracotta
fill 496 226 463 497 226 463 minecraft:orange_terracotta
setblock 501 226 505 minecraft:orange_terracotta
fill 502 226 463 502 227 463 minecraft:orange_terracotta
fill 503 226 463 503 229 463 minecraft:red_terracotta
fill 507 226 505 507 227 505 minecraft:orange_terracotta
setblock 508 226 463 minecraft:orange_terracotta
fill 509 226 463 510 229 463 minecraft:red_terracotta
setblock 512 226 476 minecraft:orange_terracotta
fill 512 226 477 512 226 480 minecraft:red_terracotta
setblock 512 226 481 minecraft:orange_terracotta
setblock 512 226 486 minecraft:orange_terracotta
setblock 512 226 487 minecraft:red_terracotta
fill 470 227 471 470 227 472 minecraft:red_terracotta
setblock 470 227 473 minecraft:orange_terracotta
fill 470 227 474 470 229 474 minecraft:red_terracotta
fill 470 227 475 470 228 475 minecraft:orange_terracotta
fill 470 227 476 470 229 479 minecraft:red_terracotta
setblock 470 227 480 minecraft:orange_terracotta
fill 470 227 481 470 229 484 minecraft:red_terracotta
fill 470 227 489 470 229 489 minecraft:red_terracotta
setblock 470 227 501 minecraft:orange_terracotta
fill 470 227 502 470 229 502 minecraft:red_terracotta
fill 472 227 463 475 229 463 minecraft:red_terracotta
setblock 473 227 505 minecraft:red_terracotta
fill 476 227 463 476 228 463 minecraft:orange_terracotta
fill 478 227 463 479 227 463 minecraft:red_terracotta
fill 479 227 505 479 229 505 minecraft:red_terracotta
setblock 480 227 463 minecraft:orange_terracotta
fill 481 227 463 481 229 463 minecraft:red_terracotta
setblock 489 227 505 minecraft:red_terracotta
setblock 493 227 463 minecraft:orange_terracotta
fill 496 227 463 497 229 463 minecraft:red_terracotta
fill 501 227 505 501 229 505 minecraft:red_terracotta
fill 508 227 463 508 229 463 minecraft:red_terracotta
fill 512 227 469 512 229 469 minecraft:red_terracotta
setblock 512 227 470 minecraft:orange_terracotta
fill 512 227 476 512 229 477 minecraft:red_terracotta
setblock 512 227 478 minecraft:orange_terracotta
fill 512 227 479 512 227 481 minecraft:red_terracotta
fill 512 227 486 512 229 486 minecraft:red_terracotta
setblock 512 227 487 minecraft:orange_terracotta
fill 512 227 496 512 229 496 minecraft:red_terracotta
fill 512 227 497 512 227 498 minecraft:orange_terracotta
setblock 512 227 499 minecraft:red_terracotta
setblock 512 227 500 minecraft:orange_terracotta
fill 512 227 501 512 229 502 minecraft:red_terracotta
fill 470 228 463 470 230 463 minecraft:red_terracotta
setblock 470 228 464 minecraft:orange_terracotta
fill 470 228 465 470 229 465 minecraft:red_terracotta
fill 470 228 471 470 228 472 minecraft:orange_terracotta
fill 470 228 473 470 229 473 minecraft:red_terracotta
fill 470 228 480 470 229 480 minecraft:red_terracotta
fill 470 228 493 470 229 495 minecraft:red_terracotta
setblock 470 228 496 minecraft:orange_terracotta
fill 470 228 497 470 229 498 minecraft:red_terracotta
setblock 470 228 499 minecraft:orange_terracotta
fill 470 228 501 470 229 501 minecraft:red_terracotta
fill 470 228 503 470 229 503 minecraft:red_terracotta
fill 470 228 504 470 228 505 minecraft:orange_terracotta
fill 472 228 484 487 228 490 minecraft:terracotta
setblock 473 228 505 minecraft:orange_terracotta
setblock 477 228 463 minecraft:orange_terracotta
fill 478 228 463 478 229 463 minecraft:red_terracotta
setblock 479 228 463 minecraft:orange_terracotta
fill 480 228 463 480 229 463 minecraft:red_terracotta
fill 482 228 505 486 229 505 minecraft:red_terracotta
fill 483 228 463 483 229 463 minecraft:red_terracotta
setblock 484 228 463 minecraft:orange_terracotta
fill 485 228 463 487 229 463 minecraft:red_terracotta
fill 487 228 469 493 228 483 minecraft:terracotta
fill 487 228 491 493 228 505 minecraft:terracotta
fill 488 228 484 488 228 486 minecraft:terracotta
fill 488 228 488 488 228 490 minecraft:terracotta
fill 489 228 484 489 228 485 minecraft:terracotta
fill 489 228 489 489 228 490 minecraft:terracotta
fill 490 228 484 508 228 484 minecraft:terracotta
fill 490 228 490 508 228 490 minecraft:terracotta
fill 491 228 485 508 228 485 minecraft:terracotta
fill 491 228 489 508 228 489 minecraft:terracotta
fill 492 228 486 508 228 486 minecraft:terracotta
fill 492 228 488 508 228 488 minecraft:terracotta
fill 493 228 463 494 229 463 minecraft:red_terracotta
fill 493 228 487 508 228 487 minecraft:terracotta
setblock 494 228 505 minecraft:orange_terracotta
setblock 495 228 463 minecraft:orange_terracotta
fill 495 228 505 500 229 505 minecraft:red_terracotta
fill 502 228 463 502 229 463 minecraft:red_terracotta
setblock 502 228 505 minecraft:orange_terracotta
setblock 505 228 505 minecraft:orange_terracotta
fill 506 228 505 507 229 505 minecraft:red_terracotta
fill 512 228 470 512 229 470 minecraft:red_terracotta
fill 512 228 478 512 229 480 minecraft:red_terracotta
setblock 512 228 481 minecraft:orange_terracotta
fill 512 228 482 512 229 482 minecraft:red_terracotta
setblock 512 228 483 minecraft:orange_terracotta
fill 512 228 487 512 229 487 minecraft:red_terracotta
fill 512 228 497 512 229 498 minecraft:red_terracotta
setblock 512 228 499 minecraft:orange_terracotta
fill 512 228 500 512 229 500 minecraft:red_terracotta
fill 512 228 503 512 229 503 minecraft:red_terracotta
setblock 512 228 504 minecraft:orange_terracotta
setblock 470 229 464 minecraft:red_terracotta
fill 470 229 471 470 229 472 minecraft:red_terracotta
fill 470 229 475 470 232 475 minecraft:red_terracotta
setblock 470 229 496 minecraft:red_terracotta
setblock 470 229 499 minecraft:red_terracotta
fill 470 229 504 470 229 505 minecraft:red_terracotta
fill 471 229 464 471 229 504 minecraft:brown_terracotta
fill 472 229 464 486 229 483 minecraft:brown_terracotta
fill 472 229 484 488 229 484 minecraft:orange_terracotta
fill 472 229 485 486 229 489 minecraft:terracotta
fill 472 229 490 488 229 490 minecraft:orange_terracotta
fill 472 229 491 486 229 504 minecraft:brown_terracotta
setblock 473 229 505 minecraft:red_terracotta
fill 476 229 463 477 229 463 minecraft:red_terracotta
setblock 479 229 463 minecraft:red_terracotta
setblock 484 229 463 minecraft:red_terracotta
fill 487 229 464 511 229 468 minecraft:brown_terracotta
fill 487 229 469 487 229 483 minecraft:orange_terracotta
setblock 487 229 485 minecraft:orange_terracotta
fill 487 229 486 487 229 488 minecraft:shroomlight
setblock 487 229 489 minecraft:orange_terracotta
fill 487 229 491 487 229 505 minecraft:orange_terracotta
fill 488 229 469 492 229 483 minecraft:terracotta
fill 488 229 485 488 229 486 minecraft:shroomlight
fill 488 229 488 488 229 489 minecraft:shroomlight
fill 488 229 491 492 229 505 minecraft:terracotta
fill 489 229 484 489 229 485 minecraft:shroomlight
fill 489 229 489 489 229 490 minecraft:shroomlight
fill 490 229 484 491 229 484 minecraft:shroomlight
fill 490 229 490 491 229 490 minecraft:shroomlight
fill 491 229 485 492 229 485 minecraft:shroomlight
fill 491 229 489 492 229 489 minecraft:shroomlight
fill 492 229 484 508 229 484 minecraft:orange_terracotta
fill 492 229 486 493 229 486 minecraft:shroomlight
fill 492 229 488 493 229 488 minecraft:shroomlight
fill 492 229 490 508 229 490 minecraft:orange_terracotta
fill 493 229 469 493 229 483 minecraft:orange_terracotta
setblock 493 229 485 minecraft:orange_terracotta
setblock 493 229 487 minecraft:shroomlight
setblock 493 229 489 minecraft:orange_terracotta
fill 493 229 491 493 229 505 minecraft:orange_terracotta
fill 494 229 469 511 229 483 minecraft:brown_terracotta
fill 494 229 485 508 229 489 minecraft:terracotta
fill 494 229 491 511 229 504 minecraft:brown_terracotta
setblock 494 229 505 minecraft:red_terracotta
setblock 495 229 463 minecraft:red_terracotta
setblock 502 229 505 minecraft:red_terracotta
setblock 505 229 505 minecraft:red_terracotta
fill 509 229 484 511 229 490 minecraft:brown_terracotta
setblock 512 229 481 minecraft:red_terracotta
fill 512 229 483 512 230 483 minecraft:red_terracotta
fill 512 229 499 512 230 499 minecraft:red_terracotta
setblock 512 229 504 minecraft:red_terracotta
fill 470 230 464 470 307 474 minecraft:orange_terracotta
fill 470 230 476 470 230 485 minecraft:orange_terracotta
setblock 470 230 487 minecraft:red_terracotta
fill 470 230 488 470 230 505 minecraft:orange_terracotta
fill 471 230 463 474 307 463 minecraft:orange_terracotta
fill 471 230 474 471 230 500 minecraft:basalt
fill 471 230 505 480 230 505 minecraft:orange_terracotta
fill 472 230 472 474 230 472 minecraft:basalt
setblock 472 230 473 minecraft:magma_block
fill 472 230 474 474 231 475 minecraft:basalt
setblock 472 230 476 minecraft:magma_block
fill 472 230 477 474 232 478 minecraft:basalt
setblock 472 230 479 minecraft:magma_block
fill 472 230 480 474 234 481 minecraft:basalt
setblock 472 230 482 minecraft:magma_block
fill 472 230 483 474 235 484 minecraft:basalt
setblock 472 230 485 minecraft:magma_block
fill 472 230 486 474 235 487 minecraft:basalt
setblock 472 230 488 minecraft:magma_block
fill 472 230 489 474 235 490 minecraft:basalt
setblock 472 230 491 minecraft:magma_block
fill 472 230 492 474 235 493 minecraft:basalt
setblock 472 230 494 minecraft:magma_block
fill 472 230 495 474 232 496 minecraft:basalt
setblock 472 230 497 minecraft:magma_block
fill 472 230 498 474 232 499 minecraft:basalt
setblock 472 230 500 minecraft:magma_block
fill 472 230 501 474 230 502 minecraft:basalt
setblock 473 230 466 minecraft:light[level=14]
fill 473 230 471 477 230 471 minecraft:basalt
fill 473 230 473 480 231 473 minecraft:basalt
fill 473 230 476 480 233 476 minecraft:basalt
fill 473 230 479 477 235 479 minecraft:basalt
fill 473 230 482 476 236 482 minecraft:basalt
fill 473 230 485 475 237 485 minecraft:basalt
fill 473 230 488 475 237 488 minecraft:basalt
fill 473 230 491 475 236 491 minecraft:basalt
fill 473 230 494 477 230 494 minecraft:basalt
fill 473 230 497 479 234 497 minecraft:basalt
fill 473 230 500 480 231 500 minecraft:basalt
fill 473 230 503 480 230 503 minecraft:basalt
fill 474 230 470 480 230 470 minecraft:basalt
fill 474 230 504 477 230 504 minecraft:basalt
setblock 475 230 463 minecraft:red_terracotta
setblock 475 230 469 minecraft:magma_block
setblock 475 230 472 minecraft:magma_block
fill 475 230 474 477 234 474 minecraft:basalt
setblock 475 230 475 minecraft:magma_block
fill 475 230 477 477 236 477 minecraft:basalt
setblock 475 230 478 minecraft:magma_block
fill 475 230 480 477 238 480 minecraft:basalt
setblock 475 230 481 minecraft:magma_block
fill 475 230 483 475 239 483 minecraft:basalt
setblock 475 230 484 minecraft:magma_block
fill 475 230 486 475 239 486 minecraft:basalt
setblock 475 230 487 minecraft:magma_block
fill 475 230 489 475 239 489 minecraft:basalt
setblock 475 230 490 minecraft:magma_block
fill 475 230 492 476 238 492 minecraft:basalt
setblock 475 230 493 minecraft:magma_block
fill 475 230 495 477 237 495 minecraft:basalt
setblock 475 230 496 minecraft:magma_block
fill 475 230 498 477 235 498 minecraft:basalt
setblock 475 230 499 minecraft:magma_block
fill 475 230 501 477 232 501 minecraft:basalt
setblock 475 230 502 minecraft:magma_block
fill 476 230 463 499 230 463 minecraft:orange_terracotta
fill 476 230 469 483 230 469 minecraft:basalt
fill 476 230 472 483 233 472 minecraft:basalt
fill 476 230 475 481 235 475 minecraft:basalt
fill 476 230 478 478 237 478 minecraft:basalt
fill 476 230 481 476 239 481 minecraft:basalt
fill 476 230 493 476 239 493 minecraft:basalt
fill 476 230 496 478 237 496 minecraft:basalt
fill 476 230 499 481 235 499 minecraft:basalt
fill 476 230 502 483 233 502 minecraft:basalt
setblock 477 230 468 minecraft:basalt
fill 478 230 467 480 230 467 minecraft:basalt
setblock 478 230 468 minecraft:magma_block
setblock 478 230 471 minecraft:magma_block
setblock 478 230 474 minecraft:magma_block
setblock 478 230 477 minecraft:magma_block
setblock 478 230 498 minecraft:magma_block
setblock 478 230 501 minecraft:magma_block
setblock 478 230 504 minecraft:magma_block
fill 479 230 468 486 231 468 minecraft:basalt
fill 479 230 471 486 234 471 minecraft:basalt
fill 479 230 474 483 230 474 minecraft:basalt
fill 479 230 477 479 239 477 minecraft:basalt
fill 479 230 498 480 239 498 minecraft:basalt
fill 479 230 501 485 236 501 minecraft:basalt
fill 479 230 504 486 233 504 minecraft:basalt
fill 480 230 466 483 230 466 minecraft:basalt
setblock 481 230 467 minecraft:magma_block
setblock 481 230 470 minecraft:magma_block
setblock 481 230 473 minecraft:magma_block
setblock 481 230 482 minecraft:light[level=14]
setblock 481 230 490 minecraft:light[level=14]
setblock 481 230 498 minecraft:light[level=14]
setblock 481 230 500 minecraft:magma_block
setblock 481 230 503 minecraft:magma_block
fill 482 230 465 486 230 465 minecraft:basalt
fill 482 230 467 489 231 467 minecraft:basalt
fill 482 230 470 489 235 470 minecraft:basalt
fill 482 230 473 485 238 473 minecraft:basalt
fill 482 230 500 483 239 500 minecraft:basalt
fill 482 230 503 489 236 503 minecraft:basalt
fill 482 230 505 491 230 505 minecraft:orange_terracotta
setblock 484 230 466 minecraft:magma_block
setblock 484 230 469 minecraft:magma_block
setblock 484 230 472 minecraft:magma_block
setblock 484 230 502 minecraft:magma_block
fill 485 230 464 489 230 464 minecraft:basalt
fill 485 230 466 492 231 466 minecraft:basalt
fill 485 230 469 492 235 469 minecraft:basalt
fill 485 230 472 492 230 472 minecraft:basalt
fill 485 230 502 492 230 502 minecraft:basalt
setblock 487 230 465 minecraft:magma_block
setblock 487 230 468 minecraft:magma_block
setblock 487 230 471 minecraft:magma_block
setblock 487 230 504 minecraft:magma_block
fill 488 230 465 495 230 465 minecraft:basalt
fill 488 230 468 495 234 468 minecraft:basalt
fill 488 230 471 495 236 471 minecraft:basalt
fill 488 230 504 495 236 504 minecraft:basalt
setblock 489 230 474 minecraft:light[level=14]
setblock 489 230 482 minecraft:light[level=14]
setblock 489 230 490 minecraft:light[level=14]
setblock 489 230 498 minecraft:light[level=14]
setblock 490 230 464 minecraft:magma_block
setblock 490 230 467 minecraft:magma_block
setblock 490 230 470 minecraft:magma_block
setblock 490 230 503 minecraft:magma_block
fill 491 230 464 495 230 464 minecraft:basalt
fill 491 230 467 498 232 467 minecraft:basalt
fill 491 230 470 498 234 470 minecraft:basalt
fill 491 230 503 498 236 503 minecraft:basalt
fill 492 230 505 492 231 505 minecraft:red_terracotta
setblock 493 230 466 minecraft:magma_block
setblock 493 230 469 minecraft:magma_block
setblock 493 230 472 minecraft:magma_block
setblock 493 230 502 minecraft:magma_block
fill 493 230 505 494 307 505 minecraft:orange_terracotta
fill 494 230 466 500 230 466 minecraft:basalt
fill 494 230 469 501 232 469 minecraft:basalt
fill 494 230 472 501 235 472 minecraft:basalt
fill 494 230 502 501 235 502 minecraft:basalt
fill 495 230 473 498 230 473 minecraft:basalt
fill 495 230 501 495 239 501 minecraft:basalt
setblock 495 230 505 minecraft:red_terracotta
setblock 496 230 465 minecraft:magma_block
setblock 496 230 468 minecraft:magma_block
setblock 496 230 471 minecraft:magma_block
setblock 496 230 501 minecraft:magma_block
setblock 496 230 504 minecraft:magma_block
fill 496 230 505 498 230 505 minecraft:orange_terracotta
fill 497 230 465 498 230 465 minecraft:basalt
fill 497 230 468 503 230 468 minecraft:basalt
fill 497 230 471 504 232 471 minecraft:basalt
fill 497 230 474 504 234 474 minecraft:basalt
setblock 497 230 482 minecraft:light[level=14]
setblock 497 230 490 minecraft:light[level=14]
setblock 497 230 498 minecraft:light[level=14]
fill 497 230 500 498 238 501 minecraft:basalt
fill 497 230 504 504 231 504 minecraft:basalt
setblock 499 230 467 minecraft:magma_block
setblock 499 230 470 minecraft:magma_block
setblock 499 230 473 minecraft:magma_block
fill 499 230 475 501 238 475 minecraft:basalt
fill 499 230 499 501 238 499 minecraft:basalt
setblock 499 230 500 minecraft:magma_block
fill 499 230 501 504 234 501 minecraft:basalt
setblock 499 230 503 minecraft:magma_block
setblock 499 230 505 minecraft:red_terracotta
setblock 500 230 463 minecraft:red_terracotta
fill 500 230 467 502 230 467 minecraft:basalt
fill 500 230 470 506 230 470 minecraft:basalt
fill 500 230 473 507 231 473 minecraft:basalt
fill 500 230 476 507 233 476 minecraft:basalt
fill 500 230 498 504 236 498 minecraft:basalt
fill 500 230 500 507 232 500 minecraft:basalt
fill 500 230 503 507 230 503 minecraft:basalt
fill 500 230 505 506 231 505 minecraft:orange_terracotta
fill 501 230 463 504 230 463 minecraft:orange_terracotta
fill 501 230 477 504 236 477 minecraft:basalt
fill 501 230 497 507 234 497 minecraft:basalt
setblock 502 230 469 minecraft:magma_block
setblock 502 230 472 minecraft:magma_block
setblock 502 230 475 minecraft:magma_block
setblock 502 230 478 minecraft:magma_block
setblock 502 230 496 minecraft:magma_block
setblock 502 230 499 minecraft:magma_block
setblock 502 230 502 minecraft:magma_block
fill 503 230 469 505 230 469 minecraft:basalt
fill 503 230 472 508 230 472 minecraft:basalt
fill 503 230 475 510 230 475 minecraft:basalt
fill 503 230 478 504 237 480 minecraft:basalt
fill 503 230 494 504 237 496 minecraft:basalt
fill 503 230 499 510 230 499 minecraft:basalt
fill 503 230 502 508 230 502 minecraft:basalt
fill 504 230 481 507 230 482 minecraft:basalt
fill 504 230 492 504 239 493 minecraft:basalt
setblock 505 230 463 minecraft:red_terracotta
setblock 505 230 466 minecraft:light[level=14]
setblock 505 230 471 minecraft:magma_block
setblock 505 230 474 minecraft:magma_block
setblock 505 230 477 minecraft:magma_block
fill 505 230 478 507 234 479 minecraft:basalt
setblock 505 230 480 minecraft:magma_block
setblock 505 230 483 minecraft:magma_block
fill 505 230 484 507 236 485 minecraft:basalt
setblock 505 230 486 minecraft:magma_block
fill 505 230 487 507 236 488 minecraft:basalt
setblock 505 230 489 minecraft:magma_block
fill 505 230 490 507 236 491 minecraft:basalt
setblock 505 230 492 minecraft:magma_block
fill 505 230 493 507 235 494 minecraft:basalt
setblock 505 230 495 minecraft:magma_block
fill 505 230 496 510 231 496 minecraft:basalt
setblock 505 230 498 minecraft:magma_block
setblock 505 230 501 minecraft:magma_block
setblock 505 230 504 minecraft:magma_block
fill 506 230 463 511 231 463 minecraft:orange_terracotta
fill 506 230 471 507 230 471 minecraft:basalt
fill 506 230 474 509 230 474 minecraft:basalt
fill 506 230 477 511 230 477 minecraft:basalt
fill 506 230 480 511 231 480 minecraft:basalt
fill 506 230 483 511 232 483 minecraft:basalt
fill 506 230 486 511 232 486 minecraft:basalt
fill 506 230 489 511 232 489 minecraft:basalt
fill 506 230 492 511 232 492 minecraft:basalt
fill 506 230 495 511 231 495 minecraft:basalt
fill 506 230 498 510 230 498 minecraft:basalt
fill 506 230 501 508 230 501 minecraft:basalt
setblock 506 230 504 minecraft:basalt
setblock 507 230 505 minecraft:red_terracotta
setblock 508 230 473 minecraft:magma_block
setblock 508 230 476 minecraft:magma_block
fill 508 230 478 510 231 478 minecraft:basalt
setblock 508 230 479 minecraft:magma_block
fill 508 230 481 510 233 481 minecraft:basalt
setblock 508 230 482 minecraft:magma_block
fill 508 230 484 510 233 484 minecraft:basalt
setblock 508 230 485 minecraft:magma_block
fill 508 230 487 510 234 487 minecraft:basalt
setblock 508 230 488 minecraft:magma_block
fill 508 230 490 510 233 490 minecraft:basalt
setblock 508 230 491 minecraft:magma_block
fill 508 230 493 510 233 493 minecraft:basalt
setblock 508 230 494 minecraft:magma_block
setblock 508 230 497 minecraft:magma_block
setblock 508 230 500 minecraft:magma_block
fill 508 230 505 508 307 505 minecraft:orange_terracotta
fill 509 230 476 510 230 476 minecraft:basalt
fill 509 230 479 511 231 479 minecraft:basalt
fill 509 230 482 511 232 482 minecraft:basalt
fill 509 230 485 511 232 485 minecraft:basalt
fill 509 230 488 511 232 488 minecraft:basalt
fill 509 230 491 511 232 491 minecraft:basalt
fill 509 230 494 511 231 494 minecraft:basalt
fill 509 230 497 511 230 497 minecraft:basalt
setblock 509 230 500 minecraft:basalt
fill 510 230 505 511 231 505 minecraft:orange_terracotta
setblock 511 230 478 minecraft:magma_block
setblock 511 230 481 minecraft:magma_block
setblock 511 230 484 minecraft:magma_block
setblock 511 230 487 minecraft:magma_block
setblock 511 230 490 minecraft:magma_block
setblock 511 230 493 minecraft:magma_block
setblock 511 230 496 minecraft:magma_block
fill 512 230 464 512 231 472 minecraft:orange_terracotta
setblock 512 230 473 minecraft:red_terracotta
fill 512 230 474 512 231 482 minecraft:orange_terracotta
fill 512 230 484 512 231 488 minecraft:orange_terracotta
fill 512 230 490 512 231 498 minecraft:orange_terracotta
fill 512 230 500 512 307 504 minecraft:orange_terracotta
fill 512 230 505 512 231 505 minecraft:red_terracotta
fill 470 231 463 470 307 463 minecraft:orange_terracotta
fill 470 231 476 470 231 482 minecraft:orange_terracotta
setblock 470 231 483 minecraft:red_terracotta
fill 470 231 484 470 307 488 minecraft:orange_terracotta
fill 470 231 489 470 232 489 minecraft:red_terracotta
fill 470 231 490 470 307 491 minecraft:orange_terracotta
fill 470 231 492 470 231 494 minecraft:red_terracotta
fill 470 231 495 470 307 505 minecraft:orange_terracotta
setblock 471 231 475 minecraft:magma_block
fill 471 231 476 471 231 498 minecraft:basalt
setblock 471 231 499 minecraft:magma_block
fill 471 231 505 474 307 505 minecraft:orange_terracotta
fill 472 231 476 472 232 476 minecraft:basalt
fill 472 231 479 472 234 479 minecraft:basalt
fill 472 231 482 472 235 482 minecraft:basalt
fill 472 231 485 472 236 485 minecraft:basalt
fill 472 231 488 472 236 488 minecraft:basalt
fill 472 231 491 472 235 491 minecraft:basalt
fill 472 231 494 476 234 494 minecraft:basalt
fill 472 231 497 472 233 497 minecraft:basalt
setblock 472 231 500 minecraft:basalt
fill 473 231 472 475 231 472 minecraft:basalt
fill 473 231 501 474 231 502 minecraft:basalt
setblock 474 231 471 minecraft:magma_block
fill 474 231 503 481 231 503 minecraft:basalt
fill 475 231 463 488 307 463 minecraft:orange_terracotta
fill 475 231 470 478 231 471 minecraft:basalt
fill 475 231 475 475 234 475 minecraft:basalt
fill 475 231 478 475 236 478 minecraft:basalt
fill 475 231 481 475 238 481 minecraft:basalt
fill 475 231 484 476 231 484 minecraft:basalt
fill 475 231 487 475 238 487 minecraft:basalt
fill 475 231 490 476 231 490 minecraft:basalt
fill 475 231 493 475 238 493 minecraft:basalt
fill 475 231 496 475 236 496 minecraft:basalt
fill 475 231 499 475 234 499 minecraft:basalt
fill 475 231 502 475 232 502 minecraft:basalt
fill 475 231 504 478 231 504 minecraft:basalt
setblock 475 231 505 minecraft:red_terracotta
fill 476 231 483 476 240 483 minecraft:basalt
fill 476 231 485 476 240 485 minecraft:basalt
fill 476 231 489 476 240 489 minecraft:basalt
fill 476 231 491 476 240 491 minecraft:basalt
fill 476 231 505 478 307 505 minecraft:orange_terracotta
fill 477 231 469 484 231 469 minecraft:basalt
fill 477 231 481 477 240 481 minecraft:basalt
fill 477 231 493 477 240 493 minecraft:basalt
setblock 477 231 494 minecraft:magma_block
setblock 478 231 468 minecraft:basalt
fill 478 231 474 482 236 474 minecraft:basalt
fill 478 231 477 478 238 477 minecraft:basalt
fill 478 231 479 478 240 479 minecraft:basalt
fill 478 231 495 478 240 495 minecraft:basalt
fill 478 231 498 478 238 498 minecraft:basalt
fill 478 231 501 478 235 501 minecraft:basalt
fill 479 231 470 481 233 470 minecraft:basalt
fill 479 231 478 479 240 478 minecraft:basalt
fill 479 231 496 479 240 496 minecraft:basalt
setblock 479 231 505 minecraft:red_terracotta
fill 480 231 467 481 231 467 minecraft:basalt
fill 480 231 477 480 240 477 minecraft:basalt
fill 480 231 497 480 240 497 minecraft:basalt
fill 480 231 505 481 231 505 minecraft:orange_terracotta
fill 481 231 473 481 237 473 minecraft:basalt
fill 481 231 476 481 240 476 minecraft:basalt
fill 481 231 498 481 240 498 minecraft:basalt
fill 481 231 500 481 238 500 minecraft:basalt
fill 482 231 466 484 231 466 minecraft:basalt
fill 482 231 475 482 240 475 minecraft:basalt
fill 482 231 499 482 240 499 minecraft:basalt
setblock 482 231 505 minecraft:red_terracotta
setblock 483 231 474 minecraft:magma_block
fill 483 231 505 488 231 505 minecraft:orange_terracotta
fill 484 231 472 488 238 472 minecraft:basalt
fill 484 231 474 484 240 474 minecraft:basalt
fill 484 231 500 484 240 500 minecraft:basalt
fill 484 231 502 488 238 502 minecraft:basalt
fill 485 231 465 491 231 465 minecraft:basalt
setblock 486 231 473 minecraft:magma_block
fill 486 231 501 488 231 501 minecraft:basalt
fill 487 231 468 487 234 468 minecraft:basalt
fill 487 231 471 487 238 471 minecraft:basalt
fill 487 231 473 488 240 473 minecraft:basalt
fill 487 231 504 487 237 504 minecraft:basalt
setblock 489 231 463 minecraft:red_terracotta
setblock 489 231 472 minecraft:magma_block
setblock 489 231 502 minecraft:magma_block
fill 489 231 505 489 232 505 minecraft:red_terracotta
fill 490 231 463 500 231 463 minecraft:orange_terracotta
fill 490 231 467 490 234 467 minecraft:basalt
fill 490 231 470 490 237 470 minecraft:basalt
fill 490 231 472 493 238 472 minecraft:basalt
fill 490 231 502 490 238 503 minecraft:basalt
fill 490 231 505 491 307 505 minecraft:orange_terracotta
fill 491 231 502 493 238 502 minecraft:basalt
setblock 492 231 465 minecraft:magma_block
fill 492 231 473 494 240 473 minecraft:basalt
setblock 492 231 501 minecraft:magma_block
fill 493 231 465 495 231 466 minecraft:basalt
fill 493 231 469 493 236 469 minecraft:basalt
fill 493 231 501 494 240 501 minecraft:basalt
setblock 495 231 473 minecraft:magma_block
fill 495 231 505 496 307 505 minecraft:orange_terracotta
fill 496 231 466 497 231 466 minecraft:basalt
fill 496 231 468 500 232 468 minecraft:basalt
fill 496 231 471 496 237 471 minecraft:basalt
fill 496 231 473 496 239 474 minecraft:basalt
fill 496 231 500 496 238 501 minecraft:basalt
fill 496 231 504 496 236 504 minecraft:basalt
fill 497 231 473 499 237 473 minecraft:basalt
setblock 497 231 505 minecraft:red_terracotta
setblock 498 231 466 minecraft:magma_block
setblock 498 231 475 minecraft:magma_block
setblock 498 231 499 minecraft:magma_block
fill 498 231 505 499 231 505 minecraft:orange_terracotta
fill 499 231 467 500 231 467 minecraft:basalt
fill 499 231 470 503 232 470 minecraft:basalt
fill 499 231 476 499 240 476 minecraft:basalt
fill 499 231 498 499 240 498 minecraft:basalt
fill 499 231 500 499 238 500 minecraft:basalt
fill 499 231 503 506 231 503 minecraft:basalt
fill 500 231 477 500 240 477 minecraft:basalt
fill 500 231 497 500 240 497 minecraft:basalt
setblock 501 231 463 minecraft:red_terracotta
setblock 501 231 468 minecraft:magma_block
fill 501 231 478 502 238 478 minecraft:basalt
fill 501 231 496 502 238 496 minecraft:basalt
fill 502 231 463 505 307 463 minecraft:orange_terracotta
fill 502 231 468 502 231 469 minecraft:basalt
fill 502 231 472 506 231 472 minecraft:basalt
fill 502 231 475 509 231 475 minecraft:basalt
fill 502 231 479 502 240 479 minecraft:basalt
fill 502 231 495 502 240 495 minecraft:basalt
fill 502 231 499 509 231 499 minecraft:basalt
fill 502 231 502 506 231 502 minecraft:basalt
setblock 503 231 469 minecraft:basalt
fill 503 231 481 507 231 481 minecraft:basalt
setblock 503 231 493 minecraft:basalt
setblock 504 231 470 minecraft:magma_block
setblock 504 231 482 minecraft:magma_block
fill 504 231 483 504 240 484 minecraft:basalt
setblock 504 231 485 minecraft:magma_block
fill 504 231 489 504 240 490 minecraft:basalt
setblock 504 231 491 minecraft:magma_block
fill 505 231 470 505 231 471 minecraft:basalt
fill 505 231 474 508 231 474 minecraft:basalt
fill 505 231 477 509 232 477 minecraft:basalt
fill 505 231 480 505 238 480 minecraft:basalt
fill 505 231 482 505 238 483 minecraft:basalt
fill 505 231 486 505 238 486 minecraft:basalt
fill 505 231 489 505 238 489 minecraft:basalt
fill 505 231 492 505 238 492 minecraft:basalt
fill 505 231 495 505 237 495 minecraft:basalt
fill 505 231 498 509 231 498 minecraft:basalt
fill 505 231 501 507 231 501 minecraft:basalt
setblock 505 231 504 minecraft:basalt
setblock 506 231 471 minecraft:basalt
fill 506 231 482 508 235 482 minecraft:basalt
setblock 507 231 472 minecraft:magma_block
setblock 507 231 502 minecraft:magma_block
fill 507 231 505 507 307 505 minecraft:orange_terracotta
fill 508 231 476 509 231 476 minecraft:basalt
fill 508 231 479 508 234 479 minecraft:basalt
fill 508 231 485 508 236 485 minecraft:basalt
fill 508 231 488 508 236 488 minecraft:basalt
fill 508 231 491 508 235 491 minecraft:basalt
fill 508 231 494 508 234 494 minecraft:basalt
fill 508 231 497 510 231 497 minecraft:basalt
setblock 508 231 500 minecraft:basalt
fill 509 231 505 509 307 505 minecraft:orange_terracotta
setblock 510 231 477 minecraft:magma_block
setblock 511 231 481 minecraft:basalt
fill 511 231 484 511 232 484 minecraft:basalt
fill 511 231 487 511 232 487 minecraft:basalt
fill 511 231 490 511 232 490 minecraft:basalt
setblock 511 231 493 minecraft:basalt
fill 512 231 463 512 307 463 minecraft:orange_terracotta
fill 512 231 473 512 307 473 minecraft:orange_terracotta
fill 512 231 483 512 307 483 minecraft:orange_terracotta
fill 512 231 489 512 307 489 minecraft:orange_terracotta
fill 512 231 499 512 307 499 minecraft:orange_terracotta
fill 470 232 476 470 307 479 minecraft:orange_terracotta
fill 470 232 480 470 232 481 minecraft:red_terracotta
fill 470 232 482 470 307 483 minecraft:orange_terracotta
fill 470 232 492 470 307 494 minecraft:orange_terracotta
fill 471 232 477 471 232 497 minecraft:basalt
fill 472 232 475 474 232 475 minecraft:basalt
fill 473 232 474 474 232 474 minecraft:basalt
setblock 473 232 500 minecraft:magma_block
fill 474 232 473 480 232 473 minecraft:basalt
fill 474 232 500 474 232 501 minecraft:basalt
setblock 475 232 472 minecraft:basalt
fill 475 232 484 475 238 484 minecraft:basalt
fill 475 232 490 475 238 490 minecraft:basalt
fill 475 232 500 480 234 500 minecraft:basalt
fill 475 232 505 475 307 505 minecraft:orange_terracotta
fill 476 232 471 478 232 471 minecraft:basalt
setblock 476 232 484 minecraft:magma_block
fill 476 232 486 476 240 486 minecraft:basalt
setblock 476 232 487 minecraft:magma_block
fill 476 232 488 476 240 488 minecraft:basalt
setblock 476 232 490 minecraft:magma_block
fill 476 232 503 481 232 503 minecraft:basalt
fill 477 232 470 478 232 470 minecraft:basalt
fill 477 232 482 477 239 483 minecraft:basalt
fill 477 232 491 477 241 492 minecraft:basalt
fill 477 232 494 478 239 494 minecraft:basalt
fill 477 232 504 478 232 504 minecraft:basalt
fill 478 232 469 484 232 469 minecraft:basalt
fill 478 232 480 478 241 480 minecraft:basalt
fill 479 232 479 479 241 479 minecraft:basalt
setblock 479 232 495 minecraft:magma_block
fill 479 232 505 480 307 505 minecraft:orange_terracotta
fill 480 232 468 486 232 468 minecraft:basalt
fill 480 232 478 480 241 478 minecraft:basalt
fill 480 232 496 480 241 496 minecraft:basalt
fill 481 232 477 481 241 477 minecraft:basalt
fill 481 232 497 481 241 497 minecraft:basalt
setblock 481 232 505 minecraft:red_terracotta
setblock 482 232 467 minecraft:magma_block
setblock 482 232 476 minecraft:magma_block
fill 482 232 498 482 241 498 minecraft:basalt
fill 482 232 505 482 307 505 minecraft:orange_terracotta
fill 483 232 467 489 232 467 minecraft:basalt
fill 483 232 474 483 239 475 minecraft:basalt
fill 483 232 499 483 241 499 minecraft:basalt
setblock 483 232 505 minecraft:red_terracotta
fill 484 232 505 488 307 505 minecraft:orange_terracotta
setblock 485 232 466 minecraft:magma_block
fill 485 232 474 486 241 474 minecraft:basalt
fill 485 232 500 486 241 500 minecraft:basalt
fill 486 232 466 493 232 466 minecraft:basalt
fill 486 232 473 486 239 473 minecraft:basalt
fill 486 232 501 487 240 501 minecraft:basalt
setblock 488 232 501 minecraft:magma_block
fill 489 232 463 489 307 463 minecraft:orange_terracotta
fill 489 232 472 489 239 473 minecraft:basalt
fill 489 232 501 489 239 502 minecraft:basalt
setblock 490 232 463 minecraft:red_terracotta
fill 490 232 473 490 240 473 minecraft:basalt
fill 490 232 501 492 239 501 minecraft:basalt
fill 491 232 463 497 307 463 minecraft:orange_terracotta
setblock 491 232 473 minecraft:magma_block
fill 492 232 505 492 307 505 minecraft:orange_terracotta
setblock 494 232 466 minecraft:magma_block
fill 494 232 474 495 241 474 minecraft:basalt
fill 494 232 500 495 239 500 minecraft:basalt
setblock 495 232 466 minecraft:basalt
fill 495 232 473 495 239 473 minecraft:basalt
fill 497 232 475 498 239 475 minecraft:basalt
fill 497 232 499 498 239 499 minecraft:basalt
fill 497 232 504 503 232 504 minecraft:basalt
fill 497 232 505 497 307 505 minecraft:orange_terracotta
setblock 498 232 463 minecraft:red_terracotta
fill 498 232 476 498 241 476 minecraft:basalt
fill 498 232 498 498 241 498 minecraft:basalt
setblock 498 232 505 minecraft:red_terracotta
fill 499 232 463 501 307 463 minecraft:orange_terracotta
fill 499 232 477 499 241 477 minecraft:basalt
fill 499 232 497 499 241 497 minecraft:basalt
fill 499 232 503 504 232 503 minecraft:basalt
fill 499 232 505 499 307 505 minecraft:orange_terracotta
fill 500 232 473 506 232 473 minecraft:basalt
fill 500 232 478 500 241 478 minecraft:basalt
fill 500 232 496 500 241 496 minecraft:basalt
setblock 500 232 505 minecraft:red_terracotta
fill 501 232 479 501 241 479 minecraft:basalt
fill 501 232 495 501 241 495 minecraft:basalt
fill 501 232 505 502 307 505 minecraft:orange_terracotta
setblock 502 232 469 minecraft:basalt
fill 502 232 472 505 232 472 minecraft:basalt
fill 502 232 475 508 232 475 minecraft:basalt
fill 502 232 480 502 241 480 minecraft:basalt
fill 502 232 494 502 241 494 minecraft:basalt
fill 502 232 499 508 232 499 minecraft:basalt
fill 502 232 502 505 232 502 minecraft:basalt
setblock 503 232 481 minecraft:magma_block
fill 503 232 482 503 241 483 minecraft:basalt
fill 503 232 491 503 241 492 minecraft:basalt
setblock 503 232 493 minecraft:magma_block
setblock 503 232 505 minecraft:red_terracotta
fill 504 232 481 504 239 482 minecraft:basalt
fill 504 232 485 504 239 488 minecraft:basalt
fill 504 232 491 504 239 491 minecraft:basalt
fill 504 232 505 504 307 505 minecraft:orange_terracotta
fill 505 232 474 507 232 474 minecraft:basalt
fill 505 232 481 507 236 481 minecraft:basalt
fill 505 232 496 509 232 496 minecraft:basalt
fill 505 232 498 508 232 498 minecraft:basalt
fill 505 232 501 505 233 501 minecraft:basalt
setblock 505 232 505 minecraft:red_terracotta
fill 506 232 463 508 307 463 minecraft:orange_terracotta
fill 506 232 480 510 232 480 minecraft:basalt
fill 506 232 495 510 232 495 minecraft:basalt
setblock 506 232 501 minecraft:magma_block
fill 506 232 505 506 307 505 minecraft:orange_terracotta
setblock 508 232 476 minecraft:basalt
fill 508 232 478 509 232 478 minecraft:basalt
fill 508 232 497 508 233 497 minecraft:basalt
setblock 509 232 463 minecraft:red_terracotta
fill 509 232 479 510 232 479 minecraft:basalt
fill 509 232 494 510 232 494 minecraft:basalt
setblock 509 232 497 minecraft:magma_block
fill 510 232 463 510 307 463 minecraft:orange_terracotta
fill 510 232 505 510 307 505 minecraft:orange_terracotta
setblock 511 232 463 minecraft:red_terracotta
setblock 511 232 505 minecraft:red_terracotta
fill 512 232 464 512 307 468 minecraft:orange_terracotta
setblock 512 232 469 minecraft:red_terracotta
fill 512 232 470 512 307 470 minecraft:orange_terracotta
setblock 512 232 471 minecraft:red_terracotta
fill 512 232 472 512 307 472 minecraft:orange_terracotta
fill 512 232 474 512 307 478 minecraft:orange_terracotta
setblock 512 232 479 minecraft:red_terracotta
fill 512 232 480 512 307 482 minecraft:orange_terracotta
fill 512 232 484 512 307 484 minecraft:orange_terracotta
setblock 512 232 485 minecraft:red_terracotta
fill 512 232 486 512 307 488 minecraft:orange_terracotta
fill 512 232 490 512 307 492 minecraft:orange_terracotta
setblock 512 232 493 minecraft:red_terracotta
fill 512 232 494 512 307 498 minecraft:orange_terracotta
fill 512 232 505 512 307 505 minecraft:orange_terracotta
fill 470 233 475 470 307 475 minecraft:orange_terracotta
fill 470 233 480 470 307 481 minecraft:orange_terracotta
fill 470 233 489 470 307 489 minecraft:orange_terracotta
setblock 471 233 477 minecraft:red_terracotta
setblock 471 233 478 minecraft:terracotta
fill 471 233 479 471 233 495 minecraft:basalt
fill 472 233 477 474 233 477 minecraft:basalt
setblock 472 233 478 minecraft:magma_block
fill 472 233 495 474 234 495 minecraft:basalt
setblock 472 233 496 minecraft:magma_block
fill 473 233 475 474 233 475 minecraft:basalt
fill 473 233 478 474 234 478 minecraft:basalt
fill 473 233 496 474 234 496 minecraft:basalt
fill 473 233 498 474 233 499 minecraft:basalt
setblock 474 233 474 minecraft:basalt
setblock 474 233 500 minecraft:basalt
fill 475 233 473 480 233 473 minecraft:basalt
setblock 475 233 501 minecraft:magma_block
setblock 475 233 504 minecraft:terracotta
fill 476 233 464 479 233 464 minecraft:red_terracotta
fill 476 233 484 477 240 484 minecraft:basalt
fill 476 233 487 477 233 487 minecraft:basalt
fill 476 233 490 477 240 490 minecraft:basalt
fill 476 233 501 477 234 501 minecraft:basalt
fill 476 233 504 477 235 504 minecraft:red_terracotta
fill 477 233 471 478 233 471 minecraft:basalt
fill 477 233 485 477 241 486 minecraft:basalt
fill 477 233 488 477 241 489 minecraft:basalt
fill 477 233 503 481 233 503 minecraft:basalt
setblock 478 233 470 minecraft:magma_block
fill 478 233 481 478 241 481 minecraft:basalt
setblock 478 233 482 minecraft:magma_block
fill 478 233 492 478 241 493 minecraft:basalt
setblock 478 233 504 minecraft:basalt
setblock 479 233 465 minecraft:terracotta
fill 479 233 480 479 242 480 minecraft:basalt
fill 479 233 494 479 240 495 minecraft:basalt
setblock 480 233 464 minecraft:terracotta
fill 480 233 465 483 233 465 minecraft:red_terracotta
setblock 480 233 469 minecraft:basalt
fill 481 233 464 484 233 464 minecraft:red_terracotta
setblock 481 233 469 minecraft:magma_block
fill 481 233 505 481 307 505 minecraft:orange_terracotta
fill 482 233 468 484 233 469 minecraft:basalt
fill 482 233 476 483 240 476 minecraft:basalt
fill 483 233 498 483 242 498 minecraft:basalt
fill 483 233 505 483 307 505 minecraft:orange_terracotta
setblock 484 233 465 minecraft:terracotta
fill 484 233 467 486 233 467 minecraft:basalt
fill 484 233 475 485 241 475 minecraft:basalt
fill 484 233 499 485 241 499 minecraft:basalt
setblock 485 233 464 minecraft:terracotta
fill 485 233 465 486 235 465 minecraft:red_terracotta
fill 485 233 468 486 234 468 minecraft:basalt
fill 486 233 464 489 233 464 minecraft:red_terracotta
setblock 487 233 467 minecraft:magma_block
fill 487 233 474 492 233 474 minecraft:basalt
setblock 487 233 500 minecraft:magma_block
fill 488 233 467 489 233 467 minecraft:basalt
fill 488 233 500 488 240 501 minecraft:basalt
fill 489 233 500 493 233 500 minecraft:basalt
fill 489 233 505 489 307 505 minecraft:orange_terracotta
fill 490 233 463 490 307 463 minecraft:orange_terracotta
setblock 490 233 464 minecraft:terracotta
fill 491 233 464 494 233 464 minecraft:red_terracotta
fill 491 233 467 495 233 467 minecraft:basalt
fill 491 233 473 491 240 473 minecraft:basalt
setblock 493 233 474 minecraft:magma_block
fill 494 233 469 498 234 469 minecraft:basalt
setblock 495 233 464 minecraft:terracotta
fill 495 233 475 496 233 475 minecraft:basalt
fill 495 233 499 496 233 499 minecraft:basalt
fill 496 233 464 498 233 465 minecraft:red_terracotta
setblock 496 233 467 minecraft:magma_block
fill 496 233 468 498 233 468 minecraft:basalt
fill 497 233 471 503 233 471 minecraft:basalt
fill 497 233 476 497 242 476 minecraft:basalt
fill 497 233 498 497 242 498 minecraft:basalt
fill 497 233 504 501 233 504 minecraft:basalt
fill 498 233 463 498 307 463 minecraft:orange_terracotta
fill 498 233 505 498 307 505 minecraft:orange_terracotta
setblock 499 233 464 minecraft:red_terracotta
setblock 499 233 465 minecraft:terracotta
setblock 499 233 469 minecraft:magma_block
fill 499 233 470 502 233 470 minecraft:basalt
fill 499 233 503 503 233 503 minecraft:basalt
setblock 500 233 464 minecraft:terracotta
fill 500 233 465 503 233 465 minecraft:red_terracotta
setblock 500 233 469 minecraft:basalt
fill 500 233 473 504 234 473 minecraft:basalt
fill 500 233 500 506 233 500 minecraft:basalt
fill 500 233 505 500 307 505 minecraft:orange_terracotta
fill 501 233 464 504 233 464 minecraft:red_terracotta
fill 501 233 480 501 242 480 minecraft:basalt
fill 501 233 494 501 242 494 minecraft:basalt
fill 502 233 472 504 233 472 minecraft:basalt
fill 502 233 475 507 233 475 minecraft:basalt
fill 502 233 481 502 241 482 minecraft:basalt
setblock 502 233 492 minecraft:magma_block
fill 502 233 493 503 240 493 minecraft:basalt
fill 502 233 499 507 233 499 minecraft:basalt
fill 502 233 502 504 233 502 minecraft:basalt
setblock 502 233 504 minecraft:magma_block
fill 503 233 481 503 240 481 minecraft:basalt
fill 503 233 484 503 240 490 minecraft:basalt
fill 503 233 504 504 233 504 minecraft:red_terracotta
fill 503 233 505 503 307 505 minecraft:orange_terracotta
fill 504 233 503 505 233 503 minecraft:red_terracotta
setblock 505 233 464 minecraft:terracotta
setblock 505 233 473 minecraft:magma_block
fill 505 233 474 506 233 474 minecraft:basalt
fill 505 233 477 508 233 477 minecraft:basalt
fill 505 233 496 507 234 496 minecraft:basalt
fill 505 233 498 507 233 498 minecraft:basalt
fill 505 233 502 506 233 502 minecraft:red_terracotta
setblock 505 233 504 minecraft:terracotta
fill 505 233 505 505 307 505 minecraft:orange_terracotta
fill 506 233 464 507 235 464 minecraft:red_terracotta
fill 506 233 480 509 233 480 minecraft:basalt
fill 506 233 483 510 233 483 minecraft:basalt
fill 506 233 486 510 234 486 minecraft:basalt
fill 506 233 489 510 233 489 minecraft:basalt
fill 506 233 492 510 233 492 minecraft:basalt
fill 506 233 495 509 233 495 minecraft:basalt
setblock 506 233 503 minecraft:terracotta
fill 506 233 504 509 233 504 minecraft:red_terracotta
setblock 507 233 502 minecraft:terracotta
fill 507 233 503 510 233 503 minecraft:red_terracotta
setblock 508 233 478 minecraft:magma_block
setblock 508 233 496 minecraft:magma_block
fill 509 233 463 509 307 463 minecraft:orange_terracotta
setblock 509 233 479 minecraft:basalt
fill 509 233 482 510 233 482 minecraft:basalt
fill 509 233 485 510 233 485 minecraft:basalt
fill 509 233 488 510 233 488 minecraft:basalt
fill 509 233 491 510 233 491 minecraft:basalt
setblock 509 233 494 minecraft:basalt
fill 510 233 473 510 246 473 minecraft:magma_block
fill 510 233 474 510 246 474 minecraft:shroomlight
fill 510 233 475 510 247 475 minecraft:magma_block
fill 510 233 501 511 233 502 minecraft:red_terracotta
setblock 510 233 504 minecraft:terracotta
fill 511 233 463 511 307 463 minecraft:orange_terracotta
fill 511 233 480 511 233 482 minecraft:red_terracotta
setblock 511 233 483 minecraft:terracotta
fill 511 233 484 511 235 485 minecraft:red_terracotta
setblock 511 233 497 minecraft:red_terracotta
setblock 511 233 498 minecraft:terracotta
fill 511 233 499 511 235 500 minecraft:red_terracotta
setblock 511 233 503 minecraft:terracotta
fill 511 233 504 511 236 504 minecraft:red_terracotta
fill 511 233 505 511 307 505 minecraft:orange_terracotta
fill 512 233 469 512 307 469 minecraft:orange_terracotta
fill 512 233 471 512 307 471 minecraft:orange_terracotta
fill 512 233 479 512 307 479 minecraft:orange_terracotta
fill 512 233 485 512 307 485 minecraft:orange_terracotta
fill 512 233 493 512 307 493 minecraft:orange_terracotta
setblock 471 234 477 minecraft:terracotta
fill 471 234 478 471 235 480 minecraft:red_terracotta
fill 471 234 481 471 234 482 minecraft:basalt
setblock 471 234 483 minecraft:magma_block
fill 471 234 484 471 234 488 minecraft:basalt
setblock 471 234 489 minecraft:magma_block
fill 471 234 490 471 234 491 minecraft:basalt
setblock 471 234 492 minecraft:magma_block
setblock 471 234 493 minecraft:basalt
fill 473 234 477 474 234 477 minecraft:basalt
setblock 474 234 475 minecraft:basalt
setblock 474 234 476 minecraft:magma_block
fill 474 234 498 474 234 499 minecraft:basalt
setblock 474 234 504 minecraft:terracotta
fill 475 234 464 478 234 464 minecraft:red_terracotta
fill 475 234 476 480 235 476 minecraft:basalt
fill 475 234 504 475 237 504 minecraft:red_terracotta
fill 476 234 473 480 234 473 minecraft:basalt
fill 476 234 487 476 240 487 minecraft:basalt
setblock 477 234 465 minecraft:red_terracotta
setblock 477 234 472 minecraft:magma_block
setblock 477 234 487 minecraft:magma_block
setblock 477 234 502 minecraft:magma_block
fill 477 234 503 477 236 503 minecraft:red_terracotta
setblock 478 234 465 minecraft:terracotta
fill 478 234 471 478 234 472 minecraft:basalt
fill 478 234 482 478 241 484 minecraft:basalt
fill 478 234 490 478 241 491 minecraft:basalt
fill 478 234 502 481 234 503 minecraft:basalt
setblock 478 234 504 minecraft:red_terracotta
setblock 479 234 464 minecraft:terracotta
fill 479 234 465 482 234 465 minecraft:red_terracotta
fill 479 234 472 483 235 472 minecraft:basalt
fill 479 234 481 479 242 481 minecraft:basalt
fill 479 234 493 479 242 493 minecraft:basalt
setblock 479 234 504 minecraft:terracotta
fill 480 234 464 483 234 464 minecraft:red_terracotta
fill 480 234 470 481 234 470 minecraft:basalt
fill 480 234 479 480 242 479 minecraft:basalt
setblock 480 234 480 minecraft:magma_block
fill 480 234 494 480 242 494 minecraft:basalt
setblock 480 234 495 minecraft:magma_block
setblock 480 234 504 minecraft:magma_block
fill 481 234 478 481 241 478 minecraft:basalt
fill 481 234 496 481 241 496 minecraft:basalt
fill 481 234 504 486 234 504 minecraft:basalt
fill 482 234 469 484 234 469 minecraft:basalt
fill 482 234 477 483 242 477 minecraft:basalt
fill 482 234 497 482 242 497 minecraft:basalt
fill 482 234 502 483 236 502 minecraft:basalt
setblock 483 234 465 minecraft:terracotta
setblock 483 234 497 minecraft:magma_block
setblock 484 234 464 minecraft:terracotta
fill 484 234 465 484 237 465 minecraft:red_terracotta
setblock 484 234 468 minecraft:basalt
fill 484 234 476 484 242 476 minecraft:basalt
fill 484 234 498 484 241 498 minecraft:basalt
fill 485 234 464 488 234 464 minecraft:red_terracotta
setblock 486 234 475 minecraft:magma_block
setblock 486 234 499 minecraft:magma_block
setblock 487 234 465 minecraft:red_terracotta
fill 487 234 474 487 241 475 minecraft:basalt
fill 487 234 499 487 241 500 minecraft:basalt
fill 488 234 474 488 240 474 minecraft:basalt
setblock 489 234 464 minecraft:terracotta
setblock 489 234 467 minecraft:basalt
setblock 489 234 474 minecraft:magma_block
fill 489 234 500 491 240 500 minecraft:basalt
fill 490 234 464 493 234 464 minecraft:red_terracotta
fill 490 234 474 493 241 474 minecraft:basalt
setblock 491 234 467 minecraft:basalt
setblock 492 234 500 minecraft:magma_block
setblock 493 234 465 minecraft:terracotta
fill 493 234 475 494 242 475 minecraft:basalt
fill 493 234 499 493 241 500 minecraft:basalt
setblock 494 234 464 minecraft:terracotta
fill 494 234 465 497 234 465 minecraft:red_terracotta
fill 494 234 499 494 242 499 minecraft:basalt
fill 495 234 464 498 234 464 minecraft:red_terracotta
setblock 495 234 475 minecraft:magma_block
setblock 495 234 499 minecraft:magma_block
setblock 496 234 468 minecraft:basalt
fill 496 234 475 496 241 476 minecraft:basalt
fill 496 234 498 496 241 499 minecraft:basalt
fill 497 234 471 502 234 471 minecraft:basalt
fill 497 234 477 497 242 477 minecraft:basalt
fill 497 234 497 498 234 497 minecraft:basalt
fill 497 234 504 500 234 504 minecraft:basalt
setblock 498 234 465 minecraft:terracotta
setblock 498 234 477 minecraft:magma_block
setblock 499 234 464 minecraft:terracotta
fill 499 234 465 502 234 465 minecraft:red_terracotta
fill 499 234 470 500 234 470 minecraft:basalt
fill 499 234 478 499 241 478 minecraft:basalt
fill 499 234 496 499 241 496 minecraft:basalt
fill 499 234 503 500 235 503 minecraft:basalt
fill 500 234 464 503 234 464 minecraft:red_terracotta
fill 500 234 476 506 234 476 minecraft:basalt
fill 500 234 479 500 242 480 minecraft:basalt
fill 500 234 494 500 242 495 minecraft:basalt
fill 500 234 500 505 234 500 minecraft:basalt
fill 501 234 481 501 242 481 minecraft:basalt
fill 501 234 493 501 242 493 minecraft:basalt
setblock 501 234 503 minecraft:magma_block
fill 501 234 504 503 234 504 minecraft:red_terracotta
fill 502 234 472 503 234 472 minecraft:basalt
fill 502 234 475 506 234 475 minecraft:basalt
fill 502 234 483 502 241 484 minecraft:basalt
fill 502 234 490 502 241 492 minecraft:basalt
fill 502 234 499 506 234 499 minecraft:basalt
fill 502 234 502 502 234 503 minecraft:basalt
setblock 503 234 465 minecraft:terracotta
setblock 503 234 502 minecraft:basalt
fill 503 234 503 504 234 503 minecraft:red_terracotta
setblock 504 234 464 minecraft:terracotta
fill 504 234 465 504 237 465 minecraft:red_terracotta
fill 504 234 502 505 234 502 minecraft:red_terracotta
setblock 504 234 504 minecraft:terracotta
fill 505 234 464 505 237 464 minecraft:red_terracotta
setblock 505 234 474 minecraft:basalt
fill 505 234 477 506 235 477 minecraft:basalt
fill 505 234 498 506 234 498 minecraft:basalt
setblock 505 234 503 minecraft:terracotta
fill 505 234 504 508 234 504 minecraft:red_terracotta
fill 506 234 480 508 234 480 minecraft:basalt
fill 506 234 483 509 234 483 minecraft:basalt
fill 506 234 489 509 235 489 minecraft:basalt
fill 506 234 492 509 234 492 minecraft:basalt
fill 506 234 495 508 234 495 minecraft:basalt
setblock 506 234 502 minecraft:terracotta
fill 506 234 503 509 234 503 minecraft:red_terracotta
setblock 507 234 477 minecraft:magma_block
setblock 507 234 502 minecraft:red_terracotta
fill 508 234 481 509 234 481 minecraft:basalt
fill 508 234 484 509 234 484 minecraft:basalt
fill 508 234 490 509 234 490 minecraft:basalt
fill 508 234 493 509 234 493 minecraft:basalt
setblock 509 234 482 minecraft:basalt
fill 509 234 485 509 235 485 minecraft:basalt
fill 509 234 488 509 235 488 minecraft:basalt
setblock 509 234 491 minecraft:basalt
setblock 509 234 504 minecraft:terracotta
setblock 510 234 488 minecraft:magma_block
fill 510 234 501 510 234 502 minecraft:red_terracotta
setblock 510 234 503 minecraft:terracotta
fill 510 234 504 510 237 504 minecraft:red_terracotta
fill 511 234 480 511 234 481 minecraft:red_terracotta
setblock 511 234 482 minecraft:terracotta
fill 511 234 483 511 237 483 minecraft:red_terracotta
setblock 511 234 486 minecraft:red_terracotta
setblock 511 234 487 minecraft:terracotta
fill 511 234 488 511 237 488 minecraft:red_terracotta
setblock 511 234 497 minecraft:terracotta
fill 511 234 498 511 237 498 minecraft:red_terracotta
setblock 511 234 501 minecraft:red_terracotta
setblock 511 234 502 minecraft:terracotta
fill 511 234 503 511 237 503 minecraft:red_terracotta
fill 471 235 477 471 238 477 minecraft:red_terracotta
setblock 471 235 481 minecraft:terracotta
fill 471 235 482 471 236 484 minecraft:red_terracotta
fill 471 235 485 471 235 489 minecraft:basalt
setblock 471 235 490 minecraft:red_terracotta
fill 472 235 478 472 235 479 minecraft:red_terracotta
setblock 472 235 480 minecraft:terracotta
fill 472 235 481 474 235 481 minecraft:basalt
setblock 472 235 504 minecraft:red_terracotta
setblock 473 235 464 minecraft:terracotta
fill 473 235 480 474 235 480 minecraft:basalt
fill 473 235 494 474 235 495 minecraft:basalt
setblock 473 235 504 minecraft:terracotta
fill 474 235 464 477 235 464 minecraft:red_terracotta
fill 474 235 477 474 235 478 minecraft:basalt
fill 474 235 496 474 235 497 minecraft:basalt
fill 474 235 504 474 238 504 minecraft:red_terracotta
fill 475 235 494 476 238 494 minecraft:basalt
fill 475 235 497 479 235 497 minecraft:basalt
setblock 476 235 465 minecraft:red_terracotta
setblock 476 235 474 minecraft:magma_block
fill 476 235 500 480 235 500 minecraft:basalt
fill 476 235 503 476 237 503 minecraft:red_terracotta
setblock 477 235 465 minecraft:terracotta
fill 477 235 473 477 235 474 minecraft:basalt
fill 477 235 487 478 242 487 minecraft:basalt
setblock 477 235 501 minecraft:basalt
setblock 478 235 464 minecraft:terracotta
fill 478 235 465 481 235 465 minecraft:red_terracotta
fill 478 235 473 480 235 473 minecraft:basalt
fill 478 235 485 478 241 486 minecraft:basalt
fill 478 235 488 478 243 489 minecraft:basalt
setblock 478 235 503 minecraft:red_terracotta
setblock 478 235 504 minecraft:terracotta
fill 479 235 464 482 235 464 minecraft:red_terracotta
fill 479 235 466 480 235 466 minecraft:red_terracotta
setblock 479 235 482 minecraft:magma_block
fill 479 235 483 479 243 483 minecraft:basalt
setblock 479 235 491 minecraft:magma_block
fill 479 235 492 479 243 492 minecraft:basalt
fill 479 235 502 481 235 502 minecraft:basalt
setblock 479 235 503 minecraft:terracotta
fill 479 235 504 481 236 504 minecraft:red_terracotta
fill 480 235 471 486 235 471 minecraft:basalt
fill 480 235 480 480 242 481 minecraft:basalt
fill 480 235 493 480 243 493 minecraft:basalt
fill 480 235 495 481 242 495 minecraft:basalt
fill 480 235 503 481 235 503 minecraft:basalt
setblock 481 235 466 minecraft:terracotta
fill 481 235 479 481 243 479 minecraft:basalt
setblock 482 235 465 minecraft:terracotta
fill 482 235 466 484 236 466 minecraft:red_terracotta
setblock 482 235 478 minecraft:magma_block
setblock 482 235 496 minecraft:magma_block
fill 482 235 504 486 235 504 minecraft:basalt
setblock 483 235 464 minecraft:terracotta
fill 483 235 465 483 238 465 minecraft:red_terracotta
fill 483 235 497 484 235 497 minecraft:basalt
fill 484 235 464 487 235 464 minecraft:red_terracotta
setblock 484 235 469 minecraft:basalt
fill 484 235 477 484 243 477 minecraft:basalt
fill 485 235 476 486 243 476 minecraft:basalt
setblock 485 235 498 minecraft:magma_block
fill 486 235 475 486 242 475 minecraft:basalt
fill 486 235 498 486 242 499 minecraft:basalt
setblock 487 235 465 minecraft:terracotta
setblock 488 235 464 minecraft:terracotta
fill 488 235 465 491 235 465 minecraft:red_terracotta
fill 488 235 468 492 235 468 minecraft:basalt
fill 488 235 475 490 243 475 minecraft:basalt
fill 488 235 499 490 243 499 minecraft:basalt
fill 489 235 464 492 235 464 minecraft:red_terracotta
fill 489 235 474 489 242 474 minecraft:basalt
fill 491 235 470 496 236 470 minecraft:basalt
setblock 491 235 475 minecraft:magma_block
setblock 491 235 499 minecraft:magma_block
setblock 492 235 465 minecraft:terracotta
fill 492 235 475 492 243 475 minecraft:basalt
fill 492 235 499 492 241 500 minecraft:basalt
setblock 493 235 464 minecraft:terracotta
fill 493 235 465 496 235 465 minecraft:red_terracotta
fill 494 235 464 497 235 464 minecraft:red_terracotta
fill 494 235 469 496 235 469 minecraft:basalt
fill 494 235 476 495 243 476 minecraft:basalt
setblock 494 235 498 minecraft:magma_block
fill 495 235 475 495 242 475 minecraft:basalt
fill 495 235 498 495 242 499 minecraft:basalt
fill 496 235 477 496 243 477 minecraft:basalt
fill 496 235 497 496 243 497 minecraft:basalt
setblock 497 235 465 minecraft:terracotta
fill 497 235 466 500 235 466 minecraft:red_terracotta
setblock 497 235 470 minecraft:magma_block
fill 497 235 471 500 235 471 minecraft:basalt
fill 497 235 474 502 236 474 minecraft:basalt
setblock 497 235 497 minecraft:magma_block
fill 497 235 504 498 235 504 minecraft:basalt
setblock 498 235 464 minecraft:terracotta
fill 498 235 465 501 235 465 minecraft:red_terracotta
setblock 498 235 470 minecraft:basalt
fill 498 235 477 498 242 478 minecraft:basalt
fill 498 235 496 498 242 497 minecraft:basalt
fill 499 235 464 502 235 464 minecraft:red_terracotta
fill 499 235 479 499 243 479 minecraft:basalt
fill 499 235 495 499 243 495 minecraft:basalt
fill 499 235 501 502 235 501 minecraft:basalt
fill 499 235 504 502 235 504 minecraft:red_terracotta
fill 500 235 473 503 235 473 minecraft:basalt
fill 500 235 476 505 235 476 minecraft:basalt
setblock 500 235 481 minecraft:magma_block
setblock 500 235 493 minecraft:magma_block
fill 500 235 500 504 235 500 minecraft:basalt
setblock 501 235 466 minecraft:terracotta
fill 501 235 482 501 242 483 minecraft:basalt
fill 501 235 491 501 242 492 minecraft:basalt
fill 501 235 497 505 236 497 minecraft:basalt
fill 501 235 503 503 235 503 minecraft:red_terracotta
setblock 502 235 465 minecraft:terracotta
fill 502 235 475 504 235 475 minecraft:basalt
fill 502 235 485 502 241 489 minecraft:basalt
fill 502 235 499 504 235 499 minecraft:basalt
fill 502 235 502 504 235 502 minecraft:red_terracotta
setblock 503 235 464 minecraft:terracotta
fill 503 235 465 503 238 465 minecraft:red_terracotta
setblock 503 235 474 minecraft:magma_block
setblock 503 235 501 minecraft:magma_block
setblock 503 235 504 minecraft:terracotta
fill 504 235 464 504 238 464 minecraft:red_terracotta
setblock 504 235 474 minecraft:basalt
setblock 504 235 503 minecraft:terracotta
fill 504 235 504 507 235 504 minecraft:red_terracotta
fill 505 235 478 506 235 479 minecraft:basalt
fill 505 235 496 506 235 496 minecraft:basalt
setblock 505 235 498 minecraft:basalt
setblock 505 235 502 minecraft:terracotta
fill 505 235 503 508 235 503 minecraft:red_terracotta
fill 506 235 480 507 235 480 minecraft:basalt
fill 506 235 483 508 235 483 minecraft:basalt
fill 506 235 486 509 235 486 minecraft:basalt
fill 506 235 492 508 235 492 minecraft:basalt
fill 506 235 495 507 235 495 minecraft:basalt
setblock 506 235 497 minecraft:magma_block
fill 506 235 502 506 236 502 minecraft:red_terracotta
setblock 507 235 479 minecraft:basalt
setblock 508 235 464 minecraft:terracotta
setblock 508 235 481 minecraft:basalt
fill 508 235 484 508 236 484 minecraft:basalt
fill 508 235 487 508 236 487 minecraft:basalt
fill 508 235 490 508 236 490 minecraft:basalt
setblock 508 235 493 minecraft:basalt
setblock 508 235 504 minecraft:terracotta
setblock 509 235 487 minecraft:magma_block
setblock 509 235 503 minecraft:terracotta
fill 509 235 504 509 238 504 minecraft:red_terracotta
fill 510 235 483 510 236 485 minecraft:red_terracotta
setblock 510 235 502 minecraft:terracotta
fill 510 235 503 510 237 503 minecraft:red_terracotta
fill 511 235 479 511 235 480 minecraft:red_terracotta
setblock 511 235 481 minecraft:terracotta
fill 511 235 482 511 238 482 minecraft:red_terracotta
setblock 511 235 486 minecraft:terracotta
fill 511 235 487 511 238 487 minecraft:red_terracotta
fill 511 235 489 511 235 490 minecraft:red_terracotta
fill 511 235 497 511 238 497 minecraft:red_terracotta
setblock 511 235 501 minecraft:terracotta
fill 511 235 502 511 238 502 minecraft:red_terracotta
setblock 471 236 464 minecraft:red_terracotta
fill 471 236 476 471 239 476 minecraft:red_terracotta
fill 471 236 478 471 236 479 minecraft:red_terracotta
setblock 471 236 480 minecraft:terracotta
fill 471 236 481 472 238 481 minecraft:red_terracotta
setblock 471 236 485 minecraft:terracotta
fill 471 236 486 471 236 489 minecraft:red_terracotta
setblock 471 236 490 minecraft:terracotta
fill 471 236 491 471 239 491 minecraft:red_terracotta
fill 471 236 503 471 236 504 minecraft:red_terracotta
setblock 472 236 464 minecraft:terracotta
setblock 472 236 478 minecraft:red_terracotta
setblock 472 236 479 minecraft:terracotta
fill 472 236 480 473 238 480 minecraft:red_terracotta
fill 472 236 482 472 236 483 minecraft:red_terracotta
fill 472 236 484 474 236 484 minecraft:basalt
setblock 472 236 486 minecraft:magma_block
fill 472 236 487 474 236 487 minecraft:basalt
setblock 472 236 489 minecraft:magma_block
fill 472 236 490 474 236 490 minecraft:basalt
setblock 472 236 504 minecraft:terracotta
fill 473 236 464 476 236 464 minecraft:red_terracotta
fill 473 236 481 474 236 481 minecraft:basalt
fill 473 236 483 474 236 483 minecraft:basalt
fill 473 236 486 474 237 486 minecraft:basalt
fill 473 236 489 474 237 489 minecraft:basalt
fill 473 236 492 474 236 493 minecraft:basalt
fill 473 236 504 473 239 504 minecraft:red_terracotta
fill 474 236 465 475 236 465 minecraft:red_terracotta
fill 474 236 479 474 236 480 minecraft:basalt
fill 474 236 494 474 236 495 minecraft:basalt
fill 475 236 479 477 237 479 minecraft:basalt
setblock 475 236 497 minecraft:magma_block
fill 475 236 503 475 238 503 minecraft:red_terracotta
setblock 476 236 465 minecraft:terracotta
fill 476 236 476 480 236 476 minecraft:basalt
fill 476 236 497 477 236 498 minecraft:basalt
setblock 476 236 504 minecraft:red_terracotta
setblock 477 236 464 minecraft:terracotta
fill 477 236 465 479 236 466 minecraft:red_terracotta
fill 477 236 475 481 236 475 minecraft:basalt
fill 477 236 499 481 236 499 minecraft:basalt
setblock 477 236 504 minecraft:terracotta
fill 478 236 464 481 236 464 minecraft:red_terracotta
fill 478 236 497 479 239 497 minecraft:basalt
fill 478 236 500 480 236 500 minecraft:basalt
setblock 478 236 503 minecraft:terracotta
fill 478 236 504 478 239 504 minecraft:red_terracotta
fill 479 236 473 480 236 473 minecraft:basalt
fill 479 236 482 480 236 482 minecraft:basalt
fill 479 236 484 479 243 491 minecraft:basalt
fill 479 236 503 481 237 503 minecraft:red_terracotta
setblock 480 236 465 minecraft:red_terracotta
setblock 480 236 466 minecraft:terracotta
fill 480 236 472 483 236 472 minecraft:basalt
fill 480 236 492 480 244 492 minecraft:basalt
fill 480 236 502 481 236 502 minecraft:basalt
setblock 481 236 465 minecraft:terracotta
fill 481 236 466 481 239 466 minecraft:red_terracotta
setblock 481 236 480 minecraft:magma_block
fill 481 236 494 481 243 494 minecraft:basalt
setblock 482 236 464 minecraft:terracotta
fill 482 236 465 482 239 465 minecraft:red_terracotta
fill 482 236 471 486 236 471 minecraft:basalt
fill 482 236 478 482 243 479 minecraft:basalt
fill 482 236 495 482 243 496 minecraft:basalt
setblock 482 236 504 minecraft:terracotta
fill 483 236 464 486 236 464 minecraft:red_terracotta
fill 483 236 478 483 243 478 minecraft:basalt
fill 483 236 496 483 242 497 minecraft:basalt
fill 483 236 504 483 239 504 minecraft:red_terracotta
setblock 484 236 470 minecraft:magma_block
setblock 484 236 497 minecraft:magma_block
fill 484 236 504 486 236 504 minecraft:basalt
setblock 485 236 465 minecraft:red_terracotta
setblock 485 236 466 minecraft:terracotta
fill 485 236 470 489 236 470 minecraft:basalt
fill 485 236 477 485 243 477 minecraft:basalt
fill 485 236 497 485 243 498 minecraft:basalt
setblock 486 236 465 minecraft:terracotta
setblock 487 236 464 minecraft:terracotta
fill 487 236 465 490 236 465 minecraft:red_terracotta
setblock 487 236 469 minecraft:magma_block
fill 487 236 476 492 236 476 minecraft:basalt
fill 487 236 498 489 243 498 minecraft:basalt
fill 488 236 464 491 236 464 minecraft:red_terracotta
fill 488 236 469 492 236 469 minecraft:basalt
setblock 490 236 498 minecraft:magma_block
setblock 491 236 465 minecraft:terracotta
fill 491 236 475 491 243 475 minecraft:basalt
fill 491 236 498 491 243 499 minecraft:basalt
setblock 492 236 464 minecraft:terracotta
fill 492 236 465 495 236 465 minecraft:red_terracotta
fill 492 236 498 494 243 498 minecraft:basalt
fill 493 236 464 496 236 464 minecraft:red_terracotta
setblock 493 236 476 minecraft:magma_block
setblock 494 236 466 minecraft:red_terracotta
fill 494 236 472 500 236 472 minecraft:basalt
fill 494 236 502 500 236 502 minecraft:basalt
setblock 495 236 466 minecraft:terracotta
setblock 495 236 477 minecraft:basalt
fill 495 236 497 495 244 497 minecraft:basalt
setblock 496 236 465 minecraft:terracotta
fill 496 236 466 499 236 466 minecraft:red_terracotta
setblock 497 236 464 minecraft:terracotta
fill 497 236 465 500 236 465 minecraft:red_terracotta
fill 497 236 471 498 236 471 minecraft:basalt
fill 497 236 478 497 243 478 minecraft:basalt
fill 497 236 496 497 242 497 minecraft:basalt
setblock 497 236 504 minecraft:terracotta
fill 498 236 464 501 236 464 minecraft:red_terracotta
fill 498 236 479 498 243 479 minecraft:basalt
fill 498 236 495 498 242 495 minecraft:basalt
fill 498 236 504 501 236 504 minecraft:red_terracotta
setblock 499 236 480 minecraft:magma_block
fill 499 236 494 499 243 494 minecraft:basalt
fill 499 236 501 501 236 501 minecraft:basalt
fill 499 236 503 502 236 503 minecraft:red_terracotta
setblock 500 236 466 minecraft:terracotta
fill 500 236 473 501 236 473 minecraft:basalt
fill 500 236 476 504 236 476 minecraft:basalt
fill 500 236 481 500 243 482 minecraft:basalt
fill 500 236 492 500 243 493 minecraft:basalt
fill 500 236 500 501 237 500 minecraft:basalt
setblock 501 236 465 minecraft:terracotta
fill 501 236 466 501 239 466 minecraft:red_terracotta
fill 501 236 484 501 236 490 minecraft:basalt
fill 501 236 502 503 236 502 minecraft:red_terracotta
setblock 502 236 464 minecraft:terracotta
fill 502 236 465 502 239 465 minecraft:red_terracotta
fill 502 236 475 503 236 475 minecraft:basalt
fill 502 236 499 503 236 499 minecraft:basalt
setblock 502 236 500 minecraft:magma_block
fill 502 236 501 503 236 501 minecraft:red_terracotta
setblock 502 236 504 minecraft:terracotta
fill 503 236 464 503 239 464 minecraft:red_terracotta
setblock 503 236 503 minecraft:terracotta
fill 503 236 504 506 236 504 minecraft:red_terracotta
setblock 504 236 502 minecraft:terracotta
fill 504 236 503 507 236 503 minecraft:red_terracotta
setblock 505 236 465 minecraft:red_terracotta
setblock 505 236 477 minecraft:basalt
setblock 505 236 478 minecraft:magma_block
fill 505 236 479 506 236 479 minecraft:basalt
fill 505 236 493 506 236 494 minecraft:basalt
setblock 505 236 496 minecraft:magma_block
fill 505 236 502 505 237 502 minecraft:red_terracotta
setblock 506 236 464 minecraft:red_terracotta
setblock 506 236 480 minecraft:basalt
fill 506 236 482 507 236 483 minecraft:basalt
fill 506 236 486 507 237 486 minecraft:basalt
fill 506 236 489 507 237 489 minecraft:basalt
fill 506 236 492 507 236 492 minecraft:basalt
setblock 506 236 495 minecraft:basalt
setblock 507 236 464 minecraft:terracotta
setblock 507 236 493 minecraft:basalt
setblock 507 236 504 minecraft:terracotta
fill 508 236 464 508 239 464 minecraft:red_terracotta
setblock 508 236 486 minecraft:magma_block
setblock 508 236 489 minecraft:magma_block
setblock 508 236 503 minecraft:terracotta
fill 508 236 504 508 239 504 minecraft:red_terracotta
fill 509 236 503 509 237 503 minecraft:red_terracotta
fill 510 236 482 510 239 482 minecraft:red_terracotta
setblock 510 236 486 minecraft:terracotta
fill 510 236 487 510 238 488 minecraft:red_terracotta
setblock 510 236 502 minecraft:red_terracotta
setblock 511 236 479 minecraft:red_terracotta
setblock 511 236 480 minecraft:terracotta
fill 511 236 481 511 239 481 minecraft:red_terracotta
setblock 511 236 484 minecraft:red_terracotta
setblock 511 236 485 minecraft:terracotta
fill 511 236 486 511 239 486 minecraft:red_terracotta
setblock 511 236 489 minecraft:red_terracotta
setblock 511 236 490 minecraft:terracotta
fill 511 236 491 511 237 493 minecraft:red_terracotta
fill 511 236 496 511 239 496 minecraft:red_terracotta
setblock 511 236 499 minecraft:red_terracotta
setblock 511 236 500 minecraft:terracotta
fill 511 236 501 511 239 501 minecraft:red_terracotta
setblock 471 237 464 minecraft:terracotta
fill 471 237 465 471 238 467 minecraft:red_terracotta
setblock 471 237 478 minecraft:red_terracotta
setblock 471 237 479 minecraft:terracotta
fill 471 237 480 471 240 480 minecraft:red_terracotta
fill 471 237 482 471 237 483 minecraft:red_terracotta
setblock 471 237 484 minecraft:terracotta
fill 471 237 485 471 237 488 minecraft:red_terracotta
setblock 471 237 489 minecraft:terracotta
fill 471 237 490 471 240 490 minecraft:red_terracotta
setblock 471 237 503 minecraft:red_terracotta
setblock 471 237 504 minecraft:terracotta
fill 472 237 464 475 237 464 minecraft:red_terracotta
setblock 472 237 478 minecraft:terracotta
fill 472 237 479 473 238 479 minecraft:red_terracotta
setblock 472 237 482 minecraft:red_terracotta
setblock 472 237 483 minecraft:terracotta
fill 472 237 484 472 237 487 minecraft:red_terracotta
setblock 472 237 488 minecraft:terracotta
fill 472 237 489 472 240 489 minecraft:red_terracotta
fill 472 237 504 472 240 504 minecraft:red_terracotta
fill 473 237 465 474 237 465 minecraft:red_terracotta
setblock 473 237 481 minecraft:red_terracotta
setblock 473 237 482 minecraft:terracotta
fill 473 237 483 473 240 483 minecraft:red_terracotta
fill 473 237 484 474 237 484 minecraft:basalt
fill 473 237 487 474 237 487 minecraft:basalt
fill 473 237 490 474 237 490 minecraft:basalt
setblock 474 237 481 minecraft:magma_block
fill 474 237 482 474 237 483 minecraft:basalt
fill 474 237 491 474 237 492 minecraft:basalt
setblock 474 237 493 minecraft:magma_block
setblock 475 237 465 minecraft:terracotta
fill 475 237 482 476 238 482 minecraft:basalt
fill 475 237 491 475 239 491 minecraft:basalt
setblock 476 237 464 minecraft:terracotta
fill 476 237 465 478 237 466 minecraft:red_terracotta
fill 476 237 477 477 237 477 minecraft:basalt
fill 476 237 497 477 237 497 minecraft:basalt
setblock 476 237 504 minecraft:terracotta
fill 477 237 464 480 237 464 minecraft:red_terracotta
fill 477 237 476 480 237 476 minecraft:basalt
setblock 477 237 498 minecraft:magma_block
setblock 477 237 503 minecraft:terracotta
fill 477 237 504 477 240 504 minecraft:red_terracotta
fill 478 237 475 481 237 475 minecraft:basalt
fill 478 237 499 481 237 499 minecraft:basalt
fill 478 237 503 478 240 503 minecraft:red_terracotta
setblock 479 237 465 minecraft:red_terracotta
setblock 479 237 466 minecraft:terracotta
fill 479 237 467 480 239 467 minecraft:red_terracotta
fill 479 237 474 482 237 474 minecraft:basalt
fill 479 237 482 479 243 482 minecraft:basalt
fill 479 237 500 480 237 500 minecraft:basalt
fill 479 237 504 480 237 504 minecraft:red_terracotta
setblock 480 237 465 minecraft:terracotta
fill 480 237 466 480 240 466 minecraft:red_terracotta
setblock 480 237 473 minecraft:magma_block
setblock 480 237 482 minecraft:magma_block
fill 480 237 483 480 244 484 minecraft:basalt
fill 480 237 490 480 244 490 minecraft:basalt
setblock 480 237 491 minecraft:magma_block
fill 480 237 501 485 237 501 minecraft:basalt
setblock 481 237 464 minecraft:terracotta
fill 481 237 465 481 240 465 minecraft:red_terracotta
fill 481 237 480 481 243 481 minecraft:basalt
fill 481 237 493 481 244 493 minecraft:basalt
setblock 481 237 504 minecraft:terracotta
fill 482 237 464 485 237 464 minecraft:red_terracotta
fill 482 237 466 483 237 466 minecraft:red_terracotta
setblock 482 237 472 minecraft:basalt
fill 482 237 480 482 244 480 minecraft:basalt
fill 482 237 494 482 244 494 minecraft:basalt
setblock 482 237 502 minecraft:basalt
setblock 482 237 503 minecraft:terracotta
fill 482 237 504 482 240 504 minecraft:red_terracotta
setblock 483 237 472 minecraft:magma_block
fill 483 237 479 483 244 479 minecraft:basalt
fill 483 237 495 483 244 495 minecraft:basalt
setblock 483 237 502 minecraft:magma_block
fill 483 237 503 483 238 503 minecraft:red_terracotta
setblock 484 237 466 minecraft:terracotta
fill 484 237 471 485 237 471 minecraft:basalt
fill 484 237 478 484 244 478 minecraft:basalt
fill 484 237 496 484 243 497 minecraft:basalt
fill 484 237 503 489 237 503 minecraft:basalt
fill 484 237 504 485 237 504 minecraft:red_terracotta
setblock 485 237 465 minecraft:terracotta
fill 485 237 466 486 239 466 minecraft:red_terracotta
setblock 486 237 464 minecraft:terracotta
fill 486 237 465 489 237 465 minecraft:red_terracotta
setblock 486 237 471 minecraft:magma_block
setblock 486 237 477 minecraft:magma_block
fill 486 237 497 487 244 497 minecraft:basalt
setblock 486 237 504 minecraft:terracotta
fill 487 237 464 490 237 464 minecraft:red_terracotta
fill 487 237 470 488 237 470 minecraft:basalt
fill 487 237 476 487 243 477 minecraft:basalt
fill 488 237 471 494 237 471 minecraft:basalt
fill 488 237 476 488 243 476 minecraft:basalt
fill 488 237 504 493 237 504 minecraft:basalt
setblock 489 237 470 minecraft:magma_block
setblock 489 237 476 minecraft:magma_block
setblock 490 237 465 minecraft:terracotta
fill 490 237 476 493 243 476 minecraft:basalt
fill 490 237 498 490 244 498 minecraft:basalt
setblock 491 237 464 minecraft:terracotta
fill 491 237 465 494 237 465 minecraft:red_terracotta
fill 491 237 470 493 237 470 minecraft:basalt
fill 491 237 503 496 237 503 minecraft:basalt
fill 492 237 464 495 237 464 minecraft:red_terracotta
setblock 493 237 466 minecraft:red_terracotta
fill 493 237 477 494 243 477 minecraft:basalt
fill 493 237 497 494 244 497 minecraft:basalt
setblock 494 237 466 minecraft:terracotta
fill 494 237 472 498 237 472 minecraft:basalt
fill 494 237 502 498 237 502 minecraft:basalt
fill 494 237 504 495 237 504 minecraft:red_terracotta
setblock 495 237 465 minecraft:terracotta
fill 495 237 466 498 237 466 minecraft:red_terracotta
setblock 495 237 471 minecraft:magma_block
setblock 495 237 477 minecraft:magma_block
setblock 496 237 464 minecraft:terracotta
fill 496 237 465 499 237 465 minecraft:red_terracotta
fill 496 237 478 496 244 478 minecraft:basalt
fill 496 237 496 496 244 496 minecraft:basalt
setblock 496 237 504 minecraft:terracotta
fill 497 237 464 500 237 464 minecraft:red_terracotta
fill 497 237 474 501 237 474 minecraft:basalt
fill 497 237 479 497 243 479 minecraft:basalt
fill 497 237 495 497 244 495 minecraft:basalt
setblock 497 237 503 minecraft:terracotta
fill 497 237 504 500 237 504 minecraft:red_terracotta
fill 498 237 480 499 243 480 minecraft:basalt
setblock 498 237 494 minecraft:magma_block
fill 498 237 503 501 237 503 minecraft:red_terracotta
setblock 499 237 466 minecraft:terracotta
fill 499 237 481 499 244 481 minecraft:basalt
fill 499 237 493 499 244 493 minecraft:basalt
fill 499 237 501 500 237 501 minecraft:basalt
fill 499 237 502 502 237 502 minecraft:red_terracotta
setblock 500 237 465 minecraft:terracotta
fill 500 237 466 500 240 466 minecraft:red_terracotta
setblock 500 237 473 minecraft:basalt
fill 500 237 476 503 237 476 minecraft:basalt
fill 500 237 483 500 243 484 minecraft:basalt
fill 500 237 490 500 243 491 minecraft:basalt
fill 500 237 498 503 237 498 minecraft:basalt
setblock 501 237 464 minecraft:terracotta
fill 501 237 465 501 240 465 minecraft:red_terracotta
fill 501 237 477 503 238 477 minecraft:basalt
fill 501 237 484 501 243 486 minecraft:basalt
setblock 501 237 487 minecraft:magma_block
fill 501 237 488 501 243 490 minecraft:basalt
fill 501 237 497 504 237 497 minecraft:basalt
fill 501 237 501 502 237 501 minecraft:red_terracotta
setblock 501 237 504 minecraft:terracotta
fill 502 237 464 502 240 464 minecraft:red_terracotta
fill 502 237 466 502 238 466 minecraft:red_terracotta
setblock 502 237 475 minecraft:basalt
setblock 502 237 499 minecraft:basalt
setblock 502 237 503 minecraft:terracotta
fill 502 237 504 505 237 504 minecraft:red_terracotta
setblock 503 237 502 minecraft:terracotta
fill 503 237 503 506 237 503 minecraft:red_terracotta
setblock 504 237 477 minecraft:magma_block
fill 504 237 502 504 238 502 minecraft:red_terracotta
setblock 505 237 465 minecraft:terracotta
setblock 505 237 479 minecraft:basalt
fill 505 237 481 506 237 481 minecraft:basalt
fill 505 237 484 506 237 485 minecraft:basalt
fill 505 237 487 506 237 488 minecraft:basalt
fill 505 237 490 506 237 491 minecraft:basalt
fill 505 237 493 505 238 494 minecraft:basalt
setblock 506 237 464 minecraft:terracotta
fill 506 237 482 506 237 483 minecraft:basalt
fill 506 237 492 506 237 493 minecraft:basalt
setblock 506 237 504 minecraft:terracotta
fill 507 237 464 507 240 464 minecraft:red_terracotta
setblock 507 237 484 minecraft:basalt
setblock 507 237 485 minecraft:magma_block
setblock 507 237 487 minecraft:basalt
setblock 507 237 488 minecraft:magma_block
setblock 507 237 490 minecraft:basalt
setblock 507 237 503 minecraft:terracotta
fill 507 237 504 507 240 504 minecraft:red_terracotta
fill 508 237 503 508 238 503 minecraft:red_terracotta
fill 509 237 464 510 237 464 minecraft:red_terracotta
fill 510 237 483 510 237 484 minecraft:red_terracotta
setblock 510 237 485 minecraft:terracotta
fill 510 237 486 510 240 486 minecraft:red_terracotta
setblock 510 237 489 minecraft:red_terracotta
setblock 511 237 464 minecraft:terracotta
setblock 511 237 479 minecraft:terracotta
fill 511 237 480 511 240 480 minecraft:red_terracotta
setblock 511 237 484 minecraft:terracotta
fill 511 237 485 511 240 485 minecraft:red_terracotta
setblock 511 237 489 minecraft:terracotta
fill 511 237 490 511 240 490 minecraft:red_terracotta
setblock 511 237 494 minecraft:terracotta
fill 511 237 495 511 240 495 minecraft:red_terracotta
setblock 511 237 499 minecraft:terracotta
fill 511 237 500 511 239 500 minecraft:red_terracotta
setblock 511 237 504 minecraft:terracotta
fill 471 238 464 474 238 464 minecraft:red_terracotta
setblock 471 238 468 minecraft:terracotta
fill 471 238 469 471 241 469 minecraft:red_terracotta
fill 471 238 475 471 240 475 minecraft:red_terracotta
setblock 471 238 478 minecraft:terracotta
fill 471 238 479 471 241 479 minecraft:red_terracotta
setblock 471 238 482 minecraft:red_terracotta
setblock 471 238 483 minecraft:terracotta
fill 471 238 484 471 238 487 minecraft:red_terracotta
setblock 471 238 488 minecraft:terracotta
fill 471 238 489 471 241 489 minecraft:red_terracotta
setblock 471 238 492 minecraft:red_terracotta
setblock 471 238 503 minecraft:terracotta
fill 471 238 504 471 239 504 minecraft:red_terracotta
fill 472 238 465 472 238 466 minecraft:red_terracotta
setblock 472 238 477 minecraft:terracotta
fill 472 238 478 472 241 478 minecraft:red_terracotta
setblock 472 238 482 minecraft:terracotta
fill 472 238 483 472 238 486 minecraft:red_terracotta
setblock 472 238 487 minecraft:terracotta
fill 472 238 488 473 240 488 minecraft:red_terracotta
fill 472 238 490 472 239 490 minecraft:red_terracotta
setblock 473 238 465 minecraft:red_terracotta
setblock 473 238 466 minecraft:light[level=14]
setblock 473 238 474 minecraft:light[level=14]
setblock 473 238 481 minecraft:terracotta
fill 473 238 482 474 239 482 minecraft:red_terracotta
fill 473 238 484 473 238 485 minecraft:red_terracotta
setblock 473 238 486 minecraft:terracotta
fill 473 238 487 473 241 487 minecraft:red_terracotta
setblock 473 238 490 minecraft:light[level=14]
setblock 473 238 498 minecraft:light[level=14]
setblock 474 238 465 minecraft:terracotta
fill 474 238 466 477 238 466 minecraft:red_terracotta
setblock 474 238 481 minecraft:red_terracotta
fill 474 238 483 474 238 491 minecraft:basalt
setblock 475 238 464 minecraft:terracotta
fill 475 238 465 478 238 465 minecraft:red_terracotta
fill 475 238 485 475 239 485 minecraft:basalt
fill 475 238 488 475 239 488 minecraft:basalt
setblock 475 238 504 minecraft:terracotta
fill 476 238 464 479 238 464 minecraft:red_terracotta
setblock 476 238 479 minecraft:magma_block
fill 476 238 495 477 238 495 minecraft:basalt
setblock 476 238 503 minecraft:terracotta
fill 476 238 504 476 241 504 minecraft:red_terracotta
setblock 477 238 467 minecraft:terracotta
fill 477 238 477 477 238 479 minecraft:basalt
fill 477 238 496 477 238 497 minecraft:basalt
fill 477 238 503 477 240 503 minecraft:red_terracotta
setblock 478 238 466 minecraft:terracotta
fill 478 238 467 478 241 467 minecraft:red_terracotta
fill 478 238 476 480 238 476 minecraft:basalt
fill 478 238 478 478 239 478 minecraft:basalt
fill 478 238 496 478 239 496 minecraft:basalt
setblock 479 238 465 minecraft:terracotta
fill 479 238 466 479 241 466 minecraft:red_terracotta
setblock 479 238 475 minecraft:magma_block
setblock 479 238 499 minecraft:magma_block
fill 479 238 503 479 238 504 minecraft:red_terracotta
setblock 480 238 464 minecraft:terracotta
fill 480 238 465 480 241 465 minecraft:red_terracotta
fill 480 238 474 481 238 475 minecraft:basalt
fill 480 238 482 481 244 482 minecraft:basalt
fill 480 238 485 480 245 489 minecraft:basalt
fill 480 238 491 481 238 491 minecraft:basalt
fill 480 238 499 480 238 500 minecraft:basalt
setblock 480 238 503 minecraft:red_terracotta
setblock 480 238 504 minecraft:terracotta
fill 481 238 464 484 238 464 minecraft:red_terracotta
setblock 481 238 467 minecraft:red_terracotta
fill 481 238 483 481 244 483 minecraft:basalt
setblock 481 238 490 minecraft:light[level=14]
fill 481 238 492 481 244 492 minecraft:basalt
fill 481 238 499 481 239 499 minecraft:basalt
setblock 481 238 503 minecraft:terracotta
fill 481 238 504 481 241 504 minecraft:red_terracotta
setblock 482 238 466 minecraft:red_terracotta
fill 482 238 474 482 239 474 minecraft:basalt
fill 482 238 481 482 245 481 minecraft:basalt
fill 482 238 493 482 245 493 minecraft:basalt
setblock 482 238 501 minecraft:magma_block
fill 482 238 503 482 239 503 minecraft:red_terracotta
setblock 483 238 466 minecraft:terracotta
setblock 483 238 472 minecraft:basalt
fill 483 238 480 483 245 480 minecraft:basalt
fill 483 238 494 483 245 494 minecraft:basalt
fill 483 238 501 483 238 502 minecraft:basalt
setblock 484 238 465 minecraft:terracotta
fill 484 238 466 484 241 466 minecraft:red_terracotta
fill 484 238 479 484 244 479 minecraft:basalt
fill 484 238 495 484 245 495 minecraft:basalt
fill 484 238 501 485 239 501 minecraft:basalt
fill 484 238 503 484 238 504 minecraft:red_terracotta
setblock 485 238 464 minecraft:terracotta
fill 485 238 465 488 238 465 minecraft:red_terracotta
fill 485 238 478 486 245 478 minecraft:basalt
fill 485 238 496 486 245 496 minecraft:basalt
setblock 485 238 504 minecraft:terracotta
fill 486 238 464 489 238 464 minecraft:red_terracotta
setblock 486 238 471 minecraft:basalt
fill 486 238 477 486 244 477 minecraft:basalt
fill 486 238 503 489 238 503 minecraft:basalt
fill 486 238 504 489 238 504 minecraft:red_terracotta
fill 488 238 471 490 238 471 minecraft:basalt
fill 488 238 477 490 244 477 minecraft:basalt
fill 488 238 497 492 238 497 minecraft:basalt
setblock 489 238 465 minecraft:terracotta
setblock 489 238 466 minecraft:light[level=14]
fill 489 238 476 489 244 476 minecraft:basalt
setblock 489 238 482 minecraft:light[level=14]
setblock 489 238 490 minecraft:light[level=14]
setblock 490 238 464 minecraft:terracotta
fill 490 238 465 493 238 465 minecraft:red_terracotta
setblock 490 238 504 minecraft:terracotta
fill 491 238 464 494 238 464 minecraft:red_terracotta
fill 491 238 466 492 238 466 minecraft:red_terracotta
setblock 491 238 471 minecraft:magma_block
setblock 491 238 477 minecraft:magma_block
fill 491 238 503 493 238 503 minecraft:basalt
fill 491 238 504 494 238 504 minecraft:red_terracotta
fill 492 238 471 494 238 471 minecraft:basalt
fill 492 238 477 492 245 477 minecraft:basalt
setblock 493 238 466 minecraft:terracotta
setblock 494 238 465 minecraft:terracotta
fill 494 238 466 497 238 466 minecraft:red_terracotta
fill 494 238 472 496 238 472 minecraft:basalt
fill 494 238 478 495 245 478 minecraft:basalt
fill 494 238 496 495 245 496 minecraft:basalt
fill 494 238 502 496 238 502 minecraft:basalt
setblock 494 238 503 minecraft:magma_block
setblock 495 238 464 minecraft:terracotta
fill 495 238 465 498 238 465 minecraft:red_terracotta
fill 495 238 477 495 244 477 minecraft:basalt
setblock 495 238 503 minecraft:red_terracotta
setblock 495 238 504 minecraft:terracotta
fill 496 238 464 499 238 464 minecraft:red_terracotta
fill 496 238 479 496 245 479 minecraft:basalt
fill 496 238 495 496 245 495 minecraft:basalt
setblock 496 238 503 minecraft:terracotta
fill 496 238 504 499 238 504 minecraft:red_terracotta
setblock 497 238 472 minecraft:magma_block
fill 497 238 473 498 238 474 minecraft:basalt
fill 497 238 480 497 245 480 minecraft:basalt
setblock 497 238 482 minecraft:light[level=14]
setblock 497 238 490 minecraft:light[level=14]
fill 497 238 494 498 244 494 minecraft:basalt
setblock 497 238 502 minecraft:magma_block
fill 497 238 503 500 238 503 minecraft:red_terracotta
setblock 498 238 466 minecraft:terracotta
fill 498 238 481 498 245 481 minecraft:basalt
fill 498 238 493 498 245 493 minecraft:basalt
fill 498 238 502 501 238 502 minecraft:red_terracotta
setblock 499 238 465 minecraft:terracotta
fill 499 238 466 499 241 466 minecraft:red_terracotta
setblock 499 238 474 minecraft:basalt
fill 499 238 482 499 244 483 minecraft:basalt
fill 499 238 491 499 238 492 minecraft:basalt
fill 499 238 501 501 238 501 minecraft:red_terracotta
setblock 500 238 464 minecraft:terracotta
fill 500 238 465 500 241 465 minecraft:red_terracotta
setblock 500 238 474 minecraft:magma_block
fill 500 238 476 502 238 476 minecraft:basalt
fill 500 238 485 500 245 485 minecraft:basalt
setblock 500 238 486 minecraft:magma_block
fill 500 238 487 500 245 488 minecraft:basalt
setblock 500 238 489 minecraft:magma_block
fill 500 238 498 502 238 498 minecraft:basalt
setblock 500 238 500 minecraft:basalt
setblock 500 238 504 minecraft:terracotta
fill 501 238 464 501 241 464 minecraft:red_terracotta
fill 501 238 487 501 244 487 minecraft:basalt
fill 501 238 497 502 239 497 minecraft:basalt
setblock 501 238 503 minecraft:terracotta
fill 501 238 504 504 238 504 minecraft:red_terracotta
setblock 502 238 502 minecraft:terracotta
fill 502 238 503 505 238 503 minecraft:red_terracotta
fill 503 238 478 503 238 480 minecraft:basalt
fill 503 238 494 503 238 496 minecraft:basalt
setblock 503 238 497 minecraft:magma_block
fill 503 238 502 503 239 502 minecraft:red_terracotta
setblock 504 238 465 minecraft:terracotta
fill 504 238 479 504 238 480 minecraft:basalt
fill 504 238 494 504 238 495 minecraft:basalt
setblock 505 238 464 minecraft:terracotta
setblock 505 238 466 minecraft:light[level=14]
setblock 505 238 474 minecraft:light[level=14]
setblock 505 238 481 minecraft:basalt
fill 505 238 484 505 239 485 minecraft:basalt
fill 505 238 487 505 239 488 minecraft:basalt
fill 505 238 490 505 239 491 minecraft:basalt
setblock 505 238 498 minecraft:light[level=14]
setblock 505 238 504 minecraft:terracotta
fill 506 238 464 506 240 464 minecraft:red_terracotta
setblock 506 238 483 minecraft:basalt
setblock 506 238 484 minecraft:magma_block
fill 506 238 485 506 238 486 minecraft:basalt
setblock 506 238 487 minecraft:magma_block
fill 506 238 488 506 238 489 minecraft:basalt
setblock 506 238 490 minecraft:magma_block
setblock 506 238 491 minecraft:basalt
setblock 506 238 503 minecraft:terracotta
fill 506 238 504 506 241 504 minecraft:red_terracotta
setblock 507 238 503 minecraft:red_terracotta
setblock 509 238 464 minecraft:red_terracotta
setblock 510 238 464 minecraft:terracotta
setblock 510 238 483 minecraft:red_terracotta
setblock 510 238 484 minecraft:terracotta
fill 510 238 485 510 241 485 minecraft:red_terracotta
setblock 510 238 489 minecraft:terracotta
fill 510 238 490 510 241 490 minecraft:red_terracotta
setblock 510 238 504 minecraft:terracotta
fill 511 238 464 511 240 465 minecraft:red_terracotta
fill 511 238 479 511 240 479 minecraft:red_terracotta
setblock 511 238 483 minecraft:terracotta
fill 511 238 484 511 241 484 minecraft:red_terracotta
setblock 511 238 488 minecraft:terracotta
fill 511 238 489 511 241 489 minecraft:red_terracotta
fill 511 238 491 511 238 492 minecraft:red_terracotta
setblock 511 238 493 minecraft:terracotta
fill 511 238 494 511 241 494 minecraft:red_terracotta
setblock 511 238 498 minecraft:terracotta
fill 511 238 499 511 239 499 minecraft:red_terracotta
setblock 511 238 503 minecraft:terracotta
fill 511 238 504 511 241 504 minecraft:red_terracotta
fill 471 239 464 471 239 466 minecraft:red_terracotta
setblock 471 239 467 minecraft:terracotta
fill 471 239 468 472 241 468 minecraft:red_terracotta
fill 471 239 470 471 239 471 minecraft:red_terracotta
setblock 471 239 472 minecraft:terracotta
fill 471 239 473 471 241 474 minecraft:red_terracotta
setblock 471 239 477 minecraft:terracotta
fill 471 239 478 471 242 478 minecraft:red_terracotta
setblock 471 239 481 minecraft:red_terracotta
setblock 471 239 482 minecraft:terracotta
fill 471 239 483 471 239 486 minecraft:red_terracotta
setblock 471 239 487 minecraft:terracotta
fill 471 239 488 471 242 488 minecraft:red_terracotta
setblock 471 239 492 minecraft:terracotta
fill 471 239 493 471 242 493 minecraft:red_terracotta
fill 472 239 464 472 239 465 minecraft:red_terracotta
setblock 472 239 466 minecraft:terracotta
fill 472 239 467 472 242 467 minecraft:red_terracotta
fill 472 239 469 472 240 469 minecraft:red_terracotta
setblock 472 239 477 minecraft:red_terracotta
fill 472 239 479 472 239 480 minecraft:red_terracotta
setblock 472 239 481 minecraft:terracotta
fill 472 239 482 472 239 485 minecraft:red_terracotta
setblock 472 239 486 minecraft:terracotta
fill 472 239 487 472 242 487 minecraft:red_terracotta
setblock 472 239 491 minecraft:terracotta
setblock 473 239 464 minecraft:red_terracotta
setblock 473 239 465 minecraft:terracotta
setblock 473 239 480 minecraft:terracotta
fill 473 239 481 473 241 481 minecraft:red_terracotta
setblock 473 239 484 minecraft:red_terracotta
setblock 473 239 485 minecraft:terracotta
fill 473 239 486 474 240 486 minecraft:red_terracotta
setblock 473 239 489 minecraft:red_terracotta
setblock 474 239 464 minecraft:terracotta
fill 474 239 465 476 239 466 minecraft:red_terracotta
setblock 474 239 483 minecraft:red_terracotta
setblock 474 239 484 minecraft:terracotta
fill 474 239 485 474 240 485 minecraft:red_terracotta
fill 474 239 487 474 240 487 minecraft:red_terracotta
setblock 474 239 504 minecraft:terracotta
fill 475 239 464 478 239 464 minecraft:red_terracotta
setblock 475 239 484 minecraft:magma_block
setblock 475 239 487 minecraft:magma_block
setblock 475 239 490 minecraft:magma_block
setblock 475 239 503 minecraft:terracotta
fill 475 239 504 475 242 504 minecraft:red_terracotta
setblock 476 239 467 minecraft:terracotta
fill 476 239 480 477 239 480 minecraft:basalt
setblock 476 239 482 minecraft:basalt
setblock 476 239 492 minecraft:basalt
setblock 476 239 494 minecraft:basalt
fill 476 239 503 476 240 503 minecraft:red_terracotta
setblock 477 239 465 minecraft:red_terracotta
setblock 477 239 466 minecraft:terracotta
fill 477 239 467 477 242 467 minecraft:red_terracotta
setblock 477 239 479 minecraft:basalt
setblock 477 239 495 minecraft:basalt
setblock 478 239 465 minecraft:terracotta
fill 478 239 466 478 242 466 minecraft:red_terracotta
setblock 478 239 477 minecraft:magma_block
setblock 479 239 464 minecraft:terracotta
fill 479 239 465 479 242 465 minecraft:red_terracotta
fill 479 239 476 480 239 476 minecraft:basalt
setblock 479 239 503 minecraft:red_terracotta
setblock 479 239 504 minecraft:terracotta
fill 480 239 464 483 239 464 minecraft:red_terracotta
fill 480 239 475 481 239 475 minecraft:basalt
fill 480 239 491 480 244 491 minecraft:basalt
setblock 480 239 499 minecraft:basalt
setblock 480 239 503 minecraft:terracotta
fill 480 239 504 480 242 504 minecraft:red_terracotta
setblock 481 239 467 minecraft:terracotta
fill 481 239 484 481 245 484 minecraft:basalt
setblock 481 239 485 minecraft:magma_block
fill 481 239 489 481 244 490 minecraft:basalt
setblock 481 239 491 minecraft:magma_block
setblock 481 239 503 minecraft:red_terracotta
setblock 482 239 466 minecraft:terracotta
fill 482 239 482 482 245 482 minecraft:basalt
fill 482 239 492 482 245 492 minecraft:basalt
setblock 483 239 465 minecraft:terracotta
fill 483 239 466 483 242 466 minecraft:red_terracotta
fill 483 239 473 485 239 473 minecraft:basalt
fill 483 239 481 483 245 481 minecraft:basalt
fill 483 239 493 483 245 493 minecraft:basalt
setblock 483 239 501 minecraft:basalt
setblock 484 239 464 minecraft:terracotta
fill 484 239 465 487 239 465 minecraft:red_terracotta
fill 484 239 480 484 245 480 minecraft:basalt
fill 484 239 494 484 244 494 minecraft:basalt
setblock 484 239 504 minecraft:terracotta
fill 485 239 464 488 239 464 minecraft:red_terracotta
fill 485 239 470 490 273 471 minecraft:terracotta
fill 485 239 479 485 245 479 minecraft:basalt
fill 485 239 495 485 245 495 minecraft:basalt
fill 485 239 504 488 239 504 minecraft:red_terracotta
fill 486 239 469 489 273 469 minecraft:terracotta
fill 486 239 472 488 239 472 minecraft:basalt
fill 486 239 502 488 239 502 minecraft:basalt
fill 487 239 478 488 244 478 minecraft:basalt
fill 487 239 496 488 244 496 minecraft:basalt
setblock 488 239 465 minecraft:terracotta
fill 488 239 497 489 245 497 minecraft:basalt
setblock 489 239 464 minecraft:terracotta
fill 489 239 465 492 239 465 minecraft:red_terracotta
setblock 489 239 504 minecraft:terracotta
fill 490 239 464 493 239 464 minecraft:red_terracotta
fill 490 239 466 491 239 466 minecraft:red_terracotta
fill 490 239 472 492 239 472 minecraft:basalt
setblock 490 239 497 minecraft:magma_block
fill 490 239 502 492 239 502 minecraft:basalt
setblock 490 239 503 minecraft:terracotta
fill 490 239 504 493 239 504 minecraft:red_terracotta
fill 491 239 477 491 245 477 minecraft:basalt
fill 491 239 497 492 245 497 minecraft:basalt
fill 491 239 503 494 239 503 minecraft:red_terracotta
setblock 492 239 466 minecraft:terracotta
fill 492 239 478 492 245 478 minecraft:basalt
fill 492 239 496 492 245 496 minecraft:basalt
setblock 493 239 465 minecraft:terracotta
fill 493 239 466 496 239 466 minecraft:red_terracotta
setblock 493 239 472 minecraft:magma_block
setblock 493 239 478 minecraft:magma_block
setblock 493 239 496 minecraft:magma_block
setblock 493 239 502 minecraft:magma_block
setblock 494 239 464 minecraft:terracotta
fill 494 239 465 497 239 465 minecraft:red_terracotta
setblock 494 239 472 minecraft:basalt
setblock 494 239 502 minecraft:basalt
setblock 494 239 504 minecraft:terracotta
fill 495 239 464 498 239 464 minecraft:red_terracotta
fill 495 239 479 495 245 479 minecraft:basalt
fill 495 239 495 495 245 495 minecraft:basalt
setblock 495 239 502 minecraft:red_terracotta
setblock 495 239 503 minecraft:terracotta
fill 495 239 504 498 239 504 minecraft:red_terracotta
setblock 496 239 480 minecraft:magma_block
fill 496 239 494 496 245 494 minecraft:basalt
fill 496 239 500 498 239 500 minecraft:basalt
setblock 496 239 501 minecraft:magma_block
setblock 496 239 502 minecraft:terracotta
fill 496 239 503 499 239 503 minecraft:red_terracotta
setblock 497 239 466 minecraft:terracotta
fill 497 239 473 497 239 474 minecraft:basalt
fill 497 239 481 497 245 481 minecraft:basalt
fill 497 239 493 497 245 493 minecraft:basalt
setblock 497 239 501 minecraft:basalt
fill 497 239 502 500 239 502 minecraft:red_terracotta
setblock 498 239 465 minecraft:terracotta
fill 498 239 466 498 242 466 minecraft:red_terracotta
setblock 498 239 474 minecraft:basalt
fill 498 239 482 498 245 482 minecraft:basalt
fill 498 239 492 499 244 492 minecraft:basalt
setblock 498 239 501 minecraft:red_terracotta
setblock 499 239 464 minecraft:terracotta
fill 499 239 465 499 242 465 minecraft:red_terracotta
fill 499 239 475 500 239 475 minecraft:basalt
fill 499 239 484 499 245 484 minecraft:basalt
setblock 499 239 485 minecraft:magma_block
fill 499 239 489 499 244 490 minecraft:basalt
setblock 499 239 491 minecraft:magma_block
fill 499 239 499 500 239 499 minecraft:basalt
setblock 499 239 504 minecraft:terracotta
fill 500 239 464 500 242 464 minecraft:red_terracotta
fill 500 239 476 501 239 476 minecraft:basalt
fill 500 239 486 500 245 486 minecraft:basalt
fill 500 239 489 500 245 489 minecraft:basalt
fill 500 239 498 501 239 498 minecraft:basalt
setblock 500 239 503 minecraft:terracotta
fill 500 239 504 503 239 504 minecraft:red_terracotta
fill 501 239 477 501 239 478 minecraft:basalt
fill 501 239 496 501 240 496 minecraft:basalt
setblock 501 239 502 minecraft:terracotta
fill 501 239 503 504 239 503 minecraft:red_terracotta
setblock 502 239 477 minecraft:basalt
setblock 502 239 478 minecraft:magma_block
setblock 502 239 496 minecraft:magma_block
setblock 502 239 502 minecraft:red_terracotta
setblock 503 239 465 minecraft:terracotta
fill 503 239 479 503 239 480 minecraft:basalt
fill 503 239 494 503 239 495 minecraft:basalt
setblock 504 239 464 minecraft:terracotta
setblock 504 239 465 minecraft:red_terracotta
setblock 504 239 480 minecraft:basalt
setblock 504 239 494 minecraft:basalt
setblock 504 239 504 minecraft:terracotta
fill 505 239 464 505 241 464 minecraft:red_terracotta
setblock 505 239 483 minecraft:magma_block
setblock 505 239 486 minecraft:magma_block
setblock 505 239 489 minecraft:magma_block
setblock 505 239 503 minecraft:terracotta
fill 505 239 504 505 241 504 minecraft:red_terracotta
setblock 506 239 503 minecraft:red_terracotta
setblock 509 239 464 minecraft:terracotta
setblock 509 239 504 minecraft:terracotta
fill 510 239 464 510 240 464 minecraft:red_terracotta
setblock 510 239 483 minecraft:terracotta
fill 510 239 484 510 242 484 minecraft:red_terracotta
setblock 510 239 487 minecraft:red_terracotta
setblock 510 239 488 minecraft:terracotta
fill 510 239 489 510 242 489 minecraft:red_terracotta
fill 510 239 491 511 239 491 minecraft:red_terracotta
fill 510 239 504 510 240 504 minecraft:red_terracotta
setblock 511 239 466 minecraft:red_terracotta
setblock 511 239 482 minecraft:terracotta
fill 511 239 483 511 242 483 minecraft:red_terracotta
setblock 511 239 487 minecraft:terracotta
fill 511 239 488 511 242 488 minecraft:red_terracotta
setblock 511 239 492 minecraft:terracotta
fill 511 239 493 511 242 493 minecraft:red_terracotta
setblock 511 239 502 minecraft:terracotta
fill 511 239 503 511 240 503 minecraft:red_terracotta
fill 471 240 464 471 240 465 minecraft:red_terracotta
setblock 471 240 466 minecraft:terracotta
fill 471 240 467 471 243 467 minecraft:red_terracotta
setblock 471 240 470 minecraft:red_terracotta
setblock 471 240 471 minecraft:terracotta
fill 471 240 472 471 243 472 minecraft:red_terracotta
setblock 471 240 476 minecraft:terracotta
fill 471 240 477 471 243 477 minecraft:red_terracotta
setblock 471 240 481 minecraft:terracotta
fill 471 240 482 471 240 485 minecraft:red_terracotta
setblock 471 240 486 minecraft:terracotta
fill 471 240 487 471 243 487 minecraft:red_terracotta
setblock 471 240 491 minecraft:terracotta
fill 471 240 492 471 243 492 minecraft:red_terracotta
setblock 472 240 464 minecraft:red_terracotta
setblock 472 240 465 minecraft:terracotta
fill 472 240 466 475 240 466 minecraft:red_terracotta
setblock 472 240 470 minecraft:terracotta
fill 472 240 471 472 243 471 minecraft:red_terracotta
setblock 472 240 479 minecraft:red_terracotta
setblock 472 240 480 minecraft:terracotta
fill 472 240 481 472 240 484 minecraft:red_terracotta
setblock 472 240 485 minecraft:terracotta
fill 472 240 486 472 243 486 minecraft:red_terracotta
setblock 472 240 490 minecraft:terracotta
fill 472 240 491 472 243 491 minecraft:red_terracotta
setblock 473 240 464 minecraft:terracotta
fill 473 240 465 476 240 465 minecraft:red_terracotta
fill 473 240 467 473 240 468 minecraft:red_terracotta
setblock 473 240 480 minecraft:red_terracotta
fill 473 240 482 473 241 482 minecraft:red_terracotta
setblock 473 240 484 minecraft:terracotta
fill 473 240 485 473 243 485 minecraft:red_terracotta
setblock 473 240 489 minecraft:terracotta
setblock 473 240 504 minecraft:terracotta
fill 474 240 464 477 240 464 minecraft:red_terracotta
setblock 474 240 483 minecraft:terracotta
setblock 474 240 484 minecraft:red_terracotta
fill 474 240 504 474 243 504 minecraft:red_terracotta
setblock 476 240 466 minecraft:terracotta
fill 476 240 467 476 243 467 minecraft:red_terracotta
setblock 477 240 465 minecraft:terracotta
fill 477 240 466 477 243 466 minecraft:red_terracotta
setblock 477 240 480 minecraft:basalt
setblock 477 240 482 minecraft:magma_block
fill 477 240 483 477 241 483 minecraft:basalt
setblock 477 240 494 minecraft:magma_block
setblock 478 240 464 minecraft:terracotta
fill 478 240 465 478 243 465 minecraft:red_terracotta
fill 478 240 494 478 241 494 minecraft:basalt
setblock 478 240 504 minecraft:terracotta
fill 479 240 464 482 240 464 minecraft:red_terracotta
setblock 479 240 467 minecraft:red_terracotta
setblock 479 240 503 minecraft:terracotta
fill 479 240 504 479 243 504 minecraft:red_terracotta
setblock 480 240 467 minecraft:terracotta
setblock 480 240 503 minecraft:red_terracotta
setblock 481 240 466 minecraft:terracotta
setblock 481 240 467 minecraft:red_terracotta
fill 481 240 485 481 244 488 minecraft:basalt
fill 481 240 491 482 245 491 minecraft:basalt
setblock 482 240 465 minecraft:terracotta
fill 482 240 466 482 242 466 minecraft:red_terracotta
fill 482 240 483 482 245 484 minecraft:basalt
fill 482 240 490 482 245 490 minecraft:basalt
setblock 483 240 464 minecraft:terracotta
fill 483 240 465 486 240 465 minecraft:red_terracotta
setblock 483 240 474 minecraft:magma_block
fill 483 240 475 483 241 475 minecraft:basalt
fill 483 240 482 483 245 482 minecraft:basalt
setblock 483 240 492 minecraft:magma_block
setblock 483 240 500 minecraft:basalt
setblock 483 240 504 minecraft:terracotta
fill 484 240 464 487 240 464 minecraft:red_terracotta
fill 484 240 470 484 241 472 minecraft:brown_terracotta
fill 484 240 481 484 245 481 minecraft:basalt
fill 484 240 493 484 245 493 minecraft:basalt
fill 484 240 504 487 240 504 minecraft:red_terracotta
setblock 485 240 466 minecraft:red_terracotta
fill 485 240 468 485 241 469 minecraft:brown_terracotta
fill 485 240 472 485 241 473 minecraft:brown_terracotta
fill 485 240 480 485 245 480 minecraft:basalt
fill 485 240 494 485 245 494 minecraft:basalt
fill 486 240 468 490 241 468 minecraft:brown_terracotta
fill 486 240 472 489 273 472 minecraft:terracotta
setblock 486 240 473 minecraft:magma_block
setblock 486 240 479 minecraft:magma_block
fill 486 240 495 487 245 495 minecraft:basalt
setblock 487 240 465 minecraft:terracotta
fill 487 240 467 488 241 467 minecraft:brown_terracotta
fill 487 240 479 487 245 479 minecraft:basalt
setblock 488 240 464 minecraft:terracotta
fill 488 240 465 491 240 465 minecraft:red_terracotta
setblock 488 240 504 minecraft:terracotta
fill 489 240 464 492 240 464 minecraft:red_terracotta
setblock 489 240 473 minecraft:basalt
setblock 489 240 478 minecraft:magma_block
setblock 489 240 496 minecraft:magma_block
fill 489 240 501 491 240 501 minecraft:basalt
fill 489 240 504 492 240 504 minecraft:red_terracotta
setblock 490 240 466 minecraft:red_terracotta
fill 490 240 469 490 241 469 minecraft:brown_terracotta
fill 490 240 472 490 241 472 minecraft:brown_terracotta
fill 490 240 478 491 245 478 minecraft:basalt
fill 490 240 496 490 245 497 minecraft:basalt
fill 490 240 503 493 240 503 minecraft:red_terracotta
setblock 491 240 466 minecraft:terracotta
fill 491 240 470 491 241 471 minecraft:brown_terracotta
fill 491 240 496 491 245 496 minecraft:basalt
setblock 492 240 465 minecraft:terracotta
fill 492 240 466 495 240 466 minecraft:red_terracotta
setblock 492 240 501 minecraft:magma_block
setblock 493 240 464 minecraft:terracotta
fill 493 240 465 496 240 465 minecraft:red_terracotta
fill 493 240 478 493 244 479 minecraft:basalt
fill 493 240 495 493 245 496 minecraft:basalt
setblock 493 240 504 minecraft:terracotta
fill 494 240 464 497 240 464 minecraft:red_terracotta
fill 494 240 479 494 245 479 minecraft:basalt
fill 494 240 495 494 245 495 minecraft:basalt
fill 494 240 500 494 241 500 minecraft:basalt
setblock 494 240 502 minecraft:red_terracotta
setblock 494 240 503 minecraft:terracotta
fill 494 240 504 497 240 504 minecraft:red_terracotta
fill 495 240 480 496 245 480 minecraft:basalt
setblock 495 240 494 minecraft:magma_block
setblock 495 240 500 minecraft:magma_block
setblock 495 240 502 minecraft:terracotta
fill 495 240 503 498 240 503 minecraft:red_terracotta
setblock 496 240 466 minecraft:terracotta
fill 496 240 474 497 240 474 minecraft:basalt
fill 496 240 481 496 244 481 minecraft:basalt
fill 496 240 493 496 244 493 minecraft:basalt
fill 496 240 500 497 240 500 minecraft:basalt
fill 496 240 502 499 240 502 minecraft:red_terracotta
setblock 497 240 465 minecraft:terracotta
fill 497 240 466 497 243 466 minecraft:red_terracotta
fill 497 240 475 497 241 475 minecraft:basalt
fill 497 240 482 497 245 482 minecraft:basalt
setblock 497 240 492 minecraft:basalt
fill 497 240 499 497 241 499 minecraft:basalt
setblock 498 240 464 minecraft:terracotta
fill 498 240 465 498 243 465 minecraft:red_terracotta
setblock 498 240 475 minecraft:magma_block
fill 498 240 483 498 245 483 minecraft:basalt
setblock 498 240 484 minecraft:magma_block
setblock 498 240 490 minecraft:magma_block
fill 498 240 491 499 245 491 minecraft:basalt
setblock 498 240 499 minecraft:magma_block
setblock 498 240 504 minecraft:terracotta
fill 499 240 464 499 243 464 minecraft:red_terracotta
fill 499 240 485 499 244 488 minecraft:basalt
setblock 499 240 503 minecraft:terracotta
fill 499 240 504 502 240 504 minecraft:red_terracotta
setblock 500 240 502 minecraft:terracotta
fill 500 240 503 503 240 503 minecraft:red_terracotta
setblock 501 240 478 minecraft:basalt
setblock 501 240 502 minecraft:red_terracotta
setblock 502 240 465 minecraft:terracotta
setblock 503 240 464 minecraft:terracotta
setblock 503 240 465 minecraft:red_terracotta
setblock 503 240 480 minecraft:basalt
setblock 503 240 494 minecraft:basalt
setblock 503 240 504 minecraft:terracotta
fill 504 240 464 504 241 464 minecraft:red_terracotta
setblock 504 240 485 minecraft:magma_block
fill 504 240 486 504 240 487 minecraft:basalt
setblock 504 240 488 minecraft:magma_block
setblock 504 240 491 minecraft:magma_block
setblock 504 240 503 minecraft:terracotta
fill 504 240 504 504 242 504 minecraft:red_terracotta
setblock 508 240 504 minecraft:terracotta
setblock 509 240 464 minecraft:red_terracotta
setblock 509 240 504 minecraft:red_terracotta
setblock 510 240 482 minecraft:terracotta
fill 510 240 483 510 242 483 minecraft:red_terracotta
setblock 510 240 487 minecraft:terracotta
fill 510 240 488 510 243 488 minecraft:red_terracotta
setblock 510 240 491 minecraft:red_terracotta
setblock 510 240 492 minecraft:terracotta
setblock 511 240 466 minecraft:terracotta
fill 511 240 467 511 243 467 minecraft:red_terracotta
setblock 511 240 481 minecraft:terracotta
fill 511 240 482 511 243 482 minecraft:red_terracotta
setblock 511 240 486 minecraft:terracotta
fill 511 240 487 511 243 487 minecraft:red_terracotta
setblock 511 240 491 minecraft:terracotta
fill 511 240 492 511 243 492 minecraft:red_terracotta
setblock 511 240 496 minecraft:terracotta
setblock 511 240 502 minecraft:red_terracotta
setblock 471 241 464 minecraft:red_terracotta
setblock 471 241 465 minecraft:terracotta
fill 471 241 466 474 241 466 minecraft:red_terracotta
setblock 471 241 470 minecraft:terracotta
fill 471 241 471 471 244 471 minecraft:red_terracotta
setblock 471 241 475 minecraft:terracotta
fill 471 241 476 471 244 476 minecraft:red_terracotta
setblock 471 241 480 minecraft:terracotta
fill 471 241 481 471 241 484 minecraft:red_terracotta
setblock 471 241 485 minecraft:terracotta
fill 471 241 486 471 244 486 minecraft:red_terracotta
setblock 471 241 490 minecraft:terracotta
fill 471 241 491 471 244 491 minecraft:red_terracotta
setblock 472 241 464 minecraft:terracotta
fill 472 241 465 475 241 465 minecraft:red_terracotta
setblock 472 241 469 minecraft:terracotta
fill 472 241 470 472 244 470 minecraft:red_terracotta
fill 472 241 472 472 242 472 minecraft:red_terracotta
setblock 472 241 479 minecraft:terracotta
fill 472 241 480 472 241 483 minecraft:red_terracotta
setblock 472 241 484 minecraft:terracotta
fill 472 241 485 472 244 485 minecraft:red_terracotta
setblock 472 241 488 minecraft:red_terracotta
setblock 472 241 489 minecraft:terracotta
fill 472 241 490 472 244 490 minecraft:red_terracotta
setblock 472 241 504 minecraft:terracotta
fill 473 241 464 476 241 464 minecraft:red_terracotta
setblock 473 241 467 minecraft:red_terracotta
setblock 473 241 468 minecraft:terracotta
fill 473 241 469 473 244 469 minecraft:red_terracotta
setblock 473 241 483 minecraft:terracotta
fill 473 241 484 473 243 484 minecraft:red_terracotta
fill 473 241 486 473 242 486 minecraft:red_terracotta
setblock 473 241 488 minecraft:terracotta
fill 473 241 489 473 244 489 minecraft:red_terracotta
fill 473 241 504 473 242 504 minecraft:red_terracotta
setblock 475 241 466 minecraft:terracotta
fill 475 241 467 475 243 467 minecraft:red_terracotta
setblock 476 241 465 minecraft:terracotta
fill 476 241 466 476 244 466 minecraft:red_terracotta
setblock 477 241 464 minecraft:terracotta
fill 477 241 465 477 244 465 minecraft:red_terracotta
setblock 477 241 482 minecraft:basalt
setblock 477 241 484 minecraft:basalt
setblock 477 241 490 minecraft:basalt
setblock 477 241 504 minecraft:terracotta
fill 478 241 464 481 241 464 minecraft:red_terracotta
fill 478 241 504 478 243 504 minecraft:red_terracotta
setblock 479 241 467 minecraft:terracotta
fill 479 241 494 479 242 494 minecraft:basalt
setblock 479 241 495 minecraft:magma_block
setblock 480 241 466 minecraft:terracotta
setblock 480 241 467 minecraft:red_terracotta
setblock 481 241 465 minecraft:terracotta
fill 481 241 466 481 243 466 minecraft:red_terracotta
setblock 482 241 464 minecraft:terracotta
fill 482 241 465 485 241 465 minecraft:red_terracotta
setblock 482 241 476 minecraft:magma_block
setblock 482 241 485 minecraft:magma_block
fill 482 241 486 482 245 487 minecraft:basalt
setblock 482 241 488 minecraft:magma_block
fill 482 241 489 482 245 489 minecraft:basalt
setblock 482 241 504 minecraft:terracotta
fill 483 241 464 486 241 464 minecraft:red_terracotta
fill 483 241 469 483 241 472 minecraft:brown_terracotta
fill 483 241 476 483 242 476 minecraft:basalt
fill 483 241 483 483 245 483 minecraft:basalt
fill 483 241 491 483 245 492 minecraft:basalt
fill 483 241 504 486 241 504 minecraft:red_terracotta
fill 484 241 468 484 241 469 minecraft:brown_terracotta
fill 484 241 473 484 241 474 minecraft:brown_terracotta
fill 485 241 467 486 241 467 minecraft:brown_terracotta
setblock 486 241 465 minecraft:terracotta
fill 486 241 473 488 273 473 minecraft:terracotta
fill 486 241 479 486 245 480 minecraft:basalt
fill 486 241 494 486 245 494 minecraft:basalt
setblock 487 241 464 minecraft:terracotta
fill 487 241 465 490 241 465 minecraft:red_terracotta
fill 487 241 466 488 241 466 minecraft:brown_terracotta
setblock 487 241 504 minecraft:terracotta
fill 488 241 464 491 241 464 minecraft:red_terracotta
setblock 488 241 474 minecraft:magma_block
fill 488 241 479 490 245 479 minecraft:basalt
setblock 488 241 495 minecraft:magma_block
fill 488 241 500 490 241 500 minecraft:basalt
fill 488 241 504 491 241 504 minecraft:red_terracotta
fill 489 241 467 490 241 467 minecraft:brown_terracotta
fill 489 241 473 491 241 473 minecraft:brown_terracotta
fill 489 241 478 489 245 478 minecraft:basalt
fill 489 241 495 489 245 496 minecraft:basalt
setblock 490 241 466 minecraft:terracotta
fill 490 241 495 492 244 495 minecraft:basalt
setblock 491 241 465 minecraft:terracotta
schedule function dropper:buildpart/118_9 1t
