setblock 19 132 584 minecraft:light[level=14]
setblock 19 132 592 minecraft:light[level=14]
fill 20 132 561 20 133 561 minecraft:black_concrete
fill 22 132 561 22 133 561 minecraft:black_concrete
setblock 23 132 598 minecraft:black_concrete
fill 26 132 561 26 133 561 minecraft:black_concrete
setblock 27 132 558 minecraft:black_concrete
setblock 27 132 560 minecraft:light[level=14]
setblock 27 132 568 minecraft:light[level=14]
setblock 27 132 576 minecraft:light[level=14]
setblock 27 132 584 minecraft:light[level=14]
setblock 27 132 592 minecraft:light[level=14]
fill 28 132 561 28 133 561 minecraft:black_concrete
setblock 33 132 598 minecraft:black_concrete
setblock 35 132 560 minecraft:light[level=14]
setblock 35 132 568 minecraft:light[level=14]
setblock 35 132 576 minecraft:light[level=14]
setblock 35 132 584 minecraft:light[level=14]
setblock 35 132 592 minecraft:light[level=14]
setblock 37 132 558 minecraft:black_concrete
fill 37 132 564 37 133 564 minecraft:black_concrete
fill 37 132 572 37 133 572 minecraft:black_concrete
setblock 41 132 564 minecraft:black_concrete
setblock 41 132 574 minecraft:black_concrete
setblock 41 132 584 minecraft:black_concrete
setblock 41 132 594 minecraft:black_concrete
fill 3 133 589 3 134 589 minecraft:black_concrete
fill 20 133 560 20 134 560 minecraft:black_concrete
fill 22 133 560 22 134 560 minecraft:black_concrete
fill 26 133 560 26 134 560 minecraft:black_concrete
fill 28 133 560 28 134 560 minecraft:black_concrete
fill 38 133 564 38 134 564 minecraft:black_concrete
fill 38 133 572 38 134 572 minecraft:black_concrete
fill 2 134 589 2 135 589 minecraft:black_concrete
fill 20 134 559 20 135 559 minecraft:black_concrete
fill 22 134 559 22 135 559 minecraft:black_concrete
fill 26 134 559 26 135 559 minecraft:black_concrete
fill 28 134 559 28 135 559 minecraft:black_concrete
fill 39 134 564 39 135 564 minecraft:black_concrete
fill 39 134 572 39 135 572 minecraft:black_concrete
fill 1 135 562 1 135 565 minecraft:black_concrete
fill 1 135 572 1 135 575 minecraft:black_concrete
fill 1 135 582 1 135 585 minecraft:black_concrete
fill 1 135 592 1 135 595 minecraft:black_concrete
fill 2 135 558 5 135 558 minecraft:black_concrete
fill 5 135 598 8 135 598 minecraft:black_concrete
fill 12 135 558 15 135 558 minecraft:black_concrete
fill 15 135 598 18 135 598 minecraft:black_concrete
fill 20 135 558 20 137 558 minecraft:black_concrete
fill 22 135 558 26 135 558 minecraft:black_concrete
fill 25 135 598 28 135 598 minecraft:black_concrete
fill 32 135 558 35 135 558 minecraft:black_concrete
fill 35 135 598 38 135 598 minecraft:black_concrete
fill 40 135 564 40 137 564 minecraft:black_concrete
fill 40 135 572 41 135 572 minecraft:black_concrete
fill 41 135 559 41 135 562 minecraft:black_concrete
fill 41 135 569 41 135 571 minecraft:black_concrete
fill 41 135 579 41 135 582 minecraft:black_concrete
fill 41 135 589 41 135 592 minecraft:black_concrete
setblock 4 136 565 minecraft:sea_lantern
setblock 4 136 571 minecraft:sea_lantern
setblock 4 136 577 minecraft:sea_lantern
setblock 4 136 583 minecraft:sea_lantern
setblock 4 136 589 minecraft:sea_lantern
setblock 4 136 595 minecraft:sea_lantern
setblock 8 136 561 minecraft:sea_lantern
setblock 10 136 595 minecraft:sea_lantern
setblock 14 136 561 minecraft:sea_lantern
setblock 16 136 595 minecraft:sea_lantern
setblock 20 136 561 minecraft:sea_lantern
fill 22 136 558 22 137 558 minecraft:black_concrete
setblock 22 136 595 minecraft:sea_lantern
fill 26 136 558 26 137 558 minecraft:black_concrete
setblock 26 136 561 minecraft:sea_lantern
setblock 28 136 595 minecraft:sea_lantern
setblock 32 136 561 minecraft:sea_lantern
setblock 34 136 595 minecraft:sea_lantern
setblock 38 136 561 minecraft:sea_lantern
setblock 38 136 567 minecraft:sea_lantern
setblock 38 136 573 minecraft:sea_lantern
setblock 38 136 579 minecraft:sea_lantern
setblock 38 136 585 minecraft:sea_lantern
setblock 38 136 591 minecraft:sea_lantern
fill 40 136 572 40 137 572 minecraft:black_concrete
fill 1 137 558 7 137 558 minecraft:black_concrete
fill 1 137 560 4 137 568 minecraft:black_concrete
fill 1 137 570 4 137 578 minecraft:black_concrete
fill 1 137 580 4 137 588 minecraft:black_concrete
fill 1 137 590 1 137 598 minecraft:black_concrete
fill 2 137 559 41 137 559 minecraft:black_concrete
fill 2 137 569 4 137 569 minecraft:black_concrete
fill 2 137 579 4 137 579 minecraft:black_concrete
fill 2 137 589 4 137 597 minecraft:black_concrete
fill 3 137 598 11 137 598 minecraft:black_concrete
fill 5 137 560 41 137 561 minecraft:black_concrete
fill 5 137 595 40 137 597 minecraft:black_concrete
fill 9 137 558 17 137 558 minecraft:black_concrete
fill 13 137 598 21 137 598 minecraft:black_concrete
setblock 19 137 558 minecraft:black_concrete
setblock 21 137 558 minecraft:black_concrete
fill 23 137 558 25 137 558 minecraft:black_concrete
fill 23 137 598 31 137 598 minecraft:black_concrete
fill 27 137 558 27 138 558 minecraft:black_concrete
fill 29 137 558 37 137 558 minecraft:black_concrete
fill 33 137 598 41 137 598 minecraft:black_concrete
fill 38 137 562 39 137 594 minecraft:black_concrete
fill 39 137 558 41 137 558 minecraft:black_concrete
fill 40 137 562 41 137 563 minecraft:black_concrete
fill 40 137 565 40 137 571 minecraft:black_concrete
fill 40 137 573 40 137 594 minecraft:black_concrete
fill 41 137 564 41 138 564 minecraft:black_concrete
fill 41 137 566 41 137 574 minecraft:black_concrete
fill 41 137 576 41 137 584 minecraft:black_concrete
fill 41 137 586 41 137 594 minecraft:black_concrete
fill 41 137 596 41 137 597 minecraft:black_concrete
setblock 1 138 560 minecraft:black_concrete
setblock 1 138 570 minecraft:black_concrete
setblock 1 138 580 minecraft:black_concrete
setblock 1 138 590 minecraft:black_concrete
setblock 3 138 598 minecraft:black_concrete
fill 4 138 561 4 138 595 minecraft:cyan_concrete
fill 5 138 561 38 138 561 minecraft:cyan_concrete
fill 5 138 595 38 138 595 minecraft:cyan_concrete
setblock 7 138 558 minecraft:black_concrete
setblock 13 138 598 minecraft:black_concrete
setblock 17 138 558 minecraft:black_concrete
setblock 23 138 598 minecraft:black_concrete
setblock 33 138 598 minecraft:black_concrete
setblock 37 138 558 minecraft:black_concrete
fill 38 138 562 38 138 594 minecraft:cyan_concrete
setblock 41 138 574 minecraft:black_concrete
setblock 41 138 584 minecraft:black_concrete
setblock 41 138 594 minecraft:black_concrete
fill 0 139 563 0 139 566 minecraft:sea_lantern
fill 0 139 573 0 139 576 minecraft:sea_lantern
fill 0 139 583 0 139 586 minecraft:sea_lantern
fill 0 139 593 0 139 596 minecraft:sea_lantern
fill 3 139 557 6 139 557 minecraft:sea_lantern
fill 4 139 599 7 139 599 minecraft:sea_lantern
fill 13 139 557 16 139 557 minecraft:sea_lantern
fill 14 139 599 17 139 599 minecraft:sea_lantern
fill 23 139 557 26 139 557 minecraft:sea_lantern
fill 24 139 599 27 139 599 minecraft:sea_lantern
fill 33 139 557 36 139 557 minecraft:sea_lantern
fill 34 139 599 37 139 599 minecraft:sea_lantern
fill 42 139 558 42 139 561 minecraft:sea_lantern
fill 42 139 568 42 139 571 minecraft:sea_lantern
fill 42 139 578 42 139 581 minecraft:sea_lantern
fill 42 139 588 42 139 591 minecraft:sea_lantern
setblock 42 139 598 minecraft:sea_lantern
fill 0 140 563 0 147 566 minecraft:cyan_concrete
fill 0 140 573 0 147 576 minecraft:cyan_concrete
fill 0 140 583 0 147 586 minecraft:cyan_concrete
fill 0 140 593 0 147 596 minecraft:cyan_concrete
fill 3 140 557 6 147 557 minecraft:cyan_concrete
setblock 3 140 560 minecraft:light[level=14]
setblock 3 140 568 minecraft:light[level=14]
setblock 3 140 576 minecraft:light[level=14]
setblock 3 140 584 minecraft:light[level=14]
setblock 3 140 592 minecraft:light[level=14]
fill 4 140 599 7 147 599 minecraft:cyan_concrete
setblock 11 140 560 minecraft:light[level=14]
setblock 11 140 568 minecraft:light[level=14]
setblock 11 140 576 minecraft:light[level=14]
setblock 11 140 584 minecraft:light[level=14]
setblock 11 140 592 minecraft:light[level=14]
fill 13 140 557 16 147 557 minecraft:cyan_concrete
fill 14 140 599 17 147 599 minecraft:cyan_concrete
setblock 19 140 560 minecraft:light[level=14]
setblock 19 140 568 minecraft:light[level=14]
setblock 19 140 576 minecraft:light[level=14]
setblock 19 140 584 minecraft:light[level=14]
setblock 19 140 592 minecraft:light[level=14]
fill 23 140 557 26 147 557 minecraft:cyan_concrete
fill 24 140 599 27 147 599 minecraft:cyan_concrete
setblock 27 140 560 minecraft:light[level=14]
setblock 27 140 568 minecraft:light[level=14]
setblock 27 140 576 minecraft:light[level=14]
setblock 27 140 584 minecraft:light[level=14]
setblock 27 140 592 minecraft:light[level=14]
fill 33 140 557 36 147 557 minecraft:cyan_concrete
fill 34 140 599 37 147 599 minecraft:cyan_concrete
setblock 35 140 560 minecraft:light[level=14]
setblock 35 140 568 minecraft:light[level=14]
setblock 35 140 576 minecraft:light[level=14]
setblock 35 140 584 minecraft:light[level=14]
setblock 35 140 592 minecraft:light[level=14]
fill 42 140 558 42 147 561 minecraft:cyan_concrete
fill 42 140 568 42 147 571 minecraft:cyan_concrete
fill 42 140 578 42 147 581 minecraft:cyan_concrete
fill 42 140 588 42 147 591 minecraft:cyan_concrete
fill 42 140 598 42 147 598 minecraft:cyan_concrete
setblock 1 144 560 minecraft:black_concrete
fill 1 144 562 1 144 565 minecraft:black_concrete
setblock 1 144 570 minecraft:black_concrete
fill 1 144 572 1 144 575 minecraft:black_concrete
setblock 1 144 580 minecraft:black_concrete
fill 1 144 582 1 144 585 minecraft:black_concrete
setblock 1 144 590 minecraft:black_concrete
fill 1 144 592 1 144 595 minecraft:black_concrete
fill 2 144 558 5 144 558 minecraft:black_concrete
setblock 3 144 598 minecraft:black_concrete
fill 5 144 598 8 144 598 minecraft:black_concrete
setblock 7 144 558 minecraft:black_concrete
fill 12 144 558 15 144 558 minecraft:black_concrete
setblock 13 144 598 minecraft:black_concrete
fill 15 144 598 18 144 598 minecraft:black_concrete
setblock 17 144 558 minecraft:black_concrete
fill 22 144 558 25 144 558 minecraft:black_concrete
setblock 23 144 598 minecraft:black_concrete
fill 25 144 598 28 144 598 minecraft:black_concrete
setblock 27 144 558 minecraft:black_concrete
fill 32 144 558 35 144 558 minecraft:black_concrete
setblock 33 144 598 minecraft:black_concrete
fill 35 144 598 38 144 598 minecraft:black_concrete
setblock 37 144 558 minecraft:black_concrete
fill 41 144 559 41 144 562 minecraft:black_concrete
setblock 41 144 564 minecraft:black_concrete
fill 41 144 569 41 144 572 minecraft:black_concrete
setblock 41 144 574 minecraft:black_concrete
fill 41 144 579 41 144 582 minecraft:black_concrete
setblock 41 144 584 minecraft:black_concrete
fill 41 144 589 41 144 592 minecraft:black_concrete
setblock 41 144 594 minecraft:black_concrete
fill 0 148 563 0 148 566 minecraft:sea_lantern
fill 0 148 573 0 148 576 minecraft:sea_lantern
fill 0 148 583 0 148 586 minecraft:sea_lantern
fill 0 148 593 0 148 596 minecraft:sea_lantern
fill 3 148 557 6 148 557 minecraft:sea_lantern
setblock 3 148 560 minecraft:light[level=14]
setblock 3 148 568 minecraft:light[level=14]
setblock 3 148 576 minecraft:light[level=14]
setblock 3 148 584 minecraft:light[level=14]
setblock 3 148 592 minecraft:light[level=14]
fill 4 148 599 7 148 599 minecraft:sea_lantern
setblock 11 148 560 minecraft:light[level=14]
setblock 11 148 568 minecraft:light[level=14]
setblock 11 148 576 minecraft:light[level=14]
setblock 11 148 584 minecraft:light[level=14]
setblock 11 148 592 minecraft:light[level=14]
fill 13 148 557 16 148 557 minecraft:sea_lantern
fill 14 148 599 17 148 599 minecraft:sea_lantern
setblock 19 148 560 minecraft:light[level=14]
setblock 19 148 568 minecraft:light[level=14]
setblock 19 148 576 minecraft:light[level=14]
setblock 19 148 584 minecraft:light[level=14]
setblock 19 148 592 minecraft:light[level=14]
fill 23 148 557 26 148 557 minecraft:sea_lantern
fill 24 148 599 27 148 599 minecraft:sea_lantern
setblock 27 148 560 minecraft:light[level=14]
setblock 27 148 568 minecraft:light[level=14]
setblock 27 148 576 minecraft:light[level=14]
setblock 27 148 584 minecraft:light[level=14]
setblock 27 148 592 minecraft:light[level=14]
fill 33 148 557 36 148 557 minecraft:sea_lantern
fill 34 148 599 37 148 599 minecraft:sea_lantern
setblock 35 148 560 minecraft:light[level=14]
setblock 35 148 568 minecraft:light[level=14]
setblock 35 148 576 minecraft:light[level=14]
setblock 35 148 584 minecraft:light[level=14]
setblock 35 148 592 minecraft:light[level=14]
fill 42 148 558 42 148 561 minecraft:sea_lantern
fill 42 148 568 42 148 571 minecraft:sea_lantern
fill 42 148 578 42 148 581 minecraft:sea_lantern
fill 42 148 588 42 148 591 minecraft:sea_lantern
setblock 42 148 598 minecraft:sea_lantern
fill 0 149 563 0 156 566 minecraft:cyan_concrete
fill 0 149 573 0 156 576 minecraft:cyan_concrete
fill 0 149 583 0 156 586 minecraft:cyan_concrete
fill 0 149 593 0 156 596 minecraft:cyan_concrete
fill 3 149 557 6 156 557 minecraft:cyan_concrete
fill 4 149 599 7 156 599 minecraft:cyan_concrete
fill 13 149 557 16 156 557 minecraft:cyan_concrete
fill 14 149 599 17 156 599 minecraft:cyan_concrete
fill 23 149 557 26 156 557 minecraft:cyan_concrete
fill 24 149 599 27 156 599 minecraft:cyan_concrete
fill 33 149 557 36 156 557 minecraft:cyan_concrete
fill 34 149 599 37 156 599 minecraft:cyan_concrete
fill 42 149 558 42 156 561 minecraft:cyan_concrete
fill 42 149 568 42 156 571 minecraft:cyan_concrete
fill 42 149 578 42 156 581 minecraft:cyan_concrete
fill 42 149 588 42 156 591 minecraft:cyan_concrete
fill 42 149 598 42 156 598 minecraft:cyan_concrete
setblock 1 150 560 minecraft:black_concrete
setblock 1 150 570 minecraft:black_concrete
setblock 1 150 580 minecraft:black_concrete
setblock 1 150 590 minecraft:black_concrete
setblock 3 150 598 minecraft:black_concrete
setblock 7 150 558 minecraft:black_concrete
setblock 13 150 598 minecraft:black_concrete
setblock 17 150 558 minecraft:black_concrete
setblock 23 150 598 minecraft:black_concrete
setblock 27 150 558 minecraft:black_concrete
setblock 33 150 598 minecraft:black_concrete
setblock 37 150 558 minecraft:black_concrete
setblock 41 150 564 minecraft:black_concrete
setblock 41 150 574 minecraft:black_concrete
setblock 41 150 584 minecraft:black_concrete
setblock 41 150 594 minecraft:black_concrete
fill 1 153 562 1 153 565 minecraft:black_concrete
fill 1 153 572 1 153 575 minecraft:black_concrete
fill 1 153 582 1 153 585 minecraft:black_concrete
fill 1 153 592 1 153 595 minecraft:black_concrete
fill 2 153 558 5 153 558 minecraft:black_concrete
fill 5 153 598 8 153 598 minecraft:black_concrete
fill 12 153 558 15 153 558 minecraft:black_concrete
fill 15 153 598 18 153 598 minecraft:black_concrete
fill 22 153 558 25 153 558 minecraft:black_concrete
fill 25 153 598 28 153 598 minecraft:black_concrete
fill 32 153 558 35 153 558 minecraft:black_concrete
fill 35 153 598 38 153 598 minecraft:black_concrete
fill 41 153 559 41 153 562 minecraft:black_concrete
fill 41 153 569 41 153 572 minecraft:black_concrete
fill 41 153 579 41 153 582 minecraft:black_concrete
fill 41 153 589 41 153 592 minecraft:black_concrete
setblock 1 156 560 minecraft:black_concrete
setblock 1 156 570 minecraft:black_concrete
setblock 1 156 580 minecraft:black_concrete
setblock 1 156 590 minecraft:black_concrete
setblock 3 156 560 minecraft:light[level=14]
setblock 3 156 568 minecraft:light[level=14]
setblock 3 156 576 minecraft:light[level=14]
setblock 3 156 584 minecraft:light[level=14]
setblock 3 156 592 minecraft:light[level=14]
setblock 3 156 598 minecraft:black_concrete
setblock 7 156 558 minecraft:black_concrete
setblock 11 156 560 minecraft:light[level=14]
setblock 11 156 568 minecraft:light[level=14]
setblock 11 156 576 minecraft:light[level=14]
setblock 11 156 584 minecraft:light[level=14]
setblock 11 156 592 minecraft:light[level=14]
setblock 13 156 598 minecraft:black_concrete
setblock 17 156 558 minecraft:black_concrete
setblock 19 156 560 minecraft:light[level=14]
setblock 19 156 568 minecraft:light[level=14]
setblock 19 156 576 minecraft:light[level=14]
setblock 19 156 584 minecraft:light[level=14]
setblock 19 156 592 minecraft:light[level=14]
setblock 23 156 598 minecraft:black_concrete
setblock 27 156 558 minecraft:black_concrete
setblock 27 156 560 minecraft:light[level=14]
setblock 27 156 568 minecraft:light[level=14]
setblock 27 156 576 minecraft:light[level=14]
setblock 27 156 584 minecraft:light[level=14]
setblock 27 156 592 minecraft:light[level=14]
setblock 33 156 598 minecraft:black_concrete
setblock 35 156 560 minecraft:light[level=14]
setblock 35 156 568 minecraft:light[level=14]
setblock 35 156 576 minecraft:light[level=14]
setblock 35 156 584 minecraft:light[level=14]
setblock 35 156 592 minecraft:light[level=14]
setblock 37 156 558 minecraft:black_concrete
setblock 41 156 564 minecraft:black_concrete
setblock 41 156 574 minecraft:black_concrete
setblock 41 156 584 minecraft:black_concrete
setblock 41 156 594 minecraft:black_concrete
fill 0 157 563 0 157 566 minecraft:sea_lantern
fill 0 157 573 0 157 576 minecraft:sea_lantern
fill 0 157 583 0 157 586 minecraft:sea_lantern
fill 0 157 593 0 157 596 minecraft:sea_lantern
fill 3 157 557 6 157 557 minecraft:sea_lantern
fill 4 157 599 7 157 599 minecraft:sea_lantern
fill 13 157 557 16 157 557 minecraft:sea_lantern
fill 14 157 599 17 157 599 minecraft:sea_lantern
fill 23 157 557 26 157 557 minecraft:sea_lantern
fill 24 157 599 27 157 599 minecraft:sea_lantern
fill 33 157 557 36 157 557 minecraft:sea_lantern
fill 34 157 599 37 157 599 minecraft:sea_lantern
fill 42 157 558 42 157 561 minecraft:sea_lantern
fill 42 157 568 42 157 571 minecraft:sea_lantern
fill 42 157 578 42 157 581 minecraft:sea_lantern
fill 42 157 588 42 157 591 minecraft:sea_lantern
setblock 42 157 598 minecraft:sea_lantern
fill 0 158 563 0 165 566 minecraft:cyan_concrete
fill 0 158 573 0 165 576 minecraft:cyan_concrete
fill 0 158 583 0 165 586 minecraft:cyan_concrete
fill 0 158 593 0 165 596 minecraft:cyan_concrete
fill 3 158 557 6 165 557 minecraft:cyan_concrete
fill 4 158 599 7 165 599 minecraft:cyan_concrete
fill 13 158 557 16 165 557 minecraft:cyan_concrete
fill 14 158 599 17 165 599 minecraft:cyan_concrete
fill 23 158 557 26 165 557 minecraft:cyan_concrete
fill 24 158 599 27 165 599 minecraft:cyan_concrete
fill 33 158 557 36 165 557 minecraft:cyan_concrete
fill 34 158 599 37 165 599 minecraft:cyan_concrete
fill 42 158 558 42 165 561 minecraft:cyan_concrete
fill 42 158 568 42 165 571 minecraft:cyan_concrete
fill 42 158 578 42 165 581 minecraft:cyan_concrete
fill 42 158 588 42 165 591 minecraft:cyan_concrete
fill 42 158 598 42 165 598 minecraft:cyan_concrete
setblock 1 162 560 minecraft:black_concrete
fill 1 162 562 1 162 565 minecraft:black_concrete
setblock 1 162 570 minecraft:black_concrete
fill 1 162 572 1 162 575 minecraft:black_concrete
setblock 1 162 580 minecraft:black_concrete
fill 1 162 582 1 162 585 minecraft:black_concrete
setblock 1 162 590 minecraft:black_concrete
fill 1 162 592 1 162 595 minecraft:black_concrete
fill 2 162 558 5 162 558 minecraft:black_concrete
fill 2 162 564 3 163 564 minecraft:gray_concrete
setblock 3 162 598 minecraft:black_concrete
fill 5 162 598 8 162 598 minecraft:black_concrete
setblock 7 162 558 minecraft:black_concrete
fill 12 162 558 15 162 558 minecraft:black_concrete
setblock 13 162 598 minecraft:black_concrete
fill 15 162 598 18 162 598 minecraft:black_concrete
setblock 17 162 558 minecraft:black_concrete
fill 22 162 558 25 162 558 minecraft:black_concrete
setblock 23 162 598 minecraft:black_concrete
fill 25 162 598 28 162 598 minecraft:black_concrete
setblock 27 162 558 minecraft:black_concrete
fill 32 162 558 35 162 558 minecraft:black_concrete
setblock 33 162 598 minecraft:black_concrete
fill 35 162 598 38 162 598 minecraft:black_concrete
setblock 37 162 558 minecraft:black_concrete
fill 41 162 559 41 162 562 minecraft:black_concrete
setblock 41 162 564 minecraft:black_concrete
fill 41 162 569 41 162 572 minecraft:black_concrete
setblock 41 162 574 minecraft:black_concrete
fill 41 162 579 41 162 582 minecraft:black_concrete
setblock 41 162 584 minecraft:black_concrete
fill 41 162 589 41 162 592 minecraft:black_concrete
setblock 41 162 594 minecraft:black_concrete
setblock 1 163 564 minecraft:gray_concrete
setblock 3 164 560 minecraft:light[level=14]
setblock 3 164 568 minecraft:light[level=14]
setblock 3 164 576 minecraft:light[level=14]
setblock 3 164 584 minecraft:light[level=14]
setblock 3 164 592 minecraft:light[level=14]
setblock 11 164 560 minecraft:light[level=14]
setblock 11 164 568 minecraft:light[level=14]
setblock 11 164 576 minecraft:light[level=14]
setblock 11 164 584 minecraft:light[level=14]
setblock 11 164 592 minecraft:light[level=14]
setblock 19 164 560 minecraft:light[level=14]
setblock 19 164 568 minecraft:light[level=14]
setblock 19 164 576 minecraft:light[level=14]
setblock 19 164 584 minecraft:light[level=14]
setblock 19 164 592 minecraft:light[level=14]
setblock 27 164 560 minecraft:light[level=14]
setblock 27 164 568 minecraft:light[level=14]
setblock 27 164 576 minecraft:light[level=14]
setblock 27 164 584 minecraft:light[level=14]
setblock 27 164 592 minecraft:light[level=14]
setblock 35 164 560 minecraft:light[level=14]
setblock 35 164 568 minecraft:light[level=14]
setblock 35 164 576 minecraft:light[level=14]
setblock 35 164 584 minecraft:light[level=14]
setblock 35 164 592 minecraft:light[level=14]
fill 7 165 558 7 166 560 minecraft:gray_concrete
fill 0 166 563 0 166 566 minecraft:sea_lantern
fill 0 166 573 0 166 576 minecraft:sea_lantern
fill 0 166 583 0 166 586 minecraft:sea_lantern
fill 0 166 593 0 166 596 minecraft:sea_lantern
fill 3 166 557 6 166 557 minecraft:sea_lantern
fill 4 166 599 7 166 599 minecraft:sea_lantern
fill 13 166 557 16 166 557 minecraft:sea_lantern
fill 14 166 599 17 166 599 minecraft:sea_lantern
fill 23 166 557 26 166 557 minecraft:sea_lantern
fill 24 166 599 27 166 599 minecraft:sea_lantern
fill 33 166 557 36 166 557 minecraft:sea_lantern
fill 34 166 599 37 166 599 minecraft:sea_lantern
fill 42 166 558 42 166 561 minecraft:sea_lantern
fill 42 166 568 42 166 571 minecraft:sea_lantern
fill 42 166 578 42 166 581 minecraft:sea_lantern
fill 42 166 588 42 166 591 minecraft:sea_lantern
setblock 42 166 598 minecraft:sea_lantern
fill 0 167 563 0 183 566 minecraft:cyan_concrete
fill 0 167 573 0 183 576 minecraft:cyan_concrete
fill 0 167 583 0 183 586 minecraft:cyan_concrete
fill 0 167 593 0 183 596 minecraft:cyan_concrete
fill 3 167 557 6 183 557 minecraft:cyan_concrete
fill 4 167 599 7 183 599 minecraft:cyan_concrete
fill 13 167 557 16 183 557 minecraft:cyan_concrete
fill 14 167 599 17 183 599 minecraft:cyan_concrete
fill 23 167 557 26 183 557 minecraft:cyan_concrete
fill 24 167 599 27 183 599 minecraft:cyan_concrete
fill 33 167 557 36 183 557 minecraft:cyan_concrete
fill 34 167 599 37 183 599 minecraft:cyan_concrete
fill 38 167 587 40 168 587 minecraft:gray_concrete
fill 42 167 558 42 183 561 minecraft:cyan_concrete
fill 42 167 568 42 183 571 minecraft:cyan_concrete
fill 42 167 578 42 183 581 minecraft:cyan_concrete
fill 42 167 588 42 183 591 minecraft:cyan_concrete
fill 42 167 598 42 183 598 minecraft:cyan_concrete
setblock 1 168 560 minecraft:black_concrete
setblock 1 168 570 minecraft:black_concrete
setblock 1 168 580 minecraft:black_concrete
setblock 1 168 590 minecraft:black_concrete
setblock 3 168 598 minecraft:black_concrete
setblock 7 168 558 minecraft:black_concrete
setblock 13 168 598 minecraft:black_concrete
setblock 17 168 558 minecraft:black_concrete
setblock 23 168 598 minecraft:black_concrete
setblock 27 168 558 minecraft:black_concrete
setblock 33 168 598 minecraft:black_concrete
setblock 37 168 558 minecraft:black_concrete
setblock 41 168 564 minecraft:black_concrete
setblock 41 168 574 minecraft:black_concrete
setblock 41 168 584 minecraft:black_concrete
setblock 41 168 594 minecraft:black_concrete
setblock 3 172 560 minecraft:light[level=14]
setblock 3 172 568 minecraft:light[level=14]
setblock 3 172 576 minecraft:light[level=14]
setblock 3 172 584 minecraft:light[level=14]
setblock 3 172 592 minecraft:light[level=14]
setblock 11 172 560 minecraft:light[level=14]
setblock 11 172 568 minecraft:light[level=14]
setblock 11 172 576 minecraft:light[level=14]
setblock 11 172 584 minecraft:light[level=14]
setblock 11 172 592 minecraft:light[level=14]
setblock 19 172 560 minecraft:light[level=14]
setblock 19 172 568 minecraft:light[level=14]
setblock 19 172 576 minecraft:light[level=14]
setblock 19 172 584 minecraft:light[level=14]
setblock 19 172 592 minecraft:light[level=14]
setblock 27 172 560 minecraft:light[level=14]
setblock 27 172 568 minecraft:light[level=14]
setblock 27 172 576 minecraft:light[level=14]
setblock 27 172 584 minecraft:light[level=14]
setblock 27 172 592 minecraft:light[level=14]
setblock 35 172 560 minecraft:light[level=14]
setblock 35 172 568 minecraft:light[level=14]
setblock 35 172 576 minecraft:light[level=14]
setblock 35 172 584 minecraft:light[level=14]
setblock 35 172 592 minecraft:light[level=14]
fill 16 175 575 18 175 577 minecraft:redstone_block
fill 24 175 571 26 175 573 minecraft:redstone_block
fill 24 175 579 26 175 581 minecraft:redstone_block
fill 14 176 568 15 176 584 minecraft:cyan_concrete
fill 16 176 568 30 176 569 minecraft:cyan_concrete
fill 16 176 570 23 176 574 minecraft:black_concrete
fill 16 176 578 23 176 582 minecraft:black_concrete
fill 16 176 583 30 176 584 minecraft:cyan_concrete
fill 19 176 575 20 176 577 minecraft:black_concrete
fill 24 176 570 28 176 570 minecraft:black_concrete
fill 24 176 574 28 176 578 minecraft:black_concrete
fill 24 176 582 28 176 582 minecraft:black_concrete
fill 27 176 571 28 176 573 minecraft:black_concrete
fill 27 176 579 28 176 581 minecraft:black_concrete
fill 29 176 570 30 176 582 minecraft:cyan_concrete
fill 1 177 558 13 177 598 minecraft:black_concrete
fill 14 177 558 41 177 567 minecraft:black_concrete
fill 14 177 568 14 177 570 minecraft:cyan_concrete
setblock 14 177 571 minecraft:sea_lantern
fill 14 177 572 14 177 574 minecraft:cyan_concrete
fill 14 177 575 15 177 575 minecraft:sea_lantern
fill 14 177 576 14 177 578 minecraft:cyan_concrete
setblock 14 177 579 minecraft:sea_lantern
fill 14 177 580 14 177 582 minecraft:cyan_concrete
setblock 14 177 583 minecraft:sea_lantern
fill 14 177 584 16 177 584 minecraft:cyan_concrete
fill 14 177 585 41 177 598 minecraft:black_concrete
fill 15 177 568 15 181 569 minecraft:cyan_concrete
setblock 15 177 570 minecraft:sea_lantern
fill 15 177 571 15 177 573 minecraft:cyan_concrete
fill 15 177 574 27 177 574 minecraft:sea_lantern
fill 15 177 576 15 177 578 minecraft:sea_lantern
fill 15 177 579 15 177 581 minecraft:cyan_concrete
setblock 15 177 582 minecraft:sea_lantern
fill 15 177 583 17 177 583 minecraft:cyan_concrete
setblock 16 177 568 minecraft:cyan_concrete
setblock 16 177 569 minecraft:sea_lantern
fill 16 177 570 22 177 573 minecraft:black_concrete
fill 16 177 575 18 177 577 minecraft:black_concrete
fill 16 177 578 27 177 578 minecraft:sea_lantern
fill 16 177 579 22 177 582 minecraft:black_concrete
setblock 17 177 568 minecraft:sea_lantern
fill 17 177 569 19 177 569 minecraft:cyan_concrete
setblock 17 177 584 minecraft:sea_lantern
fill 18 177 568 20 177 568 minecraft:cyan_concrete
setblock 18 177 583 minecraft:sea_lantern
fill 18 177 584 20 177 584 minecraft:cyan_concrete
fill 19 177 575 20 177 577 minecraft:sea_lantern
fill 19 177 583 21 177 583 minecraft:cyan_concrete
setblock 20 177 569 minecraft:sea_lantern
setblock 21 177 568 minecraft:sea_lantern
fill 21 177 569 23 177 569 minecraft:cyan_concrete
setblock 21 177 584 minecraft:sea_lantern
fill 22 177 568 24 177 568 minecraft:cyan_concrete
setblock 22 177 583 minecraft:sea_lantern
fill 22 177 584 24 177 584 minecraft:cyan_concrete
fill 23 177 570 23 177 573 minecraft:sea_lantern
fill 23 177 579 23 177 582 minecraft:sea_lantern
fill 23 177 583 25 177 583 minecraft:cyan_concrete
fill 24 177 569 24 177 570 minecraft:sea_lantern
fill 24 177 571 26 177 573 minecraft:black_concrete
fill 24 177 575 24 177 577 minecraft:sea_lantern
fill 24 177 579 26 177 581 minecraft:black_concrete
fill 24 177 582 27 177 582 minecraft:sea_lantern
setblock 25 177 568 minecraft:sea_lantern
fill 25 177 569 27 177 569 minecraft:cyan_concrete
fill 25 177 570 27 177 570 minecraft:sea_lantern
fill 25 177 575 28 177 577 minecraft:black_concrete
setblock 25 177 584 minecraft:sea_lantern
fill 26 177 568 28 177 568 minecraft:cyan_concrete
setblock 26 177 583 minecraft:sea_lantern
fill 26 177 584 28 177 584 minecraft:cyan_concrete
fill 27 177 571 27 177 573 minecraft:sea_lantern
fill 27 177 579 27 177 581 minecraft:sea_lantern
fill 27 177 583 29 177 583 minecraft:cyan_concrete
setblock 28 177 569 minecraft:sea_lantern
fill 28 177 570 28 177 574 minecraft:black_concrete
fill 28 177 578 28 177 582 minecraft:black_concrete
setblock 29 177 568 minecraft:sea_lantern
fill 29 177 569 29 177 571 minecraft:cyan_concrete
setblock 29 177 572 minecraft:sea_lantern
fill 29 177 573 29 177 575 minecraft:cyan_concrete
setblock 29 177 576 minecraft:sea_lantern
fill 29 177 577 29 177 579 minecraft:cyan_concrete
setblock 29 177 580 minecraft:sea_lantern
fill 29 177 581 30 177 582 minecraft:cyan_concrete
setblock 29 177 584 minecraft:sea_lantern
fill 30 177 568 30 177 570 minecraft:cyan_concrete
setblock 30 177 571 minecraft:sea_lantern
fill 30 177 572 30 177 574 minecraft:cyan_concrete
setblock 30 177 575 minecraft:sea_lantern
fill 30 177 576 30 177 578 minecraft:cyan_concrete
setblock 30 177 579 minecraft:sea_lantern
setblock 30 177 580 minecraft:cyan_concrete
setblock 30 177 583 minecraft:sea_lantern
setblock 30 177 584 minecraft:cyan_concrete
fill 31 177 568 41 177 584 minecraft:black_concrete
fill 8 178 576 10 192 576 minecraft:pink_concrete
fill 9 178 575 9 192 575 minecraft:pink_concrete
fill 9 178 577 9 192 577 minecraft:pink_concrete
fill 12 178 566 13 192 567 minecraft:light_blue_concrete
fill 12 178 585 13 192 586 minecraft:light_blue_concrete
fill 14 178 569 14 181 569 minecraft:cyan_concrete
fill 14 178 583 16 181 583 minecraft:cyan_concrete
fill 15 178 570 15 181 570 minecraft:cyan_concrete
fill 15 178 582 15 181 582 minecraft:cyan_concrete
fill 15 178 584 15 181 584 minecraft:cyan_concrete
fill 16 178 569 16 181 569 minecraft:cyan_concrete
fill 21 178 563 23 192 563 minecraft:pink_concrete
fill 21 178 589 23 192 589 minecraft:pink_concrete
fill 22 178 562 22 192 562 minecraft:pink_concrete
fill 22 178 564 22 192 564 minecraft:pink_concrete
fill 22 178 588 22 192 588 minecraft:pink_concrete
fill 22 178 590 22 192 590 minecraft:pink_concrete
fill 28 178 569 30 181 569 minecraft:cyan_concrete
fill 28 178 583 30 181 583 minecraft:cyan_concrete
fill 29 178 568 29 181 568 minecraft:cyan_concrete
fill 29 178 570 29 181 570 minecraft:cyan_concrete
fill 29 178 582 29 181 582 minecraft:cyan_concrete
fill 29 178 584 29 181 584 minecraft:cyan_concrete
fill 31 178 566 32 192 567 minecraft:light_blue_concrete
fill 31 178 585 32 192 586 minecraft:light_blue_concrete
fill 34 178 576 36 192 576 minecraft:pink_concrete
fill 35 178 575 35 192 575 minecraft:pink_concrete
fill 35 178 577 35 192 577 minecraft:pink_concrete
fill 16 179 575 17 180 577 minecraft:magenta_concrete
fill 17 179 573 17 180 574 minecraft:magenta_concrete
fill 17 179 578 17 180 579 minecraft:magenta_concrete
fill 18 179 572 18 180 573 minecraft:magenta_concrete
fill 18 179 579 18 180 580 minecraft:magenta_concrete
fill 19 179 571 19 180 572 minecraft:magenta_concrete
fill 19 179 580 19 180 581 minecraft:magenta_concrete
fill 20 179 571 25 180 571 minecraft:magenta_concrete
fill 20 179 581 25 180 581 minecraft:magenta_concrete
fill 21 179 570 23 180 570 minecraft:magenta_concrete
fill 21 179 582 23 180 582 minecraft:magenta_concrete
fill 25 179 572 26 180 572 minecraft:magenta_concrete
fill 25 179 580 26 180 580 minecraft:magenta_concrete
fill 26 179 573 27 180 573 minecraft:magenta_concrete
fill 26 179 579 27 180 579 minecraft:magenta_concrete
fill 27 179 574 27 180 578 minecraft:magenta_concrete
fill 28 179 575 28 180 577 minecraft:magenta_concrete
setblock 3 180 560 minecraft:light[level=14]
setblock 3 180 568 minecraft:light[level=14]
setblock 3 180 576 minecraft:light[level=14]
setblock 3 180 584 minecraft:light[level=14]
setblock 3 180 592 minecraft:light[level=14]
setblock 11 180 560 minecraft:light[level=14]
setblock 11 180 568 minecraft:light[level=14]
setblock 11 180 576 minecraft:light[level=14]
setblock 11 180 584 minecraft:light[level=14]
setblock 11 180 592 minecraft:light[level=14]
setblock 19 180 560 minecraft:light[level=14]
setblock 19 180 568 minecraft:light[level=14]
setblock 19 180 576 minecraft:light[level=14]
setblock 19 180 584 minecraft:light[level=14]
setblock 19 180 592 minecraft:light[level=14]
setblock 27 180 560 minecraft:light[level=14]
setblock 27 180 568 minecraft:light[level=14]
setblock 27 180 584 minecraft:light[level=14]
setblock 27 180 592 minecraft:light[level=14]
setblock 35 180 560 minecraft:light[level=14]
setblock 35 180 568 minecraft:light[level=14]
setblock 35 180 584 minecraft:light[level=14]
setblock 35 180 592 minecraft:light[level=14]
fill 1 181 559 1 228 559 minecraft:gray_concrete
fill 1 181 563 1 182 563 minecraft:black_concrete
fill 1 181 569 1 228 569 minecraft:gray_concrete
fill 1 181 576 1 182 576 minecraft:black_concrete
fill 1 181 579 1 228 579 minecraft:gray_concrete
fill 1 181 589 1 228 589 minecraft:gray_concrete
fill 2 181 598 2 228 598 minecraft:gray_concrete
setblock 4 181 565 minecraft:sea_lantern
setblock 4 181 571 minecraft:sea_lantern
setblock 4 181 577 minecraft:sea_lantern
setblock 4 181 583 minecraft:sea_lantern
setblock 4 181 589 minecraft:sea_lantern
setblock 4 181 595 minecraft:sea_lantern
fill 5 181 558 5 182 558 minecraft:black_concrete
fill 8 181 558 8 228 558 minecraft:gray_concrete
setblock 8 181 561 minecraft:sea_lantern
setblock 10 181 595 minecraft:sea_lantern
fill 12 181 598 12 228 598 minecraft:gray_concrete
setblock 14 181 561 minecraft:sea_lantern
fill 15 181 558 15 182 558 minecraft:black_concrete
setblock 16 181 595 minecraft:sea_lantern
fill 18 181 558 18 228 558 minecraft:gray_concrete
setblock 20 181 561 minecraft:sea_lantern
setblock 22 181 595 minecraft:sea_lantern
fill 22 181 598 22 228 598 minecraft:gray_concrete
setblock 26 181 561 minecraft:sea_lantern
fill 28 181 558 28 228 558 minecraft:gray_concrete
setblock 28 181 595 minecraft:sea_lantern
setblock 32 181 561 minecraft:sea_lantern
fill 32 181 598 32 228 598 minecraft:gray_concrete
setblock 34 181 595 minecraft:sea_lantern
fill 38 181 558 38 228 558 minecraft:gray_concrete
setblock 38 181 561 minecraft:sea_lantern
setblock 38 181 567 minecraft:sea_lantern
setblock 38 181 573 minecraft:sea_lantern
setblock 38 181 579 minecraft:sea_lantern
setblock 38 181 585 minecraft:sea_lantern
setblock 38 181 591 minecraft:sea_lantern
fill 40 181 561 40 182 561 minecraft:black_concrete
fill 40 181 578 40 182 578 minecraft:black_concrete
fill 41 181 565 41 228 565 minecraft:gray_concrete
fill 41 181 575 41 228 575 minecraft:gray_concrete
fill 41 181 585 41 228 585 minecraft:gray_concrete
fill 41 181 595 41 228 595 minecraft:gray_concrete
fill 1 182 558 4 182 558 minecraft:black_concrete
fill 1 182 560 4 182 562 minecraft:black_concrete
fill 1 182 564 4 182 568 minecraft:black_concrete
fill 1 182 570 4 182 575 minecraft:black_concrete
fill 1 182 577 4 182 578 minecraft:black_concrete
fill 1 182 580 4 182 588 minecraft:black_concrete
fill 1 182 590 1 182 598 minecraft:black_concrete
fill 2 182 559 41 182 559 minecraft:black_concrete
fill 2 182 563 4 182 563 minecraft:black_concrete
fill 2 182 569 4 182 569 minecraft:black_concrete
fill 2 182 576 4 182 576 minecraft:black_concrete
fill 2 182 579 4 182 579 minecraft:black_concrete
fill 2 182 589 4 182 597 minecraft:black_concrete
fill 3 182 598 11 182 598 minecraft:black_concrete
fill 5 182 560 39 182 561 minecraft:black_concrete
fill 5 182 595 40 182 597 minecraft:black_concrete
fill 6 182 558 7 182 558 minecraft:black_concrete
fill 9 182 558 14 182 558 minecraft:black_concrete
fill 13 182 598 21 182 598 minecraft:black_concrete
fill 16 182 558 17 182 558 minecraft:black_concrete
fill 19 182 558 27 182 558 minecraft:black_concrete
fill 23 182 598 31 182 598 minecraft:black_concrete
fill 29 182 558 37 182 558 minecraft:black_concrete
fill 33 182 598 41 182 598 minecraft:black_concrete
fill 38 182 562 39 182 594 minecraft:black_concrete
fill 39 182 558 41 182 558 minecraft:black_concrete
fill 40 182 560 41 182 560 minecraft:black_concrete
fill 40 182 562 40 182 577 minecraft:black_concrete
fill 40 182 579 40 182 594 minecraft:black_concrete
fill 41 182 561 41 182 564 minecraft:black_concrete
fill 41 182 566 41 182 574 minecraft:black_concrete
fill 41 182 576 41 182 584 minecraft:black_concrete
fill 41 182 586 41 182 594 minecraft:black_concrete
fill 41 182 596 41 182 597 minecraft:black_concrete
fill 4 183 561 4 183 595 minecraft:cyan_concrete
fill 5 183 561 38 183 561 minecraft:cyan_concrete
fill 5 183 595 38 183 595 minecraft:cyan_concrete
fill 14 183 575 15 184 577 minecraft:cyan_concrete
fill 15 183 572 15 184 574 minecraft:cyan_concrete
fill 15 183 578 15 184 580 minecraft:cyan_concrete
fill 16 183 571 16 184 572 minecraft:cyan_concrete
fill 16 183 580 16 184 581 minecraft:cyan_concrete
fill 17 183 570 17 184 571 minecraft:cyan_concrete
fill 17 183 581 17 184 582 minecraft:cyan_concrete
fill 18 183 569 18 184 570 minecraft:cyan_concrete
fill 18 183 582 18 184 583 minecraft:cyan_concrete
fill 19 183 569 26 184 569 minecraft:cyan_concrete
fill 19 183 583 26 184 583 minecraft:cyan_concrete
fill 21 183 568 23 184 568 minecraft:cyan_concrete
fill 21 183 584 23 184 584 minecraft:cyan_concrete
fill 26 183 570 27 184 570 minecraft:cyan_concrete
fill 26 183 582 27 184 582 minecraft:cyan_concrete
fill 27 183 571 28 184 571 minecraft:cyan_concrete
fill 27 183 581 28 184 581 minecraft:cyan_concrete
fill 28 183 572 29 184 572 minecraft:cyan_concrete
fill 28 183 580 29 184 580 minecraft:cyan_concrete
fill 29 183 573 29 184 579 minecraft:cyan_concrete
fill 30 183 575 30 184 577 minecraft:cyan_concrete
fill 38 183 562 38 183 594 minecraft:cyan_concrete
fill 0 184 563 0 184 566 minecraft:sea_lantern
fill 0 184 573 0 184 576 minecraft:sea_lantern
fill 0 184 583 0 184 586 minecraft:sea_lantern
fill 0 184 593 0 184 596 minecraft:sea_lantern
fill 3 184 557 6 184 557 minecraft:sea_lantern
fill 4 184 599 7 184 599 minecraft:sea_lantern
fill 13 184 557 16 184 557 minecraft:sea_lantern
fill 14 184 599 17 184 599 minecraft:sea_lantern
fill 23 184 557 26 184 557 minecraft:sea_lantern
fill 24 184 599 27 184 599 minecraft:sea_lantern
fill 33 184 557 36 184 557 minecraft:sea_lantern
fill 34 184 599 37 184 599 minecraft:sea_lantern
fill 42 184 558 42 184 561 minecraft:sea_lantern
fill 42 184 568 42 184 571 minecraft:sea_lantern
fill 42 184 578 42 184 581 minecraft:sea_lantern
fill 42 184 588 42 184 591 minecraft:sea_lantern
setblock 42 184 598 minecraft:sea_lantern
fill 0 185 563 0 192 566 minecraft:cyan_concrete
fill 0 185 573 0 192 576 minecraft:cyan_concrete
fill 0 185 583 0 192 586 minecraft:cyan_concrete
fill 0 185 593 0 192 596 minecraft:cyan_concrete
fill 3 185 557 6 192 557 minecraft:cyan_concrete
fill 4 185 599 7 192 599 minecraft:cyan_concrete
fill 13 185 557 16 192 557 minecraft:cyan_concrete
fill 14 185 599 17 192 599 minecraft:cyan_concrete
fill 23 185 557 26 192 557 minecraft:cyan_concrete
fill 24 185 599 27 192 599 minecraft:cyan_concrete
fill 33 185 557 36 192 557 minecraft:cyan_concrete
fill 34 185 599 37 192 599 minecraft:cyan_concrete
fill 42 185 558 42 192 561 minecraft:cyan_concrete
fill 42 185 568 42 192 571 minecraft:cyan_concrete
fill 42 185 578 42 192 581 minecraft:cyan_concrete
fill 42 185 588 42 192 591 minecraft:cyan_concrete
fill 42 185 598 42 192 598 minecraft:cyan_concrete
setblock 1 186 560 minecraft:black_concrete
setblock 1 186 570 minecraft:black_concrete
setblock 1 186 580 minecraft:black_concrete
setblock 1 186 590 minecraft:black_concrete
setblock 3 186 598 minecraft:black_concrete
setblock 7 186 558 minecraft:black_concrete
setblock 13 186 598 minecraft:black_concrete
setblock 17 186 558 minecraft:black_concrete
setblock 23 186 598 minecraft:black_concrete
setblock 27 186 558 minecraft:black_concrete
setblock 33 186 598 minecraft:black_concrete
setblock 37 186 558 minecraft:black_concrete
setblock 41 186 564 minecraft:black_concrete
setblock 41 186 574 minecraft:black_concrete
setblock 41 186 584 minecraft:black_concrete
setblock 41 186 594 minecraft:black_concrete
fill 1 187 563 3 188 563 minecraft:gray_concrete
fill 12 187 575 13 188 577 minecraft:lime_concrete
fill 13 187 572 13 188 574 minecraft:lime_concrete
fill 13 187 578 13 188 580 minecraft:lime_concrete
fill 14 187 570 14 188 572 minecraft:lime_concrete
fill 14 187 580 14 188 582 minecraft:lime_concrete
fill 15 187 569 15 188 570 minecraft:lime_concrete
fill 15 187 582 15 188 583 minecraft:lime_concrete
fill 16 187 568 16 188 569 minecraft:lime_concrete
fill 16 187 583 16 188 584 minecraft:lime_concrete
fill 17 187 568 18 188 568 minecraft:lime_concrete
fill 17 187 584 18 188 584 minecraft:lime_concrete
fill 18 187 567 26 188 567 minecraft:lime_concrete
fill 18 187 585 26 188 585 minecraft:lime_concrete
fill 21 187 566 23 188 566 minecraft:lime_concrete
fill 21 187 586 23 188 586 minecraft:lime_concrete
fill 26 187 568 28 188 568 minecraft:lime_concrete
fill 26 187 584 28 188 584 minecraft:lime_concrete
fill 28 187 569 29 188 569 minecraft:lime_concrete
fill 28 187 583 29 188 583 minecraft:lime_concrete
fill 29 187 570 30 188 570 minecraft:lime_concrete
fill 29 187 582 30 188 582 minecraft:lime_concrete
fill 30 187 571 30 188 572 minecraft:lime_concrete
fill 30 187 580 30 188 581 minecraft:lime_concrete
fill 31 187 572 31 188 580 minecraft:lime_concrete
fill 32 187 575 32 188 577 minecraft:lime_concrete
setblock 3 188 560 minecraft:light[level=14]
setblock 3 188 568 minecraft:light[level=14]
setblock 3 188 576 minecraft:light[level=14]
setblock 3 188 584 minecraft:light[level=14]
setblock 3 188 592 minecraft:light[level=14]
setblock 11 188 560 minecraft:light[level=14]
setblock 11 188 568 minecraft:light[level=14]
setblock 11 188 576 minecraft:light[level=14]
setblock 11 188 584 minecraft:light[level=14]
setblock 11 188 592 minecraft:light[level=14]
setblock 19 188 560 minecraft:light[level=14]
setblock 19 188 568 minecraft:light[level=14]
setblock 19 188 576 minecraft:light[level=14]
setblock 19 188 584 minecraft:light[level=14]
setblock 19 188 592 minecraft:light[level=14]
setblock 27 188 560 minecraft:light[level=14]
setblock 27 188 576 minecraft:light[level=14]
setblock 27 188 592 minecraft:light[level=14]
setblock 35 188 560 minecraft:light[level=14]
setblock 35 188 568 minecraft:light[level=14]
setblock 35 188 584 minecraft:light[level=14]
setblock 35 188 592 minecraft:light[level=14]
fill 1 189 562 1 189 565 minecraft:black_concrete
fill 1 189 572 1 189 575 minecraft:black_concrete
fill 1 189 582 1 189 585 minecraft:black_concrete
fill 1 189 592 1 189 595 minecraft:black_concrete
fill 2 189 558 5 189 558 minecraft:black_concrete
fill 5 189 598 8 189 598 minecraft:black_concrete
fill 12 189 558 15 189 558 minecraft:black_concrete
fill 15 189 598 18 189 598 minecraft:black_concrete
fill 22 189 558 25 189 558 minecraft:black_concrete
fill 25 189 598 28 189 598 minecraft:black_concrete
fill 32 189 558 35 189 558 minecraft:black_concrete
fill 35 189 598 38 189 598 minecraft:black_concrete
fill 41 189 559 41 189 562 minecraft:black_concrete
fill 41 189 569 41 189 572 minecraft:black_concrete
fill 41 189 579 41 189 582 minecraft:black_concrete
fill 41 189 589 41 189 592 minecraft:black_concrete
setblock 1 192 560 minecraft:black_concrete
setblock 1 192 570 minecraft:black_concrete
setblock 1 192 580 minecraft:black_concrete
setblock 1 192 590 minecraft:black_concrete
setblock 3 192 598 minecraft:black_concrete
setblock 7 192 558 minecraft:black_concrete
setblock 13 192 598 minecraft:black_concrete
setblock 17 192 558 minecraft:black_concrete
setblock 23 192 598 minecraft:black_concrete
setblock 27 192 558 minecraft:black_concrete
setblock 33 192 598 minecraft:black_concrete
setblock 37 192 558 minecraft:black_concrete
setblock 41 192 564 minecraft:black_concrete
setblock 41 192 574 minecraft:black_concrete
setblock 41 192 584 minecraft:black_concrete
setblock 41 192 594 minecraft:black_concrete
fill 0 193 563 0 193 566 minecraft:sea_lantern
fill 0 193 573 0 193 576 minecraft:sea_lantern
fill 0 193 583 0 193 586 minecraft:sea_lantern
fill 0 193 593 0 193 596 minecraft:sea_lantern
fill 3 193 557 6 193 557 minecraft:sea_lantern
fill 4 193 599 7 193 599 minecraft:sea_lantern
fill 8 193 576 10 193 576 minecraft:glowstone
setblock 9 193 575 minecraft:glowstone
setblock 9 193 577 minecraft:glowstone
fill 12 193 566 13 193 567 minecraft:glowstone
fill 12 193 585 13 193 586 minecraft:glowstone
fill 13 193 557 16 193 557 minecraft:sea_lantern
setblock 13 193 568 minecraft:glowstone
setblock 13 193 584 minecraft:glowstone
setblock 14 193 567 minecraft:glowstone
setblock 14 193 585 minecraft:glowstone
fill 14 193 599 17 193 599 minecraft:sea_lantern
fill 21 193 563 23 193 563 minecraft:glowstone
fill 21 193 589 23 193 589 minecraft:glowstone
setblock 22 193 562 minecraft:glowstone
setblock 22 193 564 minecraft:glowstone
setblock 22 193 588 minecraft:glowstone
setblock 22 193 590 minecraft:glowstone
fill 23 193 557 26 193 557 minecraft:sea_lantern
fill 24 193 599 27 193 599 minecraft:sea_lantern
fill 30 193 567 32 193 567 minecraft:glowstone
fill 30 193 585 32 193 585 minecraft:glowstone
fill 31 193 566 32 193 566 minecraft:glowstone
setblock 31 193 568 minecraft:glowstone
setblock 31 193 584 minecraft:glowstone
fill 31 193 586 32 193 586 minecraft:glowstone
fill 33 193 557 36 193 557 minecraft:sea_lantern
fill 34 193 576 36 193 576 minecraft:glowstone
fill 34 193 599 37 193 599 minecraft:sea_lantern
setblock 35 193 575 minecraft:glowstone
setblock 35 193 577 minecraft:glowstone
fill 42 193 558 42 193 561 minecraft:sea_lantern
fill 42 193 568 42 193 571 minecraft:sea_lantern
fill 42 193 578 42 193 581 minecraft:sea_lantern
fill 42 193 588 42 193 591 minecraft:sea_lantern
setblock 42 193 598 minecraft:sea_lantern
fill 0 194 563 0 201 566 minecraft:cyan_concrete
fill 0 194 573 0 201 576 minecraft:cyan_concrete
fill 0 194 583 0 201 586 minecraft:cyan_concrete
fill 0 194 593 0 201 596 minecraft:cyan_concrete
fill 3 194 557 6 201 557 minecraft:cyan_concrete
fill 4 194 599 7 201 599 minecraft:cyan_concrete
fill 13 194 557 16 201 557 minecraft:cyan_concrete
fill 14 194 599 17 201 599 minecraft:cyan_concrete
fill 23 194 557 26 201 557 minecraft:cyan_concrete
fill 24 194 599 27 201 599 minecraft:cyan_concrete
fill 33 194 557 36 201 557 minecraft:cyan_concrete
fill 34 194 599 37 201 599 minecraft:cyan_concrete
fill 42 194 558 42 201 561 minecraft:cyan_concrete
fill 42 194 568 42 201 571 minecraft:cyan_concrete
fill 42 194 578 42 201 581 minecraft:cyan_concrete
fill 42 194 588 42 201 591 minecraft:cyan_concrete
fill 42 194 598 42 201 598 minecraft:cyan_concrete
setblock 3 196 560 minecraft:light[level=14]
setblock 3 196 568 minecraft:light[level=14]
setblock 3 196 576 minecraft:light[level=14]
setblock 3 196 584 minecraft:light[level=14]
setblock 3 196 592 minecraft:light[level=14]
setblock 11 196 560 minecraft:light[level=14]
setblock 11 196 568 minecraft:light[level=14]
setblock 11 196 576 minecraft:light[level=14]
setblock 11 196 584 minecraft:light[level=14]
setblock 11 196 592 minecraft:light[level=14]
setblock 19 196 560 minecraft:light[level=14]
setblock 19 196 568 minecraft:light[level=14]
setblock 19 196 576 minecraft:light[level=14]
setblock 19 196 584 minecraft:light[level=14]
setblock 19 196 592 minecraft:light[level=14]
setblock 27 196 560 minecraft:light[level=14]
setblock 27 196 568 minecraft:light[level=14]
setblock 27 196 576 minecraft:light[level=14]
setblock 27 196 584 minecraft:light[level=14]
setblock 27 196 592 minecraft:light[level=14]
setblock 35 196 560 minecraft:light[level=14]
setblock 35 196 568 minecraft:light[level=14]
setblock 35 196 576 minecraft:light[level=14]
setblock 35 196 584 minecraft:light[level=14]
setblock 35 196 592 minecraft:light[level=14]
setblock 1 198 560 minecraft:black_concrete
fill 1 198 562 1 198 565 minecraft:black_concrete
setblock 1 198 570 minecraft:black_concrete
fill 1 198 572 1 198 575 minecraft:black_concrete
setblock 1 198 580 minecraft:black_concrete
fill 1 198 582 1 198 585 minecraft:black_concrete
setblock 1 198 590 minecraft:black_concrete
fill 1 198 592 1 198 595 minecraft:black_concrete
fill 2 198 558 5 198 558 minecraft:black_concrete
setblock 3 198 598 minecraft:black_concrete
fill 5 198 598 8 198 598 minecraft:black_concrete
setblock 7 198 558 minecraft:black_concrete
fill 12 198 558 15 198 558 minecraft:black_concrete
setblock 13 198 598 minecraft:black_concrete
fill 15 198 598 18 198 598 minecraft:black_concrete
setblock 17 198 558 minecraft:black_concrete
fill 22 198 558 25 198 558 minecraft:black_concrete
setblock 23 198 598 minecraft:black_concrete
fill 25 198 598 28 198 598 minecraft:black_concrete
setblock 27 198 558 minecraft:black_concrete
fill 32 198 558 35 198 558 minecraft:black_concrete
setblock 33 198 598 minecraft:black_concrete
fill 35 198 598 38 198 598 minecraft:black_concrete
setblock 37 198 558 minecraft:black_concrete
fill 41 198 559 41 198 562 minecraft:black_concrete
setblock 41 198 564 minecraft:black_concrete
fill 41 198 569 41 198 572 minecraft:black_concrete
setblock 41 198 574 minecraft:black_concrete
fill 41 198 579 41 198 582 minecraft:black_concrete
setblock 41 198 584 minecraft:black_concrete
fill 41 198 589 41 198 592 minecraft:black_concrete
setblock 41 198 594 minecraft:black_concrete
fill 0 202 563 0 202 566 minecraft:sea_lantern
fill 0 202 573 0 202 576 minecraft:sea_lantern
fill 0 202 583 0 202 586 minecraft:sea_lantern
fill 0 202 593 0 202 596 minecraft:sea_lantern
fill 3 202 557 6 202 557 minecraft:sea_lantern
fill 4 202 599 7 202 599 minecraft:sea_lantern
fill 13 202 557 16 202 557 minecraft:sea_lantern
fill 14 202 599 17 202 599 minecraft:sea_lantern
fill 23 202 557 26 202 557 minecraft:sea_lantern
fill 24 202 599 27 202 599 minecraft:sea_lantern
fill 33 202 557 36 202 557 minecraft:sea_lantern
fill 34 202 599 37 202 599 minecraft:sea_lantern
fill 42 202 558 42 202 561 minecraft:sea_lantern
fill 42 202 568 42 202 571 minecraft:sea_lantern
fill 42 202 578 42 202 581 minecraft:sea_lantern
fill 42 202 588 42 202 591 minecraft:sea_lantern
setblock 42 202 598 minecraft:sea_lantern
fill 0 203 563 0 209 566 minecraft:cyan_concrete
fill 0 203 573 0 210 576 minecraft:cyan_concrete
fill 0 203 583 0 208 586 minecraft:cyan_concrete
fill 0 203 593 0 210 596 minecraft:cyan_concrete
fill 3 203 557 6 210 557 minecraft:cyan_concrete
fill 4 203 599 7 208 599 minecraft:cyan_concrete
fill 13 203 557 16 207 557 minecraft:cyan_concrete
fill 14 203 599 17 207 599 minecraft:cyan_concrete
fill 23 203 557 26 208 557 minecraft:cyan_concrete
fill 24 203 599 27 209 599 minecraft:cyan_concrete
fill 33 203 557 36 209 557 minecraft:cyan_concrete
fill 34 203 599 37 207 599 minecraft:cyan_concrete
fill 42 203 558 42 207 561 minecraft:cyan_concrete
fill 42 203 568 42 210 571 minecraft:cyan_concrete
fill 42 203 578 42 207 581 minecraft:cyan_concrete
fill 42 203 588 42 207 591 minecraft:cyan_concrete
fill 42 203 598 42 210 598 minecraft:cyan_concrete
setblock 1 204 560 minecraft:black_concrete
setblock 1 204 570 minecraft:black_concrete
setblock 1 204 580 minecraft:black_concrete
setblock 1 204 590 minecraft:black_concrete
setblock 3 204 560 minecraft:light[level=14]
setblock 3 204 568 minecraft:light[level=14]
setblock 3 204 576 minecraft:light[level=14]
setblock 3 204 584 minecraft:light[level=14]
setblock 3 204 592 minecraft:light[level=14]
setblock 3 204 598 minecraft:black_concrete
setblock 7 204 558 minecraft:black_concrete
setblock 11 204 560 minecraft:light[level=14]
setblock 11 204 568 minecraft:light[level=14]
setblock 11 204 576 minecraft:light[level=14]
setblock 11 204 584 minecraft:light[level=14]
setblock 11 204 592 minecraft:light[level=14]
setblock 13 204 598 minecraft:black_concrete
setblock 17 204 558 minecraft:black_concrete
setblock 19 204 560 minecraft:light[level=14]
setblock 19 204 568 minecraft:light[level=14]
setblock 19 204 576 minecraft:light[level=14]
setblock 19 204 584 minecraft:light[level=14]
setblock 19 204 592 minecraft:light[level=14]
setblock 23 204 598 minecraft:black_concrete
setblock 27 204 558 minecraft:black_concrete
setblock 27 204 560 minecraft:light[level=14]
setblock 27 204 568 minecraft:light[level=14]
setblock 27 204 576 minecraft:light[level=14]
setblock 27 204 584 minecraft:light[level=14]
setblock 27 204 592 minecraft:light[level=14]
setblock 33 204 598 minecraft:black_concrete
setblock 35 204 560 minecraft:light[level=14]
setblock 35 204 568 minecraft:light[level=14]
setblock 35 204 576 minecraft:light[level=14]
setblock 35 204 584 minecraft:light[level=14]
setblock 35 204 592 minecraft:light[level=14]
setblock 37 204 558 minecraft:black_concrete
setblock 41 204 564 minecraft:black_concrete
setblock 41 204 574 minecraft:black_concrete
setblock 41 204 584 minecraft:black_concrete
setblock 41 204 594 minecraft:black_concrete
fill 1 207 562 1 207 565 minecraft:black_concrete
fill 1 207 572 1 207 575 minecraft:black_concrete
fill 1 207 582 1 207 585 minecraft:black_concrete
fill 1 207 592 1 207 595 minecraft:black_concrete
fill 2 207 558 5 207 558 minecraft:black_concrete
fill 5 207 598 8 207 598 minecraft:black_concrete
fill 12 207 558 15 207 558 minecraft:black_concrete
fill 15 207 598 18 207 598 minecraft:black_concrete
fill 22 207 558 25 207 558 minecraft:black_concrete
fill 25 207 598 28 207 598 minecraft:black_concrete
fill 32 207 558 35 207 558 minecraft:black_concrete
fill 35 207 598 38 207 598 minecraft:black_concrete
fill 41 207 559 41 207 562 minecraft:black_concrete
fill 41 207 569 41 207 572 minecraft:black_concrete
fill 41 207 579 41 207 582 minecraft:black_concrete
fill 41 207 589 41 207 592 minecraft:black_concrete
fill 0 208 567 0 211 567 minecraft:cyan_concrete
setblock 0 208 568 minecraft:black_concrete
fill 0 208 569 0 211 569 minecraft:cyan_concrete
fill 0 208 570 0 210 570 minecraft:black_concrete
fill 0 208 571 0 211 571 minecraft:cyan_concrete
setblock 0 208 587 minecraft:black_concrete
fill 0 208 588 0 211 588 minecraft:cyan_concrete
fill 9 208 599 9 211 599 minecraft:cyan_concrete
setblock 10 208 599 minecraft:black_concrete
fill 11 208 557 12 208 557 minecraft:black_concrete
setblock 13 208 557 minecraft:cyan_concrete
setblock 14 208 557 minecraft:black_concrete
fill 14 208 599 15 210 599 minecraft:cyan_concrete
fill 15 208 557 16 209 557 minecraft:cyan_concrete
fill 16 208 599 17 208 599 minecraft:black_concrete
fill 18 208 557 19 211 557 minecraft:cyan_concrete
setblock 20 208 557 minecraft:black_concrete
fill 21 208 557 21 212 557 minecraft:cyan_concrete
fill 34 208 599 34 210 599 minecraft:cyan_concrete
setblock 35 208 599 minecraft:black_concrete
fill 36 208 599 37 210 599 minecraft:cyan_concrete
fill 41 208 599 41 210 599 minecraft:black_concrete
setblock 42 208 558 minecraft:black_concrete
fill 42 208 559 42 210 559 minecraft:cyan_concrete
setblock 42 208 560 minecraft:black_concrete
fill 42 208 561 42 210 561 minecraft:cyan_concrete
setblock 42 208 562 minecraft:black_concrete
fill 42 208 572 42 211 574 minecraft:cyan_concrete
setblock 42 208 575 minecraft:black_concrete
fill 42 208 576 42 208 578 minecraft:cyan_concrete
setblock 42 208 579 minecraft:black_concrete
fill 42 208 580 42 210 581 minecraft:cyan_concrete
setblock 42 208 587 minecraft:black_concrete
fill 42 208 588 42 208 589 minecraft:cyan_concrete
setblock 42 208 590 minecraft:black_concrete
setblock 42 208 591 minecraft:cyan_concrete
fill 0 209 557 0 209 558 minecraft:cyan_concrete
setblock 0 209 559 minecraft:black_concrete
fill 0 209 560 0 211 561 minecraft:cyan_concrete
setblock 0 209 568 minecraft:cyan_concrete
fill 0 209 583 0 209 585 minecraft:cyan_concrete
setblock 0 209 586 minecraft:black_concrete
fill 0 209 587 0 211 587 minecraft:cyan_concrete
setblock 0 209 591 minecraft:black_concrete
fill 0 209 592 0 211 592 minecraft:cyan_concrete
setblock 0 209 597 minecraft:black_concrete
setblock 0 209 599 minecraft:black_concrete
fill 1 209 599 5 210 599 minecraft:cyan_concrete
setblock 6 209 599 minecraft:black_concrete
fill 7 209 599 7 210 599 minecraft:cyan_concrete
fill 10 209 599 10 211 599 minecraft:cyan_concrete
fill 11 209 557 12 211 557 minecraft:cyan_concrete
setblock 13 209 557 minecraft:black_concrete
fill 14 209 557 14 210 557 minecraft:cyan_concrete
setblock 16 209 599 minecraft:black_concrete
fill 17 209 599 17 210 599 minecraft:cyan_concrete
fill 20 209 557 20 211 557 minecraft:cyan_concrete
setblock 23 209 557 minecraft:black_concrete
fill 24 209 557 25 210 557 minecraft:cyan_concrete
setblock 26 209 557 minecraft:black_concrete
fill 35 209 599 35 210 599 minecraft:cyan_concrete
fill 37 209 557 37 211 557 minecraft:cyan_concrete
setblock 38 209 557 minecraft:black_concrete
fill 39 209 557 41 211 557 minecraft:cyan_concrete
fill 42 209 558 42 210 558 minecraft:cyan_concrete
fill 42 209 560 42 210 560 minecraft:cyan_concrete
fill 42 209 562 42 211 562 minecraft:cyan_concrete
fill 42 209 575 42 211 577 minecraft:cyan_concrete
setblock 42 209 578 minecraft:black_concrete
setblock 42 209 579 minecraft:cyan_concrete
fill 42 209 587 42 212 587 minecraft:cyan_concrete
setblock 42 209 588 minecraft:black_concrete
fill 42 209 589 42 210 590 minecraft:cyan_concrete
fill 42 209 591 42 210 591 minecraft:black_concrete
fill 0 210 557 0 211 557 minecraft:cyan_concrete
setblock 0 210 558 minecraft:black_concrete
fill 0 210 559 0 211 559 minecraft:cyan_concrete
fill 0 210 562 0 210 563 minecraft:black_concrete
fill 0 210 564 0 210 566 minecraft:cyan_concrete
setblock 0 210 568 minecraft:black_concrete
setblock 0 210 577 minecraft:black_concrete
setblock 0 210 581 minecraft:black_concrete
fill 0 210 583 0 210 584 minecraft:cyan_concrete
setblock 0 210 585 minecraft:black_concrete
setblock 0 210 586 minecraft:cyan_concrete
fill 0 210 591 0 211 591 minecraft:cyan_concrete
fill 0 210 597 0 211 597 minecraft:cyan_concrete
fill 0 210 599 0 212 599 minecraft:cyan_concrete
setblock 1 210 560 minecraft:black_concrete
setblock 1 210 570 minecraft:black_concrete
setblock 1 210 580 minecraft:black_concrete
setblock 1 210 590 minecraft:black_concrete
setblock 3 210 598 minecraft:black_concrete
setblock 6 210 599 minecraft:cyan_concrete
setblock 7 210 558 minecraft:black_concrete
setblock 13 210 557 minecraft:cyan_concrete
setblock 13 210 598 minecraft:black_concrete
setblock 15 210 557 minecraft:cyan_concrete
setblock 16 210 557 minecraft:black_concrete
setblock 16 210 599 minecraft:cyan_concrete
setblock 17 210 558 minecraft:black_concrete
setblock 18 210 599 minecraft:black_concrete
fill 19 210 599 21 211 599 minecraft:cyan_concrete
setblock 23 210 557 minecraft:cyan_concrete
setblock 23 210 598 minecraft:black_concrete
fill 24 210 599 25 210 599 minecraft:cyan_concrete
setblock 26 210 557 minecraft:cyan_concrete
fill 26 210 599 27 210 599 minecraft:black_concrete
setblock 27 210 558 minecraft:black_concrete
fill 33 210 557 34 210 557 minecraft:cyan_concrete
setblock 33 210 598 minecraft:black_concrete
fill 35 210 557 36 210 557 minecraft:black_concrete
setblock 37 210 558 minecraft:black_concrete
fill 38 210 557 38 211 557 minecraft:cyan_concrete
setblock 41 210 564 minecraft:black_concrete
setblock 41 210 574 minecraft:black_concrete
setblock 41 210 584 minecraft:black_concrete
setblock 41 210 594 minecraft:black_concrete
setblock 42 210 557 minecraft:black_concrete
setblock 42 210 566 minecraft:black_concrete
setblock 42 210 578 minecraft:cyan_concrete
setblock 42 210 579 minecraft:black_concrete
setblock 42 210 588 minecraft:cyan_concrete
setblock 42 210 597 minecraft:black_concrete
setblock 0 211 558 minecraft:cyan_concrete
setblock 0 211 562 minecraft:cyan_concrete
fill 0 211 563 0 211 566 minecraft:sea_lantern
setblock 0 211 568 minecraft:cyan_concrete
setblock 0 211 570 minecraft:cyan_concrete
fill 0 211 573 0 211 576 minecraft:sea_lantern
setblock 0 211 577 minecraft:cyan_concrete
fill 0 211 581 0 212 581 minecraft:cyan_concrete
fill 0 211 583 0 211 586 minecraft:sea_lantern
fill 0 211 593 0 211 596 minecraft:sea_lantern
fill 1 211 599 3 211 599 minecraft:cyan_concrete
fill 3 211 557 6 211 557 minecraft:sea_lantern
fill 4 211 599 7 211 599 minecraft:sea_lantern
fill 13 211 557 16 211 557 minecraft:sea_lantern
fill 14 211 599 17 211 599 minecraft:sea_lantern
setblock 18 211 599 minecraft:cyan_concrete
fill 23 211 557 26 211 557 minecraft:sea_lantern
fill 24 211 599 27 211 599 minecraft:sea_lantern
fill 33 211 557 36 211 557 minecraft:sea_lantern
fill 34 211 599 37 211 599 minecraft:sea_lantern
fill 41 211 599 41 212 599 minecraft:cyan_concrete
fill 42 211 557 42 213 557 minecraft:cyan_concrete
fill 42 211 558 42 211 561 minecraft:sea_lantern
setblock 42 211 566 minecraft:cyan_concrete
fill 42 211 568 42 211 571 minecraft:sea_lantern
fill 42 211 578 42 211 581 minecraft:sea_lantern
fill 42 211 588 42 211 591 minecraft:sea_lantern
setblock 42 211 597 minecraft:cyan_concrete
setblock 42 211 598 minecraft:sea_lantern
fill 0 212 557 0 213 564 minecraft:black_concrete
setblock 0 212 565 minecraft:cyan_concrete
fill 0 212 566 0 212 577 minecraft:black_concrete
fill 0 212 579 0 307 579 minecraft:black_concrete
setblock 0 212 580 minecraft:cyan_concrete
fill 0 212 582 0 212 598 minecraft:black_concrete
fill 1 212 557 20 212 557 minecraft:black_concrete
fill 1 212 599 5 212 599 minecraft:black_concrete
setblock 3 212 560 minecraft:light[level=14]
setblock 3 212 568 minecraft:light[level=14]
setblock 3 212 576 minecraft:light[level=14]
setblock 3 212 584 minecraft:light[level=14]
setblock 3 212 592 minecraft:light[level=14]
setblock 6 212 599 minecraft:cyan_concrete
fill 7 212 599 24 212 599 minecraft:black_concrete
setblock 11 212 560 minecraft:light[level=14]
setblock 11 212 568 minecraft:light[level=14]
setblock 11 212 576 minecraft:light[level=14]
setblock 11 212 584 minecraft:light[level=14]
setblock 11 212 592 minecraft:light[level=14]
setblock 19 212 560 minecraft:light[level=14]
setblock 19 212 568 minecraft:light[level=14]
setblock 19 212 576 minecraft:light[level=14]
setblock 19 212 584 minecraft:light[level=14]
setblock 19 212 592 minecraft:light[level=14]
fill 22 212 557 24 212 557 minecraft:black_concrete
setblock 25 212 557 minecraft:cyan_concrete
setblock 25 212 599 minecraft:cyan_concrete
fill 26 212 557 40 212 557 minecraft:black_concrete
fill 26 212 599 31 212 599 minecraft:black_concrete
setblock 27 212 560 minecraft:light[level=14]
setblock 27 212 568 minecraft:light[level=14]
setblock 27 212 576 minecraft:light[level=14]
setblock 27 212 584 minecraft:light[level=14]
setblock 27 212 592 minecraft:light[level=14]
setblock 32 212 599 minecraft:cyan_concrete
fill 33 212 599 35 212 599 minecraft:black_concrete
setblock 35 212 560 minecraft:light[level=14]
setblock 35 212 568 minecraft:light[level=14]
setblock 35 212 576 minecraft:light[level=14]
setblock 35 212 584 minecraft:light[level=14]
setblock 35 212 592 minecraft:light[level=14]
setblock 36 212 599 minecraft:cyan_concrete
fill 37 212 599 38 219 599 minecraft:black_concrete
setblock 39 212 599 minecraft:cyan_concrete
fill 40 212 599 40 307 599 minecraft:black_concrete
setblock 41 212 557 minecraft:cyan_concrete
setblock 42 212 558 minecraft:cyan_concrete
fill 42 212 559 42 212 573 minecraft:black_concrete
fill 42 212 574 42 212 575 minecraft:cyan_concrete
setblock 42 212 576 minecraft:black_concrete
fill 42 212 577 42 212 580 minecraft:cyan_concrete
fill 42 212 581 42 212 586 minecraft:black_concrete
fill 42 212 588 42 219 590 minecraft:black_concrete
setblock 42 212 591 minecraft:cyan_concrete
fill 42 212 592 42 219 598 minecraft:black_concrete
fill 0 213 565 0 213 570 minecraft:black_concrete
setblock 0 213 571 minecraft:cyan_concrete
fill 0 213 572 0 219 574 minecraft:black_concrete
setblock 0 213 575 minecraft:cyan_concrete
fill 0 213 576 0 219 578 minecraft:black_concrete
fill 0 213 580 0 213 590 minecraft:black_concrete
setblock 0 213 591 minecraft:cyan_concrete
fill 0 213 592 0 213 595 minecraft:black_concrete
setblock 0 213 596 minecraft:cyan_concrete
fill 0 213 597 0 213 599 minecraft:black_concrete
fill 1 213 557 7 213 557 minecraft:black_concrete
setblock 1 213 599 minecraft:cyan_concrete
fill 2 213 599 14 219 599 minecraft:black_concrete
setblock 8 213 557 minecraft:cyan_concrete
fill 9 213 557 22 213 557 minecraft:black_concrete
fill 15 213 599 15 214 599 minecraft:cyan_concrete
fill 16 213 599 19 219 599 minecraft:black_concrete
setblock 20 213 599 minecraft:cyan_concrete
fill 21 213 599 30 219 599 minecraft:black_concrete
setblock 23 213 557 minecraft:cyan_concrete
fill 24 213 557 27 219 557 minecraft:black_concrete
setblock 28 213 557 minecraft:cyan_concrete
fill 29 213 557 39 219 557 minecraft:black_concrete
setblock 31 213 599 minecraft:cyan_concrete
fill 32 213 599 34 219 599 minecraft:black_concrete
setblock 35 213 599 minecraft:cyan_concrete
fill 36 213 599 36 219 599 minecraft:black_concrete
fill 39 213 599 39 307 599 minecraft:black_concrete
setblock 40 213 557 minecraft:cyan_concrete
fill 41 213 557 41 307 557 minecraft:black_concrete
fill 41 213 599 41 307 599 minecraft:black_concrete
fill 42 213 558 42 213 563 minecraft:black_concrete
fill 42 213 564 42 213 565 minecraft:cyan_concrete
fill 42 213 566 42 213 575 minecraft:black_concrete
setblock 42 213 576 minecraft:cyan_concrete
fill 42 213 577 42 213 580 minecraft:black_concrete
setblock 42 213 581 minecraft:cyan_concrete
fill 42 213 582 42 307 587 minecraft:black_concrete
fill 42 213 591 42 219 591 minecraft:black_concrete
fill 0 214 557 0 307 562 minecraft:black_concrete
setblock 0 214 563 minecraft:cyan_concrete
fill 0 214 564 0 219 568 minecraft:black_concrete
setblock 0 214 569 minecraft:cyan_concrete
fill 0 214 570 0 307 571 minecraft:black_concrete
fill 0 214 575 0 219 575 minecraft:black_concrete
fill 0 214 580 0 307 580 minecraft:black_concrete
setblock 0 214 581 minecraft:cyan_concrete
fill 0 214 582 0 219 587 minecraft:black_concrete
setblock 0 214 588 minecraft:cyan_concrete
fill 0 214 589 0 307 592 minecraft:black_concrete
setblock 0 214 593 minecraft:cyan_concrete
fill 0 214 594 0 219 598 minecraft:black_concrete
setblock 0 214 599 minecraft:cyan_concrete
fill 1 214 557 5 219 557 minecraft:black_concrete
fill 1 214 599 1 307 599 minecraft:black_concrete
fill 6 214 557 7 214 557 minecraft:cyan_concrete
fill 8 214 557 15 219 557 minecraft:black_concrete
setblock 16 214 557 minecraft:cyan_concrete
fill 17 214 557 23 219 557 minecraft:black_concrete
fill 20 214 599 20 307 599 minecraft:black_concrete
fill 28 214 557 28 307 557 minecraft:black_concrete
fill 31 214 599 31 307 599 minecraft:black_concrete
fill 35 214 599 35 219 599 minecraft:black_concrete
fill 40 214 557 40 307 557 minecraft:black_concrete
fill 42 214 557 42 219 559 minecraft:black_concrete
setblock 42 214 560 minecraft:cyan_concrete
fill 42 214 561 42 219 564 minecraft:black_concrete
setblock 42 214 565 minecraft:cyan_concrete
fill 42 214 566 42 219 568 minecraft:black_concrete
setblock 42 214 569 minecraft:cyan_concrete
fill 42 214 570 42 219 570 minecraft:black_concrete
setblock 42 214 571 minecraft:cyan_concrete
fill 42 214 572 42 307 572 minecraft:black_concrete
setblock 42 214 573 minecraft:cyan_concrete
fill 42 214 574 42 307 577 minecraft:black_concrete
setblock 42 214 578 minecraft:cyan_concrete
fill 42 214 579 42 219 581 minecraft:black_concrete
fill 0 215 563 0 219 563 minecraft:black_concrete
fill 0 215 569 0 307 569 minecraft:black_concrete
fill 0 215 581 0 307 581 minecraft:black_concrete
fill 0 215 588 0 307 588 minecraft:black_concrete
fill 0 215 593 0 219 593 minecraft:black_concrete
fill 0 215 599 0 307 599 minecraft:black_concrete
fill 6 215 557 7 219 557 minecraft:black_concrete
fill 15 215 599 15 219 599 minecraft:black_concrete
fill 16 215 557 16 219 557 minecraft:black_concrete
fill 42 215 560 42 219 560 minecraft:black_concrete
fill 42 215 565 42 307 565 minecraft:black_concrete
fill 42 215 569 42 219 569 minecraft:black_concrete
fill 42 215 571 42 219 571 minecraft:black_concrete
fill 42 215 573 42 307 573 minecraft:black_concrete
fill 42 215 578 42 219 578 minecraft:black_concrete
fill 42 215 599 42 307 599 minecraft:black_concrete
setblock 1 216 560 minecraft:black_concrete
fill 1 216 562 1 216 565 minecraft:black_concrete
setblock 1 216 570 minecraft:black_concrete
fill 1 216 572 1 216 575 minecraft:black_concrete
setblock 1 216 580 minecraft:black_concrete
fill 1 216 582 1 216 585 minecraft:black_concrete
setblock 1 216 590 minecraft:black_concrete
fill 1 216 592 1 216 595 minecraft:black_concrete
fill 2 216 558 5 216 558 minecraft:black_concrete
setblock 3 216 598 minecraft:black_concrete
fill 5 216 598 8 216 598 minecraft:black_concrete
setblock 7 216 558 minecraft:black_concrete
fill 12 216 558 15 216 558 minecraft:black_concrete
setblock 13 216 598 minecraft:black_concrete
fill 15 216 598 18 216 598 minecraft:black_concrete
setblock 17 216 558 minecraft:black_concrete
fill 22 216 558 25 216 558 minecraft:black_concrete
setblock 23 216 598 minecraft:black_concrete
fill 25 216 598 28 216 598 minecraft:black_concrete
setblock 27 216 558 minecraft:black_concrete
fill 32 216 558 35 216 558 minecraft:black_concrete
setblock 33 216 598 minecraft:black_concrete
fill 35 216 598 38 216 598 minecraft:black_concrete
setblock 37 216 558 minecraft:black_concrete
fill 41 216 559 41 216 562 minecraft:black_concrete
setblock 41 216 564 minecraft:black_concrete
fill 41 216 569 41 216 572 minecraft:black_concrete
setblock 41 216 574 minecraft:black_concrete
fill 41 216 579 41 216 582 minecraft:black_concrete
setblock 41 216 584 minecraft:black_concrete
fill 41 216 589 41 216 592 minecraft:black_concrete
setblock 41 216 594 minecraft:black_concrete
fill 38 219 566 40 220 566 minecraft:gray_concrete
fill 0 220 563 0 220 566 minecraft:sea_lantern
fill 0 220 567 0 307 568 minecraft:black_concrete
fill 0 220 572 0 307 572 minecraft:black_concrete
fill 0 220 573 0 220 576 minecraft:sea_lantern
fill 0 220 577 0 307 578 minecraft:black_concrete
fill 0 220 582 0 307 582 minecraft:black_concrete
fill 0 220 583 0 220 586 minecraft:sea_lantern
fill 0 220 587 0 307 587 minecraft:black_concrete
fill 0 220 593 0 220 596 minecraft:sea_lantern
fill 0 220 597 0 307 598 minecraft:black_concrete
fill 1 220 557 2 307 557 minecraft:black_concrete
fill 2 220 599 3 307 599 minecraft:black_concrete
fill 3 220 557 6 220 557 minecraft:sea_lantern
setblock 3 220 560 minecraft:light[level=14]
setblock 3 220 568 minecraft:light[level=14]
setblock 3 220 576 minecraft:light[level=14]
setblock 3 220 584 minecraft:light[level=14]
setblock 3 220 592 minecraft:light[level=14]
fill 4 220 599 7 220 599 minecraft:sea_lantern
fill 7 220 557 12 307 557 minecraft:black_concrete
fill 8 220 599 13 307 599 minecraft:black_concrete
setblock 11 220 560 minecraft:light[level=14]
setblock 11 220 568 minecraft:light[level=14]
setblock 11 220 576 minecraft:light[level=14]
setblock 11 220 584 minecraft:light[level=14]
setblock 11 220 592 minecraft:light[level=14]
fill 13 220 557 16 220 557 minecraft:sea_lantern
fill 14 220 599 17 220 599 minecraft:sea_lantern
fill 17 220 557 22 307 557 minecraft:black_concrete
fill 18 220 599 19 307 599 minecraft:black_concrete
setblock 19 220 560 minecraft:light[level=14]
setblock 19 220 568 minecraft:light[level=14]
setblock 19 220 576 minecraft:light[level=14]
setblock 19 220 584 minecraft:light[level=14]
setblock 19 220 592 minecraft:light[level=14]
fill 21 220 599 23 307 599 minecraft:black_concrete
fill 23 220 557 26 220 557 minecraft:sea_lantern
fill 24 220 599 27 220 599 minecraft:sea_lantern
fill 27 220 557 27 307 557 minecraft:black_concrete
setblock 27 220 560 minecraft:light[level=14]
setblock 27 220 568 minecraft:light[level=14]
setblock 27 220 576 minecraft:light[level=14]
setblock 27 220 584 minecraft:light[level=14]
setblock 27 220 592 minecraft:light[level=14]
fill 28 220 599 30 307 599 minecraft:black_concrete
fill 29 220 557 32 307 557 minecraft:black_concrete
fill 32 220 599 33 307 599 minecraft:black_concrete
fill 33 220 557 36 220 557 minecraft:sea_lantern
fill 34 220 599 37 220 599 minecraft:sea_lantern
setblock 35 220 560 minecraft:light[level=14]
setblock 35 220 568 minecraft:light[level=14]
setblock 35 220 576 minecraft:light[level=14]
setblock 35 220 584 minecraft:light[level=14]
setblock 35 220 592 minecraft:light[level=14]
fill 37 220 557 39 307 557 minecraft:black_concrete
fill 38 220 599 38 307 599 minecraft:black_concrete
fill 42 220 557 42 307 557 minecraft:black_concrete
fill 42 220 558 42 220 561 minecraft:sea_lantern
fill 42 220 562 42 307 564 minecraft:black_concrete
fill 42 220 566 42 307 567 minecraft:black_concrete
fill 42 220 568 42 220 571 minecraft:sea_lantern
fill 42 220 578 42 220 581 minecraft:sea_lantern
fill 42 220 588 42 220 591 minecraft:sea_lantern
fill 42 220 592 42 307 597 minecraft:black_concrete
setblock 42 220 598 minecraft:sea_lantern
fill 0 221 563 0 246 566 minecraft:black_concrete
fill 0 221 573 0 246 576 minecraft:black_concrete
fill 0 221 583 0 246 586 minecraft:black_concrete
fill 0 221 593 0 246 596 minecraft:black_concrete
fill 3 221 557 6 246 557 minecraft:black_concrete
fill 4 221 599 7 246 599 minecraft:black_concrete
fill 13 221 557 16 246 557 minecraft:black_concrete
fill 14 221 599 17 246 599 minecraft:black_concrete
fill 23 221 557 26 246 557 minecraft:black_concrete
fill 24 221 599 27 246 599 minecraft:black_concrete
fill 33 221 557 36 246 557 minecraft:black_concrete
fill 34 221 599 37 246 599 minecraft:black_concrete
fill 42 221 558 42 246 561 minecraft:black_concrete
fill 42 221 568 42 246 571 minecraft:black_concrete
fill 42 221 578 42 246 581 minecraft:black_concrete
fill 42 221 588 42 246 591 minecraft:black_concrete
fill 42 221 598 42 246 598 minecraft:black_concrete
setblock 1 222 560 minecraft:black_concrete
setblock 1 222 570 minecraft:black_concrete
setblock 1 222 580 minecraft:black_concrete
setblock 1 222 590 minecraft:black_concrete
setblock 3 222 598 minecraft:black_concrete
setblock 7 222 558 minecraft:black_concrete
setblock 13 222 598 minecraft:black_concrete
setblock 17 222 558 minecraft:black_concrete
setblock 23 222 598 minecraft:black_concrete
setblock 27 222 558 minecraft:black_concrete
setblock 33 222 598 minecraft:black_concrete
setblock 37 222 558 minecraft:black_concrete
setblock 41 222 564 minecraft:black_concrete
setblock 41 222 574 minecraft:black_concrete
setblock 41 222 584 minecraft:black_concrete
setblock 41 222 594 minecraft:black_concrete
fill 1 225 562 1 225 565 minecraft:black_concrete
fill 1 225 572 1 225 575 minecraft:black_concrete
fill 1 225 582 1 225 585 minecraft:black_concrete
fill 1 225 592 1 225 595 minecraft:black_concrete
fill 2 225 558 5 225 558 minecraft:black_concrete
fill 5 225 598 8 225 598 minecraft:black_concrete
fill 12 225 558 15 225 558 minecraft:black_concrete
fill 15 225 598 18 225 598 minecraft:black_concrete
fill 22 225 558 25 225 558 minecraft:black_concrete
fill 25 225 598 28 225 598 minecraft:black_concrete
fill 32 225 558 35 225 558 minecraft:black_concrete
fill 35 225 598 38 225 598 minecraft:black_concrete
fill 41 225 559 41 225 562 minecraft:black_concrete
fill 41 225 569 41 225 572 minecraft:black_concrete
fill 41 225 579 41 225 582 minecraft:black_concrete
fill 41 225 589 41 225 592 minecraft:black_concrete
setblock 1 228 560 minecraft:black_concrete
setblock 1 228 570 minecraft:black_concrete
setblock 1 228 580 minecraft:black_concrete
setblock 1 228 590 minecraft:black_concrete
setblock 3 228 560 minecraft:light[level=14]
setblock 3 228 568 minecraft:light[level=14]
setblock 3 228 576 minecraft:light[level=14]
setblock 3 228 584 minecraft:light[level=14]
setblock 3 228 592 minecraft:light[level=14]
setblock 3 228 598 minecraft:black_concrete
setblock 7 228 558 minecraft:black_concrete
setblock 11 228 560 minecraft:light[level=14]
setblock 11 228 568 minecraft:light[level=14]
setblock 11 228 576 minecraft:light[level=14]
setblock 11 228 584 minecraft:light[level=14]
setblock 11 228 592 minecraft:light[level=14]
setblock 13 228 598 minecraft:black_concrete
setblock 17 228 558 minecraft:black_concrete
setblock 19 228 560 minecraft:light[level=14]
setblock 19 228 568 minecraft:light[level=14]
setblock 19 228 576 minecraft:light[level=14]
setblock 19 228 584 minecraft:light[level=14]
setblock 19 228 592 minecraft:light[level=14]
setblock 23 228 598 minecraft:black_concrete
setblock 27 228 558 minecraft:black_concrete
setblock 27 228 560 minecraft:light[level=14]
setblock 27 228 568 minecraft:light[level=14]
setblock 27 228 576 minecraft:light[level=14]
setblock 27 228 584 minecraft:light[level=14]
setblock 27 228 592 minecraft:light[level=14]
setblock 33 228 598 minecraft:black_concrete
setblock 35 228 560 minecraft:light[level=14]
setblock 35 228 568 minecraft:light[level=14]
setblock 35 228 576 minecraft:light[level=14]
setblock 35 228 584 minecraft:light[level=14]
setblock 35 228 592 minecraft:light[level=14]
setblock 37 228 558 minecraft:black_concrete
setblock 41 228 564 minecraft:black_concrete
setblock 41 228 574 minecraft:black_concrete
setblock 41 228 584 minecraft:black_concrete
setblock 41 228 594 minecraft:black_concrete
fill 18 233 574 20 233 576 minecraft:redstone_block
fill 19 233 581 21 233 583 minecraft:redstone_block
fill 25 233 573 27 233 575 minecraft:redstone_block
fill 26 233 580 28 233 582 minecraft:redstone_block
fill 12 234 567 13 234 589 minecraft:magenta_concrete
fill 14 234 567 34 234 568 minecraft:magenta_concrete
fill 14 234 569 17 234 587 minecraft:black_concrete
fill 14 234 588 34 234 589 minecraft:magenta_concrete
fill 18 234 569 24 234 573 minecraft:black_concrete
fill 18 234 577 18 234 587 minecraft:black_concrete
fill 19 234 577 21 234 580 minecraft:black_concrete
fill 19 234 584 32 234 587 minecraft:black_concrete
fill 21 234 574 24 234 576 minecraft:black_concrete
fill 22 234 580 25 234 583 minecraft:black_concrete
fill 25 234 569 32 234 572 minecraft:black_concrete
fill 25 234 576 32 234 579 minecraft:black_concrete
fill 26 234 583 32 234 583 minecraft:black_concrete
fill 28 234 573 32 234 575 minecraft:black_concrete
fill 29 234 580 32 234 582 minecraft:black_concrete
fill 33 234 569 34 234 587 minecraft:magenta_concrete
fill 1 235 558 11 235 598 minecraft:black_concrete
fill 12 235 558 41 235 566 minecraft:black_concrete
fill 12 235 567 12 235 568 minecraft:magenta_concrete
setblock 12 235 569 minecraft:sea_lantern
fill 12 235 570 12 235 572 minecraft:magenta_concrete
setblock 12 235 573 minecraft:sea_lantern
fill 12 235 574 12 235 576 minecraft:magenta_concrete
setblock 12 235 577 minecraft:sea_lantern
fill 12 235 578 12 235 580 minecraft:magenta_concrete
setblock 12 235 581 minecraft:sea_lantern
fill 12 235 582 12 235 584 minecraft:magenta_concrete
setblock 12 235 585 minecraft:sea_lantern
fill 12 235 586 12 235 588 minecraft:magenta_concrete
setblock 12 235 589 minecraft:sea_lantern
fill 12 235 590 41 235 598 minecraft:black_concrete
fill 13 235 567 13 239 567 minecraft:magenta_concrete
setblock 13 235 568 minecraft:sea_lantern
fill 13 235 569 13 235 571 minecraft:magenta_concrete
setblock 13 235 572 minecraft:sea_lantern
fill 13 235 573 13 235 575 minecraft:magenta_concrete
setblock 13 235 576 minecraft:sea_lantern
fill 13 235 577 13 235 579 minecraft:magenta_concrete
setblock 13 235 580 minecraft:sea_lantern
fill 13 235 581 13 235 583 minecraft:magenta_concrete
setblock 13 235 584 minecraft:sea_lantern
fill 13 235 585 13 235 587 minecraft:magenta_concrete
setblock 13 235 588 minecraft:sea_lantern
fill 13 235 589 15 235 589 minecraft:magenta_concrete
setblock 14 235 567 minecraft:sea_lantern
fill 14 235 568 16 235 568 minecraft:magenta_concrete
fill 14 235 569 16 235 587 minecraft:black_concrete
fill 14 235 588 16 235 588 minecraft:magenta_concrete
fill 15 235 567 17 235 567 minecraft:magenta_concrete
setblock 16 235 589 minecraft:sea_lantern
setblock 17 235 568 minecraft:sea_lantern
fill 17 235 569 23 235 572 minecraft:black_concrete
fill 17 235 573 17 235 577 minecraft:sea_lantern
fill 17 235 578 17 235 587 minecraft:black_concrete
setblock 17 235 588 minecraft:sea_lantern
fill 17 235 589 19 235 589 minecraft:magenta_concrete
setblock 18 235 567 minecraft:sea_lantern
fill 18 235 568 20 235 568 minecraft:magenta_concrete
fill 18 235 573 21 235 573 minecraft:sea_lantern
fill 18 235 574 20 235 576 minecraft:black_concrete
fill 18 235 577 20 235 577 minecraft:sea_lantern
fill 18 235 578 20 235 579 minecraft:black_concrete
fill 18 235 580 18 235 584 minecraft:sea_lantern
fill 18 235 585 32 235 587 minecraft:black_concrete
fill 18 235 588 20 235 588 minecraft:magenta_concrete
fill 19 235 567 21 235 567 minecraft:magenta_concrete
fill 19 235 580 21 235 580 minecraft:sea_lantern
fill 19 235 581 21 235 583 minecraft:black_concrete
fill 19 235 584 22 235 584 minecraft:sea_lantern
setblock 20 235 589 minecraft:sea_lantern
setblock 21 235 568 minecraft:sea_lantern
fill 21 235 574 21 235 576 minecraft:sea_lantern
fill 21 235 577 21 235 579 minecraft:ochre_froglight
setblock 21 235 588 minecraft:sea_lantern
fill 21 235 589 23 235 589 minecraft:magenta_concrete
setblock 22 235 567 minecraft:sea_lantern
fill 22 235 568 24 235 568 minecraft:magenta_concrete
fill 22 235 573 23 235 575 minecraft:black_concrete
fill 22 235 576 24 235 576 minecraft:ochre_froglight
fill 22 235 580 24 235 580 minecraft:ochre_froglight
fill 22 235 581 22 235 583 minecraft:sea_lantern
fill 22 235 588 24 235 588 minecraft:magenta_concrete
fill 23 235 567 25 235 567 minecraft:magenta_concrete
fill 23 235 581 24 235 584 minecraft:black_concrete
fill 24 235 569 32 235 571 minecraft:black_concrete
fill 24 235 572 24 235 575 minecraft:sea_lantern
setblock 24 235 589 minecraft:sea_lantern
setblock 25 235 568 minecraft:sea_lantern
fill 25 235 572 28 235 572 minecraft:sea_lantern
fill 25 235 573 27 235 575 minecraft:black_concrete
fill 25 235 576 28 235 576 minecraft:sea_lantern
fill 25 235 577 25 235 579 minecraft:ochre_froglight
fill 25 235 580 25 235 583 minecraft:sea_lantern
fill 25 235 584 32 235 584 minecraft:black_concrete
setblock 25 235 588 minecraft:sea_lantern
fill 25 235 589 27 235 589 minecraft:magenta_concrete
setblock 26 235 567 minecraft:sea_lantern
fill 26 235 568 28 235 568 minecraft:magenta_concrete
fill 26 235 577 32 235 578 minecraft:black_concrete
fill 26 235 579 29 235 579 minecraft:sea_lantern
fill 26 235 580 28 235 582 minecraft:black_concrete
fill 26 235 583 29 235 583 minecraft:sea_lantern
fill 26 235 588 28 235 588 minecraft:magenta_concrete
fill 27 235 567 29 235 567 minecraft:magenta_concrete
fill 28 235 573 28 235 575 minecraft:sea_lantern
setblock 28 235 589 minecraft:sea_lantern
setblock 29 235 568 minecraft:sea_lantern
fill 29 235 572 32 235 576 minecraft:black_concrete
fill 29 235 580 29 235 582 minecraft:sea_lantern
setblock 29 235 588 minecraft:sea_lantern
fill 29 235 589 31 235 589 minecraft:magenta_concrete
setblock 30 235 567 minecraft:sea_lantern
fill 30 235 568 32 235 568 minecraft:magenta_concrete
fill 30 235 579 32 235 583 minecraft:black_concrete
fill 30 235 588 32 235 588 minecraft:magenta_concrete
fill 31 235 567 33 235 567 minecraft:magenta_concrete
setblock 32 235 589 minecraft:sea_lantern
setblock 33 235 568 minecraft:sea_lantern
fill 33 235 569 33 235 571 minecraft:magenta_concrete
setblock 33 235 572 minecraft:sea_lantern
fill 33 235 573 33 235 575 minecraft:magenta_concrete
setblock 33 235 576 minecraft:sea_lantern
fill 33 235 577 33 235 579 minecraft:magenta_concrete
setblock 33 235 580 minecraft:sea_lantern
fill 33 235 581 33 235 583 minecraft:magenta_concrete
setblock 33 235 584 minecraft:sea_lantern
fill 33 235 585 33 235 587 minecraft:magenta_concrete
setblock 33 235 588 minecraft:sea_lantern
fill 33 235 589 34 235 589 minecraft:magenta_concrete
setblock 34 235 567 minecraft:sea_lantern
fill 34 235 568 34 235 570 minecraft:magenta_concrete
setblock 34 235 571 minecraft:sea_lantern
fill 34 235 572 34 235 574 minecraft:magenta_concrete
setblock 34 235 575 minecraft:sea_lantern
fill 34 235 576 34 235 578 minecraft:magenta_concrete
setblock 34 235 579 minecraft:sea_lantern
fill 34 235 580 34 235 582 minecraft:magenta_concrete
setblock 34 235 583 minecraft:sea_lantern
fill 34 235 584 34 235 586 minecraft:magenta_concrete
setblock 34 235 587 minecraft:sea_lantern
fill 34 235 588 34 239 588 minecraft:magenta_concrete
fill 35 235 567 41 235 589 minecraft:black_concrete
setblock 3 236 560 minecraft:light[level=14]
setblock 3 236 568 minecraft:light[level=14]
setblock 3 236 576 minecraft:light[level=14]
setblock 3 236 584 minecraft:light[level=14]
setblock 3 236 592 minecraft:light[level=14]
setblock 11 236 560 minecraft:light[level=14]
setblock 11 236 568 minecraft:light[level=14]
setblock 11 236 576 minecraft:light[level=14]
setblock 11 236 584 minecraft:light[level=14]
setblock 11 236 592 minecraft:light[level=14]
fill 12 236 568 14 239 568 minecraft:magenta_concrete
fill 12 236 588 14 239 588 minecraft:magenta_concrete
fill 13 236 569 13 239 569 minecraft:magenta_concrete
fill 13 236 587 13 239 587 minecraft:magenta_concrete
fill 13 236 589 13 239 589 minecraft:magenta_concrete
fill 14 236 569 14 237 569 minecraft:bone_block
fill 14 236 578 14 242 578 minecraft:bone_block
fill 14 236 587 14 237 587 minecraft:bone_block
fill 17 236 569 17 237 569 minecraft:bone_block
fill 17 236 578 17 242 578 minecraft:bone_block
fill 17 236 587 17 237 587 minecraft:bone_block
setblock 19 236 560 minecraft:light[level=14]
setblock 19 236 568 minecraft:light[level=14]
setblock 19 236 576 minecraft:light[level=14]
setblock 19 236 584 minecraft:light[level=14]
setblock 19 236 592 minecraft:light[level=14]
fill 20 236 569 20 237 569 minecraft:bone_block
fill 20 236 578 20 242 578 minecraft:bone_block
fill 20 236 587 20 237 587 minecraft:bone_block
fill 23 236 569 23 237 569 minecraft:bone_block
fill 23 236 587 23 237 587 minecraft:bone_block
fill 26 236 569 26 237 569 minecraft:bone_block
fill 26 236 578 26 242 578 minecraft:bone_block
fill 26 236 587 26 237 587 minecraft:bone_block
setblock 27 236 560 minecraft:light[level=14]
setblock 27 236 568 minecraft:light[level=14]
setblock 27 236 576 minecraft:light[level=14]
setblock 27 236 584 minecraft:light[level=14]
setblock 27 236 592 minecraft:light[level=14]
fill 29 236 569 29 237 569 minecraft:bone_block
fill 29 236 578 29 242 578 minecraft:bone_block
fill 29 236 587 29 237 587 minecraft:bone_block
fill 32 236 568 34 239 568 minecraft:magenta_concrete
fill 32 236 569 32 237 569 minecraft:bone_block
fill 32 236 578 32 242 578 minecraft:bone_block
fill 32 236 587 32 237 587 minecraft:bone_block
fill 32 236 588 33 239 588 minecraft:magenta_concrete
fill 33 236 567 33 239 567 minecraft:magenta_concrete
fill 33 236 569 33 239 569 minecraft:magenta_concrete
fill 33 236 587 33 239 587 minecraft:magenta_concrete
fill 33 236 589 33 239 589 minecraft:magenta_concrete
setblock 35 236 560 minecraft:light[level=14]
setblock 35 236 568 minecraft:light[level=14]
setblock 35 236 576 minecraft:light[level=14]
setblock 35 236 584 minecraft:light[level=14]
setblock 35 236 592 minecraft:light[level=14]
fill 14 238 570 14 239 570 minecraft:bone_block
fill 14 238 586 14 239 586 minecraft:bone_block
fill 17 238 570 17 239 570 minecraft:bone_block
fill 17 238 586 17 239 586 minecraft:bone_block
fill 20 238 570 20 239 570 minecraft:bone_block
fill 20 238 586 20 239 586 minecraft:bone_block
fill 23 238 570 23 239 570 minecraft:bone_block
fill 23 238 586 23 239 586 minecraft:bone_block
fill 26 238 570 26 239 570 minecraft:bone_block
fill 26 238 586 26 239 586 minecraft:bone_block
fill 29 238 570 29 239 570 minecraft:bone_block
fill 29 238 586 29 239 586 minecraft:bone_block
fill 32 238 570 32 239 570 minecraft:bone_block
fill 32 238 586 32 239 586 minecraft:bone_block
fill 1 239 559 1 273 559 minecraft:gray_concrete
fill 1 239 569 1 273 569 minecraft:gray_concrete
fill 1 239 579 1 273 579 minecraft:gray_concrete
fill 1 239 589 1 273 589 minecraft:gray_concrete
fill 2 239 598 2 273 598 minecraft:gray_concrete
fill 8 239 558 8 273 558 minecraft:gray_concrete
fill 12 239 598 12 273 598 minecraft:gray_concrete
fill 18 239 558 18 273 558 minecraft:gray_concrete
fill 22 239 598 22 273 598 minecraft:gray_concrete
fill 28 239 558 28 273 558 minecraft:gray_concrete
fill 32 239 598 32 273 598 minecraft:gray_concrete
fill 38 239 558 38 273 558 minecraft:gray_concrete
fill 41 239 565 41 273 565 minecraft:gray_concrete
fill 41 239 575 41 273 575 minecraft:gray_concrete
fill 41 239 585 41 273 585 minecraft:gray_concrete
fill 41 239 595 41 273 595 minecraft:gray_concrete
setblock 1 240 560 minecraft:black_concrete
setblock 1 240 570 minecraft:black_concrete
setblock 1 240 580 minecraft:black_concrete
setblock 1 240 590 minecraft:black_concrete
setblock 3 240 598 minecraft:black_concrete
setblock 7 240 558 minecraft:black_concrete
fill 8 240 577 11 246 577 minecraft:bone_block
fill 9 240 578 11 246 579 minecraft:bone_block
fill 10 240 580 11 246 580 minecraft:bone_block
setblock 13 240 598 minecraft:black_concrete
fill 14 240 571 14 241 571 minecraft:bone_block
fill 14 240 585 14 241 585 minecraft:bone_block
setblock 17 240 558 minecraft:black_concrete
fill 17 240 571 17 241 571 minecraft:bone_block
fill 17 240 585 17 241 585 minecraft:bone_block
fill 20 240 571 20 241 571 minecraft:bone_block
fill 20 240 585 20 241 585 minecraft:bone_block
fill 23 240 571 23 241 571 minecraft:bone_block
fill 23 240 585 23 241 585 minecraft:bone_block
setblock 23 240 598 minecraft:black_concrete
fill 26 240 571 26 241 571 minecraft:bone_block
fill 26 240 585 26 241 585 minecraft:bone_block
setblock 27 240 558 minecraft:black_concrete
fill 29 240 571 29 241 571 minecraft:bone_block
fill 29 240 585 29 241 585 minecraft:bone_block
fill 32 240 571 32 241 571 minecraft:bone_block
fill 32 240 585 32 241 585 minecraft:bone_block
setblock 33 240 598 minecraft:black_concrete
setblock 37 240 558 minecraft:black_concrete
fill 37 240 595 37 241 597 minecraft:gray_concrete
setblock 41 240 564 minecraft:black_concrete
setblock 41 240 574 minecraft:black_concrete
setblock 41 240 584 minecraft:black_concrete
setblock 41 240 594 minecraft:black_concrete
fill 7 241 577 7 245 578 minecraft:bone_block
fill 8 241 576 12 245 576 minecraft:bone_block
fill 8 241 578 8 246 580 minecraft:bone_block
fill 9 241 580 9 247 580 minecraft:bone_block
fill 10 241 581 11 245 581 minecraft:bone_block
fill 11 241 575 11 245 575 minecraft:bone_block
fill 12 241 577 12 246 580 minecraft:bone_block
fill 13 241 577 13 245 577 minecraft:bone_block
fill 14 241 572 14 243 572 minecraft:bone_block
fill 14 241 584 14 243 584 minecraft:bone_block
fill 17 241 572 17 243 572 minecraft:bone_block
fill 17 241 584 17 243 584 minecraft:bone_block
fill 20 241 572 20 243 572 minecraft:bone_block
fill 20 241 584 20 243 584 minecraft:bone_block
fill 23 241 572 23 243 572 minecraft:bone_block
fill 23 241 584 23 243 584 minecraft:bone_block
fill 26 241 572 26 243 572 minecraft:bone_block
fill 26 241 584 26 243 584 minecraft:bone_block
fill 29 241 572 29 243 572 minecraft:bone_block
fill 29 241 584 29 243 584 minecraft:bone_block
fill 32 241 572 32 243 572 minecraft:bone_block
fill 32 241 584 32 243 584 minecraft:bone_block
fill 6 242 578 6 244 578 minecraft:bone_block
fill 7 242 579 7 245 580 minecraft:bone_block
fill 9 242 575 10 246 575 minecraft:bone_block
fill 9 242 581 9 246 581 minecraft:bone_block
fill 12 242 575 12 244 575 minecraft:bone_block
fill 13 242 576 13 244 576 minecraft:bone_block
fill 13 242 578 13 246 579 minecraft:bone_block
fill 14 242 577 14 245 577 minecraft:bone_block
fill 14 242 579 14 245 579 minecraft:bone_block
fill 17 242 577 17 245 577 minecraft:bone_block
fill 17 242 579 17 245 579 minecraft:bone_block
fill 20 242 577 20 245 577 minecraft:bone_block
fill 20 242 579 20 245 579 minecraft:bone_block
fill 23 242 577 23 245 577 minecraft:bone_block
fill 26 242 577 26 245 577 minecraft:bone_block
fill 26 242 579 26 245 579 minecraft:bone_block
fill 29 242 577 29 245 577 minecraft:bone_block
fill 29 242 579 29 245 579 minecraft:bone_block
fill 32 242 577 32 245 577 minecraft:bone_block
fill 32 242 579 32 245 579 minecraft:bone_block
fill 1 243 562 1 243 565 minecraft:black_concrete
fill 1 243 572 1 243 575 minecraft:black_concrete
fill 1 243 582 1 243 585 minecraft:black_concrete
fill 1 243 592 1 243 595 minecraft:black_concrete
fill 2 243 558 5 243 558 minecraft:black_concrete
fill 5 243 598 8 243 598 minecraft:black_concrete
fill 6 243 579 6 244 579 minecraft:bone_block
fill 8 243 575 8 245 575 minecraft:bone_block
fill 8 243 581 8 245 581 minecraft:bone_block
fill 10 243 574 11 244 574 minecraft:bone_block
fill 12 243 558 15 243 558 minecraft:black_concrete
fill 12 243 581 12 245 581 minecraft:bone_block
fill 13 243 580 13 245 580 minecraft:bone_block
fill 14 243 573 14 244 573 minecraft:bone_block
fill 14 243 583 14 244 583 minecraft:bone_block
fill 15 243 598 18 243 598 minecraft:black_concrete
fill 17 243 573 17 244 573 minecraft:bone_block
fill 17 243 583 17 244 583 minecraft:bone_block
fill 20 243 573 20 244 573 minecraft:bone_block
fill 20 243 583 20 244 583 minecraft:bone_block
fill 22 243 558 25 243 558 minecraft:black_concrete
fill 23 243 573 23 244 573 minecraft:bone_block
fill 23 243 583 23 244 583 minecraft:bone_block
fill 25 243 598 28 243 598 minecraft:black_concrete
fill 26 243 573 26 244 573 minecraft:bone_block
fill 26 243 583 26 244 583 minecraft:bone_block
fill 29 243 573 29 244 573 minecraft:bone_block
fill 29 243 583 29 244 583 minecraft:bone_block
fill 32 243 558 35 243 558 minecraft:black_concrete
fill 32 243 573 32 244 573 minecraft:bone_block
fill 32 243 583 32 244 583 minecraft:bone_block
fill 35 243 598 38 243 598 minecraft:black_concrete
fill 41 243 559 41 243 562 minecraft:black_concrete
fill 41 243 569 41 243 572 minecraft:black_concrete
fill 41 243 579 41 243 582 minecraft:black_concrete
fill 41 243 589 41 243 592 minecraft:black_concrete
setblock 3 244 560 minecraft:light[level=14]
setblock 3 244 568 minecraft:light[level=14]
setblock 3 244 576 minecraft:light[level=14]
setblock 3 244 584 minecraft:light[level=14]
setblock 3 244 592 minecraft:light[level=14]
setblock 7 244 576 minecraft:bone_block
setblock 9 244 574 minecraft:bone_block
setblock 11 244 560 minecraft:light[level=14]
setblock 11 244 568 minecraft:light[level=14]
setblock 11 244 584 minecraft:light[level=14]
setblock 11 244 592 minecraft:light[level=14]
fill 14 244 574 14 245 574 minecraft:bone_block
fill 14 244 578 14 246 578 minecraft:bone_block
fill 14 244 582 14 245 582 minecraft:bone_block
fill 17 244 574 17 245 574 minecraft:bone_block
fill 17 244 582 17 245 582 minecraft:bone_block
setblock 19 244 560 minecraft:light[level=14]
setblock 19 244 568 minecraft:light[level=14]
setblock 19 244 576 minecraft:light[level=14]
setblock 19 244 584 minecraft:light[level=14]
setblock 19 244 592 minecraft:light[level=14]
fill 20 244 574 20 245 574 minecraft:bone_block
fill 20 244 582 20 245 582 minecraft:bone_block
fill 23 244 574 23 245 574 minecraft:bone_block
fill 23 244 582 23 245 582 minecraft:bone_block
fill 26 244 574 26 245 574 minecraft:bone_block
fill 26 244 582 26 245 582 minecraft:bone_block
setblock 27 244 560 minecraft:light[level=14]
setblock 27 244 568 minecraft:light[level=14]
setblock 27 244 576 minecraft:light[level=14]
setblock 27 244 584 minecraft:light[level=14]
setblock 27 244 592 minecraft:light[level=14]
fill 29 244 574 29 245 574 minecraft:bone_block
fill 29 244 582 29 245 582 minecraft:bone_block
fill 32 244 574 32 245 574 minecraft:bone_block
fill 32 244 582 32 245 582 minecraft:bone_block
setblock 35 244 560 minecraft:light[level=14]
setblock 35 244 568 minecraft:light[level=14]
setblock 35 244 576 minecraft:light[level=14]
setblock 35 244 584 minecraft:light[level=14]
setblock 35 244 592 minecraft:light[level=14]
fill 14 245 575 14 245 576 minecraft:bone_block
fill 14 245 580 14 245 581 minecraft:bone_block
fill 15 245 578 21 246 578 minecraft:bone_block
fill 17 245 575 17 245 576 minecraft:bone_block
fill 17 245 580 17 245 581 minecraft:bone_block
fill 20 245 575 20 245 576 minecraft:bone_block
fill 20 245 580 20 245 581 minecraft:bone_block
fill 23 245 575 23 245 576 minecraft:bone_block
fill 23 245 580 23 245 581 minecraft:bone_block
fill 24 245 578 34 246 578 minecraft:bone_block
fill 26 245 575 26 245 576 minecraft:bone_block
fill 26 245 580 26 245 581 minecraft:bone_block
fill 29 245 575 29 245 576 minecraft:bone_block
fill 29 245 580 29 245 581 minecraft:bone_block
fill 32 245 575 32 245 576 minecraft:bone_block
fill 32 245 580 32 245 581 minecraft:bone_block
setblock 1 246 560 minecraft:black_concrete
setblock 1 246 570 minecraft:black_concrete
setblock 1 246 580 minecraft:black_concrete
setblock 1 246 590 minecraft:black_concrete
setblock 3 246 598 minecraft:black_concrete
setblock 7 246 558 minecraft:black_concrete
fill 8 246 576 11 246 576 minecraft:bone_block
setblock 10 246 581 minecraft:bone_block
setblock 13 246 598 minecraft:black_concrete
setblock 17 246 558 minecraft:black_concrete
setblock 23 246 598 minecraft:black_concrete
setblock 27 246 558 minecraft:black_concrete
setblock 33 246 598 minecraft:black_concrete
setblock 37 246 558 minecraft:black_concrete
setblock 41 246 564 minecraft:black_concrete
setblock 41 246 574 minecraft:black_concrete
setblock 41 246 584 minecraft:black_concrete
setblock 41 246 594 minecraft:black_concrete
fill 0 247 563 0 247 566 minecraft:sea_lantern
fill 0 247 573 0 247 576 minecraft:sea_lantern
fill 0 247 583 0 247 586 minecraft:sea_lantern
fill 0 247 593 0 247 596 minecraft:sea_lantern
fill 3 247 557 6 247 557 minecraft:sea_lantern
fill 4 247 599 7 247 599 minecraft:sea_lantern
fill 8 247 577 10 247 577 minecraft:bone_block
setblock 9 247 576 minecraft:bone_block
fill 9 247 579 12 247 579 minecraft:bone_block
fill 10 247 578 12 247 578 minecraft:bone_block
setblock 10 247 580 minecraft:bone_block
fill 13 247 557 16 247 557 minecraft:sea_lantern
fill 14 247 599 17 247 599 minecraft:sea_lantern
fill 23 247 557 26 247 557 minecraft:sea_lantern
fill 24 247 599 27 247 599 minecraft:sea_lantern
fill 33 247 557 36 247 557 minecraft:sea_lantern
fill 34 247 599 37 247 599 minecraft:sea_lantern
fill 42 247 558 42 247 561 minecraft:sea_lantern
fill 42 247 568 42 247 571 minecraft:sea_lantern
fill 42 247 578 42 247 581 minecraft:sea_lantern
fill 42 247 588 42 247 591 minecraft:sea_lantern
setblock 42 247 598 minecraft:sea_lantern
fill 0 248 563 0 255 566 minecraft:black_concrete
fill 0 248 573 0 255 576 minecraft:black_concrete
fill 0 248 583 0 255 586 minecraft:black_concrete
fill 0 248 593 0 255 596 minecraft:black_concrete
fill 1 248 572 3 249 572 minecraft:gray_concrete
fill 3 248 557 6 255 557 minecraft:black_concrete
fill 4 248 599 7 255 599 minecraft:black_concrete
fill 13 248 557 16 255 557 minecraft:black_concrete
fill 14 248 599 17 255 599 minecraft:black_concrete
fill 23 248 557 26 255 557 minecraft:black_concrete
fill 24 248 599 27 255 599 minecraft:black_concrete
fill 33 248 557 36 255 557 minecraft:black_concrete
fill 34 248 599 37 255 599 minecraft:black_concrete
fill 42 248 558 42 255 561 minecraft:black_concrete
fill 42 248 568 42 255 571 minecraft:black_concrete
fill 42 248 578 42 255 581 minecraft:black_concrete
fill 42 248 588 42 255 591 minecraft:black_concrete
fill 42 248 598 42 255 598 minecraft:black_concrete
fill 25 250 558 25 251 560 minecraft:gray_concrete
setblock 1 252 560 minecraft:black_concrete
fill 1 252 562 1 252 565 minecraft:black_concrete
setblock 1 252 570 minecraft:black_concrete
fill 1 252 572 1 252 575 minecraft:black_concrete
setblock 1 252 580 minecraft:black_concrete
fill 1 252 582 1 252 585 minecraft:black_concrete
setblock 1 252 590 minecraft:black_concrete
fill 1 252 592 1 252 595 minecraft:black_concrete
fill 2 252 558 5 252 558 minecraft:black_concrete
setblock 3 252 560 minecraft:light[level=14]
setblock 3 252 568 minecraft:light[level=14]
setblock 3 252 576 minecraft:light[level=14]
setblock 3 252 584 minecraft:light[level=14]
setblock 3 252 592 minecraft:light[level=14]
setblock 3 252 598 minecraft:black_concrete
fill 5 252 598 8 252 598 minecraft:black_concrete
setblock 7 252 558 minecraft:black_concrete
setblock 11 252 560 minecraft:light[level=14]
setblock 11 252 568 minecraft:light[level=14]
setblock 11 252 576 minecraft:light[level=14]
setblock 11 252 584 minecraft:light[level=14]
setblock 11 252 592 minecraft:light[level=14]
fill 12 252 558 15 252 558 minecraft:black_concrete
setblock 13 252 598 minecraft:black_concrete
fill 15 252 598 18 252 598 minecraft:black_concrete
setblock 17 252 558 minecraft:black_concrete
setblock 19 252 560 minecraft:light[level=14]
setblock 19 252 568 minecraft:light[level=14]
setblock 19 252 576 minecraft:light[level=14]
setblock 19 252 584 minecraft:light[level=14]
setblock 19 252 592 minecraft:light[level=14]
fill 22 252 558 25 252 558 minecraft:black_concrete
setblock 23 252 598 minecraft:black_concrete
fill 25 252 598 28 252 598 minecraft:black_concrete
setblock 27 252 558 minecraft:black_concrete
setblock 27 252 560 minecraft:light[level=14]
setblock 27 252 568 minecraft:light[level=14]
setblock 27 252 576 minecraft:light[level=14]
setblock 27 252 584 minecraft:light[level=14]
setblock 27 252 592 minecraft:light[level=14]
fill 32 252 558 35 252 558 minecraft:black_concrete
setblock 33 252 598 minecraft:black_concrete
setblock 35 252 560 minecraft:light[level=14]
setblock 35 252 568 minecraft:light[level=14]
setblock 35 252 576 minecraft:light[level=14]
setblock 35 252 584 minecraft:light[level=14]
setblock 35 252 592 minecraft:light[level=14]
fill 35 252 598 38 252 598 minecraft:black_concrete
setblock 37 252 558 minecraft:black_concrete
fill 41 252 559 41 252 562 minecraft:black_concrete
setblock 41 252 564 minecraft:black_concrete
fill 41 252 569 41 252 572 minecraft:black_concrete
setblock 41 252 574 minecraft:black_concrete
fill 41 252 579 41 252 582 minecraft:black_concrete
setblock 41 252 584 minecraft:black_concrete
fill 41 252 589 41 252 592 minecraft:black_concrete
setblock 41 252 594 minecraft:black_concrete
fill 0 256 563 0 256 566 minecraft:sea_lantern
fill 0 256 573 0 256 576 minecraft:sea_lantern
fill 0 256 583 0 256 586 minecraft:sea_lantern
fill 0 256 593 0 256 596 minecraft:sea_lantern
fill 3 256 557 6 256 557 minecraft:sea_lantern
fill 4 256 599 7 256 599 minecraft:sea_lantern
fill 13 256 557 16 256 557 minecraft:sea_lantern
fill 14 256 599 17 256 599 minecraft:sea_lantern
fill 23 256 557 26 256 557 minecraft:sea_lantern
fill 24 256 599 27 256 599 minecraft:sea_lantern
fill 33 256 557 36 256 557 minecraft:sea_lantern
fill 34 256 599 37 256 599 minecraft:sea_lantern
fill 42 256 558 42 256 561 minecraft:sea_lantern
fill 42 256 568 42 256 571 minecraft:sea_lantern
fill 42 256 578 42 256 581 minecraft:sea_lantern
fill 42 256 588 42 256 591 minecraft:sea_lantern
setblock 42 256 598 minecraft:sea_lantern
fill 0 257 563 0 264 566 minecraft:black_concrete
fill 0 257 573 0 264 576 minecraft:black_concrete
fill 0 257 583 0 264 586 minecraft:black_concrete
fill 0 257 593 0 264 596 minecraft:black_concrete
fill 3 257 557 6 264 557 minecraft:black_concrete
fill 4 257 599 7 264 599 minecraft:black_concrete
fill 13 257 557 16 264 557 minecraft:black_concrete
fill 14 257 599 17 264 599 minecraft:black_concrete
fill 23 257 557 26 264 557 minecraft:black_concrete
fill 24 257 599 27 264 599 minecraft:black_concrete
fill 33 257 557 36 264 557 minecraft:black_concrete
fill 34 257 599 37 264 599 minecraft:black_concrete
fill 42 257 558 42 264 561 minecraft:black_concrete
fill 42 257 568 42 264 571 minecraft:black_concrete
fill 42 257 578 42 264 581 minecraft:black_concrete
fill 42 257 588 42 264 591 minecraft:black_concrete
fill 42 257 598 42 264 598 minecraft:black_concrete
setblock 1 258 560 minecraft:black_concrete
setblock 1 258 570 minecraft:black_concrete
setblock 1 258 580 minecraft:black_concrete
setblock 1 258 590 minecraft:black_concrete
setblock 3 258 598 minecraft:black_concrete
setblock 7 258 558 minecraft:black_concrete
setblock 13 258 598 minecraft:black_concrete
setblock 17 258 558 minecraft:black_concrete
setblock 23 258 598 minecraft:black_concrete
setblock 27 258 558 minecraft:black_concrete
setblock 33 258 598 minecraft:black_concrete
setblock 37 258 558 minecraft:black_concrete
setblock 41 258 564 minecraft:black_concrete
setblock 41 258 574 minecraft:black_concrete
setblock 41 258 584 minecraft:black_concrete
setblock 41 258 594 minecraft:black_concrete
fill 2 260 574 3 261 582 minecraft:black_concrete
setblock 3 260 560 minecraft:light[level=14]
setblock 3 260 568 minecraft:light[level=14]
fill 3 260 571 4 261 573 minecraft:black_concrete
fill 3 260 583 4 261 585 minecraft:black_concrete
setblock 3 260 592 minecraft:light[level=14]
fill 4 260 569 5 261 570 minecraft:black_concrete
fill 4 260 586 5 261 587 minecraft:black_concrete
fill 5 260 567 6 261 568 minecraft:black_concrete
fill 5 260 588 6 261 589 minecraft:black_concrete
fill 6 260 566 8 261 566 minecraft:black_concrete
fill 6 260 590 8 261 590 minecraft:black_concrete
fill 7 260 565 9 261 565 minecraft:black_concrete
fill 7 260 567 7 261 567 minecraft:black_concrete
fill 7 260 589 7 261 589 minecraft:black_concrete
fill 7 260 591 9 261 591 minecraft:black_concrete
fill 8 260 564 10 261 564 minecraft:black_concrete
fill 8 260 592 10 261 592 minecraft:black_concrete
fill 9 260 563 11 261 563 minecraft:black_concrete
fill 9 260 593 11 261 593 minecraft:black_concrete
fill 10 260 562 13 261 562 minecraft:black_concrete
fill 10 260 594 13 261 594 minecraft:black_concrete
setblock 11 260 560 minecraft:light[level=14]
setblock 11 260 568 minecraft:light[level=14]
setblock 11 260 576 minecraft:light[level=14]
setblock 11 260 584 minecraft:light[level=14]
setblock 11 260 592 minecraft:light[level=14]
fill 12 260 561 16 261 561 minecraft:black_concrete
fill 12 260 595 16 261 595 minecraft:black_concrete
fill 14 260 560 28 261 560 minecraft:black_concrete
fill 14 260 596 28 261 596 minecraft:black_concrete
fill 17 260 559 25 261 559 minecraft:black_concrete
fill 17 260 597 25 261 597 minecraft:black_concrete
setblock 19 260 568 minecraft:light[level=14]
setblock 19 260 576 minecraft:light[level=14]
setblock 19 260 584 minecraft:light[level=14]
setblock 19 260 592 minecraft:light[level=14]
fill 26 260 561 30 261 561 minecraft:black_concrete
fill 26 260 595 30 261 595 minecraft:black_concrete
setblock 27 260 568 minecraft:light[level=14]
setblock 27 260 576 minecraft:light[level=14]
setblock 27 260 584 minecraft:light[level=14]
setblock 27 260 592 minecraft:light[level=14]
fill 29 260 562 32 261 562 minecraft:black_concrete
fill 29 260 594 32 261 594 minecraft:black_concrete
fill 31 260 563 33 261 563 minecraft:black_concrete
fill 31 260 593 33 261 593 minecraft:black_concrete
fill 32 260 564 34 261 564 minecraft:black_concrete
fill 32 260 592 34 261 592 minecraft:black_concrete
fill 33 260 565 35 261 565 minecraft:black_concrete
fill 33 260 591 35 261 591 minecraft:black_concrete
fill 34 260 566 36 261 566 minecraft:black_concrete
fill 34 260 590 36 261 590 minecraft:black_concrete
setblock 35 260 560 minecraft:light[level=14]
fill 35 260 567 37 261 567 minecraft:black_concrete
setblock 35 260 568 minecraft:light[level=14]
setblock 35 260 576 minecraft:light[level=14]
setblock 35 260 584 minecraft:light[level=14]
fill 35 260 589 37 261 589 minecraft:black_concrete
setblock 35 260 592 minecraft:light[level=14]
fill 36 260 568 37 261 568 minecraft:black_concrete
fill 36 260 588 37 261 588 minecraft:black_concrete
fill 37 260 569 38 261 570 minecraft:black_concrete
fill 37 260 586 38 261 587 minecraft:black_concrete
fill 38 260 571 39 261 573 minecraft:black_concrete
fill 38 260 583 39 261 585 minecraft:black_concrete
fill 39 260 574 40 261 582 minecraft:black_concrete
fill 1 261 562 1 261 565 minecraft:black_concrete
fill 1 261 572 1 261 575 minecraft:black_concrete
fill 1 261 582 1 261 585 minecraft:black_concrete
fill 1 261 592 1 261 595 minecraft:black_concrete
fill 2 261 558 5 261 558 minecraft:black_concrete
fill 5 261 598 8 261 598 minecraft:black_concrete
fill 12 261 558 15 261 558 minecraft:black_concrete
fill 15 261 598 18 261 598 minecraft:black_concrete
fill 22 261 558 25 261 558 minecraft:black_concrete
fill 25 261 598 28 261 598 minecraft:black_concrete
fill 32 261 558 35 261 558 minecraft:black_concrete
fill 35 261 598 38 261 598 minecraft:black_concrete
fill 41 261 559 41 261 562 minecraft:black_concrete
fill 41 261 569 41 261 572 minecraft:black_concrete
fill 41 261 579 41 261 582 minecraft:black_concrete
fill 41 261 589 41 261 592 minecraft:black_concrete
fill 4 262 569 4 262 570 minecraft:sea_lantern
fill 5 262 567 5 262 568 minecraft:sea_lantern
setblock 6 262 566 minecraft:sea_lantern
setblock 7 262 565 minecraft:sea_lantern
setblock 8 262 564 minecraft:sea_lantern
setblock 9 262 563 minecraft:sea_lantern
fill 10 262 562 11 262 562 minecraft:sea_lantern
fill 12 262 561 13 262 561 minecraft:sea_lantern
fill 14 262 560 16 262 560 minecraft:sea_lantern
fill 17 262 559 25 262 559 minecraft:sea_lantern
fill 26 262 560 28 262 560 minecraft:sea_lantern
fill 29 262 561 30 262 561 minecraft:sea_lantern
fill 31 262 562 32 262 562 minecraft:sea_lantern
setblock 33 262 563 minecraft:sea_lantern
setblock 34 262 564 minecraft:sea_lantern
setblock 35 262 565 minecraft:sea_lantern
setblock 36 262 566 minecraft:sea_lantern
fill 37 262 567 37 262 568 minecraft:sea_lantern
fill 38 262 569 38 262 570 minecraft:sea_lantern
setblock 1 264 560 minecraft:black_concrete
setblock 1 264 570 minecraft:black_concrete
setblock 1 264 580 minecraft:black_concrete
setblock 1 264 590 minecraft:black_concrete
setblock 3 264 598 minecraft:black_concrete
setblock 7 264 558 minecraft:black_concrete
setblock 13 264 598 minecraft:black_concrete
setblock 17 264 558 minecraft:black_concrete
setblock 23 264 598 minecraft:black_concrete
setblock 27 264 558 minecraft:black_concrete
setblock 33 264 598 minecraft:black_concrete
setblock 37 264 558 minecraft:black_concrete
setblock 41 264 564 minecraft:black_concrete
setblock 41 264 574 minecraft:black_concrete
setblock 41 264 584 minecraft:black_concrete
setblock 41 264 594 minecraft:black_concrete
fill 0 265 563 0 265 566 minecraft:sea_lantern
fill 0 265 573 0 265 576 minecraft:sea_lantern
fill 0 265 583 0 265 586 minecraft:sea_lantern
fill 0 265 593 0 265 596 minecraft:sea_lantern
fill 3 265 557 6 265 557 minecraft:sea_lantern
fill 4 265 599 7 265 599 minecraft:sea_lantern
fill 13 265 557 16 265 557 minecraft:sea_lantern
fill 14 265 599 17 265 599 minecraft:sea_lantern
fill 23 265 557 26 265 557 minecraft:sea_lantern
fill 24 265 599 27 265 599 minecraft:sea_lantern
fill 25 265 595 25 266 597 minecraft:gray_concrete
fill 33 265 557 36 265 557 minecraft:sea_lantern
fill 34 265 599 37 265 599 minecraft:sea_lantern
fill 42 265 558 42 265 561 minecraft:sea_lantern
fill 42 265 568 42 265 571 minecraft:sea_lantern
fill 42 265 578 42 265 581 minecraft:sea_lantern
fill 42 265 588 42 265 591 minecraft:sea_lantern
setblock 42 265 598 minecraft:sea_lantern
fill 0 266 563 0 291 566 minecraft:black_concrete
fill 0 266 573 0 291 576 minecraft:black_concrete
fill 0 266 583 0 291 586 minecraft:black_concrete
fill 0 266 593 0 291 596 minecraft:black_concrete
fill 3 266 557 6 291 557 minecraft:black_concrete
fill 4 266 599 7 291 599 minecraft:black_concrete
fill 13 266 557 16 291 557 minecraft:black_concrete
fill 14 266 599 17 291 599 minecraft:black_concrete
fill 23 266 557 26 291 557 minecraft:black_concrete
fill 24 266 599 27 291 599 minecraft:black_concrete
fill 33 266 557 36 291 557 minecraft:black_concrete
fill 34 266 599 37 291 599 minecraft:black_concrete
fill 42 266 558 42 291 561 minecraft:black_concrete
fill 42 266 568 42 291 571 minecraft:black_concrete
fill 42 266 578 42 291 581 minecraft:black_concrete
fill 42 266 588 42 291 591 minecraft:black_concrete
fill 42 266 598 42 291 598 minecraft:black_concrete
setblock 3 268 560 minecraft:light[level=14]
setblock 3 268 568 minecraft:light[level=14]
setblock 3 268 576 minecraft:light[level=14]
setblock 3 268 584 minecraft:light[level=14]
setblock 3 268 592 minecraft:light[level=14]
fill 4 268 595 4 269 597 minecraft:gray_concrete
setblock 11 268 560 minecraft:light[level=14]
setblock 11 268 568 minecraft:light[level=14]
setblock 11 268 576 minecraft:light[level=14]
setblock 11 268 584 minecraft:light[level=14]
setblock 11 268 592 minecraft:light[level=14]
setblock 19 268 560 minecraft:light[level=14]
setblock 19 268 568 minecraft:light[level=14]
setblock 19 268 576 minecraft:light[level=14]
setblock 19 268 584 minecraft:light[level=14]
setblock 19 268 592 minecraft:light[level=14]
setblock 27 268 560 minecraft:light[level=14]
setblock 27 268 568 minecraft:light[level=14]
setblock 27 268 576 minecraft:light[level=14]
setblock 27 268 584 minecraft:light[level=14]
setblock 27 268 592 minecraft:light[level=14]
setblock 35 268 560 minecraft:light[level=14]
setblock 35 268 568 minecraft:light[level=14]
setblock 35 268 576 minecraft:light[level=14]
setblock 35 268 584 minecraft:light[level=14]
setblock 35 268 592 minecraft:light[level=14]
setblock 1 270 560 minecraft:black_concrete
fill 1 270 562 1 270 565 minecraft:black_concrete
setblock 1 270 570 minecraft:black_concrete
fill 1 270 572 1 270 575 minecraft:black_concrete
setblock 1 270 580 minecraft:black_concrete
fill 1 270 582 1 270 585 minecraft:black_concrete
setblock 1 270 590 minecraft:black_concrete
fill 1 270 592 1 270 595 minecraft:black_concrete
fill 2 270 558 5 270 558 minecraft:black_concrete
setblock 3 270 598 minecraft:black_concrete
fill 5 270 598 8 270 598 minecraft:black_concrete
setblock 7 270 558 minecraft:black_concrete
fill 12 270 558 15 270 558 minecraft:black_concrete
setblock 13 270 598 minecraft:black_concrete
fill 15 270 598 18 270 598 minecraft:black_concrete
setblock 17 270 558 minecraft:black_concrete
fill 22 270 558 25 270 558 minecraft:black_concrete
setblock 23 270 598 minecraft:black_concrete
fill 25 270 598 28 270 598 minecraft:black_concrete
setblock 27 270 558 minecraft:black_concrete
fill 32 270 558 35 270 558 minecraft:black_concrete
fill 33 270 559 33 271 560 minecraft:gray_concrete
setblock 33 270 598 minecraft:black_concrete
fill 35 270 598 38 270 598 minecraft:black_concrete
setblock 37 270 558 minecraft:black_concrete
fill 41 270 559 41 270 562 minecraft:black_concrete
setblock 41 270 564 minecraft:black_concrete
fill 41 270 569 41 270 572 minecraft:black_concrete
setblock 41 270 574 minecraft:black_concrete
fill 41 270 579 41 270 582 minecraft:black_concrete
setblock 41 270 584 minecraft:black_concrete
fill 41 270 589 41 270 592 minecraft:black_concrete
setblock 41 270 594 minecraft:black_concrete
setblock 33 271 558 minecraft:gray_concrete
setblock 3 276 560 minecraft:light[level=14]
setblock 3 276 568 minecraft:light[level=14]
setblock 3 276 576 minecraft:light[level=14]
setblock 3 276 584 minecraft:light[level=14]
setblock 3 276 592 minecraft:light[level=14]
setblock 11 276 560 minecraft:light[level=14]
setblock 11 276 568 minecraft:light[level=14]
setblock 11 276 576 minecraft:light[level=14]
setblock 11 276 584 minecraft:light[level=14]
setblock 11 276 592 minecraft:light[level=14]
setblock 19 276 560 minecraft:light[level=14]
setblock 19 276 568 minecraft:light[level=14]
setblock 19 276 576 minecraft:light[level=14]
setblock 19 276 584 minecraft:light[level=14]
setblock 19 276 592 minecraft:light[level=14]
setblock 27 276 560 minecraft:light[level=14]
setblock 27 276 568 minecraft:light[level=14]
setblock 27 276 576 minecraft:light[level=14]
setblock 27 276 584 minecraft:light[level=14]
setblock 27 276 592 minecraft:light[level=14]
setblock 35 276 560 minecraft:light[level=14]
setblock 35 276 568 minecraft:light[level=14]
setblock 35 276 576 minecraft:light[level=14]
setblock 35 276 584 minecraft:light[level=14]
setblock 35 276 592 minecraft:light[level=14]
fill 6 279 565 7 279 595 minecraft:cyan_concrete
fill 8 279 565 36 279 566 minecraft:cyan_concrete
fill 8 279 567 18 279 593 minecraft:black_concrete
fill 8 279 594 36 279 595 minecraft:cyan_concrete
fill 19 279 567 19 279 579 minecraft:black_concrete
fill 19 279 581 19 279 593 minecraft:black_concrete
fill 20 279 567 20 279 578 minecraft:black_concrete
fill 20 279 582 20 279 593 minecraft:black_concrete
fill 21 279 567 34 279 577 minecraft:black_concrete
fill 21 279 583 34 279 593 minecraft:black_concrete
fill 22 279 578 34 279 578 minecraft:black_concrete
fill 22 279 582 34 279 582 minecraft:black_concrete
fill 23 279 579 34 279 579 minecraft:black_concrete
fill 23 279 581 34 279 581 minecraft:black_concrete
fill 24 279 580 34 279 580 minecraft:black_concrete
fill 35 279 567 36 279 593 minecraft:cyan_concrete
fill 1 280 558 5 280 598 minecraft:black_concrete
fill 6 280 558 41 280 564 minecraft:black_concrete
fill 6 280 565 6 280 566 minecraft:cyan_concrete
setblock 6 280 567 minecraft:sea_lantern
fill 6 280 568 6 280 570 minecraft:cyan_concrete
setblock 6 280 571 minecraft:sea_lantern
fill 6 280 572 6 280 574 minecraft:cyan_concrete
setblock 6 280 575 minecraft:sea_lantern
fill 6 280 576 6 280 578 minecraft:cyan_concrete
setblock 6 280 579 minecraft:sea_lantern
fill 6 280 580 6 280 582 minecraft:cyan_concrete
setblock 6 280 583 minecraft:sea_lantern
fill 6 280 584 6 280 586 minecraft:cyan_concrete
setblock 6 280 587 minecraft:sea_lantern
fill 6 280 588 6 280 590 minecraft:cyan_concrete
setblock 6 280 591 minecraft:sea_lantern
fill 6 280 592 6 280 594 minecraft:cyan_concrete
setblock 6 280 595 minecraft:sea_lantern
fill 6 280 596 41 280 598 minecraft:black_concrete
fill 7 280 565 7 284 565 minecraft:cyan_concrete
setblock 7 280 566 minecraft:sea_lantern
fill 7 280 567 7 280 569 minecraft:cyan_concrete
setblock 7 280 570 minecraft:sea_lantern
fill 7 280 571 7 280 573 minecraft:cyan_concrete
setblock 7 280 574 minecraft:sea_lantern
fill 7 280 575 7 280 577 minecraft:cyan_concrete
setblock 7 280 578 minecraft:sea_lantern
fill 7 280 579 7 280 581 minecraft:cyan_concrete
setblock 7 280 582 minecraft:sea_lantern
fill 7 280 583 7 280 585 minecraft:cyan_concrete
setblock 7 280 586 minecraft:sea_lantern
fill 7 280 587 7 280 589 minecraft:cyan_concrete
setblock 7 280 590 minecraft:sea_lantern
fill 7 280 591 7 280 593 minecraft:cyan_concrete
setblock 7 280 594 minecraft:sea_lantern
fill 7 280 595 9 280 595 minecraft:cyan_concrete
setblock 8 280 565 minecraft:sea_lantern
fill 8 280 566 10 280 566 minecraft:cyan_concrete
fill 8 280 567 17 280 593 minecraft:black_concrete
fill 8 280 594 10 280 594 minecraft:cyan_concrete
fill 9 280 565 11 280 565 minecraft:cyan_concrete
setblock 10 280 595 minecraft:sea_lantern
setblock 11 280 566 minecraft:sea_lantern
setblock 11 280 594 minecraft:sea_lantern
fill 11 280 595 13 280 595 minecraft:cyan_concrete
setblock 12 280 565 minecraft:sea_lantern
fill 12 280 566 14 280 566 minecraft:cyan_concrete
fill 12 280 594 14 280 594 minecraft:cyan_concrete
fill 13 280 565 15 280 565 minecraft:cyan_concrete
setblock 14 280 595 minecraft:sea_lantern
setblock 15 280 566 minecraft:sea_lantern
setblock 15 280 594 minecraft:sea_lantern
fill 15 280 595 17 280 595 minecraft:cyan_concrete
setblock 16 280 565 minecraft:sea_lantern
fill 16 280 566 18 280 566 minecraft:cyan_concrete
fill 16 280 594 18 280 594 minecraft:cyan_concrete
fill 17 280 565 19 280 565 minecraft:cyan_concrete
fill 18 280 567 18 280 578 minecraft:black_concrete
fill 18 280 579 18 280 581 minecraft:sea_lantern
schedule function dropper:buildpart/132_2 1t
