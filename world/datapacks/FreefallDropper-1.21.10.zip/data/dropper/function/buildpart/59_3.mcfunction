fill 517 193 244 517 195 244 minecraft:purple_terracotta
fill 517 193 248 517 195 248 minecraft:purple_terracotta
fill 517 193 252 517 195 252 minecraft:purple_terracotta
fill 517 193 256 517 195 256 minecraft:purple_terracotta
fill 517 193 260 517 195 260 minecraft:purple_terracotta
fill 517 193 264 517 195 264 minecraft:purple_terracotta
fill 517 193 268 517 195 268 minecraft:purple_terracotta
setblock 517 193 270 minecraft:purple_terracotta
setblock 520 193 231 minecraft:light[level=11]
setblock 520 193 238 minecraft:light[level=12]
setblock 520 193 239 minecraft:light[level=11]
setblock 520 193 245 minecraft:light[level=12]
setblock 520 193 247 minecraft:light[level=11]
setblock 520 193 252 minecraft:light[level=12]
setblock 520 193 255 minecraft:light[level=11]
setblock 520 193 259 minecraft:light[level=12]
setblock 520 193 263 minecraft:light[level=11]
setblock 520 193 266 minecraft:light[level=12]
fill 521 193 228 521 195 228 minecraft:purple_terracotta
fill 521 193 270 521 195 270 minecraft:purple_terracotta
fill 525 193 228 525 195 228 minecraft:purple_terracotta
fill 525 193 270 525 195 270 minecraft:purple_terracotta
setblock 527 193 231 minecraft:light[level=12]
setblock 527 193 238 minecraft:light[level=12]
setblock 527 193 245 minecraft:light[level=12]
setblock 527 193 252 minecraft:light[level=12]
setblock 527 193 259 minecraft:light[level=12]
setblock 527 193 266 minecraft:light[level=12]
setblock 528 193 231 minecraft:light[level=11]
setblock 528 193 239 minecraft:light[level=11]
setblock 528 193 247 minecraft:light[level=11]
setblock 528 193 255 minecraft:light[level=11]
setblock 528 193 263 minecraft:light[level=11]
fill 529 193 228 529 195 228 minecraft:purple_terracotta
fill 529 193 230 530 193 230 minecraft:spruce_planks
fill 529 193 270 529 195 270 minecraft:purple_terracotta
fill 531 193 229 532 193 230 minecraft:dark_oak_planks
fill 533 193 228 533 195 228 minecraft:purple_terracotta
fill 533 193 270 533 195 270 minecraft:purple_terracotta
setblock 534 193 231 minecraft:light[level=12]
setblock 534 193 238 minecraft:light[level=12]
setblock 534 193 245 minecraft:light[level=12]
setblock 534 193 252 minecraft:light[level=12]
setblock 534 193 259 minecraft:light[level=12]
setblock 534 193 266 minecraft:light[level=12]
setblock 536 193 231 minecraft:light[level=11]
setblock 536 193 239 minecraft:light[level=11]
setblock 536 193 247 minecraft:light[level=11]
setblock 536 193 255 minecraft:light[level=11]
setblock 536 193 263 minecraft:light[level=11]
fill 537 193 228 537 195 228 minecraft:purple_terracotta
fill 537 193 270 537 195 270 minecraft:purple_terracotta
fill 541 193 228 541 195 228 minecraft:purple_terracotta
setblock 541 193 231 minecraft:light[level=12]
setblock 541 193 238 minecraft:light[level=12]
setblock 541 193 245 minecraft:light[level=12]
setblock 541 193 252 minecraft:light[level=12]
setblock 541 193 259 minecraft:light[level=12]
setblock 541 193 266 minecraft:light[level=12]
fill 541 193 270 541 195 270 minecraft:purple_terracotta
setblock 544 193 231 minecraft:light[level=11]
setblock 544 193 239 minecraft:light[level=11]
setblock 544 193 247 minecraft:light[level=11]
setblock 544 193 255 minecraft:light[level=11]
setblock 544 193 263 minecraft:light[level=11]
fill 545 193 228 545 195 228 minecraft:purple_terracotta
fill 545 193 270 545 195 270 minecraft:purple_terracotta
setblock 548 193 231 minecraft:light[level=12]
setblock 548 193 238 minecraft:light[level=12]
setblock 548 193 245 minecraft:light[level=12]
setblock 548 193 252 minecraft:light[level=12]
setblock 548 193 259 minecraft:light[level=12]
setblock 548 193 266 minecraft:light[level=12]
fill 549 193 228 549 195 228 minecraft:purple_terracotta
fill 549 193 270 549 195 270 minecraft:purple_terracotta
setblock 552 193 231 minecraft:light[level=11]
setblock 552 193 239 minecraft:light[level=11]
setblock 552 193 247 minecraft:light[level=11]
setblock 552 193 255 minecraft:light[level=11]
setblock 552 193 263 minecraft:light[level=11]
fill 553 193 228 553 195 228 minecraft:purple_terracotta
fill 553 193 270 553 195 270 minecraft:purple_terracotta
setblock 555 193 231 minecraft:light[level=12]
setblock 555 193 238 minecraft:light[level=12]
setblock 555 193 245 minecraft:light[level=12]
setblock 555 193 252 minecraft:light[level=12]
setblock 555 193 259 minecraft:light[level=12]
setblock 555 193 266 minecraft:light[level=12]
fill 557 193 228 557 195 228 minecraft:purple_terracotta
fill 557 193 270 557 195 270 minecraft:purple_terracotta
setblock 559 193 228 minecraft:purple_terracotta
fill 559 193 232 559 195 232 minecraft:purple_terracotta
setblock 559 193 234 minecraft:purple_terracotta
fill 559 193 236 559 195 236 minecraft:purple_terracotta
fill 559 193 240 559 195 240 minecraft:purple_terracotta
fill 559 193 244 559 195 244 minecraft:purple_terracotta
fill 559 193 248 559 195 248 minecraft:purple_terracotta
fill 559 193 252 559 195 252 minecraft:purple_terracotta
fill 559 193 256 559 195 256 minecraft:purple_terracotta
fill 559 193 260 559 195 260 minecraft:purple_terracotta
fill 559 193 264 559 195 264 minecraft:purple_terracotta
fill 559 193 268 559 195 268 minecraft:purple_terracotta
setblock 517 194 230 minecraft:magenta_terracotta
setblock 517 194 234 minecraft:magenta_terracotta
fill 517 194 237 517 207 237 minecraft:purple_terracotta
setblock 517 194 238 minecraft:magenta_terracotta
setblock 517 194 242 minecraft:magenta_terracotta
setblock 517 194 246 minecraft:magenta_terracotta
setblock 517 194 250 minecraft:magenta_terracotta
setblock 517 194 254 minecraft:magenta_terracotta
setblock 517 194 258 minecraft:magenta_terracotta
setblock 517 194 262 minecraft:magenta_terracotta
setblock 517 194 266 minecraft:magenta_terracotta
setblock 517 194 270 minecraft:magenta_terracotta
setblock 519 194 228 minecraft:magenta_terracotta
setblock 519 194 270 minecraft:magenta_terracotta
setblock 523 194 228 minecraft:magenta_terracotta
setblock 523 194 270 minecraft:magenta_terracotta
fill 526 194 270 526 207 270 minecraft:purple_terracotta
setblock 527 194 228 minecraft:magenta_terracotta
fill 527 194 230 528 194 230 minecraft:spruce_planks
setblock 527 194 270 minecraft:magenta_terracotta
fill 529 194 229 530 194 230 minecraft:dark_oak_planks
setblock 531 194 228 minecraft:magenta_terracotta
setblock 531 194 270 minecraft:magenta_terracotta
setblock 535 194 228 minecraft:magenta_terracotta
setblock 535 194 270 minecraft:magenta_terracotta
setblock 539 194 228 minecraft:magenta_terracotta
setblock 539 194 270 minecraft:magenta_terracotta
setblock 543 194 228 minecraft:magenta_terracotta
setblock 543 194 270 minecraft:magenta_terracotta
setblock 547 194 228 minecraft:magenta_terracotta
setblock 547 194 270 minecraft:magenta_terracotta
setblock 551 194 228 minecraft:magenta_terracotta
setblock 551 194 270 minecraft:magenta_terracotta
setblock 555 194 228 minecraft:magenta_terracotta
setblock 555 194 270 minecraft:magenta_terracotta
setblock 559 194 228 minecraft:magenta_terracotta
setblock 559 194 230 minecraft:magenta_terracotta
setblock 559 194 234 minecraft:magenta_terracotta
setblock 559 194 238 minecraft:magenta_terracotta
setblock 559 194 242 minecraft:magenta_terracotta
setblock 559 194 246 minecraft:magenta_terracotta
setblock 559 194 250 minecraft:magenta_terracotta
setblock 559 194 254 minecraft:magenta_terracotta
setblock 559 194 258 minecraft:magenta_terracotta
setblock 559 194 262 minecraft:magenta_terracotta
setblock 559 194 266 minecraft:magenta_terracotta
setblock 559 194 270 minecraft:magenta_terracotta
fill 517 195 230 517 197 230 minecraft:purple_terracotta
fill 517 195 234 517 197 234 minecraft:purple_terracotta
fill 517 195 238 517 197 238 minecraft:purple_terracotta
fill 517 195 242 517 197 242 minecraft:purple_terracotta
fill 517 195 246 517 197 246 minecraft:purple_terracotta
fill 517 195 250 517 197 250 minecraft:purple_terracotta
fill 517 195 254 517 197 254 minecraft:purple_terracotta
fill 517 195 258 517 197 258 minecraft:purple_terracotta
fill 517 195 262 517 197 262 minecraft:purple_terracotta
fill 517 195 266 517 197 266 minecraft:purple_terracotta
setblock 517 195 270 minecraft:purple_terracotta
fill 519 195 228 519 197 228 minecraft:purple_terracotta
fill 519 195 270 519 197 270 minecraft:purple_terracotta
fill 523 195 228 523 197 228 minecraft:purple_terracotta
fill 523 195 270 523 197 270 minecraft:purple_terracotta
fill 525 195 230 526 195 230 minecraft:spruce_planks
fill 527 195 228 527 197 228 minecraft:purple_terracotta
fill 527 195 229 528 196 230 minecraft:dark_oak_planks
fill 527 195 270 527 197 270 minecraft:purple_terracotta
fill 531 195 228 531 197 228 minecraft:purple_terracotta
fill 531 195 270 531 197 270 minecraft:purple_terracotta
fill 535 195 228 535 197 228 minecraft:purple_terracotta
fill 535 195 270 535 197 270 minecraft:purple_terracotta
fill 539 195 228 539 197 228 minecraft:purple_terracotta
fill 539 195 270 539 197 270 minecraft:purple_terracotta
fill 543 195 228 543 197 228 minecraft:purple_terracotta
fill 543 195 270 543 197 270 minecraft:purple_terracotta
fill 547 195 228 547 197 228 minecraft:purple_terracotta
fill 547 195 270 547 197 270 minecraft:purple_terracotta
fill 551 195 228 551 197 228 minecraft:purple_terracotta
fill 551 195 270 551 197 270 minecraft:purple_terracotta
fill 555 195 228 555 197 228 minecraft:purple_terracotta
fill 555 195 270 555 197 270 minecraft:purple_terracotta
setblock 559 195 228 minecraft:purple_terracotta
fill 559 195 230 559 197 230 minecraft:purple_terracotta
fill 559 195 234 559 197 234 minecraft:purple_terracotta
fill 559 195 238 559 197 238 minecraft:purple_terracotta
fill 559 195 242 559 197 242 minecraft:purple_terracotta
fill 559 195 246 559 197 246 minecraft:purple_terracotta
fill 559 195 250 559 197 250 minecraft:purple_terracotta
fill 559 195 254 559 197 254 minecraft:purple_terracotta
fill 559 195 258 559 197 258 minecraft:purple_terracotta
fill 559 195 262 559 197 262 minecraft:purple_terracotta
fill 559 195 266 559 197 266 minecraft:purple_terracotta
fill 559 195 270 559 197 270 minecraft:purple_terracotta
setblock 517 196 228 minecraft:magenta_terracotta
setblock 517 196 232 minecraft:magenta_terracotta
setblock 517 196 236 minecraft:magenta_terracotta
setblock 517 196 240 minecraft:magenta_terracotta
setblock 517 196 244 minecraft:magenta_terracotta
setblock 517 196 248 minecraft:magenta_terracotta
setblock 517 196 252 minecraft:magenta_terracotta
setblock 517 196 256 minecraft:magenta_terracotta
setblock 517 196 260 minecraft:magenta_terracotta
setblock 517 196 264 minecraft:magenta_terracotta
setblock 517 196 268 minecraft:magenta_terracotta
setblock 517 196 270 minecraft:magenta_terracotta
setblock 521 196 228 minecraft:magenta_terracotta
setblock 521 196 270 minecraft:magenta_terracotta
fill 522 196 229 522 196 232 minecraft:dark_oak_planks
fill 523 196 229 526 196 229 minecraft:dark_oak_planks
fill 523 196 230 524 196 230 minecraft:spruce_planks
fill 523 196 231 532 196 232 minecraft:dark_oak_planks
setblock 525 196 228 minecraft:magenta_terracotta
fill 525 196 230 526 196 230 minecraft:dark_oak_planks
setblock 525 196 270 minecraft:magenta_terracotta
setblock 529 196 228 minecraft:magenta_terracotta
fill 529 196 229 532 196 230 minecraft:dark_oak_planks
setblock 529 196 270 minecraft:magenta_terracotta
setblock 533 196 228 minecraft:magenta_terracotta
setblock 533 196 270 minecraft:magenta_terracotta
setblock 536 196 228 minecraft:gray_terracotta
setblock 537 196 228 minecraft:magenta_terracotta
setblock 537 196 270 minecraft:magenta_terracotta
setblock 541 196 228 minecraft:magenta_terracotta
setblock 541 196 270 minecraft:magenta_terracotta
setblock 545 196 228 minecraft:magenta_terracotta
setblock 545 196 270 minecraft:magenta_terracotta
setblock 549 196 228 minecraft:magenta_terracotta
setblock 549 196 270 minecraft:magenta_terracotta
setblock 553 196 228 minecraft:magenta_terracotta
setblock 553 196 270 minecraft:magenta_terracotta
setblock 557 196 228 minecraft:magenta_terracotta
setblock 557 196 270 minecraft:magenta_terracotta
setblock 559 196 228 minecraft:magenta_terracotta
setblock 559 196 232 minecraft:magenta_terracotta
setblock 559 196 236 minecraft:magenta_terracotta
setblock 559 196 240 minecraft:magenta_terracotta
setblock 559 196 244 minecraft:magenta_terracotta
setblock 559 196 248 minecraft:magenta_terracotta
setblock 559 196 252 minecraft:magenta_terracotta
setblock 559 196 256 minecraft:magenta_terracotta
setblock 559 196 260 minecraft:magenta_terracotta
setblock 559 196 264 minecraft:magenta_terracotta
setblock 559 196 268 minecraft:magenta_terracotta
fill 517 197 228 517 199 228 minecraft:purple_terracotta
fill 517 197 232 517 199 232 minecraft:purple_terracotta
fill 517 197 236 517 199 236 minecraft:purple_terracotta
fill 517 197 240 517 199 240 minecraft:purple_terracotta
fill 517 197 244 517 199 244 minecraft:purple_terracotta
fill 517 197 248 517 199 248 minecraft:purple_terracotta
fill 517 197 252 517 199 252 minecraft:purple_terracotta
fill 517 197 256 517 199 256 minecraft:purple_terracotta
fill 517 197 260 517 199 260 minecraft:purple_terracotta
fill 517 197 264 517 199 264 minecraft:purple_terracotta
fill 517 197 268 517 199 268 minecraft:purple_terracotta
setblock 517 197 270 minecraft:purple_terracotta
fill 521 197 228 521 199 228 minecraft:purple_terracotta
fill 521 197 230 522 197 230 minecraft:spruce_planks
fill 521 197 270 521 199 270 minecraft:purple_terracotta
setblock 522 197 229 minecraft:stripped_dark_oak_log
fill 522 197 231 532 197 232 minecraft:stripped_dark_oak_log
fill 523 197 229 524 197 230 minecraft:dark_oak_planks
fill 525 197 228 525 199 228 minecraft:purple_terracotta
fill 525 197 229 532 197 230 minecraft:stripped_dark_oak_log
fill 525 197 270 525 199 270 minecraft:purple_terracotta
fill 529 197 228 529 199 228 minecraft:purple_terracotta
fill 529 197 270 529 199 270 minecraft:purple_terracotta
fill 533 197 228 533 199 228 minecraft:purple_terracotta
fill 533 197 270 533 199 270 minecraft:purple_terracotta
fill 536 197 228 537 199 228 minecraft:purple_terracotta
fill 537 197 270 537 199 270 minecraft:purple_terracotta
fill 541 197 228 541 199 228 minecraft:purple_terracotta
fill 541 197 270 541 199 270 minecraft:purple_terracotta
fill 545 197 228 545 199 228 minecraft:purple_terracotta
fill 545 197 270 545 199 270 minecraft:purple_terracotta
fill 549 197 228 549 199 228 minecraft:purple_terracotta
fill 549 197 270 549 199 270 minecraft:purple_terracotta
fill 553 197 228 553 199 228 minecraft:purple_terracotta
fill 553 197 270 553 199 270 minecraft:purple_terracotta
fill 557 197 228 557 199 228 minecraft:purple_terracotta
fill 557 197 270 557 199 270 minecraft:purple_terracotta
setblock 559 197 228 minecraft:purple_terracotta
fill 559 197 232 559 199 232 minecraft:purple_terracotta
fill 559 197 236 559 199 236 minecraft:purple_terracotta
fill 559 197 240 559 199 240 minecraft:purple_terracotta
fill 559 197 244 559 199 244 minecraft:purple_terracotta
fill 559 197 248 559 199 248 minecraft:purple_terracotta
fill 559 197 252 559 199 252 minecraft:purple_terracotta
fill 559 197 256 559 199 256 minecraft:purple_terracotta
fill 559 197 260 559 199 260 minecraft:purple_terracotta
fill 559 197 264 559 199 264 minecraft:purple_terracotta
fill 559 197 268 559 199 268 minecraft:purple_terracotta
setblock 517 198 230 minecraft:magenta_terracotta
setblock 517 198 234 minecraft:magenta_terracotta
setblock 517 198 238 minecraft:magenta_terracotta
setblock 517 198 242 minecraft:magenta_terracotta
setblock 517 198 246 minecraft:magenta_terracotta
setblock 517 198 250 minecraft:magenta_terracotta
setblock 517 198 254 minecraft:magenta_terracotta
setblock 517 198 258 minecraft:magenta_terracotta
setblock 517 198 262 minecraft:magenta_terracotta
setblock 517 198 266 minecraft:magenta_terracotta
setblock 517 198 270 minecraft:magenta_terracotta
setblock 519 198 228 minecraft:magenta_terracotta
fill 519 198 230 520 198 230 minecraft:spruce_planks
setblock 519 198 270 minecraft:magenta_terracotta
fill 521 198 229 522 198 230 minecraft:dark_oak_planks
fill 522 198 232 532 198 232 minecraft:purple_concrete
setblock 523 198 228 minecraft:magenta_terracotta
setblock 523 198 270 minecraft:magenta_terracotta
fill 526 198 228 528 201 228 minecraft:jack_o_lantern
setblock 527 198 270 minecraft:magenta_terracotta
setblock 531 198 228 minecraft:magenta_terracotta
setblock 531 198 270 minecraft:magenta_terracotta
setblock 535 198 228 minecraft:magenta_terracotta
setblock 535 198 270 minecraft:magenta_terracotta
setblock 539 198 228 minecraft:magenta_terracotta
setblock 539 198 270 minecraft:magenta_terracotta
setblock 543 198 228 minecraft:magenta_terracotta
setblock 543 198 270 minecraft:magenta_terracotta
setblock 547 198 228 minecraft:magenta_terracotta
setblock 547 198 270 minecraft:magenta_terracotta
setblock 551 198 228 minecraft:magenta_terracotta
setblock 551 198 270 minecraft:magenta_terracotta
setblock 555 198 228 minecraft:magenta_terracotta
setblock 555 198 270 minecraft:magenta_terracotta
setblock 559 198 228 minecraft:magenta_terracotta
setblock 559 198 230 minecraft:magenta_terracotta
setblock 559 198 234 minecraft:magenta_terracotta
setblock 559 198 238 minecraft:magenta_terracotta
setblock 559 198 242 minecraft:magenta_terracotta
setblock 559 198 246 minecraft:magenta_terracotta
setblock 559 198 250 minecraft:magenta_terracotta
setblock 559 198 254 minecraft:magenta_terracotta
setblock 559 198 258 minecraft:magenta_terracotta
setblock 559 198 262 minecraft:magenta_terracotta
setblock 559 198 266 minecraft:magenta_terracotta
setblock 559 198 270 minecraft:magenta_terracotta
fill 517 199 230 517 201 230 minecraft:purple_terracotta
fill 517 199 234 517 201 234 minecraft:purple_terracotta
fill 517 199 238 517 201 238 minecraft:purple_terracotta
fill 517 199 242 517 201 242 minecraft:purple_terracotta
fill 517 199 246 517 201 246 minecraft:purple_terracotta
fill 517 199 250 517 201 250 minecraft:purple_terracotta
fill 517 199 254 517 201 254 minecraft:purple_terracotta
fill 517 199 258 517 201 258 minecraft:purple_terracotta
fill 517 199 262 517 201 262 minecraft:purple_terracotta
fill 517 199 266 517 201 266 minecraft:purple_terracotta
setblock 517 199 270 minecraft:purple_terracotta
fill 518 199 229 520 199 230 minecraft:dark_oak_planks
fill 519 199 228 519 201 228 minecraft:purple_terracotta
setblock 519 199 231 minecraft:spruce_planks
fill 519 199 270 519 201 270 minecraft:purple_terracotta
setblock 520 199 231 minecraft:light[level=12]
setblock 520 199 238 minecraft:light[level=12]
setblock 520 199 245 minecraft:light[level=12]
setblock 520 199 252 minecraft:light[level=12]
setblock 520 199 259 minecraft:light[level=12]
setblock 520 199 266 minecraft:light[level=12]
setblock 522 199 232 minecraft:stripped_dark_oak_log
fill 523 199 228 523 201 228 minecraft:purple_terracotta
fill 523 199 270 523 201 270 minecraft:purple_terracotta
setblock 527 199 231 minecraft:light[level=12]
setblock 527 199 232 minecraft:stripped_dark_oak_log
setblock 527 199 238 minecraft:light[level=12]
setblock 527 199 245 minecraft:light[level=12]
setblock 527 199 252 minecraft:light[level=12]
setblock 527 199 259 minecraft:light[level=12]
setblock 527 199 266 minecraft:light[level=12]
fill 527 199 270 527 201 270 minecraft:purple_terracotta
fill 531 199 228 531 201 228 minecraft:purple_terracotta
fill 531 199 270 531 201 270 minecraft:purple_terracotta
setblock 532 199 232 minecraft:stripped_dark_oak_log
setblock 534 199 231 minecraft:light[level=12]
setblock 534 199 238 minecraft:light[level=12]
setblock 534 199 245 minecraft:light[level=12]
setblock 534 199 252 minecraft:light[level=12]
setblock 534 199 259 minecraft:light[level=12]
setblock 534 199 266 minecraft:light[level=12]
fill 535 199 228 535 201 228 minecraft:purple_terracotta
fill 535 199 270 535 201 270 minecraft:purple_terracotta
setblock 536 199 270 minecraft:gray_terracotta
fill 539 199 228 539 201 228 minecraft:purple_terracotta
fill 539 199 270 539 201 270 minecraft:purple_terracotta
setblock 541 199 231 minecraft:light[level=12]
setblock 541 199 238 minecraft:light[level=12]
setblock 541 199 245 minecraft:light[level=12]
setblock 541 199 252 minecraft:light[level=12]
setblock 541 199 259 minecraft:light[level=12]
setblock 541 199 266 minecraft:light[level=12]
fill 543 199 228 543 201 228 minecraft:purple_terracotta
fill 543 199 270 543 201 270 minecraft:purple_terracotta
fill 547 199 228 547 201 228 minecraft:purple_terracotta
fill 547 199 270 547 201 270 minecraft:purple_terracotta
setblock 548 199 231 minecraft:light[level=12]
setblock 548 199 238 minecraft:light[level=12]
setblock 548 199 245 minecraft:light[level=12]
setblock 548 199 252 minecraft:light[level=12]
setblock 548 199 259 minecraft:light[level=12]
setblock 548 199 266 minecraft:light[level=12]
fill 551 199 228 551 201 228 minecraft:purple_terracotta
fill 551 199 270 551 201 270 minecraft:purple_terracotta
fill 555 199 228 555 201 228 minecraft:purple_terracotta
setblock 555 199 231 minecraft:light[level=12]
setblock 555 199 238 minecraft:light[level=12]
setblock 555 199 245 minecraft:light[level=12]
setblock 555 199 252 minecraft:light[level=12]
setblock 555 199 259 minecraft:light[level=12]
setblock 555 199 266 minecraft:light[level=12]
fill 555 199 270 555 201 270 minecraft:purple_terracotta
setblock 559 199 228 minecraft:purple_terracotta
fill 559 199 230 559 201 230 minecraft:purple_terracotta
fill 559 199 234 559 201 234 minecraft:purple_terracotta
fill 559 199 238 559 201 238 minecraft:purple_terracotta
fill 559 199 242 559 201 242 minecraft:purple_terracotta
fill 559 199 246 559 201 246 minecraft:purple_terracotta
fill 559 199 250 559 201 250 minecraft:purple_terracotta
fill 559 199 254 559 201 254 minecraft:purple_terracotta
fill 559 199 258 559 201 258 minecraft:purple_terracotta
fill 559 199 262 559 201 262 minecraft:purple_terracotta
fill 559 199 266 559 201 266 minecraft:purple_terracotta
fill 559 199 270 559 201 270 minecraft:purple_terracotta
setblock 517 200 228 minecraft:magenta_terracotta
setblock 517 200 232 minecraft:magenta_terracotta
setblock 517 200 236 minecraft:magenta_terracotta
setblock 517 200 240 minecraft:magenta_terracotta
setblock 517 200 244 minecraft:magenta_terracotta
setblock 517 200 248 minecraft:magenta_terracotta
setblock 517 200 252 minecraft:magenta_terracotta
setblock 517 200 256 minecraft:magenta_terracotta
setblock 517 200 260 minecraft:magenta_terracotta
setblock 517 200 264 minecraft:magenta_terracotta
setblock 517 200 268 minecraft:magenta_terracotta
setblock 517 200 270 minecraft:magenta_terracotta
fill 518 200 229 519 200 231 minecraft:dark_oak_planks
fill 519 200 232 519 200 233 minecraft:spruce_planks
setblock 521 200 228 minecraft:magenta_terracotta
setblock 521 200 270 minecraft:magenta_terracotta
setblock 525 200 228 minecraft:magenta_terracotta
setblock 525 200 270 minecraft:magenta_terracotta
setblock 529 200 228 minecraft:magenta_terracotta
setblock 529 200 270 minecraft:magenta_terracotta
setblock 533 200 228 minecraft:magenta_terracotta
setblock 533 200 270 minecraft:magenta_terracotta
fill 536 200 228 536 207 228 minecraft:purple_terracotta
fill 536 200 270 536 207 270 minecraft:purple_terracotta
setblock 537 200 228 minecraft:magenta_terracotta
setblock 537 200 270 minecraft:magenta_terracotta
setblock 541 200 228 minecraft:magenta_terracotta
setblock 541 200 270 minecraft:magenta_terracotta
setblock 545 200 228 minecraft:magenta_terracotta
setblock 545 200 270 minecraft:magenta_terracotta
setblock 549 200 228 minecraft:magenta_terracotta
setblock 549 200 270 minecraft:magenta_terracotta
setblock 553 200 228 minecraft:magenta_terracotta
setblock 553 200 270 minecraft:magenta_terracotta
setblock 557 200 228 minecraft:magenta_terracotta
setblock 557 200 270 minecraft:magenta_terracotta
setblock 559 200 228 minecraft:magenta_terracotta
setblock 559 200 232 minecraft:magenta_terracotta
setblock 559 200 236 minecraft:magenta_terracotta
setblock 559 200 240 minecraft:magenta_terracotta
setblock 559 200 244 minecraft:magenta_terracotta
setblock 559 200 248 minecraft:magenta_terracotta
setblock 559 200 252 minecraft:magenta_terracotta
setblock 559 200 256 minecraft:magenta_terracotta
setblock 559 200 260 minecraft:magenta_terracotta
setblock 559 200 264 minecraft:magenta_terracotta
setblock 559 200 268 minecraft:magenta_terracotta
fill 517 201 228 517 203 228 minecraft:purple_terracotta
fill 517 201 232 517 203 232 minecraft:purple_terracotta
fill 517 201 236 517 203 236 minecraft:purple_terracotta
fill 517 201 240 517 203 240 minecraft:purple_terracotta
fill 517 201 244 517 203 244 minecraft:purple_terracotta
fill 517 201 248 517 203 248 minecraft:purple_terracotta
fill 517 201 252 517 203 252 minecraft:purple_terracotta
fill 517 201 256 517 203 256 minecraft:purple_terracotta
fill 517 201 260 517 203 260 minecraft:purple_terracotta
fill 517 201 264 517 203 264 minecraft:purple_terracotta
fill 517 201 268 517 203 268 minecraft:purple_terracotta
setblock 517 201 270 minecraft:purple_terracotta
fill 518 201 232 519 201 233 minecraft:dark_oak_planks
fill 519 201 234 519 201 235 minecraft:spruce_planks
setblock 520 201 231 minecraft:light[level=11]
setblock 520 201 239 minecraft:light[level=11]
setblock 520 201 247 minecraft:light[level=11]
setblock 520 201 255 minecraft:light[level=11]
setblock 520 201 263 minecraft:light[level=11]
fill 521 201 228 521 203 228 minecraft:purple_terracotta
fill 521 201 270 521 203 270 minecraft:purple_terracotta
fill 525 201 228 525 203 228 minecraft:purple_terracotta
fill 525 201 270 525 203 270 minecraft:purple_terracotta
setblock 528 201 231 minecraft:light[level=11]
setblock 528 201 239 minecraft:light[level=11]
setblock 528 201 247 minecraft:light[level=11]
setblock 528 201 255 minecraft:light[level=11]
setblock 528 201 263 minecraft:light[level=11]
fill 529 201 228 529 203 228 minecraft:purple_terracotta
fill 529 201 270 529 203 270 minecraft:purple_terracotta
fill 533 201 228 533 203 228 minecraft:purple_terracotta
fill 533 201 270 533 203 270 minecraft:purple_terracotta
setblock 536 201 231 minecraft:light[level=11]
setblock 536 201 239 minecraft:light[level=11]
setblock 536 201 247 minecraft:light[level=11]
setblock 536 201 255 minecraft:light[level=11]
setblock 536 201 263 minecraft:light[level=11]
fill 537 201 228 537 203 228 minecraft:purple_terracotta
fill 537 201 270 537 203 270 minecraft:purple_terracotta
fill 541 201 228 541 203 228 minecraft:purple_terracotta
fill 541 201 270 541 203 270 minecraft:purple_terracotta
setblock 544 201 231 minecraft:light[level=11]
setblock 544 201 239 minecraft:light[level=11]
setblock 544 201 247 minecraft:light[level=11]
setblock 544 201 255 minecraft:light[level=11]
setblock 544 201 263 minecraft:light[level=11]
fill 545 201 228 545 203 228 minecraft:purple_terracotta
fill 545 201 270 545 203 270 minecraft:purple_terracotta
fill 549 201 228 549 203 228 minecraft:purple_terracotta
fill 549 201 270 549 203 270 minecraft:purple_terracotta
setblock 552 201 231 minecraft:light[level=11]
setblock 552 201 239 minecraft:light[level=11]
setblock 552 201 247 minecraft:light[level=11]
setblock 552 201 255 minecraft:light[level=11]
setblock 552 201 263 minecraft:light[level=11]
fill 553 201 228 553 203 228 minecraft:purple_terracotta
fill 553 201 270 553 203 270 minecraft:purple_terracotta
fill 557 201 228 557 203 228 minecraft:purple_terracotta
fill 557 201 270 557 203 270 minecraft:purple_terracotta
setblock 559 201 228 minecraft:purple_terracotta
fill 559 201 232 559 203 232 minecraft:purple_terracotta
fill 559 201 236 559 203 236 minecraft:purple_terracotta
fill 559 201 240 559 203 240 minecraft:purple_terracotta
fill 559 201 244 559 203 244 minecraft:purple_terracotta
setblock 559 201 248 minecraft:black_terracotta
fill 559 201 252 559 203 252 minecraft:purple_terracotta
fill 559 201 256 559 203 256 minecraft:purple_terracotta
fill 559 201 260 559 203 260 minecraft:purple_terracotta
fill 559 201 264 559 203 264 minecraft:purple_terracotta
fill 559 201 268 559 203 268 minecraft:purple_terracotta
setblock 517 202 230 minecraft:magenta_terracotta
setblock 517 202 234 minecraft:magenta_terracotta
setblock 517 202 238 minecraft:magenta_terracotta
setblock 517 202 242 minecraft:magenta_terracotta
setblock 517 202 246 minecraft:magenta_terracotta
setblock 517 202 250 minecraft:magenta_terracotta
setblock 517 202 254 minecraft:magenta_terracotta
setblock 517 202 258 minecraft:magenta_terracotta
setblock 517 202 262 minecraft:magenta_terracotta
setblock 517 202 266 minecraft:magenta_terracotta
setblock 517 202 270 minecraft:magenta_terracotta
fill 518 202 234 519 202 235 minecraft:dark_oak_planks
setblock 519 202 228 minecraft:magenta_terracotta
fill 519 202 236 519 202 237 minecraft:spruce_planks
setblock 519 202 270 minecraft:magenta_terracotta
setblock 523 202 228 minecraft:magenta_terracotta
setblock 523 202 270 minecraft:magenta_terracotta
fill 526 202 228 526 207 228 minecraft:purple_terracotta
setblock 527 202 228 minecraft:magenta_terracotta
setblock 527 202 270 minecraft:magenta_terracotta
fill 528 202 228 528 207 228 minecraft:purple_terracotta
setblock 531 202 228 minecraft:magenta_terracotta
setblock 531 202 270 minecraft:magenta_terracotta
setblock 535 202 228 minecraft:magenta_terracotta
setblock 535 202 270 minecraft:magenta_terracotta
setblock 539 202 228 minecraft:magenta_terracotta
setblock 539 202 270 minecraft:magenta_terracotta
setblock 543 202 228 minecraft:magenta_terracotta
setblock 543 202 270 minecraft:magenta_terracotta
setblock 547 202 228 minecraft:magenta_terracotta
setblock 547 202 270 minecraft:magenta_terracotta
setblock 551 202 228 minecraft:magenta_terracotta
setblock 551 202 270 minecraft:magenta_terracotta
setblock 555 202 228 minecraft:magenta_terracotta
setblock 555 202 270 minecraft:magenta_terracotta
setblock 559 202 228 minecraft:magenta_terracotta
setblock 559 202 230 minecraft:magenta_terracotta
setblock 559 202 234 minecraft:magenta_terracotta
setblock 559 202 238 minecraft:magenta_terracotta
setblock 559 202 242 minecraft:magenta_terracotta
setblock 559 202 246 minecraft:magenta_terracotta
fill 559 202 248 559 203 248 minecraft:purple_terracotta
setblock 559 202 250 minecraft:magenta_terracotta
setblock 559 202 254 minecraft:magenta_terracotta
setblock 559 202 258 minecraft:magenta_terracotta
setblock 559 202 262 minecraft:magenta_terracotta
setblock 559 202 266 minecraft:magenta_terracotta
setblock 559 202 270 minecraft:magenta_terracotta
fill 517 203 230 517 205 230 minecraft:purple_terracotta
fill 517 203 234 517 205 234 minecraft:purple_terracotta
fill 517 203 238 517 205 238 minecraft:purple_terracotta
fill 517 203 242 517 205 242 minecraft:purple_terracotta
fill 517 203 246 517 205 246 minecraft:purple_terracotta
fill 517 203 250 517 205 250 minecraft:purple_terracotta
fill 517 203 254 517 205 254 minecraft:purple_terracotta
fill 517 203 258 517 205 258 minecraft:purple_terracotta
fill 517 203 262 517 205 262 minecraft:purple_terracotta
fill 517 203 266 517 205 266 minecraft:purple_terracotta
setblock 517 203 270 minecraft:purple_terracotta
fill 518 203 236 519 203 237 minecraft:dark_oak_planks
fill 518 203 250 518 203 254 minecraft:gold_block
fill 519 203 228 519 205 228 minecraft:purple_terracotta
fill 519 203 238 519 203 239 minecraft:spruce_planks
fill 519 203 270 519 205 270 minecraft:purple_terracotta
fill 523 203 228 523 205 228 minecraft:purple_terracotta
fill 523 203 270 523 205 270 minecraft:purple_terracotta
fill 527 203 228 527 205 228 minecraft:purple_terracotta
fill 527 203 270 527 205 270 minecraft:purple_terracotta
fill 531 203 228 531 205 228 minecraft:purple_terracotta
fill 531 203 270 531 205 270 minecraft:purple_terracotta
fill 535 203 228 535 205 228 minecraft:purple_terracotta
fill 535 203 270 535 205 270 minecraft:purple_terracotta
fill 539 203 228 539 205 228 minecraft:purple_terracotta
fill 539 203 270 539 205 270 minecraft:purple_terracotta
setblock 542 203 228 minecraft:gray_terracotta
fill 543 203 228 543 205 228 minecraft:purple_terracotta
fill 543 203 270 543 205 270 minecraft:purple_terracotta
fill 547 203 228 547 205 228 minecraft:purple_terracotta
fill 547 203 270 547 205 270 minecraft:purple_terracotta
fill 551 203 228 551 205 228 minecraft:purple_terracotta
fill 551 203 270 551 205 270 minecraft:purple_terracotta
fill 555 203 228 555 205 228 minecraft:purple_terracotta
fill 555 203 270 555 205 270 minecraft:purple_terracotta
setblock 559 203 228 minecraft:purple_terracotta
fill 559 203 230 559 205 230 minecraft:purple_terracotta
fill 559 203 234 559 205 234 minecraft:purple_terracotta
fill 559 203 238 559 205 238 minecraft:purple_terracotta
fill 559 203 242 559 205 242 minecraft:purple_terracotta
fill 559 203 246 559 205 246 minecraft:purple_terracotta
fill 559 203 250 559 205 250 minecraft:purple_terracotta
fill 559 203 254 559 205 254 minecraft:purple_terracotta
fill 559 203 258 559 205 258 minecraft:purple_terracotta
fill 559 203 262 559 205 262 minecraft:purple_terracotta
fill 559 203 266 559 205 266 minecraft:purple_terracotta
fill 559 203 270 559 205 270 minecraft:purple_terracotta
setblock 517 204 228 minecraft:magenta_terracotta
setblock 517 204 232 minecraft:magenta_terracotta
setblock 517 204 236 minecraft:magenta_terracotta
setblock 517 204 240 minecraft:magenta_terracotta
setblock 517 204 244 minecraft:magenta_terracotta
setblock 517 204 248 minecraft:magenta_terracotta
setblock 517 204 252 minecraft:magenta_terracotta
setblock 517 204 256 minecraft:magenta_terracotta
setblock 517 204 260 minecraft:magenta_terracotta
setblock 517 204 264 minecraft:magenta_terracotta
setblock 517 204 268 minecraft:magenta_terracotta
setblock 517 204 270 minecraft:magenta_terracotta
fill 518 204 238 519 204 239 minecraft:dark_oak_planks
fill 518 204 250 518 207 250 minecraft:gold_block
fill 518 204 251 518 205 253 minecraft:red_terracotta
fill 518 204 254 518 207 254 minecraft:gold_block
fill 519 204 240 519 204 241 minecraft:spruce_planks
setblock 521 204 228 minecraft:magenta_terracotta
setblock 521 204 270 minecraft:magenta_terracotta
setblock 525 204 228 minecraft:magenta_terracotta
setblock 525 204 270 minecraft:magenta_terracotta
setblock 529 204 228 minecraft:magenta_terracotta
setblock 529 204 270 minecraft:magenta_terracotta
setblock 533 204 228 minecraft:magenta_terracotta
setblock 533 204 270 minecraft:magenta_terracotta
setblock 537 204 228 minecraft:magenta_terracotta
setblock 537 204 270 minecraft:magenta_terracotta
setblock 541 204 228 minecraft:magenta_terracotta
setblock 541 204 270 minecraft:magenta_terracotta
fill 542 204 228 542 207 228 minecraft:purple_terracotta
setblock 544 204 270 minecraft:gray_terracotta
setblock 545 204 228 minecraft:magenta_terracotta
setblock 545 204 270 minecraft:magenta_terracotta
setblock 549 204 228 minecraft:magenta_terracotta
setblock 549 204 270 minecraft:magenta_terracotta
setblock 553 204 228 minecraft:magenta_terracotta
setblock 553 204 270 minecraft:magenta_terracotta
setblock 557 204 228 minecraft:magenta_terracotta
setblock 557 204 270 minecraft:magenta_terracotta
setblock 559 204 228 minecraft:magenta_terracotta
setblock 559 204 232 minecraft:magenta_terracotta
setblock 559 204 236 minecraft:magenta_terracotta
setblock 559 204 240 minecraft:magenta_terracotta
setblock 559 204 244 minecraft:magenta_terracotta
setblock 559 204 248 minecraft:magenta_terracotta
setblock 559 204 252 minecraft:magenta_terracotta
setblock 559 204 256 minecraft:magenta_terracotta
setblock 559 204 260 minecraft:magenta_terracotta
setblock 559 204 264 minecraft:magenta_terracotta
setblock 559 204 268 minecraft:magenta_terracotta
fill 517 205 228 517 207 228 minecraft:purple_terracotta
fill 517 205 232 517 207 232 minecraft:purple_terracotta
setblock 517 205 236 minecraft:light_gray_terracotta
fill 517 205 240 517 207 240 minecraft:purple_terracotta
fill 517 205 244 517 207 244 minecraft:purple_terracotta
fill 517 205 248 517 207 248 minecraft:purple_terracotta
fill 517 205 252 517 207 252 minecraft:purple_terracotta
fill 517 205 256 517 207 256 minecraft:purple_terracotta
fill 517 205 260 517 207 260 minecraft:purple_terracotta
fill 517 205 264 517 207 264 minecraft:purple_terracotta
fill 517 205 268 517 207 268 minecraft:purple_terracotta
setblock 517 205 270 minecraft:purple_terracotta
fill 518 205 240 519 205 241 minecraft:dark_oak_planks
fill 519 205 242 519 205 243 minecraft:spruce_planks
setblock 520 205 231 minecraft:light[level=12]
setblock 520 205 238 minecraft:light[level=12]
setblock 520 205 245 minecraft:light[level=12]
setblock 520 205 252 minecraft:light[level=12]
setblock 520 205 259 minecraft:light[level=12]
setblock 520 205 266 minecraft:light[level=12]
fill 521 205 228 521 207 228 minecraft:purple_terracotta
fill 521 205 270 521 207 270 minecraft:purple_terracotta
fill 525 205 228 525 207 228 minecraft:purple_terracotta
fill 525 205 270 525 207 270 minecraft:purple_terracotta
setblock 527 205 231 minecraft:light[level=12]
setblock 527 205 238 minecraft:light[level=12]
setblock 527 205 245 minecraft:light[level=12]
setblock 527 205 252 minecraft:light[level=12]
setblock 527 205 259 minecraft:light[level=12]
setblock 527 205 266 minecraft:light[level=12]
fill 529 205 228 529 207 228 minecraft:purple_terracotta
fill 529 205 270 529 207 270 minecraft:purple_terracotta
fill 533 205 228 533 207 228 minecraft:purple_terracotta
fill 533 205 270 533 207 270 minecraft:purple_terracotta
setblock 534 205 231 minecraft:light[level=12]
setblock 534 205 238 minecraft:light[level=12]
setblock 534 205 245 minecraft:light[level=12]
setblock 534 205 252 minecraft:light[level=12]
setblock 534 205 259 minecraft:light[level=12]
setblock 534 205 266 minecraft:light[level=12]
fill 537 205 228 537 207 228 minecraft:purple_terracotta
fill 537 205 270 537 207 270 minecraft:purple_terracotta
fill 541 205 228 541 207 228 minecraft:purple_terracotta
setblock 541 205 231 minecraft:light[level=12]
setblock 541 205 238 minecraft:light[level=12]
setblock 541 205 245 minecraft:light[level=12]
setblock 541 205 252 minecraft:light[level=12]
setblock 541 205 259 minecraft:light[level=12]
setblock 541 205 266 minecraft:light[level=12]
fill 541 205 270 541 207 270 minecraft:purple_terracotta
fill 544 205 270 545 207 270 minecraft:purple_terracotta
fill 545 205 228 545 207 228 minecraft:purple_terracotta
setblock 548 205 231 minecraft:light[level=12]
setblock 548 205 238 minecraft:light[level=12]
setblock 548 205 245 minecraft:light[level=12]
setblock 548 205 252 minecraft:light[level=12]
setblock 548 205 259 minecraft:light[level=12]
setblock 548 205 266 minecraft:light[level=12]
fill 549 205 228 549 207 228 minecraft:purple_terracotta
fill 549 205 270 549 207 270 minecraft:purple_terracotta
fill 553 205 228 553 207 228 minecraft:purple_terracotta
fill 553 205 270 553 207 270 minecraft:purple_terracotta
setblock 555 205 231 minecraft:light[level=12]
setblock 555 205 238 minecraft:light[level=12]
setblock 555 205 245 minecraft:light[level=12]
setblock 555 205 252 minecraft:light[level=12]
setblock 555 205 259 minecraft:light[level=12]
setblock 555 205 266 minecraft:light[level=12]
fill 557 205 228 557 207 228 minecraft:purple_terracotta
fill 557 205 270 557 207 270 minecraft:purple_terracotta
setblock 559 205 228 minecraft:purple_terracotta
fill 559 205 232 559 207 232 minecraft:purple_terracotta
fill 559 205 236 559 207 236 minecraft:purple_terracotta
fill 559 205 240 559 207 240 minecraft:purple_terracotta
fill 559 205 244 559 207 244 minecraft:purple_terracotta
fill 559 205 248 559 207 248 minecraft:purple_terracotta
fill 559 205 252 559 207 252 minecraft:purple_terracotta
fill 559 205 256 559 207 256 minecraft:purple_terracotta
fill 559 205 260 559 207 260 minecraft:purple_terracotta
fill 559 205 264 559 207 264 minecraft:purple_terracotta
fill 559 205 268 559 207 268 minecraft:purple_terracotta
setblock 517 206 230 minecraft:magenta_terracotta
setblock 517 206 234 minecraft:magenta_terracotta
fill 517 206 236 517 207 236 minecraft:purple_terracotta
setblock 517 206 238 minecraft:magenta_terracotta
setblock 517 206 242 minecraft:magenta_terracotta
setblock 517 206 246 minecraft:magenta_terracotta
setblock 517 206 250 minecraft:magenta_terracotta
setblock 517 206 254 minecraft:magenta_terracotta
setblock 517 206 258 minecraft:magenta_terracotta
setblock 517 206 262 minecraft:magenta_terracotta
setblock 517 206 266 minecraft:magenta_terracotta
setblock 517 206 270 minecraft:magenta_terracotta
fill 518 206 242 519 206 243 minecraft:dark_oak_planks
fill 518 206 251 518 206 253 minecraft:white_terracotta
setblock 519 206 228 minecraft:magenta_terracotta
fill 519 206 244 519 206 245 minecraft:spruce_planks
setblock 519 206 270 minecraft:magenta_terracotta
setblock 523 206 228 minecraft:magenta_terracotta
setblock 523 206 270 minecraft:magenta_terracotta
setblock 527 206 228 minecraft:magenta_terracotta
setblock 527 206 270 minecraft:magenta_terracotta
setblock 531 206 228 minecraft:magenta_terracotta
setblock 531 206 270 minecraft:magenta_terracotta
setblock 535 206 228 minecraft:magenta_terracotta
setblock 535 206 270 minecraft:magenta_terracotta
setblock 539 206 228 minecraft:magenta_terracotta
setblock 539 206 270 minecraft:magenta_terracotta
setblock 543 206 228 minecraft:magenta_terracotta
setblock 543 206 270 minecraft:magenta_terracotta
setblock 547 206 228 minecraft:magenta_terracotta
setblock 547 206 270 minecraft:magenta_terracotta
setblock 551 206 228 minecraft:magenta_terracotta
setblock 551 206 270 minecraft:magenta_terracotta
setblock 555 206 228 minecraft:magenta_terracotta
setblock 555 206 270 minecraft:magenta_terracotta
setblock 559 206 228 minecraft:magenta_terracotta
setblock 559 206 230 minecraft:magenta_terracotta
setblock 559 206 234 minecraft:magenta_terracotta
setblock 559 206 238 minecraft:magenta_terracotta
setblock 559 206 242 minecraft:magenta_terracotta
setblock 559 206 246 minecraft:magenta_terracotta
setblock 559 206 250 minecraft:magenta_terracotta
setblock 559 206 254 minecraft:magenta_terracotta
setblock 559 206 258 minecraft:magenta_terracotta
setblock 559 206 262 minecraft:magenta_terracotta
setblock 559 206 266 minecraft:magenta_terracotta
setblock 559 206 270 minecraft:magenta_terracotta
setblock 517 207 230 minecraft:purple_terracotta
setblock 517 207 234 minecraft:purple_terracotta
setblock 517 207 238 minecraft:purple_terracotta
setblock 517 207 242 minecraft:purple_terracotta
setblock 517 207 246 minecraft:purple_terracotta
setblock 517 207 250 minecraft:purple_terracotta
setblock 517 207 254 minecraft:purple_terracotta
setblock 517 207 258 minecraft:purple_terracotta
setblock 517 207 262 minecraft:purple_terracotta
setblock 517 207 266 minecraft:purple_terracotta
setblock 517 207 270 minecraft:purple_terracotta
fill 518 207 244 519 208 245 minecraft:dark_oak_planks
setblock 518 207 251 minecraft:black_concrete
setblock 518 207 252 minecraft:white_terracotta
setblock 518 207 253 minecraft:black_concrete
setblock 519 207 228 minecraft:purple_terracotta
fill 519 207 246 519 207 247 minecraft:spruce_planks
setblock 519 207 270 minecraft:purple_terracotta
setblock 523 207 228 minecraft:purple_terracotta
setblock 523 207 270 minecraft:purple_terracotta
setblock 527 207 228 minecraft:purple_terracotta
setblock 527 207 270 minecraft:purple_terracotta
setblock 531 207 228 minecraft:purple_terracotta
setblock 531 207 270 minecraft:purple_terracotta
fill 532 207 247 535 207 251 minecraft:gold_block
fill 533 207 245 538 207 246 minecraft:gold_block
fill 533 207 252 538 207 253 minecraft:gold_block
fill 534 207 244 544 207 244 minecraft:gold_block
fill 534 207 254 544 207 254 minecraft:gold_block
setblock 535 207 228 minecraft:purple_terracotta
fill 535 207 243 543 207 243 minecraft:gold_block
fill 535 207 255 543 207 255 minecraft:gold_block
setblock 535 207 270 minecraft:purple_terracotta
fill 536 207 247 536 207 248 minecraft:gold_block
fill 536 207 250 536 207 251 minecraft:gold_block
fill 537 207 242 541 208 242 minecraft:gold_block
fill 537 207 256 541 208 256 minecraft:gold_block
setblock 539 207 228 minecraft:purple_terracotta
fill 539 207 245 545 207 245 minecraft:gold_block
fill 539 207 253 545 207 253 minecraft:gold_block
setblock 539 207 270 minecraft:purple_terracotta
fill 540 207 246 545 207 246 minecraft:gold_block
fill 540 207 252 545 207 252 minecraft:gold_block
fill 542 207 247 546 207 248 minecraft:gold_block
fill 542 207 250 546 207 251 minecraft:gold_block
setblock 543 207 228 minecraft:purple_terracotta
fill 543 207 249 546 207 249 minecraft:gold_block
setblock 543 207 270 minecraft:purple_terracotta
setblock 546 207 270 minecraft:gray_terracotta
setblock 547 207 228 minecraft:purple_terracotta
setblock 547 207 270 minecraft:purple_terracotta
setblock 551 207 228 minecraft:purple_terracotta
setblock 551 207 270 minecraft:purple_terracotta
setblock 555 207 228 minecraft:purple_terracotta
setblock 555 207 270 minecraft:purple_terracotta
setblock 559 207 228 minecraft:purple_terracotta
setblock 559 207 230 minecraft:purple_terracotta
setblock 559 207 234 minecraft:purple_terracotta
setblock 559 207 238 minecraft:purple_terracotta
setblock 559 207 242 minecraft:purple_terracotta
setblock 559 207 246 minecraft:purple_terracotta
setblock 559 207 250 minecraft:purple_terracotta
setblock 559 207 254 minecraft:purple_terracotta
setblock 559 207 258 minecraft:purple_terracotta
setblock 559 207 262 minecraft:purple_terracotta
setblock 559 207 266 minecraft:purple_terracotta
setblock 559 207 270 minecraft:purple_terracotta
fill 517 208 228 517 208 270 minecraft:dark_oak_planks
fill 518 208 228 531 208 243 minecraft:dark_oak_planks
fill 518 208 246 528 208 270 minecraft:dark_oak_planks
fill 520 208 244 529 208 245 minecraft:dark_oak_planks
fill 529 208 246 529 208 247 minecraft:dark_oak_planks
fill 529 208 248 529 208 250 minecraft:spruce_planks
fill 529 208 251 529 208 270 minecraft:dark_oak_planks
fill 530 208 244 530 210 244 minecraft:dark_oak_planks
fill 530 208 245 530 208 248 minecraft:spruce_planks
fill 530 208 250 530 208 253 minecraft:spruce_planks
fill 530 208 254 530 208 270 minecraft:dark_oak_planks
fill 531 208 244 531 208 245 minecraft:spruce_planks
fill 531 208 246 532 208 252 minecraft:gold_block
fill 531 208 253 531 208 254 minecraft:spruce_planks
fill 531 208 255 531 208 270 minecraft:dark_oak_planks
fill 532 208 228 532 208 242 minecraft:dark_oak_planks
setblock 532 208 243 minecraft:spruce_planks
fill 532 208 245 533 208 245 minecraft:gold_block
fill 532 208 253 533 208 253 minecraft:gold_block
setblock 532 208 255 minecraft:spruce_planks
fill 532 208 256 532 208 270 minecraft:dark_oak_planks
fill 533 208 228 533 208 241 minecraft:dark_oak_planks
fill 533 208 242 534 208 242 minecraft:spruce_planks
fill 533 208 243 534 208 244 minecraft:gold_block
fill 533 208 246 533 208 247 minecraft:gold_block
setblock 533 208 248 minecraft:yellow_stained_glass
setblock 533 208 249 minecraft:gold_block
setblock 533 208 250 minecraft:yellow_stained_glass
fill 533 208 251 533 208 252 minecraft:gold_block
fill 533 208 254 534 208 255 minecraft:gold_block
fill 533 208 256 534 208 256 minecraft:spruce_planks
fill 533 208 257 533 208 270 minecraft:dark_oak_planks
fill 534 208 228 536 208 240 minecraft:dark_oak_planks
fill 534 208 241 537 208 241 minecraft:spruce_planks
setblock 534 208 245 minecraft:yellow_stained_glass
setblock 534 208 246 minecraft:gold_block
setblock 534 208 247 minecraft:yellow_stained_glass
setblock 534 208 248 minecraft:gold_block
setblock 534 208 249 minecraft:yellow_stained_glass
setblock 534 208 250 minecraft:gold_block
setblock 534 208 251 minecraft:yellow_stained_glass
setblock 534 208 252 minecraft:gold_block
setblock 534 208 253 minecraft:yellow_stained_glass
fill 534 208 257 537 208 257 minecraft:spruce_planks
fill 534 208 258 536 208 270 minecraft:dark_oak_planks
fill 535 208 242 536 208 243 minecraft:gold_block
setblock 535 208 244 minecraft:yellow_stained_glass
setblock 535 208 245 minecraft:gold_block
setblock 535 208 246 minecraft:yellow_stained_glass
setblock 535 208 247 minecraft:gold_block
fill 535 208 248 535 208 250 minecraft:ochre_froglight
setblock 535 208 251 minecraft:gold_block
setblock 535 208 252 minecraft:yellow_stained_glass
setblock 535 208 253 minecraft:gold_block
setblock 535 208 254 minecraft:yellow_stained_glass
fill 535 208 255 536 208 256 minecraft:gold_block
setblock 536 208 244 minecraft:gold_block
setblock 536 208 245 minecraft:yellow_stained_glass
setblock 536 208 246 minecraft:ochre_froglight
fill 536 208 247 536 208 248 minecraft:pearlescent_froglight
fill 536 208 250 536 208 251 minecraft:pearlescent_froglight
setblock 536 208 252 minecraft:ochre_froglight
setblock 536 208 253 minecraft:yellow_stained_glass
setblock 536 208 254 minecraft:gold_block
fill 537 208 228 559 208 239 minecraft:dark_oak_planks
fill 537 208 240 539 208 240 minecraft:spruce_planks
setblock 537 208 243 minecraft:gold_block
setblock 537 208 244 minecraft:yellow_stained_glass
setblock 537 208 245 minecraft:gold_block
fill 537 208 246 538 208 246 minecraft:pearlescent_froglight
fill 537 208 252 538 208 252 minecraft:pearlescent_froglight
setblock 537 208 253 minecraft:gold_block
setblock 537 208 254 minecraft:yellow_stained_glass
setblock 537 208 255 minecraft:gold_block
fill 537 208 258 539 208 258 minecraft:spruce_planks
fill 537 208 259 559 208 270 minecraft:dark_oak_planks
setblock 538 208 241 minecraft:gold_block
setblock 538 208 243 minecraft:yellow_stained_glass
setblock 538 208 244 minecraft:gold_block
fill 538 208 245 540 208 245 minecraft:ochre_froglight
fill 538 208 253 540 208 253 minecraft:ochre_froglight
setblock 538 208 254 minecraft:gold_block
setblock 538 208 255 minecraft:yellow_stained_glass
setblock 538 208 257 minecraft:gold_block
fill 539 208 241 542 208 241 minecraft:spruce_planks
setblock 539 208 243 minecraft:gold_block
setblock 539 208 244 minecraft:yellow_stained_glass
setblock 539 208 254 minecraft:yellow_stained_glass
setblock 539 208 255 minecraft:gold_block
fill 539 208 257 542 208 257 minecraft:spruce_planks
fill 540 208 240 559 208 240 minecraft:dark_oak_planks
setblock 540 208 243 minecraft:yellow_stained_glass
setblock 540 208 244 minecraft:gold_block
fill 540 208 246 541 208 246 minecraft:pearlescent_froglight
fill 540 208 252 541 208 252 minecraft:pearlescent_froglight
setblock 540 208 254 minecraft:gold_block
setblock 540 208 255 minecraft:yellow_stained_glass
fill 540 208 258 559 208 258 minecraft:dark_oak_planks
fill 541 208 243 543 208 243 minecraft:gold_block
setblock 541 208 244 minecraft:yellow_stained_glass
setblock 541 208 245 minecraft:gold_block
setblock 541 208 253 minecraft:gold_block
setblock 541 208 254 minecraft:yellow_stained_glass
fill 541 208 255 543 208 255 minecraft:gold_block
fill 542 208 242 543 208 242 minecraft:spruce_planks
setblock 542 208 244 minecraft:gold_block
setblock 542 208 245 minecraft:yellow_stained_glass
setblock 542 208 246 minecraft:ochre_froglight
fill 542 208 247 542 208 248 minecraft:pearlescent_froglight
fill 542 208 250 542 208 251 minecraft:pearlescent_froglight
setblock 542 208 252 minecraft:ochre_froglight
setblock 542 208 253 minecraft:yellow_stained_glass
setblock 542 208 254 minecraft:gold_block
fill 542 208 256 543 208 256 minecraft:spruce_planks
fill 543 208 241 559 208 241 minecraft:dark_oak_planks
setblock 543 208 244 minecraft:yellow_stained_glass
setblock 543 208 245 minecraft:gold_block
setblock 543 208 246 minecraft:yellow_stained_glass
setblock 543 208 247 minecraft:gold_block
fill 543 208 248 543 208 250 minecraft:ochre_froglight
setblock 543 208 251 minecraft:gold_block
setblock 543 208 252 minecraft:yellow_stained_glass
setblock 543 208 253 minecraft:gold_block
setblock 543 208 254 minecraft:yellow_stained_glass
fill 543 208 257 559 208 257 minecraft:dark_oak_planks
fill 544 208 242 559 208 242 minecraft:dark_oak_planks
setblock 544 208 243 minecraft:spruce_planks
setblock 544 208 244 minecraft:gold_block
setblock 544 208 245 minecraft:yellow_stained_glass
fill 544 208 246 545 208 246 minecraft:gold_block
setblock 544 208 247 minecraft:yellow_stained_glass
setblock 544 208 248 minecraft:gold_block
setblock 544 208 249 minecraft:yellow_stained_glass
setblock 544 208 250 minecraft:gold_block
setblock 544 208 251 minecraft:yellow_stained_glass
fill 544 208 252 545 208 252 minecraft:gold_block
setblock 544 208 253 minecraft:yellow_stained_glass
setblock 544 208 254 minecraft:gold_block
setblock 544 208 255 minecraft:spruce_planks
fill 544 208 256 559 208 256 minecraft:dark_oak_planks
fill 545 208 243 559 208 243 minecraft:dark_oak_planks
fill 545 208 244 545 208 245 minecraft:spruce_planks
setblock 545 208 247 minecraft:gold_block
setblock 545 208 248 minecraft:yellow_stained_glass
fill 545 208 249 546 208 249 minecraft:gold_block
setblock 545 208 250 minecraft:yellow_stained_glass
setblock 545 208 251 minecraft:gold_block
fill 545 208 253 545 208 254 minecraft:spruce_planks
fill 545 208 255 559 208 255 minecraft:dark_oak_planks
fill 546 208 244 559 208 244 minecraft:dark_oak_planks
fill 546 208 245 546 208 248 minecraft:spruce_planks
fill 546 208 250 546 208 253 minecraft:spruce_planks
fill 546 208 254 559 208 254 minecraft:dark_oak_planks
fill 547 208 245 559 208 247 minecraft:dark_oak_planks
fill 547 208 248 547 208 250 minecraft:spruce_planks
fill 547 208 251 559 208 253 minecraft:dark_oak_planks
fill 548 208 248 559 208 250 minecraft:dark_oak_planks
fill 517 209 228 517 209 260 minecraft:purple_terracotta
setblock 517 209 261 minecraft:gray_terracotta
fill 517 209 262 517 209 270 minecraft:purple_terracotta
fill 518 209 228 559 209 228 minecraft:purple_terracotta
fill 518 209 248 519 209 249 minecraft:dark_oak_planks
fill 518 209 250 518 209 254 minecraft:gold_block
fill 518 209 270 559 209 270 minecraft:purple_terracotta
fill 519 209 250 519 209 251 minecraft:spruce_planks
setblock 520 209 231 minecraft:light[level=11]
setblock 520 209 239 minecraft:light[level=11]
setblock 520 209 247 minecraft:light[level=11]
setblock 520 209 255 minecraft:light[level=11]
setblock 520 209 263 minecraft:light[level=11]
fill 527 209 249 527 210 250 minecraft:cobblestone
setblock 528 209 231 minecraft:light[level=11]
setblock 528 209 239 minecraft:light[level=11]
setblock 528 209 247 minecraft:light[level=11]
setblock 528 209 255 minecraft:light[level=11]
setblock 528 209 263 minecraft:light[level=11]
fill 529 209 242 529 210 243 minecraft:cobblestone
fill 529 209 245 533 209 245 minecraft:dark_oak_planks
fill 529 209 247 533 209 247 minecraft:dark_oak_planks
fill 529 209 250 533 209 250 minecraft:dark_oak_planks
fill 529 209 252 533 209 252 minecraft:dark_oak_planks
fill 529 209 257 529 210 258 minecraft:cobblestone
fill 530 209 242 548 209 243 minecraft:dark_oak_planks
fill 530 209 246 533 209 246 minecraft:dark_oak_planks
fill 530 209 248 533 209 249 minecraft:dark_oak_planks
fill 530 209 251 533 209 251 minecraft:dark_oak_planks
fill 530 209 253 533 209 256 minecraft:dark_oak_planks
fill 531 209 244 533 209 244 minecraft:dark_oak_planks
fill 532 209 241 533 209 241 minecraft:dark_oak_planks
fill 534 209 240 535 209 240 minecraft:dark_oak_planks
fill 534 209 255 548 209 256 minecraft:dark_oak_planks
setblock 536 209 231 minecraft:light[level=11]
fill 536 209 238 536 210 239 minecraft:cobblestone
setblock 536 209 258 minecraft:dark_oak_planks
fill 536 209 261 536 210 262 minecraft:cobblestone
setblock 536 209 263 minecraft:light[level=11]
setblock 537 209 240 minecraft:dark_oak_planks
setblock 538 209 259 minecraft:dark_oak_planks
setblock 539 209 240 minecraft:dark_oak_planks
fill 539 209 241 539 210 241 minecraft:white_concrete
fill 539 209 257 539 210 257 minecraft:white_concrete
setblock 540 209 258 minecraft:dark_oak_planks
fill 541 209 240 542 209 240 minecraft:dark_oak_planks
fill 543 209 238 543 210 239 minecraft:cobblestone
setblock 543 209 257 minecraft:dark_oak_planks
fill 543 209 261 543 210 262 minecraft:cobblestone
setblock 544 209 231 minecraft:light[level=11]
setblock 544 209 239 minecraft:light[level=11]
setblock 544 209 241 minecraft:dark_oak_planks
setblock 544 209 263 minecraft:light[level=11]
fill 545 209 244 548 209 254 minecraft:dark_oak_planks
fill 550 209 242 550 210 243 minecraft:cobblestone
fill 550 209 257 550 210 258 minecraft:cobblestone
setblock 552 209 231 minecraft:light[level=11]
setblock 552 209 239 minecraft:light[level=11]
setblock 552 209 247 minecraft:light[level=11]
fill 552 209 249 552 210 250 minecraft:cobblestone
setblock 552 209 255 minecraft:light[level=11]
setblock 552 209 263 minecraft:light[level=11]
fill 559 209 229 559 209 269 minecraft:purple_terracotta
fill 517 210 228 517 211 229 minecraft:purple_terracotta
setblock 517 210 230 minecraft:magenta_terracotta
fill 517 210 231 517 211 233 minecraft:purple_terracotta
setblock 517 210 234 minecraft:magenta_terracotta
fill 517 210 235 517 211 237 minecraft:purple_terracotta
setblock 517 210 238 minecraft:magenta_terracotta
fill 517 210 239 517 211 241 minecraft:purple_terracotta
setblock 517 210 242 minecraft:magenta_terracotta
fill 517 210 243 517 211 245 minecraft:purple_terracotta
setblock 517 210 246 minecraft:magenta_terracotta
fill 517 210 247 517 211 249 minecraft:purple_terracotta
setblock 517 210 250 minecraft:magenta_terracotta
fill 517 210 251 517 211 253 minecraft:purple_terracotta
setblock 517 210 254 minecraft:magenta_terracotta
fill 517 210 255 517 211 257 minecraft:purple_terracotta
setblock 517 210 258 minecraft:magenta_terracotta
fill 517 210 259 517 211 261 minecraft:purple_terracotta
setblock 517 210 262 minecraft:magenta_terracotta
fill 517 210 263 517 211 265 minecraft:purple_terracotta
setblock 517 210 266 minecraft:magenta_terracotta
fill 517 210 267 517 211 269 minecraft:purple_terracotta
setblock 517 210 270 minecraft:magenta_terracotta
fill 518 210 228 518 278 228 minecraft:purple_terracotta
fill 518 210 250 519 210 251 minecraft:dark_oak_planks
fill 518 210 270 518 278 270 minecraft:purple_terracotta
setblock 519 210 228 minecraft:magenta_terracotta
fill 519 210 252 519 210 253 minecraft:spruce_planks
setblock 519 210 270 minecraft:magenta_terracotta
fill 520 210 228 522 211 228 minecraft:purple_terracotta
fill 520 210 270 522 211 270 minecraft:purple_terracotta
setblock 523 210 228 minecraft:magenta_terracotta
setblock 523 210 270 minecraft:magenta_terracotta
fill 524 210 228 526 211 228 minecraft:purple_terracotta
fill 524 210 270 526 211 270 minecraft:purple_terracotta
setblock 527 210 228 minecraft:magenta_terracotta
setblock 527 210 270 minecraft:magenta_terracotta
fill 528 210 228 530 211 228 minecraft:purple_terracotta
fill 528 210 270 530 211 270 minecraft:purple_terracotta
fill 530 210 242 530 216 243 minecraft:dark_oak_planks
fill 530 210 245 530 210 256 minecraft:dark_oak_planks
setblock 531 210 228 minecraft:magenta_terracotta
fill 531 210 242 548 210 242 minecraft:dark_oak_planks
setblock 531 210 249 minecraft:white_concrete
fill 531 210 256 548 210 256 minecraft:dark_oak_planks
setblock 531 210 270 minecraft:magenta_terracotta
fill 532 210 228 534 211 228 minecraft:purple_terracotta
setblock 532 210 245 minecraft:white_concrete
setblock 532 210 253 minecraft:white_concrete
fill 532 210 270 534 211 270 minecraft:purple_terracotta
setblock 535 210 228 minecraft:magenta_terracotta
setblock 535 210 270 minecraft:magenta_terracotta
fill 536 210 228 538 211 228 minecraft:purple_terracotta
fill 536 210 270 538 211 270 minecraft:purple_terracotta
setblock 539 210 228 minecraft:magenta_terracotta
setblock 539 210 270 minecraft:magenta_terracotta
fill 540 210 228 542 211 228 minecraft:purple_terracotta
fill 540 210 270 542 211 270 minecraft:purple_terracotta
setblock 543 210 228 minecraft:magenta_terracotta
setblock 543 210 270 minecraft:magenta_terracotta
fill 544 210 228 546 211 228 minecraft:purple_terracotta
fill 544 210 270 546 211 270 minecraft:purple_terracotta
setblock 546 210 245 minecraft:white_concrete
setblock 546 210 253 minecraft:white_concrete
setblock 547 210 228 minecraft:magenta_terracotta
setblock 547 210 249 minecraft:white_concrete
setblock 547 210 270 minecraft:magenta_terracotta
fill 548 210 228 550 211 228 minecraft:purple_terracotta
fill 548 210 243 548 210 255 minecraft:dark_oak_planks
fill 548 210 270 550 211 270 minecraft:purple_terracotta
setblock 551 210 228 minecraft:magenta_terracotta
setblock 551 210 270 minecraft:magenta_terracotta
fill 552 210 228 554 211 228 minecraft:purple_terracotta
fill 552 210 270 554 211 270 minecraft:purple_terracotta
setblock 555 210 228 minecraft:magenta_terracotta
setblock 555 210 270 minecraft:magenta_terracotta
fill 556 210 228 558 211 228 minecraft:purple_terracotta
fill 556 210 270 558 211 270 minecraft:purple_terracotta
setblock 559 210 228 minecraft:magenta_terracotta
fill 559 210 229 559 278 229 minecraft:purple_terracotta
setblock 559 210 230 minecraft:magenta_terracotta
fill 559 210 231 559 211 233 minecraft:purple_terracotta
setblock 559 210 234 minecraft:magenta_terracotta
fill 559 210 235 559 211 237 minecraft:purple_terracotta
setblock 559 210 238 minecraft:magenta_terracotta
fill 559 210 239 559 211 241 minecraft:purple_terracotta
setblock 559 210 242 minecraft:magenta_terracotta
fill 559 210 243 559 211 245 minecraft:purple_terracotta
setblock 559 210 246 minecraft:magenta_terracotta
fill 559 210 247 559 211 249 minecraft:purple_terracotta
setblock 559 210 250 minecraft:magenta_terracotta
fill 559 210 251 559 211 253 minecraft:purple_terracotta
setblock 559 210 254 minecraft:magenta_terracotta
fill 559 210 255 559 211 257 minecraft:purple_terracotta
setblock 559 210 258 minecraft:magenta_terracotta
fill 559 210 259 559 211 261 minecraft:purple_terracotta
setblock 559 210 262 minecraft:magenta_terracotta
fill 559 210 263 559 211 265 minecraft:purple_terracotta
setblock 559 210 266 minecraft:magenta_terracotta
fill 559 210 267 559 211 269 minecraft:purple_terracotta
setblock 559 210 270 minecraft:magenta_terracotta
fill 517 211 230 517 213 230 minecraft:purple_terracotta
fill 517 211 234 517 213 234 minecraft:purple_terracotta
fill 517 211 238 517 213 238 minecraft:purple_terracotta
fill 517 211 242 517 213 242 minecraft:purple_terracotta
fill 517 211 246 517 213 246 minecraft:purple_terracotta
fill 517 211 250 517 213 250 minecraft:purple_terracotta
fill 517 211 254 517 213 254 minecraft:purple_terracotta
fill 517 211 258 517 213 258 minecraft:purple_terracotta
fill 517 211 262 517 213 262 minecraft:purple_terracotta
fill 517 211 266 517 213 266 minecraft:purple_terracotta
setblock 517 211 270 minecraft:purple_terracotta
fill 518 211 252 519 211 253 minecraft:dark_oak_planks
fill 519 211 228 519 213 228 minecraft:purple_terracotta
fill 519 211 254 519 211 255 minecraft:spruce_planks
fill 519 211 270 519 213 270 minecraft:purple_terracotta
setblock 520 211 231 minecraft:light[level=12]
setblock 520 211 238 minecraft:light[level=12]
setblock 520 211 245 minecraft:light[level=12]
setblock 520 211 252 minecraft:light[level=12]
setblock 520 211 259 minecraft:light[level=12]
setblock 520 211 266 minecraft:light[level=12]
fill 523 211 228 523 213 228 minecraft:purple_terracotta
fill 523 211 270 523 213 270 minecraft:purple_terracotta
fill 527 211 228 527 213 228 minecraft:purple_terracotta
setblock 527 211 231 minecraft:light[level=12]
setblock 527 211 238 minecraft:light[level=12]
setblock 527 211 245 minecraft:light[level=12]
setblock 527 211 252 minecraft:light[level=12]
setblock 527 211 259 minecraft:light[level=12]
setblock 527 211 266 minecraft:light[level=12]
fill 527 211 270 527 213 270 minecraft:purple_terracotta
setblock 530 211 244 minecraft:ochre_froglight
fill 530 211 245 530 216 246 minecraft:dark_oak_planks
setblock 530 211 247 minecraft:ochre_froglight
fill 530 211 248 530 216 249 minecraft:dark_oak_planks
setblock 530 211 250 minecraft:ochre_froglight
fill 530 211 251 530 216 252 minecraft:dark_oak_planks
setblock 530 211 253 minecraft:ochre_froglight
fill 530 211 254 530 216 255 minecraft:dark_oak_planks
setblock 530 211 256 minecraft:ochre_froglight
fill 531 211 228 531 213 228 minecraft:purple_terracotta
fill 531 211 242 531 216 242 minecraft:dark_oak_planks
setblock 531 211 249 minecraft:ochre_froglight
fill 531 211 256 532 216 256 minecraft:dark_oak_planks
fill 531 211 270 531 213 270 minecraft:purple_terracotta
setblock 532 211 242 minecraft:ochre_froglight
setblock 532 211 245 minecraft:ochre_froglight
setblock 532 211 253 minecraft:ochre_froglight
fill 533 211 242 534 216 242 minecraft:dark_oak_planks
setblock 533 211 256 minecraft:ochre_froglight
setblock 534 211 231 minecraft:light[level=12]
setblock 534 211 238 minecraft:light[level=12]
fill 534 211 256 535 216 256 minecraft:dark_oak_planks
setblock 534 211 259 minecraft:light[level=12]
setblock 534 211 266 minecraft:light[level=12]
fill 535 211 228 535 213 228 minecraft:purple_terracotta
setblock 535 211 242 minecraft:ochre_froglight
fill 535 211 270 535 213 270 minecraft:purple_terracotta
fill 536 211 242 537 216 242 minecraft:dark_oak_planks
setblock 536 211 256 minecraft:ochre_froglight
fill 537 211 256 538 216 256 minecraft:dark_oak_planks
setblock 538 211 242 minecraft:ochre_froglight
fill 539 211 228 539 213 228 minecraft:purple_terracotta
setblock 539 211 241 minecraft:ochre_froglight
fill 539 211 242 540 216 242 minecraft:dark_oak_planks
fill 539 211 256 539 211 257 minecraft:ochre_froglight
fill 539 211 270 539 213 270 minecraft:purple_terracotta
fill 540 211 256 541 216 256 minecraft:dark_oak_planks
setblock 541 211 231 minecraft:light[level=12]
setblock 541 211 238 minecraft:light[level=12]
setblock 541 211 242 minecraft:ochre_froglight
setblock 541 211 259 minecraft:light[level=12]
setblock 541 211 266 minecraft:light[level=12]
fill 542 211 242 543 216 242 minecraft:dark_oak_planks
setblock 542 211 256 minecraft:ochre_froglight
fill 543 211 228 543 213 228 minecraft:purple_terracotta
fill 543 211 256 544 216 256 minecraft:dark_oak_planks
fill 543 211 270 543 213 270 minecraft:purple_terracotta
setblock 544 211 242 minecraft:ochre_froglight
fill 545 211 242 546 216 242 minecraft:dark_oak_planks
setblock 545 211 256 minecraft:ochre_froglight
setblock 546 211 245 minecraft:ochre_froglight
setblock 546 211 253 minecraft:ochre_froglight
fill 546 211 256 547 216 256 minecraft:dark_oak_planks
fill 547 211 228 547 213 228 minecraft:purple_terracotta
setblock 547 211 242 minecraft:ochre_froglight
setblock 547 211 249 minecraft:ochre_froglight
fill 547 211 270 547 213 270 minecraft:purple_terracotta
setblock 548 211 231 minecraft:light[level=12]
setblock 548 211 238 minecraft:light[level=12]
fill 548 211 242 548 216 243 minecraft:dark_oak_planks
setblock 548 211 244 minecraft:ochre_froglight
fill 548 211 245 548 216 246 minecraft:dark_oak_planks
setblock 548 211 247 minecraft:ochre_froglight
fill 548 211 248 548 216 249 minecraft:dark_oak_planks
setblock 548 211 250 minecraft:ochre_froglight
fill 548 211 251 548 216 252 minecraft:dark_oak_planks
setblock 548 211 253 minecraft:ochre_froglight
fill 548 211 254 548 216 255 minecraft:dark_oak_planks
setblock 548 211 256 minecraft:ochre_froglight
setblock 548 211 259 minecraft:light[level=12]
setblock 548 211 266 minecraft:light[level=12]
fill 551 211 228 551 213 228 minecraft:purple_terracotta
fill 551 211 270 551 213 270 minecraft:purple_terracotta
fill 555 211 228 555 213 228 minecraft:purple_terracotta
setblock 555 211 231 minecraft:light[level=12]
setblock 555 211 238 minecraft:light[level=12]
setblock 555 211 245 minecraft:light[level=12]
setblock 555 211 252 minecraft:light[level=12]
setblock 555 211 259 minecraft:light[level=12]
setblock 555 211 266 minecraft:light[level=12]
fill 555 211 270 555 213 270 minecraft:purple_terracotta
setblock 559 211 228 minecraft:purple_terracotta
fill 559 211 230 559 213 230 minecraft:purple_terracotta
fill 559 211 234 559 213 234 minecraft:purple_terracotta
fill 559 211 238 559 213 238 minecraft:purple_terracotta
fill 559 211 242 559 213 242 minecraft:purple_terracotta
fill 559 211 246 559 213 246 minecraft:purple_terracotta
fill 559 211 250 559 213 250 minecraft:purple_terracotta
fill 559 211 254 559 213 254 minecraft:purple_terracotta
fill 559 211 258 559 213 258 minecraft:purple_terracotta
fill 559 211 262 559 213 262 minecraft:purple_terracotta
setblock 559 211 266 minecraft:light_gray_terracotta
fill 559 211 270 559 213 270 minecraft:purple_terracotta
setblock 517 212 228 minecraft:magenta_terracotta
fill 517 212 229 517 278 229 minecraft:purple_terracotta
fill 517 212 231 517 246 231 minecraft:purple_terracotta
setblock 517 212 232 minecraft:magenta_terracotta
fill 517 212 233 517 278 233 minecraft:purple_terracotta
fill 517 212 235 517 278 235 minecraft:purple_terracotta
setblock 517 212 236 minecraft:magenta_terracotta
fill 517 212 237 517 278 237 minecraft:purple_terracotta
fill 517 212 239 517 278 239 minecraft:purple_terracotta
setblock 517 212 240 minecraft:magenta_terracotta
fill 517 212 241 517 278 241 minecraft:purple_terracotta
fill 517 212 243 517 278 243 minecraft:purple_terracotta
setblock 517 212 244 minecraft:magenta_terracotta
fill 517 212 245 517 278 245 minecraft:purple_terracotta
fill 517 212 247 517 278 247 minecraft:purple_terracotta
setblock 517 212 248 minecraft:magenta_terracotta
fill 517 212 249 517 278 249 minecraft:purple_terracotta
fill 517 212 251 517 278 251 minecraft:purple_terracotta
setblock 517 212 252 minecraft:magenta_terracotta
fill 517 212 253 517 242 253 minecraft:purple_terracotta
fill 517 212 255 517 278 255 minecraft:purple_terracotta
setblock 517 212 256 minecraft:magenta_terracotta
fill 517 212 257 517 217 257 minecraft:purple_terracotta
fill 517 212 259 517 237 259 minecraft:purple_terracotta
setblock 517 212 260 minecraft:magenta_terracotta
fill 517 212 261 517 278 261 minecraft:purple_terracotta
fill 517 212 263 517 239 263 minecraft:purple_terracotta
setblock 517 212 264 minecraft:magenta_terracotta
fill 517 212 265 517 278 265 minecraft:purple_terracotta
fill 517 212 267 517 278 267 minecraft:purple_terracotta
setblock 517 212 268 minecraft:magenta_terracotta
fill 517 212 269 517 278 269 minecraft:purple_terracotta
setblock 517 212 270 minecraft:magenta_terracotta
fill 518 212 254 519 212 255 minecraft:dark_oak_planks
fill 519 212 256 519 212 257 minecraft:spruce_planks
fill 520 212 228 520 278 228 minecraft:purple_terracotta
fill 520 212 270 520 228 270 minecraft:purple_terracotta
setblock 521 212 228 minecraft:magenta_terracotta
setblock 521 212 270 minecraft:magenta_terracotta
fill 522 212 228 522 278 228 minecraft:purple_terracotta
fill 522 212 270 522 278 270 minecraft:purple_terracotta
fill 524 212 228 524 278 228 minecraft:purple_terracotta
fill 524 212 270 524 218 270 minecraft:purple_terracotta
setblock 525 212 228 minecraft:magenta_terracotta
setblock 525 212 270 minecraft:magenta_terracotta
fill 526 212 228 526 278 228 minecraft:purple_terracotta
fill 526 212 270 526 278 270 minecraft:purple_terracotta
fill 528 212 228 528 278 228 minecraft:purple_terracotta
fill 528 212 270 528 229 270 minecraft:purple_terracotta
setblock 529 212 228 minecraft:magenta_terracotta
setblock 529 212 270 minecraft:magenta_terracotta
fill 530 212 228 530 278 228 minecraft:purple_terracotta
fill 530 212 244 530 214 244 minecraft:dark_oak_planks
fill 530 212 247 530 214 247 minecraft:dark_oak_planks
fill 530 212 250 530 214 250 minecraft:dark_oak_planks
fill 530 212 253 530 214 253 minecraft:dark_oak_planks
fill 530 212 256 530 214 256 minecraft:dark_oak_planks
fill 530 212 270 530 278 270 minecraft:purple_terracotta
fill 532 212 228 532 278 228 minecraft:purple_terracotta
fill 532 212 242 532 214 242 minecraft:dark_oak_planks
fill 532 212 270 532 278 270 minecraft:purple_terracotta
setblock 533 212 228 minecraft:magenta_terracotta
fill 533 212 256 533 214 256 minecraft:dark_oak_planks
setblock 533 212 270 minecraft:magenta_terracotta
fill 534 212 228 534 242 228 minecraft:purple_terracotta
fill 534 212 270 534 278 270 minecraft:purple_terracotta
fill 535 212 242 535 214 242 minecraft:dark_oak_planks
fill 536 212 228 536 278 228 minecraft:purple_terracotta
fill 536 212 256 536 214 256 minecraft:dark_oak_planks
fill 536 212 270 536 278 270 minecraft:purple_terracotta
setblock 537 212 228 minecraft:magenta_terracotta
setblock 537 212 270 minecraft:magenta_terracotta
fill 538 212 228 538 278 228 minecraft:purple_terracotta
fill 538 212 242 538 214 242 minecraft:dark_oak_planks
fill 538 212 270 538 278 270 minecraft:purple_terracotta
fill 539 212 256 539 214 256 minecraft:dark_oak_planks
fill 540 212 228 540 278 228 minecraft:purple_terracotta
fill 540 212 270 540 264 270 minecraft:purple_terracotta
setblock 541 212 228 minecraft:magenta_terracotta
fill 541 212 242 541 214 242 minecraft:dark_oak_planks
setblock 541 212 270 minecraft:magenta_terracotta
fill 542 212 228 542 278 228 minecraft:purple_terracotta
fill 542 212 256 542 214 256 minecraft:dark_oak_planks
fill 542 212 270 542 259 270 minecraft:purple_terracotta
fill 544 212 228 544 253 228 minecraft:purple_terracotta
fill 544 212 242 544 214 242 minecraft:dark_oak_planks
fill 544 212 270 544 242 270 minecraft:purple_terracotta
setblock 545 212 228 minecraft:magenta_terracotta
fill 545 212 256 545 214 256 minecraft:dark_oak_planks
setblock 545 212 270 minecraft:magenta_terracotta
fill 546 212 228 546 278 228 minecraft:purple_terracotta
fill 546 212 270 546 278 270 minecraft:purple_terracotta
fill 547 212 242 547 214 242 minecraft:dark_oak_planks
fill 548 212 228 548 278 228 minecraft:purple_terracotta
fill 548 212 244 548 214 244 minecraft:dark_oak_planks
fill 548 212 247 548 214 247 minecraft:dark_oak_planks
fill 548 212 250 548 214 250 minecraft:dark_oak_planks
fill 548 212 253 548 214 253 minecraft:dark_oak_planks
fill 548 212 256 548 214 256 minecraft:dark_oak_planks
fill 548 212 270 548 243 270 minecraft:purple_terracotta
setblock 549 212 228 minecraft:magenta_terracotta
setblock 549 212 270 minecraft:magenta_terracotta
fill 550 212 228 550 278 228 minecraft:purple_terracotta
fill 550 212 270 550 261 270 minecraft:purple_terracotta
fill 551 212 250 555 212 254 minecraft:dark_oak_planks
fill 552 212 228 552 278 228 minecraft:purple_terracotta
fill 552 212 270 552 278 270 minecraft:purple_terracotta
setblock 553 212 228 minecraft:magenta_terracotta
setblock 553 212 270 minecraft:magenta_terracotta
fill 554 212 228 554 278 228 minecraft:purple_terracotta
fill 554 212 247 554 225 247 minecraft:iron_bars
fill 554 212 270 554 278 270 minecraft:purple_terracotta
fill 555 212 240 555 217 240 minecraft:iron_bars
fill 556 212 228 556 278 228 minecraft:purple_terracotta
fill 556 212 270 556 278 270 minecraft:purple_terracotta
setblock 557 212 228 minecraft:magenta_terracotta
setblock 557 212 270 minecraft:magenta_terracotta
fill 558 212 228 558 278 228 minecraft:purple_terracotta
fill 558 212 270 558 278 270 minecraft:purple_terracotta
setblock 559 212 228 minecraft:magenta_terracotta
fill 559 212 231 559 278 231 minecraft:purple_terracotta
setblock 559 212 232 minecraft:magenta_terracotta
fill 559 212 233 559 278 233 minecraft:purple_terracotta
fill 559 212 235 559 278 235 minecraft:purple_terracotta
setblock 559 212 236 minecraft:magenta_terracotta
fill 559 212 237 559 278 237 minecraft:purple_terracotta
fill 559 212 239 559 278 239 minecraft:purple_terracotta
setblock 559 212 240 minecraft:magenta_terracotta
fill 559 212 241 559 278 241 minecraft:purple_terracotta
fill 559 212 243 559 278 243 minecraft:purple_terracotta
setblock 559 212 244 minecraft:magenta_terracotta
fill 559 212 245 559 221 245 minecraft:purple_terracotta
fill 559 212 247 559 278 247 minecraft:purple_terracotta
setblock 559 212 248 minecraft:magenta_terracotta
fill 559 212 249 559 278 249 minecraft:purple_terracotta
fill 559 212 251 559 260 251 minecraft:purple_terracotta
setblock 559 212 252 minecraft:magenta_terracotta
fill 559 212 253 559 278 253 minecraft:purple_terracotta
fill 559 212 255 559 233 255 minecraft:purple_terracotta
setblock 559 212 256 minecraft:magenta_terracotta
fill 559 212 257 559 275 257 minecraft:purple_terracotta
fill 559 212 259 559 278 259 minecraft:purple_terracotta
setblock 559 212 260 minecraft:magenta_terracotta
fill 559 212 261 559 278 261 minecraft:purple_terracotta
fill 559 212 263 559 227 263 minecraft:purple_terracotta
setblock 559 212 264 minecraft:magenta_terracotta
fill 559 212 265 559 213 267 minecraft:purple_terracotta
setblock 559 212 268 minecraft:magenta_terracotta
fill 559 212 269 559 244 269 minecraft:purple_terracotta
fill 517 213 228 517 215 228 minecraft:purple_terracotta
fill 517 213 232 517 215 232 minecraft:purple_terracotta
setblock 517 213 236 minecraft:purple_terracotta
fill 517 213 240 517 215 240 minecraft:purple_terracotta
fill 517 213 244 517 215 244 minecraft:purple_terracotta
fill 517 213 248 517 215 248 minecraft:purple_terracotta
fill 517 213 252 517 215 252 minecraft:purple_terracotta
fill 517 213 256 517 215 256 minecraft:purple_terracotta
fill 517 213 260 517 215 260 minecraft:purple_terracotta
fill 517 213 264 517 215 264 minecraft:purple_terracotta
fill 517 213 268 517 215 268 minecraft:purple_terracotta
setblock 517 213 270 minecraft:purple_terracotta
fill 518 213 256 519 213 257 minecraft:dark_oak_planks
fill 519 213 258 519 213 259 minecraft:spruce_planks
fill 521 213 228 521 215 228 minecraft:purple_terracotta
fill 521 213 270 521 215 270 minecraft:purple_terracotta
fill 525 213 228 525 215 228 minecraft:purple_terracotta
fill 525 213 270 525 215 270 minecraft:purple_terracotta
fill 529 213 228 529 215 228 minecraft:purple_terracotta
fill 529 213 270 529 215 270 minecraft:purple_terracotta
fill 533 213 228 533 215 228 minecraft:purple_terracotta
setblock 533 213 270 minecraft:light_gray_terracotta
fill 537 213 228 537 215 228 minecraft:purple_terracotta
fill 537 213 270 537 215 270 minecraft:purple_terracotta
fill 541 213 228 541 215 228 minecraft:purple_terracotta
fill 541 213 270 541 215 270 minecraft:purple_terracotta
fill 545 213 228 545 215 228 minecraft:purple_terracotta
fill 545 213 270 545 215 270 minecraft:purple_terracotta
fill 549 213 228 549 215 228 minecraft:purple_terracotta
fill 549 213 270 549 215 270 minecraft:purple_terracotta
fill 552 213 252 554 217 252 minecraft:stripped_dark_oak_log
fill 553 213 228 553 214 228 minecraft:purple_terracotta
setblock 553 213 270 minecraft:purple_terracotta
fill 557 213 228 557 215 228 minecraft:purple_terracotta
fill 557 213 270 557 215 270 minecraft:purple_terracotta
setblock 559 213 228 minecraft:purple_terracotta
fill 559 213 232 559 215 232 minecraft:purple_terracotta
fill 559 213 236 559 215 236 minecraft:purple_terracotta
fill 559 213 240 559 215 240 minecraft:purple_terracotta
fill 559 213 244 559 215 244 minecraft:purple_terracotta
fill 559 213 248 559 215 248 minecraft:purple_terracotta
fill 559 213 252 559 215 252 minecraft:purple_terracotta
fill 559 213 256 559 215 256 minecraft:purple_terracotta
fill 559 213 260 559 215 260 minecraft:purple_terracotta
fill 559 213 264 559 215 264 minecraft:purple_terracotta
fill 559 213 268 559 215 268 minecraft:purple_terracotta
setblock 517 214 230 minecraft:magenta_terracotta
setblock 517 214 234 minecraft:magenta_terracotta
setblock 517 214 236 minecraft:black_terracotta
setblock 517 214 238 minecraft:magenta_terracotta
setblock 517 214 242 minecraft:magenta_terracotta
setblock 517 214 246 minecraft:magenta_terracotta
setblock 517 214 250 minecraft:magenta_terracotta
setblock 517 214 254 minecraft:magenta_terracotta
setblock 517 214 258 minecraft:magenta_terracotta
setblock 517 214 262 minecraft:magenta_terracotta
setblock 517 214 266 minecraft:magenta_terracotta
setblock 517 214 270 minecraft:magenta_terracotta
fill 518 214 258 519 214 259 minecraft:dark_oak_planks
setblock 519 214 228 minecraft:magenta_terracotta
fill 519 214 260 519 214 261 minecraft:spruce_planks
setblock 519 214 270 minecraft:magenta_terracotta
setblock 523 214 228 minecraft:magenta_terracotta
setblock 523 214 270 minecraft:magenta_terracotta
setblock 527 214 228 minecraft:magenta_terracotta
setblock 527 214 270 minecraft:magenta_terracotta
setblock 531 214 228 minecraft:magenta_terracotta
setblock 531 214 270 minecraft:magenta_terracotta
fill 533 214 270 533 215 270 minecraft:purple_terracotta
setblock 535 214 228 minecraft:magenta_terracotta
setblock 535 214 270 minecraft:magenta_terracotta
setblock 539 214 228 minecraft:magenta_terracotta
setblock 539 214 270 minecraft:magenta_terracotta
setblock 543 214 228 minecraft:magenta_terracotta
setblock 543 214 270 minecraft:magenta_terracotta
setblock 547 214 228 minecraft:magenta_terracotta
setblock 547 214 270 minecraft:magenta_terracotta
setblock 551 214 228 minecraft:magenta_terracotta
setblock 551 214 270 minecraft:magenta_terracotta
setblock 553 214 270 minecraft:gray_terracotta
setblock 555 214 228 minecraft:magenta_terracotta
setblock 555 214 270 minecraft:magenta_terracotta
setblock 559 214 228 minecraft:magenta_terracotta
setblock 559 214 230 minecraft:magenta_terracotta
setblock 559 214 234 minecraft:magenta_terracotta
setblock 559 214 238 minecraft:magenta_terracotta
setblock 559 214 242 minecraft:magenta_terracotta
setblock 559 214 246 minecraft:magenta_terracotta
setblock 559 214 250 minecraft:magenta_terracotta
setblock 559 214 254 minecraft:magenta_terracotta
setblock 559 214 258 minecraft:magenta_terracotta
setblock 559 214 262 minecraft:magenta_terracotta
fill 559 214 265 559 262 265 minecraft:purple_terracotta
setblock 559 214 266 minecraft:magenta_terracotta
fill 559 214 267 559 278 267 minecraft:purple_terracotta
setblock 559 214 270 minecraft:magenta_terracotta
fill 517 215 230 517 217 230 minecraft:purple_terracotta
fill 517 215 234 517 217 234 minecraft:purple_terracotta
setblock 517 215 236 minecraft:purple_terracotta
fill 517 215 238 517 217 238 minecraft:purple_terracotta
fill 517 215 242 517 217 242 minecraft:purple_terracotta
fill 517 215 246 517 217 246 minecraft:purple_terracotta
fill 517 215 250 517 217 250 minecraft:purple_terracotta
fill 517 215 254 517 217 254 minecraft:purple_terracotta
fill 517 215 258 517 217 258 minecraft:purple_terracotta
fill 517 215 262 517 217 262 minecraft:purple_terracotta
fill 517 215 266 517 217 266 minecraft:purple_terracotta
setblock 517 215 270 minecraft:purple_terracotta
fill 518 215 260 519 215 261 minecraft:dark_oak_planks
fill 519 215 228 519 217 228 minecraft:purple_terracotta
fill 519 215 262 519 215 263 minecraft:spruce_planks
fill 519 215 270 519 217 270 minecraft:purple_terracotta
fill 523 215 228 523 217 228 minecraft:purple_terracotta
fill 523 215 270 523 217 270 minecraft:purple_terracotta
fill 527 215 228 527 217 228 minecraft:purple_terracotta
fill 527 215 270 527 217 270 minecraft:purple_terracotta
setblock 530 215 244 minecraft:ochre_froglight
setblock 530 215 247 minecraft:ochre_froglight
setblock 530 215 250 minecraft:ochre_froglight
setblock 530 215 253 minecraft:ochre_froglight
setblock 530 215 256 minecraft:ochre_froglight
fill 531 215 228 531 217 228 minecraft:purple_terracotta
fill 531 215 270 531 217 270 minecraft:purple_terracotta
setblock 532 215 242 minecraft:ochre_froglight
setblock 533 215 256 minecraft:ochre_froglight
fill 535 215 228 535 217 228 minecraft:purple_terracotta
setblock 535 215 242 minecraft:ochre_froglight
fill 535 215 270 535 217 270 minecraft:purple_terracotta
setblock 536 215 256 minecraft:ochre_froglight
setblock 538 215 242 minecraft:ochre_froglight
fill 539 215 228 539 217 228 minecraft:purple_terracotta
setblock 539 215 256 minecraft:ochre_froglight
fill 539 215 270 539 217 270 minecraft:purple_terracotta
setblock 541 215 242 minecraft:ochre_froglight
setblock 542 215 256 minecraft:ochre_froglight
fill 543 215 228 543 217 228 minecraft:purple_terracotta
fill 543 215 270 543 217 270 minecraft:purple_terracotta
setblock 544 215 242 minecraft:ochre_froglight
setblock 545 215 256 minecraft:ochre_froglight
fill 547 215 228 547 217 228 minecraft:purple_terracotta
setblock 547 215 242 minecraft:ochre_froglight
fill 547 215 270 547 217 270 minecraft:purple_terracotta
setblock 548 215 244 minecraft:ochre_froglight
setblock 548 215 247 minecraft:ochre_froglight
setblock 548 215 250 minecraft:ochre_froglight
setblock 548 215 253 minecraft:ochre_froglight
setblock 548 215 256 minecraft:ochre_froglight
fill 551 215 228 551 217 228 minecraft:purple_terracotta
fill 551 215 270 551 217 270 minecraft:purple_terracotta
setblock 553 215 228 minecraft:gray_terracotta
setblock 553 215 270 minecraft:purple_terracotta
fill 555 215 228 555 217 228 minecraft:purple_terracotta
fill 555 215 270 555 217 270 minecraft:purple_terracotta
setblock 559 215 228 minecraft:purple_terracotta
fill 559 215 230 559 217 230 minecraft:purple_terracotta
fill 559 215 234 559 217 234 minecraft:purple_terracotta
fill 559 215 238 559 217 238 minecraft:purple_terracotta
fill 559 215 242 559 217 242 minecraft:purple_terracotta
fill 559 215 246 559 216 246 minecraft:purple_terracotta
fill 559 215 250 559 217 250 minecraft:purple_terracotta
fill 559 215 254 559 217 254 minecraft:purple_terracotta
fill 559 215 258 559 217 258 minecraft:purple_terracotta
fill 559 215 262 559 217 262 minecraft:purple_terracotta
fill 559 215 266 559 217 266 minecraft:purple_terracotta
fill 559 215 270 559 217 270 minecraft:purple_terracotta
setblock 517 216 228 minecraft:magenta_terracotta
setblock 517 216 232 minecraft:magenta_terracotta
setblock 517 216 236 minecraft:magenta_terracotta
setblock 517 216 240 minecraft:magenta_terracotta
setblock 517 216 244 minecraft:magenta_terracotta
setblock 517 216 248 minecraft:magenta_terracotta
setblock 517 216 252 minecraft:magenta_terracotta
setblock 517 216 256 minecraft:magenta_terracotta
setblock 517 216 260 minecraft:magenta_terracotta
setblock 517 216 264 minecraft:magenta_terracotta
setblock 517 216 268 minecraft:magenta_terracotta
setblock 517 216 270 minecraft:magenta_terracotta
fill 518 216 262 519 216 263 minecraft:dark_oak_planks
fill 519 216 264 519 216 265 minecraft:spruce_planks
setblock 521 216 228 minecraft:light_gray_terracotta
setblock 521 216 270 minecraft:magenta_terracotta
setblock 525 216 228 minecraft:magenta_terracotta
setblock 525 216 270 minecraft:magenta_terracotta
setblock 529 216 228 minecraft:magenta_terracotta
setblock 529 216 270 minecraft:magenta_terracotta
fill 530 216 244 533 216 244 minecraft:dark_oak_planks
fill 530 216 247 533 216 247 minecraft:dark_oak_planks
fill 530 216 250 533 216 250 minecraft:dark_oak_planks
fill 530 216 253 533 216 253 minecraft:dark_oak_planks
setblock 530 216 256 minecraft:dark_oak_planks
fill 531 216 243 547 216 243 minecraft:dark_oak_planks
fill 531 216 245 533 216 246 minecraft:dark_oak_planks
fill 531 216 248 533 216 249 minecraft:dark_oak_planks
fill 531 216 251 533 216 252 minecraft:dark_oak_planks
fill 531 216 254 533 216 255 minecraft:dark_oak_planks
setblock 532 216 242 minecraft:dark_oak_planks
setblock 533 216 228 minecraft:magenta_terracotta
setblock 533 216 256 minecraft:dark_oak_planks
setblock 533 216 270 minecraft:magenta_terracotta
fill 534 216 255 547 216 255 minecraft:dark_oak_planks
setblock 535 216 242 minecraft:dark_oak_planks
setblock 536 216 256 minecraft:dark_oak_planks
setblock 537 216 228 minecraft:magenta_terracotta
setblock 537 216 270 minecraft:magenta_terracotta
setblock 538 216 242 minecraft:dark_oak_planks
setblock 539 216 256 minecraft:dark_oak_planks
setblock 541 216 228 minecraft:magenta_terracotta
setblock 541 216 242 minecraft:dark_oak_planks
setblock 541 216 270 minecraft:magenta_terracotta
setblock 542 216 256 minecraft:dark_oak_planks
setblock 544 216 242 minecraft:dark_oak_planks
setblock 545 216 228 minecraft:magenta_terracotta
fill 545 216 244 547 216 254 minecraft:dark_oak_planks
setblock 545 216 256 minecraft:dark_oak_planks
setblock 545 216 270 minecraft:magenta_terracotta
setblock 547 216 242 minecraft:dark_oak_planks
setblock 548 216 244 minecraft:dark_oak_planks
setblock 548 216 247 minecraft:dark_oak_planks
setblock 548 216 250 minecraft:dark_oak_planks
setblock 548 216 253 minecraft:dark_oak_planks
setblock 548 216 256 minecraft:dark_oak_planks
setblock 549 216 228 minecraft:magenta_terracotta
setblock 549 216 270 minecraft:magenta_terracotta
setblock 553 216 228 minecraft:magenta_terracotta
fill 553 216 251 553 217 251 minecraft:stripped_dark_oak_log
fill 553 216 253 553 217 253 minecraft:stripped_dark_oak_log
setblock 553 216 270 minecraft:magenta_terracotta
setblock 557 216 228 minecraft:magenta_terracotta
setblock 557 216 270 minecraft:magenta_terracotta
setblock 559 216 228 minecraft:magenta_terracotta
setblock 559 216 232 minecraft:magenta_terracotta
setblock 559 216 236 minecraft:magenta_terracotta
setblock 559 216 240 minecraft:magenta_terracotta
setblock 559 216 244 minecraft:magenta_terracotta
setblock 559 216 248 minecraft:magenta_terracotta
setblock 559 216 252 minecraft:magenta_terracotta
setblock 559 216 256 minecraft:magenta_terracotta
setblock 559 216 260 minecraft:magenta_terracotta
setblock 559 216 264 minecraft:magenta_terracotta
setblock 559 216 268 minecraft:magenta_terracotta
fill 517 217 228 517 219 228 minecraft:purple_terracotta
fill 517 217 232 517 219 232 minecraft:purple_terracotta
fill 517 217 236 517 219 236 minecraft:purple_terracotta
fill 517 217 240 517 219 240 minecraft:purple_terracotta
fill 517 217 244 517 219 244 minecraft:purple_terracotta
fill 517 217 248 517 219 248 minecraft:purple_terracotta
fill 517 217 252 517 219 252 minecraft:purple_terracotta
fill 517 217 256 517 219 256 minecraft:purple_terracotta
fill 517 217 260 517 219 260 minecraft:purple_terracotta
fill 517 217 264 517 219 264 minecraft:purple_terracotta
fill 517 217 268 517 219 268 minecraft:purple_terracotta
setblock 517 217 270 minecraft:purple_terracotta
fill 518 217 264 519 217 265 minecraft:dark_oak_planks
fill 519 217 266 519 217 267 minecraft:spruce_planks
setblock 520 217 231 minecraft:light[level=11]
setblock 520 217 238 minecraft:light[level=12]
setblock 520 217 239 minecraft:light[level=11]
setblock 520 217 245 minecraft:light[level=12]
setblock 520 217 247 minecraft:light[level=11]
setblock 520 217 252 minecraft:light[level=12]
setblock 520 217 255 minecraft:light[level=11]
setblock 520 217 259 minecraft:light[level=12]
setblock 520 217 263 minecraft:light[level=11]
setblock 520 217 266 minecraft:light[level=12]
fill 521 217 228 521 219 228 minecraft:purple_terracotta
fill 521 217 270 521 219 270 minecraft:purple_terracotta
fill 525 217 228 525 219 228 minecraft:purple_terracotta
fill 525 217 270 525 219 270 minecraft:purple_terracotta
setblock 527 217 231 minecraft:light[level=12]
setblock 527 217 238 minecraft:light[level=12]
setblock 527 217 245 minecraft:light[level=12]
setblock 527 217 252 minecraft:light[level=12]
setblock 527 217 259 minecraft:light[level=12]
setblock 527 217 266 minecraft:light[level=12]
setblock 528 217 231 minecraft:light[level=11]
setblock 528 217 239 minecraft:light[level=11]
setblock 528 217 247 minecraft:light[level=11]
setblock 528 217 255 minecraft:light[level=11]
setblock 528 217 263 minecraft:light[level=11]
fill 529 217 228 529 219 228 minecraft:purple_terracotta
fill 529 217 270 529 219 270 minecraft:purple_terracotta
fill 530 217 242 533 217 256 minecraft:deepslate_tiles
fill 533 217 228 533 219 228 minecraft:purple_terracotta
fill 533 217 270 533 219 270 minecraft:purple_terracotta
setblock 534 217 231 minecraft:light[level=12]
setblock 534 217 238 minecraft:light[level=12]
fill 534 217 242 548 217 243 minecraft:deepslate_tiles
fill 534 217 255 548 217 256 minecraft:deepslate_tiles
setblock 534 217 259 minecraft:light[level=12]
setblock 534 217 266 minecraft:light[level=12]
setblock 536 217 231 minecraft:light[level=11]
setblock 536 217 239 minecraft:light[level=11]
setblock 536 217 263 minecraft:light[level=11]
fill 537 217 228 537 219 228 minecraft:purple_terracotta
fill 537 217 270 537 219 270 minecraft:purple_terracotta
fill 541 217 228 541 219 228 minecraft:purple_terracotta
setblock 541 217 231 minecraft:light[level=12]
setblock 541 217 238 minecraft:light[level=12]
setblock 541 217 259 minecraft:light[level=12]
setblock 541 217 266 minecraft:light[level=12]
fill 541 217 270 541 219 270 minecraft:purple_terracotta
setblock 544 217 231 minecraft:light[level=11]
setblock 544 217 239 minecraft:light[level=11]
setblock 544 217 263 minecraft:light[level=11]
fill 545 217 228 545 219 228 minecraft:purple_terracotta
fill 545 217 244 548 217 254 minecraft:deepslate_tiles
fill 545 217 270 545 219 270 minecraft:purple_terracotta
setblock 548 217 231 minecraft:light[level=12]
setblock 548 217 238 minecraft:light[level=12]
setblock 548 217 259 minecraft:light[level=12]
setblock 548 217 266 minecraft:light[level=12]
fill 549 217 228 549 219 228 minecraft:purple_terracotta
fill 549 217 270 549 219 270 minecraft:purple_terracotta
setblock 552 217 231 minecraft:light[level=11]
setblock 552 217 239 minecraft:light[level=11]
setblock 552 217 247 minecraft:light[level=11]
setblock 552 217 255 minecraft:light[level=11]
setblock 552 217 263 minecraft:light[level=11]
fill 553 217 228 553 219 228 minecraft:purple_terracotta
fill 553 217 270 553 219 270 minecraft:purple_terracotta
setblock 555 217 231 minecraft:light[level=12]
setblock 555 217 238 minecraft:light[level=12]
setblock 555 217 245 minecraft:light[level=12]
setblock 555 217 252 minecraft:light[level=12]
setblock 555 217 259 minecraft:light[level=12]
setblock 555 217 266 minecraft:light[level=12]
fill 557 217 228 557 219 228 minecraft:purple_terracotta
fill 557 217 270 557 219 270 minecraft:purple_terracotta
setblock 559 217 228 minecraft:purple_terracotta
fill 559 217 232 559 219 232 minecraft:purple_terracotta
fill 559 217 236 559 219 236 minecraft:purple_terracotta
fill 559 217 240 559 219 240 minecraft:purple_terracotta
fill 559 217 244 559 219 244 minecraft:purple_terracotta
setblock 559 217 246 minecraft:light_gray_terracotta
fill 559 217 248 559 219 248 minecraft:purple_terracotta
fill 559 217 252 559 219 252 minecraft:purple_terracotta
fill 559 217 256 559 219 256 minecraft:purple_terracotta
fill 559 217 260 559 219 260 minecraft:purple_terracotta
fill 559 217 264 559 219 264 minecraft:purple_terracotta
fill 559 217 268 559 219 268 minecraft:purple_terracotta
setblock 517 218 230 minecraft:magenta_terracotta
setblock 517 218 234 minecraft:magenta_terracotta
setblock 517 218 238 minecraft:magenta_terracotta
setblock 517 218 242 minecraft:magenta_terracotta
setblock 517 218 246 minecraft:black_terracotta
setblock 517 218 250 minecraft:magenta_terracotta
setblock 517 218 254 minecraft:magenta_terracotta
setblock 517 218 257 minecraft:gray_terracotta
setblock 517 218 258 minecraft:magenta_terracotta
setblock 517 218 262 minecraft:magenta_terracotta
setblock 517 218 266 minecraft:magenta_terracotta
setblock 517 218 270 minecraft:magenta_terracotta
fill 518 218 266 519 218 267 minecraft:dark_oak_planks
setblock 519 218 228 minecraft:magenta_terracotta
setblock 519 218 268 minecraft:spruce_planks
setblock 519 218 270 minecraft:magenta_terracotta
setblock 523 218 228 minecraft:magenta_terracotta
setblock 523 218 270 minecraft:magenta_terracotta
setblock 527 218 228 minecraft:magenta_terracotta
setblock 527 218 270 minecraft:magenta_terracotta
setblock 531 218 228 minecraft:magenta_terracotta
fill 531 218 243 533 218 255 minecraft:deepslate_tiles
setblock 531 218 270 minecraft:magenta_terracotta
fill 534 218 243 547 218 243 minecraft:deepslate_tiles
fill 534 218 255 547 218 255 minecraft:deepslate_tiles
setblock 535 218 228 minecraft:magenta_terracotta
setblock 535 218 270 minecraft:magenta_terracotta
setblock 539 218 228 minecraft:magenta_terracotta
setblock 539 218 270 minecraft:magenta_terracotta
setblock 543 218 228 minecraft:magenta_terracotta
setblock 543 218 270 minecraft:magenta_terracotta
fill 545 218 244 547 218 254 minecraft:deepslate_tiles
setblock 547 218 228 minecraft:magenta_terracotta
setblock 547 218 270 minecraft:magenta_terracotta
setblock 551 218 228 minecraft:magenta_terracotta
setblock 551 218 270 minecraft:magenta_terracotta
setblock 555 218 228 minecraft:magenta_terracotta
setblock 555 218 270 minecraft:magenta_terracotta
setblock 559 218 228 minecraft:magenta_terracotta
setblock 559 218 230 minecraft:magenta_terracotta
setblock 559 218 234 minecraft:magenta_terracotta
setblock 559 218 238 minecraft:magenta_terracotta
setblock 559 218 242 minecraft:magenta_terracotta
setblock 559 218 246 minecraft:magenta_terracotta
setblock 559 218 250 minecraft:magenta_terracotta
setblock 559 218 254 minecraft:magenta_terracotta
setblock 559 218 258 minecraft:magenta_terracotta
setblock 559 218 262 minecraft:magenta_terracotta
setblock 559 218 266 minecraft:magenta_terracotta
setblock 559 218 270 minecraft:magenta_terracotta
fill 517 219 230 517 221 230 minecraft:purple_terracotta
fill 517 219 234 517 221 234 minecraft:purple_terracotta
fill 517 219 238 517 221 238 minecraft:purple_terracotta
fill 517 219 242 517 221 242 minecraft:purple_terracotta
fill 517 219 246 517 221 246 minecraft:purple_terracotta
fill 517 219 250 517 221 250 minecraft:purple_terracotta
fill 517 219 254 517 221 254 minecraft:purple_terracotta
fill 517 219 257 517 221 258 minecraft:purple_terracotta
fill 517 219 262 517 221 262 minecraft:purple_terracotta
fill 517 219 266 517 221 266 minecraft:purple_terracotta
setblock 517 219 270 minecraft:purple_terracotta
fill 518 219 268 519 219 269 minecraft:dark_oak_planks
fill 519 219 228 519 221 228 minecraft:purple_terracotta
fill 519 219 270 519 221 270 minecraft:purple_terracotta
fill 520 219 268 521 219 268 minecraft:spruce_planks
fill 523 219 228 523 221 228 minecraft:purple_terracotta
fill 523 219 270 523 221 270 minecraft:purple_terracotta
setblock 524 219 270 minecraft:black_terracotta
fill 527 219 228 527 221 228 minecraft:purple_terracotta
fill 527 219 270 527 221 270 minecraft:purple_terracotta
fill 531 219 228 531 221 228 minecraft:purple_terracotta
fill 531 219 270 531 221 270 minecraft:purple_terracotta
fill 532 219 244 533 219 254 minecraft:deepslate_tiles
fill 535 219 228 535 221 228 minecraft:purple_terracotta
fill 535 219 270 535 221 270 minecraft:purple_terracotta
fill 539 219 228 539 221 228 minecraft:purple_terracotta
fill 539 219 270 539 221 270 minecraft:purple_terracotta
fill 543 219 228 543 221 228 minecraft:purple_terracotta
fill 543 219 270 543 221 270 minecraft:purple_terracotta
fill 545 219 244 546 219 254 minecraft:deepslate_tiles
fill 547 219 228 547 221 228 minecraft:purple_terracotta
fill 547 219 270 547 221 270 minecraft:purple_terracotta
fill 551 219 228 551 221 228 minecraft:purple_terracotta
fill 551 219 270 551 221 270 minecraft:purple_terracotta
fill 555 219 228 555 221 228 minecraft:purple_terracotta
fill 555 219 270 555 221 270 minecraft:purple_terracotta
setblock 559 219 228 minecraft:purple_terracotta
fill 559 219 230 559 221 230 minecraft:purple_terracotta
fill 559 219 234 559 221 234 minecraft:purple_terracotta
fill 559 219 238 559 221 238 minecraft:purple_terracotta
fill 559 219 242 559 221 242 minecraft:purple_terracotta
fill 559 219 246 559 221 246 minecraft:purple_terracotta
fill 559 219 250 559 221 250 minecraft:purple_terracotta
fill 559 219 254 559 221 254 minecraft:purple_terracotta
fill 559 219 258 559 221 258 minecraft:purple_terracotta
fill 559 219 262 559 221 262 minecraft:purple_terracotta
fill 559 219 266 559 221 266 minecraft:purple_terracotta
fill 559 219 270 559 221 270 minecraft:purple_terracotta
setblock 517 220 228 minecraft:magenta_terracotta
setblock 517 220 232 minecraft:magenta_terracotta
setblock 517 220 236 minecraft:magenta_terracotta
setblock 517 220 240 minecraft:magenta_terracotta
setblock 517 220 244 minecraft:magenta_terracotta
setblock 517 220 248 minecraft:magenta_terracotta
setblock 517 220 252 minecraft:magenta_terracotta
setblock 517 220 256 minecraft:magenta_terracotta
setblock 517 220 260 minecraft:magenta_terracotta
setblock 517 220 264 minecraft:magenta_terracotta
setblock 517 220 268 minecraft:magenta_terracotta
setblock 517 220 270 minecraft:magenta_terracotta
fill 518 220 247 524 220 247 minecraft:dark_oak_planks
fill 520 220 245 524 221 246 minecraft:dark_oak_planks
fill 520 220 248 524 221 249 minecraft:dark_oak_planks
fill 520 220 268 521 220 269 minecraft:dark_oak_planks
setblock 521 220 228 minecraft:magenta_terracotta
setblock 521 220 270 minecraft:magenta_terracotta
fill 522 220 268 523 220 268 minecraft:spruce_planks
fill 524 220 270 524 278 270 minecraft:purple_terracotta
setblock 525 220 228 minecraft:magenta_terracotta
setblock 525 220 270 minecraft:magenta_terracotta
setblock 529 220 228 minecraft:magenta_terracotta
setblock 529 220 270 minecraft:magenta_terracotta
setblock 533 220 228 minecraft:magenta_terracotta
fill 533 220 245 533 220 253 minecraft:deepslate_tiles
setblock 533 220 270 minecraft:magenta_terracotta
setblock 537 220 228 minecraft:magenta_terracotta
setblock 537 220 270 minecraft:magenta_terracotta
setblock 541 220 228 minecraft:magenta_terracotta
setblock 541 220 270 minecraft:magenta_terracotta
setblock 545 220 228 minecraft:magenta_terracotta
fill 545 220 245 545 220 253 minecraft:deepslate_tiles
setblock 545 220 270 minecraft:magenta_terracotta
setblock 549 220 228 minecraft:magenta_terracotta
setblock 549 220 270 minecraft:magenta_terracotta
fill 551 220 232 551 227 232 minecraft:iron_bars
setblock 553 220 228 minecraft:magenta_terracotta
setblock 553 220 270 minecraft:magenta_terracotta
setblock 557 220 228 minecraft:magenta_terracotta
setblock 557 220 270 minecraft:magenta_terracotta
setblock 559 220 228 minecraft:magenta_terracotta
setblock 559 220 232 minecraft:magenta_terracotta
setblock 559 220 236 minecraft:magenta_terracotta
setblock 559 220 240 minecraft:magenta_terracotta
setblock 559 220 244 minecraft:magenta_terracotta
setblock 559 220 248 minecraft:magenta_terracotta
setblock 559 220 252 minecraft:magenta_terracotta
setblock 559 220 256 minecraft:magenta_terracotta
setblock 559 220 260 minecraft:magenta_terracotta
setblock 559 220 264 minecraft:magenta_terracotta
setblock 559 220 268 minecraft:magenta_terracotta
fill 517 221 228 517 223 228 minecraft:purple_terracotta
fill 517 221 232 517 223 232 minecraft:purple_terracotta
fill 517 221 236 517 223 236 minecraft:purple_terracotta
fill 517 221 240 517 223 240 minecraft:purple_terracotta
setblock 517 221 244 minecraft:purple_terracotta
fill 517 221 248 517 223 248 minecraft:purple_terracotta
fill 517 221 252 517 223 252 minecraft:purple_terracotta
fill 517 221 256 517 223 256 minecraft:purple_terracotta
fill 517 221 260 517 223 260 minecraft:purple_terracotta
fill 517 221 264 517 223 264 minecraft:purple_terracotta
fill 517 221 268 517 223 268 minecraft:purple_terracotta
setblock 517 221 270 minecraft:purple_terracotta
fill 520 221 247 524 221 247 minecraft:dark_oak_planks
fill 521 221 228 521 223 228 minecraft:purple_terracotta
fill 521 221 270 521 223 270 minecraft:purple_terracotta
fill 522 221 268 523 221 269 minecraft:dark_oak_planks
fill 524 221 268 525 221 268 minecraft:spruce_planks
fill 525 221 228 525 223 228 minecraft:purple_terracotta
fill 525 221 270 525 223 270 minecraft:purple_terracotta
fill 529 221 228 529 223 228 minecraft:purple_terracotta
fill 529 221 270 529 223 270 minecraft:purple_terracotta
fill 533 221 228 533 223 228 minecraft:purple_terracotta
fill 533 221 270 533 223 270 minecraft:purple_terracotta
fill 534 221 231 538 222 235 minecraft:dark_oak_planks
fill 536 221 229 536 221 230 minecraft:dark_oak_planks
fill 537 221 228 537 223 228 minecraft:purple_terracotta
fill 537 221 270 537 223 270 minecraft:purple_terracotta
fill 541 221 228 541 223 228 minecraft:purple_terracotta
fill 541 221 270 541 223 270 minecraft:purple_terracotta
fill 545 221 228 545 223 228 minecraft:purple_terracotta
fill 545 221 270 545 223 270 minecraft:purple_terracotta
fill 549 221 228 549 223 228 minecraft:purple_terracotta
fill 549 221 270 549 223 270 minecraft:purple_terracotta
fill 553 221 228 553 223 228 minecraft:purple_terracotta
fill 553 221 270 553 223 270 minecraft:purple_terracotta
fill 557 221 228 557 223 228 minecraft:purple_terracotta
fill 557 221 270 557 223 270 minecraft:purple_terracotta
setblock 559 221 228 minecraft:purple_terracotta
fill 559 221 232 559 223 232 minecraft:purple_terracotta
fill 559 221 236 559 223 236 minecraft:purple_terracotta
fill 559 221 240 559 223 240 minecraft:purple_terracotta
fill 559 221 244 559 223 244 minecraft:purple_terracotta
fill 559 221 248 559 223 248 minecraft:purple_terracotta
fill 559 221 252 559 223 252 minecraft:purple_terracotta
fill 559 221 256 559 223 256 minecraft:purple_terracotta
fill 559 221 260 559 223 260 minecraft:purple_terracotta
fill 559 221 264 559 223 264 minecraft:purple_terracotta
fill 559 221 268 559 223 268 minecraft:purple_terracotta
setblock 517 222 230 minecraft:magenta_terracotta
setblock 517 222 234 minecraft:magenta_terracotta
setblock 517 222 238 minecraft:magenta_terracotta
setblock 517 222 242 minecraft:magenta_terracotta
setblock 517 222 244 minecraft:black_terracotta
setblock 517 222 246 minecraft:magenta_terracotta
setblock 517 222 250 minecraft:magenta_terracotta
setblock 517 222 254 minecraft:magenta_terracotta
fill 517 222 257 517 278 257 minecraft:purple_terracotta
setblock 517 222 258 minecraft:magenta_terracotta
setblock 517 222 262 minecraft:magenta_terracotta
setblock 517 222 266 minecraft:magenta_terracotta
setblock 517 222 270 minecraft:magenta_terracotta
setblock 519 222 228 minecraft:magenta_terracotta
setblock 519 222 270 minecraft:magenta_terracotta
fill 521 222 247 523 226 247 minecraft:stripped_dark_oak_log
setblock 523 222 228 minecraft:magenta_terracotta
setblock 523 222 270 minecraft:magenta_terracotta
fill 524 222 268 525 222 269 minecraft:dark_oak_planks
fill 526 222 268 527 222 268 minecraft:spruce_planks
setblock 527 222 228 minecraft:magenta_terracotta
setblock 527 222 270 minecraft:magenta_terracotta
setblock 531 222 228 minecraft:magenta_terracotta
setblock 531 222 270 minecraft:magenta_terracotta
setblock 535 222 228 minecraft:magenta_terracotta
setblock 535 222 270 minecraft:magenta_terracotta
setblock 539 222 228 minecraft:magenta_terracotta
setblock 539 222 270 minecraft:magenta_terracotta
setblock 543 222 228 minecraft:magenta_terracotta
setblock 543 222 270 minecraft:magenta_terracotta
setblock 547 222 228 minecraft:magenta_terracotta
setblock 547 222 270 minecraft:magenta_terracotta
setblock 551 222 228 minecraft:magenta_terracotta
setblock 551 222 270 minecraft:magenta_terracotta
setblock 555 222 228 minecraft:magenta_terracotta
setblock 555 222 270 minecraft:magenta_terracotta
setblock 559 222 228 minecraft:magenta_terracotta
setblock 559 222 230 minecraft:magenta_terracotta
setblock 559 222 234 minecraft:magenta_terracotta
setblock 559 222 238 minecraft:magenta_terracotta
setblock 559 222 242 minecraft:magenta_terracotta
setblock 559 222 245 minecraft:light_gray_terracotta
setblock 559 222 246 minecraft:magenta_terracotta
setblock 559 222 250 minecraft:magenta_terracotta
setblock 559 222 254 minecraft:magenta_terracotta
setblock 559 222 258 minecraft:magenta_terracotta
setblock 559 222 262 minecraft:magenta_terracotta
setblock 559 222 266 minecraft:magenta_terracotta
setblock 559 222 270 minecraft:magenta_terracotta
fill 517 223 230 517 225 230 minecraft:purple_terracotta
fill 517 223 234 517 225 234 minecraft:purple_terracotta
fill 517 223 238 517 225 238 minecraft:purple_terracotta
fill 517 223 242 517 225 242 minecraft:purple_terracotta
setblock 517 223 244 minecraft:purple_terracotta
fill 517 223 246 517 225 246 minecraft:purple_terracotta
fill 517 223 250 517 225 250 minecraft:purple_terracotta
fill 517 223 254 517 225 254 minecraft:purple_terracotta
fill 517 223 258 517 225 258 minecraft:purple_terracotta
fill 517 223 262 517 225 262 minecraft:purple_terracotta
fill 517 223 266 517 225 266 minecraft:purple_terracotta
setblock 517 223 270 minecraft:purple_terracotta
fill 519 223 228 519 225 228 minecraft:purple_terracotta
fill 519 223 270 519 225 270 minecraft:purple_terracotta
setblock 520 223 231 minecraft:light[level=12]
setblock 520 223 238 minecraft:light[level=12]
setblock 520 223 245 minecraft:light[level=12]
setblock 520 223 252 minecraft:light[level=12]
setblock 520 223 259 minecraft:light[level=12]
setblock 520 223 266 minecraft:light[level=12]
fill 523 223 228 523 225 228 minecraft:purple_terracotta
fill 523 223 270 523 225 270 minecraft:purple_terracotta
fill 526 223 268 527 223 269 minecraft:dark_oak_planks
fill 527 223 228 527 225 228 minecraft:purple_terracotta
setblock 527 223 231 minecraft:light[level=12]
setblock 527 223 238 minecraft:light[level=12]
setblock 527 223 245 minecraft:light[level=12]
setblock 527 223 252 minecraft:light[level=12]
setblock 527 223 259 minecraft:light[level=12]
setblock 527 223 266 minecraft:light[level=12]
fill 527 223 270 527 225 270 minecraft:purple_terracotta
fill 528 223 268 529 223 268 minecraft:spruce_planks
fill 531 223 228 531 225 228 minecraft:purple_terracotta
fill 531 223 270 531 225 270 minecraft:purple_terracotta
setblock 534 223 231 minecraft:light[level=12]
setblock 534 223 238 minecraft:light[level=12]
setblock 534 223 259 minecraft:light[level=12]
setblock 534 223 266 minecraft:light[level=12]
fill 535 223 228 535 225 228 minecraft:purple_terracotta
fill 535 223 233 537 229 233 minecraft:purple_concrete
fill 535 223 270 535 225 270 minecraft:purple_terracotta
fill 536 223 232 536 229 232 minecraft:purple_concrete
fill 536 223 234 536 229 234 minecraft:purple_concrete
fill 539 223 228 539 225 228 minecraft:purple_terracotta
fill 539 223 270 539 225 270 minecraft:purple_terracotta
setblock 541 223 231 minecraft:light[level=12]
setblock 541 223 238 minecraft:light[level=12]
setblock 541 223 259 minecraft:light[level=12]
setblock 541 223 266 minecraft:light[level=12]
fill 543 223 228 543 225 228 minecraft:purple_terracotta
fill 543 223 270 543 225 270 minecraft:purple_terracotta
fill 547 223 228 547 225 228 minecraft:purple_terracotta
fill 547 223 270 547 225 270 minecraft:purple_terracotta
setblock 548 223 231 minecraft:light[level=12]
setblock 548 223 238 minecraft:light[level=12]
setblock 548 223 245 minecraft:light[level=12]
setblock 548 223 252 minecraft:light[level=12]
setblock 548 223 259 minecraft:light[level=12]
setblock 548 223 266 minecraft:light[level=12]
fill 551 223 228 551 225 228 minecraft:purple_terracotta
fill 551 223 270 551 225 270 minecraft:purple_terracotta
fill 555 223 228 555 225 228 minecraft:purple_terracotta
setblock 555 223 231 minecraft:light[level=12]
setblock 555 223 238 minecraft:light[level=12]
setblock 555 223 245 minecraft:light[level=12]
setblock 555 223 252 minecraft:light[level=12]
setblock 555 223 259 minecraft:light[level=12]
setblock 555 223 266 minecraft:light[level=12]
fill 555 223 270 555 225 270 minecraft:purple_terracotta
setblock 559 223 228 minecraft:purple_terracotta
fill 559 223 230 559 225 230 minecraft:purple_terracotta
fill 559 223 234 559 225 234 minecraft:purple_terracotta
fill 559 223 238 559 225 238 minecraft:purple_terracotta
fill 559 223 242 559 224 242 minecraft:purple_terracotta
fill 559 223 245 559 225 246 minecraft:purple_terracotta
fill 559 223 250 559 225 250 minecraft:purple_terracotta
fill 559 223 254 559 225 254 minecraft:purple_terracotta
fill 559 223 258 559 225 258 minecraft:purple_terracotta
fill 559 223 262 559 225 262 minecraft:purple_terracotta
fill 559 223 266 559 225 266 minecraft:purple_terracotta
fill 559 223 270 559 225 270 minecraft:purple_terracotta
setblock 517 224 228 minecraft:magenta_terracotta
setblock 517 224 232 minecraft:magenta_terracotta
setblock 517 224 236 minecraft:magenta_terracotta
setblock 517 224 240 minecraft:magenta_terracotta
setblock 517 224 244 minecraft:magenta_terracotta
setblock 517 224 248 minecraft:magenta_terracotta
setblock 517 224 252 minecraft:magenta_terracotta
setblock 517 224 256 minecraft:magenta_terracotta
setblock 517 224 260 minecraft:magenta_terracotta
setblock 517 224 264 minecraft:magenta_terracotta
setblock 517 224 268 minecraft:magenta_terracotta
setblock 517 224 270 minecraft:magenta_terracotta
setblock 521 224 228 minecraft:magenta_terracotta
setblock 521 224 270 minecraft:magenta_terracotta
setblock 525 224 228 minecraft:magenta_terracotta
setblock 525 224 270 minecraft:magenta_terracotta
fill 528 224 268 529 224 269 minecraft:dark_oak_planks
setblock 529 224 228 minecraft:magenta_terracotta
setblock 529 224 270 minecraft:magenta_terracotta
fill 530 224 268 531 224 268 minecraft:spruce_planks
setblock 533 224 228 minecraft:magenta_terracotta
setblock 533 224 270 minecraft:magenta_terracotta
setblock 537 224 228 minecraft:magenta_terracotta
setblock 537 224 270 minecraft:magenta_terracotta
setblock 541 224 228 minecraft:magenta_terracotta
setblock 541 224 270 minecraft:magenta_terracotta
setblock 545 224 228 minecraft:magenta_terracotta
setblock 545 224 270 minecraft:magenta_terracotta
setblock 549 224 228 minecraft:magenta_terracotta
setblock 549 224 270 minecraft:magenta_terracotta
setblock 553 224 228 minecraft:magenta_terracotta
setblock 553 224 270 minecraft:magenta_terracotta
setblock 557 224 228 minecraft:magenta_terracotta
setblock 557 224 270 minecraft:magenta_terracotta
setblock 559 224 228 minecraft:magenta_terracotta
setblock 559 224 232 minecraft:magenta_terracotta
setblock 559 224 236 minecraft:magenta_terracotta
setblock 559 224 240 minecraft:magenta_terracotta
setblock 559 224 244 minecraft:magenta_terracotta
setblock 559 224 248 minecraft:magenta_terracotta
setblock 559 224 252 minecraft:magenta_terracotta
setblock 559 224 256 minecraft:magenta_terracotta
setblock 559 224 260 minecraft:magenta_terracotta
setblock 559 224 264 minecraft:magenta_terracotta
setblock 559 224 268 minecraft:magenta_terracotta
fill 517 225 228 517 227 228 minecraft:purple_terracotta
fill 517 225 232 517 227 232 minecraft:purple_terracotta
fill 517 225 236 517 227 236 minecraft:purple_terracotta
fill 517 225 240 517 227 240 minecraft:purple_terracotta
fill 517 225 244 517 227 244 minecraft:purple_terracotta
fill 517 225 248 517 227 248 minecraft:purple_terracotta
fill 517 225 252 517 227 252 minecraft:purple_terracotta
fill 517 225 256 517 227 256 minecraft:purple_terracotta
fill 517 225 260 517 227 260 minecraft:purple_terracotta
fill 517 225 264 517 227 264 minecraft:purple_terracotta
fill 517 225 268 517 227 268 minecraft:purple_terracotta
setblock 517 225 270 minecraft:purple_terracotta
setblock 520 225 231 minecraft:light[level=11]
setblock 520 225 239 minecraft:light[level=11]
setblock 520 225 247 minecraft:light[level=11]
setblock 520 225 255 minecraft:light[level=11]
setblock 520 225 263 minecraft:light[level=11]
fill 521 225 228 521 227 228 minecraft:purple_terracotta
fill 521 225 270 521 227 270 minecraft:purple_terracotta
fill 522 225 246 522 226 246 minecraft:stripped_dark_oak_log
fill 522 225 248 522 226 248 minecraft:stripped_dark_oak_log
fill 525 225 228 525 227 228 minecraft:purple_terracotta
fill 525 225 270 525 227 270 minecraft:purple_terracotta
setblock 528 225 231 minecraft:light[level=11]
setblock 528 225 239 minecraft:light[level=11]
setblock 528 225 247 minecraft:light[level=11]
setblock 528 225 255 minecraft:light[level=11]
setblock 528 225 263 minecraft:light[level=11]
fill 529 225 228 529 227 228 minecraft:purple_terracotta
fill 529 225 270 529 227 270 minecraft:purple_terracotta
fill 530 225 268 531 225 269 minecraft:dark_oak_planks
fill 532 225 268 533 225 268 minecraft:spruce_planks
fill 533 225 228 533 227 228 minecraft:purple_terracotta
fill 533 225 270 533 227 270 minecraft:purple_terracotta
setblock 536 225 231 minecraft:light[level=11]
setblock 536 225 239 minecraft:light[level=11]
setblock 536 225 247 minecraft:light[level=11]
setblock 536 225 255 minecraft:light[level=11]
setblock 536 225 263 minecraft:light[level=11]
fill 537 225 228 537 227 228 minecraft:purple_terracotta
fill 537 225 270 537 227 270 minecraft:purple_terracotta
fill 541 225 228 541 227 228 minecraft:purple_terracotta
fill 541 225 270 541 227 270 minecraft:purple_terracotta
setblock 544 225 231 minecraft:light[level=11]
setblock 544 225 239 minecraft:light[level=11]
setblock 544 225 247 minecraft:light[level=11]
setblock 544 225 255 minecraft:light[level=11]
setblock 544 225 263 minecraft:light[level=11]
fill 545 225 228 545 227 228 minecraft:purple_terracotta
fill 545 225 270 545 227 270 minecraft:purple_terracotta
fill 549 225 228 549 227 228 minecraft:purple_terracotta
fill 549 225 270 549 227 270 minecraft:purple_terracotta
setblock 552 225 231 minecraft:light[level=11]
setblock 552 225 239 minecraft:light[level=11]
setblock 552 225 247 minecraft:light[level=11]
setblock 552 225 255 minecraft:light[level=11]
setblock 552 225 263 minecraft:light[level=11]
fill 553 225 228 553 227 228 minecraft:purple_terracotta
fill 553 225 270 553 227 270 minecraft:purple_terracotta
fill 557 225 228 557 227 228 minecraft:purple_terracotta
fill 557 225 270 557 227 270 minecraft:purple_terracotta
setblock 559 225 228 minecraft:purple_terracotta
fill 559 225 232 559 227 232 minecraft:purple_terracotta
fill 559 225 236 559 227 236 minecraft:purple_terracotta
fill 559 225 240 559 227 240 minecraft:purple_terracotta
setblock 559 225 242 minecraft:light_gray_terracotta
fill 559 225 244 559 227 244 minecraft:purple_terracotta
fill 559 225 248 559 227 248 minecraft:purple_terracotta
fill 559 225 252 559 227 252 minecraft:purple_terracotta
fill 559 225 256 559 227 256 minecraft:purple_terracotta
fill 559 225 260 559 227 260 minecraft:purple_terracotta
fill 559 225 264 559 227 264 minecraft:purple_terracotta
fill 559 225 268 559 227 268 minecraft:purple_terracotta
setblock 517 226 230 minecraft:magenta_terracotta
setblock 517 226 234 minecraft:magenta_terracotta
setblock 517 226 238 minecraft:magenta_terracotta
setblock 517 226 242 minecraft:magenta_terracotta
setblock 517 226 246 minecraft:magenta_terracotta
setblock 517 226 250 minecraft:magenta_terracotta
setblock 517 226 254 minecraft:magenta_terracotta
setblock 517 226 258 minecraft:magenta_terracotta
setblock 517 226 262 minecraft:magenta_terracotta
setblock 517 226 266 minecraft:magenta_terracotta
setblock 517 226 270 minecraft:magenta_terracotta
setblock 519 226 228 minecraft:magenta_terracotta
setblock 519 226 270 minecraft:magenta_terracotta
setblock 523 226 228 minecraft:magenta_terracotta
setblock 523 226 270 minecraft:magenta_terracotta
setblock 527 226 228 minecraft:magenta_terracotta
setblock 527 226 270 minecraft:magenta_terracotta
setblock 531 226 228 minecraft:magenta_terracotta
setblock 531 226 270 minecraft:magenta_terracotta
fill 532 226 268 533 226 269 minecraft:dark_oak_planks
fill 534 226 268 535 226 268 minecraft:spruce_planks
setblock 535 226 228 minecraft:magenta_terracotta
setblock 535 226 270 minecraft:magenta_terracotta
setblock 539 226 228 minecraft:magenta_terracotta
setblock 539 226 270 minecraft:magenta_terracotta
setblock 543 226 228 minecraft:magenta_terracotta
fill 543 226 245 543 239 245 minecraft:iron_bars
fill 543 226 253 543 239 253 minecraft:iron_bars
setblock 543 226 270 minecraft:magenta_terracotta
setblock 547 226 228 minecraft:magenta_terracotta
setblock 547 226 270 minecraft:magenta_terracotta
setblock 551 226 228 minecraft:magenta_terracotta
setblock 551 226 270 minecraft:magenta_terracotta
setblock 555 226 228 minecraft:magenta_terracotta
setblock 555 226 270 minecraft:magenta_terracotta
setblock 559 226 228 minecraft:magenta_terracotta
setblock 559 226 230 minecraft:magenta_terracotta
setblock 559 226 234 minecraft:magenta_terracotta
setblock 559 226 238 minecraft:magenta_terracotta
setblock 559 226 242 minecraft:magenta_terracotta
fill 559 226 245 559 278 245 minecraft:purple_terracotta
setblock 559 226 246 minecraft:magenta_terracotta
setblock 559 226 250 minecraft:magenta_terracotta
setblock 559 226 254 minecraft:magenta_terracotta
setblock 559 226 258 minecraft:magenta_terracotta
setblock 559 226 262 minecraft:magenta_terracotta
setblock 559 226 266 minecraft:magenta_terracotta
setblock 559 226 270 minecraft:magenta_terracotta
fill 517 227 230 517 229 230 minecraft:purple_terracotta
fill 517 227 234 517 229 234 minecraft:purple_terracotta
fill 517 227 238 517 229 238 minecraft:purple_terracotta
fill 517 227 242 517 229 242 minecraft:purple_terracotta
fill 517 227 246 517 229 246 minecraft:purple_terracotta
fill 517 227 250 517 229 250 minecraft:purple_terracotta
fill 517 227 254 517 229 254 minecraft:purple_terracotta
fill 517 227 258 517 229 258 minecraft:purple_terracotta
fill 517 227 262 517 229 262 minecraft:purple_terracotta
fill 517 227 266 517 229 266 minecraft:purple_terracotta
setblock 517 227 270 minecraft:purple_terracotta
fill 519 227 228 519 229 228 minecraft:purple_terracotta
fill 519 227 270 519 229 270 minecraft:purple_terracotta
fill 523 227 228 523 229 228 minecraft:purple_terracotta
fill 523 227 270 523 229 270 minecraft:purple_terracotta
fill 527 227 228 527 229 228 minecraft:purple_terracotta
fill 527 227 270 527 229 270 minecraft:purple_terracotta
fill 531 227 228 531 229 228 minecraft:purple_terracotta
fill 531 227 270 531 229 270 minecraft:purple_terracotta
fill 534 227 268 535 227 269 minecraft:dark_oak_planks
fill 535 227 228 535 229 228 minecraft:purple_terracotta
fill 535 227 270 535 229 270 minecraft:purple_terracotta
fill 536 227 268 537 227 268 minecraft:spruce_planks
fill 539 227 228 539 229 228 minecraft:purple_terracotta
fill 539 227 270 539 229 270 minecraft:purple_terracotta
fill 543 227 228 543 229 228 minecraft:purple_terracotta
fill 543 227 270 543 229 270 minecraft:purple_terracotta
fill 547 227 228 547 229 228 minecraft:purple_terracotta
fill 547 227 270 547 229 270 minecraft:purple_terracotta
fill 551 227 228 551 229 228 minecraft:purple_terracotta
fill 551 227 270 551 229 270 minecraft:purple_terracotta
setblock 555 227 228 minecraft:black_terracotta
fill 555 227 270 555 229 270 minecraft:purple_terracotta
setblock 559 227 228 minecraft:purple_terracotta
fill 559 227 230 559 229 230 minecraft:purple_terracotta
fill 559 227 234 559 229 234 minecraft:purple_terracotta
fill 559 227 238 559 229 238 minecraft:purple_terracotta
fill 559 227 242 559 229 242 minecraft:purple_terracotta
fill 559 227 246 559 229 246 minecraft:purple_terracotta
fill 559 227 250 559 229 250 minecraft:purple_terracotta
fill 559 227 254 559 229 254 minecraft:purple_terracotta
fill 559 227 258 559 229 258 minecraft:purple_terracotta
fill 559 227 262 559 229 262 minecraft:purple_terracotta
fill 559 227 266 559 229 266 minecraft:purple_terracotta
fill 559 227 270 559 229 270 minecraft:purple_terracotta
setblock 517 228 228 minecraft:magenta_terracotta
setblock 517 228 232 minecraft:magenta_terracotta
setblock 517 228 236 minecraft:magenta_terracotta
setblock 517 228 240 minecraft:magenta_terracotta
setblock 517 228 244 minecraft:magenta_terracotta
setblock 517 228 248 minecraft:magenta_terracotta
setblock 517 228 252 minecraft:magenta_terracotta
setblock 517 228 256 minecraft:magenta_terracotta
setblock 517 228 260 minecraft:magenta_terracotta
setblock 517 228 264 minecraft:magenta_terracotta
setblock 517 228 268 minecraft:magenta_terracotta
setblock 517 228 270 minecraft:magenta_terracotta
setblock 521 228 228 minecraft:magenta_terracotta
setblock 521 228 270 minecraft:magenta_terracotta
setblock 525 228 228 minecraft:magenta_terracotta
setblock 525 228 270 minecraft:magenta_terracotta
setblock 529 228 228 minecraft:magenta_terracotta
setblock 529 228 270 minecraft:magenta_terracotta
setblock 533 228 228 minecraft:magenta_terracotta
setblock 533 228 270 minecraft:magenta_terracotta
fill 536 228 268 537 228 269 minecraft:dark_oak_planks
setblock 537 228 228 minecraft:magenta_terracotta
setblock 537 228 270 minecraft:magenta_terracotta
fill 538 228 268 539 228 268 minecraft:spruce_planks
setblock 541 228 228 minecraft:magenta_terracotta
setblock 541 228 270 minecraft:magenta_terracotta
setblock 545 228 228 minecraft:magenta_terracotta
setblock 545 228 270 minecraft:black_terracotta
setblock 549 228 228 minecraft:magenta_terracotta
setblock 549 228 270 minecraft:magenta_terracotta
setblock 553 228 228 minecraft:magenta_terracotta
setblock 553 228 270 minecraft:magenta_terracotta
fill 554 228 251 554 245 251 minecraft:iron_bars
fill 555 228 228 555 229 228 minecraft:purple_terracotta
setblock 557 228 228 minecraft:magenta_terracotta
setblock 557 228 270 minecraft:magenta_terracotta
setblock 559 228 228 minecraft:magenta_terracotta
setblock 559 228 232 minecraft:magenta_terracotta
setblock 559 228 236 minecraft:magenta_terracotta
setblock 559 228 240 minecraft:magenta_terracotta
setblock 559 228 244 minecraft:magenta_terracotta
setblock 559 228 248 minecraft:magenta_terracotta
setblock 559 228 252 minecraft:magenta_terracotta
setblock 559 228 256 minecraft:magenta_terracotta
setblock 559 228 260 minecraft:magenta_terracotta
setblock 559 228 263 minecraft:light_gray_terracotta
setblock 559 228 264 minecraft:magenta_terracotta
setblock 559 228 268 minecraft:magenta_terracotta
fill 517 229 228 517 231 228 minecraft:purple_terracotta
fill 517 229 232 517 231 232 minecraft:purple_terracotta
fill 517 229 236 517 231 236 minecraft:purple_terracotta
fill 517 229 240 517 231 240 minecraft:purple_terracotta
fill 517 229 244 517 231 244 minecraft:purple_terracotta
fill 517 229 248 517 231 248 minecraft:purple_terracotta
fill 517 229 252 517 231 252 minecraft:purple_terracotta
fill 517 229 256 517 231 256 minecraft:purple_terracotta
fill 517 229 260 517 231 260 minecraft:purple_terracotta
fill 517 229 264 517 231 264 minecraft:purple_terracotta
fill 517 229 268 517 231 268 minecraft:purple_terracotta
setblock 517 229 270 minecraft:purple_terracotta
setblock 520 229 231 minecraft:light[level=12]
setblock 520 229 238 minecraft:light[level=12]
setblock 520 229 245 minecraft:light[level=12]
setblock 520 229 252 minecraft:light[level=12]
setblock 520 229 259 minecraft:light[level=12]
setblock 520 229 266 minecraft:light[level=12]
setblock 520 229 270 minecraft:light_gray_terracotta
fill 521 229 228 521 231 228 minecraft:purple_terracotta
fill 521 229 270 521 231 270 minecraft:purple_terracotta
fill 525 229 228 525 231 228 minecraft:purple_terracotta
fill 525 229 270 525 231 270 minecraft:purple_terracotta
setblock 527 229 231 minecraft:light[level=12]
setblock 527 229 238 minecraft:light[level=12]
setblock 527 229 245 minecraft:light[level=12]
setblock 527 229 252 minecraft:light[level=12]
setblock 527 229 259 minecraft:light[level=12]
setblock 527 229 266 minecraft:light[level=12]
fill 529 229 228 529 231 228 minecraft:purple_terracotta
fill 529 229 270 529 231 270 minecraft:purple_terracotta
fill 533 229 228 533 231 228 minecraft:purple_terracotta
fill 533 229 270 533 231 270 minecraft:purple_terracotta
setblock 534 229 231 minecraft:light[level=12]
setblock 534 229 238 minecraft:light[level=12]
setblock 534 229 245 minecraft:light[level=12]
setblock 534 229 252 minecraft:light[level=12]
setblock 534 229 259 minecraft:light[level=12]
setblock 534 229 266 minecraft:light[level=12]
fill 537 229 228 537 231 228 minecraft:purple_terracotta
fill 537 229 270 537 231 270 minecraft:purple_terracotta
fill 538 229 268 539 229 269 minecraft:dark_oak_planks
fill 540 229 268 541 229 268 minecraft:spruce_planks
fill 541 229 228 541 231 228 minecraft:purple_terracotta
setblock 541 229 231 minecraft:light[level=12]
setblock 541 229 238 minecraft:light[level=12]
setblock 541 229 245 minecraft:light[level=12]
setblock 541 229 252 minecraft:light[level=12]
setblock 541 229 259 minecraft:light[level=12]
setblock 541 229 266 minecraft:light[level=12]
fill 541 229 270 541 231 270 minecraft:purple_terracotta
fill 545 229 228 545 231 228 minecraft:purple_terracotta
fill 545 229 270 545 231 270 minecraft:purple_terracotta
fill 547 229 255 548 231 257 minecraft:white_stained_glass
setblock 548 229 231 minecraft:light[level=12]
setblock 548 229 238 minecraft:light[level=12]
setblock 548 229 245 minecraft:light[level=12]
setblock 548 229 252 minecraft:light[level=12]
setblock 548 229 259 minecraft:light[level=12]
setblock 548 229 266 minecraft:light[level=12]
fill 549 229 228 549 231 228 minecraft:purple_terracotta
fill 549 229 255 549 231 256 minecraft:white_stained_glass
fill 549 229 270 549 231 270 minecraft:purple_terracotta
fill 553 229 228 553 231 228 minecraft:purple_terracotta
fill 553 229 270 553 231 270 minecraft:purple_terracotta
setblock 555 229 231 minecraft:light[level=12]
setblock 555 229 238 minecraft:light[level=12]
setblock 555 229 245 minecraft:light[level=12]
setblock 555 229 252 minecraft:light[level=12]
setblock 555 229 259 minecraft:light[level=12]
setblock 555 229 266 minecraft:light[level=12]
fill 557 229 228 557 231 228 minecraft:purple_terracotta
fill 557 229 270 557 231 270 minecraft:purple_terracotta
setblock 559 229 228 minecraft:purple_terracotta
fill 559 229 232 559 231 232 minecraft:purple_terracotta
fill 559 229 236 559 231 236 minecraft:purple_terracotta
fill 559 229 240 559 231 240 minecraft:purple_terracotta
fill 559 229 244 559 231 244 minecraft:purple_terracotta
fill 559 229 248 559 231 248 minecraft:purple_terracotta
fill 559 229 252 559 231 252 minecraft:purple_terracotta
fill 559 229 256 559 231 256 minecraft:purple_terracotta
fill 559 229 260 559 231 260 minecraft:purple_terracotta
fill 559 229 263 559 231 264 minecraft:purple_terracotta
fill 559 229 268 559 231 268 minecraft:purple_terracotta
setblock 517 230 230 minecraft:magenta_terracotta
setblock 517 230 234 minecraft:magenta_terracotta
setblock 517 230 238 minecraft:magenta_terracotta
setblock 517 230 242 minecraft:magenta_terracotta
setblock 517 230 246 minecraft:magenta_terracotta
setblock 517 230 250 minecraft:magenta_terracotta
setblock 517 230 254 minecraft:magenta_terracotta
setblock 517 230 258 minecraft:magenta_terracotta
setblock 517 230 262 minecraft:magenta_terracotta
setblock 517 230 266 minecraft:magenta_terracotta
setblock 517 230 270 minecraft:magenta_terracotta
setblock 519 230 228 minecraft:magenta_terracotta
setblock 519 230 270 minecraft:magenta_terracotta
fill 520 230 270 520 278 270 minecraft:purple_terracotta
setblock 523 230 228 minecraft:magenta_terracotta
setblock 523 230 270 minecraft:magenta_terracotta
setblock 527 230 228 minecraft:magenta_terracotta
schedule function dropper:buildpart/59_4 1t
