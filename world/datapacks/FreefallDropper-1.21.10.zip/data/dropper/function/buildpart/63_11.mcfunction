fill 144 281 290 144 288 290 minecraft:basalt
fill 144 281 293 144 288 293 minecraft:basalt
fill 144 281 296 144 288 296 minecraft:basalt
fill 144 281 299 144 287 299 minecraft:basalt
fill 144 281 302 144 286 302 minecraft:basalt
fill 144 281 305 144 284 305 minecraft:basalt
fill 144 281 308 144 282 308 minecraft:basalt
fill 144 281 310 147 281 310 minecraft:basalt
fill 145 281 277 147 281 277 minecraft:basalt
fill 145 281 311 149 281 311 minecraft:basalt
setblock 146 281 276 minecraft:magma_block
fill 146 281 290 146 290 290 minecraft:basalt
setblock 146 281 291 minecraft:magma_block
fill 146 281 292 146 290 292 minecraft:basalt
fill 146 281 296 146 290 296 minecraft:basalt
setblock 146 281 297 minecraft:magma_block
fill 146 281 298 146 290 298 minecraft:basalt
setblock 146 281 312 minecraft:magma_block
fill 147 281 276 150 282 276 minecraft:basalt
fill 147 281 280 147 285 280 minecraft:basalt
fill 147 281 283 147 287 283 minecraft:basalt
fill 147 281 286 147 288 288 minecraft:basalt
fill 147 281 300 147 290 301 minecraft:basalt
fill 147 281 304 147 288 304 minecraft:basalt
fill 147 281 307 151 286 307 minecraft:basalt
fill 147 281 312 147 281 313 minecraft:basalt
setblock 148 281 286 minecraft:basalt
fill 148 281 302 148 290 302 minecraft:basalt
fill 148 281 312 150 282 312 minecraft:basalt
setblock 149 281 284 minecraft:magma_block
fill 149 281 304 149 290 304 minecraft:basalt
setblock 149 281 314 minecraft:magma_block
fill 150 281 279 150 286 279 minecraft:basalt
fill 150 281 282 150 288 283 minecraft:basalt
fill 150 281 305 150 288 306 minecraft:basalt
fill 150 281 309 150 286 309 minecraft:basalt
fill 150 281 314 153 281 314 minecraft:basalt
fill 151 281 282 151 290 282 minecraft:basalt
fill 151 281 306 151 290 306 minecraft:basalt
fill 151 281 315 155 281 315 minecraft:basalt
setblock 152 281 307 minecraft:magma_block
fill 153 281 278 153 287 278 minecraft:basalt
fill 153 281 281 153 290 281 minecraft:basalt
fill 153 281 307 153 288 308 minecraft:basalt
fill 153 281 311 153 286 311 minecraft:basalt
fill 153 281 316 156 281 316 minecraft:basalt
fill 154 281 280 155 290 280 minecraft:basalt
fill 154 281 308 155 290 308 minecraft:basalt
fill 156 281 277 156 287 277 minecraft:basalt
fill 156 281 310 160 288 310 minecraft:basalt
fill 156 281 313 156 285 313 minecraft:basalt
fill 157 281 279 159 290 279 minecraft:basalt
fill 157 281 309 159 290 309 minecraft:basalt
setblock 159 281 275 minecraft:white_concrete
fill 159 281 276 159 287 276 minecraft:basalt
fill 159 281 312 159 287 312 minecraft:basalt
fill 159 281 315 159 283 315 minecraft:basalt
setblock 161 281 310 minecraft:magma_block
fill 162 281 278 162 288 278 minecraft:basalt
fill 162 281 310 162 288 311 minecraft:basalt
fill 162 281 314 162 285 314 minecraft:basalt
fill 163 281 279 163 290 279 minecraft:basalt
fill 163 281 309 163 289 310 minecraft:basalt
setblock 164 281 279 minecraft:magma_block
setblock 164 281 309 minecraft:magma_block
fill 164 281 310 165 288 310 minecraft:basalt
fill 165 281 277 165 288 277 minecraft:basalt
fill 165 281 279 165 290 279 minecraft:basalt
fill 165 281 309 165 290 309 minecraft:basalt
fill 165 281 313 165 285 313 minecraft:basalt
fill 165 281 316 169 281 316 minecraft:basalt
fill 167 281 280 168 290 280 minecraft:basalt
setblock 167 281 308 minecraft:magma_block
fill 168 281 276 168 285 276 minecraft:basalt
fill 168 281 279 168 288 279 minecraft:basalt
fill 168 281 308 168 288 309 minecraft:basalt
fill 168 281 312 168 285 312 minecraft:basalt
fill 168 281 315 171 281 315 minecraft:basalt
fill 169 281 281 169 290 281 minecraft:basalt
fill 169 281 307 169 290 307 minecraft:basalt
setblock 170 281 307 minecraft:magma_block
fill 171 281 278 178 281 278 minecraft:basalt
fill 171 281 281 171 288 282 minecraft:basalt
fill 171 281 306 171 288 308 minecraft:basalt
fill 171 281 311 177 281 311 minecraft:basalt
fill 171 281 314 173 281 314 minecraft:basalt
fill 172 281 283 172 290 283 minecraft:basalt
fill 172 281 305 172 290 305 minecraft:basalt
fill 172 281 307 180 281 307 minecraft:basalt
fill 173 281 284 173 290 284 minecraft:basalt
fill 173 281 304 174 288 304 minecraft:basalt
setblock 174 281 275 minecraft:white_concrete
fill 174 281 277 177 281 277 minecraft:basalt
fill 174 281 280 180 281 280 minecraft:basalt
fill 174 281 283 181 281 283 minecraft:basalt
fill 174 281 286 174 290 286 minecraft:basalt
fill 174 281 302 174 290 302 minecraft:basalt
fill 174 281 310 178 281 310 minecraft:basalt
fill 174 281 313 175 281 313 minecraft:basalt
fill 175 281 287 175 290 288 minecraft:basalt
fill 175 281 300 176 289 301 minecraft:basalt
setblock 176 281 290 minecraft:magma_block
fill 176 281 291 176 290 292 minecraft:basalt
setblock 176 281 296 minecraft:magma_block
fill 176 281 297 176 290 298 minecraft:basalt
setblock 176 281 299 minecraft:magma_block
fill 177 281 279 179 281 279 minecraft:basalt
fill 177 281 282 181 281 282 minecraft:basalt
fill 177 281 285 181 283 285 minecraft:basalt
fill 177 281 288 177 288 288 minecraft:basalt
fill 177 281 291 177 288 291 minecraft:basalt
fill 177 281 294 177 288 294 minecraft:basalt
fill 177 281 297 177 288 297 minecraft:basalt
fill 177 281 300 177 288 300 minecraft:basalt
fill 177 281 303 181 283 303 minecraft:basalt
fill 177 281 306 181 281 306 minecraft:basalt
fill 177 281 309 179 281 309 minecraft:basalt
setblock 180 281 281 minecraft:basalt
fill 180 281 284 180 283 284 minecraft:basalt
fill 180 281 287 180 284 287 minecraft:basalt
fill 180 281 290 180 285 290 minecraft:basalt
fill 180 281 293 180 286 293 minecraft:basalt
fill 180 281 296 180 286 296 minecraft:basalt
fill 180 281 299 180 285 299 minecraft:basalt
fill 180 281 302 180 284 302 minecraft:basalt
fill 180 281 305 181 281 305 minecraft:basalt
setblock 180 281 308 minecraft:basalt
setblock 182 281 285 minecraft:magma_block
setblock 182 281 303 minecraft:magma_block
fill 141 282 286 141 308 286 minecraft:snow_block
setblock 142 282 282 minecraft:magma_block
fill 142 282 283 143 282 305 minecraft:basalt
setblock 142 282 306 minecraft:magma_block
fill 143 282 280 143 282 282 minecraft:basalt
fill 143 282 306 143 282 308 minecraft:basalt
setblock 144 282 278 minecraft:light[level=12]
setblock 144 282 313 minecraft:light[level=12]
setblock 145 282 278 minecraft:magma_block
fill 145 282 310 147 282 310 minecraft:basalt
fill 146 282 277 147 282 278 minecraft:basalt
fill 146 282 291 146 289 291 minecraft:basalt
fill 146 282 293 146 289 295 minecraft:basalt
fill 146 282 297 146 289 297 minecraft:basalt
fill 146 282 311 149 282 311 minecraft:basalt
fill 147 282 289 147 291 290 minecraft:basalt
fill 147 282 298 147 291 299 minecraft:basalt
setblock 147 282 312 minecraft:basalt
fill 148 282 278 152 284 278 minecraft:basalt
setblock 148 282 286 minecraft:magma_block
fill 148 282 287 148 291 287 minecraft:basalt
setblock 148 282 301 minecraft:magma_block
fill 149 282 284 149 289 285 minecraft:basalt
fill 149 282 303 149 290 303 minecraft:basalt
fill 149 282 313 155 282 313 minecraft:basalt
fill 150 282 284 150 291 284 minecraft:basalt
fill 150 282 304 150 291 304 minecraft:basalt
fill 151 282 283 151 291 283 minecraft:basalt
setblock 151 282 285 minecraft:light[level=12]
setblock 151 282 292 minecraft:light[level=12]
setblock 151 282 299 minecraft:light[level=12]
fill 151 282 305 151 291 305 minecraft:basalt
fill 151 282 314 153 282 314 minecraft:basalt
fill 152 282 282 152 290 282 minecraft:basalt
fill 152 282 306 152 289 307 minecraft:basalt
fill 153 282 315 155 282 315 minecraft:basalt
setblock 154 282 281 minecraft:magma_block
fill 154 282 307 154 291 307 minecraft:basalt
fill 155 282 316 156 282 316 minecraft:basalt
fill 156 282 280 156 291 280 minecraft:basalt
fill 156 282 308 157 291 308 minecraft:basalt
setblock 157 282 280 minecraft:magma_block
setblock 157 282 316 minecraft:magma_block
setblock 158 282 285 minecraft:light[level=12]
setblock 158 282 292 minecraft:light[level=12]
setblock 158 282 299 minecraft:light[level=12]
setblock 158 282 306 minecraft:light[level=12]
fill 158 282 316 165 282 316 minecraft:basalt
fill 159 282 275 159 308 275 minecraft:snow_block
setblock 160 282 279 minecraft:magma_block
setblock 160 282 309 minecraft:magma_block
fill 161 282 279 162 290 279 minecraft:basalt
fill 161 282 309 161 289 310 minecraft:basalt
fill 162 282 309 162 290 309 minecraft:basalt
fill 164 282 279 164 289 279 minecraft:basalt
fill 164 282 309 164 289 309 minecraft:basalt
fill 165 282 280 165 291 280 minecraft:basalt
setblock 165 282 285 minecraft:light[level=12]
setblock 165 282 292 minecraft:light[level=12]
setblock 165 282 299 minecraft:light[level=12]
setblock 165 282 306 minecraft:light[level=12]
fill 165 282 308 167 289 308 minecraft:basalt
setblock 166 282 280 minecraft:magma_block
setblock 166 282 316 minecraft:magma_block
setblock 167 282 316 minecraft:basalt
fill 168 282 281 168 291 281 minecraft:basalt
fill 168 282 307 168 291 307 minecraft:basalt
setblock 168 282 315 minecraft:basalt
fill 169 282 276 175 282 276 minecraft:basalt
fill 169 282 312 175 282 312 minecraft:basalt
setblock 169 282 315 minecraft:magma_block
fill 170 282 282 170 290 282 minecraft:basalt
fill 170 282 306 170 289 307 minecraft:basalt
fill 171 282 278 177 282 278 minecraft:basalt
fill 171 282 283 171 291 283 minecraft:basalt
fill 171 282 305 171 291 305 minecraft:basalt
fill 171 282 311 176 282 311 minecraft:basalt
setblock 171 282 314 minecraft:basalt
setblock 172 282 284 minecraft:magma_block
setblock 172 282 285 minecraft:light[level=12]
setblock 172 282 292 minecraft:light[level=12]
setblock 172 282 299 minecraft:light[level=12]
fill 172 282 304 172 291 304 minecraft:basalt
fill 172 282 307 179 282 307 minecraft:basalt
fill 173 282 285 173 289 285 minecraft:basalt
fill 173 282 303 173 289 303 minecraft:basalt
fill 174 282 275 174 308 275 minecraft:snow_block
fill 174 282 277 174 283 277 minecraft:basalt
fill 174 282 280 179 282 280 minecraft:basalt
fill 174 282 283 180 282 283 minecraft:basalt
fill 174 282 287 174 291 287 minecraft:basalt
fill 174 282 301 174 291 301 minecraft:basalt
fill 174 282 310 177 282 310 minecraft:basalt
setblock 175 282 277 minecraft:magma_block
setblock 175 282 289 minecraft:magma_block
fill 175 282 290 176 289 290 minecraft:basalt
setblock 175 282 298 minecraft:magma_block
fill 175 282 299 176 289 299 minecraft:basalt
fill 175 282 304 181 282 304 minecraft:basalt
setblock 176 282 277 minecraft:basalt
fill 176 282 293 176 289 296 minecraft:basalt
fill 177 282 279 177 283 279 minecraft:basalt
fill 177 282 282 180 282 282 minecraft:basalt
fill 177 282 306 180 282 306 minecraft:basalt
fill 177 282 309 177 283 309 minecraft:basalt
setblock 178 282 279 minecraft:magma_block
setblock 178 282 309 minecraft:magma_block
setblock 179 282 278 minecraft:light[level=12]
setblock 179 282 313 minecraft:light[level=12]
setblock 180 282 305 minecraft:basalt
setblock 181 282 284 minecraft:magma_block
setblock 183 282 286 minecraft:white_concrete
setblock 141 283 304 minecraft:light_blue_concrete
fill 141 283 305 142 283 305 minecraft:snow_block
setblock 142 283 283 minecraft:packed_ice
fill 142 283 284 143 283 304 minecraft:basalt
fill 142 283 306 142 283 309 minecraft:packed_ice
setblock 142 283 310 minecraft:snow_block
fill 142 283 311 142 283 314 minecraft:packed_ice
setblock 142 283 315 minecraft:snow_block
setblock 142 283 317 minecraft:light_blue_concrete
fill 143 283 282 143 283 283 minecraft:basalt
fill 143 283 305 143 283 306 minecraft:basalt
fill 143 283 317 144 308 317 minecraft:snow_block
fill 144 283 306 146 284 306 minecraft:basalt
setblock 144 283 307 minecraft:magma_block
fill 145 283 279 146 283 280 minecraft:basalt
fill 145 283 307 146 284 307 minecraft:basalt
fill 145 283 309 149 283 309 minecraft:basalt
fill 146 283 278 147 283 278 minecraft:basalt
fill 146 283 310 147 283 310 minecraft:basalt
setblock 147 283 291 minecraft:magma_block
fill 147 283 292 147 291 293 minecraft:basalt
setblock 147 283 294 minecraft:magma_block
fill 147 283 295 147 291 296 minecraft:basalt
setblock 147 283 297 minecraft:magma_block
fill 148 283 286 149 290 286 minecraft:basalt
fill 148 283 288 148 291 289 minecraft:basalt
fill 148 283 299 148 290 301 minecraft:basalt
fill 148 283 311 149 283 311 minecraft:basalt
fill 149 283 276 150 283 276 minecraft:basalt
fill 149 283 287 149 292 287 minecraft:basalt
fill 149 283 301 149 283 302 minecraft:basalt
fill 149 283 312 150 283 312 minecraft:basalt
fill 150 283 285 150 291 285 minecraft:basalt
fill 150 283 303 150 291 303 minecraft:basalt
fill 151 283 284 151 291 284 minecraft:basalt
fill 151 283 304 151 291 304 minecraft:basalt
fill 151 283 313 155 283 313 minecraft:basalt
fill 152 283 283 152 291 283 minecraft:basalt
fill 152 283 305 152 291 305 minecraft:basalt
fill 152 283 314 153 283 314 minecraft:basalt
fill 153 283 282 154 291 282 minecraft:basalt
fill 153 283 306 154 291 306 minecraft:basalt
fill 153 283 316 155 283 316 minecraft:packed_ice
fill 154 283 281 156 290 281 minecraft:basalt
fill 155 283 307 156 291 307 minecraft:basalt
setblock 155 283 315 minecraft:basalt
setblock 156 283 315 minecraft:magma_block
setblock 156 283 316 minecraft:snow_block
fill 157 283 280 161 290 280 minecraft:basalt
fill 157 283 315 158 283 315 minecraft:basalt
fill 157 283 316 160 283 316 minecraft:packed_ice
fill 158 283 308 158 291 308 minecraft:basalt
setblock 159 283 308 minecraft:magma_block
fill 160 283 279 160 290 279 minecraft:basalt
fill 160 283 308 160 290 309 minecraft:basalt
fill 160 283 315 164 283 315 minecraft:basalt
fill 161 283 308 164 290 308 minecraft:basalt
setblock 161 283 316 minecraft:snow_block
setblock 162 283 280 minecraft:magma_block
fill 162 283 316 165 283 316 minecraft:packed_ice
fill 163 283 280 164 291 280 minecraft:basalt
fill 163 283 314 167 283 314 minecraft:basalt
setblock 165 283 315 minecraft:magma_block
fill 166 283 280 166 290 281 minecraft:basalt
fill 166 283 307 167 291 307 minecraft:basalt
fill 166 283 313 170 284 313 minecraft:basalt
fill 166 283 315 167 283 315 minecraft:basalt
setblock 166 283 316 minecraft:snow_block
fill 167 283 281 167 291 281 minecraft:basalt
fill 167 283 316 170 283 316 minecraft:packed_ice
fill 168 283 282 169 290 282 minecraft:basalt
fill 168 283 306 169 290 306 minecraft:basalt
setblock 168 283 314 minecraft:magma_block
fill 169 283 276 173 283 276 minecraft:basalt
fill 169 283 312 173 283 312 minecraft:basalt
fill 169 283 314 170 283 314 minecraft:basalt
fill 170 283 283 170 291 283 minecraft:basalt
fill 170 283 305 170 291 305 minecraft:basalt
fill 170 283 315 171 283 315 minecraft:packed_ice
fill 171 283 278 176 283 278 minecraft:basalt
fill 171 283 284 172 290 284 minecraft:basalt
setblock 171 283 304 minecraft:magma_block
fill 171 283 311 174 283 311 minecraft:basalt
setblock 171 283 313 minecraft:magma_block
setblock 171 283 316 minecraft:snow_block
fill 172 283 285 172 291 285 minecraft:basalt
fill 172 283 303 172 291 303 minecraft:basalt
fill 172 283 307 176 284 308 minecraft:basalt
setblock 172 283 315 minecraft:snow_block
fill 172 283 316 175 283 316 minecraft:packed_ice
fill 173 283 286 173 283 287 minecraft:basalt
fill 173 283 301 173 291 302 minecraft:basalt
setblock 173 283 314 minecraft:snow_block
fill 173 283 315 176 283 315 minecraft:packed_ice
fill 174 283 280 177 283 280 minecraft:basalt
fill 174 283 283 179 283 283 minecraft:basalt
setblock 174 283 288 minecraft:magma_block
fill 174 283 289 175 290 289 minecraft:basalt
fill 174 283 299 174 292 299 minecraft:basalt
setblock 174 283 300 minecraft:magma_block
fill 174 283 310 176 283 310 minecraft:basalt
fill 174 283 314 177 283 314 minecraft:packed_ice
fill 175 283 286 181 283 286 minecraft:basalt
fill 175 283 291 175 290 298 minecraft:basalt
fill 175 283 304 179 284 304 minecraft:basalt
fill 176 283 313 178 283 313 minecraft:packed_ice
setblock 176 283 316 minecraft:snow_block
fill 177 283 281 178 283 282 minecraft:basalt
fill 177 283 301 181 283 301 minecraft:basalt
fill 177 283 306 178 283 307 minecraft:basalt
setblock 177 283 308 minecraft:magma_block
setblock 177 283 315 minecraft:snow_block
fill 177 283 316 180 283 316 minecraft:packed_ice
setblock 178 283 314 minecraft:snow_block
fill 178 283 315 181 283 315 minecraft:packed_ice
setblock 179 283 282 minecraft:basalt
setblock 179 283 306 minecraft:basalt
fill 179 283 309 179 283 312 minecraft:packed_ice
fill 179 283 314 182 283 314 minecraft:packed_ice
setblock 180 283 304 minecraft:magma_block
setblock 180 283 306 minecraft:packed_ice
setblock 180 283 307 minecraft:snow_block
fill 180 283 308 180 283 311 minecraft:packed_ice
setblock 180 283 312 minecraft:snow_block
fill 180 283 313 182 284 313 minecraft:packed_ice
setblock 181 283 287 minecraft:basalt
setblock 181 283 302 minecraft:basalt
fill 181 283 304 181 283 305 minecraft:packed_ice
setblock 181 283 306 minecraft:snow_block
fill 181 283 307 181 283 310 minecraft:packed_ice
setblock 181 283 311 minecraft:snow_block
fill 181 283 312 182 285 312 minecraft:packed_ice
setblock 181 283 316 minecraft:snow_block
setblock 182 283 285 minecraft:snow_block
fill 182 283 286 182 284 287 minecraft:packed_ice
fill 182 283 301 182 283 304 minecraft:packed_ice
setblock 182 283 305 minecraft:snow_block
fill 182 283 306 182 283 309 minecraft:packed_ice
setblock 182 283 310 minecraft:snow_block
fill 182 283 311 182 286 311 minecraft:packed_ice
setblock 182 283 315 minecraft:snow_block
fill 182 283 316 182 286 316 minecraft:packed_ice
fill 183 283 286 183 308 286 minecraft:snow_block
setblock 183 283 307 minecraft:white_concrete
fill 183 283 308 183 308 308 minecraft:snow_block
setblock 141 284 285 minecraft:light_blue_concrete
fill 141 284 289 141 308 289 minecraft:snow_block
setblock 141 284 290 minecraft:light_blue_concrete
fill 141 284 304 141 308 305 minecraft:snow_block
setblock 142 284 284 minecraft:snow_block
fill 142 284 285 143 284 303 minecraft:basalt
setblock 142 284 308 minecraft:packed_ice
setblock 142 284 309 minecraft:snow_block
fill 142 284 310 142 284 313 minecraft:packed_ice
setblock 142 284 314 minecraft:snow_block
fill 142 284 317 142 306 317 minecraft:snow_block
setblock 143 284 284 minecraft:basalt
setblock 143 284 304 minecraft:basalt
setblock 146 284 280 minecraft:basalt
setblock 146 284 308 minecraft:magma_block
fill 147 284 291 148 284 291 minecraft:basalt
fill 147 284 294 147 291 294 minecraft:basalt
fill 147 284 297 148 284 297 minecraft:basalt
fill 147 284 308 149 284 309 minecraft:basalt
fill 147 284 313 147 288 313 minecraft:packed_ice
fill 148 284 290 148 292 290 minecraft:basalt
fill 148 284 298 148 292 298 minecraft:basalt
setblock 149 284 277 minecraft:magma_block
fill 149 284 288 149 292 288 minecraft:basalt
fill 149 284 300 149 292 300 minecraft:basalt
setblock 149 284 301 minecraft:magma_block
fill 149 284 302 150 291 302 minecraft:basalt
setblock 149 284 311 minecraft:basalt
fill 150 284 277 155 284 277 minecraft:basalt
fill 150 284 286 150 292 286 minecraft:basalt
fill 150 284 308 152 287 308 minecraft:basalt
fill 151 284 285 151 292 285 minecraft:basalt
fill 151 284 303 151 292 303 minecraft:basalt
setblock 152 284 275 minecraft:light_blue_concrete
fill 152 284 284 152 292 284 minecraft:basalt
fill 152 284 304 152 292 304 minecraft:basalt
fill 152 284 313 155 284 313 minecraft:basalt
fill 152 284 316 154 284 316 minecraft:packed_ice
fill 153 284 283 153 291 283 minecraft:basalt
fill 153 284 305 153 292 305 minecraft:basalt
setblock 153 284 317 minecraft:light_blue_concrete
fill 154 284 315 155 284 315 minecraft:packed_ice
fill 155 284 282 155 292 282 minecraft:basalt
fill 155 284 306 155 292 306 minecraft:basalt
setblock 155 284 314 minecraft:magma_block
setblock 155 284 316 minecraft:snow_block
fill 156 284 314 161 284 314 minecraft:basalt
setblock 156 284 315 minecraft:snow_block
fill 156 284 316 159 284 316 minecraft:packed_ice
fill 157 284 281 158 292 281 minecraft:basalt
fill 157 284 307 157 292 307 minecraft:basalt
fill 157 284 315 159 285 315 minecraft:packed_ice
setblock 158 284 307 minecraft:magma_block
fill 159 284 308 159 291 308 minecraft:basalt
setblock 160 284 315 minecraft:basalt
setblock 160 284 316 minecraft:snow_block
setblock 161 284 315 minecraft:magma_block
fill 161 284 316 164 284 316 minecraft:packed_ice
fill 162 284 280 162 291 280 minecraft:basalt
setblock 162 284 315 minecraft:basalt
fill 163 284 314 163 285 314 minecraft:basalt
fill 163 284 315 165 284 315 minecraft:packed_ice
setblock 164 284 281 minecraft:magma_block
fill 164 284 307 165 292 307 minecraft:basalt
setblock 164 284 314 minecraft:magma_block
fill 165 284 281 165 292 281 minecraft:basalt
fill 165 284 314 167 284 314 minecraft:basalt
setblock 165 284 316 minecraft:snow_block
fill 166 284 316 169 284 316 minecraft:packed_ice
fill 167 284 282 167 292 282 minecraft:basalt
fill 167 284 306 167 292 306 minecraft:basalt
fill 169 284 276 171 284 276 minecraft:basalt
fill 169 284 283 169 292 283 minecraft:basalt
fill 169 284 305 169 292 305 minecraft:basalt
fill 169 284 312 171 284 312 minecraft:basalt
fill 169 284 315 170 284 315 minecraft:packed_ice
fill 170 284 284 170 292 284 minecraft:basalt
fill 170 284 304 171 291 304 minecraft:basalt
setblock 170 284 316 minecraft:snow_block
fill 171 284 278 174 284 278 minecraft:basalt
fill 171 284 285 171 292 285 minecraft:basalt
fill 171 284 303 171 292 303 minecraft:basalt
fill 171 284 309 175 284 309 minecraft:basalt
fill 171 284 311 172 284 311 minecraft:basalt
setblock 171 284 315 minecraft:snow_block
fill 171 284 316 174 284 316 minecraft:packed_ice
fill 172 284 286 173 291 286 minecraft:basalt
fill 172 284 302 172 292 302 minecraft:basalt
setblock 172 284 314 minecraft:snow_block
fill 172 284 315 175 284 315 minecraft:packed_ice
setblock 173 284 287 minecraft:magma_block
fill 173 284 288 174 291 288 minecraft:basalt
fill 173 284 300 174 291 300 minecraft:basalt
fill 173 284 305 178 284 305 minecraft:basalt
setblock 173 284 311 minecraft:magma_block
fill 173 284 314 176 284 314 minecraft:packed_ice
fill 174 284 279 175 284 280 minecraft:basalt
fill 174 284 283 178 284 283 minecraft:basalt
fill 174 284 290 174 291 291 minecraft:basalt
fill 174 284 297 174 291 298 minecraft:basalt
setblock 174 284 310 minecraft:basalt
fill 175 284 286 180 284 286 minecraft:basalt
setblock 175 284 316 minecraft:snow_block
setblock 176 284 280 minecraft:magma_block
fill 176 284 313 177 284 313 minecraft:packed_ice
setblock 176 284 315 minecraft:snow_block
fill 176 284 316 179 284 316 minecraft:packed_ice
fill 177 284 281 177 284 282 minecraft:basalt
fill 177 284 285 180 284 285 minecraft:basalt
fill 177 284 301 180 284 301 minecraft:basalt
fill 177 284 303 180 284 303 minecraft:basalt
fill 177 284 306 177 284 307 minecraft:basalt
setblock 177 284 314 minecraft:snow_block
fill 177 284 315 180 284 315 minecraft:packed_ice
setblock 178 284 282 minecraft:basalt
fill 178 284 288 181 284 288 minecraft:basalt
fill 178 284 291 181 284 291 minecraft:basalt
fill 178 284 297 181 284 297 minecraft:basalt
fill 178 284 300 181 284 300 minecraft:basalt
setblock 178 284 306 minecraft:basalt
fill 178 284 314 181 284 314 minecraft:packed_ice
fill 180 284 289 181 284 289 minecraft:basalt
fill 180 284 292 181 284 292 minecraft:basalt
fill 180 284 298 181 284 298 minecraft:basalt
fill 180 284 308 180 284 310 minecraft:packed_ice
setblock 180 284 311 minecraft:snow_block
fill 180 284 312 180 285 312 minecraft:packed_ice
setblock 180 284 316 minecraft:snow_block
setblock 181 284 290 minecraft:basalt
fill 181 284 293 181 285 293 minecraft:basalt
fill 181 284 296 181 285 296 minecraft:basalt
setblock 181 284 299 minecraft:basalt
setblock 181 284 305 minecraft:snow_block
fill 181 284 306 181 284 309 minecraft:packed_ice
setblock 181 284 310 minecraft:snow_block
fill 181 284 311 181 286 311 minecraft:packed_ice
setblock 181 284 315 minecraft:snow_block
fill 181 284 316 181 287 316 minecraft:packed_ice
setblock 182 284 288 minecraft:packed_ice
setblock 182 284 289 minecraft:snow_block
fill 182 284 290 182 285 292 minecraft:packed_ice
setblock 182 284 293 minecraft:magma_block
fill 182 284 296 182 284 298 minecraft:packed_ice
setblock 182 284 299 minecraft:snow_block
fill 182 284 300 182 284 303 minecraft:packed_ice
setblock 182 284 304 minecraft:snow_block
fill 182 284 305 182 284 308 minecraft:packed_ice
setblock 182 284 309 minecraft:snow_block
fill 182 284 310 182 287 310 minecraft:packed_ice
setblock 182 284 314 minecraft:snow_block
fill 182 284 315 182 287 315 minecraft:packed_ice
setblock 183 284 289 minecraft:white_concrete
fill 183 284 307 183 292 307 minecraft:snow_block
setblock 141 285 285 minecraft:snow_block
fill 141 285 290 141 308 290 minecraft:snow_block
fill 142 285 285 142 285 287 minecraft:packed_ice
fill 142 285 288 143 285 289 minecraft:basalt
setblock 142 285 290 minecraft:magma_block
fill 142 285 291 143 285 298 minecraft:basalt
setblock 142 285 299 minecraft:magma_block
fill 142 285 300 143 285 300 minecraft:basalt
fill 143 285 285 143 285 287 minecraft:basalt
fill 143 285 290 143 286 290 minecraft:basalt
fill 143 285 299 143 286 299 minecraft:basalt
fill 143 285 301 143 285 303 minecraft:basalt
fill 145 285 282 146 285 282 minecraft:basalt
setblock 145 285 283 minecraft:magma_block
fill 145 285 306 146 285 306 minecraft:basalt
fill 146 285 281 152 285 281 minecraft:basalt
fill 146 285 283 146 286 283 minecraft:basalt
setblock 146 285 307 minecraft:basalt
fill 147 285 291 147 291 291 minecraft:basalt
fill 147 285 297 147 291 297 minecraft:basalt
fill 147 285 308 149 285 308 minecraft:basalt
setblock 148 285 279 minecraft:magma_block
setblock 148 285 291 minecraft:magma_block
fill 148 285 292 148 293 293 minecraft:basalt
setblock 148 285 294 minecraft:magma_block
fill 148 285 295 148 293 296 minecraft:basalt
setblock 148 285 297 minecraft:magma_block
setblock 148 285 309 minecraft:magma_block
fill 149 285 278 149 285 279 minecraft:basalt
fill 149 285 289 149 292 290 minecraft:basalt
fill 149 285 298 149 292 299 minecraft:basalt
fill 149 285 301 150 292 301 minecraft:basalt
fill 149 285 309 149 285 310 minecraft:basalt
fill 150 285 278 152 285 278 minecraft:basalt
fill 150 285 287 150 293 287 minecraft:basalt
fill 150 285 310 155 285 310 minecraft:basalt
fill 151 285 276 151 287 276 minecraft:packed_ice
fill 151 285 277 155 285 277 minecraft:basalt
fill 151 285 286 151 293 286 minecraft:basalt
setblock 151 285 302 minecraft:magma_block
setblock 151 285 311 minecraft:magma_block
fill 151 285 316 153 285 316 minecraft:packed_ice
fill 152 285 275 152 308 275 minecraft:snow_block
fill 152 285 276 158 285 276 minecraft:basalt
fill 152 285 285 152 292 285 minecraft:basalt
fill 152 285 303 152 292 303 minecraft:basalt
fill 152 285 311 152 285 312 minecraft:basalt
fill 153 285 284 153 293 284 minecraft:basalt
fill 153 285 304 153 293 304 minecraft:basalt
fill 153 285 312 158 285 312 minecraft:basalt
fill 153 285 315 154 285 315 minecraft:packed_ice
fill 153 285 317 153 308 317 minecraft:snow_block
setblock 154 285 283 minecraft:magma_block
fill 154 285 305 154 293 305 minecraft:basalt
setblock 154 285 316 minecraft:snow_block
setblock 155 285 313 minecraft:basalt
setblock 155 285 315 minecraft:snow_block
fill 155 285 316 158 285 316 minecraft:packed_ice
fill 156 285 282 156 293 282 minecraft:basalt
fill 156 285 306 156 293 306 minecraft:basalt
setblock 156 285 314 minecraft:snow_block
fill 156 285 315 156 288 315 minecraft:packed_ice
setblock 157 285 282 minecraft:magma_block
setblock 157 285 306 minecraft:magma_block
fill 157 285 314 158 287 314 minecraft:packed_ice
fill 158 285 307 162 292 307 minecraft:basalt
fill 159 285 281 159 291 281 minecraft:basalt
setblock 159 285 314 minecraft:basalt
setblock 159 285 316 minecraft:snow_block
setblock 160 285 281 minecraft:magma_block
setblock 160 285 314 minecraft:magma_block
setblock 160 285 315 minecraft:snow_block
fill 160 285 316 163 285 316 minecraft:packed_ice
fill 161 285 281 164 292 281 minecraft:basalt
setblock 161 285 314 minecraft:basalt
fill 161 285 315 164 285 315 minecraft:packed_ice
setblock 163 285 307 minecraft:magma_block
setblock 164 285 316 minecraft:snow_block
fill 165 285 282 165 293 282 minecraft:basalt
fill 165 285 306 165 293 306 minecraft:basalt
setblock 165 285 315 minecraft:snow_block
fill 165 285 316 168 285 316 minecraft:packed_ice
fill 166 285 277 171 285 277 minecraft:basalt
setblock 166 285 282 minecraft:magma_block
setblock 166 285 306 minecraft:magma_block
fill 166 285 313 167 285 313 minecraft:basalt
fill 168 285 283 168 293 283 minecraft:basalt
fill 168 285 305 168 293 305 minecraft:basalt
fill 168 285 310 171 286 310 minecraft:basalt
fill 168 285 315 169 285 315 minecraft:packed_ice
fill 169 285 276 170 285 276 minecraft:basalt
setblock 169 285 284 minecraft:magma_block
fill 169 285 304 169 293 304 minecraft:basalt
fill 169 285 312 170 285 312 minecraft:basalt
setblock 169 285 316 minecraft:snow_block
fill 170 285 285 170 292 285 minecraft:basalt
fill 170 285 303 170 292 303 minecraft:basalt
setblock 170 285 315 minecraft:snow_block
fill 170 285 316 173 285 316 minecraft:packed_ice
fill 171 285 278 173 285 278 minecraft:basalt
fill 171 285 286 171 293 286 minecraft:basalt
fill 171 285 302 171 293 302 minecraft:basalt
fill 171 285 309 174 285 309 minecraft:basalt
setblock 171 285 311 minecraft:basalt
fill 171 285 315 174 285 315 minecraft:packed_ice
fill 172 285 287 173 292 287 minecraft:basalt
setblock 172 285 301 minecraft:magma_block
fill 172 285 307 175 285 308 minecraft:basalt
setblock 172 285 310 minecraft:magma_block
fill 172 285 314 175 285 314 minecraft:packed_ice
fill 173 285 289 173 292 290 minecraft:basalt
fill 173 285 298 173 292 299 minecraft:basalt
fill 173 285 305 177 285 305 minecraft:basalt
setblock 173 285 310 minecraft:basalt
fill 174 285 279 174 285 280 minecraft:basalt
fill 174 285 283 177 285 283 minecraft:basalt
fill 174 285 292 174 293 296 minecraft:basalt
setblock 174 285 316 minecraft:snow_block
fill 175 285 276 177 286 276 minecraft:packed_ice
setblock 175 285 280 minecraft:basalt
fill 175 285 286 179 285 286 minecraft:basalt
fill 175 285 304 178 285 304 minecraft:basalt
setblock 175 285 315 minecraft:snow_block
fill 175 285 316 178 285 316 minecraft:packed_ice
setblock 176 285 307 minecraft:basalt
setblock 176 285 314 minecraft:snow_block
fill 176 285 315 179 285 315 minecraft:packed_ice
setblock 177 285 282 minecraft:basalt
fill 177 285 284 177 286 285 minecraft:basalt
fill 177 285 301 179 285 301 minecraft:basalt
fill 177 285 303 179 285 303 minecraft:basalt
setblock 177 285 306 minecraft:basalt
fill 177 285 314 179 286 314 minecraft:packed_ice
setblock 178 285 284 minecraft:magma_block
fill 178 285 285 179 285 285 minecraft:basalt
fill 178 285 288 180 285 288 minecraft:basalt
fill 178 285 291 180 285 291 minecraft:basalt
fill 178 285 294 181 285 294 minecraft:basalt
fill 178 285 297 180 285 297 minecraft:basalt
fill 178 285 300 180 285 300 minecraft:basalt
setblock 179 285 316 minecraft:snow_block
setblock 180 285 289 minecraft:basalt
fill 180 285 292 180 286 292 minecraft:basalt
fill 180 285 295 180 286 295 minecraft:basalt
setblock 180 285 298 minecraft:basalt
setblock 180 285 310 minecraft:snow_block
setblock 180 285 311 minecraft:packed_ice
fill 180 285 313 181 285 313 minecraft:packed_ice
setblock 180 285 315 minecraft:snow_block
fill 180 285 316 180 288 316 minecraft:packed_ice
setblock 181 285 289 minecraft:snow_block
fill 181 285 290 181 287 291 minecraft:packed_ice
setblock 181 285 292 minecraft:magma_block
setblock 181 285 295 minecraft:magma_block
fill 181 285 297 182 285 297 minecraft:packed_ice
fill 181 285 307 181 285 308 minecraft:packed_ice
setblock 181 285 309 minecraft:snow_block
fill 181 285 310 181 286 310 minecraft:packed_ice
setblock 181 285 314 minecraft:snow_block
setblock 181 285 315 minecraft:packed_ice
setblock 182 285 287 minecraft:packed_ice
setblock 182 285 288 minecraft:snow_block
fill 182 285 289 182 288 289 minecraft:packed_ice
setblock 182 285 293 minecraft:snow_block
fill 182 285 294 182 286 296 minecraft:packed_ice
setblock 182 285 298 minecraft:snow_block
fill 182 285 299 182 285 301 minecraft:packed_ice
fill 182 285 304 182 285 307 minecraft:packed_ice
setblock 182 285 308 minecraft:snow_block
fill 182 285 309 182 287 309 minecraft:packed_ice
setblock 182 285 313 minecraft:snow_block
fill 182 285 314 182 288 314 minecraft:packed_ice
fill 183 285 289 183 308 289 minecraft:snow_block
setblock 141 286 285 minecraft:white_concrete
setblock 142 286 286 minecraft:packed_ice
setblock 142 286 287 minecraft:snow_block
fill 142 286 288 142 287 290 minecraft:packed_ice
fill 142 286 291 143 286 297 minecraft:basalt
fill 142 286 298 142 289 298 minecraft:packed_ice
fill 143 286 288 143 286 289 minecraft:basalt
setblock 143 286 298 minecraft:basalt
setblock 143 286 300 minecraft:basalt
setblock 144 286 285 minecraft:magma_block
fill 144 286 286 146 286 286 minecraft:basalt
setblock 144 286 303 minecraft:magma_block
fill 145 286 285 146 287 285 minecraft:basalt
fill 145 286 303 146 286 304 minecraft:basalt
setblock 146 286 282 minecraft:basalt
fill 146 286 305 146 286 306 minecraft:basalt
setblock 147 286 281 minecraft:magma_block
fill 147 286 305 149 287 305 minecraft:basalt
fill 148 286 281 152 287 281 minecraft:basalt
fill 148 286 291 149 292 291 minecraft:basalt
fill 148 286 294 149 286 294 minecraft:basalt
fill 148 286 297 149 292 297 minecraft:basalt
fill 148 286 308 149 286 308 minecraft:basalt
setblock 149 286 279 minecraft:basalt
fill 149 286 292 149 294 293 minecraft:basalt
fill 149 286 295 149 294 296 minecraft:basalt
setblock 149 286 309 minecraft:basalt
fill 150 286 276 150 288 276 minecraft:packed_ice
fill 150 286 288 150 293 288 minecraft:basalt
setblock 150 286 289 minecraft:magma_block
fill 150 286 299 150 293 300 minecraft:basalt
fill 150 286 316 152 286 316 minecraft:packed_ice
fill 151 286 278 152 286 278 minecraft:basalt
fill 151 286 287 151 293 287 minecraft:basalt
fill 151 286 301 151 293 302 minecraft:basalt
fill 151 286 310 155 286 310 minecraft:basalt
setblock 152 286 276 minecraft:packed_ice
fill 152 286 277 155 286 277 minecraft:basalt
fill 152 286 286 152 294 286 minecraft:basalt
fill 152 286 302 152 294 302 minecraft:basalt
setblock 152 286 311 minecraft:basalt
fill 152 286 315 153 286 315 minecraft:packed_ice
setblock 152 286 317 minecraft:white_concrete
setblock 153 286 276 minecraft:snow_block
setblock 153 286 285 minecraft:magma_block
setblock 153 286 303 minecraft:magma_block
setblock 153 286 316 minecraft:snow_block
fill 154 286 276 154 289 276 minecraft:packed_ice
fill 154 286 283 154 293 284 minecraft:basalt
fill 154 286 304 154 293 304 minecraft:basalt
setblock 154 286 315 minecraft:snow_block
fill 154 286 316 157 286 316 minecraft:packed_ice
fill 155 286 276 158 286 276 minecraft:basalt
fill 155 286 283 156 293 283 minecraft:basalt
fill 155 286 305 155 292 305 minecraft:basalt
fill 155 286 312 158 286 312 minecraft:basalt
setblock 155 286 314 minecraft:snow_block
fill 155 286 315 155 289 315 minecraft:packed_ice
setblock 156 286 305 minecraft:magma_block
fill 156 286 314 156 289 314 minecraft:packed_ice
fill 157 286 282 161 293 282 minecraft:basalt
fill 157 286 306 161 293 306 minecraft:basalt
fill 157 286 315 158 286 315 minecraft:packed_ice
setblock 158 286 313 minecraft:basalt
setblock 158 286 316 minecraft:snow_block
setblock 159 286 313 minecraft:magma_block
setblock 159 286 314 minecraft:packed_ice
setblock 159 286 315 minecraft:snow_block
fill 159 286 316 162 286 316 minecraft:packed_ice
fill 160 286 281 160 293 281 minecraft:basalt
fill 160 286 313 164 286 313 minecraft:basalt
setblock 160 286 314 minecraft:snow_block
fill 160 286 315 163 286 315 minecraft:packed_ice
setblock 162 286 282 minecraft:magma_block
setblock 162 286 306 minecraft:magma_block
fill 163 286 282 164 293 282 minecraft:basalt
fill 163 286 306 163 293 307 minecraft:basalt
setblock 163 286 316 minecraft:snow_block
fill 164 286 306 164 293 306 minecraft:basalt
setblock 164 286 315 minecraft:snow_block
fill 164 286 316 167 286 316 minecraft:packed_ice
fill 165 286 315 168 286 315 minecraft:packed_ice
fill 166 286 277 167 287 277 minecraft:basalt
fill 166 286 282 166 293 283 minecraft:basalt
fill 166 286 305 166 293 306 minecraft:basalt
fill 167 286 283 167 292 283 minecraft:basalt
fill 167 286 305 167 293 305 minecraft:basalt
setblock 168 286 277 minecraft:magma_block
fill 168 286 284 169 293 284 minecraft:basalt
setblock 168 286 304 minecraft:magma_block
setblock 168 286 316 minecraft:snow_block
fill 169 286 277 170 286 277 minecraft:basalt
fill 169 286 285 169 294 285 minecraft:basalt
fill 169 286 303 169 294 303 minecraft:basalt
setblock 169 286 315 minecraft:snow_block
fill 169 286 316 172 286 316 minecraft:packed_ice
fill 170 286 286 170 294 286 minecraft:basalt
fill 170 286 302 170 294 302 minecraft:basalt
fill 170 286 315 173 286 315 minecraft:packed_ice
setblock 171 286 278 minecraft:basalt
fill 171 286 287 171 294 287 minecraft:basalt
fill 171 286 301 172 293 301 minecraft:basalt
fill 171 286 309 173 286 309 minecraft:basalt
fill 171 286 314 174 286 314 minecraft:packed_ice
fill 172 286 281 175 286 282 minecraft:basalt
fill 172 286 288 172 293 289 minecraft:basalt
fill 172 286 299 172 293 300 minecraft:basalt
fill 172 286 307 173 286 308 minecraft:basalt
setblock 173 286 276 minecraft:snow_block
fill 173 286 291 173 286 297 minecraft:basalt
fill 173 286 305 176 286 305 minecraft:basalt
setblock 173 286 316 minecraft:snow_block
fill 174 286 276 174 289 276 minecraft:packed_ice
setblock 174 286 280 minecraft:basalt
fill 174 286 283 176 286 283 minecraft:basalt
fill 174 286 307 175 286 307 minecraft:basalt
setblock 174 286 308 minecraft:magma_block
setblock 174 286 315 minecraft:snow_block
fill 174 286 316 177 286 316 minecraft:packed_ice
fill 175 286 286 178 286 286 minecraft:basalt
fill 175 286 302 178 286 302 minecraft:basalt
fill 175 286 304 176 287 304 minecraft:basalt
setblock 175 286 314 minecraft:snow_block
fill 175 286 315 178 286 315 minecraft:packed_ice
setblock 176 286 282 minecraft:basalt
fill 176 286 314 176 289 314 minecraft:packed_ice
fill 177 286 287 178 287 287 minecraft:basalt
fill 177 286 301 178 287 301 minecraft:basalt
fill 177 286 303 178 286 303 minecraft:basalt
setblock 177 286 304 minecraft:magma_block
setblock 178 286 285 minecraft:basalt
fill 178 286 288 179 286 288 minecraft:basalt
fill 178 286 291 179 287 291 minecraft:basalt
fill 178 286 294 179 287 294 minecraft:basalt
fill 178 286 297 179 287 297 minecraft:basalt
fill 178 286 300 179 286 300 minecraft:basalt
setblock 178 286 316 minecraft:snow_block
setblock 179 286 315 minecraft:snow_block
fill 179 286 316 179 289 316 minecraft:packed_ice
setblock 180 286 291 minecraft:magma_block
setblock 180 286 294 minecraft:magma_block
setblock 180 286 297 minecraft:magma_block
fill 180 286 315 180 289 315 minecraft:packed_ice
setblock 181 286 292 minecraft:packed_ice
setblock 181 286 293 minecraft:snow_block
fill 181 286 294 181 286 297 minecraft:packed_ice
setblock 181 286 298 minecraft:snow_block
setblock 181 286 312 minecraft:packed_ice
setblock 181 286 313 minecraft:snow_block
setblock 181 286 314 minecraft:packed_ice
fill 182 286 288 182 287 288 minecraft:packed_ice
fill 182 286 290 182 286 291 minecraft:packed_ice
setblock 182 286 292 minecraft:snow_block
fill 182 286 293 182 289 293 minecraft:packed_ice
setblock 182 286 297 minecraft:snow_block
fill 182 286 298 182 287 300 minecraft:packed_ice
setblock 182 286 307 minecraft:snow_block
setblock 182 286 308 minecraft:packed_ice
setblock 182 286 312 minecraft:snow_block
fill 182 286 313 182 289 313 minecraft:packed_ice
fill 141 287 285 141 296 285 minecraft:snow_block
setblock 142 287 286 minecraft:snow_block
fill 142 287 287 142 290 287 minecraft:packed_ice
setblock 142 287 291 minecraft:snow_block
fill 142 287 292 142 287 295 minecraft:packed_ice
setblock 142 287 296 minecraft:snow_block
fill 142 287 297 142 290 297 minecraft:packed_ice
setblock 143 287 290 minecraft:snow_block
fill 143 287 291 143 287 292 minecraft:basalt
setblock 143 287 293 minecraft:magma_block
fill 143 287 294 143 287 295 minecraft:basalt
setblock 143 287 296 minecraft:magma_block
setblock 143 287 297 minecraft:basalt
fill 145 287 286 146 287 286 minecraft:basalt
fill 145 287 303 146 287 303 minecraft:basalt
fill 146 287 284 148 287 284 minecraft:basalt
setblock 146 287 304 minecraft:magma_block
fill 148 287 276 149 289 276 minecraft:packed_ice
fill 148 287 282 149 287 282 minecraft:basalt
fill 148 287 294 148 293 294 minecraft:basalt
fill 148 287 306 149 287 307 minecraft:basalt
setblock 149 287 294 minecraft:magma_block
fill 149 287 316 151 287 316 minecraft:packed_ice
fill 150 287 280 153 287 280 minecraft:basalt
fill 150 287 289 150 294 291 minecraft:basalt
fill 150 287 297 150 294 298 minecraft:basalt
fill 150 287 307 151 288 307 minecraft:basalt
setblock 151 287 277 minecraft:snow_block
fill 151 287 288 151 294 288 minecraft:basalt
fill 151 287 300 151 294 300 minecraft:basalt
fill 151 287 315 152 287 315 minecraft:packed_ice
setblock 152 287 276 minecraft:snow_block
fill 152 287 277 153 289 277 minecraft:packed_ice
setblock 152 287 278 minecraft:magma_block
setblock 152 287 287 minecraft:magma_block
fill 152 287 301 152 295 301 minecraft:basalt
fill 152 287 310 155 287 310 minecraft:basalt
fill 152 287 316 152 287 317 minecraft:snow_block
fill 153 287 276 153 290 276 minecraft:packed_ice
fill 153 287 285 153 294 286 minecraft:basalt
fill 153 287 302 153 294 303 minecraft:basalt
setblock 153 287 315 minecraft:snow_block
fill 153 287 316 156 287 316 minecraft:packed_ice
setblock 154 287 277 minecraft:basalt
setblock 154 287 285 minecraft:basalt
setblock 154 287 303 minecraft:basalt
setblock 154 287 314 minecraft:snow_block
fill 154 287 315 154 290 315 minecraft:packed_ice
fill 155 287 276 156 287 276 minecraft:packed_ice
setblock 155 287 277 minecraft:magma_block
fill 155 287 284 155 294 284 minecraft:basalt
setblock 155 287 304 minecraft:magma_block
fill 155 287 314 155 290 314 minecraft:packed_ice
fill 156 287 305 158 294 305 minecraft:basalt
setblock 157 287 276 minecraft:snow_block
fill 157 287 283 158 294 283 minecraft:basalt
setblock 157 287 315 minecraft:packed_ice
setblock 157 287 316 minecraft:snow_block
setblock 158 287 276 minecraft:magma_block
setblock 158 287 312 minecraft:magma_block
setblock 158 287 315 minecraft:snow_block
fill 158 287 316 161 287 316 minecraft:packed_ice
setblock 159 287 314 minecraft:snow_block
fill 159 287 315 162 287 315 minecraft:packed_ice
fill 160 287 276 164 287 276 minecraft:basalt
fill 160 287 312 164 287 312 minecraft:basalt
fill 160 287 314 160 290 314 minecraft:packed_ice
fill 162 287 282 162 294 282 minecraft:basalt
fill 162 287 306 162 294 306 minecraft:basalt
setblock 162 287 316 minecraft:snow_block
fill 163 287 278 169 287 278 minecraft:basalt
fill 163 287 311 168 287 311 minecraft:basalt
setblock 163 287 315 minecraft:snow_block
fill 163 287 316 166 287 316 minecraft:packed_ice
setblock 164 287 283 minecraft:magma_block
fill 164 287 305 165 294 305 minecraft:basalt
fill 164 287 315 167 287 315 minecraft:packed_ice
fill 165 287 283 165 294 283 minecraft:basalt
fill 167 287 284 167 294 284 minecraft:basalt
fill 167 287 304 168 294 304 minecraft:basalt
setblock 167 287 316 minecraft:snow_block
setblock 168 287 277 minecraft:basalt
fill 168 287 285 168 295 285 minecraft:basalt
fill 168 287 303 168 295 303 minecraft:basalt
fill 168 287 310 170 287 310 minecraft:basalt
setblock 168 287 315 minecraft:snow_block
fill 168 287 316 171 287 316 minecraft:packed_ice
fill 169 287 279 171 287 280 minecraft:basalt
setblock 169 287 286 minecraft:basalt
fill 169 287 302 169 295 302 minecraft:basalt
fill 169 287 315 172 287 315 minecraft:packed_ice
fill 170 287 276 171 287 276 minecraft:packed_ice
setblock 170 287 278 minecraft:magma_block
setblock 170 287 287 minecraft:magma_block
fill 170 287 301 170 295 301 minecraft:basalt
fill 170 287 314 173 287 314 minecraft:packed_ice
fill 171 287 288 171 294 288 minecraft:basalt
fill 171 287 300 171 294 300 minecraft:basalt
setblock 171 287 309 minecraft:basalt
setblock 172 287 276 minecraft:snow_block
fill 172 287 280 172 287 282 minecraft:basalt
fill 172 287 290 172 287 291 minecraft:basalt
fill 172 287 297 172 287 298 minecraft:basalt
fill 172 287 306 172 287 308 minecraft:basalt
setblock 172 287 316 minecraft:snow_block
fill 173 287 276 173 290 276 minecraft:packed_ice
fill 173 287 281 174 287 282 minecraft:basalt
fill 173 287 291 173 293 291 minecraft:basalt
setblock 173 287 292 minecraft:magma_block
fill 173 287 293 173 294 294 minecraft:basalt
setblock 173 287 295 minecraft:magma_block
fill 173 287 296 173 293 297 minecraft:basalt
fill 173 287 305 174 287 306 minecraft:basalt
setblock 173 287 307 minecraft:magma_block
setblock 173 287 315 minecraft:snow_block
fill 173 287 316 176 287 316 minecraft:packed_ice
fill 174 287 283 175 287 283 minecraft:basalt
setblock 174 287 307 minecraft:basalt
setblock 174 287 314 minecraft:snow_block
fill 174 287 315 177 287 315 minecraft:packed_ice
fill 175 287 276 176 287 276 minecraft:packed_ice
fill 175 287 286 177 287 286 minecraft:basalt
fill 175 287 302 177 287 302 minecraft:basalt
setblock 175 287 305 minecraft:basalt
fill 175 287 314 175 290 314 minecraft:packed_ice
setblock 177 287 276 minecraft:snow_block
setblock 177 287 285 minecraft:basalt
fill 177 287 289 178 287 290 minecraft:basalt
fill 177 287 292 178 287 293 minecraft:basalt
fill 177 287 295 178 287 296 minecraft:basalt
fill 177 287 298 178 287 299 minecraft:basalt
setblock 177 287 303 minecraft:basalt
fill 177 287 314 178 287 314 minecraft:packed_ice
setblock 177 287 316 minecraft:snow_block
fill 178 287 276 178 290 276 minecraft:packed_ice
setblock 178 287 288 minecraft:basalt
setblock 178 287 300 minecraft:basalt
setblock 178 287 315 minecraft:snow_block
fill 178 287 316 178 290 316 minecraft:packed_ice
setblock 179 287 292 minecraft:basalt
setblock 179 287 293 minecraft:magma_block
setblock 179 287 295 minecraft:basalt
setblock 179 287 296 minecraft:magma_block
fill 179 287 315 179 290 315 minecraft:packed_ice
setblock 180 287 293 minecraft:snow_block
fill 180 287 294 182 287 295 minecraft:packed_ice
setblock 181 287 292 minecraft:snow_block
fill 181 287 293 181 290 293 minecraft:packed_ice
setblock 181 287 296 minecraft:packed_ice
setblock 181 287 297 minecraft:snow_block
fill 181 287 298 181 290 298 minecraft:packed_ice
setblock 181 287 312 minecraft:snow_block
setblock 181 287 313 minecraft:packed_ice
setblock 182 287 290 minecraft:packed_ice
setblock 182 287 291 minecraft:snow_block
fill 182 287 292 182 290 292 minecraft:packed_ice
setblock 182 287 296 minecraft:snow_block
fill 182 287 297 182 290 297 minecraft:packed_ice
setblock 182 287 301 minecraft:snow_block
setblock 182 287 311 minecraft:snow_block
fill 182 287 312 182 289 312 minecraft:packed_ice
setblock 182 287 316 minecraft:snow_block
setblock 183 287 278 minecraft:light_blue_concrete
fill 142 288 288 142 288 289 minecraft:packed_ice
setblock 142 288 290 minecraft:snow_block
fill 142 288 291 142 288 294 minecraft:packed_ice
setblock 142 288 295 minecraft:snow_block
fill 142 288 296 142 291 296 minecraft:packed_ice
setblock 142 288 299 minecraft:packed_ice
fill 143 288 290 143 288 293 minecraft:packed_ice
setblock 143 288 294 minecraft:snow_block
fill 143 288 295 143 291 295 minecraft:packed_ice
setblock 144 288 278 minecraft:light[level=15]
setblock 144 288 285 minecraft:light[level=12]
setblock 144 288 286 minecraft:light[level=15]
setblock 144 288 299 minecraft:light[level=12]
setblock 144 288 302 minecraft:light[level=15]
setblock 144 288 306 minecraft:light[level=12]
setblock 144 288 310 minecraft:light[level=15]
setblock 144 288 313 minecraft:light[level=12]
setblock 145 288 288 minecraft:magma_block
fill 145 288 289 146 288 289 minecraft:basalt
setblock 145 288 300 minecraft:magma_block
fill 145 288 301 146 288 301 minecraft:basalt
fill 146 288 285 146 288 286 minecraft:basalt
fill 146 288 288 146 289 288 minecraft:basalt
fill 146 288 300 146 289 300 minecraft:basalt
fill 146 288 302 146 288 303 minecraft:basalt
fill 147 288 276 147 291 276 minecraft:packed_ice
fill 147 288 284 148 288 284 minecraft:basalt
fill 147 288 302 147 289 302 minecraft:basalt
setblock 148 288 305 minecraft:magma_block
fill 148 288 316 150 288 316 minecraft:packed_ice
setblock 149 288 282 minecraft:basalt
fill 149 288 294 150 288 294 minecraft:basalt
fill 149 288 305 149 288 306 minecraft:basalt
setblock 150 288 277 minecraft:snow_block
fill 150 288 281 152 288 281 minecraft:basalt
fill 150 288 292 150 294 293 minecraft:basalt
fill 150 288 295 150 294 296 minecraft:basalt
fill 150 288 315 151 288 315 minecraft:packed_ice
setblock 151 288 276 minecraft:snow_block
fill 151 288 277 151 291 277 minecraft:packed_ice
setblock 151 288 278 minecraft:light[level=12]
setblock 151 288 280 minecraft:magma_block
setblock 151 288 289 minecraft:magma_block
fill 151 288 290 151 295 290 minecraft:basalt
setblock 151 288 292 minecraft:light[level=12]
setblock 151 288 298 minecraft:magma_block
fill 151 288 299 151 295 299 minecraft:basalt
fill 151 288 308 152 288 308 minecraft:basalt
setblock 151 288 313 minecraft:light[level=12]
setblock 151 288 316 minecraft:snow_block
fill 152 288 276 152 291 276 minecraft:packed_ice
setblock 152 288 278 minecraft:light[level=15]
fill 152 288 279 153 288 280 minecraft:basalt
fill 152 288 287 152 295 288 minecraft:basalt
setblock 152 288 294 minecraft:light[level=15]
fill 152 288 300 152 295 300 minecraft:basalt
fill 152 288 309 156 288 309 minecraft:basalt
setblock 152 288 310 minecraft:light[level=15]
setblock 152 288 315 minecraft:snow_block
fill 152 288 316 155 288 316 minecraft:packed_ice
fill 152 288 317 152 308 317 minecraft:snow_block
setblock 153 288 278 minecraft:packed_ice
setblock 153 288 314 minecraft:snow_block
fill 153 288 315 153 291 315 minecraft:packed_ice
setblock 154 288 277 minecraft:packed_ice
fill 154 288 279 156 289 279 minecraft:basalt
setblock 154 288 285 minecraft:magma_block
setblock 154 288 303 minecraft:magma_block
fill 154 288 310 155 288 310 minecraft:basalt
fill 154 288 314 154 291 314 minecraft:packed_ice
setblock 155 288 276 minecraft:packed_ice
setblock 155 288 277 minecraft:snow_block
fill 155 288 285 155 295 285 minecraft:basalt
fill 155 288 303 155 294 304 minecraft:basalt
setblock 156 288 276 minecraft:snow_block
fill 156 288 277 156 291 277 minecraft:packed_ice
fill 156 288 284 156 294 284 minecraft:basalt
fill 156 288 304 157 295 304 minecraft:basalt
setblock 156 288 316 minecraft:snow_block
fill 157 288 276 160 288 276 minecraft:packed_ice
fill 157 288 277 159 288 277 minecraft:basalt
setblock 157 288 284 minecraft:magma_block
setblock 157 288 311 minecraft:magma_block
setblock 157 288 314 minecraft:packed_ice
setblock 157 288 315 minecraft:snow_block
fill 157 288 316 160 288 316 minecraft:packed_ice
setblock 158 288 285 minecraft:light[level=12]
setblock 158 288 292 minecraft:light[level=12]
setblock 158 288 299 minecraft:light[level=12]
fill 158 288 311 161 288 311 minecraft:basalt
setblock 158 288 313 minecraft:light[level=12]
setblock 158 288 314 minecraft:snow_block
fill 158 288 315 161 288 315 minecraft:packed_ice
fill 159 288 283 159 294 283 minecraft:basalt
fill 159 288 305 163 288 305 minecraft:basalt
fill 159 288 314 159 291 314 minecraft:packed_ice
setblock 160 288 277 minecraft:magma_block
setblock 160 288 283 minecraft:magma_block
setblock 160 288 286 minecraft:light[level=15]
setblock 160 288 302 minecraft:light[level=15]
setblock 161 288 276 minecraft:snow_block
fill 161 288 277 164 288 277 minecraft:basalt
fill 161 288 283 164 295 283 minecraft:basalt
setblock 161 288 316 minecraft:snow_block
fill 162 288 276 165 288 276 minecraft:packed_ice
setblock 162 288 315 minecraft:snow_block
fill 162 288 316 165 288 316 minecraft:packed_ice
fill 163 288 278 165 289 278 minecraft:basalt
fill 163 288 311 165 288 311 minecraft:basalt
fill 163 288 315 166 288 315 minecraft:packed_ice
fill 165 288 284 165 294 284 minecraft:basalt
setblock 165 288 285 minecraft:light[level=12]
setblock 165 288 292 minecraft:light[level=12]
setblock 165 288 299 minecraft:light[level=12]
fill 165 288 304 166 288 304 minecraft:basalt
setblock 165 288 313 minecraft:light[level=12]
setblock 166 288 276 minecraft:snow_block
setblock 166 288 278 minecraft:magma_block
setblock 166 288 284 minecraft:magma_block
setblock 166 288 316 minecraft:snow_block
fill 167 288 276 170 288 276 minecraft:packed_ice
fill 167 288 278 168 288 278 minecraft:basalt
fill 167 288 285 167 295 285 minecraft:basalt
fill 167 288 303 167 295 303 minecraft:basalt
setblock 167 288 315 minecraft:snow_block
fill 167 288 316 170 288 316 minecraft:packed_ice
setblock 168 288 286 minecraft:light[level=15]
setblock 168 288 294 minecraft:light[level=15]
setblock 168 288 302 minecraft:light[level=15]
setblock 168 288 310 minecraft:basalt
fill 168 288 315 171 288 315 minecraft:packed_ice
fill 169 288 279 170 288 280 minecraft:basalt
setblock 169 288 286 minecraft:magma_block
fill 169 288 314 172 288 314 minecraft:packed_ice
fill 170 288 287 170 295 288 minecraft:basalt
fill 170 288 300 170 295 300 minecraft:basalt
setblock 171 288 276 minecraft:snow_block
setblock 171 288 280 minecraft:basalt
fill 171 288 289 171 288 290 minecraft:basalt
fill 171 288 298 171 295 299 minecraft:basalt
setblock 171 288 316 minecraft:snow_block
fill 172 288 276 172 291 276 minecraft:packed_ice
setblock 172 288 278 minecraft:light[level=12]
fill 172 288 281 172 288 282 minecraft:basalt
fill 172 288 290 172 294 290 minecraft:basalt
setblock 172 288 291 minecraft:magma_block
fill 172 288 292 172 295 293 minecraft:basalt
setblock 172 288 294 minecraft:magma_block
fill 172 288 295 172 295 296 minecraft:basalt
setblock 172 288 297 minecraft:magma_block
fill 172 288 298 172 293 298 minecraft:basalt
fill 172 288 306 172 288 307 minecraft:basalt
setblock 172 288 313 minecraft:light[level=12]
setblock 172 288 315 minecraft:snow_block
fill 172 288 316 175 288 316 minecraft:packed_ice
setblock 173 288 282 minecraft:basalt
fill 173 288 292 173 294 292 minecraft:basalt
fill 173 288 295 173 294 295 minecraft:basalt
fill 173 288 305 173 288 306 minecraft:basalt
setblock 173 288 314 minecraft:snow_block
fill 173 288 315 176 288 315 minecraft:packed_ice
fill 174 288 283 174 288 285 minecraft:basalt
setblock 174 288 305 minecraft:basalt
setblock 174 288 313 minecraft:snow_block
fill 174 288 314 174 291 314 minecraft:packed_ice
setblock 175 288 276 minecraft:packed_ice
setblock 175 288 284 minecraft:magma_block
fill 175 288 285 176 288 286 minecraft:basalt
fill 175 288 302 176 288 302 minecraft:basalt
setblock 175 288 304 minecraft:basalt
setblock 175 288 313 minecraft:packed_ice
setblock 176 288 276 minecraft:snow_block
setblock 176 288 278 minecraft:light[level=15]
setblock 176 288 310 minecraft:light[level=15]
setblock 176 288 316 minecraft:snow_block
fill 177 288 276 177 291 276 minecraft:packed_ice
setblock 177 288 287 minecraft:basalt
fill 177 288 289 177 288 290 minecraft:basalt
fill 177 288 292 177 289 293 minecraft:basalt
fill 177 288 295 177 289 296 minecraft:basalt
fill 177 288 298 177 288 299 minecraft:basalt
setblock 177 288 301 minecraft:basalt
setblock 177 288 314 minecraft:packed_ice
setblock 177 288 315 minecraft:snow_block
fill 177 288 316 177 291 316 minecraft:packed_ice
fill 178 288 290 178 288 291 minecraft:basalt
setblock 178 288 292 minecraft:magma_block
fill 178 288 293 178 288 294 minecraft:basalt
setblock 178 288 295 minecraft:magma_block
fill 178 288 296 178 288 297 minecraft:basalt
setblock 178 288 298 minecraft:magma_block
setblock 178 288 314 minecraft:snow_block
fill 178 288 315 178 291 315 minecraft:packed_ice
fill 179 288 276 179 289 276 minecraft:packed_ice
setblock 179 288 278 minecraft:light[level=12]
setblock 179 288 285 minecraft:light[level=12]
setblock 179 288 292 minecraft:light[level=12]
setblock 179 288 299 minecraft:light[level=12]
setblock 179 288 306 minecraft:light[level=12]
setblock 179 288 313 minecraft:light[level=12]
fill 180 288 293 180 288 296 minecraft:packed_ice
setblock 181 288 290 minecraft:packed_ice
setblock 181 288 291 minecraft:snow_block
fill 181 288 292 181 291 292 minecraft:packed_ice
fill 181 288 294 181 288 295 minecraft:packed_ice
setblock 181 288 296 minecraft:snow_block
fill 181 288 297 181 291 297 minecraft:packed_ice
fill 181 288 299 182 288 299 minecraft:packed_ice
setblock 181 288 316 minecraft:snow_block
setblock 182 288 290 minecraft:snow_block
fill 182 288 291 182 291 291 minecraft:packed_ice
setblock 182 288 294 minecraft:packed_ice
setblock 182 288 295 minecraft:snow_block
fill 182 288 296 182 291 296 minecraft:packed_ice
fill 182 288 298 182 289 298 minecraft:packed_ice
setblock 182 288 300 minecraft:snow_block
fill 182 288 301 182 291 301 minecraft:packed_ice
setblock 182 288 311 minecraft:packed_ice
setblock 182 288 315 minecraft:snow_block
fill 182 288 316 182 291 316 minecraft:packed_ice
fill 183 288 278 183 308 278 minecraft:snow_block
fill 142 289 276 144 289 276 minecraft:packed_ice
setblock 142 289 288 minecraft:packed_ice
setblock 142 289 289 minecraft:snow_block
fill 142 289 290 142 289 293 minecraft:packed_ice
setblock 142 289 294 minecraft:snow_block
fill 142 289 295 142 292 295 minecraft:packed_ice
setblock 142 289 299 minecraft:snow_block
fill 142 289 311 147 290 313 minecraft:blue_ice
fill 143 289 290 143 289 292 minecraft:packed_ice
setblock 143 289 293 minecraft:snow_block
fill 143 289 294 143 292 294 minecraft:packed_ice
fill 143 289 296 143 290 296 minecraft:packed_ice
fill 144 289 292 144 291 292 minecraft:snow_block
setblock 145 289 276 minecraft:snow_block
fill 145 289 291 145 289 292 minecraft:basalt
fill 145 289 294 145 289 295 minecraft:basalt
fill 145 289 297 145 289 298 minecraft:basalt
fill 146 289 276 146 292 276 minecraft:packed_ice
fill 146 289 287 147 289 287 minecraft:basalt
fill 146 289 289 146 290 289 minecraft:basalt
fill 146 289 299 146 290 299 minecraft:basalt
setblock 146 289 301 minecraft:basalt
setblock 147 289 286 minecraft:magma_block
fill 147 289 288 147 290 288 minecraft:basalt
fill 147 289 314 147 293 314 minecraft:packed_ice
fill 147 289 316 149 289 316 minecraft:packed_ice
setblock 148 289 277 minecraft:packed_ice
setblock 148 289 284 minecraft:basalt
fill 148 289 312 149 289 312 minecraft:blue_ice
fill 148 289 313 148 293 313 minecraft:packed_ice
setblock 149 289 277 minecraft:snow_block
fill 149 289 283 150 289 283 minecraft:basalt
fill 149 289 294 149 294 294 minecraft:basalt
fill 149 289 305 150 289 305 minecraft:basalt
fill 149 289 315 150 289 315 minecraft:packed_ice
setblock 150 289 276 minecraft:snow_block
fill 150 289 277 150 292 277 minecraft:packed_ice
setblock 150 289 282 minecraft:magma_block
setblock 150 289 294 minecraft:magma_block
setblock 150 289 306 minecraft:magma_block
setblock 150 289 316 minecraft:snow_block
fill 151 289 276 151 292 276 minecraft:packed_ice
fill 151 289 278 152 289 278 minecraft:packed_ice
fill 151 289 281 152 289 281 minecraft:basalt
fill 151 289 289 152 289 289 minecraft:basalt
fill 151 289 291 151 295 292 minecraft:basalt
fill 151 289 296 151 295 298 minecraft:basalt
setblock 151 289 307 minecraft:basalt
setblock 151 289 315 minecraft:snow_block
fill 151 289 316 154 289 316 minecraft:packed_ice
fill 152 289 280 153 289 280 minecraft:basalt
fill 152 289 299 152 295 299 minecraft:basalt
setblock 152 289 308 minecraft:basalt
setblock 152 289 314 minecraft:snow_block
fill 152 289 315 152 292 315 minecraft:packed_ice
setblock 153 289 278 minecraft:snow_block
setblock 153 289 287 minecraft:magma_block
fill 153 289 301 153 295 301 minecraft:basalt
fill 153 289 307 153 290 307 minecraft:basalt
setblock 153 289 308 minecraft:magma_block
fill 153 289 314 153 292 314 minecraft:packed_ice
setblock 154 289 277 minecraft:snow_block
fill 154 289 278 156 290 278 minecraft:packed_ice
fill 154 289 285 154 295 286 minecraft:basalt
fill 154 289 302 154 295 303 minecraft:basalt
fill 154 289 309 156 289 309 minecraft:basalt
setblock 155 289 276 minecraft:snow_block
fill 155 289 277 155 292 277 minecraft:packed_ice
setblock 155 289 316 minecraft:snow_block
fill 156 289 276 159 289 276 minecraft:packed_ice
fill 156 289 285 156 295 285 minecraft:basalt
fill 156 289 303 156 295 303 minecraft:basalt
setblock 156 289 315 minecraft:snow_block
fill 156 289 316 159 289 316 minecraft:packed_ice
fill 157 289 277 158 289 277 minecraft:packed_ice
fill 157 289 278 161 289 278 minecraft:basalt
fill 157 289 284 159 295 284 minecraft:basalt
fill 157 289 310 160 289 310 minecraft:basalt
setblock 157 289 314 minecraft:snow_block
fill 157 289 315 160 289 315 minecraft:packed_ice
fill 158 289 304 159 294 304 minecraft:basalt
fill 158 289 314 158 292 314 minecraft:packed_ice
setblock 159 289 277 minecraft:snow_block
fill 159 289 305 161 295 305 minecraft:basalt
setblock 160 289 276 minecraft:snow_block
fill 160 289 277 161 291 277 minecraft:packed_ice
fill 160 289 283 160 295 283 minecraft:basalt
setblock 160 289 316 minecraft:snow_block
fill 161 289 276 164 289 276 minecraft:packed_ice
setblock 161 289 315 minecraft:snow_block
fill 161 289 316 164 289 316 minecraft:packed_ice
setblock 162 289 278 minecraft:magma_block
setblock 162 289 305 minecraft:magma_block
setblock 162 289 310 minecraft:basalt
fill 162 289 315 165 289 315 minecraft:packed_ice
fill 163 289 284 164 295 284 minecraft:basalt
fill 163 289 304 163 295 305 minecraft:basalt
fill 164 289 304 164 295 304 minecraft:basalt
setblock 164 289 310 minecraft:basalt
setblock 165 289 276 minecraft:snow_block
setblock 165 289 304 minecraft:magma_block
setblock 165 289 310 minecraft:magma_block
setblock 165 289 316 minecraft:snow_block
fill 166 289 276 169 289 276 minecraft:packed_ice
fill 166 289 284 166 295 285 minecraft:basalt
fill 166 289 303 166 295 304 minecraft:basalt
fill 166 289 309 167 289 309 minecraft:basalt
setblock 166 289 315 minecraft:snow_block
fill 166 289 316 169 289 316 minecraft:packed_ice
fill 167 289 315 170 289 315 minecraft:packed_ice
setblock 168 289 279 minecraft:magma_block
fill 168 289 286 169 294 286 minecraft:basalt
fill 168 289 302 168 295 302 minecraft:basalt
fill 168 289 308 170 289 308 minecraft:basalt
setblock 168 289 309 minecraft:magma_block
fill 168 289 314 171 289 314 minecraft:packed_ice
fill 169 289 280 170 289 280 minecraft:basalt
fill 169 289 287 169 295 287 minecraft:basalt
fill 169 289 301 169 295 301 minecraft:basalt
setblock 170 289 276 minecraft:snow_block
fill 170 289 289 171 289 289 minecraft:basalt
fill 170 289 299 170 295 299 minecraft:basalt
setblock 170 289 316 minecraft:snow_block
fill 171 289 276 171 292 276 minecraft:packed_ice
setblock 171 289 281 minecraft:magma_block
fill 171 289 282 172 289 282 minecraft:basalt
setblock 171 289 290 minecraft:magma_block
fill 171 289 291 171 294 292 minecraft:basalt
setblock 171 289 296 minecraft:magma_block
fill 171 289 297 172 294 297 minecraft:basalt
fill 171 289 306 171 289 307 minecraft:basalt
setblock 171 289 315 minecraft:snow_block
fill 171 289 316 174 289 316 minecraft:packed_ice
fill 172 289 291 172 295 291 minecraft:basalt
fill 172 289 294 172 295 294 minecraft:basalt
setblock 172 289 306 minecraft:basalt
setblock 172 289 314 minecraft:snow_block
fill 172 289 315 175 289 315 minecraft:packed_ice
setblock 173 289 277 minecraft:packed_ice
fill 173 289 304 173 289 305 minecraft:basalt
setblock 173 289 313 minecraft:snow_block
fill 173 289 314 173 292 314 minecraft:packed_ice
setblock 174 289 277 minecraft:snow_block
fill 174 289 284 174 289 285 minecraft:basalt
fill 174 289 303 175 289 303 minecraft:basalt
setblock 174 289 304 minecraft:magma_block
fill 174 289 313 174 290 313 minecraft:packed_ice
setblock 175 289 276 minecraft:snow_block
fill 175 289 277 175 292 277 minecraft:packed_ice
fill 175 289 285 175 289 286 minecraft:basalt
setblock 175 289 302 minecraft:basalt
setblock 175 289 316 minecraft:snow_block
fill 176 289 276 176 292 276 minecraft:packed_ice
setblock 176 289 315 minecraft:snow_block
fill 176 289 316 176 292 316 minecraft:packed_ice
setblock 177 289 290 minecraft:basalt
setblock 177 289 291 minecraft:magma_block
setblock 177 289 294 minecraft:magma_block
setblock 177 289 297 minecraft:magma_block
setblock 177 289 298 minecraft:basalt
setblock 177 289 314 minecraft:snow_block
fill 177 289 315 177 292 315 minecraft:packed_ice
setblock 178 289 314 minecraft:packed_ice
fill 180 289 293 180 289 295 minecraft:packed_ice
setblock 180 289 296 minecraft:snow_block
fill 180 289 297 180 291 298 minecraft:packed_ice
setblock 180 289 316 minecraft:snow_block
fill 181 289 291 181 292 291 minecraft:packed_ice
setblock 181 289 294 minecraft:packed_ice
setblock 181 289 295 minecraft:snow_block
fill 181 289 296 181 292 296 minecraft:packed_ice
setblock 181 289 299 minecraft:packed_ice
setblock 181 289 300 minecraft:snow_block
fill 181 289 316 181 292 316 minecraft:packed_ice
setblock 182 289 289 minecraft:snow_block
fill 182 289 290 182 292 290 minecraft:packed_ice
setblock 182 289 294 minecraft:snow_block
fill 182 289 295 182 292 295 minecraft:packed_ice
setblock 182 289 299 minecraft:snow_block
fill 182 289 300 182 292 300 minecraft:packed_ice
fill 182 289 302 182 290 302 minecraft:packed_ice
setblock 182 289 314 minecraft:snow_block
fill 182 289 315 182 291 315 minecraft:packed_ice
fill 142 290 276 142 290 277 minecraft:packed_ice
setblock 142 290 278 minecraft:snow_block
fill 142 290 279 142 293 279 minecraft:packed_ice
setblock 142 290 288 minecraft:snow_block
fill 142 290 289 142 290 292 minecraft:packed_ice
setblock 142 290 293 minecraft:snow_block
fill 142 290 294 142 293 294 minecraft:packed_ice
setblock 142 290 298 minecraft:snow_block
fill 142 290 299 142 292 300 minecraft:packed_ice
fill 142 290 310 143 291 310 minecraft:blue_ice
fill 142 290 314 143 291 314 minecraft:blue_ice
setblock 143 290 276 minecraft:packed_ice
setblock 143 290 291 minecraft:packed_ice
setblock 143 290 292 minecraft:snow_block
fill 143 290 293 143 293 293 minecraft:packed_ice
setblock 143 290 297 minecraft:snow_block
setblock 144 290 276 minecraft:snow_block
fill 144 290 291 144 291 291 minecraft:snow_block
fill 144 290 293 144 291 293 minecraft:snow_block
fill 145 290 276 145 293 276 minecraft:packed_ice
fill 145 290 316 148 290 316 minecraft:packed_ice
fill 146 290 277 147 290 277 minecraft:packed_ice
setblock 146 290 291 minecraft:magma_block
setblock 146 290 293 minecraft:basalt
setblock 146 290 294 minecraft:magma_block
setblock 146 290 295 minecraft:basalt
setblock 146 290 297 minecraft:magma_block
setblock 147 290 287 minecraft:basalt
setblock 148 290 276 minecraft:packed_ice
setblock 148 290 277 minecraft:snow_block
fill 148 290 285 149 290 285 minecraft:basalt
setblock 148 290 303 minecraft:basalt
setblock 148 290 312 minecraft:blue_ice
setblock 149 290 276 minecraft:snow_block
fill 149 290 277 149 292 278 minecraft:packed_ice
setblock 149 290 284 minecraft:magma_block
setblock 149 290 315 minecraft:packed_ice
setblock 149 290 316 minecraft:snow_block
fill 150 290 276 150 293 276 minecraft:packed_ice
fill 150 290 278 151 290 278 minecraft:packed_ice
setblock 150 290 283 minecraft:basalt
fill 150 290 294 151 295 294 minecraft:basalt
setblock 150 290 305 minecraft:basalt
setblock 150 290 315 minecraft:snow_block
fill 150 290 316 153 290 316 minecraft:packed_ice
fill 151 290 289 151 295 289 minecraft:basalt
fill 151 290 293 151 295 293 minecraft:basalt
fill 151 290 295 151 295 295 minecraft:basalt
setblock 151 290 314 minecraft:snow_block
fill 151 290 315 151 293 315 minecraft:packed_ice
setblock 152 290 277 minecraft:packed_ice
setblock 152 290 278 minecraft:snow_block
setblock 152 290 281 minecraft:basalt
setblock 152 290 289 minecraft:magma_block
fill 152 290 290 152 295 291 minecraft:basalt
fill 152 290 297 152 295 297 minecraft:basalt
setblock 152 290 298 minecraft:magma_block
setblock 152 290 306 minecraft:basalt
setblock 152 290 307 minecraft:magma_block
fill 152 290 314 152 293 314 minecraft:packed_ice
setblock 153 290 277 minecraft:snow_block
fill 153 290 278 153 293 278 minecraft:packed_ice
fill 153 290 287 153 294 288 minecraft:basalt
fill 153 290 300 153 294 300 minecraft:basalt
setblock 154 290 276 minecraft:snow_block
fill 154 290 277 154 293 277 minecraft:packed_ice
fill 154 290 287 154 295 287 minecraft:basalt
fill 154 290 301 154 295 301 minecraft:basalt
setblock 154 290 316 minecraft:snow_block
fill 155 290 276 158 290 276 minecraft:packed_ice
fill 155 290 286 155 295 286 minecraft:basalt
fill 155 290 302 155 295 302 minecraft:basalt
setblock 155 290 315 minecraft:snow_block
fill 155 290 316 158 290 316 minecraft:packed_ice
setblock 156 290 279 minecraft:basalt
setblock 156 290 309 minecraft:basalt
setblock 156 290 314 minecraft:snow_block
fill 156 290 315 159 290 315 minecraft:packed_ice
setblock 157 290 277 minecraft:packed_ice
setblock 157 290 278 minecraft:snow_block
fill 157 290 285 158 295 285 minecraft:basalt
fill 157 290 303 158 295 303 minecraft:basalt
fill 157 290 314 157 293 314 minecraft:packed_ice
setblock 158 290 277 minecraft:snow_block
fill 158 290 278 158 293 278 minecraft:packed_ice
setblock 159 290 276 minecraft:snow_block
fill 159 290 277 159 293 277 minecraft:packed_ice
setblock 159 290 316 minecraft:snow_block
fill 160 290 276 163 290 276 minecraft:packed_ice
fill 160 290 284 162 295 284 minecraft:basalt
fill 160 290 304 160 295 304 minecraft:basalt
setblock 160 290 315 minecraft:snow_block
fill 160 290 316 163 290 316 minecraft:packed_ice
setblock 161 290 304 minecraft:magma_block
setblock 161 290 309 minecraft:basalt
fill 161 290 315 164 290 315 minecraft:packed_ice
fill 162 290 304 162 295 305 minecraft:basalt
setblock 163 290 309 minecraft:basalt
setblock 164 290 276 minecraft:snow_block
setblock 164 290 279 minecraft:magma_block
setblock 164 290 285 minecraft:magma_block
setblock 164 290 303 minecraft:magma_block
setblock 164 290 309 minecraft:magma_block
setblock 164 290 316 minecraft:snow_block
fill 165 290 276 168 290 276 minecraft:packed_ice
fill 165 290 285 165 295 285 minecraft:basalt
fill 165 290 303 165 295 304 minecraft:basalt
fill 165 290 308 166 291 308 minecraft:basalt
setblock 165 290 315 minecraft:snow_block
fill 165 290 316 168 290 316 minecraft:packed_ice
setblock 166 290 279 minecraft:basalt
setblock 166 290 309 minecraft:basalt
fill 166 290 315 169 290 315 minecraft:packed_ice
fill 167 290 286 167 295 286 minecraft:basalt
setblock 167 290 302 minecraft:magma_block
setblock 167 290 308 minecraft:magma_block
fill 167 290 314 170 290 314 minecraft:packed_ice
fill 168 290 287 168 295 287 minecraft:basalt
fill 168 290 301 168 294 301 minecraft:basalt
setblock 168 290 308 minecraft:basalt
setblock 169 290 276 minecraft:snow_block
fill 169 290 288 169 295 288 minecraft:basalt
fill 169 290 300 169 295 300 minecraft:basalt
setblock 169 290 316 minecraft:snow_block
fill 170 290 276 170 292 277 minecraft:packed_ice
setblock 170 290 289 minecraft:magma_block
fill 170 290 290 170 295 291 minecraft:basalt
fill 170 290 297 170 295 297 minecraft:basalt
setblock 170 290 298 minecraft:magma_block
fill 170 290 306 171 290 306 minecraft:basalt
setblock 170 290 307 minecraft:magma_block
setblock 170 290 315 minecraft:snow_block
fill 170 290 316 173 290 316 minecraft:packed_ice
fill 171 290 277 172 290 277 minecraft:packed_ice
setblock 171 290 282 minecraft:basalt
fill 171 290 289 171 295 290 minecraft:basalt
fill 171 290 293 171 294 296 minecraft:basalt
setblock 171 290 314 minecraft:snow_block
fill 171 290 315 174 290 315 minecraft:packed_ice
setblock 172 290 313 minecraft:snow_block
fill 172 290 314 172 293 314 minecraft:packed_ice
setblock 173 290 277 minecraft:snow_block
setblock 173 290 285 minecraft:magma_block
setblock 173 290 303 minecraft:magma_block
setblock 173 290 304 minecraft:basalt
fill 173 290 313 173 291 313 minecraft:packed_ice
setblock 174 290 276 minecraft:snow_block
fill 174 290 277 174 293 277 minecraft:packed_ice
setblock 174 290 285 minecraft:basalt
setblock 174 290 303 minecraft:basalt
setblock 174 290 316 minecraft:snow_block
fill 175 290 276 175 293 276 minecraft:packed_ice
fill 175 290 290 175 291 290 minecraft:basalt
fill 175 290 299 175 290 301 minecraft:basalt
setblock 175 290 315 minecraft:snow_block
fill 175 290 316 175 293 316 minecraft:packed_ice
fill 176 290 277 176 291 277 minecraft:packed_ice
setblock 176 290 289 minecraft:basalt
setblock 176 290 290 minecraft:magma_block
setblock 176 290 293 minecraft:magma_block
fill 176 290 294 176 290 295 minecraft:basalt
setblock 176 290 296 minecraft:magma_block
setblock 176 290 299 minecraft:magma_block
setblock 176 290 314 minecraft:snow_block
fill 176 290 315 176 293 315 minecraft:packed_ice
fill 177 290 314 177 291 314 minecraft:packed_ice
setblock 179 290 276 minecraft:snow_block
setblock 179 290 316 minecraft:snow_block
fill 180 290 276 180 293 276 minecraft:packed_ice
fill 180 290 293 180 290 294 minecraft:packed_ice
setblock 180 290 295 minecraft:snow_block
fill 180 290 296 180 293 296 minecraft:packed_ice
setblock 180 290 299 minecraft:packed_ice
setblock 180 290 315 minecraft:snow_block
fill 180 290 316 180 293 316 minecraft:packed_ice
setblock 181 290 294 minecraft:snow_block
fill 181 290 295 181 293 295 minecraft:packed_ice
setblock 181 290 299 minecraft:snow_block
fill 181 290 300 181 292 301 minecraft:packed_ice
fill 182 290 289 182 293 289 minecraft:packed_ice
setblock 182 290 293 minecraft:snow_block
fill 182 290 294 182 293 294 minecraft:packed_ice
setblock 182 290 298 minecraft:snow_block
fill 182 290 299 182 293 299 minecraft:packed_ice
setblock 182 290 303 minecraft:snow_block
setblock 182 290 313 minecraft:snow_block
setblock 182 290 314 minecraft:packed_ice
setblock 142 291 276 minecraft:packed_ice
setblock 142 291 277 minecraft:snow_block
fill 142 291 278 142 294 278 minecraft:packed_ice
fill 142 291 280 142 291 281 minecraft:packed_ice
setblock 142 291 287 minecraft:snow_block
fill 142 291 288 142 291 291 minecraft:packed_ice
setblock 142 291 292 minecraft:snow_block
fill 142 291 293 142 294 293 minecraft:packed_ice
setblock 142 291 297 minecraft:snow_block
fill 142 291 298 142 294 298 minecraft:packed_ice
fill 142 291 311 145 291 313 minecraft:blue_ice
setblock 142 291 316 minecraft:packed_ice
setblock 143 291 276 minecraft:snow_block
setblock 143 291 291 minecraft:snow_block
fill 143 291 292 143 292 292 minecraft:packed_ice
setblock 143 291 296 minecraft:snow_block
fill 143 291 297 143 294 297 minecraft:packed_ice
setblock 143 291 316 minecraft:snow_block
fill 144 291 276 144 293 277 minecraft:packed_ice
fill 144 291 316 147 291 316 minecraft:packed_ice
fill 145 291 277 146 291 277 minecraft:packed_ice
fill 146 291 288 146 292 289 minecraft:snow_block
setblock 146 291 312 minecraft:blue_ice
fill 146 291 313 146 293 314 minecraft:packed_ice
setblock 147 291 277 minecraft:snow_block
fill 147 291 312 147 293 313 minecraft:packed_ice
setblock 148 291 276 minecraft:snow_block
fill 148 291 277 148 293 278 minecraft:packed_ice
fill 148 291 299 148 291 300 minecraft:basalt
setblock 148 291 301 minecraft:magma_block
fill 148 291 312 148 293 312 minecraft:packed_ice
fill 148 291 314 148 291 315 minecraft:packed_ice
setblock 148 291 316 minecraft:snow_block
fill 149 291 276 149 294 276 minecraft:packed_ice
setblock 149 291 286 minecraft:basalt
setblock 149 291 315 minecraft:snow_block
fill 149 291 316 152 291 316 minecraft:packed_ice
setblock 150 291 278 minecraft:packed_ice
fill 150 291 315 150 294 315 minecraft:packed_ice
setblock 151 291 278 minecraft:snow_block
fill 151 291 279 154 291 279 minecraft:packed_ice
fill 151 291 314 151 294 314 minecraft:packed_ice
setblock 152 291 277 minecraft:snow_block
fill 152 291 278 152 294 278 minecraft:packed_ice
fill 152 291 289 153 295 289 minecraft:basalt
fill 152 291 292 152 295 296 minecraft:basalt
fill 152 291 298 153 291 298 minecraft:basalt
setblock 153 291 276 minecraft:snow_block
fill 153 291 277 153 294 277 minecraft:packed_ice
fill 153 291 290 153 295 290 minecraft:basalt
fill 153 291 299 153 295 299 minecraft:basalt
setblock 153 291 316 minecraft:snow_block
fill 154 291 276 157 291 276 minecraft:packed_ice
fill 154 291 278 155 291 278 minecraft:packed_ice
setblock 154 291 281 minecraft:magma_block
fill 154 291 288 154 295 288 minecraft:basalt
fill 154 291 300 154 295 300 minecraft:basalt
setblock 154 291 315 minecraft:snow_block
fill 154 291 316 157 291 316 minecraft:packed_ice
setblock 155 291 279 minecraft:snow_block
fill 155 291 281 156 291 281 minecraft:basalt
fill 155 291 287 155 295 287 minecraft:basalt
fill 155 291 301 155 295 301 minecraft:basalt
setblock 155 291 314 minecraft:snow_block
fill 155 291 315 158 291 315 minecraft:packed_ice
setblock 156 291 278 minecraft:snow_block
fill 156 291 286 156 295 286 minecraft:basalt
fill 156 291 302 157 294 302 minecraft:basalt
fill 156 291 314 156 293 314 minecraft:packed_ice
setblock 157 291 277 minecraft:snow_block
fill 157 291 278 157 294 278 minecraft:packed_ice
setblock 157 291 280 minecraft:magma_block
setblock 157 291 286 minecraft:magma_block
setblock 158 291 276 minecraft:snow_block
fill 158 291 277 158 294 277 minecraft:packed_ice
fill 158 291 280 161 291 280 minecraft:basalt
setblock 158 291 316 minecraft:snow_block
fill 159 291 276 162 291 276 minecraft:packed_ice
fill 159 291 285 159 295 285 minecraft:basalt
fill 159 291 303 159 295 303 minecraft:basalt
setblock 159 291 315 minecraft:snow_block
fill 159 291 316 162 291 316 minecraft:packed_ice
setblock 160 291 285 minecraft:magma_block
setblock 160 291 303 minecraft:magma_block
fill 160 291 308 162 292 308 minecraft:basalt
fill 160 291 315 163 291 315 minecraft:packed_ice
fill 161 291 285 164 294 285 minecraft:basalt
fill 161 291 303 161 295 304 minecraft:basalt
setblock 162 291 277 minecraft:snow_block
fill 162 291 303 164 294 303 minecraft:basalt
setblock 163 291 276 minecraft:snow_block
setblock 163 291 308 minecraft:magma_block
setblock 163 291 316 minecraft:snow_block
fill 164 291 276 167 291 276 minecraft:packed_ice
setblock 164 291 308 minecraft:basalt
setblock 164 291 315 minecraft:snow_block
fill 164 291 316 167 291 316 minecraft:packed_ice
fill 165 291 286 165 295 286 minecraft:basalt
fill 165 291 302 167 294 302 minecraft:basalt
fill 165 291 315 168 291 315 minecraft:packed_ice
setblock 166 291 280 minecraft:magma_block
fill 166 291 281 166 292 281 minecraft:basalt
setblock 166 291 286 minecraft:magma_block
setblock 167 291 277 minecraft:snow_block
fill 167 291 287 167 295 287 minecraft:basalt
fill 167 291 301 167 295 301 minecraft:basalt
fill 167 291 314 169 291 314 minecraft:packed_ice
setblock 168 291 276 minecraft:snow_block
fill 168 291 277 169 293 277 minecraft:packed_ice
fill 168 291 282 168 292 282 minecraft:basalt
fill 168 291 288 168 295 288 minecraft:basalt
fill 168 291 300 168 295 300 minecraft:basalt
fill 168 291 306 168 292 306 minecraft:basalt
setblock 168 291 316 minecraft:snow_block
fill 169 291 276 169 294 276 minecraft:packed_ice
setblock 169 291 282 minecraft:magma_block
fill 169 291 289 169 295 290 minecraft:basalt
fill 169 291 298 169 295 299 minecraft:basalt
setblock 169 291 306 minecraft:magma_block
setblock 169 291 315 minecraft:snow_block
fill 169 291 316 172 291 316 minecraft:packed_ice
fill 170 291 289 170 295 289 minecraft:basalt
fill 170 291 292 170 295 296 minecraft:basalt
fill 170 291 298 170 295 298 minecraft:basalt
setblock 170 291 314 minecraft:snow_block
fill 170 291 315 173 291 315 minecraft:packed_ice
setblock 171 291 277 minecraft:packed_ice
setblock 171 291 284 minecraft:basalt
fill 171 291 314 171 294 314 minecraft:packed_ice
setblock 172 291 277 minecraft:snow_block
setblock 172 291 284 minecraft:magma_block
setblock 172 291 313 minecraft:packed_ice
setblock 173 291 276 minecraft:snow_block
fill 173 291 277 173 294 277 minecraft:packed_ice
setblock 173 291 316 minecraft:snow_block
fill 174 291 276 174 294 276 minecraft:packed_ice
fill 174 291 289 174 292 289 minecraft:basalt
setblock 174 291 315 minecraft:snow_block
fill 174 291 316 174 294 316 minecraft:packed_ice
setblock 175 291 289 minecraft:magma_block
setblock 175 291 291 minecraft:basalt
setblock 175 291 292 minecraft:magma_block
fill 175 291 293 175 292 294 minecraft:basalt
setblock 175 291 295 minecraft:magma_block
fill 175 291 296 175 291 297 minecraft:basalt
setblock 175 291 298 minecraft:magma_block
setblock 175 291 299 minecraft:basalt
setblock 175 291 314 minecraft:snow_block
fill 175 291 315 175 294 315 minecraft:packed_ice
fill 176 291 314 176 292 314 minecraft:packed_ice
setblock 177 291 277 minecraft:snow_block
setblock 178 291 276 minecraft:snow_block
setblock 178 291 316 minecraft:snow_block
fill 179 291 276 179 294 276 minecraft:packed_ice
setblock 179 291 315 minecraft:snow_block
fill 179 291 316 179 294 316 minecraft:packed_ice
setblock 180 291 293 minecraft:packed_ice
setblock 180 291 294 minecraft:snow_block
fill 180 291 295 180 293 295 minecraft:packed_ice
setblock 180 291 299 minecraft:snow_block
fill 181 291 276 181 292 276 minecraft:packed_ice
setblock 181 291 293 minecraft:snow_block
fill 181 291 294 181 294 294 minecraft:packed_ice
setblock 181 291 298 minecraft:snow_block
fill 181 291 299 181 294 299 minecraft:packed_ice
setblock 182 291 292 minecraft:snow_block
fill 182 291 293 182 294 293 minecraft:packed_ice
setblock 182 291 297 minecraft:snow_block
fill 182 291 298 182 294 298 minecraft:packed_ice
setblock 182 291 302 minecraft:snow_block
fill 182 291 303 182 294 303 minecraft:packed_ice
setblock 141 292 277 minecraft:light_blue_concrete
setblock 142 292 276 minecraft:snow_block
fill 142 292 277 143 294 277 minecraft:packed_ice
setblock 142 292 280 minecraft:packed_ice
setblock 142 292 281 minecraft:snow_block
fill 142 292 282 142 293 284 minecraft:packed_ice
setblock 142 292 286 minecraft:snow_block
fill 142 292 287 142 292 290 minecraft:packed_ice
setblock 142 292 291 minecraft:snow_block
fill 142 292 292 142 295 292 minecraft:packed_ice
setblock 142 292 296 minecraft:snow_block
fill 142 292 297 142 295 297 minecraft:packed_ice
setblock 142 292 301 minecraft:snow_block
fill 142 292 311 143 292 313 minecraft:blue_ice
setblock 142 292 316 minecraft:snow_block
fill 143 292 276 143 295 276 minecraft:packed_ice
fill 143 292 278 143 293 278 minecraft:packed_ice
setblock 143 292 295 minecraft:snow_block
fill 143 292 296 143 294 296 minecraft:packed_ice
fill 143 292 298 143 293 298 minecraft:packed_ice
fill 143 292 316 146 292 316 minecraft:packed_ice
setblock 144 292 312 minecraft:blue_ice
setblock 145 292 277 minecraft:packed_ice
setblock 146 292 277 minecraft:snow_block
fill 146 292 278 147 294 278 minecraft:packed_ice
fill 146 292 312 146 293 312 minecraft:packed_ice
setblock 147 292 276 minecraft:snow_block
fill 147 292 277 147 295 277 minecraft:packed_ice
setblock 147 292 293 minecraft:basalt
setblock 147 292 294 minecraft:magma_block
setblock 147 292 295 minecraft:basalt
setblock 147 292 315 minecraft:packed_ice
setblock 147 292 316 minecraft:snow_block
fill 148 292 276 148 295 276 minecraft:packed_ice
setblock 148 292 289 minecraft:basalt
setblock 148 292 299 minecraft:basalt
fill 148 292 314 148 293 314 minecraft:packed_ice
setblock 148 292 315 minecraft:snow_block
fill 148 292 316 151 292 316 minecraft:packed_ice
setblock 149 292 279 minecraft:snow_block
fill 149 292 315 149 295 315 minecraft:packed_ice
setblock 150 292 278 minecraft:snow_block
fill 150 292 279 153 292 279 minecraft:packed_ice
setblock 150 292 302 minecraft:magma_block
fill 150 292 314 150 293 314 minecraft:packed_ice
setblock 151 292 277 minecraft:snow_block
fill 151 292 278 151 295 278 minecraft:packed_ice
setblock 152 292 276 minecraft:snow_block
fill 152 292 277 152 295 277 minecraft:packed_ice
fill 152 292 298 152 295 298 minecraft:basalt
setblock 152 292 316 minecraft:snow_block
fill 153 292 276 156 292 276 minecraft:packed_ice
setblock 153 292 283 minecraft:magma_block
fill 153 292 291 153 294 291 minecraft:basalt
setblock 153 292 292 minecraft:magma_block
fill 153 292 296 153 294 297 minecraft:basalt
setblock 153 292 298 minecraft:magma_block
setblock 153 292 315 minecraft:snow_block
fill 153 292 316 156 292 316 minecraft:packed_ice
setblock 154 292 278 minecraft:packed_ice
setblock 154 292 279 minecraft:snow_block
setblock 154 292 282 minecraft:basalt
fill 154 292 289 154 295 289 minecraft:basalt
fill 154 292 299 154 295 299 minecraft:basalt
setblock 154 292 306 minecraft:basalt
setblock 154 292 314 minecraft:snow_block
fill 154 292 315 157 292 315 minecraft:packed_ice
setblock 155 292 278 minecraft:snow_block
fill 155 292 279 155 294 279 minecraft:packed_ice
fill 155 292 288 155 295 288 minecraft:basalt
fill 155 292 300 155 295 300 minecraft:basalt
fill 155 292 314 155 294 314 minecraft:packed_ice
setblock 156 292 277 minecraft:snow_block
fill 156 292 278 156 295 278 minecraft:packed_ice
setblock 156 292 281 minecraft:basalt
fill 156 292 287 156 294 287 minecraft:basalt
fill 156 292 301 156 295 301 minecraft:basalt
setblock 156 292 307 minecraft:basalt
setblock 157 292 276 minecraft:snow_block
fill 157 292 277 157 295 277 minecraft:packed_ice
fill 157 292 286 159 294 286 minecraft:basalt
setblock 157 292 316 minecraft:snow_block
fill 158 292 276 161 292 276 minecraft:packed_ice
fill 158 292 302 158 295 302 minecraft:basalt
setblock 158 292 315 minecraft:snow_block
fill 158 292 316 161 292 316 minecraft:packed_ice
setblock 159 292 281 minecraft:magma_block
setblock 159 292 302 minecraft:magma_block
setblock 159 292 314 minecraft:snow_block
fill 159 292 315 162 292 315 minecraft:packed_ice
setblock 160 292 277 minecraft:packed_ice
fill 160 292 280 161 292 280 minecraft:basalt
fill 160 292 285 160 295 285 minecraft:basalt
fill 160 292 303 160 295 303 minecraft:basalt
setblock 161 292 277 minecraft:snow_block
setblock 162 292 276 minecraft:snow_block
fill 162 292 277 165 292 277 minecraft:packed_ice
setblock 162 292 280 minecraft:magma_block
setblock 162 292 316 minecraft:snow_block
fill 163 292 276 166 292 276 minecraft:packed_ice
fill 163 292 286 164 295 286 minecraft:basalt
fill 163 292 302 164 295 302 minecraft:basalt
setblock 163 292 315 minecraft:snow_block
fill 163 292 316 166 292 316 minecraft:packed_ice
fill 164 292 315 167 292 315 minecraft:packed_ice
setblock 166 292 277 minecraft:snow_block
fill 166 292 286 166 295 287 minecraft:basalt
fill 166 292 301 166 295 301 minecraft:basalt
setblock 166 292 307 minecraft:basalt
fill 166 292 314 168 292 314 minecraft:packed_ice
setblock 167 292 276 minecraft:snow_block
fill 167 292 277 167 295 277 minecraft:packed_ice
fill 167 292 288 167 295 288 minecraft:basalt
fill 167 292 300 167 295 300 minecraft:basalt
setblock 167 292 316 minecraft:snow_block
fill 168 292 276 168 295 276 minecraft:packed_ice
fill 168 292 289 168 294 289 minecraft:basalt
setblock 168 292 299 minecraft:magma_block
setblock 168 292 315 minecraft:snow_block
fill 168 292 316 171 292 316 minecraft:packed_ice
fill 169 292 291 169 295 292 minecraft:basalt
fill 169 292 296 169 295 297 minecraft:basalt
setblock 169 292 314 minecraft:snow_block
fill 169 292 315 172 292 315 minecraft:packed_ice
setblock 170 292 304 minecraft:basalt
fill 170 292 314 170 295 314 minecraft:packed_ice
setblock 171 292 277 minecraft:snow_block
setblock 172 292 276 minecraft:snow_block
fill 172 292 277 172 295 277 minecraft:packed_ice
setblock 172 292 286 minecraft:basalt
setblock 172 292 316 minecraft:snow_block
fill 173 292 276 173 295 276 minecraft:packed_ice
setblock 173 292 288 minecraft:basalt
fill 173 292 300 173 292 301 minecraft:basalt
setblock 173 292 315 minecraft:snow_block
fill 173 292 316 173 295 316 minecraft:packed_ice
setblock 174 292 290 minecraft:basalt
setblock 174 292 291 minecraft:magma_block
setblock 174 292 297 minecraft:magma_block
setblock 174 292 298 minecraft:basalt
setblock 174 292 314 minecraft:snow_block
fill 174 292 315 174 295 315 minecraft:packed_ice
setblock 175 292 295 minecraft:basalt
fill 175 292 314 175 293 314 minecraft:packed_ice
setblock 176 292 277 minecraft:snow_block
setblock 177 292 275 minecraft:light_blue_concrete
setblock 177 292 276 minecraft:snow_block
fill 177 292 277 177 294 277 minecraft:packed_ice
setblock 177 292 316 minecraft:snow_block
fill 178 292 276 178 295 276 minecraft:packed_ice
setblock 178 292 315 minecraft:snow_block
fill 178 292 316 178 294 316 minecraft:packed_ice
fill 180 292 294 180 293 294 minecraft:packed_ice
setblock 180 292 297 minecraft:packed_ice
setblock 180 292 298 minecraft:snow_block
fill 180 292 299 180 294 300 minecraft:packed_ice
setblock 181 292 292 minecraft:snow_block
fill 181 292 293 181 294 293 minecraft:packed_ice
setblock 181 292 297 minecraft:snow_block
fill 181 292 298 181 295 298 minecraft:packed_ice
setblock 181 292 302 minecraft:snow_block
setblock 182 292 276 minecraft:snow_block
fill 182 292 277 182 295 277 minecraft:packed_ice
setblock 182 292 291 minecraft:snow_block
fill 182 292 292 182 295 292 minecraft:packed_ice
setblock 182 292 296 minecraft:snow_block
fill 182 292 297 182 295 297 minecraft:packed_ice
setblock 182 292 301 minecraft:snow_block
fill 182 292 302 182 295 302 minecraft:packed_ice
setblock 182 292 316 minecraft:snow_block
fill 141 293 277 141 308 277 minecraft:snow_block
setblock 141 293 278 minecraft:white_concrete
fill 142 293 276 142 296 276 minecraft:packed_ice
setblock 142 293 280 minecraft:snow_block
fill 142 293 281 142 296 281 minecraft:packed_ice
setblock 142 293 285 minecraft:snow_block
fill 142 293 286 142 293 289 minecraft:packed_ice
setblock 142 293 290 minecraft:snow_block
fill 142 293 291 142 295 291 minecraft:packed_ice
setblock 142 293 295 minecraft:snow_block
fill 142 293 296 142 296 296 minecraft:packed_ice
setblock 142 293 299 minecraft:packed_ice
setblock 142 293 300 minecraft:snow_block
fill 142 293 301 142 296 301 minecraft:packed_ice
setblock 143 293 279 minecraft:snow_block
fill 143 293 280 143 296 280 minecraft:packed_ice
setblock 143 293 294 minecraft:snow_block
fill 143 293 295 143 294 295 minecraft:packed_ice
fill 143 293 316 145 293 316 minecraft:packed_ice
fill 144 293 308 144 299 308 minecraft:packed_ice
setblock 145 293 277 minecraft:snow_block
fill 145 293 278 145 296 278 minecraft:packed_ice
setblock 146 293 276 minecraft:snow_block
fill 146 293 277 146 296 277 minecraft:packed_ice
setblock 146 293 316 minecraft:snow_block
fill 147 293 276 147 296 276 minecraft:packed_ice
setblock 147 293 315 minecraft:snow_block
fill 147 293 316 150 293 316 minecraft:packed_ice
setblock 148 293 279 minecraft:snow_block
fill 148 293 315 148 296 315 minecraft:packed_ice
setblock 149 293 277 minecraft:packed_ice
setblock 149 293 278 minecraft:snow_block
fill 149 293 279 152 293 279 minecraft:packed_ice
setblock 149 293 289 minecraft:magma_block
fill 149 293 290 149 293 291 minecraft:basalt
setblock 149 293 297 minecraft:basalt
setblock 149 293 298 minecraft:magma_block
setblock 149 293 299 minecraft:basalt
setblock 150 293 277 minecraft:snow_block
fill 150 293 278 150 296 278 minecraft:packed_ice
setblock 150 293 301 minecraft:basalt
setblock 151 293 276 minecraft:snow_block
fill 151 293 277 151 296 277 minecraft:packed_ice
setblock 151 293 316 minecraft:snow_block
fill 152 293 276 155 293 276 minecraft:packed_ice
setblock 152 293 285 minecraft:magma_block
setblock 152 293 303 minecraft:magma_block
setblock 152 293 315 minecraft:snow_block
fill 152 293 316 155 293 316 minecraft:packed_ice
setblock 153 293 279 minecraft:snow_block
fill 153 293 292 153 294 295 minecraft:basalt
fill 153 293 298 154 295 298 minecraft:basalt
setblock 153 293 314 minecraft:snow_block
fill 153 293 315 156 293 315 minecraft:packed_ice
setblock 154 293 278 minecraft:snow_block
fill 154 293 279 154 295 279 minecraft:packed_ice
fill 154 293 290 154 295 291 minecraft:basalt
fill 154 293 297 154 295 297 minecraft:basalt
fill 154 293 314 154 294 314 minecraft:packed_ice
setblock 155 293 277 minecraft:snow_block
fill 155 293 278 155 296 278 minecraft:packed_ice
fill 155 293 289 155 295 289 minecraft:basalt
setblock 155 293 299 minecraft:magma_block
setblock 155 293 305 minecraft:magma_block
setblock 156 293 276 minecraft:snow_block
fill 156 293 277 156 296 277 minecraft:packed_ice
fill 156 293 288 156 295 288 minecraft:basalt
fill 156 293 300 156 295 300 minecraft:basalt
setblock 156 293 316 minecraft:snow_block
fill 157 293 276 160 293 276 minecraft:packed_ice
fill 157 293 287 158 295 287 minecraft:basalt
fill 157 293 301 157 295 301 minecraft:basalt
setblock 157 293 315 minecraft:snow_block
fill 157 293 316 160 293 316 minecraft:packed_ice
setblock 158 293 301 minecraft:magma_block
fill 158 293 315 161 293 315 minecraft:packed_ice
setblock 159 293 281 minecraft:basalt
fill 159 293 302 162 295 302 minecraft:basalt
fill 159 293 307 162 293 307 minecraft:basalt
setblock 160 293 277 minecraft:snow_block
fill 160 293 286 162 295 286 minecraft:basalt
setblock 161 293 276 minecraft:snow_block
fill 161 293 277 164 293 277 minecraft:packed_ice
fill 161 293 281 163 293 281 minecraft:basalt
setblock 161 293 316 minecraft:snow_block
fill 162 293 276 165 293 276 minecraft:packed_ice
setblock 162 293 315 minecraft:snow_block
fill 162 293 316 165 293 316 minecraft:packed_ice
fill 163 293 315 166 293 315 minecraft:packed_ice
setblock 164 293 287 minecraft:magma_block
fill 164 293 301 165 295 301 minecraft:basalt
setblock 165 293 277 minecraft:snow_block
fill 165 293 287 165 294 287 minecraft:basalt
fill 165 293 314 165 296 314 minecraft:blue_ice
setblock 166 293 276 minecraft:snow_block
fill 166 293 277 166 296 277 minecraft:packed_ice
fill 166 293 288 166 295 288 minecraft:basalt
fill 166 293 300 166 295 300 minecraft:basalt
setblock 166 293 316 minecraft:snow_block
fill 167 293 276 167 296 276 minecraft:packed_ice
setblock 167 293 283 minecraft:magma_block
setblock 167 293 289 minecraft:magma_block
fill 167 293 299 168 295 299 minecraft:basalt
setblock 167 293 314 minecraft:packed_ice
setblock 167 293 315 minecraft:snow_block
fill 167 293 316 170 293 316 minecraft:packed_ice
fill 168 293 290 168 295 291 minecraft:basalt
fill 168 293 297 168 294 298 minecraft:basalt
setblock 168 293 314 minecraft:snow_block
fill 168 293 315 171 293 315 minecraft:packed_ice
fill 169 293 293 169 295 295 minecraft:basalt
fill 169 293 314 169 295 314 minecraft:packed_ice
setblock 170 293 276 minecraft:packed_ice
setblock 170 293 277 minecraft:snow_block
setblock 170 293 285 minecraft:magma_block
setblock 170 293 303 minecraft:magma_block
setblock 171 293 276 minecraft:snow_block
fill 171 293 277 171 295 278 minecraft:packed_ice
setblock 171 293 316 minecraft:snow_block
fill 172 293 276 172 296 276 minecraft:packed_ice
fill 172 293 278 172 294 278 minecraft:packed_ice
setblock 172 293 287 minecraft:basalt
setblock 172 293 315 minecraft:snow_block
fill 172 293 316 172 296 316 minecraft:packed_ice
setblock 173 293 289 minecraft:basalt
setblock 173 293 290 minecraft:magma_block
setblock 173 293 298 minecraft:basalt
setblock 173 293 299 minecraft:magma_block
setblock 173 293 314 minecraft:snow_block
fill 173 293 315 173 296 315 minecraft:packed_ice
setblock 174 293 314 minecraft:packed_ice
setblock 175 293 277 minecraft:snow_block
setblock 176 293 276 minecraft:snow_block
fill 176 293 277 176 295 277 minecraft:packed_ice
setblock 176 293 316 minecraft:snow_block
fill 177 293 275 177 308 275 minecraft:snow_block
fill 177 293 276 177 296 276 minecraft:packed_ice
setblock 177 293 315 minecraft:snow_block
fill 177 293 316 177 295 316 minecraft:packed_ice
setblock 180 293 297 minecraft:snow_block
fill 180 293 298 180 295 298 minecraft:packed_ice
setblock 181 293 276 minecraft:snow_block
setblock 181 293 292 minecraft:packed_ice
setblock 181 293 296 minecraft:snow_block
fill 181 293 297 181 296 297 minecraft:packed_ice
setblock 181 293 300 minecraft:packed_ice
setblock 181 293 301 minecraft:snow_block
fill 181 293 302 181 295 302 minecraft:packed_ice
setblock 181 293 316 minecraft:snow_block
fill 182 293 276 182 295 276 minecraft:packed_ice
fill 182 293 278 182 293 279 minecraft:packed_ice
setblock 182 293 290 minecraft:snow_block
fill 182 293 291 182 295 291 minecraft:packed_ice
setblock 182 293 295 minecraft:snow_block
fill 182 293 296 182 296 296 minecraft:packed_ice
setblock 182 293 300 minecraft:snow_block
fill 182 293 301 182 296 301 minecraft:packed_ice
setblock 182 293 304 minecraft:packed_ice
setblock 183 293 307 minecraft:white_concrete
fill 141 294 278 141 308 279 minecraft:snow_block
setblock 141 294 280 minecraft:light_blue_concrete
setblock 142 294 279 minecraft:snow_block
fill 142 294 280 142 297 280 minecraft:packed_ice
fill 142 294 282 142 294 283 minecraft:packed_ice
setblock 142 294 284 minecraft:snow_block
fill 142 294 285 142 294 286 minecraft:packed_ice
setblock 142 294 289 minecraft:snow_block
setblock 142 294 290 minecraft:packed_ice
setblock 142 294 294 minecraft:snow_block
fill 142 294 295 142 296 295 minecraft:packed_ice
setblock 142 294 299 minecraft:snow_block
fill 142 294 300 142 297 300 minecraft:packed_ice
setblock 143 294 278 minecraft:snow_block
fill 143 294 279 143 297 279 minecraft:packed_ice
fill 143 294 281 143 295 281 minecraft:packed_ice
setblock 143 294 294 minecraft:packed_ice
setblock 143 294 298 minecraft:snow_block
setblock 144 294 276 minecraft:packed_ice
setblock 144 294 277 minecraft:snow_block
setblock 144 294 278 minecraft:light[level=12]
setblock 144 294 285 minecraft:light[level=12]
setblock 144 294 292 minecraft:light[level=12]
setblock 144 294 299 minecraft:light[level=12]
setblock 144 294 306 minecraft:light[level=12]
setblock 144 294 313 minecraft:light[level=12]
setblock 144 294 316 minecraft:packed_ice
setblock 145 294 276 minecraft:snow_block
fill 145 294 277 145 297 277 minecraft:packed_ice
setblock 145 294 316 minecraft:snow_block
fill 146 294 276 146 297 276 minecraft:packed_ice
fill 146 294 316 149 294 316 minecraft:packed_ice
setblock 147 294 279 minecraft:snow_block
fill 147 294 315 147 295 315 minecraft:packed_ice
setblock 148 294 277 minecraft:packed_ice
setblock 148 294 278 minecraft:snow_block
fill 148 294 279 151 294 279 minecraft:packed_ice
setblock 149 294 277 minecraft:snow_block
fill 149 294 278 149 297 278 minecraft:packed_ice
setblock 150 294 276 minecraft:snow_block
fill 150 294 277 150 297 277 minecraft:packed_ice
setblock 150 294 299 minecraft:basalt
setblock 150 294 316 minecraft:snow_block
fill 151 294 276 154 294 276 minecraft:packed_ice
setblock 151 294 285 minecraft:light[level=12]
setblock 151 294 287 minecraft:magma_block
setblock 151 294 301 minecraft:basalt
setblock 151 294 306 minecraft:light[level=12]
setblock 151 294 313 minecraft:light[level=12]
setblock 151 294 315 minecraft:snow_block
fill 151 294 316 154 294 316 minecraft:packed_ice
setblock 152 294 279 minecraft:snow_block
setblock 152 294 314 minecraft:snow_block
fill 152 294 315 155 294 315 minecraft:packed_ice
setblock 153 294 278 minecraft:snow_block
fill 153 294 279 153 296 279 minecraft:packed_ice
setblock 153 294 314 minecraft:packed_ice
setblock 154 294 277 minecraft:snow_block
fill 154 294 278 154 297 278 minecraft:packed_ice
setblock 154 294 284 minecraft:basalt
setblock 154 294 292 minecraft:magma_block
fill 154 294 293 154 294 294 minecraft:basalt
fill 154 294 295 154 295 295 minecraft:magma_block
fill 154 294 296 154 295 296 minecraft:basalt
setblock 154 294 304 minecraft:magma_block
setblock 155 294 276 minecraft:snow_block
fill 155 294 277 155 297 277 minecraft:packed_ice
fill 155 294 290 155 295 290 minecraft:basalt
fill 155 294 298 155 295 299 minecraft:basalt
setblock 155 294 316 minecraft:snow_block
fill 156 294 276 159 294 276 minecraft:packed_ice
setblock 156 294 283 minecraft:basalt
setblock 156 294 289 minecraft:basalt
setblock 156 294 299 minecraft:basalt
setblock 156 294 315 minecraft:snow_block
fill 156 294 316 159 294 316 minecraft:packed_ice
setblock 157 294 288 minecraft:magma_block
setblock 157 294 300 minecraft:magma_block
fill 157 294 315 160 294 315 minecraft:packed_ice
setblock 158 294 278 minecraft:snow_block
setblock 158 294 292 minecraft:light[level=12]
setblock 158 294 299 minecraft:light[level=12]
fill 158 294 301 162 294 301 minecraft:basalt
setblock 158 294 306 minecraft:light[level=12]
setblock 158 294 313 minecraft:light[level=12]
fill 158 294 314 158 299 314 minecraft:packed_ice
setblock 159 294 277 minecraft:snow_block
fill 159 294 282 161 294 282 minecraft:basalt
fill 159 294 287 159 295 287 minecraft:basalt
fill 159 294 306 161 294 306 minecraft:basalt
setblock 160 294 275 minecraft:light_blue_concrete
setblock 160 294 276 minecraft:snow_block
fill 160 294 277 163 294 277 minecraft:packed_ice
fill 160 294 287 160 295 287 minecraft:magma_block
setblock 160 294 316 minecraft:snow_block
fill 161 294 276 164 294 276 minecraft:packed_ice
fill 161 294 287 164 294 287 minecraft:basalt
setblock 161 294 315 minecraft:snow_block
fill 161 294 316 164 294 316 minecraft:packed_ice
fill 162 294 315 165 294 315 minecraft:packed_ice
setblock 163 294 282 minecraft:basalt
setblock 163 294 301 minecraft:magma_block
setblock 163 294 306 minecraft:basalt
setblock 164 294 277 minecraft:snow_block
fill 164 294 313 164 296 314 minecraft:blue_ice
setblock 164 294 317 minecraft:white_concrete
setblock 165 294 276 minecraft:snow_block
fill 165 294 277 165 296 277 minecraft:packed_ice
setblock 165 294 278 minecraft:light[level=12]
fill 165 294 288 165 295 288 minecraft:basalt
setblock 165 294 292 minecraft:light[level=12]
setblock 165 294 299 minecraft:light[level=12]
fill 165 294 300 165 295 300 minecraft:basalt
setblock 165 294 306 minecraft:light[level=12]
fill 165 294 312 165 296 313 minecraft:blue_ice
setblock 165 294 316 minecraft:snow_block
fill 166 294 276 166 297 276 minecraft:packed_ice
setblock 166 294 283 minecraft:basalt
fill 166 294 289 167 294 289 minecraft:basalt
setblock 166 294 299 minecraft:basalt
setblock 166 294 305 minecraft:basalt
fill 166 294 313 166 296 314 minecraft:blue_ice
setblock 166 294 315 minecraft:snow_block
fill 166 294 316 169 294 316 minecraft:packed_ice
fill 167 294 290 167 295 290 minecraft:basalt
fill 167 294 298 167 295 298 minecraft:basalt
setblock 167 294 314 minecraft:snow_block
fill 167 294 315 170 294 315 minecraft:packed_ice
setblock 168 294 277 minecraft:packed_ice
setblock 168 294 284 minecraft:basalt
fill 168 294 292 168 294 296 minecraft:basalt
setblock 168 294 314 minecraft:packed_ice
setblock 169 294 277 minecraft:snow_block
setblock 170 294 276 minecraft:snow_block
fill 170 294 277 170 294 278 minecraft:packed_ice
setblock 170 294 316 minecraft:snow_block
fill 171 294 276 171 297 276 minecraft:packed_ice
setblock 171 294 301 minecraft:basalt
setblock 171 294 315 minecraft:snow_block
fill 171 294 316 171 297 316 minecraft:packed_ice
setblock 172 294 285 minecraft:light[level=12]
setblock 172 294 289 minecraft:magma_block
setblock 172 294 298 minecraft:magma_block
setblock 172 294 299 minecraft:basalt
setblock 172 294 306 minecraft:light[level=12]
setblock 172 294 313 minecraft:light[level=12]
setblock 172 294 314 minecraft:snow_block
fill 172 294 315 172 296 315 minecraft:packed_ice
setblock 173 294 296 minecraft:basalt
setblock 173 294 314 minecraft:packed_ice
setblock 174 294 277 minecraft:snow_block
setblock 175 294 276 minecraft:snow_block
fill 175 294 277 175 295 277 minecraft:packed_ice
setblock 175 294 316 minecraft:snow_block
fill 176 294 276 176 296 276 minecraft:packed_ice
setblock 176 294 315 minecraft:snow_block
fill 176 294 316 176 296 316 minecraft:packed_ice
setblock 179 294 278 minecraft:light[level=12]
setblock 179 294 285 minecraft:light[level=12]
setblock 179 294 292 minecraft:light[level=12]
setblock 179 294 299 minecraft:light[level=12]
setblock 179 294 306 minecraft:light[level=12]
setblock 179 294 313 minecraft:light[level=12]
setblock 180 294 276 minecraft:snow_block
setblock 180 294 296 minecraft:snow_block
setblock 180 294 297 minecraft:packed_ice
fill 181 294 276 181 295 276 minecraft:packed_ice
setblock 181 294 295 minecraft:snow_block
fill 181 294 296 181 296 296 minecraft:packed_ice
setblock 181 294 300 minecraft:snow_block
fill 181 294 301 181 297 301 minecraft:packed_ice
setblock 182 294 278 minecraft:packed_ice
setblock 182 294 279 minecraft:snow_block
fill 182 294 280 182 297 280 minecraft:packed_ice
setblock 182 294 290 minecraft:packed_ice
setblock 182 294 294 minecraft:snow_block
fill 182 294 295 182 297 295 minecraft:packed_ice
setblock 182 294 299 minecraft:snow_block
fill 182 294 300 182 297 300 minecraft:packed_ice
setblock 182 294 304 minecraft:snow_block
fill 183 294 307 183 308 307 minecraft:snow_block
fill 141 295 280 141 308 280 minecraft:snow_block
setblock 142 295 277 minecraft:packed_ice
setblock 142 295 278 minecraft:snow_block
fill 142 295 279 142 298 279 minecraft:packed_ice
setblock 142 295 282 minecraft:packed_ice
setblock 142 295 283 minecraft:snow_block
fill 142 295 284 142 297 285 minecraft:packed_ice
setblock 142 295 293 minecraft:snow_block
fill 142 295 294 142 296 294 minecraft:packed_ice
setblock 142 295 298 minecraft:snow_block
fill 142 295 299 142 298 299 minecraft:packed_ice
setblock 143 295 277 minecraft:snow_block
fill 143 295 278 144 297 278 minecraft:packed_ice
setblock 143 295 282 minecraft:snow_block
setblock 144 295 276 minecraft:snow_block
fill 144 295 277 144 298 277 minecraft:packed_ice
fill 144 295 279 144 296 279 minecraft:packed_ice
setblock 144 295 316 minecraft:snow_block
fill 145 295 276 145 298 276 minecraft:packed_ice
fill 145 295 316 148 295 316 minecraft:packed_ice
setblock 146 295 278 minecraft:packed_ice
setblock 147 295 278 minecraft:snow_block
fill 147 295 279 150 295 279 minecraft:packed_ice
setblock 148 295 277 minecraft:snow_block
fill 148 295 278 148 298 278 minecraft:packed_ice
setblock 149 295 276 minecraft:snow_block
fill 149 295 277 149 298 277 minecraft:packed_ice
setblock 149 295 316 minecraft:snow_block
fill 150 295 276 153 295 276 minecraft:packed_ice
setblock 150 295 291 minecraft:basalt
setblock 150 295 292 minecraft:magma_block
setblock 150 295 293 minecraft:basalt
setblock 150 295 295 minecraft:magma_block
fill 150 295 296 150 295 297 minecraft:basalt
setblock 150 295 315 minecraft:snow_block
fill 150 295 316 153 295 316 minecraft:packed_ice
setblock 151 295 279 minecraft:snow_block
fill 151 295 315 154 295 315 minecraft:packed_ice
setblock 152 295 278 minecraft:snow_block
fill 152 295 279 152 297 279 minecraft:packed_ice
setblock 152 295 314 minecraft:packed_ice
setblock 153 295 277 minecraft:snow_block
fill 153 295 278 153 298 278 minecraft:packed_ice
fill 153 295 286 153 295 287 minecraft:basalt
setblock 153 295 288 minecraft:magma_block
setblock 153 295 291 minecraft:magma_block
fill 153 295 292 153 295 293 minecraft:basalt
fill 153 295 294 154 295 294 minecraft:magma_block
fill 153 295 295 153 295 296 minecraft:basalt
setblock 153 295 297 minecraft:magma_block
setblock 153 295 300 minecraft:magma_block
setblock 153 295 302 minecraft:basalt
setblock 154 295 276 minecraft:snow_block
fill 154 295 277 154 298 277 minecraft:packed_ice
setblock 154 295 292 minecraft:basalt
fill 154 295 293 155 295 293 minecraft:magma_block
setblock 154 295 316 minecraft:snow_block
fill 155 295 276 158 295 276 minecraft:packed_ice
fill 155 295 291 155 295 292 minecraft:magma_block
fill 155 295 295 155 295 297 minecraft:magma_block
setblock 155 295 303 minecraft:basalt
setblock 155 295 315 minecraft:snow_block
fill 155 295 316 158 295 316 minecraft:packed_ice
setblock 156 295 284 minecraft:magma_block
setblock 156 295 287 minecraft:magma_block
fill 156 295 289 156 295 290 minecraft:magma_block
fill 156 295 298 156 295 299 minecraft:magma_block
setblock 156 295 302 minecraft:magma_block
fill 156 295 315 159 295 315 minecraft:packed_ice
setblock 157 295 278 minecraft:snow_block
fill 157 295 286 158 295 286 minecraft:basalt
setblock 157 295 288 minecraft:basalt
setblock 157 295 289 minecraft:magma_block
setblock 157 295 299 minecraft:magma_block
setblock 157 295 300 minecraft:basalt
setblock 157 295 302 minecraft:basalt
setblock 158 295 277 minecraft:snow_block
setblock 158 295 283 minecraft:basalt
fill 158 295 288 160 295 288 minecraft:magma_block
fill 158 295 300 160 295 300 minecraft:magma_block
setblock 158 295 301 minecraft:basalt
fill 158 295 304 158 295 305 minecraft:basalt
setblock 159 295 276 minecraft:snow_block
fill 159 295 277 162 295 277 minecraft:packed_ice
setblock 159 295 283 minecraft:magma_block
setblock 159 295 286 minecraft:magma_block
fill 159 295 301 162 295 301 minecraft:magma_block
setblock 159 295 304 minecraft:magma_block
setblock 159 295 316 minecraft:snow_block
fill 160 295 275 160 308 275 minecraft:snow_block
fill 160 295 276 163 295 276 minecraft:packed_ice
setblock 160 295 315 minecraft:snow_block
fill 160 295 316 163 295 316 minecraft:packed_ice
setblock 161 295 285 minecraft:basalt
fill 161 295 287 162 295 287 minecraft:magma_block
setblock 162 295 285 minecraft:magma_block
fill 162 295 288 164 295 288 minecraft:magma_block
fill 162 295 300 164 295 300 minecraft:magma_block
setblock 162 295 303 minecraft:magma_block
setblock 163 295 277 minecraft:snow_block
fill 163 295 285 164 295 285 minecraft:basalt
fill 163 295 287 164 295 287 minecraft:basalt
setblock 163 295 301 minecraft:basalt
fill 163 295 303 164 295 303 minecraft:basalt
fill 163 295 315 164 295 315 minecraft:packed_ice
setblock 164 295 276 minecraft:snow_block
setblock 164 295 277 minecraft:packed_ice
setblock 164 295 305 minecraft:basalt
setblock 164 295 312 minecraft:blue_ice
fill 164 295 316 164 295 317 minecraft:snow_block
fill 165 295 276 165 298 276 minecraft:packed_ice
setblock 165 295 284 minecraft:magma_block
setblock 165 295 287 minecraft:magma_block
fill 165 295 289 166 295 289 minecraft:magma_block
fill 165 295 299 166 295 299 minecraft:magma_block
setblock 165 295 302 minecraft:magma_block
fill 165 295 310 165 296 311 minecraft:blue_ice
setblock 165 295 315 minecraft:snow_block
fill 165 295 316 168 295 316 minecraft:packed_ice
setblock 166 295 290 minecraft:magma_block
setblock 166 295 298 minecraft:magma_block
fill 166 295 302 167 295 302 minecraft:basalt
setblock 166 295 312 minecraft:blue_ice
fill 166 295 315 169 295 315 minecraft:packed_ice
setblock 167 295 289 minecraft:basalt
fill 167 295 291 167 295 293 minecraft:magma_block
fill 167 295 295 167 295 297 minecraft:magma_block
setblock 168 295 277 minecraft:snow_block
setblock 168 295 286 minecraft:magma_block
setblock 168 295 289 minecraft:magma_block
fill 168 295 292 168 295 295 minecraft:magma_block
fill 168 295 296 168 295 297 minecraft:basalt
setblock 168 295 298 minecraft:magma_block
setblock 168 295 301 minecraft:magma_block
setblock 169 295 276 minecraft:snow_block
fill 169 295 277 170 297 277 minecraft:packed_ice
setblock 169 295 286 minecraft:basalt
setblock 169 295 316 minecraft:snow_block
fill 170 295 276 170 298 276 minecraft:packed_ice
setblock 170 295 315 minecraft:snow_block
fill 170 295 316 170 298 316 minecraft:packed_ice
setblock 171 295 291 minecraft:magma_block
fill 171 295 292 171 295 293 minecraft:basalt
setblock 171 295 294 minecraft:magma_block
fill 171 295 295 171 295 296 minecraft:basalt
setblock 171 295 297 minecraft:magma_block
setblock 171 295 314 minecraft:snow_block
fill 171 295 315 171 297 315 minecraft:packed_ice
setblock 172 295 297 minecraft:basalt
setblock 173 295 277 minecraft:snow_block
setblock 174 295 276 minecraft:snow_block
fill 174 295 277 174 296 277 minecraft:packed_ice
setblock 174 295 316 minecraft:snow_block
fill 175 295 276 175 297 276 minecraft:packed_ice
setblock 175 295 315 minecraft:snow_block
fill 175 295 316 175 296 316 minecraft:packed_ice
setblock 179 295 276 minecraft:snow_block
setblock 180 295 276 minecraft:packed_ice
setblock 180 295 299 minecraft:packed_ice
setblock 181 295 294 minecraft:snow_block
fill 181 295 295 181 296 295 minecraft:packed_ice
setblock 181 295 299 minecraft:snow_block
fill 181 295 300 181 297 300 minecraft:packed_ice
setblock 182 295 278 minecraft:snow_block
fill 182 295 279 182 298 279 minecraft:packed_ice
fill 182 295 281 182 296 281 minecraft:packed_ice
setblock 182 295 293 minecraft:snow_block
fill 182 295 294 182 298 294 minecraft:packed_ice
setblock 182 295 298 minecraft:snow_block
fill 182 295 299 182 298 299 minecraft:packed_ice
setblock 182 295 303 minecraft:snow_block
fill 182 295 304 182 298 304 minecraft:packed_ice
setblock 183 295 297 minecraft:white_concrete
setblock 142 296 277 minecraft:snow_block
fill 142 296 278 142 299 278 minecraft:packed_ice
setblock 142 296 282 minecraft:snow_block
fill 142 296 283 143 298 283 minecraft:packed_ice
setblock 142 296 297 minecraft:snow_block
fill 142 296 298 142 297 298 minecraft:packed_ice
setblock 143 296 276 minecraft:snow_block
fill 143 296 277 143 299 277 minecraft:packed_ice
setblock 143 296 281 minecraft:snow_block
fill 143 296 282 143 299 282 minecraft:packed_ice
fill 144 296 276 144 299 276 minecraft:packed_ice
setblock 144 296 280 minecraft:snow_block
setblock 144 296 286 minecraft:light[level=15]
setblock 144 296 294 minecraft:light[level=15]
setblock 144 296 302 minecraft:light[level=15]
setblock 144 296 310 minecraft:light[level=15]
fill 145 296 316 147 296 316 minecraft:packed_ice
setblock 146 296 278 minecraft:snow_block
setblock 147 296 277 minecraft:snow_block
fill 147 296 278 147 298 279 minecraft:packed_ice
schedule function dropper:buildpart/63_12 1t
