fill 299 160 524 301 160 526 minecraft:redstone_block
fill 307 160 520 309 160 522 minecraft:redstone_block
fill 307 160 528 309 160 530 minecraft:redstone_block
fill 290 161 525 298 161 525 minecraft:gold_block
fill 292 161 524 298 161 524 minecraft:gold_block
fill 292 161 526 298 161 526 minecraft:gold_block
fill 294 161 523 316 161 523 minecraft:gold_block
fill 294 161 527 316 161 527 minecraft:gold_block
fill 295 161 515 296 162 516 minecraft:gold_block
fill 295 161 534 296 162 535 minecraft:gold_block
fill 296 161 517 300 161 519 minecraft:gold_block
fill 296 161 531 300 161 533 minecraft:gold_block
fill 297 161 516 299 162 516 minecraft:gold_block
fill 297 161 520 306 161 520 minecraft:gold_block
fill 297 161 530 306 161 530 minecraft:gold_block
fill 297 161 534 299 162 534 minecraft:gold_block
fill 298 161 521 306 161 521 minecraft:gold_block
fill 298 161 529 306 161 529 minecraft:gold_block
fill 299 161 522 306 161 522 minecraft:gold_block
fill 299 161 528 306 161 528 minecraft:gold_block
fill 301 161 518 301 161 519 minecraft:gold_block
fill 301 161 531 301 161 532 minecraft:gold_block
fill 302 161 519 314 161 519 minecraft:gold_block
fill 302 161 524 303 161 526 minecraft:gold_block
fill 302 161 531 314 161 531 minecraft:gold_block
fill 303 161 514 307 161 518 minecraft:gold_block
fill 303 161 532 307 161 536 minecraft:gold_block
fill 304 161 512 306 162 513 minecraft:gold_block
fill 304 161 537 306 162 538 minecraft:gold_block
fill 305 161 510 305 162 511 minecraft:gold_block
fill 305 161 539 305 162 540 minecraft:gold_block
fill 307 161 524 318 161 526 minecraft:gold_block
fill 309 161 518 314 161 518 minecraft:gold_block
fill 309 161 532 314 161 532 minecraft:gold_block
fill 310 161 517 314 162 517 minecraft:gold_block
fill 310 161 520 311 161 522 minecraft:gold_block
fill 310 161 528 311 161 530 minecraft:gold_block
fill 310 161 533 314 162 533 minecraft:gold_block
fill 311 161 516 315 162 516 minecraft:gold_block
fill 311 161 534 315 162 534 minecraft:gold_block
fill 312 161 520 312 162 521 minecraft:gold_block
fill 312 161 529 312 162 530 minecraft:gold_block
fill 313 161 520 313 162 520 minecraft:gold_block
fill 313 161 530 313 162 530 minecraft:gold_block
fill 314 161 515 315 162 515 minecraft:gold_block
fill 314 161 535 315 162 535 minecraft:gold_block
fill 319 161 525 320 162 525 minecraft:gold_block
fill 283 162 511 289 162 551 minecraft:light_blue_concrete
fill 290 162 511 291 162 524 minecraft:light_blue_concrete
fill 290 162 525 294 162 525 minecraft:gold_block
fill 290 162 526 291 162 551 minecraft:light_blue_concrete
fill 292 162 511 293 162 523 minecraft:light_blue_concrete
fill 292 162 524 296 162 524 minecraft:gold_block
fill 292 162 526 296 162 526 minecraft:gold_block
fill 292 162 527 293 162 551 minecraft:light_blue_concrete
fill 294 162 511 294 162 522 minecraft:light_blue_concrete
fill 294 162 523 297 162 523 minecraft:gold_block
fill 294 162 527 297 162 527 minecraft:gold_block
fill 294 162 528 294 162 551 minecraft:light_blue_concrete
fill 295 162 511 302 162 514 minecraft:light_blue_concrete
fill 295 162 517 295 162 522 minecraft:light_blue_concrete
fill 295 162 525 297 162 525 minecraft:yellow_concrete
fill 295 162 528 295 162 533 minecraft:light_blue_concrete
fill 295 162 536 302 162 551 minecraft:light_blue_concrete
fill 296 162 517 297 162 519 minecraft:gold_block
fill 296 162 520 296 162 522 minecraft:light_blue_concrete
fill 296 162 528 296 162 530 minecraft:light_blue_concrete
fill 296 162 531 297 162 533 minecraft:gold_block
fill 297 162 515 302 162 515 minecraft:light_blue_concrete
fill 297 162 520 298 162 520 minecraft:gold_block
fill 297 162 521 297 162 522 minecraft:light_blue_concrete
setblock 297 162 524 minecraft:yellow_concrete
setblock 297 162 526 minecraft:yellow_concrete
fill 297 162 528 297 162 529 minecraft:light_blue_concrete
fill 297 162 530 298 162 530 minecraft:gold_block
fill 297 162 535 302 162 535 minecraft:light_blue_concrete
fill 298 162 517 300 162 517 minecraft:gold_block
fill 298 162 518 299 162 519 minecraft:yellow_concrete
setblock 298 162 521 minecraft:gold_block
setblock 298 162 522 minecraft:light_blue_concrete
fill 298 162 523 298 162 527 minecraft:pearlescent_froglight
setblock 298 162 528 minecraft:light_blue_concrete
setblock 298 162 529 minecraft:gold_block
fill 298 162 531 299 162 532 minecraft:yellow_concrete
fill 298 162 533 300 162 533 minecraft:gold_block
fill 299 162 520 302 162 521 minecraft:yellow_concrete
setblock 299 162 522 minecraft:gold_block
fill 299 162 523 303 162 523 minecraft:pearlescent_froglight
fill 299 162 524 301 162 526 minecraft:light_blue_concrete
fill 299 162 527 303 162 527 minecraft:pearlescent_froglight
setblock 299 162 528 minecraft:gold_block
fill 299 162 529 302 162 530 minecraft:yellow_concrete
fill 300 162 516 302 162 516 minecraft:light_blue_concrete
fill 300 162 518 301 162 518 minecraft:gold_block
fill 300 162 519 301 162 519 minecraft:yellow_concrete
fill 300 162 522 302 162 522 minecraft:yellow_concrete
fill 300 162 528 302 162 528 minecraft:yellow_concrete
fill 300 162 531 301 162 531 minecraft:yellow_concrete
fill 300 162 532 301 162 532 minecraft:gold_block
fill 300 162 534 302 162 534 minecraft:light_blue_concrete
fill 301 162 517 302 162 517 minecraft:light_blue_concrete
fill 301 162 533 302 162 533 minecraft:light_blue_concrete
setblock 302 162 518 minecraft:light_blue_concrete
fill 302 162 519 303 162 519 minecraft:gold_block
fill 302 162 524 302 162 526 minecraft:pearlescent_froglight
fill 302 162 531 303 162 531 minecraft:gold_block
setblock 302 162 532 minecraft:light_blue_concrete
fill 303 162 511 303 162 513 minecraft:light_blue_concrete
fill 303 162 514 303 162 518 minecraft:gold_block
setblock 303 162 520 minecraft:gold_block
fill 303 162 521 304 162 521 minecraft:yellow_concrete
fill 303 162 522 305 162 522 minecraft:white_concrete
fill 303 162 524 303 162 526 minecraft:sea_lantern
fill 303 162 528 305 162 528 minecraft:white_concrete
fill 303 162 529 304 162 529 minecraft:yellow_concrete
setblock 303 162 530 minecraft:gold_block
fill 303 162 532 303 162 536 minecraft:gold_block
fill 303 162 537 303 162 551 minecraft:light_blue_concrete
setblock 304 162 511 minecraft:light_blue_concrete
fill 304 162 514 304 162 516 minecraft:gold_block
fill 304 162 517 305 162 520 minecraft:yellow_concrete
fill 304 162 523 306 162 523 minecraft:sea_lantern
fill 304 162 527 306 162 527 minecraft:sea_lantern
fill 304 162 530 305 162 533 minecraft:yellow_concrete
fill 304 162 534 304 162 536 minecraft:gold_block
fill 304 162 539 304 162 551 minecraft:light_blue_concrete
fill 305 162 514 307 162 514 minecraft:gold_block
fill 305 162 515 305 162 516 minecraft:yellow_concrete
setblock 305 162 521 minecraft:white_concrete
setblock 305 162 529 minecraft:white_concrete
fill 305 162 534 305 162 535 minecraft:yellow_concrete
fill 305 162 536 307 162 536 minecraft:gold_block
fill 305 162 541 323 162 551 minecraft:light_blue_concrete
fill 306 162 511 323 162 511 minecraft:light_blue_concrete
fill 306 162 515 307 162 516 minecraft:gold_block
fill 306 162 517 306 162 518 minecraft:yellow_concrete
fill 306 162 519 306 162 522 minecraft:pearlescent_froglight
fill 306 162 528 306 162 531 minecraft:pearlescent_froglight
fill 306 162 532 306 162 533 minecraft:yellow_concrete
fill 306 162 534 307 162 535 minecraft:gold_block
fill 306 162 539 323 162 540 minecraft:light_blue_concrete
fill 307 162 512 323 162 513 minecraft:light_blue_concrete
fill 307 162 517 307 162 518 minecraft:gold_block
fill 307 162 519 310 162 519 minecraft:pearlescent_froglight
fill 307 162 520 309 162 522 minecraft:light_blue_concrete
fill 307 162 523 310 162 523 minecraft:pearlescent_froglight
fill 307 162 524 307 162 526 minecraft:sea_lantern
fill 307 162 527 310 162 527 minecraft:pearlescent_froglight
fill 307 162 528 309 162 530 minecraft:light_blue_concrete
fill 307 162 531 310 162 531 minecraft:pearlescent_froglight
fill 307 162 532 307 162 533 minecraft:gold_block
fill 307 162 537 323 162 538 minecraft:light_blue_concrete
fill 308 162 514 308 162 518 minecraft:light_blue_concrete
fill 308 162 524 308 162 526 minecraft:white_concrete
fill 308 162 532 308 162 536 minecraft:light_blue_concrete
fill 309 162 514 309 162 517 minecraft:light_blue_concrete
fill 309 162 518 310 162 518 minecraft:gold_block
fill 309 162 524 313 162 524 minecraft:yellow_concrete
setblock 309 162 525 minecraft:white_concrete
fill 309 162 526 313 162 526 minecraft:yellow_concrete
fill 309 162 532 310 162 532 minecraft:gold_block
fill 309 162 533 309 162 536 minecraft:light_blue_concrete
fill 310 162 514 310 162 516 minecraft:light_blue_concrete
fill 310 162 520 310 162 522 minecraft:pearlescent_froglight
fill 310 162 525 315 162 525 minecraft:yellow_concrete
fill 310 162 528 310 162 530 minecraft:pearlescent_froglight
fill 310 162 534 310 162 536 minecraft:light_blue_concrete
fill 311 162 514 313 162 515 minecraft:light_blue_concrete
fill 311 162 518 311 162 521 minecraft:yellow_concrete
fill 311 162 522 311 162 523 minecraft:gold_block
fill 311 162 527 311 162 528 minecraft:gold_block
fill 311 162 529 311 162 532 minecraft:yellow_concrete
fill 311 162 535 313 162 536 minecraft:light_blue_concrete
fill 312 162 518 312 162 519 minecraft:yellow_concrete
fill 312 162 522 323 162 522 minecraft:light_blue_concrete
fill 312 162 523 316 162 523 minecraft:gold_block
fill 312 162 527 316 162 527 minecraft:gold_block
fill 312 162 528 323 162 528 minecraft:light_blue_concrete
fill 312 162 531 312 162 532 minecraft:yellow_concrete
fill 313 162 518 314 162 519 minecraft:gold_block
fill 313 162 521 323 162 521 minecraft:light_blue_concrete
fill 313 162 529 323 162 529 minecraft:light_blue_concrete
fill 313 162 531 314 162 532 minecraft:gold_block
fill 314 162 514 323 162 514 minecraft:light_blue_concrete
fill 314 162 520 323 162 520 minecraft:light_blue_concrete
fill 314 162 524 318 162 524 minecraft:gold_block
fill 314 162 526 318 162 526 minecraft:gold_block
fill 314 162 530 323 162 530 minecraft:light_blue_concrete
fill 314 162 536 323 162 536 minecraft:light_blue_concrete
fill 315 162 517 323 162 519 minecraft:light_blue_concrete
fill 315 162 531 323 162 533 minecraft:light_blue_concrete
fill 316 162 515 323 162 516 minecraft:light_blue_concrete
fill 316 162 525 318 162 525 minecraft:gold_block
fill 316 162 534 323 162 535 minecraft:light_blue_concrete
fill 317 162 523 323 162 523 minecraft:light_blue_concrete
fill 317 162 527 323 162 527 minecraft:light_blue_concrete
fill 319 162 524 323 162 524 minecraft:light_blue_concrete
fill 319 162 526 323 162 526 minecraft:light_blue_concrete
fill 321 162 525 323 162 525 minecraft:light_blue_concrete
fill 298 163 518 301 164 533 minecraft:gray_concrete
fill 302 163 518 313 164 521 minecraft:gray_concrete
fill 302 163 529 313 164 533 minecraft:gray_concrete
fill 305 163 510 305 197 510 minecraft:white_concrete
fill 309 163 522 313 164 528 minecraft:gray_concrete
fill 298 165 518 298 177 518 minecraft:gray_concrete
setblock 298 165 519 minecraft:light_blue_stained_glass
fill 298 165 520 313 178 520 minecraft:gray_concrete
setblock 298 165 521 minecraft:light_blue_stained_glass
fill 298 165 522 301 178 522 minecraft:gray_concrete
setblock 298 165 523 minecraft:sea_lantern
fill 298 165 524 301 178 524 minecraft:gray_concrete
setblock 298 165 525 minecraft:sea_lantern
fill 298 165 526 301 178 526 minecraft:gray_concrete
setblock 298 165 527 minecraft:sea_lantern
fill 298 165 528 301 178 528 minecraft:gray_concrete
setblock 298 165 529 minecraft:light_blue_stained_glass
fill 298 165 530 313 178 530 minecraft:gray_concrete
setblock 298 165 531 minecraft:black_stained_glass
fill 298 165 532 298 178 533 minecraft:gray_concrete
setblock 299 165 518 minecraft:black_stained_glass
fill 299 165 519 312 178 519 minecraft:gray_concrete
fill 299 165 521 312 178 521 minecraft:gray_concrete
fill 299 165 523 301 178 523 minecraft:gray_concrete
fill 299 165 525 301 178 525 minecraft:gray_concrete
fill 299 165 527 301 178 527 minecraft:gray_concrete
fill 299 165 529 312 178 529 minecraft:gray_concrete
fill 299 165 531 312 178 532 minecraft:gray_concrete
setblock 299 165 533 minecraft:sea_lantern
fill 300 165 518 300 177 518 minecraft:gray_concrete
fill 300 165 533 300 178 533 minecraft:gray_concrete
setblock 301 165 518 minecraft:sea_lantern
setblock 301 165 533 minecraft:black_stained_glass
fill 302 165 518 302 177 518 minecraft:gray_concrete
fill 302 165 533 302 178 533 minecraft:gray_concrete
setblock 303 165 518 minecraft:sea_lantern
setblock 303 165 533 minecraft:light_blue_stained_glass
fill 304 165 518 304 177 518 minecraft:gray_concrete
fill 304 165 533 304 178 533 minecraft:gray_concrete
setblock 305 165 518 minecraft:light_blue_stained_glass
setblock 305 165 533 minecraft:light_blue_stained_glass
fill 306 165 518 306 177 518 minecraft:gray_concrete
fill 306 165 533 306 178 533 minecraft:gray_concrete
setblock 307 165 518 minecraft:black_stained_glass
setblock 307 165 533 minecraft:sea_lantern
fill 308 165 518 308 177 518 minecraft:gray_concrete
fill 308 165 533 308 178 533 minecraft:gray_concrete
setblock 309 165 518 minecraft:sea_lantern
fill 309 165 522 312 178 528 minecraft:gray_concrete
setblock 309 165 533 minecraft:black_stained_glass
fill 310 165 518 310 177 518 minecraft:gray_concrete
fill 310 165 533 310 178 533 minecraft:gray_concrete
setblock 311 165 518 minecraft:light_blue_stained_glass
setblock 311 165 533 minecraft:black_stained_glass
fill 312 165 518 313 177 518 minecraft:gray_concrete
fill 312 165 533 313 178 533 minecraft:gray_concrete
setblock 313 165 519 minecraft:black_stained_glass
setblock 313 165 521 minecraft:sea_lantern
fill 313 165 522 313 178 522 minecraft:gray_concrete
setblock 313 165 523 minecraft:sea_lantern
fill 313 165 524 313 178 524 minecraft:gray_concrete
setblock 313 165 525 minecraft:black_stained_glass
fill 313 165 526 313 178 526 minecraft:gray_concrete
setblock 313 165 527 minecraft:black_stained_glass
fill 313 165 528 313 178 528 minecraft:gray_concrete
setblock 313 165 529 minecraft:light_blue_stained_glass
setblock 313 165 531 minecraft:sea_lantern
fill 313 165 532 313 178 532 minecraft:gray_concrete
fill 282 166 516 282 171 519 minecraft:pearlescent_froglight
fill 282 166 528 282 171 531 minecraft:pearlescent_froglight
fill 282 166 540 282 171 543 minecraft:pearlescent_froglight
fill 282 166 552 285 171 552 minecraft:pearlescent_froglight
fill 283 166 511 285 221 511 minecraft:quartz_block
fill 283 166 521 283 221 523 minecraft:quartz_block
fill 283 166 533 283 221 535 minecraft:quartz_block
fill 283 166 545 283 221 547 minecraft:quartz_block
fill 289 166 510 292 171 510 minecraft:pearlescent_froglight
fill 289 166 551 291 221 551 minecraft:quartz_block
fill 294 166 552 297 171 552 minecraft:pearlescent_froglight
fill 295 166 511 297 221 511 minecraft:quartz_block
fill 298 166 519 298 167 519 minecraft:gray_concrete
fill 298 166 521 298 167 521 minecraft:gray_concrete
fill 298 166 523 298 167 523 minecraft:gray_concrete
fill 298 166 525 298 167 525 minecraft:gray_concrete
fill 298 166 527 298 167 527 minecraft:gray_concrete
fill 298 166 529 298 167 529 minecraft:gray_concrete
fill 298 166 531 298 167 531 minecraft:gray_concrete
fill 299 166 518 299 167 518 minecraft:gray_concrete
fill 299 166 533 299 167 533 minecraft:gray_concrete
fill 301 166 510 304 171 510 minecraft:pearlescent_froglight
fill 301 166 518 301 167 518 minecraft:gray_concrete
fill 301 166 533 301 167 533 minecraft:gray_concrete
fill 301 166 551 303 221 551 minecraft:quartz_block
fill 303 166 518 303 167 518 minecraft:gray_concrete
fill 303 166 533 303 167 533 minecraft:gray_concrete
fill 305 166 518 305 167 518 minecraft:gray_concrete
fill 305 166 533 305 167 533 minecraft:gray_concrete
fill 306 166 552 309 171 552 minecraft:pearlescent_froglight
fill 307 166 511 309 221 511 minecraft:quartz_block
fill 307 166 518 307 167 518 minecraft:gray_concrete
fill 307 166 533 307 167 533 minecraft:gray_concrete
fill 309 166 518 309 167 518 minecraft:gray_concrete
fill 309 166 533 309 167 533 minecraft:gray_concrete
fill 311 166 518 311 167 518 minecraft:gray_concrete
fill 311 166 533 311 167 533 minecraft:gray_concrete
fill 313 166 510 316 171 510 minecraft:pearlescent_froglight
fill 313 166 519 313 167 519 minecraft:gray_concrete
fill 313 166 521 313 167 521 minecraft:gray_concrete
fill 313 166 523 313 167 523 minecraft:gray_concrete
fill 313 166 525 313 167 525 minecraft:gray_concrete
fill 313 166 527 313 167 527 minecraft:gray_concrete
fill 313 166 529 313 167 529 minecraft:gray_concrete
fill 313 166 531 313 167 531 minecraft:gray_concrete
fill 313 166 551 315 221 551 minecraft:quartz_block
fill 318 166 552 321 171 552 minecraft:pearlescent_froglight
fill 319 166 511 321 221 511 minecraft:quartz_block
fill 323 166 519 323 221 521 minecraft:quartz_block
fill 323 166 531 323 221 533 minecraft:quartz_block
fill 323 166 543 323 221 545 minecraft:quartz_block
fill 324 166 511 324 171 514 minecraft:pearlescent_froglight
fill 324 166 523 324 171 526 minecraft:pearlescent_froglight
fill 324 166 535 324 171 538 minecraft:pearlescent_froglight
fill 324 166 547 324 171 550 minecraft:pearlescent_froglight
setblock 285 167 513 minecraft:light[level=14]
setblock 285 167 521 minecraft:light[level=14]
setblock 285 167 529 minecraft:light[level=14]
setblock 285 167 537 minecraft:light[level=14]
setblock 285 167 545 minecraft:light[level=14]
setblock 293 167 513 minecraft:light[level=14]
setblock 293 167 521 minecraft:light[level=14]
setblock 293 167 529 minecraft:light[level=14]
setblock 293 167 537 minecraft:light[level=14]
setblock 293 167 545 minecraft:light[level=14]
setblock 301 167 513 minecraft:light[level=14]
setblock 301 167 537 minecraft:light[level=14]
setblock 301 167 545 minecraft:light[level=14]
setblock 309 167 513 minecraft:light[level=14]
setblock 309 167 537 minecraft:light[level=14]
setblock 309 167 545 minecraft:light[level=14]
setblock 317 167 513 minecraft:light[level=14]
setblock 317 167 521 minecraft:light[level=14]
setblock 317 167 529 minecraft:light[level=14]
setblock 317 167 537 minecraft:light[level=14]
setblock 317 167 545 minecraft:light[level=14]
fill 288 168 537 288 169 537 minecraft:light_blue_stained_glass
setblock 298 168 519 minecraft:black_stained_glass
setblock 298 168 521 minecraft:black_stained_glass
setblock 298 168 523 minecraft:sea_lantern
setblock 298 168 525 minecraft:black_stained_glass
setblock 298 168 527 minecraft:black_stained_glass
setblock 298 168 529 minecraft:sea_lantern
setblock 298 168 531 minecraft:black_stained_glass
setblock 299 168 518 minecraft:sea_lantern
setblock 299 168 533 minecraft:black_stained_glass
setblock 301 168 518 minecraft:black_stained_glass
setblock 301 168 533 minecraft:sea_lantern
setblock 303 168 518 minecraft:sea_lantern
setblock 303 168 533 minecraft:light_blue_stained_glass
setblock 305 168 518 minecraft:sea_lantern
setblock 305 168 533 minecraft:sea_lantern
setblock 307 168 518 minecraft:light_blue_stained_glass
setblock 307 168 533 minecraft:black_stained_glass
setblock 309 168 518 minecraft:black_stained_glass
setblock 309 168 533 minecraft:sea_lantern
setblock 311 168 518 minecraft:black_stained_glass
setblock 311 168 533 minecraft:light_blue_stained_glass
setblock 313 168 519 minecraft:sea_lantern
setblock 313 168 521 minecraft:black_stained_glass
setblock 313 168 523 minecraft:black_stained_glass
setblock 313 168 525 minecraft:sea_lantern
setblock 313 168 527 minecraft:sea_lantern
setblock 313 168 529 minecraft:black_stained_glass
setblock 313 168 531 minecraft:black_stained_glass
fill 298 169 519 298 170 519 minecraft:gray_concrete
fill 298 169 521 298 170 521 minecraft:gray_concrete
fill 298 169 523 298 170 523 minecraft:gray_concrete
fill 298 169 525 298 170 525 minecraft:gray_concrete
fill 298 169 527 298 170 527 minecraft:gray_concrete
fill 298 169 529 298 170 529 minecraft:gray_concrete
fill 298 169 531 298 170 531 minecraft:gray_concrete
fill 299 169 518 299 170 518 minecraft:gray_concrete
fill 299 169 533 299 170 533 minecraft:gray_concrete
fill 301 169 518 301 170 518 minecraft:gray_concrete
fill 301 169 533 301 170 533 minecraft:gray_concrete
fill 303 169 518 303 170 518 minecraft:gray_concrete
fill 303 169 533 303 170 533 minecraft:gray_concrete
fill 305 169 518 305 170 518 minecraft:gray_concrete
fill 305 169 533 305 170 533 minecraft:gray_concrete
fill 307 169 518 307 170 518 minecraft:gray_concrete
fill 307 169 533 307 170 533 minecraft:gray_concrete
fill 309 169 518 309 170 518 minecraft:gray_concrete
fill 309 169 533 309 170 533 minecraft:gray_concrete
fill 311 169 518 311 170 518 minecraft:gray_concrete
fill 311 169 533 311 170 533 minecraft:gray_concrete
fill 313 169 519 313 170 519 minecraft:gray_concrete
fill 313 169 521 313 170 521 minecraft:gray_concrete
fill 313 169 523 313 170 523 minecraft:gray_concrete
fill 313 169 525 313 170 525 minecraft:gray_concrete
fill 313 169 527 313 170 527 minecraft:gray_concrete
fill 313 169 529 313 170 529 minecraft:gray_concrete
fill 313 169 531 313 170 531 minecraft:gray_concrete
fill 288 170 537 288 179 537 minecraft:smooth_quartz
setblock 298 171 519 minecraft:black_stained_glass
setblock 298 171 521 minecraft:sea_lantern
setblock 298 171 523 minecraft:black_stained_glass
setblock 298 171 525 minecraft:light_blue_stained_glass
setblock 298 171 527 minecraft:black_stained_glass
setblock 298 171 529 minecraft:black_stained_glass
setblock 298 171 531 minecraft:light_blue_stained_glass
setblock 299 171 518 minecraft:light_blue_stained_glass
setblock 299 171 533 minecraft:black_stained_glass
setblock 301 171 518 minecraft:black_stained_glass
setblock 301 171 533 minecraft:light_blue_stained_glass
setblock 303 171 518 minecraft:black_stained_glass
setblock 303 171 533 minecraft:light_blue_stained_glass
setblock 305 171 518 minecraft:light_blue_stained_glass
setblock 305 171 533 minecraft:light_blue_stained_glass
setblock 307 171 518 minecraft:sea_lantern
setblock 307 171 533 minecraft:light_blue_stained_glass
setblock 309 171 518 minecraft:black_stained_glass
setblock 309 171 533 minecraft:black_stained_glass
setblock 311 171 518 minecraft:black_stained_glass
setblock 311 171 533 minecraft:light_blue_stained_glass
setblock 313 171 519 minecraft:sea_lantern
setblock 313 171 521 minecraft:sea_lantern
setblock 313 171 523 minecraft:black_stained_glass
setblock 313 171 525 minecraft:black_stained_glass
setblock 313 171 527 minecraft:black_stained_glass
setblock 313 171 529 minecraft:black_stained_glass
setblock 313 171 531 minecraft:black_stained_glass
fill 282 172 516 282 185 516 minecraft:white_concrete
fill 282 172 517 282 172 518 minecraft:pearlescent_froglight
fill 282 172 519 282 185 519 minecraft:white_concrete
fill 282 172 528 282 185 528 minecraft:white_concrete
fill 282 172 529 282 172 530 minecraft:pearlescent_froglight
fill 282 172 531 282 185 531 minecraft:white_concrete
fill 282 172 540 282 185 540 minecraft:white_concrete
fill 282 172 541 282 172 542 minecraft:pearlescent_froglight
fill 282 172 543 282 185 543 minecraft:white_concrete
fill 282 172 552 282 185 552 minecraft:white_concrete
fill 283 172 552 284 172 552 minecraft:pearlescent_froglight
fill 285 172 552 285 185 552 minecraft:white_concrete
fill 287 172 537 287 179 537 minecraft:smooth_quartz
fill 288 172 536 288 179 536 minecraft:smooth_quartz
fill 288 172 538 288 179 538 minecraft:smooth_quartz
fill 289 172 510 289 185 510 minecraft:white_concrete
fill 289 172 537 289 179 537 minecraft:smooth_quartz
fill 290 172 510 291 172 510 minecraft:pearlescent_froglight
fill 292 172 510 292 185 510 minecraft:white_concrete
fill 294 172 552 294 185 552 minecraft:white_concrete
fill 295 172 552 296 172 552 minecraft:pearlescent_froglight
fill 297 172 552 297 185 552 minecraft:white_concrete
fill 298 172 519 298 173 519 minecraft:gray_concrete
fill 298 172 521 298 173 521 minecraft:gray_concrete
fill 298 172 523 298 173 523 minecraft:gray_concrete
fill 298 172 525 298 173 525 minecraft:gray_concrete
fill 298 172 527 298 173 527 minecraft:gray_concrete
fill 298 172 529 298 173 529 minecraft:gray_concrete
fill 298 172 531 298 173 531 minecraft:gray_concrete
fill 299 172 518 299 173 518 minecraft:gray_concrete
fill 299 172 533 299 173 533 minecraft:gray_concrete
fill 301 172 510 301 185 510 minecraft:white_concrete
fill 301 172 518 301 173 518 minecraft:gray_concrete
fill 301 172 533 301 173 533 minecraft:gray_concrete
fill 302 172 510 303 172 510 minecraft:pearlescent_froglight
fill 303 172 518 303 173 518 minecraft:gray_concrete
fill 303 172 533 303 173 533 minecraft:gray_concrete
fill 304 172 510 304 185 510 minecraft:white_concrete
fill 305 172 518 305 173 518 minecraft:gray_concrete
fill 305 172 533 305 173 533 minecraft:gray_concrete
fill 306 172 552 306 185 552 minecraft:white_concrete
fill 307 172 518 307 173 518 minecraft:gray_concrete
fill 307 172 533 307 173 533 minecraft:gray_concrete
fill 307 172 552 308 172 552 minecraft:pearlescent_froglight
fill 309 172 518 309 173 518 minecraft:gray_concrete
fill 309 172 533 309 173 533 minecraft:gray_concrete
fill 309 172 552 309 185 552 minecraft:white_concrete
fill 311 172 518 311 173 518 minecraft:gray_concrete
fill 311 172 533 311 173 533 minecraft:gray_concrete
fill 313 172 510 313 185 510 minecraft:white_concrete
fill 313 172 519 313 173 519 minecraft:gray_concrete
fill 313 172 521 313 173 521 minecraft:gray_concrete
fill 313 172 523 313 173 523 minecraft:gray_concrete
fill 313 172 525 313 173 525 minecraft:gray_concrete
fill 313 172 527 313 173 527 minecraft:gray_concrete
fill 313 172 529 313 173 529 minecraft:gray_concrete
fill 313 172 531 313 173 531 minecraft:gray_concrete
fill 314 172 510 315 172 510 minecraft:pearlescent_froglight
fill 316 172 510 316 185 510 minecraft:white_concrete
fill 318 172 552 318 185 552 minecraft:white_concrete
fill 319 172 552 320 172 552 minecraft:pearlescent_froglight
fill 321 172 552 321 185 552 minecraft:white_concrete
fill 324 172 511 324 185 511 minecraft:white_concrete
fill 324 172 512 324 172 513 minecraft:pearlescent_froglight
fill 324 172 514 324 185 514 minecraft:white_concrete
fill 324 172 523 324 185 523 minecraft:white_concrete
fill 324 172 524 324 172 525 minecraft:pearlescent_froglight
fill 324 172 526 324 185 526 minecraft:white_concrete
fill 324 172 535 324 185 535 minecraft:white_concrete
fill 324 172 536 324 172 537 minecraft:pearlescent_froglight
fill 324 172 538 324 185 538 minecraft:white_concrete
fill 324 172 547 324 185 547 minecraft:white_concrete
fill 324 172 548 324 172 549 minecraft:pearlescent_froglight
fill 324 172 550 324 185 550 minecraft:white_concrete
fill 282 173 517 282 185 518 minecraft:white_concrete
fill 282 173 529 282 185 530 minecraft:white_concrete
fill 282 173 541 282 185 542 minecraft:white_concrete
fill 283 173 552 284 185 552 minecraft:white_concrete
fill 287 173 536 287 179 536 minecraft:smooth_quartz
fill 287 173 538 287 179 538 minecraft:smooth_quartz
fill 289 173 536 289 179 536 minecraft:smooth_quartz
fill 289 173 538 289 179 538 minecraft:smooth_quartz
fill 290 173 510 291 185 510 minecraft:white_concrete
fill 295 173 552 296 185 552 minecraft:white_concrete
fill 302 173 510 303 185 510 minecraft:white_concrete
fill 307 173 552 308 185 552 minecraft:white_concrete
fill 314 173 510 315 185 510 minecraft:white_concrete
fill 319 173 552 320 185 552 minecraft:white_concrete
fill 324 173 512 324 185 513 minecraft:white_concrete
fill 324 173 524 324 185 525 minecraft:white_concrete
fill 324 173 536 324 185 537 minecraft:white_concrete
fill 324 173 548 324 185 549 minecraft:white_concrete
fill 286 174 536 286 179 537 minecraft:smooth_quartz
fill 287 174 535 289 179 535 minecraft:smooth_quartz
fill 288 174 539 288 179 539 minecraft:smooth_quartz
fill 290 174 536 290 179 537 minecraft:smooth_quartz
setblock 298 174 519 minecraft:sea_lantern
setblock 298 174 521 minecraft:black_stained_glass
setblock 298 174 523 minecraft:light_blue_stained_glass
setblock 298 174 525 minecraft:sea_lantern
setblock 298 174 527 minecraft:black_stained_glass
setblock 298 174 529 minecraft:black_stained_glass
setblock 298 174 531 minecraft:black_stained_glass
setblock 299 174 518 minecraft:light_blue_stained_glass
setblock 299 174 533 minecraft:light_blue_stained_glass
setblock 301 174 518 minecraft:black_stained_glass
setblock 301 174 533 minecraft:black_stained_glass
setblock 303 174 518 minecraft:black_stained_glass
setblock 303 174 533 minecraft:black_stained_glass
setblock 305 174 518 minecraft:sea_lantern
setblock 305 174 533 minecraft:black_stained_glass
setblock 307 174 518 minecraft:light_blue_stained_glass
setblock 307 174 533 minecraft:black_stained_glass
setblock 309 174 518 minecraft:black_stained_glass
setblock 309 174 533 minecraft:black_stained_glass
setblock 311 174 518 minecraft:black_stained_glass
setblock 311 174 533 minecraft:light_blue_stained_glass
setblock 313 174 519 minecraft:sea_lantern
setblock 313 174 521 minecraft:light_blue_stained_glass
setblock 313 174 523 minecraft:black_stained_glass
setblock 313 174 525 minecraft:sea_lantern
setblock 313 174 527 minecraft:sea_lantern
setblock 313 174 529 minecraft:light_blue_stained_glass
setblock 313 174 531 minecraft:black_stained_glass
fill 314 174 511 316 175 511 minecraft:quartz_block
fill 314 174 550 316 175 550 minecraft:quartz_block
fill 316 174 551 316 175 551 minecraft:quartz_block
setblock 285 175 513 minecraft:light[level=14]
setblock 285 175 521 minecraft:light[level=14]
setblock 285 175 529 minecraft:light[level=14]
setblock 285 175 537 minecraft:light[level=14]
setblock 285 175 545 minecraft:light[level=14]
fill 286 175 538 286 179 538 minecraft:smooth_quartz
fill 287 175 539 287 179 539 minecraft:smooth_quartz
fill 289 175 539 289 179 539 minecraft:smooth_quartz
fill 290 175 538 290 179 538 minecraft:smooth_quartz
setblock 293 175 513 minecraft:light[level=14]
setblock 293 175 521 minecraft:light[level=14]
setblock 293 175 529 minecraft:light[level=14]
setblock 293 175 537 minecraft:light[level=14]
setblock 293 175 545 minecraft:light[level=14]
fill 298 175 519 298 178 519 minecraft:gray_concrete
fill 298 175 521 298 178 521 minecraft:gray_concrete
fill 298 175 523 298 178 523 minecraft:gray_concrete
fill 298 175 525 298 178 525 minecraft:gray_concrete
fill 298 175 527 298 178 527 minecraft:gray_concrete
fill 298 175 529 298 178 529 minecraft:gray_concrete
fill 298 175 531 298 178 531 minecraft:gray_concrete
fill 299 175 518 299 177 518 minecraft:gray_concrete
fill 299 175 533 299 178 533 minecraft:gray_concrete
setblock 301 175 513 minecraft:light[level=14]
fill 301 175 518 301 177 518 minecraft:gray_concrete
fill 301 175 533 301 178 533 minecraft:gray_concrete
setblock 301 175 537 minecraft:light[level=14]
setblock 301 175 545 minecraft:light[level=14]
fill 303 175 518 303 177 518 minecraft:gray_concrete
fill 303 175 533 303 178 533 minecraft:gray_concrete
fill 305 175 518 305 177 518 minecraft:gray_concrete
fill 305 175 533 305 178 533 minecraft:gray_concrete
fill 307 175 518 307 177 518 minecraft:gray_concrete
fill 307 175 533 307 178 533 minecraft:gray_concrete
setblock 309 175 513 minecraft:light[level=14]
fill 309 175 518 309 177 518 minecraft:gray_concrete
fill 309 175 533 309 178 533 minecraft:gray_concrete
setblock 309 175 537 minecraft:light[level=14]
setblock 309 175 545 minecraft:light[level=14]
fill 311 175 518 311 177 518 minecraft:gray_concrete
fill 311 175 533 311 178 533 minecraft:gray_concrete
fill 313 175 519 313 178 519 minecraft:gray_concrete
fill 313 175 521 313 178 521 minecraft:gray_concrete
fill 313 175 523 313 178 523 minecraft:gray_concrete
fill 313 175 525 313 178 525 minecraft:gray_concrete
fill 313 175 527 313 178 527 minecraft:gray_concrete
fill 313 175 529 313 178 529 minecraft:gray_concrete
fill 313 175 531 313 178 531 minecraft:gray_concrete
fill 314 175 512 316 176 512 minecraft:quartz_block
fill 314 175 549 316 176 549 minecraft:quartz_block
fill 315 175 513 315 178 513 minecraft:quartz_block
fill 315 175 548 315 178 548 minecraft:quartz_block
setblock 317 175 513 minecraft:light[level=14]
setblock 317 175 521 minecraft:light[level=14]
setblock 317 175 529 minecraft:light[level=14]
setblock 317 175 537 minecraft:light[level=14]
setblock 317 175 545 minecraft:light[level=14]
fill 285 176 536 285 179 537 minecraft:smooth_quartz
fill 286 176 535 286 179 535 minecraft:smooth_quartz
fill 286 176 539 286 179 539 minecraft:smooth_quartz
fill 287 176 534 289 179 534 minecraft:smooth_quartz
fill 288 176 540 288 179 540 minecraft:smooth_quartz
fill 290 176 535 290 179 535 minecraft:smooth_quartz
fill 290 176 539 290 179 539 minecraft:smooth_quartz
fill 291 176 536 291 179 538 minecraft:smooth_quartz
fill 314 176 513 314 177 513 minecraft:quartz_block
fill 314 176 548 314 177 548 minecraft:quartz_block
setblock 315 176 511 minecraft:quartz_block
fill 315 176 514 315 178 514 minecraft:quartz_block
fill 315 176 547 315 178 547 minecraft:quartz_block
setblock 315 176 550 minecraft:quartz_block
fill 316 176 513 316 177 513 minecraft:quartz_block
fill 316 176 548 316 177 548 minecraft:quartz_block
fill 285 177 535 285 179 535 minecraft:smooth_quartz
fill 285 177 538 285 179 538 minecraft:smooth_quartz
fill 286 177 534 286 179 534 minecraft:smooth_quartz
fill 287 177 540 287 179 540 minecraft:smooth_quartz
fill 289 177 540 289 179 540 minecraft:smooth_quartz
fill 290 177 534 290 179 534 minecraft:smooth_quartz
fill 291 177 535 291 179 535 minecraft:smooth_quartz
fill 291 177 539 291 179 539 minecraft:smooth_quartz
fill 314 177 514 314 178 515 minecraft:quartz_block
fill 314 177 546 314 178 547 minecraft:quartz_block
setblock 315 177 511 minecraft:gold_block
setblock 315 177 512 minecraft:quartz_block
fill 315 177 515 316 178 515 minecraft:quartz_block
fill 315 177 546 316 178 546 minecraft:quartz_block
setblock 315 177 549 minecraft:quartz_block
setblock 315 177 550 minecraft:gold_block
fill 316 177 514 316 178 514 minecraft:quartz_block
fill 316 177 547 316 178 547 minecraft:quartz_block
fill 284 178 536 284 179 537 minecraft:smooth_quartz
fill 285 178 539 285 179 539 minecraft:smooth_quartz
fill 286 178 540 286 179 540 minecraft:smooth_quartz
fill 287 178 533 289 179 533 minecraft:smooth_quartz
fill 288 178 541 288 179 541 minecraft:smooth_quartz
fill 290 178 540 290 179 540 minecraft:smooth_quartz
fill 292 178 536 292 179 538 minecraft:smooth_quartz
fill 294 178 532 294 179 533 minecraft:white_wool
fill 298 178 518 313 178 518 minecraft:yellow_concrete
fill 308 178 545 308 179 545 minecraft:light_blue_stained_glass
fill 314 178 516 316 179 516 minecraft:quartz_block
fill 314 178 545 316 179 545 minecraft:quartz_block
setblock 315 178 512 minecraft:gold_block
fill 315 178 517 315 180 517 minecraft:quartz_block
fill 315 178 544 315 180 544 minecraft:quartz_block
setblock 315 178 549 minecraft:gold_block
setblock 284 179 535 minecraft:smooth_quartz
fill 284 179 538 284 179 539 minecraft:smooth_quartz
setblock 285 179 534 minecraft:smooth_quartz
setblock 285 179 540 minecraft:smooth_quartz
setblock 286 179 533 minecraft:smooth_quartz
fill 286 179 541 287 179 541 minecraft:smooth_quartz
fill 289 179 541 290 179 541 minecraft:smooth_quartz
setblock 290 179 533 minecraft:smooth_quartz
setblock 291 179 534 minecraft:smooth_quartz
setblock 291 179 540 minecraft:smooth_quartz
setblock 292 179 535 minecraft:smooth_quartz
setblock 292 179 539 minecraft:smooth_quartz
fill 314 179 517 314 180 517 minecraft:quartz_block
fill 314 179 544 314 180 544 minecraft:quartz_block
setblock 315 179 514 minecraft:gold_block
setblock 315 179 515 minecraft:quartz_block
fill 315 179 518 315 181 518 minecraft:quartz_block
fill 315 179 543 315 181 543 minecraft:quartz_block
setblock 315 179 546 minecraft:quartz_block
setblock 315 179 547 minecraft:gold_block
fill 316 179 517 316 180 517 minecraft:quartz_block
fill 316 179 544 316 180 544 minecraft:quartz_block
fill 284 180 520 284 185 522 minecraft:quartz_block
fill 284 180 532 284 185 534 minecraft:quartz_block
fill 284 180 544 284 185 546 minecraft:quartz_block
fill 288 180 537 288 183 537 minecraft:gold_block
fill 290 180 550 292 185 550 minecraft:quartz_block
fill 291 180 538 291 180 539 minecraft:white_concrete
fill 294 180 512 296 185 512 minecraft:quartz_block
fill 302 180 550 304 185 550 minecraft:quartz_block
fill 306 180 512 308 185 512 minecraft:quartz_block
fill 308 180 545 308 188 546 minecraft:smooth_quartz
fill 314 180 518 314 180 519 minecraft:quartz_block
fill 314 180 542 314 180 543 minecraft:quartz_block
fill 314 180 550 316 185 550 minecraft:quartz_block
setblock 315 180 515 minecraft:gold_block
setblock 315 180 516 minecraft:quartz_block
fill 315 180 519 315 182 520 minecraft:quartz_block
fill 315 180 541 315 182 542 minecraft:quartz_block
setblock 315 180 545 minecraft:quartz_block
setblock 315 180 546 minecraft:gold_block
fill 316 180 518 316 180 519 minecraft:quartz_block
fill 316 180 542 316 180 543 minecraft:quartz_block
fill 318 180 512 320 185 512 minecraft:quartz_block
fill 322 180 520 322 185 522 minecraft:quartz_block
fill 322 180 532 322 185 534 minecraft:quartz_block
fill 322 180 544 322 185 546 minecraft:quartz_block
fill 314 181 519 314 181 521 minecraft:quartz_block
fill 314 181 540 314 181 542 minecraft:quartz_block
setblock 315 181 517 minecraft:gold_block
fill 315 181 521 315 183 522 minecraft:quartz_block
fill 315 181 539 315 183 540 minecraft:quartz_block
setblock 315 181 544 minecraft:gold_block
fill 316 181 519 316 181 521 minecraft:quartz_block
fill 316 181 540 316 181 542 minecraft:quartz_block
fill 307 182 545 307 188 546 minecraft:smooth_quartz
fill 309 182 545 309 188 546 minecraft:smooth_quartz
fill 314 182 520 314 182 523 minecraft:quartz_block
fill 314 182 538 314 182 541 minecraft:quartz_block
setblock 315 182 518 minecraft:gold_block
fill 315 182 523 315 184 524 minecraft:quartz_block
fill 315 182 537 315 184 538 minecraft:quartz_block
setblock 315 182 543 minecraft:gold_block
fill 316 182 520 316 182 523 minecraft:quartz_block
fill 316 182 538 316 182 541 minecraft:quartz_block
setblock 285 183 513 minecraft:light[level=14]
setblock 285 183 521 minecraft:light[level=14]
setblock 285 183 529 minecraft:light[level=14]
setblock 285 183 537 minecraft:light[level=14]
setblock 285 183 545 minecraft:light[level=14]
setblock 293 183 513 minecraft:light[level=14]
setblock 293 183 521 minecraft:light[level=14]
setblock 293 183 529 minecraft:light[level=14]
setblock 293 183 537 minecraft:light[level=14]
setblock 293 183 545 minecraft:light[level=14]
setblock 301 183 513 minecraft:light[level=14]
setblock 301 183 521 minecraft:light[level=14]
setblock 301 183 529 minecraft:light[level=14]
setblock 301 183 537 minecraft:light[level=14]
setblock 301 183 545 minecraft:light[level=14]
fill 307 183 544 308 188 544 minecraft:smooth_quartz
fill 307 183 547 308 188 547 minecraft:smooth_quartz
setblock 309 183 513 minecraft:light[level=14]
setblock 309 183 521 minecraft:light[level=14]
setblock 309 183 529 minecraft:light[level=14]
setblock 309 183 537 minecraft:light[level=14]
fill 314 183 522 314 183 526 minecraft:quartz_block
fill 314 183 535 314 183 539 minecraft:quartz_block
setblock 315 183 520 minecraft:gold_block
fill 315 183 525 315 184 528 minecraft:quartz_block
fill 315 183 533 315 184 536 minecraft:quartz_block
setblock 315 183 541 minecraft:gold_block
fill 316 183 522 316 183 526 minecraft:quartz_block
fill 316 183 535 316 183 539 minecraft:quartz_block
setblock 317 183 513 minecraft:light[level=14]
setblock 317 183 521 minecraft:light[level=14]
setblock 317 183 529 minecraft:light[level=14]
setblock 317 183 537 minecraft:light[level=14]
setblock 317 183 545 minecraft:light[level=14]
setblock 288 184 537 minecraft:pearlescent_froglight
fill 306 184 545 306 188 546 minecraft:smooth_quartz
fill 309 184 544 309 188 544 minecraft:smooth_quartz
fill 309 184 547 309 188 547 minecraft:smooth_quartz
fill 310 184 545 310 188 546 minecraft:smooth_quartz
fill 314 184 525 314 184 536 minecraft:quartz_block
fill 315 184 521 315 184 522 minecraft:gold_block
fill 315 184 529 316 185 532 minecraft:quartz_block
fill 315 184 539 315 184 540 minecraft:gold_block
fill 316 184 525 316 184 528 minecraft:quartz_block
fill 316 184 533 316 184 536 minecraft:quartz_block
fill 283 185 514 283 185 519 minecraft:smooth_quartz
fill 283 185 526 283 185 531 minecraft:smooth_quartz
fill 283 185 538 283 185 543 minecraft:smooth_quartz
fill 283 185 550 283 185 551 minecraft:smooth_quartz
fill 284 185 551 287 185 551 minecraft:smooth_quartz
fill 287 185 511 292 185 511 minecraft:smooth_quartz
fill 294 185 551 299 185 551 minecraft:smooth_quartz
fill 299 185 511 304 185 511 minecraft:smooth_quartz
fill 306 185 544 306 188 544 minecraft:smooth_quartz
fill 306 185 547 306 188 547 minecraft:smooth_quartz
fill 306 185 551 311 185 551 minecraft:smooth_quartz
fill 307 185 543 309 188 543 minecraft:smooth_quartz
fill 307 185 548 308 188 548 minecraft:smooth_quartz
fill 310 185 544 310 188 544 minecraft:smooth_quartz
fill 310 185 547 310 188 547 minecraft:smooth_quartz
fill 311 185 511 316 185 511 minecraft:smooth_quartz
fill 314 185 528 314 185 533 minecraft:quartz_block
fill 315 185 523 315 185 525 minecraft:gold_block
fill 315 185 526 315 185 528 minecraft:quartz_block
fill 315 185 533 315 185 535 minecraft:quartz_block
fill 315 185 536 315 185 538 minecraft:gold_block
setblock 316 185 528 minecraft:quartz_block
setblock 316 185 533 minecraft:quartz_block
fill 318 185 551 323 185 551 minecraft:smooth_quartz
fill 323 185 511 323 185 516 minecraft:smooth_quartz
fill 323 185 523 323 185 528 minecraft:smooth_quartz
fill 323 185 535 323 185 540 minecraft:smooth_quartz
fill 323 185 547 323 185 550 minecraft:smooth_quartz
fill 282 186 516 282 191 519 minecraft:pearlescent_froglight
fill 282 186 528 282 191 531 minecraft:pearlescent_froglight
fill 282 186 540 282 191 543 minecraft:pearlescent_froglight
fill 282 186 552 285 191 552 minecraft:pearlescent_froglight
fill 289 186 510 292 191 510 minecraft:pearlescent_froglight
fill 294 186 552 297 191 552 minecraft:pearlescent_froglight
fill 301 186 510 304 191 510 minecraft:pearlescent_froglight
fill 305 186 544 305 188 546 minecraft:smooth_quartz
fill 306 186 543 306 188 543 minecraft:smooth_quartz
fill 306 186 548 306 188 548 minecraft:smooth_quartz
fill 306 186 552 309 191 552 minecraft:pearlescent_froglight
fill 309 186 548 309 188 548 minecraft:smooth_quartz
fill 311 186 545 311 188 546 minecraft:smooth_quartz
fill 313 186 510 316 191 510 minecraft:pearlescent_froglight
fill 315 186 527 315 186 534 minecraft:gold_block
fill 318 186 552 321 191 552 minecraft:pearlescent_froglight
fill 324 186 511 324 191 514 minecraft:pearlescent_froglight
fill 324 186 523 324 191 526 minecraft:pearlescent_froglight
fill 324 186 535 324 191 538 minecraft:pearlescent_froglight
fill 324 186 547 324 191 550 minecraft:pearlescent_froglight
fill 305 187 547 305 188 547 minecraft:smooth_quartz
fill 307 187 542 309 188 542 minecraft:smooth_quartz
fill 307 187 549 308 188 549 minecraft:smooth_quartz
fill 310 187 543 310 188 543 minecraft:smooth_quartz
fill 310 187 548 310 188 548 minecraft:smooth_quartz
fill 311 187 544 311 188 544 minecraft:smooth_quartz
fill 311 187 547 311 188 547 minecraft:smooth_quartz
fill 314 187 535 314 188 535 minecraft:white_concrete
fill 304 188 544 304 188 547 minecraft:smooth_quartz
setblock 305 188 543 minecraft:smooth_quartz
setblock 305 188 548 minecraft:smooth_quartz
setblock 306 188 542 minecraft:smooth_quartz
setblock 306 188 549 minecraft:smooth_quartz
fill 309 188 549 310 188 549 minecraft:smooth_quartz
setblock 310 188 542 minecraft:smooth_quartz
setblock 311 188 543 minecraft:smooth_quartz
setblock 311 188 548 minecraft:smooth_quartz
setblock 312 188 545 minecraft:smooth_quartz
fill 308 189 545 308 191 545 minecraft:gold_block
setblock 285 191 513 minecraft:light[level=14]
setblock 285 191 521 minecraft:light[level=14]
setblock 285 191 529 minecraft:light[level=14]
setblock 285 191 537 minecraft:light[level=14]
setblock 285 191 545 minecraft:light[level=14]
setblock 293 191 513 minecraft:light[level=14]
setblock 293 191 521 minecraft:light[level=14]
setblock 293 191 529 minecraft:light[level=14]
setblock 293 191 537 minecraft:light[level=14]
setblock 293 191 545 minecraft:light[level=14]
setblock 301 191 513 minecraft:light[level=14]
setblock 301 191 521 minecraft:light[level=14]
setblock 301 191 529 minecraft:light[level=14]
setblock 301 191 537 minecraft:light[level=14]
setblock 301 191 545 minecraft:light[level=14]
setblock 309 191 513 minecraft:light[level=14]
setblock 309 191 521 minecraft:light[level=14]
setblock 309 191 529 minecraft:light[level=14]
setblock 309 191 537 minecraft:light[level=14]
setblock 309 191 545 minecraft:light[level=14]
setblock 317 191 513 minecraft:light[level=14]
setblock 317 191 521 minecraft:light[level=14]
setblock 317 191 529 minecraft:light[level=14]
setblock 317 191 537 minecraft:light[level=14]
setblock 317 191 545 minecraft:light[level=14]
fill 282 192 516 282 197 516 minecraft:white_concrete
fill 282 192 517 282 192 518 minecraft:pearlescent_froglight
fill 282 192 519 282 201 519 minecraft:white_concrete
fill 282 192 528 282 202 528 minecraft:white_concrete
fill 282 192 529 282 192 530 minecraft:pearlescent_froglight
fill 282 192 531 282 201 531 minecraft:white_concrete
fill 282 192 540 282 202 540 minecraft:white_concrete
fill 282 192 541 282 192 542 minecraft:pearlescent_froglight
fill 282 192 543 282 201 543 minecraft:white_concrete
fill 282 192 552 282 201 552 minecraft:white_concrete
fill 283 192 552 284 192 552 minecraft:pearlescent_froglight
fill 285 192 552 285 203 552 minecraft:white_concrete
fill 289 192 510 289 202 510 minecraft:white_concrete
fill 290 192 510 291 192 510 minecraft:pearlescent_froglight
fill 292 192 510 292 201 510 minecraft:white_concrete
fill 294 192 552 294 197 552 minecraft:white_concrete
fill 295 192 552 296 192 552 minecraft:pearlescent_froglight
fill 297 192 552 297 201 552 minecraft:white_concrete
fill 301 192 510 301 199 510 minecraft:white_concrete
fill 302 192 510 303 192 510 minecraft:pearlescent_froglight
fill 304 192 510 304 201 510 minecraft:white_concrete
fill 306 192 552 306 201 552 minecraft:white_concrete
fill 307 192 552 308 192 552 minecraft:pearlescent_froglight
fill 309 192 552 309 201 552 minecraft:white_concrete
fill 313 192 510 313 197 510 minecraft:white_concrete
fill 314 192 510 315 192 510 minecraft:pearlescent_froglight
fill 316 192 510 316 201 510 minecraft:white_concrete
fill 318 192 552 318 201 552 minecraft:white_concrete
fill 319 192 552 320 192 552 minecraft:pearlescent_froglight
fill 321 192 552 321 201 552 minecraft:white_concrete
fill 324 192 511 324 198 511 minecraft:white_concrete
fill 324 192 512 324 192 513 minecraft:pearlescent_froglight
fill 324 192 514 324 201 514 minecraft:white_concrete
fill 324 192 523 324 202 523 minecraft:white_concrete
fill 324 192 524 324 192 525 minecraft:pearlescent_froglight
fill 324 192 526 324 199 526 minecraft:white_concrete
fill 324 192 535 324 202 535 minecraft:white_concrete
fill 324 192 536 324 192 537 minecraft:pearlescent_froglight
fill 324 192 538 324 197 538 minecraft:white_concrete
fill 324 192 547 324 201 547 minecraft:white_concrete
fill 324 192 548 324 192 549 minecraft:pearlescent_froglight
fill 324 192 550 324 201 550 minecraft:white_concrete
fill 282 193 517 282 197 518 minecraft:white_concrete
fill 282 193 529 282 197 530 minecraft:white_concrete
fill 282 193 541 282 201 542 minecraft:white_concrete
fill 283 193 552 284 199 552 minecraft:white_concrete
fill 290 193 510 291 201 510 minecraft:white_concrete
fill 295 193 552 296 197 552 minecraft:white_concrete
fill 302 193 510 303 199 510 minecraft:white_concrete
fill 307 193 552 308 201 552 minecraft:white_concrete
setblock 308 193 545 minecraft:pearlescent_froglight
fill 314 193 510 315 198 510 minecraft:white_concrete
fill 319 193 552 320 201 552 minecraft:white_concrete
fill 324 193 512 324 201 513 minecraft:white_concrete
fill 324 193 524 324 201 525 minecraft:white_concrete
fill 324 193 536 324 197 537 minecraft:white_concrete
fill 324 193 548 324 199 549 minecraft:white_concrete
fill 282 198 510 282 198 511 minecraft:light_blue_concrete
fill 282 198 512 282 201 513 minecraft:white_concrete
fill 282 198 515 282 198 517 minecraft:light_blue_concrete
fill 282 198 518 282 201 518 minecraft:white_concrete
fill 282 198 520 282 198 521 minecraft:light_blue_concrete
fill 282 198 522 282 198 524 minecraft:white_concrete
setblock 282 198 529 minecraft:light_blue_concrete
fill 282 198 530 282 201 530 minecraft:white_concrete
fill 282 198 544 282 201 544 minecraft:white_concrete
fill 282 198 545 282 199 545 minecraft:light_blue_concrete
fill 282 198 546 282 201 546 minecraft:white_concrete
fill 282 198 548 282 201 548 minecraft:white_concrete
fill 282 198 549 282 198 550 minecraft:light_blue_concrete
fill 286 198 552 287 198 552 minecraft:white_concrete
setblock 288 198 552 minecraft:light_blue_concrete
fill 289 198 552 290 201 552 minecraft:white_concrete
setblock 294 198 552 minecraft:light_blue_concrete
fill 295 198 552 295 201 552 minecraft:white_concrete
setblock 296 198 552 minecraft:light_blue_concrete
setblock 300 198 552 minecraft:white_concrete
setblock 301 198 552 minecraft:light_blue_concrete
fill 302 198 552 305 201 552 minecraft:white_concrete
setblock 305 198 510 minecraft:light_blue_concrete
setblock 313 198 510 minecraft:light_blue_concrete
fill 324 198 515 324 201 516 minecraft:white_concrete
setblock 324 198 517 minecraft:light_blue_concrete
fill 324 198 527 324 202 527 minecraft:white_concrete
setblock 324 198 528 minecraft:light_blue_concrete
fill 324 198 529 324 199 533 minecraft:white_concrete
fill 324 198 536 324 198 538 minecraft:light_blue_concrete
setblock 324 198 541 minecraft:light_blue_concrete
fill 324 198 542 324 201 544 minecraft:white_concrete
fill 282 199 510 282 201 511 minecraft:white_concrete
setblock 282 199 514 minecraft:light_blue_concrete
fill 282 199 515 282 201 517 minecraft:white_concrete
fill 282 199 520 282 201 523 minecraft:white_concrete
setblock 282 199 524 minecraft:light_blue_concrete
fill 282 199 529 282 201 529 minecraft:white_concrete
setblock 282 199 532 minecraft:light_blue_concrete
fill 282 199 533 282 201 534 minecraft:white_concrete
fill 282 199 549 282 201 549 minecraft:white_concrete
fill 282 199 550 282 200 550 minecraft:light_blue_concrete
setblock 285 199 513 minecraft:light[level=14]
setblock 285 199 521 minecraft:light[level=14]
setblock 285 199 529 minecraft:light[level=14]
setblock 285 199 537 minecraft:light[level=14]
setblock 285 199 545 minecraft:light[level=14]
setblock 286 199 552 minecraft:light_blue_concrete
fill 287 199 552 288 201 552 minecraft:white_concrete
setblock 293 199 513 minecraft:light[level=14]
setblock 293 199 521 minecraft:light[level=14]
setblock 293 199 529 minecraft:light[level=14]
setblock 293 199 537 minecraft:light[level=14]
setblock 293 199 545 minecraft:light[level=14]
setblock 294 199 552 minecraft:white_concrete
fill 296 199 552 296 201 552 minecraft:white_concrete
setblock 300 199 552 minecraft:light_blue_concrete
setblock 301 199 513 minecraft:light[level=14]
setblock 301 199 521 minecraft:light[level=14]
setblock 301 199 529 minecraft:light[level=14]
setblock 301 199 537 minecraft:light[level=14]
setblock 301 199 545 minecraft:light[level=14]
fill 301 199 552 301 202 552 minecraft:white_concrete
fill 305 199 510 309 201 510 minecraft:white_concrete
setblock 309 199 513 minecraft:light[level=14]
setblock 309 199 521 minecraft:light[level=14]
setblock 309 199 529 minecraft:light[level=14]
setblock 309 199 537 minecraft:light[level=14]
setblock 309 199 545 minecraft:light[level=14]
setblock 310 199 510 minecraft:light_blue_concrete
fill 310 199 552 311 199 552 minecraft:white_concrete
fill 311 199 510 314 201 510 minecraft:white_concrete
setblock 312 199 552 minecraft:light_blue_concrete
fill 313 199 552 317 201 552 minecraft:white_concrete
setblock 315 199 510 minecraft:light_blue_concrete
fill 317 199 510 317 202 510 minecraft:white_concrete
setblock 317 199 513 minecraft:light[level=14]
setblock 317 199 521 minecraft:light[level=14]
setblock 317 199 529 minecraft:light[level=14]
setblock 317 199 537 minecraft:light[level=14]
setblock 317 199 545 minecraft:light[level=14]
setblock 318 199 510 minecraft:light_blue_concrete
fill 319 199 510 319 201 510 minecraft:white_concrete
fill 321 199 510 322 201 510 minecraft:white_concrete
fill 323 199 510 324 199 510 minecraft:light_blue_concrete
setblock 324 199 511 minecraft:light_blue_concrete
fill 324 199 517 324 201 517 minecraft:white_concrete
setblock 324 199 519 minecraft:light_blue_concrete
fill 324 199 520 324 201 522 minecraft:white_concrete
fill 324 199 528 324 201 528 minecraft:white_concrete
setblock 324 199 534 minecraft:light_blue_concrete
fill 324 199 536 324 199 538 minecraft:white_concrete
fill 324 199 541 324 202 541 minecraft:white_concrete
fill 324 199 551 324 203 551 minecraft:white_concrete
fill 324 199 552 324 200 552 minecraft:light_blue_concrete
fill 282 200 514 282 201 514 minecraft:white_concrete
fill 282 200 524 282 201 524 minecraft:white_concrete
setblock 282 200 525 minecraft:light_blue_concrete
fill 282 200 526 282 201 526 minecraft:white_concrete
fill 282 200 532 282 201 532 minecraft:white_concrete
fill 282 200 536 282 201 536 minecraft:white_concrete
setblock 282 200 537 minecraft:light_blue_concrete
fill 282 200 538 282 201 539 minecraft:white_concrete
fill 282 200 545 282 201 545 minecraft:white_concrete
fill 283 200 552 283 201 552 minecraft:white_concrete
fill 284 200 520 284 205 522 minecraft:quartz_block
fill 284 200 532 284 205 534 minecraft:quartz_block
fill 284 200 544 284 205 546 minecraft:quartz_block
setblock 284 200 552 minecraft:light_blue_concrete
fill 286 200 552 286 201 552 minecraft:white_concrete
fill 290 200 550 292 205 550 minecraft:quartz_block
fill 294 200 512 296 205 512 minecraft:quartz_block
setblock 294 200 552 minecraft:light_blue_concrete
fill 300 200 510 301 200 510 minecraft:light_blue_concrete
fill 300 200 552 300 201 552 minecraft:white_concrete
fill 302 200 510 302 201 510 minecraft:white_concrete
fill 302 200 550 304 205 550 minecraft:quartz_block
setblock 303 200 510 minecraft:light_blue_concrete
fill 306 200 512 308 205 512 minecraft:quartz_block
fill 310 200 510 310 201 510 minecraft:white_concrete
setblock 310 200 552 minecraft:light_blue_concrete
fill 311 200 552 312 201 552 minecraft:white_concrete
fill 314 200 550 316 205 550 minecraft:quartz_block
fill 315 200 510 315 201 510 minecraft:white_concrete
fill 318 200 510 318 201 510 minecraft:white_concrete
fill 318 200 512 320 205 512 minecraft:quartz_block
fill 322 200 520 322 205 522 minecraft:quartz_block
fill 322 200 532 322 205 534 minecraft:quartz_block
fill 322 200 544 322 205 546 minecraft:quartz_block
setblock 323 200 510 minecraft:light_blue_concrete
fill 324 200 510 324 201 511 minecraft:white_concrete
setblock 324 200 518 minecraft:light_blue_concrete
fill 324 200 519 324 201 519 minecraft:white_concrete
setblock 324 200 526 minecraft:light_blue_concrete
fill 324 200 529 324 201 532 minecraft:white_concrete
setblock 324 200 533 minecraft:light_blue_concrete
fill 324 200 534 324 201 534 minecraft:white_concrete
setblock 324 200 536 minecraft:light_blue_concrete
fill 324 200 537 324 201 538 minecraft:white_concrete
fill 324 200 548 324 201 548 minecraft:white_concrete
setblock 324 200 549 minecraft:light_blue_concrete
setblock 282 201 525 minecraft:white_concrete
fill 282 201 537 282 202 537 minecraft:white_concrete
fill 282 201 550 282 202 550 minecraft:white_concrete
setblock 284 201 552 minecraft:white_concrete
setblock 294 201 552 minecraft:white_concrete
fill 300 201 510 301 201 510 minecraft:white_concrete
setblock 303 201 510 minecraft:white_concrete
setblock 310 201 552 minecraft:white_concrete
setblock 323 201 510 minecraft:white_concrete
setblock 324 201 518 minecraft:white_concrete
setblock 324 201 526 minecraft:white_concrete
setblock 324 201 533 minecraft:white_concrete
setblock 324 201 536 minecraft:white_concrete
setblock 324 201 549 minecraft:white_concrete
setblock 324 201 552 minecraft:white_concrete
fill 282 202 510 282 203 510 minecraft:white_concrete
fill 282 202 511 282 202 527 minecraft:light_blue_concrete
fill 282 202 529 282 203 536 minecraft:light_blue_concrete
fill 282 202 538 282 307 539 minecraft:light_blue_concrete
fill 282 202 541 282 202 549 minecraft:light_blue_concrete
fill 282 202 551 282 205 552 minecraft:light_blue_concrete
fill 283 202 510 288 202 510 minecraft:light_blue_concrete
fill 283 202 552 284 205 552 minecraft:light_blue_concrete
fill 286 202 552 300 202 552 minecraft:light_blue_concrete
fill 290 202 510 293 202 510 minecraft:light_blue_concrete
setblock 294 202 510 minecraft:white_concrete
fill 295 202 510 304 202 510 minecraft:light_blue_concrete
fill 302 202 552 324 202 552 minecraft:light_blue_concrete
fill 304 202 543 304 203 544 minecraft:white_concrete
setblock 305 202 510 minecraft:white_concrete
fill 306 202 510 316 202 510 minecraft:light_blue_concrete
fill 318 202 510 323 307 510 minecraft:light_blue_concrete
setblock 324 202 510 minecraft:white_concrete
fill 324 202 511 324 205 511 minecraft:light_blue_concrete
setblock 324 202 512 minecraft:white_concrete
fill 324 202 513 324 202 522 minecraft:light_blue_concrete
setblock 324 202 524 minecraft:light_blue_concrete
setblock 324 202 525 minecraft:white_concrete
setblock 324 202 526 minecraft:light_blue_concrete
fill 324 202 528 324 203 534 minecraft:light_blue_concrete
fill 324 202 536 324 203 540 minecraft:light_blue_concrete
fill 324 202 542 324 307 542 minecraft:light_blue_concrete
setblock 324 202 543 minecraft:white_concrete
fill 324 202 544 324 202 550 minecraft:light_blue_concrete
fill 282 203 511 282 203 513 minecraft:light_blue_concrete
setblock 282 203 514 minecraft:white_concrete
fill 282 203 515 282 203 526 minecraft:light_blue_concrete
setblock 282 203 527 minecraft:white_concrete
setblock 282 203 528 minecraft:light_blue_concrete
fill 282 203 537 282 307 537 minecraft:light_blue_concrete
fill 282 203 540 282 205 542 minecraft:light_blue_concrete
fill 282 203 543 282 204 543 minecraft:white_concrete
fill 282 203 544 282 203 546 minecraft:light_blue_concrete
setblock 282 203 547 minecraft:white_concrete
fill 282 203 548 282 307 550 minecraft:light_blue_concrete
fill 283 203 510 284 203 510 minecraft:white_concrete
fill 285 203 510 290 203 510 minecraft:light_blue_concrete
fill 286 203 552 287 307 552 minecraft:light_blue_concrete
setblock 288 203 552 minecraft:white_concrete
fill 289 203 552 295 205 552 minecraft:light_blue_concrete
setblock 291 203 510 minecraft:white_concrete
fill 292 203 510 297 205 510 minecraft:light_blue_concrete
setblock 296 203 552 minecraft:white_concrete
fill 297 203 552 308 205 552 minecraft:light_blue_concrete
setblock 298 203 510 minecraft:white_concrete
fill 299 203 510 307 203 510 minecraft:light_blue_concrete
setblock 308 203 510 minecraft:white_concrete
fill 309 203 510 317 205 510 minecraft:light_blue_concrete
setblock 309 203 552 minecraft:white_concrete
fill 310 203 552 314 307 552 minecraft:light_blue_concrete
setblock 315 203 552 minecraft:white_concrete
fill 316 203 552 322 203 552 minecraft:light_blue_concrete
setblock 323 203 552 minecraft:white_concrete
fill 324 203 510 324 307 510 minecraft:light_blue_concrete
fill 324 203 512 324 203 521 minecraft:light_blue_concrete
setblock 324 203 522 minecraft:white_concrete
fill 324 203 523 324 205 523 minecraft:light_blue_concrete
setblock 324 203 524 minecraft:white_concrete
fill 324 203 525 324 205 525 minecraft:light_blue_concrete
setblock 324 203 526 minecraft:white_concrete
fill 324 203 527 324 307 527 minecraft:light_blue_concrete
setblock 324 203 535 minecraft:light_blue_concrete
fill 324 203 541 324 307 541 minecraft:light_blue_concrete
fill 324 203 543 324 307 544 minecraft:light_blue_concrete
fill 324 203 545 324 203 546 minecraft:white_concrete
fill 324 203 547 324 205 550 minecraft:light_blue_concrete
fill 324 203 552 324 307 552 minecraft:light_blue_concrete
fill 282 204 510 288 307 510 minecraft:light_blue_concrete
setblock 282 204 511 minecraft:white_concrete
fill 282 204 512 282 205 521 minecraft:light_blue_concrete
setblock 282 204 522 minecraft:white_concrete
fill 282 204 523 282 307 527 minecraft:light_blue_concrete
setblock 282 204 528 minecraft:white_concrete
fill 282 204 529 282 205 532 minecraft:light_blue_concrete
setblock 282 204 533 minecraft:white_concrete
fill 282 204 534 282 307 535 minecraft:light_blue_concrete
setblock 282 204 536 minecraft:white_concrete
fill 282 204 544 282 307 545 minecraft:light_blue_concrete
setblock 282 204 546 minecraft:white_concrete
fill 282 204 547 282 307 547 minecraft:light_blue_concrete
fill 285 204 552 285 205 552 minecraft:light_blue_concrete
fill 288 204 552 288 307 552 minecraft:light_blue_concrete
setblock 289 204 510 minecraft:white_concrete
fill 290 204 510 291 205 510 minecraft:light_blue_concrete
fill 296 204 552 296 205 552 minecraft:light_blue_concrete
fill 298 204 510 303 205 510 minecraft:light_blue_concrete
setblock 304 204 510 minecraft:white_concrete
fill 305 204 510 308 307 510 minecraft:light_blue_concrete
fill 309 204 552 309 205 552 minecraft:light_blue_concrete
fill 315 204 552 317 307 552 minecraft:light_blue_concrete
setblock 318 204 552 minecraft:white_concrete
fill 319 204 552 323 205 552 minecraft:light_blue_concrete
fill 324 204 512 324 205 512 minecraft:light_blue_concrete
setblock 324 204 513 minecraft:white_concrete
fill 324 204 514 324 205 515 minecraft:light_blue_concrete
setblock 324 204 516 minecraft:white_concrete
fill 324 204 517 324 307 522 minecraft:light_blue_concrete
fill 324 204 524 324 205 524 minecraft:light_blue_concrete
fill 324 204 526 324 205 526 minecraft:light_blue_concrete
fill 324 204 528 324 307 529 minecraft:light_blue_concrete
setblock 324 204 530 minecraft:white_concrete
fill 324 204 531 324 307 532 minecraft:light_blue_concrete
setblock 324 204 533 minecraft:white_concrete
fill 324 204 534 324 307 534 minecraft:light_blue_concrete
setblock 324 204 535 minecraft:white_concrete
fill 324 204 536 324 205 537 minecraft:light_blue_concrete
setblock 324 204 538 minecraft:white_concrete
fill 324 204 539 324 307 540 minecraft:light_blue_concrete
fill 324 204 545 324 307 545 minecraft:light_blue_concrete
setblock 324 204 546 minecraft:white_concrete
fill 324 204 551 324 307 551 minecraft:light_blue_concrete
fill 282 205 511 282 307 511 minecraft:light_blue_concrete
fill 282 205 522 282 307 522 minecraft:light_blue_concrete
setblock 282 205 528 minecraft:light_blue_concrete
fill 282 205 533 282 307 533 minecraft:light_blue_concrete
fill 282 205 536 282 307 536 minecraft:light_blue_concrete
setblock 282 205 543 minecraft:light_blue_concrete
fill 282 205 546 282 307 546 minecraft:light_blue_concrete
fill 283 205 514 283 205 519 minecraft:smooth_quartz
fill 283 205 526 283 205 531 minecraft:smooth_quartz
fill 283 205 538 283 205 543 minecraft:smooth_quartz
fill 283 205 550 283 205 551 minecraft:smooth_quartz
fill 284 205 551 287 205 551 minecraft:smooth_quartz
fill 287 205 511 292 205 511 minecraft:smooth_quartz
setblock 289 205 510 minecraft:light_blue_concrete
fill 294 205 551 299 205 551 minecraft:smooth_quartz
fill 299 205 511 304 205 511 minecraft:smooth_quartz
setblock 304 205 510 minecraft:light_blue_concrete
fill 306 205 551 311 205 551 minecraft:smooth_quartz
fill 311 205 511 316 205 511 minecraft:smooth_quartz
fill 318 205 551 323 205 551 minecraft:smooth_quartz
setblock 318 205 552 minecraft:light_blue_concrete
fill 323 205 511 323 205 516 minecraft:smooth_quartz
fill 323 205 523 323 205 528 minecraft:smooth_quartz
fill 323 205 535 323 205 540 minecraft:smooth_quartz
fill 323 205 547 323 205 550 minecraft:smooth_quartz
setblock 324 205 513 minecraft:light_blue_concrete
fill 324 205 516 324 307 516 minecraft:light_blue_concrete
fill 324 205 530 324 307 530 minecraft:light_blue_concrete
fill 324 205 533 324 307 533 minecraft:light_blue_concrete
setblock 324 205 535 minecraft:light_blue_concrete
setblock 324 205 538 minecraft:light_blue_concrete
fill 324 205 546 324 307 546 minecraft:light_blue_concrete
fill 282 206 512 282 307 515 minecraft:light_blue_concrete
fill 282 206 516 282 211 519 minecraft:pearlescent_froglight
fill 282 206 520 282 307 521 minecraft:light_blue_concrete
fill 282 206 528 282 211 531 minecraft:pearlescent_froglight
fill 282 206 532 282 307 532 minecraft:light_blue_concrete
fill 282 206 540 282 211 543 minecraft:pearlescent_froglight
fill 282 206 551 282 307 551 minecraft:light_blue_concrete
fill 282 206 552 285 211 552 minecraft:pearlescent_froglight
fill 289 206 510 292 211 510 minecraft:pearlescent_froglight
fill 289 206 552 293 307 552 minecraft:light_blue_concrete
fill 293 206 510 300 307 510 minecraft:light_blue_concrete
fill 294 206 552 297 211 552 minecraft:pearlescent_froglight
fill 298 206 552 305 307 552 minecraft:light_blue_concrete
fill 301 206 510 304 211 510 minecraft:pearlescent_froglight
fill 306 206 552 309 211 552 minecraft:pearlescent_froglight
fill 309 206 510 312 307 510 minecraft:light_blue_concrete
fill 313 206 510 316 211 510 minecraft:pearlescent_froglight
fill 317 206 510 317 307 510 minecraft:light_blue_concrete
fill 318 206 552 321 211 552 minecraft:pearlescent_froglight
fill 322 206 552 323 307 552 minecraft:light_blue_concrete
fill 324 206 511 324 211 514 minecraft:pearlescent_froglight
fill 324 206 515 324 307 515 minecraft:light_blue_concrete
fill 324 206 523 324 211 526 minecraft:pearlescent_froglight
fill 324 206 535 324 211 538 minecraft:pearlescent_froglight
fill 324 206 547 324 211 550 minecraft:pearlescent_froglight
setblock 285 207 513 minecraft:light[level=14]
setblock 285 207 521 minecraft:light[level=14]
setblock 285 207 529 minecraft:light[level=14]
setblock 285 207 537 minecraft:light[level=14]
setblock 285 207 545 minecraft:light[level=14]
setblock 293 207 513 minecraft:light[level=14]
setblock 293 207 521 minecraft:light[level=14]
setblock 293 207 529 minecraft:light[level=14]
setblock 293 207 537 minecraft:light[level=14]
setblock 293 207 545 minecraft:light[level=14]
setblock 301 207 513 minecraft:light[level=14]
setblock 301 207 521 minecraft:light[level=14]
setblock 301 207 529 minecraft:light[level=14]
setblock 301 207 537 minecraft:light[level=14]
setblock 301 207 545 minecraft:light[level=14]
setblock 309 207 513 minecraft:light[level=14]
setblock 309 207 521 minecraft:light[level=14]
setblock 309 207 529 minecraft:light[level=14]
setblock 309 207 537 minecraft:light[level=14]
setblock 309 207 545 minecraft:light[level=14]
setblock 317 207 513 minecraft:light[level=14]
setblock 317 207 521 minecraft:light[level=14]
setblock 317 207 529 minecraft:light[level=14]
setblock 317 207 537 minecraft:light[level=14]
setblock 317 207 545 minecraft:light[level=14]
fill 282 212 516 282 245 516 minecraft:light_blue_concrete
fill 282 212 517 282 212 518 minecraft:pearlescent_froglight
fill 282 212 519 282 245 519 minecraft:light_blue_concrete
fill 282 212 528 282 245 528 minecraft:light_blue_concrete
fill 282 212 529 282 212 530 minecraft:pearlescent_froglight
fill 282 212 531 282 245 531 minecraft:light_blue_concrete
fill 282 212 540 282 245 540 minecraft:light_blue_concrete
fill 282 212 541 282 212 542 minecraft:pearlescent_froglight
fill 282 212 543 282 245 543 minecraft:light_blue_concrete
fill 282 212 552 282 245 552 minecraft:light_blue_concrete
fill 283 212 552 284 212 552 minecraft:pearlescent_froglight
fill 285 212 552 285 245 552 minecraft:light_blue_concrete
fill 289 212 510 289 245 510 minecraft:light_blue_concrete
fill 290 212 510 291 212 510 minecraft:pearlescent_froglight
fill 292 212 510 292 245 510 minecraft:light_blue_concrete
fill 294 212 552 294 245 552 minecraft:light_blue_concrete
fill 295 212 552 296 212 552 minecraft:pearlescent_froglight
fill 297 212 552 297 245 552 minecraft:light_blue_concrete
fill 301 212 510 301 245 510 minecraft:light_blue_concrete
fill 302 212 510 303 212 510 minecraft:pearlescent_froglight
fill 304 212 510 304 245 510 minecraft:light_blue_concrete
fill 306 212 552 306 245 552 minecraft:light_blue_concrete
fill 307 212 552 308 212 552 minecraft:pearlescent_froglight
fill 309 212 552 309 245 552 minecraft:light_blue_concrete
fill 313 212 510 313 245 510 minecraft:light_blue_concrete
fill 314 212 510 315 212 510 minecraft:pearlescent_froglight
fill 315 212 526 316 213 526 minecraft:white_wool
fill 316 212 510 316 245 510 minecraft:light_blue_concrete
fill 316 212 525 316 213 525 minecraft:white_wool
fill 318 212 552 318 245 552 minecraft:light_blue_concrete
fill 319 212 552 320 212 552 minecraft:pearlescent_froglight
fill 321 212 552 321 245 552 minecraft:light_blue_concrete
fill 324 212 511 324 245 511 minecraft:light_blue_concrete
fill 324 212 512 324 212 513 minecraft:pearlescent_froglight
fill 324 212 514 324 245 514 minecraft:light_blue_concrete
fill 324 212 523 324 245 523 minecraft:light_blue_concrete
fill 324 212 524 324 212 525 minecraft:pearlescent_froglight
fill 324 212 526 324 245 526 minecraft:light_blue_concrete
fill 324 212 535 324 245 535 minecraft:light_blue_concrete
fill 324 212 536 324 212 537 minecraft:pearlescent_froglight
fill 324 212 538 324 245 538 minecraft:light_blue_concrete
fill 324 212 547 324 245 547 minecraft:light_blue_concrete
fill 324 212 548 324 212 549 minecraft:pearlescent_froglight
fill 324 212 550 324 245 550 minecraft:light_blue_concrete
fill 282 213 517 282 231 518 minecraft:light_blue_concrete
fill 282 213 529 282 231 530 minecraft:light_blue_concrete
fill 282 213 541 282 231 542 minecraft:light_blue_concrete
fill 283 213 552 284 231 552 minecraft:light_blue_concrete
fill 290 213 510 291 231 510 minecraft:light_blue_concrete
fill 295 213 552 296 231 552 minecraft:light_blue_concrete
fill 302 213 510 303 231 510 minecraft:light_blue_concrete
fill 307 213 552 308 231 552 minecraft:light_blue_concrete
fill 314 213 510 315 231 510 minecraft:light_blue_concrete
fill 319 213 552 320 231 552 minecraft:light_blue_concrete
fill 324 213 512 324 231 513 minecraft:light_blue_concrete
fill 324 213 524 324 231 525 minecraft:light_blue_concrete
fill 324 213 536 324 231 537 minecraft:light_blue_concrete
fill 324 213 548 324 231 549 minecraft:light_blue_concrete
setblock 285 215 513 minecraft:light[level=14]
setblock 285 215 521 minecraft:light[level=14]
setblock 285 215 529 minecraft:light[level=14]
setblock 285 215 537 minecraft:light[level=14]
setblock 285 215 545 minecraft:light[level=14]
setblock 293 215 513 minecraft:light[level=14]
setblock 293 215 521 minecraft:light[level=14]
setblock 293 215 529 minecraft:light[level=14]
setblock 293 215 537 minecraft:light[level=14]
setblock 293 215 545 minecraft:light[level=14]
setblock 301 215 513 minecraft:light[level=14]
setblock 301 215 521 minecraft:light[level=14]
setblock 301 215 529 minecraft:light[level=14]
setblock 301 215 537 minecraft:light[level=14]
setblock 301 215 545 minecraft:light[level=14]
setblock 309 215 513 minecraft:light[level=14]
setblock 309 215 521 minecraft:light[level=14]
setblock 309 215 529 minecraft:light[level=14]
setblock 309 215 537 minecraft:light[level=14]
setblock 309 215 545 minecraft:light[level=14]
setblock 317 215 513 minecraft:light[level=14]
setblock 317 215 521 minecraft:light[level=14]
setblock 317 215 529 minecraft:light[level=14]
setblock 317 215 537 minecraft:light[level=14]
setblock 317 215 545 minecraft:light[level=14]
fill 284 220 520 284 221 522 minecraft:quartz_block
fill 284 220 532 284 221 534 minecraft:quartz_block
fill 284 220 544 284 221 546 minecraft:quartz_block
fill 290 220 550 292 221 550 minecraft:quartz_block
fill 294 220 512 296 221 512 minecraft:quartz_block
fill 302 220 550 304 221 550 minecraft:quartz_block
fill 306 220 512 308 221 512 minecraft:quartz_block
fill 314 220 550 316 221 550 minecraft:quartz_block
fill 318 220 512 320 221 512 minecraft:quartz_block
fill 322 220 520 322 221 522 minecraft:quartz_block
fill 322 220 532 322 221 534 minecraft:quartz_block
fill 322 220 544 322 221 546 minecraft:quartz_block
setblock 285 223 513 minecraft:light[level=14]
setblock 285 223 521 minecraft:light[level=14]
setblock 285 223 529 minecraft:light[level=14]
setblock 285 223 537 minecraft:light[level=14]
setblock 285 223 545 minecraft:light[level=14]
setblock 293 223 513 minecraft:light[level=14]
setblock 293 223 521 minecraft:light[level=14]
setblock 293 223 529 minecraft:light[level=14]
setblock 293 223 537 minecraft:light[level=14]
setblock 293 223 545 minecraft:light[level=14]
setblock 301 223 513 minecraft:light[level=14]
setblock 301 223 521 minecraft:light[level=14]
setblock 301 223 529 minecraft:light[level=14]
setblock 301 223 537 minecraft:light[level=14]
setblock 301 223 545 minecraft:light[level=14]
setblock 309 223 513 minecraft:light[level=14]
setblock 309 223 521 minecraft:light[level=14]
setblock 309 223 529 minecraft:light[level=14]
setblock 309 223 537 minecraft:light[level=14]
setblock 309 223 545 minecraft:light[level=14]
setblock 317 223 513 minecraft:light[level=14]
setblock 317 223 521 minecraft:light[level=14]
setblock 317 223 529 minecraft:light[level=14]
setblock 317 223 537 minecraft:light[level=14]
setblock 317 223 545 minecraft:light[level=14]
fill 291 227 527 292 228 527 minecraft:gold_block
fill 292 227 523 293 227 526 minecraft:gold_block
fill 292 227 528 293 227 531 minecraft:gold_block
fill 293 227 521 294 227 522 minecraft:gold_block
fill 293 227 527 299 227 527 minecraft:white_stained_glass
fill 293 227 532 294 228 533 minecraft:gold_block
fill 294 227 520 296 227 520 minecraft:gold_block
fill 294 227 523 300 227 526 minecraft:white_stained_glass
fill 294 227 528 300 227 531 minecraft:white_stained_glass
fill 294 227 534 296 227 534 minecraft:gold_block
fill 295 227 519 297 227 519 minecraft:gold_block
setblock 295 227 521 minecraft:gold_block
fill 295 227 522 309 228 522 minecraft:white_stained_glass
fill 295 227 532 309 228 532 minecraft:white_stained_glass
setblock 295 227 533 minecraft:gold_block
fill 295 227 535 297 227 535 minecraft:gold_block
fill 296 227 518 301 227 518 minecraft:gold_block
fill 296 227 521 308 228 521 minecraft:white_stained_glass
fill 296 227 533 308 228 533 minecraft:white_stained_glass
fill 296 227 536 301 227 536 minecraft:gold_block
fill 297 227 520 307 228 520 minecraft:white_stained_glass
fill 297 227 534 307 228 534 minecraft:white_stained_glass
fill 298 227 517 306 227 517 minecraft:gold_block
fill 298 227 519 306 228 519 minecraft:white_stained_glass
fill 298 227 535 306 228 535 minecraft:white_stained_glass
fill 298 227 537 306 227 537 minecraft:gold_block
fill 301 227 523 301 227 525 minecraft:white_stained_glass
fill 301 227 529 301 227 531 minecraft:white_stained_glass
fill 302 227 516 302 228 516 minecraft:gold_block
fill 302 227 518 302 228 518 minecraft:white_stained_glass
fill 302 227 523 310 227 524 minecraft:white_stained_glass
fill 302 227 530 310 227 531 minecraft:white_stained_glass
fill 302 227 536 302 228 536 minecraft:white_stained_glass
setblock 302 227 538 minecraft:gold_block
fill 303 227 518 308 227 518 minecraft:gold_block
fill 303 227 525 310 227 525 minecraft:white_stained_glass
fill 303 227 529 310 227 529 minecraft:white_stained_glass
fill 303 227 536 308 227 536 minecraft:gold_block
fill 304 227 526 310 227 526 minecraft:white_stained_glass
fill 304 227 528 310 227 528 minecraft:white_stained_glass
fill 305 227 527 311 227 527 minecraft:white_stained_glass
fill 307 227 519 309 227 519 minecraft:gold_block
fill 307 227 535 309 227 535 minecraft:gold_block
fill 308 227 520 310 227 520 minecraft:gold_block
fill 308 227 534 310 227 534 minecraft:gold_block
fill 309 227 521 311 227 521 minecraft:gold_block
fill 309 227 533 311 227 533 minecraft:gold_block
fill 310 227 522 311 227 522 minecraft:gold_block
fill 310 227 532 311 228 532 minecraft:gold_block
fill 311 227 523 312 227 526 minecraft:gold_block
fill 311 227 528 312 227 531 minecraft:gold_block
fill 312 227 527 313 227 527 minecraft:gold_block
fill 283 228 511 290 228 551 minecraft:quartz_block
fill 291 228 511 291 228 526 minecraft:quartz_block
fill 291 228 528 291 228 551 minecraft:quartz_block
fill 292 228 511 292 228 522 minecraft:quartz_block
setblock 292 228 523 minecraft:gold_block
setblock 292 228 524 minecraft:pearlescent_froglight
fill 292 228 525 293 228 526 minecraft:gold_block
setblock 292 228 528 minecraft:pearlescent_froglight
fill 292 228 529 292 228 531 minecraft:gold_block
fill 292 228 532 292 228 551 minecraft:quartz_block
fill 293 228 511 293 228 520 minecraft:quartz_block
fill 293 228 521 293 228 522 minecraft:gold_block
setblock 293 228 523 minecraft:pearlescent_froglight
setblock 293 228 524 minecraft:gold_block
fill 293 228 527 298 228 527 minecraft:white_stained_glass
fill 293 228 528 293 228 530 minecraft:gold_block
setblock 293 228 531 minecraft:pearlescent_froglight
fill 293 228 534 293 228 551 minecraft:quartz_block
fill 294 228 511 294 228 519 minecraft:quartz_block
fill 294 228 520 294 228 521 minecraft:gold_block
setblock 294 228 522 minecraft:pearlescent_froglight
fill 294 228 523 298 228 526 minecraft:white_stained_glass
fill 294 228 528 298 228 531 minecraft:white_stained_glass
setblock 294 228 534 minecraft:pearlescent_froglight
fill 294 228 535 294 228 551 minecraft:quartz_block
fill 295 228 511 295 228 518 minecraft:quartz_block
fill 295 228 519 295 228 520 minecraft:gold_block
setblock 295 228 521 minecraft:pearlescent_froglight
setblock 295 228 533 minecraft:pearlescent_froglight
fill 295 228 534 296 228 535 minecraft:gold_block
fill 295 228 536 295 228 551 minecraft:quartz_block
fill 296 228 511 297 228 517 minecraft:quartz_block
fill 296 228 518 296 228 519 minecraft:gold_block
setblock 296 228 520 minecraft:pearlescent_froglight
setblock 296 228 536 minecraft:pearlescent_froglight
fill 296 228 537 297 228 551 minecraft:quartz_block
setblock 297 228 518 minecraft:gold_block
setblock 297 228 519 minecraft:pearlescent_froglight
setblock 297 228 535 minecraft:pearlescent_froglight
fill 297 228 536 299 228 536 minecraft:gold_block
fill 298 228 511 301 228 516 minecraft:quartz_block
setblock 298 228 517 minecraft:gold_block
setblock 298 228 518 minecraft:pearlescent_froglight
setblock 298 228 537 minecraft:gold_block
fill 298 228 538 301 228 551 minecraft:quartz_block
setblock 299 228 517 minecraft:pearlescent_froglight
fill 299 228 518 301 228 518 minecraft:gold_block
fill 299 228 523 299 228 525 minecraft:white_stained_glass
fill 299 228 526 299 228 528 minecraft:pearlescent_froglight
fill 299 228 529 299 228 531 minecraft:white_stained_glass
setblock 299 228 537 minecraft:pearlescent_froglight
fill 300 228 517 302 228 517 minecraft:gold_block
fill 300 228 523 300 228 524 minecraft:white_stained_glass
fill 300 228 525 300 228 526 minecraft:pearlescent_froglight
fill 300 228 528 300 228 529 minecraft:pearlescent_froglight
fill 300 228 530 300 228 531 minecraft:white_stained_glass
setblock 300 228 536 minecraft:pearlescent_froglight
fill 300 228 537 302 228 537 minecraft:gold_block
fill 301 228 523 310 228 523 minecraft:white_stained_glass
fill 301 228 524 301 228 525 minecraft:pearlescent_froglight
fill 301 228 529 301 228 530 minecraft:pearlescent_froglight
fill 301 228 531 310 228 531 minecraft:white_stained_glass
setblock 301 228 536 minecraft:gold_block
fill 302 228 511 323 228 515 minecraft:quartz_block
fill 302 228 524 303 228 524 minecraft:pearlescent_froglight
fill 302 228 530 303 228 530 minecraft:pearlescent_froglight
setblock 302 228 538 minecraft:pearlescent_froglight
fill 302 228 539 323 228 551 minecraft:quartz_block
fill 303 228 516 323 228 516 minecraft:quartz_block
setblock 303 228 517 minecraft:pearlescent_froglight
fill 303 228 518 305 228 518 minecraft:gold_block
fill 303 228 525 304 228 525 minecraft:pearlescent_froglight
fill 303 228 529 304 228 529 minecraft:pearlescent_froglight
setblock 303 228 536 minecraft:gold_block
setblock 303 228 537 minecraft:pearlescent_froglight
fill 303 228 538 323 228 538 minecraft:quartz_block
fill 304 228 517 306 228 517 minecraft:gold_block
fill 304 228 524 310 228 524 minecraft:white_stained_glass
fill 304 228 526 305 228 526 minecraft:pearlescent_froglight
fill 304 228 528 305 228 528 minecraft:pearlescent_froglight
fill 304 228 530 310 228 530 minecraft:white_stained_glass
setblock 304 228 536 minecraft:pearlescent_froglight
fill 304 228 537 306 228 537 minecraft:gold_block
fill 305 228 525 310 228 525 minecraft:white_stained_glass
setblock 305 228 527 minecraft:pearlescent_froglight
fill 305 228 529 310 228 529 minecraft:white_stained_glass
fill 305 228 536 307 228 536 minecraft:gold_block
setblock 306 228 518 minecraft:pearlescent_froglight
fill 306 228 526 310 228 528 minecraft:white_stained_glass
fill 307 228 517 323 228 517 minecraft:quartz_block
fill 307 228 518 308 228 519 minecraft:gold_block
fill 307 228 535 308 228 535 minecraft:gold_block
fill 307 228 537 323 228 537 minecraft:quartz_block
setblock 308 228 520 minecraft:pearlescent_froglight
fill 308 228 534 309 228 534 minecraft:gold_block
setblock 308 228 536 minecraft:pearlescent_froglight
fill 309 228 518 323 228 518 minecraft:quartz_block
setblock 309 228 519 minecraft:pearlescent_froglight
fill 309 228 520 310 228 521 minecraft:gold_block
fill 309 228 533 310 228 533 minecraft:gold_block
setblock 309 228 535 minecraft:pearlescent_froglight
fill 309 228 536 323 228 536 minecraft:quartz_block
fill 310 228 519 323 228 519 minecraft:quartz_block
setblock 310 228 522 minecraft:pearlescent_froglight
setblock 310 228 534 minecraft:pearlescent_froglight
fill 310 228 535 323 228 535 minecraft:quartz_block
fill 311 228 520 323 228 520 minecraft:quartz_block
setblock 311 228 521 minecraft:pearlescent_froglight
fill 311 228 522 311 228 524 minecraft:gold_block
setblock 311 228 525 minecraft:pearlescent_froglight
fill 311 228 526 312 228 526 minecraft:gold_block
setblock 311 228 527 minecraft:white_stained_glass
setblock 311 228 528 minecraft:gold_block
setblock 311 228 529 minecraft:pearlescent_froglight
fill 311 228 530 312 228 531 minecraft:gold_block
setblock 311 228 533 minecraft:pearlescent_froglight
fill 311 228 534 323 228 534 minecraft:quartz_block
fill 312 228 521 323 228 522 minecraft:quartz_block
setblock 312 228 523 minecraft:gold_block
setblock 312 228 524 minecraft:pearlescent_froglight
setblock 312 228 525 minecraft:gold_block
setblock 312 228 527 minecraft:gold_block
setblock 312 228 528 minecraft:pearlescent_froglight
setblock 312 228 529 minecraft:gold_block
fill 312 228 532 323 228 533 minecraft:quartz_block
fill 313 228 523 323 228 526 minecraft:quartz_block
setblock 313 228 527 minecraft:pearlescent_froglight
fill 313 228 528 323 228 531 minecraft:quartz_block
fill 314 228 527 323 228 527 minecraft:quartz_block
fill 291 229 517 293 232 517 minecraft:gold_block
fill 291 229 537 293 232 537 minecraft:gold_block
fill 292 229 516 292 232 516 minecraft:gold_block
fill 292 229 518 292 232 518 minecraft:gold_block
fill 292 229 536 292 232 536 minecraft:gold_block
fill 292 229 538 292 232 538 minecraft:gold_block
fill 311 229 517 313 232 517 minecraft:gold_block
fill 311 229 537 313 232 537 minecraft:gold_block
fill 312 229 516 312 232 516 minecraft:gold_block
fill 312 229 518 312 232 518 minecraft:gold_block
fill 312 229 536 312 232 536 minecraft:gold_block
fill 312 229 538 312 232 538 minecraft:gold_block
setblock 285 231 513 minecraft:light[level=14]
setblock 285 231 521 minecraft:light[level=14]
setblock 285 231 529 minecraft:light[level=14]
setblock 285 231 537 minecraft:light[level=14]
setblock 285 231 545 minecraft:light[level=14]
setblock 293 231 513 minecraft:light[level=14]
setblock 293 231 521 minecraft:light[level=14]
setblock 293 231 529 minecraft:light[level=14]
setblock 293 231 545 minecraft:light[level=14]
setblock 301 231 513 minecraft:light[level=14]
setblock 301 231 521 minecraft:light[level=14]
setblock 301 231 529 minecraft:light[level=14]
setblock 301 231 537 minecraft:light[level=14]
setblock 301 231 545 minecraft:light[level=14]
setblock 309 231 513 minecraft:light[level=14]
setblock 309 231 521 minecraft:light[level=14]
setblock 309 231 529 minecraft:light[level=14]
setblock 309 231 537 minecraft:light[level=14]
setblock 309 231 545 minecraft:light[level=14]
setblock 317 231 513 minecraft:light[level=14]
setblock 317 231 521 minecraft:light[level=14]
setblock 317 231 529 minecraft:light[level=14]
setblock 317 231 537 minecraft:light[level=14]
setblock 317 231 545 minecraft:light[level=14]
fill 282 232 517 282 232 518 minecraft:pearlescent_froglight
fill 282 232 529 282 232 530 minecraft:pearlescent_froglight
fill 282 232 541 282 232 542 minecraft:pearlescent_froglight
fill 283 232 511 285 273 511 minecraft:quartz_block
fill 283 232 521 283 273 523 minecraft:quartz_block
fill 283 232 533 283 273 535 minecraft:quartz_block
fill 283 232 545 283 273 547 minecraft:quartz_block
fill 283 232 552 284 232 552 minecraft:pearlescent_froglight
fill 286 232 514 286 232 517 minecraft:smooth_quartz
fill 287 232 513 289 232 513 minecraft:smooth_quartz
fill 287 232 514 289 273 516 minecraft:quartz_block
setblock 287 232 517 minecraft:smooth_quartz
fill 288 232 517 288 273 517 minecraft:quartz_block
setblock 289 232 517 minecraft:smooth_quartz
fill 289 232 551 291 273 551 minecraft:quartz_block
fill 290 232 510 291 232 510 minecraft:pearlescent_froglight
fill 290 232 514 290 232 516 minecraft:smooth_quartz
fill 295 232 511 297 273 511 minecraft:quartz_block
fill 295 232 552 296 232 552 minecraft:pearlescent_froglight
fill 301 232 551 303 273 551 minecraft:quartz_block
fill 302 232 510 303 232 510 minecraft:pearlescent_froglight
fill 307 232 511 309 273 511 minecraft:quartz_block
fill 307 232 552 308 232 552 minecraft:pearlescent_froglight
fill 309 232 519 310 232 519 minecraft:white_concrete
fill 313 232 551 315 273 551 minecraft:quartz_block
fill 314 232 510 315 232 510 minecraft:pearlescent_froglight
fill 316 232 546 316 232 547 minecraft:smooth_quartz
setblock 317 232 545 minecraft:smooth_quartz
fill 317 232 546 320 273 547 minecraft:quartz_block
setblock 317 232 548 minecraft:smooth_quartz
fill 318 232 544 319 232 544 minecraft:smooth_quartz
fill 318 232 545 319 273 545 minecraft:quartz_block
fill 318 232 548 319 273 548 minecraft:quartz_block
setblock 318 232 549 minecraft:smooth_quartz
fill 319 232 511 321 273 511 minecraft:quartz_block
fill 319 232 552 320 232 552 minecraft:pearlescent_froglight
setblock 320 232 545 minecraft:smooth_quartz
setblock 320 232 548 minecraft:smooth_quartz
fill 323 232 519 323 273 521 minecraft:quartz_block
fill 323 232 531 323 273 533 minecraft:quartz_block
fill 323 232 543 323 273 545 minecraft:quartz_block
fill 324 232 512 324 232 513 minecraft:pearlescent_froglight
fill 324 232 524 324 232 525 minecraft:pearlescent_froglight
fill 324 232 536 324 232 537 minecraft:pearlescent_froglight
fill 324 232 548 324 232 549 minecraft:pearlescent_froglight
fill 282 233 517 282 245 518 minecraft:light_blue_concrete
fill 282 233 529 282 245 530 minecraft:light_blue_concrete
fill 282 233 541 282 245 542 minecraft:light_blue_concrete
fill 283 233 552 284 245 552 minecraft:light_blue_concrete
fill 290 233 510 291 245 510 minecraft:light_blue_concrete
fill 295 233 552 296 245 552 minecraft:light_blue_concrete
fill 302 233 510 303 245 510 minecraft:light_blue_concrete
fill 307 233 552 308 245 552 minecraft:light_blue_concrete
fill 314 233 510 315 245 510 minecraft:light_blue_concrete
fill 319 233 552 320 245 552 minecraft:light_blue_concrete
fill 324 233 512 324 245 513 minecraft:light_blue_concrete
fill 324 233 524 324 245 525 minecraft:light_blue_concrete
fill 324 233 536 324 245 537 minecraft:light_blue_concrete
fill 324 233 548 324 245 549 minecraft:light_blue_concrete
setblock 285 239 513 minecraft:light[level=14]
setblock 285 239 521 minecraft:light[level=14]
setblock 285 239 529 minecraft:light[level=14]
setblock 285 239 537 minecraft:light[level=14]
setblock 285 239 545 minecraft:light[level=14]
setblock 293 239 513 minecraft:light[level=14]
setblock 293 239 521 minecraft:light[level=14]
setblock 293 239 529 minecraft:light[level=14]
setblock 293 239 537 minecraft:light[level=14]
setblock 293 239 545 minecraft:light[level=14]
setblock 301 239 513 minecraft:light[level=14]
setblock 301 239 521 minecraft:light[level=14]
setblock 301 239 537 minecraft:light[level=14]
setblock 301 239 545 minecraft:light[level=14]
setblock 309 239 513 minecraft:light[level=14]
setblock 309 239 521 minecraft:light[level=14]
setblock 309 239 529 minecraft:light[level=14]
setblock 309 239 537 minecraft:light[level=14]
setblock 309 239 545 minecraft:light[level=14]
setblock 317 239 513 minecraft:light[level=14]
setblock 317 239 521 minecraft:light[level=14]
setblock 317 239 529 minecraft:light[level=14]
setblock 317 239 537 minecraft:light[level=14]
setblock 317 239 545 minecraft:light[level=14]
fill 284 240 520 284 245 522 minecraft:quartz_block
fill 284 240 532 284 245 534 minecraft:quartz_block
fill 284 240 544 284 245 546 minecraft:quartz_block
fill 286 240 514 286 240 517 minecraft:smooth_quartz
fill 287 240 513 289 240 513 minecraft:smooth_quartz
setblock 287 240 517 minecraft:smooth_quartz
setblock 289 240 517 minecraft:smooth_quartz
fill 290 240 514 290 240 516 minecraft:smooth_quartz
fill 290 240 550 292 245 550 minecraft:quartz_block
fill 294 240 512 296 245 512 minecraft:quartz_block
fill 302 240 550 304 245 550 minecraft:quartz_block
fill 306 240 512 308 245 512 minecraft:quartz_block
fill 314 240 550 316 245 550 minecraft:quartz_block
fill 316 240 546 316 240 547 minecraft:smooth_quartz
setblock 317 240 545 minecraft:smooth_quartz
setblock 317 240 548 minecraft:smooth_quartz
fill 318 240 512 320 245 512 minecraft:quartz_block
fill 318 240 544 319 240 544 minecraft:smooth_quartz
setblock 318 240 549 minecraft:smooth_quartz
setblock 320 240 545 minecraft:smooth_quartz
setblock 320 240 548 minecraft:smooth_quartz
fill 322 240 520 322 245 522 minecraft:quartz_block
fill 322 240 532 322 245 534 minecraft:quartz_block
fill 322 240 544 322 245 546 minecraft:quartz_block
fill 316 243 533 317 244 534 minecraft:white_wool
fill 317 243 532 317 244 532 minecraft:white_wool
fill 283 245 514 283 245 519 minecraft:smooth_quartz
fill 283 245 526 283 245 531 minecraft:smooth_quartz
fill 283 245 538 283 245 543 minecraft:smooth_quartz
fill 283 245 550 283 245 551 minecraft:smooth_quartz
fill 284 245 551 287 245 551 minecraft:smooth_quartz
fill 287 245 511 292 245 511 minecraft:smooth_quartz
fill 294 245 551 299 245 551 minecraft:smooth_quartz
fill 299 245 511 304 245 511 minecraft:smooth_quartz
fill 306 245 551 311 245 551 minecraft:smooth_quartz
fill 311 245 511 316 245 511 minecraft:smooth_quartz
fill 318 245 551 323 245 551 minecraft:smooth_quartz
fill 323 245 511 323 245 516 minecraft:smooth_quartz
fill 323 245 523 323 245 528 minecraft:smooth_quartz
fill 323 245 535 323 245 540 minecraft:smooth_quartz
fill 323 245 547 323 245 550 minecraft:smooth_quartz
fill 282 246 516 282 251 519 minecraft:pearlescent_froglight
fill 282 246 528 282 251 531 minecraft:pearlescent_froglight
fill 282 246 540 282 251 543 minecraft:pearlescent_froglight
fill 282 246 552 285 251 552 minecraft:pearlescent_froglight
fill 289 246 510 292 251 510 minecraft:pearlescent_froglight
fill 294 246 536 295 247 536 minecraft:white_concrete
fill 294 246 552 297 251 552 minecraft:pearlescent_froglight
fill 301 246 510 304 251 510 minecraft:pearlescent_froglight
fill 306 246 552 309 251 552 minecraft:pearlescent_froglight
fill 313 246 510 316 251 510 minecraft:pearlescent_froglight
fill 318 246 552 321 251 552 minecraft:pearlescent_froglight
fill 324 246 511 324 251 514 minecraft:pearlescent_froglight
fill 324 246 523 324 251 526 minecraft:pearlescent_froglight
fill 324 246 535 324 251 538 minecraft:pearlescent_froglight
fill 324 246 547 324 251 550 minecraft:pearlescent_froglight
setblock 285 247 513 minecraft:light[level=14]
setblock 285 247 521 minecraft:light[level=14]
setblock 285 247 529 minecraft:light[level=14]
setblock 285 247 537 minecraft:light[level=14]
setblock 285 247 545 minecraft:light[level=14]
setblock 293 247 513 minecraft:light[level=14]
setblock 293 247 521 minecraft:light[level=14]
setblock 293 247 529 minecraft:light[level=14]
setblock 293 247 537 minecraft:light[level=14]
setblock 293 247 545 minecraft:light[level=14]
setblock 301 247 513 minecraft:light[level=14]
setblock 301 247 521 minecraft:light[level=14]
setblock 301 247 537 minecraft:light[level=14]
setblock 301 247 545 minecraft:light[level=14]
setblock 309 247 513 minecraft:light[level=14]
setblock 309 247 521 minecraft:light[level=14]
setblock 309 247 529 minecraft:light[level=14]
setblock 309 247 537 minecraft:light[level=14]
setblock 309 247 545 minecraft:light[level=14]
setblock 317 247 513 minecraft:light[level=14]
setblock 317 247 521 minecraft:light[level=14]
setblock 317 247 529 minecraft:light[level=14]
setblock 317 247 537 minecraft:light[level=14]
setblock 317 247 545 minecraft:light[level=14]
fill 318 247 525 319 248 525 minecraft:white_concrete
fill 286 248 514 286 248 517 minecraft:smooth_quartz
fill 287 248 513 289 248 513 minecraft:smooth_quartz
setblock 287 248 517 minecraft:smooth_quartz
setblock 289 248 517 minecraft:smooth_quartz
fill 290 248 514 290 248 516 minecraft:smooth_quartz
fill 316 248 546 316 248 547 minecraft:smooth_quartz
setblock 317 248 545 minecraft:smooth_quartz
setblock 317 248 548 minecraft:smooth_quartz
fill 318 248 544 319 248 544 minecraft:smooth_quartz
setblock 318 248 549 minecraft:smooth_quartz
setblock 320 248 545 minecraft:smooth_quartz
setblock 320 248 548 minecraft:smooth_quartz
fill 282 252 516 282 265 516 minecraft:light_blue_concrete
fill 282 252 517 282 252 518 minecraft:pearlescent_froglight
fill 282 252 519 282 265 519 minecraft:light_blue_concrete
fill 282 252 528 282 265 528 minecraft:light_blue_concrete
fill 282 252 529 282 252 530 minecraft:pearlescent_froglight
fill 282 252 531 282 265 531 minecraft:light_blue_concrete
fill 282 252 540 282 265 540 minecraft:light_blue_concrete
fill 282 252 541 282 252 542 minecraft:pearlescent_froglight
fill 282 252 543 282 265 543 minecraft:light_blue_concrete
fill 282 252 552 282 265 552 minecraft:light_blue_concrete
fill 283 252 552 284 252 552 minecraft:pearlescent_froglight
fill 285 252 552 285 265 552 minecraft:light_blue_concrete
fill 289 252 510 289 265 510 minecraft:light_blue_concrete
fill 290 252 510 291 252 510 minecraft:pearlescent_froglight
fill 292 252 510 292 265 510 minecraft:light_blue_concrete
fill 294 252 552 294 265 552 minecraft:light_blue_concrete
fill 295 252 552 296 252 552 minecraft:pearlescent_froglight
fill 297 252 552 297 265 552 minecraft:light_blue_concrete
fill 301 252 510 301 265 510 minecraft:light_blue_concrete
fill 302 252 510 303 252 510 minecraft:pearlescent_froglight
fill 304 252 510 304 265 510 minecraft:light_blue_concrete
fill 306 252 552 306 265 552 minecraft:light_blue_concrete
fill 307 252 552 308 252 552 minecraft:pearlescent_froglight
fill 309 252 552 309 265 552 minecraft:light_blue_concrete
fill 313 252 510 313 265 510 minecraft:light_blue_concrete
fill 313 252 536 315 253 537 minecraft:white_concrete
fill 314 252 510 315 252 510 minecraft:pearlescent_froglight
fill 316 252 510 316 265 510 minecraft:light_blue_concrete
fill 318 252 552 318 265 552 minecraft:light_blue_concrete
fill 319 252 552 320 252 552 minecraft:pearlescent_froglight
fill 321 252 552 321 265 552 minecraft:light_blue_concrete
fill 324 252 511 324 265 511 minecraft:light_blue_concrete
fill 324 252 512 324 252 513 minecraft:pearlescent_froglight
fill 324 252 514 324 265 514 minecraft:light_blue_concrete
fill 324 252 523 324 265 523 minecraft:light_blue_concrete
fill 324 252 524 324 252 525 minecraft:pearlescent_froglight
fill 324 252 526 324 265 526 minecraft:light_blue_concrete
fill 324 252 535 324 265 535 minecraft:light_blue_concrete
fill 324 252 536 324 252 537 minecraft:pearlescent_froglight
fill 324 252 538 324 265 538 minecraft:light_blue_concrete
fill 324 252 547 324 265 547 minecraft:light_blue_concrete
fill 324 252 548 324 252 549 minecraft:pearlescent_froglight
fill 324 252 550 324 265 550 minecraft:light_blue_concrete
fill 282 253 517 282 265 518 minecraft:light_blue_concrete
fill 282 253 529 282 265 530 minecraft:light_blue_concrete
fill 282 253 541 282 265 542 minecraft:light_blue_concrete
fill 283 253 552 284 265 552 minecraft:light_blue_concrete
fill 290 253 510 291 265 510 minecraft:light_blue_concrete
fill 295 253 552 296 265 552 minecraft:light_blue_concrete
fill 302 253 510 303 265 510 minecraft:light_blue_concrete
fill 307 253 552 308 265 552 minecraft:light_blue_concrete
fill 314 253 510 315 265 510 minecraft:light_blue_concrete
fill 319 253 552 320 265 552 minecraft:light_blue_concrete
fill 324 253 512 324 265 513 minecraft:light_blue_concrete
fill 324 253 524 324 265 525 minecraft:light_blue_concrete
fill 324 253 536 324 265 537 minecraft:light_blue_concrete
fill 324 253 548 324 265 549 minecraft:light_blue_concrete
setblock 285 255 513 minecraft:light[level=14]
setblock 285 255 521 minecraft:light[level=14]
setblock 285 255 529 minecraft:light[level=14]
setblock 285 255 537 minecraft:light[level=14]
setblock 285 255 545 minecraft:light[level=14]
setblock 293 255 513 minecraft:light[level=14]
setblock 293 255 521 minecraft:light[level=14]
setblock 293 255 529 minecraft:light[level=14]
setblock 293 255 537 minecraft:light[level=14]
setblock 293 255 545 minecraft:light[level=14]
setblock 301 255 513 minecraft:light[level=14]
setblock 301 255 521 minecraft:light[level=14]
setblock 301 255 537 minecraft:light[level=14]
setblock 301 255 545 minecraft:light[level=14]
setblock 309 255 513 minecraft:light[level=14]
setblock 309 255 521 minecraft:light[level=14]
setblock 309 255 529 minecraft:light[level=14]
setblock 309 255 537 minecraft:light[level=14]
setblock 309 255 545 minecraft:light[level=14]
setblock 317 255 513 minecraft:light[level=14]
setblock 317 255 521 minecraft:light[level=14]
setblock 317 255 529 minecraft:light[level=14]
setblock 317 255 537 minecraft:light[level=14]
setblock 317 255 545 minecraft:light[level=14]
fill 286 256 514 286 256 517 minecraft:smooth_quartz
fill 287 256 513 289 256 513 minecraft:smooth_quartz
setblock 287 256 517 minecraft:smooth_quartz
setblock 289 256 517 minecraft:smooth_quartz
fill 290 256 514 290 256 516 minecraft:smooth_quartz
fill 316 256 546 316 256 547 minecraft:smooth_quartz
setblock 317 256 545 minecraft:smooth_quartz
setblock 317 256 548 minecraft:smooth_quartz
fill 318 256 544 319 256 544 minecraft:smooth_quartz
setblock 318 256 549 minecraft:smooth_quartz
setblock 320 256 545 minecraft:smooth_quartz
setblock 320 256 548 minecraft:smooth_quartz
fill 316 257 541 316 258 541 minecraft:light_blue_stained_glass
fill 286 259 532 286 260 532 minecraft:white_wool
fill 316 259 541 316 268 541 minecraft:smooth_quartz
fill 284 260 520 284 265 522 minecraft:quartz_block
fill 284 260 532 284 265 534 minecraft:quartz_block
fill 284 260 544 284 265 546 minecraft:quartz_block
fill 290 260 550 292 265 550 minecraft:quartz_block
fill 294 260 512 296 265 512 minecraft:quartz_block
fill 302 260 550 304 265 550 minecraft:quartz_block
fill 306 260 512 308 265 512 minecraft:quartz_block
fill 314 260 550 316 265 550 minecraft:quartz_block
fill 318 260 512 320 265 512 minecraft:quartz_block
fill 322 260 520 322 265 522 minecraft:quartz_block
fill 322 260 532 322 265 534 minecraft:quartz_block
fill 322 260 544 322 265 546 minecraft:quartz_block
fill 315 261 541 315 268 541 minecraft:smooth_quartz
fill 316 261 540 316 268 540 minecraft:smooth_quartz
fill 316 261 542 316 268 542 minecraft:smooth_quartz
fill 317 261 541 317 268 541 minecraft:smooth_quartz
fill 315 262 540 315 268 540 minecraft:smooth_quartz
fill 315 262 542 315 268 542 minecraft:smooth_quartz
fill 317 262 540 317 268 540 minecraft:smooth_quartz
fill 317 262 542 317 268 542 minecraft:smooth_quartz
setblock 285 263 513 minecraft:light[level=14]
setblock 285 263 521 minecraft:light[level=14]
setblock 285 263 529 minecraft:light[level=14]
setblock 285 263 537 minecraft:light[level=14]
setblock 285 263 545 minecraft:light[level=14]
setblock 293 263 513 minecraft:light[level=14]
setblock 293 263 521 minecraft:light[level=14]
setblock 293 263 529 minecraft:light[level=14]
setblock 293 263 537 minecraft:light[level=14]
setblock 293 263 545 minecraft:light[level=14]
setblock 301 263 513 minecraft:light[level=14]
setblock 301 263 521 minecraft:light[level=14]
setblock 301 263 537 minecraft:light[level=14]
setblock 301 263 545 minecraft:light[level=14]
setblock 309 263 513 minecraft:light[level=14]
setblock 309 263 521 minecraft:light[level=14]
setblock 309 263 529 minecraft:light[level=14]
setblock 309 263 537 minecraft:light[level=14]
setblock 309 263 545 minecraft:light[level=14]
fill 314 263 541 314 268 542 minecraft:smooth_quartz
fill 315 263 543 317 268 543 minecraft:smooth_quartz
setblock 317 263 513 minecraft:light[level=14]
setblock 317 263 521 minecraft:light[level=14]
setblock 317 263 529 minecraft:light[level=14]
setblock 317 263 537 minecraft:light[level=14]
setblock 317 263 545 minecraft:light[level=14]
fill 318 263 541 318 268 541 minecraft:smooth_quartz
fill 286 264 514 286 264 517 minecraft:smooth_quartz
fill 287 264 513 289 264 513 minecraft:smooth_quartz
setblock 287 264 517 minecraft:smooth_quartz
setblock 289 264 517 minecraft:smooth_quartz
fill 290 264 514 290 264 516 minecraft:smooth_quartz
fill 314 264 540 314 268 540 minecraft:smooth_quartz
fill 315 264 539 317 268 539 minecraft:smooth_quartz
fill 316 264 537 317 265 538 minecraft:white_wool
fill 316 264 546 316 264 547 minecraft:smooth_quartz
setblock 317 264 545 minecraft:smooth_quartz
setblock 317 264 548 minecraft:smooth_quartz
fill 318 264 540 318 268 540 minecraft:smooth_quartz
fill 318 264 542 318 268 542 minecraft:smooth_quartz
fill 318 264 544 319 264 544 minecraft:smooth_quartz
setblock 318 264 549 minecraft:smooth_quartz
setblock 320 264 545 minecraft:smooth_quartz
setblock 320 264 548 minecraft:smooth_quartz
fill 283 265 514 283 265 519 minecraft:smooth_quartz
fill 283 265 526 283 265 531 minecraft:smooth_quartz
fill 283 265 538 283 265 543 minecraft:smooth_quartz
fill 283 265 550 283 265 551 minecraft:smooth_quartz
fill 284 265 551 287 265 551 minecraft:smooth_quartz
fill 287 265 511 292 265 511 minecraft:smooth_quartz
fill 292 265 526 292 266 526 minecraft:white_wool
fill 294 265 551 299 265 551 minecraft:smooth_quartz
fill 299 265 511 304 265 511 minecraft:smooth_quartz
fill 306 265 551 311 265 551 minecraft:smooth_quartz
fill 311 265 511 316 265 511 minecraft:smooth_quartz
fill 313 265 541 313 268 542 minecraft:smooth_quartz
fill 314 265 539 314 268 539 minecraft:smooth_quartz
fill 314 265 543 314 268 543 minecraft:smooth_quartz
fill 315 265 544 317 268 544 minecraft:smooth_quartz
fill 318 265 539 318 268 539 minecraft:smooth_quartz
fill 318 265 543 318 268 543 minecraft:smooth_quartz
fill 318 265 551 323 265 551 minecraft:smooth_quartz
fill 319 265 541 319 268 542 minecraft:smooth_quartz
fill 323 265 511 323 265 516 minecraft:smooth_quartz
fill 323 265 523 323 265 528 minecraft:smooth_quartz
fill 323 265 535 323 265 540 minecraft:smooth_quartz
fill 323 265 547 323 265 550 minecraft:smooth_quartz
fill 282 266 516 282 271 519 minecraft:pearlescent_froglight
fill 282 266 528 282 271 531 minecraft:pearlescent_froglight
fill 282 266 540 282 271 543 minecraft:pearlescent_froglight
fill 282 266 552 285 271 552 minecraft:pearlescent_froglight
fill 289 266 510 292 271 510 minecraft:pearlescent_froglight
fill 294 266 552 297 271 552 minecraft:pearlescent_froglight
fill 301 266 510 304 271 510 minecraft:pearlescent_froglight
fill 306 266 552 309 271 552 minecraft:pearlescent_froglight
fill 313 266 510 316 271 510 minecraft:pearlescent_froglight
fill 313 266 540 313 268 540 minecraft:smooth_quartz
fill 313 266 543 313 268 543 minecraft:smooth_quartz
fill 314 266 544 314 268 544 minecraft:smooth_quartz
fill 315 266 538 317 268 538 minecraft:smooth_quartz
fill 318 266 544 318 268 544 minecraft:smooth_quartz
fill 318 266 552 321 271 552 minecraft:pearlescent_froglight
fill 319 266 540 319 268 540 minecraft:smooth_quartz
fill 319 266 543 319 268 543 minecraft:smooth_quartz
fill 324 266 511 324 271 514 minecraft:pearlescent_froglight
fill 324 266 523 324 271 526 minecraft:pearlescent_froglight
fill 324 266 535 324 271 538 minecraft:pearlescent_froglight
fill 324 266 547 324 271 550 minecraft:pearlescent_froglight
fill 312 267 541 312 268 542 minecraft:smooth_quartz
fill 313 267 539 313 268 539 minecraft:smooth_quartz
fill 314 267 538 314 268 538 minecraft:smooth_quartz
fill 315 267 545 317 268 545 minecraft:smooth_quartz
fill 318 267 538 318 268 538 minecraft:smooth_quartz
fill 319 267 539 319 268 539 minecraft:smooth_quartz
fill 320 267 541 320 268 541 minecraft:smooth_quartz
fill 312 268 539 312 268 540 minecraft:smooth_quartz
setblock 312 268 543 minecraft:smooth_quartz
setblock 313 268 538 minecraft:smooth_quartz
setblock 313 268 544 minecraft:smooth_quartz
setblock 314 268 545 minecraft:smooth_quartz
fill 315 268 537 317 268 537 minecraft:smooth_quartz
setblock 319 268 538 minecraft:smooth_quartz
setblock 319 268 544 minecraft:smooth_quartz
fill 320 268 539 320 268 540 minecraft:smooth_quartz
fill 320 268 542 320 268 543 minecraft:smooth_quartz
fill 316 269 541 316 272 541 minecraft:gold_block
setblock 285 271 513 minecraft:light[level=14]
setblock 285 271 521 minecraft:light[level=14]
setblock 285 271 529 minecraft:light[level=14]
setblock 285 271 537 minecraft:light[level=14]
setblock 285 271 545 minecraft:light[level=14]
setblock 293 271 513 minecraft:light[level=14]
setblock 293 271 521 minecraft:light[level=14]
setblock 293 271 529 minecraft:light[level=14]
setblock 293 271 537 minecraft:light[level=14]
setblock 293 271 545 minecraft:light[level=14]
setblock 301 271 513 minecraft:light[level=14]
setblock 301 271 521 minecraft:light[level=14]
setblock 301 271 537 minecraft:light[level=14]
setblock 301 271 545 minecraft:light[level=14]
setblock 309 271 513 minecraft:light[level=14]
setblock 309 271 521 minecraft:light[level=14]
setblock 309 271 529 minecraft:light[level=14]
setblock 309 271 537 minecraft:light[level=14]
setblock 309 271 545 minecraft:light[level=14]
setblock 317 271 513 minecraft:light[level=14]
setblock 317 271 521 minecraft:light[level=14]
setblock 317 271 529 minecraft:light[level=14]
setblock 317 271 537 minecraft:light[level=14]
setblock 317 271 545 minecraft:light[level=14]
fill 282 272 516 282 285 516 minecraft:light_blue_concrete
fill 282 272 517 282 272 518 minecraft:pearlescent_froglight
fill 282 272 519 282 285 519 minecraft:light_blue_concrete
fill 282 272 528 282 285 528 minecraft:light_blue_concrete
fill 282 272 529 282 272 530 minecraft:pearlescent_froglight
fill 282 272 531 282 285 531 minecraft:light_blue_concrete
fill 282 272 540 282 285 540 minecraft:light_blue_concrete
fill 282 272 541 282 272 542 minecraft:pearlescent_froglight
fill 282 272 543 282 285 543 minecraft:light_blue_concrete
fill 282 272 552 282 285 552 minecraft:light_blue_concrete
fill 283 272 552 284 272 552 minecraft:pearlescent_froglight
fill 285 272 552 285 285 552 minecraft:light_blue_concrete
fill 286 272 514 286 272 517 minecraft:smooth_quartz
fill 287 272 513 289 272 513 minecraft:smooth_quartz
setblock 287 272 517 minecraft:smooth_quartz
fill 289 272 510 289 285 510 minecraft:light_blue_concrete
setblock 289 272 517 minecraft:smooth_quartz
fill 290 272 510 291 272 510 minecraft:pearlescent_froglight
fill 290 272 514 290 272 516 minecraft:smooth_quartz
fill 292 272 510 292 285 510 minecraft:light_blue_concrete
fill 294 272 552 294 285 552 minecraft:light_blue_concrete
fill 295 272 552 296 272 552 minecraft:pearlescent_froglight
fill 297 272 552 297 285 552 minecraft:light_blue_concrete
fill 301 272 510 301 285 510 minecraft:light_blue_concrete
fill 302 272 510 303 272 510 minecraft:pearlescent_froglight
fill 304 272 510 304 285 510 minecraft:light_blue_concrete
fill 306 272 552 306 285 552 minecraft:light_blue_concrete
fill 307 272 552 308 272 552 minecraft:pearlescent_froglight
fill 309 272 552 309 285 552 minecraft:light_blue_concrete
fill 313 272 510 313 285 510 minecraft:light_blue_concrete
fill 314 272 510 315 272 510 minecraft:pearlescent_froglight
fill 316 272 510 316 285 510 minecraft:light_blue_concrete
fill 316 272 546 316 272 547 minecraft:smooth_quartz
setblock 317 272 545 minecraft:smooth_quartz
setblock 317 272 548 minecraft:smooth_quartz
fill 318 272 544 319 272 544 minecraft:smooth_quartz
setblock 318 272 549 minecraft:smooth_quartz
fill 318 272 552 318 285 552 minecraft:light_blue_concrete
fill 319 272 552 320 272 552 minecraft:pearlescent_froglight
setblock 320 272 545 minecraft:smooth_quartz
setblock 320 272 548 minecraft:smooth_quartz
fill 321 272 552 321 285 552 minecraft:light_blue_concrete
fill 324 272 511 324 285 511 minecraft:light_blue_concrete
fill 324 272 512 324 272 513 minecraft:pearlescent_froglight
fill 324 272 514 324 285 514 minecraft:light_blue_concrete
fill 324 272 523 324 285 523 minecraft:light_blue_concrete
fill 324 272 524 324 272 525 minecraft:pearlescent_froglight
fill 324 272 526 324 285 526 minecraft:light_blue_concrete
fill 324 272 535 324 285 535 minecraft:light_blue_concrete
fill 324 272 536 324 272 537 minecraft:pearlescent_froglight
fill 324 272 538 324 285 538 minecraft:light_blue_concrete
fill 324 272 547 324 285 547 minecraft:light_blue_concrete
fill 324 272 548 324 272 549 minecraft:pearlescent_froglight
fill 324 272 550 324 285 550 minecraft:light_blue_concrete
fill 282 273 517 282 285 518 minecraft:light_blue_concrete
fill 282 273 529 282 285 530 minecraft:light_blue_concrete
fill 282 273 541 282 285 542 minecraft:light_blue_concrete
fill 283 273 552 284 285 552 minecraft:light_blue_concrete
fill 286 273 514 286 273 516 minecraft:gold_block
fill 287 273 513 288 273 513 minecraft:gold_block
setblock 287 273 517 minecraft:gold_block
setblock 289 273 517 minecraft:gold_block
fill 290 273 510 291 285 510 minecraft:light_blue_concrete
fill 290 273 515 290 273 516 minecraft:gold_block
fill 295 273 552 296 285 552 minecraft:light_blue_concrete
fill 302 273 510 303 285 510 minecraft:light_blue_concrete
fill 307 273 552 308 285 552 minecraft:light_blue_concrete
fill 314 273 510 315 285 510 minecraft:light_blue_concrete
setblock 316 273 541 minecraft:pearlescent_froglight
setblock 316 273 546 minecraft:gold_block
setblock 317 273 545 minecraft:gold_block
setblock 317 273 548 minecraft:gold_block
fill 319 273 552 320 285 552 minecraft:light_blue_concrete
setblock 320 273 545 minecraft:gold_block
setblock 320 273 548 minecraft:gold_block
fill 324 273 512 324 285 513 minecraft:light_blue_concrete
fill 324 273 524 324 285 525 minecraft:light_blue_concrete
fill 324 273 536 324 285 537 minecraft:light_blue_concrete
fill 324 273 548 324 285 549 minecraft:light_blue_concrete
fill 283 279 511 286 280 513 minecraft:light_blue_wool
fill 283 279 514 283 280 521 minecraft:white_wool
fill 283 279 522 286 280 528 minecraft:light_blue_wool
fill 283 279 529 283 280 537 minecraft:white_wool
fill 283 279 538 286 280 544 minecraft:light_blue_wool
fill 283 279 545 283 280 551 minecraft:white_wool
fill 284 279 514 323 280 520 minecraft:white_wool
fill 284 279 521 285 280 521 minecraft:light_blue_wool
fill 284 279 529 286 280 529 minecraft:light_blue_wool
fill 284 279 530 298 279 536 minecraft:white_wool
fill 284 279 537 285 280 537 minecraft:light_blue_wool
fill 284 279 545 285 280 545 minecraft:light_blue_wool
fill 284 279 546 323 280 551 minecraft:white_wool
fill 286 279 521 296 280 521 minecraft:white_wool
fill 286 279 537 295 280 537 minecraft:white_wool
fill 286 279 545 296 280 545 minecraft:white_wool
fill 287 279 511 287 280 512 minecraft:light_blue_wool
fill 287 279 513 295 280 513 minecraft:white_wool
fill 287 279 522 295 280 522 minecraft:white_wool
fill 287 279 523 287 280 528 minecraft:light_blue_wool
fill 287 279 529 295 280 529 minecraft:white_wool
fill 287 279 538 294 280 538 minecraft:white_wool
fill 287 279 539 287 280 543 minecraft:light_blue_wool
fill 287 279 544 295 280 544 minecraft:white_wool
fill 288 279 511 294 280 512 minecraft:white_wool
fill 288 279 523 293 280 524 minecraft:white_wool
fill 288 279 525 288 280 526 minecraft:light_blue_wool
fill 288 279 527 294 280 528 minecraft:white_wool
fill 288 279 539 294 280 539 minecraft:white_wool
fill 288 279 540 288 280 541 minecraft:light_blue_wool
fill 288 279 542 293 280 543 minecraft:white_wool
fill 289 279 525 293 280 526 minecraft:white_wool
fill 289 279 540 293 280 541 minecraft:white_wool
fill 294 279 523 294 280 523 minecraft:white_wool
fill 294 279 524 300 280 526 minecraft:light_blue_wool
fill 294 279 540 300 280 542 minecraft:light_blue_wool
fill 294 279 543 294 280 543 minecraft:white_wool
fill 295 279 511 299 280 512 minecraft:light_blue_wool
fill 295 279 523 300 280 523 minecraft:light_blue_wool
fill 295 279 527 299 279 528 minecraft:light_blue_wool
fill 295 279 538 299 280 539 minecraft:light_blue_wool
fill 295 279 543 300 280 543 minecraft:light_blue_wool
fill 296 279 513 298 280 513 minecraft:light_blue_wool
fill 296 279 522 299 280 522 minecraft:light_blue_wool
fill 296 279 529 298 279 529 minecraft:light_blue_wool
fill 296 279 537 298 280 537 minecraft:light_blue_wool
fill 296 279 544 299 280 544 minecraft:light_blue_wool
fill 297 279 521 298 280 521 minecraft:light_blue_wool
fill 297 279 545 298 280 545 minecraft:light_blue_wool
fill 299 279 513 307 280 513 minecraft:white_wool
fill 299 279 521 308 280 521 minecraft:white_wool
setblock 299 279 529 minecraft:white_wool
fill 299 279 531 299 279 537 minecraft:white_wool
fill 299 279 545 308 280 545 minecraft:white_wool
fill 300 279 511 300 280 511 minecraft:light_blue_wool
fill 300 279 512 307 280 512 minecraft:white_wool
fill 300 279 522 307 280 522 minecraft:white_wool
setblock 300 279 527 minecraft:light_blue_wool
setblock 300 279 528 minecraft:white_wool
fill 300 279 532 300 279 538 minecraft:white_wool
fill 300 279 539 300 280 539 minecraft:light_blue_wool
fill 300 279 544 307 280 544 minecraft:white_wool
fill 301 279 511 306 280 511 minecraft:white_wool
fill 301 279 523 306 279 527 minecraft:white_wool
fill 301 279 533 306 279 543 minecraft:white_wool
fill 302 279 528 307 279 528 minecraft:white_wool
fill 302 279 532 323 279 532 minecraft:white_wool
fill 303 279 529 308 279 529 minecraft:white_wool
fill 303 279 531 323 279 531 minecraft:white_wool
fill 304 279 530 323 279 530 minecraft:white_wool
fill 307 279 511 312 280 511 minecraft:light_blue_wool
fill 307 279 523 312 280 527 minecraft:light_blue_wool
fill 307 279 533 307 280 538 minecraft:white_wool
fill 307 279 539 312 280 543 minecraft:light_blue_wool
fill 308 279 512 311 280 513 minecraft:light_blue_wool
fill 308 279 522 311 280 522 minecraft:light_blue_wool
fill 308 279 528 312 280 528 minecraft:light_blue_wool
fill 308 279 533 308 280 537 minecraft:white_wool
fill 308 279 538 312 280 538 minecraft:light_blue_wool
fill 308 279 544 311 280 544 minecraft:light_blue_wool
fill 309 279 521 310 280 521 minecraft:light_blue_wool
fill 309 279 529 311 280 529 minecraft:light_blue_wool
fill 309 279 533 323 280 536 minecraft:white_wool
fill 309 279 537 311 280 537 minecraft:light_blue_wool
fill 309 279 545 310 280 545 minecraft:light_blue_wool
fill 311 279 521 321 280 521 minecraft:white_wool
fill 311 279 545 321 280 545 minecraft:white_wool
fill 312 279 512 312 280 512 minecraft:light_blue_wool
fill 312 279 513 320 280 513 minecraft:white_wool
fill 312 279 522 320 280 522 minecraft:white_wool
fill 312 279 529 320 280 529 minecraft:white_wool
fill 312 279 537 321 280 537 minecraft:white_wool
fill 312 279 544 320 280 544 minecraft:white_wool
fill 313 279 511 319 280 512 minecraft:white_wool
fill 313 279 523 319 280 523 minecraft:white_wool
fill 313 279 524 313 280 526 minecraft:light_blue_wool
fill 313 279 527 319 280 528 minecraft:white_wool
fill 313 279 538 319 280 539 minecraft:white_wool
fill 313 279 540 313 280 542 minecraft:light_blue_wool
fill 313 279 543 319 280 543 minecraft:white_wool
fill 314 279 524 318 280 526 minecraft:white_wool
fill 314 279 540 318 280 542 minecraft:white_wool
fill 319 279 524 319 280 524 minecraft:white_wool
fill 319 279 525 323 280 526 minecraft:light_blue_wool
fill 319 279 540 323 280 542 minecraft:light_blue_wool
fill 320 279 511 323 280 512 minecraft:light_blue_wool
fill 320 279 523 323 280 524 minecraft:light_blue_wool
fill 320 279 527 323 280 528 minecraft:light_blue_wool
fill 320 279 538 320 280 538 minecraft:white_wool
fill 320 279 539 323 280 539 minecraft:light_blue_wool
fill 320 279 543 323 280 543 minecraft:light_blue_wool
fill 321 279 513 323 280 513 minecraft:light_blue_wool
fill 321 279 522 323 280 522 minecraft:light_blue_wool
fill 321 279 529 323 280 529 minecraft:light_blue_wool
fill 321 279 538 323 280 538 minecraft:light_blue_wool
fill 321 279 544 323 280 544 minecraft:light_blue_wool
fill 322 279 521 323 280 521 minecraft:light_blue_wool
fill 322 279 537 323 280 537 minecraft:light_blue_wool
fill 322 279 545 323 280 545 minecraft:light_blue_wool
fill 284 280 530 297 280 536 minecraft:white_wool
fill 295 280 527 298 280 528 minecraft:light_blue_wool
fill 296 280 529 297 280 529 minecraft:light_blue_wool
fill 298 280 529 298 280 531 minecraft:pearlescent_froglight
fill 298 280 532 298 280 536 minecraft:white_wool
setblock 299 280 527 minecraft:light_blue_wool
fill 299 280 528 299 280 529 minecraft:pearlescent_froglight
fill 299 280 531 299 280 532 minecraft:pearlescent_froglight
fill 299 280 533 299 280 537 minecraft:white_wool
fill 300 280 527 300 280 528 minecraft:pearlescent_froglight
fill 300 280 532 300 280 533 minecraft:pearlescent_froglight
fill 300 280 534 306 280 538 minecraft:white_wool
fill 301 280 523 306 280 526 minecraft:white_wool
fill 301 280 527 302 280 527 minecraft:pearlescent_froglight
fill 301 280 533 302 280 533 minecraft:pearlescent_froglight
fill 301 280 539 306 280 543 minecraft:white_wool
fill 302 280 528 303 280 528 minecraft:pearlescent_froglight
fill 302 280 532 303 280 532 minecraft:pearlescent_froglight
fill 303 280 527 306 280 527 minecraft:white_wool
fill 303 280 529 304 280 529 minecraft:pearlescent_froglight
fill 303 280 531 304 280 531 minecraft:pearlescent_froglight
fill 303 280 533 306 280 533 minecraft:white_wool
fill 304 280 528 307 280 528 minecraft:white_wool
setblock 304 280 530 minecraft:pearlescent_froglight
fill 304 280 532 323 280 532 minecraft:white_wool
fill 305 280 529 308 280 531 minecraft:white_wool
fill 309 280 530 323 280 531 minecraft:white_wool
fill 283 284 511 285 300 511 minecraft:quartz_block
fill 283 284 521 283 300 523 minecraft:quartz_block
fill 283 284 533 283 300 535 minecraft:quartz_block
fill 283 284 545 283 300 547 minecraft:quartz_block
fill 284 284 520 284 285 522 minecraft:quartz_block
fill 284 284 532 284 285 534 minecraft:quartz_block
fill 284 284 544 284 285 546 minecraft:quartz_block
fill 285 284 546 285 284 547 minecraft:smooth_quartz
fill 286 284 544 288 284 544 minecraft:smooth_quartz
fill 286 284 545 288 300 547 minecraft:quartz_block
fill 286 284 548 289 284 548 minecraft:smooth_quartz
setblock 289 284 545 minecraft:smooth_quartz
fill 289 284 546 289 300 546 minecraft:quartz_block
setblock 289 284 547 minecraft:smooth_quartz
fill 289 284 551 291 300 551 minecraft:quartz_block
fill 290 284 550 292 285 550 minecraft:quartz_block
fill 292 284 544 293 284 545 minecraft:white_concrete
fill 294 284 512 296 285 512 minecraft:quartz_block
fill 295 284 511 297 300 511 minecraft:quartz_block
fill 301 284 551 303 300 551 minecraft:quartz_block
fill 302 284 550 304 285 550 minecraft:quartz_block
fill 306 284 512 308 285 512 minecraft:quartz_block
fill 307 284 511 309 300 511 minecraft:quartz_block
fill 313 284 551 315 300 551 minecraft:quartz_block
fill 314 284 550 316 285 550 minecraft:quartz_block
fill 318 284 512 320 285 512 minecraft:quartz_block
setblock 318 284 513 minecraft:smooth_quartz
fill 318 284 514 321 300 514 minecraft:quartz_block
setblock 318 284 515 minecraft:smooth_quartz
fill 319 284 511 321 300 511 minecraft:quartz_block
fill 319 284 513 321 300 513 minecraft:quartz_block
fill 319 284 515 321 300 515 minecraft:quartz_block
fill 319 284 516 321 284 516 minecraft:smooth_quartz
setblock 321 284 512 minecraft:smooth_quartz
fill 322 284 513 322 284 515 minecraft:smooth_quartz
fill 322 284 520 322 285 522 minecraft:quartz_block
fill 322 284 532 322 285 534 minecraft:quartz_block
fill 322 284 544 322 285 546 minecraft:quartz_block
fill 323 284 519 323 300 521 minecraft:quartz_block
fill 323 284 531 323 300 533 minecraft:quartz_block
fill 323 284 543 323 300 545 minecraft:quartz_block
fill 283 285 514 283 285 519 minecraft:smooth_quartz
fill 283 285 526 283 285 531 minecraft:smooth_quartz
fill 283 285 538 283 285 543 minecraft:smooth_quartz
fill 283 285 550 283 285 551 minecraft:smooth_quartz
fill 284 285 551 287 285 551 minecraft:smooth_quartz
fill 287 285 511 292 285 511 minecraft:smooth_quartz
fill 294 285 551 299 285 551 minecraft:smooth_quartz
fill 299 285 511 304 285 511 minecraft:smooth_quartz
fill 306 285 551 311 285 551 minecraft:smooth_quartz
fill 311 285 511 316 285 511 minecraft:smooth_quartz
fill 318 285 551 323 285 551 minecraft:smooth_quartz
fill 323 285 511 323 285 516 minecraft:smooth_quartz
fill 323 285 523 323 285 528 minecraft:smooth_quartz
fill 323 285 535 323 285 540 minecraft:smooth_quartz
fill 323 285 547 323 285 550 minecraft:smooth_quartz
fill 282 286 516 282 291 519 minecraft:pearlescent_froglight
fill 282 286 528 282 291 531 minecraft:pearlescent_froglight
fill 282 286 540 282 291 543 minecraft:pearlescent_froglight
fill 282 286 552 285 291 552 minecraft:pearlescent_froglight
fill 289 286 510 292 291 510 minecraft:pearlescent_froglight
fill 294 286 552 297 291 552 minecraft:pearlescent_froglight
fill 301 286 510 304 291 510 minecraft:pearlescent_froglight
fill 306 286 552 309 291 552 minecraft:pearlescent_froglight
fill 313 286 510 316 291 510 minecraft:pearlescent_froglight
fill 318 286 552 321 291 552 minecraft:pearlescent_froglight
fill 324 286 511 324 291 514 minecraft:pearlescent_froglight
fill 324 286 523 324 291 526 minecraft:pearlescent_froglight
fill 324 286 535 324 291 538 minecraft:pearlescent_froglight
fill 324 286 547 324 291 550 minecraft:pearlescent_froglight
setblock 285 287 513 minecraft:light[level=14]
setblock 285 287 521 minecraft:light[level=14]
setblock 285 287 529 minecraft:light[level=14]
setblock 285 287 537 minecraft:light[level=14]
setblock 285 287 545 minecraft:light[level=14]
setblock 293 287 513 minecraft:light[level=14]
setblock 293 287 521 minecraft:light[level=14]
setblock 293 287 529 minecraft:light[level=14]
setblock 293 287 537 minecraft:light[level=14]
setblock 293 287 545 minecraft:light[level=14]
setblock 301 287 513 minecraft:light[level=14]
setblock 301 287 521 minecraft:light[level=14]
setblock 301 287 537 minecraft:light[level=14]
setblock 301 287 545 minecraft:light[level=14]
setblock 309 287 513 minecraft:light[level=14]
setblock 309 287 521 minecraft:light[level=14]
setblock 309 287 529 minecraft:light[level=14]
setblock 309 287 537 minecraft:light[level=14]
setblock 309 287 545 minecraft:light[level=14]
setblock 317 287 513 minecraft:light[level=14]
setblock 317 287 521 minecraft:light[level=14]
setblock 317 287 529 minecraft:light[level=14]
setblock 317 287 537 minecraft:light[level=14]
setblock 317 287 545 minecraft:light[level=14]
fill 282 292 516 282 307 516 minecraft:light_blue_concrete
fill 282 292 517 282 292 518 minecraft:pearlescent_froglight
fill 282 292 519 282 307 519 minecraft:light_blue_concrete
fill 282 292 528 282 307 528 minecraft:light_blue_concrete
fill 282 292 529 282 292 530 minecraft:pearlescent_froglight
fill 282 292 531 282 307 531 minecraft:light_blue_concrete
fill 282 292 540 282 307 540 minecraft:light_blue_concrete
fill 282 292 541 282 292 542 minecraft:pearlescent_froglight
fill 282 292 543 282 307 543 minecraft:light_blue_concrete
fill 282 292 552 282 307 552 minecraft:light_blue_concrete
fill 283 292 552 284 292 552 minecraft:pearlescent_froglight
fill 285 292 546 285 292 547 minecraft:smooth_quartz
fill 285 292 552 285 307 552 minecraft:light_blue_concrete
fill 286 292 544 288 292 544 minecraft:smooth_quartz
fill 286 292 548 289 292 548 minecraft:smooth_quartz
fill 289 292 510 289 307 510 minecraft:light_blue_concrete
setblock 289 292 545 minecraft:smooth_quartz
setblock 289 292 547 minecraft:smooth_quartz
fill 290 292 510 291 292 510 minecraft:pearlescent_froglight
fill 292 292 510 292 307 510 minecraft:light_blue_concrete
fill 294 292 552 294 307 552 minecraft:light_blue_concrete
fill 295 292 552 296 292 552 minecraft:pearlescent_froglight
fill 297 292 552 297 307 552 minecraft:light_blue_concrete
fill 301 292 510 301 307 510 minecraft:light_blue_concrete
fill 302 292 510 303 292 510 minecraft:pearlescent_froglight
fill 304 292 510 304 307 510 minecraft:light_blue_concrete
fill 306 292 552 306 307 552 minecraft:light_blue_concrete
fill 307 292 552 308 292 552 minecraft:pearlescent_froglight
fill 309 292 552 309 307 552 minecraft:light_blue_concrete
fill 313 292 510 313 307 510 minecraft:light_blue_concrete
fill 314 292 510 315 292 510 minecraft:pearlescent_froglight
fill 316 292 510 316 307 510 minecraft:light_blue_concrete
setblock 318 292 513 minecraft:smooth_quartz
setblock 318 292 515 minecraft:smooth_quartz
fill 318 292 552 318 307 552 minecraft:light_blue_concrete
fill 319 292 512 321 292 512 minecraft:smooth_quartz
fill 319 292 516 321 292 516 minecraft:smooth_quartz
fill 319 292 552 320 292 552 minecraft:pearlescent_froglight
fill 321 292 552 321 307 552 minecraft:light_blue_concrete
fill 322 292 513 322 292 515 minecraft:smooth_quartz
fill 324 292 511 324 307 511 minecraft:light_blue_concrete
fill 324 292 512 324 292 513 minecraft:pearlescent_froglight
fill 324 292 514 324 307 514 minecraft:light_blue_concrete
fill 324 292 523 324 307 523 minecraft:light_blue_concrete
fill 324 292 524 324 292 525 minecraft:pearlescent_froglight
fill 324 292 526 324 307 526 minecraft:light_blue_concrete
fill 324 292 535 324 307 535 minecraft:light_blue_concrete
fill 324 292 536 324 292 537 minecraft:pearlescent_froglight
fill 324 292 538 324 307 538 minecraft:light_blue_concrete
fill 324 292 547 324 307 547 minecraft:light_blue_concrete
fill 324 292 548 324 292 549 minecraft:pearlescent_froglight
fill 324 292 550 324 307 550 minecraft:light_blue_concrete
fill 282 293 517 282 307 518 minecraft:light_blue_concrete
fill 282 293 529 282 307 530 minecraft:light_blue_concrete
fill 282 293 541 282 307 542 minecraft:light_blue_concrete
fill 283 293 552 284 307 552 minecraft:light_blue_concrete
fill 290 293 510 291 307 510 minecraft:light_blue_concrete
fill 295 293 552 296 307 552 minecraft:light_blue_concrete
fill 302 293 510 303 307 510 minecraft:light_blue_concrete
fill 307 293 552 308 307 552 minecraft:light_blue_concrete
fill 314 293 510 315 307 510 minecraft:light_blue_concrete
fill 319 293 552 320 307 552 minecraft:light_blue_concrete
fill 324 293 512 324 307 513 minecraft:light_blue_concrete
fill 324 293 524 324 307 525 minecraft:light_blue_concrete
fill 324 293 536 324 307 537 minecraft:light_blue_concrete
fill 324 293 548 324 307 549 minecraft:light_blue_concrete
fill 316 294 529 318 295 529 minecraft:white_concrete
fill 317 294 528 317 295 528 minecraft:white_concrete
fill 317 294 530 317 295 530 minecraft:white_concrete
setblock 285 295 513 minecraft:light[level=14]
setblock 285 295 521 minecraft:light[level=14]
setblock 285 295 529 minecraft:light[level=14]
setblock 285 295 537 minecraft:light[level=14]
setblock 285 295 545 minecraft:light[level=14]
setblock 293 295 513 minecraft:light[level=14]
setblock 293 295 521 minecraft:light[level=14]
setblock 293 295 529 minecraft:light[level=14]
setblock 293 295 537 minecraft:light[level=14]
setblock 293 295 545 minecraft:light[level=14]
setblock 301 295 513 minecraft:light[level=14]
setblock 301 295 521 minecraft:light[level=14]
setblock 301 295 529 minecraft:light[level=14]
setblock 301 295 537 minecraft:light[level=14]
setblock 301 295 545 minecraft:light[level=14]
setblock 309 295 513 minecraft:light[level=14]
setblock 309 295 521 minecraft:light[level=14]
setblock 309 295 529 minecraft:light[level=14]
setblock 309 295 537 minecraft:light[level=14]
setblock 309 295 545 minecraft:light[level=14]
setblock 317 295 513 minecraft:light[level=14]
setblock 317 295 521 minecraft:light[level=14]
setblock 317 295 537 minecraft:light[level=14]
setblock 317 295 545 minecraft:light[level=14]
fill 285 299 546 285 300 546 minecraft:gold_block
fill 286 299 548 288 300 548 minecraft:gold_block
fill 287 299 544 288 300 544 minecraft:gold_block
fill 289 299 545 289 300 545 minecraft:gold_block
fill 289 299 547 289 300 547 minecraft:gold_block
fill 318 299 513 318 300 513 minecraft:gold_block
fill 318 299 515 318 300 515 minecraft:gold_block
fill 319 299 512 321 299 512 minecraft:gold_block
fill 319 299 516 321 300 516 minecraft:gold_block
fill 322 299 514 322 300 514 minecraft:gold_block
fill 284 300 520 284 300 522 minecraft:quartz_block
fill 284 300 532 284 300 534 minecraft:quartz_block
fill 284 300 544 284 300 546 minecraft:quartz_block
fill 290 300 550 292 300 550 minecraft:quartz_block
fill 294 300 512 296 300 512 minecraft:quartz_block
fill 302 300 550 304 300 550 minecraft:quartz_block
fill 306 300 512 308 300 512 minecraft:quartz_block
fill 314 300 550 316 300 550 minecraft:quartz_block
fill 318 300 512 320 300 512 minecraft:quartz_block
setblock 321 300 512 minecraft:gold_block
fill 322 300 520 322 300 522 minecraft:quartz_block
fill 322 300 532 322 300 534 minecraft:quartz_block
fill 322 300 544 322 300 546 minecraft:quartz_block
setblock 285 303 513 minecraft:light[level=14]
setblock 285 303 521 minecraft:light[level=14]
setblock 285 303 529 minecraft:light[level=14]
setblock 285 303 537 minecraft:light[level=14]
setblock 285 303 545 minecraft:light[level=14]
setblock 293 303 513 minecraft:light[level=14]
setblock 293 303 521 minecraft:light[level=14]
setblock 293 303 529 minecraft:light[level=14]
setblock 293 303 537 minecraft:light[level=14]
setblock 293 303 545 minecraft:light[level=14]
setblock 301 303 513 minecraft:light[level=14]
setblock 301 303 521 minecraft:light[level=14]
setblock 301 303 529 minecraft:light[level=14]
setblock 301 303 537 minecraft:light[level=14]
setblock 301 303 545 minecraft:light[level=14]
setblock 309 303 513 minecraft:light[level=14]
setblock 309 303 521 minecraft:light[level=14]
setblock 309 303 529 minecraft:light[level=14]
setblock 309 303 537 minecraft:light[level=14]
setblock 309 303 545 minecraft:light[level=14]
setblock 317 303 513 minecraft:light[level=14]
setblock 317 303 521 minecraft:light[level=14]
setblock 317 303 529 minecraft:light[level=14]
setblock 317 303 537 minecraft:light[level=14]
setblock 317 303 545 minecraft:light[level=14]
