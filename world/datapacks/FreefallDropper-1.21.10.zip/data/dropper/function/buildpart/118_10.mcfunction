fill 509 264 480 509 266 480 minecraft:red_terracotta
setblock 509 264 484 minecraft:terracotta
setblock 509 264 503 minecraft:red_terracotta
setblock 509 264 504 minecraft:terracotta
fill 510 264 464 510 267 464 minecraft:red_terracotta
fill 510 264 466 511 264 466 minecraft:red_terracotta
fill 510 264 474 510 273 474 minecraft:shroomlight
setblock 510 264 478 minecraft:terracotta
fill 510 264 479 510 267 479 minecraft:red_terracotta
setblock 510 264 483 minecraft:terracotta
fill 510 264 484 510 267 484 minecraft:red_terracotta
fill 510 264 504 510 267 504 minecraft:red_terracotta
setblock 511 264 467 minecraft:terracotta
fill 511 264 468 511 267 468 minecraft:red_terracotta
setblock 511 264 472 minecraft:terracotta
fill 511 264 473 511 267 473 minecraft:red_terracotta
setblock 511 264 477 minecraft:terracotta
fill 511 264 478 511 267 478 minecraft:red_terracotta
setblock 511 264 482 minecraft:terracotta
fill 511 264 483 511 267 483 minecraft:red_terracotta
setblock 511 264 487 minecraft:terracotta
setblock 511 264 502 minecraft:terracotta
fill 511 264 503 511 267 503 minecraft:red_terracotta
setblock 471 265 466 minecraft:terracotta
fill 471 265 467 471 268 467 minecraft:red_terracotta
setblock 471 265 481 minecraft:terracotta
fill 471 265 482 471 267 482 minecraft:red_terracotta
setblock 471 265 501 minecraft:terracotta
fill 471 265 502 471 266 504 minecraft:red_terracotta
setblock 472 265 465 minecraft:terracotta
fill 472 265 466 472 268 466 minecraft:red_terracotta
fill 472 265 503 472 265 504 minecraft:red_terracotta
setblock 473 265 464 minecraft:terracotta
fill 473 265 465 476 265 465 minecraft:red_terracotta
setblock 473 265 503 minecraft:red_terracotta
setblock 473 265 504 minecraft:terracotta
fill 474 265 464 474 268 464 minecraft:red_terracotta
setblock 474 265 503 minecraft:terracotta
fill 474 265 504 477 265 504 minecraft:red_terracotta
fill 475 265 503 475 268 503 minecraft:red_terracotta
setblock 477 265 465 minecraft:terracotta
fill 477 265 502 477 267 502 minecraft:red_terracotta
setblock 478 265 464 minecraft:terracotta
fill 478 265 465 481 265 465 minecraft:red_terracotta
setblock 478 265 504 minecraft:terracotta
fill 479 265 464 479 268 464 minecraft:red_terracotta
setblock 479 265 503 minecraft:terracotta
fill 479 265 504 479 268 504 minecraft:red_terracotta
setblock 480 265 501 minecraft:red_terracotta
setblock 480 265 502 minecraft:terracotta
fill 480 265 503 480 268 503 minecraft:red_terracotta
setblock 481 265 501 minecraft:terracotta
fill 481 265 502 481 268 502 minecraft:red_terracotta
setblock 482 265 465 minecraft:terracotta
fill 482 265 501 482 268 501 minecraft:red_terracotta
setblock 483 265 464 minecraft:terracotta
fill 483 265 465 483 268 465 minecraft:red_terracotta
setblock 483 265 504 minecraft:terracotta
fill 484 265 464 484 268 464 minecraft:red_terracotta
setblock 484 265 503 minecraft:terracotta
fill 484 265 504 484 268 504 minecraft:red_terracotta
setblock 485 265 502 minecraft:terracotta
fill 485 265 503 485 268 503 minecraft:red_terracotta
setblock 486 265 501 minecraft:terracotta
fill 486 265 502 486 268 502 minecraft:red_terracotta
setblock 487 265 465 minecraft:terracotta
setblock 487 265 501 minecraft:red_terracotta
setblock 488 265 464 minecraft:terracotta
setblock 488 265 504 minecraft:terracotta
fill 489 265 464 489 268 464 minecraft:red_terracotta
setblock 489 265 503 minecraft:terracotta
fill 489 265 504 489 268 504 minecraft:red_terracotta
fill 490 265 503 490 267 503 minecraft:red_terracotta
setblock 493 265 504 minecraft:terracotta
fill 494 265 504 497 265 504 minecraft:red_terracotta
setblock 497 265 464 minecraft:red_terracotta
setblock 498 265 464 minecraft:terracotta
setblock 498 265 504 minecraft:terracotta
fill 499 265 464 499 268 464 minecraft:red_terracotta
setblock 499 265 503 minecraft:terracotta
fill 499 265 504 499 268 504 minecraft:red_terracotta
fill 500 265 465 501 265 465 minecraft:red_terracotta
fill 500 265 503 503 265 503 minecraft:red_terracotta
setblock 502 265 464 minecraft:red_terracotta
setblock 502 265 465 minecraft:terracotta
setblock 503 265 464 minecraft:terracotta
fill 503 265 465 506 265 465 minecraft:red_terracotta
setblock 503 265 504 minecraft:terracotta
fill 504 265 464 504 268 464 minecraft:red_terracotta
fill 504 265 466 505 265 466 minecraft:red_terracotta
setblock 504 265 503 minecraft:terracotta
fill 504 265 504 504 268 504 minecraft:red_terracotta
fill 505 265 503 505 268 503 minecraft:red_terracotta
setblock 506 265 466 minecraft:terracotta
setblock 507 265 465 minecraft:terracotta
fill 507 265 466 507 268 466 minecraft:red_terracotta
setblock 508 265 464 minecraft:terracotta
fill 508 265 465 508 268 465 minecraft:red_terracotta
setblock 508 265 504 minecraft:terracotta
fill 509 265 464 509 268 464 minecraft:red_terracotta
setblock 509 265 478 minecraft:terracotta
fill 509 265 479 509 266 479 minecraft:red_terracotta
setblock 509 265 483 minecraft:terracotta
fill 509 265 484 509 266 484 minecraft:red_terracotta
setblock 509 265 503 minecraft:terracotta
fill 509 265 504 509 268 504 minecraft:red_terracotta
setblock 510 265 466 minecraft:red_terracotta
setblock 510 265 467 minecraft:terracotta
fill 510 265 468 510 268 468 minecraft:red_terracotta
setblock 510 265 477 minecraft:terracotta
fill 510 265 478 510 267 478 minecraft:red_terracotta
setblock 510 265 482 minecraft:terracotta
fill 510 265 483 510 268 483 minecraft:red_terracotta
setblock 510 265 486 minecraft:red_terracotta
setblock 511 265 466 minecraft:terracotta
fill 511 265 467 511 268 467 minecraft:red_terracotta
setblock 511 265 471 minecraft:terracotta
fill 511 265 472 511 268 472 minecraft:red_terracotta
setblock 511 265 476 minecraft:terracotta
fill 511 265 477 511 268 477 minecraft:red_terracotta
setblock 511 265 481 minecraft:terracotta
fill 511 265 482 511 268 482 minecraft:red_terracotta
setblock 511 265 486 minecraft:terracotta
fill 511 265 487 511 268 487 minecraft:red_terracotta
setblock 511 265 501 minecraft:terracotta
fill 511 265 502 511 267 502 minecraft:red_terracotta
setblock 471 266 465 minecraft:terracotta
fill 471 266 466 471 269 466 minecraft:red_terracotta
setblock 471 266 470 minecraft:terracotta
setblock 471 266 480 minecraft:terracotta
setblock 471 266 481 minecraft:red_terracotta
setblock 471 266 485 minecraft:terracotta
setblock 471 266 500 minecraft:terracotta
fill 471 266 501 471 269 501 minecraft:red_terracotta
setblock 472 266 464 minecraft:terracotta
fill 472 266 465 475 266 465 minecraft:red_terracotta
setblock 472 266 503 minecraft:red_terracotta
setblock 472 266 504 minecraft:terracotta
fill 473 266 464 473 269 464 minecraft:red_terracotta
setblock 473 266 503 minecraft:terracotta
fill 473 266 504 476 266 504 minecraft:red_terracotta
fill 474 266 503 474 269 503 minecraft:red_terracotta
setblock 476 266 465 minecraft:terracotta
fill 476 266 502 476 268 502 minecraft:red_terracotta
setblock 477 266 464 minecraft:terracotta
fill 477 266 465 480 266 465 minecraft:red_terracotta
setblock 477 266 504 minecraft:terracotta
fill 478 266 464 478 269 464 minecraft:red_terracotta
setblock 478 266 503 minecraft:terracotta
fill 478 266 504 478 269 504 minecraft:red_terracotta
setblock 479 266 502 minecraft:terracotta
fill 479 266 503 479 269 503 minecraft:red_terracotta
setblock 480 266 466 minecraft:terracotta
setblock 480 266 501 minecraft:terracotta
fill 480 266 502 480 269 502 minecraft:red_terracotta
setblock 481 266 465 minecraft:terracotta
fill 481 266 466 483 267 466 minecraft:red_terracotta
fill 481 266 501 481 268 501 minecraft:red_terracotta
setblock 482 266 464 minecraft:terracotta
fill 482 266 465 482 269 465 minecraft:red_terracotta
setblock 482 266 504 minecraft:terracotta
fill 483 266 464 483 269 464 minecraft:red_terracotta
setblock 483 266 503 minecraft:terracotta
fill 483 266 504 483 269 504 minecraft:red_terracotta
setblock 484 266 502 minecraft:terracotta
fill 484 266 503 484 269 503 minecraft:red_terracotta
setblock 485 266 465 minecraft:red_terracotta
setblock 485 266 501 minecraft:terracotta
fill 485 266 502 485 269 502 minecraft:red_terracotta
setblock 486 266 465 minecraft:terracotta
setblock 486 266 501 minecraft:red_terracotta
setblock 487 266 464 minecraft:terracotta
fill 487 266 465 487 268 465 minecraft:red_terracotta
setblock 487 266 504 minecraft:terracotta
fill 488 266 464 488 269 464 minecraft:red_terracotta
setblock 488 266 503 minecraft:terracotta
fill 488 266 504 488 269 504 minecraft:red_terracotta
fill 489 266 503 489 268 503 minecraft:red_terracotta
setblock 491 266 464 minecraft:red_terracotta
setblock 492 266 504 minecraft:terracotta
fill 493 266 504 496 266 504 minecraft:red_terracotta
setblock 496 266 464 minecraft:red_terracotta
setblock 497 266 464 minecraft:terracotta
setblock 497 266 504 minecraft:terracotta
fill 498 266 464 498 269 464 minecraft:red_terracotta
setblock 498 266 503 minecraft:terracotta
fill 498 266 504 498 269 504 minecraft:red_terracotta
fill 499 266 465 500 266 465 minecraft:red_terracotta
fill 499 266 503 502 266 503 minecraft:red_terracotta
setblock 501 266 465 minecraft:terracotta
setblock 502 266 464 minecraft:terracotta
fill 502 266 465 504 266 466 minecraft:red_terracotta
setblock 502 266 504 minecraft:terracotta
fill 503 266 464 503 269 464 minecraft:red_terracotta
setblock 503 266 503 minecraft:terracotta
fill 503 266 504 503 269 504 minecraft:red_terracotta
fill 504 266 503 504 269 503 minecraft:red_terracotta
setblock 505 266 465 minecraft:red_terracotta
setblock 505 266 466 minecraft:terracotta
setblock 506 266 465 minecraft:terracotta
fill 506 266 466 506 269 466 minecraft:red_terracotta
setblock 507 266 464 minecraft:terracotta
fill 507 266 465 507 269 465 minecraft:red_terracotta
setblock 507 266 504 minecraft:terracotta
fill 508 266 464 508 269 464 minecraft:red_terracotta
fill 508 266 466 508 267 466 minecraft:red_terracotta
setblock 508 266 503 minecraft:terracotta
fill 508 266 504 508 269 504 minecraft:red_terracotta
fill 509 266 465 510 266 465 minecraft:red_terracotta
setblock 509 266 482 minecraft:terracotta
fill 509 266 483 509 267 483 minecraft:red_terracotta
setblock 509 266 503 minecraft:red_terracotta
setblock 510 266 466 minecraft:terracotta
fill 510 266 467 510 269 467 minecraft:red_terracotta
fill 510 266 469 510 267 469 minecraft:red_terracotta
fill 510 266 475 510 273 475 minecraft:magma_block
setblock 510 266 477 minecraft:red_terracotta
setblock 510 266 481 minecraft:terracotta
fill 510 266 482 510 268 482 minecraft:red_terracotta
setblock 510 266 486 minecraft:terracotta
setblock 511 266 465 minecraft:terracotta
fill 511 266 466 511 269 466 minecraft:red_terracotta
setblock 511 266 470 minecraft:terracotta
fill 511 266 471 511 269 471 minecraft:red_terracotta
setblock 511 266 475 minecraft:terracotta
fill 511 266 476 511 267 476 minecraft:red_terracotta
setblock 511 266 480 minecraft:terracotta
fill 511 266 481 511 269 481 minecraft:red_terracotta
setblock 511 266 485 minecraft:terracotta
fill 511 266 486 511 269 486 minecraft:red_terracotta
setblock 471 267 464 minecraft:terracotta
fill 471 267 465 474 267 465 minecraft:red_terracotta
setblock 471 267 468 minecraft:red_terracotta
setblock 471 267 469 minecraft:terracotta
fill 471 267 470 471 269 470 minecraft:red_terracotta
setblock 471 267 483 minecraft:red_terracotta
setblock 471 267 484 minecraft:terracotta
fill 471 267 485 471 268 485 minecraft:red_terracotta
fill 471 267 500 471 268 500 minecraft:red_terracotta
fill 471 267 502 471 267 503 minecraft:red_terracotta
setblock 471 267 504 minecraft:terracotta
fill 472 267 464 472 270 464 minecraft:red_terracotta
setblock 472 267 467 minecraft:red_terracotta
setblock 472 267 503 minecraft:terracotta
fill 472 267 504 475 267 504 minecraft:red_terracotta
fill 473 267 503 473 270 503 minecraft:red_terracotta
setblock 475 267 465 minecraft:terracotta
setblock 476 267 464 minecraft:terracotta
fill 476 267 465 479 267 465 minecraft:red_terracotta
setblock 476 267 504 minecraft:terracotta
fill 477 267 464 477 270 464 minecraft:red_terracotta
setblock 477 267 503 minecraft:terracotta
fill 477 267 504 477 270 504 minecraft:red_terracotta
setblock 478 267 466 minecraft:red_terracotta
setblock 478 267 502 minecraft:terracotta
fill 478 267 503 478 270 503 minecraft:red_terracotta
setblock 479 267 466 minecraft:terracotta
fill 479 267 502 479 270 502 minecraft:red_terracotta
setblock 480 267 465 minecraft:terracotta
fill 480 267 466 480 270 466 minecraft:red_terracotta
fill 480 267 501 480 268 501 minecraft:red_terracotta
setblock 481 267 464 minecraft:terracotta
fill 481 267 465 481 270 465 minecraft:red_terracotta
setblock 481 267 504 minecraft:terracotta
fill 482 267 464 482 270 464 minecraft:red_terracotta
setblock 482 267 503 minecraft:terracotta
fill 482 267 504 482 270 504 minecraft:red_terracotta
setblock 483 267 502 minecraft:terracotta
fill 483 267 503 483 270 503 minecraft:red_terracotta
setblock 484 267 466 minecraft:terracotta
setblock 484 267 501 minecraft:terracotta
fill 484 267 502 484 269 502 minecraft:red_terracotta
setblock 485 267 465 minecraft:terracotta
setblock 485 267 501 minecraft:red_terracotta
setblock 486 267 464 minecraft:terracotta
fill 486 267 465 486 269 465 minecraft:red_terracotta
setblock 486 267 504 minecraft:terracotta
fill 487 267 464 487 270 464 minecraft:red_terracotta
setblock 487 267 503 minecraft:terracotta
fill 487 267 504 487 270 504 minecraft:red_terracotta
setblock 488 267 502 minecraft:terracotta
fill 488 267 503 488 269 503 minecraft:red_terracotta
setblock 491 267 464 minecraft:terracotta
setblock 491 267 504 minecraft:terracotta
fill 492 267 504 495 267 504 minecraft:red_terracotta
fill 494 267 464 495 267 464 minecraft:red_terracotta
setblock 496 267 464 minecraft:terracotta
setblock 496 267 504 minecraft:terracotta
fill 497 267 464 497 270 464 minecraft:red_terracotta
fill 497 267 504 497 270 504 minecraft:red_terracotta
fill 498 267 465 499 267 465 minecraft:red_terracotta
fill 498 267 503 501 267 503 minecraft:red_terracotta
setblock 500 267 465 minecraft:terracotta
setblock 501 267 464 minecraft:terracotta
fill 501 267 465 503 267 466 minecraft:red_terracotta
setblock 501 267 504 minecraft:terracotta
fill 502 267 464 502 270 464 minecraft:red_terracotta
setblock 502 267 503 minecraft:terracotta
fill 502 267 504 502 270 504 minecraft:red_terracotta
fill 503 267 503 503 269 503 minecraft:red_terracotta
setblock 504 267 465 minecraft:red_terracotta
setblock 504 267 466 minecraft:terracotta
setblock 505 267 465 minecraft:terracotta
fill 505 267 466 505 270 466 minecraft:red_terracotta
setblock 506 267 464 minecraft:terracotta
fill 506 267 465 506 270 465 minecraft:red_terracotta
setblock 506 267 504 minecraft:terracotta
fill 507 267 464 507 270 464 minecraft:red_terracotta
setblock 507 267 503 minecraft:terracotta
fill 507 267 504 507 270 504 minecraft:red_terracotta
setblock 508 267 503 minecraft:red_terracotta
setblock 509 267 465 minecraft:red_terracotta
setblock 509 267 466 minecraft:terracotta
setblock 509 267 482 minecraft:red_terracotta
setblock 510 267 465 minecraft:terracotta
fill 510 267 466 510 270 466 minecraft:red_terracotta
setblock 510 267 480 minecraft:terracotta
fill 510 267 481 510 268 481 minecraft:red_terracotta
setblock 510 267 485 minecraft:terracotta
setblock 510 267 486 minecraft:red_terracotta
setblock 511 267 464 minecraft:terracotta
fill 511 267 465 511 270 465 minecraft:red_terracotta
setblock 511 267 469 minecraft:terracotta
fill 511 267 470 511 270 470 minecraft:red_terracotta
setblock 511 267 474 minecraft:terracotta
setblock 511 267 475 minecraft:red_terracotta
setblock 511 267 479 minecraft:terracotta
fill 511 267 480 511 269 480 minecraft:red_terracotta
setblock 511 267 484 minecraft:terracotta
fill 511 267 485 511 270 485 minecraft:red_terracotta
setblock 511 267 504 minecraft:terracotta
fill 471 268 464 471 270 465 minecraft:red_terracotta
setblock 471 268 468 minecraft:terracotta
fill 471 268 469 471 271 469 minecraft:red_terracotta
setblock 471 268 484 minecraft:red_terracotta
setblock 471 268 502 minecraft:red_terracotta
setblock 471 268 503 minecraft:terracotta
fill 471 268 504 474 268 504 minecraft:red_terracotta
fill 472 268 465 473 268 465 minecraft:red_terracotta
setblock 472 268 467 minecraft:terracotta
fill 472 268 503 472 269 503 minecraft:red_terracotta
setblock 474 268 465 minecraft:terracotta
setblock 475 268 464 minecraft:terracotta
fill 475 268 465 478 268 465 minecraft:red_terracotta
setblock 475 268 504 minecraft:terracotta
fill 476 268 464 476 271 464 minecraft:red_terracotta
setblock 476 268 503 minecraft:terracotta
fill 476 268 504 476 271 504 minecraft:red_terracotta
setblock 477 268 466 minecraft:red_terracotta
setblock 477 268 502 minecraft:terracotta
fill 477 268 503 477 271 503 minecraft:red_terracotta
setblock 478 268 466 minecraft:terracotta
fill 478 268 502 478 271 502 minecraft:red_terracotta
setblock 479 268 465 minecraft:terracotta
fill 479 268 466 479 271 466 minecraft:red_terracotta
setblock 480 268 464 minecraft:terracotta
fill 480 268 465 480 271 465 minecraft:red_terracotta
setblock 480 268 504 minecraft:terracotta
fill 481 268 464 481 271 464 minecraft:red_terracotta
fill 481 268 466 482 268 466 minecraft:red_terracotta
setblock 481 268 503 minecraft:terracotta
fill 481 268 504 481 271 504 minecraft:red_terracotta
setblock 482 268 502 minecraft:terracotta
fill 482 268 503 482 271 503 minecraft:red_terracotta
setblock 483 268 466 minecraft:terracotta
setblock 483 268 501 minecraft:terracotta
fill 483 268 502 483 270 502 minecraft:red_terracotta
setblock 484 268 465 minecraft:terracotta
setblock 484 268 466 minecraft:red_terracotta
setblock 485 268 464 minecraft:terracotta
fill 485 268 465 485 270 465 minecraft:red_terracotta
setblock 485 268 504 minecraft:terracotta
fill 486 268 464 486 271 464 minecraft:red_terracotta
setblock 486 268 503 minecraft:terracotta
fill 486 268 504 486 271 504 minecraft:red_terracotta
fill 487 268 503 487 269 503 minecraft:red_terracotta
setblock 490 268 464 minecraft:terracotta
setblock 490 268 504 minecraft:terracotta
setblock 491 268 464 minecraft:red_terracotta
fill 491 268 504 494 268 504 minecraft:red_terracotta
fill 493 268 464 494 268 464 minecraft:red_terracotta
setblock 495 268 464 minecraft:terracotta
setblock 495 268 504 minecraft:terracotta
fill 496 268 464 496 271 464 minecraft:red_terracotta
fill 496 268 504 496 270 504 minecraft:red_terracotta
fill 497 268 465 498 268 465 minecraft:red_terracotta
fill 498 268 503 500 268 503 minecraft:red_terracotta
setblock 499 268 465 minecraft:terracotta
setblock 500 268 464 minecraft:terracotta
fill 500 268 465 502 268 466 minecraft:red_terracotta
setblock 500 268 504 minecraft:terracotta
fill 501 268 464 501 271 464 minecraft:red_terracotta
setblock 501 268 503 minecraft:terracotta
fill 501 268 504 501 271 504 minecraft:red_terracotta
fill 502 268 503 502 269 503 minecraft:red_terracotta
setblock 503 268 465 minecraft:red_terracotta
setblock 503 268 466 minecraft:terracotta
setblock 504 268 465 minecraft:terracotta
fill 504 268 466 504 271 466 minecraft:red_terracotta
setblock 505 268 464 minecraft:terracotta
fill 505 268 465 505 271 465 minecraft:red_terracotta
setblock 505 268 504 minecraft:terracotta
fill 506 268 464 506 271 464 minecraft:red_terracotta
setblock 506 268 503 minecraft:terracotta
fill 506 268 504 506 270 504 minecraft:red_terracotta
setblock 508 268 466 minecraft:terracotta
setblock 509 268 465 minecraft:terracotta
fill 509 268 466 509 269 466 minecraft:red_terracotta
setblock 510 268 464 minecraft:terracotta
fill 510 268 465 510 271 465 minecraft:red_terracotta
setblock 510 268 469 minecraft:terracotta
setblock 510 268 484 minecraft:terracotta
setblock 510 268 485 minecraft:red_terracotta
setblock 510 268 504 minecraft:terracotta
fill 511 268 464 511 271 464 minecraft:red_terracotta
setblock 511 268 468 minecraft:terracotta
fill 511 268 469 511 271 469 minecraft:red_terracotta
setblock 511 268 473 minecraft:terracotta
setblock 511 268 478 minecraft:terracotta
setblock 511 268 479 minecraft:red_terracotta
setblock 511 268 483 minecraft:terracotta
fill 511 268 484 511 270 484 minecraft:red_terracotta
setblock 511 268 503 minecraft:terracotta
fill 511 268 504 511 270 504 minecraft:red_terracotta
setblock 471 269 467 minecraft:terracotta
fill 471 269 468 471 272 468 minecraft:red_terracotta
fill 471 269 485 471 270 487 minecraft:terracotta
setblock 471 269 502 minecraft:terracotta
fill 471 269 503 471 271 504 minecraft:red_terracotta
setblock 472 269 465 minecraft:red_terracotta
setblock 472 269 466 minecraft:terracotta
fill 472 269 467 472 271 467 minecraft:red_terracotta
fill 472 269 485 476 270 486 minecraft:terracotta
fill 472 269 504 473 269 504 minecraft:red_terracotta
setblock 473 269 465 minecraft:terracotta
setblock 474 269 464 minecraft:terracotta
fill 474 269 465 477 269 465 minecraft:red_terracotta
setblock 474 269 504 minecraft:terracotta
fill 475 269 464 475 272 464 minecraft:red_terracotta
setblock 475 269 503 minecraft:terracotta
fill 475 269 504 475 272 504 minecraft:red_terracotta
fill 476 269 503 476 272 503 minecraft:red_terracotta
setblock 477 269 466 minecraft:terracotta
fill 477 269 485 479 271 485 minecraft:terracotta
fill 477 269 502 477 270 502 minecraft:red_terracotta
setblock 478 269 465 minecraft:terracotta
fill 478 269 466 478 272 466 minecraft:red_terracotta
setblock 479 269 464 minecraft:terracotta
fill 479 269 465 479 272 465 minecraft:red_terracotta
setblock 479 269 504 minecraft:terracotta
fill 480 269 464 480 272 464 minecraft:red_terracotta
setblock 480 269 503 minecraft:terracotta
fill 480 269 504 480 272 504 minecraft:red_terracotta
setblock 481 269 466 minecraft:red_terracotta
setblock 481 269 502 minecraft:terracotta
fill 481 269 503 481 272 503 minecraft:red_terracotta
setblock 482 269 466 minecraft:terracotta
fill 482 269 502 482 270 502 minecraft:red_terracotta
setblock 483 269 465 minecraft:terracotta
setblock 483 269 466 minecraft:red_terracotta
setblock 484 269 464 minecraft:terracotta
fill 484 269 465 484 271 465 minecraft:red_terracotta
setblock 484 269 504 minecraft:terracotta
fill 485 269 464 485 272 464 minecraft:red_terracotta
setblock 485 269 503 minecraft:terracotta
fill 485 269 504 485 272 504 minecraft:red_terracotta
fill 486 269 503 486 270 503 minecraft:red_terracotta
setblock 489 269 464 minecraft:terracotta
setblock 489 269 504 minecraft:terracotta
setblock 490 269 464 minecraft:red_terracotta
fill 490 269 504 492 269 504 minecraft:red_terracotta
setblock 494 269 464 minecraft:terracotta
setblock 494 269 504 minecraft:terracotta
fill 495 269 464 495 272 464 minecraft:red_terracotta
setblock 495 269 504 minecraft:red_terracotta
setblock 497 269 465 minecraft:red_terracotta
setblock 498 269 465 minecraft:terracotta
setblock 499 269 464 minecraft:terracotta
fill 499 269 465 501 269 466 minecraft:red_terracotta
setblock 499 269 503 minecraft:red_terracotta
setblock 499 269 504 minecraft:terracotta
fill 500 269 464 500 272 464 minecraft:red_terracotta
setblock 500 269 503 minecraft:terracotta
fill 500 269 504 500 272 504 minecraft:red_terracotta
setblock 501 269 503 minecraft:red_terracotta
setblock 502 269 465 minecraft:red_terracotta
setblock 502 269 466 minecraft:terracotta
setblock 503 269 465 minecraft:terracotta
fill 503 269 466 503 272 466 minecraft:red_terracotta
setblock 504 269 464 minecraft:terracotta
fill 504 269 465 504 272 465 minecraft:red_terracotta
setblock 504 269 504 minecraft:terracotta
fill 505 269 464 505 272 464 minecraft:red_terracotta
fill 505 269 504 505 271 504 minecraft:red_terracotta
setblock 507 269 466 minecraft:terracotta
setblock 508 269 465 minecraft:terracotta
fill 508 269 466 508 270 466 minecraft:red_terracotta
setblock 509 269 464 minecraft:terracotta
fill 509 269 465 509 272 465 minecraft:red_terracotta
setblock 509 269 504 minecraft:terracotta
fill 510 269 464 510 272 464 minecraft:red_terracotta
setblock 510 269 468 minecraft:terracotta
fill 510 269 469 510 272 469 minecraft:red_terracotta
setblock 510 269 504 minecraft:red_terracotta
setblock 511 269 467 minecraft:terracotta
fill 511 269 468 511 272 468 minecraft:red_terracotta
setblock 511 269 472 minecraft:terracotta
setblock 511 269 482 minecraft:terracotta
setblock 511 269 483 minecraft:red_terracotta
setblock 511 269 487 minecraft:terracotta
setblock 471 270 466 minecraft:terracotta
fill 471 270 467 471 273 467 minecraft:red_terracotta
setblock 471 270 502 minecraft:red_terracotta
setblock 472 270 465 minecraft:terracotta
fill 472 270 466 472 272 466 minecraft:red_terracotta
setblock 472 270 504 minecraft:red_terracotta
setblock 473 270 464 minecraft:terracotta
fill 473 270 465 476 270 465 minecraft:red_terracotta
setblock 473 270 466 minecraft:light[level=14]
setblock 473 270 474 minecraft:light[level=14]
setblock 473 270 482 minecraft:light[level=14]
setblock 473 270 490 minecraft:light[level=14]
setblock 473 270 498 minecraft:light[level=14]
setblock 473 270 504 minecraft:terracotta
fill 474 270 464 474 273 464 minecraft:red_terracotta
setblock 474 270 503 minecraft:terracotta
fill 474 270 504 474 273 504 minecraft:red_terracotta
fill 475 270 503 475 272 503 minecraft:red_terracotta
setblock 477 270 465 minecraft:terracotta
fill 477 270 466 477 271 466 minecraft:red_terracotta
fill 477 270 484 485 270 484 minecraft:terracotta
fill 477 270 486 480 270 486 minecraft:terracotta
setblock 478 270 464 minecraft:terracotta
fill 478 270 465 478 273 465 minecraft:red_terracotta
setblock 478 270 504 minecraft:terracotta
fill 479 270 464 479 273 464 minecraft:red_terracotta
setblock 479 270 503 minecraft:terracotta
fill 479 270 504 479 273 504 minecraft:red_terracotta
fill 480 270 485 485 271 485 minecraft:terracotta
setblock 480 270 502 minecraft:terracotta
fill 480 270 503 480 273 503 minecraft:red_terracotta
setblock 481 270 466 minecraft:terracotta
setblock 481 270 474 minecraft:light[level=14]
setblock 481 270 482 minecraft:light[level=14]
setblock 481 270 490 minecraft:light[level=14]
setblock 481 270 498 minecraft:light[level=14]
fill 481 270 502 481 271 502 minecraft:red_terracotta
setblock 482 270 465 minecraft:terracotta
setblock 482 270 466 minecraft:red_terracotta
setblock 483 270 464 minecraft:terracotta
fill 483 270 465 483 272 465 minecraft:red_terracotta
fill 483 270 469 484 270 473 minecraft:orange_concrete
setblock 483 270 504 minecraft:terracotta
fill 484 270 464 484 273 464 minecraft:red_terracotta
fill 484 270 467 490 270 468 minecraft:orange_concrete
fill 484 270 474 491 270 474 minecraft:orange_concrete
setblock 484 270 503 minecraft:terracotta
fill 484 270 504 484 273 504 minecraft:red_terracotta
fill 485 270 469 485 272 469 minecraft:orange_concrete
fill 485 270 472 485 272 473 minecraft:orange_concrete
fill 485 270 475 490 270 475 minecraft:orange_concrete
setblock 485 270 503 minecraft:red_terracotta
fill 486 270 466 489 270 466 minecraft:orange_concrete
setblock 488 270 464 minecraft:terracotta
setblock 488 270 504 minecraft:terracotta
fill 489 270 473 491 271 473 minecraft:orange_concrete
setblock 489 270 482 minecraft:light[level=14]
setblock 489 270 490 minecraft:light[level=14]
setblock 489 270 498 minecraft:light[level=14]
setblock 489 270 504 minecraft:red_terracotta
fill 490 270 469 492 270 469 minecraft:orange_concrete
fill 490 270 472 492 270 472 minecraft:orange_concrete
setblock 491 270 468 minecraft:orange_concrete
fill 491 270 470 492 270 471 minecraft:orange_concrete
fill 491 270 483 491 272 484 minecraft:terracotta
fill 492 270 483 493 272 483 minecraft:terracotta
fill 494 270 464 494 271 464 minecraft:red_terracotta
setblock 497 270 465 minecraft:terracotta
setblock 497 270 466 minecraft:light[level=14]
setblock 497 270 474 minecraft:light[level=14]
setblock 497 270 482 minecraft:light[level=14]
setblock 497 270 490 minecraft:light[level=14]
setblock 497 270 498 minecraft:light[level=14]
setblock 498 270 464 minecraft:terracotta
fill 498 270 465 501 270 465 minecraft:red_terracotta
setblock 498 270 504 minecraft:terracotta
fill 499 270 464 499 273 464 minecraft:red_terracotta
fill 499 270 466 500 270 466 minecraft:red_terracotta
fill 499 270 504 499 272 504 minecraft:red_terracotta
setblock 501 270 466 minecraft:terracotta
setblock 502 270 465 minecraft:terracotta
fill 502 270 466 502 273 466 minecraft:red_terracotta
setblock 503 270 464 minecraft:terracotta
fill 503 270 465 503 273 465 minecraft:red_terracotta
setblock 503 270 504 minecraft:terracotta
fill 504 270 464 504 273 464 minecraft:red_terracotta
fill 504 270 504 504 271 504 minecraft:red_terracotta
setblock 505 270 474 minecraft:light[level=14]
setblock 505 270 482 minecraft:light[level=14]
setblock 505 270 490 minecraft:light[level=14]
setblock 505 270 498 minecraft:light[level=14]
setblock 506 270 466 minecraft:terracotta
setblock 507 270 465 minecraft:terracotta
setblock 507 270 466 minecraft:red_terracotta
setblock 508 270 464 minecraft:terracotta
fill 508 270 465 508 273 465 minecraft:red_terracotta
setblock 508 270 504 minecraft:terracotta
fill 509 270 464 509 273 464 minecraft:red_terracotta
setblock 509 270 504 minecraft:red_terracotta
setblock 510 270 467 minecraft:terracotta
fill 510 270 468 510 273 468 minecraft:red_terracotta
setblock 511 270 466 minecraft:terracotta
fill 511 270 467 511 273 467 minecraft:red_terracotta
setblock 511 270 471 minecraft:terracotta
setblock 511 270 472 minecraft:red_terracotta
setblock 511 270 486 minecraft:terracotta
setblock 471 271 464 minecraft:red_terracotta
setblock 471 271 465 minecraft:terracotta
fill 471 271 466 471 273 466 minecraft:red_terracotta
fill 471 271 486 473 271 486 minecraft:orange_concrete
setblock 472 271 464 minecraft:terracotta
fill 472 271 465 475 271 465 minecraft:red_terracotta
setblock 472 271 504 minecraft:terracotta
fill 473 271 464 473 273 464 minecraft:red_terracotta
fill 473 271 504 473 273 504 minecraft:red_terracotta
setblock 474 271 503 minecraft:red_terracotta
setblock 476 271 465 minecraft:terracotta
setblock 476 271 485 minecraft:terracotta
setblock 477 271 464 minecraft:terracotta
fill 477 271 465 477 273 465 minecraft:red_terracotta
setblock 477 271 504 minecraft:terracotta
fill 478 271 464 478 273 464 minecraft:red_terracotta
setblock 478 271 503 minecraft:terracotta
fill 478 271 504 478 273 504 minecraft:red_terracotta
setblock 479 271 502 minecraft:terracotta
fill 479 271 503 479 273 503 minecraft:red_terracotta
setblock 480 271 466 minecraft:terracotta
fill 480 271 484 485 271 484 minecraft:terracotta
setblock 480 271 502 minecraft:red_terracotta
setblock 481 271 465 minecraft:terracotta
setblock 481 271 466 minecraft:red_terracotta
setblock 482 271 464 minecraft:terracotta
fill 482 271 465 482 273 465 minecraft:red_terracotta
setblock 482 271 504 minecraft:terracotta
fill 483 271 464 483 273 464 minecraft:red_terracotta
setblock 483 271 503 minecraft:terracotta
fill 483 271 504 483 273 504 minecraft:red_terracotta
fill 484 271 469 484 271 473 minecraft:orange_concrete
setblock 484 271 503 minecraft:red_terracotta
fill 485 271 468 490 271 468 minecraft:orange_concrete
fill 485 271 474 490 271 474 minecraft:orange_concrete
fill 486 271 467 489 271 467 minecraft:orange_concrete
setblock 487 271 464 minecraft:terracotta
setblock 487 271 475 minecraft:orange_concrete
setblock 487 271 504 minecraft:terracotta
fill 490 271 469 491 271 469 minecraft:orange_concrete
fill 490 271 472 491 271 472 minecraft:orange_concrete
fill 491 271 470 491 271 471 minecraft:orange_concrete
fill 492 271 484 495 271 484 minecraft:terracotta
fill 493 271 482 505 271 482 minecraft:terracotta
fill 494 271 483 501 272 483 minecraft:terracotta
setblock 496 271 465 minecraft:terracotta
setblock 497 271 464 minecraft:terracotta
fill 497 271 465 500 271 465 minecraft:red_terracotta
setblock 497 271 504 minecraft:terracotta
fill 498 271 464 498 273 464 minecraft:red_terracotta
fill 498 271 504 498 272 504 minecraft:red_terracotta
setblock 499 271 466 minecraft:red_terracotta
setblock 500 271 466 minecraft:terracotta
setblock 501 271 465 minecraft:terracotta
fill 501 271 466 501 273 466 minecraft:red_terracotta
setblock 502 271 464 minecraft:terracotta
fill 502 271 465 502 273 465 minecraft:red_terracotta
setblock 502 271 504 minecraft:terracotta
fill 503 271 464 503 273 464 minecraft:red_terracotta
fill 503 271 504 503 272 504 minecraft:red_terracotta
setblock 505 271 466 minecraft:terracotta
setblock 506 271 465 minecraft:terracotta
setblock 506 271 466 minecraft:red_terracotta
setblock 507 271 464 minecraft:terracotta
fill 507 271 465 507 273 465 minecraft:red_terracotta
fill 508 271 464 508 273 464 minecraft:red_terracotta
setblock 510 271 466 minecraft:terracotta
fill 510 271 467 510 273 467 minecraft:red_terracotta
setblock 511 271 465 minecraft:terracotta
fill 511 271 466 511 273 466 minecraft:red_terracotta
setblock 511 271 470 minecraft:terracotta
fill 511 271 471 511 273 471 minecraft:red_terracotta
setblock 471 272 464 minecraft:terracotta
fill 471 272 465 474 272 465 minecraft:red_terracotta
setblock 471 272 469 minecraft:terracotta
setblock 471 272 504 minecraft:terracotta
fill 472 272 464 472 273 464 minecraft:red_terracotta
fill 472 272 504 472 273 504 minecraft:red_terracotta
setblock 475 272 465 minecraft:terracotta
setblock 476 272 464 minecraft:terracotta
fill 476 272 465 476 273 465 minecraft:red_terracotta
setblock 476 272 504 minecraft:terracotta
fill 477 272 464 477 273 464 minecraft:red_terracotta
fill 477 272 485 482 272 485 minecraft:orange_concrete
setblock 477 272 503 minecraft:terracotta
fill 477 272 504 477 273 504 minecraft:red_terracotta
fill 478 272 503 478 273 503 minecraft:red_terracotta
setblock 479 272 466 minecraft:terracotta
setblock 480 272 465 minecraft:terracotta
setblock 481 272 464 minecraft:terracotta
fill 481 272 465 481 273 465 minecraft:red_terracotta
setblock 481 272 504 minecraft:terracotta
fill 482 272 464 482 273 464 minecraft:red_terracotta
setblock 482 272 503 minecraft:terracotta
fill 482 272 504 482 273 504 minecraft:red_terracotta
fill 483 272 484 485 272 484 minecraft:orange_concrete
setblock 483 272 503 minecraft:red_terracotta
fill 484 272 470 484 272 471 minecraft:orange_concrete
fill 486 272 468 489 272 468 minecraft:orange_concrete
fill 487 272 474 488 272 474 minecraft:orange_concrete
fill 489 272 473 490 272 473 minecraft:orange_concrete
setblock 490 272 469 minecraft:orange_concrete
setblock 490 272 472 minecraft:orange_concrete
fill 492 272 484 494 272 484 minecraft:terracotta
fill 495 272 482 510 272 482 minecraft:terracotta
setblock 496 272 464 minecraft:terracotta
fill 496 272 465 499 272 465 minecraft:red_terracotta
fill 497 272 464 497 273 464 minecraft:red_terracotta
setblock 499 272 466 minecraft:terracotta
setblock 500 272 465 minecraft:terracotta
fill 500 272 466 500 273 466 minecraft:red_terracotta
setblock 501 272 464 minecraft:terracotta
fill 501 272 465 501 273 465 minecraft:red_terracotta
fill 501 272 481 511 272 481 minecraft:terracotta
setblock 501 272 504 minecraft:terracotta
fill 502 272 464 502 273 464 minecraft:red_terracotta
fill 502 272 483 504 272 483 minecraft:terracotta
setblock 502 272 504 minecraft:red_terracotta
setblock 504 272 466 minecraft:terracotta
setblock 505 272 465 minecraft:terracotta
setblock 505 272 466 minecraft:red_terracotta
setblock 506 272 464 minecraft:terracotta
fill 506 272 465 506 273 465 minecraft:red_terracotta
fill 507 272 464 507 273 464 minecraft:red_terracotta
setblock 510 272 465 minecraft:terracotta
fill 510 272 466 510 273 466 minecraft:red_terracotta
fill 510 272 480 510 273 480 minecraft:terracotta
setblock 511 272 464 minecraft:terracotta
fill 511 272 465 511 273 465 minecraft:red_terracotta
setblock 511 272 469 minecraft:terracotta
fill 511 272 470 511 273 470 minecraft:red_terracotta
fill 471 273 464 471 273 465 minecraft:red_terracotta
setblock 471 273 468 minecraft:terracotta
setblock 471 273 469 minecraft:red_terracotta
setblock 471 273 504 minecraft:red_terracotta
setblock 473 273 465 minecraft:red_terracotta
setblock 474 273 465 minecraft:terracotta
setblock 475 273 464 minecraft:terracotta
setblock 475 273 465 minecraft:red_terracotta
setblock 475 273 504 minecraft:terracotta
setblock 476 273 464 minecraft:red_terracotta
setblock 476 273 503 minecraft:terracotta
setblock 476 273 504 minecraft:red_terracotta
setblock 477 273 503 minecraft:red_terracotta
setblock 479 273 465 minecraft:terracotta
setblock 480 273 464 minecraft:terracotta
setblock 480 273 465 minecraft:red_terracotta
setblock 480 273 504 minecraft:terracotta
setblock 481 273 464 minecraft:red_terracotta
setblock 481 273 503 minecraft:terracotta
setblock 481 273 504 minecraft:red_terracotta
fill 492 273 483 498 273 483 minecraft:orange_concrete
setblock 495 273 464 minecraft:terracotta
fill 496 273 464 496 273 465 minecraft:red_terracotta
fill 497 273 465 498 273 465 minecraft:red_terracotta
setblock 498 273 466 minecraft:terracotta
setblock 499 273 465 minecraft:terracotta
setblock 499 273 466 minecraft:red_terracotta
fill 499 273 482 501 273 482 minecraft:orange_concrete
setblock 500 273 464 minecraft:terracotta
setblock 500 273 465 minecraft:red_terracotta
setblock 501 273 464 minecraft:red_terracotta
fill 502 273 482 510 273 482 minecraft:terracotta
setblock 503 273 466 minecraft:terracotta
setblock 504 273 465 minecraft:terracotta
setblock 504 273 466 minecraft:red_terracotta
setblock 505 273 464 minecraft:terracotta
setblock 505 273 465 minecraft:red_terracotta
fill 505 273 481 511 273 481 minecraft:terracotta
setblock 506 273 464 minecraft:red_terracotta
setblock 509 273 465 minecraft:terracotta
setblock 510 273 464 minecraft:terracotta
setblock 510 273 465 minecraft:red_terracotta
setblock 511 273 464 minecraft:red_terracotta
setblock 511 273 468 minecraft:terracotta
setblock 511 273 469 minecraft:red_terracotta
setblock 473 278 466 minecraft:light[level=14]
setblock 473 278 474 minecraft:light[level=14]
setblock 473 278 482 minecraft:light[level=14]
setblock 473 278 490 minecraft:light[level=14]
setblock 473 278 498 minecraft:light[level=14]
setblock 481 278 466 minecraft:light[level=14]
setblock 481 278 474 minecraft:light[level=14]
setblock 481 278 482 minecraft:light[level=14]
setblock 481 278 490 minecraft:light[level=14]
setblock 481 278 498 minecraft:light[level=14]
setblock 489 278 466 minecraft:light[level=14]
setblock 489 278 474 minecraft:light[level=14]
setblock 489 278 482 minecraft:light[level=14]
setblock 489 278 490 minecraft:light[level=14]
setblock 489 278 498 minecraft:light[level=14]
setblock 497 278 466 minecraft:light[level=14]
setblock 497 278 474 minecraft:light[level=14]
setblock 497 278 482 minecraft:light[level=14]
setblock 497 278 490 minecraft:light[level=14]
setblock 497 278 498 minecraft:light[level=14]
setblock 505 278 466 minecraft:light[level=14]
setblock 505 278 474 minecraft:light[level=14]
setblock 505 278 482 minecraft:light[level=14]
setblock 505 278 490 minecraft:light[level=14]
setblock 505 278 498 minecraft:light[level=14]
fill 471 279 474 485 279 494 minecraft:terracotta
fill 472 279 472 510 279 473 minecraft:terracotta
fill 472 279 495 510 279 496 minecraft:terracotta
fill 473 279 471 509 279 471 minecraft:terracotta
fill 473 279 497 509 279 497 minecraft:terracotta
fill 474 279 470 508 279 470 minecraft:terracotta
fill 474 279 498 508 279 498 minecraft:terracotta
fill 475 279 469 507 279 469 minecraft:terracotta
fill 475 279 499 507 279 499 minecraft:terracotta
fill 476 279 468 506 279 468 minecraft:terracotta
fill 476 279 500 506 279 500 minecraft:terracotta
fill 477 279 467 505 279 467 minecraft:terracotta
fill 477 279 501 505 279 501 minecraft:terracotta
fill 478 279 466 504 279 466 minecraft:terracotta
fill 478 279 502 504 279 502 minecraft:terracotta
fill 479 279 465 503 279 465 minecraft:terracotta
fill 479 279 503 503 279 503 minecraft:terracotta
fill 481 279 464 501 279 464 minecraft:terracotta
fill 481 279 504 501 279 504 minecraft:terracotta
fill 486 279 474 486 279 482 minecraft:terracotta
setblock 486 279 483 minecraft:orange_terracotta
setblock 486 279 485 minecraft:orange_terracotta
fill 486 279 486 486 279 494 minecraft:terracotta
fill 487 279 474 511 279 481 minecraft:terracotta
setblock 487 279 482 minecraft:orange_terracotta
setblock 487 279 486 minecraft:orange_terracotta
fill 487 279 487 511 279 494 minecraft:terracotta
fill 489 279 482 490 279 482 minecraft:orange_terracotta
fill 489 279 486 490 279 486 minecraft:orange_terracotta
fill 490 279 483 491 279 483 minecraft:orange_terracotta
fill 490 279 485 491 279 485 minecraft:orange_terracotta
fill 491 279 482 511 279 482 minecraft:terracotta
setblock 491 279 484 minecraft:orange_terracotta
fill 491 279 486 511 279 486 minecraft:terracotta
fill 492 279 483 511 279 485 minecraft:terracotta
fill 471 280 464 471 280 474 minecraft:red_terracotta
fill 471 280 475 471 280 493 minecraft:terracotta
fill 471 280 494 471 280 504 minecraft:red_terracotta
fill 472 280 464 472 280 472 minecraft:red_terracotta
fill 472 280 473 472 280 474 minecraft:terracotta
fill 472 280 475 484 280 493 minecraft:red_terracotta
fill 472 280 494 472 280 495 minecraft:terracotta
fill 472 280 496 472 280 504 minecraft:red_terracotta
fill 473 280 464 473 280 471 minecraft:red_terracotta
setblock 473 280 472 minecraft:terracotta
fill 473 280 473 509 280 474 minecraft:red_terracotta
fill 473 280 494 509 280 495 minecraft:red_terracotta
setblock 473 280 496 minecraft:terracotta
fill 473 280 497 473 280 504 minecraft:red_terracotta
fill 474 280 464 474 280 470 minecraft:red_terracotta
setblock 474 280 471 minecraft:terracotta
fill 474 280 472 508 280 472 minecraft:red_terracotta
fill 474 280 496 508 280 496 minecraft:red_terracotta
setblock 474 280 497 minecraft:terracotta
fill 474 280 498 474 280 504 minecraft:red_terracotta
fill 475 280 464 475 280 468 minecraft:red_terracotta
fill 475 280 469 475 280 470 minecraft:terracotta
fill 475 280 471 507 280 471 minecraft:red_terracotta
fill 475 280 497 507 280 497 minecraft:red_terracotta
fill 475 280 498 475 280 499 minecraft:terracotta
fill 475 280 500 475 280 504 minecraft:red_terracotta
fill 476 280 464 477 280 467 minecraft:red_terracotta
fill 476 280 468 477 280 468 minecraft:terracotta
fill 476 280 469 506 280 470 minecraft:red_terracotta
fill 476 280 498 506 280 499 minecraft:red_terracotta
fill 476 280 500 477 280 500 minecraft:terracotta
fill 476 280 501 477 280 504 minecraft:red_terracotta
fill 478 280 464 478 280 466 minecraft:red_terracotta
setblock 478 280 467 minecraft:terracotta
fill 478 280 468 504 280 468 minecraft:red_terracotta
fill 478 280 500 504 280 500 minecraft:red_terracotta
setblock 478 280 501 minecraft:terracotta
fill 478 280 502 478 280 504 minecraft:red_terracotta
fill 479 280 464 479 280 465 minecraft:red_terracotta
setblock 479 280 466 minecraft:terracotta
fill 479 280 467 503 280 467 minecraft:red_terracotta
fill 479 280 501 503 280 501 minecraft:red_terracotta
setblock 479 280 502 minecraft:terracotta
fill 479 280 503 479 280 504 minecraft:red_terracotta
fill 480 280 464 481 280 464 minecraft:red_terracotta
fill 480 280 465 481 280 465 minecraft:terracotta
fill 480 280 466 502 280 466 minecraft:red_terracotta
fill 480 280 502 502 280 502 minecraft:red_terracotta
fill 480 280 503 481 280 503 minecraft:terracotta
fill 480 280 504 481 280 504 minecraft:red_terracotta
fill 482 280 464 500 280 464 minecraft:terracotta
fill 482 280 465 500 280 465 minecraft:red_terracotta
fill 482 280 503 500 280 503 minecraft:red_terracotta
fill 482 280 504 500 280 504 minecraft:terracotta
fill 485 280 475 485 280 481 minecraft:red_terracotta
setblock 485 280 482 minecraft:orange_terracotta
fill 485 280 483 485 280 485 minecraft:shroomlight
setblock 485 280 486 minecraft:orange_terracotta
fill 485 280 487 485 280 493 minecraft:red_terracotta
fill 486 280 475 486 280 480 minecraft:red_terracotta
setblock 486 280 481 minecraft:orange_terracotta
fill 486 280 482 486 280 483 minecraft:shroomlight
fill 486 280 485 486 280 486 minecraft:shroomlight
setblock 486 280 487 minecraft:orange_terracotta
fill 486 280 488 486 280 493 minecraft:red_terracotta
fill 487 280 475 510 280 479 minecraft:red_terracotta
fill 487 280 480 490 280 480 minecraft:orange_terracotta
fill 487 280 481 487 280 482 minecraft:shroomlight
fill 487 280 486 487 280 487 minecraft:shroomlight
fill 487 280 488 490 280 488 minecraft:orange_terracotta
fill 487 280 489 510 280 493 minecraft:red_terracotta
fill 488 280 481 489 280 481 minecraft:shroomlight
fill 488 280 487 489 280 487 minecraft:shroomlight
fill 489 280 482 490 280 482 minecraft:shroomlight
fill 489 280 486 490 280 486 minecraft:shroomlight
fill 490 280 481 492 280 481 minecraft:orange_terracotta
fill 490 280 483 491 280 483 minecraft:shroomlight
fill 490 280 485 491 280 485 minecraft:shroomlight
fill 490 280 487 492 280 487 minecraft:orange_terracotta
fill 491 280 480 510 280 480 minecraft:red_terracotta
fill 491 280 482 492 280 482 minecraft:orange_terracotta
setblock 491 280 484 minecraft:shroomlight
fill 491 280 486 492 280 486 minecraft:orange_terracotta
fill 491 280 488 510 280 488 minecraft:red_terracotta
fill 492 280 483 493 280 485 minecraft:orange_terracotta
fill 493 280 481 510 280 482 minecraft:red_terracotta
fill 493 280 486 510 280 487 minecraft:red_terracotta
fill 494 280 483 510 280 485 minecraft:red_terracotta
fill 501 280 464 511 280 464 minecraft:red_terracotta
fill 501 280 465 502 280 465 minecraft:terracotta
fill 501 280 503 502 280 503 minecraft:terracotta
fill 501 280 504 511 280 504 minecraft:red_terracotta
fill 503 280 465 511 280 465 minecraft:red_terracotta
setblock 503 280 466 minecraft:terracotta
setblock 503 280 502 minecraft:terracotta
fill 503 280 503 511 280 503 minecraft:red_terracotta
fill 504 280 466 511 280 466 minecraft:red_terracotta
setblock 504 280 467 minecraft:terracotta
setblock 504 280 501 minecraft:terracotta
fill 504 280 502 511 280 502 minecraft:red_terracotta
fill 505 280 467 511 280 467 minecraft:red_terracotta
fill 505 280 468 506 280 468 minecraft:terracotta
fill 505 280 500 506 280 500 minecraft:terracotta
fill 505 280 501 511 280 501 minecraft:red_terracotta
fill 507 280 468 511 280 468 minecraft:red_terracotta
fill 507 280 469 507 280 470 minecraft:terracotta
fill 507 280 498 507 280 499 minecraft:terracotta
fill 507 280 500 511 280 500 minecraft:red_terracotta
fill 508 280 469 511 280 470 minecraft:red_terracotta
setblock 508 280 471 minecraft:terracotta
setblock 508 280 497 minecraft:terracotta
fill 508 280 498 511 280 499 minecraft:red_terracotta
fill 509 280 471 511 280 471 minecraft:red_terracotta
setblock 509 280 472 minecraft:terracotta
setblock 509 280 496 minecraft:terracotta
fill 509 280 497 511 280 497 minecraft:red_terracotta
fill 510 280 472 511 280 472 minecraft:red_terracotta
fill 510 280 473 510 280 474 minecraft:terracotta
fill 510 280 494 510 280 495 minecraft:terracotta
fill 510 280 496 511 280 496 minecraft:red_terracotta
fill 511 280 473 511 280 474 minecraft:red_terracotta
fill 511 280 475 511 280 493 minecraft:terracotta
fill 511 280 494 511 280 495 minecraft:red_terracotta
fill 471 281 477 471 281 491 minecraft:terracotta
fill 472 281 475 472 281 476 minecraft:terracotta
fill 472 281 477 483 281 491 minecraft:red_terracotta
fill 472 281 492 472 281 493 minecraft:terracotta
fill 473 281 473 473 281 474 minecraft:terracotta
fill 473 281 475 509 281 476 minecraft:red_terracotta
fill 473 281 492 509 281 493 minecraft:red_terracotta
fill 473 281 494 473 281 495 minecraft:terracotta
setblock 474 281 472 minecraft:terracotta
fill 474 281 473 508 281 474 minecraft:red_terracotta
fill 474 281 494 508 281 495 minecraft:red_terracotta
setblock 474 281 496 minecraft:terracotta
fill 475 281 470 475 281 471 minecraft:terracotta
fill 475 281 472 507 281 472 minecraft:red_terracotta
fill 475 281 496 507 281 496 minecraft:red_terracotta
fill 475 281 497 475 281 498 minecraft:terracotta
setblock 476 281 469 minecraft:terracotta
fill 476 281 470 506 281 471 minecraft:red_terracotta
fill 476 281 497 506 281 498 minecraft:red_terracotta
setblock 476 281 499 minecraft:terracotta
fill 477 281 468 478 281 468 minecraft:terracotta
fill 477 281 469 505 281 469 minecraft:red_terracotta
fill 477 281 499 505 281 499 minecraft:red_terracotta
fill 477 281 500 478 281 500 minecraft:terracotta
setblock 479 281 467 minecraft:terracotta
fill 479 281 468 503 281 468 minecraft:red_terracotta
fill 479 281 500 503 281 500 minecraft:red_terracotta
setblock 479 281 501 minecraft:terracotta
fill 480 281 466 481 281 466 minecraft:terracotta
fill 480 281 467 502 281 467 minecraft:red_terracotta
fill 480 281 501 502 281 501 minecraft:red_terracotta
fill 480 281 502 481 281 502 minecraft:terracotta
fill 482 281 465 483 281 465 minecraft:terracotta
fill 482 281 466 500 281 466 minecraft:red_terracotta
fill 482 281 502 500 281 502 minecraft:red_terracotta
fill 482 281 503 483 281 503 minecraft:terracotta
fill 484 281 464 498 281 464 minecraft:terracotta
fill 484 281 465 498 281 465 minecraft:red_terracotta
fill 484 281 477 484 281 480 minecraft:red_terracotta
fill 484 281 481 484 281 487 minecraft:orange_terracotta
fill 484 281 488 484 281 491 minecraft:red_terracotta
fill 484 281 503 498 281 503 minecraft:red_terracotta
fill 484 281 504 498 281 504 minecraft:terracotta
fill 485 281 477 485 281 479 minecraft:red_terracotta
fill 485 281 480 485 281 481 minecraft:orange_terracotta
fill 485 281 487 485 281 488 minecraft:orange_terracotta
fill 485 281 489 485 281 491 minecraft:red_terracotta
fill 486 281 477 488 281 478 minecraft:red_terracotta
fill 486 281 479 486 281 480 minecraft:orange_terracotta
fill 486 281 488 486 281 489 minecraft:orange_terracotta
fill 486 281 490 488 281 491 minecraft:red_terracotta
fill 487 281 479 492 281 479 minecraft:orange_terracotta
fill 487 281 489 492 281 489 minecraft:orange_terracotta
fill 489 281 477 510 281 477 minecraft:red_terracotta
setblock 489 281 478 minecraft:orange_terracotta
setblock 489 281 490 minecraft:orange_terracotta
fill 489 281 491 510 281 491 minecraft:red_terracotta
fill 490 281 478 510 281 478 minecraft:red_terracotta
fill 490 281 490 510 281 490 minecraft:red_terracotta
fill 491 281 480 493 281 480 minecraft:orange_terracotta
fill 491 281 488 493 281 488 minecraft:orange_terracotta
fill 493 281 479 510 281 479 minecraft:red_terracotta
fill 493 281 481 494 281 482 minecraft:orange_terracotta
fill 493 281 486 494 281 487 minecraft:orange_terracotta
fill 493 281 489 510 281 489 minecraft:red_terracotta
fill 494 281 480 510 281 480 minecraft:red_terracotta
fill 494 281 483 495 281 485 minecraft:orange_terracotta
fill 494 281 488 510 281 488 minecraft:red_terracotta
fill 495 281 481 510 281 482 minecraft:red_terracotta
fill 495 281 486 510 281 487 minecraft:red_terracotta
fill 496 281 483 510 281 485 minecraft:red_terracotta
fill 499 281 465 500 281 465 minecraft:terracotta
fill 499 281 503 500 281 503 minecraft:terracotta
fill 501 281 466 502 281 466 minecraft:terracotta
fill 501 281 502 502 281 502 minecraft:terracotta
setblock 503 281 467 minecraft:terracotta
setblock 503 281 501 minecraft:terracotta
fill 504 281 468 505 281 468 minecraft:terracotta
fill 504 281 500 505 281 500 minecraft:terracotta
setblock 506 281 469 minecraft:terracotta
setblock 506 281 499 minecraft:terracotta
fill 507 281 470 507 281 471 minecraft:terracotta
fill 507 281 497 507 281 498 minecraft:terracotta
setblock 508 281 472 minecraft:terracotta
setblock 508 281 496 minecraft:terracotta
fill 509 281 473 509 281 474 minecraft:terracotta
fill 509 281 494 509 281 495 minecraft:terracotta
fill 510 281 475 510 281 476 minecraft:terracotta
fill 510 281 492 510 281 493 minecraft:terracotta
fill 511 281 477 511 281 491 minecraft:terracotta
fill 471 282 479 471 282 489 minecraft:terracotta
fill 472 282 476 472 282 478 minecraft:terracotta
fill 472 282 479 481 282 489 minecraft:red_terracotta
fill 472 282 490 472 282 492 minecraft:terracotta
fill 473 282 474 473 282 475 minecraft:terracotta
fill 473 282 476 484 282 478 minecraft:red_terracotta
fill 473 282 490 484 282 492 minecraft:red_terracotta
fill 473 282 493 473 282 494 minecraft:terracotta
setblock 474 282 473 minecraft:terracotta
fill 474 282 474 508 282 475 minecraft:red_terracotta
fill 474 282 493 508 282 494 minecraft:red_terracotta
setblock 474 282 495 minecraft:terracotta
fill 475 282 471 475 282 472 minecraft:terracotta
fill 475 282 473 507 282 473 minecraft:red_terracotta
fill 475 282 495 507 282 495 minecraft:red_terracotta
fill 475 282 496 475 282 497 minecraft:terracotta
setblock 476 282 470 minecraft:terracotta
fill 476 282 471 506 282 472 minecraft:red_terracotta
fill 476 282 496 506 282 497 minecraft:red_terracotta
setblock 476 282 498 minecraft:terracotta
setblock 477 282 469 minecraft:terracotta
fill 477 282 470 505 282 470 minecraft:red_terracotta
fill 477 282 498 505 282 498 minecraft:red_terracotta
setblock 477 282 499 minecraft:terracotta
fill 478 282 468 479 282 468 minecraft:terracotta
fill 478 282 469 504 282 469 minecraft:red_terracotta
fill 478 282 499 504 282 499 minecraft:red_terracotta
fill 478 282 500 479 282 500 minecraft:terracotta
setblock 480 282 467 minecraft:terracotta
fill 480 282 468 502 282 468 minecraft:red_terracotta
fill 480 282 500 502 282 500 minecraft:red_terracotta
setblock 480 282 501 minecraft:terracotta
fill 481 282 466 482 282 466 minecraft:terracotta
fill 481 282 467 501 282 467 minecraft:red_terracotta
fill 481 282 501 501 282 501 minecraft:red_terracotta
fill 481 282 502 482 282 502 minecraft:terracotta
fill 482 282 479 482 282 482 minecraft:red_terracotta
fill 482 282 483 483 282 485 minecraft:orange_terracotta
fill 482 282 486 482 282 489 minecraft:red_terracotta
fill 483 282 465 485 282 465 minecraft:terracotta
fill 483 282 466 499 282 466 minecraft:red_terracotta
fill 483 282 479 483 282 480 minecraft:red_terracotta
fill 483 282 481 483 282 482 minecraft:orange_terracotta
fill 483 282 486 483 282 487 minecraft:orange_terracotta
fill 483 282 488 483 282 489 minecraft:red_terracotta
fill 483 282 502 499 282 502 minecraft:red_terracotta
fill 483 282 503 485 282 503 minecraft:terracotta
fill 484 282 479 484 282 480 minecraft:orange_terracotta
fill 484 282 488 484 282 489 minecraft:orange_terracotta
fill 485 282 476 486 282 477 minecraft:red_terracotta
fill 485 282 478 485 282 479 minecraft:orange_terracotta
fill 485 282 489 485 282 490 minecraft:orange_terracotta
fill 485 282 491 486 282 492 minecraft:red_terracotta
fill 486 282 464 496 282 464 minecraft:terracotta
fill 486 282 465 496 282 465 minecraft:red_terracotta
fill 486 282 478 488 282 478 minecraft:orange_terracotta
fill 486 282 490 488 282 490 minecraft:orange_terracotta
fill 486 282 503 496 282 503 minecraft:red_terracotta
fill 486 282 504 496 282 504 minecraft:terracotta
fill 487 282 476 509 282 476 minecraft:red_terracotta
fill 487 282 477 492 282 477 minecraft:orange_terracotta
fill 487 282 491 492 282 491 minecraft:orange_terracotta
fill 487 282 492 509 282 492 minecraft:red_terracotta
fill 490 282 478 494 282 478 minecraft:orange_terracotta
fill 490 282 490 494 282 490 minecraft:orange_terracotta
fill 493 282 477 509 282 477 minecraft:red_terracotta
fill 493 282 479 495 282 479 minecraft:orange_terracotta
fill 493 282 489 495 282 489 minecraft:orange_terracotta
fill 493 282 491 509 282 491 minecraft:red_terracotta
fill 494 282 480 495 282 480 minecraft:orange_terracotta
fill 494 282 488 495 282 488 minecraft:orange_terracotta
fill 495 282 478 509 282 478 minecraft:red_terracotta
fill 495 282 481 496 282 482 minecraft:orange_terracotta
fill 495 282 486 496 282 487 minecraft:orange_terracotta
fill 495 282 490 509 282 490 minecraft:red_terracotta
fill 496 282 479 510 282 480 minecraft:red_terracotta
fill 496 282 483 497 282 485 minecraft:orange_terracotta
fill 496 282 488 510 282 489 minecraft:red_terracotta
fill 497 282 465 499 282 465 minecraft:terracotta
fill 497 282 481 510 282 482 minecraft:red_terracotta
fill 497 282 486 510 282 487 minecraft:red_terracotta
fill 497 282 503 499 282 503 minecraft:terracotta
fill 498 282 483 510 282 485 minecraft:red_terracotta
fill 500 282 466 501 282 466 minecraft:terracotta
fill 500 282 502 501 282 502 minecraft:terracotta
setblock 502 282 467 minecraft:terracotta
setblock 502 282 501 minecraft:terracotta
fill 503 282 468 504 282 468 minecraft:terracotta
fill 503 282 500 504 282 500 minecraft:terracotta
setblock 505 282 469 minecraft:terracotta
setblock 505 282 499 minecraft:terracotta
setblock 506 282 470 minecraft:terracotta
setblock 506 282 498 minecraft:terracotta
fill 507 282 471 507 282 472 minecraft:terracotta
fill 507 282 496 507 282 497 minecraft:terracotta
setblock 508 282 473 minecraft:terracotta
setblock 508 282 495 minecraft:terracotta
fill 509 282 474 509 282 475 minecraft:terracotta
fill 509 282 493 509 282 494 minecraft:terracotta
fill 510 282 476 510 282 478 minecraft:terracotta
fill 510 282 490 510 282 492 minecraft:terracotta
fill 511 282 479 511 282 489 minecraft:terracotta
fill 472 283 479 472 283 489 minecraft:terracotta
fill 473 283 476 473 283 478 minecraft:terracotta
fill 473 283 479 480 283 489 minecraft:red_terracotta
fill 473 283 490 473 283 492 minecraft:terracotta
fill 474 283 474 474 283 475 minecraft:terracotta
fill 474 283 476 483 283 478 minecraft:red_terracotta
fill 474 283 490 483 283 492 minecraft:red_terracotta
fill 474 283 493 474 283 494 minecraft:terracotta
setblock 475 283 473 minecraft:terracotta
fill 475 283 474 488 283 475 minecraft:red_terracotta
fill 475 283 493 488 283 494 minecraft:red_terracotta
setblock 475 283 495 minecraft:terracotta
fill 476 283 471 476 283 472 minecraft:terracotta
fill 476 283 473 506 283 473 minecraft:red_terracotta
fill 476 283 495 506 283 495 minecraft:red_terracotta
fill 476 283 496 476 283 497 minecraft:terracotta
fill 477 283 470 477 283 471 minecraft:terracotta
fill 477 283 472 505 283 472 minecraft:red_terracotta
fill 477 283 496 505 283 496 minecraft:red_terracotta
fill 477 283 497 477 283 498 minecraft:terracotta
fill 478 283 469 478 283 470 minecraft:terracotta
fill 478 283 471 504 283 471 minecraft:red_terracotta
fill 478 283 497 504 283 497 minecraft:red_terracotta
fill 478 283 498 478 283 499 minecraft:terracotta
setblock 479 283 469 minecraft:terracotta
fill 479 283 470 503 283 470 minecraft:red_terracotta
fill 479 283 498 503 283 498 minecraft:red_terracotta
setblock 479 283 499 minecraft:terracotta
setblock 480 283 468 minecraft:terracotta
fill 480 283 469 502 283 469 minecraft:red_terracotta
fill 480 283 499 502 283 499 minecraft:red_terracotta
setblock 480 283 500 minecraft:terracotta
fill 481 283 467 482 283 467 minecraft:terracotta
fill 481 283 468 501 283 468 minecraft:red_terracotta
fill 481 283 479 481 283 482 minecraft:red_terracotta
fill 481 283 483 481 283 485 minecraft:orange_terracotta
fill 481 283 486 481 283 489 minecraft:red_terracotta
fill 481 283 500 501 283 500 minecraft:red_terracotta
fill 481 283 501 482 283 501 minecraft:terracotta
setblock 482 283 479 minecraft:red_terracotta
fill 482 283 480 482 283 482 minecraft:orange_terracotta
fill 482 283 486 482 283 488 minecraft:orange_terracotta
setblock 482 283 489 minecraft:red_terracotta
fill 483 283 466 485 283 466 minecraft:terracotta
fill 483 283 467 499 283 467 minecraft:red_terracotta
fill 483 283 479 483 283 480 minecraft:orange_terracotta
fill 483 283 488 483 283 489 minecraft:orange_terracotta
fill 483 283 501 499 283 501 minecraft:red_terracotta
fill 483 283 502 485 283 502 minecraft:terracotta
fill 484 283 476 484 283 477 minecraft:red_terracotta
setblock 484 283 478 minecraft:orange_terracotta
setblock 484 283 490 minecraft:orange_terracotta
fill 484 283 491 484 283 492 minecraft:red_terracotta
setblock 485 283 476 minecraft:red_terracotta
fill 485 283 477 486 283 477 minecraft:orange_terracotta
fill 485 283 491 486 283 491 minecraft:orange_terracotta
setblock 485 283 492 minecraft:red_terracotta
fill 486 283 465 496 283 465 minecraft:terracotta
fill 486 283 466 496 283 466 minecraft:red_terracotta
fill 486 283 476 494 283 476 minecraft:orange_terracotta
fill 486 283 492 494 283 492 minecraft:orange_terracotta
fill 486 283 502 496 283 502 minecraft:red_terracotta
fill 486 283 503 496 283 503 minecraft:terracotta
fill 489 283 474 507 283 474 minecraft:red_terracotta
fill 489 283 475 491 283 475 minecraft:orange_terracotta
fill 489 283 493 491 283 493 minecraft:orange_terracotta
fill 489 283 494 507 283 494 minecraft:red_terracotta
fill 492 283 475 507 283 475 minecraft:red_terracotta
fill 492 283 493 507 283 493 minecraft:red_terracotta
fill 493 283 477 495 283 477 minecraft:orange_terracotta
fill 493 283 491 495 283 491 minecraft:orange_terracotta
fill 495 283 476 508 283 476 minecraft:red_terracotta
fill 495 283 478 496 283 478 minecraft:orange_terracotta
fill 495 283 490 496 283 490 minecraft:orange_terracotta
fill 495 283 492 508 283 492 minecraft:red_terracotta
fill 496 283 477 508 283 477 minecraft:red_terracotta
fill 496 283 479 497 283 480 minecraft:orange_terracotta
fill 496 283 488 497 283 489 minecraft:orange_terracotta
fill 496 283 491 508 283 491 minecraft:red_terracotta
fill 497 283 466 499 283 466 minecraft:terracotta
fill 497 283 478 508 283 478 minecraft:red_terracotta
fill 497 283 481 498 283 482 minecraft:orange_terracotta
fill 497 283 486 498 283 487 minecraft:orange_terracotta
fill 497 283 490 508 283 490 minecraft:red_terracotta
fill 497 283 502 499 283 502 minecraft:terracotta
fill 498 283 479 509 283 479 minecraft:red_terracotta
setblock 498 283 480 minecraft:orange_terracotta
fill 498 283 483 499 283 485 minecraft:orange_terracotta
setblock 498 283 488 minecraft:orange_terracotta
fill 498 283 489 509 283 489 minecraft:red_terracotta
fill 499 283 480 509 283 482 minecraft:red_terracotta
fill 499 283 486 509 283 488 minecraft:red_terracotta
fill 500 283 467 501 283 467 minecraft:terracotta
fill 500 283 483 509 283 485 minecraft:red_terracotta
fill 500 283 501 501 283 501 minecraft:terracotta
setblock 502 283 468 minecraft:terracotta
setblock 502 283 500 minecraft:terracotta
fill 503 283 469 504 283 469 minecraft:terracotta
fill 503 283 499 504 283 499 minecraft:terracotta
fill 504 283 470 505 283 470 minecraft:terracotta
fill 504 283 498 505 283 498 minecraft:terracotta
fill 505 283 471 506 283 471 minecraft:terracotta
fill 505 283 497 506 283 497 minecraft:terracotta
setblock 506 283 472 minecraft:terracotta
setblock 506 283 496 minecraft:terracotta
setblock 507 283 473 minecraft:terracotta
setblock 507 283 495 minecraft:terracotta
fill 508 283 474 508 283 475 minecraft:terracotta
fill 508 283 493 508 283 494 minecraft:terracotta
fill 509 283 476 509 283 478 minecraft:terracotta
fill 509 283 490 509 283 492 minecraft:terracotta
fill 510 283 479 510 283 489 minecraft:terracotta
fill 471 284 464 471 284 466 minecraft:red_terracotta
setblock 471 284 467 minecraft:terracotta
fill 471 284 468 471 284 471 minecraft:red_terracotta
setblock 471 284 472 minecraft:terracotta
fill 471 284 473 471 284 476 minecraft:red_terracotta
setblock 471 284 477 minecraft:terracotta
fill 471 284 478 471 284 481 minecraft:red_terracotta
setblock 471 284 482 minecraft:terracotta
fill 471 284 483 471 284 486 minecraft:red_terracotta
setblock 471 284 487 minecraft:terracotta
fill 471 284 488 471 284 491 minecraft:red_terracotta
setblock 471 284 492 minecraft:terracotta
fill 471 284 493 471 284 496 minecraft:red_terracotta
setblock 471 284 497 minecraft:terracotta
fill 471 284 498 471 284 501 minecraft:red_terracotta
setblock 471 284 502 minecraft:terracotta
fill 471 284 503 473 284 504 minecraft:red_terracotta
fill 472 284 464 473 284 464 minecraft:red_terracotta
setblock 472 284 470 minecraft:red_terracotta
setblock 472 284 471 minecraft:terracotta
fill 472 284 472 472 284 475 minecraft:red_terracotta
setblock 472 284 476 minecraft:terracotta
fill 472 284 477 472 284 480 minecraft:red_terracotta
fill 472 284 481 473 284 481 minecraft:terracotta
fill 472 284 487 472 284 490 minecraft:red_terracotta
setblock 472 284 491 minecraft:terracotta
fill 472 284 492 472 284 495 minecraft:red_terracotta
setblock 472 284 496 minecraft:terracotta
fill 472 284 497 472 284 500 minecraft:red_terracotta
setblock 472 284 501 minecraft:terracotta
fill 472 284 502 475 284 502 minecraft:red_terracotta
setblock 473 284 475 minecraft:terracotta
setblock 473 284 476 minecraft:red_terracotta
fill 473 284 479 473 284 480 minecraft:terracotta
fill 473 284 482 473 284 490 minecraft:terracotta
fill 473 284 491 473 284 494 minecraft:red_terracotta
setblock 473 284 495 minecraft:terracotta
fill 473 284 496 473 284 499 minecraft:red_terracotta
setblock 473 284 500 minecraft:terracotta
fill 473 284 501 474 284 501 minecraft:red_terracotta
setblock 474 284 464 minecraft:terracotta
fill 474 284 476 474 284 478 minecraft:terracotta
fill 474 284 479 479 284 489 minecraft:red_terracotta
fill 474 284 490 474 284 492 minecraft:terracotta
setblock 474 284 493 minecraft:red_terracotta
fill 474 284 494 476 284 494 minecraft:terracotta
fill 474 284 495 474 284 498 minecraft:red_terracotta
setblock 474 284 499 minecraft:terracotta
fill 474 284 500 474 286 500 minecraft:red_terracotta
setblock 474 284 503 minecraft:red_terracotta
setblock 474 284 504 minecraft:terracotta
fill 475 284 474 475 284 476 minecraft:terracotta
fill 475 284 477 481 284 478 minecraft:red_terracotta
fill 475 284 490 481 284 491 minecraft:red_terracotta
fill 475 284 492 475 284 493 minecraft:terracotta
setblock 475 284 503 minecraft:terracotta
fill 475 284 504 478 284 504 minecraft:red_terracotta
fill 476 284 473 476 284 474 minecraft:terracotta
fill 476 284 475 483 284 476 minecraft:red_terracotta
fill 476 284 492 483 284 493 minecraft:red_terracotta
setblock 476 284 495 minecraft:terracotta
setblock 476 284 502 minecraft:terracotta
fill 476 284 503 477 284 503 minecraft:red_terracotta
setblock 477 284 472 minecraft:terracotta
fill 477 284 473 486 284 474 minecraft:red_terracotta
fill 477 284 494 486 284 495 minecraft:red_terracotta
setblock 477 284 496 minecraft:terracotta
setblock 478 284 471 minecraft:terracotta
fill 478 284 472 504 284 472 minecraft:red_terracotta
fill 478 284 496 504 284 496 minecraft:red_terracotta
setblock 478 284 497 minecraft:terracotta
setblock 479 284 470 minecraft:terracotta
fill 479 284 471 503 284 471 minecraft:red_terracotta
fill 479 284 497 503 284 497 minecraft:red_terracotta
setblock 479 284 498 minecraft:terracotta
fill 480 284 469 481 284 469 minecraft:terracotta
fill 480 284 470 502 284 470 minecraft:red_terracotta
fill 480 284 479 480 284 481 minecraft:red_terracotta
fill 480 284 482 480 284 486 minecraft:orange_terracotta
fill 480 284 487 480 284 489 minecraft:red_terracotta
fill 480 284 498 502 284 498 minecraft:red_terracotta
fill 480 284 499 481 284 499 minecraft:terracotta
fill 481 284 468 483 284 468 minecraft:terracotta
fill 481 284 479 481 284 482 minecraft:orange_terracotta
fill 481 284 486 481 284 489 minecraft:orange_terracotta
fill 481 284 500 483 284 500 minecraft:terracotta
fill 482 284 469 500 284 469 minecraft:red_terracotta
setblock 482 284 477 minecraft:red_terracotta
fill 482 284 478 482 284 479 minecraft:orange_terracotta
fill 482 284 489 482 284 490 minecraft:orange_terracotta
setblock 482 284 491 minecraft:red_terracotta
fill 482 284 499 500 284 499 minecraft:red_terracotta
fill 483 284 467 485 284 467 minecraft:terracotta
fill 483 284 477 483 284 478 minecraft:orange_terracotta
fill 483 284 490 483 284 491 minecraft:orange_terracotta
fill 483 284 501 485 284 501 minecraft:terracotta
fill 484 284 468 498 284 468 minecraft:red_terracotta
setblock 484 284 475 minecraft:red_terracotta
fill 484 284 476 484 284 477 minecraft:orange_terracotta
fill 484 284 491 484 284 492 minecraft:orange_terracotta
setblock 484 284 493 minecraft:red_terracotta
fill 484 284 500 498 284 500 minecraft:red_terracotta
fill 485 284 475 485 284 476 minecraft:orange_terracotta
fill 485 284 492 485 284 493 minecraft:orange_terracotta
fill 486 284 466 496 284 466 minecraft:terracotta
fill 486 284 467 496 284 467 minecraft:red_terracotta
fill 486 284 475 488 284 475 minecraft:orange_terracotta
fill 486 284 493 488 284 493 minecraft:orange_terracotta
fill 486 284 501 496 284 501 minecraft:red_terracotta
fill 486 284 502 496 284 502 minecraft:terracotta
fill 486 284 503 486 291 503 minecraft:magma_block
fill 487 284 473 505 284 473 minecraft:red_terracotta
fill 487 284 474 494 284 474 minecraft:orange_terracotta
fill 487 284 494 494 284 494 minecraft:orange_terracotta
fill 487 284 495 505 284 495 minecraft:red_terracotta
fill 487 284 503 487 291 503 minecraft:shroomlight
fill 488 284 503 488 290 503 minecraft:magma_block
fill 489 284 464 489 288 464 minecraft:magma_block
fill 490 284 464 490 286 464 minecraft:shroomlight
fill 491 284 464 493 284 464 minecraft:red_terracotta
fill 492 284 475 496 284 475 minecraft:orange_terracotta
fill 492 284 493 496 284 493 minecraft:orange_terracotta
fill 492 284 504 493 284 504 minecraft:red_terracotta
setblock 494 284 464 minecraft:terracotta
fill 494 284 465 496 284 465 minecraft:red_terracotta
setblock 494 284 504 minecraft:terracotta
fill 495 284 464 498 284 464 minecraft:red_terracotta
fill 495 284 474 505 284 474 minecraft:red_terracotta
fill 495 284 476 497 284 476 minecraft:orange_terracotta
fill 495 284 492 497 284 492 minecraft:orange_terracotta
fill 495 284 494 505 284 494 minecraft:red_terracotta
fill 495 284 504 497 284 504 minecraft:red_terracotta
fill 496 284 477 498 284 477 minecraft:orange_terracotta
fill 496 284 491 498 284 491 minecraft:orange_terracotta
fill 497 284 467 499 284 467 minecraft:terracotta
fill 497 284 475 506 284 475 minecraft:red_terracotta
fill 497 284 478 499 284 478 minecraft:orange_terracotta
fill 497 284 490 499 284 490 minecraft:orange_terracotta
fill 497 284 493 506 284 493 minecraft:red_terracotta
fill 497 284 501 499 284 501 minecraft:terracotta
fill 498 284 476 506 284 476 minecraft:red_terracotta
fill 498 284 479 499 284 479 minecraft:orange_terracotta
fill 498 284 489 499 284 489 minecraft:orange_terracotta
fill 498 284 492 506 284 492 minecraft:red_terracotta
setblock 499 284 464 minecraft:terracotta
fill 499 284 468 501 284 468 minecraft:terracotta
fill 499 284 477 507 284 477 minecraft:red_terracotta
fill 499 284 480 500 284 482 minecraft:orange_terracotta
fill 499 284 486 500 284 488 minecraft:orange_terracotta
fill 499 284 491 507 284 491 minecraft:red_terracotta
fill 499 284 500 501 284 500 minecraft:terracotta
setblock 500 284 464 minecraft:red_terracotta
fill 500 284 478 507 284 479 minecraft:red_terracotta
fill 500 284 483 500 284 485 minecraft:orange_terracotta
fill 500 284 489 507 284 490 minecraft:red_terracotta
fill 501 284 469 502 284 469 minecraft:terracotta
fill 501 284 480 508 284 483 minecraft:red_terracotta
setblock 501 284 484 minecraft:orange_terracotta
fill 501 284 485 508 284 488 minecraft:red_terracotta
fill 501 284 499 502 284 499 minecraft:terracotta
fill 502 284 484 508 284 484 minecraft:red_terracotta
setblock 503 284 470 minecraft:terracotta
setblock 503 284 498 minecraft:terracotta
setblock 504 284 471 minecraft:terracotta
setblock 504 284 497 minecraft:terracotta
setblock 505 284 472 minecraft:terracotta
setblock 505 284 496 minecraft:terracotta
fill 506 284 464 508 284 464 minecraft:red_terracotta
fill 506 284 473 506 284 474 minecraft:terracotta
fill 506 284 494 506 284 495 minecraft:terracotta
fill 507 284 474 507 284 476 minecraft:terracotta
fill 507 284 492 507 284 494 minecraft:terracotta
fill 507 284 504 508 284 504 minecraft:red_terracotta
fill 508 284 476 508 284 478 minecraft:terracotta
setblock 508 284 479 minecraft:red_terracotta
setblock 508 284 489 minecraft:red_terracotta
fill 508 284 490 508 284 492 minecraft:terracotta
setblock 509 284 464 minecraft:terracotta
fill 509 284 479 509 284 489 minecraft:terracotta
fill 509 284 497 509 284 498 minecraft:red_terracotta
setblock 509 284 499 minecraft:terracotta
setblock 509 284 503 minecraft:red_terracotta
setblock 509 284 504 minecraft:terracotta
fill 510 284 464 510 284 467 minecraft:red_terracotta
setblock 510 284 468 minecraft:terracotta
fill 510 284 469 510 284 472 minecraft:red_terracotta
setblock 510 284 473 minecraft:terracotta
fill 510 284 474 510 284 477 minecraft:red_terracotta
setblock 510 284 478 minecraft:terracotta
setblock 510 284 492 minecraft:red_terracotta
setblock 510 284 493 minecraft:terracotta
fill 510 284 494 510 284 497 minecraft:red_terracotta
setblock 510 284 498 minecraft:terracotta
fill 510 284 499 510 284 502 minecraft:red_terracotta
setblock 510 284 503 minecraft:terracotta
fill 510 284 504 511 286 504 minecraft:red_terracotta
fill 511 284 464 511 284 466 minecraft:red_terracotta
setblock 511 284 467 minecraft:terracotta
fill 511 284 468 511 284 471 minecraft:red_terracotta
setblock 511 284 472 minecraft:terracotta
fill 511 284 473 511 284 476 minecraft:red_terracotta
setblock 511 284 477 minecraft:terracotta
fill 511 284 478 511 284 481 minecraft:red_terracotta
fill 511 284 489 511 284 491 minecraft:red_terracotta
setblock 511 284 492 minecraft:terracotta
fill 511 284 493 511 284 496 minecraft:red_terracotta
setblock 511 284 497 minecraft:terracotta
fill 511 284 498 511 284 501 minecraft:red_terracotta
setblock 511 284 502 minecraft:terracotta
fill 511 284 503 511 287 503 minecraft:red_terracotta
fill 471 285 464 471 285 465 minecraft:red_terracotta
setblock 471 285 466 minecraft:terracotta
fill 471 285 467 471 285 470 minecraft:red_terracotta
setblock 471 285 471 minecraft:terracotta
fill 471 285 472 471 285 475 minecraft:red_terracotta
setblock 471 285 476 minecraft:terracotta
fill 471 285 477 471 285 480 minecraft:red_terracotta
setblock 471 285 481 minecraft:terracotta
fill 471 285 482 471 285 485 minecraft:red_terracotta
setblock 471 285 486 minecraft:terracotta
fill 471 285 487 471 285 490 minecraft:red_terracotta
setblock 471 285 491 minecraft:terracotta
fill 471 285 492 471 285 495 minecraft:red_terracotta
setblock 471 285 496 minecraft:terracotta
fill 471 285 497 471 285 500 minecraft:red_terracotta
setblock 471 285 501 minecraft:terracotta
fill 471 285 502 472 285 504 minecraft:red_terracotta
setblock 472 285 464 minecraft:red_terracotta
fill 472 285 472 472 285 474 minecraft:red_terracotta
setblock 472 285 475 minecraft:terracotta
fill 472 285 476 472 285 479 minecraft:red_terracotta
setblock 472 285 480 minecraft:terracotta
fill 472 285 481 472 288 481 minecraft:red_terracotta
fill 472 285 488 472 285 489 minecraft:red_terracotta
setblock 472 285 490 minecraft:terracotta
fill 472 285 491 472 285 494 minecraft:red_terracotta
setblock 472 285 495 minecraft:terracotta
fill 472 285 496 472 285 499 minecraft:red_terracotta
setblock 472 285 500 minecraft:terracotta
fill 472 285 501 473 287 501 minecraft:red_terracotta
setblock 473 285 464 minecraft:terracotta
fill 473 285 490 473 285 493 minecraft:red_terracotta
setblock 473 285 494 minecraft:terracotta
fill 473 285 495 473 285 498 minecraft:red_terracotta
setblock 473 285 499 minecraft:terracotta
fill 473 285 500 473 288 500 minecraft:red_terracotta
fill 473 285 502 473 285 503 minecraft:red_terracotta
setblock 473 285 504 minecraft:terracotta
fill 474 285 479 474 285 489 minecraft:terracotta
setblock 474 285 493 minecraft:terracotta
fill 474 285 494 474 285 497 minecraft:red_terracotta
setblock 474 285 498 minecraft:terracotta
fill 474 285 499 474 286 499 minecraft:red_terracotta
setblock 474 285 502 minecraft:red_terracotta
setblock 474 285 503 minecraft:terracotta
fill 474 285 504 477 285 504 minecraft:red_terracotta
fill 475 285 477 475 285 481 minecraft:terracotta
fill 475 285 482 478 285 486 minecraft:red_terracotta
fill 475 285 487 475 285 491 minecraft:terracotta
setblock 475 285 502 minecraft:terracotta
fill 475 285 503 476 286 503 minecraft:red_terracotta
fill 476 285 475 476 285 477 minecraft:terracotta
fill 476 285 478 478 285 481 minecraft:red_terracotta
fill 476 285 487 478 285 490 minecraft:red_terracotta
fill 476 285 491 476 285 493 minecraft:terracotta
fill 477 285 473 477 285 475 minecraft:terracotta
fill 477 285 476 480 285 477 minecraft:red_terracotta
fill 477 285 491 480 285 492 minecraft:red_terracotta
fill 477 285 493 477 285 495 minecraft:terracotta
fill 478 285 472 478 285 474 minecraft:terracotta
fill 478 285 475 482 285 475 minecraft:red_terracotta
fill 478 285 493 482 285 493 minecraft:red_terracotta
fill 478 285 494 478 285 496 minecraft:terracotta
fill 479 285 471 479 285 473 minecraft:terracotta
fill 479 285 474 483 285 474 minecraft:red_terracotta
fill 479 285 478 479 285 480 minecraft:red_terracotta
fill 479 285 481 479 285 487 minecraft:orange_terracotta
fill 479 285 488 479 285 490 minecraft:red_terracotta
fill 479 285 494 483 285 494 minecraft:red_terracotta
fill 479 285 495 479 285 497 minecraft:terracotta
fill 480 285 470 480 285 472 minecraft:terracotta
fill 480 285 473 485 285 473 minecraft:red_terracotta
setblock 480 285 478 minecraft:red_terracotta
fill 480 285 479 480 285 481 minecraft:orange_terracotta
fill 480 285 487 480 285 489 minecraft:orange_terracotta
setblock 480 285 490 minecraft:red_terracotta
fill 480 285 495 485 285 495 minecraft:red_terracotta
fill 480 285 496 480 285 498 minecraft:terracotta
fill 481 285 470 481 285 471 minecraft:terracotta
fill 481 285 472 488 285 472 minecraft:red_terracotta
setblock 481 285 476 minecraft:red_terracotta
fill 481 285 477 481 285 478 minecraft:orange_terracotta
fill 481 285 490 481 285 491 minecraft:orange_terracotta
setblock 481 285 492 minecraft:red_terracotta
fill 481 285 496 488 285 496 minecraft:red_terracotta
fill 481 285 497 481 285 498 minecraft:terracotta
fill 482 285 469 482 285 470 minecraft:terracotta
fill 482 285 471 500 285 471 minecraft:red_terracotta
fill 482 285 476 482 285 477 minecraft:orange_terracotta
fill 482 285 491 482 285 492 minecraft:orange_terracotta
fill 482 285 497 500 285 497 minecraft:red_terracotta
fill 482 285 498 482 285 499 minecraft:terracotta
fill 483 285 469 484 285 469 minecraft:terracotta
fill 483 285 470 499 285 470 minecraft:red_terracotta
fill 483 285 475 483 285 476 minecraft:orange_terracotta
fill 483 285 492 483 285 493 minecraft:orange_terracotta
fill 483 285 498 499 285 498 minecraft:red_terracotta
fill 483 285 499 484 285 499 minecraft:terracotta
fill 484 285 468 488 285 468 minecraft:terracotta
fill 484 285 474 484 285 475 minecraft:orange_terracotta
fill 484 285 493 484 285 494 minecraft:orange_terracotta
fill 484 285 500 488 285 500 minecraft:terracotta
fill 485 285 469 497 285 469 minecraft:red_terracotta
fill 485 285 474 486 285 474 minecraft:orange_terracotta
fill 485 285 494 486 285 494 minecraft:orange_terracotta
fill 485 285 499 497 285 499 minecraft:red_terracotta
fill 486 285 467 496 285 467 minecraft:terracotta
fill 486 285 473 496 285 473 minecraft:orange_terracotta
fill 486 285 495 496 285 495 minecraft:orange_terracotta
fill 486 285 501 496 285 501 minecraft:terracotta
fill 489 285 468 493 285 468 minecraft:red_terracotta
fill 489 285 472 493 285 472 minecraft:orange_terracotta
fill 489 285 496 493 285 496 minecraft:orange_terracotta
fill 489 285 500 493 285 500 minecraft:red_terracotta
fill 491 285 464 492 285 464 minecraft:red_terracotta
fill 491 285 504 492 285 504 minecraft:red_terracotta
setblock 493 285 464 minecraft:terracotta
setblock 493 285 504 minecraft:terracotta
fill 494 285 464 497 285 464 minecraft:red_terracotta
fill 494 285 468 498 285 468 minecraft:terracotta
fill 494 285 472 501 285 472 minecraft:red_terracotta
fill 494 285 496 501 285 496 minecraft:red_terracotta
fill 494 285 500 498 285 500 minecraft:terracotta
fill 494 285 504 496 286 504 minecraft:red_terracotta
fill 495 285 474 497 285 474 minecraft:orange_terracotta
fill 495 285 494 497 285 494 minecraft:orange_terracotta
fill 497 285 473 502 285 473 minecraft:red_terracotta
fill 497 285 475 499 285 475 minecraft:orange_terracotta
fill 497 285 493 499 285 493 minecraft:orange_terracotta
fill 497 285 495 502 285 495 minecraft:red_terracotta
setblock 498 285 464 minecraft:terracotta
fill 498 285 469 500 285 469 minecraft:terracotta
fill 498 285 474 503 285 474 minecraft:red_terracotta
fill 498 285 476 500 285 476 minecraft:orange_terracotta
fill 498 285 492 500 285 492 minecraft:orange_terracotta
fill 498 285 494 503 285 494 minecraft:red_terracotta
fill 498 285 499 500 285 499 minecraft:terracotta
setblock 499 285 464 minecraft:red_terracotta
fill 499 285 477 500 285 477 minecraft:orange_terracotta
fill 499 285 491 500 285 491 minecraft:orange_terracotta
fill 500 285 470 502 285 470 minecraft:terracotta
fill 500 285 475 504 285 475 minecraft:red_terracotta
fill 500 285 478 501 285 479 minecraft:orange_terracotta
fill 500 285 489 501 285 490 minecraft:orange_terracotta
fill 500 285 493 504 285 493 minecraft:red_terracotta
fill 500 285 498 502 285 498 minecraft:terracotta
fill 501 285 471 503 285 471 minecraft:terracotta
fill 501 285 476 505 285 477 minecraft:red_terracotta
fill 501 285 480 502 285 483 minecraft:orange_terracotta
fill 501 285 485 502 285 488 minecraft:orange_terracotta
fill 501 285 491 505 285 492 minecraft:red_terracotta
fill 501 285 497 503 285 497 minecraft:terracotta
fill 502 285 472 504 285 472 minecraft:terracotta
fill 502 285 478 506 285 479 minecraft:red_terracotta
fill 502 285 484 503 285 484 minecraft:orange_terracotta
fill 502 285 489 506 285 490 minecraft:red_terracotta
fill 502 285 496 504 285 496 minecraft:terracotta
fill 503 285 473 505 285 473 minecraft:terracotta
fill 503 285 480 506 285 483 minecraft:red_terracotta
fill 503 285 485 506 285 488 minecraft:red_terracotta
fill 503 285 495 505 285 495 minecraft:terracotta
fill 504 285 474 505 285 474 minecraft:terracotta
fill 504 285 484 507 285 484 minecraft:red_terracotta
fill 504 285 494 505 285 494 minecraft:terracotta
fill 505 285 475 506 285 475 minecraft:terracotta
fill 505 285 493 506 285 493 minecraft:terracotta
fill 506 285 476 506 285 477 minecraft:terracotta
fill 506 285 491 506 285 492 minecraft:terracotta
fill 506 285 504 507 285 504 minecraft:red_terracotta
setblock 507 285 464 minecraft:red_terracotta
fill 507 285 477 507 285 481 minecraft:terracotta
fill 507 285 482 507 285 483 minecraft:red_terracotta
fill 507 285 485 507 285 486 minecraft:red_terracotta
fill 507 285 487 507 285 491 minecraft:terracotta
setblock 508 285 464 minecraft:terracotta
fill 508 285 479 508 285 489 minecraft:terracotta
setblock 508 285 503 minecraft:red_terracotta
setblock 508 285 504 minecraft:terracotta
fill 509 285 464 511 286 464 minecraft:red_terracotta
setblock 509 285 497 minecraft:red_terracotta
setblock 509 285 498 minecraft:terracotta
fill 509 285 499 510 285 501 minecraft:red_terracotta
setblock 509 285 503 minecraft:terracotta
fill 509 285 504 509 288 504 minecraft:red_terracotta
fill 510 285 468 510 285 471 minecraft:red_terracotta
setblock 510 285 472 minecraft:terracotta
fill 510 285 473 510 285 476 minecraft:red_terracotta
setblock 510 285 477 minecraft:terracotta
fill 510 285 478 511 287 478 minecraft:red_terracotta
fill 510 285 493 510 285 496 minecraft:red_terracotta
setblock 510 285 497 minecraft:terracotta
fill 510 285 498 511 287 498 minecraft:red_terracotta
setblock 510 285 502 minecraft:terracotta
fill 510 285 503 510 288 503 minecraft:red_terracotta
setblock 511 285 465 minecraft:red_terracotta
setblock 511 285 466 minecraft:terracotta
fill 511 285 467 511 285 470 minecraft:red_terracotta
setblock 511 285 471 minecraft:terracotta
fill 511 285 472 511 285 475 minecraft:red_terracotta
setblock 511 285 476 minecraft:terracotta
fill 511 285 477 511 288 477 minecraft:red_terracotta
fill 511 285 479 511 285 480 minecraft:red_terracotta
setblock 511 285 481 minecraft:terracotta
fill 511 285 482 511 288 482 minecraft:red_terracotta
fill 511 285 489 511 285 490 minecraft:red_terracotta
setblock 511 285 491 minecraft:terracotta
fill 511 285 492 511 285 495 minecraft:red_terracotta
setblock 511 285 496 minecraft:terracotta
fill 511 285 497 511 288 497 minecraft:red_terracotta
fill 511 285 499 511 285 500 minecraft:red_terracotta
setblock 511 285 501 minecraft:terracotta
fill 511 285 502 511 288 502 minecraft:red_terracotta
setblock 471 286 464 minecraft:red_terracotta
setblock 471 286 470 minecraft:terracotta
fill 471 286 471 471 286 474 minecraft:red_terracotta
setblock 471 286 475 minecraft:terracotta
fill 471 286 476 471 286 479 minecraft:red_terracotta
setblock 471 286 480 minecraft:terracotta
fill 471 286 481 471 286 484 minecraft:red_terracotta
setblock 471 286 485 minecraft:terracotta
fill 471 286 486 471 286 489 minecraft:red_terracotta
setblock 471 286 490 minecraft:terracotta
fill 471 286 491 471 286 494 minecraft:red_terracotta
setblock 471 286 495 minecraft:terracotta
fill 471 286 496 471 286 499 minecraft:red_terracotta
setblock 471 286 500 minecraft:terracotta
fill 471 286 501 471 286 504 minecraft:red_terracotta
setblock 472 286 473 minecraft:red_terracotta
setblock 472 286 474 minecraft:terracotta
fill 472 286 475 472 286 478 minecraft:red_terracotta
setblock 472 286 479 minecraft:terracotta
fill 472 286 480 472 289 480 minecraft:red_terracotta
fill 472 286 482 472 287 482 minecraft:red_terracotta
setblock 472 286 489 minecraft:terracotta
fill 472 286 490 472 286 493 minecraft:red_terracotta
setblock 472 286 494 minecraft:terracotta
fill 472 286 495 472 286 498 minecraft:red_terracotta
setblock 472 286 499 minecraft:terracotta
fill 472 286 500 472 289 500 minecraft:red_terracotta
fill 472 286 502 472 286 503 minecraft:red_terracotta
setblock 472 286 504 minecraft:terracotta
setblock 473 286 466 minecraft:light[level=14]
setblock 473 286 474 minecraft:light[level=14]
setblock 473 286 482 minecraft:light[level=14]
setblock 473 286 490 minecraft:light[level=14]
setblock 473 286 492 minecraft:red_terracotta
setblock 473 286 493 minecraft:terracotta
fill 473 286 494 473 286 497 minecraft:red_terracotta
setblock 473 286 498 minecraft:terracotta
fill 473 286 499 473 289 499 minecraft:red_terracotta
setblock 473 286 502 minecraft:red_terracotta
setblock 473 286 503 minecraft:terracotta
fill 473 286 504 476 286 504 minecraft:red_terracotta
fill 474 286 495 474 286 496 minecraft:red_terracotta
setblock 474 286 497 minecraft:terracotta
fill 474 286 498 474 287 498 minecraft:red_terracotta
setblock 474 286 502 minecraft:terracotta
fill 474 286 503 474 289 503 minecraft:red_terracotta
fill 475 286 482 477 286 486 minecraft:terracotta
fill 476 286 478 477 286 481 minecraft:terracotta
fill 476 286 487 477 286 490 minecraft:terracotta
fill 477 286 476 479 286 477 minecraft:terracotta
fill 477 286 491 479 286 492 minecraft:terracotta
setblock 477 286 504 minecraft:terracotta
fill 478 286 475 481 286 475 minecraft:terracotta
fill 478 286 478 478 286 480 minecraft:terracotta
fill 478 286 481 478 286 487 minecraft:orange_terracotta
fill 478 286 488 478 286 490 minecraft:terracotta
fill 478 286 493 481 286 493 minecraft:terracotta
fill 479 286 474 482 286 474 minecraft:terracotta
setblock 479 286 478 minecraft:terracotta
fill 479 286 479 479 286 480 minecraft:orange_terracotta
fill 479 286 488 479 286 489 minecraft:orange_terracotta
setblock 479 286 490 minecraft:terracotta
fill 479 286 494 482 286 494 minecraft:terracotta
fill 480 286 473 483 286 473 minecraft:terracotta
setblock 480 286 476 minecraft:terracotta
fill 480 286 477 480 286 478 minecraft:orange_terracotta
fill 480 286 490 480 286 491 minecraft:orange_terracotta
setblock 480 286 492 minecraft:terracotta
fill 480 286 495 483 286 495 minecraft:terracotta
setblock 481 286 466 minecraft:light[level=14]
fill 481 286 472 485 286 472 minecraft:terracotta
setblock 481 286 476 minecraft:orange_terracotta
setblock 481 286 482 minecraft:light[level=14]
setblock 481 286 490 minecraft:light[level=14]
setblock 481 286 492 minecraft:orange_terracotta
fill 481 286 496 485 286 496 minecraft:terracotta
setblock 481 286 498 minecraft:light[level=14]
fill 482 286 471 488 286 471 minecraft:terracotta
setblock 482 286 475 minecraft:orange_terracotta
setblock 482 286 493 minecraft:orange_terracotta
fill 482 286 497 488 286 497 minecraft:terracotta
fill 483 286 470 499 286 470 minecraft:terracotta
setblock 483 286 474 minecraft:orange_terracotta
setblock 483 286 494 minecraft:orange_terracotta
fill 483 286 498 499 286 498 minecraft:terracotta
fill 484 286 473 485 286 473 minecraft:orange_terracotta
fill 484 286 495 485 286 495 minecraft:orange_terracotta
fill 485 286 469 497 286 469 minecraft:terracotta
fill 485 286 499 497 286 499 minecraft:terracotta
fill 486 286 472 488 286 472 minecraft:orange_terracotta
fill 486 286 496 488 286 496 minecraft:orange_terracotta
fill 488 286 468 493 286 468 minecraft:terracotta
setblock 489 286 466 minecraft:light[level=14]
fill 489 286 471 493 286 471 minecraft:orange_terracotta
fill 489 286 472 490 300 472 minecraft:terracotta
setblock 489 286 474 minecraft:light[level=14]
setblock 489 286 482 minecraft:light[level=14]
setblock 489 286 490 minecraft:light[level=14]
fill 489 286 497 493 286 497 minecraft:orange_terracotta
fill 489 286 500 493 286 500 minecraft:terracotta
setblock 491 286 464 minecraft:red_terracotta
setblock 491 286 504 minecraft:red_terracotta
setblock 492 286 464 minecraft:terracotta
setblock 492 286 504 minecraft:terracotta
fill 493 286 464 496 286 464 minecraft:red_terracotta
fill 493 286 504 493 289 504 minecraft:red_terracotta
fill 494 286 471 500 286 471 minecraft:terracotta
fill 494 286 472 496 286 472 minecraft:orange_terracotta
fill 494 286 496 496 286 496 minecraft:orange_terracotta
fill 494 286 497 500 286 497 minecraft:terracotta
setblock 497 286 464 minecraft:terracotta
setblock 497 286 466 minecraft:light[level=14]
fill 497 286 472 501 286 472 minecraft:terracotta
setblock 497 286 473 minecraft:orange_terracotta
setblock 497 286 474 minecraft:light[level=14]
setblock 497 286 482 minecraft:light[level=14]
setblock 497 286 490 minecraft:light[level=14]
setblock 497 286 495 minecraft:orange_terracotta
fill 497 286 496 501 286 496 minecraft:terracotta
fill 498 286 473 502 286 473 minecraft:terracotta
fill 498 286 474 499 286 474 minecraft:orange_terracotta
fill 498 286 494 499 286 494 minecraft:orange_terracotta
fill 498 286 495 502 286 495 minecraft:terracotta
fill 500 286 474 503 286 474 minecraft:terracotta
setblock 500 286 475 minecraft:orange_terracotta
setblock 500 286 493 minecraft:orange_terracotta
fill 500 286 494 503 286 494 minecraft:terracotta
fill 501 286 475 504 286 475 minecraft:terracotta
fill 501 286 476 501 286 477 minecraft:orange_terracotta
fill 501 286 491 501 286 492 minecraft:orange_terracotta
fill 501 286 493 504 286 493 minecraft:terracotta
fill 502 286 476 505 286 477 minecraft:terracotta
fill 502 286 478 502 286 479 minecraft:orange_terracotta
fill 502 286 489 502 286 490 minecraft:orange_terracotta
fill 502 286 491 505 286 492 minecraft:terracotta
fill 503 286 478 509 286 478 minecraft:terracotta
fill 503 286 479 503 286 483 minecraft:orange_terracotta
fill 503 286 485 503 286 489 minecraft:orange_terracotta
fill 503 286 490 506 286 490 minecraft:terracotta
fill 504 286 479 506 286 483 minecraft:terracotta
setblock 504 286 484 minecraft:orange_terracotta
fill 504 286 485 506 286 489 minecraft:terracotta
setblock 505 286 466 minecraft:light[level=14]
setblock 505 286 474 minecraft:light[level=14]
fill 505 286 484 507 286 484 minecraft:terracotta
setblock 505 286 498 minecraft:light[level=14]
setblock 506 286 504 minecraft:red_terracotta
setblock 507 286 464 minecraft:terracotta
fill 507 286 477 508 300 477 minecraft:terracotta
fill 507 286 479 509 300 480 minecraft:terracotta
fill 507 286 482 507 286 483 minecraft:terracotta
fill 507 286 485 507 286 486 minecraft:terracotta
setblock 507 286 503 minecraft:red_terracotta
setblock 507 286 504 minecraft:terracotta
fill 508 286 464 508 289 464 minecraft:red_terracotta
setblock 508 286 503 minecraft:terracotta
fill 508 286 504 508 289 504 minecraft:red_terracotta
setblock 509 286 497 minecraft:terracotta
fill 509 286 498 509 286 501 minecraft:red_terracotta
setblock 509 286 502 minecraft:terracotta
fill 509 286 503 509 289 503 minecraft:red_terracotta
setblock 510 286 471 minecraft:terracotta
fill 510 286 472 510 286 475 minecraft:red_terracotta
setblock 510 286 476 minecraft:terracotta
fill 510 286 477 510 289 477 minecraft:red_terracotta
fill 510 286 493 510 286 495 minecraft:red_terracotta
setblock 510 286 496 minecraft:terracotta
fill 510 286 497 510 289 497 minecraft:red_terracotta
fill 510 286 499 510 286 500 minecraft:red_terracotta
setblock 510 286 501 minecraft:terracotta
fill 510 286 502 510 289 502 minecraft:red_terracotta
setblock 511 286 465 minecraft:terracotta
fill 511 286 466 511 286 469 minecraft:red_terracotta
setblock 511 286 470 minecraft:terracotta
fill 511 286 471 511 286 474 minecraft:red_terracotta
setblock 511 286 475 minecraft:terracotta
fill 511 286 476 511 289 476 minecraft:red_terracotta
setblock 511 286 479 minecraft:red_terracotta
setblock 511 286 480 minecraft:terracotta
fill 511 286 481 511 289 481 minecraft:red_terracotta
setblock 511 286 490 minecraft:terracotta
fill 511 286 491 511 286 494 minecraft:red_terracotta
setblock 511 286 495 minecraft:terracotta
fill 511 286 496 511 289 496 minecraft:red_terracotta
setblock 511 286 499 minecraft:red_terracotta
setblock 511 286 500 minecraft:terracotta
fill 511 286 501 511 289 501 minecraft:red_terracotta
fill 471 287 471 471 287 473 minecraft:red_terracotta
setblock 471 287 474 minecraft:terracotta
fill 471 287 475 471 287 478 minecraft:red_terracotta
setblock 471 287 479 minecraft:terracotta
fill 471 287 480 471 287 483 minecraft:red_terracotta
setblock 471 287 484 minecraft:terracotta
fill 471 287 485 471 287 488 minecraft:red_terracotta
setblock 471 287 489 minecraft:terracotta
fill 471 287 490 471 287 493 minecraft:red_terracotta
setblock 471 287 494 minecraft:terracotta
fill 471 287 495 471 287 498 minecraft:red_terracotta
setblock 471 287 499 minecraft:terracotta
fill 471 287 500 471 287 503 minecraft:red_terracotta
setblock 471 287 504 minecraft:terracotta
fill 472 287 474 472 287 477 minecraft:red_terracotta
setblock 472 287 478 minecraft:terracotta
fill 472 287 479 472 290 479 minecraft:red_terracotta
setblock 472 287 483 minecraft:terracotta
fill 472 287 490 472 287 492 minecraft:red_terracotta
setblock 472 287 493 minecraft:terracotta
fill 472 287 494 472 287 497 minecraft:red_terracotta
setblock 472 287 498 minecraft:terracotta
fill 472 287 499 472 290 499 minecraft:red_terracotta
setblock 472 287 502 minecraft:red_terracotta
setblock 472 287 503 minecraft:terracotta
fill 472 287 504 475 287 504 minecraft:red_terracotta
fill 473 287 493 473 287 496 minecraft:red_terracotta
setblock 473 287 497 minecraft:terracotta
fill 473 287 498 473 290 498 minecraft:red_terracotta
setblock 473 287 502 minecraft:terracotta
fill 473 287 503 473 290 503 minecraft:red_terracotta
setblock 474 287 497 minecraft:red_terracotta
setblock 474 287 502 minecraft:red_terracotta
fill 475 287 503 475 288 503 minecraft:red_terracotta
setblock 476 287 504 minecraft:terracotta
fill 485 287 470 485 288 470 minecraft:brown_terracotta
fill 486 287 468 486 288 469 minecraft:brown_terracotta
fill 486 287 470 491 300 470 minecraft:terracotta
fill 486 287 471 486 288 472 minecraft:brown_terracotta
fill 487 287 467 487 288 468 minecraft:brown_terracotta
fill 487 287 469 490 300 469 minecraft:terracotta
fill 487 287 471 488 300 472 minecraft:terracotta
fill 487 287 473 490 288 473 minecraft:brown_terracotta
fill 488 287 467 490 288 467 minecraft:brown_terracotta
fill 488 287 468 489 300 468 minecraft:terracotta
fill 489 287 471 490 300 471 minecraft:terracotta
setblock 490 287 464 minecraft:red_terracotta
fill 490 287 468 491 288 468 minecraft:brown_terracotta
setblock 490 287 504 minecraft:red_terracotta
setblock 491 287 464 minecraft:terracotta
fill 491 287 469 491 288 469 minecraft:brown_terracotta
fill 491 287 471 491 288 472 minecraft:brown_terracotta
setblock 491 287 504 minecraft:terracotta
fill 492 287 464 495 287 464 minecraft:red_terracotta
fill 492 287 470 492 288 470 minecraft:brown_terracotta
fill 492 287 504 492 290 504 minecraft:red_terracotta
fill 494 287 504 495 287 504 minecraft:red_terracotta
setblock 496 287 464 minecraft:terracotta
fill 505 287 478 505 288 479 minecraft:brown_terracotta
setblock 505 287 504 minecraft:red_terracotta
setblock 506 287 464 minecraft:terracotta
fill 506 287 477 506 288 477 minecraft:brown_terracotta
fill 506 287 478 506 300 480 minecraft:terracotta
fill 506 287 481 509 288 481 minecraft:brown_terracotta
setblock 506 287 504 minecraft:terracotta
fill 507 287 464 507 290 464 minecraft:red_terracotta
fill 507 287 476 508 288 476 minecraft:brown_terracotta
fill 507 287 478 509 300 478 minecraft:terracotta
setblock 507 287 503 minecraft:terracotta
fill 507 287 504 507 290 504 minecraft:red_terracotta
fill 508 287 503 508 290 503 minecraft:red_terracotta
fill 509 287 464 510 287 464 minecraft:red_terracotta
fill 509 287 477 509 288 477 minecraft:brown_terracotta
fill 509 287 497 509 287 500 minecraft:red_terracotta
setblock 509 287 501 minecraft:terracotta
fill 509 287 502 509 290 502 minecraft:red_terracotta
fill 510 287 473 510 287 474 minecraft:red_terracotta
setblock 510 287 475 minecraft:terracotta
fill 510 287 476 510 289 476 minecraft:red_terracotta
fill 510 287 479 510 287 480 minecraft:brown_terracotta
setblock 510 287 494 minecraft:red_terracotta
setblock 510 287 495 minecraft:terracotta
fill 510 287 496 510 290 496 minecraft:red_terracotta
setblock 510 287 499 minecraft:red_terracotta
setblock 510 287 500 minecraft:terracotta
fill 510 287 501 510 290 501 minecraft:red_terracotta
setblock 510 287 504 minecraft:red_terracotta
setblock 511 287 464 minecraft:terracotta
fill 511 287 465 511 287 468 minecraft:red_terracotta
setblock 511 287 469 minecraft:terracotta
fill 511 287 470 511 287 473 minecraft:red_terracotta
setblock 511 287 474 minecraft:terracotta
fill 511 287 475 511 290 475 minecraft:red_terracotta
setblock 511 287 479 minecraft:terracotta
fill 511 287 480 511 290 480 minecraft:red_terracotta
fill 511 287 491 511 287 493 minecraft:red_terracotta
setblock 511 287 494 minecraft:terracotta
fill 511 287 495 511 290 495 minecraft:red_terracotta
setblock 511 287 499 minecraft:terracotta
fill 511 287 500 511 290 500 minecraft:red_terracotta
setblock 511 287 504 minecraft:terracotta
setblock 471 288 472 minecraft:red_terracotta
setblock 471 288 473 minecraft:terracotta
fill 471 288 474 471 288 477 minecraft:red_terracotta
setblock 471 288 478 minecraft:terracotta
fill 471 288 479 471 288 482 minecraft:red_terracotta
setblock 471 288 483 minecraft:terracotta
fill 471 288 484 471 288 487 minecraft:red_terracotta
setblock 471 288 488 minecraft:terracotta
fill 471 288 489 471 288 492 minecraft:red_terracotta
setblock 471 288 493 minecraft:terracotta
fill 471 288 494 471 288 497 minecraft:red_terracotta
setblock 471 288 498 minecraft:terracotta
fill 471 288 499 471 288 502 minecraft:red_terracotta
setblock 471 288 503 minecraft:terracotta
fill 471 288 504 474 288 504 minecraft:red_terracotta
setblock 472 288 476 minecraft:red_terracotta
setblock 472 288 477 minecraft:terracotta
fill 472 288 478 472 291 478 minecraft:red_terracotta
setblock 472 288 482 minecraft:terracotta
fill 472 288 483 472 291 483 minecraft:red_terracotta
fill 472 288 490 472 288 491 minecraft:red_terracotta
setblock 472 288 492 minecraft:terracotta
fill 472 288 493 472 288 496 minecraft:red_terracotta
setblock 472 288 497 minecraft:terracotta
fill 472 288 498 472 291 498 minecraft:red_terracotta
setblock 472 288 501 minecraft:red_terracotta
setblock 472 288 502 minecraft:terracotta
fill 472 288 503 472 291 503 minecraft:red_terracotta
fill 473 288 494 473 288 495 minecraft:red_terracotta
setblock 473 288 496 minecraft:terracotta
fill 473 288 497 473 290 497 minecraft:red_terracotta
setblock 473 288 501 minecraft:terracotta
fill 473 288 502 473 291 502 minecraft:red_terracotta
setblock 475 288 504 minecraft:terracotta
fill 476 288 504 476 291 504 minecraft:red_terracotta
fill 484 288 470 484 288 471 minecraft:brown_terracotta
fill 485 288 468 485 288 469 minecraft:brown_terracotta
fill 485 288 471 485 288 473 minecraft:brown_terracotta
setblock 486 288 467 minecraft:brown_terracotta
fill 486 288 473 486 288 474 minecraft:brown_terracotta
fill 487 288 466 490 288 466 minecraft:brown_terracotta
fill 487 288 474 491 288 474 minecraft:brown_terracotta
setblock 489 288 504 minecraft:red_terracotta
setblock 490 288 464 minecraft:terracotta
setblock 490 288 504 minecraft:terracotta
fill 491 288 464 494 288 464 minecraft:red_terracotta
setblock 491 288 467 minecraft:brown_terracotta
fill 491 288 473 492 288 473 minecraft:brown_terracotta
fill 491 288 504 491 291 504 minecraft:red_terracotta
fill 492 288 468 492 288 469 minecraft:brown_terracotta
fill 492 288 471 492 288 472 minecraft:brown_terracotta
fill 493 288 470 493 288 471 minecraft:brown_terracotta
setblock 494 288 504 minecraft:red_terracotta
setblock 495 288 464 minecraft:terracotta
setblock 495 288 504 minecraft:terracotta
fill 496 288 464 496 291 464 minecraft:red_terracotta
fill 504 288 478 504 288 479 minecraft:brown_terracotta
setblock 504 288 504 minecraft:red_terracotta
setblock 505 288 477 minecraft:brown_terracotta
fill 505 288 480 505 288 481 minecraft:brown_terracotta
setblock 505 288 504 minecraft:terracotta
fill 506 288 464 506 291 464 minecraft:red_terracotta
setblock 506 288 476 minecraft:brown_terracotta
fill 506 288 482 509 288 482 minecraft:brown_terracotta
setblock 506 288 503 minecraft:terracotta
fill 506 288 504 506 291 504 minecraft:red_terracotta
fill 507 288 503 507 291 503 minecraft:red_terracotta
fill 508 288 502 508 291 502 minecraft:red_terracotta
setblock 509 288 464 minecraft:red_terracotta
setblock 509 288 476 minecraft:brown_terracotta
fill 509 288 497 509 288 499 minecraft:red_terracotta
setblock 509 288 500 minecraft:terracotta
fill 509 288 501 509 291 501 minecraft:red_terracotta
setblock 510 288 464 minecraft:terracotta
setblock 510 288 475 minecraft:red_terracotta
setblock 510 288 478 minecraft:red_terracotta
setblock 510 288 479 minecraft:terracotta
fill 510 288 480 510 288 481 minecraft:brown_terracotta
setblock 510 288 494 minecraft:terracotta
fill 510 288 495 510 291 495 minecraft:red_terracotta
setblock 510 288 498 minecraft:red_terracotta
setblock 510 288 499 minecraft:terracotta
fill 510 288 500 510 291 500 minecraft:red_terracotta
setblock 510 288 504 minecraft:terracotta
fill 511 288 464 511 288 467 minecraft:red_terracotta
setblock 511 288 468 minecraft:terracotta
fill 511 288 469 511 288 472 minecraft:red_terracotta
setblock 511 288 473 minecraft:terracotta
fill 511 288 474 511 291 474 minecraft:red_terracotta
setblock 511 288 478 minecraft:terracotta
fill 511 288 479 511 291 479 minecraft:red_terracotta
setblock 511 288 483 minecraft:terracotta
fill 511 288 491 511 288 492 minecraft:red_terracotta
setblock 511 288 493 minecraft:terracotta
fill 511 288 494 511 291 494 minecraft:red_terracotta
setblock 511 288 498 minecraft:terracotta
fill 511 288 499 511 291 499 minecraft:red_terracotta
setblock 511 288 503 minecraft:terracotta
fill 511 288 504 511 291 504 minecraft:red_terracotta
fill 471 289 473 471 289 476 minecraft:red_terracotta
setblock 471 289 477 minecraft:terracotta
fill 471 289 478 471 289 481 minecraft:red_terracotta
setblock 471 289 482 minecraft:terracotta
fill 471 289 483 471 289 486 minecraft:red_terracotta
setblock 471 289 487 minecraft:terracotta
fill 471 289 488 471 289 491 minecraft:red_terracotta
setblock 471 289 492 minecraft:terracotta
fill 471 289 493 471 289 496 minecraft:red_terracotta
setblock 471 289 497 minecraft:terracotta
fill 471 289 498 471 289 501 minecraft:red_terracotta
setblock 471 289 502 minecraft:terracotta
fill 471 289 503 471 291 504 minecraft:red_terracotta
setblock 472 289 476 minecraft:terracotta
fill 472 289 477 472 292 477 minecraft:red_terracotta
setblock 472 289 481 minecraft:terracotta
fill 472 289 482 472 292 482 minecraft:red_terracotta
fill 472 289 484 472 289 485 minecraft:red_terracotta
setblock 472 289 491 minecraft:terracotta
fill 472 289 492 472 289 495 minecraft:red_terracotta
setblock 472 289 496 minecraft:terracotta
fill 472 289 497 472 292 497 minecraft:red_terracotta
setblock 472 289 501 minecraft:terracotta
fill 472 289 502 472 292 502 minecraft:red_terracotta
fill 472 289 504 473 289 504 minecraft:red_terracotta
setblock 473 289 495 minecraft:terracotta
setblock 473 289 496 minecraft:red_terracotta
setblock 473 289 500 minecraft:terracotta
fill 473 289 501 473 292 501 minecraft:red_terracotta
setblock 474 289 504 minecraft:terracotta
setblock 475 289 503 minecraft:terracotta
fill 475 289 504 475 292 504 minecraft:red_terracotta
setblock 488 289 504 minecraft:red_terracotta
setblock 489 289 464 minecraft:terracotta
setblock 489 289 504 minecraft:terracotta
fill 490 289 464 493 289 464 minecraft:red_terracotta
fill 490 289 504 490 292 504 minecraft:red_terracotta
setblock 494 289 464 minecraft:terracotta
setblock 494 289 504 minecraft:terracotta
fill 495 289 464 495 292 464 minecraft:red_terracotta
fill 495 289 504 496 291 504 minecraft:red_terracotta
setblock 503 289 504 minecraft:red_terracotta
setblock 504 289 504 minecraft:terracotta
fill 505 289 464 505 292 464 minecraft:red_terracotta
setblock 505 289 503 minecraft:terracotta
fill 505 289 504 505 292 504 minecraft:red_terracotta
fill 506 289 503 506 292 503 minecraft:red_terracotta
fill 507 289 502 507 292 502 minecraft:red_terracotta
setblock 509 289 464 minecraft:terracotta
fill 509 289 497 509 289 498 minecraft:red_terracotta
setblock 509 289 499 minecraft:terracotta
fill 509 289 500 509 292 500 minecraft:red_terracotta
setblock 509 289 504 minecraft:terracotta
fill 510 289 464 511 291 464 minecraft:red_terracotta
setblock 510 289 478 minecraft:terracotta
fill 510 289 479 510 292 479 minecraft:red_terracotta
fill 510 289 494 510 292 494 minecraft:red_terracotta
setblock 510 289 498 minecraft:terracotta
fill 510 289 499 510 292 499 minecraft:red_terracotta
setblock 510 289 503 minecraft:terracotta
fill 510 289 504 510 292 504 minecraft:red_terracotta
fill 511 289 465 511 289 466 minecraft:red_terracotta
setblock 511 289 467 minecraft:terracotta
setblock 511 289 471 minecraft:red_terracotta
setblock 511 289 472 minecraft:terracotta
fill 511 289 473 511 291 473 minecraft:red_terracotta
setblock 511 289 477 minecraft:terracotta
fill 511 289 478 511 292 478 minecraft:red_terracotta
setblock 511 289 482 minecraft:terracotta
fill 511 289 483 511 291 484 minecraft:red_terracotta
setblock 511 289 491 minecraft:red_terracotta
setblock 511 289 492 minecraft:terracotta
fill 511 289 493 511 292 493 minecraft:red_terracotta
setblock 511 289 497 minecraft:terracotta
fill 511 289 498 511 292 498 minecraft:red_terracotta
setblock 511 289 502 minecraft:terracotta
fill 511 289 503 511 292 503 minecraft:red_terracotta
fill 471 290 464 471 291 464 minecraft:red_terracotta
fill 471 290 474 471 290 475 minecraft:red_terracotta
setblock 471 290 476 minecraft:terracotta
fill 471 290 477 471 290 480 minecraft:red_terracotta
setblock 471 290 481 minecraft:terracotta
fill 471 290 482 471 290 485 minecraft:red_terracotta
setblock 471 290 486 minecraft:terracotta
fill 471 290 487 471 290 490 minecraft:red_terracotta
setblock 471 290 491 minecraft:terracotta
fill 471 290 492 471 290 495 minecraft:red_terracotta
setblock 471 290 496 minecraft:terracotta
fill 471 290 497 471 290 500 minecraft:red_terracotta
setblock 471 290 501 minecraft:terracotta
fill 471 290 502 471 293 502 minecraft:red_terracotta
setblock 472 290 480 minecraft:terracotta
fill 472 290 481 472 293 481 minecraft:red_terracotta
setblock 472 290 484 minecraft:red_terracotta
setblock 472 290 485 minecraft:terracotta
fill 472 290 486 472 293 486 minecraft:red_terracotta
fill 472 290 492 472 290 494 minecraft:red_terracotta
setblock 472 290 495 minecraft:terracotta
fill 472 290 496 472 293 496 minecraft:red_terracotta
setblock 472 290 500 minecraft:terracotta
fill 472 290 501 472 293 501 minecraft:red_terracotta
setblock 472 290 504 minecraft:red_terracotta
setblock 473 290 499 minecraft:terracotta
fill 473 290 500 473 292 500 minecraft:red_terracotta
setblock 473 290 504 minecraft:terracotta
setblock 474 290 503 minecraft:terracotta
fill 474 290 504 474 293 504 minecraft:red_terracotta
setblock 487 290 504 minecraft:red_terracotta
setblock 488 290 464 minecraft:terracotta
setblock 488 290 504 minecraft:terracotta
fill 489 290 464 492 290 464 minecraft:red_terracotta
fill 489 290 504 489 293 504 minecraft:red_terracotta
fill 490 290 503 492 291 503 minecraft:red_terracotta
setblock 493 290 464 minecraft:terracotta
setblock 493 290 504 minecraft:terracotta
fill 494 290 464 494 293 464 minecraft:red_terracotta
fill 494 290 504 494 293 504 minecraft:red_terracotta
setblock 497 290 464 minecraft:red_terracotta
setblock 497 290 504 minecraft:red_terracotta
fill 501 290 504 502 290 504 minecraft:red_terracotta
setblock 503 290 464 minecraft:terracotta
setblock 503 290 504 minecraft:terracotta
fill 504 290 464 504 293 464 minecraft:red_terracotta
setblock 504 290 503 minecraft:terracotta
fill 504 290 504 504 293 504 minecraft:red_terracotta
fill 505 290 503 505 293 503 minecraft:red_terracotta
fill 506 290 502 506 293 502 minecraft:red_terracotta
setblock 508 290 464 minecraft:terracotta
setblock 508 290 504 minecraft:terracotta
fill 509 290 464 509 293 464 minecraft:red_terracotta
setblock 509 290 497 minecraft:red_terracotta
setblock 509 290 498 minecraft:terracotta
fill 509 290 499 509 293 499 minecraft:red_terracotta
setblock 509 290 503 minecraft:terracotta
fill 509 290 504 509 293 504 minecraft:red_terracotta
setblock 510 290 477 minecraft:terracotta
fill 510 290 478 510 293 478 minecraft:red_terracotta
fill 510 290 480 510 290 481 minecraft:red_terracotta
setblock 510 290 497 minecraft:terracotta
fill 510 290 498 510 293 498 minecraft:red_terracotta
setblock 510 290 502 minecraft:terracotta
fill 510 290 503 510 293 503 minecraft:red_terracotta
setblock 511 290 465 minecraft:red_terracotta
setblock 511 290 466 minecraft:terracotta
fill 511 290 467 511 293 467 minecraft:red_terracotta
setblock 511 290 476 minecraft:terracotta
fill 511 290 477 511 293 477 minecraft:red_terracotta
setblock 511 290 481 minecraft:terracotta
fill 511 290 482 511 293 482 minecraft:red_terracotta
setblock 511 290 485 minecraft:red_terracotta
setblock 511 290 486 minecraft:terracotta
setblock 511 290 491 minecraft:terracotta
fill 511 290 492 511 293 492 minecraft:red_terracotta
setblock 511 290 496 minecraft:terracotta
fill 511 290 497 511 293 497 minecraft:red_terracotta
setblock 511 290 501 minecraft:terracotta
fill 511 290 502 511 293 502 minecraft:red_terracotta
setblock 471 291 474 minecraft:red_terracotta
setblock 471 291 475 minecraft:terracotta
fill 471 291 476 471 291 479 minecraft:red_terracotta
setblock 471 291 480 minecraft:terracotta
fill 471 291 481 471 291 484 minecraft:red_terracotta
setblock 471 291 485 minecraft:terracotta
fill 471 291 486 471 291 489 minecraft:red_terracotta
setblock 471 291 490 minecraft:terracotta
fill 471 291 491 471 291 494 minecraft:red_terracotta
setblock 471 291 495 minecraft:terracotta
fill 471 291 496 471 291 499 minecraft:red_terracotta
setblock 471 291 500 minecraft:terracotta
fill 471 291 501 471 294 501 minecraft:red_terracotta
setblock 472 291 479 minecraft:terracotta
fill 472 291 480 472 294 480 minecraft:red_terracotta
setblock 472 291 484 minecraft:terracotta
fill 472 291 485 472 294 485 minecraft:red_terracotta
fill 472 291 487 472 291 488 minecraft:red_terracotta
setblock 472 291 489 minecraft:terracotta
fill 472 291 492 472 291 493 minecraft:red_terracotta
setblock 472 291 494 minecraft:terracotta
fill 472 291 495 472 294 495 minecraft:red_terracotta
setblock 472 291 499 minecraft:terracotta
fill 472 291 500 472 294 500 minecraft:red_terracotta
setblock 472 291 504 minecraft:terracotta
setblock 473 291 498 minecraft:terracotta
fill 473 291 499 473 292 499 minecraft:red_terracotta
setblock 473 291 503 minecraft:terracotta
fill 473 291 504 473 294 504 minecraft:red_terracotta
fill 474 291 503 474 294 503 minecraft:red_terracotta
fill 485 291 504 486 291 504 minecraft:red_terracotta
setblock 486 291 464 minecraft:red_terracotta
setblock 487 291 464 minecraft:terracotta
setblock 487 291 504 minecraft:terracotta
fill 488 291 464 491 291 464 minecraft:red_terracotta
setblock 488 291 503 minecraft:terracotta
fill 488 291 504 488 294 504 minecraft:red_terracotta
fill 489 291 465 490 291 465 minecraft:red_terracotta
fill 489 291 503 489 294 503 minecraft:red_terracotta
setblock 491 291 465 minecraft:terracotta
setblock 492 291 464 minecraft:terracotta
fill 492 291 465 493 293 465 minecraft:red_terracotta
setblock 492 291 504 minecraft:terracotta
fill 493 291 464 493 294 464 minecraft:red_terracotta
setblock 493 291 503 minecraft:terracotta
fill 493 291 504 493 294 504 minecraft:red_terracotta
fill 495 291 476 496 292 476 minecraft:orange_concrete
setblock 497 291 464 minecraft:terracotta
setblock 497 291 504 minecraft:terracotta
fill 498 291 464 501 291 464 minecraft:red_terracotta
fill 498 291 504 501 291 504 minecraft:red_terracotta
setblock 502 291 464 minecraft:terracotta
setblock 502 291 504 minecraft:terracotta
fill 503 291 464 503 294 464 minecraft:red_terracotta
setblock 503 291 503 minecraft:terracotta
fill 503 291 504 503 294 504 minecraft:red_terracotta
fill 504 291 503 504 294 503 minecraft:red_terracotta
fill 505 291 502 505 294 502 minecraft:red_terracotta
setblock 507 291 464 minecraft:terracotta
fill 507 291 465 510 291 465 minecraft:red_terracotta
setblock 507 291 504 minecraft:terracotta
fill 508 291 464 508 294 464 minecraft:red_terracotta
fill 508 291 500 508 292 501 minecraft:red_terracotta
setblock 508 291 503 minecraft:terracotta
fill 508 291 504 508 294 504 minecraft:red_terracotta
setblock 509 291 497 minecraft:terracotta
fill 509 291 498 509 294 498 minecraft:red_terracotta
setblock 509 291 502 minecraft:terracotta
fill 509 291 503 509 294 503 minecraft:red_terracotta
fill 510 291 477 510 293 477 minecraft:red_terracotta
setblock 510 291 480 minecraft:red_terracotta
setblock 510 291 481 minecraft:terracotta
fill 510 291 482 510 293 483 minecraft:red_terracotta
setblock 510 291 496 minecraft:terracotta
fill 510 291 497 510 294 497 minecraft:red_terracotta
setblock 510 291 501 minecraft:terracotta
fill 510 291 502 510 294 502 minecraft:red_terracotta
setblock 511 291 465 minecraft:terracotta
fill 511 291 466 511 294 466 minecraft:red_terracotta
setblock 511 291 475 minecraft:terracotta
fill 511 291 476 511 294 476 minecraft:red_terracotta
setblock 511 291 480 minecraft:terracotta
fill 511 291 481 511 294 481 minecraft:red_terracotta
setblock 511 291 485 minecraft:terracotta
fill 511 291 486 511 291 489 minecraft:red_terracotta
setblock 511 291 490 minecraft:terracotta
fill 511 291 491 511 294 491 minecraft:red_terracotta
setblock 511 291 495 minecraft:terracotta
fill 511 291 496 511 294 496 minecraft:red_terracotta
setblock 511 291 500 minecraft:terracotta
fill 511 291 501 511 294 501 minecraft:red_terracotta
setblock 471 292 464 minecraft:terracotta
fill 471 292 465 471 295 465 minecraft:red_terracotta
setblock 471 292 474 minecraft:terracotta
fill 471 292 475 471 292 478 minecraft:red_terracotta
setblock 471 292 479 minecraft:terracotta
fill 471 292 480 471 292 483 minecraft:red_terracotta
setblock 471 292 484 minecraft:terracotta
fill 471 292 485 471 292 488 minecraft:red_terracotta
setblock 471 292 489 minecraft:terracotta
fill 471 292 490 471 292 493 minecraft:red_terracotta
setblock 471 292 494 minecraft:terracotta
fill 471 292 495 471 292 498 minecraft:red_terracotta
setblock 471 292 499 minecraft:terracotta
fill 471 292 500 471 295 500 minecraft:red_terracotta
setblock 471 292 503 minecraft:red_terracotta
setblock 471 292 504 minecraft:terracotta
fill 472 292 464 472 295 464 minecraft:red_terracotta
setblock 472 292 478 minecraft:terracotta
fill 472 292 479 472 295 479 minecraft:red_terracotta
setblock 472 292 483 minecraft:terracotta
fill 472 292 484 473 294 484 minecraft:red_terracotta
setblock 472 292 487 minecraft:red_terracotta
setblock 472 292 488 minecraft:terracotta
fill 472 292 489 472 292 492 minecraft:red_terracotta
setblock 472 292 493 minecraft:terracotta
fill 472 292 494 472 295 494 minecraft:red_terracotta
setblock 472 292 498 minecraft:terracotta
fill 472 292 499 472 295 499 minecraft:red_terracotta
setblock 472 292 503 minecraft:terracotta
fill 472 292 504 472 295 504 minecraft:red_terracotta
setblock 473 292 481 minecraft:red_terracotta
setblock 473 292 482 minecraft:terracotta
fill 473 292 483 473 295 483 minecraft:red_terracotta
setblock 473 292 502 minecraft:terracotta
fill 473 292 503 473 295 503 minecraft:red_terracotta
setblock 476 292 504 minecraft:terracotta
fill 484 292 504 485 292 504 minecraft:red_terracotta
setblock 485 292 464 minecraft:red_terracotta
setblock 486 292 464 minecraft:terracotta
setblock 486 292 503 minecraft:red_terracotta
setblock 486 292 504 minecraft:terracotta
fill 487 292 464 489 292 465 minecraft:red_terracotta
setblock 487 292 503 minecraft:terracotta
fill 487 292 504 487 295 504 minecraft:red_terracotta
fill 488 292 503 488 295 503 minecraft:red_terracotta
setblock 490 292 464 minecraft:red_terracotta
setblock 490 292 465 minecraft:terracotta
fill 490 292 503 491 292 503 minecraft:red_terracotta
setblock 491 292 464 minecraft:terracotta
fill 491 292 465 491 295 465 minecraft:red_terracotta
setblock 491 292 504 minecraft:terracotta
fill 492 292 464 492 295 464 minecraft:red_terracotta
setblock 492 292 503 minecraft:terracotta
fill 492 292 504 492 295 504 minecraft:red_terracotta
fill 493 292 503 494 294 503 minecraft:red_terracotta
setblock 494 292 465 minecraft:red_terracotta
setblock 495 292 504 minecraft:red_terracotta
setblock 496 292 464 minecraft:terracotta
setblock 496 292 504 minecraft:terracotta
fill 497 292 464 500 292 464 minecraft:red_terracotta
fill 497 292 504 500 292 504 minecraft:red_terracotta
setblock 501 292 464 minecraft:terracotta
setblock 501 292 503 minecraft:red_terracotta
setblock 501 292 504 minecraft:terracotta
fill 502 292 464 502 295 464 minecraft:red_terracotta
setblock 502 292 503 minecraft:terracotta
fill 502 292 504 502 295 504 minecraft:red_terracotta
fill 503 292 503 503 295 503 minecraft:red_terracotta
setblock 504 292 465 minecraft:red_terracotta
fill 504 292 502 504 295 502 minecraft:red_terracotta
setblock 505 292 465 minecraft:terracotta
setblock 506 292 464 minecraft:terracotta
fill 506 292 465 509 292 465 minecraft:red_terracotta
setblock 506 292 504 minecraft:terracotta
fill 507 292 464 507 295 464 minecraft:red_terracotta
fill 507 292 501 507 293 501 minecraft:red_terracotta
setblock 507 292 503 minecraft:terracotta
fill 507 292 504 507 295 504 minecraft:red_terracotta
setblock 508 292 502 minecraft:terracotta
fill 508 292 503 508 295 503 minecraft:red_terracotta
fill 509 292 497 509 295 497 minecraft:red_terracotta
setblock 509 292 501 minecraft:terracotta
fill 509 292 502 509 295 502 minecraft:red_terracotta
setblock 510 292 464 minecraft:red_terracotta
setblock 510 292 465 minecraft:terracotta
fill 510 292 466 510 295 466 minecraft:red_terracotta
setblock 510 292 480 minecraft:terracotta
fill 510 292 481 510 295 481 minecraft:red_terracotta
setblock 510 292 484 minecraft:red_terracotta
setblock 510 292 485 minecraft:terracotta
setblock 510 292 495 minecraft:terracotta
fill 510 292 496 510 295 496 minecraft:red_terracotta
setblock 510 292 500 minecraft:terracotta
fill 510 292 501 510 295 501 minecraft:red_terracotta
setblock 511 292 464 minecraft:terracotta
fill 511 292 465 511 295 465 minecraft:red_terracotta
setblock 511 292 468 minecraft:red_terracotta
setblock 511 292 474 minecraft:terracotta
fill 511 292 475 511 294 475 minecraft:red_terracotta
setblock 511 292 479 minecraft:terracotta
fill 511 292 480 511 295 480 minecraft:red_terracotta
setblock 511 292 483 minecraft:red_terracotta
setblock 511 292 484 minecraft:terracotta
fill 511 292 485 511 292 488 minecraft:red_terracotta
setblock 511 292 489 minecraft:terracotta
fill 511 292 490 511 295 490 minecraft:red_terracotta
setblock 511 292 494 minecraft:terracotta
fill 511 292 495 511 295 495 minecraft:red_terracotta
setblock 511 292 499 minecraft:terracotta
fill 511 292 500 511 295 500 minecraft:red_terracotta
setblock 511 292 504 minecraft:terracotta
fill 471 293 464 471 296 464 minecraft:red_terracotta
fill 471 293 466 471 294 466 minecraft:red_terracotta
fill 471 293 474 471 293 477 minecraft:red_terracotta
setblock 471 293 478 minecraft:terracotta
fill 471 293 479 471 293 482 minecraft:red_terracotta
setblock 471 293 483 minecraft:terracotta
fill 471 293 484 471 293 487 minecraft:red_terracotta
setblock 471 293 488 minecraft:terracotta
fill 471 293 489 471 293 492 minecraft:red_terracotta
setblock 471 293 493 minecraft:terracotta
fill 471 293 494 471 293 497 minecraft:red_terracotta
setblock 471 293 498 minecraft:terracotta
fill 471 293 499 471 296 499 minecraft:red_terracotta
setblock 471 293 503 minecraft:terracotta
fill 471 293 504 471 296 504 minecraft:red_terracotta
setblock 472 293 477 minecraft:terracotta
fill 472 293 478 472 296 478 minecraft:red_terracotta
setblock 472 293 482 minecraft:terracotta
fill 472 293 483 472 296 483 minecraft:red_terracotta
setblock 472 293 487 minecraft:terracotta
fill 472 293 488 472 293 491 minecraft:red_terracotta
setblock 472 293 492 minecraft:terracotta
fill 472 293 493 472 296 493 minecraft:red_terracotta
setblock 472 293 497 minecraft:terracotta
fill 472 293 498 472 296 498 minecraft:red_terracotta
setblock 472 293 502 minecraft:terracotta
fill 472 293 503 472 296 503 minecraft:red_terracotta
fill 473 293 464 473 294 464 minecraft:red_terracotta
setblock 473 293 480 minecraft:red_terracotta
setblock 473 293 481 minecraft:terracotta
fill 473 293 482 473 296 482 minecraft:red_terracotta
setblock 473 293 485 minecraft:red_terracotta
setblock 475 293 504 minecraft:terracotta
fill 476 293 504 477 295 504 minecraft:red_terracotta
fill 482 293 504 484 293 504 minecraft:red_terracotta
fill 483 293 464 484 293 464 minecraft:red_terracotta
setblock 485 293 464 minecraft:terracotta
setblock 485 293 503 minecraft:red_terracotta
setblock 485 293 504 minecraft:terracotta
fill 486 293 464 488 293 465 minecraft:red_terracotta
setblock 486 293 503 minecraft:terracotta
fill 486 293 504 486 296 504 minecraft:red_terracotta
fill 487 293 503 487 296 503 minecraft:red_terracotta
setblock 489 293 464 minecraft:red_terracotta
setblock 489 293 465 minecraft:terracotta
setblock 490 293 464 minecraft:terracotta
fill 490 293 465 490 296 465 minecraft:red_terracotta
setblock 490 293 503 minecraft:red_terracotta
setblock 490 293 504 minecraft:terracotta
fill 491 293 464 491 296 464 minecraft:red_terracotta
setblock 491 293 503 minecraft:terracotta
fill 491 293 504 491 296 504 minecraft:red_terracotta
fill 492 293 503 492 296 503 minecraft:red_terracotta
schedule function dropper:buildpart/118_11 1t
