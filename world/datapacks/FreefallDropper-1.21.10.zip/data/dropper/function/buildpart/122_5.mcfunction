setblock 102 106 550 minecraft:smooth_basalt
fill 102 106 551 102 109 551 minecraft:blackstone
fill 103 106 550 103 109 550 minecraft:blackstone
setblock 105 106 512 minecraft:smooth_basalt
setblock 106 106 511 minecraft:smooth_basalt
fill 106 106 512 106 109 512 minecraft:blackstone
setblock 106 106 551 minecraft:smooth_basalt
fill 107 106 511 107 109 511 minecraft:blackstone
fill 107 106 551 107 109 551 minecraft:blackstone
setblock 120 106 512 minecraft:smooth_basalt
setblock 121 106 511 minecraft:smooth_basalt
fill 121 106 512 121 109 512 minecraft:blackstone
setblock 121 106 551 minecraft:smooth_basalt
fill 122 106 511 122 109 511 minecraft:blackstone
fill 122 106 513 122 107 513 minecraft:blackstone
fill 122 106 551 122 109 551 minecraft:blackstone
setblock 124 106 512 minecraft:blackstone
setblock 124 106 513 minecraft:smooth_basalt
setblock 125 106 512 minecraft:smooth_basalt
fill 125 106 513 125 109 513 minecraft:blackstone
setblock 126 106 511 minecraft:smooth_basalt
fill 126 106 512 126 109 512 minecraft:blackstone
setblock 126 106 551 minecraft:smooth_basalt
fill 127 106 511 127 109 511 minecraft:blackstone
fill 127 106 551 127 109 551 minecraft:blackstone
setblock 129 106 513 minecraft:smooth_basalt
setblock 130 106 512 minecraft:smooth_basalt
setblock 131 106 511 minecraft:smooth_basalt
fill 131 106 512 131 109 512 minecraft:blackstone
setblock 131 106 551 minecraft:smooth_basalt
fill 132 106 511 132 109 511 minecraft:blackstone
fill 132 106 551 132 109 551 minecraft:blackstone
setblock 135 106 512 minecraft:smooth_basalt
fill 135 106 513 135 109 513 minecraft:blackstone
setblock 95 107 511 minecraft:smooth_basalt
fill 95 107 512 95 109 513 minecraft:blackstone
setblock 95 107 535 minecraft:blackstone
setblock 95 107 536 minecraft:smooth_basalt
setblock 95 107 550 minecraft:blackstone
setblock 95 107 551 minecraft:smooth_basalt
fill 96 107 511 96 110 511 minecraft:blackstone
fill 96 107 551 96 110 551 minecraft:blackstone
fill 98 107 512 99 107 514 minecraft:smooth_basalt
setblock 100 107 511 minecraft:smooth_basalt
fill 100 107 512 100 110 512 minecraft:blackstone
fill 100 107 513 100 138 514 minecraft:smooth_basalt
setblock 100 107 551 minecraft:smooth_basalt
fill 101 107 511 101 110 511 minecraft:blackstone
setblock 101 107 550 minecraft:smooth_basalt
fill 101 107 551 101 110 551 minecraft:blackstone
fill 102 107 550 102 110 550 minecraft:blackstone
setblock 104 107 512 minecraft:smooth_basalt
setblock 105 107 511 minecraft:smooth_basalt
fill 105 107 512 105 110 512 minecraft:blackstone
setblock 105 107 551 minecraft:smooth_basalt
fill 106 107 511 106 110 511 minecraft:blackstone
fill 106 107 551 106 110 551 minecraft:blackstone
fill 117 107 511 117 109 511 minecraft:blackstone
setblock 119 107 512 minecraft:smooth_basalt
setblock 120 107 511 minecraft:smooth_basalt
fill 120 107 512 120 110 512 minecraft:blackstone
fill 121 107 511 121 110 511 minecraft:blackstone
fill 121 107 513 121 108 513 minecraft:blackstone
fill 121 107 551 121 110 551 minecraft:blackstone
setblock 123 107 513 minecraft:smooth_basalt
setblock 124 107 512 minecraft:smooth_basalt
fill 124 107 513 124 109 514 minecraft:blackstone
setblock 125 107 511 minecraft:smooth_basalt
fill 125 107 512 125 110 512 minecraft:blackstone
fill 125 107 514 125 108 514 minecraft:blackstone
setblock 125 107 551 minecraft:smooth_basalt
fill 126 107 511 126 110 511 minecraft:blackstone
fill 126 107 551 126 110 551 minecraft:blackstone
setblock 128 107 513 minecraft:smooth_basalt
setblock 129 107 512 minecraft:smooth_basalt
fill 129 107 513 129 110 513 minecraft:blackstone
setblock 130 107 511 minecraft:smooth_basalt
fill 130 107 512 130 110 512 minecraft:blackstone
setblock 130 107 551 minecraft:smooth_basalt
fill 131 107 511 131 110 511 minecraft:blackstone
fill 131 107 551 131 110 551 minecraft:blackstone
setblock 134 107 512 minecraft:smooth_basalt
fill 134 107 513 134 110 513 minecraft:blackstone
setblock 135 107 511 minecraft:smooth_basalt
fill 135 107 512 135 110 512 minecraft:blackstone
setblock 135 107 516 minecraft:smooth_basalt
setblock 135 107 551 minecraft:smooth_basalt
fill 95 108 511 95 111 511 minecraft:blackstone
setblock 95 108 514 minecraft:blackstone
fill 95 108 533 95 108 534 minecraft:blackstone
setblock 95 108 535 minecraft:smooth_basalt
fill 95 108 536 95 108 539 minecraft:blackstone
setblock 95 108 540 minecraft:smooth_basalt
setblock 95 108 550 minecraft:smooth_basalt
fill 95 108 551 95 111 551 minecraft:blackstone
fill 98 108 512 98 108 514 minecraft:smooth_basalt
fill 98 108 550 98 109 550 minecraft:blackstone
setblock 99 108 511 minecraft:smooth_basalt
fill 99 108 512 99 111 512 minecraft:blackstone
fill 99 108 513 99 141 514 minecraft:smooth_basalt
setblock 99 108 551 minecraft:smooth_basalt
fill 100 108 511 100 111 511 minecraft:blackstone
setblock 100 108 550 minecraft:smooth_basalt
fill 100 108 551 100 111 551 minecraft:blackstone
fill 101 108 550 101 111 550 minecraft:blackstone
setblock 103 108 512 minecraft:smooth_basalt
setblock 104 108 511 minecraft:smooth_basalt
fill 104 108 512 104 111 512 minecraft:blackstone
setblock 104 108 551 minecraft:smooth_basalt
fill 105 108 511 105 111 511 minecraft:blackstone
setblock 105 108 550 minecraft:smooth_basalt
fill 105 108 551 105 111 551 minecraft:blackstone
fill 116 108 511 116 110 511 minecraft:blackstone
setblock 118 108 512 minecraft:smooth_basalt
setblock 119 108 511 minecraft:smooth_basalt
fill 119 108 512 119 111 512 minecraft:blackstone
fill 120 108 511 120 111 511 minecraft:blackstone
fill 120 108 513 120 109 513 minecraft:blackstone
fill 120 108 551 120 111 551 minecraft:blackstone
setblock 122 108 513 minecraft:smooth_basalt
fill 122 108 514 123 110 514 minecraft:blackstone
setblock 123 108 512 minecraft:smooth_basalt
fill 123 108 513 123 111 513 minecraft:blackstone
setblock 124 108 511 minecraft:smooth_basalt
fill 124 108 512 124 111 512 minecraft:blackstone
setblock 124 108 551 minecraft:smooth_basalt
fill 125 108 511 125 111 511 minecraft:blackstone
fill 125 108 551 125 111 551 minecraft:blackstone
setblock 126 108 514 minecraft:smooth_basalt
setblock 127 108 513 minecraft:smooth_basalt
setblock 128 108 512 minecraft:smooth_basalt
fill 128 108 513 128 111 513 minecraft:blackstone
setblock 129 108 511 minecraft:smooth_basalt
fill 129 108 512 129 111 512 minecraft:blackstone
setblock 129 108 551 minecraft:smooth_basalt
fill 130 108 511 130 111 511 minecraft:blackstone
fill 130 108 513 130 109 513 minecraft:blackstone
fill 130 108 551 130 111 551 minecraft:blackstone
setblock 133 108 512 minecraft:smooth_basalt
setblock 134 108 511 minecraft:smooth_basalt
fill 134 108 512 134 111 512 minecraft:blackstone
fill 134 108 514 134 109 514 minecraft:blackstone
setblock 134 108 551 minecraft:smooth_basalt
fill 135 108 511 135 111 511 minecraft:blackstone
setblock 135 108 515 minecraft:smooth_basalt
fill 135 108 516 135 110 517 minecraft:blackstone
fill 135 108 551 135 111 551 minecraft:blackstone
setblock 95 109 514 minecraft:smooth_basalt
fill 95 109 515 95 111 516 minecraft:blackstone
fill 95 109 532 95 109 533 minecraft:blackstone
setblock 95 109 534 minecraft:smooth_basalt
fill 95 109 535 95 109 538 minecraft:blackstone
setblock 95 109 539 minecraft:smooth_basalt
fill 95 109 540 95 109 543 minecraft:blackstone
setblock 95 109 548 minecraft:blackstone
setblock 95 109 549 minecraft:smooth_basalt
fill 95 109 550 95 112 550 minecraft:blackstone
fill 96 109 534 96 109 537 minecraft:blackstone
setblock 96 109 538 minecraft:smooth_basalt
fill 96 109 539 96 111 540 minecraft:blackstone
setblock 97 109 512 minecraft:smooth_basalt
setblock 97 109 513 minecraft:light[level=12]
setblock 97 109 521 minecraft:light[level=12]
setblock 97 109 529 minecraft:light[level=12]
setblock 97 109 537 minecraft:light[level=12]
setblock 97 109 545 minecraft:light[level=12]
setblock 98 109 511 minecraft:smooth_basalt
fill 98 109 512 98 112 512 minecraft:blackstone
fill 98 109 513 98 143 514 minecraft:smooth_basalt
setblock 98 109 551 minecraft:smooth_basalt
fill 99 109 511 99 112 511 minecraft:blackstone
setblock 99 109 550 minecraft:smooth_basalt
fill 99 109 551 99 112 551 minecraft:blackstone
fill 100 109 550 100 112 550 minecraft:blackstone
setblock 102 109 512 minecraft:smooth_basalt
setblock 103 109 511 minecraft:smooth_basalt
fill 103 109 512 103 112 512 minecraft:blackstone
setblock 103 109 551 minecraft:smooth_basalt
fill 104 109 511 104 112 511 minecraft:blackstone
setblock 104 109 550 minecraft:smooth_basalt
fill 104 109 551 104 112 551 minecraft:blackstone
setblock 105 109 513 minecraft:light[level=12]
setblock 105 109 521 minecraft:light[level=12]
setblock 105 109 529 minecraft:light[level=12]
setblock 105 109 537 minecraft:light[level=12]
setblock 105 109 545 minecraft:light[level=12]
setblock 108 109 511 minecraft:smooth_basalt
setblock 113 109 513 minecraft:light[level=12]
setblock 113 109 521 minecraft:light[level=12]
setblock 113 109 529 minecraft:light[level=12]
setblock 113 109 537 minecraft:light[level=12]
setblock 113 109 545 minecraft:light[level=12]
fill 115 109 511 115 111 511 minecraft:blackstone
setblock 117 109 512 minecraft:smooth_basalt
setblock 118 109 511 minecraft:smooth_basalt
fill 118 109 512 118 112 512 minecraft:blackstone
fill 119 109 511 119 112 511 minecraft:blackstone
fill 119 109 513 119 110 513 minecraft:blackstone
setblock 121 109 513 minecraft:smooth_basalt
fill 121 109 514 121 112 514 minecraft:blackstone
setblock 121 109 521 minecraft:light[level=12]
setblock 121 109 529 minecraft:light[level=12]
setblock 121 109 537 minecraft:light[level=12]
setblock 121 109 545 minecraft:light[level=12]
setblock 122 109 512 minecraft:smooth_basalt
fill 122 109 513 122 112 513 minecraft:blackstone
setblock 123 109 511 minecraft:smooth_basalt
fill 123 109 512 123 112 512 minecraft:blackstone
setblock 123 109 551 minecraft:smooth_basalt
fill 124 109 511 124 112 511 minecraft:blackstone
fill 124 109 551 124 112 551 minecraft:blackstone
setblock 125 109 514 minecraft:smooth_basalt
setblock 126 109 513 minecraft:smooth_basalt
fill 126 109 514 127 111 514 minecraft:blackstone
setblock 127 109 512 minecraft:smooth_basalt
fill 127 109 513 127 112 513 minecraft:blackstone
setblock 128 109 511 minecraft:smooth_basalt
fill 128 109 512 128 112 512 minecraft:blackstone
setblock 128 109 551 minecraft:smooth_basalt
fill 129 109 511 129 112 511 minecraft:blackstone
setblock 129 109 521 minecraft:light[level=12]
setblock 129 109 529 minecraft:light[level=12]
setblock 129 109 537 minecraft:light[level=12]
setblock 129 109 545 minecraft:light[level=12]
fill 129 109 551 129 112 551 minecraft:blackstone
setblock 132 109 512 minecraft:smooth_basalt
setblock 133 109 511 minecraft:smooth_basalt
fill 133 109 512 133 112 512 minecraft:blackstone
setblock 133 109 551 minecraft:smooth_basalt
fill 134 109 511 134 112 511 minecraft:blackstone
setblock 134 109 515 minecraft:smooth_basalt
fill 134 109 551 134 112 551 minecraft:blackstone
setblock 135 109 514 minecraft:smooth_basalt
fill 135 109 515 135 112 515 minecraft:blackstone
setblock 135 109 518 minecraft:blackstone
fill 135 109 550 135 112 550 minecraft:blackstone
setblock 95 110 512 minecraft:blackstone
setblock 95 110 513 minecraft:smooth_basalt
fill 95 110 514 96 112 514 minecraft:blackstone
setblock 95 110 517 minecraft:blackstone
setblock 95 110 532 minecraft:blackstone
setblock 95 110 533 minecraft:smooth_basalt
fill 95 110 534 95 110 537 minecraft:blackstone
setblock 95 110 538 minecraft:smooth_basalt
fill 95 110 539 95 110 542 minecraft:blackstone
setblock 95 110 543 minecraft:smooth_basalt
fill 95 110 544 95 110 547 minecraft:blackstone
setblock 95 110 548 minecraft:smooth_basalt
fill 95 110 549 95 113 549 minecraft:blackstone
setblock 96 110 512 minecraft:smooth_basalt
fill 96 110 513 96 113 513 minecraft:blackstone
fill 96 110 533 96 110 536 minecraft:blackstone
setblock 96 110 537 minecraft:smooth_basalt
fill 96 110 538 97 112 538 minecraft:blackstone
setblock 96 110 541 minecraft:blackstone
setblock 96 110 542 minecraft:smooth_basalt
fill 96 110 543 96 113 543 minecraft:blackstone
setblock 97 110 511 minecraft:smooth_basalt
fill 97 110 512 97 113 512 minecraft:blackstone
fill 97 110 534 97 110 535 minecraft:blackstone
setblock 97 110 536 minecraft:smooth_basalt
fill 97 110 537 98 112 537 minecraft:blackstone
fill 97 110 539 97 110 540 minecraft:blackstone
setblock 97 110 550 minecraft:blackstone
setblock 97 110 551 minecraft:smooth_basalt
fill 98 110 511 98 113 511 minecraft:blackstone
setblock 98 110 550 minecraft:smooth_basalt
fill 98 110 551 98 113 551 minecraft:blackstone
fill 99 110 550 99 113 550 minecraft:blackstone
setblock 101 110 512 minecraft:smooth_basalt
setblock 102 110 511 minecraft:smooth_basalt
fill 102 110 512 102 113 512 minecraft:blackstone
setblock 102 110 551 minecraft:smooth_basalt
fill 103 110 511 103 113 511 minecraft:blackstone
setblock 103 110 550 minecraft:smooth_basalt
fill 103 110 551 103 113 551 minecraft:blackstone
setblock 104 110 550 minecraft:blackstone
setblock 107 110 511 minecraft:smooth_basalt
setblock 108 110 511 minecraft:blackstone
fill 114 110 511 114 112 511 minecraft:blackstone
setblock 116 110 512 minecraft:smooth_basalt
setblock 117 110 511 minecraft:smooth_basalt
fill 117 110 512 117 113 512 minecraft:blackstone
fill 118 110 511 118 113 511 minecraft:blackstone
fill 118 110 513 118 111 513 minecraft:blackstone
setblock 119 110 514 minecraft:smooth_basalt
fill 119 110 551 119 112 551 minecraft:blackstone
setblock 120 110 513 minecraft:smooth_basalt
fill 120 110 514 120 113 514 minecraft:blackstone
setblock 121 110 512 minecraft:smooth_basalt
fill 121 110 513 121 113 513 minecraft:blackstone
setblock 122 110 511 minecraft:smooth_basalt
fill 122 110 512 122 113 512 minecraft:blackstone
setblock 122 110 551 minecraft:smooth_basalt
fill 123 110 511 123 113 511 minecraft:blackstone
fill 123 110 551 123 113 551 minecraft:blackstone
setblock 124 110 513 minecraft:blackstone
setblock 124 110 514 minecraft:smooth_basalt
setblock 125 110 513 minecraft:smooth_basalt
fill 125 110 514 125 113 514 minecraft:blackstone
setblock 126 110 512 minecraft:smooth_basalt
fill 126 110 513 126 113 513 minecraft:blackstone
setblock 127 110 511 minecraft:smooth_basalt
fill 127 110 512 127 113 512 minecraft:blackstone
setblock 127 110 551 minecraft:smooth_basalt
fill 128 110 511 128 113 511 minecraft:blackstone
fill 128 110 551 128 112 551 minecraft:blackstone
setblock 130 110 513 minecraft:smooth_basalt
setblock 131 110 512 minecraft:smooth_basalt
setblock 132 110 511 minecraft:smooth_basalt
fill 132 110 512 132 113 512 minecraft:blackstone
setblock 132 110 551 minecraft:smooth_basalt
fill 133 110 511 133 113 511 minecraft:blackstone
fill 133 110 551 133 113 551 minecraft:blackstone
setblock 134 110 514 minecraft:smooth_basalt
fill 134 110 515 134 111 517 minecraft:blackstone
setblock 135 110 513 minecraft:smooth_basalt
fill 135 110 514 135 113 514 minecraft:blackstone
setblock 135 110 518 minecraft:smooth_basalt
fill 135 110 519 135 113 519 minecraft:blackstone
fill 135 110 534 135 110 537 minecraft:blackstone
setblock 135 110 538 minecraft:smooth_basalt
fill 135 110 539 135 112 540 minecraft:blackstone
fill 135 110 549 135 113 549 minecraft:blackstone
setblock 95 111 512 minecraft:smooth_basalt
fill 95 111 513 95 114 513 minecraft:blackstone
setblock 95 111 517 minecraft:smooth_basalt
fill 95 111 518 95 114 518 minecraft:blackstone
setblock 95 111 531 minecraft:blackstone
setblock 95 111 532 minecraft:smooth_basalt
fill 95 111 533 95 111 536 minecraft:blackstone
setblock 95 111 537 minecraft:smooth_basalt
fill 95 111 538 95 111 541 minecraft:blackstone
setblock 95 111 542 minecraft:smooth_basalt
fill 95 111 543 95 111 546 minecraft:blackstone
setblock 95 111 547 minecraft:smooth_basalt
fill 95 111 548 95 114 548 minecraft:blackstone
setblock 96 111 511 minecraft:smooth_basalt
fill 96 111 512 96 113 512 minecraft:blackstone
setblock 96 111 515 minecraft:blackstone
setblock 96 111 516 minecraft:smooth_basalt
fill 96 111 532 96 111 535 minecraft:blackstone
setblock 96 111 536 minecraft:smooth_basalt
fill 96 111 537 96 114 537 minecraft:blackstone
setblock 96 111 541 minecraft:smooth_basalt
fill 96 111 542 97 113 542 minecraft:blackstone
fill 96 111 544 96 111 545 minecraft:blackstone
setblock 96 111 546 minecraft:smooth_basalt
setblock 96 111 551 minecraft:smooth_basalt
fill 97 111 511 97 114 511 minecraft:blackstone
fill 97 111 533 97 111 534 minecraft:blackstone
setblock 97 111 535 minecraft:smooth_basalt
fill 97 111 536 98 113 536 minecraft:blackstone
setblock 97 111 539 minecraft:blackstone
setblock 97 111 540 minecraft:smooth_basalt
fill 97 111 541 97 114 541 minecraft:blackstone
fill 97 111 543 97 112 543 minecraft:blackstone
setblock 97 111 550 minecraft:smooth_basalt
fill 97 111 551 97 114 551 minecraft:blackstone
fill 98 111 535 98 114 535 minecraft:blackstone
setblock 98 111 538 minecraft:blackstone
setblock 98 111 539 minecraft:smooth_basalt
fill 98 111 540 98 114 540 minecraft:blackstone
fill 98 111 550 98 114 550 minecraft:blackstone
setblock 100 111 512 minecraft:smooth_basalt
setblock 101 111 511 minecraft:smooth_basalt
fill 101 111 512 101 111 513 minecraft:blackstone
fill 101 111 514 101 139 514 minecraft:smooth_basalt
setblock 101 111 551 minecraft:smooth_basalt
fill 102 111 511 102 114 511 minecraft:blackstone
setblock 102 111 550 minecraft:smooth_basalt
fill 102 111 551 102 114 551 minecraft:blackstone
setblock 103 111 550 minecraft:blackstone
setblock 105 111 512 minecraft:smooth_basalt
setblock 106 111 511 minecraft:smooth_basalt
setblock 106 111 551 minecraft:smooth_basalt
setblock 107 111 511 minecraft:blackstone
setblock 115 111 512 minecraft:smooth_basalt
setblock 116 111 511 minecraft:smooth_basalt
fill 116 111 512 116 114 512 minecraft:blackstone
fill 117 111 511 117 114 511 minecraft:blackstone
fill 117 111 513 117 112 513 minecraft:blackstone
setblock 118 111 514 minecraft:smooth_basalt
fill 118 111 551 118 113 551 minecraft:blackstone
setblock 119 111 513 minecraft:smooth_basalt
fill 119 111 514 119 114 514 minecraft:blackstone
setblock 120 111 512 minecraft:smooth_basalt
fill 120 111 513 120 114 513 minecraft:blackstone
setblock 121 111 511 minecraft:smooth_basalt
fill 121 111 512 121 114 512 minecraft:blackstone
setblock 121 111 515 minecraft:blackstone
setblock 121 111 551 minecraft:smooth_basalt
fill 122 111 511 122 114 511 minecraft:blackstone
setblock 122 111 514 minecraft:blackstone
setblock 122 111 515 minecraft:smooth_basalt
fill 122 111 551 122 114 551 minecraft:blackstone
setblock 123 111 514 minecraft:smooth_basalt
fill 123 111 515 124 111 515 minecraft:blackstone
setblock 124 111 513 minecraft:smooth_basalt
fill 124 111 514 124 114 514 minecraft:blackstone
setblock 125 111 512 minecraft:smooth_basalt
fill 125 111 513 125 114 513 minecraft:blackstone
setblock 126 111 511 minecraft:smooth_basalt
fill 126 111 512 126 114 512 minecraft:blackstone
setblock 126 111 551 minecraft:smooth_basalt
fill 127 111 511 127 114 511 minecraft:blackstone
fill 127 111 551 127 113 551 minecraft:blackstone
setblock 129 111 513 minecraft:smooth_basalt
setblock 130 111 512 minecraft:smooth_basalt
setblock 130 111 513 minecraft:blackstone
setblock 131 111 511 minecraft:smooth_basalt
fill 131 111 512 131 114 512 minecraft:blackstone
setblock 131 111 551 minecraft:smooth_basalt
fill 132 111 511 132 114 511 minecraft:blackstone
fill 132 111 551 132 114 551 minecraft:blackstone
setblock 134 111 513 minecraft:smooth_basalt
fill 134 111 514 134 114 514 minecraft:blackstone
setblock 135 111 512 minecraft:smooth_basalt
fill 135 111 513 135 114 513 minecraft:blackstone
setblock 135 111 516 minecraft:blackstone
setblock 135 111 517 minecraft:smooth_basalt
fill 135 111 518 135 114 518 minecraft:blackstone
fill 135 111 520 135 112 520 minecraft:blackstone
fill 135 111 534 135 111 536 minecraft:blackstone
setblock 135 111 537 minecraft:smooth_basalt
fill 135 111 538 135 114 538 minecraft:blackstone
setblock 135 111 541 minecraft:blackstone
setblock 135 111 542 minecraft:smooth_basalt
fill 135 111 543 135 112 545 minecraft:blackstone
setblock 135 111 547 minecraft:smooth_basalt
fill 135 111 548 135 114 548 minecraft:blackstone
setblock 95 112 511 minecraft:smooth_basalt
fill 95 112 512 95 115 512 minecraft:blackstone
setblock 95 112 515 minecraft:blackstone
setblock 95 112 516 minecraft:smooth_basalt
fill 95 112 517 96 114 517 minecraft:blackstone
fill 95 112 519 95 112 520 minecraft:blackstone
setblock 95 112 531 minecraft:smooth_basalt
fill 95 112 532 95 112 535 minecraft:blackstone
setblock 95 112 536 minecraft:smooth_basalt
fill 95 112 537 95 112 540 minecraft:blackstone
setblock 95 112 541 minecraft:smooth_basalt
fill 95 112 542 95 112 545 minecraft:blackstone
setblock 95 112 546 minecraft:smooth_basalt
fill 95 112 547 96 114 547 minecraft:blackstone
setblock 95 112 551 minecraft:smooth_basalt
fill 96 112 511 96 115 511 minecraft:blackstone
setblock 96 112 515 minecraft:smooth_basalt
fill 96 112 516 96 115 516 minecraft:blackstone
fill 96 112 518 96 113 518 minecraft:blackstone
fill 96 112 532 96 112 534 minecraft:blackstone
setblock 96 112 535 minecraft:smooth_basalt
fill 96 112 536 96 115 536 minecraft:blackstone
setblock 96 112 539 minecraft:blackstone
setblock 96 112 540 minecraft:smooth_basalt
fill 96 112 541 96 115 541 minecraft:blackstone
setblock 96 112 544 minecraft:blackstone
setblock 96 112 545 minecraft:smooth_basalt
fill 96 112 546 96 115 546 minecraft:blackstone
fill 96 112 548 96 112 549 minecraft:blackstone
setblock 96 112 550 minecraft:smooth_basalt
fill 96 112 551 96 115 551 minecraft:blackstone
setblock 97 112 533 minecraft:blackstone
setblock 97 112 534 minecraft:smooth_basalt
fill 97 112 535 97 115 535 minecraft:blackstone
setblock 97 112 539 minecraft:smooth_basalt
fill 97 112 540 97 115 540 minecraft:blackstone
setblock 97 112 544 minecraft:smooth_basalt
fill 97 112 550 97 115 550 minecraft:blackstone
fill 98 112 534 98 113 534 minecraft:blackstone
setblock 98 112 538 minecraft:smooth_basalt
fill 98 112 539 99 114 539 minecraft:blackstone
fill 98 112 541 98 112 542 minecraft:blackstone
setblock 99 112 512 minecraft:smooth_basalt
setblock 99 112 537 minecraft:smooth_basalt
fill 99 112 538 99 115 538 minecraft:blackstone
setblock 100 112 511 minecraft:smooth_basalt
fill 100 112 512 101 114 512 minecraft:blackstone
setblock 100 112 551 minecraft:smooth_basalt
fill 101 112 511 101 115 511 minecraft:blackstone
fill 101 112 513 101 139 513 minecraft:smooth_basalt
setblock 101 112 550 minecraft:smooth_basalt
fill 101 112 551 101 115 551 minecraft:blackstone
setblock 102 112 550 minecraft:blackstone
setblock 104 112 512 minecraft:smooth_basalt
setblock 105 112 511 minecraft:smooth_basalt
setblock 105 112 551 minecraft:smooth_basalt
setblock 106 112 511 minecraft:blackstone
setblock 115 112 511 minecraft:smooth_basalt
fill 115 112 512 115 115 512 minecraft:blackstone
fill 116 112 511 116 115 511 minecraft:blackstone
fill 116 112 513 116 113 513 minecraft:blackstone
setblock 118 112 513 minecraft:smooth_basalt
fill 118 112 514 118 115 514 minecraft:blackstone
setblock 119 112 512 minecraft:smooth_basalt
fill 119 112 513 119 115 513 minecraft:blackstone
setblock 120 112 511 minecraft:smooth_basalt
fill 120 112 512 120 115 512 minecraft:blackstone
setblock 120 112 515 minecraft:blackstone
setblock 120 112 551 minecraft:smooth_basalt
fill 121 112 511 121 115 511 minecraft:blackstone
setblock 121 112 515 minecraft:smooth_basalt
fill 121 112 551 121 115 551 minecraft:blackstone
setblock 122 112 514 minecraft:smooth_basalt
fill 122 112 515 123 113 515 minecraft:blackstone
setblock 123 112 513 minecraft:smooth_basalt
fill 123 112 514 123 114 514 minecraft:blackstone
setblock 124 112 512 minecraft:smooth_basalt
fill 124 112 513 124 115 513 minecraft:blackstone
setblock 125 112 511 minecraft:smooth_basalt
fill 125 112 512 125 115 512 minecraft:blackstone
setblock 125 112 551 minecraft:smooth_basalt
fill 126 112 511 126 115 511 minecraft:blackstone
setblock 126 112 514 minecraft:blackstone
fill 126 112 551 126 114 551 minecraft:blackstone
setblock 128 112 513 minecraft:smooth_basalt
setblock 129 112 512 minecraft:smooth_basalt
setblock 129 112 513 minecraft:blackstone
setblock 130 112 511 minecraft:smooth_basalt
fill 130 112 512 130 114 512 minecraft:blackstone
setblock 130 112 551 minecraft:smooth_basalt
fill 131 112 511 131 115 511 minecraft:blackstone
setblock 131 112 551 minecraft:blackstone
setblock 134 112 512 minecraft:smooth_basalt
fill 134 112 513 134 115 513 minecraft:blackstone
fill 134 112 515 134 112 516 minecraft:blackstone
setblock 134 112 517 minecraft:smooth_basalt
fill 134 112 518 134 115 518 minecraft:blackstone
setblock 135 112 511 minecraft:smooth_basalt
fill 135 112 512 135 115 512 minecraft:blackstone
setblock 135 112 516 minecraft:smooth_basalt
fill 135 112 517 135 115 517 minecraft:blackstone
setblock 135 112 521 minecraft:smooth_basalt
fill 135 112 533 135 112 535 minecraft:blackstone
setblock 135 112 536 minecraft:smooth_basalt
fill 135 112 537 135 115 537 minecraft:blackstone
setblock 135 112 541 minecraft:smooth_basalt
fill 135 112 542 135 115 542 minecraft:blackstone
setblock 135 112 546 minecraft:smooth_basalt
fill 135 112 547 135 115 547 minecraft:blackstone
setblock 135 112 551 minecraft:smooth_basalt
fill 95 113 511 95 115 511 minecraft:blackstone
setblock 95 113 514 minecraft:blackstone
setblock 95 113 515 minecraft:smooth_basalt
fill 95 113 516 95 116 516 minecraft:blackstone
setblock 95 113 519 minecraft:blackstone
setblock 95 113 520 minecraft:smooth_basalt
fill 95 113 521 95 116 521 minecraft:blackstone
fill 95 113 531 95 113 534 minecraft:blackstone
setblock 95 113 535 minecraft:smooth_basalt
fill 95 113 536 95 113 539 minecraft:blackstone
setblock 95 113 540 minecraft:smooth_basalt
fill 95 113 541 95 113 544 minecraft:blackstone
setblock 95 113 545 minecraft:smooth_basalt
fill 95 113 546 95 116 546 minecraft:blackstone
setblock 95 113 550 minecraft:smooth_basalt
fill 95 113 551 95 116 551 minecraft:blackstone
setblock 96 113 514 minecraft:smooth_basalt
fill 96 113 515 96 115 515 minecraft:blackstone
setblock 96 113 519 minecraft:smooth_basalt
fill 96 113 532 96 113 533 minecraft:blackstone
setblock 96 113 534 minecraft:smooth_basalt
fill 96 113 535 96 116 535 minecraft:blackstone
setblock 96 113 538 minecraft:blackstone
setblock 96 113 539 minecraft:smooth_basalt
fill 96 113 540 96 116 540 minecraft:blackstone
setblock 96 113 544 minecraft:smooth_basalt
fill 96 113 545 97 115 545 minecraft:blackstone
setblock 96 113 548 minecraft:blackstone
setblock 96 113 549 minecraft:smooth_basalt
fill 96 113 550 96 114 550 minecraft:blackstone
setblock 97 113 533 minecraft:smooth_basalt
fill 97 113 534 97 116 534 minecraft:blackstone
setblock 97 113 537 minecraft:blackstone
setblock 97 113 538 minecraft:smooth_basalt
fill 97 113 539 97 116 539 minecraft:blackstone
setblock 97 113 543 minecraft:smooth_basalt
fill 97 113 544 97 116 544 minecraft:blackstone
setblock 98 113 512 minecraft:smooth_basalt
setblock 98 113 537 minecraft:smooth_basalt
fill 98 113 538 98 116 538 minecraft:blackstone
setblock 98 113 541 minecraft:blackstone
setblock 98 113 542 minecraft:smooth_basalt
fill 98 113 543 98 116 543 minecraft:blackstone
setblock 99 113 511 minecraft:smooth_basalt
fill 99 113 512 99 114 512 minecraft:blackstone
fill 99 113 537 99 114 537 minecraft:blackstone
setblock 99 113 540 minecraft:blackstone
setblock 99 113 551 minecraft:smooth_basalt
fill 100 113 511 100 115 511 minecraft:blackstone
setblock 100 113 550 minecraft:smooth_basalt
fill 100 113 551 100 116 551 minecraft:blackstone
setblock 101 113 550 minecraft:blackstone
setblock 103 113 512 minecraft:smooth_basalt
setblock 104 113 511 minecraft:smooth_basalt
setblock 104 113 551 minecraft:smooth_basalt
setblock 105 113 511 minecraft:blackstone
setblock 114 113 511 minecraft:smooth_basalt
fill 115 113 511 115 116 511 minecraft:blackstone
setblock 117 113 513 minecraft:smooth_basalt
setblock 117 113 514 minecraft:blackstone
setblock 118 113 512 minecraft:smooth_basalt
fill 118 113 513 118 116 513 minecraft:blackstone
setblock 119 113 511 minecraft:smooth_basalt
fill 119 113 512 119 116 512 minecraft:blackstone
setblock 119 113 551 minecraft:smooth_basalt
fill 120 113 511 120 116 511 minecraft:blackstone
setblock 120 113 515 minecraft:smooth_basalt
fill 120 113 551 120 116 551 minecraft:blackstone
setblock 121 113 514 minecraft:smooth_basalt
fill 121 113 515 121 114 515 minecraft:blackstone
setblock 122 113 513 minecraft:smooth_basalt
fill 122 113 514 122 115 514 minecraft:blackstone
setblock 123 113 512 minecraft:smooth_basalt
fill 123 113 513 123 116 513 minecraft:blackstone
setblock 124 113 511 minecraft:smooth_basalt
fill 124 113 512 124 116 512 minecraft:blackstone
setblock 124 113 551 minecraft:smooth_basalt
fill 125 113 511 125 116 511 minecraft:blackstone
fill 125 113 551 125 114 551 minecraft:blackstone
setblock 127 113 513 minecraft:smooth_basalt
setblock 128 113 512 minecraft:smooth_basalt
setblock 128 113 513 minecraft:blackstone
setblock 129 113 511 minecraft:smooth_basalt
fill 129 113 512 129 114 512 minecraft:blackstone
fill 130 113 511 130 115 511 minecraft:blackstone
setblock 133 113 512 minecraft:smooth_basalt
setblock 134 113 511 minecraft:smooth_basalt
fill 134 113 512 134 115 512 minecraft:blackstone
setblock 134 113 515 minecraft:blackstone
setblock 134 113 516 minecraft:smooth_basalt
fill 134 113 517 134 116 517 minecraft:blackstone
fill 134 113 519 134 114 519 minecraft:blackstone
fill 134 113 537 134 113 540 minecraft:blackstone
setblock 134 113 541 minecraft:smooth_basalt
fill 134 113 542 134 116 542 minecraft:blackstone
setblock 134 113 551 minecraft:smooth_basalt
fill 135 113 511 135 116 511 minecraft:blackstone
setblock 135 113 515 minecraft:smooth_basalt
fill 135 113 516 135 116 516 minecraft:blackstone
setblock 135 113 520 minecraft:smooth_basalt
fill 135 113 521 135 115 522 minecraft:blackstone
fill 135 113 533 135 113 534 minecraft:blackstone
setblock 135 113 535 minecraft:smooth_basalt
fill 135 113 536 135 116 536 minecraft:blackstone
setblock 135 113 539 minecraft:blackstone
setblock 135 113 540 minecraft:smooth_basalt
fill 135 113 541 135 116 541 minecraft:blackstone
fill 135 113 543 135 113 544 minecraft:blackstone
setblock 135 113 545 minecraft:smooth_basalt
fill 135 113 546 135 116 546 minecraft:blackstone
setblock 135 113 550 minecraft:smooth_basalt
fill 135 113 551 135 116 551 minecraft:blackstone
setblock 95 114 514 minecraft:smooth_basalt
fill 95 114 515 95 117 515 minecraft:blackstone
setblock 95 114 519 minecraft:smooth_basalt
fill 95 114 520 96 116 520 minecraft:blackstone
fill 95 114 522 95 114 523 minecraft:blackstone
fill 95 114 530 95 114 533 minecraft:blackstone
setblock 95 114 534 minecraft:smooth_basalt
fill 95 114 535 95 114 538 minecraft:blackstone
setblock 95 114 539 minecraft:smooth_basalt
fill 95 114 540 95 114 543 minecraft:blackstone
setblock 95 114 544 minecraft:smooth_basalt
fill 95 114 545 95 117 545 minecraft:blackstone
setblock 95 114 549 minecraft:smooth_basalt
fill 95 114 550 95 117 550 minecraft:blackstone
setblock 96 114 513 minecraft:smooth_basalt
setblock 96 114 514 minecraft:blackstone
setblock 96 114 518 minecraft:smooth_basalt
fill 96 114 519 96 117 519 minecraft:blackstone
setblock 96 114 532 minecraft:blackstone
setblock 96 114 533 minecraft:smooth_basalt
fill 96 114 534 96 117 534 minecraft:blackstone
setblock 96 114 538 minecraft:smooth_basalt
fill 96 114 539 96 117 539 minecraft:blackstone
setblock 96 114 542 minecraft:blackstone
setblock 96 114 543 minecraft:smooth_basalt
fill 96 114 544 96 117 544 minecraft:blackstone
setblock 96 114 548 minecraft:smooth_basalt
fill 96 114 549 96 117 549 minecraft:blackstone
setblock 97 114 512 minecraft:smooth_basalt
setblock 97 114 533 minecraft:blackstone
setblock 97 114 536 minecraft:blackstone
setblock 97 114 537 minecraft:smooth_basalt
fill 97 114 538 97 117 538 minecraft:blackstone
setblock 97 114 542 minecraft:smooth_basalt
fill 97 114 543 97 117 543 minecraft:blackstone
setblock 97 114 546 minecraft:blackstone
setblock 98 114 511 minecraft:smooth_basalt
setblock 98 114 512 minecraft:blackstone
setblock 98 114 536 minecraft:smooth_basalt
fill 98 114 537 98 117 537 minecraft:blackstone
setblock 98 114 541 minecraft:smooth_basalt
fill 98 114 542 98 117 542 minecraft:blackstone
fill 98 114 544 98 115 544 minecraft:blackstone
setblock 98 114 551 minecraft:smooth_basalt
fill 99 114 511 99 116 511 minecraft:blackstone
setblock 99 114 540 minecraft:smooth_basalt
fill 99 114 541 99 115 541 minecraft:blackstone
setblock 99 114 550 minecraft:smooth_basalt
fill 99 114 551 99 117 551 minecraft:blackstone
setblock 100 114 550 minecraft:blackstone
setblock 103 114 511 minecraft:smooth_basalt
setblock 103 114 551 minecraft:smooth_basalt
fill 114 114 511 114 116 511 minecraft:blackstone
setblock 116 114 513 minecraft:smooth_basalt
setblock 117 114 512 minecraft:smooth_basalt
fill 117 114 513 117 116 513 minecraft:blackstone
setblock 118 114 511 minecraft:smooth_basalt
fill 118 114 512 118 117 512 minecraft:blackstone
setblock 118 114 551 minecraft:smooth_basalt
fill 119 114 511 119 117 511 minecraft:blackstone
fill 119 114 551 119 117 551 minecraft:blackstone
setblock 120 114 514 minecraft:smooth_basalt
setblock 120 114 515 minecraft:blackstone
setblock 121 114 513 minecraft:smooth_basalt
fill 121 114 514 121 115 514 minecraft:blackstone
setblock 122 114 512 minecraft:smooth_basalt
fill 122 114 513 122 116 513 minecraft:blackstone
setblock 123 114 511 minecraft:smooth_basalt
fill 123 114 512 123 117 512 minecraft:blackstone
setblock 123 114 551 minecraft:smooth_basalt
fill 124 114 511 124 117 511 minecraft:blackstone
fill 124 114 551 124 115 551 minecraft:blackstone
setblock 126 114 513 minecraft:smooth_basalt
setblock 127 114 512 minecraft:smooth_basalt
setblock 128 114 511 minecraft:smooth_basalt
setblock 128 114 512 minecraft:blackstone
fill 129 114 511 129 115 511 minecraft:blackstone
setblock 132 114 512 minecraft:smooth_basalt
setblock 133 114 511 minecraft:smooth_basalt
setblock 133 114 512 minecraft:blackstone
setblock 133 114 551 minecraft:smooth_basalt
fill 134 114 511 134 117 511 minecraft:blackstone
setblock 134 114 515 minecraft:smooth_basalt
fill 134 114 516 134 117 516 minecraft:blackstone
fill 134 114 537 134 114 539 minecraft:blackstone
setblock 134 114 540 minecraft:smooth_basalt
fill 134 114 541 134 117 541 minecraft:blackstone
fill 134 114 543 134 114 544 minecraft:blackstone
fill 134 114 551 134 117 551 minecraft:blackstone
setblock 135 114 514 minecraft:smooth_basalt
fill 135 114 515 135 117 515 minecraft:blackstone
setblock 135 114 519 minecraft:smooth_basalt
fill 135 114 520 135 117 520 minecraft:blackstone
setblock 135 114 533 minecraft:blackstone
setblock 135 114 534 minecraft:smooth_basalt
fill 135 114 535 135 117 535 minecraft:blackstone
setblock 135 114 539 minecraft:smooth_basalt
fill 135 114 540 135 117 540 minecraft:blackstone
setblock 135 114 543 minecraft:blackstone
setblock 135 114 544 minecraft:smooth_basalt
fill 135 114 545 135 117 545 minecraft:blackstone
setblock 135 114 549 minecraft:smooth_basalt
fill 135 114 550 135 117 550 minecraft:blackstone
setblock 95 115 513 minecraft:smooth_basalt
fill 95 115 514 95 117 514 minecraft:blackstone
setblock 95 115 517 minecraft:blackstone
setblock 95 115 518 minecraft:smooth_basalt
fill 95 115 519 95 118 519 minecraft:blackstone
setblock 95 115 522 minecraft:blackstone
setblock 95 115 523 minecraft:smooth_basalt
fill 95 115 524 95 118 524 minecraft:blackstone
fill 95 115 530 95 115 532 minecraft:blackstone
setblock 95 115 533 minecraft:smooth_basalt
fill 95 115 534 95 115 537 minecraft:blackstone
setblock 95 115 538 minecraft:smooth_basalt
fill 95 115 539 95 115 542 minecraft:blackstone
setblock 95 115 543 minecraft:smooth_basalt
fill 95 115 544 95 118 544 minecraft:blackstone
setblock 95 115 547 minecraft:blackstone
setblock 95 115 548 minecraft:smooth_basalt
fill 95 115 549 95 118 549 minecraft:blackstone
setblock 96 115 517 minecraft:smooth_basalt
fill 96 115 518 96 118 518 minecraft:blackstone
setblock 96 115 521 minecraft:blackstone
setblock 96 115 532 minecraft:smooth_basalt
fill 96 115 533 96 117 533 minecraft:blackstone
setblock 96 115 537 minecraft:smooth_basalt
fill 96 115 538 96 118 538 minecraft:blackstone
setblock 96 115 542 minecraft:smooth_basalt
fill 96 115 543 96 118 543 minecraft:blackstone
setblock 96 115 547 minecraft:smooth_basalt
fill 96 115 548 96 118 548 minecraft:blackstone
setblock 97 115 511 minecraft:smooth_basalt
setblock 97 115 536 minecraft:smooth_basalt
fill 97 115 537 97 118 537 minecraft:blackstone
setblock 97 115 541 minecraft:smooth_basalt
fill 97 115 542 97 118 542 minecraft:blackstone
setblock 97 115 546 minecraft:smooth_basalt
setblock 97 115 551 minecraft:smooth_basalt
fill 98 115 511 98 116 511 minecraft:blackstone
fill 98 115 512 101 136 512 minecraft:smooth_basalt
setblock 98 115 535 minecraft:smooth_basalt
fill 98 115 536 98 116 536 minecraft:blackstone
setblock 98 115 539 minecraft:blackstone
setblock 98 115 540 minecraft:smooth_basalt
fill 98 115 541 98 118 541 minecraft:blackstone
setblock 98 115 550 minecraft:smooth_basalt
fill 98 115 551 98 118 551 minecraft:blackstone
setblock 99 115 539 minecraft:smooth_basalt
setblock 99 115 540 minecraft:blackstone
setblock 99 115 550 minecraft:blackstone
setblock 102 115 511 minecraft:smooth_basalt
setblock 102 115 551 minecraft:smooth_basalt
setblock 116 115 512 minecraft:smooth_basalt
setblock 116 115 513 minecraft:blackstone
setblock 117 115 511 minecraft:smooth_basalt
fill 117 115 512 117 118 512 minecraft:blackstone
fill 118 115 511 118 118 511 minecraft:blackstone
setblock 118 115 551 minecraft:blackstone
setblock 119 115 514 minecraft:smooth_basalt
setblock 120 115 513 minecraft:smooth_basalt
setblock 120 115 514 minecraft:blackstone
setblock 121 115 512 minecraft:smooth_basalt
fill 121 115 513 121 116 513 minecraft:blackstone
setblock 122 115 511 minecraft:smooth_basalt
fill 122 115 512 122 117 512 minecraft:blackstone
setblock 122 115 551 minecraft:smooth_basalt
fill 123 115 511 123 118 511 minecraft:blackstone
setblock 123 115 551 minecraft:blackstone
setblock 126 115 512 minecraft:smooth_basalt
setblock 127 115 511 minecraft:smooth_basalt
setblock 127 115 512 minecraft:blackstone
fill 128 115 511 128 116 511 minecraft:blackstone
setblock 132 115 511 minecraft:smooth_basalt
fill 133 115 511 133 117 511 minecraft:blackstone
fill 133 115 551 133 118 551 minecraft:blackstone
setblock 134 115 514 minecraft:smooth_basalt
fill 134 115 515 134 116 515 minecraft:blackstone
setblock 134 115 519 minecraft:smooth_basalt
fill 134 115 537 134 115 538 minecraft:blackstone
setblock 134 115 539 minecraft:smooth_basalt
fill 134 115 540 134 118 540 minecraft:blackstone
setblock 134 115 543 minecraft:blackstone
setblock 134 115 544 minecraft:smooth_basalt
fill 134 115 545 134 117 546 minecraft:blackstone
setblock 135 115 513 minecraft:smooth_basalt
fill 135 115 514 135 118 514 minecraft:blackstone
setblock 135 115 518 minecraft:smooth_basalt
fill 135 115 519 135 118 519 minecraft:blackstone
setblock 135 115 523 minecraft:smooth_basalt
fill 135 115 534 135 116 534 minecraft:blackstone
setblock 135 115 538 minecraft:smooth_basalt
fill 135 115 539 135 118 539 minecraft:blackstone
setblock 135 115 543 minecraft:smooth_basalt
fill 135 115 544 135 118 544 minecraft:blackstone
setblock 135 115 548 minecraft:smooth_basalt
fill 135 115 549 135 118 549 minecraft:blackstone
setblock 95 116 513 minecraft:blackstone
setblock 95 116 517 minecraft:smooth_basalt
fill 95 116 518 95 119 518 minecraft:blackstone
setblock 95 116 522 minecraft:smooth_basalt
fill 95 116 523 95 119 523 minecraft:blackstone
fill 95 116 525 95 117 525 minecraft:blackstone
setblock 95 116 531 minecraft:blackstone
setblock 95 116 532 minecraft:smooth_basalt
fill 95 116 533 95 116 536 minecraft:blackstone
setblock 95 116 537 minecraft:smooth_basalt
fill 95 116 538 95 116 541 minecraft:blackstone
setblock 95 116 542 minecraft:smooth_basalt
fill 95 116 543 95 119 543 minecraft:blackstone
setblock 95 116 547 minecraft:smooth_basalt
fill 95 116 548 95 119 548 minecraft:blackstone
setblock 96 116 516 minecraft:smooth_basalt
fill 96 116 517 96 117 517 minecraft:blackstone
setblock 96 116 521 minecraft:smooth_basalt
fill 96 116 522 96 119 522 minecraft:blackstone
setblock 96 116 536 minecraft:smooth_basalt
fill 96 116 537 96 119 537 minecraft:blackstone
setblock 96 116 541 minecraft:smooth_basalt
fill 96 116 542 96 119 542 minecraft:blackstone
setblock 96 116 545 minecraft:blackstone
setblock 96 116 546 minecraft:smooth_basalt
fill 96 116 547 96 119 547 minecraft:blackstone
setblock 96 116 551 minecraft:smooth_basalt
setblock 97 116 511 minecraft:blackstone
setblock 97 116 535 minecraft:smooth_basalt
fill 97 116 536 97 118 536 minecraft:blackstone
setblock 97 116 540 minecraft:smooth_basalt
fill 97 116 541 97 119 541 minecraft:blackstone
setblock 97 116 545 minecraft:smooth_basalt
fill 97 116 546 97 119 546 minecraft:blackstone
fill 97 116 551 97 119 551 minecraft:blackstone
setblock 98 116 539 minecraft:smooth_basalt
fill 98 116 540 98 119 540 minecraft:blackstone
setblock 98 116 544 minecraft:smooth_basalt
setblock 116 116 511 minecraft:smooth_basalt
fill 116 116 512 116 117 512 minecraft:blackstone
fill 117 116 511 117 119 511 minecraft:blackstone
setblock 119 116 513 minecraft:smooth_basalt
setblock 120 116 512 minecraft:smooth_basalt
fill 120 116 513 120 117 513 minecraft:blackstone
setblock 121 116 511 minecraft:smooth_basalt
fill 121 116 512 121 118 512 minecraft:blackstone
setblock 121 116 551 minecraft:smooth_basalt
fill 122 116 511 122 119 511 minecraft:blackstone
setblock 122 116 551 minecraft:blackstone
setblock 125 116 512 minecraft:smooth_basalt
setblock 126 116 511 minecraft:smooth_basalt
setblock 127 116 511 minecraft:blackstone
setblock 132 116 511 minecraft:blackstone
setblock 134 116 514 minecraft:blackstone
setblock 134 116 518 minecraft:smooth_basalt
fill 134 116 519 134 117 519 minecraft:blackstone
setblock 134 116 538 minecraft:smooth_basalt
fill 134 116 539 134 119 539 minecraft:blackstone
setblock 134 116 543 minecraft:smooth_basalt
fill 134 116 544 134 119 544 minecraft:blackstone
setblock 134 116 547 minecraft:blackstone
setblock 135 116 512 minecraft:smooth_basalt
fill 135 116 513 135 119 513 minecraft:blackstone
setblock 135 116 517 minecraft:smooth_basalt
fill 135 116 518 135 119 518 minecraft:blackstone
setblock 135 116 521 minecraft:blackstone
setblock 135 116 522 minecraft:smooth_basalt
fill 135 116 523 135 119 523 minecraft:blackstone
setblock 135 116 537 minecraft:smooth_basalt
fill 135 116 538 135 119 538 minecraft:blackstone
setblock 135 116 542 minecraft:smooth_basalt
fill 135 116 543 135 119 543 minecraft:blackstone
setblock 135 116 547 minecraft:smooth_basalt
fill 135 116 548 135 119 548 minecraft:blackstone
setblock 95 117 516 minecraft:smooth_basalt
fill 95 117 517 95 120 517 minecraft:blackstone
setblock 95 117 520 minecraft:blackstone
setblock 95 117 521 minecraft:smooth_basalt
fill 95 117 522 95 120 522 minecraft:blackstone
setblock 95 117 526 minecraft:smooth_basalt
setblock 95 117 530 minecraft:blackstone
setblock 95 117 531 minecraft:smooth_basalt
fill 95 117 532 95 117 535 minecraft:blackstone
setblock 95 117 536 minecraft:smooth_basalt
fill 95 117 537 95 117 540 minecraft:blackstone
setblock 95 117 541 minecraft:smooth_basalt
fill 95 117 542 95 120 542 minecraft:blackstone
setblock 95 117 546 minecraft:smooth_basalt
fill 95 117 547 95 120 547 minecraft:blackstone
setblock 95 117 551 minecraft:smooth_basalt
setblock 96 117 520 minecraft:smooth_basalt
fill 96 117 521 96 120 521 minecraft:blackstone
fill 96 117 523 96 118 523 minecraft:blackstone
setblock 96 117 535 minecraft:smooth_basalt
fill 96 117 536 96 120 536 minecraft:blackstone
setblock 96 117 540 minecraft:smooth_basalt
fill 96 117 541 96 120 541 minecraft:blackstone
setblock 96 117 545 minecraft:smooth_basalt
fill 96 117 546 96 120 546 minecraft:blackstone
fill 96 117 551 96 120 551 minecraft:blackstone
setblock 97 117 513 minecraft:light[level=12]
setblock 97 117 521 minecraft:light[level=12]
setblock 97 117 529 minecraft:light[level=12]
setblock 97 117 535 minecraft:blackstone
setblock 97 117 539 minecraft:smooth_basalt
fill 97 117 540 97 120 540 minecraft:blackstone
setblock 97 117 544 minecraft:smooth_basalt
fill 97 117 545 97 120 545 minecraft:blackstone
setblock 98 117 538 minecraft:smooth_basalt
fill 98 117 539 98 118 539 minecraft:blackstone
setblock 98 117 543 minecraft:smooth_basalt
setblock 98 117 544 minecraft:blackstone
setblock 105 117 513 minecraft:light[level=12]
setblock 105 117 521 minecraft:light[level=12]
setblock 105 117 529 minecraft:light[level=12]
setblock 105 117 537 minecraft:light[level=12]
setblock 105 117 545 minecraft:light[level=12]
setblock 113 117 513 minecraft:light[level=12]
setblock 113 117 521 minecraft:light[level=12]
setblock 113 117 529 minecraft:light[level=12]
setblock 113 117 537 minecraft:light[level=12]
setblock 113 117 545 minecraft:light[level=12]
setblock 115 117 511 minecraft:smooth_basalt
fill 116 117 511 116 120 511 minecraft:blackstone
setblock 118 117 513 minecraft:smooth_basalt
setblock 119 117 512 minecraft:smooth_basalt
setblock 119 117 513 minecraft:blackstone
setblock 120 117 511 minecraft:smooth_basalt
fill 120 117 512 120 118 512 minecraft:blackstone
setblock 120 117 551 minecraft:smooth_basalt
fill 121 117 511 121 120 511 minecraft:blackstone
setblock 121 117 513 minecraft:light[level=12]
setblock 121 117 521 minecraft:light[level=12]
setblock 121 117 529 minecraft:light[level=12]
setblock 121 117 537 minecraft:light[level=12]
setblock 121 117 545 minecraft:light[level=12]
setblock 125 117 511 minecraft:smooth_basalt
setblock 129 117 513 minecraft:light[level=12]
setblock 129 117 521 minecraft:light[level=12]
setblock 129 117 529 minecraft:light[level=12]
setblock 129 117 537 minecraft:light[level=12]
setblock 129 117 545 minecraft:light[level=12]
setblock 134 117 517 minecraft:smooth_basalt
setblock 134 117 518 minecraft:blackstone
fill 134 117 538 134 118 538 minecraft:blackstone
setblock 134 117 542 minecraft:smooth_basalt
fill 134 117 543 134 120 543 minecraft:blackstone
setblock 134 117 547 minecraft:smooth_basalt
fill 134 117 548 134 120 548 minecraft:blackstone
setblock 135 117 511 minecraft:smooth_basalt
fill 135 117 512 135 119 512 minecraft:blackstone
setblock 135 117 516 minecraft:smooth_basalt
fill 135 117 517 135 120 517 minecraft:blackstone
setblock 135 117 521 minecraft:smooth_basalt
fill 135 117 522 135 120 522 minecraft:blackstone
fill 135 117 524 135 118 524 minecraft:blackstone
setblock 135 117 536 minecraft:smooth_basalt
fill 135 117 537 135 120 537 minecraft:blackstone
setblock 135 117 541 minecraft:smooth_basalt
fill 135 117 542 135 120 542 minecraft:blackstone
setblock 135 117 546 minecraft:smooth_basalt
fill 135 117 547 135 120 547 minecraft:blackstone
setblock 135 117 551 minecraft:smooth_basalt
setblock 95 118 515 minecraft:smooth_basalt
fill 95 118 516 95 119 516 minecraft:blackstone
setblock 95 118 520 minecraft:smooth_basalt
fill 95 118 521 95 121 521 minecraft:blackstone
setblock 95 118 525 minecraft:smooth_basalt
fill 95 118 526 95 118 529 minecraft:blackstone
setblock 95 118 530 minecraft:smooth_basalt
fill 95 118 531 95 118 534 minecraft:blackstone
setblock 95 118 535 minecraft:smooth_basalt
fill 95 118 536 95 118 539 minecraft:blackstone
setblock 95 118 540 minecraft:smooth_basalt
fill 95 118 541 95 121 541 minecraft:blackstone
setblock 95 118 545 minecraft:smooth_basalt
fill 95 118 546 95 121 546 minecraft:blackstone
setblock 95 118 550 minecraft:smooth_basalt
fill 95 118 551 95 121 551 minecraft:blackstone
setblock 96 118 519 minecraft:smooth_basalt
fill 96 118 520 96 121 520 minecraft:blackstone
setblock 96 118 524 minecraft:smooth_basalt
setblock 96 118 534 minecraft:smooth_basalt
fill 96 118 535 96 121 535 minecraft:blackstone
setblock 96 118 539 minecraft:smooth_basalt
fill 96 118 540 96 121 540 minecraft:blackstone
setblock 96 118 544 minecraft:smooth_basalt
fill 96 118 545 96 121 545 minecraft:blackstone
setblock 96 118 549 minecraft:smooth_basalt
setblock 97 118 538 minecraft:smooth_basalt
fill 97 118 539 97 121 539 minecraft:blackstone
setblock 97 118 543 minecraft:smooth_basalt
fill 97 118 544 97 121 544 minecraft:blackstone
setblock 98 118 542 minecraft:smooth_basalt
fill 98 118 543 98 119 543 minecraft:blackstone
fill 115 118 511 115 121 511 minecraft:blackstone
setblock 118 118 512 minecraft:smooth_basalt
setblock 119 118 511 minecraft:smooth_basalt
fill 119 118 512 119 119 512 minecraft:blackstone
fill 120 118 511 120 121 511 minecraft:blackstone
setblock 134 118 511 minecraft:smooth_basalt
setblock 134 118 541 minecraft:smooth_basalt
fill 134 118 542 134 121 542 minecraft:blackstone
setblock 134 118 545 minecraft:blackstone
setblock 134 118 546 minecraft:smooth_basalt
fill 134 118 547 134 121 547 minecraft:blackstone
fill 134 118 549 134 119 549 minecraft:blackstone
setblock 134 118 551 minecraft:smooth_basalt
fill 135 118 511 135 119 511 minecraft:blackstone
setblock 135 118 515 minecraft:smooth_basalt
fill 135 118 516 135 121 516 minecraft:blackstone
setblock 135 118 520 minecraft:smooth_basalt
fill 135 118 521 135 121 521 minecraft:blackstone
setblock 135 118 535 minecraft:smooth_basalt
fill 135 118 536 135 121 536 minecraft:blackstone
setblock 135 118 540 minecraft:smooth_basalt
fill 135 118 541 135 121 541 minecraft:blackstone
setblock 135 118 545 minecraft:smooth_basalt
fill 135 118 546 135 121 546 minecraft:blackstone
setblock 135 118 550 minecraft:smooth_basalt
fill 135 118 551 135 121 551 minecraft:blackstone
setblock 95 119 519 minecraft:smooth_basalt
fill 95 119 520 95 122 520 minecraft:blackstone
setblock 95 119 524 minecraft:smooth_basalt
fill 95 119 525 95 119 528 minecraft:blackstone
setblock 95 119 529 minecraft:smooth_basalt
fill 95 119 530 95 119 533 minecraft:blackstone
setblock 95 119 534 minecraft:smooth_basalt
fill 95 119 535 95 119 538 minecraft:blackstone
setblock 95 119 539 minecraft:smooth_basalt
fill 95 119 540 95 122 540 minecraft:blackstone
setblock 95 119 544 minecraft:smooth_basalt
fill 95 119 545 95 122 545 minecraft:blackstone
setblock 95 119 549 minecraft:smooth_basalt
fill 95 119 550 95 122 550 minecraft:blackstone
fill 96 119 519 96 122 519 minecraft:blackstone
setblock 96 119 523 minecraft:smooth_basalt
fill 96 119 524 96 120 526 minecraft:blackstone
fill 96 119 534 96 122 534 minecraft:blackstone
setblock 96 119 538 minecraft:smooth_basalt
fill 96 119 539 96 122 539 minecraft:blackstone
setblock 96 119 543 minecraft:smooth_basalt
fill 96 119 544 96 122 544 minecraft:blackstone
setblock 96 119 548 minecraft:smooth_basalt
fill 96 119 549 96 122 549 minecraft:blackstone
setblock 97 119 537 minecraft:smooth_basalt
fill 97 119 538 97 121 538 minecraft:blackstone
setblock 97 119 542 minecraft:smooth_basalt
fill 97 119 543 97 122 543 minecraft:blackstone
setblock 98 119 541 minecraft:smooth_basalt
setblock 98 119 542 minecraft:blackstone
setblock 98 119 551 minecraft:smooth_basalt
setblock 117 119 512 minecraft:smooth_basalt
setblock 118 119 511 minecraft:smooth_basalt
setblock 118 119 512 minecraft:blackstone
fill 119 119 511 119 122 511 minecraft:blackstone
setblock 132 119 551 minecraft:blackstone
setblock 133 119 551 minecraft:smooth_basalt
setblock 134 119 540 minecraft:smooth_basalt
fill 134 119 541 134 122 541 minecraft:blackstone
setblock 134 119 545 minecraft:smooth_basalt
fill 134 119 546 134 122 546 minecraft:blackstone
setblock 134 119 550 minecraft:smooth_basalt
fill 134 119 551 134 122 551 minecraft:blackstone
setblock 135 119 514 minecraft:smooth_basalt
fill 135 119 515 135 121 515 minecraft:blackstone
setblock 135 119 519 minecraft:smooth_basalt
fill 135 119 520 135 122 520 minecraft:blackstone
setblock 135 119 524 minecraft:smooth_basalt
fill 135 119 525 135 122 525 minecraft:blackstone
fill 135 119 535 135 122 535 minecraft:blackstone
setblock 135 119 539 minecraft:smooth_basalt
fill 135 119 540 135 122 540 minecraft:blackstone
setblock 135 119 544 minecraft:smooth_basalt
fill 135 119 545 135 122 545 minecraft:blackstone
setblock 135 119 549 minecraft:smooth_basalt
fill 135 119 550 135 122 550 minecraft:blackstone
setblock 95 120 518 minecraft:smooth_basalt
fill 95 120 519 95 123 519 minecraft:blackstone
setblock 95 120 523 minecraft:smooth_basalt
fill 95 120 524 95 120 527 minecraft:blackstone
setblock 95 120 528 minecraft:smooth_basalt
fill 95 120 529 95 120 532 minecraft:blackstone
setblock 95 120 533 minecraft:smooth_basalt
fill 95 120 534 95 120 537 minecraft:blackstone
setblock 95 120 538 minecraft:smooth_basalt
fill 95 120 539 95 123 539 minecraft:blackstone
setblock 95 120 543 minecraft:smooth_basalt
fill 95 120 544 95 123 544 minecraft:blackstone
setblock 95 120 548 minecraft:smooth_basalt
fill 95 120 549 95 123 549 minecraft:blackstone
setblock 96 120 522 minecraft:smooth_basalt
fill 96 120 523 96 123 523 minecraft:blackstone
setblock 96 120 527 minecraft:smooth_basalt
fill 96 120 528 96 123 528 minecraft:blackstone
setblock 96 120 537 minecraft:smooth_basalt
fill 96 120 538 96 123 538 minecraft:blackstone
setblock 96 120 542 minecraft:smooth_basalt
fill 96 120 543 96 123 543 minecraft:blackstone
setblock 96 120 547 minecraft:smooth_basalt
fill 96 120 548 96 123 548 minecraft:blackstone
setblock 97 120 537 minecraft:blackstone
setblock 97 120 541 minecraft:smooth_basalt
fill 97 120 542 97 123 542 minecraft:blackstone
setblock 97 120 546 minecraft:smooth_basalt
setblock 97 120 551 minecraft:smooth_basalt
fill 114 120 511 114 122 511 minecraft:blackstone
setblock 117 120 511 minecraft:smooth_basalt
setblock 117 120 551 minecraft:smooth_basalt
fill 118 120 511 118 123 511 minecraft:blackstone
fill 118 120 551 119 122 551 minecraft:blackstone
setblock 131 120 551 minecraft:blackstone
setblock 132 120 551 minecraft:smooth_basalt
fill 133 120 542 133 120 544 minecraft:blackstone
setblock 133 120 545 minecraft:smooth_basalt
fill 133 120 546 133 123 546 minecraft:blackstone
setblock 133 120 550 minecraft:smooth_basalt
fill 133 120 551 133 123 551 minecraft:blackstone
setblock 134 120 539 minecraft:smooth_basalt
fill 134 120 540 134 123 540 minecraft:blackstone
setblock 134 120 544 minecraft:smooth_basalt
fill 134 120 545 134 123 545 minecraft:blackstone
setblock 134 120 549 minecraft:smooth_basalt
fill 134 120 550 134 123 550 minecraft:blackstone
setblock 135 120 514 minecraft:blackstone
setblock 135 120 518 minecraft:smooth_basalt
fill 135 120 519 135 123 519 minecraft:blackstone
setblock 135 120 523 minecraft:smooth_basalt
fill 135 120 524 135 123 524 minecraft:blackstone
fill 135 120 526 135 121 526 minecraft:blackstone
setblock 135 120 538 minecraft:smooth_basalt
fill 135 120 539 135 123 539 minecraft:blackstone
setblock 135 120 543 minecraft:smooth_basalt
fill 135 120 544 135 123 544 minecraft:blackstone
setblock 135 120 548 minecraft:smooth_basalt
fill 135 120 549 135 123 549 minecraft:blackstone
setblock 95 121 517 minecraft:smooth_basalt
fill 95 121 518 95 124 518 minecraft:blackstone
setblock 95 121 522 minecraft:smooth_basalt
fill 95 121 523 95 121 526 minecraft:blackstone
setblock 95 121 527 minecraft:smooth_basalt
fill 95 121 528 95 121 531 minecraft:blackstone
setblock 95 121 532 minecraft:smooth_basalt
fill 95 121 533 95 121 536 minecraft:blackstone
setblock 95 121 537 minecraft:smooth_basalt
fill 95 121 538 95 124 538 minecraft:blackstone
setblock 95 121 542 minecraft:smooth_basalt
fill 95 121 543 95 124 543 minecraft:blackstone
setblock 95 121 547 minecraft:smooth_basalt
fill 95 121 548 95 124 548 minecraft:blackstone
setblock 96 121 521 minecraft:smooth_basalt
fill 96 121 522 96 124 522 minecraft:blackstone
fill 96 121 524 96 121 525 minecraft:blackstone
setblock 96 121 526 minecraft:smooth_basalt
fill 96 121 527 96 124 527 minecraft:blackstone
fill 96 121 529 96 121 530 minecraft:blackstone
fill 96 121 533 96 123 533 minecraft:blackstone
setblock 96 121 536 minecraft:smooth_basalt
fill 96 121 537 96 124 537 minecraft:blackstone
setblock 96 121 541 minecraft:smooth_basalt
fill 96 121 542 96 124 542 minecraft:blackstone
setblock 96 121 546 minecraft:smooth_basalt
fill 96 121 547 97 123 547 minecraft:blackstone
setblock 96 121 551 minecraft:smooth_basalt
setblock 97 121 540 minecraft:smooth_basalt
fill 97 121 541 97 124 541 minecraft:blackstone
setblock 97 121 545 minecraft:smooth_basalt
fill 97 121 546 97 124 546 minecraft:blackstone
fill 97 121 551 98 123 551 minecraft:blackstone
setblock 115 121 551 minecraft:blackstone
setblock 116 121 511 minecraft:smooth_basalt
setblock 116 121 551 minecraft:smooth_basalt
fill 117 121 511 117 124 511 minecraft:blackstone
fill 117 121 551 117 124 551 minecraft:blackstone
setblock 120 121 551 minecraft:blackstone
setblock 121 121 511 minecraft:smooth_basalt
setblock 130 121 551 minecraft:blackstone
setblock 131 121 551 minecraft:smooth_basalt
setblock 132 121 550 minecraft:smooth_basalt
fill 132 121 551 132 124 551 minecraft:blackstone
fill 133 121 542 133 121 543 minecraft:blackstone
setblock 133 121 544 minecraft:smooth_basalt
fill 133 121 545 133 124 545 minecraft:blackstone
fill 133 121 547 133 121 548 minecraft:blackstone
fill 133 121 550 133 124 550 minecraft:blackstone
setblock 134 121 538 minecraft:smooth_basalt
fill 134 121 539 134 124 539 minecraft:blackstone
setblock 134 121 543 minecraft:smooth_basalt
fill 134 121 544 134 124 544 minecraft:blackstone
setblock 134 121 548 minecraft:smooth_basalt
fill 134 121 549 134 124 549 minecraft:blackstone
setblock 135 121 511 minecraft:blackstone
setblock 135 121 517 minecraft:smooth_basalt
fill 135 121 518 135 124 518 minecraft:blackstone
setblock 135 121 522 minecraft:smooth_basalt
fill 135 121 523 135 124 523 minecraft:blackstone
setblock 135 121 527 minecraft:smooth_basalt
fill 135 121 528 135 124 528 minecraft:blackstone
setblock 135 121 537 minecraft:smooth_basalt
fill 135 121 538 135 124 538 minecraft:blackstone
setblock 135 121 542 minecraft:smooth_basalt
fill 135 121 543 135 124 543 minecraft:blackstone
setblock 135 121 547 minecraft:smooth_basalt
fill 135 121 548 135 124 548 minecraft:blackstone
fill 95 122 517 95 125 517 minecraft:blackstone
setblock 95 122 521 minecraft:smooth_basalt
fill 95 122 522 95 122 525 minecraft:blackstone
setblock 95 122 526 minecraft:smooth_basalt
fill 95 122 527 95 122 530 minecraft:blackstone
setblock 95 122 531 minecraft:smooth_basalt
fill 95 122 532 95 122 535 minecraft:blackstone
setblock 95 122 536 minecraft:smooth_basalt
fill 95 122 537 95 125 537 minecraft:blackstone
setblock 95 122 541 minecraft:smooth_basalt
fill 95 122 542 95 125 542 minecraft:blackstone
setblock 95 122 546 minecraft:smooth_basalt
fill 95 122 547 95 125 547 minecraft:blackstone
setblock 95 122 551 minecraft:smooth_basalt
setblock 96 122 520 minecraft:smooth_basalt
fill 96 122 521 96 125 521 minecraft:blackstone
setblock 96 122 524 minecraft:blackstone
setblock 96 122 525 minecraft:smooth_basalt
fill 96 122 526 97 124 526 minecraft:blackstone
setblock 96 122 529 minecraft:blackstone
setblock 96 122 530 minecraft:smooth_basalt
fill 96 122 531 96 124 532 minecraft:blackstone
setblock 96 122 535 minecraft:smooth_basalt
fill 96 122 536 96 125 536 minecraft:blackstone
setblock 96 122 540 minecraft:smooth_basalt
fill 96 122 541 96 125 541 minecraft:blackstone
setblock 96 122 545 minecraft:smooth_basalt
fill 96 122 546 96 125 546 minecraft:blackstone
setblock 96 122 550 minecraft:smooth_basalt
fill 96 122 551 96 125 551 minecraft:blackstone
fill 97 122 522 97 122 523 minecraft:blackstone
setblock 97 122 524 minecraft:smooth_basalt
fill 97 122 525 97 125 525 minecraft:blackstone
fill 97 122 527 97 123 527 minecraft:blackstone
setblock 97 122 539 minecraft:smooth_basalt
fill 97 122 540 97 124 540 minecraft:blackstone
setblock 97 122 544 minecraft:smooth_basalt
fill 97 122 545 97 125 545 minecraft:blackstone
fill 113 122 511 113 123 511 minecraft:blackstone
fill 113 122 551 114 122 551 minecraft:blackstone
setblock 115 122 511 minecraft:smooth_basalt
fill 115 122 512 118 122 512 minecraft:blackstone
setblock 115 122 551 minecraft:smooth_basalt
fill 116 122 511 116 125 511 minecraft:blackstone
fill 116 122 551 116 125 551 minecraft:blackstone
setblock 120 122 511 minecraft:smooth_basalt
setblock 120 122 551 minecraft:smooth_basalt
fill 121 122 511 121 125 511 minecraft:blackstone
fill 121 122 551 122 124 551 minecraft:blackstone
fill 128 122 551 129 122 551 minecraft:blackstone
setblock 130 122 550 minecraft:blackstone
setblock 130 122 551 minecraft:smooth_basalt
setblock 131 122 550 minecraft:smooth_basalt
fill 131 122 551 131 125 551 minecraft:blackstone
setblock 132 122 549 minecraft:smooth_basalt
fill 132 122 550 132 125 550 minecraft:blackstone
fill 133 122 511 134 122 511 minecraft:blackstone
fill 133 122 541 133 122 542 minecraft:blackstone
setblock 133 122 543 minecraft:smooth_basalt
fill 133 122 544 133 125 544 minecraft:blackstone
setblock 133 122 547 minecraft:blackstone
setblock 133 122 548 minecraft:smooth_basalt
fill 133 122 549 133 125 549 minecraft:blackstone
setblock 134 122 521 minecraft:blackstone
setblock 134 122 522 minecraft:smooth_basalt
fill 134 122 523 134 123 525 minecraft:blackstone
fill 134 122 538 134 125 538 minecraft:blackstone
setblock 134 122 542 minecraft:smooth_basalt
fill 134 122 543 134 125 543 minecraft:blackstone
setblock 134 122 547 minecraft:smooth_basalt
fill 134 122 548 134 125 548 minecraft:blackstone
setblock 135 122 511 minecraft:smooth_basalt
setblock 135 122 516 minecraft:smooth_basalt
fill 135 122 517 135 125 517 minecraft:blackstone
setblock 135 122 521 minecraft:smooth_basalt
fill 135 122 522 135 125 522 minecraft:blackstone
setblock 135 122 526 minecraft:smooth_basalt
fill 135 122 527 135 125 527 minecraft:blackstone
fill 135 122 529 135 122 530 minecraft:blackstone
setblock 135 122 531 minecraft:smooth_basalt
fill 135 122 532 135 123 534 minecraft:blackstone
setblock 135 122 536 minecraft:smooth_basalt
fill 135 122 537 135 125 537 minecraft:blackstone
setblock 135 122 541 minecraft:smooth_basalt
fill 135 122 542 135 125 542 minecraft:blackstone
setblock 135 122 546 minecraft:smooth_basalt
fill 135 122 547 135 125 547 minecraft:blackstone
setblock 135 122 551 minecraft:smooth_basalt
setblock 95 123 520 minecraft:smooth_basalt
fill 95 123 521 95 123 524 minecraft:blackstone
setblock 95 123 525 minecraft:smooth_basalt
fill 95 123 526 95 123 529 minecraft:blackstone
setblock 95 123 530 minecraft:smooth_basalt
fill 95 123 531 95 123 534 minecraft:blackstone
setblock 95 123 535 minecraft:smooth_basalt
fill 95 123 536 95 126 536 minecraft:blackstone
setblock 95 123 540 minecraft:smooth_basalt
fill 95 123 541 95 126 541 minecraft:blackstone
setblock 95 123 545 minecraft:smooth_basalt
fill 95 123 546 95 126 546 minecraft:blackstone
setblock 95 123 550 minecraft:smooth_basalt
fill 95 123 551 95 126 551 minecraft:blackstone
setblock 96 123 519 minecraft:smooth_basalt
fill 96 123 520 96 126 520 minecraft:blackstone
setblock 96 123 524 minecraft:smooth_basalt
fill 96 123 525 96 126 525 minecraft:blackstone
setblock 96 123 529 minecraft:smooth_basalt
fill 96 123 530 96 126 530 minecraft:blackstone
setblock 96 123 534 minecraft:smooth_basalt
fill 96 123 535 96 126 535 minecraft:blackstone
setblock 96 123 539 minecraft:smooth_basalt
fill 96 123 540 96 126 540 minecraft:blackstone
setblock 96 123 544 minecraft:smooth_basalt
fill 96 123 545 96 126 545 minecraft:blackstone
setblock 96 123 549 minecraft:smooth_basalt
fill 96 123 550 97 125 550 minecraft:blackstone
setblock 97 123 522 minecraft:blackstone
setblock 97 123 523 minecraft:smooth_basalt
fill 97 123 524 97 126 524 minecraft:blackstone
setblock 97 123 528 minecraft:smooth_basalt
fill 97 123 529 97 126 529 minecraft:blackstone
setblock 97 123 539 minecraft:blackstone
setblock 97 123 543 minecraft:smooth_basalt
fill 97 123 544 97 126 544 minecraft:blackstone
setblock 97 123 548 minecraft:smooth_basalt
fill 105 123 544 109 124 548 minecraft:blackstone
fill 107 123 549 107 123 550 minecraft:blackstone
fill 111 123 511 112 124 511 minecraft:blackstone
fill 112 123 551 113 123 551 minecraft:blackstone
setblock 114 123 511 minecraft:smooth_basalt
fill 114 123 512 117 123 512 minecraft:blackstone
setblock 114 123 550 minecraft:blackstone
setblock 114 123 551 minecraft:smooth_basalt
fill 115 123 511 115 126 511 minecraft:blackstone
setblock 115 123 550 minecraft:smooth_basalt
fill 115 123 551 115 126 551 minecraft:blackstone
fill 116 123 550 119 123 550 minecraft:blackstone
setblock 118 123 512 minecraft:smooth_basalt
setblock 118 123 551 minecraft:blackstone
setblock 119 123 511 minecraft:smooth_basalt
setblock 119 123 551 minecraft:smooth_basalt
fill 120 123 511 120 126 511 minecraft:blackstone
fill 120 123 551 120 126 551 minecraft:blackstone
fill 122 123 511 122 124 511 minecraft:blackstone
setblock 123 123 551 minecraft:blackstone
setblock 124 123 551 minecraft:smooth_basalt
fill 125 123 551 128 123 551 minecraft:blackstone
fill 128 123 550 129 123 550 minecraft:blackstone
setblock 129 123 551 minecraft:smooth_basalt
setblock 130 123 550 minecraft:smooth_basalt
fill 130 123 551 130 126 551 minecraft:blackstone
fill 131 123 511 133 123 511 minecraft:blackstone
setblock 131 123 549 minecraft:smooth_basalt
fill 131 123 550 131 126 550 minecraft:blackstone
fill 132 123 545 132 123 547 minecraft:blackstone
fill 132 123 549 132 126 549 minecraft:blackstone
setblock 133 123 541 minecraft:blackstone
setblock 133 123 542 minecraft:smooth_basalt
fill 133 123 543 133 126 543 minecraft:blackstone
setblock 133 123 547 minecraft:smooth_basalt
fill 133 123 548 133 126 548 minecraft:blackstone
setblock 134 123 511 minecraft:smooth_basalt
setblock 134 123 520 minecraft:blackstone
setblock 134 123 521 minecraft:smooth_basalt
fill 134 123 522 134 126 522 minecraft:blackstone
setblock 134 123 526 minecraft:smooth_basalt
fill 134 123 527 134 126 527 minecraft:blackstone
fill 134 123 537 134 126 537 minecraft:blackstone
setblock 134 123 541 minecraft:smooth_basalt
fill 134 123 542 134 126 542 minecraft:blackstone
setblock 134 123 546 minecraft:smooth_basalt
fill 134 123 547 134 126 547 minecraft:blackstone
setblock 134 123 551 minecraft:smooth_basalt
fill 135 123 511 135 124 513 minecraft:blackstone
fill 135 123 516 135 126 516 minecraft:blackstone
setblock 135 123 520 minecraft:smooth_basalt
fill 135 123 521 135 126 521 minecraft:blackstone
setblock 135 123 525 minecraft:smooth_basalt
fill 135 123 526 135 126 526 minecraft:blackstone
setblock 135 123 529 minecraft:blackstone
setblock 135 123 530 minecraft:smooth_basalt
fill 135 123 531 135 126 531 minecraft:blackstone
setblock 135 123 535 minecraft:smooth_basalt
fill 135 123 536 135 126 536 minecraft:blackstone
setblock 135 123 540 minecraft:smooth_basalt
fill 135 123 541 135 126 541 minecraft:blackstone
setblock 135 123 545 minecraft:smooth_basalt
fill 135 123 546 135 126 546 minecraft:blackstone
setblock 135 123 550 minecraft:smooth_basalt
fill 135 123 551 135 126 551 minecraft:blackstone
setblock 95 124 519 minecraft:smooth_basalt
fill 95 124 520 95 124 523 minecraft:blackstone
setblock 95 124 524 minecraft:smooth_basalt
fill 95 124 525 95 124 528 minecraft:blackstone
setblock 95 124 529 minecraft:smooth_basalt
fill 95 124 530 95 124 533 minecraft:blackstone
setblock 95 124 534 minecraft:smooth_basalt
fill 95 124 535 95 127 535 minecraft:blackstone
setblock 95 124 539 minecraft:smooth_basalt
fill 95 124 540 95 127 540 minecraft:blackstone
setblock 95 124 544 minecraft:smooth_basalt
fill 95 124 545 95 127 545 minecraft:blackstone
setblock 95 124 549 minecraft:smooth_basalt
fill 95 124 550 95 127 550 minecraft:blackstone
fill 96 124 519 96 125 519 minecraft:blackstone
setblock 96 124 523 minecraft:smooth_basalt
fill 96 124 524 96 127 524 minecraft:blackstone
setblock 96 124 528 minecraft:smooth_basalt
fill 96 124 529 96 127 529 minecraft:blackstone
setblock 96 124 533 minecraft:smooth_basalt
fill 96 124 534 96 127 534 minecraft:blackstone
setblock 96 124 538 minecraft:smooth_basalt
fill 96 124 539 96 127 539 minecraft:blackstone
setblock 96 124 543 minecraft:smooth_basalt
fill 96 124 544 96 127 544 minecraft:blackstone
setblock 96 124 547 minecraft:blackstone
setblock 96 124 548 minecraft:smooth_basalt
fill 96 124 549 96 127 549 minecraft:blackstone
setblock 97 124 522 minecraft:smooth_basalt
fill 97 124 523 97 127 523 minecraft:blackstone
setblock 97 124 527 minecraft:smooth_basalt
fill 97 124 528 97 127 528 minecraft:blackstone
fill 97 124 530 97 124 531 minecraft:blackstone
setblock 97 124 542 minecraft:smooth_basalt
fill 97 124 543 97 126 543 minecraft:blackstone
setblock 97 124 547 minecraft:smooth_basalt
fill 97 124 548 97 127 548 minecraft:blackstone
setblock 97 124 551 minecraft:blackstone
setblock 98 124 550 minecraft:blackstone
setblock 98 124 551 minecraft:smooth_basalt
fill 99 124 551 99 127 551 minecraft:blackstone
fill 110 124 511 110 126 511 minecraft:blackstone
fill 110 124 551 112 124 551 minecraft:blackstone
setblock 112 124 512 minecraft:smooth_basalt
fill 112 124 550 113 124 550 minecraft:blackstone
setblock 113 124 511 minecraft:smooth_basalt
fill 113 124 512 116 124 512 minecraft:blackstone
setblock 113 124 551 minecraft:smooth_basalt
fill 114 124 511 114 127 511 minecraft:blackstone
setblock 114 124 550 minecraft:smooth_basalt
fill 114 124 551 114 127 551 minecraft:blackstone
fill 115 124 550 118 124 550 minecraft:blackstone
fill 116 124 549 116 127 549 minecraft:blackstone
setblock 117 124 512 minecraft:smooth_basalt
setblock 118 124 511 minecraft:smooth_basalt
fill 118 124 512 119 126 512 minecraft:blackstone
setblock 118 124 551 minecraft:smooth_basalt
fill 119 124 511 119 127 511 minecraft:blackstone
setblock 119 124 550 minecraft:smooth_basalt
fill 119 124 551 119 127 551 minecraft:blackstone
fill 120 124 550 121 126 550 minecraft:blackstone
setblock 123 124 551 minecraft:smooth_basalt
fill 124 124 551 127 124 551 minecraft:blackstone
fill 126 124 550 128 124 550 minecraft:blackstone
setblock 128 124 551 minecraft:smooth_basalt
fill 129 124 511 132 124 511 minecraft:blackstone
setblock 129 124 549 minecraft:blackstone
setblock 129 124 550 minecraft:smooth_basalt
fill 129 124 551 129 127 551 minecraft:blackstone
setblock 130 124 549 minecraft:smooth_basalt
fill 130 124 550 130 127 550 minecraft:blackstone
setblock 131 124 548 minecraft:smooth_basalt
fill 131 124 549 131 127 549 minecraft:blackstone
fill 132 124 543 132 124 546 minecraft:blackstone
setblock 132 124 547 minecraft:smooth_basalt
fill 132 124 548 132 127 548 minecraft:blackstone
setblock 133 124 511 minecraft:smooth_basalt
setblock 133 124 540 minecraft:blackstone
setblock 133 124 541 minecraft:smooth_basalt
fill 133 124 542 133 127 542 minecraft:blackstone
setblock 133 124 546 minecraft:smooth_basalt
fill 133 124 547 133 127 547 minecraft:blackstone
setblock 133 124 551 minecraft:smooth_basalt
fill 134 124 511 134 127 511 minecraft:blackstone
setblock 134 124 520 minecraft:smooth_basalt
fill 134 124 521 134 127 521 minecraft:blackstone
fill 134 124 523 134 124 524 minecraft:blackstone
setblock 134 124 525 minecraft:smooth_basalt
fill 134 124 526 134 127 526 minecraft:blackstone
fill 134 124 528 134 124 529 minecraft:blackstone
setblock 134 124 530 minecraft:smooth_basalt
fill 134 124 536 134 127 536 minecraft:blackstone
setblock 134 124 540 minecraft:smooth_basalt
fill 134 124 541 134 127 541 minecraft:blackstone
setblock 134 124 545 minecraft:smooth_basalt
fill 134 124 546 134 127 546 minecraft:blackstone
setblock 134 124 550 minecraft:smooth_basalt
fill 134 124 551 134 127 551 minecraft:blackstone
setblock 135 124 514 minecraft:smooth_basalt
fill 135 124 515 135 127 515 minecraft:blackstone
setblock 135 124 519 minecraft:smooth_basalt
fill 135 124 520 135 127 520 minecraft:blackstone
setblock 135 124 524 minecraft:smooth_basalt
fill 135 124 525 135 127 525 minecraft:blackstone
setblock 135 124 529 minecraft:smooth_basalt
fill 135 124 530 135 127 530 minecraft:blackstone
fill 135 124 532 135 124 533 minecraft:blackstone
setblock 135 124 534 minecraft:smooth_basalt
fill 135 124 535 135 127 535 minecraft:blackstone
setblock 135 124 539 minecraft:smooth_basalt
fill 135 124 540 135 127 540 minecraft:blackstone
setblock 135 124 544 minecraft:smooth_basalt
fill 135 124 545 135 127 545 minecraft:blackstone
setblock 135 124 549 minecraft:smooth_basalt
fill 135 124 550 135 127 550 minecraft:blackstone
fill 95 125 511 96 125 511 minecraft:blackstone
fill 95 125 516 95 126 516 minecraft:blackstone
setblock 95 125 518 minecraft:smooth_basalt
fill 95 125 519 95 125 522 minecraft:blackstone
setblock 95 125 523 minecraft:smooth_basalt
fill 95 125 524 95 125 527 minecraft:blackstone
setblock 95 125 528 minecraft:smooth_basalt
fill 95 125 529 95 125 532 minecraft:blackstone
setblock 95 125 533 minecraft:smooth_basalt
fill 95 125 534 95 128 534 minecraft:blackstone
setblock 95 125 538 minecraft:smooth_basalt
fill 95 125 539 95 128 539 minecraft:blackstone
setblock 95 125 543 minecraft:smooth_basalt
fill 95 125 544 95 128 544 minecraft:blackstone
setblock 95 125 548 minecraft:smooth_basalt
fill 95 125 549 95 128 549 minecraft:blackstone
setblock 96 125 522 minecraft:smooth_basalt
fill 96 125 523 96 128 523 minecraft:blackstone
setblock 96 125 526 minecraft:blackstone
setblock 96 125 527 minecraft:smooth_basalt
fill 96 125 528 96 128 528 minecraft:blackstone
setblock 96 125 531 minecraft:blackstone
setblock 96 125 532 minecraft:smooth_basalt
fill 96 125 533 96 128 533 minecraft:blackstone
setblock 96 125 537 minecraft:smooth_basalt
fill 96 125 538 96 128 538 minecraft:blackstone
setblock 96 125 542 minecraft:smooth_basalt
fill 96 125 543 96 128 543 minecraft:blackstone
setblock 96 125 547 minecraft:smooth_basalt
fill 96 125 548 96 128 548 minecraft:blackstone
setblock 97 125 513 minecraft:light[level=12]
setblock 97 125 521 minecraft:light[level=12]
fill 97 125 522 97 126 522 minecraft:blackstone
setblock 97 125 526 minecraft:smooth_basalt
fill 97 125 527 97 128 527 minecraft:blackstone
setblock 97 125 530 minecraft:blackstone
setblock 97 125 531 minecraft:smooth_basalt
fill 97 125 532 97 128 532 minecraft:blackstone
setblock 97 125 537 minecraft:light[level=12]
setblock 97 125 541 minecraft:smooth_basalt
setblock 97 125 542 minecraft:blackstone
setblock 97 125 546 minecraft:smooth_basalt
fill 97 125 547 97 127 547 minecraft:blackstone
setblock 97 125 551 minecraft:smooth_basalt
setblock 98 125 550 minecraft:smooth_basalt
fill 98 125 551 98 128 551 minecraft:blackstone
setblock 105 125 513 minecraft:light[level=12]
setblock 105 125 521 minecraft:light[level=12]
setblock 105 125 529 minecraft:light[level=12]
setblock 105 125 537 minecraft:light[level=12]
setblock 105 125 545 minecraft:light[level=12]
fill 106 125 545 108 126 547 minecraft:smooth_basalt
fill 108 125 551 111 125 551 minecraft:blackstone
fill 109 125 511 109 127 511 minecraft:blackstone
fill 110 125 550 112 125 550 minecraft:blackstone
setblock 111 125 511 minecraft:blackstone
setblock 111 125 512 minecraft:smooth_basalt
setblock 112 125 511 minecraft:smooth_basalt
fill 112 125 512 115 125 512 minecraft:blackstone
setblock 112 125 551 minecraft:smooth_basalt
fill 113 125 511 113 128 511 minecraft:blackstone
setblock 113 125 513 minecraft:light[level=12]
setblock 113 125 521 minecraft:light[level=12]
setblock 113 125 529 minecraft:light[level=12]
setblock 113 125 537 minecraft:light[level=12]
setblock 113 125 545 minecraft:light[level=12]
setblock 113 125 549 minecraft:blackstone
setblock 113 125 550 minecraft:smooth_basalt
fill 113 125 551 113 128 551 minecraft:blackstone
setblock 114 125 549 minecraft:smooth_basalt
fill 114 125 550 117 125 550 minecraft:blackstone
fill 115 125 549 115 128 549 minecraft:blackstone
setblock 116 125 512 minecraft:smooth_basalt
setblock 117 125 511 minecraft:smooth_basalt
fill 117 125 512 117 128 512 minecraft:blackstone
fill 117 125 549 118 125 549 minecraft:blackstone
setblock 117 125 551 minecraft:smooth_basalt
fill 118 125 511 118 128 511 minecraft:blackstone
setblock 118 125 550 minecraft:smooth_basalt
fill 118 125 551 118 128 551 minecraft:blackstone
fill 119 125 550 119 128 550 minecraft:blackstone
setblock 121 125 513 minecraft:light[level=12]
setblock 121 125 521 minecraft:light[level=12]
setblock 121 125 529 minecraft:light[level=12]
setblock 121 125 537 minecraft:light[level=12]
setblock 121 125 545 minecraft:light[level=12]
setblock 121 125 551 minecraft:blackstone
setblock 122 125 511 minecraft:smooth_basalt
setblock 122 125 550 minecraft:blackstone
setblock 122 125 551 minecraft:smooth_basalt
fill 123 125 511 126 125 511 minecraft:blackstone
setblock 123 125 550 minecraft:smooth_basalt
fill 123 125 551 126 125 551 minecraft:blackstone
fill 124 125 550 127 125 550 minecraft:blackstone
setblock 127 125 511 minecraft:smooth_basalt
fill 127 125 549 128 125 549 minecraft:blackstone
setblock 127 125 551 minecraft:smooth_basalt
fill 128 125 511 131 125 511 minecraft:blackstone
setblock 128 125 550 minecraft:smooth_basalt
fill 128 125 551 128 128 551 minecraft:blackstone
setblock 129 125 513 minecraft:light[level=12]
setblock 129 125 521 minecraft:light[level=12]
setblock 129 125 529 minecraft:light[level=12]
setblock 129 125 537 minecraft:light[level=12]
setblock 129 125 545 minecraft:light[level=12]
setblock 129 125 549 minecraft:smooth_basalt
fill 129 125 550 129 128 550 minecraft:blackstone
setblock 130 125 548 minecraft:smooth_basalt
fill 130 125 549 130 128 549 minecraft:blackstone
fill 131 125 548 131 128 548 minecraft:blackstone
setblock 132 125 511 minecraft:smooth_basalt
fill 132 125 543 132 125 545 minecraft:blackstone
setblock 132 125 546 minecraft:smooth_basalt
fill 132 125 547 132 128 547 minecraft:blackstone
setblock 132 125 551 minecraft:smooth_basalt
fill 133 125 511 133 128 511 minecraft:blackstone
setblock 133 125 525 minecraft:smooth_basalt
fill 133 125 526 133 128 526 minecraft:blackstone
setblock 133 125 540 minecraft:smooth_basalt
fill 133 125 541 133 128 541 minecraft:blackstone
setblock 133 125 545 minecraft:smooth_basalt
fill 133 125 546 133 128 546 minecraft:blackstone
setblock 133 125 550 minecraft:smooth_basalt
fill 133 125 551 133 128 551 minecraft:blackstone
setblock 134 125 520 minecraft:blackstone
setblock 134 125 523 minecraft:blackstone
setblock 134 125 524 minecraft:smooth_basalt
fill 134 125 525 134 128 525 minecraft:blackstone
setblock 134 125 528 minecraft:blackstone
setblock 134 125 529 minecraft:smooth_basalt
fill 134 125 530 134 125 533 minecraft:blackstone
setblock 134 125 534 minecraft:smooth_basalt
fill 134 125 535 134 128 535 minecraft:blackstone
setblock 134 125 539 minecraft:smooth_basalt
fill 134 125 540 134 128 540 minecraft:blackstone
setblock 134 125 544 minecraft:smooth_basalt
fill 134 125 545 134 128 545 minecraft:blackstone
setblock 134 125 549 minecraft:smooth_basalt
fill 134 125 550 134 128 550 minecraft:blackstone
fill 135 125 511 135 125 512 minecraft:blackstone
setblock 135 125 513 minecraft:smooth_basalt
fill 135 125 514 135 128 514 minecraft:blackstone
setblock 135 125 518 minecraft:smooth_basalt
fill 135 125 519 135 128 519 minecraft:blackstone
setblock 135 125 523 minecraft:smooth_basalt
fill 135 125 524 135 128 524 minecraft:blackstone
setblock 135 125 528 minecraft:smooth_basalt
fill 135 125 529 135 128 529 minecraft:blackstone
setblock 135 125 532 minecraft:blackstone
setblock 135 125 533 minecraft:smooth_basalt
fill 135 125 534 135 128 534 minecraft:blackstone
setblock 135 125 538 minecraft:smooth_basalt
fill 135 125 539 135 128 539 minecraft:blackstone
setblock 135 125 543 minecraft:smooth_basalt
fill 135 125 544 135 128 544 minecraft:blackstone
setblock 135 125 548 minecraft:smooth_basalt
fill 135 125 549 135 128 549 minecraft:blackstone
setblock 95 126 511 minecraft:blackstone
setblock 95 126 512 minecraft:smooth_basalt
fill 95 126 513 95 129 513 minecraft:blackstone
setblock 95 126 517 minecraft:smooth_basalt
fill 95 126 518 95 126 521 minecraft:blackstone
setblock 95 126 522 minecraft:smooth_basalt
fill 95 126 523 95 126 526 minecraft:blackstone
setblock 95 126 527 minecraft:smooth_basalt
fill 95 126 528 95 126 531 minecraft:blackstone
setblock 95 126 532 minecraft:smooth_basalt
fill 95 126 533 95 129 533 minecraft:blackstone
setblock 95 126 537 minecraft:smooth_basalt
fill 95 126 538 95 129 538 minecraft:blackstone
setblock 95 126 542 minecraft:smooth_basalt
fill 95 126 543 95 129 543 minecraft:blackstone
setblock 95 126 547 minecraft:smooth_basalt
fill 95 126 548 95 129 548 minecraft:blackstone
setblock 96 126 511 minecraft:smooth_basalt
setblock 96 126 521 minecraft:smooth_basalt
fill 96 126 522 96 129 522 minecraft:blackstone
setblock 96 126 526 minecraft:smooth_basalt
fill 96 126 527 96 129 527 minecraft:blackstone
setblock 96 126 531 minecraft:smooth_basalt
fill 96 126 532 96 129 532 minecraft:blackstone
setblock 96 126 536 minecraft:smooth_basalt
fill 96 126 537 96 129 537 minecraft:blackstone
setblock 96 126 541 minecraft:smooth_basalt
fill 96 126 542 96 128 542 minecraft:blackstone
setblock 96 126 546 minecraft:smooth_basalt
fill 96 126 547 96 129 547 minecraft:blackstone
setblock 96 126 550 minecraft:blackstone
setblock 96 126 551 minecraft:smooth_basalt
setblock 97 126 525 minecraft:smooth_basalt
fill 97 126 526 98 126 526 minecraft:blackstone
setblock 97 126 530 minecraft:smooth_basalt
fill 97 126 531 97 129 531 minecraft:blackstone
fill 97 126 533 97 127 533 minecraft:blackstone
setblock 97 126 545 minecraft:smooth_basalt
fill 97 126 546 97 127 546 minecraft:blackstone
setblock 97 126 550 minecraft:smooth_basalt
fill 97 126 551 97 129 551 minecraft:blackstone
fill 98 126 527 98 127 527 minecraft:blackstone
fill 98 126 550 98 127 550 minecraft:blackstone
setblock 100 126 551 minecraft:blackstone
fill 107 126 511 108 128 511 minecraft:blackstone
fill 107 126 551 110 126 551 minecraft:blackstone
fill 109 126 550 111 126 550 minecraft:blackstone
setblock 110 126 512 minecraft:smooth_basalt
setblock 111 126 511 minecraft:smooth_basalt
fill 111 126 512 114 126 512 minecraft:blackstone
fill 111 126 549 112 126 549 minecraft:blackstone
setblock 111 126 551 minecraft:smooth_basalt
fill 112 126 511 112 129 511 minecraft:blackstone
setblock 112 126 550 minecraft:smooth_basalt
fill 112 126 551 112 129 551 minecraft:blackstone
setblock 113 126 513 minecraft:blackstone
setblock 113 126 549 minecraft:smooth_basalt
fill 113 126 550 116 126 550 minecraft:blackstone
setblock 114 126 513 minecraft:smooth_basalt
fill 114 126 549 114 129 549 minecraft:blackstone
setblock 115 126 512 minecraft:smooth_basalt
fill 115 126 513 116 128 513 minecraft:blackstone
setblock 116 126 511 minecraft:smooth_basalt
fill 116 126 512 116 129 512 minecraft:blackstone
setblock 116 126 551 minecraft:smooth_basalt
fill 117 126 511 117 129 511 minecraft:blackstone
setblock 117 126 549 minecraft:blackstone
setblock 117 126 550 minecraft:smooth_basalt
fill 117 126 551 117 129 551 minecraft:blackstone
setblock 118 126 549 minecraft:smooth_basalt
fill 118 126 550 118 129 550 minecraft:blackstone
fill 119 126 549 119 128 549 minecraft:blackstone
setblock 121 126 511 minecraft:smooth_basalt
setblock 121 126 551 minecraft:smooth_basalt
fill 122 126 511 125 126 511 minecraft:blackstone
setblock 122 126 550 minecraft:smooth_basalt
fill 122 126 551 125 126 551 minecraft:blackstone
fill 123 126 550 126 126 550 minecraft:blackstone
setblock 126 126 511 minecraft:smooth_basalt
fill 126 126 549 127 126 549 minecraft:blackstone
setblock 126 126 551 minecraft:smooth_basalt
fill 127 126 511 130 126 511 minecraft:blackstone
setblock 127 126 550 minecraft:smooth_basalt
fill 127 126 551 127 129 551 minecraft:blackstone
setblock 128 126 549 minecraft:smooth_basalt
fill 128 126 550 128 129 550 minecraft:blackstone
setblock 129 126 548 minecraft:smooth_basalt
fill 129 126 549 129 129 549 minecraft:blackstone
fill 130 126 548 130 129 548 minecraft:blackstone
setblock 131 126 511 minecraft:smooth_basalt
fill 131 126 512 133 127 512 minecraft:blackstone
fill 131 126 547 131 128 547 minecraft:blackstone
setblock 131 126 551 minecraft:smooth_basalt
fill 132 126 511 132 129 511 minecraft:blackstone
fill 132 126 543 132 126 544 minecraft:blackstone
setblock 132 126 545 minecraft:smooth_basalt
fill 132 126 546 132 129 546 minecraft:blackstone
setblock 132 126 550 minecraft:smooth_basalt
fill 132 126 551 132 129 551 minecraft:blackstone
setblock 133 126 524 minecraft:smooth_basalt
fill 133 126 525 133 128 525 minecraft:blackstone
fill 133 126 527 133 126 528 minecraft:blackstone
setblock 133 126 529 minecraft:smooth_basalt
fill 133 126 530 134 128 530 minecraft:blackstone
setblock 133 126 539 minecraft:smooth_basalt
fill 133 126 540 133 128 540 minecraft:blackstone
setblock 133 126 544 minecraft:smooth_basalt
fill 133 126 545 133 129 545 minecraft:blackstone
setblock 133 126 549 minecraft:smooth_basalt
fill 133 126 550 133 129 550 minecraft:blackstone
setblock 134 126 523 minecraft:smooth_basalt
fill 134 126 524 134 129 524 minecraft:blackstone
setblock 134 126 528 minecraft:smooth_basalt
fill 134 126 529 134 129 529 minecraft:blackstone
fill 134 126 531 134 126 532 minecraft:blackstone
setblock 134 126 533 minecraft:smooth_basalt
fill 134 126 534 134 129 534 minecraft:blackstone
setblock 134 126 538 minecraft:smooth_basalt
fill 134 126 539 134 129 539 minecraft:blackstone
setblock 134 126 543 minecraft:smooth_basalt
fill 134 126 544 134 129 544 minecraft:blackstone
setblock 134 126 548 minecraft:smooth_basalt
fill 134 126 549 134 129 549 minecraft:blackstone
setblock 135 126 511 minecraft:blackstone
setblock 135 126 512 minecraft:smooth_basalt
fill 135 126 513 135 129 513 minecraft:blackstone
setblock 135 126 517 minecraft:smooth_basalt
fill 135 126 518 135 127 518 minecraft:blackstone
setblock 135 126 522 minecraft:smooth_basalt
fill 135 126 523 135 129 523 minecraft:blackstone
setblock 135 126 527 minecraft:smooth_basalt
fill 135 126 528 135 129 528 minecraft:blackstone
setblock 135 126 532 minecraft:smooth_basalt
fill 135 126 533 135 129 533 minecraft:blackstone
setblock 135 126 537 minecraft:smooth_basalt
fill 135 126 538 135 129 538 minecraft:blackstone
setblock 135 126 542 minecraft:smooth_basalt
fill 135 126 543 135 129 543 minecraft:blackstone
setblock 135 126 547 minecraft:smooth_basalt
fill 135 126 548 135 129 548 minecraft:blackstone
setblock 95 127 511 minecraft:smooth_basalt
fill 95 127 512 95 130 512 minecraft:blackstone
setblock 95 127 516 minecraft:smooth_basalt
fill 95 127 517 95 127 520 minecraft:blackstone
setblock 95 127 521 minecraft:smooth_basalt
fill 95 127 522 95 127 525 minecraft:blackstone
setblock 95 127 526 minecraft:smooth_basalt
fill 95 127 527 95 127 530 minecraft:blackstone
setblock 95 127 531 minecraft:smooth_basalt
fill 95 127 532 95 130 532 minecraft:blackstone
setblock 95 127 536 minecraft:smooth_basalt
fill 95 127 537 95 130 537 minecraft:blackstone
setblock 95 127 541 minecraft:smooth_basalt
fill 95 127 542 95 130 542 minecraft:blackstone
setblock 95 127 546 minecraft:smooth_basalt
fill 95 127 547 95 130 547 minecraft:blackstone
setblock 95 127 551 minecraft:smooth_basalt
fill 96 127 511 97 129 511 minecraft:blackstone
setblock 96 127 520 minecraft:smooth_basalt
fill 96 127 521 96 128 521 minecraft:blackstone
setblock 96 127 525 minecraft:smooth_basalt
fill 96 127 526 97 129 526 minecraft:blackstone
setblock 96 127 530 minecraft:smooth_basalt
fill 96 127 531 96 130 531 minecraft:blackstone
setblock 96 127 535 minecraft:smooth_basalt
fill 96 127 536 96 130 536 minecraft:blackstone
setblock 96 127 540 minecraft:smooth_basalt
fill 96 127 541 96 128 541 minecraft:blackstone
setblock 96 127 545 minecraft:smooth_basalt
fill 96 127 546 96 129 546 minecraft:blackstone
setblock 96 127 550 minecraft:smooth_basalt
fill 96 127 551 96 130 551 minecraft:blackstone
setblock 97 127 524 minecraft:smooth_basalt
fill 97 127 525 97 129 525 minecraft:blackstone
setblock 97 127 529 minecraft:smooth_basalt
fill 97 127 530 97 130 530 minecraft:blackstone
setblock 97 127 545 minecraft:blackstone
fill 97 127 550 97 129 550 minecraft:blackstone
setblock 98 127 528 minecraft:smooth_basalt
fill 99 127 525 99 128 525 minecraft:gold_block
setblock 100 127 551 minecraft:smooth_basalt
setblock 105 127 551 minecraft:smooth_basalt
fill 106 127 511 106 130 511 minecraft:blackstone
fill 106 127 546 108 129 546 minecraft:smooth_basalt
fill 106 127 551 109 127 551 minecraft:blackstone
fill 107 127 545 107 129 545 minecraft:smooth_basalt
fill 107 127 547 107 129 547 minecraft:smooth_basalt
setblock 108 127 512 minecraft:blackstone
fill 108 127 550 110 127 550 minecraft:blackstone
setblock 109 127 512 minecraft:smooth_basalt
setblock 110 127 511 minecraft:smooth_basalt
fill 110 127 512 113 127 512 minecraft:blackstone
fill 110 127 549 111 127 549 minecraft:blackstone
setblock 110 127 551 minecraft:smooth_basalt
fill 111 127 511 111 130 511 minecraft:blackstone
fill 111 127 513 112 127 513 minecraft:blackstone
setblock 111 127 550 minecraft:smooth_basalt
fill 111 127 551 111 130 551 minecraft:blackstone
setblock 112 127 549 minecraft:smooth_basalt
fill 112 127 550 115 127 550 minecraft:blackstone
setblock 113 127 513 minecraft:smooth_basalt
fill 113 127 549 113 130 549 minecraft:blackstone
setblock 114 127 512 minecraft:smooth_basalt
fill 114 127 513 114 130 513 minecraft:blackstone
setblock 115 127 511 minecraft:smooth_basalt
fill 115 127 512 115 130 512 minecraft:blackstone
setblock 115 127 551 minecraft:smooth_basalt
fill 116 127 511 116 130 511 minecraft:blackstone
setblock 116 127 550 minecraft:smooth_basalt
fill 116 127 551 116 130 551 minecraft:blackstone
setblock 117 127 549 minecraft:smooth_basalt
fill 117 127 550 117 130 550 minecraft:blackstone
setblock 118 127 512 minecraft:blackstone
fill 118 127 549 118 129 549 minecraft:blackstone
setblock 119 127 512 minecraft:smooth_basalt
setblock 120 127 511 minecraft:smooth_basalt
fill 120 127 512 120 128 512 minecraft:blackstone
setblock 120 127 550 minecraft:blackstone
setblock 120 127 551 minecraft:smooth_basalt
fill 121 127 511 124 127 511 minecraft:blackstone
setblock 121 127 550 minecraft:smooth_basalt
fill 121 127 551 124 127 551 minecraft:blackstone
fill 122 127 550 125 127 550 minecraft:blackstone
fill 124 127 549 126 127 549 minecraft:blackstone
setblock 125 127 511 minecraft:smooth_basalt
setblock 125 127 551 minecraft:smooth_basalt
fill 126 127 511 129 127 511 minecraft:blackstone
setblock 126 127 550 minecraft:smooth_basalt
fill 126 127 551 126 130 551 minecraft:blackstone
setblock 127 127 549 minecraft:smooth_basalt
fill 127 127 550 127 130 550 minecraft:blackstone
setblock 128 127 548 minecraft:smooth_basalt
fill 128 127 549 128 130 549 minecraft:blackstone
setblock 129 127 512 minecraft:smooth_basalt
fill 129 127 548 129 130 548 minecraft:blackstone
setblock 130 127 511 minecraft:smooth_basalt
fill 130 127 512 130 130 512 minecraft:blackstone
setblock 130 127 551 minecraft:smooth_basalt
fill 131 127 511 131 130 511 minecraft:blackstone
setblock 131 127 550 minecraft:smooth_basalt
fill 131 127 551 131 130 551 minecraft:blackstone
setblock 132 127 543 minecraft:blackstone
setblock 132 127 544 minecraft:smooth_basalt
fill 132 127 545 132 129 545 minecraft:blackstone
setblock 132 127 549 minecraft:smooth_basalt
fill 132 127 550 132 130 550 minecraft:blackstone
setblock 133 127 524 minecraft:blackstone
setblock 133 127 527 minecraft:blackstone
setblock 133 127 528 minecraft:smooth_basalt
fill 133 127 529 133 130 529 minecraft:blackstone
fill 133 127 531 133 127 532 minecraft:blackstone
setblock 133 127 539 minecraft:blackstone
setblock 133 127 543 minecraft:smooth_basalt
fill 133 127 544 133 130 544 minecraft:blackstone
setblock 133 127 548 minecraft:smooth_basalt
fill 133 127 549 133 130 549 minecraft:blackstone
setblock 134 127 512 minecraft:smooth_basalt
setblock 134 127 522 minecraft:smooth_basalt
fill 134 127 523 134 129 523 minecraft:blackstone
setblock 134 127 527 minecraft:smooth_basalt
fill 134 127 528 134 130 528 minecraft:blackstone
setblock 134 127 531 minecraft:blackstone
setblock 134 127 532 minecraft:smooth_basalt
fill 134 127 533 134 130 533 minecraft:blackstone
setblock 134 127 537 minecraft:smooth_basalt
fill 134 127 538 134 130 538 minecraft:blackstone
setblock 134 127 542 minecraft:smooth_basalt
fill 134 127 543 134 130 543 minecraft:blackstone
setblock 134 127 547 minecraft:smooth_basalt
fill 134 127 548 134 130 548 minecraft:blackstone
setblock 135 127 511 minecraft:smooth_basalt
fill 135 127 512 135 130 512 minecraft:blackstone
setblock 135 127 521 minecraft:smooth_basalt
fill 135 127 522 135 130 522 minecraft:blackstone
setblock 135 127 526 minecraft:smooth_basalt
fill 135 127 527 135 130 527 minecraft:blackstone
setblock 135 127 531 minecraft:smooth_basalt
fill 135 127 532 135 130 532 minecraft:blackstone
setblock 135 127 536 minecraft:smooth_basalt
fill 135 127 537 135 130 537 minecraft:blackstone
setblock 135 127 541 minecraft:smooth_basalt
fill 135 127 542 135 130 542 minecraft:blackstone
setblock 135 127 546 minecraft:smooth_basalt
fill 135 127 547 135 130 547 minecraft:blackstone
setblock 135 127 551 minecraft:smooth_basalt
fill 95 128 511 95 131 511 minecraft:blackstone
fill 95 128 517 95 128 519 minecraft:blackstone
setblock 95 128 520 minecraft:smooth_basalt
fill 95 128 521 95 128 524 minecraft:blackstone
setblock 95 128 525 minecraft:smooth_basalt
fill 95 128 526 95 128 529 minecraft:blackstone
setblock 95 128 530 minecraft:smooth_basalt
fill 95 128 531 95 131 531 minecraft:blackstone
setblock 95 128 535 minecraft:smooth_basalt
fill 95 128 536 95 131 536 minecraft:blackstone
setblock 95 128 540 minecraft:smooth_basalt
fill 95 128 541 95 131 541 minecraft:blackstone
setblock 95 128 545 minecraft:smooth_basalt
fill 95 128 546 95 131 546 minecraft:blackstone
setblock 95 128 550 minecraft:smooth_basalt
fill 95 128 551 95 131 551 minecraft:blackstone
setblock 96 128 524 minecraft:smooth_basalt
fill 96 128 525 96 131 525 minecraft:blackstone
setblock 96 128 529 minecraft:smooth_basalt
fill 96 128 530 96 131 530 minecraft:blackstone
setblock 96 128 534 minecraft:smooth_basalt
fill 96 128 535 96 131 535 minecraft:blackstone
setblock 96 128 539 minecraft:smooth_basalt
setblock 96 128 540 minecraft:blackstone
setblock 96 128 544 minecraft:smooth_basalt
fill 96 128 545 96 129 545 minecraft:blackstone
setblock 96 128 549 minecraft:smooth_basalt
fill 96 128 550 96 130 550 minecraft:blackstone
setblock 97 128 524 minecraft:blackstone
setblock 97 128 528 minecraft:smooth_basalt
fill 97 128 529 97 131 529 minecraft:blackstone
setblock 97 128 533 minecraft:smooth_basalt
setblock 99 128 551 minecraft:smooth_basalt
setblock 100 128 551 minecraft:blackstone
setblock 104 128 551 minecraft:smooth_basalt
fill 105 128 511 105 131 511 minecraft:blackstone
fill 105 128 551 108 128 551 minecraft:blackstone
fill 107 128 550 109 128 550 minecraft:blackstone
setblock 108 128 512 minecraft:smooth_basalt
setblock 109 128 511 minecraft:smooth_basalt
fill 109 128 512 112 128 512 minecraft:blackstone
setblock 109 128 551 minecraft:smooth_basalt
fill 110 128 511 110 131 511 minecraft:blackstone
fill 110 128 513 111 128 513 minecraft:blackstone
setblock 110 128 549 minecraft:blackstone
setblock 110 128 550 minecraft:smooth_basalt
fill 110 128 551 110 131 551 minecraft:blackstone
setblock 111 128 549 minecraft:smooth_basalt
fill 111 128 550 114 128 550 minecraft:blackstone
setblock 112 128 513 minecraft:smooth_basalt
fill 112 128 549 112 131 549 minecraft:blackstone
setblock 113 128 512 minecraft:smooth_basalt
fill 113 128 513 113 131 513 minecraft:blackstone
setblock 114 128 511 minecraft:smooth_basalt
fill 114 128 512 114 131 512 minecraft:blackstone
setblock 114 128 551 minecraft:smooth_basalt
fill 115 128 511 115 131 511 minecraft:blackstone
setblock 115 128 550 minecraft:smooth_basalt
fill 115 128 551 115 131 551 minecraft:blackstone
setblock 116 128 549 minecraft:smooth_basalt
fill 116 128 550 116 131 550 minecraft:blackstone
fill 117 128 549 117 129 549 minecraft:blackstone
setblock 118 128 512 minecraft:smooth_basalt
setblock 119 128 511 minecraft:smooth_basalt
fill 119 128 512 119 130 512 minecraft:blackstone
setblock 119 128 551 minecraft:smooth_basalt
fill 120 128 511 123 128 511 minecraft:blackstone
setblock 120 128 550 minecraft:smooth_basalt
fill 120 128 551 123 128 551 minecraft:blackstone
fill 121 128 550 124 128 550 minecraft:blackstone
setblock 124 128 511 minecraft:smooth_basalt
fill 124 128 549 125 128 549 minecraft:blackstone
setblock 124 128 551 minecraft:smooth_basalt
fill 125 128 511 128 128 511 minecraft:blackstone
setblock 125 128 550 minecraft:smooth_basalt
fill 125 128 551 125 131 551 minecraft:blackstone
setblock 126 128 549 minecraft:smooth_basalt
fill 126 128 550 126 131 550 minecraft:blackstone
setblock 127 128 548 minecraft:smooth_basalt
fill 127 128 549 127 131 549 minecraft:blackstone
setblock 128 128 512 minecraft:smooth_basalt
fill 128 128 548 128 131 548 minecraft:blackstone
setblock 129 128 511 minecraft:smooth_basalt
fill 129 128 512 129 131 512 minecraft:blackstone
setblock 129 128 551 minecraft:smooth_basalt
fill 130 128 511 130 131 511 minecraft:blackstone
setblock 130 128 550 minecraft:smooth_basalt
fill 130 128 551 130 131 551 minecraft:blackstone
fill 131 128 512 132 128 512 minecraft:blackstone
setblock 131 128 549 minecraft:smooth_basalt
fill 131 128 550 131 131 550 minecraft:blackstone
setblock 132 128 543 minecraft:smooth_basalt
fill 132 128 544 132 129 544 minecraft:blackstone
setblock 132 128 548 minecraft:smooth_basalt
fill 132 128 549 132 131 549 minecraft:blackstone
setblock 133 128 512 minecraft:smooth_basalt
setblock 133 128 527 minecraft:smooth_basalt
fill 133 128 528 133 131 528 minecraft:blackstone
setblock 133 128 531 minecraft:blackstone
setblock 133 128 532 minecraft:smooth_basalt
fill 133 128 533 133 130 534 minecraft:blackstone
setblock 133 128 542 minecraft:smooth_basalt
fill 133 128 543 133 130 543 minecraft:blackstone
setblock 133 128 547 minecraft:smooth_basalt
fill 133 128 548 133 131 548 minecraft:blackstone
setblock 134 128 511 minecraft:smooth_basalt
fill 134 128 512 134 129 512 minecraft:blackstone
setblock 134 128 522 minecraft:blackstone
setblock 134 128 526 minecraft:smooth_basalt
fill 134 128 527 134 131 527 minecraft:blackstone
setblock 134 128 531 minecraft:smooth_basalt
fill 134 128 532 134 131 532 minecraft:blackstone
setblock 134 128 536 minecraft:smooth_basalt
fill 134 128 537 134 131 537 minecraft:blackstone
setblock 134 128 541 minecraft:smooth_basalt
fill 134 128 542 134 131 542 minecraft:blackstone
setblock 134 128 546 minecraft:smooth_basalt
fill 134 128 547 134 131 547 minecraft:blackstone
setblock 134 128 551 minecraft:smooth_basalt
fill 135 128 511 135 131 511 minecraft:blackstone
setblock 135 128 520 minecraft:smooth_basalt
fill 135 128 521 135 129 521 minecraft:blackstone
setblock 135 128 525 minecraft:smooth_basalt
fill 135 128 526 135 131 526 minecraft:blackstone
setblock 135 128 530 minecraft:smooth_basalt
fill 135 128 531 135 131 531 minecraft:blackstone
setblock 135 128 535 minecraft:smooth_basalt
fill 135 128 536 135 131 536 minecraft:blackstone
setblock 135 128 540 minecraft:smooth_basalt
fill 135 128 541 135 131 541 minecraft:blackstone
setblock 135 128 545 minecraft:smooth_basalt
fill 135 128 546 135 131 546 minecraft:blackstone
setblock 135 128 550 minecraft:smooth_basalt
fill 135 128 551 135 131 551 minecraft:blackstone
setblock 95 129 519 minecraft:smooth_basalt
fill 95 129 520 95 129 523 minecraft:blackstone
setblock 95 129 524 minecraft:smooth_basalt
fill 95 129 525 95 129 528 minecraft:blackstone
setblock 95 129 529 minecraft:smooth_basalt
fill 95 129 530 95 132 530 minecraft:blackstone
setblock 95 129 534 minecraft:smooth_basalt
fill 95 129 535 95 132 535 minecraft:blackstone
setblock 95 129 539 minecraft:smooth_basalt
fill 95 129 540 95 131 540 minecraft:blackstone
setblock 95 129 544 minecraft:smooth_basalt
fill 95 129 545 95 131 545 minecraft:blackstone
setblock 95 129 549 minecraft:smooth_basalt
fill 95 129 550 95 132 550 minecraft:blackstone
setblock 96 129 523 minecraft:smooth_basalt
fill 96 129 524 96 131 524 minecraft:blackstone
setblock 96 129 528 minecraft:smooth_basalt
fill 96 129 529 96 132 529 minecraft:blackstone
setblock 96 129 533 minecraft:smooth_basalt
fill 96 129 534 96 132 534 minecraft:blackstone
setblock 96 129 544 minecraft:blackstone
setblock 96 129 548 minecraft:smooth_basalt
fill 96 129 549 96 130 549 minecraft:blackstone
setblock 97 129 527 minecraft:smooth_basalt
fill 97 129 528 97 131 528 minecraft:blackstone
setblock 97 129 532 minecraft:smooth_basalt
setblock 97 129 533 minecraft:blackstone
setblock 98 129 551 minecraft:smooth_basalt
setblock 99 129 551 minecraft:blackstone
fill 104 129 511 104 132 511 minecraft:blackstone
fill 104 129 551 107 129 551 minecraft:blackstone
setblock 107 129 511 minecraft:blackstone
setblock 107 129 512 minecraft:smooth_basalt
fill 107 129 550 108 129 550 minecraft:blackstone
setblock 108 129 511 minecraft:smooth_basalt
fill 108 129 512 111 129 512 minecraft:blackstone
setblock 108 129 551 minecraft:smooth_basalt
fill 109 129 511 109 132 511 minecraft:blackstone
fill 109 129 513 110 129 513 minecraft:blackstone
setblock 109 129 550 minecraft:smooth_basalt
fill 109 129 551 109 132 551 minecraft:blackstone
setblock 110 129 549 minecraft:smooth_basalt
fill 110 129 550 113 129 550 minecraft:blackstone
setblock 111 129 513 minecraft:smooth_basalt
fill 111 129 549 111 131 549 minecraft:blackstone
setblock 112 129 512 minecraft:smooth_basalt
fill 112 129 513 112 132 513 minecraft:blackstone
setblock 113 129 511 minecraft:smooth_basalt
fill 113 129 512 113 132 512 minecraft:blackstone
setblock 113 129 551 minecraft:smooth_basalt
fill 114 129 511 114 132 511 minecraft:blackstone
setblock 114 129 550 minecraft:smooth_basalt
fill 114 129 551 114 132 551 minecraft:blackstone
setblock 115 129 513 minecraft:blackstone
setblock 115 129 549 minecraft:smooth_basalt
fill 115 129 550 115 132 550 minecraft:blackstone
fill 116 129 549 116 130 549 minecraft:blackstone
setblock 117 129 512 minecraft:smooth_basalt
setblock 118 129 511 minecraft:smooth_basalt
fill 118 129 512 118 132 512 minecraft:blackstone
setblock 118 129 551 minecraft:smooth_basalt
fill 119 129 511 122 129 511 minecraft:blackstone
setblock 119 129 550 minecraft:smooth_basalt
fill 119 129 551 122 129 551 minecraft:blackstone
fill 120 129 550 123 129 550 minecraft:blackstone
setblock 123 129 511 minecraft:smooth_basalt
setblock 123 129 551 minecraft:smooth_basalt
fill 124 129 511 127 129 511 minecraft:blackstone
setblock 124 129 549 minecraft:blackstone
setblock 124 129 550 minecraft:smooth_basalt
fill 124 129 551 124 132 551 minecraft:blackstone
setblock 125 129 549 minecraft:smooth_basalt
fill 125 129 550 125 132 550 minecraft:blackstone
fill 126 129 549 126 132 549 minecraft:blackstone
setblock 127 129 512 minecraft:smooth_basalt
setblock 127 129 548 minecraft:blackstone
setblock 128 129 511 minecraft:smooth_basalt
fill 128 129 512 128 132 512 minecraft:blackstone
setblock 128 129 551 minecraft:smooth_basalt
fill 129 129 511 129 132 511 minecraft:blackstone
setblock 129 129 550 minecraft:smooth_basalt
fill 129 129 551 129 132 551 minecraft:blackstone
setblock 130 129 549 minecraft:smooth_basalt
fill 130 129 550 130 132 550 minecraft:blackstone
setblock 131 129 512 minecraft:blackstone
setblock 131 129 548 minecraft:smooth_basalt
fill 131 129 549 131 132 549 minecraft:blackstone
setblock 132 129 512 minecraft:smooth_basalt
setblock 132 129 547 minecraft:smooth_basalt
fill 132 129 548 132 131 548 minecraft:blackstone
setblock 133 129 511 minecraft:smooth_basalt
fill 133 129 512 133 131 512 minecraft:blackstone
setblock 133 129 526 minecraft:smooth_basalt
fill 133 129 527 133 130 527 minecraft:blackstone
setblock 133 129 530 minecraft:blackstone
setblock 133 129 531 minecraft:smooth_basalt
fill 133 129 532 133 132 532 minecraft:blackstone
setblock 133 129 535 minecraft:blackstone
setblock 133 129 541 minecraft:smooth_basalt
fill 133 129 542 133 130 542 minecraft:blackstone
setblock 133 129 546 minecraft:smooth_basalt
fill 133 129 547 133 132 547 minecraft:blackstone
setblock 133 129 551 minecraft:smooth_basalt
fill 134 129 511 134 132 511 minecraft:blackstone
setblock 134 129 525 minecraft:smooth_basalt
fill 134 129 526 134 131 526 minecraft:blackstone
setblock 134 129 530 minecraft:smooth_basalt
fill 134 129 531 134 132 531 minecraft:blackstone
setblock 134 129 535 minecraft:smooth_basalt
fill 134 129 536 134 132 536 minecraft:blackstone
setblock 134 129 540 minecraft:smooth_basalt
fill 134 129 541 134 131 541 minecraft:blackstone
setblock 134 129 545 minecraft:smooth_basalt
fill 134 129 546 134 132 546 minecraft:blackstone
setblock 134 129 550 minecraft:smooth_basalt
fill 134 129 551 134 132 551 minecraft:blackstone
setblock 135 129 524 minecraft:smooth_basalt
fill 135 129 525 135 132 525 minecraft:blackstone
setblock 135 129 529 minecraft:smooth_basalt
fill 135 129 530 135 132 530 minecraft:blackstone
setblock 135 129 534 minecraft:smooth_basalt
fill 135 129 535 135 132 535 minecraft:blackstone
setblock 135 129 539 minecraft:smooth_basalt
fill 135 129 540 135 132 540 minecraft:blackstone
setblock 135 129 544 minecraft:smooth_basalt
fill 135 129 545 135 132 545 minecraft:blackstone
setblock 135 129 549 minecraft:smooth_basalt
fill 135 129 550 135 132 550 minecraft:blackstone
setblock 95 130 513 minecraft:smooth_basalt
fill 95 130 520 95 130 522 minecraft:blackstone
setblock 95 130 523 minecraft:smooth_basalt
fill 95 130 524 95 130 527 minecraft:blackstone
setblock 95 130 528 minecraft:smooth_basalt
fill 95 130 529 95 133 529 minecraft:blackstone
setblock 95 130 533 minecraft:smooth_basalt
fill 95 130 534 95 133 534 minecraft:blackstone
setblock 95 130 538 minecraft:smooth_basalt
fill 95 130 539 95 131 539 minecraft:blackstone
setblock 95 130 543 minecraft:smooth_basalt
fill 95 130 544 95 131 544 minecraft:blackstone
setblock 95 130 548 minecraft:smooth_basalt
fill 95 130 549 95 132 549 minecraft:blackstone
setblock 96 130 511 minecraft:blackstone
setblock 96 130 523 minecraft:blackstone
setblock 96 130 526 minecraft:blackstone
setblock 96 130 527 minecraft:smooth_basalt
fill 96 130 528 96 133 528 minecraft:blackstone
setblock 96 130 532 minecraft:smooth_basalt
fill 96 130 533 96 133 533 minecraft:blackstone
setblock 96 130 548 minecraft:blackstone
setblock 97 130 526 minecraft:smooth_basalt
setblock 97 130 527 minecraft:blackstone
setblock 97 130 531 minecraft:smooth_basalt
setblock 97 130 532 minecraft:blackstone
setblock 97 130 551 minecraft:smooth_basalt
setblock 98 130 551 minecraft:blackstone
fill 103 130 511 103 133 511 minecraft:blackstone
fill 104 130 551 106 130 551 minecraft:blackstone
setblock 106 130 512 minecraft:smooth_basalt
setblock 107 130 511 minecraft:smooth_basalt
fill 107 130 512 110 130 512 minecraft:blackstone
fill 107 130 546 107 134 546 minecraft:smooth_basalt
setblock 107 130 550 minecraft:blackstone
setblock 107 130 551 minecraft:smooth_basalt
fill 108 130 511 108 133 511 minecraft:blackstone
setblock 108 130 550 minecraft:smooth_basalt
fill 108 130 551 108 133 551 minecraft:blackstone
setblock 109 130 513 minecraft:blackstone
fill 109 130 550 112 130 550 minecraft:blackstone
setblock 110 130 513 minecraft:smooth_basalt
setblock 110 130 549 minecraft:blackstone
setblock 111 130 512 minecraft:smooth_basalt
fill 111 130 513 111 133 513 minecraft:blackstone
setblock 112 130 511 minecraft:smooth_basalt
fill 112 130 512 112 133 512 minecraft:blackstone
setblock 112 130 551 minecraft:smooth_basalt
fill 113 130 511 113 133 511 minecraft:blackstone
setblock 113 130 550 minecraft:smooth_basalt
fill 113 130 551 113 133 551 minecraft:blackstone
setblock 114 130 549 minecraft:smooth_basalt
fill 114 130 550 114 133 550 minecraft:blackstone
setblock 115 130 513 minecraft:smooth_basalt
setblock 115 130 549 minecraft:blackstone
setblock 116 130 512 minecraft:smooth_basalt
setblock 117 130 511 minecraft:smooth_basalt
fill 117 130 512 117 133 512 minecraft:blackstone
setblock 117 130 551 minecraft:smooth_basalt
fill 118 130 511 121 130 511 minecraft:blackstone
setblock 118 130 550 minecraft:smooth_basalt
fill 118 130 551 121 130 551 minecraft:blackstone
fill 119 130 550 122 130 550 minecraft:blackstone
setblock 122 130 511 minecraft:smooth_basalt
setblock 122 130 551 minecraft:smooth_basalt
fill 123 130 511 126 130 511 minecraft:blackstone
setblock 123 130 550 minecraft:smooth_basalt
fill 123 130 551 123 133 551 minecraft:blackstone
setblock 124 130 549 minecraft:smooth_basalt
fill 124 130 550 124 133 550 minecraft:blackstone
fill 125 130 549 125 132 549 minecraft:blackstone
setblock 126 130 512 minecraft:smooth_basalt
setblock 127 130 511 minecraft:smooth_basalt
fill 127 130 512 127 133 512 minecraft:blackstone
setblock 127 130 551 minecraft:smooth_basalt
fill 128 130 511 128 133 511 minecraft:blackstone
setblock 128 130 550 minecraft:smooth_basalt
fill 128 130 551 128 133 551 minecraft:blackstone
setblock 129 130 549 minecraft:smooth_basalt
fill 129 130 550 129 133 550 minecraft:blackstone
setblock 130 130 548 minecraft:smooth_basalt
fill 130 130 549 130 133 549 minecraft:blackstone
setblock 131 130 512 minecraft:smooth_basalt
fill 131 130 548 131 131 548 minecraft:blackstone
setblock 132 130 511 minecraft:smooth_basalt
fill 132 130 512 132 132 512 minecraft:blackstone
setblock 132 130 546 minecraft:smooth_basalt
setblock 132 130 547 minecraft:blackstone
setblock 132 130 551 minecraft:smooth_basalt
fill 133 130 511 133 133 511 minecraft:blackstone
setblock 133 130 530 minecraft:smooth_basalt
fill 133 130 531 133 133 531 minecraft:blackstone
setblock 133 130 535 minecraft:smooth_basalt
setblock 133 130 545 minecraft:smooth_basalt
fill 133 130 546 133 131 546 minecraft:blackstone
setblock 133 130 550 minecraft:smooth_basalt
fill 133 130 551 133 133 551 minecraft:blackstone
setblock 134 130 524 minecraft:smooth_basalt
setblock 134 130 525 minecraft:blackstone
setblock 134 130 529 minecraft:smooth_basalt
fill 134 130 530 134 133 530 minecraft:blackstone
setblock 134 130 534 minecraft:smooth_basalt
fill 134 130 535 134 133 535 minecraft:blackstone
setblock 134 130 539 minecraft:smooth_basalt
fill 134 130 540 134 131 540 minecraft:blackstone
setblock 134 130 544 minecraft:smooth_basalt
fill 134 130 545 134 132 545 minecraft:blackstone
setblock 134 130 549 minecraft:smooth_basalt
fill 134 130 550 134 133 550 minecraft:blackstone
setblock 135 130 513 minecraft:smooth_basalt
setblock 135 130 523 minecraft:smooth_basalt
fill 135 130 524 135 131 524 minecraft:blackstone
setblock 135 130 528 minecraft:smooth_basalt
fill 135 130 529 135 133 529 minecraft:blackstone
setblock 135 130 533 minecraft:smooth_basalt
fill 135 130 534 135 133 534 minecraft:blackstone
setblock 135 130 538 minecraft:smooth_basalt
fill 135 130 539 135 133 539 minecraft:blackstone
setblock 135 130 543 minecraft:smooth_basalt
fill 135 130 544 135 133 544 minecraft:blackstone
setblock 135 130 548 minecraft:smooth_basalt
fill 135 130 549 135 133 549 minecraft:blackstone
setblock 95 131 512 minecraft:smooth_basalt
setblock 95 131 521 minecraft:blackstone
setblock 95 131 522 minecraft:smooth_basalt
fill 95 131 523 95 131 526 minecraft:blackstone
setblock 95 131 527 minecraft:smooth_basalt
fill 95 131 528 95 134 528 minecraft:blackstone
setblock 95 131 532 minecraft:smooth_basalt
fill 95 131 533 95 134 533 minecraft:blackstone
setblock 95 131 537 minecraft:smooth_basalt
fill 95 131 538 95 133 538 minecraft:blackstone
setblock 95 131 542 minecraft:smooth_basalt
setblock 95 131 543 minecraft:blackstone
setblock 95 131 547 minecraft:smooth_basalt
fill 95 131 548 95 132 548 minecraft:blackstone
setblock 96 131 511 minecraft:smooth_basalt
setblock 96 131 526 minecraft:smooth_basalt
fill 96 131 527 96 133 527 minecraft:blackstone
setblock 96 131 531 minecraft:smooth_basalt
fill 96 131 532 96 134 532 minecraft:blackstone
setblock 96 131 551 minecraft:smooth_basalt
setblock 97 131 530 minecraft:smooth_basalt
setblock 97 131 531 minecraft:blackstone
setblock 97 131 551 minecraft:blackstone
fill 104 131 551 105 131 551 minecraft:blackstone
setblock 105 131 512 minecraft:smooth_basalt
setblock 106 131 511 minecraft:smooth_basalt
fill 106 131 512 109 131 512 minecraft:blackstone
setblock 106 131 551 minecraft:smooth_basalt
fill 107 131 511 107 134 511 minecraft:blackstone
setblock 107 131 550 minecraft:smooth_basalt
fill 107 131 551 107 134 551 minecraft:blackstone
setblock 108 131 513 minecraft:blackstone
fill 108 131 550 111 131 550 minecraft:blackstone
setblock 109 131 513 minecraft:smooth_basalt
setblock 110 131 512 minecraft:smooth_basalt
fill 110 131 513 110 134 513 minecraft:blackstone
setblock 111 131 511 minecraft:smooth_basalt
fill 111 131 512 111 134 512 minecraft:blackstone
setblock 111 131 551 minecraft:smooth_basalt
fill 112 131 511 112 134 511 minecraft:blackstone
setblock 112 131 550 minecraft:smooth_basalt
fill 112 131 551 112 134 551 minecraft:blackstone
setblock 113 131 549 minecraft:smooth_basalt
fill 113 131 550 113 134 550 minecraft:blackstone
setblock 114 131 513 minecraft:smooth_basalt
setblock 115 131 512 minecraft:smooth_basalt
setblock 116 131 511 minecraft:smooth_basalt
fill 116 131 512 116 134 512 minecraft:blackstone
setblock 116 131 551 minecraft:smooth_basalt
fill 117 131 511 120 131 511 minecraft:blackstone
setblock 117 131 550 minecraft:smooth_basalt
fill 117 131 551 120 131 551 minecraft:blackstone
fill 118 131 550 121 131 550 minecraft:blackstone
setblock 121 131 511 minecraft:smooth_basalt
setblock 121 131 551 minecraft:smooth_basalt
fill 122 131 511 125 131 511 minecraft:blackstone
setblock 122 131 550 minecraft:smooth_basalt
fill 122 131 551 122 134 551 minecraft:blackstone
fill 123 131 550 123 134 550 minecraft:blackstone
setblock 126 131 511 minecraft:smooth_basalt
fill 126 131 512 126 134 512 minecraft:blackstone
setblock 126 131 551 minecraft:smooth_basalt
fill 127 131 511 127 134 511 minecraft:blackstone
setblock 127 131 550 minecraft:smooth_basalt
fill 127 131 551 127 134 551 minecraft:blackstone
setblock 128 131 549 minecraft:smooth_basalt
fill 128 131 550 128 134 550 minecraft:blackstone
setblock 129 131 548 minecraft:smooth_basalt
fill 129 131 549 129 134 549 minecraft:blackstone
setblock 130 131 512 minecraft:smooth_basalt
setblock 130 131 548 minecraft:blackstone
setblock 131 131 511 minecraft:smooth_basalt
fill 131 131 512 131 134 512 minecraft:blackstone
setblock 131 131 551 minecraft:smooth_basalt
fill 132 131 511 132 134 511 minecraft:blackstone
setblock 132 131 550 minecraft:smooth_basalt
fill 132 131 551 132 134 551 minecraft:blackstone
setblock 133 131 529 minecraft:smooth_basalt
fill 133 131 530 133 133 530 minecraft:blackstone
setblock 133 131 533 minecraft:blackstone
setblock 133 131 534 minecraft:smooth_basalt
setblock 133 131 535 minecraft:blackstone
setblock 133 131 545 minecraft:blackstone
setblock 133 131 549 minecraft:smooth_basalt
fill 133 131 550 133 134 550 minecraft:blackstone
setblock 134 131 528 minecraft:smooth_basalt
fill 134 131 529 134 134 529 minecraft:blackstone
setblock 134 131 533 minecraft:smooth_basalt
fill 134 131 534 134 134 534 minecraft:blackstone
setblock 134 131 538 minecraft:smooth_basalt
setblock 134 131 539 minecraft:blackstone
setblock 134 131 543 minecraft:smooth_basalt
fill 134 131 544 134 132 544 minecraft:blackstone
setblock 134 131 548 minecraft:smooth_basalt
fill 134 131 549 134 133 549 minecraft:blackstone
setblock 135 131 512 minecraft:smooth_basalt
setblock 135 131 527 minecraft:smooth_basalt
fill 135 131 528 135 134 528 minecraft:blackstone
setblock 135 131 532 minecraft:smooth_basalt
fill 135 131 533 135 134 533 minecraft:blackstone
setblock 135 131 537 minecraft:smooth_basalt
fill 135 131 538 135 134 538 minecraft:blackstone
setblock 135 131 542 minecraft:smooth_basalt
fill 135 131 543 135 133 543 minecraft:blackstone
setblock 135 131 547 minecraft:smooth_basalt
fill 135 131 548 135 134 548 minecraft:blackstone
setblock 95 132 511 minecraft:smooth_basalt
fill 95 132 523 95 132 525 minecraft:blackstone
setblock 95 132 526 minecraft:smooth_basalt
fill 95 132 527 95 135 527 minecraft:blackstone
setblock 95 132 531 minecraft:smooth_basalt
fill 95 132 532 95 135 532 minecraft:blackstone
setblock 95 132 536 minecraft:smooth_basalt
fill 95 132 537 95 135 537 minecraft:blackstone
setblock 95 132 551 minecraft:smooth_basalt
schedule function dropper:buildpart/122_6 1t
