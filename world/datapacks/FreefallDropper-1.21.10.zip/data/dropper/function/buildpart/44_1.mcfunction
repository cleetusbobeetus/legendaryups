setblock 417 -35 204 minecraft:stone_bricks
fill 417 -35 205 417 -32 205 minecraft:mossy_cobblestone
setblock 417 -35 208 minecraft:mossy_cobblestone
setblock 417 -35 209 minecraft:stone_bricks
fill 417 -35 210 417 -32 210 minecraft:mossy_cobblestone
setblock 417 -35 213 minecraft:mossy_cobblestone
setblock 417 -35 219 minecraft:stone_bricks
fill 417 -35 220 417 -32 220 minecraft:mossy_cobblestone
setblock 377 -34 182 minecraft:mossy_cobblestone
setblock 377 -34 183 minecraft:stone_bricks
fill 377 -34 184 377 -31 184 minecraft:mossy_cobblestone
setblock 377 -34 188 minecraft:stone_bricks
fill 377 -34 189 377 -31 189 minecraft:mossy_cobblestone
setblock 377 -34 193 minecraft:stone_bricks
fill 377 -34 194 377 -31 194 minecraft:mossy_cobblestone
setblock 377 -34 198 minecraft:stone_bricks
fill 377 -34 199 377 -31 199 minecraft:mossy_cobblestone
setblock 377 -34 203 minecraft:stone_bricks
fill 377 -34 204 377 -31 204 minecraft:mossy_cobblestone
setblock 377 -34 207 minecraft:mossy_cobblestone
setblock 377 -34 208 minecraft:stone_bricks
fill 377 -34 209 377 -31 209 minecraft:mossy_cobblestone
setblock 377 -34 212 minecraft:mossy_cobblestone
setblock 377 -34 213 minecraft:stone_bricks
fill 377 -34 214 377 -32 215 minecraft:mossy_cobblestone
setblock 377 -34 218 minecraft:stone_bricks
fill 377 -34 219 377 -31 219 minecraft:mossy_cobblestone
setblock 378 -34 182 minecraft:stone_bricks
fill 378 -34 183 378 -31 183 minecraft:mossy_cobblestone
setblock 378 -34 187 minecraft:stone_bricks
fill 378 -34 188 378 -31 188 minecraft:mossy_cobblestone
setblock 378 -34 192 minecraft:stone_bricks
fill 378 -34 193 378 -31 193 minecraft:mossy_cobblestone
setblock 378 -34 197 minecraft:stone_bricks
fill 378 -34 198 378 -33 198 minecraft:mossy_cobblestone
setblock 378 -34 202 minecraft:stone_bricks
fill 378 -34 203 378 -32 203 minecraft:mossy_cobblestone
setblock 378 -34 206 minecraft:mossy_cobblestone
setblock 378 -34 207 minecraft:stone_bricks
fill 378 -34 208 378 -31 208 minecraft:mossy_cobblestone
fill 378 -34 210 378 -33 210 minecraft:mossy_cobblestone
fill 378 -34 220 378 -33 220 minecraft:mossy_cobblestone
setblock 378 -34 222 minecraft:stone_bricks
fill 379 -34 182 379 -31 182 minecraft:mossy_cobblestone
setblock 379 -34 186 minecraft:stone_bricks
fill 379 -34 187 379 -31 187 minecraft:mossy_cobblestone
setblock 379 -34 191 minecraft:stone_bricks
setblock 379 -34 202 minecraft:mossy_cobblestone
setblock 379 -34 206 minecraft:stone_bricks
setblock 379 -34 207 minecraft:mossy_cobblestone
setblock 379 -34 221 minecraft:stone_bricks
fill 379 -34 222 382 -34 222 minecraft:mossy_cobblestone
setblock 380 -34 185 minecraft:stone_bricks
fill 380 -34 186 380 -31 186 minecraft:mossy_cobblestone
fill 380 -34 221 383 -34 221 minecraft:mossy_cobblestone
setblock 381 -34 184 minecraft:stone_bricks
fill 381 -34 185 381 -32 185 minecraft:mossy_cobblestone
setblock 382 -34 183 minecraft:stone_bricks
fill 382 -34 184 382 -31 184 minecraft:mossy_cobblestone
setblock 383 -34 182 minecraft:stone_bricks
fill 383 -34 183 383 -31 183 minecraft:mossy_cobblestone
setblock 383 -34 222 minecraft:stone_bricks
fill 384 -34 182 384 -31 182 minecraft:mossy_cobblestone
setblock 384 -34 221 minecraft:stone_bricks
fill 384 -34 222 387 -34 222 minecraft:mossy_cobblestone
fill 385 -34 221 388 -34 221 minecraft:mossy_cobblestone
setblock 386 -34 184 minecraft:stone_bricks
setblock 387 -34 183 minecraft:stone_bricks
setblock 388 -34 182 minecraft:stone_bricks
fill 388 -34 183 391 -34 183 minecraft:mossy_cobblestone
setblock 388 -34 222 minecraft:stone_bricks
fill 389 -34 182 392 -34 182 minecraft:mossy_cobblestone
setblock 389 -34 221 minecraft:stone_bricks
fill 389 -34 222 392 -34 222 minecraft:mossy_cobblestone
fill 390 -34 221 393 -34 221 minecraft:mossy_cobblestone
setblock 392 -34 183 minecraft:stone_bricks
setblock 393 -34 182 minecraft:stone_bricks
fill 393 -34 183 393 -32 183 minecraft:mossy_cobblestone
setblock 393 -34 222 minecraft:stone_bricks
fill 394 -34 182 394 -31 182 minecraft:mossy_cobblestone
setblock 394 -34 221 minecraft:stone_bricks
fill 394 -34 222 397 -34 222 minecraft:mossy_cobblestone
fill 395 -34 221 395 -31 221 minecraft:mossy_cobblestone
setblock 396 -34 184 minecraft:stone_bricks
setblock 396 -34 220 minecraft:mossy_cobblestone
setblock 397 -34 183 minecraft:stone_bricks
fill 397 -34 184 397 -33 184 minecraft:mossy_cobblestone
setblock 398 -34 182 minecraft:stone_bricks
fill 398 -34 183 398 -31 183 minecraft:mossy_cobblestone
setblock 398 -34 222 minecraft:stone_bricks
fill 399 -34 182 399 -31 182 minecraft:mossy_cobblestone
fill 399 -34 184 400 -34 184 minecraft:mossy_cobblestone
setblock 399 -34 221 minecraft:stone_bricks
fill 399 -34 222 399 -31 222 minecraft:mossy_cobblestone
setblock 400 -34 220 minecraft:stone_bricks
fill 400 -34 221 400 -32 221 minecraft:mossy_cobblestone
setblock 401 -34 184 minecraft:stone_bricks
setblock 402 -34 183 minecraft:stone_bricks
setblock 403 -34 182 minecraft:stone_bricks
fill 403 -34 183 403 -33 183 minecraft:mossy_cobblestone
setblock 403 -34 222 minecraft:stone_bricks
fill 404 -34 182 404 -32 182 minecraft:mossy_cobblestone
fill 404 -34 222 404 -33 222 minecraft:mossy_cobblestone
setblock 408 -34 182 minecraft:stone_bricks
fill 409 -34 182 412 -34 182 minecraft:mossy_cobblestone
setblock 413 -34 182 minecraft:stone_bricks
fill 413 -34 183 413 -31 183 minecraft:mossy_cobblestone
fill 414 -34 182 414 -31 182 minecraft:mossy_cobblestone
fill 414 -34 184 415 -34 184 minecraft:mossy_cobblestone
setblock 414 -34 222 minecraft:mossy_cobblestone
fill 415 -34 183 416 -34 183 minecraft:mossy_cobblestone
setblock 415 -34 185 minecraft:stone_bricks
fill 415 -34 186 415 -33 188 minecraft:mossy_cobblestone
setblock 415 -34 199 minecraft:mossy_cobblestone
setblock 415 -34 200 minecraft:stone_bricks
fill 415 -34 201 415 -33 201 minecraft:mossy_cobblestone
setblock 415 -34 204 minecraft:mossy_cobblestone
setblock 415 -34 205 minecraft:stone_bricks
fill 415 -34 206 415 -31 206 minecraft:mossy_cobblestone
setblock 416 -34 184 minecraft:stone_bricks
fill 416 -34 185 416 -31 185 minecraft:mossy_cobblestone
setblock 416 -34 188 minecraft:mossy_cobblestone
setblock 416 -34 189 minecraft:stone_bricks
fill 416 -34 190 416 -31 190 minecraft:mossy_cobblestone
setblock 416 -34 194 minecraft:stone_bricks
fill 416 -34 195 416 -31 195 minecraft:mossy_cobblestone
setblock 416 -34 199 minecraft:stone_bricks
fill 416 -34 200 416 -31 200 minecraft:mossy_cobblestone
setblock 416 -34 204 minecraft:stone_bricks
fill 416 -34 205 416 -31 205 minecraft:mossy_cobblestone
setblock 416 -34 209 minecraft:stone_bricks
fill 416 -34 210 416 -31 210 minecraft:mossy_cobblestone
setblock 417 -34 183 minecraft:stone_bricks
fill 417 -34 184 417 -31 184 minecraft:mossy_cobblestone
setblock 417 -34 188 minecraft:stone_bricks
fill 417 -34 189 417 -31 189 minecraft:mossy_cobblestone
setblock 417 -34 193 minecraft:stone_bricks
fill 417 -34 194 417 -31 194 minecraft:mossy_cobblestone
setblock 417 -34 198 minecraft:stone_bricks
fill 417 -34 199 417 -31 199 minecraft:mossy_cobblestone
setblock 417 -34 203 minecraft:stone_bricks
fill 417 -34 204 417 -31 204 minecraft:mossy_cobblestone
setblock 417 -34 208 minecraft:stone_bricks
fill 417 -34 209 417 -31 209 minecraft:mossy_cobblestone
setblock 417 -34 213 minecraft:stone_bricks
setblock 417 -34 219 minecraft:mossy_cobblestone
setblock 377 -33 182 minecraft:stone_bricks
fill 377 -33 183 377 -30 183 minecraft:mossy_cobblestone
setblock 377 -33 187 minecraft:stone_bricks
fill 377 -33 188 377 -30 188 minecraft:mossy_cobblestone
setblock 377 -33 192 minecraft:stone_bricks
fill 377 -33 193 377 -30 193 minecraft:mossy_cobblestone
setblock 377 -33 197 minecraft:stone_bricks
fill 377 -33 198 377 -31 198 minecraft:mossy_cobblestone
setblock 377 -33 202 minecraft:stone_bricks
fill 377 -33 203 377 -30 203 minecraft:mossy_cobblestone
setblock 377 -33 207 minecraft:stone_bricks
fill 377 -33 208 377 -30 208 minecraft:mossy_cobblestone
setblock 377 -33 212 minecraft:stone_bricks
fill 377 -33 213 377 -30 213 minecraft:mossy_cobblestone
setblock 377 -33 217 minecraft:stone_bricks
fill 377 -33 218 377 -30 218 minecraft:mossy_cobblestone
setblock 377 -33 221 minecraft:mossy_cobblestone
setblock 377 -33 222 minecraft:stone_bricks
fill 378 -33 182 378 -30 182 minecraft:mossy_cobblestone
setblock 378 -33 186 minecraft:stone_bricks
fill 378 -33 187 378 -30 187 minecraft:mossy_cobblestone
setblock 378 -33 190 minecraft:mossy_cobblestone
setblock 378 -33 191 minecraft:stone_bricks
fill 378 -33 192 378 -30 192 minecraft:mossy_cobblestone
setblock 378 -33 201 minecraft:stone_bricks
fill 378 -33 202 378 -32 202 minecraft:mossy_cobblestone
setblock 378 -33 205 minecraft:mossy_cobblestone
setblock 378 -33 206 minecraft:stone_bricks
fill 378 -33 207 378 -30 207 minecraft:mossy_cobblestone
setblock 378 -33 211 minecraft:stone_bricks
setblock 378 -33 221 minecraft:stone_bricks
fill 378 -33 222 381 -33 222 minecraft:mossy_cobblestone
setblock 379 -33 185 minecraft:stone_bricks
fill 379 -33 186 379 -30 186 minecraft:mossy_cobblestone
setblock 379 -33 190 minecraft:stone_bricks
setblock 379 -33 191 minecraft:mossy_cobblestone
setblock 379 -33 205 minecraft:stone_bricks
setblock 379 -33 206 minecraft:mossy_cobblestone
fill 379 -33 221 382 -33 221 minecraft:mossy_cobblestone
setblock 380 -33 184 minecraft:stone_bricks
fill 380 -33 185 380 -31 185 minecraft:mossy_cobblestone
setblock 381 -33 183 minecraft:stone_bricks
fill 381 -33 184 381 -30 184 minecraft:mossy_cobblestone
setblock 382 -33 182 minecraft:stone_bricks
fill 382 -33 183 382 -30 183 minecraft:mossy_cobblestone
setblock 382 -33 222 minecraft:stone_bricks
fill 383 -33 182 383 -30 182 minecraft:mossy_cobblestone
setblock 383 -33 221 minecraft:stone_bricks
fill 383 -33 222 386 -33 222 minecraft:mossy_cobblestone
fill 384 -33 221 385 -33 221 minecraft:mossy_cobblestone
setblock 385 -33 184 minecraft:stone_bricks
setblock 386 -33 183 minecraft:stone_bricks
setblock 387 -33 182 minecraft:stone_bricks
fill 387 -33 183 390 -33 183 minecraft:mossy_cobblestone
setblock 387 -33 222 minecraft:stone_bricks
fill 388 -33 182 391 -33 182 minecraft:mossy_cobblestone
fill 388 -33 222 391 -33 222 minecraft:mossy_cobblestone
setblock 391 -33 183 minecraft:stone_bricks
setblock 392 -33 182 minecraft:stone_bricks
fill 392 -33 183 392 -32 183 minecraft:mossy_cobblestone
setblock 392 -33 221 minecraft:mossy_cobblestone
setblock 392 -33 222 minecraft:stone_bricks
fill 393 -33 182 393 -30 182 minecraft:mossy_cobblestone
setblock 393 -33 221 minecraft:stone_bricks
fill 393 -33 222 396 -33 222 minecraft:mossy_cobblestone
fill 394 -33 221 394 -31 221 minecraft:mossy_cobblestone
setblock 396 -33 183 minecraft:stone_bricks
setblock 396 -33 184 minecraft:mossy_cobblestone
setblock 397 -33 182 minecraft:stone_bricks
fill 397 -33 183 397 -30 183 minecraft:mossy_cobblestone
setblock 397 -33 222 minecraft:stone_bricks
fill 398 -33 182 398 -30 182 minecraft:mossy_cobblestone
setblock 398 -33 221 minecraft:stone_bricks
fill 398 -33 222 398 -30 222 minecraft:mossy_cobblestone
setblock 399 -33 184 minecraft:mossy_cobblestone
fill 399 -33 221 399 -32 221 minecraft:mossy_cobblestone
setblock 401 -33 183 minecraft:stone_bricks
setblock 402 -33 182 minecraft:stone_bricks
setblock 402 -33 183 minecraft:mossy_cobblestone
setblock 402 -33 222 minecraft:stone_bricks
fill 403 -33 182 403 -32 182 minecraft:mossy_cobblestone
fill 403 -33 222 403 -32 222 minecraft:mossy_cobblestone
fill 410 -33 182 411 -33 182 minecraft:mossy_cobblestone
setblock 412 -33 182 minecraft:stone_bricks
fill 412 -33 183 412 -32 183 minecraft:mossy_cobblestone
fill 413 -33 182 413 -30 182 minecraft:mossy_cobblestone
setblock 414 -33 184 minecraft:mossy_cobblestone
setblock 415 -33 183 minecraft:mossy_cobblestone
setblock 415 -33 184 minecraft:stone_bricks
fill 415 -33 185 415 -30 185 minecraft:mossy_cobblestone
setblock 415 -33 189 minecraft:stone_bricks
fill 415 -33 190 415 -30 190 minecraft:mossy_cobblestone
setblock 415 -33 200 minecraft:mossy_cobblestone
setblock 415 -33 204 minecraft:stone_bricks
fill 415 -33 205 415 -31 205 minecraft:mossy_cobblestone
setblock 415 -33 208 minecraft:mossy_cobblestone
setblock 416 -33 182 minecraft:mossy_cobblestone
setblock 416 -33 183 minecraft:stone_bricks
fill 416 -33 184 416 -30 184 minecraft:mossy_cobblestone
setblock 416 -33 188 minecraft:stone_bricks
fill 416 -33 189 416 -30 189 minecraft:mossy_cobblestone
setblock 416 -33 192 minecraft:mossy_cobblestone
setblock 416 -33 193 minecraft:stone_bricks
fill 416 -33 194 416 -30 194 minecraft:mossy_cobblestone
setblock 416 -33 198 minecraft:stone_bricks
fill 416 -33 199 416 -30 199 minecraft:mossy_cobblestone
setblock 416 -33 203 minecraft:stone_bricks
fill 416 -33 204 416 -30 204 minecraft:mossy_cobblestone
setblock 416 -33 208 minecraft:stone_bricks
fill 416 -33 209 416 -30 209 minecraft:mossy_cobblestone
fill 416 -33 211 417 -33 211 minecraft:mossy_cobblestone
setblock 417 -33 182 minecraft:stone_bricks
fill 417 -33 183 417 -30 183 minecraft:mossy_cobblestone
setblock 417 -33 187 minecraft:stone_bricks
fill 417 -33 188 417 -30 188 minecraft:mossy_cobblestone
setblock 417 -33 192 minecraft:stone_bricks
fill 417 -33 193 417 -30 193 minecraft:mossy_cobblestone
setblock 417 -33 197 minecraft:stone_bricks
fill 417 -33 198 417 -30 198 minecraft:mossy_cobblestone
setblock 417 -33 202 minecraft:stone_bricks
fill 417 -33 203 417 -30 203 minecraft:mossy_cobblestone
setblock 417 -33 207 minecraft:stone_bricks
fill 417 -33 208 417 -30 208 minecraft:mossy_cobblestone
setblock 417 -33 212 minecraft:stone_bricks
fill 417 -33 213 417 -31 214 minecraft:mossy_cobblestone
setblock 417 -33 222 minecraft:stone_bricks
fill 377 -32 182 377 -29 182 minecraft:mossy_cobblestone
setblock 377 -32 186 minecraft:stone_bricks
fill 377 -32 187 377 -29 187 minecraft:mossy_cobblestone
setblock 377 -32 191 minecraft:stone_bricks
fill 377 -32 192 377 -29 192 minecraft:mossy_cobblestone
setblock 377 -32 196 minecraft:stone_bricks
fill 377 -32 197 377 -31 197 minecraft:mossy_cobblestone
setblock 377 -32 201 minecraft:stone_bricks
fill 377 -32 202 377 -30 202 minecraft:mossy_cobblestone
setblock 377 -32 206 minecraft:stone_bricks
fill 377 -32 207 377 -29 207 minecraft:mossy_cobblestone
setblock 377 -32 211 minecraft:stone_bricks
fill 377 -32 212 377 -29 212 minecraft:mossy_cobblestone
setblock 377 -32 216 minecraft:stone_bricks
fill 377 -32 217 377 -29 217 minecraft:mossy_cobblestone
setblock 377 -32 221 minecraft:stone_bricks
fill 377 -32 222 380 -32 222 minecraft:mossy_cobblestone
setblock 378 -32 185 minecraft:stone_bricks
fill 378 -32 186 378 -29 186 minecraft:mossy_cobblestone
setblock 378 -32 190 minecraft:stone_bricks
fill 378 -32 191 378 -29 191 minecraft:mossy_cobblestone
setblock 378 -32 201 minecraft:mossy_cobblestone
setblock 378 -32 205 minecraft:stone_bricks
fill 378 -32 206 378 -30 206 minecraft:mossy_cobblestone
setblock 378 -32 210 minecraft:stone_bricks
fill 378 -32 211 378 -29 211 minecraft:mossy_cobblestone
setblock 378 -32 220 minecraft:stone_bricks
fill 378 -32 221 381 -32 221 minecraft:mossy_cobblestone
setblock 379 -32 184 minecraft:stone_bricks
fill 379 -32 185 379 -29 185 minecraft:mossy_cobblestone
setblock 379 -32 188 minecraft:mossy_cobblestone
setblock 379 -32 189 minecraft:stone_bricks
fill 379 -32 190 379 -30 190 minecraft:mossy_cobblestone
setblock 380 -32 183 minecraft:stone_bricks
fill 380 -32 184 380 -29 184 minecraft:mossy_cobblestone
setblock 381 -32 182 minecraft:stone_bricks
fill 381 -32 183 381 -29 183 minecraft:mossy_cobblestone
setblock 381 -32 222 minecraft:stone_bricks
fill 382 -32 182 382 -29 182 minecraft:mossy_cobblestone
setblock 382 -32 221 minecraft:stone_bricks
fill 382 -32 222 385 -32 222 minecraft:mossy_cobblestone
setblock 383 -32 221 minecraft:mossy_cobblestone
setblock 384 -32 184 minecraft:stone_bricks
setblock 385 -32 183 minecraft:stone_bricks
setblock 386 -32 182 minecraft:stone_bricks
fill 386 -32 183 387 -32 183 minecraft:mossy_cobblestone
setblock 386 -32 222 minecraft:stone_bricks
fill 387 -32 182 390 -32 182 minecraft:mossy_cobblestone
fill 387 -32 222 390 -32 222 minecraft:mossy_cobblestone
setblock 391 -32 182 minecraft:stone_bricks
setblock 391 -32 222 minecraft:stone_bricks
fill 392 -32 182 392 -29 182 minecraft:mossy_cobblestone
fill 392 -32 222 395 -32 222 minecraft:mossy_cobblestone
setblock 393 -32 221 minecraft:mossy_cobblestone
setblock 395 -32 183 minecraft:stone_bricks
setblock 396 -32 182 minecraft:stone_bricks
fill 396 -32 183 396 -30 183 minecraft:mossy_cobblestone
setblock 396 -32 222 minecraft:stone_bricks
fill 397 -32 182 397 -29 182 minecraft:mossy_cobblestone
setblock 397 -32 221 minecraft:stone_bricks
fill 397 -32 222 397 -29 222 minecraft:mossy_cobblestone
fill 398 -32 221 398 -31 221 minecraft:mossy_cobblestone
setblock 400 -32 183 minecraft:stone_bricks
setblock 401 -32 182 minecraft:stone_bricks
setblock 401 -32 183 minecraft:mossy_cobblestone
setblock 401 -32 222 minecraft:stone_bricks
fill 402 -32 182 402 -31 182 minecraft:mossy_cobblestone
setblock 402 -32 222 minecraft:mossy_cobblestone
setblock 411 -32 182 minecraft:stone_bricks
fill 412 -32 182 412 -29 182 minecraft:mossy_cobblestone
setblock 414 -32 184 minecraft:stone_bricks
setblock 415 -32 183 minecraft:stone_bricks
fill 415 -32 184 415 -29 184 minecraft:mossy_cobblestone
fill 415 -32 186 415 -32 187 minecraft:mossy_cobblestone
setblock 415 -32 188 minecraft:stone_bricks
fill 415 -32 189 415 -29 189 minecraft:mossy_cobblestone
fill 415 -32 191 415 -31 191 minecraft:mossy_cobblestone
setblock 415 -32 203 minecraft:stone_bricks
fill 415 -32 204 415 -31 204 minecraft:mossy_cobblestone
setblock 415 -32 208 minecraft:stone_bricks
setblock 416 -32 182 minecraft:stone_bricks
fill 416 -32 183 416 -29 183 minecraft:mossy_cobblestone
setblock 416 -32 187 minecraft:stone_bricks
fill 416 -32 188 416 -29 188 minecraft:mossy_cobblestone
setblock 416 -32 192 minecraft:stone_bricks
fill 416 -32 193 416 -29 193 minecraft:mossy_cobblestone
setblock 416 -32 197 minecraft:stone_bricks
fill 416 -32 198 416 -30 198 minecraft:mossy_cobblestone
setblock 416 -32 202 minecraft:stone_bricks
fill 416 -32 203 416 -29 203 minecraft:mossy_cobblestone
setblock 416 -32 207 minecraft:stone_bricks
fill 416 -32 208 416 -29 208 minecraft:mossy_cobblestone
setblock 416 -32 211 minecraft:mossy_cobblestone
setblock 416 -32 222 minecraft:stone_bricks
fill 417 -32 182 417 -29 182 minecraft:mossy_cobblestone
setblock 417 -32 186 minecraft:stone_bricks
fill 417 -32 187 417 -29 187 minecraft:mossy_cobblestone
setblock 417 -32 191 minecraft:stone_bricks
fill 417 -32 192 417 -29 192 minecraft:mossy_cobblestone
setblock 417 -32 196 minecraft:stone_bricks
fill 417 -32 197 417 -29 197 minecraft:mossy_cobblestone
setblock 417 -32 201 minecraft:stone_bricks
fill 417 -32 202 417 -29 202 minecraft:mossy_cobblestone
setblock 417 -32 206 minecraft:stone_bricks
fill 417 -32 207 417 -29 207 minecraft:mossy_cobblestone
setblock 417 -32 211 minecraft:stone_bricks
fill 417 -32 212 417 -29 212 minecraft:mossy_cobblestone
setblock 417 -32 221 minecraft:stone_bricks
fill 417 -32 222 417 -30 222 minecraft:mossy_cobblestone
setblock 377 -31 185 minecraft:stone_bricks
fill 377 -31 186 377 -28 186 minecraft:mossy_cobblestone
setblock 377 -31 190 minecraft:stone_bricks
fill 377 -31 191 377 -28 191 minecraft:mossy_cobblestone
setblock 377 -31 195 minecraft:stone_bricks
fill 377 -31 196 377 -30 196 minecraft:mossy_cobblestone
setblock 377 -31 200 minecraft:stone_bricks
fill 377 -31 201 377 -30 201 minecraft:mossy_cobblestone
setblock 377 -31 205 minecraft:stone_bricks
fill 377 -31 206 377 -28 206 minecraft:mossy_cobblestone
setblock 377 -31 210 minecraft:stone_bricks
fill 377 -31 211 377 -28 211 minecraft:mossy_cobblestone
setblock 377 -31 214 minecraft:mossy_cobblestone
setblock 377 -31 215 minecraft:stone_bricks
fill 377 -31 216 377 -28 216 minecraft:mossy_cobblestone
setblock 377 -31 220 minecraft:stone_bricks
fill 377 -31 221 379 -31 222 minecraft:mossy_cobblestone
setblock 378 -31 184 minecraft:stone_bricks
fill 378 -31 185 378 -28 185 minecraft:mossy_cobblestone
setblock 378 -31 189 minecraft:stone_bricks
fill 378 -31 190 378 -28 190 minecraft:mossy_cobblestone
setblock 378 -31 204 minecraft:stone_bricks
setblock 378 -31 205 minecraft:mossy_cobblestone
setblock 378 -31 209 minecraft:stone_bricks
fill 378 -31 210 378 -28 210 minecraft:mossy_cobblestone
fill 378 -31 212 378 -30 212 minecraft:mossy_cobblestone
setblock 379 -31 183 minecraft:stone_bricks
fill 379 -31 184 379 -29 184 minecraft:mossy_cobblestone
setblock 379 -31 188 minecraft:stone_bricks
fill 379 -31 189 379 -29 189 minecraft:mossy_cobblestone
setblock 379 -31 192 minecraft:light[level=12]
setblock 379 -31 200 minecraft:light[level=12]
setblock 379 -31 208 minecraft:light[level=12]
setblock 379 -31 216 minecraft:light[level=12]
setblock 380 -31 182 minecraft:stone_bricks
fill 380 -31 183 380 -28 183 minecraft:mossy_cobblestone
setblock 380 -31 221 minecraft:mossy_cobblestone
setblock 380 -31 222 minecraft:stone_bricks
fill 381 -31 182 381 -28 182 minecraft:mossy_cobblestone
fill 381 -31 222 384 -31 222 minecraft:mossy_cobblestone
setblock 384 -31 183 minecraft:stone_bricks
setblock 385 -31 182 minecraft:stone_bricks
setblock 385 -31 183 minecraft:mossy_cobblestone
setblock 385 -31 222 minecraft:stone_bricks
fill 386 -31 182 389 -31 182 minecraft:mossy_cobblestone
fill 386 -31 222 389 -31 222 minecraft:mossy_cobblestone
setblock 387 -31 184 minecraft:light[level=12]
setblock 387 -31 192 minecraft:light[level=12]
setblock 387 -31 200 minecraft:light[level=12]
setblock 387 -31 208 minecraft:light[level=12]
setblock 387 -31 216 minecraft:light[level=12]
setblock 390 -31 182 minecraft:stone_bricks
setblock 390 -31 222 minecraft:stone_bricks
fill 391 -31 182 391 -30 182 minecraft:mossy_cobblestone
fill 391 -31 222 394 -31 222 minecraft:mossy_cobblestone
setblock 394 -31 183 minecraft:stone_bricks
setblock 395 -31 182 minecraft:stone_bricks
fill 395 -31 183 395 -30 183 minecraft:mossy_cobblestone
setblock 395 -31 184 minecraft:light[level=12]
setblock 395 -31 192 minecraft:light[level=12]
setblock 395 -31 200 minecraft:light[level=12]
setblock 395 -31 208 minecraft:light[level=12]
setblock 395 -31 216 minecraft:light[level=12]
setblock 395 -31 222 minecraft:stone_bricks
fill 396 -31 182 396 -28 182 minecraft:mossy_cobblestone
setblock 396 -31 221 minecraft:stone_bricks
fill 396 -31 222 396 -28 222 minecraft:mossy_cobblestone
setblock 397 -31 221 minecraft:mossy_cobblestone
setblock 399 -31 183 minecraft:stone_bricks
setblock 400 -31 182 minecraft:stone_bricks
setblock 400 -31 183 minecraft:mossy_cobblestone
setblock 400 -31 222 minecraft:stone_bricks
setblock 401 -31 182 minecraft:mossy_cobblestone
setblock 401 -31 222 minecraft:mossy_cobblestone
setblock 403 -31 184 minecraft:light[level=12]
setblock 403 -31 192 minecraft:light[level=12]
setblock 403 -31 200 minecraft:light[level=12]
setblock 403 -31 208 minecraft:light[level=12]
setblock 403 -31 216 minecraft:light[level=12]
setblock 411 -31 182 minecraft:mossy_cobblestone
setblock 411 -31 184 minecraft:light[level=12]
setblock 411 -31 192 minecraft:light[level=12]
setblock 411 -31 200 minecraft:light[level=12]
setblock 411 -31 208 minecraft:light[level=12]
setblock 411 -31 216 minecraft:light[level=12]
setblock 414 -31 183 minecraft:stone_bricks
fill 414 -31 184 414 -29 184 minecraft:mossy_cobblestone
setblock 415 -31 182 minecraft:stone_bricks
fill 415 -31 183 415 -28 183 minecraft:mossy_cobblestone
setblock 415 -31 186 minecraft:mossy_cobblestone
setblock 415 -31 187 minecraft:stone_bricks
fill 415 -31 188 415 -28 188 minecraft:mossy_cobblestone
setblock 415 -31 192 minecraft:stone_bricks
setblock 415 -31 207 minecraft:stone_bricks
fill 416 -31 182 416 -28 182 minecraft:mossy_cobblestone
setblock 416 -31 186 minecraft:stone_bricks
fill 416 -31 187 416 -28 187 minecraft:mossy_cobblestone
setblock 416 -31 191 minecraft:stone_bricks
fill 416 -31 192 416 -28 192 minecraft:mossy_cobblestone
setblock 416 -31 196 minecraft:stone_bricks
fill 416 -31 197 416 -30 197 minecraft:mossy_cobblestone
setblock 416 -31 201 minecraft:stone_bricks
fill 416 -31 202 416 -30 202 minecraft:mossy_cobblestone
setblock 416 -31 206 minecraft:stone_bricks
fill 416 -31 207 416 -28 207 minecraft:mossy_cobblestone
setblock 416 -31 211 minecraft:stone_bricks
setblock 416 -31 222 minecraft:mossy_cobblestone
setblock 417 -31 185 minecraft:stone_bricks
fill 417 -31 186 417 -28 186 minecraft:mossy_cobblestone
setblock 417 -31 190 minecraft:stone_bricks
fill 417 -31 191 417 -28 191 minecraft:mossy_cobblestone
setblock 417 -31 195 minecraft:stone_bricks
fill 417 -31 196 417 -28 196 minecraft:mossy_cobblestone
setblock 417 -31 200 minecraft:stone_bricks
fill 417 -31 201 417 -28 201 minecraft:mossy_cobblestone
setblock 417 -31 205 minecraft:stone_bricks
fill 417 -31 206 417 -28 206 minecraft:mossy_cobblestone
setblock 417 -31 210 minecraft:stone_bricks
fill 417 -31 211 417 -28 211 minecraft:mossy_cobblestone
setblock 417 -31 221 minecraft:mossy_cobblestone
setblock 377 -30 184 minecraft:stone_bricks
fill 377 -30 185 377 -27 185 minecraft:mossy_cobblestone
setblock 377 -30 189 minecraft:stone_bricks
fill 377 -30 190 377 -27 190 minecraft:mossy_cobblestone
setblock 377 -30 194 minecraft:stone_bricks
fill 377 -30 195 377 -27 195 minecraft:mossy_cobblestone
setblock 377 -30 204 minecraft:stone_bricks
fill 377 -30 205 377 -28 205 minecraft:mossy_cobblestone
setblock 377 -30 209 minecraft:stone_bricks
fill 377 -30 210 377 -27 210 minecraft:mossy_cobblestone
setblock 377 -30 214 minecraft:stone_bricks
fill 377 -30 215 377 -27 215 minecraft:mossy_cobblestone
setblock 377 -30 219 minecraft:stone_bricks
fill 377 -30 220 377 -29 222 minecraft:mossy_cobblestone
setblock 378 -30 183 minecraft:stone_bricks
fill 378 -30 184 378 -27 184 minecraft:mossy_cobblestone
setblock 378 -30 188 minecraft:stone_bricks
fill 378 -30 189 378 -27 189 minecraft:mossy_cobblestone
setblock 378 -30 208 minecraft:stone_bricks
fill 378 -30 209 378 -28 209 minecraft:mossy_cobblestone
setblock 378 -30 222 minecraft:mossy_cobblestone
setblock 379 -30 182 minecraft:stone_bricks
fill 379 -30 183 379 -27 183 minecraft:mossy_cobblestone
setblock 379 -30 187 minecraft:stone_bricks
fill 379 -30 188 379 -28 188 minecraft:mossy_cobblestone
setblock 379 -30 222 minecraft:stone_bricks
fill 380 -30 182 380 -27 182 minecraft:mossy_cobblestone
fill 380 -30 222 383 -30 222 minecraft:mossy_cobblestone
setblock 383 -30 183 minecraft:stone_bricks
setblock 384 -30 182 minecraft:stone_bricks
setblock 384 -30 222 minecraft:stone_bricks
fill 385 -30 182 386 -30 182 minecraft:mossy_cobblestone
fill 391 -30 222 393 -30 222 minecraft:mossy_cobblestone
setblock 394 -30 182 minecraft:stone_bricks
setblock 394 -30 222 minecraft:stone_bricks
fill 395 -30 182 395 -28 182 minecraft:mossy_cobblestone
fill 395 -30 222 395 -27 222 minecraft:mossy_cobblestone
setblock 399 -30 182 minecraft:stone_bricks
setblock 399 -30 222 minecraft:stone_bricks
setblock 400 -30 182 minecraft:mossy_cobblestone
setblock 413 -30 183 minecraft:stone_bricks
setblock 414 -30 182 minecraft:stone_bricks
fill 414 -30 183 414 -27 183 minecraft:mossy_cobblestone
fill 415 -30 182 415 -27 182 minecraft:mossy_cobblestone
setblock 415 -30 186 minecraft:stone_bricks
fill 415 -30 187 415 -27 187 minecraft:mossy_cobblestone
setblock 415 -30 191 minecraft:stone_bricks
fill 415 -30 192 415 -27 192 minecraft:mossy_cobblestone
setblock 416 -30 185 minecraft:stone_bricks
fill 416 -30 186 416 -27 186 minecraft:mossy_cobblestone
setblock 416 -30 190 minecraft:stone_bricks
fill 416 -30 191 416 -27 191 minecraft:mossy_cobblestone
setblock 416 -30 195 minecraft:stone_bricks
fill 416 -30 196 416 -27 196 minecraft:mossy_cobblestone
setblock 416 -30 200 minecraft:stone_bricks
setblock 416 -30 201 minecraft:mossy_cobblestone
setblock 416 -30 205 minecraft:stone_bricks
fill 416 -30 206 416 -28 206 minecraft:mossy_cobblestone
setblock 416 -30 210 minecraft:stone_bricks
fill 416 -30 211 416 -27 211 minecraft:mossy_cobblestone
setblock 417 -30 184 minecraft:stone_bricks
fill 417 -30 185 417 -27 185 minecraft:mossy_cobblestone
setblock 417 -30 189 minecraft:stone_bricks
fill 417 -30 190 417 -27 190 minecraft:mossy_cobblestone
setblock 417 -30 194 minecraft:stone_bricks
fill 417 -30 195 417 -27 195 minecraft:mossy_cobblestone
setblock 417 -30 199 minecraft:stone_bricks
fill 417 -30 200 417 -27 200 minecraft:mossy_cobblestone
setblock 417 -30 204 minecraft:stone_bricks
fill 417 -30 205 417 -27 205 minecraft:mossy_cobblestone
setblock 417 -30 209 minecraft:stone_bricks
fill 417 -30 210 417 -27 210 minecraft:mossy_cobblestone
setblock 417 -30 213 minecraft:mossy_cobblestone
setblock 417 -30 214 minecraft:stone_bricks
setblock 377 -29 183 minecraft:stone_bricks
fill 377 -29 184 377 -26 184 minecraft:mossy_cobblestone
setblock 377 -29 188 minecraft:stone_bricks
fill 377 -29 189 377 -26 189 minecraft:mossy_cobblestone
setblock 377 -29 193 minecraft:stone_bricks
fill 377 -29 194 377 -26 194 minecraft:mossy_cobblestone
setblock 377 -29 203 minecraft:stone_bricks
setblock 377 -29 204 minecraft:mossy_cobblestone
setblock 377 -29 208 minecraft:stone_bricks
fill 377 -29 209 377 -26 209 minecraft:mossy_cobblestone
setblock 377 -29 213 minecraft:stone_bricks
fill 377 -29 214 377 -26 214 minecraft:mossy_cobblestone
setblock 377 -29 218 minecraft:stone_bricks
fill 377 -29 219 377 -26 219 minecraft:mossy_cobblestone
setblock 378 -29 182 minecraft:stone_bricks
fill 378 -29 183 378 -26 183 minecraft:mossy_cobblestone
setblock 378 -29 187 minecraft:stone_bricks
fill 378 -29 188 378 -26 188 minecraft:mossy_cobblestone
setblock 378 -29 192 minecraft:stone_bricks
setblock 378 -29 208 minecraft:mossy_cobblestone
setblock 378 -29 212 minecraft:stone_bricks
setblock 378 -29 222 minecraft:stone_bricks
fill 379 -29 182 379 -26 182 minecraft:mossy_cobblestone
setblock 379 -29 186 minecraft:stone_bricks
fill 379 -29 187 379 -28 187 minecraft:mossy_cobblestone
fill 379 -29 222 382 -29 222 minecraft:mossy_cobblestone
setblock 382 -29 183 minecraft:stone_bricks
setblock 383 -29 182 minecraft:stone_bricks
setblock 384 -29 182 minecraft:mossy_cobblestone
setblock 392 -29 222 minecraft:mossy_cobblestone
setblock 393 -29 182 minecraft:stone_bricks
setblock 393 -29 222 minecraft:stone_bricks
fill 394 -29 182 394 -28 182 minecraft:mossy_cobblestone
fill 394 -29 222 394 -26 222 minecraft:mossy_cobblestone
setblock 398 -29 182 minecraft:stone_bricks
setblock 398 -29 222 minecraft:stone_bricks
setblock 413 -29 182 minecraft:stone_bricks
fill 413 -29 183 413 -26 183 minecraft:mossy_cobblestone
fill 414 -29 182 414 -26 182 minecraft:mossy_cobblestone
setblock 415 -29 185 minecraft:stone_bricks
fill 415 -29 186 415 -26 186 minecraft:mossy_cobblestone
setblock 415 -29 190 minecraft:stone_bricks
fill 415 -29 191 415 -26 191 minecraft:mossy_cobblestone
fill 415 -29 193 415 -28 193 minecraft:mossy_cobblestone
setblock 416 -29 184 minecraft:stone_bricks
fill 416 -29 185 416 -26 185 minecraft:mossy_cobblestone
setblock 416 -29 189 minecraft:stone_bricks
fill 416 -29 190 416 -26 190 minecraft:mossy_cobblestone
setblock 416 -29 194 minecraft:stone_bricks
fill 416 -29 195 416 -26 195 minecraft:mossy_cobblestone
setblock 416 -29 204 minecraft:stone_bricks
fill 416 -29 205 416 -28 205 minecraft:mossy_cobblestone
setblock 416 -29 209 minecraft:stone_bricks
fill 416 -29 210 416 -26 210 minecraft:mossy_cobblestone
setblock 417 -29 183 minecraft:stone_bricks
fill 417 -29 184 417 -26 184 minecraft:mossy_cobblestone
setblock 417 -29 188 minecraft:stone_bricks
fill 417 -29 189 417 -26 189 minecraft:mossy_cobblestone
setblock 417 -29 193 minecraft:stone_bricks
fill 417 -29 194 417 -26 194 minecraft:mossy_cobblestone
setblock 417 -29 198 minecraft:stone_bricks
fill 417 -29 199 417 -26 199 minecraft:mossy_cobblestone
setblock 417 -29 203 minecraft:stone_bricks
fill 417 -29 204 417 -26 204 minecraft:mossy_cobblestone
setblock 417 -29 208 minecraft:stone_bricks
fill 417 -29 209 417 -26 209 minecraft:mossy_cobblestone
setblock 417 -29 213 minecraft:stone_bricks
fill 417 -29 214 417 -26 214 minecraft:mossy_cobblestone
setblock 377 -28 182 minecraft:stone_bricks
fill 377 -28 183 377 -25 183 minecraft:mossy_cobblestone
setblock 377 -28 187 minecraft:stone_bricks
fill 377 -28 188 377 -25 188 minecraft:mossy_cobblestone
setblock 377 -28 192 minecraft:stone_bricks
fill 377 -28 193 377 -25 193 minecraft:mossy_cobblestone
setblock 377 -28 207 minecraft:stone_bricks
fill 377 -28 208 377 -25 208 minecraft:mossy_cobblestone
setblock 377 -28 212 minecraft:stone_bricks
fill 377 -28 213 377 -25 213 minecraft:mossy_cobblestone
setblock 377 -28 217 minecraft:stone_bricks
fill 377 -28 218 377 -25 218 minecraft:mossy_cobblestone
fill 377 -28 220 377 -28 221 minecraft:mossy_cobblestone
setblock 377 -28 222 minecraft:stone_bricks
fill 378 -28 182 378 -25 182 minecraft:mossy_cobblestone
setblock 378 -28 186 minecraft:stone_bricks
fill 378 -28 187 378 -25 187 minecraft:mossy_cobblestone
setblock 378 -28 191 minecraft:stone_bricks
fill 378 -28 192 378 -25 192 minecraft:mossy_cobblestone
setblock 378 -28 211 minecraft:stone_bricks
fill 378 -28 212 378 -25 212 minecraft:mossy_cobblestone
fill 378 -28 222 380 -27 222 minecraft:mossy_cobblestone
setblock 379 -28 185 minecraft:stone_bricks
setblock 379 -28 186 minecraft:mossy_cobblestone
setblock 382 -28 182 minecraft:stone_bricks
setblock 392 -28 222 minecraft:stone_bricks
fill 393 -28 222 393 -25 222 minecraft:mossy_cobblestone
setblock 397 -28 222 minecraft:stone_bricks
setblock 412 -28 182 minecraft:stone_bricks
fill 413 -28 182 413 -25 182 minecraft:mossy_cobblestone
setblock 415 -28 184 minecraft:stone_bricks
fill 415 -28 185 415 -25 185 minecraft:mossy_cobblestone
setblock 415 -28 189 minecraft:stone_bricks
fill 415 -28 190 415 -25 190 minecraft:mossy_cobblestone
setblock 416 -28 183 minecraft:stone_bricks
fill 416 -28 184 416 -25 184 minecraft:mossy_cobblestone
setblock 416 -28 188 minecraft:stone_bricks
fill 416 -28 189 416 -25 189 minecraft:mossy_cobblestone
setblock 416 -28 193 minecraft:stone_bricks
fill 416 -28 194 416 -25 194 minecraft:mossy_cobblestone
setblock 416 -28 208 minecraft:stone_bricks
fill 416 -28 209 416 -25 209 minecraft:mossy_cobblestone
setblock 417 -28 182 minecraft:stone_bricks
fill 417 -28 183 417 -25 183 minecraft:mossy_cobblestone
setblock 417 -28 187 minecraft:stone_bricks
fill 417 -28 188 417 -25 188 minecraft:mossy_cobblestone
setblock 417 -28 192 minecraft:stone_bricks
fill 417 -28 193 417 -25 193 minecraft:mossy_cobblestone
setblock 417 -28 197 minecraft:stone_bricks
fill 417 -28 198 417 -25 198 minecraft:mossy_cobblestone
setblock 417 -28 202 minecraft:stone_bricks
fill 417 -28 203 417 -27 203 minecraft:mossy_cobblestone
setblock 417 -28 207 minecraft:stone_bricks
fill 417 -28 208 417 -25 208 minecraft:mossy_cobblestone
setblock 417 -28 212 minecraft:stone_bricks
fill 417 -28 213 417 -25 213 minecraft:mossy_cobblestone
fill 377 -27 182 377 -24 182 minecraft:mossy_cobblestone
setblock 377 -27 186 minecraft:stone_bricks
fill 377 -27 187 377 -24 187 minecraft:mossy_cobblestone
setblock 377 -27 191 minecraft:stone_bricks
fill 377 -27 192 377 -24 192 minecraft:mossy_cobblestone
setblock 377 -27 206 minecraft:stone_bricks
fill 377 -27 207 377 -24 207 minecraft:mossy_cobblestone
setblock 377 -27 211 minecraft:stone_bricks
fill 377 -27 212 377 -24 212 minecraft:mossy_cobblestone
setblock 377 -27 216 minecraft:stone_bricks
fill 377 -27 217 377 -24 217 minecraft:mossy_cobblestone
setblock 377 -27 220 minecraft:mossy_cobblestone
setblock 377 -27 221 minecraft:stone_bricks
fill 377 -27 222 377 -24 222 minecraft:mossy_cobblestone
setblock 378 -27 185 minecraft:stone_bricks
fill 378 -27 186 378 -24 186 minecraft:mossy_cobblestone
setblock 378 -27 190 minecraft:stone_bricks
fill 378 -27 191 378 -24 191 minecraft:mossy_cobblestone
setblock 378 -27 210 minecraft:stone_bricks
fill 378 -27 211 378 -24 211 minecraft:mossy_cobblestone
fill 378 -27 213 378 -27 214 minecraft:mossy_cobblestone
setblock 381 -27 182 minecraft:stone_bricks
fill 392 -27 222 392 -24 222 minecraft:mossy_cobblestone
setblock 396 -27 222 minecraft:stone_bricks
fill 412 -27 182 412 -24 182 minecraft:mossy_cobblestone
setblock 414 -27 188 minecraft:mossy_cobblestone
setblock 414 -27 189 minecraft:stone_bricks
fill 414 -27 190 414 -24 190 minecraft:mossy_cobblestone
setblock 415 -27 183 minecraft:stone_bricks
fill 415 -27 184 415 -24 184 minecraft:mossy_cobblestone
setblock 415 -27 188 minecraft:stone_bricks
fill 415 -27 189 415 -24 189 minecraft:mossy_cobblestone
setblock 415 -27 193 minecraft:stone_bricks
fill 415 -27 194 415 -24 194 minecraft:mossy_cobblestone
setblock 416 -27 182 minecraft:stone_bricks
fill 416 -27 183 416 -24 183 minecraft:mossy_cobblestone
setblock 416 -27 187 minecraft:stone_bricks
fill 416 -27 188 416 -24 188 minecraft:mossy_cobblestone
setblock 416 -27 192 minecraft:stone_bricks
fill 416 -27 193 416 -24 193 minecraft:mossy_cobblestone
setblock 416 -27 207 minecraft:stone_bricks
fill 416 -27 208 416 -26 208 minecraft:mossy_cobblestone
setblock 416 -27 212 minecraft:stone_bricks
fill 417 -27 182 417 -24 182 minecraft:mossy_cobblestone
setblock 417 -27 186 minecraft:stone_bricks
fill 417 -27 187 417 -24 187 minecraft:mossy_cobblestone
setblock 417 -27 191 minecraft:stone_bricks
fill 417 -27 192 417 -24 192 minecraft:mossy_cobblestone
setblock 417 -27 196 minecraft:stone_bricks
fill 417 -27 197 417 -24 197 minecraft:mossy_cobblestone
setblock 417 -27 201 minecraft:stone_bricks
setblock 417 -27 202 minecraft:mossy_cobblestone
setblock 417 -27 206 minecraft:stone_bricks
fill 417 -27 207 417 -24 207 minecraft:mossy_cobblestone
setblock 417 -27 211 minecraft:stone_bricks
fill 417 -27 212 417 -24 212 minecraft:mossy_cobblestone
setblock 417 -27 215 minecraft:mossy_cobblestone
setblock 377 -26 185 minecraft:stone_bricks
fill 377 -26 186 377 -23 186 minecraft:mossy_cobblestone
setblock 377 -26 190 minecraft:stone_bricks
fill 377 -26 191 377 -23 191 minecraft:mossy_cobblestone
setblock 377 -26 195 minecraft:stone_bricks
setblock 377 -26 206 minecraft:mossy_cobblestone
setblock 377 -26 210 minecraft:stone_bricks
fill 377 -26 211 377 -23 211 minecraft:mossy_cobblestone
setblock 377 -26 215 minecraft:stone_bricks
fill 377 -26 216 377 -23 216 minecraft:mossy_cobblestone
setblock 377 -26 220 minecraft:stone_bricks
fill 377 -26 221 377 -23 221 minecraft:mossy_cobblestone
setblock 378 -26 184 minecraft:stone_bricks
fill 378 -26 185 378 -24 185 minecraft:mossy_cobblestone
setblock 378 -26 189 minecraft:stone_bricks
fill 378 -26 190 378 -23 190 minecraft:mossy_cobblestone
fill 378 -26 210 378 -23 210 minecraft:mossy_cobblestone
setblock 378 -26 213 minecraft:mossy_cobblestone
setblock 378 -26 214 minecraft:stone_bricks
fill 378 -26 215 378 -23 215 minecraft:mossy_cobblestone
fill 378 -26 222 379 -26 222 minecraft:mossy_cobblestone
setblock 380 -26 182 minecraft:stone_bricks
fill 391 -26 222 391 -23 222 minecraft:mossy_cobblestone
setblock 395 -26 222 minecraft:stone_bricks
fill 411 -26 182 411 -23 182 minecraft:mossy_cobblestone
setblock 414 -26 183 minecraft:stone_bricks
setblock 414 -26 187 minecraft:mossy_cobblestone
setblock 414 -26 188 minecraft:stone_bricks
fill 414 -26 189 414 -23 189 minecraft:mossy_cobblestone
fill 414 -26 191 414 -26 192 minecraft:mossy_cobblestone
setblock 415 -26 182 minecraft:stone_bricks
fill 415 -26 183 415 -23 183 minecraft:mossy_cobblestone
setblock 415 -26 187 minecraft:stone_bricks
fill 415 -26 188 415 -23 188 minecraft:mossy_cobblestone
setblock 415 -26 192 minecraft:stone_bricks
fill 415 -26 193 415 -23 193 minecraft:mossy_cobblestone
fill 415 -26 195 415 -25 195 minecraft:mossy_cobblestone
fill 416 -26 182 416 -23 182 minecraft:mossy_cobblestone
setblock 416 -26 186 minecraft:stone_bricks
fill 416 -26 187 416 -23 187 minecraft:mossy_cobblestone
setblock 416 -26 191 minecraft:stone_bricks
fill 416 -26 192 416 -23 192 minecraft:mossy_cobblestone
setblock 416 -26 196 minecraft:stone_bricks
fill 416 -26 197 416 -23 197 minecraft:mossy_cobblestone
setblock 416 -26 211 minecraft:stone_bricks
fill 416 -26 212 416 -24 213 minecraft:mossy_cobblestone
setblock 417 -26 185 minecraft:stone_bricks
fill 417 -26 186 417 -23 186 minecraft:mossy_cobblestone
setblock 417 -26 190 minecraft:stone_bricks
fill 417 -26 191 417 -23 191 minecraft:mossy_cobblestone
setblock 417 -26 195 minecraft:stone_bricks
fill 417 -26 196 417 -23 196 minecraft:mossy_cobblestone
setblock 417 -26 205 minecraft:stone_bricks
fill 417 -26 206 417 -24 206 minecraft:mossy_cobblestone
setblock 417 -26 210 minecraft:stone_bricks
fill 417 -26 211 417 -23 211 minecraft:mossy_cobblestone
setblock 417 -26 215 minecraft:stone_bricks
fill 417 -26 216 417 -23 216 minecraft:mossy_cobblestone
setblock 377 -25 184 minecraft:stone_bricks
fill 377 -25 185 377 -22 185 minecraft:mossy_cobblestone
setblock 377 -25 189 minecraft:stone_bricks
fill 377 -25 190 377 -22 190 minecraft:mossy_cobblestone
setblock 377 -25 194 minecraft:stone_bricks
fill 377 -25 195 377 -23 196 minecraft:mossy_cobblestone
setblock 377 -25 209 minecraft:stone_bricks
fill 377 -25 210 377 -22 210 minecraft:mossy_cobblestone
setblock 377 -25 214 minecraft:stone_bricks
fill 377 -25 215 377 -22 215 minecraft:mossy_cobblestone
setblock 377 -25 219 minecraft:stone_bricks
fill 377 -25 220 377 -22 220 minecraft:mossy_cobblestone
setblock 378 -25 183 minecraft:stone_bricks
fill 378 -25 184 378 -24 184 minecraft:mossy_cobblestone
setblock 378 -25 188 minecraft:stone_bricks
fill 378 -25 189 378 -22 189 minecraft:mossy_cobblestone
setblock 378 -25 213 minecraft:stone_bricks
fill 378 -25 214 378 -22 214 minecraft:mossy_cobblestone
fill 378 -25 216 378 -25 217 minecraft:mossy_cobblestone
setblock 378 -25 222 minecraft:mossy_cobblestone
setblock 379 -25 182 minecraft:stone_bricks
setblock 379 -25 222 minecraft:stone_bricks
setblock 380 -25 182 minecraft:mossy_cobblestone
fill 380 -25 222 380 -22 222 minecraft:mossy_cobblestone
fill 390 -25 222 390 -22 222 minecraft:mossy_cobblestone
setblock 394 -25 222 minecraft:stone_bricks
fill 395 -25 222 395 -22 222 minecraft:mossy_cobblestone
setblock 412 -25 183 minecraft:mossy_cobblestone
setblock 413 -25 183 minecraft:stone_bricks
setblock 414 -25 182 minecraft:stone_bricks
fill 414 -25 183 414 -23 184 minecraft:mossy_cobblestone
setblock 414 -25 187 minecraft:stone_bricks
fill 414 -25 188 414 -22 188 minecraft:mossy_cobblestone
setblock 414 -25 191 minecraft:mossy_cobblestone
setblock 414 -25 192 minecraft:stone_bricks
fill 414 -25 193 414 -22 193 minecraft:mossy_cobblestone
fill 415 -25 182 415 -22 182 minecraft:mossy_cobblestone
setblock 415 -25 186 minecraft:stone_bricks
fill 415 -25 187 415 -22 187 minecraft:mossy_cobblestone
setblock 415 -25 191 minecraft:stone_bricks
fill 415 -25 192 415 -22 192 minecraft:mossy_cobblestone
setblock 416 -25 185 minecraft:stone_bricks
fill 416 -25 186 416 -22 186 minecraft:mossy_cobblestone
setblock 416 -25 190 minecraft:stone_bricks
fill 416 -25 191 416 -22 191 minecraft:mossy_cobblestone
setblock 416 -25 195 minecraft:stone_bricks
fill 416 -25 196 416 -22 196 minecraft:mossy_cobblestone
setblock 416 -25 210 minecraft:stone_bricks
fill 416 -25 211 416 -22 211 minecraft:mossy_cobblestone
setblock 416 -25 214 minecraft:mossy_cobblestone
setblock 417 -25 184 minecraft:stone_bricks
fill 417 -25 185 417 -22 185 minecraft:mossy_cobblestone
setblock 417 -25 189 minecraft:stone_bricks
fill 417 -25 190 417 -22 190 minecraft:mossy_cobblestone
setblock 417 -25 194 minecraft:stone_bricks
fill 417 -25 195 417 -22 195 minecraft:mossy_cobblestone
setblock 417 -25 199 minecraft:stone_bricks
setblock 417 -25 205 minecraft:mossy_cobblestone
setblock 417 -25 209 minecraft:stone_bricks
fill 417 -25 210 417 -22 210 minecraft:mossy_cobblestone
setblock 417 -25 214 minecraft:stone_bricks
fill 417 -25 215 417 -22 215 minecraft:mossy_cobblestone
fill 417 -25 217 417 -25 218 minecraft:mossy_cobblestone
setblock 377 -24 183 minecraft:stone_bricks
fill 377 -24 184 377 -21 184 minecraft:mossy_cobblestone
setblock 377 -24 188 minecraft:stone_bricks
fill 377 -24 189 377 -21 189 minecraft:mossy_cobblestone
setblock 377 -24 193 minecraft:stone_bricks
fill 377 -24 194 377 -21 194 minecraft:mossy_cobblestone
setblock 377 -24 208 minecraft:stone_bricks
fill 377 -24 209 377 -21 209 minecraft:mossy_cobblestone
setblock 377 -24 213 minecraft:stone_bricks
fill 377 -24 214 377 -21 214 minecraft:mossy_cobblestone
setblock 377 -24 218 minecraft:stone_bricks
fill 377 -24 219 378 -22 219 minecraft:mossy_cobblestone
setblock 378 -24 182 minecraft:stone_bricks
setblock 378 -24 187 minecraft:stone_bricks
fill 378 -24 188 378 -22 188 minecraft:mossy_cobblestone
setblock 378 -24 192 minecraft:stone_bricks
fill 378 -24 193 378 -21 193 minecraft:mossy_cobblestone
setblock 378 -24 212 minecraft:stone_bricks
fill 378 -24 213 378 -21 213 minecraft:mossy_cobblestone
setblock 378 -24 216 minecraft:mossy_cobblestone
setblock 378 -24 217 minecraft:stone_bricks
fill 378 -24 218 378 -21 218 minecraft:mossy_cobblestone
setblock 378 -24 222 minecraft:stone_bricks
fill 379 -24 182 379 -22 182 minecraft:mossy_cobblestone
fill 379 -24 222 379 -21 222 minecraft:mossy_cobblestone
setblock 388 -24 222 minecraft:stone_bricks
fill 389 -24 222 389 -21 222 minecraft:mossy_cobblestone
fill 392 -24 221 393 -24 221 minecraft:mossy_cobblestone
setblock 393 -24 222 minecraft:stone_bricks
fill 394 -24 222 394 -21 222 minecraft:mossy_cobblestone
fill 396 -24 222 396 -23 222 minecraft:mossy_cobblestone
fill 410 -24 182 410 -22 182 minecraft:mossy_cobblestone
setblock 412 -24 183 minecraft:stone_bricks
setblock 413 -24 182 minecraft:stone_bricks
fill 413 -24 183 413 -21 183 minecraft:mossy_cobblestone
fill 414 -24 182 414 -21 182 minecraft:mossy_cobblestone
fill 414 -24 187 414 -21 187 minecraft:mossy_cobblestone
setblock 414 -24 191 minecraft:stone_bricks
fill 414 -24 192 414 -21 192 minecraft:mossy_cobblestone
fill 414 -24 194 414 -23 194 minecraft:mossy_cobblestone
fill 414 -24 222 417 -24 222 minecraft:mossy_cobblestone
setblock 415 -24 185 minecraft:stone_bricks
fill 415 -24 186 415 -21 186 minecraft:mossy_cobblestone
setblock 415 -24 190 minecraft:stone_bricks
fill 415 -24 191 415 -21 191 minecraft:mossy_cobblestone
setblock 415 -24 195 minecraft:stone_bricks
fill 415 -24 196 415 -21 196 minecraft:mossy_cobblestone
setblock 416 -24 184 minecraft:stone_bricks
fill 416 -24 185 416 -21 185 minecraft:mossy_cobblestone
setblock 416 -24 189 minecraft:stone_bricks
fill 416 -24 190 416 -21 190 minecraft:mossy_cobblestone
setblock 416 -24 194 minecraft:stone_bricks
fill 416 -24 195 416 -21 195 minecraft:mossy_cobblestone
setblock 416 -24 198 minecraft:mossy_cobblestone
setblock 416 -24 209 minecraft:stone_bricks
fill 416 -24 210 416 -22 210 minecraft:mossy_cobblestone
setblock 416 -24 214 minecraft:stone_bricks
fill 416 -24 215 416 -22 216 minecraft:mossy_cobblestone
setblock 417 -24 183 minecraft:stone_bricks
fill 417 -24 184 417 -21 184 minecraft:mossy_cobblestone
setblock 417 -24 188 minecraft:stone_bricks
fill 417 -24 189 417 -21 189 minecraft:mossy_cobblestone
setblock 417 -24 193 minecraft:stone_bricks
fill 417 -24 194 417 -21 194 minecraft:mossy_cobblestone
setblock 417 -24 198 minecraft:stone_bricks
fill 417 -24 199 417 -22 200 minecraft:mossy_cobblestone
setblock 417 -24 208 minecraft:stone_bricks
fill 417 -24 209 417 -21 209 minecraft:mossy_cobblestone
setblock 417 -24 213 minecraft:stone_bricks
fill 417 -24 214 417 -21 214 minecraft:mossy_cobblestone
setblock 417 -24 217 minecraft:mossy_cobblestone
setblock 417 -24 218 minecraft:stone_bricks
fill 417 -24 219 417 -23 221 minecraft:mossy_cobblestone
setblock 377 -23 182 minecraft:stone_bricks
fill 377 -23 183 377 -20 183 minecraft:mossy_cobblestone
setblock 377 -23 187 minecraft:stone_bricks
fill 377 -23 188 377 -20 188 minecraft:mossy_cobblestone
setblock 377 -23 192 minecraft:stone_bricks
fill 377 -23 193 377 -20 193 minecraft:mossy_cobblestone
setblock 377 -23 197 minecraft:stone_bricks
setblock 377 -23 207 minecraft:stone_bricks
fill 377 -23 208 377 -21 208 minecraft:mossy_cobblestone
setblock 377 -23 212 minecraft:stone_bricks
fill 377 -23 213 377 -20 213 minecraft:mossy_cobblestone
setblock 377 -23 217 minecraft:stone_bricks
fill 377 -23 218 377 -20 218 minecraft:mossy_cobblestone
setblock 377 -23 222 minecraft:stone_bricks
fill 378 -23 182 378 -20 182 minecraft:mossy_cobblestone
setblock 378 -23 186 minecraft:stone_bricks
fill 378 -23 187 378 -22 187 minecraft:mossy_cobblestone
setblock 378 -23 191 minecraft:stone_bricks
fill 378 -23 192 378 -21 192 minecraft:mossy_cobblestone
setblock 378 -23 211 minecraft:stone_bricks
fill 378 -23 212 378 -20 212 minecraft:mossy_cobblestone
setblock 378 -23 216 minecraft:stone_bricks
fill 378 -23 217 378 -20 217 minecraft:mossy_cobblestone
setblock 378 -23 220 minecraft:mossy_cobblestone
setblock 378 -23 221 minecraft:stone_bricks
fill 378 -23 222 378 -20 222 minecraft:mossy_cobblestone
setblock 379 -23 184 minecraft:light[level=12]
setblock 379 -23 192 minecraft:light[level=12]
setblock 379 -23 200 minecraft:light[level=12]
setblock 379 -23 208 minecraft:light[level=12]
setblock 379 -23 216 minecraft:light[level=12]
setblock 381 -23 222 minecraft:mossy_cobblestone
setblock 386 -23 222 minecraft:mossy_cobblestone
setblock 387 -23 184 minecraft:light[level=12]
setblock 387 -23 192 minecraft:light[level=12]
setblock 387 -23 200 minecraft:light[level=12]
setblock 387 -23 208 minecraft:light[level=12]
setblock 387 -23 216 minecraft:light[level=12]
setblock 387 -23 222 minecraft:stone_bricks
fill 388 -23 222 388 -20 222 minecraft:mossy_cobblestone
fill 389 -23 221 392 -23 221 minecraft:mossy_cobblestone
setblock 392 -23 222 minecraft:stone_bricks
setblock 393 -23 221 minecraft:stone_bricks
fill 393 -23 222 393 -20 222 minecraft:mossy_cobblestone
fill 394 -23 221 394 -20 221 minecraft:mossy_cobblestone
setblock 395 -23 184 minecraft:light[level=12]
setblock 395 -23 192 minecraft:light[level=12]
setblock 395 -23 200 minecraft:light[level=12]
setblock 395 -23 208 minecraft:light[level=12]
setblock 395 -23 216 minecraft:light[level=12]
setblock 403 -23 184 minecraft:light[level=12]
setblock 403 -23 192 minecraft:light[level=12]
setblock 403 -23 200 minecraft:light[level=12]
setblock 403 -23 208 minecraft:light[level=12]
setblock 403 -23 216 minecraft:light[level=12]
fill 409 -23 182 409 -21 182 minecraft:mossy_cobblestone
setblock 411 -23 183 minecraft:stone_bricks
setblock 411 -23 184 minecraft:light[level=12]
setblock 411 -23 192 minecraft:light[level=12]
setblock 411 -23 200 minecraft:light[level=12]
setblock 411 -23 208 minecraft:light[level=12]
setblock 411 -23 216 minecraft:light[level=12]
setblock 412 -23 182 minecraft:stone_bricks
fill 412 -23 183 412 -20 183 minecraft:mossy_cobblestone
setblock 412 -23 222 minecraft:stone_bricks
fill 413 -23 182 413 -20 182 minecraft:mossy_cobblestone
fill 413 -23 184 413 -22 184 minecraft:mossy_cobblestone
setblock 413 -23 190 minecraft:mossy_cobblestone
setblock 413 -23 191 minecraft:stone_bricks
fill 413 -23 192 413 -20 192 minecraft:mossy_cobblestone
fill 413 -23 222 416 -23 222 minecraft:mossy_cobblestone
setblock 414 -23 190 minecraft:stone_bricks
fill 414 -23 191 414 -20 191 minecraft:mossy_cobblestone
setblock 414 -23 195 minecraft:stone_bricks
setblock 415 -23 184 minecraft:stone_bricks
fill 415 -23 185 415 -21 185 minecraft:mossy_cobblestone
setblock 415 -23 189 minecraft:stone_bricks
fill 415 -23 190 415 -20 190 minecraft:mossy_cobblestone
setblock 415 -23 194 minecraft:stone_bricks
fill 415 -23 195 415 -20 195 minecraft:mossy_cobblestone
fill 415 -23 197 415 -22 197 minecraft:mossy_cobblestone
setblock 416 -23 183 minecraft:stone_bricks
fill 416 -23 184 416 -20 184 minecraft:mossy_cobblestone
setblock 416 -23 188 minecraft:stone_bricks
fill 416 -23 189 416 -20 189 minecraft:mossy_cobblestone
setblock 416 -23 193 minecraft:stone_bricks
fill 416 -23 194 416 -20 194 minecraft:mossy_cobblestone
setblock 416 -23 198 minecraft:stone_bricks
setblock 416 -23 212 minecraft:mossy_cobblestone
setblock 416 -23 213 minecraft:stone_bricks
fill 416 -23 214 416 -20 214 minecraft:mossy_cobblestone
setblock 416 -23 217 minecraft:mossy_cobblestone
setblock 416 -23 218 minecraft:stone_bricks
setblock 417 -23 182 minecraft:stone_bricks
fill 417 -23 183 417 -20 183 minecraft:mossy_cobblestone
setblock 417 -23 187 minecraft:stone_bricks
fill 417 -23 188 417 -20 188 minecraft:mossy_cobblestone
setblock 417 -23 192 minecraft:stone_bricks
fill 417 -23 193 417 -20 193 minecraft:mossy_cobblestone
setblock 417 -23 197 minecraft:stone_bricks
fill 417 -23 198 417 -20 198 minecraft:mossy_cobblestone
setblock 417 -23 207 minecraft:stone_bricks
fill 417 -23 208 417 -22 208 minecraft:mossy_cobblestone
setblock 417 -23 212 minecraft:stone_bricks
fill 417 -23 213 417 -20 213 minecraft:mossy_cobblestone
setblock 417 -23 217 minecraft:stone_bricks
fill 417 -23 218 417 -20 218 minecraft:mossy_cobblestone
setblock 417 -23 222 minecraft:stone_bricks
fill 377 -22 182 377 -19 182 minecraft:mossy_cobblestone
setblock 377 -22 186 minecraft:stone_bricks
fill 377 -22 187 377 -19 187 minecraft:mossy_cobblestone
setblock 377 -22 191 minecraft:stone_bricks
fill 377 -22 192 377 -19 192 minecraft:mossy_cobblestone
setblock 377 -22 195 minecraft:mossy_cobblestone
setblock 377 -22 196 minecraft:stone_bricks
fill 377 -22 197 377 -19 197 minecraft:mossy_cobblestone
setblock 377 -22 211 minecraft:stone_bricks
fill 377 -22 212 377 -19 212 minecraft:mossy_cobblestone
setblock 377 -22 216 minecraft:stone_bricks
fill 377 -22 217 377 -19 217 minecraft:mossy_cobblestone
setblock 377 -22 221 minecraft:stone_bricks
fill 377 -22 222 377 -19 222 minecraft:mossy_cobblestone
setblock 378 -22 190 minecraft:stone_bricks
fill 378 -22 191 378 -21 191 minecraft:mossy_cobblestone
setblock 378 -22 210 minecraft:stone_bricks
fill 378 -22 211 378 -20 211 minecraft:mossy_cobblestone
setblock 378 -22 215 minecraft:stone_bricks
fill 378 -22 216 379 -20 216 minecraft:mossy_cobblestone
setblock 378 -22 220 minecraft:stone_bricks
fill 378 -22 221 378 -19 221 minecraft:mossy_cobblestone
fill 379 -22 215 379 -20 215 minecraft:mossy_cobblestone
setblock 381 -22 222 minecraft:stone_bricks
fill 382 -22 222 385 -22 222 minecraft:mossy_cobblestone
setblock 386 -22 222 minecraft:stone_bricks
setblock 387 -22 221 minecraft:stone_bricks
fill 387 -22 222 387 -19 222 minecraft:mossy_cobblestone
fill 388 -22 221 391 -22 221 minecraft:mossy_cobblestone
fill 390 -22 220 392 -22 220 minecraft:mossy_cobblestone
setblock 391 -22 182 minecraft:stone_bricks
setblock 391 -22 222 minecraft:stone_bricks
fill 392 -22 182 393 -21 182 minecraft:mossy_cobblestone
setblock 392 -22 221 minecraft:stone_bricks
fill 392 -22 222 392 -19 222 minecraft:mossy_cobblestone
setblock 393 -22 220 minecraft:stone_bricks
fill 393 -22 221 393 -19 221 minecraft:mossy_cobblestone
fill 395 -22 221 395 -21 221 minecraft:mossy_cobblestone
setblock 396 -22 222 minecraft:stone_bricks
fill 408 -22 182 408 -20 182 minecraft:mossy_cobblestone
setblock 410 -22 183 minecraft:stone_bricks
setblock 410 -22 222 minecraft:mossy_cobblestone
setblock 411 -22 182 minecraft:stone_bricks
fill 411 -22 183 411 -19 183 minecraft:mossy_cobblestone
setblock 411 -22 222 minecraft:stone_bricks
fill 412 -22 182 412 -19 182 minecraft:mossy_cobblestone
fill 412 -22 184 412 -21 184 minecraft:mossy_cobblestone
fill 412 -22 222 415 -22 222 minecraft:mossy_cobblestone
setblock 413 -22 190 minecraft:stone_bricks
fill 413 -22 191 413 -21 191 minecraft:mossy_cobblestone
fill 413 -22 193 413 -21 193 minecraft:mossy_cobblestone
setblock 414 -22 183 minecraft:mossy_cobblestone
setblock 414 -22 184 minecraft:stone_bricks
setblock 414 -22 189 minecraft:stone_bricks
fill 414 -22 190 414 -19 190 minecraft:mossy_cobblestone
setblock 414 -22 194 minecraft:stone_bricks
fill 414 -22 195 414 -20 196 minecraft:mossy_cobblestone
fill 414 -22 221 414 -20 221 minecraft:mossy_cobblestone
setblock 415 -22 183 minecraft:stone_bricks
setblock 415 -22 184 minecraft:mossy_cobblestone
setblock 415 -22 188 minecraft:stone_bricks
fill 415 -22 189 415 -19 189 minecraft:mossy_cobblestone
setblock 415 -22 193 minecraft:stone_bricks
fill 415 -22 194 415 -19 194 minecraft:mossy_cobblestone
setblock 416 -22 182 minecraft:stone_bricks
fill 416 -22 183 416 -19 183 minecraft:mossy_cobblestone
setblock 416 -22 187 minecraft:stone_bricks
fill 416 -22 188 416 -19 188 minecraft:mossy_cobblestone
setblock 416 -22 192 minecraft:stone_bricks
fill 416 -22 193 416 -19 193 minecraft:mossy_cobblestone
setblock 416 -22 197 minecraft:stone_bricks
fill 416 -22 198 416 -20 199 minecraft:mossy_cobblestone
setblock 416 -22 212 minecraft:stone_bricks
fill 416 -22 213 416 -20 213 minecraft:mossy_cobblestone
setblock 416 -22 217 minecraft:stone_bricks
fill 416 -22 218 416 -21 220 minecraft:mossy_cobblestone
setblock 416 -22 222 minecraft:stone_bricks
fill 417 -22 182 417 -19 182 minecraft:mossy_cobblestone
setblock 417 -22 186 minecraft:stone_bricks
fill 417 -22 187 417 -19 187 minecraft:mossy_cobblestone
setblock 417 -22 191 minecraft:stone_bricks
fill 417 -22 192 417 -19 192 minecraft:mossy_cobblestone
setblock 417 -22 196 minecraft:stone_bricks
fill 417 -22 197 417 -19 197 minecraft:mossy_cobblestone
setblock 417 -22 211 minecraft:stone_bricks
fill 417 -22 212 417 -19 212 minecraft:mossy_cobblestone
setblock 417 -22 216 minecraft:stone_bricks
fill 417 -22 217 417 -19 217 minecraft:mossy_cobblestone
fill 417 -22 219 417 -22 220 minecraft:mossy_cobblestone
setblock 417 -22 221 minecraft:stone_bricks
fill 417 -22 222 417 -19 222 minecraft:mossy_cobblestone
setblock 377 -21 185 minecraft:stone_bricks
fill 377 -21 186 377 -20 186 minecraft:mossy_cobblestone
setblock 377 -21 190 minecraft:stone_bricks
fill 377 -21 191 377 -18 191 minecraft:mossy_cobblestone
setblock 377 -21 195 minecraft:stone_bricks
fill 377 -21 196 377 -18 196 minecraft:mossy_cobblestone
fill 377 -21 198 377 -20 198 minecraft:mossy_cobblestone
setblock 377 -21 210 minecraft:stone_bricks
fill 377 -21 211 377 -18 211 minecraft:mossy_cobblestone
setblock 377 -21 215 minecraft:stone_bricks
fill 377 -21 216 377 -18 216 minecraft:mossy_cobblestone
setblock 377 -21 219 minecraft:mossy_cobblestone
setblock 377 -21 220 minecraft:stone_bricks
fill 377 -21 221 377 -18 221 minecraft:mossy_cobblestone
setblock 378 -21 190 minecraft:mossy_cobblestone
setblock 378 -21 214 minecraft:stone_bricks
fill 378 -21 215 378 -18 215 minecraft:mossy_cobblestone
setblock 378 -21 219 minecraft:stone_bricks
fill 378 -21 220 378 -18 220 minecraft:mossy_cobblestone
setblock 379 -21 214 minecraft:mossy_cobblestone
setblock 379 -21 217 minecraft:mossy_cobblestone
fill 379 -21 221 379 -20 221 minecraft:mossy_cobblestone
setblock 380 -21 222 minecraft:stone_bricks
fill 381 -21 222 384 -21 222 minecraft:mossy_cobblestone
setblock 385 -21 221 minecraft:mossy_cobblestone
setblock 385 -21 222 minecraft:stone_bricks
setblock 386 -21 221 minecraft:stone_bricks
fill 386 -21 222 386 -18 222 minecraft:mossy_cobblestone
fill 387 -21 221 390 -21 221 minecraft:mossy_cobblestone
fill 388 -21 220 391 -21 220 minecraft:mossy_cobblestone
setblock 390 -21 182 minecraft:stone_bricks
setblock 390 -21 222 minecraft:stone_bricks
fill 391 -21 182 391 -18 182 minecraft:mossy_cobblestone
setblock 391 -21 221 minecraft:stone_bricks
fill 391 -21 222 391 -18 222 minecraft:mossy_cobblestone
setblock 392 -21 220 minecraft:stone_bricks
fill 392 -21 221 392 -18 221 minecraft:mossy_cobblestone
fill 393 -21 220 393 -18 220 minecraft:mossy_cobblestone
setblock 395 -21 222 minecraft:stone_bricks
fill 396 -21 222 396 -19 222 minecraft:mossy_cobblestone
setblock 409 -21 183 minecraft:stone_bricks
setblock 409 -21 222 minecraft:mossy_cobblestone
setblock 410 -21 182 minecraft:stone_bricks
fill 410 -21 183 410 -18 183 minecraft:mossy_cobblestone
setblock 410 -21 222 minecraft:stone_bricks
fill 411 -21 182 411 -18 182 minecraft:mossy_cobblestone
setblock 411 -21 221 minecraft:stone_bricks
fill 411 -21 222 414 -21 222 minecraft:mossy_cobblestone
fill 412 -21 221 413 -19 221 minecraft:mossy_cobblestone
setblock 413 -21 184 minecraft:stone_bricks
setblock 413 -21 190 minecraft:mossy_cobblestone
setblock 413 -21 194 minecraft:stone_bricks
setblock 414 -21 183 minecraft:stone_bricks
setblock 414 -21 184 minecraft:mossy_cobblestone
setblock 414 -21 188 minecraft:stone_bricks
fill 414 -21 189 414 -20 189 minecraft:mossy_cobblestone
setblock 414 -21 193 minecraft:stone_bricks
fill 414 -21 194 414 -19 194 minecraft:mossy_cobblestone
setblock 415 -21 182 minecraft:stone_bricks
fill 415 -21 183 415 -18 183 minecraft:mossy_cobblestone
setblock 415 -21 187 minecraft:stone_bricks
fill 415 -21 188 415 -19 188 minecraft:mossy_cobblestone
setblock 415 -21 192 minecraft:stone_bricks
fill 415 -21 193 415 -18 193 minecraft:mossy_cobblestone
setblock 415 -21 197 minecraft:stone_bricks
fill 415 -21 198 415 -20 198 minecraft:mossy_cobblestone
fill 415 -21 215 415 -21 216 minecraft:mossy_cobblestone
setblock 415 -21 221 minecraft:mossy_cobblestone
setblock 415 -21 222 minecraft:stone_bricks
fill 416 -21 182 416 -18 182 minecraft:mossy_cobblestone
setblock 416 -21 186 minecraft:stone_bricks
fill 416 -21 187 416 -18 187 minecraft:mossy_cobblestone
setblock 416 -21 191 minecraft:stone_bricks
fill 416 -21 192 416 -18 192 minecraft:mossy_cobblestone
setblock 416 -21 196 minecraft:stone_bricks
fill 416 -21 197 416 -18 197 minecraft:mossy_cobblestone
setblock 416 -21 211 minecraft:stone_bricks
fill 416 -21 212 416 -20 212 minecraft:mossy_cobblestone
setblock 416 -21 215 minecraft:mossy_cobblestone
setblock 416 -21 216 minecraft:stone_bricks
fill 416 -21 217 416 -18 217 minecraft:mossy_cobblestone
setblock 416 -21 221 minecraft:stone_bricks
fill 416 -21 222 416 -18 222 minecraft:mossy_cobblestone
setblock 417 -21 185 minecraft:stone_bricks
fill 417 -21 186 417 -18 186 minecraft:mossy_cobblestone
setblock 417 -21 190 minecraft:stone_bricks
fill 417 -21 191 417 -18 191 minecraft:mossy_cobblestone
setblock 417 -21 195 minecraft:stone_bricks
fill 417 -21 196 417 -18 196 minecraft:mossy_cobblestone
setblock 417 -21 199 minecraft:mossy_cobblestone
setblock 417 -21 200 minecraft:stone_bricks
setblock 417 -21 210 minecraft:stone_bricks
fill 417 -21 211 417 -20 211 minecraft:mossy_cobblestone
setblock 417 -21 215 minecraft:stone_bricks
fill 417 -21 216 417 -18 216 minecraft:mossy_cobblestone
setblock 417 -21 219 minecraft:mossy_cobblestone
setblock 417 -21 220 minecraft:stone_bricks
fill 417 -21 221 417 -18 221 minecraft:mossy_cobblestone
setblock 377 -20 184 minecraft:stone_bricks
setblock 377 -20 185 minecraft:mossy_cobblestone
setblock 377 -20 189 minecraft:stone_bricks
fill 377 -20 190 377 -19 190 minecraft:mossy_cobblestone
setblock 377 -20 194 minecraft:stone_bricks
fill 377 -20 195 377 -18 195 minecraft:mossy_cobblestone
setblock 377 -20 209 minecraft:stone_bricks
fill 377 -20 210 377 -19 210 minecraft:mossy_cobblestone
setblock 377 -20 214 minecraft:stone_bricks
fill 377 -20 215 377 -17 215 minecraft:mossy_cobblestone
setblock 377 -20 219 minecraft:stone_bricks
fill 377 -20 220 377 -17 220 minecraft:mossy_cobblestone
setblock 378 -20 213 minecraft:stone_bricks
fill 378 -20 214 378 -17 214 minecraft:mossy_cobblestone
setblock 378 -20 218 minecraft:stone_bricks
fill 378 -20 219 378 -17 219 minecraft:mossy_cobblestone
setblock 379 -20 217 minecraft:stone_bricks
fill 379 -20 218 379 -19 218 minecraft:mossy_cobblestone
setblock 379 -20 222 minecraft:stone_bricks
setblock 380 -20 221 minecraft:stone_bricks
fill 380 -20 222 383 -20 222 minecraft:mossy_cobblestone
fill 381 -20 221 381 -17 221 minecraft:mossy_cobblestone
fill 383 -20 221 384 -20 221 minecraft:mossy_cobblestone
setblock 384 -20 222 minecraft:stone_bricks
setblock 385 -20 221 minecraft:stone_bricks
fill 385 -20 222 385 -17 222 minecraft:mossy_cobblestone
setblock 386 -20 220 minecraft:stone_bricks
fill 386 -20 221 389 -20 221 minecraft:mossy_cobblestone
fill 387 -20 220 390 -20 220 minecraft:mossy_cobblestone
setblock 389 -20 182 minecraft:stone_bricks
fill 389 -20 219 391 -20 219 minecraft:mossy_cobblestone
setblock 389 -20 222 minecraft:stone_bricks
fill 390 -20 182 390 -18 182 minecraft:mossy_cobblestone
setblock 390 -20 221 minecraft:stone_bricks
fill 390 -20 222 390 -17 222 minecraft:mossy_cobblestone
setblock 391 -20 220 minecraft:stone_bricks
fill 391 -20 221 391 -17 221 minecraft:mossy_cobblestone
fill 392 -20 182 392 -19 182 minecraft:mossy_cobblestone
fill 392 -20 220 392 -17 220 minecraft:mossy_cobblestone
setblock 394 -20 222 minecraft:stone_bricks
setblock 395 -20 221 minecraft:stone_bricks
fill 395 -20 222 395 -17 222 minecraft:mossy_cobblestone
fill 407 -20 182 407 -19 182 minecraft:mossy_cobblestone
setblock 408 -20 222 minecraft:mossy_cobblestone
setblock 409 -20 182 minecraft:stone_bricks
fill 409 -20 183 409 -17 183 minecraft:mossy_cobblestone
setblock 409 -20 222 minecraft:stone_bricks
fill 410 -20 182 410 -17 182 minecraft:mossy_cobblestone
setblock 410 -20 221 minecraft:stone_bricks
fill 410 -20 222 413 -20 222 minecraft:mossy_cobblestone
fill 411 -20 221 411 -17 221 minecraft:mossy_cobblestone
setblock 412 -20 184 minecraft:stone_bricks
setblock 413 -20 183 minecraft:stone_bricks
setblock 413 -20 184 minecraft:mossy_cobblestone
setblock 413 -20 193 minecraft:stone_bricks
setblock 413 -20 194 minecraft:mossy_cobblestone
setblock 414 -20 182 minecraft:stone_bricks
fill 414 -20 183 414 -17 183 minecraft:mossy_cobblestone
setblock 414 -20 188 minecraft:mossy_cobblestone
setblock 414 -20 192 minecraft:stone_bricks
fill 414 -20 193 414 -19 193 minecraft:mossy_cobblestone
setblock 414 -20 222 minecraft:stone_bricks
fill 415 -20 182 415 -17 182 minecraft:mossy_cobblestone
setblock 415 -20 186 minecraft:stone_bricks
setblock 415 -20 187 minecraft:mossy_cobblestone
setblock 415 -20 191 minecraft:stone_bricks
fill 415 -20 192 415 -18 192 minecraft:mossy_cobblestone
setblock 415 -20 196 minecraft:stone_bricks
fill 415 -20 197 415 -19 197 minecraft:mossy_cobblestone
setblock 415 -20 216 minecraft:stone_bricks
setblock 415 -20 217 minecraft:mossy_cobblestone
setblock 415 -20 221 minecraft:stone_bricks
fill 415 -20 222 415 -17 222 minecraft:mossy_cobblestone
setblock 416 -20 185 minecraft:stone_bricks
fill 416 -20 186 416 -19 186 minecraft:mossy_cobblestone
setblock 416 -20 190 minecraft:stone_bricks
fill 416 -20 191 416 -17 191 minecraft:mossy_cobblestone
setblock 416 -20 195 minecraft:stone_bricks
fill 416 -20 196 416 -17 196 minecraft:mossy_cobblestone
setblock 416 -20 215 minecraft:stone_bricks
fill 416 -20 216 416 -18 216 minecraft:mossy_cobblestone
fill 416 -20 218 416 -20 219 minecraft:mossy_cobblestone
setblock 416 -20 220 minecraft:stone_bricks
fill 416 -20 221 416 -17 221 minecraft:mossy_cobblestone
setblock 417 -20 184 minecraft:stone_bricks
fill 417 -20 185 417 -18 185 minecraft:mossy_cobblestone
setblock 417 -20 189 minecraft:stone_bricks
fill 417 -20 190 417 -17 190 minecraft:mossy_cobblestone
setblock 417 -20 194 minecraft:stone_bricks
fill 417 -20 195 417 -17 195 minecraft:mossy_cobblestone
setblock 417 -20 199 minecraft:stone_bricks
fill 417 -20 200 417 -19 200 minecraft:mossy_cobblestone
setblock 417 -20 210 minecraft:mossy_cobblestone
setblock 417 -20 214 minecraft:stone_bricks
fill 417 -20 215 417 -17 215 minecraft:mossy_cobblestone
setblock 417 -20 219 minecraft:stone_bricks
fill 417 -20 220 417 -17 220 minecraft:mossy_cobblestone
setblock 377 -19 183 minecraft:stone_bricks
setblock 377 -19 188 minecraft:stone_bricks
setblock 377 -19 189 minecraft:mossy_cobblestone
setblock 377 -19 193 minecraft:stone_bricks
fill 377 -19 194 377 -18 194 minecraft:mossy_cobblestone
setblock 377 -19 198 minecraft:stone_bricks
setblock 377 -19 213 minecraft:stone_bricks
fill 377 -19 214 377 -16 214 minecraft:mossy_cobblestone
setblock 377 -19 218 minecraft:stone_bricks
fill 377 -19 219 377 -16 219 minecraft:mossy_cobblestone
setblock 378 -19 212 minecraft:stone_bricks
fill 378 -19 213 378 -18 213 minecraft:mossy_cobblestone
setblock 378 -19 216 minecraft:mossy_cobblestone
setblock 378 -19 217 minecraft:stone_bricks
fill 378 -19 218 378 -16 218 minecraft:mossy_cobblestone
setblock 378 -19 222 minecraft:stone_bricks
setblock 379 -19 216 minecraft:stone_bricks
setblock 379 -19 217 minecraft:mossy_cobblestone
setblock 379 -19 221 minecraft:stone_bricks
fill 379 -19 222 382 -19 222 minecraft:mossy_cobblestone
fill 380 -19 221 380 -16 221 minecraft:mossy_cobblestone
fill 382 -19 221 383 -19 221 minecraft:mossy_cobblestone
setblock 383 -19 222 minecraft:stone_bricks
setblock 384 -19 221 minecraft:stone_bricks
fill 384 -19 222 384 -16 222 minecraft:mossy_cobblestone
setblock 385 -19 220 minecraft:stone_bricks
fill 385 -19 221 388 -19 221 minecraft:mossy_cobblestone
fill 386 -19 220 389 -19 220 minecraft:mossy_cobblestone
fill 388 -19 219 390 -19 219 minecraft:mossy_cobblestone
setblock 388 -19 222 minecraft:stone_bricks
fill 389 -19 182 389 -17 182 minecraft:mossy_cobblestone
setblock 389 -19 221 minecraft:stone_bricks
fill 389 -19 222 389 -16 222 minecraft:mossy_cobblestone
setblock 390 -19 220 minecraft:stone_bricks
fill 390 -19 221 390 -16 221 minecraft:mossy_cobblestone
setblock 391 -19 219 minecraft:stone_bricks
fill 391 -19 220 391 -16 220 minecraft:mossy_cobblestone
setblock 393 -19 222 minecraft:stone_bricks
setblock 394 -19 221 minecraft:stone_bricks
fill 394 -19 222 394 -16 222 minecraft:mossy_cobblestone
fill 406 -19 182 406 -18 182 minecraft:mossy_cobblestone
setblock 407 -19 222 minecraft:mossy_cobblestone
setblock 408 -19 182 minecraft:stone_bricks
setblock 408 -19 222 minecraft:stone_bricks
fill 409 -19 182 409 -16 182 minecraft:mossy_cobblestone
setblock 409 -19 221 minecraft:stone_bricks
fill 409 -19 222 412 -19 222 minecraft:mossy_cobblestone
fill 410 -19 221 410 -16 221 minecraft:mossy_cobblestone
setblock 412 -19 183 minecraft:stone_bricks
setblock 413 -19 182 minecraft:stone_bricks
fill 413 -19 183 413 -16 183 minecraft:mossy_cobblestone
setblock 413 -19 222 minecraft:stone_bricks
fill 414 -19 182 414 -16 182 minecraft:mossy_cobblestone
setblock 414 -19 191 minecraft:stone_bricks
setblock 414 -19 192 minecraft:mossy_cobblestone
setblock 414 -19 195 minecraft:mossy_cobblestone
setblock 414 -19 196 minecraft:stone_bricks
setblock 414 -19 221 minecraft:stone_bricks
fill 414 -19 222 414 -16 222 minecraft:mossy_cobblestone
setblock 415 -19 190 minecraft:stone_bricks
fill 415 -19 191 415 -18 191 minecraft:mossy_cobblestone
setblock 415 -19 195 minecraft:stone_bricks
fill 415 -19 196 415 -18 196 minecraft:mossy_cobblestone
fill 415 -19 221 415 -16 221 minecraft:mossy_cobblestone
setblock 416 -19 184 minecraft:stone_bricks
setblock 416 -19 185 minecraft:mossy_cobblestone
setblock 416 -19 189 minecraft:stone_bricks
fill 416 -19 190 416 -18 190 minecraft:mossy_cobblestone
setblock 416 -19 194 minecraft:stone_bricks
fill 416 -19 195 416 -17 195 minecraft:mossy_cobblestone
setblock 416 -19 198 minecraft:mossy_cobblestone
setblock 416 -19 214 minecraft:stone_bricks
fill 416 -19 215 416 -18 215 minecraft:mossy_cobblestone
setblock 416 -19 218 minecraft:mossy_cobblestone
setblock 416 -19 219 minecraft:stone_bricks
fill 416 -19 220 416 -16 220 minecraft:mossy_cobblestone
setblock 417 -19 183 minecraft:stone_bricks
fill 417 -19 184 417 -17 184 minecraft:mossy_cobblestone
setblock 417 -19 188 minecraft:stone_bricks
fill 417 -19 189 417 -17 189 minecraft:mossy_cobblestone
setblock 417 -19 193 minecraft:stone_bricks
fill 417 -19 194 417 -16 194 minecraft:mossy_cobblestone
setblock 417 -19 198 minecraft:stone_bricks
fill 417 -19 199 417 -17 199 minecraft:mossy_cobblestone
setblock 417 -19 213 minecraft:stone_bricks
fill 417 -19 214 417 -17 214 minecraft:mossy_cobblestone
setblock 417 -19 218 minecraft:stone_bricks
fill 417 -19 219 417 -16 219 minecraft:mossy_cobblestone
setblock 377 -18 192 minecraft:stone_bricks
setblock 377 -18 193 minecraft:mossy_cobblestone
setblock 377 -18 197 minecraft:stone_bricks
setblock 377 -18 212 minecraft:stone_bricks
fill 377 -18 213 377 -16 213 minecraft:mossy_cobblestone
setblock 377 -18 217 minecraft:stone_bricks
fill 377 -18 218 377 -15 218 minecraft:mossy_cobblestone
setblock 377 -18 222 minecraft:stone_bricks
setblock 378 -18 216 minecraft:stone_bricks
fill 378 -18 217 378 -15 217 minecraft:mossy_cobblestone
setblock 378 -18 221 minecraft:stone_bricks
fill 378 -18 222 381 -18 222 minecraft:mossy_cobblestone
fill 379 -18 221 379 -15 221 minecraft:mossy_cobblestone
setblock 382 -18 221 minecraft:mossy_cobblestone
setblock 382 -18 222 minecraft:stone_bricks
setblock 383 -18 221 minecraft:stone_bricks
fill 383 -18 222 383 -15 222 minecraft:mossy_cobblestone
fill 384 -18 221 387 -18 221 minecraft:mossy_cobblestone
fill 385 -18 220 388 -18 220 minecraft:mossy_cobblestone
fill 387 -18 219 389 -18 219 minecraft:mossy_cobblestone
setblock 387 -18 222 minecraft:stone_bricks
setblock 388 -18 221 minecraft:stone_bricks
fill 388 -18 222 388 -15 222 minecraft:mossy_cobblestone
setblock 389 -18 220 minecraft:stone_bricks
fill 389 -18 221 389 -15 221 minecraft:mossy_cobblestone
setblock 390 -18 219 minecraft:stone_bricks
fill 390 -18 220 390 -15 220 minecraft:mossy_cobblestone
setblock 391 -18 219 minecraft:mossy_cobblestone
setblock 392 -18 222 minecraft:stone_bricks
setblock 393 -18 221 minecraft:stone_bricks
fill 393 -18 222 393 -15 222 minecraft:mossy_cobblestone
setblock 394 -18 221 minecraft:mossy_cobblestone
setblock 406 -18 222 minecraft:mossy_cobblestone
setblock 407 -18 182 minecraft:stone_bricks
setblock 407 -18 222 minecraft:stone_bricks
fill 408 -18 182 408 -16 183 minecraft:mossy_cobblestone
setblock 408 -18 221 minecraft:stone_bricks
fill 408 -18 222 411 -18 222 minecraft:mossy_cobblestone
fill 409 -18 221 409 -15 221 minecraft:mossy_cobblestone
setblock 411 -18 183 minecraft:stone_bricks
setblock 412 -18 182 minecraft:stone_bricks
fill 412 -18 183 412 -15 183 minecraft:mossy_cobblestone
fill 412 -18 220 412 -18 221 minecraft:mossy_cobblestone
setblock 412 -18 222 minecraft:stone_bricks
fill 413 -18 182 413 -15 182 minecraft:mossy_cobblestone
setblock 413 -18 221 minecraft:stone_bricks
fill 413 -18 222 413 -15 222 minecraft:mossy_cobblestone
fill 414 -18 221 414 -15 221 minecraft:mossy_cobblestone
setblock 415 -18 190 minecraft:mossy_cobblestone
setblock 415 -18 194 minecraft:stone_bricks
setblock 415 -18 195 minecraft:mossy_cobblestone
setblock 416 -18 188 minecraft:stone_bricks
setblock 416 -18 189 minecraft:mossy_cobblestone
setblock 416 -18 193 minecraft:stone_bricks
fill 416 -18 194 416 -17 194 minecraft:mossy_cobblestone
setblock 416 -18 198 minecraft:stone_bricks
setblock 416 -18 218 minecraft:stone_bricks
fill 416 -18 219 416 -16 219 minecraft:mossy_cobblestone
setblock 417 -18 182 minecraft:stone_bricks
fill 417 -18 183 417 -17 183 minecraft:mossy_cobblestone
setblock 417 -18 187 minecraft:stone_bricks
fill 417 -18 188 417 -17 188 minecraft:mossy_cobblestone
setblock 417 -18 192 minecraft:stone_bricks
fill 417 -18 193 417 -16 193 minecraft:mossy_cobblestone
setblock 417 -18 197 minecraft:stone_bricks
fill 417 -18 198 417 -16 198 minecraft:mossy_cobblestone
setblock 417 -18 213 minecraft:mossy_cobblestone
setblock 417 -18 217 minecraft:stone_bricks
fill 417 -18 218 417 -15 218 minecraft:mossy_cobblestone
setblock 417 -18 222 minecraft:stone_bricks
setblock 377 -17 212 minecraft:mossy_cobblestone
setblock 377 -17 216 minecraft:stone_bricks
fill 377 -17 217 377 -14 217 minecraft:mossy_cobblestone
setblock 377 -17 221 minecraft:stone_bricks
fill 377 -17 222 380 -17 222 minecraft:mossy_cobblestone
setblock 378 -17 215 minecraft:stone_bricks
fill 378 -17 216 378 -16 216 minecraft:mossy_cobblestone
setblock 378 -17 220 minecraft:stone_bricks
fill 378 -17 221 378 -14 221 minecraft:mossy_cobblestone
setblock 381 -17 222 minecraft:stone_bricks
setblock 382 -17 221 minecraft:stone_bricks
fill 382 -17 222 382 -14 222 minecraft:mossy_cobblestone
fill 383 -17 221 386 -17 221 minecraft:mossy_cobblestone
fill 384 -17 220 387 -17 220 minecraft:mossy_cobblestone
setblock 386 -17 222 minecraft:stone_bricks
setblock 387 -17 221 minecraft:stone_bricks
fill 387 -17 222 387 -14 222 minecraft:mossy_cobblestone
setblock 388 -17 219 minecraft:mossy_cobblestone
setblock 388 -17 220 minecraft:stone_bricks
fill 388 -17 221 388 -14 221 minecraft:mossy_cobblestone
setblock 389 -17 219 minecraft:stone_bricks
fill 389 -17 220 389 -14 220 minecraft:mossy_cobblestone
setblock 390 -17 219 minecraft:mossy_cobblestone
setblock 391 -17 222 minecraft:stone_bricks
setblock 392 -17 221 minecraft:stone_bricks
fill 392 -17 222 392 -14 222 minecraft:mossy_cobblestone
fill 393 -17 221 393 -16 221 minecraft:mossy_cobblestone
setblock 406 -17 182 minecraft:stone_bricks
setblock 406 -17 222 minecraft:stone_bricks
fill 407 -17 182 407 -14 182 minecraft:mossy_cobblestone
fill 407 -17 222 410 -17 222 minecraft:mossy_cobblestone
fill 408 -17 221 408 -14 221 minecraft:mossy_cobblestone
setblock 410 -17 183 minecraft:stone_bricks
setblock 411 -17 182 minecraft:stone_bricks
fill 411 -17 183 411 -14 183 minecraft:mossy_cobblestone
setblock 411 -17 222 minecraft:stone_bricks
fill 412 -17 182 412 -14 182 minecraft:mossy_cobblestone
setblock 412 -17 221 minecraft:stone_bricks
fill 412 -17 222 412 -14 222 minecraft:mossy_cobblestone
fill 413 -17 221 413 -14 221 minecraft:mossy_cobblestone
setblock 416 -17 182 minecraft:stone_bricks
setblock 416 -17 192 minecraft:stone_bricks
setblock 416 -17 193 minecraft:mossy_cobblestone
setblock 416 -17 197 minecraft:stone_bricks
setblock 416 -17 217 minecraft:stone_bricks
fill 416 -17 218 416 -16 218 minecraft:mossy_cobblestone
setblock 416 -17 222 minecraft:stone_bricks
fill 417 -17 182 417 -14 182 minecraft:mossy_cobblestone
setblock 417 -17 187 minecraft:mossy_cobblestone
setblock 417 -17 191 minecraft:stone_bricks
fill 417 -17 192 417 -16 192 minecraft:mossy_cobblestone
setblock 417 -17 196 minecraft:stone_bricks
fill 417 -17 197 417 -16 197 minecraft:mossy_cobblestone
setblock 417 -17 216 minecraft:stone_bricks
fill 417 -17 217 417 -14 217 minecraft:mossy_cobblestone
setblock 417 -17 221 minecraft:stone_bricks
fill 417 -17 222 417 -14 222 minecraft:mossy_cobblestone
setblock 377 -16 215 minecraft:stone_bricks
fill 377 -16 216 377 -13 216 minecraft:mossy_cobblestone
setblock 377 -16 220 minecraft:stone_bricks
fill 377 -16 221 377 -14 222 minecraft:mossy_cobblestone
setblock 378 -16 219 minecraft:stone_bricks
fill 378 -16 220 378 -13 220 minecraft:mossy_cobblestone
fill 378 -16 222 379 -16 222 minecraft:mossy_cobblestone
setblock 380 -16 222 minecraft:stone_bricks
setblock 381 -16 221 minecraft:stone_bricks
fill 381 -16 222 381 -13 222 minecraft:mossy_cobblestone
fill 382 -16 221 385 -16 221 minecraft:mossy_cobblestone
fill 384 -16 220 386 -16 220 minecraft:mossy_cobblestone
setblock 385 -16 222 minecraft:stone_bricks
setblock 386 -16 221 minecraft:stone_bricks
fill 386 -16 222 386 -13 222 minecraft:mossy_cobblestone
setblock 387 -16 220 minecraft:stone_bricks
fill 387 -16 221 387 -13 221 minecraft:mossy_cobblestone
fill 388 -16 220 388 -13 220 minecraft:mossy_cobblestone
setblock 390 -16 222 minecraft:stone_bricks
setblock 391 -16 221 minecraft:stone_bricks
fill 391 -16 222 391 -13 222 minecraft:mossy_cobblestone
fill 392 -16 221 392 -15 221 minecraft:mossy_cobblestone
setblock 405 -16 182 minecraft:stone_bricks
setblock 405 -16 222 minecraft:stone_bricks
fill 406 -16 182 406 -13 182 minecraft:mossy_cobblestone
fill 406 -16 222 409 -16 222 minecraft:mossy_cobblestone
fill 407 -16 221 407 -13 221 minecraft:mossy_cobblestone
setblock 409 -16 183 minecraft:stone_bricks
setblock 410 -16 182 minecraft:stone_bricks
fill 410 -16 183 410 -13 183 minecraft:mossy_cobblestone
setblock 410 -16 222 minecraft:stone_bricks
fill 411 -16 182 411 -13 182 minecraft:mossy_cobblestone
setblock 411 -16 221 minecraft:stone_bricks
fill 411 -16 222 411 -13 222 minecraft:mossy_cobblestone
fill 412 -16 221 412 -13 221 minecraft:mossy_cobblestone
setblock 415 -16 182 minecraft:stone_bricks
setblock 415 -16 222 minecraft:stone_bricks
fill 416 -16 182 416 -13 182 minecraft:mossy_cobblestone
setblock 416 -16 221 minecraft:stone_bricks
fill 416 -16 222 416 -13 222 minecraft:mossy_cobblestone
setblock 417 -16 195 minecraft:stone_bricks
setblock 417 -16 196 minecraft:mossy_cobblestone
setblock 417 -16 215 minecraft:stone_bricks
fill 417 -16 216 417 -15 216 minecraft:mossy_cobblestone
setblock 417 -16 220 minecraft:stone_bricks
fill 417 -16 221 417 -13 221 minecraft:mossy_cobblestone
setblock 377 -15 214 minecraft:stone_bricks
fill 377 -15 215 377 -14 215 minecraft:mossy_cobblestone
setblock 377 -15 219 minecraft:stone_bricks
fill 377 -15 220 377 -12 220 minecraft:mossy_cobblestone
setblock 378 -15 218 minecraft:stone_bricks
fill 378 -15 219 378 -12 219 minecraft:mossy_cobblestone
setblock 378 -15 222 minecraft:mossy_cobblestone
setblock 379 -15 184 minecraft:light[level=12]
setblock 379 -15 192 minecraft:light[level=12]
setblock 379 -15 200 minecraft:light[level=12]
setblock 379 -15 208 minecraft:light[level=12]
setblock 379 -15 216 minecraft:light[level=12]
setblock 379 -15 222 minecraft:stone_bricks
setblock 380 -15 221 minecraft:stone_bricks
fill 380 -15 222 380 -12 222 minecraft:mossy_cobblestone
fill 381 -15 221 384 -15 221 minecraft:mossy_cobblestone
fill 384 -15 220 385 -15 220 minecraft:mossy_cobblestone
setblock 384 -15 222 minecraft:stone_bricks
setblock 385 -15 221 minecraft:stone_bricks
fill 385 -15 222 385 -12 222 minecraft:mossy_cobblestone
setblock 386 -15 220 minecraft:stone_bricks
fill 386 -15 221 386 -12 221 minecraft:mossy_cobblestone
setblock 387 -15 184 minecraft:light[level=12]
setblock 387 -15 192 minecraft:light[level=12]
setblock 387 -15 200 minecraft:light[level=12]
setblock 387 -15 208 minecraft:light[level=12]
setblock 387 -15 216 minecraft:light[level=12]
fill 387 -15 220 387 -12 220 minecraft:mossy_cobblestone
setblock 389 -15 222 minecraft:stone_bricks
setblock 390 -15 221 minecraft:stone_bricks
fill 390 -15 222 390 -12 222 minecraft:mossy_cobblestone
fill 391 -15 221 391 -13 221 minecraft:mossy_cobblestone
setblock 395 -15 184 minecraft:light[level=12]
setblock 395 -15 192 minecraft:light[level=12]
setblock 395 -15 200 minecraft:light[level=12]
setblock 395 -15 208 minecraft:light[level=12]
setblock 395 -15 216 minecraft:light[level=12]
setblock 403 -15 184 minecraft:light[level=12]
setblock 403 -15 192 minecraft:light[level=12]
setblock 403 -15 200 minecraft:light[level=12]
setblock 403 -15 208 minecraft:light[level=12]
setblock 403 -15 216 minecraft:light[level=12]
setblock 404 -15 182 minecraft:stone_bricks
setblock 404 -15 222 minecraft:stone_bricks
fill 405 -15 182 405 -12 182 minecraft:mossy_cobblestone
fill 405 -15 222 408 -15 222 minecraft:mossy_cobblestone
setblock 407 -15 183 minecraft:mossy_cobblestone
setblock 408 -15 182 minecraft:mossy_cobblestone
setblock 408 -15 183 minecraft:stone_bricks
setblock 409 -15 182 minecraft:stone_bricks
fill 409 -15 183 409 -12 183 minecraft:mossy_cobblestone
setblock 409 -15 222 minecraft:stone_bricks
fill 410 -15 182 410 -12 182 minecraft:mossy_cobblestone
setblock 410 -15 221 minecraft:stone_bricks
fill 410 -15 222 410 -12 222 minecraft:mossy_cobblestone
setblock 411 -15 184 minecraft:light[level=12]
setblock 411 -15 192 minecraft:light[level=12]
setblock 411 -15 200 minecraft:light[level=12]
setblock 411 -15 208 minecraft:light[level=12]
setblock 411 -15 216 minecraft:light[level=12]
fill 411 -15 221 411 -12 221 minecraft:mossy_cobblestone
setblock 413 -15 183 minecraft:stone_bricks
setblock 414 -15 182 minecraft:stone_bricks
setblock 414 -15 222 minecraft:stone_bricks
fill 415 -15 182 415 -12 182 minecraft:mossy_cobblestone
setblock 415 -15 221 minecraft:stone_bricks
fill 415 -15 222 415 -12 222 minecraft:mossy_cobblestone
setblock 417 -15 219 minecraft:stone_bricks
fill 417 -15 220 417 -12 220 minecraft:mossy_cobblestone
setblock 377 -14 218 minecraft:stone_bricks
fill 377 -14 219 377 -11 219 minecraft:mossy_cobblestone
setblock 378 -14 218 minecraft:mossy_cobblestone
setblock 378 -14 222 minecraft:stone_bricks
setblock 379 -14 221 minecraft:stone_bricks
fill 379 -14 222 379 -11 222 minecraft:mossy_cobblestone
fill 380 -14 221 383 -14 221 minecraft:mossy_cobblestone
setblock 383 -14 222 minecraft:stone_bricks
setblock 384 -14 220 minecraft:mossy_cobblestone
setblock 384 -14 221 minecraft:stone_bricks
fill 384 -14 222 384 -11 222 minecraft:mossy_cobblestone
setblock 385 -14 220 minecraft:stone_bricks
fill 385 -14 221 385 -11 221 minecraft:mossy_cobblestone
fill 386 -14 220 386 -11 220 minecraft:mossy_cobblestone
setblock 387 -14 182 minecraft:mossy_cobblestone
setblock 388 -14 182 minecraft:stone_bricks
setblock 388 -14 222 minecraft:stone_bricks
setblock 389 -14 221 minecraft:stone_bricks
fill 389 -14 222 389 -11 222 minecraft:mossy_cobblestone
fill 390 -14 221 390 -11 221 minecraft:mossy_cobblestone
setblock 393 -14 222 minecraft:stone_bricks
fill 404 -14 182 404 -11 182 minecraft:mossy_cobblestone
fill 404 -14 222 407 -14 222 minecraft:mossy_cobblestone
setblock 406 -14 183 minecraft:mossy_cobblestone
fill 406 -14 221 406 -12 221 minecraft:mossy_cobblestone
setblock 407 -14 183 minecraft:stone_bricks
setblock 408 -14 182 minecraft:stone_bricks
fill 408 -14 183 408 -11 183 minecraft:mossy_cobblestone
setblock 408 -14 222 minecraft:stone_bricks
fill 409 -14 182 409 -11 182 minecraft:mossy_cobblestone
setblock 409 -14 221 minecraft:stone_bricks
fill 409 -14 222 409 -11 222 minecraft:mossy_cobblestone
fill 410 -14 221 410 -11 221 minecraft:mossy_cobblestone
setblock 412 -14 183 minecraft:stone_bricks
setblock 413 -14 182 minecraft:stone_bricks
setblock 413 -14 222 minecraft:stone_bricks
fill 414 -14 182 414 -11 182 minecraft:mossy_cobblestone
setblock 414 -14 221 minecraft:stone_bricks
fill 414 -14 222 414 -11 222 minecraft:mossy_cobblestone
fill 415 -14 221 415 -11 221 minecraft:mossy_cobblestone
setblock 417 -14 218 minecraft:stone_bricks
fill 417 -14 219 417 -11 219 minecraft:mossy_cobblestone
setblock 377 -13 217 minecraft:stone_bricks
fill 377 -13 218 377 -10 218 minecraft:mossy_cobblestone
setblock 377 -13 221 minecraft:mossy_cobblestone
setblock 377 -13 222 minecraft:stone_bricks
fill 378 -13 218 378 -10 218 minecraft:spruce_log
setblock 378 -13 221 minecraft:stone_bricks
fill 378 -13 222 378 -10 222 minecraft:mossy_cobblestone
fill 379 -13 221 382 -13 221 minecraft:mossy_cobblestone
setblock 382 -13 222 minecraft:stone_bricks
setblock 383 -13 221 minecraft:stone_bricks
fill 383 -13 222 383 -10 222 minecraft:mossy_cobblestone
setblock 384 -13 220 minecraft:stone_bricks
fill 384 -13 221 384 -10 221 minecraft:mossy_cobblestone
fill 385 -13 182 386 -13 182 minecraft:mossy_cobblestone
fill 385 -13 220 385 -10 220 minecraft:mossy_cobblestone
setblock 387 -13 182 minecraft:stone_bricks
setblock 387 -13 222 minecraft:stone_bricks
fill 388 -13 182 389 -11 182 minecraft:mossy_cobblestone
setblock 388 -13 221 minecraft:stone_bricks
fill 388 -13 222 388 -10 222 minecraft:mossy_cobblestone
setblock 389 -13 220 minecraft:stone_bricks
fill 389 -13 221 389 -10 221 minecraft:mossy_cobblestone
setblock 392 -13 222 minecraft:stone_bricks
setblock 393 -13 222 minecraft:mossy_cobblestone
fill 403 -13 182 403 -10 182 minecraft:mossy_cobblestone
fill 403 -13 222 406 -13 222 minecraft:mossy_cobblestone
setblock 405 -13 183 minecraft:mossy_cobblestone
fill 405 -13 221 405 -11 221 minecraft:mossy_cobblestone
setblock 406 -13 183 minecraft:stone_bricks
setblock 407 -13 182 minecraft:stone_bricks
fill 407 -13 183 407 -10 183 minecraft:mossy_cobblestone
setblock 407 -13 222 minecraft:stone_bricks
fill 408 -13 182 408 -10 182 minecraft:mossy_cobblestone
setblock 408 -13 221 minecraft:stone_bricks
fill 408 -13 222 408 -10 222 minecraft:mossy_cobblestone
fill 409 -13 221 409 -10 221 minecraft:mossy_cobblestone
setblock 411 -13 183 minecraft:stone_bricks
setblock 412 -13 182 minecraft:stone_bricks
fill 412 -13 183 412 -10 183 minecraft:mossy_cobblestone
setblock 412 -13 222 minecraft:stone_bricks
fill 413 -13 182 413 -10 182 minecraft:mossy_cobblestone
setblock 413 -13 221 minecraft:stone_bricks
fill 413 -13 222 413 -10 222 minecraft:mossy_cobblestone
fill 414 -13 221 414 -10 221 minecraft:mossy_cobblestone
setblock 417 -13 182 minecraft:stone_bricks
fill 417 -13 218 417 -10 218 minecraft:mossy_cobblestone
setblock 417 -13 222 minecraft:stone_bricks
setblock 377 -12 216 minecraft:stone_bricks
fill 377 -12 217 377 -9 217 minecraft:mossy_cobblestone
setblock 377 -12 221 minecraft:stone_bricks
fill 377 -12 222 377 -9 222 minecraft:mossy_cobblestone
setblock 378 -12 220 minecraft:stone_bricks
fill 378 -12 221 381 -12 221 minecraft:mossy_cobblestone
setblock 381 -12 222 minecraft:stone_bricks
setblock 382 -12 221 minecraft:stone_bricks
fill 382 -12 222 382 -9 222 minecraft:mossy_cobblestone
setblock 383 -12 220 minecraft:stone_bricks
fill 383 -12 221 383 -9 221 minecraft:mossy_cobblestone
fill 384 -12 182 385 -12 182 minecraft:mossy_cobblestone
fill 384 -12 220 384 -9 220 minecraft:mossy_cobblestone
setblock 386 -12 182 minecraft:stone_bricks
setblock 386 -12 222 minecraft:stone_bricks
fill 387 -12 182 387 -9 182 minecraft:mossy_cobblestone
setblock 387 -12 221 minecraft:stone_bricks
fill 387 -12 222 387 -9 222 minecraft:mossy_cobblestone
setblock 388 -12 220 minecraft:stone_bricks
fill 388 -12 221 388 -9 221 minecraft:mossy_cobblestone
setblock 390 -12 182 minecraft:mossy_cobblestone
setblock 391 -12 222 minecraft:stone_bricks
fill 392 -12 222 392 -9 222 minecraft:mossy_cobblestone
fill 402 -12 182 402 -9 182 minecraft:mossy_cobblestone
fill 402 -12 222 405 -12 222 minecraft:mossy_cobblestone
setblock 404 -12 183 minecraft:mossy_cobblestone
setblock 405 -12 183 minecraft:stone_bricks
setblock 406 -12 182 minecraft:stone_bricks
fill 406 -12 183 406 -9 183 minecraft:mossy_cobblestone
setblock 406 -12 222 minecraft:stone_bricks
fill 407 -12 182 407 -9 182 minecraft:mossy_cobblestone
setblock 407 -12 221 minecraft:stone_bricks
fill 407 -12 222 407 -9 222 minecraft:mossy_cobblestone
fill 408 -12 221 408 -9 221 minecraft:mossy_cobblestone
setblock 410 -12 183 minecraft:stone_bricks
setblock 411 -12 182 minecraft:stone_bricks
fill 411 -12 183 411 -9 183 minecraft:mossy_cobblestone
setblock 411 -12 222 minecraft:stone_bricks
fill 412 -12 182 412 -9 182 minecraft:mossy_cobblestone
setblock 412 -12 221 minecraft:stone_bricks
fill 412 -12 222 412 -9 222 minecraft:mossy_cobblestone
fill 413 -12 183 413 -11 183 minecraft:mossy_cobblestone
fill 413 -12 221 413 -9 221 minecraft:mossy_cobblestone
setblock 416 -12 182 minecraft:stone_bricks
setblock 416 -12 222 minecraft:stone_bricks
fill 417 -12 182 417 -9 182 minecraft:mossy_cobblestone
setblock 417 -12 221 minecraft:stone_bricks
fill 417 -12 222 417 -9 222 minecraft:mossy_cobblestone
fill 377 -11 216 377 -8 216 minecraft:mossy_cobblestone
setblock 377 -11 220 minecraft:stone_bricks
fill 377 -11 221 380 -11 221 minecraft:mossy_cobblestone
setblock 378 -11 219 minecraft:stone_bricks
fill 378 -11 220 378 -8 220 minecraft:mossy_cobblestone
setblock 380 -11 222 minecraft:stone_bricks
fill 381 -11 182 384 -11 182 minecraft:mossy_cobblestone
setblock 381 -11 221 minecraft:stone_bricks
fill 381 -11 222 381 -8 222 minecraft:mossy_cobblestone
setblock 382 -11 220 minecraft:stone_bricks
fill 382 -11 221 382 -8 221 minecraft:mossy_cobblestone
fill 383 -11 220 383 -8 220 minecraft:mossy_cobblestone
setblock 385 -11 182 minecraft:stone_bricks
setblock 385 -11 222 minecraft:stone_bricks
fill 386 -11 182 386 -8 182 minecraft:mossy_cobblestone
setblock 386 -11 221 minecraft:stone_bricks
fill 386 -11 222 386 -8 222 minecraft:mossy_cobblestone
setblock 387 -11 220 minecraft:stone_bricks
fill 387 -11 221 387 -8 221 minecraft:mossy_cobblestone
setblock 388 -11 220 minecraft:mossy_cobblestone
setblock 390 -11 182 minecraft:stone_bricks
setblock 390 -11 222 minecraft:stone_bricks
fill 391 -11 222 391 -8 222 minecraft:mossy_cobblestone
setblock 400 -11 182 minecraft:stone_bricks
fill 401 -11 182 401 -8 182 minecraft:mossy_cobblestone
fill 401 -11 222 404 -11 222 minecraft:mossy_cobblestone
setblock 403 -11 183 minecraft:mossy_cobblestone
setblock 404 -11 183 minecraft:stone_bricks
fill 404 -11 221 404 -10 221 minecraft:mossy_cobblestone
setblock 405 -11 182 minecraft:stone_bricks
fill 405 -11 183 405 -8 183 minecraft:mossy_cobblestone
setblock 405 -11 222 minecraft:stone_bricks
fill 406 -11 182 406 -8 182 minecraft:mossy_cobblestone
fill 406 -11 184 407 -11 184 minecraft:mossy_cobblestone
setblock 406 -11 221 minecraft:stone_bricks
fill 406 -11 222 406 -8 222 minecraft:mossy_cobblestone
fill 407 -11 221 407 -8 221 minecraft:mossy_cobblestone
setblock 408 -11 184 minecraft:stone_bricks
setblock 409 -11 183 minecraft:stone_bricks
fill 409 -11 184 409 -8 184 minecraft:mossy_cobblestone
setblock 410 -11 182 minecraft:stone_bricks
fill 410 -11 183 410 -8 183 minecraft:mossy_cobblestone
setblock 410 -11 222 minecraft:stone_bricks
fill 411 -11 182 411 -8 182 minecraft:mossy_cobblestone
setblock 411 -11 221 minecraft:stone_bricks
fill 411 -11 222 411 -8 222 minecraft:mossy_cobblestone
fill 412 -11 221 412 -8 221 minecraft:mossy_cobblestone
setblock 415 -11 182 minecraft:stone_bricks
setblock 415 -11 222 minecraft:stone_bricks
fill 416 -11 182 416 -8 182 minecraft:mossy_cobblestone
setblock 416 -11 221 minecraft:stone_bricks
fill 416 -11 222 416 -8 222 minecraft:mossy_cobblestone
fill 417 -11 183 417 -10 183 minecraft:mossy_cobblestone
setblock 417 -11 220 minecraft:stone_bricks
fill 417 -11 221 417 -8 221 minecraft:mossy_cobblestone
fill 377 -10 201 377 -10 203 minecraft:mossy_cobblestone
setblock 377 -10 219 minecraft:stone_bricks
fill 377 -10 220 377 -8 221 minecraft:mossy_cobblestone
fill 378 -10 219 378 -7 219 minecraft:mossy_cobblestone
fill 378 -10 221 379 -10 221 minecraft:mossy_cobblestone
setblock 379 -10 182 minecraft:stone_bricks
setblock 379 -10 222 minecraft:stone_bricks
fill 380 -10 182 383 -10 182 minecraft:mossy_cobblestone
setblock 380 -10 221 minecraft:stone_bricks
fill 380 -10 222 380 -7 222 minecraft:mossy_cobblestone
fill 381 -10 221 381 -7 221 minecraft:mossy_cobblestone
fill 382 -10 220 382 -7 220 minecraft:mossy_cobblestone
setblock 384 -10 182 minecraft:stone_bricks
setblock 384 -10 222 minecraft:stone_bricks
fill 385 -10 182 385 -7 182 minecraft:mossy_cobblestone
setblock 385 -10 221 minecraft:stone_bricks
fill 385 -10 222 385 -7 222 minecraft:mossy_cobblestone
setblock 386 -10 220 minecraft:stone_bricks
fill 386 -10 221 386 -7 221 minecraft:mossy_cobblestone
fill 387 -10 220 387 -9 220 minecraft:mossy_cobblestone
setblock 388 -10 182 minecraft:mossy_cobblestone
setblock 389 -10 182 minecraft:stone_bricks
setblock 389 -10 222 minecraft:stone_bricks
fill 390 -10 182 391 -8 182 minecraft:mossy_cobblestone
setblock 390 -10 221 minecraft:stone_bricks
fill 390 -10 222 390 -7 222 minecraft:mossy_cobblestone
setblock 398 -10 182 minecraft:mossy_cobblestone
setblock 399 -10 182 minecraft:stone_bricks
fill 400 -10 182 400 -7 182 minecraft:mossy_cobblestone
fill 400 -10 222 403 -10 222 minecraft:mossy_cobblestone
fill 401 -10 183 402 -10 183 minecraft:mossy_cobblestone
setblock 403 -10 183 minecraft:stone_bricks
fill 403 -10 221 403 -9 221 minecraft:mossy_cobblestone
setblock 404 -10 182 minecraft:stone_bricks
fill 404 -10 183 404 -8 184 minecraft:mossy_cobblestone
setblock 404 -10 222 minecraft:stone_bricks
fill 405 -10 182 405 -7 182 minecraft:mossy_cobblestone
fill 405 -10 184 406 -10 184 minecraft:mossy_cobblestone
setblock 405 -10 221 minecraft:stone_bricks
fill 405 -10 222 405 -7 222 minecraft:mossy_cobblestone
fill 406 -10 221 406 -7 221 minecraft:mossy_cobblestone
setblock 407 -10 184 minecraft:stone_bricks
setblock 408 -10 183 minecraft:stone_bricks
fill 408 -10 184 408 -7 184 minecraft:mossy_cobblestone
setblock 409 -10 182 minecraft:stone_bricks
fill 409 -10 183 409 -7 183 minecraft:mossy_cobblestone
setblock 409 -10 222 minecraft:stone_bricks
fill 410 -10 182 410 -7 182 minecraft:mossy_cobblestone
fill 410 -10 184 410 -9 184 minecraft:mossy_cobblestone
setblock 410 -10 221 minecraft:stone_bricks
fill 410 -10 222 410 -7 222 minecraft:mossy_cobblestone
fill 411 -10 221 411 -7 221 minecraft:mossy_cobblestone
setblock 413 -10 183 minecraft:stone_bricks
setblock 414 -10 182 minecraft:stone_bricks
fill 414 -10 183 414 -7 183 minecraft:mossy_cobblestone
setblock 414 -10 222 minecraft:stone_bricks
fill 415 -10 182 415 -7 182 minecraft:mossy_cobblestone
setblock 415 -10 221 minecraft:stone_bricks
fill 415 -10 222 415 -7 222 minecraft:mossy_cobblestone
fill 416 -10 221 416 -7 221 minecraft:mossy_cobblestone
setblock 417 -10 184 minecraft:stone_bricks
setblock 417 -10 219 minecraft:stone_bricks
fill 417 -10 220 417 -7 220 minecraft:mossy_cobblestone
setblock 377 -9 182 minecraft:mossy_cobblestone
fill 377 -9 200 377 -9 202 minecraft:mossy_cobblestone
setblock 377 -9 203 minecraft:stone_bricks
fill 377 -9 204 377 -9 207 minecraft:mossy_cobblestone
fill 377 -9 215 377 -7 215 minecraft:mossy_cobblestone
setblock 377 -9 218 minecraft:stone_bricks
fill 377 -9 219 377 -6 219 minecraft:mossy_cobblestone
setblock 378 -9 182 minecraft:stone_bricks
fill 378 -9 218 378 -6 218 minecraft:mossy_cobblestone
setblock 378 -9 221 minecraft:mossy_cobblestone
setblock 378 -9 222 minecraft:stone_bricks
fill 379 -9 182 382 -9 182 minecraft:mossy_cobblestone
setblock 379 -9 221 minecraft:stone_bricks
fill 379 -9 222 379 -6 222 minecraft:mossy_cobblestone
fill 380 -9 221 380 -6 221 minecraft:mossy_cobblestone
fill 381 -9 220 381 -6 220 minecraft:mossy_cobblestone
setblock 383 -9 182 minecraft:stone_bricks
fill 383 -9 183 386 -9 183 minecraft:mossy_cobblestone
setblock 383 -9 222 minecraft:stone_bricks
fill 384 -9 182 384 -6 182 minecraft:mossy_cobblestone
setblock 384 -9 221 minecraft:stone_bricks
fill 384 -9 222 384 -6 222 minecraft:mossy_cobblestone
setblock 385 -9 220 minecraft:stone_bricks
fill 385 -9 221 385 -6 221 minecraft:mossy_cobblestone
fill 386 -9 220 386 -8 220 minecraft:mossy_cobblestone
setblock 387 -9 183 minecraft:stone_bricks
setblock 388 -9 182 minecraft:stone_bricks
fill 388 -9 183 388 -6 183 minecraft:mossy_cobblestone
setblock 388 -9 222 minecraft:stone_bricks
fill 389 -9 182 389 -6 182 minecraft:mossy_cobblestone
setblock 389 -9 221 minecraft:stone_bricks
fill 389 -9 222 389 -6 222 minecraft:mossy_cobblestone
setblock 390 -9 221 minecraft:mossy_cobblestone
setblock 392 -9 182 minecraft:mossy_cobblestone
setblock 393 -9 182 minecraft:stone_bricks
fill 396 -9 182 397 -9 182 minecraft:mossy_cobblestone
setblock 398 -9 182 minecraft:stone_bricks
fill 399 -9 182 399 -6 182 minecraft:mossy_cobblestone
fill 399 -9 222 402 -9 222 minecraft:mossy_cobblestone
fill 400 -9 183 401 -9 183 minecraft:mossy_cobblestone
setblock 402 -9 183 minecraft:stone_bricks
fill 402 -9 184 403 -7 184 minecraft:mossy_cobblestone
fill 402 -9 221 402 -8 221 minecraft:mossy_cobblestone
setblock 403 -9 182 minecraft:stone_bricks
fill 403 -9 183 403 -6 183 minecraft:mossy_cobblestone
setblock 403 -9 222 minecraft:stone_bricks
fill 404 -9 182 404 -6 182 minecraft:mossy_cobblestone
setblock 404 -9 221 minecraft:stone_bricks
fill 404 -9 222 404 -6 222 minecraft:mossy_cobblestone
setblock 405 -9 184 minecraft:mossy_cobblestone
fill 405 -9 221 405 -6 221 minecraft:mossy_cobblestone
setblock 406 -9 184 minecraft:stone_bricks
setblock 407 -9 183 minecraft:stone_bricks
fill 407 -9 184 407 -6 184 minecraft:mossy_cobblestone
fill 407 -9 220 407 -8 220 minecraft:mossy_cobblestone
setblock 408 -9 182 minecraft:stone_bricks
fill 408 -9 183 408 -6 183 minecraft:mossy_cobblestone
setblock 408 -9 222 minecraft:stone_bricks
fill 409 -9 182 409 -6 182 minecraft:mossy_cobblestone
setblock 409 -9 221 minecraft:stone_bricks
fill 409 -9 222 409 -6 222 minecraft:mossy_cobblestone
fill 410 -9 221 410 -6 221 minecraft:mossy_cobblestone
setblock 411 -9 184 minecraft:stone_bricks
setblock 412 -9 183 minecraft:stone_bricks
setblock 413 -9 182 minecraft:stone_bricks
fill 413 -9 183 413 -6 183 minecraft:mossy_cobblestone
setblock 413 -9 222 minecraft:stone_bricks
fill 414 -9 182 414 -6 182 minecraft:mossy_cobblestone
setblock 414 -9 221 minecraft:stone_bricks
fill 414 -9 222 414 -6 222 minecraft:mossy_cobblestone
fill 415 -9 183 416 -9 183 minecraft:mossy_cobblestone
fill 415 -9 221 415 -6 221 minecraft:mossy_cobblestone
fill 416 -9 220 416 -6 220 minecraft:mossy_cobblestone
setblock 417 -9 183 minecraft:stone_bricks
fill 417 -9 184 417 -7 185 minecraft:mossy_cobblestone
setblock 417 -9 217 minecraft:mossy_cobblestone
setblock 417 -9 218 minecraft:stone_bricks
fill 417 -9 219 417 -6 219 minecraft:mossy_cobblestone
setblock 377 -8 182 minecraft:stone_bricks
fill 377 -8 183 377 -6 184 minecraft:mossy_cobblestone
fill 377 -8 199 377 -8 201 minecraft:mossy_cobblestone
setblock 377 -8 202 minecraft:stone_bricks
fill 377 -8 203 377 -8 206 minecraft:mossy_cobblestone
setblock 377 -8 207 minecraft:stone_bricks
fill 377 -8 208 377 -8 211 minecraft:mossy_cobblestone
setblock 377 -8 212 minecraft:stone_bricks
fill 377 -8 213 377 -6 214 minecraft:mossy_cobblestone
setblock 377 -8 217 minecraft:stone_bricks
fill 377 -8 218 377 -5 218 minecraft:mossy_cobblestone
setblock 377 -8 222 minecraft:stone_bricks
fill 378 -8 182 381 -8 182 minecraft:mossy_cobblestone
setblock 378 -8 201 minecraft:stone_bricks
fill 378 -8 202 378 -8 205 minecraft:mossy_cobblestone
setblock 378 -8 206 minecraft:stone_bricks
fill 378 -8 207 378 -5 207 minecraft:mossy_cobblestone
setblock 378 -8 221 minecraft:stone_bricks
fill 378 -8 222 378 -5 222 minecraft:mossy_cobblestone
fill 379 -8 218 379 -1 218 minecraft:spruce_log
fill 379 -8 221 379 -5 221 minecraft:mossy_cobblestone
fill 380 -8 220 380 -6 220 minecraft:mossy_cobblestone
setblock 381 -8 183 minecraft:stone_bricks
setblock 382 -8 182 minecraft:stone_bricks
fill 382 -8 183 385 -8 183 minecraft:mossy_cobblestone
setblock 382 -8 222 minecraft:stone_bricks
fill 383 -8 182 383 -5 182 minecraft:mossy_cobblestone
setblock 383 -8 221 minecraft:stone_bricks
fill 383 -8 222 383 -5 222 minecraft:mossy_cobblestone
setblock 384 -8 220 minecraft:stone_bricks
fill 384 -8 221 384 -5 221 minecraft:mossy_cobblestone
fill 385 -8 220 385 -7 220 minecraft:mossy_cobblestone
setblock 386 -8 183 minecraft:stone_bricks
setblock 387 -8 182 minecraft:stone_bricks
fill 387 -8 183 387 -5 183 minecraft:mossy_cobblestone
setblock 387 -8 222 minecraft:stone_bricks
fill 388 -8 182 388 -5 182 minecraft:mossy_cobblestone
setblock 388 -8 221 minecraft:stone_bricks
fill 388 -8 222 388 -5 222 minecraft:mossy_cobblestone
fill 389 -8 183 389 -7 183 minecraft:mossy_cobblestone
setblock 389 -8 221 minecraft:mossy_cobblestone
setblock 392 -8 182 minecraft:stone_bricks
setblock 392 -8 222 minecraft:stone_bricks
fill 393 -8 182 396 -8 182 minecraft:mossy_cobblestone
setblock 397 -8 182 minecraft:stone_bricks
fill 398 -8 182 398 -6 183 minecraft:mossy_cobblestone
fill 398 -8 222 401 -8 222 minecraft:mossy_cobblestone
fill 399 -8 183 400 -8 183 minecraft:mossy_cobblestone
setblock 401 -8 183 minecraft:stone_bricks
fill 401 -8 184 401 -5 184 minecraft:mossy_cobblestone
fill 401 -8 221 401 -7 221 minecraft:mossy_cobblestone
setblock 402 -8 182 minecraft:stone_bricks
fill 402 -8 183 402 -5 183 minecraft:mossy_cobblestone
setblock 402 -8 222 minecraft:stone_bricks
fill 403 -8 182 403 -5 182 minecraft:mossy_cobblestone
setblock 403 -8 221 minecraft:stone_bricks
fill 403 -8 222 403 -5 222 minecraft:mossy_cobblestone
setblock 404 -8 185 minecraft:stone_bricks
fill 404 -8 221 404 -5 221 minecraft:mossy_cobblestone
setblock 405 -8 184 minecraft:stone_bricks
fill 405 -8 185 408 -8 185 minecraft:mossy_cobblestone
setblock 406 -8 183 minecraft:stone_bricks
fill 406 -8 184 406 -5 184 minecraft:mossy_cobblestone
fill 406 -8 220 406 -7 220 minecraft:mossy_cobblestone
setblock 407 -8 182 minecraft:stone_bricks
fill 407 -8 183 407 -5 183 minecraft:mossy_cobblestone
setblock 407 -8 222 minecraft:stone_bricks
fill 408 -8 182 408 -5 182 minecraft:mossy_cobblestone
setblock 408 -8 221 minecraft:stone_bricks
fill 408 -8 222 408 -5 222 minecraft:mossy_cobblestone
fill 409 -8 221 409 -5 221 minecraft:mossy_cobblestone
setblock 410 -8 184 minecraft:stone_bricks
setblock 411 -8 183 minecraft:stone_bricks
fill 411 -8 184 411 -5 184 minecraft:mossy_cobblestone
setblock 412 -8 182 minecraft:stone_bricks
fill 412 -8 183 412 -5 183 minecraft:mossy_cobblestone
setblock 412 -8 222 minecraft:stone_bricks
fill 413 -8 182 413 -5 182 minecraft:mossy_cobblestone
setblock 413 -8 221 minecraft:stone_bricks
fill 413 -8 222 413 -5 222 minecraft:mossy_cobblestone
fill 414 -8 221 414 -5 221 minecraft:mossy_cobblestone
setblock 415 -8 183 minecraft:mossy_cobblestone
setblock 416 -8 183 minecraft:stone_bricks
fill 416 -8 184 416 -5 184 minecraft:mossy_cobblestone
setblock 417 -8 182 minecraft:stone_bricks
fill 417 -8 183 417 -5 183 minecraft:mossy_cobblestone
setblock 417 -8 186 minecraft:mossy_cobblestone
setblock 417 -8 202 minecraft:stone_bricks
fill 417 -8 203 417 -5 203 minecraft:mossy_cobblestone
setblock 417 -8 217 minecraft:stone_bricks
fill 417 -8 218 417 -5 218 minecraft:mossy_cobblestone
setblock 417 -8 222 minecraft:stone_bricks
fill 377 -7 182 380 -7 182 minecraft:mossy_cobblestone
setblock 377 -7 185 minecraft:mossy_cobblestone
fill 377 -7 199 377 -7 200 minecraft:mossy_cobblestone
setblock 377 -7 201 minecraft:stone_bricks
fill 377 -7 202 377 -7 205 minecraft:mossy_cobblestone
setblock 377 -7 206 minecraft:stone_bricks
fill 377 -7 207 377 -7 210 minecraft:mossy_cobblestone
setblock 377 -7 211 minecraft:stone_bricks
fill 377 -7 212 377 -4 212 minecraft:mossy_cobblestone
setblock 377 -7 216 minecraft:stone_bricks
fill 377 -7 217 377 -4 217 minecraft:mossy_cobblestone
setblock 377 -7 220 minecraft:mossy_cobblestone
setblock 377 -7 221 minecraft:stone_bricks
fill 377 -7 222 377 -4 222 minecraft:mossy_cobblestone
setblock 378 -7 200 minecraft:stone_bricks
fill 378 -7 201 378 -7 204 minecraft:mossy_cobblestone
setblock 378 -7 205 minecraft:stone_bricks
fill 378 -7 206 379 -5 206 minecraft:mossy_cobblestone
fill 378 -7 208 378 -7 209 minecraft:mossy_cobblestone
setblock 378 -7 210 minecraft:stone_bricks
setblock 378 -7 220 minecraft:stone_bricks
fill 378 -7 221 378 -4 221 minecraft:mossy_cobblestone
setblock 379 -7 183 minecraft:mossy_cobblestone
setblock 379 -7 184 minecraft:light[level=12]
setblock 379 -7 192 minecraft:light[level=12]
setblock 379 -7 200 minecraft:light[level=12]
fill 379 -7 202 379 -7 203 minecraft:mossy_cobblestone
setblock 379 -7 204 minecraft:stone_bricks
fill 379 -7 205 379 -4 205 minecraft:mossy_cobblestone
fill 379 -7 207 379 -6 207 minecraft:mossy_cobblestone
setblock 379 -7 208 minecraft:light[level=12]
setblock 379 -7 216 minecraft:light[level=12]
setblock 380 -7 183 minecraft:stone_bricks
setblock 381 -7 182 minecraft:stone_bricks
fill 381 -7 183 384 -7 183 minecraft:mossy_cobblestone
setblock 381 -7 222 minecraft:stone_bricks
fill 382 -7 182 382 -4 182 minecraft:mossy_cobblestone
setblock 382 -7 221 minecraft:stone_bricks
fill 382 -7 222 382 -4 222 minecraft:mossy_cobblestone
setblock 383 -7 220 minecraft:stone_bricks
fill 383 -7 221 383 -4 221 minecraft:mossy_cobblestone
fill 384 -7 220 384 -6 220 minecraft:mossy_cobblestone
setblock 385 -7 183 minecraft:stone_bricks
setblock 386 -7 182 minecraft:stone_bricks
fill 386 -7 183 386 -4 183 minecraft:mossy_cobblestone
setblock 386 -7 222 minecraft:stone_bricks
fill 387 -7 182 387 -4 182 minecraft:mossy_cobblestone
setblock 387 -7 184 minecraft:light[level=12]
setblock 387 -7 192 minecraft:light[level=12]
setblock 387 -7 200 minecraft:light[level=12]
setblock 387 -7 208 minecraft:light[level=12]
setblock 387 -7 216 minecraft:light[level=12]
setblock 387 -7 221 minecraft:stone_bricks
fill 387 -7 222 387 -4 222 minecraft:mossy_cobblestone
fill 388 -7 221 388 -6 221 minecraft:mossy_cobblestone
setblock 390 -7 182 minecraft:mossy_cobblestone
setblock 391 -7 182 minecraft:stone_bricks
setblock 391 -7 222 minecraft:stone_bricks
fill 392 -7 182 395 -7 182 minecraft:mossy_cobblestone
setblock 392 -7 222 minecraft:mossy_cobblestone
setblock 395 -7 184 minecraft:light[level=12]
setblock 395 -7 192 minecraft:light[level=12]
setblock 395 -7 200 minecraft:light[level=12]
setblock 395 -7 208 minecraft:light[level=12]
setblock 395 -7 216 minecraft:light[level=12]
setblock 396 -7 182 minecraft:stone_bricks
fill 397 -7 182 397 -5 183 minecraft:mossy_cobblestone
fill 397 -7 222 400 -7 222 minecraft:mossy_cobblestone
setblock 399 -7 183 minecraft:mossy_cobblestone
setblock 399 -7 184 minecraft:stone_bricks
setblock 400 -7 183 minecraft:stone_bricks
fill 400 -7 184 400 -4 184 minecraft:mossy_cobblestone
setblock 401 -7 182 minecraft:stone_bricks
fill 401 -7 183 401 -4 183 minecraft:mossy_cobblestone
setblock 401 -7 222 minecraft:stone_bricks
fill 402 -7 182 402 -4 182 minecraft:mossy_cobblestone
setblock 402 -7 185 minecraft:mossy_cobblestone
setblock 402 -7 221 minecraft:stone_bricks
fill 402 -7 222 402 -4 222 minecraft:mossy_cobblestone
setblock 403 -7 185 minecraft:stone_bricks
setblock 403 -7 192 minecraft:light[level=12]
setblock 403 -7 200 minecraft:light[level=12]
setblock 403 -7 208 minecraft:light[level=12]
setblock 403 -7 216 minecraft:light[level=12]
fill 403 -7 221 403 -4 221 minecraft:mossy_cobblestone
setblock 404 -7 183 minecraft:mossy_cobblestone
setblock 404 -7 184 minecraft:stone_bricks
fill 404 -7 185 407 -7 185 minecraft:mossy_cobblestone
setblock 405 -7 183 minecraft:stone_bricks
fill 405 -7 184 405 -4 184 minecraft:mossy_cobblestone
setblock 406 -7 182 minecraft:stone_bricks
fill 406 -7 183 406 -4 183 minecraft:mossy_cobblestone
setblock 406 -7 222 minecraft:stone_bricks
fill 407 -7 182 407 -4 182 minecraft:mossy_cobblestone
setblock 407 -7 221 minecraft:stone_bricks
fill 407 -7 222 407 -4 222 minecraft:mossy_cobblestone
setblock 408 -7 185 minecraft:stone_bricks
fill 408 -7 221 408 -4 221 minecraft:mossy_cobblestone
setblock 409 -7 184 minecraft:stone_bricks
setblock 410 -7 183 minecraft:stone_bricks
fill 410 -7 184 410 -4 184 minecraft:mossy_cobblestone
setblock 411 -7 182 minecraft:stone_bricks
fill 411 -7 183 411 -4 183 minecraft:mossy_cobblestone
setblock 411 -7 192 minecraft:light[level=12]
setblock 411 -7 200 minecraft:light[level=12]
setblock 411 -7 208 minecraft:light[level=12]
setblock 411 -7 216 minecraft:light[level=12]
setblock 411 -7 222 minecraft:stone_bricks
fill 412 -7 182 412 -4 182 minecraft:mossy_cobblestone
fill 412 -7 184 412 -6 184 minecraft:mossy_cobblestone
setblock 412 -7 221 minecraft:stone_bricks
fill 412 -7 222 412 -4 222 minecraft:mossy_cobblestone
fill 413 -7 221 413 -5 221 minecraft:mossy_cobblestone
setblock 415 -7 183 minecraft:stone_bricks
setblock 416 -7 182 minecraft:stone_bricks
fill 416 -7 183 416 -4 183 minecraft:mossy_cobblestone
setblock 416 -7 222 minecraft:stone_bricks
fill 417 -7 182 417 -4 182 minecraft:mossy_cobblestone
setblock 417 -7 186 minecraft:stone_bricks
fill 417 -7 187 417 -4 187 minecraft:mossy_cobblestone
setblock 417 -7 201 minecraft:stone_bricks
fill 417 -7 202 417 -4 202 minecraft:mossy_cobblestone
fill 417 -7 204 417 -7 205 minecraft:mossy_cobblestone
setblock 417 -7 206 minecraft:stone_bricks
fill 417 -7 207 417 -4 207 minecraft:mossy_cobblestone
setblock 417 -7 216 minecraft:stone_bricks
fill 417 -7 217 417 -4 217 minecraft:mossy_cobblestone
setblock 417 -7 221 minecraft:stone_bricks
fill 417 -7 222 417 -4 222 minecraft:mossy_cobblestone
fill 377 -6 182 379 -6 182 minecraft:mossy_cobblestone
setblock 377 -6 185 minecraft:stone_bricks
fill 377 -6 186 377 -3 186 minecraft:mossy_cobblestone
setblock 377 -6 199 minecraft:mossy_cobblestone
setblock 377 -6 200 minecraft:stone_bricks
fill 377 -6 201 377 -6 204 minecraft:mossy_cobblestone
setblock 377 -6 205 minecraft:stone_bricks
fill 377 -6 206 377 -6 209 minecraft:mossy_cobblestone
setblock 377 -6 210 minecraft:stone_bricks
fill 377 -6 211 378 -4 211 minecraft:mossy_cobblestone
setblock 377 -6 215 minecraft:stone_bricks
fill 377 -6 216 377 -3 216 minecraft:mossy_cobblestone
setblock 377 -6 220 minecraft:stone_bricks
fill 377 -6 221 377 -3 221 minecraft:mossy_cobblestone
setblock 378 -6 183 minecraft:mossy_cobblestone
fill 378 -6 200 378 -6 203 minecraft:mossy_cobblestone
setblock 378 -6 204 minecraft:stone_bricks
fill 378 -6 205 378 -3 205 minecraft:mossy_cobblestone
setblock 378 -6 208 minecraft:mossy_cobblestone
setblock 378 -6 209 minecraft:stone_bricks
fill 378 -6 210 379 -4 210 minecraft:mossy_cobblestone
fill 378 -6 212 378 -6 213 minecraft:mossy_cobblestone
fill 378 -6 217 378 -5 217 minecraft:mossy_cobblestone
setblock 378 -6 219 minecraft:stone_bricks
fill 378 -6 220 378 -4 220 minecraft:mossy_cobblestone
setblock 379 -6 183 minecraft:stone_bricks
fill 379 -6 201 379 -6 202 minecraft:mossy_cobblestone
setblock 379 -6 203 minecraft:stone_bricks
fill 379 -6 204 380 -4 204 minecraft:mossy_cobblestone
setblock 379 -6 208 minecraft:stone_bricks
fill 379 -6 209 379 -3 209 minecraft:mossy_cobblestone
setblock 380 -6 182 minecraft:stone_bricks
fill 380 -6 183 383 -6 183 minecraft:mossy_cobblestone
fill 380 -6 203 380 -3 203 minecraft:mossy_cobblestone
fill 380 -6 205 380 -6 206 minecraft:mossy_cobblestone
setblock 380 -6 207 minecraft:stone_bricks
setblock 380 -6 222 minecraft:stone_bricks
fill 381 -6 182 381 -3 182 minecraft:mossy_cobblestone
setblock 381 -6 221 minecraft:stone_bricks
fill 381 -6 222 381 -3 222 minecraft:mossy_cobblestone
setblock 382 -6 220 minecraft:stone_bricks
fill 382 -6 221 382 -3 221 minecraft:mossy_cobblestone
setblock 383 -6 184 minecraft:stone_bricks
setblock 383 -6 220 minecraft:mossy_cobblestone
setblock 384 -6 183 minecraft:stone_bricks
fill 384 -6 184 385 -5 184 minecraft:mossy_cobblestone
setblock 385 -6 182 minecraft:stone_bricks
fill 385 -6 183 385 -3 183 minecraft:mossy_cobblestone
setblock 385 -6 222 minecraft:stone_bricks
fill 386 -6 182 386 -3 182 minecraft:mossy_cobblestone
setblock 386 -6 221 minecraft:stone_bricks
fill 386 -6 222 386 -3 222 minecraft:mossy_cobblestone
setblock 387 -6 221 minecraft:mossy_cobblestone
setblock 389 -6 183 minecraft:stone_bricks
setblock 390 -6 182 minecraft:stone_bricks
setblock 390 -6 183 minecraft:mossy_cobblestone
setblock 390 -6 222 minecraft:stone_bricks
fill 391 -6 182 394 -6 182 minecraft:mossy_cobblestone
setblock 391 -6 222 minecraft:mossy_cobblestone
setblock 395 -6 182 minecraft:stone_bricks
fill 395 -6 183 396 -4 183 minecraft:mossy_cobblestone
fill 396 -6 182 396 -3 182 minecraft:mossy_cobblestone
fill 397 -6 222 399 -6 222 minecraft:mossy_cobblestone
setblock 398 -6 184 minecraft:stone_bricks
setblock 399 -6 183 minecraft:stone_bricks
fill 399 -6 184 399 -3 184 minecraft:mossy_cobblestone
setblock 400 -6 182 minecraft:stone_bricks
fill 400 -6 183 400 -3 183 minecraft:mossy_cobblestone
setblock 400 -6 221 minecraft:mossy_cobblestone
setblock 400 -6 222 minecraft:stone_bricks
fill 401 -6 182 401 -3 182 minecraft:mossy_cobblestone
setblock 401 -6 185 minecraft:mossy_cobblestone
setblock 401 -6 221 minecraft:stone_bricks
fill 401 -6 222 401 -3 222 minecraft:mossy_cobblestone
setblock 402 -6 184 minecraft:mossy_cobblestone
setblock 402 -6 185 minecraft:stone_bricks
fill 402 -6 221 402 -3 221 minecraft:mossy_cobblestone
setblock 403 -6 184 minecraft:stone_bricks
fill 403 -6 185 406 -6 185 minecraft:mossy_cobblestone
setblock 404 -6 183 minecraft:stone_bricks
fill 404 -6 184 404 -3 184 minecraft:mossy_cobblestone
setblock 405 -6 182 minecraft:stone_bricks
fill 405 -6 183 405 -3 183 minecraft:mossy_cobblestone
setblock 405 -6 222 minecraft:stone_bricks
fill 406 -6 182 406 -3 182 minecraft:mossy_cobblestone
setblock 406 -6 221 minecraft:stone_bricks
fill 406 -6 222 406 -3 222 minecraft:mossy_cobblestone
setblock 407 -6 185 minecraft:stone_bricks
fill 407 -6 221 407 -3 221 minecraft:mossy_cobblestone
setblock 408 -6 184 minecraft:stone_bricks
fill 408 -6 185 408 -4 185 minecraft:mossy_cobblestone
setblock 409 -6 183 minecraft:stone_bricks
fill 409 -6 184 409 -3 184 minecraft:mossy_cobblestone
setblock 410 -6 182 minecraft:stone_bricks
fill 410 -6 183 410 -3 183 minecraft:mossy_cobblestone
setblock 410 -6 222 minecraft:stone_bricks
fill 411 -6 182 411 -3 182 minecraft:mossy_cobblestone
setblock 411 -6 221 minecraft:stone_bricks
fill 411 -6 222 411 -3 222 minecraft:mossy_cobblestone
fill 412 -6 221 412 -5 221 minecraft:mossy_cobblestone
setblock 414 -6 183 minecraft:stone_bricks
setblock 415 -6 182 minecraft:stone_bricks
fill 415 -6 183 415 -3 183 minecraft:mossy_cobblestone
setblock 415 -6 222 minecraft:stone_bricks
fill 416 -6 182 416 -3 182 minecraft:mossy_cobblestone
setblock 416 -6 185 minecraft:mossy_cobblestone
setblock 416 -6 221 minecraft:stone_bricks
fill 416 -6 222 416 -3 222 minecraft:mossy_cobblestone
setblock 417 -6 184 minecraft:mossy_cobblestone
setblock 417 -6 185 minecraft:stone_bricks
fill 417 -6 186 417 -3 186 minecraft:mossy_cobblestone
fill 417 -6 201 417 -4 201 minecraft:mossy_cobblestone
setblock 417 -6 204 minecraft:mossy_cobblestone
setblock 417 -6 205 minecraft:stone_bricks
fill 417 -6 206 417 -3 206 minecraft:mossy_cobblestone
fill 417 -6 208 417 -6 209 minecraft:mossy_cobblestone
setblock 417 -6 210 minecraft:stone_bricks
fill 417 -6 216 417 -3 216 minecraft:mossy_cobblestone
setblock 417 -6 220 minecraft:stone_bricks
fill 417 -6 221 417 -3 221 minecraft:mossy_cobblestone
fill 377 -5 182 377 -5 183 minecraft:mossy_cobblestone
setblock 377 -5 184 minecraft:stone_bricks
fill 377 -5 185 377 -2 185 minecraft:mossy_cobblestone
fill 377 -5 187 377 -4 187 minecraft:mossy_cobblestone
setblock 377 -5 199 minecraft:stone_bricks
fill 377 -5 200 377 -5 203 minecraft:mossy_cobblestone
setblock 377 -5 204 minecraft:stone_bricks
fill 377 -5 205 377 -5 208 minecraft:mossy_cobblestone
setblock 377 -5 209 minecraft:stone_bricks
fill 377 -5 210 377 -2 210 minecraft:mossy_cobblestone
setblock 377 -5 213 minecraft:mossy_cobblestone
setblock 377 -5 214 minecraft:stone_bricks
fill 377 -5 215 377 -2 215 minecraft:mossy_cobblestone
setblock 377 -5 219 minecraft:stone_bricks
fill 377 -5 220 377 -2 220 minecraft:mossy_cobblestone
setblock 378 -5 182 minecraft:mossy_cobblestone
setblock 378 -5 183 minecraft:stone_bricks
fill 378 -5 184 378 -2 184 minecraft:mossy_cobblestone
fill 378 -5 200 378 -5 202 minecraft:mossy_cobblestone
setblock 378 -5 203 minecraft:stone_bricks
fill 378 -5 204 378 -2 204 minecraft:mossy_cobblestone
setblock 378 -5 208 minecraft:stone_bricks
fill 378 -5 209 378 -2 209 minecraft:mossy_cobblestone
setblock 378 -5 212 minecraft:mossy_cobblestone
setblock 378 -5 213 minecraft:stone_bricks
fill 378 -5 214 378 -2 214 minecraft:mossy_cobblestone
setblock 378 -5 218 minecraft:stone_bricks
fill 378 -5 219 378 -4 219 minecraft:mossy_cobblestone
setblock 379 -5 182 minecraft:stone_bricks
fill 379 -5 183 382 -5 183 minecraft:mossy_cobblestone
setblock 379 -5 201 minecraft:mossy_cobblestone
setblock 379 -5 202 minecraft:stone_bricks
fill 379 -5 203 379 -2 203 minecraft:mossy_cobblestone
setblock 379 -5 207 minecraft:stone_bricks
fill 379 -5 208 380 -3 208 minecraft:mossy_cobblestone
setblock 379 -5 211 minecraft:mossy_cobblestone
setblock 379 -5 222 minecraft:stone_bricks
fill 380 -5 182 380 -2 182 minecraft:mossy_cobblestone
fill 380 -5 202 380 -4 202 minecraft:mossy_cobblestone
setblock 380 -5 205 minecraft:mossy_cobblestone
setblock 380 -5 206 minecraft:stone_bricks
fill 380 -5 207 380 -2 207 minecraft:mossy_cobblestone
fill 380 -5 209 380 -4 209 minecraft:mossy_cobblestone
setblock 380 -5 221 minecraft:stone_bricks
fill 380 -5 222 380 -2 222 minecraft:mossy_cobblestone
fill 381 -5 221 381 -3 221 minecraft:mossy_cobblestone
setblock 382 -5 184 minecraft:stone_bricks
setblock 382 -5 220 minecraft:mossy_cobblestone
setblock 383 -5 183 minecraft:stone_bricks
fill 383 -5 184 383 -4 184 minecraft:mossy_cobblestone
setblock 384 -5 182 minecraft:stone_bricks
fill 384 -5 183 384 -2 183 minecraft:mossy_cobblestone
setblock 384 -5 222 minecraft:stone_bricks
fill 385 -5 182 385 -2 182 minecraft:mossy_cobblestone
setblock 385 -5 221 minecraft:stone_bricks
fill 385 -5 222 385 -2 222 minecraft:mossy_cobblestone
setblock 386 -5 221 minecraft:mossy_cobblestone
setblock 388 -5 183 minecraft:stone_bricks
setblock 389 -5 182 minecraft:stone_bricks
setblock 389 -5 183 minecraft:mossy_cobblestone
setblock 389 -5 222 minecraft:stone_bricks
fill 390 -5 182 393 -5 182 minecraft:mossy_cobblestone
setblock 394 -5 182 minecraft:stone_bricks
fill 395 -5 182 395 -2 182 minecraft:mossy_cobblestone
setblock 397 -5 184 minecraft:stone_bricks
fill 397 -5 222 398 -5 222 minecraft:mossy_cobblestone
setblock 398 -5 182 minecraft:mossy_cobblestone
setblock 398 -5 183 minecraft:stone_bricks
fill 398 -5 184 398 -2 184 minecraft:mossy_cobblestone
setblock 399 -5 182 minecraft:stone_bricks
fill 399 -5 183 399 -2 183 minecraft:mossy_cobblestone
setblock 399 -5 222 minecraft:stone_bricks
fill 400 -5 182 400 -2 182 minecraft:mossy_cobblestone
setblock 400 -5 185 minecraft:mossy_cobblestone
setblock 400 -5 221 minecraft:stone_bricks
fill 400 -5 222 400 -2 222 minecraft:mossy_cobblestone
setblock 401 -5 185 minecraft:stone_bricks
fill 401 -5 221 401 -3 221 minecraft:mossy_cobblestone
setblock 402 -5 184 minecraft:stone_bricks
fill 402 -5 185 405 -5 185 minecraft:mossy_cobblestone
setblock 403 -5 183 minecraft:stone_bricks
fill 403 -5 184 403 -2 184 minecraft:mossy_cobblestone
setblock 404 -5 182 minecraft:stone_bricks
fill 404 -5 183 404 -2 183 minecraft:mossy_cobblestone
setblock 404 -5 222 minecraft:stone_bricks
fill 405 -5 182 405 -2 182 minecraft:mossy_cobblestone
setblock 405 -5 221 minecraft:stone_bricks
fill 405 -5 222 405 -2 222 minecraft:mossy_cobblestone
setblock 406 -5 185 minecraft:stone_bricks
fill 406 -5 221 406 -3 221 minecraft:mossy_cobblestone
setblock 407 -5 184 minecraft:stone_bricks
fill 407 -5 185 407 -3 185 minecraft:mossy_cobblestone
setblock 408 -5 183 minecraft:stone_bricks
fill 408 -5 184 408 -2 184 minecraft:mossy_cobblestone
setblock 409 -5 182 minecraft:stone_bricks
fill 409 -5 183 409 -2 183 minecraft:mossy_cobblestone
setblock 409 -5 222 minecraft:stone_bricks
fill 410 -5 182 410 -2 182 minecraft:mossy_cobblestone
setblock 410 -5 221 minecraft:stone_bricks
fill 410 -5 222 410 -2 222 minecraft:mossy_cobblestone
setblock 411 -5 221 minecraft:mossy_cobblestone
setblock 412 -5 184 minecraft:stone_bricks
setblock 413 -5 183 minecraft:stone_bricks
setblock 414 -5 182 minecraft:stone_bricks
fill 414 -5 183 414 -2 183 minecraft:mossy_cobblestone
setblock 414 -5 222 minecraft:stone_bricks
fill 415 -5 182 415 -2 182 minecraft:mossy_cobblestone
setblock 415 -5 221 minecraft:stone_bricks
fill 415 -5 222 415 -2 222 minecraft:mossy_cobblestone
setblock 416 -5 185 minecraft:stone_bricks
fill 416 -5 186 416 -2 186 minecraft:mossy_cobblestone
setblock 416 -5 220 minecraft:stone_bricks
fill 416 -5 221 416 -3 221 minecraft:mossy_cobblestone
setblock 417 -5 184 minecraft:stone_bricks
fill 417 -5 185 417 -2 185 minecraft:mossy_cobblestone
setblock 417 -5 188 minecraft:mossy_cobblestone
setblock 417 -5 204 minecraft:stone_bricks
fill 417 -5 205 417 -2 205 minecraft:mossy_cobblestone
setblock 417 -5 208 minecraft:mossy_cobblestone
setblock 417 -5 209 minecraft:stone_bricks
fill 417 -5 210 417 -5 213 minecraft:mossy_cobblestone
setblock 417 -5 214 minecraft:stone_bricks
fill 417 -5 215 417 -2 215 minecraft:mossy_cobblestone
setblock 417 -5 219 minecraft:stone_bricks
fill 417 -5 220 417 -2 220 minecraft:mossy_cobblestone
setblock 377 -4 182 minecraft:mossy_cobblestone
setblock 377 -4 183 minecraft:stone_bricks
fill 377 -4 184 377 -1 184 minecraft:mossy_cobblestone
fill 377 -4 199 377 -4 202 minecraft:mossy_cobblestone
setblock 377 -4 203 minecraft:stone_bricks
fill 377 -4 204 377 -4 207 minecraft:mossy_cobblestone
setblock 377 -4 208 minecraft:stone_bricks
fill 377 -4 209 377 -1 209 minecraft:mossy_cobblestone
setblock 377 -4 213 minecraft:stone_bricks
fill 377 -4 214 377 -1 214 minecraft:mossy_cobblestone
setblock 377 -4 218 minecraft:stone_bricks
fill 377 -4 219 377 -1 219 minecraft:mossy_cobblestone
setblock 378 -4 182 minecraft:stone_bricks
fill 378 -4 183 381 -4 183 minecraft:mossy_cobblestone
fill 378 -4 185 378 -3 185 minecraft:mossy_cobblestone
fill 378 -4 200 378 -4 201 minecraft:mossy_cobblestone
setblock 378 -4 202 minecraft:stone_bricks
fill 378 -4 203 378 -1 203 minecraft:mossy_cobblestone
setblock 378 -4 206 minecraft:mossy_cobblestone
setblock 378 -4 207 minecraft:stone_bricks
fill 378 -4 208 378 -1 208 minecraft:mossy_cobblestone
setblock 378 -4 212 minecraft:stone_bricks
fill 378 -4 213 378 -1 213 minecraft:mossy_cobblestone
fill 378 -4 215 378 -3 215 minecraft:mossy_cobblestone
fill 378 -4 218 378 -2 218 minecraft:spruce_log
setblock 378 -4 222 minecraft:stone_bricks
fill 379 -4 182 379 -1 182 minecraft:mossy_cobblestone
schedule function dropper:buildpart/44_2 1t
