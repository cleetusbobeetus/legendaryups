setblock 144 223 615 minecraft:light[level=14]
setblock 144 223 623 minecraft:light[level=14]
setblock 144 223 631 minecraft:light[level=14]
setblock 144 223 639 minecraft:light[level=14]
setblock 152 223 607 minecraft:light[level=14]
setblock 152 223 615 minecraft:light[level=14]
setblock 152 223 623 minecraft:light[level=14]
setblock 152 223 631 minecraft:light[level=14]
setblock 152 223 639 minecraft:light[level=14]
fill 154 223 622 154 223 626 minecraft:waxed_oxidized_copper
fill 155 223 620 155 223 621 minecraft:waxed_oxidized_copper
fill 155 223 627 155 223 628 minecraft:waxed_oxidized_copper
setblock 156 223 619 minecraft:waxed_oxidized_copper
setblock 156 223 629 minecraft:waxed_oxidized_copper
fill 157 223 618 158 223 618 minecraft:waxed_oxidized_copper
fill 157 223 630 158 223 630 minecraft:waxed_oxidized_copper
fill 159 223 617 163 223 617 minecraft:waxed_oxidized_copper
setblock 159 223 622 minecraft:waxed_copper_block
setblock 159 223 626 minecraft:waxed_copper_block
fill 159 223 631 163 223 631 minecraft:waxed_oxidized_copper
setblock 160 223 607 minecraft:light[level=14]
setblock 160 223 615 minecraft:light[level=14]
setblock 160 223 639 minecraft:light[level=14]
setblock 163 223 622 minecraft:waxed_copper_block
setblock 163 223 626 minecraft:waxed_copper_block
fill 164 223 618 165 223 618 minecraft:waxed_oxidized_copper
fill 164 223 630 165 223 630 minecraft:waxed_oxidized_copper
setblock 166 223 619 minecraft:waxed_oxidized_copper
setblock 166 223 629 minecraft:waxed_oxidized_copper
fill 167 223 620 167 223 621 minecraft:waxed_oxidized_copper
fill 167 223 627 167 223 628 minecraft:waxed_oxidized_copper
setblock 168 223 607 minecraft:light[level=14]
setblock 168 223 615 minecraft:light[level=14]
fill 168 223 622 168 223 626 minecraft:waxed_oxidized_copper
setblock 168 223 631 minecraft:light[level=14]
setblock 168 223 639 minecraft:light[level=14]
setblock 176 223 607 minecraft:light[level=14]
setblock 176 223 615 minecraft:light[level=14]
setblock 176 223 623 minecraft:light[level=14]
setblock 176 223 631 minecraft:light[level=14]
setblock 176 223 639 minecraft:light[level=14]
fill 142 225 606 142 273 606 minecraft:iron_block
fill 142 225 609 142 225 612 minecraft:iron_block
fill 142 225 616 142 273 616 minecraft:iron_block
fill 142 225 619 142 225 622 minecraft:iron_block
fill 142 225 626 142 273 626 minecraft:iron_block
fill 142 225 629 142 225 632 minecraft:iron_block
fill 142 225 636 142 273 636 minecraft:iron_block
fill 142 225 639 142 225 642 minecraft:iron_block
fill 143 225 605 146 225 605 minecraft:iron_block
fill 143 225 645 143 273 645 minecraft:iron_block
fill 146 225 645 149 225 645 minecraft:iron_block
fill 149 225 605 149 273 605 minecraft:iron_block
fill 153 225 605 156 225 605 minecraft:iron_block
fill 153 225 645 153 273 645 minecraft:iron_block
fill 156 225 645 159 225 645 minecraft:iron_block
fill 159 225 605 159 273 605 minecraft:iron_block
fill 163 225 605 166 225 605 minecraft:iron_block
fill 163 225 645 163 273 645 minecraft:iron_block
fill 166 225 645 169 225 645 minecraft:iron_block
fill 169 225 605 169 273 605 minecraft:iron_block
fill 173 225 605 176 225 605 minecraft:iron_block
fill 173 225 645 173 273 645 minecraft:iron_block
fill 176 225 645 179 225 645 minecraft:iron_block
fill 178 225 627 178 273 627 minecraft:iron_block
fill 179 225 605 179 273 605 minecraft:iron_block
fill 182 225 606 182 225 609 minecraft:iron_block
fill 182 225 612 182 273 612 minecraft:iron_block
fill 182 225 616 182 225 619 minecraft:iron_block
fill 182 225 622 182 273 622 minecraft:iron_block
fill 182 225 626 182 225 629 minecraft:iron_block
fill 182 225 632 182 273 632 minecraft:iron_block
fill 182 225 636 182 225 639 minecraft:iron_block
fill 182 225 642 182 273 642 minecraft:iron_block
fill 146 227 624 148 228 624 minecraft:waxed_copper_block
fill 147 227 621 149 228 623 minecraft:waxed_copper_block
fill 147 227 625 149 228 627 minecraft:waxed_copper_block
fill 148 227 620 156 228 620 minecraft:waxed_copper_block
fill 148 227 628 156 228 628 minecraft:waxed_copper_block
fill 149 227 619 155 228 619 minecraft:waxed_copper_block
fill 149 227 629 155 228 629 minecraft:waxed_copper_block
fill 150 227 621 151 228 621 minecraft:waxed_copper_block
fill 150 227 627 151 228 627 minecraft:waxed_copper_block
fill 152 227 618 152 228 618 minecraft:waxed_copper_block
fill 152 227 630 152 228 630 minecraft:waxed_copper_block
fill 153 227 621 157 228 621 minecraft:waxed_copper_block
fill 153 227 627 157 228 627 minecraft:waxed_copper_block
fill 155 227 622 157 228 623 minecraft:waxed_copper_block
fill 155 227 625 157 228 626 minecraft:waxed_copper_block
fill 156 227 624 157 228 624 minecraft:waxed_copper_block
fill 177 227 626 177 227 628 minecraft:iron_block
fill 178 227 626 179 227 626 minecraft:iron_block
fill 178 227 628 179 227 628 minecraft:iron_block
setblock 179 227 627 minecraft:iron_block
setblock 142 228 607 minecraft:iron_block
setblock 142 228 617 minecraft:iron_block
setblock 142 228 627 minecraft:iron_block
setblock 142 228 637 minecraft:iron_block
setblock 144 228 645 minecraft:iron_block
setblock 148 228 605 minecraft:iron_block
setblock 154 228 645 minecraft:iron_block
setblock 158 228 605 minecraft:iron_block
setblock 164 228 645 minecraft:iron_block
fill 166 228 611 166 241 611 minecraft:iron_block
setblock 168 228 605 minecraft:iron_block
setblock 174 228 645 minecraft:iron_block
setblock 178 228 605 minecraft:iron_block
setblock 182 228 611 minecraft:iron_block
setblock 182 228 621 minecraft:iron_block
setblock 182 228 631 minecraft:iron_block
setblock 182 228 641 minecraft:iron_block
fill 141 229 610 141 229 613 minecraft:sea_lantern
fill 141 229 620 141 229 623 minecraft:sea_lantern
fill 141 229 630 141 229 633 minecraft:sea_lantern
fill 141 229 640 141 229 643 minecraft:sea_lantern
fill 144 229 604 147 229 604 minecraft:sea_lantern
fill 145 229 646 148 229 646 minecraft:sea_lantern
fill 154 229 604 157 229 604 minecraft:sea_lantern
fill 155 229 646 158 229 646 minecraft:sea_lantern
fill 164 229 604 167 229 604 minecraft:sea_lantern
fill 165 229 646 168 229 646 minecraft:sea_lantern
fill 174 229 604 177 229 604 minecraft:sea_lantern
fill 175 229 646 178 229 646 minecraft:sea_lantern
fill 183 229 605 183 229 608 minecraft:sea_lantern
fill 183 229 615 183 229 618 minecraft:sea_lantern
fill 183 229 625 183 229 628 minecraft:sea_lantern
fill 183 229 635 183 229 638 minecraft:sea_lantern
setblock 183 229 645 minecraft:sea_lantern
fill 141 230 610 141 237 613 minecraft:netherite_block
fill 141 230 620 141 237 623 minecraft:netherite_block
fill 141 230 630 141 237 633 minecraft:netherite_block
fill 141 230 640 141 237 643 minecraft:netherite_block
fill 144 230 604 147 237 604 minecraft:netherite_block
fill 145 230 646 148 237 646 minecraft:netherite_block
fill 154 230 604 157 237 604 minecraft:netherite_block
fill 155 230 646 158 237 646 minecraft:netherite_block
fill 164 230 604 167 237 604 minecraft:netherite_block
fill 165 230 646 168 237 646 minecraft:netherite_block
fill 174 230 604 177 237 604 minecraft:netherite_block
fill 175 230 646 178 237 646 minecraft:netherite_block
fill 183 230 605 183 237 608 minecraft:netherite_block
fill 183 230 615 183 237 618 minecraft:netherite_block
fill 183 230 625 183 237 628 minecraft:netherite_block
fill 183 230 635 183 237 638 minecraft:netherite_block
fill 183 230 645 183 237 645 minecraft:netherite_block
setblock 144 231 607 minecraft:light[level=14]
setblock 144 231 615 minecraft:light[level=14]
setblock 144 231 623 minecraft:light[level=14]
setblock 144 231 631 minecraft:light[level=14]
setblock 144 231 639 minecraft:light[level=14]
setblock 152 231 607 minecraft:light[level=14]
setblock 152 231 615 minecraft:light[level=14]
setblock 152 231 623 minecraft:light[level=14]
setblock 152 231 631 minecraft:light[level=14]
setblock 152 231 639 minecraft:light[level=14]
setblock 160 231 607 minecraft:light[level=14]
setblock 160 231 615 minecraft:light[level=14]
setblock 160 231 623 minecraft:light[level=14]
setblock 160 231 631 minecraft:light[level=14]
setblock 160 231 639 minecraft:light[level=14]
setblock 168 231 607 minecraft:light[level=14]
setblock 168 231 615 minecraft:light[level=14]
setblock 168 231 623 minecraft:light[level=14]
setblock 168 231 631 minecraft:light[level=14]
setblock 168 231 639 minecraft:light[level=14]
setblock 176 231 607 minecraft:light[level=14]
setblock 176 231 615 minecraft:light[level=14]
setblock 176 231 623 minecraft:light[level=14]
setblock 176 231 631 minecraft:light[level=14]
setblock 176 231 639 minecraft:light[level=14]
fill 177 232 626 177 232 628 minecraft:iron_block
fill 178 232 626 179 232 626 minecraft:iron_block
fill 178 232 628 179 232 628 minecraft:iron_block
setblock 179 232 627 minecraft:iron_block
setblock 142 234 607 minecraft:iron_block
fill 142 234 609 142 234 612 minecraft:iron_block
setblock 142 234 617 minecraft:iron_block
fill 142 234 619 142 234 622 minecraft:iron_block
setblock 142 234 627 minecraft:iron_block
fill 142 234 629 142 234 632 minecraft:iron_block
setblock 142 234 637 minecraft:iron_block
fill 142 234 639 142 234 642 minecraft:iron_block
fill 143 234 605 146 234 605 minecraft:iron_block
setblock 144 234 645 minecraft:iron_block
fill 146 234 606 146 235 607 minecraft:iron_block
fill 146 234 645 149 234 645 minecraft:iron_block
setblock 148 234 605 minecraft:iron_block
fill 153 234 605 156 234 605 minecraft:iron_block
setblock 154 234 645 minecraft:iron_block
fill 156 234 645 159 234 645 minecraft:iron_block
setblock 158 234 605 minecraft:iron_block
fill 163 234 605 166 234 605 minecraft:iron_block
setblock 164 234 645 minecraft:iron_block
fill 166 234 645 169 234 645 minecraft:iron_block
setblock 168 234 605 minecraft:iron_block
fill 173 234 605 176 234 605 minecraft:iron_block
setblock 174 234 645 minecraft:iron_block
fill 176 234 645 179 234 645 minecraft:iron_block
setblock 178 234 605 minecraft:iron_block
fill 182 234 606 182 234 609 minecraft:iron_block
setblock 182 234 611 minecraft:iron_block
fill 182 234 616 182 234 619 minecraft:iron_block
setblock 182 234 621 minecraft:iron_block
fill 182 234 626 182 234 629 minecraft:iron_block
setblock 182 234 631 minecraft:iron_block
fill 182 234 636 182 234 639 minecraft:iron_block
setblock 182 234 641 minecraft:iron_block
setblock 146 235 605 minecraft:iron_block
fill 148 236 630 148 248 630 minecraft:iron_block
fill 177 237 626 177 237 628 minecraft:iron_block
fill 178 237 626 179 237 626 minecraft:iron_block
fill 178 237 628 179 237 628 minecraft:iron_block
setblock 179 237 627 minecraft:iron_block
fill 141 238 610 141 238 613 minecraft:sea_lantern
fill 141 238 620 141 238 623 minecraft:sea_lantern
fill 141 238 630 141 238 633 minecraft:sea_lantern
fill 141 238 640 141 238 643 minecraft:sea_lantern
fill 144 238 604 147 238 604 minecraft:sea_lantern
fill 145 238 646 148 238 646 minecraft:sea_lantern
fill 152 238 638 156 239 642 minecraft:netherite_block
fill 154 238 604 157 238 604 minecraft:sea_lantern
fill 154 238 643 154 238 644 minecraft:netherite_block
fill 155 238 646 158 238 646 minecraft:sea_lantern
fill 164 238 604 167 238 604 minecraft:sea_lantern
fill 165 238 646 168 238 646 minecraft:sea_lantern
fill 174 238 604 177 238 604 minecraft:sea_lantern
fill 175 238 646 178 238 646 minecraft:sea_lantern
fill 183 238 605 183 238 608 minecraft:sea_lantern
fill 183 238 615 183 238 618 minecraft:sea_lantern
fill 183 238 625 183 238 628 minecraft:sea_lantern
fill 183 238 635 183 238 638 minecraft:sea_lantern
setblock 183 238 645 minecraft:sea_lantern
fill 141 239 610 141 246 613 minecraft:netherite_block
fill 141 239 620 141 246 623 minecraft:netherite_block
fill 141 239 630 141 246 633 minecraft:netherite_block
fill 141 239 640 141 246 643 minecraft:netherite_block
fill 144 239 604 147 246 604 minecraft:netherite_block
setblock 144 239 607 minecraft:light[level=14]
setblock 144 239 615 minecraft:light[level=14]
setblock 144 239 623 minecraft:light[level=14]
setblock 144 239 631 minecraft:light[level=14]
setblock 144 239 639 minecraft:light[level=14]
fill 145 239 646 148 246 646 minecraft:netherite_block
setblock 152 239 607 minecraft:light[level=14]
setblock 152 239 615 minecraft:light[level=14]
setblock 152 239 623 minecraft:light[level=14]
setblock 152 239 631 minecraft:light[level=14]
fill 154 239 604 157 246 604 minecraft:netherite_block
fill 155 239 646 158 246 646 minecraft:netherite_block
setblock 160 239 607 minecraft:light[level=14]
setblock 160 239 615 minecraft:light[level=14]
setblock 160 239 623 minecraft:light[level=14]
setblock 160 239 631 minecraft:light[level=14]
setblock 160 239 639 minecraft:light[level=14]
fill 164 239 604 167 246 604 minecraft:netherite_block
fill 165 239 646 168 246 646 minecraft:netherite_block
setblock 168 239 607 minecraft:light[level=14]
setblock 168 239 615 minecraft:light[level=14]
setblock 168 239 623 minecraft:light[level=14]
setblock 168 239 631 minecraft:light[level=14]
setblock 168 239 639 minecraft:light[level=14]
fill 174 239 604 177 246 604 minecraft:netherite_block
fill 175 239 646 178 246 646 minecraft:netherite_block
setblock 176 239 607 minecraft:light[level=14]
setblock 176 239 615 minecraft:light[level=14]
setblock 176 239 623 minecraft:light[level=14]
setblock 176 239 631 minecraft:light[level=14]
setblock 176 239 639 minecraft:light[level=14]
fill 183 239 605 183 246 608 minecraft:netherite_block
fill 183 239 615 183 246 618 minecraft:netherite_block
fill 183 239 625 183 246 628 minecraft:netherite_block
fill 183 239 635 183 246 638 minecraft:netherite_block
fill 183 239 645 183 246 645 minecraft:netherite_block
setblock 142 240 607 minecraft:iron_block
setblock 142 240 617 minecraft:iron_block
setblock 142 240 627 minecraft:iron_block
setblock 142 240 637 minecraft:iron_block
setblock 144 240 645 minecraft:iron_block
setblock 148 240 605 minecraft:iron_block
setblock 154 240 645 minecraft:iron_block
setblock 158 240 605 minecraft:iron_block
setblock 164 240 645 minecraft:iron_block
setblock 168 240 605 minecraft:iron_block
setblock 174 240 645 minecraft:iron_block
setblock 178 240 605 minecraft:iron_block
setblock 182 240 611 minecraft:iron_block
setblock 182 240 621 minecraft:iron_block
setblock 182 240 631 minecraft:iron_block
setblock 182 240 641 minecraft:iron_block
fill 177 242 626 177 242 628 minecraft:iron_block
fill 178 242 626 179 242 626 minecraft:iron_block
fill 178 242 628 179 242 628 minecraft:iron_block
setblock 179 242 627 minecraft:iron_block
fill 142 243 609 142 243 612 minecraft:iron_block
fill 142 243 619 142 243 622 minecraft:iron_block
fill 142 243 629 142 243 632 minecraft:iron_block
fill 142 243 639 142 243 642 minecraft:iron_block
fill 143 243 605 146 243 605 minecraft:iron_block
fill 146 243 645 149 243 645 minecraft:iron_block
fill 151 243 638 151 244 642 minecraft:iron_block
fill 152 243 637 152 244 638 minecraft:iron_block
fill 152 243 640 157 244 640 minecraft:iron_block
fill 152 243 642 152 244 643 minecraft:iron_block
fill 153 243 605 156 243 605 minecraft:iron_block
fill 153 243 637 156 244 637 minecraft:iron_block
fill 153 243 643 156 244 643 minecraft:iron_block
fill 154 243 638 154 244 639 minecraft:iron_block
fill 154 243 641 154 244 642 minecraft:iron_block
fill 156 243 638 157 244 638 minecraft:iron_block
fill 156 243 642 157 244 642 minecraft:iron_block
fill 156 243 645 159 243 645 minecraft:iron_block
fill 157 243 639 157 244 639 minecraft:iron_block
fill 157 243 641 157 244 641 minecraft:iron_block
fill 163 243 605 166 243 605 minecraft:iron_block
fill 166 243 645 169 243 645 minecraft:iron_block
fill 173 243 605 176 243 605 minecraft:iron_block
fill 176 243 645 179 243 645 minecraft:iron_block
fill 182 243 606 182 243 609 minecraft:iron_block
fill 182 243 616 182 243 619 minecraft:iron_block
fill 182 243 626 182 243 629 minecraft:iron_block
fill 182 243 636 182 243 639 minecraft:iron_block
setblock 142 246 607 minecraft:iron_block
setblock 142 246 617 minecraft:iron_block
setblock 142 246 627 minecraft:iron_block
setblock 142 246 637 minecraft:iron_block
setblock 144 246 645 minecraft:iron_block
setblock 148 246 605 minecraft:iron_block
setblock 154 246 645 minecraft:iron_block
setblock 158 246 605 minecraft:iron_block
setblock 164 246 645 minecraft:iron_block
setblock 168 246 605 minecraft:iron_block
setblock 174 246 645 minecraft:iron_block
setblock 178 246 605 minecraft:iron_block
setblock 182 246 611 minecraft:iron_block
setblock 182 246 621 minecraft:iron_block
setblock 182 246 631 minecraft:iron_block
setblock 182 246 641 minecraft:iron_block
fill 141 247 610 141 247 613 minecraft:sea_lantern
fill 141 247 620 141 247 623 minecraft:sea_lantern
fill 141 247 630 141 247 633 minecraft:sea_lantern
fill 141 247 640 141 247 643 minecraft:sea_lantern
fill 144 247 604 147 247 604 minecraft:sea_lantern
setblock 144 247 607 minecraft:light[level=14]
setblock 144 247 615 minecraft:light[level=14]
setblock 144 247 623 minecraft:light[level=14]
setblock 144 247 631 minecraft:light[level=14]
setblock 144 247 639 minecraft:light[level=14]
fill 145 247 646 148 247 646 minecraft:sea_lantern
setblock 152 247 607 minecraft:light[level=14]
setblock 152 247 615 minecraft:light[level=14]
setblock 152 247 623 minecraft:light[level=14]
setblock 152 247 631 minecraft:light[level=14]
setblock 152 247 639 minecraft:light[level=14]
fill 154 247 604 157 247 604 minecraft:sea_lantern
fill 155 247 646 158 247 646 minecraft:sea_lantern
setblock 160 247 607 minecraft:light[level=14]
setblock 160 247 615 minecraft:light[level=14]
setblock 160 247 623 minecraft:light[level=14]
setblock 160 247 631 minecraft:light[level=14]
setblock 160 247 639 minecraft:light[level=14]
fill 164 247 604 167 247 604 minecraft:sea_lantern
fill 165 247 646 168 247 646 minecraft:sea_lantern
setblock 168 247 607 minecraft:light[level=14]
setblock 168 247 615 minecraft:light[level=14]
setblock 168 247 623 minecraft:light[level=14]
setblock 168 247 631 minecraft:light[level=14]
setblock 168 247 639 minecraft:light[level=14]
fill 174 247 604 177 247 604 minecraft:sea_lantern
fill 175 247 646 178 247 646 minecraft:sea_lantern
setblock 176 247 607 minecraft:light[level=14]
setblock 176 247 615 minecraft:light[level=14]
setblock 176 247 623 minecraft:light[level=14]
setblock 176 247 631 minecraft:light[level=14]
setblock 176 247 639 minecraft:light[level=14]
fill 177 247 626 177 247 628 minecraft:iron_block
fill 178 247 626 179 247 626 minecraft:iron_block
fill 178 247 628 179 247 628 minecraft:iron_block
setblock 179 247 627 minecraft:iron_block
fill 183 247 605 183 247 608 minecraft:sea_lantern
fill 183 247 615 183 247 618 minecraft:sea_lantern
fill 183 247 625 183 247 628 minecraft:sea_lantern
fill 183 247 635 183 247 638 minecraft:sea_lantern
setblock 183 247 645 minecraft:sea_lantern
fill 141 248 610 141 255 613 minecraft:netherite_block
fill 141 248 620 141 255 623 minecraft:netherite_block
fill 141 248 630 141 255 633 minecraft:netherite_block
fill 141 248 640 141 255 643 minecraft:netherite_block
fill 144 248 604 147 255 604 minecraft:netherite_block
fill 145 248 646 148 255 646 minecraft:netherite_block
fill 154 248 604 157 255 604 minecraft:netherite_block
fill 155 248 646 158 255 646 minecraft:netherite_block
fill 164 248 604 167 255 604 minecraft:netherite_block
fill 165 248 646 168 255 646 minecraft:netherite_block
fill 174 248 604 177 255 604 minecraft:netherite_block
fill 175 248 646 178 255 646 minecraft:netherite_block
fill 183 248 605 183 255 608 minecraft:netherite_block
fill 183 248 615 183 255 618 minecraft:netherite_block
fill 183 248 625 183 255 628 minecraft:netherite_block
fill 183 248 635 183 255 638 minecraft:netherite_block
fill 183 248 645 183 255 645 minecraft:netherite_block
setblock 142 252 607 minecraft:iron_block
fill 142 252 609 142 252 612 minecraft:iron_block
setblock 142 252 617 minecraft:iron_block
fill 142 252 619 142 252 622 minecraft:iron_block
setblock 142 252 627 minecraft:iron_block
fill 142 252 629 142 252 632 minecraft:iron_block
setblock 142 252 637 minecraft:iron_block
fill 142 252 639 142 252 642 minecraft:iron_block
fill 143 252 605 146 252 605 minecraft:iron_block
setblock 144 252 645 minecraft:iron_block
fill 146 252 645 149 252 645 minecraft:iron_block
setblock 148 252 605 minecraft:iron_block
fill 153 252 605 156 252 605 minecraft:iron_block
setblock 154 252 645 minecraft:iron_block
fill 156 252 645 159 252 645 minecraft:iron_block
setblock 158 252 605 minecraft:iron_block
fill 163 252 605 166 252 605 minecraft:iron_block
setblock 164 252 645 minecraft:iron_block
fill 166 252 645 169 252 645 minecraft:iron_block
setblock 168 252 605 minecraft:iron_block
fill 173 252 605 176 252 605 minecraft:iron_block
setblock 174 252 645 minecraft:iron_block
fill 176 252 645 179 252 645 minecraft:iron_block
fill 177 252 626 177 252 628 minecraft:iron_block
setblock 178 252 605 minecraft:iron_block
fill 178 252 626 179 252 626 minecraft:iron_block
fill 178 252 628 179 252 628 minecraft:iron_block
setblock 179 252 627 minecraft:iron_block
fill 182 252 606 182 252 609 minecraft:iron_block
setblock 182 252 611 minecraft:iron_block
fill 182 252 616 182 252 619 minecraft:iron_block
setblock 182 252 621 minecraft:iron_block
fill 182 252 626 182 252 629 minecraft:iron_block
setblock 182 252 631 minecraft:iron_block
fill 182 252 636 182 252 639 minecraft:iron_block
setblock 182 252 641 minecraft:iron_block
setblock 144 255 607 minecraft:light[level=14]
setblock 144 255 615 minecraft:light[level=14]
setblock 144 255 623 minecraft:light[level=14]
setblock 144 255 631 minecraft:light[level=14]
setblock 144 255 639 minecraft:light[level=14]
setblock 152 255 607 minecraft:light[level=14]
setblock 152 255 615 minecraft:light[level=14]
setblock 152 255 623 minecraft:light[level=14]
setblock 152 255 631 minecraft:light[level=14]
setblock 152 255 639 minecraft:light[level=14]
setblock 160 255 607 minecraft:light[level=14]
setblock 160 255 615 minecraft:light[level=14]
setblock 160 255 623 minecraft:light[level=14]
setblock 160 255 631 minecraft:light[level=14]
setblock 160 255 639 minecraft:light[level=14]
setblock 168 255 607 minecraft:light[level=14]
setblock 168 255 615 minecraft:light[level=14]
setblock 168 255 623 minecraft:light[level=14]
setblock 168 255 631 minecraft:light[level=14]
setblock 168 255 639 minecraft:light[level=14]
setblock 176 255 607 minecraft:light[level=14]
setblock 176 255 615 minecraft:light[level=14]
setblock 176 255 623 minecraft:light[level=14]
setblock 176 255 631 minecraft:light[level=14]
setblock 176 255 639 minecraft:light[level=14]
fill 141 256 610 141 256 613 minecraft:sea_lantern
fill 141 256 620 141 256 623 minecraft:sea_lantern
fill 141 256 630 141 256 633 minecraft:sea_lantern
fill 141 256 640 141 256 643 minecraft:sea_lantern
fill 144 256 604 147 256 604 minecraft:sea_lantern
fill 145 256 646 148 256 646 minecraft:sea_lantern
fill 154 256 604 157 256 604 minecraft:sea_lantern
fill 155 256 646 158 256 646 minecraft:sea_lantern
fill 164 256 604 167 256 604 minecraft:sea_lantern
fill 165 256 646 168 256 646 minecraft:sea_lantern
fill 174 256 604 177 256 604 minecraft:sea_lantern
fill 175 256 646 178 256 646 minecraft:sea_lantern
fill 183 256 605 183 256 608 minecraft:sea_lantern
fill 183 256 615 183 256 618 minecraft:sea_lantern
fill 183 256 625 183 256 628 minecraft:sea_lantern
fill 183 256 635 183 256 638 minecraft:sea_lantern
setblock 183 256 645 minecraft:sea_lantern
fill 141 257 610 141 264 613 minecraft:netherite_block
fill 141 257 620 141 264 623 minecraft:netherite_block
fill 141 257 630 141 264 633 minecraft:netherite_block
fill 141 257 640 141 264 643 minecraft:netherite_block
fill 144 257 604 147 264 604 minecraft:netherite_block
fill 145 257 646 148 264 646 minecraft:netherite_block
fill 154 257 604 157 264 604 minecraft:netherite_block
fill 155 257 646 158 264 646 minecraft:netherite_block
fill 164 257 604 167 264 604 minecraft:netherite_block
fill 165 257 646 168 264 646 minecraft:netherite_block
fill 174 257 604 177 264 604 minecraft:netherite_block
fill 175 257 646 178 264 646 minecraft:netherite_block
fill 177 257 626 177 257 628 minecraft:iron_block
fill 178 257 626 179 257 626 minecraft:iron_block
fill 178 257 628 179 257 628 minecraft:iron_block
setblock 179 257 627 minecraft:iron_block
fill 183 257 605 183 264 608 minecraft:netherite_block
fill 183 257 615 183 264 618 minecraft:netherite_block
fill 183 257 625 183 264 628 minecraft:netherite_block
fill 183 257 635 183 264 638 minecraft:netherite_block
fill 183 257 645 183 264 645 minecraft:netherite_block
setblock 142 258 607 minecraft:iron_block
setblock 142 258 617 minecraft:iron_block
setblock 142 258 627 minecraft:iron_block
setblock 142 258 637 minecraft:iron_block
setblock 144 258 645 minecraft:iron_block
setblock 148 258 605 minecraft:iron_block
setblock 154 258 645 minecraft:iron_block
setblock 158 258 605 minecraft:iron_block
setblock 164 258 645 minecraft:iron_block
setblock 168 258 605 minecraft:iron_block
setblock 174 258 645 minecraft:iron_block
setblock 178 258 605 minecraft:iron_block
setblock 182 258 611 minecraft:iron_block
setblock 182 258 621 minecraft:iron_block
setblock 182 258 631 minecraft:iron_block
setblock 182 258 641 minecraft:iron_block
fill 142 261 609 142 261 612 minecraft:iron_block
fill 142 261 619 142 261 622 minecraft:iron_block
fill 142 261 629 142 261 632 minecraft:iron_block
fill 142 261 639 142 261 642 minecraft:iron_block
fill 143 261 605 146 261 605 minecraft:iron_block
fill 146 261 645 149 261 645 minecraft:iron_block
fill 153 261 605 156 261 605 minecraft:iron_block
fill 156 261 645 159 261 645 minecraft:iron_block
fill 163 261 605 166 261 605 minecraft:iron_block
fill 166 261 645 169 261 645 minecraft:iron_block
fill 173 261 605 176 261 605 minecraft:iron_block
fill 176 261 645 179 261 645 minecraft:iron_block
fill 182 261 606 182 261 609 minecraft:iron_block
fill 182 261 616 182 261 619 minecraft:iron_block
fill 182 261 626 182 261 629 minecraft:iron_block
fill 182 261 636 182 261 639 minecraft:iron_block
fill 177 262 626 177 262 628 minecraft:iron_block
fill 178 262 626 179 262 626 minecraft:iron_block
fill 178 262 628 179 262 628 minecraft:iron_block
setblock 179 262 627 minecraft:iron_block
setblock 144 263 607 minecraft:light[level=14]
setblock 144 263 615 minecraft:light[level=14]
setblock 144 263 623 minecraft:light[level=14]
setblock 144 263 631 minecraft:light[level=14]
setblock 144 263 639 minecraft:light[level=14]
setblock 152 263 607 minecraft:light[level=14]
setblock 152 263 615 minecraft:light[level=14]
setblock 152 263 623 minecraft:light[level=14]
setblock 152 263 631 minecraft:light[level=14]
setblock 152 263 639 minecraft:light[level=14]
setblock 160 263 607 minecraft:light[level=14]
setblock 160 263 615 minecraft:light[level=14]
setblock 160 263 623 minecraft:light[level=14]
setblock 160 263 631 minecraft:light[level=14]
setblock 160 263 639 minecraft:light[level=14]
setblock 168 263 607 minecraft:light[level=14]
setblock 168 263 615 minecraft:light[level=14]
setblock 168 263 623 minecraft:light[level=14]
setblock 168 263 631 minecraft:light[level=14]
setblock 168 263 639 minecraft:light[level=14]
setblock 176 263 607 minecraft:light[level=14]
setblock 176 263 615 minecraft:light[level=14]
setblock 176 263 623 minecraft:light[level=14]
setblock 176 263 631 minecraft:light[level=14]
setblock 176 263 639 minecraft:light[level=14]
setblock 142 264 607 minecraft:iron_block
setblock 142 264 617 minecraft:iron_block
setblock 142 264 627 minecraft:iron_block
setblock 142 264 637 minecraft:iron_block
setblock 144 264 645 minecraft:iron_block
setblock 148 264 605 minecraft:iron_block
setblock 154 264 645 minecraft:iron_block
setblock 158 264 605 minecraft:iron_block
setblock 164 264 645 minecraft:iron_block
setblock 168 264 605 minecraft:iron_block
setblock 174 264 645 minecraft:iron_block
setblock 178 264 605 minecraft:iron_block
setblock 182 264 611 minecraft:iron_block
setblock 182 264 621 minecraft:iron_block
setblock 182 264 631 minecraft:iron_block
setblock 182 264 641 minecraft:iron_block
fill 141 265 610 141 265 613 minecraft:sea_lantern
fill 141 265 620 141 265 623 minecraft:sea_lantern
fill 141 265 630 141 265 633 minecraft:sea_lantern
fill 141 265 640 141 265 643 minecraft:sea_lantern
fill 144 265 604 147 265 604 minecraft:sea_lantern
fill 145 265 646 148 265 646 minecraft:sea_lantern
fill 154 265 604 157 265 604 minecraft:sea_lantern
fill 155 265 646 158 265 646 minecraft:sea_lantern
fill 164 265 604 167 265 604 minecraft:sea_lantern
fill 165 265 646 168 265 646 minecraft:sea_lantern
fill 174 265 604 177 265 604 minecraft:sea_lantern
fill 175 265 646 178 265 646 minecraft:sea_lantern
fill 183 265 605 183 265 608 minecraft:sea_lantern
fill 183 265 615 183 265 618 minecraft:sea_lantern
fill 183 265 625 183 265 628 minecraft:sea_lantern
fill 183 265 635 183 265 638 minecraft:sea_lantern
setblock 183 265 645 minecraft:sea_lantern
fill 141 266 610 141 291 613 minecraft:netherite_block
fill 141 266 620 141 291 623 minecraft:netherite_block
fill 141 266 630 141 291 633 minecraft:netherite_block
fill 141 266 640 141 291 643 minecraft:netherite_block
fill 144 266 604 147 291 604 minecraft:netherite_block
fill 145 266 646 148 291 646 minecraft:netherite_block
fill 154 266 604 157 291 604 minecraft:netherite_block
fill 155 266 646 158 291 646 minecraft:netherite_block
fill 164 266 604 167 291 604 minecraft:netherite_block
fill 165 266 646 168 291 646 minecraft:netherite_block
fill 174 266 604 177 291 604 minecraft:netherite_block
fill 175 266 646 178 291 646 minecraft:netherite_block
fill 183 266 605 183 291 608 minecraft:netherite_block
fill 183 266 615 183 291 618 minecraft:netherite_block
fill 183 266 625 183 291 628 minecraft:netherite_block
fill 183 266 635 183 291 638 minecraft:netherite_block
fill 183 266 645 183 291 645 minecraft:netherite_block
fill 177 267 626 177 267 628 minecraft:iron_block
fill 178 267 626 179 267 626 minecraft:iron_block
fill 178 267 628 179 267 628 minecraft:iron_block
setblock 179 267 627 minecraft:iron_block
setblock 142 270 607 minecraft:iron_block
fill 142 270 609 142 270 612 minecraft:iron_block
setblock 142 270 617 minecraft:iron_block
fill 142 270 619 142 270 622 minecraft:iron_block
setblock 142 270 627 minecraft:iron_block
fill 142 270 629 142 270 632 minecraft:iron_block
setblock 142 270 637 minecraft:iron_block
fill 142 270 639 142 270 642 minecraft:iron_block
fill 143 270 605 146 270 605 minecraft:iron_block
setblock 144 270 645 minecraft:iron_block
fill 146 270 645 149 270 645 minecraft:iron_block
setblock 148 270 605 minecraft:iron_block
fill 153 270 605 156 270 605 minecraft:iron_block
setblock 154 270 645 minecraft:iron_block
fill 156 270 645 159 270 645 minecraft:iron_block
setblock 158 270 605 minecraft:iron_block
fill 163 270 605 166 270 605 minecraft:iron_block
setblock 164 270 645 minecraft:iron_block
fill 166 270 645 169 270 645 minecraft:iron_block
setblock 168 270 605 minecraft:iron_block
fill 173 270 605 176 270 605 minecraft:iron_block
setblock 174 270 645 minecraft:iron_block
fill 176 270 645 179 270 645 minecraft:iron_block
setblock 178 270 605 minecraft:iron_block
fill 179 270 627 182 270 627 minecraft:iron_block
fill 182 270 606 182 270 609 minecraft:iron_block
setblock 182 270 611 minecraft:iron_block
fill 182 270 616 182 270 619 minecraft:iron_block
setblock 182 270 621 minecraft:iron_block
setblock 182 270 626 minecraft:iron_block
fill 182 270 628 182 270 629 minecraft:iron_block
setblock 182 270 631 minecraft:iron_block
fill 182 270 636 182 270 639 minecraft:iron_block
setblock 182 270 641 minecraft:iron_block
setblock 144 271 607 minecraft:light[level=14]
setblock 144 271 615 minecraft:light[level=14]
setblock 144 271 623 minecraft:light[level=14]
setblock 144 271 631 minecraft:light[level=14]
setblock 144 271 639 minecraft:light[level=14]
setblock 152 271 607 minecraft:light[level=14]
setblock 152 271 615 minecraft:light[level=14]
setblock 152 271 623 minecraft:light[level=14]
setblock 152 271 631 minecraft:light[level=14]
setblock 152 271 639 minecraft:light[level=14]
setblock 160 271 607 minecraft:light[level=14]
setblock 160 271 615 minecraft:light[level=14]
setblock 160 271 623 minecraft:light[level=14]
setblock 160 271 631 minecraft:light[level=14]
setblock 160 271 639 minecraft:light[level=14]
setblock 168 271 607 minecraft:light[level=14]
setblock 168 271 615 minecraft:light[level=14]
setblock 168 271 623 minecraft:light[level=14]
setblock 168 271 631 minecraft:light[level=14]
setblock 168 271 639 minecraft:light[level=14]
setblock 176 271 607 minecraft:light[level=14]
setblock 176 271 615 minecraft:light[level=14]
setblock 176 271 623 minecraft:light[level=14]
setblock 176 271 631 minecraft:light[level=14]
setblock 176 271 639 minecraft:light[level=14]
setblock 177 271 627 minecraft:sea_lantern
fill 179 271 627 181 271 627 minecraft:iron_block
fill 177 272 626 177 272 628 minecraft:iron_block
fill 178 272 626 179 272 626 minecraft:iron_block
fill 178 272 628 179 272 628 minecraft:iron_block
setblock 179 272 627 minecraft:iron_block
fill 158 278 624 160 278 626 minecraft:redstone_block
fill 162 278 619 164 278 621 minecraft:redstone_block
fill 163 278 629 165 278 631 minecraft:redstone_block
fill 168 278 624 170 278 626 minecraft:redstone_block
setblock 144 279 607 minecraft:light[level=14]
setblock 144 279 615 minecraft:light[level=14]
setblock 144 279 623 minecraft:light[level=14]
setblock 144 279 631 minecraft:light[level=14]
setblock 144 279 639 minecraft:light[level=14]
fill 149 279 625 157 279 625 minecraft:gold_block
fill 150 279 621 150 280 622 minecraft:gold_block
fill 150 279 624 157 279 624 minecraft:gold_block
fill 150 279 627 176 279 627 minecraft:gold_block
fill 150 279 630 162 279 630 minecraft:gold_block
fill 151 279 619 161 279 619 minecraft:gold_block
fill 151 279 622 176 279 622 minecraft:gold_block
fill 151 279 629 162 279 629 minecraft:gold_block
fill 151 279 632 174 279 632 minecraft:gold_block
setblock 152 279 607 minecraft:light[level=14]
setblock 152 279 615 minecraft:light[level=14]
fill 152 279 616 153 280 616 minecraft:gold_block
fill 152 279 620 161 279 621 minecraft:gold_block
fill 152 279 623 178 279 623 minecraft:gold_block
fill 152 279 626 157 279 626 minecraft:gold_block
fill 152 279 628 178 279 628 minecraft:gold_block
setblock 152 279 631 minecraft:light[level=14]
fill 152 279 633 152 280 633 minecraft:gold_block
setblock 152 279 639 minecraft:light[level=14]
fill 153 279 617 174 279 617 minecraft:gold_block
fill 153 279 631 162 279 631 minecraft:gold_block
fill 153 279 635 154 280 635 minecraft:gold_block
fill 154 279 614 154 280 615 minecraft:gold_block
fill 154 279 618 177 279 618 minecraft:gold_block
fill 154 279 633 173 279 634 minecraft:gold_block
fill 155 279 615 172 279 616 minecraft:gold_block
fill 155 279 636 155 280 637 minecraft:gold_block
fill 156 279 613 157 280 613 minecraft:gold_block
fill 156 279 635 156 280 636 minecraft:gold_block
fill 157 279 612 157 280 612 minecraft:gold_block
fill 157 279 614 170 280 614 minecraft:gold_block
fill 157 279 635 174 280 635 minecraft:gold_block
fill 158 279 636 158 280 638 minecraft:gold_block
fill 159 279 611 159 280 613 minecraft:gold_block
fill 159 279 636 169 280 637 minecraft:gold_block
setblock 160 279 607 minecraft:light[level=14]
fill 160 279 612 160 280 613 minecraft:gold_block
fill 160 279 639 161 280 639 minecraft:gold_block
fill 161 279 613 170 280 613 minecraft:gold_block
fill 161 279 624 162 279 626 minecraft:gold_block
fill 161 279 638 161 280 638 minecraft:gold_block
fill 162 279 611 162 280 612 minecraft:gold_block
fill 163 279 638 164 280 639 minecraft:gold_block
fill 164 279 610 164 280 612 minecraft:gold_block
fill 164 279 640 164 280 640 minecraft:gold_block
fill 165 279 611 165 280 612 minecraft:gold_block
fill 165 279 619 175 279 621 minecraft:gold_block
fill 166 279 624 167 279 626 minecraft:gold_block
fill 166 279 629 176 279 631 minecraft:gold_block
fill 166 279 638 166 280 639 minecraft:gold_block
fill 167 279 611 167 280 612 minecraft:gold_block
setblock 168 279 607 minecraft:light[level=14]
fill 168 279 611 168 280 611 minecraft:gold_block
fill 168 279 638 169 280 638 minecraft:gold_block
setblock 168 279 639 minecraft:light[level=14]
fill 169 279 639 169 280 639 minecraft:gold_block
fill 170 279 612 170 280 612 minecraft:gold_block
fill 170 279 636 171 280 636 minecraft:gold_block
fill 171 279 624 176 279 626 minecraft:gold_block
fill 171 279 637 171 280 638 minecraft:gold_block
fill 172 279 614 173 280 614 minecraft:gold_block
fill 172 279 637 172 280 637 minecraft:gold_block
fill 173 279 613 173 280 613 minecraft:gold_block
fill 173 279 616 174 280 616 minecraft:gold_block
fill 174 279 615 175 280 615 minecraft:gold_block
fill 174 279 633 175 280 633 minecraft:gold_block
fill 174 279 636 174 280 636 minecraft:gold_block
fill 175 279 634 176 280 634 minecraft:gold_block
setblock 176 279 607 minecraft:light[level=14]
setblock 176 279 615 minecraft:light[level=14]
fill 176 279 617 176 280 617 minecraft:gold_block
fill 176 279 620 177 280 621 minecraft:gold_block
setblock 176 279 639 minecraft:light[level=14]
fill 177 279 625 178 280 626 minecraft:gold_block
fill 177 279 631 177 280 631 minecraft:gold_block
fill 178 279 620 178 280 620 minecraft:gold_block
fill 178 279 629 178 280 629 minecraft:gold_block
fill 179 279 625 179 280 625 minecraft:gold_block
fill 142 280 605 148 280 645 minecraft:netherite_block
fill 149 280 605 149 280 624 minecraft:netherite_block
fill 149 280 625 156 280 625 minecraft:gold_block
fill 149 280 626 149 280 645 minecraft:netherite_block
fill 150 280 605 150 280 620 minecraft:netherite_block
fill 150 280 623 151 280 623 minecraft:netherite_block
fill 150 280 624 156 280 624 minecraft:gold_block
fill 150 280 626 151 280 626 minecraft:netherite_block
fill 150 280 627 153 280 627 minecraft:gold_block
fill 150 280 628 150 280 629 minecraft:netherite_block
fill 150 280 630 154 280 630 minecraft:gold_block
fill 150 280 631 150 280 645 minecraft:netherite_block
fill 151 280 605 151 280 618 minecraft:netherite_block
fill 151 280 619 160 280 619 minecraft:gold_block
fill 151 280 620 151 280 621 minecraft:netherite_block
fill 151 280 622 160 280 622 minecraft:gold_block
setblock 151 280 628 minecraft:netherite_block
fill 151 280 629 154 280 629 minecraft:gold_block
fill 151 280 631 152 280 631 minecraft:netherite_block
fill 151 280 632 156 280 632 minecraft:gold_block
fill 151 280 633 151 280 645 minecraft:netherite_block
fill 152 280 605 153 280 615 minecraft:netherite_block
fill 152 280 617 152 280 618 minecraft:netherite_block
fill 152 280 620 160 280 621 minecraft:gold_block
fill 152 280 623 156 280 623 minecraft:gold_block
fill 152 280 626 153 280 626 minecraft:gold_block
fill 152 280 628 153 280 628 minecraft:gold_block
fill 152 280 634 152 280 645 minecraft:netherite_block
fill 153 280 617 159 280 617 minecraft:gold_block
setblock 153 280 618 minecraft:netherite_block
fill 153 280 631 155 280 631 minecraft:gold_block
fill 153 280 633 153 280 634 minecraft:netherite_block
fill 153 280 636 154 280 645 minecraft:netherite_block
fill 154 280 605 155 280 613 minecraft:netherite_block
setblock 154 280 616 minecraft:netherite_block
fill 154 280 618 159 280 618 minecraft:gold_block
fill 154 280 626 156 280 628 minecraft:iron_block
fill 154 280 633 157 280 634 minecraft:gold_block
fill 155 280 614 156 280 614 minecraft:netherite_block
fill 155 280 615 158 280 616 minecraft:gold_block
fill 155 280 629 161 280 630 minecraft:iron_block
setblock 155 280 635 minecraft:netherite_block
fill 155 280 638 157 280 645 minecraft:netherite_block
fill 156 280 605 156 280 612 minecraft:netherite_block
fill 156 280 631 160 280 631 minecraft:iron_block
fill 156 280 637 157 280 637 minecraft:netherite_block
fill 157 280 605 158 280 611 minecraft:netherite_block
fill 157 280 623 157 280 627 minecraft:sea_lantern
fill 157 280 628 161 280 628 minecraft:iron_block
fill 157 280 632 159 280 632 minecraft:iron_block
setblock 157 280 636 minecraft:netherite_block
fill 158 280 612 158 280 613 minecraft:netherite_block
fill 158 280 623 171 280 623 minecraft:sea_lantern
fill 158 280 624 160 280 626 minecraft:netherite_block
fill 158 280 627 171 280 627 minecraft:sea_lantern
fill 158 280 633 159 280 633 minecraft:iron_block
fill 158 280 634 173 280 634 minecraft:gold_block
fill 158 280 639 159 280 645 minecraft:netherite_block
fill 159 280 605 163 280 610 minecraft:netherite_block
fill 159 280 615 160 280 615 minecraft:gold_block
fill 159 280 616 169 280 616 minecraft:iron_block
fill 159 280 638 160 280 638 minecraft:netherite_block
fill 160 280 611 161 280 611 minecraft:netherite_block
fill 160 280 617 160 280 618 minecraft:iron_block
fill 160 280 632 161 280 633 minecraft:gold_block
fill 160 280 640 163 280 645 minecraft:netherite_block
setblock 161 280 612 minecraft:netherite_block
fill 161 280 615 167 280 615 minecraft:iron_block
fill 161 280 617 168 280 617 minecraft:iron_block
fill 161 280 618 161 280 622 minecraft:sea_lantern
fill 161 280 624 162 280 626 minecraft:sea_lantern
setblock 161 280 631 minecraft:gold_block
fill 162 280 618 165 280 618 minecraft:sea_lantern
fill 162 280 619 164 280 621 minecraft:netherite_block
fill 162 280 622 165 280 622 minecraft:sea_lantern
fill 162 280 628 162 280 632 minecraft:sea_lantern
fill 162 280 633 168 280 633 minecraft:gold_block
fill 162 280 638 162 280 639 minecraft:netherite_block
fill 163 280 611 163 280 612 minecraft:netherite_block
fill 163 280 628 166 280 628 minecraft:sea_lantern
fill 163 280 629 165 280 631 minecraft:netherite_block
fill 163 280 632 166 280 632 minecraft:sea_lantern
fill 164 280 605 182 280 609 minecraft:netherite_block
fill 164 280 641 182 280 645 minecraft:netherite_block
fill 165 280 610 182 280 610 minecraft:netherite_block
fill 165 280 619 165 280 621 minecraft:sea_lantern
fill 165 280 638 165 280 640 minecraft:netherite_block
fill 166 280 611 166 280 612 minecraft:netherite_block
fill 166 280 618 166 280 621 minecraft:iron_block
fill 166 280 622 176 280 622 minecraft:gold_block
fill 166 280 624 167 280 626 minecraft:sea_lantern
fill 166 280 629 166 280 631 minecraft:sea_lantern
fill 166 280 640 182 280 640 minecraft:netherite_block
fill 167 280 618 167 280 619 minecraft:iron_block
fill 167 280 620 175 280 621 minecraft:gold_block
fill 167 280 628 173 280 630 minecraft:iron_block
fill 167 280 631 167 280 632 minecraft:gold_block
fill 167 280 638 167 280 639 minecraft:netherite_block
fill 168 280 612 169 280 612 minecraft:netherite_block
fill 168 280 615 172 280 615 minecraft:gold_block
setblock 168 280 618 minecraft:iron_block
fill 168 280 619 175 280 619 minecraft:gold_block
fill 168 280 624 170 280 626 minecraft:netherite_block
fill 168 280 631 172 280 631 minecraft:iron_block
setblock 168 280 632 minecraft:gold_block
setblock 168 280 639 minecraft:netherite_block
fill 169 280 611 182 280 611 minecraft:netherite_block
fill 169 280 617 174 280 618 minecraft:gold_block
fill 169 280 632 170 280 633 minecraft:iron_block
fill 170 280 616 172 280 616 minecraft:gold_block
fill 170 280 637 170 280 639 minecraft:netherite_block
fill 171 280 612 171 280 614 minecraft:netherite_block
fill 171 280 624 171 280 626 minecraft:sea_lantern
setblock 171 280 632 minecraft:iron_block
fill 171 280 633 173 280 633 minecraft:gold_block
fill 171 280 639 182 280 639 minecraft:netherite_block
fill 172 280 612 172 280 613 minecraft:netherite_block
fill 172 280 623 176 280 624 minecraft:gold_block
fill 172 280 625 174 280 627 minecraft:iron_block
fill 172 280 632 174 280 632 minecraft:gold_block
fill 172 280 636 173 280 636 minecraft:netherite_block
fill 172 280 638 182 280 638 minecraft:netherite_block
fill 173 280 612 182 280 612 minecraft:netherite_block
setblock 173 280 615 minecraft:netherite_block
fill 173 280 631 176 280 631 minecraft:gold_block
fill 173 280 637 182 280 637 minecraft:netherite_block
fill 174 280 613 182 280 614 minecraft:netherite_block
setblock 174 280 628 minecraft:iron_block
fill 174 280 629 176 280 630 minecraft:gold_block
setblock 174 280 634 minecraft:netherite_block
fill 175 280 616 175 280 617 minecraft:netherite_block
fill 175 280 618 177 280 618 minecraft:gold_block
fill 175 280 625 176 280 628 minecraft:gold_block
fill 175 280 632 182 280 632 minecraft:netherite_block
fill 175 280 635 182 280 636 minecraft:netherite_block
fill 176 280 615 182 280 616 minecraft:netherite_block
fill 176 280 619 182 280 619 minecraft:netherite_block
fill 176 280 633 182 280 633 minecraft:netherite_block
fill 177 280 617 182 280 617 minecraft:netherite_block
fill 177 280 622 182 280 622 minecraft:netherite_block
fill 177 280 623 178 280 623 minecraft:gold_block
fill 177 280 624 182 280 624 minecraft:netherite_block
fill 177 280 627 182 280 627 minecraft:netherite_block
fill 177 280 628 178 280 628 minecraft:gold_block
fill 177 280 629 177 280 630 minecraft:netherite_block
fill 177 280 634 182 280 634 minecraft:netherite_block
fill 178 280 618 182 280 618 minecraft:netherite_block
fill 178 280 621 182 280 621 minecraft:netherite_block
fill 178 280 630 182 280 631 minecraft:netherite_block
fill 179 280 620 182 280 620 minecraft:netherite_block
fill 179 280 623 182 280 623 minecraft:netherite_block
fill 179 280 626 182 280 626 minecraft:netherite_block
fill 179 280 628 182 280 629 minecraft:netherite_block
fill 180 280 625 182 280 625 minecraft:netherite_block
fill 142 284 606 142 300 606 minecraft:iron_block
fill 142 284 616 142 300 616 minecraft:iron_block
fill 142 284 626 142 300 626 minecraft:iron_block
fill 142 284 636 142 300 636 minecraft:iron_block
fill 143 284 645 143 300 645 minecraft:iron_block
fill 144 284 614 146 300 616 minecraft:iron_block
fill 149 284 605 149 300 605 minecraft:iron_block
fill 153 284 645 153 300 645 minecraft:iron_block
fill 159 284 605 159 300 605 minecraft:iron_block
fill 163 284 645 163 300 645 minecraft:iron_block
fill 169 284 605 169 300 605 minecraft:iron_block
fill 173 284 645 173 300 645 minecraft:iron_block
fill 174 284 642 176 300 642 minecraft:iron_block
fill 175 284 641 175 300 641 minecraft:iron_block
fill 175 284 643 175 300 643 minecraft:iron_block
fill 177 284 633 179 300 635 minecraft:iron_block
fill 179 284 605 179 300 605 minecraft:iron_block
fill 182 284 612 182 300 612 minecraft:iron_block
fill 182 284 622 182 300 622 minecraft:iron_block
fill 182 284 632 182 300 632 minecraft:iron_block
fill 182 284 642 182 300 642 minecraft:iron_block
fill 142 286 614 143 287 615 minecraft:iron_block
fill 143 286 616 143 287 616 minecraft:iron_block
fill 144 286 613 146 286 613 minecraft:iron_block
fill 144 286 617 146 286 617 minecraft:iron_block
fill 147 286 614 147 286 616 minecraft:iron_block
setblock 174 286 641 minecraft:iron_block
setblock 174 286 643 minecraft:iron_block
fill 176 286 633 176 286 635 minecraft:iron_block
setblock 176 286 641 minecraft:iron_block
setblock 176 286 643 minecraft:iron_block
fill 177 286 632 179 286 632 minecraft:iron_block
fill 177 286 636 179 286 636 minecraft:iron_block
fill 180 286 633 180 286 635 minecraft:iron_block
setblock 144 287 607 minecraft:light[level=14]
setblock 144 287 623 minecraft:light[level=14]
setblock 144 287 631 minecraft:light[level=14]
setblock 144 287 639 minecraft:light[level=14]
setblock 147 287 615 minecraft:sea_lantern
setblock 152 287 607 minecraft:light[level=14]
setblock 152 287 615 minecraft:light[level=14]
setblock 152 287 623 minecraft:light[level=14]
setblock 152 287 631 minecraft:light[level=14]
setblock 152 287 639 minecraft:light[level=14]
setblock 160 287 607 minecraft:light[level=14]
setblock 160 287 615 minecraft:light[level=14]
setblock 160 287 623 minecraft:light[level=14]
setblock 160 287 631 minecraft:light[level=14]
setblock 160 287 639 minecraft:light[level=14]
setblock 168 287 607 minecraft:light[level=14]
setblock 168 287 615 minecraft:light[level=14]
setblock 168 287 623 minecraft:light[level=14]
setblock 168 287 631 minecraft:light[level=14]
setblock 168 287 639 minecraft:light[level=14]
setblock 176 287 607 minecraft:light[level=14]
setblock 176 287 615 minecraft:light[level=14]
setblock 176 287 623 minecraft:light[level=14]
setblock 176 287 631 minecraft:light[level=14]
setblock 176 287 639 minecraft:light[level=14]
setblock 142 288 607 minecraft:iron_block
fill 142 288 609 142 288 612 minecraft:iron_block
setblock 142 288 617 minecraft:iron_block
fill 142 288 619 142 288 622 minecraft:iron_block
setblock 142 288 627 minecraft:iron_block
fill 142 288 629 142 288 632 minecraft:iron_block
setblock 142 288 637 minecraft:iron_block
fill 142 288 639 142 288 642 minecraft:iron_block
fill 143 288 605 146 288 605 minecraft:iron_block
setblock 144 288 645 minecraft:iron_block
fill 146 288 645 149 288 645 minecraft:iron_block
setblock 148 288 605 minecraft:iron_block
fill 153 288 605 156 288 605 minecraft:iron_block
setblock 154 288 645 minecraft:iron_block
fill 156 288 645 159 288 645 minecraft:iron_block
setblock 158 288 605 minecraft:iron_block
fill 163 288 605 166 288 605 minecraft:iron_block
setblock 164 288 645 minecraft:iron_block
fill 166 288 645 169 288 645 minecraft:iron_block
setblock 168 288 605 minecraft:iron_block
fill 173 288 605 176 288 605 minecraft:iron_block
setblock 174 288 645 minecraft:iron_block
fill 176 288 645 179 288 645 minecraft:iron_block
setblock 178 288 605 minecraft:iron_block
fill 182 288 606 182 288 609 minecraft:iron_block
setblock 182 288 611 minecraft:iron_block
fill 182 288 616 182 288 619 minecraft:iron_block
setblock 182 288 621 minecraft:iron_block
fill 182 288 626 182 288 629 minecraft:iron_block
setblock 182 288 631 minecraft:iron_block
fill 182 288 636 182 288 639 minecraft:iron_block
setblock 182 288 641 minecraft:iron_block
fill 155 290 605 155 291 607 minecraft:iron_block
fill 180 290 633 181 291 635 minecraft:iron_block
fill 182 290 634 182 291 634 minecraft:iron_block
setblock 174 291 641 minecraft:iron_block
setblock 174 291 643 minecraft:iron_block
setblock 176 291 634 minecraft:sea_lantern
setblock 176 291 641 minecraft:iron_block
setblock 176 291 643 minecraft:iron_block
fill 141 292 610 141 292 613 minecraft:sea_lantern
fill 141 292 620 141 292 623 minecraft:sea_lantern
fill 141 292 630 141 292 633 minecraft:sea_lantern
fill 141 292 640 141 292 643 minecraft:sea_lantern
fill 143 292 614 143 292 616 minecraft:iron_block
fill 144 292 604 147 292 604 minecraft:sea_lantern
fill 144 292 613 146 292 613 minecraft:iron_block
fill 144 292 617 146 292 617 minecraft:iron_block
fill 145 292 646 148 292 646 minecraft:sea_lantern
fill 147 292 614 147 292 616 minecraft:iron_block
fill 154 292 604 157 292 604 minecraft:sea_lantern
fill 155 292 646 158 292 646 minecraft:sea_lantern
fill 164 292 604 167 292 604 minecraft:sea_lantern
fill 165 292 646 168 292 646 minecraft:sea_lantern
fill 174 292 604 177 292 604 minecraft:sea_lantern
fill 175 292 646 178 292 646 minecraft:sea_lantern
fill 176 292 633 176 292 635 minecraft:iron_block
fill 177 292 632 179 292 632 minecraft:iron_block
fill 177 292 636 179 292 636 minecraft:iron_block
fill 180 292 633 180 292 635 minecraft:iron_block
fill 183 292 605 183 292 608 minecraft:sea_lantern
fill 183 292 615 183 292 618 minecraft:sea_lantern
fill 183 292 625 183 292 628 minecraft:sea_lantern
fill 183 292 635 183 292 638 minecraft:sea_lantern
setblock 183 292 645 minecraft:sea_lantern
fill 141 293 610 141 307 613 minecraft:netherite_block
fill 141 293 620 141 307 623 minecraft:netherite_block
fill 141 293 630 141 307 633 minecraft:netherite_block
fill 141 293 640 141 307 643 minecraft:netherite_block
fill 144 293 604 147 307 604 minecraft:netherite_block
fill 145 293 646 148 307 646 minecraft:netherite_block
fill 154 293 604 157 307 604 minecraft:netherite_block
fill 155 293 646 158 307 646 minecraft:netherite_block
fill 164 293 604 167 307 604 minecraft:netherite_block
fill 165 293 646 168 307 646 minecraft:netherite_block
fill 174 293 604 177 307 604 minecraft:netherite_block
fill 175 293 646 178 307 646 minecraft:netherite_block
fill 183 293 605 183 307 608 minecraft:netherite_block
fill 183 293 615 183 307 618 minecraft:netherite_block
fill 183 293 625 183 307 628 minecraft:netherite_block
fill 183 293 635 183 307 638 minecraft:netherite_block
fill 183 293 645 183 307 645 minecraft:netherite_block
setblock 142 294 607 minecraft:iron_block
setblock 142 294 617 minecraft:iron_block
setblock 142 294 627 minecraft:iron_block
setblock 142 294 637 minecraft:iron_block
setblock 144 294 645 minecraft:iron_block
setblock 148 294 605 minecraft:iron_block
setblock 154 294 645 minecraft:iron_block
setblock 158 294 605 minecraft:iron_block
setblock 164 294 645 minecraft:iron_block
setblock 168 294 605 minecraft:iron_block
fill 174 294 645 175 294 645 minecraft:iron_block
fill 175 294 644 175 295 644 minecraft:iron_block
setblock 178 294 605 minecraft:iron_block
setblock 182 294 611 minecraft:iron_block
setblock 182 294 621 minecraft:iron_block
setblock 182 294 631 minecraft:iron_block
setblock 182 294 641 minecraft:iron_block
setblock 144 295 607 minecraft:light[level=14]
setblock 144 295 623 minecraft:light[level=14]
setblock 144 295 631 minecraft:light[level=14]
setblock 144 295 639 minecraft:light[level=14]
setblock 152 295 607 minecraft:light[level=14]
setblock 152 295 615 minecraft:light[level=14]
setblock 152 295 623 minecraft:light[level=14]
setblock 152 295 631 minecraft:light[level=14]
setblock 152 295 639 minecraft:light[level=14]
setblock 160 295 607 minecraft:light[level=14]
setblock 160 295 615 minecraft:light[level=14]
setblock 160 295 623 minecraft:light[level=14]
setblock 160 295 631 minecraft:light[level=14]
setblock 160 295 639 minecraft:light[level=14]
setblock 168 295 607 minecraft:light[level=14]
setblock 168 295 615 minecraft:light[level=14]
setblock 168 295 623 minecraft:light[level=14]
setblock 168 295 631 minecraft:light[level=14]
setblock 168 295 639 minecraft:light[level=14]
setblock 175 295 640 minecraft:sea_lantern
setblock 175 295 645 minecraft:iron_block
setblock 176 295 607 minecraft:light[level=14]
setblock 176 295 615 minecraft:light[level=14]
setblock 176 295 623 minecraft:light[level=14]
setblock 176 295 631 minecraft:light[level=14]
setblock 176 295 639 minecraft:light[level=14]
setblock 174 296 641 minecraft:iron_block
setblock 174 296 643 minecraft:iron_block
setblock 176 296 641 minecraft:iron_block
setblock 176 296 643 minecraft:iron_block
fill 142 297 609 142 297 612 minecraft:iron_block
fill 142 297 619 142 297 622 minecraft:iron_block
fill 142 297 629 142 297 632 minecraft:iron_block
fill 142 297 639 142 297 642 minecraft:iron_block
fill 143 297 605 146 297 605 minecraft:iron_block
fill 146 297 645 149 297 645 minecraft:iron_block
fill 153 297 605 156 297 605 minecraft:iron_block
fill 156 297 645 159 297 645 minecraft:iron_block
fill 163 297 605 166 297 605 minecraft:iron_block
fill 166 297 645 169 297 645 minecraft:iron_block
fill 173 297 605 176 297 605 minecraft:iron_block
fill 176 297 645 179 297 645 minecraft:iron_block
fill 182 297 606 182 297 609 minecraft:iron_block
fill 182 297 616 182 297 619 minecraft:iron_block
fill 182 297 626 182 297 629 minecraft:iron_block
fill 182 297 636 182 297 639 minecraft:iron_block
fill 143 298 614 143 298 616 minecraft:iron_block
fill 144 298 613 146 298 613 minecraft:iron_block
fill 144 298 617 146 298 617 minecraft:iron_block
fill 147 298 614 147 298 616 minecraft:iron_block
fill 176 298 633 176 298 635 minecraft:iron_block
fill 177 298 632 179 298 632 minecraft:iron_block
fill 177 298 636 179 298 636 minecraft:iron_block
fill 180 298 633 180 298 635 minecraft:iron_block
setblock 142 300 607 minecraft:iron_block
setblock 142 300 617 minecraft:iron_block
setblock 142 300 627 minecraft:iron_block
setblock 142 300 637 minecraft:iron_block
setblock 144 300 645 minecraft:iron_block
setblock 148 300 605 minecraft:iron_block
setblock 154 300 645 minecraft:iron_block
setblock 158 300 605 minecraft:iron_block
setblock 164 300 645 minecraft:iron_block
setblock 168 300 605 minecraft:iron_block
setblock 174 300 645 minecraft:iron_block
setblock 178 300 605 minecraft:iron_block
setblock 182 300 611 minecraft:iron_block
setblock 182 300 621 minecraft:iron_block
setblock 182 300 631 minecraft:iron_block
setblock 182 300 641 minecraft:iron_block
setblock 144 303 607 minecraft:light[level=14]
setblock 144 303 615 minecraft:light[level=14]
setblock 144 303 623 minecraft:light[level=14]
setblock 144 303 631 minecraft:light[level=14]
setblock 144 303 639 minecraft:light[level=14]
setblock 152 303 607 minecraft:light[level=14]
setblock 152 303 615 minecraft:light[level=14]
setblock 152 303 623 minecraft:light[level=14]
setblock 152 303 631 minecraft:light[level=14]
setblock 152 303 639 minecraft:light[level=14]
setblock 160 303 607 minecraft:light[level=14]
setblock 160 303 615 minecraft:light[level=14]
setblock 160 303 623 minecraft:light[level=14]
setblock 160 303 631 minecraft:light[level=14]
setblock 160 303 639 minecraft:light[level=14]
setblock 168 303 607 minecraft:light[level=14]
setblock 168 303 615 minecraft:light[level=14]
setblock 168 303 623 minecraft:light[level=14]
setblock 168 303 631 minecraft:light[level=14]
setblock 168 303 639 minecraft:light[level=14]
setblock 176 303 607 minecraft:light[level=14]
setblock 176 303 615 minecraft:light[level=14]
setblock 176 303 623 minecraft:light[level=14]
setblock 176 303 631 minecraft:light[level=14]
setblock 176 303 639 minecraft:light[level=14]
