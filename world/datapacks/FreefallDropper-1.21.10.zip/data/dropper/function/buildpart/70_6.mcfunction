fill 510 131 309 510 134 309 minecraft:deepslate_tiles
setblock 510 131 313 minecraft:cobbled_deepslate
setblock 511 131 278 minecraft:deepslate_tiles
setblock 511 131 282 minecraft:cobbled_deepslate
fill 511 131 283 511 134 283 minecraft:deepslate_tiles
setblock 511 131 287 minecraft:cobbled_deepslate
fill 511 131 288 511 134 288 minecraft:deepslate_tiles
setblock 511 131 297 minecraft:cobbled_deepslate
fill 511 131 298 511 134 298 minecraft:deepslate_tiles
setblock 511 131 302 minecraft:cobbled_deepslate
fill 511 131 303 511 134 303 minecraft:deepslate_tiles
setblock 511 131 307 minecraft:cobbled_deepslate
fill 511 131 308 511 134 308 minecraft:deepslate_tiles
setblock 511 131 312 minecraft:cobbled_deepslate
fill 511 131 313 511 134 313 minecraft:deepslate_tiles
setblock 512 131 296 minecraft:white_wool
setblock 471 132 281 minecraft:cobbled_deepslate
fill 471 132 282 471 135 282 minecraft:deepslate_tiles
setblock 471 132 286 minecraft:cobbled_deepslate
fill 471 132 287 472 134 287 minecraft:deepslate_tiles
setblock 471 132 290 minecraft:deepslate_tiles
setblock 471 132 291 minecraft:cobbled_deepslate
fill 471 132 292 471 135 292 minecraft:deepslate_tiles
setblock 471 132 296 minecraft:cobbled_deepslate
fill 471 132 297 471 135 297 minecraft:deepslate_tiles
setblock 471 132 301 minecraft:cobbled_deepslate
fill 471 132 302 471 135 302 minecraft:deepslate_tiles
setblock 471 132 306 minecraft:cobbled_deepslate
fill 471 132 307 471 135 307 minecraft:deepslate_tiles
setblock 471 132 311 minecraft:cobbled_deepslate
setblock 472 132 284 minecraft:deepslate_tiles
setblock 472 132 285 minecraft:cobbled_deepslate
fill 472 132 286 472 135 286 minecraft:deepslate_tiles
fill 472 132 288 472 133 288 minecraft:deepslate_tiles
setblock 472 132 300 minecraft:cobbled_deepslate
fill 472 132 301 472 133 301 minecraft:deepslate_tiles
setblock 472 132 305 minecraft:cobbled_deepslate
fill 472 132 306 472 135 306 minecraft:deepslate_tiles
fill 472 132 308 472 133 308 minecraft:deepslate_tiles
fill 479 132 276 479 133 276 minecraft:deepslate_tiles
setblock 481 132 276 minecraft:cobbled_deepslate
fill 481 132 277 481 135 277 minecraft:deepslate_tiles
fill 482 132 276 482 135 276 minecraft:deepslate_tiles
setblock 483 132 279 minecraft:cobbled_deepslate
fill 483 132 316 483 134 316 minecraft:deepslate_tiles
setblock 484 132 278 minecraft:cobbled_deepslate
fill 484 132 279 484 134 279 minecraft:deepslate_tiles
setblock 485 132 277 minecraft:cobbled_deepslate
fill 485 132 278 485 135 278 minecraft:deepslate_tiles
setblock 486 132 276 minecraft:cobbled_deepslate
fill 486 132 277 489 132 277 minecraft:deepslate_tiles
setblock 486 132 316 minecraft:cobbled_deepslate
fill 487 132 276 490 132 276 minecraft:deepslate_tiles
fill 487 132 316 487 135 316 minecraft:deepslate_tiles
setblock 488 132 279 minecraft:cobbled_deepslate
setblock 489 132 278 minecraft:cobbled_deepslate
setblock 490 132 277 minecraft:cobbled_deepslate
setblock 490 132 278 minecraft:deepslate_tiles
setblock 491 132 276 minecraft:cobbled_deepslate
fill 491 132 277 491 133 277 minecraft:deepslate_tiles
setblock 491 132 316 minecraft:cobbled_deepslate
fill 492 132 276 492 135 276 minecraft:deepslate_tiles
setblock 496 132 276 minecraft:cobbled_deepslate
fill 497 132 276 497 135 276 minecraft:deepslate_tiles
fill 497 132 316 498 134 316 minecraft:deepslate_tiles
setblock 500 132 277 minecraft:cobbled_deepslate
setblock 501 132 276 minecraft:cobbled_deepslate
fill 501 132 277 501 134 277 minecraft:deepslate_tiles
setblock 501 132 315 minecraft:deepslate_tiles
setblock 501 132 316 minecraft:cobbled_deepslate
fill 502 132 276 502 135 276 minecraft:deepslate_tiles
setblock 502 132 315 minecraft:cobbled_deepslate
fill 502 132 316 502 135 316 minecraft:deepslate_tiles
fill 503 132 315 503 135 315 minecraft:deepslate_tiles
fill 504 132 314 506 133 314 minecraft:deepslate_tiles
setblock 505 132 277 minecraft:cobbled_deepslate
setblock 506 132 276 minecraft:cobbled_deepslate
fill 506 132 277 506 133 277 minecraft:deepslate_tiles
setblock 506 132 316 minecraft:cobbled_deepslate
fill 507 132 276 507 134 276 minecraft:deepslate_tiles
setblock 507 132 305 minecraft:cobbled_deepslate
fill 507 132 306 507 134 306 minecraft:deepslate_tiles
setblock 507 132 315 minecraft:cobbled_deepslate
fill 507 132 316 507 135 316 minecraft:deepslate_tiles
fill 508 132 302 508 132 303 minecraft:deepslate_tiles
setblock 508 132 304 minecraft:cobbled_deepslate
fill 508 132 305 508 135 305 minecraft:deepslate_tiles
setblock 508 132 308 minecraft:deepslate_tiles
setblock 508 132 309 minecraft:cobbled_deepslate
fill 508 132 315 508 135 315 minecraft:deepslate_tiles
setblock 509 132 303 minecraft:cobbled_deepslate
fill 509 132 304 509 135 304 minecraft:deepslate_tiles
setblock 509 132 308 minecraft:cobbled_deepslate
fill 509 132 309 509 135 309 minecraft:deepslate_tiles
setblock 510 132 282 minecraft:cobbled_deepslate
fill 510 132 283 510 133 283 minecraft:deepslate_tiles
fill 510 132 285 510 133 285 minecraft:deepslate_tiles
fill 510 132 298 510 133 298 minecraft:deepslate_tiles
setblock 510 132 302 minecraft:cobbled_deepslate
fill 510 132 303 510 135 303 minecraft:deepslate_tiles
setblock 510 132 307 minecraft:cobbled_deepslate
fill 510 132 308 510 135 308 minecraft:deepslate_tiles
setblock 510 132 311 minecraft:deepslate_tiles
setblock 510 132 312 minecraft:cobbled_deepslate
fill 510 132 313 510 134 313 minecraft:deepslate_tiles
setblock 511 132 281 minecraft:cobbled_deepslate
fill 511 132 282 511 134 282 minecraft:deepslate_tiles
setblock 511 132 286 minecraft:cobbled_deepslate
fill 511 132 287 511 135 287 minecraft:deepslate_tiles
fill 511 132 289 511 133 289 minecraft:deepslate_tiles
setblock 511 132 296 minecraft:cobbled_deepslate
fill 511 132 297 511 135 297 minecraft:deepslate_tiles
setblock 511 132 301 minecraft:cobbled_deepslate
fill 511 132 302 511 135 302 minecraft:deepslate_tiles
setblock 511 132 306 minecraft:cobbled_deepslate
fill 511 132 307 511 135 307 minecraft:deepslate_tiles
setblock 511 132 311 minecraft:cobbled_deepslate
fill 511 132 312 511 135 312 minecraft:deepslate_tiles
fill 512 132 296 512 145 296 minecraft:black_concrete
setblock 471 133 280 minecraft:cobbled_deepslate
fill 471 133 281 471 135 281 minecraft:deepslate_tiles
setblock 471 133 285 minecraft:cobbled_deepslate
fill 471 133 286 471 136 286 minecraft:deepslate_tiles
setblock 471 133 290 minecraft:cobbled_deepslate
fill 471 133 291 471 136 291 minecraft:deepslate_tiles
setblock 471 133 295 minecraft:cobbled_deepslate
fill 471 133 296 471 135 296 minecraft:deepslate_tiles
setblock 471 133 300 minecraft:cobbled_deepslate
fill 471 133 301 471 136 301 minecraft:deepslate_tiles
setblock 471 133 305 minecraft:cobbled_deepslate
fill 471 133 306 471 136 306 minecraft:deepslate_tiles
setblock 471 133 310 minecraft:cobbled_deepslate
fill 471 133 311 471 135 311 minecraft:deepslate_tiles
setblock 472 133 284 minecraft:cobbled_deepslate
fill 472 133 285 472 136 285 minecraft:deepslate_tiles
setblock 472 133 289 minecraft:cobbled_deepslate
setblock 472 133 300 minecraft:deepslate_tiles
setblock 472 133 304 minecraft:cobbled_deepslate
fill 472 133 305 472 135 305 minecraft:deepslate_tiles
setblock 473 133 278 minecraft:light[level=13]
setblock 473 133 285 minecraft:light[level=12]
setblock 473 133 286 minecraft:light[level=13]
setblock 473 133 292 minecraft:light[level=12]
setblock 473 133 294 minecraft:light[level=13]
setblock 473 133 299 minecraft:light[level=12]
setblock 473 133 302 minecraft:light[level=13]
setblock 473 133 306 minecraft:light[level=12]
setblock 473 133 310 minecraft:light[level=13]
setblock 473 133 313 minecraft:light[level=12]
setblock 480 133 276 minecraft:cobbled_deepslate
fill 480 133 277 480 136 277 minecraft:deepslate_tiles
setblock 480 133 278 minecraft:light[level=12]
setblock 480 133 285 minecraft:light[level=12]
setblock 480 133 292 minecraft:light[level=12]
setblock 480 133 299 minecraft:light[level=12]
setblock 480 133 306 minecraft:light[level=12]
setblock 480 133 313 minecraft:light[level=12]
fill 481 133 275 484 178 275 minecraft:black_concrete
fill 481 133 276 481 136 276 minecraft:deepslate_tiles
setblock 481 133 278 minecraft:light[level=13]
setblock 481 133 286 minecraft:light[level=13]
setblock 481 133 294 minecraft:light[level=13]
setblock 481 133 302 minecraft:light[level=13]
setblock 481 133 310 minecraft:light[level=13]
fill 482 133 316 482 135 316 minecraft:deepslate_tiles
setblock 483 133 277 minecraft:deepslate_tiles
setblock 483 133 278 minecraft:cobbled_deepslate
fill 483 133 279 483 134 279 minecraft:deepslate_tiles
setblock 484 133 277 minecraft:cobbled_deepslate
fill 484 133 278 484 136 278 minecraft:deepslate_tiles
setblock 485 133 275 minecraft:white_wool
setblock 485 133 276 minecraft:cobbled_deepslate
fill 485 133 277 488 133 277 minecraft:deepslate_tiles
setblock 485 133 316 minecraft:cobbled_deepslate
fill 486 133 276 489 133 276 minecraft:deepslate_tiles
fill 486 133 316 486 136 316 minecraft:deepslate_tiles
setblock 487 133 279 minecraft:cobbled_deepslate
setblock 487 133 285 minecraft:light[level=12]
setblock 487 133 292 minecraft:light[level=12]
setblock 487 133 299 minecraft:light[level=12]
setblock 487 133 306 minecraft:light[level=12]
setblock 487 133 313 minecraft:light[level=12]
setblock 488 133 278 minecraft:cobbled_deepslate
setblock 489 133 277 minecraft:cobbled_deepslate
setblock 489 133 278 minecraft:deepslate_tiles
setblock 489 133 286 minecraft:light[level=13]
setblock 489 133 294 minecraft:light[level=13]
setblock 489 133 302 minecraft:light[level=13]
setblock 489 133 310 minecraft:light[level=13]
setblock 490 133 276 minecraft:cobbled_deepslate
fill 490 133 277 490 134 277 minecraft:deepslate_tiles
setblock 490 133 316 minecraft:cobbled_deepslate
fill 491 133 276 491 135 276 minecraft:deepslate_tiles
fill 491 133 316 491 134 316 minecraft:deepslate_tiles
setblock 494 133 278 minecraft:light[level=12]
setblock 494 133 285 minecraft:light[level=12]
setblock 494 133 292 minecraft:light[level=12]
setblock 494 133 299 minecraft:light[level=12]
setblock 494 133 306 minecraft:light[level=12]
setblock 494 133 313 minecraft:light[level=12]
setblock 495 133 276 minecraft:cobbled_deepslate
fill 496 133 276 496 135 276 minecraft:deepslate_tiles
fill 496 133 316 496 136 316 minecraft:deepslate_tiles
setblock 497 133 278 minecraft:light[level=13]
setblock 497 133 286 minecraft:light[level=13]
setblock 497 133 294 minecraft:light[level=13]
setblock 497 133 302 minecraft:light[level=13]
setblock 497 133 310 minecraft:light[level=13]
setblock 500 133 276 minecraft:cobbled_deepslate
setblock 500 133 277 minecraft:deepslate_tiles
setblock 500 133 315 minecraft:deepslate_tiles
setblock 500 133 316 minecraft:cobbled_deepslate
fill 501 133 276 501 136 276 minecraft:deepslate_tiles
setblock 501 133 278 minecraft:light[level=12]
setblock 501 133 285 minecraft:light[level=12]
setblock 501 133 292 minecraft:light[level=12]
setblock 501 133 299 minecraft:light[level=12]
setblock 501 133 306 minecraft:light[level=12]
setblock 501 133 313 minecraft:light[level=12]
setblock 501 133 315 minecraft:cobbled_deepslate
fill 501 133 316 501 136 316 minecraft:deepslate_tiles
setblock 502 133 314 minecraft:cobbled_deepslate
fill 502 133 315 502 136 315 minecraft:deepslate_tiles
setblock 503 133 277 minecraft:deepslate_tiles
fill 503 133 314 503 136 314 minecraft:deepslate_tiles
setblock 504 133 277 minecraft:cobbled_deepslate
setblock 505 133 276 minecraft:cobbled_deepslate
fill 505 133 277 505 134 277 minecraft:deepslate_tiles
setblock 505 133 278 minecraft:light[level=13]
setblock 505 133 286 minecraft:light[level=13]
setblock 505 133 294 minecraft:light[level=13]
setblock 505 133 302 minecraft:light[level=13]
setblock 505 133 310 minecraft:light[level=13]
setblock 505 133 316 minecraft:cobbled_deepslate
fill 506 133 276 506 135 276 minecraft:deepslate_tiles
setblock 506 133 315 minecraft:cobbled_deepslate
fill 506 133 316 506 136 316 minecraft:deepslate_tiles
setblock 507 133 305 minecraft:deepslate_tiles
fill 507 133 307 507 134 307 minecraft:deepslate_tiles
fill 507 133 315 507 136 315 minecraft:deepslate_tiles
setblock 508 133 278 minecraft:light[level=12]
setblock 508 133 285 minecraft:light[level=12]
setblock 508 133 292 minecraft:light[level=12]
setblock 508 133 299 minecraft:light[level=12]
setblock 508 133 302 minecraft:deepslate_tiles
setblock 508 133 303 minecraft:cobbled_deepslate
fill 508 133 304 508 135 304 minecraft:deepslate_tiles
setblock 508 133 308 minecraft:cobbled_deepslate
fill 508 133 309 508 134 310 minecraft:deepslate_tiles
setblock 508 133 313 minecraft:light[level=12]
setblock 509 133 302 minecraft:cobbled_deepslate
fill 509 133 303 509 135 303 minecraft:deepslate_tiles
setblock 509 133 307 minecraft:cobbled_deepslate
fill 509 133 308 509 136 308 minecraft:deepslate_tiles
setblock 510 133 286 minecraft:cobbled_deepslate
setblock 510 133 301 minecraft:cobbled_deepslate
fill 510 133 302 510 136 302 minecraft:deepslate_tiles
setblock 510 133 306 minecraft:cobbled_deepslate
fill 510 133 307 510 136 307 minecraft:deepslate_tiles
setblock 510 133 311 minecraft:cobbled_deepslate
fill 510 133 312 510 136 312 minecraft:deepslate_tiles
setblock 510 133 316 minecraft:cobbled_deepslate
setblock 511 133 280 minecraft:cobbled_deepslate
fill 511 133 281 511 134 281 minecraft:deepslate_tiles
setblock 511 133 285 minecraft:cobbled_deepslate
fill 511 133 286 511 136 286 minecraft:deepslate_tiles
setblock 511 133 290 minecraft:cobbled_deepslate
fill 511 133 291 511 136 291 minecraft:deepslate_tiles
setblock 511 133 295 minecraft:cobbled_deepslate
fill 511 133 296 511 134 296 minecraft:deepslate_tiles
setblock 511 133 300 minecraft:cobbled_deepslate
fill 511 133 301 511 136 301 minecraft:deepslate_tiles
setblock 511 133 305 minecraft:cobbled_deepslate
fill 511 133 306 511 136 306 minecraft:deepslate_tiles
setblock 511 133 310 minecraft:cobbled_deepslate
fill 511 133 311 511 136 311 minecraft:deepslate_tiles
setblock 471 134 280 minecraft:deepslate_tiles
setblock 471 134 284 minecraft:cobbled_deepslate
fill 471 134 285 471 137 285 minecraft:deepslate_tiles
setblock 471 134 289 minecraft:cobbled_deepslate
fill 471 134 290 472 136 290 minecraft:deepslate_tiles
setblock 471 134 294 minecraft:cobbled_deepslate
fill 471 134 295 471 136 295 minecraft:deepslate_tiles
setblock 471 134 299 minecraft:cobbled_deepslate
fill 471 134 300 471 136 300 minecraft:deepslate_tiles
setblock 471 134 304 minecraft:cobbled_deepslate
fill 471 134 305 471 137 305 minecraft:deepslate_tiles
setblock 471 134 309 minecraft:cobbled_deepslate
fill 471 134 310 471 137 310 minecraft:deepslate_tiles
setblock 472 134 283 minecraft:cobbled_deepslate
fill 472 134 284 472 136 284 minecraft:deepslate_tiles
setblock 472 134 288 minecraft:cobbled_deepslate
fill 472 134 289 472 137 289 minecraft:deepslate_tiles
setblock 472 134 303 minecraft:cobbled_deepslate
fill 472 134 304 472 135 304 minecraft:deepslate_tiles
setblock 479 134 276 minecraft:cobbled_deepslate
fill 480 134 276 480 137 276 minecraft:deepslate_tiles
setblock 481 134 278 minecraft:deepslate_tiles
fill 481 134 316 481 136 316 minecraft:deepslate_tiles
setblock 482 134 277 minecraft:deepslate_tiles
setblock 482 134 278 minecraft:cobbled_deepslate
setblock 483 134 277 minecraft:cobbled_deepslate
fill 483 134 278 483 136 278 minecraft:deepslate_tiles
setblock 484 134 276 minecraft:cobbled_deepslate
fill 484 134 277 487 134 277 minecraft:deepslate_tiles
setblock 484 134 316 minecraft:cobbled_deepslate
fill 485 134 275 485 201 275 minecraft:black_concrete
fill 485 134 276 488 134 276 minecraft:deepslate_tiles
fill 485 134 316 485 137 316 minecraft:deepslate_tiles
setblock 486 134 279 minecraft:cobbled_deepslate
setblock 487 134 278 minecraft:cobbled_deepslate
setblock 488 134 277 minecraft:cobbled_deepslate
setblock 488 134 278 minecraft:deepslate_tiles
setblock 489 134 276 minecraft:cobbled_deepslate
fill 489 134 277 489 135 277 minecraft:deepslate_tiles
setblock 489 134 316 minecraft:cobbled_deepslate
fill 490 134 276 490 136 276 minecraft:deepslate_tiles
fill 490 134 316 490 136 316 minecraft:deepslate_tiles
setblock 494 134 276 minecraft:cobbled_deepslate
setblock 495 134 276 minecraft:deepslate_tiles
fill 495 134 316 495 137 316 minecraft:deepslate_tiles
setblock 499 134 276 minecraft:cobbled_deepslate
setblock 499 134 315 minecraft:deepslate_tiles
setblock 499 134 316 minecraft:cobbled_deepslate
fill 500 134 276 500 137 276 minecraft:deepslate_tiles
setblock 500 134 315 minecraft:cobbled_deepslate
fill 500 134 316 500 137 316 minecraft:deepslate_tiles
setblock 501 134 314 minecraft:cobbled_deepslate
fill 501 134 315 501 137 315 minecraft:deepslate_tiles
fill 502 134 314 502 137 314 minecraft:deepslate_tiles
setblock 503 134 277 minecraft:cobbled_deepslate
setblock 504 134 276 minecraft:cobbled_deepslate
setblock 504 134 277 minecraft:deepslate_tiles
fill 504 134 314 505 134 314 minecraft:deepslate_tiles
setblock 504 134 316 minecraft:cobbled_deepslate
fill 505 134 276 505 136 276 minecraft:deepslate_tiles
setblock 505 134 315 minecraft:cobbled_deepslate
fill 505 134 316 505 137 316 minecraft:deepslate_tiles
setblock 506 134 314 minecraft:cobbled_deepslate
fill 506 134 315 506 137 315 minecraft:deepslate_tiles
setblock 508 134 303 minecraft:deepslate_tiles
setblock 508 134 307 minecraft:cobbled_deepslate
fill 508 134 308 508 136 308 minecraft:deepslate_tiles
setblock 509 134 301 minecraft:cobbled_deepslate
fill 509 134 302 509 135 302 minecraft:deepslate_tiles
setblock 509 134 306 minecraft:cobbled_deepslate
fill 509 134 307 509 137 307 minecraft:deepslate_tiles
setblock 509 134 310 minecraft:deepslate_tiles
setblock 509 134 311 minecraft:cobbled_deepslate
setblock 509 134 316 minecraft:cobbled_deepslate
setblock 510 134 285 minecraft:cobbled_deepslate
fill 510 134 286 510 134 287 minecraft:deepslate_tiles
setblock 510 134 300 minecraft:cobbled_deepslate
fill 510 134 301 510 135 301 minecraft:deepslate_tiles
setblock 510 134 305 minecraft:cobbled_deepslate
fill 510 134 306 510 137 306 minecraft:deepslate_tiles
setblock 510 134 310 minecraft:cobbled_deepslate
fill 510 134 311 510 137 311 minecraft:deepslate_tiles
setblock 510 134 316 minecraft:deepslate_tiles
setblock 511 134 284 minecraft:cobbled_deepslate
fill 511 134 285 511 137 285 minecraft:deepslate_tiles
setblock 511 134 289 minecraft:cobbled_deepslate
fill 511 134 290 511 137 290 minecraft:deepslate_tiles
fill 511 134 292 511 135 292 minecraft:deepslate_tiles
setblock 511 134 299 minecraft:cobbled_deepslate
fill 511 134 300 511 136 300 minecraft:deepslate_tiles
setblock 511 134 304 minecraft:cobbled_deepslate
fill 511 134 305 511 137 305 minecraft:deepslate_tiles
setblock 511 134 309 minecraft:cobbled_deepslate
fill 511 134 310 511 137 310 minecraft:deepslate_tiles
setblock 511 134 314 minecraft:cobbled_deepslate
setblock 471 135 283 minecraft:cobbled_deepslate
fill 471 135 284 471 138 284 minecraft:deepslate_tiles
setblock 471 135 287 minecraft:deepslate_tiles
setblock 471 135 288 minecraft:cobbled_deepslate
fill 471 135 289 471 138 289 minecraft:deepslate_tiles
setblock 471 135 293 minecraft:cobbled_deepslate
fill 471 135 294 471 138 294 minecraft:deepslate_tiles
setblock 471 135 298 minecraft:cobbled_deepslate
setblock 471 135 299 minecraft:deepslate_tiles
setblock 471 135 303 minecraft:cobbled_deepslate
fill 471 135 304 471 137 304 minecraft:deepslate_tiles
setblock 471 135 308 minecraft:cobbled_deepslate
fill 471 135 309 471 137 309 minecraft:deepslate_tiles
setblock 472 135 283 minecraft:deepslate_tiles
setblock 472 135 287 minecraft:cobbled_deepslate
fill 472 135 288 472 138 288 minecraft:deepslate_tiles
fill 479 135 276 479 138 276 minecraft:deepslate_tiles
setblock 482 135 277 minecraft:cobbled_deepslate
fill 482 135 278 482 136 278 minecraft:deepslate_tiles
setblock 483 135 276 minecraft:cobbled_deepslate
fill 483 135 277 486 135 277 minecraft:deepslate_tiles
setblock 483 135 316 minecraft:cobbled_deepslate
fill 484 135 276 487 135 276 minecraft:deepslate_tiles
fill 484 135 316 484 138 316 minecraft:deepslate_tiles
setblock 486 135 278 minecraft:cobbled_deepslate
setblock 487 135 277 minecraft:cobbled_deepslate
setblock 487 135 278 minecraft:deepslate_tiles
setblock 488 135 276 minecraft:cobbled_deepslate
setblock 488 135 277 minecraft:deepslate_tiles
setblock 488 135 316 minecraft:cobbled_deepslate
fill 489 135 276 489 137 276 minecraft:deepslate_tiles
fill 489 135 316 489 137 316 minecraft:deepslate_tiles
fill 491 135 275 492 199 275 minecraft:black_concrete
setblock 493 135 275 minecraft:redstone_block
fill 494 135 275 495 197 275 minecraft:black_concrete
setblock 497 135 316 minecraft:deepslate_tiles
setblock 498 135 276 minecraft:cobbled_deepslate
setblock 498 135 315 minecraft:deepslate_tiles
setblock 498 135 316 minecraft:cobbled_deepslate
fill 499 135 276 499 138 276 minecraft:deepslate_tiles
setblock 499 135 315 minecraft:cobbled_deepslate
fill 499 135 316 499 138 316 minecraft:deepslate_tiles
setblock 500 135 314 minecraft:cobbled_deepslate
fill 500 135 315 500 138 315 minecraft:deepslate_tiles
fill 501 135 314 501 138 314 minecraft:deepslate_tiles
setblock 502 135 277 minecraft:cobbled_deepslate
setblock 503 135 276 minecraft:cobbled_deepslate
fill 503 135 313 504 135 313 minecraft:deepslate_tiles
setblock 503 135 316 minecraft:cobbled_deepslate
fill 504 135 276 504 137 276 minecraft:deepslate_tiles
setblock 504 135 314 minecraft:deepslate_tiles
setblock 504 135 315 minecraft:cobbled_deepslate
fill 504 135 316 504 138 316 minecraft:deepslate_tiles
setblock 505 135 314 minecraft:cobbled_deepslate
fill 505 135 315 505 138 315 minecraft:deepslate_tiles
fill 506 135 314 506 136 314 minecraft:deepslate_tiles
setblock 508 135 306 minecraft:cobbled_deepslate
fill 508 135 307 508 136 307 minecraft:deepslate_tiles
setblock 508 135 309 minecraft:deepslate_tiles
setblock 508 135 316 minecraft:cobbled_deepslate
setblock 509 135 305 minecraft:cobbled_deepslate
fill 509 135 306 509 137 306 minecraft:deepslate_tiles
setblock 509 135 310 minecraft:cobbled_deepslate
setblock 509 135 311 minecraft:deepslate_tiles
setblock 509 135 316 minecraft:deepslate_tiles
setblock 510 135 300 minecraft:deepslate_tiles
setblock 510 135 304 minecraft:cobbled_deepslate
fill 510 135 305 510 137 305 minecraft:deepslate_tiles
setblock 510 135 309 minecraft:cobbled_deepslate
fill 510 135 310 510 138 310 minecraft:deepslate_tiles
setblock 511 135 283 minecraft:cobbled_deepslate
fill 511 135 284 511 136 284 minecraft:deepslate_tiles
setblock 511 135 288 minecraft:cobbled_deepslate
fill 511 135 289 511 138 289 minecraft:deepslate_tiles
setblock 511 135 298 minecraft:cobbled_deepslate
fill 511 135 299 511 136 299 minecraft:deepslate_tiles
setblock 511 135 303 minecraft:cobbled_deepslate
fill 511 135 304 511 138 304 minecraft:deepslate_tiles
setblock 511 135 308 minecraft:cobbled_deepslate
fill 511 135 309 511 138 309 minecraft:deepslate_tiles
setblock 511 135 313 minecraft:cobbled_deepslate
setblock 511 135 314 minecraft:deepslate_tiles
fill 512 135 308 512 197 309 minecraft:black_concrete
setblock 512 135 310 minecraft:white_wool
fill 512 135 311 512 197 312 minecraft:black_concrete
setblock 471 136 282 minecraft:cobbled_deepslate
fill 471 136 283 471 137 283 minecraft:deepslate_tiles
setblock 471 136 287 minecraft:cobbled_deepslate
fill 471 136 288 471 139 288 minecraft:deepslate_tiles
setblock 471 136 292 minecraft:cobbled_deepslate
fill 471 136 293 471 139 293 minecraft:deepslate_tiles
setblock 471 136 302 minecraft:cobbled_deepslate
setblock 471 136 303 minecraft:deepslate_tiles
setblock 471 136 307 minecraft:cobbled_deepslate
fill 471 136 308 471 137 308 minecraft:deepslate_tiles
setblock 472 136 286 minecraft:cobbled_deepslate
fill 472 136 287 472 139 287 minecraft:deepslate_tiles
setblock 472 136 291 minecraft:cobbled_deepslate
fill 480 136 316 480 137 316 minecraft:deepslate_tiles
setblock 481 136 277 minecraft:cobbled_deepslate
setblock 482 136 276 minecraft:cobbled_deepslate
fill 482 136 277 485 136 277 minecraft:deepslate_tiles
setblock 482 136 316 minecraft:cobbled_deepslate
fill 483 136 276 486 136 276 minecraft:deepslate_tiles
fill 483 136 316 483 139 316 minecraft:deepslate_tiles
fill 484 136 315 484 139 315 minecraft:deepslate_tiles
setblock 485 136 278 minecraft:cobbled_deepslate
setblock 486 136 277 minecraft:cobbled_deepslate
setblock 487 136 276 minecraft:cobbled_deepslate
setblock 487 136 277 minecraft:deepslate_tiles
setblock 487 136 316 minecraft:cobbled_deepslate
fill 488 136 276 488 138 276 minecraft:deepslate_tiles
fill 488 136 316 488 139 316 minecraft:deepslate_tiles
fill 493 136 275 493 149 275 minecraft:black_concrete
fill 494 136 316 494 138 316 minecraft:deepslate_tiles
setblock 497 136 276 minecraft:cobbled_deepslate
setblock 497 136 315 minecraft:deepslate_tiles
setblock 497 136 316 minecraft:cobbled_deepslate
fill 498 136 276 498 137 276 minecraft:deepslate_tiles
setblock 498 136 315 minecraft:cobbled_deepslate
fill 498 136 316 498 139 316 minecraft:deepslate_tiles
setblock 499 136 314 minecraft:cobbled_deepslate
fill 499 136 315 499 139 315 minecraft:deepslate_tiles
fill 500 136 314 500 139 314 minecraft:deepslate_tiles
setblock 502 136 276 minecraft:cobbled_deepslate
fill 502 136 313 503 137 313 minecraft:deepslate_tiles
setblock 502 136 316 minecraft:cobbled_deepslate
fill 503 136 276 503 137 276 minecraft:deepslate_tiles
setblock 503 136 315 minecraft:cobbled_deepslate
fill 503 136 316 503 139 316 minecraft:deepslate_tiles
setblock 504 136 314 minecraft:cobbled_deepslate
fill 504 136 315 504 139 315 minecraft:deepslate_tiles
fill 505 136 314 505 137 314 minecraft:deepslate_tiles
setblock 507 136 316 minecraft:cobbled_deepslate
fill 508 136 316 508 137 316 minecraft:deepslate_tiles
setblock 509 136 304 minecraft:cobbled_deepslate
setblock 509 136 305 minecraft:deepslate_tiles
setblock 509 136 309 minecraft:cobbled_deepslate
setblock 509 136 310 minecraft:deepslate_tiles
setblock 510 136 303 minecraft:cobbled_deepslate
fill 510 136 304 510 137 304 minecraft:deepslate_tiles
setblock 510 136 308 minecraft:cobbled_deepslate
fill 510 136 309 510 138 309 minecraft:deepslate_tiles
setblock 511 136 287 minecraft:cobbled_deepslate
fill 511 136 288 511 139 288 minecraft:deepslate_tiles
setblock 511 136 292 minecraft:cobbled_deepslate
setblock 511 136 302 minecraft:cobbled_deepslate
fill 511 136 303 511 138 303 minecraft:deepslate_tiles
setblock 511 136 307 minecraft:cobbled_deepslate
fill 511 136 308 511 139 308 minecraft:deepslate_tiles
setblock 511 136 312 minecraft:cobbled_deepslate
fill 511 136 313 511 137 313 minecraft:deepslate_tiles
fill 512 136 310 512 201 310 minecraft:black_concrete
setblock 471 137 286 minecraft:cobbled_deepslate
fill 471 137 287 471 139 287 minecraft:deepslate_tiles
setblock 471 137 290 minecraft:deepslate_tiles
setblock 471 137 291 minecraft:cobbled_deepslate
fill 471 137 292 471 139 292 minecraft:deepslate_tiles
setblock 471 137 306 minecraft:cobbled_deepslate
setblock 471 137 307 minecraft:deepslate_tiles
setblock 472 137 285 minecraft:cobbled_deepslate
fill 472 137 286 472 138 286 minecraft:deepslate_tiles
setblock 472 137 290 minecraft:cobbled_deepslate
fill 472 137 291 472 139 291 minecraft:deepslate_tiles
fill 478 137 276 478 139 276 minecraft:deepslate_tiles
setblock 480 137 277 minecraft:cobbled_deepslate
setblock 481 137 276 minecraft:cobbled_deepslate
fill 481 137 277 484 137 277 minecraft:deepslate_tiles
setblock 481 137 316 minecraft:cobbled_deepslate
fill 482 137 276 485 137 276 minecraft:deepslate_tiles
fill 482 137 316 482 139 316 minecraft:deepslate_tiles
fill 483 137 315 483 139 315 minecraft:deepslate_tiles
setblock 485 137 277 minecraft:cobbled_deepslate
setblock 486 137 276 minecraft:cobbled_deepslate
setblock 486 137 277 minecraft:deepslate_tiles
setblock 486 137 316 minecraft:cobbled_deepslate
fill 487 137 276 487 139 276 minecraft:deepslate_tiles
fill 487 137 316 487 139 316 minecraft:deepslate_tiles
setblock 496 137 316 minecraft:cobbled_deepslate
setblock 497 137 315 minecraft:cobbled_deepslate
fill 497 137 316 497 139 316 minecraft:deepslate_tiles
fill 498 137 315 498 139 315 minecraft:deepslate_tiles
fill 499 137 314 499 139 314 minecraft:deepslate_tiles
setblock 501 137 276 minecraft:cobbled_deepslate
setblock 501 137 316 minecraft:cobbled_deepslate
fill 502 137 276 502 138 276 minecraft:deepslate_tiles
setblock 502 137 315 minecraft:cobbled_deepslate
fill 502 137 316 502 139 316 minecraft:deepslate_tiles
setblock 503 137 314 minecraft:cobbled_deepslate
fill 503 137 315 503 139 315 minecraft:deepslate_tiles
fill 504 137 314 504 139 314 minecraft:deepslate_tiles
setblock 506 137 316 minecraft:cobbled_deepslate
fill 507 137 316 507 138 316 minecraft:deepslate_tiles
setblock 509 137 308 minecraft:cobbled_deepslate
setblock 509 137 309 minecraft:deepslate_tiles
setblock 510 137 307 minecraft:cobbled_deepslate
fill 510 137 308 510 138 308 minecraft:deepslate_tiles
setblock 511 137 286 minecraft:cobbled_deepslate
fill 511 137 287 511 138 287 minecraft:deepslate_tiles
setblock 511 137 291 minecraft:cobbled_deepslate
fill 511 137 292 511 139 292 minecraft:deepslate_tiles
setblock 511 137 301 minecraft:cobbled_deepslate
setblock 511 137 302 minecraft:deepslate_tiles
setblock 511 137 306 minecraft:cobbled_deepslate
fill 511 137 307 511 139 307 minecraft:deepslate_tiles
setblock 511 137 311 minecraft:cobbled_deepslate
fill 511 137 312 511 139 312 minecraft:deepslate_tiles
fill 470 138 282 470 201 282 minecraft:black_concrete
setblock 470 138 283 minecraft:white_wool
setblock 471 138 285 minecraft:cobbled_deepslate
fill 471 138 286 471 139 286 minecraft:deepslate_tiles
setblock 471 138 290 minecraft:cobbled_deepslate
fill 471 138 291 471 139 291 minecraft:deepslate_tiles
setblock 472 138 289 minecraft:cobbled_deepslate
fill 472 138 290 472 139 290 minecraft:deepslate_tiles
setblock 479 138 316 minecraft:deepslate_tiles
setblock 480 138 276 minecraft:cobbled_deepslate
setblock 480 138 316 minecraft:cobbled_deepslate
fill 481 138 276 483 138 277 minecraft:deepslate_tiles
fill 481 138 316 481 139 316 minecraft:deepslate_tiles
setblock 484 138 276 minecraft:deepslate_tiles
setblock 484 138 277 minecraft:cobbled_deepslate
setblock 485 138 276 minecraft:cobbled_deepslate
setblock 485 138 316 minecraft:cobbled_deepslate
fill 486 138 276 486 139 276 minecraft:deepslate_tiles
fill 486 138 316 486 139 316 minecraft:deepslate_tiles
setblock 495 138 316 minecraft:cobbled_deepslate
setblock 496 138 315 minecraft:cobbled_deepslate
fill 496 138 316 496 139 316 minecraft:deepslate_tiles
fill 497 138 315 497 139 315 minecraft:deepslate_tiles
fill 498 138 314 498 139 314 minecraft:deepslate_tiles
setblock 500 138 276 minecraft:cobbled_deepslate
setblock 500 138 316 minecraft:cobbled_deepslate
fill 501 138 276 501 139 276 minecraft:deepslate_tiles
fill 501 138 313 502 138 313 minecraft:deepslate_tiles
setblock 501 138 315 minecraft:cobbled_deepslate
fill 501 138 316 501 139 316 minecraft:deepslate_tiles
setblock 502 138 314 minecraft:cobbled_deepslate
fill 502 138 315 502 139 315 minecraft:deepslate_tiles
fill 503 138 314 503 139 314 minecraft:deepslate_tiles
setblock 505 138 316 minecraft:cobbled_deepslate
setblock 506 138 315 minecraft:cobbled_deepslate
fill 506 138 316 506 139 316 minecraft:deepslate_tiles
setblock 510 138 306 minecraft:cobbled_deepslate
setblock 510 138 307 minecraft:deepslate_tiles
setblock 511 138 290 minecraft:cobbled_deepslate
fill 511 138 291 511 139 291 minecraft:deepslate_tiles
setblock 511 138 305 minecraft:cobbled_deepslate
fill 511 138 306 511 139 306 minecraft:deepslate_tiles
setblock 511 138 310 minecraft:cobbled_deepslate
fill 511 138 311 511 139 311 minecraft:deepslate_tiles
fill 470 139 283 470 201 283 minecraft:black_concrete
setblock 471 139 284 minecraft:cobbled_deepslate
setblock 471 139 285 minecraft:deepslate_tiles
setblock 471 139 289 minecraft:cobbled_deepslate
setblock 471 139 290 minecraft:deepslate_tiles
setblock 471 139 294 minecraft:cobbled_deepslate
setblock 472 139 288 minecraft:cobbled_deepslate
setblock 472 139 289 minecraft:deepslate_tiles
setblock 473 139 278 minecraft:light[level=12]
setblock 473 139 285 minecraft:light[level=12]
setblock 473 139 292 minecraft:light[level=12]
setblock 473 139 299 minecraft:light[level=12]
setblock 473 139 306 minecraft:light[level=12]
setblock 473 139 313 minecraft:light[level=12]
setblock 479 139 276 minecraft:cobbled_deepslate
setblock 479 139 316 minecraft:cobbled_deepslate
fill 480 139 276 483 139 276 minecraft:deepslate_tiles
setblock 480 139 278 minecraft:light[level=12]
setblock 480 139 285 minecraft:light[level=12]
setblock 480 139 292 minecraft:light[level=12]
setblock 480 139 299 minecraft:light[level=12]
setblock 480 139 306 minecraft:light[level=12]
setblock 480 139 313 minecraft:light[level=12]
setblock 480 139 316 minecraft:deepslate_tiles
fill 481 139 277 482 139 277 minecraft:deepslate_tiles
setblock 482 139 315 minecraft:deepslate_tiles
setblock 483 139 277 minecraft:cobbled_deepslate
setblock 484 139 276 minecraft:cobbled_deepslate
setblock 484 139 316 minecraft:cobbled_deepslate
setblock 485 139 276 minecraft:deepslate_tiles
setblock 485 139 316 minecraft:deepslate_tiles
setblock 487 139 278 minecraft:light[level=12]
setblock 487 139 285 minecraft:light[level=12]
setblock 487 139 292 minecraft:light[level=12]
setblock 487 139 299 minecraft:light[level=12]
setblock 487 139 306 minecraft:light[level=12]
setblock 487 139 313 minecraft:light[level=12]
setblock 493 139 316 minecraft:deepslate_tiles
setblock 494 139 278 minecraft:light[level=12]
setblock 494 139 285 minecraft:light[level=12]
setblock 494 139 292 minecraft:light[level=12]
setblock 494 139 299 minecraft:light[level=12]
setblock 494 139 306 minecraft:light[level=12]
setblock 494 139 313 minecraft:light[level=12]
setblock 494 139 316 minecraft:cobbled_deepslate
setblock 495 139 316 minecraft:deepslate_tiles
setblock 496 139 315 minecraft:deepslate_tiles
setblock 499 139 276 minecraft:cobbled_deepslate
setblock 499 139 316 minecraft:cobbled_deepslate
setblock 500 139 276 minecraft:deepslate_tiles
setblock 500 139 315 minecraft:cobbled_deepslate
setblock 500 139 316 minecraft:deepslate_tiles
setblock 501 139 278 minecraft:light[level=12]
setblock 501 139 285 minecraft:light[level=12]
setblock 501 139 292 minecraft:light[level=12]
setblock 501 139 299 minecraft:light[level=12]
setblock 501 139 306 minecraft:light[level=12]
setblock 501 139 313 minecraft:deepslate_tiles
setblock 501 139 314 minecraft:cobbled_deepslate
setblock 501 139 315 minecraft:deepslate_tiles
setblock 502 139 314 minecraft:deepslate_tiles
setblock 504 139 316 minecraft:cobbled_deepslate
setblock 505 139 315 minecraft:cobbled_deepslate
setblock 505 139 316 minecraft:deepslate_tiles
setblock 508 139 278 minecraft:light[level=12]
setblock 508 139 285 minecraft:light[level=12]
setblock 508 139 292 minecraft:light[level=12]
setblock 508 139 299 minecraft:light[level=12]
setblock 508 139 306 minecraft:light[level=12]
setblock 508 139 313 minecraft:light[level=12]
setblock 511 139 289 minecraft:cobbled_deepslate
setblock 511 139 290 minecraft:deepslate_tiles
setblock 511 139 305 minecraft:deepslate_tiles
setblock 511 139 309 minecraft:cobbled_deepslate
setblock 511 139 310 minecraft:deepslate_tiles
setblock 473 141 278 minecraft:light[level=13]
setblock 473 141 286 minecraft:light[level=13]
setblock 473 141 294 minecraft:light[level=13]
setblock 473 141 302 minecraft:light[level=13]
setblock 473 141 310 minecraft:light[level=13]
setblock 481 141 278 minecraft:light[level=13]
setblock 481 141 286 minecraft:light[level=13]
setblock 481 141 294 minecraft:light[level=13]
setblock 481 141 302 minecraft:light[level=13]
setblock 481 141 310 minecraft:light[level=13]
setblock 489 141 278 minecraft:light[level=13]
setblock 489 141 286 minecraft:light[level=13]
setblock 489 141 294 minecraft:light[level=13]
setblock 489 141 302 minecraft:light[level=13]
setblock 489 141 310 minecraft:light[level=13]
setblock 489 141 317 minecraft:redstone_block
fill 490 141 317 490 195 317 minecraft:black_concrete
setblock 497 141 278 minecraft:light[level=13]
setblock 497 141 286 minecraft:light[level=13]
setblock 497 141 294 minecraft:light[level=13]
setblock 497 141 302 minecraft:light[level=13]
setblock 497 141 310 minecraft:light[level=13]
setblock 505 141 278 minecraft:light[level=13]
setblock 505 141 286 minecraft:light[level=13]
setblock 505 141 294 minecraft:light[level=13]
setblock 505 141 302 minecraft:light[level=13]
setblock 505 141 310 minecraft:light[level=13]
fill 485 142 317 487 185 317 minecraft:black_concrete
setblock 488 142 317 minecraft:white_wool
fill 489 142 317 489 160 317 minecraft:black_concrete
setblock 494 142 317 minecraft:redstone_block
fill 488 143 317 488 190 317 minecraft:black_concrete
fill 494 143 317 494 198 317 minecraft:black_concrete
setblock 470 144 294 minecraft:white_wool
setblock 503 144 276 minecraft:white_wool
setblock 504 144 277 minecraft:white_wool
setblock 505 144 278 minecraft:white_wool
setblock 506 144 279 minecraft:white_wool
fill 470 145 285 470 202 285 minecraft:black_concrete
setblock 470 145 286 minecraft:redstone_block
fill 470 145 294 470 198 294 minecraft:black_concrete
fill 471 145 276 471 146 276 minecraft:white_terracotta
fill 471 145 277 471 146 279 minecraft:white_wool
fill 471 145 280 471 146 280 minecraft:white_terracotta
fill 471 145 281 471 146 283 minecraft:white_wool
fill 471 145 284 471 146 284 minecraft:white_terracotta
fill 471 145 285 471 146 287 minecraft:white_wool
fill 471 145 288 471 146 288 minecraft:white_terracotta
fill 471 145 289 471 146 291 minecraft:white_wool
fill 471 145 292 471 146 292 minecraft:white_terracotta
fill 471 145 293 471 146 295 minecraft:white_wool
fill 471 145 296 471 146 296 minecraft:white_terracotta
fill 471 145 297 471 146 299 minecraft:white_wool
fill 471 145 300 471 146 300 minecraft:white_terracotta
fill 471 145 301 471 146 303 minecraft:white_wool
fill 471 145 304 471 146 304 minecraft:white_terracotta
fill 471 145 305 471 146 307 minecraft:white_wool
fill 471 145 308 471 146 308 minecraft:white_terracotta
fill 471 145 309 471 146 311 minecraft:white_wool
fill 471 145 312 471 146 312 minecraft:white_terracotta
fill 471 145 313 471 146 315 minecraft:white_wool
fill 471 145 316 471 146 316 minecraft:white_terracotta
fill 472 145 276 474 146 276 minecraft:white_wool
fill 472 145 277 472 146 277 minecraft:white_terracotta
fill 472 145 278 472 146 280 minecraft:white_wool
fill 472 145 281 472 146 281 minecraft:white_terracotta
fill 472 145 282 472 146 284 minecraft:white_wool
fill 472 145 285 472 146 285 minecraft:white_terracotta
fill 472 145 286 472 146 288 minecraft:white_wool
fill 472 145 289 472 146 289 minecraft:white_terracotta
fill 472 145 290 472 146 292 minecraft:white_wool
fill 472 145 293 472 146 293 minecraft:white_terracotta
fill 472 145 294 472 146 296 minecraft:white_wool
fill 472 145 297 472 146 297 minecraft:white_terracotta
fill 472 145 298 472 146 300 minecraft:white_wool
fill 472 145 301 472 146 301 minecraft:white_terracotta
fill 472 145 302 472 146 304 minecraft:white_wool
fill 472 145 305 472 146 305 minecraft:white_terracotta
fill 472 145 306 472 146 308 minecraft:white_wool
fill 472 145 309 472 146 309 minecraft:white_terracotta
fill 472 145 310 472 146 312 minecraft:white_wool
fill 472 145 313 472 146 313 minecraft:white_terracotta
fill 472 145 314 472 146 316 minecraft:white_wool
fill 473 145 277 475 146 277 minecraft:white_wool
fill 473 145 278 473 146 278 minecraft:white_terracotta
fill 473 145 279 473 146 281 minecraft:white_wool
fill 473 145 282 473 146 282 minecraft:white_terracotta
fill 473 145 283 473 146 285 minecraft:white_wool
fill 473 145 286 473 146 286 minecraft:white_terracotta
fill 473 145 287 473 146 289 minecraft:white_wool
fill 473 145 290 473 146 290 minecraft:white_terracotta
fill 473 145 291 473 146 293 minecraft:white_wool
fill 473 145 294 473 146 294 minecraft:white_terracotta
fill 473 145 295 473 146 297 minecraft:white_wool
fill 473 145 298 473 146 298 minecraft:white_terracotta
fill 473 145 299 473 146 301 minecraft:white_wool
fill 473 145 302 473 146 302 minecraft:white_terracotta
fill 473 145 303 473 146 305 minecraft:white_wool
fill 473 145 306 473 146 306 minecraft:white_terracotta
fill 473 145 307 473 146 309 minecraft:white_wool
fill 473 145 310 473 146 310 minecraft:white_terracotta
fill 473 145 311 473 146 313 minecraft:white_wool
fill 473 145 314 473 146 314 minecraft:white_terracotta
fill 473 145 315 473 145 317 minecraft:white_wool
fill 474 145 278 476 146 278 minecraft:white_wool
fill 474 145 279 474 146 279 minecraft:white_terracotta
fill 474 145 280 474 146 282 minecraft:white_wool
fill 474 145 283 474 146 283 minecraft:white_terracotta
fill 474 145 284 474 146 286 minecraft:white_wool
fill 474 145 287 474 146 287 minecraft:white_terracotta
fill 474 145 288 474 146 290 minecraft:white_wool
fill 474 145 291 474 146 291 minecraft:white_terracotta
fill 474 145 292 474 146 294 minecraft:white_wool
fill 474 145 295 474 146 295 minecraft:white_terracotta
fill 474 145 296 474 146 298 minecraft:white_wool
fill 474 145 299 474 146 299 minecraft:white_terracotta
fill 474 145 300 474 146 302 minecraft:white_wool
fill 474 145 303 474 146 303 minecraft:white_terracotta
fill 474 145 304 474 146 306 minecraft:white_wool
fill 474 145 307 474 146 307 minecraft:white_terracotta
fill 474 145 308 474 146 310 minecraft:white_wool
fill 474 145 311 474 146 311 minecraft:white_terracotta
fill 474 145 312 474 146 314 minecraft:white_wool
fill 474 145 315 474 146 315 minecraft:white_terracotta
fill 474 145 316 474 146 316 minecraft:white_wool
fill 475 145 276 475 146 276 minecraft:white_terracotta
fill 475 145 279 477 146 279 minecraft:white_wool
fill 475 145 280 475 148 280 minecraft:white_terracotta
fill 475 145 281 475 146 283 minecraft:white_wool
fill 475 145 284 475 146 284 minecraft:white_terracotta
fill 475 145 285 475 146 287 minecraft:white_wool
fill 475 145 288 475 146 288 minecraft:white_terracotta
fill 475 145 289 475 146 291 minecraft:white_wool
fill 475 145 292 475 146 292 minecraft:white_terracotta
fill 475 145 293 475 146 295 minecraft:white_wool
fill 475 145 296 475 146 296 minecraft:white_terracotta
fill 475 145 297 475 146 299 minecraft:white_wool
fill 475 145 300 475 146 300 minecraft:white_terracotta
fill 475 145 301 475 146 303 minecraft:white_wool
fill 475 145 304 475 146 304 minecraft:white_terracotta
fill 475 145 305 475 146 307 minecraft:white_wool
fill 475 145 308 475 148 308 minecraft:white_terracotta
fill 475 145 309 475 145 311 minecraft:white_wool
fill 475 145 312 475 146 312 minecraft:white_terracotta
fill 475 145 313 475 146 315 minecraft:white_wool
fill 475 145 316 475 146 316 minecraft:white_terracotta
fill 476 145 276 478 146 276 minecraft:white_wool
fill 476 145 277 476 146 277 minecraft:white_terracotta
fill 476 145 280 478 145 280 minecraft:white_wool
fill 476 145 281 476 148 281 minecraft:white_terracotta
fill 476 145 282 476 146 284 minecraft:white_wool
fill 476 145 285 476 146 285 minecraft:white_terracotta
fill 476 145 286 476 146 288 minecraft:white_wool
fill 476 145 289 476 146 289 minecraft:white_terracotta
fill 476 145 290 476 145 292 minecraft:white_wool
fill 476 145 293 476 146 293 minecraft:white_terracotta
fill 476 145 294 476 146 296 minecraft:white_wool
fill 476 145 297 476 146 297 minecraft:white_terracotta
fill 476 145 298 476 146 300 minecraft:white_wool
fill 476 145 301 476 146 301 minecraft:white_terracotta
fill 476 145 302 476 146 304 minecraft:white_wool
fill 476 145 305 476 146 305 minecraft:white_terracotta
fill 476 145 306 476 145 308 minecraft:white_wool
fill 476 145 309 476 148 309 minecraft:white_terracotta
fill 476 145 310 476 146 312 minecraft:white_wool
fill 476 145 313 476 146 313 minecraft:white_terracotta
fill 476 145 314 476 146 316 minecraft:white_wool
fill 477 145 277 479 146 277 minecraft:white_wool
fill 477 145 278 477 146 278 minecraft:white_terracotta
fill 477 145 281 479 145 281 minecraft:white_wool
fill 477 145 282 477 146 282 minecraft:white_terracotta
fill 477 145 283 477 146 285 minecraft:white_wool
fill 477 145 286 477 146 286 minecraft:white_terracotta
fill 477 145 287 477 146 289 minecraft:white_wool
fill 477 145 290 477 146 290 minecraft:white_terracotta
fill 477 145 291 477 145 293 minecraft:white_wool
fill 477 145 294 477 146 294 minecraft:white_terracotta
fill 477 145 295 477 146 297 minecraft:white_wool
fill 477 145 298 477 146 298 minecraft:white_terracotta
fill 477 145 299 477 146 301 minecraft:white_wool
fill 477 145 302 477 146 302 minecraft:white_terracotta
fill 477 145 303 477 146 305 minecraft:white_wool
fill 477 145 306 477 146 306 minecraft:white_terracotta
fill 477 145 307 477 146 309 minecraft:white_wool
fill 477 145 310 477 146 310 minecraft:white_terracotta
fill 477 145 311 477 146 313 minecraft:white_wool
fill 477 145 314 477 146 314 minecraft:white_terracotta
fill 477 145 315 477 146 316 minecraft:white_wool
fill 478 145 278 480 146 278 minecraft:white_wool
fill 478 145 279 478 146 279 minecraft:white_terracotta
fill 478 145 282 480 146 282 minecraft:white_wool
fill 478 145 283 478 146 283 minecraft:white_terracotta
fill 478 145 284 478 146 286 minecraft:white_wool
fill 478 145 287 478 146 287 minecraft:white_terracotta
fill 478 145 288 478 146 290 minecraft:white_wool
fill 478 145 291 478 146 291 minecraft:white_terracotta
fill 478 145 292 478 146 294 minecraft:white_wool
fill 478 145 295 478 146 295 minecraft:white_terracotta
fill 478 145 296 478 146 298 minecraft:white_wool
fill 478 145 299 478 146 299 minecraft:white_terracotta
fill 478 145 300 478 146 302 minecraft:white_wool
fill 478 145 303 478 146 303 minecraft:white_terracotta
fill 478 145 304 478 146 306 minecraft:white_wool
fill 478 145 307 478 146 307 minecraft:white_terracotta
fill 478 145 308 478 146 310 minecraft:white_wool
fill 478 145 311 478 146 311 minecraft:white_terracotta
fill 478 145 312 478 146 314 minecraft:white_wool
fill 478 145 315 478 146 315 minecraft:white_terracotta
fill 478 145 316 478 146 316 minecraft:white_wool
fill 479 145 276 479 146 276 minecraft:white_terracotta
fill 479 145 279 481 146 279 minecraft:white_wool
fill 479 145 280 479 146 280 minecraft:white_terracotta
fill 479 145 283 481 146 283 minecraft:white_wool
fill 479 145 284 479 146 284 minecraft:white_terracotta
fill 479 145 285 479 146 287 minecraft:white_wool
fill 479 145 288 479 146 288 minecraft:white_terracotta
fill 479 145 289 479 146 291 minecraft:white_wool
fill 479 145 292 479 146 292 minecraft:white_terracotta
fill 479 145 293 479 146 295 minecraft:white_wool
fill 479 145 296 479 146 296 minecraft:white_terracotta
fill 479 145 297 479 146 299 minecraft:white_wool
fill 479 145 300 479 146 300 minecraft:white_terracotta
fill 479 145 301 479 146 303 minecraft:white_wool
fill 479 145 304 479 146 304 minecraft:white_terracotta
fill 479 145 305 479 146 307 minecraft:white_wool
fill 479 145 308 479 146 308 minecraft:white_terracotta
fill 479 145 309 479 146 311 minecraft:white_wool
fill 479 145 312 479 146 312 minecraft:white_terracotta
fill 479 145 313 479 146 315 minecraft:white_wool
fill 479 145 316 479 146 316 minecraft:white_terracotta
fill 480 145 276 482 146 276 minecraft:white_wool
fill 480 145 277 480 146 277 minecraft:white_terracotta
fill 480 145 280 482 146 280 minecraft:white_wool
fill 480 145 281 480 146 281 minecraft:white_terracotta
fill 480 145 284 482 146 284 minecraft:white_wool
fill 480 145 285 480 146 285 minecraft:white_terracotta
fill 480 145 286 480 146 288 minecraft:white_wool
fill 480 145 289 480 146 289 minecraft:white_terracotta
fill 480 145 290 480 145 292 minecraft:white_wool
setblock 480 145 293 minecraft:white_terracotta
fill 480 145 294 480 145 296 minecraft:white_wool
fill 480 145 297 480 146 297 minecraft:white_terracotta
fill 480 145 298 480 146 300 minecraft:white_wool
fill 480 145 301 480 146 301 minecraft:white_terracotta
fill 480 145 302 480 146 304 minecraft:white_wool
fill 480 145 305 480 146 305 minecraft:white_terracotta
fill 480 145 306 480 146 308 minecraft:white_wool
fill 480 145 309 480 146 309 minecraft:white_terracotta
fill 480 145 310 480 146 312 minecraft:white_wool
fill 480 145 313 480 146 313 minecraft:white_terracotta
fill 480 145 314 480 146 316 minecraft:white_wool
fill 481 145 277 483 146 277 minecraft:white_wool
fill 481 145 278 481 146 278 minecraft:white_terracotta
fill 481 145 281 483 146 281 minecraft:white_wool
fill 481 145 282 481 146 282 minecraft:white_terracotta
fill 481 145 285 483 146 285 minecraft:white_wool
fill 481 145 286 481 146 286 minecraft:white_terracotta
fill 481 145 287 481 146 289 minecraft:white_wool
fill 481 145 290 481 146 290 minecraft:white_terracotta
fill 481 145 291 481 145 292 minecraft:white_wool
fill 481 145 296 481 145 297 minecraft:white_wool
fill 481 145 298 481 146 298 minecraft:white_terracotta
fill 481 145 299 481 146 301 minecraft:white_wool
fill 481 145 302 481 146 302 minecraft:white_terracotta
fill 481 145 303 481 146 305 minecraft:white_wool
fill 481 145 306 481 146 306 minecraft:white_terracotta
fill 481 145 307 481 146 309 minecraft:white_wool
fill 481 145 310 481 146 310 minecraft:white_terracotta
fill 481 145 311 481 146 313 minecraft:white_wool
fill 481 145 314 481 146 314 minecraft:white_terracotta
fill 481 145 315 481 146 316 minecraft:white_wool
fill 482 145 278 484 146 278 minecraft:white_wool
fill 482 145 279 482 146 279 minecraft:white_terracotta
fill 482 145 282 484 146 282 minecraft:white_wool
fill 482 145 283 482 146 283 minecraft:white_terracotta
fill 482 145 286 484 146 286 minecraft:white_wool
fill 482 145 287 482 146 287 minecraft:white_terracotta
fill 482 145 288 482 146 290 minecraft:white_wool
setblock 482 145 291 minecraft:white_terracotta
fill 482 145 297 483 145 298 minecraft:white_wool
fill 482 145 299 482 146 299 minecraft:white_terracotta
fill 482 145 300 482 146 302 minecraft:white_wool
fill 482 145 303 482 146 303 minecraft:white_terracotta
fill 482 145 304 482 146 306 minecraft:white_wool
fill 482 145 307 482 146 307 minecraft:white_terracotta
fill 482 145 308 482 146 310 minecraft:white_wool
fill 482 145 311 482 146 311 minecraft:white_terracotta
fill 482 145 312 482 146 314 minecraft:white_wool
fill 482 145 315 482 146 315 minecraft:white_terracotta
fill 482 145 316 482 146 316 minecraft:white_wool
fill 483 145 276 483 146 276 minecraft:white_terracotta
fill 483 145 279 485 146 279 minecraft:white_wool
fill 483 145 280 483 146 280 minecraft:white_terracotta
fill 483 145 283 485 146 283 minecraft:white_wool
fill 483 145 284 483 146 284 minecraft:white_terracotta
fill 483 145 287 485 146 287 minecraft:white_wool
fill 483 145 288 483 146 288 minecraft:white_terracotta
fill 483 145 289 483 145 291 minecraft:white_wool
fill 483 145 299 485 146 299 minecraft:white_wool
fill 483 145 300 483 146 300 minecraft:white_terracotta
fill 483 145 301 483 146 303 minecraft:white_wool
fill 483 145 304 483 146 304 minecraft:white_terracotta
fill 483 145 305 483 146 307 minecraft:white_wool
fill 483 145 308 483 146 308 minecraft:white_terracotta
fill 483 145 309 483 146 311 minecraft:white_wool
fill 483 145 312 483 146 312 minecraft:white_terracotta
fill 483 145 313 483 146 315 minecraft:white_wool
fill 483 145 316 483 146 316 minecraft:white_terracotta
fill 484 145 276 486 146 276 minecraft:white_wool
fill 484 145 277 484 146 277 minecraft:white_terracotta
fill 484 145 280 486 146 280 minecraft:white_wool
fill 484 145 281 484 146 281 minecraft:white_terracotta
fill 484 145 284 486 146 284 minecraft:white_wool
fill 484 145 285 484 146 285 minecraft:white_terracotta
fill 484 145 288 486 146 288 minecraft:white_wool
fill 484 145 289 484 146 289 minecraft:white_terracotta
fill 484 145 290 484 145 291 minecraft:white_wool
setblock 484 145 297 minecraft:white_terracotta
fill 484 145 298 484 146 298 minecraft:white_wool
fill 484 145 300 486 146 300 minecraft:white_wool
fill 484 145 301 484 146 301 minecraft:white_terracotta
fill 484 145 302 484 146 304 minecraft:white_wool
fill 484 145 305 484 146 305 minecraft:white_terracotta
fill 484 145 306 484 146 308 minecraft:white_wool
fill 484 145 309 484 146 309 minecraft:white_terracotta
fill 484 145 310 484 146 312 minecraft:white_wool
fill 484 145 313 484 146 313 minecraft:white_terracotta
fill 484 145 314 484 146 316 minecraft:white_wool
fill 485 145 277 487 146 277 minecraft:white_wool
fill 485 145 278 485 146 278 minecraft:white_terracotta
fill 485 145 281 487 146 281 minecraft:white_wool
fill 485 145 282 485 146 282 minecraft:white_terracotta
fill 485 145 285 487 146 285 minecraft:white_wool
fill 485 145 286 485 146 286 minecraft:white_terracotta
fill 485 145 289 487 146 289 minecraft:white_wool
fill 485 145 290 485 148 290 minecraft:white_terracotta
fill 485 145 291 485 145 292 minecraft:white_wool
fill 485 145 296 486 145 297 minecraft:white_wool
fill 485 145 298 485 146 298 minecraft:white_terracotta
fill 485 145 301 487 146 301 minecraft:white_wool
fill 485 145 302 485 146 302 minecraft:white_terracotta
fill 485 145 303 485 146 305 minecraft:white_wool
fill 485 145 306 485 146 306 minecraft:white_terracotta
fill 485 145 307 485 146 309 minecraft:white_wool
fill 485 145 310 485 146 310 minecraft:white_terracotta
fill 485 145 311 485 146 313 minecraft:white_wool
fill 485 145 314 485 146 314 minecraft:white_terracotta
fill 485 145 315 485 146 316 minecraft:white_wool
fill 486 145 278 488 146 278 minecraft:white_wool
fill 486 145 279 486 146 279 minecraft:white_terracotta
fill 486 145 282 488 146 282 minecraft:white_wool
fill 486 145 283 486 146 283 minecraft:white_terracotta
fill 486 145 286 488 146 286 minecraft:white_wool
fill 486 145 287 486 146 287 minecraft:white_terracotta
fill 486 145 290 488 145 290 minecraft:white_wool
fill 486 145 291 486 148 291 minecraft:white_terracotta
fill 486 145 292 486 145 294 minecraft:white_wool
setblock 486 145 295 minecraft:white_terracotta
fill 486 145 298 488 146 298 minecraft:white_wool
fill 486 145 299 486 146 299 minecraft:white_terracotta
fill 486 145 302 488 146 302 minecraft:white_wool
fill 486 145 303 486 146 303 minecraft:white_terracotta
fill 486 145 304 486 146 306 minecraft:white_wool
fill 486 145 307 486 146 307 minecraft:white_terracotta
fill 486 145 308 486 146 310 minecraft:white_wool
fill 486 145 311 486 146 311 minecraft:white_terracotta
fill 486 145 312 486 146 314 minecraft:white_wool
fill 486 145 315 486 146 315 minecraft:white_terracotta
fill 486 145 316 486 146 316 minecraft:white_wool
fill 487 145 276 487 146 276 minecraft:white_terracotta
fill 487 145 279 489 146 279 minecraft:white_wool
fill 487 145 280 487 146 280 minecraft:white_terracotta
fill 487 145 283 489 146 283 minecraft:white_wool
fill 487 145 284 487 146 284 minecraft:white_terracotta
fill 487 145 287 489 145 287 minecraft:white_wool
fill 487 145 288 487 146 288 minecraft:white_terracotta
fill 487 145 291 489 146 291 minecraft:white_wool
fill 487 145 292 487 146 292 minecraft:white_terracotta
fill 487 145 293 487 146 295 minecraft:white_wool
fill 487 145 296 487 146 296 minecraft:white_terracotta
fill 487 145 297 487 146 297 minecraft:white_wool
fill 487 145 299 489 146 299 minecraft:white_wool
fill 487 145 300 487 146 300 minecraft:white_terracotta
fill 487 145 303 489 146 303 minecraft:white_wool
fill 487 145 304 487 146 304 minecraft:white_terracotta
fill 487 145 305 487 146 307 minecraft:white_wool
fill 487 145 308 487 146 308 minecraft:white_terracotta
fill 487 145 309 487 146 311 minecraft:white_wool
fill 487 145 312 487 146 312 minecraft:white_terracotta
fill 487 145 313 487 146 315 minecraft:white_wool
fill 487 145 316 487 146 316 minecraft:white_terracotta
fill 488 145 276 490 146 276 minecraft:white_wool
fill 488 145 277 488 146 277 minecraft:white_terracotta
fill 488 145 280 490 146 280 minecraft:white_wool
fill 488 145 281 488 146 281 minecraft:white_terracotta
fill 488 145 284 490 146 284 minecraft:white_wool
fill 488 145 285 488 146 285 minecraft:white_terracotta
fill 488 145 288 490 146 288 minecraft:white_wool
fill 488 145 289 488 146 289 minecraft:white_terracotta
fill 488 145 292 490 146 292 minecraft:white_wool
fill 488 145 293 488 146 293 minecraft:white_terracotta
fill 488 145 294 488 146 296 minecraft:white_wool
fill 488 145 297 488 146 297 minecraft:white_terracotta
fill 488 145 300 490 146 300 minecraft:white_wool
fill 488 145 301 488 146 301 minecraft:white_terracotta
fill 488 145 304 490 146 304 minecraft:white_wool
fill 488 145 305 488 146 305 minecraft:white_terracotta
fill 488 145 306 488 146 308 minecraft:white_wool
fill 488 145 309 488 146 309 minecraft:white_terracotta
fill 488 145 310 488 146 312 minecraft:white_wool
fill 488 145 313 488 146 313 minecraft:white_terracotta
fill 488 145 314 488 146 316 minecraft:white_wool
fill 489 145 277 491 146 277 minecraft:white_wool
fill 489 145 278 489 146 278 minecraft:white_terracotta
fill 489 145 281 491 146 281 minecraft:white_wool
fill 489 145 282 489 146 282 minecraft:white_terracotta
fill 489 145 285 491 146 285 minecraft:white_wool
fill 489 145 286 489 146 286 minecraft:white_terracotta
fill 489 145 289 491 146 289 minecraft:white_wool
fill 489 145 290 489 146 290 minecraft:white_terracotta
fill 489 145 293 491 146 293 minecraft:white_wool
fill 489 145 294 489 146 294 minecraft:white_terracotta
fill 489 145 295 489 146 297 minecraft:white_wool
fill 489 145 298 489 146 298 minecraft:white_terracotta
fill 489 145 301 491 146 301 minecraft:white_wool
fill 489 145 302 489 146 302 minecraft:white_terracotta
fill 489 145 305 491 146 305 minecraft:white_wool
fill 489 145 306 489 146 306 minecraft:white_terracotta
fill 489 145 307 489 146 309 minecraft:white_wool
fill 489 145 310 489 146 310 minecraft:white_terracotta
fill 489 145 311 489 146 313 minecraft:white_wool
fill 489 145 314 489 146 314 minecraft:white_terracotta
fill 489 145 315 489 146 316 minecraft:white_wool
fill 490 145 278 492 146 278 minecraft:white_wool
fill 490 145 279 490 146 279 minecraft:white_terracotta
fill 490 145 282 492 146 282 minecraft:white_wool
fill 490 145 283 490 146 283 minecraft:white_terracotta
fill 490 145 286 492 145 286 minecraft:white_wool
fill 490 145 287 490 146 287 minecraft:white_terracotta
fill 490 145 290 492 145 290 minecraft:white_wool
fill 490 145 291 490 146 291 minecraft:white_terracotta
fill 490 145 294 492 146 294 minecraft:white_wool
fill 490 145 295 490 146 295 minecraft:white_terracotta
fill 490 145 296 490 146 298 minecraft:white_wool
fill 490 145 299 490 146 299 minecraft:white_terracotta
fill 490 145 302 492 146 302 minecraft:white_wool
fill 490 145 303 490 146 303 minecraft:white_terracotta
fill 490 145 306 492 146 306 minecraft:white_wool
fill 490 145 307 490 146 307 minecraft:white_terracotta
fill 490 145 308 490 146 310 minecraft:white_wool
fill 490 145 311 490 146 311 minecraft:white_terracotta
fill 490 145 312 490 146 314 minecraft:white_wool
fill 490 145 315 490 146 315 minecraft:white_terracotta
fill 490 145 316 490 146 316 minecraft:white_wool
fill 491 145 276 491 146 276 minecraft:white_terracotta
fill 491 145 279 493 146 279 minecraft:white_wool
fill 491 145 280 491 146 280 minecraft:white_terracotta
fill 491 145 283 493 146 283 minecraft:white_wool
fill 491 145 284 491 146 284 minecraft:white_terracotta
fill 491 145 287 493 146 287 minecraft:white_wool
fill 491 145 288 491 146 288 minecraft:white_terracotta
fill 491 145 291 493 146 291 minecraft:white_wool
fill 491 145 292 491 146 292 minecraft:white_terracotta
fill 491 145 295 493 146 295 minecraft:white_wool
fill 491 145 296 491 146 296 minecraft:white_terracotta
fill 491 145 297 491 146 299 minecraft:white_wool
fill 491 145 300 491 146 300 minecraft:white_terracotta
fill 491 145 303 493 146 303 minecraft:white_wool
fill 491 145 304 491 146 304 minecraft:white_terracotta
fill 491 145 307 493 146 307 minecraft:white_wool
fill 491 145 308 491 146 308 minecraft:white_terracotta
fill 491 145 309 491 146 311 minecraft:white_wool
fill 491 145 312 491 146 312 minecraft:white_terracotta
fill 491 145 313 491 146 315 minecraft:white_wool
fill 491 145 316 491 146 316 minecraft:white_terracotta
fill 492 145 276 494 146 276 minecraft:white_wool
fill 492 145 277 492 146 277 minecraft:white_terracotta
fill 492 145 280 494 146 280 minecraft:white_wool
fill 492 145 281 492 146 281 minecraft:white_terracotta
fill 492 145 284 494 146 284 minecraft:white_wool
fill 492 145 285 492 146 285 minecraft:white_terracotta
fill 492 145 288 494 145 288 minecraft:white_wool
fill 492 145 289 492 146 289 minecraft:white_terracotta
fill 492 145 292 494 145 292 minecraft:white_wool
fill 492 145 293 492 146 293 minecraft:white_terracotta
fill 492 145 296 494 146 296 minecraft:white_wool
fill 492 145 297 492 146 297 minecraft:white_terracotta
fill 492 145 298 492 146 300 minecraft:white_wool
fill 492 145 301 492 146 301 minecraft:white_terracotta
fill 492 145 304 494 146 304 minecraft:white_wool
fill 492 145 305 492 146 305 minecraft:white_terracotta
fill 492 145 308 494 146 308 minecraft:white_wool
fill 492 145 309 492 146 309 minecraft:white_terracotta
fill 492 145 310 492 146 312 minecraft:white_wool
fill 492 145 313 492 146 313 minecraft:white_terracotta
fill 492 145 314 492 146 316 minecraft:white_wool
fill 493 145 277 495 146 277 minecraft:white_wool
fill 493 145 278 493 146 278 minecraft:white_terracotta
fill 493 145 281 495 145 281 minecraft:white_wool
fill 493 145 282 493 148 282 minecraft:white_terracotta
fill 493 145 285 495 146 285 minecraft:white_wool
fill 493 145 286 493 146 286 minecraft:white_terracotta
fill 493 145 289 495 145 289 minecraft:white_wool
fill 493 145 290 493 146 290 minecraft:white_terracotta
fill 493 145 293 495 145 293 minecraft:white_wool
fill 493 145 294 493 146 294 minecraft:white_terracotta
fill 493 145 297 495 146 297 minecraft:white_wool
fill 493 145 298 493 146 298 minecraft:white_terracotta
fill 493 145 299 493 146 301 minecraft:white_wool
fill 493 145 302 493 146 302 minecraft:white_terracotta
fill 493 145 305 495 146 305 minecraft:white_wool
fill 493 145 306 493 146 306 minecraft:white_terracotta
fill 493 145 309 495 146 309 minecraft:white_wool
fill 493 145 310 493 146 310 minecraft:white_terracotta
fill 493 145 311 493 146 313 minecraft:white_wool
fill 493 145 314 493 146 314 minecraft:white_terracotta
fill 493 145 315 493 146 316 minecraft:white_wool
fill 494 145 278 496 146 278 minecraft:white_wool
fill 494 145 279 494 146 279 minecraft:white_terracotta
fill 494 145 282 496 145 282 minecraft:white_wool
fill 494 145 283 494 147 283 minecraft:white_terracotta
fill 494 145 286 496 146 286 minecraft:white_wool
fill 494 145 287 494 146 287 minecraft:white_terracotta
fill 494 145 290 496 146 290 minecraft:white_wool
fill 494 145 291 494 146 291 minecraft:white_terracotta
fill 494 145 294 496 145 294 minecraft:white_wool
fill 494 145 295 494 146 295 minecraft:white_terracotta
fill 494 145 298 496 145 298 minecraft:white_wool
fill 494 145 299 494 146 299 minecraft:white_terracotta
fill 494 145 300 494 146 302 minecraft:white_wool
fill 494 145 303 494 146 303 minecraft:white_terracotta
fill 494 145 306 496 146 306 minecraft:white_wool
fill 494 145 307 494 146 307 minecraft:white_terracotta
fill 494 145 310 496 146 310 minecraft:white_wool
fill 494 145 311 494 146 311 minecraft:white_terracotta
fill 494 145 312 494 146 314 minecraft:white_wool
fill 494 145 315 494 146 315 minecraft:white_terracotta
fill 494 145 316 494 146 316 minecraft:white_wool
fill 495 145 276 495 146 276 minecraft:white_terracotta
fill 495 145 279 497 146 279 minecraft:white_wool
fill 495 145 280 495 146 280 minecraft:white_terracotta
fill 495 145 283 497 146 283 minecraft:white_wool
fill 495 145 284 495 146 284 minecraft:white_terracotta
fill 495 145 287 497 146 287 minecraft:white_wool
fill 495 145 288 495 146 288 minecraft:white_terracotta
fill 495 145 291 497 146 291 minecraft:white_wool
fill 495 145 292 495 146 292 minecraft:white_terracotta
fill 495 145 295 497 146 295 minecraft:white_wool
fill 495 145 296 495 146 296 minecraft:white_terracotta
fill 495 145 299 497 146 299 minecraft:white_wool
fill 495 145 300 495 146 300 minecraft:white_terracotta
fill 495 145 301 495 146 303 minecraft:white_wool
fill 495 145 304 495 146 304 minecraft:white_terracotta
fill 495 145 307 497 146 307 minecraft:white_wool
fill 495 145 308 495 146 308 minecraft:white_terracotta
fill 495 145 311 497 146 311 minecraft:white_wool
fill 495 145 312 495 146 312 minecraft:white_terracotta
fill 495 145 313 495 146 315 minecraft:white_wool
fill 495 145 316 495 146 316 minecraft:white_terracotta
fill 496 145 276 498 146 276 minecraft:white_wool
fill 496 145 277 496 146 277 minecraft:white_terracotta
fill 496 145 280 498 146 280 minecraft:white_wool
fill 496 145 281 496 146 281 minecraft:white_terracotta
fill 496 145 284 498 146 284 minecraft:white_wool
fill 496 145 285 496 146 285 minecraft:white_terracotta
fill 496 145 288 498 146 288 minecraft:white_wool
fill 496 145 289 496 146 289 minecraft:white_terracotta
fill 496 145 292 498 146 292 minecraft:white_wool
fill 496 145 293 496 146 293 minecraft:white_terracotta
fill 496 145 296 498 146 296 minecraft:white_wool
fill 496 145 297 496 146 297 minecraft:white_terracotta
fill 496 145 300 498 146 300 minecraft:white_wool
fill 496 145 301 496 146 301 minecraft:white_terracotta
fill 496 145 302 496 146 304 minecraft:white_wool
fill 496 145 305 496 146 305 minecraft:white_terracotta
fill 496 145 308 498 146 308 minecraft:white_wool
fill 496 145 309 496 146 309 minecraft:white_terracotta
fill 496 145 312 498 146 312 minecraft:white_wool
fill 496 145 313 496 146 313 minecraft:white_terracotta
fill 496 145 314 496 146 316 minecraft:white_wool
fill 497 145 277 499 146 277 minecraft:white_wool
fill 497 145 278 497 146 278 minecraft:white_terracotta
fill 497 145 281 499 146 281 minecraft:white_wool
fill 497 145 282 497 146 282 minecraft:white_terracotta
fill 497 145 285 499 146 285 minecraft:white_wool
fill 497 145 286 497 146 286 minecraft:white_terracotta
fill 497 145 289 499 146 289 minecraft:white_wool
fill 497 145 290 497 146 290 minecraft:white_terracotta
fill 497 145 293 499 146 293 minecraft:white_wool
fill 497 145 294 497 146 294 minecraft:white_terracotta
fill 497 145 297 499 145 297 minecraft:white_wool
fill 497 145 298 497 148 298 minecraft:white_terracotta
fill 497 145 301 499 146 301 minecraft:white_wool
fill 497 145 302 497 146 302 minecraft:white_terracotta
fill 497 145 303 497 146 305 minecraft:white_wool
fill 497 145 306 497 146 306 minecraft:white_terracotta
fill 497 145 309 499 146 309 minecraft:white_wool
fill 497 145 310 497 146 310 minecraft:white_terracotta
fill 497 145 313 499 146 313 minecraft:white_wool
fill 497 145 314 497 146 314 minecraft:white_terracotta
fill 497 145 315 497 146 316 minecraft:white_wool
fill 498 145 278 500 146 278 minecraft:white_wool
fill 498 145 279 498 146 279 minecraft:white_terracotta
fill 498 145 282 500 146 282 minecraft:white_wool
fill 498 145 283 498 146 283 minecraft:white_terracotta
fill 498 145 286 500 146 286 minecraft:white_wool
fill 498 145 287 498 146 287 minecraft:white_terracotta
fill 498 145 290 500 146 290 minecraft:white_wool
fill 498 145 291 498 146 291 minecraft:white_terracotta
fill 498 145 294 500 146 294 minecraft:white_wool
fill 498 145 295 498 146 295 minecraft:white_terracotta
fill 498 145 298 500 146 298 minecraft:white_wool
fill 498 145 299 498 146 299 minecraft:white_terracotta
fill 498 145 302 500 146 302 minecraft:white_wool
fill 498 145 303 498 146 303 minecraft:white_terracotta
fill 498 145 304 498 146 306 minecraft:white_wool
fill 498 145 307 498 146 307 minecraft:white_terracotta
fill 498 145 310 500 146 310 minecraft:white_wool
fill 498 145 311 498 146 311 minecraft:white_terracotta
fill 498 145 314 500 146 314 minecraft:white_wool
fill 498 145 315 498 146 315 minecraft:white_terracotta
fill 498 145 316 498 146 316 minecraft:white_wool
fill 499 145 276 499 146 276 minecraft:white_terracotta
fill 499 145 279 501 146 279 minecraft:white_wool
fill 499 145 280 499 146 280 minecraft:white_terracotta
fill 499 145 283 501 146 283 minecraft:white_wool
fill 499 145 284 499 146 284 minecraft:white_terracotta
fill 499 145 287 501 146 287 minecraft:white_wool
fill 499 145 288 499 146 288 minecraft:white_terracotta
fill 499 145 291 501 146 291 minecraft:white_wool
fill 499 145 292 499 146 292 minecraft:white_terracotta
fill 499 145 295 501 146 295 minecraft:white_wool
fill 499 145 296 499 146 296 minecraft:white_terracotta
fill 499 145 299 501 146 299 minecraft:white_wool
fill 499 145 300 499 146 300 minecraft:white_terracotta
fill 499 145 303 501 146 303 minecraft:white_wool
fill 499 145 304 499 146 304 minecraft:white_terracotta
fill 499 145 305 499 146 307 minecraft:white_wool
fill 499 145 308 499 146 308 minecraft:white_terracotta
fill 499 145 311 501 146 311 minecraft:white_wool
fill 499 145 312 499 146 312 minecraft:white_terracotta
fill 499 145 315 501 146 315 minecraft:white_wool
fill 499 145 316 499 146 316 minecraft:white_terracotta
fill 500 145 276 502 146 276 minecraft:white_wool
fill 500 145 277 500 146 277 minecraft:white_terracotta
fill 500 145 280 502 146 280 minecraft:white_wool
fill 500 145 281 500 146 281 minecraft:white_terracotta
fill 500 145 284 502 146 284 minecraft:white_wool
fill 500 145 285 500 146 285 minecraft:white_terracotta
fill 500 145 288 502 146 288 minecraft:white_wool
fill 500 145 289 500 146 289 minecraft:white_terracotta
fill 500 145 292 502 146 292 minecraft:white_wool
fill 500 145 293 500 146 293 minecraft:white_terracotta
fill 500 145 296 502 146 296 minecraft:white_wool
fill 500 145 297 500 146 297 minecraft:white_terracotta
fill 500 145 300 502 146 300 minecraft:white_wool
fill 500 145 301 500 146 301 minecraft:white_terracotta
fill 500 145 304 502 145 304 minecraft:white_wool
fill 500 145 305 500 146 305 minecraft:white_terracotta
fill 500 145 306 500 146 308 minecraft:white_wool
fill 500 145 309 500 146 309 minecraft:white_terracotta
fill 500 145 312 502 146 312 minecraft:white_wool
fill 500 145 313 500 146 313 minecraft:white_terracotta
fill 500 145 316 502 146 316 minecraft:white_wool
fill 501 145 277 503 146 277 minecraft:white_wool
fill 501 145 278 501 146 278 minecraft:white_terracotta
fill 501 145 281 503 146 281 minecraft:white_wool
fill 501 145 282 501 146 282 minecraft:white_terracotta
fill 501 145 285 503 146 285 minecraft:white_wool
fill 501 145 286 501 146 286 minecraft:white_terracotta
fill 501 145 289 503 146 289 minecraft:white_wool
fill 501 145 290 501 146 290 minecraft:white_terracotta
fill 501 145 293 503 146 293 minecraft:white_wool
fill 501 145 294 501 146 294 minecraft:white_terracotta
fill 501 145 297 503 146 297 minecraft:white_wool
fill 501 145 298 501 146 298 minecraft:white_terracotta
fill 501 145 301 503 146 301 minecraft:white_wool
fill 501 145 302 501 146 302 minecraft:white_terracotta
fill 501 145 305 503 146 305 minecraft:white_wool
fill 501 145 306 501 146 306 minecraft:white_terracotta
fill 501 145 307 501 146 309 minecraft:white_wool
fill 501 145 310 501 146 310 minecraft:white_terracotta
fill 501 145 313 503 145 313 minecraft:white_wool
fill 501 145 314 501 146 314 minecraft:white_terracotta
fill 502 145 278 504 146 278 minecraft:white_wool
fill 502 145 279 502 146 279 minecraft:white_terracotta
fill 502 145 282 504 146 282 minecraft:white_wool
fill 502 145 283 502 146 283 minecraft:white_terracotta
fill 502 145 286 504 146 286 minecraft:white_wool
fill 502 145 287 502 146 287 minecraft:white_terracotta
fill 502 145 290 504 146 290 minecraft:white_wool
fill 502 145 291 502 146 291 minecraft:white_terracotta
fill 502 145 294 504 146 294 minecraft:white_wool
fill 502 145 295 502 146 295 minecraft:white_terracotta
fill 502 145 298 504 146 298 minecraft:white_wool
fill 502 145 299 502 146 299 minecraft:white_terracotta
fill 502 145 302 504 146 302 minecraft:white_wool
fill 502 145 303 502 148 303 minecraft:white_terracotta
fill 502 145 306 504 146 306 minecraft:white_wool
fill 502 145 307 502 146 307 minecraft:white_terracotta
fill 502 145 308 502 146 310 minecraft:white_wool
fill 502 145 311 502 146 311 minecraft:white_terracotta
fill 502 145 314 504 145 314 minecraft:white_wool
fill 502 145 315 502 146 315 minecraft:white_terracotta
fill 503 145 276 503 146 276 minecraft:white_terracotta
fill 503 145 279 505 146 279 minecraft:white_wool
fill 503 145 280 503 146 280 minecraft:white_terracotta
fill 503 145 283 505 146 283 minecraft:white_wool
fill 503 145 284 503 146 284 minecraft:white_terracotta
fill 503 145 287 505 146 287 minecraft:white_wool
fill 503 145 288 503 146 288 minecraft:white_terracotta
fill 503 145 291 505 146 291 minecraft:white_wool
fill 503 145 292 503 146 292 minecraft:white_terracotta
fill 503 145 295 505 146 295 minecraft:white_wool
fill 503 145 296 503 146 296 minecraft:white_terracotta
fill 503 145 299 505 146 299 minecraft:white_wool
fill 503 145 300 503 146 300 minecraft:white_terracotta
fill 503 145 303 505 145 303 minecraft:white_wool
fill 503 145 304 503 148 304 minecraft:white_terracotta
fill 503 145 307 505 146 307 minecraft:white_wool
fill 503 145 308 503 146 308 minecraft:white_terracotta
fill 503 145 309 503 146 311 minecraft:white_wool
fill 503 145 312 503 148 312 minecraft:white_terracotta
fill 503 145 315 505 146 315 minecraft:white_wool
fill 503 145 316 503 146 316 minecraft:white_terracotta
fill 504 145 276 506 146 276 minecraft:white_wool
fill 504 145 277 504 146 277 minecraft:white_terracotta
fill 504 145 280 506 145 280 minecraft:white_wool
fill 504 145 281 504 146 281 minecraft:white_terracotta
fill 504 145 284 506 146 284 minecraft:white_wool
fill 504 145 285 504 146 285 minecraft:white_terracotta
fill 504 145 288 506 146 288 minecraft:white_wool
fill 504 145 289 504 146 289 minecraft:white_terracotta
fill 504 145 292 506 146 292 minecraft:white_wool
fill 504 145 293 504 146 293 minecraft:white_terracotta
fill 504 145 296 506 146 296 minecraft:white_wool
fill 504 145 297 504 146 297 minecraft:white_terracotta
fill 504 145 300 506 146 300 minecraft:white_wool
fill 504 145 301 504 146 301 minecraft:white_terracotta
fill 504 145 304 506 146 304 minecraft:white_wool
fill 504 145 305 504 146 305 minecraft:white_terracotta
fill 504 145 308 506 146 308 minecraft:white_wool
fill 504 145 309 504 146 309 minecraft:white_terracotta
fill 504 145 310 504 145 312 minecraft:white_wool
fill 504 145 313 504 148 313 minecraft:white_terracotta
fill 504 145 316 506 146 316 minecraft:white_wool
fill 505 145 277 507 146 277 minecraft:white_wool
fill 505 145 278 505 146 278 minecraft:white_terracotta
fill 505 145 281 507 145 281 minecraft:white_wool
fill 505 145 282 505 146 282 minecraft:white_terracotta
fill 505 145 285 507 146 285 minecraft:white_wool
fill 505 145 286 505 146 286 minecraft:white_terracotta
fill 505 145 289 507 146 289 minecraft:white_wool
fill 505 145 290 505 146 290 minecraft:white_terracotta
fill 505 145 293 507 146 293 minecraft:white_wool
fill 505 145 294 505 146 294 minecraft:white_terracotta
fill 505 145 297 507 146 297 minecraft:white_wool
fill 505 145 298 505 146 298 minecraft:white_terracotta
fill 505 145 301 507 146 301 minecraft:white_wool
fill 505 145 302 505 146 302 minecraft:white_terracotta
fill 505 145 305 507 146 305 minecraft:white_wool
fill 505 145 306 505 146 306 minecraft:white_terracotta
fill 505 145 309 507 146 309 minecraft:white_wool
fill 505 145 310 505 146 310 minecraft:white_terracotta
fill 505 145 311 505 145 313 minecraft:white_wool
fill 505 145 314 505 146 314 minecraft:white_terracotta
fill 506 145 278 508 146 278 minecraft:white_wool
fill 506 145 279 506 147 279 minecraft:white_terracotta
fill 506 145 282 508 146 282 minecraft:white_wool
fill 506 145 283 506 146 283 minecraft:white_terracotta
fill 506 145 286 508 146 286 minecraft:white_wool
fill 506 145 287 506 146 287 minecraft:white_terracotta
fill 506 145 290 508 146 290 minecraft:white_wool
fill 506 145 291 506 146 291 minecraft:white_terracotta
fill 506 145 294 508 146 294 minecraft:white_wool
fill 506 145 295 506 146 295 minecraft:white_terracotta
fill 506 145 298 508 146 298 minecraft:white_wool
fill 506 145 299 506 146 299 minecraft:white_terracotta
fill 506 145 302 508 146 302 minecraft:white_wool
fill 506 145 303 506 146 303 minecraft:white_terracotta
fill 506 145 306 508 146 306 minecraft:white_wool
fill 506 145 307 506 146 307 minecraft:white_terracotta
fill 506 145 310 508 146 310 minecraft:white_wool
fill 506 145 311 506 148 311 minecraft:white_terracotta
fill 506 145 312 506 145 314 minecraft:white_wool
fill 506 145 315 506 146 315 minecraft:white_terracotta
fill 507 145 276 507 146 276 minecraft:white_terracotta
fill 507 145 279 509 145 279 minecraft:white_wool
fill 507 145 280 507 148 280 minecraft:white_terracotta
fill 507 145 283 509 146 283 minecraft:white_wool
fill 507 145 284 507 146 284 minecraft:white_terracotta
fill 507 145 287 509 146 287 minecraft:white_wool
fill 507 145 288 507 146 288 minecraft:white_terracotta
fill 507 145 291 509 146 291 minecraft:white_wool
fill 507 145 292 507 146 292 minecraft:white_terracotta
fill 507 145 295 509 146 295 minecraft:white_wool
fill 507 145 296 507 146 296 minecraft:white_terracotta
fill 507 145 299 509 146 299 minecraft:white_wool
fill 507 145 300 507 146 300 minecraft:white_terracotta
fill 507 145 303 509 146 303 minecraft:white_wool
fill 507 145 304 507 146 304 minecraft:white_terracotta
fill 507 145 307 509 146 307 minecraft:white_wool
fill 507 145 308 507 146 308 minecraft:white_terracotta
fill 507 145 311 509 146 311 minecraft:white_wool
fill 507 145 312 507 148 312 minecraft:white_terracotta
fill 507 145 313 507 146 315 minecraft:white_wool
fill 507 145 316 507 146 316 minecraft:white_terracotta
fill 508 145 276 510 146 276 minecraft:white_wool
fill 508 145 277 508 146 277 minecraft:white_terracotta
fill 508 145 280 510 145 280 minecraft:white_wool
fill 508 145 281 508 147 281 minecraft:white_terracotta
fill 508 145 284 510 146 284 minecraft:white_wool
fill 508 145 285 508 146 285 minecraft:white_terracotta
fill 508 145 288 510 146 288 minecraft:white_wool
fill 508 145 289 508 146 289 minecraft:white_terracotta
fill 508 145 292 510 146 292 minecraft:white_wool
fill 508 145 293 508 146 293 minecraft:white_terracotta
fill 508 145 296 510 146 296 minecraft:white_wool
fill 508 145 297 508 146 297 minecraft:white_terracotta
fill 508 145 300 510 146 300 minecraft:white_wool
fill 508 145 301 508 146 301 minecraft:white_terracotta
fill 508 145 304 510 146 304 minecraft:white_wool
fill 508 145 305 508 146 305 minecraft:white_terracotta
fill 508 145 308 510 146 308 minecraft:white_wool
fill 508 145 309 508 146 309 minecraft:white_terracotta
fill 508 145 312 510 146 312 minecraft:white_wool
fill 508 145 313 508 146 313 minecraft:white_terracotta
fill 508 145 314 508 146 316 minecraft:white_wool
fill 509 145 277 511 146 277 minecraft:white_wool
fill 509 145 278 509 146 278 minecraft:white_terracotta
fill 509 145 281 511 146 281 minecraft:white_wool
fill 509 145 282 509 146 282 minecraft:white_terracotta
fill 509 145 285 511 146 285 minecraft:white_wool
fill 509 145 286 509 146 286 minecraft:white_terracotta
fill 509 145 289 511 146 289 minecraft:white_wool
fill 509 145 290 509 146 290 minecraft:white_terracotta
fill 509 145 293 511 146 293 minecraft:white_wool
fill 509 145 294 509 146 294 minecraft:white_terracotta
fill 509 145 297 511 146 297 minecraft:white_wool
fill 509 145 298 509 146 298 minecraft:white_terracotta
fill 509 145 301 511 146 301 minecraft:white_wool
fill 509 145 302 509 146 302 minecraft:white_terracotta
fill 509 145 305 511 146 305 minecraft:white_wool
fill 509 145 306 509 146 306 minecraft:white_terracotta
fill 509 145 309 511 146 309 minecraft:white_wool
fill 509 145 310 509 146 310 minecraft:white_terracotta
fill 509 145 313 511 146 313 minecraft:white_wool
fill 509 145 314 509 146 314 minecraft:white_terracotta
fill 509 145 315 509 146 316 minecraft:white_wool
fill 510 145 278 511 146 278 minecraft:white_wool
fill 510 145 279 510 146 279 minecraft:white_terracotta
fill 510 145 282 511 146 282 minecraft:white_wool
fill 510 145 283 510 146 283 minecraft:white_terracotta
fill 510 145 286 511 146 286 minecraft:white_wool
fill 510 145 287 510 146 287 minecraft:white_terracotta
fill 510 145 290 511 146 290 minecraft:white_wool
fill 510 145 291 510 146 291 minecraft:white_terracotta
fill 510 145 294 511 146 294 minecraft:white_wool
fill 510 145 295 510 146 295 minecraft:white_terracotta
fill 510 145 298 511 146 298 minecraft:white_wool
fill 510 145 299 510 146 299 minecraft:white_terracotta
fill 510 145 302 511 146 302 minecraft:white_wool
fill 510 145 303 510 146 303 minecraft:white_terracotta
fill 510 145 306 511 146 306 minecraft:white_wool
fill 510 145 307 510 146 307 minecraft:white_terracotta
fill 510 145 310 511 146 310 minecraft:white_wool
fill 510 145 311 510 146 311 minecraft:white_terracotta
fill 510 145 314 511 146 314 minecraft:white_wool
fill 510 145 315 510 146 315 minecraft:white_terracotta
fill 510 145 316 510 146 316 minecraft:white_wool
fill 511 145 276 511 146 276 minecraft:white_terracotta
fill 511 145 279 511 146 279 minecraft:white_wool
fill 511 145 280 511 146 280 minecraft:white_terracotta
fill 511 145 283 511 146 283 minecraft:white_wool
fill 511 145 284 511 146 284 minecraft:white_terracotta
fill 511 145 287 511 146 287 minecraft:white_wool
fill 511 145 288 511 146 288 minecraft:white_terracotta
fill 511 145 291 511 146 291 minecraft:white_wool
fill 511 145 292 511 146 292 minecraft:white_terracotta
fill 511 145 295 511 146 295 minecraft:white_wool
fill 511 145 296 511 146 296 minecraft:white_terracotta
fill 511 145 299 511 146 299 minecraft:white_wool
fill 511 145 300 511 146 300 minecraft:white_terracotta
fill 511 145 303 511 146 303 minecraft:white_wool
fill 511 145 304 511 146 304 minecraft:white_terracotta
fill 511 145 307 511 146 307 minecraft:white_wool
fill 511 145 308 511 146 308 minecraft:white_terracotta
fill 511 145 311 511 146 311 minecraft:white_wool
fill 511 145 312 511 146 312 minecraft:white_terracotta
fill 511 145 315 511 146 315 minecraft:white_wool
fill 511 145 316 511 146 316 minecraft:white_terracotta
fill 470 146 286 470 201 286 minecraft:black_concrete
setblock 470 146 305 minecraft:white_wool
fill 473 146 315 473 146 316 minecraft:white_wool
fill 473 146 317 473 201 317 minecraft:black_concrete
fill 475 146 309 475 148 309 minecraft:white_terracotta
fill 475 146 310 475 146 311 minecraft:white_wool
fill 476 146 280 477 148 280 minecraft:white_terracotta
setblock 476 146 290 minecraft:white_wool
fill 476 146 291 477 146 292 minecraft:white_terracotta
fill 476 146 306 476 146 307 minecraft:white_wool
fill 476 146 308 476 148 308 minecraft:white_terracotta
fill 477 146 281 477 148 281 minecraft:white_terracotta
setblock 477 146 293 minecraft:white_wool
fill 478 146 280 478 146 281 minecraft:white_wool
setblock 479 146 281 minecraft:white_wool
fill 480 146 290 480 146 291 minecraft:white_wool
setblock 480 146 292 minecraft:redstone_block
fill 480 146 293 480 146 295 minecraft:ochre_froglight
setblock 480 146 296 minecraft:redstone_block
setblock 481 146 291 minecraft:redstone_block
setblock 481 146 292 minecraft:ochre_froglight
setblock 481 146 296 minecraft:ochre_froglight
setblock 481 146 297 minecraft:redstone_block
fill 482 146 291 484 146 291 minecraft:ochre_froglight
fill 482 146 297 484 146 297 minecraft:ochre_froglight
fill 482 146 298 483 146 298 minecraft:white_wool
fill 483 146 289 483 146 290 minecraft:white_wool
setblock 484 146 290 minecraft:white_wool
setblock 485 146 291 minecraft:redstone_block
setblock 485 146 292 minecraft:ochre_froglight
setblock 485 146 296 minecraft:ochre_froglight
setblock 485 146 297 minecraft:redstone_block
fill 486 146 290 486 148 290 minecraft:white_terracotta
setblock 486 146 292 minecraft:redstone_block
fill 486 146 293 486 146 295 minecraft:ochre_froglight
setblock 486 146 296 minecraft:redstone_block
setblock 486 146 297 minecraft:white_wool
fill 487 146 287 488 146 287 minecraft:white_wool
fill 487 146 290 488 146 290 minecraft:white_wool
setblock 489 146 287 minecraft:white_terracotta
setblock 490 146 286 minecraft:white_terracotta
fill 490 146 290 491 146 290 minecraft:white_wool
fill 491 146 286 492 146 286 minecraft:white_wool
setblock 492 146 288 minecraft:white_wool
setblock 492 146 290 minecraft:white_terracotta
fill 492 146 292 493 146 292 minecraft:white_wool
fill 493 146 281 494 148 281 minecraft:white_terracotta
fill 493 146 288 493 146 289 minecraft:white_terracotta
setblock 493 146 293 minecraft:white_wool
fill 494 146 282 495 148 282 minecraft:white_terracotta
fill 494 146 288 494 146 289 minecraft:white_wool
fill 494 146 292 494 146 294 minecraft:white_terracotta
fill 494 146 298 495 146 298 minecraft:white_wool
setblock 495 146 281 minecraft:white_wool
setblock 495 146 289 minecraft:white_wool
fill 495 146 293 495 146 294 minecraft:white_terracotta
setblock 496 146 282 minecraft:white_wool
setblock 496 146 294 minecraft:white_wool
setblock 496 146 298 minecraft:white_terracotta
fill 497 146 297 497 148 297 minecraft:white_terracotta
fill 498 146 297 499 146 297 minecraft:white_wool
fill 500 146 304 501 146 304 minecraft:white_wool
fill 501 146 313 502 146 313 minecraft:white_wool
fill 502 146 304 502 148 304 minecraft:white_terracotta
setblock 502 146 314 minecraft:white_wool
fill 503 146 303 503 148 303 minecraft:white_terracotta
fill 503 146 313 503 148 314 minecraft:white_terracotta
fill 504 146 280 505 146 280 minecraft:white_wool
fill 504 146 303 505 146 303 minecraft:white_wool
fill 504 146 310 504 146 311 minecraft:white_wool
fill 504 146 312 506 148 312 minecraft:white_terracotta
setblock 504 146 314 minecraft:white_wool
fill 505 146 281 506 146 281 minecraft:white_wool
setblock 505 146 311 minecraft:white_wool
fill 505 146 313 505 147 313 minecraft:white_wool
fill 506 146 280 506 148 280 minecraft:white_terracotta
fill 506 146 313 506 148 313 minecraft:white_terracotta
setblock 506 146 314 minecraft:white_wool
fill 507 146 279 507 148 279 minecraft:white_terracotta
fill 507 146 281 507 148 281 minecraft:white_terracotta
setblock 507 146 317 minecraft:redstone_block
fill 508 146 279 509 146 279 minecraft:white_wool
fill 508 146 280 508 148 280 minecraft:white_terracotta
fill 508 146 317 508 170 317 minecraft:black_concrete
fill 509 146 280 510 146 280 minecraft:white_wool
setblock 512 146 296 minecraft:white_wool
fill 470 147 305 470 187 305 minecraft:black_concrete
fill 471 147 285 478 155 303 minecraft:smooth_stone
setblock 474 147 309 minecraft:white_terracotta
setblock 475 147 281 minecraft:white_terracotta
fill 475 147 310 476 147 310 minecraft:white_terracotta
setblock 476 147 279 minecraft:white_terracotta
fill 479 147 285 479 155 303 minecraft:oak_planks
fill 485 147 289 486 147 289 minecraft:white_terracotta
fill 485 147 291 485 148 291 minecraft:white_terracotta
setblock 487 147 290 minecraft:white_terracotta
fill 488 147 285 488 155 303 minecraft:oak_planks
fill 489 147 285 496 155 303 minecraft:smooth_stone
setblock 495 147 281 minecraft:white_terracotta
setblock 497 147 296 minecraft:white_terracotta
fill 498 147 297 498 147 298 minecraft:white_terracotta
fill 501 147 303 501 147 304 minecraft:white_terracotta
setblock 502 147 305 minecraft:white_terracotta
setblock 502 147 313 minecraft:white_terracotta
setblock 503 147 315 minecraft:white_wool
setblock 504 147 314 minecraft:white_terracotta
setblock 505 147 311 minecraft:white_terracotta
setblock 507 147 311 minecraft:white_terracotta
setblock 507 147 313 minecraft:white_terracotta
fill 507 147 317 507 201 317 minecraft:black_concrete
setblock 508 147 279 minecraft:white_terracotta
fill 512 147 296 512 201 296 minecraft:black_concrete
setblock 507 148 311 minecraft:white_wool
setblock 508 148 310 minecraft:white_wool
setblock 509 148 309 minecraft:white_wool
setblock 510 148 308 minecraft:white_wool
setblock 512 148 286 minecraft:redstone_block
fill 512 148 287 512 201 287 minecraft:black_concrete
setblock 512 148 299 minecraft:redstone_block
setblock 473 149 278 minecraft:light[level=13]
setblock 473 149 310 minecraft:light[level=13]
fill 476 149 275 477 197 275 minecraft:black_concrete
setblock 478 149 275 minecraft:white_wool
setblock 481 149 278 minecraft:light[level=13]
setblock 481 149 286 minecraft:light[level=13]
setblock 481 149 294 minecraft:light[level=13]
setblock 481 149 302 minecraft:light[level=13]
setblock 481 149 310 minecraft:light[level=13]
setblock 489 149 278 minecraft:light[level=13]
setblock 489 149 310 minecraft:light[level=13]
setblock 497 149 278 minecraft:light[level=13]
setblock 497 149 286 minecraft:light[level=13]
setblock 497 149 294 minecraft:light[level=13]
setblock 497 149 302 minecraft:light[level=13]
setblock 497 149 310 minecraft:light[level=13]
setblock 505 149 278 minecraft:light[level=13]
setblock 505 149 286 minecraft:light[level=13]
setblock 505 149 294 minecraft:light[level=13]
setblock 505 149 302 minecraft:light[level=13]
setblock 505 149 310 minecraft:light[level=13]
fill 512 149 286 512 201 286 minecraft:black_concrete
fill 512 149 299 512 161 299 minecraft:black_concrete
fill 470 150 313 470 152 313 minecraft:black_concrete
setblock 470 150 314 minecraft:redstone_block
fill 470 150 315 470 201 315 minecraft:black_concrete
fill 471 150 276 471 150 277 minecraft:deepslate_tiles
setblock 471 150 278 minecraft:cobbled_deepslate
fill 471 150 279 471 150 282 minecraft:deepslate_tiles
setblock 471 150 283 minecraft:cobbled_deepslate
fill 471 150 284 472 152 284 minecraft:deepslate_tiles
setblock 471 150 312 minecraft:deepslate_tiles
setblock 471 150 313 minecraft:cobbled_deepslate
fill 471 150 314 472 150 316 minecraft:deepslate_tiles
setblock 472 150 276 minecraft:deepslate_tiles
setblock 472 150 277 minecraft:cobbled_deepslate
fill 472 150 278 472 150 281 minecraft:deepslate_tiles
setblock 472 150 282 minecraft:cobbled_deepslate
fill 472 150 283 473 152 283 minecraft:deepslate_tiles
setblock 473 150 276 minecraft:cobbled_deepslate
fill 473 150 277 473 150 280 minecraft:deepslate_tiles
setblock 473 150 281 minecraft:cobbled_deepslate
fill 473 150 282 473 153 282 minecraft:deepslate_tiles
setblock 473 150 315 minecraft:deepslate_tiles
setblock 473 150 316 minecraft:cobbled_deepslate
fill 474 150 276 474 150 279 minecraft:deepslate_tiles
setblock 474 150 280 minecraft:cobbled_deepslate
setblock 474 150 315 minecraft:cobbled_deepslate
fill 474 150 316 477 150 316 minecraft:deepslate_tiles
fill 475 150 276 475 150 278 minecraft:deepslate_tiles
setblock 475 150 279 minecraft:cobbled_deepslate
setblock 475 150 314 minecraft:cobbled_deepslate
fill 475 150 315 478 150 315 minecraft:deepslate_tiles
fill 476 150 276 476 150 277 minecraft:deepslate_tiles
setblock 476 150 278 minecraft:cobbled_deepslate
fill 476 150 279 478 150 279 minecraft:deepslate_tiles
fill 476 150 314 479 150 314 minecraft:deepslate_tiles
setblock 477 150 276 minecraft:deepslate_tiles
setblock 477 150 277 minecraft:cobbled_deepslate
fill 477 150 278 480 150 278 minecraft:deepslate_tiles
fill 478 150 275 478 197 275 minecraft:black_concrete
setblock 478 150 276 minecraft:cobbled_deepslate
fill 478 150 277 481 150 277 minecraft:deepslate_tiles
setblock 478 150 316 minecraft:cobbled_deepslate
fill 479 150 276 482 150 276 minecraft:deepslate_tiles
setblock 479 150 315 minecraft:cobbled_deepslate
fill 479 150 316 482 150 316 minecraft:deepslate_tiles
fill 480 150 315 483 150 315 minecraft:deepslate_tiles
setblock 481 150 278 minecraft:cobbled_deepslate
setblock 482 150 277 minecraft:cobbled_deepslate
setblock 483 150 276 minecraft:cobbled_deepslate
fill 483 150 277 486 150 277 minecraft:deepslate_tiles
fill 483 150 309 483 167 309 minecraft:white_wool
setblock 483 150 316 minecraft:cobbled_deepslate
fill 484 150 276 487 150 276 minecraft:deepslate_tiles
setblock 484 150 315 minecraft:cobbled_deepslate
fill 484 150 316 487 150 316 minecraft:deepslate_tiles
fill 485 150 315 488 150 315 minecraft:deepslate_tiles
setblock 487 150 277 minecraft:cobbled_deepslate
setblock 488 150 276 minecraft:cobbled_deepslate
fill 488 150 277 491 150 277 minecraft:deepslate_tiles
setblock 488 150 316 minecraft:cobbled_deepslate
fill 489 150 276 492 150 276 minecraft:deepslate_tiles
setblock 489 150 314 minecraft:deepslate_tiles
setblock 489 150 315 minecraft:cobbled_deepslate
fill 489 150 316 492 150 316 minecraft:deepslate_tiles
setblock 490 150 314 minecraft:cobbled_deepslate
fill 490 150 315 493 150 315 minecraft:deepslate_tiles
fill 491 150 314 494 150 314 minecraft:deepslate_tiles
setblock 492 150 277 minecraft:cobbled_deepslate
setblock 493 150 275 minecraft:white_wool
setblock 493 150 276 minecraft:cobbled_deepslate
fill 493 150 277 496 150 277 minecraft:deepslate_tiles
setblock 493 150 316 minecraft:cobbled_deepslate
fill 494 150 276 497 150 276 minecraft:deepslate_tiles
fill 494 150 313 495 150 313 minecraft:deepslate_tiles
setblock 494 150 315 minecraft:cobbled_deepslate
fill 494 150 316 497 150 316 minecraft:deepslate_tiles
setblock 495 150 314 minecraft:cobbled_deepslate
fill 495 150 315 498 150 315 minecraft:deepslate_tiles
setblock 496 150 313 minecraft:cobbled_deepslate
fill 496 150 314 499 150 314 minecraft:deepslate_tiles
setblock 497 150 277 minecraft:cobbled_deepslate
setblock 498 150 276 minecraft:cobbled_deepslate
fill 498 150 277 499 151 277 minecraft:deepslate_tiles
setblock 498 150 316 minecraft:cobbled_deepslate
fill 499 150 276 502 150 276 minecraft:deepslate_tiles
setblock 499 150 315 minecraft:cobbled_deepslate
fill 499 150 316 502 150 316 minecraft:deepslate_tiles
fill 500 150 315 502 150 315 minecraft:deepslate_tiles
setblock 503 150 276 minecraft:cobbled_deepslate
setblock 503 150 316 minecraft:cobbled_deepslate
fill 504 150 316 507 150 316 minecraft:deepslate_tiles
setblock 508 150 276 minecraft:cobbled_deepslate
setblock 508 150 316 minecraft:cobbled_deepslate
fill 509 150 276 511 151 276 minecraft:deepslate_tiles
fill 509 150 293 509 150 294 minecraft:deepslate_tiles
setblock 509 150 295 minecraft:cobbled_deepslate
fill 509 150 296 509 150 299 minecraft:deepslate_tiles
fill 509 150 316 511 151 316 minecraft:deepslate_tiles
setblock 510 150 289 minecraft:cobbled_deepslate
fill 510 150 290 510 150 293 minecraft:deepslate_tiles
setblock 510 150 294 minecraft:cobbled_deepslate
fill 510 150 295 510 150 298 minecraft:deepslate_tiles
setblock 510 150 299 minecraft:cobbled_deepslate
fill 510 150 300 511 150 302 minecraft:deepslate_tiles
setblock 511 150 277 minecraft:deepslate_tiles
setblock 511 150 278 minecraft:cobbled_deepslate
fill 511 150 279 511 150 282 minecraft:deepslate_tiles
setblock 511 150 283 minecraft:cobbled_deepslate
fill 511 150 284 511 150 287 minecraft:deepslate_tiles
setblock 511 150 288 minecraft:cobbled_deepslate
fill 511 150 289 511 150 292 minecraft:deepslate_tiles
setblock 511 150 293 minecraft:cobbled_deepslate
fill 511 150 294 511 150 297 minecraft:deepslate_tiles
setblock 511 150 298 minecraft:cobbled_deepslate
fill 511 150 299 511 153 299 minecraft:deepslate_tiles
setblock 511 150 303 minecraft:cobbled_deepslate
fill 511 150 304 511 152 305 minecraft:deepslate_tiles
setblock 511 150 312 minecraft:deepslate_tiles
setblock 511 150 313 minecraft:cobbled_deepslate
fill 511 150 314 511 151 315 minecraft:deepslate_tiles
fill 470 151 314 470 201 314 minecraft:black_concrete
setblock 471 151 276 minecraft:deepslate_tiles
setblock 471 151 277 minecraft:cobbled_deepslate
fill 471 151 278 471 151 281 minecraft:deepslate_tiles
setblock 471 151 282 minecraft:cobbled_deepslate
fill 471 151 283 471 154 283 minecraft:deepslate_tiles
fill 471 151 313 471 151 316 minecraft:deepslate_tiles
setblock 472 151 276 minecraft:cobbled_deepslate
fill 472 151 277 472 151 280 minecraft:deepslate_tiles
setblock 472 151 281 minecraft:cobbled_deepslate
fill 472 151 282 472 154 282 minecraft:deepslate_tiles
fill 472 151 314 472 151 315 minecraft:deepslate_tiles
setblock 472 151 316 minecraft:cobbled_deepslate
fill 473 151 276 473 151 279 minecraft:deepslate_tiles
setblock 473 151 280 minecraft:cobbled_deepslate
fill 473 151 281 473 154 281 minecraft:deepslate_tiles
setblock 473 151 306 minecraft:light[level=12]
setblock 473 151 313 minecraft:light[level=12]
setblock 473 151 315 minecraft:cobbled_deepslate
fill 473 151 316 476 151 316 minecraft:deepslate_tiles
fill 474 151 276 474 151 278 minecraft:deepslate_tiles
setblock 474 151 279 minecraft:cobbled_deepslate
fill 474 151 280 474 154 280 minecraft:deepslate_tiles
fill 474 151 315 477 151 315 minecraft:deepslate_tiles
fill 475 151 276 475 151 277 minecraft:deepslate_tiles
setblock 475 151 278 minecraft:cobbled_deepslate
fill 475 151 279 477 152 279 minecraft:deepslate_tiles
setblock 476 151 276 minecraft:deepslate_tiles
setblock 476 151 277 minecraft:cobbled_deepslate
fill 476 151 278 479 151 278 minecraft:deepslate_tiles
setblock 477 151 276 minecraft:cobbled_deepslate
fill 477 151 277 480 151 277 minecraft:deepslate_tiles
setblock 477 151 316 minecraft:cobbled_deepslate
fill 478 151 276 481 151 276 minecraft:deepslate_tiles
setblock 478 151 315 minecraft:cobbled_deepslate
fill 478 151 316 481 151 316 minecraft:deepslate_tiles
fill 479 151 315 482 151 315 minecraft:deepslate_tiles
setblock 480 151 278 minecraft:cobbled_deepslate
setblock 480 151 285 minecraft:light[level=12]
setblock 480 151 292 minecraft:light[level=12]
setblock 480 151 299 minecraft:light[level=12]
setblock 480 151 306 minecraft:light[level=12]
setblock 480 151 313 minecraft:light[level=12]
setblock 481 151 277 minecraft:cobbled_deepslate
setblock 481 151 278 minecraft:deepslate_tiles
setblock 482 151 276 minecraft:cobbled_deepslate
fill 482 151 277 485 151 277 minecraft:deepslate_tiles
setblock 482 151 316 minecraft:cobbled_deepslate
fill 483 151 276 486 151 276 minecraft:deepslate_tiles
fill 483 151 315 483 152 315 minecraft:cobbled_deepslate
fill 483 151 316 486 151 316 minecraft:deepslate_tiles
fill 484 151 315 487 151 315 minecraft:deepslate_tiles
setblock 486 151 277 minecraft:cobbled_deepslate
setblock 487 151 276 minecraft:cobbled_deepslate
fill 487 151 277 490 151 277 minecraft:deepslate_tiles
setblock 487 151 278 minecraft:light[level=12]
setblock 487 151 285 minecraft:light[level=12]
setblock 487 151 292 minecraft:light[level=12]
setblock 487 151 299 minecraft:light[level=12]
setblock 487 151 306 minecraft:light[level=12]
setblock 487 151 313 minecraft:light[level=12]
setblock 487 151 316 minecraft:cobbled_deepslate
fill 488 151 276 491 151 276 minecraft:deepslate_tiles
setblock 488 151 315 minecraft:cobbled_deepslate
fill 488 151 316 491 151 316 minecraft:deepslate_tiles
fill 489 151 315 492 151 315 minecraft:deepslate_tiles
fill 490 151 314 493 151 314 minecraft:deepslate_tiles
setblock 491 151 277 minecraft:cobbled_deepslate
setblock 492 151 276 minecraft:cobbled_deepslate
fill 492 151 277 495 151 277 minecraft:deepslate_tiles
setblock 492 151 316 minecraft:cobbled_deepslate
fill 493 151 275 493 201 275 minecraft:black_concrete
fill 493 151 276 496 151 276 minecraft:deepslate_tiles
setblock 493 151 315 minecraft:cobbled_deepslate
fill 493 151 316 496 151 316 minecraft:deepslate_tiles
setblock 494 151 278 minecraft:light[level=12]
setblock 494 151 306 minecraft:light[level=12]
setblock 494 151 313 minecraft:light[level=12]
setblock 494 151 314 minecraft:cobbled_deepslate
fill 494 151 315 497 151 315 minecraft:deepslate_tiles
fill 495 151 314 498 151 314 minecraft:deepslate_tiles
setblock 496 151 277 minecraft:cobbled_deepslate
setblock 497 151 276 minecraft:cobbled_deepslate
fill 497 151 277 497 153 277 minecraft:deepslate_tiles
setblock 497 151 316 minecraft:cobbled_deepslate
fill 498 151 276 501 151 276 minecraft:deepslate_tiles
setblock 498 151 315 minecraft:cobbled_deepslate
fill 498 151 316 501 151 316 minecraft:deepslate_tiles
fill 499 151 315 500 151 315 minecraft:deepslate_tiles
setblock 501 151 278 minecraft:light[level=12]
setblock 501 151 285 minecraft:light[level=12]
setblock 501 151 292 minecraft:light[level=12]
setblock 501 151 299 minecraft:light[level=12]
setblock 501 151 306 minecraft:light[level=12]
setblock 501 151 313 minecraft:light[level=12]
setblock 502 151 276 minecraft:cobbled_deepslate
setblock 502 151 316 minecraft:cobbled_deepslate
setblock 503 151 316 minecraft:deepslate_tiles
fill 504 151 279 510 151 279 minecraft:cobbled_deepslate
fill 506 151 283 510 151 283 minecraft:cobbled_deepslate
setblock 507 151 276 minecraft:cobbled_deepslate
fill 508 151 276 508 154 276 minecraft:deepslate_tiles
setblock 508 151 278 minecraft:light[level=12]
setblock 508 151 285 minecraft:light[level=12]
setblock 508 151 292 minecraft:light[level=12]
setblock 508 151 299 minecraft:light[level=12]
setblock 508 151 306 minecraft:light[level=12]
setblock 508 151 313 minecraft:light[level=12]
setblock 509 151 294 minecraft:cobbled_deepslate
fill 509 151 295 509 151 298 minecraft:deepslate_tiles
setblock 509 151 299 minecraft:cobbled_deepslate
setblock 510 151 277 minecraft:deepslate_tiles
setblock 510 151 278 minecraft:cobbled_deepslate
fill 510 151 290 510 151 292 minecraft:deepslate_tiles
setblock 510 151 293 minecraft:cobbled_deepslate
fill 510 151 294 510 151 297 minecraft:deepslate_tiles
setblock 510 151 298 minecraft:cobbled_deepslate
fill 510 151 299 510 151 302 minecraft:deepslate_tiles
setblock 511 151 277 minecraft:cobbled_deepslate
fill 511 151 278 511 151 281 minecraft:deepslate_tiles
setblock 511 151 282 minecraft:cobbled_deepslate
fill 511 151 283 511 151 286 minecraft:deepslate_tiles
setblock 511 151 287 minecraft:cobbled_deepslate
fill 511 151 288 511 151 291 minecraft:deepslate_tiles
setblock 511 151 292 minecraft:cobbled_deepslate
fill 511 151 293 511 151 296 minecraft:deepslate_tiles
setblock 511 151 297 minecraft:cobbled_deepslate
fill 511 151 298 511 154 298 minecraft:deepslate_tiles
fill 511 151 300 511 151 301 minecraft:deepslate_tiles
setblock 511 151 302 minecraft:cobbled_deepslate
fill 511 151 303 511 154 303 minecraft:deepslate_tiles
setblock 471 152 276 minecraft:cobbled_deepslate
fill 471 152 277 471 152 280 minecraft:deepslate_tiles
setblock 471 152 281 minecraft:cobbled_deepslate
fill 471 152 282 471 155 282 minecraft:deepslate_tiles
fill 471 152 307 471 153 307 minecraft:cobbled_deepslate
fill 471 152 311 511 152 311 minecraft:cobbled_deepslate
fill 471 152 313 471 152 315 minecraft:deepslate_tiles
setblock 471 152 316 minecraft:cobbled_deepslate
fill 472 152 276 472 152 279 minecraft:deepslate_tiles
setblock 472 152 280 minecraft:cobbled_deepslate
fill 472 152 281 472 155 281 minecraft:deepslate_tiles
setblock 472 152 315 minecraft:cobbled_deepslate
fill 472 152 316 475 152 316 minecraft:deepslate_tiles
fill 473 152 276 473 152 278 minecraft:deepslate_tiles
setblock 473 152 279 minecraft:cobbled_deepslate
fill 473 152 280 473 155 280 minecraft:deepslate_tiles
fill 473 152 315 476 152 315 minecraft:deepslate_tiles
fill 474 152 276 474 152 277 minecraft:deepslate_tiles
setblock 474 152 278 minecraft:cobbled_deepslate
fill 474 152 279 474 155 279 minecraft:deepslate_tiles
fill 474 152 283 509 152 283 minecraft:cobbled_deepslate
setblock 475 152 276 minecraft:deepslate_tiles
setblock 475 152 277 minecraft:cobbled_deepslate
fill 475 152 278 478 152 278 minecraft:deepslate_tiles
setblock 476 152 276 minecraft:cobbled_deepslate
fill 476 152 277 479 152 277 minecraft:deepslate_tiles
setblock 476 152 316 minecraft:cobbled_deepslate
fill 477 152 276 480 152 276 minecraft:deepslate_tiles
setblock 477 152 315 minecraft:cobbled_deepslate
fill 477 152 316 480 152 316 minecraft:deepslate_tiles
fill 478 152 279 507 152 279 minecraft:cobbled_deepslate
fill 478 152 315 481 152 315 minecraft:deepslate_tiles
setblock 479 152 278 minecraft:cobbled_deepslate
setblock 480 152 277 minecraft:cobbled_deepslate
setblock 480 152 278 minecraft:deepslate_tiles
fill 480 152 291 481 153 291 minecraft:cobbled_deepslate
fill 480 152 303 487 153 303 minecraft:cobbled_deepslate
setblock 481 152 276 minecraft:cobbled_deepslate
fill 481 152 277 484 152 277 minecraft:deepslate_tiles
setblock 481 152 316 minecraft:cobbled_deepslate
fill 482 152 276 485 152 276 minecraft:deepslate_tiles
setblock 482 152 315 minecraft:cobbled_deepslate
fill 482 152 316 485 152 316 minecraft:deepslate_tiles
fill 484 152 315 485 152 315 minecraft:cobbled_deepslate
setblock 485 152 277 minecraft:cobbled_deepslate
setblock 486 152 276 minecraft:cobbled_deepslate
fill 486 152 277 489 152 277 minecraft:deepslate_tiles
fill 486 152 291 487 153 291 minecraft:cobbled_deepslate
setblock 486 152 315 minecraft:deepslate_tiles
setblock 486 152 316 minecraft:cobbled_deepslate
fill 487 152 276 490 152 276 minecraft:deepslate_tiles
setblock 487 152 295 minecraft:cobbled_deepslate
setblock 487 152 315 minecraft:cobbled_deepslate
fill 487 152 316 490 152 316 minecraft:deepslate_tiles
fill 488 152 315 491 152 315 minecraft:deepslate_tiles
setblock 490 152 277 minecraft:cobbled_deepslate
setblock 491 152 276 minecraft:cobbled_deepslate
fill 491 152 277 494 152 277 minecraft:deepslate_tiles
fill 491 152 314 492 152 314 minecraft:deepslate_tiles
setblock 491 152 316 minecraft:cobbled_deepslate
fill 492 152 276 495 152 276 minecraft:deepslate_tiles
setblock 492 152 315 minecraft:cobbled_deepslate
fill 492 152 316 495 152 316 minecraft:deepslate_tiles
setblock 493 152 314 minecraft:cobbled_deepslate
fill 493 152 315 496 152 315 minecraft:deepslate_tiles
fill 494 152 314 496 152 314 minecraft:deepslate_tiles
setblock 495 152 277 minecraft:cobbled_deepslate
setblock 496 152 276 minecraft:cobbled_deepslate
fill 496 152 277 496 154 277 minecraft:deepslate_tiles
setblock 496 152 316 minecraft:cobbled_deepslate
fill 497 152 276 500 152 276 minecraft:deepslate_tiles
fill 497 152 295 508 152 295 minecraft:cobbled_deepslate
fill 497 152 303 509 153 303 minecraft:cobbled_deepslate
setblock 497 152 315 minecraft:cobbled_deepslate
fill 497 152 316 500 152 316 minecraft:deepslate_tiles
setblock 498 152 277 minecraft:deepslate_tiles
fill 498 152 315 499 152 315 minecraft:deepslate_tiles
fill 500 152 315 510 152 315 minecraft:cobbled_deepslate
setblock 501 152 276 minecraft:cobbled_deepslate
setblock 501 152 316 minecraft:cobbled_deepslate
setblock 508 152 275 minecraft:white_wool
fill 509 152 276 510 152 276 minecraft:deepslate_tiles
fill 509 152 295 509 152 297 minecraft:deepslate_tiles
setblock 509 152 298 minecraft:cobbled_deepslate
fill 509 152 299 510 154 299 minecraft:deepslate_tiles
setblock 510 152 277 minecraft:cobbled_deepslate
fill 510 152 278 511 152 280 minecraft:deepslate_tiles
fill 510 152 290 510 152 291 minecraft:deepslate_tiles
setblock 510 152 292 minecraft:cobbled_deepslate
fill 510 152 293 510 152 296 minecraft:deepslate_tiles
setblock 510 152 297 minecraft:cobbled_deepslate
fill 510 152 298 510 155 298 minecraft:deepslate_tiles
fill 510 152 300 510 152 301 minecraft:deepslate_tiles
setblock 510 152 302 minecraft:cobbled_deepslate
setblock 510 152 316 minecraft:deepslate_tiles
setblock 511 152 276 minecraft:cobbled_deepslate
fill 511 152 277 511 155 277 minecraft:deepslate_tiles
setblock 511 152 281 minecraft:cobbled_deepslate
fill 511 152 282 511 152 285 minecraft:deepslate_tiles
setblock 511 152 286 minecraft:cobbled_deepslate
fill 511 152 287 511 152 290 minecraft:deepslate_tiles
setblock 511 152 291 minecraft:cobbled_deepslate
fill 511 152 292 511 152 295 minecraft:deepslate_tiles
setblock 511 152 296 minecraft:cobbled_deepslate
fill 511 152 297 511 155 297 minecraft:deepslate_tiles
setblock 511 152 300 minecraft:deepslate_tiles
setblock 511 152 301 minecraft:cobbled_deepslate
fill 511 152 302 511 155 302 minecraft:deepslate_tiles
setblock 511 152 315 minecraft:deepslate_tiles
setblock 511 152 316 minecraft:cobbled_deepslate
setblock 470 153 313 minecraft:redstone_block
fill 471 153 276 471 153 279 minecraft:deepslate_tiles
setblock 471 153 280 minecraft:cobbled_deepslate
fill 471 153 281 471 156 281 minecraft:deepslate_tiles
setblock 471 153 284 minecraft:deepslate_tiles
setblock 471 153 304 minecraft:deepslate_tiles
fill 471 153 311 474 153 311 minecraft:cobbled_deepslate
setblock 471 153 314 minecraft:deepslate_tiles
setblock 471 153 315 minecraft:cobbled_deepslate
fill 471 153 316 474 153 316 minecraft:deepslate_tiles
fill 472 153 276 472 153 278 minecraft:deepslate_tiles
setblock 472 153 279 minecraft:cobbled_deepslate
fill 472 153 280 472 156 280 minecraft:deepslate_tiles
setblock 472 153 283 minecraft:deepslate_tiles
setblock 472 153 284 minecraft:cobbled_deepslate
fill 472 153 307 481 153 307 minecraft:cobbled_deepslate
fill 472 153 315 475 153 315 minecraft:deepslate_tiles
fill 473 153 276 473 153 277 minecraft:deepslate_tiles
setblock 473 153 278 minecraft:cobbled_deepslate
fill 473 153 279 473 156 279 minecraft:deepslate_tiles
setblock 473 153 283 minecraft:cobbled_deepslate
setblock 474 153 276 minecraft:deepslate_tiles
setblock 474 153 277 minecraft:cobbled_deepslate
fill 474 153 278 477 153 278 minecraft:deepslate_tiles
setblock 475 153 276 minecraft:cobbled_deepslate
fill 475 153 277 478 153 277 minecraft:deepslate_tiles
fill 475 153 279 476 153 279 minecraft:deepslate_tiles
setblock 475 153 316 minecraft:cobbled_deepslate
fill 476 153 276 479 153 276 minecraft:deepslate_tiles
setblock 476 153 315 minecraft:cobbled_deepslate
fill 476 153 316 479 153 316 minecraft:deepslate_tiles
fill 477 153 315 478 153 315 minecraft:deepslate_tiles
setblock 478 153 278 minecraft:cobbled_deepslate
fill 478 153 308 478 153 314 minecraft:white_wool
setblock 479 153 277 minecraft:cobbled_deepslate
setblock 479 153 278 minecraft:deepslate_tiles
setblock 480 153 276 minecraft:cobbled_deepslate
fill 480 153 277 483 153 277 minecraft:deepslate_tiles
fill 480 153 287 487 153 287 minecraft:cobbled_deepslate
fill 480 153 299 487 153 299 minecraft:cobbled_deepslate
setblock 480 153 316 minecraft:cobbled_deepslate
fill 481 153 276 484 153 276 minecraft:deepslate_tiles
fill 481 153 316 484 153 316 minecraft:deepslate_tiles
fill 482 153 306 482 153 315 minecraft:white_wool
fill 483 153 307 501 153 307 minecraft:cobbled_deepslate
setblock 485 153 276 minecraft:cobbled_deepslate
setblock 485 153 316 minecraft:cobbled_deepslate
fill 486 153 276 489 153 276 minecraft:deepslate_tiles
fill 486 153 316 489 153 316 minecraft:deepslate_tiles
fill 487 153 277 488 153 277 minecraft:deepslate_tiles
fill 488 153 315 490 153 315 minecraft:deepslate_tiles
setblock 489 153 277 minecraft:cobbled_deepslate
setblock 490 153 276 minecraft:cobbled_deepslate
fill 490 153 277 493 153 277 minecraft:deepslate_tiles
setblock 490 153 316 minecraft:cobbled_deepslate
fill 491 153 276 494 153 276 minecraft:deepslate_tiles
setblock 491 153 315 minecraft:cobbled_deepslate
fill 491 153 316 494 153 316 minecraft:deepslate_tiles
fill 492 153 315 495 153 315 minecraft:deepslate_tiles
setblock 493 153 314 minecraft:deepslate_tiles
setblock 494 153 277 minecraft:cobbled_deepslate
setblock 495 153 276 minecraft:cobbled_deepslate
fill 495 153 277 495 154 277 minecraft:deepslate_tiles
setblock 495 153 316 minecraft:cobbled_deepslate
fill 496 153 276 499 153 276 minecraft:deepslate_tiles
setblock 496 153 315 minecraft:cobbled_deepslate
fill 496 153 316 499 153 316 minecraft:deepslate_tiles
fill 497 153 287 510 153 287 minecraft:cobbled_deepslate
fill 497 153 291 510 153 291 minecraft:cobbled_deepslate
fill 497 153 299 508 153 299 minecraft:cobbled_deepslate
setblock 497 153 315 minecraft:deepslate_tiles
setblock 500 153 316 minecraft:cobbled_deepslate
fill 508 153 275 508 162 275 minecraft:black_concrete
setblock 509 153 276 minecraft:deepslate_tiles
setblock 509 153 296 minecraft:deepslate_tiles
setblock 509 153 297 minecraft:cobbled_deepslate
fill 509 153 298 509 156 298 minecraft:deepslate_tiles
setblock 509 153 307 minecraft:white_wool
setblock 510 153 276 minecraft:cobbled_deepslate
fill 510 153 277 510 153 280 minecraft:deepslate_tiles
setblock 510 153 281 minecraft:cobbled_deepslate
fill 510 153 282 511 155 282 minecraft:deepslate_tiles
fill 510 153 292 510 153 295 minecraft:deepslate_tiles
setblock 510 153 296 minecraft:cobbled_deepslate
fill 510 153 297 510 156 297 minecraft:deepslate_tiles
setblock 510 153 300 minecraft:deepslate_tiles
setblock 510 153 301 minecraft:cobbled_deepslate
fill 510 153 302 510 155 303 minecraft:deepslate_tiles
fill 511 153 276 511 156 276 minecraft:deepslate_tiles
fill 511 153 278 511 153 279 minecraft:deepslate_tiles
setblock 511 153 280 minecraft:cobbled_deepslate
fill 511 153 281 511 156 281 minecraft:deepslate_tiles
fill 511 153 283 511 153 284 minecraft:deepslate_tiles
setblock 511 153 285 minecraft:cobbled_deepslate
fill 511 153 286 511 153 289 minecraft:deepslate_tiles
setblock 511 153 290 minecraft:cobbled_deepslate
fill 511 153 291 511 153 294 minecraft:deepslate_tiles
setblock 511 153 295 minecraft:cobbled_deepslate
fill 511 153 296 511 156 296 minecraft:deepslate_tiles
setblock 511 153 300 minecraft:cobbled_deepslate
fill 511 153 301 511 156 301 minecraft:deepslate_tiles
setblock 511 153 304 minecraft:deepslate_tiles
setblock 511 153 305 minecraft:cobbled_deepslate
fill 511 153 316 511 154 316 minecraft:deepslate_tiles
fill 470 154 313 470 188 313 minecraft:black_concrete
fill 471 154 276 471 154 278 minecraft:deepslate_tiles
setblock 471 154 279 minecraft:cobbled_deepslate
fill 471 154 280 471 157 280 minecraft:deepslate_tiles
setblock 471 154 284 minecraft:cobbled_deepslate
setblock 471 154 304 minecraft:cobbled_deepslate
setblock 471 154 314 minecraft:cobbled_deepslate
fill 471 154 315 471 156 316 minecraft:deepslate_tiles
fill 472 154 276 472 154 277 minecraft:deepslate_tiles
setblock 472 154 278 minecraft:cobbled_deepslate
fill 472 154 279 472 157 279 minecraft:deepslate_tiles
setblock 472 154 283 minecraft:cobbled_deepslate
fill 472 154 284 472 157 284 minecraft:deepslate_tiles
fill 472 154 316 473 154 316 minecraft:deepslate_tiles
setblock 473 154 276 minecraft:deepslate_tiles
setblock 473 154 277 minecraft:cobbled_deepslate
fill 473 154 278 476 154 278 minecraft:deepslate_tiles
setblock 473 154 282 minecraft:cobbled_deepslate
fill 473 154 283 473 157 283 minecraft:deepslate_tiles
setblock 474 154 276 minecraft:cobbled_deepslate
fill 474 154 277 477 154 277 minecraft:deepslate_tiles
setblock 474 154 315 minecraft:deepslate_tiles
setblock 474 154 316 minecraft:cobbled_deepslate
fill 475 154 276 478 154 276 minecraft:deepslate_tiles
setblock 475 154 279 minecraft:deepslate_tiles
setblock 475 154 315 minecraft:cobbled_deepslate
fill 475 154 316 478 154 316 minecraft:deepslate_tiles
setblock 477 154 278 minecraft:cobbled_deepslate
setblock 478 154 277 minecraft:cobbled_deepslate
setblock 478 154 278 minecraft:deepslate_tiles
fill 478 154 279 478 154 284 minecraft:white_wool
fill 478 154 304 478 154 310 minecraft:white_wool
setblock 479 154 276 minecraft:cobbled_deepslate
fill 479 154 277 481 154 277 minecraft:deepslate_tiles
setblock 479 154 316 minecraft:cobbled_deepslate
fill 480 154 276 483 154 276 minecraft:deepslate_tiles
fill 480 154 316 483 154 316 minecraft:deepslate_tiles
fill 482 154 277 482 154 290 minecraft:white_wool
fill 482 154 298 482 154 308 minecraft:white_wool
setblock 484 154 276 minecraft:cobbled_deepslate
setblock 484 154 316 minecraft:cobbled_deepslate
fill 485 154 276 488 154 276 minecraft:deepslate_tiles
fill 485 154 316 488 154 316 minecraft:deepslate_tiles
fill 486 154 277 486 154 291 minecraft:white_wool
fill 486 154 297 486 154 315 minecraft:white_wool
setblock 488 154 277 minecraft:cobbled_deepslate
fill 488 154 315 489 154 315 minecraft:deepslate_tiles
setblock 489 154 276 minecraft:cobbled_deepslate
fill 489 154 277 492 154 277 minecraft:deepslate_tiles
setblock 489 154 316 minecraft:cobbled_deepslate
fill 490 154 276 493 154 276 minecraft:deepslate_tiles
fill 490 154 278 490 155 284 minecraft:white_wool
setblock 490 154 315 minecraft:cobbled_deepslate
fill 490 154 316 493 154 316 minecraft:deepslate_tiles
fill 491 154 315 494 154 315 minecraft:deepslate_tiles
setblock 493 154 277 minecraft:cobbled_deepslate
setblock 494 154 276 minecraft:cobbled_deepslate
fill 494 154 277 494 156 277 minecraft:deepslate_tiles
fill 494 154 278 494 155 284 minecraft:white_wool
fill 494 154 304 494 155 314 minecraft:white_wool
setblock 494 154 316 minecraft:cobbled_deepslate
fill 495 154 276 498 154 276 minecraft:deepslate_tiles
setblock 495 154 315 minecraft:cobbled_deepslate
fill 495 154 316 498 154 316 minecraft:deepslate_tiles
setblock 496 154 315 minecraft:deepslate_tiles
fill 498 154 277 498 154 315 minecraft:white_wool
fill 499 154 307 501 154 307 minecraft:cobbled_deepslate
fill 502 154 276 502 154 315 minecraft:white_wool
fill 503 154 307 511 154 307 minecraft:cobbled_deepslate
fill 506 154 276 506 154 306 minecraft:white_wool
fill 506 154 308 506 154 315 minecraft:white_wool
setblock 509 154 276 minecraft:cobbled_deepslate
fill 509 154 277 510 156 277 minecraft:deepslate_tiles
setblock 509 154 297 minecraft:deepslate_tiles
fill 510 154 276 510 157 276 minecraft:deepslate_tiles
fill 510 154 278 510 154 279 minecraft:deepslate_tiles
setblock 510 154 280 minecraft:cobbled_deepslate
fill 510 154 281 510 157 281 minecraft:deepslate_tiles
fill 510 154 283 511 154 283 minecraft:deepslate_tiles
fill 510 154 292 510 154 294 minecraft:deepslate_tiles
setblock 510 154 295 minecraft:cobbled_deepslate
fill 510 154 296 510 157 296 minecraft:deepslate_tiles
setblock 510 154 300 minecraft:cobbled_deepslate
fill 510 154 301 510 157 301 minecraft:deepslate_tiles
setblock 511 154 278 minecraft:deepslate_tiles
setblock 511 154 279 minecraft:cobbled_deepslate
fill 511 154 280 511 157 280 minecraft:deepslate_tiles
setblock 511 154 284 minecraft:cobbled_deepslate
fill 511 154 285 511 154 288 minecraft:deepslate_tiles
setblock 511 154 289 minecraft:cobbled_deepslate
fill 511 154 290 511 154 293 minecraft:deepslate_tiles
setblock 511 154 294 minecraft:cobbled_deepslate
fill 511 154 295 511 157 295 minecraft:deepslate_tiles
setblock 511 154 299 minecraft:cobbled_deepslate
fill 511 154 300 511 157 300 minecraft:deepslate_tiles
setblock 511 154 304 minecraft:cobbled_deepslate
fill 511 154 305 511 157 305 minecraft:deepslate_tiles
fill 471 155 276 471 155 277 minecraft:deepslate_tiles
setblock 471 155 278 minecraft:cobbled_deepslate
fill 471 155 279 471 158 279 minecraft:deepslate_tiles
setblock 471 155 283 minecraft:cobbled_deepslate
fill 471 155 284 471 158 284 minecraft:deepslate_tiles
fill 471 155 304 471 157 305 minecraft:deepslate_tiles
setblock 472 155 276 minecraft:deepslate_tiles
setblock 472 155 277 minecraft:cobbled_deepslate
fill 472 155 278 475 155 278 minecraft:deepslate_tiles
setblock 472 155 282 minecraft:cobbled_deepslate
fill 472 155 283 472 158 283 minecraft:deepslate_tiles
setblock 472 155 316 minecraft:deepslate_tiles
setblock 473 155 276 minecraft:cobbled_deepslate
fill 473 155 277 476 155 277 minecraft:deepslate_tiles
setblock 473 155 281 minecraft:cobbled_deepslate
fill 473 155 282 473 158 282 minecraft:deepslate_tiles
setblock 473 155 316 minecraft:cobbled_deepslate
fill 474 155 276 477 155 276 minecraft:deepslate_tiles
setblock 474 155 280 minecraft:cobbled_deepslate
fill 474 155 281 474 155 284 minecraft:white_wool
fill 474 155 304 474 155 313 minecraft:white_wool
fill 474 155 316 477 155 316 minecraft:deepslate_tiles
setblock 476 155 278 minecraft:cobbled_deepslate
setblock 477 155 277 minecraft:cobbled_deepslate
fill 477 155 278 477 156 278 minecraft:deepslate_tiles
setblock 478 155 276 minecraft:cobbled_deepslate
fill 478 155 277 480 155 277 minecraft:deepslate_tiles
setblock 478 155 316 minecraft:cobbled_deepslate
fill 479 155 276 482 155 276 minecraft:deepslate_tiles
fill 479 155 316 481 155 316 minecraft:deepslate_tiles
setblock 482 155 277 minecraft:white_wool
setblock 483 155 276 minecraft:cobbled_deepslate
setblock 483 155 316 minecraft:cobbled_deepslate
fill 484 155 276 487 155 276 minecraft:deepslate_tiles
fill 484 155 316 487 155 316 minecraft:deepslate_tiles
fill 486 155 277 486 155 278 minecraft:white_wool
setblock 488 155 276 minecraft:cobbled_deepslate
fill 488 155 277 491 155 277 minecraft:deepslate_tiles
setblock 488 155 316 minecraft:cobbled_deepslate
fill 489 155 276 492 155 276 minecraft:deepslate_tiles
setblock 489 155 315 minecraft:cobbled_deepslate
fill 489 155 316 492 155 316 minecraft:deepslate_tiles
fill 490 155 304 490 155 314 minecraft:white_wool
fill 490 155 315 493 155 315 minecraft:deepslate_tiles
setblock 492 155 277 minecraft:cobbled_deepslate
setblock 493 155 276 minecraft:cobbled_deepslate
fill 493 155 277 493 157 277 minecraft:deepslate_tiles
setblock 493 155 316 minecraft:cobbled_deepslate
fill 494 155 276 497 155 276 minecraft:deepslate_tiles
setblock 494 155 315 minecraft:cobbled_deepslate
fill 494 155 316 497 155 316 minecraft:deepslate_tiles
setblock 496 155 317 minecraft:white_wool
fill 497 155 317 497 201 317 minecraft:black_concrete
fill 498 155 276 498 155 280 minecraft:white_wool
fill 502 155 276 502 155 285 minecraft:white_wool
fill 506 155 276 506 155 278 minecraft:white_wool
setblock 508 155 276 minecraft:cobbled_deepslate
fill 509 155 276 509 158 276 minecraft:deepslate_tiles
setblock 509 155 299 minecraft:deepslate_tiles
fill 509 155 307 510 155 307 minecraft:white_wool
fill 509 155 314 509 163 314 minecraft:black_concrete
setblock 510 155 278 minecraft:deepslate_tiles
setblock 510 155 279 minecraft:cobbled_deepslate
fill 510 155 280 510 158 280 minecraft:deepslate_tiles
setblock 510 155 283 minecraft:deepslate_tiles
setblock 510 155 284 minecraft:cobbled_deepslate
fill 510 155 285 511 157 285 minecraft:deepslate_tiles
fill 510 155 286 510 155 291 minecraft:white_wool
fill 510 155 292 510 155 293 minecraft:deepslate_tiles
setblock 510 155 294 minecraft:cobbled_deepslate
fill 510 155 295 510 158 295 minecraft:deepslate_tiles
setblock 510 155 299 minecraft:cobbled_deepslate
fill 510 155 300 510 158 300 minecraft:deepslate_tiles
fill 510 155 304 510 155 306 minecraft:white_wool
fill 510 155 308 510 155 315 minecraft:white_wool
setblock 511 155 278 minecraft:cobbled_deepslate
fill 511 155 279 511 158 279 minecraft:deepslate_tiles
setblock 511 155 283 minecraft:cobbled_deepslate
fill 511 155 284 511 158 284 minecraft:deepslate_tiles
fill 511 155 286 511 155 287 minecraft:deepslate_tiles
setblock 511 155 288 minecraft:cobbled_deepslate
fill 511 155 289 511 155 292 minecraft:deepslate_tiles
setblock 511 155 293 minecraft:cobbled_deepslate
fill 511 155 294 511 158 294 minecraft:deepslate_tiles
setblock 511 155 298 minecraft:cobbled_deepslate
fill 511 155 299 511 158 299 minecraft:deepslate_tiles
setblock 511 155 303 minecraft:cobbled_deepslate
fill 511 155 304 511 158 304 minecraft:deepslate_tiles
fill 511 155 306 511 156 306 minecraft:deepslate_tiles
setblock 512 155 307 minecraft:white_wool
setblock 471 156 276 minecraft:deepslate_tiles
setblock 471 156 277 minecraft:cobbled_deepslate
fill 471 156 278 474 156 278 minecraft:deepslate_tiles
setblock 471 156 282 minecraft:cobbled_deepslate
fill 471 156 283 471 159 283 minecraft:deepslate_tiles
fill 471 156 285 471 156 286 minecraft:deepslate_tiles
setblock 471 156 287 minecraft:cobbled_deepslate
fill 471 156 288 471 156 291 minecraft:deepslate_tiles
setblock 471 156 292 minecraft:cobbled_deepslate
fill 471 156 293 471 156 296 minecraft:deepslate_tiles
setblock 471 156 297 minecraft:cobbled_deepslate
fill 471 156 298 471 156 301 minecraft:deepslate_tiles
setblock 471 156 302 minecraft:cobbled_deepslate
fill 471 156 303 471 159 303 minecraft:deepslate_tiles
setblock 471 156 306 minecraft:deepslate_tiles
setblock 472 156 276 minecraft:cobbled_deepslate
fill 472 156 277 475 156 277 minecraft:deepslate_tiles
setblock 472 156 281 minecraft:cobbled_deepslate
fill 472 156 282 472 159 282 minecraft:deepslate_tiles
setblock 472 156 285 minecraft:deepslate_tiles
setblock 472 156 286 minecraft:cobbled_deepslate
fill 472 156 298 472 156 300 minecraft:deepslate_tiles
setblock 472 156 301 minecraft:cobbled_deepslate
fill 472 156 302 472 159 302 minecraft:deepslate_tiles
setblock 472 156 316 minecraft:cobbled_deepslate
fill 473 156 276 476 156 276 minecraft:deepslate_tiles
setblock 473 156 280 minecraft:cobbled_deepslate
fill 473 156 281 473 159 281 minecraft:deepslate_tiles
setblock 473 156 284 minecraft:deepslate_tiles
fill 473 156 291 477 157 293 minecraft:bone_block
fill 473 156 316 476 156 316 minecraft:deepslate_tiles
setblock 474 156 279 minecraft:cobbled_deepslate
fill 474 156 280 474 158 280 minecraft:deepslate_tiles
fill 474 156 290 476 158 290 minecraft:bone_block
fill 474 156 294 476 158 294 minecraft:bone_block
fill 474 156 311 474 156 315 minecraft:white_wool
setblock 475 156 278 minecraft:cobbled_deepslate
setblock 476 156 277 minecraft:cobbled_deepslate
fill 476 156 278 476 158 278 minecraft:deepslate_tiles
setblock 477 156 276 minecraft:cobbled_deepslate
fill 477 156 277 479 157 277 minecraft:deepslate_tiles
setblock 477 156 316 minecraft:cobbled_deepslate
fill 478 156 276 481 156 276 minecraft:deepslate_tiles
fill 478 156 316 479 156 316 minecraft:deepslate_tiles
setblock 482 156 276 minecraft:cobbled_deepslate
fill 483 156 276 486 156 276 minecraft:deepslate_tiles
fill 485 156 316 486 156 316 minecraft:deepslate_tiles
setblock 487 156 276 minecraft:cobbled_deepslate
setblock 487 156 316 minecraft:cobbled_deepslate
fill 488 156 276 490 156 277 minecraft:deepslate_tiles
fill 488 156 316 491 156 316 minecraft:deepslate_tiles
fill 489 156 315 492 156 315 minecraft:deepslate_tiles
setblock 491 156 276 minecraft:deepslate_tiles
setblock 491 156 277 minecraft:cobbled_deepslate
setblock 492 156 276 minecraft:cobbled_deepslate
fill 492 156 277 492 159 277 minecraft:deepslate_tiles
setblock 492 156 316 minecraft:cobbled_deepslate
fill 493 156 276 496 156 276 minecraft:deepslate_tiles
setblock 493 156 315 minecraft:cobbled_deepslate
fill 493 156 316 496 156 316 minecraft:deepslate_tiles
fill 496 156 317 496 187 317 minecraft:black_concrete
setblock 507 156 276 minecraft:cobbled_deepslate
fill 508 156 276 508 159 276 minecraft:deepslate_tiles
setblock 509 156 299 minecraft:cobbled_deepslate
fill 509 156 300 509 159 300 minecraft:deepslate_tiles
fill 509 156 307 509 161 307 minecraft:white_wool
setblock 510 156 278 minecraft:cobbled_deepslate
fill 510 156 279 510 159 279 minecraft:deepslate_tiles
setblock 510 156 282 minecraft:deepslate_tiles
setblock 510 156 283 minecraft:cobbled_deepslate
fill 510 156 284 510 159 284 minecraft:deepslate_tiles
fill 510 156 286 510 156 287 minecraft:deepslate_tiles
setblock 510 156 292 minecraft:deepslate_tiles
setblock 510 156 293 minecraft:cobbled_deepslate
fill 510 156 294 510 159 294 minecraft:deepslate_tiles
setblock 510 156 298 minecraft:cobbled_deepslate
fill 510 156 299 510 159 299 minecraft:deepslate_tiles
setblock 510 156 302 minecraft:deepslate_tiles
setblock 510 156 303 minecraft:cobbled_deepslate
fill 510 156 304 510 159 304 minecraft:deepslate_tiles
setblock 511 156 277 minecraft:cobbled_deepslate
fill 511 156 278 511 159 278 minecraft:deepslate_tiles
setblock 511 156 282 minecraft:cobbled_deepslate
fill 511 156 283 511 159 283 minecraft:deepslate_tiles
setblock 511 156 286 minecraft:deepslate_tiles
setblock 511 156 287 minecraft:cobbled_deepslate
fill 511 156 288 511 156 291 minecraft:deepslate_tiles
setblock 511 156 292 minecraft:cobbled_deepslate
fill 511 156 293 511 159 293 minecraft:deepslate_tiles
setblock 511 156 297 minecraft:cobbled_deepslate
fill 511 156 298 511 159 298 minecraft:deepslate_tiles
setblock 511 156 302 minecraft:cobbled_deepslate
fill 511 156 303 511 159 303 minecraft:deepslate_tiles
fill 512 156 307 512 201 307 minecraft:black_concrete
setblock 471 157 276 minecraft:cobbled_deepslate
fill 471 157 277 473 157 278 minecraft:deepslate_tiles
setblock 471 157 281 minecraft:cobbled_deepslate
fill 471 157 282 471 160 282 minecraft:deepslate_tiles
setblock 471 157 285 minecraft:deepslate_tiles
setblock 471 157 286 minecraft:cobbled_deepslate
fill 471 157 287 471 157 290 minecraft:deepslate_tiles
setblock 471 157 291 minecraft:cobbled_deepslate
fill 471 157 292 471 157 295 minecraft:deepslate_tiles
setblock 471 157 296 minecraft:cobbled_deepslate
fill 471 157 297 471 157 300 minecraft:deepslate_tiles
setblock 471 157 301 minecraft:cobbled_deepslate
fill 471 157 302 471 160 302 minecraft:deepslate_tiles
setblock 471 157 306 minecraft:cobbled_deepslate
fill 471 157 307 471 160 307 minecraft:deepslate_tiles
fill 471 157 314 471 157 315 minecraft:deepslate_tiles
setblock 471 157 316 minecraft:cobbled_deepslate
fill 472 157 276 475 157 276 minecraft:deepslate_tiles
setblock 472 157 280 minecraft:cobbled_deepslate
fill 472 157 281 472 160 281 minecraft:deepslate_tiles
setblock 472 157 285 minecraft:cobbled_deepslate
fill 472 157 286 472 159 287 minecraft:deepslate_tiles
setblock 472 157 299 minecraft:deepslate_tiles
setblock 472 157 300 minecraft:cobbled_deepslate
fill 472 157 301 472 160 301 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_7 1t
