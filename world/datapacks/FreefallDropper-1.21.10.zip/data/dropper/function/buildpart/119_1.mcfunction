fill 545 140 480 545 140 482 minecraft:ochre_froglight
fill 545 140 488 545 140 490 minecraft:ochre_froglight
fill 545 140 505 546 220 505 minecraft:red_terracotta
fill 546 140 479 558 140 479 minecraft:dark_oak_planks
fill 546 140 480 546 140 481 minecraft:gold_block
fill 546 140 482 546 140 483 minecraft:black_concrete
fill 546 140 487 546 140 488 minecraft:black_concrete
fill 546 140 489 546 140 490 minecraft:gold_block
fill 546 140 491 558 140 491 minecraft:dark_oak_planks
fill 547 140 463 549 219 463 minecraft:red_terracotta
fill 547 140 480 558 140 481 minecraft:dark_oak_planks
fill 547 140 482 547 140 484 minecraft:gold_block
setblock 547 140 485 minecraft:black_concrete
fill 547 140 486 547 140 488 minecraft:gold_block
fill 547 140 489 558 140 490 minecraft:dark_oak_planks
fill 548 140 482 558 140 484 minecraft:dark_oak_planks
fill 548 140 486 558 140 488 minecraft:dark_oak_planks
fill 549 140 485 558 140 485 minecraft:dark_oak_planks
setblock 550 140 463 minecraft:black_concrete
fill 551 140 463 553 219 463 minecraft:red_terracotta
setblock 554 140 463 minecraft:black_concrete
fill 555 140 463 555 220 463 minecraft:red_terracotta
fill 557 140 463 557 222 463 minecraft:red_terracotta
fill 559 140 465 559 222 465 minecraft:red_terracotta
fill 559 140 497 559 220 497 minecraft:red_terracotta
fill 517 141 463 518 222 463 minecraft:red_terracotta
fill 517 141 465 517 222 465 minecraft:red_terracotta
fill 517 141 472 517 222 472 minecraft:red_terracotta
fill 517 141 489 517 218 489 minecraft:red_terracotta
fill 523 141 505 523 223 505 minecraft:red_terracotta
fill 531 141 463 531 222 463 minecraft:red_terracotta
fill 539 141 463 539 222 463 minecraft:red_terracotta
fill 544 141 505 544 222 505 minecraft:red_terracotta
fill 550 141 463 550 223 463 minecraft:red_terracotta
fill 554 141 463 554 222 463 minecraft:red_terracotta
setblock 520 142 466 minecraft:light[level=12]
setblock 520 142 474 minecraft:light[level=12]
setblock 520 142 482 minecraft:light[level=12]
setblock 520 142 490 minecraft:light[level=12]
setblock 520 142 498 minecraft:light[level=12]
setblock 528 142 466 minecraft:light[level=12]
setblock 528 142 474 minecraft:light[level=12]
setblock 528 142 482 minecraft:light[level=12]
setblock 528 142 490 minecraft:light[level=12]
setblock 528 142 498 minecraft:light[level=12]
setblock 536 142 466 minecraft:light[level=12]
setblock 536 142 474 minecraft:light[level=12]
setblock 536 142 482 minecraft:light[level=12]
setblock 536 142 490 minecraft:light[level=12]
setblock 536 142 498 minecraft:light[level=12]
setblock 544 142 466 minecraft:light[level=12]
setblock 544 142 474 minecraft:light[level=12]
setblock 544 142 482 minecraft:light[level=12]
setblock 544 142 490 minecraft:light[level=12]
setblock 544 142 498 minecraft:light[level=12]
setblock 552 142 466 minecraft:light[level=12]
setblock 552 142 474 minecraft:light[level=12]
setblock 552 142 482 minecraft:light[level=12]
setblock 552 142 490 minecraft:light[level=12]
setblock 552 142 498 minecraft:light[level=12]
setblock 518 144 466 minecraft:gold_block
fill 518 144 469 518 188 469 minecraft:gold_block
setblock 518 144 473 minecraft:gold_block
fill 518 144 476 518 188 476 minecraft:gold_block
setblock 518 144 480 minecraft:gold_block
fill 518 144 483 518 188 483 minecraft:gold_block
setblock 518 144 487 minecraft:gold_block
fill 518 144 490 518 188 490 minecraft:gold_block
setblock 518 144 494 minecraft:gold_block
fill 518 144 497 518 188 497 minecraft:gold_block
setblock 518 144 501 minecraft:gold_block
fill 518 144 504 518 188 504 minecraft:gold_block
fill 520 144 464 520 188 464 minecraft:gold_block
fill 520 144 468 520 150 468 minecraft:white_wool
fill 520 144 470 520 153 470 minecraft:white_wool
setblock 522 144 504 minecraft:gold_block
setblock 523 144 464 minecraft:gold_block
fill 524 144 485 524 146 485 minecraft:white_wool
fill 525 144 504 525 188 504 minecraft:gold_block
fill 527 144 464 527 188 464 minecraft:gold_block
setblock 529 144 504 minecraft:gold_block
setblock 530 144 464 minecraft:gold_block
fill 532 144 504 532 188 504 minecraft:gold_block
fill 534 144 464 534 188 464 minecraft:gold_block
setblock 536 144 504 minecraft:gold_block
setblock 537 144 464 minecraft:gold_block
fill 539 144 504 539 188 504 minecraft:gold_block
fill 541 144 464 541 188 464 minecraft:gold_block
setblock 543 144 504 minecraft:gold_block
setblock 544 144 464 minecraft:gold_block
fill 546 144 504 546 188 504 minecraft:gold_block
fill 548 144 464 548 188 464 minecraft:gold_block
fill 548 144 502 548 145 502 minecraft:white_wool
setblock 550 144 504 minecraft:gold_block
setblock 551 144 464 minecraft:gold_block
fill 553 144 504 553 188 504 minecraft:gold_block
fill 555 144 464 555 188 464 minecraft:gold_block
setblock 557 144 504 minecraft:gold_block
setblock 558 144 464 minecraft:gold_block
fill 558 144 468 558 188 468 minecraft:gold_block
setblock 558 144 471 minecraft:gold_block
fill 558 144 475 558 188 475 minecraft:gold_block
setblock 558 144 478 minecraft:gold_block
fill 558 144 482 558 188 482 minecraft:gold_block
setblock 558 144 485 minecraft:gold_block
fill 558 144 489 558 188 489 minecraft:gold_block
setblock 558 144 492 minecraft:gold_block
fill 558 144 496 558 188 496 minecraft:gold_block
setblock 558 144 499 minecraft:gold_block
fill 558 144 503 558 188 503 minecraft:gold_block
setblock 518 145 467 minecraft:gold_block
setblock 518 145 474 minecraft:gold_block
setblock 518 145 481 minecraft:gold_block
setblock 518 145 488 minecraft:gold_block
setblock 518 145 495 minecraft:gold_block
setblock 518 145 502 minecraft:gold_block
setblock 522 145 464 minecraft:gold_block
setblock 523 145 504 minecraft:gold_block
setblock 529 145 464 minecraft:gold_block
setblock 530 145 504 minecraft:gold_block
setblock 536 145 464 minecraft:gold_block
setblock 537 145 504 minecraft:gold_block
setblock 543 145 464 minecraft:gold_block
setblock 544 145 504 minecraft:gold_block
setblock 550 145 464 minecraft:gold_block
setblock 551 145 504 minecraft:gold_block
setblock 557 145 464 minecraft:gold_block
setblock 558 145 470 minecraft:gold_block
setblock 558 145 477 minecraft:gold_block
setblock 558 145 484 minecraft:gold_block
setblock 558 145 491 minecraft:gold_block
setblock 558 145 498 minecraft:gold_block
setblock 558 145 504 minecraft:gold_block
setblock 518 146 468 minecraft:gold_block
setblock 518 146 475 minecraft:gold_block
setblock 518 146 482 minecraft:gold_block
setblock 518 146 489 minecraft:gold_block
setblock 518 146 496 minecraft:gold_block
setblock 518 146 503 minecraft:gold_block
setblock 521 146 464 minecraft:gold_block
setblock 524 146 504 minecraft:gold_block
setblock 528 146 464 minecraft:gold_block
setblock 531 146 504 minecraft:gold_block
setblock 535 146 464 minecraft:gold_block
setblock 538 146 504 minecraft:gold_block
setblock 542 146 464 minecraft:gold_block
setblock 545 146 504 minecraft:gold_block
setblock 549 146 464 minecraft:gold_block
setblock 552 146 504 minecraft:gold_block
setblock 556 146 464 minecraft:gold_block
setblock 558 146 469 minecraft:gold_block
setblock 558 146 476 minecraft:gold_block
setblock 558 146 483 minecraft:gold_block
setblock 558 146 490 minecraft:gold_block
setblock 558 146 497 minecraft:gold_block
setblock 518 148 470 minecraft:gold_block
setblock 518 148 477 minecraft:gold_block
setblock 518 148 484 minecraft:gold_block
setblock 518 148 491 minecraft:gold_block
setblock 518 148 498 minecraft:gold_block
setblock 519 148 464 minecraft:gold_block
setblock 519 148 504 minecraft:gold_block
setblock 526 148 464 minecraft:gold_block
setblock 526 148 504 minecraft:gold_block
setblock 533 148 464 minecraft:gold_block
setblock 533 148 504 minecraft:gold_block
setblock 540 148 464 minecraft:gold_block
setblock 540 148 504 minecraft:gold_block
setblock 547 148 464 minecraft:gold_block
setblock 547 148 504 minecraft:gold_block
setblock 554 148 464 minecraft:gold_block
setblock 554 148 504 minecraft:gold_block
setblock 558 148 467 minecraft:gold_block
setblock 558 148 474 minecraft:gold_block
setblock 558 148 481 minecraft:gold_block
setblock 558 148 488 minecraft:gold_block
setblock 558 148 495 minecraft:gold_block
setblock 558 148 502 minecraft:gold_block
fill 518 149 464 518 150 464 minecraft:gold_block
fill 518 149 471 518 150 471 minecraft:gold_block
fill 518 149 478 518 150 478 minecraft:gold_block
fill 518 149 485 518 150 485 minecraft:gold_block
fill 518 149 492 518 150 492 minecraft:gold_block
fill 518 149 499 518 150 499 minecraft:gold_block
fill 520 149 504 520 150 504 minecraft:gold_block
fill 525 149 464 525 150 464 minecraft:gold_block
fill 527 149 504 527 150 504 minecraft:gold_block
fill 532 149 464 532 150 464 minecraft:gold_block
fill 534 149 504 534 150 504 minecraft:gold_block
fill 539 149 464 539 150 464 minecraft:gold_block
fill 541 149 504 541 150 504 minecraft:gold_block
fill 546 149 464 546 150 464 minecraft:gold_block
fill 548 149 504 548 150 504 minecraft:gold_block
fill 553 149 464 553 150 464 minecraft:gold_block
fill 555 149 504 555 150 504 minecraft:gold_block
fill 558 149 466 558 150 466 minecraft:gold_block
fill 558 149 473 558 150 473 minecraft:gold_block
fill 558 149 480 558 150 480 minecraft:gold_block
fill 558 149 487 558 150 487 minecraft:gold_block
fill 558 149 494 558 150 494 minecraft:gold_block
fill 558 149 501 558 150 501 minecraft:gold_block
fill 518 150 465 518 150 468 minecraft:gold_block
setblock 518 150 470 minecraft:gold_block
fill 518 150 472 518 150 475 minecraft:gold_block
setblock 518 150 477 minecraft:gold_block
fill 518 150 479 518 150 482 minecraft:gold_block
setblock 518 150 484 minecraft:gold_block
fill 518 150 486 518 150 489 minecraft:gold_block
setblock 518 150 491 minecraft:gold_block
fill 518 150 493 518 150 496 minecraft:gold_block
setblock 518 150 498 minecraft:gold_block
fill 518 150 500 518 150 503 minecraft:gold_block
setblock 519 150 464 minecraft:gold_block
setblock 519 150 504 minecraft:gold_block
setblock 520 150 466 minecraft:light[level=12]
setblock 520 150 474 minecraft:light[level=12]
setblock 520 150 482 minecraft:light[level=12]
setblock 520 150 490 minecraft:light[level=12]
setblock 520 150 498 minecraft:light[level=12]
fill 521 150 464 524 150 464 minecraft:gold_block
fill 521 150 504 524 150 504 minecraft:gold_block
setblock 526 150 464 minecraft:gold_block
setblock 526 150 504 minecraft:gold_block
fill 528 150 464 531 150 464 minecraft:gold_block
setblock 528 150 466 minecraft:light[level=12]
setblock 528 150 474 minecraft:light[level=12]
setblock 528 150 482 minecraft:light[level=12]
setblock 528 150 490 minecraft:light[level=12]
setblock 528 150 498 minecraft:light[level=12]
fill 528 150 504 531 150 504 minecraft:gold_block
setblock 533 150 464 minecraft:gold_block
setblock 533 150 504 minecraft:gold_block
fill 535 150 464 538 150 464 minecraft:gold_block
fill 535 150 504 538 150 504 minecraft:gold_block
setblock 536 150 466 minecraft:light[level=12]
setblock 536 150 474 minecraft:light[level=12]
setblock 536 150 482 minecraft:light[level=12]
setblock 536 150 490 minecraft:light[level=12]
setblock 536 150 498 minecraft:light[level=12]
setblock 540 150 464 minecraft:gold_block
setblock 540 150 504 minecraft:gold_block
fill 542 150 464 545 150 464 minecraft:gold_block
fill 542 150 504 545 150 504 minecraft:gold_block
setblock 544 150 466 minecraft:light[level=12]
setblock 544 150 474 minecraft:light[level=12]
setblock 544 150 482 minecraft:light[level=12]
setblock 544 150 490 minecraft:light[level=12]
setblock 544 150 498 minecraft:light[level=12]
setblock 547 150 464 minecraft:gold_block
setblock 547 150 504 minecraft:gold_block
fill 549 150 464 552 150 464 minecraft:gold_block
fill 549 150 504 552 150 504 minecraft:gold_block
setblock 552 150 466 minecraft:light[level=12]
setblock 552 150 474 minecraft:light[level=12]
setblock 552 150 482 minecraft:light[level=12]
setblock 552 150 490 minecraft:light[level=12]
setblock 552 150 498 minecraft:light[level=12]
setblock 554 150 464 minecraft:gold_block
setblock 554 150 504 minecraft:gold_block
fill 556 150 464 558 150 464 minecraft:gold_block
fill 556 150 504 558 150 504 minecraft:gold_block
setblock 558 150 465 minecraft:gold_block
setblock 558 150 467 minecraft:gold_block
fill 558 150 469 558 150 472 minecraft:gold_block
setblock 558 150 474 minecraft:gold_block
fill 558 150 476 558 150 479 minecraft:gold_block
setblock 558 150 481 minecraft:gold_block
fill 558 150 483 558 150 486 minecraft:gold_block
setblock 558 150 488 minecraft:gold_block
fill 558 150 490 558 150 493 minecraft:gold_block
setblock 558 150 495 minecraft:gold_block
fill 558 150 497 558 150 500 minecraft:gold_block
setblock 558 150 502 minecraft:gold_block
setblock 518 151 466 minecraft:gold_block
setblock 518 151 473 minecraft:gold_block
setblock 518 151 480 minecraft:gold_block
setblock 518 151 487 minecraft:gold_block
setblock 518 151 494 minecraft:gold_block
setblock 518 151 501 minecraft:gold_block
setblock 522 151 504 minecraft:gold_block
setblock 523 151 464 minecraft:gold_block
setblock 529 151 504 minecraft:gold_block
setblock 530 151 464 minecraft:gold_block
setblock 536 151 504 minecraft:gold_block
setblock 537 151 464 minecraft:gold_block
setblock 543 151 504 minecraft:gold_block
setblock 544 151 464 minecraft:gold_block
setblock 550 151 504 minecraft:gold_block
setblock 551 151 464 minecraft:gold_block
setblock 557 151 504 minecraft:gold_block
setblock 558 151 464 minecraft:gold_block
setblock 558 151 471 minecraft:gold_block
setblock 558 151 478 minecraft:gold_block
setblock 558 151 485 minecraft:gold_block
setblock 558 151 492 minecraft:gold_block
setblock 558 151 499 minecraft:gold_block
setblock 518 152 467 minecraft:gold_block
setblock 518 152 474 minecraft:gold_block
setblock 518 152 481 minecraft:gold_block
setblock 518 152 488 minecraft:gold_block
setblock 518 152 495 minecraft:gold_block
setblock 518 152 502 minecraft:gold_block
setblock 522 152 464 minecraft:gold_block
setblock 523 152 504 minecraft:gold_block
setblock 529 152 464 minecraft:gold_block
setblock 530 152 504 minecraft:gold_block
setblock 536 152 464 minecraft:gold_block
setblock 537 152 504 minecraft:gold_block
setblock 543 152 464 minecraft:gold_block
setblock 544 152 504 minecraft:gold_block
setblock 550 152 464 minecraft:gold_block
setblock 551 152 504 minecraft:gold_block
setblock 557 152 464 minecraft:gold_block
setblock 558 152 470 minecraft:gold_block
setblock 558 152 477 minecraft:gold_block
setblock 558 152 484 minecraft:gold_block
setblock 558 152 491 minecraft:gold_block
setblock 558 152 498 minecraft:gold_block
setblock 558 152 504 minecraft:gold_block
setblock 518 153 468 minecraft:gold_block
setblock 518 153 475 minecraft:gold_block
setblock 518 153 482 minecraft:gold_block
setblock 518 153 489 minecraft:gold_block
setblock 518 153 496 minecraft:gold_block
setblock 518 153 503 minecraft:gold_block
setblock 521 153 464 minecraft:gold_block
setblock 524 153 504 minecraft:gold_block
setblock 528 153 464 minecraft:gold_block
setblock 531 153 504 minecraft:gold_block
setblock 535 153 464 minecraft:gold_block
setblock 538 153 504 minecraft:gold_block
setblock 542 153 464 minecraft:gold_block
setblock 545 153 504 minecraft:gold_block
setblock 549 153 464 minecraft:gold_block
setblock 552 153 504 minecraft:gold_block
setblock 556 153 464 minecraft:gold_block
fill 556 153 494 556 174 494 minecraft:white_wool
setblock 558 153 469 minecraft:gold_block
setblock 558 153 476 minecraft:gold_block
setblock 558 153 483 minecraft:gold_block
setblock 558 153 490 minecraft:gold_block
setblock 558 153 497 minecraft:gold_block
setblock 518 155 470 minecraft:gold_block
setblock 518 155 477 minecraft:gold_block
setblock 518 155 484 minecraft:gold_block
setblock 518 155 491 minecraft:gold_block
setblock 518 155 498 minecraft:gold_block
setblock 519 155 464 minecraft:gold_block
setblock 519 155 504 minecraft:gold_block
setblock 526 155 464 minecraft:gold_block
setblock 526 155 504 minecraft:gold_block
setblock 533 155 464 minecraft:gold_block
setblock 533 155 504 minecraft:gold_block
setblock 540 155 464 minecraft:gold_block
setblock 540 155 504 minecraft:gold_block
setblock 547 155 464 minecraft:gold_block
setblock 547 155 504 minecraft:gold_block
setblock 554 155 464 minecraft:gold_block
setblock 554 155 504 minecraft:gold_block
setblock 558 155 467 minecraft:gold_block
setblock 558 155 474 minecraft:gold_block
setblock 558 155 481 minecraft:gold_block
setblock 558 155 488 minecraft:gold_block
setblock 558 155 495 minecraft:gold_block
setblock 558 155 502 minecraft:gold_block
setblock 518 156 464 minecraft:gold_block
setblock 518 156 471 minecraft:gold_block
setblock 518 156 478 minecraft:gold_block
setblock 518 156 485 minecraft:gold_block
setblock 518 156 492 minecraft:gold_block
setblock 518 156 499 minecraft:gold_block
setblock 520 156 504 minecraft:gold_block
setblock 525 156 464 minecraft:gold_block
setblock 527 156 504 minecraft:gold_block
setblock 532 156 464 minecraft:gold_block
setblock 534 156 504 minecraft:gold_block
setblock 539 156 464 minecraft:gold_block
setblock 541 156 504 minecraft:gold_block
setblock 546 156 464 minecraft:gold_block
setblock 548 156 504 minecraft:gold_block
setblock 553 156 464 minecraft:gold_block
setblock 555 156 504 minecraft:gold_block
setblock 558 156 466 minecraft:gold_block
setblock 558 156 473 minecraft:gold_block
setblock 558 156 480 minecraft:gold_block
setblock 558 156 487 minecraft:gold_block
setblock 558 156 494 minecraft:gold_block
setblock 558 156 501 minecraft:gold_block
setblock 518 157 465 minecraft:gold_block
setblock 518 157 472 minecraft:gold_block
setblock 518 157 479 minecraft:gold_block
setblock 518 157 486 minecraft:gold_block
setblock 518 157 493 minecraft:gold_block
setblock 518 157 500 minecraft:gold_block
setblock 521 157 504 minecraft:gold_block
setblock 524 157 464 minecraft:gold_block
setblock 528 157 504 minecraft:gold_block
setblock 531 157 464 minecraft:gold_block
setblock 535 157 504 minecraft:gold_block
setblock 538 157 464 minecraft:gold_block
setblock 542 157 504 minecraft:gold_block
setblock 545 157 464 minecraft:gold_block
setblock 549 157 504 minecraft:gold_block
setblock 552 157 464 minecraft:gold_block
fill 554 157 493 554 160 493 minecraft:white_wool
setblock 556 157 504 minecraft:gold_block
setblock 558 157 465 minecraft:gold_block
setblock 558 157 472 minecraft:gold_block
setblock 558 157 479 minecraft:gold_block
setblock 558 157 486 minecraft:gold_block
setblock 558 157 493 minecraft:gold_block
setblock 558 157 500 minecraft:gold_block
setblock 518 158 466 minecraft:gold_block
setblock 518 158 473 minecraft:gold_block
setblock 518 158 480 minecraft:gold_block
setblock 518 158 487 minecraft:gold_block
setblock 518 158 494 minecraft:gold_block
setblock 518 158 501 minecraft:gold_block
setblock 520 158 466 minecraft:light[level=12]
setblock 520 158 474 minecraft:light[level=12]
setblock 520 158 482 minecraft:light[level=12]
setblock 520 158 490 minecraft:light[level=12]
setblock 520 158 498 minecraft:light[level=12]
setblock 522 158 504 minecraft:gold_block
setblock 523 158 464 minecraft:gold_block
setblock 528 158 466 minecraft:light[level=12]
setblock 528 158 474 minecraft:light[level=12]
setblock 528 158 482 minecraft:light[level=12]
setblock 528 158 490 minecraft:light[level=12]
setblock 528 158 498 minecraft:light[level=12]
setblock 529 158 504 minecraft:gold_block
setblock 530 158 464 minecraft:gold_block
setblock 536 158 466 minecraft:light[level=12]
setblock 536 158 474 minecraft:light[level=12]
setblock 536 158 482 minecraft:light[level=12]
setblock 536 158 490 minecraft:light[level=12]
setblock 536 158 498 minecraft:light[level=12]
setblock 536 158 504 minecraft:gold_block
setblock 537 158 464 minecraft:gold_block
setblock 543 158 504 minecraft:gold_block
setblock 544 158 464 minecraft:gold_block
setblock 544 158 466 minecraft:light[level=12]
setblock 544 158 474 minecraft:light[level=12]
setblock 544 158 482 minecraft:light[level=12]
setblock 544 158 490 minecraft:light[level=12]
setblock 544 158 498 minecraft:light[level=12]
setblock 550 158 504 minecraft:gold_block
setblock 551 158 464 minecraft:gold_block
setblock 552 158 466 minecraft:light[level=12]
setblock 552 158 474 minecraft:light[level=12]
setblock 552 158 482 minecraft:light[level=12]
setblock 552 158 490 minecraft:light[level=12]
setblock 552 158 498 minecraft:light[level=12]
setblock 557 158 504 minecraft:gold_block
setblock 558 158 464 minecraft:gold_block
setblock 558 158 471 minecraft:gold_block
setblock 558 158 478 minecraft:gold_block
setblock 558 158 485 minecraft:gold_block
setblock 558 158 492 minecraft:gold_block
setblock 558 158 499 minecraft:gold_block
fill 518 159 467 518 160 467 minecraft:gold_block
fill 518 159 474 518 160 474 minecraft:gold_block
fill 518 159 481 518 160 481 minecraft:gold_block
fill 518 159 488 518 160 488 minecraft:gold_block
fill 518 159 495 518 160 495 minecraft:gold_block
fill 518 159 502 518 160 502 minecraft:gold_block
fill 522 159 464 522 160 464 minecraft:gold_block
fill 523 159 504 523 160 504 minecraft:gold_block
fill 529 159 464 529 160 464 minecraft:gold_block
fill 530 159 504 530 160 504 minecraft:gold_block
fill 536 159 464 536 160 464 minecraft:gold_block
fill 537 159 504 537 160 504 minecraft:gold_block
fill 543 159 464 543 160 464 minecraft:gold_block
fill 544 159 504 544 160 504 minecraft:gold_block
fill 550 159 464 550 160 464 minecraft:gold_block
fill 551 159 504 551 160 504 minecraft:gold_block
fill 557 159 464 557 160 464 minecraft:gold_block
fill 558 159 470 558 160 470 minecraft:gold_block
fill 558 159 477 558 160 477 minecraft:gold_block
fill 558 159 484 558 160 484 minecraft:gold_block
fill 558 159 491 558 160 491 minecraft:gold_block
fill 558 159 498 558 160 498 minecraft:gold_block
fill 558 159 504 558 160 504 minecraft:gold_block
fill 518 160 464 518 160 466 minecraft:gold_block
setblock 518 160 468 minecraft:gold_block
fill 518 160 470 518 160 473 minecraft:gold_block
setblock 518 160 475 minecraft:gold_block
fill 518 160 477 518 160 480 minecraft:gold_block
setblock 518 160 482 minecraft:gold_block
fill 518 160 484 518 160 487 minecraft:gold_block
setblock 518 160 489 minecraft:gold_block
fill 518 160 491 518 160 494 minecraft:gold_block
setblock 518 160 496 minecraft:gold_block
fill 518 160 498 518 160 501 minecraft:gold_block
setblock 518 160 503 minecraft:gold_block
setblock 519 160 464 minecraft:gold_block
fill 519 160 504 522 160 504 minecraft:gold_block
setblock 521 160 464 minecraft:gold_block
fill 523 160 464 526 160 464 minecraft:gold_block
setblock 524 160 504 minecraft:gold_block
fill 526 160 504 529 160 504 minecraft:gold_block
setblock 528 160 464 minecraft:gold_block
fill 530 160 464 533 160 464 minecraft:gold_block
setblock 531 160 504 minecraft:gold_block
fill 533 160 504 536 160 504 minecraft:gold_block
setblock 535 160 464 minecraft:gold_block
fill 537 160 464 540 160 464 minecraft:gold_block
setblock 538 160 504 minecraft:gold_block
fill 540 160 504 543 160 504 minecraft:gold_block
setblock 542 160 464 minecraft:gold_block
fill 544 160 464 547 160 464 minecraft:gold_block
setblock 545 160 504 minecraft:gold_block
fill 547 160 504 550 160 504 minecraft:gold_block
setblock 549 160 464 minecraft:gold_block
fill 551 160 464 554 160 464 minecraft:gold_block
setblock 552 160 504 minecraft:gold_block
fill 554 160 504 557 160 504 minecraft:gold_block
setblock 556 160 464 minecraft:gold_block
fill 558 160 464 558 160 467 minecraft:gold_block
setblock 558 160 469 minecraft:gold_block
fill 558 160 471 558 160 474 minecraft:gold_block
setblock 558 160 476 minecraft:gold_block
fill 558 160 478 558 160 481 minecraft:gold_block
setblock 558 160 483 minecraft:gold_block
fill 558 160 485 558 160 488 minecraft:gold_block
setblock 558 160 490 minecraft:gold_block
fill 558 160 492 558 160 495 minecraft:gold_block
setblock 558 160 497 minecraft:gold_block
fill 558 160 499 558 160 502 minecraft:gold_block
fill 554 161 488 555 161 498 minecraft:dark_oak_planks
fill 556 161 488 557 161 493 minecraft:dark_oak_planks
fill 556 161 495 557 161 498 minecraft:dark_oak_planks
setblock 557 161 494 minecraft:dark_oak_planks
setblock 518 162 470 minecraft:gold_block
setblock 518 162 477 minecraft:gold_block
setblock 518 162 484 minecraft:gold_block
setblock 518 162 491 minecraft:gold_block
setblock 518 162 498 minecraft:gold_block
setblock 519 162 464 minecraft:gold_block
setblock 519 162 504 minecraft:gold_block
setblock 526 162 464 minecraft:gold_block
setblock 526 162 504 minecraft:gold_block
setblock 533 162 464 minecraft:gold_block
setblock 533 162 504 minecraft:gold_block
setblock 540 162 464 minecraft:gold_block
setblock 540 162 504 minecraft:gold_block
setblock 547 162 464 minecraft:gold_block
setblock 547 162 504 minecraft:gold_block
setblock 554 162 464 minecraft:gold_block
fill 554 162 488 555 162 498 minecraft:gold_block
setblock 554 162 504 minecraft:gold_block
fill 556 162 488 557 162 493 minecraft:gold_block
fill 556 162 495 557 162 498 minecraft:gold_block
setblock 557 162 494 minecraft:gold_block
setblock 558 162 467 minecraft:gold_block
setblock 558 162 474 minecraft:gold_block
setblock 558 162 481 minecraft:gold_block
setblock 558 162 488 minecraft:gold_block
setblock 558 162 495 minecraft:gold_block
setblock 558 162 502 minecraft:gold_block
setblock 518 163 464 minecraft:gold_block
setblock 518 163 471 minecraft:gold_block
setblock 518 163 478 minecraft:gold_block
setblock 518 163 485 minecraft:gold_block
setblock 518 163 492 minecraft:gold_block
setblock 518 163 499 minecraft:gold_block
setblock 520 163 504 minecraft:gold_block
setblock 525 163 464 minecraft:gold_block
setblock 527 163 504 minecraft:gold_block
setblock 532 163 464 minecraft:gold_block
setblock 534 163 504 minecraft:gold_block
setblock 539 163 464 minecraft:gold_block
setblock 541 163 504 minecraft:gold_block
setblock 546 163 464 minecraft:gold_block
setblock 548 163 504 minecraft:gold_block
setblock 553 163 464 minecraft:gold_block
fill 554 163 488 554 163 498 minecraft:red_wool
setblock 555 163 504 minecraft:gold_block
setblock 558 163 466 minecraft:gold_block
setblock 558 163 473 minecraft:gold_block
setblock 558 163 480 minecraft:gold_block
setblock 558 163 487 minecraft:gold_block
fill 558 163 492 558 166 494 minecraft:ochre_froglight
setblock 558 163 501 minecraft:gold_block
setblock 518 164 465 minecraft:gold_block
setblock 518 164 472 minecraft:gold_block
setblock 518 164 479 minecraft:gold_block
setblock 518 164 486 minecraft:gold_block
setblock 518 164 493 minecraft:gold_block
setblock 518 164 500 minecraft:gold_block
setblock 521 164 504 minecraft:gold_block
setblock 524 164 464 minecraft:gold_block
setblock 528 164 504 minecraft:gold_block
setblock 531 164 464 minecraft:gold_block
setblock 535 164 504 minecraft:gold_block
setblock 538 164 464 minecraft:gold_block
setblock 542 164 504 minecraft:gold_block
setblock 545 164 464 minecraft:gold_block
setblock 549 164 504 minecraft:gold_block
setblock 552 164 464 minecraft:gold_block
setblock 554 164 488 minecraft:gold_block
setblock 554 164 493 minecraft:gold_block
setblock 554 164 498 minecraft:gold_block
setblock 556 164 504 minecraft:gold_block
setblock 558 164 465 minecraft:gold_block
setblock 558 164 472 minecraft:gold_block
setblock 558 164 479 minecraft:gold_block
setblock 558 164 486 minecraft:gold_block
setblock 558 164 500 minecraft:gold_block
setblock 518 165 466 minecraft:gold_block
setblock 518 165 473 minecraft:gold_block
setblock 518 165 480 minecraft:gold_block
setblock 518 165 487 minecraft:gold_block
setblock 518 165 494 minecraft:gold_block
setblock 518 165 501 minecraft:gold_block
setblock 522 165 504 minecraft:gold_block
setblock 523 165 464 minecraft:gold_block
setblock 529 165 504 minecraft:gold_block
setblock 530 165 464 minecraft:gold_block
setblock 536 165 504 minecraft:gold_block
setblock 537 165 464 minecraft:gold_block
setblock 543 165 504 minecraft:gold_block
setblock 544 165 464 minecraft:gold_block
setblock 550 165 504 minecraft:gold_block
setblock 551 165 464 minecraft:gold_block
setblock 557 165 504 minecraft:gold_block
setblock 558 165 464 minecraft:gold_block
setblock 558 165 471 minecraft:gold_block
setblock 558 165 478 minecraft:gold_block
setblock 558 165 485 minecraft:gold_block
setblock 558 165 499 minecraft:gold_block
setblock 518 166 467 minecraft:gold_block
setblock 518 166 474 minecraft:gold_block
setblock 518 166 481 minecraft:gold_block
setblock 518 166 488 minecraft:gold_block
setblock 518 166 495 minecraft:gold_block
setblock 518 166 502 minecraft:gold_block
setblock 520 166 466 minecraft:light[level=12]
setblock 520 166 474 minecraft:light[level=12]
setblock 520 166 482 minecraft:light[level=12]
setblock 520 166 490 minecraft:light[level=12]
setblock 520 166 498 minecraft:light[level=12]
setblock 522 166 464 minecraft:gold_block
setblock 523 166 504 minecraft:gold_block
setblock 528 166 466 minecraft:light[level=12]
setblock 528 166 474 minecraft:light[level=12]
setblock 528 166 482 minecraft:light[level=12]
setblock 528 166 490 minecraft:light[level=12]
setblock 528 166 498 minecraft:light[level=12]
setblock 529 166 464 minecraft:gold_block
setblock 530 166 504 minecraft:gold_block
setblock 536 166 464 minecraft:gold_block
setblock 536 166 466 minecraft:light[level=12]
setblock 536 166 474 minecraft:light[level=12]
setblock 536 166 482 minecraft:light[level=12]
setblock 536 166 490 minecraft:light[level=12]
setblock 536 166 498 minecraft:light[level=12]
setblock 537 166 504 minecraft:gold_block
fill 542 166 468 542 180 468 minecraft:white_wool
setblock 543 166 464 minecraft:gold_block
setblock 544 166 466 minecraft:light[level=12]
setblock 544 166 474 minecraft:light[level=12]
setblock 544 166 482 minecraft:light[level=12]
setblock 544 166 490 minecraft:light[level=12]
setblock 544 166 498 minecraft:light[level=12]
setblock 544 166 504 minecraft:gold_block
setblock 550 166 464 minecraft:gold_block
setblock 551 166 504 minecraft:gold_block
setblock 552 166 466 minecraft:light[level=12]
setblock 552 166 474 minecraft:light[level=12]
setblock 552 166 482 minecraft:light[level=12]
setblock 552 166 490 minecraft:light[level=12]
setblock 552 166 498 minecraft:light[level=12]
setblock 557 166 464 minecraft:gold_block
setblock 558 166 470 minecraft:gold_block
setblock 558 166 477 minecraft:gold_block
setblock 558 166 484 minecraft:gold_block
setblock 558 166 491 minecraft:gold_block
setblock 558 166 498 minecraft:gold_block
setblock 558 166 504 minecraft:gold_block
setblock 518 167 468 minecraft:gold_block
setblock 518 167 475 minecraft:gold_block
setblock 518 167 482 minecraft:gold_block
setblock 518 167 489 minecraft:gold_block
setblock 518 167 496 minecraft:gold_block
setblock 518 167 503 minecraft:gold_block
setblock 521 167 464 minecraft:gold_block
setblock 524 167 504 minecraft:gold_block
setblock 528 167 464 minecraft:gold_block
setblock 531 167 504 minecraft:gold_block
setblock 535 167 464 minecraft:gold_block
setblock 538 167 504 minecraft:gold_block
setblock 542 167 464 minecraft:gold_block
setblock 545 167 504 minecraft:gold_block
setblock 549 167 464 minecraft:gold_block
setblock 552 167 504 minecraft:gold_block
setblock 556 167 464 minecraft:gold_block
setblock 558 167 469 minecraft:gold_block
setblock 558 167 476 minecraft:gold_block
setblock 558 167 483 minecraft:gold_block
setblock 558 167 490 minecraft:gold_block
setblock 558 167 497 minecraft:gold_block
fill 519 168 482 519 177 482 minecraft:red_wool
fill 520 168 468 520 182 468 minecraft:white_wool
fill 518 169 470 518 170 470 minecraft:gold_block
fill 518 169 477 518 170 477 minecraft:gold_block
fill 518 169 484 518 170 484 minecraft:gold_block
fill 518 169 491 518 170 491 minecraft:gold_block
fill 518 169 498 518 170 498 minecraft:gold_block
fill 519 169 464 519 170 464 minecraft:gold_block
fill 519 169 480 519 177 481 minecraft:red_wool
fill 519 169 483 519 177 484 minecraft:red_wool
fill 519 169 504 519 170 504 minecraft:gold_block
fill 526 169 464 526 170 464 minecraft:gold_block
fill 526 169 504 526 170 504 minecraft:gold_block
fill 533 169 464 533 170 464 minecraft:gold_block
fill 533 169 504 533 170 504 minecraft:gold_block
fill 540 169 464 540 170 464 minecraft:gold_block
fill 540 169 465 540 170 466 minecraft:white_wool
fill 540 169 504 540 170 504 minecraft:gold_block
fill 547 169 464 547 170 464 minecraft:gold_block
fill 547 169 504 547 170 504 minecraft:gold_block
fill 554 169 464 554 170 464 minecraft:gold_block
fill 554 169 504 554 170 504 minecraft:gold_block
fill 558 169 467 558 170 467 minecraft:gold_block
fill 558 169 474 558 170 474 minecraft:gold_block
fill 558 169 481 558 170 481 minecraft:gold_block
fill 558 169 488 558 170 488 minecraft:gold_block
fill 558 169 495 558 170 495 minecraft:gold_block
fill 558 169 502 558 170 502 minecraft:gold_block
fill 518 170 464 518 170 468 minecraft:gold_block
fill 518 170 471 518 170 475 minecraft:gold_block
fill 518 170 478 518 170 482 minecraft:gold_block
fill 518 170 485 518 170 489 minecraft:gold_block
fill 518 170 492 518 170 496 minecraft:gold_block
fill 518 170 499 518 170 503 minecraft:gold_block
fill 520 170 504 524 170 504 minecraft:gold_block
fill 521 170 464 525 170 464 minecraft:gold_block
fill 527 170 504 531 170 504 minecraft:gold_block
fill 528 170 464 532 170 464 minecraft:gold_block
fill 534 170 504 538 170 504 minecraft:gold_block
fill 535 170 464 539 170 464 minecraft:gold_block
fill 541 170 504 545 170 504 minecraft:gold_block
fill 542 170 464 546 170 464 minecraft:gold_block
fill 548 170 504 552 170 504 minecraft:gold_block
fill 549 170 464 553 170 464 minecraft:gold_block
fill 555 170 504 558 170 504 minecraft:gold_block
fill 556 170 464 558 170 464 minecraft:gold_block
fill 558 170 465 558 170 466 minecraft:gold_block
fill 558 170 469 558 170 473 minecraft:gold_block
fill 558 170 476 558 170 480 minecraft:gold_block
fill 558 170 483 558 170 487 minecraft:gold_block
fill 558 170 490 558 170 494 minecraft:gold_block
fill 558 170 497 558 170 501 minecraft:gold_block
setblock 518 171 465 minecraft:gold_block
setblock 518 171 472 minecraft:gold_block
setblock 518 171 479 minecraft:gold_block
setblock 518 171 486 minecraft:gold_block
setblock 518 171 493 minecraft:gold_block
setblock 518 171 500 minecraft:gold_block
setblock 521 171 504 minecraft:gold_block
setblock 524 171 464 minecraft:gold_block
setblock 528 171 504 minecraft:gold_block
setblock 531 171 464 minecraft:gold_block
setblock 535 171 504 minecraft:gold_block
setblock 538 171 464 minecraft:gold_block
setblock 542 171 504 minecraft:gold_block
setblock 545 171 464 minecraft:gold_block
setblock 549 171 504 minecraft:gold_block
setblock 552 171 464 minecraft:gold_block
setblock 556 171 504 minecraft:gold_block
setblock 558 171 465 minecraft:gold_block
setblock 558 171 472 minecraft:gold_block
setblock 558 171 479 minecraft:gold_block
setblock 558 171 486 minecraft:gold_block
setblock 558 171 493 minecraft:gold_block
setblock 558 171 500 minecraft:gold_block
setblock 518 172 466 minecraft:gold_block
setblock 518 172 473 minecraft:gold_block
setblock 518 172 480 minecraft:gold_block
setblock 518 172 487 minecraft:gold_block
setblock 518 172 494 minecraft:gold_block
setblock 518 172 501 minecraft:gold_block
setblock 522 172 504 minecraft:gold_block
setblock 523 172 464 minecraft:gold_block
setblock 529 172 504 minecraft:gold_block
setblock 530 172 464 minecraft:gold_block
setblock 536 172 504 minecraft:gold_block
setblock 537 172 464 minecraft:gold_block
setblock 543 172 504 minecraft:gold_block
setblock 544 172 464 minecraft:gold_block
setblock 550 172 504 minecraft:gold_block
setblock 551 172 464 minecraft:gold_block
setblock 557 172 504 minecraft:gold_block
setblock 558 172 464 minecraft:gold_block
setblock 558 172 471 minecraft:gold_block
setblock 558 172 478 minecraft:gold_block
setblock 558 172 485 minecraft:gold_block
setblock 558 172 492 minecraft:gold_block
setblock 558 172 499 minecraft:gold_block
setblock 518 173 467 minecraft:gold_block
setblock 518 173 474 minecraft:gold_block
setblock 518 173 481 minecraft:gold_block
setblock 518 173 488 minecraft:gold_block
setblock 518 173 495 minecraft:gold_block
setblock 518 173 502 minecraft:gold_block
setblock 522 173 464 minecraft:gold_block
setblock 523 173 504 minecraft:gold_block
setblock 529 173 464 minecraft:gold_block
setblock 530 173 504 minecraft:gold_block
setblock 536 173 464 minecraft:gold_block
setblock 537 173 504 minecraft:gold_block
setblock 543 173 464 minecraft:gold_block
setblock 544 173 504 minecraft:gold_block
setblock 550 173 464 minecraft:gold_block
setblock 551 173 504 minecraft:gold_block
setblock 557 173 464 minecraft:gold_block
setblock 558 173 470 minecraft:gold_block
setblock 558 173 477 minecraft:gold_block
setblock 558 173 484 minecraft:gold_block
setblock 558 173 491 minecraft:gold_block
setblock 558 173 498 minecraft:gold_block
setblock 558 173 504 minecraft:gold_block
setblock 518 174 468 minecraft:gold_block
setblock 518 174 475 minecraft:gold_block
setblock 518 174 482 minecraft:gold_block
setblock 518 174 489 minecraft:gold_block
setblock 518 174 496 minecraft:gold_block
setblock 518 174 503 minecraft:gold_block
setblock 520 174 466 minecraft:light[level=12]
setblock 520 174 474 minecraft:light[level=12]
setblock 520 174 482 minecraft:light[level=12]
setblock 520 174 490 minecraft:light[level=12]
setblock 520 174 498 minecraft:light[level=12]
setblock 521 174 464 minecraft:gold_block
setblock 524 174 504 minecraft:gold_block
setblock 528 174 464 minecraft:gold_block
setblock 528 174 466 minecraft:light[level=12]
setblock 528 174 474 minecraft:light[level=12]
setblock 528 174 482 minecraft:light[level=12]
setblock 528 174 490 minecraft:light[level=12]
setblock 528 174 498 minecraft:light[level=12]
setblock 531 174 504 minecraft:gold_block
setblock 535 174 464 minecraft:gold_block
setblock 536 174 466 minecraft:light[level=12]
setblock 536 174 474 minecraft:light[level=12]
setblock 536 174 482 minecraft:light[level=12]
setblock 536 174 490 minecraft:light[level=12]
setblock 536 174 498 minecraft:light[level=12]
setblock 538 174 504 minecraft:gold_block
setblock 542 174 464 minecraft:gold_block
setblock 544 174 466 minecraft:light[level=12]
setblock 544 174 474 minecraft:light[level=12]
setblock 544 174 482 minecraft:light[level=12]
setblock 544 174 490 minecraft:light[level=12]
setblock 544 174 498 minecraft:light[level=12]
setblock 545 174 504 minecraft:gold_block
setblock 549 174 464 minecraft:gold_block
setblock 552 174 466 minecraft:light[level=12]
setblock 552 174 474 minecraft:light[level=12]
setblock 552 174 482 minecraft:light[level=12]
setblock 552 174 490 minecraft:light[level=12]
setblock 552 174 498 minecraft:light[level=12]
setblock 552 174 504 minecraft:gold_block
setblock 556 174 464 minecraft:gold_block
setblock 558 174 469 minecraft:gold_block
setblock 558 174 476 minecraft:gold_block
setblock 558 174 483 minecraft:gold_block
setblock 558 174 490 minecraft:gold_block
setblock 558 174 497 minecraft:gold_block
setblock 518 176 470 minecraft:gold_block
setblock 518 176 477 minecraft:gold_block
setblock 518 176 484 minecraft:gold_block
setblock 518 176 491 minecraft:gold_block
setblock 518 176 498 minecraft:gold_block
setblock 519 176 464 minecraft:gold_block
setblock 519 176 504 minecraft:gold_block
setblock 526 176 464 minecraft:gold_block
setblock 526 176 504 minecraft:gold_block
setblock 533 176 464 minecraft:gold_block
setblock 533 176 504 minecraft:gold_block
setblock 540 176 464 minecraft:gold_block
setblock 540 176 504 minecraft:gold_block
setblock 547 176 464 minecraft:gold_block
setblock 547 176 504 minecraft:gold_block
setblock 554 176 464 minecraft:gold_block
setblock 554 176 504 minecraft:gold_block
fill 556 176 472 556 188 472 minecraft:white_wool
setblock 558 176 467 minecraft:gold_block
setblock 558 176 474 minecraft:gold_block
setblock 558 176 481 minecraft:gold_block
setblock 558 176 488 minecraft:gold_block
setblock 558 176 495 minecraft:gold_block
setblock 558 176 502 minecraft:gold_block
setblock 518 177 464 minecraft:gold_block
setblock 518 177 471 minecraft:gold_block
setblock 518 177 478 minecraft:gold_block
setblock 518 177 485 minecraft:gold_block
setblock 518 177 492 minecraft:gold_block
setblock 518 177 499 minecraft:gold_block
setblock 520 177 504 minecraft:gold_block
setblock 525 177 464 minecraft:gold_block
setblock 527 177 504 minecraft:gold_block
setblock 532 177 464 minecraft:gold_block
setblock 534 177 504 minecraft:gold_block
setblock 539 177 464 minecraft:gold_block
setblock 541 177 504 minecraft:gold_block
setblock 546 177 464 minecraft:gold_block
setblock 548 177 504 minecraft:gold_block
setblock 553 177 464 minecraft:gold_block
setblock 555 177 504 minecraft:gold_block
setblock 558 177 466 minecraft:gold_block
setblock 558 177 473 minecraft:gold_block
setblock 558 177 480 minecraft:gold_block
setblock 558 177 487 minecraft:gold_block
setblock 558 177 494 minecraft:gold_block
setblock 558 177 501 minecraft:gold_block
setblock 518 178 465 minecraft:gold_block
setblock 518 178 472 minecraft:gold_block
setblock 518 178 479 minecraft:gold_block
setblock 518 178 486 minecraft:gold_block
setblock 518 178 493 minecraft:gold_block
setblock 518 178 500 minecraft:gold_block
fill 519 178 479 519 179 485 minecraft:white_wool
setblock 521 178 504 minecraft:gold_block
setblock 524 178 464 minecraft:gold_block
setblock 528 178 504 minecraft:gold_block
setblock 531 178 464 minecraft:gold_block
setblock 535 178 504 minecraft:gold_block
setblock 538 178 464 minecraft:gold_block
setblock 542 178 504 minecraft:gold_block
setblock 545 178 464 minecraft:gold_block
setblock 549 178 504 minecraft:gold_block
setblock 552 178 464 minecraft:gold_block
setblock 556 178 504 minecraft:gold_block
setblock 558 178 465 minecraft:gold_block
setblock 558 178 472 minecraft:gold_block
setblock 558 178 479 minecraft:gold_block
setblock 558 178 486 minecraft:gold_block
setblock 558 178 493 minecraft:gold_block
setblock 558 178 500 minecraft:gold_block
fill 518 179 466 518 180 466 minecraft:gold_block
fill 518 179 473 518 180 473 minecraft:gold_block
fill 518 179 480 518 180 480 minecraft:gold_block
fill 518 179 487 518 180 487 minecraft:gold_block
fill 518 179 494 518 180 494 minecraft:gold_block
fill 518 179 501 518 180 501 minecraft:gold_block
fill 522 179 504 522 180 504 minecraft:gold_block
fill 523 179 464 523 180 464 minecraft:gold_block
fill 529 179 504 529 180 504 minecraft:gold_block
fill 530 179 464 530 180 464 minecraft:gold_block
fill 536 179 504 536 180 504 minecraft:gold_block
fill 537 179 464 537 180 464 minecraft:gold_block
fill 543 179 504 543 180 504 minecraft:gold_block
fill 544 179 464 544 180 464 minecraft:gold_block
fill 550 179 504 550 180 504 minecraft:gold_block
fill 551 179 464 551 180 464 minecraft:gold_block
fill 557 179 504 557 180 504 minecraft:gold_block
fill 558 179 464 558 180 464 minecraft:gold_block
fill 558 179 471 558 180 471 minecraft:gold_block
fill 558 179 478 558 180 478 minecraft:gold_block
fill 558 179 485 558 180 485 minecraft:gold_block
fill 558 179 492 558 180 492 minecraft:gold_block
fill 558 179 499 558 180 499 minecraft:gold_block
fill 518 180 464 518 180 465 minecraft:gold_block
fill 518 180 467 518 180 468 minecraft:gold_block
fill 518 180 470 518 180 472 minecraft:gold_block
fill 518 180 474 518 180 475 minecraft:gold_block
fill 518 180 477 518 180 479 minecraft:gold_block
fill 518 180 481 518 180 482 minecraft:gold_block
fill 518 180 484 518 180 486 minecraft:gold_block
fill 518 180 488 518 180 489 minecraft:gold_block
fill 518 180 491 518 180 493 minecraft:gold_block
fill 518 180 495 518 180 496 minecraft:gold_block
fill 518 180 498 518 180 500 minecraft:gold_block
fill 518 180 502 518 180 503 minecraft:gold_block
setblock 519 180 464 minecraft:gold_block
fill 519 180 504 521 180 504 minecraft:gold_block
fill 521 180 464 522 180 464 minecraft:gold_block
fill 523 180 504 524 180 504 minecraft:gold_block
fill 524 180 464 526 180 464 minecraft:gold_block
fill 526 180 504 528 180 504 minecraft:gold_block
fill 528 180 464 529 180 464 minecraft:gold_block
fill 530 180 504 531 180 504 minecraft:gold_block
fill 531 180 464 533 180 464 minecraft:gold_block
fill 533 180 504 535 180 504 minecraft:gold_block
fill 535 180 464 536 180 464 minecraft:gold_block
fill 537 180 504 538 180 504 minecraft:gold_block
fill 538 180 464 540 180 464 minecraft:gold_block
fill 540 180 504 542 180 504 minecraft:gold_block
fill 542 180 464 543 180 464 minecraft:gold_block
fill 544 180 504 545 180 504 minecraft:gold_block
fill 545 180 464 547 180 464 minecraft:gold_block
fill 547 180 504 549 180 504 minecraft:gold_block
fill 549 180 464 550 180 464 minecraft:gold_block
fill 551 180 504 552 180 504 minecraft:gold_block
fill 552 180 464 554 180 464 minecraft:gold_block
fill 554 180 504 556 180 504 minecraft:gold_block
fill 556 180 464 557 180 464 minecraft:gold_block
fill 558 180 465 558 180 467 minecraft:gold_block
fill 558 180 469 558 180 470 minecraft:gold_block
fill 558 180 472 558 180 474 minecraft:gold_block
fill 558 180 476 558 180 477 minecraft:gold_block
fill 558 180 479 558 180 481 minecraft:gold_block
fill 558 180 483 558 180 484 minecraft:gold_block
fill 558 180 486 558 180 488 minecraft:gold_block
fill 558 180 490 558 180 491 minecraft:gold_block
fill 558 180 493 558 180 495 minecraft:gold_block
fill 558 180 497 558 180 498 minecraft:gold_block
fill 558 180 500 558 180 502 minecraft:gold_block
setblock 558 180 504 minecraft:gold_block
setblock 518 181 468 minecraft:gold_block
setblock 518 181 475 minecraft:gold_block
setblock 518 181 482 minecraft:gold_block
setblock 518 181 489 minecraft:gold_block
setblock 518 181 496 minecraft:gold_block
setblock 518 181 503 minecraft:gold_block
setblock 521 181 464 minecraft:gold_block
setblock 524 181 504 minecraft:gold_block
setblock 528 181 464 minecraft:gold_block
setblock 531 181 504 minecraft:gold_block
setblock 535 181 464 minecraft:gold_block
setblock 538 181 504 minecraft:gold_block
setblock 542 181 464 minecraft:gold_block
setblock 545 181 504 minecraft:gold_block
setblock 549 181 464 minecraft:gold_block
setblock 552 181 504 minecraft:gold_block
setblock 556 181 464 minecraft:gold_block
setblock 558 181 469 minecraft:gold_block
setblock 558 181 476 minecraft:gold_block
setblock 558 181 483 minecraft:gold_block
setblock 558 181 490 minecraft:gold_block
setblock 558 181 497 minecraft:gold_block
setblock 520 182 466 minecraft:light[level=12]
setblock 520 182 474 minecraft:light[level=12]
setblock 520 182 482 minecraft:light[level=12]
setblock 520 182 490 minecraft:light[level=12]
setblock 520 182 498 minecraft:light[level=12]
setblock 528 182 466 minecraft:light[level=12]
setblock 528 182 474 minecraft:light[level=12]
setblock 528 182 482 minecraft:light[level=12]
setblock 528 182 490 minecraft:light[level=12]
setblock 528 182 498 minecraft:light[level=12]
setblock 536 182 466 minecraft:light[level=12]
setblock 536 182 474 minecraft:light[level=12]
setblock 536 182 482 minecraft:light[level=12]
setblock 536 182 490 minecraft:light[level=12]
setblock 536 182 498 minecraft:light[level=12]
setblock 544 182 466 minecraft:light[level=12]
setblock 544 182 474 minecraft:light[level=12]
setblock 544 182 482 minecraft:light[level=12]
setblock 544 182 490 minecraft:light[level=12]
setblock 544 182 498 minecraft:light[level=12]
setblock 552 182 466 minecraft:light[level=12]
setblock 552 182 474 minecraft:light[level=12]
setblock 552 182 482 minecraft:light[level=12]
setblock 552 182 490 minecraft:light[level=12]
setblock 552 182 498 minecraft:light[level=12]
setblock 518 183 470 minecraft:gold_block
setblock 518 183 477 minecraft:gold_block
setblock 518 183 484 minecraft:gold_block
setblock 518 183 491 minecraft:gold_block
setblock 518 183 498 minecraft:gold_block
setblock 519 183 464 minecraft:gold_block
setblock 519 183 504 minecraft:gold_block
setblock 526 183 464 minecraft:gold_block
setblock 526 183 504 minecraft:gold_block
setblock 533 183 464 minecraft:gold_block
setblock 533 183 504 minecraft:gold_block
setblock 540 183 464 minecraft:gold_block
setblock 540 183 504 minecraft:gold_block
setblock 547 183 464 minecraft:gold_block
setblock 547 183 504 minecraft:gold_block
setblock 554 183 464 minecraft:gold_block
setblock 554 183 504 minecraft:gold_block
setblock 558 183 467 minecraft:gold_block
setblock 558 183 474 minecraft:gold_block
setblock 558 183 481 minecraft:gold_block
setblock 558 183 488 minecraft:gold_block
setblock 558 183 495 minecraft:gold_block
setblock 558 183 502 minecraft:gold_block
setblock 518 184 464 minecraft:gold_block
setblock 518 184 471 minecraft:gold_block
setblock 518 184 478 minecraft:gold_block
setblock 518 184 485 minecraft:gold_block
setblock 518 184 492 minecraft:gold_block
setblock 518 184 499 minecraft:gold_block
setblock 520 184 504 minecraft:gold_block
setblock 525 184 464 minecraft:gold_block
setblock 527 184 504 minecraft:gold_block
setblock 532 184 464 minecraft:gold_block
setblock 534 184 504 minecraft:gold_block
setblock 539 184 464 minecraft:gold_block
setblock 541 184 504 minecraft:gold_block
setblock 546 184 464 minecraft:gold_block
setblock 548 184 504 minecraft:gold_block
setblock 553 184 464 minecraft:gold_block
setblock 555 184 504 minecraft:gold_block
setblock 558 184 466 minecraft:gold_block
setblock 558 184 473 minecraft:gold_block
setblock 558 184 480 minecraft:gold_block
setblock 558 184 487 minecraft:gold_block
setblock 558 184 494 minecraft:gold_block
setblock 558 184 501 minecraft:gold_block
setblock 518 185 465 minecraft:gold_block
setblock 518 185 472 minecraft:gold_block
setblock 518 185 479 minecraft:gold_block
setblock 518 185 486 minecraft:gold_block
setblock 518 185 493 minecraft:gold_block
setblock 518 185 500 minecraft:gold_block
fill 521 185 480 521 188 480 minecraft:white_wool
setblock 521 185 504 minecraft:gold_block
setblock 524 185 464 minecraft:gold_block
setblock 528 185 504 minecraft:gold_block
setblock 531 185 464 minecraft:gold_block
setblock 535 185 504 minecraft:gold_block
setblock 538 185 464 minecraft:gold_block
setblock 542 185 504 minecraft:gold_block
setblock 545 185 464 minecraft:gold_block
setblock 549 185 504 minecraft:gold_block
setblock 552 185 464 minecraft:gold_block
setblock 556 185 504 minecraft:gold_block
setblock 558 185 465 minecraft:gold_block
setblock 558 185 472 minecraft:gold_block
setblock 558 185 479 minecraft:gold_block
setblock 558 185 486 minecraft:gold_block
setblock 558 185 493 minecraft:gold_block
setblock 558 185 500 minecraft:gold_block
setblock 518 186 466 minecraft:gold_block
setblock 518 186 473 minecraft:gold_block
setblock 518 186 480 minecraft:gold_block
setblock 518 186 487 minecraft:gold_block
setblock 518 186 494 minecraft:gold_block
setblock 518 186 501 minecraft:gold_block
setblock 522 186 504 minecraft:gold_block
setblock 523 186 464 minecraft:gold_block
setblock 529 186 504 minecraft:gold_block
setblock 530 186 464 minecraft:gold_block
setblock 536 186 504 minecraft:gold_block
setblock 537 186 464 minecraft:gold_block
setblock 543 186 504 minecraft:gold_block
setblock 544 186 464 minecraft:gold_block
setblock 550 186 504 minecraft:gold_block
setblock 551 186 464 minecraft:gold_block
setblock 557 186 504 minecraft:gold_block
setblock 558 186 464 minecraft:gold_block
setblock 558 186 471 minecraft:gold_block
setblock 558 186 478 minecraft:gold_block
setblock 558 186 485 minecraft:gold_block
setblock 558 186 492 minecraft:gold_block
setblock 558 186 499 minecraft:gold_block
setblock 518 187 467 minecraft:gold_block
setblock 518 187 474 minecraft:gold_block
setblock 518 187 481 minecraft:gold_block
setblock 518 187 488 minecraft:gold_block
fill 518 187 489 520 187 489 minecraft:white_wool
setblock 518 187 495 minecraft:gold_block
setblock 518 187 502 minecraft:gold_block
setblock 522 187 464 minecraft:gold_block
setblock 523 187 504 minecraft:gold_block
setblock 529 187 464 minecraft:gold_block
setblock 530 187 504 minecraft:gold_block
setblock 536 187 464 minecraft:gold_block
setblock 537 187 504 minecraft:gold_block
setblock 543 187 464 minecraft:gold_block
setblock 544 187 504 minecraft:gold_block
setblock 550 187 464 minecraft:gold_block
setblock 551 187 504 minecraft:gold_block
setblock 557 187 464 minecraft:gold_block
setblock 558 187 470 minecraft:gold_block
setblock 558 187 477 minecraft:gold_block
setblock 558 187 484 minecraft:gold_block
setblock 558 187 491 minecraft:gold_block
setblock 558 187 498 minecraft:gold_block
setblock 558 187 504 minecraft:gold_block
setblock 518 188 468 minecraft:gold_block
setblock 518 188 475 minecraft:gold_block
setblock 518 188 482 minecraft:gold_block
setblock 518 188 489 minecraft:gold_block
setblock 518 188 496 minecraft:gold_block
setblock 518 188 503 minecraft:gold_block
fill 519 188 489 520 188 489 minecraft:white_wool
setblock 521 188 464 minecraft:gold_block
setblock 524 188 504 minecraft:gold_block
setblock 528 188 464 minecraft:gold_block
setblock 531 188 504 minecraft:gold_block
setblock 535 188 464 minecraft:gold_block
setblock 538 188 504 minecraft:gold_block
setblock 542 188 464 minecraft:gold_block
setblock 545 188 504 minecraft:gold_block
setblock 549 188 464 minecraft:gold_block
setblock 552 188 504 minecraft:gold_block
setblock 556 188 464 minecraft:gold_block
setblock 558 188 469 minecraft:gold_block
setblock 558 188 476 minecraft:gold_block
setblock 558 188 483 minecraft:gold_block
setblock 558 188 490 minecraft:gold_block
setblock 558 188 497 minecraft:gold_block
setblock 520 190 466 minecraft:light[level=12]
setblock 520 190 474 minecraft:light[level=12]
setblock 520 190 482 minecraft:light[level=12]
setblock 520 190 490 minecraft:light[level=12]
setblock 520 190 498 minecraft:light[level=12]
setblock 528 190 466 minecraft:light[level=12]
setblock 528 190 474 minecraft:light[level=12]
setblock 528 190 482 minecraft:light[level=12]
setblock 528 190 490 minecraft:light[level=12]
setblock 528 190 498 minecraft:light[level=12]
setblock 536 190 466 minecraft:light[level=12]
setblock 536 190 474 minecraft:light[level=12]
setblock 536 190 482 minecraft:light[level=12]
setblock 536 190 490 minecraft:light[level=12]
setblock 536 190 498 minecraft:light[level=12]
setblock 544 190 466 minecraft:light[level=12]
setblock 544 190 474 minecraft:light[level=12]
setblock 544 190 482 minecraft:light[level=12]
setblock 544 190 490 minecraft:light[level=12]
setblock 544 190 498 minecraft:light[level=12]
setblock 552 190 466 minecraft:light[level=12]
setblock 552 190 474 minecraft:light[level=12]
setblock 552 190 482 minecraft:light[level=12]
setblock 552 190 490 minecraft:light[level=12]
setblock 552 190 498 minecraft:light[level=12]
fill 533 193 480 535 193 482 minecraft:redstone_block
fill 536 193 488 538 193 490 minecraft:redstone_block
fill 541 193 480 543 193 482 minecraft:redstone_block
fill 541 193 486 543 193 488 minecraft:redstone_block
fill 518 194 464 519 194 465 minecraft:spruce_planks
fill 518 194 466 519 194 467 minecraft:dark_oak_planks
fill 518 194 468 519 194 469 minecraft:spruce_planks
fill 518 194 470 519 194 471 minecraft:dark_oak_planks
fill 518 194 472 519 194 473 minecraft:spruce_planks
fill 518 194 474 519 194 475 minecraft:dark_oak_planks
fill 518 194 476 519 194 477 minecraft:spruce_planks
fill 518 194 478 519 194 479 minecraft:dark_oak_planks
fill 518 194 480 519 194 481 minecraft:spruce_planks
fill 518 194 482 519 194 483 minecraft:dark_oak_planks
fill 518 194 484 519 194 485 minecraft:spruce_planks
fill 518 194 486 519 194 487 minecraft:dark_oak_planks
fill 518 194 488 519 194 489 minecraft:spruce_planks
fill 518 194 490 519 194 491 minecraft:dark_oak_planks
fill 518 194 492 519 194 493 minecraft:spruce_planks
fill 518 194 494 519 194 495 minecraft:dark_oak_planks
fill 518 194 496 519 194 497 minecraft:spruce_planks
fill 518 194 498 519 194 499 minecraft:dark_oak_planks
fill 518 194 500 519 194 501 minecraft:spruce_planks
fill 518 194 502 519 194 503 minecraft:dark_oak_planks
fill 518 194 504 519 194 504 minecraft:spruce_planks
fill 520 194 464 521 194 465 minecraft:dark_oak_planks
fill 520 194 466 521 194 467 minecraft:spruce_planks
fill 520 194 468 521 194 469 minecraft:dark_oak_planks
fill 520 194 470 521 194 471 minecraft:spruce_planks
fill 520 194 472 521 194 473 minecraft:dark_oak_planks
fill 520 194 474 521 194 475 minecraft:spruce_planks
fill 520 194 476 521 194 477 minecraft:dark_oak_planks
fill 520 194 478 521 194 479 minecraft:spruce_planks
fill 520 194 480 521 194 481 minecraft:dark_oak_planks
fill 520 194 482 521 194 483 minecraft:spruce_planks
fill 520 194 484 521 194 485 minecraft:dark_oak_planks
fill 520 194 486 521 194 487 minecraft:spruce_planks
fill 520 194 488 521 194 489 minecraft:dark_oak_planks
fill 520 194 490 521 194 491 minecraft:spruce_planks
fill 520 194 492 521 194 493 minecraft:dark_oak_planks
fill 520 194 494 521 194 495 minecraft:spruce_planks
fill 520 194 496 521 194 497 minecraft:dark_oak_planks
fill 520 194 498 521 194 499 minecraft:spruce_planks
fill 520 194 500 521 194 501 minecraft:dark_oak_planks
fill 520 194 502 521 194 503 minecraft:spruce_planks
fill 520 194 504 521 194 504 minecraft:dark_oak_planks
fill 522 194 464 523 194 465 minecraft:spruce_planks
fill 522 194 466 523 194 467 minecraft:dark_oak_planks
fill 522 194 468 523 194 469 minecraft:spruce_planks
fill 522 194 470 523 194 471 minecraft:dark_oak_planks
fill 522 194 472 523 194 473 minecraft:spruce_planks
fill 522 194 474 523 194 475 minecraft:dark_oak_planks
fill 522 194 476 523 194 477 minecraft:spruce_planks
fill 522 194 478 523 194 479 minecraft:dark_oak_planks
fill 522 194 480 523 194 481 minecraft:spruce_planks
fill 522 194 482 523 194 483 minecraft:dark_oak_planks
fill 522 194 484 523 194 485 minecraft:spruce_planks
fill 522 194 486 523 194 487 minecraft:dark_oak_planks
fill 522 194 488 523 194 489 minecraft:spruce_planks
fill 522 194 490 523 194 491 minecraft:dark_oak_planks
fill 522 194 492 523 194 493 minecraft:spruce_planks
fill 522 194 494 523 194 495 minecraft:dark_oak_planks
fill 522 194 496 523 194 497 minecraft:spruce_planks
fill 522 194 498 523 194 499 minecraft:dark_oak_planks
fill 522 194 500 523 194 501 minecraft:spruce_planks
fill 522 194 502 523 194 503 minecraft:dark_oak_planks
fill 522 194 504 523 194 504 minecraft:spruce_planks
fill 524 194 464 525 194 465 minecraft:dark_oak_planks
fill 524 194 466 525 194 467 minecraft:spruce_planks
fill 524 194 468 525 194 469 minecraft:dark_oak_planks
fill 524 194 470 525 194 471 minecraft:spruce_planks
fill 524 194 472 525 194 473 minecraft:dark_oak_planks
fill 524 194 474 525 194 475 minecraft:spruce_planks
fill 524 194 476 525 194 477 minecraft:dark_oak_planks
fill 524 194 478 525 194 479 minecraft:spruce_planks
fill 524 194 480 525 194 481 minecraft:dark_oak_planks
fill 524 194 482 525 194 483 minecraft:spruce_planks
fill 524 194 484 525 194 485 minecraft:dark_oak_planks
fill 524 194 486 525 194 487 minecraft:spruce_planks
fill 524 194 488 525 194 489 minecraft:dark_oak_planks
fill 524 194 490 525 194 491 minecraft:spruce_planks
fill 524 194 492 525 194 493 minecraft:dark_oak_planks
fill 524 194 494 525 194 495 minecraft:spruce_planks
fill 524 194 496 525 194 497 minecraft:dark_oak_planks
fill 524 194 498 525 194 499 minecraft:spruce_planks
fill 524 194 500 525 194 501 minecraft:dark_oak_planks
fill 524 194 502 525 194 503 minecraft:spruce_planks
fill 524 194 504 525 194 504 minecraft:dark_oak_planks
fill 526 194 464 527 194 465 minecraft:spruce_planks
fill 526 194 466 527 194 467 minecraft:dark_oak_planks
fill 526 194 468 527 194 469 minecraft:spruce_planks
fill 526 194 470 527 194 471 minecraft:dark_oak_planks
fill 526 194 472 527 194 473 minecraft:spruce_planks
fill 526 194 474 527 194 475 minecraft:dark_oak_planks
fill 526 194 476 527 194 477 minecraft:spruce_planks
fill 526 194 478 527 194 479 minecraft:dark_oak_planks
fill 526 194 480 527 194 481 minecraft:spruce_planks
fill 526 194 482 527 194 483 minecraft:dark_oak_planks
fill 526 194 484 527 194 485 minecraft:spruce_planks
fill 526 194 486 527 194 487 minecraft:dark_oak_planks
fill 526 194 488 527 194 489 minecraft:spruce_planks
fill 526 194 490 527 194 491 minecraft:dark_oak_planks
fill 526 194 492 527 194 493 minecraft:spruce_planks
fill 526 194 494 527 194 495 minecraft:dark_oak_planks
fill 526 194 496 527 194 497 minecraft:spruce_planks
fill 526 194 498 527 194 499 minecraft:dark_oak_planks
fill 526 194 500 527 194 501 minecraft:spruce_planks
fill 526 194 502 527 194 503 minecraft:dark_oak_planks
fill 526 194 504 527 194 504 minecraft:spruce_planks
fill 528 194 464 529 194 465 minecraft:dark_oak_planks
fill 528 194 466 529 194 467 minecraft:spruce_planks
fill 528 194 468 529 194 469 minecraft:dark_oak_planks
fill 528 194 470 529 194 471 minecraft:spruce_planks
fill 528 194 472 529 194 473 minecraft:dark_oak_planks
fill 528 194 474 529 194 475 minecraft:spruce_planks
fill 528 194 476 529 194 477 minecraft:dark_oak_planks
fill 528 194 478 529 194 479 minecraft:spruce_planks
fill 528 194 480 529 194 481 minecraft:dark_oak_planks
fill 528 194 482 529 194 483 minecraft:spruce_planks
fill 528 194 484 529 194 485 minecraft:dark_oak_planks
fill 528 194 486 529 194 487 minecraft:spruce_planks
fill 528 194 488 529 194 489 minecraft:dark_oak_planks
fill 528 194 490 529 194 491 minecraft:spruce_planks
fill 528 194 492 529 194 493 minecraft:dark_oak_planks
fill 528 194 494 529 194 495 minecraft:spruce_planks
fill 528 194 496 529 194 497 minecraft:dark_oak_planks
fill 528 194 498 529 194 499 minecraft:spruce_planks
fill 528 194 500 529 194 501 minecraft:dark_oak_planks
fill 528 194 502 529 194 503 minecraft:spruce_planks
fill 528 194 504 529 194 504 minecraft:dark_oak_planks
fill 530 194 464 531 194 465 minecraft:spruce_planks
fill 530 194 466 531 194 467 minecraft:dark_oak_planks
fill 530 194 468 531 194 469 minecraft:spruce_planks
fill 530 194 470 531 194 471 minecraft:dark_oak_planks
fill 530 194 472 531 194 473 minecraft:spruce_planks
fill 530 194 474 531 194 475 minecraft:dark_oak_planks
fill 530 194 476 531 194 477 minecraft:spruce_planks
fill 530 194 478 531 194 479 minecraft:dark_oak_planks
fill 530 194 480 531 194 481 minecraft:spruce_planks
fill 530 194 482 531 194 483 minecraft:dark_oak_planks
fill 530 194 484 531 194 485 minecraft:spruce_planks
fill 530 194 486 531 194 487 minecraft:dark_oak_planks
fill 530 194 488 531 194 489 minecraft:spruce_planks
fill 530 194 490 531 194 491 minecraft:dark_oak_planks
fill 530 194 492 531 194 493 minecraft:spruce_planks
fill 530 194 494 531 194 495 minecraft:dark_oak_planks
fill 530 194 496 531 194 497 minecraft:spruce_planks
fill 530 194 498 531 194 499 minecraft:dark_oak_planks
fill 530 194 500 531 194 501 minecraft:spruce_planks
fill 530 194 502 531 194 503 minecraft:dark_oak_planks
fill 530 194 504 531 194 504 minecraft:spruce_planks
fill 532 194 464 533 194 465 minecraft:dark_oak_planks
fill 532 194 466 533 194 467 minecraft:spruce_planks
fill 532 194 468 533 194 469 minecraft:dark_oak_planks
fill 532 194 470 533 194 471 minecraft:spruce_planks
fill 532 194 472 533 194 473 minecraft:dark_oak_planks
fill 532 194 474 533 194 475 minecraft:spruce_planks
fill 532 194 476 533 194 477 minecraft:dark_oak_planks
fill 532 194 478 533 194 479 minecraft:spruce_planks
fill 532 194 480 532 194 481 minecraft:dark_oak_planks
fill 532 194 482 532 194 483 minecraft:spruce_planks
fill 532 194 484 533 194 485 minecraft:dark_oak_planks
fill 532 194 486 533 194 487 minecraft:spruce_planks
fill 532 194 488 533 194 489 minecraft:dark_oak_planks
fill 532 194 490 533 194 491 minecraft:spruce_planks
fill 532 194 492 533 194 493 minecraft:dark_oak_planks
fill 532 194 494 533 194 495 minecraft:spruce_planks
fill 532 194 496 533 194 497 minecraft:dark_oak_planks
fill 532 194 498 533 194 499 minecraft:spruce_planks
fill 532 194 500 533 194 501 minecraft:dark_oak_planks
fill 532 194 502 533 194 503 minecraft:spruce_planks
fill 532 194 504 533 194 504 minecraft:dark_oak_planks
setblock 533 194 483 minecraft:spruce_planks
fill 534 194 464 535 194 465 minecraft:spruce_planks
fill 534 194 466 535 194 467 minecraft:dark_oak_planks
fill 534 194 468 535 194 469 minecraft:spruce_planks
fill 534 194 470 535 194 471 minecraft:dark_oak_planks
fill 534 194 472 535 194 473 minecraft:spruce_planks
fill 534 194 474 535 194 475 minecraft:dark_oak_planks
fill 534 194 476 535 194 477 minecraft:spruce_planks
fill 534 194 478 535 194 479 minecraft:dark_oak_planks
fill 534 194 483 535 194 483 minecraft:dark_oak_planks
fill 534 194 484 535 194 485 minecraft:spruce_planks
fill 534 194 486 535 194 487 minecraft:dark_oak_planks
fill 534 194 488 535 194 489 minecraft:spruce_planks
fill 534 194 490 535 194 491 minecraft:dark_oak_planks
fill 534 194 492 535 194 493 minecraft:spruce_planks
fill 534 194 494 535 194 495 minecraft:dark_oak_planks
fill 534 194 496 535 194 497 minecraft:spruce_planks
fill 534 194 498 535 194 499 minecraft:dark_oak_planks
fill 534 194 500 535 194 501 minecraft:spruce_planks
fill 534 194 502 535 194 503 minecraft:dark_oak_planks
fill 534 194 504 535 194 504 minecraft:spruce_planks
fill 536 194 464 537 194 465 minecraft:dark_oak_planks
fill 536 194 466 537 194 467 minecraft:spruce_planks
fill 536 194 468 537 194 469 minecraft:dark_oak_planks
fill 536 194 470 537 194 471 minecraft:spruce_planks
fill 536 194 472 537 194 473 minecraft:dark_oak_planks
fill 536 194 474 537 194 475 minecraft:spruce_planks
fill 536 194 476 537 194 477 minecraft:dark_oak_planks
fill 536 194 478 537 194 479 minecraft:spruce_planks
fill 536 194 480 537 194 481 minecraft:dark_oak_planks
fill 536 194 482 536 194 483 minecraft:spruce_planks
fill 536 194 484 536 194 485 minecraft:dark_oak_planks
fill 536 194 486 537 194 487 minecraft:spruce_planks
fill 536 194 491 537 194 491 minecraft:spruce_planks
fill 536 194 492 537 194 493 minecraft:dark_oak_planks
fill 536 194 494 537 194 495 minecraft:spruce_planks
fill 536 194 496 537 194 497 minecraft:dark_oak_planks
fill 536 194 498 537 194 499 minecraft:spruce_planks
fill 536 194 500 537 194 501 minecraft:dark_oak_planks
fill 536 194 502 537 194 503 minecraft:spruce_planks
fill 536 194 504 537 194 504 minecraft:dark_oak_planks
setblock 537 194 482 minecraft:spruce_planks
fill 538 194 464 539 194 465 minecraft:spruce_planks
fill 538 194 466 539 194 467 minecraft:dark_oak_planks
fill 538 194 468 539 194 469 minecraft:spruce_planks
fill 538 194 470 539 194 471 minecraft:dark_oak_planks
fill 538 194 472 539 194 473 minecraft:spruce_planks
fill 538 194 474 539 194 475 minecraft:dark_oak_planks
fill 538 194 476 539 194 477 minecraft:spruce_planks
fill 538 194 478 539 194 479 minecraft:dark_oak_planks
fill 538 194 480 539 194 481 minecraft:spruce_planks
fill 538 194 482 539 194 482 minecraft:dark_oak_planks
fill 538 194 486 539 194 487 minecraft:dark_oak_planks
fill 538 194 491 539 194 491 minecraft:dark_oak_planks
fill 538 194 492 539 194 493 minecraft:spruce_planks
fill 538 194 494 539 194 495 minecraft:dark_oak_planks
fill 538 194 496 539 194 497 minecraft:spruce_planks
fill 538 194 498 539 194 499 minecraft:dark_oak_planks
fill 538 194 500 539 194 501 minecraft:spruce_planks
fill 538 194 502 539 194 503 minecraft:dark_oak_planks
fill 538 194 504 539 194 504 minecraft:spruce_planks
fill 539 194 488 539 194 489 minecraft:spruce_planks
setblock 539 194 490 minecraft:dark_oak_planks
fill 540 194 464 541 194 465 minecraft:dark_oak_planks
fill 540 194 466 541 194 467 minecraft:spruce_planks
fill 540 194 468 541 194 469 minecraft:dark_oak_planks
fill 540 194 470 541 194 471 minecraft:spruce_planks
fill 540 194 472 541 194 473 minecraft:dark_oak_planks
fill 540 194 474 541 194 475 minecraft:spruce_planks
fill 540 194 476 541 194 477 minecraft:dark_oak_planks
fill 540 194 478 541 194 479 minecraft:spruce_planks
fill 540 194 480 540 194 481 minecraft:dark_oak_planks
fill 540 194 482 540 194 483 minecraft:spruce_planks
fill 540 194 484 541 194 485 minecraft:dark_oak_planks
fill 540 194 486 540 194 487 minecraft:spruce_planks
fill 540 194 488 540 194 489 minecraft:dark_oak_planks
fill 540 194 490 541 194 491 minecraft:spruce_planks
fill 540 194 492 541 194 493 minecraft:dark_oak_planks
fill 540 194 494 541 194 495 minecraft:spruce_planks
fill 540 194 496 541 194 497 minecraft:dark_oak_planks
fill 540 194 498 541 194 499 minecraft:spruce_planks
fill 540 194 500 541 194 501 minecraft:dark_oak_planks
fill 540 194 502 541 194 503 minecraft:spruce_planks
fill 540 194 504 541 194 504 minecraft:dark_oak_planks
setblock 541 194 483 minecraft:spruce_planks
setblock 541 194 489 minecraft:dark_oak_planks
fill 542 194 464 543 194 465 minecraft:spruce_planks
fill 542 194 466 543 194 467 minecraft:dark_oak_planks
fill 542 194 468 543 194 469 minecraft:spruce_planks
fill 542 194 470 543 194 471 minecraft:dark_oak_planks
fill 542 194 472 543 194 473 minecraft:spruce_planks
fill 542 194 474 543 194 475 minecraft:dark_oak_planks
fill 542 194 476 543 194 477 minecraft:spruce_planks
fill 542 194 478 543 194 479 minecraft:dark_oak_planks
fill 542 194 483 543 194 483 minecraft:dark_oak_planks
fill 542 194 484 543 194 485 minecraft:spruce_planks
fill 542 194 489 543 194 489 minecraft:spruce_planks
fill 542 194 490 543 194 491 minecraft:dark_oak_planks
fill 542 194 492 543 194 493 minecraft:spruce_planks
fill 542 194 494 543 194 495 minecraft:dark_oak_planks
fill 542 194 496 543 194 497 minecraft:spruce_planks
fill 542 194 498 543 194 499 minecraft:dark_oak_planks
fill 542 194 500 543 194 501 minecraft:spruce_planks
fill 542 194 502 543 194 503 minecraft:dark_oak_planks
fill 542 194 504 543 194 504 minecraft:spruce_planks
fill 544 194 464 545 194 465 minecraft:dark_oak_planks
fill 544 194 466 545 194 467 minecraft:spruce_planks
fill 544 194 468 545 194 469 minecraft:dark_oak_planks
fill 544 194 470 545 194 471 minecraft:spruce_planks
fill 544 194 472 545 194 473 minecraft:dark_oak_planks
fill 544 194 474 545 194 475 minecraft:spruce_planks
fill 544 194 476 545 194 477 minecraft:dark_oak_planks
fill 544 194 478 545 194 479 minecraft:spruce_planks
fill 544 194 480 545 194 481 minecraft:dark_oak_planks
fill 544 194 482 545 194 483 minecraft:spruce_planks
fill 544 194 484 545 194 485 minecraft:dark_oak_planks
fill 544 194 486 545 194 487 minecraft:spruce_planks
fill 544 194 488 545 194 489 minecraft:dark_oak_planks
fill 544 194 490 545 194 491 minecraft:spruce_planks
fill 544 194 492 545 194 493 minecraft:dark_oak_planks
fill 544 194 494 545 194 495 minecraft:spruce_planks
fill 544 194 496 545 194 497 minecraft:dark_oak_planks
fill 544 194 498 545 194 499 minecraft:spruce_planks
fill 544 194 500 545 194 501 minecraft:dark_oak_planks
fill 544 194 502 545 194 503 minecraft:spruce_planks
fill 544 194 504 545 194 504 minecraft:dark_oak_planks
fill 546 194 464 547 194 465 minecraft:spruce_planks
fill 546 194 466 547 194 467 minecraft:dark_oak_planks
fill 546 194 468 547 194 469 minecraft:spruce_planks
fill 546 194 470 547 194 471 minecraft:dark_oak_planks
fill 546 194 472 547 194 473 minecraft:spruce_planks
fill 546 194 474 547 194 475 minecraft:dark_oak_planks
fill 546 194 476 547 194 477 minecraft:spruce_planks
fill 546 194 478 547 194 479 minecraft:dark_oak_planks
fill 546 194 480 547 194 481 minecraft:spruce_planks
fill 546 194 482 547 194 483 minecraft:dark_oak_planks
fill 546 194 484 547 194 485 minecraft:spruce_planks
fill 546 194 486 547 194 487 minecraft:dark_oak_planks
fill 546 194 488 547 194 489 minecraft:spruce_planks
fill 546 194 490 547 194 491 minecraft:dark_oak_planks
fill 546 194 492 547 194 493 minecraft:spruce_planks
fill 546 194 494 547 194 495 minecraft:dark_oak_planks
fill 546 194 496 547 194 497 minecraft:spruce_planks
fill 546 194 498 547 194 499 minecraft:dark_oak_planks
fill 546 194 500 547 194 501 minecraft:spruce_planks
fill 546 194 502 547 194 503 minecraft:dark_oak_planks
fill 546 194 504 547 194 504 minecraft:spruce_planks
fill 548 194 464 549 194 465 minecraft:dark_oak_planks
fill 548 194 466 549 194 467 minecraft:spruce_planks
fill 548 194 468 549 194 469 minecraft:dark_oak_planks
fill 548 194 470 549 194 471 minecraft:spruce_planks
fill 548 194 472 549 194 473 minecraft:dark_oak_planks
fill 548 194 474 549 194 475 minecraft:spruce_planks
fill 548 194 476 549 194 477 minecraft:dark_oak_planks
fill 548 194 478 549 194 479 minecraft:spruce_planks
fill 548 194 480 549 194 481 minecraft:dark_oak_planks
fill 548 194 482 549 194 483 minecraft:spruce_planks
fill 548 194 484 549 194 485 minecraft:dark_oak_planks
fill 548 194 486 549 194 487 minecraft:spruce_planks
fill 548 194 488 549 194 489 minecraft:dark_oak_planks
fill 548 194 490 549 194 491 minecraft:spruce_planks
fill 548 194 492 549 194 493 minecraft:dark_oak_planks
fill 548 194 494 549 194 495 minecraft:spruce_planks
fill 548 194 496 549 194 497 minecraft:dark_oak_planks
fill 548 194 498 549 194 499 minecraft:spruce_planks
fill 548 194 500 549 194 501 minecraft:dark_oak_planks
fill 548 194 502 549 194 503 minecraft:spruce_planks
fill 548 194 504 549 194 504 minecraft:dark_oak_planks
fill 550 194 464 551 194 465 minecraft:spruce_planks
fill 550 194 466 551 194 467 minecraft:dark_oak_planks
fill 550 194 468 551 194 469 minecraft:spruce_planks
fill 550 194 470 551 194 471 minecraft:dark_oak_planks
fill 550 194 472 551 194 473 minecraft:spruce_planks
fill 550 194 474 551 194 475 minecraft:dark_oak_planks
fill 550 194 476 551 194 477 minecraft:spruce_planks
fill 550 194 478 551 194 479 minecraft:dark_oak_planks
fill 550 194 480 551 194 481 minecraft:spruce_planks
fill 550 194 482 551 194 483 minecraft:dark_oak_planks
fill 550 194 484 551 194 485 minecraft:spruce_planks
fill 550 194 486 551 194 487 minecraft:dark_oak_planks
fill 550 194 488 551 194 489 minecraft:spruce_planks
fill 550 194 490 551 194 491 minecraft:dark_oak_planks
fill 550 194 492 551 194 493 minecraft:spruce_planks
fill 550 194 494 551 194 495 minecraft:dark_oak_planks
fill 550 194 496 551 194 497 minecraft:spruce_planks
fill 550 194 498 551 194 499 minecraft:dark_oak_planks
fill 550 194 500 551 194 501 minecraft:spruce_planks
fill 550 194 502 551 194 503 minecraft:dark_oak_planks
fill 550 194 504 551 194 504 minecraft:spruce_planks
fill 552 194 464 553 194 465 minecraft:dark_oak_planks
fill 552 194 466 553 194 467 minecraft:spruce_planks
fill 552 194 468 553 194 469 minecraft:dark_oak_planks
fill 552 194 470 553 194 471 minecraft:spruce_planks
fill 552 194 472 553 194 473 minecraft:dark_oak_planks
fill 552 194 474 553 194 475 minecraft:spruce_planks
fill 552 194 476 553 194 477 minecraft:dark_oak_planks
fill 552 194 478 553 194 479 minecraft:spruce_planks
fill 552 194 480 553 194 481 minecraft:dark_oak_planks
fill 552 194 482 553 194 483 minecraft:spruce_planks
fill 552 194 484 553 194 485 minecraft:dark_oak_planks
fill 552 194 486 553 194 487 minecraft:spruce_planks
fill 552 194 488 553 194 489 minecraft:dark_oak_planks
fill 552 194 490 553 194 491 minecraft:spruce_planks
fill 552 194 492 553 194 493 minecraft:dark_oak_planks
fill 552 194 494 553 194 495 minecraft:spruce_planks
fill 552 194 496 553 194 497 minecraft:dark_oak_planks
fill 552 194 498 553 194 499 minecraft:spruce_planks
fill 552 194 500 553 194 501 minecraft:dark_oak_planks
fill 552 194 502 553 194 503 minecraft:spruce_planks
fill 552 194 504 553 194 504 minecraft:dark_oak_planks
fill 554 194 464 555 194 465 minecraft:spruce_planks
fill 554 194 466 555 194 467 minecraft:dark_oak_planks
fill 554 194 468 555 194 469 minecraft:spruce_planks
fill 554 194 470 555 194 471 minecraft:dark_oak_planks
fill 554 194 472 555 194 473 minecraft:spruce_planks
fill 554 194 474 555 194 475 minecraft:dark_oak_planks
fill 554 194 476 555 194 477 minecraft:spruce_planks
fill 554 194 478 555 194 479 minecraft:dark_oak_planks
fill 554 194 480 555 194 481 minecraft:spruce_planks
fill 554 194 482 555 194 483 minecraft:dark_oak_planks
fill 554 194 484 555 194 485 minecraft:spruce_planks
fill 554 194 486 555 194 487 minecraft:dark_oak_planks
fill 554 194 488 555 194 489 minecraft:spruce_planks
fill 554 194 490 555 194 491 minecraft:dark_oak_planks
fill 554 194 492 555 194 493 minecraft:spruce_planks
fill 554 194 494 555 194 495 minecraft:dark_oak_planks
fill 554 194 496 555 194 497 minecraft:spruce_planks
fill 554 194 498 555 194 499 minecraft:dark_oak_planks
fill 554 194 500 555 194 501 minecraft:spruce_planks
fill 554 194 502 555 194 503 minecraft:dark_oak_planks
fill 554 194 504 555 194 504 minecraft:spruce_planks
fill 556 194 464 557 194 465 minecraft:dark_oak_planks
fill 556 194 466 557 194 467 minecraft:spruce_planks
fill 556 194 468 557 194 469 minecraft:dark_oak_planks
fill 556 194 470 557 194 471 minecraft:spruce_planks
fill 556 194 472 557 194 473 minecraft:dark_oak_planks
fill 556 194 474 557 194 475 minecraft:spruce_planks
fill 556 194 476 557 194 477 minecraft:dark_oak_planks
fill 556 194 478 557 194 479 minecraft:spruce_planks
fill 556 194 480 557 194 481 minecraft:dark_oak_planks
fill 556 194 482 557 194 483 minecraft:spruce_planks
fill 556 194 484 557 194 485 minecraft:dark_oak_planks
fill 556 194 486 557 194 487 minecraft:spruce_planks
fill 556 194 488 557 194 489 minecraft:dark_oak_planks
fill 556 194 490 557 194 491 minecraft:spruce_planks
fill 556 194 492 557 194 493 minecraft:dark_oak_planks
fill 556 194 494 557 194 495 minecraft:spruce_planks
fill 556 194 496 557 194 497 minecraft:dark_oak_planks
fill 556 194 498 557 194 499 minecraft:spruce_planks
fill 556 194 500 557 194 501 minecraft:dark_oak_planks
fill 556 194 502 557 194 503 minecraft:spruce_planks
fill 556 194 504 557 194 504 minecraft:dark_oak_planks
fill 558 194 464 558 194 465 minecraft:spruce_planks
fill 558 194 466 558 194 467 minecraft:dark_oak_planks
fill 558 194 468 558 194 469 minecraft:spruce_planks
fill 558 194 470 558 194 471 minecraft:dark_oak_planks
fill 558 194 472 558 194 473 minecraft:spruce_planks
fill 558 194 474 558 194 475 minecraft:dark_oak_planks
fill 558 194 476 558 194 477 minecraft:spruce_planks
fill 558 194 478 558 194 479 minecraft:dark_oak_planks
fill 558 194 480 558 194 481 minecraft:spruce_planks
fill 558 194 482 558 194 483 minecraft:dark_oak_planks
fill 558 194 484 558 194 485 minecraft:spruce_planks
fill 558 194 486 558 194 487 minecraft:dark_oak_planks
fill 558 194 488 558 194 489 minecraft:spruce_planks
fill 558 194 490 558 194 491 minecraft:dark_oak_planks
fill 558 194 492 558 194 493 minecraft:spruce_planks
fill 558 194 494 558 194 495 minecraft:dark_oak_planks
fill 558 194 496 558 194 497 minecraft:spruce_planks
fill 558 194 498 558 194 499 minecraft:dark_oak_planks
fill 558 194 500 558 194 501 minecraft:spruce_planks
fill 558 194 502 558 194 503 minecraft:dark_oak_planks
setblock 558 194 504 minecraft:spruce_planks
fill 518 195 464 518 195 468 minecraft:orange_terracotta
setblock 518 195 469 minecraft:white_concrete
fill 518 195 470 518 195 476 minecraft:orange_terracotta
setblock 518 195 477 minecraft:white_concrete
fill 518 195 478 518 195 484 minecraft:orange_terracotta
setblock 518 195 485 minecraft:white_concrete
fill 518 195 486 518 195 492 minecraft:orange_terracotta
setblock 518 195 493 minecraft:white_concrete
fill 518 195 494 518 195 500 minecraft:orange_terracotta
setblock 518 195 501 minecraft:white_concrete
fill 518 195 502 522 195 504 minecraft:orange_terracotta
fill 519 195 464 519 195 467 minecraft:orange_terracotta
setblock 519 195 468 minecraft:white_concrete
fill 519 195 469 519 195 475 minecraft:orange_terracotta
setblock 519 195 476 minecraft:white_concrete
fill 519 195 477 519 195 483 minecraft:orange_terracotta
setblock 519 195 484 minecraft:white_concrete
fill 519 195 485 519 195 491 minecraft:orange_terracotta
setblock 519 195 492 minecraft:white_concrete
fill 519 195 493 519 195 499 minecraft:orange_terracotta
setblock 519 195 500 minecraft:white_concrete
fill 519 195 501 525 195 501 minecraft:orange_terracotta
fill 520 195 464 520 195 466 minecraft:orange_terracotta
setblock 520 195 467 minecraft:white_concrete
fill 520 195 468 520 195 474 minecraft:orange_terracotta
setblock 520 195 475 minecraft:white_concrete
fill 520 195 476 520 195 482 minecraft:orange_terracotta
setblock 520 195 483 minecraft:white_concrete
fill 520 195 484 520 195 490 minecraft:orange_terracotta
setblock 520 195 491 minecraft:white_concrete
fill 520 195 492 520 195 498 minecraft:orange_terracotta
setblock 520 195 499 minecraft:white_concrete
fill 520 195 500 526 195 500 minecraft:orange_terracotta
fill 521 195 464 521 195 465 minecraft:orange_terracotta
setblock 521 195 466 minecraft:white_concrete
fill 521 195 467 521 195 473 minecraft:orange_terracotta
setblock 521 195 474 minecraft:white_concrete
fill 521 195 475 521 195 481 minecraft:orange_terracotta
setblock 521 195 482 minecraft:white_concrete
fill 521 195 483 521 195 489 minecraft:orange_terracotta
setblock 521 195 490 minecraft:white_concrete
fill 521 195 491 521 195 497 minecraft:orange_terracotta
setblock 521 195 498 minecraft:white_concrete
fill 521 195 499 527 195 499 minecraft:orange_terracotta
setblock 522 195 464 minecraft:orange_terracotta
setblock 522 195 465 minecraft:white_concrete
fill 522 195 466 522 195 472 minecraft:orange_terracotta
setblock 522 195 473 minecraft:white_concrete
fill 522 195 474 522 195 480 minecraft:orange_terracotta
setblock 522 195 481 minecraft:white_concrete
fill 522 195 482 522 195 488 minecraft:orange_terracotta
setblock 522 195 489 minecraft:white_concrete
fill 522 195 490 522 195 496 minecraft:orange_terracotta
setblock 522 195 497 minecraft:white_concrete
fill 522 195 498 528 195 498 minecraft:orange_terracotta
setblock 523 195 464 minecraft:white_concrete
fill 523 195 465 523 195 471 minecraft:orange_terracotta
setblock 523 195 472 minecraft:white_concrete
fill 523 195 473 523 195 479 minecraft:orange_terracotta
setblock 523 195 480 minecraft:white_concrete
fill 523 195 481 523 195 487 minecraft:orange_terracotta
setblock 523 195 488 minecraft:white_concrete
fill 523 195 489 523 195 495 minecraft:orange_terracotta
setblock 523 195 496 minecraft:white_concrete
fill 523 195 497 529 195 497 minecraft:orange_terracotta
fill 523 195 502 523 195 503 minecraft:orange_terracotta
setblock 523 195 504 minecraft:white_concrete
fill 524 195 464 524 195 470 minecraft:orange_terracotta
setblock 524 195 471 minecraft:white_concrete
fill 524 195 472 524 195 478 minecraft:orange_terracotta
setblock 524 195 479 minecraft:white_concrete
fill 524 195 480 524 195 486 minecraft:orange_terracotta
setblock 524 195 487 minecraft:white_concrete
fill 524 195 488 524 195 494 minecraft:orange_terracotta
setblock 524 195 495 minecraft:white_concrete
fill 524 195 496 530 195 496 minecraft:orange_terracotta
setblock 524 195 502 minecraft:orange_terracotta
setblock 524 195 503 minecraft:white_concrete
fill 524 195 504 530 195 504 minecraft:orange_terracotta
fill 525 195 464 525 195 469 minecraft:orange_terracotta
setblock 525 195 470 minecraft:white_concrete
fill 525 195 471 525 195 477 minecraft:orange_terracotta
setblock 525 195 478 minecraft:white_concrete
fill 525 195 479 525 195 485 minecraft:orange_terracotta
setblock 525 195 486 minecraft:white_concrete
fill 525 195 487 525 195 493 minecraft:orange_terracotta
setblock 525 195 494 minecraft:white_concrete
fill 525 195 495 531 195 495 minecraft:orange_terracotta
setblock 525 195 502 minecraft:white_concrete
fill 525 195 503 531 195 503 minecraft:orange_terracotta
fill 526 195 464 526 195 468 minecraft:orange_terracotta
setblock 526 195 469 minecraft:white_concrete
fill 526 195 470 526 195 476 minecraft:orange_terracotta
setblock 526 195 477 minecraft:white_concrete
fill 526 195 478 526 195 484 minecraft:orange_terracotta
setblock 526 195 485 minecraft:white_concrete
fill 526 195 486 526 195 492 minecraft:orange_terracotta
setblock 526 195 493 minecraft:white_concrete
fill 526 195 494 532 195 494 minecraft:orange_terracotta
setblock 526 195 501 minecraft:white_concrete
fill 526 195 502 532 195 502 minecraft:orange_terracotta
fill 527 195 464 527 195 467 minecraft:orange_terracotta
setblock 527 195 468 minecraft:white_concrete
fill 527 195 469 527 195 475 minecraft:orange_terracotta
setblock 527 195 476 minecraft:white_concrete
fill 527 195 477 527 195 483 minecraft:orange_terracotta
setblock 527 195 484 minecraft:white_concrete
fill 527 195 485 527 195 491 minecraft:orange_terracotta
setblock 527 195 492 minecraft:white_concrete
fill 527 195 493 533 195 493 minecraft:orange_terracotta
setblock 527 195 500 minecraft:white_concrete
fill 527 195 501 533 195 501 minecraft:orange_terracotta
fill 528 195 464 528 195 466 minecraft:orange_terracotta
setblock 528 195 467 minecraft:white_concrete
fill 528 195 468 528 195 474 minecraft:orange_terracotta
setblock 528 195 475 minecraft:white_concrete
fill 528 195 476 528 195 482 minecraft:orange_terracotta
setblock 528 195 483 minecraft:white_concrete
fill 528 195 484 528 195 490 minecraft:orange_terracotta
setblock 528 195 491 minecraft:white_concrete
fill 528 195 492 534 195 492 minecraft:orange_terracotta
setblock 528 195 499 minecraft:white_concrete
fill 528 195 500 534 195 500 minecraft:orange_terracotta
fill 529 195 464 529 195 465 minecraft:orange_terracotta
setblock 529 195 466 minecraft:white_concrete
fill 529 195 467 529 195 473 minecraft:orange_terracotta
setblock 529 195 474 minecraft:white_concrete
fill 529 195 475 529 195 481 minecraft:orange_terracotta
setblock 529 195 482 minecraft:white_concrete
fill 529 195 483 529 195 489 minecraft:orange_terracotta
setblock 529 195 490 minecraft:white_concrete
fill 529 195 491 535 195 491 minecraft:orange_terracotta
setblock 529 195 498 minecraft:white_concrete
fill 529 195 499 535 195 499 minecraft:orange_terracotta
setblock 530 195 464 minecraft:orange_terracotta
setblock 530 195 465 minecraft:white_concrete
fill 530 195 466 530 195 472 minecraft:orange_terracotta
setblock 530 195 473 minecraft:white_concrete
fill 530 195 474 530 195 480 minecraft:orange_terracotta
setblock 530 195 481 minecraft:white_concrete
fill 530 195 482 530 195 488 minecraft:orange_terracotta
setblock 530 195 489 minecraft:white_concrete
fill 530 195 490 536 195 490 minecraft:orange_terracotta
setblock 530 195 497 minecraft:white_concrete
fill 530 195 498 536 195 498 minecraft:orange_terracotta
setblock 531 195 464 minecraft:white_concrete
fill 531 195 465 531 195 471 minecraft:orange_terracotta
setblock 531 195 472 minecraft:white_concrete
fill 531 195 473 531 195 479 minecraft:orange_terracotta
setblock 531 195 480 minecraft:white_concrete
fill 531 195 481 531 195 487 minecraft:orange_terracotta
setblock 531 195 488 minecraft:white_concrete
fill 531 195 489 537 195 489 minecraft:orange_terracotta
setblock 531 195 496 minecraft:white_concrete
fill 531 195 497 537 195 497 minecraft:orange_terracotta
setblock 531 195 504 minecraft:white_concrete
fill 532 195 464 532 195 470 minecraft:orange_terracotta
setblock 532 195 471 minecraft:white_concrete
fill 532 195 472 532 195 478 minecraft:orange_terracotta
setblock 532 195 479 minecraft:white_concrete
fill 532 195 480 532 195 486 minecraft:orange_terracotta
setblock 532 195 487 minecraft:white_concrete
fill 532 195 488 538 195 488 minecraft:orange_terracotta
setblock 532 195 495 minecraft:white_concrete
fill 532 195 496 538 195 496 minecraft:orange_terracotta
setblock 532 195 503 minecraft:white_concrete
fill 532 195 504 538 195 504 minecraft:orange_terracotta
fill 533 195 464 533 195 469 minecraft:orange_terracotta
setblock 533 195 470 minecraft:white_concrete
fill 533 195 471 533 195 477 minecraft:orange_terracotta
setblock 533 195 478 minecraft:white_concrete
fill 533 195 479 533 195 485 minecraft:orange_terracotta
setblock 533 195 486 minecraft:white_concrete
fill 533 195 487 539 195 487 minecraft:orange_terracotta
setblock 533 195 494 minecraft:white_concrete
fill 533 195 495 539 195 495 minecraft:orange_terracotta
setblock 533 195 502 minecraft:white_concrete
fill 533 195 503 539 195 503 minecraft:orange_terracotta
fill 534 195 464 534 195 468 minecraft:orange_terracotta
setblock 534 195 469 minecraft:white_concrete
fill 534 195 470 534 195 476 minecraft:orange_terracotta
setblock 534 195 477 minecraft:white_concrete
fill 534 195 478 534 195 484 minecraft:orange_terracotta
fill 534 195 485 534 196 485 minecraft:white_concrete
fill 534 195 486 536 195 486 minecraft:orange_terracotta
setblock 534 195 493 minecraft:white_concrete
fill 534 195 494 540 195 494 minecraft:orange_terracotta
setblock 534 195 501 minecraft:white_concrete
fill 534 195 502 540 195 502 minecraft:orange_terracotta
fill 535 195 464 535 195 467 minecraft:orange_terracotta
setblock 535 195 468 minecraft:white_concrete
fill 535 195 469 535 195 475 minecraft:orange_terracotta
setblock 535 195 476 minecraft:white_concrete
fill 535 195 477 535 195 483 minecraft:orange_terracotta
setblock 535 195 484 minecraft:white_concrete
setblock 535 195 485 minecraft:orange_terracotta
setblock 535 195 492 minecraft:white_concrete
fill 535 195 493 541 195 493 minecraft:orange_terracotta
setblock 535 195 500 minecraft:white_concrete
fill 535 195 501 541 195 501 minecraft:orange_terracotta
fill 536 195 464 536 195 466 minecraft:orange_terracotta
setblock 536 195 467 minecraft:white_concrete
fill 536 195 468 536 195 474 minecraft:orange_terracotta
setblock 536 195 475 minecraft:white_concrete
fill 536 195 476 536 195 482 minecraft:orange_terracotta
fill 536 195 483 536 195 485 minecraft:orange_concrete
setblock 536 195 491 minecraft:white_concrete
fill 536 195 492 542 195 492 minecraft:orange_terracotta
setblock 536 195 499 minecraft:white_concrete
fill 536 195 500 542 195 500 minecraft:orange_terracotta
fill 537 195 464 537 195 465 minecraft:orange_terracotta
setblock 537 195 466 minecraft:white_concrete
fill 537 195 467 537 195 473 minecraft:orange_terracotta
setblock 537 195 474 minecraft:white_concrete
fill 537 195 475 537 195 481 minecraft:orange_terracotta
fill 537 195 482 539 196 482 minecraft:orange_concrete
fill 537 195 486 539 196 486 minecraft:orange_concrete
setblock 537 195 490 minecraft:white_concrete
fill 537 195 491 543 195 491 minecraft:orange_terracotta
setblock 537 195 498 minecraft:white_concrete
fill 537 195 499 543 195 499 minecraft:orange_terracotta
setblock 538 195 464 minecraft:orange_terracotta
setblock 538 195 465 minecraft:white_concrete
fill 538 195 466 538 195 472 minecraft:orange_terracotta
setblock 538 195 473 minecraft:white_concrete
fill 538 195 474 538 195 480 minecraft:orange_terracotta
setblock 538 195 481 minecraft:white_concrete
setblock 538 195 489 minecraft:white_concrete
fill 538 195 490 544 195 490 minecraft:orange_terracotta
setblock 538 195 497 minecraft:white_concrete
fill 538 195 498 544 195 498 minecraft:orange_terracotta
setblock 539 195 464 minecraft:white_concrete
fill 539 195 465 539 195 471 minecraft:orange_terracotta
setblock 539 195 472 minecraft:white_concrete
fill 539 195 473 539 195 479 minecraft:orange_terracotta
setblock 539 195 480 minecraft:white_concrete
fill 539 195 481 545 195 481 minecraft:orange_terracotta
setblock 539 195 488 minecraft:white_concrete
fill 539 195 489 545 195 489 minecraft:orange_terracotta
setblock 539 195 496 minecraft:white_concrete
fill 539 195 497 545 195 497 minecraft:orange_terracotta
setblock 539 195 504 minecraft:white_concrete
fill 540 195 464 540 195 470 minecraft:orange_terracotta
setblock 540 195 471 minecraft:white_concrete
fill 540 195 472 540 195 478 minecraft:orange_terracotta
setblock 540 195 479 minecraft:white_concrete
fill 540 195 480 546 195 480 minecraft:orange_terracotta
fill 540 195 482 544 195 482 minecraft:orange_terracotta
fill 540 195 483 540 196 485 minecraft:orange_concrete
setblock 540 195 486 minecraft:orange_terracotta
setblock 540 195 487 minecraft:white_concrete
fill 540 195 488 546 195 488 minecraft:orange_terracotta
setblock 540 195 495 minecraft:white_concrete
fill 540 195 496 546 195 496 minecraft:orange_terracotta
setblock 540 195 503 minecraft:white_concrete
fill 540 195 504 546 195 504 minecraft:orange_terracotta
fill 541 195 464 541 195 469 minecraft:orange_terracotta
setblock 541 195 470 minecraft:white_concrete
fill 541 195 471 541 195 477 minecraft:orange_terracotta
setblock 541 195 478 minecraft:white_concrete
fill 541 195 479 547 195 479 minecraft:orange_terracotta
fill 541 195 483 541 195 485 minecraft:orange_terracotta
setblock 541 195 486 minecraft:white_concrete
fill 541 195 487 547 195 487 minecraft:orange_terracotta
setblock 541 195 494 minecraft:white_concrete
fill 541 195 495 547 195 495 minecraft:orange_terracotta
setblock 541 195 502 minecraft:white_concrete
fill 541 195 503 547 195 503 minecraft:orange_terracotta
fill 542 195 464 542 195 468 minecraft:orange_terracotta
setblock 542 195 469 minecraft:white_concrete
fill 542 195 470 542 195 476 minecraft:orange_terracotta
setblock 542 195 477 minecraft:white_concrete
fill 542 195 478 548 195 478 minecraft:orange_terracotta
fill 542 195 483 542 195 484 minecraft:orange_terracotta
setblock 542 195 485 minecraft:white_concrete
fill 542 195 486 548 195 486 minecraft:orange_terracotta
setblock 542 195 493 minecraft:white_concrete
fill 542 195 494 548 195 494 minecraft:orange_terracotta
setblock 542 195 501 minecraft:white_concrete
fill 542 195 502 548 195 502 minecraft:orange_terracotta
fill 543 195 464 543 195 467 minecraft:orange_terracotta
setblock 543 195 468 minecraft:white_concrete
fill 543 195 469 543 195 475 minecraft:orange_terracotta
setblock 543 195 476 minecraft:white_concrete
fill 543 195 477 549 195 477 minecraft:orange_terracotta
setblock 543 195 483 minecraft:orange_terracotta
setblock 543 195 484 minecraft:white_concrete
fill 543 195 485 549 195 485 minecraft:orange_terracotta
setblock 543 195 492 minecraft:white_concrete
fill 543 195 493 549 195 493 minecraft:orange_terracotta
setblock 543 195 500 minecraft:white_concrete
fill 543 195 501 549 195 501 minecraft:orange_terracotta
fill 544 195 464 544 195 466 minecraft:orange_terracotta
setblock 544 195 467 minecraft:white_concrete
fill 544 195 468 544 195 474 minecraft:orange_terracotta
setblock 544 195 475 minecraft:white_concrete
fill 544 195 476 550 195 476 minecraft:orange_terracotta
setblock 544 195 483 minecraft:white_concrete
fill 544 195 484 550 195 484 minecraft:orange_terracotta
setblock 544 195 491 minecraft:white_concrete
fill 544 195 492 550 195 492 minecraft:orange_terracotta
setblock 544 195 499 minecraft:white_concrete
fill 544 195 500 550 195 500 minecraft:orange_terracotta
fill 545 195 464 545 195 465 minecraft:orange_terracotta
setblock 545 195 466 minecraft:white_concrete
fill 545 195 467 545 195 473 minecraft:orange_terracotta
setblock 545 195 474 minecraft:white_concrete
fill 545 195 475 551 195 475 minecraft:orange_terracotta
setblock 545 195 482 minecraft:white_concrete
fill 545 195 483 551 195 483 minecraft:orange_terracotta
setblock 545 195 490 minecraft:white_concrete
fill 545 195 491 551 195 491 minecraft:orange_terracotta
setblock 545 195 498 minecraft:white_concrete
fill 545 195 499 551 195 499 minecraft:orange_terracotta
setblock 546 195 464 minecraft:orange_terracotta
setblock 546 195 465 minecraft:white_concrete
fill 546 195 466 546 195 472 minecraft:orange_terracotta
setblock 546 195 473 minecraft:white_concrete
fill 546 195 474 552 195 474 minecraft:orange_terracotta
setblock 546 195 481 minecraft:white_concrete
fill 546 195 482 552 195 482 minecraft:orange_terracotta
setblock 546 195 489 minecraft:white_concrete
fill 546 195 490 552 195 490 minecraft:orange_terracotta
setblock 546 195 497 minecraft:white_concrete
fill 546 195 498 552 195 498 minecraft:orange_terracotta
setblock 547 195 464 minecraft:white_concrete
fill 547 195 465 547 195 471 minecraft:orange_terracotta
setblock 547 195 472 minecraft:white_concrete
fill 547 195 473 553 195 473 minecraft:orange_terracotta
setblock 547 195 480 minecraft:white_concrete
fill 547 195 481 553 195 481 minecraft:orange_terracotta
setblock 547 195 488 minecraft:white_concrete
fill 547 195 489 553 195 489 minecraft:orange_terracotta
setblock 547 195 496 minecraft:white_concrete
fill 547 195 497 553 195 497 minecraft:orange_terracotta
setblock 547 195 504 minecraft:white_concrete
fill 548 195 464 548 195 470 minecraft:orange_terracotta
setblock 548 195 471 minecraft:white_concrete
fill 548 195 472 554 195 472 minecraft:orange_terracotta
setblock 548 195 479 minecraft:white_concrete
fill 548 195 480 554 195 480 minecraft:orange_terracotta
setblock 548 195 487 minecraft:white_concrete
fill 548 195 488 554 195 488 minecraft:orange_terracotta
setblock 548 195 495 minecraft:white_concrete
fill 548 195 496 554 195 496 minecraft:orange_terracotta
setblock 548 195 503 minecraft:white_concrete
fill 548 195 504 554 195 504 minecraft:orange_terracotta
fill 549 195 464 549 195 469 minecraft:orange_terracotta
setblock 549 195 470 minecraft:white_concrete
fill 549 195 471 555 195 471 minecraft:orange_terracotta
setblock 549 195 478 minecraft:white_concrete
fill 549 195 479 555 195 479 minecraft:orange_terracotta
setblock 549 195 486 minecraft:white_concrete
fill 549 195 487 555 195 487 minecraft:orange_terracotta
setblock 549 195 494 minecraft:white_concrete
fill 549 195 495 555 195 495 minecraft:orange_terracotta
setblock 549 195 502 minecraft:white_concrete
fill 549 195 503 555 195 503 minecraft:orange_terracotta
fill 550 195 464 550 195 468 minecraft:orange_terracotta
setblock 550 195 469 minecraft:white_concrete
fill 550 195 470 556 195 470 minecraft:orange_terracotta
setblock 550 195 477 minecraft:white_concrete
fill 550 195 478 556 195 478 minecraft:orange_terracotta
setblock 550 195 485 minecraft:white_concrete
fill 550 195 486 556 195 486 minecraft:orange_terracotta
setblock 550 195 493 minecraft:white_concrete
fill 550 195 494 556 195 494 minecraft:orange_terracotta
setblock 550 195 501 minecraft:white_concrete
fill 550 195 502 556 195 502 minecraft:orange_terracotta
fill 551 195 464 551 195 467 minecraft:orange_terracotta
setblock 551 195 468 minecraft:white_concrete
fill 551 195 469 557 195 469 minecraft:orange_terracotta
setblock 551 195 476 minecraft:white_concrete
fill 551 195 477 557 195 477 minecraft:orange_terracotta
setblock 551 195 484 minecraft:white_concrete
fill 551 195 485 557 195 485 minecraft:orange_terracotta
setblock 551 195 492 minecraft:white_concrete
fill 551 195 493 557 195 493 minecraft:orange_terracotta
setblock 551 195 500 minecraft:white_concrete
fill 551 195 501 557 195 501 minecraft:orange_terracotta
fill 552 195 464 552 195 466 minecraft:orange_terracotta
setblock 552 195 467 minecraft:white_concrete
fill 552 195 468 558 195 468 minecraft:orange_terracotta
setblock 552 195 475 minecraft:white_concrete
fill 552 195 476 558 195 476 minecraft:orange_terracotta
setblock 552 195 483 minecraft:white_concrete
fill 552 195 484 558 195 484 minecraft:orange_terracotta
setblock 552 195 491 minecraft:white_concrete
fill 552 195 492 558 195 492 minecraft:orange_terracotta
setblock 552 195 499 minecraft:white_concrete
fill 552 195 500 558 195 500 minecraft:orange_terracotta
fill 553 195 464 553 195 465 minecraft:orange_terracotta
setblock 553 195 466 minecraft:white_concrete
fill 553 195 467 558 195 467 minecraft:orange_terracotta
setblock 553 195 474 minecraft:white_concrete
fill 553 195 475 558 195 475 minecraft:orange_terracotta
setblock 553 195 482 minecraft:white_concrete
fill 553 195 483 558 195 483 minecraft:orange_terracotta
setblock 553 195 490 minecraft:white_concrete
fill 553 195 491 558 195 491 minecraft:orange_terracotta
setblock 553 195 498 minecraft:white_concrete
fill 553 195 499 558 195 499 minecraft:orange_terracotta
setblock 554 195 464 minecraft:orange_terracotta
setblock 554 195 465 minecraft:white_concrete
fill 554 195 466 558 195 466 minecraft:orange_terracotta
setblock 554 195 473 minecraft:white_concrete
fill 554 195 474 558 195 474 minecraft:orange_terracotta
setblock 554 195 481 minecraft:white_concrete
fill 554 195 482 558 195 482 minecraft:orange_terracotta
setblock 554 195 489 minecraft:white_concrete
fill 554 195 490 558 195 490 minecraft:orange_terracotta
setblock 554 195 497 minecraft:white_concrete
fill 554 195 498 558 195 498 minecraft:orange_terracotta
setblock 555 195 464 minecraft:white_concrete
fill 555 195 465 558 195 465 minecraft:orange_terracotta
setblock 555 195 472 minecraft:white_concrete
fill 555 195 473 558 195 473 minecraft:orange_terracotta
setblock 555 195 480 minecraft:white_concrete
fill 555 195 481 558 195 481 minecraft:orange_terracotta
setblock 555 195 488 minecraft:white_concrete
fill 555 195 489 558 195 489 minecraft:orange_terracotta
setblock 555 195 496 minecraft:white_concrete
fill 555 195 497 558 195 497 minecraft:orange_terracotta
setblock 555 195 504 minecraft:white_concrete
fill 556 195 464 558 195 464 minecraft:orange_terracotta
setblock 556 195 471 minecraft:white_concrete
fill 556 195 472 558 195 472 minecraft:orange_terracotta
setblock 556 195 479 minecraft:white_concrete
fill 556 195 480 558 195 480 minecraft:orange_terracotta
setblock 556 195 487 minecraft:white_concrete
fill 556 195 488 558 195 488 minecraft:orange_terracotta
setblock 556 195 495 minecraft:white_concrete
fill 556 195 496 558 195 496 minecraft:orange_terracotta
setblock 556 195 503 minecraft:white_concrete
fill 556 195 504 558 195 504 minecraft:orange_terracotta
setblock 557 195 470 minecraft:white_concrete
fill 557 195 471 558 195 471 minecraft:orange_terracotta
setblock 557 195 478 minecraft:white_concrete
fill 557 195 479 558 195 479 minecraft:orange_terracotta
setblock 557 195 486 minecraft:white_concrete
fill 557 195 487 558 195 487 minecraft:orange_terracotta
setblock 557 195 494 minecraft:white_concrete
fill 557 195 495 558 195 495 minecraft:orange_terracotta
setblock 557 195 502 minecraft:white_concrete
fill 557 195 503 558 195 503 minecraft:orange_terracotta
setblock 558 195 469 minecraft:white_concrete
setblock 558 195 470 minecraft:orange_terracotta
setblock 558 195 477 minecraft:white_concrete
setblock 558 195 478 minecraft:orange_terracotta
setblock 558 195 485 minecraft:white_concrete
setblock 558 195 486 minecraft:orange_terracotta
setblock 558 195 493 minecraft:white_concrete
setblock 558 195 494 minecraft:orange_terracotta
setblock 558 195 501 minecraft:white_concrete
setblock 558 195 502 minecraft:orange_terracotta
fill 534 196 479 534 196 484 minecraft:white_concrete
fill 534 196 486 534 196 489 minecraft:white_concrete
setblock 536 196 483 minecraft:orange_concrete
fill 534 197 479 534 202 481 minecraft:white_concrete
fill 534 197 482 534 200 486 minecraft:red_concrete
fill 534 197 487 534 202 489 minecraft:white_concrete
setblock 520 198 466 minecraft:light[level=12]
setblock 520 198 474 minecraft:light[level=12]
setblock 520 198 482 minecraft:light[level=12]
setblock 520 198 490 minecraft:light[level=12]
setblock 520 198 498 minecraft:light[level=12]
setblock 528 198 466 minecraft:light[level=12]
setblock 528 198 474 minecraft:light[level=12]
setblock 528 198 482 minecraft:light[level=12]
setblock 528 198 490 minecraft:light[level=12]
setblock 528 198 498 minecraft:light[level=12]
setblock 536 198 466 minecraft:light[level=12]
setblock 536 198 474 minecraft:light[level=12]
setblock 536 198 482 minecraft:light[level=12]
setblock 536 198 490 minecraft:light[level=12]
setblock 536 198 498 minecraft:light[level=12]
setblock 544 198 466 minecraft:light[level=12]
setblock 544 198 474 minecraft:light[level=12]
setblock 544 198 482 minecraft:light[level=12]
setblock 544 198 490 minecraft:light[level=12]
setblock 544 198 498 minecraft:light[level=12]
setblock 552 198 466 minecraft:light[level=12]
setblock 552 198 474 minecraft:light[level=12]
setblock 552 198 482 minecraft:light[level=12]
setblock 552 198 490 minecraft:light[level=12]
setblock 552 198 498 minecraft:light[level=12]
fill 518 199 465 518 200 465 minecraft:gold_block
fill 518 199 469 518 235 469 minecraft:gold_block
fill 518 199 472 518 200 472 minecraft:gold_block
fill 518 199 476 518 235 476 minecraft:gold_block
fill 518 199 479 518 200 479 minecraft:gold_block
fill 518 199 483 518 235 483 minecraft:gold_block
fill 518 199 486 518 200 486 minecraft:gold_block
fill 518 199 490 518 235 490 minecraft:gold_block
fill 518 199 493 518 200 493 minecraft:gold_block
fill 518 199 497 518 235 497 minecraft:gold_block
fill 518 199 500 518 200 500 minecraft:gold_block
fill 518 199 504 518 235 504 minecraft:gold_block
fill 520 199 464 520 235 464 minecraft:gold_block
fill 521 199 480 521 211 480 minecraft:white_wool
fill 521 199 504 521 200 504 minecraft:gold_block
fill 524 199 464 524 200 464 minecraft:gold_block
fill 525 199 504 525 235 504 minecraft:gold_block
fill 527 199 464 527 235 464 minecraft:gold_block
fill 528 199 504 528 200 504 minecraft:gold_block
fill 531 199 464 531 200 464 minecraft:gold_block
fill 532 199 504 532 235 504 minecraft:gold_block
fill 534 199 464 534 235 464 minecraft:gold_block
fill 535 199 504 535 200 504 minecraft:gold_block
fill 538 199 464 538 200 464 minecraft:gold_block
fill 539 199 504 539 235 504 minecraft:gold_block
fill 541 199 464 541 235 464 minecraft:gold_block
fill 542 199 504 542 200 504 minecraft:gold_block
fill 545 199 464 545 200 464 minecraft:gold_block
fill 546 199 504 546 235 504 minecraft:gold_block
fill 548 199 464 548 235 464 minecraft:gold_block
fill 549 199 504 549 200 504 minecraft:gold_block
fill 552 199 464 552 200 464 minecraft:gold_block
fill 553 199 504 553 235 504 minecraft:gold_block
fill 555 199 464 555 235 464 minecraft:gold_block
setblock 556 199 472 minecraft:white_wool
fill 556 199 504 556 200 504 minecraft:gold_block
fill 558 199 465 558 200 465 minecraft:gold_block
fill 558 199 468 558 235 468 minecraft:gold_block
fill 558 199 472 558 200 472 minecraft:gold_block
fill 558 199 475 558 235 475 minecraft:gold_block
fill 558 199 479 558 200 479 minecraft:gold_block
fill 558 199 482 558 235 482 minecraft:gold_block
fill 558 199 486 558 200 486 minecraft:gold_block
fill 558 199 489 558 235 489 minecraft:gold_block
fill 558 199 493 558 200 493 minecraft:gold_block
fill 558 199 496 558 235 496 minecraft:gold_block
fill 558 199 500 558 200 500 minecraft:gold_block
fill 558 199 503 558 235 503 minecraft:gold_block
fill 518 200 464 519 200 464 minecraft:gold_block
fill 518 200 466 518 200 468 minecraft:gold_block
fill 518 200 470 518 200 471 minecraft:gold_block
fill 518 200 473 518 200 475 minecraft:gold_block
fill 518 200 477 518 200 478 minecraft:gold_block
fill 518 200 480 518 200 482 minecraft:gold_block
fill 518 200 484 518 200 485 minecraft:gold_block
fill 518 200 487 518 200 489 minecraft:gold_block
fill 518 200 491 518 200 492 minecraft:gold_block
fill 518 200 494 518 200 496 minecraft:gold_block
fill 518 200 498 518 200 499 minecraft:gold_block
fill 518 200 501 518 200 503 minecraft:gold_block
fill 519 200 504 520 200 504 minecraft:gold_block
fill 521 200 464 523 200 464 minecraft:gold_block
fill 522 200 504 524 200 504 minecraft:gold_block
fill 525 200 464 526 200 464 minecraft:gold_block
fill 526 200 504 527 200 504 minecraft:gold_block
fill 528 200 464 530 200 464 minecraft:gold_block
fill 529 200 504 531 200 504 minecraft:gold_block
fill 532 200 464 533 200 464 minecraft:gold_block
fill 533 200 504 534 200 504 minecraft:gold_block
fill 535 200 464 537 200 464 minecraft:gold_block
fill 536 200 504 538 200 504 minecraft:gold_block
fill 539 200 464 540 200 464 minecraft:gold_block
fill 540 200 504 541 200 504 minecraft:gold_block
fill 542 200 464 544 200 464 minecraft:gold_block
fill 543 200 504 545 200 504 minecraft:gold_block
fill 546 200 464 547 200 464 minecraft:gold_block
fill 547 200 504 548 200 504 minecraft:gold_block
fill 549 200 464 551 200 464 minecraft:gold_block
fill 550 200 504 552 200 504 minecraft:gold_block
fill 553 200 464 554 200 464 minecraft:gold_block
fill 554 200 504 555 200 504 minecraft:gold_block
fill 556 200 464 558 200 464 minecraft:gold_block
fill 557 200 504 558 200 504 minecraft:gold_block
fill 558 200 466 558 200 467 minecraft:gold_block
fill 558 200 469 558 200 471 minecraft:gold_block
fill 558 200 473 558 200 474 minecraft:gold_block
fill 558 200 476 558 200 478 minecraft:gold_block
fill 558 200 480 558 200 481 minecraft:gold_block
fill 558 200 483 558 200 485 minecraft:gold_block
fill 558 200 487 558 200 488 minecraft:gold_block
fill 558 200 490 558 200 492 minecraft:gold_block
fill 558 200 494 558 200 495 minecraft:gold_block
fill 558 200 497 558 200 499 minecraft:gold_block
fill 558 200 501 558 200 502 minecraft:gold_block
setblock 518 201 467 minecraft:gold_block
setblock 518 201 474 minecraft:gold_block
setblock 518 201 481 minecraft:gold_block
setblock 518 201 488 minecraft:gold_block
setblock 518 201 495 minecraft:gold_block
setblock 518 201 502 minecraft:gold_block
setblock 522 201 464 minecraft:gold_block
setblock 523 201 504 minecraft:gold_block
setblock 529 201 464 minecraft:gold_block
setblock 530 201 504 minecraft:gold_block
fill 534 201 482 534 202 486 minecraft:white_concrete
setblock 536 201 464 minecraft:gold_block
setblock 537 201 504 minecraft:gold_block
setblock 543 201 464 minecraft:gold_block
setblock 544 201 504 minecraft:gold_block
setblock 550 201 464 minecraft:gold_block
setblock 551 201 504 minecraft:gold_block
setblock 557 201 464 minecraft:gold_block
setblock 558 201 470 minecraft:gold_block
setblock 558 201 477 minecraft:gold_block
setblock 558 201 484 minecraft:gold_block
setblock 558 201 491 minecraft:gold_block
setblock 558 201 498 minecraft:gold_block
setblock 558 201 504 minecraft:gold_block
setblock 518 202 468 minecraft:gold_block
setblock 518 202 475 minecraft:gold_block
setblock 518 202 482 minecraft:gold_block
setblock 518 202 489 minecraft:gold_block
setblock 518 202 496 minecraft:gold_block
setblock 518 202 503 minecraft:gold_block
setblock 521 202 464 minecraft:gold_block
setblock 524 202 504 minecraft:gold_block
setblock 528 202 464 minecraft:gold_block
setblock 531 202 504 minecraft:gold_block
setblock 535 202 464 minecraft:gold_block
setblock 538 202 504 minecraft:gold_block
setblock 542 202 464 minecraft:gold_block
setblock 545 202 504 minecraft:gold_block
setblock 549 202 464 minecraft:gold_block
setblock 552 202 504 minecraft:gold_block
setblock 556 202 464 minecraft:gold_block
setblock 558 202 469 minecraft:gold_block
setblock 558 202 476 minecraft:gold_block
setblock 558 202 483 minecraft:gold_block
setblock 558 202 490 minecraft:gold_block
setblock 558 202 497 minecraft:gold_block
setblock 518 204 470 minecraft:gold_block
setblock 518 204 477 minecraft:gold_block
setblock 518 204 484 minecraft:gold_block
setblock 518 204 491 minecraft:gold_block
setblock 518 204 498 minecraft:gold_block
setblock 519 204 464 minecraft:gold_block
setblock 519 204 504 minecraft:gold_block
setblock 526 204 464 minecraft:gold_block
setblock 526 204 504 minecraft:gold_block
setblock 533 204 464 minecraft:gold_block
setblock 533 204 504 minecraft:gold_block
setblock 540 204 464 minecraft:gold_block
setblock 540 204 504 minecraft:gold_block
setblock 547 204 464 minecraft:gold_block
setblock 547 204 504 minecraft:gold_block
setblock 554 204 464 minecraft:gold_block
setblock 554 204 504 minecraft:gold_block
setblock 558 204 467 minecraft:gold_block
setblock 558 204 474 minecraft:gold_block
setblock 558 204 481 minecraft:gold_block
setblock 558 204 488 minecraft:gold_block
setblock 558 204 495 minecraft:gold_block
setblock 558 204 502 minecraft:gold_block
setblock 518 205 464 minecraft:gold_block
setblock 518 205 471 minecraft:gold_block
setblock 518 205 478 minecraft:gold_block
setblock 518 205 485 minecraft:gold_block
setblock 518 205 492 minecraft:gold_block
setblock 518 205 499 minecraft:gold_block
setblock 520 205 504 minecraft:gold_block
setblock 525 205 464 minecraft:gold_block
setblock 527 205 504 minecraft:gold_block
setblock 532 205 464 minecraft:gold_block
setblock 534 205 504 minecraft:gold_block
setblock 539 205 464 minecraft:gold_block
setblock 541 205 504 minecraft:gold_block
setblock 546 205 464 minecraft:gold_block
setblock 548 205 504 minecraft:gold_block
setblock 553 205 464 minecraft:gold_block
setblock 555 205 504 minecraft:gold_block
setblock 558 205 466 minecraft:gold_block
setblock 558 205 473 minecraft:gold_block
setblock 558 205 480 minecraft:gold_block
setblock 558 205 487 minecraft:gold_block
setblock 558 205 494 minecraft:gold_block
setblock 558 205 501 minecraft:gold_block
setblock 518 206 465 minecraft:gold_block
setblock 518 206 472 minecraft:gold_block
setblock 518 206 479 minecraft:gold_block
setblock 518 206 486 minecraft:gold_block
setblock 518 206 493 minecraft:gold_block
setblock 518 206 500 minecraft:gold_block
setblock 520 206 466 minecraft:light[level=12]
setblock 520 206 474 minecraft:light[level=12]
setblock 520 206 482 minecraft:light[level=12]
setblock 520 206 490 minecraft:light[level=12]
setblock 520 206 498 minecraft:light[level=12]
setblock 521 206 504 minecraft:gold_block
setblock 524 206 464 minecraft:gold_block
setblock 528 206 466 minecraft:light[level=12]
setblock 528 206 474 minecraft:light[level=12]
setblock 528 206 482 minecraft:light[level=12]
setblock 528 206 490 minecraft:light[level=12]
setblock 528 206 498 minecraft:light[level=12]
setblock 528 206 504 minecraft:gold_block
setblock 531 206 464 minecraft:gold_block
setblock 535 206 504 minecraft:gold_block
setblock 536 206 466 minecraft:light[level=12]
setblock 536 206 474 minecraft:light[level=12]
setblock 536 206 482 minecraft:light[level=12]
setblock 536 206 490 minecraft:light[level=12]
setblock 536 206 498 minecraft:light[level=12]
setblock 538 206 464 minecraft:gold_block
setblock 542 206 504 minecraft:gold_block
setblock 544 206 466 minecraft:light[level=12]
setblock 544 206 474 minecraft:light[level=12]
setblock 544 206 482 minecraft:light[level=12]
setblock 544 206 490 minecraft:light[level=12]
setblock 544 206 498 minecraft:light[level=12]
setblock 545 206 464 minecraft:gold_block
setblock 549 206 504 minecraft:gold_block
setblock 552 206 464 minecraft:gold_block
setblock 552 206 466 minecraft:light[level=12]
setblock 552 206 474 minecraft:light[level=12]
setblock 552 206 482 minecraft:light[level=12]
setblock 552 206 490 minecraft:light[level=12]
setblock 552 206 498 minecraft:light[level=12]
setblock 556 206 504 minecraft:gold_block
setblock 558 206 465 minecraft:gold_block
setblock 558 206 472 minecraft:gold_block
setblock 558 206 479 minecraft:gold_block
setblock 558 206 486 minecraft:gold_block
setblock 558 206 493 minecraft:gold_block
setblock 558 206 500 minecraft:gold_block
setblock 518 207 466 minecraft:gold_block
setblock 518 207 473 minecraft:gold_block
setblock 518 207 480 minecraft:gold_block
setblock 518 207 487 minecraft:gold_block
setblock 518 207 494 minecraft:gold_block
setblock 518 207 501 minecraft:gold_block
setblock 522 207 504 minecraft:gold_block
setblock 523 207 464 minecraft:gold_block
fill 526 207 467 526 223 467 minecraft:white_wool
setblock 529 207 504 minecraft:gold_block
setblock 530 207 464 minecraft:gold_block
setblock 536 207 504 minecraft:gold_block
setblock 537 207 464 minecraft:gold_block
setblock 543 207 504 minecraft:gold_block
setblock 544 207 464 minecraft:gold_block
setblock 550 207 504 minecraft:gold_block
setblock 551 207 464 minecraft:gold_block
setblock 557 207 504 minecraft:gold_block
setblock 558 207 464 minecraft:gold_block
setblock 558 207 471 minecraft:gold_block
setblock 558 207 478 minecraft:gold_block
setblock 558 207 485 minecraft:gold_block
setblock 558 207 492 minecraft:gold_block
setblock 558 207 499 minecraft:gold_block
setblock 518 208 467 minecraft:gold_block
setblock 518 208 474 minecraft:gold_block
setblock 518 208 481 minecraft:gold_block
setblock 518 208 488 minecraft:gold_block
setblock 518 208 495 minecraft:gold_block
setblock 518 208 502 minecraft:gold_block
setblock 522 208 464 minecraft:gold_block
setblock 523 208 504 minecraft:gold_block
setblock 529 208 464 minecraft:gold_block
setblock 530 208 504 minecraft:gold_block
setblock 536 208 464 minecraft:gold_block
setblock 537 208 504 minecraft:gold_block
setblock 543 208 464 minecraft:gold_block
setblock 544 208 504 minecraft:gold_block
setblock 550 208 464 minecraft:gold_block
setblock 551 208 504 minecraft:gold_block
setblock 557 208 464 minecraft:gold_block
setblock 558 208 470 minecraft:gold_block
setblock 558 208 477 minecraft:gold_block
setblock 558 208 484 minecraft:gold_block
setblock 558 208 491 minecraft:gold_block
setblock 558 208 498 minecraft:gold_block
setblock 558 208 504 minecraft:gold_block
fill 518 209 468 518 210 468 minecraft:gold_block
fill 518 209 475 518 210 475 minecraft:gold_block
fill 518 209 482 518 210 482 minecraft:gold_block
fill 518 209 489 518 210 489 minecraft:gold_block
fill 518 209 496 518 210 496 minecraft:gold_block
fill 518 209 503 518 210 503 minecraft:gold_block
fill 521 209 464 521 210 464 minecraft:gold_block
fill 524 209 504 524 210 504 minecraft:gold_block
fill 528 209 464 528 210 464 minecraft:gold_block
fill 531 209 504 531 210 504 minecraft:gold_block
fill 535 209 464 535 210 464 minecraft:gold_block
fill 538 209 504 538 210 504 minecraft:gold_block
fill 542 209 464 542 210 464 minecraft:gold_block
fill 545 209 504 545 210 504 minecraft:gold_block
fill 549 209 464 549 210 464 minecraft:gold_block
fill 552 209 504 552 210 504 minecraft:gold_block
fill 556 209 464 556 210 464 minecraft:gold_block
fill 558 209 469 558 210 469 minecraft:gold_block
fill 558 209 476 558 210 476 minecraft:gold_block
fill 558 209 483 558 210 483 minecraft:gold_block
fill 558 209 490 558 210 490 minecraft:gold_block
fill 558 209 497 558 210 497 minecraft:gold_block
fill 518 210 464 518 210 467 minecraft:gold_block
fill 518 210 470 518 210 474 minecraft:gold_block
fill 518 210 477 518 210 481 minecraft:gold_block
fill 518 210 484 518 210 488 minecraft:gold_block
fill 518 210 491 518 210 495 minecraft:gold_block
fill 518 210 498 518 210 502 minecraft:gold_block
fill 519 210 464 519 211 464 minecraft:gold_block
fill 519 210 483 520 211 483 minecraft:white_wool
fill 519 210 504 523 210 504 minecraft:gold_block
fill 522 210 464 526 210 464 minecraft:gold_block
fill 526 210 504 530 210 504 minecraft:gold_block
fill 529 210 464 533 210 464 minecraft:gold_block
fill 533 210 504 537 210 504 minecraft:gold_block
fill 536 210 464 540 210 464 minecraft:gold_block
fill 540 210 504 544 210 504 minecraft:gold_block
fill 543 210 464 547 210 464 minecraft:gold_block
fill 547 210 504 551 210 504 minecraft:gold_block
fill 550 210 464 554 210 464 minecraft:gold_block
fill 554 210 504 558 210 504 minecraft:gold_block
fill 557 210 464 558 210 464 minecraft:gold_block
fill 558 210 465 558 210 467 minecraft:gold_block
fill 558 210 470 558 210 474 minecraft:gold_block
fill 558 210 477 558 210 481 minecraft:gold_block
fill 558 210 484 558 210 488 minecraft:gold_block
fill 558 210 491 558 210 495 minecraft:gold_block
fill 558 210 498 558 210 502 minecraft:gold_block
setblock 518 211 470 minecraft:gold_block
setblock 518 211 477 minecraft:gold_block
setblock 518 211 484 minecraft:gold_block
setblock 518 211 491 minecraft:gold_block
setblock 518 211 498 minecraft:gold_block
setblock 519 211 504 minecraft:gold_block
setblock 526 211 464 minecraft:gold_block
setblock 526 211 504 minecraft:gold_block
setblock 533 211 464 minecraft:gold_block
setblock 533 211 504 minecraft:gold_block
setblock 540 211 464 minecraft:gold_block
setblock 540 211 504 minecraft:gold_block
setblock 547 211 464 minecraft:gold_block
setblock 547 211 504 minecraft:gold_block
setblock 554 211 464 minecraft:gold_block
setblock 554 211 504 minecraft:gold_block
setblock 558 211 467 minecraft:gold_block
schedule function dropper:buildpart/119_2 1t
