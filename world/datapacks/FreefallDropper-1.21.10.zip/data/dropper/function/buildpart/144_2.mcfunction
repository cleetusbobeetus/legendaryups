fill 28 183 604 28 215 604 minecraft:blue_concrete
setblock 29 183 604 minecraft:diamond_block
fill 30 183 646 30 188 646 minecraft:blue_concrete
fill 36 183 604 36 188 604 minecraft:blue_concrete
fill 38 183 604 38 218 604 minecraft:blue_concrete
setblock 42 183 611 minecraft:white_concrete
fill 42 183 614 42 188 614 minecraft:blue_concrete
fill 42 183 630 42 188 630 minecraft:blue_concrete
fill 0 184 629 0 218 629 minecraft:blue_concrete
fill 0 184 637 0 218 637 minecraft:blue_concrete
setblock 3 184 607 minecraft:light[level=14]
setblock 3 184 615 minecraft:light[level=14]
setblock 3 184 623 minecraft:light[level=14]
setblock 3 184 631 minecraft:light[level=14]
setblock 3 184 639 minecraft:light[level=14]
fill 3 184 646 3 218 646 minecraft:blue_concrete
setblock 4 184 646 minecraft:white_concrete
fill 5 184 646 6 218 646 minecraft:blue_concrete
setblock 11 184 607 minecraft:light[level=14]
setblock 11 184 615 minecraft:light[level=14]
setblock 11 184 623 minecraft:light[level=14]
setblock 11 184 631 minecraft:light[level=14]
setblock 11 184 639 minecraft:light[level=14]
setblock 19 184 607 minecraft:light[level=14]
setblock 19 184 615 minecraft:light[level=14]
setblock 19 184 623 minecraft:light[level=14]
setblock 19 184 631 minecraft:light[level=14]
setblock 19 184 639 minecraft:light[level=14]
fill 24 184 604 24 212 604 minecraft:blue_concrete
setblock 27 184 607 minecraft:light[level=14]
setblock 27 184 615 minecraft:light[level=14]
setblock 27 184 623 minecraft:light[level=14]
setblock 27 184 631 minecraft:light[level=14]
setblock 27 184 639 minecraft:light[level=14]
fill 29 184 604 29 215 604 minecraft:blue_concrete
setblock 35 184 607 minecraft:light[level=14]
setblock 35 184 615 minecraft:light[level=14]
setblock 35 184 623 minecraft:light[level=14]
setblock 35 184 631 minecraft:light[level=14]
setblock 35 184 639 minecraft:light[level=14]
fill 42 184 611 42 219 611 minecraft:blue_concrete
fill 4 185 646 4 201 646 minecraft:blue_concrete
setblock 0 186 620 minecraft:diamond_block
setblock 0 186 645 minecraft:glowstone
fill 0 186 646 0 216 646 minecraft:blue_concrete
setblock 14 186 646 minecraft:white_concrete
fill 15 186 646 15 215 646 minecraft:blue_concrete
setblock 40 186 646 minecraft:glowstone
setblock 42 186 625 minecraft:glowstone
setblock 0 187 619 minecraft:white_concrete
fill 0 187 620 0 218 620 minecraft:blue_concrete
fill 0 187 645 0 218 645 minecraft:blue_concrete
fill 14 187 646 14 188 646 minecraft:blue_concrete
fill 25 187 604 25 218 604 minecraft:blue_concrete
setblock 26 187 604 minecraft:glowstone
fill 40 187 646 40 218 646 minecraft:blue_concrete
fill 42 187 625 42 214 625 minecraft:blue_concrete
setblock 0 188 617 minecraft:glowstone
fill 0 188 619 0 196 619 minecraft:blue_concrete
fill 26 188 604 26 215 604 minecraft:blue_concrete
fill 27 188 613 28 189 614 minecraft:gold_block
fill 0 189 612 0 191 612 minecraft:moss_block
fill 0 189 617 0 218 617 minecraft:blue_concrete
fill 0 189 628 0 191 628 minecraft:moss_block
fill 0 189 644 0 191 644 minecraft:moss_block
fill 4 189 604 4 191 604 minecraft:moss_block
fill 14 189 646 14 191 646 minecraft:moss_block
fill 18 189 641 20 190 645 minecraft:diamond_block
fill 19 189 640 19 190 640 minecraft:diamond_block
fill 20 189 604 20 191 604 minecraft:moss_block
fill 30 189 646 30 191 646 minecraft:moss_block
fill 36 189 604 36 191 604 minecraft:moss_block
fill 42 189 614 42 191 614 minecraft:moss_block
fill 42 189 630 42 191 630 minecraft:moss_block
setblock 0 190 643 minecraft:glowstone
fill 17 190 643 17 191 645 minecraft:diamond_block
fill 21 190 643 21 191 645 minecraft:diamond_block
setblock 22 190 646 minecraft:glowstone
setblock 42 190 635 minecraft:white_concrete
fill 0 191 643 0 218 643 minecraft:blue_concrete
setblock 3 191 604 minecraft:glowstone
fill 18 191 642 20 191 645 minecraft:diamond_block
setblock 19 191 641 minecraft:diamond_block
fill 22 191 646 22 218 646 minecraft:blue_concrete
setblock 42 191 612 minecraft:diamond_block
fill 42 191 635 42 218 635 minecraft:blue_concrete
fill 0 192 607 0 215 607 minecraft:blue_concrete
setblock 0 192 608 minecraft:diamond_block
fill 0 192 609 0 205 609 minecraft:blue_concrete
fill 0 192 612 0 197 612 minecraft:blue_concrete
fill 0 192 628 0 197 628 minecraft:blue_concrete
fill 0 192 644 0 197 644 minecraft:blue_concrete
fill 3 192 604 4 197 604 minecraft:blue_concrete
setblock 3 192 607 minecraft:light[level=14]
setblock 3 192 615 minecraft:light[level=14]
setblock 3 192 623 minecraft:light[level=14]
setblock 3 192 631 minecraft:light[level=14]
setblock 3 192 639 minecraft:light[level=14]
setblock 5 192 604 minecraft:white_concrete
setblock 11 192 607 minecraft:light[level=14]
setblock 11 192 615 minecraft:light[level=14]
setblock 11 192 623 minecraft:light[level=14]
setblock 11 192 631 minecraft:light[level=14]
setblock 11 192 639 minecraft:light[level=14]
fill 14 192 646 14 197 646 minecraft:blue_concrete
fill 18 192 643 20 192 645 minecraft:diamond_block
setblock 19 192 607 minecraft:light[level=14]
setblock 19 192 615 minecraft:light[level=14]
setblock 19 192 623 minecraft:light[level=14]
setblock 19 192 631 minecraft:light[level=14]
setblock 19 192 639 minecraft:light[level=14]
fill 20 192 604 20 197 604 minecraft:blue_concrete
setblock 27 192 607 minecraft:light[level=14]
setblock 27 192 615 minecraft:light[level=14]
setblock 27 192 623 minecraft:light[level=14]
setblock 27 192 631 minecraft:light[level=14]
setblock 27 192 639 minecraft:light[level=14]
fill 30 192 646 30 197 646 minecraft:blue_concrete
setblock 35 192 607 minecraft:light[level=14]
setblock 35 192 615 minecraft:light[level=14]
setblock 35 192 623 minecraft:light[level=14]
setblock 35 192 631 minecraft:light[level=14]
setblock 35 192 639 minecraft:light[level=14]
fill 36 192 604 36 197 604 minecraft:blue_concrete
fill 42 192 612 42 204 612 minecraft:blue_concrete
fill 42 192 614 42 197 614 minecraft:blue_concrete
fill 42 192 630 42 197 630 minecraft:blue_concrete
fill 0 193 608 0 218 608 minecraft:blue_concrete
setblock 0 193 641 minecraft:glowstone
fill 5 193 604 5 218 604 minecraft:blue_concrete
setblock 23 193 604 minecraft:white_concrete
setblock 36 193 646 minecraft:white_concrete
fill 0 194 641 0 218 641 minecraft:blue_concrete
setblock 19 194 604 minecraft:diamond_block
fill 23 194 604 23 202 604 minecraft:blue_concrete
fill 26 194 612 26 195 612 minecraft:diamond_block
fill 36 194 646 36 218 646 minecraft:blue_concrete
setblock 42 194 610 minecraft:white_concrete
setblock 17 195 604 minecraft:white_concrete
fill 19 195 604 19 214 604 minecraft:blue_concrete
setblock 35 195 646 minecraft:glowstone
setblock 39 195 604 minecraft:glowstone
fill 42 195 610 42 197 610 minecraft:blue_concrete
fill 17 196 604 17 218 604 minecraft:blue_concrete
fill 26 196 611 26 205 612 minecraft:dirt
fill 35 196 646 35 201 646 minecraft:blue_concrete
fill 39 196 604 39 210 604 minecraft:blue_concrete
setblock 0 197 619 minecraft:diamond_block
fill 25 197 611 25 205 612 minecraft:dirt
setblock 34 197 604 minecraft:glowstone
fill 0 198 612 0 200 612 minecraft:moss_block
fill 0 198 619 0 219 619 minecraft:blue_concrete
fill 0 198 628 0 200 628 minecraft:moss_block
fill 0 198 644 0 200 644 minecraft:moss_block
fill 3 198 604 3 218 604 minecraft:blue_concrete
fill 4 198 604 4 200 604 minecraft:moss_block
setblock 8 198 604 minecraft:glowstone
fill 14 198 646 14 200 646 minecraft:moss_block
fill 20 198 604 20 200 604 minecraft:moss_block
fill 26 198 613 26 205 613 minecraft:dirt
fill 27 198 611 27 205 612 minecraft:dirt
fill 30 198 646 30 200 646 minecraft:moss_block
fill 34 198 604 34 204 604 minecraft:blue_concrete
fill 36 198 604 36 200 604 minecraft:moss_block
setblock 42 198 610 minecraft:white_concrete
fill 42 198 614 42 200 614 minecraft:moss_block
fill 42 198 630 42 200 630 minecraft:moss_block
fill 8 199 604 8 218 604 minecraft:blue_concrete
fill 24 199 611 24 205 612 minecraft:dirt
fill 25 199 610 27 205 610 minecraft:dirt
fill 25 199 613 25 205 613 minecraft:dirt
fill 27 199 613 27 205 613 minecraft:dirt
fill 42 199 610 42 218 610 minecraft:blue_concrete
setblock 0 200 613 minecraft:diamond_block
setblock 3 200 607 minecraft:light[level=14]
setblock 3 200 615 minecraft:light[level=14]
setblock 3 200 623 minecraft:light[level=14]
setblock 3 200 631 minecraft:light[level=14]
setblock 3 200 639 minecraft:light[level=14]
setblock 11 200 607 minecraft:light[level=14]
setblock 11 200 615 minecraft:light[level=14]
setblock 11 200 623 minecraft:light[level=14]
setblock 11 200 631 minecraft:light[level=14]
setblock 11 200 639 minecraft:light[level=14]
setblock 19 200 607 minecraft:light[level=14]
setblock 19 200 615 minecraft:light[level=14]
setblock 19 200 623 minecraft:light[level=14]
setblock 19 200 631 minecraft:light[level=14]
setblock 19 200 639 minecraft:light[level=14]
fill 24 200 610 24 205 610 minecraft:dirt
fill 24 200 613 24 205 613 minecraft:dirt
setblock 27 200 607 minecraft:light[level=14]
setblock 27 200 615 minecraft:light[level=14]
setblock 27 200 623 minecraft:light[level=14]
setblock 27 200 631 minecraft:light[level=14]
setblock 27 200 639 minecraft:light[level=14]
fill 28 200 611 28 205 612 minecraft:dirt
setblock 35 200 607 minecraft:light[level=14]
setblock 35 200 615 minecraft:light[level=14]
setblock 35 200 623 minecraft:light[level=14]
setblock 35 200 631 minecraft:light[level=14]
setblock 35 200 639 minecraft:light[level=14]
fill 42 200 644 42 218 644 minecraft:blue_concrete
setblock 42 200 645 minecraft:glowstone
fill 0 201 612 0 206 613 minecraft:blue_concrete
fill 0 201 628 0 206 628 minecraft:blue_concrete
fill 0 201 644 0 206 644 minecraft:blue_concrete
fill 4 201 604 4 206 604 minecraft:blue_concrete
fill 14 201 646 14 206 646 minecraft:blue_concrete
fill 20 201 604 20 206 604 minecraft:blue_concrete
fill 23 201 611 23 205 612 minecraft:dirt
fill 25 201 609 27 205 609 minecraft:dirt
fill 25 201 614 27 205 614 minecraft:dirt
fill 28 201 610 28 205 610 minecraft:dirt
fill 28 201 613 28 205 613 minecraft:dirt
fill 30 201 646 30 206 646 minecraft:blue_concrete
fill 36 201 604 36 206 604 minecraft:blue_concrete
fill 42 201 614 42 206 614 minecraft:blue_concrete
fill 42 201 630 42 206 630 minecraft:blue_concrete
fill 42 201 645 42 219 645 minecraft:blue_concrete
setblock 0 202 618 minecraft:diamond_block
setblock 1 202 646 minecraft:glowstone
setblock 4 202 646 minecraft:glowstone
fill 23 202 610 23 205 610 minecraft:dirt
fill 23 202 613 23 205 613 minecraft:dirt
fill 24 202 609 24 205 609 minecraft:dirt
fill 24 202 614 24 205 614 minecraft:dirt
fill 28 202 609 28 205 609 minecraft:dirt
fill 28 202 614 28 205 614 minecraft:dirt
fill 29 202 611 29 205 612 minecraft:dirt
fill 33 202 644 33 205 644 minecraft:diamond_block
setblock 35 202 646 minecraft:diamond_block
setblock 42 202 643 minecraft:white_concrete
fill 0 203 618 0 214 618 minecraft:blue_concrete
fill 1 203 646 1 218 646 minecraft:blue_concrete
fill 4 203 646 4 218 646 minecraft:blue_concrete
setblock 12 203 604 minecraft:glowstone
fill 22 203 611 22 205 612 minecraft:dirt
setblock 23 203 604 minecraft:diamond_block
fill 23 203 609 23 205 609 minecraft:dirt
fill 23 203 614 23 205 614 minecraft:dirt
fill 25 203 608 27 205 608 minecraft:dirt
fill 25 203 615 27 205 615 minecraft:dirt
fill 29 203 610 29 205 610 minecraft:dirt
fill 29 203 613 29 205 613 minecraft:dirt
fill 32 203 643 32 204 645 minecraft:diamond_block
fill 33 203 643 34 204 643 minecraft:diamond_block
fill 33 203 645 34 204 645 minecraft:diamond_block
fill 34 203 644 34 204 644 minecraft:diamond_block
fill 35 203 646 35 218 646 minecraft:blue_concrete
fill 42 203 622 42 203 623 minecraft:diamond_block
fill 42 203 624 42 204 624 minecraft:blue_concrete
fill 42 203 643 42 216 643 minecraft:blue_concrete
setblock 0 204 626 minecraft:white_concrete
fill 12 204 604 12 218 604 minecraft:blue_concrete
fill 22 204 610 22 205 610 minecraft:dirt
fill 22 204 613 22 205 613 minecraft:dirt
fill 23 204 604 23 218 604 minecraft:blue_concrete
fill 24 204 608 24 205 608 minecraft:dirt
fill 24 204 615 24 205 615 minecraft:dirt
fill 28 204 608 28 205 608 minecraft:dirt
fill 28 204 615 28 205 615 minecraft:dirt
fill 29 204 609 29 205 609 minecraft:dirt
fill 29 204 614 29 205 614 minecraft:dirt
fill 30 204 611 30 205 613 minecraft:dirt
fill 32 204 642 34 204 642 minecraft:diamond_block
fill 42 204 622 42 214 623 minecraft:blue_concrete
fill 0 205 626 0 215 626 minecraft:blue_concrete
fill 21 205 611 21 205 612 minecraft:dirt
setblock 22 205 609 minecraft:dirt
setblock 22 205 614 minecraft:dirt
setblock 23 205 608 minecraft:dirt
setblock 23 205 615 minecraft:dirt
fill 24 205 607 27 205 607 minecraft:dirt
fill 24 205 616 27 205 616 minecraft:dirt
setblock 29 205 608 minecraft:dirt
setblock 29 205 615 minecraft:dirt
fill 30 205 609 30 205 610 minecraft:dirt
setblock 30 205 614 minecraft:dirt
fill 33 205 641 33 205 643 minecraft:diamond_block
setblock 34 205 604 minecraft:glowstone
setblock 42 205 612 minecraft:diamond_block
setblock 42 205 624 minecraft:glowstone
setblock 0 206 609 minecraft:white_concrete
fill 25 206 637 26 207 637 minecraft:coal_block
setblock 25 206 646 minecraft:glowstone
fill 26 206 611 26 208 612 minecraft:stone
fill 33 206 631 34 207 632 minecraft:coal_block
setblock 33 206 640 minecraft:diamond_block
fill 34 206 604 34 219 604 minecraft:blue_concrete
setblock 35 206 604 minecraft:glowstone
fill 35 206 631 35 207 631 minecraft:coal_block
fill 42 206 612 42 215 612 minecraft:blue_concrete
fill 42 206 624 42 216 624 minecraft:blue_concrete
fill 0 207 609 0 216 609 minecraft:blue_concrete
fill 0 207 612 0 209 612 minecraft:moss_block
fill 0 207 613 0 208 613 minecraft:blue_concrete
fill 0 207 628 0 209 628 minecraft:moss_block
fill 0 207 644 0 209 644 minecraft:moss_block
fill 4 207 604 4 209 604 minecraft:moss_block
fill 14 207 646 14 209 646 minecraft:moss_block
fill 20 207 604 20 209 604 minecraft:moss_block
fill 25 207 646 25 218 646 minecraft:blue_concrete
setblock 27 207 604 minecraft:white_concrete
fill 30 207 646 30 209 646 minecraft:moss_block
fill 35 207 604 35 218 604 minecraft:blue_concrete
fill 36 207 604 36 209 604 minecraft:moss_block
setblock 40 207 604 minecraft:glowstone
fill 42 207 614 42 209 614 minecraft:moss_block
setblock 42 207 618 minecraft:diamond_block
fill 42 207 630 42 209 630 minecraft:moss_block
fill 42 207 631 42 214 631 minecraft:blue_concrete
setblock 42 207 632 minecraft:diamond_block
fill 42 207 633 42 216 634 minecraft:blue_concrete
setblock 3 208 607 minecraft:light[level=14]
setblock 3 208 615 minecraft:light[level=14]
setblock 3 208 623 minecraft:light[level=14]
setblock 3 208 631 minecraft:light[level=14]
setblock 3 208 639 minecraft:light[level=14]
setblock 11 208 607 minecraft:light[level=14]
setblock 11 208 615 minecraft:light[level=14]
setblock 11 208 623 minecraft:light[level=14]
setblock 11 208 631 minecraft:light[level=14]
setblock 11 208 639 minecraft:light[level=14]
setblock 19 208 607 minecraft:light[level=14]
setblock 19 208 615 minecraft:light[level=14]
setblock 19 208 623 minecraft:light[level=14]
setblock 19 208 631 minecraft:light[level=14]
setblock 19 208 639 minecraft:light[level=14]
fill 27 208 604 27 219 604 minecraft:blue_concrete
setblock 27 208 607 minecraft:light[level=14]
setblock 27 208 615 minecraft:light[level=14]
setblock 27 208 623 minecraft:light[level=14]
setblock 27 208 631 minecraft:light[level=14]
setblock 27 208 639 minecraft:light[level=14]
setblock 35 208 607 minecraft:light[level=14]
setblock 35 208 615 minecraft:light[level=14]
setblock 35 208 623 minecraft:light[level=14]
setblock 35 208 631 minecraft:light[level=14]
setblock 35 208 639 minecraft:light[level=14]
fill 40 208 604 40 214 604 minecraft:blue_concrete
fill 42 208 618 42 218 618 minecraft:blue_concrete
fill 42 208 632 42 218 632 minecraft:blue_concrete
setblock 0 209 613 minecraft:glowstone
fill 24 209 611 27 211 612 minecraft:oak_leaves[persistent=true]
fill 25 209 610 27 211 610 minecraft:oak_leaves[persistent=true]
fill 25 209 613 27 211 613 minecraft:oak_leaves[persistent=true]
fill 0 210 612 0 218 613 minecraft:blue_concrete
fill 0 210 628 0 218 628 minecraft:blue_concrete
setblock 0 210 636 minecraft:glowstone
setblock 0 210 638 minecraft:white_concrete
fill 0 210 639 0 218 639 minecraft:blue_concrete
fill 0 210 644 0 211 644 minecraft:blue_concrete
setblock 4 210 604 minecraft:blue_concrete
fill 14 210 646 14 216 646 minecraft:blue_concrete
fill 20 210 604 20 216 604 minecraft:blue_concrete
fill 23 210 644 25 213 644 minecraft:diamond_block
setblock 24 210 610 minecraft:oak_leaves[persistent=true]
setblock 24 210 613 minecraft:oak_leaves[persistent=true]
fill 24 210 643 24 213 643 minecraft:diamond_block
fill 24 210 645 24 213 645 minecraft:diamond_block
fill 28 210 611 28 210 612 minecraft:oak_leaves[persistent=true]
fill 30 210 646 30 214 646 minecraft:blue_concrete
fill 36 210 604 36 214 604 minecraft:blue_concrete
fill 38 210 646 38 218 646 minecraft:blue_concrete
setblock 39 210 646 minecraft:diamond_block
fill 42 210 614 42 216 614 minecraft:blue_concrete
fill 42 210 630 42 218 630 minecraft:blue_concrete
fill 0 211 636 0 218 636 minecraft:blue_concrete
fill 0 211 638 0 214 638 minecraft:blue_concrete
setblock 4 211 604 minecraft:white_concrete
fill 23 211 642 23 212 643 minecraft:diamond_block
fill 23 211 645 23 212 645 minecraft:diamond_block
fill 24 211 641 24 212 642 minecraft:diamond_block
fill 25 211 642 25 212 643 minecraft:diamond_block
fill 25 211 645 25 212 645 minecraft:diamond_block
fill 34 211 638 35 212 638 minecraft:raw_iron_block
fill 35 211 637 35 212 637 minecraft:raw_iron_block
fill 35 211 639 35 212 639 minecraft:raw_iron_block
setblock 39 211 604 minecraft:glowstone
fill 39 211 646 39 214 646 minecraft:blue_concrete
setblock 0 212 610 minecraft:white_concrete
setblock 0 212 621 minecraft:diamond_block
setblock 0 212 644 minecraft:diamond_block
fill 4 212 604 4 218 604 minecraft:blue_concrete
setblock 23 212 641 minecraft:diamond_block
fill 24 212 639 24 212 640 minecraft:diamond_block
setblock 25 212 641 minecraft:diamond_block
setblock 39 212 604 minecraft:blue_concrete
setblock 42 212 609 minecraft:white_concrete
fill 0 213 610 0 218 610 minecraft:blue_concrete
fill 0 213 621 0 216 621 minecraft:blue_concrete
fill 0 213 644 0 218 644 minecraft:blue_concrete
setblock 24 213 604 minecraft:glowstone
setblock 39 213 604 minecraft:diamond_block
fill 42 213 609 42 215 609 minecraft:blue_concrete
setblock 16 214 646 minecraft:glowstone
fill 24 214 604 24 216 604 minecraft:blue_concrete
fill 39 214 604 39 218 604 minecraft:blue_concrete
setblock 42 214 638 minecraft:glowstone
setblock 42 214 639 minecraft:blue_concrete
setblock 0 215 618 minecraft:black_concrete
setblock 0 215 638 minecraft:black_concrete
setblock 0 215 640 minecraft:black_concrete
fill 16 215 646 16 218 646 minecraft:blue_concrete
setblock 19 215 604 minecraft:black_concrete
setblock 30 215 646 minecraft:black_concrete
setblock 33 215 646 minecraft:black_concrete
fill 34 215 646 34 218 646 minecraft:blue_concrete
setblock 36 215 604 minecraft:black_concrete
setblock 37 215 646 minecraft:black_concrete
setblock 39 215 646 minecraft:black_concrete
setblock 40 215 604 minecraft:black_concrete
setblock 42 215 622 minecraft:black_concrete
fill 42 215 623 42 218 623 minecraft:blue_concrete
fill 42 215 625 42 216 625 minecraft:black_concrete
fill 42 215 631 42 216 631 minecraft:black_concrete
fill 42 215 638 42 218 638 minecraft:blue_concrete
setblock 42 215 639 minecraft:glowstone
setblock 0 216 604 minecraft:black_concrete
fill 0 216 605 0 218 605 minecraft:blue_concrete
setblock 0 216 607 minecraft:black_concrete
fill 0 216 618 0 218 618 minecraft:blue_concrete
setblock 0 216 626 minecraft:black_concrete
fill 0 216 638 0 218 638 minecraft:blue_concrete
setblock 0 216 640 minecraft:blue_concrete
setblock 3 216 607 minecraft:light[level=14]
setblock 3 216 615 minecraft:light[level=14]
setblock 3 216 623 minecraft:light[level=14]
setblock 3 216 631 minecraft:light[level=14]
setblock 3 216 639 minecraft:light[level=14]
setblock 11 216 607 minecraft:light[level=14]
setblock 11 216 615 minecraft:light[level=14]
setblock 11 216 623 minecraft:light[level=14]
setblock 11 216 631 minecraft:light[level=14]
setblock 11 216 639 minecraft:light[level=14]
setblock 15 216 646 minecraft:black_concrete
fill 19 216 604 19 218 604 minecraft:blue_concrete
setblock 19 216 607 minecraft:light[level=14]
setblock 19 216 615 minecraft:light[level=14]
setblock 19 216 623 minecraft:light[level=14]
setblock 19 216 631 minecraft:light[level=14]
setblock 19 216 639 minecraft:light[level=14]
setblock 19 216 646 minecraft:black_concrete
fill 20 216 646 20 218 646 minecraft:blue_concrete
setblock 22 216 604 minecraft:black_concrete
setblock 24 216 646 minecraft:black_concrete
setblock 26 216 604 minecraft:black_concrete
setblock 27 216 607 minecraft:light[level=14]
setblock 27 216 615 minecraft:light[level=14]
setblock 27 216 623 minecraft:light[level=14]
setblock 27 216 631 minecraft:light[level=14]
setblock 27 216 639 minecraft:light[level=14]
setblock 27 216 646 minecraft:black_concrete
fill 28 216 604 29 216 604 minecraft:black_concrete
setblock 30 216 604 minecraft:diamond_block
fill 30 216 646 30 218 646 minecraft:blue_concrete
setblock 31 216 604 minecraft:blue_concrete
setblock 33 216 604 minecraft:black_concrete
fill 33 216 646 33 218 646 minecraft:blue_concrete
setblock 35 216 607 minecraft:light[level=14]
setblock 35 216 615 minecraft:light[level=14]
setblock 35 216 623 minecraft:light[level=14]
setblock 35 216 631 minecraft:light[level=14]
setblock 35 216 639 minecraft:light[level=14]
setblock 36 216 604 minecraft:blue_concrete
fill 37 216 646 37 218 646 minecraft:blue_concrete
fill 39 216 646 39 218 646 minecraft:blue_concrete
fill 40 216 604 40 218 604 minecraft:blue_concrete
setblock 42 216 606 minecraft:black_concrete
setblock 42 216 609 minecraft:black_concrete
setblock 42 216 612 minecraft:white_concrete
setblock 42 216 617 minecraft:black_concrete
fill 42 216 622 42 218 622 minecraft:blue_concrete
fill 42 216 639 42 218 639 minecraft:blue_concrete
fill 42 216 641 42 217 641 minecraft:black_concrete
fill 0 217 604 0 218 604 minecraft:blue_concrete
setblock 0 217 606 minecraft:black_concrete
fill 0 217 607 0 218 607 minecraft:blue_concrete
setblock 0 217 609 minecraft:black_concrete
setblock 0 217 621 minecraft:black_concrete
fill 0 217 626 0 218 626 minecraft:blue_concrete
setblock 0 217 630 minecraft:black_concrete
setblock 0 217 631 minecraft:glowstone
setblock 0 217 640 minecraft:black_concrete
setblock 0 217 646 minecraft:black_concrete
setblock 11 217 604 minecraft:black_concrete
setblock 14 217 646 minecraft:black_concrete
fill 15 217 646 15 218 646 minecraft:blue_concrete
fill 19 217 646 19 218 646 minecraft:blue_concrete
setblock 20 217 604 minecraft:black_concrete
fill 22 217 604 22 218 604 minecraft:blue_concrete
setblock 24 217 604 minecraft:black_concrete
fill 24 217 646 24 218 646 minecraft:blue_concrete
fill 26 217 604 26 218 604 minecraft:blue_concrete
setblock 26 217 646 minecraft:black_concrete
fill 27 217 646 27 218 646 minecraft:blue_concrete
fill 28 217 604 30 218 604 minecraft:blue_concrete
setblock 31 217 604 minecraft:black_concrete
fill 33 217 604 33 218 604 minecraft:blue_concrete
setblock 36 217 604 minecraft:black_concrete
setblock 41 217 604 minecraft:black_concrete
fill 42 217 606 42 220 606 minecraft:blue_concrete
fill 42 217 609 42 218 609 minecraft:blue_concrete
fill 42 217 612 42 218 612 minecraft:blue_concrete
fill 42 217 613 42 217 614 minecraft:black_concrete
fill 42 217 617 42 218 617 minecraft:blue_concrete
setblock 42 217 621 minecraft:black_concrete
setblock 42 217 624 minecraft:glowstone
fill 42 217 625 42 218 625 minecraft:blue_concrete
fill 42 217 631 42 218 631 minecraft:blue_concrete
fill 42 217 633 42 218 633 minecraft:blue_concrete
setblock 42 217 634 minecraft:glowstone
setblock 42 217 643 minecraft:black_concrete
setblock 0 218 606 minecraft:blue_concrete
setblock 0 218 609 minecraft:blue_concrete
setblock 0 218 621 minecraft:blue_concrete
fill 0 218 630 0 218 631 minecraft:blue_concrete
fill 0 218 640 0 220 640 minecraft:blue_concrete
setblock 0 218 646 minecraft:blue_concrete
setblock 11 218 604 minecraft:blue_concrete
setblock 14 218 646 minecraft:blue_concrete
fill 20 218 604 20 219 604 minecraft:blue_concrete
setblock 24 218 604 minecraft:blue_concrete
setblock 26 218 646 minecraft:blue_concrete
setblock 31 218 604 minecraft:blue_concrete
setblock 36 218 604 minecraft:blue_concrete
fill 41 218 604 41 219 604 minecraft:blue_concrete
fill 42 218 613 42 218 614 minecraft:blue_concrete
setblock 42 218 621 minecraft:blue_concrete
setblock 42 218 624 minecraft:blue_concrete
setblock 42 218 634 minecraft:blue_concrete
setblock 42 218 641 minecraft:blue_concrete
setblock 42 218 642 minecraft:white_concrete
setblock 42 218 643 minecraft:blue_concrete
fill 0 219 604 19 219 604 minecraft:black_concrete
setblock 0 219 605 minecraft:white_concrete
fill 0 219 606 0 219 618 minecraft:black_concrete
fill 0 219 620 0 219 622 minecraft:black_concrete
fill 0 219 624 0 220 630 minecraft:black_concrete
setblock 0 219 631 minecraft:white_concrete
fill 0 219 633 0 219 637 minecraft:black_concrete
setblock 0 219 638 minecraft:diamond_block
fill 0 219 639 0 305 639 minecraft:black_concrete
fill 0 219 641 0 219 646 minecraft:black_concrete
fill 1 219 646 10 219 646 minecraft:black_concrete
setblock 11 219 646 minecraft:glowstone
fill 13 219 646 28 219 646 minecraft:black_concrete
fill 14 219 624 16 219 626 minecraft:redstone_block
fill 19 219 629 21 219 631 minecraft:redstone_block
fill 21 219 604 26 220 604 minecraft:black_concrete
fill 22 219 620 24 219 622 minecraft:redstone_block
fill 24 219 625 26 219 627 minecraft:redstone_block
fill 28 219 604 33 220 604 minecraft:black_concrete
setblock 29 219 646 minecraft:blue_concrete
fill 30 219 646 30 224 646 minecraft:black_concrete
fill 32 219 646 42 219 646 minecraft:black_concrete
fill 35 219 604 40 223 604 minecraft:black_concrete
setblock 42 219 605 minecraft:black_concrete
fill 42 219 607 42 219 610 minecraft:black_concrete
fill 42 219 612 42 219 644 minecraft:black_concrete
fill 0 220 604 0 220 609 minecraft:black_concrete
setblock 0 220 610 minecraft:blue_concrete
fill 0 220 611 0 223 612 minecraft:black_concrete
setblock 0 220 613 minecraft:blue_concrete
fill 0 220 614 0 230 621 minecraft:black_concrete
setblock 0 220 622 minecraft:blue_concrete
fill 0 220 631 0 220 635 minecraft:black_concrete
setblock 0 220 636 minecraft:glowstone
fill 0 220 637 0 220 638 minecraft:black_concrete
fill 0 220 641 0 307 641 minecraft:black_concrete
setblock 0 220 642 minecraft:blue_concrete
fill 0 220 643 0 224 644 minecraft:black_concrete
fill 0 220 645 0 221 645 minecraft:blue_concrete
fill 0 220 646 3 220 646 minecraft:black_concrete
fill 1 220 604 6 220 604 minecraft:black_concrete
fill 1 220 605 3 220 608 minecraft:green_terracotta
fill 1 220 609 3 220 612 minecraft:moss_block
fill 1 220 613 3 220 616 minecraft:green_terracotta
fill 1 220 617 3 220 620 minecraft:moss_block
fill 1 220 621 3 220 624 minecraft:green_terracotta
fill 1 220 625 3 220 628 minecraft:moss_block
fill 1 220 629 3 220 632 minecraft:green_terracotta
fill 1 220 633 3 220 636 minecraft:moss_block
fill 1 220 637 3 220 640 minecraft:green_terracotta
fill 1 220 641 3 220 644 minecraft:moss_block
fill 1 220 645 3 220 645 minecraft:green_terracotta
fill 4 220 605 7 220 608 minecraft:moss_block
fill 4 220 609 7 220 612 minecraft:green_terracotta
fill 4 220 613 7 220 616 minecraft:moss_block
fill 4 220 617 7 220 620 minecraft:green_terracotta
fill 4 220 621 7 220 624 minecraft:moss_block
fill 4 220 625 7 220 628 minecraft:green_terracotta
fill 4 220 629 7 220 632 minecraft:moss_block
fill 4 220 633 7 220 636 minecraft:green_terracotta
fill 4 220 637 7 220 640 minecraft:moss_block
fill 4 220 641 7 220 644 minecraft:green_terracotta
fill 4 220 645 7 220 645 minecraft:moss_block
setblock 4 220 646 minecraft:blue_concrete
fill 5 220 646 6 240 646 minecraft:black_concrete
setblock 7 220 604 minecraft:diamond_block
setblock 7 220 646 minecraft:blue_concrete
fill 8 220 604 9 220 604 minecraft:black_concrete
fill 8 220 605 11 220 608 minecraft:green_terracotta
fill 8 220 609 11 220 612 minecraft:moss_block
fill 8 220 613 11 220 616 minecraft:green_terracotta
fill 8 220 617 11 220 620 minecraft:moss_block
fill 8 220 621 11 220 624 minecraft:green_terracotta
fill 8 220 625 11 220 628 minecraft:moss_block
fill 8 220 629 11 220 632 minecraft:green_terracotta
fill 8 220 633 11 220 636 minecraft:moss_block
fill 8 220 637 11 220 640 minecraft:green_terracotta
fill 8 220 641 11 220 644 minecraft:moss_block
fill 8 220 645 11 220 645 minecraft:green_terracotta
fill 8 220 646 25 220 646 minecraft:black_concrete
setblock 10 220 604 minecraft:blue_concrete
fill 11 220 604 11 307 604 minecraft:black_concrete
setblock 12 220 604 minecraft:blue_concrete
fill 12 220 605 15 220 608 minecraft:moss_block
fill 12 220 609 15 220 612 minecraft:green_terracotta
fill 12 220 613 15 220 616 minecraft:moss_block
fill 12 220 617 15 220 620 minecraft:green_terracotta
fill 12 220 621 13 220 624 minecraft:moss_block
fill 12 220 625 13 220 628 minecraft:green_terracotta
fill 12 220 629 15 220 632 minecraft:moss_block
fill 12 220 633 15 220 636 minecraft:green_terracotta
fill 12 220 637 15 220 640 minecraft:moss_block
fill 12 220 641 15 220 644 minecraft:green_terracotta
fill 12 220 645 15 220 645 minecraft:moss_block
fill 13 220 604 20 220 604 minecraft:black_concrete
fill 14 220 621 15 220 623 minecraft:moss_block
fill 14 220 627 15 220 628 minecraft:green_terracotta
fill 16 220 605 19 220 608 minecraft:green_terracotta
fill 16 220 609 19 220 612 minecraft:moss_block
fill 16 220 613 19 220 616 minecraft:green_terracotta
fill 16 220 617 19 220 620 minecraft:moss_block
fill 16 220 621 19 220 623 minecraft:green_terracotta
fill 16 220 627 19 220 628 minecraft:moss_block
fill 16 220 629 18 220 632 minecraft:green_terracotta
fill 16 220 633 19 220 636 minecraft:moss_block
fill 16 220 637 19 220 640 minecraft:green_terracotta
fill 16 220 641 19 220 644 minecraft:moss_block
fill 16 220 645 19 220 645 minecraft:green_terracotta
fill 17 220 624 18 220 624 minecraft:green_terracotta
fill 17 220 625 18 220 626 minecraft:moss_block
setblock 19 220 632 minecraft:green_terracotta
fill 20 220 605 23 220 608 minecraft:moss_block
fill 20 220 609 23 220 612 minecraft:green_terracotta
fill 20 220 613 23 220 616 minecraft:moss_block
fill 20 220 617 21 220 620 minecraft:green_terracotta
fill 20 220 621 21 220 623 minecraft:moss_block
fill 20 220 627 23 220 628 minecraft:green_terracotta
fill 20 220 632 23 220 632 minecraft:moss_block
fill 20 220 633 23 220 636 minecraft:green_terracotta
fill 20 220 637 23 220 640 minecraft:moss_block
fill 20 220 641 23 220 644 minecraft:green_terracotta
fill 20 220 645 23 220 645 minecraft:moss_block
fill 22 220 617 23 220 619 minecraft:green_terracotta
fill 22 220 623 23 220 624 minecraft:moss_block
fill 22 220 625 23 220 626 minecraft:green_terracotta
fill 22 220 629 23 220 631 minecraft:moss_block
fill 24 220 605 27 220 608 minecraft:green_terracotta
fill 24 220 609 27 220 612 minecraft:moss_block
fill 24 220 613 27 220 616 minecraft:green_terracotta
fill 24 220 617 27 220 619 minecraft:moss_block
fill 24 220 623 27 220 624 minecraft:green_terracotta
fill 24 220 628 27 220 628 minecraft:moss_block
fill 24 220 629 27 220 632 minecraft:green_terracotta
fill 24 220 633 27 220 636 minecraft:moss_block
fill 24 220 637 27 220 640 minecraft:green_terracotta
fill 24 220 641 27 220 644 minecraft:moss_block
fill 24 220 645 27 220 645 minecraft:green_terracotta
fill 25 220 620 27 220 620 minecraft:moss_block
fill 25 220 621 27 220 622 minecraft:green_terracotta
fill 26 220 646 28 220 646 minecraft:blue_concrete
fill 27 220 604 27 307 604 minecraft:black_concrete
fill 27 220 625 27 220 627 minecraft:moss_block
fill 28 220 605 31 220 608 minecraft:moss_block
fill 28 220 609 31 220 612 minecraft:green_terracotta
fill 28 220 613 31 220 616 minecraft:moss_block
fill 28 220 617 31 220 620 minecraft:green_terracotta
fill 28 220 621 31 220 624 minecraft:moss_block
fill 28 220 625 31 220 628 minecraft:green_terracotta
fill 28 220 629 31 220 632 minecraft:moss_block
fill 28 220 633 31 220 636 minecraft:green_terracotta
fill 28 220 637 31 220 640 minecraft:moss_block
fill 28 220 641 31 220 644 minecraft:green_terracotta
fill 28 220 645 31 220 645 minecraft:moss_block
fill 29 220 646 29 307 646 minecraft:black_concrete
fill 31 220 646 36 226 646 minecraft:black_concrete
fill 32 220 605 35 220 608 minecraft:green_terracotta
fill 32 220 609 35 220 612 minecraft:moss_block
fill 32 220 613 35 220 616 minecraft:green_terracotta
fill 32 220 617 35 220 620 minecraft:moss_block
fill 32 220 621 35 220 624 minecraft:green_terracotta
fill 32 220 625 35 220 628 minecraft:moss_block
fill 32 220 629 35 220 632 minecraft:green_terracotta
fill 32 220 633 35 220 636 minecraft:moss_block
fill 32 220 637 35 220 640 minecraft:green_terracotta
fill 32 220 641 35 220 644 minecraft:moss_block
fill 32 220 645 35 220 645 minecraft:green_terracotta
fill 34 220 604 34 247 604 minecraft:black_concrete
fill 36 220 605 39 220 608 minecraft:moss_block
fill 36 220 609 39 220 612 minecraft:green_terracotta
fill 36 220 613 39 220 616 minecraft:moss_block
fill 36 220 617 39 220 620 minecraft:green_terracotta
fill 36 220 621 39 220 624 minecraft:moss_block
fill 36 220 625 39 220 628 minecraft:green_terracotta
fill 36 220 629 39 220 632 minecraft:moss_block
fill 36 220 633 39 220 636 minecraft:green_terracotta
fill 36 220 637 39 220 640 minecraft:moss_block
fill 36 220 641 39 220 644 minecraft:green_terracotta
fill 36 220 645 39 220 645 minecraft:moss_block
setblock 37 220 646 minecraft:glowstone
fill 38 220 646 38 221 646 minecraft:blue_concrete
fill 39 220 646 41 231 646 minecraft:black_concrete
fill 40 220 605 41 220 608 minecraft:green_terracotta
fill 40 220 609 41 220 612 minecraft:moss_block
fill 40 220 613 41 220 616 minecraft:green_terracotta
fill 40 220 617 41 220 620 minecraft:moss_block
fill 40 220 621 41 220 624 minecraft:green_terracotta
fill 40 220 625 41 220 628 minecraft:moss_block
fill 40 220 629 41 220 632 minecraft:green_terracotta
fill 40 220 633 41 220 636 minecraft:moss_block
fill 40 220 637 41 220 640 minecraft:green_terracotta
fill 40 220 641 41 220 644 minecraft:moss_block
fill 40 220 645 41 220 645 minecraft:green_terracotta
fill 41 220 604 42 222 604 minecraft:black_concrete
setblock 42 220 605 minecraft:blue_concrete
fill 42 220 607 42 227 608 minecraft:black_concrete
fill 42 220 609 42 221 609 minecraft:blue_concrete
fill 42 220 610 42 223 611 minecraft:black_concrete
setblock 42 220 612 minecraft:diamond_block
fill 42 220 613 42 220 628 minecraft:black_concrete
setblock 42 220 629 minecraft:blue_concrete
fill 42 220 630 42 220 645 minecraft:black_concrete
setblock 42 220 646 minecraft:blue_concrete
fill 0 221 604 0 221 606 minecraft:black_concrete
setblock 0 221 607 minecraft:blue_concrete
fill 0 221 608 0 231 610 minecraft:black_concrete
fill 0 221 613 0 255 613 minecraft:black_concrete
fill 0 221 622 0 243 625 minecraft:black_concrete
setblock 0 221 626 minecraft:blue_concrete
fill 0 221 627 0 224 632 minecraft:black_concrete
setblock 0 221 633 minecraft:blue_concrete
fill 0 221 634 0 247 636 minecraft:black_concrete
setblock 0 221 637 minecraft:blue_concrete
fill 0 221 638 0 293 638 minecraft:black_concrete
fill 0 221 640 0 307 640 minecraft:black_concrete
fill 0 221 642 0 307 642 minecraft:black_concrete
setblock 0 221 646 minecraft:blue_concrete
fill 1 221 604 3 233 604 minecraft:black_concrete
fill 1 221 605 41 221 605 minecraft:dirt
fill 1 221 606 3 221 608 minecraft:green_terracotta
fill 1 221 609 41 221 609 minecraft:dirt
fill 1 221 610 3 221 612 minecraft:moss_block
fill 1 221 613 41 221 613 minecraft:dirt
fill 1 221 614 3 221 616 minecraft:green_terracotta
fill 1 221 617 41 221 617 minecraft:dirt
fill 1 221 618 3 221 620 minecraft:moss_block
fill 1 221 621 20 221 621 minecraft:dirt
fill 1 221 622 3 221 624 minecraft:green_terracotta
fill 1 221 625 12 221 625 minecraft:dirt
fill 1 221 626 3 221 628 minecraft:moss_block
fill 1 221 629 17 221 629 minecraft:dirt
fill 1 221 630 3 221 632 minecraft:green_terracotta
fill 1 221 633 41 221 633 minecraft:dirt
fill 1 221 634 3 221 636 minecraft:moss_block
fill 1 221 637 41 221 637 minecraft:dirt
fill 1 221 638 3 221 640 minecraft:green_terracotta
fill 1 221 641 41 221 641 minecraft:dirt
fill 1 221 642 3 221 644 minecraft:moss_block
fill 1 221 645 41 221 645 minecraft:dirt
fill 1 221 646 1 257 646 minecraft:black_concrete
fill 2 221 646 3 221 646 minecraft:blue_concrete
setblock 4 221 604 minecraft:blue_concrete
fill 4 221 606 4 221 608 minecraft:dirt
fill 4 221 610 4 221 612 minecraft:dirt
fill 4 221 614 4 221 616 minecraft:dirt
fill 4 221 618 4 221 620 minecraft:dirt
fill 4 221 622 4 221 624 minecraft:dirt
fill 4 221 626 4 221 628 minecraft:dirt
fill 4 221 630 4 221 632 minecraft:dirt
fill 4 221 634 4 221 636 minecraft:dirt
fill 4 221 638 4 221 640 minecraft:dirt
fill 4 221 642 4 221 644 minecraft:dirt
fill 4 221 646 4 307 646 minecraft:black_concrete
fill 5 221 604 7 265 604 minecraft:black_concrete
fill 5 221 606 7 221 608 minecraft:moss_block
fill 5 221 610 7 221 612 minecraft:green_terracotta
fill 5 221 614 7 221 616 minecraft:moss_block
fill 5 221 618 7 221 620 minecraft:green_terracotta
fill 5 221 622 7 221 624 minecraft:moss_block
fill 5 221 626 7 221 628 minecraft:green_terracotta
fill 5 221 630 7 221 632 minecraft:moss_block
fill 5 221 634 7 221 636 minecraft:green_terracotta
fill 5 221 638 7 221 640 minecraft:moss_block
fill 5 221 642 7 221 644 minecraft:green_terracotta
fill 7 221 646 9 241 646 minecraft:black_concrete
setblock 8 221 604 minecraft:blue_concrete
fill 8 221 606 8 221 608 minecraft:dirt
fill 8 221 610 8 221 612 minecraft:dirt
fill 8 221 614 8 221 616 minecraft:dirt
fill 8 221 618 8 221 620 minecraft:dirt
fill 8 221 622 8 221 624 minecraft:dirt
fill 8 221 626 8 221 628 minecraft:dirt
fill 8 221 630 8 221 632 minecraft:dirt
fill 8 221 634 8 221 636 minecraft:dirt
fill 8 221 638 8 221 640 minecraft:dirt
fill 8 221 642 8 221 644 minecraft:dirt
fill 9 221 604 10 229 604 minecraft:black_concrete
fill 9 221 606 11 221 608 minecraft:green_terracotta
fill 9 221 610 11 221 612 minecraft:moss_block
fill 9 221 614 11 221 616 minecraft:green_terracotta
fill 9 221 618 11 221 620 minecraft:moss_block
fill 9 221 622 11 221 624 minecraft:green_terracotta
fill 9 221 626 11 221 628 minecraft:moss_block
fill 9 221 630 11 221 632 minecraft:green_terracotta
fill 9 221 634 11 221 636 minecraft:moss_block
fill 9 221 638 11 221 640 minecraft:green_terracotta
fill 9 221 642 11 221 644 minecraft:moss_block
setblock 10 221 646 minecraft:blue_concrete
fill 11 221 646 24 222 646 minecraft:black_concrete
setblock 12 221 604 minecraft:white_concrete
fill 12 221 606 12 221 608 minecraft:dirt
fill 12 221 610 12 221 612 minecraft:dirt
fill 12 221 614 12 221 616 minecraft:dirt
fill 12 221 618 12 221 620 minecraft:dirt
fill 12 221 622 12 221 624 minecraft:dirt
fill 12 221 626 12 221 628 minecraft:dirt
fill 12 221 630 12 221 632 minecraft:dirt
fill 12 221 634 12 221 636 minecraft:dirt
fill 12 221 638 12 221 640 minecraft:dirt
fill 12 221 642 12 221 644 minecraft:dirt
setblock 13 221 604 minecraft:blue_concrete
fill 13 221 606 15 221 608 minecraft:moss_block
fill 13 221 610 15 221 612 minecraft:green_terracotta
fill 13 221 614 15 221 616 minecraft:moss_block
fill 13 221 618 15 221 620 minecraft:green_terracotta
fill 13 221 622 15 221 622 minecraft:moss_block
fill 13 221 623 13 221 627 minecraft:glowstone
fill 13 221 628 15 221 628 minecraft:green_terracotta
fill 13 221 630 15 221 632 minecraft:moss_block
fill 13 221 634 15 221 636 minecraft:green_terracotta
fill 13 221 638 15 221 640 minecraft:moss_block
fill 13 221 642 15 221 644 minecraft:green_terracotta
fill 14 221 604 23 221 604 minecraft:black_concrete
fill 14 221 623 25 221 623 minecraft:glowstone
fill 14 221 624 16 221 626 minecraft:moss_block
fill 14 221 627 23 221 627 minecraft:glowstone
fill 16 221 606 16 221 608 minecraft:dirt
fill 16 221 610 16 221 612 minecraft:dirt
fill 16 221 614 16 221 616 minecraft:dirt
fill 16 221 618 16 221 620 minecraft:dirt
setblock 16 221 622 minecraft:dirt
setblock 16 221 628 minecraft:dirt
fill 16 221 630 16 221 632 minecraft:dirt
fill 16 221 634 16 221 636 minecraft:dirt
fill 16 221 638 16 221 640 minecraft:dirt
fill 16 221 642 16 221 644 minecraft:dirt
fill 17 221 606 19 221 608 minecraft:green_terracotta
fill 17 221 610 19 221 612 minecraft:moss_block
fill 17 221 614 19 221 616 minecraft:green_terracotta
fill 17 221 618 19 221 620 minecraft:moss_block
fill 17 221 622 19 221 622 minecraft:green_terracotta
fill 17 221 624 18 221 626 minecraft:glowstone
setblock 17 221 628 minecraft:moss_block
fill 17 221 630 17 221 632 minecraft:green_terracotta
fill 17 221 634 19 221 636 minecraft:moss_block
fill 17 221 638 19 221 640 minecraft:green_terracotta
fill 17 221 642 19 221 644 minecraft:moss_block
fill 18 221 628 18 221 632 minecraft:glowstone
fill 19 221 628 27 221 628 minecraft:glowstone
fill 19 221 629 21 221 631 minecraft:moss_block
fill 19 221 632 22 221 632 minecraft:glowstone
fill 20 221 606 20 221 608 minecraft:dirt
fill 20 221 610 20 221 612 minecraft:dirt
fill 20 221 614 20 221 616 minecraft:dirt
fill 20 221 618 20 221 620 minecraft:dirt
setblock 20 221 622 minecraft:dirt
fill 20 221 634 20 221 636 minecraft:dirt
fill 20 221 638 20 221 640 minecraft:dirt
fill 20 221 642 20 221 644 minecraft:dirt
fill 21 221 606 23 221 608 minecraft:moss_block
fill 21 221 610 23 221 612 minecraft:green_terracotta
fill 21 221 614 23 221 616 minecraft:moss_block
fill 21 221 618 23 221 618 minecraft:green_terracotta
fill 21 221 619 21 221 622 minecraft:glowstone
fill 21 221 634 23 221 636 minecraft:green_terracotta
fill 21 221 638 23 221 640 minecraft:moss_block
fill 21 221 642 23 221 644 minecraft:green_terracotta
fill 22 221 619 25 221 619 minecraft:glowstone
fill 22 221 620 24 221 622 minecraft:moss_block
fill 22 221 624 23 221 626 minecraft:glowstone
fill 22 221 629 22 221 631 minecraft:glowstone
fill 23 221 629 41 221 629 minecraft:dirt
fill 23 221 630 23 221 632 minecraft:moss_block
setblock 24 221 604 minecraft:blue_concrete
fill 24 221 606 24 221 608 minecraft:dirt
fill 24 221 610 24 221 612 minecraft:dirt
fill 24 221 614 24 221 616 minecraft:dirt
setblock 24 221 618 minecraft:dirt
fill 24 221 624 27 221 624 minecraft:glowstone
fill 24 221 625 26 221 627 minecraft:moss_block
fill 24 221 630 24 221 632 minecraft:dirt
fill 24 221 634 24 221 636 minecraft:dirt
fill 24 221 638 24 221 640 minecraft:dirt
fill 24 221 642 24 221 644 minecraft:dirt
fill 25 221 604 26 307 604 minecraft:black_concrete
fill 25 221 606 27 221 608 minecraft:green_terracotta
fill 25 221 610 27 221 612 minecraft:moss_block
fill 25 221 614 27 221 616 minecraft:green_terracotta
fill 25 221 618 27 221 618 minecraft:moss_block
fill 25 221 620 25 221 622 minecraft:glowstone
fill 25 221 630 27 221 632 minecraft:green_terracotta
fill 25 221 634 27 221 636 minecraft:moss_block
fill 25 221 638 27 221 640 minecraft:green_terracotta
fill 25 221 642 27 221 644 minecraft:moss_block
setblock 25 221 646 minecraft:blue_concrete
fill 26 221 619 27 221 620 minecraft:moss_block
fill 26 221 621 41 221 621 minecraft:dirt
fill 26 221 622 27 221 623 minecraft:green_terracotta
fill 26 221 646 28 242 646 minecraft:black_concrete
fill 27 221 625 27 221 627 minecraft:glowstone
fill 28 221 604 30 260 604 minecraft:black_concrete
fill 28 221 606 28 221 608 minecraft:dirt
fill 28 221 610 28 221 612 minecraft:dirt
fill 28 221 614 28 221 616 minecraft:dirt
fill 28 221 618 28 221 620 minecraft:dirt
fill 28 221 622 28 221 628 minecraft:dirt
fill 28 221 630 28 221 632 minecraft:dirt
fill 28 221 634 28 221 636 minecraft:dirt
fill 28 221 638 28 221 640 minecraft:dirt
fill 28 221 642 28 221 644 minecraft:dirt
fill 29 221 606 31 221 608 minecraft:moss_block
fill 29 221 610 31 221 612 minecraft:green_terracotta
fill 29 221 614 31 221 616 minecraft:moss_block
fill 29 221 618 31 221 620 minecraft:green_terracotta
fill 29 221 622 31 221 624 minecraft:moss_block
fill 29 221 625 41 221 625 minecraft:dirt
fill 29 221 626 31 221 628 minecraft:green_terracotta
fill 29 221 630 31 221 632 minecraft:moss_block
fill 29 221 634 31 221 636 minecraft:green_terracotta
fill 29 221 638 31 221 640 minecraft:moss_block
fill 29 221 642 31 221 644 minecraft:green_terracotta
setblock 31 221 604 minecraft:blue_concrete
fill 32 221 604 32 279 604 minecraft:black_concrete
fill 32 221 606 32 221 608 minecraft:dirt
fill 32 221 610 32 221 612 minecraft:dirt
fill 32 221 614 32 221 616 minecraft:dirt
fill 32 221 618 32 221 620 minecraft:dirt
fill 32 221 622 32 221 624 minecraft:dirt
fill 32 221 626 32 221 628 minecraft:dirt
fill 32 221 630 32 221 632 minecraft:dirt
fill 32 221 634 32 221 636 minecraft:dirt
fill 32 221 638 32 221 640 minecraft:dirt
fill 32 221 642 32 221 644 minecraft:dirt
setblock 33 221 604 minecraft:blue_concrete
fill 33 221 606 35 221 608 minecraft:green_terracotta
fill 33 221 610 35 221 612 minecraft:moss_block
fill 33 221 614 35 221 616 minecraft:green_terracotta
fill 33 221 618 35 221 620 minecraft:moss_block
fill 33 221 622 35 221 624 minecraft:green_terracotta
fill 33 221 626 35 221 628 minecraft:moss_block
fill 33 221 630 35 221 632 minecraft:green_terracotta
fill 33 221 634 35 221 636 minecraft:moss_block
fill 33 221 638 35 221 640 minecraft:green_terracotta
fill 33 221 642 35 221 644 minecraft:moss_block
fill 36 221 606 36 221 608 minecraft:dirt
fill 36 221 610 36 221 612 minecraft:dirt
fill 36 221 614 36 221 616 minecraft:dirt
fill 36 221 618 36 221 620 minecraft:dirt
fill 36 221 622 36 221 624 minecraft:dirt
fill 36 221 626 36 221 628 minecraft:dirt
fill 36 221 630 36 221 632 minecraft:dirt
fill 36 221 634 36 221 636 minecraft:dirt
fill 36 221 638 36 221 640 minecraft:dirt
fill 36 221 642 36 221 644 minecraft:dirt
fill 37 221 606 39 221 608 minecraft:moss_block
fill 37 221 610 39 221 612 minecraft:green_terracotta
fill 37 221 614 39 221 616 minecraft:moss_block
fill 37 221 618 39 221 620 minecraft:green_terracotta
fill 37 221 622 39 221 624 minecraft:moss_block
fill 37 221 626 39 221 628 minecraft:green_terracotta
fill 37 221 630 39 221 632 minecraft:moss_block
fill 37 221 634 39 221 636 minecraft:green_terracotta
fill 37 221 638 39 221 640 minecraft:moss_block
fill 37 221 642 39 221 644 minecraft:green_terracotta
fill 37 221 646 37 244 646 minecraft:black_concrete
fill 40 221 606 40 221 608 minecraft:dirt
fill 40 221 610 40 221 612 minecraft:dirt
fill 40 221 614 40 221 616 minecraft:dirt
fill 40 221 618 40 221 620 minecraft:dirt
fill 40 221 622 40 221 624 minecraft:dirt
fill 40 221 626 40 221 628 minecraft:dirt
fill 40 221 630 40 221 632 minecraft:dirt
fill 40 221 634 40 221 636 minecraft:dirt
fill 40 221 638 40 221 640 minecraft:dirt
fill 40 221 642 40 221 644 minecraft:dirt
fill 41 221 606 41 221 608 minecraft:green_terracotta
fill 41 221 610 41 221 612 minecraft:moss_block
fill 41 221 614 41 221 616 minecraft:green_terracotta
fill 41 221 618 41 221 620 minecraft:moss_block
fill 41 221 622 41 221 624 minecraft:green_terracotta
fill 41 221 626 41 221 628 minecraft:moss_block
fill 41 221 630 41 221 632 minecraft:green_terracotta
fill 41 221 634 41 221 636 minecraft:moss_block
fill 41 221 638 41 221 640 minecraft:green_terracotta
fill 41 221 642 41 221 644 minecraft:moss_block
fill 42 221 605 42 221 606 minecraft:black_concrete
fill 42 221 612 42 307 612 minecraft:black_concrete
setblock 42 221 613 minecraft:blue_concrete
fill 42 221 614 42 222 617 minecraft:black_concrete
fill 42 221 618 42 221 619 minecraft:blue_concrete
fill 42 221 620 42 223 623 minecraft:black_concrete
fill 42 221 624 42 221 625 minecraft:blue_concrete
fill 42 221 626 42 224 634 minecraft:black_concrete
setblock 42 221 635 minecraft:blue_concrete
fill 42 221 636 42 223 642 minecraft:black_concrete
setblock 42 221 643 minecraft:blue_concrete
fill 42 221 644 42 256 644 minecraft:black_concrete
setblock 42 221 645 minecraft:blue_concrete
fill 42 221 646 42 307 646 minecraft:black_concrete
fill 0 222 604 0 307 604 minecraft:black_concrete
setblock 0 222 605 minecraft:glowstone
fill 0 222 606 0 238 607 minecraft:black_concrete
fill 0 222 626 0 307 626 minecraft:black_concrete
fill 0 222 633 0 307 633 minecraft:black_concrete
fill 0 222 637 0 268 637 minecraft:black_concrete
fill 0 222 645 0 254 646 minecraft:black_concrete
fill 2 222 646 3 252 646 minecraft:black_concrete
fill 4 222 604 4 224 604 minecraft:black_concrete
fill 8 222 604 8 282 604 minecraft:black_concrete
fill 10 222 646 10 307 646 minecraft:black_concrete
fill 12 222 604 19 226 604 minecraft:black_concrete
setblock 20 222 604 minecraft:diamond_block
fill 21 222 604 24 229 604 minecraft:black_concrete
fill 25 222 646 25 263 646 minecraft:black_concrete
fill 31 222 604 31 307 604 minecraft:black_concrete
fill 33 222 604 33 291 604 minecraft:black_concrete
fill 38 222 646 38 232 646 minecraft:black_concrete
fill 42 222 605 42 224 605 minecraft:black_concrete
setblock 42 222 606 minecraft:glowstone
fill 42 222 609 42 226 609 minecraft:black_concrete
fill 42 222 613 42 271 613 minecraft:black_concrete
fill 42 222 618 42 227 619 minecraft:black_concrete
fill 42 222 624 42 235 625 minecraft:black_concrete
fill 42 222 635 42 251 635 minecraft:black_concrete
fill 42 222 643 42 238 643 minecraft:black_concrete
fill 42 222 645 42 289 645 minecraft:black_concrete
fill 0 223 605 0 307 605 minecraft:black_concrete
fill 11 223 646 22 224 646 minecraft:black_concrete
fill 20 223 604 20 224 604 minecraft:black_concrete
setblock 23 223 646 minecraft:white_concrete
fill 24 223 646 24 257 646 minecraft:black_concrete
setblock 41 223 604 minecraft:diamond_block
fill 42 223 604 42 307 604 minecraft:black_concrete
fill 42 223 606 42 307 606 minecraft:black_concrete
setblock 42 223 614 minecraft:diamond_block
fill 42 223 615 42 239 617 minecraft:black_concrete
fill 0 224 611 0 233 611 minecraft:black_concrete
setblock 0 224 612 minecraft:white_concrete
setblock 3 224 607 minecraft:light[level=14]
setblock 3 224 615 minecraft:light[level=14]
setblock 3 224 623 minecraft:light[level=14]
setblock 3 224 631 minecraft:light[level=14]
setblock 3 224 639 minecraft:light[level=14]
setblock 11 224 607 minecraft:light[level=14]
setblock 11 224 615 minecraft:light[level=14]
setblock 11 224 623 minecraft:light[level=14]
setblock 11 224 631 minecraft:light[level=14]
setblock 11 224 639 minecraft:light[level=14]
setblock 19 224 607 minecraft:light[level=14]
setblock 19 224 615 minecraft:light[level=14]
setblock 19 224 623 minecraft:light[level=14]
setblock 19 224 631 minecraft:light[level=14]
setblock 19 224 639 minecraft:light[level=14]
fill 23 224 646 23 307 646 minecraft:black_concrete
setblock 27 224 607 minecraft:light[level=14]
setblock 27 224 615 minecraft:light[level=14]
setblock 27 224 623 minecraft:light[level=14]
setblock 27 224 631 minecraft:light[level=14]
setblock 27 224 639 minecraft:light[level=14]
fill 35 224 604 39 224 604 minecraft:black_concrete
setblock 35 224 607 minecraft:light[level=14]
setblock 35 224 615 minecraft:light[level=14]
setblock 35 224 623 minecraft:light[level=14]
setblock 35 224 631 minecraft:light[level=14]
setblock 35 224 639 minecraft:light[level=14]
setblock 40 224 604 minecraft:glowstone
fill 41 224 604 41 307 604 minecraft:black_concrete
setblock 42 224 610 minecraft:diamond_block
fill 42 224 611 42 262 611 minecraft:black_concrete
setblock 42 224 614 minecraft:black_concrete
fill 42 224 620 42 262 620 minecraft:black_concrete
setblock 42 224 621 minecraft:diamond_block
fill 42 224 622 42 245 623 minecraft:black_concrete
setblock 42 224 636 minecraft:white_concrete
fill 42 224 637 42 230 642 minecraft:black_concrete
fill 0 225 612 0 227 612 minecraft:moss_block
fill 0 225 627 0 236 627 minecraft:black_concrete
fill 0 225 628 0 227 628 minecraft:moss_block
fill 0 225 629 0 257 632 minecraft:black_concrete
fill 0 225 643 0 303 643 minecraft:black_concrete
fill 0 225 644 0 227 644 minecraft:moss_block
fill 4 225 604 4 227 604 minecraft:moss_block
fill 11 225 646 13 234 646 minecraft:black_concrete
fill 14 225 646 14 227 646 minecraft:moss_block
fill 15 225 646 22 242 646 minecraft:black_concrete
fill 20 225 604 20 227 604 minecraft:moss_block
fill 30 225 646 30 227 646 minecraft:moss_block
fill 35 225 604 35 227 604 minecraft:black_concrete
fill 36 225 604 36 227 604 minecraft:moss_block
fill 37 225 604 40 236 604 minecraft:black_concrete
setblock 42 225 605 minecraft:glowstone
fill 42 225 610 42 307 610 minecraft:black_concrete
fill 42 225 614 42 227 614 minecraft:moss_block
fill 42 225 621 42 241 621 minecraft:black_concrete
fill 42 225 626 42 261 629 minecraft:black_concrete
fill 42 225 630 42 227 630 minecraft:moss_block
fill 42 225 631 42 234 634 minecraft:black_concrete
fill 42 225 636 42 307 636 minecraft:black_concrete
fill 42 226 605 42 302 605 minecraft:black_concrete
fill 12 227 604 12 253 604 minecraft:black_concrete
setblock 13 227 604 minecraft:diamond_block
fill 14 227 604 19 237 604 minecraft:black_concrete
fill 31 227 646 34 257 646 minecraft:black_concrete
setblock 35 227 646 minecraft:diamond_block
fill 36 227 646 36 284 646 minecraft:black_concrete
setblock 42 227 609 minecraft:glowstone
fill 0 228 612 0 233 612 minecraft:black_concrete
fill 0 228 628 0 233 628 minecraft:black_concrete
fill 0 228 644 0 233 644 minecraft:black_concrete
fill 4 228 604 4 233 604 minecraft:black_concrete
fill 13 228 604 13 229 604 minecraft:black_concrete
fill 14 228 646 14 233 646 minecraft:black_concrete
fill 20 228 604 20 233 604 minecraft:black_concrete
fill 30 228 646 30 229 646 minecraft:black_concrete
setblock 35 228 604 minecraft:white_concrete
fill 35 228 646 35 307 646 minecraft:black_concrete
fill 36 228 604 36 233 604 minecraft:black_concrete
fill 42 228 607 42 307 607 minecraft:black_concrete
setblock 42 228 608 minecraft:diamond_block
fill 42 228 609 42 307 609 minecraft:black_concrete
fill 42 228 614 42 233 614 minecraft:black_concrete
fill 42 228 618 42 242 618 minecraft:black_concrete
setblock 42 228 619 minecraft:white_concrete
fill 42 228 630 42 230 630 minecraft:black_concrete
fill 35 229 604 35 307 604 minecraft:black_concrete
fill 42 229 608 42 275 608 minecraft:black_concrete
fill 42 229 619 42 257 619 minecraft:black_concrete
fill 9 230 604 9 240 604 minecraft:black_concrete
setblock 10 230 604 minecraft:glowstone
fill 12 230 622 13 231 622 minecraft:gold_block
setblock 13 230 604 minecraft:diamond_block
fill 21 230 604 21 266 604 minecraft:black_concrete
setblock 22 230 604 minecraft:diamond_block
fill 23 230 604 24 234 604 minecraft:black_concrete
setblock 30 230 646 minecraft:glowstone
fill 0 231 614 0 251 618 minecraft:black_concrete
setblock 0 231 619 minecraft:white_concrete
fill 0 231 620 0 307 621 minecraft:black_concrete
fill 10 231 604 10 258 604 minecraft:black_concrete
fill 13 231 604 13 307 604 minecraft:black_concrete
fill 22 231 604 22 276 604 minecraft:black_concrete
setblock 30 231 646 minecraft:black_concrete
setblock 42 231 630 minecraft:diamond_block
fill 42 231 637 42 240 641 minecraft:black_concrete
setblock 42 231 642 minecraft:diamond_block
fill 0 232 608 0 243 609 minecraft:black_concrete
setblock 0 232 610 minecraft:glowstone
fill 0 232 619 0 254 619 minecraft:black_concrete
setblock 3 232 607 minecraft:light[level=14]
setblock 3 232 615 minecraft:light[level=14]
setblock 3 232 623 minecraft:light[level=14]
setblock 3 232 631 minecraft:light[level=14]
setblock 3 232 639 minecraft:light[level=14]
setblock 11 232 607 minecraft:light[level=14]
setblock 11 232 615 minecraft:light[level=14]
setblock 11 232 623 minecraft:light[level=14]
setblock 11 232 631 minecraft:light[level=14]
setblock 11 232 639 minecraft:light[level=14]
setblock 19 232 607 minecraft:light[level=14]
setblock 19 232 615 minecraft:light[level=14]
setblock 19 232 623 minecraft:light[level=14]
setblock 19 232 631 minecraft:light[level=14]
setblock 19 232 639 minecraft:light[level=14]
setblock 27 232 607 minecraft:light[level=14]
setblock 27 232 615 minecraft:light[level=14]
setblock 27 232 623 minecraft:light[level=14]
setblock 27 232 631 minecraft:light[level=14]
setblock 27 232 639 minecraft:light[level=14]
setblock 30 232 646 minecraft:glowstone
setblock 35 232 607 minecraft:light[level=14]
setblock 35 232 615 minecraft:light[level=14]
setblock 35 232 623 minecraft:light[level=14]
setblock 35 232 631 minecraft:light[level=14]
setblock 35 232 639 minecraft:light[level=14]
setblock 39 232 646 minecraft:glowstone
fill 40 232 646 40 248 646 minecraft:black_concrete
setblock 41 232 646 minecraft:diamond_block
fill 42 232 630 42 233 630 minecraft:black_concrete
fill 42 232 642 42 253 642 minecraft:black_concrete
fill 0 233 610 0 258 610 minecraft:black_concrete
fill 11 233 631 11 234 631 minecraft:gold_block
setblock 30 233 646 minecraft:black_concrete
setblock 38 233 646 minecraft:white_concrete
fill 39 233 646 39 271 646 minecraft:black_concrete
fill 41 233 646 41 307 646 minecraft:black_concrete
setblock 0 234 611 minecraft:diamond_block
fill 0 234 612 0 236 612 minecraft:moss_block
fill 0 234 628 0 236 628 minecraft:moss_block
fill 0 234 644 0 236 644 minecraft:moss_block
setblock 1 234 604 minecraft:diamond_block
fill 2 234 604 3 239 604 minecraft:black_concrete
fill 4 234 604 4 236 604 minecraft:moss_block
fill 14 234 646 14 236 646 minecraft:moss_block
fill 20 234 604 20 236 604 minecraft:moss_block
fill 30 234 646 30 236 646 minecraft:moss_block
fill 36 234 604 36 236 604 minecraft:moss_block
fill 38 234 646 38 287 646 minecraft:black_concrete
fill 42 234 614 42 236 614 minecraft:moss_block
fill 42 234 630 42 236 630 minecraft:moss_block
fill 0 235 611 0 307 611 minecraft:black_concrete
fill 1 235 604 1 307 604 minecraft:black_concrete
setblock 11 235 646 minecraft:diamond_block
fill 12 235 646 13 291 646 minecraft:black_concrete
fill 23 235 604 23 249 604 minecraft:black_concrete
setblock 24 235 604 minecraft:diamond_block
setblock 42 235 631 minecraft:glowstone
fill 42 235 632 42 277 634 minecraft:black_concrete
fill 11 236 646 11 252 646 minecraft:black_concrete
fill 24 236 604 24 307 604 minecraft:black_concrete
fill 42 236 624 42 275 624 minecraft:black_concrete
setblock 42 236 625 minecraft:diamond_block
fill 42 236 631 42 307 631 minecraft:black_concrete
fill 0 237 612 0 242 612 minecraft:black_concrete
setblock 0 237 627 minecraft:diamond_block
fill 0 237 628 0 242 628 minecraft:black_concrete
fill 0 237 644 0 242 644 minecraft:black_concrete
fill 4 237 604 4 242 604 minecraft:black_concrete
fill 14 237 646 14 242 646 minecraft:black_concrete
fill 20 237 604 20 242 604 minecraft:black_concrete
fill 25 237 634 25 238 634 minecraft:raw_iron_block
fill 30 237 646 30 242 646 minecraft:black_concrete
fill 36 237 604 39 242 604 minecraft:black_concrete
setblock 40 237 604 minecraft:diamond_block
fill 42 237 614 42 242 614 minecraft:black_concrete
fill 42 237 625 42 307 625 minecraft:black_concrete
fill 42 237 630 42 242 630 minecraft:black_concrete
fill 0 238 627 0 307 627 minecraft:black_concrete
fill 14 238 604 18 238 604 minecraft:black_concrete
setblock 19 238 604 minecraft:diamond_block
fill 40 238 604 40 251 604 minecraft:black_concrete
fill 0 239 606 0 307 606 minecraft:black_concrete
setblock 0 239 607 minecraft:glowstone
fill 14 239 604 15 255 604 minecraft:black_concrete
setblock 16 239 604 minecraft:glowstone
fill 17 239 604 19 248 604 minecraft:black_concrete
setblock 42 239 643 minecraft:diamond_block
fill 0 240 607 0 289 607 minecraft:black_concrete
setblock 2 240 604 minecraft:glowstone
fill 3 240 604 3 251 604 minecraft:black_concrete
setblock 3 240 607 minecraft:light[level=14]
setblock 3 240 615 minecraft:light[level=14]
setblock 3 240 623 minecraft:light[level=14]
setblock 3 240 631 minecraft:light[level=14]
setblock 3 240 639 minecraft:light[level=14]
setblock 11 240 607 minecraft:light[level=14]
setblock 11 240 615 minecraft:light[level=14]
setblock 11 240 623 minecraft:light[level=14]
setblock 11 240 631 minecraft:light[level=14]
setblock 11 240 639 minecraft:light[level=14]
fill 16 240 604 16 307 604 minecraft:black_concrete
setblock 19 240 607 minecraft:light[level=14]
setblock 19 240 615 minecraft:light[level=14]
setblock 19 240 623 minecraft:light[level=14]
setblock 19 240 631 minecraft:light[level=14]
setblock 19 240 639 minecraft:light[level=14]
setblock 27 240 607 minecraft:light[level=14]
setblock 27 240 615 minecraft:light[level=14]
setblock 27 240 623 minecraft:light[level=14]
setblock 27 240 631 minecraft:light[level=14]
setblock 27 240 639 minecraft:light[level=14]
setblock 35 240 607 minecraft:light[level=14]
setblock 35 240 615 minecraft:light[level=14]
setblock 35 240 623 minecraft:light[level=14]
setblock 35 240 631 minecraft:light[level=14]
setblock 35 240 639 minecraft:light[level=14]
fill 42 240 615 42 242 616 minecraft:black_concrete
setblock 42 240 617 minecraft:diamond_block
fill 42 240 643 42 260 643 minecraft:black_concrete
fill 2 241 604 2 287 604 minecraft:black_concrete
setblock 5 241 646 minecraft:diamond_block
fill 6 241 646 6 307 646 minecraft:black_concrete
setblock 9 241 604 minecraft:white_concrete
fill 42 241 617 42 275 617 minecraft:black_concrete
fill 42 241 637 42 273 637 minecraft:black_concrete
setblock 42 241 638 minecraft:glowstone
fill 42 241 639 42 261 641 minecraft:black_concrete
fill 5 242 646 5 307 646 minecraft:black_concrete
fill 7 242 646 7 307 646 minecraft:black_concrete
fill 8 242 646 9 242 646 minecraft:white_concrete
fill 9 242 604 9 307 604 minecraft:black_concrete
setblock 42 242 621 minecraft:diamond_block
fill 42 242 638 42 307 638 minecraft:black_concrete
fill 0 243 612 0 245 612 minecraft:moss_block
fill 0 243 628 0 245 628 minecraft:moss_block
fill 0 243 644 0 245 644 minecraft:moss_block
fill 4 243 604 4 245 604 minecraft:moss_block
fill 8 243 646 9 260 646 minecraft:black_concrete
fill 14 243 646 14 245 646 minecraft:moss_block
fill 15 243 646 21 243 646 minecraft:black_concrete
fill 20 243 604 20 245 604 minecraft:moss_block
setblock 22 243 646 minecraft:glowstone
fill 26 243 646 26 273 646 minecraft:black_concrete
setblock 27 243 646 minecraft:diamond_block
fill 28 243 646 28 256 646 minecraft:black_concrete
fill 30 243 646 30 245 646 minecraft:moss_block
fill 36 243 604 36 245 604 minecraft:moss_block
fill 37 243 604 39 256 604 minecraft:black_concrete
fill 42 243 614 42 245 614 minecraft:moss_block
setblock 42 243 615 minecraft:glowstone
fill 42 243 616 42 307 616 minecraft:black_concrete
setblock 42 243 618 minecraft:diamond_block
fill 42 243 621 42 247 621 minecraft:black_concrete
fill 42 243 630 42 245 630 minecraft:moss_block
fill 0 244 608 0 273 608 minecraft:black_concrete
setblock 0 244 609 minecraft:diamond_block
fill 0 244 622 0 252 622 minecraft:black_concrete
setblock 0 244 623 minecraft:glowstone
fill 0 244 624 0 255 625 minecraft:black_concrete
fill 15 244 646 15 284 646 minecraft:black_concrete
setblock 16 244 646 minecraft:white_concrete
fill 17 244 646 22 252 646 minecraft:black_concrete
fill 27 244 646 27 307 646 minecraft:black_concrete
fill 42 244 615 42 307 615 minecraft:black_concrete
fill 42 244 618 42 307 618 minecraft:black_concrete
setblock 0 245 609 minecraft:black_concrete
fill 0 245 623 0 307 623 minecraft:black_concrete
fill 16 245 646 16 254 646 minecraft:black_concrete
fill 37 245 617 38 246 617 minecraft:moss_block
setblock 37 245 646 minecraft:diamond_block
setblock 0 246 609 minecraft:white_concrete
fill 0 246 612 0 247 612 minecraft:black_concrete
fill 0 246 628 0 251 628 minecraft:black_concrete
fill 0 246 644 0 248 644 minecraft:black_concrete
fill 4 246 604 4 251 604 minecraft:black_concrete
fill 14 246 646 14 251 646 minecraft:black_concrete
fill 20 246 604 20 251 604 minecraft:black_concrete
fill 30 246 646 30 251 646 minecraft:black_concrete
fill 36 246 604 36 251 604 minecraft:black_concrete
fill 37 246 646 37 289 646 minecraft:black_concrete
setblock 42 246 614 minecraft:glowstone
fill 42 246 622 42 307 622 minecraft:black_concrete
setblock 42 246 623 minecraft:white_concrete
fill 42 246 630 42 251 630 minecraft:black_concrete
fill 0 247 609 0 307 609 minecraft:black_concrete
fill 42 247 614 42 251 614 minecraft:black_concrete
fill 42 247 623 42 252 623 minecraft:black_concrete
setblock 0 248 612 minecraft:white_concrete
fill 0 248 634 0 249 635 minecraft:black_concrete
setblock 0 248 636 minecraft:white_concrete
setblock 3 248 607 minecraft:light[level=14]
setblock 3 248 615 minecraft:light[level=14]
setblock 3 248 623 minecraft:light[level=14]
setblock 3 248 631 minecraft:light[level=14]
setblock 3 248 639 minecraft:light[level=14]
setblock 11 248 607 minecraft:light[level=14]
setblock 11 248 615 minecraft:light[level=14]
setblock 11 248 623 minecraft:light[level=14]
setblock 11 248 631 minecraft:light[level=14]
setblock 11 248 639 minecraft:light[level=14]
setblock 19 248 607 minecraft:light[level=14]
setblock 19 248 615 minecraft:light[level=14]
setblock 19 248 623 minecraft:light[level=14]
setblock 19 248 631 minecraft:light[level=14]
setblock 19 248 639 minecraft:light[level=14]
setblock 27 248 607 minecraft:light[level=14]
setblock 27 248 615 minecraft:light[level=14]
setblock 27 248 623 minecraft:light[level=14]
setblock 27 248 631 minecraft:light[level=14]
setblock 27 248 639 minecraft:light[level=14]
setblock 34 248 604 minecraft:diamond_block
setblock 35 248 607 minecraft:light[level=14]
setblock 35 248 615 minecraft:light[level=14]
setblock 35 248 623 minecraft:light[level=14]
setblock 35 248 631 minecraft:light[level=14]
setblock 35 248 639 minecraft:light[level=14]
setblock 42 248 621 minecraft:glowstone
fill 0 249 612 0 251 612 minecraft:black_concrete
fill 0 249 636 0 274 636 minecraft:black_concrete
setblock 0 249 644 minecraft:white_concrete
fill 17 249 604 17 288 604 minecraft:black_concrete
setblock 18 249 604 minecraft:glowstone
fill 19 249 604 19 307 604 minecraft:black_concrete
fill 34 249 604 34 307 604 minecraft:black_concrete
setblock 40 249 646 minecraft:white_concrete
fill 42 249 621 42 307 621 minecraft:black_concrete
setblock 0 250 634 minecraft:white_concrete
fill 0 250 635 0 272 635 minecraft:black_concrete
fill 0 250 644 0 251 644 minecraft:black_concrete
fill 18 250 604 18 307 604 minecraft:black_concrete
setblock 23 250 604 minecraft:white_concrete
fill 40 250 646 40 307 646 minecraft:black_concrete
fill 0 251 634 0 267 634 minecraft:black_concrete
fill 23 251 604 23 307 604 minecraft:black_concrete
fill 0 252 612 0 254 612 minecraft:moss_block
fill 0 252 614 0 258 617 minecraft:black_concrete
setblock 0 252 618 minecraft:glowstone
fill 0 252 628 0 254 628 minecraft:moss_block
fill 0 252 644 0 254 644 minecraft:moss_block
setblock 3 252 604 minecraft:diamond_block
fill 4 252 604 4 254 604 minecraft:moss_block
fill 14 252 646 14 254 646 minecraft:moss_block
fill 20 252 604 20 254 604 minecraft:moss_block
fill 30 252 646 30 254 646 minecraft:moss_block
fill 36 252 604 36 254 604 minecraft:moss_block
setblock 40 252 604 minecraft:glowstone
fill 42 252 614 42 254 614 minecraft:moss_block
fill 42 252 630 42 254 630 minecraft:moss_block
setblock 42 252 635 minecraft:diamond_block
fill 0 253 618 0 265 618 minecraft:black_concrete
setblock 0 253 622 minecraft:diamond_block
fill 2 253 646 2 307 646 minecraft:black_concrete
fill 3 253 604 3 307 604 minecraft:black_concrete
setblock 3 253 646 minecraft:glowstone
setblock 11 253 646 minecraft:diamond_block
fill 17 253 646 21 263 646 minecraft:black_concrete
setblock 22 253 646 minecraft:diamond_block
fill 40 253 604 40 307 604 minecraft:black_concrete
setblock 42 253 623 minecraft:diamond_block
fill 42 253 635 42 307 635 minecraft:black_concrete
fill 0 254 622 0 307 622 minecraft:black_concrete
fill 3 254 646 3 292 646 minecraft:black_concrete
setblock 11 254 646 minecraft:black_concrete
setblock 12 254 604 minecraft:diamond_block
fill 22 254 646 22 307 646 minecraft:black_concrete
fill 42 254 623 42 269 623 minecraft:black_concrete
setblock 42 254 642 minecraft:diamond_block
fill 0 255 612 0 260 612 minecraft:black_concrete
setblock 0 255 619 minecraft:white_concrete
fill 0 255 628 0 260 628 minecraft:black_concrete
fill 0 255 644 0 260 644 minecraft:black_concrete
setblock 0 255 645 minecraft:diamond_block
fill 0 255 646 0 307 646 minecraft:black_concrete
fill 4 255 604 4 260 604 minecraft:black_concrete
setblock 11 255 646 minecraft:white_concrete
fill 12 255 604 12 307 604 minecraft:black_concrete
fill 14 255 646 14 260 646 minecraft:black_concrete
setblock 16 255 646 minecraft:glowstone
fill 20 255 604 20 260 604 minecraft:black_concrete
fill 30 255 646 30 260 646 minecraft:black_concrete
fill 36 255 604 36 260 604 minecraft:black_concrete
fill 42 255 614 42 260 614 minecraft:black_concrete
fill 42 255 630 42 256 630 minecraft:black_concrete
fill 42 255 642 42 307 642 minecraft:black_concrete
setblock 0 256 613 minecraft:diamond_block
fill 0 256 619 0 271 619 minecraft:black_concrete
fill 0 256 624 0 307 624 minecraft:black_concrete
setblock 0 256 625 minecraft:diamond_block
fill 0 256 645 0 307 645 minecraft:black_concrete
setblock 3 256 607 minecraft:light[level=14]
setblock 3 256 615 minecraft:light[level=14]
setblock 3 256 623 minecraft:light[level=14]
setblock 3 256 631 minecraft:light[level=14]
setblock 3 256 639 minecraft:light[level=14]
setblock 11 256 607 minecraft:light[level=14]
setblock 11 256 615 minecraft:light[level=14]
setblock 11 256 623 minecraft:light[level=14]
setblock 11 256 631 minecraft:light[level=14]
setblock 11 256 639 minecraft:light[level=14]
fill 11 256 646 11 277 646 minecraft:black_concrete
setblock 14 256 604 minecraft:diamond_block
fill 15 256 604 15 295 604 minecraft:black_concrete
fill 16 256 646 16 307 646 minecraft:black_concrete
setblock 19 256 607 minecraft:light[level=14]
setblock 19 256 615 minecraft:light[level=14]
setblock 19 256 623 minecraft:light[level=14]
setblock 19 256 631 minecraft:light[level=14]
setblock 19 256 639 minecraft:light[level=14]
setblock 27 256 607 minecraft:light[level=14]
setblock 27 256 615 minecraft:light[level=14]
setblock 27 256 623 minecraft:light[level=14]
setblock 27 256 631 minecraft:light[level=14]
setblock 27 256 639 minecraft:light[level=14]
setblock 35 256 607 minecraft:light[level=14]
setblock 35 256 615 minecraft:light[level=14]
setblock 35 256 623 minecraft:light[level=14]
setblock 35 256 631 minecraft:light[level=14]
setblock 35 256 639 minecraft:light[level=14]
fill 0 257 613 0 307 613 minecraft:black_concrete
fill 0 257 625 0 287 625 minecraft:black_concrete
fill 14 257 604 14 272 604 minecraft:black_concrete
setblock 28 257 646 minecraft:glowstone
fill 37 257 604 38 276 604 minecraft:black_concrete
setblock 39 257 604 minecraft:white_concrete
setblock 42 257 630 minecraft:glowstone
setblock 42 257 644 minecraft:glowstone
fill 0 258 629 0 280 631 minecraft:black_concrete
setblock 0 258 632 minecraft:diamond_block
setblock 1 258 646 minecraft:white_concrete
setblock 24 258 646 minecraft:glowstone
fill 28 258 646 28 281 646 minecraft:black_concrete
setblock 31 258 646 minecraft:white_concrete
fill 32 258 646 34 260 646 minecraft:black_concrete
fill 39 258 604 39 305 604 minecraft:black_concrete
setblock 42 258 619 minecraft:white_concrete
fill 42 258 630 42 260 630 minecraft:black_concrete
fill 42 258 644 42 307 644 minecraft:black_concrete
setblock 0 259 610 minecraft:diamond_block
setblock 0 259 614 minecraft:glowstone
fill 0 259 615 0 286 617 minecraft:black_concrete
fill 0 259 632 0 263 632 minecraft:black_concrete
fill 1 259 646 1 276 646 minecraft:black_concrete
setblock 10 259 604 minecraft:glowstone
fill 24 259 646 24 270 646 minecraft:black_concrete
fill 31 259 646 31 266 646 minecraft:black_concrete
fill 42 259 619 42 277 619 minecraft:black_concrete
fill 0 260 610 0 296 610 minecraft:black_concrete
fill 0 260 614 0 286 614 minecraft:black_concrete
fill 10 260 604 10 307 604 minecraft:black_concrete
fill 27 260 636 27 261 636 minecraft:diamond_block
fill 0 261 612 0 263 612 minecraft:moss_block
fill 0 261 628 0 263 628 minecraft:moss_block
fill 0 261 644 0 263 644 minecraft:moss_block
fill 4 261 604 4 263 604 minecraft:moss_block
fill 8 261 646 8 303 646 minecraft:black_concrete
setblock 9 261 646 minecraft:diamond_block
fill 14 261 646 14 263 646 minecraft:moss_block
fill 20 261 604 20 263 604 minecraft:moss_block
fill 25 261 614 25 262 614 minecraft:diamond_block
fill 28 261 604 28 307 604 minecraft:black_concrete
setblock 29 261 604 minecraft:diamond_block
setblock 30 261 604 minecraft:black_concrete
fill 30 261 646 30 263 646 minecraft:moss_block
setblock 32 261 646 minecraft:glowstone
fill 33 261 646 34 261 646 minecraft:black_concrete
fill 36 261 604 36 263 604 minecraft:moss_block
fill 42 261 614 42 263 614 minecraft:moss_block
fill 42 261 630 42 263 630 minecraft:moss_block
setblock 42 261 643 minecraft:glowstone
fill 9 262 646 9 307 646 minecraft:black_concrete
fill 27 262 636 27 270 636 minecraft:dirt
fill 29 262 604 29 307 604 minecraft:black_concrete
setblock 30 262 604 minecraft:glowstone
fill 32 262 646 33 276 646 minecraft:black_concrete
setblock 34 262 646 minecraft:glowstone
fill 42 262 626 42 275 627 minecraft:black_concrete
setblock 42 262 628 minecraft:white_concrete
fill 42 262 629 42 307 629 minecraft:black_concrete
setblock 42 262 639 minecraft:glowstone
fill 42 262 640 42 278 641 minecraft:black_concrete
fill 42 262 643 42 263 643 minecraft:black_concrete
fill 25 263 614 25 269 614 minecraft:dirt
fill 30 263 604 30 264 604 minecraft:black_concrete
fill 34 263 646 34 296 646 minecraft:black_concrete
setblock 42 263 611 minecraft:glowstone
setblock 42 263 620 minecraft:white_concrete
setblock 42 263 628 minecraft:black_concrete
fill 42 263 639 42 307 639 minecraft:black_concrete
fill 0 264 612 0 269 612 minecraft:black_concrete
fill 0 264 628 0 269 628 minecraft:black_concrete
setblock 0 264 632 minecraft:diamond_block
fill 0 264 644 0 269 644 minecraft:black_concrete
setblock 3 264 607 minecraft:light[level=14]
setblock 3 264 615 minecraft:light[level=14]
setblock 3 264 623 minecraft:light[level=14]
setblock 3 264 631 minecraft:light[level=14]
setblock 3 264 639 minecraft:light[level=14]
fill 4 264 604 4 269 604 minecraft:black_concrete
setblock 11 264 607 minecraft:light[level=14]
setblock 11 264 615 minecraft:light[level=14]
setblock 11 264 623 minecraft:light[level=14]
setblock 11 264 631 minecraft:light[level=14]
setblock 11 264 639 minecraft:light[level=14]
fill 14 264 646 14 269 646 minecraft:black_concrete
fill 17 264 646 18 307 646 minecraft:black_concrete
setblock 19 264 607 minecraft:light[level=14]
setblock 19 264 615 minecraft:light[level=14]
setblock 19 264 623 minecraft:light[level=14]
setblock 19 264 631 minecraft:light[level=14]
setblock 19 264 639 minecraft:light[level=14]
setblock 19 264 646 minecraft:glowstone
fill 20 264 604 20 269 604 minecraft:black_concrete
fill 20 264 646 21 281 646 minecraft:black_concrete
setblock 25 264 646 minecraft:diamond_block
fill 26 264 614 26 269 614 minecraft:dirt
fill 26 264 636 26 270 636 minecraft:dirt
setblock 27 264 607 minecraft:light[level=14]
setblock 27 264 615 minecraft:light[level=14]
setblock 27 264 623 minecraft:light[level=14]
setblock 27 264 631 minecraft:light[level=14]
fill 27 264 635 27 270 635 minecraft:dirt
fill 27 264 637 27 270 637 minecraft:dirt
setblock 27 264 639 minecraft:light[level=14]
fill 28 264 636 28 270 636 minecraft:dirt
fill 30 264 646 30 269 646 minecraft:black_concrete
setblock 35 264 607 minecraft:light[level=14]
setblock 35 264 615 minecraft:light[level=14]
setblock 35 264 623 minecraft:light[level=14]
setblock 35 264 631 minecraft:light[level=14]
setblock 35 264 639 minecraft:light[level=14]
fill 36 264 604 36 269 604 minecraft:black_concrete
fill 42 264 611 42 265 611 minecraft:black_concrete
fill 42 264 614 42 269 614 minecraft:black_concrete
fill 42 264 620 42 307 620 minecraft:black_concrete
setblock 42 264 628 minecraft:diamond_block
fill 42 264 630 42 269 630 minecraft:black_concrete
setblock 42 264 643 minecraft:diamond_block
fill 0 265 632 0 278 632 minecraft:black_concrete
fill 19 265 646 19 283 646 minecraft:black_concrete
fill 24 265 614 24 269 614 minecraft:dirt
fill 25 265 613 26 269 613 minecraft:dirt
fill 25 265 615 26 269 615 minecraft:dirt
fill 25 265 646 25 307 646 minecraft:black_concrete
fill 26 265 635 26 270 635 minecraft:dirt
fill 26 265 637 26 270 637 minecraft:dirt
fill 28 265 635 28 270 635 minecraft:dirt
fill 28 265 637 28 270 637 minecraft:dirt
setblock 30 265 604 minecraft:diamond_block
fill 42 265 628 42 307 628 minecraft:black_concrete
fill 42 265 643 42 291 643 minecraft:black_concrete
setblock 0 266 618 minecraft:glowstone
fill 5 266 604 6 277 604 minecraft:black_concrete
setblock 7 266 604 minecraft:white_concrete
fill 24 266 613 24 269 613 minecraft:dirt
fill 24 266 615 24 269 615 minecraft:dirt
fill 27 266 614 27 269 614 minecraft:dirt
fill 27 266 634 28 270 634 minecraft:dirt
fill 29 266 635 29 270 636 minecraft:dirt
fill 30 266 604 30 307 604 minecraft:black_concrete
setblock 42 266 611 minecraft:white_concrete
fill 0 267 618 0 307 618 minecraft:black_concrete
fill 7 267 604 7 297 604 minecraft:black_concrete
setblock 21 267 604 minecraft:glowstone
fill 23 267 614 23 269 614 minecraft:dirt
fill 25 267 612 26 269 612 minecraft:dirt
fill 25 267 616 26 269 616 minecraft:dirt
fill 25 267 635 25 270 637 minecraft:dirt
fill 26 267 634 26 270 634 minecraft:dirt
fill 26 267 638 28 270 638 minecraft:dirt
fill 27 267 613 27 269 613 minecraft:dirt
fill 27 267 615 27 269 615 minecraft:dirt
fill 29 267 637 29 270 637 minecraft:dirt
setblock 31 267 646 minecraft:glowstone
fill 42 267 611 42 292 611 minecraft:black_concrete
setblock 0 268 634 minecraft:glowstone
fill 21 268 604 21 307 604 minecraft:black_concrete
fill 23 268 613 23 269 613 minecraft:dirt
fill 23 268 615 23 269 615 minecraft:dirt
fill 24 268 612 24 269 612 minecraft:dirt
fill 24 268 616 24 269 616 minecraft:dirt
fill 25 268 634 25 270 634 minecraft:dirt
fill 25 268 638 25 270 638 minecraft:dirt
fill 26 268 633 28 270 633 minecraft:dirt
fill 27 268 612 27 269 612 minecraft:dirt
fill 27 268 616 27 269 616 minecraft:dirt
fill 29 268 634 29 270 634 minecraft:dirt
fill 29 268 638 29 270 638 minecraft:dirt
fill 30 268 635 30 270 636 minecraft:dirt
fill 31 268 646 31 307 646 minecraft:black_concrete
fill 0 269 634 0 307 634 minecraft:black_concrete
setblock 0 269 637 minecraft:diamond_block
setblock 23 269 612 minecraft:dirt
setblock 23 269 616 minecraft:dirt
fill 24 269 635 24 270 637 minecraft:dirt
fill 25 269 611 26 269 611 minecraft:dirt
fill 25 269 617 26 269 617 minecraft:dirt
fill 26 269 639 28 270 639 minecraft:dirt
fill 28 269 613 28 269 615 minecraft:dirt
fill 29 269 633 29 270 633 minecraft:dirt
fill 30 269 634 30 270 634 minecraft:dirt
fill 30 269 637 30 270 637 minecraft:dirt
fill 0 270 612 0 272 612 minecraft:moss_block
fill 0 270 628 0 272 628 minecraft:moss_block
fill 0 270 637 0 289 637 minecraft:black_concrete
fill 0 270 644 0 272 644 minecraft:moss_block
fill 4 270 604 4 272 604 minecraft:moss_block
fill 14 270 646 14 272 646 minecraft:moss_block
fill 20 270 604 20 272 604 minecraft:moss_block
setblock 24 270 634 minecraft:dirt
setblock 24 270 638 minecraft:dirt
fill 25 270 614 25 273 614 minecraft:stone
setblock 25 270 633 minecraft:dirt
setblock 25 270 639 minecraft:dirt
fill 26 270 632 28 270 632 minecraft:dirt
setblock 29 270 639 minecraft:dirt
setblock 30 270 638 minecraft:dirt
fill 30 270 646 30 272 646 minecraft:moss_block
fill 31 270 635 31 270 636 minecraft:dirt
fill 32 270 639 32 271 639 minecraft:gold_block
fill 36 270 604 36 272 604 minecraft:moss_block
fill 42 270 614 42 272 614 minecraft:moss_block
setblock 42 270 623 minecraft:diamond_block
fill 42 270 630 42 272 630 minecraft:moss_block
setblock 24 271 646 minecraft:diamond_block
fill 27 271 636 27 273 636 minecraft:stone
fill 30 271 627 30 272 628 minecraft:stone
fill 42 271 623 42 299 623 minecraft:black_concrete
setblock 0 272 619 minecraft:white_concrete
setblock 3 272 607 minecraft:light[level=14]
setblock 3 272 615 minecraft:light[level=14]
setblock 3 272 623 minecraft:light[level=14]
setblock 3 272 631 minecraft:light[level=14]
setblock 3 272 639 minecraft:light[level=14]
setblock 11 272 607 minecraft:light[level=14]
setblock 11 272 615 minecraft:light[level=14]
setblock 11 272 623 minecraft:light[level=14]
setblock 11 272 631 minecraft:light[level=14]
setblock 11 272 639 minecraft:light[level=14]
setblock 19 272 607 minecraft:light[level=14]
setblock 19 272 615 minecraft:light[level=14]
setblock 19 272 623 minecraft:light[level=14]
setblock 19 272 631 minecraft:light[level=14]
setblock 19 272 639 minecraft:light[level=14]
fill 24 272 646 24 307 646 minecraft:black_concrete
setblock 27 272 607 minecraft:light[level=14]
setblock 27 272 615 minecraft:light[level=14]
setblock 27 272 623 minecraft:light[level=14]
setblock 27 272 631 minecraft:light[level=14]
setblock 27 272 639 minecraft:light[level=14]
setblock 35 272 607 minecraft:light[level=14]
setblock 35 272 615 minecraft:light[level=14]
setblock 35 272 623 minecraft:light[level=14]
setblock 35 272 631 minecraft:light[level=14]
setblock 35 272 639 minecraft:light[level=14]
setblock 39 272 646 minecraft:white_concrete
setblock 42 272 613 minecraft:white_concrete
fill 0 273 612 0 287 612 minecraft:black_concrete
fill 0 273 619 0 307 619 minecraft:black_concrete
fill 0 273 628 0 287 628 minecraft:black_concrete
setblock 0 273 635 minecraft:glowstone
fill 0 273 644 0 279 644 minecraft:black_concrete
fill 4 273 604 4 287 604 minecraft:black_concrete
setblock 14 273 604 minecraft:glowstone
fill 14 273 646 14 287 646 minecraft:black_concrete
fill 20 273 604 20 287 604 minecraft:black_concrete
fill 24 273 613 24 273 615 minecraft:oak_leaves[persistent=true]
fill 25 273 613 26 273 613 minecraft:oak_leaves[persistent=true]
fill 25 273 615 25 273 616 minecraft:oak_leaves[persistent=true]
fill 26 273 614 27 273 615 minecraft:oak_leaves[persistent=true]
fill 30 273 646 30 287 646 minecraft:black_concrete
fill 36 273 604 36 287 604 minecraft:black_concrete
fill 39 273 646 39 307 646 minecraft:black_concrete
fill 42 273 613 42 287 614 minecraft:black_concrete
fill 42 273 630 42 287 630 minecraft:black_concrete
setblock 0 274 608 minecraft:white_concrete
fill 0 274 635 0 305 635 minecraft:black_concrete
fill 14 274 604 14 307 604 minecraft:black_concrete
setblock 26 274 646 minecraft:white_concrete
setblock 42 274 637 minecraft:diamond_block
fill 0 275 608 0 307 608 minecraft:black_concrete
setblock 0 275 636 minecraft:glowstone
fill 26 275 646 26 307 646 minecraft:black_concrete
fill 42 275 637 42 287 637 minecraft:black_concrete
fill 0 276 636 0 307 636 minecraft:black_concrete
setblock 42 276 608 minecraft:glowstone
setblock 42 276 617 minecraft:white_concrete
setblock 42 276 624 minecraft:white_concrete
fill 42 276 626 42 291 626 minecraft:black_concrete
setblock 42 276 627 minecraft:glowstone
setblock 1 277 646 minecraft:white_concrete
setblock 22 277 604 minecraft:white_concrete
setblock 32 277 646 minecraft:diamond_block
fill 33 277 646 33 307 646 minecraft:black_concrete
setblock 37 277 604 minecraft:diamond_block
setblock 38 277 604 minecraft:glowstone
fill 42 277 608 42 288 608 minecraft:black_concrete
fill 42 277 617 42 307 617 minecraft:black_concrete
fill 42 277 624 42 307 624 minecraft:black_concrete
fill 42 277 627 42 288 627 minecraft:black_concrete
fill 1 278 646 1 294 646 minecraft:black_concrete
setblock 5 278 604 minecraft:glowstone
fill 6 278 604 6 280 604 minecraft:black_concrete
setblock 11 278 646 minecraft:glowstone
fill 17 278 624 19 278 626 minecraft:redstone_block
fill 21 278 619 23 278 621 minecraft:redstone_block
fill 22 278 604 22 279 604 minecraft:black_concrete
fill 22 278 629 24 278 631 minecraft:redstone_block
fill 26 278 621 28 278 623 minecraft:redstone_block
fill 32 278 646 32 307 646 minecraft:black_concrete
fill 37 278 604 38 286 604 minecraft:black_concrete
setblock 42 278 619 minecraft:white_concrete
fill 42 278 632 42 307 632 minecraft:black_concrete
setblock 42 278 633 minecraft:diamond_block
fill 42 278 634 42 296 634 minecraft:black_concrete
setblock 0 279 632 minecraft:glowstone
fill 1 279 605 2 280 606 minecraft:light_blue_wool
fill 1 279 607 2 280 612 minecraft:white_wool
fill 1 279 613 2 280 615 minecraft:light_blue_wool
fill 1 279 616 2 280 621 minecraft:white_wool
fill 1 279 622 2 280 624 minecraft:light_blue_wool
fill 1 279 625 2 280 630 minecraft:white_wool
fill 1 279 631 2 280 633 minecraft:light_blue_wool
fill 1 279 634 2 280 639 minecraft:white_wool
fill 1 279 640 2 280 642 minecraft:light_blue_wool
fill 1 279 643 5 280 645 minecraft:white_wool
fill 3 279 605 5 280 609 minecraft:white_wool
fill 3 279 610 5 280 612 minecraft:light_blue_wool
fill 3 279 613 5 280 618 minecraft:white_wool
fill 3 279 619 5 280 621 minecraft:light_blue_wool
fill 3 279 622 5 280 627 minecraft:white_wool
fill 3 279 628 5 280 630 minecraft:light_blue_wool
fill 3 279 631 5 280 636 minecraft:white_wool
fill 3 279 637 5 280 639 minecraft:light_blue_wool
fill 3 279 640 8 280 642 minecraft:white_wool
fill 5 279 604 5 298 604 minecraft:black_concrete
fill 6 279 605 8 280 606 minecraft:white_wool
fill 6 279 607 8 280 609 minecraft:light_blue_wool
fill 6 279 610 8 280 615 minecraft:white_wool
fill 6 279 616 8 280 618 minecraft:light_blue_wool
fill 6 279 619 8 280 624 minecraft:white_wool
fill 6 279 625 8 280 627 minecraft:light_blue_wool
fill 6 279 628 8 280 633 minecraft:white_wool
fill 6 279 634 8 280 636 minecraft:light_blue_wool
fill 6 279 637 11 280 639 minecraft:white_wool
fill 6 279 643 8 280 645 minecraft:light_blue_wool
fill 9 279 605 11 280 606 minecraft:light_blue_wool
fill 9 279 607 11 280 612 minecraft:white_wool
fill 9 279 613 11 280 615 minecraft:light_blue_wool
fill 9 279 616 11 280 621 minecraft:white_wool
fill 9 279 622 11 280 624 minecraft:light_blue_wool
fill 9 279 625 11 280 630 minecraft:white_wool
fill 9 279 631 11 280 633 minecraft:light_blue_wool
fill 9 279 634 14 280 636 minecraft:white_wool
fill 9 279 640 11 280 642 minecraft:light_blue_wool
fill 9 279 643 14 280 645 minecraft:white_wool
fill 11 279 646 11 307 646 minecraft:black_concrete
fill 12 279 605 14 280 609 minecraft:white_wool
fill 12 279 610 14 280 612 minecraft:light_blue_wool
fill 12 279 613 14 280 618 minecraft:white_wool
fill 12 279 619 14 280 621 minecraft:light_blue_wool
fill 12 279 622 14 280 627 minecraft:white_wool
fill 12 279 628 14 280 630 minecraft:light_blue_wool
fill 12 279 631 17 280 633 minecraft:white_wool
fill 12 279 637 14 280 639 minecraft:light_blue_wool
fill 12 279 640 17 280 642 minecraft:white_wool
fill 15 279 605 17 280 606 minecraft:white_wool
fill 15 279 607 17 280 609 minecraft:light_blue_wool
fill 15 279 610 17 280 615 minecraft:white_wool
fill 15 279 616 17 280 618 minecraft:light_blue_wool
fill 15 279 619 16 279 624 minecraft:white_wool
fill 15 279 625 16 279 627 minecraft:light_blue_wool
fill 15 279 628 20 280 630 minecraft:white_wool
fill 15 279 634 17 280 636 minecraft:light_blue_wool
fill 15 279 637 20 280 639 minecraft:white_wool
fill 15 279 643 17 280 645 minecraft:light_blue_wool
fill 17 279 619 17 279 623 minecraft:white_wool
setblock 17 279 627 minecraft:light_blue_wool
fill 18 279 605 20 280 606 minecraft:light_blue_wool
fill 18 279 607 20 280 612 minecraft:white_wool
fill 18 279 613 20 280 615 minecraft:light_blue_wool
fill 18 279 616 20 279 621 minecraft:white_wool
fill 18 279 622 20 279 623 minecraft:light_blue_wool
fill 18 279 627 23 279 627 minecraft:white_wool
fill 18 279 631 20 280 633 minecraft:light_blue_wool
fill 18 279 634 23 280 636 minecraft:white_wool
fill 18 279 640 20 280 642 minecraft:light_blue_wool
fill 18 279 643 23 280 645 minecraft:white_wool
setblock 20 279 624 minecraft:light_blue_wool
fill 20 279 625 21 279 626 minecraft:white_wool
fill 21 279 605 23 280 609 minecraft:white_wool
fill 21 279 610 23 280 612 minecraft:light_blue_wool
fill 21 279 613 23 279 618 minecraft:white_wool
fill 21 279 622 21 279 624 minecraft:white_wool
fill 21 279 628 21 279 630 minecraft:light_blue_wool
fill 21 279 631 21 279 633 minecraft:white_wool
fill 21 279 637 23 280 639 minecraft:light_blue_wool
fill 21 279 640 26 280 642 minecraft:white_wool
fill 22 279 622 25 279 623 minecraft:white_wool
fill 22 279 628 23 279 628 minecraft:light_blue_wool
fill 22 279 632 26 279 633 minecraft:white_wool
fill 24 279 605 26 280 606 minecraft:white_wool
fill 24 279 607 26 280 609 minecraft:light_blue_wool
fill 24 279 610 26 280 615 minecraft:white_wool
fill 24 279 616 26 279 618 minecraft:light_blue_wool
fill 24 279 619 25 279 621 minecraft:white_wool
fill 24 279 627 26 279 627 minecraft:light_blue_wool
fill 24 279 628 29 279 628 minecraft:white_wool
fill 24 279 634 26 280 636 minecraft:light_blue_wool
fill 24 279 637 29 280 639 minecraft:white_wool
fill 24 279 643 26 280 645 minecraft:light_blue_wool
fill 25 279 624 26 279 624 minecraft:white_wool
fill 25 279 625 26 279 626 minecraft:light_blue_wool
fill 25 279 629 26 279 631 minecraft:white_wool
fill 26 279 619 29 279 620 minecraft:white_wool
fill 27 279 605 29 280 606 minecraft:light_blue_wool
fill 27 279 607 29 280 612 minecraft:white_wool
fill 27 279 613 29 280 615 minecraft:light_blue_wool
fill 27 279 616 32 280 618 minecraft:white_wool
fill 27 279 624 29 279 624 minecraft:light_blue_wool
fill 27 279 625 32 280 627 minecraft:white_wool
fill 27 279 629 29 280 630 minecraft:white_wool
fill 27 279 631 29 280 633 minecraft:light_blue_wool
fill 27 279 634 32 280 636 minecraft:white_wool
fill 27 279 640 29 280 642 minecraft:light_blue_wool
fill 27 279 643 32 280 645 minecraft:white_wool
setblock 29 279 621 minecraft:white_wool
fill 29 279 622 29 279 623 minecraft:light_blue_wool
fill 30 279 605 32 280 609 minecraft:white_wool
fill 30 279 610 32 280 612 minecraft:light_blue_wool
fill 30 279 613 35 280 615 minecraft:white_wool
fill 30 279 619 32 280 621 minecraft:light_blue_wool
fill 30 279 622 35 280 624 minecraft:white_wool
fill 30 279 628 32 280 630 minecraft:light_blue_wool
fill 30 279 631 35 280 633 minecraft:white_wool
fill 30 279 637 32 280 639 minecraft:light_blue_wool
fill 30 279 640 35 280 642 minecraft:white_wool
fill 33 279 605 35 280 606 minecraft:white_wool
fill 33 279 607 35 280 609 minecraft:light_blue_wool
fill 33 279 610 38 280 612 minecraft:white_wool
fill 33 279 616 35 280 618 minecraft:light_blue_wool
fill 33 279 619 38 280 621 minecraft:white_wool
fill 33 279 625 35 280 627 minecraft:light_blue_wool
fill 33 279 628 38 280 630 minecraft:white_wool
fill 33 279 634 35 280 636 minecraft:light_blue_wool
fill 33 279 637 38 280 639 minecraft:white_wool
fill 33 279 643 35 280 645 minecraft:light_blue_wool
fill 36 279 605 38 280 606 minecraft:light_blue_wool
fill 36 279 607 41 280 609 minecraft:white_wool
fill 36 279 613 38 280 615 minecraft:light_blue_wool
fill 36 279 616 41 280 618 minecraft:white_wool
fill 36 279 622 38 280 624 minecraft:light_blue_wool
fill 36 279 625 41 280 627 minecraft:white_wool
fill 36 279 631 38 280 633 minecraft:light_blue_wool
fill 36 279 634 41 280 636 minecraft:white_wool
fill 36 279 640 38 280 642 minecraft:light_blue_wool
fill 36 279 643 41 280 645 minecraft:white_wool
fill 39 279 605 41 280 606 minecraft:white_wool
fill 39 279 610 41 280 612 minecraft:light_blue_wool
fill 39 279 613 41 280 615 minecraft:white_wool
fill 39 279 619 41 280 621 minecraft:light_blue_wool
fill 39 279 622 41 280 624 minecraft:white_wool
fill 39 279 628 41 280 630 minecraft:light_blue_wool
fill 39 279 631 41 280 633 minecraft:white_wool
fill 39 279 637 41 280 639 minecraft:light_blue_wool
fill 39 279 640 41 280 642 minecraft:white_wool
fill 42 279 619 42 304 619 minecraft:black_concrete
fill 42 279 633 42 307 633 minecraft:black_concrete
fill 42 279 640 42 307 640 minecraft:black_concrete
setblock 42 279 641 minecraft:diamond_block
fill 0 280 632 0 307 632 minecraft:black_concrete
setblock 0 280 644 minecraft:glowstone
fill 15 280 619 15 280 624 minecraft:white_wool
fill 15 280 625 15 280 627 minecraft:light_blue_wool
fill 16 280 619 17 280 622 minecraft:white_wool
fill 16 280 623 16 280 627 minecraft:glowstone
fill 17 280 623 25 280 623 minecraft:glowstone
fill 17 280 624 19 280 626 minecraft:white_wool
fill 17 280 627 25 280 627 minecraft:glowstone
fill 18 280 616 19 280 621 minecraft:white_wool
fill 18 280 622 19 280 622 minecraft:light_blue_wool
fill 20 280 616 23 280 617 minecraft:white_wool
fill 20 280 618 20 280 622 minecraft:glowstone
fill 20 280 624 21 280 626 minecraft:glowstone
fill 21 280 613 23 280 615 minecraft:white_wool
fill 21 280 618 24 280 618 minecraft:glowstone
fill 21 280 619 23 280 621 minecraft:white_wool
fill 21 280 622 25 280 622 minecraft:glowstone
fill 21 280 628 21 280 632 minecraft:glowstone
fill 21 280 633 26 280 633 minecraft:white_wool
setblock 22 280 604 minecraft:glowstone
fill 22 280 628 25 280 628 minecraft:glowstone
fill 22 280 629 24 280 631 minecraft:white_wool
fill 22 280 632 25 280 632 minecraft:glowstone
fill 24 280 616 26 280 617 minecraft:light_blue_wool
fill 24 280 619 24 280 621 minecraft:glowstone
fill 25 280 618 26 280 618 minecraft:light_blue_wool
fill 25 280 619 29 280 619 minecraft:white_wool
fill 25 280 620 25 280 621 minecraft:glowstone
fill 25 280 624 25 280 626 minecraft:glowstone
fill 25 280 629 25 280 631 minecraft:glowstone
fill 26 280 620 29 280 620 minecraft:glowstone
fill 26 280 621 28 280 623 minecraft:white_wool
fill 26 280 624 29 280 624 minecraft:glowstone
fill 26 280 625 26 280 627 minecraft:light_blue_wool
fill 26 280 628 26 280 632 minecraft:white_wool
fill 27 280 628 29 280 628 minecraft:white_wool
fill 29 280 621 29 280 623 minecraft:glowstone
setblock 32 280 604 minecraft:glowstone
fill 42 280 641 42 307 641 minecraft:black_concrete
setblock 0 281 629 minecraft:diamond_block
fill 0 281 630 0 303 631 minecraft:black_concrete
fill 0 281 644 0 287 644 minecraft:black_concrete
setblock 6 281 604 minecraft:white_concrete
fill 22 281 604 22 295 604 minecraft:black_concrete
fill 32 281 604 32 285 604 minecraft:black_concrete
fill 0 282 629 0 307 629 minecraft:black_concrete
fill 6 282 604 6 285 604 minecraft:black_concrete
fill 20 282 646 20 307 646 minecraft:black_concrete
setblock 21 282 646 minecraft:white_concrete
setblock 28 282 646 minecraft:glowstone
setblock 8 283 604 minecraft:white_concrete
fill 21 283 646 21 307 646 minecraft:black_concrete
fill 28 283 646 28 307 646 minecraft:black_concrete
fill 8 284 604 8 307 604 minecraft:black_concrete
fill 16 284 615 17 285 615 minecraft:raw_iron_block
setblock 19 284 646 minecraft:glowstone
fill 34 284 631 35 291 632 minecraft:dirt
setblock 15 285 646 minecraft:diamond_block
fill 19 285 646 19 307 646 minecraft:black_concrete
fill 33 285 632 33 291 632 minecraft:dirt
fill 34 285 633 35 291 633 minecraft:dirt
setblock 36 285 646 minecraft:diamond_block
setblock 6 286 604 minecraft:glowstone
fill 15 286 646 15 307 646 minecraft:black_concrete
setblock 32 286 604 minecraft:glowstone
fill 33 286 631 33 291 631 minecraft:dirt
fill 33 286 633 33 291 633 minecraft:dirt
fill 34 286 630 35 291 630 minecraft:dirt
fill 36 286 631 36 291 632 minecraft:dirt
fill 36 286 646 36 307 646 minecraft:black_concrete
setblock 0 287 614 minecraft:glowstone
setblock 0 287 615 minecraft:diamond_block
fill 0 287 616 0 307 617 minecraft:black_concrete
fill 6 287 604 6 307 604 minecraft:black_concrete
fill 9 287 620 9 288 620 minecraft:diamond_block
fill 16 287 616 17 288 617 minecraft:stone
fill 32 287 604 32 306 604 minecraft:black_concrete
fill 33 287 630 33 291 630 minecraft:dirt
fill 34 287 634 35 291 634 minecraft:dirt
fill 36 287 630 36 291 630 minecraft:dirt
fill 36 287 633 36 291 633 minecraft:dirt
fill 37 287 604 37 307 604 minecraft:black_concrete
setblock 38 287 604 minecraft:diamond_block
fill 0 288 612 0 290 612 minecraft:moss_block
fill 0 288 614 0 293 615 minecraft:black_concrete
setblock 0 288 625 minecraft:white_concrete
fill 0 288 628 0 290 628 minecraft:moss_block
fill 0 288 644 0 290 644 minecraft:moss_block
setblock 2 288 604 minecraft:diamond_block
setblock 3 288 607 minecraft:light[level=14]
setblock 3 288 615 minecraft:light[level=14]
setblock 3 288 623 minecraft:light[level=14]
setblock 3 288 631 minecraft:light[level=14]
setblock 3 288 639 minecraft:light[level=14]
fill 4 288 604 4 290 604 minecraft:moss_block
setblock 11 288 607 minecraft:light[level=14]
setblock 11 288 615 minecraft:light[level=14]
setblock 11 288 623 minecraft:light[level=14]
setblock 11 288 631 minecraft:light[level=14]
setblock 11 288 639 minecraft:light[level=14]
fill 14 288 646 14 290 646 minecraft:moss_block
setblock 19 288 607 minecraft:light[level=14]
setblock 19 288 615 minecraft:light[level=14]
setblock 19 288 623 minecraft:light[level=14]
setblock 19 288 631 minecraft:light[level=14]
setblock 19 288 639 minecraft:light[level=14]
fill 20 288 604 20 290 604 minecraft:moss_block
setblock 27 288 607 minecraft:light[level=14]
setblock 27 288 615 minecraft:light[level=14]
setblock 27 288 623 minecraft:light[level=14]
setblock 27 288 631 minecraft:light[level=14]
setblock 27 288 639 minecraft:light[level=14]
fill 30 288 646 30 290 646 minecraft:moss_block
fill 32 288 631 32 291 633 minecraft:dirt
fill 33 288 634 33 291 634 minecraft:dirt
fill 34 288 629 35 291 629 minecraft:dirt
setblock 35 288 607 minecraft:light[level=14]
setblock 35 288 615 minecraft:light[level=14]
setblock 35 288 623 minecraft:light[level=14]
setblock 35 288 639 minecraft:light[level=14]
fill 36 288 604 36 290 604 minecraft:moss_block
fill 36 288 634 36 291 634 minecraft:dirt
fill 37 288 631 37 291 633 minecraft:dirt
fill 38 288 604 38 307 604 minecraft:black_concrete
setblock 38 288 646 minecraft:glowstone
fill 42 288 613 42 307 613 minecraft:black_concrete
fill 42 288 614 42 290 614 minecraft:moss_block
fill 42 288 630 42 290 630 minecraft:moss_block
setblock 42 288 637 minecraft:glowstone
fill 0 289 625 0 307 625 minecraft:black_concrete
fill 2 289 604 2 307 604 minecraft:black_concrete
fill 9 289 620 9 296 620 minecraft:dirt
setblock 17 289 604 minecraft:white_concrete
fill 32 289 630 32 291 630 minecraft:dirt
fill 32 289 634 32 291 634 minecraft:dirt
fill 33 289 629 33 291 629 minecraft:dirt
fill 34 289 635 35 291 635 minecraft:dirt
fill 36 289 629 36 291 629 minecraft:dirt
fill 37 289 630 37 291 630 minecraft:dirt
fill 38 289 646 38 307 646 minecraft:black_concrete
setblock 42 289 608 minecraft:diamond_block
setblock 42 289 627 minecraft:glowstone
fill 42 289 637 42 307 637 minecraft:black_concrete
setblock 0 290 607 minecraft:glowstone
setblock 0 290 637 minecraft:diamond_block
fill 8 290 620 8 296 620 minecraft:dirt
fill 9 290 618 10 291 618 minecraft:moss_block
fill 9 290 619 9 296 619 minecraft:dirt
fill 9 290 621 9 296 621 minecraft:dirt
setblock 10 290 619 minecraft:moss_block
fill 10 290 620 10 296 620 minecraft:dirt
fill 17 290 604 17 307 604 minecraft:black_concrete
fill 21 290 644 21 295 644 minecraft:diamond_block
fill 31 290 630 31 291 633 minecraft:dirt
fill 32 290 629 32 291 629 minecraft:dirt
fill 33 290 635 33 291 635 minecraft:dirt
fill 34 290 628 35 291 628 minecraft:dirt
fill 36 290 635 36 291 635 minecraft:dirt
fill 37 290 629 37 291 629 minecraft:dirt
fill 37 290 634 37 291 634 minecraft:dirt
setblock 37 290 646 minecraft:glowstone
fill 38 290 631 38 291 633 minecraft:dirt
fill 42 290 608 42 299 608 minecraft:black_concrete
fill 42 290 627 42 296 627 minecraft:black_concrete
setblock 42 290 645 minecraft:diamond_block
fill 0 291 607 0 307 607 minecraft:black_concrete
fill 0 291 612 0 296 612 minecraft:black_concrete
fill 0 291 628 0 296 628 minecraft:black_concrete
fill 0 291 637 0 307 637 minecraft:black_concrete
fill 0 291 644 0 296 644 minecraft:black_concrete
fill 4 291 604 4 296 604 minecraft:black_concrete
fill 8 291 619 8 296 619 minecraft:dirt
fill 8 291 621 8 296 621 minecraft:dirt
fill 10 291 619 10 296 619 minecraft:dirt
fill 10 291 621 10 296 621 minecraft:dirt
fill 14 291 646 14 296 646 minecraft:black_concrete
fill 19 291 644 20 294 644 minecraft:diamond_block
fill 20 291 604 20 296 604 minecraft:black_concrete
fill 20 291 643 22 294 643 minecraft:diamond_block
fill 20 291 645 22 294 645 minecraft:diamond_block
fill 21 291 642 21 295 642 minecraft:diamond_block
fill 22 291 644 23 294 644 minecraft:diamond_block
fill 30 291 646 30 296 646 minecraft:black_concrete
setblock 31 291 629 minecraft:dirt
setblock 31 291 634 minecraft:dirt
setblock 32 291 635 minecraft:dirt
setblock 33 291 628 minecraft:dirt
setblock 34 291 636 minecraft:dirt
fill 36 291 604 36 296 604 minecraft:black_concrete
setblock 36 291 628 minecraft:dirt
setblock 37 291 635 minecraft:dirt
fill 37 291 646 37 307 646 minecraft:black_concrete
setblock 38 291 630 minecraft:dirt
setblock 38 291 634 minecraft:dirt
fill 42 291 614 42 296 614 minecraft:black_concrete
fill 42 291 630 42 296 630 minecraft:black_concrete
fill 42 291 645 42 307 645 minecraft:black_concrete
fill 9 292 622 9 296 622 minecraft:dirt
fill 11 292 620 11 296 620 minecraft:dirt
setblock 12 292 646 minecraft:glowstone
fill 13 292 646 13 307 646 minecraft:black_concrete
fill 19 292 643 19 293 643 minecraft:diamond_block
fill 19 292 645 19 293 645 minecraft:diamond_block
fill 20 292 642 20 294 642 minecraft:diamond_block
fill 21 292 641 21 295 641 minecraft:diamond_block
fill 22 292 642 22 294 642 minecraft:diamond_block
fill 23 292 643 23 293 643 minecraft:diamond_block
fill 23 292 645 23 293 645 minecraft:diamond_block
setblock 33 292 604 minecraft:white_concrete
fill 34 292 632 34 294 632 minecraft:stone
setblock 42 292 626 minecraft:white_concrete
setblock 42 292 643 minecraft:white_concrete
setblock 3 293 646 minecraft:diamond_block
fill 7 293 619 7 296 621 minecraft:dirt
fill 8 293 618 10 296 618 minecraft:dirt
fill 8 293 622 8 296 622 minecraft:dirt
fill 10 293 622 10 296 622 minecraft:dirt
fill 11 293 619 11 296 619 minecraft:dirt
fill 11 293 621 11 296 621 minecraft:dirt
fill 12 293 646 12 307 646 minecraft:black_concrete
fill 20 293 641 20 294 641 minecraft:diamond_block
fill 21 293 640 21 295 640 minecraft:diamond_block
fill 22 293 641 22 294 641 minecraft:diamond_block
fill 33 293 604 33 299 604 minecraft:black_concrete
fill 36 293 632 37 294 633 minecraft:gold_block
setblock 42 293 611 minecraft:white_concrete
fill 42 293 626 42 307 626 minecraft:black_concrete
fill 42 293 643 42 307 643 minecraft:black_concrete
fill 0 294 614 0 307 614 minecraft:black_concrete
setblock 0 294 615 minecraft:diamond_block
setblock 0 294 638 minecraft:glowstone
fill 3 294 646 3 307 646 minecraft:black_concrete
fill 7 294 618 7 296 618 minecraft:dirt
fill 7 294 622 7 296 622 minecraft:dirt
fill 11 294 618 11 296 618 minecraft:dirt
fill 11 294 622 11 296 622 minecraft:dirt
setblock 20 294 640 minecraft:diamond_block
setblock 21 294 639 minecraft:diamond_block
setblock 22 294 640 minecraft:diamond_block
fill 42 294 611 42 301 611 minecraft:black_concrete
fill 0 295 615 0 307 615 minecraft:black_concrete
fill 0 295 638 0 307 638 minecraft:black_concrete
setblock 1 295 646 minecraft:diamond_block
fill 6 295 619 6 296 621 minecraft:dirt
fill 8 295 617 10 296 617 minecraft:dirt
fill 8 295 623 10 296 623 minecraft:dirt
fill 12 295 619 12 296 621 minecraft:dirt
setblock 21 295 643 minecraft:diamond_block
fill 33 295 631 35 297 633 minecraft:oak_leaves[persistent=true]
fill 34 295 630 35 297 630 minecraft:oak_leaves[persistent=true]
fill 36 295 631 36 297 632 minecraft:oak_leaves[persistent=true]
fill 1 296 646 1 307 646 minecraft:black_concrete
setblock 3 296 607 minecraft:light[level=14]
setblock 3 296 615 minecraft:light[level=14]
setblock 3 296 623 minecraft:light[level=14]
setblock 3 296 631 minecraft:light[level=14]
setblock 3 296 639 minecraft:light[level=14]
setblock 6 296 618 minecraft:dirt
setblock 6 296 622 minecraft:dirt
setblock 7 296 617 minecraft:dirt
setblock 7 296 623 minecraft:dirt
setblock 11 296 607 minecraft:light[level=14]
setblock 11 296 615 minecraft:light[level=14]
setblock 11 296 617 minecraft:dirt
setblock 11 296 623 minecraft:dirt
setblock 11 296 631 minecraft:light[level=14]
setblock 11 296 639 minecraft:light[level=14]
setblock 12 296 618 minecraft:dirt
setblock 12 296 622 minecraft:dirt
setblock 15 296 604 minecraft:diamond_block
setblock 19 296 607 minecraft:light[level=14]
setblock 19 296 615 minecraft:light[level=14]
setblock 19 296 623 minecraft:light[level=14]
setblock 19 296 631 minecraft:light[level=14]
setblock 19 296 639 minecraft:light[level=14]
setblock 22 296 604 minecraft:diamond_block
setblock 27 296 607 minecraft:light[level=14]
setblock 27 296 615 minecraft:light[level=14]
setblock 27 296 623 minecraft:light[level=14]
setblock 27 296 631 minecraft:light[level=14]
setblock 27 296 639 minecraft:light[level=14]
setblock 33 296 630 minecraft:oak_leaves[persistent=true]
fill 34 296 634 35 296 634 minecraft:oak_leaves[persistent=true]
setblock 35 296 607 minecraft:light[level=14]
setblock 35 296 615 minecraft:light[level=14]
setblock 35 296 623 minecraft:light[level=14]
setblock 35 296 639 minecraft:light[level=14]
setblock 36 296 630 minecraft:oak_leaves[persistent=true]
setblock 36 296 633 minecraft:oak_leaves[persistent=true]
setblock 0 297 610 minecraft:white_concrete
fill 0 297 612 0 299 612 minecraft:moss_block
fill 0 297 628 0 299 628 minecraft:moss_block
fill 0 297 644 0 299 644 minecraft:moss_block
fill 4 297 604 4 299 604 minecraft:moss_block
fill 9 297 620 9 300 620 minecraft:stone
fill 14 297 646 14 299 646 minecraft:moss_block
fill 15 297 604 15 307 604 minecraft:black_concrete
fill 20 297 604 20 299 604 minecraft:moss_block
fill 22 297 604 22 307 604 minecraft:black_concrete
fill 30 297 646 30 299 646 minecraft:moss_block
setblock 34 297 646 minecraft:diamond_block
fill 36 297 604 36 299 604 minecraft:moss_block
fill 42 297 614 42 299 614 minecraft:moss_block
setblock 42 297 627 minecraft:glowstone
fill 42 297 630 42 299 630 minecraft:moss_block
setblock 42 297 634 minecraft:diamond_block
fill 0 298 610 0 307 610 minecraft:black_concrete
setblock 7 298 604 minecraft:diamond_block
fill 9 298 633 10 299 634 minecraft:moss_block
fill 34 298 646 34 307 646 minecraft:black_concrete
fill 42 298 627 42 302 627 minecraft:black_concrete
setblock 42 298 634 minecraft:glowstone
setblock 5 299 604 minecraft:diamond_block
fill 7 299 604 7 307 604 minecraft:black_concrete
fill 42 299 634 42 307 634 minecraft:black_concrete
fill 0 300 612 0 306 612 minecraft:black_concrete
fill 0 300 628 0 303 628 minecraft:black_concrete
fill 0 300 644 0 307 644 minecraft:black_concrete
fill 4 300 604 5 307 604 minecraft:black_concrete
fill 8 300 619 8 300 621 minecraft:oak_leaves[persistent=true]
fill 9 300 619 10 300 619 minecraft:oak_leaves[persistent=true]
fill 9 300 621 9 300 622 minecraft:oak_leaves[persistent=true]
fill 10 300 620 10 300 621 minecraft:oak_leaves[persistent=true]
setblock 11 300 620 minecraft:oak_leaves[persistent=true]
fill 14 300 646 14 307 646 minecraft:black_concrete
fill 20 300 604 20 307 604 minecraft:black_concrete
fill 30 300 646 30 307 646 minecraft:black_concrete
setblock 33 300 604 minecraft:diamond_block
fill 36 300 604 36 307 604 minecraft:black_concrete
setblock 42 300 608 minecraft:glowstone
fill 42 300 614 42 307 614 minecraft:black_concrete
setblock 42 300 623 minecraft:white_concrete
fill 42 300 630 42 307 630 minecraft:black_concrete
fill 33 301 604 33 307 604 minecraft:black_concrete
fill 42 301 608 42 307 608 minecraft:black_concrete
fill 42 301 623 42 307 623 minecraft:black_concrete
setblock 42 302 611 minecraft:diamond_block
setblock 42 303 605 minecraft:diamond_block
fill 42 303 611 42 307 611 minecraft:black_concrete
setblock 42 303 627 minecraft:glowstone
setblock 0 304 628 minecraft:diamond_block
fill 0 304 630 0 307 630 minecraft:black_concrete
setblock 0 304 631 minecraft:diamond_block
setblock 0 304 643 minecraft:glowstone
setblock 8 304 646 minecraft:diamond_block
fill 42 304 605 42 307 605 minecraft:black_concrete
fill 42 304 627 42 307 627 minecraft:black_concrete
fill 0 305 628 0 307 628 minecraft:black_concrete
fill 0 305 631 0 307 631 minecraft:black_concrete
fill 0 305 643 0 307 643 minecraft:black_concrete
fill 8 305 646 8 307 646 minecraft:black_concrete
setblock 42 305 619 minecraft:white_concrete
setblock 0 306 635 minecraft:glowstone
setblock 0 306 639 minecraft:glowstone
setblock 39 306 604 minecraft:glowstone
fill 42 306 619 42 307 619 minecraft:black_concrete
setblock 0 307 612 minecraft:diamond_block
setblock 0 307 635 minecraft:black_concrete
setblock 0 307 639 minecraft:black_concrete
setblock 32 307 604 minecraft:glowstone
setblock 39 307 604 minecraft:black_concrete
