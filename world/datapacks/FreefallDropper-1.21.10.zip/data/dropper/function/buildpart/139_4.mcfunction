setblock 370 141 589 minecraft:oak_log
fill 370 141 590 370 144 590 minecraft:green_terracotta
setblock 370 141 594 minecraft:oak_log
fill 370 141 595 370 144 595 minecraft:green_terracotta
setblock 330 142 558 minecraft:oak_log
fill 330 142 559 330 143 559 minecraft:green_terracotta
setblock 330 142 563 minecraft:oak_log
fill 330 142 564 330 145 564 minecraft:green_terracotta
setblock 330 142 568 minecraft:oak_log
fill 330 142 569 330 145 569 minecraft:green_terracotta
fill 330 142 574 330 142 577 minecraft:green_terracotta
setblock 330 142 578 minecraft:oak_log
fill 330 142 579 330 142 582 minecraft:green_terracotta
setblock 330 142 583 minecraft:oak_log
fill 330 142 584 330 142 587 minecraft:green_terracotta
setblock 330 142 588 minecraft:oak_log
fill 330 142 589 330 145 589 minecraft:green_terracotta
setblock 330 142 593 minecraft:oak_log
setblock 330 142 594 minecraft:green_terracotta
setblock 330 142 595 minecraft:oak_leaves[persistent=true]
setblock 330 142 598 minecraft:oak_log
fill 331 142 578 331 143 578 minecraft:green_terracotta
setblock 331 142 582 minecraft:oak_log
fill 331 142 583 331 145 583 minecraft:green_terracotta
setblock 331 142 587 minecraft:oak_log
fill 331 142 588 331 145 588 minecraft:green_terracotta
setblock 332 142 581 minecraft:oak_log
fill 332 142 582 332 143 582 minecraft:green_terracotta
setblock 332 142 586 minecraft:oak_log
fill 338 142 558 339 142 558 minecraft:green_terracotta
setblock 340 142 558 minecraft:oak_log
fill 340 142 559 340 145 559 minecraft:green_terracotta
fill 341 142 558 344 142 558 minecraft:green_terracotta
fill 341 142 560 341 143 560 minecraft:green_terracotta
fill 342 142 598 344 142 598 minecraft:green_terracotta
setblock 343 142 560 minecraft:oak_log
fill 343 142 561 343 145 561 minecraft:green_terracotta
setblock 344 142 559 minecraft:oak_log
fill 344 142 560 344 145 560 minecraft:green_terracotta
setblock 345 142 558 minecraft:oak_log
fill 345 142 559 348 142 559 minecraft:green_terracotta
setblock 345 142 598 minecraft:oak_log
fill 346 142 558 349 142 558 minecraft:green_terracotta
fill 346 142 598 346 145 598 minecraft:green_terracotta
setblock 347 142 560 minecraft:green_terracotta
setblock 347 142 561 minecraft:oak_log
setblock 348 142 560 minecraft:oak_log
fill 348 142 561 348 144 561 minecraft:green_terracotta
setblock 349 142 559 minecraft:oak_log
fill 349 142 560 349 145 560 minecraft:green_terracotta
setblock 349 142 598 minecraft:green_terracotta
setblock 350 142 558 minecraft:oak_log
fill 350 142 559 353 142 559 minecraft:green_terracotta
setblock 350 142 598 minecraft:oak_log
fill 351 142 558 354 142 558 minecraft:green_terracotta
setblock 352 142 560 minecraft:green_terracotta
setblock 352 142 598 minecraft:oak_leaves[persistent=true]
setblock 353 142 560 minecraft:oak_log
setblock 354 142 559 minecraft:oak_log
setblock 355 142 558 minecraft:oak_log
fill 355 142 559 358 142 559 minecraft:green_terracotta
fill 356 142 558 356 145 558 minecraft:green_terracotta
setblock 357 142 560 minecraft:green_terracotta
setblock 358 142 560 minecraft:oak_log
setblock 359 142 559 minecraft:oak_log
fill 359 142 560 359 145 560 minecraft:green_terracotta
setblock 360 142 558 minecraft:oak_log
fill 360 142 559 360 145 559 minecraft:green_terracotta
setblock 360 142 597 minecraft:green_terracotta
setblock 360 142 598 minecraft:oak_log
fill 361 142 558 361 145 558 minecraft:green_terracotta
setblock 361 142 597 minecraft:oak_log
fill 361 142 598 361 145 598 minecraft:green_terracotta
setblock 362 142 561 minecraft:oak_log
fill 362 142 597 362 145 597 minecraft:green_terracotta
setblock 363 142 560 minecraft:oak_log
fill 363 142 561 365 143 561 minecraft:green_terracotta
setblock 364 142 559 minecraft:oak_log
fill 364 142 560 364 145 560 minecraft:green_terracotta
fill 364 142 596 364 144 596 minecraft:green_terracotta
setblock 365 142 558 minecraft:oak_log
fill 365 142 559 365 145 559 minecraft:green_terracotta
setblock 365 142 598 minecraft:oak_log
fill 366 142 558 366 145 558 minecraft:green_terracotta
setblock 366 142 597 minecraft:oak_log
fill 366 142 598 366 145 598 minecraft:green_terracotta
fill 367 142 584 367 142 585 minecraft:green_terracotta
setblock 367 142 586 minecraft:oak_log
fill 367 142 587 367 145 587 minecraft:green_terracotta
setblock 367 142 596 minecraft:oak_log
fill 367 142 597 367 145 597 minecraft:green_terracotta
setblock 368 142 560 minecraft:oak_log
fill 368 142 561 368 143 561 minecraft:green_terracotta
fill 368 142 581 368 143 581 minecraft:green_terracotta
setblock 368 142 584 minecraft:green_terracotta
setblock 368 142 585 minecraft:oak_log
fill 368 142 586 368 145 586 minecraft:green_terracotta
setblock 368 142 589 minecraft:green_terracotta
setblock 368 142 590 minecraft:oak_log
fill 368 142 591 368 145 591 minecraft:green_terracotta
setblock 369 142 559 minecraft:oak_log
fill 369 142 560 369 144 560 minecraft:green_terracotta
setblock 369 142 564 minecraft:oak_log
fill 369 142 565 369 144 565 minecraft:green_terracotta
setblock 369 142 579 minecraft:oak_log
fill 369 142 580 369 144 580 minecraft:green_terracotta
setblock 369 142 584 minecraft:oak_log
fill 369 142 585 369 145 585 minecraft:green_terracotta
setblock 369 142 589 minecraft:oak_log
fill 369 142 590 369 145 590 minecraft:green_terracotta
setblock 369 142 594 minecraft:oak_log
fill 369 142 595 369 144 595 minecraft:green_terracotta
setblock 370 142 558 minecraft:oak_log
fill 370 142 559 370 144 559 minecraft:green_terracotta
setblock 370 142 563 minecraft:oak_log
fill 370 142 564 370 145 564 minecraft:green_terracotta
setblock 370 142 567 minecraft:green_terracotta
setblock 370 142 578 minecraft:oak_log
fill 370 142 579 370 145 579 minecraft:green_terracotta
setblock 370 142 583 minecraft:oak_log
fill 370 142 584 370 145 584 minecraft:green_terracotta
setblock 370 142 588 minecraft:oak_log
fill 370 142 589 370 145 589 minecraft:green_terracotta
setblock 370 142 593 minecraft:oak_log
fill 370 142 594 370 145 594 minecraft:green_terracotta
setblock 370 142 598 minecraft:oak_log
setblock 330 143 562 minecraft:oak_log
fill 330 143 563 330 146 563 minecraft:green_terracotta
fill 330 143 565 330 143 566 minecraft:green_terracotta
setblock 330 143 567 minecraft:oak_log
fill 330 143 568 330 146 568 minecraft:green_terracotta
fill 330 143 570 330 144 570 minecraft:green_terracotta
fill 330 143 574 330 143 576 minecraft:green_terracotta
setblock 330 143 577 minecraft:oak_log
fill 330 143 578 330 143 581 minecraft:green_terracotta
setblock 330 143 582 minecraft:oak_log
fill 330 143 583 330 143 586 minecraft:green_terracotta
setblock 330 143 587 minecraft:oak_log
fill 330 143 588 330 146 588 minecraft:green_terracotta
setblock 330 143 592 minecraft:oak_log
fill 330 143 593 330 144 593 minecraft:green_terracotta
setblock 331 143 581 minecraft:oak_log
fill 331 143 582 331 146 582 minecraft:green_terracotta
setblock 331 143 585 minecraft:green_terracotta
setblock 331 143 586 minecraft:oak_log
fill 331 143 587 331 146 587 minecraft:green_terracotta
setblock 331 143 590 minecraft:green_terracotta
setblock 332 143 585 minecraft:oak_log
fill 332 143 586 332 144 586 minecraft:green_terracotta
setblock 333 143 598 minecraft:oak_leaves[persistent=true]
setblock 338 143 558 minecraft:green_terracotta
setblock 339 143 558 minecraft:oak_log
fill 339 143 559 339 146 559 minecraft:green_terracotta
fill 340 143 558 343 143 558 minecraft:green_terracotta
fill 340 143 560 340 144 560 minecraft:green_terracotta
setblock 342 143 560 minecraft:oak_log
fill 342 143 561 342 145 561 minecraft:green_terracotta
fill 342 143 598 343 143 598 minecraft:green_terracotta
setblock 343 143 559 minecraft:oak_log
fill 343 143 560 343 146 560 minecraft:green_terracotta
setblock 344 143 558 minecraft:oak_log
fill 344 143 559 347 143 559 minecraft:green_terracotta
setblock 344 143 598 minecraft:oak_log
fill 345 143 558 348 143 558 minecraft:green_terracotta
setblock 345 143 561 minecraft:green_terracotta
setblock 345 143 562 minecraft:oak_log
fill 345 143 598 345 145 598 minecraft:green_terracotta
setblock 346 143 561 minecraft:oak_log
setblock 347 143 560 minecraft:oak_log
fill 347 143 561 347 145 561 minecraft:green_terracotta
setblock 348 143 559 minecraft:oak_log
fill 348 143 560 348 145 560 minecraft:green_terracotta
setblock 349 143 558 minecraft:oak_log
fill 349 143 559 352 143 559 minecraft:green_terracotta
setblock 349 143 561 minecraft:green_terracotta
setblock 349 143 598 minecraft:oak_log
fill 350 143 558 353 143 558 minecraft:green_terracotta
setblock 352 143 560 minecraft:oak_log
setblock 353 143 559 minecraft:oak_log
setblock 354 143 558 minecraft:oak_log
fill 354 143 559 357 143 559 minecraft:green_terracotta
fill 355 143 558 355 146 558 minecraft:green_terracotta
fill 356 143 598 356 145 598 minecraft:green_terracotta
setblock 357 143 560 minecraft:oak_log
setblock 358 143 559 minecraft:oak_log
fill 358 143 560 358 145 560 minecraft:green_terracotta
setblock 359 143 558 minecraft:oak_log
fill 359 143 559 359 146 559 minecraft:green_terracotta
setblock 359 143 598 minecraft:oak_log
fill 360 143 558 360 146 558 minecraft:green_terracotta
setblock 360 143 597 minecraft:oak_log
fill 360 143 598 360 146 598 minecraft:green_terracotta
setblock 361 143 561 minecraft:oak_log
fill 361 143 597 361 146 597 minecraft:green_terracotta
setblock 362 143 560 minecraft:oak_log
fill 362 143 561 362 144 561 minecraft:green_terracotta
setblock 363 143 559 minecraft:oak_log
fill 363 143 560 363 146 560 minecraft:green_terracotta
fill 363 143 596 363 145 596 minecraft:green_terracotta
setblock 364 143 558 minecraft:oak_log
fill 364 143 559 364 146 559 minecraft:green_terracotta
setblock 364 143 598 minecraft:oak_log
fill 365 143 558 365 146 558 minecraft:green_terracotta
setblock 365 143 597 minecraft:oak_log
fill 365 143 598 365 146 598 minecraft:green_terracotta
setblock 366 143 596 minecraft:oak_log
fill 366 143 597 366 146 597 minecraft:green_terracotta
setblock 367 143 560 minecraft:oak_log
setblock 367 143 584 minecraft:green_terracotta
setblock 367 143 585 minecraft:oak_log
fill 367 143 586 367 145 586 minecraft:green_terracotta
fill 367 143 588 367 143 589 minecraft:green_terracotta
setblock 368 143 559 minecraft:oak_log
setblock 368 143 560 minecraft:green_terracotta
setblock 368 143 562 minecraft:green_terracotta
setblock 368 143 584 minecraft:oak_log
fill 368 143 585 368 146 585 minecraft:green_terracotta
setblock 368 143 589 minecraft:oak_log
fill 368 143 590 368 146 590 minecraft:green_terracotta
fill 368 143 592 368 144 592 minecraft:green_terracotta
setblock 369 143 558 minecraft:oak_log
setblock 369 143 559 minecraft:green_terracotta
setblock 369 143 563 minecraft:oak_log
fill 369 143 564 369 144 564 minecraft:green_terracotta
setblock 369 143 579 minecraft:green_terracotta
setblock 369 143 583 minecraft:oak_log
fill 369 143 584 369 146 584 minecraft:green_terracotta
setblock 369 143 588 minecraft:oak_log
fill 369 143 589 369 146 589 minecraft:green_terracotta
setblock 369 143 593 minecraft:oak_log
fill 369 143 594 369 145 594 minecraft:green_terracotta
setblock 369 143 598 minecraft:oak_log
fill 370 143 558 370 144 558 minecraft:green_terracotta
setblock 370 143 562 minecraft:oak_log
fill 370 143 563 370 146 563 minecraft:green_terracotta
setblock 370 143 567 minecraft:oak_log
setblock 370 143 574 minecraft:oak_leaves[persistent=true]
setblock 370 143 577 minecraft:oak_log
fill 370 143 578 370 144 578 minecraft:green_terracotta
setblock 370 143 582 minecraft:oak_log
fill 370 143 583 370 146 583 minecraft:green_terracotta
setblock 370 143 587 minecraft:oak_log
fill 370 143 588 370 146 588 minecraft:green_terracotta
setblock 370 143 592 minecraft:oak_log
fill 370 143 593 370 146 593 minecraft:green_terracotta
setblock 370 143 597 minecraft:oak_log
fill 370 143 598 370 145 598 minecraft:green_terracotta
setblock 330 144 561 minecraft:oak_log
fill 330 144 562 330 145 562 minecraft:green_terracotta
setblock 330 144 565 minecraft:green_terracotta
setblock 330 144 566 minecraft:oak_log
fill 330 144 567 330 147 567 minecraft:green_terracotta
setblock 330 144 571 minecraft:oak_log
fill 330 144 574 330 144 575 minecraft:green_terracotta
setblock 330 144 576 minecraft:oak_log
fill 330 144 577 330 144 580 minecraft:green_terracotta
setblock 330 144 581 minecraft:oak_log
fill 330 144 582 330 144 585 minecraft:green_terracotta
setblock 330 144 586 minecraft:oak_log
fill 330 144 587 330 147 587 minecraft:green_terracotta
setblock 330 144 591 minecraft:oak_log
fill 330 144 592 330 147 592 minecraft:green_terracotta
setblock 331 144 580 minecraft:oak_log
fill 331 144 581 331 145 581 minecraft:green_terracotta
setblock 331 144 585 minecraft:oak_log
fill 331 144 586 331 147 586 minecraft:green_terracotta
setblock 331 144 590 minecraft:oak_log
setblock 332 144 584 minecraft:oak_log
setblock 332 144 585 minecraft:green_terracotta
setblock 336 144 558 minecraft:oak_leaves[persistent=true]
setblock 338 144 558 minecraft:oak_log
fill 339 144 558 342 144 558 minecraft:green_terracotta
setblock 339 144 598 minecraft:oak_leaves[persistent=true]
setblock 341 144 560 minecraft:oak_log
setblock 342 144 559 minecraft:oak_log
fill 342 144 560 342 147 560 minecraft:green_terracotta
setblock 342 144 598 minecraft:green_terracotta
setblock 343 144 558 minecraft:oak_log
fill 343 144 559 346 144 559 minecraft:green_terracotta
setblock 343 144 598 minecraft:oak_log
fill 344 144 558 347 144 558 minecraft:green_terracotta
fill 344 144 598 344 146 598 minecraft:green_terracotta
setblock 345 144 561 minecraft:oak_log
setblock 346 144 560 minecraft:oak_log
fill 346 144 561 346 145 561 minecraft:green_terracotta
setblock 347 144 559 minecraft:oak_log
fill 347 144 560 347 146 560 minecraft:green_terracotta
setblock 348 144 558 minecraft:oak_log
fill 348 144 559 351 144 559 minecraft:green_terracotta
setblock 348 144 598 minecraft:oak_log
fill 349 144 558 352 144 558 minecraft:green_terracotta
setblock 351 144 560 minecraft:oak_log
setblock 352 144 559 minecraft:oak_log
setblock 353 144 558 minecraft:oak_log
fill 353 144 559 356 144 559 minecraft:green_terracotta
fill 354 144 558 354 147 558 minecraft:green_terracotta
setblock 357 144 559 minecraft:oak_log
setblock 357 144 560 minecraft:green_terracotta
setblock 358 144 558 minecraft:oak_log
fill 358 144 559 358 147 559 minecraft:green_terracotta
setblock 358 144 598 minecraft:oak_log
fill 359 144 558 359 147 558 minecraft:green_terracotta
setblock 359 144 597 minecraft:oak_log
fill 359 144 598 359 147 598 minecraft:green_terracotta
fill 360 144 597 360 147 597 minecraft:green_terracotta
setblock 361 144 560 minecraft:oak_log
setblock 361 144 561 minecraft:green_terracotta
setblock 362 144 559 minecraft:oak_log
fill 362 144 560 362 146 560 minecraft:green_terracotta
setblock 363 144 558 minecraft:oak_log
fill 363 144 559 363 147 559 minecraft:green_terracotta
fill 363 144 561 364 144 561 minecraft:green_terracotta
setblock 363 144 598 minecraft:oak_log
fill 364 144 558 364 147 558 minecraft:green_terracotta
setblock 364 144 597 minecraft:oak_log
fill 364 144 598 364 147 598 minecraft:green_terracotta
setblock 365 144 596 minecraft:oak_log
fill 365 144 597 365 147 597 minecraft:green_terracotta
setblock 366 144 560 minecraft:oak_log
setblock 366 144 596 minecraft:green_terracotta
setblock 367 144 559 minecraft:oak_log
setblock 367 144 560 minecraft:green_terracotta
setblock 367 144 584 minecraft:oak_log
fill 367 144 585 367 145 585 minecraft:green_terracotta
setblock 367 144 588 minecraft:green_terracotta
setblock 367 144 589 minecraft:oak_log
setblock 368 144 558 minecraft:oak_log
setblock 368 144 559 minecraft:green_terracotta
setblock 368 144 583 minecraft:oak_log
fill 368 144 584 368 146 584 minecraft:green_terracotta
setblock 368 144 588 minecraft:oak_log
fill 368 144 589 368 147 589 minecraft:green_terracotta
setblock 368 144 598 minecraft:oak_log
fill 369 144 558 369 145 558 minecraft:green_terracotta
setblock 369 144 562 minecraft:oak_log
setblock 369 144 563 minecraft:green_terracotta
setblock 369 144 582 minecraft:oak_log
fill 369 144 583 369 147 583 minecraft:green_terracotta
setblock 369 144 587 minecraft:oak_log
fill 369 144 588 369 147 588 minecraft:green_terracotta
setblock 369 144 592 minecraft:oak_log
fill 369 144 593 369 147 593 minecraft:green_terracotta
fill 369 144 598 369 146 598 minecraft:green_terracotta
setblock 370 144 561 minecraft:oak_log
fill 370 144 562 370 145 562 minecraft:green_terracotta
setblock 370 144 566 minecraft:oak_log
fill 370 144 567 370 144 568 minecraft:green_terracotta
setblock 370 144 581 minecraft:oak_log
fill 370 144 582 370 147 582 minecraft:green_terracotta
setblock 370 144 586 minecraft:oak_log
fill 370 144 587 370 147 587 minecraft:green_terracotta
setblock 370 144 591 minecraft:oak_log
fill 370 144 592 370 147 592 minecraft:green_terracotta
setblock 370 144 596 minecraft:oak_log
fill 370 144 597 370 145 597 minecraft:green_terracotta
setblock 330 145 561 minecraft:green_terracotta
setblock 330 145 565 minecraft:oak_log
fill 330 145 566 330 148 566 minecraft:green_terracotta
setblock 330 145 570 minecraft:oak_log
fill 330 145 571 330 148 571 minecraft:green_terracotta
fill 330 145 576 330 145 579 minecraft:green_terracotta
setblock 330 145 580 minecraft:oak_log
fill 330 145 581 330 145 584 minecraft:green_terracotta
setblock 330 145 585 minecraft:oak_log
fill 330 145 586 330 148 586 minecraft:green_terracotta
setblock 330 145 590 minecraft:oak_log
fill 330 145 591 330 148 591 minecraft:green_terracotta
setblock 330 145 594 minecraft:oak_leaves[persistent=true]
setblock 331 145 580 minecraft:green_terracotta
setblock 331 145 584 minecraft:oak_log
fill 331 145 585 331 147 585 minecraft:green_terracotta
setblock 331 145 589 minecraft:oak_log
setblock 332 145 560 minecraft:light[level=14]
setblock 332 145 568 minecraft:light[level=14]
setblock 332 145 576 minecraft:light[level=14]
setblock 332 145 584 minecraft:light[level=14]
setblock 332 145 592 minecraft:light[level=14]
fill 338 145 558 341 145 558 minecraft:green_terracotta
setblock 340 145 560 minecraft:oak_log
setblock 340 145 568 minecraft:light[level=14]
setblock 340 145 576 minecraft:light[level=14]
setblock 340 145 584 minecraft:light[level=14]
setblock 340 145 592 minecraft:light[level=14]
setblock 341 145 559 minecraft:oak_log
fill 341 145 560 341 146 560 minecraft:green_terracotta
setblock 342 145 558 minecraft:oak_log
fill 342 145 559 345 145 559 minecraft:green_terracotta
setblock 342 145 598 minecraft:oak_log
fill 343 145 558 346 145 558 minecraft:green_terracotta
fill 343 145 598 343 146 598 minecraft:green_terracotta
setblock 344 145 561 minecraft:oak_log
setblock 345 145 560 minecraft:oak_log
setblock 345 145 561 minecraft:green_terracotta
setblock 346 145 559 minecraft:oak_log
fill 346 145 560 346 146 560 minecraft:green_terracotta
setblock 347 145 558 minecraft:oak_log
fill 347 145 559 350 145 559 minecraft:green_terracotta
fill 348 145 558 351 145 558 minecraft:green_terracotta
setblock 348 145 568 minecraft:light[level=14]
setblock 348 145 576 minecraft:light[level=14]
setblock 348 145 584 minecraft:light[level=14]
setblock 348 145 592 minecraft:light[level=14]
setblock 351 145 559 minecraft:oak_log
setblock 352 145 558 minecraft:oak_log
fill 352 145 559 355 145 559 minecraft:green_terracotta
fill 353 145 558 353 146 558 minecraft:green_terracotta
setblock 356 145 559 minecraft:oak_log
setblock 356 145 560 minecraft:light[level=14]
setblock 356 145 568 minecraft:light[level=14]
setblock 356 145 576 minecraft:light[level=14]
setblock 356 145 584 minecraft:light[level=14]
setblock 356 145 592 minecraft:light[level=14]
setblock 357 145 558 minecraft:oak_log
fill 357 145 559 357 146 559 minecraft:green_terracotta
setblock 357 145 598 minecraft:oak_log
fill 358 145 558 358 148 558 minecraft:green_terracotta
fill 358 145 598 358 148 598 minecraft:green_terracotta
fill 359 145 597 359 148 597 minecraft:green_terracotta
setblock 360 145 560 minecraft:oak_log
setblock 361 145 559 minecraft:oak_log
fill 361 145 560 361 146 560 minecraft:green_terracotta
setblock 362 145 558 minecraft:oak_log
fill 362 145 559 362 148 559 minecraft:green_terracotta
setblock 362 145 596 minecraft:green_terracotta
setblock 362 145 598 minecraft:oak_log
fill 363 145 558 363 148 558 minecraft:green_terracotta
setblock 363 145 597 minecraft:oak_log
fill 363 145 598 363 148 598 minecraft:green_terracotta
setblock 364 145 568 minecraft:light[level=14]
setblock 364 145 576 minecraft:light[level=14]
setblock 364 145 584 minecraft:light[level=14]
setblock 364 145 592 minecraft:light[level=14]
setblock 364 145 596 minecraft:oak_log
fill 364 145 597 364 148 597 minecraft:green_terracotta
setblock 365 145 560 minecraft:oak_log
setblock 365 145 596 minecraft:green_terracotta
setblock 366 145 559 minecraft:oak_log
setblock 367 145 558 minecraft:oak_log
setblock 367 145 559 minecraft:green_terracotta
setblock 367 145 588 minecraft:oak_log
setblock 367 145 589 minecraft:green_terracotta
setblock 367 145 598 minecraft:oak_log
setblock 368 145 558 minecraft:green_terracotta
setblock 368 145 583 minecraft:green_terracotta
setblock 368 145 587 minecraft:oak_log
fill 368 145 588 368 148 588 minecraft:green_terracotta
setblock 368 145 592 minecraft:oak_log
fill 368 145 598 368 146 598 minecraft:green_terracotta
setblock 369 145 581 minecraft:oak_log
fill 369 145 582 369 146 582 minecraft:green_terracotta
setblock 369 145 586 minecraft:oak_log
fill 369 145 587 369 148 587 minecraft:green_terracotta
setblock 369 145 591 minecraft:oak_log
fill 369 145 592 369 148 592 minecraft:green_terracotta
setblock 370 145 560 minecraft:oak_log
setblock 370 145 561 minecraft:green_terracotta
setblock 370 145 565 minecraft:oak_log
fill 370 145 566 370 146 567 minecraft:green_terracotta
setblock 370 145 580 minecraft:oak_log
fill 370 145 581 370 147 581 minecraft:green_terracotta
setblock 370 145 585 minecraft:oak_log
fill 370 145 586 370 148 586 minecraft:green_terracotta
setblock 370 145 590 minecraft:oak_log
fill 370 145 591 370 148 591 minecraft:green_terracotta
setblock 370 145 595 minecraft:oak_log
setblock 370 145 596 minecraft:green_terracotta
setblock 330 146 564 minecraft:oak_log
fill 330 146 565 330 148 565 minecraft:green_terracotta
setblock 330 146 569 minecraft:oak_log
fill 330 146 570 330 149 570 minecraft:green_terracotta
setblock 330 146 575 minecraft:oak_leaves[persistent=true]
setblock 330 146 578 minecraft:green_terracotta
setblock 330 146 579 minecraft:oak_log
fill 330 146 580 330 146 583 minecraft:green_terracotta
setblock 330 146 584 minecraft:oak_log
fill 330 146 585 330 149 585 minecraft:green_terracotta
setblock 330 146 589 minecraft:oak_log
fill 330 146 590 330 149 590 minecraft:green_terracotta
setblock 331 146 583 minecraft:oak_log
fill 331 146 584 331 147 584 minecraft:green_terracotta
setblock 331 146 588 minecraft:oak_log
setblock 331 146 589 minecraft:green_terracotta
setblock 332 146 598 minecraft:oak_leaves[persistent=true]
fill 338 146 558 340 146 558 minecraft:green_terracotta
setblock 340 146 559 minecraft:oak_log
setblock 341 146 558 minecraft:oak_log
fill 341 146 559 344 146 559 minecraft:green_terracotta
fill 342 146 558 345 146 558 minecraft:green_terracotta
fill 342 146 561 342 149 561 minecraft:oak_leaves[persistent=true]
setblock 343 146 561 minecraft:oak_log
setblock 344 146 560 minecraft:oak_log
setblock 344 146 561 minecraft:green_terracotta
setblock 345 146 559 minecraft:oak_log
fill 345 146 560 345 147 560 minecraft:green_terracotta
setblock 346 146 558 minecraft:oak_log
fill 346 146 559 349 146 559 minecraft:green_terracotta
fill 347 146 558 350 146 558 minecraft:green_terracotta
setblock 351 146 558 minecraft:oak_log
setblock 351 146 598 minecraft:oak_leaves[persistent=true]
setblock 352 146 558 minecraft:green_terracotta
setblock 356 146 558 minecraft:oak_log
setblock 356 146 559 minecraft:green_terracotta
setblock 356 146 598 minecraft:oak_log
fill 357 146 558 357 149 558 minecraft:green_terracotta
fill 357 146 598 357 149 598 minecraft:green_terracotta
setblock 360 146 559 minecraft:oak_log
setblock 360 146 560 minecraft:green_terracotta
setblock 361 146 558 minecraft:oak_log
fill 361 146 559 361 148 559 minecraft:green_terracotta
setblock 361 146 598 minecraft:oak_log
fill 362 146 558 362 149 558 minecraft:green_terracotta
setblock 362 146 597 minecraft:oak_log
fill 362 146 598 362 149 598 minecraft:green_terracotta
setblock 363 146 596 minecraft:oak_log
fill 363 146 597 363 149 597 minecraft:green_terracotta
setblock 365 146 559 minecraft:oak_log
setblock 366 146 558 minecraft:oak_log
setblock 366 146 559 minecraft:green_terracotta
setblock 366 146 598 minecraft:oak_log
setblock 367 146 558 minecraft:green_terracotta
setblock 367 146 587 minecraft:oak_log
setblock 367 146 588 minecraft:green_terracotta
fill 367 146 598 367 147 598 minecraft:green_terracotta
setblock 368 146 558 minecraft:oak_leaves[persistent=true]
setblock 368 146 586 minecraft:oak_log
fill 368 146 587 368 148 587 minecraft:green_terracotta
setblock 368 146 591 minecraft:oak_log
setblock 369 146 585 minecraft:oak_log
fill 369 146 586 369 149 586 minecraft:green_terracotta
setblock 369 146 590 minecraft:oak_log
fill 369 146 591 369 149 591 minecraft:green_terracotta
setblock 370 146 564 minecraft:oak_log
setblock 370 146 565 minecraft:green_terracotta
setblock 370 146 575 minecraft:oak_leaves[persistent=true]
setblock 370 146 580 minecraft:green_terracotta
setblock 370 146 584 minecraft:oak_log
fill 370 146 585 370 149 585 minecraft:green_terracotta
setblock 370 146 589 minecraft:oak_log
fill 370 146 590 370 149 590 minecraft:green_terracotta
setblock 370 146 594 minecraft:oak_log
setblock 370 146 595 minecraft:green_terracotta
setblock 330 147 562 minecraft:oak_leaves[persistent=true]
setblock 330 147 564 minecraft:green_terracotta
setblock 330 147 568 minecraft:oak_log
fill 330 147 569 330 150 569 minecraft:green_terracotta
fill 330 147 580 330 147 582 minecraft:green_terracotta
setblock 330 147 583 minecraft:oak_log
fill 330 147 584 330 149 584 minecraft:green_terracotta
setblock 330 147 588 minecraft:oak_log
fill 330 147 589 330 150 589 minecraft:green_terracotta
setblock 331 147 587 minecraft:oak_log
setblock 331 147 588 minecraft:green_terracotta
setblock 337 147 558 minecraft:oak_leaves[persistent=true]
setblock 338 147 598 minecraft:oak_leaves[persistent=true]
setblock 339 147 558 minecraft:green_terracotta
setblock 340 147 558 minecraft:oak_log
fill 340 147 559 343 147 559 minecraft:green_terracotta
fill 341 147 558 344 147 558 minecraft:green_terracotta
setblock 343 147 560 minecraft:oak_log
setblock 344 147 559 minecraft:oak_log
setblock 344 147 560 minecraft:green_terracotta
setblock 345 147 558 minecraft:oak_log
fill 345 147 559 347 147 559 minecraft:green_terracotta
fill 346 147 558 349 147 558 minecraft:green_terracotta
setblock 350 147 558 minecraft:oak_log
setblock 351 147 558 minecraft:green_terracotta
setblock 355 147 558 minecraft:oak_log
fill 356 147 558 356 149 558 minecraft:green_terracotta
fill 356 147 598 356 150 598 minecraft:green_terracotta
setblock 359 147 559 minecraft:oak_log
setblock 360 147 558 minecraft:oak_log
fill 360 147 559 360 148 559 minecraft:green_terracotta
setblock 360 147 598 minecraft:oak_log
fill 361 147 558 361 150 558 minecraft:green_terracotta
setblock 361 147 597 minecraft:oak_log
fill 361 147 598 361 150 598 minecraft:green_terracotta
fill 362 147 597 362 150 597 minecraft:green_terracotta
setblock 364 147 559 minecraft:oak_log
setblock 365 147 558 minecraft:oak_log
setblock 365 147 598 minecraft:oak_log
setblock 366 147 558 minecraft:green_terracotta
fill 366 147 598 366 149 598 minecraft:green_terracotta
setblock 368 147 585 minecraft:oak_log
setblock 368 147 586 minecraft:green_terracotta
setblock 368 147 590 minecraft:oak_log
setblock 368 147 591 minecraft:green_terracotta
setblock 369 147 584 minecraft:oak_log
fill 369 147 585 369 148 585 minecraft:green_terracotta
setblock 369 147 589 minecraft:oak_log
fill 369 147 590 369 150 590 minecraft:green_terracotta
setblock 370 147 569 minecraft:oak_leaves[persistent=true]
setblock 370 147 583 minecraft:oak_log
fill 370 147 584 370 150 584 minecraft:green_terracotta
setblock 370 147 588 minecraft:oak_log
fill 370 147 589 370 150 589 minecraft:green_terracotta
setblock 370 147 593 minecraft:oak_log
fill 370 147 594 370 148 594 minecraft:green_terracotta
setblock 330 148 567 minecraft:oak_log
fill 330 148 568 330 151 568 minecraft:green_terracotta
setblock 330 148 582 minecraft:oak_log
setblock 330 148 583 minecraft:green_terracotta
setblock 330 148 587 minecraft:oak_log
fill 330 148 588 330 151 588 minecraft:green_terracotta
setblock 330 148 593 minecraft:oak_leaves[persistent=true]
setblock 331 148 558 minecraft:oak_leaves[persistent=true]
setblock 339 148 558 minecraft:oak_log
fill 340 148 558 343 148 558 minecraft:green_terracotta
fill 341 148 559 342 148 559 minecraft:green_terracotta
setblock 343 148 559 minecraft:oak_log
setblock 344 148 558 minecraft:oak_log
fill 344 148 559 345 148 559 minecraft:green_terracotta
setblock 344 148 598 minecraft:oak_leaves[persistent=true]
fill 345 148 558 348 148 558 minecraft:green_terracotta
setblock 355 148 558 minecraft:green_terracotta
setblock 359 148 558 minecraft:oak_log
setblock 359 148 559 minecraft:green_terracotta
setblock 359 148 598 minecraft:oak_log
fill 360 148 558 360 151 558 minecraft:green_terracotta
setblock 360 148 597 minecraft:oak_log
fill 360 148 598 360 151 598 minecraft:green_terracotta
fill 361 148 597 361 151 597 minecraft:green_terracotta
setblock 364 148 558 minecraft:oak_log
setblock 364 148 598 minecraft:oak_log
setblock 365 148 597 minecraft:oak_log
fill 365 148 598 365 151 598 minecraft:green_terracotta
setblock 368 148 589 minecraft:oak_log
setblock 368 148 590 minecraft:green_terracotta
setblock 369 148 588 minecraft:oak_log
fill 369 148 589 369 151 589 minecraft:green_terracotta
setblock 369 148 598 minecraft:oak_leaves[persistent=true]
setblock 370 148 563 minecraft:oak_leaves[persistent=true]
setblock 370 148 582 minecraft:oak_log
setblock 370 148 583 minecraft:green_terracotta
setblock 370 148 587 minecraft:oak_log
fill 370 148 588 370 151 588 minecraft:green_terracotta
setblock 370 148 592 minecraft:oak_log
fill 370 148 593 370 151 593 minecraft:green_terracotta
setblock 330 149 566 minecraft:oak_log
fill 330 149 567 330 152 567 minecraft:green_terracotta
setblock 330 149 571 minecraft:oak_log
setblock 330 149 574 minecraft:oak_leaves[persistent=true]
setblock 330 149 586 minecraft:oak_log
fill 330 149 587 330 150 587 minecraft:green_terracotta
setblock 330 149 591 minecraft:oak_log
setblock 331 149 598 minecraft:oak_leaves[persistent=true]
fill 339 149 558 342 149 558 minecraft:green_terracotta
setblock 342 149 559 minecraft:oak_log
setblock 343 149 558 minecraft:oak_log
fill 344 149 558 346 149 558 minecraft:green_terracotta
setblock 350 149 558 minecraft:oak_leaves[persistent=true]
setblock 350 149 598 minecraft:oak_leaves[persistent=true]
setblock 358 149 558 minecraft:oak_log
setblock 358 149 597 minecraft:green_terracotta
setblock 358 149 598 minecraft:oak_log
fill 359 149 558 359 152 558 minecraft:green_terracotta
setblock 359 149 597 minecraft:oak_log
fill 359 149 598 359 152 598 minecraft:green_terracotta
fill 360 149 597 360 152 597 minecraft:green_terracotta
setblock 363 149 558 minecraft:oak_log
setblock 363 149 598 minecraft:oak_log
setblock 364 149 597 minecraft:oak_log
fill 364 149 598 364 152 598 minecraft:green_terracotta
setblock 369 149 558 minecraft:oak_leaves[persistent=true]
setblock 369 149 587 minecraft:oak_log
fill 369 149 588 369 150 588 minecraft:green_terracotta
setblock 369 149 592 minecraft:oak_log
setblock 370 149 582 minecraft:oak_leaves[persistent=true]
setblock 370 149 586 minecraft:oak_log
fill 370 149 587 370 152 587 minecraft:green_terracotta
setblock 370 149 591 minecraft:oak_log
fill 370 149 592 370 152 592 minecraft:green_terracotta
setblock 330 150 561 minecraft:oak_leaves[persistent=true]
setblock 330 150 570 minecraft:oak_log
fill 330 150 571 330 152 572 minecraft:green_terracotta
setblock 330 150 580 minecraft:oak_leaves[persistent=true]
setblock 330 150 586 minecraft:green_terracotta
setblock 330 150 590 minecraft:oak_log
setblock 337 150 598 minecraft:oak_leaves[persistent=true]
fill 339 150 558 341 150 558 minecraft:green_terracotta
setblock 342 150 558 minecraft:oak_log
fill 343 150 558 345 150 558 minecraft:green_terracotta
fill 355 150 598 355 151 598 minecraft:green_terracotta
setblock 357 150 558 minecraft:oak_log
setblock 357 150 598 minecraft:oak_log
fill 358 150 558 358 153 558 minecraft:green_terracotta
setblock 358 150 597 minecraft:oak_log
fill 358 150 598 358 153 598 minecraft:green_terracotta
fill 359 150 597 359 153 597 minecraft:green_terracotta
setblock 362 150 558 minecraft:oak_log
setblock 362 150 598 minecraft:oak_log
setblock 363 150 558 minecraft:oak_leaves[persistent=true]
setblock 363 150 597 minecraft:oak_log
fill 363 150 598 363 153 598 minecraft:green_terracotta
setblock 369 150 587 minecraft:green_terracotta
setblock 369 150 591 minecraft:oak_log
setblock 370 150 576 minecraft:oak_leaves[persistent=true]
setblock 370 150 585 minecraft:oak_log
fill 370 150 586 370 153 586 minecraft:green_terracotta
setblock 370 150 590 minecraft:oak_log
fill 370 150 591 370 153 591 minecraft:green_terracotta
setblock 370 150 595 minecraft:oak_leaves[persistent=true]
setblock 330 151 569 minecraft:oak_log
fill 330 151 570 330 154 570 minecraft:green_terracotta
setblock 330 151 573 minecraft:green_terracotta
setblock 330 151 586 minecraft:oak_leaves[persistent=true]
setblock 330 151 589 minecraft:oak_log
setblock 330 151 590 minecraft:green_terracotta
setblock 338 151 558 minecraft:oak_leaves[persistent=true]
fill 339 151 558 340 151 558 minecraft:green_terracotta
setblock 341 151 558 minecraft:oak_log
fill 342 151 558 344 152 558 minecraft:green_terracotta
setblock 343 151 598 minecraft:oak_leaves[persistent=true]
setblock 356 151 558 minecraft:oak_log
setblock 356 151 598 minecraft:oak_log
fill 357 151 558 357 154 558 minecraft:green_terracotta
setblock 357 151 597 minecraft:oak_log
fill 357 151 598 357 154 598 minecraft:green_terracotta
fill 358 151 597 358 154 597 minecraft:green_terracotta
fill 359 151 596 361 152 596 minecraft:green_terracotta
setblock 361 151 558 minecraft:oak_log
setblock 361 151 598 minecraft:oak_log
setblock 362 151 597 minecraft:oak_log
fill 362 151 598 362 154 598 minecraft:green_terracotta
fill 363 151 597 363 154 597 minecraft:green_terracotta
setblock 369 151 590 minecraft:oak_log
fill 369 151 591 369 154 591 minecraft:green_terracotta
setblock 370 151 570 minecraft:oak_leaves[persistent=true]
setblock 370 151 585 minecraft:green_terracotta
setblock 370 151 589 minecraft:oak_log
fill 370 151 590 370 154 590 minecraft:green_terracotta
setblock 370 151 594 minecraft:oak_log
setblock 330 152 568 minecraft:oak_log
fill 330 152 569 330 155 569 minecraft:green_terracotta
setblock 330 152 573 minecraft:oak_log
fill 330 152 574 330 154 575 minecraft:green_terracotta
setblock 330 152 589 minecraft:green_terracotta
setblock 330 152 592 minecraft:oak_leaves[persistent=true]
fill 331 152 570 331 152 571 minecraft:green_terracotta
setblock 332 152 558 minecraft:oak_leaves[persistent=true]
fill 338 152 558 339 152 558 minecraft:green_terracotta
setblock 340 152 558 minecraft:oak_log
setblock 340 152 598 minecraft:oak_log
fill 341 152 558 341 155 558 minecraft:green_terracotta
setblock 349 152 598 minecraft:oak_leaves[persistent=true]
fill 350 152 579 350 179 579 minecraft:oak_log
setblock 351 152 558 minecraft:oak_leaves[persistent=true]
fill 353 152 598 354 152 598 minecraft:green_terracotta
setblock 355 152 558 minecraft:oak_log
setblock 355 152 597 minecraft:green_terracotta
setblock 355 152 598 minecraft:oak_log
fill 356 152 558 356 155 558 minecraft:green_terracotta
setblock 356 152 597 minecraft:oak_log
fill 356 152 598 356 155 598 minecraft:green_terracotta
setblock 357 152 596 minecraft:oak_log
fill 357 152 597 357 155 597 minecraft:green_terracotta
fill 358 152 571 358 153 571 minecraft:glowstone
fill 358 152 596 358 155 596 minecraft:green_terracotta
setblock 360 152 558 minecraft:oak_log
setblock 360 152 598 minecraft:oak_log
fill 361 152 558 361 155 558 minecraft:green_terracotta
setblock 361 152 597 minecraft:oak_log
fill 361 152 598 361 155 598 minecraft:green_terracotta
setblock 362 152 596 minecraft:oak_log
fill 362 152 597 362 155 597 minecraft:green_terracotta
setblock 365 152 598 minecraft:oak_log
setblock 368 152 598 minecraft:oak_leaves[persistent=true]
setblock 369 152 589 minecraft:oak_log
fill 369 152 590 369 155 590 minecraft:green_terracotta
setblock 370 152 564 minecraft:oak_leaves[persistent=true]
setblock 370 152 583 minecraft:oak_leaves[persistent=true]
setblock 370 152 588 minecraft:oak_log
fill 370 152 589 370 155 589 minecraft:green_terracotta
setblock 370 152 593 minecraft:oak_log
fill 370 152 594 370 155 594 minecraft:green_terracotta
setblock 330 153 567 minecraft:oak_log
fill 330 153 568 331 155 568 minecraft:green_terracotta
setblock 330 153 571 minecraft:green_terracotta
setblock 330 153 572 minecraft:oak_log
fill 330 153 573 331 155 573 minecraft:green_terracotta
setblock 330 153 576 minecraft:green_terracotta
setblock 330 153 579 minecraft:oak_leaves[persistent=true]
fill 330 153 590 330 153 591 minecraft:green_terracotta
setblock 330 153 598 minecraft:oak_leaves[persistent=true]
fill 331 153 569 331 153 570 minecraft:green_terracotta
setblock 331 153 571 minecraft:oak_log
fill 331 153 572 331 156 572 minecraft:green_terracotta
fill 331 153 574 331 154 574 minecraft:green_terracotta
setblock 332 153 560 minecraft:light[level=14]
setblock 332 153 568 minecraft:light[level=14]
setblock 332 153 576 minecraft:light[level=14]
setblock 332 153 584 minecraft:light[level=14]
setblock 332 153 592 minecraft:light[level=14]
fill 337 153 558 338 153 558 minecraft:green_terracotta
fill 337 153 598 338 153 598 minecraft:green_terracotta
setblock 339 153 558 minecraft:oak_log
setblock 339 153 598 minecraft:oak_log
fill 340 153 558 340 156 558 minecraft:green_terracotta
setblock 340 153 560 minecraft:light[level=14]
setblock 340 153 568 minecraft:light[level=14]
setblock 340 153 576 minecraft:light[level=14]
setblock 340 153 584 minecraft:light[level=14]
setblock 340 153 592 minecraft:light[level=14]
fill 340 153 598 343 153 598 minecraft:green_terracotta
fill 342 153 558 343 153 558 minecraft:green_terracotta
setblock 344 153 558 minecraft:oak_log
setblock 345 153 558 minecraft:oak_leaves[persistent=true]
setblock 348 153 560 minecraft:light[level=14]
setblock 348 153 568 minecraft:light[level=14]
setblock 348 153 576 minecraft:light[level=14]
setblock 348 153 584 minecraft:light[level=14]
setblock 348 153 592 minecraft:light[level=14]
fill 352 153 598 353 153 598 minecraft:green_terracotta
setblock 354 153 558 minecraft:oak_log
setblock 354 153 597 minecraft:green_terracotta
setblock 354 153 598 minecraft:oak_log
fill 355 153 558 355 156 558 minecraft:green_terracotta
setblock 355 153 597 minecraft:oak_log
fill 355 153 598 355 156 598 minecraft:green_terracotta
setblock 356 153 560 minecraft:light[level=14]
setblock 356 153 568 minecraft:light[level=14]
setblock 356 153 576 minecraft:light[level=14]
setblock 356 153 584 minecraft:light[level=14]
setblock 356 153 592 minecraft:light[level=14]
setblock 356 153 596 minecraft:oak_log
fill 356 153 597 356 156 597 minecraft:green_terracotta
fill 357 153 596 357 156 596 minecraft:green_terracotta
fill 358 153 595 360 154 595 minecraft:green_terracotta
setblock 359 153 558 minecraft:oak_log
fill 359 153 596 360 153 596 minecraft:green_terracotta
setblock 359 153 598 minecraft:oak_log
fill 360 153 558 360 156 558 minecraft:green_terracotta
setblock 360 153 597 minecraft:oak_log
fill 360 153 598 360 156 598 minecraft:green_terracotta
setblock 361 153 596 minecraft:oak_log
fill 361 153 597 361 156 597 minecraft:green_terracotta
fill 362 153 596 362 156 596 minecraft:green_terracotta
setblock 364 153 560 minecraft:light[level=14]
setblock 364 153 568 minecraft:light[level=14]
setblock 364 153 576 minecraft:light[level=14]
setblock 364 153 584 minecraft:light[level=14]
setblock 364 153 592 minecraft:light[level=14]
setblock 364 153 597 minecraft:green_terracotta
setblock 364 153 598 minecraft:oak_log
fill 365 153 598 365 156 598 minecraft:green_terracotta
setblock 369 153 592 minecraft:green_terracotta
setblock 370 153 558 minecraft:oak_leaves[persistent=true]
setblock 370 153 571 minecraft:green_terracotta
setblock 370 153 572 minecraft:oak_log
fill 370 153 573 370 156 573 minecraft:green_terracotta
setblock 370 153 577 minecraft:oak_leaves[persistent=true]
setblock 370 153 587 minecraft:oak_log
fill 370 153 588 370 156 588 minecraft:green_terracotta
setblock 370 153 592 minecraft:oak_log
fill 370 153 593 370 156 593 minecraft:green_terracotta
fill 370 153 595 370 154 595 minecraft:green_terracotta
setblock 330 154 560 minecraft:oak_leaves[persistent=true]
setblock 330 154 566 minecraft:oak_log
fill 330 154 567 330 157 567 minecraft:green_terracotta
setblock 330 154 571 minecraft:oak_log
fill 330 154 572 330 157 572 minecraft:green_terracotta
setblock 330 154 576 minecraft:oak_log
fill 330 154 577 330 156 578 minecraft:green_terracotta
setblock 330 154 585 minecraft:oak_leaves[persistent=true]
fill 330 154 589 330 154 590 minecraft:green_terracotta
setblock 330 154 591 minecraft:oak_log
fill 330 154 592 330 157 592 minecraft:green_terracotta
setblock 331 154 569 minecraft:green_terracotta
setblock 331 154 570 minecraft:oak_log
fill 331 154 571 332 156 571 minecraft:green_terracotta
setblock 331 154 575 minecraft:oak_log
setblock 332 154 569 minecraft:oak_log
fill 332 154 570 332 157 570 minecraft:green_terracotta
fill 332 154 572 332 154 573 minecraft:green_terracotta
fill 335 154 558 337 154 558 minecraft:green_terracotta
fill 335 154 598 337 154 598 minecraft:green_terracotta
fill 337 154 560 337 156 560 minecraft:iron_block
setblock 338 154 558 minecraft:oak_log
fill 338 154 559 340 155 559 minecraft:green_terracotta
setblock 338 154 597 minecraft:green_terracotta
setblock 338 154 598 minecraft:oak_log
fill 339 154 558 339 157 558 minecraft:green_terracotta
setblock 339 154 597 minecraft:oak_log
fill 339 154 598 342 154 598 minecraft:green_terracotta
fill 340 154 597 340 157 597 minecraft:green_terracotta
setblock 342 154 558 minecraft:green_terracotta
setblock 343 154 558 minecraft:oak_log
setblock 343 154 598 minecraft:oak_log
fill 344 154 558 345 156 558 minecraft:green_terracotta
fill 344 154 598 345 156 598 minecraft:green_terracotta
fill 349 154 598 352 154 598 minecraft:green_terracotta
setblock 352 154 558 minecraft:green_terracotta
fill 352 154 597 353 154 597 minecraft:green_terracotta
setblock 353 154 558 minecraft:oak_log
setblock 353 154 598 minecraft:oak_log
fill 354 154 558 354 157 558 minecraft:green_terracotta
setblock 354 154 596 minecraft:green_terracotta
setblock 354 154 597 minecraft:oak_log
fill 354 154 598 354 157 598 minecraft:green_terracotta
setblock 355 154 596 minecraft:oak_log
fill 355 154 597 355 157 597 minecraft:green_terracotta
setblock 356 154 595 minecraft:oak_log
fill 356 154 596 356 157 596 minecraft:green_terracotta
fill 357 154 595 357 157 595 minecraft:green_terracotta
setblock 358 154 558 minecraft:oak_log
setblock 358 154 598 minecraft:oak_log
fill 359 154 558 359 157 558 minecraft:green_terracotta
setblock 359 154 596 minecraft:green_terracotta
setblock 359 154 597 minecraft:oak_log
fill 359 154 598 359 157 598 minecraft:green_terracotta
setblock 360 154 596 minecraft:oak_log
fill 360 154 597 360 157 597 minecraft:green_terracotta
setblock 361 154 595 minecraft:oak_log
fill 361 154 596 361 157 596 minecraft:green_terracotta
fill 363 154 596 363 155 596 minecraft:green_terracotta
setblock 363 154 598 minecraft:oak_log
setblock 364 154 558 minecraft:oak_leaves[persistent=true]
setblock 364 154 597 minecraft:oak_log
fill 364 154 598 364 157 598 minecraft:green_terracotta
setblock 369 154 592 minecraft:oak_log
fill 369 154 593 369 157 593 minecraft:green_terracotta
fill 370 154 569 370 154 570 minecraft:green_terracotta
setblock 370 154 571 minecraft:oak_log
fill 370 154 572 370 157 572 minecraft:green_terracotta
fill 370 154 574 370 154 575 minecraft:green_terracotta
setblock 370 154 576 minecraft:oak_log
setblock 370 154 586 minecraft:oak_log
fill 370 154 587 370 157 587 minecraft:green_terracotta
setblock 370 154 591 minecraft:oak_log
fill 370 154 592 370 157 592 minecraft:green_terracotta
setblock 370 154 596 minecraft:oak_log
fill 330 155 566 330 158 566 minecraft:green_terracotta
setblock 330 155 570 minecraft:oak_log
fill 330 155 571 330 158 571 minecraft:green_terracotta
setblock 330 155 574 minecraft:green_terracotta
setblock 330 155 575 minecraft:oak_log
fill 330 155 576 331 157 576 minecraft:green_terracotta
setblock 330 155 579 minecraft:green_terracotta
setblock 330 155 589 minecraft:green_terracotta
setblock 330 155 590 minecraft:oak_log
fill 330 155 591 330 158 591 minecraft:green_terracotta
fill 330 155 593 330 155 594 minecraft:green_terracotta
fill 331 155 567 331 156 567 minecraft:green_terracotta
setblock 331 155 569 minecraft:oak_log
fill 331 155 570 331 158 570 minecraft:green_terracotta
setblock 331 155 574 minecraft:oak_log
fill 331 155 575 332 157 575 minecraft:green_terracotta
fill 331 155 577 331 156 577 minecraft:green_terracotta
setblock 332 155 568 minecraft:oak_log
fill 332 155 569 332 158 569 minecraft:green_terracotta
setblock 332 155 572 minecraft:green_terracotta
setblock 332 155 573 minecraft:oak_log
fill 332 155 574 332 158 574 minecraft:green_terracotta
setblock 333 155 558 minecraft:oak_leaves[persistent=true]
setblock 333 155 571 minecraft:green_terracotta
setblock 333 155 572 minecraft:oak_log
fill 333 155 598 336 155 598 minecraft:green_terracotta
fill 334 155 558 336 155 558 minecraft:green_terracotta
setblock 336 155 559 minecraft:oak_log
fill 336 155 597 337 155 597 minecraft:green_terracotta
setblock 337 155 558 minecraft:oak_log
fill 337 155 559 337 158 559 minecraft:green_terracotta
setblock 337 155 598 minecraft:oak_log
fill 338 155 558 338 158 558 minecraft:green_terracotta
setblock 338 155 597 minecraft:oak_log
fill 338 155 598 341 155 598 minecraft:green_terracotta
fill 339 155 597 339 158 597 minecraft:green_terracotta
setblock 341 155 559 minecraft:oak_log
fill 341 155 597 342 155 597 minecraft:green_terracotta
setblock 342 155 558 minecraft:oak_log
setblock 342 155 598 minecraft:oak_log
fill 343 155 558 343 158 558 minecraft:green_terracotta
fill 343 155 598 343 158 598 minecraft:green_terracotta
setblock 346 155 558 minecraft:green_terracotta
setblock 346 155 598 minecraft:green_terracotta
setblock 347 155 598 minecraft:oak_log
fill 348 155 598 351 155 598 minecraft:green_terracotta
fill 350 155 558 351 155 558 minecraft:green_terracotta
fill 350 155 597 352 155 597 minecraft:green_terracotta
setblock 352 155 558 minecraft:oak_log
fill 352 155 596 353 155 596 minecraft:green_terracotta
setblock 352 155 598 minecraft:oak_log
fill 353 155 558 353 158 558 minecraft:green_terracotta
setblock 353 155 597 minecraft:oak_log
fill 353 155 598 353 158 598 minecraft:green_terracotta
setblock 354 155 595 minecraft:green_terracotta
setblock 354 155 596 minecraft:oak_log
fill 354 155 597 354 158 597 minecraft:green_terracotta
setblock 355 155 595 minecraft:oak_log
fill 355 155 596 355 158 596 minecraft:green_terracotta
fill 356 155 595 356 158 595 minecraft:green_terracotta
setblock 357 155 558 minecraft:oak_log
setblock 357 155 598 minecraft:oak_log
fill 358 155 558 358 158 558 minecraft:green_terracotta
fill 358 155 595 359 155 595 minecraft:green_terracotta
setblock 358 155 597 minecraft:oak_log
fill 358 155 598 358 158 598 minecraft:green_terracotta
setblock 359 155 596 minecraft:oak_log
fill 359 155 597 359 158 597 minecraft:green_terracotta
setblock 360 155 595 minecraft:oak_log
fill 360 155 596 360 158 596 minecraft:green_terracotta
fill 361 155 595 361 158 595 minecraft:green_terracotta
setblock 362 155 598 minecraft:oak_log
setblock 363 155 597 minecraft:oak_log
fill 363 155 598 363 158 598 minecraft:green_terracotta
fill 364 155 597 365 157 597 minecraft:green_terracotta
setblock 366 155 598 minecraft:green_terracotta
setblock 367 155 598 minecraft:oak_leaves[persistent=true]
setblock 369 155 591 minecraft:oak_log
fill 369 155 592 369 158 592 minecraft:green_terracotta
fill 369 155 594 369 156 594 minecraft:green_terracotta
setblock 370 155 565 minecraft:oak_leaves[persistent=true]
setblock 370 155 569 minecraft:green_terracotta
setblock 370 155 570 minecraft:oak_log
fill 370 155 571 370 158 571 minecraft:green_terracotta
setblock 370 155 574 minecraft:green_terracotta
setblock 370 155 575 minecraft:oak_log
fill 370 155 576 370 155 579 minecraft:green_terracotta
setblock 370 155 584 minecraft:oak_leaves[persistent=true]
setblock 370 155 585 minecraft:oak_log
fill 370 155 586 370 158 586 minecraft:green_terracotta
setblock 370 155 590 minecraft:oak_log
fill 370 155 591 370 158 591 minecraft:green_terracotta
setblock 370 155 595 minecraft:oak_log
fill 370 155 596 370 157 597 minecraft:green_terracotta
fill 330 156 565 330 159 565 minecraft:green_terracotta
setblock 330 156 568 minecraft:green_terracotta
setblock 330 156 569 minecraft:oak_log
fill 330 156 570 330 159 570 minecraft:green_terracotta
setblock 330 156 573 minecraft:green_terracotta
setblock 330 156 574 minecraft:oak_log
fill 330 156 575 330 159 575 minecraft:green_terracotta
setblock 330 156 579 minecraft:oak_log
fill 330 156 580 330 158 581 minecraft:green_terracotta
setblock 330 156 589 minecraft:oak_log
fill 330 156 590 330 159 590 minecraft:green_terracotta
setblock 330 156 593 minecraft:green_terracotta
setblock 330 156 594 minecraft:oak_log
fill 330 156 595 330 158 596 minecraft:green_terracotta
setblock 330 156 597 minecraft:oak_leaves[persistent=true]
fill 331 156 566 331 157 566 minecraft:green_terracotta
setblock 331 156 568 minecraft:oak_log
fill 331 156 569 331 159 569 minecraft:green_terracotta
setblock 331 156 573 minecraft:oak_log
fill 331 156 574 331 159 574 minecraft:green_terracotta
setblock 331 156 578 minecraft:oak_log
fill 332 156 558 335 156 558 minecraft:green_terracotta
fill 332 156 568 332 159 568 minecraft:green_terracotta
setblock 332 156 572 minecraft:oak_log
fill 332 156 573 333 158 573 minecraft:green_terracotta
setblock 332 156 576 minecraft:green_terracotta
setblock 332 156 577 minecraft:oak_log
fill 332 156 598 335 156 598 minecraft:green_terracotta
setblock 333 156 570 minecraft:green_terracotta
setblock 333 156 571 minecraft:oak_log
fill 333 156 572 333 159 572 minecraft:green_terracotta
fill 333 156 574 333 156 575 minecraft:green_terracotta
fill 334 156 597 336 156 597 minecraft:green_terracotta
setblock 335 156 559 minecraft:oak_log
setblock 336 156 558 minecraft:oak_log
fill 336 156 559 336 159 559 minecraft:green_terracotta
setblock 336 156 598 minecraft:oak_log
fill 337 156 558 337 159 558 minecraft:green_terracotta
setblock 337 156 596 minecraft:green_terracotta
setblock 337 156 597 minecraft:oak_log
fill 337 156 598 340 156 598 minecraft:green_terracotta
fill 338 156 559 339 156 559 minecraft:green_terracotta
setblock 338 156 596 minecraft:oak_log
fill 338 156 597 338 159 597 minecraft:green_terracotta
fill 339 156 596 339 159 596 minecraft:green_terracotta
setblock 340 156 559 minecraft:oak_log
setblock 341 156 558 minecraft:oak_log
fill 341 156 559 342 158 559 minecraft:green_terracotta
setblock 341 156 597 minecraft:green_terracotta
setblock 341 156 598 minecraft:oak_log
fill 342 156 558 342 159 558 minecraft:green_terracotta
setblock 342 156 597 minecraft:oak_log
fill 342 156 598 342 159 598 minecraft:green_terracotta
fill 343 156 597 344 158 597 minecraft:green_terracotta
setblock 346 156 558 minecraft:oak_log
setblock 346 156 598 minecraft:oak_log
fill 347 156 558 350 156 558 minecraft:green_terracotta
setblock 347 156 597 minecraft:oak_log
fill 347 156 598 350 156 598 minecraft:green_terracotta
fill 348 156 597 351 156 597 minecraft:green_terracotta
setblock 351 156 558 minecraft:oak_log
fill 351 156 596 352 156 596 minecraft:green_terracotta
setblock 351 156 598 minecraft:oak_log
fill 352 156 558 352 159 558 minecraft:green_terracotta
setblock 352 156 597 minecraft:oak_log
fill 352 156 598 352 159 598 minecraft:green_terracotta
setblock 353 156 595 minecraft:green_terracotta
setblock 353 156 596 minecraft:oak_log
fill 353 156 597 353 159 597 minecraft:green_terracotta
setblock 354 156 559 minecraft:green_terracotta
setblock 354 156 595 minecraft:oak_log
fill 354 156 596 354 159 596 minecraft:green_terracotta
setblock 355 156 559 minecraft:oak_log
fill 355 156 595 355 159 595 minecraft:green_terracotta
setblock 356 156 558 minecraft:oak_log
fill 356 156 559 358 157 559 minecraft:green_terracotta
fill 356 156 594 359 156 594 minecraft:green_terracotta
setblock 356 156 598 minecraft:oak_log
fill 357 156 558 357 159 558 minecraft:green_terracotta
setblock 357 156 597 minecraft:oak_log
fill 357 156 598 357 159 598 minecraft:green_terracotta
setblock 358 156 595 minecraft:green_terracotta
setblock 358 156 596 minecraft:oak_log
fill 358 156 597 358 159 597 minecraft:green_terracotta
setblock 359 156 595 minecraft:oak_log
fill 359 156 596 359 159 596 minecraft:green_terracotta
fill 360 156 595 360 159 595 minecraft:green_terracotta
setblock 361 156 558 minecraft:oak_log
setblock 361 156 598 minecraft:oak_log
setblock 362 156 595 minecraft:green_terracotta
setblock 362 156 597 minecraft:oak_log
fill 362 156 598 362 159 598 minecraft:green_terracotta
setblock 363 156 596 minecraft:oak_log
fill 363 156 597 363 159 597 minecraft:green_terracotta
setblock 366 156 598 minecraft:oak_log
fill 367 156 598 370 156 598 minecraft:green_terracotta
fill 369 156 572 369 156 574 minecraft:green_terracotta
setblock 369 156 575 minecraft:oak_log
fill 369 156 576 370 158 576 minecraft:green_terracotta
setblock 369 156 590 minecraft:oak_log
fill 369 156 591 369 158 591 minecraft:green_terracotta
setblock 369 156 595 minecraft:oak_log
setblock 370 156 559 minecraft:oak_leaves[persistent=true]
setblock 370 156 568 minecraft:green_terracotta
setblock 370 156 569 minecraft:oak_log
fill 370 156 570 370 159 570 minecraft:green_terracotta
setblock 370 156 574 minecraft:oak_log
fill 370 156 575 370 159 575 minecraft:green_terracotta
fill 370 156 577 370 156 578 minecraft:green_terracotta
setblock 370 156 579 minecraft:oak_log
fill 370 156 580 370 156 583 minecraft:green_terracotta
setblock 370 156 584 minecraft:oak_log
fill 370 156 585 370 159 585 minecraft:green_terracotta
setblock 370 156 589 minecraft:oak_log
fill 370 156 590 370 159 590 minecraft:green_terracotta
setblock 370 156 594 minecraft:oak_log
fill 370 156 595 370 159 595 minecraft:green_terracotta
setblock 330 157 559 minecraft:oak_leaves[persistent=true]
fill 330 157 564 330 160 564 minecraft:green_terracotta
setblock 330 157 568 minecraft:oak_log
fill 330 157 569 330 160 569 minecraft:green_terracotta
setblock 330 157 573 minecraft:oak_log
fill 330 157 574 330 160 574 minecraft:green_terracotta
setblock 330 157 577 minecraft:green_terracotta
setblock 330 157 578 minecraft:oak_log
fill 330 157 579 331 159 579 minecraft:green_terracotta
setblock 330 157 582 minecraft:green_terracotta
fill 330 157 584 330 158 584 minecraft:oak_leaves[persistent=true]
fill 330 157 589 330 158 589 minecraft:green_terracotta
setblock 330 157 593 minecraft:oak_log
fill 330 157 594 330 160 594 minecraft:green_terracotta
setblock 330 157 597 minecraft:green_terracotta
setblock 330 157 598 minecraft:oak_log
fill 331 157 558 334 157 558 minecraft:green_terracotta
setblock 331 157 567 minecraft:oak_log
fill 331 157 568 331 160 568 minecraft:green_terracotta
setblock 331 157 571 minecraft:green_terracotta
setblock 331 157 572 minecraft:oak_log
fill 331 157 573 331 160 573 minecraft:green_terracotta
setblock 331 157 577 minecraft:oak_log
fill 331 157 578 332 159 578 minecraft:green_terracotta
fill 331 157 580 331 158 580 minecraft:green_terracotta
fill 331 157 598 334 157 598 minecraft:green_terracotta
fill 332 157 567 332 159 567 minecraft:green_terracotta
setblock 332 157 571 minecraft:oak_log
fill 332 157 572 332 160 572 minecraft:green_terracotta
setblock 332 157 576 minecraft:oak_log
fill 332 157 577 332 160 577 minecraft:green_terracotta
fill 332 157 597 335 157 597 minecraft:green_terracotta
setblock 333 157 569 minecraft:green_terracotta
setblock 333 157 570 minecraft:oak_log
fill 333 157 571 333 160 571 minecraft:green_terracotta
setblock 333 157 574 minecraft:green_terracotta
setblock 333 157 575 minecraft:oak_log
fill 333 157 576 333 160 576 minecraft:green_terracotta
setblock 334 157 559 minecraft:oak_log
setblock 335 157 558 minecraft:oak_log
fill 335 157 559 335 160 559 minecraft:green_terracotta
fill 335 157 596 336 157 596 minecraft:green_terracotta
setblock 335 157 598 minecraft:oak_log
fill 336 157 558 336 160 558 minecraft:green_terracotta
setblock 336 157 597 minecraft:oak_log
fill 336 157 598 339 157 598 minecraft:green_terracotta
setblock 337 157 560 minecraft:green_terracotta
setblock 337 157 596 minecraft:oak_log
fill 337 157 597 337 160 597 minecraft:green_terracotta
setblock 338 157 559 minecraft:green_terracotta
setblock 338 157 560 minecraft:oak_log
fill 338 157 596 338 160 596 minecraft:green_terracotta
setblock 339 157 559 minecraft:oak_log
setblock 340 157 558 minecraft:oak_log
fill 340 157 559 340 160 559 minecraft:green_terracotta
fill 340 157 596 340 158 596 minecraft:green_terracotta
setblock 340 157 598 minecraft:oak_log
fill 341 157 558 341 160 558 minecraft:green_terracotta
setblock 341 157 597 minecraft:oak_log
fill 341 157 598 341 160 598 minecraft:green_terracotta
fill 342 157 597 342 160 597 minecraft:green_terracotta
setblock 343 157 559 minecraft:green_terracotta
setblock 344 157 558 minecraft:green_terracotta
setblock 344 157 598 minecraft:green_terracotta
setblock 345 157 558 minecraft:oak_log
fill 345 157 565 345 158 565 minecraft:oak_leaves[persistent=true]
setblock 345 157 597 minecraft:green_terracotta
setblock 345 157 598 minecraft:oak_log
fill 346 157 558 349 157 558 minecraft:green_terracotta
setblock 346 157 597 minecraft:oak_log
fill 346 157 598 349 157 598 minecraft:green_terracotta
fill 347 157 597 350 157 597 minecraft:green_terracotta
setblock 350 157 558 minecraft:oak_log
fill 350 157 578 350 179 578 minecraft:oak_log
fill 350 157 596 351 157 596 minecraft:green_terracotta
setblock 350 157 598 minecraft:oak_log
fill 351 157 558 351 160 558 minecraft:green_terracotta
setblock 351 157 597 minecraft:oak_log
fill 351 157 598 351 160 598 minecraft:green_terracotta
fill 352 157 559 353 157 559 minecraft:green_terracotta
setblock 352 157 595 minecraft:green_terracotta
setblock 352 157 596 minecraft:oak_log
fill 352 157 597 352 160 597 minecraft:green_terracotta
setblock 353 157 595 minecraft:oak_log
fill 353 157 596 353 160 596 minecraft:green_terracotta
setblock 354 157 559 minecraft:oak_log
fill 354 157 595 354 160 595 minecraft:green_terracotta
setblock 355 157 558 minecraft:oak_log
fill 355 157 559 355 160 559 minecraft:green_terracotta
fill 355 157 594 358 157 594 minecraft:green_terracotta
setblock 355 157 598 minecraft:oak_log
fill 356 157 558 356 160 558 minecraft:green_terracotta
setblock 356 157 597 minecraft:oak_log
fill 356 157 598 356 160 598 minecraft:green_terracotta
setblock 357 157 596 minecraft:oak_log
fill 357 157 597 357 160 597 minecraft:green_terracotta
setblock 358 157 595 minecraft:oak_log
fill 358 157 596 358 160 596 minecraft:green_terracotta
setblock 359 157 594 minecraft:oak_log
fill 359 157 595 359 160 595 minecraft:green_terracotta
setblock 360 157 558 minecraft:oak_log
setblock 360 157 598 minecraft:oak_log
fill 361 157 558 362 158 558 minecraft:green_terracotta
setblock 361 157 597 minecraft:oak_log
fill 361 157 598 361 160 598 minecraft:green_terracotta
setblock 362 157 596 minecraft:oak_log
fill 362 157 597 362 160 597 minecraft:green_terracotta
fill 363 157 596 363 158 596 minecraft:green_terracotta
setblock 365 157 558 minecraft:oak_leaves[persistent=true]
setblock 365 157 598 minecraft:oak_log
setblock 366 157 597 minecraft:oak_log
fill 366 157 598 369 157 598 minecraft:green_terracotta
fill 369 157 571 369 157 573 minecraft:green_terracotta
setblock 369 157 574 minecraft:oak_log
fill 369 157 575 369 160 575 minecraft:green_terracotta
fill 369 157 577 369 157 578 minecraft:green_terracotta
fill 369 157 590 369 158 590 minecraft:green_terracotta
setblock 369 157 594 minecraft:oak_log
fill 369 157 595 369 159 596 minecraft:green_terracotta
setblock 370 157 568 minecraft:oak_log
fill 370 157 569 370 160 569 minecraft:green_terracotta
setblock 370 157 573 minecraft:oak_log
fill 370 157 574 370 160 574 minecraft:green_terracotta
setblock 370 157 577 minecraft:green_terracotta
setblock 370 157 578 minecraft:oak_log
fill 370 157 579 370 157 582 minecraft:green_terracotta
setblock 370 157 583 minecraft:oak_log
fill 370 157 584 370 160 584 minecraft:green_terracotta
setblock 370 157 588 minecraft:oak_log
fill 370 157 589 370 160 589 minecraft:green_terracotta
setblock 370 157 593 minecraft:oak_log
fill 370 157 594 370 160 594 minecraft:green_terracotta
setblock 370 157 598 minecraft:oak_log
fill 330 158 558 330 160 559 minecraft:green_terracotta
fill 330 158 563 330 161 563 minecraft:green_terracotta
setblock 330 158 567 minecraft:oak_log
fill 330 158 568 330 161 568 minecraft:green_terracotta
setblock 330 158 572 minecraft:oak_log
fill 330 158 573 330 161 573 minecraft:green_terracotta
setblock 330 158 576 minecraft:green_terracotta
setblock 330 158 577 minecraft:oak_log
fill 330 158 578 330 161 578 minecraft:green_terracotta
setblock 330 158 582 minecraft:oak_log
fill 330 158 583 330 161 583 minecraft:green_terracotta
setblock 330 158 592 minecraft:oak_log
fill 330 158 593 331 158 593 minecraft:green_terracotta
setblock 330 158 597 minecraft:oak_log
fill 330 158 598 333 158 598 minecraft:green_terracotta
fill 331 158 558 333 158 558 minecraft:green_terracotta
setblock 331 158 566 minecraft:oak_log
fill 331 158 567 331 161 567 minecraft:green_terracotta
setblock 331 158 571 minecraft:oak_log
fill 331 158 572 331 161 572 minecraft:green_terracotta
setblock 331 158 575 minecraft:green_terracotta
setblock 331 158 576 minecraft:oak_log
fill 331 158 577 331 161 577 minecraft:green_terracotta
setblock 331 158 581 minecraft:oak_log
fill 331 158 594 331 158 595 minecraft:green_terracotta
setblock 331 158 596 minecraft:oak_log
fill 331 158 597 334 158 597 minecraft:green_terracotta
setblock 332 158 559 minecraft:green_terracotta
setblock 332 158 570 minecraft:oak_log
fill 332 158 571 332 161 571 minecraft:green_terracotta
setblock 332 158 575 minecraft:oak_log
fill 332 158 576 332 161 576 minecraft:green_terracotta
setblock 332 158 579 minecraft:green_terracotta
setblock 333 158 559 minecraft:oak_log
setblock 333 158 569 minecraft:oak_log
fill 333 158 570 333 160 570 minecraft:green_terracotta
setblock 333 158 574 minecraft:oak_log
fill 333 158 575 333 161 575 minecraft:green_terracotta
fill 333 158 577 333 159 577 minecraft:green_terracotta
setblock 334 158 558 minecraft:oak_log
fill 334 158 559 334 161 559 minecraft:green_terracotta
setblock 334 158 572 minecraft:green_terracotta
setblock 334 158 573 minecraft:oak_log
setblock 334 158 574 minecraft:green_terracotta
fill 334 158 596 335 158 596 minecraft:green_terracotta
setblock 334 158 598 minecraft:oak_log
fill 335 158 558 335 161 558 minecraft:green_terracotta
fill 335 158 560 336 158 560 minecraft:green_terracotta
setblock 335 158 597 minecraft:oak_log
fill 335 158 598 338 158 598 minecraft:green_terracotta
setblock 336 158 596 minecraft:oak_log
fill 336 158 597 336 161 597 minecraft:green_terracotta
setblock 337 158 560 minecraft:oak_log
fill 337 158 596 337 160 596 minecraft:green_terracotta
setblock 338 158 559 minecraft:oak_log
fill 338 158 560 339 159 560 minecraft:green_terracotta
setblock 339 158 558 minecraft:oak_log
fill 339 158 559 339 161 559 minecraft:green_terracotta
setblock 339 158 598 minecraft:oak_log
fill 340 158 558 340 161 558 minecraft:green_terracotta
setblock 340 158 597 minecraft:oak_log
fill 340 158 598 340 161 598 minecraft:green_terracotta
fill 341 158 597 341 161 597 minecraft:green_terracotta
setblock 343 158 559 minecraft:oak_log
setblock 344 158 558 minecraft:oak_log
setblock 344 158 598 minecraft:oak_log
fill 345 158 558 348 158 558 minecraft:green_terracotta
setblock 345 158 597 minecraft:oak_log
fill 345 158 598 348 158 598 minecraft:green_terracotta
fill 346 158 597 349 158 597 minecraft:green_terracotta
setblock 349 158 558 minecraft:oak_log
fill 349 158 596 350 158 596 minecraft:green_terracotta
setblock 349 158 598 minecraft:oak_log
fill 350 158 558 350 160 559 minecraft:green_terracotta
setblock 350 158 597 minecraft:oak_log
fill 350 158 598 350 161 598 minecraft:green_terracotta
fill 351 158 559 352 158 559 minecraft:green_terracotta
setblock 351 158 595 minecraft:green_terracotta
setblock 351 158 596 minecraft:oak_log
fill 351 158 597 351 161 597 minecraft:green_terracotta
setblock 352 158 595 minecraft:oak_log
fill 352 158 596 352 161 596 minecraft:green_terracotta
setblock 353 158 559 minecraft:oak_log
fill 353 158 595 353 161 595 minecraft:green_terracotta
setblock 354 158 558 minecraft:oak_log
fill 354 158 559 354 161 559 minecraft:green_terracotta
fill 354 158 594 357 158 594 minecraft:green_terracotta
setblock 354 158 598 minecraft:oak_log
fill 355 158 558 355 161 558 minecraft:green_terracotta
setblock 355 158 597 minecraft:oak_log
fill 355 158 598 355 161 598 minecraft:green_terracotta
fill 356 158 559 357 158 559 minecraft:green_terracotta
setblock 356 158 596 minecraft:oak_log
fill 356 158 597 356 161 597 minecraft:green_terracotta
setblock 357 158 595 minecraft:oak_log
fill 357 158 596 357 161 596 minecraft:green_terracotta
setblock 358 158 559 minecraft:oak_log
setblock 358 158 594 minecraft:oak_log
fill 358 158 595 358 161 595 minecraft:green_terracotta
setblock 359 158 558 minecraft:oak_log
setblock 359 158 598 minecraft:oak_log
fill 360 158 558 360 161 558 minecraft:green_terracotta
setblock 360 158 597 minecraft:oak_log
fill 360 158 598 360 161 598 minecraft:green_terracotta
setblock 361 158 596 minecraft:oak_log
fill 361 158 597 361 161 597 minecraft:green_terracotta
fill 362 158 596 362 159 596 minecraft:green_terracotta
setblock 364 158 597 minecraft:green_terracotta
setblock 364 158 598 minecraft:oak_log
setblock 365 158 597 minecraft:oak_log
fill 365 158 598 368 158 598 minecraft:green_terracotta
fill 366 158 597 366 159 597 minecraft:green_terracotta
fill 369 158 571 369 158 572 minecraft:green_terracotta
setblock 369 158 573 minecraft:oak_log
fill 369 158 574 369 161 574 minecraft:green_terracotta
setblock 369 158 577 minecraft:green_terracotta
setblock 369 158 578 minecraft:oak_log
fill 369 158 579 370 159 580 minecraft:green_terracotta
setblock 369 158 593 minecraft:oak_log
fill 369 158 594 369 160 594 minecraft:green_terracotta
setblock 369 158 598 minecraft:oak_log
setblock 370 158 566 minecraft:oak_leaves[persistent=true]
fill 370 158 568 370 161 568 minecraft:green_terracotta
setblock 370 158 572 minecraft:oak_log
fill 370 158 573 370 161 573 minecraft:green_terracotta
setblock 370 158 577 minecraft:oak_log
fill 370 158 578 370 161 578 minecraft:green_terracotta
setblock 370 158 581 minecraft:green_terracotta
setblock 370 158 582 minecraft:oak_log
fill 370 158 583 370 161 583 minecraft:green_terracotta
setblock 370 158 587 minecraft:oak_log
fill 370 158 588 370 161 588 minecraft:green_terracotta
setblock 370 158 592 minecraft:oak_log
fill 370 158 593 370 161 593 minecraft:green_terracotta
setblock 370 158 596 minecraft:green_terracotta
setblock 370 158 597 minecraft:oak_log
fill 370 158 598 370 161 598 minecraft:green_terracotta
setblock 330 159 560 minecraft:green_terracotta
setblock 330 159 561 minecraft:oak_log
fill 330 159 562 330 162 562 minecraft:green_terracotta
setblock 330 159 566 minecraft:oak_log
fill 330 159 567 330 162 567 minecraft:green_terracotta
setblock 330 159 571 minecraft:oak_log
fill 330 159 572 330 162 572 minecraft:green_terracotta
setblock 330 159 576 minecraft:oak_log
fill 330 159 577 330 162 577 minecraft:green_terracotta
setblock 330 159 580 minecraft:green_terracotta
setblock 330 159 581 minecraft:oak_log
fill 330 159 582 330 162 582 minecraft:green_terracotta
setblock 330 159 591 minecraft:oak_log
fill 330 159 592 330 160 593 minecraft:green_terracotta
setblock 330 159 595 minecraft:green_terracotta
setblock 330 159 596 minecraft:oak_log
fill 330 159 597 332 159 598 minecraft:green_terracotta
fill 331 159 558 331 159 559 minecraft:green_terracotta
setblock 331 159 565 minecraft:oak_log
fill 331 159 566 331 162 566 minecraft:green_terracotta
setblock 331 159 570 minecraft:oak_log
fill 331 159 571 331 162 571 minecraft:green_terracotta
setblock 331 159 575 minecraft:oak_log
fill 331 159 576 331 162 576 minecraft:green_terracotta
setblock 331 159 580 minecraft:oak_log
fill 331 159 581 331 162 581 minecraft:green_terracotta
setblock 331 159 594 minecraft:green_terracotta
setblock 331 159 595 minecraft:oak_log
fill 331 159 596 331 162 596 minecraft:green_terracotta
setblock 332 159 558 minecraft:green_terracotta
setblock 332 159 559 minecraft:oak_log
setblock 332 159 569 minecraft:oak_log
fill 332 159 570 332 162 570 minecraft:green_terracotta
setblock 332 159 573 minecraft:green_terracotta
setblock 332 159 574 minecraft:oak_log
fill 332 159 575 332 162 575 minecraft:green_terracotta
setblock 332 159 579 minecraft:oak_log
setblock 333 159 558 minecraft:oak_log
fill 333 159 559 333 162 559 minecraft:green_terracotta
setblock 333 159 569 minecraft:green_terracotta
setblock 333 159 573 minecraft:oak_log
fill 333 159 574 333 162 574 minecraft:green_terracotta
setblock 333 159 597 minecraft:green_terracotta
setblock 333 159 598 minecraft:oak_log
fill 334 159 558 334 162 558 minecraft:green_terracotta
fill 334 159 560 335 159 560 minecraft:green_terracotta
setblock 334 159 573 minecraft:green_terracotta
setblock 334 159 596 minecraft:green_terracotta
setblock 334 159 597 minecraft:oak_log
fill 334 159 598 337 159 598 minecraft:green_terracotta
setblock 335 159 596 minecraft:oak_log
fill 335 159 597 335 162 597 minecraft:green_terracotta
setblock 336 159 560 minecraft:oak_log
fill 336 159 596 336 161 596 minecraft:green_terracotta
setblock 337 159 559 minecraft:oak_log
fill 337 159 560 337 162 560 minecraft:green_terracotta
setblock 338 159 558 minecraft:oak_log
fill 338 159 559 338 162 559 minecraft:green_terracotta
setblock 338 159 598 minecraft:oak_log
fill 339 159 558 339 162 558 minecraft:green_terracotta
setblock 339 159 597 minecraft:oak_log
fill 339 159 598 339 162 598 minecraft:green_terracotta
setblock 340 159 596 minecraft:oak_log
fill 340 159 597 340 162 597 minecraft:green_terracotta
setblock 341 159 559 minecraft:green_terracotta
setblock 342 159 559 minecraft:oak_log
setblock 343 159 558 minecraft:oak_log
fill 343 159 559 343 161 559 minecraft:green_terracotta
setblock 343 159 597 minecraft:green_terracotta
setblock 343 159 598 minecraft:oak_log
fill 344 159 558 347 159 558 minecraft:green_terracotta
setblock 344 159 597 minecraft:oak_log
fill 344 159 598 347 159 598 minecraft:green_terracotta
fill 345 159 597 348 159 597 minecraft:green_terracotta
setblock 348 159 558 minecraft:oak_log
fill 348 159 596 349 159 596 minecraft:green_terracotta
setblock 348 159 598 minecraft:oak_log
fill 349 159 558 349 161 559 minecraft:green_terracotta
setblock 349 159 597 minecraft:oak_log
fill 349 159 598 349 162 598 minecraft:green_terracotta
setblock 350 159 596 minecraft:oak_log
fill 350 159 597 350 162 597 minecraft:green_terracotta
setblock 351 159 559 minecraft:green_terracotta
setblock 351 159 595 minecraft:oak_log
fill 351 159 596 351 162 596 minecraft:green_terracotta
setblock 352 159 559 minecraft:oak_log
fill 352 159 595 352 162 595 minecraft:green_terracotta
setblock 353 159 558 minecraft:oak_log
fill 353 159 559 353 162 559 minecraft:green_terracotta
setblock 353 159 598 minecraft:oak_log
fill 354 159 558 354 162 558 minecraft:green_terracotta
fill 354 159 594 356 159 594 minecraft:green_terracotta
setblock 354 159 597 minecraft:oak_log
fill 354 159 598 354 162 598 minecraft:green_terracotta
setblock 355 159 596 minecraft:oak_log
fill 355 159 597 355 162 597 minecraft:green_terracotta
setblock 356 159 559 minecraft:green_terracotta
setblock 356 159 595 minecraft:oak_log
fill 356 159 596 356 162 596 minecraft:green_terracotta
setblock 357 159 559 minecraft:oak_log
setblock 357 159 594 minecraft:oak_log
fill 357 159 595 357 161 595 minecraft:green_terracotta
setblock 358 159 558 minecraft:oak_log
fill 358 159 559 358 160 559 minecraft:green_terracotta
setblock 358 159 598 minecraft:oak_log
fill 359 159 558 359 162 558 minecraft:green_terracotta
setblock 359 159 597 minecraft:oak_log
fill 359 159 598 359 162 598 minecraft:green_terracotta
setblock 360 159 596 minecraft:oak_log
fill 360 159 597 360 162 597 minecraft:green_terracotta
fill 361 159 558 361 160 558 minecraft:green_terracotta
fill 361 159 596 361 160 596 minecraft:green_terracotta
setblock 363 159 598 minecraft:oak_log
setblock 364 159 597 minecraft:oak_log
fill 364 159 598 367 159 598 minecraft:green_terracotta
setblock 365 159 597 minecraft:green_terracotta
setblock 368 159 598 minecraft:oak_log
setblock 369 159 571 minecraft:green_terracotta
setblock 369 159 572 minecraft:oak_log
fill 369 159 573 369 162 573 minecraft:green_terracotta
setblock 369 159 576 minecraft:green_terracotta
setblock 369 159 577 minecraft:oak_log
fill 369 159 578 369 162 578 minecraft:green_terracotta
setblock 369 159 581 minecraft:green_terracotta
setblock 369 159 592 minecraft:oak_log
fill 369 159 593 369 160 593 minecraft:green_terracotta
setblock 369 159 597 minecraft:oak_log
fill 369 159 598 369 162 598 minecraft:green_terracotta
setblock 370 159 560 minecraft:oak_leaves[persistent=true]
setblock 370 159 567 minecraft:green_terracotta
setblock 370 159 571 minecraft:oak_log
fill 370 159 572 370 162 572 minecraft:green_terracotta
setblock 370 159 576 minecraft:oak_log
fill 370 159 577 370 162 577 minecraft:green_terracotta
setblock 370 159 581 minecraft:oak_log
fill 370 159 582 370 162 582 minecraft:green_terracotta
setblock 370 159 586 minecraft:oak_log
fill 370 159 587 370 162 587 minecraft:green_terracotta
setblock 370 159 591 minecraft:oak_log
fill 370 159 592 370 162 592 minecraft:green_terracotta
setblock 370 159 596 minecraft:oak_log
fill 370 159 597 370 162 597 minecraft:green_terracotta
setblock 330 160 560 minecraft:oak_log
fill 330 160 561 331 162 561 minecraft:green_terracotta
setblock 330 160 565 minecraft:oak_log
fill 330 160 566 330 163 566 minecraft:green_terracotta
setblock 330 160 570 minecraft:oak_log
fill 330 160 571 330 163 571 minecraft:green_terracotta
setblock 330 160 575 minecraft:oak_log
fill 330 160 576 330 163 576 minecraft:green_terracotta
setblock 330 160 579 minecraft:green_terracotta
setblock 330 160 580 minecraft:oak_log
fill 330 160 581 330 163 581 minecraft:green_terracotta
setblock 330 160 584 minecraft:green_terracotta
setblock 330 160 591 minecraft:green_terracotta
setblock 330 160 595 minecraft:oak_log
fill 330 160 596 330 161 598 minecraft:green_terracotta
setblock 331 160 558 minecraft:green_terracotta
setblock 331 160 559 minecraft:oak_log
fill 331 160 560 331 163 560 minecraft:green_terracotta
fill 331 160 562 331 161 562 minecraft:green_terracotta
setblock 331 160 564 minecraft:oak_log
fill 331 160 565 331 163 565 minecraft:green_terracotta
setblock 331 160 569 minecraft:oak_log
fill 331 160 570 331 163 570 minecraft:green_terracotta
setblock 331 160 574 minecraft:oak_log
fill 331 160 575 331 163 575 minecraft:green_terracotta
setblock 331 160 578 minecraft:green_terracotta
setblock 331 160 579 minecraft:oak_log
fill 331 160 580 332 162 580 minecraft:green_terracotta
setblock 331 160 594 minecraft:oak_log
fill 331 160 595 331 161 595 minecraft:green_terracotta
fill 331 160 597 331 160 598 minecraft:green_terracotta
setblock 332 160 558 minecraft:oak_log
fill 332 160 559 332 163 559 minecraft:green_terracotta
setblock 332 160 568 minecraft:oak_log
fill 332 160 569 332 161 569 minecraft:green_terracotta
setblock 332 160 573 minecraft:oak_log
fill 332 160 574 332 163 574 minecraft:green_terracotta
setblock 332 160 578 minecraft:oak_log
fill 332 160 579 332 163 579 minecraft:green_terracotta
setblock 332 160 597 minecraft:green_terracotta
setblock 332 160 598 minecraft:oak_log
fill 333 160 558 333 163 558 minecraft:green_terracotta
fill 333 160 560 334 160 560 minecraft:green_terracotta
setblock 333 160 572 minecraft:oak_log
fill 333 160 573 333 161 573 minecraft:green_terracotta
setblock 333 160 577 minecraft:oak_log
setblock 333 160 597 minecraft:oak_log
fill 333 160 598 336 160 598 minecraft:green_terracotta
setblock 334 160 596 minecraft:oak_log
fill 334 160 597 334 163 597 minecraft:green_terracotta
setblock 335 160 560 minecraft:oak_log
fill 335 160 596 335 161 596 minecraft:green_terracotta
setblock 336 160 559 minecraft:oak_log
fill 336 160 560 336 163 560 minecraft:green_terracotta
setblock 337 160 558 minecraft:oak_log
fill 337 160 559 337 163 559 minecraft:green_terracotta
setblock 337 160 598 minecraft:oak_log
fill 338 160 558 338 163 558 minecraft:green_terracotta
fill 338 160 560 338 161 560 minecraft:green_terracotta
setblock 338 160 597 minecraft:oak_log
fill 338 160 598 338 163 598 minecraft:green_terracotta
fill 339 160 597 339 163 597 minecraft:green_terracotta
setblock 341 160 559 minecraft:oak_log
setblock 342 160 558 minecraft:oak_log
fill 342 160 559 342 162 559 minecraft:green_terracotta
setblock 342 160 598 minecraft:oak_log
fill 343 160 558 346 160 558 minecraft:green_terracotta
setblock 343 160 597 minecraft:oak_log
fill 343 160 598 346 160 598 minecraft:green_terracotta
fill 344 160 597 347 160 597 minecraft:green_terracotta
setblock 347 160 558 minecraft:oak_log
setblock 347 160 598 minecraft:oak_log
fill 348 160 558 348 162 559 minecraft:green_terracotta
setblock 348 160 596 minecraft:green_terracotta
setblock 348 160 597 minecraft:oak_log
fill 348 160 598 348 163 598 minecraft:green_terracotta
setblock 349 160 596 minecraft:oak_log
fill 349 160 597 349 163 597 minecraft:green_terracotta
fill 350 160 596 350 163 596 minecraft:green_terracotta
setblock 351 160 559 minecraft:oak_log
fill 351 160 595 351 161 595 minecraft:green_terracotta
setblock 352 160 558 minecraft:oak_log
fill 352 160 559 352 163 559 minecraft:green_terracotta
setblock 352 160 598 minecraft:oak_log
fill 353 160 558 353 163 558 minecraft:green_terracotta
setblock 353 160 597 minecraft:oak_log
fill 353 160 598 353 163 598 minecraft:green_terracotta
setblock 354 160 596 minecraft:oak_log
fill 354 160 597 354 163 597 minecraft:green_terracotta
setblock 355 160 595 minecraft:oak_log
fill 355 160 596 355 163 596 minecraft:green_terracotta
setblock 356 160 559 minecraft:oak_log
fill 356 160 595 356 162 595 minecraft:green_terracotta
setblock 357 160 558 minecraft:oak_log
fill 357 160 559 357 162 559 minecraft:green_terracotta
setblock 357 160 598 minecraft:oak_log
fill 358 160 558 358 163 558 minecraft:green_terracotta
setblock 358 160 597 minecraft:oak_log
fill 358 160 598 358 163 598 minecraft:green_terracotta
setblock 359 160 596 minecraft:oak_log
fill 359 160 597 359 163 597 minecraft:green_terracotta
fill 360 160 596 360 161 596 minecraft:green_terracotta
setblock 362 160 598 minecraft:oak_log
setblock 363 160 597 minecraft:oak_log
fill 363 160 598 366 160 598 minecraft:green_terracotta
setblock 364 160 597 minecraft:green_terracotta
setblock 366 160 558 minecraft:oak_leaves[persistent=true]
setblock 367 160 598 minecraft:oak_log
fill 368 160 575 368 160 576 minecraft:green_terracotta
setblock 368 160 577 minecraft:oak_log
fill 368 160 598 368 163 598 minecraft:green_terracotta
setblock 369 160 571 minecraft:oak_log
fill 369 160 572 369 163 572 minecraft:green_terracotta
setblock 369 160 576 minecraft:oak_log
fill 369 160 577 369 163 577 minecraft:green_terracotta
fill 369 160 579 369 160 580 minecraft:green_terracotta
setblock 369 160 581 minecraft:oak_log
fill 369 160 582 369 163 582 minecraft:green_terracotta
setblock 369 160 595 minecraft:green_terracotta
setblock 369 160 596 minecraft:oak_log
setblock 369 160 597 minecraft:green_terracotta
fill 370 160 558 370 161 558 minecraft:green_terracotta
setblock 370 160 570 minecraft:oak_log
fill 370 160 571 370 163 571 minecraft:green_terracotta
setblock 370 160 575 minecraft:oak_log
fill 370 160 576 370 163 576 minecraft:green_terracotta
setblock 370 160 579 minecraft:green_terracotta
setblock 370 160 580 minecraft:oak_log
fill 370 160 581 370 163 581 minecraft:green_terracotta
setblock 370 160 585 minecraft:oak_log
fill 370 160 586 370 163 586 minecraft:green_terracotta
setblock 370 160 590 minecraft:oak_log
fill 370 160 591 370 162 591 minecraft:green_terracotta
setblock 370 160 595 minecraft:oak_log
fill 370 160 596 370 163 596 minecraft:green_terracotta
setblock 330 161 558 minecraft:green_terracotta
setblock 330 161 559 minecraft:oak_log
fill 330 161 560 330 164 560 minecraft:green_terracotta
setblock 330 161 564 minecraft:oak_log
fill 330 161 565 330 164 565 minecraft:green_terracotta
setblock 330 161 569 minecraft:oak_log
fill 330 161 570 330 164 570 minecraft:green_terracotta
setblock 330 161 574 minecraft:oak_log
fill 330 161 575 330 164 575 minecraft:green_terracotta
setblock 330 161 579 minecraft:oak_log
fill 330 161 580 330 164 580 minecraft:green_terracotta
setblock 330 161 584 minecraft:oak_log
setblock 330 161 593 minecraft:green_terracotta
setblock 330 161 594 minecraft:oak_log
fill 330 161 595 330 164 595 minecraft:green_terracotta
setblock 331 161 558 minecraft:oak_log
fill 331 161 559 331 164 559 minecraft:green_terracotta
setblock 331 161 563 minecraft:oak_log
fill 331 161 564 331 164 564 minecraft:green_terracotta
setblock 331 161 568 minecraft:oak_log
fill 331 161 569 331 164 569 minecraft:green_terracotta
setblock 331 161 573 minecraft:oak_log
fill 331 161 574 331 164 574 minecraft:green_terracotta
setblock 331 161 578 minecraft:oak_log
fill 331 161 579 331 164 579 minecraft:green_terracotta
setblock 331 161 582 minecraft:green_terracotta
setblock 331 161 597 minecraft:green_terracotta
setblock 331 161 598 minecraft:oak_log
fill 332 161 558 332 164 558 minecraft:green_terracotta
setblock 332 161 560 minecraft:light[level=14]
setblock 332 161 568 minecraft:light[level=14]
setblock 332 161 572 minecraft:oak_log
fill 332 161 573 332 164 573 minecraft:green_terracotta
setblock 332 161 577 minecraft:oak_log
fill 332 161 578 332 164 578 minecraft:green_terracotta
setblock 332 161 584 minecraft:light[level=14]
setblock 332 161 592 minecraft:light[level=14]
setblock 332 161 597 minecraft:oak_log
fill 332 161 598 335 161 598 minecraft:green_terracotta
setblock 333 161 560 minecraft:green_terracotta
setblock 333 161 572 minecraft:green_terracotta
setblock 333 161 576 minecraft:oak_log
fill 333 161 577 333 162 577 minecraft:green_terracotta
fill 333 161 597 333 164 597 minecraft:green_terracotta
setblock 334 161 560 minecraft:oak_log
setblock 335 161 559 minecraft:oak_log
fill 335 161 560 335 164 560 minecraft:green_terracotta
setblock 336 161 558 minecraft:oak_log
fill 336 161 559 336 164 559 minecraft:green_terracotta
setblock 336 161 598 minecraft:oak_log
fill 337 161 558 337 164 558 minecraft:green_terracotta
setblock 337 161 597 minecraft:oak_log
fill 337 161 598 337 164 598 minecraft:green_terracotta
fill 338 161 597 338 163 597 minecraft:green_terracotta
setblock 340 161 559 minecraft:oak_log
setblock 340 161 560 minecraft:light[level=14]
setblock 340 161 568 minecraft:light[level=14]
setblock 340 161 576 minecraft:light[level=14]
setblock 340 161 584 minecraft:light[level=14]
setblock 340 161 592 minecraft:light[level=14]
setblock 341 161 558 minecraft:oak_log
fill 341 161 559 341 164 559 minecraft:green_terracotta
setblock 341 161 598 minecraft:oak_log
fill 342 161 558 345 161 558 minecraft:green_terracotta
setblock 342 161 597 minecraft:oak_log
fill 342 161 598 345 161 598 minecraft:green_terracotta
fill 343 161 597 346 161 597 minecraft:green_terracotta
setblock 346 161 558 minecraft:oak_log
setblock 346 161 598 minecraft:oak_log
fill 347 161 558 347 163 559 minecraft:green_terracotta
setblock 347 161 597 minecraft:oak_log
fill 347 161 598 347 164 598 minecraft:green_terracotta
setblock 348 161 560 minecraft:light[level=14]
setblock 348 161 568 minecraft:light[level=14]
setblock 348 161 576 minecraft:light[level=14]
setblock 348 161 584 minecraft:light[level=14]
setblock 348 161 592 minecraft:light[level=14]
setblock 348 161 596 minecraft:oak_log
fill 348 161 597 348 164 597 minecraft:green_terracotta
fill 349 161 596 349 164 596 minecraft:green_terracotta
setblock 350 161 558 minecraft:green_terracotta
setblock 350 161 559 minecraft:oak_log
setblock 351 161 558 minecraft:oak_log
fill 351 161 559 351 164 559 minecraft:green_terracotta
setblock 351 161 598 minecraft:oak_log
fill 352 161 558 352 164 558 minecraft:green_terracotta
setblock 352 161 597 minecraft:oak_log
fill 352 161 598 352 164 598 minecraft:green_terracotta
setblock 353 161 596 minecraft:oak_log
fill 353 161 597 353 164 597 minecraft:green_terracotta
setblock 354 161 595 minecraft:oak_log
fill 354 161 596 354 164 596 minecraft:green_terracotta
setblock 355 161 559 minecraft:oak_log
fill 355 161 595 355 162 595 minecraft:green_terracotta
setblock 356 161 558 minecraft:oak_log
fill 356 161 559 356 164 559 minecraft:green_terracotta
setblock 356 161 560 minecraft:light[level=14]
setblock 356 161 568 minecraft:light[level=14]
setblock 356 161 576 minecraft:light[level=14]
setblock 356 161 584 minecraft:light[level=14]
setblock 356 161 592 minecraft:light[level=14]
setblock 356 161 598 minecraft:oak_log
fill 357 161 558 357 164 558 minecraft:green_terracotta
setblock 357 161 597 minecraft:oak_log
fill 357 161 598 357 164 598 minecraft:green_terracotta
setblock 358 161 596 minecraft:oak_log
fill 358 161 597 358 164 597 minecraft:green_terracotta
fill 359 161 596 359 162 596 minecraft:green_terracotta
setblock 361 161 558 minecraft:oak_log
setblock 361 161 598 minecraft:oak_log
setblock 362 161 597 minecraft:oak_log
fill 362 161 598 365 161 598 minecraft:green_terracotta
setblock 363 161 597 minecraft:green_terracotta
setblock 364 161 560 minecraft:light[level=14]
setblock 364 161 568 minecraft:light[level=14]
setblock 364 161 576 minecraft:light[level=14]
setblock 364 161 584 minecraft:light[level=14]
setblock 364 161 592 minecraft:light[level=14]
setblock 366 161 598 minecraft:oak_log
fill 367 161 598 367 163 598 minecraft:green_terracotta
setblock 368 161 575 minecraft:green_terracotta
setblock 368 161 576 minecraft:oak_log
fill 368 161 577 368 163 578 minecraft:green_terracotta
setblock 369 161 571 minecraft:green_terracotta
setblock 369 161 575 minecraft:oak_log
fill 369 161 576 369 164 576 minecraft:green_terracotta
setblock 369 161 579 minecraft:green_terracotta
setblock 369 161 580 minecraft:oak_log
fill 369 161 581 369 164 581 minecraft:green_terracotta
setblock 370 161 559 minecraft:oak_log
setblock 370 161 569 minecraft:oak_log
fill 370 161 570 370 164 570 minecraft:green_terracotta
setblock 370 161 574 minecraft:oak_log
fill 370 161 575 370 164 575 minecraft:green_terracotta
setblock 370 161 579 minecraft:oak_log
fill 370 161 580 370 164 580 minecraft:green_terracotta
setblock 370 161 584 minecraft:oak_log
fill 370 161 585 370 164 585 minecraft:green_terracotta
setblock 370 161 589 minecraft:oak_log
fill 370 161 590 370 162 590 minecraft:green_terracotta
setblock 370 161 594 minecraft:oak_log
fill 370 161 595 370 164 595 minecraft:green_terracotta
setblock 330 162 558 minecraft:oak_log
fill 330 162 559 330 165 559 minecraft:green_terracotta
setblock 330 162 563 minecraft:oak_log
fill 330 162 564 330 165 564 minecraft:green_terracotta
setblock 330 162 568 minecraft:oak_log
fill 330 162 569 330 165 569 minecraft:green_terracotta
setblock 330 162 573 minecraft:oak_log
fill 330 162 574 330 165 574 minecraft:green_terracotta
setblock 330 162 578 minecraft:oak_log
fill 330 162 579 330 165 579 minecraft:green_terracotta
setblock 330 162 583 minecraft:oak_log
fill 330 162 584 330 165 584 minecraft:green_terracotta
setblock 330 162 589 minecraft:oak_leaves[persistent=true]
setblock 330 162 594 minecraft:green_terracotta
fill 330 162 596 330 162 597 minecraft:green_terracotta
setblock 330 162 598 minecraft:oak_log
fill 331 162 558 331 165 558 minecraft:green_terracotta
setblock 331 162 562 minecraft:oak_log
fill 331 162 563 331 165 563 minecraft:green_terracotta
setblock 331 162 567 minecraft:oak_log
fill 331 162 568 331 165 568 minecraft:green_terracotta
setblock 331 162 572 minecraft:oak_log
fill 331 162 573 331 165 573 minecraft:green_terracotta
setblock 331 162 577 minecraft:oak_log
fill 331 162 578 331 165 578 minecraft:green_terracotta
setblock 331 162 582 minecraft:oak_log
setblock 331 162 597 minecraft:oak_log
fill 331 162 598 334 162 598 minecraft:green_terracotta
setblock 332 162 560 minecraft:green_terracotta
setblock 332 162 571 minecraft:oak_log
fill 332 162 572 332 163 572 minecraft:green_terracotta
setblock 332 162 576 minecraft:oak_log
fill 332 162 577 332 165 577 minecraft:green_terracotta
fill 332 162 597 332 165 597 minecraft:green_terracotta
setblock 333 162 560 minecraft:oak_log
setblock 333 162 575 minecraft:oak_log
setblock 333 162 576 minecraft:green_terracotta
setblock 334 162 559 minecraft:oak_log
fill 334 162 560 334 165 560 minecraft:green_terracotta
setblock 335 162 558 minecraft:oak_log
fill 335 162 559 335 165 559 minecraft:green_terracotta
setblock 335 162 598 minecraft:oak_log
fill 336 162 558 336 165 558 minecraft:green_terracotta
setblock 336 162 597 minecraft:oak_log
fill 336 162 598 336 165 598 minecraft:green_terracotta
fill 337 162 597 337 164 597 minecraft:green_terracotta
setblock 339 162 559 minecraft:oak_log
setblock 340 162 558 minecraft:oak_log
fill 340 162 559 340 165 559 minecraft:green_terracotta
setblock 340 162 598 minecraft:oak_log
fill 341 162 558 344 162 558 minecraft:green_terracotta
setblock 341 162 597 minecraft:oak_log
fill 341 162 598 344 162 598 minecraft:green_terracotta
fill 342 162 597 345 162 597 minecraft:green_terracotta
setblock 345 162 558 minecraft:oak_log
setblock 345 162 598 minecraft:oak_log
fill 346 162 558 346 165 558 minecraft:green_terracotta
setblock 346 162 597 minecraft:oak_log
fill 346 162 598 346 165 598 minecraft:green_terracotta
fill 347 162 597 347 165 597 minecraft:green_terracotta
setblock 348 162 596 minecraft:green_terracotta
setblock 349 162 558 minecraft:green_terracotta
setblock 349 162 559 minecraft:oak_log
setblock 350 162 558 minecraft:oak_log
fill 350 162 559 350 165 559 minecraft:green_terracotta
setblock 350 162 598 minecraft:oak_log
fill 351 162 558 351 165 558 minecraft:green_terracotta
setblock 351 162 597 minecraft:oak_log
fill 351 162 598 351 165 598 minecraft:green_terracotta
setblock 352 162 596 minecraft:oak_log
fill 352 162 597 352 165 597 minecraft:green_terracotta
setblock 353 162 595 minecraft:oak_log
fill 353 162 596 353 165 596 minecraft:green_terracotta
setblock 354 162 559 minecraft:oak_log
setblock 354 162 595 minecraft:green_terracotta
setblock 355 162 558 minecraft:oak_log
fill 355 162 559 355 165 559 minecraft:green_terracotta
setblock 355 162 598 minecraft:oak_log
fill 356 162 558 356 165 558 minecraft:green_terracotta
setblock 356 162 597 minecraft:oak_log
fill 356 162 598 356 165 598 minecraft:green_terracotta
setblock 357 162 596 minecraft:oak_log
fill 357 162 597 357 165 597 minecraft:green_terracotta
setblock 358 162 596 minecraft:green_terracotta
setblock 360 162 558 minecraft:oak_log
setblock 360 162 598 minecraft:oak_log
setblock 361 162 597 minecraft:oak_log
fill 361 162 598 364 162 598 minecraft:green_terracotta
setblock 365 162 598 minecraft:oak_log
setblock 366 162 598 minecraft:green_terracotta
fill 368 162 576 368 165 576 minecraft:green_terracotta
setblock 368 162 579 minecraft:green_terracotta
setblock 369 162 558 minecraft:green_terracotta
setblock 369 162 574 minecraft:oak_log
fill 369 162 575 369 165 575 minecraft:green_terracotta
setblock 369 162 579 minecraft:oak_log
fill 369 162 580 369 165 580 minecraft:green_terracotta
setblock 369 162 583 minecraft:green_terracotta
setblock 370 162 558 minecraft:oak_log
fill 370 162 559 370 164 560 minecraft:green_terracotta
setblock 370 162 567 minecraft:oak_leaves[persistent=true]
setblock 370 162 568 minecraft:oak_log
fill 370 162 569 370 165 569 minecraft:green_terracotta
setblock 370 162 573 minecraft:oak_log
fill 370 162 574 370 165 574 minecraft:green_terracotta
setblock 370 162 578 minecraft:oak_log
fill 370 162 579 370 165 579 minecraft:green_terracotta
setblock 370 162 583 minecraft:oak_log
fill 370 162 584 370 165 584 minecraft:green_terracotta
setblock 370 162 588 minecraft:oak_log
setblock 370 162 589 minecraft:green_terracotta
setblock 370 162 593 minecraft:oak_log
fill 370 162 594 370 164 594 minecraft:green_terracotta
setblock 370 162 598 minecraft:oak_log
fill 330 163 558 330 166 558 minecraft:green_terracotta
setblock 330 163 561 minecraft:green_terracotta
setblock 330 163 562 minecraft:oak_log
fill 330 163 563 330 166 563 minecraft:green_terracotta
setblock 330 163 567 minecraft:oak_log
fill 330 163 568 330 166 568 minecraft:green_terracotta
setblock 330 163 572 minecraft:oak_log
fill 330 163 573 330 166 573 minecraft:green_terracotta
setblock 330 163 577 minecraft:oak_log
fill 330 163 578 330 166 578 minecraft:green_terracotta
setblock 330 163 582 minecraft:oak_log
fill 330 163 583 330 166 583 minecraft:green_terracotta
setblock 330 163 596 minecraft:green_terracotta
setblock 330 163 597 minecraft:oak_log
fill 330 163 598 333 163 598 minecraft:green_terracotta
setblock 331 163 561 minecraft:oak_log
fill 331 163 562 331 166 562 minecraft:green_terracotta
setblock 331 163 566 minecraft:oak_log
fill 331 163 567 331 166 567 minecraft:green_terracotta
setblock 331 163 571 minecraft:oak_log
fill 331 163 572 331 166 572 minecraft:green_terracotta
setblock 331 163 576 minecraft:oak_log
fill 331 163 577 331 166 577 minecraft:green_terracotta
setblock 331 163 580 minecraft:green_terracotta
setblock 331 163 581 minecraft:oak_log
fill 331 163 582 331 166 582 minecraft:green_terracotta
fill 331 163 597 331 164 597 minecraft:green_terracotta
setblock 332 163 560 minecraft:oak_log
fill 332 163 561 332 166 561 minecraft:green_terracotta
setblock 332 163 571 minecraft:green_terracotta
setblock 332 163 575 minecraft:oak_log
fill 332 163 576 332 165 576 minecraft:green_terracotta
setblock 332 163 580 minecraft:oak_log
setblock 333 163 559 minecraft:oak_log
fill 333 163 560 333 166 560 minecraft:green_terracotta
setblock 334 163 558 minecraft:oak_log
fill 334 163 559 334 166 559 minecraft:green_terracotta
setblock 334 163 598 minecraft:oak_log
fill 335 163 558 335 166 558 minecraft:green_terracotta
setblock 335 163 597 minecraft:oak_log
fill 335 163 598 335 166 598 minecraft:green_terracotta
fill 336 163 597 336 164 597 minecraft:green_terracotta
setblock 337 163 560 minecraft:oak_log
setblock 338 163 559 minecraft:oak_log
setblock 339 163 558 minecraft:oak_log
fill 339 163 559 339 166 559 minecraft:green_terracotta
setblock 339 163 598 minecraft:oak_log
fill 340 163 558 343 163 558 minecraft:green_terracotta
fill 340 163 598 343 163 598 minecraft:green_terracotta
setblock 344 163 558 minecraft:oak_log
setblock 344 163 598 minecraft:oak_log
fill 345 163 558 345 166 558 minecraft:green_terracotta
setblock 345 163 597 minecraft:oak_log
fill 345 163 598 345 166 598 minecraft:green_terracotta
fill 346 163 597 346 166 597 minecraft:green_terracotta
setblock 348 163 558 minecraft:green_terracotta
setblock 348 163 559 minecraft:oak_log
setblock 349 163 558 minecraft:oak_log
fill 349 163 559 349 166 559 minecraft:green_terracotta
setblock 349 163 598 minecraft:oak_log
fill 350 163 558 350 166 558 minecraft:green_terracotta
setblock 350 163 597 minecraft:oak_log
fill 350 163 598 350 166 598 minecraft:green_terracotta
setblock 351 163 596 minecraft:oak_log
fill 351 163 597 351 166 597 minecraft:green_terracotta
fill 352 163 596 352 166 596 minecraft:green_terracotta
setblock 353 163 559 minecraft:oak_log
setblock 354 163 558 minecraft:oak_log
fill 354 163 559 354 166 559 minecraft:green_terracotta
setblock 354 163 598 minecraft:oak_log
fill 355 163 558 355 166 558 minecraft:green_terracotta
setblock 355 163 597 minecraft:oak_log
fill 355 163 598 355 166 598 minecraft:green_terracotta
setblock 356 163 596 minecraft:oak_log
fill 356 163 597 356 166 597 minecraft:green_terracotta
setblock 357 163 596 minecraft:green_terracotta
setblock 359 163 558 minecraft:oak_log
setblock 359 163 598 minecraft:oak_log
setblock 360 163 597 minecraft:oak_log
fill 360 163 598 363 163 598 minecraft:green_terracotta
setblock 368 163 579 minecraft:oak_log
setblock 369 163 558 minecraft:oak_log
setblock 369 163 573 minecraft:oak_log
fill 369 163 574 369 166 574 minecraft:green_terracotta
setblock 369 163 578 minecraft:oak_log
fill 369 163 579 369 166 579 minecraft:green_terracotta
setblock 369 163 583 minecraft:oak_log
setblock 369 163 598 minecraft:oak_log
fill 370 163 558 370 166 558 minecraft:green_terracotta
setblock 370 163 561 minecraft:green_terracotta
fill 370 163 568 370 166 568 minecraft:green_terracotta
setblock 370 163 572 minecraft:oak_log
fill 370 163 573 370 166 573 minecraft:green_terracotta
setblock 370 163 577 minecraft:oak_log
fill 370 163 578 370 166 578 minecraft:green_terracotta
setblock 370 163 582 minecraft:oak_log
fill 370 163 583 370 166 583 minecraft:green_terracotta
setblock 370 163 587 minecraft:oak_log
setblock 370 163 593 minecraft:green_terracotta
setblock 370 163 597 minecraft:oak_log
fill 370 163 598 370 166 598 minecraft:green_terracotta
setblock 330 164 561 minecraft:oak_log
fill 330 164 562 330 167 562 minecraft:green_terracotta
setblock 330 164 566 minecraft:oak_log
fill 330 164 567 330 167 567 minecraft:green_terracotta
setblock 330 164 571 minecraft:oak_log
fill 330 164 572 330 167 572 minecraft:green_terracotta
setblock 330 164 576 minecraft:oak_log
fill 330 164 577 330 167 577 minecraft:green_terracotta
setblock 330 164 581 minecraft:oak_log
fill 330 164 582 330 167 582 minecraft:green_terracotta
setblock 330 164 596 minecraft:oak_log
fill 330 164 597 330 166 598 minecraft:green_terracotta
setblock 331 164 560 minecraft:oak_log
fill 331 164 561 331 167 561 minecraft:green_terracotta
setblock 331 164 565 minecraft:oak_log
fill 331 164 566 331 167 566 minecraft:green_terracotta
setblock 331 164 570 minecraft:oak_log
fill 331 164 571 331 167 571 minecraft:green_terracotta
setblock 331 164 575 minecraft:oak_log
fill 331 164 576 331 167 576 minecraft:green_terracotta
setblock 331 164 580 minecraft:oak_log
fill 331 164 581 331 167 581 minecraft:green_terracotta
fill 331 164 598 332 164 598 minecraft:green_terracotta
setblock 332 164 559 minecraft:oak_log
fill 332 164 560 332 167 560 minecraft:green_terracotta
fill 332 164 562 332 165 562 minecraft:green_terracotta
setblock 332 164 574 minecraft:oak_log
fill 332 164 575 332 165 575 minecraft:green_terracotta
setblock 332 164 579 minecraft:oak_log
setblock 333 164 558 minecraft:oak_log
fill 333 164 559 333 167 559 minecraft:green_terracotta
setblock 333 164 598 minecraft:oak_log
fill 334 164 558 334 167 558 minecraft:green_terracotta
setblock 334 164 597 minecraft:oak_log
fill 334 164 598 334 167 598 minecraft:green_terracotta
fill 335 164 597 335 165 597 minecraft:green_terracotta
setblock 336 164 560 minecraft:oak_log
setblock 337 164 559 minecraft:oak_log
setblock 337 164 560 minecraft:green_terracotta
setblock 338 164 558 minecraft:oak_log
fill 338 164 559 338 167 559 minecraft:green_terracotta
setblock 338 164 598 minecraft:oak_log
fill 339 164 558 342 164 558 minecraft:green_terracotta
fill 339 164 598 342 164 598 minecraft:green_terracotta
setblock 343 164 558 minecraft:oak_log
setblock 343 164 598 minecraft:oak_log
fill 344 164 558 344 167 558 minecraft:green_terracotta
fill 344 164 598 344 167 598 minecraft:green_terracotta
setblock 346 164 559 minecraft:green_terracotta
setblock 347 164 558 minecraft:green_terracotta
setblock 347 164 559 minecraft:oak_log
setblock 348 164 558 minecraft:oak_log
fill 348 164 559 348 167 559 minecraft:green_terracotta
setblock 348 164 598 minecraft:oak_log
fill 349 164 558 349 167 558 minecraft:green_terracotta
setblock 349 164 597 minecraft:oak_log
fill 349 164 598 349 167 598 minecraft:green_terracotta
setblock 350 164 596 minecraft:oak_log
fill 350 164 597 350 167 597 minecraft:green_terracotta
fill 351 164 596 351 167 596 minecraft:green_terracotta
setblock 352 164 559 minecraft:oak_log
setblock 353 164 558 minecraft:oak_log
fill 353 164 559 353 167 559 minecraft:green_terracotta
setblock 353 164 598 minecraft:oak_log
fill 354 164 558 354 167 558 minecraft:green_terracotta
setblock 354 164 597 minecraft:oak_log
fill 354 164 598 354 167 598 minecraft:green_terracotta
setblock 355 164 596 minecraft:oak_log
fill 355 164 597 355 167 597 minecraft:green_terracotta
setblock 356 164 596 minecraft:green_terracotta
setblock 358 164 558 minecraft:oak_log
setblock 358 164 598 minecraft:oak_log
setblock 359 164 597 minecraft:oak_log
fill 359 164 598 361 164 598 minecraft:green_terracotta
fill 361 164 558 361 165 558 minecraft:oak_leaves[persistent=true]
setblock 367 164 558 minecraft:oak_leaves[persistent=true]
setblock 368 164 558 minecraft:oak_log
setblock 368 164 577 minecraft:green_terracotta
setblock 368 164 578 minecraft:oak_log
fill 368 164 579 368 166 580 minecraft:green_terracotta
setblock 368 164 598 minecraft:oak_log
fill 369 164 558 369 167 558 minecraft:green_terracotta
setblock 369 164 572 minecraft:oak_log
fill 369 164 573 369 167 573 minecraft:green_terracotta
setblock 369 164 577 minecraft:oak_log
fill 369 164 578 369 167 578 minecraft:green_terracotta
setblock 369 164 582 minecraft:oak_log
fill 369 164 583 369 166 584 minecraft:green_terracotta
fill 369 164 598 369 167 598 minecraft:green_terracotta
setblock 370 164 561 minecraft:oak_log
fill 370 164 562 370 166 563 minecraft:green_terracotta
setblock 370 164 571 minecraft:oak_log
fill 370 164 572 370 167 572 minecraft:green_terracotta
setblock 370 164 576 minecraft:oak_log
fill 370 164 577 370 167 577 minecraft:green_terracotta
setblock 370 164 581 minecraft:oak_log
fill 370 164 582 370 167 582 minecraft:green_terracotta
setblock 370 164 586 minecraft:oak_log
fill 370 164 587 370 167 587 minecraft:green_terracotta
setblock 370 164 596 minecraft:oak_log
fill 370 164 597 370 167 597 minecraft:green_terracotta
setblock 330 165 560 minecraft:oak_log
fill 330 165 561 330 168 561 minecraft:green_terracotta
setblock 330 165 565 minecraft:oak_log
fill 330 165 566 330 168 566 minecraft:green_terracotta
setblock 330 165 570 minecraft:oak_log
fill 330 165 571 330 168 571 minecraft:green_terracotta
setblock 330 165 575 minecraft:oak_log
fill 330 165 576 330 168 576 minecraft:green_terracotta
setblock 330 165 580 minecraft:oak_log
fill 330 165 581 330 168 581 minecraft:green_terracotta
setblock 330 165 585 minecraft:oak_log
setblock 330 165 588 minecraft:oak_leaves[persistent=true]
fill 330 165 596 330 168 596 minecraft:green_terracotta
setblock 331 165 559 minecraft:oak_log
fill 331 165 560 331 168 560 minecraft:green_terracotta
setblock 331 165 564 minecraft:oak_log
fill 331 165 565 331 168 565 minecraft:green_terracotta
setblock 331 165 569 minecraft:oak_log
fill 331 165 570 331 168 570 minecraft:green_terracotta
setblock 331 165 574 minecraft:oak_log
fill 331 165 575 331 168 575 minecraft:green_terracotta
setblock 331 165 579 minecraft:oak_log
fill 331 165 580 331 168 580 minecraft:green_terracotta
setblock 331 165 598 minecraft:green_terracotta
setblock 332 165 558 minecraft:oak_log
fill 332 165 559 332 168 559 minecraft:green_terracotta
setblock 332 165 563 minecraft:oak_log
setblock 332 165 578 minecraft:oak_log
fill 332 165 579 332 166 579 minecraft:green_terracotta
setblock 332 165 598 minecraft:oak_log
fill 333 165 558 333 168 558 minecraft:green_terracotta
setblock 333 165 597 minecraft:oak_log
fill 333 165 598 333 168 598 minecraft:green_terracotta
setblock 334 165 597 minecraft:green_terracotta
setblock 335 165 560 minecraft:oak_log
setblock 336 165 559 minecraft:oak_log
fill 336 165 560 336 168 560 minecraft:green_terracotta
setblock 337 165 558 minecraft:oak_log
fill 337 165 559 337 168 559 minecraft:green_terracotta
fill 337 165 560 337 167 560 minecraft:iron_block
setblock 337 165 598 minecraft:oak_log
fill 338 165 558 341 165 558 minecraft:green_terracotta
fill 338 165 598 341 165 598 minecraft:green_terracotta
setblock 341 165 559 minecraft:oak_log
setblock 342 165 558 minecraft:oak_log
setblock 342 165 598 minecraft:oak_log
fill 343 165 558 343 168 558 minecraft:green_terracotta
fill 343 165 598 343 168 598 minecraft:green_terracotta
setblock 345 165 559 minecraft:green_terracotta
setblock 346 165 559 minecraft:oak_log
setblock 347 165 558 minecraft:oak_log
fill 347 165 559 347 168 559 minecraft:green_terracotta
setblock 347 165 598 minecraft:oak_log
fill 348 165 558 348 168 558 minecraft:green_terracotta
setblock 348 165 597 minecraft:oak_log
fill 348 165 598 348 168 598 minecraft:green_terracotta
setblock 349 165 596 minecraft:oak_log
fill 349 165 597 349 168 597 minecraft:green_terracotta
fill 350 165 596 350 168 596 minecraft:green_terracotta
setblock 351 165 559 minecraft:oak_log
setblock 352 165 558 minecraft:oak_log
fill 352 165 559 352 168 559 minecraft:green_terracotta
setblock 352 165 598 minecraft:oak_log
fill 353 165 558 353 168 558 minecraft:green_terracotta
setblock 353 165 597 minecraft:oak_log
fill 353 165 598 353 168 598 minecraft:green_terracotta
setblock 354 165 596 minecraft:oak_log
fill 354 165 597 354 168 597 minecraft:green_terracotta
setblock 355 165 596 minecraft:green_terracotta
setblock 357 165 558 minecraft:oak_log
setblock 357 165 598 minecraft:oak_log
setblock 358 165 558 minecraft:green_terracotta
fill 358 165 598 360 165 598 minecraft:green_terracotta
setblock 364 165 598 minecraft:oak_leaves[persistent=true]
fill 368 165 558 368 168 558 minecraft:green_terracotta
setblock 368 165 577 minecraft:oak_log
fill 368 165 578 368 168 578 minecraft:green_terracotta
setblock 368 165 581 minecraft:green_terracotta
fill 368 165 598 368 168 598 minecraft:green_terracotta
setblock 369 165 576 minecraft:oak_log
fill 369 165 577 369 168 577 minecraft:green_terracotta
setblock 369 165 581 minecraft:oak_log
fill 369 165 582 369 168 582 minecraft:green_terracotta
setblock 370 165 559 minecraft:green_terracotta
setblock 370 165 560 minecraft:oak_log
fill 370 165 561 370 168 561 minecraft:green_terracotta
setblock 370 165 564 minecraft:green_terracotta
setblock 370 165 565 minecraft:oak_log
fill 370 165 566 370 167 567 minecraft:green_terracotta
setblock 370 165 570 minecraft:oak_log
fill 370 165 571 370 168 571 minecraft:green_terracotta
setblock 370 165 575 minecraft:oak_log
fill 370 165 576 370 168 576 minecraft:green_terracotta
setblock 370 165 580 minecraft:oak_log
fill 370 165 581 370 168 581 minecraft:green_terracotta
setblock 370 165 585 minecraft:oak_log
fill 370 165 586 370 168 586 minecraft:green_terracotta
setblock 370 165 593 minecraft:oak_leaves[persistent=true]
fill 370 165 596 370 168 596 minecraft:green_terracotta
setblock 329 166 559 minecraft:green_terracotta
fill 329 166 560 329 169 560 minecraft:brown_terracotta
setblock 329 166 574 minecraft:brown_terracotta
fill 329 166 575 330 166 575 minecraft:green_terracotta
fill 329 166 576 329 169 577 minecraft:brown_terracotta
setblock 329 166 578 minecraft:green_terracotta
fill 329 166 579 329 167 581 minecraft:brown_terracotta
setblock 329 166 586 minecraft:green_terracotta
setblock 329 166 588 minecraft:green_terracotta
fill 329 166 589 329 170 589 minecraft:brown_terracotta
setblock 329 166 590 minecraft:green_terracotta
fill 329 166 591 329 169 591 minecraft:brown_terracotta
setblock 329 166 592 minecraft:green_terracotta
fill 329 166 593 329 169 593 minecraft:brown_terracotta
fill 329 166 595 329 169 595 minecraft:brown_terracotta
setblock 329 166 596 minecraft:green_terracotta
fill 329 166 597 329 169 597 minecraft:brown_terracotta
fill 329 166 598 329 166 599 minecraft:green_terracotta
fill 330 166 557 330 169 557 minecraft:brown_terracotta
setblock 330 166 559 minecraft:oak_log
fill 330 166 560 330 169 560 minecraft:green_terracotta
setblock 330 166 564 minecraft:oak_log
fill 330 166 565 330 169 565 minecraft:green_terracotta
setblock 330 166 569 minecraft:oak_log
fill 330 166 570 330 169 570 minecraft:green_terracotta
setblock 330 166 574 minecraft:oak_log
setblock 330 166 579 minecraft:oak_log
fill 330 166 580 330 169 580 minecraft:green_terracotta
setblock 330 166 584 minecraft:oak_log
fill 330 166 585 330 169 585 minecraft:green_terracotta
setblock 330 166 594 minecraft:oak_leaves[persistent=true]
setblock 331 166 557 minecraft:green_terracotta
setblock 331 166 558 minecraft:oak_log
fill 331 166 559 331 169 559 minecraft:green_terracotta
setblock 331 166 563 minecraft:oak_log
fill 331 166 564 331 169 564 minecraft:green_terracotta
setblock 331 166 568 minecraft:oak_log
fill 331 166 569 331 169 569 minecraft:green_terracotta
setblock 331 166 573 minecraft:oak_log
fill 331 166 574 331 169 574 minecraft:green_terracotta
setblock 331 166 578 minecraft:oak_log
fill 331 166 579 331 169 579 minecraft:green_terracotta
setblock 331 166 583 minecraft:oak_log
setblock 331 166 598 minecraft:oak_log
fill 332 166 557 332 169 557 minecraft:brown_terracotta
fill 332 166 558 332 169 558 minecraft:green_terracotta
setblock 332 166 562 minecraft:oak_log
fill 332 166 563 332 169 563 minecraft:green_terracotta
setblock 332 166 577 minecraft:oak_log
setblock 332 166 578 minecraft:green_terracotta
fill 332 166 598 332 169 598 minecraft:green_terracotta
fill 333 166 557 334 166 557 minecraft:green_terracotta
setblock 334 166 560 minecraft:oak_log
fill 335 166 557 336 169 557 minecraft:brown_terracotta
setblock 335 166 559 minecraft:oak_log
fill 335 166 560 335 169 560 minecraft:green_terracotta
setblock 336 166 558 minecraft:oak_log
fill 336 166 559 336 169 559 minecraft:green_terracotta
setblock 336 166 598 minecraft:oak_log
fill 337 166 558 340 166 558 minecraft:green_terracotta
fill 337 166 598 340 166 598 minecraft:green_terracotta
setblock 340 166 559 minecraft:oak_log
setblock 340 166 599 minecraft:green_terracotta
setblock 341 166 558 minecraft:oak_log
fill 341 166 559 341 169 559 minecraft:green_terracotta
setblock 341 166 598 minecraft:oak_log
fill 341 166 599 350 167 599 minecraft:brown_terracotta
fill 342 166 557 347 167 557 minecraft:brown_terracotta
fill 342 166 558 342 169 558 minecraft:green_terracotta
fill 342 166 598 342 169 598 minecraft:green_terracotta
setblock 344 166 559 minecraft:green_terracotta
setblock 345 166 559 minecraft:oak_log
setblock 346 166 558 minecraft:oak_log
fill 346 166 559 346 169 559 minecraft:green_terracotta
setblock 346 166 598 minecraft:oak_log
fill 347 166 558 347 169 558 minecraft:green_terracotta
setblock 347 166 597 minecraft:oak_log
fill 347 166 598 347 169 598 minecraft:green_terracotta
setblock 348 166 557 minecraft:green_terracotta
fill 348 166 597 348 169 597 minecraft:green_terracotta
fill 349 166 557 349 167 557 minecraft:brown_terracotta
setblock 350 166 557 minecraft:green_terracotta
setblock 350 166 559 minecraft:oak_log
fill 351 166 557 354 169 557 minecraft:brown_terracotta
setblock 351 166 558 minecraft:oak_log
fill 351 166 559 351 169 559 minecraft:green_terracotta
setblock 351 166 598 minecraft:oak_log
fill 352 166 558 352 169 558 minecraft:green_terracotta
setblock 352 166 597 minecraft:oak_log
fill 352 166 598 352 169 598 minecraft:green_terracotta
setblock 353 166 596 minecraft:oak_log
fill 353 166 597 353 169 597 minecraft:green_terracotta
setblock 355 166 557 minecraft:green_terracotta
setblock 355 166 559 minecraft:oak_log
fill 356 166 557 357 169 557 minecraft:brown_terracotta
setblock 356 166 558 minecraft:oak_log
setblock 356 166 598 minecraft:oak_log
fill 357 166 558 357 169 558 minecraft:green_terracotta
fill 357 166 598 359 166 598 minecraft:green_terracotta
fill 358 166 599 359 166 599 minecraft:green_terracotta
fill 359 166 557 360 169 557 minecraft:brown_terracotta
fill 360 166 599 363 169 599 minecraft:brown_terracotta
setblock 361 166 557 minecraft:green_terracotta
fill 362 166 557 362 169 557 minecraft:brown_terracotta
setblock 363 166 557 minecraft:green_terracotta
fill 367 166 558 367 169 558 minecraft:green_terracotta
setblock 367 166 599 minecraft:brown_terracotta
fill 368 166 557 369 169 557 minecraft:brown_terracotta
setblock 368 166 576 minecraft:oak_log
fill 368 166 577 368 169 577 minecraft:green_terracotta
setblock 368 166 581 minecraft:oak_log
fill 368 166 582 368 169 582 minecraft:green_terracotta
setblock 368 166 599 minecraft:green_terracotta
setblock 369 166 575 minecraft:oak_log
fill 369 166 576 369 169 576 minecraft:green_terracotta
setblock 369 166 580 minecraft:oak_log
fill 369 166 581 369 169 581 minecraft:green_terracotta
setblock 369 166 585 minecraft:oak_log
fill 369 166 599 371 169 599 minecraft:brown_terracotta
setblock 370 166 557 minecraft:green_terracotta
setblock 370 166 559 minecraft:oak_log
fill 370 166 560 370 169 560 minecraft:green_terracotta
setblock 370 166 564 minecraft:oak_log
fill 370 166 565 370 169 565 minecraft:green_terracotta
setblock 370 166 569 minecraft:oak_log
fill 370 166 570 370 169 570 minecraft:green_terracotta
setblock 370 166 574 minecraft:oak_log
fill 370 166 575 370 169 575 minecraft:green_terracotta
setblock 370 166 579 minecraft:oak_log
fill 370 166 580 370 169 580 minecraft:green_terracotta
setblock 370 166 584 minecraft:oak_log
fill 370 166 585 371 166 585 minecraft:green_terracotta
fill 370 166 588 371 166 588 minecraft:green_terracotta
fill 371 166 557 371 169 557 minecraft:brown_terracotta
setblock 371 166 558 minecraft:green_terracotta
fill 371 166 559 371 167 562 minecraft:brown_terracotta
setblock 371 166 568 minecraft:green_terracotta
fill 371 166 569 371 169 571 minecraft:brown_terracotta
setblock 371 166 577 minecraft:brown_terracotta
setblock 371 166 578 minecraft:green_terracotta
fill 371 166 579 371 167 584 minecraft:brown_terracotta
setblock 371 166 587 minecraft:green_terracotta
fill 371 166 589 371 167 597 minecraft:brown_terracotta
fill 329 167 559 329 169 559 minecraft:brown_terracotta
fill 329 167 574 330 167 574 minecraft:green_terracotta
fill 329 167 575 329 169 575 minecraft:brown_terracotta
fill 329 167 578 329 169 578 minecraft:brown_terracotta
fill 329 167 582 329 167 583 minecraft:green_terracotta
fill 329 167 584 329 169 584 minecraft:brown_terracotta
fill 329 167 586 329 170 586 minecraft:brown_terracotta
fill 329 167 588 329 169 588 minecraft:brown_terracotta
fill 329 167 590 329 169 590 minecraft:brown_terracotta
fill 329 167 592 329 169 592 minecraft:brown_terracotta
fill 329 167 596 329 170 596 minecraft:brown_terracotta
fill 329 167 598 329 169 599 minecraft:brown_terracotta
setblock 330 167 558 minecraft:oak_log
fill 330 167 559 330 170 559 minecraft:green_terracotta
setblock 330 167 563 minecraft:oak_log
fill 330 167 564 330 170 564 minecraft:green_terracotta
setblock 330 167 568 minecraft:oak_log
fill 330 167 569 330 170 569 minecraft:green_terracotta
setblock 330 167 573 minecraft:oak_log
fill 330 167 575 330 169 575 minecraft:green_terracotta
setblock 330 167 578 minecraft:oak_log
fill 330 167 579 330 170 579 minecraft:green_terracotta
setblock 330 167 583 minecraft:oak_log
fill 330 167 584 330 170 584 minecraft:green_terracotta
fill 330 167 586 330 168 586 minecraft:green_terracotta
setblock 330 167 597 minecraft:green_terracotta
setblock 330 167 598 minecraft:oak_log
fill 331 167 557 331 169 557 minecraft:brown_terracotta
fill 331 167 558 331 170 558 minecraft:green_terracotta
setblock 331 167 562 minecraft:oak_log
fill 331 167 563 331 170 563 minecraft:green_terracotta
setblock 331 167 567 minecraft:oak_log
fill 331 167 568 331 170 568 minecraft:green_terracotta
setblock 331 167 572 minecraft:oak_log
fill 331 167 573 331 170 573 minecraft:green_terracotta
setblock 331 167 577 minecraft:oak_log
fill 331 167 578 331 170 578 minecraft:green_terracotta
setblock 331 167 582 minecraft:oak_log
fill 331 167 583 331 170 583 minecraft:green_terracotta
fill 331 167 598 331 170 598 minecraft:green_terracotta
setblock 332 167 561 minecraft:oak_log
fill 332 167 562 332 170 562 minecraft:green_terracotta
fill 332 167 564 332 168 564 minecraft:green_terracotta
fill 333 167 557 334 169 557 minecraft:brown_terracotta
setblock 333 167 560 minecraft:oak_log
setblock 333 167 599 minecraft:green_terracotta
setblock 334 167 559 minecraft:oak_log
fill 334 167 560 334 170 560 minecraft:green_terracotta
setblock 335 167 558 minecraft:oak_log
fill 335 167 559 335 170 559 minecraft:green_terracotta
setblock 335 167 598 minecraft:oak_log
fill 336 167 558 339 167 558 minecraft:green_terracotta
fill 336 167 598 339 167 598 minecraft:green_terracotta
setblock 339 167 559 minecraft:oak_log
setblock 340 167 558 minecraft:oak_log
fill 340 167 559 340 170 559 minecraft:green_terracotta
setblock 340 167 598 minecraft:oak_log
fill 340 167 599 340 169 599 minecraft:brown_terracotta
fill 341 167 558 341 170 558 minecraft:green_terracotta
fill 341 167 598 341 170 598 minecraft:green_terracotta
fill 342 167 559 343 167 559 minecraft:green_terracotta
setblock 344 167 559 minecraft:oak_log
setblock 345 167 558 minecraft:oak_log
fill 345 167 559 345 170 559 minecraft:green_terracotta
setblock 345 167 598 minecraft:oak_log
fill 346 167 558 346 170 558 minecraft:green_terracotta
setblock 346 167 597 minecraft:oak_log
fill 346 167 598 346 170 598 minecraft:green_terracotta
fill 347 167 597 347 170 597 minecraft:green_terracotta
fill 348 167 557 348 169 557 minecraft:brown_terracotta
setblock 349 167 559 minecraft:oak_log
fill 350 167 557 350 169 557 minecraft:brown_terracotta
setblock 350 167 558 minecraft:oak_log
fill 350 167 559 350 169 560 minecraft:green_terracotta
setblock 350 167 598 minecraft:oak_log
fill 351 167 558 351 170 558 minecraft:green_terracotta
setblock 351 167 597 minecraft:oak_log
fill 351 167 598 351 170 598 minecraft:green_terracotta
setblock 352 167 596 minecraft:oak_log
fill 352 167 597 352 170 597 minecraft:green_terracotta
setblock 354 167 559 minecraft:oak_log
fill 355 167 557 355 169 557 minecraft:brown_terracotta
setblock 355 167 558 minecraft:oak_log
setblock 355 167 559 minecraft:green_terracotta
fill 355 167 590 356 168 590 minecraft:oak_leaves[persistent=true]
setblock 355 167 598 minecraft:oak_log
fill 356 167 558 356 170 558 minecraft:green_terracotta
setblock 356 167 597 minecraft:oak_log
fill 356 167 598 358 167 598 minecraft:green_terracotta
fill 358 167 599 359 169 599 minecraft:brown_terracotta
fill 361 167 557 361 170 557 minecraft:brown_terracotta
fill 363 167 557 363 169 557 minecraft:brown_terracotta
setblock 364 167 557 minecraft:green_terracotta
fill 366 167 558 366 170 558 minecraft:green_terracotta
setblock 367 167 599 minecraft:green_terracotta
fill 368 167 576 368 170 576 minecraft:green_terracotta
setblock 368 167 579 minecraft:green_terracotta
setblock 368 167 580 minecraft:oak_log
fill 368 167 581 368 170 581 minecraft:green_terracotta
fill 368 167 583 369 167 583 minecraft:green_terracotta
fill 368 167 599 368 169 599 minecraft:brown_terracotta
setblock 369 167 559 minecraft:oak_log
fill 369 167 560 369 167 563 minecraft:green_terracotta
fill 369 167 572 369 168 572 minecraft:green_terracotta
setblock 369 167 574 minecraft:oak_log
fill 369 167 575 369 170 575 minecraft:green_terracotta
setblock 369 167 579 minecraft:oak_log
fill 369 167 580 369 170 580 minecraft:green_terracotta
setblock 369 167 584 minecraft:oak_log
fill 369 167 585 369 169 586 minecraft:green_terracotta
fill 370 167 557 370 169 557 minecraft:brown_terracotta
setblock 370 167 558 minecraft:oak_log
schedule function dropper:buildpart/139_5 1t
