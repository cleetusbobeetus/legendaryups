setblock 42 248 530 minecraft:sea_lantern
fill 0 249 515 0 296 515 minecraft:black_concrete
setblock 0 249 547 minecraft:light_blue_stained_glass
fill 4 249 529 18 249 533 minecraft:black_wool
fill 5 249 525 18 249 528 minecraft:black_wool
fill 5 249 534 18 249 537 minecraft:black_wool
fill 6 249 524 36 250 524 minecraft:black_wool
fill 6 249 538 36 250 538 minecraft:black_wool
fill 7 249 522 35 250 522 minecraft:black_wool
fill 7 249 540 35 250 540 minecraft:black_wool
setblock 9 249 510 minecraft:white_concrete
fill 9 249 519 33 249 519 minecraft:black_wool
fill 9 249 543 33 249 543 minecraft:black_wool
fill 10 249 518 32 249 518 minecraft:black_wool
fill 10 249 544 32 249 544 minecraft:black_wool
fill 13 249 516 29 249 516 minecraft:black_wool
fill 13 249 546 29 249 546 minecraft:black_wool
fill 15 249 515 27 249 515 minecraft:black_wool
fill 15 249 547 27 249 547 minecraft:black_wool
fill 17 249 510 17 307 510 minecraft:black_concrete
fill 19 249 514 23 249 514 minecraft:black_wool
fill 19 249 525 37 249 526 minecraft:black_wool
fill 19 249 531 19 272 531 minecraft:black_wool
fill 19 249 536 37 249 537 minecraft:black_wool
fill 19 249 548 23 249 548 minecraft:black_wool
fill 21 249 535 37 250 535 minecraft:black_wool
fill 22 249 527 37 250 527 minecraft:black_wool
fill 24 249 528 37 250 528 minecraft:black_wool
fill 25 249 534 37 251 534 minecraft:black_wool
fill 26 249 529 38 249 529 minecraft:black_wool
setblock 32 249 510 minecraft:sea_lantern
fill 42 249 530 42 297 530 minecraft:black_concrete
fill 0 250 519 0 307 519 minecraft:black_concrete
setblock 0 250 520 minecraft:sea_lantern
setblock 0 250 535 minecraft:light_blue_stained_glass
fill 0 250 547 0 279 547 minecraft:black_concrete
fill 2 250 534 2 251 536 minecraft:cyan_stained_glass
fill 3 250 534 3 251 535 minecraft:cyan_stained_glass
fill 5 250 526 18 250 536 minecraft:black_wool
fill 6 250 525 36 251 525 minecraft:black_wool
fill 6 250 537 36 251 537 minecraft:black_wool
fill 7 250 523 35 251 523 minecraft:black_wool
fill 7 250 539 35 251 539 minecraft:black_wool
fill 8 250 521 34 250 521 minecraft:black_wool
fill 8 250 541 34 250 541 minecraft:black_wool
fill 9 250 510 9 307 510 minecraft:black_concrete
fill 9 250 520 33 251 520 minecraft:black_wool
fill 9 250 542 33 251 542 minecraft:black_wool
fill 10 250 519 32 251 519 minecraft:black_wool
fill 10 250 543 32 251 543 minecraft:black_wool
fill 11 250 518 31 250 518 minecraft:black_wool
fill 11 250 544 31 250 544 minecraft:black_wool
fill 12 250 517 30 250 517 minecraft:black_wool
fill 12 250 545 30 250 545 minecraft:black_wool
fill 14 250 516 28 250 516 minecraft:black_wool
fill 14 250 546 28 250 546 minecraft:black_wool
fill 16 250 515 26 250 515 minecraft:black_wool
fill 16 250 547 26 250 547 minecraft:black_wool
setblock 18 250 552 minecraft:sea_lantern
fill 19 250 526 37 250 526 minecraft:black_wool
fill 19 250 536 37 250 536 minecraft:black_wool
fill 19 250 552 19 307 552 minecraft:black_concrete
fill 20 250 527 20 272 528 minecraft:black_wool
fill 21 250 527 21 272 527 minecraft:black_wool
fill 26 250 529 37 251 533 minecraft:black_wool
fill 32 250 510 32 277 510 minecraft:black_concrete
setblock 42 250 539 minecraft:light_blue_stained_glass
setblock 0 251 511 minecraft:white_concrete
fill 0 251 520 0 252 520 minecraft:black_concrete
fill 0 251 535 0 307 535 minecraft:black_concrete
fill 3 251 528 4 254 530 minecraft:light_blue_stained_glass
fill 5 251 528 18 251 534 minecraft:black_wool
fill 6 251 526 18 252 527 minecraft:black_wool
fill 6 251 535 18 252 536 minecraft:black_wool
fill 7 251 524 35 252 524 minecraft:black_wool
fill 7 251 538 35 252 538 minecraft:black_wool
fill 8 251 522 34 252 522 minecraft:black_wool
fill 8 251 540 34 252 540 minecraft:black_wool
fill 9 251 521 33 252 521 minecraft:black_wool
fill 9 251 541 33 252 541 minecraft:black_wool
setblock 10 251 510 minecraft:white_concrete
fill 12 251 518 30 252 518 minecraft:black_wool
fill 12 251 544 30 252 544 minecraft:black_wool
fill 13 251 517 29 251 517 minecraft:black_wool
fill 13 251 545 29 251 545 minecraft:black_wool
fill 15 251 516 27 251 516 minecraft:black_wool
fill 15 251 546 27 251 546 minecraft:black_wool
fill 18 251 515 24 251 515 minecraft:black_wool
fill 18 251 547 24 251 547 minecraft:black_wool
fill 18 251 552 18 282 552 minecraft:black_concrete
fill 19 251 526 36 252 526 minecraft:black_wool
fill 19 251 536 36 252 536 minecraft:black_wool
fill 21 251 535 36 252 535 minecraft:black_wool
fill 22 251 527 36 252 527 minecraft:black_wool
fill 25 251 528 37 251 528 minecraft:black_wool
fill 42 251 539 42 255 539 minecraft:black_concrete
fill 0 252 511 0 267 511 minecraft:black_concrete
fill 0 252 518 0 254 518 minecraft:cyan_concrete
fill 0 252 534 0 254 534 minecraft:cyan_concrete
setblock 0 252 543 minecraft:sea_lantern
setblock 0 252 546 minecraft:light_blue_stained_glass
fill 0 252 550 0 254 550 minecraft:cyan_concrete
fill 4 252 510 4 254 510 minecraft:cyan_concrete
fill 5 252 528 5 254 530 minecraft:light_blue_stained_glass
fill 6 252 528 18 253 534 minecraft:black_wool
fill 7 252 525 35 253 525 minecraft:black_wool
fill 7 252 537 35 253 537 minecraft:black_wool
fill 8 252 523 34 253 523 minecraft:black_wool
fill 8 252 539 34 253 539 minecraft:black_wool
fill 10 252 510 10 263 510 minecraft:black_concrete
fill 10 252 520 32 252 520 minecraft:black_wool
fill 10 252 542 32 252 542 minecraft:black_wool
fill 11 252 519 31 252 519 minecraft:black_wool
fill 11 252 543 31 252 543 minecraft:black_wool
fill 14 252 517 28 252 517 minecraft:black_wool
fill 14 252 545 28 252 545 minecraft:black_wool
fill 14 252 552 14 254 552 minecraft:cyan_concrete
fill 16 252 516 26 252 516 minecraft:black_wool
fill 16 252 546 26 252 546 minecraft:black_wool
fill 20 252 510 20 254 510 minecraft:cyan_concrete
fill 25 252 528 36 253 528 minecraft:black_wool
fill 25 252 534 36 253 534 minecraft:black_wool
fill 26 252 529 36 253 533 minecraft:black_wool
fill 30 252 552 30 254 552 minecraft:cyan_concrete
fill 31 252 552 31 297 552 minecraft:black_concrete
fill 36 252 510 36 254 510 minecraft:cyan_concrete
fill 42 252 520 42 254 520 minecraft:cyan_concrete
setblock 42 252 521 minecraft:light_blue_stained_glass
fill 42 252 536 42 254 536 minecraft:cyan_concrete
fill 42 252 537 42 272 538 minecraft:black_concrete
setblock 0 253 520 minecraft:light_blue_stained_glass
fill 0 253 543 0 307 543 minecraft:black_concrete
fill 0 253 546 0 285 546 minecraft:black_concrete
setblock 3 253 513 minecraft:light[level=11]
setblock 3 253 521 minecraft:light[level=11]
setblock 3 253 537 minecraft:light[level=11]
fill 3 253 542 5 256 544 minecraft:light_blue_stained_glass
setblock 3 253 545 minecraft:light[level=11]
fill 7 253 526 18 254 527 minecraft:black_wool
fill 7 253 535 18 254 536 minecraft:black_wool
fill 8 253 524 34 254 524 minecraft:black_wool
fill 8 253 538 34 254 538 minecraft:black_wool
fill 9 253 522 33 254 522 minecraft:black_wool
fill 9 253 540 33 254 540 minecraft:black_wool
fill 10 253 521 32 254 521 minecraft:black_wool
fill 10 253 541 32 254 541 minecraft:black_wool
setblock 11 253 513 minecraft:light[level=11]
fill 11 253 520 31 254 520 minecraft:black_wool
fill 11 253 542 31 254 542 minecraft:black_wool
setblock 11 253 545 minecraft:light[level=11]
fill 12 253 519 30 254 519 minecraft:black_wool
fill 12 253 543 30 254 543 minecraft:black_wool
fill 13 253 518 29 253 518 minecraft:black_wool
fill 13 253 544 29 253 544 minecraft:black_wool
fill 15 253 517 27 253 517 minecraft:black_wool
fill 15 253 545 27 253 545 minecraft:black_wool
fill 18 253 516 24 253 516 minecraft:black_wool
fill 18 253 546 24 253 546 minecraft:black_wool
setblock 19 253 513 minecraft:light[level=11]
fill 19 253 526 35 254 526 minecraft:black_wool
fill 19 253 536 35 254 536 minecraft:black_wool
fill 21 253 534 21 272 535 minecraft:black_wool
fill 22 253 527 35 254 527 minecraft:black_wool
fill 22 253 535 35 254 535 minecraft:black_wool
fill 24 253 534 24 272 534 minecraft:black_wool
setblock 27 253 513 minecraft:light[level=11]
setblock 35 253 513 minecraft:light[level=11]
setblock 35 253 521 minecraft:light[level=11]
setblock 35 253 545 minecraft:light[level=11]
fill 42 253 521 42 307 521 minecraft:black_concrete
fill 0 254 520 0 268 520 minecraft:black_concrete
setblock 0 254 537 minecraft:light_blue_stained_glass
fill 6 254 531 18 254 531 minecraft:black_wool
fill 7 254 528 18 255 530 minecraft:black_wool
fill 7 254 532 18 255 534 minecraft:black_wool
fill 8 254 525 34 255 525 minecraft:black_wool
fill 8 254 537 34 255 537 minecraft:black_wool
fill 9 254 523 33 255 523 minecraft:black_wool
fill 9 254 539 33 255 539 minecraft:black_wool
fill 14 254 518 28 254 518 minecraft:black_wool
fill 14 254 544 28 254 544 minecraft:black_wool
fill 16 254 517 26 254 517 minecraft:black_wool
fill 16 254 545 26 254 545 minecraft:black_wool
setblock 21 254 516 minecraft:black_wool
setblock 21 254 546 minecraft:black_wool
fill 25 254 528 35 255 528 minecraft:black_wool
fill 25 254 534 35 255 534 minecraft:black_wool
fill 26 254 529 35 255 533 minecraft:black_wool
fill 36 254 530 38 255 530 minecraft:black_concrete
setblock 36 254 531 minecraft:black_wool
fill 36 254 532 38 255 534 minecraft:black_concrete
fill 37 254 531 38 255 531 minecraft:black_concrete
fill 39 254 532 40 254 532 minecraft:black_concrete
fill 0 255 518 0 260 518 minecraft:black_concrete
fill 0 255 534 0 260 534 minecraft:black_concrete
fill 0 255 537 0 307 537 minecraft:black_concrete
fill 0 255 550 0 260 550 minecraft:black_concrete
fill 4 255 510 4 260 510 minecraft:black_concrete
setblock 5 255 510 minecraft:white_concrete
fill 7 255 531 18 256 531 minecraft:black_wool
fill 8 255 526 18 256 527 minecraft:black_wool
fill 8 255 535 18 256 536 minecraft:black_wool
fill 9 255 524 33 256 524 minecraft:black_wool
fill 9 255 538 33 256 538 minecraft:black_wool
fill 10 255 522 32 255 522 minecraft:black_wool
fill 10 255 540 32 255 540 minecraft:black_wool
fill 11 255 521 31 255 521 minecraft:black_wool
fill 11 255 541 31 255 541 minecraft:black_wool
fill 12 255 520 30 255 520 minecraft:black_wool
fill 12 255 542 30 255 542 minecraft:black_wool
fill 13 255 519 29 255 519 minecraft:black_wool
fill 13 255 543 29 255 543 minecraft:black_wool
fill 14 255 552 15 260 552 minecraft:black_concrete
fill 15 255 518 27 255 518 minecraft:black_wool
fill 15 255 544 27 255 544 minecraft:black_wool
setblock 16 255 552 minecraft:light_blue_stained_glass
fill 18 255 517 24 255 517 minecraft:black_wool
fill 18 255 545 24 255 545 minecraft:black_wool
fill 19 255 526 34 256 526 minecraft:black_wool
fill 19 255 536 34 256 536 minecraft:black_wool
fill 20 255 510 20 260 510 minecraft:black_concrete
fill 22 255 527 34 257 527 minecraft:black_wool
fill 22 255 535 34 257 535 minecraft:black_wool
setblock 30 255 552 minecraft:black_concrete
fill 36 255 510 36 260 510 minecraft:black_concrete
setblock 36 255 531 minecraft:black_concrete
fill 42 255 520 42 260 520 minecraft:black_concrete
fill 42 255 536 42 260 536 minecraft:black_concrete
fill 5 256 510 5 307 510 minecraft:black_concrete
fill 7 256 530 18 256 530 minecraft:black_wool
fill 7 256 532 18 256 532 minecraft:black_wool
fill 8 256 528 18 257 529 minecraft:black_wool
fill 8 256 533 18 257 534 minecraft:black_wool
fill 9 256 525 33 257 525 minecraft:black_wool
fill 9 256 537 33 257 537 minecraft:black_wool
fill 10 256 523 32 257 523 minecraft:black_wool
fill 10 256 539 32 257 539 minecraft:black_wool
fill 11 256 522 31 257 522 minecraft:black_wool
fill 11 256 540 31 257 540 minecraft:black_wool
fill 12 256 521 30 257 521 minecraft:black_wool
fill 12 256 541 30 257 541 minecraft:black_wool
fill 13 256 520 29 257 520 minecraft:black_wool
fill 13 256 542 29 257 542 minecraft:black_wool
fill 14 256 519 28 256 519 minecraft:black_wool
fill 14 256 543 28 256 543 minecraft:black_wool
fill 16 256 518 26 256 518 minecraft:black_wool
fill 16 256 544 26 256 544 minecraft:black_wool
fill 16 256 552 16 307 552 minecraft:black_concrete
setblock 18 256 510 minecraft:light_blue_stained_glass
fill 19 256 510 19 261 510 minecraft:black_concrete
fill 20 256 517 22 256 517 minecraft:black_wool
fill 20 256 533 20 272 533 minecraft:black_wool
fill 20 256 545 22 256 545 minecraft:black_wool
fill 25 256 528 34 257 528 minecraft:black_wool
fill 25 256 534 34 257 534 minecraft:black_wool
fill 26 256 529 34 256 533 minecraft:black_wool
setblock 30 256 552 minecraft:sea_lantern
fill 35 256 530 35 256 532 minecraft:black_wool
fill 36 256 532 37 260 532 minecraft:black_wool
setblock 42 256 539 minecraft:sea_lantern
setblock 0 257 544 minecraft:white_concrete
setblock 6 257 510 minecraft:light_blue_stained_glass
fill 8 257 527 18 257 527 minecraft:black_wool
fill 8 257 530 18 258 532 minecraft:black_wool
fill 8 257 535 18 257 535 minecraft:black_wool
fill 9 257 526 33 258 526 minecraft:black_wool
fill 9 257 536 33 258 536 minecraft:black_wool
fill 10 257 524 32 258 524 minecraft:black_wool
fill 10 257 538 32 258 538 minecraft:black_wool
fill 15 257 519 27 257 519 minecraft:black_wool
fill 15 257 543 27 257 543 minecraft:black_wool
fill 17 257 518 25 257 518 minecraft:black_wool
fill 17 257 544 25 257 544 minecraft:black_wool
fill 18 257 510 18 307 510 minecraft:black_concrete
fill 26 257 529 34 258 530 minecraft:black_wool
fill 26 257 532 34 258 533 minecraft:black_wool
fill 27 257 531 34 258 531 minecraft:black_wool
fill 30 257 552 30 260 552 minecraft:black_concrete
fill 35 257 532 35 260 532 minecraft:black_wool
fill 42 257 539 42 307 539 minecraft:black_concrete
setblock 0 258 544 minecraft:black_concrete
fill 6 258 510 6 259 510 minecraft:black_concrete
fill 8 258 529 18 258 529 minecraft:black_wool
fill 8 258 533 18 258 533 minecraft:black_wool
fill 9 258 527 18 259 528 minecraft:black_wool
fill 9 258 534 18 259 535 minecraft:black_wool
fill 10 258 525 32 259 525 minecraft:black_wool
fill 10 258 537 32 259 537 minecraft:black_wool
fill 11 258 523 31 258 523 minecraft:black_wool
fill 11 258 539 31 258 539 minecraft:black_wool
fill 12 258 522 30 259 522 minecraft:black_wool
fill 12 258 540 30 259 540 minecraft:black_wool
fill 13 258 521 29 258 521 minecraft:black_wool
fill 13 258 541 29 258 541 minecraft:black_wool
fill 14 258 520 28 258 520 minecraft:black_wool
fill 14 258 542 28 258 542 minecraft:black_wool
fill 16 258 519 26 258 519 minecraft:black_wool
fill 16 258 543 26 258 543 minecraft:black_wool
fill 19 258 518 23 258 518 minecraft:black_wool
fill 19 258 544 23 258 544 minecraft:black_wool
fill 22 258 527 33 259 527 minecraft:black_wool
fill 22 258 534 22 272 535 minecraft:black_wool
setblock 22 258 552 minecraft:light_blue_stained_glass
setblock 23 258 510 minecraft:light_blue_stained_glass
fill 23 258 535 33 259 535 minecraft:black_wool
fill 25 258 528 33 259 528 minecraft:black_wool
fill 25 258 534 33 259 534 minecraft:black_wool
setblock 31 258 540 minecraft:cyan_stained_glass
setblock 0 259 544 minecraft:white_concrete
fill 9 259 529 18 260 533 minecraft:black_wool
fill 10 259 526 32 260 526 minecraft:black_wool
fill 10 259 536 32 260 536 minecraft:black_wool
fill 11 259 524 31 260 524 minecraft:black_wool
fill 11 259 538 31 260 538 minecraft:black_wool
setblock 11 259 552 minecraft:sea_lantern
fill 12 259 523 30 260 523 minecraft:black_wool
fill 12 259 539 30 260 539 minecraft:black_wool
fill 14 259 521 28 260 521 minecraft:black_wool
fill 14 259 541 28 260 541 minecraft:black_wool
fill 15 259 520 27 259 520 minecraft:black_wool
fill 15 259 542 27 259 542 minecraft:black_wool
fill 17 259 519 25 259 519 minecraft:black_wool
fill 17 259 543 25 259 543 minecraft:black_wool
fill 22 259 552 22 292 552 minecraft:black_concrete
fill 23 259 510 23 307 510 minecraft:black_concrete
fill 23 259 534 23 272 534 minecraft:black_wool
fill 26 259 529 33 260 529 minecraft:black_wool
fill 26 259 532 33 260 533 minecraft:black_wool
fill 27 259 530 33 260 531 minecraft:black_wool
fill 36 259 531 36 260 531 minecraft:black_wool
fill 36 259 533 36 260 533 minecraft:black_wool
setblock 42 259 532 minecraft:sea_lantern
fill 42 259 533 42 306 533 minecraft:black_concrete
setblock 42 259 540 minecraft:sea_lantern
setblock 42 259 549 minecraft:light_blue_stained_glass
fill 0 260 544 0 307 544 minecraft:black_concrete
setblock 6 260 510 minecraft:white_concrete
setblock 8 260 510 minecraft:light_blue_stained_glass
fill 10 260 527 18 261 528 minecraft:black_wool
fill 10 260 534 18 261 535 minecraft:black_wool
fill 11 260 525 31 261 525 minecraft:black_wool
fill 11 260 537 31 261 537 minecraft:black_wool
fill 11 260 552 11 305 552 minecraft:black_concrete
setblock 12 260 510 minecraft:light_blue_stained_glass
fill 13 260 522 29 260 522 minecraft:black_wool
fill 13 260 540 29 260 540 minecraft:black_wool
fill 16 260 520 26 260 520 minecraft:black_wool
fill 16 260 542 26 260 542 minecraft:black_wool
fill 19 260 519 23 260 519 minecraft:black_wool
fill 19 260 543 23 260 543 minecraft:black_wool
fill 22 260 527 32 261 527 minecraft:black_wool
fill 23 260 535 32 261 535 minecraft:black_wool
fill 25 260 528 32 260 528 minecraft:black_wool
fill 25 260 534 32 261 534 minecraft:black_wool
fill 42 260 532 42 306 532 minecraft:black_concrete
fill 42 260 540 42 261 540 minecraft:black_concrete
fill 42 260 549 42 290 549 minecraft:black_concrete
fill 0 261 518 0 263 518 minecraft:cyan_concrete
setblock 0 261 527 minecraft:light_blue_stained_glass
fill 0 261 534 0 263 534 minecraft:cyan_concrete
fill 0 261 550 0 263 550 minecraft:cyan_concrete
setblock 3 261 513 minecraft:light[level=11]
setblock 3 261 521 minecraft:light[level=11]
setblock 3 261 529 minecraft:light[level=11]
setblock 3 261 537 minecraft:light[level=11]
setblock 3 261 545 minecraft:light[level=11]
fill 4 261 510 4 263 510 minecraft:cyan_concrete
fill 6 261 510 6 307 510 minecraft:black_concrete
setblock 8 261 510 minecraft:black_concrete
fill 10 261 529 18 262 533 minecraft:black_wool
setblock 10 261 552 minecraft:sea_lantern
setblock 11 261 513 minecraft:light[level=11]
setblock 11 261 521 minecraft:light[level=11]
fill 11 261 526 31 262 526 minecraft:black_wool
fill 11 261 536 31 262 536 minecraft:black_wool
setblock 11 261 545 minecraft:light[level=11]
fill 12 261 510 12 301 510 minecraft:black_concrete
fill 12 261 524 30 261 524 minecraft:black_wool
fill 12 261 538 30 261 538 minecraft:black_wool
fill 13 261 523 29 262 523 minecraft:black_wool
fill 13 261 539 29 262 539 minecraft:black_wool
fill 14 261 522 28 261 522 minecraft:black_wool
fill 14 261 540 28 261 540 minecraft:black_wool
fill 14 261 552 14 263 552 minecraft:cyan_concrete
fill 15 261 521 27 261 521 minecraft:black_wool
fill 15 261 541 27 261 541 minecraft:black_wool
fill 15 261 552 15 299 552 minecraft:black_concrete
fill 17 261 520 25 261 520 minecraft:black_wool
fill 17 261 542 25 261 542 minecraft:black_wool
setblock 19 261 513 minecraft:light[level=11]
setblock 19 261 545 minecraft:light[level=11]
fill 20 261 510 20 263 510 minecraft:cyan_concrete
fill 26 261 528 32 261 529 minecraft:black_wool
fill 26 261 532 32 262 533 minecraft:black_wool
setblock 27 261 513 minecraft:light[level=11]
fill 27 261 530 32 262 531 minecraft:black_wool
setblock 27 261 545 minecraft:light[level=11]
fill 30 261 552 30 263 552 minecraft:cyan_concrete
setblock 35 261 513 minecraft:light[level=11]
setblock 35 261 521 minecraft:light[level=11]
setblock 35 261 529 minecraft:light[level=11]
setblock 35 261 537 minecraft:light[level=11]
setblock 35 261 545 minecraft:light[level=11]
fill 36 261 510 36 263 510 minecraft:cyan_concrete
fill 42 261 520 42 263 520 minecraft:cyan_concrete
setblock 42 261 529 minecraft:light_blue_stained_glass
fill 42 261 536 42 263 536 minecraft:cyan_concrete
fill 0 262 527 0 289 527 minecraft:black_concrete
setblock 0 262 538 minecraft:white_concrete
setblock 2 262 510 minecraft:sea_lantern
setblock 8 262 510 minecraft:sea_lantern
fill 10 262 552 10 307 552 minecraft:black_concrete
fill 11 262 527 18 263 528 minecraft:black_wool
fill 11 262 534 18 263 535 minecraft:black_wool
fill 12 262 525 30 263 525 minecraft:black_wool
fill 12 262 537 30 263 537 minecraft:black_wool
fill 13 262 524 29 263 524 minecraft:black_wool
fill 13 262 538 29 263 538 minecraft:black_wool
fill 15 262 522 27 263 522 minecraft:black_wool
fill 15 262 540 27 263 540 minecraft:black_wool
fill 16 262 521 26 262 521 minecraft:black_wool
fill 16 262 541 26 262 541 minecraft:black_wool
setblock 19 262 510 minecraft:light_blue_stained_glass
fill 19 262 520 23 262 520 minecraft:black_wool
fill 19 262 542 23 262 542 minecraft:black_wool
fill 22 262 527 31 263 527 minecraft:black_wool
fill 23 262 535 31 263 535 minecraft:black_wool
fill 25 262 533 25 272 534 minecraft:black_wool
fill 26 262 528 31 264 529 minecraft:black_wool
fill 26 262 534 31 264 534 minecraft:black_wool
setblock 32 262 529 minecraft:black_wool
fill 37 262 552 37 282 552 minecraft:black_concrete
setblock 38 262 552 minecraft:sea_lantern
fill 42 262 529 42 307 529 minecraft:black_concrete
setblock 42 262 540 minecraft:white_concrete
setblock 42 262 542 minecraft:sea_lantern
fill 0 263 538 0 298 538 minecraft:black_concrete
fill 2 263 510 2 279 510 minecraft:black_concrete
fill 8 263 510 8 307 510 minecraft:black_concrete
fill 11 263 529 18 264 533 minecraft:black_wool
fill 12 263 526 30 264 526 minecraft:black_wool
fill 12 263 536 30 264 536 minecraft:black_wool
fill 14 263 523 28 263 523 minecraft:black_wool
fill 14 263 539 28 263 539 minecraft:black_wool
fill 17 263 521 25 263 521 minecraft:black_wool
fill 17 263 541 25 263 541 minecraft:black_wool
fill 19 263 510 19 307 510 minecraft:black_concrete
fill 26 263 532 31 264 533 minecraft:black_wool
fill 27 263 530 31 265 531 minecraft:black_wool
fill 38 263 552 38 307 552 minecraft:black_concrete
fill 42 263 540 42 274 540 minecraft:black_concrete
fill 42 263 542 42 291 542 minecraft:black_concrete
fill 0 264 518 0 267 518 minecraft:black_concrete
fill 0 264 534 0 269 534 minecraft:black_concrete
fill 0 264 550 0 269 550 minecraft:black_concrete
fill 4 264 510 4 269 510 minecraft:black_concrete
setblock 10 264 510 minecraft:white_concrete
fill 11 264 528 18 264 528 minecraft:black_wool
fill 11 264 534 18 264 534 minecraft:black_wool
fill 12 264 527 18 265 527 minecraft:black_wool
fill 12 264 535 18 265 535 minecraft:black_wool
fill 13 264 525 29 265 525 minecraft:black_wool
fill 13 264 537 29 265 537 minecraft:black_wool
fill 14 264 524 28 265 524 minecraft:black_wool
fill 14 264 538 28 265 538 minecraft:black_wool
fill 14 264 552 14 269 552 minecraft:black_concrete
fill 15 264 523 27 265 523 minecraft:black_wool
fill 15 264 539 27 265 539 minecraft:black_wool
fill 16 264 522 26 264 522 minecraft:black_wool
fill 16 264 540 26 264 540 minecraft:black_wool
fill 18 264 521 24 264 521 minecraft:black_wool
fill 18 264 541 24 264 541 minecraft:black_wool
fill 20 264 510 20 269 510 minecraft:black_concrete
fill 22 264 527 22 265 527 minecraft:black_wool
fill 23 264 535 30 265 535 minecraft:black_wool
fill 24 264 527 30 265 527 minecraft:black_wool
setblock 24 264 552 minecraft:white_concrete
fill 30 264 552 30 269 552 minecraft:black_concrete
fill 36 264 510 36 269 510 minecraft:black_concrete
fill 42 264 520 42 269 520 minecraft:black_concrete
fill 42 264 536 42 269 536 minecraft:black_concrete
fill 0 265 524 0 274 524 minecraft:black_concrete
setblock 0 265 525 minecraft:sea_lantern
fill 10 265 510 10 292 510 minecraft:black_concrete
fill 11 265 530 18 265 532 minecraft:black_wool
fill 12 265 528 18 266 529 minecraft:black_wool
fill 12 265 533 18 266 534 minecraft:black_wool
fill 13 265 526 29 266 526 minecraft:black_wool
fill 13 265 536 29 266 536 minecraft:black_wool
fill 17 265 522 25 265 522 minecraft:black_wool
fill 17 265 540 25 265 540 minecraft:black_wool
fill 20 265 521 22 265 521 minecraft:black_wool
fill 20 265 541 22 265 541 minecraft:black_wool
fill 24 265 552 24 307 552 minecraft:black_concrete
fill 26 265 528 30 266 529 minecraft:black_wool
fill 26 265 532 30 266 534 minecraft:black_wool
setblock 31 265 532 minecraft:black_wool
fill 42 265 511 42 273 511 minecraft:black_concrete
setblock 42 265 512 minecraft:white_concrete
fill 42 265 513 42 307 513 minecraft:black_concrete
fill 0 266 525 0 283 525 minecraft:black_concrete
fill 12 266 530 18 267 532 minecraft:black_wool
fill 13 266 527 18 267 527 minecraft:black_wool
fill 13 266 535 18 267 535 minecraft:black_wool
fill 14 266 525 28 266 525 minecraft:black_wool
fill 14 266 537 28 266 537 minecraft:black_wool
fill 15 266 524 27 266 524 minecraft:black_wool
fill 15 266 538 27 266 538 minecraft:black_wool
fill 16 266 523 26 266 523 minecraft:black_wool
fill 16 266 539 26 266 539 minecraft:black_wool
fill 18 266 522 24 266 522 minecraft:black_wool
fill 18 266 540 24 266 540 minecraft:black_wool
fill 23 266 535 29 267 535 minecraft:black_wool
fill 24 266 527 29 267 527 minecraft:black_wool
fill 26 266 552 26 293 552 minecraft:black_concrete
fill 27 266 530 30 267 531 minecraft:black_wool
setblock 27 266 552 minecraft:sea_lantern
fill 31 266 544 35 267 548 minecraft:black_concrete
fill 33 266 549 33 266 550 minecraft:black_concrete
fill 42 266 512 42 286 512 minecraft:black_concrete
setblock 7 267 552 minecraft:white_concrete
fill 13 267 528 18 268 529 minecraft:black_wool
fill 13 267 533 18 268 534 minecraft:black_wool
fill 14 267 526 28 268 526 minecraft:black_wool
fill 14 267 536 28 268 536 minecraft:black_wool
fill 15 267 525 27 268 525 minecraft:black_wool
fill 15 267 537 27 268 537 minecraft:black_wool
fill 16 267 524 26 268 524 minecraft:black_wool
fill 16 267 538 26 268 538 minecraft:black_wool
fill 17 267 523 25 267 523 minecraft:black_wool
fill 17 267 539 25 267 539 minecraft:black_wool
fill 20 267 522 22 267 522 minecraft:black_wool
fill 20 267 540 22 267 540 minecraft:black_wool
fill 26 267 528 29 268 528 minecraft:black_wool
fill 26 267 532 29 268 534 minecraft:black_wool
fill 27 267 529 29 269 529 minecraft:black_wool
fill 27 267 552 27 307 552 minecraft:black_concrete
setblock 30 267 532 minecraft:black_wool
setblock 42 267 527 minecraft:light_blue_stained_glass
setblock 0 268 511 minecraft:white_concrete
setblock 0 268 518 minecraft:sea_lantern
setblock 0 268 545 minecraft:white_concrete
fill 0 268 552 1 307 552 minecraft:black_concrete
setblock 2 268 552 minecraft:white_concrete
fill 7 268 552 7 307 552 minecraft:black_concrete
fill 13 268 530 18 269 532 minecraft:black_wool
fill 14 268 527 18 269 527 minecraft:black_wool
fill 14 268 535 18 269 535 minecraft:black_wool
fill 18 268 523 24 268 523 minecraft:black_wool
fill 18 268 539 24 268 539 minecraft:black_wool
fill 23 268 535 28 269 535 minecraft:black_wool
fill 24 268 527 28 268 527 minecraft:black_wool
fill 27 268 530 29 269 531 minecraft:black_wool
fill 32 268 546 34 272 546 minecraft:black_wool
setblock 34 268 510 minecraft:sea_lantern
setblock 42 268 523 minecraft:white_concrete
fill 42 268 527 42 279 527 minecraft:black_concrete
fill 0 269 511 0 307 511 minecraft:black_concrete
setblock 0 269 518 minecraft:black_concrete
setblock 0 269 520 minecraft:white_concrete
fill 0 269 545 0 299 545 minecraft:black_concrete
fill 2 269 552 2 307 552 minecraft:black_concrete
setblock 3 269 513 minecraft:light[level=11]
setblock 3 269 521 minecraft:light[level=11]
setblock 3 269 529 minecraft:light[level=11]
setblock 3 269 537 minecraft:light[level=11]
setblock 3 269 545 minecraft:light[level=11]
setblock 11 269 513 minecraft:light[level=11]
setblock 11 269 521 minecraft:light[level=11]
setblock 11 269 529 minecraft:light[level=11]
setblock 11 269 537 minecraft:light[level=11]
setblock 11 269 545 minecraft:light[level=11]
fill 13 269 529 18 269 529 minecraft:black_wool
fill 13 269 533 18 269 533 minecraft:black_wool
fill 14 269 528 18 270 528 minecraft:black_wool
fill 14 269 534 18 270 534 minecraft:black_wool
fill 15 269 526 27 269 526 minecraft:black_wool
fill 15 269 536 27 269 536 minecraft:black_wool
fill 16 269 525 26 269 525 minecraft:black_wool
fill 16 269 537 26 269 537 minecraft:black_wool
fill 17 269 524 25 269 524 minecraft:black_wool
fill 17 269 538 25 269 538 minecraft:black_wool
setblock 19 269 513 minecraft:light[level=11]
setblock 19 269 521 minecraft:light[level=11]
fill 19 269 523 23 269 523 minecraft:black_wool
fill 19 269 539 23 269 539 minecraft:black_wool
setblock 19 269 545 minecraft:light[level=11]
fill 20 269 532 20 272 532 minecraft:black_wool
fill 25 269 527 28 269 527 minecraft:black_wool
fill 26 269 528 28 270 528 minecraft:black_wool
fill 26 269 532 28 270 534 minecraft:black_wool
setblock 27 269 513 minecraft:light[level=11]
setblock 27 269 521 minecraft:light[level=11]
setblock 27 269 537 minecraft:light[level=11]
setblock 27 269 545 minecraft:light[level=11]
fill 29 269 532 29 269 533 minecraft:black_wool
fill 34 269 510 34 300 510 minecraft:black_concrete
setblock 35 269 513 minecraft:light[level=11]
setblock 35 269 521 minecraft:light[level=11]
setblock 35 269 529 minecraft:light[level=11]
setblock 35 269 537 minecraft:light[level=11]
setblock 35 269 545 minecraft:light[level=11]
fill 42 269 523 42 307 523 minecraft:black_concrete
setblock 42 269 535 minecraft:light_blue_stained_glass
fill 0 270 518 0 272 518 minecraft:cyan_concrete
fill 0 270 520 0 307 520 minecraft:black_concrete
setblock 0 270 532 minecraft:white_concrete
fill 0 270 534 0 272 534 minecraft:cyan_concrete
fill 0 270 550 0 272 550 minecraft:cyan_concrete
fill 4 270 510 4 272 510 minecraft:cyan_concrete
fill 14 270 529 18 271 533 minecraft:black_wool
fill 14 270 552 14 272 552 minecraft:cyan_concrete
fill 15 270 527 18 271 527 minecraft:black_wool
fill 15 270 535 18 271 535 minecraft:black_wool
fill 16 270 526 26 271 526 minecraft:black_wool
fill 16 270 536 26 271 536 minecraft:black_wool
fill 17 270 525 25 271 525 minecraft:black_wool
fill 17 270 537 25 271 537 minecraft:black_wool
fill 18 270 524 24 270 524 minecraft:black_wool
fill 18 270 538 24 270 538 minecraft:black_wool
fill 20 270 510 20 272 510 minecraft:cyan_concrete
fill 21 270 533 21 272 533 minecraft:black_wool
fill 23 270 535 27 271 535 minecraft:black_wool
fill 25 270 527 27 271 527 minecraft:black_wool
fill 27 270 529 28 271 531 minecraft:black_wool
fill 30 270 552 30 272 552 minecraft:cyan_concrete
fill 36 270 510 36 272 510 minecraft:cyan_concrete
setblock 39 270 552 minecraft:sea_lantern
fill 42 270 520 42 272 520 minecraft:cyan_concrete
fill 42 270 535 42 307 535 minecraft:black_concrete
fill 42 270 536 42 272 536 minecraft:cyan_concrete
setblock 42 270 544 minecraft:sea_lantern
fill 0 271 532 0 306 532 minecraft:black_concrete
setblock 3 271 510 minecraft:white_concrete
fill 15 271 528 18 272 528 minecraft:black_wool
fill 15 271 534 18 272 534 minecraft:black_wool
fill 19 271 524 23 271 524 minecraft:black_wool
fill 19 271 538 23 271 538 minecraft:black_wool
fill 26 271 528 27 272 528 minecraft:black_wool
fill 26 271 532 27 272 534 minecraft:black_wool
fill 28 271 532 28 271 533 minecraft:black_wool
fill 33 271 545 33 272 545 minecraft:black_wool
fill 33 271 547 33 272 547 minecraft:black_wool
fill 39 271 552 39 282 552 minecraft:black_concrete
fill 42 271 544 42 293 544 minecraft:black_concrete
fill 3 272 510 3 307 510 minecraft:black_concrete
setblock 3 272 552 minecraft:sea_lantern
setblock 13 272 510 minecraft:light_blue_stained_glass
fill 15 272 529 18 272 533 minecraft:black_wool
fill 16 272 527 18 272 527 minecraft:black_wool
fill 16 272 535 18 272 535 minecraft:black_wool
fill 17 272 526 25 272 526 minecraft:black_wool
fill 17 272 536 25 272 536 minecraft:black_wool
fill 18 272 525 24 272 525 minecraft:black_wool
fill 18 272 537 24 272 537 minecraft:black_wool
fill 23 272 535 26 272 535 minecraft:black_wool
fill 25 272 527 26 272 527 minecraft:black_wool
fill 27 272 529 27 272 531 minecraft:black_wool
setblock 42 272 517 minecraft:light_blue_stained_glass
fill 0 273 518 0 287 518 minecraft:black_concrete
setblock 0 273 521 minecraft:sea_lantern
fill 0 273 534 0 287 534 minecraft:black_concrete
fill 0 273 550 0 283 550 minecraft:black_concrete
fill 3 273 552 3 307 552 minecraft:black_concrete
fill 4 273 510 4 287 510 minecraft:black_concrete
fill 13 273 510 13 290 510 minecraft:black_concrete
setblock 14 273 552 minecraft:light_blue_stained_glass
fill 20 273 510 20 287 510 minecraft:black_concrete
setblock 23 273 552 minecraft:sea_lantern
fill 30 273 552 30 287 552 minecraft:black_concrete
fill 36 273 510 36 287 510 minecraft:black_concrete
fill 42 273 517 42 303 517 minecraft:black_concrete
fill 42 273 520 42 287 520 minecraft:black_concrete
fill 42 273 536 42 287 537 minecraft:black_concrete
setblock 42 273 538 minecraft:light_blue_stained_glass
fill 0 274 521 0 276 521 minecraft:black_concrete
setblock 0 274 531 minecraft:white_concrete
setblock 1 274 510 minecraft:white_concrete
fill 14 274 552 14 287 552 minecraft:black_concrete
fill 23 274 552 23 307 552 minecraft:black_concrete
setblock 42 274 511 minecraft:sea_lantern
fill 42 274 538 42 292 538 minecraft:black_concrete
setblock 0 275 524 minecraft:light_blue_stained_glass
fill 0 275 531 0 277 531 minecraft:black_concrete
setblock 0 275 536 minecraft:white_concrete
fill 1 275 510 1 307 510 minecraft:black_concrete
setblock 25 275 510 minecraft:light_blue_stained_glass
fill 42 275 511 42 279 511 minecraft:black_concrete
setblock 42 275 540 minecraft:light_blue_stained_glass
fill 0 276 524 0 307 524 minecraft:black_concrete
fill 0 276 536 0 307 536 minecraft:black_concrete
fill 25 276 510 25 307 510 minecraft:black_concrete
setblock 29 276 552 minecraft:light_blue_stained_glass
setblock 42 276 518 minecraft:white_concrete
setblock 42 276 528 minecraft:white_concrete
fill 42 276 540 42 307 540 minecraft:black_concrete
setblock 0 277 521 minecraft:white_concrete
setblock 3 277 513 minecraft:light[level=11]
setblock 3 277 521 minecraft:light[level=11]
setblock 3 277 529 minecraft:light[level=11]
setblock 3 277 537 minecraft:light[level=11]
setblock 3 277 545 minecraft:light[level=11]
setblock 11 277 513 minecraft:light[level=11]
setblock 11 277 521 minecraft:light[level=11]
setblock 11 277 529 minecraft:light[level=11]
setblock 11 277 537 minecraft:light[level=11]
setblock 11 277 545 minecraft:light[level=11]
setblock 19 277 513 minecraft:light[level=11]
setblock 19 277 521 minecraft:light[level=11]
setblock 19 277 529 minecraft:light[level=11]
setblock 19 277 537 minecraft:light[level=11]
setblock 19 277 545 minecraft:light[level=11]
setblock 27 277 513 minecraft:light[level=11]
setblock 27 277 521 minecraft:light[level=11]
setblock 27 277 529 minecraft:light[level=11]
setblock 27 277 537 minecraft:light[level=11]
setblock 27 277 545 minecraft:light[level=11]
fill 29 277 552 29 296 552 minecraft:black_concrete
setblock 35 277 513 minecraft:light[level=11]
setblock 35 277 521 minecraft:light[level=11]
setblock 35 277 529 minecraft:light[level=11]
setblock 35 277 537 minecraft:light[level=11]
setblock 35 277 545 minecraft:light[level=11]
fill 42 277 518 42 307 518 minecraft:black_concrete
fill 42 277 528 42 307 528 minecraft:black_concrete
fill 0 278 521 41 278 521 minecraft:black_concrete
setblock 0 278 531 minecraft:white_concrete
setblock 0 278 542 minecraft:white_concrete
fill 1 278 520 41 278 520 minecraft:black_concrete
fill 1 278 522 20 278 542 minecraft:black_concrete
fill 2 278 518 40 278 519 minecraft:black_concrete
fill 2 278 543 40 278 544 minecraft:black_concrete
fill 3 278 517 39 278 517 minecraft:black_concrete
fill 3 278 545 39 278 545 minecraft:black_concrete
fill 4 278 516 38 278 516 minecraft:black_concrete
fill 4 278 546 38 278 546 minecraft:black_concrete
fill 5 278 515 37 278 515 minecraft:black_concrete
fill 5 278 547 37 278 547 minecraft:black_concrete
fill 6 278 514 36 278 514 minecraft:black_concrete
fill 6 278 548 36 278 548 minecraft:black_concrete
fill 7 278 513 35 278 513 minecraft:black_concrete
fill 7 278 549 35 278 549 minecraft:black_concrete
fill 8 278 512 34 278 512 minecraft:black_concrete
fill 8 278 550 34 278 550 minecraft:black_concrete
fill 10 278 511 32 278 511 minecraft:black_concrete
fill 10 278 551 32 278 551 minecraft:black_concrete
fill 21 278 522 21 278 529 minecraft:black_concrete
fill 21 278 531 21 278 542 minecraft:black_concrete
fill 22 278 522 22 278 528 minecraft:black_concrete
fill 22 278 532 22 278 542 minecraft:black_concrete
fill 23 278 522 41 278 527 minecraft:black_concrete
fill 23 278 533 41 278 542 minecraft:black_concrete
fill 24 278 528 41 278 528 minecraft:black_concrete
fill 24 278 532 41 278 532 minecraft:black_concrete
fill 25 278 529 41 278 529 minecraft:black_concrete
fill 25 278 531 41 278 531 minecraft:black_concrete
fill 26 278 530 41 278 530 minecraft:black_concrete
setblock 32 278 510 minecraft:light_blue_stained_glass
fill 0 279 521 1 279 521 minecraft:black_concrete
fill 0 279 531 1 283 531 minecraft:black_concrete
fill 0 279 542 0 307 542 minecraft:black_concrete
fill 1 279 522 1 280 530 minecraft:black_concrete
fill 1 279 532 1 279 541 minecraft:black_concrete
fill 2 279 519 2 279 520 minecraft:black_concrete
fill 2 279 521 20 279 541 minecraft:black_wool
fill 2 279 542 2 279 543 minecraft:black_concrete
setblock 3 279 518 minecraft:black_concrete
fill 3 279 519 39 279 520 minecraft:black_wool
fill 3 279 542 39 279 543 minecraft:black_wool
setblock 3 279 544 minecraft:black_concrete
fill 4 279 517 4 280 517 minecraft:black_concrete
fill 4 279 518 38 279 518 minecraft:black_wool
fill 4 279 544 38 279 544 minecraft:black_wool
fill 4 279 545 4 280 545 minecraft:black_concrete
fill 5 279 515 5 279 516 minecraft:black_concrete
fill 5 279 517 37 280 517 minecraft:black_wool
fill 5 279 545 37 280 545 minecraft:black_wool
fill 5 279 546 5 279 547 minecraft:black_concrete
fill 6 279 515 6 280 515 minecraft:black_concrete
fill 6 279 516 36 280 516 minecraft:black_wool
fill 6 279 546 36 280 546 minecraft:black_wool
fill 6 279 547 6 280 547 minecraft:black_concrete
fill 7 279 514 7 280 514 minecraft:black_concrete
fill 7 279 515 35 280 515 minecraft:black_wool
fill 7 279 547 35 280 547 minecraft:black_wool
fill 7 279 548 7 280 548 minecraft:black_concrete
setblock 8 279 513 minecraft:black_concrete
fill 8 279 514 34 279 514 minecraft:black_wool
fill 8 279 548 34 279 548 minecraft:black_wool
setblock 8 279 549 minecraft:black_concrete
fill 9 279 512 10 279 512 minecraft:black_concrete
fill 9 279 513 33 279 513 minecraft:black_wool
fill 9 279 549 33 279 549 minecraft:black_wool
fill 9 279 550 10 279 550 minecraft:black_concrete
fill 11 279 511 31 279 511 minecraft:black_concrete
fill 11 279 512 31 279 512 minecraft:black_wool
fill 11 279 550 31 279 550 minecraft:black_wool
fill 11 279 551 31 279 551 minecraft:black_concrete
fill 21 279 521 21 279 528 minecraft:black_wool
setblock 21 279 529 minecraft:gray_wool
fill 21 279 531 21 279 532 minecraft:gray_wool
fill 21 279 533 40 279 541 minecraft:black_wool
fill 22 279 521 40 279 527 minecraft:black_wool
setblock 22 279 528 minecraft:gray_wool
setblock 22 279 532 minecraft:gray_wool
setblock 24 279 528 minecraft:gray_wool
setblock 24 279 532 minecraft:gray_wool
fill 25 279 528 40 279 528 minecraft:black_wool
setblock 25 279 529 minecraft:gray_wool
setblock 25 279 531 minecraft:gray_wool
fill 25 279 532 40 279 532 minecraft:black_wool
fill 26 279 529 40 279 531 minecraft:black_wool
fill 32 279 510 32 305 510 minecraft:black_concrete
fill 32 279 512 33 279 512 minecraft:black_concrete
fill 32 279 550 33 279 550 minecraft:black_concrete
setblock 34 279 513 minecraft:black_concrete
setblock 34 279 549 minecraft:black_concrete
fill 35 279 514 35 280 514 minecraft:black_concrete
fill 35 279 548 35 280 548 minecraft:black_concrete
fill 36 279 515 37 279 515 minecraft:black_concrete
fill 36 279 547 37 279 547 minecraft:black_concrete
fill 37 279 516 37 280 516 minecraft:black_concrete
fill 37 279 546 37 280 546 minecraft:black_concrete
fill 38 279 517 38 280 517 minecraft:black_concrete
fill 38 279 545 38 280 545 minecraft:black_concrete
setblock 39 279 518 minecraft:black_concrete
setblock 39 279 544 minecraft:black_concrete
fill 40 279 519 40 279 520 minecraft:black_concrete
fill 40 279 542 40 279 543 minecraft:black_concrete
fill 41 279 521 41 279 541 minecraft:black_concrete
fill 0 280 521 0 293 521 minecraft:black_concrete
setblock 0 280 547 minecraft:white_concrete
fill 1 280 511 1 280 521 minecraft:black_wool
fill 1 280 532 1 280 540 minecraft:black_concrete
fill 1 280 541 1 280 551 minecraft:black_wool
setblock 2 280 510 minecraft:light_blue_stained_glass
fill 2 280 511 2 280 519 minecraft:black_wool
fill 2 280 520 2 280 521 minecraft:black_concrete
fill 2 280 522 18 280 540 minecraft:black_wool
fill 2 280 541 2 280 542 minecraft:black_concrete
fill 2 280 543 2 280 551 minecraft:black_wool
fill 3 280 511 3 280 518 minecraft:black_wool
setblock 3 280 519 minecraft:black_concrete
fill 3 280 520 39 280 521 minecraft:black_wool
fill 3 280 541 39 280 542 minecraft:black_wool
setblock 3 280 543 minecraft:black_concrete
fill 3 280 544 3 280 551 minecraft:black_wool
fill 4 280 511 4 280 516 minecraft:black_wool
fill 4 280 518 4 281 518 minecraft:black_concrete
fill 4 280 519 38 280 519 minecraft:black_wool
fill 4 280 543 38 280 543 minecraft:black_wool
fill 4 280 544 4 281 544 minecraft:black_concrete
fill 4 280 546 4 280 551 minecraft:black_wool
fill 5 280 511 5 280 515 minecraft:black_wool
setblock 5 280 516 minecraft:black_concrete
fill 5 280 518 37 281 518 minecraft:black_wool
fill 5 280 544 37 281 544 minecraft:black_wool
setblock 5 280 546 minecraft:black_concrete
fill 5 280 547 5 280 551 minecraft:black_wool
fill 6 280 511 6 280 514 minecraft:black_wool
fill 6 280 548 6 280 551 minecraft:black_wool
fill 7 280 511 8 280 513 minecraft:black_wool
fill 7 280 549 8 280 551 minecraft:black_wool
fill 8 280 514 8 281 514 minecraft:black_concrete
fill 8 280 548 8 281 548 minecraft:black_concrete
fill 9 280 511 9 280 512 minecraft:black_wool
setblock 9 280 513 minecraft:black_concrete
fill 9 280 514 33 280 514 minecraft:black_wool
fill 9 280 548 33 280 548 minecraft:black_wool
setblock 9 280 549 minecraft:black_concrete
fill 9 280 550 9 280 551 minecraft:black_wool
setblock 9 280 552 minecraft:white_concrete
fill 10 280 511 11 280 511 minecraft:black_wool
fill 10 280 512 11 280 512 minecraft:black_concrete
fill 10 280 513 32 280 513 minecraft:black_wool
fill 10 280 549 32 280 549 minecraft:black_wool
fill 10 280 550 11 280 550 minecraft:black_concrete
fill 10 280 551 11 280 551 minecraft:black_wool
fill 12 280 511 30 280 511 minecraft:black_concrete
fill 12 280 512 30 280 512 minecraft:black_wool
fill 12 280 550 30 280 550 minecraft:black_wool
fill 12 280 551 30 280 551 minecraft:black_concrete
fill 19 280 522 19 280 529 minecraft:black_wool
fill 19 280 530 19 280 531 minecraft:gray_wool
fill 19 280 532 19 280 540 minecraft:black_wool
fill 20 280 522 20 280 527 minecraft:black_wool
setblock 20 280 528 minecraft:gray_wool
fill 20 280 529 20 280 531 minecraft:sea_lantern
setblock 20 280 532 minecraft:gray_wool
fill 20 280 533 20 280 540 minecraft:black_wool
fill 21 280 522 40 280 526 minecraft:black_wool
setblock 21 280 527 minecraft:gray_wool
fill 21 280 528 21 280 529 minecraft:sea_lantern
fill 21 280 531 21 280 532 minecraft:sea_lantern
setblock 21 280 533 minecraft:gray_wool
fill 21 280 534 40 280 540 minecraft:black_wool
fill 22 280 527 22 280 528 minecraft:sea_lantern
fill 22 280 532 22 280 533 minecraft:sea_lantern
fill 23 280 527 24 280 527 minecraft:sea_lantern
fill 23 280 533 24 280 533 minecraft:sea_lantern
fill 24 280 528 25 280 528 minecraft:sea_lantern
fill 24 280 532 25 280 532 minecraft:sea_lantern
fill 25 280 527 40 280 527 minecraft:black_wool
fill 25 280 529 26 280 529 minecraft:sea_lantern
fill 25 280 531 26 280 531 minecraft:sea_lantern
setblock 25 280 533 minecraft:gray_wool
fill 26 280 528 40 280 528 minecraft:black_wool
setblock 26 280 530 minecraft:sea_lantern
setblock 26 280 532 minecraft:gray_wool
fill 26 280 533 40 280 533 minecraft:black_wool
fill 27 280 529 40 280 532 minecraft:black_wool
fill 31 280 511 41 280 511 minecraft:black_wool
fill 31 280 512 32 280 512 minecraft:black_concrete
fill 31 280 550 32 280 550 minecraft:black_concrete
fill 31 280 551 41 280 551 minecraft:black_wool
fill 33 280 512 41 280 512 minecraft:black_wool
setblock 33 280 513 minecraft:black_concrete
setblock 33 280 549 minecraft:black_concrete
fill 33 280 550 41 280 550 minecraft:black_wool
fill 34 280 513 41 280 513 minecraft:black_wool
fill 34 280 514 34 281 514 minecraft:black_concrete
fill 34 280 548 34 281 548 minecraft:black_concrete
fill 34 280 549 41 280 549 minecraft:black_wool
fill 36 280 514 41 280 514 minecraft:black_wool
setblock 36 280 515 minecraft:black_concrete
setblock 36 280 547 minecraft:black_concrete
fill 36 280 548 41 280 548 minecraft:black_wool
fill 37 280 515 41 280 515 minecraft:black_wool
fill 37 280 547 41 280 547 minecraft:black_wool
fill 38 280 516 41 280 516 minecraft:black_wool
fill 38 280 518 38 281 518 minecraft:black_concrete
fill 38 280 544 38 281 544 minecraft:black_concrete
fill 38 280 546 41 280 546 minecraft:black_wool
fill 39 280 517 41 280 518 minecraft:black_wool
setblock 39 280 519 minecraft:black_concrete
setblock 39 280 543 minecraft:black_concrete
fill 39 280 544 41 280 545 minecraft:black_wool
fill 40 280 519 41 280 519 minecraft:black_wool
fill 40 280 520 40 280 521 minecraft:black_concrete
fill 40 280 541 40 280 542 minecraft:black_concrete
fill 40 280 543 41 280 543 minecraft:black_wool
fill 41 280 520 41 280 521 minecraft:black_wool
fill 41 280 522 41 280 540 minecraft:black_concrete
fill 41 280 541 41 280 542 minecraft:black_wool
setblock 42 280 511 minecraft:white_concrete
setblock 42 280 527 minecraft:light_blue_stained_glass
fill 0 281 547 0 307 547 minecraft:black_concrete
fill 1 281 523 1 281 530 minecraft:black_concrete
fill 1 281 532 1 281 539 minecraft:black_concrete
fill 2 281 510 2 307 510 minecraft:black_concrete
fill 2 281 521 2 281 522 minecraft:black_concrete
fill 2 281 523 17 281 539 minecraft:black_wool
fill 2 281 540 2 281 541 minecraft:black_concrete
setblock 3 281 520 minecraft:black_concrete
fill 3 281 521 39 281 522 minecraft:black_wool
fill 3 281 540 39 281 541 minecraft:black_wool
setblock 3 281 542 minecraft:black_concrete
fill 4 281 519 4 282 519 minecraft:black_concrete
fill 4 281 520 38 281 520 minecraft:black_wool
fill 4 281 542 38 281 542 minecraft:black_wool
fill 4 281 543 4 282 543 minecraft:black_concrete
setblock 5 281 517 minecraft:black_concrete
fill 5 281 519 37 282 519 minecraft:black_wool
fill 5 281 543 37 282 543 minecraft:black_wool
setblock 5 281 545 minecraft:black_concrete
setblock 6 281 516 minecraft:black_concrete
fill 6 281 517 36 281 517 minecraft:black_wool
fill 6 281 545 36 281 545 minecraft:black_wool
setblock 6 281 546 minecraft:black_concrete
setblock 7 281 515 minecraft:black_concrete
fill 7 281 516 35 281 516 minecraft:black_wool
fill 7 281 546 35 281 546 minecraft:black_wool
setblock 7 281 547 minecraft:black_concrete
fill 8 281 515 34 281 515 minecraft:black_wool
fill 8 281 547 34 281 547 minecraft:black_wool
fill 9 281 514 9 282 514 minecraft:black_concrete
fill 9 281 548 9 282 548 minecraft:black_concrete
fill 9 281 552 9 284 552 minecraft:black_concrete
setblock 10 281 513 minecraft:black_concrete
fill 10 281 514 32 281 514 minecraft:black_wool
fill 10 281 548 32 281 548 minecraft:black_wool
setblock 10 281 549 minecraft:black_concrete
fill 11 281 512 12 281 512 minecraft:black_concrete
fill 11 281 513 31 281 513 minecraft:black_wool
fill 11 281 549 31 281 549 minecraft:black_wool
fill 11 281 550 12 281 550 minecraft:black_concrete
fill 13 281 511 29 281 511 minecraft:black_concrete
fill 13 281 512 29 281 512 minecraft:black_wool
fill 13 281 550 29 281 550 minecraft:black_wool
fill 13 281 551 29 281 551 minecraft:black_concrete
fill 18 281 523 18 281 528 minecraft:black_wool
fill 18 281 529 18 281 532 minecraft:gray_wool
fill 18 281 533 18 281 539 minecraft:black_wool
fill 19 281 523 20 281 526 minecraft:black_wool
fill 19 281 527 19 281 529 minecraft:gray_wool
fill 19 281 532 19 281 533 minecraft:gray_wool
fill 19 281 534 19 281 539 minecraft:black_wool
setblock 20 281 527 minecraft:gray_wool
fill 20 281 533 20 281 534 minecraft:gray_wool
fill 20 281 535 21 281 539 minecraft:black_wool
fill 21 281 523 40 281 525 minecraft:black_wool
fill 21 281 526 24 281 526 minecraft:gray_wool
fill 21 281 534 25 281 534 minecraft:gray_wool
fill 22 281 535 23 281 535 minecraft:gray_wool
fill 22 281 536 40 281 539 minecraft:black_wool
fill 24 281 535 40 281 535 minecraft:black_wool
fill 25 281 526 40 281 526 minecraft:black_wool
fill 25 281 527 26 281 527 minecraft:gray_wool
setblock 26 281 528 minecraft:gray_wool
setblock 26 281 533 minecraft:gray_wool
fill 26 281 534 40 281 534 minecraft:black_wool
fill 27 281 527 40 281 528 minecraft:black_wool
fill 27 281 529 27 281 532 minecraft:gray_wool
fill 27 281 533 40 281 533 minecraft:black_wool
fill 28 281 529 40 281 532 minecraft:black_wool
setblock 30 281 510 minecraft:light_blue_stained_glass
fill 30 281 512 31 281 512 minecraft:black_concrete
fill 30 281 550 31 281 550 minecraft:black_concrete
setblock 32 281 513 minecraft:black_concrete
setblock 32 281 549 minecraft:black_concrete
fill 33 281 514 33 282 514 minecraft:black_concrete
fill 33 281 548 33 282 548 minecraft:black_concrete
setblock 35 281 515 minecraft:black_concrete
setblock 35 281 547 minecraft:black_concrete
setblock 36 281 516 minecraft:black_concrete
setblock 36 281 546 minecraft:black_concrete
setblock 37 281 510 minecraft:white_concrete
setblock 37 281 517 minecraft:black_concrete
setblock 37 281 545 minecraft:black_concrete
fill 38 281 519 38 282 519 minecraft:black_concrete
fill 38 281 543 38 282 543 minecraft:black_concrete
setblock 39 281 520 minecraft:black_concrete
setblock 39 281 542 minecraft:black_concrete
fill 40 281 521 40 281 522 minecraft:black_concrete
fill 40 281 540 40 281 541 minecraft:black_concrete
fill 41 281 523 41 281 539 minecraft:black_concrete
fill 42 281 511 42 307 511 minecraft:black_concrete
fill 42 281 527 42 298 527 minecraft:black_concrete
fill 1 282 525 1 282 530 minecraft:black_concrete
fill 1 282 532 1 282 537 minecraft:black_concrete
fill 2 282 523 2 282 524 minecraft:black_concrete
fill 2 282 525 16 282 537 minecraft:black_wool
fill 2 282 538 2 282 539 minecraft:black_concrete
fill 3 282 521 3 282 522 minecraft:black_concrete
fill 3 282 523 39 282 524 minecraft:black_wool
fill 3 282 538 39 282 539 minecraft:black_wool
fill 3 282 540 3 282 541 minecraft:black_concrete
fill 4 282 520 4 283 520 minecraft:black_concrete
fill 4 282 521 38 282 522 minecraft:black_wool
fill 4 282 540 38 282 541 minecraft:black_wool
fill 4 282 542 4 283 542 minecraft:black_concrete
setblock 5 282 518 minecraft:black_concrete
fill 5 282 520 37 283 520 minecraft:black_wool
fill 5 282 542 37 283 542 minecraft:black_wool
setblock 5 282 544 minecraft:black_concrete
setblock 6 282 517 minecraft:black_concrete
fill 6 282 518 36 282 518 minecraft:black_wool
fill 6 282 544 36 282 544 minecraft:black_wool
setblock 6 282 545 minecraft:black_concrete
setblock 7 282 516 minecraft:black_concrete
fill 7 282 517 35 282 517 minecraft:black_wool
fill 7 282 545 35 282 545 minecraft:black_wool
setblock 7 282 546 minecraft:black_concrete
setblock 8 282 515 minecraft:black_concrete
fill 8 282 516 34 282 516 minecraft:black_wool
fill 8 282 546 34 282 546 minecraft:black_wool
setblock 8 282 547 minecraft:black_concrete
fill 9 282 515 33 282 515 minecraft:black_wool
fill 9 282 547 33 282 547 minecraft:black_wool
fill 10 282 514 10 283 514 minecraft:black_concrete
fill 10 282 548 10 283 548 minecraft:black_concrete
fill 11 282 513 12 282 513 minecraft:black_concrete
fill 11 282 514 31 282 514 minecraft:black_wool
fill 11 282 548 31 282 548 minecraft:black_wool
fill 11 282 549 12 282 549 minecraft:black_concrete
fill 13 282 512 14 282 512 minecraft:black_concrete
fill 13 282 513 29 282 513 minecraft:black_wool
fill 13 282 549 29 282 549 minecraft:black_wool
fill 13 282 550 14 282 550 minecraft:black_concrete
fill 15 282 511 27 282 511 minecraft:black_concrete
fill 15 282 512 27 282 512 minecraft:black_wool
fill 15 282 550 27 282 550 minecraft:black_wool
fill 15 282 551 27 282 551 minecraft:black_concrete
fill 17 282 525 17 282 527 minecraft:black_wool
fill 17 282 528 17 282 533 minecraft:gray_wool
fill 17 282 534 17 282 537 minecraft:black_wool
fill 18 282 525 18 282 526 minecraft:black_wool
fill 18 282 527 18 282 528 minecraft:gray_wool
fill 18 282 533 18 282 534 minecraft:gray_wool
fill 18 282 535 18 282 537 minecraft:black_wool
setblock 19 282 525 minecraft:black_wool
fill 19 282 526 20 282 526 minecraft:gray_wool
fill 19 282 534 19 282 535 minecraft:gray_wool
fill 19 282 536 20 282 537 minecraft:black_wool
fill 20 282 525 24 282 525 minecraft:gray_wool
fill 20 282 535 21 282 535 minecraft:gray_wool
fill 21 282 510 21 307 510 minecraft:black_concrete
fill 21 282 536 24 282 536 minecraft:gray_wool
fill 21 282 537 40 282 537 minecraft:black_wool
setblock 22 282 510 minecraft:sea_lantern
fill 24 282 535 26 282 535 minecraft:gray_wool
fill 25 282 525 40 282 525 minecraft:black_wool
fill 25 282 526 26 282 526 minecraft:gray_wool
fill 25 282 536 40 282 536 minecraft:black_wool
fill 26 282 534 27 282 534 minecraft:gray_wool
fill 27 282 526 40 282 526 minecraft:black_wool
fill 27 282 527 27 282 528 minecraft:gray_wool
setblock 27 282 533 minecraft:gray_wool
fill 27 282 535 40 282 535 minecraft:black_wool
fill 28 282 512 29 282 512 minecraft:black_concrete
fill 28 282 527 40 282 528 minecraft:black_wool
fill 28 282 529 28 282 532 minecraft:gray_wool
fill 28 282 533 40 282 534 minecraft:black_wool
fill 28 282 550 29 282 550 minecraft:black_concrete
fill 29 282 529 40 282 532 minecraft:black_wool
fill 30 282 510 30 307 510 minecraft:black_concrete
fill 30 282 513 31 282 513 minecraft:black_concrete
fill 30 282 549 31 282 549 minecraft:black_concrete
fill 32 282 514 32 283 514 minecraft:black_concrete
fill 32 282 548 32 283 548 minecraft:black_concrete
setblock 34 282 515 minecraft:black_concrete
setblock 34 282 547 minecraft:black_concrete
setblock 35 282 516 minecraft:black_concrete
setblock 35 282 546 minecraft:black_concrete
setblock 36 282 517 minecraft:black_concrete
setblock 36 282 545 minecraft:black_concrete
fill 37 282 510 37 307 510 minecraft:black_concrete
setblock 37 282 518 minecraft:black_concrete
setblock 37 282 544 minecraft:black_concrete
fill 38 282 520 38 283 520 minecraft:black_concrete
fill 38 282 542 38 283 542 minecraft:black_concrete
fill 39 282 521 39 282 522 minecraft:black_concrete
fill 39 282 540 39 282 541 minecraft:black_concrete
fill 40 282 523 40 282 524 minecraft:black_concrete
fill 40 282 538 40 282 539 minecraft:black_concrete
fill 41 282 525 41 282 537 minecraft:black_concrete
fill 1 283 528 1 283 530 minecraft:black_concrete
fill 1 283 532 1 283 534 minecraft:black_concrete
fill 2 283 524 2 283 527 minecraft:black_concrete
fill 2 283 528 14 283 534 minecraft:black_wool
fill 2 283 535 2 283 538 minecraft:black_concrete
fill 3 283 522 3 283 523 minecraft:black_concrete
fill 3 283 524 15 283 527 minecraft:black_wool
fill 3 283 535 16 283 538 minecraft:black_wool
fill 3 283 539 3 283 540 minecraft:black_concrete
setblock 4 283 521 minecraft:black_concrete
fill 4 283 522 38 283 523 minecraft:black_wool
fill 4 283 539 38 283 540 minecraft:black_wool
setblock 4 283 541 minecraft:black_concrete
setblock 5 283 519 minecraft:black_concrete
fill 5 283 521 37 283 521 minecraft:black_wool
fill 5 283 541 37 283 541 minecraft:black_wool
setblock 5 283 543 minecraft:black_concrete
setblock 6 283 518 minecraft:black_concrete
fill 6 283 519 36 283 519 minecraft:black_wool
fill 6 283 543 36 283 543 minecraft:black_wool
setblock 6 283 544 minecraft:black_concrete
setblock 7 283 517 minecraft:black_concrete
fill 7 283 518 35 283 518 minecraft:black_wool
fill 7 283 544 35 283 544 minecraft:black_wool
setblock 7 283 545 minecraft:black_concrete
setblock 8 283 516 minecraft:black_concrete
fill 8 283 517 34 283 517 minecraft:black_wool
fill 8 283 545 34 283 545 minecraft:black_wool
setblock 8 283 546 minecraft:black_concrete
setblock 9 283 515 minecraft:black_concrete
fill 9 283 516 33 283 516 minecraft:black_wool
fill 9 283 546 33 283 546 minecraft:black_wool
setblock 9 283 547 minecraft:black_concrete
fill 10 283 515 32 283 515 minecraft:black_wool
fill 10 283 547 32 283 547 minecraft:black_wool
setblock 11 283 514 minecraft:black_concrete
setblock 11 283 548 minecraft:black_concrete
fill 12 283 513 13 283 513 minecraft:black_concrete
fill 12 283 514 30 283 514 minecraft:black_wool
fill 12 283 548 30 283 548 minecraft:black_wool
fill 12 283 549 13 283 549 minecraft:black_concrete
fill 14 283 512 17 283 512 minecraft:black_concrete
fill 14 283 513 28 283 513 minecraft:black_wool
fill 14 283 549 28 283 549 minecraft:black_wool
fill 14 283 550 17 283 550 minecraft:black_concrete
fill 15 283 528 15 283 529 minecraft:black_wool
fill 15 283 530 16 283 531 minecraft:gray_wool
fill 15 283 532 15 283 534 minecraft:black_wool
fill 16 283 524 16 283 526 minecraft:black_wool
fill 16 283 527 16 283 529 minecraft:gray_wool
fill 16 283 532 16 283 534 minecraft:gray_wool
fill 17 283 524 17 283 525 minecraft:black_wool
fill 17 283 526 17 283 527 minecraft:gray_wool
fill 17 283 534 17 283 535 minecraft:gray_wool
fill 17 283 536 17 283 538 minecraft:black_wool
fill 18 283 511 24 283 511 minecraft:black_concrete
fill 18 283 512 24 283 512 minecraft:black_wool
fill 18 283 524 19 283 524 minecraft:black_wool
fill 18 283 525 18 283 526 minecraft:gray_wool
fill 18 283 535 18 283 536 minecraft:gray_wool
fill 18 283 537 19 283 538 minecraft:black_wool
fill 18 283 550 24 283 550 minecraft:black_wool
fill 18 283 551 24 283 551 minecraft:black_concrete
setblock 18 283 552 minecraft:white_concrete
setblock 19 283 525 minecraft:gray_wool
fill 19 283 536 20 283 536 minecraft:gray_wool
fill 20 283 524 24 283 524 minecraft:gray_wool
fill 20 283 537 24 283 537 minecraft:gray_wool
fill 20 283 538 39 283 538 minecraft:black_wool
fill 22 283 510 22 292 510 minecraft:black_concrete
fill 25 283 512 28 283 512 minecraft:black_concrete
fill 25 283 524 39 283 524 minecraft:black_wool
fill 25 283 525 26 283 525 minecraft:gray_wool
fill 25 283 536 26 283 536 minecraft:gray_wool
fill 25 283 537 39 283 537 minecraft:black_wool
fill 25 283 550 28 283 550 minecraft:black_concrete
fill 27 283 525 39 283 525 minecraft:black_wool
setblock 27 283 526 minecraft:gray_wool
setblock 27 283 535 minecraft:gray_wool
fill 27 283 536 39 283 536 minecraft:black_wool
fill 28 283 526 39 283 526 minecraft:black_wool
fill 28 283 527 28 283 528 minecraft:gray_wool
fill 28 283 533 28 283 534 minecraft:gray_wool
fill 28 283 535 39 283 535 minecraft:black_wool
fill 29 283 513 30 283 513 minecraft:black_concrete
fill 29 283 527 39 283 528 minecraft:black_wool
fill 29 283 529 29 283 532 minecraft:gray_wool
fill 29 283 533 40 283 534 minecraft:black_wool
fill 29 283 549 30 283 549 minecraft:black_concrete
fill 30 283 529 40 283 532 minecraft:black_wool
setblock 31 283 514 minecraft:black_concrete
setblock 31 283 548 minecraft:black_concrete
setblock 33 283 515 minecraft:black_concrete
setblock 33 283 547 minecraft:black_concrete
setblock 34 283 516 minecraft:black_concrete
setblock 34 283 546 minecraft:black_concrete
setblock 35 283 517 minecraft:black_concrete
setblock 35 283 545 minecraft:black_concrete
setblock 36 283 518 minecraft:black_concrete
setblock 36 283 544 minecraft:black_concrete
setblock 37 283 519 minecraft:black_concrete
setblock 37 283 543 minecraft:black_concrete
setblock 37 283 552 minecraft:white_concrete
setblock 38 283 521 minecraft:black_concrete
setblock 38 283 541 minecraft:black_concrete
fill 39 283 522 39 283 523 minecraft:black_concrete
fill 39 283 539 39 283 540 minecraft:black_concrete
setblock 39 283 552 minecraft:light_blue_stained_glass
fill 40 283 524 40 283 527 minecraft:black_concrete
setblock 40 283 528 minecraft:black_wool
fill 40 283 535 40 283 538 minecraft:black_concrete
fill 41 283 528 41 283 534 minecraft:black_concrete
setblock 0 284 525 minecraft:white_concrete
fill 0 284 531 0 307 531 minecraft:black_concrete
setblock 0 284 550 minecraft:sea_lantern
fill 2 284 526 2 293 526 minecraft:iron_block
fill 2 284 527 2 284 535 minecraft:black_concrete
fill 3 284 524 3 284 526 minecraft:black_concrete
fill 3 284 527 13 284 535 minecraft:black_wool
fill 3 284 536 3 284 538 minecraft:black_concrete
fill 4 284 522 4 284 523 minecraft:black_concrete
fill 4 284 524 15 284 526 minecraft:black_wool
fill 4 284 536 15 284 538 minecraft:black_wool
fill 4 284 539 4 284 540 minecraft:black_concrete
fill 5 284 520 5 284 521 minecraft:black_concrete
fill 5 284 522 18 284 523 minecraft:black_wool
fill 5 284 539 37 284 540 minecraft:black_wool
fill 5 284 541 5 284 542 minecraft:black_concrete
fill 5 284 548 5 297 548 minecraft:iron_block
setblock 6 284 519 minecraft:black_concrete
fill 6 284 520 36 284 521 minecraft:black_wool
fill 6 284 541 36 284 542 minecraft:black_wool
setblock 6 284 543 minecraft:black_concrete
setblock 7 284 518 minecraft:black_concrete
fill 7 284 519 35 284 519 minecraft:black_wool
fill 7 284 543 35 284 543 minecraft:black_wool
setblock 7 284 544 minecraft:black_concrete
setblock 8 284 517 minecraft:black_concrete
fill 8 284 518 34 284 518 minecraft:black_wool
fill 8 284 544 34 284 544 minecraft:black_wool
setblock 8 284 545 minecraft:black_concrete
setblock 9 284 516 minecraft:black_concrete
fill 9 284 517 33 284 517 minecraft:black_wool
fill 9 284 545 33 284 545 minecraft:black_wool
setblock 9 284 546 minecraft:black_concrete
fill 10 284 515 11 284 515 minecraft:black_concrete
fill 10 284 516 32 284 516 minecraft:black_wool
fill 10 284 546 32 284 546 minecraft:black_wool
fill 10 284 547 11 284 547 minecraft:black_concrete
fill 12 284 514 13 284 514 minecraft:black_concrete
fill 12 284 515 30 284 515 minecraft:black_wool
fill 12 284 547 30 284 547 minecraft:black_wool
fill 12 284 548 13 284 548 minecraft:black_concrete
fill 14 284 513 16 284 513 minecraft:black_concrete
fill 14 284 514 28 284 514 minecraft:black_wool
fill 14 284 527 14 284 528 minecraft:black_wool
fill 14 284 529 14 284 533 minecraft:gray_wool
fill 14 284 534 14 284 535 minecraft:black_wool
fill 14 284 548 28 284 548 minecraft:black_wool
fill 14 284 549 16 284 549 minecraft:black_concrete
fill 15 284 527 15 284 529 minecraft:gray_wool
fill 15 284 532 15 284 535 minecraft:gray_wool
setblock 16 284 524 minecraft:black_wool
fill 16 284 525 16 284 526 minecraft:gray_wool
fill 16 284 535 16 284 536 minecraft:gray_wool
fill 16 284 537 16 284 538 minecraft:black_wool
fill 17 284 512 25 284 512 minecraft:black_concrete
fill 17 284 513 25 284 513 minecraft:black_wool
fill 17 284 524 17 284 525 minecraft:gray_wool
fill 17 284 536 17 284 537 minecraft:gray_wool
fill 17 284 538 18 284 538 minecraft:black_wool
fill 17 284 549 25 284 549 minecraft:black_wool
fill 17 284 550 25 284 550 minecraft:black_concrete
fill 18 284 524 19 284 524 minecraft:gray_wool
fill 18 284 537 19 284 537 minecraft:gray_wool
fill 18 284 552 18 300 552 minecraft:black_concrete
fill 19 284 522 37 284 522 minecraft:black_wool
fill 19 284 523 24 284 523 minecraft:gray_wool
fill 19 284 538 25 284 538 minecraft:gray_wool
fill 25 284 523 37 284 523 minecraft:black_wool
fill 25 284 524 26 284 524 minecraft:gray_wool
fill 25 284 537 26 284 537 minecraft:gray_wool
fill 26 284 513 28 284 513 minecraft:black_concrete
fill 26 284 538 38 284 538 minecraft:black_wool
fill 26 284 549 28 284 549 minecraft:black_concrete
fill 27 284 524 38 284 524 minecraft:black_wool
setblock 27 284 525 minecraft:gray_wool
setblock 27 284 536 minecraft:gray_wool
fill 27 284 537 38 284 537 minecraft:black_wool
fill 28 284 525 38 284 525 minecraft:black_wool
setblock 28 284 526 minecraft:gray_wool
setblock 28 284 535 minecraft:gray_wool
fill 28 284 536 38 284 536 minecraft:black_wool
fill 29 284 514 30 284 514 minecraft:black_concrete
fill 29 284 526 38 284 526 minecraft:black_wool
fill 29 284 527 29 284 529 minecraft:gray_wool
fill 29 284 532 29 284 534 minecraft:gray_wool
fill 29 284 535 39 284 535 minecraft:black_wool
fill 29 284 548 30 284 548 minecraft:black_concrete
fill 30 284 527 39 284 529 minecraft:black_wool
fill 30 284 530 30 285 531 minecraft:gray_wool
fill 30 284 532 39 284 534 minecraft:black_wool
fill 31 284 515 32 284 515 minecraft:black_concrete
fill 31 284 530 39 284 531 minecraft:black_wool
fill 31 284 547 32 284 547 minecraft:black_concrete
setblock 33 284 516 minecraft:black_concrete
setblock 33 284 546 minecraft:black_concrete
setblock 34 284 517 minecraft:black_concrete
setblock 34 284 545 minecraft:black_concrete
setblock 35 284 518 minecraft:black_concrete
setblock 35 284 544 minecraft:black_concrete
setblock 36 284 519 minecraft:black_concrete
setblock 36 284 543 minecraft:black_concrete
fill 37 284 520 37 284 521 minecraft:black_concrete
fill 37 284 541 37 284 542 minecraft:black_concrete
fill 37 284 552 37 307 552 minecraft:black_concrete
fill 38 284 522 38 284 523 minecraft:black_concrete
fill 38 284 539 38 284 540 minecraft:black_concrete
fill 39 284 524 39 284 526 minecraft:black_concrete
fill 39 284 536 39 284 538 minecraft:black_concrete
fill 39 284 552 39 290 552 minecraft:black_concrete
fill 40 284 527 40 284 535 minecraft:black_concrete
fill 42 284 525 42 304 525 minecraft:black_concrete
setblock 42 284 526 minecraft:light_blue_stained_glass
fill 0 285 525 0 306 525 minecraft:black_concrete
fill 0 285 550 0 287 550 minecraft:black_concrete
setblock 3 285 513 minecraft:light[level=11]
setblock 3 285 521 minecraft:light[level=11]
fill 3 285 526 3 285 536 minecraft:black_concrete
setblock 3 285 537 minecraft:light[level=11]
setblock 3 285 545 minecraft:light[level=11]
fill 4 285 523 4 285 525 minecraft:black_concrete
fill 4 285 526 12 285 536 minecraft:black_wool
fill 4 285 537 4 285 539 minecraft:black_concrete
setblock 5 285 522 minecraft:black_concrete
fill 5 285 523 14 285 525 minecraft:black_wool
fill 5 285 537 14 285 539 minecraft:black_wool
setblock 5 285 540 minecraft:black_concrete
fill 6 285 520 6 285 521 minecraft:black_concrete
fill 6 285 522 18 285 522 minecraft:black_wool
fill 6 285 540 36 285 540 minecraft:black_wool
fill 6 285 541 6 285 542 minecraft:black_concrete
setblock 7 285 519 minecraft:black_concrete
fill 7 285 520 35 285 521 minecraft:black_wool
fill 7 285 541 35 285 542 minecraft:black_wool
setblock 7 285 543 minecraft:black_concrete
setblock 8 285 518 minecraft:black_concrete
fill 8 285 519 34 285 519 minecraft:black_wool
fill 8 285 543 34 285 543 minecraft:black_wool
setblock 8 285 544 minecraft:black_concrete
setblock 9 285 517 minecraft:black_concrete
fill 9 285 518 33 285 518 minecraft:black_wool
fill 9 285 544 33 285 544 minecraft:black_wool
setblock 9 285 545 minecraft:black_concrete
setblock 9 285 552 minecraft:light_blue_stained_glass
fill 10 285 516 11 285 516 minecraft:black_concrete
fill 10 285 517 32 285 517 minecraft:black_wool
fill 10 285 545 32 285 545 minecraft:black_wool
fill 10 285 546 11 285 546 minecraft:black_concrete
setblock 11 285 513 minecraft:light[level=11]
setblock 12 285 515 minecraft:black_concrete
fill 12 285 516 30 285 516 minecraft:black_wool
fill 12 285 546 30 285 546 minecraft:black_wool
setblock 12 285 547 minecraft:black_concrete
fill 13 285 514 15 285 514 minecraft:black_concrete
fill 13 285 515 29 285 515 minecraft:black_wool
fill 13 285 526 13 285 527 minecraft:black_wool
fill 13 285 528 13 285 534 minecraft:gray_wool
fill 13 285 535 13 285 536 minecraft:black_wool
fill 13 285 547 29 285 547 minecraft:black_wool
fill 13 285 548 15 285 548 minecraft:black_concrete
fill 14 285 526 14 285 528 minecraft:gray_wool
fill 14 285 534 14 285 536 minecraft:gray_wool
fill 15 285 523 15 285 524 minecraft:black_wool
fill 15 285 525 15 285 526 minecraft:gray_wool
fill 15 285 536 15 285 537 minecraft:gray_wool
fill 15 285 538 15 285 539 minecraft:black_wool
fill 16 285 513 26 285 513 minecraft:black_concrete
fill 16 285 514 26 285 514 minecraft:black_wool
setblock 16 285 523 minecraft:black_wool
setblock 16 285 524 minecraft:gray_wool
fill 16 285 537 16 285 538 minecraft:gray_wool
fill 16 285 539 17 285 539 minecraft:black_wool
fill 16 285 548 26 285 548 minecraft:black_wool
fill 16 285 549 26 285 549 minecraft:black_concrete
fill 17 285 523 18 285 523 minecraft:gray_wool
fill 17 285 538 18 285 538 minecraft:gray_wool
fill 18 285 539 25 285 539 minecraft:gray_wool
fill 19 285 522 24 285 522 minecraft:gray_wool
setblock 19 285 529 minecraft:light[level=11]
setblock 19 285 537 minecraft:light[level=11]
fill 25 285 522 36 285 522 minecraft:black_wool
fill 25 285 523 26 285 523 minecraft:gray_wool
fill 26 285 538 27 285 538 minecraft:gray_wool
fill 26 285 539 37 285 539 minecraft:black_wool
setblock 27 285 513 minecraft:light[level=11]
fill 27 285 514 29 285 514 minecraft:black_concrete
fill 27 285 523 37 285 523 minecraft:black_wool
setblock 27 285 524 minecraft:gray_wool
setblock 27 285 529 minecraft:light[level=11]
fill 27 285 537 28 285 537 minecraft:gray_wool
fill 27 285 548 29 285 548 minecraft:black_concrete
fill 28 285 524 37 285 524 minecraft:black_wool
setblock 28 285 525 minecraft:gray_wool
fill 28 285 536 29 285 536 minecraft:gray_wool
fill 28 285 538 37 285 538 minecraft:black_wool
fill 29 285 525 37 285 525 minecraft:black_wool
setblock 29 285 526 minecraft:gray_wool
setblock 29 285 535 minecraft:gray_wool
fill 29 285 537 37 285 537 minecraft:black_wool
setblock 30 285 515 minecraft:black_concrete
fill 30 285 526 38 285 526 minecraft:black_wool
fill 30 285 527 30 285 529 minecraft:gray_wool
fill 30 285 532 30 285 534 minecraft:gray_wool
fill 30 285 535 38 285 536 minecraft:black_wool
setblock 30 285 547 minecraft:black_concrete
fill 31 285 516 32 285 516 minecraft:black_concrete
fill 31 285 527 38 285 534 minecraft:black_wool
fill 31 285 546 32 285 546 minecraft:black_concrete
setblock 33 285 517 minecraft:black_concrete
setblock 33 285 545 minecraft:black_concrete
setblock 34 285 518 minecraft:black_concrete
setblock 34 285 544 minecraft:black_concrete
setblock 35 285 513 minecraft:light[level=11]
setblock 35 285 519 minecraft:black_concrete
setblock 35 285 543 minecraft:black_concrete
setblock 35 285 545 minecraft:light[level=11]
fill 36 285 520 36 285 521 minecraft:black_concrete
fill 36 285 541 36 285 542 minecraft:black_concrete
setblock 37 285 522 minecraft:black_concrete
setblock 37 285 540 minecraft:black_concrete
fill 38 285 523 38 285 525 minecraft:black_concrete
fill 38 285 537 38 285 539 minecraft:black_concrete
fill 39 285 526 39 285 536 minecraft:black_concrete
setblock 42 285 515 minecraft:light_blue_stained_glass
fill 42 285 526 42 287 526 minecraft:black_concrete
setblock 0 286 546 minecraft:light_blue_stained_glass
fill 4 286 526 4 286 536 minecraft:black_concrete
fill 5 286 523 5 286 525 minecraft:black_concrete
fill 5 286 526 10 286 536 minecraft:black_wool
fill 5 286 537 5 286 539 minecraft:black_concrete
fill 6 286 522 6 286 523 minecraft:black_concrete
fill 6 286 524 12 286 525 minecraft:black_wool
fill 6 286 537 13 286 538 minecraft:black_wool
fill 6 286 539 6 286 540 minecraft:black_concrete
fill 7 286 520 7 286 521 minecraft:black_concrete
fill 7 286 522 14 286 523 minecraft:black_wool
fill 7 286 539 14 286 540 minecraft:black_wool
fill 7 286 541 7 286 542 minecraft:black_concrete
fill 8 286 519 8 286 520 minecraft:black_concrete
fill 8 286 521 18 286 521 minecraft:black_wool
fill 8 286 541 19 286 541 minecraft:black_wool
fill 8 286 542 8 286 543 minecraft:black_concrete
fill 9 286 518 9 286 519 minecraft:black_concrete
fill 9 286 520 33 286 520 minecraft:black_wool
fill 9 286 542 33 286 542 minecraft:black_wool
fill 9 286 543 9 286 544 minecraft:black_concrete
fill 9 286 552 9 293 552 minecraft:black_concrete
fill 10 286 517 10 286 518 minecraft:black_concrete
fill 10 286 519 32 286 519 minecraft:black_wool
fill 10 286 543 32 286 543 minecraft:black_wool
fill 10 286 544 10 286 545 minecraft:black_concrete
setblock 11 286 517 minecraft:black_concrete
fill 11 286 518 31 286 518 minecraft:black_wool
fill 11 286 526 11 286 530 minecraft:black_wool
fill 11 286 531 12 286 531 minecraft:gray_wool
fill 11 286 532 11 286 536 minecraft:black_wool
fill 11 286 544 31 286 544 minecraft:black_wool
setblock 11 286 545 minecraft:black_concrete
fill 12 286 516 13 286 516 minecraft:black_concrete
fill 12 286 517 30 286 517 minecraft:black_wool
setblock 12 286 526 minecraft:black_wool
fill 12 286 527 12 286 530 minecraft:gray_wool
fill 12 286 532 12 286 535 minecraft:gray_wool
setblock 12 286 536 minecraft:black_wool
fill 12 286 545 30 286 545 minecraft:black_wool
fill 12 286 546 13 286 546 minecraft:black_concrete
fill 13 286 515 15 286 515 minecraft:black_concrete
setblock 13 286 524 minecraft:black_wool
fill 13 286 525 13 286 527 minecraft:gray_wool
fill 13 286 535 13 286 536 minecraft:gray_wool
fill 13 286 547 15 286 547 minecraft:black_concrete
fill 14 286 516 28 286 516 minecraft:black_wool
fill 14 286 524 14 286 525 minecraft:gray_wool
fill 14 286 537 14 286 538 minecraft:gray_wool
fill 14 286 546 28 286 546 minecraft:black_wool
setblock 15 286 522 minecraft:black_wool
fill 15 286 523 15 286 524 minecraft:gray_wool
fill 15 286 538 15 286 539 minecraft:gray_wool
fill 15 286 540 16 286 540 minecraft:black_wool
fill 16 286 514 26 286 514 minecraft:black_concrete
fill 16 286 515 26 286 515 minecraft:black_wool
fill 16 286 522 16 286 523 minecraft:gray_wool
fill 16 286 539 17 286 539 minecraft:gray_wool
fill 16 286 547 26 286 547 minecraft:black_wool
fill 16 286 548 26 286 548 minecraft:black_concrete
fill 17 286 522 18 286 522 minecraft:gray_wool
fill 17 286 540 26 286 540 minecraft:gray_wool
fill 19 286 521 24 286 521 minecraft:gray_wool
fill 20 286 541 23 286 541 minecraft:gray_wool
fill 24 286 541 34 286 541 minecraft:black_wool
fill 25 286 521 34 286 521 minecraft:black_wool
fill 25 286 522 26 286 522 minecraft:gray_wool
fill 26 286 539 27 286 539 minecraft:gray_wool
fill 27 286 515 29 286 515 minecraft:black_concrete
fill 27 286 522 35 286 522 minecraft:black_wool
fill 27 286 523 28 286 523 minecraft:gray_wool
fill 27 286 540 35 286 540 minecraft:black_wool
fill 27 286 547 29 286 547 minecraft:black_concrete
fill 28 286 524 29 286 524 minecraft:gray_wool
setblock 28 286 538 minecraft:gray_wool
fill 28 286 539 35 286 539 minecraft:black_wool
fill 29 286 516 30 286 516 minecraft:black_concrete
fill 29 286 523 35 286 523 minecraft:black_wool
setblock 29 286 525 minecraft:gray_wool
setblock 29 286 537 minecraft:gray_wool
fill 29 286 538 36 286 538 minecraft:black_wool
fill 29 286 546 30 286 546 minecraft:black_concrete
fill 30 286 524 36 286 525 minecraft:black_wool
setblock 30 286 526 minecraft:gray_wool
fill 30 286 535 30 286 536 minecraft:gray_wool
fill 30 286 537 36 286 537 minecraft:black_wool
fill 31 286 517 32 286 517 minecraft:black_concrete
fill 31 286 526 37 286 526 minecraft:black_wool
fill 31 286 527 31 286 534 minecraft:gray_wool
fill 31 286 535 37 286 536 minecraft:black_wool
fill 31 286 545 32 286 545 minecraft:black_concrete
fill 32 286 518 33 286 518 minecraft:black_concrete
fill 32 286 527 37 286 534 minecraft:black_wool
fill 32 286 544 33 286 544 minecraft:black_concrete
fill 33 286 519 34 286 519 minecraft:black_concrete
fill 33 286 543 34 286 543 minecraft:black_concrete
fill 34 286 520 35 286 520 minecraft:black_concrete
fill 34 286 542 35 286 542 minecraft:black_concrete
setblock 35 286 521 minecraft:black_concrete
setblock 35 286 541 minecraft:black_concrete
fill 36 286 522 36 286 523 minecraft:black_concrete
fill 36 286 539 36 286 540 minecraft:black_concrete
fill 37 286 523 37 286 525 minecraft:black_concrete
fill 37 286 537 37 286 539 minecraft:black_concrete
fill 38 286 526 38 286 536 minecraft:black_concrete
fill 42 286 515 42 307 515 minecraft:black_concrete
fill 0 287 546 0 302 546 minecraft:black_concrete
fill 5 287 526 5 287 536 minecraft:black_concrete
fill 6 287 524 6 287 528 minecraft:black_concrete
fill 6 287 529 9 287 533 minecraft:black_wool
fill 6 287 534 6 287 538 minecraft:black_concrete
fill 7 287 522 7 287 525 minecraft:black_concrete
fill 7 287 526 10 287 528 minecraft:black_wool
fill 7 287 534 10 287 536 minecraft:black_wool
fill 7 287 537 7 287 540 minecraft:black_concrete
fill 8 287 521 8 287 523 minecraft:black_concrete
fill 8 287 524 11 287 525 minecraft:black_wool
fill 8 287 537 11 287 538 minecraft:black_wool
fill 8 287 539 8 287 541 minecraft:black_concrete
fill 9 287 520 9 287 521 minecraft:black_concrete
fill 9 287 522 12 287 523 minecraft:black_wool
fill 9 287 539 12 287 540 minecraft:black_wool
fill 9 287 541 9 287 542 minecraft:black_concrete
fill 10 287 519 10 287 520 minecraft:black_concrete
fill 10 287 521 15 287 521 minecraft:black_wool
fill 10 287 529 10 287 533 minecraft:gray_wool
fill 10 287 541 15 287 541 minecraft:black_wool
fill 10 287 542 10 287 543 minecraft:black_concrete
fill 11 287 518 11 287 519 minecraft:black_concrete
fill 11 287 520 17 287 520 minecraft:black_wool
fill 11 287 526 11 287 530 minecraft:gray_wool
fill 11 287 532 11 287 536 minecraft:gray_wool
fill 11 287 542 18 287 542 minecraft:black_wool
fill 11 287 543 11 287 544 minecraft:black_concrete
fill 12 287 517 13 287 518 minecraft:black_concrete
fill 12 287 519 30 287 519 minecraft:black_wool
setblock 12 287 524 minecraft:black_wool
fill 12 287 525 12 287 526 minecraft:gray_wool
fill 12 287 536 12 287 537 minecraft:gray_wool
setblock 12 287 538 minecraft:black_wool
fill 12 287 543 30 287 543 minecraft:black_wool
fill 12 287 544 13 287 545 minecraft:black_concrete
setblock 13 287 522 minecraft:black_wool
fill 13 287 523 13 287 524 minecraft:gray_wool
fill 13 287 537 13 287 539 minecraft:gray_wool
fill 13 287 540 14 287 540 minecraft:black_wool
fill 14 287 516 15 287 517 minecraft:black_concrete
fill 14 287 518 28 287 518 minecraft:black_wool
fill 14 287 522 14 287 523 minecraft:gray_wool
setblock 14 287 539 minecraft:gray_wool
fill 14 287 544 28 287 544 minecraft:black_wool
fill 14 287 545 15 287 546 minecraft:black_concrete
setblock 15 287 522 minecraft:gray_wool
fill 15 287 540 16 287 540 minecraft:gray_wool
fill 16 287 515 18 287 516 minecraft:black_concrete
fill 16 287 517 26 287 517 minecraft:black_wool
fill 16 287 521 18 287 521 minecraft:gray_wool
fill 16 287 541 19 287 541 minecraft:gray_wool
fill 16 287 545 26 287 545 minecraft:black_wool
fill 16 287 546 18 287 547 minecraft:black_concrete
fill 18 287 520 24 287 520 minecraft:gray_wool
fill 19 287 515 26 287 515 minecraft:black_concrete
fill 19 287 516 23 287 516 minecraft:black_wool
fill 19 287 542 24 287 542 minecraft:gray_wool
fill 19 287 546 23 287 546 minecraft:black_wool
fill 19 287 547 26 287 547 minecraft:black_concrete
fill 24 287 516 28 287 516 minecraft:black_concrete
fill 24 287 541 26 287 541 minecraft:gray_wool
fill 24 287 546 28 287 546 minecraft:black_concrete
fill 25 287 520 31 287 520 minecraft:black_wool
fill 25 287 521 26 287 521 minecraft:gray_wool
fill 25 287 542 31 287 542 minecraft:black_wool
fill 27 287 517 30 287 517 minecraft:black_concrete
fill 27 287 521 32 287 521 minecraft:black_wool
fill 27 287 522 28 287 522 minecraft:gray_wool
fill 27 287 540 28 287 540 minecraft:gray_wool
fill 27 287 541 32 287 541 minecraft:black_wool
fill 27 287 545 30 287 545 minecraft:black_concrete
fill 28 287 539 29 287 539 minecraft:gray_wool
fill 29 287 518 31 287 518 minecraft:black_concrete
fill 29 287 522 33 287 522 minecraft:black_wool
setblock 29 287 523 minecraft:gray_wool
fill 29 287 538 30 287 538 minecraft:gray_wool
fill 29 287 540 33 287 540 minecraft:black_wool
fill 29 287 544 31 287 544 minecraft:black_concrete
fill 30 287 523 33 287 523 minecraft:black_wool
fill 30 287 524 30 287 525 minecraft:gray_wool
setblock 30 287 537 minecraft:gray_wool
fill 30 287 539 33 287 539 minecraft:black_wool
fill 31 287 519 32 287 519 minecraft:black_concrete
fill 31 287 524 34 287 525 minecraft:black_wool
fill 31 287 526 31 287 527 minecraft:gray_wool
fill 31 287 535 31 287 536 minecraft:gray_wool
fill 31 287 537 34 287 538 minecraft:black_wool
fill 31 287 543 32 287 543 minecraft:black_concrete
fill 32 287 520 33 287 520 minecraft:black_concrete
fill 32 287 526 35 287 527 minecraft:black_wool
fill 32 287 528 32 287 534 minecraft:gray_wool
fill 32 287 535 35 287 536 minecraft:black_wool
fill 32 287 542 33 287 542 minecraft:black_concrete
fill 33 287 521 34 287 521 minecraft:black_concrete
fill 33 287 528 35 287 534 minecraft:black_wool
fill 33 287 541 34 287 541 minecraft:black_concrete
fill 34 287 522 35 287 523 minecraft:black_concrete
fill 34 287 539 35 287 540 minecraft:black_concrete
fill 35 287 524 36 287 525 minecraft:black_concrete
fill 35 287 537 36 287 538 minecraft:black_concrete
fill 36 287 526 37 287 528 minecraft:black_concrete
fill 36 287 529 36 287 533 minecraft:black_wool
fill 36 287 534 37 287 536 minecraft:black_concrete
fill 37 287 529 37 287 533 minecraft:black_concrete
setblock 41 287 552 minecraft:light_blue_stained_glass
setblock 42 287 512 minecraft:white_concrete
fill 42 287 552 42 307 552 minecraft:black_concrete
fill 0 288 518 0 290 518 minecraft:cyan_concrete
fill 0 288 534 0 290 534 minecraft:cyan_concrete
fill 0 288 550 0 290 550 minecraft:cyan_concrete
fill 4 288 510 4 290 510 minecraft:cyan_concrete
fill 6 288 529 8 288 533 minecraft:black_concrete
fill 7 288 526 9 288 528 minecraft:black_concrete
fill 7 288 534 9 288 536 minecraft:black_concrete
fill 8 288 524 10 288 525 minecraft:black_concrete
fill 8 288 537 10 288 538 minecraft:black_concrete
fill 9 288 522 11 288 523 minecraft:black_concrete
fill 9 288 529 9 288 533 minecraft:gray_wool
fill 9 288 539 11 288 540 minecraft:black_concrete
fill 10 288 521 13 288 521 minecraft:black_concrete
fill 10 288 526 10 288 528 minecraft:gray_wool
fill 10 288 534 10 288 536 minecraft:gray_wool
fill 10 288 541 14 288 541 minecraft:black_concrete
fill 11 288 520 15 288 520 minecraft:black_concrete
setblock 11 288 524 minecraft:black_concrete
setblock 11 288 525 minecraft:gray_wool
setblock 11 288 537 minecraft:gray_wool
setblock 11 288 538 minecraft:black_concrete
fill 11 288 542 15 288 542 minecraft:black_concrete
fill 12 288 519 17 288 519 minecraft:black_concrete
setblock 12 288 522 minecraft:black_concrete
fill 12 288 523 12 288 524 minecraft:gray_wool
fill 12 288 538 12 288 539 minecraft:gray_wool
setblock 12 288 540 minecraft:black_concrete
fill 12 288 543 18 288 543 minecraft:black_concrete
setblock 13 288 522 minecraft:gray_wool
fill 13 288 540 14 288 540 minecraft:gray_wool
fill 14 288 518 28 288 518 minecraft:black_concrete
fill 14 288 521 15 288 521 minecraft:gray_wool
fill 14 288 544 28 288 544 minecraft:black_concrete
fill 14 288 552 14 290 552 minecraft:cyan_concrete
setblock 15 288 541 minecraft:gray_wool
fill 16 288 517 26 288 517 minecraft:black_concrete
fill 16 288 520 17 288 520 minecraft:gray_wool
fill 16 288 542 18 288 542 minecraft:gray_wool
fill 16 288 545 26 288 545 minecraft:black_concrete
fill 18 288 519 24 288 519 minecraft:gray_wool
fill 19 288 516 23 288 516 minecraft:black_concrete
fill 19 288 543 24 288 543 minecraft:gray_wool
fill 19 288 546 23 288 546 minecraft:black_concrete
fill 20 288 510 20 290 510 minecraft:cyan_concrete
fill 25 288 519 30 288 519 minecraft:black_concrete
fill 25 288 520 26 288 520 minecraft:gray_wool
fill 25 288 542 26 288 542 minecraft:gray_wool
fill 25 288 543 30 288 543 minecraft:black_concrete
fill 27 288 520 31 288 520 minecraft:black_concrete
fill 27 288 521 28 288 521 minecraft:gray_wool
fill 27 288 541 28 288 541 minecraft:gray_wool
fill 27 288 542 31 288 542 minecraft:black_concrete
fill 29 288 521 32 288 521 minecraft:black_concrete
setblock 29 288 522 minecraft:gray_wool
setblock 29 288 540 minecraft:gray_wool
fill 29 288 541 32 288 541 minecraft:black_concrete
fill 30 288 522 33 288 522 minecraft:black_concrete
setblock 30 288 523 minecraft:gray_wool
setblock 30 288 539 minecraft:gray_wool
fill 30 288 540 33 288 540 minecraft:black_concrete
fill 30 288 552 30 290 552 minecraft:cyan_concrete
fill 31 288 523 33 288 523 minecraft:black_concrete
fill 31 288 524 31 288 525 minecraft:gray_wool
fill 31 288 537 31 288 538 minecraft:gray_wool
fill 31 288 539 33 288 539 minecraft:black_concrete
fill 32 288 524 34 288 525 minecraft:black_concrete
fill 32 288 526 32 288 527 minecraft:gray_wool
fill 32 288 535 32 288 536 minecraft:gray_wool
fill 32 288 537 34 288 538 minecraft:black_concrete
fill 33 288 526 35 288 527 minecraft:black_concrete
fill 33 288 528 33 288 534 minecraft:gray_wool
fill 33 288 535 35 288 536 minecraft:black_concrete
fill 34 288 528 35 288 534 minecraft:black_concrete
fill 36 288 510 36 290 510 minecraft:cyan_concrete
fill 36 288 529 36 288 533 minecraft:black_concrete
setblock 41 288 510 minecraft:light_blue_stained_glass
fill 41 288 552 41 307 552 minecraft:black_concrete
fill 42 288 512 42 289 512 minecraft:black_concrete
fill 42 288 520 42 290 520 minecraft:cyan_concrete
setblock 42 288 526 minecraft:light_blue_stained_glass
fill 42 288 536 42 290 536 minecraft:cyan_concrete
fill 42 288 537 42 307 537 minecraft:black_concrete
setblock 0 289 529 minecraft:light_blue_stained_glass
fill 2 289 533 2 298 533 minecraft:iron_block
fill 27 289 542 28 289 543 minecraft:cyan_stained_glass
fill 28 289 546 30 292 548 minecraft:light_blue_stained_glass
fill 41 289 510 41 307 510 minecraft:black_concrete
fill 42 289 526 42 307 526 minecraft:black_concrete
setblock 0 290 527 minecraft:light_blue_stained_glass
fill 0 290 529 0 307 529 minecraft:black_concrete
fill 36 290 545 38 293 547 minecraft:light_blue_stained_glass
setblock 42 290 512 minecraft:white_concrete
setblock 42 290 514 minecraft:sea_lantern
fill 42 290 545 42 307 545 minecraft:black_concrete
setblock 42 290 546 minecraft:white_concrete
fill 0 291 518 0 296 518 minecraft:black_concrete
fill 0 291 527 0 307 527 minecraft:black_concrete
fill 0 291 534 0 296 534 minecraft:black_concrete
fill 0 291 550 0 296 550 minecraft:black_concrete
fill 4 291 510 4 296 510 minecraft:black_concrete
setblock 13 291 510 minecraft:white_concrete
fill 14 291 552 14 296 552 minecraft:black_concrete
fill 20 291 510 20 296 510 minecraft:black_concrete
setblock 24 291 510 minecraft:white_concrete
fill 30 291 552 30 296 552 minecraft:black_concrete
fill 36 291 510 36 296 510 minecraft:black_concrete
fill 39 291 552 40 291 552 minecraft:light_blue_stained_glass
fill 42 291 512 42 307 512 minecraft:black_concrete
fill 42 291 514 42 292 514 minecraft:black_concrete
fill 42 291 520 42 296 520 minecraft:black_concrete
fill 42 291 536 42 296 536 minecraft:black_concrete
fill 42 291 546 42 305 546 minecraft:black_concrete
setblock 42 291 549 minecraft:sea_lantern
setblock 8 292 552 minecraft:light_blue_stained_glass
fill 13 292 510 13 307 510 minecraft:black_concrete
fill 24 292 510 24 307 510 minecraft:black_concrete
fill 39 292 552 40 304 552 minecraft:black_concrete
setblock 42 292 542 minecraft:sea_lantern
fill 42 292 549 42 307 549 minecraft:black_concrete
setblock 0 293 516 minecraft:sea_lantern
setblock 3 293 513 minecraft:light[level=11]
setblock 3 293 521 minecraft:light[level=11]
setblock 3 293 529 minecraft:light[level=11]
setblock 3 293 537 minecraft:light[level=11]
setblock 3 293 545 minecraft:light[level=11]
fill 8 293 552 8 307 552 minecraft:black_concrete
setblock 10 293 510 minecraft:white_concrete
setblock 11 293 513 minecraft:light[level=11]
setblock 11 293 521 minecraft:light[level=11]
setblock 11 293 529 minecraft:light[level=11]
setblock 11 293 537 minecraft:light[level=11]
setblock 11 293 545 minecraft:light[level=11]
setblock 19 293 513 minecraft:light[level=11]
setblock 19 293 521 minecraft:light[level=11]
setblock 19 293 529 minecraft:light[level=11]
setblock 19 293 537 minecraft:light[level=11]
setblock 19 293 545 minecraft:light[level=11]
setblock 22 293 510 minecraft:sea_lantern
setblock 22 293 552 minecraft:sea_lantern
setblock 27 293 513 minecraft:light[level=11]
setblock 27 293 521 minecraft:light[level=11]
setblock 27 293 529 minecraft:light[level=11]
setblock 27 293 537 minecraft:light[level=11]
setblock 27 293 545 minecraft:light[level=11]
setblock 35 293 513 minecraft:light[level=11]
setblock 35 293 521 minecraft:light[level=11]
setblock 35 293 529 minecraft:light[level=11]
setblock 35 293 537 minecraft:light[level=11]
setblock 35 293 545 minecraft:light[level=11]
fill 36 293 544 38 296 544 minecraft:light_blue_stained_glass
setblock 42 293 514 minecraft:light_blue_stained_glass
setblock 42 293 538 minecraft:sea_lantern
fill 42 293 542 42 294 542 minecraft:black_concrete
fill 0 294 516 0 307 516 minecraft:black_concrete
setblock 0 294 521 minecraft:light_blue_stained_glass
setblock 9 294 552 minecraft:light_blue_stained_glass
fill 10 294 510 10 307 510 minecraft:black_concrete
fill 22 294 510 22 307 510 minecraft:black_concrete
fill 22 294 552 22 307 552 minecraft:black_concrete
setblock 26 294 552 minecraft:light_blue_stained_glass
setblock 31 294 510 minecraft:light_blue_stained_glass
setblock 32 294 552 minecraft:sea_lantern
fill 36 294 545 38 296 546 minecraft:light_blue_stained_glass
fill 42 294 514 42 300 514 minecraft:black_concrete
fill 42 294 538 42 307 538 minecraft:black_concrete
setblock 42 294 544 minecraft:sea_lantern
fill 0 295 521 0 307 521 minecraft:black_concrete
fill 9 295 552 9 307 552 minecraft:black_concrete
setblock 16 295 510 minecraft:light_blue_stained_glass
fill 26 295 552 26 304 552 minecraft:black_concrete
setblock 27 295 510 minecraft:white_concrete
fill 31 295 510 31 307 510 minecraft:black_concrete
fill 32 295 552 32 307 552 minecraft:black_concrete
fill 34 295 529 35 296 530 minecraft:cyan_stained_glass
setblock 42 295 542 minecraft:light_blue_stained_glass
fill 42 295 544 42 307 544 minecraft:black_concrete
fill 16 296 510 16 307 510 minecraft:black_concrete
setblock 27 296 510 minecraft:black_concrete
fill 42 296 542 42 307 542 minecraft:black_concrete
setblock 0 297 515 minecraft:sea_lantern
fill 0 297 518 0 299 518 minecraft:cyan_concrete
fill 0 297 534 0 299 534 minecraft:cyan_concrete
fill 0 297 550 0 299 550 minecraft:cyan_concrete
fill 4 297 510 4 299 510 minecraft:cyan_concrete
fill 14 297 552 14 299 552 minecraft:cyan_concrete
fill 20 297 510 20 299 510 minecraft:cyan_concrete
setblock 27 297 510 minecraft:sea_lantern
setblock 29 297 552 minecraft:sea_lantern
fill 30 297 552 30 299 552 minecraft:cyan_concrete
fill 36 297 510 36 299 510 minecraft:cyan_concrete
fill 42 297 520 42 299 520 minecraft:cyan_concrete
fill 42 297 536 42 299 536 minecraft:cyan_concrete
fill 0 298 515 0 307 515 minecraft:black_concrete
fill 27 298 510 27 307 510 minecraft:black_concrete
fill 29 298 552 29 307 552 minecraft:black_concrete
setblock 31 298 552 minecraft:white_concrete
setblock 42 298 530 minecraft:light_blue_stained_glass
setblock 0 299 538 minecraft:light_blue_stained_glass
setblock 0 299 549 minecraft:white_concrete
fill 31 299 552 31 307 552 minecraft:black_concrete
setblock 42 299 527 minecraft:white_concrete
fill 42 299 530 42 307 530 minecraft:black_concrete
fill 0 300 518 0 307 518 minecraft:black_concrete
fill 0 300 534 0 307 534 minecraft:black_concrete
fill 0 300 538 0 307 538 minecraft:black_concrete
setblock 0 300 545 minecraft:white_concrete
fill 0 300 549 0 307 550 minecraft:black_concrete
setblock 4 300 510 minecraft:white_concrete
setblock 7 300 510 minecraft:light_blue_stained_glass
fill 14 300 552 14 307 552 minecraft:black_concrete
setblock 15 300 552 minecraft:light_blue_stained_glass
fill 20 300 510 20 307 510 minecraft:black_concrete
fill 30 300 552 30 307 552 minecraft:black_concrete
fill 36 300 510 36 307 510 minecraft:black_concrete
fill 42 300 520 42 307 520 minecraft:black_concrete
fill 42 300 527 42 307 527 minecraft:black_concrete
fill 42 300 536 42 307 536 minecraft:black_concrete
setblock 0 301 513 minecraft:white_concrete
fill 0 301 545 0 307 545 minecraft:black_concrete
setblock 0 301 551 minecraft:white_concrete
setblock 3 301 513 minecraft:light[level=11]
setblock 3 301 521 minecraft:light[level=11]
setblock 3 301 529 minecraft:light[level=11]
setblock 3 301 537 minecraft:light[level=11]
setblock 3 301 545 minecraft:light[level=11]
fill 4 301 510 4 307 510 minecraft:black_concrete
fill 7 301 510 7 307 510 minecraft:black_concrete
setblock 11 301 513 minecraft:light[level=11]
setblock 11 301 521 minecraft:light[level=11]
setblock 11 301 529 minecraft:light[level=11]
setblock 11 301 537 minecraft:light[level=11]
setblock 11 301 545 minecraft:light[level=11]
fill 15 301 552 15 307 552 minecraft:black_concrete
setblock 18 301 552 minecraft:sea_lantern
setblock 19 301 513 minecraft:light[level=11]
setblock 19 301 521 minecraft:light[level=11]
setblock 19 301 529 minecraft:light[level=11]
setblock 19 301 537 minecraft:light[level=11]
setblock 19 301 545 minecraft:light[level=11]
setblock 27 301 513 minecraft:light[level=11]
setblock 27 301 521 minecraft:light[level=11]
setblock 27 301 529 minecraft:light[level=11]
setblock 27 301 537 minecraft:light[level=11]
setblock 27 301 545 minecraft:light[level=11]
setblock 34 301 510 minecraft:sea_lantern
setblock 35 301 513 minecraft:light[level=11]
setblock 35 301 521 minecraft:light[level=11]
setblock 35 301 529 minecraft:light[level=11]
setblock 35 301 537 minecraft:light[level=11]
setblock 35 301 545 minecraft:light[level=11]
setblock 42 301 514 minecraft:light_blue_stained_glass
fill 0 302 513 0 307 513 minecraft:black_concrete
setblock 0 302 523 minecraft:white_concrete
fill 0 302 551 0 307 551 minecraft:black_concrete
setblock 12 302 510 minecraft:white_concrete
fill 18 302 552 18 307 552 minecraft:black_concrete
fill 34 302 510 34 307 510 minecraft:black_concrete
fill 42 302 514 42 307 514 minecraft:black_concrete
fill 0 303 523 0 307 523 minecraft:black_concrete
setblock 0 303 546 minecraft:light_blue_stained_glass
fill 12 303 510 12 307 510 minecraft:black_concrete
fill 0 304 546 0 307 546 minecraft:black_concrete
setblock 42 304 517 minecraft:white_concrete
setblock 26 305 552 minecraft:white_concrete
setblock 33 305 510 minecraft:light_blue_stained_glass
fill 39 305 552 39 307 552 minecraft:black_concrete
setblock 40 305 552 minecraft:light_blue_stained_glass
fill 42 305 517 42 307 517 minecraft:black_concrete
setblock 42 305 525 minecraft:light_blue_stained_glass
setblock 11 306 552 minecraft:light_blue_stained_glass
fill 26 306 552 26 307 552 minecraft:black_concrete
setblock 32 306 510 minecraft:sea_lantern
fill 33 306 510 33 307 510 minecraft:black_concrete
fill 39 306 510 39 307 510 minecraft:black_concrete
setblock 40 306 510 minecraft:sea_lantern
fill 40 306 552 40 307 552 minecraft:black_concrete
fill 42 306 525 42 307 525 minecraft:black_concrete
setblock 42 306 546 minecraft:white_concrete
setblock 42 306 548 minecraft:white_concrete
setblock 0 307 525 minecraft:light_blue_stained_glass
setblock 0 307 532 minecraft:white_concrete
setblock 11 307 552 minecraft:black_concrete
setblock 32 307 510 minecraft:black_concrete
setblock 40 307 510 minecraft:black_concrete
fill 42 307 532 42 307 533 minecraft:white_concrete
setblock 42 307 546 minecraft:black_concrete
setblock 42 307 548 minecraft:black_concrete
