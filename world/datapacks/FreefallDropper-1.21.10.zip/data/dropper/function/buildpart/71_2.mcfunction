fill 553 126 317 556 131 317 minecraft:shroomlight
setblock 555 126 275 minecraft:white_concrete
setblock 559 126 275 minecraft:white_concrete
fill 559 126 276 559 131 279 minecraft:shroomlight
setblock 559 126 281 minecraft:white_concrete
setblock 559 126 285 minecraft:white_concrete
fill 559 126 288 559 131 291 minecraft:shroomlight
setblock 559 126 293 minecraft:white_concrete
setblock 559 126 297 minecraft:white_concrete
fill 559 126 300 559 131 303 minecraft:shroomlight
setblock 559 126 305 minecraft:white_concrete
setblock 559 126 309 minecraft:white_concrete
fill 559 126 312 559 131 315 minecraft:shroomlight
setblock 559 126 317 minecraft:white_concrete
setblock 517 127 276 minecraft:white_concrete
fill 517 127 277 517 134 277 minecraft:brown_terracotta
setblock 517 127 278 minecraft:white_concrete
setblock 517 127 280 minecraft:white_concrete
fill 517 127 285 517 134 285 minecraft:brown_terracotta
setblock 517 127 286 minecraft:white_concrete
setblock 517 127 288 minecraft:white_concrete
fill 517 127 289 517 134 289 minecraft:brown_terracotta
setblock 517 127 290 minecraft:white_concrete
setblock 517 127 292 minecraft:white_concrete
fill 517 127 297 517 134 297 minecraft:brown_terracotta
setblock 517 127 298 minecraft:white_concrete
setblock 517 127 300 minecraft:white_concrete
fill 517 127 301 517 134 301 minecraft:brown_terracotta
setblock 517 127 302 minecraft:white_concrete
setblock 517 127 304 minecraft:white_concrete
fill 517 127 309 517 134 309 minecraft:brown_terracotta
setblock 517 127 310 minecraft:white_concrete
setblock 517 127 312 minecraft:white_concrete
fill 517 127 313 517 134 313 minecraft:brown_terracotta
setblock 517 127 314 minecraft:white_concrete
setblock 517 127 316 minecraft:white_concrete
setblock 518 127 275 minecraft:white_concrete
fill 519 127 275 519 134 275 minecraft:brown_terracotta
setblock 520 127 275 minecraft:white_concrete
setblock 522 127 275 minecraft:white_concrete
setblock 522 127 317 minecraft:white_concrete
fill 523 127 275 523 134 275 minecraft:brown_terracotta
fill 523 127 317 523 134 317 minecraft:brown_terracotta
setblock 524 127 317 minecraft:white_concrete
setblock 526 127 317 minecraft:white_concrete
fill 527 127 317 527 134 317 minecraft:brown_terracotta
setblock 528 127 275 minecraft:white_concrete
setblock 528 127 317 minecraft:white_concrete
setblock 530 127 275 minecraft:white_concrete
fill 531 127 275 531 134 275 minecraft:brown_terracotta
setblock 532 127 275 minecraft:white_concrete
setblock 534 127 275 minecraft:white_concrete
setblock 534 127 317 minecraft:white_concrete
fill 535 127 275 535 134 275 minecraft:brown_terracotta
fill 535 127 317 535 134 317 minecraft:brown_terracotta
setblock 536 127 317 minecraft:white_concrete
setblock 538 127 317 minecraft:white_concrete
fill 539 127 317 539 134 317 minecraft:brown_terracotta
setblock 540 127 275 minecraft:white_concrete
setblock 540 127 317 minecraft:white_concrete
setblock 542 127 275 minecraft:white_concrete
fill 543 127 275 543 134 275 minecraft:brown_terracotta
setblock 544 127 275 minecraft:white_concrete
setblock 546 127 275 minecraft:white_concrete
setblock 546 127 317 minecraft:white_concrete
fill 547 127 275 547 134 275 minecraft:brown_terracotta
fill 547 127 317 547 134 317 minecraft:brown_terracotta
fill 548 127 275 549 131 275 minecraft:shroomlight
setblock 548 127 317 minecraft:white_concrete
setblock 550 127 317 minecraft:white_concrete
fill 551 127 317 551 134 317 minecraft:brown_terracotta
setblock 552 127 275 minecraft:white_concrete
setblock 552 127 317 minecraft:white_concrete
setblock 554 127 275 minecraft:white_concrete
fill 555 127 275 555 134 275 minecraft:brown_terracotta
setblock 556 127 275 minecraft:white_concrete
setblock 558 127 275 minecraft:white_concrete
setblock 558 127 317 minecraft:white_concrete
setblock 559 127 275 minecraft:brown_terracotta
setblock 559 127 280 minecraft:white_concrete
fill 559 127 281 559 134 281 minecraft:brown_terracotta
setblock 559 127 282 minecraft:white_concrete
setblock 559 127 284 minecraft:white_concrete
fill 559 127 285 559 134 285 minecraft:brown_terracotta
setblock 559 127 286 minecraft:white_concrete
setblock 559 127 292 minecraft:white_concrete
fill 559 127 293 559 134 293 minecraft:brown_terracotta
setblock 559 127 294 minecraft:white_concrete
setblock 559 127 296 minecraft:white_concrete
fill 559 127 297 559 134 297 minecraft:brown_terracotta
setblock 559 127 298 minecraft:white_concrete
setblock 559 127 304 minecraft:white_concrete
fill 559 127 305 559 134 305 minecraft:brown_terracotta
setblock 559 127 306 minecraft:white_concrete
setblock 559 127 308 minecraft:white_concrete
fill 559 127 309 559 134 309 minecraft:brown_terracotta
setblock 559 127 310 minecraft:white_concrete
setblock 559 127 316 minecraft:white_concrete
fill 559 127 317 559 134 317 minecraft:brown_terracotta
setblock 517 128 275 minecraft:white_concrete
fill 517 128 276 517 135 276 minecraft:brown_terracotta
fill 517 128 278 517 135 278 minecraft:brown_terracotta
setblock 517 128 279 minecraft:white_concrete
fill 517 128 280 517 135 280 minecraft:brown_terracotta
fill 517 128 286 517 135 286 minecraft:brown_terracotta
setblock 517 128 287 minecraft:white_concrete
fill 517 128 288 517 135 288 minecraft:brown_terracotta
fill 517 128 290 517 135 290 minecraft:brown_terracotta
setblock 517 128 291 minecraft:white_concrete
fill 517 128 292 517 135 292 minecraft:brown_terracotta
fill 517 128 298 517 135 298 minecraft:brown_terracotta
setblock 517 128 299 minecraft:white_concrete
fill 517 128 300 517 135 300 minecraft:brown_terracotta
fill 517 128 302 517 135 302 minecraft:brown_terracotta
setblock 517 128 303 minecraft:white_concrete
fill 517 128 304 517 135 304 minecraft:brown_terracotta
fill 517 128 310 517 135 310 minecraft:brown_terracotta
setblock 517 128 311 minecraft:white_concrete
fill 517 128 312 517 135 312 minecraft:brown_terracotta
fill 517 128 314 517 135 314 minecraft:brown_terracotta
setblock 517 128 315 minecraft:white_concrete
fill 517 128 316 517 135 316 minecraft:brown_terracotta
fill 518 128 275 518 135 275 minecraft:brown_terracotta
fill 520 128 275 520 135 275 minecraft:brown_terracotta
setblock 521 128 275 minecraft:white_concrete
setblock 521 128 317 minecraft:white_concrete
fill 522 128 275 522 135 275 minecraft:brown_terracotta
fill 522 128 317 522 135 317 minecraft:brown_terracotta
fill 524 128 317 524 135 317 minecraft:brown_terracotta
setblock 525 128 317 minecraft:white_concrete
fill 526 128 317 526 135 317 minecraft:brown_terracotta
fill 528 128 275 528 135 275 minecraft:brown_terracotta
fill 528 128 317 528 135 317 minecraft:brown_terracotta
setblock 529 128 275 minecraft:white_concrete
fill 530 128 275 530 135 275 minecraft:brown_terracotta
fill 532 128 275 532 135 275 minecraft:brown_terracotta
setblock 533 128 275 minecraft:white_concrete
setblock 533 128 317 minecraft:white_concrete
fill 534 128 275 534 135 275 minecraft:brown_terracotta
fill 534 128 317 534 135 317 minecraft:brown_terracotta
fill 536 128 317 536 135 317 minecraft:brown_terracotta
setblock 537 128 317 minecraft:white_concrete
fill 538 128 317 538 135 317 minecraft:brown_terracotta
fill 540 128 275 540 135 275 minecraft:brown_terracotta
fill 540 128 317 540 135 317 minecraft:brown_terracotta
setblock 541 128 275 minecraft:white_concrete
fill 542 128 275 542 135 275 minecraft:brown_terracotta
fill 544 128 275 544 135 275 minecraft:brown_terracotta
setblock 545 128 275 minecraft:white_concrete
setblock 545 128 317 minecraft:white_concrete
fill 546 128 275 546 135 275 minecraft:brown_terracotta
fill 546 128 317 546 135 317 minecraft:brown_terracotta
fill 548 128 317 548 135 317 minecraft:brown_terracotta
setblock 549 128 317 minecraft:white_concrete
fill 550 128 317 550 135 317 minecraft:brown_terracotta
fill 552 128 275 552 135 275 minecraft:brown_terracotta
fill 552 128 317 552 135 317 minecraft:brown_terracotta
setblock 553 128 275 minecraft:white_concrete
fill 554 128 275 554 135 275 minecraft:brown_terracotta
fill 556 128 275 556 135 275 minecraft:brown_terracotta
setblock 557 128 275 minecraft:white_concrete
setblock 557 128 317 minecraft:white_concrete
fill 558 128 275 558 135 275 minecraft:brown_terracotta
fill 558 128 317 558 135 317 minecraft:brown_terracotta
setblock 559 128 275 minecraft:white_concrete
fill 559 128 280 559 135 280 minecraft:brown_terracotta
fill 559 128 282 559 135 282 minecraft:brown_terracotta
setblock 559 128 283 minecraft:white_concrete
fill 559 128 284 559 135 284 minecraft:brown_terracotta
fill 559 128 286 559 135 286 minecraft:brown_terracotta
setblock 559 128 287 minecraft:white_concrete
fill 559 128 292 559 135 292 minecraft:brown_terracotta
fill 559 128 294 559 135 294 minecraft:brown_terracotta
setblock 559 128 295 minecraft:white_concrete
fill 559 128 296 559 135 296 minecraft:brown_terracotta
fill 559 128 298 559 135 298 minecraft:brown_terracotta
setblock 559 128 299 minecraft:white_concrete
fill 559 128 304 559 135 304 minecraft:brown_terracotta
fill 559 128 306 559 135 306 minecraft:brown_terracotta
setblock 559 128 307 minecraft:white_concrete
fill 559 128 308 559 135 308 minecraft:brown_terracotta
fill 559 128 310 559 135 310 minecraft:brown_terracotta
setblock 559 128 311 minecraft:white_concrete
fill 559 128 316 559 135 316 minecraft:brown_terracotta
fill 517 129 275 517 136 275 minecraft:brown_terracotta
fill 517 129 279 517 136 279 minecraft:brown_terracotta
fill 517 129 287 517 136 287 minecraft:brown_terracotta
fill 517 129 291 517 136 291 minecraft:brown_terracotta
fill 517 129 299 517 136 299 minecraft:brown_terracotta
fill 517 129 303 517 136 303 minecraft:brown_terracotta
fill 517 129 311 517 136 311 minecraft:brown_terracotta
fill 517 129 315 517 136 315 minecraft:brown_terracotta
setblock 520 129 278 minecraft:light[level=12]
setblock 520 129 285 minecraft:light[level=12]
setblock 520 129 292 minecraft:light[level=12]
setblock 520 129 299 minecraft:light[level=12]
setblock 520 129 306 minecraft:light[level=12]
setblock 520 129 313 minecraft:light[level=12]
fill 521 129 275 521 136 275 minecraft:brown_terracotta
fill 521 129 317 521 136 317 minecraft:brown_terracotta
fill 525 129 317 525 136 317 minecraft:brown_terracotta
setblock 527 129 278 minecraft:light[level=12]
setblock 527 129 285 minecraft:light[level=12]
setblock 527 129 292 minecraft:light[level=12]
setblock 527 129 299 minecraft:light[level=12]
setblock 527 129 306 minecraft:light[level=12]
setblock 527 129 313 minecraft:light[level=12]
fill 529 129 275 529 136 275 minecraft:brown_terracotta
fill 533 129 275 533 136 275 minecraft:brown_terracotta
fill 533 129 317 533 136 317 minecraft:brown_terracotta
setblock 534 129 278 minecraft:light[level=12]
setblock 534 129 285 minecraft:light[level=12]
setblock 534 129 292 minecraft:light[level=12]
setblock 534 129 299 minecraft:light[level=12]
setblock 534 129 306 minecraft:light[level=12]
setblock 534 129 313 minecraft:light[level=12]
fill 537 129 317 537 136 317 minecraft:brown_terracotta
fill 540 129 278 541 130 279 minecraft:red_concrete
fill 541 129 275 541 136 275 minecraft:brown_terracotta
setblock 541 129 285 minecraft:light[level=12]
setblock 541 129 292 minecraft:light[level=12]
setblock 541 129 299 minecraft:light[level=12]
setblock 541 129 306 minecraft:light[level=12]
setblock 541 129 313 minecraft:light[level=12]
fill 545 129 275 545 136 275 minecraft:brown_terracotta
fill 545 129 317 545 136 317 minecraft:brown_terracotta
setblock 548 129 278 minecraft:light[level=12]
setblock 548 129 285 minecraft:light[level=12]
setblock 548 129 292 minecraft:light[level=12]
setblock 548 129 299 minecraft:light[level=12]
setblock 548 129 306 minecraft:light[level=12]
setblock 548 129 313 minecraft:light[level=12]
fill 549 129 317 549 136 317 minecraft:brown_terracotta
fill 553 129 275 553 136 275 minecraft:brown_terracotta
setblock 555 129 278 minecraft:light[level=12]
setblock 555 129 285 minecraft:light[level=12]
setblock 555 129 292 minecraft:light[level=12]
setblock 555 129 299 minecraft:light[level=12]
setblock 555 129 306 minecraft:light[level=12]
setblock 555 129 313 minecraft:light[level=12]
fill 557 129 275 557 136 275 minecraft:brown_terracotta
fill 557 129 317 557 136 317 minecraft:brown_terracotta
fill 559 129 275 559 134 275 minecraft:brown_terracotta
fill 559 129 283 559 136 283 minecraft:brown_terracotta
fill 559 129 287 559 136 287 minecraft:brown_terracotta
fill 559 129 295 559 136 295 minecraft:brown_terracotta
fill 559 129 299 559 136 299 minecraft:brown_terracotta
fill 559 129 307 559 136 307 minecraft:brown_terracotta
fill 559 129 311 559 136 311 minecraft:brown_terracotta
fill 529 130 309 529 131 310 minecraft:red_concrete
setblock 520 131 278 minecraft:light[level=15]
setblock 520 131 286 minecraft:light[level=15]
setblock 520 131 294 minecraft:light[level=15]
setblock 520 131 302 minecraft:light[level=15]
setblock 520 131 310 minecraft:light[level=15]
setblock 528 131 278 minecraft:light[level=15]
setblock 528 131 286 minecraft:light[level=15]
setblock 528 131 294 minecraft:light[level=15]
setblock 528 131 302 minecraft:light[level=15]
setblock 528 131 310 minecraft:light[level=15]
setblock 536 131 278 minecraft:light[level=15]
setblock 536 131 286 minecraft:light[level=15]
setblock 536 131 294 minecraft:light[level=15]
setblock 536 131 302 minecraft:light[level=15]
setblock 536 131 310 minecraft:light[level=15]
setblock 544 131 278 minecraft:light[level=15]
setblock 544 131 286 minecraft:light[level=15]
setblock 544 131 294 minecraft:light[level=15]
setblock 544 131 302 minecraft:light[level=15]
setblock 544 131 310 minecraft:light[level=15]
setblock 552 131 278 minecraft:light[level=15]
setblock 552 131 286 minecraft:light[level=15]
setblock 552 131 294 minecraft:light[level=15]
setblock 552 131 302 minecraft:light[level=15]
setblock 552 131 310 minecraft:light[level=15]
fill 517 132 281 517 134 281 minecraft:brown_terracotta
fill 517 132 282 517 132 283 minecraft:shroomlight
fill 517 132 284 517 135 284 minecraft:brown_terracotta
fill 517 132 293 517 134 293 minecraft:brown_terracotta
fill 517 132 294 517 132 295 minecraft:shroomlight
fill 517 132 296 517 135 296 minecraft:brown_terracotta
fill 517 132 305 517 134 305 minecraft:brown_terracotta
fill 517 132 306 517 132 307 minecraft:shroomlight
fill 517 132 308 517 135 308 minecraft:brown_terracotta
fill 517 132 317 517 134 317 minecraft:brown_terracotta
fill 518 132 317 519 132 317 minecraft:shroomlight
fill 520 132 317 520 135 317 minecraft:brown_terracotta
fill 524 132 275 524 135 275 minecraft:brown_terracotta
fill 525 132 275 526 132 275 minecraft:shroomlight
fill 527 132 275 527 134 275 minecraft:brown_terracotta
fill 529 132 317 529 136 317 minecraft:brown_terracotta
fill 530 132 317 531 132 317 minecraft:shroomlight
fill 532 132 317 532 135 317 minecraft:brown_terracotta
fill 536 132 275 536 135 275 minecraft:brown_terracotta
fill 537 132 275 538 132 275 minecraft:shroomlight
fill 539 132 275 539 134 275 minecraft:brown_terracotta
fill 541 132 317 541 136 317 minecraft:brown_terracotta
fill 542 132 317 543 132 317 minecraft:shroomlight
fill 544 132 317 544 135 317 minecraft:brown_terracotta
fill 547 132 294 549 133 294 minecraft:lime_concrete
fill 548 132 275 548 135 275 minecraft:brown_terracotta
fill 548 132 293 548 133 293 minecraft:lime_concrete
fill 548 132 295 548 133 295 minecraft:lime_concrete
fill 549 132 275 550 132 275 minecraft:shroomlight
fill 551 132 275 551 134 275 minecraft:brown_terracotta
fill 553 132 317 553 136 317 minecraft:brown_terracotta
fill 554 132 317 555 132 317 minecraft:shroomlight
fill 556 132 317 556 135 317 minecraft:brown_terracotta
fill 559 132 276 559 135 276 minecraft:brown_terracotta
fill 559 132 277 559 132 278 minecraft:shroomlight
fill 559 132 279 559 136 279 minecraft:brown_terracotta
fill 559 132 288 559 135 288 minecraft:brown_terracotta
fill 559 132 289 559 132 290 minecraft:shroomlight
fill 559 132 291 559 136 291 minecraft:brown_terracotta
fill 559 132 300 559 135 300 minecraft:brown_terracotta
fill 559 132 301 559 132 302 minecraft:shroomlight
fill 559 132 303 559 136 303 minecraft:brown_terracotta
fill 559 132 312 559 135 312 minecraft:brown_terracotta
fill 559 132 313 559 132 314 minecraft:shroomlight
fill 559 132 315 559 136 315 minecraft:brown_terracotta
fill 517 133 282 517 135 283 minecraft:brown_terracotta
fill 517 133 294 517 135 295 minecraft:brown_terracotta
fill 517 133 306 517 135 307 minecraft:brown_terracotta
fill 518 133 317 519 134 317 minecraft:brown_terracotta
fill 525 133 275 526 135 275 minecraft:brown_terracotta
fill 530 133 317 531 134 317 minecraft:brown_terracotta
fill 537 133 275 538 135 275 minecraft:brown_terracotta
fill 542 133 310 542 136 310 minecraft:iron_block
fill 542 133 317 543 134 317 minecraft:brown_terracotta
fill 549 133 275 550 135 275 minecraft:brown_terracotta
fill 554 133 317 555 134 317 minecraft:brown_terracotta
fill 559 133 277 559 134 278 minecraft:brown_terracotta
fill 559 133 289 559 134 290 minecraft:brown_terracotta
fill 559 133 301 559 134 302 minecraft:brown_terracotta
fill 559 133 313 559 134 314 minecraft:brown_terracotta
setblock 517 135 277 minecraft:white_concrete
setblock 517 135 281 minecraft:white_concrete
setblock 517 135 285 minecraft:white_concrete
setblock 517 135 289 minecraft:white_concrete
setblock 517 135 293 minecraft:white_concrete
setblock 517 135 297 minecraft:white_concrete
setblock 517 135 301 minecraft:white_concrete
setblock 517 135 305 minecraft:white_concrete
setblock 517 135 309 minecraft:white_concrete
setblock 517 135 313 minecraft:white_concrete
setblock 517 135 317 minecraft:white_concrete
setblock 518 135 317 minecraft:brown_terracotta
setblock 519 135 275 minecraft:white_concrete
setblock 519 135 317 minecraft:white_concrete
setblock 520 135 278 minecraft:light[level=12]
setblock 520 135 285 minecraft:light[level=12]
setblock 520 135 292 minecraft:light[level=12]
setblock 520 135 299 minecraft:light[level=12]
setblock 520 135 306 minecraft:light[level=12]
setblock 520 135 313 minecraft:light[level=12]
setblock 523 135 275 minecraft:white_concrete
setblock 523 135 317 minecraft:white_concrete
setblock 527 135 275 minecraft:white_concrete
setblock 527 135 278 minecraft:light[level=12]
setblock 527 135 285 minecraft:light[level=12]
setblock 527 135 292 minecraft:light[level=12]
setblock 527 135 299 minecraft:light[level=12]
setblock 527 135 306 minecraft:light[level=12]
setblock 527 135 313 minecraft:light[level=12]
setblock 527 135 317 minecraft:white_concrete
setblock 530 135 317 minecraft:brown_terracotta
setblock 531 135 275 minecraft:white_concrete
setblock 531 135 317 minecraft:white_concrete
setblock 534 135 278 minecraft:light[level=12]
setblock 534 135 285 minecraft:light[level=12]
setblock 534 135 292 minecraft:light[level=12]
setblock 534 135 299 minecraft:light[level=12]
setblock 534 135 306 minecraft:light[level=12]
setblock 534 135 313 minecraft:light[level=12]
setblock 535 135 275 minecraft:white_concrete
setblock 535 135 317 minecraft:white_concrete
setblock 539 135 275 minecraft:white_concrete
setblock 539 135 317 minecraft:white_concrete
setblock 541 135 278 minecraft:light[level=12]
setblock 541 135 285 minecraft:light[level=12]
setblock 541 135 292 minecraft:light[level=12]
setblock 541 135 299 minecraft:light[level=12]
setblock 541 135 306 minecraft:light[level=12]
setblock 541 135 313 minecraft:light[level=12]
setblock 542 135 317 minecraft:brown_terracotta
setblock 543 135 275 minecraft:white_concrete
setblock 543 135 317 minecraft:white_concrete
setblock 547 135 275 minecraft:white_concrete
setblock 547 135 317 minecraft:white_concrete
setblock 548 135 278 minecraft:light[level=12]
setblock 548 135 285 minecraft:light[level=12]
setblock 548 135 292 minecraft:light[level=12]
setblock 548 135 299 minecraft:light[level=12]
setblock 548 135 306 minecraft:light[level=12]
setblock 548 135 313 minecraft:light[level=12]
setblock 551 135 275 minecraft:white_concrete
setblock 551 135 317 minecraft:white_concrete
setblock 554 135 317 minecraft:brown_terracotta
setblock 555 135 275 minecraft:white_concrete
setblock 555 135 278 minecraft:light[level=12]
setblock 555 135 285 minecraft:light[level=12]
setblock 555 135 292 minecraft:light[level=12]
setblock 555 135 299 minecraft:light[level=12]
setblock 555 135 306 minecraft:light[level=12]
setblock 555 135 313 minecraft:light[level=12]
setblock 555 135 317 minecraft:white_concrete
fill 556 135 282 556 148 282 minecraft:red_wool
setblock 559 135 275 minecraft:white_concrete
setblock 559 135 277 minecraft:white_concrete
setblock 559 135 278 minecraft:brown_terracotta
setblock 559 135 281 minecraft:white_concrete
setblock 559 135 285 minecraft:white_concrete
setblock 559 135 289 minecraft:white_concrete
setblock 559 135 290 minecraft:brown_terracotta
setblock 559 135 293 minecraft:white_concrete
setblock 559 135 297 minecraft:white_concrete
setblock 559 135 301 minecraft:white_concrete
setblock 559 135 302 minecraft:brown_terracotta
setblock 559 135 305 minecraft:white_concrete
setblock 559 135 309 minecraft:white_concrete
setblock 559 135 313 minecraft:white_concrete
setblock 559 135 314 minecraft:brown_terracotta
setblock 559 135 317 minecraft:white_concrete
setblock 517 136 276 minecraft:white_concrete
fill 517 136 277 517 143 277 minecraft:brown_terracotta
setblock 517 136 278 minecraft:white_concrete
setblock 517 136 280 minecraft:white_concrete
fill 517 136 281 517 143 281 minecraft:brown_terracotta
setblock 517 136 282 minecraft:white_concrete
setblock 517 136 283 minecraft:brown_terracotta
setblock 517 136 284 minecraft:white_concrete
fill 517 136 285 517 143 285 minecraft:brown_terracotta
setblock 517 136 286 minecraft:white_concrete
setblock 517 136 288 minecraft:white_concrete
fill 517 136 289 517 143 289 minecraft:brown_terracotta
setblock 517 136 290 minecraft:white_concrete
setblock 517 136 292 minecraft:white_concrete
fill 517 136 293 517 143 293 minecraft:brown_terracotta
setblock 517 136 294 minecraft:white_concrete
setblock 517 136 295 minecraft:brown_terracotta
setblock 517 136 296 minecraft:white_concrete
fill 517 136 297 517 143 297 minecraft:brown_terracotta
setblock 517 136 298 minecraft:white_concrete
setblock 517 136 300 minecraft:white_concrete
fill 517 136 301 517 143 301 minecraft:brown_terracotta
setblock 517 136 302 minecraft:white_concrete
setblock 517 136 304 minecraft:white_concrete
fill 517 136 305 517 143 305 minecraft:brown_terracotta
setblock 517 136 306 minecraft:white_concrete
setblock 517 136 307 minecraft:brown_terracotta
setblock 517 136 308 minecraft:white_concrete
fill 517 136 309 517 143 309 minecraft:brown_terracotta
setblock 517 136 310 minecraft:white_concrete
setblock 517 136 312 minecraft:white_concrete
fill 517 136 313 517 143 313 minecraft:brown_terracotta
setblock 517 136 314 minecraft:white_concrete
setblock 517 136 316 minecraft:white_concrete
setblock 517 136 317 minecraft:brown_terracotta
setblock 518 136 275 minecraft:white_concrete
setblock 518 136 317 minecraft:white_concrete
fill 519 136 275 519 143 275 minecraft:brown_terracotta
fill 519 136 317 519 143 317 minecraft:brown_terracotta
setblock 520 136 275 minecraft:white_concrete
setblock 520 136 317 minecraft:white_concrete
setblock 522 136 275 minecraft:white_concrete
setblock 522 136 317 minecraft:white_concrete
fill 523 136 275 523 143 275 minecraft:brown_terracotta
fill 523 136 317 523 143 317 minecraft:brown_terracotta
setblock 524 136 275 minecraft:white_concrete
setblock 524 136 317 minecraft:white_concrete
setblock 525 136 275 minecraft:brown_terracotta
setblock 526 136 275 minecraft:white_concrete
setblock 526 136 317 minecraft:white_concrete
fill 527 136 275 527 143 275 minecraft:brown_terracotta
fill 527 136 317 527 143 317 minecraft:brown_terracotta
setblock 528 136 275 minecraft:white_concrete
setblock 528 136 317 minecraft:white_concrete
setblock 530 136 275 minecraft:white_concrete
setblock 530 136 317 minecraft:white_concrete
fill 531 136 275 531 143 275 minecraft:brown_terracotta
fill 531 136 317 531 143 317 minecraft:brown_terracotta
setblock 532 136 275 minecraft:white_concrete
setblock 532 136 317 minecraft:white_concrete
setblock 534 136 275 minecraft:white_concrete
setblock 534 136 317 minecraft:white_concrete
fill 535 136 275 535 143 275 minecraft:brown_terracotta
fill 535 136 317 535 143 317 minecraft:brown_terracotta
setblock 536 136 275 minecraft:white_concrete
setblock 536 136 317 minecraft:white_concrete
setblock 537 136 275 minecraft:brown_terracotta
setblock 538 136 275 minecraft:white_concrete
setblock 538 136 317 minecraft:white_concrete
fill 539 136 275 539 143 275 minecraft:brown_terracotta
fill 539 136 317 539 143 317 minecraft:brown_terracotta
setblock 540 136 275 minecraft:white_concrete
setblock 540 136 317 minecraft:white_concrete
setblock 542 136 275 minecraft:white_concrete
setblock 542 136 317 minecraft:white_concrete
fill 543 136 275 543 143 275 minecraft:brown_terracotta
fill 543 136 317 543 143 317 minecraft:brown_terracotta
setblock 544 136 275 minecraft:white_concrete
setblock 544 136 317 minecraft:white_concrete
setblock 546 136 275 minecraft:white_concrete
setblock 546 136 317 minecraft:white_concrete
fill 547 136 275 547 143 275 minecraft:brown_terracotta
fill 547 136 317 547 143 317 minecraft:brown_terracotta
setblock 548 136 275 minecraft:white_concrete
setblock 548 136 317 minecraft:white_concrete
setblock 549 136 275 minecraft:brown_terracotta
setblock 550 136 275 minecraft:white_concrete
setblock 550 136 317 minecraft:white_concrete
fill 551 136 275 551 143 275 minecraft:brown_terracotta
fill 551 136 317 551 143 317 minecraft:brown_terracotta
setblock 552 136 275 minecraft:white_concrete
setblock 552 136 317 minecraft:white_concrete
setblock 554 136 275 minecraft:white_concrete
setblock 554 136 317 minecraft:white_concrete
fill 555 136 275 555 143 275 minecraft:brown_terracotta
fill 555 136 317 555 143 317 minecraft:brown_terracotta
setblock 556 136 275 minecraft:white_concrete
fill 556 136 280 556 148 281 minecraft:red_wool
fill 556 136 283 556 148 284 minecraft:red_wool
setblock 556 136 317 minecraft:white_concrete
setblock 558 136 275 minecraft:white_concrete
setblock 558 136 317 minecraft:white_concrete
setblock 559 136 275 minecraft:brown_terracotta
setblock 559 136 276 minecraft:white_concrete
fill 559 136 277 559 143 277 minecraft:brown_terracotta
setblock 559 136 278 minecraft:white_concrete
setblock 559 136 280 minecraft:white_concrete
fill 559 136 281 559 143 281 minecraft:brown_terracotta
setblock 559 136 282 minecraft:white_concrete
setblock 559 136 284 minecraft:white_concrete
fill 559 136 285 559 143 285 minecraft:brown_terracotta
setblock 559 136 286 minecraft:white_concrete
setblock 559 136 288 minecraft:white_concrete
fill 559 136 289 559 143 289 minecraft:brown_terracotta
setblock 559 136 290 minecraft:white_concrete
setblock 559 136 292 minecraft:white_concrete
fill 559 136 293 559 143 293 minecraft:brown_terracotta
setblock 559 136 294 minecraft:white_concrete
setblock 559 136 296 minecraft:white_concrete
fill 559 136 297 559 143 297 minecraft:brown_terracotta
setblock 559 136 298 minecraft:white_concrete
setblock 559 136 300 minecraft:white_concrete
fill 559 136 301 559 143 301 minecraft:brown_terracotta
setblock 559 136 302 minecraft:white_concrete
setblock 559 136 304 minecraft:white_concrete
fill 559 136 305 559 143 305 minecraft:brown_terracotta
setblock 559 136 306 minecraft:white_concrete
setblock 559 136 308 minecraft:white_concrete
fill 559 136 309 559 143 309 minecraft:brown_terracotta
setblock 559 136 310 minecraft:white_concrete
setblock 559 136 312 minecraft:white_concrete
fill 559 136 313 559 143 313 minecraft:brown_terracotta
setblock 559 136 314 minecraft:white_concrete
setblock 559 136 316 minecraft:white_concrete
fill 559 136 317 559 143 317 minecraft:brown_terracotta
setblock 517 137 275 minecraft:white_concrete
fill 517 137 276 517 144 276 minecraft:brown_terracotta
fill 517 137 278 517 144 278 minecraft:brown_terracotta
setblock 517 137 279 minecraft:white_concrete
fill 517 137 280 517 144 280 minecraft:brown_terracotta
fill 517 137 282 517 144 282 minecraft:brown_terracotta
setblock 517 137 283 minecraft:white_concrete
fill 517 137 284 517 144 284 minecraft:brown_terracotta
fill 517 137 286 517 144 286 minecraft:brown_terracotta
setblock 517 137 287 minecraft:white_concrete
fill 517 137 288 517 144 288 minecraft:brown_terracotta
fill 517 137 290 517 144 290 minecraft:brown_terracotta
setblock 517 137 291 minecraft:white_concrete
fill 517 137 292 517 144 292 minecraft:brown_terracotta
fill 517 137 294 517 144 294 minecraft:brown_terracotta
setblock 517 137 295 minecraft:white_concrete
fill 517 137 296 517 144 296 minecraft:brown_terracotta
fill 517 137 298 517 144 298 minecraft:brown_terracotta
setblock 517 137 299 minecraft:white_concrete
fill 517 137 300 517 144 300 minecraft:brown_terracotta
fill 517 137 302 517 144 302 minecraft:brown_terracotta
setblock 517 137 303 minecraft:white_concrete
fill 517 137 304 517 144 304 minecraft:brown_terracotta
fill 517 137 306 517 144 306 minecraft:brown_terracotta
setblock 517 137 307 minecraft:white_concrete
fill 517 137 308 517 144 308 minecraft:brown_terracotta
fill 517 137 310 517 144 310 minecraft:brown_terracotta
setblock 517 137 311 minecraft:white_concrete
fill 517 137 312 517 144 312 minecraft:brown_terracotta
fill 517 137 314 517 144 314 minecraft:brown_terracotta
setblock 517 137 315 minecraft:white_concrete
fill 517 137 316 517 144 316 minecraft:brown_terracotta
setblock 517 137 317 minecraft:white_concrete
fill 518 137 275 518 144 275 minecraft:brown_terracotta
fill 518 137 317 518 144 317 minecraft:brown_terracotta
fill 520 137 275 520 144 275 minecraft:brown_terracotta
fill 520 137 317 520 144 317 minecraft:brown_terracotta
setblock 521 137 275 minecraft:white_concrete
setblock 521 137 317 minecraft:white_concrete
fill 522 137 275 522 144 275 minecraft:brown_terracotta
fill 522 137 317 522 144 317 minecraft:brown_terracotta
fill 524 137 275 524 144 275 minecraft:brown_terracotta
fill 524 137 317 524 144 317 minecraft:brown_terracotta
setblock 525 137 275 minecraft:white_concrete
setblock 525 137 317 minecraft:white_concrete
fill 526 137 275 526 144 275 minecraft:brown_terracotta
fill 526 137 317 526 144 317 minecraft:brown_terracotta
fill 528 137 275 528 144 275 minecraft:brown_terracotta
fill 528 137 317 528 144 317 minecraft:brown_terracotta
setblock 529 137 275 minecraft:white_concrete
setblock 529 137 317 minecraft:white_concrete
fill 530 137 275 530 144 275 minecraft:brown_terracotta
fill 530 137 317 530 144 317 minecraft:brown_terracotta
fill 532 137 275 532 144 275 minecraft:brown_terracotta
fill 532 137 317 532 144 317 minecraft:brown_terracotta
setblock 533 137 275 minecraft:white_concrete
setblock 533 137 317 minecraft:white_concrete
fill 534 137 275 534 144 275 minecraft:brown_terracotta
fill 534 137 317 534 144 317 minecraft:brown_terracotta
fill 536 137 275 536 144 275 minecraft:brown_terracotta
fill 536 137 317 536 144 317 minecraft:brown_terracotta
setblock 537 137 275 minecraft:white_concrete
setblock 537 137 317 minecraft:white_concrete
fill 538 137 275 538 144 275 minecraft:brown_terracotta
fill 538 137 317 538 144 317 minecraft:brown_terracotta
fill 539 137 310 545 137 315 minecraft:brown_terracotta
fill 540 137 275 540 144 275 minecraft:brown_terracotta
fill 540 137 317 540 144 317 minecraft:brown_terracotta
setblock 541 137 275 minecraft:white_concrete
setblock 541 137 317 minecraft:white_concrete
fill 542 137 275 542 144 275 minecraft:brown_terracotta
fill 542 137 317 542 144 317 minecraft:brown_terracotta
fill 544 137 275 544 144 275 minecraft:brown_terracotta
fill 544 137 317 544 144 317 minecraft:brown_terracotta
setblock 545 137 275 minecraft:white_concrete
setblock 545 137 317 minecraft:white_concrete
fill 546 137 275 546 144 275 minecraft:brown_terracotta
fill 546 137 317 546 144 317 minecraft:brown_terracotta
fill 548 137 275 548 144 275 minecraft:brown_terracotta
fill 548 137 317 548 144 317 minecraft:brown_terracotta
setblock 549 137 275 minecraft:white_concrete
setblock 549 137 317 minecraft:white_concrete
fill 550 137 275 550 144 275 minecraft:brown_terracotta
fill 550 137 317 550 144 317 minecraft:brown_terracotta
fill 552 137 275 552 144 275 minecraft:brown_terracotta
fill 552 137 317 552 144 317 minecraft:brown_terracotta
setblock 553 137 275 minecraft:white_concrete
setblock 553 137 317 minecraft:white_concrete
fill 554 137 275 554 144 275 minecraft:brown_terracotta
fill 554 137 317 554 144 317 minecraft:brown_terracotta
fill 556 137 275 556 144 275 minecraft:brown_terracotta
fill 556 137 317 556 144 317 minecraft:brown_terracotta
setblock 557 137 275 minecraft:white_concrete
setblock 557 137 317 minecraft:white_concrete
fill 558 137 275 558 144 275 minecraft:brown_terracotta
fill 558 137 317 558 144 317 minecraft:brown_terracotta
setblock 559 137 275 minecraft:white_concrete
fill 559 137 276 559 144 276 minecraft:brown_terracotta
fill 559 137 278 559 144 278 minecraft:brown_terracotta
setblock 559 137 279 minecraft:white_concrete
fill 559 137 280 559 144 280 minecraft:brown_terracotta
fill 559 137 282 559 144 282 minecraft:brown_terracotta
setblock 559 137 283 minecraft:white_concrete
fill 559 137 284 559 144 284 minecraft:brown_terracotta
fill 559 137 286 559 144 286 minecraft:brown_terracotta
setblock 559 137 287 minecraft:white_concrete
fill 559 137 288 559 144 288 minecraft:brown_terracotta
fill 559 137 290 559 144 290 minecraft:brown_terracotta
setblock 559 137 291 minecraft:white_concrete
fill 559 137 292 559 144 292 minecraft:brown_terracotta
fill 559 137 294 559 144 294 minecraft:brown_terracotta
setblock 559 137 295 minecraft:white_concrete
fill 559 137 296 559 144 296 minecraft:brown_terracotta
fill 559 137 298 559 144 298 minecraft:brown_terracotta
setblock 559 137 299 minecraft:white_concrete
fill 559 137 300 559 144 300 minecraft:brown_terracotta
fill 559 137 302 559 144 302 minecraft:brown_terracotta
setblock 559 137 303 minecraft:white_concrete
fill 559 137 304 559 144 304 minecraft:brown_terracotta
fill 559 137 306 559 144 306 minecraft:brown_terracotta
setblock 559 137 307 minecraft:white_concrete
fill 559 137 308 559 144 308 minecraft:brown_terracotta
fill 559 137 310 559 144 310 minecraft:brown_terracotta
setblock 559 137 311 minecraft:white_concrete
fill 559 137 312 559 144 312 minecraft:brown_terracotta
fill 559 137 314 559 144 314 minecraft:brown_terracotta
setblock 559 137 315 minecraft:white_concrete
fill 559 137 316 559 144 316 minecraft:brown_terracotta
fill 517 138 275 517 145 275 minecraft:brown_terracotta
fill 517 138 279 517 145 279 minecraft:brown_terracotta
fill 517 138 283 517 145 283 minecraft:brown_terracotta
fill 517 138 287 517 145 287 minecraft:brown_terracotta
fill 517 138 291 517 145 291 minecraft:brown_terracotta
fill 517 138 295 517 145 295 minecraft:brown_terracotta
fill 517 138 299 517 145 299 minecraft:brown_terracotta
fill 517 138 303 517 145 303 minecraft:brown_terracotta
fill 517 138 307 517 145 307 minecraft:brown_terracotta
fill 517 138 311 517 145 311 minecraft:brown_terracotta
fill 517 138 315 517 145 315 minecraft:brown_terracotta
fill 517 138 317 517 143 317 minecraft:brown_terracotta
fill 521 138 275 521 145 275 minecraft:brown_terracotta
fill 521 138 299 521 139 299 minecraft:lime_concrete
fill 521 138 317 521 145 317 minecraft:brown_terracotta
fill 525 138 275 525 145 275 minecraft:brown_terracotta
fill 525 138 317 525 145 317 minecraft:brown_terracotta
fill 529 138 275 529 145 275 minecraft:brown_terracotta
fill 529 138 317 529 145 317 minecraft:brown_terracotta
fill 533 138 275 533 145 275 minecraft:brown_terracotta
fill 533 138 317 533 145 317 minecraft:brown_terracotta
fill 537 138 275 537 145 275 minecraft:brown_terracotta
fill 537 138 317 537 145 317 minecraft:brown_terracotta
fill 539 138 310 545 138 315 minecraft:white_concrete
fill 541 138 275 541 145 275 minecraft:brown_terracotta
fill 541 138 317 541 145 317 minecraft:brown_terracotta
fill 544 138 283 544 139 283 minecraft:white_concrete
fill 545 138 275 545 145 275 minecraft:brown_terracotta
fill 545 138 317 545 145 317 minecraft:brown_terracotta
fill 549 138 275 549 145 275 minecraft:brown_terracotta
fill 549 138 317 549 145 317 minecraft:brown_terracotta
fill 553 138 275 553 145 275 minecraft:brown_terracotta
fill 553 138 317 553 145 317 minecraft:brown_terracotta
fill 557 138 275 557 145 275 minecraft:brown_terracotta
fill 557 138 317 557 145 317 minecraft:brown_terracotta
fill 559 138 275 559 143 275 minecraft:brown_terracotta
fill 559 138 279 559 145 279 minecraft:brown_terracotta
fill 559 138 283 559 145 283 minecraft:brown_terracotta
fill 559 138 287 559 145 287 minecraft:brown_terracotta
fill 559 138 291 559 145 291 minecraft:brown_terracotta
fill 559 138 295 559 145 295 minecraft:brown_terracotta
fill 559 138 299 559 145 299 minecraft:brown_terracotta
fill 559 138 303 559 145 303 minecraft:brown_terracotta
fill 559 138 307 559 145 307 minecraft:brown_terracotta
fill 559 138 311 559 145 311 minecraft:brown_terracotta
fill 559 138 315 559 145 315 minecraft:brown_terracotta
setblock 520 139 278 minecraft:light[level=15]
setblock 520 139 286 minecraft:light[level=15]
setblock 520 139 294 minecraft:light[level=15]
setblock 520 139 302 minecraft:light[level=15]
setblock 520 139 310 minecraft:light[level=15]
setblock 528 139 278 minecraft:light[level=15]
setblock 528 139 286 minecraft:light[level=15]
setblock 528 139 294 minecraft:light[level=15]
setblock 528 139 302 minecraft:light[level=15]
setblock 528 139 310 minecraft:light[level=15]
setblock 536 139 278 minecraft:light[level=15]
setblock 536 139 286 minecraft:light[level=15]
setblock 536 139 294 minecraft:light[level=15]
setblock 536 139 302 minecraft:light[level=15]
setblock 536 139 310 minecraft:light[level=15]
fill 539 139 310 545 139 310 minecraft:red_concrete
fill 541 139 316 543 142 316 minecraft:shroomlight
setblock 544 139 278 minecraft:light[level=15]
setblock 544 139 286 minecraft:light[level=15]
setblock 544 139 294 minecraft:light[level=15]
setblock 544 139 302 minecraft:light[level=15]
setblock 552 139 278 minecraft:light[level=15]
setblock 552 139 286 minecraft:light[level=15]
setblock 552 139 294 minecraft:light[level=15]
setblock 552 139 302 minecraft:light[level=15]
setblock 552 139 310 minecraft:light[level=15]
fill 519 140 285 519 145 287 minecraft:white_concrete
fill 519 140 297 519 145 299 minecraft:white_concrete
fill 519 140 309 519 145 311 minecraft:white_concrete
fill 525 140 315 527 145 315 minecraft:white_concrete
fill 529 140 277 531 145 277 minecraft:white_concrete
fill 537 140 315 539 145 315 minecraft:white_concrete
setblock 539 140 310 minecraft:white_concrete
fill 541 140 277 543 145 277 minecraft:white_concrete
setblock 542 140 310 minecraft:white_concrete
setblock 545 140 310 minecraft:white_concrete
fill 549 140 315 551 145 315 minecraft:white_concrete
fill 550 140 285 551 141 285 minecraft:lime_concrete
fill 553 140 277 555 145 277 minecraft:white_concrete
fill 557 140 285 557 145 287 minecraft:white_concrete
fill 557 140 297 557 145 299 minecraft:white_concrete
fill 557 140 309 557 145 311 minecraft:white_concrete
setblock 520 141 278 minecraft:light[level=12]
setblock 520 141 285 minecraft:light[level=12]
setblock 520 141 292 minecraft:light[level=12]
setblock 520 141 299 minecraft:light[level=12]
setblock 520 141 306 minecraft:light[level=12]
setblock 520 141 313 minecraft:light[level=12]
setblock 527 141 278 minecraft:light[level=12]
setblock 527 141 285 minecraft:light[level=12]
setblock 527 141 292 minecraft:light[level=12]
setblock 527 141 299 minecraft:light[level=12]
setblock 527 141 306 minecraft:light[level=12]
setblock 527 141 313 minecraft:light[level=12]
setblock 534 141 278 minecraft:light[level=12]
setblock 534 141 285 minecraft:light[level=12]
setblock 534 141 292 minecraft:light[level=12]
setblock 534 141 299 minecraft:light[level=12]
setblock 534 141 306 minecraft:light[level=12]
setblock 534 141 313 minecraft:light[level=12]
setblock 541 141 278 minecraft:light[level=12]
setblock 541 141 285 minecraft:light[level=12]
setblock 541 141 292 minecraft:light[level=12]
setblock 541 141 299 minecraft:light[level=12]
setblock 541 141 306 minecraft:light[level=12]
setblock 541 141 313 minecraft:light[level=12]
setblock 548 141 278 minecraft:light[level=12]
setblock 548 141 285 minecraft:light[level=12]
setblock 548 141 292 minecraft:light[level=12]
setblock 548 141 299 minecraft:light[level=12]
setblock 548 141 306 minecraft:light[level=12]
setblock 548 141 313 minecraft:light[level=12]
setblock 555 141 278 minecraft:light[level=12]
setblock 555 141 285 minecraft:light[level=12]
setblock 555 141 292 minecraft:light[level=12]
setblock 555 141 299 minecraft:light[level=12]
setblock 555 141 306 minecraft:light[level=12]
setblock 555 141 313 minecraft:light[level=12]
fill 529 142 305 529 143 305 minecraft:white_concrete
fill 543 142 279 543 143 280 minecraft:white_concrete
fill 532 143 290 532 144 290 minecraft:red_concrete
setblock 517 144 277 minecraft:white_concrete
setblock 517 144 281 minecraft:white_concrete
setblock 517 144 285 minecraft:white_concrete
setblock 517 144 289 minecraft:white_concrete
setblock 517 144 293 minecraft:white_concrete
setblock 517 144 297 minecraft:white_concrete
setblock 517 144 301 minecraft:white_concrete
setblock 517 144 305 minecraft:white_concrete
setblock 517 144 309 minecraft:white_concrete
setblock 517 144 313 minecraft:white_concrete
setblock 517 144 317 minecraft:white_concrete
setblock 519 144 275 minecraft:white_concrete
setblock 519 144 317 minecraft:white_concrete
setblock 523 144 275 minecraft:white_concrete
setblock 523 144 317 minecraft:white_concrete
setblock 527 144 275 minecraft:white_concrete
setblock 527 144 317 minecraft:white_concrete
setblock 531 144 275 minecraft:white_concrete
setblock 531 144 317 minecraft:white_concrete
setblock 535 144 275 minecraft:white_concrete
setblock 535 144 317 minecraft:white_concrete
setblock 539 144 275 minecraft:white_concrete
setblock 539 144 317 minecraft:white_concrete
setblock 543 144 275 minecraft:white_concrete
setblock 543 144 317 minecraft:white_concrete
setblock 547 144 275 minecraft:white_concrete
setblock 547 144 317 minecraft:white_concrete
setblock 551 144 275 minecraft:white_concrete
setblock 551 144 317 minecraft:white_concrete
setblock 555 144 275 minecraft:white_concrete
setblock 555 144 317 minecraft:white_concrete
setblock 559 144 275 minecraft:white_concrete
setblock 559 144 277 minecraft:white_concrete
setblock 559 144 281 minecraft:white_concrete
setblock 559 144 285 minecraft:white_concrete
setblock 559 144 289 minecraft:white_concrete
setblock 559 144 293 minecraft:white_concrete
setblock 559 144 297 minecraft:white_concrete
setblock 559 144 301 minecraft:white_concrete
setblock 559 144 305 minecraft:white_concrete
setblock 559 144 309 minecraft:white_concrete
setblock 559 144 313 minecraft:white_concrete
setblock 559 144 317 minecraft:white_concrete
setblock 517 145 276 minecraft:white_concrete
fill 517 145 277 517 152 277 minecraft:brown_terracotta
setblock 517 145 278 minecraft:white_concrete
setblock 517 145 280 minecraft:white_concrete
fill 517 145 281 518 145 281 minecraft:brown_terracotta
setblock 517 145 282 minecraft:white_concrete
setblock 517 145 284 minecraft:white_concrete
fill 517 145 285 517 152 285 minecraft:brown_terracotta
setblock 517 145 286 minecraft:white_concrete
setblock 517 145 288 minecraft:white_concrete
fill 517 145 289 517 152 289 minecraft:brown_terracotta
setblock 517 145 290 minecraft:white_concrete
setblock 517 145 292 minecraft:white_concrete
fill 517 145 293 518 145 293 minecraft:brown_terracotta
setblock 517 145 294 minecraft:white_concrete
setblock 517 145 296 minecraft:white_concrete
fill 517 145 297 517 152 297 minecraft:brown_terracotta
setblock 517 145 298 minecraft:white_concrete
setblock 517 145 300 minecraft:white_concrete
fill 517 145 301 517 152 301 minecraft:brown_terracotta
setblock 517 145 302 minecraft:white_concrete
setblock 517 145 304 minecraft:white_concrete
fill 517 145 305 518 145 305 minecraft:brown_terracotta
setblock 517 145 306 minecraft:white_concrete
setblock 517 145 308 minecraft:white_concrete
fill 517 145 309 517 152 309 minecraft:brown_terracotta
setblock 517 145 310 minecraft:white_concrete
setblock 517 145 312 minecraft:white_concrete
fill 517 145 313 517 152 313 minecraft:brown_terracotta
setblock 517 145 314 minecraft:white_concrete
setblock 517 145 316 minecraft:white_concrete
setblock 517 145 317 minecraft:brown_terracotta
setblock 518 145 275 minecraft:white_concrete
fill 518 145 279 518 145 280 minecraft:brown_terracotta
fill 518 145 282 518 145 284 minecraft:brown_terracotta
fill 518 145 291 518 145 292 minecraft:brown_terracotta
fill 518 145 294 518 145 296 minecraft:brown_terracotta
fill 518 145 303 518 145 304 minecraft:brown_terracotta
fill 518 145 306 518 145 308 minecraft:brown_terracotta
fill 518 145 315 518 145 316 minecraft:brown_terracotta
setblock 518 145 317 minecraft:white_concrete
fill 519 145 275 519 152 275 minecraft:brown_terracotta
fill 519 145 316 519 145 317 minecraft:brown_terracotta
setblock 520 145 275 minecraft:white_concrete
fill 520 145 316 522 145 316 minecraft:brown_terracotta
setblock 520 145 317 minecraft:white_concrete
fill 521 145 305 521 146 305 minecraft:brown_terracotta
setblock 522 145 275 minecraft:white_concrete
fill 522 145 276 527 145 276 minecraft:brown_terracotta
setblock 522 145 317 minecraft:white_concrete
fill 523 145 275 523 152 275 minecraft:brown_terracotta
fill 523 145 317 523 152 317 minecraft:brown_terracotta
setblock 524 145 275 minecraft:white_concrete
fill 524 145 312 524 146 312 minecraft:brown_terracotta
setblock 524 145 317 minecraft:white_concrete
setblock 526 145 275 minecraft:white_concrete
setblock 526 145 317 minecraft:white_concrete
setblock 527 145 275 minecraft:brown_terracotta
fill 527 145 317 527 152 317 minecraft:brown_terracotta
setblock 528 145 275 minecraft:white_concrete
setblock 528 145 317 minecraft:white_concrete
fill 529 145 316 534 145 316 minecraft:brown_terracotta
setblock 530 145 275 minecraft:white_concrete
setblock 530 145 317 minecraft:white_concrete
fill 531 145 275 531 152 275 minecraft:brown_terracotta
setblock 531 145 317 minecraft:brown_terracotta
setblock 532 145 275 minecraft:white_concrete
setblock 532 145 317 minecraft:white_concrete
fill 533 145 279 533 146 279 minecraft:brown_terracotta
setblock 534 145 275 minecraft:white_concrete
fill 534 145 276 539 145 276 minecraft:brown_terracotta
setblock 534 145 317 minecraft:white_concrete
fill 535 145 275 535 152 275 minecraft:brown_terracotta
fill 535 145 317 535 152 317 minecraft:brown_terracotta
setblock 536 145 275 minecraft:white_concrete
setblock 536 145 317 minecraft:white_concrete
setblock 538 145 275 minecraft:white_concrete
setblock 538 145 317 minecraft:white_concrete
setblock 539 145 275 minecraft:brown_terracotta
fill 539 145 317 539 152 317 minecraft:brown_terracotta
setblock 540 145 275 minecraft:white_concrete
fill 540 145 312 540 146 312 minecraft:brown_terracotta
setblock 540 145 317 minecraft:white_concrete
fill 541 145 316 546 145 316 minecraft:brown_terracotta
setblock 542 145 275 minecraft:white_concrete
setblock 542 145 317 minecraft:white_concrete
fill 543 145 275 543 152 275 minecraft:brown_terracotta
setblock 543 145 317 minecraft:brown_terracotta
setblock 544 145 275 minecraft:white_concrete
setblock 544 145 317 minecraft:white_concrete
fill 545 145 279 545 146 279 minecraft:brown_terracotta
setblock 546 145 275 minecraft:white_concrete
fill 546 145 276 551 145 276 minecraft:brown_terracotta
setblock 546 145 317 minecraft:white_concrete
fill 547 145 275 547 152 275 minecraft:brown_terracotta
fill 547 145 317 547 152 317 minecraft:brown_terracotta
setblock 548 145 275 minecraft:white_concrete
setblock 548 145 317 minecraft:white_concrete
setblock 550 145 275 minecraft:white_concrete
setblock 550 145 317 minecraft:white_concrete
setblock 551 145 275 minecraft:brown_terracotta
fill 551 145 317 551 152 317 minecraft:brown_terracotta
setblock 552 145 275 minecraft:white_concrete
setblock 552 145 317 minecraft:white_concrete
fill 553 145 312 553 146 312 minecraft:brown_terracotta
fill 553 145 316 558 145 316 minecraft:brown_terracotta
setblock 554 145 275 minecraft:white_concrete
fill 554 145 302 554 146 302 minecraft:brown_terracotta
fill 554 145 313 554 146 313 minecraft:brown_terracotta
setblock 554 145 317 minecraft:white_concrete
fill 555 145 275 555 152 275 minecraft:brown_terracotta
setblock 555 145 317 minecraft:brown_terracotta
setblock 556 145 275 minecraft:white_concrete
setblock 556 145 317 minecraft:white_concrete
setblock 558 145 275 minecraft:white_concrete
fill 558 145 276 558 145 281 minecraft:brown_terracotta
fill 558 145 288 558 145 293 minecraft:brown_terracotta
fill 558 145 300 558 145 305 minecraft:brown_terracotta
fill 558 145 312 558 145 315 minecraft:brown_terracotta
setblock 558 145 317 minecraft:white_concrete
setblock 559 145 275 minecraft:brown_terracotta
setblock 559 145 276 minecraft:white_concrete
setblock 559 145 277 minecraft:brown_terracotta
setblock 559 145 278 minecraft:white_concrete
setblock 559 145 280 minecraft:white_concrete
fill 559 145 281 559 152 281 minecraft:brown_terracotta
setblock 559 145 282 minecraft:white_concrete
setblock 559 145 284 minecraft:white_concrete
fill 559 145 285 559 152 285 minecraft:brown_terracotta
setblock 559 145 286 minecraft:white_concrete
setblock 559 145 288 minecraft:white_concrete
setblock 559 145 289 minecraft:brown_terracotta
setblock 559 145 290 minecraft:white_concrete
setblock 559 145 292 minecraft:white_concrete
fill 559 145 293 559 152 293 minecraft:brown_terracotta
setblock 559 145 294 minecraft:white_concrete
setblock 559 145 296 minecraft:white_concrete
fill 559 145 297 559 152 297 minecraft:brown_terracotta
setblock 559 145 298 minecraft:white_concrete
setblock 559 145 300 minecraft:white_concrete
setblock 559 145 301 minecraft:brown_terracotta
setblock 559 145 302 minecraft:white_concrete
setblock 559 145 304 minecraft:white_concrete
fill 559 145 305 559 152 305 minecraft:brown_terracotta
setblock 559 145 306 minecraft:white_concrete
setblock 559 145 308 minecraft:white_concrete
fill 559 145 309 559 152 309 minecraft:brown_terracotta
setblock 559 145 310 minecraft:white_concrete
setblock 559 145 312 minecraft:white_concrete
setblock 559 145 313 minecraft:brown_terracotta
setblock 559 145 314 minecraft:white_concrete
setblock 559 145 316 minecraft:white_concrete
fill 559 145 317 559 152 317 minecraft:brown_terracotta
setblock 517 146 275 minecraft:white_concrete
fill 517 146 276 517 153 276 minecraft:brown_terracotta
fill 517 146 278 517 153 278 minecraft:brown_terracotta
setblock 517 146 279 minecraft:white_concrete
fill 517 146 280 517 153 280 minecraft:brown_terracotta
fill 517 146 281 517 151 284 minecraft:shroomlight
fill 517 146 286 517 153 286 minecraft:brown_terracotta
setblock 517 146 287 minecraft:white_concrete
fill 517 146 288 517 153 288 minecraft:brown_terracotta
fill 517 146 290 517 153 290 minecraft:brown_terracotta
setblock 517 146 291 minecraft:white_concrete
fill 517 146 292 517 153 292 minecraft:brown_terracotta
fill 517 146 293 517 151 296 minecraft:shroomlight
fill 517 146 298 517 153 298 minecraft:brown_terracotta
setblock 517 146 299 minecraft:white_concrete
fill 517 146 300 517 153 300 minecraft:brown_terracotta
fill 517 146 302 517 153 302 minecraft:brown_terracotta
setblock 517 146 303 minecraft:white_concrete
fill 517 146 304 517 153 304 minecraft:brown_terracotta
fill 517 146 305 517 151 308 minecraft:shroomlight
fill 517 146 310 517 153 310 minecraft:brown_terracotta
setblock 517 146 311 minecraft:white_concrete
fill 517 146 312 517 153 312 minecraft:brown_terracotta
fill 517 146 314 517 153 314 minecraft:brown_terracotta
setblock 517 146 315 minecraft:white_concrete
fill 517 146 316 517 153 316 minecraft:brown_terracotta
fill 517 146 317 520 151 317 minecraft:shroomlight
fill 518 146 275 518 153 275 minecraft:brown_terracotta
fill 520 146 275 520 153 275 minecraft:brown_terracotta
fill 520 146 305 520 147 305 minecraft:brown_terracotta
setblock 521 146 275 minecraft:white_concrete
setblock 521 146 317 minecraft:white_concrete
fill 522 146 275 522 153 275 minecraft:brown_terracotta
fill 522 146 317 522 153 317 minecraft:brown_terracotta
fill 524 146 275 527 151 275 minecraft:shroomlight
fill 524 146 313 524 147 313 minecraft:brown_terracotta
fill 524 146 317 524 153 317 minecraft:brown_terracotta
setblock 525 146 317 minecraft:white_concrete
fill 526 146 317 526 153 317 minecraft:brown_terracotta
fill 528 146 275 528 153 275 minecraft:brown_terracotta
fill 528 146 317 528 153 317 minecraft:brown_terracotta
setblock 529 146 275 minecraft:white_concrete
fill 529 146 317 532 151 317 minecraft:shroomlight
fill 530 146 275 530 153 275 minecraft:brown_terracotta
fill 532 146 275 532 153 275 minecraft:brown_terracotta
setblock 533 146 275 minecraft:white_concrete
fill 533 146 278 533 147 278 minecraft:brown_terracotta
setblock 533 146 317 minecraft:white_concrete
fill 534 146 275 534 153 275 minecraft:brown_terracotta
fill 534 146 317 534 153 317 minecraft:brown_terracotta
fill 536 146 275 539 151 275 minecraft:shroomlight
fill 536 146 317 536 153 317 minecraft:brown_terracotta
setblock 537 146 317 minecraft:white_concrete
fill 538 146 317 538 153 317 minecraft:brown_terracotta
fill 540 146 275 540 153 275 minecraft:brown_terracotta
fill 540 146 313 540 147 313 minecraft:brown_terracotta
fill 540 146 317 540 153 317 minecraft:brown_terracotta
setblock 541 146 275 minecraft:white_concrete
fill 541 146 317 544 151 317 minecraft:shroomlight
fill 542 146 275 542 153 275 minecraft:brown_terracotta
fill 544 146 275 544 153 275 minecraft:brown_terracotta
setblock 545 146 275 minecraft:white_concrete
fill 545 146 278 545 147 278 minecraft:brown_terracotta
setblock 545 146 317 minecraft:white_concrete
fill 546 146 275 546 153 275 minecraft:brown_terracotta
fill 546 146 317 546 153 317 minecraft:brown_terracotta
fill 548 146 275 551 151 275 minecraft:shroomlight
fill 548 146 317 548 153 317 minecraft:brown_terracotta
setblock 549 146 317 minecraft:white_concrete
fill 550 146 317 550 153 317 minecraft:brown_terracotta
fill 552 146 275 552 153 275 minecraft:brown_terracotta
fill 552 146 317 552 153 317 minecraft:brown_terracotta
setblock 553 146 275 minecraft:white_concrete
fill 553 146 313 553 147 313 minecraft:brown_terracotta
fill 553 146 317 556 151 317 minecraft:shroomlight
fill 554 146 275 554 153 275 minecraft:brown_terracotta
fill 555 146 302 555 147 302 minecraft:brown_terracotta
fill 555 146 313 555 147 313 minecraft:brown_terracotta
fill 556 146 275 556 153 275 minecraft:brown_terracotta
setblock 557 146 275 minecraft:white_concrete
setblock 557 146 317 minecraft:white_concrete
fill 558 146 275 558 153 275 minecraft:brown_terracotta
fill 558 146 317 558 153 317 minecraft:brown_terracotta
setblock 559 146 275 minecraft:white_concrete
fill 559 146 276 559 151 279 minecraft:shroomlight
fill 559 146 280 559 153 280 minecraft:brown_terracotta
fill 559 146 282 559 153 282 minecraft:brown_terracotta
setblock 559 146 283 minecraft:white_concrete
fill 559 146 284 559 153 284 minecraft:brown_terracotta
fill 559 146 286 559 153 286 minecraft:brown_terracotta
setblock 559 146 287 minecraft:white_concrete
fill 559 146 288 559 151 291 minecraft:shroomlight
fill 559 146 292 559 153 292 minecraft:brown_terracotta
fill 559 146 294 559 153 294 minecraft:brown_terracotta
setblock 559 146 295 minecraft:white_concrete
fill 559 146 296 559 153 296 minecraft:brown_terracotta
fill 559 146 298 559 153 298 minecraft:brown_terracotta
setblock 559 146 299 minecraft:white_concrete
fill 559 146 300 559 151 303 minecraft:shroomlight
fill 559 146 304 559 153 304 minecraft:brown_terracotta
fill 559 146 306 559 153 306 minecraft:brown_terracotta
setblock 559 146 307 minecraft:white_concrete
fill 559 146 308 559 153 308 minecraft:brown_terracotta
fill 559 146 310 559 153 310 minecraft:brown_terracotta
setblock 559 146 311 minecraft:white_concrete
fill 559 146 312 559 151 315 minecraft:shroomlight
fill 559 146 316 559 153 316 minecraft:brown_terracotta
fill 517 147 275 517 154 275 minecraft:brown_terracotta
fill 517 147 279 517 154 279 minecraft:brown_terracotta
fill 517 147 287 517 154 287 minecraft:brown_terracotta
fill 517 147 291 517 154 291 minecraft:brown_terracotta
fill 517 147 299 517 154 299 minecraft:brown_terracotta
fill 517 147 303 517 154 303 minecraft:brown_terracotta
fill 517 147 311 517 154 311 minecraft:brown_terracotta
fill 517 147 315 517 154 315 minecraft:brown_terracotta
fill 519 147 305 519 148 305 minecraft:brown_terracotta
setblock 520 147 278 minecraft:light[level=15]
setblock 520 147 285 minecraft:light[level=12]
setblock 520 147 286 minecraft:light[level=15]
setblock 520 147 292 minecraft:light[level=12]
setblock 520 147 294 minecraft:light[level=15]
setblock 520 147 299 minecraft:light[level=12]
setblock 520 147 302 minecraft:light[level=15]
setblock 520 147 306 minecraft:light[level=12]
setblock 520 147 310 minecraft:light[level=15]
setblock 520 147 313 minecraft:light[level=12]
fill 521 147 275 521 154 275 minecraft:brown_terracotta
fill 521 147 317 521 154 317 minecraft:brown_terracotta
fill 524 147 314 524 148 314 minecraft:brown_terracotta
fill 525 147 317 525 154 317 minecraft:brown_terracotta
setblock 527 147 278 minecraft:light[level=12]
setblock 527 147 285 minecraft:light[level=12]
setblock 527 147 292 minecraft:light[level=12]
setblock 527 147 299 minecraft:light[level=12]
setblock 527 147 306 minecraft:light[level=12]
setblock 527 147 313 minecraft:light[level=12]
setblock 528 147 278 minecraft:light[level=15]
setblock 528 147 286 minecraft:light[level=15]
setblock 528 147 294 minecraft:light[level=15]
setblock 528 147 302 minecraft:light[level=15]
setblock 528 147 310 minecraft:light[level=15]
fill 529 147 275 529 154 275 minecraft:brown_terracotta
fill 533 147 275 533 154 275 minecraft:brown_terracotta
fill 533 147 277 533 148 277 minecraft:brown_terracotta
fill 533 147 317 533 154 317 minecraft:brown_terracotta
setblock 534 147 278 minecraft:light[level=12]
setblock 534 147 285 minecraft:light[level=12]
setblock 534 147 292 minecraft:light[level=12]
setblock 534 147 299 minecraft:light[level=12]
setblock 534 147 306 minecraft:light[level=12]
setblock 534 147 313 minecraft:light[level=12]
setblock 536 147 278 minecraft:light[level=15]
setblock 536 147 286 minecraft:light[level=15]
setblock 536 147 294 minecraft:light[level=15]
setblock 536 147 302 minecraft:light[level=15]
setblock 536 147 310 minecraft:light[level=15]
fill 537 147 317 537 154 317 minecraft:brown_terracotta
fill 540 147 314 540 148 314 minecraft:brown_terracotta
fill 541 147 275 541 154 275 minecraft:brown_terracotta
setblock 541 147 278 minecraft:light[level=12]
setblock 541 147 285 minecraft:light[level=12]
setblock 541 147 292 minecraft:light[level=12]
setblock 541 147 299 minecraft:light[level=12]
setblock 541 147 306 minecraft:light[level=12]
setblock 541 147 313 minecraft:light[level=12]
setblock 544 147 278 minecraft:light[level=15]
setblock 544 147 286 minecraft:light[level=15]
setblock 544 147 294 minecraft:light[level=15]
setblock 544 147 302 minecraft:light[level=15]
setblock 544 147 310 minecraft:light[level=15]
fill 545 147 275 545 154 275 minecraft:brown_terracotta
fill 545 147 277 545 148 277 minecraft:brown_terracotta
fill 545 147 317 545 154 317 minecraft:brown_terracotta
setblock 548 147 278 minecraft:light[level=12]
setblock 548 147 285 minecraft:light[level=12]
setblock 548 147 292 minecraft:light[level=12]
setblock 548 147 299 minecraft:light[level=12]
setblock 548 147 306 minecraft:light[level=12]
setblock 548 147 313 minecraft:light[level=12]
fill 549 147 317 549 154 317 minecraft:brown_terracotta
setblock 552 147 278 minecraft:light[level=15]
setblock 552 147 286 minecraft:light[level=15]
setblock 552 147 294 minecraft:light[level=15]
setblock 552 147 302 minecraft:light[level=15]
setblock 552 147 310 minecraft:light[level=15]
fill 553 147 275 553 154 275 minecraft:brown_terracotta
fill 553 147 314 553 148 314 minecraft:brown_terracotta
setblock 555 147 278 minecraft:light[level=12]
setblock 555 147 285 minecraft:light[level=12]
setblock 555 147 292 minecraft:light[level=12]
setblock 555 147 299 minecraft:light[level=12]
setblock 555 147 306 minecraft:light[level=12]
fill 556 147 302 556 148 302 minecraft:brown_terracotta
fill 556 147 313 556 148 313 minecraft:brown_terracotta
fill 557 147 275 557 154 275 minecraft:brown_terracotta
fill 557 147 317 557 154 317 minecraft:brown_terracotta
fill 559 147 275 559 152 275 minecraft:brown_terracotta
fill 559 147 283 559 154 283 minecraft:brown_terracotta
fill 559 147 287 559 154 287 minecraft:brown_terracotta
fill 559 147 295 559 154 295 minecraft:brown_terracotta
fill 559 147 299 559 154 299 minecraft:brown_terracotta
fill 559 147 307 559 154 307 minecraft:brown_terracotta
fill 559 147 311 559 154 311 minecraft:brown_terracotta
fill 518 148 305 518 149 305 minecraft:brown_terracotta
fill 524 148 315 524 149 315 minecraft:brown_terracotta
fill 533 148 276 533 149 276 minecraft:brown_terracotta
fill 540 148 315 540 149 315 minecraft:brown_terracotta
fill 545 148 276 545 149 276 minecraft:brown_terracotta
fill 553 148 315 553 149 315 minecraft:brown_terracotta
fill 557 148 302 557 149 302 minecraft:brown_terracotta
fill 557 148 313 557 149 313 minecraft:brown_terracotta
setblock 521 149 283 minecraft:shroomlight
setblock 521 149 289 minecraft:shroomlight
setblock 521 149 295 minecraft:shroomlight
setblock 521 149 301 minecraft:shroomlight
setblock 521 149 307 minecraft:shroomlight
setblock 521 149 313 minecraft:shroomlight
setblock 525 149 279 minecraft:shroomlight
setblock 527 149 313 minecraft:shroomlight
setblock 531 149 279 minecraft:shroomlight
setblock 533 149 313 minecraft:shroomlight
setblock 537 149 279 minecraft:shroomlight
setblock 539 149 313 minecraft:shroomlight
setblock 543 149 279 minecraft:shroomlight
setblock 545 149 313 minecraft:shroomlight
setblock 549 149 279 minecraft:shroomlight
setblock 551 149 313 minecraft:shroomlight
setblock 555 149 279 minecraft:shroomlight
setblock 555 149 285 minecraft:shroomlight
setblock 555 149 291 minecraft:shroomlight
setblock 555 149 297 minecraft:shroomlight
setblock 555 149 303 minecraft:shroomlight
setblock 555 149 309 minecraft:shroomlight
fill 556 149 279 556 149 285 minecraft:iron_block
fill 518 150 277 521 150 285 minecraft:white_concrete
fill 518 150 289 521 150 297 minecraft:white_concrete
fill 518 150 301 521 150 309 minecraft:white_concrete
fill 518 150 313 523 150 316 minecraft:white_concrete
fill 519 150 286 521 150 288 minecraft:white_concrete
fill 519 150 298 521 150 300 minecraft:white_concrete
fill 519 150 310 521 150 312 minecraft:white_concrete
fill 521 150 276 529 150 276 minecraft:white_concrete
fill 522 150 277 558 150 279 minecraft:white_concrete
fill 524 150 313 534 150 315 minecraft:white_concrete
fill 527 150 316 535 150 316 minecraft:white_concrete
fill 533 150 276 541 150 276 minecraft:white_concrete
fill 535 150 311 539 150 315 minecraft:orange_terracotta
fill 539 150 316 547 150 316 minecraft:white_concrete
fill 540 150 313 558 150 315 minecraft:white_concrete
fill 545 150 276 553 150 276 minecraft:white_concrete
fill 551 150 316 558 150 316 minecraft:white_concrete
fill 555 150 280 557 150 312 minecraft:white_concrete
fill 557 150 276 558 150 276 minecraft:white_concrete
fill 558 150 280 558 150 283 minecraft:white_concrete
fill 558 150 287 558 150 295 minecraft:white_concrete
fill 558 150 299 558 150 307 minecraft:white_concrete
fill 558 150 311 558 150 312 minecraft:white_concrete
fill 521 151 279 521 151 313 minecraft:red_concrete
fill 522 151 279 555 151 279 minecraft:red_concrete
fill 522 151 313 534 151 313 minecraft:red_concrete
fill 523 151 302 523 152 302 minecraft:white_concrete
fill 535 151 311 536 154 315 minecraft:orange_terracotta
fill 537 151 311 539 154 312 minecraft:orange_terracotta
fill 537 151 313 537 152 313 minecraft:ochre_froglight
fill 537 151 314 539 154 315 minecraft:orange_terracotta
fill 538 151 313 539 154 313 minecraft:orange_terracotta
fill 540 151 313 555 151 313 minecraft:red_concrete
fill 555 151 280 555 151 312 minecraft:red_concrete
setblock 517 152 281 minecraft:brown_terracotta
fill 517 152 282 517 152 283 minecraft:shroomlight
fill 517 152 284 517 153 284 minecraft:brown_terracotta
setblock 517 152 293 minecraft:brown_terracotta
fill 517 152 294 517 152 295 minecraft:shroomlight
fill 517 152 296 517 153 296 minecraft:brown_terracotta
setblock 517 152 305 minecraft:brown_terracotta
fill 517 152 306 517 152 307 minecraft:shroomlight
fill 517 152 308 517 153 308 minecraft:brown_terracotta
setblock 517 152 317 minecraft:brown_terracotta
fill 518 152 317 519 152 317 minecraft:shroomlight
fill 520 152 317 520 153 317 minecraft:brown_terracotta
fill 524 152 275 524 153 275 minecraft:brown_terracotta
fill 525 152 275 526 152 275 minecraft:shroomlight
setblock 527 152 275 minecraft:brown_terracotta
fill 529 152 317 529 154 317 minecraft:brown_terracotta
fill 530 152 317 531 152 317 minecraft:shroomlight
fill 532 152 317 532 153 317 minecraft:brown_terracotta
fill 536 152 275 536 153 275 minecraft:brown_terracotta
fill 537 152 275 538 152 275 minecraft:shroomlight
setblock 539 152 275 minecraft:brown_terracotta
fill 541 152 317 541 154 317 minecraft:brown_terracotta
fill 542 152 317 543 152 317 minecraft:shroomlight
fill 544 152 317 544 153 317 minecraft:brown_terracotta
fill 548 152 275 548 153 275 minecraft:brown_terracotta
fill 549 152 275 550 152 275 minecraft:shroomlight
setblock 551 152 275 minecraft:brown_terracotta
fill 553 152 317 553 154 317 minecraft:brown_terracotta
fill 554 152 317 555 152 317 minecraft:shroomlight
fill 556 152 317 556 153 317 minecraft:brown_terracotta
fill 559 152 276 559 153 276 minecraft:brown_terracotta
fill 559 152 277 559 152 278 minecraft:shroomlight
fill 559 152 279 559 154 279 minecraft:brown_terracotta
fill 559 152 288 559 153 288 minecraft:brown_terracotta
fill 559 152 289 559 152 290 minecraft:shroomlight
fill 559 152 291 559 154 291 minecraft:brown_terracotta
fill 559 152 300 559 153 300 minecraft:brown_terracotta
fill 559 152 301 559 152 302 minecraft:shroomlight
fill 559 152 303 559 154 303 minecraft:brown_terracotta
fill 559 152 312 559 153 312 minecraft:brown_terracotta
fill 559 152 313 559 152 314 minecraft:shroomlight
fill 559 152 315 559 154 315 minecraft:brown_terracotta
setblock 517 153 277 minecraft:white_concrete
setblock 517 153 281 minecraft:white_concrete
fill 517 153 282 517 153 283 minecraft:brown_terracotta
setblock 517 153 285 minecraft:white_concrete
setblock 517 153 289 minecraft:white_concrete
setblock 517 153 293 minecraft:white_concrete
fill 517 153 294 517 153 295 minecraft:brown_terracotta
setblock 517 153 297 minecraft:white_concrete
setblock 517 153 301 minecraft:white_concrete
setblock 517 153 305 minecraft:white_concrete
fill 517 153 306 517 153 307 minecraft:brown_terracotta
setblock 517 153 309 minecraft:white_concrete
setblock 517 153 313 minecraft:white_concrete
setblock 517 153 317 minecraft:white_concrete
setblock 518 153 317 minecraft:brown_terracotta
setblock 519 153 275 minecraft:white_concrete
setblock 519 153 317 minecraft:white_concrete
setblock 520 153 278 minecraft:light[level=12]
setblock 520 153 285 minecraft:light[level=12]
setblock 520 153 292 minecraft:light[level=12]
setblock 520 153 299 minecraft:light[level=12]
setblock 520 153 306 minecraft:light[level=12]
setblock 520 153 313 minecraft:light[level=12]
setblock 523 153 275 minecraft:white_concrete
setblock 523 153 317 minecraft:white_concrete
fill 525 153 275 526 153 275 minecraft:brown_terracotta
setblock 527 153 275 minecraft:white_concrete
setblock 527 153 278 minecraft:light[level=12]
setblock 527 153 285 minecraft:light[level=12]
setblock 527 153 292 minecraft:light[level=12]
setblock 527 153 299 minecraft:light[level=12]
setblock 527 153 306 minecraft:light[level=12]
setblock 527 153 313 minecraft:light[level=12]
setblock 527 153 317 minecraft:white_concrete
setblock 530 153 317 minecraft:brown_terracotta
setblock 531 153 275 minecraft:white_concrete
setblock 531 153 317 minecraft:white_concrete
setblock 534 153 278 minecraft:light[level=12]
setblock 534 153 285 minecraft:light[level=12]
setblock 534 153 292 minecraft:light[level=12]
setblock 534 153 299 minecraft:light[level=12]
setblock 534 153 306 minecraft:light[level=12]
setblock 534 153 313 minecraft:light[level=12]
setblock 535 153 275 minecraft:white_concrete
setblock 535 153 317 minecraft:white_concrete
fill 537 153 275 538 153 275 minecraft:brown_terracotta
fill 537 153 313 537 154 313 minecraft:orange_terracotta
setblock 539 153 275 minecraft:white_concrete
setblock 539 153 317 minecraft:white_concrete
setblock 541 153 278 minecraft:light[level=12]
setblock 541 153 285 minecraft:light[level=12]
setblock 541 153 292 minecraft:light[level=12]
setblock 541 153 299 minecraft:light[level=12]
setblock 541 153 306 minecraft:light[level=12]
setblock 541 153 313 minecraft:light[level=12]
setblock 542 153 317 minecraft:brown_terracotta
setblock 543 153 275 minecraft:white_concrete
setblock 543 153 317 minecraft:white_concrete
setblock 547 153 275 minecraft:white_concrete
setblock 547 153 317 minecraft:white_concrete
setblock 548 153 278 minecraft:light[level=12]
setblock 548 153 285 minecraft:light[level=12]
setblock 548 153 292 minecraft:light[level=12]
setblock 548 153 299 minecraft:light[level=12]
setblock 548 153 306 minecraft:light[level=12]
setblock 548 153 313 minecraft:light[level=12]
fill 549 153 275 550 153 275 minecraft:brown_terracotta
setblock 551 153 275 minecraft:white_concrete
setblock 551 153 317 minecraft:white_concrete
setblock 554 153 317 minecraft:brown_terracotta
setblock 555 153 275 minecraft:white_concrete
setblock 555 153 278 minecraft:light[level=12]
setblock 555 153 285 minecraft:light[level=12]
setblock 555 153 292 minecraft:light[level=12]
setblock 555 153 299 minecraft:light[level=12]
setblock 555 153 306 minecraft:light[level=12]
setblock 555 153 313 minecraft:light[level=12]
setblock 555 153 317 minecraft:white_concrete
setblock 559 153 275 minecraft:white_concrete
setblock 559 153 277 minecraft:white_concrete
setblock 559 153 278 minecraft:brown_terracotta
setblock 559 153 281 minecraft:white_concrete
setblock 559 153 285 minecraft:white_concrete
setblock 559 153 289 minecraft:white_concrete
setblock 559 153 290 minecraft:brown_terracotta
setblock 559 153 293 minecraft:white_concrete
setblock 559 153 297 minecraft:white_concrete
setblock 559 153 301 minecraft:white_concrete
setblock 559 153 302 minecraft:brown_terracotta
setblock 559 153 305 minecraft:white_concrete
setblock 559 153 309 minecraft:white_concrete
setblock 559 153 313 minecraft:white_concrete
setblock 559 153 314 minecraft:brown_terracotta
setblock 559 153 317 minecraft:white_concrete
setblock 517 154 276 minecraft:white_concrete
fill 517 154 277 517 161 277 minecraft:brown_terracotta
setblock 517 154 278 minecraft:white_concrete
setblock 517 154 280 minecraft:white_concrete
fill 517 154 281 517 161 281 minecraft:brown_terracotta
setblock 517 154 282 minecraft:white_concrete
setblock 517 154 283 minecraft:brown_terracotta
setblock 517 154 284 minecraft:white_concrete
fill 517 154 285 517 161 285 minecraft:brown_terracotta
setblock 517 154 286 minecraft:white_concrete
setblock 517 154 288 minecraft:white_concrete
fill 517 154 289 517 161 289 minecraft:brown_terracotta
setblock 517 154 290 minecraft:white_concrete
setblock 517 154 292 minecraft:white_concrete
fill 517 154 293 517 161 293 minecraft:brown_terracotta
setblock 517 154 294 minecraft:white_concrete
setblock 517 154 295 minecraft:brown_terracotta
setblock 517 154 296 minecraft:white_concrete
fill 517 154 297 517 161 297 minecraft:brown_terracotta
setblock 517 154 298 minecraft:white_concrete
setblock 517 154 300 minecraft:white_concrete
fill 517 154 301 517 161 301 minecraft:brown_terracotta
setblock 517 154 302 minecraft:white_concrete
setblock 517 154 304 minecraft:white_concrete
fill 517 154 305 517 161 305 minecraft:brown_terracotta
setblock 517 154 306 minecraft:white_concrete
setblock 517 154 307 minecraft:brown_terracotta
setblock 517 154 308 minecraft:white_concrete
fill 517 154 309 517 161 309 minecraft:brown_terracotta
setblock 517 154 310 minecraft:white_concrete
setblock 517 154 312 minecraft:white_concrete
fill 517 154 313 517 161 313 minecraft:brown_terracotta
setblock 517 154 314 minecraft:white_concrete
setblock 517 154 316 minecraft:white_concrete
setblock 517 154 317 minecraft:brown_terracotta
setblock 518 154 275 minecraft:white_concrete
setblock 518 154 317 minecraft:white_concrete
fill 519 154 275 519 161 275 minecraft:brown_terracotta
fill 519 154 317 519 161 317 minecraft:brown_terracotta
setblock 520 154 275 minecraft:white_concrete
setblock 520 154 317 minecraft:white_concrete
setblock 522 154 275 minecraft:white_concrete
setblock 522 154 317 minecraft:white_concrete
fill 523 154 275 523 161 275 minecraft:brown_terracotta
fill 523 154 317 523 161 317 minecraft:brown_terracotta
setblock 524 154 275 minecraft:white_concrete
setblock 524 154 317 minecraft:white_concrete
setblock 525 154 275 minecraft:brown_terracotta
setblock 526 154 275 minecraft:white_concrete
setblock 526 154 317 minecraft:white_concrete
fill 527 154 275 527 161 275 minecraft:brown_terracotta
fill 527 154 317 527 161 317 minecraft:brown_terracotta
setblock 528 154 275 minecraft:white_concrete
setblock 528 154 317 minecraft:white_concrete
setblock 530 154 275 minecraft:white_concrete
setblock 530 154 317 minecraft:white_concrete
fill 531 154 275 531 161 275 minecraft:brown_terracotta
fill 531 154 317 531 161 317 minecraft:brown_terracotta
setblock 532 154 275 minecraft:white_concrete
setblock 532 154 317 minecraft:white_concrete
setblock 534 154 275 minecraft:white_concrete
setblock 534 154 317 minecraft:white_concrete
fill 535 154 275 535 161 275 minecraft:brown_terracotta
fill 535 154 317 535 161 317 minecraft:brown_terracotta
setblock 536 154 275 minecraft:white_concrete
setblock 536 154 317 minecraft:white_concrete
setblock 537 154 275 minecraft:brown_terracotta
setblock 538 154 275 minecraft:white_concrete
setblock 538 154 317 minecraft:white_concrete
fill 539 154 275 539 161 275 minecraft:brown_terracotta
fill 539 154 317 539 161 317 minecraft:brown_terracotta
setblock 540 154 275 minecraft:white_concrete
setblock 540 154 317 minecraft:white_concrete
setblock 542 154 275 minecraft:white_concrete
setblock 542 154 317 minecraft:white_concrete
fill 543 154 275 543 161 275 minecraft:brown_terracotta
fill 543 154 317 543 161 317 minecraft:brown_terracotta
setblock 544 154 275 minecraft:white_concrete
setblock 544 154 317 minecraft:white_concrete
setblock 546 154 275 minecraft:white_concrete
setblock 546 154 317 minecraft:white_concrete
fill 547 154 275 547 161 275 minecraft:brown_terracotta
fill 547 154 317 547 161 317 minecraft:brown_terracotta
setblock 548 154 275 minecraft:white_concrete
setblock 548 154 317 minecraft:white_concrete
setblock 549 154 275 minecraft:brown_terracotta
setblock 550 154 275 minecraft:white_concrete
setblock 550 154 317 minecraft:white_concrete
fill 551 154 275 551 161 275 minecraft:brown_terracotta
fill 551 154 317 551 161 317 minecraft:brown_terracotta
setblock 552 154 275 minecraft:white_concrete
setblock 552 154 317 minecraft:white_concrete
setblock 554 154 275 minecraft:white_concrete
setblock 554 154 317 minecraft:white_concrete
fill 555 154 275 555 161 275 minecraft:brown_terracotta
fill 555 154 317 555 161 317 minecraft:brown_terracotta
setblock 556 154 275 minecraft:white_concrete
setblock 556 154 317 minecraft:white_concrete
setblock 558 154 275 minecraft:white_concrete
setblock 558 154 317 minecraft:white_concrete
setblock 559 154 275 minecraft:brown_terracotta
setblock 559 154 276 minecraft:white_concrete
fill 559 154 277 559 161 277 minecraft:brown_terracotta
setblock 559 154 278 minecraft:white_concrete
setblock 559 154 280 minecraft:white_concrete
fill 559 154 281 559 161 281 minecraft:brown_terracotta
setblock 559 154 282 minecraft:white_concrete
setblock 559 154 284 minecraft:white_concrete
fill 559 154 285 559 161 285 minecraft:brown_terracotta
setblock 559 154 286 minecraft:white_concrete
setblock 559 154 288 minecraft:white_concrete
fill 559 154 289 559 161 289 minecraft:brown_terracotta
setblock 559 154 290 minecraft:white_concrete
setblock 559 154 292 minecraft:white_concrete
fill 559 154 293 559 161 293 minecraft:brown_terracotta
setblock 559 154 294 minecraft:white_concrete
setblock 559 154 296 minecraft:white_concrete
fill 559 154 297 559 161 297 minecraft:brown_terracotta
setblock 559 154 298 minecraft:white_concrete
setblock 559 154 300 minecraft:white_concrete
fill 559 154 301 559 161 301 minecraft:brown_terracotta
setblock 559 154 302 minecraft:white_concrete
setblock 559 154 304 minecraft:white_concrete
fill 559 154 305 559 161 305 minecraft:brown_terracotta
setblock 559 154 306 minecraft:white_concrete
setblock 559 154 308 minecraft:white_concrete
fill 559 154 309 559 161 309 minecraft:brown_terracotta
setblock 559 154 310 minecraft:white_concrete
setblock 559 154 312 minecraft:white_concrete
fill 559 154 313 559 161 313 minecraft:brown_terracotta
setblock 559 154 314 minecraft:white_concrete
setblock 559 154 316 minecraft:white_concrete
fill 559 154 317 559 161 317 minecraft:brown_terracotta
setblock 517 155 275 minecraft:white_concrete
fill 517 155 276 517 162 276 minecraft:brown_terracotta
fill 517 155 278 517 162 278 minecraft:brown_terracotta
setblock 517 155 279 minecraft:white_concrete
fill 517 155 280 517 162 280 minecraft:brown_terracotta
fill 517 155 282 517 162 282 minecraft:brown_terracotta
setblock 517 155 283 minecraft:white_concrete
fill 517 155 284 517 162 284 minecraft:brown_terracotta
fill 517 155 286 517 162 286 minecraft:brown_terracotta
setblock 517 155 287 minecraft:white_concrete
fill 517 155 288 517 162 288 minecraft:brown_terracotta
fill 517 155 290 517 162 290 minecraft:brown_terracotta
setblock 517 155 291 minecraft:white_concrete
fill 517 155 292 517 162 292 minecraft:brown_terracotta
fill 517 155 294 517 162 294 minecraft:brown_terracotta
setblock 517 155 295 minecraft:white_concrete
fill 517 155 296 517 162 296 minecraft:brown_terracotta
fill 517 155 298 517 162 298 minecraft:brown_terracotta
setblock 517 155 299 minecraft:white_concrete
fill 517 155 300 517 162 300 minecraft:brown_terracotta
fill 517 155 302 517 162 302 minecraft:brown_terracotta
setblock 517 155 303 minecraft:white_concrete
fill 517 155 304 517 162 304 minecraft:brown_terracotta
fill 517 155 306 517 162 306 minecraft:brown_terracotta
setblock 517 155 307 minecraft:white_concrete
fill 517 155 308 517 162 308 minecraft:brown_terracotta
fill 517 155 310 517 162 310 minecraft:brown_terracotta
setblock 517 155 311 minecraft:white_concrete
fill 517 155 312 517 162 312 minecraft:brown_terracotta
fill 517 155 314 517 162 314 minecraft:brown_terracotta
setblock 517 155 315 minecraft:white_concrete
fill 517 155 316 517 162 316 minecraft:brown_terracotta
setblock 517 155 317 minecraft:white_concrete
fill 518 155 275 518 162 275 minecraft:brown_terracotta
fill 518 155 317 518 162 317 minecraft:brown_terracotta
fill 520 155 275 520 162 275 minecraft:brown_terracotta
setblock 520 155 278 minecraft:light[level=15]
setblock 520 155 286 minecraft:light[level=15]
setblock 520 155 294 minecraft:light[level=15]
setblock 520 155 302 minecraft:light[level=15]
setblock 520 155 310 minecraft:light[level=15]
fill 520 155 317 520 162 317 minecraft:brown_terracotta
setblock 521 155 275 minecraft:white_concrete
setblock 521 155 317 minecraft:white_concrete
fill 522 155 275 522 162 275 minecraft:brown_terracotta
fill 522 155 317 522 162 317 minecraft:brown_terracotta
fill 524 155 275 524 162 275 minecraft:brown_terracotta
fill 524 155 317 524 162 317 minecraft:brown_terracotta
setblock 525 155 275 minecraft:white_concrete
setblock 525 155 317 minecraft:white_concrete
fill 526 155 275 526 162 275 minecraft:brown_terracotta
fill 526 155 317 526 162 317 minecraft:brown_terracotta
fill 528 155 275 528 162 275 minecraft:brown_terracotta
setblock 528 155 278 minecraft:light[level=15]
setblock 528 155 286 minecraft:light[level=15]
setblock 528 155 294 minecraft:light[level=15]
setblock 528 155 302 minecraft:light[level=15]
setblock 528 155 310 minecraft:light[level=15]
fill 528 155 317 528 162 317 minecraft:brown_terracotta
setblock 529 155 275 minecraft:white_concrete
setblock 529 155 317 minecraft:white_concrete
fill 530 155 275 530 162 275 minecraft:brown_terracotta
fill 530 155 317 530 162 317 minecraft:brown_terracotta
fill 532 155 275 532 162 275 minecraft:brown_terracotta
fill 532 155 317 532 162 317 minecraft:brown_terracotta
setblock 533 155 275 minecraft:white_concrete
setblock 533 155 317 minecraft:white_concrete
fill 534 155 275 534 162 275 minecraft:brown_terracotta
fill 534 155 317 534 162 317 minecraft:brown_terracotta
fill 535 155 311 539 155 315 minecraft:white_concrete
fill 536 155 275 536 162 275 minecraft:brown_terracotta
setblock 536 155 278 minecraft:light[level=15]
setblock 536 155 286 minecraft:light[level=15]
setblock 536 155 294 minecraft:light[level=15]
setblock 536 155 302 minecraft:light[level=15]
setblock 536 155 310 minecraft:light[level=15]
fill 536 155 317 536 162 317 minecraft:brown_terracotta
setblock 537 155 275 minecraft:white_concrete
setblock 537 155 317 minecraft:white_concrete
fill 538 155 275 538 162 275 minecraft:brown_terracotta
fill 538 155 317 538 162 317 minecraft:brown_terracotta
fill 540 155 275 540 162 275 minecraft:brown_terracotta
fill 540 155 317 540 162 317 minecraft:brown_terracotta
setblock 541 155 275 minecraft:white_concrete
setblock 541 155 317 minecraft:white_concrete
fill 542 155 275 542 162 275 minecraft:brown_terracotta
fill 542 155 317 542 162 317 minecraft:brown_terracotta
fill 544 155 275 544 162 275 minecraft:brown_terracotta
setblock 544 155 278 minecraft:light[level=15]
setblock 544 155 286 minecraft:light[level=15]
setblock 544 155 294 minecraft:light[level=15]
setblock 544 155 302 minecraft:light[level=15]
setblock 544 155 310 minecraft:light[level=15]
fill 544 155 317 544 162 317 minecraft:brown_terracotta
setblock 545 155 275 minecraft:white_concrete
setblock 545 155 317 minecraft:white_concrete
fill 546 155 275 546 162 275 minecraft:brown_terracotta
fill 546 155 317 546 162 317 minecraft:brown_terracotta
fill 548 155 275 548 162 275 minecraft:brown_terracotta
fill 548 155 317 548 162 317 minecraft:brown_terracotta
setblock 549 155 275 minecraft:white_concrete
setblock 549 155 317 minecraft:white_concrete
fill 550 155 275 550 162 275 minecraft:brown_terracotta
fill 550 155 317 550 162 317 minecraft:brown_terracotta
fill 552 155 275 552 162 275 minecraft:brown_terracotta
setblock 552 155 278 minecraft:light[level=15]
setblock 552 155 286 minecraft:light[level=15]
setblock 552 155 294 minecraft:light[level=15]
setblock 552 155 302 minecraft:light[level=15]
setblock 552 155 310 minecraft:light[level=15]
fill 552 155 317 552 162 317 minecraft:brown_terracotta
setblock 553 155 275 minecraft:white_concrete
setblock 553 155 317 minecraft:white_concrete
fill 554 155 275 554 162 275 minecraft:brown_terracotta
fill 554 155 317 554 162 317 minecraft:brown_terracotta
fill 556 155 275 556 162 275 minecraft:brown_terracotta
fill 556 155 317 556 162 317 minecraft:brown_terracotta
setblock 557 155 275 minecraft:white_concrete
setblock 557 155 317 minecraft:white_concrete
fill 558 155 275 558 162 275 minecraft:brown_terracotta
fill 558 155 317 558 162 317 minecraft:brown_terracotta
setblock 559 155 275 minecraft:white_concrete
fill 559 155 276 559 162 276 minecraft:brown_terracotta
fill 559 155 278 559 162 278 minecraft:brown_terracotta
setblock 559 155 279 minecraft:white_concrete
fill 559 155 280 559 162 280 minecraft:brown_terracotta
fill 559 155 282 559 162 282 minecraft:brown_terracotta
setblock 559 155 283 minecraft:white_concrete
fill 559 155 284 559 162 284 minecraft:brown_terracotta
fill 559 155 286 559 162 286 minecraft:brown_terracotta
setblock 559 155 287 minecraft:white_concrete
fill 559 155 288 559 162 288 minecraft:brown_terracotta
fill 559 155 290 559 162 290 minecraft:brown_terracotta
setblock 559 155 291 minecraft:white_concrete
fill 559 155 292 559 162 292 minecraft:brown_terracotta
fill 559 155 294 559 162 294 minecraft:brown_terracotta
setblock 559 155 295 minecraft:white_concrete
fill 559 155 296 559 162 296 minecraft:brown_terracotta
fill 559 155 298 559 162 298 minecraft:brown_terracotta
setblock 559 155 299 minecraft:white_concrete
fill 559 155 300 559 162 300 minecraft:brown_terracotta
fill 559 155 302 559 162 302 minecraft:brown_terracotta
setblock 559 155 303 minecraft:white_concrete
fill 559 155 304 559 162 304 minecraft:brown_terracotta
fill 559 155 306 559 162 306 minecraft:brown_terracotta
setblock 559 155 307 minecraft:white_concrete
fill 559 155 308 559 162 308 minecraft:brown_terracotta
fill 559 155 310 559 162 310 minecraft:brown_terracotta
setblock 559 155 311 minecraft:white_concrete
fill 559 155 312 559 162 312 minecraft:brown_terracotta
fill 559 155 314 559 162 314 minecraft:brown_terracotta
setblock 559 155 315 minecraft:white_concrete
fill 559 155 316 559 162 316 minecraft:brown_terracotta
fill 517 156 275 517 163 275 minecraft:brown_terracotta
fill 517 156 279 517 163 279 minecraft:brown_terracotta
fill 517 156 283 517 163 283 minecraft:brown_terracotta
fill 517 156 287 517 163 287 minecraft:brown_terracotta
fill 517 156 291 517 163 291 minecraft:brown_terracotta
fill 517 156 295 517 163 295 minecraft:brown_terracotta
fill 517 156 299 517 163 299 minecraft:brown_terracotta
fill 517 156 303 517 163 303 minecraft:brown_terracotta
fill 517 156 307 517 163 307 minecraft:brown_terracotta
fill 517 156 311 517 163 311 minecraft:brown_terracotta
fill 517 156 315 517 163 315 minecraft:brown_terracotta
fill 517 156 317 517 161 317 minecraft:brown_terracotta
fill 521 156 275 521 163 275 minecraft:brown_terracotta
fill 521 156 317 521 163 317 minecraft:brown_terracotta
fill 525 156 275 525 163 275 minecraft:brown_terracotta
fill 525 156 317 525 163 317 minecraft:brown_terracotta
fill 529 156 275 529 163 275 minecraft:brown_terracotta
fill 529 156 317 529 163 317 minecraft:brown_terracotta
fill 533 156 275 533 163 275 minecraft:brown_terracotta
fill 533 156 317 533 163 317 minecraft:brown_terracotta
fill 536 156 311 538 156 315 minecraft:white_concrete
fill 537 156 275 537 163 275 minecraft:brown_terracotta
fill 537 156 317 537 163 317 minecraft:brown_terracotta
fill 541 156 275 541 163 275 minecraft:brown_terracotta
fill 541 156 317 541 163 317 minecraft:brown_terracotta
fill 545 156 275 545 163 275 minecraft:brown_terracotta
fill 545 156 317 545 163 317 minecraft:brown_terracotta
fill 549 156 275 549 163 275 minecraft:brown_terracotta
fill 549 156 317 549 163 317 minecraft:brown_terracotta
fill 553 156 275 553 163 275 minecraft:brown_terracotta
fill 553 156 317 553 163 317 minecraft:brown_terracotta
fill 557 156 275 557 163 275 minecraft:brown_terracotta
fill 557 156 317 557 163 317 minecraft:brown_terracotta
fill 559 156 275 559 161 275 minecraft:brown_terracotta
fill 559 156 279 559 163 279 minecraft:brown_terracotta
fill 559 156 283 559 163 283 minecraft:brown_terracotta
fill 559 156 287 559 163 287 minecraft:brown_terracotta
fill 559 156 291 559 163 291 minecraft:brown_terracotta
fill 559 156 295 559 163 295 minecraft:brown_terracotta
fill 559 156 299 559 163 299 minecraft:brown_terracotta
fill 559 156 303 559 163 303 minecraft:brown_terracotta
fill 559 156 307 559 163 307 minecraft:brown_terracotta
fill 559 156 311 559 163 311 minecraft:brown_terracotta
fill 559 156 315 559 163 315 minecraft:brown_terracotta
fill 537 157 311 537 157 315 minecraft:white_concrete
fill 518 158 276 527 159 276 minecraft:light_blue_stained_glass
fill 518 158 277 518 159 278 minecraft:white_stained_glass
fill 518 158 279 518 159 287 minecraft:light_blue_stained_glass
fill 518 158 288 518 159 288 minecraft:white_stained_glass
fill 518 158 289 518 159 297 minecraft:light_blue_stained_glass
fill 518 158 298 518 159 299 minecraft:white_stained_glass
fill 518 158 300 518 159 308 minecraft:light_blue_stained_glass
fill 518 158 309 518 159 309 minecraft:white_stained_glass
fill 518 158 310 518 159 316 minecraft:light_blue_stained_glass
fill 519 158 277 522 159 278 minecraft:light_blue_stained_glass
fill 519 158 279 519 159 280 minecraft:white_stained_glass
fill 519 158 281 519 159 289 minecraft:light_blue_stained_glass
fill 519 158 290 519 159 290 minecraft:white_stained_glass
fill 519 158 291 519 159 299 minecraft:light_blue_stained_glass
fill 519 158 300 519 159 301 minecraft:white_stained_glass
fill 519 158 302 519 159 310 minecraft:light_blue_stained_glass
fill 519 158 311 519 159 311 minecraft:white_stained_glass
fill 519 158 312 519 159 316 minecraft:light_blue_stained_glass
fill 520 158 279 523 159 280 minecraft:light_blue_stained_glass
fill 520 158 281 520 159 282 minecraft:white_stained_glass
fill 520 158 283 520 159 291 minecraft:light_blue_stained_glass
fill 520 158 292 520 159 292 minecraft:white_stained_glass
fill 520 158 293 520 159 301 minecraft:light_blue_stained_glass
fill 520 158 302 520 159 303 minecraft:white_stained_glass
fill 520 158 304 520 159 312 minecraft:light_blue_stained_glass
fill 520 158 313 520 159 313 minecraft:white_stained_glass
fill 520 158 314 520 159 316 minecraft:light_blue_stained_glass
fill 521 158 281 524 159 282 minecraft:light_blue_stained_glass
fill 521 158 283 521 159 284 minecraft:white_stained_glass
fill 521 158 285 521 159 293 minecraft:light_blue_stained_glass
fill 521 158 294 521 159 294 minecraft:white_stained_glass
fill 521 158 295 521 159 303 minecraft:light_blue_stained_glass
fill 521 158 304 521 159 305 minecraft:white_stained_glass
fill 521 158 306 521 159 314 minecraft:light_blue_stained_glass
fill 521 158 315 521 159 315 minecraft:white_stained_glass
fill 521 158 316 526 159 316 minecraft:light_blue_stained_glass
fill 522 158 283 525 159 284 minecraft:light_blue_stained_glass
fill 522 158 285 522 159 286 minecraft:white_stained_glass
fill 522 158 287 522 159 295 minecraft:light_blue_stained_glass
fill 522 158 296 522 159 296 minecraft:white_stained_glass
fill 522 158 297 522 159 305 minecraft:light_blue_stained_glass
fill 522 158 306 522 159 307 minecraft:white_stained_glass
fill 522 158 308 522 159 315 minecraft:light_blue_stained_glass
fill 523 158 277 523 159 277 minecraft:white_stained_glass
fill 523 158 278 528 159 278 minecraft:light_blue_stained_glass
fill 523 158 285 526 159 286 minecraft:light_blue_stained_glass
fill 523 158 287 523 159 288 minecraft:white_stained_glass
fill 523 158 289 523 159 297 minecraft:light_blue_stained_glass
fill 523 158 298 523 159 298 minecraft:white_stained_glass
fill 523 158 299 523 159 307 minecraft:light_blue_stained_glass
fill 523 158 308 523 159 309 minecraft:white_stained_glass
fill 523 158 310 523 159 315 minecraft:light_blue_stained_glass
fill 524 158 277 527 159 277 minecraft:light_blue_stained_glass
fill 524 158 279 524 159 279 minecraft:white_stained_glass
fill 524 158 280 529 159 280 minecraft:light_blue_stained_glass
fill 524 158 287 527 159 288 minecraft:light_blue_stained_glass
fill 524 158 289 524 159 290 minecraft:white_stained_glass
fill 524 158 291 524 159 299 minecraft:light_blue_stained_glass
fill 524 158 300 524 159 300 minecraft:white_stained_glass
fill 524 158 301 524 159 309 minecraft:light_blue_stained_glass
fill 524 158 310 524 159 311 minecraft:white_stained_glass
fill 524 158 312 524 159 315 minecraft:light_blue_stained_glass
fill 525 158 279 528 159 279 minecraft:light_blue_stained_glass
fill 525 158 281 525 159 281 minecraft:white_stained_glass
fill 525 158 282 530 159 282 minecraft:light_blue_stained_glass
fill 525 158 289 528 159 290 minecraft:light_blue_stained_glass
fill 525 158 291 525 159 292 minecraft:white_stained_glass
fill 525 158 293 525 159 301 minecraft:light_blue_stained_glass
fill 525 158 302 525 159 302 minecraft:white_stained_glass
fill 525 158 303 525 159 311 minecraft:light_blue_stained_glass
fill 525 158 312 525 159 313 minecraft:white_stained_glass
fill 525 158 314 525 159 315 minecraft:light_blue_stained_glass
fill 526 158 281 529 159 281 minecraft:light_blue_stained_glass
fill 526 158 283 526 159 283 minecraft:white_stained_glass
fill 526 158 284 531 159 284 minecraft:light_blue_stained_glass
fill 526 158 291 529 159 292 minecraft:light_blue_stained_glass
fill 526 158 293 526 159 294 minecraft:white_stained_glass
fill 526 158 295 526 159 303 minecraft:light_blue_stained_glass
fill 526 158 304 526 159 304 minecraft:white_stained_glass
fill 526 158 305 526 159 313 minecraft:light_blue_stained_glass
fill 526 158 314 526 159 315 minecraft:white_stained_glass
fill 527 158 283 530 159 283 minecraft:light_blue_stained_glass
fill 527 158 285 527 159 285 minecraft:white_stained_glass
fill 527 158 286 532 159 286 minecraft:light_blue_stained_glass
fill 527 158 293 530 159 294 minecraft:light_blue_stained_glass
fill 527 158 295 527 159 296 minecraft:white_stained_glass
fill 527 158 297 527 159 305 minecraft:light_blue_stained_glass
fill 527 158 306 527 159 306 minecraft:white_stained_glass
fill 527 158 307 527 159 315 minecraft:light_blue_stained_glass
fill 527 158 316 527 159 316 minecraft:white_stained_glass
fill 528 158 276 528 159 277 minecraft:white_stained_glass
fill 528 158 285 531 159 285 minecraft:light_blue_stained_glass
fill 528 158 287 528 159 287 minecraft:white_stained_glass
fill 528 158 288 533 159 288 minecraft:light_blue_stained_glass
fill 528 158 295 529 158 296 minecraft:light_blue_stained_glass
fill 528 158 297 528 158 298 minecraft:white_stained_glass
fill 528 158 299 528 158 307 minecraft:light_blue_stained_glass
fill 528 158 308 528 159 308 minecraft:white_stained_glass
fill 528 158 309 528 159 316 minecraft:light_blue_stained_glass
fill 529 158 276 532 159 277 minecraft:light_blue_stained_glass
fill 529 158 278 529 159 279 minecraft:white_stained_glass
fill 529 158 287 532 159 287 minecraft:light_blue_stained_glass
fill 529 158 289 529 159 289 minecraft:white_stained_glass
fill 529 158 290 534 159 290 minecraft:light_blue_stained_glass
setblock 529 158 300 minecraft:white_stained_glass
fill 529 158 301 529 158 309 minecraft:light_blue_stained_glass
fill 529 158 310 529 159 310 minecraft:white_stained_glass
fill 529 158 311 529 159 316 minecraft:light_blue_stained_glass
fill 530 158 278 533 159 279 minecraft:light_blue_stained_glass
fill 530 158 280 530 159 281 minecraft:white_stained_glass
fill 530 158 289 533 159 289 minecraft:light_blue_stained_glass
fill 530 158 291 530 159 291 minecraft:white_stained_glass
fill 530 158 292 535 159 292 minecraft:light_blue_stained_glass
fill 530 158 295 531 158 295 minecraft:light_blue_stained_glass
fill 530 158 301 530 158 302 minecraft:white_stained_glass
fill 530 158 303 530 159 311 minecraft:light_blue_stained_glass
fill 530 158 312 530 159 312 minecraft:white_stained_glass
fill 530 158 313 530 159 316 minecraft:light_blue_stained_glass
fill 531 158 280 534 159 281 minecraft:light_blue_stained_glass
fill 531 158 282 531 159 283 minecraft:white_stained_glass
fill 531 158 291 534 159 291 minecraft:light_blue_stained_glass
fill 531 158 293 531 159 293 minecraft:white_stained_glass
fill 531 158 294 536 159 294 minecraft:light_blue_stained_glass
fill 531 158 301 534 158 302 minecraft:light_blue_stained_glass
fill 531 158 303 531 159 304 minecraft:white_stained_glass
fill 531 158 305 531 159 313 minecraft:light_blue_stained_glass
fill 531 158 314 531 159 314 minecraft:white_stained_glass
fill 531 158 315 531 159 316 minecraft:light_blue_stained_glass
fill 532 158 282 535 159 283 minecraft:light_blue_stained_glass
fill 532 158 284 532 159 285 minecraft:white_stained_glass
fill 532 158 293 535 159 293 minecraft:light_blue_stained_glass
setblock 532 158 295 minecraft:white_stained_glass
fill 532 158 303 535 159 304 minecraft:light_blue_stained_glass
fill 532 158 305 532 159 306 minecraft:white_stained_glass
fill 532 158 307 532 159 315 minecraft:light_blue_stained_glass
fill 532 158 316 532 159 316 minecraft:white_stained_glass
fill 533 158 276 533 159 276 minecraft:white_stained_glass
fill 533 158 277 538 159 277 minecraft:light_blue_stained_glass
fill 533 158 284 536 159 285 minecraft:light_blue_stained_glass
fill 533 158 286 533 159 287 minecraft:white_stained_glass
fill 533 158 295 536 158 296 minecraft:light_blue_stained_glass
fill 533 158 300 539 158 300 minecraft:light_blue_stained_glass
fill 533 158 305 536 159 306 minecraft:light_blue_stained_glass
fill 533 158 307 533 159 308 minecraft:white_stained_glass
fill 533 158 309 533 159 316 minecraft:light_blue_stained_glass
fill 534 158 276 537 159 276 minecraft:light_blue_stained_glass
fill 534 158 278 534 159 278 minecraft:white_stained_glass
fill 534 158 279 539 159 279 minecraft:light_blue_stained_glass
fill 534 158 286 537 159 287 minecraft:light_blue_stained_glass
fill 534 158 288 534 159 289 minecraft:white_stained_glass
fill 534 158 297 537 158 298 minecraft:light_blue_stained_glass
setblock 534 158 299 minecraft:white_stained_glass
fill 534 158 307 537 159 308 minecraft:light_blue_stained_glass
fill 534 158 309 534 159 310 minecraft:white_stained_glass
fill 534 158 311 534 159 316 minecraft:light_blue_stained_glass
fill 535 158 278 538 159 278 minecraft:light_blue_stained_glass
fill 535 158 280 535 159 280 minecraft:white_stained_glass
fill 535 158 281 540 159 281 minecraft:light_blue_stained_glass
fill 535 158 288 538 159 289 minecraft:light_blue_stained_glass
fill 535 158 290 535 159 291 minecraft:white_stained_glass
fill 535 158 299 538 159 299 minecraft:light_blue_stained_glass
fill 535 158 301 535 159 301 minecraft:white_stained_glass
fill 535 158 302 540 159 302 minecraft:light_blue_stained_glass
fill 535 158 309 538 159 310 minecraft:light_blue_stained_glass
fill 535 158 311 535 159 312 minecraft:white_stained_glass
fill 535 158 313 535 159 316 minecraft:light_blue_stained_glass
fill 536 158 280 539 159 280 minecraft:light_blue_stained_glass
fill 536 158 282 536 159 282 minecraft:white_stained_glass
fill 536 158 283 541 159 283 minecraft:light_blue_stained_glass
fill 536 158 290 539 159 291 minecraft:light_blue_stained_glass
fill 536 158 292 536 159 293 minecraft:white_stained_glass
fill 536 158 301 539 159 301 minecraft:light_blue_stained_glass
fill 536 158 303 536 159 303 minecraft:white_stained_glass
fill 536 158 304 541 159 304 minecraft:light_blue_stained_glass
fill 536 158 311 539 159 312 minecraft:light_blue_stained_glass
fill 536 158 313 536 159 314 minecraft:white_stained_glass
fill 536 158 315 536 159 316 minecraft:light_blue_stained_glass
fill 537 158 282 540 159 282 minecraft:light_blue_stained_glass
fill 537 158 284 537 159 284 minecraft:white_stained_glass
fill 537 158 285 542 159 285 minecraft:light_blue_stained_glass
fill 537 158 292 540 159 293 minecraft:light_blue_stained_glass
fill 537 158 294 537 159 295 minecraft:white_stained_glass
fill 537 158 296 537 159 296 minecraft:light_blue_stained_glass
fill 537 158 303 540 159 303 minecraft:light_blue_stained_glass
fill 537 158 305 537 159 305 minecraft:white_stained_glass
fill 537 158 306 542 159 306 minecraft:light_blue_stained_glass
fill 537 158 313 540 159 314 minecraft:light_blue_stained_glass
fill 537 158 315 537 159 316 minecraft:white_stained_glass
fill 538 158 276 538 159 276 minecraft:white_stained_glass
fill 538 158 284 541 159 284 minecraft:light_blue_stained_glass
fill 538 158 286 538 159 286 minecraft:white_stained_glass
fill 538 158 287 543 159 287 minecraft:light_blue_stained_glass
fill 538 158 294 541 159 295 minecraft:light_blue_stained_glass
fill 538 158 296 538 159 297 minecraft:white_stained_glass
fill 538 158 298 538 159 298 minecraft:light_blue_stained_glass
fill 538 158 305 541 159 305 minecraft:light_blue_stained_glass
fill 538 158 307 538 159 307 minecraft:white_stained_glass
fill 538 158 308 543 159 308 minecraft:light_blue_stained_glass
fill 538 158 315 541 159 316 minecraft:light_blue_stained_glass
fill 539 158 276 548 159 276 minecraft:light_blue_stained_glass
fill 539 158 277 539 159 278 minecraft:white_stained_glass
fill 539 158 286 542 159 286 minecraft:light_blue_stained_glass
fill 539 158 288 539 159 288 minecraft:white_stained_glass
fill 539 158 289 544 159 289 minecraft:light_blue_stained_glass
fill 539 158 296 542 159 297 minecraft:light_blue_stained_glass
fill 539 158 298 539 159 299 minecraft:white_stained_glass
fill 539 158 307 542 159 307 minecraft:light_blue_stained_glass
fill 539 158 309 539 159 309 minecraft:white_stained_glass
fill 539 158 310 544 159 310 minecraft:light_blue_stained_glass
fill 540 158 277 543 159 278 minecraft:light_blue_stained_glass
fill 540 158 279 540 159 280 minecraft:white_stained_glass
fill 540 158 288 543 159 288 minecraft:light_blue_stained_glass
fill 540 158 290 540 159 290 minecraft:white_stained_glass
fill 540 158 291 545 159 291 minecraft:light_blue_stained_glass
fill 540 158 298 543 159 299 minecraft:light_blue_stained_glass
fill 540 158 300 540 159 301 minecraft:white_stained_glass
fill 540 158 309 543 159 309 minecraft:light_blue_stained_glass
fill 540 158 311 540 159 311 minecraft:white_stained_glass
fill 540 158 312 545 159 312 minecraft:light_blue_stained_glass
fill 541 158 279 544 159 280 minecraft:light_blue_stained_glass
fill 541 158 281 541 159 282 minecraft:white_stained_glass
fill 541 158 290 544 159 290 minecraft:light_blue_stained_glass
fill 541 158 292 541 159 292 minecraft:white_stained_glass
fill 541 158 293 546 159 293 minecraft:light_blue_stained_glass
fill 541 158 300 544 159 301 minecraft:light_blue_stained_glass
fill 541 158 302 541 159 303 minecraft:white_stained_glass
fill 541 158 311 544 159 311 minecraft:light_blue_stained_glass
fill 541 158 313 541 159 313 minecraft:white_stained_glass
fill 541 158 314 546 159 314 minecraft:light_blue_stained_glass
fill 542 158 281 545 159 282 minecraft:light_blue_stained_glass
fill 542 158 283 542 159 284 minecraft:white_stained_glass
fill 542 158 292 545 159 292 minecraft:light_blue_stained_glass
fill 542 158 294 542 159 294 minecraft:white_stained_glass
fill 542 158 295 547 159 295 minecraft:light_blue_stained_glass
fill 542 158 302 545 159 303 minecraft:light_blue_stained_glass
fill 542 158 304 542 159 305 minecraft:white_stained_glass
fill 542 158 313 545 159 313 minecraft:light_blue_stained_glass
fill 542 158 315 542 159 315 minecraft:white_stained_glass
fill 542 158 316 547 159 316 minecraft:light_blue_stained_glass
fill 543 158 283 546 159 284 minecraft:light_blue_stained_glass
fill 543 158 285 543 159 286 minecraft:white_stained_glass
fill 543 158 294 546 159 294 minecraft:light_blue_stained_glass
fill 543 158 296 543 159 296 minecraft:white_stained_glass
fill 543 158 297 548 159 297 minecraft:light_blue_stained_glass
fill 543 158 304 546 159 305 minecraft:light_blue_stained_glass
fill 543 158 306 543 159 307 minecraft:white_stained_glass
fill 543 158 315 546 159 315 minecraft:light_blue_stained_glass
fill 544 158 277 544 159 277 minecraft:white_stained_glass
fill 544 158 278 549 159 278 minecraft:light_blue_stained_glass
fill 544 158 285 547 159 286 minecraft:light_blue_stained_glass
fill 544 158 287 544 159 288 minecraft:white_stained_glass
fill 544 158 296 547 159 296 minecraft:light_blue_stained_glass
fill 544 158 298 544 159 298 minecraft:white_stained_glass
fill 544 158 299 549 159 299 minecraft:light_blue_stained_glass
fill 544 158 306 547 159 307 minecraft:light_blue_stained_glass
fill 544 158 308 544 159 309 minecraft:white_stained_glass
fill 545 158 277 548 159 277 minecraft:light_blue_stained_glass
fill 545 158 279 545 159 279 minecraft:white_stained_glass
fill 545 158 280 550 159 280 minecraft:light_blue_stained_glass
fill 545 158 287 548 159 288 minecraft:light_blue_stained_glass
fill 545 158 289 545 159 290 minecraft:white_stained_glass
fill 545 158 298 548 159 298 minecraft:light_blue_stained_glass
fill 545 158 300 545 159 300 minecraft:white_stained_glass
fill 545 158 301 550 159 301 minecraft:light_blue_stained_glass
fill 545 158 308 548 159 309 minecraft:light_blue_stained_glass
fill 545 158 310 545 159 311 minecraft:white_stained_glass
fill 546 158 279 549 159 279 minecraft:light_blue_stained_glass
fill 546 158 281 546 159 281 minecraft:white_stained_glass
fill 546 158 282 551 159 282 minecraft:light_blue_stained_glass
fill 546 158 289 549 159 290 minecraft:light_blue_stained_glass
fill 546 158 291 546 159 292 minecraft:white_stained_glass
fill 546 158 300 549 159 300 minecraft:light_blue_stained_glass
fill 546 158 302 546 159 302 minecraft:white_stained_glass
fill 546 158 303 551 159 303 minecraft:light_blue_stained_glass
fill 546 158 310 549 159 311 minecraft:light_blue_stained_glass
fill 546 158 312 546 159 313 minecraft:white_stained_glass
fill 547 158 281 550 159 281 minecraft:light_blue_stained_glass
fill 547 158 283 547 159 283 minecraft:white_stained_glass
fill 547 158 284 552 159 284 minecraft:light_blue_stained_glass
fill 547 158 291 550 159 292 minecraft:light_blue_stained_glass
fill 547 158 293 547 159 294 minecraft:white_stained_glass
fill 547 158 302 550 159 302 minecraft:light_blue_stained_glass
fill 547 158 304 547 159 304 minecraft:white_stained_glass
fill 547 158 305 552 159 305 minecraft:light_blue_stained_glass
fill 547 158 312 550 159 313 minecraft:light_blue_stained_glass
fill 547 158 314 547 159 315 minecraft:white_stained_glass
fill 548 158 283 551 159 283 minecraft:light_blue_stained_glass
fill 548 158 285 548 159 285 minecraft:white_stained_glass
fill 548 158 286 553 159 286 minecraft:light_blue_stained_glass
fill 548 158 293 551 159 294 minecraft:light_blue_stained_glass
fill 548 158 295 548 159 296 minecraft:white_stained_glass
fill 548 158 304 551 159 304 minecraft:light_blue_stained_glass
fill 548 158 306 548 159 306 minecraft:white_stained_glass
fill 548 158 307 553 159 307 minecraft:light_blue_stained_glass
fill 548 158 314 551 159 315 minecraft:light_blue_stained_glass
fill 548 158 316 548 159 316 minecraft:white_stained_glass
fill 549 158 276 549 159 277 minecraft:white_stained_glass
fill 549 158 285 552 159 285 minecraft:light_blue_stained_glass
fill 549 158 287 549 159 287 minecraft:white_stained_glass
fill 549 158 288 554 159 288 minecraft:light_blue_stained_glass
fill 549 158 295 552 159 296 minecraft:light_blue_stained_glass
fill 549 158 297 549 159 298 minecraft:white_stained_glass
fill 549 158 306 552 159 306 minecraft:light_blue_stained_glass
fill 549 158 308 549 159 308 minecraft:white_stained_glass
fill 549 158 309 554 159 309 minecraft:light_blue_stained_glass
fill 549 158 316 552 159 316 minecraft:light_blue_stained_glass
fill 550 158 276 553 159 277 minecraft:light_blue_stained_glass
fill 550 158 278 550 159 279 minecraft:white_stained_glass
fill 550 158 287 553 159 287 minecraft:light_blue_stained_glass
fill 550 158 289 550 159 289 minecraft:white_stained_glass
fill 550 158 290 555 159 290 minecraft:light_blue_stained_glass
fill 550 158 297 553 159 298 minecraft:light_blue_stained_glass
fill 550 158 299 550 159 300 minecraft:white_stained_glass
fill 550 158 308 553 159 308 minecraft:light_blue_stained_glass
fill 550 158 310 550 159 310 minecraft:white_stained_glass
fill 550 158 311 555 159 311 minecraft:light_blue_stained_glass
fill 551 158 278 554 159 279 minecraft:light_blue_stained_glass
fill 551 158 280 551 159 281 minecraft:white_stained_glass
fill 551 158 289 554 159 289 minecraft:light_blue_stained_glass
fill 551 158 291 551 159 291 minecraft:white_stained_glass
fill 551 158 292 556 159 292 minecraft:light_blue_stained_glass
fill 551 158 299 554 159 300 minecraft:light_blue_stained_glass
fill 551 158 301 551 159 302 minecraft:white_stained_glass
fill 551 158 310 554 159 310 minecraft:light_blue_stained_glass
fill 551 158 312 551 159 312 minecraft:white_stained_glass
fill 551 158 313 556 159 313 minecraft:light_blue_stained_glass
fill 552 158 280 555 159 281 minecraft:light_blue_stained_glass
fill 552 158 282 552 159 283 minecraft:white_stained_glass
fill 552 158 291 555 159 291 minecraft:light_blue_stained_glass
fill 552 158 293 552 159 293 minecraft:white_stained_glass
fill 552 158 294 557 159 294 minecraft:light_blue_stained_glass
fill 552 158 301 555 159 302 minecraft:light_blue_stained_glass
fill 552 158 303 552 159 304 minecraft:white_stained_glass
fill 552 158 312 555 159 312 minecraft:light_blue_stained_glass
fill 552 158 314 552 159 314 minecraft:white_stained_glass
fill 552 158 315 557 159 315 minecraft:light_blue_stained_glass
fill 553 158 282 556 159 283 minecraft:light_blue_stained_glass
fill 553 158 284 553 159 285 minecraft:white_stained_glass
fill 553 158 293 556 159 293 minecraft:light_blue_stained_glass
fill 553 158 295 553 159 295 minecraft:white_stained_glass
fill 553 158 296 558 159 296 minecraft:light_blue_stained_glass
fill 553 158 303 556 159 304 minecraft:light_blue_stained_glass
fill 553 158 305 553 159 306 minecraft:white_stained_glass
fill 553 158 314 556 159 314 minecraft:light_blue_stained_glass
fill 553 158 316 553 159 316 minecraft:white_stained_glass
fill 554 158 276 554 159 276 minecraft:white_stained_glass
fill 554 158 277 558 159 277 minecraft:light_blue_stained_glass
fill 554 158 284 557 159 285 minecraft:light_blue_stained_glass
fill 554 158 286 554 159 287 minecraft:white_stained_glass
fill 554 158 295 557 159 295 minecraft:light_blue_stained_glass
fill 554 158 297 554 159 297 minecraft:white_stained_glass
fill 554 158 298 558 159 298 minecraft:light_blue_stained_glass
fill 554 158 305 557 159 306 minecraft:light_blue_stained_glass
fill 554 158 307 554 159 308 minecraft:white_stained_glass
fill 554 158 316 557 159 316 minecraft:light_blue_stained_glass
fill 555 158 276 558 159 276 minecraft:light_blue_stained_glass
fill 555 158 278 555 159 278 minecraft:white_stained_glass
fill 555 158 279 558 159 279 minecraft:light_blue_stained_glass
fill 555 158 286 558 159 287 minecraft:light_blue_stained_glass
fill 555 158 288 555 159 289 minecraft:white_stained_glass
fill 555 158 297 558 159 297 minecraft:light_blue_stained_glass
fill 555 158 299 555 159 299 minecraft:white_stained_glass
fill 555 158 300 558 159 300 minecraft:light_blue_stained_glass
fill 555 158 307 558 159 308 minecraft:light_blue_stained_glass
fill 555 158 309 555 159 310 minecraft:white_stained_glass
fill 556 158 278 558 159 278 minecraft:light_blue_stained_glass
fill 556 158 280 556 159 280 minecraft:white_stained_glass
fill 556 158 281 558 159 281 minecraft:light_blue_stained_glass
fill 556 158 288 558 159 289 minecraft:light_blue_stained_glass
fill 556 158 290 556 159 291 minecraft:white_stained_glass
fill 556 158 299 558 159 299 minecraft:light_blue_stained_glass
fill 556 158 301 556 159 301 minecraft:white_stained_glass
fill 556 158 302 558 159 302 minecraft:light_blue_stained_glass
fill 556 158 309 558 159 310 minecraft:light_blue_stained_glass
fill 556 158 311 556 159 312 minecraft:white_stained_glass
fill 557 158 280 558 159 280 minecraft:light_blue_stained_glass
fill 557 158 282 557 159 282 minecraft:white_stained_glass
fill 557 158 283 558 159 283 minecraft:light_blue_stained_glass
fill 557 158 290 558 159 291 minecraft:light_blue_stained_glass
fill 557 158 292 557 159 293 minecraft:white_stained_glass
fill 557 158 301 558 159 301 minecraft:light_blue_stained_glass
fill 557 158 303 557 159 303 minecraft:white_stained_glass
fill 557 158 304 558 159 304 minecraft:light_blue_stained_glass
fill 557 158 311 558 159 312 minecraft:light_blue_stained_glass
fill 557 158 313 557 159 314 minecraft:white_stained_glass
fill 558 158 282 558 159 282 minecraft:light_blue_stained_glass
fill 558 158 284 558 159 284 minecraft:white_stained_glass
fill 558 158 285 558 159 285 minecraft:light_blue_stained_glass
fill 558 158 292 558 159 293 minecraft:light_blue_stained_glass
fill 558 158 294 558 159 295 minecraft:white_stained_glass
fill 558 158 303 558 159 303 minecraft:light_blue_stained_glass
fill 558 158 305 558 159 305 minecraft:white_stained_glass
fill 558 158 306 558 159 306 minecraft:light_blue_stained_glass
fill 558 158 313 558 159 314 minecraft:light_blue_stained_glass
fill 558 158 315 558 159 316 minecraft:white_stained_glass
setblock 528 159 295 minecraft:light_blue_stained_glass
fill 528 159 296 528 159 300 minecraft:white_concrete
fill 528 159 301 528 159 307 minecraft:light_blue_stained_glass
fill 529 159 295 529 159 296 minecraft:white_concrete
fill 529 159 300 529 159 301 minecraft:white_concrete
fill 529 159 302 529 159 309 minecraft:light_blue_stained_glass
fill 530 159 295 533 159 295 minecraft:white_concrete
fill 530 159 301 533 159 301 minecraft:white_concrete
setblock 530 159 302 minecraft:white_stained_glass
fill 531 159 302 534 159 302 minecraft:light_blue_stained_glass
fill 533 159 296 534 159 296 minecraft:white_concrete
fill 533 159 300 534 159 300 minecraft:white_concrete
fill 534 159 295 536 159 295 minecraft:light_blue_stained_glass
fill 534 159 297 534 159 299 minecraft:white_concrete
setblock 534 159 301 minecraft:light_blue_stained_glass
fill 535 159 296 536 159 298 minecraft:light_blue_stained_glass
fill 535 159 300 539 159 300 minecraft:light_blue_stained_glass
fill 537 159 297 537 159 298 minecraft:light_blue_stained_glass
setblock 521 160 298 minecraft:white_concrete
setblock 524 160 291 minecraft:white_concrete
setblock 524 160 305 minecraft:white_concrete
setblock 531 160 288 minecraft:white_concrete
setblock 531 160 308 minecraft:white_concrete
setblock 538 160 291 minecraft:white_concrete
setblock 538 160 305 minecraft:white_concrete
setblock 541 160 298 minecraft:white_concrete
setblock 521 161 298 minecraft:red_concrete
setblock 524 161 291 minecraft:red_concrete
setblock 524 161 305 minecraft:red_concrete
setblock 531 161 288 minecraft:red_concrete
setblock 531 161 308 minecraft:red_concrete
setblock 538 161 291 minecraft:red_concrete
setblock 538 161 305 minecraft:red_concrete
setblock 541 161 298 minecraft:red_concrete
setblock 517 162 277 minecraft:white_concrete
setblock 517 162 281 minecraft:white_concrete
setblock 517 162 285 minecraft:white_concrete
setblock 517 162 289 minecraft:white_concrete
setblock 517 162 293 minecraft:white_concrete
setblock 517 162 297 minecraft:white_concrete
setblock 517 162 301 minecraft:white_concrete
setblock 517 162 305 minecraft:white_concrete
setblock 517 162 309 minecraft:white_concrete
setblock 517 162 313 minecraft:white_concrete
setblock 517 162 317 minecraft:white_concrete
setblock 519 162 275 minecraft:white_concrete
setblock 519 162 317 minecraft:white_concrete
setblock 521 162 298 minecraft:white_concrete
setblock 523 162 275 minecraft:white_concrete
setblock 523 162 317 minecraft:white_concrete
setblock 524 162 291 minecraft:white_concrete
setblock 524 162 305 minecraft:white_concrete
setblock 527 162 275 minecraft:white_concrete
setblock 527 162 317 minecraft:white_concrete
setblock 531 162 275 minecraft:white_concrete
setblock 531 162 288 minecraft:white_concrete
setblock 531 162 308 minecraft:white_concrete
setblock 531 162 317 minecraft:white_concrete
setblock 535 162 275 minecraft:white_concrete
setblock 535 162 317 minecraft:white_concrete
setblock 538 162 291 minecraft:white_concrete
setblock 538 162 305 minecraft:white_concrete
setblock 539 162 275 minecraft:white_concrete
setblock 539 162 317 minecraft:white_concrete
setblock 541 162 298 minecraft:white_concrete
setblock 543 162 275 minecraft:white_concrete
setblock 543 162 317 minecraft:white_concrete
setblock 547 162 275 minecraft:white_concrete
setblock 547 162 317 minecraft:white_concrete
setblock 551 162 275 minecraft:white_concrete
setblock 551 162 317 minecraft:white_concrete
setblock 555 162 275 minecraft:white_concrete
setblock 555 162 317 minecraft:white_concrete
setblock 559 162 275 minecraft:white_concrete
setblock 559 162 277 minecraft:white_concrete
setblock 559 162 281 minecraft:white_concrete
setblock 559 162 285 minecraft:white_concrete
setblock 559 162 289 minecraft:white_concrete
setblock 559 162 293 minecraft:white_concrete
setblock 559 162 297 minecraft:white_concrete
setblock 559 162 301 minecraft:white_concrete
setblock 559 162 305 minecraft:white_concrete
setblock 559 162 309 minecraft:white_concrete
setblock 559 162 313 minecraft:white_concrete
setblock 559 162 317 minecraft:white_concrete
fill 517 163 276 520 163 276 minecraft:white_concrete
fill 517 163 277 517 170 277 minecraft:brown_terracotta
setblock 517 163 278 minecraft:white_concrete
setblock 517 163 280 minecraft:white_concrete
fill 517 163 281 517 165 281 minecraft:brown_terracotta
setblock 517 163 282 minecraft:white_concrete
setblock 517 163 284 minecraft:white_concrete
fill 517 163 285 517 170 285 minecraft:brown_terracotta
fill 517 163 286 519 163 286 minecraft:white_concrete
fill 517 163 288 518 163 288 minecraft:white_concrete
fill 517 163 289 517 170 289 minecraft:brown_terracotta
setblock 517 163 290 minecraft:white_concrete
setblock 517 163 292 minecraft:white_concrete
fill 517 163 293 517 165 293 minecraft:brown_terracotta
setblock 517 163 294 minecraft:white_concrete
setblock 517 163 296 minecraft:white_concrete
fill 517 163 297 517 170 297 minecraft:brown_terracotta
fill 517 163 298 519 163 298 minecraft:white_concrete
fill 517 163 300 518 163 300 minecraft:white_concrete
fill 517 163 301 517 170 301 minecraft:brown_terracotta
setblock 517 163 302 minecraft:white_concrete
setblock 517 163 304 minecraft:white_concrete
fill 517 163 305 517 165 305 minecraft:brown_terracotta
setblock 517 163 306 minecraft:white_concrete
setblock 517 163 308 minecraft:white_concrete
fill 517 163 309 517 170 309 minecraft:brown_terracotta
fill 517 163 310 519 163 310 minecraft:white_concrete
fill 517 163 312 518 163 312 minecraft:white_concrete
fill 517 163 313 517 170 313 minecraft:brown_terracotta
setblock 517 163 314 minecraft:white_concrete
setblock 517 163 316 minecraft:white_concrete
setblock 517 163 317 minecraft:brown_terracotta
setblock 518 163 275 minecraft:white_concrete
fill 518 163 287 519 165 287 minecraft:white_concrete
fill 518 163 299 519 165 299 minecraft:white_concrete
fill 518 163 311 519 165 311 minecraft:white_concrete
setblock 518 163 317 minecraft:white_concrete
fill 519 163 275 519 170 275 minecraft:brown_terracotta
fill 519 163 285 519 165 285 minecraft:white_concrete
fill 519 163 297 519 165 297 minecraft:white_concrete
fill 519 163 309 519 165 309 minecraft:white_concrete
fill 519 163 317 519 165 317 minecraft:brown_terracotta
setblock 520 163 275 minecraft:white_concrete
setblock 520 163 278 minecraft:light[level=15]
fill 520 163 279 520 163 281 minecraft:brown_terracotta
setblock 520 163 286 minecraft:light[level=15]
setblock 520 163 294 minecraft:light[level=15]
setblock 520 163 302 minecraft:light[level=15]
setblock 520 163 310 minecraft:light[level=15]
setblock 520 163 317 minecraft:white_concrete
fill 521 163 278 523 163 278 minecraft:brown_terracotta
fill 521 163 279 523 174 281 minecraft:white_concrete
setblock 521 163 282 minecraft:brown_terracotta
setblock 521 163 298 minecraft:red_concrete
setblock 522 163 275 minecraft:white_concrete
fill 522 163 282 522 174 282 minecraft:white_concrete
setblock 522 163 317 minecraft:white_concrete
fill 523 163 275 523 170 275 minecraft:brown_terracotta
setblock 523 163 282 minecraft:brown_terracotta
fill 523 163 317 523 170 317 minecraft:brown_terracotta
setblock 524 163 275 minecraft:white_concrete
fill 524 163 279 524 163 281 minecraft:brown_terracotta
setblock 524 163 291 minecraft:red_concrete
setblock 524 163 305 minecraft:red_concrete
fill 524 163 316 524 163 317 minecraft:white_concrete
fill 525 163 315 526 165 316 minecraft:white_concrete
setblock 526 163 275 minecraft:white_concrete
setblock 526 163 317 minecraft:white_concrete
fill 527 163 275 527 165 275 minecraft:brown_terracotta
fill 527 163 315 527 165 315 minecraft:white_concrete
fill 527 163 317 527 170 317 minecraft:brown_terracotta
setblock 528 163 275 minecraft:white_concrete
setblock 528 163 278 minecraft:light[level=15]
setblock 528 163 286 minecraft:light[level=15]
setblock 528 163 294 minecraft:light[level=15]
setblock 528 163 302 minecraft:light[level=15]
setblock 528 163 310 minecraft:light[level=15]
setblock 528 163 317 minecraft:white_concrete
fill 529 163 277 531 165 277 minecraft:white_concrete
fill 530 163 275 530 163 276 minecraft:white_concrete
setblock 530 163 317 minecraft:white_concrete
fill 531 163 275 531 170 275 minecraft:brown_terracotta
fill 531 163 276 532 218 276 minecraft:white_concrete
setblock 531 163 288 minecraft:red_concrete
setblock 531 163 308 minecraft:red_concrete
fill 531 163 317 531 165 317 minecraft:brown_terracotta
setblock 532 163 275 minecraft:white_concrete
setblock 532 163 317 minecraft:white_concrete
setblock 534 163 275 minecraft:white_concrete
setblock 534 163 317 minecraft:white_concrete
fill 535 163 275 535 170 275 minecraft:brown_terracotta
fill 535 163 317 535 170 317 minecraft:brown_terracotta
setblock 536 163 275 minecraft:white_concrete
setblock 536 163 278 minecraft:light[level=15]
setblock 536 163 286 minecraft:light[level=15]
setblock 536 163 294 minecraft:light[level=15]
setblock 536 163 302 minecraft:light[level=15]
setblock 536 163 310 minecraft:light[level=15]
fill 536 163 316 536 163 317 minecraft:white_concrete
fill 537 163 315 538 165 316 minecraft:white_concrete
setblock 538 163 275 minecraft:white_concrete
setblock 538 163 291 minecraft:red_concrete
setblock 538 163 305 minecraft:red_concrete
setblock 538 163 317 minecraft:white_concrete
fill 539 163 275 539 165 275 minecraft:brown_terracotta
fill 539 163 315 539 165 315 minecraft:white_concrete
fill 539 163 317 539 170 317 minecraft:brown_terracotta
setblock 540 163 275 minecraft:white_concrete
setblock 540 163 317 minecraft:white_concrete
fill 541 163 277 543 165 277 minecraft:white_concrete
setblock 541 163 298 minecraft:red_concrete
fill 542 163 275 542 163 276 minecraft:white_concrete
setblock 542 163 317 minecraft:white_concrete
fill 543 163 275 543 170 275 minecraft:brown_terracotta
fill 543 163 276 544 218 276 minecraft:white_concrete
fill 543 163 317 543 165 317 minecraft:brown_terracotta
setblock 544 163 275 minecraft:white_concrete
setblock 544 163 278 minecraft:light[level=15]
setblock 544 163 286 minecraft:light[level=15]
setblock 544 163 294 minecraft:light[level=15]
setblock 544 163 302 minecraft:light[level=15]
setblock 544 163 310 minecraft:light[level=15]
setblock 544 163 317 minecraft:white_concrete
setblock 546 163 275 minecraft:white_concrete
fill 546 163 310 546 163 317 minecraft:white_concrete
fill 547 163 275 547 170 275 minecraft:brown_terracotta
fill 547 163 310 558 164 316 minecraft:white_concrete
fill 547 163 317 547 170 317 minecraft:brown_terracotta
setblock 548 163 275 minecraft:white_concrete
setblock 548 163 317 minecraft:white_concrete
setblock 550 163 275 minecraft:white_concrete
setblock 550 163 317 minecraft:white_concrete
fill 551 163 275 551 165 275 minecraft:brown_terracotta
fill 551 163 276 558 164 286 minecraft:white_concrete
fill 551 163 317 551 170 317 minecraft:brown_terracotta
setblock 552 163 275 minecraft:white_concrete
setblock 552 163 294 minecraft:light[level=15]
setblock 552 163 302 minecraft:light[level=15]
setblock 552 163 317 minecraft:white_concrete
setblock 554 163 275 minecraft:white_concrete
setblock 554 163 317 minecraft:white_concrete
fill 555 163 275 555 165 275 minecraft:brown_terracotta
fill 555 163 317 555 165 317 minecraft:brown_terracotta
setblock 556 163 275 minecraft:white_concrete
setblock 556 163 317 minecraft:white_concrete
fill 557 163 287 557 165 287 minecraft:white_concrete
fill 557 163 297 557 165 299 minecraft:white_concrete
fill 557 163 309 558 165 309 minecraft:white_concrete
setblock 558 163 275 minecraft:white_concrete
fill 558 163 296 558 218 298 minecraft:white_concrete
fill 558 163 308 559 163 308 minecraft:white_concrete
setblock 558 163 317 minecraft:white_concrete
setblock 559 163 275 minecraft:brown_terracotta
setblock 559 163 276 minecraft:white_concrete
fill 559 163 277 559 165 277 minecraft:brown_terracotta
setblock 559 163 278 minecraft:white_concrete
setblock 559 163 280 minecraft:white_concrete
fill 559 163 281 559 170 281 minecraft:brown_terracotta
setblock 559 163 282 minecraft:white_concrete
setblock 559 163 284 minecraft:white_concrete
fill 559 163 285 559 170 285 minecraft:brown_terracotta
setblock 559 163 286 minecraft:white_concrete
setblock 559 163 288 minecraft:white_concrete
fill 559 163 289 559 165 289 minecraft:brown_terracotta
setblock 559 163 290 minecraft:white_concrete
setblock 559 163 292 minecraft:white_concrete
fill 559 163 293 559 170 293 minecraft:brown_terracotta
setblock 559 163 294 minecraft:white_concrete
setblock 559 163 296 minecraft:white_concrete
fill 559 163 297 559 170 297 minecraft:brown_terracotta
setblock 559 163 298 minecraft:white_concrete
setblock 559 163 300 minecraft:white_concrete
fill 559 163 301 559 165 301 minecraft:brown_terracotta
setblock 559 163 302 minecraft:white_concrete
setblock 559 163 304 minecraft:white_concrete
fill 559 163 305 559 170 305 minecraft:brown_terracotta
setblock 559 163 306 minecraft:white_concrete
fill 559 163 309 559 170 309 minecraft:brown_terracotta
setblock 559 163 310 minecraft:white_concrete
setblock 559 163 312 minecraft:white_concrete
fill 559 163 313 559 165 313 minecraft:brown_terracotta
setblock 559 163 314 minecraft:white_concrete
setblock 559 163 316 minecraft:white_concrete
fill 559 163 317 559 170 317 minecraft:brown_terracotta
setblock 517 164 275 minecraft:white_concrete
fill 517 164 276 517 171 276 minecraft:brown_terracotta
fill 517 164 278 517 171 278 minecraft:brown_terracotta
setblock 517 164 279 minecraft:white_concrete
fill 517 164 280 517 171 280 minecraft:brown_terracotta
fill 517 164 282 517 165 282 minecraft:brown_terracotta
setblock 517 164 283 minecraft:white_concrete
fill 517 164 284 517 165 284 minecraft:brown_terracotta
fill 517 164 286 517 171 286 minecraft:brown_terracotta
setblock 517 164 287 minecraft:white_concrete
fill 517 164 288 517 171 288 minecraft:brown_terracotta
fill 517 164 290 517 171 290 minecraft:brown_terracotta
setblock 517 164 291 minecraft:white_concrete
fill 517 164 292 517 171 292 minecraft:brown_terracotta
fill 517 164 294 517 165 294 minecraft:brown_terracotta
setblock 517 164 295 minecraft:white_concrete
fill 517 164 296 517 165 296 minecraft:brown_terracotta
fill 517 164 298 517 171 298 minecraft:brown_terracotta
setblock 517 164 299 minecraft:white_concrete
fill 517 164 300 517 171 300 minecraft:brown_terracotta
fill 517 164 302 517 171 302 minecraft:brown_terracotta
setblock 517 164 303 minecraft:white_concrete
fill 517 164 304 517 171 304 minecraft:brown_terracotta
fill 517 164 306 517 165 306 minecraft:brown_terracotta
setblock 517 164 307 minecraft:white_concrete
fill 517 164 308 517 165 308 minecraft:brown_terracotta
fill 517 164 310 517 171 310 minecraft:brown_terracotta
setblock 517 164 311 minecraft:white_concrete
fill 517 164 312 517 171 312 minecraft:brown_terracotta
fill 517 164 314 517 171 314 minecraft:brown_terracotta
setblock 517 164 315 minecraft:white_concrete
fill 517 164 316 517 171 316 minecraft:brown_terracotta
setblock 517 164 317 minecraft:white_concrete
fill 518 164 275 518 171 275 minecraft:brown_terracotta
fill 518 164 276 520 218 276 minecraft:white_concrete
fill 518 164 286 519 165 286 minecraft:white_concrete
fill 518 164 288 518 218 288 minecraft:white_concrete
fill 518 164 298 519 165 298 minecraft:white_concrete
fill 518 164 300 518 218 300 minecraft:white_concrete
fill 518 164 310 519 165 310 minecraft:white_concrete
fill 518 164 312 518 218 312 minecraft:white_concrete
fill 518 164 317 518 165 317 minecraft:brown_terracotta
fill 520 164 275 520 171 275 minecraft:brown_terracotta
fill 520 164 317 520 165 317 minecraft:brown_terracotta
setblock 521 164 275 minecraft:white_concrete
setblock 521 164 298 minecraft:white_concrete
setblock 521 164 317 minecraft:white_concrete
fill 522 164 275 522 171 275 minecraft:brown_terracotta
fill 522 164 317 522 171 317 minecraft:brown_terracotta
fill 524 164 275 524 165 275 minecraft:brown_terracotta
setblock 524 164 291 minecraft:white_concrete
setblock 524 164 305 minecraft:white_concrete
fill 524 164 316 524 218 316 minecraft:white_concrete
fill 524 164 317 524 171 317 minecraft:brown_terracotta
setblock 525 164 275 minecraft:white_concrete
setblock 525 164 317 minecraft:white_concrete
fill 526 164 275 526 165 275 minecraft:brown_terracotta
fill 526 164 317 526 171 317 minecraft:brown_terracotta
fill 528 164 275 528 171 275 minecraft:brown_terracotta
fill 528 164 317 528 171 317 minecraft:brown_terracotta
setblock 529 164 275 minecraft:white_concrete
setblock 529 164 317 minecraft:white_concrete
fill 530 164 275 530 171 275 minecraft:brown_terracotta
fill 530 164 276 530 218 276 minecraft:white_concrete
fill 530 164 317 530 165 317 minecraft:brown_terracotta
setblock 531 164 288 minecraft:white_concrete
setblock 531 164 308 minecraft:white_concrete
fill 532 164 275 532 171 275 minecraft:brown_terracotta
fill 532 164 317 532 165 317 minecraft:brown_terracotta
setblock 533 164 275 minecraft:white_concrete
setblock 533 164 317 minecraft:white_concrete
fill 534 164 275 534 171 275 minecraft:brown_terracotta
fill 534 164 317 534 171 317 minecraft:brown_terracotta
fill 536 164 275 536 165 275 minecraft:brown_terracotta
fill 536 164 316 536 218 316 minecraft:white_concrete
fill 536 164 317 536 171 317 minecraft:brown_terracotta
setblock 537 164 275 minecraft:white_concrete
setblock 537 164 317 minecraft:white_concrete
fill 538 164 275 538 165 275 minecraft:brown_terracotta
setblock 538 164 291 minecraft:white_concrete
setblock 538 164 305 minecraft:white_concrete
fill 538 164 317 538 171 317 minecraft:brown_terracotta
fill 540 164 275 540 171 275 minecraft:brown_terracotta
fill 540 164 317 540 171 317 minecraft:brown_terracotta
setblock 541 164 275 minecraft:white_concrete
setblock 541 164 298 minecraft:white_concrete
setblock 541 164 317 minecraft:white_concrete
fill 542 164 275 542 171 275 minecraft:brown_terracotta
fill 542 164 276 542 218 276 minecraft:white_concrete
fill 542 164 317 542 165 317 minecraft:brown_terracotta
fill 544 164 275 544 171 275 minecraft:brown_terracotta
fill 544 164 317 544 165 317 minecraft:brown_terracotta
schedule function dropper:buildpart/71_3 1t
