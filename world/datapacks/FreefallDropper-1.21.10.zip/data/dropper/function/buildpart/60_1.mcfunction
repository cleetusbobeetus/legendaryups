setblock 3 36 278 minecraft:light[level=12]
fill 3 36 285 3 36 286 minecraft:light[level=12]
setblock 3 36 292 minecraft:light[level=12]
setblock 3 36 294 minecraft:light[level=12]
setblock 3 36 299 minecraft:light[level=12]
setblock 3 36 302 minecraft:light[level=12]
setblock 3 36 306 minecraft:light[level=12]
setblock 3 36 310 minecraft:light[level=12]
setblock 3 36 313 minecraft:light[level=12]
setblock 4 36 317 minecraft:cobbled_deepslate
setblock 7 36 275 minecraft:cobbled_deepslate
fill 10 36 278 11 36 278 minecraft:light[level=12]
setblock 10 36 285 minecraft:light[level=12]
setblock 10 36 292 minecraft:light[level=12]
setblock 10 36 299 minecraft:light[level=12]
setblock 10 36 306 minecraft:light[level=12]
setblock 10 36 313 minecraft:light[level=12]
setblock 11 36 286 minecraft:light[level=12]
setblock 11 36 294 minecraft:light[level=12]
setblock 11 36 302 minecraft:light[level=12]
setblock 11 36 310 minecraft:light[level=12]
setblock 17 36 278 minecraft:light[level=12]
setblock 17 36 285 minecraft:light[level=12]
setblock 17 36 299 minecraft:light[level=12]
setblock 17 36 306 minecraft:light[level=12]
setblock 17 36 313 minecraft:light[level=12]
setblock 19 36 278 minecraft:light[level=12]
setblock 19 36 286 minecraft:light[level=12]
setblock 19 36 294 minecraft:light[level=12]
setblock 19 36 302 minecraft:light[level=12]
setblock 19 36 310 minecraft:light[level=12]
fill 23 36 317 26 39 317 minecraft:blackstone
setblock 24 36 278 minecraft:light[level=12]
setblock 24 36 285 minecraft:light[level=12]
setblock 24 36 292 minecraft:light[level=12]
setblock 24 36 299 minecraft:light[level=12]
setblock 24 36 306 minecraft:light[level=12]
setblock 24 36 313 minecraft:light[level=12]
setblock 27 36 278 minecraft:light[level=12]
setblock 27 36 286 minecraft:light[level=12]
setblock 27 36 294 minecraft:light[level=12]
setblock 27 36 302 minecraft:light[level=12]
setblock 27 36 310 minecraft:light[level=12]
setblock 27 36 317 minecraft:crying_obsidian
fill 28 36 275 29 36 275 minecraft:cobbled_deepslate
fill 29 36 317 30 37 317 minecraft:cobbled_deepslate
setblock 31 36 278 minecraft:light[level=12]
setblock 31 36 285 minecraft:light[level=12]
setblock 31 36 292 minecraft:light[level=12]
setblock 31 36 299 minecraft:light[level=12]
setblock 31 36 306 minecraft:light[level=12]
setblock 31 36 313 minecraft:light[level=12]
setblock 31 36 317 minecraft:blackstone
setblock 35 36 278 minecraft:light[level=12]
setblock 35 36 286 minecraft:light[level=12]
setblock 35 36 294 minecraft:light[level=12]
setblock 35 36 302 minecraft:light[level=12]
setblock 35 36 310 minecraft:light[level=12]
setblock 37 36 275 minecraft:blackstone
fill 37 36 276 38 36 276 minecraft:amethyst_block
setblock 38 36 275 minecraft:amethyst_block
fill 38 36 277 39 36 277 minecraft:amethyst_block
setblock 38 36 278 minecraft:light[level=12]
setblock 38 36 285 minecraft:light[level=12]
setblock 38 36 292 minecraft:light[level=12]
setblock 38 36 299 minecraft:light[level=12]
setblock 38 36 306 minecraft:light[level=12]
setblock 38 36 313 minecraft:light[level=12]
fill 39 36 275 40 39 275 minecraft:blackstone
fill 42 36 276 42 37 277 minecraft:blackstone
setblock 42 36 278 minecraft:cobbled_deepslate
fill 42 36 279 42 39 279 minecraft:blackstone
setblock 42 36 280 minecraft:cobbled_deepslate
setblock 42 36 282 minecraft:purple_concrete
fill 42 36 290 42 38 290 minecraft:cobbled_deepslate
fill 42 36 291 42 39 291 minecraft:blackstone
fill 42 36 293 42 39 296 minecraft:blackstone
setblock 42 36 297 minecraft:cobbled_deepslate
fill 0 37 276 0 37 277 minecraft:blackstone
fill 0 37 280 0 39 280 minecraft:blackstone
fill 0 37 291 0 39 291 minecraft:blackstone
fill 0 37 299 0 39 299 minecraft:blackstone
setblock 0 37 304 minecraft:cobbled_deepslate
setblock 0 37 311 minecraft:cobbled_deepslate
fill 0 37 312 0 39 312 minecraft:blackstone
setblock 0 37 316 minecraft:purple_concrete
fill 0 37 317 1 37 317 minecraft:blackstone
setblock 4 37 275 minecraft:cobbled_deepslate
fill 4 37 317 4 39 317 minecraft:blackstone
fill 5 37 275 7 37 275 minecraft:blackstone
setblock 6 37 317 minecraft:cobbled_deepslate
fill 8 37 312 8 43 312 minecraft:polished_blackstone
setblock 10 37 275 minecraft:cobbled_deepslate
fill 10 37 317 11 37 317 minecraft:blackstone
fill 11 37 275 13 37 275 minecraft:blackstone
setblock 12 37 317 minecraft:cobbled_deepslate
setblock 15 37 275 minecraft:cobbled_deepslate
fill 17 37 275 19 39 275 minecraft:blackstone
setblock 20 37 275 minecraft:cobbled_deepslate
setblock 20 37 317 minecraft:cobbled_deepslate
fill 21 37 275 24 37 275 minecraft:blackstone
fill 21 37 312 24 44 312 minecraft:blackstone
fill 22 37 311 23 44 311 minecraft:blackstone
fill 22 37 313 24 44 313 minecraft:blackstone
setblock 22 37 317 minecraft:cobbled_deepslate
setblock 25 37 275 minecraft:cobbled_deepslate
setblock 27 37 275 minecraft:cobbled_deepslate
fill 27 37 317 27 39 317 minecraft:blackstone
fill 28 37 275 29 39 275 minecraft:blackstone
setblock 31 37 317 minecraft:cobbled_deepslate
fill 37 37 275 37 38 275 minecraft:cobbled_deepslate
fill 38 37 275 38 38 275 minecraft:blackstone
setblock 40 37 317 minecraft:cobbled_deepslate
fill 41 37 317 41 40 317 minecraft:blackstone
fill 42 37 278 42 39 278 minecraft:blackstone
fill 42 37 280 42 39 280 minecraft:blackstone
fill 42 37 282 42 38 282 minecraft:blackstone
fill 42 37 297 42 39 297 minecraft:blackstone
setblock 42 37 305 minecraft:cobbled_deepslate
setblock 42 37 317 minecraft:cobbled_deepslate
fill 0 38 276 0 38 277 minecraft:cobbled_deepslate
setblock 0 38 282 minecraft:cobbled_deepslate
setblock 0 38 289 minecraft:cobbled_deepslate
fill 0 38 304 0 39 304 minecraft:blackstone
fill 0 38 306 0 39 306 minecraft:blackstone
setblock 0 38 307 minecraft:cobbled_deepslate
fill 0 38 308 0 40 308 minecraft:blackstone
setblock 0 38 310 minecraft:cobbled_deepslate
fill 0 38 311 0 39 311 minecraft:blackstone
setblock 0 38 313 minecraft:cobbled_deepslate
fill 0 38 314 0 39 316 minecraft:blackstone
setblock 0 38 317 minecraft:cobbled_deepslate
fill 1 38 317 1 39 317 minecraft:blackstone
setblock 2 38 317 minecraft:crying_obsidian
fill 4 38 275 4 39 275 minecraft:blackstone
setblock 5 38 275 minecraft:cobbled_deepslate
fill 6 38 275 7 39 275 minecraft:blackstone
fill 6 38 317 6 39 317 minecraft:blackstone
fill 10 38 275 11 39 275 minecraft:blackstone
setblock 10 38 317 minecraft:cobbled_deepslate
fill 11 38 317 12 39 317 minecraft:blackstone
setblock 12 38 275 minecraft:cobbled_deepslate
fill 13 38 275 13 39 275 minecraft:blackstone
fill 15 38 275 15 39 275 minecraft:blackstone
setblock 17 38 317 minecraft:cobbled_deepslate
fill 20 38 275 23 39 275 minecraft:blackstone
fill 20 38 317 20 39 317 minecraft:blackstone
fill 21 38 311 21 44 311 minecraft:blackstone
fill 21 38 313 21 44 313 minecraft:blackstone
fill 22 38 314 23 44 314 minecraft:blackstone
fill 22 38 317 22 39 317 minecraft:blackstone
setblock 24 38 275 minecraft:cobbled_deepslate
fill 24 38 311 24 44 311 minecraft:blackstone
fill 25 38 275 25 39 275 minecraft:blackstone
fill 27 38 275 27 39 275 minecraft:blackstone
fill 29 38 317 31 39 317 minecraft:blackstone
fill 31 38 275 32 39 275 minecraft:blackstone
setblock 32 38 317 minecraft:cobbled_deepslate
setblock 33 38 275 minecraft:cobbled_deepslate
fill 40 38 317 40 39 317 minecraft:blackstone
fill 41 38 275 41 39 275 minecraft:blackstone
setblock 42 38 275 minecraft:cobbled_deepslate
fill 42 38 276 42 39 276 minecraft:blackstone
setblock 42 38 277 minecraft:cobbled_deepslate
setblock 42 38 281 minecraft:cobbled_deepslate
fill 42 38 302 42 39 302 minecraft:blackstone
setblock 42 38 303 minecraft:cobbled_deepslate
fill 42 38 305 42 39 305 minecraft:blackstone
fill 42 38 315 42 39 315 minecraft:blackstone
setblock 42 38 316 minecraft:purple_concrete
fill 42 38 317 42 39 317 minecraft:blackstone
fill 0 39 276 0 39 277 minecraft:blackstone
setblock 0 39 282 minecraft:blackstone
setblock 0 39 289 minecraft:blackstone
setblock 0 39 307 minecraft:blackstone
setblock 0 39 310 minecraft:blackstone
setblock 0 39 313 minecraft:blackstone
setblock 0 39 317 minecraft:blackstone
fill 2 39 317 2 40 317 minecraft:blackstone
setblock 5 39 275 minecraft:blackstone
fill 7 39 312 7 43 312 minecraft:polished_blackstone
fill 8 39 311 8 43 311 minecraft:polished_blackstone
fill 8 39 313 8 43 313 minecraft:polished_blackstone
fill 9 39 312 9 43 312 minecraft:polished_blackstone
setblock 10 39 317 minecraft:blackstone
setblock 12 39 275 minecraft:blackstone
setblock 17 39 317 minecraft:blackstone
fill 20 39 312 20 44 312 minecraft:blackstone
fill 21 39 314 21 44 314 minecraft:blackstone
fill 22 39 310 23 44 310 minecraft:blackstone
setblock 24 39 275 minecraft:blackstone
fill 24 39 314 24 44 314 minecraft:blackstone
fill 25 39 312 25 44 313 minecraft:blackstone
setblock 32 39 317 minecraft:blackstone
fill 33 39 275 33 40 275 minecraft:blackstone
fill 37 39 275 37 40 275 minecraft:blackstone
setblock 38 39 275 minecraft:crying_obsidian
setblock 42 39 275 minecraft:blackstone
setblock 42 39 277 minecraft:blackstone
fill 42 39 281 42 40 281 minecraft:blackstone
setblock 42 39 282 minecraft:crying_obsidian
setblock 42 39 290 minecraft:blackstone
setblock 42 39 303 minecraft:blackstone
setblock 42 39 316 minecraft:blackstone
fill 0 40 275 0 43 291 minecraft:cobbled_deepslate
fill 0 40 293 0 111 293 minecraft:cobbled_deepslate
setblock 0 40 294 minecraft:blackstone
setblock 0 40 295 minecraft:crying_obsidian
fill 0 40 296 0 43 297 minecraft:cobbled_deepslate
setblock 0 40 298 minecraft:magma_block
fill 0 40 299 0 40 307 minecraft:cobbled_deepslate
fill 0 40 309 0 118 313 minecraft:cobbled_deepslate
setblock 0 40 314 minecraft:blackstone
fill 0 40 315 0 41 317 minecraft:cobbled_deepslate
fill 1 40 275 19 40 275 minecraft:cobbled_deepslate
setblock 1 40 317 minecraft:cobbled_deepslate
fill 4 40 317 33 40 317 minecraft:cobbled_deepslate
fill 20 40 275 21 40 275 minecraft:blackstone
fill 20 40 311 20 44 311 minecraft:blackstone
fill 20 40 313 20 44 314 minecraft:blackstone
fill 21 40 310 21 44 310 minecraft:blackstone
fill 21 40 315 24 44 315 minecraft:blackstone
fill 22 40 275 29 46 275 minecraft:cobbled_deepslate
fill 24 40 310 24 44 310 minecraft:blackstone
fill 25 40 311 25 44 311 minecraft:blackstone
fill 25 40 314 25 44 314 minecraft:blackstone
setblock 30 40 275 minecraft:crying_obsidian
fill 31 40 275 32 129 275 minecraft:cobbled_deepslate
fill 34 40 275 36 41 275 minecraft:cobbled_deepslate
setblock 34 40 317 minecraft:blackstone
fill 35 40 317 40 40 317 minecraft:cobbled_deepslate
setblock 38 40 275 minecraft:blackstone
fill 39 40 275 42 40 275 minecraft:cobbled_deepslate
fill 42 40 276 42 40 280 minecraft:cobbled_deepslate
fill 42 40 282 42 46 285 minecraft:cobbled_deepslate
fill 42 40 286 42 41 286 minecraft:blackstone
fill 42 40 287 42 109 290 minecraft:cobbled_deepslate
setblock 42 40 291 minecraft:amethyst_block
fill 42 40 292 42 40 308 minecraft:cobbled_deepslate
setblock 42 40 309 minecraft:magma_block
fill 42 40 311 42 40 317 minecraft:cobbled_deepslate
fill 0 41 292 0 129 292 minecraft:cobbled_deepslate
fill 0 41 294 0 59 295 minecraft:cobbled_deepslate
fill 0 41 298 0 57 304 minecraft:cobbled_deepslate
setblock 0 41 305 minecraft:blackstone
fill 0 41 306 0 87 308 minecraft:cobbled_deepslate
fill 0 41 314 0 100 314 minecraft:cobbled_deepslate
fill 1 41 275 4 75 275 minecraft:cobbled_deepslate
fill 1 41 317 1 42 317 minecraft:blackstone
fill 2 41 317 13 41 317 minecraft:cobbled_deepslate
fill 5 41 275 5 42 275 minecraft:blackstone
setblock 6 41 275 minecraft:cobbled_deepslate
setblock 7 41 275 minecraft:blackstone
fill 7 41 311 7 43 311 minecraft:polished_blackstone
fill 7 41 313 7 43 313 minecraft:polished_blackstone
fill 8 41 275 16 41 275 minecraft:cobbled_deepslate
fill 9 41 311 9 43 311 minecraft:polished_blackstone
fill 9 41 313 9 43 313 minecraft:polished_blackstone
setblock 14 41 317 minecraft:blackstone
fill 15 41 317 18 102 317 minecraft:cobbled_deepslate
setblock 17 41 275 minecraft:blackstone
fill 18 41 275 21 67 275 minecraft:cobbled_deepslate
fill 19 41 312 19 44 312 minecraft:blackstone
fill 19 41 317 19 42 317 minecraft:blackstone
fill 20 41 310 20 44 310 minecraft:blackstone
fill 20 41 317 26 41 317 minecraft:cobbled_deepslate
fill 22 41 309 23 44 309 minecraft:blackstone
fill 25 41 310 25 44 310 minecraft:blackstone
fill 26 41 312 26 44 313 minecraft:blackstone
setblock 27 41 317 minecraft:blackstone
fill 28 41 317 28 129 317 minecraft:cobbled_deepslate
setblock 29 41 317 minecraft:blackstone
setblock 30 41 275 minecraft:cobbled_deepslate
fill 30 41 317 34 67 317 minecraft:cobbled_deepslate
fill 33 41 275 33 51 275 minecraft:cobbled_deepslate
setblock 35 41 317 minecraft:blackstone
fill 36 41 317 42 41 317 minecraft:cobbled_deepslate
fill 37 41 275 39 53 275 minecraft:cobbled_deepslate
setblock 40 41 275 minecraft:blackstone
fill 41 41 275 42 77 275 minecraft:cobbled_deepslate
fill 42 41 276 42 87 277 minecraft:cobbled_deepslate
setblock 42 41 278 minecraft:blackstone
fill 42 41 279 42 78 281 minecraft:cobbled_deepslate
fill 42 41 291 42 75 295 minecraft:cobbled_deepslate
setblock 42 41 296 minecraft:purple_concrete
fill 42 41 297 42 49 302 minecraft:cobbled_deepslate
setblock 42 41 303 minecraft:blackstone
fill 42 41 304 42 41 312 minecraft:cobbled_deepslate
fill 42 41 313 42 41 314 minecraft:blackstone
fill 42 41 315 42 88 316 minecraft:cobbled_deepslate
fill 0 42 305 0 129 305 minecraft:cobbled_deepslate
setblock 0 42 315 minecraft:blackstone
fill 0 42 316 0 68 317 minecraft:cobbled_deepslate
fill 2 42 317 2 57 317 minecraft:cobbled_deepslate
fill 3 42 278 3 43 278 minecraft:light[level=12]
setblock 3 42 285 minecraft:light[level=12]
setblock 3 42 292 minecraft:light[level=12]
setblock 3 42 299 minecraft:light[level=12]
setblock 3 42 306 minecraft:light[level=12]
setblock 3 42 313 minecraft:light[level=12]
fill 3 42 317 4 42 317 minecraft:blackstone
fill 5 42 317 5 129 317 minecraft:cobbled_deepslate
setblock 6 42 275 minecraft:blackstone
setblock 6 42 317 minecraft:blackstone
fill 7 42 275 8 93 275 minecraft:cobbled_deepslate
fill 7 42 317 10 126 317 minecraft:cobbled_deepslate
setblock 9 42 275 minecraft:blackstone
fill 10 42 275 12 80 275 minecraft:cobbled_deepslate
setblock 10 42 278 minecraft:light[level=12]
setblock 10 42 285 minecraft:light[level=12]
setblock 10 42 292 minecraft:light[level=12]
setblock 10 42 299 minecraft:light[level=12]
setblock 10 42 306 minecraft:light[level=12]
setblock 10 42 313 minecraft:light[level=12]
setblock 11 42 317 minecraft:blackstone
fill 12 42 317 14 102 317 minecraft:cobbled_deepslate
fill 13 42 275 14 42 275 minecraft:blackstone
fill 15 42 275 17 97 275 minecraft:cobbled_deepslate
setblock 17 42 278 minecraft:light[level=12]
setblock 17 42 285 minecraft:light[level=12]
setblock 17 42 299 minecraft:light[level=12]
setblock 17 42 306 minecraft:light[level=12]
setblock 17 42 313 minecraft:light[level=12]
fill 19 42 311 19 44 311 minecraft:blackstone
fill 19 42 313 19 44 314 minecraft:blackstone
fill 20 42 315 20 44 315 minecraft:blackstone
fill 20 42 317 22 42 317 minecraft:blackstone
fill 21 42 309 21 44 309 minecraft:blackstone
fill 21 42 316 24 44 316 minecraft:blackstone
fill 23 42 317 27 122 317 minecraft:cobbled_deepslate
setblock 24 42 278 minecraft:light[level=12]
setblock 24 42 285 minecraft:light[level=12]
setblock 24 42 292 minecraft:light[level=12]
setblock 24 42 299 minecraft:light[level=12]
setblock 24 42 306 minecraft:light[level=12]
fill 24 42 309 24 44 309 minecraft:blackstone
fill 25 42 315 25 44 315 minecraft:blackstone
fill 26 42 311 26 44 311 minecraft:blackstone
fill 26 42 314 26 44 314 minecraft:blackstone
fill 29 42 317 29 67 317 minecraft:cobbled_deepslate
setblock 30 42 275 minecraft:blackstone
setblock 31 42 278 minecraft:light[level=12]
setblock 31 42 285 minecraft:light[level=12]
setblock 31 42 292 minecraft:light[level=12]
setblock 31 42 299 minecraft:light[level=12]
setblock 31 42 306 minecraft:light[level=12]
setblock 31 42 313 minecraft:light[level=12]
fill 34 42 275 34 129 275 minecraft:cobbled_deepslate
fill 35 42 275 36 42 275 minecraft:blackstone
fill 35 42 317 36 78 317 minecraft:cobbled_deepslate
setblock 37 42 317 minecraft:blackstone
setblock 38 42 278 minecraft:light[level=12]
setblock 38 42 285 minecraft:light[level=12]
setblock 38 42 292 minecraft:light[level=12]
setblock 38 42 299 minecraft:light[level=12]
setblock 38 42 306 minecraft:light[level=12]
setblock 38 42 313 minecraft:light[level=12]
fill 38 42 317 39 121 317 minecraft:cobbled_deepslate
fill 40 42 275 40 125 275 minecraft:cobbled_deepslate
setblock 40 42 317 minecraft:blackstone
fill 41 42 317 42 90 317 minecraft:cobbled_deepslate
fill 42 42 278 42 49 278 minecraft:cobbled_deepslate
fill 42 42 286 42 74 286 minecraft:cobbled_deepslate
fill 42 42 296 42 130 296 minecraft:cobbled_deepslate
fill 42 42 303 42 65 306 minecraft:cobbled_deepslate
setblock 42 42 307 minecraft:blackstone
fill 42 42 308 42 44 314 minecraft:cobbled_deepslate
fill 0 43 315 0 60 315 minecraft:cobbled_deepslate
fill 1 43 317 1 67 317 minecraft:cobbled_deepslate
setblock 3 43 286 minecraft:light[level=12]
setblock 3 43 294 minecraft:light[level=12]
setblock 3 43 302 minecraft:light[level=12]
setblock 3 43 310 minecraft:light[level=12]
fill 3 43 317 4 45 317 minecraft:cobbled_deepslate
fill 5 43 275 6 129 275 minecraft:cobbled_deepslate
fill 6 43 317 6 120 317 minecraft:cobbled_deepslate
fill 9 43 275 9 50 275 minecraft:cobbled_deepslate
setblock 11 43 278 minecraft:light[level=12]
setblock 11 43 286 minecraft:light[level=12]
setblock 11 43 294 minecraft:light[level=12]
setblock 11 43 302 minecraft:light[level=12]
setblock 11 43 310 minecraft:light[level=12]
fill 11 43 317 11 129 317 minecraft:cobbled_deepslate
fill 13 43 275 14 81 275 minecraft:cobbled_deepslate
setblock 19 43 278 minecraft:light[level=12]
setblock 19 43 286 minecraft:light[level=12]
setblock 19 43 294 minecraft:light[level=12]
setblock 19 43 302 minecraft:light[level=12]
fill 19 43 310 19 44 310 minecraft:blackstone
fill 19 43 315 19 44 315 minecraft:blackstone
fill 19 43 317 22 46 317 minecraft:cobbled_deepslate
fill 20 43 309 20 44 309 minecraft:blackstone
fill 20 43 316 20 44 316 minecraft:blackstone
fill 22 43 308 23 44 308 minecraft:blackstone
fill 25 43 309 25 44 309 minecraft:blackstone
fill 25 43 316 25 44 316 minecraft:blackstone
fill 26 43 310 26 44 310 minecraft:blackstone
fill 26 43 315 26 44 315 minecraft:blackstone
setblock 27 43 278 minecraft:light[level=12]
setblock 27 43 286 minecraft:light[level=12]
setblock 27 43 294 minecraft:light[level=12]
setblock 27 43 302 minecraft:light[level=12]
setblock 27 43 310 minecraft:light[level=12]
fill 27 43 312 27 44 313 minecraft:blackstone
fill 30 43 275 30 100 275 minecraft:cobbled_deepslate
fill 35 43 275 36 69 275 minecraft:cobbled_deepslate
setblock 35 43 278 minecraft:light[level=12]
setblock 35 43 286 minecraft:light[level=12]
setblock 35 43 294 minecraft:light[level=12]
setblock 35 43 302 minecraft:light[level=12]
setblock 35 43 310 minecraft:light[level=12]
fill 37 43 317 37 45 317 minecraft:cobbled_deepslate
fill 40 43 317 40 129 317 minecraft:cobbled_deepslate
fill 42 43 307 42 129 307 minecraft:cobbled_deepslate
fill 0 44 275 0 83 289 minecraft:cobbled_deepslate
setblock 0 44 290 minecraft:purple_concrete
fill 0 44 291 0 129 291 minecraft:cobbled_deepslate
fill 0 44 296 0 129 296 minecraft:cobbled_deepslate
setblock 0 44 297 minecraft:crying_obsidian
fill 18 44 311 18 44 314 minecraft:blackstone
setblock 19 44 309 minecraft:blackstone
setblock 21 44 308 minecraft:blackstone
setblock 24 44 308 minecraft:blackstone
setblock 26 44 309 minecraft:blackstone
setblock 26 44 316 minecraft:blackstone
setblock 27 44 311 minecraft:blackstone
setblock 27 44 314 minecraft:blackstone
fill 0 45 290 0 127 290 minecraft:cobbled_deepslate
fill 0 45 297 0 60 297 minecraft:cobbled_deepslate
fill 22 45 312 23 47 313 minecraft:amethyst_block
fill 42 45 308 42 48 313 minecraft:cobbled_deepslate
setblock 42 45 314 minecraft:magma_block
setblock 3 46 317 minecraft:purple_concrete
fill 4 46 317 4 125 317 minecraft:cobbled_deepslate
setblock 37 46 317 minecraft:crying_obsidian
fill 42 46 314 42 102 314 minecraft:cobbled_deepslate
fill 1 47 301 2 50 303 minecraft:amethyst_block
fill 3 47 317 3 78 317 minecraft:cobbled_deepslate
fill 19 47 317 21 85 317 minecraft:cobbled_deepslate
fill 22 47 275 24 49 275 minecraft:cobbled_deepslate
setblock 22 47 317 minecraft:magma_block
setblock 25 47 275 minecraft:amethyst_block
fill 26 47 275 29 110 275 minecraft:cobbled_deepslate
fill 37 47 317 37 129 317 minecraft:cobbled_deepslate
fill 42 47 282 42 60 284 minecraft:cobbled_deepslate
setblock 42 47 285 minecraft:amethyst_block
fill 1 48 300 1 49 300 minecraft:amethyst_block
fill 1 48 304 1 49 304 minecraft:amethyst_block
setblock 3 48 278 minecraft:light[level=12]
setblock 3 48 285 minecraft:light[level=12]
setblock 3 48 292 minecraft:light[level=12]
setblock 3 48 299 minecraft:light[level=12]
fill 3 48 301 3 49 303 minecraft:amethyst_block
setblock 3 48 306 minecraft:light[level=12]
setblock 3 48 313 minecraft:light[level=12]
fill 4 48 302 4 49 302 minecraft:amethyst_block
setblock 10 48 278 minecraft:light[level=12]
setblock 10 48 285 minecraft:light[level=12]
setblock 10 48 292 minecraft:light[level=12]
setblock 10 48 299 minecraft:light[level=12]
setblock 10 48 306 minecraft:light[level=12]
setblock 10 48 313 minecraft:light[level=12]
setblock 17 48 278 minecraft:light[level=12]
setblock 17 48 285 minecraft:light[level=12]
setblock 17 48 299 minecraft:light[level=12]
setblock 17 48 306 minecraft:light[level=12]
setblock 17 48 313 minecraft:light[level=12]
setblock 22 48 317 minecraft:purple_concrete
setblock 24 48 278 minecraft:light[level=12]
setblock 24 48 285 minecraft:light[level=12]
setblock 24 48 292 minecraft:light[level=12]
setblock 24 48 299 minecraft:light[level=12]
setblock 24 48 306 minecraft:light[level=12]
setblock 24 48 313 minecraft:light[level=12]
fill 25 48 275 25 129 275 minecraft:cobbled_deepslate
setblock 31 48 278 minecraft:light[level=12]
setblock 31 48 285 minecraft:light[level=12]
setblock 31 48 292 minecraft:light[level=12]
setblock 31 48 299 minecraft:light[level=12]
setblock 31 48 306 minecraft:light[level=12]
setblock 31 48 313 minecraft:light[level=12]
setblock 38 48 278 minecraft:light[level=12]
setblock 38 48 285 minecraft:light[level=12]
setblock 38 48 292 minecraft:light[level=12]
setblock 38 48 299 minecraft:light[level=12]
setblock 38 48 306 minecraft:light[level=12]
setblock 38 48 313 minecraft:light[level=12]
fill 42 48 285 42 97 285 minecraft:cobbled_deepslate
setblock 4 49 301 minecraft:amethyst_block
setblock 4 49 303 minecraft:amethyst_block
setblock 5 49 302 minecraft:amethyst_block
fill 22 49 317 22 90 317 minecraft:cobbled_deepslate
fill 42 49 308 42 98 308 minecraft:cobbled_deepslate
setblock 42 49 309 minecraft:magma_block
fill 42 49 310 42 109 313 minecraft:cobbled_deepslate
setblock 3 50 278 minecraft:light[level=12]
setblock 3 50 286 minecraft:light[level=12]
setblock 3 50 294 minecraft:light[level=12]
setblock 3 50 302 minecraft:amethyst_block
setblock 3 50 310 minecraft:light[level=12]
setblock 11 50 278 minecraft:light[level=12]
setblock 11 50 286 minecraft:light[level=12]
setblock 11 50 294 minecraft:light[level=12]
setblock 11 50 302 minecraft:light[level=12]
setblock 11 50 310 minecraft:light[level=12]
setblock 19 50 278 minecraft:light[level=12]
setblock 19 50 286 minecraft:light[level=12]
setblock 19 50 294 minecraft:light[level=12]
setblock 19 50 302 minecraft:light[level=12]
setblock 19 50 310 minecraft:light[level=12]
fill 22 50 275 22 130 275 minecraft:cobbled_deepslate
setblock 23 50 275 minecraft:purple_concrete
fill 24 50 275 24 129 275 minecraft:cobbled_deepslate
setblock 27 50 278 minecraft:light[level=12]
setblock 27 50 286 minecraft:light[level=12]
setblock 27 50 294 minecraft:light[level=12]
setblock 27 50 302 minecraft:light[level=12]
setblock 27 50 310 minecraft:light[level=12]
setblock 35 50 278 minecraft:light[level=12]
setblock 35 50 286 minecraft:light[level=12]
setblock 35 50 294 minecraft:light[level=12]
setblock 35 50 302 minecraft:light[level=12]
setblock 35 50 310 minecraft:light[level=12]
setblock 42 50 278 minecraft:crying_obsidian
fill 42 50 297 42 59 301 minecraft:cobbled_deepslate
setblock 42 50 302 minecraft:magma_block
fill 42 50 309 42 129 309 minecraft:cobbled_deepslate
setblock 9 51 275 minecraft:crying_obsidian
fill 23 51 275 23 129 275 minecraft:cobbled_deepslate
fill 42 51 278 42 105 278 minecraft:cobbled_deepslate
fill 42 51 302 42 98 302 minecraft:cobbled_deepslate
fill 9 52 275 9 125 275 minecraft:cobbled_deepslate
setblock 33 52 275 minecraft:purple_concrete
fill 33 53 275 33 78 275 minecraft:cobbled_deepslate
fill 2 54 311 2 59 311 minecraft:blackstone
setblock 3 54 278 minecraft:light[level=12]
setblock 3 54 285 minecraft:light[level=12]
setblock 3 54 292 minecraft:light[level=12]
setblock 3 54 299 minecraft:light[level=12]
setblock 3 54 306 minecraft:light[level=12]
setblock 3 54 313 minecraft:light[level=12]
setblock 10 54 278 minecraft:light[level=12]
setblock 10 54 285 minecraft:light[level=12]
setblock 10 54 292 minecraft:light[level=12]
setblock 10 54 299 minecraft:light[level=12]
setblock 10 54 306 minecraft:light[level=12]
setblock 10 54 313 minecraft:light[level=12]
setblock 17 54 278 minecraft:light[level=12]
setblock 17 54 285 minecraft:light[level=12]
setblock 17 54 299 minecraft:light[level=12]
setblock 17 54 306 minecraft:light[level=12]
setblock 17 54 313 minecraft:light[level=12]
setblock 24 54 278 minecraft:light[level=12]
setblock 24 54 285 minecraft:light[level=12]
setblock 24 54 292 minecraft:light[level=12]
setblock 24 54 299 minecraft:light[level=12]
setblock 24 54 306 minecraft:light[level=12]
setblock 24 54 313 minecraft:light[level=12]
setblock 31 54 278 minecraft:light[level=12]
setblock 31 54 285 minecraft:light[level=12]
setblock 31 54 292 minecraft:light[level=12]
setblock 31 54 299 minecraft:light[level=12]
setblock 31 54 306 minecraft:light[level=12]
setblock 31 54 313 minecraft:light[level=12]
fill 37 54 275 38 126 275 minecraft:cobbled_deepslate
setblock 38 54 278 minecraft:light[level=12]
setblock 38 54 285 minecraft:light[level=12]
setblock 38 54 292 minecraft:light[level=12]
setblock 38 54 299 minecraft:light[level=12]
setblock 38 54 306 minecraft:light[level=12]
setblock 38 54 313 minecraft:light[level=12]
setblock 39 54 275 minecraft:purple_concrete
fill 23 55 281 24 56 281 minecraft:gold_block
fill 24 55 280 24 56 280 minecraft:gold_block
fill 24 55 282 24 56 282 minecraft:gold_block
fill 39 55 275 39 94 275 minecraft:cobbled_deepslate
fill 1 57 311 1 59 311 minecraft:blackstone
fill 2 57 310 2 59 310 minecraft:blackstone
fill 2 57 312 2 59 312 minecraft:blackstone
setblock 3 57 278 minecraft:light[level=12]
setblock 3 57 286 minecraft:light[level=12]
setblock 3 57 294 minecraft:light[level=12]
setblock 3 57 302 minecraft:light[level=12]
setblock 3 57 310 minecraft:light[level=12]
fill 3 57 311 3 59 311 minecraft:blackstone
setblock 11 57 278 minecraft:light[level=12]
setblock 11 57 286 minecraft:light[level=12]
setblock 11 57 294 minecraft:light[level=12]
setblock 11 57 302 minecraft:light[level=12]
setblock 11 57 310 minecraft:light[level=12]
fill 16 57 283 16 58 283 minecraft:gold_block
setblock 19 57 278 minecraft:light[level=12]
setblock 19 57 286 minecraft:light[level=12]
setblock 19 57 294 minecraft:light[level=12]
setblock 19 57 302 minecraft:light[level=12]
setblock 19 57 310 minecraft:light[level=12]
setblock 27 57 278 minecraft:light[level=12]
setblock 27 57 286 minecraft:light[level=12]
setblock 27 57 294 minecraft:light[level=12]
setblock 27 57 302 minecraft:light[level=12]
setblock 27 57 310 minecraft:light[level=12]
setblock 35 57 278 minecraft:light[level=12]
setblock 35 57 286 minecraft:light[level=12]
setblock 35 57 294 minecraft:light[level=12]
setblock 35 57 302 minecraft:light[level=12]
setblock 35 57 310 minecraft:light[level=12]
fill 0 58 298 0 59 300 minecraft:cobbled_deepslate
setblock 0 58 301 minecraft:crying_obsidian
fill 0 58 302 0 74 304 minecraft:cobbled_deepslate
fill 1 58 310 1 59 310 minecraft:blackstone
fill 1 58 312 1 59 312 minecraft:blackstone
setblock 2 58 317 minecraft:magma_block
fill 3 58 310 3 59 310 minecraft:blackstone
fill 3 58 312 3 59 312 minecraft:blackstone
fill 0 59 301 0 125 301 minecraft:cobbled_deepslate
fill 1 59 298 1 61 299 minecraft:amethyst_block
fill 2 59 317 2 128 317 minecraft:cobbled_deepslate
fill 0 60 294 0 91 294 minecraft:cobbled_deepslate
setblock 0 60 295 minecraft:crying_obsidian
fill 0 60 298 0 61 298 minecraft:amethyst_block
fill 0 60 299 0 125 300 minecraft:cobbled_deepslate
fill 1 60 297 1 61 297 minecraft:amethyst_block
fill 2 60 298 2 60 299 minecraft:amethyst_block
setblock 3 60 278 minecraft:light[level=12]
setblock 3 60 285 minecraft:light[level=12]
setblock 3 60 292 minecraft:light[level=12]
setblock 3 60 299 minecraft:light[level=12]
setblock 3 60 306 minecraft:light[level=12]
setblock 3 60 313 minecraft:light[level=12]
setblock 10 60 278 minecraft:light[level=12]
setblock 10 60 285 minecraft:light[level=12]
setblock 10 60 292 minecraft:light[level=12]
setblock 10 60 299 minecraft:light[level=12]
setblock 10 60 306 minecraft:light[level=12]
setblock 10 60 313 minecraft:light[level=12]
setblock 17 60 278 minecraft:light[level=12]
setblock 17 60 285 minecraft:light[level=12]
setblock 17 60 299 minecraft:light[level=12]
setblock 17 60 306 minecraft:light[level=12]
setblock 17 60 313 minecraft:light[level=12]
setblock 24 60 278 minecraft:light[level=12]
setblock 24 60 285 minecraft:light[level=12]
setblock 24 60 292 minecraft:light[level=12]
setblock 24 60 299 minecraft:light[level=12]
setblock 24 60 306 minecraft:light[level=12]
setblock 24 60 313 minecraft:light[level=12]
setblock 31 60 278 minecraft:light[level=12]
setblock 31 60 285 minecraft:light[level=12]
setblock 31 60 292 minecraft:light[level=12]
setblock 31 60 299 minecraft:light[level=12]
setblock 31 60 306 minecraft:light[level=12]
setblock 31 60 313 minecraft:light[level=12]
setblock 38 60 278 minecraft:light[level=12]
setblock 38 60 285 minecraft:light[level=12]
setblock 38 60 292 minecraft:light[level=12]
setblock 38 60 299 minecraft:light[level=12]
setblock 38 60 306 minecraft:light[level=12]
setblock 38 60 313 minecraft:light[level=12]
fill 42 60 297 42 98 299 minecraft:cobbled_deepslate
setblock 42 60 300 minecraft:purple_concrete
fill 42 60 301 42 97 301 minecraft:cobbled_deepslate
fill 0 61 295 0 86 295 minecraft:cobbled_deepslate
setblock 0 61 297 minecraft:amethyst_block
setblock 0 61 315 minecraft:purple_concrete
fill 2 61 297 2 61 298 minecraft:amethyst_block
fill 17 61 314 17 65 314 minecraft:blackstone
fill 42 61 282 42 69 283 minecraft:cobbled_deepslate
setblock 42 61 284 minecraft:purple_concrete
fill 42 61 300 42 98 300 minecraft:cobbled_deepslate
fill 0 62 297 0 127 298 minecraft:cobbled_deepslate
fill 0 62 315 0 129 315 minecraft:cobbled_deepslate
setblock 1 62 298 minecraft:amethyst_block
fill 42 62 284 42 127 284 minecraft:cobbled_deepslate
setblock 3 64 278 minecraft:light[level=12]
setblock 3 64 286 minecraft:light[level=12]
setblock 3 64 294 minecraft:light[level=12]
setblock 3 64 302 minecraft:light[level=12]
setblock 3 64 310 minecraft:light[level=12]
setblock 11 64 278 minecraft:light[level=12]
setblock 11 64 286 minecraft:light[level=12]
setblock 11 64 294 minecraft:light[level=12]
setblock 11 64 302 minecraft:light[level=12]
setblock 11 64 310 minecraft:light[level=12]
fill 16 64 314 16 65 314 minecraft:blackstone
fill 17 64 313 17 65 313 minecraft:blackstone
fill 17 64 315 17 65 315 minecraft:blackstone
fill 18 64 314 18 65 314 minecraft:blackstone
setblock 19 64 278 minecraft:light[level=12]
setblock 19 64 286 minecraft:light[level=12]
setblock 19 64 294 minecraft:light[level=12]
setblock 19 64 302 minecraft:light[level=12]
setblock 19 64 310 minecraft:light[level=12]
setblock 27 64 278 minecraft:light[level=12]
setblock 27 64 286 minecraft:light[level=12]
setblock 27 64 294 minecraft:light[level=12]
setblock 27 64 302 minecraft:light[level=12]
setblock 27 64 310 minecraft:light[level=12]
setblock 35 64 278 minecraft:light[level=12]
setblock 35 64 286 minecraft:light[level=12]
setblock 35 64 294 minecraft:light[level=12]
setblock 35 64 302 minecraft:light[level=12]
setblock 35 64 310 minecraft:light[level=12]
setblock 16 65 313 minecraft:blackstone
setblock 16 65 315 minecraft:blackstone
setblock 18 65 313 minecraft:blackstone
setblock 18 65 315 minecraft:blackstone
setblock 3 66 278 minecraft:light[level=12]
setblock 3 66 285 minecraft:light[level=12]
setblock 3 66 292 minecraft:light[level=12]
setblock 3 66 299 minecraft:light[level=12]
setblock 3 66 306 minecraft:light[level=12]
setblock 3 66 313 minecraft:light[level=12]
setblock 10 66 278 minecraft:light[level=12]
setblock 10 66 285 minecraft:light[level=12]
setblock 10 66 292 minecraft:light[level=12]
setblock 10 66 299 minecraft:light[level=12]
setblock 10 66 306 minecraft:light[level=12]
setblock 10 66 313 minecraft:light[level=12]
setblock 17 66 278 minecraft:light[level=12]
setblock 17 66 285 minecraft:light[level=12]
setblock 17 66 299 minecraft:light[level=12]
setblock 17 66 306 minecraft:light[level=12]
setblock 17 66 313 minecraft:light[level=12]
setblock 24 66 278 minecraft:light[level=12]
setblock 24 66 285 minecraft:light[level=12]
setblock 24 66 292 minecraft:light[level=12]
setblock 24 66 299 minecraft:light[level=12]
setblock 24 66 306 minecraft:light[level=12]
setblock 24 66 313 minecraft:light[level=12]
setblock 31 66 278 minecraft:light[level=12]
setblock 31 66 285 minecraft:light[level=12]
setblock 31 66 292 minecraft:light[level=12]
setblock 31 66 299 minecraft:light[level=12]
setblock 31 66 306 minecraft:light[level=12]
setblock 31 66 313 minecraft:light[level=12]
setblock 38 66 278 minecraft:light[level=12]
setblock 38 66 285 minecraft:light[level=12]
setblock 38 66 292 minecraft:light[level=12]
setblock 38 66 299 minecraft:light[level=12]
setblock 38 66 306 minecraft:light[level=12]
setblock 38 66 313 minecraft:light[level=12]
fill 42 66 303 42 129 303 minecraft:cobbled_deepslate
setblock 42 66 304 minecraft:purple_concrete
fill 42 66 305 42 72 306 minecraft:cobbled_deepslate
fill 42 67 304 42 72 304 minecraft:cobbled_deepslate
setblock 1 68 317 minecraft:purple_concrete
setblock 18 68 275 minecraft:purple_concrete
fill 19 68 275 21 90 275 minecraft:cobbled_deepslate
setblock 29 68 317 minecraft:magma_block
fill 30 68 317 30 127 317 minecraft:cobbled_deepslate
setblock 31 68 317 minecraft:purple_concrete
fill 32 68 317 34 109 317 minecraft:cobbled_deepslate
setblock 0 69 316 minecraft:crying_obsidian
fill 0 69 317 1 129 317 minecraft:cobbled_deepslate
fill 18 69 275 18 129 275 minecraft:cobbled_deepslate
fill 29 69 317 29 90 317 minecraft:cobbled_deepslate
fill 31 69 317 31 130 317 minecraft:cobbled_deepslate
fill 0 70 316 0 129 316 minecraft:cobbled_deepslate
setblock 35 70 275 minecraft:amethyst_block
fill 36 70 275 36 105 275 minecraft:cobbled_deepslate
fill 42 70 282 42 125 282 minecraft:cobbled_deepslate
setblock 42 70 283 minecraft:magma_block
fill 3 71 278 3 72 278 minecraft:light[level=12]
setblock 3 71 286 minecraft:light[level=12]
setblock 3 71 294 minecraft:light[level=12]
setblock 3 71 302 minecraft:light[level=12]
setblock 3 71 310 minecraft:light[level=12]
setblock 11 71 278 minecraft:light[level=12]
setblock 11 71 286 minecraft:light[level=12]
setblock 11 71 294 minecraft:light[level=12]
setblock 11 71 302 minecraft:light[level=12]
setblock 11 71 310 minecraft:light[level=12]
setblock 19 71 278 minecraft:light[level=12]
setblock 19 71 286 minecraft:light[level=12]
setblock 19 71 294 minecraft:light[level=12]
setblock 19 71 302 minecraft:light[level=12]
setblock 19 71 310 minecraft:light[level=12]
setblock 27 71 278 minecraft:light[level=12]
setblock 27 71 286 minecraft:light[level=12]
setblock 27 71 294 minecraft:light[level=12]
setblock 27 71 302 minecraft:light[level=12]
setblock 27 71 310 minecraft:light[level=12]
fill 35 71 275 35 127 275 minecraft:cobbled_deepslate
setblock 35 71 278 minecraft:light[level=12]
setblock 35 71 286 minecraft:light[level=12]
setblock 35 71 294 minecraft:light[level=12]
setblock 35 71 302 minecraft:light[level=12]
setblock 35 71 310 minecraft:light[level=12]
fill 42 71 283 42 127 283 minecraft:cobbled_deepslate
setblock 3 72 285 minecraft:light[level=12]
setblock 3 72 292 minecraft:light[level=12]
setblock 3 72 299 minecraft:light[level=12]
setblock 3 72 306 minecraft:light[level=12]
setblock 3 72 313 minecraft:light[level=12]
setblock 10 72 278 minecraft:light[level=12]
setblock 10 72 285 minecraft:light[level=12]
setblock 10 72 292 minecraft:light[level=12]
setblock 10 72 299 minecraft:light[level=12]
setblock 10 72 306 minecraft:light[level=12]
setblock 10 72 313 minecraft:light[level=12]
setblock 17 72 278 minecraft:light[level=12]
setblock 17 72 285 minecraft:light[level=12]
setblock 17 72 299 minecraft:light[level=12]
setblock 17 72 306 minecraft:light[level=12]
setblock 17 72 313 minecraft:light[level=12]
setblock 24 72 278 minecraft:light[level=12]
setblock 24 72 285 minecraft:light[level=12]
setblock 24 72 292 minecraft:light[level=12]
setblock 24 72 299 minecraft:light[level=12]
setblock 24 72 306 minecraft:light[level=12]
setblock 24 72 313 minecraft:light[level=12]
setblock 31 72 278 minecraft:light[level=12]
setblock 31 72 285 minecraft:light[level=12]
setblock 31 72 292 minecraft:light[level=12]
setblock 31 72 299 minecraft:light[level=12]
setblock 31 72 306 minecraft:light[level=12]
setblock 31 72 313 minecraft:light[level=12]
setblock 38 72 278 minecraft:light[level=12]
setblock 38 72 285 minecraft:light[level=12]
setblock 38 72 292 minecraft:light[level=12]
setblock 38 72 299 minecraft:light[level=12]
setblock 38 72 306 minecraft:light[level=12]
setblock 38 72 313 minecraft:light[level=12]
fill 41 73 304 41 76 306 minecraft:amethyst_block
fill 42 73 304 42 75 305 minecraft:amethyst_block
setblock 42 73 306 minecraft:cobbled_deepslate
fill 40 74 304 40 76 306 minecraft:amethyst_block
setblock 41 74 307 minecraft:amethyst_block
fill 42 74 306 42 75 306 minecraft:amethyst_block
fill 0 75 302 0 97 302 minecraft:cobbled_deepslate
setblock 0 75 303 minecraft:magma_block
fill 0 75 304 0 129 304 minecraft:cobbled_deepslate
setblock 39 75 304 minecraft:amethyst_block
setblock 42 75 286 minecraft:magma_block
fill 0 76 303 0 125 303 minecraft:cobbled_deepslate
fill 1 76 275 3 125 275 minecraft:cobbled_deepslate
setblock 4 76 275 minecraft:crying_obsidian
fill 18 76 311 18 85 311 minecraft:polished_blackstone
fill 42 76 286 42 129 286 minecraft:cobbled_deepslate
fill 42 76 291 42 85 292 minecraft:cobbled_deepslate
setblock 42 76 293 minecraft:crying_obsidian
fill 42 76 294 42 129 295 minecraft:cobbled_deepslate
fill 42 76 304 42 115 304 minecraft:cobbled_deepslate
setblock 42 76 305 minecraft:amethyst_block
fill 42 76 306 42 95 306 minecraft:cobbled_deepslate
fill 4 77 275 4 108 275 minecraft:cobbled_deepslate
fill 42 77 293 42 129 293 minecraft:cobbled_deepslate
fill 42 77 305 42 129 305 minecraft:cobbled_deepslate
setblock 3 78 278 minecraft:light[level=12]
fill 3 78 285 3 78 286 minecraft:light[level=12]
setblock 3 78 292 minecraft:light[level=12]
setblock 3 78 294 minecraft:light[level=12]
setblock 3 78 299 minecraft:light[level=12]
setblock 3 78 302 minecraft:light[level=12]
setblock 3 78 306 minecraft:light[level=12]
setblock 3 78 310 minecraft:light[level=12]
setblock 3 78 313 minecraft:light[level=12]
fill 10 78 278 11 78 278 minecraft:light[level=12]
setblock 10 78 285 minecraft:light[level=12]
setblock 10 78 292 minecraft:light[level=12]
setblock 10 78 299 minecraft:light[level=12]
setblock 10 78 306 minecraft:light[level=12]
setblock 10 78 313 minecraft:light[level=12]
setblock 11 78 286 minecraft:light[level=12]
setblock 11 78 294 minecraft:light[level=12]
setblock 11 78 302 minecraft:light[level=12]
setblock 11 78 310 minecraft:light[level=12]
fill 13 78 299 14 79 299 minecraft:gold_block
setblock 17 78 278 minecraft:light[level=12]
setblock 17 78 285 minecraft:light[level=12]
setblock 17 78 299 minecraft:light[level=12]
setblock 17 78 306 minecraft:light[level=12]
setblock 17 78 313 minecraft:light[level=12]
setblock 19 78 278 minecraft:light[level=12]
setblock 19 78 286 minecraft:light[level=12]
setblock 19 78 294 minecraft:light[level=12]
setblock 19 78 302 minecraft:light[level=12]
setblock 19 78 310 minecraft:light[level=12]
setblock 24 78 278 minecraft:light[level=12]
setblock 24 78 285 minecraft:light[level=12]
setblock 24 78 292 minecraft:light[level=12]
setblock 24 78 299 minecraft:light[level=12]
setblock 24 78 306 minecraft:light[level=12]
setblock 24 78 313 minecraft:light[level=12]
setblock 27 78 278 minecraft:light[level=12]
setblock 27 78 286 minecraft:light[level=12]
setblock 27 78 294 minecraft:light[level=12]
setblock 27 78 302 minecraft:light[level=12]
setblock 27 78 310 minecraft:light[level=12]
setblock 31 78 278 minecraft:light[level=12]
setblock 31 78 285 minecraft:light[level=12]
setblock 31 78 292 minecraft:light[level=12]
setblock 31 78 299 minecraft:light[level=12]
setblock 31 78 306 minecraft:light[level=12]
setblock 31 78 313 minecraft:light[level=12]
setblock 35 78 278 minecraft:light[level=12]
setblock 35 78 286 minecraft:light[level=12]
setblock 35 78 294 minecraft:light[level=12]
setblock 35 78 302 minecraft:light[level=12]
setblock 35 78 310 minecraft:light[level=12]
setblock 38 78 278 minecraft:light[level=12]
setblock 38 78 285 minecraft:light[level=12]
setblock 38 78 292 minecraft:light[level=12]
setblock 38 78 299 minecraft:light[level=12]
setblock 38 78 306 minecraft:light[level=12]
setblock 38 78 313 minecraft:light[level=12]
setblock 41 78 275 minecraft:crying_obsidian
fill 42 78 275 42 125 275 minecraft:cobbled_deepslate
setblock 3 79 317 minecraft:purple_concrete
setblock 33 79 275 minecraft:amethyst_block
setblock 35 79 317 minecraft:amethyst_block
fill 36 79 317 36 125 317 minecraft:cobbled_deepslate
fill 41 79 275 41 125 275 minecraft:cobbled_deepslate
fill 42 79 279 42 107 280 minecraft:cobbled_deepslate
setblock 42 79 281 minecraft:purple_concrete
fill 3 80 317 3 89 317 minecraft:cobbled_deepslate
fill 33 80 275 33 114 275 minecraft:cobbled_deepslate
fill 35 80 317 35 129 317 minecraft:cobbled_deepslate
fill 42 80 281 42 127 281 minecraft:cobbled_deepslate
fill 10 81 275 11 90 275 minecraft:cobbled_deepslate
setblock 12 81 275 minecraft:amethyst_block
fill 12 82 275 13 126 275 minecraft:cobbled_deepslate
setblock 14 82 275 minecraft:amethyst_block
fill 17 82 311 17 85 311 minecraft:polished_blackstone
fill 18 82 310 18 85 310 minecraft:polished_blackstone
fill 18 82 312 18 85 312 minecraft:polished_blackstone
fill 19 82 311 19 85 311 minecraft:polished_blackstone
fill 14 83 275 14 126 275 minecraft:cobbled_deepslate
fill 0 84 275 0 125 278 minecraft:cobbled_deepslate
setblock 0 84 279 minecraft:crying_obsidian
fill 0 84 280 0 118 289 minecraft:cobbled_deepslate
fill 3 84 278 3 85 278 minecraft:light[level=12]
setblock 3 84 285 minecraft:light[level=12]
setblock 3 84 292 minecraft:light[level=12]
setblock 3 84 299 minecraft:light[level=12]
setblock 3 84 306 minecraft:light[level=12]
setblock 3 84 313 minecraft:light[level=12]
setblock 10 84 278 minecraft:light[level=12]
setblock 10 84 285 minecraft:light[level=12]
setblock 10 84 292 minecraft:light[level=12]
setblock 10 84 299 minecraft:light[level=12]
setblock 10 84 306 minecraft:light[level=12]
setblock 10 84 313 minecraft:light[level=12]
setblock 17 84 278 minecraft:light[level=12]
setblock 17 84 285 minecraft:light[level=12]
setblock 17 84 299 minecraft:light[level=12]
setblock 17 84 306 minecraft:light[level=12]
setblock 17 84 313 minecraft:light[level=12]
setblock 24 84 278 minecraft:light[level=12]
setblock 24 84 285 minecraft:light[level=12]
setblock 24 84 292 minecraft:light[level=12]
setblock 24 84 299 minecraft:light[level=12]
setblock 24 84 306 minecraft:light[level=12]
setblock 24 84 313 minecraft:light[level=12]
setblock 31 84 278 minecraft:light[level=12]
setblock 31 84 285 minecraft:light[level=12]
setblock 31 84 292 minecraft:light[level=12]
setblock 31 84 299 minecraft:light[level=12]
setblock 31 84 306 minecraft:light[level=12]
setblock 31 84 313 minecraft:light[level=12]
setblock 38 84 278 minecraft:light[level=12]
setblock 38 84 285 minecraft:light[level=12]
setblock 38 84 292 minecraft:light[level=12]
setblock 38 84 299 minecraft:light[level=12]
setblock 38 84 306 minecraft:light[level=12]
setblock 38 84 313 minecraft:light[level=12]
fill 0 85 279 0 125 279 minecraft:cobbled_deepslate
setblock 3 85 286 minecraft:light[level=12]
setblock 3 85 294 minecraft:light[level=12]
setblock 3 85 302 minecraft:light[level=12]
setblock 3 85 310 minecraft:light[level=12]
setblock 11 85 278 minecraft:light[level=12]
setblock 11 85 286 minecraft:light[level=12]
setblock 11 85 294 minecraft:light[level=12]
setblock 11 85 302 minecraft:light[level=12]
setblock 11 85 310 minecraft:light[level=12]
setblock 17 85 310 minecraft:polished_blackstone
setblock 17 85 312 minecraft:polished_blackstone
setblock 19 85 278 minecraft:light[level=12]
setblock 19 85 286 minecraft:light[level=12]
setblock 19 85 294 minecraft:light[level=12]
setblock 19 85 302 minecraft:light[level=12]
setblock 19 85 310 minecraft:polished_blackstone
setblock 19 85 312 minecraft:polished_blackstone
setblock 27 85 278 minecraft:light[level=12]
setblock 27 85 286 minecraft:light[level=12]
setblock 27 85 294 minecraft:light[level=12]
setblock 27 85 302 minecraft:light[level=12]
setblock 27 85 310 minecraft:light[level=12]
setblock 35 85 278 minecraft:light[level=12]
setblock 35 85 286 minecraft:light[level=12]
setblock 35 85 294 minecraft:light[level=12]
setblock 35 85 302 minecraft:light[level=12]
setblock 35 85 310 minecraft:light[level=12]
setblock 19 86 317 minecraft:amethyst_block
fill 20 86 317 21 92 317 minecraft:cobbled_deepslate
fill 42 86 291 42 126 291 minecraft:cobbled_deepslate
setblock 42 86 292 minecraft:magma_block
setblock 0 87 295 minecraft:amethyst_block
fill 19 87 317 19 107 317 minecraft:cobbled_deepslate
fill 42 87 292 42 129 292 minecraft:cobbled_deepslate
fill 0 88 295 0 129 295 minecraft:cobbled_deepslate
setblock 0 88 306 minecraft:magma_block
fill 0 88 307 0 126 308 minecraft:cobbled_deepslate
fill 42 88 276 42 92 276 minecraft:cobbled_deepslate
setblock 42 88 277 minecraft:magma_block
fill 0 89 306 0 129 306 minecraft:cobbled_deepslate
fill 36 89 308 36 98 308 minecraft:blackstone
fill 42 89 277 42 126 277 minecraft:cobbled_deepslate
setblock 42 89 315 minecraft:crying_obsidian
fill 42 89 316 42 118 316 minecraft:cobbled_deepslate
setblock 3 90 278 minecraft:light[level=12]
setblock 3 90 285 minecraft:light[level=12]
setblock 3 90 292 minecraft:light[level=12]
setblock 3 90 299 minecraft:light[level=12]
setblock 3 90 306 minecraft:light[level=12]
setblock 3 90 313 minecraft:light[level=12]
setblock 3 90 317 minecraft:crying_obsidian
setblock 10 90 278 minecraft:light[level=12]
setblock 10 90 285 minecraft:light[level=12]
setblock 10 90 292 minecraft:light[level=12]
setblock 10 90 299 minecraft:light[level=12]
setblock 10 90 306 minecraft:light[level=12]
setblock 10 90 313 minecraft:light[level=12]
setblock 17 90 278 minecraft:light[level=12]
setblock 17 90 285 minecraft:light[level=12]
setblock 17 90 299 minecraft:light[level=12]
setblock 17 90 306 minecraft:light[level=12]
setblock 17 90 313 minecraft:light[level=12]
setblock 24 90 278 minecraft:light[level=12]
setblock 24 90 285 minecraft:light[level=12]
setblock 24 90 292 minecraft:light[level=12]
setblock 24 90 299 minecraft:light[level=12]
setblock 24 90 306 minecraft:light[level=12]
setblock 24 90 313 minecraft:light[level=12]
setblock 31 90 278 minecraft:light[level=12]
setblock 31 90 285 minecraft:light[level=12]
setblock 31 90 292 minecraft:light[level=12]
setblock 31 90 299 minecraft:light[level=12]
setblock 31 90 306 minecraft:light[level=12]
setblock 31 90 313 minecraft:light[level=12]
setblock 38 90 278 minecraft:light[level=12]
setblock 38 90 285 minecraft:light[level=12]
setblock 38 90 292 minecraft:light[level=12]
setblock 38 90 299 minecraft:light[level=12]
setblock 38 90 306 minecraft:light[level=12]
setblock 38 90 313 minecraft:light[level=12]
fill 42 90 315 42 125 315 minecraft:cobbled_deepslate
fill 3 91 317 3 126 317 minecraft:cobbled_deepslate
setblock 10 91 275 minecraft:amethyst_block
fill 11 91 275 11 129 275 minecraft:cobbled_deepslate
fill 19 91 275 20 125 275 minecraft:cobbled_deepslate
setblock 21 91 275 minecraft:purple_concrete
setblock 22 91 317 minecraft:purple_concrete
setblock 29 91 317 minecraft:crying_obsidian
setblock 41 91 317 minecraft:magma_block
fill 42 91 317 42 125 317 minecraft:cobbled_deepslate
setblock 0 92 294 minecraft:magma_block
setblock 3 92 278 minecraft:light[level=12]
setblock 3 92 286 minecraft:light[level=12]
setblock 3 92 294 minecraft:light[level=12]
setblock 3 92 302 minecraft:light[level=12]
setblock 3 92 310 minecraft:light[level=12]
fill 10 92 275 10 108 275 minecraft:cobbled_deepslate
setblock 11 92 278 minecraft:light[level=12]
setblock 11 92 286 minecraft:light[level=12]
setblock 11 92 294 minecraft:light[level=12]
setblock 11 92 302 minecraft:light[level=12]
setblock 11 92 310 minecraft:light[level=12]
setblock 19 92 278 minecraft:light[level=12]
setblock 19 92 286 minecraft:light[level=12]
setblock 19 92 294 minecraft:light[level=12]
setblock 19 92 302 minecraft:light[level=12]
setblock 19 92 310 minecraft:light[level=12]
fill 21 92 275 21 129 275 minecraft:cobbled_deepslate
fill 22 92 317 22 114 317 minecraft:cobbled_deepslate
setblock 27 92 278 minecraft:light[level=12]
setblock 27 92 286 minecraft:light[level=12]
setblock 27 92 294 minecraft:light[level=12]
setblock 27 92 302 minecraft:light[level=12]
setblock 27 92 310 minecraft:light[level=12]
fill 29 92 317 29 120 317 minecraft:cobbled_deepslate
setblock 35 92 278 minecraft:light[level=12]
setblock 35 92 286 minecraft:light[level=12]
setblock 35 92 294 minecraft:light[level=12]
setblock 35 92 302 minecraft:light[level=12]
setblock 35 92 310 minecraft:light[level=12]
fill 41 92 317 41 120 317 minecraft:cobbled_deepslate
fill 0 93 294 0 129 294 minecraft:cobbled_deepslate
setblock 20 93 317 minecraft:crying_obsidian
fill 21 93 317 21 106 317 minecraft:cobbled_deepslate
setblock 42 93 276 minecraft:magma_block
setblock 7 94 275 minecraft:crying_obsidian
fill 8 94 275 8 129 275 minecraft:cobbled_deepslate
fill 20 94 317 20 129 317 minecraft:cobbled_deepslate
fill 42 94 276 42 126 276 minecraft:cobbled_deepslate
fill 7 95 275 7 111 275 minecraft:cobbled_deepslate
fill 24 95 313 25 96 313 minecraft:raw_gold_block
fill 35 95 308 35 98 308 minecraft:blackstone
fill 36 95 307 36 98 307 minecraft:blackstone
fill 36 95 309 36 98 309 minecraft:blackstone
fill 37 95 308 37 98 308 minecraft:blackstone
setblock 39 95 275 minecraft:crying_obsidian
setblock 3 96 278 minecraft:light[level=12]
setblock 3 96 285 minecraft:light[level=12]
setblock 3 96 292 minecraft:light[level=12]
setblock 3 96 299 minecraft:light[level=12]
setblock 3 96 306 minecraft:light[level=12]
setblock 3 96 313 minecraft:light[level=12]
setblock 10 96 278 minecraft:light[level=12]
setblock 10 96 285 minecraft:light[level=12]
setblock 10 96 292 minecraft:light[level=12]
setblock 10 96 299 minecraft:light[level=12]
setblock 10 96 306 minecraft:light[level=12]
setblock 10 96 313 minecraft:light[level=12]
setblock 17 96 278 minecraft:light[level=12]
setblock 17 96 285 minecraft:light[level=12]
setblock 17 96 292 minecraft:light[level=12]
setblock 17 96 299 minecraft:light[level=12]
setblock 17 96 306 minecraft:light[level=12]
setblock 17 96 313 minecraft:light[level=12]
setblock 24 96 278 minecraft:light[level=12]
setblock 24 96 285 minecraft:light[level=12]
setblock 24 96 292 minecraft:light[level=12]
setblock 24 96 299 minecraft:light[level=12]
setblock 24 96 306 minecraft:light[level=12]
setblock 31 96 278 minecraft:light[level=12]
setblock 31 96 285 minecraft:light[level=12]
setblock 31 96 292 minecraft:light[level=12]
setblock 31 96 299 minecraft:light[level=12]
setblock 31 96 306 minecraft:light[level=12]
setblock 31 96 313 minecraft:light[level=12]
setblock 38 96 278 minecraft:light[level=12]
setblock 38 96 285 minecraft:light[level=12]
setblock 38 96 292 minecraft:light[level=12]
setblock 38 96 299 minecraft:light[level=12]
setblock 38 96 306 minecraft:light[level=12]
setblock 38 96 313 minecraft:light[level=12]
fill 39 96 275 39 129 275 minecraft:cobbled_deepslate
setblock 42 96 306 minecraft:amethyst_block
fill 42 97 306 42 127 306 minecraft:cobbled_deepslate
setblock 0 98 302 minecraft:amethyst_block
setblock 15 98 275 minecraft:magma_block
fill 16 98 275 17 116 275 minecraft:cobbled_deepslate
setblock 35 98 307 minecraft:blackstone
setblock 35 98 309 minecraft:blackstone
setblock 37 98 307 minecraft:blackstone
setblock 37 98 309 minecraft:blackstone
fill 40 98 300 40 101 300 minecraft:amethyst_block
fill 41 98 301 41 101 302 minecraft:amethyst_block
setblock 42 98 285 minecraft:purple_concrete
fill 42 98 301 42 101 301 minecraft:amethyst_block
fill 0 99 302 0 129 302 minecraft:cobbled_deepslate
setblock 3 99 278 minecraft:light[level=12]
setblock 3 99 286 minecraft:light[level=12]
setblock 3 99 294 minecraft:light[level=12]
setblock 3 99 302 minecraft:light[level=12]
setblock 3 99 310 minecraft:light[level=12]
setblock 11 99 278 minecraft:light[level=12]
setblock 11 99 286 minecraft:light[level=12]
setblock 11 99 294 minecraft:light[level=12]
setblock 11 99 302 minecraft:light[level=12]
setblock 11 99 310 minecraft:light[level=12]
fill 15 99 275 15 125 275 minecraft:cobbled_deepslate
setblock 19 99 278 minecraft:light[level=12]
setblock 19 99 286 minecraft:light[level=12]
setblock 19 99 294 minecraft:light[level=12]
setblock 19 99 302 minecraft:light[level=12]
setblock 19 99 310 minecraft:light[level=12]
setblock 27 99 278 minecraft:light[level=12]
setblock 27 99 286 minecraft:light[level=12]
setblock 27 99 294 minecraft:light[level=12]
setblock 27 99 302 minecraft:light[level=12]
setblock 27 99 310 minecraft:light[level=12]
setblock 35 99 278 minecraft:light[level=12]
setblock 35 99 286 minecraft:light[level=12]
setblock 35 99 294 minecraft:light[level=12]
setblock 35 99 302 minecraft:light[level=12]
setblock 35 99 310 minecraft:light[level=12]
fill 39 99 301 40 99 302 minecraft:amethyst_block
fill 41 99 299 42 100 300 minecraft:amethyst_block
fill 42 99 285 42 129 285 minecraft:cobbled_deepslate
fill 42 99 297 42 129 298 minecraft:cobbled_deepslate
fill 42 99 302 42 100 302 minecraft:amethyst_block
setblock 42 99 308 minecraft:crying_obsidian
fill 39 100 301 40 100 301 minecraft:amethyst_block
setblock 40 100 302 minecraft:amethyst_block
fill 42 100 308 42 129 308 minecraft:cobbled_deepslate
setblock 0 101 314 minecraft:magma_block
setblock 30 101 275 minecraft:crying_obsidian
fill 42 101 299 42 127 300 minecraft:cobbled_deepslate
setblock 42 101 302 minecraft:cobbled_deepslate
fill 0 102 314 0 125 314 minecraft:cobbled_deepslate
setblock 3 102 278 minecraft:light[level=12]
setblock 3 102 285 minecraft:light[level=12]
setblock 3 102 292 minecraft:light[level=12]
setblock 3 102 299 minecraft:light[level=12]
setblock 3 102 306 minecraft:light[level=12]
setblock 3 102 313 minecraft:light[level=12]
setblock 10 102 278 minecraft:light[level=12]
setblock 10 102 285 minecraft:light[level=12]
setblock 10 102 292 minecraft:light[level=12]
setblock 10 102 299 minecraft:light[level=12]
setblock 10 102 306 minecraft:light[level=12]
setblock 10 102 313 minecraft:light[level=12]
setblock 17 102 278 minecraft:light[level=12]
setblock 17 102 285 minecraft:light[level=12]
setblock 17 102 292 minecraft:light[level=12]
setblock 17 102 299 minecraft:light[level=12]
setblock 17 102 306 minecraft:light[level=12]
setblock 17 102 313 minecraft:light[level=12]
setblock 24 102 278 minecraft:light[level=12]
setblock 24 102 285 minecraft:light[level=12]
setblock 24 102 292 minecraft:light[level=12]
setblock 24 102 299 minecraft:light[level=12]
setblock 24 102 306 minecraft:light[level=12]
setblock 24 102 313 minecraft:light[level=12]
fill 30 102 275 30 125 275 minecraft:cobbled_deepslate
setblock 31 102 278 minecraft:light[level=12]
setblock 31 102 285 minecraft:light[level=12]
setblock 31 102 292 minecraft:light[level=12]
setblock 31 102 299 minecraft:light[level=12]
setblock 31 102 306 minecraft:light[level=12]
setblock 31 102 313 minecraft:light[level=12]
setblock 38 102 278 minecraft:light[level=12]
setblock 38 102 285 minecraft:light[level=12]
setblock 38 102 292 minecraft:light[level=12]
setblock 38 102 299 minecraft:light[level=12]
setblock 38 102 306 minecraft:light[level=12]
setblock 38 102 313 minecraft:light[level=12]
fill 42 102 301 42 106 301 minecraft:cobbled_deepslate
setblock 42 102 302 minecraft:magma_block
fill 12 103 317 12 129 317 minecraft:cobbled_deepslate
setblock 13 103 317 minecraft:crying_obsidian
fill 14 103 317 17 125 317 minecraft:cobbled_deepslate
setblock 18 103 317 minecraft:magma_block
fill 42 103 302 42 129 302 minecraft:cobbled_deepslate
setblock 42 103 314 minecraft:purple_concrete
fill 13 104 317 13 127 317 minecraft:cobbled_deepslate
fill 18 104 317 18 129 317 minecraft:cobbled_deepslate
fill 42 104 314 42 125 314 minecraft:cobbled_deepslate
setblock 3 106 278 minecraft:light[level=12]
setblock 3 106 286 minecraft:light[level=12]
setblock 3 106 294 minecraft:light[level=12]
setblock 3 106 302 minecraft:light[level=12]
setblock 3 106 310 minecraft:light[level=12]
setblock 11 106 278 minecraft:light[level=12]
setblock 11 106 286 minecraft:light[level=12]
fill 11 106 293 15 108 293 minecraft:red_nether_bricks
fill 11 106 294 17 106 294 minecraft:nether_wart_block
fill 11 106 295 31 106 296 minecraft:red_nether_bricks
fill 11 106 297 31 106 297 minecraft:nether_wart_block
fill 11 106 298 31 106 299 minecraft:red_nether_bricks
setblock 11 106 302 minecraft:light[level=12]
setblock 11 106 310 minecraft:light[level=12]
fill 12 106 290 15 107 290 minecraft:red_nether_bricks
fill 12 106 291 14 106 291 minecraft:nether_wart_block
fill 12 106 292 15 107 292 minecraft:red_nether_bricks
fill 12 106 300 30 106 300 minecraft:nether_wart_block
fill 12 106 301 30 109 302 minecraft:red_nether_bricks
fill 13 106 288 17 106 288 minecraft:nether_wart_block
fill 13 106 289 15 108 289 minecraft:red_nether_bricks
fill 13 106 303 29 106 303 minecraft:nether_wart_block
fill 13 106 304 29 106 304 minecraft:red_nether_bricks
fill 14 106 287 28 108 287 minecraft:red_nether_bricks
fill 14 106 305 28 109 305 minecraft:red_nether_bricks
fill 15 106 286 27 113 286 minecraft:red_nether_bricks
fill 15 106 306 27 106 306 minecraft:nether_wart_block
fill 16 106 285 26 106 285 minecraft:nether_wart_block
fill 16 106 307 26 109 307 minecraft:red_nether_bricks
fill 17 106 284 25 119 284 minecraft:red_nether_bricks
fill 17 106 308 25 109 308 minecraft:red_nether_bricks
setblock 19 106 278 minecraft:light[level=12]
fill 19 106 283 23 106 283 minecraft:red_nether_bricks
fill 19 106 288 29 106 288 minecraft:nether_wart_block
fill 19 106 294 31 106 294 minecraft:nether_wart_block
fill 19 106 309 23 106 309 minecraft:nether_wart_block
setblock 19 106 310 minecraft:light[level=12]
fill 21 106 289 29 107 290 minecraft:red_nether_bricks
fill 21 106 292 30 107 293 minecraft:red_nether_bricks
fill 22 106 291 30 106 291 minecraft:nether_wart_block
setblock 27 106 278 minecraft:light[level=12]
setblock 27 106 310 minecraft:light[level=12]
fill 30 106 290 30 115 290 minecraft:red_nether_bricks
fill 31 106 293 31 114 293 minecraft:red_nether_bricks
setblock 35 106 278 minecraft:light[level=12]
setblock 35 106 286 minecraft:light[level=12]
setblock 35 106 294 minecraft:light[level=12]
setblock 35 106 302 minecraft:light[level=12]
setblock 35 106 310 minecraft:light[level=12]
setblock 36 106 275 minecraft:amethyst_block
setblock 42 106 278 minecraft:crying_obsidian
fill 11 107 291 14 108 291 minecraft:red_nether_bricks
setblock 11 107 292 minecraft:nether_wart_block
fill 11 107 294 17 107 294 minecraft:red_nether_bricks
setblock 11 107 295 minecraft:nether_wart_block
fill 11 107 296 31 109 297 minecraft:red_nether_bricks
setblock 11 107 298 minecraft:nether_wart_block
fill 11 107 299 31 109 300 minecraft:red_nether_bricks
setblock 11 107 301 minecraft:nether_wart_block
setblock 12 107 289 minecraft:nether_wart_block
fill 12 107 295 30 108 295 minecraft:red_nether_bricks
fill 12 107 298 30 112 298 minecraft:red_nether_bricks
fill 12 107 303 30 109 303 minecraft:red_nether_bricks
fill 13 107 287 13 107 288 minecraft:red_nether_bricks
setblock 13 107 304 minecraft:nether_wart_block
setblock 13 107 305 minecraft:red_nether_bricks
setblock 14 107 286 minecraft:nether_wart_block
fill 14 107 288 17 107 288 minecraft:red_nether_bricks
fill 14 107 304 28 109 304 minecraft:red_nether_bricks
fill 14 107 306 28 109 306 minecraft:red_nether_bricks
fill 15 107 285 27 117 285 minecraft:red_nether_bricks
setblock 15 107 307 minecraft:nether_wart_block
fill 16 107 284 16 118 284 minecraft:red_nether_bricks
fill 16 107 308 16 109 308 minecraft:red_nether_bricks
fill 17 107 283 20 107 283 minecraft:nether_wart_block
fill 17 107 309 25 109 309 minecraft:red_nether_bricks
fill 19 107 288 29 107 288 minecraft:red_nether_bricks
fill 19 107 294 31 107 294 minecraft:red_nether_bricks
fill 21 107 282 21 108 283 minecraft:red_nether_bricks
setblock 21 107 310 minecraft:nether_wart_block
setblock 21 107 317 minecraft:amethyst_block
fill 22 107 283 25 107 283 minecraft:nether_wart_block
fill 22 107 291 31 108 291 minecraft:red_nether_bricks
fill 26 107 284 26 118 284 minecraft:red_nether_bricks
fill 26 107 308 26 109 308 minecraft:red_nether_bricks
setblock 27 107 307 minecraft:nether_wart_block
setblock 28 107 286 minecraft:nether_wart_block
setblock 29 107 287 minecraft:red_nether_bricks
setblock 29 107 304 minecraft:nether_wart_block
setblock 29 107 305 minecraft:red_nether_bricks
setblock 30 107 289 minecraft:nether_wart_block
setblock 31 107 292 minecraft:nether_wart_block
setblock 31 107 295 minecraft:nether_wart_block
setblock 31 107 298 minecraft:nether_wart_block
setblock 31 107 301 minecraft:nether_wart_block
fill 36 107 275 36 125 275 minecraft:cobbled_deepslate
fill 42 107 278 42 129 278 minecraft:cobbled_deepslate
setblock 42 107 301 minecraft:amethyst_block
setblock 3 108 278 minecraft:light[level=12]
setblock 3 108 285 minecraft:light[level=12]
setblock 3 108 292 minecraft:light[level=12]
setblock 3 108 299 minecraft:light[level=12]
setblock 3 108 306 minecraft:light[level=12]
setblock 3 108 313 minecraft:light[level=12]
setblock 10 108 278 minecraft:light[level=12]
setblock 10 108 285 minecraft:light[level=12]
setblock 10 108 292 minecraft:light[level=12]
setblock 10 108 293 minecraft:nether_wart_block
fill 10 108 294 11 108 295 minecraft:red_nether_bricks
setblock 10 108 296 minecraft:nether_wart_block
fill 10 108 297 10 108 298 minecraft:red_nether_bricks
setblock 10 108 299 minecraft:nether_wart_block
setblock 10 108 306 minecraft:light[level=12]
setblock 10 108 313 minecraft:light[level=12]
setblock 11 108 290 minecraft:nether_wart_block
fill 11 108 292 14 108 292 minecraft:red_nether_bricks
fill 11 108 298 11 118 298 minecraft:red_nether_bricks
fill 11 108 301 11 115 301 minecraft:red_nether_bricks
setblock 11 108 302 minecraft:nether_wart_block
fill 12 108 288 12 108 290 minecraft:red_nether_bricks
fill 12 108 294 16 108 294 minecraft:red_nether_bricks
fill 12 108 304 13 112 304 minecraft:red_nether_bricks
fill 13 108 286 14 109 286 minecraft:red_nether_bricks
setblock 13 108 287 minecraft:nether_wart_block
fill 13 108 288 16 108 288 minecraft:red_nether_bricks
fill 13 108 290 14 108 290 minecraft:red_nether_bricks
setblock 13 108 305 minecraft:nether_wart_block
setblock 13 108 306 minecraft:red_nether_bricks
setblock 14 108 285 minecraft:red_nether_bricks
fill 14 108 307 15 109 307 minecraft:red_nether_bricks
setblock 15 108 284 minecraft:nether_wart_block
setblock 15 108 290 minecraft:magma_block
setblock 15 108 292 minecraft:magma_block
setblock 15 108 308 minecraft:nether_wart_block
fill 16 108 283 20 109 283 minecraft:red_nether_bricks
setblock 16 108 309 minecraft:red_nether_bricks
setblock 17 108 278 minecraft:light[level=12]
setblock 17 108 288 minecraft:magma_block
setblock 17 108 294 minecraft:magma_block
setblock 17 108 313 minecraft:light[level=12]
fill 18 108 282 20 108 282 minecraft:red_nether_bricks
fill 18 108 310 24 109 310 minecraft:red_nether_bricks
setblock 19 108 288 minecraft:magma_block
setblock 19 108 294 minecraft:magma_block
setblock 19 108 317 minecraft:purple_concrete
fill 20 108 288 30 108 288 minecraft:red_nether_bricks
fill 20 108 294 32 108 294 minecraft:red_nether_bricks
fill 21 108 289 30 108 289 minecraft:red_nether_bricks
setblock 21 108 290 minecraft:magma_block
setblock 21 108 292 minecraft:magma_block
fill 21 108 293 30 108 293 minecraft:red_nether_bricks
fill 21 108 317 21 129 317 minecraft:cobbled_deepslate
fill 22 108 282 24 108 283 minecraft:red_nether_bricks
fill 22 108 290 29 108 290 minecraft:red_nether_bricks
fill 22 108 292 31 108 292 minecraft:red_nether_bricks
setblock 24 108 278 minecraft:light[level=12]
setblock 24 108 313 minecraft:light[level=12]
fill 25 108 283 26 109 283 minecraft:red_nether_bricks
setblock 26 108 309 minecraft:red_nether_bricks
setblock 27 108 284 minecraft:nether_wart_block
fill 27 108 307 28 109 307 minecraft:red_nether_bricks
setblock 27 108 308 minecraft:nether_wart_block
fill 28 108 285 28 108 286 minecraft:red_nether_bricks
fill 29 108 286 29 109 286 minecraft:red_nether_bricks
setblock 29 108 287 minecraft:nether_wart_block
fill 29 108 304 30 109 304 minecraft:red_nether_bricks
setblock 29 108 305 minecraft:nether_wart_block
setblock 29 108 306 minecraft:red_nether_bricks
setblock 31 108 278 minecraft:light[level=12]
setblock 31 108 285 minecraft:light[level=12]
setblock 31 108 290 minecraft:nether_wart_block
fill 31 108 295 32 109 295 minecraft:red_nether_bricks
fill 31 108 298 32 109 298 minecraft:red_nether_bricks
fill 31 108 301 31 109 301 minecraft:red_nether_bricks
setblock 31 108 302 minecraft:nether_wart_block
setblock 31 108 306 minecraft:light[level=12]
setblock 31 108 313 minecraft:light[level=12]
setblock 32 108 293 minecraft:nether_wart_block
setblock 32 108 296 minecraft:nether_wart_block
setblock 32 108 297 minecraft:red_nether_bricks
setblock 32 108 299 minecraft:nether_wart_block
setblock 38 108 278 minecraft:light[level=12]
setblock 38 108 285 minecraft:light[level=12]
setblock 38 108 292 minecraft:light[level=12]
setblock 38 108 299 minecraft:light[level=12]
setblock 38 108 306 minecraft:light[level=12]
setblock 38 108 313 minecraft:light[level=12]
setblock 42 108 279 minecraft:amethyst_block
fill 42 108 280 42 129 280 minecraft:cobbled_deepslate
fill 42 108 301 42 129 301 minecraft:cobbled_deepslate
fill 1 109 276 9 109 316 minecraft:blackstone
setblock 4 109 275 minecraft:crying_obsidian
setblock 10 109 275 minecraft:purple_concrete
fill 10 109 276 10 109 291 minecraft:blackstone
fill 10 109 292 13 109 293 minecraft:red_nether_bricks
setblock 10 109 294 minecraft:nether_wart_block
fill 10 109 295 10 109 296 minecraft:red_nether_bricks
setblock 10 109 297 minecraft:nether_wart_block
fill 10 109 298 10 109 299 minecraft:red_nether_bricks
setblock 10 109 300 minecraft:nether_wart_block
fill 10 109 301 10 109 316 minecraft:blackstone
fill 11 109 276 11 109 288 minecraft:blackstone
fill 11 109 289 13 109 290 minecraft:red_nether_bricks
setblock 11 109 291 minecraft:nether_wart_block
fill 11 109 294 14 111 295 minecraft:red_nether_bricks
fill 11 109 302 11 110 302 minecraft:red_nether_bricks
setblock 11 109 303 minecraft:nether_wart_block
fill 11 109 304 11 109 316 minecraft:blackstone
fill 12 109 276 12 109 286 minecraft:blackstone
fill 12 109 287 16 110 287 minecraft:red_nether_bricks
setblock 12 109 288 minecraft:nether_wart_block
fill 12 109 291 13 120 291 minecraft:red_nether_bricks
fill 12 109 305 13 110 305 minecraft:red_nether_bricks
fill 12 109 306 12 109 316 minecraft:blackstone
fill 13 109 276 13 109 285 minecraft:blackstone
fill 13 109 288 14 117 288 minecraft:red_nether_bricks
setblock 13 109 306 minecraft:nether_wart_block
fill 13 109 307 13 109 316 minecraft:blackstone
fill 14 109 276 14 109 284 minecraft:blackstone
setblock 14 109 285 minecraft:nether_wart_block
fill 14 109 289 14 121 289 minecraft:red_nether_bricks
fill 14 109 290 14 109 292 minecraft:magma_block
setblock 14 109 293 minecraft:red_nether_bricks
fill 14 109 308 14 109 316 minecraft:blackstone
fill 15 109 276 15 109 283 minecraft:blackstone
fill 15 109 284 15 116 284 minecraft:red_nether_bricks
setblock 15 109 288 minecraft:magma_block
fill 15 109 289 15 109 290 minecraft:shroomlight
fill 15 109 292 15 109 293 minecraft:shroomlight
setblock 15 109 294 minecraft:magma_block
fill 15 109 295 16 109 295 minecraft:red_nether_bricks
setblock 15 109 308 minecraft:red_nether_bricks
fill 15 109 309 15 109 316 minecraft:blackstone
fill 16 109 276 16 110 282 minecraft:blackstone
fill 16 109 288 17 109 288 minecraft:shroomlight
fill 16 109 294 17 109 294 minecraft:shroomlight
setblock 16 109 309 minecraft:nether_wart_block
fill 16 109 310 16 109 316 minecraft:blackstone
fill 17 109 276 41 109 281 minecraft:blackstone
fill 17 109 282 25 109 282 minecraft:nether_wart_block
fill 17 109 287 19 109 287 minecraft:magma_block
fill 17 109 295 19 109 295 minecraft:magma_block
setblock 17 109 310 minecraft:red_nether_bricks
fill 17 109 311 41 109 316 minecraft:blackstone
fill 19 109 288 20 109 288 minecraft:shroomlight
fill 19 109 294 20 109 294 minecraft:shroomlight
fill 19 109 317 19 129 317 minecraft:cobbled_deepslate
fill 20 109 287 30 110 287 minecraft:red_nether_bricks
fill 20 109 295 30 109 295 minecraft:red_nether_bricks
fill 21 109 283 24 118 283 minecraft:red_nether_bricks
setblock 21 109 288 minecraft:magma_block
fill 21 109 289 21 109 290 minecraft:shroomlight
fill 21 109 292 21 109 293 minecraft:shroomlight
setblock 21 109 294 minecraft:magma_block
fill 22 109 288 29 109 289 minecraft:red_nether_bricks
fill 22 109 290 22 109 292 minecraft:magma_block
fill 22 109 293 30 109 294 minecraft:red_nether_bricks
fill 23 109 290 29 110 292 minecraft:red_nether_bricks
setblock 25 109 310 minecraft:red_nether_bricks
fill 26 109 282 41 109 282 minecraft:blackstone
setblock 26 109 309 minecraft:nether_wart_block
fill 26 109 310 41 109 310 minecraft:blackstone
fill 27 109 283 41 109 283 minecraft:blackstone
fill 27 109 284 27 116 284 minecraft:red_nether_bricks
setblock 27 109 308 minecraft:red_nether_bricks
fill 27 109 309 41 109 309 minecraft:blackstone
fill 28 109 284 41 109 284 minecraft:blackstone
setblock 28 109 285 minecraft:nether_wart_block
fill 28 109 286 28 117 286 minecraft:red_nether_bricks
fill 28 109 308 41 109 308 minecraft:blackstone
fill 29 109 285 41 109 285 minecraft:blackstone
fill 29 109 305 30 109 305 minecraft:red_nether_bricks
setblock 29 109 306 minecraft:nether_wart_block
fill 29 109 307 41 109 307 minecraft:blackstone
fill 30 109 286 41 109 286 minecraft:blackstone
setblock 30 109 288 minecraft:nether_wart_block
fill 30 109 289 31 109 289 minecraft:red_nether_bricks
fill 30 109 291 30 115 292 minecraft:red_nether_bricks
fill 30 109 306 41 109 306 minecraft:blackstone
fill 31 109 287 41 109 288 minecraft:blackstone
fill 31 109 290 31 110 290 minecraft:red_nether_bricks
setblock 31 109 291 minecraft:nether_wart_block
fill 31 109 292 32 109 292 minecraft:red_nether_bricks
fill 31 109 294 31 113 294 minecraft:red_nether_bricks
setblock 31 109 302 minecraft:red_nether_bricks
setblock 31 109 303 minecraft:nether_wart_block
fill 31 109 304 41 109 305 minecraft:blackstone
fill 32 109 289 41 109 291 minecraft:blackstone
fill 32 109 293 32 110 293 minecraft:red_nether_bricks
setblock 32 109 294 minecraft:nether_wart_block
fill 32 109 296 32 110 296 minecraft:red_nether_bricks
setblock 32 109 297 minecraft:nether_wart_block
setblock 32 109 299 minecraft:red_nether_bricks
setblock 32 109 300 minecraft:nether_wart_block
fill 32 109 301 41 109 303 minecraft:blackstone
fill 33 109 292 41 109 300 minecraft:blackstone
fill 42 109 279 42 129 279 minecraft:cobbled_deepslate
fill 1 110 276 1 110 308 minecraft:basalt
fill 1 110 309 1 111 316 minecraft:blackstone
fill 2 110 276 4 112 276 minecraft:basalt
setblock 2 110 277 minecraft:magma_block
fill 2 110 278 4 114 279 minecraft:basalt
setblock 2 110 280 minecraft:magma_block
fill 2 110 281 4 115 282 minecraft:basalt
setblock 2 110 283 minecraft:magma_block
fill 2 110 284 3 118 285 minecraft:basalt
setblock 2 110 286 minecraft:magma_block
fill 2 110 287 2 119 288 minecraft:basalt
setblock 2 110 289 minecraft:magma_block
fill 2 110 290 2 119 291 minecraft:basalt
setblock 2 110 292 minecraft:magma_block
fill 2 110 293 2 119 294 minecraft:basalt
setblock 2 110 295 minecraft:magma_block
fill 2 110 296 3 118 297 minecraft:basalt
setblock 2 110 298 minecraft:magma_block
fill 2 110 299 4 117 300 minecraft:basalt
setblock 2 110 301 minecraft:magma_block
fill 2 110 302 4 115 303 minecraft:basalt
setblock 2 110 304 minecraft:magma_block
fill 2 110 305 4 112 306 minecraft:basalt
setblock 2 110 307 minecraft:magma_block
fill 2 110 308 4 110 309 minecraft:basalt
fill 2 110 310 2 111 316 minecraft:blackstone
fill 3 110 277 10 114 277 minecraft:basalt
fill 3 110 280 6 116 280 minecraft:basalt
fill 3 110 283 4 118 283 minecraft:basalt
fill 3 110 286 3 120 286 minecraft:basalt
fill 3 110 287 9 110 295 minecraft:blackstone
fill 3 110 298 3 119 298 minecraft:basalt
fill 3 110 301 5 117 301 minecraft:basalt
fill 3 110 304 9 115 304 minecraft:basalt
fill 3 110 307 10 113 307 minecraft:basalt
fill 3 110 310 10 110 310 minecraft:basalt
fill 3 110 311 3 111 316 minecraft:blackstone
fill 4 110 275 4 129 275 minecraft:cobbled_deepslate
fill 4 110 284 12 110 286 minecraft:blackstone
fill 4 110 296 9 110 298 minecraft:blackstone
fill 4 110 311 7 110 311 minecraft:basalt
fill 4 110 312 5 111 316 minecraft:blackstone
setblock 5 110 276 minecraft:magma_block
fill 5 110 278 7 117 278 minecraft:basalt
setblock 5 110 279 minecraft:magma_block
fill 5 110 281 5 119 281 minecraft:basalt
setblock 5 110 282 minecraft:magma_block
fill 5 110 283 14 110 283 minecraft:blackstone
fill 5 110 299 9 110 299 minecraft:blackstone
setblock 5 110 300 minecraft:magma_block
fill 5 110 302 6 118 302 minecraft:basalt
setblock 5 110 303 minecraft:magma_block
fill 5 110 305 7 116 305 minecraft:basalt
setblock 5 110 306 minecraft:magma_block
fill 5 110 308 7 112 308 minecraft:basalt
setblock 5 110 309 minecraft:magma_block
fill 6 110 276 13 116 276 minecraft:basalt
fill 6 110 279 7 118 279 minecraft:basalt
fill 6 110 281 15 110 282 minecraft:blackstone
fill 6 110 300 9 110 301 minecraft:blackstone
fill 6 110 303 7 118 303 minecraft:basalt
fill 6 110 306 13 116 306 minecraft:basalt
fill 6 110 309 13 113 309 minecraft:basalt
fill 6 110 312 13 110 312 minecraft:basalt
fill 6 110 313 7 111 316 minecraft:blackstone
fill 7 110 280 15 110 280 minecraft:blackstone
fill 7 110 302 10 110 302 minecraft:blackstone
setblock 8 110 278 minecraft:magma_block
fill 8 110 279 15 110 279 minecraft:blackstone
fill 8 110 303 10 110 303 minecraft:blackstone
setblock 8 110 305 minecraft:magma_block
setblock 8 110 308 minecraft:magma_block
setblock 8 110 311 minecraft:magma_block
fill 8 110 313 10 110 313 minecraft:basalt
fill 8 110 314 9 111 316 minecraft:blackstone
fill 9 110 278 9 120 278 minecraft:basalt
fill 9 110 305 10 119 305 minecraft:basalt
fill 9 110 308 16 115 308 minecraft:basalt
fill 9 110 311 16 111 311 minecraft:basalt
fill 10 110 275 10 123 275 minecraft:cobbled_deepslate
fill 10 110 278 15 110 278 minecraft:blackstone
fill 10 110 287 10 111 290 minecraft:blackstone
fill 10 110 291 11 111 291 minecraft:red_nether_bricks
setblock 10 110 292 minecraft:nether_wart_block
fill 10 110 293 10 110 294 minecraft:red_nether_bricks
setblock 10 110 295 minecraft:nether_wart_block
fill 10 110 296 16 110 297 minecraft:red_nether_bricks
setblock 10 110 298 minecraft:nether_wart_block
fill 10 110 299 30 110 300 minecraft:red_nether_bricks
setblock 10 110 301 minecraft:nether_wart_block
setblock 10 110 304 minecraft:blackstone
fill 10 110 314 16 110 314 minecraft:basalt
fill 10 110 315 12 111 316 minecraft:blackstone
fill 11 110 277 15 110 277 minecraft:blackstone
fill 11 110 287 11 111 287 minecraft:blackstone
fill 11 110 288 12 111 288 minecraft:red_nether_bricks
setblock 11 110 289 minecraft:nether_wart_block
fill 11 110 290 13 110 290 minecraft:red_nether_bricks
fill 11 110 292 13 118 293 minecraft:red_nether_bricks
fill 11 110 303 28 110 303 minecraft:red_nether_bricks
setblock 11 110 304 minecraft:nether_wart_block
setblock 11 110 305 minecraft:blackstone
setblock 11 110 307 minecraft:magma_block
setblock 11 110 310 minecraft:magma_block
setblock 11 110 313 minecraft:magma_block
fill 12 110 289 13 118 289 minecraft:red_nether_bricks
fill 12 110 301 29 110 302 minecraft:red_nether_bricks
fill 12 110 307 19 118 307 minecraft:basalt
fill 12 110 310 19 115 310 minecraft:basalt
fill 12 110 313 19 111 313 minecraft:basalt
fill 13 110 284 13 111 284 minecraft:blackstone
fill 13 110 285 14 111 285 minecraft:red_nether_bricks
setblock 13 110 286 minecraft:nether_wart_block
setblock 13 110 315 minecraft:basalt
fill 13 110 316 41 111 316 minecraft:blackstone
fill 14 110 276 15 110 276 minecraft:blackstone
setblock 14 110 284 minecraft:red_nether_bricks
fill 14 110 286 14 118 286 minecraft:red_nether_bricks
fill 14 110 290 14 110 293 minecraft:red_terracotta
fill 14 110 304 22 110 306 minecraft:red_nether_bricks
setblock 14 110 309 minecraft:magma_block
setblock 14 110 312 minecraft:magma_block
setblock 14 110 315 minecraft:magma_block
fill 15 110 283 16 110 283 minecraft:nether_wart_block
fill 15 110 288 15 119 288 minecraft:red_nether_bricks
setblock 15 110 289 minecraft:red_terracotta
setblock 15 110 294 minecraft:red_terracotta
setblock 15 110 295 minecraft:red_nether_bricks
fill 15 110 309 22 116 309 minecraft:basalt
fill 15 110 312 22 112 312 minecraft:basalt
fill 15 110 315 22 110 315 minecraft:basalt
setblock 16 110 288 minecraft:red_terracotta
setblock 16 110 295 minecraft:red_terracotta
fill 17 110 276 19 110 281 minecraft:blackstone
fill 17 110 282 20 111 283 minecraft:red_nether_bricks
fill 17 110 287 19 110 287 minecraft:red_terracotta
fill 17 110 296 19 110 296 minecraft:red_terracotta
fill 17 110 297 32 110 297 minecraft:red_nether_bricks
setblock 17 110 308 minecraft:magma_block
setblock 17 110 311 minecraft:magma_block
setblock 17 110 314 minecraft:magma_block
fill 18 110 308 25 116 308 minecraft:basalt
fill 18 110 311 25 113 311 minecraft:basalt
fill 18 110 314 25 110 314 minecraft:basalt
fill 20 110 276 22 110 280 minecraft:blackstone
fill 20 110 281 22 110 281 minecraft:red_nether_bricks
fill 20 110 288 21 110 288 minecraft:red_terracotta
fill 20 110 295 21 110 295 minecraft:red_terracotta
fill 20 110 296 31 110 296 minecraft:red_nether_bricks
setblock 20 110 307 minecraft:magma_block
setblock 20 110 310 minecraft:magma_block
setblock 20 110 313 minecraft:magma_block
fill 21 110 282 25 111 282 minecraft:red_nether_bricks
fill 21 110 307 28 116 307 minecraft:basalt
fill 21 110 310 28 113 310 minecraft:basalt
fill 21 110 313 28 110 313 minecraft:basalt
fill 22 110 288 31 111 288 minecraft:red_nether_bricks
fill 22 110 289 22 110 294 minecraft:red_terracotta
fill 22 110 295 31 110 295 minecraft:red_nether_bricks
setblock 23 110 276 minecraft:magma_block
fill 23 110 277 25 110 281 minecraft:blackstone
fill 23 110 289 30 112 289 minecraft:red_nether_bricks
fill 23 110 293 30 110 294 minecraft:red_nether_bricks
fill 23 110 304 25 110 305 minecraft:red_nether_bricks
setblock 23 110 306 minecraft:magma_block
setblock 23 110 309 minecraft:magma_block
setblock 23 110 312 minecraft:magma_block
setblock 23 110 315 minecraft:magma_block
fill 24 110 276 31 115 276 minecraft:basalt
fill 24 110 306 31 115 306 minecraft:basalt
fill 24 110 309 31 112 309 minecraft:basalt
fill 24 110 312 30 110 312 minecraft:basalt
fill 24 110 315 41 111 315 minecraft:blackstone
fill 25 110 283 25 118 283 minecraft:red_nether_bricks
fill 26 110 277 28 118 277 minecraft:basalt
fill 26 110 278 26 110 282 minecraft:blackstone
fill 26 110 283 27 110 283 minecraft:nether_wart_block
setblock 26 110 304 minecraft:red_nether_bricks
setblock 26 110 305 minecraft:magma_block
setblock 26 110 308 minecraft:magma_block
setblock 26 110 311 minecraft:magma_block
setblock 26 110 314 minecraft:magma_block
fill 27 110 278 34 114 278 minecraft:basalt
fill 27 110 279 28 110 282 minecraft:blackstone
fill 27 110 304 28 118 305 minecraft:basalt
fill 27 110 308 34 111 308 minecraft:basalt
fill 27 110 311 32 110 311 minecraft:basalt
fill 27 110 314 41 111 314 minecraft:blackstone
fill 28 110 283 31 110 283 minecraft:blackstone
fill 28 110 284 28 110 285 minecraft:red_nether_bricks
setblock 29 110 277 minecraft:magma_block
fill 29 110 279 31 116 279 minecraft:basalt
fill 29 110 280 29 110 282 minecraft:blackstone
fill 29 110 284 32 110 284 minecraft:blackstone
fill 29 110 285 29 111 285 minecraft:red_nether_bricks
setblock 29 110 286 minecraft:nether_wart_block
fill 29 110 303 31 116 303 minecraft:basalt
setblock 29 110 304 minecraft:magma_block
fill 29 110 305 34 113 305 minecraft:basalt
setblock 29 110 307 minecraft:magma_block
setblock 29 110 310 minecraft:magma_block
fill 29 110 313 41 111 313 minecraft:blackstone
fill 30 110 277 37 111 277 minecraft:basalt
fill 30 110 280 37 112 280 minecraft:basalt
fill 30 110 281 30 110 282 minecraft:blackstone
fill 30 110 285 32 110 286 minecraft:blackstone
setblock 30 110 301 minecraft:red_nether_bricks
fill 30 110 302 34 115 302 minecraft:basalt
fill 30 110 304 37 111 304 minecraft:basalt
fill 30 110 307 36 110 307 minecraft:basalt
fill 30 110 310 33 110 310 minecraft:basalt
fill 31 110 281 31 119 282 minecraft:basalt
fill 31 110 287 33 110 287 minecraft:blackstone
setblock 31 110 289 minecraft:nether_wart_block
fill 31 110 291 31 114 292 minecraft:red_nether_bricks
fill 31 110 298 31 110 299 minecraft:red_nether_bricks
fill 31 110 300 31 119 301 minecraft:basalt
fill 31 110 312 41 111 312 minecraft:blackstone
setblock 32 110 276 minecraft:magma_block
setblock 32 110 279 minecraft:magma_block
fill 32 110 281 34 116 281 minecraft:basalt
setblock 32 110 282 minecraft:magma_block
fill 32 110 283 37 114 283 minecraft:basalt
fill 32 110 288 33 110 290 minecraft:blackstone
fill 32 110 291 32 111 291 minecraft:red_nether_bricks
setblock 32 110 292 minecraft:nether_wart_block
fill 32 110 294 32 111 294 minecraft:red_nether_bricks
setblock 32 110 295 minecraft:nether_wart_block
setblock 32 110 298 minecraft:nether_wart_block
fill 32 110 299 34 116 299 minecraft:basalt
setblock 32 110 300 minecraft:magma_block
fill 32 110 301 37 113 301 minecraft:basalt
setblock 32 110 303 minecraft:magma_block
setblock 32 110 306 minecraft:magma_block
setblock 32 110 309 minecraft:magma_block
fill 32 110 317 33 127 317 minecraft:cobbled_deepslate
fill 33 110 276 37 110 276 minecraft:basalt
fill 33 110 279 39 110 279 minecraft:basalt
fill 33 110 282 40 110 282 minecraft:basalt
fill 33 110 284 34 118 286 minecraft:basalt
fill 33 110 291 33 110 295 minecraft:blackstone
fill 33 110 296 34 118 298 minecraft:basalt
fill 33 110 300 40 110 300 minecraft:basalt
fill 33 110 303 39 110 303 minecraft:basalt
fill 33 110 306 37 110 306 minecraft:basalt
fill 33 110 309 34 110 309 minecraft:basalt
fill 33 110 311 41 111 311 minecraft:blackstone
fill 34 110 287 34 110 295 minecraft:basalt
fill 34 110 310 41 111 310 minecraft:blackstone
setblock 34 110 317 minecraft:purple_concrete
setblock 35 110 278 minecraft:magma_block
setblock 35 110 281 minecraft:magma_block
setblock 35 110 284 minecraft:magma_block
fill 35 110 285 37 115 286 minecraft:basalt
setblock 35 110 287 minecraft:magma_block
fill 35 110 288 37 116 289 minecraft:basalt
setblock 35 110 290 minecraft:magma_block
fill 35 110 291 37 116 292 minecraft:basalt
setblock 35 110 293 minecraft:magma_block
fill 35 110 294 37 115 295 minecraft:basalt
setblock 35 110 296 minecraft:magma_block
fill 35 110 297 37 114 298 minecraft:basalt
setblock 35 110 299 minecraft:magma_block
setblock 35 110 302 minecraft:magma_block
setblock 35 110 305 minecraft:magma_block
setblock 35 110 308 minecraft:magma_block
fill 35 110 309 41 111 309 minecraft:blackstone
fill 36 110 278 38 110 278 minecraft:basalt
fill 36 110 281 40 110 281 minecraft:basalt
fill 36 110 284 41 110 284 minecraft:basalt
fill 36 110 287 41 111 287 minecraft:basalt
fill 36 110 290 41 111 290 minecraft:basalt
fill 36 110 293 41 111 293 minecraft:basalt
fill 36 110 296 41 111 296 minecraft:basalt
fill 36 110 299 41 110 299 minecraft:basalt
fill 36 110 302 39 110 302 minecraft:basalt
fill 36 110 305 38 110 305 minecraft:basalt
fill 36 110 308 41 111 308 minecraft:blackstone
fill 37 110 307 41 111 307 minecraft:blackstone
fill 38 110 276 41 111 276 minecraft:blackstone
setblock 38 110 277 minecraft:magma_block
setblock 38 110 280 minecraft:magma_block
setblock 38 110 283 minecraft:magma_block
fill 38 110 285 40 112 285 minecraft:basalt
setblock 38 110 286 minecraft:magma_block
fill 38 110 288 40 112 288 minecraft:basalt
setblock 38 110 289 minecraft:magma_block
fill 38 110 291 40 112 291 minecraft:basalt
setblock 38 110 292 minecraft:magma_block
fill 38 110 294 40 112 294 minecraft:basalt
setblock 38 110 295 minecraft:magma_block
fill 38 110 297 40 112 297 minecraft:basalt
setblock 38 110 298 minecraft:magma_block
setblock 38 110 301 minecraft:magma_block
setblock 38 110 304 minecraft:magma_block
fill 38 110 306 41 111 306 minecraft:blackstone
fill 39 110 277 41 111 278 minecraft:blackstone
setblock 39 110 280 minecraft:basalt
fill 39 110 283 41 110 283 minecraft:basalt
fill 39 110 286 41 111 286 minecraft:basalt
fill 39 110 289 41 111 289 minecraft:basalt
fill 39 110 292 41 111 292 minecraft:basalt
fill 39 110 295 41 111 295 minecraft:basalt
fill 39 110 298 41 110 298 minecraft:basalt
fill 39 110 301 40 110 301 minecraft:basalt
fill 39 110 304 41 111 305 minecraft:blackstone
fill 40 110 279 41 111 280 minecraft:blackstone
fill 40 110 302 41 111 303 minecraft:blackstone
fill 41 110 281 41 111 282 minecraft:blackstone
setblock 41 110 285 minecraft:magma_block
setblock 41 110 288 minecraft:magma_block
setblock 41 110 291 minecraft:magma_block
setblock 41 110 294 minecraft:magma_block
setblock 41 110 297 minecraft:magma_block
fill 41 110 300 41 111 301 minecraft:blackstone
setblock 42 110 287 minecraft:amethyst_block
fill 42 110 288 42 112 290 minecraft:cobbled_deepslate
fill 42 110 310 42 126 310 minecraft:cobbled_deepslate
setblock 42 110 311 minecraft:purple_concrete
fill 42 110 312 42 129 313 minecraft:cobbled_deepslate
fill 1 111 276 1 111 307 minecraft:basalt
setblock 1 111 308 minecraft:blackstone
fill 2 111 277 2 113 277 minecraft:basalt
fill 2 111 280 2 115 280 minecraft:basalt
fill 2 111 283 2 117 283 minecraft:basalt
fill 2 111 286 2 118 286 minecraft:basalt
fill 2 111 289 3 111 289 minecraft:basalt
fill 2 111 292 2 118 292 minecraft:basalt
fill 2 111 295 3 118 295 minecraft:basalt
fill 2 111 298 2 118 298 minecraft:basalt
fill 2 111 301 2 116 301 minecraft:basalt
fill 2 111 304 2 114 304 minecraft:basalt
fill 2 111 307 2 111 308 minecraft:basalt
setblock 2 111 309 minecraft:blackstone
fill 3 111 287 3 120 288 minecraft:basalt
fill 3 111 290 9 111 292 minecraft:blackstone
fill 3 111 293 3 120 294 minecraft:basalt
fill 3 111 308 4 111 309 minecraft:basalt
setblock 3 111 310 minecraft:blackstone
setblock 4 111 284 minecraft:magma_block
fill 4 111 285 4 120 285 minecraft:basalt
fill 4 111 286 9 111 289 minecraft:blackstone
fill 4 111 293 9 111 296 minecraft:blackstone
fill 4 111 297 4 120 298 minecraft:basalt
fill 4 111 310 11 111 310 minecraft:basalt
fill 4 111 311 5 111 311 minecraft:blackstone
fill 5 111 276 5 115 276 minecraft:basalt
fill 5 111 279 5 117 279 minecraft:basalt
fill 5 111 282 5 120 283 minecraft:basalt
fill 5 111 284 12 111 285 minecraft:blackstone
fill 5 111 297 9 111 298 minecraft:blackstone
fill 5 111 299 5 120 300 minecraft:basalt
fill 5 111 303 5 117 303 minecraft:basalt
fill 5 111 306 5 115 306 minecraft:basalt
fill 5 111 309 5 112 309 minecraft:basalt
fill 6 111 281 6 120 281 minecraft:basalt
fill 6 111 282 14 111 283 minecraft:blackstone
fill 6 111 299 9 111 300 minecraft:blackstone
fill 6 111 301 6 120 301 minecraft:basalt
fill 6 111 311 8 111 311 minecraft:basalt
fill 6 111 312 7 111 312 minecraft:blackstone
setblock 7 111 280 minecraft:magma_block
fill 7 111 281 18 111 281 minecraft:blackstone
fill 7 111 301 9 111 301 minecraft:blackstone
fill 7 111 302 7 120 302 minecraft:basalt
fill 8 111 278 8 118 279 minecraft:basalt
fill 8 111 280 28 111 280 minecraft:blackstone
fill 8 111 302 10 111 302 minecraft:blackstone
fill 8 111 303 8 120 303 minecraft:basalt
fill 8 111 305 8 118 305 minecraft:basalt
fill 8 111 308 8 115 308 minecraft:basalt
fill 8 111 312 14 111 312 minecraft:basalt
fill 8 111 313 9 111 313 minecraft:blackstone
fill 9 111 279 27 111 279 minecraft:blackstone
fill 9 111 303 10 111 303 minecraft:blackstone
fill 10 111 278 10 120 278 minecraft:basalt
fill 10 111 286 11 111 286 minecraft:blackstone
fill 10 111 292 10 112 292 minecraft:red_nether_bricks
setblock 10 111 293 minecraft:nether_wart_block
fill 10 111 294 10 111 295 minecraft:red_nether_bricks
setblock 10 111 296 minecraft:nether_wart_block
fill 10 111 297 10 111 298 minecraft:red_nether_bricks
setblock 10 111 299 minecraft:nether_wart_block
fill 10 111 300 10 111 301 minecraft:red_nether_bricks
fill 10 111 304 10 120 304 minecraft:basalt
fill 10 111 313 11 111 313 minecraft:basalt
fill 10 111 314 12 111 314 minecraft:blackstone
fill 11 111 277 12 111 277 minecraft:basalt
fill 11 111 278 25 111 278 minecraft:blackstone
fill 11 111 289 11 112 289 minecraft:red_nether_bricks
setblock 11 111 290 minecraft:nether_wart_block
fill 11 111 296 15 112 297 minecraft:red_nether_bricks
fill 11 111 299 30 111 300 minecraft:red_nether_bricks
setblock 11 111 302 minecraft:nether_wart_block
fill 11 111 303 11 111 304 minecraft:red_nether_bricks
fill 11 111 305 12 120 305 minecraft:basalt
fill 11 111 307 11 118 307 minecraft:basalt
fill 12 111 286 13 112 286 minecraft:red_nether_bricks
setblock 12 111 287 minecraft:nether_wart_block
fill 12 111 290 13 119 290 minecraft:red_nether_bricks
fill 12 111 301 27 111 303 minecraft:red_nether_bricks
fill 13 111 277 23 111 277 minecraft:blackstone
fill 13 111 287 16 116 287 minecraft:red_nether_bricks
fill 13 111 305 23 111 305 minecraft:red_nether_bricks
setblock 13 111 314 minecraft:magma_block
fill 13 111 315 23 111 315 minecraft:blackstone
fill 14 111 276 16 111 276 minecraft:basalt
setblock 14 111 284 minecraft:nether_wart_block
fill 14 111 290 14 111 293 minecraft:magma_block
fill 14 111 304 25 111 304 minecraft:red_nether_bricks
fill 14 111 306 16 111 306 minecraft:basalt
fill 14 111 309 14 116 309 minecraft:basalt
fill 14 111 314 21 111 314 minecraft:basalt
fill 15 111 282 16 111 282 minecraft:blackstone
fill 15 111 283 16 112 283 minecraft:red_nether_bricks
setblock 15 111 289 minecraft:magma_block
fill 15 111 294 15 111 295 minecraft:magma_block
setblock 16 111 288 minecraft:magma_block
fill 16 111 296 17 111 296 minecraft:magma_block
fill 16 111 297 17 111 297 minecraft:red_nether_bricks
fill 17 111 276 19 111 276 minecraft:blackstone
fill 17 111 287 20 111 287 minecraft:magma_block
fill 17 111 306 19 111 306 minecraft:red_nether_bricks
fill 17 111 308 17 118 308 minecraft:basalt
fill 17 111 311 17 115 311 minecraft:basalt
fill 18 111 297 19 111 297 minecraft:magma_block
fill 19 111 281 23 111 281 minecraft:nether_wart_block
fill 20 111 276 23 118 276 minecraft:basalt
fill 20 111 296 21 111 296 minecraft:magma_block
fill 20 111 297 31 111 297 minecraft:red_nether_bricks
fill 20 111 306 20 118 307 minecraft:basalt
fill 20 111 310 20 116 310 minecraft:basalt
fill 20 111 313 24 111 313 minecraft:basalt
fill 21 111 287 29 112 287 minecraft:red_nether_bricks
setblock 21 111 288 minecraft:magma_block
fill 21 111 306 23 118 306 minecraft:basalt
setblock 22 111 289 minecraft:magma_block
fill 22 111 294 22 111 295 minecraft:magma_block
fill 22 111 296 31 111 296 minecraft:red_nether_bricks
setblock 22 111 314 minecraft:magma_block
fill 23 111 290 23 111 293 minecraft:magma_block
fill 23 111 294 30 111 295 minecraft:red_nether_bricks
fill 23 111 309 23 116 309 minecraft:basalt
fill 23 111 312 27 111 312 minecraft:basalt
setblock 23 111 314 minecraft:basalt
fill 24 111 277 24 120 277 minecraft:basalt
fill 24 111 281 29 111 281 minecraft:blackstone
fill 24 111 290 29 112 293 minecraft:red_nether_bricks
fill 24 111 305 26 118 305 minecraft:basalt
fill 24 111 314 26 111 314 minecraft:blackstone
setblock 25 111 277 minecraft:magma_block
setblock 25 111 313 minecraft:magma_block
fill 26 111 275 28 129 275 minecraft:cobbled_deepslate
fill 26 111 278 26 120 278 minecraft:basalt
fill 26 111 282 30 111 282 minecraft:blackstone
fill 26 111 283 27 112 283 minecraft:red_nether_bricks
fill 26 111 304 26 120 304 minecraft:basalt
fill 26 111 308 26 116 308 minecraft:basalt
fill 26 111 311 30 111 311 minecraft:basalt
setblock 26 111 313 minecraft:basalt
fill 27 111 313 28 111 313 minecraft:blackstone
setblock 28 111 279 minecraft:magma_block
fill 28 111 283 30 111 283 minecraft:blackstone
setblock 28 111 284 minecraft:nether_wart_block
fill 28 111 285 28 116 285 minecraft:red_nether_bricks
fill 28 111 301 28 111 302 minecraft:red_nether_bricks
setblock 28 111 303 minecraft:magma_block
setblock 28 111 312 minecraft:magma_block
setblock 29 111 275 minecraft:amethyst_block
fill 29 111 277 29 117 277 minecraft:basalt
fill 29 111 280 29 120 280 minecraft:basalt
fill 29 111 284 31 111 284 minecraft:blackstone
fill 29 111 286 30 112 286 minecraft:red_nether_bricks
setblock 29 111 301 minecraft:red_nether_bricks
fill 29 111 302 29 120 302 minecraft:basalt
fill 29 111 304 29 118 304 minecraft:basalt
fill 29 111 307 35 111 307 minecraft:basalt
fill 29 111 310 32 111 310 minecraft:basalt
fill 29 111 312 30 111 312 minecraft:blackstone
fill 30 111 281 30 120 281 minecraft:basalt
fill 30 111 285 31 111 285 minecraft:blackstone
setblock 30 111 287 minecraft:nether_wart_block
fill 30 111 293 30 115 293 minecraft:red_nether_bricks
fill 30 111 301 30 120 301 minecraft:basalt
fill 31 111 283 31 120 283 minecraft:basalt
fill 31 111 286 32 111 287 minecraft:blackstone
fill 31 111 289 31 112 289 minecraft:red_nether_bricks
setblock 31 111 290 minecraft:nether_wart_block
fill 31 111 295 32 111 295 minecraft:red_nether_bricks
setblock 31 111 298 minecraft:red_nether_bricks
setblock 31 111 299 minecraft:magma_block
fill 31 111 311 32 111 311 minecraft:blackstone
fill 32 111 276 36 111 276 minecraft:basalt
fill 32 111 279 38 111 279 minecraft:basalt
fill 32 111 282 39 111 282 minecraft:basalt
fill 32 111 284 32 120 285 minecraft:basalt
fill 32 111 288 32 111 290 minecraft:blackstone
fill 32 111 292 32 112 292 minecraft:red_nether_bricks
setblock 32 111 293 minecraft:nether_wart_block
setblock 32 111 296 minecraft:nether_wart_block
fill 32 111 297 32 120 298 minecraft:basalt
fill 32 111 300 39 111 300 minecraft:basalt
fill 32 111 303 38 111 303 minecraft:basalt
fill 32 111 306 36 111 306 minecraft:basalt
fill 32 111 309 33 111 309 minecraft:basalt
fill 33 111 287 34 111 289 minecraft:basalt
fill 33 111 290 33 111 292 minecraft:blackstone
fill 33 111 293 34 111 295 minecraft:basalt
setblock 33 111 310 minecraft:blackstone
fill 34 111 290 34 119 291 minecraft:basalt
setblock 34 111 292 minecraft:magma_block
setblock 34 111 309 minecraft:blackstone
fill 34 111 317 34 129 317 minecraft:cobbled_deepslate
fill 35 111 278 37 111 278 minecraft:basalt
fill 35 111 281 39 111 281 minecraft:basalt
fill 35 111 284 39 112 284 minecraft:basalt
fill 35 111 287 35 118 287 minecraft:basalt
fill 35 111 290 35 118 290 minecraft:basalt
fill 35 111 293 35 118 293 minecraft:basalt
fill 35 111 296 35 117 296 minecraft:basalt
fill 35 111 299 39 112 299 minecraft:basalt
fill 35 111 302 38 111 302 minecraft:basalt
fill 35 111 305 37 111 305 minecraft:basalt
setblock 35 111 308 minecraft:blackstone
setblock 36 111 307 minecraft:blackstone
setblock 37 111 276 minecraft:blackstone
setblock 37 111 306 minecraft:blackstone
fill 38 111 277 38 111 278 minecraft:blackstone
setblock 38 111 280 minecraft:basalt
fill 38 111 283 40 111 283 minecraft:basalt
fill 38 111 286 38 114 286 minecraft:basalt
fill 38 111 289 38 115 289 minecraft:basalt
fill 38 111 292 38 115 292 minecraft:basalt
fill 38 111 295 38 114 295 minecraft:basalt
fill 38 111 298 40 111 298 minecraft:basalt
fill 38 111 301 39 111 301 minecraft:basalt
fill 38 111 304 38 111 305 minecraft:blackstone
fill 39 111 279 39 111 280 minecraft:blackstone
fill 39 111 302 39 111 303 minecraft:blackstone
fill 40 111 281 40 111 282 minecraft:blackstone
setblock 40 111 284 minecraft:magma_block
setblock 40 111 299 minecraft:magma_block
fill 40 111 300 40 111 301 minecraft:blackstone
fill 41 111 283 41 111 285 minecraft:blackstone
setblock 41 111 288 minecraft:basalt
setblock 41 111 291 minecraft:basalt
setblock 41 111 294 minecraft:basalt
fill 41 111 297 41 111 299 minecraft:blackstone
fill 42 111 287 42 129 287 minecraft:cobbled_deepslate
fill 42 111 311 42 129 311 minecraft:cobbled_deepslate
setblock 0 112 293 minecraft:magma_block
fill 1 112 276 1 112 306 minecraft:basalt
fill 2 112 289 2 118 289 minecraft:basalt
setblock 2 112 307 minecraft:basalt
setblock 3 112 289 minecraft:magma_block
fill 3 112 290 3 120 291 minecraft:basalt
setblock 3 112 292 minecraft:magma_block
fill 3 112 308 4 112 308 minecraft:basalt
fill 4 112 284 5 119 284 minecraft:basalt
fill 4 112 286 4 121 287 minecraft:basalt
fill 4 112 295 4 121 296 minecraft:basalt
setblock 4 112 309 minecraft:basalt
fill 5 112 298 5 121 298 minecraft:basalt
setblock 6 112 282 minecraft:magma_block
setblock 6 112 300 minecraft:magma_block
fill 6 112 310 11 112 310 minecraft:basalt
setblock 7 112 275 minecraft:magma_block
fill 7 112 280 7 119 281 minecraft:basalt
fill 7 112 301 7 121 301 minecraft:basalt
fill 8 112 280 8 121 280 minecraft:basalt
fill 8 112 302 8 121 302 minecraft:basalt
setblock 8 112 311 minecraft:basalt
fill 9 112 279 9 120 279 minecraft:basalt
fill 9 112 303 9 120 303 minecraft:basalt
setblock 9 112 311 minecraft:magma_block
fill 10 112 290 11 113 290 minecraft:red_nether_bricks
setblock 10 112 291 minecraft:nether_wart_block
fill 10 112 293 10 113 293 minecraft:red_nether_bricks
setblock 10 112 294 minecraft:nether_wart_block
fill 10 112 295 10 112 296 minecraft:red_nether_bricks
setblock 10 112 297 minecraft:nether_wart_block
fill 10 112 298 10 112 299 minecraft:red_nether_bricks
setblock 10 112 300 minecraft:nether_wart_block
fill 10 112 301 10 112 302 minecraft:red_nether_bricks
fill 10 112 311 14 112 312 minecraft:basalt
fill 11 112 277 11 120 278 minecraft:basalt
setblock 11 112 288 minecraft:nether_wart_block
fill 11 112 291 11 117 291 minecraft:red_nether_bricks
fill 11 112 294 13 117 295 minecraft:red_nether_bricks
fill 11 112 299 29 112 300 minecraft:red_nether_bricks
fill 11 112 302 27 112 302 minecraft:red_nether_bricks
setblock 11 112 303 minecraft:nether_wart_block
fill 11 112 304 11 121 304 minecraft:basalt
setblock 12 112 277 minecraft:magma_block
fill 12 112 287 12 113 288 minecraft:red_nether_bricks
fill 12 112 301 28 112 301 minecraft:red_nether_bricks
fill 12 112 303 26 112 303 minecraft:red_nether_bricks
setblock 12 112 313 minecraft:magma_block
fill 13 112 277 14 121 277 minecraft:basalt
setblock 13 112 285 minecraft:nether_wart_block
fill 13 112 305 14 112 305 minecraft:basalt
fill 13 112 313 20 112 313 minecraft:basalt
fill 14 112 276 14 120 276 minecraft:basalt
fill 14 112 284 14 113 285 minecraft:red_nether_bricks
fill 14 112 290 14 113 294 minecraft:red_terracotta
setblock 14 112 295 minecraft:red_nether_bricks
fill 14 112 304 24 112 304 minecraft:red_nether_bricks
fill 14 112 306 14 120 306 minecraft:basalt
setblock 15 112 276 minecraft:magma_block
fill 15 112 289 15 113 289 minecraft:red_terracotta
setblock 15 112 295 minecraft:red_terracotta
fill 15 112 305 21 112 305 minecraft:red_nether_bricks
setblock 15 112 306 minecraft:magma_block
fill 15 112 311 16 114 311 minecraft:basalt
fill 16 112 276 19 119 276 minecraft:basalt
fill 16 112 282 18 112 282 minecraft:nether_wart_block
fill 16 112 288 16 113 288 minecraft:red_terracotta
setblock 16 112 296 minecraft:red_terracotta
setblock 16 112 297 minecraft:red_nether_bricks
fill 16 112 306 19 119 306 minecraft:basalt
fill 17 112 283 20 118 283 minecraft:red_nether_bricks
fill 17 112 287 20 113 287 minecraft:red_terracotta
fill 17 112 297 21 112 297 minecraft:red_terracotta
fill 19 112 281 23 113 282 minecraft:red_nether_bricks
setblock 21 112 288 minecraft:red_terracotta
setblock 21 112 313 minecraft:magma_block
fill 22 112 277 23 121 277 minecraft:basalt
fill 22 112 288 30 112 288 minecraft:red_nether_bricks
setblock 22 112 289 minecraft:red_terracotta
fill 22 112 295 22 112 296 minecraft:red_terracotta
fill 22 112 297 31 112 297 minecraft:red_nether_bricks
fill 22 112 305 23 121 305 minecraft:basalt
fill 22 112 313 24 112 313 minecraft:basalt
fill 23 112 290 23 112 294 minecraft:red_terracotta
fill 23 112 295 31 112 296 minecraft:red_nether_bricks
fill 23 112 312 26 112 312 minecraft:basalt
fill 24 112 282 26 112 282 minecraft:nether_wart_block
fill 24 112 294 30 112 294 minecraft:red_nether_bricks
fill 25 112 277 25 119 278 minecraft:basalt
fill 25 112 304 25 121 304 minecraft:basalt
fill 26 112 311 26 113 311 minecraft:basalt
fill 27 112 279 28 119 279 minecraft:basalt
fill 27 112 303 28 119 303 minecraft:basalt
fill 27 112 308 33 112 308 minecraft:basalt
setblock 27 112 311 minecraft:magma_block
fill 28 112 280 28 121 280 minecraft:basalt
fill 28 112 284 28 113 284 minecraft:red_nether_bricks
fill 28 112 302 28 121 302 minecraft:basalt
setblock 28 112 311 minecraft:basalt
fill 29 112 275 29 127 275 minecraft:cobbled_deepslate
fill 29 112 281 29 121 281 minecraft:basalt
setblock 29 112 285 minecraft:nether_wart_block
fill 29 112 301 29 121 301 minecraft:basalt
fill 29 112 307 34 112 307 minecraft:basalt
setblock 29 112 310 minecraft:basalt
fill 30 112 277 36 112 277 minecraft:basalt
fill 30 112 282 30 120 282 minecraft:basalt
fill 30 112 287 30 113 287 minecraft:red_nether_bricks
setblock 30 112 299 minecraft:red_nether_bricks
fill 30 112 300 30 120 300 minecraft:basalt
fill 30 112 304 36 112 304 minecraft:basalt
setblock 30 112 310 minecraft:magma_block
fill 31 112 284 31 121 284 minecraft:basalt
setblock 31 112 288 minecraft:nether_wart_block
fill 31 112 290 32 112 290 minecraft:red_nether_bricks
fill 31 112 298 31 119 299 minecraft:basalt
fill 32 112 276 35 112 276 minecraft:basalt
fill 32 112 279 37 112 279 minecraft:basalt
fill 32 112 282 38 112 282 minecraft:basalt
fill 32 112 286 32 112 287 minecraft:basalt
setblock 32 112 291 minecraft:nether_wart_block
setblock 32 112 293 minecraft:red_nether_bricks
setblock 32 112 294 minecraft:nether_wart_block
fill 32 112 295 32 121 296 minecraft:basalt
fill 32 112 300 38 112 300 minecraft:basalt
fill 32 112 303 37 112 303 minecraft:basalt
fill 32 112 306 35 112 306 minecraft:basalt
setblock 32 112 309 minecraft:basalt
fill 33 112 287 34 119 287 minecraft:basalt
setblock 33 112 288 minecraft:magma_block
fill 33 112 289 33 120 290 minecraft:basalt
setblock 33 112 291 minecraft:magma_block
fill 33 112 292 34 119 293 minecraft:basalt
setblock 33 112 294 minecraft:magma_block
fill 33 112 295 34 119 295 minecraft:basalt
fill 34 112 288 34 119 289 minecraft:basalt
fill 34 112 294 34 119 294 minecraft:basalt
fill 35 112 278 35 113 278 minecraft:basalt
fill 35 112 281 38 112 281 minecraft:basalt
fill 35 112 302 37 112 302 minecraft:basalt
setblock 35 112 305 minecraft:basalt
setblock 36 112 278 minecraft:magma_block
fill 36 112 287 40 112 287 minecraft:basalt
fill 36 112 290 40 112 290 minecraft:basalt
fill 36 112 293 40 112 293 minecraft:basalt
fill 36 112 296 40 112 296 minecraft:basalt
setblock 36 112 305 minecraft:magma_block
fill 38 112 283 38 113 283 minecraft:basalt
fill 38 112 298 38 113 298 minecraft:basalt
setblock 38 112 301 minecraft:basalt
setblock 39 112 283 minecraft:magma_block
fill 39 112 286 40 112 286 minecraft:basalt
fill 39 112 289 40 112 289 minecraft:basalt
fill 39 112 292 40 112 292 minecraft:basalt
fill 39 112 295 40 112 295 minecraft:basalt
setblock 39 112 298 minecraft:magma_block
fill 0 113 293 0 129 293 minecraft:cobbled_deepslate
fill 1 113 278 1 113 304 minecraft:basalt
setblock 2 113 276 minecraft:magma_block
fill 2 113 305 4 113 305 minecraft:basalt
setblock 2 113 306 minecraft:magma_block
fill 3 113 276 4 113 276 minecraft:basalt
fill 3 113 289 4 113 289 minecraft:basalt
fill 3 113 292 4 113 292 minecraft:basalt
fill 3 113 306 4 113 306 minecraft:basalt
setblock 3 113 310 minecraft:light[level=12]
fill 4 113 288 4 121 288 minecraft:basalt
fill 4 113 290 4 122 291 minecraft:basalt
fill 4 113 293 4 121 294 minecraft:basalt
fill 5 113 285 5 121 286 minecraft:basalt
setblock 5 113 296 minecraft:magma_block
fill 5 113 297 5 121 297 minecraft:basalt
setblock 5 113 308 minecraft:magma_block
fill 6 113 282 6 120 284 minecraft:basalt
fill 6 113 298 6 120 300 minecraft:basalt
fill 6 113 308 7 114 308 minecraft:basalt
fill 7 113 275 7 129 275 minecraft:cobbled_deepslate
fill 7 113 282 7 121 282 minecraft:basalt
fill 7 113 300 7 121 300 minecraft:basalt
fill 8 113 281 8 121 281 minecraft:basalt
setblock 8 113 301 minecraft:magma_block
setblock 8 113 310 minecraft:magma_block
fill 9 113 280 9 121 280 minecraft:basalt
fill 9 113 302 9 120 302 minecraft:basalt
fill 9 113 310 11 113 311 minecraft:basalt
fill 10 113 279 10 121 279 minecraft:basalt
fill 10 113 291 10 114 291 minecraft:red_nether_bricks
setblock 10 113 292 minecraft:nether_wart_block
fill 10 113 294 10 114 294 minecraft:red_nether_bricks
setblock 10 113 295 minecraft:nether_wart_block
fill 10 113 296 14 113 297 minecraft:red_nether_bricks
setblock 10 113 298 minecraft:nether_wart_block
fill 10 113 299 28 113 300 minecraft:red_nether_bricks
setblock 10 113 301 minecraft:nether_wart_block
fill 10 113 302 26 113 302 minecraft:red_nether_bricks
fill 10 113 303 10 121 303 minecraft:basalt
setblock 11 113 279 minecraft:magma_block
setblock 11 113 286 minecraft:light[level=12]
fill 11 113 288 11 114 288 minecraft:red_nether_bricks
setblock 11 113 289 minecraft:nether_wart_block
setblock 11 113 303 minecraft:magma_block
fill 12 113 277 12 120 278 minecraft:basalt
setblock 12 113 286 minecraft:nether_wart_block
fill 12 113 298 16 113 298 minecraft:red_nether_bricks
fill 12 113 301 27 113 301 minecraft:red_nether_bricks
fill 12 113 303 24 113 303 minecraft:red_nether_bricks
fill 12 113 304 13 113 304 minecraft:basalt
fill 12 113 311 14 113 312 minecraft:basalt
fill 13 113 278 13 122 278 minecraft:basalt
fill 13 113 285 13 114 286 minecraft:red_nether_bricks
fill 13 113 305 13 121 305 minecraft:basalt
setblock 14 113 295 minecraft:red_terracotta
fill 14 113 304 22 113 304 minecraft:red_nether_bricks
setblock 14 113 305 minecraft:magma_block
fill 15 113 276 15 120 277 minecraft:basalt
setblock 15 113 283 minecraft:nether_wart_block
setblock 15 113 296 minecraft:red_terracotta
setblock 15 113 297 minecraft:red_nether_bricks
fill 15 113 305 15 120 306 minecraft:basalt
fill 15 113 312 19 113 312 minecraft:basalt
fill 16 113 277 16 121 277 minecraft:basalt
fill 16 113 282 16 113 283 minecraft:red_nether_bricks
setblock 16 113 297 minecraft:red_terracotta
fill 16 113 305 21 113 305 minecraft:basalt
setblock 17 113 277 minecraft:magma_block
fill 17 113 282 18 114 282 minecraft:red_nether_bricks
fill 17 113 298 21 113 298 minecraft:red_terracotta
fill 18 113 277 21 120 277 minecraft:basalt
setblock 19 113 278 minecraft:light[level=12]
setblock 19 113 294 minecraft:light[level=12]
setblock 20 113 312 minecraft:magma_block
setblock 21 113 287 minecraft:red_terracotta
fill 21 113 312 24 113 312 minecraft:basalt
fill 22 113 287 29 114 287 minecraft:red_nether_bricks
setblock 22 113 288 minecraft:red_terracotta
setblock 22 113 297 minecraft:red_terracotta
fill 22 113 298 29 113 298 minecraft:red_nether_bricks
setblock 23 113 278 minecraft:magma_block
fill 23 113 288 31 113 288 minecraft:red_nether_bricks
fill 23 113 289 23 113 290 minecraft:red_terracotta
fill 23 113 295 23 113 296 minecraft:red_terracotta
fill 23 113 297 30 113 297 minecraft:red_nether_bricks
fill 23 113 304 24 121 304 minecraft:basalt
fill 24 113 278 24 121 278 minecraft:basalt
fill 24 113 282 26 113 282 minecraft:red_nether_bricks
fill 24 113 289 29 113 290 minecraft:red_nether_bricks
fill 24 113 291 24 113 294 minecraft:red_terracotta
fill 24 113 295 30 113 296 minecraft:red_nether_bricks
fill 24 113 309 28 114 309 minecraft:basalt
fill 25 113 279 26 113 279 minecraft:basalt
fill 25 113 291 29 114 294 minecraft:red_nether_bricks
fill 25 113 303 26 113 303 minecraft:basalt
fill 26 113 283 26 115 283 minecraft:red_nether_bricks
fill 27 113 280 27 121 280 minecraft:basalt
setblock 27 113 283 minecraft:nether_wart_block
fill 27 113 302 27 120 302 minecraft:basalt
fill 27 113 308 31 113 308 minecraft:basalt
setblock 27 113 311 minecraft:basalt
fill 28 113 281 28 121 281 minecraft:basalt
fill 28 113 301 28 121 301 minecraft:basalt
setblock 29 113 282 minecraft:magma_block
fill 29 113 285 29 114 286 minecraft:red_nether_bricks
setblock 29 113 299 minecraft:red_nether_bricks
setblock 29 113 300 minecraft:magma_block
fill 29 113 307 33 113 307 minecraft:basalt
setblock 29 113 309 minecraft:magma_block
fill 30 113 277 34 113 277 minecraft:basalt
fill 30 113 280 36 113 280 minecraft:basalt
fill 30 113 283 30 120 284 minecraft:basalt
setblock 30 113 286 minecraft:nether_wart_block
fill 30 113 289 30 115 289 minecraft:red_nether_bricks
fill 30 113 294 30 115 294 minecraft:red_nether_bricks
fill 30 113 298 30 121 299 minecraft:basalt
fill 30 113 304 34 114 304 minecraft:basalt
setblock 30 113 309 minecraft:basalt
fill 31 113 285 31 113 286 minecraft:basalt
setblock 31 113 289 minecraft:nether_wart_block
setblock 31 113 290 minecraft:red_nether_bricks
setblock 31 113 295 minecraft:red_nether_bricks
fill 31 113 296 31 121 297 minecraft:basalt
fill 32 113 276 34 113 276 minecraft:basalt
fill 32 113 279 36 113 279 minecraft:basalt
fill 32 113 282 37 114 282 minecraft:basalt
fill 32 113 286 32 121 286 minecraft:basalt
setblock 32 113 287 minecraft:magma_block
fill 32 113 288 32 121 289 minecraft:basalt
setblock 32 113 290 minecraft:magma_block
fill 32 113 291 32 122 292 minecraft:basalt
setblock 32 113 293 minecraft:magma_block
fill 32 113 294 33 120 294 minecraft:basalt
fill 32 113 300 37 114 300 minecraft:basalt
fill 32 113 303 36 113 303 minecraft:basalt
fill 32 113 306 34 113 306 minecraft:basalt
fill 33 113 288 33 120 288 minecraft:basalt
fill 33 113 291 33 120 291 minecraft:basalt
fill 35 113 281 37 113 281 minecraft:basalt
fill 35 113 284 38 113 284 minecraft:basalt
fill 35 113 299 38 113 299 minecraft:basalt
fill 35 113 302 36 113 302 minecraft:basalt
setblock 35 113 304 minecraft:magma_block
setblock 35 113 310 minecraft:light[level=12]
fill 36 113 287 39 113 287 minecraft:basalt
fill 36 113 290 39 114 290 minecraft:basalt
fill 36 113 293 39 113 293 minecraft:basalt
fill 36 113 296 39 113 296 minecraft:basalt
setblock 38 113 282 minecraft:magma_block
fill 38 113 285 39 113 285 minecraft:basalt
fill 38 113 288 39 113 288 minecraft:basalt
fill 38 113 291 39 114 291 minecraft:basalt
fill 38 113 294 39 113 294 minecraft:basalt
fill 38 113 297 39 113 297 minecraft:basalt
setblock 38 113 300 minecraft:magma_block
setblock 39 113 286 minecraft:basalt
setblock 39 113 289 minecraft:basalt
fill 39 113 292 39 114 292 minecraft:basalt
setblock 39 113 295 minecraft:basalt
fill 42 113 288 42 129 288 minecraft:cobbled_deepslate
setblock 42 113 289 minecraft:amethyst_block
fill 42 113 290 42 129 290 minecraft:cobbled_deepslate
fill 1 114 279 1 114 301 minecraft:basalt
setblock 1 114 302 minecraft:magma_block
setblock 1 114 303 minecraft:basalt
fill 3 114 289 3 120 289 minecraft:basalt
fill 3 114 292 3 120 292 minecraft:basalt
fill 3 114 305 4 114 305 minecraft:basalt
setblock 3 114 306 minecraft:light[level=12]
setblock 3 114 313 minecraft:light[level=12]
setblock 4 114 276 minecraft:basalt
setblock 4 114 289 minecraft:magma_block
setblock 4 114 292 minecraft:magma_block
setblock 4 114 306 minecraft:basalt
fill 5 114 287 5 121 288 minecraft:basalt
fill 5 114 294 5 121 296 minecraft:basalt
fill 5 114 307 10 114 307 minecraft:basalt
fill 6 114 285 6 122 285 minecraft:basalt
fill 6 114 297 6 122 297 minecraft:basalt
fill 7 114 283 7 122 283 minecraft:basalt
fill 7 114 299 7 122 299 minecraft:basalt
fill 8 114 282 8 122 282 minecraft:basalt
fill 8 114 300 8 121 301 minecraft:basalt
fill 8 114 309 13 114 309 minecraft:basalt
fill 9 114 281 9 122 281 minecraft:basalt
fill 9 114 301 9 122 301 minecraft:basalt
fill 9 114 310 11 114 310 minecraft:basalt
fill 10 114 280 10 122 280 minecraft:basalt
setblock 10 114 285 minecraft:light[level=12]
fill 10 114 292 10 115 292 minecraft:red_nether_bricks
setblock 10 114 293 minecraft:nether_wart_block
fill 10 114 295 10 115 295 minecraft:red_nether_bricks
setblock 10 114 296 minecraft:nether_wart_block
fill 10 114 297 10 114 298 minecraft:red_nether_bricks
setblock 10 114 299 minecraft:nether_wart_block
fill 10 114 300 10 114 301 minecraft:red_nether_bricks
setblock 10 114 302 minecraft:magma_block
setblock 10 114 313 minecraft:light[level=12]
fill 11 114 279 12 114 279 minecraft:basalt
fill 11 114 289 11 115 289 minecraft:red_nether_bricks
setblock 11 114 290 minecraft:nether_wart_block
fill 11 114 296 14 114 297 minecraft:red_nether_bricks
fill 11 114 299 16 115 300 minecraft:red_nether_bricks
setblock 11 114 302 minecraft:nether_wart_block
fill 11 114 303 12 114 303 minecraft:basalt
setblock 12 114 286 minecraft:red_nether_bricks
setblock 12 114 287 minecraft:nether_wart_block
fill 12 114 288 12 117 288 minecraft:red_nether_bricks
fill 12 114 298 15 115 298 minecraft:red_nether_bricks
fill 12 114 301 25 114 302 minecraft:red_nether_bricks
fill 12 114 304 12 120 304 minecraft:basalt
fill 12 114 311 14 114 311 minecraft:basalt
fill 13 114 303 23 114 303 minecraft:red_nether_bricks
setblock 13 114 304 minecraft:magma_block
fill 14 114 278 15 114 278 minecraft:basalt
setblock 14 114 284 minecraft:nether_wart_block
fill 14 114 285 14 117 285 minecraft:red_nether_bricks
fill 14 114 290 14 114 295 minecraft:magma_block
fill 14 114 304 14 121 305 minecraft:basalt
fill 15 114 283 16 115 283 minecraft:red_nether_bricks
fill 15 114 286 17 118 286 minecraft:red_nether_bricks
setblock 15 114 289 minecraft:magma_block
fill 15 114 296 15 114 297 minecraft:magma_block
fill 15 114 304 15 122 304 minecraft:basalt
setblock 16 114 288 minecraft:magma_block
setblock 16 114 298 minecraft:magma_block
fill 16 114 304 20 114 304 minecraft:red_nether_bricks
fill 16 114 305 18 120 305 minecraft:basalt
fill 17 114 277 17 121 277 minecraft:basalt
setblock 17 114 278 minecraft:light[level=12]
setblock 17 114 287 minecraft:magma_block
setblock 17 114 292 minecraft:light[level=12]
fill 17 114 299 21 114 299 minecraft:magma_block
fill 17 114 300 27 114 300 minecraft:red_nether_bricks
fill 17 114 312 19 114 312 minecraft:basalt
setblock 17 114 313 minecraft:light[level=12]
fill 18 114 286 20 114 286 minecraft:magma_block
fill 18 114 311 24 114 311 minecraft:basalt
fill 19 114 281 23 114 281 minecraft:nether_wart_block
fill 19 114 282 25 114 282 minecraft:red_nether_bricks
setblock 19 114 305 minecraft:magma_block
fill 20 114 305 21 121 305 minecraft:basalt
fill 21 114 278 23 121 278 minecraft:basalt
fill 21 114 286 27 115 286 minecraft:red_nether_bricks
setblock 21 114 287 minecraft:magma_block
fill 21 114 304 21 122 304 minecraft:basalt
fill 21 114 310 27 114 310 minecraft:basalt
setblock 22 114 288 minecraft:magma_block
setblock 22 114 298 minecraft:magma_block
fill 22 114 299 28 114 299 minecraft:red_nether_bricks
setblock 22 114 304 minecraft:magma_block
fill 23 114 288 30 114 288 minecraft:red_nether_bricks
setblock 23 114 289 minecraft:magma_block
fill 23 114 296 23 114 297 minecraft:magma_block
fill 23 114 298 29 114 298 minecraft:red_nether_bricks
schedule function dropper:buildpart/60_2 1t
