fill 500 -7 458 500 -5 458 minecraft:blackstone
fill 501 -7 416 501 -4 416 minecraft:blackstone
setblock 501 -7 458 minecraft:orange_concrete
setblock 502 -7 416 minecraft:orange_concrete
fill 505 -7 416 506 -7 416 minecraft:orange_concrete
fill 512 -7 426 512 -4 426 minecraft:blackstone
setblock 512 -7 430 minecraft:orange_concrete
fill 512 -7 437 512 -4 437 minecraft:blackstone
setblock 512 -7 438 minecraft:orange_concrete
setblock 512 -7 441 minecraft:orange_concrete
fill 512 -7 457 512 -4 457 minecraft:blackstone
setblock 512 -7 458 minecraft:orange_concrete
fill 470 -6 416 470 -1 417 minecraft:blackstone
setblock 470 -6 418 minecraft:orange_concrete
fill 470 -6 420 470 -1 420 minecraft:blackstone
fill 470 -6 426 470 -5 427 minecraft:orange_concrete
fill 470 -6 428 470 -1 429 minecraft:blackstone
fill 470 -6 437 470 -1 437 minecraft:blackstone
fill 470 -6 438 470 -6 439 minecraft:orange_concrete
fill 470 -6 440 470 -1 441 minecraft:blackstone
fill 470 -6 446 470 -5 447 minecraft:orange_concrete
fill 470 -6 448 470 -1 449 minecraft:blackstone
setblock 470 -6 450 minecraft:orange_concrete
fill 470 -6 458 471 -5 458 minecraft:orange_concrete
fill 471 -6 417 473 -6 417 minecraft:red_nether_bricks
fill 471 -6 419 471 -6 421 minecraft:red_nether_bricks
fill 471 -6 423 471 -6 425 minecraft:red_nether_bricks
fill 471 -6 427 471 -6 429 minecraft:red_nether_bricks
fill 471 -6 431 471 -6 433 minecraft:red_nether_bricks
fill 471 -6 435 471 -6 437 minecraft:red_nether_bricks
fill 471 -6 439 471 -6 441 minecraft:red_nether_bricks
fill 471 -6 443 471 -6 445 minecraft:red_nether_bricks
fill 471 -6 447 471 -6 449 minecraft:red_nether_bricks
fill 471 -6 451 471 -6 453 minecraft:red_nether_bricks
fill 471 -6 455 471 -6 457 minecraft:red_nether_bricks
setblock 472 -6 416 minecraft:orange_concrete
fill 472 -6 458 473 -1 458 minecraft:blackstone
fill 473 -6 416 474 -1 416 minecraft:blackstone
fill 473 -6 457 475 -6 457 minecraft:red_nether_bricks
fill 475 -6 416 476 -5 416 minecraft:orange_concrete
fill 475 -6 417 477 -6 417 minecraft:red_nether_bricks
fill 477 -6 457 479 -6 457 minecraft:red_nether_bricks
fill 479 -6 417 481 -6 417 minecraft:red_nether_bricks
fill 479 -6 458 479 -5 458 minecraft:orange_concrete
fill 480 -6 458 481 -5 458 minecraft:blackstone
fill 481 -6 416 482 -1 416 minecraft:blackstone
fill 481 -6 457 483 -6 457 minecraft:red_nether_bricks
fill 482 -6 458 483 -6 458 minecraft:orange_concrete
fill 483 -6 416 484 -6 416 minecraft:orange_concrete
fill 483 -6 417 485 -6 417 minecraft:red_nether_bricks
fill 484 -6 458 484 -1 458 minecraft:blackstone
fill 485 -6 416 485 -1 416 minecraft:blackstone
fill 485 -6 457 487 -6 457 minecraft:red_nether_bricks
fill 487 -6 417 489 -6 417 minecraft:red_nether_bricks
fill 489 -6 457 491 -6 457 minecraft:red_nether_bricks
fill 490 -6 458 491 -5 458 minecraft:orange_concrete
fill 491 -6 417 493 -6 417 minecraft:red_nether_bricks
fill 492 -6 458 493 -1 458 minecraft:blackstone
fill 493 -6 416 494 -1 416 minecraft:blackstone
fill 493 -6 457 495 -6 457 minecraft:red_nether_bricks
fill 495 -6 416 496 -5 416 minecraft:orange_concrete
fill 495 -6 417 497 -6 417 minecraft:red_nether_bricks
fill 497 -6 457 499 -6 457 minecraft:red_nether_bricks
fill 499 -6 417 501 -6 417 minecraft:red_nether_bricks
fill 501 -6 457 503 -6 457 minecraft:red_nether_bricks
fill 501 -6 458 501 -1 458 minecraft:blackstone
fill 502 -6 416 502 -1 416 minecraft:blackstone
fill 502 -6 458 503 -6 458 minecraft:orange_concrete
fill 503 -6 417 505 -6 417 minecraft:red_nether_bricks
setblock 504 -6 416 minecraft:orange_concrete
fill 504 -6 458 505 -1 458 minecraft:blackstone
fill 505 -6 416 506 -1 416 minecraft:blackstone
fill 505 -6 457 507 -6 457 minecraft:red_nether_bricks
fill 507 -6 416 507 -5 416 minecraft:orange_concrete
fill 507 -6 417 509 -6 417 minecraft:red_nether_bricks
fill 509 -6 457 511 -6 457 minecraft:red_nether_bricks
fill 510 -6 458 511 -5 458 minecraft:orange_concrete
fill 511 -6 417 511 -6 419 minecraft:red_nether_bricks
fill 511 -6 421 511 -6 423 minecraft:red_nether_bricks
fill 511 -6 425 511 -6 427 minecraft:red_nether_bricks
fill 511 -6 429 511 -6 431 minecraft:red_nether_bricks
fill 511 -6 433 511 -6 435 minecraft:red_nether_bricks
fill 511 -6 437 511 -6 439 minecraft:red_nether_bricks
fill 511 -6 441 511 -6 443 minecraft:red_nether_bricks
fill 511 -6 445 511 -6 447 minecraft:red_nether_bricks
fill 511 -6 449 511 -6 451 minecraft:red_nether_bricks
fill 511 -6 453 511 -6 455 minecraft:red_nether_bricks
fill 512 -6 417 512 -1 418 minecraft:blackstone
fill 512 -6 419 512 -6 420 minecraft:orange_concrete
fill 512 -6 429 512 -1 430 minecraft:blackstone
fill 512 -6 431 512 -5 432 minecraft:orange_concrete
fill 512 -6 438 512 -1 438 minecraft:blackstone
fill 512 -6 439 512 -6 440 minecraft:orange_concrete
fill 512 -6 441 512 -1 441 minecraft:blackstone
fill 512 -6 443 512 -5 443 minecraft:orange_concrete
fill 512 -6 449 512 -1 450 minecraft:blackstone
fill 512 -6 451 512 -5 452 minecraft:orange_concrete
fill 512 -6 458 512 -1 458 minecraft:blackstone
fill 470 -5 418 470 -2 418 minecraft:blackstone
fill 470 -5 434 470 -5 435 minecraft:orange_concrete
setblock 470 -5 438 minecraft:orange_concrete
fill 470 -5 439 470 -2 439 minecraft:blackstone
fill 470 -5 450 470 -2 450 minecraft:blackstone
setblock 470 -5 455 minecraft:orange_concrete
fill 472 -5 416 472 -2 416 minecraft:blackstone
setblock 478 -5 458 minecraft:orange_concrete
fill 482 -5 458 483 -3 458 minecraft:blackstone
fill 483 -5 416 483 -2 416 minecraft:blackstone
setblock 484 -5 416 minecraft:orange_concrete
fill 487 -5 416 488 -5 416 minecraft:orange_concrete
fill 498 -5 458 499 -5 458 minecraft:orange_concrete
setblock 502 -5 458 minecraft:orange_concrete
fill 503 -5 458 503 -2 458 minecraft:blackstone
fill 504 -5 416 504 -2 416 minecraft:blackstone
setblock 508 -5 416 minecraft:orange_concrete
fill 512 -5 419 512 -2 419 minecraft:blackstone
setblock 512 -5 420 minecraft:orange_concrete
setblock 512 -5 423 minecraft:orange_concrete
fill 512 -5 439 512 -2 440 minecraft:blackstone
setblock 512 -5 444 minecraft:orange_concrete
setblock 512 -5 455 minecraft:orange_concrete
fill 470 -4 424 470 -4 425 minecraft:orange_concrete
fill 470 -4 426 470 1 427 minecraft:blackstone
fill 470 -4 433 470 -3 433 minecraft:orange_concrete
fill 470 -4 434 470 1 435 minecraft:blackstone
setblock 470 -4 436 minecraft:orange_concrete
fill 470 -4 438 470 1 438 minecraft:blackstone
fill 470 -4 444 470 -3 445 minecraft:orange_concrete
fill 470 -4 446 470 1 447 minecraft:blackstone
fill 470 -4 455 470 1 455 minecraft:blackstone
fill 470 -4 456 470 -4 457 minecraft:orange_concrete
fill 470 -4 458 471 -2 458 minecraft:blackstone
fill 475 -4 416 476 1 416 minecraft:blackstone
fill 476 -4 458 477 -3 458 minecraft:orange_concrete
fill 477 -4 416 478 -3 416 minecraft:orange_concrete
fill 478 -4 458 479 1 458 minecraft:blackstone
setblock 480 -4 458 minecraft:orange_concrete
fill 481 -4 458 481 -1 458 minecraft:blackstone
fill 484 -4 416 484 1 416 minecraft:blackstone
setblock 486 -4 416 minecraft:orange_concrete
fill 487 -4 416 488 1 416 minecraft:blackstone
fill 488 -4 458 489 -3 458 minecraft:orange_concrete
fill 489 -4 416 489 -3 416 minecraft:orange_concrete
fill 490 -4 458 491 1 458 minecraft:blackstone
fill 495 -4 416 496 1 416 minecraft:blackstone
fill 497 -4 416 498 -4 416 minecraft:orange_concrete
fill 497 -4 458 497 -3 458 minecraft:orange_concrete
fill 498 -4 458 499 1 458 minecraft:blackstone
setblock 500 -4 458 minecraft:orange_concrete
fill 502 -4 458 502 1 458 minecraft:blackstone
fill 507 -4 416 508 1 416 minecraft:blackstone
fill 508 -4 458 509 -3 458 minecraft:orange_concrete
fill 509 -4 416 510 -3 416 minecraft:orange_concrete
fill 510 -4 458 511 1 458 minecraft:blackstone
fill 512 -4 420 512 1 420 minecraft:blackstone
fill 512 -4 421 512 -4 422 minecraft:orange_concrete
fill 512 -4 423 512 1 423 minecraft:blackstone
fill 512 -4 425 512 -3 425 minecraft:orange_concrete
fill 512 -4 431 512 1 432 minecraft:blackstone
fill 512 -4 433 512 -3 434 minecraft:orange_concrete
setblock 512 -4 442 minecraft:orange_concrete
fill 512 -4 443 512 1 444 minecraft:blackstone
fill 512 -4 445 512 -3 446 minecraft:orange_concrete
fill 512 -4 451 512 1 452 minecraft:blackstone
fill 512 -4 453 512 -4 454 minecraft:orange_concrete
fill 512 -4 455 512 1 455 minecraft:blackstone
setblock 470 -3 421 minecraft:orange_concrete
setblock 470 -3 424 minecraft:orange_concrete
fill 470 -3 425 470 0 425 minecraft:blackstone
setblock 470 -3 432 minecraft:orange_concrete
fill 470 -3 436 470 0 436 minecraft:blackstone
fill 470 -3 452 470 -3 453 minecraft:orange_concrete
setblock 470 -3 456 minecraft:orange_concrete
fill 470 -3 457 470 0 457 minecraft:blackstone
fill 480 -3 458 480 -1 458 minecraft:blackstone
setblock 485 -3 458 minecraft:orange_concrete
fill 486 -3 416 486 0 416 minecraft:blackstone
setblock 490 -3 416 minecraft:orange_concrete
setblock 496 -3 458 minecraft:orange_concrete
fill 497 -3 416 497 0 416 minecraft:blackstone
setblock 498 -3 416 minecraft:orange_concrete
fill 500 -3 458 500 0 458 minecraft:blackstone
setblock 501 -3 416 minecraft:orange_concrete
fill 512 -3 421 512 0 422 minecraft:blackstone
setblock 512 -3 426 minecraft:orange_concrete
setblock 512 -3 437 minecraft:orange_concrete
fill 512 -3 442 512 0 442 minecraft:blackstone
fill 512 -3 453 512 0 453 minecraft:blackstone
setblock 512 -3 454 minecraft:orange_concrete
setblock 512 -3 457 minecraft:orange_concrete
fill 470 -2 419 470 -1 419 minecraft:orange_concrete
fill 470 -2 421 470 3 421 minecraft:blackstone
fill 470 -2 422 470 -2 423 minecraft:orange_concrete
fill 470 -2 424 470 3 424 minecraft:blackstone
fill 470 -2 430 470 -1 431 minecraft:orange_concrete
fill 470 -2 432 470 3 433 minecraft:blackstone
fill 470 -2 442 470 -2 443 minecraft:orange_concrete
fill 470 -2 444 470 3 445 minecraft:blackstone
fill 470 -2 451 470 -1 451 minecraft:orange_concrete
fill 470 -2 452 470 3 453 minecraft:blackstone
setblock 470 -2 454 minecraft:orange_concrete
fill 470 -2 456 470 0 456 minecraft:blackstone
fill 471 -2 416 471 -1 416 minecraft:orange_concrete
fill 474 -2 458 475 -1 458 minecraft:orange_concrete
fill 476 -2 458 477 3 458 minecraft:blackstone
fill 477 -2 416 478 3 416 minecraft:blackstone
fill 479 -2 416 480 -2 416 minecraft:orange_concrete
setblock 482 -2 458 minecraft:blackstone
fill 483 -2 458 483 -1 458 minecraft:orange_concrete
fill 485 -2 458 485 3 458 minecraft:blackstone
fill 486 -2 458 487 -2 458 minecraft:orange_concrete
fill 488 -2 458 489 0 458 minecraft:blackstone
fill 489 -2 416 490 3 416 minecraft:blackstone
fill 491 -2 416 492 -1 416 minecraft:orange_concrete
fill 494 -2 458 495 -1 458 minecraft:orange_concrete
fill 496 -2 458 497 3 458 minecraft:blackstone
fill 498 -2 416 498 3 416 minecraft:blackstone
fill 499 -2 416 500 -2 416 minecraft:orange_concrete
fill 501 -2 416 501 3 416 minecraft:blackstone
fill 503 -2 416 503 -1 416 minecraft:orange_concrete
fill 506 -2 458 507 -2 458 minecraft:orange_concrete
fill 508 -2 458 509 3 458 minecraft:blackstone
fill 509 -2 416 510 3 416 minecraft:blackstone
fill 511 -2 416 512 -1 416 minecraft:orange_concrete
setblock 512 -2 424 minecraft:orange_concrete
fill 512 -2 425 512 3 426 minecraft:blackstone
fill 512 -2 427 512 -1 428 minecraft:orange_concrete
fill 512 -2 433 512 3 434 minecraft:blackstone
fill 512 -2 435 512 -2 436 minecraft:orange_concrete
fill 512 -2 437 512 3 437 minecraft:blackstone
fill 512 -2 445 512 3 446 minecraft:blackstone
fill 512 -2 447 512 -1 448 minecraft:orange_concrete
fill 512 -2 454 512 3 454 minecraft:blackstone
setblock 512 -2 456 minecraft:orange_concrete
fill 512 -2 457 512 3 457 minecraft:blackstone
setblock 470 -1 418 minecraft:orange_concrete
fill 470 -1 422 470 2 423 minecraft:blackstone
setblock 470 -1 439 minecraft:orange_concrete
setblock 470 -1 442 minecraft:orange_concrete
fill 470 -1 443 470 2 443 minecraft:blackstone
setblock 470 -1 450 minecraft:orange_concrete
fill 470 -1 454 470 2 454 minecraft:blackstone
fill 470 -1 458 470 1 458 minecraft:blackstone
setblock 471 -1 458 minecraft:orange_concrete
setblock 472 -1 416 minecraft:orange_concrete
fill 479 -1 416 479 2 416 minecraft:blackstone
setblock 480 -1 416 minecraft:orange_concrete
setblock 482 -1 458 minecraft:orange_concrete
setblock 483 -1 416 minecraft:orange_concrete
setblock 486 -1 458 minecraft:orange_concrete
fill 487 -1 458 487 2 458 minecraft:blackstone
fill 499 -1 416 500 2 416 minecraft:blackstone
setblock 503 -1 458 minecraft:orange_concrete
setblock 504 -1 416 minecraft:orange_concrete
setblock 506 -1 458 minecraft:orange_concrete
fill 507 -1 458 507 2 458 minecraft:blackstone
setblock 512 -1 419 minecraft:orange_concrete
fill 512 -1 424 512 2 424 minecraft:blackstone
fill 512 -1 435 512 2 435 minecraft:blackstone
setblock 512 -1 436 minecraft:orange_concrete
fill 512 -1 439 512 -1 440 minecraft:orange_concrete
fill 512 -1 456 512 2 456 minecraft:blackstone
fill 470 0 416 470 1 417 minecraft:orange_concrete
fill 470 0 418 470 5 419 minecraft:blackstone
setblock 470 0 420 minecraft:orange_concrete
fill 470 0 428 470 1 429 minecraft:orange_concrete
fill 470 0 430 470 5 431 minecraft:blackstone
fill 470 0 437 470 1 437 minecraft:orange_concrete
fill 470 0 439 470 5 439 minecraft:blackstone
fill 470 0 440 470 0 441 minecraft:orange_concrete
fill 470 0 442 470 5 442 minecraft:blackstone
fill 470 0 448 470 1 449 minecraft:orange_concrete
fill 470 0 450 470 5 451 minecraft:blackstone
fill 471 0 416 472 5 416 minecraft:blackstone
fill 471 0 417 473 0 417 minecraft:red_nether_bricks
fill 471 0 419 471 0 421 minecraft:red_nether_bricks
fill 471 0 423 471 0 425 minecraft:red_nether_bricks
fill 471 0 427 471 0 429 minecraft:red_nether_bricks
fill 471 0 431 471 0 433 minecraft:red_nether_bricks
fill 471 0 435 471 0 437 minecraft:red_nether_bricks
fill 471 0 439 471 0 441 minecraft:red_nether_bricks
fill 471 0 443 471 0 445 minecraft:red_nether_bricks
fill 471 0 447 471 0 449 minecraft:red_nether_bricks
fill 471 0 451 471 0 453 minecraft:red_nether_bricks
fill 471 0 455 471 0 457 minecraft:red_nether_bricks
fill 471 0 458 471 1 458 minecraft:blackstone
fill 472 0 458 473 0 458 minecraft:orange_concrete
fill 473 0 416 474 1 416 minecraft:orange_concrete
setblock 473 0 419 minecraft:light[level=14]
setblock 473 0 427 minecraft:light[level=14]
setblock 473 0 435 minecraft:light[level=14]
setblock 473 0 443 minecraft:light[level=14]
setblock 473 0 451 minecraft:light[level=14]
fill 473 0 457 475 0 457 minecraft:red_nether_bricks
fill 474 0 458 475 5 458 minecraft:blackstone
fill 475 0 417 477 0 417 minecraft:red_nether_bricks
fill 477 0 457 479 0 457 minecraft:red_nether_bricks
fill 479 0 417 481 0 417 minecraft:red_nether_bricks
fill 480 0 416 480 5 416 minecraft:blackstone
fill 480 0 458 481 1 458 minecraft:orange_concrete
fill 481 0 416 482 0 416 minecraft:orange_concrete
setblock 481 0 419 minecraft:light[level=14]
setblock 481 0 427 minecraft:light[level=14]
setblock 481 0 435 minecraft:light[level=14]
setblock 481 0 443 minecraft:light[level=14]
setblock 481 0 451 minecraft:light[level=14]
fill 481 0 457 483 0 457 minecraft:red_nether_bricks
fill 482 0 458 483 5 458 minecraft:blackstone
fill 483 0 416 483 5 416 minecraft:blackstone
fill 483 0 417 485 0 417 minecraft:red_nether_bricks
setblock 484 0 458 minecraft:orange_concrete
fill 485 0 416 485 1 416 minecraft:orange_concrete
fill 485 0 457 487 0 457 minecraft:red_nether_bricks
fill 486 0 458 486 2 458 minecraft:blackstone
fill 487 0 417 489 0 417 minecraft:red_nether_bricks
setblock 489 0 419 minecraft:light[level=14]
setblock 489 0 427 minecraft:light[level=14]
setblock 489 0 435 minecraft:light[level=14]
setblock 489 0 443 minecraft:light[level=14]
fill 489 0 457 491 0 457 minecraft:red_nether_bricks
fill 491 0 416 492 5 416 minecraft:blackstone
fill 491 0 417 493 0 417 minecraft:red_nether_bricks
fill 492 0 458 493 1 458 minecraft:orange_concrete
fill 493 0 416 494 1 416 minecraft:orange_concrete
fill 493 0 457 495 0 457 minecraft:red_nether_bricks
fill 494 0 458 495 5 458 minecraft:blackstone
fill 495 0 417 497 0 417 minecraft:red_nether_bricks
setblock 497 0 419 minecraft:light[level=14]
setblock 497 0 427 minecraft:light[level=14]
setblock 497 0 435 minecraft:light[level=14]
setblock 497 0 443 minecraft:light[level=14]
setblock 497 0 451 minecraft:light[level=14]
fill 497 0 457 499 0 457 minecraft:red_nether_bricks
fill 499 0 417 501 0 417 minecraft:red_nether_bricks
fill 501 0 457 503 0 457 minecraft:red_nether_bricks
fill 501 0 458 501 1 458 minecraft:orange_concrete
setblock 502 0 416 minecraft:orange_concrete
fill 503 0 416 504 5 416 minecraft:blackstone
fill 503 0 417 505 0 417 minecraft:red_nether_bricks
fill 503 0 458 503 5 458 minecraft:blackstone
fill 504 0 458 505 0 458 minecraft:orange_concrete
fill 505 0 416 506 1 416 minecraft:orange_concrete
setblock 505 0 419 minecraft:light[level=14]
setblock 505 0 427 minecraft:light[level=14]
setblock 505 0 435 minecraft:light[level=14]
setblock 505 0 443 minecraft:light[level=14]
setblock 505 0 451 minecraft:light[level=14]
fill 505 0 457 507 0 457 minecraft:red_nether_bricks
fill 506 0 458 506 5 458 minecraft:blackstone
fill 507 0 417 509 0 417 minecraft:red_nether_bricks
fill 509 0 457 511 0 457 minecraft:red_nether_bricks
fill 511 0 416 512 5 416 minecraft:blackstone
fill 511 0 417 511 0 419 minecraft:red_nether_bricks
fill 511 0 421 511 0 423 minecraft:red_nether_bricks
fill 511 0 425 511 0 427 minecraft:red_nether_bricks
fill 511 0 429 511 0 431 minecraft:red_nether_bricks
fill 511 0 433 511 0 435 minecraft:red_nether_bricks
fill 511 0 437 511 0 439 minecraft:red_nether_bricks
fill 511 0 441 511 0 443 minecraft:red_nether_bricks
fill 511 0 445 511 0 447 minecraft:red_nether_bricks
fill 511 0 449 511 0 451 minecraft:red_nether_bricks
fill 511 0 453 511 0 455 minecraft:red_nether_bricks
fill 512 0 417 512 0 418 minecraft:orange_concrete
fill 512 0 419 512 5 419 minecraft:blackstone
fill 512 0 427 512 5 428 minecraft:blackstone
fill 512 0 429 512 1 430 minecraft:orange_concrete
fill 512 0 436 512 5 436 minecraft:blackstone
setblock 512 0 438 minecraft:orange_concrete
fill 512 0 439 512 5 440 minecraft:blackstone
fill 512 0 441 512 1 441 minecraft:orange_concrete
fill 512 0 447 512 5 448 minecraft:blackstone
fill 512 0 449 512 0 450 minecraft:orange_concrete
fill 512 0 458 512 1 458 minecraft:orange_concrete
fill 470 1 420 470 4 420 minecraft:blackstone
setblock 470 1 425 minecraft:orange_concrete
setblock 470 1 436 minecraft:orange_concrete
fill 470 1 440 470 4 441 minecraft:blackstone
fill 470 1 456 470 1 457 minecraft:orange_concrete
setblock 472 1 458 minecraft:orange_concrete
fill 473 1 458 473 4 458 minecraft:blackstone
fill 481 1 416 482 4 416 minecraft:blackstone
fill 484 1 458 484 4 458 minecraft:blackstone
setblock 486 1 416 minecraft:orange_concrete
fill 488 1 458 488 3 458 minecraft:blackstone
setblock 489 1 458 minecraft:orange_concrete
setblock 497 1 416 minecraft:orange_concrete
setblock 500 1 458 minecraft:orange_concrete
fill 502 1 416 502 4 416 minecraft:blackstone
fill 504 1 458 505 4 458 minecraft:blackstone
fill 512 1 417 512 4 417 minecraft:blackstone
setblock 512 1 418 minecraft:orange_concrete
fill 512 1 421 512 1 422 minecraft:orange_concrete
fill 512 1 438 512 4 438 minecraft:blackstone
setblock 512 1 442 minecraft:orange_concrete
fill 512 1 449 512 4 449 minecraft:blackstone
setblock 512 1 450 minecraft:orange_concrete
setblock 512 1 453 minecraft:orange_concrete
fill 470 2 416 470 7 417 minecraft:blackstone
fill 470 2 425 470 7 425 minecraft:blackstone
fill 470 2 426 470 2 427 minecraft:orange_concrete
fill 470 2 428 470 7 429 minecraft:blackstone
fill 470 2 434 470 3 435 minecraft:orange_concrete
fill 470 2 436 470 7 437 minecraft:blackstone
setblock 470 2 438 minecraft:orange_concrete
fill 470 2 446 470 3 447 minecraft:orange_concrete
fill 470 2 448 470 7 449 minecraft:blackstone
fill 470 2 455 470 3 455 minecraft:orange_concrete
fill 470 2 456 470 3 457 minecraft:blackstone
fill 470 2 458 471 2 458 minecraft:orange_concrete
fill 472 2 458 472 7 458 minecraft:blackstone
fill 473 2 416 474 7 416 minecraft:blackstone
fill 475 2 416 476 3 416 minecraft:orange_concrete
fill 478 2 458 479 3 458 minecraft:orange_concrete
fill 480 2 458 481 7 458 minecraft:blackstone
setblock 484 2 416 minecraft:orange_concrete
fill 485 2 416 486 7 416 minecraft:blackstone
fill 487 2 416 488 3 416 minecraft:orange_concrete
fill 489 2 458 489 7 458 minecraft:blackstone
fill 490 2 458 491 2 458 minecraft:orange_concrete
fill 492 2 458 493 7 458 minecraft:blackstone
fill 493 2 416 494 7 416 minecraft:blackstone
fill 495 2 416 496 2 416 minecraft:orange_concrete
fill 497 2 416 497 7 416 minecraft:blackstone
fill 498 2 458 499 3 458 minecraft:orange_concrete
fill 500 2 458 501 7 458 minecraft:blackstone
setblock 502 2 458 minecraft:orange_concrete
fill 505 2 416 506 7 416 minecraft:blackstone
fill 507 2 416 508 3 416 minecraft:orange_concrete
fill 510 2 458 511 3 458 minecraft:orange_concrete
fill 512 2 418 512 7 418 minecraft:blackstone
setblock 512 2 420 minecraft:orange_concrete
fill 512 2 421 512 7 422 minecraft:blackstone
fill 512 2 423 512 3 423 minecraft:orange_concrete
fill 512 2 429 512 7 430 minecraft:blackstone
fill 512 2 431 512 2 432 minecraft:orange_concrete
fill 512 2 441 512 7 442 minecraft:blackstone
fill 512 2 443 512 3 444 minecraft:orange_concrete
fill 512 2 450 512 7 450 minecraft:blackstone
fill 512 2 451 512 2 452 minecraft:orange_concrete
fill 512 2 453 512 7 453 minecraft:blackstone
fill 512 2 455 512 3 455 minecraft:orange_concrete
fill 512 2 458 512 7 458 minecraft:blackstone
fill 470 3 422 470 3 423 minecraft:orange_concrete
setblock 470 3 426 minecraft:orange_concrete
fill 470 3 427 470 6 427 minecraft:blackstone
fill 470 3 438 470 6 438 minecraft:blackstone
setblock 470 3 443 minecraft:orange_concrete
setblock 470 3 454 minecraft:orange_concrete
fill 470 3 458 471 5 458 minecraft:blackstone
setblock 479 3 416 minecraft:orange_concrete
fill 484 3 416 484 6 416 minecraft:blackstone
fill 486 3 458 487 3 458 minecraft:orange_concrete
setblock 490 3 458 minecraft:orange_concrete
fill 491 3 458 491 6 458 minecraft:blackstone
fill 495 3 416 495 6 416 minecraft:blackstone
setblock 496 3 416 minecraft:orange_concrete
fill 499 3 416 500 3 416 minecraft:orange_concrete
fill 502 3 458 502 6 458 minecraft:blackstone
setblock 507 3 458 minecraft:orange_concrete
fill 512 3 420 512 6 420 minecraft:blackstone
setblock 512 3 424 minecraft:orange_concrete
fill 512 3 431 512 6 431 minecraft:blackstone
setblock 512 3 432 minecraft:orange_concrete
setblock 512 3 435 minecraft:orange_concrete
fill 512 3 451 512 6 452 minecraft:blackstone
setblock 512 3 456 minecraft:orange_concrete
fill 470 4 421 470 5 421 minecraft:orange_concrete
fill 470 4 422 470 9 423 minecraft:blackstone
setblock 470 4 424 minecraft:orange_concrete
fill 470 4 426 470 9 426 minecraft:blackstone
fill 470 4 432 470 5 433 minecraft:orange_concrete
fill 470 4 434 470 9 435 minecraft:blackstone
fill 470 4 443 470 9 443 minecraft:blackstone
fill 470 4 444 470 4 445 minecraft:orange_concrete
fill 470 4 446 470 6 447 minecraft:blackstone
fill 470 4 452 470 5 453 minecraft:orange_concrete
fill 470 4 454 470 9 455 minecraft:blackstone
setblock 470 4 456 minecraft:orange_concrete
fill 470 4 457 470 7 457 minecraft:blackstone
fill 475 4 416 476 9 416 minecraft:blackstone
fill 476 4 458 477 5 458 minecraft:orange_concrete
fill 477 4 416 478 4 416 minecraft:orange_concrete
fill 478 4 458 479 9 458 minecraft:blackstone
fill 479 4 416 479 9 416 minecraft:blackstone
fill 485 4 458 485 5 458 minecraft:orange_concrete
fill 486 4 458 487 9 458 minecraft:blackstone
fill 487 4 416 488 9 416 minecraft:blackstone
setblock 488 4 458 minecraft:orange_concrete
fill 489 4 416 490 5 416 minecraft:orange_concrete
fill 490 4 458 490 9 458 minecraft:blackstone
fill 496 4 416 496 9 416 minecraft:blackstone
fill 496 4 458 497 5 458 minecraft:orange_concrete
setblock 498 4 416 minecraft:orange_concrete
fill 498 4 458 499 9 458 minecraft:blackstone
fill 499 4 416 500 9 416 minecraft:blackstone
fill 501 4 416 501 5 416 minecraft:orange_concrete
fill 507 4 416 508 9 416 minecraft:blackstone
fill 507 4 458 507 9 458 minecraft:blackstone
fill 508 4 458 509 4 458 minecraft:orange_concrete
fill 509 4 416 510 4 416 minecraft:orange_concrete
fill 510 4 458 511 9 458 minecraft:blackstone
fill 512 4 423 512 9 424 minecraft:blackstone
fill 512 4 425 512 5 426 minecraft:orange_concrete
fill 512 4 432 512 9 432 minecraft:blackstone
fill 512 4 433 512 4 434 minecraft:orange_concrete
fill 512 4 435 512 9 435 minecraft:blackstone
fill 512 4 437 512 5 437 minecraft:orange_concrete
fill 512 4 443 512 9 444 minecraft:blackstone
fill 512 4 445 512 5 446 minecraft:orange_concrete
setblock 512 4 454 minecraft:orange_concrete
fill 512 4 455 512 9 456 minecraft:blackstone
fill 512 4 457 512 5 457 minecraft:orange_concrete
setblock 470 5 420 minecraft:orange_concrete
fill 470 5 424 470 8 424 minecraft:blackstone
fill 470 5 440 470 5 441 minecraft:orange_concrete
setblock 470 5 444 minecraft:orange_concrete
fill 470 5 445 470 8 445 minecraft:blackstone
fill 470 5 456 470 7 456 minecraft:blackstone
setblock 473 5 458 minecraft:orange_concrete
fill 477 5 416 477 8 416 minecraft:blackstone
setblock 478 5 416 minecraft:orange_concrete
fill 481 5 416 482 5 416 minecraft:orange_concrete
setblock 484 5 458 minecraft:orange_concrete
fill 488 5 458 488 8 458 minecraft:blackstone
fill 498 5 416 498 8 416 minecraft:blackstone
setblock 502 5 416 minecraft:orange_concrete
fill 504 5 458 505 5 458 minecraft:orange_concrete
setblock 508 5 458 minecraft:orange_concrete
fill 509 5 416 509 8 416 minecraft:blackstone
fill 509 5 458 509 8 458 minecraft:blackstone
setblock 510 5 416 minecraft:orange_concrete
setblock 512 5 417 minecraft:orange_concrete
fill 512 5 433 512 8 434 minecraft:blackstone
setblock 512 5 438 minecraft:orange_concrete
setblock 512 5 449 minecraft:orange_concrete
fill 512 5 454 512 8 454 minecraft:blackstone
fill 470 6 418 470 7 419 minecraft:orange_concrete
fill 470 6 420 470 11 421 minecraft:blackstone
fill 470 6 430 470 6 431 minecraft:orange_concrete
fill 470 6 432 470 11 433 minecraft:blackstone
fill 470 6 439 470 7 439 minecraft:orange_concrete
fill 470 6 440 470 11 441 minecraft:blackstone
setblock 470 6 442 minecraft:orange_concrete
fill 470 6 444 470 8 444 minecraft:blackstone
fill 470 6 450 470 7 451 minecraft:orange_concrete
fill 470 6 452 470 11 453 minecraft:blackstone
setblock 470 6 458 minecraft:blackstone
fill 471 6 416 472 7 416 minecraft:orange_concrete
fill 471 6 417 473 6 417 minecraft:red_nether_bricks
fill 471 6 419 471 6 421 minecraft:red_nether_bricks
fill 471 6 423 471 6 425 minecraft:red_nether_bricks
fill 471 6 427 471 6 429 minecraft:red_nether_bricks
fill 471 6 431 471 6 433 minecraft:red_nether_bricks
fill 471 6 435 471 6 437 minecraft:red_nether_bricks
fill 471 6 439 471 6 441 minecraft:red_nether_bricks
fill 471 6 443 471 6 445 minecraft:red_nether_bricks
fill 471 6 447 471 6 449 minecraft:red_nether_bricks
fill 471 6 451 471 6 453 minecraft:red_nether_bricks
fill 471 6 455 471 6 457 minecraft:red_nether_bricks
fill 471 6 458 471 7 458 minecraft:orange_concrete
fill 473 6 457 475 6 457 minecraft:red_nether_bricks
fill 473 6 458 473 11 458 minecraft:blackstone
fill 474 6 458 475 6 458 minecraft:orange_concrete
fill 475 6 417 477 6 417 minecraft:red_nether_bricks
fill 476 6 458 477 8 458 minecraft:blackstone
fill 477 6 457 479 6 457 minecraft:red_nether_bricks
fill 478 6 416 478 11 416 minecraft:blackstone
fill 479 6 417 481 6 417 minecraft:red_nether_bricks
setblock 480 6 416 minecraft:orange_concrete
fill 481 6 416 482 11 416 minecraft:blackstone
fill 481 6 457 483 6 457 minecraft:red_nether_bricks
fill 482 6 458 483 7 458 minecraft:orange_concrete
fill 483 6 416 483 7 416 minecraft:orange_concrete
fill 483 6 417 485 6 417 minecraft:red_nether_bricks
fill 484 6 458 485 11 458 minecraft:blackstone
fill 485 6 457 487 6 457 minecraft:red_nether_bricks
fill 487 6 417 489 6 417 minecraft:red_nether_bricks
fill 489 6 416 490 11 416 minecraft:blackstone
fill 489 6 457 491 6 457 minecraft:red_nether_bricks
fill 491 6 416 492 6 416 minecraft:orange_concrete
fill 491 6 417 493 6 417 minecraft:red_nether_bricks
fill 493 6 457 495 6 457 minecraft:red_nether_bricks
fill 494 6 458 495 6 458 minecraft:orange_concrete
fill 495 6 417 497 6 417 minecraft:red_nether_bricks
fill 496 6 458 497 11 458 minecraft:blackstone
fill 497 6 457 499 6 457 minecraft:red_nether_bricks
fill 499 6 417 501 6 417 minecraft:red_nether_bricks
fill 501 6 416 502 11 416 minecraft:blackstone
fill 501 6 457 503 6 457 minecraft:red_nether_bricks
fill 503 6 416 504 7 416 minecraft:orange_concrete
fill 503 6 417 505 6 417 minecraft:red_nether_bricks
fill 503 6 458 503 7 458 minecraft:orange_concrete
fill 504 6 458 505 11 458 minecraft:blackstone
fill 505 6 457 507 6 457 minecraft:red_nether_bricks
setblock 506 6 458 minecraft:orange_concrete
fill 507 6 417 509 6 417 minecraft:red_nether_bricks
fill 508 6 458 508 11 458 minecraft:blackstone
fill 509 6 457 511 6 457 minecraft:red_nether_bricks
fill 510 6 416 510 11 416 minecraft:blackstone
fill 511 6 416 512 6 416 minecraft:orange_concrete
fill 511 6 417 511 6 419 minecraft:red_nether_bricks
fill 511 6 421 511 6 423 minecraft:red_nether_bricks
fill 511 6 425 511 6 427 minecraft:red_nether_bricks
fill 511 6 429 511 6 431 minecraft:red_nether_bricks
fill 511 6 433 511 6 435 minecraft:red_nether_bricks
fill 511 6 437 511 6 439 minecraft:red_nether_bricks
fill 511 6 441 511 6 443 minecraft:red_nether_bricks
fill 511 6 445 511 6 447 minecraft:red_nether_bricks
fill 511 6 449 511 6 451 minecraft:red_nether_bricks
fill 511 6 453 511 6 455 minecraft:red_nether_bricks
fill 512 6 417 512 11 417 minecraft:blackstone
fill 512 6 419 512 7 419 minecraft:orange_concrete
fill 512 6 425 512 11 426 minecraft:blackstone
fill 512 6 427 512 7 428 minecraft:orange_concrete
setblock 512 6 436 minecraft:orange_concrete
fill 512 6 437 512 11 438 minecraft:blackstone
fill 512 6 439 512 7 440 minecraft:orange_concrete
fill 512 6 445 512 11 446 minecraft:blackstone
fill 512 6 447 512 6 448 minecraft:orange_concrete
fill 512 6 449 512 11 449 minecraft:blackstone
fill 512 6 457 512 11 457 minecraft:blackstone
setblock 470 7 427 minecraft:orange_concrete
setblock 470 7 430 minecraft:orange_concrete
fill 470 7 431 470 10 431 minecraft:blackstone
setblock 470 7 438 minecraft:orange_concrete
fill 470 7 442 470 10 442 minecraft:blackstone
fill 470 7 446 470 9 446 minecraft:blackstone
setblock 470 7 447 minecraft:orange_concrete
setblock 470 7 458 minecraft:orange_concrete
setblock 474 7 458 minecraft:orange_concrete
fill 475 7 458 475 10 458 minecraft:blackstone
fill 480 7 416 480 10 416 minecraft:blackstone
setblock 484 7 416 minecraft:orange_concrete
fill 491 7 416 491 10 416 minecraft:blackstone
setblock 491 7 458 minecraft:orange_concrete
setblock 492 7 416 minecraft:orange_concrete
setblock 494 7 458 minecraft:orange_concrete
setblock 495 7 416 minecraft:orange_concrete
fill 495 7 458 495 10 458 minecraft:blackstone
setblock 502 7 458 minecraft:orange_concrete
fill 506 7 458 506 10 458 minecraft:blackstone
fill 511 7 416 512 10 416 minecraft:blackstone
setblock 512 7 420 minecraft:orange_concrete
setblock 512 7 431 minecraft:orange_concrete
fill 512 7 436 512 10 436 minecraft:blackstone
fill 512 7 447 512 10 447 minecraft:blackstone
setblock 512 7 448 minecraft:orange_concrete
fill 512 7 451 512 7 452 minecraft:orange_concrete
fill 470 8 416 470 9 417 minecraft:orange_concrete
fill 470 8 418 470 13 419 minecraft:blackstone
fill 470 8 425 470 9 425 minecraft:orange_concrete
fill 470 8 427 470 13 427 minecraft:blackstone
fill 470 8 428 470 8 429 minecraft:orange_concrete
fill 470 8 430 470 13 430 minecraft:blackstone
fill 470 8 436 470 9 437 minecraft:orange_concrete
fill 470 8 438 470 13 439 minecraft:blackstone
fill 470 8 447 470 9 447 minecraft:blackstone
fill 470 8 448 470 8 449 minecraft:orange_concrete
fill 470 8 450 470 13 451 minecraft:blackstone
fill 470 8 456 470 9 457 minecraft:orange_concrete
fill 470 8 458 471 13 458 minecraft:blackstone
fill 471 8 416 472 13 416 minecraft:blackstone
setblock 472 8 458 minecraft:orange_concrete
fill 473 8 416 474 8 416 minecraft:orange_concrete
setblock 473 8 419 minecraft:light[level=14]
setblock 473 8 427 minecraft:light[level=14]
setblock 473 8 435 minecraft:light[level=14]
setblock 473 8 443 minecraft:light[level=14]
setblock 473 8 451 minecraft:light[level=14]
fill 474 8 458 474 10 458 minecraft:blackstone
fill 480 8 458 481 9 458 minecraft:orange_concrete
setblock 481 8 419 minecraft:light[level=14]
setblock 481 8 427 minecraft:light[level=14]
setblock 481 8 435 minecraft:light[level=14]
setblock 481 8 443 minecraft:light[level=14]
setblock 481 8 451 minecraft:light[level=14]
fill 482 8 458 483 13 458 minecraft:blackstone
fill 483 8 416 484 13 416 minecraft:blackstone
fill 485 8 416 486 9 416 minecraft:orange_concrete
setblock 489 8 419 minecraft:light[level=14]
setblock 489 8 427 minecraft:light[level=14]
setblock 489 8 435 minecraft:light[level=14]
setblock 489 8 443 minecraft:light[level=14]
fill 489 8 458 489 9 458 minecraft:orange_concrete
fill 491 8 458 491 13 458 minecraft:blackstone
fill 492 8 416 492 13 416 minecraft:blackstone
fill 492 8 458 493 8 458 minecraft:orange_concrete
fill 493 8 416 494 8 416 minecraft:orange_concrete
fill 494 8 458 494 13 458 minecraft:blackstone
fill 495 8 416 495 13 416 minecraft:blackstone
fill 497 8 416 497 9 416 minecraft:orange_concrete
setblock 497 8 419 minecraft:light[level=14]
setblock 497 8 427 minecraft:light[level=14]
setblock 497 8 435 minecraft:light[level=14]
setblock 497 8 443 minecraft:light[level=14]
setblock 497 8 451 minecraft:light[level=14]
fill 500 8 458 501 9 458 minecraft:orange_concrete
fill 502 8 458 503 13 458 minecraft:blackstone
fill 503 8 416 504 13 416 minecraft:blackstone
fill 505 8 416 506 9 416 minecraft:orange_concrete
setblock 505 8 419 minecraft:light[level=14]
setblock 505 8 427 minecraft:light[level=14]
setblock 505 8 435 minecraft:light[level=14]
setblock 505 8 443 minecraft:light[level=14]
setblock 505 8 451 minecraft:light[level=14]
setblock 512 8 418 minecraft:orange_concrete
fill 512 8 419 512 13 420 minecraft:blackstone
fill 512 8 421 512 9 422 minecraft:orange_concrete
fill 512 8 427 512 13 428 minecraft:blackstone
fill 512 8 429 512 8 430 minecraft:orange_concrete
fill 512 8 431 512 13 431 minecraft:blackstone
fill 512 8 439 512 13 440 minecraft:blackstone
fill 512 8 441 512 9 442 minecraft:orange_concrete
fill 512 8 448 512 13 448 minecraft:blackstone
setblock 512 8 450 minecraft:orange_concrete
fill 512 8 451 512 13 452 minecraft:blackstone
fill 512 8 453 512 9 453 minecraft:orange_concrete
fill 512 8 458 512 9 458 minecraft:orange_concrete
setblock 470 9 424 minecraft:orange_concrete
fill 470 9 428 470 12 429 minecraft:blackstone
fill 470 9 444 470 9 445 minecraft:orange_concrete
setblock 470 9 448 minecraft:orange_concrete
fill 470 9 449 470 12 449 minecraft:blackstone
fill 472 9 458 472 12 458 minecraft:blackstone
fill 473 9 416 473 12 416 minecraft:blackstone
setblock 474 9 416 minecraft:orange_concrete
fill 476 9 458 476 11 458 minecraft:blackstone
setblock 477 9 416 minecraft:orange_concrete
setblock 477 9 458 minecraft:orange_concrete
setblock 488 9 458 minecraft:orange_concrete
fill 492 9 458 493 12 458 minecraft:blackstone
fill 493 9 416 494 12 416 minecraft:blackstone
setblock 498 9 416 minecraft:orange_concrete
setblock 509 9 416 minecraft:orange_concrete
setblock 509 9 458 minecraft:orange_concrete
fill 512 9 418 512 12 418 minecraft:blackstone
fill 512 9 429 512 12 429 minecraft:blackstone
setblock 512 9 430 minecraft:orange_concrete
fill 512 9 433 512 9 434 minecraft:orange_concrete
fill 512 9 450 512 12 450 minecraft:blackstone
setblock 512 9 454 minecraft:orange_concrete
fill 470 10 416 470 15 417 minecraft:blackstone
fill 470 10 422 470 11 423 minecraft:orange_concrete
fill 470 10 424 470 15 425 minecraft:blackstone
setblock 470 10 426 minecraft:orange_concrete
fill 470 10 434 470 11 435 minecraft:orange_concrete
fill 470 10 436 470 15 437 minecraft:blackstone
fill 470 10 443 470 11 443 minecraft:orange_concrete
fill 470 10 444 470 11 445 minecraft:blackstone
fill 470 10 446 470 10 447 minecraft:orange_concrete
fill 470 10 448 470 15 448 minecraft:blackstone
fill 470 10 454 470 11 455 minecraft:orange_concrete
fill 470 10 456 470 15 457 minecraft:blackstone
fill 474 10 416 474 15 416 minecraft:blackstone
fill 475 10 416 476 10 416 minecraft:orange_concrete
fill 477 10 416 477 15 416 minecraft:blackstone
fill 477 10 458 477 15 458 minecraft:blackstone
fill 478 10 458 479 10 458 minecraft:orange_concrete
fill 479 10 416 479 11 416 minecraft:orange_concrete
fill 480 10 458 481 15 458 minecraft:blackstone
fill 485 10 416 486 15 416 minecraft:blackstone
fill 486 10 458 487 11 458 minecraft:orange_concrete
fill 487 10 416 488 11 416 minecraft:orange_concrete
fill 488 10 458 489 15 458 minecraft:blackstone
setblock 490 10 458 minecraft:orange_concrete
setblock 496 10 416 minecraft:orange_concrete
fill 497 10 416 498 15 416 minecraft:blackstone
fill 498 10 458 499 11 458 minecraft:orange_concrete
fill 499 10 416 500 11 416 minecraft:orange_concrete
fill 500 10 458 501 15 458 minecraft:blackstone
fill 505 10 416 506 15 416 minecraft:blackstone
fill 507 10 416 508 10 416 minecraft:orange_concrete
fill 507 10 458 507 11 458 minecraft:orange_concrete
fill 509 10 416 509 15 416 minecraft:blackstone
fill 509 10 458 509 15 458 minecraft:blackstone
fill 510 10 458 511 10 458 minecraft:orange_concrete
fill 512 10 421 512 15 422 minecraft:blackstone
fill 512 10 423 512 11 424 minecraft:orange_concrete
fill 512 10 430 512 15 430 minecraft:blackstone
setblock 512 10 432 minecraft:orange_concrete
fill 512 10 433 512 15 434 minecraft:blackstone
fill 512 10 435 512 11 435 minecraft:orange_concrete
fill 512 10 441 512 15 442 minecraft:blackstone
fill 512 10 443 512 10 444 minecraft:orange_concrete
fill 512 10 453 512 15 454 minecraft:blackstone
fill 512 10 455 512 11 456 minecraft:orange_concrete
fill 512 10 458 512 15 458 minecraft:blackstone
fill 470 11 426 470 14 426 minecraft:blackstone
setblock 470 11 431 minecraft:orange_concrete
setblock 470 11 442 minecraft:orange_concrete
fill 470 11 446 470 13 447 minecraft:blackstone
fill 474 11 458 475 11 458 minecraft:orange_concrete
fill 475 11 416 476 14 416 minecraft:blackstone
setblock 478 11 458 minecraft:orange_concrete
fill 479 11 458 479 14 458 minecraft:blackstone
setblock 480 11 416 minecraft:orange_concrete
fill 490 11 458 490 14 458 minecraft:blackstone
setblock 491 11 416 minecraft:orange_concrete
setblock 495 11 458 minecraft:orange_concrete
fill 496 11 416 496 14 416 minecraft:blackstone
setblock 506 11 458 minecraft:orange_concrete
fill 507 11 416 507 14 416 minecraft:blackstone
setblock 508 11 416 minecraft:orange_concrete
fill 510 11 458 511 14 458 minecraft:blackstone
fill 511 11 416 512 11 416 minecraft:orange_concrete
fill 512 11 432 512 14 432 minecraft:blackstone
setblock 512 11 436 minecraft:orange_concrete
fill 512 11 443 512 14 443 minecraft:blackstone
setblock 512 11 444 minecraft:orange_concrete
setblock 512 11 447 minecraft:orange_concrete
fill 470 12 420 470 13 421 minecraft:orange_concrete
fill 470 12 422 470 17 423 minecraft:blackstone
fill 470 12 431 470 17 431 minecraft:blackstone
fill 470 12 432 470 12 433 minecraft:orange_concrete
fill 470 12 434 470 14 435 minecraft:blackstone
fill 470 12 440 470 13 441 minecraft:orange_concrete
fill 470 12 442 470 17 443 minecraft:blackstone
setblock 470 12 444 minecraft:orange_concrete
fill 470 12 445 470 15 445 minecraft:blackstone
fill 470 12 452 470 13 453 minecraft:orange_concrete
fill 470 12 454 470 17 455 minecraft:blackstone
fill 471 12 417 473 12 417 minecraft:red_nether_bricks
fill 471 12 419 471 12 421 minecraft:red_nether_bricks
fill 471 12 423 471 12 425 minecraft:red_nether_bricks
fill 471 12 427 471 12 429 minecraft:red_nether_bricks
fill 471 12 431 471 12 433 minecraft:red_nether_bricks
fill 471 12 435 471 12 437 minecraft:red_nether_bricks
fill 471 12 439 471 12 441 minecraft:red_nether_bricks
fill 471 12 443 471 12 445 minecraft:red_nether_bricks
fill 471 12 447 471 12 449 minecraft:red_nether_bricks
fill 471 12 451 471 12 453 minecraft:red_nether_bricks
fill 471 12 455 471 12 457 minecraft:red_nether_bricks
fill 473 12 457 475 12 457 minecraft:red_nether_bricks
fill 473 12 458 473 13 458 minecraft:orange_concrete
fill 474 12 458 475 17 458 minecraft:blackstone
fill 475 12 417 477 12 417 minecraft:red_nether_bricks
setblock 476 12 458 minecraft:orange_concrete
fill 477 12 457 479 12 457 minecraft:red_nether_bricks
setblock 478 12 416 minecraft:orange_concrete
fill 478 12 458 478 17 458 minecraft:blackstone
fill 479 12 416 480 17 416 minecraft:blackstone
fill 479 12 417 481 12 417 minecraft:red_nether_bricks
fill 481 12 416 482 13 416 minecraft:orange_concrete
fill 481 12 457 483 12 457 minecraft:red_nether_bricks
fill 483 12 417 485 12 417 minecraft:red_nether_bricks
fill 484 12 458 485 13 458 minecraft:orange_concrete
fill 485 12 457 487 12 457 minecraft:red_nether_bricks
fill 486 12 458 487 17 458 minecraft:blackstone
fill 487 12 416 488 17 416 minecraft:blackstone
fill 487 12 417 489 12 417 minecraft:red_nether_bricks
fill 489 12 416 490 12 416 minecraft:orange_concrete
fill 489 12 457 491 12 457 minecraft:red_nether_bricks
fill 491 12 416 491 17 416 minecraft:blackstone
fill 491 12 417 493 12 417 minecraft:red_nether_bricks
fill 493 12 457 495 12 457 minecraft:red_nether_bricks
fill 495 12 417 497 12 417 minecraft:red_nether_bricks
fill 495 12 458 495 17 458 minecraft:blackstone
fill 496 12 458 497 12 458 minecraft:orange_concrete
fill 497 12 457 499 12 457 minecraft:red_nether_bricks
fill 498 12 458 499 17 458 minecraft:blackstone
fill 499 12 416 500 17 416 minecraft:blackstone
fill 499 12 417 501 12 417 minecraft:red_nether_bricks
fill 500 12 442 500 13 442 minecraft:netherrack
fill 501 12 416 502 13 416 minecraft:orange_concrete
fill 501 12 457 503 12 457 minecraft:red_nether_bricks
fill 503 12 417 505 12 417 minecraft:red_nether_bricks
fill 504 12 458 505 13 458 minecraft:orange_concrete
fill 505 12 457 507 12 457 minecraft:red_nether_bricks
fill 506 12 458 507 17 458 minecraft:blackstone
fill 507 12 417 509 12 417 minecraft:red_nether_bricks
fill 508 12 416 508 17 416 minecraft:blackstone
setblock 508 12 458 minecraft:orange_concrete
fill 509 12 457 511 12 457 minecraft:red_nether_bricks
setblock 510 12 416 minecraft:orange_concrete
fill 511 12 416 512 17 416 minecraft:blackstone
fill 511 12 417 511 12 419 minecraft:red_nether_bricks
fill 511 12 421 511 12 423 minecraft:red_nether_bricks
fill 511 12 425 511 12 427 minecraft:red_nether_bricks
fill 511 12 429 511 12 431 minecraft:red_nether_bricks
fill 511 12 433 511 12 435 minecraft:red_nether_bricks
fill 511 12 437 511 12 439 minecraft:red_nether_bricks
fill 511 12 441 511 12 443 minecraft:red_nether_bricks
fill 511 12 445 511 12 447 minecraft:red_nether_bricks
fill 511 12 449 511 12 451 minecraft:red_nether_bricks
fill 511 12 453 511 12 455 minecraft:red_nether_bricks
fill 512 12 417 512 13 417 minecraft:orange_concrete
fill 512 12 423 512 17 424 minecraft:blackstone
fill 512 12 425 512 12 426 minecraft:orange_concrete
fill 512 12 435 512 17 436 minecraft:blackstone
fill 512 12 437 512 13 438 minecraft:orange_concrete
fill 512 12 444 512 17 444 minecraft:blackstone
fill 512 12 445 512 12 446 minecraft:orange_concrete
fill 512 12 447 512 17 447 minecraft:blackstone
fill 512 12 449 512 13 449 minecraft:orange_concrete
fill 512 12 455 512 17 456 minecraft:blackstone
fill 512 12 457 512 13 457 minecraft:orange_concrete
fill 470 13 428 470 13 429 minecraft:orange_concrete
setblock 470 13 432 minecraft:orange_concrete
fill 470 13 433 470 16 433 minecraft:blackstone
fill 470 13 444 470 15 444 minecraft:blackstone
setblock 470 13 449 minecraft:orange_concrete
setblock 472 13 458 minecraft:orange_concrete
setblock 473 13 416 minecraft:orange_concrete
fill 476 13 458 476 16 458 minecraft:blackstone
fill 478 13 416 478 16 416 minecraft:blackstone
fill 489 13 416 489 16 416 minecraft:blackstone
setblock 490 13 416 minecraft:orange_concrete
fill 492 13 458 493 13 458 minecraft:orange_concrete
fill 493 13 416 494 13 416 minecraft:orange_concrete
setblock 496 13 458 minecraft:orange_concrete
fill 497 13 458 497 16 458 minecraft:blackstone
fill 508 13 458 508 16 458 minecraft:blackstone
fill 510 13 416 510 16 416 minecraft:blackstone
setblock 512 13 418 minecraft:orange_concrete
fill 512 13 425 512 16 425 minecraft:blackstone
setblock 512 13 426 minecraft:orange_concrete
setblock 512 13 429 minecraft:orange_concrete
fill 512 13 445 512 16 446 minecraft:blackstone
setblock 512 13 450 minecraft:orange_concrete
fill 470 14 418 470 14 419 minecraft:orange_concrete
fill 470 14 420 470 19 421 minecraft:blackstone
fill 470 14 427 470 15 427 minecraft:orange_concrete
fill 470 14 428 470 19 429 minecraft:blackstone
setblock 470 14 430 minecraft:orange_concrete
fill 470 14 432 470 16 432 minecraft:blackstone
fill 470 14 438 470 15 439 minecraft:orange_concrete
fill 470 14 440 470 19 441 minecraft:blackstone
setblock 470 14 446 minecraft:blackstone
fill 470 14 447 470 15 447 minecraft:orange_concrete
fill 470 14 449 470 19 449 minecraft:blackstone
fill 470 14 450 470 14 451 minecraft:orange_concrete
fill 470 14 452 470 16 453 minecraft:blackstone
fill 470 14 458 471 15 458 minecraft:orange_concrete
fill 471 14 416 472 14 416 minecraft:orange_concrete
fill 472 14 458 473 19 458 minecraft:blackstone
fill 473 14 416 473 19 416 minecraft:blackstone
fill 481 14 416 482 19 416 minecraft:blackstone
fill 482 14 458 483 14 458 minecraft:orange_concrete
fill 483 14 416 484 15 416 minecraft:orange_concrete
fill 484 14 458 485 19 458 minecraft:blackstone
fill 490 14 416 490 19 416 minecraft:blackstone
fill 491 14 458 491 15 458 minecraft:orange_concrete
setblock 492 14 416 minecraft:orange_concrete
fill 492 14 458 493 19 458 minecraft:blackstone
fill 493 14 416 494 19 416 minecraft:blackstone
setblock 494 14 458 minecraft:orange_concrete
fill 495 14 416 495 15 416 minecraft:orange_concrete
fill 496 14 458 496 19 458 minecraft:blackstone
fill 501 14 416 502 19 416 minecraft:blackstone
fill 502 14 458 503 15 458 minecraft:orange_concrete
fill 503 14 416 504 14 416 minecraft:orange_concrete
fill 504 14 458 505 19 458 minecraft:blackstone
fill 512 14 417 512 19 418 minecraft:blackstone
fill 512 14 419 512 15 420 minecraft:orange_concrete
fill 512 14 426 512 19 426 minecraft:blackstone
fill 512 14 427 512 14 428 minecraft:orange_concrete
fill 512 14 429 512 19 429 minecraft:blackstone
fill 512 14 431 512 15 431 minecraft:orange_concrete
fill 512 14 437 512 19 438 minecraft:blackstone
fill 512 14 439 512 15 440 minecraft:orange_concrete
setblock 512 14 448 minecraft:orange_concrete
fill 512 14 449 512 19 450 minecraft:blackstone
fill 512 14 451 512 15 452 minecraft:orange_concrete
fill 512 14 457 512 19 457 minecraft:blackstone
setblock 470 15 418 minecraft:orange_concrete
fill 470 15 419 470 18 419 minecraft:blackstone
setblock 470 15 426 minecraft:orange_concrete
fill 470 15 430 470 18 430 minecraft:blackstone
fill 470 15 434 470 17 434 minecraft:blackstone
setblock 470 15 435 minecraft:orange_concrete
setblock 470 15 446 minecraft:orange_concrete
setblock 470 15 450 minecraft:orange_concrete
fill 470 15 451 470 18 451 minecraft:blackstone
fill 471 15 416 471 18 416 minecraft:blackstone
setblock 472 15 416 minecraft:orange_concrete
fill 475 15 416 476 15 416 minecraft:orange_concrete
setblock 479 15 458 minecraft:orange_concrete
setblock 482 15 458 minecraft:orange_concrete
fill 483 15 458 483 18 458 minecraft:blackstone
fill 484 15 422 484 16 423 minecraft:magma_block
setblock 490 15 458 minecraft:orange_concrete
fill 492 15 416 492 18 416 minecraft:blackstone
fill 494 15 458 494 18 458 minecraft:blackstone
setblock 496 15 416 minecraft:orange_concrete
fill 503 15 416 503 18 416 minecraft:blackstone
setblock 504 15 416 minecraft:orange_concrete
setblock 507 15 416 minecraft:orange_concrete
fill 510 15 458 511 15 458 minecraft:orange_concrete
fill 512 15 427 512 18 428 minecraft:blackstone
setblock 512 15 432 minecraft:orange_concrete
setblock 512 15 443 minecraft:orange_concrete
fill 512 15 448 512 18 448 minecraft:blackstone
fill 470 16 416 470 16 417 minecraft:orange_concrete
fill 470 16 418 470 21 418 minecraft:blackstone
fill 470 16 424 470 17 425 minecraft:orange_concrete
fill 470 16 426 470 21 427 minecraft:blackstone
fill 470 16 435 470 17 435 minecraft:blackstone
fill 470 16 436 470 16 437 minecraft:orange_concrete
fill 470 16 438 470 21 439 minecraft:blackstone
fill 470 16 444 470 17 445 minecraft:orange_concrete
fill 470 16 446 470 21 447 minecraft:blackstone
setblock 470 16 448 minecraft:orange_concrete
fill 470 16 450 470 18 450 minecraft:blackstone
fill 470 16 456 470 17 457 minecraft:orange_concrete
fill 470 16 458 471 21 458 minecraft:blackstone
fill 472 16 416 472 21 416 minecraft:blackstone
setblock 473 16 419 minecraft:light[level=14]
setblock 473 16 427 minecraft:light[level=14]
setblock 473 16 435 minecraft:light[level=14]
setblock 473 16 443 minecraft:light[level=14]
setblock 473 16 451 minecraft:light[level=14]
setblock 474 16 416 minecraft:orange_concrete
fill 475 16 416 476 21 416 minecraft:blackstone
fill 477 16 416 477 17 416 minecraft:orange_concrete
fill 477 16 458 477 17 458 minecraft:orange_concrete
fill 479 16 458 479 21 458 minecraft:blackstone
fill 480 16 458 481 16 458 minecraft:orange_concrete
setblock 481 16 419 minecraft:light[level=14]
setblock 481 16 427 minecraft:light[level=14]
setblock 481 16 435 minecraft:light[level=14]
setblock 481 16 443 minecraft:light[level=14]
setblock 481 16 451 minecraft:light[level=14]
fill 482 16 458 482 21 458 minecraft:blackstone
fill 483 16 416 484 21 416 minecraft:blackstone
fill 485 16 416 486 16 416 minecraft:orange_concrete
fill 488 16 458 489 17 458 minecraft:orange_concrete
setblock 489 16 419 minecraft:light[level=14]
setblock 489 16 427 minecraft:light[level=14]
setblock 489 16 435 minecraft:light[level=14]
setblock 489 16 443 minecraft:light[level=14]
fill 490 16 458 491 21 458 minecraft:blackstone
fill 495 16 416 496 21 416 minecraft:blackstone
fill 497 16 416 498 17 416 minecraft:orange_concrete
setblock 497 16 419 minecraft:light[level=14]
setblock 497 16 427 minecraft:light[level=14]
setblock 497 16 435 minecraft:light[level=14]
setblock 497 16 443 minecraft:light[level=14]
setblock 497 16 451 minecraft:light[level=14]
fill 500 16 458 501 16 458 minecraft:orange_concrete
fill 502 16 458 503 21 458 minecraft:blackstone
fill 504 16 416 504 21 416 minecraft:blackstone
fill 505 16 416 506 16 416 minecraft:orange_concrete
setblock 505 16 419 minecraft:light[level=14]
setblock 505 16 427 minecraft:light[level=14]
setblock 505 16 435 minecraft:light[level=14]
setblock 505 16 443 minecraft:light[level=14]
setblock 505 16 451 minecraft:light[level=14]
fill 507 16 416 507 21 416 minecraft:blackstone
fill 509 16 416 509 17 416 minecraft:orange_concrete
fill 509 16 458 509 17 458 minecraft:orange_concrete
fill 510 16 458 511 21 458 minecraft:blackstone
fill 512 16 419 512 21 420 minecraft:blackstone
fill 512 16 421 512 17 422 minecraft:orange_concrete
setblock 512 16 430 minecraft:orange_concrete
fill 512 16 431 512 21 432 minecraft:blackstone
fill 512 16 433 512 17 434 minecraft:orange_concrete
fill 512 16 439 512 21 440 minecraft:blackstone
fill 512 16 441 512 16 442 minecraft:orange_concrete
fill 512 16 443 512 21 443 minecraft:blackstone
fill 512 16 451 512 21 452 minecraft:blackstone
fill 512 16 453 512 17 454 minecraft:orange_concrete
setblock 512 16 458 minecraft:orange_concrete
fill 470 17 416 470 20 417 minecraft:blackstone
fill 470 17 432 470 17 433 minecraft:orange_concrete
setblock 470 17 436 minecraft:orange_concrete
fill 470 17 437 470 20 437 minecraft:blackstone
fill 470 17 448 470 20 448 minecraft:blackstone
fill 470 17 452 470 19 452 minecraft:blackstone
setblock 470 17 453 minecraft:orange_concrete
fill 474 17 416 474 20 416 minecraft:blackstone
setblock 476 17 458 minecraft:orange_concrete
setblock 478 17 416 minecraft:orange_concrete
fill 480 17 458 481 20 458 minecraft:blackstone
fill 485 17 416 485 20 416 minecraft:blackstone
setblock 486 17 416 minecraft:orange_concrete
setblock 489 17 416 minecraft:orange_concrete
setblock 497 17 458 minecraft:orange_concrete
setblock 500 17 458 minecraft:orange_concrete
fill 501 17 458 501 20 458 minecraft:blackstone
fill 505 17 416 506 20 416 minecraft:blackstone
setblock 508 17 458 minecraft:orange_concrete
setblock 510 17 416 minecraft:orange_concrete
setblock 512 17 425 minecraft:orange_concrete
fill 512 17 430 512 20 430 minecraft:blackstone
fill 512 17 441 512 20 441 minecraft:blackstone
setblock 512 17 442 minecraft:orange_concrete
fill 512 17 445 512 17 446 minecraft:orange_concrete
fill 512 17 458 512 20 458 minecraft:blackstone
fill 470 18 422 470 19 423 minecraft:orange_concrete
fill 470 18 424 470 23 425 minecraft:blackstone
fill 470 18 431 470 19 431 minecraft:orange_concrete
fill 470 18 432 470 19 433 minecraft:blackstone
fill 470 18 434 470 18 435 minecraft:orange_concrete
fill 470 18 436 470 23 436 minecraft:blackstone
fill 470 18 442 470 19 443 minecraft:orange_concrete
fill 470 18 444 470 23 445 minecraft:blackstone
fill 470 18 453 470 23 453 minecraft:blackstone
fill 470 18 454 470 18 455 minecraft:orange_concrete
fill 470 18 456 470 23 457 minecraft:blackstone
fill 471 18 417 473 18 417 minecraft:red_nether_bricks
fill 471 18 419 471 18 421 minecraft:red_nether_bricks
fill 471 18 423 471 18 425 minecraft:red_nether_bricks
fill 471 18 427 471 18 429 minecraft:red_nether_bricks
fill 471 18 431 471 18 433 minecraft:red_nether_bricks
fill 471 18 435 471 18 437 minecraft:red_nether_bricks
fill 471 18 439 471 18 441 minecraft:red_nether_bricks
fill 471 18 443 471 18 445 minecraft:red_nether_bricks
fill 471 18 447 471 18 449 minecraft:red_nether_bricks
fill 471 18 451 471 18 453 minecraft:red_nether_bricks
fill 471 18 455 471 18 457 minecraft:red_nether_bricks
fill 473 18 457 475 18 457 minecraft:red_nether_bricks
fill 474 18 458 475 19 458 minecraft:orange_concrete
fill 475 18 417 477 18 417 minecraft:red_nether_bricks
fill 476 18 458 477 23 458 minecraft:blackstone
fill 477 18 416 478 23 416 minecraft:blackstone
fill 477 18 457 479 18 457 minecraft:red_nether_bricks
fill 478 18 444 478 19 445 minecraft:shroomlight
setblock 478 18 458 minecraft:orange_concrete
fill 479 18 416 480 19 416 minecraft:orange_concrete
fill 479 18 417 481 18 417 minecraft:red_nether_bricks
fill 481 18 457 483 18 457 minecraft:red_nether_bricks
fill 483 18 417 485 18 417 minecraft:red_nether_bricks
fill 485 18 457 487 18 457 minecraft:red_nether_bricks
fill 486 18 416 486 23 416 minecraft:blackstone
fill 486 18 458 487 19 458 minecraft:orange_concrete
fill 487 18 416 488 18 416 minecraft:orange_concrete
fill 487 18 417 489 18 417 minecraft:red_nether_bricks
fill 488 18 458 489 23 458 minecraft:blackstone
fill 489 18 416 489 23 416 minecraft:blackstone
fill 489 18 457 491 18 457 minecraft:red_nether_bricks
fill 491 18 416 491 19 416 minecraft:orange_concrete
fill 491 18 417 493 18 417 minecraft:red_nether_bricks
fill 493 18 457 495 18 457 minecraft:red_nether_bricks
fill 495 18 417 497 18 417 minecraft:red_nether_bricks
fill 495 18 458 495 19 458 minecraft:orange_concrete
fill 497 18 416 498 23 416 minecraft:blackstone
fill 497 18 457 499 18 457 minecraft:red_nether_bricks
fill 497 18 458 497 23 458 minecraft:blackstone
fill 498 18 458 499 18 458 minecraft:orange_concrete
fill 499 18 416 500 19 416 minecraft:orange_concrete
fill 499 18 417 501 18 417 minecraft:red_nether_bricks
fill 500 18 458 500 23 458 minecraft:blackstone
fill 501 18 457 503 18 457 minecraft:red_nether_bricks
fill 503 18 417 505 18 417 minecraft:red_nether_bricks
fill 505 18 457 507 18 457 minecraft:red_nether_bricks
fill 506 18 458 507 19 458 minecraft:orange_concrete
fill 507 18 417 509 18 417 minecraft:red_nether_bricks
setblock 508 18 416 minecraft:orange_concrete
fill 508 18 458 509 23 458 minecraft:blackstone
fill 509 18 416 510 23 416 minecraft:blackstone
fill 509 18 457 511 18 457 minecraft:red_nether_bricks
fill 511 18 416 512 19 416 minecraft:orange_concrete
fill 511 18 417 511 18 419 minecraft:red_nether_bricks
fill 511 18 421 511 18 423 minecraft:red_nether_bricks
fill 511 18 425 511 18 427 minecraft:red_nether_bricks
fill 511 18 429 511 18 431 minecraft:red_nether_bricks
fill 511 18 433 511 18 435 minecraft:red_nether_bricks
fill 511 18 437 511 18 439 minecraft:red_nether_bricks
fill 511 18 441 511 18 443 minecraft:red_nether_bricks
fill 511 18 445 511 18 447 minecraft:red_nether_bricks
fill 511 18 449 511 18 451 minecraft:red_nether_bricks
fill 511 18 453 511 18 455 minecraft:red_nether_bricks
fill 512 18 421 512 23 422 minecraft:blackstone
fill 512 18 423 512 18 424 minecraft:orange_concrete
fill 512 18 425 512 23 425 minecraft:blackstone
fill 512 18 433 512 23 434 minecraft:blackstone
fill 512 18 435 512 19 436 minecraft:orange_concrete
fill 512 18 442 512 23 442 minecraft:blackstone
setblock 512 18 444 minecraft:orange_concrete
fill 512 18 445 512 23 446 minecraft:blackstone
fill 512 18 447 512 19 447 minecraft:orange_concrete
fill 512 18 453 512 23 454 minecraft:blackstone
fill 512 18 455 512 18 456 minecraft:orange_concrete
setblock 470 19 419 minecraft:orange_concrete
setblock 470 19 430 minecraft:orange_concrete
fill 470 19 434 470 21 435 minecraft:blackstone
fill 470 19 450 470 19 451 minecraft:orange_concrete
setblock 470 19 454 minecraft:orange_concrete
fill 470 19 455 470 22 455 minecraft:blackstone
setblock 471 19 416 minecraft:orange_concrete
fill 478 19 440 479 20 441 minecraft:shroomlight
fill 478 19 458 478 22 458 minecraft:blackstone
setblock 483 19 458 minecraft:orange_concrete
fill 487 19 416 488 22 416 minecraft:blackstone
setblock 492 19 416 minecraft:orange_concrete
setblock 494 19 458 minecraft:orange_concrete
fill 498 19 458 499 22 458 minecraft:blackstone
setblock 503 19 416 minecraft:orange_concrete
fill 508 19 416 508 22 416 minecraft:blackstone
fill 512 19 423 512 22 423 minecraft:blackstone
setblock 512 19 424 minecraft:orange_concrete
fill 512 19 427 512 19 428 minecraft:orange_concrete
fill 512 19 444 512 22 444 minecraft:blackstone
setblock 512 19 448 minecraft:orange_concrete
fill 512 19 455 512 22 455 minecraft:blackstone
setblock 512 19 456 minecraft:orange_concrete
fill 470 20 419 470 25 419 minecraft:blackstone
fill 470 20 420 470 20 421 minecraft:orange_concrete
fill 470 20 422 470 22 423 minecraft:blackstone
fill 470 20 428 470 21 429 minecraft:orange_concrete
fill 470 20 430 470 25 431 minecraft:blackstone
setblock 470 20 432 minecraft:orange_concrete
fill 470 20 433 470 23 433 minecraft:blackstone
fill 470 20 440 470 21 441 minecraft:orange_concrete
fill 470 20 442 470 25 443 minecraft:blackstone
fill 470 20 449 470 21 449 minecraft:orange_concrete
fill 470 20 450 470 25 451 minecraft:blackstone
setblock 470 20 452 minecraft:orange_concrete
fill 470 20 454 470 25 454 minecraft:blackstone
fill 471 20 416 471 25 416 minecraft:blackstone
fill 472 20 458 473 21 458 minecraft:orange_concrete
fill 473 20 416 473 21 416 minecraft:orange_concrete
fill 474 20 458 475 25 458 minecraft:blackstone
fill 479 20 416 480 25 416 minecraft:blackstone
fill 481 20 416 482 21 416 minecraft:orange_concrete
fill 483 20 458 483 25 458 minecraft:blackstone
fill 484 20 458 485 20 458 minecraft:orange_concrete
fill 486 20 458 487 25 458 minecraft:blackstone
setblock 490 20 416 minecraft:orange_concrete
fill 491 20 416 492 25 416 minecraft:blackstone
fill 492 20 458 493 21 458 minecraft:orange_concrete
fill 493 20 416 494 21 416 minecraft:orange_concrete
fill 494 20 458 495 25 458 minecraft:blackstone
setblock 496 20 458 minecraft:orange_concrete
fill 499 20 416 500 25 416 minecraft:blackstone
fill 501 20 416 502 20 416 minecraft:orange_concrete
fill 503 20 416 503 25 416 minecraft:blackstone
fill 504 20 458 505 21 458 minecraft:orange_concrete
fill 506 20 458 507 25 458 minecraft:blackstone
fill 511 20 416 512 25 416 minecraft:blackstone
fill 512 20 417 512 21 418 minecraft:orange_concrete
fill 512 20 424 512 25 424 minecraft:blackstone
setblock 512 20 426 minecraft:orange_concrete
fill 512 20 427 512 25 428 minecraft:blackstone
fill 512 20 429 512 21 429 minecraft:orange_concrete
fill 512 20 435 512 25 436 minecraft:blackstone
fill 512 20 437 512 20 438 minecraft:orange_concrete
fill 512 20 447 512 25 448 minecraft:blackstone
fill 512 20 449 512 21 450 minecraft:orange_concrete
fill 512 20 456 512 25 456 minecraft:blackstone
setblock 512 20 457 minecraft:orange_concrete
fill 470 21 416 470 21 417 minecraft:orange_concrete
setblock 470 21 420 minecraft:orange_concrete
fill 470 21 421 470 24 421 minecraft:blackstone
fill 470 21 432 470 23 432 minecraft:blackstone
setblock 470 21 437 minecraft:orange_concrete
setblock 470 21 448 minecraft:orange_concrete
fill 470 21 452 470 24 452 minecraft:blackstone
setblock 474 21 416 minecraft:orange_concrete
fill 480 21 458 481 21 458 minecraft:orange_concrete
setblock 484 21 458 minecraft:orange_concrete
setblock 485 21 416 minecraft:orange_concrete
fill 485 21 458 485 24 458 minecraft:blackstone
fill 490 21 416 490 24 416 minecraft:blackstone
fill 496 21 458 496 24 458 minecraft:blackstone
fill 501 21 416 501 24 416 minecraft:blackstone
setblock 501 21 458 minecraft:orange_concrete
setblock 502 21 416 minecraft:orange_concrete
fill 505 21 416 506 21 416 minecraft:orange_concrete
fill 512 21 426 512 24 426 minecraft:blackstone
setblock 512 21 430 minecraft:orange_concrete
fill 512 21 437 512 24 437 minecraft:blackstone
setblock 512 21 438 minecraft:orange_concrete
setblock 512 21 441 minecraft:orange_concrete
fill 512 21 457 512 24 457 minecraft:blackstone
setblock 512 21 458 minecraft:orange_concrete
fill 470 22 416 470 27 417 minecraft:blackstone
setblock 470 22 418 minecraft:orange_concrete
fill 470 22 420 470 24 420 minecraft:blackstone
fill 470 22 426 470 23 427 minecraft:orange_concrete
fill 470 22 428 470 27 429 minecraft:blackstone
setblock 470 22 434 minecraft:blackstone
fill 470 22 435 470 23 435 minecraft:orange_concrete
fill 470 22 437 470 27 437 minecraft:blackstone
fill 470 22 438 470 22 439 minecraft:orange_concrete
fill 470 22 440 470 24 441 minecraft:blackstone
fill 470 22 446 470 23 447 minecraft:orange_concrete
fill 470 22 448 470 27 449 minecraft:blackstone
fill 470 22 458 471 22 458 minecraft:orange_concrete
setblock 472 22 416 minecraft:orange_concrete
fill 472 22 458 473 27 458 minecraft:blackstone
fill 473 22 416 474 27 416 minecraft:blackstone
fill 475 22 416 476 23 416 minecraft:orange_concrete
fill 479 22 458 479 23 458 minecraft:orange_concrete
fill 480 22 458 481 27 458 minecraft:blackstone
fill 481 22 416 482 27 416 minecraft:blackstone
setblock 482 22 458 minecraft:orange_concrete
fill 483 22 416 484 22 416 minecraft:orange_concrete
fill 484 22 458 484 27 458 minecraft:blackstone
fill 485 22 416 485 27 416 minecraft:blackstone
fill 490 22 458 491 23 458 minecraft:orange_concrete
fill 492 22 458 493 27 458 minecraft:blackstone
fill 493 22 416 494 27 416 minecraft:blackstone
fill 495 22 416 496 23 416 minecraft:orange_concrete
fill 501 22 458 501 27 458 minecraft:blackstone
fill 502 22 416 502 27 416 minecraft:blackstone
fill 502 22 458 503 22 458 minecraft:orange_concrete
setblock 504 22 416 minecraft:orange_concrete
fill 504 22 458 505 27 458 minecraft:blackstone
fill 505 22 416 506 27 416 minecraft:blackstone
fill 507 22 416 507 23 416 minecraft:orange_concrete
fill 510 22 458 511 23 458 minecraft:orange_concrete
fill 512 22 417 512 27 418 minecraft:blackstone
fill 512 22 419 512 22 420 minecraft:orange_concrete
fill 512 22 429 512 27 430 minecraft:blackstone
fill 512 22 431 512 23 432 minecraft:orange_concrete
fill 512 22 438 512 27 438 minecraft:blackstone
fill 512 22 439 512 22 440 minecraft:orange_concrete
fill 512 22 441 512 27 441 minecraft:blackstone
fill 512 22 443 512 23 443 minecraft:orange_concrete
fill 512 22 449 512 27 450 minecraft:blackstone
fill 512 22 451 512 23 452 minecraft:orange_concrete
fill 512 22 458 512 27 458 minecraft:blackstone
fill 470 23 418 470 26 418 minecraft:blackstone
fill 470 23 422 470 25 422 minecraft:blackstone
setblock 470 23 423 minecraft:orange_concrete
setblock 470 23 434 minecraft:orange_concrete
setblock 470 23 438 minecraft:orange_concrete
fill 470 23 439 470 26 439 minecraft:blackstone
setblock 470 23 455 minecraft:orange_concrete
setblock 470 23 458 minecraft:orange_concrete
fill 471 23 458 471 26 458 minecraft:blackstone
fill 472 23 416 472 26 416 minecraft:blackstone
setblock 478 23 458 minecraft:orange_concrete
fill 482 23 458 482 26 458 minecraft:blackstone
fill 483 23 416 483 26 416 minecraft:blackstone
setblock 484 23 416 minecraft:orange_concrete
fill 487 23 416 488 23 416 minecraft:orange_concrete
fill 498 23 458 499 23 458 minecraft:orange_concrete
setblock 502 23 458 minecraft:orange_concrete
fill 503 23 458 503 26 458 minecraft:blackstone
fill 504 23 416 504 26 416 minecraft:blackstone
setblock 508 23 416 minecraft:orange_concrete
fill 512 23 419 512 26 419 minecraft:blackstone
setblock 512 23 420 minecraft:orange_concrete
setblock 512 23 423 minecraft:orange_concrete
fill 512 23 439 512 26 440 minecraft:blackstone
setblock 512 23 444 minecraft:orange_concrete
setblock 512 23 455 minecraft:orange_concrete
fill 470 24 423 470 25 423 minecraft:blackstone
fill 470 24 424 470 24 425 minecraft:orange_concrete
fill 470 24 426 470 29 427 minecraft:blackstone
fill 470 24 432 470 25 433 minecraft:orange_concrete
fill 470 24 434 470 29 435 minecraft:blackstone
setblock 470 24 436 minecraft:orange_concrete
fill 470 24 438 470 26 438 minecraft:blackstone
fill 470 24 444 470 25 445 minecraft:orange_concrete
fill 470 24 446 470 29 447 minecraft:blackstone
fill 470 24 453 470 25 453 minecraft:orange_concrete
fill 470 24 455 470 29 455 minecraft:blackstone
fill 470 24 456 470 24 457 minecraft:orange_concrete
fill 470 24 458 470 29 458 minecraft:blackstone
fill 471 24 417 473 24 417 minecraft:red_nether_bricks
fill 471 24 419 471 24 421 minecraft:red_nether_bricks
fill 471 24 423 471 24 425 minecraft:red_nether_bricks
fill 471 24 427 471 24 429 minecraft:red_nether_bricks
fill 471 24 431 471 24 433 minecraft:red_nether_bricks
fill 471 24 435 471 24 437 minecraft:red_nether_bricks
fill 471 24 439 471 24 441 minecraft:red_nether_bricks
fill 471 24 443 471 24 445 minecraft:red_nether_bricks
fill 471 24 447 471 24 449 minecraft:red_nether_bricks
fill 471 24 451 471 24 453 minecraft:red_nether_bricks
fill 471 24 455 471 24 457 minecraft:red_nether_bricks
setblock 473 24 419 minecraft:light[level=14]
setblock 473 24 427 minecraft:light[level=14]
setblock 473 24 435 minecraft:light[level=14]
setblock 473 24 443 minecraft:light[level=14]
setblock 473 24 451 minecraft:light[level=14]
fill 473 24 457 475 24 457 minecraft:red_nether_bricks
fill 475 24 416 476 29 416 minecraft:blackstone
fill 475 24 417 477 24 417 minecraft:red_nether_bricks
fill 476 24 458 477 25 458 minecraft:orange_concrete
fill 477 24 416 478 25 416 minecraft:orange_concrete
fill 477 24 457 479 24 457 minecraft:red_nether_bricks
fill 478 24 458 479 29 458 minecraft:blackstone
fill 479 24 417 481 24 417 minecraft:red_nether_bricks
setblock 481 24 419 minecraft:light[level=14]
setblock 481 24 427 minecraft:light[level=14]
setblock 481 24 435 minecraft:light[level=14]
setblock 481 24 443 minecraft:light[level=14]
setblock 481 24 451 minecraft:light[level=14]
fill 481 24 457 483 24 457 minecraft:red_nether_bricks
fill 483 24 417 485 24 417 minecraft:red_nether_bricks
fill 484 24 416 484 29 416 minecraft:blackstone
fill 484 24 430 484 25 430 minecraft:shroomlight
fill 485 24 457 487 24 457 minecraft:red_nether_bricks
setblock 486 24 416 minecraft:orange_concrete
fill 487 24 416 488 29 416 minecraft:blackstone
fill 487 24 417 489 24 417 minecraft:red_nether_bricks
fill 488 24 458 489 24 458 minecraft:orange_concrete
fill 489 24 416 489 25 416 minecraft:orange_concrete
setblock 489 24 419 minecraft:light[level=14]
setblock 489 24 427 minecraft:light[level=14]
setblock 489 24 435 minecraft:light[level=14]
setblock 489 24 443 minecraft:light[level=14]
fill 489 24 457 491 24 457 minecraft:red_nether_bricks
fill 490 24 458 491 29 458 minecraft:blackstone
fill 491 24 417 493 24 417 minecraft:red_nether_bricks
fill 493 24 457 495 24 457 minecraft:red_nether_bricks
fill 495 24 416 496 29 416 minecraft:blackstone
fill 495 24 417 497 24 417 minecraft:red_nether_bricks
fill 497 24 416 498 24 416 minecraft:orange_concrete
setblock 497 24 419 minecraft:light[level=14]
setblock 497 24 427 minecraft:light[level=14]
setblock 497 24 435 minecraft:light[level=14]
setblock 497 24 443 minecraft:light[level=14]
setblock 497 24 451 minecraft:light[level=14]
fill 497 24 457 499 24 457 minecraft:red_nether_bricks
fill 497 24 458 497 25 458 minecraft:orange_concrete
fill 498 24 458 499 29 458 minecraft:blackstone
fill 499 24 417 501 24 417 minecraft:red_nether_bricks
setblock 500 24 458 minecraft:orange_concrete
fill 501 24 457 503 24 457 minecraft:red_nether_bricks
fill 502 24 458 502 29 458 minecraft:blackstone
fill 503 24 417 505 24 417 minecraft:red_nether_bricks
setblock 505 24 419 minecraft:light[level=14]
setblock 505 24 427 minecraft:light[level=14]
setblock 505 24 435 minecraft:light[level=14]
setblock 505 24 443 minecraft:light[level=14]
setblock 505 24 451 minecraft:light[level=14]
fill 505 24 457 507 24 457 minecraft:red_nether_bricks
fill 507 24 416 508 29 416 minecraft:blackstone
fill 507 24 417 509 24 417 minecraft:red_nether_bricks
fill 508 24 458 509 25 458 minecraft:orange_concrete
fill 509 24 416 510 25 416 minecraft:orange_concrete
fill 509 24 457 511 24 457 minecraft:red_nether_bricks
fill 510 24 458 511 29 458 minecraft:blackstone
fill 511 24 417 511 24 419 minecraft:red_nether_bricks
fill 511 24 421 511 24 423 minecraft:red_nether_bricks
fill 511 24 425 511 24 427 minecraft:red_nether_bricks
fill 511 24 429 511 24 431 minecraft:red_nether_bricks
fill 511 24 433 511 24 435 minecraft:red_nether_bricks
fill 511 24 437 511 24 439 minecraft:red_nether_bricks
fill 511 24 441 511 24 443 minecraft:red_nether_bricks
fill 511 24 445 511 24 447 minecraft:red_nether_bricks
fill 511 24 449 511 24 451 minecraft:red_nether_bricks
fill 511 24 453 511 24 455 minecraft:red_nether_bricks
fill 512 24 420 512 29 420 minecraft:blackstone
fill 512 24 421 512 24 422 minecraft:orange_concrete
fill 512 24 423 512 29 423 minecraft:blackstone
fill 512 24 425 512 25 425 minecraft:orange_concrete
fill 512 24 431 512 29 432 minecraft:blackstone
fill 512 24 433 512 25 434 minecraft:orange_concrete
setblock 512 24 442 minecraft:orange_concrete
fill 512 24 443 512 29 444 minecraft:blackstone
fill 512 24 445 512 25 446 minecraft:orange_concrete
fill 512 24 451 512 29 452 minecraft:blackstone
fill 512 24 453 512 24 454 minecraft:orange_concrete
fill 512 24 455 512 29 455 minecraft:blackstone
fill 470 25 420 470 25 421 minecraft:orange_concrete
setblock 470 25 424 minecraft:orange_concrete
fill 470 25 425 470 28 425 minecraft:blackstone
fill 470 25 436 470 28 436 minecraft:blackstone
fill 470 25 440 470 27 440 minecraft:blackstone
setblock 470 25 441 minecraft:orange_concrete
setblock 470 25 452 minecraft:orange_concrete
fill 470 25 456 470 28 457 minecraft:blackstone
setblock 485 25 458 minecraft:orange_concrete
fill 486 25 416 486 28 416 minecraft:blackstone
setblock 488 25 458 minecraft:orange_concrete
fill 489 25 458 489 28 458 minecraft:blackstone
setblock 490 25 416 minecraft:orange_concrete
setblock 496 25 458 minecraft:orange_concrete
fill 497 25 416 497 28 416 minecraft:blackstone
setblock 498 25 416 minecraft:orange_concrete
fill 500 25 458 500 28 458 minecraft:blackstone
setblock 501 25 416 minecraft:orange_concrete
fill 512 25 421 512 28 422 minecraft:blackstone
setblock 512 25 426 minecraft:orange_concrete
setblock 512 25 437 minecraft:orange_concrete
fill 512 25 442 512 28 442 minecraft:blackstone
fill 512 25 453 512 28 453 minecraft:blackstone
setblock 512 25 454 minecraft:orange_concrete
setblock 512 25 457 minecraft:orange_concrete
fill 470 26 419 470 27 419 minecraft:orange_concrete
fill 470 26 420 470 27 421 minecraft:blackstone
fill 470 26 422 470 26 423 minecraft:orange_concrete
fill 470 26 424 470 43 424 minecraft:blackstone
fill 470 26 430 470 27 431 minecraft:orange_concrete
fill 470 26 432 470 44 433 minecraft:blackstone
fill 470 26 441 470 40 441 minecraft:blackstone
fill 470 26 442 470 26 443 minecraft:orange_concrete
fill 470 26 444 470 43 445 minecraft:blackstone
fill 470 26 450 470 27 451 minecraft:orange_concrete
fill 470 26 452 470 40 453 minecraft:blackstone
setblock 470 26 454 minecraft:orange_concrete
fill 471 26 416 471 27 416 minecraft:orange_concrete
fill 474 26 458 475 27 458 minecraft:orange_concrete
fill 476 26 458 477 43 458 minecraft:blackstone
fill 477 26 416 478 43 416 minecraft:blackstone
fill 479 26 416 480 26 416 minecraft:orange_concrete
fill 483 26 458 483 27 458 minecraft:orange_concrete
fill 485 26 458 485 40 458 minecraft:blackstone
fill 486 26 458 487 26 458 minecraft:orange_concrete
fill 488 26 458 488 43 458 minecraft:blackstone
fill 489 26 416 490 40 416 minecraft:blackstone
fill 491 26 416 492 27 416 minecraft:orange_concrete
fill 494 26 458 495 27 458 minecraft:orange_concrete
fill 496 26 458 497 40 458 minecraft:blackstone
fill 498 26 416 498 43 416 minecraft:blackstone
fill 499 26 416 500 26 416 minecraft:orange_concrete
fill 501 26 416 501 40 416 minecraft:blackstone
fill 503 26 416 503 27 416 minecraft:orange_concrete
fill 506 26 458 507 26 458 minecraft:orange_concrete
fill 508 26 458 509 43 458 minecraft:blackstone
fill 509 26 416 510 43 416 minecraft:blackstone
fill 511 26 416 512 27 416 minecraft:orange_concrete
setblock 512 26 424 minecraft:orange_concrete
fill 512 26 425 512 40 426 minecraft:blackstone
fill 512 26 427 512 27 428 minecraft:orange_concrete
fill 512 26 433 512 43 434 minecraft:blackstone
fill 512 26 435 512 26 436 minecraft:orange_concrete
fill 512 26 437 512 40 437 minecraft:blackstone
fill 512 26 445 512 44 446 minecraft:blackstone
fill 512 26 447 512 27 448 minecraft:orange_concrete
fill 512 26 454 512 43 454 minecraft:blackstone
setblock 512 26 456 minecraft:orange_concrete
fill 512 26 457 512 40 457 minecraft:blackstone
setblock 470 27 418 minecraft:orange_concrete
fill 470 27 422 470 29 423 minecraft:blackstone
fill 470 27 438 470 27 439 minecraft:orange_concrete
setblock 470 27 442 minecraft:orange_concrete
fill 470 27 443 470 45 443 minecraft:blackstone
fill 470 27 454 470 45 454 minecraft:blackstone
setblock 471 27 458 minecraft:orange_concrete
setblock 472 27 416 minecraft:orange_concrete
fill 479 27 416 479 45 416 minecraft:blackstone
setblock 480 27 416 minecraft:orange_concrete
setblock 482 27 458 minecraft:orange_concrete
setblock 483 27 416 minecraft:orange_concrete
fill 486 27 458 487 45 458 minecraft:blackstone
fill 487 27 450 488 27 454 minecraft:orange_concrete
fill 488 27 449 492 27 449 minecraft:orange_concrete
fill 488 27 455 495 27 455 minecraft:orange_concrete
fill 489 27 450 489 29 450 minecraft:orange_concrete
fill 489 27 454 489 29 454 minecraft:orange_concrete
fill 491 27 450 493 27 450 minecraft:orange_concrete
fill 491 27 454 493 28 454 minecraft:orange_concrete
fill 492 27 451 492 28 453 minecraft:orange_concrete
fill 493 27 451 496 27 451 minecraft:orange_concrete
fill 495 27 454 496 27 454 minecraft:orange_concrete
fill 496 27 452 496 28 453 minecraft:orange_concrete
fill 499 27 416 500 45 416 minecraft:blackstone
setblock 503 27 458 minecraft:orange_concrete
setblock 504 27 416 minecraft:orange_concrete
setblock 506 27 458 minecraft:orange_concrete
fill 507 27 458 507 45 458 minecraft:blackstone
setblock 512 27 419 minecraft:orange_concrete
fill 512 27 424 512 45 424 minecraft:blackstone
fill 512 27 435 512 45 435 minecraft:blackstone
setblock 512 27 436 minecraft:orange_concrete
fill 512 27 439 512 27 440 minecraft:orange_concrete
fill 512 27 456 512 45 456 minecraft:blackstone
fill 470 28 416 470 29 417 minecraft:orange_concrete
fill 470 28 418 470 41 419 minecraft:blackstone
setblock 470 28 420 minecraft:orange_concrete
fill 470 28 421 470 40 421 minecraft:blackstone
fill 470 28 428 470 29 429 minecraft:orange_concrete
fill 470 28 430 470 41 431 minecraft:blackstone
fill 470 28 437 470 29 437 minecraft:orange_concrete
fill 470 28 438 470 41 439 minecraft:blackstone
setblock 470 28 440 minecraft:orange_concrete
fill 470 28 442 470 45 442 minecraft:blackstone
fill 470 28 448 470 29 449 minecraft:orange_concrete
fill 470 28 450 470 41 451 minecraft:blackstone
fill 471 28 416 472 41 416 minecraft:blackstone
fill 471 28 458 471 41 458 minecraft:blackstone
fill 472 28 458 473 28 458 minecraft:orange_concrete
fill 473 28 416 474 29 416 minecraft:orange_concrete
fill 474 28 458 475 45 458 minecraft:blackstone
fill 480 28 416 480 45 416 minecraft:blackstone
fill 480 28 458 481 29 458 minecraft:orange_concrete
fill 481 28 416 482 28 416 minecraft:orange_concrete
fill 482 28 458 483 41 458 minecraft:blackstone
fill 483 28 416 483 41 416 minecraft:blackstone
setblock 484 28 458 minecraft:orange_concrete
fill 485 28 416 485 29 416 minecraft:orange_concrete
fill 487 28 452 488 28 452 minecraft:orange_concrete
fill 488 28 450 488 28 451 minecraft:orange_concrete
fill 488 28 453 488 28 454 minecraft:orange_concrete
fill 489 28 449 491 28 449 minecraft:orange_concrete
fill 489 28 455 491 28 455 minecraft:orange_concrete
fill 491 28 416 492 41 416 minecraft:blackstone
fill 491 28 450 492 28 450 minecraft:orange_concrete
fill 492 28 458 493 29 458 minecraft:orange_concrete
fill 493 28 416 494 29 416 minecraft:orange_concrete
fill 493 28 451 495 28 451 minecraft:orange_concrete
setblock 494 28 455 minecraft:orange_concrete
fill 494 28 458 495 41 458 minecraft:blackstone
fill 495 28 454 495 29 454 minecraft:orange_concrete
fill 501 28 458 501 29 458 minecraft:orange_concrete
setblock 502 28 416 minecraft:orange_concrete
fill 503 28 416 504 41 416 minecraft:blackstone
fill 503 28 458 503 41 458 minecraft:blackstone
fill 504 28 458 505 28 458 minecraft:orange_concrete
fill 505 28 416 506 29 416 minecraft:orange_concrete
fill 506 28 458 506 45 458 minecraft:blackstone
fill 511 28 416 512 45 416 minecraft:blackstone
fill 512 28 417 512 28 418 minecraft:orange_concrete
fill 512 28 419 512 41 419 minecraft:blackstone
fill 512 28 427 512 41 428 minecraft:blackstone
fill 512 28 429 512 29 430 minecraft:orange_concrete
fill 512 28 436 512 45 436 minecraft:blackstone
setblock 512 28 438 minecraft:orange_concrete
fill 512 28 439 512 41 440 minecraft:blackstone
fill 512 28 441 512 29 441 minecraft:orange_concrete
fill 512 28 447 512 41 448 minecraft:blackstone
fill 512 28 449 512 28 450 minecraft:orange_concrete
fill 512 28 458 512 29 458 minecraft:orange_concrete
fill 470 29 420 470 40 420 minecraft:blackstone
setblock 470 29 425 minecraft:orange_concrete
setblock 470 29 436 minecraft:orange_concrete
fill 470 29 440 470 40 440 minecraft:blackstone
fill 470 29 456 470 29 457 minecraft:orange_concrete
setblock 472 29 458 minecraft:orange_concrete
fill 473 29 458 473 40 458 minecraft:blackstone
fill 481 29 416 482 40 416 minecraft:blackstone
fill 484 29 458 484 40 458 minecraft:blackstone
setblock 486 29 416 minecraft:orange_concrete
fill 488 29 451 488 29 453 minecraft:orange_concrete
setblock 489 29 458 minecraft:orange_concrete
setblock 491 29 450 minecraft:orange_concrete
setblock 491 29 454 minecraft:orange_concrete
setblock 492 29 451 minecraft:orange_concrete
fill 492 29 452 492 30 452 minecraft:red_nether_bricks
setblock 492 29 453 minecraft:orange_concrete
setblock 493 29 454 minecraft:orange_concrete
setblock 494 29 451 minecraft:orange_concrete
setblock 497 29 416 minecraft:orange_concrete
setblock 500 29 458 minecraft:orange_concrete
fill 502 29 416 502 40 416 minecraft:blackstone
fill 504 29 458 505 40 458 minecraft:blackstone
fill 512 29 417 512 40 417 minecraft:blackstone
setblock 512 29 418 minecraft:orange_concrete
fill 512 29 421 512 29 422 minecraft:orange_concrete
fill 512 29 438 512 40 438 minecraft:blackstone
setblock 512 29 442 minecraft:orange_concrete
fill 512 29 449 512 40 449 minecraft:blackstone
setblock 512 29 450 minecraft:orange_concrete
setblock 512 29 453 minecraft:orange_concrete
fill 470 30 416 470 40 417 minecraft:blackstone
fill 470 30 422 470 45 422 minecraft:blackstone
setblock 470 30 423 minecraft:orange_concrete
fill 470 30 425 470 43 425 minecraft:blackstone
fill 470 30 426 470 30 427 minecraft:orange_concrete
fill 470 30 428 470 40 429 minecraft:blackstone
fill 470 30 434 470 30 435 minecraft:orange_concrete
fill 470 30 436 470 43 437 minecraft:blackstone
fill 470 30 446 470 30 447 minecraft:orange_concrete
fill 470 30 448 470 40 449 minecraft:blackstone
setblock 470 30 455 minecraft:orange_concrete
fill 470 30 456 470 43 457 minecraft:blackstone
setblock 470 30 458 minecraft:orange_concrete
fill 471 30 417 473 30 417 minecraft:red_nether_bricks
fill 471 30 419 471 30 421 minecraft:red_nether_bricks
fill 471 30 423 471 30 425 minecraft:red_nether_bricks
fill 471 30 427 471 30 429 minecraft:red_nether_bricks
fill 471 30 431 471 30 433 minecraft:red_nether_bricks
fill 471 30 435 471 30 437 minecraft:red_nether_bricks
fill 471 30 439 471 30 441 minecraft:red_nether_bricks
fill 471 30 443 471 30 445 minecraft:red_nether_bricks
fill 471 30 447 471 30 449 minecraft:red_nether_bricks
fill 471 30 451 471 30 453 minecraft:red_nether_bricks
fill 471 30 455 471 30 457 minecraft:red_nether_bricks
fill 472 30 458 472 40 458 minecraft:blackstone
fill 473 30 416 474 40 416 minecraft:blackstone
fill 473 30 457 475 30 457 minecraft:red_nether_bricks
fill 475 30 416 476 30 416 minecraft:orange_concrete
fill 475 30 417 477 30 417 minecraft:red_nether_bricks
fill 477 30 457 479 30 457 minecraft:red_nether_bricks
fill 478 30 458 479 30 458 minecraft:orange_concrete
fill 479 30 417 481 30 417 minecraft:red_nether_bricks
fill 480 30 458 481 43 458 minecraft:blackstone
fill 481 30 457 483 30 457 minecraft:red_nether_bricks
fill 483 30 417 485 30 417 minecraft:red_nether_bricks
setblock 484 30 416 minecraft:orange_concrete
fill 485 30 416 486 43 416 minecraft:blackstone
fill 485 30 457 487 30 457 minecraft:red_nether_bricks
fill 487 30 416 488 30 416 minecraft:orange_concrete
fill 487 30 417 489 30 417 minecraft:red_nether_bricks
fill 489 30 457 491 30 457 minecraft:red_nether_bricks
fill 489 30 458 489 43 458 minecraft:blackstone
fill 490 30 458 491 30 458 minecraft:orange_concrete
fill 491 30 417 493 30 417 minecraft:red_nether_bricks
fill 492 30 458 493 40 458 minecraft:blackstone
fill 493 30 416 494 40 416 minecraft:blackstone
fill 493 30 457 495 30 457 minecraft:red_nether_bricks
fill 495 30 416 496 30 416 minecraft:orange_concrete
fill 495 30 417 497 30 417 minecraft:red_nether_bricks
fill 497 30 416 497 43 416 minecraft:blackstone
fill 497 30 457 499 30 457 minecraft:red_nether_bricks
fill 498 30 458 499 30 458 minecraft:orange_concrete
fill 499 30 417 501 30 417 minecraft:red_nether_bricks
fill 500 30 458 501 43 458 minecraft:blackstone
fill 501 30 457 503 30 457 minecraft:red_nether_bricks
setblock 502 30 458 minecraft:orange_concrete
fill 503 30 417 505 30 417 minecraft:red_nether_bricks
fill 505 30 416 506 43 416 minecraft:blackstone
fill 505 30 457 507 30 457 minecraft:red_nether_bricks
fill 507 30 416 508 30 416 minecraft:orange_concrete
fill 507 30 417 509 30 417 minecraft:red_nether_bricks
fill 509 30 457 511 30 457 minecraft:red_nether_bricks
fill 510 30 458 511 30 458 minecraft:orange_concrete
fill 511 30 417 511 30 419 minecraft:red_nether_bricks
fill 511 30 421 511 30 423 minecraft:red_nether_bricks
fill 511 30 425 511 30 427 minecraft:red_nether_bricks
fill 511 30 429 511 30 431 minecraft:red_nether_bricks
fill 511 30 433 511 30 435 minecraft:red_nether_bricks
fill 511 30 437 511 30 439 minecraft:red_nether_bricks
fill 511 30 441 511 30 443 minecraft:red_nether_bricks
fill 511 30 445 511 30 447 minecraft:red_nether_bricks
fill 511 30 449 511 30 451 minecraft:red_nether_bricks
fill 511 30 453 511 30 455 minecraft:red_nether_bricks
fill 512 30 418 512 40 418 minecraft:blackstone
setblock 512 30 420 minecraft:orange_concrete
fill 512 30 421 512 43 422 minecraft:blackstone
setblock 512 30 423 minecraft:orange_concrete
fill 512 30 429 512 40 430 minecraft:blackstone
fill 512 30 431 512 30 432 minecraft:orange_concrete
fill 512 30 441 512 43 442 minecraft:blackstone
fill 512 30 443 512 30 444 minecraft:orange_concrete
fill 512 30 450 512 40 450 minecraft:blackstone
fill 512 30 451 512 30 452 minecraft:orange_concrete
fill 512 30 453 512 43 453 minecraft:blackstone
setblock 512 30 455 minecraft:orange_concrete
fill 512 30 458 512 43 458 minecraft:blackstone
fill 470 31 423 470 45 423 minecraft:blackstone
fill 470 31 426 470 41 427 minecraft:blackstone
fill 470 31 434 470 42 435 minecraft:blackstone
fill 470 31 446 470 41 447 minecraft:blackstone
fill 470 31 455 470 45 455 minecraft:blackstone
fill 470 31 458 470 41 458 minecraft:blackstone
fill 475 31 416 476 41 416 minecraft:blackstone
fill 478 31 458 479 42 458 minecraft:blackstone
fill 484 31 416 484 41 416 minecraft:blackstone
fill 487 31 416 488 42 416 minecraft:blackstone
fill 490 31 458 491 41 458 minecraft:blackstone
fill 495 31 416 496 41 416 minecraft:blackstone
fill 498 31 458 499 45 458 minecraft:blackstone
fill 502 31 458 502 41 458 minecraft:blackstone
fill 507 31 416 508 42 416 minecraft:blackstone
fill 510 31 458 511 42 458 minecraft:blackstone
fill 512 31 420 512 41 420 minecraft:blackstone
fill 512 31 423 512 45 423 minecraft:blackstone
fill 512 31 431 512 41 432 minecraft:blackstone
fill 512 31 443 512 42 444 minecraft:blackstone
fill 512 31 451 512 41 452 minecraft:blackstone
fill 512 31 455 512 45 455 minecraft:blackstone
setblock 473 32 419 minecraft:light[level=14]
setblock 473 32 427 minecraft:light[level=14]
setblock 473 32 435 minecraft:light[level=14]
setblock 473 32 443 minecraft:light[level=14]
setblock 473 32 451 minecraft:light[level=14]
setblock 481 32 419 minecraft:light[level=14]
setblock 481 32 427 minecraft:light[level=14]
setblock 481 32 435 minecraft:light[level=14]
setblock 481 32 443 minecraft:light[level=14]
setblock 481 32 451 minecraft:light[level=14]
setblock 489 32 419 minecraft:light[level=14]
setblock 489 32 427 minecraft:light[level=14]
setblock 489 32 435 minecraft:light[level=14]
setblock 489 32 443 minecraft:light[level=14]
setblock 489 32 451 minecraft:light[level=14]
setblock 497 32 419 minecraft:light[level=14]
setblock 497 32 427 minecraft:light[level=14]
setblock 497 32 435 minecraft:light[level=14]
setblock 497 32 443 minecraft:light[level=14]
setblock 497 32 451 minecraft:light[level=14]
setblock 505 32 419 minecraft:light[level=14]
setblock 505 32 427 minecraft:light[level=14]
setblock 505 32 435 minecraft:light[level=14]
setblock 505 32 443 minecraft:light[level=14]
setblock 505 32 451 minecraft:light[level=14]
fill 484 35 435 486 35 437 minecraft:redstone_block
fill 490 35 435 492 35 437 minecraft:redstone_block
fill 491 35 442 493 35 444 minecraft:redstone_block
fill 473 36 440 477 37 440 minecraft:red_nether_bricks
fill 474 36 435 477 37 439 minecraft:red_nether_bricks
fill 474 36 441 477 37 445 minecraft:red_nether_bricks
fill 475 36 433 480 37 434 minecraft:red_nether_bricks
fill 475 36 446 477 37 447 minecraft:red_nether_bricks
fill 476 36 431 484 37 432 minecraft:red_nether_bricks
fill 476 36 448 478 37 449 minecraft:red_nether_bricks
fill 477 36 430 497 37 430 minecraft:red_nether_bricks
fill 477 36 450 480 37 450 minecraft:red_nether_bricks
fill 478 36 429 496 37 429 minecraft:red_nether_bricks
fill 478 36 435 478 37 437 minecraft:red_nether_bricks
fill 478 36 438 481 37 446 minecraft:magma_block
fill 478 36 447 478 37 447 minecraft:red_nether_bricks
fill 478 36 451 481 37 451 minecraft:red_nether_bricks
fill 479 36 428 495 37 428 minecraft:red_nether_bricks
fill 479 36 435 479 37 435 minecraft:red_nether_bricks
fill 479 36 436 483 36 437 minecraft:magma_block
fill 479 36 447 483 37 448 minecraft:magma_block
fill 479 36 449 479 37 449 minecraft:red_nether_bricks
fill 479 36 452 483 37 452 minecraft:red_nether_bricks
fill 480 36 435 483 36 435 minecraft:magma_block
fill 480 36 449 487 37 449 minecraft:magma_block
fill 481 36 427 493 37 427 minecraft:red_nether_bricks
fill 481 36 433 482 37 433 minecraft:red_nether_bricks
fill 481 36 434 491 36 434 minecraft:magma_block
fill 481 36 450 499 37 450 minecraft:magma_block
fill 481 36 453 485 37 453 minecraft:red_nether_bricks
fill 482 36 438 482 37 439 minecraft:magma_block
fill 482 36 440 484 37 444 minecraft:red_nether_bricks
fill 482 36 445 482 37 446 minecraft:magma_block
fill 482 36 451 498 37 451 minecraft:magma_block
fill 483 36 426 491 37 426 minecraft:red_nether_bricks
fill 483 36 433 490 37 433 minecraft:magma_block
fill 483 36 438 484 36 439 minecraft:red_nether_bricks
fill 483 36 445 497 36 446 minecraft:red_nether_bricks
fill 483 36 454 493 37 454 minecraft:red_nether_bricks
fill 484 36 447 496 37 447 minecraft:red_nether_bricks
fill 484 36 448 484 37 448 minecraft:magma_block
fill 484 36 452 496 37 452 minecraft:magma_block
fill 485 36 431 497 37 431 minecraft:red_nether_bricks
fill 485 36 432 487 37 432 minecraft:magma_block
setblock 485 36 438 minecraft:red_nether_bricks
fill 485 36 439 486 36 441 minecraft:obsidian
fill 485 36 442 485 37 444 minecraft:red_nether_bricks
fill 485 36 448 494 37 448 minecraft:red_nether_bricks
fill 486 36 438 490 36 438 minecraft:obsidian
fill 486 36 442 490 36 442 minecraft:obsidian
fill 486 36 443 486 37 444 minecraft:red_nether_bricks
fill 486 36 453 494 37 453 minecraft:magma_block
fill 487 36 435 489 36 436 minecraft:magma_block
fill 487 36 437 489 36 437 minecraft:obsidian
fill 487 36 443 489 37 443 minecraft:obsidian
fill 487 36 444 490 36 444 minecraft:red_nether_bricks
fill 488 36 425 488 37 425 minecraft:magma_block
fill 488 36 432 498 37 432 minecraft:red_nether_bricks
fill 488 36 449 492 37 449 minecraft:red_nether_bricks
fill 488 36 455 488 37 455 minecraft:red_nether_bricks
fill 490 36 439 491 36 441 minecraft:obsidian
setblock 490 36 443 minecraft:red_nether_bricks
fill 491 36 433 499 37 433 minecraft:red_nether_bricks
fill 491 36 438 493 36 438 minecraft:magma_block
fill 492 36 426 493 37 426 minecraft:magma_block
fill 492 36 434 499 36 434 minecraft:red_nether_bricks
fill 492 36 439 492 36 441 minecraft:magma_block
fill 493 36 435 499 36 436 minecraft:red_nether_bricks
setblock 493 36 437 minecraft:magma_block
fill 493 36 439 493 37 440 minecraft:magma_block
fill 493 36 441 499 36 441 minecraft:red_nether_bricks
fill 493 36 449 500 37 449 minecraft:magma_block
fill 494 36 427 495 37 427 minecraft:magma_block
fill 494 36 437 500 37 440 minecraft:red_nether_bricks
fill 494 36 442 498 36 444 minecraft:red_nether_bricks
fill 495 36 448 500 37 448 minecraft:magma_block
fill 495 36 453 495 37 453 minecraft:red_nether_bricks
fill 496 36 428 497 37 428 minecraft:magma_block
fill 497 36 429 498 37 429 minecraft:magma_block
fill 497 36 447 501 37 447 minecraft:magma_block
fill 497 36 452 497 37 452 minecraft:red_nether_bricks
fill 498 36 430 499 37 431 minecraft:magma_block
fill 498 36 445 498 37 445 minecraft:red_nether_bricks
fill 498 36 446 501 37 446 minecraft:magma_block
fill 499 36 432 500 37 432 minecraft:magma_block
fill 499 36 442 499 37 443 minecraft:red_nether_bricks
fill 499 36 444 502 37 445 minecraft:magma_block
fill 500 36 431 500 37 431 minecraft:magma_block
fill 500 36 433 501 37 435 minecraft:magma_block
fill 500 36 436 500 37 436 minecraft:red_nether_bricks
fill 500 36 441 502 37 443 minecraft:magma_block
fill 501 36 436 502 37 440 minecraft:magma_block
fill 502 36 435 502 37 435 minecraft:magma_block
fill 503 36 440 503 37 440 minecraft:magma_block
fill 471 37 417 472 37 457 minecraft:blackstone
fill 473 37 417 473 37 439 minecraft:blackstone
fill 473 37 441 473 37 457 minecraft:blackstone
fill 474 37 417 474 37 434 minecraft:blackstone
fill 474 37 446 474 37 457 minecraft:blackstone
fill 475 37 417 475 37 432 minecraft:blackstone
fill 475 37 448 475 37 457 minecraft:blackstone
fill 476 37 417 476 37 430 minecraft:blackstone
fill 476 37 450 476 37 457 minecraft:blackstone
fill 477 37 417 477 37 429 minecraft:blackstone
fill 477 37 451 477 37 457 minecraft:blackstone
fill 478 37 417 478 37 428 minecraft:blackstone
fill 478 37 452 478 37 457 minecraft:blackstone
fill 479 37 417 480 37 427 minecraft:blackstone
fill 479 37 436 482 37 437 minecraft:magma_block
fill 479 37 453 480 37 457 minecraft:blackstone
fill 480 37 435 482 37 435 minecraft:magma_block
fill 481 37 417 482 37 426 minecraft:blackstone
fill 481 37 434 482 37 434 minecraft:magma_block
fill 481 37 454 482 37 457 minecraft:blackstone
fill 483 37 417 487 37 425 minecraft:blackstone
fill 483 37 434 483 37 438 minecraft:shroomlight
fill 483 37 439 484 37 439 minecraft:red_nether_bricks
fill 483 37 445 489 37 446 minecraft:red_nether_bricks
fill 483 37 455 487 37 457 minecraft:blackstone
fill 484 37 434 487 37 434 minecraft:shroomlight
fill 484 37 435 486 37 437 minecraft:blackstone
fill 484 37 438 493 37 438 minecraft:shroomlight
fill 485 37 439 485 37 441 minecraft:obsidian
fill 486 37 439 486 37 442 minecraft:shroomlight
fill 487 37 435 487 37 437 minecraft:shroomlight
fill 487 37 442 490 37 442 minecraft:shroomlight
fill 487 37 444 489 37 444 minecraft:red_nether_bricks
fill 488 37 417 511 37 424 minecraft:blackstone
fill 488 37 434 488 37 436 minecraft:magma_block
setblock 488 37 437 minecraft:obsidian
fill 488 37 456 511 37 457 minecraft:blackstone
fill 489 37 425 511 37 425 minecraft:blackstone
fill 489 37 434 489 37 437 minecraft:shroomlight
fill 489 37 455 511 37 455 minecraft:blackstone
fill 490 37 434 493 37 434 minecraft:shroomlight
fill 490 37 435 492 37 437 minecraft:blackstone
fill 490 37 439 490 37 441 minecraft:shroomlight
fill 490 37 443 490 37 445 minecraft:shroomlight
fill 490 37 446 497 37 446 minecraft:red_nether_bricks
fill 491 37 439 491 37 440 minecraft:obsidian
fill 491 37 441 494 37 441 minecraft:shroomlight
fill 491 37 442 493 37 444 minecraft:blackstone
fill 491 37 445 494 37 445 minecraft:shroomlight
fill 492 37 439 492 37 440 minecraft:magma_block
fill 493 37 435 493 37 437 minecraft:shroomlight
fill 494 37 426 511 37 426 minecraft:blackstone
fill 494 37 434 499 37 436 minecraft:red_nether_bricks
fill 494 37 442 494 37 444 minecraft:shroomlight
fill 494 37 454 511 37 454 minecraft:blackstone
fill 495 37 441 497 37 445 minecraft:red_nether_bricks
fill 496 37 427 511 37 427 minecraft:blackstone
fill 496 37 453 511 37 453 minecraft:blackstone
fill 498 37 428 511 37 428 minecraft:blackstone
fill 498 37 441 498 37 444 minecraft:red_nether_bricks
fill 498 37 452 511 37 452 minecraft:blackstone
fill 499 37 429 511 37 429 minecraft:blackstone
setblock 499 37 441 minecraft:red_nether_bricks
fill 499 37 451 511 37 451 minecraft:blackstone
fill 500 37 430 511 37 430 minecraft:blackstone
fill 500 37 450 511 37 450 minecraft:blackstone
fill 501 37 431 511 37 432 minecraft:blackstone
fill 501 37 448 511 37 449 minecraft:blackstone
fill 502 37 433 511 37 434 minecraft:blackstone
fill 502 37 446 511 37 447 minecraft:blackstone
fill 503 37 435 511 37 439 minecraft:blackstone
fill 503 37 441 511 37 445 minecraft:blackstone
fill 504 37 440 511 37 440 minecraft:blackstone
setblock 473 40 419 minecraft:light[level=14]
setblock 473 40 427 minecraft:light[level=14]
setblock 473 40 435 minecraft:light[level=14]
setblock 473 40 443 minecraft:light[level=14]
setblock 473 40 451 minecraft:light[level=14]
setblock 481 40 419 minecraft:light[level=14]
setblock 481 40 427 minecraft:light[level=14]
setblock 481 40 435 minecraft:light[level=14]
setblock 481 40 443 minecraft:light[level=14]
setblock 481 40 451 minecraft:light[level=14]
setblock 489 40 419 minecraft:light[level=14]
setblock 489 40 427 minecraft:light[level=14]
setblock 489 40 435 minecraft:light[level=14]
setblock 489 40 443 minecraft:light[level=14]
setblock 489 40 451 minecraft:light[level=14]
setblock 497 40 419 minecraft:light[level=14]
setblock 497 40 427 minecraft:light[level=14]
setblock 497 40 435 minecraft:light[level=14]
setblock 497 40 443 minecraft:light[level=14]
setblock 497 40 451 minecraft:light[level=14]
setblock 505 40 419 minecraft:light[level=14]
setblock 505 40 427 minecraft:light[level=14]
setblock 505 40 435 minecraft:light[level=14]
setblock 505 40 443 minecraft:light[level=14]
setblock 505 40 451 minecraft:light[level=14]
fill 470 41 416 470 43 416 minecraft:blackstone
setblock 470 41 417 minecraft:orange_concrete
fill 470 41 420 470 41 421 minecraft:orange_concrete
fill 470 41 428 470 41 429 minecraft:orange_concrete
fill 470 41 440 470 41 441 minecraft:orange_concrete
fill 470 41 448 470 43 448 minecraft:blackstone
setblock 470 41 449 minecraft:orange_concrete
setblock 470 41 452 minecraft:orange_concrete
fill 470 41 453 470 44 453 minecraft:blackstone
fill 472 41 458 473 41 458 minecraft:orange_concrete
setblock 473 41 416 minecraft:orange_concrete
fill 474 41 416 474 43 416 minecraft:blackstone
fill 481 41 416 482 41 416 minecraft:orange_concrete
fill 484 41 458 485 41 458 minecraft:orange_concrete
fill 489 41 416 489 44 416 minecraft:blackstone
setblock 490 41 416 minecraft:orange_concrete
fill 492 41 458 493 41 458 minecraft:orange_concrete
fill 493 41 416 494 41 416 minecraft:orange_concrete
setblock 496 41 458 minecraft:orange_concrete
fill 497 41 458 497 44 458 minecraft:blackstone
fill 501 41 416 502 41 416 minecraft:orange_concrete
fill 504 41 458 505 41 458 minecraft:orange_concrete
fill 512 41 417 512 41 418 minecraft:orange_concrete
fill 512 41 425 512 44 425 minecraft:blackstone
setblock 512 41 426 minecraft:orange_concrete
setblock 512 41 429 minecraft:orange_concrete
fill 512 41 430 512 43 430 minecraft:blackstone
fill 512 41 437 512 41 438 minecraft:orange_concrete
fill 512 41 449 512 41 450 minecraft:orange_concrete
setblock 512 41 457 minecraft:orange_concrete
fill 470 42 417 470 47 417 minecraft:blackstone
fill 470 42 418 470 42 419 minecraft:orange_concrete
fill 470 42 420 470 47 421 minecraft:blackstone
fill 470 42 426 470 43 427 minecraft:orange_concrete
fill 470 42 428 470 47 429 minecraft:blackstone
setblock 470 42 430 minecraft:orange_concrete
fill 470 42 431 470 45 431 minecraft:blackstone
fill 470 42 438 470 43 439 minecraft:orange_concrete
fill 470 42 440 470 47 441 minecraft:blackstone
setblock 470 42 446 minecraft:blackstone
fill 470 42 447 470 43 447 minecraft:orange_concrete
fill 470 42 449 470 47 449 minecraft:blackstone
fill 470 42 450 470 42 451 minecraft:orange_concrete
fill 470 42 452 470 47 452 minecraft:blackstone
fill 470 42 458 471 43 458 minecraft:orange_concrete
fill 471 42 416 472 42 416 minecraft:orange_concrete
fill 471 42 417 473 42 417 minecraft:red_nether_bricks
fill 471 42 419 471 42 421 minecraft:red_nether_bricks
fill 471 42 423 471 42 425 minecraft:red_nether_bricks
fill 471 42 427 471 42 429 minecraft:red_nether_bricks
fill 471 42 431 471 42 433 minecraft:red_nether_bricks
fill 471 42 435 471 42 437 minecraft:red_nether_bricks
fill 471 42 439 471 42 441 minecraft:red_nether_bricks
fill 471 42 443 471 42 445 minecraft:red_nether_bricks
fill 471 42 447 471 42 449 minecraft:red_nether_bricks
fill 471 42 451 471 42 453 minecraft:red_nether_bricks
fill 471 42 455 471 42 457 minecraft:red_nether_bricks
fill 472 42 458 473 47 458 minecraft:blackstone
fill 473 42 416 473 47 416 minecraft:blackstone
fill 473 42 457 475 42 457 minecraft:red_nether_bricks
fill 475 42 416 475 43 416 minecraft:orange_concrete
fill 475 42 417 477 42 417 minecraft:red_nether_bricks
setblock 476 42 416 minecraft:blackstone
fill 477 42 457 479 42 457 minecraft:red_nether_bricks
fill 479 42 417 481 42 417 minecraft:red_nether_bricks
fill 481 42 416 482 47 416 minecraft:blackstone
fill 481 42 457 483 42 457 minecraft:red_nether_bricks
fill 482 42 458 483 42 458 minecraft:orange_concrete
fill 483 42 416 484 43 416 minecraft:orange_concrete
fill 483 42 417 485 42 417 minecraft:red_nether_bricks
fill 484 42 458 485 47 458 minecraft:blackstone
fill 485 42 457 487 42 457 minecraft:red_nether_bricks
fill 487 42 417 489 42 417 minecraft:red_nether_bricks
fill 489 42 457 491 42 457 minecraft:red_nether_bricks
fill 490 42 416 491 44 416 minecraft:blackstone
setblock 490 42 458 minecraft:blackstone
fill 491 42 417 493 42 417 minecraft:red_nether_bricks
fill 491 42 458 491 43 458 minecraft:orange_concrete
setblock 492 42 416 minecraft:orange_concrete
fill 492 42 458 493 47 458 minecraft:blackstone
fill 493 42 416 494 47 416 minecraft:blackstone
fill 493 42 457 495 42 457 minecraft:red_nether_bricks
setblock 494 42 458 minecraft:orange_concrete
fill 495 42 416 495 43 416 minecraft:orange_concrete
fill 495 42 417 497 42 417 minecraft:red_nether_bricks
fill 495 42 458 496 45 458 minecraft:blackstone
setblock 496 42 416 minecraft:blackstone
fill 497 42 457 499 42 457 minecraft:red_nether_bricks
fill 499 42 417 501 42 417 minecraft:red_nether_bricks
fill 501 42 416 502 47 416 minecraft:blackstone
fill 501 42 457 503 42 457 minecraft:red_nether_bricks
fill 502 42 458 503 43 458 minecraft:orange_concrete
fill 503 42 416 504 42 416 minecraft:orange_concrete
fill 503 42 417 505 42 417 minecraft:red_nether_bricks
fill 504 42 458 505 47 458 minecraft:blackstone
fill 505 42 457 507 42 457 minecraft:red_nether_bricks
fill 507 42 417 509 42 417 minecraft:red_nether_bricks
fill 509 42 457 511 42 457 minecraft:red_nether_bricks
fill 511 42 417 511 42 419 minecraft:red_nether_bricks
fill 511 42 421 511 42 423 minecraft:red_nether_bricks
fill 511 42 425 511 42 427 minecraft:red_nether_bricks
fill 511 42 429 511 42 431 minecraft:red_nether_bricks
fill 511 42 433 511 42 435 minecraft:red_nether_bricks
fill 511 42 437 511 42 439 minecraft:red_nether_bricks
fill 511 42 441 511 42 443 minecraft:red_nether_bricks
fill 511 42 445 511 42 447 minecraft:red_nether_bricks
fill 511 42 449 511 42 451 minecraft:red_nether_bricks
fill 511 42 453 511 42 455 minecraft:red_nether_bricks
fill 512 42 417 512 47 418 minecraft:blackstone
fill 512 42 419 512 43 420 minecraft:orange_concrete
fill 512 42 426 512 47 426 minecraft:blackstone
fill 512 42 427 512 42 428 minecraft:orange_concrete
fill 512 42 429 512 47 429 minecraft:blackstone
fill 512 42 431 512 43 431 minecraft:orange_concrete
setblock 512 42 432 minecraft:blackstone
fill 512 42 437 512 47 438 minecraft:blackstone
fill 512 42 439 512 43 440 minecraft:orange_concrete
fill 512 42 447 512 45 447 minecraft:blackstone
setblock 512 42 448 minecraft:orange_concrete
fill 512 42 449 512 47 450 minecraft:blackstone
fill 512 42 451 512 43 452 minecraft:orange_concrete
fill 512 42 457 512 47 457 minecraft:blackstone
setblock 470 43 418 minecraft:orange_concrete
fill 470 43 419 470 46 419 minecraft:blackstone
fill 470 43 430 470 46 430 minecraft:blackstone
fill 470 43 434 470 45 434 minecraft:blackstone
setblock 470 43 435 minecraft:orange_concrete
setblock 470 43 446 minecraft:orange_concrete
fill 470 43 450 470 46 451 minecraft:blackstone
fill 471 43 416 471 46 416 minecraft:blackstone
setblock 472 43 416 minecraft:orange_concrete
setblock 476 43 416 minecraft:orange_concrete
fill 478 43 458 478 45 458 minecraft:blackstone
setblock 479 43 458 minecraft:orange_concrete
setblock 482 43 458 minecraft:orange_concrete
fill 483 43 458 483 46 458 minecraft:blackstone
setblock 487 43 416 minecraft:orange_concrete
fill 488 43 416 488 45 416 minecraft:blackstone
setblock 490 43 458 minecraft:orange_concrete
fill 492 43 416 492 46 416 minecraft:blackstone
fill 494 43 458 494 46 458 minecraft:blackstone
setblock 496 43 416 minecraft:orange_concrete
fill 503 43 416 503 46 416 minecraft:blackstone
setblock 504 43 416 minecraft:orange_concrete
setblock 507 43 416 minecraft:orange_concrete
fill 508 43 416 508 45 416 minecraft:blackstone
fill 510 43 458 511 43 458 minecraft:orange_concrete
fill 512 43 427 512 46 428 minecraft:blackstone
setblock 512 43 432 minecraft:orange_concrete
setblock 512 43 443 minecraft:orange_concrete
fill 512 43 444 512 45 444 minecraft:blackstone
fill 512 43 448 512 46 448 minecraft:blackstone
setblock 470 44 416 minecraft:orange_concrete
fill 470 44 418 470 49 418 minecraft:blackstone
fill 470 44 424 470 45 425 minecraft:orange_concrete
fill 470 44 426 470 49 427 minecraft:blackstone
fill 470 44 435 470 49 435 minecraft:blackstone
fill 470 44 436 470 44 437 minecraft:orange_concrete
fill 470 44 438 470 49 439 minecraft:blackstone
fill 470 44 444 470 45 445 minecraft:orange_concrete
fill 470 44 446 470 49 447 minecraft:blackstone
setblock 470 44 448 minecraft:orange_concrete
fill 470 44 456 470 45 457 minecraft:orange_concrete
fill 470 44 458 471 49 458 minecraft:blackstone
fill 472 44 416 472 46 416 minecraft:blackstone
setblock 474 44 416 minecraft:orange_concrete
fill 475 44 416 476 49 416 minecraft:blackstone
setblock 476 44 458 minecraft:blackstone
fill 477 44 416 478 45 416 minecraft:orange_concrete
fill 477 44 458 477 45 458 minecraft:orange_concrete
fill 479 44 458 479 49 458 minecraft:blackstone
fill 480 44 458 481 44 458 minecraft:orange_concrete
fill 482 44 458 482 49 458 minecraft:blackstone
fill 483 44 416 484 49 416 minecraft:blackstone
fill 485 44 416 486 44 416 minecraft:orange_concrete
fill 487 44 416 487 45 416 minecraft:blackstone
fill 488 44 458 489 45 458 minecraft:orange_concrete
fill 490 44 458 491 49 458 minecraft:blackstone
fill 495 44 416 496 49 416 minecraft:blackstone
fill 497 44 416 498 45 416 minecraft:orange_concrete
fill 500 44 458 501 44 458 minecraft:orange_concrete
fill 502 44 458 503 49 458 minecraft:blackstone
fill 504 44 416 504 49 416 minecraft:blackstone
fill 505 44 416 506 44 416 minecraft:orange_concrete
fill 507 44 416 507 49 416 minecraft:blackstone
setblock 508 44 458 minecraft:blackstone
fill 509 44 416 509 45 416 minecraft:orange_concrete
fill 509 44 458 509 45 458 minecraft:orange_concrete
setblock 510 44 416 minecraft:blackstone
fill 510 44 458 511 49 458 minecraft:blackstone
fill 512 44 419 512 49 420 minecraft:blackstone
fill 512 44 421 512 45 422 minecraft:orange_concrete
setblock 512 44 430 minecraft:orange_concrete
fill 512 44 431 512 49 432 minecraft:blackstone
fill 512 44 433 512 45 434 minecraft:orange_concrete
fill 512 44 439 512 49 440 minecraft:blackstone
fill 512 44 441 512 44 442 minecraft:orange_concrete
fill 512 44 443 512 49 443 minecraft:blackstone
fill 512 44 451 512 49 452 minecraft:blackstone
fill 512 44 453 512 45 454 minecraft:orange_concrete
setblock 512 44 458 minecraft:orange_concrete
fill 470 45 416 470 48 416 minecraft:blackstone
fill 470 45 432 470 45 433 minecraft:orange_concrete
setblock 470 45 436 minecraft:orange_concrete
fill 470 45 437 470 48 437 minecraft:blackstone
fill 470 45 448 470 48 448 minecraft:blackstone
setblock 470 45 453 minecraft:orange_concrete
fill 474 45 416 474 48 416 minecraft:blackstone
setblock 476 45 458 minecraft:orange_concrete
fill 480 45 458 481 48 458 minecraft:blackstone
fill 485 45 416 485 48 416 minecraft:blackstone
setblock 486 45 416 minecraft:orange_concrete
fill 489 45 416 490 45 416 minecraft:orange_concrete
setblock 491 45 416 minecraft:blackstone
fill 493 45 418 494 46 419 minecraft:magma_block
setblock 497 45 458 minecraft:orange_concrete
setblock 500 45 458 minecraft:orange_concrete
fill 501 45 458 501 48 458 minecraft:blackstone
fill 505 45 416 506 48 416 minecraft:blackstone
setblock 508 45 458 minecraft:orange_concrete
setblock 510 45 416 minecraft:orange_concrete
setblock 512 45 425 minecraft:orange_concrete
fill 512 45 430 512 48 430 minecraft:blackstone
fill 512 45 441 512 48 441 minecraft:blackstone
setblock 512 45 442 minecraft:orange_concrete
fill 512 45 445 512 45 446 minecraft:orange_concrete
fill 512 45 458 512 48 458 minecraft:blackstone
fill 470 46 422 470 46 423 minecraft:orange_concrete
fill 470 46 424 470 51 425 minecraft:blackstone
fill 470 46 431 470 47 431 minecraft:orange_concrete
fill 470 46 432 470 51 433 minecraft:blackstone
setblock 470 46 434 minecraft:orange_concrete
fill 470 46 436 470 51 436 minecraft:blackstone
fill 470 46 442 470 47 443 minecraft:orange_concrete
fill 470 46 444 470 51 445 minecraft:blackstone
fill 470 46 453 470 51 453 minecraft:blackstone
fill 470 46 454 470 46 455 minecraft:orange_concrete
fill 470 46 456 470 51 457 minecraft:blackstone
fill 474 46 458 475 47 458 minecraft:orange_concrete
fill 476 46 458 477 51 458 minecraft:blackstone
fill 477 46 416 478 51 416 minecraft:blackstone
setblock 478 46 458 minecraft:orange_concrete
fill 479 46 416 480 47 416 minecraft:orange_concrete
fill 486 46 416 486 51 416 minecraft:blackstone
fill 486 46 458 487 47 458 minecraft:orange_concrete
fill 487 46 416 488 46 416 minecraft:orange_concrete
fill 488 46 458 489 51 458 minecraft:blackstone
fill 489 46 416 490 47 416 minecraft:blackstone
fill 491 46 416 491 47 416 minecraft:orange_concrete
fill 495 46 458 495 47 458 minecraft:orange_concrete
fill 496 46 458 497 47 458 minecraft:blackstone
fill 497 46 416 498 51 416 minecraft:blackstone
fill 498 46 458 499 46 458 minecraft:orange_concrete
fill 499 46 416 500 47 416 minecraft:orange_concrete
fill 500 46 458 500 51 458 minecraft:blackstone
fill 506 46 458 507 47 458 minecraft:orange_concrete
setblock 508 46 416 minecraft:orange_concrete
fill 508 46 458 509 51 458 minecraft:blackstone
fill 509 46 416 510 51 416 minecraft:blackstone
fill 511 46 416 512 47 416 minecraft:orange_concrete
fill 512 46 421 512 51 422 minecraft:blackstone
fill 512 46 423 512 46 424 minecraft:orange_concrete
fill 512 46 425 512 51 425 minecraft:blackstone
fill 512 46 433 512 51 434 minecraft:blackstone
fill 512 46 435 512 47 436 minecraft:orange_concrete
fill 512 46 442 512 51 442 minecraft:blackstone
setblock 512 46 444 minecraft:orange_concrete
fill 512 46 445 512 51 446 minecraft:blackstone
fill 512 46 447 512 47 447 minecraft:orange_concrete
fill 512 46 453 512 51 454 minecraft:blackstone
fill 512 46 455 512 46 456 minecraft:orange_concrete
setblock 470 47 419 minecraft:orange_concrete
setblock 470 47 422 minecraft:orange_concrete
fill 470 47 423 470 50 423 minecraft:blackstone
setblock 470 47 430 minecraft:orange_concrete
fill 470 47 434 470 50 434 minecraft:blackstone
fill 470 47 450 470 47 451 minecraft:orange_concrete
setblock 470 47 454 minecraft:orange_concrete
fill 470 47 455 470 50 455 minecraft:blackstone
fill 471 47 416 472 47 416 minecraft:orange_concrete
fill 478 47 458 478 50 458 minecraft:blackstone
setblock 483 47 458 minecraft:orange_concrete
fill 487 47 416 488 49 416 minecraft:blackstone
setblock 492 47 416 minecraft:orange_concrete
setblock 494 47 458 minecraft:orange_concrete
fill 498 47 458 499 50 458 minecraft:blackstone
setblock 503 47 416 minecraft:orange_concrete
fill 508 47 416 508 50 416 minecraft:blackstone
fill 512 47 423 512 50 423 minecraft:blackstone
setblock 512 47 424 minecraft:orange_concrete
fill 512 47 427 512 47 428 minecraft:orange_concrete
fill 512 47 444 512 50 444 minecraft:blackstone
setblock 512 47 448 minecraft:orange_concrete
fill 512 47 455 512 50 455 minecraft:blackstone
setblock 512 47 456 minecraft:orange_concrete
fill 470 48 417 470 49 417 minecraft:orange_concrete
fill 470 48 419 470 53 419 minecraft:blackstone
fill 470 48 420 470 48 421 minecraft:orange_concrete
fill 470 48 422 470 53 422 minecraft:blackstone
fill 470 48 428 470 49 429 minecraft:orange_concrete
fill 470 48 430 470 53 431 minecraft:blackstone
fill 470 48 440 470 48 441 minecraft:orange_concrete
fill 470 48 442 470 53 443 minecraft:blackstone
fill 470 48 449 470 49 449 minecraft:orange_concrete
fill 470 48 450 470 53 451 minecraft:blackstone
setblock 470 48 452 minecraft:orange_concrete
fill 470 48 454 470 53 454 minecraft:blackstone
fill 471 48 416 472 49 416 minecraft:blackstone
fill 471 48 417 473 48 417 minecraft:red_nether_bricks
fill 471 48 419 471 48 421 minecraft:red_nether_bricks
fill 471 48 423 471 48 425 minecraft:red_nether_bricks
fill 471 48 427 471 48 429 minecraft:red_nether_bricks
fill 471 48 431 471 48 433 minecraft:red_nether_bricks
fill 471 48 435 471 48 437 minecraft:red_nether_bricks
fill 471 48 439 471 48 441 minecraft:red_nether_bricks
fill 471 48 443 471 48 445 minecraft:red_nether_bricks
fill 471 48 447 471 48 449 minecraft:red_nether_bricks
fill 471 48 451 471 48 453 minecraft:red_nether_bricks
fill 471 48 455 471 48 457 minecraft:red_nether_bricks
fill 472 48 458 473 49 458 minecraft:orange_concrete
fill 473 48 416 473 49 416 minecraft:orange_concrete
setblock 473 48 419 minecraft:light[level=14]
setblock 473 48 427 minecraft:light[level=14]
setblock 473 48 435 minecraft:light[level=14]
setblock 473 48 443 minecraft:light[level=14]
setblock 473 48 451 minecraft:light[level=14]
fill 473 48 457 475 48 457 minecraft:red_nether_bricks
fill 474 48 458 475 53 458 minecraft:blackstone
fill 475 48 417 477 48 417 minecraft:red_nether_bricks
fill 477 48 457 479 48 457 minecraft:red_nether_bricks
fill 479 48 416 480 53 416 minecraft:blackstone
fill 479 48 417 481 48 417 minecraft:red_nether_bricks
fill 481 48 416 482 49 416 minecraft:orange_concrete
setblock 481 48 419 minecraft:light[level=14]
setblock 481 48 427 minecraft:light[level=14]
setblock 481 48 435 minecraft:light[level=14]
setblock 481 48 443 minecraft:light[level=14]
setblock 481 48 451 minecraft:light[level=14]
fill 481 48 457 483 48 457 minecraft:red_nether_bricks
fill 483 48 417 485 48 417 minecraft:red_nether_bricks
fill 483 48 458 483 53 458 minecraft:blackstone
fill 484 48 458 485 48 458 minecraft:orange_concrete
fill 485 48 457 487 48 457 minecraft:red_nether_bricks
fill 486 48 458 487 53 458 minecraft:blackstone
fill 487 48 417 489 48 417 minecraft:red_nether_bricks
fill 489 48 416 489 51 416 minecraft:blackstone
setblock 489 48 419 minecraft:light[level=14]
setblock 489 48 427 minecraft:light[level=14]
setblock 489 48 435 minecraft:light[level=14]
setblock 489 48 443 minecraft:light[level=14]
setblock 489 48 451 minecraft:light[level=14]
fill 489 48 457 491 48 457 minecraft:red_nether_bricks
setblock 490 48 416 minecraft:orange_concrete
fill 491 48 416 492 53 416 minecraft:blackstone
fill 491 48 417 493 48 417 minecraft:red_nether_bricks
fill 492 48 458 493 49 458 minecraft:orange_concrete
fill 493 48 416 494 49 416 minecraft:orange_concrete
fill 493 48 457 495 48 457 minecraft:red_nether_bricks
fill 494 48 458 495 53 458 minecraft:blackstone
fill 495 48 417 497 48 417 minecraft:red_nether_bricks
setblock 496 48 458 minecraft:orange_concrete
setblock 497 48 419 minecraft:light[level=14]
setblock 497 48 427 minecraft:light[level=14]
setblock 497 48 435 minecraft:light[level=14]
setblock 497 48 443 minecraft:light[level=14]
setblock 497 48 451 minecraft:light[level=14]
fill 497 48 457 499 48 457 minecraft:red_nether_bricks
fill 497 48 458 497 51 458 minecraft:blackstone
fill 499 48 416 500 50 416 minecraft:blackstone
fill 499 48 417 501 48 417 minecraft:red_nether_bricks
fill 501 48 416 502 48 416 minecraft:orange_concrete
fill 501 48 457 503 48 457 minecraft:red_nether_bricks
fill 503 48 416 503 53 416 minecraft:blackstone
fill 503 48 417 505 48 417 minecraft:red_nether_bricks
fill 504 48 458 505 49 458 minecraft:orange_concrete
setblock 505 48 419 minecraft:light[level=14]
setblock 505 48 427 minecraft:light[level=14]
setblock 505 48 435 minecraft:light[level=14]
setblock 505 48 443 minecraft:light[level=14]
setblock 505 48 451 minecraft:light[level=14]
fill 505 48 457 507 48 457 minecraft:red_nether_bricks
fill 506 48 458 507 53 458 minecraft:blackstone
fill 507 48 417 509 48 417 minecraft:red_nether_bricks
fill 509 48 457 511 48 457 minecraft:red_nether_bricks
fill 511 48 416 512 53 416 minecraft:blackstone
fill 511 48 417 511 48 419 minecraft:red_nether_bricks
fill 511 48 421 511 48 423 minecraft:red_nether_bricks
fill 511 48 425 511 48 427 minecraft:red_nether_bricks
fill 511 48 429 511 48 431 minecraft:red_nether_bricks
fill 511 48 433 511 48 435 minecraft:red_nether_bricks
fill 511 48 437 511 48 439 minecraft:red_nether_bricks
fill 511 48 441 511 48 443 minecraft:red_nether_bricks
fill 511 48 445 511 48 447 minecraft:red_nether_bricks
fill 511 48 449 511 48 451 minecraft:red_nether_bricks
fill 511 48 453 511 48 455 minecraft:red_nether_bricks
fill 512 48 417 512 49 418 minecraft:orange_concrete
fill 512 48 424 512 53 424 minecraft:blackstone
setblock 512 48 426 minecraft:orange_concrete
fill 512 48 427 512 53 428 minecraft:blackstone
fill 512 48 429 512 49 429 minecraft:orange_concrete
fill 512 48 435 512 53 436 minecraft:blackstone
fill 512 48 437 512 48 438 minecraft:orange_concrete
fill 512 48 447 512 53 448 minecraft:blackstone
fill 512 48 449 512 49 450 minecraft:orange_concrete
fill 512 48 456 512 53 456 minecraft:blackstone
setblock 512 48 457 minecraft:orange_concrete
setblock 470 49 416 minecraft:orange_concrete
fill 470 49 420 470 52 421 minecraft:blackstone
setblock 470 49 437 minecraft:orange_concrete
setblock 470 49 440 minecraft:orange_concrete
fill 470 49 441 470 52 441 minecraft:blackstone
setblock 470 49 448 minecraft:orange_concrete
fill 470 49 452 470 52 452 minecraft:blackstone
setblock 474 49 416 minecraft:orange_concrete
fill 480 49 458 481 49 458 minecraft:orange_concrete
setblock 484 49 458 minecraft:orange_concrete
setblock 485 49 416 minecraft:orange_concrete
fill 485 49 458 485 52 458 minecraft:blackstone
fill 490 49 416 490 51 416 minecraft:blackstone
fill 496 49 458 496 52 458 minecraft:blackstone
fill 501 49 416 501 52 416 minecraft:blackstone
setblock 501 49 458 minecraft:orange_concrete
setblock 502 49 416 minecraft:orange_concrete
fill 505 49 416 506 49 416 minecraft:orange_concrete
fill 512 49 426 512 52 426 minecraft:blackstone
setblock 512 49 430 minecraft:orange_concrete
fill 512 49 437 512 52 437 minecraft:blackstone
setblock 512 49 438 minecraft:orange_concrete
setblock 512 49 441 minecraft:orange_concrete
fill 512 49 457 512 52 457 minecraft:blackstone
setblock 512 49 458 minecraft:orange_concrete
fill 470 50 416 470 55 417 minecraft:blackstone
setblock 470 50 418 minecraft:orange_concrete
fill 470 50 426 470 51 427 minecraft:orange_concrete
fill 470 50 428 470 55 429 minecraft:blackstone
fill 470 50 435 470 51 435 minecraft:orange_concrete
fill 470 50 437 470 55 437 minecraft:blackstone
fill 470 50 438 470 50 439 minecraft:orange_concrete
fill 470 50 440 470 55 440 minecraft:blackstone
fill 470 50 446 470 51 447 minecraft:orange_concrete
fill 470 50 448 470 55 449 minecraft:blackstone
fill 470 50 458 471 50 458 minecraft:orange_concrete
fill 471 50 416 471 53 416 minecraft:blackstone
setblock 472 50 416 minecraft:orange_concrete
fill 472 50 458 473 55 458 minecraft:blackstone
fill 473 50 416 474 55 416 minecraft:blackstone
fill 475 50 416 476 51 416 minecraft:orange_concrete
fill 479 50 458 479 51 458 minecraft:orange_concrete
fill 480 50 458 481 55 458 minecraft:blackstone
fill 481 50 416 482 52 416 minecraft:blackstone
setblock 482 50 458 minecraft:orange_concrete
fill 483 50 416 484 50 416 minecraft:orange_concrete
fill 484 50 458 484 55 458 minecraft:blackstone
fill 485 50 416 485 55 416 minecraft:blackstone
fill 487 50 416 487 51 416 minecraft:orange_concrete
setblock 488 50 416 minecraft:blackstone
fill 490 50 458 491 51 458 minecraft:orange_concrete
fill 492 50 458 493 55 458 minecraft:blackstone
fill 493 50 416 494 55 416 minecraft:blackstone
fill 495 50 416 496 51 416 minecraft:orange_concrete
fill 501 50 458 501 55 458 minecraft:blackstone
fill 502 50 416 502 52 416 minecraft:blackstone
fill 502 50 458 503 50 458 minecraft:orange_concrete
setblock 504 50 416 minecraft:orange_concrete
fill 504 50 458 505 55 458 minecraft:blackstone
fill 505 50 416 506 55 416 minecraft:blackstone
fill 507 50 416 507 51 416 minecraft:orange_concrete
fill 510 50 458 511 51 458 minecraft:orange_concrete
fill 512 50 417 512 55 418 minecraft:blackstone
fill 512 50 419 512 50 420 minecraft:orange_concrete
fill 512 50 429 512 55 430 minecraft:blackstone
fill 512 50 431 512 51 432 minecraft:orange_concrete
fill 512 50 438 512 55 438 minecraft:blackstone
fill 512 50 439 512 50 440 minecraft:orange_concrete
fill 512 50 441 512 55 441 minecraft:blackstone
fill 512 50 443 512 51 443 minecraft:orange_concrete
fill 512 50 449 512 55 450 minecraft:blackstone
fill 512 50 451 512 51 452 minecraft:orange_concrete
fill 512 50 458 512 55 458 minecraft:blackstone
fill 470 51 418 470 54 418 minecraft:blackstone
setblock 470 51 423 minecraft:orange_concrete
setblock 470 51 434 minecraft:orange_concrete
fill 470 51 438 470 54 439 minecraft:blackstone
setblock 470 51 455 minecraft:orange_concrete
setblock 470 51 458 minecraft:orange_concrete
fill 471 51 458 471 54 458 minecraft:blackstone
fill 472 51 416 472 53 416 minecraft:blackstone
setblock 478 51 458 minecraft:orange_concrete
fill 482 51 458 482 54 458 minecraft:blackstone
fill 483 51 416 483 54 416 minecraft:blackstone
setblock 484 51 416 minecraft:orange_concrete
setblock 488 51 416 minecraft:orange_concrete
fill 498 51 458 499 51 458 minecraft:orange_concrete
setblock 499 51 416 minecraft:orange_concrete
fill 500 51 416 500 53 416 minecraft:blackstone
setblock 502 51 458 minecraft:orange_concrete
fill 503 51 458 503 54 458 minecraft:blackstone
fill 504 51 416 504 54 416 minecraft:blackstone
setblock 508 51 416 minecraft:orange_concrete
fill 512 51 419 512 54 419 minecraft:blackstone
setblock 512 51 420 minecraft:orange_concrete
setblock 512 51 423 minecraft:orange_concrete
fill 512 51 439 512 54 440 minecraft:blackstone
setblock 512 51 444 minecraft:orange_concrete
setblock 512 51 455 minecraft:orange_concrete
fill 470 52 423 470 57 423 minecraft:blackstone
fill 470 52 424 470 52 425 minecraft:orange_concrete
fill 470 52 426 470 57 427 minecraft:blackstone
fill 470 52 432 470 53 433 minecraft:orange_concrete
fill 470 52 434 470 57 435 minecraft:blackstone
setblock 470 52 436 minecraft:orange_concrete
fill 470 52 444 470 53 445 minecraft:orange_concrete
fill 470 52 446 470 57 447 minecraft:blackstone
fill 470 52 453 470 53 453 minecraft:orange_concrete
fill 470 52 455 470 57 455 minecraft:blackstone
fill 470 52 456 470 52 457 minecraft:orange_concrete
fill 470 52 458 470 57 458 minecraft:blackstone
fill 475 52 416 476 57 416 minecraft:blackstone
fill 476 52 458 477 53 458 minecraft:orange_concrete
fill 477 52 416 478 53 416 minecraft:orange_concrete
fill 478 52 458 479 57 458 minecraft:blackstone
fill 484 52 416 484 54 416 minecraft:blackstone
setblock 486 52 416 minecraft:orange_concrete
fill 487 52 416 488 57 416 minecraft:blackstone
fill 488 52 458 489 52 458 minecraft:orange_concrete
fill 489 52 416 490 53 416 minecraft:orange_concrete
fill 490 52 458 491 57 458 minecraft:blackstone
fill 495 52 416 496 57 416 minecraft:blackstone
fill 497 52 416 498 52 416 minecraft:orange_concrete
fill 497 52 458 497 53 458 minecraft:orange_concrete
fill 498 52 458 499 57 458 minecraft:blackstone
fill 499 52 416 499 53 416 minecraft:blackstone
setblock 500 52 458 minecraft:orange_concrete
fill 502 52 458 502 57 458 minecraft:blackstone
fill 507 52 416 508 57 416 minecraft:blackstone
schedule function dropper:buildpart/106_2 1t
