fill 405 59 183 407 59 184 minecraft:mossy_cobblestone
fill 406 59 182 409 59 182 minecraft:mossy_cobblestone
setblock 407 59 185 minecraft:stone_bricks
fill 407 59 222 409 59 222 minecraft:mossy_cobblestone
setblock 408 59 183 minecraft:mossy_cobblestone
setblock 408 59 184 minecraft:stone_bricks
fill 408 59 185 411 59 185 minecraft:mossy_cobblestone
setblock 409 59 183 minecraft:stone_bricks
fill 409 59 184 412 59 184 minecraft:mossy_cobblestone
setblock 410 59 182 minecraft:stone_bricks
fill 410 59 183 410 62 183 minecraft:mossy_cobblestone
setblock 410 59 222 minecraft:stone_bricks
fill 411 59 182 411 62 182 minecraft:mossy_cobblestone
fill 411 59 222 411 62 222 minecraft:mossy_cobblestone
setblock 413 59 184 minecraft:stone_bricks
setblock 414 59 183 minecraft:stone_bricks
setblock 414 59 184 minecraft:mossy_cobblestone
setblock 415 59 182 minecraft:stone_bricks
fill 415 59 183 415 60 183 minecraft:mossy_cobblestone
setblock 415 59 222 minecraft:stone_bricks
fill 416 59 182 416 61 182 minecraft:mossy_cobblestone
setblock 416 59 186 minecraft:stone_bricks
setblock 417 59 185 minecraft:stone_bricks
fill 417 59 186 417 62 186 minecraft:mossy_cobblestone
fill 417 59 188 417 60 188 minecraft:mossy_cobblestone
fill 377 60 206 377 60 208 minecraft:mossy_cobblestone
setblock 377 60 209 minecraft:stone_bricks
fill 377 60 210 377 63 210 minecraft:mossy_cobblestone
setblock 377 60 213 minecraft:mossy_cobblestone
fill 386 60 182 388 60 182 minecraft:mossy_cobblestone
setblock 389 60 182 minecraft:stone_bricks
fill 390 60 182 391 60 182 minecraft:mossy_cobblestone
fill 402 60 182 403 60 182 minecraft:mossy_cobblestone
setblock 403 60 183 minecraft:stone_bricks
setblock 404 60 182 minecraft:stone_bricks
fill 404 60 183 407 60 183 minecraft:mossy_cobblestone
fill 405 60 182 408 60 182 minecraft:mossy_cobblestone
fill 405 60 184 406 60 184 minecraft:mossy_cobblestone
setblock 407 60 184 minecraft:stone_bricks
fill 407 60 185 410 60 185 minecraft:mossy_cobblestone
fill 407 60 222 408 60 222 minecraft:mossy_cobblestone
setblock 408 60 183 minecraft:stone_bricks
fill 408 60 184 411 60 184 minecraft:mossy_cobblestone
setblock 409 60 182 minecraft:stone_bricks
fill 409 60 183 409 63 183 minecraft:mossy_cobblestone
setblock 409 60 222 minecraft:stone_bricks
fill 410 60 182 410 63 182 minecraft:mossy_cobblestone
fill 410 60 222 410 63 222 minecraft:mossy_cobblestone
setblock 412 60 184 minecraft:stone_bricks
setblock 413 60 183 minecraft:stone_bricks
setblock 413 60 184 minecraft:mossy_cobblestone
setblock 414 60 182 minecraft:stone_bricks
fill 414 60 183 414 61 183 minecraft:mossy_cobblestone
fill 415 60 182 415 62 182 minecraft:mossy_cobblestone
setblock 417 60 184 minecraft:stone_bricks
fill 417 60 185 417 63 185 minecraft:mossy_cobblestone
fill 376 61 181 376 62 181 minecraft:mossy_cobblestone
fill 376 61 182 376 62 182 minecraft:stone
setblock 376 61 183 minecraft:mossy_cobblestone
fill 376 61 184 376 62 189 minecraft:stone
setblock 376 61 190 minecraft:mossy_cobblestone
fill 376 61 191 376 61 193 minecraft:stone
setblock 376 61 194 minecraft:mossy_cobblestone
fill 376 61 195 376 61 199 minecraft:stone
fill 376 61 200 376 61 201 minecraft:mossy_cobblestone
fill 376 61 202 376 61 221 minecraft:stone
setblock 376 61 222 minecraft:mossy_cobblestone
fill 376 61 223 377 64 223 minecraft:stone
fill 377 61 181 385 61 181 minecraft:stone
fill 377 61 206 377 61 207 minecraft:mossy_cobblestone
setblock 377 61 208 minecraft:stone_bricks
fill 377 61 209 377 64 209 minecraft:mossy_cobblestone
setblock 377 61 213 minecraft:stone_bricks
fill 377 61 214 377 64 214 minecraft:mossy_cobblestone
setblock 378 61 223 minecraft:mossy_cobblestone
fill 379 61 223 379 64 223 minecraft:stone
fill 380 61 223 381 61 223 minecraft:mossy_cobblestone
fill 382 61 223 390 64 223 minecraft:stone
fill 386 61 181 386 61 182 minecraft:mossy_cobblestone
fill 387 61 181 398 61 181 minecraft:stone
setblock 387 61 182 minecraft:mossy_cobblestone
setblock 388 61 182 minecraft:stone_bricks
setblock 389 61 182 minecraft:mossy_cobblestone
fill 391 61 223 392 61 223 minecraft:mossy_cobblestone
fill 393 61 223 418 61 223 minecraft:stone
setblock 399 61 181 minecraft:mossy_cobblestone
fill 400 61 181 403 64 181 minecraft:stone
setblock 402 61 182 minecraft:mossy_cobblestone
setblock 403 61 182 minecraft:stone_bricks
fill 403 61 183 406 61 183 minecraft:mossy_cobblestone
fill 404 61 181 404 61 182 minecraft:mossy_cobblestone
fill 404 61 184 405 61 184 minecraft:mossy_cobblestone
fill 405 61 181 418 61 181 minecraft:stone
fill 405 61 182 407 61 182 minecraft:mossy_cobblestone
setblock 406 61 184 minecraft:stone_bricks
setblock 407 61 183 minecraft:stone_bricks
fill 407 61 184 409 61 185 minecraft:mossy_cobblestone
setblock 407 61 222 minecraft:mossy_cobblestone
setblock 408 61 182 minecraft:stone_bricks
fill 408 61 183 408 64 183 minecraft:mossy_cobblestone
setblock 408 61 222 minecraft:stone_bricks
fill 409 61 182 409 64 182 minecraft:mossy_cobblestone
fill 409 61 222 409 64 222 minecraft:mossy_cobblestone
setblock 410 61 184 minecraft:mossy_cobblestone
setblock 411 61 184 minecraft:stone_bricks
setblock 412 61 183 minecraft:stone_bricks
setblock 412 61 184 minecraft:mossy_cobblestone
setblock 413 61 182 minecraft:stone_bricks
fill 413 61 183 413 62 183 minecraft:mossy_cobblestone
fill 414 61 182 414 64 182 minecraft:mossy_cobblestone
setblock 417 61 183 minecraft:stone_bricks
fill 417 61 184 417 62 184 minecraft:mossy_cobblestone
setblock 417 61 188 minecraft:stone_bricks
setblock 418 61 182 minecraft:mossy_cobblestone
fill 418 61 183 418 64 184 minecraft:stone
setblock 418 61 185 minecraft:mossy_cobblestone
fill 418 61 186 418 64 189 minecraft:stone
setblock 418 61 190 minecraft:mossy_cobblestone
fill 418 61 191 418 64 192 minecraft:stone
setblock 418 61 193 minecraft:mossy_cobblestone
fill 418 61 194 418 64 194 minecraft:stone
setblock 418 61 195 minecraft:mossy_cobblestone
fill 418 61 196 418 64 197 minecraft:stone
setblock 418 61 198 minecraft:mossy_cobblestone
fill 418 61 199 418 62 222 minecraft:stone
fill 376 62 183 376 65 183 minecraft:stone
fill 376 62 190 376 64 190 minecraft:stone
setblock 376 62 191 minecraft:mossy_cobblestone
fill 376 62 192 376 64 192 minecraft:stone
setblock 376 62 193 minecraft:mossy_cobblestone
fill 376 62 194 376 62 195 minecraft:stone
setblock 376 62 196 minecraft:mossy_cobblestone
fill 376 62 197 376 62 202 minecraft:stone
setblock 376 62 203 minecraft:mossy_cobblestone
fill 376 62 204 376 62 215 minecraft:stone
setblock 376 62 216 minecraft:mossy_cobblestone
fill 376 62 217 376 64 219 minecraft:stone
setblock 376 62 220 minecraft:mossy_cobblestone
fill 376 62 221 376 64 222 minecraft:stone
setblock 377 62 181 minecraft:mossy_cobblestone
setblock 377 62 206 minecraft:mossy_cobblestone
setblock 377 62 207 minecraft:stone_bricks
fill 377 62 208 377 65 208 minecraft:mossy_cobblestone
setblock 377 62 212 minecraft:stone_bricks
fill 377 62 213 377 65 213 minecraft:mossy_cobblestone
fill 377 62 215 377 63 215 minecraft:mossy_cobblestone
fill 378 62 181 391 62 181 minecraft:stone
fill 378 62 209 378 62 210 minecraft:mossy_cobblestone
setblock 378 62 211 minecraft:stone_bricks
fill 378 62 212 378 65 212 minecraft:mossy_cobblestone
fill 378 62 223 378 64 223 minecraft:stone
setblock 380 62 223 minecraft:stone
setblock 381 62 223 minecraft:mossy_cobblestone
setblock 386 62 182 minecraft:mossy_cobblestone
setblock 387 62 182 minecraft:stone_bricks
fill 388 62 182 388 63 182 minecraft:mossy_cobblestone
fill 391 62 223 397 64 223 minecraft:stone
setblock 392 62 181 minecraft:mossy_cobblestone
fill 393 62 181 393 65 181 minecraft:stone
fill 394 62 181 394 63 181 minecraft:mossy_cobblestone
fill 395 62 181 399 62 181 minecraft:stone
setblock 398 62 223 minecraft:mossy_cobblestone
fill 399 62 223 399 64 223 minecraft:stone
setblock 400 62 223 minecraft:mossy_cobblestone
setblock 401 62 182 minecraft:mossy_cobblestone
fill 401 62 223 403 62 223 minecraft:stone
setblock 402 62 182 minecraft:stone_bricks
fill 403 62 182 405 62 183 minecraft:mossy_cobblestone
fill 404 62 181 410 64 181 minecraft:stone
setblock 404 62 184 minecraft:mossy_cobblestone
setblock 404 62 223 minecraft:mossy_cobblestone
setblock 405 62 184 minecraft:stone_bricks
fill 405 62 223 405 64 223 minecraft:stone
setblock 406 62 182 minecraft:mossy_cobblestone
setblock 406 62 183 minecraft:stone_bricks
fill 406 62 184 408 62 185 minecraft:mossy_cobblestone
fill 406 62 222 406 62 223 minecraft:mossy_cobblestone
setblock 407 62 182 minecraft:stone_bricks
fill 407 62 183 407 65 183 minecraft:mossy_cobblestone
setblock 407 62 222 minecraft:stone_bricks
fill 407 62 223 418 62 223 minecraft:stone
fill 408 62 182 408 65 182 minecraft:mossy_cobblestone
fill 408 62 222 408 65 222 minecraft:mossy_cobblestone
setblock 409 62 184 minecraft:mossy_cobblestone
setblock 410 62 184 minecraft:stone_bricks
setblock 411 62 181 minecraft:mossy_cobblestone
setblock 411 62 183 minecraft:stone_bricks
setblock 411 62 184 minecraft:mossy_cobblestone
fill 412 62 181 418 62 181 minecraft:stone
setblock 412 62 182 minecraft:stone_bricks
fill 412 62 183 412 64 183 minecraft:mossy_cobblestone
setblock 412 62 222 minecraft:stone_bricks
fill 413 62 182 413 65 182 minecraft:mossy_cobblestone
setblock 417 62 187 minecraft:stone_bricks
fill 417 62 188 417 65 188 minecraft:mossy_cobblestone
fill 417 62 210 417 62 211 minecraft:mossy_cobblestone
setblock 417 62 212 minecraft:stone_bricks
setblock 418 62 182 minecraft:stone
fill 418 62 185 418 64 185 minecraft:stone
fill 418 62 190 418 64 190 minecraft:stone
fill 418 62 193 418 64 193 minecraft:stone
setblock 418 62 195 minecraft:stone
fill 418 62 198 418 64 198 minecraft:stone
fill 376 63 181 387 64 181 minecraft:stone
setblock 376 63 182 minecraft:mossy_cobblestone
fill 376 63 184 376 64 186 minecraft:stone
setblock 376 63 187 minecraft:mossy_cobblestone
fill 376 63 188 376 64 189 minecraft:stone
fill 376 63 191 376 64 191 minecraft:stone
fill 376 63 193 376 64 194 minecraft:stone
setblock 376 63 195 minecraft:mossy_cobblestone
fill 376 63 196 376 64 199 minecraft:stone
fill 376 63 200 376 63 201 minecraft:mossy_cobblestone
fill 376 63 202 376 64 210 minecraft:stone
setblock 376 63 211 minecraft:mossy_cobblestone
fill 376 63 212 376 64 216 minecraft:stone
fill 376 63 220 376 64 220 minecraft:stone
setblock 377 63 206 minecraft:stone_bricks
fill 377 63 207 377 66 207 minecraft:mossy_cobblestone
setblock 377 63 211 minecraft:stone_bricks
fill 377 63 212 377 66 212 minecraft:mossy_cobblestone
setblock 377 63 216 minecraft:stone_bricks
fill 377 63 217 377 66 217 minecraft:mossy_cobblestone
fill 378 63 208 378 63 209 minecraft:mossy_cobblestone
setblock 378 63 210 minecraft:stone_bricks
fill 378 63 211 378 66 211 minecraft:mossy_cobblestone
fill 378 63 213 378 63 214 minecraft:mossy_cobblestone
setblock 380 63 223 minecraft:mossy_cobblestone
fill 381 63 223 381 64 223 minecraft:stone
setblock 386 63 182 minecraft:stone_bricks
fill 387 63 182 387 66 182 minecraft:mossy_cobblestone
setblock 388 63 181 minecraft:mossy_cobblestone
fill 389 63 181 392 64 181 minecraft:stone
fill 395 63 181 398 64 181 minecraft:stone
fill 398 63 223 398 64 223 minecraft:stone
setblock 399 63 181 minecraft:mossy_cobblestone
fill 400 63 223 402 64 223 minecraft:stone
setblock 401 63 182 minecraft:stone_bricks
fill 402 63 182 404 63 183 minecraft:mossy_cobblestone
setblock 403 63 184 minecraft:mossy_cobblestone
setblock 403 63 223 minecraft:mossy_cobblestone
setblock 404 63 184 minecraft:stone_bricks
fill 404 63 223 404 64 223 minecraft:stone
setblock 405 63 182 minecraft:mossy_cobblestone
setblock 405 63 183 minecraft:stone_bricks
fill 405 63 184 408 63 184 minecraft:mossy_cobblestone
setblock 405 63 222 minecraft:mossy_cobblestone
setblock 406 63 182 minecraft:stone_bricks
fill 406 63 183 406 66 183 minecraft:mossy_cobblestone
fill 406 63 185 407 63 185 minecraft:mossy_cobblestone
setblock 406 63 222 minecraft:stone_bricks
fill 406 63 223 413 64 223 minecraft:stone
fill 407 63 182 407 66 182 minecraft:mossy_cobblestone
fill 407 63 222 407 66 222 minecraft:mossy_cobblestone
setblock 408 63 185 minecraft:stone_bricks
setblock 409 63 184 minecraft:stone_bricks
setblock 410 63 183 minecraft:stone_bricks
fill 410 63 184 410 64 184 minecraft:mossy_cobblestone
fill 411 63 181 415 64 181 minecraft:stone
setblock 411 63 182 minecraft:stone_bricks
fill 411 63 183 411 66 183 minecraft:mossy_cobblestone
setblock 411 63 222 minecraft:stone_bricks
fill 412 63 182 412 66 182 minecraft:mossy_cobblestone
fill 412 63 222 412 66 222 minecraft:mossy_cobblestone
setblock 414 63 223 minecraft:mossy_cobblestone
fill 415 63 223 415 64 223 minecraft:stone
setblock 416 63 181 minecraft:mossy_cobblestone
setblock 416 63 223 minecraft:mossy_cobblestone
fill 417 63 181 418 64 181 minecraft:stone
setblock 417 63 186 minecraft:stone_bricks
fill 417 63 187 417 66 187 minecraft:mossy_cobblestone
fill 417 63 189 417 64 189 minecraft:mossy_cobblestone
fill 417 63 209 417 63 210 minecraft:mossy_cobblestone
setblock 417 63 211 minecraft:stone_bricks
fill 417 63 212 417 63 215 minecraft:mossy_cobblestone
fill 417 63 223 417 64 223 minecraft:stone
setblock 418 63 182 minecraft:mossy_cobblestone
setblock 418 63 195 minecraft:mossy_cobblestone
fill 418 63 199 418 64 203 minecraft:stone
fill 418 63 204 418 63 205 minecraft:mossy_cobblestone
fill 418 63 206 418 64 218 minecraft:stone
setblock 418 63 219 minecraft:mossy_cobblestone
fill 418 63 220 418 64 222 minecraft:stone
setblock 418 63 223 minecraft:mossy_cobblestone
setblock 376 64 182 minecraft:stone
setblock 376 64 187 minecraft:stone
setblock 376 64 195 minecraft:stone
fill 376 64 200 376 64 201 minecraft:stone
setblock 376 64 211 minecraft:stone
fill 377 64 206 377 67 206 minecraft:mossy_cobblestone
setblock 377 64 210 minecraft:stone_bricks
fill 377 64 211 377 67 211 minecraft:mossy_cobblestone
setblock 377 64 215 minecraft:stone_bricks
fill 377 64 216 377 67 216 minecraft:mossy_cobblestone
fill 377 64 218 377 65 218 minecraft:mossy_cobblestone
fill 378 64 207 378 64 208 minecraft:mossy_cobblestone
setblock 378 64 209 minecraft:stone_bricks
fill 378 64 210 379 66 210 minecraft:mossy_cobblestone
setblock 378 64 213 minecraft:mossy_cobblestone
setblock 378 64 214 minecraft:stone_bricks
fill 378 64 215 378 67 215 minecraft:mossy_cobblestone
fill 379 64 209 379 67 209 minecraft:mossy_cobblestone
fill 379 64 211 379 64 212 minecraft:mossy_cobblestone
setblock 379 64 213 minecraft:stone_bricks
setblock 380 64 223 minecraft:stone
setblock 384 64 222 minecraft:mossy_cobblestone
setblock 385 64 182 minecraft:stone_bricks
setblock 385 64 222 minecraft:stone_bricks
fill 386 64 182 386 67 182 minecraft:mossy_cobblestone
fill 386 64 222 386 67 222 minecraft:mossy_cobblestone
setblock 388 64 181 minecraft:stone
setblock 394 64 181 minecraft:stone
setblock 399 64 181 minecraft:stone
setblock 400 64 182 minecraft:stone_bricks
fill 401 64 182 403 64 183 minecraft:mossy_cobblestone
setblock 403 64 184 minecraft:stone_bricks
setblock 403 64 223 minecraft:stone
setblock 404 64 182 minecraft:mossy_cobblestone
setblock 404 64 183 minecraft:stone_bricks
fill 404 64 184 407 64 184 minecraft:mossy_cobblestone
setblock 404 64 222 minecraft:mossy_cobblestone
setblock 405 64 182 minecraft:stone_bricks
fill 405 64 183 405 67 183 minecraft:mossy_cobblestone
fill 405 64 185 406 64 185 minecraft:mossy_cobblestone
setblock 405 64 222 minecraft:stone_bricks
fill 406 64 182 406 67 182 minecraft:mossy_cobblestone
fill 406 64 222 406 67 222 minecraft:mossy_cobblestone
setblock 407 64 185 minecraft:stone_bricks
setblock 408 64 184 minecraft:stone_bricks
setblock 408 64 185 minecraft:mossy_cobblestone
setblock 409 64 183 minecraft:stone_bricks
fill 409 64 184 409 66 184 minecraft:mossy_cobblestone
setblock 410 64 182 minecraft:stone_bricks
fill 410 64 183 410 67 183 minecraft:mossy_cobblestone
setblock 410 64 222 minecraft:stone_bricks
fill 411 64 182 411 67 182 minecraft:mossy_cobblestone
fill 411 64 222 411 67 222 minecraft:mossy_cobblestone
setblock 414 64 223 minecraft:stone
setblock 416 64 181 minecraft:stone
setblock 416 64 223 minecraft:stone
setblock 417 64 185 minecraft:stone_bricks
fill 417 64 186 417 66 186 minecraft:mossy_cobblestone
setblock 417 64 190 minecraft:stone_bricks
setblock 417 64 209 minecraft:mossy_cobblestone
setblock 417 64 210 minecraft:stone_bricks
fill 417 64 211 417 64 214 minecraft:mossy_cobblestone
setblock 417 64 215 minecraft:stone_bricks
fill 417 64 216 417 65 218 minecraft:mossy_cobblestone
setblock 418 64 182 minecraft:stone
setblock 418 64 195 minecraft:stone
fill 418 64 204 418 64 205 minecraft:stone
setblock 418 64 219 minecraft:stone
setblock 418 64 223 minecraft:stone
setblock 376 65 181 minecraft:stone
fill 376 65 182 376 66 182 minecraft:mossy_cobblestone
fill 376 65 184 376 183 196 minecraft:mossy_cobblestone
fill 376 65 197 376 66 197 minecraft:stone
fill 376 65 198 376 66 204 minecraft:mossy_cobblestone
setblock 376 65 205 minecraft:stone
fill 376 65 206 376 66 222 minecraft:mossy_cobblestone
setblock 376 65 223 minecraft:stone
fill 377 65 181 377 66 181 minecraft:mossy_cobblestone
fill 377 65 205 377 68 205 minecraft:mossy_cobblestone
setblock 377 65 209 minecraft:stone_bricks
fill 377 65 210 377 68 210 minecraft:mossy_cobblestone
setblock 377 65 214 minecraft:stone_bricks
fill 377 65 215 377 68 215 minecraft:mossy_cobblestone
setblock 377 65 219 minecraft:stone_bricks
fill 377 65 223 386 65 223 minecraft:mossy_cobblestone
fill 378 65 181 378 66 181 minecraft:stone
setblock 378 65 207 minecraft:mossy_cobblestone
setblock 378 65 208 minecraft:stone_bricks
fill 378 65 209 378 68 209 minecraft:mossy_cobblestone
setblock 378 65 213 minecraft:stone_bricks
fill 378 65 214 379 67 214 minecraft:mossy_cobblestone
fill 378 65 216 378 65 217 minecraft:mossy_cobblestone
fill 379 65 181 380 182 181 minecraft:mossy_cobblestone
setblock 379 65 184 minecraft:light[level=12]
setblock 379 65 192 minecraft:light[level=12]
setblock 379 65 200 minecraft:light[level=12]
setblock 379 65 208 minecraft:light[level=12]
setblock 379 65 211 minecraft:mossy_cobblestone
setblock 379 65 212 minecraft:stone_bricks
fill 379 65 213 379 68 213 minecraft:mossy_cobblestone
fill 379 65 215 379 66 215 minecraft:mossy_cobblestone
setblock 379 65 216 minecraft:light[level=12]
fill 381 65 181 381 66 181 minecraft:stone
fill 382 65 181 391 65 181 minecraft:mossy_cobblestone
fill 382 65 222 383 65 222 minecraft:mossy_cobblestone
setblock 384 65 182 minecraft:stone_bricks
setblock 384 65 222 minecraft:stone_bricks
fill 385 65 182 385 68 182 minecraft:mossy_cobblestone
fill 385 65 222 385 68 222 minecraft:mossy_cobblestone
setblock 387 65 184 minecraft:light[level=12]
setblock 387 65 192 minecraft:light[level=12]
setblock 387 65 200 minecraft:light[level=12]
setblock 387 65 208 minecraft:light[level=12]
setblock 387 65 216 minecraft:light[level=12]
setblock 387 65 223 minecraft:stone
fill 388 65 223 409 65 223 minecraft:mossy_cobblestone
setblock 392 65 181 minecraft:stone
fill 394 65 181 405 65 181 minecraft:mossy_cobblestone
setblock 395 65 184 minecraft:light[level=12]
setblock 395 65 192 minecraft:light[level=12]
setblock 395 65 200 minecraft:light[level=12]
setblock 395 65 208 minecraft:light[level=12]
setblock 395 65 216 minecraft:light[level=12]
setblock 399 65 182 minecraft:stone_bricks
fill 400 65 182 403 65 182 minecraft:mossy_cobblestone
fill 401 65 183 402 65 183 minecraft:mossy_cobblestone
setblock 402 65 184 minecraft:stone_bricks
setblock 403 65 183 minecraft:stone_bricks
fill 403 65 184 406 65 184 minecraft:mossy_cobblestone
setblock 403 65 192 minecraft:light[level=12]
setblock 403 65 200 minecraft:light[level=12]
setblock 403 65 208 minecraft:light[level=12]
setblock 403 65 216 minecraft:light[level=12]
setblock 403 65 222 minecraft:mossy_cobblestone
setblock 404 65 182 minecraft:stone_bricks
fill 404 65 183 404 68 183 minecraft:mossy_cobblestone
fill 404 65 185 405 65 185 minecraft:mossy_cobblestone
setblock 404 65 222 minecraft:stone_bricks
fill 405 65 182 405 68 182 minecraft:mossy_cobblestone
fill 405 65 222 405 68 222 minecraft:mossy_cobblestone
setblock 406 65 181 minecraft:stone
setblock 406 65 185 minecraft:stone_bricks
fill 406 65 221 408 66 221 minecraft:mossy_cobblestone
fill 407 65 181 409 182 181 minecraft:mossy_cobblestone
setblock 407 65 184 minecraft:stone_bricks
setblock 407 65 185 minecraft:mossy_cobblestone
setblock 408 65 183 minecraft:stone_bricks
fill 408 65 184 408 67 184 minecraft:mossy_cobblestone
setblock 409 65 182 minecraft:stone_bricks
fill 409 65 183 409 68 183 minecraft:mossy_cobblestone
setblock 409 65 222 minecraft:stone_bricks
setblock 410 65 181 minecraft:stone
fill 410 65 182 410 68 182 minecraft:mossy_cobblestone
fill 410 65 222 410 68 222 minecraft:mossy_cobblestone
fill 410 65 223 410 66 223 minecraft:stone
setblock 411 65 181 minecraft:mossy_cobblestone
setblock 411 65 184 minecraft:light[level=12]
setblock 411 65 192 minecraft:light[level=12]
setblock 411 65 200 minecraft:light[level=12]
setblock 411 65 208 minecraft:light[level=12]
setblock 411 65 216 minecraft:light[level=12]
fill 411 65 223 418 65 223 minecraft:mossy_cobblestone
setblock 412 65 181 minecraft:stone
fill 413 65 181 418 65 181 minecraft:mossy_cobblestone
setblock 413 65 222 minecraft:mossy_cobblestone
setblock 414 65 182 minecraft:stone_bricks
fill 416 65 212 416 65 214 minecraft:mossy_cobblestone
setblock 416 65 215 minecraft:stone_bricks
fill 417 65 185 418 65 185 minecraft:mossy_cobblestone
setblock 417 65 189 minecraft:stone_bricks
fill 417 65 190 418 67 191 minecraft:mossy_cobblestone
fill 417 65 208 418 65 208 minecraft:mossy_cobblestone
setblock 417 65 209 minecraft:stone_bricks
fill 417 65 210 417 65 213 minecraft:mossy_cobblestone
setblock 417 65 214 minecraft:stone_bricks
fill 417 65 215 418 68 215 minecraft:mossy_cobblestone
setblock 417 65 219 minecraft:stone_bricks
fill 417 65 220 418 66 220 minecraft:mossy_cobblestone
fill 418 65 182 418 66 184 minecraft:mossy_cobblestone
fill 418 65 186 418 65 187 minecraft:mossy_cobblestone
setblock 418 65 188 minecraft:stone
fill 418 65 189 418 183 189 minecraft:mossy_cobblestone
fill 418 65 192 418 65 199 minecraft:mossy_cobblestone
setblock 418 65 200 minecraft:stone
fill 418 65 201 418 65 207 minecraft:mossy_cobblestone
fill 418 65 209 418 186 210 minecraft:mossy_cobblestone
setblock 418 65 211 minecraft:stone
fill 418 65 212 418 65 214 minecraft:mossy_cobblestone
fill 418 65 216 418 182 219 minecraft:mossy_cobblestone
fill 418 65 221 418 186 222 minecraft:mossy_cobblestone
fill 376 66 181 376 186 181 minecraft:mossy_cobblestone
fill 376 66 183 376 186 183 minecraft:mossy_cobblestone
fill 376 66 205 376 186 205 minecraft:mossy_cobblestone
fill 376 66 223 383 182 223 minecraft:mossy_cobblestone
fill 377 66 189 377 66 192 minecraft:mossy_cobblestone
setblock 377 66 193 minecraft:stone_bricks
fill 377 66 194 377 69 194 minecraft:mossy_cobblestone
setblock 377 66 208 minecraft:stone_bricks
fill 377 66 209 377 69 209 minecraft:mossy_cobblestone
setblock 377 66 213 minecraft:stone_bricks
fill 377 66 214 377 69 214 minecraft:mossy_cobblestone
setblock 377 66 218 minecraft:stone_bricks
fill 377 66 219 377 68 220 minecraft:mossy_cobblestone
setblock 378 66 207 minecraft:stone_bricks
fill 378 66 208 379 68 208 minecraft:mossy_cobblestone
setblock 378 66 212 minecraft:stone_bricks
fill 378 66 213 378 69 213 minecraft:mossy_cobblestone
setblock 378 66 216 minecraft:mossy_cobblestone
setblock 378 66 217 minecraft:stone_bricks
fill 378 66 218 378 69 218 minecraft:mossy_cobblestone
setblock 379 66 211 minecraft:stone_bricks
fill 379 66 212 380 68 212 minecraft:mossy_cobblestone
setblock 379 66 216 minecraft:stone_bricks
setblock 380 66 210 minecraft:stone_bricks
fill 380 66 211 380 69 211 minecraft:mossy_cobblestone
fill 380 66 213 380 66 214 minecraft:mossy_cobblestone
fill 380 66 222 382 66 222 minecraft:mossy_cobblestone
fill 382 66 181 383 182 181 minecraft:mossy_cobblestone
setblock 383 66 222 minecraft:stone_bricks
setblock 384 66 181 minecraft:stone
fill 384 66 182 384 68 182 minecraft:mossy_cobblestone
fill 384 66 222 384 69 222 minecraft:mossy_cobblestone
setblock 384 66 223 minecraft:stone
fill 385 66 181 385 186 181 minecraft:mossy_cobblestone
fill 385 66 223 389 66 223 minecraft:mossy_cobblestone
setblock 386 66 181 minecraft:stone
fill 387 66 181 388 186 181 minecraft:mossy_cobblestone
setblock 387 66 222 minecraft:mossy_cobblestone
setblock 389 66 181 minecraft:stone
fill 390 66 181 400 184 181 minecraft:mossy_cobblestone
setblock 390 66 223 minecraft:stone
fill 391 66 223 392 186 223 minecraft:mossy_cobblestone
setblock 393 66 223 minecraft:stone
fill 394 66 223 395 182 223 minecraft:mossy_cobblestone
setblock 396 66 223 minecraft:stone
fill 397 66 223 398 182 223 minecraft:mossy_cobblestone
fill 399 66 182 402 66 182 minecraft:mossy_cobblestone
setblock 399 66 223 minecraft:stone
fill 400 66 183 401 66 183 minecraft:mossy_cobblestone
fill 400 66 223 406 66 223 minecraft:mossy_cobblestone
setblock 401 66 181 minecraft:stone
fill 402 66 181 402 186 181 minecraft:mossy_cobblestone
setblock 402 66 183 minecraft:stone_bricks
fill 402 66 184 405 66 184 minecraft:mossy_cobblestone
setblock 402 66 222 minecraft:mossy_cobblestone
setblock 403 66 181 minecraft:stone
setblock 403 66 182 minecraft:stone_bricks
fill 403 66 183 403 69 183 minecraft:mossy_cobblestone
setblock 403 66 222 minecraft:stone_bricks
fill 404 66 181 404 69 182 minecraft:mossy_cobblestone
setblock 404 66 185 minecraft:mossy_cobblestone
setblock 404 66 221 minecraft:stone_bricks
fill 404 66 222 404 69 222 minecraft:mossy_cobblestone
fill 405 66 181 406 186 181 minecraft:mossy_cobblestone
setblock 405 66 185 minecraft:stone_bricks
fill 405 66 221 405 69 221 minecraft:mossy_cobblestone
setblock 406 66 184 minecraft:stone_bricks
setblock 406 66 185 minecraft:mossy_cobblestone
setblock 407 66 183 minecraft:stone_bricks
fill 407 66 184 407 68 184 minecraft:mossy_cobblestone
setblock 407 66 223 minecraft:stone
setblock 408 66 182 minecraft:stone_bricks
fill 408 66 183 408 69 183 minecraft:mossy_cobblestone
setblock 408 66 222 minecraft:stone_bricks
fill 408 66 223 409 183 223 minecraft:mossy_cobblestone
fill 409 66 182 409 69 182 minecraft:mossy_cobblestone
setblock 409 66 221 minecraft:stone_bricks
fill 409 66 222 409 69 222 minecraft:mossy_cobblestone
fill 410 66 181 410 182 181 minecraft:mossy_cobblestone
setblock 411 66 181 minecraft:stone
fill 411 66 223 417 66 223 minecraft:mossy_cobblestone
fill 412 66 181 416 182 181 minecraft:mossy_cobblestone
setblock 413 66 182 minecraft:stone_bricks
setblock 413 66 222 minecraft:stone_bricks
fill 414 66 222 417 66 222 minecraft:mossy_cobblestone
fill 416 66 211 416 66 213 minecraft:mossy_cobblestone
setblock 416 66 214 minecraft:stone_bricks
fill 416 66 215 416 67 217 minecraft:mossy_cobblestone
fill 417 66 181 418 66 181 minecraft:stone
setblock 417 66 188 minecraft:stone_bricks
fill 417 66 189 417 69 189 minecraft:mossy_cobblestone
fill 417 66 192 418 66 192 minecraft:mossy_cobblestone
setblock 417 66 193 minecraft:stone_bricks
setblock 417 66 208 minecraft:stone_bricks
fill 417 66 209 417 66 212 minecraft:mossy_cobblestone
setblock 417 66 213 minecraft:stone_bricks
fill 417 66 214 418 69 214 minecraft:mossy_cobblestone
fill 417 66 216 417 66 217 minecraft:mossy_cobblestone
setblock 417 66 218 minecraft:stone_bricks
fill 417 66 219 417 69 219 minecraft:mossy_cobblestone
fill 417 66 221 417 67 221 minecraft:mossy_cobblestone
fill 418 66 185 418 182 186 minecraft:mossy_cobblestone
setblock 418 66 187 minecraft:stone
fill 418 66 188 418 183 188 minecraft:mossy_cobblestone
fill 418 66 193 418 186 193 minecraft:mossy_cobblestone
setblock 418 66 194 minecraft:stone
fill 418 66 195 418 138 198 minecraft:mossy_cobblestone
fill 418 66 199 418 67 199 minecraft:stone
fill 418 66 200 418 138 202 minecraft:mossy_cobblestone
setblock 418 66 203 minecraft:stone
fill 418 66 204 418 66 208 minecraft:mossy_cobblestone
fill 418 66 211 418 182 212 minecraft:mossy_cobblestone
setblock 418 66 213 minecraft:stone
setblock 418 66 223 minecraft:stone
setblock 376 67 182 minecraft:stone
fill 376 67 197 376 186 199 minecraft:mossy_cobblestone
setblock 376 67 200 minecraft:stone
fill 376 67 201 376 184 204 minecraft:mossy_cobblestone
fill 376 67 206 376 182 216 minecraft:mossy_cobblestone
setblock 376 67 217 minecraft:stone
fill 376 67 218 376 184 222 minecraft:mossy_cobblestone
setblock 377 67 181 minecraft:stone
fill 377 67 189 377 67 191 minecraft:mossy_cobblestone
setblock 377 67 192 minecraft:stone_bricks
fill 377 67 193 377 70 193 minecraft:mossy_cobblestone
fill 377 67 195 377 67 196 minecraft:mossy_cobblestone
setblock 377 67 197 minecraft:stone_bricks
fill 377 67 204 377 69 204 minecraft:mossy_cobblestone
setblock 377 67 207 minecraft:stone_bricks
fill 377 67 208 377 70 208 minecraft:mossy_cobblestone
setblock 377 67 212 minecraft:stone_bricks
fill 377 67 213 377 70 213 minecraft:mossy_cobblestone
setblock 377 67 217 minecraft:stone_bricks
fill 377 67 218 377 70 218 minecraft:mossy_cobblestone
setblock 377 67 221 minecraft:mossy_cobblestone
fill 378 67 181 378 186 181 minecraft:mossy_cobblestone
setblock 378 67 206 minecraft:stone_bricks
fill 378 67 207 378 70 207 minecraft:mossy_cobblestone
setblock 378 67 210 minecraft:mossy_cobblestone
setblock 378 67 211 minecraft:stone_bricks
fill 378 67 212 378 70 212 minecraft:mossy_cobblestone
setblock 378 67 216 minecraft:stone_bricks
fill 378 67 217 379 69 217 minecraft:mossy_cobblestone
fill 378 67 219 378 68 219 minecraft:mossy_cobblestone
setblock 379 67 210 minecraft:stone_bricks
fill 379 67 211 379 70 211 minecraft:mossy_cobblestone
setblock 379 67 215 minecraft:stone_bricks
fill 379 67 216 379 70 216 minecraft:mossy_cobblestone
fill 379 67 222 381 67 222 minecraft:mossy_cobblestone
fill 380 67 210 380 68 210 minecraft:mossy_cobblestone
setblock 380 67 213 minecraft:mossy_cobblestone
setblock 380 67 214 minecraft:stone_bricks
fill 380 67 215 380 70 215 minecraft:mossy_cobblestone
fill 381 67 181 381 188 181 minecraft:mossy_cobblestone
setblock 382 67 222 minecraft:stone_bricks
fill 383 67 182 383 68 182 minecraft:mossy_cobblestone
setblock 383 67 221 minecraft:stone_bricks
fill 383 67 222 383 70 222 minecraft:mossy_cobblestone
fill 384 67 181 384 183 181 minecraft:mossy_cobblestone
fill 384 67 223 388 186 223 minecraft:mossy_cobblestone
fill 386 67 181 386 183 181 minecraft:mossy_cobblestone
setblock 387 67 222 minecraft:stone_bricks
fill 389 67 181 389 184 181 minecraft:mossy_cobblestone
setblock 389 67 223 minecraft:stone
fill 390 67 223 390 186 223 minecraft:mossy_cobblestone
fill 393 67 223 393 183 223 minecraft:mossy_cobblestone
fill 396 67 223 396 183 223 minecraft:mossy_cobblestone
fill 398 67 182 401 67 182 minecraft:mossy_cobblestone
fill 399 67 223 402 186 223 minecraft:mossy_cobblestone
setblock 400 67 183 minecraft:mossy_cobblestone
fill 401 67 181 401 186 181 minecraft:mossy_cobblestone
setblock 401 67 183 minecraft:stone_bricks
setblock 401 67 222 minecraft:mossy_cobblestone
setblock 402 67 182 minecraft:stone_bricks
fill 402 67 183 402 69 184 minecraft:mossy_cobblestone
setblock 402 67 222 minecraft:stone_bricks
fill 403 67 181 403 70 182 minecraft:mossy_cobblestone
fill 403 67 184 404 67 184 minecraft:mossy_cobblestone
setblock 403 67 221 minecraft:stone_bricks
fill 403 67 222 403 70 222 minecraft:mossy_cobblestone
setblock 403 67 223 minecraft:stone
fill 404 67 221 404 70 221 minecraft:mossy_cobblestone
fill 404 67 223 404 186 223 minecraft:mossy_cobblestone
setblock 405 67 184 minecraft:stone_bricks
setblock 405 67 223 minecraft:stone
setblock 406 67 183 minecraft:stone_bricks
fill 406 67 184 406 68 184 minecraft:mossy_cobblestone
fill 406 67 221 407 67 221 minecraft:mossy_cobblestone
fill 406 67 223 407 182 223 minecraft:mossy_cobblestone
setblock 407 67 182 minecraft:stone_bricks
fill 407 67 183 407 70 183 minecraft:mossy_cobblestone
setblock 407 67 222 minecraft:stone_bricks
fill 408 67 182 408 70 182 minecraft:mossy_cobblestone
setblock 408 67 221 minecraft:stone_bricks
fill 408 67 222 408 70 222 minecraft:mossy_cobblestone
fill 409 67 221 410 69 221 minecraft:mossy_cobblestone
fill 410 67 223 413 186 223 minecraft:mossy_cobblestone
fill 411 67 181 411 186 181 minecraft:mossy_cobblestone
setblock 412 67 182 minecraft:stone_bricks
setblock 412 67 222 minecraft:stone_bricks
fill 413 67 222 416 67 222 minecraft:mossy_cobblestone
setblock 414 67 223 minecraft:stone
fill 415 67 223 415 182 223 minecraft:mossy_cobblestone
fill 416 67 211 416 67 212 minecraft:mossy_cobblestone
setblock 416 67 213 minecraft:stone_bricks
fill 416 67 214 416 70 214 minecraft:mossy_cobblestone
setblock 416 67 218 minecraft:stone_bricks
fill 416 67 219 416 70 219 minecraft:mossy_cobblestone
setblock 416 67 223 minecraft:stone
fill 417 67 181 418 186 181 minecraft:mossy_cobblestone
setblock 417 67 187 minecraft:stone_bricks
fill 417 67 188 417 68 188 minecraft:mossy_cobblestone
setblock 417 67 192 minecraft:stone_bricks
fill 417 67 193 417 69 194 minecraft:mossy_cobblestone
fill 417 67 208 417 67 211 minecraft:mossy_cobblestone
setblock 417 67 212 minecraft:stone_bricks
fill 417 67 213 418 70 213 minecraft:mossy_cobblestone
setblock 417 67 216 minecraft:mossy_cobblestone
setblock 417 67 217 minecraft:stone_bricks
fill 417 67 218 417 70 218 minecraft:mossy_cobblestone
fill 417 67 220 417 68 220 minecraft:mossy_cobblestone
setblock 417 67 222 minecraft:stone_bricks
fill 417 67 223 418 182 223 minecraft:mossy_cobblestone
fill 418 67 182 418 184 182 minecraft:mossy_cobblestone
setblock 418 67 183 minecraft:stone
fill 418 67 184 418 186 184 minecraft:mossy_cobblestone
fill 418 67 187 418 187 187 minecraft:mossy_cobblestone
fill 418 67 192 418 187 192 minecraft:mossy_cobblestone
fill 418 67 194 418 183 194 minecraft:mossy_cobblestone
fill 418 67 203 418 138 203 minecraft:mossy_cobblestone
fill 418 67 204 418 67 205 minecraft:stone
fill 418 67 206 418 138 208 minecraft:mossy_cobblestone
setblock 418 67 220 minecraft:stone
fill 376 68 182 376 186 182 minecraft:mossy_cobblestone
fill 376 68 200 377 68 200 minecraft:mossy_cobblestone
fill 376 68 217 377 71 217 minecraft:mossy_cobblestone
fill 377 68 181 377 186 181 minecraft:mossy_cobblestone
fill 377 68 189 377 68 190 minecraft:mossy_cobblestone
setblock 377 68 191 minecraft:stone_bricks
fill 377 68 192 378 70 192 minecraft:mossy_cobblestone
setblock 377 68 195 minecraft:mossy_cobblestone
setblock 377 68 196 minecraft:stone_bricks
fill 377 68 197 377 69 199 minecraft:mossy_cobblestone
fill 377 68 203 377 70 203 minecraft:mossy_cobblestone
setblock 377 68 206 minecraft:stone_bricks
fill 377 68 207 377 71 207 minecraft:mossy_cobblestone
setblock 377 68 211 minecraft:stone_bricks
fill 377 68 212 377 71 212 minecraft:mossy_cobblestone
setblock 377 68 216 minecraft:stone_bricks
setblock 377 68 221 minecraft:stone_bricks
fill 378 68 191 378 69 191 minecraft:mossy_cobblestone
fill 378 68 193 378 68 194 minecraft:mossy_cobblestone
setblock 378 68 195 minecraft:stone_bricks
fill 378 68 196 378 71 196 minecraft:mossy_cobblestone
fill 378 68 206 378 69 206 minecraft:mossy_cobblestone
setblock 378 68 210 minecraft:stone_bricks
fill 378 68 211 378 71 211 minecraft:mossy_cobblestone
setblock 378 68 214 minecraft:mossy_cobblestone
setblock 378 68 215 minecraft:stone_bricks
fill 378 68 216 378 71 216 minecraft:mossy_cobblestone
setblock 378 68 220 minecraft:stone_bricks
fill 378 68 222 380 68 222 minecraft:mossy_cobblestone
setblock 379 68 209 minecraft:stone_bricks
fill 379 68 210 379 71 210 minecraft:mossy_cobblestone
setblock 379 68 214 minecraft:stone_bricks
fill 379 68 215 379 71 215 minecraft:mossy_cobblestone
setblock 379 68 218 minecraft:mossy_cobblestone
setblock 380 68 213 minecraft:stone_bricks
fill 380 68 214 380 70 214 minecraft:mossy_cobblestone
fill 380 68 216 380 69 216 minecraft:mossy_cobblestone
setblock 381 68 221 minecraft:mossy_cobblestone
setblock 381 68 222 minecraft:stone_bricks
setblock 382 68 221 minecraft:stone_bricks
fill 382 68 222 382 71 222 minecraft:mossy_cobblestone
fill 383 68 221 384 69 221 minecraft:mossy_cobblestone
setblock 386 68 222 minecraft:stone_bricks
fill 389 68 223 389 186 223 minecraft:mossy_cobblestone
fill 398 68 182 400 68 182 minecraft:mossy_cobblestone
setblock 400 68 183 minecraft:stone_bricks
setblock 400 68 222 minecraft:mossy_cobblestone
setblock 401 68 182 minecraft:stone_bricks
fill 401 68 183 401 71 183 minecraft:mossy_cobblestone
setblock 401 68 222 minecraft:stone_bricks
fill 402 68 182 402 71 182 minecraft:mossy_cobblestone
setblock 402 68 221 minecraft:stone_bricks
fill 402 68 222 402 71 222 minecraft:mossy_cobblestone
setblock 403 68 184 minecraft:mossy_cobblestone
fill 403 68 221 403 71 221 minecraft:mossy_cobblestone
fill 403 68 223 403 187 223 minecraft:mossy_cobblestone
setblock 404 68 184 minecraft:stone_bricks
setblock 405 68 183 minecraft:stone_bricks
fill 405 68 184 405 69 184 minecraft:mossy_cobblestone
fill 405 68 220 406 69 220 minecraft:mossy_cobblestone
fill 405 68 223 405 186 223 minecraft:mossy_cobblestone
setblock 406 68 182 minecraft:stone_bricks
fill 406 68 183 406 71 183 minecraft:mossy_cobblestone
setblock 406 68 221 minecraft:mossy_cobblestone
setblock 406 68 222 minecraft:stone_bricks
fill 407 68 182 407 71 182 minecraft:mossy_cobblestone
setblock 407 68 221 minecraft:stone_bricks
fill 407 68 222 407 71 222 minecraft:mossy_cobblestone
fill 408 68 221 408 71 221 minecraft:mossy_cobblestone
setblock 411 68 182 minecraft:stone_bricks
setblock 411 68 222 minecraft:stone_bricks
fill 412 68 222 415 68 222 minecraft:mossy_cobblestone
fill 414 68 223 414 186 223 minecraft:mossy_cobblestone
setblock 416 68 211 minecraft:mossy_cobblestone
setblock 416 68 212 minecraft:stone_bricks
fill 416 68 213 416 71 213 minecraft:mossy_cobblestone
fill 416 68 215 416 68 216 minecraft:mossy_cobblestone
setblock 416 68 217 minecraft:stone_bricks
fill 416 68 218 416 71 218 minecraft:mossy_cobblestone
fill 416 68 220 416 69 220 minecraft:mossy_cobblestone
setblock 416 68 222 minecraft:stone_bricks
fill 416 68 223 416 186 223 minecraft:mossy_cobblestone
fill 417 68 190 418 68 190 minecraft:mossy_cobblestone
setblock 417 68 191 minecraft:stone_bricks
fill 417 68 192 417 71 192 minecraft:mossy_cobblestone
setblock 417 68 195 minecraft:mossy_cobblestone
fill 417 68 208 417 68 210 minecraft:mossy_cobblestone
setblock 417 68 211 minecraft:stone_bricks
fill 417 68 212 417 71 212 minecraft:mossy_cobblestone
setblock 417 68 216 minecraft:stone_bricks
fill 417 68 217 417 71 217 minecraft:mossy_cobblestone
setblock 417 68 221 minecraft:stone_bricks
fill 417 68 222 417 71 222 minecraft:mossy_cobblestone
fill 418 68 183 418 186 183 minecraft:mossy_cobblestone
fill 418 68 191 418 186 191 minecraft:mossy_cobblestone
fill 418 68 199 418 138 199 minecraft:mossy_cobblestone
fill 418 68 204 418 138 205 minecraft:mossy_cobblestone
fill 418 68 220 418 186 220 minecraft:mossy_cobblestone
fill 376 69 200 376 186 200 minecraft:mossy_cobblestone
setblock 377 69 189 minecraft:mossy_cobblestone
setblock 377 69 190 minecraft:stone_bricks
fill 377 69 191 377 72 191 minecraft:mossy_cobblestone
setblock 377 69 195 minecraft:stone_bricks
fill 377 69 196 377 72 196 minecraft:mossy_cobblestone
setblock 377 69 200 minecraft:stone_bricks
fill 377 69 201 377 71 202 minecraft:mossy_cobblestone
setblock 377 69 205 minecraft:stone_bricks
fill 377 69 206 377 72 206 minecraft:mossy_cobblestone
setblock 377 69 210 minecraft:stone_bricks
fill 377 69 211 377 72 211 minecraft:mossy_cobblestone
setblock 377 69 215 minecraft:stone_bricks
fill 377 69 216 377 72 216 minecraft:mossy_cobblestone
setblock 377 69 219 minecraft:mossy_cobblestone
setblock 377 69 220 minecraft:stone_bricks
fill 377 69 221 377 71 222 minecraft:mossy_cobblestone
setblock 378 69 193 minecraft:mossy_cobblestone
setblock 378 69 194 minecraft:stone_bricks
fill 378 69 195 379 71 195 minecraft:mossy_cobblestone
fill 378 69 197 378 69 198 minecraft:mossy_cobblestone
setblock 378 69 199 minecraft:stone_bricks
setblock 378 69 208 minecraft:mossy_cobblestone
setblock 378 69 209 minecraft:stone_bricks
fill 378 69 210 378 72 210 minecraft:mossy_cobblestone
setblock 378 69 214 minecraft:stone_bricks
fill 378 69 215 378 72 215 minecraft:mossy_cobblestone
setblock 378 69 219 minecraft:stone_bricks
fill 378 69 220 378 72 220 minecraft:mossy_cobblestone
fill 378 69 222 379 69 222 minecraft:mossy_cobblestone
fill 379 69 194 379 72 194 minecraft:mossy_cobblestone
setblock 379 69 208 minecraft:stone_bricks
fill 379 69 209 379 70 209 minecraft:mossy_cobblestone
setblock 379 69 212 minecraft:mossy_cobblestone
setblock 379 69 213 minecraft:stone_bricks
fill 379 69 214 379 72 214 minecraft:mossy_cobblestone
setblock 379 69 218 minecraft:stone_bricks
setblock 380 69 212 minecraft:stone_bricks
fill 380 69 213 380 70 213 minecraft:mossy_cobblestone
setblock 380 69 221 minecraft:mossy_cobblestone
setblock 380 69 222 minecraft:stone_bricks
setblock 381 69 221 minecraft:stone_bricks
fill 381 69 222 381 72 222 minecraft:mossy_cobblestone
fill 382 69 221 382 72 221 minecraft:mossy_cobblestone
setblock 385 69 222 minecraft:stone_bricks
setblock 386 69 222 minecraft:mossy_cobblestone
fill 398 69 182 399 69 182 minecraft:mossy_cobblestone
setblock 399 69 222 minecraft:mossy_cobblestone
setblock 400 69 182 minecraft:stone_bricks
fill 400 69 183 400 72 183 minecraft:mossy_cobblestone
setblock 400 69 222 minecraft:stone_bricks
fill 401 69 182 401 72 182 minecraft:mossy_cobblestone
setblock 401 69 221 minecraft:stone_bricks
fill 401 69 222 401 72 222 minecraft:mossy_cobblestone
fill 402 69 221 402 72 221 minecraft:mossy_cobblestone
setblock 403 69 184 minecraft:stone_bricks
fill 403 69 220 404 71 220 minecraft:mossy_cobblestone
setblock 404 69 183 minecraft:stone_bricks
setblock 404 69 184 minecraft:mossy_cobblestone
setblock 405 69 182 minecraft:stone_bricks
fill 405 69 183 405 71 183 minecraft:mossy_cobblestone
setblock 405 69 222 minecraft:stone_bricks
fill 406 69 182 406 72 182 minecraft:mossy_cobblestone
setblock 406 69 221 minecraft:stone_bricks
fill 406 69 222 406 72 222 minecraft:mossy_cobblestone
fill 407 69 221 407 72 221 minecraft:mossy_cobblestone
setblock 410 69 182 minecraft:stone_bricks
setblock 410 69 222 minecraft:stone_bricks
fill 411 69 222 414 69 222 minecraft:mossy_cobblestone
setblock 415 69 222 minecraft:stone_bricks
setblock 416 69 211 minecraft:stone_bricks
fill 416 69 212 416 72 212 minecraft:mossy_cobblestone
setblock 416 69 215 minecraft:mossy_cobblestone
setblock 416 69 216 minecraft:stone_bricks
fill 416 69 217 416 72 217 minecraft:mossy_cobblestone
fill 416 69 222 416 72 222 minecraft:mossy_cobblestone
setblock 417 69 190 minecraft:stone_bricks
fill 417 69 191 417 70 191 minecraft:mossy_cobblestone
setblock 417 69 195 minecraft:stone_bricks
fill 417 69 196 417 72 196 minecraft:mossy_cobblestone
fill 417 69 208 417 69 209 minecraft:mossy_cobblestone
setblock 417 69 210 minecraft:stone_bricks
fill 417 69 211 417 72 211 minecraft:mossy_cobblestone
setblock 417 69 215 minecraft:stone_bricks
fill 417 69 216 417 72 216 minecraft:mossy_cobblestone
setblock 417 69 220 minecraft:stone_bricks
fill 417 69 221 417 72 221 minecraft:mossy_cobblestone
fill 418 69 190 418 187 190 minecraft:mossy_cobblestone
fill 418 69 215 418 186 215 minecraft:mossy_cobblestone
fill 377 70 190 377 71 190 minecraft:mossy_cobblestone
setblock 377 70 194 minecraft:stone_bricks
fill 377 70 195 377 73 195 minecraft:mossy_cobblestone
fill 377 70 197 377 70 198 minecraft:mossy_cobblestone
setblock 377 70 199 minecraft:stone_bricks
fill 377 70 200 378 72 200 minecraft:mossy_cobblestone
setblock 377 70 204 minecraft:stone_bricks
fill 377 70 205 377 73 205 minecraft:mossy_cobblestone
setblock 377 70 209 minecraft:stone_bricks
fill 377 70 210 377 73 210 minecraft:mossy_cobblestone
setblock 377 70 214 minecraft:stone_bricks
fill 377 70 215 377 73 215 minecraft:mossy_cobblestone
setblock 377 70 219 minecraft:stone_bricks
fill 377 70 220 377 73 220 minecraft:mossy_cobblestone
setblock 378 70 193 minecraft:stone_bricks
fill 378 70 194 378 73 194 minecraft:mossy_cobblestone
setblock 378 70 197 minecraft:mossy_cobblestone
setblock 378 70 198 minecraft:stone_bricks
fill 378 70 199 378 73 199 minecraft:mossy_cobblestone
setblock 378 70 208 minecraft:stone_bricks
fill 378 70 209 378 73 209 minecraft:mossy_cobblestone
setblock 378 70 213 minecraft:stone_bricks
fill 378 70 214 378 73 214 minecraft:mossy_cobblestone
setblock 378 70 217 minecraft:mossy_cobblestone
setblock 378 70 218 minecraft:stone_bricks
fill 378 70 219 378 73 219 minecraft:mossy_cobblestone
setblock 378 70 222 minecraft:mossy_cobblestone
setblock 379 70 196 minecraft:mossy_cobblestone
setblock 379 70 197 minecraft:stone_bricks
setblock 379 70 212 minecraft:stone_bricks
fill 379 70 213 379 72 213 minecraft:mossy_cobblestone
setblock 379 70 217 minecraft:stone_bricks
fill 379 70 218 379 73 218 minecraft:mossy_cobblestone
setblock 379 70 221 minecraft:mossy_cobblestone
setblock 379 70 222 minecraft:stone_bricks
setblock 380 70 212 minecraft:mossy_cobblestone
setblock 380 70 216 minecraft:stone_bricks
setblock 380 70 221 minecraft:stone_bricks
fill 380 70 222 380 73 222 minecraft:mossy_cobblestone
fill 381 70 221 381 73 221 minecraft:mossy_cobblestone
fill 383 70 221 383 71 221 minecraft:mossy_cobblestone
setblock 384 70 222 minecraft:stone_bricks
fill 385 70 222 385 71 222 minecraft:mossy_cobblestone
fill 397 70 182 398 70 182 minecraft:mossy_cobblestone
fill 397 70 183 397 74 183 minecraft:moss_block
setblock 398 70 222 minecraft:mossy_cobblestone
setblock 399 70 182 minecraft:stone_bricks
fill 399 70 183 399 73 183 minecraft:mossy_cobblestone
setblock 399 70 222 minecraft:stone_bricks
fill 400 70 182 400 73 182 minecraft:mossy_cobblestone
setblock 400 70 221 minecraft:stone_bricks
fill 400 70 222 400 73 222 minecraft:mossy_cobblestone
fill 401 70 221 401 73 221 minecraft:mossy_cobblestone
setblock 402 70 183 minecraft:mossy_cobblestone
setblock 403 70 183 minecraft:stone_bricks
fill 404 70 181 404 182 181 minecraft:mossy_cobblestone
setblock 404 70 182 minecraft:stone_bricks
fill 404 70 183 404 73 183 minecraft:mossy_cobblestone
setblock 404 70 222 minecraft:stone_bricks
fill 405 70 182 405 73 182 minecraft:mossy_cobblestone
setblock 405 70 220 minecraft:mossy_cobblestone
setblock 405 70 221 minecraft:stone_bricks
fill 405 70 222 405 73 222 minecraft:mossy_cobblestone
setblock 406 70 220 minecraft:stone_bricks
fill 406 70 221 406 73 221 minecraft:mossy_cobblestone
setblock 409 70 182 minecraft:stone_bricks
setblock 409 70 221 minecraft:mossy_cobblestone
setblock 409 70 222 minecraft:stone_bricks
setblock 410 70 221 minecraft:stone_bricks
fill 410 70 222 413 70 222 minecraft:mossy_cobblestone
setblock 414 70 222 minecraft:stone_bricks
fill 415 70 222 415 73 222 minecraft:mossy_cobblestone
setblock 416 70 211 minecraft:mossy_cobblestone
setblock 416 70 215 minecraft:stone_bricks
fill 416 70 216 416 73 216 minecraft:mossy_cobblestone
setblock 416 70 220 minecraft:stone_bricks
fill 416 70 221 416 73 221 minecraft:mossy_cobblestone
setblock 417 70 190 minecraft:mossy_cobblestone
setblock 417 70 193 minecraft:mossy_cobblestone
setblock 417 70 194 minecraft:stone_bricks
fill 417 70 195 417 73 195 minecraft:mossy_cobblestone
fill 417 70 197 417 71 197 minecraft:mossy_cobblestone
setblock 417 70 208 minecraft:mossy_cobblestone
setblock 417 70 209 minecraft:stone_bricks
fill 417 70 210 417 73 210 minecraft:mossy_cobblestone
setblock 417 70 214 minecraft:stone_bricks
fill 417 70 215 417 73 215 minecraft:mossy_cobblestone
setblock 417 70 219 minecraft:stone_bricks
fill 417 70 220 417 73 220 minecraft:mossy_cobblestone
fill 418 70 214 418 184 214 minecraft:mossy_cobblestone
setblock 377 71 192 minecraft:mossy_cobblestone
setblock 377 71 193 minecraft:stone_bricks
fill 377 71 194 377 74 194 minecraft:mossy_cobblestone
setblock 377 71 197 minecraft:mossy_cobblestone
setblock 377 71 198 minecraft:stone_bricks
fill 377 71 199 377 74 199 minecraft:mossy_cobblestone
setblock 377 71 203 minecraft:stone_bricks
fill 377 71 204 377 74 204 minecraft:mossy_cobblestone
setblock 377 71 208 minecraft:stone_bricks
fill 377 71 209 377 74 209 minecraft:mossy_cobblestone
setblock 377 71 213 minecraft:stone_bricks
fill 377 71 214 377 74 214 minecraft:mossy_cobblestone
setblock 377 71 218 minecraft:stone_bricks
fill 377 71 219 377 74 219 minecraft:mossy_cobblestone
setblock 378 71 192 minecraft:stone_bricks
fill 378 71 193 378 74 193 minecraft:mossy_cobblestone
setblock 378 71 197 minecraft:stone_bricks
fill 378 71 198 379 73 198 minecraft:mossy_cobblestone
setblock 378 71 201 minecraft:mossy_cobblestone
setblock 378 71 202 minecraft:stone_bricks
setblock 378 71 207 minecraft:stone_bricks
fill 378 71 208 378 72 208 minecraft:mossy_cobblestone
setblock 378 71 212 minecraft:stone_bricks
fill 378 71 213 378 74 213 minecraft:mossy_cobblestone
setblock 378 71 217 minecraft:stone_bricks
fill 378 71 218 378 74 218 minecraft:mossy_cobblestone
setblock 378 71 222 minecraft:stone_bricks
setblock 379 71 196 minecraft:stone_bricks
fill 379 71 197 379 74 197 minecraft:mossy_cobblestone
fill 379 71 199 379 72 199 minecraft:mossy_cobblestone
setblock 379 71 211 minecraft:stone_bricks
fill 379 71 212 379 72 212 minecraft:mossy_cobblestone
setblock 379 71 216 minecraft:stone_bricks
fill 379 71 217 379 74 217 minecraft:mossy_cobblestone
setblock 379 71 221 minecraft:stone_bricks
fill 379 71 222 379 74 222 minecraft:mossy_cobblestone
fill 380 71 221 380 74 221 minecraft:mossy_cobblestone
setblock 383 71 222 minecraft:stone_bricks
fill 384 71 222 384 74 222 minecraft:mossy_cobblestone
setblock 397 71 182 minecraft:mossy_cobblestone
setblock 398 71 182 minecraft:stone_bricks
setblock 398 71 222 minecraft:stone_bricks
fill 399 71 182 399 74 182 minecraft:mossy_cobblestone
fill 399 71 222 399 74 222 minecraft:mossy_cobblestone
fill 400 71 221 400 74 221 minecraft:mossy_cobblestone
setblock 402 71 183 minecraft:stone_bricks
fill 402 71 220 402 73 220 minecraft:mossy_cobblestone
fill 403 71 181 403 187 181 minecraft:mossy_cobblestone
setblock 403 71 182 minecraft:stone_bricks
fill 403 71 183 403 74 183 minecraft:mossy_cobblestone
setblock 403 71 222 minecraft:stone_bricks
fill 404 71 182 404 74 182 minecraft:mossy_cobblestone
setblock 404 71 221 minecraft:stone_bricks
fill 404 71 222 404 74 222 minecraft:mossy_cobblestone
setblock 405 71 220 minecraft:stone_bricks
fill 405 71 221 405 74 221 minecraft:mossy_cobblestone
setblock 406 71 220 minecraft:mossy_cobblestone
setblock 408 71 182 minecraft:stone_bricks
setblock 408 71 222 minecraft:stone_bricks
setblock 409 71 221 minecraft:stone_bricks
fill 409 71 222 412 71 222 minecraft:mossy_cobblestone
setblock 413 71 222 minecraft:stone_bricks
fill 414 71 222 414 74 222 minecraft:mossy_cobblestone
fill 415 71 221 415 74 221 minecraft:mossy_cobblestone
setblock 416 71 214 minecraft:stone_bricks
fill 416 71 215 416 74 215 minecraft:mossy_cobblestone
setblock 416 71 219 minecraft:stone_bricks
fill 416 71 220 416 74 220 minecraft:mossy_cobblestone
setblock 417 71 193 minecraft:stone_bricks
fill 417 71 194 417 74 194 minecraft:mossy_cobblestone
setblock 417 71 198 minecraft:stone_bricks
fill 417 71 209 417 74 209 minecraft:mossy_cobblestone
setblock 417 71 213 minecraft:stone_bricks
fill 417 71 214 417 74 214 minecraft:mossy_cobblestone
setblock 417 71 218 minecraft:stone_bricks
fill 417 71 219 417 74 219 minecraft:mossy_cobblestone
fill 418 71 213 418 186 213 minecraft:mossy_cobblestone
fill 376 72 217 376 182 217 minecraft:mossy_cobblestone
setblock 377 72 192 minecraft:stone_bricks
fill 377 72 193 377 75 193 minecraft:mossy_cobblestone
setblock 377 72 197 minecraft:stone_bricks
fill 377 72 198 377 75 198 minecraft:mossy_cobblestone
setblock 377 72 201 minecraft:mossy_cobblestone
setblock 377 72 202 minecraft:stone_bricks
fill 377 72 203 378 74 203 minecraft:mossy_cobblestone
setblock 377 72 207 minecraft:stone_bricks
fill 377 72 208 377 75 208 minecraft:mossy_cobblestone
setblock 377 72 212 minecraft:stone_bricks
fill 377 72 213 377 75 213 minecraft:mossy_cobblestone
setblock 377 72 217 minecraft:stone_bricks
fill 377 72 218 377 75 218 minecraft:mossy_cobblestone
setblock 377 72 221 minecraft:mossy_cobblestone
setblock 377 72 222 minecraft:stone_bricks
setblock 378 72 192 minecraft:mossy_cobblestone
setblock 378 72 195 minecraft:mossy_cobblestone
setblock 378 72 196 minecraft:stone_bricks
fill 378 72 197 378 75 197 minecraft:mossy_cobblestone
setblock 378 72 201 minecraft:stone_bricks
fill 378 72 202 378 75 202 minecraft:mossy_cobblestone
setblock 378 72 211 minecraft:stone_bricks
fill 378 72 212 378 75 212 minecraft:mossy_cobblestone
setblock 378 72 216 minecraft:stone_bricks
fill 378 72 217 378 75 217 minecraft:mossy_cobblestone
setblock 378 72 221 minecraft:stone_bricks
fill 378 72 222 378 75 222 minecraft:mossy_cobblestone
setblock 379 72 195 minecraft:stone_bricks
fill 379 72 196 379 75 196 minecraft:mossy_cobblestone
setblock 379 72 200 minecraft:stone_bricks
setblock 379 72 215 minecraft:stone_bricks
fill 379 72 216 379 74 216 minecraft:mossy_cobblestone
fill 379 72 221 379 75 221 minecraft:mossy_cobblestone
setblock 382 72 222 minecraft:stone_bricks
fill 383 72 182 383 73 187 minecraft:stone_bricks
fill 383 72 222 383 75 222 minecraft:mossy_cobblestone
fill 384 72 185 384 73 191 minecraft:stone_bricks
setblock 397 72 182 minecraft:stone_bricks
setblock 397 72 222 minecraft:stone_bricks
fill 398 72 182 398 75 182 minecraft:mossy_cobblestone
fill 398 72 222 398 75 222 minecraft:mossy_cobblestone
fill 399 72 221 399 75 221 minecraft:mossy_cobblestone
setblock 401 72 183 minecraft:stone_bricks
fill 401 72 220 401 74 220 minecraft:mossy_cobblestone
setblock 402 72 182 minecraft:stone_bricks
fill 402 72 183 402 75 183 minecraft:mossy_cobblestone
setblock 402 72 222 minecraft:stone_bricks
fill 403 72 182 403 75 182 minecraft:mossy_cobblestone
setblock 403 72 220 minecraft:mossy_cobblestone
setblock 403 72 221 minecraft:stone_bricks
fill 403 72 222 403 75 222 minecraft:mossy_cobblestone
setblock 404 72 220 minecraft:stone_bricks
fill 404 72 221 404 75 221 minecraft:mossy_cobblestone
fill 405 72 220 405 73 220 minecraft:mossy_cobblestone
setblock 407 72 182 minecraft:stone_bricks
setblock 407 72 222 minecraft:stone_bricks
setblock 408 72 182 minecraft:mossy_cobblestone
setblock 408 72 221 minecraft:stone_bricks
fill 408 72 222 411 72 222 minecraft:mossy_cobblestone
setblock 409 72 221 minecraft:mossy_cobblestone
setblock 412 72 222 minecraft:stone_bricks
fill 413 72 222 413 75 222 minecraft:mossy_cobblestone
setblock 416 72 213 minecraft:stone_bricks
fill 416 72 214 416 75 214 minecraft:mossy_cobblestone
setblock 416 72 218 minecraft:stone_bricks
fill 416 72 219 416 75 219 minecraft:mossy_cobblestone
fill 417 72 193 417 73 193 minecraft:mossy_cobblestone
setblock 417 72 197 minecraft:stone_bricks
fill 417 72 198 417 74 199 minecraft:mossy_cobblestone
setblock 417 72 212 minecraft:stone_bricks
fill 417 72 213 417 75 213 minecraft:mossy_cobblestone
setblock 417 72 217 minecraft:stone_bricks
fill 417 72 218 417 75 218 minecraft:mossy_cobblestone
setblock 417 72 222 minecraft:stone_bricks
setblock 377 73 191 minecraft:stone_bricks
fill 377 73 192 377 76 192 minecraft:mossy_cobblestone
setblock 377 73 196 minecraft:stone_bricks
fill 377 73 197 377 76 197 minecraft:mossy_cobblestone
setblock 377 73 200 minecraft:mossy_cobblestone
setblock 377 73 201 minecraft:stone_bricks
fill 377 73 202 377 76 202 minecraft:mossy_cobblestone
setblock 377 73 206 minecraft:stone_bricks
fill 377 73 207 377 76 207 minecraft:mossy_cobblestone
setblock 377 73 211 minecraft:stone_bricks
fill 377 73 212 377 76 212 minecraft:mossy_cobblestone
setblock 377 73 216 minecraft:stone_bricks
fill 377 73 217 377 76 217 minecraft:mossy_cobblestone
setblock 377 73 221 minecraft:stone_bricks
fill 377 73 222 377 76 222 minecraft:mossy_cobblestone
setblock 378 73 195 minecraft:stone_bricks
fill 378 73 196 378 76 196 minecraft:mossy_cobblestone
setblock 378 73 200 minecraft:stone_bricks
fill 378 73 201 379 75 201 minecraft:mossy_cobblestone
setblock 378 73 204 minecraft:mossy_cobblestone
setblock 378 73 210 minecraft:stone_bricks
fill 378 73 211 378 75 211 minecraft:mossy_cobblestone
setblock 378 73 215 minecraft:stone_bricks
fill 378 73 216 378 76 216 minecraft:mossy_cobblestone
setblock 378 73 220 minecraft:stone_bricks
fill 378 73 221 378 76 221 minecraft:mossy_cobblestone
setblock 379 73 184 minecraft:light[level=12]
setblock 379 73 192 minecraft:light[level=12]
setblock 379 73 194 minecraft:stone_bricks
fill 379 73 195 379 76 195 minecraft:mossy_cobblestone
setblock 379 73 199 minecraft:stone_bricks
fill 379 73 200 379 76 200 minecraft:mossy_cobblestone
setblock 379 73 208 minecraft:light[level=12]
setblock 379 73 214 minecraft:stone_bricks
setblock 379 73 215 minecraft:mossy_cobblestone
setblock 381 73 222 minecraft:stone_bricks
setblock 382 73 182 minecraft:stone_bricks
setblock 382 73 221 minecraft:stone_bricks
fill 382 73 222 382 76 222 minecraft:mossy_cobblestone
fill 383 73 188 383 73 190 minecraft:stone_bricks
setblock 384 73 184 minecraft:stone_bricks
fill 384 73 192 385 73 197 minecraft:stone_bricks
setblock 385 73 191 minecraft:stone_bricks
fill 385 73 198 385 74 204 minecraft:stone_bricks
fill 386 73 199 386 73 209 minecraft:stone_bricks
setblock 387 73 184 minecraft:light[level=12]
setblock 387 73 192 minecraft:light[level=12]
setblock 387 73 200 minecraft:light[level=12]
setblock 387 73 208 minecraft:light[level=12]
setblock 387 73 216 minecraft:light[level=12]
setblock 395 73 184 minecraft:light[level=12]
setblock 395 73 192 minecraft:light[level=12]
setblock 395 73 200 minecraft:light[level=12]
setblock 395 73 208 minecraft:light[level=12]
setblock 395 73 216 minecraft:light[level=12]
setblock 396 73 182 minecraft:stone_bricks
fill 397 73 182 397 76 182 minecraft:mossy_cobblestone
fill 397 73 222 397 76 222 minecraft:mossy_cobblestone
fill 398 73 221 398 76 221 minecraft:mossy_cobblestone
setblock 400 73 183 minecraft:stone_bricks
setblock 401 73 182 minecraft:stone_bricks
fill 401 73 183 401 76 183 minecraft:mossy_cobblestone
setblock 401 73 222 minecraft:stone_bricks
fill 402 73 182 402 76 182 minecraft:mossy_cobblestone
setblock 402 73 221 minecraft:stone_bricks
fill 402 73 222 402 76 222 minecraft:mossy_cobblestone
setblock 403 73 184 minecraft:light[level=12]
setblock 403 73 192 minecraft:light[level=12]
setblock 403 73 200 minecraft:light[level=12]
setblock 403 73 208 minecraft:light[level=12]
setblock 403 73 216 minecraft:light[level=12]
setblock 403 73 220 minecraft:stone_bricks
fill 403 73 221 403 76 221 minecraft:mossy_cobblestone
fill 404 73 220 404 76 220 minecraft:mossy_cobblestone
setblock 406 73 182 minecraft:stone_bricks
setblock 406 73 222 minecraft:stone_bricks
fill 407 73 182 407 76 182 minecraft:mossy_cobblestone
setblock 407 73 221 minecraft:stone_bricks
fill 407 73 222 410 73 222 minecraft:mossy_cobblestone
fill 408 73 221 408 76 221 minecraft:mossy_cobblestone
setblock 411 73 184 minecraft:light[level=12]
setblock 411 73 192 minecraft:light[level=12]
setblock 411 73 200 minecraft:light[level=12]
setblock 411 73 208 minecraft:light[level=12]
setblock 411 73 216 minecraft:light[level=12]
setblock 411 73 222 minecraft:stone_bricks
fill 412 73 222 412 76 222 minecraft:mossy_cobblestone
fill 414 73 221 414 75 221 minecraft:mossy_cobblestone
fill 416 73 213 416 76 213 minecraft:mossy_cobblestone
setblock 416 73 217 minecraft:stone_bricks
fill 416 73 218 416 76 218 minecraft:mossy_cobblestone
setblock 416 73 222 minecraft:stone_bricks
setblock 417 73 196 minecraft:stone_bricks
fill 417 73 197 417 76 197 minecraft:mossy_cobblestone
setblock 417 73 200 minecraft:mossy_cobblestone
setblock 417 73 201 minecraft:stone_bricks
setblock 417 73 211 minecraft:stone_bricks
fill 417 73 212 417 76 212 minecraft:mossy_cobblestone
setblock 417 73 216 minecraft:stone_bricks
fill 417 73 217 417 76 217 minecraft:mossy_cobblestone
setblock 417 73 221 minecraft:stone_bricks
fill 417 73 222 417 76 222 minecraft:mossy_cobblestone
setblock 377 74 195 minecraft:stone_bricks
fill 377 74 196 377 77 196 minecraft:mossy_cobblestone
setblock 377 74 200 minecraft:stone_bricks
fill 377 74 201 377 77 201 minecraft:mossy_cobblestone
setblock 377 74 205 minecraft:stone_bricks
fill 377 74 206 377 77 206 minecraft:mossy_cobblestone
setblock 377 74 210 minecraft:stone_bricks
fill 377 74 211 377 77 211 minecraft:mossy_cobblestone
setblock 377 74 215 minecraft:stone_bricks
fill 377 74 216 377 77 216 minecraft:mossy_cobblestone
setblock 377 74 220 minecraft:stone_bricks
fill 377 74 221 377 77 221 minecraft:mossy_cobblestone
setblock 378 74 194 minecraft:stone_bricks
fill 378 74 195 378 77 195 minecraft:mossy_cobblestone
setblock 378 74 198 minecraft:mossy_cobblestone
setblock 378 74 199 minecraft:stone_bricks
fill 378 74 200 378 77 200 minecraft:mossy_cobblestone
setblock 378 74 204 minecraft:stone_bricks
fill 378 74 205 378 77 205 minecraft:mossy_cobblestone
setblock 378 74 210 minecraft:mossy_cobblestone
setblock 378 74 214 minecraft:stone_bricks
fill 378 74 215 378 77 215 minecraft:mossy_cobblestone
setblock 378 74 219 minecraft:stone_bricks
fill 378 74 220 378 77 220 minecraft:mossy_cobblestone
setblock 379 74 194 minecraft:mossy_cobblestone
setblock 379 74 198 minecraft:stone_bricks
fill 379 74 199 379 77 199 minecraft:mossy_cobblestone
setblock 379 74 202 minecraft:mossy_cobblestone
setblock 379 74 218 minecraft:stone_bricks
setblock 380 74 222 minecraft:stone_bricks
setblock 381 74 221 minecraft:stone_bricks
fill 381 74 222 381 77 222 minecraft:mossy_cobblestone
fill 383 74 182 383 74 186 minecraft:spruce_planks
fill 384 74 187 384 74 191 minecraft:spruce_planks
fill 384 74 192 384 74 194 minecraft:stone_bricks
fill 385 74 195 385 74 197 minecraft:stone_bricks
fill 385 74 205 386 74 205 minecraft:stone_bricks
fill 386 74 200 386 74 204 minecraft:stone_bricks
fill 386 74 206 386 74 213 minecraft:stone_bricks
fill 387 74 207 387 74 220 minecraft:stone_bricks
fill 388 74 214 388 74 222 minecraft:stone_bricks
setblock 395 74 182 minecraft:stone_bricks
fill 396 74 182 396 77 182 minecraft:mossy_cobblestone
fill 396 74 222 396 77 222 minecraft:mossy_cobblestone
setblock 398 74 183 minecraft:mossy_cobblestone
setblock 399 74 183 minecraft:stone_bricks
setblock 400 74 182 minecraft:stone_bricks
fill 400 74 183 400 77 183 minecraft:mossy_cobblestone
fill 400 74 220 400 75 220 minecraft:mossy_cobblestone
setblock 400 74 222 minecraft:stone_bricks
fill 401 74 182 401 77 182 minecraft:mossy_cobblestone
setblock 401 74 221 minecraft:stone_bricks
fill 401 74 222 401 77 222 minecraft:mossy_cobblestone
setblock 402 74 220 minecraft:stone_bricks
fill 402 74 221 402 77 221 minecraft:mossy_cobblestone
fill 403 74 220 403 77 220 minecraft:mossy_cobblestone
setblock 405 74 182 minecraft:stone_bricks
setblock 405 74 222 minecraft:stone_bricks
fill 406 74 182 406 77 182 minecraft:mossy_cobblestone
setblock 406 74 221 minecraft:stone_bricks
fill 406 74 222 409 74 222 minecraft:mossy_cobblestone
fill 407 74 221 407 77 221 minecraft:mossy_cobblestone
setblock 410 74 222 minecraft:stone_bricks
fill 411 74 222 411 77 222 minecraft:mossy_cobblestone
fill 413 74 221 413 76 221 minecraft:mossy_cobblestone
setblock 415 74 222 minecraft:stone_bricks
setblock 416 74 216 minecraft:stone_bricks
fill 416 74 217 416 77 217 minecraft:mossy_cobblestone
setblock 416 74 221 minecraft:stone_bricks
fill 416 74 222 416 77 222 minecraft:mossy_cobblestone
setblock 417 74 195 minecraft:stone_bricks
fill 417 74 196 417 77 196 minecraft:mossy_cobblestone
setblock 417 74 200 minecraft:stone_bricks
fill 417 74 201 417 75 203 minecraft:mossy_cobblestone
setblock 417 74 210 minecraft:stone_bricks
fill 417 74 211 417 77 211 minecraft:mossy_cobblestone
setblock 417 74 215 minecraft:stone_bricks
fill 417 74 216 417 77 216 minecraft:mossy_cobblestone
setblock 417 74 220 minecraft:stone_bricks
fill 417 74 221 417 77 221 minecraft:mossy_cobblestone
setblock 377 75 194 minecraft:stone_bricks
fill 377 75 195 377 78 195 minecraft:mossy_cobblestone
setblock 377 75 199 minecraft:stone_bricks
fill 377 75 200 377 78 200 minecraft:mossy_cobblestone
setblock 377 75 203 minecraft:mossy_cobblestone
setblock 377 75 204 minecraft:stone_bricks
fill 377 75 205 377 78 205 minecraft:mossy_cobblestone
setblock 377 75 209 minecraft:stone_bricks
fill 377 75 210 377 78 210 minecraft:mossy_cobblestone
setblock 377 75 214 minecraft:stone_bricks
fill 377 75 215 377 78 215 minecraft:mossy_cobblestone
setblock 377 75 219 minecraft:stone_bricks
fill 377 75 220 377 78 220 minecraft:mossy_cobblestone
setblock 378 75 193 minecraft:stone_bricks
fill 378 75 194 378 78 194 minecraft:mossy_cobblestone
setblock 378 75 198 minecraft:stone_bricks
fill 378 75 199 378 78 199 minecraft:mossy_cobblestone
setblock 378 75 203 minecraft:stone_bricks
fill 378 75 204 378 78 204 minecraft:mossy_cobblestone
fill 378 75 206 378 75 207 minecraft:mossy_cobblestone
setblock 378 75 213 minecraft:stone_bricks
fill 378 75 214 378 78 214 minecraft:mossy_cobblestone
setblock 378 75 218 minecraft:stone_bricks
fill 378 75 219 378 78 219 minecraft:mossy_cobblestone
setblock 379 75 197 minecraft:stone_bricks
fill 379 75 198 380 77 198 minecraft:mossy_cobblestone
setblock 379 75 202 minecraft:stone_bricks
fill 379 75 203 379 78 203 minecraft:mossy_cobblestone
setblock 379 75 222 minecraft:stone_bricks
fill 380 75 197 380 78 197 minecraft:mossy_cobblestone
fill 380 75 199 380 76 199 minecraft:mossy_cobblestone
setblock 380 75 221 minecraft:stone_bricks
fill 380 75 222 380 78 222 minecraft:mossy_cobblestone
fill 381 75 221 381 78 221 minecraft:mossy_cobblestone
setblock 384 75 222 minecraft:stone_bricks
fill 385 75 196 385 75 202 minecraft:spruce_planks
fill 386 75 202 386 75 209 minecraft:spruce_planks
setblock 387 75 211 minecraft:spruce_planks
fill 387 75 212 387 75 219 minecraft:stone_bricks
fill 388 75 217 388 75 222 minecraft:stone_bricks
setblock 394 75 182 minecraft:stone_bricks
fill 395 75 182 395 78 182 minecraft:mossy_cobblestone
fill 395 75 222 395 78 222 minecraft:mossy_cobblestone
setblock 397 75 183 minecraft:mossy_cobblestone
fill 397 75 221 397 77 221 minecraft:mossy_cobblestone
setblock 398 75 183 minecraft:stone_bricks
setblock 399 75 182 minecraft:stone_bricks
fill 399 75 183 399 78 183 minecraft:mossy_cobblestone
fill 399 75 220 399 76 220 minecraft:mossy_cobblestone
setblock 399 75 222 minecraft:stone_bricks
fill 400 75 182 400 78 182 minecraft:mossy_cobblestone
setblock 400 75 221 minecraft:stone_bricks
fill 400 75 222 400 78 222 minecraft:mossy_cobblestone
setblock 401 75 220 minecraft:stone_bricks
fill 401 75 221 401 78 221 minecraft:mossy_cobblestone
fill 402 75 220 402 78 220 minecraft:mossy_cobblestone
setblock 403 75 183 minecraft:stone_bricks
setblock 404 75 182 minecraft:stone_bricks
setblock 404 75 222 minecraft:stone_bricks
fill 405 75 182 405 78 182 minecraft:mossy_cobblestone
setblock 405 75 221 minecraft:stone_bricks
fill 405 75 222 408 75 222 minecraft:mossy_cobblestone
fill 406 75 221 406 78 221 minecraft:mossy_cobblestone
setblock 409 75 221 minecraft:mossy_cobblestone
setblock 409 75 222 minecraft:stone_bricks
fill 410 75 222 410 78 222 minecraft:mossy_cobblestone
fill 412 75 221 412 77 221 minecraft:mossy_cobblestone
setblock 414 75 222 minecraft:stone_bricks
fill 415 75 218 415 76 219 minecraft:mossy_cobblestone
setblock 415 75 221 minecraft:stone_bricks
fill 415 75 222 415 78 222 minecraft:mossy_cobblestone
setblock 416 75 215 minecraft:stone_bricks
fill 416 75 216 416 78 216 minecraft:mossy_cobblestone
setblock 416 75 220 minecraft:stone_bricks
fill 416 75 221 416 78 221 minecraft:mossy_cobblestone
setblock 417 75 194 minecraft:stone_bricks
fill 417 75 195 417 78 195 minecraft:mossy_cobblestone
setblock 417 75 198 minecraft:mossy_cobblestone
setblock 417 75 199 minecraft:stone_bricks
fill 417 75 200 417 78 200 minecraft:mossy_cobblestone
setblock 417 75 204 minecraft:stone_bricks
fill 417 75 205 417 75 208 minecraft:mossy_cobblestone
setblock 417 75 209 minecraft:stone_bricks
fill 417 75 210 417 78 210 minecraft:mossy_cobblestone
setblock 417 75 214 minecraft:stone_bricks
fill 417 75 215 417 78 215 minecraft:mossy_cobblestone
setblock 417 75 219 minecraft:stone_bricks
fill 417 75 220 417 78 220 minecraft:mossy_cobblestone
fill 377 76 191 377 77 191 minecraft:mossy_cobblestone
setblock 377 76 193 minecraft:stone_bricks
fill 377 76 194 377 79 194 minecraft:mossy_cobblestone
setblock 377 76 198 minecraft:stone_bricks
fill 377 76 199 377 79 199 minecraft:mossy_cobblestone
setblock 377 76 203 minecraft:stone_bricks
fill 377 76 204 377 79 204 minecraft:mossy_cobblestone
setblock 377 76 208 minecraft:stone_bricks
fill 377 76 209 377 79 209 minecraft:mossy_cobblestone
setblock 377 76 213 minecraft:stone_bricks
fill 377 76 214 377 79 214 minecraft:mossy_cobblestone
setblock 377 76 218 minecraft:stone_bricks
fill 377 76 219 377 79 219 minecraft:mossy_cobblestone
setblock 378 76 182 minecraft:stone_bricks
fill 378 76 193 378 79 193 minecraft:mossy_cobblestone
setblock 378 76 197 minecraft:stone_bricks
fill 378 76 198 378 79 198 minecraft:mossy_cobblestone
setblock 378 76 201 minecraft:mossy_cobblestone
setblock 378 76 202 minecraft:stone_bricks
fill 378 76 203 378 79 203 minecraft:mossy_cobblestone
setblock 378 76 206 minecraft:mossy_cobblestone
setblock 378 76 207 minecraft:stone_bricks
fill 378 76 208 378 79 208 minecraft:mossy_cobblestone
setblock 378 76 212 minecraft:stone_bricks
fill 378 76 213 378 79 213 minecraft:mossy_cobblestone
setblock 378 76 217 minecraft:stone_bricks
fill 378 76 218 378 79 218 minecraft:mossy_cobblestone
setblock 378 76 222 minecraft:stone_bricks
fill 379 76 182 382 76 182 minecraft:mossy_cobblestone
fill 379 76 194 379 77 194 minecraft:mossy_cobblestone
setblock 379 76 196 minecraft:stone_bricks
fill 379 76 197 379 79 197 minecraft:mossy_cobblestone
setblock 379 76 201 minecraft:stone_bricks
fill 379 76 202 379 79 202 minecraft:mossy_cobblestone
fill 379 76 204 379 77 204 minecraft:mossy_cobblestone
setblock 379 76 221 minecraft:stone_bricks
fill 379 76 222 379 79 222 minecraft:mossy_cobblestone
setblock 380 76 200 minecraft:stone_bricks
fill 380 76 201 380 79 201 minecraft:mossy_cobblestone
fill 380 76 221 380 79 221 minecraft:mossy_cobblestone
setblock 383 76 222 minecraft:stone_bricks
fill 384 76 222 384 79 222 minecraft:mossy_cobblestone
fill 387 76 213 387 76 216 minecraft:spruce_planks
fill 388 76 218 388 76 222 minecraft:spruce_planks
setblock 393 76 182 minecraft:stone_bricks
fill 394 76 182 394 79 182 minecraft:mossy_cobblestone
fill 394 76 222 394 79 222 minecraft:mossy_cobblestone
setblock 396 76 183 minecraft:mossy_cobblestone
fill 396 76 221 396 78 221 minecraft:mossy_cobblestone
setblock 397 76 183 minecraft:stone_bricks
setblock 398 76 182 minecraft:stone_bricks
fill 398 76 183 398 79 183 minecraft:mossy_cobblestone
fill 398 76 220 398 77 220 minecraft:mossy_cobblestone
setblock 398 76 222 minecraft:stone_bricks
fill 399 76 182 399 79 182 minecraft:mossy_cobblestone
setblock 399 76 221 minecraft:stone_bricks
fill 399 76 222 399 79 222 minecraft:mossy_cobblestone
setblock 400 76 220 minecraft:stone_bricks
fill 400 76 221 400 79 221 minecraft:mossy_cobblestone
fill 401 76 220 401 79 220 minecraft:mossy_cobblestone
setblock 402 76 183 minecraft:stone_bricks
setblock 403 76 182 minecraft:stone_bricks
fill 403 76 183 403 79 183 minecraft:mossy_cobblestone
setblock 403 76 222 minecraft:stone_bricks
fill 404 76 182 404 79 182 minecraft:mossy_cobblestone
setblock 404 76 221 minecraft:stone_bricks
fill 404 76 222 407 76 222 minecraft:mossy_cobblestone
fill 405 76 221 405 79 221 minecraft:mossy_cobblestone
setblock 408 76 222 minecraft:stone_bricks
setblock 409 76 221 minecraft:stone_bricks
fill 409 76 222 409 79 222 minecraft:mossy_cobblestone
fill 410 76 221 411 78 221 minecraft:mossy_cobblestone
setblock 413 76 222 minecraft:stone_bricks
setblock 414 76 221 minecraft:stone_bricks
fill 414 76 222 414 79 222 minecraft:mossy_cobblestone
fill 415 76 217 415 78 217 minecraft:mossy_cobblestone
setblock 415 76 220 minecraft:stone_bricks
fill 415 76 221 415 79 221 minecraft:mossy_cobblestone
fill 416 76 182 417 76 182 minecraft:mossy_cobblestone
setblock 416 76 199 minecraft:stone_bricks
fill 416 76 200 416 79 200 minecraft:mossy_cobblestone
setblock 416 76 214 minecraft:stone_bricks
fill 416 76 215 416 79 215 minecraft:mossy_cobblestone
setblock 416 76 219 minecraft:stone_bricks
fill 416 76 220 416 79 220 minecraft:mossy_cobblestone
fill 417 76 194 417 79 194 minecraft:mossy_cobblestone
setblock 417 76 198 minecraft:stone_bricks
fill 417 76 199 417 79 199 minecraft:mossy_cobblestone
fill 417 76 201 417 76 202 minecraft:mossy_cobblestone
setblock 417 76 203 minecraft:stone_bricks
fill 417 76 204 417 76 207 minecraft:mossy_cobblestone
setblock 417 76 208 minecraft:stone_bricks
fill 417 76 209 417 79 209 minecraft:mossy_cobblestone
setblock 417 76 213 minecraft:stone_bricks
fill 417 76 214 417 79 214 minecraft:mossy_cobblestone
setblock 417 76 218 minecraft:stone_bricks
fill 417 76 219 417 79 219 minecraft:mossy_cobblestone
setblock 377 77 182 minecraft:stone_bricks
fill 377 77 183 377 80 183 minecraft:mossy_cobblestone
setblock 377 77 192 minecraft:stone_bricks
fill 377 77 193 377 80 193 minecraft:mossy_cobblestone
setblock 377 77 197 minecraft:stone_bricks
fill 377 77 198 377 80 198 minecraft:mossy_cobblestone
setblock 377 77 202 minecraft:stone_bricks
fill 377 77 203 377 80 203 minecraft:mossy_cobblestone
setblock 377 77 207 minecraft:stone_bricks
fill 377 77 208 377 80 208 minecraft:mossy_cobblestone
setblock 377 77 212 minecraft:stone_bricks
fill 377 77 213 377 80 213 minecraft:mossy_cobblestone
setblock 377 77 217 minecraft:stone_bricks
fill 377 77 218 377 80 218 minecraft:mossy_cobblestone
setblock 377 77 222 minecraft:stone_bricks
fill 378 77 182 381 77 182 minecraft:mossy_cobblestone
setblock 378 77 196 minecraft:stone_bricks
fill 378 77 197 378 80 197 minecraft:mossy_cobblestone
setblock 378 77 201 minecraft:stone_bricks
fill 378 77 202 378 80 202 minecraft:mossy_cobblestone
setblock 378 77 206 minecraft:stone_bricks
fill 378 77 207 378 80 207 minecraft:mossy_cobblestone
fill 378 77 209 378 77 210 minecraft:mossy_cobblestone
setblock 378 77 211 minecraft:stone_bricks
fill 378 77 212 378 80 212 minecraft:mossy_cobblestone
setblock 378 77 216 minecraft:stone_bricks
fill 378 77 217 378 80 217 minecraft:mossy_cobblestone
setblock 378 77 221 minecraft:stone_bricks
fill 378 77 222 378 80 222 minecraft:mossy_cobblestone
setblock 379 77 195 minecraft:stone_bricks
fill 379 77 196 379 80 196 minecraft:mossy_cobblestone
setblock 379 77 200 minecraft:stone_bricks
fill 379 77 201 379 80 201 minecraft:mossy_cobblestone
setblock 379 77 205 minecraft:stone_bricks
fill 379 77 221 379 80 221 minecraft:mossy_cobblestone
setblock 380 77 199 minecraft:stone_bricks
fill 380 77 200 380 80 200 minecraft:mossy_cobblestone
fill 380 77 202 380 78 202 minecraft:mossy_cobblestone
setblock 382 77 182 minecraft:stone_bricks
setblock 382 77 222 minecraft:stone_bricks
fill 383 77 182 383 80 182 minecraft:mossy_cobblestone
fill 383 77 222 383 80 222 minecraft:mossy_cobblestone
setblock 391 77 182 minecraft:mossy_cobblestone
setblock 392 77 182 minecraft:stone_bricks
setblock 392 77 222 minecraft:stone_bricks
fill 393 77 182 393 80 182 minecraft:mossy_cobblestone
fill 393 77 222 393 80 222 minecraft:mossy_cobblestone
fill 394 77 183 395 77 183 minecraft:mossy_cobblestone
fill 395 77 221 395 79 221 minecraft:mossy_cobblestone
setblock 396 77 183 minecraft:stone_bricks
setblock 397 77 182 minecraft:stone_bricks
fill 397 77 183 397 80 183 minecraft:mossy_cobblestone
fill 397 77 220 397 78 220 minecraft:mossy_cobblestone
setblock 397 77 222 minecraft:stone_bricks
fill 398 77 182 398 80 182 minecraft:mossy_cobblestone
setblock 398 77 221 minecraft:stone_bricks
fill 398 77 222 398 80 222 minecraft:mossy_cobblestone
setblock 399 77 184 minecraft:mossy_cobblestone
setblock 399 77 220 minecraft:stone_bricks
fill 399 77 221 399 80 221 minecraft:mossy_cobblestone
fill 400 77 220 400 80 220 minecraft:mossy_cobblestone
setblock 401 77 183 minecraft:stone_bricks
setblock 402 77 182 minecraft:stone_bricks
fill 402 77 183 402 80 183 minecraft:mossy_cobblestone
setblock 402 77 222 minecraft:stone_bricks
fill 403 77 182 403 80 182 minecraft:mossy_cobblestone
setblock 403 77 221 minecraft:stone_bricks
fill 403 77 222 406 77 222 minecraft:mossy_cobblestone
fill 404 77 183 404 78 183 minecraft:mossy_cobblestone
setblock 404 77 220 minecraft:stone_bricks
fill 404 77 221 404 80 221 minecraft:mossy_cobblestone
setblock 407 77 182 minecraft:stone_bricks
setblock 407 77 222 minecraft:stone_bricks
fill 408 77 182 408 80 182 minecraft:mossy_cobblestone
setblock 408 77 221 minecraft:stone_bricks
fill 408 77 222 408 80 222 minecraft:mossy_cobblestone
fill 409 77 221 409 80 221 minecraft:mossy_cobblestone
setblock 412 77 222 minecraft:stone_bricks
setblock 413 77 220 minecraft:mossy_cobblestone
setblock 413 77 221 minecraft:stone_bricks
fill 413 77 222 413 80 222 minecraft:mossy_cobblestone
fill 414 77 182 416 77 182 minecraft:mossy_cobblestone
setblock 414 77 220 minecraft:stone_bricks
fill 414 77 221 414 80 221 minecraft:mossy_cobblestone
setblock 415 77 218 minecraft:mossy_cobblestone
setblock 415 77 219 minecraft:stone_bricks
fill 415 77 220 415 80 220 minecraft:mossy_cobblestone
setblock 416 77 197 minecraft:mossy_cobblestone
setblock 416 77 198 minecraft:stone_bricks
fill 416 77 199 416 80 199 minecraft:mossy_cobblestone
fill 416 77 201 416 77 202 minecraft:mossy_cobblestone
setblock 416 77 203 minecraft:stone_bricks
fill 416 77 204 417 78 205 minecraft:mossy_cobblestone
setblock 416 77 212 minecraft:mossy_cobblestone
setblock 416 77 213 minecraft:stone_bricks
fill 416 77 214 416 80 214 minecraft:mossy_cobblestone
setblock 416 77 218 minecraft:stone_bricks
fill 416 77 219 416 80 219 minecraft:mossy_cobblestone
setblock 417 77 182 minecraft:stone_bricks
fill 417 77 183 417 80 183 minecraft:mossy_cobblestone
fill 417 77 193 417 80 193 minecraft:mossy_cobblestone
setblock 417 77 197 minecraft:stone_bricks
fill 417 77 198 417 80 198 minecraft:mossy_cobblestone
setblock 417 77 201 minecraft:mossy_cobblestone
setblock 417 77 202 minecraft:stone_bricks
fill 417 77 203 417 80 203 minecraft:mossy_cobblestone
setblock 417 77 206 minecraft:mossy_cobblestone
setblock 417 77 207 minecraft:stone_bricks
fill 417 77 208 417 80 208 minecraft:mossy_cobblestone
setblock 417 77 212 minecraft:stone_bricks
fill 417 77 213 417 80 213 minecraft:mossy_cobblestone
setblock 417 77 217 minecraft:stone_bricks
fill 417 77 218 417 80 218 minecraft:mossy_cobblestone
setblock 417 77 222 minecraft:stone_bricks
fill 377 78 182 380 78 182 minecraft:mossy_cobblestone
fill 377 78 184 377 78 185 minecraft:mossy_cobblestone
fill 377 78 189 377 78 190 minecraft:mossy_cobblestone
setblock 377 78 191 minecraft:stone_bricks
fill 377 78 192 378 80 192 minecraft:mossy_cobblestone
setblock 377 78 196 minecraft:stone_bricks
fill 377 78 197 377 81 197 minecraft:mossy_cobblestone
setblock 377 78 201 minecraft:stone_bricks
fill 377 78 202 377 81 202 minecraft:mossy_cobblestone
setblock 377 78 206 minecraft:stone_bricks
fill 377 78 207 377 81 207 minecraft:mossy_cobblestone
setblock 377 78 211 minecraft:stone_bricks
fill 377 78 212 377 81 212 minecraft:mossy_cobblestone
setblock 377 78 216 minecraft:stone_bricks
fill 377 78 217 377 81 217 minecraft:mossy_cobblestone
setblock 377 78 221 minecraft:stone_bricks
fill 377 78 222 377 81 222 minecraft:mossy_cobblestone
setblock 378 78 195 minecraft:stone_bricks
fill 378 78 196 378 81 196 minecraft:mossy_cobblestone
setblock 378 78 200 minecraft:stone_bricks
fill 378 78 201 378 81 201 minecraft:mossy_cobblestone
setblock 378 78 205 minecraft:stone_bricks
fill 378 78 206 379 80 206 minecraft:mossy_cobblestone
setblock 378 78 209 minecraft:mossy_cobblestone
setblock 378 78 210 minecraft:stone_bricks
fill 378 78 211 378 81 211 minecraft:mossy_cobblestone
setblock 378 78 215 minecraft:stone_bricks
fill 378 78 216 378 81 216 minecraft:mossy_cobblestone
setblock 378 78 220 minecraft:stone_bricks
fill 378 78 221 378 81 221 minecraft:mossy_cobblestone
setblock 379 78 194 minecraft:stone_bricks
fill 379 78 195 379 81 195 minecraft:mossy_cobblestone
setblock 379 78 198 minecraft:mossy_cobblestone
setblock 379 78 199 minecraft:stone_bricks
fill 379 78 200 379 81 200 minecraft:mossy_cobblestone
setblock 379 78 204 minecraft:stone_bricks
fill 379 78 205 379 81 205 minecraft:mossy_cobblestone
setblock 380 78 198 minecraft:stone_bricks
fill 380 78 199 380 81 199 minecraft:mossy_cobblestone
setblock 380 78 203 minecraft:stone_bricks
setblock 381 78 182 minecraft:stone_bricks
setblock 381 78 222 minecraft:stone_bricks
fill 382 78 182 382 81 182 minecraft:mossy_cobblestone
setblock 382 78 221 minecraft:stone_bricks
fill 382 78 222 382 81 222 minecraft:mossy_cobblestone
fill 384 78 182 385 78 182 minecraft:mossy_cobblestone
fill 389 78 182 390 78 182 minecraft:mossy_cobblestone
setblock 391 78 182 minecraft:stone_bricks
setblock 391 78 222 minecraft:stone_bricks
fill 392 78 182 392 81 182 minecraft:mossy_cobblestone
fill 392 78 222 392 81 222 minecraft:mossy_cobblestone
fill 393 78 183 394 78 183 minecraft:mossy_cobblestone
fill 394 78 221 394 80 221 minecraft:mossy_cobblestone
setblock 395 78 183 minecraft:stone_bricks
setblock 396 78 182 minecraft:stone_bricks
fill 396 78 183 396 80 184 minecraft:mossy_cobblestone
fill 396 78 220 396 79 220 minecraft:mossy_cobblestone
setblock 396 78 222 minecraft:stone_bricks
fill 397 78 182 397 81 182 minecraft:mossy_cobblestone
fill 397 78 184 398 78 184 minecraft:mossy_cobblestone
setblock 397 78 221 minecraft:stone_bricks
fill 397 78 222 397 81 222 minecraft:mossy_cobblestone
setblock 398 78 220 minecraft:stone_bricks
fill 398 78 221 398 81 221 minecraft:mossy_cobblestone
setblock 399 78 184 minecraft:stone_bricks
fill 399 78 220 399 81 220 minecraft:mossy_cobblestone
setblock 400 78 183 minecraft:stone_bricks
fill 400 78 184 401 80 184 minecraft:mossy_cobblestone
setblock 401 78 182 minecraft:stone_bricks
fill 401 78 183 401 81 183 minecraft:mossy_cobblestone
setblock 401 78 222 minecraft:stone_bricks
fill 402 78 182 402 81 182 minecraft:mossy_cobblestone
setblock 402 78 221 minecraft:stone_bricks
fill 402 78 222 405 78 222 minecraft:mossy_cobblestone
setblock 403 78 220 minecraft:stone_bricks
fill 403 78 221 403 81 221 minecraft:mossy_cobblestone
fill 404 78 220 405 80 220 minecraft:mossy_cobblestone
setblock 406 78 182 minecraft:stone_bricks
setblock 406 78 222 minecraft:stone_bricks
fill 407 78 182 407 81 182 minecraft:mossy_cobblestone
setblock 407 78 221 minecraft:stone_bricks
fill 407 78 222 407 81 222 minecraft:mossy_cobblestone
fill 408 78 221 408 81 221 minecraft:mossy_cobblestone
fill 409 78 182 410 78 182 minecraft:mossy_cobblestone
setblock 411 78 182 minecraft:stone_bricks
setblock 411 78 222 minecraft:stone_bricks
fill 412 78 182 415 78 182 minecraft:mossy_cobblestone
setblock 412 78 220 minecraft:mossy_cobblestone
setblock 412 78 221 minecraft:stone_bricks
fill 412 78 222 412 81 222 minecraft:mossy_cobblestone
setblock 413 78 220 minecraft:stone_bricks
fill 413 78 221 413 81 221 minecraft:mossy_cobblestone
fill 414 78 220 414 81 220 minecraft:mossy_cobblestone
fill 415 78 216 415 79 216 minecraft:mossy_cobblestone
setblock 415 78 218 minecraft:stone_bricks
fill 415 78 219 415 81 219 minecraft:mossy_cobblestone
setblock 416 78 182 minecraft:stone_bricks
setblock 416 78 196 minecraft:mossy_cobblestone
setblock 416 78 197 minecraft:stone_bricks
fill 416 78 198 416 81 198 minecraft:mossy_cobblestone
setblock 416 78 201 minecraft:mossy_cobblestone
setblock 416 78 202 minecraft:stone_bricks
fill 416 78 203 416 81 203 minecraft:mossy_cobblestone
setblock 416 78 206 minecraft:mossy_cobblestone
setblock 416 78 207 minecraft:stone_bricks
fill 416 78 208 416 78 211 minecraft:mossy_cobblestone
setblock 416 78 212 minecraft:stone_bricks
fill 416 78 213 416 81 213 minecraft:mossy_cobblestone
setblock 416 78 217 minecraft:stone_bricks
fill 416 78 218 416 81 218 minecraft:mossy_cobblestone
setblock 416 78 222 minecraft:stone_bricks
fill 417 78 182 417 81 182 minecraft:mossy_cobblestone
fill 417 78 184 417 79 184 minecraft:mossy_cobblestone
setblock 417 78 196 minecraft:stone_bricks
fill 417 78 197 417 81 197 minecraft:mossy_cobblestone
setblock 417 78 201 minecraft:stone_bricks
fill 417 78 202 417 81 202 minecraft:mossy_cobblestone
setblock 417 78 206 minecraft:stone_bricks
fill 417 78 207 417 81 207 minecraft:mossy_cobblestone
setblock 417 78 211 minecraft:stone_bricks
fill 417 78 212 417 81 212 minecraft:mossy_cobblestone
setblock 417 78 216 minecraft:stone_bricks
fill 417 78 217 417 81 217 minecraft:mossy_cobblestone
setblock 417 78 221 minecraft:stone_bricks
fill 417 78 222 417 81 222 minecraft:mossy_cobblestone
fill 377 79 182 379 79 182 minecraft:mossy_cobblestone
setblock 377 79 184 minecraft:mossy_cobblestone
setblock 377 79 185 minecraft:stone_bricks
fill 377 79 186 377 79 189 minecraft:mossy_cobblestone
setblock 377 79 190 minecraft:stone_bricks
fill 377 79 191 377 82 191 minecraft:mossy_cobblestone
setblock 377 79 195 minecraft:stone_bricks
fill 377 79 196 377 82 196 minecraft:mossy_cobblestone
setblock 377 79 200 minecraft:stone_bricks
fill 377 79 201 377 82 201 minecraft:mossy_cobblestone
setblock 377 79 205 minecraft:stone_bricks
fill 377 79 206 377 82 206 minecraft:mossy_cobblestone
setblock 377 79 210 minecraft:stone_bricks
fill 377 79 211 377 82 211 minecraft:mossy_cobblestone
setblock 377 79 215 minecraft:stone_bricks
fill 377 79 216 377 82 216 minecraft:mossy_cobblestone
setblock 377 79 220 minecraft:stone_bricks
fill 377 79 221 377 82 221 minecraft:mossy_cobblestone
setblock 378 79 183 minecraft:mossy_cobblestone
setblock 378 79 184 minecraft:stone_bricks
setblock 378 79 194 minecraft:stone_bricks
fill 378 79 195 378 82 195 minecraft:mossy_cobblestone
setblock 378 79 199 minecraft:stone_bricks
fill 378 79 200 378 82 200 minecraft:mossy_cobblestone
setblock 378 79 204 minecraft:stone_bricks
fill 378 79 205 378 82 205 minecraft:mossy_cobblestone
setblock 378 79 209 minecraft:stone_bricks
fill 378 79 210 378 82 210 minecraft:mossy_cobblestone
setblock 378 79 214 minecraft:stone_bricks
fill 378 79 215 378 81 215 minecraft:mossy_cobblestone
setblock 378 79 219 minecraft:stone_bricks
fill 378 79 220 378 82 220 minecraft:mossy_cobblestone
setblock 379 79 183 minecraft:stone_bricks
fill 379 79 194 379 81 194 minecraft:mossy_cobblestone
setblock 379 79 198 minecraft:stone_bricks
fill 379 79 199 379 82 199 minecraft:mossy_cobblestone
setblock 379 79 203 minecraft:stone_bricks
fill 379 79 204 380 81 204 minecraft:mossy_cobblestone
setblock 379 79 207 minecraft:mossy_cobblestone
setblock 380 79 182 minecraft:stone_bricks
fill 380 79 183 381 81 183 minecraft:mossy_cobblestone
setblock 380 79 197 minecraft:stone_bricks
fill 380 79 198 380 81 198 minecraft:mossy_cobblestone
setblock 380 79 202 minecraft:stone_bricks
fill 380 79 203 380 82 203 minecraft:mossy_cobblestone
setblock 380 79 222 minecraft:stone_bricks
fill 381 79 182 381 82 182 minecraft:mossy_cobblestone
setblock 381 79 221 minecraft:stone_bricks
fill 381 79 222 381 82 222 minecraft:mossy_cobblestone
setblock 382 79 221 minecraft:mossy_cobblestone
setblock 384 79 182 minecraft:mossy_cobblestone
setblock 385 79 182 minecraft:stone_bricks
setblock 385 79 222 minecraft:stone_bricks
fill 386 79 182 389 79 182 minecraft:mossy_cobblestone
setblock 389 79 222 minecraft:mossy_cobblestone
setblock 390 79 182 minecraft:stone_bricks
setblock 390 79 222 minecraft:stone_bricks
fill 391 79 182 391 81 183 minecraft:mossy_cobblestone
fill 391 79 222 391 82 222 minecraft:mossy_cobblestone
fill 392 79 183 393 79 183 minecraft:mossy_cobblestone
fill 393 79 221 393 81 221 minecraft:mossy_cobblestone
setblock 394 79 183 minecraft:stone_bricks
fill 394 79 184 395 81 184 minecraft:mossy_cobblestone
setblock 395 79 182 minecraft:stone_bricks
fill 395 79 183 395 82 183 minecraft:mossy_cobblestone
fill 395 79 220 395 80 220 minecraft:mossy_cobblestone
setblock 395 79 222 minecraft:stone_bricks
fill 396 79 182 396 82 182 minecraft:mossy_cobblestone
setblock 396 79 221 minecraft:stone_bricks
fill 396 79 222 396 82 222 minecraft:mossy_cobblestone
setblock 397 79 184 minecraft:mossy_cobblestone
setblock 397 79 220 minecraft:stone_bricks
fill 397 79 221 397 82 221 minecraft:mossy_cobblestone
setblock 398 79 184 minecraft:stone_bricks
fill 398 79 220 398 82 220 minecraft:mossy_cobblestone
setblock 399 79 183 minecraft:stone_bricks
fill 399 79 184 399 82 184 minecraft:mossy_cobblestone
setblock 400 79 182 minecraft:stone_bricks
fill 400 79 183 400 82 183 minecraft:mossy_cobblestone
setblock 400 79 222 minecraft:stone_bricks
fill 401 79 182 401 82 182 minecraft:mossy_cobblestone
setblock 401 79 221 minecraft:stone_bricks
fill 401 79 222 404 79 222 minecraft:mossy_cobblestone
setblock 402 79 220 minecraft:stone_bricks
fill 402 79 221 402 82 221 minecraft:mossy_cobblestone
fill 403 79 220 403 82 220 minecraft:mossy_cobblestone
setblock 404 79 183 minecraft:stone_bricks
setblock 405 79 182 minecraft:stone_bricks
fill 405 79 183 405 82 183 minecraft:mossy_cobblestone
setblock 405 79 222 minecraft:stone_bricks
fill 406 79 182 406 82 182 minecraft:mossy_cobblestone
setblock 406 79 221 minecraft:stone_bricks
fill 406 79 222 406 82 222 minecraft:mossy_cobblestone
fill 407 79 221 407 82 221 minecraft:mossy_cobblestone
setblock 409 79 182 minecraft:mossy_cobblestone
setblock 410 79 182 minecraft:stone_bricks
setblock 410 79 221 minecraft:mossy_cobblestone
setblock 410 79 222 minecraft:stone_bricks
fill 411 79 182 414 79 182 minecraft:mossy_cobblestone
setblock 411 79 220 minecraft:mossy_cobblestone
setblock 411 79 221 minecraft:stone_bricks
fill 411 79 222 411 82 222 minecraft:mossy_cobblestone
setblock 412 79 220 minecraft:stone_bricks
fill 412 79 221 412 82 221 minecraft:mossy_cobblestone
fill 413 79 220 413 82 220 minecraft:mossy_cobblestone
setblock 415 79 182 minecraft:stone_bricks
fill 415 79 200 415 79 201 minecraft:mossy_cobblestone
setblock 415 79 202 minecraft:stone_bricks
fill 415 79 203 415 81 204 minecraft:mossy_cobblestone
setblock 415 79 217 minecraft:stone_bricks
fill 415 79 218 415 82 218 minecraft:mossy_cobblestone
setblock 415 79 222 minecraft:stone_bricks
fill 416 79 182 416 81 183 minecraft:mossy_cobblestone
setblock 416 79 196 minecraft:stone_bricks
fill 416 79 197 416 82 197 minecraft:mossy_cobblestone
setblock 416 79 201 minecraft:stone_bricks
fill 416 79 202 416 82 202 minecraft:mossy_cobblestone
fill 416 79 204 416 79 205 minecraft:mossy_cobblestone
setblock 416 79 206 minecraft:stone_bricks
fill 416 79 207 416 79 210 minecraft:mossy_cobblestone
setblock 416 79 211 minecraft:stone_bricks
fill 416 79 212 416 82 212 minecraft:mossy_cobblestone
setblock 416 79 216 minecraft:stone_bricks
fill 416 79 217 416 82 217 minecraft:mossy_cobblestone
setblock 416 79 221 minecraft:stone_bricks
fill 416 79 222 416 82 222 minecraft:mossy_cobblestone
setblock 417 79 185 minecraft:stone_bricks
fill 417 79 186 417 82 186 minecraft:mossy_cobblestone
fill 417 79 192 417 81 192 minecraft:mossy_cobblestone
setblock 417 79 195 minecraft:stone_bricks
fill 417 79 196 417 82 196 minecraft:mossy_cobblestone
setblock 417 79 200 minecraft:stone_bricks
fill 417 79 201 417 82 201 minecraft:mossy_cobblestone
setblock 417 79 204 minecraft:mossy_cobblestone
setblock 417 79 205 minecraft:stone_bricks
fill 417 79 206 417 82 206 minecraft:mossy_cobblestone
setblock 417 79 210 minecraft:stone_bricks
fill 417 79 211 417 82 211 minecraft:mossy_cobblestone
setblock 417 79 215 minecraft:stone_bricks
fill 417 79 216 417 82 216 minecraft:mossy_cobblestone
setblock 417 79 220 minecraft:stone_bricks
fill 417 79 221 417 82 221 minecraft:mossy_cobblestone
fill 377 80 182 378 80 182 minecraft:mossy_cobblestone
setblock 377 80 184 minecraft:stone_bricks
fill 377 80 185 377 80 188 minecraft:mossy_cobblestone
setblock 377 80 189 minecraft:stone_bricks
fill 377 80 190 377 83 190 minecraft:mossy_cobblestone
setblock 377 80 194 minecraft:stone_bricks
fill 377 80 195 377 83 195 minecraft:mossy_cobblestone
setblock 377 80 199 minecraft:stone_bricks
fill 377 80 200 377 83 200 minecraft:mossy_cobblestone
setblock 377 80 204 minecraft:stone_bricks
fill 377 80 205 377 83 205 minecraft:mossy_cobblestone
setblock 377 80 209 minecraft:stone_bricks
fill 377 80 210 377 83 210 minecraft:mossy_cobblestone
setblock 377 80 214 minecraft:stone_bricks
fill 377 80 215 377 83 215 minecraft:mossy_cobblestone
setblock 377 80 219 minecraft:stone_bricks
fill 377 80 220 377 83 220 minecraft:mossy_cobblestone
setblock 378 80 183 minecraft:stone_bricks
fill 378 80 184 378 81 186 minecraft:mossy_cobblestone
fill 378 80 191 378 81 191 minecraft:mossy_cobblestone
setblock 378 80 193 minecraft:stone_bricks
fill 378 80 194 378 83 194 minecraft:mossy_cobblestone
setblock 378 80 198 minecraft:stone_bricks
fill 378 80 199 378 83 199 minecraft:mossy_cobblestone
setblock 378 80 203 minecraft:stone_bricks
fill 378 80 204 378 83 204 minecraft:mossy_cobblestone
setblock 378 80 208 minecraft:stone_bricks
fill 378 80 209 378 83 209 minecraft:mossy_cobblestone
setblock 378 80 213 minecraft:stone_bricks
fill 378 80 214 378 81 214 minecraft:mossy_cobblestone
setblock 378 80 218 minecraft:stone_bricks
fill 378 80 219 378 82 219 minecraft:mossy_cobblestone
setblock 379 80 182 minecraft:stone_bricks
fill 379 80 183 379 83 183 minecraft:mossy_cobblestone
setblock 379 80 197 minecraft:stone_bricks
fill 379 80 198 379 83 198 minecraft:mossy_cobblestone
setblock 379 80 202 minecraft:stone_bricks
fill 379 80 203 379 83 203 minecraft:mossy_cobblestone
setblock 379 80 207 minecraft:stone_bricks
fill 379 80 208 379 83 208 minecraft:mossy_cobblestone
setblock 379 80 222 minecraft:stone_bricks
fill 380 80 182 380 83 182 minecraft:mossy_cobblestone
setblock 380 80 197 minecraft:mossy_cobblestone
setblock 380 80 201 minecraft:stone_bricks
fill 380 80 202 380 83 202 minecraft:mossy_cobblestone
setblock 380 80 221 minecraft:stone_bricks
fill 380 80 222 380 83 222 minecraft:mossy_cobblestone
fill 381 80 221 381 81 221 minecraft:mossy_cobblestone
setblock 382 80 183 minecraft:mossy_cobblestone
setblock 384 80 182 minecraft:stone_bricks
setblock 384 80 222 minecraft:stone_bricks
fill 385 80 182 388 80 182 minecraft:mossy_cobblestone
fill 385 80 222 388 80 222 minecraft:mossy_cobblestone
setblock 389 80 182 minecraft:stone_bricks
fill 389 80 183 390 82 183 minecraft:mossy_cobblestone
setblock 389 80 222 minecraft:stone_bricks
fill 390 80 182 390 83 182 minecraft:mossy_cobblestone
fill 390 80 222 390 83 222 minecraft:mossy_cobblestone
setblock 392 80 183 minecraft:mossy_cobblestone
setblock 392 80 184 minecraft:stone_bricks
fill 392 80 221 392 82 221 minecraft:mossy_cobblestone
setblock 393 80 183 minecraft:stone_bricks
fill 393 80 184 393 83 184 minecraft:mossy_cobblestone
setblock 394 80 182 minecraft:stone_bricks
fill 394 80 183 394 83 183 minecraft:mossy_cobblestone
fill 394 80 220 394 81 220 minecraft:mossy_cobblestone
setblock 394 80 222 minecraft:stone_bricks
fill 395 80 182 395 83 182 minecraft:mossy_cobblestone
setblock 395 80 221 minecraft:stone_bricks
fill 395 80 222 395 83 222 minecraft:mossy_cobblestone
setblock 396 80 220 minecraft:stone_bricks
fill 396 80 221 396 83 221 minecraft:mossy_cobblestone
setblock 397 80 184 minecraft:stone_bricks
fill 397 80 185 397 83 185 minecraft:mossy_cobblestone
fill 397 80 220 397 83 220 minecraft:mossy_cobblestone
setblock 398 80 183 minecraft:stone_bricks
fill 398 80 184 398 83 184 minecraft:mossy_cobblestone
setblock 399 80 182 minecraft:stone_bricks
fill 399 80 183 399 83 183 minecraft:mossy_cobblestone
setblock 399 80 222 minecraft:stone_bricks
fill 400 80 182 400 83 182 minecraft:mossy_cobblestone
setblock 400 80 221 minecraft:stone_bricks
fill 400 80 222 403 80 222 minecraft:mossy_cobblestone
setblock 401 80 220 minecraft:stone_bricks
fill 401 80 221 401 83 221 minecraft:mossy_cobblestone
setblock 402 80 184 minecraft:stone_bricks
fill 402 80 220 402 82 220 minecraft:mossy_cobblestone
setblock 403 80 183 minecraft:stone_bricks
setblock 404 80 182 minecraft:stone_bricks
fill 404 80 183 404 83 183 minecraft:mossy_cobblestone
setblock 404 80 222 minecraft:stone_bricks
fill 405 80 182 405 83 182 minecraft:mossy_cobblestone
setblock 405 80 221 minecraft:stone_bricks
fill 405 80 222 405 83 222 minecraft:mossy_cobblestone
fill 406 80 221 406 83 221 minecraft:mossy_cobblestone
setblock 409 80 182 minecraft:stone_bricks
setblock 409 80 222 minecraft:stone_bricks
fill 410 80 182 413 80 182 minecraft:mossy_cobblestone
setblock 410 80 220 minecraft:mossy_cobblestone
setblock 410 80 221 minecraft:stone_bricks
fill 410 80 222 410 83 222 minecraft:mossy_cobblestone
setblock 411 80 220 minecraft:stone_bricks
fill 411 80 221 411 83 221 minecraft:mossy_cobblestone
fill 412 80 220 412 83 220 minecraft:mossy_cobblestone
setblock 413 80 183 minecraft:stone_bricks
setblock 414 80 182 minecraft:stone_bricks
fill 414 80 183 415 82 183 minecraft:mossy_cobblestone
setblock 414 80 222 minecraft:stone_bricks
fill 415 80 182 415 83 182 minecraft:mossy_cobblestone
fill 415 80 199 415 80 200 minecraft:mossy_cobblestone
setblock 415 80 201 minecraft:stone_bricks
fill 415 80 202 415 83 202 minecraft:mossy_cobblestone
setblock 415 80 205 minecraft:mossy_cobblestone
setblock 415 80 206 minecraft:stone_bricks
fill 415 80 207 416 81 208 minecraft:mossy_cobblestone
setblock 415 80 215 minecraft:mossy_cobblestone
setblock 415 80 216 minecraft:stone_bricks
fill 415 80 217 415 83 217 minecraft:mossy_cobblestone
setblock 415 80 221 minecraft:stone_bricks
fill 415 80 222 415 83 222 minecraft:mossy_cobblestone
setblock 416 80 184 minecraft:mossy_cobblestone
setblock 416 80 195 minecraft:stone_bricks
fill 416 80 196 416 83 196 minecraft:mossy_cobblestone
setblock 416 80 200 minecraft:stone_bricks
fill 416 80 201 416 83 201 minecraft:mossy_cobblestone
setblock 416 80 204 minecraft:mossy_cobblestone
setblock 416 80 205 minecraft:stone_bricks
fill 416 80 206 416 83 206 minecraft:mossy_cobblestone
setblock 416 80 209 minecraft:mossy_cobblestone
setblock 416 80 210 minecraft:stone_bricks
fill 416 80 211 416 83 211 minecraft:mossy_cobblestone
setblock 416 80 215 minecraft:stone_bricks
fill 416 80 216 416 83 216 minecraft:mossy_cobblestone
setblock 416 80 220 minecraft:stone_bricks
fill 416 80 221 416 83 221 minecraft:mossy_cobblestone
setblock 417 80 184 minecraft:stone_bricks
fill 417 80 185 417 83 185 minecraft:mossy_cobblestone
fill 417 80 187 417 80 188 minecraft:mossy_cobblestone
fill 417 80 191 417 82 191 minecraft:mossy_cobblestone
setblock 417 80 194 minecraft:stone_bricks
fill 417 80 195 417 83 195 minecraft:mossy_cobblestone
setblock 417 80 199 minecraft:stone_bricks
fill 417 80 200 417 83 200 minecraft:mossy_cobblestone
setblock 417 80 204 minecraft:stone_bricks
fill 417 80 205 417 83 205 minecraft:mossy_cobblestone
setblock 417 80 209 minecraft:stone_bricks
fill 417 80 210 417 83 210 minecraft:mossy_cobblestone
setblock 417 80 214 minecraft:stone_bricks
fill 417 80 215 417 83 215 minecraft:mossy_cobblestone
setblock 417 80 219 minecraft:stone_bricks
fill 417 80 220 417 83 220 minecraft:mossy_cobblestone
setblock 377 81 182 minecraft:mossy_cobblestone
setblock 377 81 183 minecraft:stone_bricks
fill 377 81 184 377 81 187 minecraft:mossy_cobblestone
setblock 377 81 188 minecraft:stone_bricks
fill 377 81 189 378 83 189 minecraft:mossy_cobblestone
setblock 377 81 192 minecraft:mossy_cobblestone
setblock 377 81 193 minecraft:stone_bricks
fill 377 81 194 377 84 194 minecraft:mossy_cobblestone
setblock 377 81 198 minecraft:stone_bricks
fill 377 81 199 377 84 199 minecraft:mossy_cobblestone
setblock 377 81 203 minecraft:stone_bricks
fill 377 81 204 377 84 204 minecraft:mossy_cobblestone
setblock 377 81 208 minecraft:stone_bricks
fill 377 81 209 377 84 209 minecraft:mossy_cobblestone
setblock 377 81 213 minecraft:stone_bricks
fill 377 81 214 377 84 214 minecraft:mossy_cobblestone
setblock 377 81 218 minecraft:stone_bricks
fill 377 81 219 377 84 219 minecraft:mossy_cobblestone
setblock 378 81 182 minecraft:stone_bricks
fill 378 81 183 378 84 183 minecraft:mossy_cobblestone
setblock 378 81 187 minecraft:stone_bricks
fill 378 81 188 378 84 188 minecraft:mossy_cobblestone
fill 378 81 190 378 82 190 minecraft:mossy_cobblestone
setblock 378 81 192 minecraft:stone_bricks
fill 378 81 193 378 84 193 minecraft:mossy_cobblestone
setblock 378 81 197 minecraft:stone_bricks
fill 378 81 198 378 84 198 minecraft:mossy_cobblestone
setblock 378 81 202 minecraft:stone_bricks
fill 378 81 203 378 84 203 minecraft:mossy_cobblestone
setblock 378 81 206 minecraft:mossy_cobblestone
setblock 378 81 207 minecraft:stone_bricks
fill 378 81 208 378 84 208 minecraft:mossy_cobblestone
setblock 378 81 212 minecraft:stone_bricks
setblock 378 81 213 minecraft:mossy_cobblestone
setblock 378 81 217 minecraft:stone_bricks
fill 378 81 218 378 82 218 minecraft:mossy_cobblestone
setblock 378 81 222 minecraft:stone_bricks
fill 379 81 182 379 84 182 minecraft:mossy_cobblestone
setblock 379 81 184 minecraft:light[level=12]
setblock 379 81 192 minecraft:light[level=12]
setblock 379 81 196 minecraft:stone_bricks
fill 379 81 197 379 83 197 minecraft:mossy_cobblestone
setblock 379 81 201 minecraft:stone_bricks
fill 379 81 202 379 84 202 minecraft:mossy_cobblestone
setblock 379 81 206 minecraft:stone_bricks
fill 379 81 207 379 84 207 minecraft:mossy_cobblestone
setblock 379 81 216 minecraft:light[level=12]
setblock 379 81 221 minecraft:stone_bricks
fill 379 81 222 379 84 222 minecraft:mossy_cobblestone
setblock 380 81 200 minecraft:stone_bricks
fill 380 81 201 380 83 201 minecraft:mossy_cobblestone
setblock 380 81 205 minecraft:stone_bricks
fill 380 81 221 380 82 221 minecraft:mossy_cobblestone
setblock 382 81 183 minecraft:stone_bricks
setblock 383 81 182 minecraft:stone_bricks
fill 383 81 183 386 81 183 minecraft:mossy_cobblestone
setblock 383 81 222 minecraft:stone_bricks
fill 384 81 182 387 81 182 minecraft:mossy_cobblestone
fill 384 81 222 387 81 222 minecraft:mossy_cobblestone
setblock 387 81 183 minecraft:stone_bricks
setblock 387 81 184 minecraft:light[level=12]
setblock 387 81 192 minecraft:light[level=12]
setblock 387 81 200 minecraft:light[level=12]
setblock 387 81 208 minecraft:light[level=12]
setblock 387 81 216 minecraft:light[level=12]
setblock 388 81 182 minecraft:stone_bricks
fill 388 81 183 388 84 183 minecraft:mossy_cobblestone
setblock 388 81 222 minecraft:stone_bricks
fill 389 81 182 389 84 182 minecraft:mossy_cobblestone
fill 389 81 222 389 84 222 minecraft:mossy_cobblestone
setblock 391 81 184 minecraft:stone_bricks
fill 391 81 221 391 83 221 minecraft:mossy_cobblestone
setblock 392 81 183 minecraft:stone_bricks
fill 392 81 184 392 84 184 minecraft:mossy_cobblestone
setblock 393 81 182 minecraft:stone_bricks
fill 393 81 183 393 84 183 minecraft:mossy_cobblestone
setblock 393 81 222 minecraft:stone_bricks
fill 394 81 182 394 84 182 minecraft:mossy_cobblestone
setblock 394 81 185 minecraft:mossy_cobblestone
setblock 394 81 221 minecraft:stone_bricks
fill 394 81 222 394 84 222 minecraft:mossy_cobblestone
setblock 395 81 185 minecraft:stone_bricks
setblock 395 81 192 minecraft:light[level=12]
setblock 395 81 200 minecraft:light[level=12]
setblock 395 81 208 minecraft:light[level=12]
setblock 395 81 216 minecraft:light[level=12]
setblock 395 81 220 minecraft:stone_bricks
fill 395 81 221 395 84 221 minecraft:mossy_cobblestone
setblock 396 81 183 minecraft:mossy_cobblestone
setblock 396 81 184 minecraft:stone_bricks
fill 396 81 185 396 84 185 minecraft:mossy_cobblestone
fill 396 81 220 396 84 220 minecraft:mossy_cobblestone
setblock 397 81 183 minecraft:stone_bricks
fill 397 81 184 397 84 184 minecraft:mossy_cobblestone
setblock 398 81 182 minecraft:stone_bricks
fill 398 81 183 398 84 183 minecraft:mossy_cobblestone
fill 398 81 185 399 81 185 minecraft:mossy_cobblestone
setblock 398 81 222 minecraft:stone_bricks
fill 399 81 182 399 84 182 minecraft:mossy_cobblestone
setblock 399 81 221 minecraft:stone_bricks
fill 399 81 222 402 81 222 minecraft:mossy_cobblestone
setblock 400 81 184 minecraft:mossy_cobblestone
setblock 400 81 220 minecraft:stone_bricks
fill 400 81 221 400 84 221 minecraft:mossy_cobblestone
setblock 401 81 184 minecraft:stone_bricks
fill 401 81 220 401 83 220 minecraft:mossy_cobblestone
setblock 402 81 183 minecraft:stone_bricks
fill 402 81 184 402 83 184 minecraft:mossy_cobblestone
setblock 403 81 182 minecraft:stone_bricks
fill 403 81 183 403 84 183 minecraft:mossy_cobblestone
setblock 403 81 184 minecraft:light[level=12]
setblock 403 81 192 minecraft:light[level=12]
setblock 403 81 200 minecraft:light[level=12]
setblock 403 81 208 minecraft:light[level=12]
setblock 403 81 216 minecraft:light[level=12]
setblock 403 81 222 minecraft:stone_bricks
fill 404 81 182 404 84 182 minecraft:mossy_cobblestone
setblock 404 81 220 minecraft:mossy_cobblestone
setblock 404 81 221 minecraft:stone_bricks
fill 404 81 222 404 84 222 minecraft:mossy_cobblestone
fill 405 81 221 405 84 221 minecraft:mossy_cobblestone
setblock 406 81 183 minecraft:mossy_cobblestone
setblock 408 81 182 minecraft:stone_bricks
setblock 408 81 222 minecraft:stone_bricks
fill 409 81 182 412 81 182 minecraft:mossy_cobblestone
setblock 409 81 221 minecraft:stone_bricks
fill 409 81 222 409 84 222 minecraft:mossy_cobblestone
setblock 410 81 220 minecraft:stone_bricks
fill 410 81 221 410 84 221 minecraft:mossy_cobblestone
setblock 411 81 183 minecraft:mossy_cobblestone
setblock 411 81 184 minecraft:light[level=12]
setblock 411 81 192 minecraft:light[level=12]
setblock 411 81 200 minecraft:light[level=12]
setblock 411 81 208 minecraft:light[level=12]
setblock 411 81 216 minecraft:light[level=12]
fill 411 81 220 411 83 220 minecraft:mossy_cobblestone
setblock 412 81 183 minecraft:stone_bricks
setblock 413 81 182 minecraft:stone_bricks
fill 413 81 183 413 84 183 minecraft:mossy_cobblestone
setblock 413 81 222 minecraft:stone_bricks
fill 414 81 182 414 84 182 minecraft:mossy_cobblestone
setblock 414 81 221 minecraft:stone_bricks
fill 414 81 222 414 84 222 minecraft:mossy_cobblestone
fill 415 81 198 415 81 199 minecraft:mossy_cobblestone
setblock 415 81 200 minecraft:stone_bricks
fill 415 81 201 415 84 201 minecraft:mossy_cobblestone
setblock 415 81 205 minecraft:stone_bricks
fill 415 81 206 415 84 206 minecraft:mossy_cobblestone
setblock 415 81 209 minecraft:mossy_cobblestone
setblock 415 81 210 minecraft:stone_bricks
fill 415 81 211 415 84 211 minecraft:mossy_cobblestone
setblock 415 81 214 minecraft:mossy_cobblestone
setblock 415 81 215 minecraft:stone_bricks
fill 415 81 216 415 83 216 minecraft:mossy_cobblestone
setblock 415 81 220 minecraft:stone_bricks
fill 415 81 221 415 84 221 minecraft:mossy_cobblestone
setblock 416 81 184 minecraft:stone_bricks
fill 416 81 185 416 84 185 minecraft:mossy_cobblestone
fill 416 81 195 416 82 195 minecraft:mossy_cobblestone
setblock 416 81 199 minecraft:stone_bricks
fill 416 81 200 416 84 200 minecraft:mossy_cobblestone
setblock 416 81 204 minecraft:stone_bricks
fill 416 81 205 416 84 205 minecraft:mossy_cobblestone
setblock 416 81 209 minecraft:stone_bricks
fill 416 81 210 416 84 210 minecraft:mossy_cobblestone
setblock 416 81 214 minecraft:stone_bricks
fill 416 81 215 416 84 215 minecraft:mossy_cobblestone
setblock 416 81 219 minecraft:stone_bricks
fill 416 81 220 416 84 220 minecraft:mossy_cobblestone
setblock 417 81 183 minecraft:stone_bricks
fill 417 81 184 417 84 184 minecraft:mossy_cobblestone
setblock 417 81 187 minecraft:mossy_cobblestone
setblock 417 81 188 minecraft:stone_bricks
fill 417 81 189 417 83 190 minecraft:mossy_cobblestone
setblock 417 81 193 minecraft:stone_bricks
fill 417 81 194 417 84 194 minecraft:mossy_cobblestone
setblock 417 81 198 minecraft:stone_bricks
fill 417 81 199 417 84 199 minecraft:mossy_cobblestone
setblock 417 81 203 minecraft:stone_bricks
fill 417 81 204 417 84 204 minecraft:mossy_cobblestone
setblock 417 81 208 minecraft:stone_bricks
fill 417 81 209 417 84 209 minecraft:mossy_cobblestone
setblock 417 81 213 minecraft:stone_bricks
fill 417 81 214 417 84 214 minecraft:mossy_cobblestone
setblock 417 81 218 minecraft:stone_bricks
fill 417 81 219 417 84 219 minecraft:mossy_cobblestone
setblock 377 82 182 minecraft:stone_bricks
fill 377 82 183 377 82 186 minecraft:mossy_cobblestone
setblock 377 82 187 minecraft:stone_bricks
fill 377 82 188 377 85 188 minecraft:mossy_cobblestone
setblock 377 82 192 minecraft:stone_bricks
fill 377 82 193 377 85 193 minecraft:mossy_cobblestone
setblock 377 82 197 minecraft:stone_bricks
fill 377 82 198 377 85 198 minecraft:mossy_cobblestone
setblock 377 82 202 minecraft:stone_bricks
fill 377 82 203 377 85 203 minecraft:mossy_cobblestone
setblock 377 82 207 minecraft:stone_bricks
fill 377 82 208 377 85 208 minecraft:mossy_cobblestone
setblock 377 82 212 minecraft:stone_bricks
fill 377 82 213 377 85 213 minecraft:mossy_cobblestone
setblock 377 82 217 minecraft:stone_bricks
fill 377 82 218 377 84 218 minecraft:mossy_cobblestone
setblock 377 82 222 minecraft:stone_bricks
fill 378 82 182 378 85 182 minecraft:mossy_cobblestone
fill 378 82 184 378 82 185 minecraft:mossy_cobblestone
setblock 378 82 186 minecraft:stone_bricks
fill 378 82 187 378 85 187 minecraft:mossy_cobblestone
setblock 378 82 191 minecraft:stone_bricks
fill 378 82 192 378 85 192 minecraft:mossy_cobblestone
setblock 378 82 196 minecraft:stone_bricks
fill 378 82 197 378 85 197 minecraft:mossy_cobblestone
setblock 378 82 201 minecraft:stone_bricks
fill 378 82 202 378 85 202 minecraft:mossy_cobblestone
setblock 378 82 206 minecraft:stone_bricks
fill 378 82 207 378 85 207 minecraft:mossy_cobblestone
setblock 378 82 211 minecraft:stone_bricks
setblock 378 82 212 minecraft:mossy_cobblestone
setblock 378 82 221 minecraft:stone_bricks
fill 378 82 222 378 85 222 minecraft:mossy_cobblestone
setblock 379 82 184 minecraft:mossy_cobblestone
setblock 379 82 195 minecraft:stone_bricks
fill 379 82 196 379 83 196 minecraft:mossy_cobblestone
setblock 379 82 200 minecraft:stone_bricks
fill 379 82 201 379 85 201 minecraft:mossy_cobblestone
setblock 379 82 204 minecraft:mossy_cobblestone
setblock 379 82 205 minecraft:stone_bricks
fill 379 82 206 379 85 206 minecraft:mossy_cobblestone
fill 379 82 221 379 83 221 minecraft:mossy_cobblestone
setblock 380 82 183 minecraft:mossy_cobblestone
setblock 380 82 199 minecraft:stone_bricks
fill 380 82 200 380 83 200 minecraft:mossy_cobblestone
setblock 380 82 204 minecraft:stone_bricks
setblock 380 82 205 minecraft:mossy_cobblestone
setblock 381 82 183 minecraft:stone_bricks
setblock 382 82 182 minecraft:stone_bricks
fill 382 82 183 385 82 183 minecraft:mossy_cobblestone
setblock 382 82 222 minecraft:stone_bricks
fill 383 82 182 386 82 182 minecraft:mossy_cobblestone
fill 383 82 222 386 82 222 minecraft:mossy_cobblestone
setblock 386 82 183 minecraft:stone_bricks
setblock 387 82 182 minecraft:stone_bricks
fill 387 82 183 387 85 183 minecraft:mossy_cobblestone
setblock 387 82 222 minecraft:stone_bricks
fill 388 82 182 388 85 182 minecraft:mossy_cobblestone
fill 388 82 222 388 85 222 minecraft:mossy_cobblestone
setblock 390 82 184 minecraft:stone_bricks
setblock 391 82 182 minecraft:mossy_cobblestone
setblock 391 82 183 minecraft:stone_bricks
fill 391 82 184 391 85 184 minecraft:mossy_cobblestone
setblock 392 82 182 minecraft:stone_bricks
fill 392 82 183 392 85 183 minecraft:mossy_cobblestone
setblock 392 82 222 minecraft:stone_bricks
fill 393 82 182 393 85 182 minecraft:mossy_cobblestone
setblock 393 82 185 minecraft:mossy_cobblestone
setblock 393 82 221 minecraft:stone_bricks
fill 393 82 222 393 85 222 minecraft:mossy_cobblestone
setblock 394 82 184 minecraft:mossy_cobblestone
setblock 394 82 185 minecraft:stone_bricks
setblock 394 82 220 minecraft:stone_bricks
fill 394 82 221 394 85 221 minecraft:mossy_cobblestone
setblock 395 82 184 minecraft:stone_bricks
fill 395 82 185 395 85 185 minecraft:mossy_cobblestone
fill 395 82 220 395 84 220 minecraft:mossy_cobblestone
setblock 396 82 183 minecraft:stone_bricks
fill 396 82 184 396 85 184 minecraft:mossy_cobblestone
setblock 397 82 182 minecraft:stone_bricks
fill 397 82 183 397 85 183 minecraft:mossy_cobblestone
setblock 397 82 222 minecraft:stone_bricks
fill 398 82 182 398 85 182 minecraft:mossy_cobblestone
setblock 398 82 185 minecraft:mossy_cobblestone
setblock 398 82 221 minecraft:stone_bricks
fill 398 82 222 401 82 222 minecraft:mossy_cobblestone
setblock 399 82 185 minecraft:stone_bricks
setblock 399 82 220 minecraft:stone_bricks
fill 399 82 221 399 85 221 minecraft:mossy_cobblestone
setblock 400 82 184 minecraft:stone_bricks
fill 400 82 220 400 83 220 minecraft:mossy_cobblestone
setblock 401 82 183 minecraft:stone_bricks
fill 401 82 184 401 84 184 minecraft:mossy_cobblestone
setblock 402 82 182 minecraft:stone_bricks
fill 402 82 183 402 85 183 minecraft:mossy_cobblestone
setblock 402 82 222 minecraft:stone_bricks
fill 403 82 182 403 85 182 minecraft:mossy_cobblestone
setblock 403 82 221 minecraft:stone_bricks
fill 403 82 222 403 85 222 minecraft:mossy_cobblestone
fill 404 82 221 404 84 221 minecraft:mossy_cobblestone
setblock 406 82 183 minecraft:stone_bricks
setblock 407 82 182 minecraft:stone_bricks
fill 407 82 183 407 83 183 minecraft:mossy_cobblestone
setblock 407 82 222 minecraft:stone_bricks
fill 408 82 182 411 82 182 minecraft:mossy_cobblestone
setblock 408 82 221 minecraft:stone_bricks
fill 408 82 222 408 85 222 minecraft:mossy_cobblestone
fill 409 82 183 410 82 183 minecraft:mossy_cobblestone
fill 409 82 221 409 85 221 minecraft:mossy_cobblestone
setblock 410 82 220 minecraft:mossy_cobblestone
setblock 411 82 183 minecraft:stone_bricks
setblock 412 82 182 minecraft:stone_bricks
fill 412 82 183 412 85 183 minecraft:mossy_cobblestone
setblock 412 82 222 minecraft:stone_bricks
fill 413 82 182 413 85 182 minecraft:mossy_cobblestone
setblock 413 82 221 minecraft:stone_bricks
fill 413 82 222 413 85 222 minecraft:mossy_cobblestone
fill 414 82 202 414 82 204 minecraft:mossy_cobblestone
setblock 414 82 205 minecraft:stone_bricks
fill 414 82 206 414 85 206 minecraft:mossy_cobblestone
setblock 414 82 220 minecraft:stone_bricks
fill 414 82 221 414 85 221 minecraft:mossy_cobblestone
setblock 415 82 198 minecraft:mossy_cobblestone
setblock 415 82 199 minecraft:stone_bricks
fill 415 82 200 415 85 200 minecraft:mossy_cobblestone
setblock 415 82 203 minecraft:mossy_cobblestone
setblock 415 82 204 minecraft:stone_bricks
fill 415 82 205 415 85 205 minecraft:mossy_cobblestone
fill 415 82 207 415 82 208 minecraft:mossy_cobblestone
setblock 415 82 209 minecraft:stone_bricks
fill 415 82 210 415 85 210 minecraft:mossy_cobblestone
fill 415 82 212 415 82 213 minecraft:mossy_cobblestone
setblock 415 82 214 minecraft:stone_bricks
fill 415 82 215 415 83 215 minecraft:mossy_cobblestone
setblock 415 82 219 minecraft:stone_bricks
fill 415 82 220 415 84 220 minecraft:mossy_cobblestone
setblock 416 82 182 minecraft:mossy_cobblestone
setblock 416 82 183 minecraft:stone_bricks
fill 416 82 184 416 85 184 minecraft:mossy_cobblestone
fill 416 82 186 416 83 186 minecraft:mossy_cobblestone
setblock 416 82 198 minecraft:stone_bricks
fill 416 82 199 416 85 199 minecraft:mossy_cobblestone
setblock 416 82 203 minecraft:stone_bricks
fill 416 82 204 416 85 204 minecraft:mossy_cobblestone
setblock 416 82 207 minecraft:mossy_cobblestone
setblock 416 82 208 minecraft:stone_bricks
fill 416 82 209 416 85 209 minecraft:mossy_cobblestone
setblock 416 82 213 minecraft:stone_bricks
fill 416 82 214 416 85 214 minecraft:mossy_cobblestone
setblock 416 82 218 minecraft:stone_bricks
fill 416 82 219 416 85 219 minecraft:mossy_cobblestone
setblock 417 82 182 minecraft:stone_bricks
fill 417 82 183 417 85 183 minecraft:mossy_cobblestone
setblock 417 82 187 minecraft:stone_bricks
fill 417 82 188 417 85 188 minecraft:mossy_cobblestone
setblock 417 82 192 minecraft:stone_bricks
fill 417 82 193 417 85 193 minecraft:mossy_cobblestone
setblock 417 82 197 minecraft:stone_bricks
fill 417 82 198 417 85 198 minecraft:mossy_cobblestone
setblock 417 82 202 minecraft:stone_bricks
fill 417 82 203 417 85 203 minecraft:mossy_cobblestone
setblock 417 82 207 minecraft:stone_bricks
fill 417 82 208 417 85 208 minecraft:mossy_cobblestone
setblock 417 82 212 minecraft:stone_bricks
fill 417 82 213 417 85 213 minecraft:mossy_cobblestone
setblock 417 82 217 minecraft:stone_bricks
fill 417 82 218 417 85 218 minecraft:mossy_cobblestone
setblock 417 82 222 minecraft:stone_bricks
fill 377 83 182 377 83 185 minecraft:mossy_cobblestone
setblock 377 83 186 minecraft:stone_bricks
fill 377 83 187 377 86 187 minecraft:mossy_cobblestone
setblock 377 83 191 minecraft:stone_bricks
fill 377 83 192 377 86 192 minecraft:mossy_cobblestone
setblock 377 83 196 minecraft:stone_bricks
fill 377 83 197 377 86 197 minecraft:mossy_cobblestone
setblock 377 83 201 minecraft:stone_bricks
fill 377 83 202 377 86 202 minecraft:mossy_cobblestone
setblock 377 83 206 minecraft:stone_bricks
fill 377 83 207 377 86 207 minecraft:mossy_cobblestone
setblock 377 83 211 minecraft:stone_bricks
fill 377 83 212 377 86 212 minecraft:mossy_cobblestone
setblock 377 83 216 minecraft:stone_bricks
fill 377 83 217 377 84 217 minecraft:mossy_cobblestone
setblock 377 83 221 minecraft:stone_bricks
fill 377 83 222 377 86 222 minecraft:mossy_cobblestone
setblock 378 83 184 minecraft:mossy_cobblestone
setblock 378 83 185 minecraft:stone_bricks
fill 378 83 186 378 86 186 minecraft:mossy_cobblestone
setblock 378 83 190 minecraft:stone_bricks
fill 378 83 191 378 85 191 minecraft:mossy_cobblestone
setblock 378 83 195 minecraft:stone_bricks
fill 378 83 196 378 85 196 minecraft:mossy_cobblestone
setblock 378 83 200 minecraft:stone_bricks
fill 378 83 201 378 86 201 minecraft:mossy_cobblestone
setblock 378 83 205 minecraft:stone_bricks
fill 378 83 206 378 86 206 minecraft:mossy_cobblestone
setblock 378 83 210 minecraft:stone_bricks
fill 378 83 211 378 84 211 minecraft:mossy_cobblestone
setblock 378 83 220 minecraft:stone_bricks
setblock 378 83 221 minecraft:mossy_cobblestone
setblock 379 83 184 minecraft:stone_bricks
setblock 379 83 199 minecraft:stone_bricks
fill 379 83 200 379 85 200 minecraft:mossy_cobblestone
setblock 379 83 204 minecraft:stone_bricks
fill 379 83 205 379 86 205 minecraft:mossy_cobblestone
setblock 380 83 183 minecraft:stone_bricks
setblock 380 83 203 minecraft:stone_bricks
setblock 380 83 204 minecraft:mossy_cobblestone
setblock 381 83 182 minecraft:stone_bricks
fill 381 83 183 384 83 183 minecraft:mossy_cobblestone
setblock 381 83 222 minecraft:stone_bricks
fill 382 83 182 385 83 182 minecraft:mossy_cobblestone
fill 382 83 222 383 83 222 minecraft:mossy_cobblestone
setblock 385 83 183 minecraft:stone_bricks
setblock 386 83 182 minecraft:stone_bricks
fill 386 83 183 386 86 183 minecraft:mossy_cobblestone
fill 387 83 182 387 86 182 minecraft:mossy_cobblestone
fill 387 83 222 387 84 222 minecraft:mossy_cobblestone
setblock 389 83 183 minecraft:mossy_cobblestone
setblock 389 83 184 minecraft:stone_bricks
setblock 390 83 183 minecraft:stone_bricks
fill 390 83 184 390 86 184 minecraft:mossy_cobblestone
setblock 391 83 182 minecraft:stone_bricks
fill 391 83 183 391 86 183 minecraft:mossy_cobblestone
setblock 391 83 222 minecraft:stone_bricks
fill 392 83 182 392 86 182 minecraft:mossy_cobblestone
setblock 392 83 185 minecraft:mossy_cobblestone
setblock 392 83 221 minecraft:stone_bricks
fill 392 83 222 392 86 222 minecraft:mossy_cobblestone
setblock 393 83 185 minecraft:stone_bricks
fill 393 83 221 393 86 221 minecraft:mossy_cobblestone
setblock 394 83 184 minecraft:stone_bricks
fill 394 83 185 394 86 185 minecraft:mossy_cobblestone
fill 394 83 220 394 84 220 minecraft:mossy_cobblestone
setblock 395 83 183 minecraft:stone_bricks
fill 395 83 184 395 86 184 minecraft:mossy_cobblestone
setblock 396 83 182 minecraft:stone_bricks
fill 396 83 183 396 86 183 minecraft:mossy_cobblestone
setblock 396 83 222 minecraft:stone_bricks
fill 397 83 182 397 86 182 minecraft:mossy_cobblestone
setblock 397 83 221 minecraft:stone_bricks
fill 397 83 222 400 83 222 minecraft:mossy_cobblestone
setblock 398 83 185 minecraft:stone_bricks
setblock 398 83 220 minecraft:stone_bricks
fill 398 83 221 398 86 221 minecraft:mossy_cobblestone
setblock 399 83 184 minecraft:stone_bricks
setblock 399 83 185 minecraft:mossy_cobblestone
fill 399 83 220 399 84 220 minecraft:mossy_cobblestone
setblock 400 83 183 minecraft:stone_bricks
fill 400 83 184 400 85 184 minecraft:mossy_cobblestone
setblock 401 83 182 minecraft:stone_bricks
fill 401 83 183 401 86 183 minecraft:mossy_cobblestone
setblock 401 83 222 minecraft:stone_bricks
fill 402 83 182 402 86 182 minecraft:mossy_cobblestone
setblock 402 83 221 minecraft:stone_bricks
fill 402 83 222 402 86 222 minecraft:mossy_cobblestone
fill 403 83 221 403 84 221 minecraft:mossy_cobblestone
setblock 405 83 183 minecraft:stone_bricks
setblock 406 83 182 minecraft:stone_bricks
setblock 406 83 183 minecraft:mossy_cobblestone
setblock 406 83 222 minecraft:stone_bricks
fill 407 83 182 410 83 182 minecraft:mossy_cobblestone
setblock 407 83 221 minecraft:stone_bricks
fill 407 83 222 407 86 222 minecraft:mossy_cobblestone
fill 408 83 183 409 83 183 minecraft:mossy_cobblestone
fill 408 83 221 408 85 221 minecraft:mossy_cobblestone
setblock 410 83 183 minecraft:stone_bricks
setblock 411 83 182 minecraft:stone_bricks
fill 411 83 183 411 86 183 minecraft:mossy_cobblestone
setblock 411 83 222 minecraft:stone_bricks
fill 412 83 182 412 86 182 minecraft:mossy_cobblestone
setblock 412 83 221 minecraft:stone_bricks
fill 412 83 222 412 86 222 minecraft:mossy_cobblestone
setblock 413 83 220 minecraft:stone_bricks
fill 413 83 221 413 86 221 minecraft:mossy_cobblestone
setblock 414 83 183 minecraft:mossy_cobblestone
fill 414 83 201 414 83 203 minecraft:mossy_cobblestone
setblock 414 83 204 minecraft:stone_bricks
fill 414 83 205 414 86 205 minecraft:mossy_cobblestone
schedule function dropper:buildpart/44_5 1t
