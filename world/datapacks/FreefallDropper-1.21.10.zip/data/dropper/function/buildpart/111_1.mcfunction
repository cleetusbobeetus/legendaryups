fill 148 155 495 148 158 495 minecraft:purpur_block
fill 149 155 493 149 158 493 minecraft:purpur_block
fill 149 155 497 152 158 497 minecraft:purpur_block
setblock 150 155 463 minecraft:white_concrete
fill 152 155 493 152 158 493 minecraft:purpur_block
fill 153 155 495 153 158 495 minecraft:purpur_block
fill 158 155 505 158 179 505 minecraft:end_stone_bricks
fill 161 155 505 161 176 505 minecraft:end_stone_bricks
setblock 170 155 505 minecraft:magenta_stained_glass
fill 179 155 473 180 157 473 minecraft:magenta_stained_glass
fill 180 155 472 182 156 472 minecraft:magenta_stained_glass
fill 180 155 474 182 156 474 minecraft:magenta_stained_glass
fill 182 155 473 182 156 473 minecraft:magenta_stained_glass
fill 183 155 479 183 179 479 minecraft:end_stone_bricks
fill 183 155 490 183 211 490 minecraft:end_stone_bricks
setblock 183 155 503 minecraft:white_concrete
setblock 141 156 467 minecraft:pearlescent_froglight
fill 141 156 471 141 161 471 minecraft:end_stone_bricks
fill 141 156 487 141 161 487 minecraft:end_stone_bricks
fill 141 156 500 141 164 500 minecraft:end_stone_bricks
fill 141 156 503 141 161 503 minecraft:end_stone_bricks
fill 142 156 499 142 159 499 minecraft:magenta_stained_glass
fill 142 156 505 142 214 505 minecraft:end_stone_bricks
setblock 143 156 505 minecraft:white_concrete
fill 145 156 463 145 161 463 minecraft:end_stone_bricks
fill 148 156 494 148 158 494 minecraft:purpur_block
fill 148 156 496 148 158 496 minecraft:purpur_block
fill 150 156 463 150 208 463 minecraft:end_stone_bricks
fill 150 156 492 151 158 492 minecraft:purpur_block
fill 153 156 494 153 158 494 minecraft:purpur_block
fill 153 156 496 153 158 496 minecraft:purpur_block
fill 155 156 505 155 161 505 minecraft:end_stone_bricks
fill 161 156 463 161 161 463 minecraft:end_stone_bricks
fill 170 156 505 171 157 505 minecraft:end_stone_bricks
setblock 173 156 463 minecraft:magenta_stained_glass
fill 177 156 463 177 161 463 minecraft:end_stone_bricks
fill 177 156 473 178 157 473 minecraft:magenta_stained_glass
fill 179 156 472 179 157 472 minecraft:magenta_stained_glass
fill 179 156 474 179 157 474 minecraft:magenta_stained_glass
setblock 181 156 505 minecraft:magenta_stained_glass
fill 183 156 473 183 161 473 minecraft:end_stone_bricks
fill 183 156 489 183 161 489 minecraft:end_stone_bricks
fill 183 156 503 183 174 503 minecraft:end_stone_bricks
fill 141 157 467 141 171 467 minecraft:end_stone_bricks
setblock 141 157 473 minecraft:pearlescent_froglight
fill 142 157 498 143 158 498 minecraft:magenta_stained_glass
fill 142 157 500 143 158 500 minecraft:magenta_stained_glass
fill 143 157 499 145 158 499 minecraft:magenta_stained_glass
fill 143 157 505 143 211 505 minecraft:end_stone_bricks
fill 147 157 495 147 158 495 minecraft:purpur_block
fill 148 157 493 148 158 493 minecraft:purpur_block
fill 148 157 497 148 158 497 minecraft:purpur_block
fill 149 157 492 149 158 492 minecraft:purpur_block
fill 149 157 498 152 158 498 minecraft:purpur_block
fill 152 157 492 152 158 492 minecraft:purpur_block
fill 153 157 493 153 158 493 minecraft:purpur_block
fill 153 157 497 153 158 497 minecraft:purpur_block
fill 154 157 495 154 158 495 minecraft:purpur_block
setblock 164 157 463 minecraft:magenta_stained_glass
fill 173 157 463 173 214 463 minecraft:end_stone_bricks
setblock 176 157 463 minecraft:white_concrete
setblock 176 157 473 minecraft:magenta_stained_glass
setblock 180 157 472 minecraft:magenta_stained_glass
setblock 180 157 474 minecraft:magenta_stained_glass
fill 181 157 505 181 214 505 minecraft:end_stone_bricks
fill 183 157 464 183 161 464 minecraft:end_stone_bricks
setblock 183 157 465 minecraft:magenta_stained_glass
fill 141 158 473 141 198 473 minecraft:end_stone_bricks
setblock 144 158 466 minecraft:light[level=14]
setblock 144 158 474 minecraft:light[level=14]
setblock 144 158 482 minecraft:light[level=14]
setblock 144 158 490 minecraft:light[level=14]
setblock 144 158 498 minecraft:magenta_stained_glass
setblock 144 158 500 minecraft:magenta_stained_glass
setblock 146 158 499 minecraft:magenta_stained_glass
fill 147 158 493 147 158 494 minecraft:purpur_block
setblock 147 158 496 minecraft:purpur_block
setblock 148 158 492 minecraft:purpur_block
setblock 148 158 498 minecraft:purpur_block
fill 150 158 491 151 158 491 minecraft:purpur_block
setblock 151 158 463 minecraft:pearlescent_froglight
setblock 152 158 466 minecraft:light[level=14]
setblock 152 158 474 minecraft:light[level=14]
setblock 152 158 482 minecraft:light[level=14]
setblock 152 158 490 minecraft:light[level=14]
setblock 153 158 492 minecraft:purpur_block
setblock 153 158 498 minecraft:purpur_block
fill 154 158 493 154 158 494 minecraft:purpur_block
setblock 154 158 496 minecraft:purpur_block
setblock 160 158 466 minecraft:light[level=14]
setblock 160 158 474 minecraft:light[level=14]
setblock 160 158 482 minecraft:light[level=14]
setblock 160 158 490 minecraft:light[level=14]
setblock 160 158 498 minecraft:light[level=14]
fill 164 158 463 164 159 463 minecraft:end_stone_bricks
setblock 165 158 505 minecraft:white_concrete
setblock 168 158 466 minecraft:light[level=14]
setblock 168 158 474 minecraft:light[level=14]
setblock 168 158 482 minecraft:light[level=14]
setblock 168 158 490 minecraft:light[level=14]
setblock 168 158 498 minecraft:light[level=14]
setblock 170 158 505 minecraft:magenta_stained_glass
fill 171 158 481 171 159 482 minecraft:purpur_block
fill 171 158 505 171 161 505 minecraft:end_stone_bricks
setblock 175 158 473 minecraft:magenta_stained_glass
fill 176 158 463 176 211 463 minecraft:end_stone_bricks
setblock 176 158 466 minecraft:light[level=14]
setblock 176 158 474 minecraft:light[level=14]
setblock 176 158 482 minecraft:light[level=14]
setblock 176 158 490 minecraft:light[level=14]
setblock 176 158 498 minecraft:light[level=14]
fill 183 158 465 183 214 465 minecraft:end_stone_bricks
fill 183 158 469 183 169 470 minecraft:end_stone_bricks
setblock 183 158 471 minecraft:pearlescent_froglight
fill 143 159 499 144 159 499 minecraft:magenta_stained_glass
fill 149 159 496 149 163 496 minecraft:end_stone_bricks
fill 150 159 493 150 161 493 minecraft:end_stone_bricks
fill 151 159 463 151 214 463 minecraft:end_stone_bricks
fill 152 159 495 152 160 495 minecraft:end_stone_bricks
fill 165 159 505 165 202 505 minecraft:end_stone_bricks
fill 170 159 505 170 200 505 minecraft:end_stone_bricks
fill 183 159 471 183 214 471 minecraft:end_stone_bricks
fill 183 159 486 183 214 486 minecraft:end_stone_bricks
setblock 183 159 487 minecraft:magenta_stained_glass
fill 183 159 488 183 204 488 minecraft:end_stone_bricks
setblock 141 160 478 minecraft:magenta_stained_glass
setblock 141 160 489 minecraft:pearlescent_froglight
setblock 141 160 499 minecraft:pearlescent_froglight
setblock 149 160 463 minecraft:pearlescent_froglight
setblock 164 160 463 minecraft:pearlescent_froglight
fill 183 160 487 183 185 487 minecraft:end_stone_bricks
fill 141 161 478 141 211 479 minecraft:end_stone_bricks
setblock 141 161 480 minecraft:pearlescent_froglight
fill 141 161 489 141 211 489 minecraft:end_stone_bricks
fill 141 161 499 141 210 499 minecraft:end_stone_bricks
fill 149 161 463 149 212 463 minecraft:end_stone_bricks
fill 163 161 493 163 162 493 minecraft:end_stone
fill 164 161 463 164 174 463 minecraft:end_stone_bricks
fill 141 162 471 141 164 471 minecraft:magenta_concrete
fill 141 162 480 141 211 480 minecraft:end_stone_bricks
fill 141 162 487 141 164 487 minecraft:magenta_concrete
fill 141 162 503 141 164 503 minecraft:magenta_concrete
fill 145 162 463 145 164 463 minecraft:magenta_concrete
fill 155 162 505 155 164 505 minecraft:magenta_concrete
fill 161 162 463 161 164 463 minecraft:magenta_concrete
fill 171 162 505 171 164 505 minecraft:magenta_concrete
fill 177 162 463 177 164 463 minecraft:magenta_concrete
setblock 183 162 464 minecraft:white_concrete
fill 183 162 473 183 164 473 minecraft:magenta_concrete
fill 183 162 489 183 164 489 minecraft:magenta_concrete
setblock 183 162 494 minecraft:pearlescent_froglight
setblock 141 163 475 minecraft:white_concrete
setblock 148 163 463 minecraft:pearlescent_froglight
setblock 162 163 463 minecraft:white_concrete
setblock 174 163 463 minecraft:white_concrete
fill 183 163 464 183 179 464 minecraft:end_stone_bricks
setblock 183 163 478 minecraft:magenta_stained_glass
fill 183 163 494 183 165 494 minecraft:end_stone_bricks
fill 141 164 475 141 214 475 minecraft:end_stone_bricks
fill 148 164 463 148 167 463 minecraft:end_stone_bricks
fill 162 164 463 162 175 463 minecraft:end_stone_bricks
fill 174 164 463 174 166 463 minecraft:end_stone_bricks
fill 183 164 478 183 193 478 minecraft:end_stone_bricks
fill 141 165 471 141 170 471 minecraft:end_stone_bricks
fill 141 165 487 141 170 487 minecraft:end_stone_bricks
setblock 141 165 488 minecraft:magenta_stained_glass
setblock 141 165 500 minecraft:pearlescent_froglight
fill 141 165 503 141 170 503 minecraft:end_stone_bricks
fill 145 165 463 145 170 463 minecraft:end_stone_bricks
fill 155 165 505 155 170 505 minecraft:end_stone_bricks
fill 161 165 463 161 170 463 minecraft:end_stone_bricks
fill 171 165 505 171 170 505 minecraft:end_stone_bricks
fill 177 165 463 177 170 463 minecraft:end_stone_bricks
setblock 183 165 466 minecraft:magenta_stained_glass
fill 183 165 473 183 170 473 minecraft:end_stone_bricks
fill 183 165 489 183 170 489 minecraft:end_stone_bricks
fill 141 166 488 141 214 488 minecraft:end_stone_bricks
setblock 141 166 491 minecraft:magenta_stained_glass
fill 141 166 500 141 177 500 minecraft:end_stone_bricks
setblock 144 166 466 minecraft:light[level=14]
setblock 144 166 474 minecraft:light[level=14]
setblock 144 166 482 minecraft:light[level=14]
setblock 144 166 490 minecraft:light[level=14]
setblock 144 166 498 minecraft:light[level=14]
setblock 152 166 466 minecraft:light[level=14]
setblock 152 166 474 minecraft:light[level=14]
setblock 152 166 482 minecraft:light[level=14]
setblock 152 166 490 minecraft:light[level=14]
setblock 152 166 498 minecraft:light[level=14]
setblock 160 166 466 minecraft:light[level=14]
setblock 160 166 474 minecraft:light[level=14]
setblock 160 166 482 minecraft:light[level=14]
setblock 160 166 490 minecraft:light[level=14]
setblock 160 166 498 minecraft:light[level=14]
setblock 168 166 466 minecraft:light[level=14]
setblock 168 166 474 minecraft:light[level=14]
setblock 168 166 482 minecraft:light[level=14]
setblock 168 166 490 minecraft:light[level=14]
setblock 168 166 498 minecraft:light[level=14]
setblock 176 166 466 minecraft:light[level=14]
setblock 176 166 474 minecraft:light[level=14]
setblock 176 166 482 minecraft:light[level=14]
setblock 176 166 490 minecraft:light[level=14]
setblock 176 166 498 minecraft:light[level=14]
fill 183 166 466 183 211 466 minecraft:end_stone_bricks
setblock 183 166 492 minecraft:magenta_stained_glass
fill 183 166 493 183 215 493 minecraft:end_stone_bricks
setblock 183 166 494 minecraft:pearlescent_froglight
fill 141 167 491 141 214 491 minecraft:end_stone_bricks
fill 155 167 498 156 168 499 minecraft:obsidian
setblock 174 167 463 minecraft:pearlescent_froglight
fill 183 167 492 183 214 492 minecraft:end_stone_bricks
fill 183 167 494 183 182 494 minecraft:end_stone_bricks
setblock 141 168 496 minecraft:white_concrete
setblock 147 168 463 minecraft:magenta_stained_glass
setblock 148 168 463 minecraft:pearlescent_froglight
setblock 156 168 463 minecraft:white_concrete
fill 174 168 463 174 210 463 minecraft:end_stone_bricks
fill 141 169 496 141 199 496 minecraft:end_stone_bricks
fill 147 169 463 148 199 463 minecraft:end_stone_bricks
fill 156 169 463 156 172 463 minecraft:end_stone_bricks
setblock 183 169 476 minecraft:white_concrete
fill 164 170 476 164 171 476 minecraft:obsidian
fill 183 170 469 183 214 469 minecraft:end_stone_bricks
setblock 183 170 470 minecraft:pearlescent_froglight
fill 183 170 476 183 178 476 minecraft:end_stone_bricks
fill 141 171 471 141 173 471 minecraft:magenta_concrete
setblock 141 171 486 minecraft:magenta_stained_glass
fill 141 171 487 141 173 487 minecraft:magenta_concrete
fill 141 171 503 141 173 503 minecraft:magenta_concrete
fill 145 171 463 145 173 463 minecraft:magenta_concrete
fill 155 171 505 155 173 505 minecraft:magenta_concrete
fill 156 171 505 156 203 505 minecraft:end_stone_bricks
setblock 157 171 505 minecraft:pearlescent_froglight
fill 161 171 463 161 173 463 minecraft:magenta_concrete
setblock 168 171 463 minecraft:white_concrete
fill 171 171 505 171 173 505 minecraft:magenta_concrete
fill 177 171 463 177 173 463 minecraft:magenta_concrete
setblock 183 171 468 minecraft:magenta_stained_glass
fill 183 171 470 183 192 470 minecraft:end_stone_bricks
fill 183 171 473 183 173 473 minecraft:magenta_concrete
fill 183 171 489 183 173 489 minecraft:magenta_concrete
setblock 141 172 467 minecraft:magenta_stained_glass
fill 141 172 486 141 208 486 minecraft:end_stone_bricks
fill 157 172 505 157 214 505 minecraft:end_stone_bricks
fill 168 172 463 168 210 463 minecraft:end_stone_bricks
fill 183 172 468 183 214 468 minecraft:end_stone_bricks
fill 141 173 467 141 210 467 minecraft:end_stone_bricks
setblock 152 173 463 minecraft:magenta_stained_glass
setblock 156 173 463 minecraft:white_concrete
fill 141 174 471 141 188 471 minecraft:end_stone_bricks
fill 141 174 487 141 188 487 minecraft:end_stone_bricks
fill 141 174 503 141 188 503 minecraft:end_stone_bricks
setblock 144 174 466 minecraft:light[level=14]
setblock 144 174 474 minecraft:light[level=14]
setblock 144 174 482 minecraft:light[level=14]
setblock 144 174 490 minecraft:light[level=14]
setblock 144 174 498 minecraft:light[level=14]
fill 145 174 463 145 188 463 minecraft:end_stone_bricks
fill 152 174 463 152 186 463 minecraft:end_stone_bricks
setblock 152 174 466 minecraft:light[level=14]
setblock 152 174 474 minecraft:light[level=14]
setblock 152 174 482 minecraft:light[level=14]
setblock 152 174 490 minecraft:light[level=14]
setblock 152 174 498 minecraft:light[level=14]
fill 155 174 505 155 188 505 minecraft:end_stone_bricks
fill 156 174 463 156 210 463 minecraft:end_stone_bricks
setblock 160 174 466 minecraft:light[level=14]
setblock 160 174 474 minecraft:light[level=14]
setblock 160 174 482 minecraft:light[level=14]
setblock 160 174 490 minecraft:light[level=14]
setblock 160 174 498 minecraft:light[level=14]
fill 161 174 463 161 183 463 minecraft:end_stone_bricks
setblock 168 174 466 minecraft:light[level=14]
setblock 168 174 474 minecraft:light[level=14]
setblock 168 174 482 minecraft:light[level=14]
setblock 168 174 490 minecraft:light[level=14]
setblock 168 174 498 minecraft:light[level=14]
setblock 168 174 505 minecraft:white_concrete
fill 171 174 505 171 188 505 minecraft:end_stone_bricks
setblock 172 174 463 minecraft:magenta_stained_glass
setblock 176 174 466 minecraft:light[level=14]
setblock 176 174 474 minecraft:light[level=14]
setblock 176 174 482 minecraft:light[level=14]
setblock 176 174 490 minecraft:light[level=14]
setblock 176 174 498 minecraft:light[level=14]
fill 177 174 463 177 188 463 minecraft:end_stone_bricks
fill 183 174 473 183 188 473 minecraft:end_stone_bricks
fill 183 174 489 183 188 489 minecraft:end_stone_bricks
setblock 141 175 474 minecraft:pearlescent_froglight
setblock 141 175 481 minecraft:pearlescent_froglight
fill 141 175 482 141 214 482 minecraft:end_stone_bricks
setblock 164 175 463 minecraft:white_concrete
fill 168 175 505 168 214 505 minecraft:end_stone_bricks
fill 172 175 463 172 214 463 minecraft:end_stone_bricks
setblock 183 175 503 minecraft:white_concrete
fill 141 176 474 141 200 474 minecraft:end_stone_bricks
fill 141 176 481 141 182 481 minecraft:end_stone_bricks
setblock 141 176 501 minecraft:white_concrete
fill 141 176 502 141 197 502 minecraft:end_stone_bricks
setblock 153 176 505 minecraft:magenta_stained_glass
setblock 162 176 463 minecraft:magenta_stained_glass
fill 164 176 463 164 198 463 minecraft:end_stone_bricks
fill 183 176 503 183 203 503 minecraft:end_stone_bricks
fill 141 177 501 141 214 501 minecraft:end_stone_bricks
fill 153 177 505 153 214 505 minecraft:end_stone_bricks
setblock 161 177 505 minecraft:magenta_stained_glass
setblock 162 177 463 minecraft:end_stone_bricks
setblock 141 178 500 minecraft:pearlescent_froglight
fill 158 178 478 160 178 480 minecraft:redstone_block
fill 159 178 485 161 178 487 minecraft:redstone_block
fill 161 178 505 161 210 505 minecraft:end_stone_bricks
setblock 162 178 463 minecraft:white_concrete
fill 165 178 463 165 179 463 minecraft:white_concrete
fill 166 178 478 168 178 480 minecraft:redstone_block
fill 166 178 484 168 178 486 minecraft:redstone_block
setblock 180 178 505 minecraft:white_concrete
fill 141 179 500 141 181 500 minecraft:end_stone_bricks
fill 145 179 481 161 179 483 minecraft:magenta_concrete
fill 162 179 463 162 184 463 minecraft:end_stone_bricks
fill 162 179 464 164 179 480 minecraft:magenta_concrete
fill 162 179 484 164 179 500 minecraft:magenta_concrete
fill 165 179 481 181 179 483 minecraft:magenta_concrete
fill 180 179 505 180 214 505 minecraft:end_stone_bricks
setblock 183 179 476 minecraft:pearlescent_froglight
setblock 183 179 498 minecraft:magenta_stained_glass
setblock 183 179 499 minecraft:pearlescent_froglight
fill 142 180 464 144 180 504 minecraft:black_concrete
fill 145 180 464 156 180 480 minecraft:black_concrete
fill 145 180 481 161 180 481 minecraft:pearlescent_froglight
fill 145 180 482 160 180 482 minecraft:magenta_concrete
fill 145 180 483 161 180 483 minecraft:pearlescent_froglight
fill 145 180 484 157 180 504 minecraft:black_concrete
fill 157 180 464 161 180 476 minecraft:black_concrete
fill 157 180 477 157 180 480 minecraft:pearlescent_froglight
fill 158 180 463 159 205 463 minecraft:end_stone_bricks
fill 158 180 477 162 180 477 minecraft:pearlescent_froglight
fill 158 180 478 160 180 480 minecraft:black_concrete
fill 158 180 484 158 180 488 minecraft:pearlescent_froglight
fill 158 180 489 161 180 504 minecraft:black_concrete
setblock 158 180 505 minecraft:pearlescent_froglight
fill 159 180 484 165 180 484 minecraft:pearlescent_froglight
fill 159 180 485 161 180 487 minecraft:black_concrete
fill 159 180 488 162 180 488 minecraft:pearlescent_froglight
setblock 160 180 463 minecraft:magenta_stained_glass
fill 161 180 478 162 180 480 minecraft:pearlescent_froglight
setblock 161 180 482 minecraft:pearlescent_froglight
fill 162 180 464 162 180 476 minecraft:pearlescent_froglight
fill 162 180 485 162 180 487 minecraft:pearlescent_froglight
fill 162 180 489 162 180 500 minecraft:pearlescent_froglight
fill 162 180 501 182 180 504 minecraft:black_concrete
fill 163 180 464 163 180 479 minecraft:magenta_concrete
fill 163 180 480 165 180 480 minecraft:pearlescent_froglight
fill 163 180 485 163 180 500 minecraft:magenta_concrete
fill 164 180 464 164 180 479 minecraft:pearlescent_froglight
fill 164 180 485 164 180 500 minecraft:pearlescent_froglight
fill 165 180 463 165 212 463 minecraft:end_stone_bricks
fill 165 180 464 182 180 476 minecraft:black_concrete
fill 165 180 477 165 180 479 minecraft:pearlescent_froglight
fill 165 180 481 165 180 483 minecraft:pearlescent_froglight
fill 165 180 485 165 180 487 minecraft:pearlescent_froglight
fill 165 180 488 182 180 500 minecraft:black_concrete
fill 166 180 477 169 180 477 minecraft:pearlescent_froglight
fill 166 180 478 168 180 480 minecraft:black_concrete
fill 166 180 481 181 180 481 minecraft:pearlescent_froglight
fill 166 180 482 181 180 482 minecraft:magenta_concrete
fill 166 180 483 181 180 483 minecraft:pearlescent_froglight
fill 166 180 484 168 180 486 minecraft:black_concrete
fill 166 180 487 169 180 487 minecraft:pearlescent_froglight
fill 169 180 478 169 180 480 minecraft:pearlescent_froglight
fill 169 180 484 169 180 486 minecraft:pearlescent_froglight
fill 170 180 477 182 180 480 minecraft:black_concrete
fill 170 180 484 182 180 487 minecraft:black_concrete
fill 182 180 481 182 180 483 minecraft:black_concrete
setblock 183 180 464 minecraft:white_concrete
fill 183 180 476 183 212 476 minecraft:end_stone_bricks
setblock 183 180 479 minecraft:white_concrete
fill 183 180 498 183 202 499 minecraft:end_stone_bricks
fill 151 181 482 151 182 483 minecraft:cobblestone
fill 153 181 475 153 182 476 minecraft:cobblestone
fill 153 181 490 153 182 491 minecraft:cobblestone
fill 154 181 475 159 181 489 minecraft:dark_oak_planks
fill 158 181 505 158 200 505 minecraft:end_stone_bricks
fill 160 181 463 160 214 463 minecraft:end_stone_bricks
fill 160 181 471 160 182 472 minecraft:cobblestone
fill 160 181 475 172 181 478 minecraft:dark_oak_planks
fill 160 181 487 172 181 489 minecraft:dark_oak_planks
fill 160 181 494 160 182 495 minecraft:cobblestone
fill 167 181 471 167 182 472 minecraft:cobblestone
fill 167 181 494 167 182 495 minecraft:cobblestone
fill 168 181 479 172 181 486 minecraft:dark_oak_planks
setblock 173 181 505 minecraft:pearlescent_froglight
fill 174 181 475 174 182 476 minecraft:cobblestone
fill 174 181 490 174 182 491 minecraft:cobblestone
fill 174 181 505 175 208 505 minecraft:end_stone_bricks
fill 176 181 482 176 182 483 minecraft:cobblestone
fill 183 181 464 183 214 464 minecraft:end_stone_bricks
fill 183 181 479 183 185 479 minecraft:end_stone_bricks
fill 141 182 476 141 195 476 minecraft:end_stone_bricks
setblock 141 182 477 minecraft:magenta_stained_glass
setblock 141 182 500 minecraft:white_concrete
setblock 144 182 463 minecraft:magenta_stained_glass
setblock 144 182 466 minecraft:light[level=14]
setblock 144 182 474 minecraft:light[level=14]
setblock 144 182 482 minecraft:light[level=14]
setblock 144 182 490 minecraft:light[level=14]
setblock 144 182 498 minecraft:light[level=14]
setblock 147 182 505 minecraft:pearlescent_froglight
setblock 152 182 466 minecraft:light[level=14]
setblock 152 182 474 minecraft:light[level=14]
setblock 152 182 482 minecraft:light[level=14]
setblock 152 182 490 minecraft:light[level=14]
setblock 152 182 498 minecraft:light[level=14]
fill 154 182 475 154 182 489 minecraft:dark_oak_planks
fill 155 182 475 172 182 475 minecraft:dark_oak_planks
fill 155 182 489 172 182 489 minecraft:dark_oak_planks
setblock 160 182 466 minecraft:light[level=14]
setblock 160 182 474 minecraft:light[level=14]
setblock 160 182 490 minecraft:light[level=14]
setblock 160 182 498 minecraft:light[level=14]
setblock 168 182 466 minecraft:light[level=14]
setblock 168 182 474 minecraft:light[level=14]
setblock 168 182 482 minecraft:light[level=14]
setblock 168 182 490 minecraft:light[level=14]
setblock 168 182 498 minecraft:light[level=14]
fill 172 182 476 172 182 488 minecraft:dark_oak_planks
fill 173 182 505 173 197 505 minecraft:end_stone_bricks
setblock 176 182 466 minecraft:light[level=14]
setblock 176 182 474 minecraft:light[level=14]
setblock 176 182 490 minecraft:light[level=14]
setblock 176 182 498 minecraft:light[level=14]
fill 181 182 463 181 214 463 minecraft:end_stone_bricks
setblock 182 182 463 minecraft:pearlescent_froglight
fill 183 182 463 183 215 463 minecraft:end_stone_bricks
fill 141 183 477 141 212 477 minecraft:end_stone_bricks
setblock 141 183 481 minecraft:magenta_stained_glass
fill 141 183 500 141 214 500 minecraft:end_stone_bricks
fill 144 183 463 144 212 463 minecraft:end_stone_bricks
fill 147 183 505 147 188 505 minecraft:end_stone_bricks
fill 154 183 475 154 188 475 minecraft:dark_oak_planks
setblock 154 183 476 minecraft:ochre_froglight
fill 154 183 477 154 188 478 minecraft:dark_oak_planks
setblock 154 183 479 minecraft:ochre_froglight
fill 154 183 480 154 188 481 minecraft:dark_oak_planks
setblock 154 183 482 minecraft:ochre_froglight
fill 154 183 483 154 188 484 minecraft:dark_oak_planks
setblock 154 183 485 minecraft:ochre_froglight
fill 154 183 486 154 188 487 minecraft:dark_oak_planks
setblock 154 183 488 minecraft:ochre_froglight
fill 154 183 489 155 188 489 minecraft:dark_oak_planks
setblock 155 183 475 minecraft:ochre_froglight
fill 156 183 475 157 188 475 minecraft:dark_oak_planks
setblock 156 183 489 minecraft:ochre_froglight
fill 157 183 489 158 188 489 minecraft:dark_oak_planks
setblock 158 183 475 minecraft:ochre_froglight
fill 159 183 475 160 188 475 minecraft:dark_oak_planks
setblock 159 183 489 minecraft:ochre_froglight
fill 160 183 489 161 188 489 minecraft:dark_oak_planks
setblock 161 183 475 minecraft:ochre_froglight
fill 162 183 475 163 188 475 minecraft:dark_oak_planks
setblock 162 183 489 minecraft:ochre_froglight
fill 163 183 489 164 188 489 minecraft:dark_oak_planks
setblock 164 183 475 minecraft:ochre_froglight
fill 165 183 475 166 188 475 minecraft:dark_oak_planks
setblock 165 183 489 minecraft:ochre_froglight
fill 166 183 489 167 188 489 minecraft:dark_oak_planks
setblock 167 183 475 minecraft:ochre_froglight
fill 168 183 475 169 188 475 minecraft:dark_oak_planks
setblock 168 183 489 minecraft:ochre_froglight
fill 169 183 489 170 188 489 minecraft:dark_oak_planks
setblock 170 183 475 minecraft:ochre_froglight
fill 171 183 475 172 188 475 minecraft:dark_oak_planks
setblock 171 183 489 minecraft:ochre_froglight
setblock 172 183 476 minecraft:ochre_froglight
fill 172 183 477 172 188 478 minecraft:dark_oak_planks
setblock 172 183 479 minecraft:ochre_froglight
fill 172 183 480 172 188 481 minecraft:dark_oak_planks
setblock 172 183 482 minecraft:ochre_froglight
fill 172 183 483 172 188 484 minecraft:dark_oak_planks
setblock 172 183 485 minecraft:ochre_froglight
fill 172 183 486 172 188 487 minecraft:dark_oak_planks
setblock 172 183 488 minecraft:ochre_froglight
fill 172 183 489 172 188 489 minecraft:dark_oak_planks
fill 182 183 463 182 204 463 minecraft:end_stone_bricks
setblock 183 183 494 minecraft:pearlescent_froglight
fill 141 184 481 141 214 481 minecraft:end_stone_bricks
fill 154 184 476 154 186 476 minecraft:dark_oak_planks
fill 154 184 479 154 186 479 minecraft:dark_oak_planks
fill 154 184 482 154 186 482 minecraft:dark_oak_planks
fill 154 184 485 154 186 485 minecraft:dark_oak_planks
fill 154 184 488 154 186 488 minecraft:dark_oak_planks
fill 155 184 475 155 186 475 minecraft:dark_oak_planks
fill 156 184 489 156 186 489 minecraft:dark_oak_planks
fill 158 184 475 158 186 475 minecraft:dark_oak_planks
fill 159 184 489 159 186 489 minecraft:dark_oak_planks
setblock 161 184 463 minecraft:magenta_stained_glass
fill 161 184 475 161 186 475 minecraft:dark_oak_planks
fill 162 184 489 162 186 489 minecraft:dark_oak_planks
fill 164 184 475 164 186 475 minecraft:dark_oak_planks
fill 165 184 464 169 184 466 minecraft:magenta_stained_glass
fill 165 184 489 165 186 489 minecraft:dark_oak_planks
fill 166 184 467 168 186 467 minecraft:magenta_stained_glass
fill 167 184 468 167 186 468 minecraft:magenta_stained_glass
fill 167 184 475 167 186 475 minecraft:dark_oak_planks
fill 168 184 489 168 186 489 minecraft:dark_oak_planks
fill 170 184 475 170 186 475 minecraft:dark_oak_planks
fill 171 184 489 171 186 489 minecraft:dark_oak_planks
fill 172 184 476 172 186 476 minecraft:dark_oak_planks
fill 172 184 479 172 186 479 minecraft:dark_oak_planks
fill 172 184 482 172 186 482 minecraft:dark_oak_planks
fill 172 184 485 172 186 485 minecraft:dark_oak_planks
fill 172 184 488 172 186 488 minecraft:dark_oak_planks
fill 183 184 494 183 214 494 minecraft:end_stone_bricks
fill 144 185 477 145 186 478 minecraft:purpur_block
fill 153 185 470 155 186 470 minecraft:obsidian
fill 154 185 469 154 186 469 minecraft:obsidian
fill 154 185 471 154 186 471 minecraft:obsidian
fill 161 185 463 161 186 463 minecraft:end_stone_bricks
setblock 162 185 463 minecraft:white_concrete
fill 165 185 464 169 185 464 minecraft:magenta_stained_glass
fill 166 185 465 168 185 466 minecraft:magenta_stained_glass
fill 166 185 468 166 186 468 minecraft:magenta_stained_glass
fill 167 185 469 167 186 469 minecraft:magenta_stained_glass
fill 168 185 468 168 186 468 minecraft:magenta_stained_glass
setblock 169 185 463 minecraft:magenta_stained_glass
setblock 183 185 467 minecraft:magenta_stained_glass
setblock 144 186 505 minecraft:white_concrete
fill 162 186 463 162 214 463 minecraft:end_stone_bricks
fill 166 186 466 168 186 466 minecraft:magenta_stained_glass
setblock 166 186 469 minecraft:magenta_stained_glass
fill 167 186 464 167 186 465 minecraft:magenta_stained_glass
fill 167 186 470 167 187 470 minecraft:magenta_stained_glass
setblock 168 186 469 minecraft:magenta_stained_glass
fill 169 186 463 169 203 463 minecraft:end_stone_bricks
fill 177 186 479 177 187 479 minecraft:magenta_stained_glass
fill 183 186 467 183 212 467 minecraft:end_stone_bricks
setblock 183 186 479 minecraft:magenta_stained_glass
setblock 183 186 487 minecraft:magenta_stained_glass
fill 144 187 505 144 214 505 minecraft:end_stone_bricks
setblock 152 187 463 minecraft:white_concrete
setblock 154 187 476 minecraft:ochre_froglight
setblock 154 187 479 minecraft:ochre_froglight
setblock 154 187 482 minecraft:ochre_froglight
setblock 154 187 485 minecraft:ochre_froglight
setblock 154 187 488 minecraft:ochre_froglight
setblock 155 187 475 minecraft:ochre_froglight
setblock 156 187 489 minecraft:ochre_froglight
setblock 158 187 475 minecraft:ochre_froglight
setblock 159 187 489 minecraft:ochre_froglight
setblock 161 187 463 minecraft:pearlescent_froglight
setblock 161 187 475 minecraft:ochre_froglight
fill 161 187 500 163 188 500 minecraft:end_stone
setblock 162 187 489 minecraft:ochre_froglight
fill 162 187 499 162 188 499 minecraft:end_stone
fill 162 187 501 162 188 501 minecraft:end_stone
setblock 164 187 475 minecraft:ochre_froglight
setblock 165 187 489 minecraft:ochre_froglight
setblock 167 187 475 minecraft:ochre_froglight
setblock 168 187 489 minecraft:ochre_froglight
setblock 170 187 475 minecraft:ochre_froglight
setblock 171 187 489 minecraft:ochre_froglight
setblock 172 187 476 minecraft:ochre_froglight
setblock 172 187 479 minecraft:ochre_froglight
setblock 172 187 482 minecraft:ochre_froglight
setblock 172 187 485 minecraft:ochre_froglight
setblock 172 187 488 minecraft:ochre_froglight
fill 183 187 479 183 210 479 minecraft:end_stone_bricks
fill 183 187 487 183 202 487 minecraft:end_stone_bricks
fill 152 188 463 152 189 463 minecraft:end_stone_bricks
fill 154 188 476 172 188 476 minecraft:dark_oak_planks
fill 154 188 479 159 188 479 minecraft:dark_oak_planks
fill 154 188 482 159 188 482 minecraft:dark_oak_planks
fill 154 188 485 159 188 485 minecraft:dark_oak_planks
fill 154 188 488 172 188 488 minecraft:dark_oak_planks
setblock 155 188 475 minecraft:dark_oak_planks
fill 155 188 477 171 188 478 minecraft:dark_oak_planks
fill 155 188 480 159 188 481 minecraft:dark_oak_planks
fill 155 188 483 159 188 484 minecraft:dark_oak_planks
fill 155 188 486 159 188 487 minecraft:dark_oak_planks
setblock 156 188 489 minecraft:dark_oak_planks
setblock 158 188 475 minecraft:dark_oak_planks
setblock 159 188 489 minecraft:dark_oak_planks
fill 160 188 487 171 188 487 minecraft:dark_oak_planks
setblock 161 188 463 minecraft:end_stone_bricks
setblock 161 188 475 minecraft:dark_oak_planks
setblock 162 188 489 minecraft:dark_oak_planks
setblock 164 188 475 minecraft:dark_oak_planks
setblock 165 188 489 minecraft:dark_oak_planks
setblock 167 188 475 minecraft:dark_oak_planks
fill 168 188 479 171 188 486 minecraft:dark_oak_planks
setblock 168 188 489 minecraft:dark_oak_planks
setblock 170 188 475 minecraft:dark_oak_planks
setblock 171 188 489 minecraft:dark_oak_planks
setblock 172 188 479 minecraft:dark_oak_planks
setblock 172 188 482 minecraft:dark_oak_planks
setblock 172 188 485 minecraft:dark_oak_planks
fill 177 188 479 177 193 479 minecraft:purpur_block
fill 141 189 471 141 191 471 minecraft:magenta_concrete
fill 141 189 487 141 191 487 minecraft:magenta_concrete
fill 141 189 503 141 191 503 minecraft:magenta_concrete
fill 145 189 463 145 191 463 minecraft:magenta_concrete
setblock 147 189 505 minecraft:magenta_stained_glass
fill 154 189 475 159 189 489 minecraft:deepslate_tiles
fill 155 189 505 155 191 505 minecraft:magenta_concrete
fill 160 189 475 172 189 478 minecraft:deepslate_tiles
fill 160 189 487 172 189 489 minecraft:deepslate_tiles
fill 161 189 463 161 191 463 minecraft:magenta_concrete
setblock 166 189 505 minecraft:pearlescent_froglight
fill 168 189 479 172 189 486 minecraft:deepslate_tiles
fill 171 189 505 171 191 505 minecraft:magenta_concrete
fill 177 189 463 177 191 463 minecraft:magenta_concrete
fill 177 189 478 177 193 478 minecraft:purpur_block
fill 183 189 473 183 191 473 minecraft:magenta_concrete
fill 183 189 489 183 191 489 minecraft:magenta_concrete
setblock 183 189 502 minecraft:white_concrete
setblock 144 190 466 minecraft:light[level=14]
setblock 144 190 474 minecraft:light[level=14]
setblock 144 190 482 minecraft:light[level=14]
setblock 144 190 490 minecraft:light[level=14]
setblock 144 190 498 minecraft:light[level=14]
fill 147 190 505 147 211 505 minecraft:end_stone_bricks
setblock 152 190 463 minecraft:magenta_stained_glass
setblock 152 190 466 minecraft:light[level=14]
setblock 152 190 474 minecraft:light[level=14]
setblock 152 190 482 minecraft:light[level=14]
setblock 152 190 490 minecraft:light[level=14]
setblock 152 190 498 minecraft:light[level=14]
fill 155 190 476 159 190 488 minecraft:deepslate_tiles
setblock 157 190 463 minecraft:magenta_stained_glass
setblock 160 190 466 minecraft:light[level=14]
setblock 160 190 474 minecraft:light[level=14]
fill 160 190 476 171 190 478 minecraft:deepslate_tiles
fill 160 190 487 171 190 488 minecraft:deepslate_tiles
setblock 160 190 490 minecraft:light[level=14]
setblock 160 190 498 minecraft:light[level=14]
fill 166 190 505 166 214 505 minecraft:end_stone_bricks
setblock 168 190 466 minecraft:light[level=14]
setblock 168 190 474 minecraft:light[level=14]
fill 168 190 479 171 190 486 minecraft:deepslate_tiles
setblock 168 190 490 minecraft:light[level=14]
setblock 168 190 498 minecraft:light[level=14]
setblock 176 190 466 minecraft:light[level=14]
setblock 176 190 474 minecraft:light[level=14]
fill 176 190 479 176 193 479 minecraft:purpur_block
setblock 176 190 482 minecraft:light[level=14]
setblock 176 190 490 minecraft:light[level=14]
setblock 176 190 498 minecraft:light[level=14]
fill 177 190 480 177 193 480 minecraft:purpur_block
fill 178 190 478 178 193 479 minecraft:purpur_block
fill 183 190 502 183 199 502 minecraft:end_stone_bricks
fill 152 191 463 152 214 463 minecraft:end_stone_bricks
fill 156 191 477 159 191 487 minecraft:deepslate_tiles
fill 157 191 463 157 210 463 minecraft:end_stone_bricks
fill 160 191 477 170 191 478 minecraft:deepslate_tiles
fill 160 191 487 170 191 487 minecraft:deepslate_tiles
fill 168 191 479 170 191 486 minecraft:deepslate_tiles
fill 170 191 472 170 192 472 minecraft:magenta_stained_glass
setblock 172 191 505 minecraft:white_concrete
setblock 175 191 463 minecraft:pearlescent_froglight
fill 176 191 478 176 193 478 minecraft:purpur_block
fill 176 191 480 176 193 480 minecraft:purpur_block
fill 178 191 480 178 193 480 minecraft:purpur_block
setblock 141 192 466 minecraft:pearlescent_froglight
fill 141 192 471 141 197 471 minecraft:end_stone_bricks
fill 141 192 487 141 197 487 minecraft:end_stone_bricks
fill 141 192 503 141 197 503 minecraft:end_stone_bricks
setblock 143 192 463 minecraft:magenta_stained_glass
fill 145 192 463 145 197 463 minecraft:end_stone_bricks
fill 155 192 505 155 197 505 minecraft:end_stone_bricks
fill 157 192 478 159 192 486 minecraft:deepslate_tiles
fill 160 192 478 169 192 478 minecraft:deepslate_tiles
fill 161 192 463 161 194 463 minecraft:end_stone_bricks
fill 167 192 499 167 193 499 minecraft:magenta_stained_glass
fill 168 192 479 169 192 486 minecraft:deepslate_tiles
fill 171 192 505 172 197 505 minecraft:end_stone_bricks
fill 175 192 463 175 214 463 minecraft:end_stone_bricks
fill 175 192 479 175 193 479 minecraft:purpur_block
fill 176 192 477 178 193 477 minecraft:purpur_block
fill 177 192 463 177 197 463 minecraft:end_stone_bricks
fill 179 192 478 179 193 479 minecraft:purpur_block
fill 183 192 473 183 197 473 minecraft:end_stone_bricks
fill 183 192 489 183 197 489 minecraft:end_stone_bricks
fill 141 193 466 141 214 466 minecraft:end_stone_bricks
fill 143 193 463 143 214 463 minecraft:end_stone_bricks
fill 158 193 479 159 193 485 minecraft:deepslate_tiles
fill 163 193 473 163 194 473 minecraft:purpur_block
fill 168 193 479 168 193 485 minecraft:deepslate_tiles
fill 170 193 472 170 198 472 minecraft:purpur_block
setblock 175 193 478 minecraft:purpur_block
setblock 175 193 480 minecraft:purpur_block
fill 176 193 481 178 193 481 minecraft:purpur_block
setblock 179 193 477 minecraft:purpur_block
setblock 179 193 480 minecraft:purpur_block
setblock 183 193 470 minecraft:white_concrete
fill 159 194 480 159 194 484 minecraft:deepslate_tiles
setblock 160 194 505 minecraft:magenta_stained_glass
fill 167 194 499 167 201 499 minecraft:purpur_block
fill 169 194 472 169 198 472 minecraft:purpur_block
fill 176 194 478 176 195 478 minecraft:end_stone_bricks
fill 177 194 480 177 197 480 minecraft:end_stone_bricks
fill 179 194 478 179 196 478 minecraft:end_stone_bricks
setblock 183 194 470 minecraft:pearlescent_froglight
setblock 183 194 478 minecraft:white_concrete
fill 153 195 486 154 196 487 minecraft:obsidian
fill 160 195 505 160 206 505 minecraft:end_stone_bricks
setblock 161 195 463 minecraft:magenta_stained_glass
fill 169 195 471 170 198 471 minecraft:purpur_block
fill 169 195 473 170 198 473 minecraft:purpur_block
fill 171 195 472 171 198 472 minecraft:purpur_block
fill 183 195 470 183 210 470 minecraft:end_stone_bricks
fill 183 195 478 183 215 478 minecraft:end_stone_bricks
setblock 183 195 504 minecraft:pearlescent_froglight
fill 183 195 505 183 214 505 minecraft:end_stone_bricks
setblock 141 196 476 minecraft:magenta_stained_glass
fill 151 196 487 151 197 488 minecraft:purpur_block
setblock 154 196 463 minecraft:white_concrete
fill 161 196 463 161 197 463 minecraft:end_stone_bricks
fill 167 196 500 167 201 500 minecraft:purpur_block
setblock 167 196 505 minecraft:magenta_stained_glass
fill 168 196 499 168 201 499 minecraft:purpur_block
fill 171 196 471 171 198 471 minecraft:purpur_block
fill 171 196 473 171 198 473 minecraft:purpur_block
fill 183 196 504 183 198 504 minecraft:end_stone_bricks
fill 141 197 476 141 214 476 minecraft:end_stone_bricks
setblock 146 197 505 minecraft:pearlescent_froglight
fill 154 197 463 154 214 463 minecraft:end_stone_bricks
fill 166 197 499 166 201 500 minecraft:purpur_block
fill 167 197 498 168 201 498 minecraft:purpur_block
setblock 167 197 505 minecraft:end_stone_bricks
fill 168 197 471 168 198 473 minecraft:purpur_block
fill 168 197 500 168 201 500 minecraft:purpur_block
fill 169 197 470 170 198 470 minecraft:purpur_block
fill 169 197 474 170 198 474 minecraft:purpur_block
fill 141 198 471 141 200 471 minecraft:magenta_concrete
fill 141 198 487 141 200 487 minecraft:magenta_concrete
setblock 141 198 502 minecraft:white_concrete
fill 141 198 503 141 200 503 minecraft:magenta_concrete
setblock 144 198 466 minecraft:light[level=14]
setblock 144 198 474 minecraft:light[level=14]
setblock 144 198 482 minecraft:light[level=14]
setblock 144 198 490 minecraft:light[level=14]
setblock 144 198 498 minecraft:light[level=14]
fill 145 198 463 145 200 463 minecraft:magenta_concrete
fill 146 198 505 146 204 505 minecraft:end_stone_bricks
setblock 152 198 466 minecraft:light[level=14]
setblock 152 198 474 minecraft:light[level=14]
setblock 152 198 482 minecraft:light[level=14]
setblock 152 198 490 minecraft:light[level=14]
setblock 152 198 498 minecraft:light[level=14]
fill 155 198 505 155 200 505 minecraft:magenta_concrete
setblock 160 198 466 minecraft:light[level=14]
setblock 160 198 474 minecraft:light[level=14]
setblock 160 198 482 minecraft:light[level=14]
setblock 160 198 490 minecraft:light[level=14]
setblock 160 198 498 minecraft:light[level=14]
fill 161 198 463 161 200 463 minecraft:magenta_concrete
fill 166 198 498 166 201 498 minecraft:purpur_block
fill 167 198 501 167 201 501 minecraft:purpur_block
setblock 167 198 505 minecraft:white_concrete
setblock 168 198 466 minecraft:light[level=14]
setblock 168 198 474 minecraft:light[level=14]
setblock 168 198 482 minecraft:light[level=14]
setblock 168 198 490 minecraft:light[level=14]
fill 169 198 499 169 201 499 minecraft:purpur_block
setblock 171 198 470 minecraft:purpur_block
setblock 171 198 474 minecraft:purpur_block
fill 171 198 505 171 200 505 minecraft:magenta_concrete
fill 172 198 471 172 198 473 minecraft:purpur_block
fill 172 198 505 172 214 505 minecraft:end_stone_bricks
setblock 173 198 505 minecraft:white_concrete
setblock 176 198 466 minecraft:light[level=14]
setblock 176 198 474 minecraft:light[level=14]
setblock 176 198 482 minecraft:light[level=14]
setblock 176 198 490 minecraft:light[level=14]
setblock 176 198 498 minecraft:light[level=14]
fill 177 198 463 177 200 463 minecraft:magenta_concrete
fill 183 198 473 183 200 473 minecraft:magenta_concrete
fill 183 198 489 183 200 489 minecraft:magenta_concrete
setblock 141 199 473 minecraft:magenta_stained_glass
setblock 141 199 494 minecraft:magenta_stained_glass
fill 141 199 502 141 209 502 minecraft:end_stone_bricks
setblock 164 199 463 minecraft:pearlescent_froglight
fill 165 199 499 165 201 500 minecraft:purpur_block
fill 166 199 501 166 201 501 minecraft:purpur_block
fill 167 199 497 168 201 497 minecraft:purpur_block
fill 167 199 505 167 212 505 minecraft:end_stone_bricks
fill 168 199 472 168 200 472 minecraft:end_stone_bricks
fill 168 199 501 168 201 501 minecraft:purpur_block
fill 169 199 498 169 201 498 minecraft:purpur_block
fill 169 199 500 169 201 500 minecraft:purpur_block
fill 171 199 471 171 202 471 minecraft:end_stone_bricks
fill 171 199 473 171 203 473 minecraft:end_stone_bricks
fill 173 199 505 173 202 505 minecraft:end_stone_bricks
setblock 183 199 504 minecraft:white_concrete
setblock 141 200 472 minecraft:pearlescent_froglight
setblock 141 200 473 minecraft:end_stone_bricks
fill 141 200 494 141 201 494 minecraft:end_stone_bricks
setblock 141 200 496 minecraft:magenta_stained_glass
setblock 147 200 463 minecraft:pearlescent_froglight
fill 147 200 486 147 201 487 minecraft:obsidian
fill 148 200 463 148 203 463 minecraft:end_stone_bricks
fill 164 200 463 164 214 463 minecraft:end_stone_bricks
fill 165 200 498 165 201 498 minecraft:purpur_block
fill 165 200 501 165 201 501 minecraft:purpur_block
fill 166 200 497 166 201 497 minecraft:purpur_block
fill 167 200 502 167 201 502 minecraft:purpur_block
fill 169 200 497 169 201 497 minecraft:purpur_block
fill 169 200 501 169 201 501 minecraft:purpur_block
fill 170 200 499 170 201 499 minecraft:purpur_block
setblock 183 200 502 minecraft:magenta_stained_glass
fill 183 200 504 183 215 504 minecraft:end_stone_bricks
fill 141 201 471 141 201 472 minecraft:end_stone_bricks
setblock 141 201 473 minecraft:pearlescent_froglight
setblock 141 201 474 minecraft:magenta_stained_glass
fill 141 201 487 141 206 487 minecraft:end_stone_bricks
fill 141 201 496 141 211 496 minecraft:end_stone_bricks
fill 141 201 503 141 206 503 minecraft:end_stone_bricks
fill 145 201 463 145 206 463 minecraft:end_stone_bricks
fill 147 201 463 147 214 463 minecraft:end_stone_bricks
fill 155 201 505 155 206 505 minecraft:end_stone_bricks
fill 158 201 505 158 202 505 minecraft:pearlescent_froglight
fill 161 201 463 161 206 463 minecraft:end_stone_bricks
fill 164 201 499 164 201 500 minecraft:purpur_block
setblock 164 201 505 minecraft:magenta_stained_glass
setblock 165 201 497 minecraft:purpur_block
setblock 166 201 502 minecraft:purpur_block
fill 167 201 496 168 201 496 minecraft:purpur_block
setblock 168 201 502 minecraft:purpur_block
setblock 170 201 498 minecraft:purpur_block
setblock 170 201 500 minecraft:purpur_block
setblock 170 201 505 minecraft:pearlescent_froglight
fill 171 201 505 171 206 505 minecraft:end_stone_bricks
fill 177 201 463 177 206 463 minecraft:end_stone_bricks
fill 183 201 473 183 203 473 minecraft:end_stone_bricks
setblock 183 201 489 minecraft:end_stone_bricks
fill 183 201 502 183 211 502 minecraft:end_stone_bricks
fill 141 202 471 141 206 471 minecraft:end_stone_bricks
setblock 141 202 472 minecraft:pearlescent_froglight
fill 141 202 473 141 214 474 minecraft:end_stone_bricks
setblock 141 202 483 minecraft:pearlescent_froglight
setblock 141 202 494 minecraft:magenta_stained_glass
fill 164 202 505 164 214 505 minecraft:end_stone_bricks
fill 166 202 499 166 206 499 minecraft:end_stone_bricks
fill 168 202 498 168 204 498 minecraft:end_stone_bricks
fill 168 202 501 168 204 501 minecraft:end_stone_bricks
fill 170 202 505 170 205 505 minecraft:end_stone_bricks
setblock 183 202 489 minecraft:white_concrete
fill 141 203 472 141 209 472 minecraft:end_stone_bricks
fill 141 203 483 141 214 483 minecraft:end_stone_bricks
fill 141 203 494 141 214 494 minecraft:end_stone_bricks
fill 141 203 497 141 214 497 minecraft:end_stone_bricks
setblock 141 203 498 minecraft:pearlescent_froglight
fill 149 203 505 150 206 505 minecraft:end_stone_bricks
setblock 151 203 505 minecraft:magenta_stained_glass
fill 152 203 505 152 209 505 minecraft:end_stone_bricks
fill 158 203 505 158 212 505 minecraft:end_stone_bricks
setblock 165 203 505 minecraft:white_concrete
setblock 173 203 505 minecraft:white_concrete
setblock 183 203 487 minecraft:magenta_stained_glass
fill 183 203 489 183 206 489 minecraft:end_stone_bricks
fill 183 203 498 183 214 498 minecraft:end_stone_bricks
setblock 183 203 499 minecraft:pearlescent_froglight
fill 141 204 498 141 214 498 minecraft:end_stone_bricks
setblock 148 204 463 minecraft:white_concrete
fill 151 204 505 151 212 505 minecraft:end_stone_bricks
fill 153 204 468 155 205 468 minecraft:obsidian
fill 154 204 469 155 205 469 minecraft:obsidian
setblock 154 204 505 minecraft:magenta_stained_glass
setblock 156 204 505 minecraft:magenta_stained_glass
fill 159 204 505 159 205 505 minecraft:magenta_stained_glass
fill 165 204 505 165 209 505 minecraft:end_stone_bricks
setblock 169 204 463 minecraft:pearlescent_froglight
fill 173 204 505 173 214 505 minecraft:end_stone_bricks
setblock 183 204 473 minecraft:white_concrete
fill 183 204 487 183 214 487 minecraft:end_stone_bricks
setblock 183 204 496 minecraft:white_concrete
fill 183 204 499 183 206 499 minecraft:end_stone_bricks
setblock 183 204 503 minecraft:magenta_stained_glass
setblock 146 205 505 minecraft:white_concrete
fill 148 205 463 148 214 463 minecraft:end_stone_bricks
fill 154 205 505 154 212 505 minecraft:end_stone_bricks
setblock 155 205 463 minecraft:magenta_stained_glass
fill 156 205 505 156 214 505 minecraft:end_stone_bricks
fill 159 205 475 159 206 475 minecraft:purpur_block
fill 169 205 463 169 214 463 minecraft:end_stone_bricks
setblock 182 205 463 minecraft:white_concrete
fill 183 205 473 183 206 473 minecraft:end_stone_bricks
setblock 183 205 488 minecraft:magenta_stained_glass
fill 183 205 496 183 214 496 minecraft:end_stone_bricks
fill 183 205 503 183 214 503 minecraft:end_stone_bricks
setblock 144 206 466 minecraft:light[level=14]
setblock 144 206 474 minecraft:light[level=14]
setblock 144 206 482 minecraft:light[level=14]
setblock 144 206 490 minecraft:light[level=14]
setblock 144 206 498 minecraft:light[level=14]
fill 146 206 505 146 214 505 minecraft:end_stone_bricks
setblock 152 206 466 minecraft:light[level=14]
setblock 152 206 474 minecraft:light[level=14]
setblock 152 206 482 minecraft:light[level=14]
setblock 152 206 490 minecraft:light[level=14]
setblock 152 206 498 minecraft:light[level=14]
fill 155 206 463 155 214 463 minecraft:end_stone_bricks
fill 158 206 463 158 210 463 minecraft:end_stone_bricks
setblock 159 206 463 minecraft:magenta_stained_glass
fill 159 206 505 159 210 505 minecraft:end_stone_bricks
setblock 160 206 466 minecraft:light[level=14]
setblock 160 206 474 minecraft:light[level=14]
setblock 160 206 482 minecraft:light[level=14]
setblock 160 206 490 minecraft:light[level=14]
setblock 160 206 498 minecraft:light[level=14]
setblock 168 206 466 minecraft:light[level=14]
setblock 168 206 474 minecraft:light[level=14]
setblock 168 206 482 minecraft:light[level=14]
setblock 168 206 490 minecraft:light[level=14]
setblock 168 206 498 minecraft:light[level=14]
setblock 170 206 505 minecraft:pearlescent_froglight
fill 174 206 464 174 209 464 minecraft:magenta_stained_glass
setblock 176 206 466 minecraft:light[level=14]
setblock 176 206 474 minecraft:light[level=14]
setblock 176 206 482 minecraft:light[level=14]
setblock 176 206 490 minecraft:light[level=14]
setblock 176 206 498 minecraft:light[level=14]
fill 178 206 479 180 207 479 minecraft:purpur_block
fill 179 206 480 179 207 480 minecraft:purpur_block
fill 182 206 463 182 209 463 minecraft:end_stone_bricks
setblock 183 206 482 minecraft:white_concrete
fill 183 206 488 183 208 488 minecraft:end_stone_bricks
fill 141 207 471 141 209 471 minecraft:magenta_concrete
fill 141 207 487 141 209 487 minecraft:magenta_concrete
fill 141 207 503 141 209 503 minecraft:magenta_concrete
fill 145 207 463 145 209 463 minecraft:magenta_concrete
fill 149 207 505 149 214 505 minecraft:end_stone_bricks
setblock 150 207 505 minecraft:pearlescent_froglight
fill 155 207 505 155 209 505 minecraft:magenta_concrete
setblock 159 207 463 minecraft:pearlescent_froglight
setblock 160 207 505 minecraft:white_concrete
fill 161 207 463 161 209 463 minecraft:magenta_concrete
setblock 163 207 505 minecraft:pearlescent_froglight
fill 170 207 505 170 212 505 minecraft:end_stone_bricks
fill 171 207 505 171 209 505 minecraft:magenta_concrete
fill 173 207 464 173 208 465 minecraft:magenta_stained_glass
fill 174 207 465 174 208 467 minecraft:magenta_stained_glass
fill 175 207 464 175 208 465 minecraft:magenta_stained_glass
fill 177 207 463 177 209 463 minecraft:magenta_concrete
setblock 177 207 505 minecraft:white_concrete
fill 183 207 473 183 209 473 minecraft:magenta_concrete
fill 183 207 482 183 214 482 minecraft:end_stone_bricks
setblock 183 207 485 minecraft:white_concrete
fill 183 207 489 183 209 489 minecraft:magenta_concrete
setblock 183 207 497 minecraft:white_concrete
setblock 183 207 499 minecraft:pearlescent_froglight
fill 150 208 505 150 211 505 minecraft:end_stone_bricks
fill 154 208 499 154 209 499 minecraft:magenta_stained_glass
fill 157 208 498 157 209 498 minecraft:magenta_stained_glass
fill 159 208 463 159 210 463 minecraft:end_stone_bricks
fill 160 208 505 160 216 505 minecraft:end_stone_bricks
fill 163 208 505 163 214 505 minecraft:end_stone_bricks
setblock 173 208 466 minecraft:magenta_stained_glass
fill 174 208 468 174 208 470 minecraft:magenta_stained_glass
setblock 175 208 466 minecraft:magenta_stained_glass
fill 177 208 505 177 210 505 minecraft:end_stone_bricks
fill 178 208 463 178 214 463 minecraft:end_stone_bricks
setblock 179 208 463 minecraft:white_concrete
setblock 183 208 474 minecraft:pearlescent_froglight
fill 183 208 485 183 214 485 minecraft:end_stone_bricks
setblock 183 208 497 minecraft:end_stone_bricks
fill 183 208 499 183 214 499 minecraft:end_stone_bricks
setblock 141 209 464 minecraft:white_concrete
setblock 141 209 485 minecraft:white_concrete
setblock 141 209 486 minecraft:pearlescent_froglight
setblock 150 209 463 minecraft:magenta_stained_glass
setblock 153 209 463 minecraft:pearlescent_froglight
setblock 174 209 505 minecraft:magenta_stained_glass
fill 175 209 505 175 214 505 minecraft:end_stone_bricks
fill 179 209 463 179 211 463 minecraft:end_stone_bricks
fill 183 209 474 183 215 474 minecraft:end_stone_bricks
setblock 183 209 488 minecraft:magenta_stained_glass
setblock 183 209 497 minecraft:pearlescent_froglight
fill 141 210 464 141 215 464 minecraft:end_stone_bricks
fill 141 210 471 141 214 471 minecraft:end_stone_bricks
setblock 141 210 472 minecraft:magenta_stained_glass
fill 141 210 485 141 214 487 minecraft:end_stone_bricks
setblock 141 210 490 minecraft:white_concrete
setblock 141 210 502 minecraft:white_concrete
fill 141 210 503 141 214 503 minecraft:end_stone_bricks
fill 145 210 463 145 212 463 minecraft:end_stone_bricks
fill 150 210 463 150 214 463 minecraft:end_stone_bricks
fill 152 210 494 153 211 495 minecraft:end_stone
setblock 152 210 505 minecraft:white_concrete
setblock 153 210 463 minecraft:end_stone_bricks
fill 154 210 499 154 219 499 minecraft:purpur_block
fill 155 210 505 155 214 505 minecraft:end_stone_bricks
fill 157 210 498 157 219 498 minecraft:purpur_block
fill 161 210 463 161 211 463 minecraft:end_stone_bricks
fill 163 210 475 163 211 475 minecraft:purpur_block
setblock 165 210 505 minecraft:magenta_stained_glass
fill 171 210 505 171 212 505 minecraft:end_stone_bricks
fill 174 210 505 174 215 505 minecraft:end_stone_bricks
setblock 177 210 463 minecraft:end_stone_bricks
setblock 182 210 463 minecraft:white_concrete
fill 183 210 473 183 212 473 minecraft:end_stone_bricks
fill 183 210 488 183 210 489 minecraft:end_stone_bricks
fill 183 210 497 183 211 497 minecraft:end_stone_bricks
setblock 141 211 463 minecraft:purpur_block
setblock 141 211 465 minecraft:white_concrete
setblock 141 211 467 minecraft:purpur_block
setblock 141 211 472 minecraft:white_concrete
fill 141 211 490 141 214 490 minecraft:end_stone_bricks
fill 141 211 495 141 212 495 minecraft:purpur_block
setblock 141 211 499 minecraft:purpur_block
setblock 141 211 502 minecraft:end_stone_bricks
setblock 152 211 505 minecraft:purpur_block
setblock 153 211 463 minecraft:purpur_block
fill 153 211 498 153 215 499 minecraft:purpur_block
fill 154 211 498 154 219 498 minecraft:purpur_block
fill 156 211 463 157 211 463 minecraft:purpur_block
fill 156 211 498 156 219 499 minecraft:purpur_block
fill 157 211 499 157 219 499 minecraft:purpur_block
setblock 158 211 463 minecraft:magenta_stained_glass
setblock 159 211 463 minecraft:purpur_block
setblock 159 211 505 minecraft:magenta_stained_glass
setblock 161 211 505 minecraft:pearlescent_froglight
fill 165 211 505 165 214 505 minecraft:end_stone_bricks
setblock 168 211 463 minecraft:purpur_block
setblock 174 211 463 minecraft:purpur_block
setblock 177 211 463 minecraft:purpur_block
setblock 177 211 505 minecraft:purpur_block
fill 182 211 463 182 214 463 minecraft:end_stone_bricks
fill 183 211 470 183 212 470 minecraft:purpur_block
setblock 183 211 479 minecraft:purpur_block
fill 183 211 483 183 214 483 minecraft:end_stone_bricks
setblock 183 211 484 minecraft:purpur_block
setblock 183 211 488 minecraft:pearlescent_froglight
fill 183 211 489 183 214 489 minecraft:end_stone_bricks
setblock 141 212 463 minecraft:end_stone_bricks
fill 141 212 465 141 215 465 minecraft:end_stone_bricks
fill 141 212 467 141 214 467 minecraft:end_stone_bricks
fill 141 212 468 141 213 468 minecraft:purpur_block
setblock 141 212 472 minecraft:end_stone_bricks
fill 141 212 478 141 214 478 minecraft:end_stone_bricks
setblock 141 212 479 minecraft:white_concrete
fill 141 212 480 141 213 480 minecraft:purpur_block
setblock 141 212 489 minecraft:purpur_block
setblock 141 212 493 minecraft:purpur_block
setblock 141 212 496 minecraft:purpur_block
fill 141 212 499 141 214 499 minecraft:end_stone_bricks
setblock 141 212 502 minecraft:purpur_block
setblock 142 212 463 minecraft:magenta_stained_glass
setblock 143 212 505 minecraft:purpur_block
fill 147 212 505 147 213 505 minecraft:purpur_block
setblock 150 212 505 minecraft:purpur_block
fill 152 212 492 152 213 492 minecraft:end_stone
fill 152 212 505 152 214 505 minecraft:end_stone_bricks
fill 153 212 463 153 214 463 minecraft:end_stone_bricks
fill 156 212 463 159 214 463 minecraft:end_stone_bricks
fill 156 212 497 157 219 497 minecraft:purpur_block
fill 159 212 505 159 214 505 minecraft:end_stone_bricks
setblock 161 212 463 minecraft:purpur_block
setblock 161 212 505 minecraft:end_stone_bricks
fill 168 212 463 168 214 463 minecraft:end_stone_bricks
setblock 170 212 463 minecraft:purpur_block
fill 171 212 490 171 213 490 minecraft:purpur_block
fill 174 212 463 174 214 463 minecraft:end_stone_bricks
setblock 176 212 463 minecraft:purpur_block
fill 177 212 463 177 214 463 minecraft:end_stone_bricks
fill 177 212 505 177 214 505 minecraft:end_stone_bricks
setblock 179 212 463 minecraft:purpur_block
setblock 183 212 466 minecraft:purpur_block
fill 183 212 479 183 214 479 minecraft:end_stone_bricks
fill 183 212 484 183 214 484 minecraft:end_stone_bricks
fill 183 212 488 183 214 488 minecraft:end_stone_bricks
setblock 183 212 490 minecraft:pearlescent_froglight
setblock 183 212 497 minecraft:purpur_block
fill 183 212 502 183 213 502 minecraft:purpur_block
fill 141 213 463 142 213 463 minecraft:purpur_block
setblock 141 213 472 minecraft:purpur_block
setblock 141 213 477 minecraft:purpur_block
fill 141 213 479 141 214 479 minecraft:end_stone_bricks
fill 141 213 489 141 214 489 minecraft:end_stone_bricks
setblock 141 213 492 minecraft:purpur_block
fill 141 213 493 141 214 493 minecraft:end_stone_bricks
fill 141 213 495 141 213 496 minecraft:end_stone_bricks
fill 141 213 502 141 214 502 minecraft:end_stone_bricks
fill 143 213 505 143 214 505 minecraft:end_stone_bricks
fill 144 213 463 145 213 463 minecraft:purpur_block
setblock 149 213 463 minecraft:white_concrete
fill 150 213 505 150 214 505 minecraft:end_stone_bricks
setblock 151 213 505 minecraft:purpur_block
fill 152 213 498 152 215 499 minecraft:purpur_block
fill 153 213 497 154 215 497 minecraft:purpur_block
fill 153 213 500 154 215 500 minecraft:purpur_block
setblock 154 213 505 minecraft:purpur_block
fill 155 213 498 155 219 499 minecraft:purpur_block
fill 156 213 500 157 219 500 minecraft:purpur_block
fill 158 213 497 158 219 499 minecraft:purpur_block
setblock 158 213 505 minecraft:purpur_block
fill 161 213 463 161 215 463 minecraft:end_stone_bricks
setblock 161 213 505 minecraft:purpur_block
setblock 165 213 463 minecraft:purpur_block
setblock 167 213 505 minecraft:purpur_block
fill 169 213 505 171 213 505 minecraft:purpur_block
fill 170 213 463 170 214 463 minecraft:end_stone_bricks
fill 176 213 463 176 214 463 minecraft:end_stone_bricks
fill 179 213 463 179 214 463 minecraft:end_stone_bricks
setblock 179 213 505 minecraft:purpur_block
setblock 180 213 463 minecraft:purpur_block
fill 183 213 466 183 214 466 minecraft:end_stone_bricks
setblock 183 213 467 minecraft:purpur_block
fill 183 213 470 183 214 470 minecraft:end_stone_bricks
setblock 183 213 473 minecraft:purpur_block
setblock 183 213 476 minecraft:purpur_block
setblock 183 213 481 minecraft:purpur_block
fill 183 213 490 183 214 490 minecraft:end_stone_bricks
fill 183 213 497 183 215 497 minecraft:end_stone_bricks
fill 141 214 463 142 214 463 minecraft:end_stone_bricks
setblock 141 214 468 minecraft:end_stone_bricks
fill 141 214 472 141 215 472 minecraft:end_stone_bricks
setblock 141 214 477 minecraft:end_stone_bricks
setblock 141 214 480 minecraft:end_stone_bricks
setblock 141 214 492 minecraft:pearlescent_froglight
setblock 141 214 495 minecraft:magenta_stained_glass
setblock 141 214 496 minecraft:end_stone_bricks
fill 144 214 463 145 214 463 minecraft:end_stone_bricks
setblock 144 214 466 minecraft:light[level=14]
setblock 144 214 474 minecraft:light[level=14]
setblock 144 214 482 minecraft:light[level=14]
setblock 144 214 490 minecraft:light[level=14]
setblock 144 214 498 minecraft:light[level=14]
setblock 147 214 505 minecraft:end_stone_bricks
setblock 149 214 463 minecraft:end_stone_bricks
setblock 151 214 505 minecraft:end_stone_bricks
setblock 152 214 466 minecraft:light[level=14]
setblock 152 214 474 minecraft:light[level=14]
setblock 152 214 482 minecraft:light[level=14]
setblock 152 214 490 minecraft:light[level=14]
fill 152 214 500 152 215 500 minecraft:purpur_block
setblock 154 214 505 minecraft:end_stone_bricks
fill 155 214 497 155 219 497 minecraft:purpur_block
fill 155 214 500 155 219 500 minecraft:purpur_block
fill 156 214 496 157 219 496 minecraft:purpur_block
fill 158 214 500 158 219 500 minecraft:purpur_block
setblock 158 214 505 minecraft:end_stone_bricks
setblock 160 214 466 minecraft:light[level=14]
setblock 160 214 474 minecraft:light[level=14]
setblock 160 214 482 minecraft:light[level=14]
setblock 160 214 490 minecraft:light[level=14]
setblock 160 214 498 minecraft:light[level=14]
setblock 161 214 505 minecraft:end_stone_bricks
fill 165 214 463 165 215 463 minecraft:end_stone_bricks
setblock 167 214 505 minecraft:end_stone_bricks
setblock 168 214 466 minecraft:light[level=14]
setblock 168 214 474 minecraft:light[level=14]
setblock 168 214 482 minecraft:light[level=14]
setblock 168 214 490 minecraft:light[level=14]
setblock 168 214 498 minecraft:light[level=14]
fill 169 214 505 171 214 505 minecraft:end_stone_bricks
setblock 176 214 466 minecraft:light[level=14]
setblock 176 214 474 minecraft:light[level=14]
setblock 176 214 482 minecraft:light[level=14]
setblock 176 214 490 minecraft:light[level=14]
setblock 176 214 498 minecraft:light[level=14]
fill 179 214 505 179 215 505 minecraft:end_stone_bricks
fill 180 214 463 180 215 463 minecraft:end_stone_bricks
setblock 183 214 467 minecraft:end_stone_bricks
setblock 183 214 473 minecraft:end_stone_bricks
setblock 183 214 476 minecraft:end_stone_bricks
setblock 183 214 481 minecraft:end_stone_bricks
setblock 183 214 502 minecraft:end_stone_bricks
fill 141 215 463 144 216 463 minecraft:purpur_block
setblock 141 215 466 minecraft:pearlescent_froglight
fill 141 215 467 141 215 471 minecraft:purpur_block
fill 141 215 473 141 215 482 minecraft:purpur_block
setblock 141 215 483 minecraft:pearlescent_froglight
fill 141 215 484 141 216 485 minecraft:purpur_block
setblock 141 215 486 minecraft:end_stone_bricks
fill 141 215 487 141 215 504 minecraft:purpur_block
setblock 141 215 505 minecraft:end_stone_bricks
fill 142 215 505 144 215 505 minecraft:purpur_block
setblock 145 215 463 minecraft:end_stone_bricks
fill 146 215 463 158 216 463 minecraft:purpur_block
fill 146 215 505 159 215 505 minecraft:purpur_block
fill 151 215 498 151 215 499 minecraft:purpur_block
setblock 152 215 497 minecraft:purpur_block
fill 153 215 501 154 215 501 minecraft:purpur_block
fill 155 215 496 155 219 496 minecraft:purpur_block
fill 156 215 501 157 219 501 minecraft:purpur_block
fill 158 215 496 158 219 496 minecraft:purpur_block
setblock 159 215 463 minecraft:end_stone_bricks
fill 159 215 497 159 219 499 minecraft:purpur_block
fill 160 215 463 160 245 463 minecraft:purpur_block
fill 161 215 505 173 215 505 minecraft:purpur_block
fill 162 215 463 164 248 463 minecraft:purpur_block
fill 164 215 492 164 216 493 minecraft:end_stone
fill 166 215 463 172 216 463 minecraft:purpur_block
setblock 173 215 463 minecraft:white_concrete
fill 174 215 463 179 215 463 minecraft:purpur_block
fill 175 215 505 178 216 505 minecraft:purpur_block
fill 180 215 505 183 216 505 minecraft:purpur_block
fill 181 215 463 182 249 463 minecraft:purpur_block
fill 183 215 464 183 215 470 minecraft:purpur_block
setblock 183 215 471 minecraft:white_concrete
setblock 183 215 473 minecraft:purpur_block
fill 183 215 475 183 216 477 minecraft:purpur_block
fill 183 215 479 183 229 479 minecraft:purpur_block
setblock 183 215 480 minecraft:magenta_stained_glass
fill 183 215 481 183 215 492 minecraft:purpur_block
fill 183 215 494 183 216 494 minecraft:purpur_block
fill 183 215 496 183 284 496 minecraft:purpur_block
fill 183 215 498 183 215 503 minecraft:purpur_block
fill 141 216 464 141 266 467 minecraft:purpur_block
setblock 141 216 468 minecraft:end_stone_bricks
fill 141 216 469 141 242 469 minecraft:purpur_block
setblock 141 216 470 minecraft:end_stone_bricks
fill 141 216 471 141 218 471 minecraft:magenta_concrete
fill 141 216 472 141 216 478 minecraft:purpur_block
setblock 141 216 479 minecraft:end_stone_bricks
fill 141 216 480 141 218 483 minecraft:purpur_block
fill 141 216 486 141 222 486 minecraft:purpur_block
fill 141 216 487 141 218 487 minecraft:magenta_concrete
setblock 141 216 488 minecraft:magenta_stained_glass
setblock 141 216 489 minecraft:end_stone_bricks
fill 141 216 490 141 280 491 minecraft:purpur_block
setblock 141 216 492 minecraft:end_stone_bricks
fill 141 216 493 141 216 502 minecraft:purpur_block
fill 141 216 503 141 218 503 minecraft:magenta_concrete
fill 141 216 504 141 274 505 minecraft:purpur_block
setblock 142 216 505 minecraft:end_stone_bricks
fill 143 216 505 150 225 505 minecraft:purpur_block
fill 145 216 463 145 218 463 minecraft:magenta_concrete
setblock 151 216 505 minecraft:end_stone_bricks
fill 152 216 505 154 217 505 minecraft:purpur_block
setblock 153 216 497 minecraft:end_stone_bricks
fill 153 216 500 153 217 500 minecraft:end_stone_bricks
fill 154 216 497 154 219 497 minecraft:purpur_block
fill 154 216 500 154 219 500 minecraft:purpur_block
fill 155 216 501 155 219 501 minecraft:purpur_block
fill 155 216 505 155 218 505 minecraft:magenta_concrete
fill 156 216 495 157 219 495 minecraft:purpur_block
fill 156 216 505 159 237 505 minecraft:purpur_block
fill 158 216 501 158 219 501 minecraft:purpur_block
fill 159 216 463 159 307 463 minecraft:purpur_block
fill 159 216 496 159 219 496 minecraft:purpur_block
fill 159 216 500 159 219 500 minecraft:purpur_block
fill 161 216 463 161 218 463 minecraft:magenta_concrete
fill 161 216 505 165 216 505 minecraft:purpur_block
fill 165 216 463 165 232 463 minecraft:purpur_block
setblock 166 216 505 minecraft:magenta_stained_glass
fill 167 216 505 170 224 505 minecraft:purpur_block
fill 171 216 505 171 218 505 minecraft:magenta_concrete
setblock 172 216 505 minecraft:end_stone_bricks
fill 173 216 463 176 216 463 minecraft:purpur_block
fill 173 216 505 174 238 505 minecraft:purpur_block
fill 177 216 463 177 218 463 minecraft:magenta_concrete
setblock 178 216 463 minecraft:purpur_block
setblock 179 216 463 minecraft:magenta_stained_glass
fill 179 216 505 179 307 505 minecraft:purpur_block
fill 180 216 463 180 227 463 minecraft:purpur_block
fill 183 216 463 183 221 466 minecraft:purpur_block
setblock 183 216 467 minecraft:end_stone_bricks
fill 183 216 468 183 261 470 minecraft:purpur_block
setblock 183 216 471 minecraft:end_stone_bricks
fill 183 216 473 183 218 473 minecraft:magenta_concrete
fill 183 216 474 183 242 474 minecraft:purpur_block
fill 183 216 478 183 299 478 minecraft:purpur_block
fill 183 216 480 183 222 488 minecraft:purpur_block
fill 183 216 489 183 218 489 minecraft:magenta_concrete
fill 183 216 490 183 224 490 minecraft:purpur_block
setblock 183 216 491 minecraft:end_stone_bricks
fill 183 216 492 183 216 493 minecraft:purpur_block
fill 183 216 495 183 235 495 minecraft:purpur_block
fill 183 216 497 183 216 498 minecraft:purpur_block
setblock 183 216 499 minecraft:end_stone_bricks
fill 183 216 500 183 277 500 minecraft:purpur_block
setblock 183 216 501 minecraft:end_stone_bricks
fill 183 216 502 183 250 504 minecraft:purpur_block
fill 141 217 463 141 307 463 minecraft:purpur_block
fill 141 217 468 141 240 468 minecraft:purpur_block
fill 141 217 470 141 307 470 minecraft:purpur_block
fill 141 217 472 141 254 472 minecraft:purpur_block
fill 141 217 473 141 217 474 minecraft:end_stone_bricks
fill 141 217 475 141 224 479 minecraft:purpur_block
fill 141 217 484 141 217 485 minecraft:end_stone_bricks
fill 141 217 488 141 221 489 minecraft:purpur_block
fill 141 217 492 141 228 493 minecraft:purpur_block
setblock 141 217 494 minecraft:end_stone_bricks
fill 141 217 495 141 218 499 minecraft:purpur_block
setblock 141 217 500 minecraft:end_stone_bricks
fill 141 217 501 141 222 502 minecraft:purpur_block
setblock 142 217 463 minecraft:pearlescent_froglight
fill 142 217 505 142 228 505 minecraft:purpur_block
fill 143 217 463 144 222 463 minecraft:purpur_block
fill 146 217 463 146 218 463 minecraft:pearlescent_froglight
fill 147 217 463 148 227 463 minecraft:purpur_block
setblock 149 217 463 minecraft:end_stone_bricks
fill 150 217 463 158 221 463 minecraft:purpur_block
fill 151 217 505 151 272 505 minecraft:purpur_block
fill 153 217 497 153 219 499 minecraft:purpur_block
fill 154 217 496 154 219 496 minecraft:purpur_block
fill 154 217 501 154 219 501 minecraft:purpur_block
fill 155 217 495 155 219 495 minecraft:purpur_block
fill 156 217 502 157 219 502 minecraft:purpur_block
fill 158 217 495 158 219 495 minecraft:purpur_block
fill 159 217 501 159 219 501 minecraft:purpur_block
fill 160 217 497 160 219 500 minecraft:purpur_block
fill 160 217 505 162 235 505 minecraft:purpur_block
setblock 163 217 505 minecraft:end_stone_bricks
fill 164 217 505 166 222 505 minecraft:purpur_block
fill 166 217 463 166 233 463 minecraft:purpur_block
setblock 167 217 463 minecraft:magenta_stained_glass
fill 168 217 463 172 222 463 minecraft:purpur_block
fill 172 217 505 172 253 505 minecraft:purpur_block
setblock 173 217 463 minecraft:end_stone_bricks
fill 174 217 463 174 226 463 minecraft:purpur_block
setblock 175 217 463 minecraft:white_concrete
fill 175 217 505 177 230 505 minecraft:purpur_block
fill 176 217 463 176 303 463 minecraft:purpur_block
setblock 178 217 463 minecraft:end_stone_bricks
fill 178 217 505 178 218 505 minecraft:pearlescent_froglight
fill 179 217 463 179 296 463 minecraft:purpur_block
fill 180 217 505 181 263 505 minecraft:purpur_block
setblock 182 217 505 minecraft:end_stone_bricks
fill 183 217 467 183 235 467 minecraft:purpur_block
fill 183 217 471 183 270 472 minecraft:purpur_block
fill 183 217 475 183 307 475 minecraft:purpur_block
fill 183 217 476 183 217 477 minecraft:end_stone_bricks
setblock 183 217 491 minecraft:purpur_block
setblock 183 217 492 minecraft:end_stone_bricks
fill 183 217 493 183 233 493 minecraft:purpur_block
setblock 183 217 494 minecraft:end_stone_bricks
fill 183 217 497 183 245 497 minecraft:purpur_block
setblock 183 217 498 minecraft:end_stone_bricks
fill 183 217 499 183 220 499 minecraft:purpur_block
fill 183 217 501 183 241 501 minecraft:purpur_block
fill 183 217 505 183 307 505 minecraft:purpur_block
fill 141 218 473 141 231 474 minecraft:purpur_block
fill 141 218 484 141 227 485 minecraft:purpur_block
fill 141 218 494 141 227 494 minecraft:purpur_block
fill 141 218 500 141 307 500 minecraft:purpur_block
fill 142 218 463 142 243 463 minecraft:purpur_block
fill 149 218 463 149 284 463 minecraft:purpur_block
fill 152 218 505 153 223 505 minecraft:purpur_block
fill 153 218 496 153 219 496 minecraft:purpur_block
fill 153 218 500 153 219 500 minecraft:purpur_block
fill 154 218 495 154 219 495 minecraft:purpur_block
setblock 154 218 505 minecraft:magenta_stained_glass
fill 155 218 502 155 219 502 minecraft:purpur_block
fill 156 218 494 157 219 494 minecraft:purpur_block
fill 158 218 502 158 219 502 minecraft:purpur_block
fill 159 218 495 159 219 495 minecraft:purpur_block
fill 160 218 496 160 219 496 minecraft:purpur_block
fill 160 218 501 160 219 501 minecraft:purpur_block
fill 163 218 505 163 236 505 minecraft:purpur_block
fill 167 218 463 167 255 463 minecraft:purpur_block
fill 173 218 463 173 238 463 minecraft:purpur_block
fill 175 218 463 175 307 463 minecraft:purpur_block
setblock 178 218 463 minecraft:purpur_block
fill 182 218 505 182 272 505 minecraft:purpur_block
fill 183 218 476 183 220 477 minecraft:purpur_block
setblock 183 218 491 minecraft:white_concrete
fill 183 218 492 183 226 492 minecraft:purpur_block
fill 183 218 494 183 255 494 minecraft:purpur_block
fill 183 218 498 183 225 498 minecraft:purpur_block
fill 141 219 471 141 224 471 minecraft:purpur_block
fill 141 219 480 141 245 481 minecraft:purpur_block
setblock 141 219 482 minecraft:pearlescent_froglight
fill 141 219 483 141 277 483 minecraft:purpur_block
fill 141 219 487 141 224 487 minecraft:purpur_block
fill 141 219 495 141 229 495 minecraft:purpur_block
setblock 141 219 496 minecraft:pearlescent_froglight
fill 141 219 497 141 274 499 minecraft:purpur_block
fill 141 219 503 141 224 503 minecraft:purpur_block
fill 145 219 463 146 224 463 minecraft:purpur_block
fill 152 219 497 152 219 500 minecraft:purpur_block
setblock 153 219 495 minecraft:purpur_block
setblock 153 219 501 minecraft:purpur_block
setblock 154 219 502 minecraft:purpur_block
fill 154 219 505 155 219 505 minecraft:purpur_block
setblock 155 219 494 minecraft:purpur_block
fill 156 219 503 157 219 503 minecraft:purpur_block
setblock 158 219 494 minecraft:purpur_block
setblock 159 219 502 minecraft:purpur_block
setblock 160 219 495 minecraft:purpur_block
fill 161 219 463 161 224 463 minecraft:purpur_block
fill 161 219 497 161 219 500 minecraft:purpur_block
fill 171 219 505 171 224 505 minecraft:purpur_block
fill 177 219 463 177 220 463 minecraft:purpur_block
setblock 178 219 463 minecraft:white_concrete
fill 178 219 505 178 307 505 minecraft:purpur_block
fill 183 219 473 183 224 473 minecraft:purpur_block
fill 183 219 489 183 224 489 minecraft:purpur_block
fill 183 219 491 183 220 491 minecraft:purpur_block
fill 141 220 482 141 258 482 minecraft:purpur_block
fill 141 220 496 141 269 496 minecraft:purpur_block
fill 154 220 505 154 307 505 minecraft:purpur_block
setblock 155 220 505 minecraft:pearlescent_froglight
fill 156 220 497 156 223 497 minecraft:end_stone_bricks
fill 156 220 500 156 222 500 minecraft:end_stone_bricks
fill 158 220 498 158 224 498 minecraft:end_stone_bricks
fill 178 220 463 178 258 463 minecraft:purpur_block
fill 155 221 505 155 224 505 minecraft:purpur_block
setblock 177 221 463 minecraft:pearlescent_froglight
fill 183 221 476 183 305 476 minecraft:purpur_block
setblock 183 221 477 minecraft:white_concrete
setblock 183 221 491 minecraft:white_concrete
setblock 183 221 499 minecraft:white_concrete
setblock 141 222 488 minecraft:magenta_stained_glass
fill 141 222 489 141 240 489 minecraft:purpur_block
setblock 144 222 466 minecraft:light[level=14]
setblock 144 222 474 minecraft:light[level=14]
setblock 144 222 482 minecraft:light[level=14]
setblock 144 222 490 minecraft:light[level=14]
setblock 144 222 498 minecraft:light[level=14]
fill 150 222 463 152 226 463 minecraft:purpur_block
setblock 152 222 466 minecraft:light[level=14]
setblock 152 222 474 minecraft:light[level=14]
setblock 152 222 482 minecraft:light[level=14]
setblock 152 222 490 minecraft:light[level=14]
setblock 152 222 498 minecraft:light[level=14]
setblock 153 222 463 minecraft:white_concrete
fill 154 222 463 158 225 463 minecraft:purpur_block
setblock 160 222 466 minecraft:light[level=14]
setblock 160 222 474 minecraft:light[level=14]
setblock 160 222 482 minecraft:light[level=14]
setblock 160 222 490 minecraft:light[level=14]
setblock 160 222 498 minecraft:light[level=14]
setblock 168 222 466 minecraft:light[level=14]
setblock 168 222 474 minecraft:light[level=14]
setblock 168 222 482 minecraft:light[level=14]
setblock 168 222 490 minecraft:light[level=14]
setblock 168 222 498 minecraft:light[level=14]
setblock 176 222 466 minecraft:light[level=14]
setblock 176 222 474 minecraft:light[level=14]
setblock 176 222 482 minecraft:light[level=14]
setblock 176 222 490 minecraft:light[level=14]
setblock 176 222 498 minecraft:light[level=14]
fill 177 222 463 177 224 463 minecraft:purpur_block
fill 183 222 463 183 223 464 minecraft:purpur_block
setblock 183 222 465 minecraft:pearlescent_froglight
fill 183 222 466 183 252 466 minecraft:purpur_block
fill 183 222 477 183 226 477 minecraft:purpur_block
fill 183 222 491 183 307 491 minecraft:purpur_block
fill 183 222 499 183 307 499 minecraft:purpur_block
setblock 141 223 486 minecraft:white_concrete
fill 141 223 488 141 251 488 minecraft:purpur_block
setblock 141 223 501 minecraft:pearlescent_froglight
fill 141 223 502 141 271 502 minecraft:purpur_block
fill 143 223 463 143 260 463 minecraft:purpur_block
setblock 144 223 463 minecraft:pearlescent_froglight
fill 153 223 463 153 228 463 minecraft:purpur_block
fill 164 223 505 165 231 505 minecraft:purpur_block
setblock 166 223 505 minecraft:magenta_stained_glass
fill 168 223 463 170 245 463 minecraft:purpur_block
setblock 171 223 463 minecraft:white_concrete
fill 172 223 463 172 260 463 minecraft:purpur_block
fill 183 223 465 183 224 465 minecraft:purpur_block
fill 183 223 480 183 224 484 minecraft:purpur_block
setblock 183 223 485 minecraft:white_concrete
fill 183 223 486 183 224 488 minecraft:purpur_block
fill 141 224 486 141 247 486 minecraft:purpur_block
fill 141 224 501 141 250 501 minecraft:purpur_block
fill 144 224 463 144 252 463 minecraft:purpur_block
setblock 152 224 505 minecraft:white_concrete
fill 153 224 505 153 307 505 minecraft:purpur_block
fill 157 224 476 157 225 477 minecraft:obsidian
fill 166 224 505 166 294 505 minecraft:purpur_block
fill 171 224 463 171 260 463 minecraft:purpur_block
fill 183 224 463 183 307 463 minecraft:purpur_block
setblock 183 224 464 minecraft:white_concrete
fill 183 224 485 183 251 485 minecraft:purpur_block
fill 141 225 471 141 227 471 minecraft:magenta_concrete
setblock 141 225 475 minecraft:magenta_stained_glass
fill 141 225 476 141 229 478 minecraft:purpur_block
setblock 141 225 479 minecraft:pearlescent_froglight
fill 141 225 487 141 227 487 minecraft:magenta_concrete
fill 141 225 503 141 227 503 minecraft:magenta_concrete
fill 145 225 463 145 227 463 minecraft:magenta_concrete
fill 146 225 463 146 307 463 minecraft:purpur_block
fill 152 225 505 152 305 505 minecraft:purpur_block
fill 155 225 505 155 227 505 minecraft:magenta_concrete
fill 161 225 463 161 227 463 minecraft:magenta_concrete
fill 167 225 505 169 234 505 minecraft:purpur_block
setblock 170 225 505 minecraft:white_concrete
fill 171 225 505 171 227 505 minecraft:magenta_concrete
fill 177 225 463 177 227 463 minecraft:magenta_concrete
fill 183 225 464 183 307 464 minecraft:purpur_block
setblock 183 225 465 minecraft:white_concrete
fill 183 225 473 183 227 473 minecraft:magenta_concrete
setblock 183 225 480 minecraft:pearlescent_froglight
fill 183 225 481 183 255 484 minecraft:purpur_block
setblock 183 225 486 minecraft:pearlescent_froglight
fill 183 225 487 183 280 488 minecraft:purpur_block
fill 183 225 489 183 227 489 minecraft:magenta_concrete
setblock 183 225 490 minecraft:magenta_stained_glass
fill 141 226 475 141 239 475 minecraft:purpur_block
fill 141 226 479 141 248 479 minecraft:purpur_block
fill 143 226 505 146 227 505 minecraft:purpur_block
setblock 147 226 505 minecraft:white_concrete
fill 148 226 505 150 228 505 minecraft:purpur_block
fill 154 226 463 155 226 463 minecraft:white_concrete
fill 156 226 463 158 237 463 minecraft:purpur_block
fill 168 226 473 169 227 474 minecraft:obsidian
fill 170 226 505 170 262 505 minecraft:purpur_block
fill 183 226 465 183 266 465 minecraft:purpur_block
fill 183 226 480 183 307 480 minecraft:purpur_block
fill 183 226 486 183 252 486 minecraft:purpur_block
fill 183 226 490 183 307 490 minecraft:purpur_block
setblock 183 226 498 minecraft:white_concrete
fill 147 227 505 147 282 505 minecraft:purpur_block
fill 150 227 463 150 243 463 minecraft:purpur_block
setblock 151 227 463 minecraft:pearlescent_froglight
setblock 152 227 463 minecraft:magenta_stained_glass
fill 154 227 463 155 234 463 minecraft:purpur_block
setblock 174 227 463 minecraft:white_concrete
setblock 183 227 477 minecraft:magenta_stained_glass
setblock 183 227 492 minecraft:magenta_stained_glass
fill 183 227 498 183 294 498 minecraft:purpur_block
fill 141 228 471 141 242 471 minecraft:purpur_block
fill 141 228 484 141 263 484 minecraft:purpur_block
setblock 141 228 485 minecraft:white_concrete
fill 141 228 487 141 231 487 minecraft:purpur_block
setblock 141 228 494 minecraft:magenta_stained_glass
setblock 141 228 503 minecraft:purpur_block
fill 143 228 505 144 234 505 minecraft:purpur_block
fill 145 228 463 145 242 463 minecraft:purpur_block
setblock 145 228 505 minecraft:magenta_stained_glass
fill 146 228 505 146 307 505 minecraft:purpur_block
setblock 147 228 463 minecraft:pearlescent_froglight
fill 148 228 463 148 301 463 minecraft:purpur_block
fill 151 228 463 152 234 463 minecraft:purpur_block
fill 155 228 505 155 242 505 minecraft:purpur_block
fill 161 228 463 161 229 463 minecraft:purpur_block
fill 171 228 505 171 242 505 minecraft:purpur_block
fill 174 228 463 174 307 463 minecraft:purpur_block
fill 177 228 463 177 242 463 minecraft:purpur_block
setblock 180 228 463 minecraft:pearlescent_froglight
fill 183 228 473 183 242 473 minecraft:purpur_block
fill 183 228 477 183 299 477 minecraft:purpur_block
fill 183 228 489 183 242 489 minecraft:purpur_block
fill 183 228 492 183 264 492 minecraft:purpur_block
setblock 141 229 485 minecraft:pearlescent_froglight
fill 141 229 492 141 254 492 minecraft:purpur_block
setblock 141 229 493 minecraft:magenta_stained_glass
fill 141 229 494 141 269 494 minecraft:purpur_block
setblock 141 229 503 minecraft:pearlescent_froglight
setblock 142 229 505 minecraft:white_concrete
fill 145 229 505 145 245 505 minecraft:purpur_block
fill 147 229 463 147 307 463 minecraft:purpur_block
fill 148 229 505 148 239 505 minecraft:purpur_block
setblock 149 229 505 minecraft:pearlescent_froglight
fill 150 229 505 150 307 505 minecraft:purpur_block
setblock 153 229 463 minecraft:magenta_stained_glass
fill 180 229 463 180 307 463 minecraft:purpur_block
fill 141 230 476 141 236 476 minecraft:purpur_block
setblock 141 230 477 minecraft:white_concrete
fill 141 230 478 141 276 478 minecraft:purpur_block
fill 141 230 485 141 290 485 minecraft:purpur_block
fill 141 230 493 141 286 493 minecraft:purpur_block
setblock 141 230 495 minecraft:pearlescent_froglight
fill 141 230 503 141 242 503 minecraft:purpur_block
fill 142 230 505 142 266 505 minecraft:purpur_block
setblock 144 230 466 minecraft:light[level=14]
setblock 144 230 474 minecraft:light[level=14]
setblock 144 230 482 minecraft:light[level=14]
setblock 144 230 490 minecraft:light[level=14]
setblock 144 230 498 minecraft:light[level=14]
fill 149 230 505 149 307 505 minecraft:purpur_block
setblock 152 230 466 minecraft:light[level=14]
setblock 152 230 474 minecraft:light[level=14]
setblock 152 230 482 minecraft:light[level=14]
setblock 152 230 490 minecraft:light[level=14]
setblock 152 230 498 minecraft:light[level=14]
fill 153 230 463 153 243 463 minecraft:purpur_block
setblock 160 230 466 minecraft:light[level=14]
setblock 160 230 474 minecraft:light[level=14]
setblock 160 230 482 minecraft:light[level=14]
setblock 160 230 490 minecraft:light[level=14]
setblock 160 230 498 minecraft:light[level=14]
setblock 161 230 463 minecraft:pearlescent_froglight
setblock 168 230 466 minecraft:light[level=14]
setblock 168 230 474 minecraft:light[level=14]
setblock 168 230 482 minecraft:light[level=14]
setblock 168 230 490 minecraft:light[level=14]
setblock 168 230 498 minecraft:light[level=14]
setblock 176 230 466 minecraft:light[level=14]
setblock 176 230 474 minecraft:light[level=14]
setblock 176 230 482 minecraft:light[level=14]
setblock 176 230 490 minecraft:light[level=14]
setblock 176 230 498 minecraft:light[level=14]
setblock 183 230 479 minecraft:pearlescent_froglight
fill 141 231 477 141 243 477 minecraft:purpur_block
fill 141 231 495 141 307 495 minecraft:purpur_block
fill 161 231 463 161 242 463 minecraft:purpur_block
setblock 175 231 505 minecraft:pearlescent_froglight
fill 176 231 505 177 307 505 minecraft:purpur_block
fill 183 231 479 183 238 479 minecraft:purpur_block
setblock 141 232 473 minecraft:pearlescent_froglight
fill 141 232 474 141 270 474 minecraft:purpur_block
setblock 141 232 487 minecraft:white_concrete
setblock 164 232 505 minecraft:white_concrete
fill 165 232 505 165 259 505 minecraft:purpur_block
fill 175 232 505 175 266 505 minecraft:purpur_block
fill 141 233 473 141 307 473 minecraft:purpur_block
fill 141 233 487 141 242 487 minecraft:purpur_block
fill 164 233 505 164 307 505 minecraft:purpur_block
setblock 165 233 463 minecraft:white_concrete
fill 165 234 463 165 245 463 minecraft:purpur_block
setblock 166 234 463 minecraft:white_concrete
setblock 183 234 493 minecraft:white_concrete
fill 143 235 505 143 280 505 minecraft:purpur_block
setblock 144 235 505 minecraft:magenta_stained_glass
setblock 151 235 463 minecraft:purpur_block
setblock 152 235 463 minecraft:pearlescent_froglight
fill 154 235 463 154 269 463 minecraft:purpur_block
setblock 155 235 463 minecraft:magenta_stained_glass
fill 166 235 463 166 254 463 minecraft:purpur_block
fill 167 235 505 167 248 505 minecraft:purpur_block
setblock 168 235 505 minecraft:white_concrete
fill 169 235 505 169 260 505 minecraft:purpur_block
setblock 183 235 493 minecraft:purpur_block
fill 144 236 505 144 275 505 minecraft:purpur_block
setblock 151 236 463 minecraft:magenta_stained_glass
fill 151 236 483 158 236 483 minecraft:end_stone
fill 152 236 463 152 307 463 minecraft:purpur_block
fill 152 236 479 159 236 482 minecraft:end_stone
fill 152 236 484 159 236 487 minecraft:end_stone
fill 153 236 477 169 236 478 minecraft:end_stone
fill 153 236 488 169 236 489 minecraft:end_stone
fill 154 236 476 168 236 476 minecraft:end_stone
fill 154 236 490 168 236 490 minecraft:end_stone
fill 155 236 463 155 307 463 minecraft:purpur_block
fill 155 236 475 167 236 475 minecraft:end_stone
fill 155 236 491 167 236 491 minecraft:end_stone
fill 157 236 474 165 236 474 minecraft:end_stone
fill 157 236 492 165 236 492 minecraft:end_stone
fill 160 236 479 160 236 481 minecraft:end_stone
fill 160 236 485 160 236 487 minecraft:end_stone
fill 160 236 505 160 255 505 minecraft:purpur_block
setblock 161 236 473 minecraft:end_stone
fill 161 236 479 170 236 480 minecraft:end_stone
fill 161 236 486 170 236 487 minecraft:end_stone
setblock 161 236 493 minecraft:end_stone
setblock 161 236 505 minecraft:pearlescent_froglight
fill 162 236 481 170 236 481 minecraft:end_stone
fill 162 236 485 170 236 485 minecraft:end_stone
fill 162 236 505 162 258 505 minecraft:purpur_block
fill 163 236 482 170 236 482 minecraft:end_stone
fill 163 236 484 170 236 484 minecraft:end_stone
fill 164 236 483 171 236 483 minecraft:end_stone
fill 168 236 505 168 255 505 minecraft:purpur_block
setblock 183 236 467 minecraft:magenta_stained_glass
setblock 183 236 493 minecraft:pearlescent_froglight
setblock 183 236 495 minecraft:white_concrete
setblock 141 237 476 minecraft:white_concrete
fill 142 237 464 182 237 465 minecraft:black_concrete
setblock 142 237 466 minecraft:magenta_stained_glass
fill 142 237 467 142 237 471 minecraft:black_concrete
setblock 142 237 472 minecraft:magenta_stained_glass
fill 142 237 473 142 237 477 minecraft:black_concrete
setblock 142 237 478 minecraft:magenta_stained_glass
fill 142 237 479 142 237 483 minecraft:black_concrete
setblock 142 237 484 minecraft:magenta_stained_glass
fill 142 237 485 142 237 489 minecraft:black_concrete
setblock 142 237 490 minecraft:magenta_stained_glass
fill 142 237 491 142 237 495 minecraft:black_concrete
setblock 142 237 496 minecraft:magenta_stained_glass
fill 142 237 497 142 237 501 minecraft:black_concrete
setblock 142 237 502 minecraft:magenta_stained_glass
fill 142 237 503 182 237 504 minecraft:black_concrete
fill 143 237 466 143 237 468 minecraft:black_concrete
setblock 143 237 469 minecraft:magenta_stained_glass
fill 143 237 470 143 237 474 minecraft:black_concrete
setblock 143 237 475 minecraft:magenta_stained_glass
fill 143 237 476 143 237 480 minecraft:black_concrete
setblock 143 237 481 minecraft:magenta_stained_glass
fill 143 237 482 143 237 486 minecraft:black_concrete
setblock 143 237 487 minecraft:magenta_stained_glass
fill 143 237 488 143 237 492 minecraft:black_concrete
setblock 143 237 493 minecraft:magenta_stained_glass
fill 143 237 494 143 237 498 minecraft:black_concrete
setblock 143 237 499 minecraft:magenta_stained_glass
fill 143 237 500 143 237 502 minecraft:black_concrete
setblock 144 237 466 minecraft:magenta_stained_glass
fill 144 237 467 144 237 471 minecraft:black_concrete
setblock 144 237 472 minecraft:magenta_stained_glass
fill 144 237 473 144 237 477 minecraft:black_concrete
setblock 144 237 478 minecraft:magenta_stained_glass
fill 144 237 479 144 237 483 minecraft:black_concrete
setblock 144 237 484 minecraft:magenta_stained_glass
fill 144 237 485 144 237 489 minecraft:black_concrete
setblock 144 237 490 minecraft:magenta_stained_glass
fill 144 237 491 144 237 495 minecraft:black_concrete
setblock 144 237 496 minecraft:magenta_stained_glass
fill 144 237 497 144 237 501 minecraft:black_concrete
setblock 144 237 502 minecraft:magenta_stained_glass
fill 145 237 466 145 237 468 minecraft:black_concrete
setblock 145 237 469 minecraft:magenta_stained_glass
fill 145 237 470 145 237 474 minecraft:black_concrete
setblock 145 237 475 minecraft:magenta_stained_glass
fill 145 237 476 145 237 480 minecraft:black_concrete
setblock 145 237 481 minecraft:magenta_stained_glass
fill 145 237 482 145 237 486 minecraft:black_concrete
setblock 145 237 487 minecraft:magenta_stained_glass
fill 145 237 488 145 237 492 minecraft:black_concrete
setblock 145 237 493 minecraft:magenta_stained_glass
fill 145 237 494 145 237 498 minecraft:black_concrete
setblock 145 237 499 minecraft:magenta_stained_glass
fill 145 237 500 145 237 502 minecraft:black_concrete
setblock 146 237 466 minecraft:magenta_stained_glass
fill 146 237 467 146 237 471 minecraft:black_concrete
setblock 146 237 472 minecraft:magenta_stained_glass
fill 146 237 473 146 237 477 minecraft:black_concrete
setblock 146 237 478 minecraft:magenta_stained_glass
fill 146 237 479 146 237 483 minecraft:black_concrete
setblock 146 237 484 minecraft:magenta_stained_glass
fill 146 237 485 146 237 489 minecraft:black_concrete
setblock 146 237 490 minecraft:magenta_stained_glass
fill 146 237 491 146 237 495 minecraft:black_concrete
setblock 146 237 496 minecraft:magenta_stained_glass
fill 146 237 497 146 237 501 minecraft:black_concrete
setblock 146 237 502 minecraft:magenta_stained_glass
fill 147 237 466 147 237 468 minecraft:black_concrete
setblock 147 237 469 minecraft:magenta_stained_glass
fill 147 237 470 147 237 474 minecraft:black_concrete
setblock 147 237 475 minecraft:magenta_stained_glass
fill 147 237 476 147 237 480 minecraft:black_concrete
setblock 147 237 481 minecraft:magenta_stained_glass
fill 147 237 482 147 237 486 minecraft:black_concrete
setblock 147 237 487 minecraft:magenta_stained_glass
fill 147 237 488 147 237 492 minecraft:black_concrete
setblock 147 237 493 minecraft:magenta_stained_glass
fill 147 237 494 147 237 498 minecraft:black_concrete
setblock 147 237 499 minecraft:magenta_stained_glass
fill 147 237 500 147 237 502 minecraft:black_concrete
setblock 148 237 466 minecraft:magenta_stained_glass
fill 148 237 467 148 237 471 minecraft:black_concrete
setblock 148 237 472 minecraft:magenta_stained_glass
fill 148 237 473 148 237 477 minecraft:black_concrete
setblock 148 237 478 minecraft:magenta_stained_glass
fill 148 237 479 148 237 483 minecraft:black_concrete
setblock 148 237 484 minecraft:magenta_stained_glass
fill 148 237 485 148 237 489 minecraft:black_concrete
setblock 148 237 490 minecraft:magenta_stained_glass
fill 148 237 491 148 237 495 minecraft:black_concrete
setblock 148 237 496 minecraft:magenta_stained_glass
fill 148 237 497 148 237 501 minecraft:black_concrete
setblock 148 237 502 minecraft:magenta_stained_glass
fill 149 237 466 149 237 468 minecraft:black_concrete
setblock 149 237 469 minecraft:magenta_stained_glass
fill 149 237 470 149 237 474 minecraft:black_concrete
setblock 149 237 475 minecraft:magenta_stained_glass
fill 149 237 476 149 237 480 minecraft:black_concrete
setblock 149 237 481 minecraft:magenta_stained_glass
fill 149 237 482 149 237 486 minecraft:black_concrete
setblock 149 237 487 minecraft:magenta_stained_glass
fill 149 237 488 149 237 492 minecraft:black_concrete
setblock 149 237 493 minecraft:magenta_stained_glass
fill 149 237 494 149 237 498 minecraft:black_concrete
setblock 149 237 499 minecraft:magenta_stained_glass
fill 149 237 500 149 237 502 minecraft:black_concrete
setblock 150 237 466 minecraft:magenta_stained_glass
fill 150 237 467 150 237 471 minecraft:black_concrete
setblock 150 237 472 minecraft:magenta_stained_glass
fill 150 237 473 150 237 477 minecraft:black_concrete
setblock 150 237 478 minecraft:magenta_stained_glass
fill 150 237 479 150 237 483 minecraft:black_concrete
setblock 150 237 484 minecraft:magenta_stained_glass
fill 150 237 485 150 237 489 minecraft:black_concrete
setblock 150 237 490 minecraft:magenta_stained_glass
fill 150 237 491 150 237 495 minecraft:black_concrete
setblock 150 237 496 minecraft:magenta_stained_glass
fill 150 237 497 150 237 501 minecraft:black_concrete
setblock 150 237 502 minecraft:magenta_stained_glass
fill 151 237 463 151 307 463 minecraft:purpur_block
fill 151 237 466 151 237 468 minecraft:black_concrete
setblock 151 237 469 minecraft:magenta_stained_glass
fill 151 237 470 151 237 474 minecraft:black_concrete
setblock 151 237 475 minecraft:magenta_stained_glass
fill 151 237 476 151 237 480 minecraft:black_concrete
setblock 151 237 481 minecraft:magenta_stained_glass
setblock 151 237 482 minecraft:black_concrete
fill 151 237 483 157 237 483 minecraft:purpur_block
fill 151 237 484 151 237 486 minecraft:black_concrete
setblock 151 237 487 minecraft:magenta_stained_glass
fill 151 237 488 151 237 492 minecraft:black_concrete
setblock 151 237 493 minecraft:magenta_stained_glass
fill 151 237 494 151 237 498 minecraft:black_concrete
setblock 151 237 499 minecraft:magenta_stained_glass
fill 151 237 500 151 237 502 minecraft:black_concrete
setblock 152 237 466 minecraft:magenta_stained_glass
fill 152 237 467 152 237 471 minecraft:black_concrete
setblock 152 237 472 minecraft:magenta_stained_glass
fill 152 237 473 152 237 477 minecraft:black_concrete
setblock 152 237 478 minecraft:magenta_stained_glass
fill 152 237 479 152 237 482 minecraft:purpur_pillar
fill 152 237 484 152 237 487 minecraft:purpur_pillar
fill 152 237 488 152 237 489 minecraft:black_concrete
setblock 152 237 490 minecraft:magenta_stained_glass
fill 152 237 491 152 237 495 minecraft:black_concrete
setblock 152 237 496 minecraft:magenta_stained_glass
fill 152 237 497 152 237 501 minecraft:black_concrete
setblock 152 237 502 minecraft:magenta_stained_glass
fill 153 237 466 153 237 468 minecraft:black_concrete
setblock 153 237 469 minecraft:magenta_stained_glass
fill 153 237 470 153 237 474 minecraft:black_concrete
setblock 153 237 475 minecraft:magenta_stained_glass
setblock 153 237 476 minecraft:black_concrete
setblock 153 237 477 minecraft:purpur_block
setblock 153 237 478 minecraft:purpur_pillar
fill 153 237 479 157 237 482 minecraft:purpur_block
fill 153 237 484 157 237 487 minecraft:purpur_block
setblock 153 237 488 minecraft:purpur_pillar
setblock 153 237 489 minecraft:purpur_block
fill 153 237 490 153 237 492 minecraft:black_concrete
setblock 153 237 493 minecraft:magenta_stained_glass
fill 153 237 494 153 237 498 minecraft:black_concrete
setblock 153 237 499 minecraft:magenta_stained_glass
fill 153 237 500 153 237 502 minecraft:black_concrete
setblock 154 237 466 minecraft:magenta_stained_glass
fill 154 237 467 154 237 471 minecraft:black_concrete
setblock 154 237 472 minecraft:magenta_stained_glass
fill 154 237 473 154 237 475 minecraft:black_concrete
fill 154 237 476 154 237 477 minecraft:purpur_pillar
fill 154 237 478 168 237 478 minecraft:purpur_block
fill 154 237 488 168 237 488 minecraft:purpur_block
fill 154 237 489 154 237 490 minecraft:purpur_pillar
fill 154 237 491 154 237 495 minecraft:black_concrete
setblock 154 237 496 minecraft:magenta_stained_glass
fill 154 237 497 154 237 501 minecraft:black_concrete
setblock 154 237 502 minecraft:magenta_stained_glass
fill 155 237 466 155 237 468 minecraft:black_concrete
setblock 155 237 469 minecraft:magenta_stained_glass
fill 155 237 470 155 237 474 minecraft:black_concrete
setblock 155 237 475 minecraft:purpur_block
setblock 155 237 476 minecraft:purpur_pillar
fill 155 237 477 167 237 477 minecraft:purpur_block
fill 155 237 489 167 237 489 minecraft:purpur_block
setblock 155 237 490 minecraft:purpur_pillar
setblock 155 237 491 minecraft:purpur_block
fill 155 237 492 156 237 492 minecraft:black_concrete
setblock 155 237 493 minecraft:magenta_stained_glass
fill 155 237 494 155 237 498 minecraft:black_concrete
setblock 155 237 499 minecraft:magenta_stained_glass
fill 155 237 500 155 237 502 minecraft:black_concrete
setblock 156 237 466 minecraft:magenta_stained_glass
fill 156 237 467 156 237 471 minecraft:black_concrete
setblock 156 237 472 minecraft:magenta_stained_glass
fill 156 237 473 156 237 474 minecraft:black_concrete
setblock 156 237 475 minecraft:purpur_pillar
fill 156 237 476 166 237 476 minecraft:purpur_block
fill 156 237 490 166 237 490 minecraft:purpur_block
setblock 156 237 491 minecraft:purpur_pillar
fill 156 237 493 156 237 495 minecraft:black_concrete
setblock 156 237 496 minecraft:magenta_stained_glass
fill 156 237 497 156 237 501 minecraft:black_concrete
setblock 156 237 502 minecraft:magenta_stained_glass
fill 157 237 466 157 237 468 minecraft:black_concrete
setblock 157 237 469 minecraft:magenta_stained_glass
fill 157 237 470 157 237 473 minecraft:black_concrete
fill 157 237 474 160 237 474 minecraft:purpur_pillar
fill 157 237 475 165 237 475 minecraft:purpur_block
fill 157 237 491 165 237 491 minecraft:purpur_block
fill 157 237 492 160 237 492 minecraft:purpur_pillar
setblock 157 237 493 minecraft:magenta_stained_glass
fill 157 237 494 157 237 498 minecraft:black_concrete
setblock 157 237 499 minecraft:magenta_stained_glass
fill 157 237 500 157 237 502 minecraft:black_concrete
setblock 158 237 466 minecraft:magenta_stained_glass
fill 158 237 467 158 237 471 minecraft:black_concrete
setblock 158 237 472 minecraft:magenta_stained_glass
fill 158 237 473 160 237 473 minecraft:black_concrete
fill 158 237 479 158 237 481 minecraft:purpur_block
fill 158 237 482 158 237 484 minecraft:pearlescent_froglight
fill 158 237 485 158 237 487 minecraft:purpur_block
fill 158 237 493 158 237 495 minecraft:black_concrete
setblock 158 237 496 minecraft:magenta_stained_glass
fill 158 237 497 158 237 501 minecraft:black_concrete
setblock 158 237 502 minecraft:magenta_stained_glass
fill 159 237 466 159 237 468 minecraft:black_concrete
setblock 159 237 469 minecraft:magenta_stained_glass
fill 159 237 470 159 237 472 minecraft:black_concrete
fill 159 237 479 159 237 480 minecraft:purpur_block
fill 159 237 481 159 237 482 minecraft:pearlescent_froglight
fill 159 237 484 159 237 485 minecraft:pearlescent_froglight
fill 159 237 486 159 237 487 minecraft:purpur_block
setblock 159 237 493 minecraft:magenta_stained_glass
fill 159 237 494 159 237 498 minecraft:black_concrete
setblock 159 237 499 minecraft:magenta_stained_glass
fill 159 237 500 159 237 502 minecraft:black_concrete
setblock 160 237 466 minecraft:magenta_stained_glass
fill 160 237 467 160 237 471 minecraft:black_concrete
setblock 160 237 472 minecraft:magenta_stained_glass
fill 160 237 479 169 237 479 minecraft:purpur_block
fill 160 237 480 160 237 481 minecraft:pearlescent_froglight
fill 160 237 485 160 237 486 minecraft:pearlescent_froglight
fill 160 237 487 169 237 487 minecraft:purpur_block
fill 160 237 493 160 237 495 minecraft:black_concrete
setblock 160 237 496 minecraft:magenta_stained_glass
fill 160 237 497 160 237 501 minecraft:black_concrete
setblock 160 237 502 minecraft:magenta_stained_glass
fill 161 237 466 161 237 468 minecraft:black_concrete
setblock 161 237 469 minecraft:magenta_stained_glass
fill 161 237 470 161 237 472 minecraft:black_concrete
fill 161 237 473 161 237 474 minecraft:purpur_block
fill 161 237 480 162 237 480 minecraft:pearlescent_froglight
fill 161 237 486 162 237 486 minecraft:pearlescent_froglight
fill 161 237 492 161 237 493 minecraft:purpur_block
fill 161 237 494 161 237 498 minecraft:black_concrete
setblock 161 237 499 minecraft:magenta_stained_glass
fill 161 237 500 161 237 502 minecraft:black_concrete
fill 161 237 505 161 287 505 minecraft:purpur_block
setblock 162 237 466 minecraft:magenta_stained_glass
fill 162 237 467 162 237 471 minecraft:black_concrete
setblock 162 237 472 minecraft:magenta_stained_glass
fill 162 237 473 182 237 473 minecraft:black_concrete
fill 162 237 474 165 237 474 minecraft:purpur_pillar
fill 162 237 481 163 237 481 minecraft:pearlescent_froglight
fill 162 237 485 163 237 485 minecraft:pearlescent_froglight
fill 162 237 492 165 237 492 minecraft:purpur_pillar
fill 162 237 493 162 237 495 minecraft:black_concrete
setblock 162 237 496 minecraft:magenta_stained_glass
fill 162 237 497 162 237 501 minecraft:black_concrete
setblock 162 237 502 minecraft:magenta_stained_glass
fill 163 237 466 163 237 468 minecraft:black_concrete
setblock 163 237 469 minecraft:magenta_stained_glass
fill 163 237 470 163 237 472 minecraft:black_concrete
fill 163 237 480 169 237 480 minecraft:purpur_block
fill 163 237 482 164 237 482 minecraft:pearlescent_froglight
fill 163 237 484 164 237 484 minecraft:pearlescent_froglight
fill 163 237 486 169 237 486 minecraft:purpur_block
setblock 163 237 493 minecraft:magenta_stained_glass
fill 163 237 494 163 237 498 minecraft:black_concrete
setblock 163 237 499 minecraft:magenta_stained_glass
fill 163 237 500 163 237 502 minecraft:black_concrete
setblock 163 237 505 minecraft:pearlescent_froglight
setblock 164 237 466 minecraft:magenta_stained_glass
fill 164 237 467 164 237 471 minecraft:black_concrete
setblock 164 237 472 minecraft:magenta_stained_glass
fill 164 237 481 169 237 481 minecraft:purpur_block
setblock 164 237 483 minecraft:pearlescent_froglight
fill 164 237 485 169 237 485 minecraft:purpur_block
fill 164 237 493 164 237 495 minecraft:black_concrete
setblock 164 237 496 minecraft:magenta_stained_glass
fill 164 237 497 164 237 501 minecraft:black_concrete
setblock 164 237 502 minecraft:magenta_stained_glass
fill 165 237 466 165 237 468 minecraft:black_concrete
setblock 165 237 469 minecraft:magenta_stained_glass
fill 165 237 470 165 237 472 minecraft:black_concrete
fill 165 237 482 169 237 484 minecraft:purpur_block
setblock 165 237 493 minecraft:magenta_stained_glass
fill 165 237 494 165 237 498 minecraft:black_concrete
setblock 165 237 499 minecraft:magenta_stained_glass
fill 165 237 500 165 237 502 minecraft:black_concrete
setblock 166 237 466 minecraft:magenta_stained_glass
fill 166 237 467 166 237 471 minecraft:black_concrete
setblock 166 237 472 minecraft:magenta_stained_glass
fill 166 237 474 182 237 474 minecraft:black_concrete
setblock 166 237 475 minecraft:purpur_pillar
setblock 166 237 491 minecraft:purpur_pillar
fill 166 237 492 166 237 495 minecraft:black_concrete
setblock 166 237 496 minecraft:magenta_stained_glass
fill 166 237 497 166 237 501 minecraft:black_concrete
setblock 166 237 502 minecraft:magenta_stained_glass
fill 167 237 466 167 237 468 minecraft:black_concrete
setblock 167 237 469 minecraft:magenta_stained_glass
fill 167 237 470 167 237 472 minecraft:black_concrete
setblock 167 237 475 minecraft:purpur_block
fill 167 237 476 168 237 476 minecraft:purpur_pillar
fill 167 237 490 168 237 490 minecraft:purpur_pillar
setblock 167 237 491 minecraft:purpur_block
fill 167 237 492 182 237 492 minecraft:black_concrete
setblock 167 237 493 minecraft:magenta_stained_glass
fill 167 237 494 167 237 498 minecraft:black_concrete
setblock 167 237 499 minecraft:magenta_stained_glass
fill 167 237 500 167 237 502 minecraft:black_concrete
setblock 168 237 466 minecraft:magenta_stained_glass
fill 168 237 467 168 237 471 minecraft:black_concrete
setblock 168 237 472 minecraft:magenta_stained_glass
setblock 168 237 475 minecraft:black_concrete
setblock 168 237 477 minecraft:purpur_pillar
setblock 168 237 489 minecraft:purpur_pillar
fill 168 237 491 182 237 491 minecraft:black_concrete
fill 168 237 493 168 237 495 minecraft:black_concrete
setblock 168 237 496 minecraft:magenta_stained_glass
fill 168 237 497 168 237 501 minecraft:black_concrete
setblock 168 237 502 minecraft:magenta_stained_glass
fill 169 237 466 169 237 468 minecraft:black_concrete
setblock 169 237 469 minecraft:magenta_stained_glass
fill 169 237 470 169 237 472 minecraft:black_concrete
setblock 169 237 475 minecraft:magenta_stained_glass
fill 169 237 476 182 237 476 minecraft:black_concrete
setblock 169 237 477 minecraft:purpur_block
setblock 169 237 478 minecraft:purpur_pillar
setblock 169 237 488 minecraft:purpur_pillar
setblock 169 237 489 minecraft:purpur_block
setblock 169 237 490 minecraft:black_concrete
setblock 169 237 493 minecraft:magenta_stained_glass
fill 169 237 494 169 237 498 minecraft:black_concrete
setblock 169 237 499 minecraft:magenta_stained_glass
fill 169 237 500 169 237 502 minecraft:black_concrete
setblock 170 237 466 minecraft:magenta_stained_glass
fill 170 237 467 170 237 471 minecraft:black_concrete
setblock 170 237 472 minecraft:magenta_stained_glass
setblock 170 237 475 minecraft:black_concrete
fill 170 237 477 182 237 477 minecraft:black_concrete
setblock 170 237 478 minecraft:magenta_stained_glass
fill 170 237 479 170 237 482 minecraft:purpur_pillar
fill 170 237 483 171 237 483 minecraft:purpur_block
fill 170 237 484 170 237 487 minecraft:purpur_pillar
fill 170 237 488 182 237 489 minecraft:black_concrete
setblock 170 237 490 minecraft:magenta_stained_glass
fill 170 237 493 170 237 495 minecraft:black_concrete
setblock 170 237 496 minecraft:magenta_stained_glass
fill 170 237 497 170 237 501 minecraft:black_concrete
setblock 170 237 502 minecraft:magenta_stained_glass
fill 171 237 466 171 237 468 minecraft:black_concrete
setblock 171 237 469 minecraft:magenta_stained_glass
fill 171 237 470 171 237 472 minecraft:black_concrete
setblock 171 237 475 minecraft:magenta_stained_glass
fill 171 237 478 171 237 480 minecraft:black_concrete
setblock 171 237 481 minecraft:magenta_stained_glass
fill 171 237 482 182 237 482 minecraft:black_concrete
fill 171 237 484 171 237 486 minecraft:black_concrete
setblock 171 237 487 minecraft:magenta_stained_glass
setblock 171 237 490 minecraft:black_concrete
setblock 171 237 493 minecraft:magenta_stained_glass
fill 171 237 494 171 237 498 minecraft:black_concrete
setblock 171 237 499 minecraft:magenta_stained_glass
fill 171 237 500 171 237 502 minecraft:black_concrete
setblock 172 237 466 minecraft:magenta_stained_glass
fill 172 237 467 172 237 471 minecraft:black_concrete
setblock 172 237 472 minecraft:magenta_stained_glass
setblock 172 237 475 minecraft:black_concrete
setblock 172 237 478 minecraft:magenta_stained_glass
fill 172 237 479 172 237 481 minecraft:black_concrete
fill 172 237 483 182 237 483 minecraft:black_concrete
setblock 172 237 484 minecraft:magenta_stained_glass
fill 172 237 485 172 237 487 minecraft:black_concrete
setblock 172 237 490 minecraft:magenta_stained_glass
fill 172 237 493 172 237 495 minecraft:black_concrete
setblock 172 237 496 minecraft:magenta_stained_glass
fill 172 237 497 172 237 501 minecraft:black_concrete
setblock 172 237 502 minecraft:magenta_stained_glass
fill 173 237 466 173 237 468 minecraft:black_concrete
setblock 173 237 469 minecraft:magenta_stained_glass
fill 173 237 470 173 237 472 minecraft:black_concrete
setblock 173 237 475 minecraft:magenta_stained_glass
fill 173 237 478 173 237 480 minecraft:black_concrete
setblock 173 237 481 minecraft:magenta_stained_glass
fill 173 237 484 173 237 486 minecraft:black_concrete
setblock 173 237 487 minecraft:magenta_stained_glass
setblock 173 237 490 minecraft:black_concrete
setblock 173 237 493 minecraft:magenta_stained_glass
fill 173 237 494 173 237 498 minecraft:black_concrete
setblock 173 237 499 minecraft:magenta_stained_glass
fill 173 237 500 173 237 502 minecraft:black_concrete
setblock 174 237 466 minecraft:magenta_stained_glass
fill 174 237 467 174 237 471 minecraft:black_concrete
setblock 174 237 472 minecraft:magenta_stained_glass
setblock 174 237 475 minecraft:black_concrete
setblock 174 237 478 minecraft:magenta_stained_glass
fill 174 237 479 174 237 481 minecraft:black_concrete
setblock 174 237 484 minecraft:magenta_stained_glass
fill 174 237 485 174 237 487 minecraft:black_concrete
setblock 174 237 490 minecraft:magenta_stained_glass
fill 174 237 493 174 237 495 minecraft:black_concrete
setblock 174 237 496 minecraft:magenta_stained_glass
fill 174 237 497 174 237 501 minecraft:black_concrete
setblock 174 237 502 minecraft:magenta_stained_glass
fill 175 237 466 175 237 468 minecraft:black_concrete
setblock 175 237 469 minecraft:magenta_stained_glass
fill 175 237 470 175 237 472 minecraft:black_concrete
setblock 175 237 475 minecraft:magenta_stained_glass
fill 175 237 478 175 237 480 minecraft:black_concrete
setblock 175 237 481 minecraft:magenta_stained_glass
fill 175 237 484 175 237 486 minecraft:black_concrete
setblock 175 237 487 minecraft:magenta_stained_glass
setblock 175 237 490 minecraft:black_concrete
setblock 175 237 493 minecraft:magenta_stained_glass
fill 175 237 494 175 237 498 minecraft:black_concrete
setblock 175 237 499 minecraft:magenta_stained_glass
fill 175 237 500 175 237 502 minecraft:black_concrete
setblock 176 237 466 minecraft:magenta_stained_glass
fill 176 237 467 176 237 471 minecraft:black_concrete
setblock 176 237 472 minecraft:magenta_stained_glass
setblock 176 237 475 minecraft:black_concrete
setblock 176 237 478 minecraft:magenta_stained_glass
fill 176 237 479 176 237 481 minecraft:black_concrete
setblock 176 237 484 minecraft:magenta_stained_glass
fill 176 237 485 176 237 487 minecraft:black_concrete
setblock 176 237 490 minecraft:magenta_stained_glass
fill 176 237 493 176 237 495 minecraft:black_concrete
setblock 176 237 496 minecraft:magenta_stained_glass
fill 176 237 497 176 237 501 minecraft:black_concrete
setblock 176 237 502 minecraft:magenta_stained_glass
fill 177 237 466 177 237 468 minecraft:black_concrete
setblock 177 237 469 minecraft:magenta_stained_glass
fill 177 237 470 177 237 472 minecraft:black_concrete
setblock 177 237 475 minecraft:magenta_stained_glass
fill 177 237 478 177 237 480 minecraft:black_concrete
setblock 177 237 481 minecraft:magenta_stained_glass
fill 177 237 484 177 237 486 minecraft:black_concrete
setblock 177 237 487 minecraft:magenta_stained_glass
setblock 177 237 490 minecraft:black_concrete
setblock 177 237 493 minecraft:magenta_stained_glass
fill 177 237 494 177 237 498 minecraft:black_concrete
setblock 177 237 499 minecraft:magenta_stained_glass
fill 177 237 500 177 237 502 minecraft:black_concrete
setblock 178 237 466 minecraft:magenta_stained_glass
fill 178 237 467 178 237 471 minecraft:black_concrete
setblock 178 237 472 minecraft:magenta_stained_glass
setblock 178 237 475 minecraft:black_concrete
setblock 178 237 478 minecraft:magenta_stained_glass
fill 178 237 479 178 237 481 minecraft:black_concrete
setblock 178 237 484 minecraft:magenta_stained_glass
fill 178 237 485 178 237 487 minecraft:black_concrete
setblock 178 237 490 minecraft:magenta_stained_glass
fill 178 237 493 178 237 495 minecraft:black_concrete
setblock 178 237 496 minecraft:magenta_stained_glass
fill 178 237 497 178 237 501 minecraft:black_concrete
setblock 178 237 502 minecraft:magenta_stained_glass
fill 179 237 466 179 237 468 minecraft:black_concrete
setblock 179 237 469 minecraft:magenta_stained_glass
fill 179 237 470 179 237 472 minecraft:black_concrete
setblock 179 237 475 minecraft:magenta_stained_glass
fill 179 237 478 179 237 480 minecraft:black_concrete
setblock 179 237 481 minecraft:magenta_stained_glass
fill 179 237 484 179 237 486 minecraft:black_concrete
setblock 179 237 487 minecraft:magenta_stained_glass
setblock 179 237 490 minecraft:black_concrete
setblock 179 237 493 minecraft:magenta_stained_glass
fill 179 237 494 179 237 498 minecraft:black_concrete
setblock 179 237 499 minecraft:magenta_stained_glass
fill 179 237 500 179 237 502 minecraft:black_concrete
setblock 180 237 466 minecraft:magenta_stained_glass
fill 180 237 467 180 237 471 minecraft:black_concrete
setblock 180 237 472 minecraft:magenta_stained_glass
setblock 180 237 475 minecraft:black_concrete
setblock 180 237 478 minecraft:magenta_stained_glass
fill 180 237 479 180 237 481 minecraft:black_concrete
setblock 180 237 484 minecraft:magenta_stained_glass
fill 180 237 485 180 237 487 minecraft:black_concrete
setblock 180 237 490 minecraft:magenta_stained_glass
fill 180 237 493 180 237 495 minecraft:black_concrete
setblock 180 237 496 minecraft:magenta_stained_glass
fill 180 237 497 180 237 501 minecraft:black_concrete
setblock 180 237 502 minecraft:magenta_stained_glass
fill 181 237 466 181 237 468 minecraft:black_concrete
setblock 181 237 469 minecraft:magenta_stained_glass
fill 181 237 470 181 237 472 minecraft:black_concrete
setblock 181 237 475 minecraft:magenta_stained_glass
fill 181 237 478 181 237 480 minecraft:black_concrete
setblock 181 237 481 minecraft:magenta_stained_glass
fill 181 237 484 181 237 486 minecraft:black_concrete
setblock 181 237 487 minecraft:magenta_stained_glass
setblock 181 237 490 minecraft:black_concrete
setblock 181 237 493 minecraft:magenta_stained_glass
fill 181 237 494 181 237 498 minecraft:black_concrete
setblock 181 237 499 minecraft:magenta_stained_glass
fill 181 237 500 181 237 502 minecraft:black_concrete
setblock 182 237 466 minecraft:magenta_stained_glass
fill 182 237 467 182 237 471 minecraft:black_concrete
setblock 182 237 472 minecraft:magenta_stained_glass
setblock 182 237 475 minecraft:black_concrete
setblock 182 237 478 minecraft:magenta_stained_glass
fill 182 237 479 182 237 481 minecraft:black_concrete
setblock 182 237 484 minecraft:magenta_stained_glass
fill 182 237 485 182 237 487 minecraft:black_concrete
setblock 182 237 490 minecraft:magenta_stained_glass
fill 182 237 493 182 237 495 minecraft:black_concrete
setblock 182 237 496 minecraft:magenta_stained_glass
fill 182 237 497 182 237 501 minecraft:black_concrete
setblock 182 237 502 minecraft:magenta_stained_glass
fill 183 237 467 183 276 467 minecraft:purpur_block
fill 183 237 493 183 307 493 minecraft:purpur_block
fill 183 237 495 183 289 495 minecraft:purpur_block
fill 141 238 476 141 293 476 minecraft:purpur_block
setblock 144 238 466 minecraft:light[level=14]
setblock 144 238 474 minecraft:light[level=14]
setblock 144 238 482 minecraft:light[level=14]
setblock 144 238 490 minecraft:light[level=14]
setblock 144 238 498 minecraft:light[level=14]
setblock 152 238 466 minecraft:light[level=14]
setblock 152 238 474 minecraft:light[level=14]
setblock 152 238 482 minecraft:light[level=14]
setblock 152 238 490 minecraft:light[level=14]
setblock 152 238 498 minecraft:light[level=14]
setblock 156 238 463 minecraft:magenta_stained_glass
fill 156 238 505 156 288 505 minecraft:purpur_block
fill 157 238 463 158 242 463 minecraft:purpur_block
setblock 157 238 505 minecraft:pearlescent_froglight
fill 158 238 505 159 279 505 minecraft:purpur_block
setblock 160 238 466 minecraft:light[level=14]
setblock 160 238 474 minecraft:light[level=14]
setblock 160 238 490 minecraft:light[level=14]
setblock 160 238 498 minecraft:light[level=14]
fill 163 238 505 163 307 505 minecraft:purpur_block
setblock 168 238 466 minecraft:light[level=14]
setblock 168 238 474 minecraft:light[level=14]
setblock 168 238 482 minecraft:light[level=14]
setblock 168 238 490 minecraft:light[level=14]
setblock 168 238 498 minecraft:light[level=14]
setblock 176 238 466 minecraft:light[level=14]
setblock 176 238 474 minecraft:light[level=14]
setblock 176 238 482 minecraft:light[level=14]
setblock 176 238 490 minecraft:light[level=14]
setblock 176 238 498 minecraft:light[level=14]
fill 156 239 463 156 257 463 minecraft:purpur_block
fill 157 239 505 157 252 505 minecraft:purpur_block
setblock 173 239 463 minecraft:white_concrete
setblock 173 239 505 minecraft:magenta_stained_glass
fill 174 239 505 174 307 505 minecraft:purpur_block
setblock 183 239 479 minecraft:white_concrete
setblock 141 240 475 minecraft:white_concrete
setblock 148 240 505 minecraft:pearlescent_froglight
fill 173 240 463 173 250 463 minecraft:purpur_block
fill 173 240 505 173 270 505 minecraft:purpur_block
fill 183 240 479 183 307 479 minecraft:purpur_block
setblock 141 241 468 minecraft:magenta_stained_glass
fill 141 241 475 141 307 475 minecraft:purpur_block
setblock 141 241 489 minecraft:magenta_stained_glass
fill 148 241 505 148 245 505 minecraft:purpur_block
fill 141 242 468 141 307 468 minecraft:purpur_block
fill 141 242 489 141 261 489 minecraft:purpur_block
setblock 183 242 501 minecraft:magenta_stained_glass
setblock 141 243 469 minecraft:magenta_stained_glass
fill 141 243 471 141 245 471 minecraft:magenta_concrete
fill 141 243 487 141 245 487 minecraft:magenta_concrete
fill 141 243 503 141 245 503 minecraft:magenta_concrete
fill 145 243 463 145 245 463 minecraft:magenta_concrete
fill 147 243 476 148 244 477 minecraft:purpur_block
fill 155 243 505 155 245 505 minecraft:magenta_concrete
fill 157 243 463 157 260 463 minecraft:purpur_block
setblock 158 243 463 minecraft:magenta_stained_glass
fill 161 243 463 161 245 463 minecraft:magenta_concrete
fill 171 243 505 171 245 505 minecraft:magenta_concrete
fill 177 243 463 177 245 463 minecraft:magenta_concrete
fill 183 243 473 183 245 473 minecraft:magenta_concrete
setblock 183 243 474 minecraft:white_concrete
fill 183 243 489 183 245 489 minecraft:magenta_concrete
fill 183 243 501 183 307 501 minecraft:purpur_block
fill 141 244 469 141 273 469 minecraft:purpur_block
setblock 141 244 477 minecraft:white_concrete
setblock 142 244 463 minecraft:pearlescent_froglight
setblock 150 244 463 minecraft:magenta_stained_glass
setblock 153 244 463 minecraft:pearlescent_froglight
fill 158 244 463 158 307 463 minecraft:purpur_block
fill 183 244 474 183 270 474 minecraft:purpur_block
fill 141 245 477 141 285 477 minecraft:purpur_block
fill 142 245 463 142 255 463 minecraft:purpur_block
fill 150 245 463 150 269 463 minecraft:purpur_block
fill 153 245 463 153 252 463 minecraft:purpur_block
fill 170 245 484 171 246 485 minecraft:end_stone
fill 171 245 483 171 246 483 minecraft:end_stone
fill 141 246 471 141 251 471 minecraft:purpur_block
fill 141 246 480 141 268 480 minecraft:purpur_block
setblock 141 246 481 minecraft:magenta_stained_glass
fill 141 246 487 141 251 487 minecraft:purpur_block
fill 141 246 503 141 251 503 minecraft:purpur_block
setblock 144 246 466 minecraft:light[level=14]
setblock 144 246 474 minecraft:light[level=14]
setblock 144 246 482 minecraft:light[level=14]
setblock 144 246 490 minecraft:light[level=14]
setblock 144 246 498 minecraft:light[level=14]
fill 145 246 463 145 251 463 minecraft:purpur_block
setblock 145 246 505 minecraft:white_concrete
setblock 148 246 505 minecraft:magenta_stained_glass
setblock 152 246 466 minecraft:light[level=14]
setblock 152 246 474 minecraft:light[level=14]
setblock 152 246 482 minecraft:light[level=14]
setblock 152 246 490 minecraft:light[level=14]
setblock 152 246 498 minecraft:light[level=14]
fill 155 246 505 155 251 505 minecraft:purpur_block
setblock 160 246 463 minecraft:magenta_stained_glass
setblock 160 246 466 minecraft:light[level=14]
setblock 160 246 474 minecraft:light[level=14]
setblock 160 246 482 minecraft:light[level=14]
setblock 160 246 490 minecraft:light[level=14]
setblock 160 246 498 minecraft:light[level=14]
fill 161 246 463 161 251 463 minecraft:purpur_block
setblock 165 246 463 minecraft:pearlescent_froglight
fill 168 246 463 169 282 463 minecraft:purpur_block
setblock 168 246 466 minecraft:light[level=14]
setblock 168 246 474 minecraft:light[level=14]
setblock 168 246 482 minecraft:light[level=14]
setblock 168 246 490 minecraft:light[level=14]
setblock 168 246 498 minecraft:light[level=14]
setblock 170 246 463 minecraft:pearlescent_froglight
fill 171 246 505 171 251 505 minecraft:purpur_block
setblock 176 246 466 minecraft:light[level=14]
setblock 176 246 474 minecraft:light[level=14]
setblock 176 246 482 minecraft:light[level=14]
setblock 176 246 490 minecraft:light[level=14]
setblock 176 246 498 minecraft:light[level=14]
fill 177 246 463 177 251 463 minecraft:purpur_block
fill 183 246 473 183 251 473 minecraft:purpur_block
fill 183 246 489 183 251 489 minecraft:purpur_block
setblock 183 246 497 minecraft:white_concrete
fill 141 247 481 141 254 481 minecraft:purpur_block
fill 145 247 505 145 292 505 minecraft:purpur_block
fill 148 247 505 148 291 505 minecraft:purpur_block
fill 160 247 463 160 259 463 minecraft:purpur_block
fill 165 247 463 165 253 463 minecraft:purpur_block
fill 170 247 463 170 251 463 minecraft:purpur_block
fill 171 247 499 171 248 499 minecraft:obsidian
fill 183 247 497 183 282 497 minecraft:purpur_block
setblock 141 248 486 minecraft:pearlescent_froglight
setblock 141 249 479 minecraft:white_concrete
fill 141 249 486 141 307 486 minecraft:purpur_block
fill 162 249 463 162 306 463 minecraft:purpur_block
setblock 163 249 463 minecraft:pearlescent_froglight
fill 164 249 463 164 267 463 minecraft:purpur_block
setblock 167 249 505 minecraft:white_concrete
fill 141 250 479 141 302 479 minecraft:purpur_block
fill 163 250 463 163 307 463 minecraft:purpur_block
fill 167 250 505 167 260 505 minecraft:purpur_block
setblock 181 250 463 minecraft:pearlescent_froglight
fill 182 250 463 182 251 463 minecraft:purpur_block
setblock 141 251 501 minecraft:white_concrete
setblock 173 251 463 minecraft:white_concrete
fill 181 251 463 181 284 463 minecraft:purpur_block
fill 183 251 502 183 301 503 minecraft:purpur_block
setblock 183 251 504 minecraft:white_concrete
fill 141 252 471 141 254 471 minecraft:magenta_concrete
fill 141 252 487 141 254 487 minecraft:magenta_concrete
setblock 141 252 488 minecraft:pearlescent_froglight
fill 141 252 501 141 295 501 minecraft:purpur_block
fill 141 252 503 141 254 503 minecraft:magenta_concrete
fill 145 252 463 145 254 463 minecraft:magenta_concrete
fill 155 252 505 155 254 505 minecraft:magenta_concrete
fill 161 252 463 161 254 463 minecraft:magenta_concrete
setblock 170 252 463 minecraft:magenta_stained_glass
fill 171 252 505 171 254 505 minecraft:magenta_concrete
setblock 173 252 463 minecraft:magenta_stained_glass
fill 177 252 463 177 254 463 minecraft:magenta_concrete
setblock 182 252 463 minecraft:magenta_stained_glass
fill 183 252 473 183 254 473 minecraft:magenta_concrete
setblock 183 252 485 minecraft:magenta_stained_glass
fill 183 252 489 183 254 489 minecraft:magenta_concrete
fill 183 252 504 183 292 504 minecraft:purpur_block
fill 141 253 488 141 270 488 minecraft:purpur_block
setblock 144 253 463 minecraft:white_concrete
setblock 153 253 463 minecraft:pearlescent_froglight
setblock 157 253 505 minecraft:pearlescent_froglight
fill 170 253 463 170 307 463 minecraft:purpur_block
fill 173 253 463 173 259 463 minecraft:purpur_block
fill 182 253 463 182 256 463 minecraft:purpur_block
setblock 183 253 466 minecraft:pearlescent_froglight
fill 183 253 485 183 307 485 minecraft:purpur_block
setblock 183 253 486 minecraft:magenta_stained_glass
fill 144 254 463 144 298 463 minecraft:purpur_block
setblock 144 254 466 minecraft:light[level=14]
setblock 144 254 474 minecraft:light[level=14]
setblock 144 254 482 minecraft:light[level=14]
setblock 144 254 490 minecraft:light[level=14]
setblock 144 254 498 minecraft:light[level=14]
setblock 152 254 466 minecraft:light[level=14]
setblock 152 254 474 minecraft:light[level=14]
setblock 152 254 482 minecraft:light[level=14]
setblock 152 254 490 minecraft:light[level=14]
setblock 152 254 498 minecraft:light[level=14]
fill 153 254 463 153 275 463 minecraft:purpur_block
fill 157 254 505 157 257 505 minecraft:purpur_block
setblock 160 254 466 minecraft:light[level=14]
setblock 160 254 474 minecraft:light[level=14]
setblock 160 254 482 minecraft:light[level=14]
setblock 160 254 490 minecraft:light[level=14]
setblock 160 254 498 minecraft:light[level=14]
setblock 165 254 463 minecraft:magenta_stained_glass
setblock 168 254 466 minecraft:light[level=14]
setblock 168 254 474 minecraft:light[level=14]
setblock 168 254 482 minecraft:light[level=14]
setblock 168 254 490 minecraft:light[level=14]
setblock 168 254 498 minecraft:light[level=14]
setblock 172 254 505 minecraft:pearlescent_froglight
setblock 176 254 466 minecraft:light[level=14]
setblock 176 254 474 minecraft:light[level=14]
setblock 176 254 482 minecraft:light[level=14]
setblock 176 254 490 minecraft:light[level=14]
setblock 176 254 498 minecraft:light[level=14]
fill 183 254 466 183 270 466 minecraft:purpur_block
fill 183 254 486 183 260 486 minecraft:purpur_block
fill 141 255 471 141 260 471 minecraft:purpur_block
setblock 141 255 472 minecraft:pearlescent_froglight
setblock 141 255 481 minecraft:pearlescent_froglight
fill 141 255 487 141 260 487 minecraft:purpur_block
setblock 141 255 492 minecraft:magenta_stained_glass
fill 141 255 503 141 260 503 minecraft:purpur_block
fill 145 255 463 145 258 463 minecraft:purpur_block
fill 155 255 505 155 260 505 minecraft:purpur_block
fill 161 255 463 161 260 463 minecraft:purpur_block
fill 165 255 463 165 307 463 minecraft:purpur_block
setblock 166 255 463 minecraft:pearlescent_froglight
fill 171 255 505 172 260 505 minecraft:purpur_block
fill 177 255 463 177 260 463 minecraft:purpur_block
setblock 183 255 473 minecraft:purpur_block
setblock 183 255 489 minecraft:white_concrete
fill 141 256 472 141 289 472 minecraft:purpur_block
fill 141 256 481 141 307 481 minecraft:purpur_block
fill 141 256 492 141 284 492 minecraft:purpur_block
setblock 142 256 463 minecraft:magenta_stained_glass
setblock 160 256 505 minecraft:white_concrete
fill 166 256 463 166 259 463 minecraft:purpur_block
setblock 167 256 463 minecraft:pearlescent_froglight
setblock 168 256 505 minecraft:pearlescent_froglight
setblock 183 256 473 minecraft:pearlescent_froglight
fill 183 256 481 183 274 481 minecraft:purpur_block
setblock 183 256 482 minecraft:pearlescent_froglight
fill 183 256 483 183 265 484 minecraft:purpur_block
fill 183 256 489 183 260 489 minecraft:purpur_block
setblock 183 256 494 minecraft:white_concrete
fill 142 257 463 142 259 463 minecraft:purpur_block
fill 160 257 505 160 307 505 minecraft:purpur_block
fill 167 257 463 167 294 463 minecraft:purpur_block
fill 168 257 505 168 307 505 minecraft:purpur_block
setblock 182 257 463 minecraft:pearlescent_froglight
fill 183 257 473 183 260 473 minecraft:purpur_block
fill 183 257 482 183 279 482 minecraft:purpur_block
fill 183 257 494 183 266 494 minecraft:purpur_block
setblock 156 258 463 minecraft:white_concrete
setblock 157 258 505 minecraft:magenta_stained_glass
fill 182 258 463 182 259 463 minecraft:purpur_block
setblock 141 259 482 minecraft:magenta_stained_glass
setblock 145 259 463 minecraft:white_concrete
fill 153 259 476 154 260 476 minecraft:end_stone
fill 156 259 463 156 281 463 minecraft:purpur_block
fill 157 259 505 157 307 505 minecraft:purpur_block
setblock 162 259 505 minecraft:pearlescent_froglight
setblock 178 259 463 minecraft:white_concrete
fill 141 260 482 141 307 482 minecraft:purpur_block
setblock 142 260 463 minecraft:pearlescent_froglight
setblock 145 260 463 minecraft:purpur_block
setblock 160 260 463 minecraft:magenta_stained_glass
fill 162 260 505 162 265 505 minecraft:purpur_block
setblock 165 260 505 minecraft:white_concrete
setblock 166 260 463 minecraft:white_concrete
setblock 173 260 463 minecraft:pearlescent_froglight
fill 178 260 463 178 286 463 minecraft:purpur_block
setblock 182 260 463 minecraft:pearlescent_froglight
fill 141 261 471 141 263 471 minecraft:magenta_concrete
fill 141 261 487 141 263 487 minecraft:magenta_concrete
fill 141 261 503 141 263 503 minecraft:magenta_concrete
fill 142 261 463 142 273 463 minecraft:purpur_block
setblock 143 261 463 minecraft:white_concrete
fill 145 261 463 145 263 463 minecraft:magenta_concrete
fill 155 261 505 155 263 505 minecraft:magenta_concrete
setblock 157 261 463 minecraft:pearlescent_froglight
fill 160 261 463 160 297 463 minecraft:purpur_block
fill 161 261 463 161 263 463 minecraft:magenta_concrete
fill 165 261 505 165 307 505 minecraft:purpur_block
fill 166 261 463 166 287 463 minecraft:purpur_block
setblock 167 261 505 minecraft:white_concrete
setblock 169 261 505 minecraft:white_concrete
fill 171 261 463 172 261 463 minecraft:white_concrete
fill 171 261 505 171 263 505 minecraft:magenta_concrete
fill 172 261 505 172 265 505 minecraft:purpur_block
fill 173 261 463 173 307 463 minecraft:purpur_block
fill 177 261 463 177 263 463 minecraft:magenta_concrete
fill 182 261 463 182 291 463 minecraft:purpur_block
fill 183 261 473 183 263 473 minecraft:magenta_concrete
setblock 183 261 486 minecraft:white_concrete
fill 183 261 489 183 263 489 minecraft:magenta_concrete
setblock 141 262 489 minecraft:white_concrete
fill 143 262 463 143 307 463 minecraft:purpur_block
setblock 144 262 466 minecraft:light[level=14]
setblock 144 262 474 minecraft:light[level=14]
setblock 144 262 482 minecraft:light[level=14]
setblock 144 262 490 minecraft:light[level=14]
setblock 144 262 498 minecraft:light[level=14]
setblock 152 262 466 minecraft:light[level=14]
setblock 152 262 474 minecraft:light[level=14]
setblock 152 262 482 minecraft:light[level=14]
setblock 152 262 490 minecraft:light[level=14]
setblock 152 262 498 minecraft:light[level=14]
fill 154 262 479 154 263 480 minecraft:obsidian
fill 157 262 463 157 307 463 minecraft:purpur_block
setblock 160 262 466 minecraft:light[level=14]
setblock 160 262 474 minecraft:light[level=14]
setblock 160 262 482 minecraft:light[level=14]
setblock 160 262 490 minecraft:light[level=14]
setblock 160 262 498 minecraft:light[level=14]
fill 167 262 505 167 303 505 minecraft:purpur_block
setblock 168 262 466 minecraft:light[level=14]
setblock 168 262 474 minecraft:light[level=14]
setblock 168 262 482 minecraft:light[level=14]
setblock 168 262 490 minecraft:light[level=14]
setblock 168 262 498 minecraft:light[level=14]
fill 169 262 505 169 307 505 minecraft:purpur_block
fill 171 262 463 172 286 463 minecraft:purpur_block
setblock 176 262 466 minecraft:light[level=14]
setblock 176 262 474 minecraft:light[level=14]
setblock 176 262 482 minecraft:light[level=14]
setblock 176 262 490 minecraft:light[level=14]
setblock 176 262 498 minecraft:light[level=14]
fill 179 262 484 180 263 485 minecraft:purpur_block
fill 181 262 484 181 263 484 minecraft:purpur_block
fill 183 262 468 183 274 469 minecraft:purpur_block
setblock 183 262 470 minecraft:magenta_stained_glass
fill 183 262 486 183 272 486 minecraft:purpur_block
fill 141 263 489 141 307 489 minecraft:purpur_block
setblock 170 263 505 minecraft:pearlescent_froglight
schedule function dropper:buildpart/111_2 1t
