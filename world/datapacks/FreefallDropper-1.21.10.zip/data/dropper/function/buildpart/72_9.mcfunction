fill 36 239 362 36 242 362 minecraft:honeycomb_block
setblock 37 239 355 minecraft:yellow_terracotta
setblock 37 239 356 minecraft:honeycomb_block
setblock 37 239 360 minecraft:yellow_terracotta
fill 37 239 361 37 242 361 minecraft:honeycomb_block
setblock 38 239 354 minecraft:yellow_terracotta
fill 38 239 355 38 242 355 minecraft:honeycomb_block
setblock 38 239 359 minecraft:yellow_terracotta
fill 38 239 360 38 241 360 minecraft:honeycomb_block
setblock 39 239 323 minecraft:yellow_terracotta
setblock 39 239 333 minecraft:yellow_terracotta
fill 39 239 334 39 240 334 minecraft:honeycomb_block
setblock 39 239 348 minecraft:yellow_terracotta
fill 39 239 349 39 240 349 minecraft:honeycomb_block
setblock 39 239 353 minecraft:yellow_terracotta
fill 39 239 354 39 242 354 minecraft:honeycomb_block
setblock 39 239 358 minecraft:yellow_terracotta
fill 39 239 359 39 242 359 minecraft:honeycomb_block
setblock 39 239 363 minecraft:yellow_terracotta
setblock 40 239 323 minecraft:honeycomb_block
setblock 40 239 332 minecraft:yellow_terracotta
fill 40 239 333 40 242 333 minecraft:honeycomb_block
setblock 40 239 337 minecraft:yellow_terracotta
fill 40 239 338 40 242 338 minecraft:honeycomb_block
fill 40 239 340 40 239 341 minecraft:honeycomb_block
setblock 40 239 342 minecraft:yellow_terracotta
fill 40 239 343 40 242 343 minecraft:honeycomb_block
setblock 40 239 347 minecraft:yellow_terracotta
fill 40 239 348 40 242 348 minecraft:honeycomb_block
setblock 40 239 352 minecraft:yellow_terracotta
fill 40 239 353 40 242 353 minecraft:honeycomb_block
setblock 40 239 357 minecraft:yellow_terracotta
fill 40 239 358 40 242 358 minecraft:honeycomb_block
setblock 40 239 362 minecraft:yellow_terracotta
fill 40 239 363 40 242 363 minecraft:honeycomb_block
setblock 41 239 326 minecraft:yellow_terracotta
setblock 41 239 327 minecraft:honeycomb_block
setblock 41 239 331 minecraft:yellow_terracotta
fill 41 239 332 41 242 332 minecraft:honeycomb_block
setblock 41 239 336 minecraft:yellow_terracotta
fill 41 239 337 41 242 337 minecraft:honeycomb_block
setblock 41 239 341 minecraft:yellow_terracotta
fill 41 239 342 41 242 342 minecraft:honeycomb_block
setblock 41 239 346 minecraft:yellow_terracotta
fill 41 239 347 41 242 347 minecraft:honeycomb_block
setblock 41 239 351 minecraft:yellow_terracotta
fill 41 239 352 41 242 352 minecraft:honeycomb_block
setblock 41 239 356 minecraft:yellow_terracotta
fill 41 239 357 41 242 357 minecraft:honeycomb_block
setblock 41 239 361 minecraft:yellow_terracotta
fill 41 239 362 41 242 362 minecraft:honeycomb_block
fill 42 239 346 42 261 346 minecraft:honeycomb_block
fill 1 240 327 1 240 329 minecraft:honeycomb_block
setblock 1 240 330 minecraft:yellow_terracotta
fill 1 240 331 1 243 331 minecraft:honeycomb_block
setblock 1 240 335 minecraft:yellow_terracotta
fill 1 240 336 1 243 336 minecraft:honeycomb_block
setblock 1 240 340 minecraft:yellow_terracotta
fill 1 240 341 1 243 341 minecraft:honeycomb_block
setblock 1 240 345 minecraft:yellow_terracotta
fill 1 240 346 1 243 346 minecraft:honeycomb_block
setblock 1 240 350 minecraft:yellow_terracotta
fill 1 240 351 1 243 351 minecraft:honeycomb_block
setblock 1 240 355 minecraft:yellow_terracotta
fill 1 240 356 1 243 356 minecraft:honeycomb_block
setblock 1 240 360 minecraft:yellow_terracotta
fill 1 240 361 1 243 361 minecraft:honeycomb_block
setblock 2 240 330 minecraft:honeycomb_block
setblock 2 240 334 minecraft:yellow_terracotta
fill 2 240 335 2 243 335 minecraft:honeycomb_block
setblock 2 240 339 minecraft:yellow_terracotta
fill 2 240 340 2 243 340 minecraft:honeycomb_block
setblock 2 240 344 minecraft:yellow_terracotta
setblock 2 240 345 minecraft:honeycomb_block
setblock 2 240 349 minecraft:yellow_terracotta
setblock 2 240 350 minecraft:honeycomb_block
setblock 2 240 354 minecraft:yellow_terracotta
fill 2 240 355 2 241 355 minecraft:honeycomb_block
setblock 2 240 359 minecraft:yellow_terracotta
setblock 3 240 333 minecraft:yellow_terracotta
fill 3 240 334 3 241 334 minecraft:honeycomb_block
setblock 3 240 338 minecraft:yellow_terracotta
setblock 3 240 339 minecraft:honeycomb_block
setblock 7 240 322 minecraft:yellow_concrete
setblock 10 240 322 minecraft:yellow_concrete
setblock 13 240 323 minecraft:yellow_terracotta
fill 14 240 323 14 243 323 minecraft:honeycomb_block
fill 14 240 363 17 240 363 minecraft:honeycomb_block
fill 16 240 362 18 240 362 minecraft:honeycomb_block
setblock 17 240 324 minecraft:yellow_terracotta
setblock 18 240 323 minecraft:yellow_terracotta
fill 18 240 324 18 243 324 minecraft:honeycomb_block
setblock 18 240 363 minecraft:yellow_terracotta
fill 19 240 323 19 243 323 minecraft:honeycomb_block
setblock 19 240 362 minecraft:yellow_terracotta
fill 19 240 363 19 243 363 minecraft:honeycomb_block
fill 20 240 362 20 243 362 minecraft:honeycomb_block
setblock 22 240 324 minecraft:yellow_terracotta
setblock 23 240 323 minecraft:yellow_terracotta
setblock 23 240 362 minecraft:honeycomb_block
setblock 23 240 363 minecraft:yellow_terracotta
fill 24 240 323 24 241 323 minecraft:honeycomb_block
setblock 24 240 362 minecraft:yellow_terracotta
fill 24 240 363 24 243 363 minecraft:honeycomb_block
setblock 28 240 363 minecraft:yellow_terracotta
fill 29 240 363 29 243 363 minecraft:honeycomb_block
fill 32 240 362 33 240 362 minecraft:honeycomb_block
setblock 32 240 364 minecraft:yellow_concrete
setblock 33 240 363 minecraft:yellow_terracotta
setblock 34 240 361 minecraft:honeycomb_block
setblock 34 240 362 minecraft:yellow_terracotta
fill 34 240 363 34 243 363 minecraft:honeycomb_block
fill 35 240 322 35 308 322 minecraft:honeycomb_block
setblock 35 240 361 minecraft:yellow_terracotta
fill 35 240 362 35 243 362 minecraft:honeycomb_block
fill 36 240 361 36 243 361 minecraft:honeycomb_block
fill 37 240 360 37 242 360 minecraft:honeycomb_block
setblock 38 240 323 minecraft:yellow_terracotta
setblock 38 240 353 minecraft:yellow_terracotta
fill 38 240 354 38 242 354 minecraft:honeycomb_block
setblock 38 240 358 minecraft:yellow_terracotta
fill 38 240 359 38 242 359 minecraft:honeycomb_block
setblock 38 240 363 minecraft:yellow_terracotta
fill 38 240 364 38 308 364 minecraft:honeycomb_block
setblock 39 240 323 minecraft:honeycomb_block
fill 39 240 335 39 240 336 minecraft:honeycomb_block
setblock 39 240 337 minecraft:yellow_terracotta
setblock 39 240 352 minecraft:yellow_terracotta
fill 39 240 353 39 243 353 minecraft:honeycomb_block
setblock 39 240 357 minecraft:yellow_terracotta
fill 39 240 358 39 243 358 minecraft:honeycomb_block
setblock 39 240 362 minecraft:yellow_terracotta
fill 39 240 363 39 243 363 minecraft:honeycomb_block
setblock 40 240 331 minecraft:yellow_terracotta
fill 40 240 332 40 241 332 minecraft:honeycomb_block
setblock 40 240 335 minecraft:honeycomb_block
setblock 40 240 336 minecraft:yellow_terracotta
fill 40 240 337 40 243 337 minecraft:honeycomb_block
setblock 40 240 340 minecraft:honeycomb_block
setblock 40 240 341 minecraft:yellow_terracotta
fill 40 240 342 40 243 342 minecraft:honeycomb_block
setblock 40 240 346 minecraft:yellow_terracotta
fill 40 240 347 40 241 347 minecraft:honeycomb_block
setblock 40 240 351 minecraft:yellow_terracotta
fill 40 240 352 40 243 352 minecraft:honeycomb_block
setblock 40 240 356 minecraft:yellow_terracotta
fill 40 240 357 40 243 357 minecraft:honeycomb_block
setblock 40 240 361 minecraft:yellow_terracotta
fill 40 240 362 40 243 362 minecraft:honeycomb_block
fill 40 240 364 40 256 364 minecraft:honeycomb_block
setblock 41 240 324 minecraft:honey_block
setblock 41 240 330 minecraft:yellow_terracotta
fill 41 240 331 41 242 331 minecraft:honeycomb_block
setblock 41 240 335 minecraft:yellow_terracotta
fill 41 240 336 41 243 336 minecraft:honeycomb_block
setblock 41 240 340 minecraft:yellow_terracotta
fill 41 240 341 41 243 341 minecraft:honeycomb_block
setblock 41 240 345 minecraft:yellow_terracotta
fill 41 240 346 41 243 346 minecraft:honeycomb_block
setblock 41 240 350 minecraft:yellow_terracotta
fill 41 240 351 41 243 351 minecraft:honeycomb_block
setblock 41 240 355 minecraft:yellow_terracotta
fill 41 240 356 41 243 356 minecraft:honeycomb_block
setblock 41 240 360 minecraft:yellow_terracotta
fill 41 240 361 41 243 361 minecraft:honeycomb_block
setblock 41 240 364 minecraft:yellow_concrete
setblock 42 240 342 minecraft:yellow_concrete
setblock 1 241 324 minecraft:honey_block
setblock 1 241 328 minecraft:honeycomb_block
setblock 1 241 329 minecraft:yellow_terracotta
fill 1 241 330 1 243 330 minecraft:honeycomb_block
setblock 1 241 334 minecraft:yellow_terracotta
fill 1 241 335 1 244 335 minecraft:honeycomb_block
setblock 1 241 339 minecraft:yellow_terracotta
fill 1 241 340 1 244 340 minecraft:honeycomb_block
setblock 1 241 344 minecraft:yellow_terracotta
fill 1 241 345 1 244 345 minecraft:honeycomb_block
setblock 1 241 349 minecraft:yellow_terracotta
fill 1 241 350 1 242 350 minecraft:honeycomb_block
setblock 1 241 354 minecraft:yellow_terracotta
fill 1 241 355 1 244 355 minecraft:honeycomb_block
setblock 1 241 359 minecraft:yellow_terracotta
fill 1 241 360 1 244 360 minecraft:honeycomb_block
setblock 2 241 333 minecraft:yellow_terracotta
fill 2 241 334 2 244 334 minecraft:honeycomb_block
setblock 2 241 338 minecraft:yellow_terracotta
fill 2 241 339 2 244 339 minecraft:honeycomb_block
setblock 2 241 353 minecraft:yellow_terracotta
setblock 2 241 354 minecraft:honeycomb_block
setblock 2 241 358 minecraft:yellow_terracotta
setblock 3 241 337 minecraft:yellow_terracotta
setblock 3 241 338 minecraft:honeycomb_block
setblock 6 241 363 minecraft:honey_block
fill 7 241 322 7 256 322 minecraft:honeycomb_block
setblock 8 241 322 minecraft:yellow_terracotta
fill 10 241 322 10 308 322 minecraft:honeycomb_block
setblock 11 241 323 minecraft:honey_block
fill 13 241 323 13 244 323 minecraft:honeycomb_block
fill 14 241 363 16 241 363 minecraft:honeycomb_block
setblock 16 241 324 minecraft:yellow_terracotta
fill 16 241 362 17 241 362 minecraft:honeycomb_block
setblock 17 241 323 minecraft:yellow_terracotta
fill 17 241 324 17 244 324 minecraft:honeycomb_block
setblock 17 241 363 minecraft:yellow_terracotta
fill 18 241 323 18 244 323 minecraft:honeycomb_block
setblock 18 241 362 minecraft:yellow_terracotta
fill 18 241 363 18 244 363 minecraft:honeycomb_block
fill 19 241 362 19 244 362 minecraft:honeycomb_block
setblock 21 241 324 minecraft:yellow_terracotta
setblock 22 241 323 minecraft:yellow_terracotta
setblock 22 241 363 minecraft:yellow_terracotta
fill 23 241 323 23 242 323 minecraft:honeycomb_block
setblock 23 241 362 minecraft:yellow_terracotta
fill 23 241 363 23 244 363 minecraft:honeycomb_block
setblock 27 241 363 minecraft:yellow_terracotta
fill 28 241 363 28 244 363 minecraft:honeycomb_block
fill 31 241 362 32 241 362 minecraft:honeycomb_block
setblock 32 241 363 minecraft:yellow_terracotta
fill 32 241 364 32 308 364 minecraft:honeycomb_block
setblock 33 241 361 minecraft:honeycomb_block
setblock 33 241 362 minecraft:yellow_terracotta
fill 33 241 363 33 244 363 minecraft:honeycomb_block
setblock 34 241 361 minecraft:yellow_terracotta
fill 34 241 362 34 244 362 minecraft:honeycomb_block
fill 35 241 361 35 244 361 minecraft:honeycomb_block
setblock 36 241 323 minecraft:honey_block
fill 36 241 360 36 242 360 minecraft:honeycomb_block
setblock 37 241 363 minecraft:yellow_terracotta
setblock 38 241 353 minecraft:honeycomb_block
setblock 38 241 357 minecraft:yellow_terracotta
fill 38 241 358 38 243 358 minecraft:honeycomb_block
setblock 38 241 362 minecraft:yellow_terracotta
fill 38 241 363 38 244 363 minecraft:honeycomb_block
setblock 39 241 351 minecraft:yellow_terracotta
fill 39 241 352 39 242 352 minecraft:honeycomb_block
setblock 39 241 356 minecraft:yellow_terracotta
fill 39 241 357 39 244 357 minecraft:honeycomb_block
setblock 39 241 361 minecraft:yellow_terracotta
fill 39 241 362 39 244 362 minecraft:honeycomb_block
setblock 40 241 335 minecraft:yellow_terracotta
fill 40 241 336 40 244 336 minecraft:honeycomb_block
setblock 40 241 340 minecraft:yellow_terracotta
fill 40 241 341 40 244 341 minecraft:honeycomb_block
setblock 40 241 345 minecraft:yellow_terracotta
setblock 40 241 346 minecraft:honeycomb_block
setblock 40 241 350 minecraft:yellow_terracotta
fill 40 241 351 40 243 351 minecraft:honeycomb_block
setblock 40 241 355 minecraft:yellow_terracotta
fill 40 241 356 40 244 356 minecraft:honeycomb_block
setblock 40 241 360 minecraft:yellow_terracotta
fill 40 241 361 40 244 361 minecraft:honeycomb_block
setblock 41 241 330 minecraft:honeycomb_block
setblock 41 241 334 minecraft:yellow_terracotta
fill 41 241 335 41 244 335 minecraft:honeycomb_block
setblock 41 241 339 minecraft:yellow_terracotta
fill 41 241 340 41 244 340 minecraft:honeycomb_block
setblock 41 241 344 minecraft:yellow_terracotta
fill 41 241 345 41 244 345 minecraft:honeycomb_block
setblock 41 241 349 minecraft:yellow_terracotta
fill 41 241 350 41 244 350 minecraft:honeycomb_block
setblock 41 241 354 minecraft:yellow_terracotta
fill 41 241 355 41 244 355 minecraft:honeycomb_block
setblock 41 241 359 minecraft:yellow_terracotta
fill 41 241 360 41 244 360 minecraft:honeycomb_block
fill 41 241 364 41 308 364 minecraft:honeycomb_block
fill 42 241 342 42 308 342 minecraft:honeycomb_block
setblock 42 241 350 minecraft:orange_terracotta
setblock 1 242 329 minecraft:honeycomb_block
setblock 1 242 333 minecraft:yellow_terracotta
fill 1 242 334 1 245 334 minecraft:honeycomb_block
setblock 1 242 338 minecraft:yellow_terracotta
fill 1 242 339 1 245 339 minecraft:honeycomb_block
setblock 1 242 343 minecraft:yellow_terracotta
fill 1 242 344 1 245 344 minecraft:honeycomb_block
setblock 1 242 348 minecraft:yellow_terracotta
setblock 1 242 349 minecraft:honeycomb_block
setblock 1 242 353 minecraft:yellow_terracotta
fill 1 242 354 1 243 354 minecraft:honeycomb_block
setblock 1 242 358 minecraft:yellow_terracotta
fill 1 242 359 1 244 359 minecraft:honeycomb_block
setblock 2 242 332 minecraft:yellow_terracotta
fill 2 242 333 2 243 333 minecraft:honeycomb_block
setblock 2 242 337 minecraft:yellow_terracotta
fill 2 242 338 2 245 338 minecraft:honeycomb_block
setblock 2 242 342 minecraft:yellow_terracotta
setblock 5 242 323 minecraft:honey_block
fill 8 242 322 8 282 322 minecraft:honeycomb_block
setblock 12 242 363 minecraft:honey_block
fill 13 242 363 15 242 363 minecraft:honeycomb_block
setblock 15 242 324 minecraft:yellow_terracotta
fill 15 242 362 16 242 362 minecraft:honeycomb_block
setblock 16 242 323 minecraft:yellow_terracotta
fill 16 242 324 16 245 324 minecraft:honeycomb_block
setblock 16 242 363 minecraft:yellow_terracotta
fill 17 242 323 17 245 323 minecraft:honeycomb_block
setblock 17 242 362 minecraft:yellow_terracotta
fill 17 242 363 17 245 363 minecraft:honeycomb_block
fill 18 242 362 18 245 362 minecraft:honeycomb_block
setblock 20 242 324 minecraft:yellow_terracotta
setblock 21 242 323 minecraft:yellow_terracotta
setblock 21 242 363 minecraft:yellow_terracotta
fill 22 242 323 22 245 323 minecraft:honeycomb_block
setblock 22 242 362 minecraft:yellow_terracotta
fill 22 242 363 22 245 363 minecraft:honeycomb_block
setblock 22 242 364 minecraft:yellow_terracotta
setblock 23 242 362 minecraft:honeycomb_block
setblock 26 242 363 minecraft:yellow_terracotta
fill 27 242 363 27 245 363 minecraft:honeycomb_block
setblock 29 242 322 minecraft:yellow_concrete
setblock 30 242 323 minecraft:honey_block
setblock 31 242 362 minecraft:honeycomb_block
setblock 31 242 363 minecraft:yellow_terracotta
setblock 32 242 362 minecraft:yellow_terracotta
fill 32 242 363 32 245 363 minecraft:honeycomb_block
setblock 33 242 361 minecraft:yellow_terracotta
fill 33 242 362 33 245 362 minecraft:honeycomb_block
fill 34 242 361 34 245 361 minecraft:honeycomb_block
setblock 36 242 363 minecraft:yellow_terracotta
setblock 37 242 362 minecraft:yellow_terracotta
fill 37 242 363 37 245 363 minecraft:honeycomb_block
setblock 38 242 356 minecraft:yellow_terracotta
fill 38 242 357 38 243 357 minecraft:honeycomb_block
setblock 38 242 361 minecraft:yellow_terracotta
fill 38 242 362 38 245 362 minecraft:honeycomb_block
setblock 39 242 351 minecraft:honeycomb_block
setblock 39 242 355 minecraft:yellow_terracotta
fill 39 242 356 39 244 356 minecraft:honeycomb_block
setblock 39 242 360 minecraft:yellow_terracotta
fill 39 242 361 39 243 361 minecraft:honeycomb_block
setblock 40 242 334 minecraft:yellow_terracotta
fill 40 242 335 40 244 335 minecraft:honeycomb_block
setblock 40 242 339 minecraft:yellow_terracotta
fill 40 242 340 40 245 340 minecraft:honeycomb_block
setblock 40 242 349 minecraft:yellow_terracotta
fill 40 242 350 40 243 350 minecraft:honeycomb_block
setblock 40 242 354 minecraft:yellow_terracotta
fill 40 242 355 40 245 355 minecraft:honeycomb_block
setblock 40 242 359 minecraft:yellow_terracotta
fill 40 242 360 40 245 360 minecraft:honeycomb_block
setblock 41 242 333 minecraft:yellow_terracotta
fill 41 242 334 41 245 334 minecraft:honeycomb_block
setblock 41 242 338 minecraft:yellow_terracotta
fill 41 242 339 41 245 339 minecraft:honeycomb_block
setblock 41 242 343 minecraft:yellow_terracotta
fill 41 242 344 41 245 344 minecraft:honeycomb_block
setblock 41 242 348 minecraft:yellow_terracotta
fill 41 242 349 41 244 349 minecraft:honeycomb_block
setblock 41 242 353 minecraft:yellow_terracotta
fill 41 242 354 41 245 354 minecraft:honeycomb_block
setblock 41 242 358 minecraft:yellow_terracotta
fill 41 242 359 41 245 359 minecraft:honeycomb_block
setblock 41 242 363 minecraft:yellow_terracotta
setblock 42 242 334 minecraft:orange_terracotta
fill 42 242 350 42 262 350 minecraft:honeycomb_block
setblock 1 243 332 minecraft:yellow_terracotta
fill 1 243 333 1 246 333 minecraft:honeycomb_block
setblock 1 243 337 minecraft:yellow_terracotta
fill 1 243 338 1 246 338 minecraft:honeycomb_block
setblock 1 243 342 minecraft:yellow_terracotta
fill 1 243 343 1 246 343 minecraft:honeycomb_block
setblock 1 243 352 minecraft:yellow_terracotta
setblock 1 243 353 minecraft:honeycomb_block
setblock 1 243 357 minecraft:yellow_terracotta
fill 1 243 358 1 244 358 minecraft:honeycomb_block
setblock 1 243 364 minecraft:yellow_terracotta
setblock 2 243 336 minecraft:yellow_terracotta
fill 2 243 337 2 246 337 minecraft:honeycomb_block
setblock 2 243 341 minecraft:yellow_terracotta
setblock 3 243 325 minecraft:light[level=12]
setblock 3 243 332 minecraft:light[level=12]
setblock 3 243 339 minecraft:light[level=12]
setblock 3 243 346 minecraft:light[level=12]
setblock 3 243 353 minecraft:light[level=12]
setblock 3 243 360 minecraft:light[level=12]
setblock 10 243 325 minecraft:light[level=12]
setblock 10 243 332 minecraft:light[level=12]
setblock 10 243 339 minecraft:light[level=12]
setblock 10 243 346 minecraft:light[level=12]
setblock 10 243 353 minecraft:light[level=12]
setblock 10 243 360 minecraft:light[level=12]
setblock 11 243 322 minecraft:orange_terracotta
fill 12 243 323 12 245 323 minecraft:honeycomb_block
fill 12 243 363 14 243 363 minecraft:honeycomb_block
fill 14 243 362 15 243 362 minecraft:honeycomb_block
setblock 15 243 323 minecraft:yellow_terracotta
fill 15 243 324 15 246 324 minecraft:honeycomb_block
setblock 15 243 363 minecraft:yellow_terracotta
fill 16 243 323 16 246 323 minecraft:honeycomb_block
setblock 16 243 362 minecraft:yellow_terracotta
fill 16 243 363 16 246 363 minecraft:honeycomb_block
setblock 17 243 325 minecraft:light[level=12]
setblock 17 243 332 minecraft:light[level=12]
setblock 17 243 339 minecraft:light[level=12]
setblock 17 243 346 minecraft:light[level=12]
setblock 17 243 353 minecraft:light[level=12]
setblock 17 243 360 minecraft:light[level=12]
fill 17 243 362 17 246 362 minecraft:honeycomb_block
setblock 19 243 324 minecraft:yellow_terracotta
setblock 20 243 323 minecraft:yellow_terracotta
setblock 20 243 363 minecraft:yellow_terracotta
fill 21 243 323 21 246 323 minecraft:honeycomb_block
setblock 21 243 362 minecraft:yellow_terracotta
fill 21 243 363 21 246 363 minecraft:honeycomb_block
fill 22 243 362 22 246 362 minecraft:honeycomb_block
fill 22 243 364 22 260 364 minecraft:honeycomb_block
setblock 24 243 323 minecraft:honey_block
setblock 24 243 325 minecraft:light[level=12]
setblock 24 243 332 minecraft:light[level=12]
setblock 24 243 339 minecraft:light[level=12]
setblock 24 243 346 minecraft:light[level=12]
setblock 24 243 353 minecraft:light[level=12]
setblock 24 243 360 minecraft:light[level=12]
setblock 25 243 363 minecraft:yellow_terracotta
fill 26 243 363 26 246 363 minecraft:honeycomb_block
fill 29 243 322 29 308 322 minecraft:honeycomb_block
setblock 30 243 362 minecraft:honeycomb_block
setblock 30 243 363 minecraft:yellow_terracotta
setblock 31 243 325 minecraft:light[level=12]
setblock 31 243 332 minecraft:light[level=12]
setblock 31 243 339 minecraft:light[level=12]
setblock 31 243 346 minecraft:light[level=12]
setblock 31 243 353 minecraft:light[level=12]
setblock 31 243 360 minecraft:light[level=12]
setblock 31 243 362 minecraft:yellow_terracotta
fill 31 243 363 31 246 363 minecraft:honeycomb_block
setblock 32 243 361 minecraft:yellow_terracotta
fill 32 243 362 32 246 362 minecraft:honeycomb_block
fill 33 243 361 33 246 361 minecraft:honeycomb_block
setblock 35 243 363 minecraft:yellow_terracotta
setblock 36 243 362 minecraft:yellow_terracotta
fill 36 243 363 36 246 363 minecraft:honeycomb_block
setblock 37 243 361 minecraft:yellow_terracotta
fill 37 243 362 37 246 362 minecraft:honeycomb_block
setblock 38 243 325 minecraft:light[level=12]
setblock 38 243 332 minecraft:light[level=12]
setblock 38 243 339 minecraft:light[level=12]
setblock 38 243 346 minecraft:light[level=12]
setblock 38 243 353 minecraft:light[level=12]
setblock 38 243 356 minecraft:honeycomb_block
setblock 38 243 360 minecraft:light[level=12]
fill 38 243 361 38 246 361 minecraft:honeycomb_block
setblock 39 243 354 minecraft:yellow_terracotta
fill 39 243 355 39 244 355 minecraft:honeycomb_block
setblock 39 243 359 minecraft:yellow_terracotta
fill 39 243 360 39 244 360 minecraft:honeycomb_block
setblock 40 243 338 minecraft:yellow_terracotta
fill 40 243 339 40 246 339 minecraft:honeycomb_block
setblock 40 243 353 minecraft:yellow_terracotta
fill 40 243 354 40 245 354 minecraft:honeycomb_block
setblock 40 243 358 minecraft:yellow_terracotta
fill 40 243 359 40 246 359 minecraft:honeycomb_block
setblock 40 243 363 minecraft:yellow_terracotta
setblock 41 243 325 minecraft:honey_block
setblock 41 243 332 minecraft:yellow_terracotta
fill 41 243 333 41 244 333 minecraft:honeycomb_block
setblock 41 243 337 minecraft:yellow_terracotta
fill 41 243 338 41 246 338 minecraft:honeycomb_block
setblock 41 243 342 minecraft:yellow_terracotta
fill 41 243 343 41 246 343 minecraft:honeycomb_block
setblock 41 243 347 minecraft:yellow_terracotta
fill 41 243 348 41 244 348 minecraft:honeycomb_block
setblock 41 243 352 minecraft:yellow_terracotta
fill 41 243 353 41 246 353 minecraft:honeycomb_block
setblock 41 243 357 minecraft:yellow_terracotta
fill 41 243 358 41 246 358 minecraft:honeycomb_block
setblock 41 243 362 minecraft:yellow_terracotta
fill 41 243 363 41 246 363 minecraft:honeycomb_block
fill 42 243 334 42 308 334 minecraft:honeycomb_block
setblock 0 244 327 minecraft:yellow_terracotta
setblock 0 244 332 minecraft:yellow_concrete
setblock 1 244 323 minecraft:honey_block
setblock 1 244 331 minecraft:yellow_terracotta
fill 1 244 332 1 246 332 minecraft:honeycomb_block
setblock 1 244 336 minecraft:yellow_terracotta
fill 1 244 337 1 247 337 minecraft:honeycomb_block
setblock 1 244 341 minecraft:yellow_terracotta
fill 1 244 342 1 247 342 minecraft:honeycomb_block
setblock 1 244 356 minecraft:yellow_terracotta
setblock 1 244 357 minecraft:honeycomb_block
fill 1 244 364 1 249 364 minecraft:honeycomb_block
setblock 2 244 335 minecraft:yellow_terracotta
fill 2 244 336 2 247 336 minecraft:honeycomb_block
setblock 2 244 340 minecraft:yellow_terracotta
fill 2 244 341 2 247 341 minecraft:honeycomb_block
setblock 5 244 363 minecraft:honey_block
fill 7 244 324 7 246 324 minecraft:brown_terracotta
fill 8 244 323 8 246 323 minecraft:brown_terracotta
fill 8 244 325 8 246 325 minecraft:brown_terracotta
fill 9 244 324 9 246 324 minecraft:brown_terracotta
fill 11 244 322 11 246 323 minecraft:honeycomb_block
fill 12 244 363 13 244 363 minecraft:honeycomb_block
fill 13 244 362 14 244 362 minecraft:honeycomb_block
setblock 14 244 323 minecraft:yellow_terracotta
fill 14 244 324 14 247 324 minecraft:honeycomb_block
setblock 14 244 363 minecraft:yellow_terracotta
fill 15 244 323 15 247 323 minecraft:honeycomb_block
setblock 15 244 362 minecraft:yellow_terracotta
fill 15 244 363 15 247 363 minecraft:honeycomb_block
fill 16 244 362 16 247 362 minecraft:honeycomb_block
fill 17 244 361 18 246 361 minecraft:honeycomb_block
setblock 18 244 324 minecraft:yellow_terracotta
setblock 19 244 323 minecraft:yellow_terracotta
setblock 19 244 363 minecraft:yellow_terracotta
fill 20 244 323 20 247 323 minecraft:honeycomb_block
setblock 20 244 362 minecraft:yellow_terracotta
fill 20 244 363 20 247 363 minecraft:honeycomb_block
fill 21 244 362 21 247 362 minecraft:honeycomb_block
setblock 24 244 363 minecraft:yellow_terracotta
fill 25 244 363 25 247 363 minecraft:honeycomb_block
setblock 29 244 362 minecraft:honeycomb_block
setblock 29 244 363 minecraft:yellow_terracotta
setblock 30 244 362 minecraft:yellow_terracotta
fill 30 244 363 30 247 363 minecraft:honeycomb_block
fill 31 244 362 31 247 362 minecraft:honeycomb_block
fill 32 244 361 32 247 361 minecraft:honeycomb_block
setblock 34 244 363 minecraft:yellow_terracotta
setblock 35 244 362 minecraft:yellow_terracotta
fill 35 244 363 35 247 363 minecraft:honeycomb_block
setblock 36 244 361 minecraft:yellow_terracotta
fill 36 244 362 36 247 362 minecraft:honeycomb_block
setblock 37 244 323 minecraft:honey_block
fill 37 244 361 37 247 361 minecraft:honeycomb_block
setblock 39 244 358 minecraft:yellow_terracotta
fill 39 244 359 39 245 359 minecraft:honeycomb_block
setblock 39 244 363 minecraft:yellow_terracotta
setblock 40 244 337 minecraft:yellow_terracotta
fill 40 244 338 40 247 338 minecraft:honeycomb_block
setblock 40 244 342 minecraft:yellow_terracotta
fill 40 244 343 40 247 343 minecraft:honeycomb_block
setblock 40 244 352 minecraft:yellow_terracotta
setblock 40 244 353 minecraft:honeycomb_block
setblock 40 244 357 minecraft:yellow_terracotta
fill 40 244 358 40 247 358 minecraft:honeycomb_block
setblock 40 244 362 minecraft:yellow_terracotta
fill 40 244 363 40 247 363 minecraft:honeycomb_block
setblock 41 244 336 minecraft:yellow_terracotta
fill 41 244 337 41 247 337 minecraft:honeycomb_block
setblock 41 244 341 minecraft:yellow_terracotta
fill 41 244 342 41 247 342 minecraft:honeycomb_block
setblock 41 244 346 minecraft:yellow_terracotta
fill 41 244 347 41 247 347 minecraft:honeycomb_block
setblock 41 244 351 minecraft:yellow_terracotta
fill 41 244 352 41 245 352 minecraft:honeycomb_block
setblock 41 244 356 minecraft:yellow_terracotta
fill 41 244 357 41 247 357 minecraft:honeycomb_block
setblock 41 244 361 minecraft:yellow_terracotta
fill 41 244 362 41 247 362 minecraft:honeycomb_block
fill 0 245 322 0 308 322 minecraft:honeycomb_block
setblock 0 245 323 minecraft:orange_terracotta
fill 0 245 327 0 308 327 minecraft:honeycomb_block
fill 0 245 332 0 308 332 minecraft:honeycomb_block
setblock 0 245 347 minecraft:yellow_concrete
setblock 1 245 329 minecraft:honey_block
setblock 1 245 335 minecraft:yellow_terracotta
fill 1 245 336 1 248 336 minecraft:honeycomb_block
setblock 1 245 340 minecraft:yellow_terracotta
fill 1 245 341 1 248 341 minecraft:honeycomb_block
setblock 1 245 345 minecraft:yellow_terracotta
setblock 1 245 348 minecraft:honey_block
fill 2 245 335 2 246 335 minecraft:honeycomb_block
setblock 2 245 339 minecraft:yellow_terracotta
fill 2 245 340 2 248 340 minecraft:honeycomb_block
setblock 6 245 323 minecraft:honey_block
fill 10 245 323 10 247 323 minecraft:honeycomb_block
fill 10 245 363 12 245 363 minecraft:honeycomb_block
fill 12 245 362 13 245 362 minecraft:honeycomb_block
setblock 13 245 322 minecraft:orange_terracotta
setblock 13 245 323 minecraft:yellow_terracotta
fill 13 245 324 13 248 324 minecraft:honeycomb_block
setblock 13 245 363 minecraft:yellow_terracotta
fill 14 245 323 14 248 323 minecraft:honeycomb_block
setblock 14 245 362 minecraft:yellow_terracotta
fill 14 245 363 14 248 363 minecraft:honeycomb_block
setblock 15 245 361 minecraft:yellow_terracotta
fill 15 245 362 15 248 362 minecraft:honeycomb_block
fill 16 245 361 16 248 361 minecraft:honeycomb_block
setblock 17 245 324 minecraft:yellow_terracotta
setblock 18 245 323 minecraft:yellow_terracotta
fill 18 245 324 18 248 324 minecraft:honeycomb_block
setblock 18 245 363 minecraft:yellow_terracotta
fill 19 245 323 19 248 323 minecraft:honeycomb_block
setblock 19 245 362 minecraft:yellow_terracotta
fill 19 245 363 19 248 363 minecraft:honeycomb_block
fill 20 245 362 20 248 362 minecraft:honeycomb_block
setblock 23 245 362 minecraft:honeycomb_block
setblock 23 245 363 minecraft:yellow_terracotta
fill 24 245 363 24 248 363 minecraft:honeycomb_block
fill 27 245 362 28 245 362 minecraft:honeycomb_block
setblock 28 245 363 minecraft:yellow_terracotta
setblock 29 245 362 minecraft:yellow_terracotta
fill 29 245 363 29 248 363 minecraft:honeycomb_block
fill 30 245 362 30 248 362 minecraft:honeycomb_block
setblock 31 245 323 minecraft:honey_block
fill 31 245 361 31 248 361 minecraft:honeycomb_block
setblock 33 245 363 minecraft:yellow_terracotta
fill 34 245 323 35 247 323 minecraft:honeycomb_block
setblock 34 245 362 minecraft:yellow_terracotta
fill 34 245 363 34 248 363 minecraft:honeycomb_block
setblock 35 245 360 minecraft:honeycomb_block
setblock 35 245 361 minecraft:yellow_terracotta
fill 35 245 362 35 248 362 minecraft:honeycomb_block
fill 36 245 361 36 248 361 minecraft:honeycomb_block
setblock 38 245 363 minecraft:yellow_terracotta
setblock 39 245 357 minecraft:yellow_terracotta
setblock 39 245 358 minecraft:honeycomb_block
setblock 39 245 362 minecraft:yellow_terracotta
fill 39 245 363 39 248 363 minecraft:honeycomb_block
setblock 40 245 336 minecraft:yellow_terracotta
fill 40 245 337 40 248 337 minecraft:honeycomb_block
setblock 40 245 341 minecraft:yellow_terracotta
fill 40 245 342 40 248 342 minecraft:honeycomb_block
setblock 40 245 356 minecraft:yellow_terracotta
fill 40 245 357 40 247 357 minecraft:honeycomb_block
setblock 40 245 361 minecraft:yellow_terracotta
setblock 41 245 332 minecraft:honey_block
setblock 41 245 335 minecraft:yellow_terracotta
fill 41 245 336 41 248 336 minecraft:honeycomb_block
setblock 41 245 340 minecraft:yellow_terracotta
fill 41 245 341 41 248 341 minecraft:honeycomb_block
setblock 41 245 345 minecraft:yellow_terracotta
fill 41 245 346 41 248 346 minecraft:honeycomb_block
setblock 41 245 350 minecraft:yellow_terracotta
setblock 41 245 351 minecraft:honeycomb_block
setblock 41 245 355 minecraft:yellow_terracotta
fill 41 245 356 41 248 356 minecraft:honeycomb_block
setblock 41 245 360 minecraft:yellow_terracotta
fill 41 245 361 41 248 361 minecraft:honeycomb_block
setblock 42 245 327 minecraft:yellow_concrete
fill 0 246 323 0 308 323 minecraft:honeycomb_block
setblock 0 246 335 minecraft:yellow_terracotta
setblock 0 246 346 minecraft:yellow_terracotta
fill 0 246 347 0 290 347 minecraft:honeycomb_block
setblock 1 246 334 minecraft:yellow_terracotta
fill 1 246 335 1 249 335 minecraft:honeycomb_block
setblock 1 246 339 minecraft:yellow_terracotta
fill 1 246 340 1 249 340 minecraft:honeycomb_block
setblock 1 246 344 minecraft:yellow_terracotta
fill 1 246 345 1 249 345 minecraft:honeycomb_block
setblock 1 246 354 minecraft:honey_block
fill 1 246 360 1 247 360 minecraft:honey_block
setblock 2 246 338 minecraft:yellow_terracotta
fill 2 246 339 2 249 339 minecraft:honeycomb_block
setblock 7 246 323 minecraft:brown_terracotta
setblock 7 246 325 minecraft:brown_terracotta
fill 9 246 323 9 248 323 minecraft:honeycomb_block
setblock 9 246 325 minecraft:brown_terracotta
fill 9 246 363 11 246 363 minecraft:honeycomb_block
fill 11 246 362 12 246 362 minecraft:honeycomb_block
setblock 12 246 323 minecraft:yellow_terracotta
fill 12 246 324 12 249 324 minecraft:honeycomb_block
setblock 12 246 363 minecraft:yellow_terracotta
fill 13 246 322 13 249 323 minecraft:honeycomb_block
setblock 13 246 362 minecraft:yellow_terracotta
fill 13 246 363 13 249 363 minecraft:honeycomb_block
setblock 14 246 361 minecraft:yellow_terracotta
fill 14 246 362 14 249 362 minecraft:honeycomb_block
fill 15 246 361 15 249 361 minecraft:honeycomb_block
setblock 16 246 324 minecraft:yellow_terracotta
setblock 17 246 323 minecraft:yellow_terracotta
fill 17 246 324 17 249 324 minecraft:honeycomb_block
setblock 17 246 363 minecraft:yellow_terracotta
fill 18 246 323 18 249 323 minecraft:honeycomb_block
setblock 18 246 362 minecraft:yellow_terracotta
fill 18 246 363 18 249 363 minecraft:honeycomb_block
setblock 19 246 361 minecraft:yellow_terracotta
fill 19 246 362 19 249 362 minecraft:honeycomb_block
setblock 22 246 323 minecraft:yellow_terracotta
setblock 22 246 363 minecraft:yellow_terracotta
setblock 23 246 362 minecraft:yellow_terracotta
fill 23 246 363 23 249 363 minecraft:honeycomb_block
fill 24 246 362 27 246 362 minecraft:honeycomb_block
setblock 25 246 323 minecraft:honey_block
setblock 27 246 363 minecraft:yellow_terracotta
setblock 28 246 362 minecraft:yellow_terracotta
fill 28 246 363 28 249 363 minecraft:honeycomb_block
fill 29 246 362 29 249 362 minecraft:honeycomb_block
fill 30 246 361 30 249 361 minecraft:honeycomb_block
setblock 31 246 323 minecraft:honeycomb_block
setblock 32 246 323 minecraft:yellow_terracotta
setblock 32 246 363 minecraft:yellow_terracotta
fill 33 246 323 33 249 323 minecraft:honeycomb_block
fill 33 246 360 34 246 360 minecraft:honeycomb_block
setblock 33 246 362 minecraft:yellow_terracotta
fill 33 246 363 33 249 363 minecraft:honeycomb_block
setblock 34 246 361 minecraft:yellow_terracotta
fill 34 246 362 34 249 362 minecraft:honeycomb_block
setblock 35 246 360 minecraft:yellow_terracotta
fill 35 246 361 35 249 361 minecraft:honeycomb_block
setblock 36 246 323 minecraft:honeycomb_block
setblock 37 246 363 minecraft:yellow_terracotta
setblock 38 246 362 minecraft:yellow_terracotta
fill 38 246 363 38 249 363 minecraft:honeycomb_block
fill 39 246 362 39 249 362 minecraft:honeycomb_block
setblock 40 246 340 minecraft:yellow_terracotta
fill 40 246 341 40 249 341 minecraft:honeycomb_block
setblock 40 246 344 minecraft:honeycomb_block
setblock 40 246 356 minecraft:honeycomb_block
setblock 40 246 360 minecraft:yellow_terracotta
fill 40 246 361 40 248 361 minecraft:honeycomb_block
setblock 41 246 326 minecraft:honey_block
fill 41 246 335 41 249 335 minecraft:honeycomb_block
setblock 41 246 339 minecraft:yellow_terracotta
fill 41 246 340 41 249 340 minecraft:honeycomb_block
setblock 41 246 344 minecraft:yellow_terracotta
fill 41 246 345 41 249 345 minecraft:honeycomb_block
setblock 41 246 351 minecraft:honey_block
setblock 41 246 354 minecraft:yellow_terracotta
fill 41 246 355 41 247 355 minecraft:honeycomb_block
setblock 41 246 359 minecraft:yellow_terracotta
fill 41 246 360 41 249 360 minecraft:honeycomb_block
fill 42 246 327 42 308 327 minecraft:honeycomb_block
fill 0 247 335 0 308 335 minecraft:honeycomb_block
fill 0 247 346 0 283 346 minecraft:honeycomb_block
setblock 1 247 333 minecraft:yellow_terracotta
fill 1 247 334 1 250 334 minecraft:honeycomb_block
setblock 1 247 338 minecraft:yellow_terracotta
fill 1 247 339 1 250 339 minecraft:honeycomb_block
setblock 1 247 343 minecraft:yellow_terracotta
fill 1 247 344 1 250 344 minecraft:honeycomb_block
setblock 2 247 337 minecraft:yellow_terracotta
fill 2 247 338 2 250 338 minecraft:honeycomb_block
setblock 2 247 342 minecraft:yellow_terracotta
setblock 3 247 325 minecraft:light[level=15]
setblock 3 247 333 minecraft:light[level=15]
setblock 3 247 341 minecraft:light[level=15]
setblock 3 247 349 minecraft:light[level=15]
setblock 3 247 357 minecraft:light[level=15]
setblock 4 247 363 minecraft:honey_block
fill 7 247 323 8 249 323 minecraft:honeycomb_block
fill 8 247 363 10 247 363 minecraft:honeycomb_block
setblock 10 247 324 minecraft:yellow_terracotta
fill 10 247 362 11 247 362 minecraft:honeycomb_block
fill 11 247 322 11 269 322 minecraft:honeycomb_block
setblock 11 247 323 minecraft:yellow_terracotta
fill 11 247 324 11 250 324 minecraft:honeycomb_block
setblock 11 247 325 minecraft:light[level=15]
setblock 11 247 333 minecraft:light[level=15]
setblock 11 247 341 minecraft:light[level=15]
setblock 11 247 349 minecraft:light[level=15]
setblock 11 247 357 minecraft:light[level=15]
setblock 11 247 363 minecraft:yellow_terracotta
fill 12 247 323 12 250 323 minecraft:honeycomb_block
setblock 12 247 362 minecraft:yellow_terracotta
fill 12 247 363 12 250 363 minecraft:honeycomb_block
setblock 13 247 361 minecraft:yellow_terracotta
fill 13 247 362 13 250 362 minecraft:honeycomb_block
fill 14 247 361 14 250 361 minecraft:honeycomb_block
setblock 15 247 324 minecraft:yellow_terracotta
setblock 16 247 323 minecraft:yellow_terracotta
fill 16 247 324 16 250 324 minecraft:honeycomb_block
setblock 16 247 363 minecraft:yellow_terracotta
fill 17 247 323 17 250 323 minecraft:honeycomb_block
setblock 17 247 361 minecraft:honeycomb_block
setblock 17 247 362 minecraft:yellow_terracotta
fill 17 247 363 17 250 363 minecraft:honeycomb_block
setblock 18 247 361 minecraft:yellow_terracotta
fill 18 247 362 18 250 362 minecraft:honeycomb_block
setblock 19 247 324 minecraft:honeycomb_block
setblock 19 247 325 minecraft:light[level=15]
setblock 19 247 333 minecraft:light[level=15]
setblock 19 247 341 minecraft:light[level=15]
setblock 19 247 349 minecraft:light[level=15]
setblock 19 247 357 minecraft:light[level=15]
fill 19 247 361 19 250 361 minecraft:honeycomb_block
setblock 21 247 323 minecraft:yellow_terracotta
setblock 21 247 363 minecraft:yellow_terracotta
fill 22 247 323 23 249 323 minecraft:honeycomb_block
setblock 22 247 362 minecraft:yellow_terracotta
fill 22 247 363 22 250 363 minecraft:honeycomb_block
fill 23 247 362 26 247 362 minecraft:honeycomb_block
setblock 26 247 363 minecraft:yellow_terracotta
setblock 27 247 325 minecraft:light[level=15]
setblock 27 247 333 minecraft:light[level=15]
setblock 27 247 341 minecraft:light[level=15]
setblock 27 247 349 minecraft:light[level=15]
setblock 27 247 357 minecraft:light[level=15]
setblock 27 247 362 minecraft:yellow_terracotta
fill 27 247 363 27 250 363 minecraft:honeycomb_block
setblock 28 247 361 minecraft:yellow_terracotta
fill 28 247 362 28 250 362 minecraft:honeycomb_block
fill 29 247 323 30 247 323 minecraft:honeycomb_block
fill 29 247 361 29 250 361 minecraft:honeycomb_block
setblock 31 247 323 minecraft:yellow_terracotta
setblock 31 247 363 minecraft:yellow_terracotta
fill 32 247 323 32 250 323 minecraft:honeycomb_block
fill 32 247 360 33 247 360 minecraft:honeycomb_block
setblock 32 247 362 minecraft:yellow_terracotta
fill 32 247 363 32 250 363 minecraft:honeycomb_block
setblock 33 247 361 minecraft:yellow_terracotta
fill 33 247 362 33 250 362 minecraft:honeycomb_block
setblock 34 247 360 minecraft:yellow_terracotta
fill 34 247 361 34 250 361 minecraft:honeycomb_block
setblock 35 247 325 minecraft:light[level=15]
setblock 35 247 333 minecraft:light[level=15]
setblock 35 247 341 minecraft:light[level=15]
setblock 35 247 357 minecraft:light[level=15]
fill 35 247 360 35 249 360 minecraft:honeycomb_block
setblock 36 247 323 minecraft:yellow_terracotta
setblock 36 247 363 minecraft:yellow_terracotta
fill 37 247 323 37 250 323 minecraft:honeycomb_block
setblock 37 247 362 minecraft:yellow_terracotta
fill 37 247 363 37 250 363 minecraft:honeycomb_block
setblock 38 247 323 minecraft:honey_block
setblock 38 247 361 minecraft:yellow_terracotta
fill 38 247 362 38 250 362 minecraft:honeycomb_block
setblock 39 247 340 minecraft:yellow_terracotta
fill 39 247 341 39 249 342 minecraft:honeycomb_block
setblock 40 247 339 minecraft:yellow_terracotta
fill 40 247 340 40 250 340 minecraft:honeycomb_block
setblock 40 247 344 minecraft:yellow_terracotta
fill 40 247 345 40 250 345 minecraft:honeycomb_block
setblock 40 247 359 minecraft:yellow_terracotta
fill 40 247 360 40 248 360 minecraft:honeycomb_block
setblock 41 247 338 minecraft:yellow_terracotta
fill 41 247 339 41 250 339 minecraft:honeycomb_block
setblock 41 247 343 minecraft:yellow_terracotta
fill 41 247 344 41 250 344 minecraft:honeycomb_block
setblock 41 247 348 minecraft:yellow_terracotta
setblock 41 247 354 minecraft:honeycomb_block
setblock 41 247 358 minecraft:yellow_terracotta
fill 41 247 359 41 250 359 minecraft:honeycomb_block
setblock 41 247 363 minecraft:yellow_terracotta
setblock 1 248 328 minecraft:honey_block
fill 1 248 333 1 251 333 minecraft:honeycomb_block
setblock 1 248 337 minecraft:yellow_terracotta
fill 1 248 338 1 251 338 minecraft:honeycomb_block
setblock 1 248 342 minecraft:yellow_terracotta
fill 1 248 343 2 250 343 minecraft:honeycomb_block
setblock 1 248 346 minecraft:honeycomb_block
setblock 1 248 347 minecraft:honey_block
setblock 2 248 336 minecraft:yellow_terracotta
fill 2 248 337 2 251 337 minecraft:honeycomb_block
setblock 2 248 341 minecraft:yellow_terracotta
fill 2 248 342 2 251 342 minecraft:honeycomb_block
setblock 5 248 323 minecraft:yellow_terracotta
fill 6 248 323 6 251 323 minecraft:honeycomb_block
fill 6 248 363 9 248 363 minecraft:honeycomb_block
setblock 8 248 324 minecraft:honeycomb_block
setblock 9 248 324 minecraft:yellow_terracotta
fill 9 248 362 10 248 362 minecraft:honeycomb_block
setblock 10 248 323 minecraft:yellow_terracotta
fill 10 248 324 10 251 324 minecraft:honeycomb_block
setblock 10 248 363 minecraft:yellow_terracotta
fill 11 248 323 11 251 323 minecraft:honeycomb_block
setblock 11 248 362 minecraft:yellow_terracotta
fill 11 248 363 11 251 363 minecraft:honeycomb_block
setblock 12 248 325 minecraft:honeycomb_block
setblock 12 248 361 minecraft:yellow_terracotta
fill 12 248 362 12 251 362 minecraft:honeycomb_block
setblock 13 248 325 minecraft:yellow_terracotta
fill 13 248 361 13 251 361 minecraft:honeycomb_block
setblock 14 248 324 minecraft:yellow_terracotta
fill 14 248 325 16 249 325 minecraft:honeycomb_block
setblock 15 248 323 minecraft:yellow_terracotta
fill 15 248 324 15 251 324 minecraft:honeycomb_block
setblock 15 248 363 minecraft:yellow_terracotta
fill 16 248 323 16 251 323 minecraft:honeycomb_block
setblock 16 248 362 minecraft:yellow_terracotta
fill 16 248 363 16 251 363 minecraft:honeycomb_block
setblock 17 248 361 minecraft:yellow_terracotta
fill 17 248 362 17 251 362 minecraft:honeycomb_block
fill 18 248 361 18 251 361 minecraft:honeycomb_block
setblock 19 248 324 minecraft:yellow_terracotta
setblock 20 248 322 minecraft:yellow_concrete
setblock 20 248 323 minecraft:yellow_terracotta
fill 20 248 361 20 249 361 minecraft:honeycomb_block
setblock 20 248 363 minecraft:yellow_terracotta
fill 21 248 323 21 251 323 minecraft:honeycomb_block
setblock 21 248 362 minecraft:yellow_terracotta
fill 21 248 363 21 251 363 minecraft:honeycomb_block
fill 22 248 362 25 248 362 minecraft:honeycomb_block
setblock 24 248 323 minecraft:honeycomb_block
setblock 25 248 323 minecraft:yellow_terracotta
setblock 25 248 363 minecraft:yellow_terracotta
fill 26 248 323 29 248 323 minecraft:honeycomb_block
setblock 26 248 362 minecraft:yellow_terracotta
fill 26 248 363 26 251 363 minecraft:honeycomb_block
setblock 27 248 361 minecraft:yellow_terracotta
fill 27 248 362 27 251 362 minecraft:honeycomb_block
fill 28 248 361 28 251 361 minecraft:honeycomb_block
setblock 30 248 323 minecraft:yellow_terracotta
setblock 30 248 363 minecraft:yellow_terracotta
fill 31 248 323 31 251 323 minecraft:honeycomb_block
fill 31 248 360 32 248 360 minecraft:honeycomb_block
setblock 31 248 362 minecraft:yellow_terracotta
fill 31 248 363 31 251 363 minecraft:honeycomb_block
setblock 32 248 361 minecraft:yellow_terracotta
fill 32 248 362 32 251 362 minecraft:honeycomb_block
setblock 33 248 360 minecraft:yellow_terracotta
fill 33 248 361 33 251 361 minecraft:honeycomb_block
setblock 34 248 323 minecraft:honeycomb_block
fill 34 248 360 34 250 360 minecraft:honeycomb_block
setblock 35 248 323 minecraft:yellow_terracotta
setblock 35 248 363 minecraft:yellow_terracotta
fill 36 248 323 36 251 323 minecraft:honeycomb_block
setblock 36 248 362 minecraft:yellow_terracotta
fill 36 248 363 36 251 363 minecraft:honeycomb_block
setblock 37 248 361 minecraft:yellow_terracotta
fill 37 248 362 37 251 362 minecraft:honeycomb_block
fill 38 248 323 38 249 323 minecraft:honeycomb_block
setblock 38 248 361 minecraft:honeycomb_block
setblock 39 248 339 minecraft:yellow_terracotta
fill 39 248 340 39 251 340 minecraft:honeycomb_block
setblock 39 248 343 minecraft:honeycomb_block
setblock 40 248 338 minecraft:yellow_terracotta
fill 40 248 339 40 251 339 minecraft:honeycomb_block
setblock 40 248 343 minecraft:yellow_terracotta
fill 40 248 344 40 251 344 minecraft:honeycomb_block
fill 40 248 346 40 249 346 minecraft:honeycomb_block
setblock 40 248 359 minecraft:honeycomb_block
setblock 40 248 363 minecraft:yellow_terracotta
setblock 41 248 337 minecraft:yellow_terracotta
fill 41 248 338 41 251 338 minecraft:honeycomb_block
setblock 41 248 342 minecraft:yellow_terracotta
fill 41 248 343 41 251 343 minecraft:honeycomb_block
setblock 41 248 347 minecraft:yellow_terracotta
fill 41 248 348 41 250 349 minecraft:honeycomb_block
setblock 41 248 357 minecraft:yellow_terracotta
fill 41 248 358 41 250 358 minecraft:honeycomb_block
setblock 41 248 362 minecraft:yellow_terracotta
fill 41 248 363 41 251 363 minecraft:honeycomb_block
setblock 42 248 335 minecraft:yellow_terracotta
setblock 0 249 340 minecraft:yellow_terracotta
setblock 0 249 345 minecraft:yellow_concrete
setblock 0 249 363 minecraft:yellow_concrete
fill 1 249 323 3 249 323 minecraft:honeycomb_block
setblock 1 249 336 minecraft:yellow_terracotta
fill 1 249 337 1 252 337 minecraft:honeycomb_block
setblock 1 249 341 minecraft:yellow_terracotta
fill 1 249 342 1 252 342 minecraft:honeycomb_block
setblock 1 249 346 minecraft:yellow_terracotta
setblock 1 249 353 minecraft:honey_block
setblock 2 249 336 minecraft:honeycomb_block
setblock 2 249 340 minecraft:yellow_terracotta
fill 2 249 341 2 252 341 minecraft:honeycomb_block
setblock 3 249 325 minecraft:light[level=12]
setblock 3 249 332 minecraft:light[level=12]
setblock 3 249 339 minecraft:light[level=12]
setblock 3 249 346 minecraft:light[level=12]
setblock 3 249 353 minecraft:light[level=12]
setblock 3 249 360 minecraft:light[level=12]
setblock 4 249 323 minecraft:yellow_terracotta
fill 5 249 323 5 252 323 minecraft:honeycomb_block
fill 5 249 363 8 249 363 minecraft:honeycomb_block
setblock 7 249 324 minecraft:honeycomb_block
setblock 8 249 324 minecraft:yellow_terracotta
fill 8 249 362 9 249 362 minecraft:honeycomb_block
setblock 9 249 323 minecraft:yellow_terracotta
fill 9 249 324 9 252 324 minecraft:honeycomb_block
setblock 9 249 363 minecraft:yellow_terracotta
fill 10 249 323 10 252 323 minecraft:honeycomb_block
fill 10 249 325 11 249 325 minecraft:honeycomb_block
setblock 10 249 332 minecraft:light[level=12]
setblock 10 249 339 minecraft:light[level=12]
setblock 10 249 346 minecraft:light[level=12]
setblock 10 249 353 minecraft:light[level=12]
setblock 10 249 360 minecraft:light[level=12]
setblock 10 249 362 minecraft:yellow_terracotta
fill 10 249 363 10 252 363 minecraft:honeycomb_block
setblock 11 249 361 minecraft:yellow_terracotta
fill 11 249 362 11 252 362 minecraft:honeycomb_block
setblock 12 249 325 minecraft:yellow_terracotta
fill 12 249 361 12 252 361 minecraft:honeycomb_block
setblock 13 249 324 minecraft:yellow_terracotta
fill 13 249 325 13 252 325 minecraft:honeycomb_block
setblock 14 249 323 minecraft:yellow_terracotta
fill 14 249 324 14 252 324 minecraft:honeycomb_block
setblock 14 249 363 minecraft:yellow_terracotta
fill 15 249 323 15 252 323 minecraft:honeycomb_block
setblock 15 249 362 minecraft:yellow_terracotta
fill 15 249 363 15 252 363 minecraft:honeycomb_block
setblock 16 249 361 minecraft:yellow_terracotta
fill 16 249 362 16 252 362 minecraft:honeycomb_block
setblock 17 249 325 minecraft:yellow_terracotta
setblock 17 249 332 minecraft:light[level=12]
setblock 17 249 339 minecraft:light[level=12]
setblock 17 249 346 minecraft:light[level=12]
setblock 17 249 353 minecraft:light[level=12]
setblock 17 249 360 minecraft:light[level=12]
fill 17 249 361 17 252 361 minecraft:honeycomb_block
setblock 18 249 324 minecraft:yellow_terracotta
setblock 19 249 323 minecraft:yellow_terracotta
fill 19 249 324 20 251 324 minecraft:honeycomb_block
setblock 19 249 363 minecraft:yellow_terracotta
fill 20 249 322 20 252 323 minecraft:honeycomb_block
setblock 20 249 362 minecraft:yellow_terracotta
fill 20 249 363 20 252 363 minecraft:honeycomb_block
fill 21 249 362 24 249 362 minecraft:honeycomb_block
setblock 24 249 323 minecraft:yellow_terracotta
setblock 24 249 325 minecraft:light[level=12]
setblock 24 249 332 minecraft:light[level=12]
setblock 24 249 339 minecraft:light[level=12]
setblock 24 249 346 minecraft:light[level=12]
setblock 24 249 353 minecraft:light[level=12]
setblock 24 249 360 minecraft:light[level=12]
setblock 24 249 363 minecraft:yellow_terracotta
fill 25 249 323 28 249 323 minecraft:honeycomb_block
setblock 25 249 362 minecraft:yellow_terracotta
fill 25 249 363 25 252 363 minecraft:honeycomb_block
setblock 26 249 361 minecraft:yellow_terracotta
fill 26 249 362 26 252 362 minecraft:honeycomb_block
fill 27 249 361 27 252 361 minecraft:honeycomb_block
setblock 29 249 323 minecraft:yellow_terracotta
setblock 29 249 363 minecraft:yellow_terracotta
fill 30 249 323 30 252 323 minecraft:honeycomb_block
fill 30 249 360 31 249 360 minecraft:honeycomb_block
setblock 30 249 362 minecraft:yellow_terracotta
fill 30 249 363 30 252 363 minecraft:honeycomb_block
fill 31 249 324 32 249 324 minecraft:honeycomb_block
setblock 31 249 325 minecraft:light[level=12]
setblock 31 249 332 minecraft:light[level=12]
setblock 31 249 339 minecraft:light[level=12]
setblock 31 249 346 minecraft:light[level=12]
setblock 31 249 353 minecraft:light[level=12]
setblock 31 249 361 minecraft:yellow_terracotta
fill 31 249 362 31 252 362 minecraft:honeycomb_block
setblock 32 249 360 minecraft:yellow_terracotta
fill 32 249 361 32 252 361 minecraft:honeycomb_block
setblock 33 249 324 minecraft:yellow_terracotta
fill 33 249 360 33 251 360 minecraft:honeycomb_block
setblock 34 249 323 minecraft:yellow_terracotta
fill 34 249 324 34 252 324 minecraft:honeycomb_block
setblock 34 249 363 minecraft:yellow_terracotta
fill 35 249 323 35 252 323 minecraft:honeycomb_block
setblock 35 249 362 minecraft:yellow_terracotta
fill 35 249 363 35 252 363 minecraft:honeycomb_block
setblock 35 249 364 minecraft:yellow_terracotta
setblock 36 249 361 minecraft:yellow_terracotta
fill 36 249 362 36 252 362 minecraft:honeycomb_block
fill 37 249 361 37 250 361 minecraft:honeycomb_block
setblock 38 249 325 minecraft:light[level=12]
setblock 38 249 332 minecraft:light[level=12]
setblock 38 249 339 minecraft:light[level=12]
setblock 38 249 346 minecraft:light[level=12]
setblock 38 249 353 minecraft:light[level=12]
setblock 38 249 360 minecraft:light[level=12]
fill 39 249 339 39 250 339 minecraft:honeycomb_block
setblock 39 249 343 minecraft:yellow_terracotta
fill 39 249 344 39 251 345 minecraft:honeycomb_block
setblock 39 249 363 minecraft:yellow_terracotta
setblock 39 249 364 minecraft:yellow_concrete
setblock 40 249 337 minecraft:yellow_terracotta
fill 40 249 338 40 252 338 minecraft:honeycomb_block
setblock 40 249 342 minecraft:yellow_terracotta
fill 40 249 343 40 252 343 minecraft:honeycomb_block
setblock 40 249 347 minecraft:yellow_terracotta
fill 40 249 363 40 252 363 minecraft:honeycomb_block
setblock 41 249 333 minecraft:honey_block
setblock 41 249 336 minecraft:yellow_terracotta
fill 41 249 337 41 252 337 minecraft:honeycomb_block
fill 41 249 341 42 249 341 minecraft:yellow_terracotta
fill 41 249 342 41 252 342 minecraft:honeycomb_block
setblock 41 249 346 minecraft:yellow_terracotta
fill 41 249 347 41 252 347 minecraft:honeycomb_block
setblock 41 249 352 minecraft:honey_block
setblock 41 249 357 minecraft:honeycomb_block
setblock 41 249 361 minecraft:yellow_terracotta
fill 41 249 362 41 252 362 minecraft:honeycomb_block
fill 42 249 335 42 260 335 minecraft:honeycomb_block
setblock 42 249 360 minecraft:yellow_terracotta
fill 0 250 340 0 308 340 minecraft:honeycomb_block
fill 0 250 345 0 292 345 minecraft:honeycomb_block
fill 0 250 363 2 250 363 minecraft:honeycomb_block
fill 1 250 323 1 250 324 minecraft:honeycomb_block
setblock 1 250 325 minecraft:yellow_terracotta
fill 1 250 326 1 253 326 minecraft:honeycomb_block
setblock 1 250 335 minecraft:yellow_terracotta
fill 1 250 336 1 253 336 minecraft:honeycomb_block
setblock 1 250 340 minecraft:yellow_terracotta
fill 1 250 341 1 253 341 minecraft:honeycomb_block
setblock 1 250 345 minecraft:yellow_terracotta
fill 1 250 346 1 252 347 minecraft:honeycomb_block
setblock 1 250 359 minecraft:honey_block
setblock 1 250 364 minecraft:yellow_concrete
setblock 2 250 323 minecraft:honeycomb_block
setblock 2 250 339 minecraft:yellow_terracotta
fill 2 250 340 2 253 340 minecraft:honeycomb_block
setblock 2 250 344 minecraft:yellow_terracotta
setblock 3 250 323 minecraft:yellow_terracotta
setblock 3 250 363 minecraft:yellow_terracotta
fill 4 250 323 4 253 323 minecraft:honeycomb_block
fill 4 250 363 7 250 363 minecraft:honeycomb_block
fill 5 250 324 6 250 324 minecraft:honeycomb_block
setblock 7 250 323 minecraft:honeycomb_block
setblock 7 250 324 minecraft:yellow_terracotta
fill 7 250 362 8 250 362 minecraft:honeycomb_block
setblock 8 250 323 minecraft:yellow_terracotta
fill 8 250 324 8 252 325 minecraft:honeycomb_block
setblock 8 250 363 minecraft:yellow_terracotta
fill 9 250 323 9 253 323 minecraft:honeycomb_block
fill 9 250 325 10 250 325 minecraft:honeycomb_block
setblock 9 250 362 minecraft:yellow_terracotta
fill 9 250 363 9 253 363 minecraft:honeycomb_block
setblock 10 250 361 minecraft:yellow_terracotta
fill 10 250 362 10 253 362 minecraft:honeycomb_block
setblock 11 250 325 minecraft:yellow_terracotta
fill 11 250 361 11 253 361 minecraft:honeycomb_block
setblock 12 250 324 minecraft:yellow_terracotta
fill 12 250 325 12 253 325 minecraft:honeycomb_block
fill 13 250 322 13 305 322 minecraft:honeycomb_block
setblock 13 250 323 minecraft:yellow_terracotta
fill 13 250 324 13 253 324 minecraft:honeycomb_block
setblock 13 250 363 minecraft:yellow_terracotta
fill 14 250 323 14 253 323 minecraft:honeycomb_block
fill 14 250 325 15 250 325 minecraft:honeycomb_block
setblock 14 250 362 minecraft:yellow_terracotta
fill 14 250 363 14 253 363 minecraft:honeycomb_block
fill 15 250 353 15 251 354 minecraft:black_concrete
setblock 15 250 361 minecraft:yellow_terracotta
fill 15 250 362 15 253 362 minecraft:honeycomb_block
setblock 16 250 325 minecraft:yellow_terracotta
fill 16 250 361 16 253 361 minecraft:honeycomb_block
setblock 17 250 324 minecraft:yellow_terracotta
fill 17 250 325 17 253 325 minecraft:honeycomb_block
setblock 18 250 323 minecraft:yellow_terracotta
fill 18 250 324 18 253 324 minecraft:honeycomb_block
setblock 18 250 363 minecraft:yellow_terracotta
fill 19 250 323 19 253 323 minecraft:honeycomb_block
setblock 19 250 362 minecraft:yellow_terracotta
fill 19 250 363 19 253 363 minecraft:honeycomb_block
setblock 20 250 361 minecraft:yellow_terracotta
fill 20 250 362 23 250 362 minecraft:honeycomb_block
setblock 21 250 324 minecraft:honeycomb_block
setblock 22 250 323 minecraft:honeycomb_block
setblock 23 250 323 minecraft:yellow_terracotta
setblock 23 250 363 minecraft:yellow_terracotta
fill 24 250 323 27 250 323 minecraft:honeycomb_block
setblock 24 250 362 minecraft:yellow_terracotta
fill 24 250 363 24 253 363 minecraft:honeycomb_block
setblock 25 250 361 minecraft:yellow_terracotta
fill 25 250 362 25 253 362 minecraft:honeycomb_block
fill 26 250 361 26 253 361 minecraft:honeycomb_block
setblock 28 250 323 minecraft:yellow_terracotta
fill 28 250 324 31 250 324 minecraft:honeycomb_block
setblock 28 250 363 minecraft:yellow_terracotta
fill 29 250 323 29 253 323 minecraft:honeycomb_block
fill 29 250 360 30 250 360 minecraft:honeycomb_block
setblock 29 250 362 minecraft:yellow_terracotta
fill 29 250 363 29 253 363 minecraft:honeycomb_block
setblock 30 250 361 minecraft:yellow_terracotta
fill 30 250 362 30 253 362 minecraft:honeycomb_block
setblock 31 250 360 minecraft:yellow_terracotta
fill 31 250 361 31 253 361 minecraft:honeycomb_block
setblock 32 250 324 minecraft:yellow_terracotta
fill 32 250 360 32 252 360 minecraft:honeycomb_block
setblock 33 250 323 minecraft:yellow_terracotta
fill 33 250 324 33 253 324 minecraft:honeycomb_block
setblock 33 250 363 minecraft:yellow_terracotta
fill 34 250 323 34 253 323 minecraft:honeycomb_block
setblock 34 250 362 minecraft:yellow_terracotta
fill 34 250 363 34 253 363 minecraft:honeycomb_block
fill 35 250 324 35 251 324 minecraft:honeycomb_block
setblock 35 250 361 minecraft:yellow_terracotta
fill 35 250 362 35 253 362 minecraft:honeycomb_block
fill 35 250 364 35 308 364 minecraft:honeycomb_block
fill 36 250 361 36 251 361 minecraft:honeycomb_block
setblock 38 250 323 minecraft:yellow_terracotta
setblock 38 250 363 minecraft:yellow_terracotta
fill 39 250 323 39 253 323 minecraft:honeycomb_block
setblock 39 250 341 minecraft:honeycomb_block
setblock 39 250 342 minecraft:yellow_terracotta
fill 39 250 343 39 253 343 minecraft:honeycomb_block
setblock 39 250 346 minecraft:honeycomb_block
setblock 39 250 362 minecraft:yellow_terracotta
fill 39 250 363 39 253 364 minecraft:honeycomb_block
setblock 40 250 337 minecraft:honeycomb_block
setblock 40 250 341 minecraft:yellow_terracotta
fill 40 250 342 40 253 342 minecraft:honeycomb_block
setblock 40 250 346 minecraft:yellow_terracotta
fill 40 250 347 40 252 348 minecraft:honeycomb_block
setblock 41 250 327 minecraft:honey_block
setblock 41 250 335 minecraft:yellow_terracotta
fill 41 250 336 41 253 336 minecraft:honeycomb_block
setblock 41 250 340 minecraft:yellow_terracotta
fill 41 250 341 42 253 341 minecraft:honeycomb_block
setblock 41 250 345 minecraft:yellow_terracotta
fill 41 250 346 41 253 346 minecraft:honeycomb_block
setblock 41 250 350 minecraft:yellow_terracotta
setblock 41 250 360 minecraft:yellow_terracotta
fill 41 250 361 41 251 361 minecraft:honeycomb_block
fill 42 250 360 42 272 360 minecraft:honeycomb_block
setblock 0 251 339 minecraft:orange_terracotta
fill 0 251 363 1 251 363 minecraft:honeycomb_block
setblock 1 251 323 minecraft:honeycomb_block
setblock 1 251 324 minecraft:yellow_terracotta
fill 1 251 325 1 254 325 minecraft:honeycomb_block
fill 1 251 327 1 251 328 minecraft:honeycomb_block
setblock 1 251 334 minecraft:yellow_terracotta
fill 1 251 335 1 253 335 minecraft:honeycomb_block
setblock 1 251 339 minecraft:yellow_terracotta
fill 1 251 340 1 254 340 minecraft:honeycomb_block
setblock 1 251 343 minecraft:honeycomb_block
setblock 1 251 344 minecraft:yellow_terracotta
fill 1 251 345 2 253 345 minecraft:honeycomb_block
fill 1 251 364 1 308 364 minecraft:honeycomb_block
setblock 2 251 323 minecraft:yellow_terracotta
setblock 2 251 338 minecraft:yellow_terracotta
fill 2 251 339 2 253 339 minecraft:honeycomb_block
setblock 2 251 343 minecraft:yellow_terracotta
fill 2 251 344 2 254 344 minecraft:honeycomb_block
setblock 2 251 363 minecraft:yellow_terracotta
fill 3 251 323 3 253 324 minecraft:honeycomb_block
fill 3 251 363 6 251 363 minecraft:honeycomb_block
fill 4 251 324 5 251 324 minecraft:honeycomb_block
setblock 6 251 324 minecraft:yellow_terracotta
fill 6 251 362 7 251 362 minecraft:honeycomb_block
setblock 7 251 323 minecraft:yellow_terracotta
fill 7 251 324 7 253 325 minecraft:honeycomb_block
setblock 7 251 363 minecraft:yellow_terracotta
fill 8 251 323 8 254 323 minecraft:honeycomb_block
setblock 8 251 362 minecraft:yellow_terracotta
fill 8 251 363 8 254 363 minecraft:honeycomb_block
setblock 9 251 325 minecraft:honeycomb_block
setblock 9 251 361 minecraft:yellow_terracotta
fill 9 251 362 9 254 362 minecraft:honeycomb_block
setblock 10 251 325 minecraft:yellow_terracotta
fill 10 251 326 13 251 326 minecraft:honeycomb_block
fill 10 251 361 10 254 361 minecraft:honeycomb_block
setblock 11 251 324 minecraft:yellow_terracotta
fill 11 251 325 11 254 325 minecraft:honeycomb_block
setblock 12 251 323 minecraft:yellow_terracotta
fill 12 251 324 12 254 324 minecraft:honeycomb_block
setblock 12 251 363 minecraft:yellow_terracotta
fill 13 251 323 13 254 323 minecraft:honeycomb_block
setblock 13 251 362 minecraft:yellow_terracotta
fill 13 251 363 13 254 363 minecraft:honeycomb_block
setblock 14 251 325 minecraft:honeycomb_block
setblock 14 251 326 minecraft:yellow_terracotta
setblock 14 251 361 minecraft:yellow_terracotta
fill 14 251 362 14 254 362 minecraft:honeycomb_block
setblock 15 251 325 minecraft:yellow_terracotta
fill 15 251 361 15 253 361 minecraft:honeycomb_block
setblock 16 251 324 minecraft:yellow_terracotta
fill 16 251 325 16 254 325 minecraft:honeycomb_block
setblock 17 251 323 minecraft:yellow_terracotta
fill 17 251 324 17 254 324 minecraft:honeycomb_block
setblock 17 251 363 minecraft:yellow_terracotta
fill 18 251 323 18 254 323 minecraft:honeycomb_block
setblock 18 251 362 minecraft:yellow_terracotta
fill 18 251 363 18 254 363 minecraft:honeycomb_block
setblock 19 251 361 minecraft:yellow_terracotta
fill 19 251 362 22 251 362 minecraft:honeycomb_block
setblock 21 251 324 minecraft:yellow_terracotta
setblock 22 251 323 minecraft:yellow_terracotta
setblock 22 251 363 minecraft:yellow_terracotta
fill 23 251 323 26 251 323 minecraft:honeycomb_block
setblock 23 251 362 minecraft:yellow_terracotta
fill 23 251 363 23 254 363 minecraft:honeycomb_block
setblock 24 251 361 minecraft:yellow_terracotta
fill 24 251 362 24 254 362 minecraft:honeycomb_block
fill 25 251 361 25 253 361 minecraft:honeycomb_block
setblock 26 251 324 minecraft:yellow_terracotta
setblock 27 251 323 minecraft:yellow_terracotta
fill 27 251 324 30 251 324 minecraft:honeycomb_block
setblock 27 251 363 minecraft:yellow_terracotta
fill 28 251 323 28 254 323 minecraft:honeycomb_block
setblock 28 251 362 minecraft:yellow_terracotta
fill 28 251 363 28 254 363 minecraft:honeycomb_block
setblock 29 251 360 minecraft:honeycomb_block
setblock 29 251 361 minecraft:yellow_terracotta
fill 29 251 362 29 254 362 minecraft:honeycomb_block
setblock 30 251 360 minecraft:yellow_terracotta
fill 30 251 361 30 254 361 minecraft:honeycomb_block
setblock 31 251 324 minecraft:yellow_terracotta
fill 31 251 360 31 252 360 minecraft:honeycomb_block
setblock 32 251 323 minecraft:yellow_terracotta
fill 32 251 324 32 254 324 minecraft:honeycomb_block
setblock 32 251 363 minecraft:yellow_terracotta
fill 33 251 323 33 254 323 minecraft:honeycomb_block
setblock 33 251 362 minecraft:yellow_terracotta
fill 33 251 363 33 254 363 minecraft:honeycomb_block
setblock 34 251 361 minecraft:yellow_terracotta
fill 34 251 362 34 254 362 minecraft:honeycomb_block
fill 35 251 361 35 252 361 minecraft:honeycomb_block
setblock 36 251 324 minecraft:yellow_terracotta
setblock 37 251 323 minecraft:yellow_terracotta
setblock 37 251 363 minecraft:yellow_terracotta
fill 38 251 323 38 254 323 minecraft:honeycomb_block
setblock 38 251 362 minecraft:yellow_terracotta
fill 38 251 363 38 254 363 minecraft:honeycomb_block
setblock 39 251 341 minecraft:yellow_terracotta
fill 39 251 342 39 253 342 minecraft:honeycomb_block
setblock 39 251 346 minecraft:yellow_terracotta
fill 40 251 323 40 252 323 minecraft:honeycomb_block
setblock 40 251 340 minecraft:yellow_terracotta
fill 40 251 341 40 254 341 minecraft:honeycomb_block
setblock 40 251 345 minecraft:yellow_terracotta
fill 40 251 346 40 254 346 minecraft:honeycomb_block
setblock 41 251 335 minecraft:honeycomb_block
setblock 41 251 339 minecraft:yellow_terracotta
fill 41 251 340 41 254 340 minecraft:honeycomb_block
setblock 41 251 344 minecraft:yellow_terracotta
fill 41 251 345 41 254 345 minecraft:honeycomb_block
setblock 41 251 348 minecraft:honeycomb_block
setblock 41 251 349 minecraft:yellow_terracotta
fill 41 251 350 41 254 350 minecraft:honeycomb_block
setblock 41 251 360 minecraft:honeycomb_block
setblock 42 251 339 minecraft:yellow_concrete
setblock 42 251 361 minecraft:orange_terracotta
fill 0 252 339 1 255 339 minecraft:honeycomb_block
setblock 0 252 353 minecraft:yellow_concrete
fill 0 252 363 0 308 363 minecraft:honeycomb_block
setblock 1 252 322 minecraft:yellow_concrete
setblock 1 252 323 minecraft:yellow_terracotta
fill 1 252 324 2 254 324 minecraft:honeycomb_block
setblock 1 252 327 minecraft:honeycomb_block
setblock 1 252 328 minecraft:yellow_terracotta
fill 1 252 329 1 254 330 minecraft:honeycomb_block
setblock 1 252 333 minecraft:yellow_terracotta
fill 1 252 334 1 253 334 minecraft:honeycomb_block
setblock 1 252 338 minecraft:yellow_terracotta
setblock 1 252 343 minecraft:yellow_terracotta
fill 1 252 344 1 255 344 minecraft:honeycomb_block
setblock 1 252 348 minecraft:yellow_terracotta
setblock 1 252 352 minecraft:honey_block
setblock 1 252 363 minecraft:yellow_terracotta
fill 2 252 323 2 255 323 minecraft:honeycomb_block
fill 2 252 325 2 253 325 minecraft:honeycomb_block
setblock 2 252 338 minecraft:honeycomb_block
setblock 2 252 342 minecraft:yellow_terracotta
fill 2 252 343 2 254 343 minecraft:honeycomb_block
fill 2 252 363 5 252 363 minecraft:honeycomb_block
setblock 4 252 324 minecraft:honeycomb_block
setblock 5 252 324 minecraft:yellow_terracotta
setblock 6 252 323 minecraft:yellow_terracotta
fill 6 252 324 6 254 325 minecraft:honeycomb_block
setblock 6 252 362 minecraft:honeycomb_block
setblock 6 252 363 minecraft:yellow_terracotta
fill 7 252 323 7 255 323 minecraft:honeycomb_block
setblock 7 252 362 minecraft:yellow_terracotta
fill 7 252 363 7 255 363 minecraft:honeycomb_block
fill 8 252 362 8 255 362 minecraft:honeycomb_block
setblock 9 252 325 minecraft:yellow_terracotta
fill 9 252 326 12 252 326 minecraft:honeycomb_block
fill 9 252 361 9 253 361 minecraft:honeycomb_block
setblock 10 252 324 minecraft:yellow_terracotta
fill 10 252 325 10 255 325 minecraft:honeycomb_block
setblock 11 252 323 minecraft:yellow_terracotta
fill 11 252 324 11 255 324 minecraft:honeycomb_block
setblock 11 252 363 minecraft:yellow_terracotta
fill 12 252 323 12 255 323 minecraft:honeycomb_block
setblock 12 252 362 minecraft:yellow_terracotta
fill 12 252 363 12 255 363 minecraft:honeycomb_block
setblock 13 252 326 minecraft:yellow_terracotta
setblock 13 252 361 minecraft:yellow_terracotta
fill 13 252 362 13 255 362 minecraft:honeycomb_block
setblock 14 252 325 minecraft:yellow_terracotta
fill 14 252 326 14 253 326 minecraft:honeycomb_block
fill 14 252 361 14 254 361 minecraft:honeycomb_block
setblock 15 252 324 minecraft:yellow_terracotta
fill 15 252 325 15 255 325 minecraft:honeycomb_block
setblock 15 252 364 minecraft:yellow_terracotta
setblock 16 252 323 minecraft:yellow_terracotta
fill 16 252 324 16 255 324 minecraft:honeycomb_block
setblock 16 252 363 minecraft:yellow_terracotta
fill 17 252 323 17 255 323 minecraft:honeycomb_block
setblock 17 252 362 minecraft:yellow_terracotta
fill 17 252 363 17 255 363 minecraft:honeycomb_block
setblock 18 252 361 minecraft:yellow_terracotta
fill 18 252 362 21 252 362 minecraft:honeycomb_block
setblock 19 252 324 minecraft:honeycomb_block
setblock 20 252 324 minecraft:yellow_terracotta
setblock 21 252 323 minecraft:yellow_terracotta
fill 21 252 324 24 252 324 minecraft:honeycomb_block
setblock 21 252 363 minecraft:yellow_terracotta
fill 22 252 323 25 252 323 minecraft:honeycomb_block
setblock 22 252 362 minecraft:yellow_terracotta
fill 22 252 363 22 255 363 minecraft:honeycomb_block
fill 23 252 362 23 255 362 minecraft:honeycomb_block
setblock 25 252 324 minecraft:yellow_terracotta
setblock 26 252 323 minecraft:yellow_terracotta
fill 26 252 324 29 252 324 minecraft:honeycomb_block
setblock 26 252 363 minecraft:yellow_terracotta
fill 27 252 323 27 255 323 minecraft:honeycomb_block
setblock 27 252 362 minecraft:yellow_terracotta
fill 27 252 363 27 255 363 minecraft:honeycomb_block
setblock 28 252 361 minecraft:yellow_terracotta
fill 28 252 362 28 255 362 minecraft:honeycomb_block
setblock 29 252 360 minecraft:yellow_terracotta
fill 29 252 361 29 255 361 minecraft:honeycomb_block
setblock 30 252 324 minecraft:yellow_terracotta
setblock 30 252 360 minecraft:honeycomb_block
setblock 31 252 323 minecraft:yellow_terracotta
fill 31 252 324 31 255 324 minecraft:honeycomb_block
setblock 31 252 363 minecraft:yellow_terracotta
fill 32 252 323 32 255 323 minecraft:honeycomb_block
setblock 32 252 362 minecraft:yellow_terracotta
fill 32 252 363 32 255 363 minecraft:honeycomb_block
setblock 33 252 361 minecraft:yellow_terracotta
fill 33 252 362 33 255 362 minecraft:honeycomb_block
fill 34 252 361 34 253 361 minecraft:honeycomb_block
setblock 35 252 324 minecraft:yellow_terracotta
setblock 36 252 323 minecraft:yellow_terracotta
setblock 36 252 324 minecraft:honeycomb_block
setblock 36 252 363 minecraft:yellow_terracotta
fill 37 252 323 37 255 323 minecraft:honeycomb_block
setblock 37 252 362 minecraft:yellow_terracotta
fill 37 252 363 37 254 363 minecraft:honeycomb_block
setblock 38 252 362 minecraft:honeycomb_block
setblock 39 252 340 minecraft:yellow_terracotta
fill 39 252 341 39 253 341 minecraft:honeycomb_block
setblock 39 252 344 minecraft:honeycomb_block
setblock 39 252 345 minecraft:yellow_terracotta
fill 39 252 346 39 254 346 minecraft:honeycomb_block
setblock 40 252 339 minecraft:yellow_terracotta
fill 40 252 340 40 254 340 minecraft:honeycomb_block
setblock 40 252 344 minecraft:yellow_terracotta
fill 40 252 345 40 255 345 minecraft:honeycomb_block
setblock 41 252 323 minecraft:yellow_terracotta
setblock 41 252 334 minecraft:honey_block
setblock 41 252 338 minecraft:yellow_terracotta
fill 41 252 339 42 255 339 minecraft:honeycomb_block
setblock 41 252 343 minecraft:yellow_terracotta
fill 41 252 344 41 255 344 minecraft:honeycomb_block
setblock 41 252 348 minecraft:yellow_terracotta
fill 41 252 349 41 255 349 minecraft:honeycomb_block
setblock 41 252 359 minecraft:honey_block
setblock 41 252 363 minecraft:yellow_terracotta
fill 42 252 361 42 308 361 minecraft:honeycomb_block
fill 0 253 353 0 258 353 minecraft:honeycomb_block
fill 1 253 322 1 256 323 minecraft:honeycomb_block
setblock 1 253 327 minecraft:yellow_terracotta
fill 1 253 328 1 256 328 minecraft:honeycomb_block
setblock 1 253 331 minecraft:honeycomb_block
setblock 1 253 333 minecraft:honey_block
setblock 1 253 337 minecraft:yellow_terracotta
fill 1 253 338 1 255 338 minecraft:honeycomb_block
setblock 1 253 342 minecraft:yellow_terracotta
fill 1 253 343 1 256 343 minecraft:honeycomb_block
setblock 1 253 346 minecraft:honeycomb_block
setblock 1 253 347 minecraft:yellow_terracotta
fill 1 253 348 1 254 348 minecraft:honeycomb_block
setblock 1 253 358 minecraft:honey_block
setblock 2 253 326 minecraft:yellow_terracotta
setblock 2 253 341 minecraft:yellow_terracotta
fill 2 253 342 2 254 342 minecraft:honeycomb_block
fill 2 253 363 4 253 363 minecraft:honeycomb_block
fill 4 253 324 4 253 326 minecraft:yellow_terracotta
setblock 5 253 323 minecraft:yellow_terracotta
fill 5 253 324 5 255 325 minecraft:honeycomb_block
fill 5 253 326 5 260 326 minecraft:yellow_terracotta
setblock 5 253 363 minecraft:yellow_terracotta
fill 6 253 323 6 256 323 minecraft:honeycomb_block
setblock 6 253 362 minecraft:yellow_terracotta
fill 6 253 363 6 256 363 minecraft:honeycomb_block
setblock 6 253 364 minecraft:yellow_concrete
fill 7 253 362 7 256 362 minecraft:honeycomb_block
setblock 8 253 324 minecraft:honeycomb_block
setblock 8 253 325 minecraft:yellow_terracotta
fill 8 253 326 11 253 326 minecraft:honeycomb_block
setblock 9 253 324 minecraft:yellow_terracotta
fill 9 253 325 9 256 325 minecraft:honeycomb_block
setblock 10 253 323 minecraft:yellow_terracotta
fill 10 253 324 10 256 324 minecraft:honeycomb_block
setblock 10 253 363 minecraft:yellow_terracotta
fill 11 253 323 11 256 323 minecraft:honeycomb_block
setblock 11 253 362 minecraft:yellow_terracotta
fill 11 253 363 11 256 363 minecraft:honeycomb_block
setblock 12 253 326 minecraft:yellow_terracotta
setblock 12 253 361 minecraft:yellow_terracotta
fill 12 253 362 12 256 362 minecraft:honeycomb_block
setblock 13 253 325 minecraft:yellow_terracotta
fill 13 253 326 13 254 326 minecraft:honeycomb_block
fill 13 253 361 13 254 361 minecraft:honeycomb_block
setblock 14 253 324 minecraft:yellow_terracotta
fill 14 253 325 14 256 325 minecraft:honeycomb_block
setblock 15 253 323 minecraft:yellow_terracotta
fill 15 253 324 15 256 324 minecraft:honeycomb_block
setblock 15 253 363 minecraft:yellow_terracotta
fill 15 253 364 15 308 364 minecraft:honeycomb_block
fill 16 253 323 16 256 323 minecraft:honeycomb_block
setblock 16 253 362 minecraft:yellow_terracotta
fill 16 253 363 16 256 363 minecraft:honeycomb_block
fill 17 253 362 20 253 362 minecraft:honeycomb_block
setblock 19 253 324 minecraft:yellow_terracotta
fill 20 253 322 20 308 322 minecraft:honeycomb_block
setblock 20 253 323 minecraft:yellow_terracotta
fill 20 253 324 23 253 324 minecraft:honeycomb_block
setblock 20 253 363 minecraft:yellow_terracotta
fill 21 253 323 24 253 323 minecraft:honeycomb_block
setblock 21 253 362 minecraft:yellow_terracotta
fill 21 253 363 21 256 363 minecraft:honeycomb_block
fill 22 253 362 22 255 362 minecraft:honeycomb_block
setblock 24 253 324 minecraft:yellow_terracotta
setblock 25 253 323 minecraft:yellow_terracotta
fill 25 253 324 28 253 324 minecraft:honeycomb_block
setblock 25 253 363 minecraft:yellow_terracotta
fill 26 253 323 26 256 323 minecraft:honeycomb_block
setblock 26 253 362 minecraft:yellow_terracotta
fill 26 253 363 26 256 363 minecraft:honeycomb_block
setblock 27 253 361 minecraft:yellow_terracotta
fill 27 253 362 27 256 362 minecraft:honeycomb_block
fill 28 253 361 28 255 361 minecraft:honeycomb_block
setblock 29 253 324 minecraft:yellow_terracotta
setblock 30 253 323 minecraft:yellow_terracotta
fill 30 253 324 30 256 324 minecraft:honeycomb_block
setblock 30 253 363 minecraft:yellow_terracotta
fill 31 253 323 31 256 323 minecraft:honeycomb_block
setblock 31 253 362 minecraft:yellow_terracotta
fill 31 253 363 31 256 363 minecraft:honeycomb_block
setblock 32 253 361 minecraft:yellow_terracotta
fill 32 253 362 32 256 362 minecraft:honeycomb_block
setblock 33 253 361 minecraft:honeycomb_block
setblock 34 253 324 minecraft:yellow_terracotta
setblock 35 253 323 minecraft:yellow_terracotta
fill 35 253 324 35 254 324 minecraft:honeycomb_block
setblock 35 253 363 minecraft:yellow_terracotta
fill 36 253 323 36 255 323 minecraft:honeycomb_block
setblock 36 253 362 minecraft:yellow_terracotta
fill 36 253 363 36 255 363 minecraft:honeycomb_block
setblock 39 253 344 minecraft:yellow_terracotta
fill 39 253 345 39 254 345 minecraft:honeycomb_block
setblock 40 253 323 minecraft:yellow_terracotta
setblock 40 253 339 minecraft:honeycomb_block
setblock 40 253 343 minecraft:yellow_terracotta
fill 40 253 344 40 256 344 minecraft:honeycomb_block
setblock 40 253 347 minecraft:honeycomb_block
setblock 40 253 348 minecraft:yellow_terracotta
setblock 40 253 363 minecraft:yellow_terracotta
fill 41 253 323 41 254 324 minecraft:honeycomb_block
setblock 41 253 328 minecraft:honey_block
setblock 41 253 337 minecraft:yellow_terracotta
fill 41 253 338 41 255 338 minecraft:honeycomb_block
setblock 41 253 342 minecraft:yellow_terracotta
fill 41 253 343 41 256 343 minecraft:honeycomb_block
setblock 41 253 347 minecraft:yellow_terracotta
fill 41 253 348 41 256 348 minecraft:honeycomb_block
setblock 41 253 353 minecraft:honey_block
setblock 42 253 351 minecraft:yellow_concrete
setblock 1 254 326 minecraft:yellow_terracotta
fill 1 254 327 2 256 327 minecraft:honeycomb_block
setblock 1 254 331 minecraft:yellow_terracotta
setblock 1 254 336 minecraft:yellow_terracotta
setblock 1 254 337 minecraft:honeycomb_block
setblock 1 254 341 minecraft:yellow_terracotta
fill 1 254 342 1 256 342 minecraft:honeycomb_block
setblock 1 254 345 minecraft:honeycomb_block
setblock 1 254 346 minecraft:yellow_terracotta
fill 1 254 347 1 257 347 minecraft:honeycomb_block
setblock 2 254 325 minecraft:yellow_terracotta
fill 2 254 326 2 257 326 minecraft:honeycomb_block
setblock 2 254 341 minecraft:honeycomb_block
setblock 2 254 363 minecraft:honey_block
setblock 3 254 323 minecraft:honeycomb_block
setblock 3 254 324 minecraft:yellow_terracotta
setblock 3 254 363 minecraft:honeycomb_block
setblock 4 254 323 minecraft:yellow_terracotta
fill 4 254 324 4 256 325 minecraft:honeycomb_block
fill 4 254 326 4 261 326 minecraft:yellow_terracotta
setblock 4 254 363 minecraft:yellow_terracotta
fill 5 254 323 5 257 323 minecraft:honeycomb_block
fill 5 254 363 5 257 363 minecraft:honeycomb_block
fill 6 254 362 6 255 362 minecraft:honeycomb_block
fill 6 254 364 6 300 364 minecraft:honeycomb_block
setblock 7 254 324 minecraft:honeycomb_block
setblock 7 254 325 minecraft:yellow_terracotta
fill 7 254 326 10 254 326 minecraft:honeycomb_block
setblock 8 254 324 minecraft:yellow_terracotta
fill 8 254 325 8 257 325 minecraft:honeycomb_block
setblock 9 254 323 minecraft:yellow_terracotta
fill 9 254 324 9 257 324 minecraft:honeycomb_block
setblock 9 254 363 minecraft:yellow_terracotta
fill 10 254 323 10 257 323 minecraft:honeycomb_block
setblock 10 254 362 minecraft:yellow_terracotta
fill 10 254 363 10 257 363 minecraft:honeycomb_block
setblock 11 254 326 minecraft:yellow_terracotta
setblock 11 254 361 minecraft:yellow_terracotta
fill 11 254 362 11 257 362 minecraft:honeycomb_block
setblock 12 254 325 minecraft:yellow_terracotta
fill 12 254 326 12 256 326 minecraft:honeycomb_block
setblock 12 254 361 minecraft:honeycomb_block
setblock 13 254 324 minecraft:yellow_terracotta
fill 13 254 325 13 257 325 minecraft:honeycomb_block
setblock 14 254 323 minecraft:yellow_terracotta
fill 14 254 324 14 257 324 minecraft:honeycomb_block
setblock 14 254 363 minecraft:yellow_terracotta
fill 15 254 323 15 257 323 minecraft:honeycomb_block
setblock 15 254 362 minecraft:yellow_terracotta
fill 15 254 363 15 257 363 minecraft:honeycomb_block
fill 16 254 362 19 254 362 minecraft:honeycomb_block
setblock 18 254 324 minecraft:yellow_terracotta
setblock 19 254 323 minecraft:yellow_terracotta
fill 19 254 324 22 254 324 minecraft:honeycomb_block
setblock 19 254 363 minecraft:yellow_terracotta
fill 20 254 323 23 254 323 minecraft:honeycomb_block
setblock 20 254 362 minecraft:yellow_terracotta
fill 20 254 363 20 257 363 minecraft:honeycomb_block
setblock 21 254 362 minecraft:honeycomb_block
setblock 23 254 324 minecraft:yellow_terracotta
setblock 24 254 323 minecraft:yellow_terracotta
fill 24 254 324 27 254 324 minecraft:honeycomb_block
setblock 24 254 363 minecraft:yellow_terracotta
fill 25 254 323 25 257 323 minecraft:honeycomb_block
setblock 25 254 362 minecraft:yellow_terracotta
fill 25 254 363 25 257 363 minecraft:honeycomb_block
setblock 26 254 361 minecraft:yellow_terracotta
fill 26 254 362 26 257 362 minecraft:honeycomb_block
setblock 27 254 361 minecraft:honeycomb_block
setblock 28 254 324 minecraft:yellow_terracotta
setblock 29 254 323 minecraft:yellow_terracotta
fill 29 254 324 29 257 324 minecraft:honeycomb_block
setblock 29 254 363 minecraft:yellow_terracotta
fill 30 254 323 30 257 323 minecraft:honeycomb_block
setblock 30 254 362 minecraft:yellow_terracotta
fill 30 254 363 30 257 363 minecraft:honeycomb_block
setblock 31 254 361 minecraft:yellow_terracotta
fill 31 254 362 31 256 362 minecraft:honeycomb_block
setblock 32 254 361 minecraft:honeycomb_block
setblock 33 254 324 minecraft:yellow_terracotta
setblock 34 254 323 minecraft:yellow_terracotta
fill 34 254 324 34 255 324 minecraft:honeycomb_block
setblock 34 254 363 minecraft:yellow_terracotta
fill 35 254 323 35 256 323 minecraft:honeycomb_block
setblock 35 254 362 minecraft:yellow_terracotta
fill 35 254 363 35 256 363 minecraft:honeycomb_block
setblock 39 254 323 minecraft:yellow_terracotta
setblock 39 254 343 minecraft:yellow_terracotta
setblock 39 254 344 minecraft:honeycomb_block
fill 39 254 364 39 308 364 minecraft:honeycomb_block
setblock 40 254 323 minecraft:honeycomb_block
setblock 40 254 342 minecraft:yellow_terracotta
fill 40 254 343 40 256 343 minecraft:honeycomb_block
setblock 40 254 347 minecraft:yellow_terracotta
fill 40 254 348 40 255 348 minecraft:honeycomb_block
setblock 41 254 325 minecraft:honeycomb_block
setblock 41 254 337 minecraft:honeycomb_block
setblock 41 254 341 minecraft:yellow_terracotta
fill 41 254 342 41 257 342 minecraft:honeycomb_block
setblock 41 254 346 minecraft:yellow_terracotta
fill 41 254 347 41 257 347 minecraft:honeycomb_block
fill 42 254 341 42 264 341 minecraft:honeycomb_block
fill 42 254 351 42 308 351 minecraft:honeycomb_block
setblock 1 255 324 minecraft:honeycomb_block
setblock 1 255 325 minecraft:yellow_terracotta
fill 1 255 326 1 258 326 minecraft:honeycomb_block
setblock 1 255 329 minecraft:honeycomb_block
setblock 1 255 330 minecraft:yellow_terracotta
fill 1 255 331 1 258 331 minecraft:honeycomb_block
setblock 1 255 340 minecraft:yellow_terracotta
fill 1 255 341 1 256 341 minecraft:honeycomb_block
setblock 1 255 345 minecraft:yellow_terracotta
fill 1 255 346 1 258 346 minecraft:honeycomb_block
setblock 2 255 324 minecraft:yellow_terracotta
fill 2 255 325 2 258 325 minecraft:honeycomb_block
setblock 2 255 328 minecraft:honeycomb_block
fill 2 255 364 3 308 364 minecraft:honeycomb_block
setblock 3 255 323 minecraft:yellow_terracotta
fill 3 255 324 3 258 324 minecraft:honeycomb_block
setblock 3 255 325 minecraft:light[level=15]
setblock 3 255 332 minecraft:light[level=12]
setblock 3 255 333 minecraft:light[level=15]
setblock 3 255 339 minecraft:light[level=12]
setblock 3 255 341 minecraft:light[level=15]
setblock 3 255 346 minecraft:light[level=12]
setblock 3 255 349 minecraft:light[level=15]
setblock 3 255 353 minecraft:light[level=12]
setblock 3 255 357 minecraft:light[level=15]
setblock 3 255 360 minecraft:light[level=12]
setblock 3 255 363 minecraft:yellow_terracotta
fill 4 255 323 4 258 323 minecraft:honeycomb_block
fill 4 255 363 4 258 363 minecraft:honeycomb_block
setblock 4 255 364 minecraft:yellow_terracotta
setblock 6 255 324 minecraft:honeycomb_block
setblock 6 255 325 minecraft:yellow_terracotta
setblock 7 255 324 minecraft:yellow_terracotta
fill 7 255 325 7 257 326 minecraft:honeycomb_block
setblock 8 255 323 minecraft:yellow_terracotta
fill 8 255 324 8 258 324 minecraft:honeycomb_block
fill 8 255 326 9 255 326 minecraft:honeycomb_block
setblock 8 255 363 minecraft:yellow_terracotta
fill 9 255 323 9 258 323 minecraft:honeycomb_block
setblock 9 255 362 minecraft:yellow_terracotta
fill 9 255 363 9 258 363 minecraft:honeycomb_block
setblock 10 255 326 minecraft:yellow_terracotta
setblock 10 255 332 minecraft:light[level=12]
setblock 10 255 339 minecraft:light[level=12]
setblock 10 255 346 minecraft:light[level=12]
setblock 10 255 353 minecraft:light[level=12]
setblock 10 255 360 minecraft:light[level=12]
fill 10 255 362 10 258 362 minecraft:honeycomb_block
setblock 11 255 325 minecraft:yellow_terracotta
fill 11 255 326 11 257 326 minecraft:honeycomb_block
setblock 11 255 333 minecraft:light[level=15]
setblock 11 255 341 minecraft:light[level=15]
setblock 11 255 349 minecraft:light[level=15]
setblock 11 255 357 minecraft:light[level=15]
setblock 12 255 324 minecraft:yellow_terracotta
fill 12 255 325 12 258 325 minecraft:honeycomb_block
setblock 13 255 323 minecraft:yellow_terracotta
fill 13 255 324 13 258 324 minecraft:honeycomb_block
setblock 13 255 363 minecraft:yellow_terracotta
fill 14 255 323 14 258 323 minecraft:honeycomb_block
setblock 14 255 362 minecraft:yellow_terracotta
fill 14 255 363 14 258 363 minecraft:honeycomb_block
fill 15 255 362 18 255 362 minecraft:honeycomb_block
setblock 17 255 324 minecraft:yellow_terracotta
setblock 17 255 325 minecraft:light[level=12]
setblock 17 255 332 minecraft:light[level=12]
setblock 17 255 339 minecraft:light[level=12]
setblock 17 255 346 minecraft:light[level=12]
setblock 17 255 353 minecraft:light[level=12]
setblock 17 255 360 minecraft:light[level=12]
setblock 18 255 323 minecraft:yellow_terracotta
fill 18 255 324 19 255 324 minecraft:honeycomb_block
setblock 18 255 363 minecraft:yellow_terracotta
fill 19 255 323 22 255 323 minecraft:honeycomb_block
setblock 19 255 325 minecraft:light[level=15]
setblock 19 255 333 minecraft:light[level=15]
setblock 19 255 341 minecraft:light[level=15]
setblock 19 255 349 minecraft:light[level=15]
setblock 19 255 357 minecraft:light[level=15]
fill 19 255 363 19 257 363 minecraft:honeycomb_block
setblock 23 255 323 minecraft:yellow_terracotta
setblock 23 255 363 minecraft:yellow_terracotta
fill 24 255 323 24 255 324 minecraft:honeycomb_block
setblock 24 255 325 minecraft:light[level=12]
setblock 24 255 332 minecraft:light[level=12]
setblock 24 255 339 minecraft:light[level=12]
setblock 24 255 346 minecraft:light[level=12]
setblock 24 255 353 minecraft:light[level=12]
setblock 24 255 360 minecraft:light[level=12]
setblock 24 255 362 minecraft:yellow_terracotta
fill 24 255 363 24 258 363 minecraft:honeycomb_block
fill 25 255 324 26 255 324 minecraft:honeycomb_block
fill 25 255 362 25 257 362 minecraft:honeycomb_block
setblock 27 255 324 minecraft:yellow_terracotta
setblock 27 255 325 minecraft:light[level=15]
setblock 27 255 333 minecraft:light[level=15]
setblock 27 255 341 minecraft:light[level=15]
setblock 27 255 349 minecraft:light[level=15]
setblock 27 255 357 minecraft:light[level=15]
setblock 28 255 323 minecraft:yellow_terracotta
fill 28 255 324 28 258 324 minecraft:honeycomb_block
setblock 28 255 363 minecraft:yellow_terracotta
fill 29 255 323 29 258 323 minecraft:honeycomb_block
setblock 29 255 362 minecraft:yellow_terracotta
fill 29 255 363 29 258 363 minecraft:honeycomb_block
setblock 30 255 361 minecraft:yellow_terracotta
fill 30 255 362 30 257 362 minecraft:honeycomb_block
setblock 31 255 325 minecraft:light[level=12]
setblock 31 255 332 minecraft:light[level=12]
setblock 31 255 339 minecraft:light[level=12]
setblock 31 255 346 minecraft:light[level=12]
setblock 31 255 353 minecraft:light[level=12]
setblock 31 255 360 minecraft:light[level=12]
setblock 32 255 324 minecraft:yellow_terracotta
fill 32 255 338 32 256 338 minecraft:ochre_froglight
setblock 33 255 323 minecraft:yellow_terracotta
setblock 33 255 324 minecraft:honeycomb_block
setblock 33 255 363 minecraft:yellow_terracotta
fill 34 255 323 34 257 323 minecraft:honeycomb_block
setblock 34 255 362 minecraft:yellow_terracotta
fill 34 255 363 34 256 363 minecraft:honeycomb_block
setblock 35 255 325 minecraft:light[level=15]
setblock 35 255 333 minecraft:light[level=15]
setblock 35 255 341 minecraft:light[level=15]
setblock 35 255 357 minecraft:light[level=15]
setblock 38 255 325 minecraft:light[level=12]
setblock 38 255 332 minecraft:light[level=12]
setblock 38 255 339 minecraft:light[level=12]
setblock 38 255 346 minecraft:light[level=12]
setblock 38 255 353 minecraft:light[level=12]
setblock 38 255 360 minecraft:light[level=12]
setblock 40 255 341 minecraft:yellow_terracotta
setblock 40 255 342 minecraft:honeycomb_block
setblock 40 255 346 minecraft:yellow_terracotta
fill 40 255 347 40 257 347 minecraft:honeycomb_block
setblock 41 255 324 minecraft:honeycomb_block
setblock 41 255 325 minecraft:yellow_terracotta
fill 41 255 326 41 258 326 minecraft:honeycomb_block
setblock 41 255 335 minecraft:honey_block
setblock 41 255 340 minecraft:yellow_terracotta
fill 41 255 341 41 258 341 minecraft:honeycomb_block
setblock 41 255 345 minecraft:yellow_terracotta
fill 41 255 346 41 258 346 minecraft:honeycomb_block
setblock 41 255 350 minecraft:yellow_terracotta
setblock 41 255 360 minecraft:honey_block
fill 0 256 339 0 305 339 minecraft:honeycomb_block
setblock 1 256 324 minecraft:yellow_terracotta
fill 1 256 325 1 259 325 minecraft:honeycomb_block
setblock 1 256 329 minecraft:yellow_terracotta
fill 1 256 330 1 259 330 minecraft:honeycomb_block
setblock 1 256 332 minecraft:honey_block
setblock 1 256 344 minecraft:yellow_terracotta
fill 1 256 345 1 257 345 minecraft:honeycomb_block
setblock 1 256 351 minecraft:honey_block
fill 1 256 357 1 257 357 minecraft:honey_block
setblock 2 256 323 minecraft:yellow_terracotta
fill 2 256 324 2 259 324 minecraft:honeycomb_block
setblock 2 256 328 minecraft:yellow_terracotta
fill 3 256 323 3 259 323 minecraft:honeycomb_block
fill 4 256 364 4 264 364 minecraft:honeycomb_block
setblock 5 256 324 minecraft:honeycomb_block
setblock 5 256 325 minecraft:yellow_terracotta
fill 5 256 358 5 264 358 minecraft:yellow_terracotta
setblock 6 256 324 minecraft:yellow_terracotta
fill 6 256 325 6 258 326 minecraft:honeycomb_block
setblock 7 256 323 minecraft:yellow_terracotta
fill 7 256 324 7 259 324 minecraft:honeycomb_block
setblock 7 256 363 minecraft:yellow_terracotta
fill 8 256 323 8 259 323 minecraft:honeycomb_block
setblock 8 256 326 minecraft:honeycomb_block
setblock 8 256 362 minecraft:yellow_terracotta
fill 8 256 363 8 259 363 minecraft:honeycomb_block
setblock 9 256 326 minecraft:yellow_terracotta
fill 9 256 362 9 258 362 minecraft:honeycomb_block
setblock 10 256 325 minecraft:yellow_terracotta
fill 10 256 326 10 258 326 minecraft:honeycomb_block
setblock 11 256 324 minecraft:yellow_terracotta
fill 11 256 325 11 259 325 minecraft:honeycomb_block
setblock 12 256 323 minecraft:yellow_terracotta
fill 12 256 324 12 259 324 minecraft:honeycomb_block
setblock 12 256 363 minecraft:yellow_terracotta
fill 13 256 323 13 259 323 minecraft:honeycomb_block
setblock 13 256 362 minecraft:yellow_terracotta
fill 13 256 363 13 259 363 minecraft:honeycomb_block
fill 14 256 362 15 256 362 minecraft:honeycomb_block
setblock 16 256 324 minecraft:yellow_terracotta
setblock 17 256 323 minecraft:yellow_terracotta
fill 17 256 324 18 256 324 minecraft:honeycomb_block
setblock 17 256 363 minecraft:yellow_terracotta
fill 18 256 323 21 256 323 minecraft:honeycomb_block
fill 18 256 363 18 257 363 minecraft:honeycomb_block
setblock 22 256 323 minecraft:yellow_terracotta
setblock 22 256 363 minecraft:yellow_terracotta
fill 23 256 323 24 258 323 minecraft:honeycomb_block
fill 23 256 363 23 259 363 minecraft:honeycomb_block
setblock 24 256 362 minecraft:honeycomb_block
setblock 25 256 324 minecraft:honeycomb_block
setblock 26 256 324 minecraft:yellow_terracotta
setblock 27 256 323 minecraft:yellow_terracotta
fill 27 256 324 27 259 324 minecraft:honeycomb_block
setblock 27 256 363 minecraft:yellow_terracotta
fill 28 256 323 28 259 323 minecraft:honeycomb_block
setblock 28 256 362 minecraft:yellow_terracotta
fill 28 256 363 28 259 363 minecraft:honeycomb_block
fill 29 256 362 29 257 362 minecraft:honeycomb_block
setblock 31 256 324 minecraft:yellow_terracotta
setblock 31 256 364 minecraft:yellow_terracotta
setblock 32 256 323 minecraft:yellow_terracotta
setblock 32 256 324 minecraft:honeycomb_block
setblock 32 256 363 minecraft:yellow_terracotta
fill 33 256 323 33 257 323 minecraft:honeycomb_block
fill 33 256 363 33 257 363 minecraft:honeycomb_block
fill 34 256 349 34 262 349 minecraft:brown_terracotta
fill 37 256 349 37 262 349 minecraft:brown_terracotta
setblock 39 256 363 minecraft:honey_block
setblock 40 256 345 minecraft:yellow_terracotta
fill 40 256 346 40 257 346 minecraft:honeycomb_block
fill 41 256 325 41 259 325 minecraft:honeycomb_block
fill 41 256 327 41 257 327 minecraft:honeycomb_block
setblock 41 256 329 minecraft:honey_block
setblock 41 256 339 minecraft:yellow_terracotta
fill 41 256 340 41 257 340 minecraft:honeycomb_block
setblock 41 256 344 minecraft:yellow_terracotta
fill 41 256 345 41 259 345 minecraft:honeycomb_block
setblock 41 256 349 minecraft:yellow_terracotta
fill 41 256 350 41 259 350 minecraft:honeycomb_block
setblock 41 256 354 minecraft:honey_block
fill 42 256 339 42 308 339 minecraft:honeycomb_block
fill 1 257 322 1 278 322 minecraft:honeycomb_block
setblock 1 257 323 minecraft:yellow_terracotta
fill 1 257 324 1 260 324 minecraft:honeycomb_block
setblock 1 257 327 minecraft:honeycomb_block
setblock 1 257 328 minecraft:yellow_terracotta
fill 1 257 329 2 259 329 minecraft:honeycomb_block
setblock 1 257 332 minecraft:honeycomb_block
setblock 1 257 338 minecraft:honey_block
setblock 1 257 343 minecraft:yellow_terracotta
setblock 1 257 344 minecraft:honeycomb_block
setblock 1 257 363 minecraft:honey_block
fill 2 257 323 2 260 323 minecraft:honeycomb_block
setblock 2 257 327 minecraft:yellow_terracotta
fill 2 257 328 2 260 328 minecraft:honeycomb_block
setblock 3 257 325 minecraft:honeycomb_block
setblock 3 257 326 minecraft:yellow_terracotta
setblock 4 257 324 minecraft:honeycomb_block
setblock 4 257 325 minecraft:yellow_terracotta
setblock 5 257 324 minecraft:yellow_terracotta
fill 5 257 325 5 260 325 minecraft:honeycomb_block
setblock 6 257 323 minecraft:yellow_terracotta
fill 6 257 324 6 260 324 minecraft:honeycomb_block
setblock 6 257 363 minecraft:yellow_terracotta
setblock 7 257 322 minecraft:yellow_terracotta
fill 7 257 323 7 260 323 minecraft:honeycomb_block
fill 7 257 363 7 260 363 minecraft:honeycomb_block
setblock 8 257 326 minecraft:yellow_terracotta
fill 8 257 362 8 258 362 minecraft:honeycomb_block
setblock 9 257 325 minecraft:yellow_terracotta
fill 9 257 326 9 259 326 minecraft:honeycomb_block
setblock 10 257 324 minecraft:yellow_terracotta
fill 10 257 325 10 260 325 minecraft:honeycomb_block
setblock 11 257 323 minecraft:yellow_terracotta
fill 11 257 324 11 260 324 minecraft:honeycomb_block
setblock 11 257 363 minecraft:yellow_terracotta
fill 12 257 323 12 260 323 minecraft:honeycomb_block
setblock 12 257 362 minecraft:yellow_terracotta
fill 12 257 363 12 260 363 minecraft:honeycomb_block
setblock 13 257 362 minecraft:honeycomb_block
setblock 14 257 325 minecraft:yellow_terracotta
setblock 15 257 324 minecraft:yellow_terracotta
setblock 16 257 323 minecraft:yellow_terracotta
setblock 16 257 324 minecraft:honeycomb_block
setblock 16 257 363 minecraft:yellow_terracotta
fill 17 257 323 20 257 323 minecraft:honeycomb_block
fill 17 257 363 17 258 363 minecraft:honeycomb_block
setblock 21 257 323 minecraft:yellow_terracotta
setblock 21 257 363 minecraft:yellow_terracotta
fill 22 257 323 22 260 323 minecraft:honeycomb_block
fill 22 257 363 22 260 363 minecraft:honeycomb_block
setblock 25 257 324 minecraft:yellow_terracotta
setblock 26 257 323 minecraft:yellow_terracotta
fill 26 257 324 26 258 324 minecraft:honeycomb_block
setblock 26 257 363 minecraft:yellow_terracotta
fill 27 257 323 27 260 323 minecraft:honeycomb_block
setblock 27 257 362 minecraft:yellow_terracotta
fill 27 257 363 27 260 363 minecraft:honeycomb_block
fill 28 257 362 28 258 362 minecraft:honeycomb_block
setblock 30 257 324 minecraft:yellow_terracotta
setblock 31 257 323 minecraft:yellow_terracotta
setblock 31 257 324 minecraft:honeycomb_block
setblock 31 257 363 minecraft:yellow_terracotta
fill 31 257 364 31 308 364 minecraft:honeycomb_block
fill 32 257 323 32 258 323 minecraft:honeycomb_block
fill 32 257 338 32 263 338 minecraft:brown_terracotta
fill 32 257 363 32 258 363 minecraft:honeycomb_block
fill 35 257 350 36 262 350 minecraft:brown_terracotta
setblock 40 257 344 minecraft:yellow_terracotta
setblock 40 257 345 minecraft:honeycomb_block
setblock 40 257 364 minecraft:yellow_terracotta
setblock 41 257 323 minecraft:honey_block
setblock 41 257 328 minecraft:yellow_terracotta
setblock 41 257 343 minecraft:yellow_terracotta
fill 41 257 344 41 260 344 minecraft:honeycomb_block
setblock 41 257 348 minecraft:yellow_terracotta
fill 41 257 349 41 260 349 minecraft:honeycomb_block
setblock 0 258 329 minecraft:yellow_concrete
fill 1 258 323 1 261 323 minecraft:honeycomb_block
setblock 1 258 327 minecraft:yellow_terracotta
fill 1 258 328 1 261 328 minecraft:honeycomb_block
setblock 1 258 332 minecraft:yellow_terracotta
setblock 1 258 344 minecraft:honey_block
setblock 2 258 326 minecraft:yellow_terracotta
fill 2 258 327 3 260 327 minecraft:honeycomb_block
setblock 2 258 330 minecraft:honeycomb_block
setblock 3 258 325 minecraft:yellow_terracotta
fill 3 258 326 3 261 326 minecraft:honeycomb_block
setblock 4 258 324 minecraft:yellow_terracotta
fill 4 258 325 4 261 325 minecraft:honeycomb_block
setblock 5 258 323 minecraft:yellow_terracotta
fill 5 258 324 5 261 324 minecraft:honeycomb_block
setblock 5 258 363 minecraft:yellow_terracotta
fill 6 258 323 6 261 323 minecraft:honeycomb_block
fill 6 258 363 6 261 363 minecraft:honeycomb_block
fill 7 258 322 7 298 322 minecraft:honeycomb_block
setblock 7 258 325 minecraft:honeycomb_block
setblock 7 258 326 minecraft:yellow_terracotta
setblock 8 258 325 minecraft:yellow_terracotta
fill 8 258 326 8 261 326 minecraft:honeycomb_block
setblock 9 258 324 minecraft:yellow_terracotta
fill 9 258 325 9 261 325 minecraft:honeycomb_block
setblock 10 258 323 minecraft:yellow_terracotta
fill 10 258 324 10 261 324 minecraft:honeycomb_block
setblock 10 258 363 minecraft:yellow_terracotta
fill 11 258 323 11 261 323 minecraft:honeycomb_block
setblock 11 258 362 minecraft:yellow_terracotta
fill 11 258 363 11 261 363 minecraft:honeycomb_block
setblock 13 258 325 minecraft:yellow_terracotta
setblock 14 258 324 minecraft:yellow_terracotta
setblock 15 258 323 minecraft:yellow_terracotta
setblock 15 258 324 minecraft:honeycomb_block
setblock 15 258 363 minecraft:yellow_terracotta
fill 16 258 323 19 258 323 minecraft:honeycomb_block
setblock 16 258 363 minecraft:honeycomb_block
setblock 20 258 323 minecraft:yellow_terracotta
setblock 21 258 323 minecraft:honeycomb_block
setblock 21 258 363 minecraft:honeycomb_block
setblock 25 258 323 minecraft:yellow_terracotta
setblock 25 258 363 minecraft:yellow_terracotta
fill 26 258 323 26 261 323 minecraft:honeycomb_block
fill 26 258 363 26 261 363 minecraft:honeycomb_block
setblock 27 258 362 minecraft:honeycomb_block
setblock 29 258 324 minecraft:yellow_terracotta
setblock 30 258 323 minecraft:yellow_terracotta
setblock 30 258 324 minecraft:honeycomb_block
setblock 30 258 363 minecraft:yellow_terracotta
fill 31 258 323 31 259 323 minecraft:honeycomb_block
setblock 31 258 363 minecraft:honeycomb_block
fill 32 258 339 32 263 339 minecraft:brown_terracotta
fill 33 258 347 33 262 349 minecraft:brown_terracotta
fill 34 258 350 34 262 350 minecraft:brown_terracotta
setblock 35 258 323 minecraft:honey_block
fill 37 258 350 37 262 350 minecraft:brown_terracotta
fill 38 258 347 38 262 349 minecraft:brown_terracotta
fill 40 258 364 40 276 364 minecraft:honeycomb_block
setblock 41 258 327 minecraft:yellow_terracotta
fill 41 258 328 41 259 330 minecraft:honeycomb_block
setblock 41 258 342 minecraft:yellow_terracotta
fill 41 258 343 41 261 343 minecraft:honeycomb_block
setblock 41 258 347 minecraft:yellow_terracotta
fill 41 258 348 41 261 348 minecraft:honeycomb_block
setblock 41 258 361 minecraft:honey_block
fill 0 259 329 0 308 329 minecraft:honeycomb_block
setblock 0 259 353 minecraft:yellow_terracotta
setblock 1 259 326 minecraft:yellow_terracotta
fill 1 259 327 1 262 327 minecraft:honeycomb_block
setblock 1 259 331 minecraft:yellow_terracotta
fill 1 259 332 1 261 333 minecraft:honeycomb_block
setblock 1 259 350 minecraft:honey_block
setblock 2 259 325 minecraft:yellow_terracotta
fill 2 259 326 2 262 326 minecraft:honeycomb_block
setblock 2 259 330 minecraft:yellow_terracotta
fill 2 259 331 2 262 331 minecraft:honeycomb_block
setblock 3 259 324 minecraft:yellow_terracotta
fill 3 259 325 3 262 325 minecraft:honeycomb_block
setblock 3 259 328 minecraft:honeycomb_block
setblock 3 259 329 minecraft:yellow_terracotta
setblock 4 259 323 minecraft:yellow_terracotta
fill 4 259 324 4 262 324 minecraft:honeycomb_block
setblock 4 259 363 minecraft:yellow_terracotta
fill 5 259 323 5 262 323 minecraft:honeycomb_block
fill 5 259 363 5 262 363 minecraft:honeycomb_block
setblock 6 259 325 minecraft:honeycomb_block
setblock 6 259 326 minecraft:yellow_terracotta
setblock 7 259 325 minecraft:yellow_terracotta
fill 7 259 326 7 262 326 minecraft:honeycomb_block
setblock 8 259 324 minecraft:yellow_terracotta
fill 8 259 325 8 262 325 minecraft:honeycomb_block
setblock 9 259 323 minecraft:yellow_terracotta
fill 9 259 324 9 262 324 minecraft:honeycomb_block
setblock 9 259 363 minecraft:yellow_terracotta
fill 10 259 323 10 262 323 minecraft:honeycomb_block
fill 10 259 363 10 262 363 minecraft:honeycomb_block
setblock 12 259 325 minecraft:yellow_terracotta
setblock 13 259 324 minecraft:yellow_terracotta
setblock 14 259 323 minecraft:yellow_terracotta
setblock 14 259 324 minecraft:honeycomb_block
setblock 14 259 363 minecraft:yellow_terracotta
fill 15 259 323 17 259 323 minecraft:honeycomb_block
setblock 15 259 363 minecraft:honeycomb_block
setblock 20 259 364 minecraft:yellow_concrete
setblock 23 259 323 minecraft:honeycomb_block
setblock 24 259 323 minecraft:yellow_terracotta
fill 24 259 363 24 259 364 minecraft:yellow_terracotta
fill 25 259 323 25 262 323 minecraft:honeycomb_block
fill 25 259 363 25 262 363 minecraft:honeycomb_block
setblock 28 259 324 minecraft:yellow_terracotta
setblock 29 259 323 minecraft:yellow_terracotta
setblock 29 259 363 minecraft:yellow_terracotta
fill 30 259 323 30 260 323 minecraft:honeycomb_block
setblock 30 259 363 minecraft:honeycomb_block
fill 31 259 338 31 263 339 minecraft:brown_terracotta
setblock 32 259 363 minecraft:honey_block
fill 33 259 338 33 263 339 minecraft:brown_terracotta
fill 33 259 346 33 262 346 minecraft:brown_terracotta
fill 33 259 350 33 262 350 minecraft:brown_terracotta
fill 34 259 345 34 262 345 minecraft:brown_terracotta
fill 34 259 351 37 262 351 minecraft:brown_terracotta
fill 37 259 345 37 262 345 minecraft:brown_terracotta
fill 38 259 346 38 262 346 minecraft:brown_terracotta
fill 38 259 350 38 262 350 minecraft:brown_terracotta
setblock 41 259 326 minecraft:yellow_terracotta
fill 41 259 327 41 262 327 minecraft:honeycomb_block
setblock 41 259 331 minecraft:yellow_terracotta
fill 41 259 332 41 262 332 minecraft:honeycomb_block
setblock 41 259 336 minecraft:honey_block
fill 41 259 342 41 262 342 minecraft:honeycomb_block
setblock 41 259 346 minecraft:yellow_terracotta
fill 41 259 347 41 262 347 minecraft:honeycomb_block
setblock 41 259 355 minecraft:honey_block
setblock 42 259 336 minecraft:orange_terracotta
setblock 0 260 338 minecraft:yellow_terracotta
fill 0 260 353 0 273 353 minecraft:honeycomb_block
setblock 1 260 325 minecraft:yellow_terracotta
fill 1 260 326 1 263 326 minecraft:honeycomb_block
setblock 1 260 329 minecraft:honeycomb_block
setblock 1 260 330 minecraft:yellow_terracotta
fill 1 260 331 1 263 331 minecraft:honeycomb_block
setblock 1 260 334 minecraft:honeycomb_block
setblock 1 260 337 minecraft:honey_block
setblock 1 260 356 minecraft:honey_block
setblock 2 260 324 minecraft:yellow_terracotta
fill 2 260 325 2 263 325 minecraft:honeycomb_block
setblock 2 260 329 minecraft:yellow_terracotta
fill 2 260 330 3 262 330 minecraft:honeycomb_block
fill 2 260 332 2 261 332 minecraft:honeycomb_block
setblock 3 260 323 minecraft:yellow_terracotta
fill 3 260 324 3 263 324 minecraft:honeycomb_block
setblock 3 260 328 minecraft:yellow_terracotta
fill 3 260 329 3 263 329 minecraft:honeycomb_block
fill 4 260 323 4 263 323 minecraft:honeycomb_block
fill 4 260 363 4 263 363 minecraft:honeycomb_block
setblock 6 260 325 minecraft:yellow_terracotta
fill 6 260 326 6 263 326 minecraft:honeycomb_block
setblock 7 260 324 minecraft:yellow_terracotta
fill 7 260 325 7 263 325 minecraft:honeycomb_block
setblock 8 260 323 minecraft:yellow_terracotta
fill 8 260 324 8 263 324 minecraft:honeycomb_block
setblock 8 260 363 minecraft:yellow_terracotta
fill 9 260 323 9 263 323 minecraft:honeycomb_block
fill 9 260 363 9 263 363 minecraft:honeycomb_block
setblock 11 260 325 minecraft:yellow_terracotta
setblock 12 260 324 minecraft:yellow_terracotta
setblock 13 260 323 minecraft:yellow_terracotta
setblock 13 260 324 minecraft:honeycomb_block
setblock 13 260 363 minecraft:yellow_terracotta
fill 14 260 323 15 260 323 minecraft:honeycomb_block
setblock 19 260 363 minecraft:honey_block
fill 20 260 364 20 285 364 minecraft:honeycomb_block
setblock 23 260 323 minecraft:yellow_terracotta
setblock 23 260 363 minecraft:yellow_terracotta
fill 24 260 323 24 263 323 minecraft:honeycomb_block
fill 24 260 363 24 263 364 minecraft:honeycomb_block
setblock 28 260 323 minecraft:yellow_terracotta
fill 28 260 332 29 261 333 minecraft:yellow_concrete
setblock 28 260 363 minecraft:yellow_terracotta
fill 29 260 323 29 262 323 minecraft:honeycomb_block
fill 29 260 363 29 261 363 minecraft:honeycomb_block
fill 32 260 337 33 263 337 minecraft:brown_terracotta
fill 32 260 340 32 263 340 minecraft:brown_terracotta
fill 32 260 347 32 262 349 minecraft:brown_terracotta
fill 38 260 345 38 262 345 minecraft:brown_terracotta
setblock 38 260 363 minecraft:honey_block
fill 39 260 347 39 262 349 minecraft:brown_terracotta
setblock 41 260 324 minecraft:honeycomb_block
setblock 41 260 325 minecraft:yellow_terracotta
fill 41 260 326 41 263 326 minecraft:honeycomb_block
fill 41 260 328 41 260 329 minecraft:honeycomb_block
setblock 41 260 330 minecraft:yellow_terracotta
fill 41 260 331 41 263 331 minecraft:honeycomb_block
fill 41 260 333 41 260 334 minecraft:honeycomb_block
setblock 41 260 345 minecraft:yellow_terracotta
fill 41 260 346 41 263 346 minecraft:honeycomb_block
setblock 41 260 350 minecraft:yellow_terracotta
fill 41 260 351 41 263 351 minecraft:honeycomb_block
fill 42 260 336 42 261 336 minecraft:honeycomb_block
fill 0 261 338 0 274 338 minecraft:honeycomb_block
setblock 1 261 324 minecraft:yellow_terracotta
fill 1 261 325 1 264 325 minecraft:honeycomb_block
setblock 1 261 329 minecraft:yellow_terracotta
fill 1 261 330 1 264 330 minecraft:honeycomb_block
setblock 1 261 334 minecraft:yellow_terracotta
fill 1 261 335 1 264 335 minecraft:honeycomb_block
setblock 1 261 343 minecraft:honey_block
fill 1 261 347 1 261 348 minecraft:honeycomb_block
setblock 1 261 349 minecraft:yellow_terracotta
fill 1 261 350 1 264 350 minecraft:honeycomb_block
setblock 1 261 362 minecraft:honey_block
setblock 2 261 323 minecraft:yellow_terracotta
fill 2 261 324 2 264 324 minecraft:honeycomb_block
setblock 2 261 327 minecraft:honeycomb_block
setblock 2 261 328 minecraft:yellow_terracotta
fill 2 261 329 2 264 329 minecraft:honeycomb_block
setblock 2 261 333 minecraft:yellow_terracotta
fill 3 261 323 3 264 323 minecraft:honeycomb_block
setblock 3 261 327 minecraft:yellow_terracotta
fill 3 261 328 4 263 328 minecraft:honeycomb_block
setblock 3 261 331 minecraft:honeycomb_block
setblock 3 261 332 minecraft:light[level=12]
setblock 3 261 339 minecraft:light[level=12]
setblock 3 261 346 minecraft:light[level=12]
setblock 3 261 353 minecraft:light[level=12]
setblock 3 261 360 minecraft:light[level=12]
fill 4 261 327 4 264 327 minecraft:honeycomb_block
fill 4 261 329 4 262 329 minecraft:honeycomb_block
setblock 5 261 325 minecraft:yellow_terracotta
fill 5 261 326 5 264 326 minecraft:honeycomb_block
setblock 6 261 322 minecraft:yellow_concrete
setblock 6 261 324 minecraft:yellow_terracotta
fill 6 261 325 6 264 325 minecraft:honeycomb_block
setblock 7 261 323 minecraft:yellow_terracotta
fill 7 261 324 7 264 324 minecraft:honeycomb_block
setblock 7 261 363 minecraft:yellow_terracotta
fill 8 261 323 8 264 323 minecraft:honeycomb_block
fill 8 261 363 8 264 363 minecraft:honeycomb_block
setblock 10 261 325 minecraft:yellow_terracotta
setblock 10 261 332 minecraft:light[level=12]
setblock 10 261 339 minecraft:light[level=12]
setblock 10 261 346 minecraft:light[level=12]
setblock 10 261 353 minecraft:light[level=12]
setblock 10 261 360 minecraft:light[level=12]
setblock 11 261 324 minecraft:yellow_terracotta
setblock 11 261 364 minecraft:yellow_concrete
setblock 12 261 323 minecraft:yellow_terracotta
fill 12 261 324 12 262 324 minecraft:honeycomb_block
setblock 12 261 363 minecraft:yellow_terracotta
fill 13 261 323 14 262 323 minecraft:honeycomb_block
setblock 13 261 363 minecraft:honeycomb_block
setblock 17 261 323 minecraft:honey_block
setblock 17 261 325 minecraft:light[level=12]
setblock 17 261 332 minecraft:light[level=12]
setblock 17 261 339 minecraft:light[level=12]
setblock 17 261 346 minecraft:light[level=12]
setblock 17 261 353 minecraft:light[level=12]
setblock 17 261 360 minecraft:light[level=12]
setblock 22 261 323 minecraft:yellow_terracotta
setblock 22 261 363 minecraft:yellow_terracotta
setblock 22 261 364 minecraft:orange_terracotta
fill 23 261 323 23 264 323 minecraft:honeycomb_block
fill 23 261 363 23 264 363 minecraft:honeycomb_block
setblock 24 261 325 minecraft:light[level=12]
setblock 24 261 332 minecraft:light[level=12]
setblock 24 261 339 minecraft:light[level=12]
setblock 24 261 346 minecraft:light[level=12]
setblock 24 261 353 minecraft:light[level=12]
setblock 24 261 360 minecraft:light[level=12]
setblock 27 261 323 minecraft:yellow_terracotta
setblock 27 261 363 minecraft:yellow_terracotta
fill 28 261 323 28 264 323 minecraft:honeycomb_block
fill 28 261 363 28 264 363 minecraft:honeycomb_block
fill 30 261 338 30 263 339 minecraft:brown_terracotta
setblock 31 261 325 minecraft:light[level=12]
setblock 31 261 332 minecraft:light[level=12]
fill 31 261 337 31 263 337 minecraft:brown_terracotta
fill 31 261 340 31 263 340 minecraft:brown_terracotta
setblock 31 261 346 minecraft:light[level=12]
setblock 31 261 353 minecraft:light[level=12]
setblock 31 261 360 minecraft:light[level=12]
fill 32 261 346 32 262 346 minecraft:brown_terracotta
fill 32 261 350 32 262 350 minecraft:brown_terracotta
fill 33 261 340 33 263 340 minecraft:brown_terracotta
fill 33 261 345 33 262 345 minecraft:brown_terracotta
fill 33 261 351 33 262 351 minecraft:brown_terracotta
fill 34 261 338 34 263 339 minecraft:brown_terracotta
fill 34 261 344 37 262 344 minecraft:brown_terracotta
fill 34 261 352 37 262 352 minecraft:brown_terracotta
setblock 38 261 325 minecraft:light[level=12]
setblock 38 261 332 minecraft:light[level=12]
setblock 38 261 339 minecraft:light[level=12]
fill 38 261 351 38 262 351 minecraft:brown_terracotta
setblock 38 261 353 minecraft:light[level=12]
setblock 38 261 360 minecraft:light[level=12]
fill 39 261 346 39 262 346 minecraft:brown_terracotta
fill 39 261 350 39 262 350 minecraft:brown_terracotta
setblock 40 261 329 minecraft:honeycomb_block
setblock 40 261 330 minecraft:yellow_terracotta
setblock 41 261 324 minecraft:yellow_terracotta
fill 41 261 325 41 264 325 minecraft:honeycomb_block
setblock 41 261 328 minecraft:honeycomb_block
setblock 41 261 329 minecraft:yellow_terracotta
fill 41 261 330 41 264 330 minecraft:honeycomb_block
setblock 41 261 333 minecraft:honeycomb_block
setblock 41 261 334 minecraft:yellow_terracotta
fill 41 261 335 41 263 336 minecraft:honeycomb_block
setblock 41 261 344 minecraft:yellow_terracotta
fill 41 261 345 41 264 345 minecraft:honeycomb_block
setblock 41 261 349 minecraft:yellow_terracotta
fill 41 261 350 41 264 350 minecraft:honeycomb_block
fill 41 261 352 41 262 352 minecraft:honeycomb_block
setblock 42 261 335 minecraft:yellow_concrete
setblock 1 262 323 minecraft:yellow_terracotta
fill 1 262 324 1 265 324 minecraft:honeycomb_block
setblock 1 262 328 minecraft:yellow_terracotta
fill 1 262 329 1 265 329 minecraft:honeycomb_block
setblock 1 262 332 minecraft:honeycomb_block
setblock 1 262 333 minecraft:yellow_terracotta
fill 1 262 334 2 264 334 minecraft:honeycomb_block
fill 1 262 336 1 262 337 minecraft:honeycomb_block
fill 1 262 346 1 262 347 minecraft:honeycomb_block
setblock 1 262 348 minecraft:yellow_terracotta
fill 1 262 349 1 265 349 minecraft:honeycomb_block
fill 1 262 351 1 262 352 minecraft:honeycomb_block
setblock 1 262 353 minecraft:yellow_terracotta
fill 2 262 323 2 265 323 minecraft:honeycomb_block
setblock 2 262 327 minecraft:yellow_terracotta
fill 2 262 328 2 265 328 minecraft:honeycomb_block
setblock 2 262 332 minecraft:yellow_terracotta
fill 2 262 333 3 264 333 minecraft:honeycomb_block
setblock 3 262 326 minecraft:yellow_terracotta
fill 3 262 327 3 265 327 minecraft:honeycomb_block
setblock 3 262 331 minecraft:yellow_terracotta
fill 3 262 332 3 265 332 minecraft:honeycomb_block
fill 3 262 363 3 264 363 minecraft:honeycomb_block
setblock 4 262 325 minecraft:yellow_terracotta
fill 4 262 326 4 265 326 minecraft:honeycomb_block
setblock 4 262 330 minecraft:yellow_terracotta
fill 4 262 358 4 264 358 minecraft:yellow_terracotta
setblock 5 262 324 minecraft:yellow_terracotta
fill 5 262 325 5 265 325 minecraft:honeycomb_block
fill 5 262 357 5 264 357 minecraft:yellow_terracotta
fill 5 262 359 5 264 359 minecraft:yellow_terracotta
fill 6 262 322 6 275 322 minecraft:honeycomb_block
setblock 6 262 323 minecraft:yellow_terracotta
fill 6 262 324 6 265 324 minecraft:honeycomb_block
fill 6 262 358 6 264 358 minecraft:yellow_terracotta
setblock 6 262 363 minecraft:yellow_terracotta
fill 7 262 323 7 265 323 minecraft:honeycomb_block
fill 7 262 363 7 265 363 minecraft:honeycomb_block
setblock 8 262 326 minecraft:yellow_terracotta
setblock 9 262 325 minecraft:yellow_terracotta
setblock 10 262 324 minecraft:yellow_terracotta
setblock 10 262 325 minecraft:honeycomb_block
setblock 11 262 323 minecraft:yellow_terracotta
fill 11 262 324 11 264 324 minecraft:honeycomb_block
setblock 11 262 363 minecraft:yellow_terracotta
fill 11 262 364 11 308 364 minecraft:honeycomb_block
fill 12 262 323 12 265 323 minecraft:honeycomb_block
fill 12 262 363 12 265 363 minecraft:honeycomb_block
setblock 21 262 363 minecraft:yellow_terracotta
fill 22 262 323 22 265 323 minecraft:honeycomb_block
fill 22 262 363 22 265 364 minecraft:honeycomb_block
setblock 26 262 323 minecraft:yellow_terracotta
setblock 26 262 363 minecraft:yellow_terracotta
fill 27 262 323 27 265 323 minecraft:honeycomb_block
fill 27 262 363 27 265 363 minecraft:honeycomb_block
fill 30 262 337 30 263 337 minecraft:brown_terracotta
fill 30 262 340 30 263 340 minecraft:brown_terracotta
fill 31 262 336 33 263 336 minecraft:brown_terracotta
fill 31 262 347 31 262 349 minecraft:brown_terracotta
setblock 31 262 363 minecraft:honey_block
fill 32 262 341 32 263 341 minecraft:brown_terracotta
setblock 32 262 345 minecraft:brown_terracotta
setblock 32 262 351 minecraft:brown_terracotta
setblock 33 262 344 minecraft:brown_terracotta
setblock 33 262 352 minecraft:brown_terracotta
fill 34 262 337 34 263 337 minecraft:brown_terracotta
fill 34 262 340 34 263 340 minecraft:brown_terracotta
setblock 36 262 323 minecraft:honey_block
setblock 38 262 344 minecraft:brown_terracotta
setblock 38 262 352 minecraft:brown_terracotta
setblock 39 262 345 minecraft:brown_terracotta
setblock 39 262 351 minecraft:brown_terracotta
fill 40 262 327 40 262 328 minecraft:honeycomb_block
setblock 40 262 329 minecraft:yellow_terracotta
fill 40 262 330 40 262 333 minecraft:honeycomb_block
setblock 40 262 347 minecraft:brown_terracotta
setblock 40 262 348 minecraft:honeycomb_block
setblock 40 262 349 minecraft:yellow_terracotta
setblock 41 262 323 minecraft:yellow_terracotta
fill 41 262 324 41 265 324 minecraft:honeycomb_block
setblock 41 262 328 minecraft:yellow_terracotta
fill 41 262 329 41 265 329 minecraft:honeycomb_block
setblock 41 262 333 minecraft:yellow_terracotta
fill 41 262 334 41 265 334 minecraft:honeycomb_block
setblock 41 262 337 minecraft:honeycomb_block
setblock 41 262 338 minecraft:yellow_terracotta
fill 41 262 339 41 263 341 minecraft:honeycomb_block
setblock 41 262 343 minecraft:yellow_terracotta
fill 41 262 344 41 265 344 minecraft:honeycomb_block
setblock 41 262 348 minecraft:yellow_terracotta
fill 41 262 349 41 265 349 minecraft:honeycomb_block
setblock 41 262 353 minecraft:yellow_terracotta
fill 41 262 354 41 265 354 minecraft:honeycomb_block
setblock 41 262 362 minecraft:honey_block
fill 42 262 335 42 308 335 minecraft:honeycomb_block
setblock 42 262 336 minecraft:yellow_terracotta
setblock 42 262 346 minecraft:yellow_terracotta
fill 1 263 323 1 266 323 minecraft:honeycomb_block
setblock 1 263 327 minecraft:yellow_terracotta
fill 1 263 328 1 266 328 minecraft:honeycomb_block
setblock 1 263 332 minecraft:yellow_terracotta
fill 1 263 333 1 266 333 minecraft:honeycomb_block
setblock 1 263 336 minecraft:honeycomb_block
setblock 1 263 337 minecraft:yellow_terracotta
fill 1 263 338 1 266 338 minecraft:honeycomb_block
setblock 1 263 346 minecraft:honeycomb_block
setblock 1 263 347 minecraft:yellow_terracotta
fill 1 263 348 1 266 348 minecraft:honeycomb_block
setblock 1 263 351 minecraft:honeycomb_block
setblock 1 263 352 minecraft:yellow_terracotta
fill 1 263 353 1 263 356 minecraft:honeycomb_block
setblock 2 263 326 minecraft:yellow_terracotta
fill 2 263 327 2 266 327 minecraft:honeycomb_block
setblock 2 263 330 minecraft:honeycomb_block
setblock 2 263 331 minecraft:yellow_terracotta
fill 2 263 332 2 266 332 minecraft:honeycomb_block
setblock 2 263 335 minecraft:honeycomb_block
setblock 2 263 336 minecraft:yellow_terracotta
fill 2 263 349 2 263 350 minecraft:honeycomb_block
setblock 2 263 351 minecraft:yellow_terracotta
fill 2 263 352 2 265 353 minecraft:honeycomb_block
fill 2 263 363 2 265 363 minecraft:honeycomb_block
setblock 3 263 325 minecraft:yellow_terracotta
fill 3 263 326 3 266 326 minecraft:honeycomb_block
setblock 3 263 330 minecraft:yellow_terracotta
fill 3 263 331 4 265 331 minecraft:honeycomb_block
setblock 3 263 334 minecraft:honeycomb_block
setblock 3 263 341 minecraft:light[level=15]
setblock 3 263 349 minecraft:light[level=15]
setblock 3 263 357 minecraft:light[level=15]
setblock 4 263 324 minecraft:yellow_terracotta
fill 4 263 325 4 266 325 minecraft:honeycomb_block
setblock 4 263 329 minecraft:yellow_terracotta
fill 4 263 330 4 266 330 minecraft:honeycomb_block
setblock 5 263 323 minecraft:yellow_terracotta
fill 5 263 324 5 266 324 minecraft:honeycomb_block
setblock 5 263 362 minecraft:honeycomb_block
setblock 5 263 363 minecraft:yellow_terracotta
fill 6 263 323 6 266 323 minecraft:honeycomb_block
setblock 6 263 362 minecraft:yellow_terracotta
fill 6 263 363 6 266 363 minecraft:honeycomb_block
setblock 7 263 326 minecraft:yellow_terracotta
fill 7 263 362 8 265 362 minecraft:honeycomb_block
setblock 8 263 325 minecraft:yellow_terracotta
setblock 9 263 324 minecraft:yellow_terracotta
fill 9 263 325 9 264 325 minecraft:honeycomb_block
setblock 10 263 323 minecraft:yellow_terracotta
fill 10 263 324 10 265 324 minecraft:honeycomb_block
setblock 10 263 363 minecraft:yellow_terracotta
fill 11 263 323 11 266 323 minecraft:honeycomb_block
setblock 11 263 325 minecraft:light[level=15]
setblock 11 263 333 minecraft:light[level=15]
setblock 11 263 341 minecraft:light[level=15]
setblock 11 263 349 minecraft:light[level=15]
setblock 11 263 357 minecraft:light[level=15]
fill 11 263 363 11 266 363 minecraft:honeycomb_block
fill 13 263 323 13 264 323 minecraft:honeycomb_block
setblock 19 263 325 minecraft:light[level=15]
setblock 19 263 333 minecraft:light[level=15]
setblock 19 263 341 minecraft:light[level=15]
setblock 19 263 349 minecraft:light[level=15]
setblock 19 263 357 minecraft:light[level=15]
setblock 20 263 363 minecraft:yellow_terracotta
fill 21 263 323 21 266 323 minecraft:honeycomb_block
fill 21 263 363 21 266 363 minecraft:honeycomb_block
setblock 21 263 364 minecraft:yellow_concrete
setblock 25 263 323 minecraft:yellow_terracotta
setblock 25 263 363 minecraft:yellow_terracotta
fill 26 263 323 26 266 323 minecraft:honeycomb_block
fill 26 263 363 26 266 363 minecraft:honeycomb_block
setblock 27 263 325 minecraft:light[level=15]
setblock 27 263 333 minecraft:light[level=15]
setblock 27 263 341 minecraft:light[level=15]
setblock 27 263 349 minecraft:light[level=15]
setblock 27 263 357 minecraft:light[level=15]
setblock 30 263 323 minecraft:honey_block
setblock 31 263 341 minecraft:brown_terracotta
setblock 33 263 341 minecraft:brown_terracotta
setblock 34 263 336 minecraft:brown_terracotta
setblock 35 263 325 minecraft:light[level=15]
setblock 35 263 333 minecraft:light[level=15]
fill 35 263 338 35 263 339 minecraft:brown_terracotta
setblock 35 263 341 minecraft:light[level=15]
setblock 35 263 357 minecraft:light[level=15]
setblock 37 263 363 minecraft:honey_block
fill 40 263 326 40 263 327 minecraft:honeycomb_block
setblock 40 263 328 minecraft:yellow_terracotta
fill 40 263 329 40 263 332 minecraft:honeycomb_block
setblock 40 263 333 minecraft:yellow_terracotta
fill 40 263 334 40 264 336 minecraft:honeycomb_block
setblock 40 263 347 minecraft:honeycomb_block
setblock 40 263 348 minecraft:yellow_terracotta
fill 40 263 349 40 264 351 minecraft:honeycomb_block
fill 41 263 323 41 266 323 minecraft:honeycomb_block
setblock 41 263 327 minecraft:yellow_terracotta
fill 41 263 328 41 266 328 minecraft:honeycomb_block
setblock 41 263 332 minecraft:yellow_terracotta
fill 41 263 333 41 266 333 minecraft:honeycomb_block
setblock 41 263 337 minecraft:yellow_terracotta
fill 41 263 338 41 266 338 minecraft:honeycomb_block
setblock 41 263 342 minecraft:yellow_terracotta
fill 41 263 343 41 266 343 minecraft:honeycomb_block
setblock 41 263 347 minecraft:yellow_terracotta
fill 41 263 348 41 266 348 minecraft:honeycomb_block
setblock 41 263 352 minecraft:yellow_terracotta
fill 41 263 353 41 266 353 minecraft:honeycomb_block
fill 41 263 355 41 264 355 minecraft:honeycomb_block
setblock 41 263 356 minecraft:honey_block
fill 42 263 336 42 308 336 minecraft:honeycomb_block
fill 42 263 346 42 265 346 minecraft:honeycomb_block
setblock 42 263 350 minecraft:orange_terracotta
setblock 1 264 326 minecraft:yellow_terracotta
fill 1 264 327 1 267 327 minecraft:honeycomb_block
setblock 1 264 331 minecraft:yellow_terracotta
fill 1 264 332 1 267 332 minecraft:honeycomb_block
setblock 1 264 336 minecraft:yellow_terracotta
fill 1 264 337 2 266 337 minecraft:honeycomb_block
fill 1 264 339 1 265 339 minecraft:honeycomb_block
setblock 1 264 345 minecraft:honeycomb_block
setblock 1 264 346 minecraft:yellow_terracotta
fill 1 264 347 1 267 347 minecraft:honeycomb_block
setblock 1 264 351 minecraft:yellow_terracotta
fill 1 264 352 1 264 355 minecraft:honeycomb_block
setblock 1 264 356 minecraft:yellow_terracotta
fill 1 264 357 1 264 360 minecraft:honeycomb_block
setblock 1 264 361 minecraft:yellow_terracotta
fill 1 264 362 1 266 363 minecraft:honeycomb_block
setblock 2 264 325 minecraft:yellow_terracotta
fill 2 264 326 2 267 326 minecraft:honeycomb_block
setblock 2 264 330 minecraft:yellow_terracotta
fill 2 264 331 2 267 331 minecraft:honeycomb_block
setblock 2 264 335 minecraft:yellow_terracotta
fill 2 264 336 2 267 336 minecraft:honeycomb_block
fill 2 264 348 2 264 349 minecraft:honeycomb_block
setblock 2 264 350 minecraft:yellow_terracotta
fill 2 264 351 2 267 351 minecraft:honeycomb_block
setblock 2 264 354 minecraft:honeycomb_block
setblock 2 264 355 minecraft:yellow_terracotta
fill 2 264 356 2 267 356 minecraft:honeycomb_block
setblock 3 264 324 minecraft:yellow_terracotta
fill 3 264 325 3 267 325 minecraft:honeycomb_block
setblock 3 264 328 minecraft:honeycomb_block
setblock 3 264 329 minecraft:yellow_terracotta
fill 3 264 330 3 267 330 minecraft:honeycomb_block
setblock 3 264 334 minecraft:yellow_terracotta
fill 3 264 335 3 267 335 minecraft:honeycomb_block
setblock 4 264 323 minecraft:yellow_terracotta
fill 4 264 324 4 267 324 minecraft:honeycomb_block
setblock 4 264 328 minecraft:yellow_terracotta
fill 4 264 329 4 267 329 minecraft:honeycomb_block
schedule function dropper:buildpart/72_10 1t
