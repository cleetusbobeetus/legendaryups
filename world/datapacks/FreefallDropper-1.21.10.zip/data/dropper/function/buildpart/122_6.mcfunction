setblock 96 132 526 minecraft:blackstone
setblock 96 132 530 minecraft:smooth_basalt
fill 96 132 531 96 135 531 minecraft:blackstone
setblock 96 132 535 minecraft:smooth_basalt
setblock 96 132 551 minecraft:blackstone
fill 102 132 511 102 134 511 minecraft:blackstone
setblock 104 132 551 minecraft:blackstone
setblock 105 132 511 minecraft:smooth_basalt
fill 105 132 512 108 132 512 minecraft:blackstone
setblock 105 132 551 minecraft:smooth_basalt
fill 106 132 511 106 135 511 minecraft:blackstone
fill 106 132 551 106 135 551 minecraft:blackstone
fill 107 132 550 110 132 550 minecraft:blackstone
setblock 108 132 513 minecraft:smooth_basalt
setblock 109 132 512 minecraft:smooth_basalt
fill 109 132 513 109 135 513 minecraft:blackstone
setblock 110 132 511 minecraft:smooth_basalt
fill 110 132 512 110 135 512 minecraft:blackstone
setblock 110 132 551 minecraft:smooth_basalt
fill 111 132 511 111 135 511 minecraft:blackstone
setblock 111 132 550 minecraft:smooth_basalt
fill 111 132 551 111 135 551 minecraft:blackstone
fill 112 132 550 112 135 550 minecraft:blackstone
setblock 113 132 513 minecraft:smooth_basalt
setblock 114 132 512 minecraft:smooth_basalt
setblock 114 132 513 minecraft:blackstone
setblock 115 132 511 minecraft:smooth_basalt
fill 115 132 512 115 135 512 minecraft:blackstone
setblock 115 132 551 minecraft:smooth_basalt
fill 116 132 511 119 132 511 minecraft:blackstone
setblock 116 132 550 minecraft:smooth_basalt
fill 116 132 551 119 132 551 minecraft:blackstone
fill 117 132 550 120 132 550 minecraft:blackstone
setblock 120 132 511 minecraft:smooth_basalt
setblock 120 132 551 minecraft:smooth_basalt
fill 121 132 511 124 132 511 minecraft:blackstone
setblock 121 132 550 minecraft:smooth_basalt
fill 121 132 551 121 135 551 minecraft:blackstone
fill 122 132 550 122 135 550 minecraft:blackstone
setblock 125 132 511 minecraft:smooth_basalt
setblock 125 132 551 minecraft:smooth_basalt
fill 126 132 511 126 135 511 minecraft:blackstone
setblock 126 132 550 minecraft:smooth_basalt
fill 126 132 551 126 135 551 minecraft:blackstone
setblock 127 132 549 minecraft:smooth_basalt
fill 127 132 550 127 135 550 minecraft:blackstone
fill 128 132 549 128 135 549 minecraft:blackstone
setblock 129 132 512 minecraft:smooth_basalt
setblock 130 132 511 minecraft:smooth_basalt
fill 130 132 512 130 135 512 minecraft:blackstone
setblock 130 132 551 minecraft:smooth_basalt
fill 131 132 511 131 135 511 minecraft:blackstone
setblock 131 132 550 minecraft:smooth_basalt
fill 131 132 551 131 135 551 minecraft:blackstone
setblock 132 132 549 minecraft:smooth_basalt
fill 132 132 550 132 135 550 minecraft:blackstone
setblock 133 132 529 minecraft:blackstone
setblock 133 132 533 minecraft:smooth_basalt
fill 133 132 534 133 135 534 minecraft:blackstone
setblock 133 132 548 minecraft:smooth_basalt
setblock 133 132 549 minecraft:blackstone
setblock 134 132 527 minecraft:smooth_basalt
fill 134 132 528 134 133 528 minecraft:blackstone
setblock 134 132 532 minecraft:smooth_basalt
fill 134 132 533 134 135 533 minecraft:blackstone
setblock 134 132 537 minecraft:smooth_basalt
setblock 134 132 538 minecraft:blackstone
setblock 134 132 547 minecraft:smooth_basalt
fill 134 132 548 134 133 548 minecraft:blackstone
setblock 135 132 511 minecraft:smooth_basalt
setblock 135 132 512 minecraft:blackstone
setblock 135 132 526 minecraft:smooth_basalt
fill 135 132 527 135 134 527 minecraft:blackstone
setblock 135 132 531 minecraft:smooth_basalt
fill 135 132 532 135 135 532 minecraft:blackstone
setblock 135 132 536 minecraft:smooth_basalt
fill 135 132 537 135 135 537 minecraft:blackstone
setblock 135 132 541 minecraft:smooth_basalt
fill 135 132 542 135 133 542 minecraft:blackstone
setblock 135 132 546 minecraft:smooth_basalt
fill 135 132 547 135 134 547 minecraft:blackstone
setblock 135 132 551 minecraft:smooth_basalt
setblock 95 133 524 minecraft:blackstone
setblock 95 133 525 minecraft:smooth_basalt
fill 95 133 526 95 136 526 minecraft:blackstone
setblock 95 133 530 minecraft:smooth_basalt
fill 95 133 531 95 136 531 minecraft:blackstone
setblock 95 133 535 minecraft:smooth_basalt
fill 95 133 536 95 136 536 minecraft:blackstone
setblock 96 133 529 minecraft:smooth_basalt
fill 96 133 530 96 135 530 minecraft:blackstone
setblock 96 133 534 minecraft:smooth_basalt
setblock 97 133 513 minecraft:light[level=12]
setblock 97 133 521 minecraft:light[level=12]
setblock 97 133 529 minecraft:light[level=12]
setblock 97 133 537 minecraft:light[level=12]
setblock 97 133 545 minecraft:light[level=12]
setblock 104 133 511 minecraft:smooth_basalt
fill 104 133 512 107 133 512 minecraft:blackstone
setblock 104 133 551 minecraft:smooth_basalt
fill 105 133 511 105 136 511 minecraft:blackstone
setblock 105 133 513 minecraft:light[level=12]
setblock 105 133 521 minecraft:light[level=12]
setblock 105 133 529 minecraft:light[level=12]
setblock 105 133 537 minecraft:light[level=12]
setblock 105 133 545 minecraft:light[level=12]
fill 105 133 551 105 136 551 minecraft:blackstone
setblock 107 133 513 minecraft:smooth_basalt
fill 107 133 550 109 133 550 minecraft:blackstone
setblock 108 133 512 minecraft:smooth_basalt
fill 108 133 513 108 136 513 minecraft:blackstone
setblock 109 133 511 minecraft:smooth_basalt
fill 109 133 512 109 136 512 minecraft:blackstone
setblock 109 133 551 minecraft:smooth_basalt
fill 110 133 511 110 136 511 minecraft:blackstone
setblock 110 133 550 minecraft:smooth_basalt
fill 110 133 551 110 136 551 minecraft:blackstone
fill 111 133 550 111 136 550 minecraft:blackstone
setblock 112 133 513 minecraft:smooth_basalt
setblock 113 133 512 minecraft:smooth_basalt
fill 113 133 513 113 136 513 minecraft:blackstone
setblock 113 133 521 minecraft:light[level=12]
setblock 113 133 529 minecraft:light[level=12]
setblock 113 133 537 minecraft:light[level=12]
setblock 113 133 545 minecraft:light[level=12]
setblock 114 133 511 minecraft:smooth_basalt
fill 114 133 512 114 136 512 minecraft:blackstone
setblock 114 133 551 minecraft:smooth_basalt
fill 115 133 511 118 133 511 minecraft:blackstone
setblock 115 133 550 minecraft:smooth_basalt
fill 115 133 551 118 133 551 minecraft:blackstone
setblock 116 133 550 minecraft:blackstone
setblock 119 133 511 minecraft:smooth_basalt
setblock 119 133 551 minecraft:smooth_basalt
fill 120 133 511 123 133 511 minecraft:blackstone
fill 120 133 551 120 136 551 minecraft:blackstone
setblock 121 133 513 minecraft:light[level=12]
setblock 121 133 521 minecraft:light[level=12]
setblock 121 133 529 minecraft:light[level=12]
setblock 121 133 537 minecraft:light[level=12]
setblock 121 133 545 minecraft:light[level=12]
setblock 124 133 511 minecraft:smooth_basalt
setblock 124 133 551 minecraft:smooth_basalt
fill 125 133 511 125 135 512 minecraft:blackstone
setblock 125 133 550 minecraft:smooth_basalt
fill 125 133 551 125 136 551 minecraft:blackstone
setblock 126 133 549 minecraft:smooth_basalt
fill 126 133 550 126 136 550 minecraft:blackstone
fill 127 133 549 127 136 549 minecraft:blackstone
setblock 128 133 512 minecraft:smooth_basalt
setblock 129 133 511 minecraft:smooth_basalt
fill 129 133 512 129 136 512 minecraft:blackstone
setblock 129 133 513 minecraft:light[level=12]
setblock 129 133 521 minecraft:light[level=12]
setblock 129 133 529 minecraft:light[level=12]
setblock 129 133 537 minecraft:light[level=12]
setblock 129 133 545 minecraft:light[level=12]
setblock 129 133 551 minecraft:smooth_basalt
fill 130 133 511 130 136 511 minecraft:blackstone
setblock 130 133 550 minecraft:smooth_basalt
fill 130 133 551 130 136 551 minecraft:blackstone
setblock 131 133 549 minecraft:smooth_basalt
fill 131 133 550 131 136 550 minecraft:blackstone
setblock 132 133 549 minecraft:blackstone
setblock 133 133 532 minecraft:smooth_basalt
fill 133 133 533 133 136 533 minecraft:blackstone
setblock 134 133 511 minecraft:smooth_basalt
setblock 134 133 531 minecraft:smooth_basalt
fill 134 133 532 134 136 532 minecraft:blackstone
setblock 134 133 536 minecraft:smooth_basalt
fill 134 133 537 134 136 537 minecraft:blackstone
setblock 134 133 547 minecraft:blackstone
setblock 134 133 551 minecraft:smooth_basalt
setblock 135 133 511 minecraft:blackstone
setblock 135 133 526 minecraft:blackstone
setblock 135 133 530 minecraft:smooth_basalt
fill 135 133 531 135 136 531 minecraft:blackstone
setblock 135 133 535 minecraft:smooth_basalt
fill 135 133 536 135 136 536 minecraft:blackstone
setblock 135 133 540 minecraft:smooth_basalt
setblock 135 133 541 minecraft:blackstone
setblock 135 133 545 minecraft:smooth_basalt
setblock 135 133 546 minecraft:blackstone
setblock 135 133 550 minecraft:smooth_basalt
fill 135 133 551 135 135 551 minecraft:blackstone
setblock 95 134 525 minecraft:blackstone
setblock 95 134 529 minecraft:smooth_basalt
fill 95 134 530 95 137 530 minecraft:blackstone
setblock 95 134 534 minecraft:smooth_basalt
fill 95 134 535 95 137 535 minecraft:blackstone
setblock 96 134 528 minecraft:smooth_basalt
setblock 96 134 529 minecraft:blackstone
setblock 96 134 533 minecraft:smooth_basalt
fill 96 134 534 96 137 534 minecraft:blackstone
fill 101 134 511 101 135 511 minecraft:blackstone
setblock 103 134 511 minecraft:smooth_basalt
fill 104 134 511 104 136 512 minecraft:blackstone
fill 104 134 551 104 137 551 minecraft:blackstone
fill 105 134 512 106 134 512 minecraft:blackstone
setblock 106 134 513 minecraft:smooth_basalt
setblock 107 134 512 minecraft:smooth_basalt
fill 107 134 513 107 137 513 minecraft:blackstone
fill 107 134 550 108 134 550 minecraft:blackstone
setblock 108 134 511 minecraft:smooth_basalt
fill 108 134 512 108 137 512 minecraft:blackstone
setblock 108 134 551 minecraft:smooth_basalt
fill 109 134 511 109 137 511 minecraft:blackstone
setblock 109 134 550 minecraft:smooth_basalt
fill 109 134 551 109 137 551 minecraft:blackstone
fill 110 134 550 110 137 550 minecraft:blackstone
setblock 111 134 513 minecraft:smooth_basalt
setblock 112 134 512 minecraft:smooth_basalt
fill 112 134 513 112 137 513 minecraft:blackstone
setblock 113 134 511 minecraft:smooth_basalt
fill 113 134 512 113 137 512 minecraft:blackstone
setblock 113 134 551 minecraft:smooth_basalt
fill 114 134 511 117 134 511 minecraft:blackstone
setblock 114 134 550 minecraft:smooth_basalt
fill 114 134 551 117 134 551 minecraft:blackstone
setblock 117 134 512 minecraft:smooth_basalt
setblock 118 134 511 minecraft:smooth_basalt
setblock 118 134 551 minecraft:smooth_basalt
fill 119 134 511 122 134 511 minecraft:blackstone
fill 119 134 551 119 137 551 minecraft:blackstone
setblock 123 134 511 minecraft:smooth_basalt
setblock 123 134 551 minecraft:smooth_basalt
fill 124 134 511 124 136 512 minecraft:blackstone
setblock 124 134 550 minecraft:smooth_basalt
fill 124 134 551 124 137 551 minecraft:blackstone
fill 125 134 550 125 137 550 minecraft:blackstone
setblock 126 134 549 minecraft:blackstone
setblock 127 134 512 minecraft:smooth_basalt
setblock 128 134 511 minecraft:smooth_basalt
fill 128 134 512 128 137 512 minecraft:blackstone
setblock 128 134 551 minecraft:smooth_basalt
fill 129 134 511 129 137 511 minecraft:blackstone
setblock 129 134 550 minecraft:smooth_basalt
fill 129 134 551 129 137 551 minecraft:blackstone
setblock 130 134 549 minecraft:smooth_basalt
fill 130 134 550 130 137 550 minecraft:blackstone
setblock 131 134 549 minecraft:blackstone
setblock 133 134 511 minecraft:smooth_basalt
setblock 133 134 531 minecraft:smooth_basalt
fill 133 134 532 133 136 532 minecraft:blackstone
setblock 133 134 551 minecraft:smooth_basalt
fill 134 134 511 134 135 511 minecraft:blackstone
setblock 134 134 530 minecraft:smooth_basalt
fill 134 134 531 134 137 531 minecraft:blackstone
setblock 134 134 535 minecraft:smooth_basalt
fill 134 134 536 134 137 536 minecraft:blackstone
setblock 134 134 550 minecraft:smooth_basalt
fill 134 134 551 134 136 551 minecraft:blackstone
setblock 135 134 529 minecraft:smooth_basalt
fill 135 134 530 135 137 530 minecraft:blackstone
setblock 135 134 534 minecraft:smooth_basalt
fill 135 134 535 135 137 535 minecraft:blackstone
setblock 135 134 539 minecraft:smooth_basalt
fill 135 134 540 135 137 540 minecraft:blackstone
setblock 135 134 549 minecraft:smooth_basalt
fill 135 134 550 135 135 550 minecraft:blackstone
setblock 95 135 528 minecraft:smooth_basalt
fill 95 135 529 95 138 529 minecraft:blackstone
setblock 95 135 533 minecraft:smooth_basalt
fill 95 135 534 95 138 534 minecraft:blackstone
setblock 96 135 532 minecraft:smooth_basalt
fill 96 135 533 96 138 533 minecraft:blackstone
fill 100 135 511 100 136 511 minecraft:blackstone
setblock 102 135 511 minecraft:smooth_basalt
fill 103 135 511 103 137 512 minecraft:blackstone
setblock 105 135 512 minecraft:blackstone
setblock 105 135 513 minecraft:smooth_basalt
setblock 106 135 512 minecraft:smooth_basalt
fill 106 135 513 106 138 513 minecraft:blackstone
setblock 107 135 511 minecraft:smooth_basalt
fill 107 135 512 107 138 512 minecraft:blackstone
setblock 107 135 546 minecraft:shroomlight
setblock 107 135 550 minecraft:blackstone
setblock 107 135 551 minecraft:smooth_basalt
fill 108 135 511 108 138 511 minecraft:blackstone
setblock 108 135 550 minecraft:smooth_basalt
fill 108 135 551 108 138 551 minecraft:blackstone
fill 109 135 550 109 138 550 minecraft:blackstone
setblock 110 135 513 minecraft:smooth_basalt
setblock 111 135 512 minecraft:smooth_basalt
fill 111 135 513 111 138 513 minecraft:blackstone
setblock 112 135 511 minecraft:smooth_basalt
fill 112 135 512 112 138 512 minecraft:blackstone
setblock 112 135 551 minecraft:smooth_basalt
fill 113 135 511 116 135 511 minecraft:blackstone
setblock 113 135 550 minecraft:smooth_basalt
fill 113 135 551 116 135 551 minecraft:blackstone
setblock 116 135 512 minecraft:smooth_basalt
setblock 117 135 511 minecraft:smooth_basalt
fill 117 135 512 117 138 512 minecraft:blackstone
setblock 117 135 551 minecraft:smooth_basalt
fill 118 135 511 121 135 511 minecraft:blackstone
fill 118 135 551 118 138 551 minecraft:blackstone
setblock 122 135 511 minecraft:smooth_basalt
setblock 122 135 551 minecraft:smooth_basalt
fill 123 135 511 123 137 512 minecraft:blackstone
setblock 123 135 550 minecraft:smooth_basalt
fill 123 135 551 123 138 551 minecraft:blackstone
fill 124 135 550 124 138 550 minecraft:blackstone
setblock 126 135 512 minecraft:smooth_basalt
setblock 127 135 511 minecraft:smooth_basalt
fill 127 135 512 127 138 512 minecraft:blackstone
setblock 127 135 551 minecraft:smooth_basalt
fill 128 135 511 128 138 511 minecraft:blackstone
setblock 128 135 550 minecraft:smooth_basalt
fill 128 135 551 128 138 551 minecraft:blackstone
setblock 129 135 549 minecraft:smooth_basalt
fill 129 135 550 129 138 550 minecraft:blackstone
setblock 131 135 512 minecraft:smooth_basalt
setblock 132 135 511 minecraft:smooth_basalt
setblock 132 135 551 minecraft:smooth_basalt
fill 133 135 511 133 138 511 minecraft:blackstone
setblock 133 135 535 minecraft:smooth_basalt
setblock 133 135 550 minecraft:smooth_basalt
fill 133 135 551 133 138 551 minecraft:blackstone
setblock 134 135 529 minecraft:smooth_basalt
fill 134 135 530 134 138 530 minecraft:blackstone
setblock 134 135 534 minecraft:smooth_basalt
fill 134 135 535 134 138 535 minecraft:blackstone
setblock 134 135 538 minecraft:blackstone
setblock 135 135 528 minecraft:smooth_basalt
fill 135 135 529 135 138 529 minecraft:blackstone
setblock 135 135 533 minecraft:smooth_basalt
fill 135 135 534 135 138 534 minecraft:blackstone
setblock 135 135 538 minecraft:smooth_basalt
fill 135 135 539 135 138 539 minecraft:blackstone
setblock 95 136 527 minecraft:smooth_basalt
fill 95 136 528 95 139 528 minecraft:blackstone
setblock 95 136 532 minecraft:smooth_basalt
fill 95 136 533 95 139 533 minecraft:blackstone
setblock 95 136 537 minecraft:smooth_basalt
setblock 96 136 531 minecraft:smooth_basalt
fill 96 136 532 96 139 532 minecraft:blackstone
fill 99 136 511 99 137 511 minecraft:blackstone
setblock 101 136 511 minecraft:smooth_basalt
fill 102 136 511 102 138 512 minecraft:blackstone
fill 103 136 551 103 138 551 minecraft:blackstone
setblock 104 136 513 minecraft:smooth_basalt
setblock 105 136 512 minecraft:smooth_basalt
fill 105 136 513 105 139 513 minecraft:blackstone
setblock 106 136 511 minecraft:smooth_basalt
fill 106 136 512 106 139 512 minecraft:blackstone
setblock 106 136 551 minecraft:smooth_basalt
fill 107 136 511 107 139 511 minecraft:blackstone
setblock 107 136 514 minecraft:blackstone
setblock 107 136 550 minecraft:smooth_basalt
fill 107 136 551 107 139 551 minecraft:blackstone
setblock 108 136 514 minecraft:smooth_basalt
fill 108 136 550 108 139 550 minecraft:blackstone
setblock 109 136 513 minecraft:smooth_basalt
fill 109 136 514 109 139 514 minecraft:blackstone
setblock 110 136 512 minecraft:smooth_basalt
fill 110 136 513 110 139 513 minecraft:blackstone
setblock 111 136 511 minecraft:smooth_basalt
fill 111 136 512 111 139 512 minecraft:blackstone
setblock 111 136 551 minecraft:smooth_basalt
fill 112 136 511 115 136 511 minecraft:blackstone
setblock 112 136 550 minecraft:smooth_basalt
fill 112 136 551 115 136 551 minecraft:blackstone
setblock 115 136 512 minecraft:smooth_basalt
setblock 116 136 511 minecraft:smooth_basalt
fill 116 136 512 116 139 512 minecraft:blackstone
setblock 116 136 551 minecraft:smooth_basalt
fill 117 136 511 120 136 511 minecraft:blackstone
fill 117 136 551 117 139 551 minecraft:blackstone
setblock 121 136 511 minecraft:smooth_basalt
setblock 121 136 551 minecraft:smooth_basalt
fill 122 136 511 122 138 512 minecraft:blackstone
setblock 122 136 550 minecraft:smooth_basalt
fill 122 136 551 122 139 551 minecraft:blackstone
fill 123 136 550 123 139 550 minecraft:blackstone
setblock 125 136 511 minecraft:blackstone
setblock 125 136 512 minecraft:smooth_basalt
setblock 126 136 511 minecraft:smooth_basalt
fill 126 136 512 126 139 512 minecraft:blackstone
setblock 126 136 551 minecraft:smooth_basalt
fill 127 136 511 127 139 511 minecraft:blackstone
setblock 127 136 550 minecraft:smooth_basalt
fill 127 136 551 127 139 551 minecraft:blackstone
setblock 128 136 549 minecraft:smooth_basalt
fill 128 136 550 128 139 550 minecraft:blackstone
setblock 130 136 512 minecraft:smooth_basalt
setblock 131 136 511 minecraft:smooth_basalt
fill 131 136 512 131 138 512 minecraft:blackstone
setblock 131 136 551 minecraft:smooth_basalt
fill 132 136 511 132 139 511 minecraft:blackstone
setblock 132 136 550 minecraft:smooth_basalt
fill 132 136 551 132 139 551 minecraft:blackstone
setblock 133 136 534 minecraft:smooth_basalt
fill 133 136 535 133 138 536 minecraft:blackstone
setblock 134 136 533 minecraft:smooth_basalt
fill 134 136 534 134 139 534 minecraft:blackstone
setblock 134 136 538 minecraft:smooth_basalt
fill 135 136 528 135 139 528 minecraft:blackstone
setblock 135 136 532 minecraft:smooth_basalt
fill 135 136 533 135 139 533 minecraft:blackstone
setblock 135 136 537 minecraft:smooth_basalt
fill 135 136 538 135 139 538 minecraft:blackstone
fill 95 137 512 95 137 515 minecraft:blackstone
setblock 95 137 516 minecraft:smooth_basalt
fill 95 137 527 95 140 527 minecraft:blackstone
setblock 95 137 531 minecraft:smooth_basalt
fill 95 137 532 95 140 532 minecraft:blackstone
setblock 95 137 536 minecraft:smooth_basalt
fill 95 137 537 95 139 538 minecraft:blackstone
setblock 96 137 531 minecraft:blackstone
fill 98 137 511 98 138 511 minecraft:blackstone
fill 98 137 512 100 137 512 minecraft:smooth_basalt
setblock 100 137 511 minecraft:smooth_basalt
fill 101 137 511 101 139 512 minecraft:blackstone
setblock 103 137 513 minecraft:smooth_basalt
setblock 104 137 511 minecraft:blackstone
setblock 104 137 512 minecraft:smooth_basalt
fill 104 137 513 104 140 513 minecraft:blackstone
setblock 105 137 511 minecraft:smooth_basalt
fill 105 137 512 105 140 512 minecraft:blackstone
fill 105 137 514 106 137 514 minecraft:blackstone
setblock 105 137 551 minecraft:smooth_basalt
fill 106 137 511 106 140 511 minecraft:blackstone
fill 106 137 551 106 140 551 minecraft:blackstone
setblock 107 137 514 minecraft:smooth_basalt
fill 107 137 550 107 140 550 minecraft:blackstone
setblock 108 137 513 minecraft:smooth_basalt
fill 108 137 514 108 140 514 minecraft:blackstone
setblock 109 137 512 minecraft:smooth_basalt
fill 109 137 513 109 140 513 minecraft:blackstone
setblock 110 137 511 minecraft:smooth_basalt
fill 110 137 512 110 140 512 minecraft:blackstone
fill 110 137 514 110 138 514 minecraft:blackstone
setblock 110 137 551 minecraft:smooth_basalt
fill 111 137 511 114 137 511 minecraft:blackstone
setblock 111 137 550 minecraft:smooth_basalt
fill 111 137 551 114 137 551 minecraft:blackstone
setblock 113 137 513 minecraft:smooth_basalt
setblock 114 137 512 minecraft:smooth_basalt
setblock 115 137 511 minecraft:smooth_basalt
fill 115 137 512 115 140 512 minecraft:blackstone
setblock 115 137 551 minecraft:smooth_basalt
fill 116 137 511 119 137 511 minecraft:blackstone
fill 116 137 551 116 140 551 minecraft:blackstone
setblock 118 137 512 minecraft:blackstone
setblock 120 137 511 minecraft:smooth_basalt
fill 120 137 512 121 139 512 minecraft:blackstone
setblock 120 137 551 minecraft:smooth_basalt
fill 121 137 511 121 140 511 minecraft:blackstone
fill 121 137 551 121 140 551 minecraft:blackstone
fill 122 137 550 122 140 550 minecraft:blackstone
setblock 124 137 511 minecraft:blackstone
setblock 124 137 512 minecraft:smooth_basalt
setblock 125 137 511 minecraft:smooth_basalt
fill 125 137 512 125 140 512 minecraft:blackstone
setblock 125 137 551 minecraft:smooth_basalt
fill 126 137 511 126 140 511 minecraft:blackstone
setblock 126 137 550 minecraft:smooth_basalt
fill 126 137 551 126 140 551 minecraft:blackstone
setblock 127 137 549 minecraft:smooth_basalt
fill 127 137 550 127 140 550 minecraft:blackstone
setblock 129 137 512 minecraft:smooth_basalt
setblock 130 137 511 minecraft:smooth_basalt
fill 130 137 512 130 140 512 minecraft:blackstone
setblock 130 137 551 minecraft:smooth_basalt
fill 131 137 511 131 140 511 minecraft:blackstone
setblock 131 137 550 minecraft:smooth_basalt
fill 131 137 551 131 140 551 minecraft:blackstone
setblock 133 137 533 minecraft:smooth_basalt
fill 133 137 534 133 140 534 minecraft:blackstone
setblock 134 137 532 minecraft:smooth_basalt
fill 134 137 533 134 140 533 minecraft:blackstone
setblock 134 137 537 minecraft:smooth_basalt
fill 134 137 538 134 139 539 minecraft:blackstone
setblock 135 137 531 minecraft:smooth_basalt
fill 135 137 532 135 140 532 minecraft:blackstone
setblock 135 137 536 minecraft:smooth_basalt
fill 135 137 537 135 140 537 minecraft:blackstone
fill 95 138 511 95 138 514 minecraft:blackstone
setblock 95 138 515 minecraft:smooth_basalt
fill 95 138 516 95 139 518 minecraft:blackstone
setblock 95 138 530 minecraft:smooth_basalt
fill 95 138 531 95 141 531 minecraft:blackstone
setblock 95 138 535 minecraft:smooth_basalt
fill 95 138 536 95 141 536 minecraft:blackstone
fill 96 138 511 97 139 511 minecraft:blackstone
setblock 96 138 534 minecraft:smooth_basalt
fill 96 138 535 96 141 535 minecraft:blackstone
fill 98 138 512 99 138 512 minecraft:smooth_basalt
setblock 99 138 511 minecraft:smooth_basalt
fill 100 138 511 100 140 512 minecraft:blackstone
setblock 102 138 513 minecraft:smooth_basalt
fill 102 138 551 102 139 551 minecraft:blackstone
setblock 103 138 511 minecraft:blackstone
setblock 103 138 512 minecraft:smooth_basalt
fill 103 138 513 103 141 513 minecraft:blackstone
setblock 104 138 511 minecraft:smooth_basalt
fill 104 138 512 104 141 512 minecraft:blackstone
fill 104 138 514 105 138 514 minecraft:blackstone
setblock 104 138 551 minecraft:smooth_basalt
fill 105 138 511 105 141 511 minecraft:blackstone
fill 105 138 551 105 141 551 minecraft:blackstone
setblock 106 138 514 minecraft:smooth_basalt
fill 106 138 550 106 141 550 minecraft:blackstone
setblock 107 138 513 minecraft:smooth_basalt
fill 107 138 514 107 141 514 minecraft:blackstone
setblock 108 138 512 minecraft:smooth_basalt
fill 108 138 513 108 141 513 minecraft:blackstone
setblock 109 138 511 minecraft:smooth_basalt
fill 109 138 512 109 141 512 minecraft:blackstone
setblock 109 138 551 minecraft:smooth_basalt
fill 110 138 511 113 138 511 minecraft:blackstone
setblock 110 138 550 minecraft:smooth_basalt
fill 110 138 551 113 138 551 minecraft:blackstone
setblock 111 138 550 minecraft:blackstone
setblock 112 138 513 minecraft:smooth_basalt
setblock 113 138 512 minecraft:smooth_basalt
fill 113 138 513 113 141 513 minecraft:blackstone
setblock 114 138 511 minecraft:smooth_basalt
fill 114 138 512 114 141 512 minecraft:blackstone
setblock 114 138 551 minecraft:smooth_basalt
fill 115 138 511 118 138 511 minecraft:blackstone
fill 115 138 551 115 141 551 minecraft:blackstone
setblock 118 138 512 minecraft:smooth_basalt
setblock 119 138 511 minecraft:smooth_basalt
fill 119 138 512 119 141 512 minecraft:blackstone
setblock 119 138 551 minecraft:smooth_basalt
fill 120 138 511 120 141 511 minecraft:blackstone
fill 120 138 551 120 141 551 minecraft:blackstone
fill 121 138 550 121 141 550 minecraft:blackstone
setblock 123 138 511 minecraft:blackstone
setblock 123 138 512 minecraft:smooth_basalt
setblock 124 138 511 minecraft:smooth_basalt
fill 124 138 512 124 141 512 minecraft:blackstone
setblock 124 138 551 minecraft:smooth_basalt
fill 125 138 511 125 141 511 minecraft:blackstone
fill 125 138 513 126 138 513 minecraft:blackstone
setblock 125 138 550 minecraft:smooth_basalt
fill 125 138 551 125 141 551 minecraft:blackstone
setblock 126 138 549 minecraft:smooth_basalt
fill 126 138 550 126 141 550 minecraft:blackstone
setblock 127 138 513 minecraft:smooth_basalt
setblock 128 138 512 minecraft:smooth_basalt
setblock 129 138 511 minecraft:smooth_basalt
fill 129 138 512 129 141 512 minecraft:blackstone
setblock 129 138 551 minecraft:smooth_basalt
fill 130 138 511 130 141 511 minecraft:blackstone
setblock 130 138 550 minecraft:smooth_basalt
fill 130 138 551 130 141 551 minecraft:blackstone
fill 133 138 533 133 140 533 minecraft:blackstone
setblock 133 138 537 minecraft:smooth_basalt
setblock 134 138 531 minecraft:smooth_basalt
fill 134 138 532 134 141 532 minecraft:blackstone
setblock 134 138 536 minecraft:smooth_basalt
fill 134 138 537 134 141 537 minecraft:blackstone
setblock 135 138 530 minecraft:smooth_basalt
fill 135 138 531 135 141 531 minecraft:blackstone
setblock 135 138 535 minecraft:smooth_basalt
fill 135 138 536 135 141 536 minecraft:blackstone
setblock 135 138 540 minecraft:smooth_basalt
fill 135 138 541 135 141 541 minecraft:blackstone
fill 95 139 511 95 139 513 minecraft:blackstone
setblock 95 139 514 minecraft:smooth_basalt
fill 95 139 515 95 142 515 minecraft:blackstone
setblock 95 139 519 minecraft:smooth_basalt
fill 95 139 520 95 141 521 minecraft:blackstone
setblock 95 139 529 minecraft:smooth_basalt
fill 95 139 530 95 142 530 minecraft:blackstone
setblock 95 139 534 minecraft:smooth_basalt
fill 95 139 535 95 142 535 minecraft:blackstone
setblock 95 139 539 minecraft:smooth_basalt
setblock 96 139 533 minecraft:smooth_basalt
fill 96 139 534 96 141 534 minecraft:blackstone
fill 98 139 511 98 139 512 minecraft:smooth_basalt
fill 99 139 511 99 141 512 minecraft:blackstone
setblock 100 139 513 minecraft:blackstone
fill 100 139 514 100 141 514 minecraft:smooth_basalt
setblock 102 139 511 minecraft:blackstone
setblock 102 139 512 minecraft:smooth_basalt
fill 102 139 513 102 141 514 minecraft:blackstone
setblock 103 139 511 minecraft:smooth_basalt
fill 103 139 512 103 142 512 minecraft:blackstone
fill 103 139 514 104 139 514 minecraft:blackstone
setblock 103 139 551 minecraft:smooth_basalt
fill 104 139 511 104 142 511 minecraft:blackstone
fill 104 139 551 104 142 551 minecraft:blackstone
setblock 105 139 514 minecraft:smooth_basalt
fill 105 139 550 105 142 550 minecraft:blackstone
setblock 106 139 513 minecraft:smooth_basalt
fill 106 139 514 106 141 515 minecraft:blackstone
setblock 107 139 512 minecraft:smooth_basalt
fill 107 139 513 107 142 513 minecraft:blackstone
setblock 108 139 511 minecraft:smooth_basalt
fill 108 139 512 108 142 512 minecraft:blackstone
setblock 108 139 551 minecraft:smooth_basalt
fill 109 139 511 112 139 511 minecraft:blackstone
setblock 109 139 550 minecraft:smooth_basalt
fill 109 139 551 112 139 551 minecraft:blackstone
setblock 110 139 514 minecraft:smooth_basalt
fill 110 139 550 110 140 550 minecraft:blackstone
setblock 111 139 513 minecraft:smooth_basalt
setblock 111 139 514 minecraft:blackstone
setblock 112 139 512 minecraft:smooth_basalt
fill 112 139 513 112 142 513 minecraft:blackstone
setblock 113 139 511 minecraft:smooth_basalt
fill 113 139 512 113 142 512 minecraft:blackstone
setblock 113 139 551 minecraft:smooth_basalt
fill 114 139 511 117 139 511 minecraft:blackstone
fill 114 139 551 114 142 551 minecraft:blackstone
setblock 117 139 512 minecraft:smooth_basalt
setblock 118 139 511 minecraft:smooth_basalt
fill 118 139 512 118 142 512 minecraft:blackstone
setblock 118 139 551 minecraft:smooth_basalt
fill 119 139 511 119 142 511 minecraft:blackstone
fill 119 139 551 119 142 551 minecraft:blackstone
setblock 122 139 511 minecraft:blackstone
setblock 122 139 512 minecraft:smooth_basalt
setblock 123 139 511 minecraft:smooth_basalt
fill 123 139 512 123 141 513 minecraft:blackstone
setblock 123 139 551 minecraft:smooth_basalt
fill 124 139 511 124 142 511 minecraft:blackstone
fill 124 139 513 125 139 513 minecraft:blackstone
setblock 124 139 550 minecraft:smooth_basalt
fill 124 139 551 124 142 551 minecraft:blackstone
setblock 125 139 549 minecraft:smooth_basalt
fill 125 139 550 125 142 550 minecraft:blackstone
setblock 126 139 513 minecraft:smooth_basalt
fill 126 139 549 126 140 549 minecraft:blackstone
setblock 127 139 512 minecraft:smooth_basalt
fill 127 139 513 127 141 513 minecraft:blackstone
setblock 128 139 511 minecraft:smooth_basalt
fill 128 139 512 128 142 512 minecraft:blackstone
setblock 128 139 551 minecraft:smooth_basalt
fill 129 139 511 129 142 511 minecraft:blackstone
setblock 129 139 550 minecraft:smooth_basalt
fill 129 139 551 129 142 551 minecraft:blackstone
setblock 130 139 550 minecraft:blackstone
setblock 133 139 511 minecraft:smooth_basalt
setblock 133 139 535 minecraft:blackstone
setblock 133 139 536 minecraft:smooth_basalt
fill 133 139 537 133 141 538 minecraft:blackstone
fill 134 139 531 134 141 531 minecraft:blackstone
setblock 134 139 535 minecraft:smooth_basalt
fill 134 139 536 134 142 536 minecraft:blackstone
setblock 134 139 540 minecraft:smooth_basalt
setblock 135 139 529 minecraft:smooth_basalt
fill 135 139 530 135 142 530 minecraft:blackstone
setblock 135 139 534 minecraft:smooth_basalt
fill 135 139 535 135 142 535 minecraft:blackstone
setblock 135 139 539 minecraft:smooth_basalt
fill 135 139 540 135 142 540 minecraft:blackstone
fill 135 139 542 135 140 542 minecraft:blackstone
fill 95 140 511 95 140 512 minecraft:blackstone
setblock 95 140 513 minecraft:smooth_basalt
fill 95 140 514 96 142 514 minecraft:blackstone
fill 95 140 516 95 140 517 minecraft:blackstone
setblock 95 140 518 minecraft:smooth_basalt
fill 95 140 519 95 143 519 minecraft:blackstone
setblock 95 140 522 minecraft:blackstone
setblock 95 140 523 minecraft:smooth_basalt
setblock 95 140 528 minecraft:smooth_basalt
fill 95 140 529 95 142 529 minecraft:blackstone
setblock 95 140 533 minecraft:smooth_basalt
fill 95 140 534 95 143 534 minecraft:blackstone
setblock 95 140 537 minecraft:blackstone
setblock 95 140 538 minecraft:smooth_basalt
fill 95 140 539 95 142 540 minecraft:blackstone
setblock 96 140 511 minecraft:blackstone
fill 96 140 512 97 140 512 minecraft:gold_block
fill 96 140 513 96 143 513 minecraft:blackstone
fill 96 140 515 96 140 516 minecraft:blackstone
setblock 96 140 517 minecraft:smooth_basalt
fill 96 140 518 96 143 518 minecraft:blackstone
setblock 96 140 532 minecraft:smooth_basalt
fill 96 140 533 96 141 533 minecraft:blackstone
setblock 96 140 536 minecraft:blackstone
setblock 97 140 511 minecraft:smooth_basalt
fill 97 140 513 97 141 515 minecraft:gold_block
fill 98 140 511 98 142 512 minecraft:blackstone
fill 98 140 515 98 140 516 minecraft:gold_block
fill 99 140 516 101 140 516 minecraft:gold_block
setblock 100 140 513 minecraft:smooth_basalt
setblock 101 140 511 minecraft:blackstone
setblock 101 140 512 minecraft:smooth_basalt
fill 101 140 513 101 142 514 minecraft:blackstone
fill 101 140 515 102 141 515 minecraft:gold_block
setblock 101 140 551 minecraft:blackstone
setblock 102 140 511 minecraft:smooth_basalt
fill 102 140 512 102 143 512 minecraft:blackstone
fill 102 140 538 103 140 542 minecraft:gold_block
setblock 102 140 551 minecraft:smooth_basalt
fill 103 140 511 103 143 511 minecraft:blackstone
setblock 103 140 514 minecraft:blackstone
fill 103 140 537 108 140 537 minecraft:gold_block
fill 103 140 543 108 140 543 minecraft:gold_block
fill 103 140 551 103 143 551 minecraft:blackstone
setblock 104 140 514 minecraft:smooth_basalt
fill 104 140 515 105 142 515 minecraft:blackstone
fill 104 140 538 109 140 538 minecraft:gold_block
fill 104 140 542 104 142 542 minecraft:gold_block
fill 104 140 544 107 140 544 minecraft:gold_block
setblock 105 140 513 minecraft:smooth_basalt
fill 105 140 514 105 143 514 minecraft:blackstone
setblock 106 140 512 minecraft:smooth_basalt
fill 106 140 513 106 143 513 minecraft:blackstone
setblock 107 140 511 minecraft:smooth_basalt
fill 107 140 512 107 143 512 minecraft:blackstone
setblock 107 140 515 minecraft:blackstone
fill 107 140 542 109 140 542 minecraft:gold_block
setblock 107 140 551 minecraft:smooth_basalt
fill 108 140 511 111 140 511 minecraft:blackstone
fill 108 140 539 109 140 541 minecraft:gold_block
setblock 108 140 550 minecraft:smooth_basalt
fill 108 140 551 111 140 551 minecraft:blackstone
setblock 109 140 514 minecraft:smooth_basalt
fill 109 140 550 109 141 550 minecraft:blackstone
setblock 110 140 513 minecraft:smooth_basalt
fill 110 140 514 110 141 514 minecraft:blackstone
setblock 111 140 512 minecraft:smooth_basalt
fill 111 140 513 111 142 513 minecraft:blackstone
setblock 112 140 511 minecraft:smooth_basalt
fill 112 140 512 112 143 512 minecraft:blackstone
setblock 112 140 551 minecraft:smooth_basalt
fill 113 140 511 116 140 511 minecraft:blackstone
fill 113 140 551 113 143 551 minecraft:blackstone
setblock 116 140 512 minecraft:smooth_basalt
setblock 117 140 511 minecraft:smooth_basalt
fill 117 140 512 117 142 512 minecraft:blackstone
setblock 117 140 551 minecraft:smooth_basalt
fill 118 140 511 118 143 511 minecraft:blackstone
fill 118 140 551 118 143 551 minecraft:blackstone
setblock 120 140 512 minecraft:blackstone
fill 120 140 541 121 140 544 minecraft:gold_block
fill 120 140 550 120 142 550 minecraft:blackstone
setblock 121 140 512 minecraft:smooth_basalt
fill 121 140 539 123 140 540 minecraft:gold_block
fill 121 140 545 124 140 545 minecraft:gold_block
setblock 122 140 511 minecraft:smooth_basalt
fill 122 140 512 122 142 513 minecraft:blackstone
fill 122 140 527 123 140 529 minecraft:gold_block
fill 122 140 541 122 142 541 minecraft:gold_block
fill 122 140 544 122 142 544 minecraft:gold_block
fill 122 140 546 128 140 546 minecraft:gold_block
setblock 122 140 551 minecraft:smooth_basalt
fill 123 140 511 123 143 511 minecraft:blackstone
fill 123 140 525 124 140 526 minecraft:gold_block
fill 123 140 530 129 140 530 minecraft:gold_block
fill 123 140 538 126 140 538 minecraft:gold_block
fill 123 140 547 126 140 547 minecraft:gold_block
setblock 123 140 550 minecraft:smooth_basalt
fill 123 140 551 123 143 551 minecraft:blackstone
setblock 124 140 513 minecraft:blackstone
fill 124 140 531 128 140 531 minecraft:gold_block
fill 124 140 539 128 140 539 minecraft:gold_block
fill 124 140 550 124 143 550 minecraft:blackstone
setblock 125 140 513 minecraft:smooth_basalt
fill 125 140 524 126 140 525 minecraft:gold_block
fill 125 140 549 125 141 549 minecraft:blackstone
setblock 126 140 512 minecraft:smooth_basalt
fill 126 140 513 126 142 513 minecraft:blackstone
fill 126 140 540 128 141 540 minecraft:gold_block
fill 126 140 545 128 140 545 minecraft:gold_block
setblock 127 140 511 minecraft:smooth_basalt
fill 127 140 512 127 143 512 minecraft:blackstone
fill 127 140 525 128 140 526 minecraft:gold_block
fill 127 140 541 129 140 541 minecraft:gold_block
fill 127 140 544 129 140 544 minecraft:gold_block
setblock 127 140 551 minecraft:smooth_basalt
fill 128 140 511 128 143 511 minecraft:blackstone
fill 128 140 527 129 140 529 minecraft:gold_block
fill 128 140 542 129 140 543 minecraft:gold_block
setblock 128 140 550 minecraft:smooth_basalt
fill 128 140 551 128 143 551 minecraft:blackstone
setblock 129 140 526 minecraft:gold_block
fill 129 140 550 129 141 550 minecraft:blackstone
setblock 132 140 511 minecraft:smooth_basalt
setblock 132 140 551 minecraft:smooth_basalt
setblock 133 140 535 minecraft:smooth_basalt
fill 133 140 536 133 143 536 minecraft:blackstone
setblock 133 140 539 minecraft:blackstone
setblock 134 140 534 minecraft:smooth_basalt
fill 134 140 535 134 143 535 minecraft:blackstone
setblock 134 140 538 minecraft:blackstone
setblock 134 140 539 minecraft:smooth_basalt
fill 134 140 540 134 142 541 minecraft:blackstone
fill 135 140 514 135 140 517 minecraft:blackstone
setblock 135 140 528 minecraft:smooth_basalt
fill 135 140 529 135 143 529 minecraft:blackstone
setblock 135 140 533 minecraft:smooth_basalt
fill 135 140 534 135 143 534 minecraft:blackstone
setblock 135 140 538 minecraft:smooth_basalt
fill 135 140 539 135 143 539 minecraft:blackstone
setblock 95 141 511 minecraft:blackstone
setblock 95 141 512 minecraft:smooth_basalt
fill 95 141 513 95 143 513 minecraft:blackstone
setblock 95 141 516 minecraft:blackstone
setblock 95 141 517 minecraft:smooth_basalt
fill 95 141 518 95 143 518 minecraft:blackstone
setblock 95 141 522 minecraft:smooth_basalt
fill 95 141 523 95 141 526 minecraft:blackstone
setblock 95 141 527 minecraft:smooth_basalt
fill 95 141 528 95 142 528 minecraft:blackstone
setblock 95 141 532 minecraft:smooth_basalt
fill 95 141 533 95 143 533 minecraft:blackstone
setblock 95 141 537 minecraft:smooth_basalt
fill 95 141 538 95 143 538 minecraft:blackstone
setblock 96 141 511 minecraft:smooth_basalt
setblock 96 141 515 minecraft:blackstone
setblock 96 141 516 minecraft:smooth_basalt
fill 96 141 517 96 143 517 minecraft:blackstone
fill 96 141 519 96 141 520 minecraft:blackstone
setblock 96 141 536 minecraft:smooth_basalt
fill 96 141 537 96 142 537 minecraft:blackstone
fill 97 141 511 97 143 512 minecraft:blackstone
setblock 97 141 521 minecraft:light[level=12]
setblock 97 141 529 minecraft:light[level=12]
setblock 97 141 537 minecraft:light[level=12]
setblock 97 141 545 minecraft:light[level=12]
fill 98 141 515 98 142 515 minecraft:gold_block
fill 99 141 516 100 141 516 minecraft:gold_block
setblock 100 141 511 minecraft:blackstone
setblock 100 141 512 minecraft:smooth_basalt
fill 100 141 513 100 143 513 minecraft:blackstone
setblock 101 141 511 minecraft:smooth_basalt
fill 101 141 512 101 143 512 minecraft:blackstone
setblock 101 141 551 minecraft:smooth_basalt
fill 102 141 511 102 143 511 minecraft:blackstone
fill 102 141 540 103 141 541 minecraft:gold_block
fill 102 141 551 102 143 551 minecraft:blackstone
setblock 103 141 514 minecraft:smooth_basalt
fill 103 141 515 103 143 515 minecraft:blackstone
fill 103 141 538 103 141 539 minecraft:gold_block
setblock 103 141 542 minecraft:gold_block
setblock 104 141 513 minecraft:smooth_basalt
fill 104 141 514 104 143 514 minecraft:blackstone
fill 104 141 538 108 141 538 minecraft:gold_block
fill 104 141 543 107 141 543 minecraft:gold_block
fill 104 141 550 104 143 550 minecraft:blackstone
setblock 105 141 512 minecraft:smooth_basalt
fill 105 141 513 105 143 513 minecraft:blackstone
setblock 105 141 521 minecraft:light[level=12]
setblock 105 141 529 minecraft:light[level=12]
fill 105 141 537 106 141 537 minecraft:gold_block
setblock 105 141 545 minecraft:light[level=12]
setblock 106 141 511 minecraft:smooth_basalt
fill 106 141 512 106 143 512 minecraft:blackstone
setblock 106 141 551 minecraft:smooth_basalt
fill 107 141 511 110 141 511 minecraft:blackstone
setblock 107 141 515 minecraft:smooth_basalt
fill 107 141 542 108 141 542 minecraft:gold_block
setblock 107 141 550 minecraft:smooth_basalt
fill 107 141 551 110 141 551 minecraft:blackstone
setblock 108 141 514 minecraft:smooth_basalt
fill 108 141 539 108 142 541 minecraft:gold_block
fill 108 141 550 108 142 550 minecraft:blackstone
setblock 109 141 513 minecraft:smooth_basalt
fill 109 141 514 109 142 514 minecraft:blackstone
setblock 109 141 540 minecraft:gold_block
setblock 110 141 512 minecraft:smooth_basalt
fill 110 141 513 110 143 513 minecraft:blackstone
setblock 111 141 511 minecraft:smooth_basalt
fill 111 141 512 111 143 512 minecraft:blackstone
setblock 111 141 551 minecraft:smooth_basalt
fill 112 141 511 115 141 511 minecraft:blackstone
fill 112 141 551 112 143 551 minecraft:blackstone
setblock 113 141 521 minecraft:light[level=12]
setblock 113 141 529 minecraft:light[level=12]
setblock 113 141 537 minecraft:light[level=12]
setblock 113 141 545 minecraft:light[level=12]
setblock 115 141 512 minecraft:smooth_basalt
setblock 116 141 511 minecraft:smooth_basalt
fill 116 141 512 116 142 512 minecraft:blackstone
setblock 116 141 551 minecraft:smooth_basalt
fill 117 141 511 117 143 511 minecraft:blackstone
fill 117 141 551 117 143 551 minecraft:blackstone
setblock 120 141 512 minecraft:smooth_basalt
setblock 121 141 511 minecraft:smooth_basalt
fill 121 141 512 121 143 512 minecraft:blackstone
setblock 121 141 513 minecraft:light[level=12]
setblock 121 141 521 minecraft:light[level=12]
setblock 121 141 529 minecraft:light[level=12]
setblock 121 141 537 minecraft:light[level=12]
fill 121 141 541 121 141 544 minecraft:gold_block
setblock 121 141 545 minecraft:light[level=12]
setblock 121 141 551 minecraft:smooth_basalt
fill 122 141 511 122 143 511 minecraft:blackstone
fill 122 141 540 123 141 540 minecraft:gold_block
fill 122 141 545 124 141 545 minecraft:gold_block
setblock 122 141 550 minecraft:smooth_basalt
fill 122 141 551 122 143 551 minecraft:blackstone
fill 123 141 526 123 141 529 minecraft:gold_block
fill 123 141 539 127 141 539 minecraft:gold_block
fill 123 141 546 126 141 546 minecraft:gold_block
fill 123 141 550 123 143 550 minecraft:blackstone
setblock 124 141 513 minecraft:smooth_basalt
fill 124 141 525 124 141 526 minecraft:gold_block
fill 124 141 530 128 141 530 minecraft:gold_block
setblock 124 141 549 minecraft:blackstone
setblock 125 141 512 minecraft:smooth_basalt
fill 125 141 513 125 142 513 minecraft:blackstone
fill 125 141 525 127 141 525 minecraft:gold_block
fill 125 141 531 126 141 531 minecraft:gold_block
setblock 126 141 511 minecraft:smooth_basalt
fill 126 141 512 126 143 512 minecraft:blackstone
fill 126 141 545 127 141 545 minecraft:gold_block
setblock 126 141 551 minecraft:smooth_basalt
fill 127 141 511 127 143 511 minecraft:blackstone
fill 127 141 526 128 141 526 minecraft:gold_block
fill 127 141 541 128 141 541 minecraft:gold_block
fill 127 141 544 128 141 544 minecraft:gold_block
setblock 127 141 550 minecraft:smooth_basalt
fill 127 141 551 127 143 551 minecraft:blackstone
fill 128 141 527 128 142 529 minecraft:gold_block
fill 128 141 542 128 141 543 minecraft:gold_block
fill 128 141 550 128 142 550 minecraft:blackstone
setblock 129 141 513 minecraft:light[level=12]
setblock 129 141 521 minecraft:light[level=12]
setblock 129 141 528 minecraft:gold_block
setblock 129 141 529 minecraft:light[level=12]
setblock 129 141 537 minecraft:light[level=12]
setblock 129 141 545 minecraft:light[level=12]
setblock 131 141 511 minecraft:smooth_basalt
setblock 131 141 551 minecraft:smooth_basalt
setblock 133 141 534 minecraft:smooth_basalt
fill 133 141 535 133 142 535 minecraft:blackstone
setblock 133 141 539 minecraft:smooth_basalt
setblock 134 141 533 minecraft:smooth_basalt
fill 134 141 534 134 143 534 minecraft:blackstone
setblock 134 141 538 minecraft:smooth_basalt
fill 134 141 539 134 143 539 minecraft:blackstone
fill 135 141 513 135 141 516 minecraft:blackstone
setblock 135 141 517 minecraft:smooth_basalt
fill 135 141 518 135 143 519 minecraft:blackstone
setblock 135 141 528 minecraft:blackstone
setblock 135 141 532 minecraft:smooth_basalt
fill 135 141 533 135 143 533 minecraft:blackstone
setblock 135 141 537 minecraft:smooth_basalt
fill 135 141 538 135 143 538 minecraft:blackstone
setblock 135 141 542 minecraft:smooth_basalt
fill 135 141 543 135 143 543 minecraft:blackstone
setblock 95 142 511 minecraft:smooth_basalt
fill 95 142 512 95 143 512 minecraft:blackstone
setblock 95 142 516 minecraft:smooth_basalt
fill 95 142 517 95 143 517 minecraft:blackstone
setblock 95 142 520 minecraft:blackstone
setblock 95 142 521 minecraft:smooth_basalt
fill 95 142 522 95 142 525 minecraft:blackstone
setblock 95 142 526 minecraft:smooth_basalt
setblock 95 142 527 minecraft:blackstone
setblock 95 142 531 minecraft:smooth_basalt
fill 95 142 532 95 143 532 minecraft:blackstone
setblock 95 142 536 minecraft:smooth_basalt
fill 95 142 537 95 143 537 minecraft:blackstone
fill 96 142 511 96 143 511 minecraft:blackstone
setblock 96 142 515 minecraft:smooth_basalt
fill 96 142 516 97 143 516 minecraft:blackstone
setblock 96 142 519 minecraft:blackstone
setblock 96 142 520 minecraft:smooth_basalt
fill 96 142 521 96 143 521 minecraft:blackstone
setblock 96 142 535 minecraft:smooth_basalt
setblock 96 142 536 minecraft:blackstone
setblock 97 142 513 minecraft:gold_block
fill 97 142 515 97 143 515 minecraft:blackstone
fill 97 142 517 97 142 518 minecraft:blackstone
setblock 99 142 511 minecraft:blackstone
setblock 99 142 512 minecraft:smooth_basalt
fill 99 142 513 99 143 513 minecraft:blackstone
fill 99 142 514 99 143 514 minecraft:smooth_basalt
setblock 100 142 511 minecraft:smooth_basalt
fill 100 142 512 100 143 512 minecraft:blackstone
fill 100 142 514 100 143 514 minecraft:blackstone
fill 101 142 511 101 143 511 minecraft:blackstone
setblock 101 142 515 minecraft:gold_block
fill 101 142 551 101 143 551 minecraft:blackstone
setblock 102 142 513 minecraft:blackstone
setblock 102 142 514 minecraft:smooth_basalt
fill 102 142 515 102 143 515 minecraft:blackstone
setblock 103 142 513 minecraft:smooth_basalt
fill 103 142 514 103 143 514 minecraft:blackstone
fill 103 142 539 103 142 541 minecraft:gold_block
setblock 104 142 512 minecraft:smooth_basalt
fill 104 142 513 104 143 513 minecraft:blackstone
fill 104 142 538 107 142 538 minecraft:gold_block
setblock 105 142 511 minecraft:smooth_basalt
fill 105 142 512 105 143 512 minecraft:blackstone
fill 105 142 543 106 142 543 minecraft:gold_block
setblock 105 142 551 minecraft:smooth_basalt
fill 106 142 511 109 142 511 minecraft:blackstone
setblock 106 142 514 minecraft:blackstone
setblock 106 142 515 minecraft:smooth_basalt
setblock 106 142 550 minecraft:smooth_basalt
fill 106 142 551 109 142 551 minecraft:blackstone
setblock 107 142 514 minecraft:smooth_basalt
setblock 107 142 515 minecraft:blackstone
setblock 107 142 542 minecraft:gold_block
fill 107 142 550 107 143 550 minecraft:blackstone
setblock 108 142 513 minecraft:smooth_basalt
fill 108 142 514 108 143 514 minecraft:blackstone
setblock 109 142 512 minecraft:smooth_basalt
fill 109 142 513 109 143 513 minecraft:blackstone
setblock 110 142 511 minecraft:smooth_basalt
fill 110 142 512 110 143 512 minecraft:blackstone
setblock 110 142 551 minecraft:smooth_basalt
fill 111 142 511 114 142 511 minecraft:blackstone
fill 111 142 551 111 143 551 minecraft:blackstone
setblock 114 142 512 minecraft:smooth_basalt
setblock 115 142 511 minecraft:smooth_basalt
setblock 115 142 512 minecraft:blackstone
fill 115 142 547 117 143 547 minecraft:gold_block
setblock 115 142 551 minecraft:smooth_basalt
fill 116 142 511 116 143 511 minecraft:blackstone
fill 116 142 546 116 143 546 minecraft:gold_block
fill 116 142 548 116 143 548 minecraft:gold_block
fill 116 142 551 116 143 551 minecraft:blackstone
setblock 119 142 512 minecraft:smooth_basalt
setblock 120 142 511 minecraft:smooth_basalt
fill 120 142 512 120 143 512 minecraft:blackstone
setblock 120 142 551 minecraft:smooth_basalt
fill 121 142 511 121 143 511 minecraft:blackstone
setblock 121 142 550 minecraft:smooth_basalt
fill 121 142 551 121 143 551 minecraft:blackstone
fill 122 142 550 122 143 550 minecraft:blackstone
setblock 123 142 512 minecraft:blackstone
setblock 123 142 513 minecraft:smooth_basalt
setblock 123 142 528 minecraft:gold_block
setblock 123 142 540 minecraft:gold_block
fill 123 142 545 124 142 545 minecraft:gold_block
setblock 124 142 512 minecraft:smooth_basalt
setblock 124 142 513 minecraft:blackstone
setblock 124 142 526 minecraft:gold_block
fill 124 142 530 127 142 530 minecraft:gold_block
setblock 125 142 511 minecraft:smooth_basalt
fill 125 142 512 125 143 512 minecraft:blackstone
setblock 125 142 551 minecraft:smooth_basalt
fill 126 142 511 126 143 511 minecraft:blackstone
setblock 126 142 540 minecraft:gold_block
setblock 126 142 545 minecraft:gold_block
setblock 126 142 550 minecraft:smooth_basalt
fill 126 142 551 126 143 551 minecraft:blackstone
setblock 127 142 526 minecraft:gold_block
setblock 127 142 541 minecraft:gold_block
setblock 127 142 544 minecraft:gold_block
fill 127 142 550 127 143 550 minecraft:blackstone
setblock 130 142 511 minecraft:smooth_basalt
setblock 130 142 551 minecraft:smooth_basalt
setblock 133 142 537 minecraft:blackstone
setblock 133 142 538 minecraft:smooth_basalt
fill 133 142 539 133 143 539 minecraft:blackstone
setblock 134 142 532 minecraft:smooth_basalt
fill 134 142 533 134 143 533 minecraft:blackstone
setblock 134 142 537 minecraft:smooth_basalt
fill 134 142 538 134 143 538 minecraft:blackstone
fill 135 142 514 135 142 515 minecraft:blackstone
setblock 135 142 516 minecraft:smooth_basalt
fill 135 142 517 135 143 517 minecraft:blackstone
setblock 135 142 520 minecraft:blackstone
setblock 135 142 521 minecraft:smooth_basalt
setblock 135 142 531 minecraft:smooth_basalt
fill 135 142 532 135 143 532 minecraft:blackstone
setblock 135 142 536 minecraft:smooth_basalt
fill 135 142 537 135 143 537 minecraft:blackstone
setblock 135 142 541 minecraft:smooth_basalt
fill 135 142 542 135 143 542 minecraft:blackstone
setblock 95 143 514 minecraft:blackstone
setblock 95 143 515 minecraft:smooth_basalt
setblock 95 143 516 minecraft:blackstone
setblock 95 143 520 minecraft:smooth_basalt
fill 95 143 521 95 143 524 minecraft:blackstone
setblock 95 143 525 minecraft:smooth_basalt
setblock 95 143 526 minecraft:blackstone
setblock 95 143 531 minecraft:blackstone
setblock 95 143 535 minecraft:smooth_basalt
setblock 95 143 536 minecraft:blackstone
setblock 95 143 539 minecraft:blackstone
setblock 95 143 540 minecraft:smooth_basalt
setblock 95 143 541 minecraft:blackstone
setblock 96 143 514 minecraft:smooth_basalt
setblock 96 143 515 minecraft:blackstone
setblock 96 143 519 minecraft:smooth_basalt
fill 96 143 520 97 143 520 minecraft:blackstone
setblock 96 143 522 minecraft:blackstone
setblock 97 143 517 minecraft:blackstone
setblock 97 143 518 minecraft:smooth_basalt
setblock 97 143 519 minecraft:blackstone
setblock 98 143 511 minecraft:blackstone
setblock 98 143 512 minecraft:smooth_basalt
setblock 99 143 511 minecraft:smooth_basalt
setblock 99 143 512 minecraft:blackstone
setblock 100 143 511 minecraft:blackstone
setblock 101 143 513 minecraft:blackstone
setblock 101 143 514 minecraft:smooth_basalt
setblock 102 143 513 minecraft:smooth_basalt
setblock 102 143 514 minecraft:blackstone
setblock 103 143 512 minecraft:smooth_basalt
setblock 103 143 513 minecraft:blackstone
setblock 104 143 511 minecraft:smooth_basalt
setblock 104 143 512 minecraft:blackstone
setblock 104 143 515 minecraft:blackstone
setblock 104 143 551 minecraft:smooth_basalt
fill 105 143 511 108 143 511 minecraft:blackstone
setblock 105 143 515 minecraft:smooth_basalt
setblock 105 143 550 minecraft:smooth_basalt
fill 105 143 551 108 143 551 minecraft:blackstone
setblock 106 143 514 minecraft:smooth_basalt
setblock 106 143 515 minecraft:blackstone
setblock 106 143 550 minecraft:blackstone
setblock 107 143 513 minecraft:smooth_basalt
setblock 107 143 514 minecraft:blackstone
setblock 108 143 512 minecraft:smooth_basalt
setblock 108 143 513 minecraft:blackstone
setblock 109 143 511 minecraft:smooth_basalt
setblock 109 143 512 minecraft:blackstone
setblock 109 143 551 minecraft:smooth_basalt
fill 110 143 511 113 143 511 minecraft:blackstone
setblock 110 143 551 minecraft:blackstone
setblock 113 143 512 minecraft:smooth_basalt
setblock 114 143 511 minecraft:smooth_basalt
setblock 114 143 551 minecraft:smooth_basalt
setblock 115 143 511 minecraft:blackstone
setblock 115 143 551 minecraft:blackstone
setblock 118 143 512 minecraft:smooth_basalt
setblock 119 143 511 minecraft:smooth_basalt
setblock 119 143 512 minecraft:blackstone
setblock 119 143 551 minecraft:smooth_basalt
setblock 120 143 511 minecraft:blackstone
setblock 120 143 550 minecraft:smooth_basalt
setblock 120 143 551 minecraft:blackstone
setblock 121 143 550 minecraft:blackstone
setblock 122 143 512 minecraft:blackstone
setblock 123 143 512 minecraft:smooth_basalt
setblock 124 143 511 minecraft:smooth_basalt
setblock 124 143 512 minecraft:blackstone
setblock 124 143 551 minecraft:smooth_basalt
setblock 125 143 511 minecraft:blackstone
setblock 125 143 550 minecraft:smooth_basalt
setblock 125 143 551 minecraft:blackstone
setblock 126 143 550 minecraft:blackstone
setblock 129 143 511 minecraft:smooth_basalt
setblock 129 143 551 minecraft:smooth_basalt
setblock 133 143 537 minecraft:smooth_basalt
setblock 133 143 538 minecraft:blackstone
setblock 134 143 536 minecraft:smooth_basalt
setblock 134 143 537 minecraft:blackstone
setblock 134 143 540 minecraft:blackstone
setblock 134 143 541 minecraft:smooth_basalt
setblock 135 143 514 minecraft:blackstone
setblock 135 143 515 minecraft:smooth_basalt
setblock 135 143 516 minecraft:blackstone
setblock 135 143 520 minecraft:smooth_basalt
fill 135 143 521 135 143 523 minecraft:blackstone
setblock 135 143 530 minecraft:smooth_basalt
setblock 135 143 531 minecraft:blackstone
setblock 135 143 535 minecraft:smooth_basalt
setblock 135 143 536 minecraft:blackstone
setblock 135 143 540 minecraft:smooth_basalt
setblock 135 143 541 minecraft:blackstone
fill 104 144 525 110 161 527 minecraft:jungle_log
fill 105 144 524 109 162 524 minecraft:jungle_log
fill 105 144 528 109 162 528 minecraft:jungle_log
fill 106 144 523 108 162 523 minecraft:jungle_log
fill 106 144 529 108 162 529 minecraft:jungle_log
fill 113 148 528 115 148 530 minecraft:redstone_block
fill 117 148 520 119 148 522 minecraft:redstone_block
fill 118 148 530 120 148 532 minecraft:redstone_block
fill 122 148 525 124 148 527 minecraft:redstone_block
fill 95 149 511 96 150 521 minecraft:black_concrete
fill 95 149 522 116 149 522 minecraft:gilded_blackstone
fill 95 149 523 96 150 533 minecraft:black_concrete
fill 95 149 534 135 150 534 minecraft:gilded_blackstone
fill 95 149 535 96 150 545 minecraft:black_concrete
fill 95 149 546 135 150 546 minecraft:gilded_blackstone
fill 95 149 547 96 150 551 minecraft:black_concrete
fill 97 149 511 97 150 521 minecraft:gold_block
fill 97 149 523 97 150 533 minecraft:gold_block
fill 97 149 535 97 150 545 minecraft:gold_block
fill 97 149 547 97 150 551 minecraft:gold_block
fill 98 149 511 99 150 521 minecraft:black_concrete
fill 98 149 523 99 150 533 minecraft:black_concrete
fill 98 149 535 99 150 545 minecraft:black_concrete
fill 98 149 547 99 150 551 minecraft:black_concrete
fill 100 149 511 100 150 521 minecraft:gold_block
fill 100 149 523 100 150 533 minecraft:gold_block
fill 100 149 535 100 150 545 minecraft:gold_block
fill 100 149 547 100 150 551 minecraft:gold_block
fill 101 149 511 102 150 521 minecraft:black_concrete
fill 101 149 523 102 150 533 minecraft:black_concrete
fill 101 149 535 102 150 545 minecraft:black_concrete
fill 101 149 547 102 150 551 minecraft:black_concrete
fill 103 149 511 103 150 521 minecraft:gold_block
fill 103 149 523 103 150 533 minecraft:gold_block
fill 103 149 535 103 150 545 minecraft:gold_block
fill 103 149 547 103 150 551 minecraft:gold_block
fill 104 149 511 105 150 521 minecraft:black_concrete
fill 104 149 523 104 150 524 minecraft:black_concrete
fill 104 149 528 104 150 533 minecraft:black_concrete
fill 104 149 535 105 150 545 minecraft:black_concrete
fill 104 149 547 105 150 551 minecraft:black_concrete
fill 105 149 523 105 150 523 minecraft:black_concrete
fill 105 149 529 105 150 533 minecraft:black_concrete
fill 106 149 511 106 150 521 minecraft:gold_block
fill 106 149 530 106 150 533 minecraft:gold_block
fill 106 149 535 106 150 545 minecraft:gold_block
fill 106 149 547 106 150 551 minecraft:gold_block
fill 107 149 511 108 150 521 minecraft:black_concrete
fill 107 149 530 108 150 533 minecraft:black_concrete
fill 107 149 535 108 150 545 minecraft:black_concrete
fill 107 149 547 108 150 551 minecraft:black_concrete
fill 109 149 511 109 150 521 minecraft:gold_block
fill 109 149 523 109 150 523 minecraft:gold_block
fill 109 149 529 109 150 533 minecraft:gold_block
fill 109 149 535 109 150 545 minecraft:gold_block
fill 109 149 547 109 150 551 minecraft:gold_block
fill 110 149 511 111 150 521 minecraft:black_concrete
fill 110 149 523 111 150 524 minecraft:black_concrete
fill 110 149 528 111 150 533 minecraft:black_concrete
fill 110 149 535 111 150 545 minecraft:black_concrete
fill 110 149 547 111 150 551 minecraft:black_concrete
fill 111 149 525 111 150 527 minecraft:black_concrete
fill 112 149 511 112 150 521 minecraft:gold_block
fill 112 149 523 112 149 533 minecraft:gold_block
fill 112 149 535 112 150 545 minecraft:gold_block
fill 112 149 547 112 150 551 minecraft:gold_block
fill 113 149 511 114 150 521 minecraft:black_concrete
fill 113 149 523 114 149 527 minecraft:black_concrete
setblock 113 149 529 minecraft:light[level=12]
fill 113 149 531 114 149 533 minecraft:black_concrete
fill 113 149 535 114 150 545 minecraft:black_concrete
fill 113 149 547 114 150 551 minecraft:black_concrete
fill 115 149 511 115 150 521 minecraft:gold_block
fill 115 149 523 115 149 527 minecraft:gold_block
fill 115 149 531 115 149 533 minecraft:gold_block
fill 115 149 535 115 150 545 minecraft:gold_block
fill 115 149 547 115 150 551 minecraft:gold_block
fill 116 149 511 116 149 521 minecraft:black_concrete
fill 116 149 523 116 149 533 minecraft:black_concrete
fill 116 149 535 117 150 545 minecraft:black_concrete
fill 116 149 547 117 150 551 minecraft:black_concrete
fill 117 149 511 117 149 519 minecraft:black_concrete
fill 117 149 523 117 149 524 minecraft:black_concrete
fill 117 149 528 117 149 533 minecraft:black_concrete
fill 118 149 511 118 149 519 minecraft:gold_block
fill 118 149 523 118 149 524 minecraft:gold_block
fill 118 149 528 118 149 529 minecraft:gold_block
setblock 118 149 533 minecraft:gold_block
fill 118 149 535 118 150 545 minecraft:gold_block
fill 118 149 547 118 150 551 minecraft:gold_block
fill 119 149 511 120 149 519 minecraft:black_concrete
fill 119 149 523 120 149 524 minecraft:black_concrete
fill 119 149 528 120 149 529 minecraft:black_concrete
fill 119 149 533 120 149 533 minecraft:black_concrete
fill 119 149 535 120 150 545 minecraft:black_concrete
fill 119 149 547 120 150 551 minecraft:black_concrete
fill 120 149 520 120 149 521 minecraft:black_concrete
fill 120 149 522 135 149 522 minecraft:gilded_blackstone
fill 120 149 525 120 149 527 minecraft:black_concrete
fill 121 149 511 121 150 521 minecraft:gold_block
fill 121 149 523 121 149 533 minecraft:gold_block
fill 121 149 535 121 150 545 minecraft:gold_block
fill 121 149 547 121 150 551 minecraft:gold_block
fill 122 149 511 123 150 521 minecraft:black_concrete
fill 122 149 523 123 149 524 minecraft:black_concrete
fill 122 149 528 123 149 533 minecraft:black_concrete
fill 122 149 535 123 150 545 minecraft:black_concrete
fill 122 149 547 123 150 551 minecraft:black_concrete
fill 124 149 511 124 150 521 minecraft:gold_block
fill 124 149 523 124 149 524 minecraft:gold_block
fill 124 149 528 124 149 533 minecraft:gold_block
fill 124 149 535 124 150 545 minecraft:gold_block
fill 124 149 547 124 150 551 minecraft:gold_block
fill 125 149 511 126 150 521 minecraft:black_concrete
fill 125 149 523 126 149 533 minecraft:black_concrete
fill 125 149 535 126 150 545 minecraft:black_concrete
fill 125 149 547 126 150 551 minecraft:black_concrete
fill 127 149 511 127 150 521 minecraft:gold_block
fill 127 149 523 127 150 533 minecraft:gold_block
fill 127 149 535 127 150 545 minecraft:gold_block
fill 127 149 547 127 150 551 minecraft:gold_block
fill 128 149 511 129 150 521 minecraft:black_concrete
fill 128 149 523 129 150 533 minecraft:black_concrete
fill 128 149 535 129 150 545 minecraft:black_concrete
fill 128 149 547 129 150 551 minecraft:black_concrete
fill 130 149 511 130 150 521 minecraft:gold_block
fill 130 149 523 130 150 533 minecraft:gold_block
fill 130 149 535 130 150 545 minecraft:gold_block
fill 130 149 547 130 150 551 minecraft:gold_block
fill 131 149 511 132 150 521 minecraft:black_concrete
fill 131 149 523 132 150 533 minecraft:black_concrete
fill 131 149 535 132 150 545 minecraft:black_concrete
fill 131 149 547 132 150 551 minecraft:black_concrete
fill 133 149 511 133 150 521 minecraft:gold_block
fill 133 149 523 133 150 533 minecraft:gold_block
fill 133 149 535 133 150 545 minecraft:gold_block
fill 133 149 547 133 150 551 minecraft:gold_block
fill 134 149 511 135 150 521 minecraft:black_concrete
fill 134 149 523 135 150 533 minecraft:black_concrete
fill 134 149 535 135 150 545 minecraft:black_concrete
fill 134 149 547 135 150 551 minecraft:black_concrete
fill 95 150 522 115 150 522 minecraft:gilded_blackstone
fill 112 150 523 112 150 526 minecraft:gold_block
fill 112 150 527 112 150 531 minecraft:shroomlight
fill 112 150 532 112 150 533 minecraft:gold_block
fill 113 150 523 114 150 526 minecraft:black_concrete
fill 113 150 527 115 150 527 minecraft:shroomlight
fill 113 150 528 115 150 530 minecraft:blackstone
fill 113 150 531 117 150 531 minecraft:shroomlight
fill 113 150 532 114 150 533 minecraft:black_concrete
fill 115 150 523 115 150 526 minecraft:gold_block
fill 115 150 532 115 150 533 minecraft:gold_block
fill 116 150 511 117 150 518 minecraft:black_concrete
fill 116 150 519 116 150 524 minecraft:shroomlight
fill 116 150 525 116 150 527 minecraft:ochre_froglight
fill 116 150 528 116 150 530 minecraft:shroomlight
fill 116 150 532 116 150 533 minecraft:black_concrete
fill 117 150 519 120 150 519 minecraft:shroomlight
fill 117 150 520 119 150 522 minecraft:blackstone
fill 117 150 523 120 150 523 minecraft:shroomlight
fill 117 150 524 119 150 524 minecraft:ochre_froglight
fill 117 150 528 119 150 528 minecraft:ochre_froglight
fill 117 150 529 117 150 530 minecraft:shroomlight
fill 117 150 532 117 150 533 minecraft:shroomlight
fill 118 150 511 118 150 518 minecraft:gold_block
fill 118 150 529 121 150 529 minecraft:shroomlight
fill 118 150 530 120 150 532 minecraft:blackstone
fill 118 150 533 121 150 533 minecraft:shroomlight
fill 119 150 511 120 150 518 minecraft:black_concrete
fill 120 150 520 120 150 522 minecraft:shroomlight
fill 120 150 524 125 150 524 minecraft:shroomlight
fill 120 150 525 120 150 527 minecraft:ochre_froglight
fill 120 150 528 125 150 528 minecraft:shroomlight
fill 121 150 522 135 150 522 minecraft:gilded_blackstone
setblock 121 150 523 minecraft:gold_block
fill 121 150 525 121 150 527 minecraft:shroomlight
fill 121 150 530 121 150 532 minecraft:shroomlight
fill 122 150 523 123 150 523 minecraft:black_concrete
fill 122 150 525 124 150 527 minecraft:blackstone
fill 122 150 529 123 150 533 minecraft:black_concrete
setblock 124 150 523 minecraft:gold_block
fill 124 150 529 124 150 533 minecraft:gold_block
fill 125 150 523 126 150 523 minecraft:black_concrete
fill 125 150 525 125 150 527 minecraft:shroomlight
fill 125 150 529 126 150 533 minecraft:black_concrete
fill 126 150 524 126 150 528 minecraft:black_concrete
fill 95 154 511 95 154 513 minecraft:blackstone
setblock 95 154 514 minecraft:smooth_basalt
fill 95 154 515 95 154 518 minecraft:blackstone
setblock 95 154 519 minecraft:smooth_basalt
fill 95 154 520 95 154 523 minecraft:blackstone
setblock 95 154 524 minecraft:smooth_basalt
fill 95 154 525 95 154 528 minecraft:blackstone
setblock 95 154 529 minecraft:smooth_basalt
fill 95 154 530 95 155 532 minecraft:blackstone
fill 95 154 540 95 154 543 minecraft:blackstone
setblock 95 154 544 minecraft:smooth_basalt
fill 95 154 545 95 154 548 minecraft:blackstone
setblock 95 154 549 minecraft:smooth_basalt
fill 95 154 550 97 154 551 minecraft:blackstone
fill 96 154 511 96 154 512 minecraft:blackstone
setblock 96 154 513 minecraft:smooth_basalt
fill 96 154 514 96 154 517 minecraft:blackstone
setblock 96 154 518 minecraft:smooth_basalt
fill 96 154 519 96 154 522 minecraft:blackstone
setblock 96 154 523 minecraft:smooth_basalt
fill 96 154 524 96 154 527 minecraft:blackstone
setblock 96 154 528 minecraft:smooth_basalt
fill 96 154 529 96 156 530 minecraft:blackstone
setblock 96 154 542 minecraft:blackstone
setblock 96 154 543 minecraft:smooth_basalt
fill 96 154 544 96 154 547 minecraft:blackstone
setblock 96 154 548 minecraft:smooth_basalt
fill 96 154 549 99 154 549 minecraft:blackstone
setblock 97 154 511 minecraft:blackstone
setblock 97 154 512 minecraft:smooth_basalt
fill 97 154 515 97 154 516 minecraft:blackstone
setblock 97 154 517 minecraft:smooth_basalt
fill 97 154 518 97 154 521 minecraft:blackstone
setblock 97 154 522 minecraft:smooth_basalt
fill 97 154 523 97 154 526 minecraft:blackstone
setblock 97 154 527 minecraft:smooth_basalt
fill 97 154 528 97 157 528 minecraft:blackstone
fill 97 154 544 97 154 546 minecraft:blackstone
setblock 97 154 547 minecraft:smooth_basalt
fill 97 154 548 97 157 548 minecraft:blackstone
setblock 98 154 511 minecraft:smooth_basalt
fill 98 154 512 98 156 513 minecraft:blackstone
setblock 98 154 521 minecraft:smooth_basalt
fill 98 154 522 98 154 525 minecraft:blackstone
setblock 98 154 550 minecraft:blackstone
setblock 98 154 551 minecraft:smooth_basalt
fill 99 154 511 101 154 512 minecraft:blackstone
setblock 99 154 550 minecraft:smooth_basalt
fill 99 154 551 102 154 551 minecraft:blackstone
setblock 100 154 549 minecraft:smooth_basalt
fill 100 154 550 103 154 550 minecraft:blackstone
fill 101 154 549 104 154 549 minecraft:blackstone
setblock 102 154 511 minecraft:blackstone
setblock 102 154 512 minecraft:smooth_basalt
setblock 103 154 511 minecraft:smooth_basalt
setblock 103 154 551 minecraft:smooth_basalt
fill 104 154 511 106 155 511 minecraft:blackstone
setblock 104 154 550 minecraft:smooth_basalt
fill 104 154 551 107 154 551 minecraft:blackstone
fill 105 154 550 108 154 550 minecraft:blackstone
setblock 108 154 551 minecraft:smooth_basalt
setblock 109 154 550 minecraft:smooth_basalt
fill 109 154 551 112 154 551 minecraft:blackstone
fill 110 154 550 113 154 550 minecraft:blackstone
fill 111 154 549 114 154 549 minecraft:blackstone
setblock 113 154 551 minecraft:smooth_basalt
fill 114 154 511 117 154 511 minecraft:blackstone
fill 114 154 548 115 154 548 minecraft:blackstone
setblock 114 154 550 minecraft:smooth_basalt
fill 114 154 551 117 154 551 minecraft:blackstone
setblock 115 154 549 minecraft:smooth_basalt
fill 115 154 550 118 154 550 minecraft:blackstone
setblock 116 154 548 minecraft:smooth_basalt
fill 116 154 549 119 154 549 minecraft:blackstone
fill 117 154 548 120 154 548 minecraft:blackstone
setblock 118 154 511 minecraft:smooth_basalt
setblock 118 154 551 minecraft:smooth_basalt
fill 119 154 511 120 156 511 minecraft:blackstone
setblock 119 154 550 minecraft:smooth_basalt
fill 119 154 551 122 154 551 minecraft:blackstone
setblock 120 154 549 minecraft:smooth_basalt
fill 120 154 550 123 154 550 minecraft:blackstone
fill 121 154 549 122 156 549 minecraft:blackstone
setblock 123 154 551 minecraft:smooth_basalt
fill 124 154 551 124 157 551 minecraft:blackstone
setblock 133 154 521 minecraft:smooth_basalt
fill 133 154 522 133 154 525 minecraft:blackstone
setblock 133 154 526 minecraft:smooth_basalt
fill 133 154 527 134 154 529 minecraft:blackstone
fill 134 154 518 134 154 519 minecraft:blackstone
setblock 134 154 520 minecraft:smooth_basalt
fill 134 154 521 134 154 524 minecraft:blackstone
setblock 134 154 525 minecraft:smooth_basalt
fill 134 154 526 135 156 526 minecraft:blackstone
setblock 134 154 530 minecraft:smooth_basalt
fill 134 154 531 135 155 532 minecraft:blackstone
fill 134 154 543 134 154 544 minecraft:blackstone
setblock 134 154 545 minecraft:smooth_basalt
fill 134 154 546 135 155 547 minecraft:blackstone
fill 134 154 551 135 156 551 minecraft:blackstone
fill 135 154 511 135 154 513 minecraft:blackstone
setblock 135 154 514 minecraft:smooth_basalt
fill 135 154 515 135 154 518 minecraft:blackstone
setblock 135 154 519 minecraft:smooth_basalt
fill 135 154 520 135 154 523 minecraft:blackstone
setblock 135 154 524 minecraft:smooth_basalt
fill 135 154 525 135 157 525 minecraft:blackstone
fill 135 154 527 135 154 528 minecraft:blackstone
setblock 135 154 529 minecraft:smooth_basalt
fill 135 154 530 135 157 530 minecraft:blackstone
setblock 135 154 533 minecraft:blackstone
setblock 135 154 534 minecraft:smooth_basalt
fill 135 154 535 135 154 538 minecraft:blackstone
setblock 135 154 539 minecraft:smooth_basalt
fill 135 154 540 135 154 543 minecraft:blackstone
setblock 135 154 544 minecraft:smooth_basalt
fill 135 154 545 135 157 545 minecraft:blackstone
setblock 135 154 548 minecraft:blackstone
setblock 135 154 549 minecraft:smooth_basalt
fill 135 154 550 135 157 550 minecraft:blackstone
fill 95 155 511 95 155 512 minecraft:blackstone
setblock 95 155 513 minecraft:smooth_basalt
fill 95 155 514 95 155 517 minecraft:blackstone
setblock 95 155 518 minecraft:smooth_basalt
fill 95 155 519 95 155 522 minecraft:blackstone
setblock 95 155 523 minecraft:smooth_basalt
fill 95 155 524 95 155 527 minecraft:blackstone
setblock 95 155 528 minecraft:smooth_basalt
fill 95 155 529 95 158 529 minecraft:blackstone
setblock 95 155 533 minecraft:smooth_basalt
fill 95 155 534 95 158 534 minecraft:blackstone
fill 95 155 539 95 155 542 minecraft:blackstone
setblock 95 155 543 minecraft:smooth_basalt
fill 95 155 544 95 155 547 minecraft:blackstone
setblock 95 155 548 minecraft:smooth_basalt
fill 95 155 549 96 155 551 minecraft:blackstone
setblock 96 155 511 minecraft:blackstone
setblock 96 155 512 minecraft:smooth_basalt
fill 96 155 513 96 155 516 minecraft:blackstone
setblock 96 155 517 minecraft:smooth_basalt
fill 96 155 518 96 155 521 minecraft:blackstone
setblock 96 155 522 minecraft:smooth_basalt
fill 96 155 523 96 155 526 minecraft:blackstone
setblock 96 155 527 minecraft:smooth_basalt
fill 96 155 528 96 158 528 minecraft:blackstone
setblock 96 155 531 minecraft:blackstone
setblock 96 155 542 minecraft:smooth_basalt
fill 96 155 543 96 155 546 minecraft:blackstone
setblock 96 155 547 minecraft:smooth_basalt
fill 96 155 548 96 158 548 minecraft:blackstone
setblock 97 155 511 minecraft:smooth_basalt
fill 97 155 512 97 155 515 minecraft:blackstone
setblock 97 155 516 minecraft:smooth_basalt
fill 97 155 517 97 155 520 minecraft:blackstone
setblock 97 155 521 minecraft:smooth_basalt
fill 97 155 522 97 155 525 minecraft:blackstone
setblock 97 155 526 minecraft:smooth_basalt
fill 97 155 527 97 158 527 minecraft:blackstone
fill 97 155 529 97 156 529 minecraft:blackstone
fill 97 155 544 97 155 545 minecraft:blackstone
setblock 97 155 546 minecraft:smooth_basalt
fill 97 155 547 98 157 547 minecraft:blackstone
fill 97 155 549 97 155 550 minecraft:blackstone
setblock 97 155 551 minecraft:smooth_basalt
fill 98 155 511 101 155 511 minecraft:blackstone
fill 98 155 521 98 155 524 minecraft:blackstone
setblock 98 155 525 minecraft:smooth_basalt
fill 98 155 548 98 155 549 minecraft:blackstone
setblock 98 155 550 minecraft:smooth_basalt
fill 98 155 551 101 155 551 minecraft:blackstone
fill 99 155 512 99 155 513 minecraft:blackstone
setblock 99 155 548 minecraft:blackstone
setblock 99 155 549 minecraft:smooth_basalt
fill 99 155 550 102 155 550 minecraft:blackstone
setblock 100 155 512 minecraft:blackstone
setblock 100 155 548 minecraft:smooth_basalt
fill 100 155 549 103 155 549 minecraft:blackstone
setblock 101 155 512 minecraft:smooth_basalt
setblock 102 155 511 minecraft:smooth_basalt
fill 102 155 512 102 158 512 minecraft:blackstone
setblock 102 155 551 minecraft:smooth_basalt
fill 103 155 511 103 158 511 minecraft:blackstone
setblock 103 155 550 minecraft:smooth_basalt
fill 103 155 551 106 155 551 minecraft:blackstone
setblock 104 155 549 minecraft:smooth_basalt
fill 104 155 550 107 155 550 minecraft:blackstone
fill 105 155 549 105 158 549 minecraft:blackstone
setblock 107 155 551 minecraft:smooth_basalt
setblock 108 155 550 minecraft:smooth_basalt
fill 108 155 551 111 155 551 minecraft:blackstone
setblock 109 155 549 minecraft:smooth_basalt
fill 109 155 550 112 155 550 minecraft:blackstone
fill 110 155 549 113 155 549 minecraft:blackstone
setblock 112 155 511 minecraft:smooth_basalt
setblock 112 155 551 minecraft:smooth_basalt
fill 113 155 511 116 155 511 minecraft:blackstone
fill 113 155 548 114 155 548 minecraft:blackstone
setblock 113 155 550 minecraft:smooth_basalt
fill 113 155 551 116 155 551 minecraft:blackstone
setblock 114 155 549 minecraft:smooth_basalt
fill 114 155 550 117 155 550 minecraft:blackstone
setblock 115 155 548 minecraft:smooth_basalt
fill 115 155 549 118 155 549 minecraft:blackstone
setblock 116 155 547 minecraft:smooth_basalt
fill 116 155 548 119 155 548 minecraft:blackstone
setblock 117 155 511 minecraft:smooth_basalt
fill 117 155 547 117 156 547 minecraft:blackstone
setblock 117 155 551 minecraft:smooth_basalt
fill 118 155 511 118 158 511 minecraft:blackstone
setblock 118 155 550 minecraft:smooth_basalt
fill 118 155 551 121 155 551 minecraft:blackstone
setblock 119 155 549 minecraft:smooth_basalt
fill 119 155 550 122 155 550 minecraft:blackstone
setblock 120 155 548 minecraft:smooth_basalt
fill 120 155 549 120 158 549 minecraft:blackstone
setblock 122 155 551 minecraft:smooth_basalt
setblock 123 155 550 minecraft:smooth_basalt
fill 123 155 551 123 158 551 minecraft:blackstone
fill 125 155 551 125 156 551 minecraft:blackstone
setblock 132 155 551 minecraft:smooth_basalt
fill 133 155 511 135 156 511 minecraft:blackstone
fill 133 155 521 133 155 524 minecraft:blackstone
setblock 133 155 525 minecraft:smooth_basalt
fill 133 155 526 133 155 529 minecraft:blackstone
setblock 133 155 530 minecraft:smooth_basalt
fill 133 155 551 133 158 551 minecraft:blackstone
fill 134 155 517 134 155 518 minecraft:blackstone
setblock 134 155 519 minecraft:smooth_basalt
fill 134 155 520 134 155 523 minecraft:blackstone
setblock 134 155 524 minecraft:smooth_basalt
fill 134 155 525 134 158 525 minecraft:blackstone
fill 134 155 527 134 155 528 minecraft:blackstone
setblock 134 155 529 minecraft:smooth_basalt
fill 134 155 530 134 158 530 minecraft:blackstone
setblock 134 155 533 minecraft:blackstone
setblock 134 155 543 minecraft:blackstone
setblock 134 155 544 minecraft:smooth_basalt
fill 134 155 545 134 158 545 minecraft:blackstone
setblock 134 155 548 minecraft:blackstone
setblock 134 155 549 minecraft:smooth_basalt
setblock 135 155 512 minecraft:blackstone
setblock 135 155 513 minecraft:smooth_basalt
fill 135 155 514 135 155 517 minecraft:blackstone
setblock 135 155 518 minecraft:smooth_basalt
fill 135 155 519 135 155 522 minecraft:blackstone
setblock 135 155 523 minecraft:smooth_basalt
fill 135 155 524 135 158 524 minecraft:blackstone
setblock 135 155 527 minecraft:blackstone
setblock 135 155 528 minecraft:smooth_basalt
fill 135 155 529 135 158 529 minecraft:blackstone
setblock 135 155 533 minecraft:smooth_basalt
fill 135 155 534 135 155 537 minecraft:blackstone
setblock 135 155 538 minecraft:smooth_basalt
fill 135 155 539 135 155 542 minecraft:blackstone
setblock 135 155 543 minecraft:smooth_basalt
fill 135 155 544 135 158 544 minecraft:blackstone
setblock 135 155 548 minecraft:smooth_basalt
fill 135 155 549 135 158 549 minecraft:blackstone
setblock 95 156 511 minecraft:blackstone
setblock 95 156 512 minecraft:smooth_basalt
fill 95 156 513 95 156 516 minecraft:blackstone
setblock 95 156 517 minecraft:smooth_basalt
fill 95 156 518 95 156 521 minecraft:blackstone
setblock 95 156 522 minecraft:smooth_basalt
fill 95 156 523 95 156 526 minecraft:blackstone
setblock 95 156 527 minecraft:smooth_basalt
fill 95 156 528 95 159 528 minecraft:blackstone
fill 95 156 530 95 156 531 minecraft:blackstone
setblock 95 156 532 minecraft:smooth_basalt
fill 95 156 533 95 159 533 minecraft:blackstone
fill 95 156 535 95 157 535 minecraft:blackstone
fill 95 156 539 95 156 541 minecraft:blackstone
setblock 95 156 542 minecraft:smooth_basalt
fill 95 156 543 95 156 546 minecraft:blackstone
setblock 95 156 547 minecraft:smooth_basalt
fill 95 156 548 95 156 551 minecraft:blackstone
setblock 96 156 511 minecraft:smooth_basalt
fill 96 156 512 96 156 515 minecraft:blackstone
setblock 96 156 516 minecraft:smooth_basalt
fill 96 156 517 96 156 520 minecraft:blackstone
setblock 96 156 521 minecraft:smooth_basalt
fill 96 156 522 96 156 525 minecraft:blackstone
setblock 96 156 526 minecraft:smooth_basalt
fill 96 156 527 96 159 527 minecraft:blackstone
setblock 96 156 531 minecraft:smooth_basalt
fill 96 156 532 96 159 532 minecraft:blackstone
fill 96 156 542 96 156 545 minecraft:blackstone
setblock 96 156 546 minecraft:smooth_basalt
fill 96 156 547 96 159 547 minecraft:blackstone
fill 96 156 549 96 156 550 minecraft:blackstone
setblock 96 156 551 minecraft:smooth_basalt
fill 97 156 511 97 156 514 minecraft:blackstone
setblock 97 156 515 minecraft:smooth_basalt
fill 97 156 516 97 156 519 minecraft:blackstone
setblock 97 156 520 minecraft:smooth_basalt
fill 97 156 521 97 156 524 minecraft:blackstone
setblock 97 156 525 minecraft:smooth_basalt
fill 97 156 526 97 159 526 minecraft:blackstone
setblock 97 156 544 minecraft:blackstone
setblock 97 156 545 minecraft:smooth_basalt
fill 97 156 546 97 159 546 minecraft:blackstone
setblock 97 156 549 minecraft:blackstone
setblock 97 156 550 minecraft:smooth_basalt
fill 97 156 551 100 156 551 minecraft:blackstone
fill 98 156 511 100 156 511 minecraft:blackstone
setblock 98 156 523 minecraft:blackstone
setblock 98 156 524 minecraft:smooth_basalt
setblock 98 156 525 minecraft:blackstone
setblock 98 156 548 minecraft:blackstone
setblock 98 156 549 minecraft:smooth_basalt
fill 98 156 550 101 156 550 minecraft:blackstone
setblock 99 156 512 minecraft:blackstone
setblock 99 156 513 minecraft:smooth_basalt
setblock 99 156 548 minecraft:smooth_basalt
fill 99 156 549 102 156 549 minecraft:blackstone
setblock 100 156 512 minecraft:smooth_basalt
fill 100 156 548 101 156 548 minecraft:blackstone
setblock 101 156 511 minecraft:smooth_basalt
fill 101 156 512 101 159 512 minecraft:blackstone
setblock 101 156 551 minecraft:smooth_basalt
fill 102 156 511 102 159 511 minecraft:blackstone
setblock 102 156 550 minecraft:smooth_basalt
fill 102 156 551 105 156 551 minecraft:blackstone
setblock 103 156 549 minecraft:smooth_basalt
fill 103 156 550 106 156 550 minecraft:blackstone
fill 104 156 511 105 156 511 minecraft:blackstone
fill 104 156 549 104 158 549 minecraft:blackstone
setblock 106 156 511 minecraft:smooth_basalt
fill 106 156 549 107 156 549 minecraft:blackstone
setblock 106 156 551 minecraft:smooth_basalt
fill 107 156 511 110 156 511 minecraft:blackstone
setblock 107 156 550 minecraft:smooth_basalt
fill 107 156 551 110 156 551 minecraft:blackstone
setblock 108 156 549 minecraft:smooth_basalt
fill 108 156 550 111 156 550 minecraft:blackstone
fill 109 156 549 112 156 549 minecraft:blackstone
setblock 111 156 511 minecraft:smooth_basalt
setblock 111 156 548 minecraft:gold_block
setblock 111 156 551 minecraft:smooth_basalt
fill 112 156 511 115 156 511 minecraft:blackstone
fill 112 156 548 113 156 548 minecraft:blackstone
setblock 112 156 550 minecraft:smooth_basalt
fill 112 156 551 115 156 551 minecraft:blackstone
setblock 113 156 549 minecraft:smooth_basalt
fill 113 156 550 116 156 550 minecraft:blackstone
setblock 114 156 548 minecraft:smooth_basalt
fill 114 156 549 117 156 549 minecraft:blackstone
setblock 115 156 547 minecraft:smooth_basalt
fill 115 156 548 118 156 548 minecraft:blackstone
setblock 116 156 511 minecraft:smooth_basalt
fill 116 156 547 116 157 547 minecraft:blackstone
setblock 116 156 551 minecraft:smooth_basalt
fill 117 156 511 117 159 511 minecraft:blackstone
setblock 117 156 550 minecraft:smooth_basalt
fill 117 156 551 120 156 551 minecraft:blackstone
setblock 118 156 549 minecraft:smooth_basalt
fill 118 156 550 121 156 550 minecraft:blackstone
setblock 119 156 548 minecraft:smooth_basalt
fill 119 156 549 119 159 549 minecraft:blackstone
setblock 120 156 548 minecraft:blackstone
setblock 121 156 511 minecraft:smooth_basalt
setblock 121 156 551 minecraft:smooth_basalt
setblock 122 156 550 minecraft:smooth_basalt
fill 122 156 551 122 159 551 minecraft:blackstone
fill 123 156 550 123 157 550 minecraft:blackstone
setblock 131 156 551 minecraft:smooth_basalt
fill 132 156 511 132 159 511 minecraft:blackstone
setblock 132 156 524 minecraft:blackstone
setblock 132 156 525 minecraft:smooth_basalt
fill 132 156 526 133 157 527 minecraft:blackstone
fill 132 156 551 132 159 551 minecraft:blackstone
fill 133 156 520 133 156 523 minecraft:blackstone
setblock 133 156 524 minecraft:smooth_basalt
fill 133 156 525 133 159 525 minecraft:blackstone
setblock 133 156 528 minecraft:blackstone
setblock 133 156 529 minecraft:smooth_basalt
fill 133 156 530 133 158 531 minecraft:blackstone
fill 133 156 550 134 158 550 minecraft:blackstone
fill 134 156 516 134 156 517 minecraft:blackstone
setblock 134 156 518 minecraft:smooth_basalt
fill 134 156 519 134 156 522 minecraft:blackstone
setblock 134 156 523 minecraft:smooth_basalt
fill 134 156 524 134 159 524 minecraft:blackstone
setblock 134 156 527 minecraft:blackstone
setblock 134 156 528 minecraft:smooth_basalt
fill 134 156 529 134 159 529 minecraft:blackstone
fill 134 156 531 134 156 532 minecraft:blackstone
setblock 134 156 533 minecraft:smooth_basalt
fill 134 156 534 135 158 534 minecraft:blackstone
setblock 134 156 543 minecraft:smooth_basalt
fill 134 156 544 134 157 544 minecraft:blackstone
fill 134 156 546 134 156 547 minecraft:blackstone
setblock 134 156 548 minecraft:smooth_basalt
fill 134 156 549 134 159 549 minecraft:blackstone
setblock 135 156 512 minecraft:smooth_basalt
fill 135 156 513 135 156 516 minecraft:blackstone
setblock 135 156 517 minecraft:smooth_basalt
fill 135 156 518 135 156 521 minecraft:blackstone
setblock 135 156 522 minecraft:smooth_basalt
fill 135 156 523 135 159 523 minecraft:blackstone
setblock 135 156 527 minecraft:smooth_basalt
fill 135 156 528 135 159 528 minecraft:blackstone
setblock 135 156 531 minecraft:blackstone
setblock 135 156 532 minecraft:smooth_basalt
fill 135 156 533 135 159 533 minecraft:blackstone
fill 135 156 535 135 156 536 minecraft:blackstone
setblock 135 156 537 minecraft:smooth_basalt
fill 135 156 538 135 156 541 minecraft:blackstone
setblock 135 156 542 minecraft:smooth_basalt
fill 135 156 543 135 159 543 minecraft:blackstone
setblock 135 156 546 minecraft:blackstone
setblock 135 156 547 minecraft:smooth_basalt
fill 135 156 548 135 159 548 minecraft:blackstone
setblock 95 157 511 minecraft:smooth_basalt
fill 95 157 512 95 157 515 minecraft:blackstone
setblock 95 157 516 minecraft:smooth_basalt
fill 95 157 517 95 157 520 minecraft:blackstone
setblock 95 157 521 minecraft:smooth_basalt
fill 95 157 522 95 157 525 minecraft:blackstone
setblock 95 157 526 minecraft:smooth_basalt
fill 95 157 527 95 160 527 minecraft:blackstone
setblock 95 157 530 minecraft:blackstone
setblock 95 157 531 minecraft:smooth_basalt
fill 95 157 532 95 160 532 minecraft:blackstone
setblock 95 157 536 minecraft:smooth_basalt
fill 95 157 539 95 157 540 minecraft:blackstone
setblock 95 157 541 minecraft:smooth_basalt
fill 95 157 542 95 157 545 minecraft:blackstone
setblock 95 157 546 minecraft:smooth_basalt
fill 95 157 547 95 157 550 minecraft:blackstone
setblock 95 157 551 minecraft:smooth_basalt
fill 96 157 511 96 157 514 minecraft:blackstone
setblock 96 157 515 minecraft:smooth_basalt
fill 96 157 516 96 157 519 minecraft:blackstone
setblock 96 157 520 minecraft:smooth_basalt
fill 96 157 521 96 157 524 minecraft:blackstone
setblock 96 157 525 minecraft:smooth_basalt
fill 96 157 526 96 160 526 minecraft:blackstone
setblock 96 157 529 minecraft:blackstone
setblock 96 157 530 minecraft:smooth_basalt
fill 96 157 531 96 160 531 minecraft:blackstone
fill 96 157 542 96 157 544 minecraft:blackstone
setblock 96 157 545 minecraft:smooth_basalt
fill 96 157 546 96 160 546 minecraft:blackstone
setblock 96 157 549 minecraft:blackstone
setblock 96 157 550 minecraft:smooth_basalt
fill 96 157 551 99 157 551 minecraft:blackstone
fill 97 157 511 97 157 513 minecraft:blackstone
setblock 97 157 514 minecraft:smooth_basalt
fill 97 157 515 97 157 518 minecraft:blackstone
setblock 97 157 519 minecraft:smooth_basalt
fill 97 157 520 97 157 523 minecraft:blackstone
setblock 97 157 524 minecraft:smooth_basalt
fill 97 157 525 97 159 525 minecraft:blackstone
setblock 97 157 529 minecraft:smooth_basalt
setblock 97 157 530 minecraft:blackstone
setblock 97 157 537 minecraft:light[level=12]
setblock 97 157 544 minecraft:smooth_basalt
fill 97 157 545 97 158 545 minecraft:blackstone
setblock 97 157 549 minecraft:smooth_basalt
fill 97 157 550 100 157 550 minecraft:blackstone
fill 98 157 511 98 157 512 minecraft:blackstone
setblock 98 157 513 minecraft:smooth_basalt
setblock 98 157 548 minecraft:smooth_basalt
fill 98 157 549 101 157 549 minecraft:blackstone
setblock 99 157 511 minecraft:blackstone
setblock 99 157 512 minecraft:smooth_basalt
fill 99 157 513 99 158 513 minecraft:blackstone
fill 99 157 548 100 157 548 minecraft:blackstone
setblock 100 157 511 minecraft:smooth_basalt
fill 100 157 512 100 160 512 minecraft:blackstone
setblock 100 157 551 minecraft:smooth_basalt
fill 101 157 511 101 160 511 minecraft:blackstone
setblock 101 157 550 minecraft:smooth_basalt
fill 101 157 551 104 157 551 minecraft:blackstone
setblock 102 157 549 minecraft:smooth_basalt
fill 102 157 550 105 157 550 minecraft:blackstone
fill 103 157 549 103 159 549 minecraft:blackstone
setblock 104 157 511 minecraft:blackstone
setblock 105 157 511 minecraft:smooth_basalt
setblock 105 157 513 minecraft:light[level=12]
setblock 105 157 521 minecraft:light[level=12]
setblock 105 157 529 minecraft:light[level=12]
setblock 105 157 537 minecraft:light[level=12]
setblock 105 157 545 minecraft:light[level=12]
setblock 105 157 551 minecraft:smooth_basalt
fill 106 157 511 109 157 511 minecraft:blackstone
setblock 106 157 549 minecraft:blackstone
setblock 106 157 550 minecraft:smooth_basalt
fill 106 157 551 109 157 551 minecraft:blackstone
setblock 107 157 549 minecraft:smooth_basalt
fill 107 157 550 110 157 550 minecraft:blackstone
fill 108 157 549 111 157 549 minecraft:blackstone
setblock 110 157 511 minecraft:smooth_basalt
setblock 110 157 551 minecraft:smooth_basalt
fill 111 157 511 114 157 511 minecraft:blackstone
fill 111 157 548 112 157 548 minecraft:blackstone
setblock 111 157 550 minecraft:smooth_basalt
fill 111 157 551 114 157 551 minecraft:blackstone
setblock 112 157 549 minecraft:smooth_basalt
fill 112 157 550 115 157 550 minecraft:blackstone
setblock 113 157 513 minecraft:light[level=12]
setblock 113 157 521 minecraft:light[level=12]
setblock 113 157 529 minecraft:light[level=12]
setblock 113 157 537 minecraft:light[level=12]
setblock 113 157 545 minecraft:light[level=12]
setblock 113 157 548 minecraft:smooth_basalt
fill 113 157 549 116 157 549 minecraft:blackstone
fill 114 157 548 117 157 548 minecraft:blackstone
setblock 115 157 511 minecraft:smooth_basalt
setblock 115 157 547 minecraft:blackstone
setblock 115 157 551 minecraft:smooth_basalt
fill 116 157 511 116 160 511 minecraft:blackstone
setblock 116 157 550 minecraft:smooth_basalt
fill 116 157 551 119 157 551 minecraft:blackstone
setblock 117 157 549 minecraft:smooth_basalt
fill 117 157 550 120 157 550 minecraft:blackstone
setblock 118 157 548 minecraft:smooth_basalt
fill 118 157 549 118 160 549 minecraft:blackstone
setblock 119 157 511 minecraft:blackstone
setblock 119 157 548 minecraft:blackstone
setblock 120 157 511 minecraft:smooth_basalt
setblock 120 157 551 minecraft:smooth_basalt
setblock 121 157 511 minecraft:blackstone
setblock 121 157 513 minecraft:light[level=12]
setblock 121 157 521 minecraft:light[level=12]
setblock 121 157 529 minecraft:light[level=12]
setblock 121 157 537 minecraft:light[level=12]
setblock 121 157 545 minecraft:light[level=12]
setblock 121 157 549 minecraft:blackstone
setblock 121 157 550 minecraft:smooth_basalt
fill 121 157 551 121 160 551 minecraft:blackstone
fill 122 157 550 122 158 550 minecraft:blackstone
setblock 125 157 551 minecraft:smooth_basalt
setblock 129 157 513 minecraft:light[level=12]
setblock 129 157 521 minecraft:light[level=12]
setblock 129 157 529 minecraft:light[level=12]
setblock 129 157 537 minecraft:light[level=12]
setblock 129 157 545 minecraft:light[level=12]
setblock 130 157 551 minecraft:smooth_basalt
fill 131 157 511 131 160 511 minecraft:blackstone
fill 131 157 551 131 160 551 minecraft:blackstone
setblock 132 157 524 minecraft:smooth_basalt
fill 132 157 525 132 159 525 minecraft:blackstone
setblock 132 157 528 minecraft:blackstone
fill 132 157 550 132 160 550 minecraft:blackstone
fill 133 157 511 134 157 511 minecraft:blackstone
fill 133 157 520 133 157 522 minecraft:blackstone
setblock 133 157 523 minecraft:smooth_basalt
fill 133 157 524 133 160 524 minecraft:blackstone
setblock 133 157 528 minecraft:smooth_basalt
fill 133 157 529 133 160 529 minecraft:blackstone
setblock 133 157 532 minecraft:blackstone
setblock 134 157 512 minecraft:smooth_basalt
fill 134 157 513 134 157 516 minecraft:blackstone
setblock 134 157 517 minecraft:smooth_basalt
fill 134 157 518 134 157 521 minecraft:blackstone
setblock 134 157 522 minecraft:smooth_basalt
fill 134 157 523 134 160 523 minecraft:blackstone
setblock 134 157 526 minecraft:blackstone
setblock 134 157 527 minecraft:smooth_basalt
fill 134 157 528 134 160 528 minecraft:blackstone
setblock 134 157 531 minecraft:blackstone
setblock 134 157 532 minecraft:smooth_basalt
fill 134 157 533 134 160 533 minecraft:blackstone
setblock 134 157 546 minecraft:blackstone
setblock 134 157 547 minecraft:smooth_basalt
fill 134 157 548 134 160 548 minecraft:blackstone
setblock 134 157 551 minecraft:blackstone
setblock 135 157 511 minecraft:smooth_basalt
fill 135 157 512 135 157 515 minecraft:blackstone
setblock 135 157 516 minecraft:smooth_basalt
fill 135 157 517 135 157 520 minecraft:blackstone
setblock 135 157 521 minecraft:smooth_basalt
fill 135 157 522 135 160 522 minecraft:blackstone
setblock 135 157 526 minecraft:smooth_basalt
fill 135 157 527 135 160 527 minecraft:blackstone
setblock 135 157 531 minecraft:smooth_basalt
fill 135 157 532 135 160 532 minecraft:blackstone
setblock 135 157 535 minecraft:blackstone
setblock 135 157 536 minecraft:smooth_basalt
fill 135 157 537 135 157 540 minecraft:blackstone
setblock 135 157 541 minecraft:smooth_basalt
fill 135 157 542 135 159 542 minecraft:blackstone
setblock 135 157 546 minecraft:smooth_basalt
fill 135 157 547 135 160 547 minecraft:blackstone
setblock 135 157 551 minecraft:smooth_basalt
fill 95 158 511 95 158 514 minecraft:blackstone
setblock 95 158 515 minecraft:smooth_basalt
fill 95 158 516 95 158 519 minecraft:blackstone
setblock 95 158 520 minecraft:smooth_basalt
fill 95 158 521 95 158 524 minecraft:blackstone
setblock 95 158 525 minecraft:smooth_basalt
fill 95 158 526 95 161 526 minecraft:blackstone
setblock 95 158 530 minecraft:smooth_basalt
fill 95 158 531 95 161 531 minecraft:blackstone
setblock 95 158 535 minecraft:smooth_basalt
fill 95 158 536 95 160 536 minecraft:blackstone
setblock 95 158 540 minecraft:smooth_basalt
fill 95 158 541 95 158 544 minecraft:blackstone
setblock 95 158 545 minecraft:smooth_basalt
fill 95 158 546 95 158 549 minecraft:blackstone
setblock 95 158 550 minecraft:smooth_basalt
fill 95 158 551 98 158 551 minecraft:blackstone
fill 96 158 511 96 158 513 minecraft:blackstone
setblock 96 158 514 minecraft:smooth_basalt
fill 96 158 515 96 158 518 minecraft:blackstone
setblock 96 158 519 minecraft:smooth_basalt
fill 96 158 520 96 158 523 minecraft:blackstone
setblock 96 158 524 minecraft:smooth_basalt
fill 96 158 525 96 161 525 minecraft:blackstone
setblock 96 158 529 minecraft:smooth_basalt
fill 96 158 530 96 161 530 minecraft:blackstone
setblock 96 158 533 minecraft:blackstone
setblock 96 158 543 minecraft:blackstone
setblock 96 158 544 minecraft:smooth_basalt
fill 96 158 545 96 160 545 minecraft:blackstone
setblock 96 158 549 minecraft:smooth_basalt
fill 96 158 550 99 158 550 minecraft:blackstone
fill 97 158 511 97 158 512 minecraft:blackstone
setblock 97 158 513 minecraft:smooth_basalt
fill 97 158 514 97 158 515 minecraft:blackstone
fill 97 158 521 97 158 522 minecraft:blackstone
setblock 97 158 523 minecraft:smooth_basalt
fill 97 158 524 97 159 524 minecraft:blackstone
setblock 97 158 528 minecraft:smooth_basalt
fill 97 158 529 97 159 529 minecraft:blackstone
setblock 97 158 547 minecraft:blackstone
setblock 97 158 548 minecraft:smooth_basalt
fill 97 158 549 100 158 549 minecraft:blackstone
setblock 98 158 511 minecraft:blackstone
setblock 98 158 512 minecraft:smooth_basalt
fill 98 158 513 98 159 513 minecraft:blackstone
fill 98 158 548 99 158 548 minecraft:blackstone
setblock 99 158 511 minecraft:smooth_basalt
fill 99 158 512 99 161 512 minecraft:blackstone
setblock 99 158 551 minecraft:smooth_basalt
fill 100 158 511 100 161 511 minecraft:blackstone
setblock 100 158 550 minecraft:smooth_basalt
fill 100 158 551 103 158 551 minecraft:blackstone
setblock 101 158 549 minecraft:smooth_basalt
fill 101 158 550 104 158 550 minecraft:blackstone
fill 102 158 549 102 159 549 minecraft:blackstone
setblock 104 158 511 minecraft:smooth_basalt
setblock 104 158 551 minecraft:smooth_basalt
fill 105 158 511 108 158 511 minecraft:blackstone
setblock 105 158 550 minecraft:smooth_basalt
fill 105 158 551 108 158 551 minecraft:blackstone
setblock 106 158 549 minecraft:smooth_basalt
fill 106 158 550 109 158 550 minecraft:blackstone
fill 107 158 549 110 158 549 minecraft:blackstone
setblock 109 158 511 minecraft:smooth_basalt
setblock 109 158 551 minecraft:smooth_basalt
fill 110 158 511 113 158 511 minecraft:blackstone
setblock 110 158 550 minecraft:smooth_basalt
fill 110 158 551 113 158 551 minecraft:blackstone
setblock 111 158 548 minecraft:blackstone
setblock 111 158 549 minecraft:smooth_basalt
fill 111 158 550 114 158 550 minecraft:blackstone
setblock 112 158 548 minecraft:smooth_basalt
fill 112 158 549 115 158 549 minecraft:blackstone
fill 113 158 548 116 158 548 minecraft:blackstone
setblock 114 158 511 minecraft:smooth_basalt
setblock 114 158 551 minecraft:smooth_basalt
fill 115 158 511 115 161 511 minecraft:blackstone
setblock 115 158 550 minecraft:smooth_basalt
fill 115 158 551 118 158 551 minecraft:blackstone
setblock 116 158 549 minecraft:smooth_basalt
fill 116 158 550 119 158 550 minecraft:blackstone
setblock 117 158 548 minecraft:smooth_basalt
fill 117 158 549 117 161 549 minecraft:blackstone
setblock 118 158 548 minecraft:blackstone
setblock 119 158 511 minecraft:smooth_basalt
setblock 119 158 551 minecraft:smooth_basalt
fill 120 158 511 120 159 511 minecraft:blackstone
setblock 120 158 550 minecraft:smooth_basalt
fill 120 158 551 120 161 551 minecraft:blackstone
fill 121 158 550 121 159 550 minecraft:blackstone
setblock 124 158 551 minecraft:smooth_basalt
setblock 125 158 551 minecraft:blackstone
setblock 129 158 551 minecraft:smooth_basalt
fill 130 158 511 130 161 511 minecraft:blackstone
fill 130 158 551 130 161 551 minecraft:blackstone
fill 132 158 526 132 158 527 minecraft:blackstone
setblock 132 158 528 minecraft:smooth_basalt
fill 132 158 529 132 160 529 minecraft:blackstone
setblock 133 158 511 minecraft:blackstone
setblock 133 158 512 minecraft:smooth_basalt
setblock 133 158 521 minecraft:blackstone
setblock 133 158 522 minecraft:smooth_basalt
fill 133 158 523 133 161 523 minecraft:blackstone
setblock 133 158 526 minecraft:blackstone
setblock 133 158 527 minecraft:smooth_basalt
fill 133 158 528 133 161 528 minecraft:blackstone
setblock 133 158 532 minecraft:smooth_basalt
setblock 134 158 511 minecraft:smooth_basalt
fill 134 158 512 134 158 515 minecraft:blackstone
setblock 134 158 516 minecraft:smooth_basalt
fill 134 158 517 134 158 520 minecraft:blackstone
setblock 134 158 521 minecraft:smooth_basalt
fill 134 158 522 134 161 522 minecraft:blackstone
setblock 134 158 526 minecraft:smooth_basalt
fill 134 158 527 134 161 527 minecraft:blackstone
setblock 134 158 531 minecraft:smooth_basalt
fill 134 158 532 134 161 532 minecraft:blackstone
setblock 134 158 535 minecraft:blackstone
setblock 134 158 546 minecraft:smooth_basalt
fill 134 158 547 134 160 547 minecraft:blackstone
setblock 134 158 551 minecraft:smooth_basalt
fill 135 158 511 135 158 514 minecraft:blackstone
setblock 135 158 515 minecraft:smooth_basalt
fill 135 158 516 135 158 519 minecraft:blackstone
setblock 135 158 520 minecraft:smooth_basalt
fill 135 158 521 135 161 521 minecraft:blackstone
setblock 135 158 525 minecraft:smooth_basalt
fill 135 158 526 135 161 526 minecraft:blackstone
setblock 135 158 530 minecraft:smooth_basalt
fill 135 158 531 135 161 531 minecraft:blackstone
setblock 135 158 535 minecraft:smooth_basalt
fill 135 158 536 135 158 539 minecraft:blackstone
setblock 135 158 540 minecraft:smooth_basalt
fill 135 158 541 135 159 541 minecraft:blackstone
setblock 135 158 545 minecraft:smooth_basalt
fill 135 158 546 135 161 546 minecraft:blackstone
setblock 135 158 550 minecraft:smooth_basalt
fill 135 158 551 135 161 551 minecraft:blackstone
fill 95 159 511 95 159 513 minecraft:blackstone
setblock 95 159 514 minecraft:smooth_basalt
fill 95 159 515 95 159 518 minecraft:blackstone
setblock 95 159 519 minecraft:smooth_basalt
fill 95 159 520 95 159 523 minecraft:blackstone
setblock 95 159 524 minecraft:smooth_basalt
fill 95 159 525 95 162 525 minecraft:blackstone
setblock 95 159 529 minecraft:smooth_basalt
fill 95 159 530 95 162 530 minecraft:blackstone
setblock 95 159 534 minecraft:smooth_basalt
fill 95 159 535 95 162 535 minecraft:blackstone
fill 95 159 541 95 159 543 minecraft:blackstone
setblock 95 159 544 minecraft:smooth_basalt
fill 95 159 545 95 159 548 minecraft:blackstone
setblock 95 159 549 minecraft:smooth_basalt
fill 95 159 550 97 159 551 minecraft:blackstone
fill 96 159 511 96 159 512 minecraft:blackstone
setblock 96 159 513 minecraft:smooth_basalt
fill 96 159 514 96 159 517 minecraft:blackstone
setblock 96 159 518 minecraft:smooth_basalt
fill 96 159 519 96 159 522 minecraft:blackstone
setblock 96 159 523 minecraft:smooth_basalt
fill 96 159 524 96 161 524 minecraft:blackstone
setblock 96 159 528 minecraft:smooth_basalt
fill 96 159 529 96 162 529 minecraft:blackstone
setblock 96 159 533 minecraft:smooth_basalt
setblock 96 159 544 minecraft:blackstone
setblock 96 159 548 minecraft:smooth_basalt
fill 96 159 549 99 159 549 minecraft:blackstone
setblock 97 159 511 minecraft:blackstone
setblock 97 159 512 minecraft:smooth_basalt
fill 97 159 513 97 159 514 minecraft:blackstone
setblock 97 159 527 minecraft:smooth_basalt
setblock 97 159 528 minecraft:blackstone
setblock 97 159 547 minecraft:smooth_basalt
fill 97 159 548 97 161 548 minecraft:blackstone
setblock 98 159 511 minecraft:smooth_basalt
fill 98 159 512 98 162 512 minecraft:blackstone
setblock 98 159 550 minecraft:blackstone
setblock 98 159 551 minecraft:smooth_basalt
fill 99 159 511 99 162 511 minecraft:blackstone
setblock 99 159 550 minecraft:smooth_basalt
fill 99 159 551 102 159 551 minecraft:blackstone
setblock 100 159 549 minecraft:smooth_basalt
fill 100 159 550 103 159 550 minecraft:blackstone
fill 101 159 549 101 160 549 minecraft:blackstone
setblock 103 159 511 minecraft:smooth_basalt
setblock 103 159 551 minecraft:smooth_basalt
fill 104 159 511 107 159 511 minecraft:blackstone
setblock 104 159 550 minecraft:smooth_basalt
fill 104 159 551 107 159 551 minecraft:blackstone
fill 105 159 550 108 159 550 minecraft:blackstone
fill 107 159 549 109 159 549 minecraft:blackstone
setblock 108 159 511 minecraft:smooth_basalt
setblock 108 159 551 minecraft:smooth_basalt
fill 109 159 511 112 159 511 minecraft:blackstone
setblock 109 159 550 minecraft:smooth_basalt
fill 109 159 551 112 159 551 minecraft:blackstone
setblock 110 159 549 minecraft:smooth_basalt
fill 110 159 550 113 159 550 minecraft:blackstone
fill 111 159 549 114 159 549 minecraft:blackstone
fill 112 159 548 115 159 548 minecraft:blackstone
setblock 113 159 511 minecraft:smooth_basalt
setblock 113 159 551 minecraft:smooth_basalt
fill 114 159 511 114 162 511 minecraft:blackstone
setblock 114 159 550 minecraft:smooth_basalt
fill 114 159 551 117 159 551 minecraft:blackstone
setblock 115 159 549 minecraft:smooth_basalt
fill 115 159 550 118 159 550 minecraft:blackstone
setblock 116 159 548 minecraft:smooth_basalt
fill 116 159 549 116 161 549 minecraft:blackstone
setblock 117 159 548 minecraft:blackstone
setblock 118 159 511 minecraft:smooth_basalt
setblock 118 159 551 minecraft:smooth_basalt
fill 119 159 511 119 161 511 minecraft:blackstone
setblock 119 159 550 minecraft:smooth_basalt
fill 119 159 551 119 162 551 minecraft:blackstone
fill 120 159 550 120 160 550 minecraft:blackstone
setblock 123 159 551 minecraft:smooth_basalt
setblock 124 159 551 minecraft:blackstone
fill 129 159 551 129 162 551 minecraft:blackstone
setblock 132 159 512 minecraft:smooth_basalt
setblock 132 159 526 minecraft:blackstone
setblock 132 159 527 minecraft:smooth_basalt
fill 132 159 528 132 160 528 minecraft:blackstone
setblock 133 159 511 minecraft:smooth_basalt
fill 133 159 512 135 160 512 minecraft:blackstone
setblock 133 159 521 minecraft:smooth_basalt
fill 133 159 522 133 160 522 minecraft:blackstone
setblock 133 159 526 minecraft:smooth_basalt
fill 133 159 527 133 162 527 minecraft:blackstone
setblock 133 159 530 minecraft:blackstone
setblock 133 159 531 minecraft:smooth_basalt
fill 133 159 532 133 162 532 minecraft:blackstone
setblock 133 159 550 minecraft:blackstone
setblock 133 159 551 minecraft:smooth_basalt
fill 134 159 511 135 161 511 minecraft:blackstone
fill 134 159 513 134 159 514 minecraft:blackstone
setblock 134 159 515 minecraft:smooth_basalt
fill 134 159 516 134 159 519 minecraft:blackstone
setblock 134 159 520 minecraft:smooth_basalt
fill 134 159 521 134 162 521 minecraft:blackstone
setblock 134 159 525 minecraft:smooth_basalt
fill 134 159 526 134 162 526 minecraft:blackstone
setblock 134 159 530 minecraft:smooth_basalt
fill 134 159 531 134 162 531 minecraft:blackstone
setblock 134 159 534 minecraft:blackstone
setblock 134 159 535 minecraft:smooth_basalt
setblock 134 159 546 minecraft:blackstone
setblock 134 159 550 minecraft:smooth_basalt
fill 134 159 551 134 162 551 minecraft:blackstone
setblock 135 159 513 minecraft:blackstone
setblock 135 159 514 minecraft:smooth_basalt
fill 135 159 515 135 159 518 minecraft:blackstone
setblock 135 159 519 minecraft:smooth_basalt
fill 135 159 520 135 162 520 minecraft:blackstone
setblock 135 159 524 minecraft:smooth_basalt
fill 135 159 525 135 162 525 minecraft:blackstone
setblock 135 159 529 minecraft:smooth_basalt
fill 135 159 530 135 162 530 minecraft:blackstone
setblock 135 159 534 minecraft:smooth_basalt
fill 135 159 535 135 159 538 minecraft:blackstone
setblock 135 159 539 minecraft:smooth_basalt
setblock 135 159 544 minecraft:smooth_basalt
fill 135 159 545 135 161 545 minecraft:blackstone
setblock 135 159 549 minecraft:smooth_basalt
fill 135 159 550 135 162 550 minecraft:blackstone
fill 95 160 511 95 160 512 minecraft:blackstone
setblock 95 160 513 minecraft:smooth_basalt
fill 95 160 514 95 160 517 minecraft:blackstone
setblock 95 160 518 minecraft:smooth_basalt
fill 95 160 519 95 160 522 minecraft:blackstone
setblock 95 160 523 minecraft:smooth_basalt
fill 95 160 524 95 163 524 minecraft:blackstone
setblock 95 160 528 minecraft:smooth_basalt
fill 95 160 529 95 163 529 minecraft:blackstone
setblock 95 160 533 minecraft:smooth_basalt
fill 95 160 534 95 163 534 minecraft:blackstone
setblock 95 160 542 minecraft:blackstone
setblock 95 160 543 minecraft:smooth_basalt
fill 95 160 544 95 160 547 minecraft:blackstone
setblock 95 160 548 minecraft:smooth_basalt
fill 95 160 549 96 160 551 minecraft:blackstone
setblock 96 160 511 minecraft:blackstone
setblock 96 160 512 minecraft:smooth_basalt
fill 96 160 513 96 160 516 minecraft:blackstone
setblock 96 160 517 minecraft:smooth_basalt
fill 96 160 518 96 160 521 minecraft:blackstone
setblock 96 160 522 minecraft:smooth_basalt
setblock 96 160 523 minecraft:blackstone
setblock 96 160 527 minecraft:smooth_basalt
fill 96 160 528 96 162 528 minecraft:blackstone
setblock 96 160 532 minecraft:smooth_basalt
setblock 96 160 547 minecraft:smooth_basalt
fill 96 160 548 96 163 548 minecraft:blackstone
setblock 97 160 511 minecraft:smooth_basalt
fill 97 160 512 97 161 513 minecraft:blackstone
setblock 97 160 547 minecraft:blackstone
fill 97 160 549 97 160 550 minecraft:blackstone
setblock 97 160 551 minecraft:smooth_basalt
fill 98 160 511 98 163 511 minecraft:blackstone
setblock 98 160 549 minecraft:blackstone
setblock 98 160 550 minecraft:smooth_basalt
fill 98 160 551 101 160 551 minecraft:blackstone
setblock 99 160 549 minecraft:smooth_basalt
fill 99 160 550 102 160 550 minecraft:blackstone
setblock 100 160 549 minecraft:blackstone
setblock 101 160 512 minecraft:smooth_basalt
setblock 102 160 511 minecraft:smooth_basalt
setblock 102 160 551 minecraft:smooth_basalt
fill 103 160 511 106 160 511 minecraft:blackstone
setblock 103 160 550 minecraft:smooth_basalt
fill 103 160 551 106 160 551 minecraft:blackstone
fill 104 160 550 107 160 550 minecraft:blackstone
setblock 107 160 511 minecraft:smooth_basalt
setblock 107 160 551 minecraft:smooth_basalt
fill 108 160 511 111 160 511 minecraft:blackstone
setblock 108 160 549 minecraft:blackstone
setblock 108 160 550 minecraft:smooth_basalt
fill 108 160 551 111 160 551 minecraft:blackstone
setblock 109 160 549 minecraft:smooth_basalt
fill 109 160 550 112 160 550 minecraft:blackstone
fill 110 160 549 113 160 549 minecraft:blackstone
setblock 112 160 511 minecraft:smooth_basalt
setblock 112 160 551 minecraft:smooth_basalt
fill 113 160 511 113 163 511 minecraft:blackstone
fill 113 160 548 114 160 548 minecraft:blackstone
setblock 113 160 550 minecraft:smooth_basalt
fill 113 160 551 116 160 551 minecraft:blackstone
setblock 114 160 549 minecraft:smooth_basalt
fill 114 160 550 117 160 550 minecraft:blackstone
setblock 115 160 548 minecraft:smooth_basalt
fill 115 160 549 115 162 549 minecraft:blackstone
setblock 117 160 511 minecraft:smooth_basalt
setblock 117 160 551 minecraft:smooth_basalt
fill 118 160 511 118 163 511 minecraft:blackstone
setblock 118 160 550 minecraft:smooth_basalt
fill 118 160 551 118 163 551 minecraft:blackstone
fill 119 160 550 119 161 550 minecraft:blackstone
setblock 122 160 551 minecraft:smooth_basalt
fill 129 160 511 129 162 511 minecraft:blackstone
setblock 132 160 511 minecraft:smooth_basalt
fill 132 160 512 132 163 512 minecraft:blackstone
setblock 132 160 527 minecraft:blackstone
setblock 132 160 551 minecraft:smooth_basalt
fill 133 160 511 133 163 511 minecraft:blackstone
setblock 133 160 525 minecraft:smooth_basalt
fill 133 160 526 133 163 526 minecraft:blackstone
setblock 133 160 530 minecraft:smooth_basalt
fill 133 160 531 133 163 531 minecraft:blackstone
setblock 133 160 550 minecraft:smooth_basalt
fill 133 160 551 133 163 551 minecraft:blackstone
setblock 134 160 513 minecraft:blackstone
setblock 134 160 514 minecraft:smooth_basalt
fill 134 160 515 134 160 518 minecraft:blackstone
setblock 134 160 519 minecraft:smooth_basalt
fill 134 160 520 134 163 520 minecraft:blackstone
setblock 134 160 524 minecraft:smooth_basalt
fill 134 160 525 134 163 525 minecraft:blackstone
setblock 134 160 529 minecraft:smooth_basalt
fill 134 160 530 134 163 530 minecraft:blackstone
setblock 134 160 534 minecraft:smooth_basalt
fill 134 160 535 135 162 535 minecraft:blackstone
setblock 134 160 549 minecraft:smooth_basalt
fill 134 160 550 134 163 550 minecraft:blackstone
setblock 135 160 513 minecraft:smooth_basalt
fill 135 160 514 135 160 517 minecraft:blackstone
setblock 135 160 518 minecraft:smooth_basalt
fill 135 160 519 135 163 519 minecraft:blackstone
setblock 135 160 523 minecraft:smooth_basalt
fill 135 160 524 135 163 524 minecraft:blackstone
setblock 135 160 528 minecraft:smooth_basalt
fill 135 160 529 135 163 529 minecraft:blackstone
setblock 135 160 533 minecraft:smooth_basalt
fill 135 160 534 135 163 534 minecraft:blackstone
fill 135 160 536 135 160 537 minecraft:blackstone
setblock 135 160 543 minecraft:smooth_basalt
setblock 135 160 544 minecraft:blackstone
setblock 135 160 548 minecraft:smooth_basalt
fill 135 160 549 135 163 549 minecraft:blackstone
setblock 95 161 511 minecraft:blackstone
setblock 95 161 512 minecraft:smooth_basalt
fill 95 161 513 95 161 516 minecraft:blackstone
setblock 95 161 517 minecraft:smooth_basalt
fill 95 161 518 95 161 521 minecraft:blackstone
setblock 95 161 522 minecraft:smooth_basalt
fill 95 161 523 95 163 523 minecraft:blackstone
setblock 95 161 527 minecraft:smooth_basalt
fill 95 161 528 95 164 528 minecraft:blackstone
setblock 95 161 532 minecraft:smooth_basalt
fill 95 161 533 95 164 533 minecraft:blackstone
fill 95 161 543 95 161 546 minecraft:blackstone
setblock 95 161 547 minecraft:smooth_basalt
fill 95 161 548 95 161 551 minecraft:blackstone
setblock 96 161 511 minecraft:smooth_basalt
fill 96 161 512 96 161 515 minecraft:blackstone
setblock 96 161 516 minecraft:smooth_basalt
setblock 96 161 517 minecraft:blackstone
setblock 96 161 526 minecraft:smooth_basalt
setblock 96 161 527 minecraft:blackstone
setblock 96 161 531 minecraft:smooth_basalt
setblock 96 161 532 minecraft:blackstone
setblock 96 161 546 minecraft:smooth_basalt
fill 96 161 547 96 162 547 minecraft:blackstone
fill 96 161 549 96 161 550 minecraft:blackstone
setblock 96 161 551 minecraft:smooth_basalt
fill 97 161 511 97 164 511 minecraft:blackstone
setblock 97 161 549 minecraft:blackstone
setblock 97 161 550 minecraft:smooth_basalt
fill 97 161 551 100 161 551 minecraft:blackstone
setblock 98 161 549 minecraft:smooth_basalt
fill 98 161 550 101 161 550 minecraft:blackstone
setblock 99 161 549 minecraft:blackstone
setblock 100 161 512 minecraft:smooth_basalt
setblock 101 161 511 minecraft:smooth_basalt
setblock 101 161 551 minecraft:smooth_basalt
fill 102 161 511 105 161 511 minecraft:blackstone
setblock 102 161 550 minecraft:smooth_basalt
fill 102 161 551 105 161 551 minecraft:blackstone
fill 103 161 550 106 161 550 minecraft:blackstone
setblock 106 161 511 minecraft:smooth_basalt
setblock 106 161 551 minecraft:smooth_basalt
fill 107 161 511 110 161 511 minecraft:blackstone
setblock 107 161 550 minecraft:smooth_basalt
fill 107 161 551 110 161 551 minecraft:blackstone
fill 108 161 550 111 161 550 minecraft:blackstone
fill 109 161 549 112 161 549 minecraft:blackstone
setblock 111 161 511 minecraft:smooth_basalt
setblock 111 161 551 minecraft:smooth_basalt
fill 112 161 511 112 164 511 minecraft:blackstone
setblock 112 161 550 minecraft:smooth_basalt
fill 112 161 551 115 161 551 minecraft:blackstone
setblock 113 161 549 minecraft:smooth_basalt
fill 113 161 550 116 161 550 minecraft:blackstone
fill 114 161 549 114 163 549 minecraft:blackstone
setblock 116 161 511 minecraft:smooth_basalt
setblock 116 161 551 minecraft:smooth_basalt
fill 117 161 511 117 164 511 minecraft:blackstone
setblock 117 161 550 minecraft:smooth_basalt
fill 117 161 551 117 164 551 minecraft:blackstone
fill 118 161 550 118 162 550 minecraft:blackstone
setblock 121 161 551 minecraft:smooth_basalt
fill 128 161 511 128 163 511 minecraft:blackstone
setblock 131 161 511 minecraft:smooth_basalt
fill 131 161 512 131 164 512 minecraft:blackstone
setblock 131 161 551 minecraft:smooth_basalt
fill 132 161 511 132 164 511 minecraft:blackstone
setblock 132 161 550 minecraft:smooth_basalt
fill 132 161 551 132 164 551 minecraft:blackstone
fill 133 161 512 134 161 512 minecraft:blackstone
setblock 133 161 524 minecraft:smooth_basalt
fill 133 161 525 133 162 525 minecraft:blackstone
setblock 133 161 529 minecraft:smooth_basalt
fill 133 161 530 133 164 530 minecraft:blackstone
fill 133 161 550 133 164 550 minecraft:blackstone
setblock 134 161 513 minecraft:smooth_basalt
fill 134 161 514 134 161 517 minecraft:blackstone
setblock 134 161 518 minecraft:smooth_basalt
fill 134 161 519 134 164 519 minecraft:blackstone
setblock 134 161 523 minecraft:smooth_basalt
fill 134 161 524 134 164 524 minecraft:blackstone
setblock 134 161 528 minecraft:smooth_basalt
fill 134 161 529 134 164 529 minecraft:blackstone
setblock 134 161 533 minecraft:smooth_basalt
fill 134 161 534 134 164 534 minecraft:blackstone
setblock 134 161 548 minecraft:smooth_basalt
fill 134 161 549 134 162 549 minecraft:blackstone
setblock 135 161 512 minecraft:smooth_basalt
fill 135 161 513 135 161 516 minecraft:blackstone
setblock 135 161 517 minecraft:smooth_basalt
fill 135 161 518 135 164 518 minecraft:blackstone
setblock 135 161 522 minecraft:smooth_basalt
fill 135 161 523 135 164 523 minecraft:blackstone
setblock 135 161 527 minecraft:smooth_basalt
fill 135 161 528 135 164 528 minecraft:blackstone
setblock 135 161 532 minecraft:smooth_basalt
fill 135 161 533 135 164 533 minecraft:blackstone
setblock 135 161 536 minecraft:blackstone
setblock 135 161 537 minecraft:smooth_basalt
setblock 135 161 547 minecraft:smooth_basalt
fill 135 161 548 135 164 548 minecraft:blackstone
setblock 95 162 511 minecraft:smooth_basalt
fill 95 162 512 95 162 515 minecraft:blackstone
setblock 95 162 516 minecraft:smooth_basalt
fill 95 162 517 95 162 520 minecraft:blackstone
setblock 95 162 521 minecraft:smooth_basalt
fill 95 162 522 95 163 522 minecraft:blackstone
setblock 95 162 526 minecraft:smooth_basalt
fill 95 162 527 95 164 527 minecraft:blackstone
setblock 95 162 531 minecraft:smooth_basalt
fill 95 162 532 95 165 532 minecraft:blackstone
fill 95 162 544 95 162 545 minecraft:blackstone
setblock 95 162 546 minecraft:smooth_basalt
fill 95 162 547 95 162 550 minecraft:blackstone
setblock 95 162 551 minecraft:smooth_basalt
fill 96 162 511 96 162 514 minecraft:blackstone
setblock 96 162 515 minecraft:smooth_basalt
setblock 96 162 516 minecraft:blackstone
setblock 96 162 530 minecraft:smooth_basalt
setblock 96 162 531 minecraft:blackstone
setblock 96 162 549 minecraft:blackstone
setblock 96 162 550 minecraft:smooth_basalt
fill 96 162 551 99 162 551 minecraft:blackstone
fill 97 162 512 97 163 512 minecraft:blackstone
setblock 97 162 549 minecraft:smooth_basalt
fill 97 162 550 100 162 550 minecraft:blackstone
fill 98 162 526 98 163 526 minecraft:jungle_log
setblock 99 162 512 minecraft:smooth_basalt
setblock 100 162 511 minecraft:smooth_basalt
setblock 100 162 512 minecraft:blackstone
setblock 100 162 551 minecraft:smooth_basalt
fill 101 162 511 104 162 511 minecraft:blackstone
setblock 101 162 550 minecraft:smooth_basalt
fill 101 162 551 104 162 551 minecraft:blackstone
fill 102 162 514 104 216 516 minecraft:smooth_basalt
fill 102 162 550 105 162 550 minecraft:blackstone
fill 104 162 525 108 162 527 minecraft:jungle_log
setblock 105 162 511 minecraft:smooth_basalt
setblock 105 162 551 minecraft:smooth_basalt
fill 106 162 511 109 162 511 minecraft:blackstone
setblock 106 162 550 minecraft:smooth_basalt
fill 106 162 551 109 162 551 minecraft:blackstone
fill 107 162 550 110 162 550 minecraft:blackstone
fill 109 162 525 114 162 527 minecraft:jungle_leaves[persistent=true]
setblock 110 162 511 minecraft:smooth_basalt
fill 110 162 523 114 167 524 minecraft:jungle_leaves[persistent=true]
fill 110 162 528 114 167 529 minecraft:jungle_leaves[persistent=true]
fill 110 162 549 111 162 549 minecraft:blackstone
setblock 110 162 551 minecraft:smooth_basalt
fill 111 162 511 111 165 511 minecraft:blackstone
fill 111 162 522 119 164 522 minecraft:jungle_leaves[persistent=true]
fill 111 162 530 119 164 530 minecraft:jungle_leaves[persistent=true]
setblock 111 162 550 minecraft:smooth_basalt
fill 111 162 551 114 162 551 minecraft:blackstone
setblock 112 162 549 minecraft:smooth_basalt
fill 112 162 550 115 162 550 minecraft:blackstone
fill 113 162 521 117 169 521 minecraft:jungle_leaves[persistent=true]
fill 113 162 531 117 169 531 minecraft:jungle_leaves[persistent=true]
fill 113 162 549 113 163 549 minecraft:blackstone
setblock 115 162 511 minecraft:smooth_basalt
fill 115 162 523 115 166 523 minecraft:jungle_leaves[persistent=true]
fill 115 162 529 115 166 529 minecraft:jungle_leaves[persistent=true]
setblock 115 162 551 minecraft:smooth_basalt
fill 116 162 511 116 165 511 minecraft:blackstone
setblock 116 162 550 minecraft:smooth_basalt
fill 116 162 551 116 165 551 minecraft:blackstone
fill 117 162 550 117 163 550 minecraft:blackstone
setblock 120 162 551 minecraft:smooth_basalt
setblock 130 162 511 minecraft:smooth_basalt
fill 130 162 512 130 165 512 minecraft:blackstone
setblock 130 162 551 minecraft:smooth_basalt
fill 131 162 511 131 165 511 minecraft:blackstone
fill 131 162 551 131 165 551 minecraft:blackstone
setblock 132 162 550 minecraft:blackstone
setblock 133 162 512 minecraft:blackstone
setblock 133 162 513 minecraft:smooth_basalt
setblock 133 162 528 minecraft:smooth_basalt
fill 133 162 529 133 165 529 minecraft:blackstone
setblock 134 162 511 minecraft:blackstone
setblock 134 162 512 minecraft:smooth_basalt
fill 134 162 513 134 162 516 minecraft:blackstone
setblock 134 162 517 minecraft:smooth_basalt
fill 134 162 518 134 165 518 minecraft:blackstone
setblock 134 162 522 minecraft:smooth_basalt
fill 134 162 523 134 164 523 minecraft:blackstone
setblock 134 162 527 minecraft:smooth_basalt
fill 134 162 528 134 165 528 minecraft:blackstone
setblock 134 162 532 minecraft:smooth_basalt
fill 134 162 533 134 165 533 minecraft:blackstone
setblock 135 162 511 minecraft:smooth_basalt
fill 135 162 512 135 162 515 minecraft:blackstone
setblock 135 162 516 minecraft:smooth_basalt
schedule function dropper:buildpart/122_7 1t
