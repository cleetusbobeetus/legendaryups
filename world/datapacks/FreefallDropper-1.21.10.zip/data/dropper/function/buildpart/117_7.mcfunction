fill 463 208 475 463 209 475 minecraft:blackstone
setblock 463 208 479 minecraft:polished_blackstone_bricks
setblock 463 208 505 minecraft:blackstone
fill 464 208 463 465 208 463 minecraft:soul_soil
fill 464 208 464 464 211 464 minecraft:blackstone
setblock 464 208 468 minecraft:polished_blackstone_bricks
fill 464 208 469 465 208 469 minecraft:blackstone
setblock 464 208 473 minecraft:polished_blackstone_bricks
fill 464 208 474 464 211 474 minecraft:blackstone
setblock 464 208 478 minecraft:polished_blackstone_bricks
fill 464 208 479 464 211 479 minecraft:blackstone
fill 464 208 481 464 209 481 minecraft:blackstone
setblock 464 208 497 minecraft:blackstone
setblock 464 208 498 minecraft:polished_blackstone_bricks
fill 464 208 499 464 211 499 minecraft:blackstone
setblock 464 208 502 minecraft:blackstone
setblock 464 208 503 minecraft:polished_blackstone_bricks
fill 464 208 504 465 208 504 minecraft:blackstone
fill 464 208 505 465 307 505 minecraft:soul_soil
fill 465 208 464 465 307 465 minecraft:soul_soil
setblock 465 208 466 minecraft:blackstone
fill 465 208 467 465 307 468 minecraft:soul_soil
fill 465 208 470 465 208 475 minecraft:soul_soil
setblock 465 208 476 minecraft:blackstone
fill 465 208 477 465 208 479 minecraft:soul_soil
fill 465 208 481 465 307 481 minecraft:soul_soil
fill 465 208 485 465 307 485 minecraft:soul_soil
fill 465 208 493 465 307 493 minecraft:soul_soil
fill 465 208 501 465 209 501 minecraft:blackstone
fill 465 208 502 465 307 503 minecraft:soul_soil
fill 423 209 463 423 307 464 minecraft:soul_soil
fill 423 209 465 423 209 466 minecraft:blackstone
fill 423 209 467 423 307 469 minecraft:soul_soil
setblock 423 209 470 minecraft:blackstone
fill 423 209 471 423 307 481 minecraft:soul_soil
fill 423 209 482 423 209 483 minecraft:blackstone
fill 423 209 484 423 307 485 minecraft:soul_soil
setblock 423 209 486 minecraft:blackstone
fill 423 209 487 423 307 493 minecraft:soul_soil
setblock 423 209 494 minecraft:blackstone
fill 423 209 495 423 307 501 minecraft:soul_soil
setblock 423 209 502 minecraft:blackstone
fill 423 209 503 423 307 503 minecraft:soul_soil
setblock 424 209 477 minecraft:polished_blackstone_bricks
setblock 424 209 478 minecraft:blackstone
setblock 424 209 496 minecraft:blackstone
setblock 424 209 497 minecraft:polished_blackstone_bricks
fill 424 209 498 424 212 498 minecraft:blackstone
fill 424 209 500 424 209 501 minecraft:blackstone
setblock 424 209 502 minecraft:polished_blackstone_bricks
fill 424 209 503 424 211 504 minecraft:blackstone
fill 424 209 505 424 307 505 minecraft:soul_soil
setblock 425 209 496 minecraft:polished_blackstone_bricks
fill 425 209 497 425 211 497 minecraft:blackstone
setblock 425 209 501 minecraft:polished_blackstone_bricks
fill 425 209 502 425 211 503 minecraft:blackstone
setblock 426 209 499 minecraft:blackstone
setblock 426 209 500 minecraft:polished_blackstone_bricks
fill 426 209 501 426 212 501 minecraft:blackstone
fill 426 209 503 427 209 503 minecraft:blackstone
fill 427 209 463 429 307 463 minecraft:soul_soil
setblock 427 209 464 minecraft:polished_blackstone_bricks
fill 427 209 502 428 209 502 minecraft:blackstone
setblock 427 209 504 minecraft:polished_blackstone_bricks
fill 428 209 464 428 212 464 minecraft:blackstone
setblock 428 209 503 minecraft:polished_blackstone_bricks
fill 428 209 504 428 212 504 minecraft:blackstone
setblock 429 209 501 minecraft:blackstone
setblock 429 209 502 minecraft:polished_blackstone_bricks
fill 429 209 503 429 212 503 minecraft:blackstone
setblock 430 209 463 minecraft:blackstone
setblock 430 209 501 minecraft:polished_blackstone_bricks
fill 430 209 502 433 209 502 minecraft:blackstone
fill 431 209 463 433 307 463 minecraft:soul_soil
fill 431 209 501 431 212 501 minecraft:blackstone
setblock 432 209 464 minecraft:polished_blackstone_bricks
setblock 432 209 500 minecraft:blackstone
setblock 432 209 504 minecraft:polished_blackstone_bricks
fill 433 209 464 433 212 464 minecraft:blackstone
setblock 433 209 503 minecraft:polished_blackstone_bricks
fill 433 209 504 433 212 504 minecraft:blackstone
setblock 434 209 463 minecraft:blackstone
setblock 434 209 500 minecraft:blackstone
setblock 434 209 502 minecraft:polished_blackstone_bricks
fill 434 209 503 434 212 503 minecraft:blackstone
fill 435 209 463 436 307 463 minecraft:soul_soil
setblock 435 209 501 minecraft:polished_blackstone_bricks
fill 435 209 502 435 212 502 minecraft:blackstone
fill 436 209 501 436 210 501 minecraft:blackstone
setblock 437 209 463 minecraft:blackstone
setblock 437 209 504 minecraft:polished_blackstone_bricks
fill 438 209 463 438 307 463 minecraft:soul_soil
setblock 438 209 503 minecraft:polished_blackstone_bricks
fill 438 209 504 438 212 504 minecraft:blackstone
fill 438 209 505 438 307 505 minecraft:soul_soil
setblock 439 209 503 minecraft:blackstone
fill 440 209 505 442 307 505 minecraft:soul_soil
fill 441 209 463 441 307 463 minecraft:soul_soil
fill 443 209 463 451 307 463 minecraft:soul_soil
setblock 443 209 505 minecraft:blackstone
fill 449 209 504 451 209 504 minecraft:blackstone
fill 449 209 505 451 307 505 minecraft:soul_soil
fill 450 209 464 450 210 464 minecraft:blackstone
fill 451 209 503 452 209 503 minecraft:blackstone
setblock 452 209 463 minecraft:blackstone
setblock 452 209 464 minecraft:polished_blackstone_bricks
setblock 452 209 504 minecraft:polished_blackstone_bricks
setblock 452 209 505 minecraft:blackstone
fill 453 209 463 455 307 463 minecraft:soul_soil
fill 453 209 464 453 211 465 minecraft:blackstone
setblock 453 209 503 minecraft:polished_blackstone_bricks
fill 453 209 504 453 212 504 minecraft:blackstone
fill 453 209 505 455 307 505 minecraft:soul_soil
fill 454 209 503 454 212 503 minecraft:blackstone
setblock 456 209 463 minecraft:blackstone
setblock 456 209 465 minecraft:polished_blackstone_bricks
fill 457 209 463 458 307 463 minecraft:soul_soil
setblock 457 209 464 minecraft:polished_blackstone_bricks
setblock 457 209 465 minecraft:blackstone
setblock 457 209 504 minecraft:polished_blackstone_bricks
fill 458 209 464 458 212 464 minecraft:blackstone
fill 458 209 504 458 212 504 minecraft:blackstone
fill 459 209 505 461 307 505 minecraft:soul_soil
setblock 462 209 464 minecraft:polished_blackstone_bricks
setblock 462 209 504 minecraft:polished_blackstone_bricks
fill 463 209 464 463 212 464 minecraft:blackstone
setblock 463 209 473 minecraft:polished_blackstone_bricks
setblock 463 209 474 minecraft:blackstone
setblock 463 209 478 minecraft:polished_blackstone_bricks
fill 463 209 504 464 211 504 minecraft:blackstone
fill 463 209 505 463 307 505 minecraft:soul_soil
setblock 464 209 463 minecraft:blackstone
setblock 464 209 469 minecraft:blackstone
setblock 464 209 472 minecraft:polished_blackstone_bricks
fill 464 209 473 464 210 473 minecraft:blackstone
setblock 464 209 477 minecraft:polished_blackstone_bricks
fill 464 209 478 464 212 478 minecraft:blackstone
setblock 464 209 497 minecraft:polished_blackstone_bricks
fill 464 209 498 464 210 498 minecraft:blackstone
fill 464 209 500 464 210 500 minecraft:blackstone
setblock 464 209 502 minecraft:polished_blackstone_bricks
fill 464 209 503 464 212 503 minecraft:blackstone
fill 465 209 463 465 307 463 minecraft:soul_soil
fill 465 209 466 465 307 466 minecraft:soul_soil
fill 465 209 469 465 307 474 minecraft:soul_soil
setblock 465 209 475 minecraft:blackstone
fill 465 209 476 465 307 478 minecraft:soul_soil
setblock 465 209 479 minecraft:blackstone
fill 465 209 482 465 307 482 minecraft:soul_soil
setblock 465 209 483 minecraft:blackstone
fill 465 209 484 465 307 484 minecraft:soul_soil
fill 465 209 486 465 307 487 minecraft:soul_soil
setblock 465 209 488 minecraft:blackstone
fill 465 209 489 465 307 492 minecraft:soul_soil
fill 465 209 494 465 307 494 minecraft:soul_soil
setblock 465 209 495 minecraft:blackstone
fill 465 209 496 465 307 500 minecraft:soul_soil
fill 465 209 504 465 307 504 minecraft:soul_soil
fill 423 210 465 423 307 466 minecraft:soul_soil
fill 423 210 470 423 307 470 minecraft:soul_soil
fill 423 210 482 423 307 483 minecraft:soul_soil
fill 423 210 486 423 307 486 minecraft:soul_soil
fill 423 210 494 423 307 494 minecraft:soul_soil
fill 423 210 502 423 307 502 minecraft:soul_soil
setblock 424 210 496 minecraft:polished_blackstone_bricks
fill 424 210 497 424 213 497 minecraft:blackstone
setblock 424 210 500 minecraft:blackstone
setblock 424 210 501 minecraft:polished_blackstone_bricks
fill 424 210 502 424 213 502 minecraft:blackstone
fill 425 210 498 425 211 498 minecraft:blackstone
setblock 425 210 500 minecraft:polished_blackstone_bricks
fill 425 210 501 425 213 501 minecraft:blackstone
setblock 426 210 499 minecraft:polished_blackstone_bricks
fill 426 210 500 426 213 500 minecraft:blackstone
fill 426 210 502 426 210 503 minecraft:blackstone
setblock 426 210 504 minecraft:polished_blackstone_bricks
fill 427 210 464 427 213 464 minecraft:blackstone
setblock 427 210 502 minecraft:blackstone
setblock 427 210 503 minecraft:polished_blackstone_bricks
fill 427 210 504 427 213 504 minecraft:blackstone
setblock 428 210 502 minecraft:polished_blackstone_bricks
fill 428 210 503 428 213 503 minecraft:blackstone
setblock 429 210 501 minecraft:polished_blackstone_bricks
fill 429 210 502 432 210 502 minecraft:blackstone
fill 430 210 463 430 307 463 minecraft:soul_soil
fill 430 210 501 430 213 501 minecraft:blackstone
setblock 431 210 464 minecraft:polished_blackstone_bricks
setblock 431 210 504 minecraft:polished_blackstone_bricks
fill 432 210 464 432 213 464 minecraft:blackstone
setblock 432 210 503 minecraft:polished_blackstone_bricks
fill 432 210 504 432 213 504 minecraft:blackstone
setblock 433 210 502 minecraft:polished_blackstone_bricks
fill 433 210 503 433 213 503 minecraft:blackstone
fill 434 210 463 434 307 463 minecraft:soul_soil
setblock 434 210 501 minecraft:polished_blackstone_bricks
fill 434 210 502 434 213 502 minecraft:blackstone
fill 435 210 501 435 211 501 minecraft:blackstone
setblock 436 210 504 minecraft:polished_blackstone_bricks
fill 437 210 463 437 307 463 minecraft:soul_soil
setblock 437 210 503 minecraft:polished_blackstone_bricks
fill 437 210 504 437 213 504 minecraft:blackstone
fill 438 210 503 438 211 503 minecraft:blackstone
fill 443 210 505 443 307 505 minecraft:soul_soil
fill 448 210 504 450 210 504 minecraft:blackstone
setblock 451 210 464 minecraft:polished_blackstone_bricks
setblock 451 210 503 minecraft:blackstone
setblock 451 210 504 minecraft:polished_blackstone_bricks
fill 452 210 463 452 307 463 minecraft:soul_soil
fill 452 210 464 452 213 464 minecraft:blackstone
setblock 452 210 503 minecraft:polished_blackstone_bricks
fill 452 210 504 452 213 504 minecraft:blackstone
fill 452 210 505 452 307 505 minecraft:soul_soil
fill 453 210 503 453 213 503 minecraft:blackstone
setblock 455 210 465 minecraft:polished_blackstone_bricks
fill 456 210 463 456 307 463 minecraft:soul_soil
setblock 456 210 464 minecraft:polished_blackstone_bricks
setblock 456 210 465 minecraft:blackstone
setblock 456 210 503 minecraft:blackstone
setblock 456 210 504 minecraft:polished_blackstone_bricks
fill 457 210 464 457 213 464 minecraft:blackstone
setblock 457 210 503 minecraft:polished_blackstone_bricks
fill 457 210 504 457 213 504 minecraft:blackstone
setblock 460 210 504 minecraft:blackstone
setblock 461 210 464 minecraft:polished_blackstone_bricks
setblock 461 210 504 minecraft:polished_blackstone_bricks
fill 462 210 464 462 213 464 minecraft:blackstone
fill 462 210 504 462 213 504 minecraft:blackstone
fill 464 210 463 464 307 463 minecraft:soul_soil
setblock 464 210 471 minecraft:polished_blackstone_bricks
setblock 464 210 472 minecraft:blackstone
setblock 464 210 476 minecraft:polished_blackstone_bricks
fill 464 210 477 464 212 477 minecraft:blackstone
setblock 464 210 501 minecraft:polished_blackstone_bricks
fill 464 210 502 464 213 502 minecraft:blackstone
fill 465 210 475 465 307 475 minecraft:soul_soil
fill 465 210 479 465 307 479 minecraft:soul_soil
fill 465 210 483 465 307 483 minecraft:soul_soil
fill 465 210 488 465 307 488 minecraft:soul_soil
fill 465 210 495 465 307 495 minecraft:soul_soil
fill 465 210 501 465 307 501 minecraft:soul_soil
fill 424 211 496 424 212 496 minecraft:blackstone
setblock 424 211 500 minecraft:polished_blackstone_bricks
fill 424 211 501 424 214 501 minecraft:blackstone
setblock 425 211 499 minecraft:polished_blackstone_bricks
fill 425 211 500 425 214 500 minecraft:blackstone
setblock 425 211 504 minecraft:polished_blackstone_bricks
setblock 426 211 499 minecraft:blackstone
setblock 426 211 502 minecraft:blackstone
setblock 426 211 503 minecraft:polished_blackstone_bricks
fill 426 211 504 426 214 504 minecraft:blackstone
setblock 427 211 502 minecraft:polished_blackstone_bricks
fill 427 211 503 427 214 503 minecraft:blackstone
fill 428 211 502 431 211 502 minecraft:blackstone
fill 429 211 501 429 213 501 minecraft:blackstone
setblock 430 211 464 minecraft:polished_blackstone_bricks
setblock 430 211 504 minecraft:polished_blackstone_bricks
fill 431 211 464 431 214 464 minecraft:blackstone
setblock 431 211 503 minecraft:polished_blackstone_bricks
fill 431 211 504 431 214 504 minecraft:blackstone
setblock 432 211 502 minecraft:polished_blackstone_bricks
fill 432 211 503 432 214 503 minecraft:blackstone
setblock 433 211 501 minecraft:polished_blackstone_bricks
fill 433 211 502 433 214 502 minecraft:blackstone
setblock 434 211 501 minecraft:blackstone
setblock 435 211 464 minecraft:polished_blackstone_bricks
setblock 435 211 504 minecraft:polished_blackstone_bricks
setblock 436 211 503 minecraft:polished_blackstone_bricks
fill 436 211 504 436 214 504 minecraft:blackstone
fill 437 211 503 437 212 503 minecraft:blackstone
fill 448 211 504 449 211 504 minecraft:blackstone
setblock 449 211 464 minecraft:blackstone
setblock 450 211 464 minecraft:polished_blackstone_bricks
setblock 450 211 503 minecraft:blackstone
setblock 450 211 504 minecraft:polished_blackstone_bricks
fill 451 211 464 451 214 464 minecraft:blackstone
setblock 451 211 503 minecraft:polished_blackstone_bricks
fill 451 211 504 451 214 504 minecraft:blackstone
fill 452 211 503 452 214 503 minecraft:blackstone
setblock 454 211 465 minecraft:polished_blackstone_bricks
setblock 455 211 464 minecraft:polished_blackstone_bricks
fill 455 211 465 455 212 465 minecraft:blackstone
setblock 455 211 504 minecraft:polished_blackstone_bricks
fill 456 211 464 456 214 464 minecraft:blackstone
setblock 456 211 503 minecraft:polished_blackstone_bricks
fill 456 211 504 456 214 504 minecraft:blackstone
setblock 460 211 464 minecraft:polished_blackstone_bricks
setblock 460 211 504 minecraft:polished_blackstone_bricks
fill 461 211 464 461 214 464 minecraft:blackstone
fill 461 211 504 461 214 504 minecraft:blackstone
setblock 464 211 475 minecraft:polished_blackstone_bricks
setblock 464 211 476 minecraft:blackstone
setblock 464 211 480 minecraft:polished_blackstone_bricks
setblock 464 211 500 minecraft:polished_blackstone_bricks
fill 464 211 501 464 214 501 minecraft:blackstone
setblock 424 212 499 minecraft:polished_blackstone_bricks
fill 424 212 500 424 215 500 minecraft:blackstone
setblock 424 212 503 minecraft:blackstone
setblock 424 212 504 minecraft:polished_blackstone_bricks
setblock 425 212 498 minecraft:polished_blackstone_bricks
fill 425 212 499 425 215 499 minecraft:blackstone
setblock 425 212 502 minecraft:blackstone
setblock 425 212 503 minecraft:polished_blackstone_bricks
fill 425 212 504 425 215 504 minecraft:blackstone
fill 426 212 464 426 214 464 minecraft:blackstone
setblock 426 212 502 minecraft:polished_blackstone_bricks
fill 426 212 503 426 215 503 minecraft:blackstone
fill 427 212 502 430 212 502 minecraft:blackstone
setblock 429 212 464 minecraft:polished_blackstone_bricks
setblock 429 212 504 minecraft:polished_blackstone_bricks
fill 430 212 464 430 215 464 minecraft:blackstone
setblock 430 212 503 minecraft:polished_blackstone_bricks
fill 430 212 504 430 215 504 minecraft:blackstone
setblock 431 212 502 minecraft:polished_blackstone_bricks
fill 431 212 503 431 215 503 minecraft:blackstone
setblock 432 212 501 minecraft:polished_blackstone_bricks
fill 432 212 502 432 215 502 minecraft:blackstone
setblock 433 212 501 minecraft:blackstone
setblock 434 212 464 minecraft:polished_blackstone_bricks
setblock 434 212 504 minecraft:polished_blackstone_bricks
setblock 435 212 503 minecraft:polished_blackstone_bricks
fill 435 212 504 435 215 504 minecraft:blackstone
fill 436 212 503 436 214 503 minecraft:blackstone
setblock 448 212 504 minecraft:blackstone
setblock 449 212 464 minecraft:polished_blackstone_bricks
setblock 449 212 504 minecraft:polished_blackstone_bricks
fill 450 212 464 450 215 464 minecraft:blackstone
setblock 450 212 503 minecraft:polished_blackstone_bricks
fill 450 212 504 450 215 504 minecraft:blackstone
fill 451 212 503 451 215 503 minecraft:blackstone
setblock 452 212 465 minecraft:blackstone
setblock 453 212 464 minecraft:blackstone
setblock 453 212 465 minecraft:polished_blackstone_bricks
setblock 454 212 464 minecraft:polished_blackstone_bricks
fill 454 212 465 454 215 465 minecraft:blackstone
setblock 454 212 504 minecraft:polished_blackstone_bricks
fill 455 212 464 455 215 464 minecraft:blackstone
setblock 455 212 503 minecraft:polished_blackstone_bricks
fill 455 212 504 455 215 504 minecraft:blackstone
setblock 459 212 464 minecraft:polished_blackstone_bricks
setblock 459 212 504 minecraft:polished_blackstone_bricks
fill 460 212 464 460 215 464 minecraft:blackstone
fill 460 212 504 460 215 504 minecraft:blackstone
setblock 463 212 504 minecraft:blackstone
setblock 464 212 464 minecraft:polished_blackstone_bricks
setblock 464 212 479 minecraft:polished_blackstone_bricks
setblock 464 212 499 minecraft:polished_blackstone_bricks
fill 464 212 500 464 215 500 minecraft:blackstone
setblock 464 212 504 minecraft:polished_blackstone_bricks
setblock 424 213 498 minecraft:polished_blackstone_bricks
fill 424 213 499 424 216 499 minecraft:blackstone
setblock 424 213 503 minecraft:polished_blackstone_bricks
fill 424 213 504 424 216 504 minecraft:blackstone
fill 425 213 464 425 215 464 minecraft:blackstone
fill 425 213 498 425 216 498 minecraft:blackstone
setblock 425 213 502 minecraft:polished_blackstone_bricks
fill 425 213 503 425 216 503 minecraft:blackstone
setblock 426 213 501 minecraft:polished_blackstone_bricks
fill 426 213 502 429 213 502 minecraft:blackstone
setblock 428 213 464 minecraft:polished_blackstone_bricks
setblock 428 213 504 minecraft:polished_blackstone_bricks
fill 429 213 464 429 216 464 minecraft:blackstone
setblock 429 213 503 minecraft:polished_blackstone_bricks
fill 429 213 504 429 216 504 minecraft:blackstone
setblock 430 213 502 minecraft:polished_blackstone_bricks
fill 430 213 503 430 216 503 minecraft:blackstone
setblock 431 213 501 minecraft:polished_blackstone_bricks
fill 431 213 502 431 216 502 minecraft:blackstone
setblock 432 213 501 minecraft:blackstone
setblock 433 213 464 minecraft:polished_blackstone_bricks
setblock 433 213 504 minecraft:polished_blackstone_bricks
setblock 434 213 503 minecraft:polished_blackstone_bricks
fill 434 213 504 434 216 504 minecraft:blackstone
setblock 435 213 502 minecraft:polished_blackstone_bricks
fill 435 213 503 435 216 503 minecraft:blackstone
setblock 438 213 504 minecraft:polished_blackstone_bricks
setblock 447 213 504 minecraft:blackstone
setblock 448 213 464 minecraft:polished_blackstone_bricks
setblock 448 213 504 minecraft:polished_blackstone_bricks
fill 449 213 464 449 216 464 minecraft:blackstone
fill 449 213 504 449 216 504 minecraft:blackstone
fill 450 213 503 450 216 503 minecraft:blackstone
setblock 451 213 465 minecraft:blackstone
setblock 452 213 465 minecraft:polished_blackstone_bricks
setblock 453 213 464 minecraft:polished_blackstone_bricks
fill 453 213 465 453 216 465 minecraft:blackstone
setblock 453 213 504 minecraft:polished_blackstone_bricks
fill 454 213 464 454 216 464 minecraft:blackstone
setblock 454 213 503 minecraft:polished_blackstone_bricks
fill 454 213 504 454 216 504 minecraft:blackstone
setblock 458 213 464 minecraft:polished_blackstone_bricks
setblock 458 213 504 minecraft:polished_blackstone_bricks
fill 459 213 464 459 216 464 minecraft:blackstone
fill 459 213 504 459 216 504 minecraft:blackstone
setblock 463 213 464 minecraft:polished_blackstone_bricks
setblock 463 213 504 minecraft:polished_blackstone_bricks
fill 464 213 464 464 215 465 minecraft:blackstone
setblock 464 213 503 minecraft:polished_blackstone_bricks
fill 464 213 504 464 216 504 minecraft:blackstone
fill 424 214 464 424 216 464 minecraft:blackstone
setblock 424 214 497 minecraft:polished_blackstone_bricks
fill 424 214 498 424 217 498 minecraft:blackstone
setblock 424 214 502 minecraft:polished_blackstone_bricks
fill 424 214 503 424 217 503 minecraft:blackstone
setblock 425 214 501 minecraft:polished_blackstone_bricks
fill 425 214 502 428 214 502 minecraft:blackstone
setblock 426 214 466 minecraft:light[level=11]
setblock 426 214 474 minecraft:light[level=11]
setblock 426 214 482 minecraft:light[level=11]
setblock 426 214 490 minecraft:light[level=11]
setblock 426 214 498 minecraft:light[level=11]
setblock 426 214 500 minecraft:polished_blackstone_bricks
fill 426 214 501 426 217 501 minecraft:blackstone
setblock 427 214 464 minecraft:polished_blackstone_bricks
setblock 427 214 504 minecraft:polished_blackstone_bricks
fill 428 214 464 428 217 464 minecraft:blackstone
setblock 428 214 503 minecraft:polished_blackstone_bricks
fill 428 214 504 428 217 504 minecraft:blackstone
setblock 429 214 502 minecraft:polished_blackstone_bricks
fill 429 214 503 429 217 503 minecraft:blackstone
setblock 430 214 501 minecraft:polished_blackstone_bricks
fill 430 214 502 430 217 502 minecraft:blackstone
setblock 432 214 464 minecraft:polished_blackstone_bricks
setblock 432 214 504 minecraft:polished_blackstone_bricks
fill 433 214 464 433 217 464 minecraft:blackstone
setblock 433 214 503 minecraft:polished_blackstone_bricks
fill 433 214 504 433 217 504 minecraft:blackstone
setblock 434 214 466 minecraft:light[level=11]
setblock 434 214 474 minecraft:light[level=11]
setblock 434 214 482 minecraft:light[level=11]
setblock 434 214 490 minecraft:light[level=11]
setblock 434 214 498 minecraft:light[level=11]
setblock 434 214 502 minecraft:polished_blackstone_bricks
fill 434 214 503 434 217 503 minecraft:blackstone
setblock 437 214 504 minecraft:polished_blackstone_bricks
setblock 442 214 466 minecraft:light[level=11]
setblock 442 214 474 minecraft:light[level=11]
setblock 442 214 482 minecraft:light[level=11]
setblock 442 214 490 minecraft:light[level=11]
setblock 442 214 498 minecraft:light[level=11]
setblock 447 214 464 minecraft:polished_blackstone_bricks
setblock 447 214 504 minecraft:polished_blackstone_bricks
fill 448 214 464 448 217 464 minecraft:blackstone
fill 448 214 504 448 217 504 minecraft:blackstone
setblock 450 214 465 minecraft:blackstone
setblock 450 214 466 minecraft:light[level=11]
setblock 450 214 474 minecraft:light[level=11]
setblock 450 214 482 minecraft:light[level=11]
setblock 450 214 498 minecraft:light[level=11]
setblock 451 214 465 minecraft:polished_blackstone_bricks
setblock 452 214 464 minecraft:polished_blackstone_bricks
fill 452 214 465 452 217 465 minecraft:blackstone
setblock 452 214 504 minecraft:polished_blackstone_bricks
fill 453 214 464 453 217 464 minecraft:blackstone
setblock 453 214 503 minecraft:polished_blackstone_bricks
fill 453 214 504 453 217 504 minecraft:blackstone
setblock 454 214 503 minecraft:blackstone
setblock 455 214 465 minecraft:blackstone
setblock 457 214 464 minecraft:polished_blackstone_bricks
setblock 457 214 504 minecraft:polished_blackstone_bricks
fill 458 214 464 458 217 464 minecraft:blackstone
setblock 458 214 466 minecraft:light[level=11]
setblock 458 214 474 minecraft:light[level=11]
setblock 458 214 482 minecraft:light[level=11]
setblock 458 214 490 minecraft:light[level=11]
setblock 458 214 498 minecraft:light[level=11]
fill 458 214 504 458 217 504 minecraft:blackstone
setblock 462 214 464 minecraft:polished_blackstone_bricks
setblock 462 214 504 minecraft:polished_blackstone_bricks
fill 463 214 464 463 217 464 minecraft:blackstone
fill 463 214 504 463 217 504 minecraft:blackstone
setblock 464 214 502 minecraft:polished_blackstone_bricks
fill 464 214 503 464 217 503 minecraft:blackstone
fill 424 215 497 424 218 497 minecraft:blackstone
setblock 424 215 501 minecraft:polished_blackstone_bricks
fill 424 215 502 427 215 502 minecraft:blackstone
setblock 425 215 500 minecraft:polished_blackstone_bricks
fill 425 215 501 425 218 501 minecraft:blackstone
setblock 426 215 464 minecraft:polished_blackstone_bricks
fill 426 215 500 426 218 500 minecraft:blackstone
setblock 426 215 504 minecraft:polished_blackstone_bricks
fill 427 215 464 427 218 464 minecraft:blackstone
setblock 427 215 503 minecraft:polished_blackstone_bricks
fill 427 215 504 427 218 504 minecraft:blackstone
setblock 428 215 502 minecraft:polished_blackstone_bricks
fill 428 215 503 428 218 503 minecraft:blackstone
fill 429 215 502 429 218 502 minecraft:blackstone
setblock 431 215 464 minecraft:polished_blackstone_bricks
setblock 431 215 504 minecraft:polished_blackstone_bricks
fill 432 215 464 432 218 464 minecraft:blackstone
setblock 432 215 503 minecraft:polished_blackstone_bricks
fill 432 215 504 432 218 504 minecraft:blackstone
setblock 433 215 502 minecraft:polished_blackstone_bricks
fill 433 215 503 433 218 503 minecraft:blackstone
setblock 436 215 504 minecraft:polished_blackstone_bricks
fill 437 215 504 437 216 504 minecraft:blackstone
setblock 446 215 464 minecraft:polished_blackstone_bricks
setblock 446 215 504 minecraft:polished_blackstone_bricks
fill 447 215 464 447 218 464 minecraft:blackstone
fill 447 215 504 447 218 504 minecraft:blackstone
setblock 449 215 465 minecraft:blackstone
fill 449 215 503 449 217 503 minecraft:blackstone
setblock 450 215 465 minecraft:polished_blackstone_bricks
setblock 451 215 464 minecraft:polished_blackstone_bricks
fill 451 215 465 451 218 465 minecraft:blackstone
setblock 451 215 504 minecraft:polished_blackstone_bricks
fill 452 215 464 452 218 464 minecraft:blackstone
setblock 452 215 503 minecraft:polished_blackstone_bricks
fill 452 215 504 452 218 504 minecraft:blackstone
fill 453 215 503 453 218 503 minecraft:blackstone
setblock 455 215 465 minecraft:polished_blackstone_bricks
setblock 456 215 464 minecraft:polished_blackstone_bricks
setblock 456 215 504 minecraft:polished_blackstone_bricks
fill 457 215 464 457 218 464 minecraft:blackstone
fill 457 215 504 457 218 504 minecraft:blackstone
setblock 461 215 464 minecraft:polished_blackstone_bricks
setblock 461 215 504 minecraft:polished_blackstone_bricks
fill 462 215 464 462 218 464 minecraft:blackstone
fill 462 215 504 462 218 504 minecraft:blackstone
setblock 464 215 466 minecraft:polished_blackstone_bricks
setblock 464 215 501 minecraft:polished_blackstone_bricks
fill 464 215 502 464 218 502 minecraft:blackstone
setblock 424 216 465 minecraft:polished_blackstone_bricks
fill 424 216 481 424 216 484 minecraft:blackstone
setblock 424 216 485 minecraft:polished_blackstone_bricks
fill 424 216 486 424 219 486 minecraft:blackstone
fill 424 216 496 424 219 496 minecraft:blackstone
setblock 424 216 500 minecraft:polished_blackstone_bricks
fill 424 216 501 424 218 502 minecraft:blackstone
setblock 425 216 464 minecraft:polished_blackstone_bricks
setblock 425 216 499 minecraft:polished_blackstone_bricks
fill 425 216 500 425 219 500 minecraft:blackstone
fill 425 216 502 426 216 502 minecraft:blackstone
setblock 425 216 504 minecraft:polished_blackstone_bricks
fill 426 216 464 426 219 464 minecraft:blackstone
setblock 426 216 503 minecraft:polished_blackstone_bricks
fill 426 216 504 426 219 504 minecraft:blackstone
setblock 427 216 502 minecraft:polished_blackstone_bricks
fill 427 216 503 427 219 503 minecraft:blackstone
fill 428 216 502 428 219 502 minecraft:blackstone
setblock 430 216 464 minecraft:polished_blackstone_bricks
setblock 430 216 504 minecraft:polished_blackstone_bricks
fill 431 216 464 431 219 464 minecraft:blackstone
setblock 431 216 503 minecraft:polished_blackstone_bricks
fill 431 216 504 431 219 504 minecraft:blackstone
setblock 432 216 502 minecraft:polished_blackstone_bricks
fill 432 216 503 432 219 503 minecraft:blackstone
setblock 434 216 464 minecraft:blackstone
setblock 435 216 504 minecraft:polished_blackstone_bricks
fill 436 216 504 436 219 504 minecraft:blackstone
setblock 445 216 464 minecraft:polished_blackstone_bricks
setblock 445 216 504 minecraft:polished_blackstone_bricks
fill 446 216 464 446 219 464 minecraft:blackstone
fill 446 216 504 446 219 504 minecraft:blackstone
fill 447 216 465 448 216 465 minecraft:blackstone
fill 448 216 503 448 218 503 minecraft:blackstone
setblock 449 216 465 minecraft:polished_blackstone_bricks
setblock 450 216 464 minecraft:polished_blackstone_bricks
fill 450 216 465 450 219 465 minecraft:blackstone
setblock 450 216 504 minecraft:polished_blackstone_bricks
fill 451 216 464 451 219 464 minecraft:blackstone
setblock 451 216 503 minecraft:polished_blackstone_bricks
fill 451 216 504 451 219 504 minecraft:blackstone
fill 452 216 503 452 219 503 minecraft:blackstone
setblock 454 216 465 minecraft:polished_blackstone_bricks
setblock 455 216 464 minecraft:polished_blackstone_bricks
fill 455 216 465 456 218 465 minecraft:blackstone
setblock 455 216 504 minecraft:polished_blackstone_bricks
fill 456 216 464 456 219 464 minecraft:blackstone
fill 456 216 504 456 219 504 minecraft:blackstone
setblock 460 216 464 minecraft:polished_blackstone_bricks
setblock 460 216 504 minecraft:polished_blackstone_bricks
fill 461 216 464 461 219 464 minecraft:blackstone
fill 461 216 504 461 219 504 minecraft:blackstone
fill 463 216 503 463 218 503 minecraft:blackstone
setblock 464 216 464 minecraft:blackstone
setblock 464 216 465 minecraft:polished_blackstone_bricks
fill 464 216 466 464 218 467 minecraft:blackstone
setblock 464 216 499 minecraft:blackstone
setblock 464 216 500 minecraft:polished_blackstone_bricks
fill 464 216 501 464 219 501 minecraft:blackstone
setblock 424 217 464 minecraft:polished_blackstone_bricks
fill 424 217 465 424 219 466 minecraft:blackstone
fill 424 217 480 424 217 483 minecraft:blackstone
setblock 424 217 484 minecraft:polished_blackstone_bricks
fill 424 217 485 425 219 485 minecraft:blackstone
fill 424 217 487 424 217 488 minecraft:blackstone
setblock 424 217 489 minecraft:polished_blackstone_bricks
fill 424 217 490 424 220 490 minecraft:blackstone
fill 424 217 495 424 220 495 minecraft:blackstone
setblock 424 217 499 minecraft:polished_blackstone_bricks
fill 424 217 500 424 220 500 minecraft:blackstone
setblock 424 217 504 minecraft:polished_blackstone_bricks
fill 425 217 464 425 220 464 minecraft:blackstone
setblock 425 217 482 minecraft:blackstone
setblock 425 217 483 minecraft:polished_blackstone_bricks
fill 425 217 484 425 220 484 minecraft:blackstone
fill 425 217 486 425 217 487 minecraft:blackstone
setblock 425 217 497 minecraft:blackstone
setblock 425 217 498 minecraft:polished_blackstone_bricks
fill 425 217 499 425 220 499 minecraft:blackstone
setblock 425 217 502 minecraft:blackstone
setblock 425 217 503 minecraft:polished_blackstone_bricks
fill 425 217 504 425 220 504 minecraft:blackstone
fill 426 217 465 427 217 465 minecraft:blackstone
setblock 426 217 502 minecraft:polished_blackstone_bricks
fill 426 217 503 426 220 503 minecraft:blackstone
fill 427 217 502 427 220 502 minecraft:blackstone
setblock 428 217 465 minecraft:polished_blackstone_bricks
setblock 429 217 464 minecraft:polished_blackstone_bricks
fill 429 217 465 430 219 465 minecraft:blackstone
setblock 429 217 504 minecraft:polished_blackstone_bricks
fill 430 217 464 430 220 464 minecraft:blackstone
setblock 430 217 503 minecraft:polished_blackstone_bricks
fill 430 217 504 430 220 504 minecraft:blackstone
setblock 431 217 502 minecraft:polished_blackstone_bricks
fill 431 217 503 431 220 503 minecraft:blackstone
setblock 432 217 502 minecraft:blackstone
setblock 434 217 464 minecraft:polished_blackstone_bricks
setblock 434 217 504 minecraft:polished_blackstone_bricks
fill 435 217 504 435 220 504 minecraft:blackstone
setblock 443 217 464 minecraft:blackstone
setblock 444 217 464 minecraft:polished_blackstone_bricks
setblock 444 217 504 minecraft:polished_blackstone_bricks
fill 445 217 464 445 220 464 minecraft:blackstone
fill 445 217 504 445 220 504 minecraft:blackstone
fill 446 217 465 447 217 465 minecraft:blackstone
fill 447 217 503 447 219 503 minecraft:blackstone
setblock 448 217 465 minecraft:polished_blackstone_bricks
setblock 449 217 464 minecraft:polished_blackstone_bricks
fill 449 217 465 449 219 466 minecraft:blackstone
setblock 449 217 504 minecraft:polished_blackstone_bricks
fill 450 217 464 450 220 464 minecraft:blackstone
fill 450 217 466 451 217 466 minecraft:blackstone
setblock 450 217 503 minecraft:polished_blackstone_bricks
fill 450 217 504 450 220 504 minecraft:blackstone
fill 451 217 503 451 220 503 minecraft:blackstone
setblock 452 217 466 minecraft:polished_blackstone_bricks
setblock 453 217 465 minecraft:polished_blackstone_bricks
setblock 454 217 464 minecraft:polished_blackstone_bricks
fill 454 217 465 454 220 465 minecraft:blackstone
setblock 454 217 504 minecraft:polished_blackstone_bricks
fill 455 217 464 455 220 464 minecraft:blackstone
fill 455 217 504 455 220 504 minecraft:blackstone
setblock 457 217 465 minecraft:blackstone
setblock 459 217 464 minecraft:polished_blackstone_bricks
setblock 459 217 504 minecraft:polished_blackstone_bricks
fill 460 217 464 460 220 464 minecraft:blackstone
fill 460 217 504 460 220 504 minecraft:blackstone
fill 461 217 465 462 217 465 minecraft:blackstone
fill 462 217 503 462 219 503 minecraft:blackstone
setblock 463 217 465 minecraft:polished_blackstone_bricks
fill 463 217 466 463 220 466 minecraft:blackstone
fill 463 217 502 463 219 502 minecraft:blackstone
setblock 464 217 464 minecraft:polished_blackstone_bricks
fill 464 217 465 464 220 465 minecraft:blackstone
setblock 464 217 468 minecraft:blackstone
setblock 464 217 469 minecraft:polished_blackstone_bricks
fill 464 217 481 464 217 483 minecraft:blackstone
setblock 464 217 484 minecraft:polished_blackstone_bricks
setblock 464 217 499 minecraft:polished_blackstone_bricks
fill 464 217 500 464 220 500 minecraft:blackstone
setblock 464 217 504 minecraft:polished_blackstone_bricks
fill 424 218 464 424 221 464 minecraft:blackstone
setblock 424 218 467 minecraft:blackstone
setblock 424 218 468 minecraft:polished_blackstone_bricks
fill 424 218 480 424 218 482 minecraft:blackstone
setblock 424 218 483 minecraft:polished_blackstone_bricks
fill 424 218 484 424 221 484 minecraft:blackstone
setblock 424 218 487 minecraft:blackstone
setblock 424 218 488 minecraft:polished_blackstone_bricks
fill 424 218 489 425 220 489 minecraft:blackstone
fill 424 218 491 424 218 492 minecraft:blackstone
setblock 424 218 493 minecraft:polished_blackstone_bricks
fill 424 218 494 424 221 494 minecraft:blackstone
setblock 424 218 498 minecraft:polished_blackstone_bricks
fill 424 218 499 424 221 499 minecraft:blackstone
setblock 424 218 503 minecraft:polished_blackstone_bricks
fill 424 218 504 424 221 504 minecraft:blackstone
fill 425 218 465 425 218 466 minecraft:blackstone
setblock 425 218 481 minecraft:blackstone
setblock 425 218 482 minecraft:polished_blackstone_bricks
fill 425 218 483 426 220 483 minecraft:blackstone
setblock 425 218 486 minecraft:blackstone
setblock 425 218 487 minecraft:polished_blackstone_bricks
fill 425 218 488 426 220 488 minecraft:blackstone
fill 425 218 490 425 218 491 minecraft:blackstone
setblock 425 218 496 minecraft:blackstone
setblock 425 218 497 minecraft:polished_blackstone_bricks
fill 425 218 498 425 221 498 minecraft:blackstone
setblock 425 218 502 minecraft:polished_blackstone_bricks
fill 425 218 503 425 221 503 minecraft:blackstone
setblock 426 218 465 minecraft:blackstone
fill 426 218 484 426 218 485 minecraft:blackstone
setblock 426 218 486 minecraft:polished_blackstone_bricks
fill 426 218 487 426 221 487 minecraft:blackstone
fill 426 218 499 426 219 499 minecraft:blackstone
setblock 426 218 501 minecraft:polished_blackstone_bricks
fill 426 218 502 426 221 502 minecraft:blackstone
setblock 427 218 465 minecraft:polished_blackstone_bricks
setblock 428 218 464 minecraft:polished_blackstone_bricks
fill 428 218 465 428 221 465 minecraft:blackstone
setblock 428 218 504 minecraft:polished_blackstone_bricks
fill 429 218 464 429 221 464 minecraft:blackstone
setblock 429 218 503 minecraft:polished_blackstone_bricks
fill 429 218 504 429 221 504 minecraft:blackstone
setblock 430 218 502 minecraft:polished_blackstone_bricks
fill 430 218 503 430 221 503 minecraft:blackstone
setblock 431 218 465 minecraft:blackstone
fill 431 218 502 431 219 502 minecraft:blackstone
setblock 433 218 464 minecraft:polished_blackstone_bricks
setblock 433 218 504 minecraft:polished_blackstone_bricks
fill 434 218 464 434 221 464 minecraft:blackstone
setblock 434 218 503 minecraft:polished_blackstone_bricks
fill 434 218 504 434 221 504 minecraft:blackstone
setblock 442 218 464 minecraft:blackstone
setblock 443 218 464 minecraft:polished_blackstone_bricks
setblock 443 218 504 minecraft:polished_blackstone_bricks
fill 444 218 464 444 220 465 minecraft:blackstone
fill 444 218 504 444 221 504 minecraft:blackstone
fill 445 218 465 446 218 465 minecraft:blackstone
fill 446 218 503 446 220 503 minecraft:blackstone
setblock 447 218 465 minecraft:polished_blackstone_bricks
fill 447 218 466 448 220 466 minecraft:blackstone
setblock 448 218 464 minecraft:polished_blackstone_bricks
fill 448 218 465 448 221 465 minecraft:blackstone
setblock 448 218 504 minecraft:polished_blackstone_bricks
fill 449 218 464 449 221 464 minecraft:blackstone
setblock 449 218 503 minecraft:polished_blackstone_bricks
fill 449 218 504 449 221 504 minecraft:blackstone
setblock 450 218 466 minecraft:blackstone
fill 450 218 503 450 221 503 minecraft:blackstone
setblock 451 218 466 minecraft:polished_blackstone_bricks
setblock 452 218 465 minecraft:polished_blackstone_bricks
fill 452 218 466 453 220 466 minecraft:blackstone
setblock 453 218 464 minecraft:polished_blackstone_bricks
fill 453 218 465 453 221 465 minecraft:blackstone
setblock 453 218 504 minecraft:polished_blackstone_bricks
fill 454 218 464 454 221 464 minecraft:blackstone
fill 454 218 504 454 221 504 minecraft:blackstone
setblock 457 218 465 minecraft:polished_blackstone_bricks
setblock 458 218 464 minecraft:polished_blackstone_bricks
fill 458 218 465 461 218 465 minecraft:blackstone
setblock 458 218 504 minecraft:polished_blackstone_bricks
fill 459 218 464 459 221 464 minecraft:blackstone
fill 459 218 504 459 221 504 minecraft:blackstone
fill 461 218 503 461 220 503 minecraft:blackstone
setblock 462 218 465 minecraft:polished_blackstone_bricks
setblock 463 218 464 minecraft:polished_blackstone_bricks
fill 463 218 465 463 221 465 minecraft:blackstone
fill 463 218 467 463 219 467 minecraft:blackstone
fill 463 218 501 463 220 501 minecraft:blackstone
setblock 463 218 504 minecraft:polished_blackstone_bricks
fill 464 218 464 464 221 464 minecraft:blackstone
setblock 464 218 468 minecraft:polished_blackstone_bricks
fill 464 218 469 464 220 470 minecraft:blackstone
fill 464 218 480 464 218 482 minecraft:blackstone
setblock 464 218 483 minecraft:polished_blackstone_bricks
fill 464 218 484 464 218 487 minecraft:blackstone
setblock 464 218 498 minecraft:polished_blackstone_bricks
fill 464 218 499 464 221 499 minecraft:blackstone
setblock 464 218 503 minecraft:polished_blackstone_bricks
fill 464 218 504 464 221 504 minecraft:blackstone
setblock 424 219 467 minecraft:polished_blackstone_bricks
fill 424 219 468 424 221 469 minecraft:blackstone
fill 424 219 479 424 219 481 minecraft:blackstone
setblock 424 219 482 minecraft:polished_blackstone_bricks
fill 424 219 483 424 222 483 minecraft:blackstone
setblock 424 219 487 minecraft:polished_blackstone_bricks
fill 424 219 488 424 222 488 minecraft:blackstone
setblock 424 219 491 minecraft:blackstone
setblock 424 219 492 minecraft:polished_blackstone_bricks
fill 424 219 493 425 221 493 minecraft:blackstone
setblock 424 219 497 minecraft:polished_blackstone_bricks
fill 424 219 498 424 222 498 minecraft:blackstone
setblock 424 219 501 minecraft:blackstone
setblock 424 219 502 minecraft:polished_blackstone_bricks
fill 424 219 503 424 222 503 minecraft:blackstone
setblock 425 219 465 minecraft:blackstone
setblock 425 219 466 minecraft:polished_blackstone_bricks
fill 425 219 467 425 222 467 minecraft:blackstone
setblock 425 219 481 minecraft:polished_blackstone_bricks
fill 425 219 482 426 221 482 minecraft:blackstone
setblock 425 219 486 minecraft:polished_blackstone_bricks
fill 425 219 487 425 222 487 minecraft:blackstone
setblock 425 219 490 minecraft:blackstone
setblock 425 219 491 minecraft:polished_blackstone_bricks
fill 425 219 492 425 222 492 minecraft:blackstone
fill 425 219 494 425 219 495 minecraft:blackstone
setblock 425 219 496 minecraft:polished_blackstone_bricks
fill 425 219 497 425 222 497 minecraft:blackstone
setblock 425 219 501 minecraft:polished_blackstone_bricks
fill 425 219 502 425 222 502 minecraft:blackstone
setblock 426 219 465 minecraft:polished_blackstone_bricks
setblock 426 219 484 minecraft:blackstone
setblock 426 219 485 minecraft:polished_blackstone_bricks
fill 426 219 486 427 221 486 minecraft:blackstone
setblock 426 219 489 minecraft:blackstone
setblock 426 219 490 minecraft:polished_blackstone_bricks
fill 426 219 491 426 222 491 minecraft:blackstone
fill 426 219 498 426 220 498 minecraft:blackstone
setblock 426 219 500 minecraft:polished_blackstone_bricks
fill 426 219 501 426 222 501 minecraft:blackstone
setblock 427 219 464 minecraft:polished_blackstone_bricks
fill 427 219 465 427 222 465 minecraft:blackstone
fill 427 219 485 427 222 485 minecraft:blackstone
fill 427 219 487 427 220 487 minecraft:blackstone
setblock 427 219 504 minecraft:polished_blackstone_bricks
fill 428 219 464 428 222 464 minecraft:blackstone
setblock 428 219 503 minecraft:polished_blackstone_bricks
fill 428 219 504 428 222 504 minecraft:blackstone
setblock 429 219 502 minecraft:polished_blackstone_bricks
fill 429 219 503 429 222 503 minecraft:blackstone
fill 430 219 502 430 220 502 minecraft:blackstone
setblock 431 219 465 minecraft:polished_blackstone_bricks
setblock 432 219 464 minecraft:polished_blackstone_bricks
setblock 432 219 504 minecraft:polished_blackstone_bricks
fill 433 219 464 433 222 464 minecraft:blackstone
setblock 433 219 503 minecraft:polished_blackstone_bricks
fill 433 219 504 433 222 504 minecraft:blackstone
fill 435 219 464 435 220 464 minecraft:blackstone
fill 440 219 464 441 219 464 minecraft:blackstone
setblock 442 219 464 minecraft:polished_blackstone_bricks
setblock 442 219 504 minecraft:polished_blackstone_bricks
fill 443 219 464 443 221 465 minecraft:blackstone
fill 443 219 504 443 222 504 minecraft:blackstone
setblock 445 219 465 minecraft:blackstone
setblock 445 219 466 minecraft:polished_blackstone_bricks
setblock 446 219 465 minecraft:polished_blackstone_bricks
fill 446 219 466 446 222 466 minecraft:blackstone
setblock 447 219 464 minecraft:polished_blackstone_bricks
fill 447 219 465 447 222 465 minecraft:blackstone
setblock 447 219 504 minecraft:polished_blackstone_bricks
fill 448 219 464 448 222 464 minecraft:blackstone
setblock 448 219 503 minecraft:polished_blackstone_bricks
fill 448 219 504 448 222 504 minecraft:blackstone
fill 449 219 503 449 222 503 minecraft:blackstone
setblock 450 219 466 minecraft:polished_blackstone_bricks
setblock 451 219 465 minecraft:polished_blackstone_bricks
fill 451 219 466 451 222 466 minecraft:blackstone
setblock 452 219 464 minecraft:polished_blackstone_bricks
fill 452 219 465 452 222 465 minecraft:blackstone
setblock 452 219 504 minecraft:polished_blackstone_bricks
fill 453 219 464 453 222 464 minecraft:blackstone
setblock 453 219 503 minecraft:polished_blackstone_bricks
fill 453 219 504 453 222 504 minecraft:blackstone
setblock 454 219 466 minecraft:blackstone
setblock 455 219 465 minecraft:blackstone
setblock 456 219 465 minecraft:polished_blackstone_bricks
setblock 457 219 464 minecraft:polished_blackstone_bricks
fill 457 219 465 460 219 465 minecraft:blackstone
setblock 457 219 504 minecraft:polished_blackstone_bricks
fill 458 219 464 458 222 464 minecraft:blackstone
fill 458 219 504 458 222 504 minecraft:blackstone
setblock 461 219 465 minecraft:polished_blackstone_bricks
setblock 462 219 464 minecraft:polished_blackstone_bricks
fill 462 219 465 462 222 465 minecraft:blackstone
setblock 462 219 504 minecraft:polished_blackstone_bricks
fill 463 219 464 463 222 464 minecraft:blackstone
setblock 463 219 468 minecraft:polished_blackstone_bricks
setblock 463 219 503 minecraft:polished_blackstone_bricks
fill 463 219 504 463 222 504 minecraft:blackstone
setblock 464 219 466 minecraft:blackstone
setblock 464 219 467 minecraft:polished_blackstone_bricks
fill 464 219 468 464 222 468 minecraft:blackstone
setblock 464 219 471 minecraft:blackstone
fill 464 219 479 464 219 481 minecraft:blackstone
setblock 464 219 482 minecraft:polished_blackstone_bricks
fill 464 219 483 464 219 486 minecraft:blackstone
setblock 464 219 487 minecraft:polished_blackstone_bricks
fill 464 219 488 464 219 491 minecraft:blackstone
setblock 464 219 497 minecraft:polished_blackstone_bricks
fill 464 219 498 464 222 498 minecraft:blackstone
setblock 464 219 502 minecraft:polished_blackstone_bricks
fill 464 219 503 464 222 503 minecraft:blackstone
setblock 424 220 465 minecraft:blackstone
setblock 424 220 466 minecraft:polished_blackstone_bricks
fill 424 220 467 424 223 467 minecraft:blackstone
setblock 424 220 470 minecraft:blackstone
fill 424 220 478 424 220 480 minecraft:blackstone
setblock 424 220 481 minecraft:polished_blackstone_bricks
fill 424 220 482 424 223 482 minecraft:blackstone
setblock 424 220 485 minecraft:blackstone
setblock 424 220 486 minecraft:polished_blackstone_bricks
fill 424 220 487 424 223 487 minecraft:blackstone
setblock 424 220 491 minecraft:polished_blackstone_bricks
fill 424 220 492 424 223 492 minecraft:blackstone
setblock 424 220 496 minecraft:polished_blackstone_bricks
fill 424 220 497 424 223 497 minecraft:blackstone
setblock 424 220 501 minecraft:polished_blackstone_bricks
fill 424 220 502 424 223 502 minecraft:blackstone
setblock 425 220 465 minecraft:polished_blackstone_bricks
fill 425 220 466 427 221 466 minecraft:blackstone
fill 425 220 468 425 221 468 minecraft:blackstone
setblock 425 220 480 minecraft:polished_blackstone_bricks
fill 425 220 481 425 223 481 minecraft:blackstone
setblock 425 220 485 minecraft:polished_blackstone_bricks
fill 425 220 486 425 223 486 minecraft:blackstone
setblock 425 220 490 minecraft:polished_blackstone_bricks
fill 425 220 491 425 223 491 minecraft:blackstone
setblock 425 220 494 minecraft:blackstone
setblock 425 220 495 minecraft:polished_blackstone_bricks
fill 425 220 496 425 223 496 minecraft:blackstone
setblock 425 220 500 minecraft:polished_blackstone_bricks
fill 425 220 501 425 223 501 minecraft:blackstone
setblock 426 220 464 minecraft:polished_blackstone_bricks
fill 426 220 465 426 223 465 minecraft:blackstone
setblock 426 220 484 minecraft:polished_blackstone_bricks
fill 426 220 485 426 223 485 minecraft:blackstone
setblock 426 220 489 minecraft:polished_blackstone_bricks
fill 426 220 490 427 222 490 minecraft:blackstone
fill 426 220 492 426 220 493 minecraft:blackstone
setblock 426 220 494 minecraft:polished_blackstone_bricks
fill 426 220 495 426 223 495 minecraft:blackstone
fill 426 220 497 426 221 497 minecraft:blackstone
setblock 426 220 499 minecraft:polished_blackstone_bricks
fill 426 220 500 426 223 500 minecraft:blackstone
setblock 426 220 504 minecraft:polished_blackstone_bricks
fill 427 220 464 427 223 464 minecraft:blackstone
fill 427 220 484 427 223 484 minecraft:blackstone
setblock 427 220 488 minecraft:polished_blackstone_bricks
fill 427 220 489 427 223 489 minecraft:blackstone
setblock 427 220 503 minecraft:polished_blackstone_bricks
fill 427 220 504 427 223 504 minecraft:blackstone
setblock 428 220 502 minecraft:polished_blackstone_bricks
fill 428 220 503 428 223 503 minecraft:blackstone
setblock 429 220 465 minecraft:blackstone
fill 429 220 502 429 221 502 minecraft:blackstone
setblock 430 220 465 minecraft:polished_blackstone_bricks
setblock 431 220 464 minecraft:polished_blackstone_bricks
fill 431 220 465 432 221 465 minecraft:blackstone
setblock 431 220 504 minecraft:polished_blackstone_bricks
fill 432 220 464 432 223 464 minecraft:blackstone
setblock 432 220 503 minecraft:polished_blackstone_bricks
fill 432 220 504 432 223 504 minecraft:blackstone
setblock 433 220 503 minecraft:blackstone
setblock 436 220 464 minecraft:polished_blackstone_bricks
setblock 436 220 504 minecraft:polished_blackstone_bricks
fill 438 220 464 440 220 464 minecraft:blackstone
setblock 441 220 464 minecraft:polished_blackstone_bricks
setblock 441 220 504 minecraft:polished_blackstone_bricks
fill 442 220 464 442 222 465 minecraft:blackstone
fill 442 220 504 442 223 504 minecraft:blackstone
setblock 444 220 466 minecraft:polished_blackstone_bricks
setblock 445 220 465 minecraft:polished_blackstone_bricks
fill 445 220 466 445 223 466 minecraft:blackstone
fill 445 220 503 445 221 503 minecraft:blackstone
setblock 446 220 464 minecraft:polished_blackstone_bricks
fill 446 220 465 446 223 465 minecraft:blackstone
setblock 446 220 504 minecraft:polished_blackstone_bricks
fill 447 220 464 447 223 464 minecraft:blackstone
setblock 447 220 467 minecraft:blackstone
setblock 447 220 503 minecraft:polished_blackstone_bricks
fill 447 220 504 447 223 504 minecraft:blackstone
setblock 448 220 467 minecraft:polished_blackstone_bricks
fill 448 220 503 448 223 503 minecraft:blackstone
setblock 449 220 465 minecraft:blackstone
setblock 449 220 466 minecraft:polished_blackstone_bricks
fill 449 220 467 451 221 467 minecraft:blackstone
setblock 450 220 465 minecraft:polished_blackstone_bricks
fill 450 220 466 450 223 466 minecraft:blackstone
setblock 451 220 464 minecraft:polished_blackstone_bricks
fill 451 220 465 451 223 465 minecraft:blackstone
setblock 451 220 504 minecraft:polished_blackstone_bricks
fill 452 220 464 452 223 464 minecraft:blackstone
setblock 452 220 503 minecraft:polished_blackstone_bricks
fill 452 220 504 452 223 504 minecraft:blackstone
setblock 453 220 503 minecraft:blackstone
setblock 454 220 466 minecraft:polished_blackstone_bricks
setblock 455 220 465 minecraft:polished_blackstone_bricks
fill 455 220 466 456 222 466 minecraft:blackstone
setblock 456 220 464 minecraft:polished_blackstone_bricks
fill 456 220 465 459 220 465 minecraft:blackstone
setblock 456 220 504 minecraft:polished_blackstone_bricks
fill 457 220 464 457 223 464 minecraft:blackstone
fill 457 220 504 457 223 504 minecraft:blackstone
setblock 460 220 465 minecraft:polished_blackstone_bricks
fill 460 220 503 460 221 503 minecraft:blackstone
setblock 461 220 464 minecraft:polished_blackstone_bricks
fill 461 220 465 461 222 466 minecraft:blackstone
setblock 461 220 504 minecraft:polished_blackstone_bricks
fill 462 220 464 462 223 464 minecraft:blackstone
fill 462 220 466 462 220 467 minecraft:blackstone
setblock 462 220 503 minecraft:polished_blackstone_bricks
fill 462 220 504 462 223 504 minecraft:blackstone
setblock 463 220 467 minecraft:polished_blackstone_bricks
fill 463 220 468 463 222 469 minecraft:blackstone
fill 463 220 485 463 220 486 minecraft:blackstone
fill 463 220 500 463 221 500 minecraft:blackstone
setblock 463 220 502 minecraft:polished_blackstone_bricks
fill 463 220 503 463 223 503 minecraft:blackstone
setblock 464 220 466 minecraft:polished_blackstone_bricks
fill 464 220 467 464 223 467 minecraft:blackstone
setblock 464 220 471 minecraft:polished_blackstone_bricks
fill 464 220 472 464 222 473 minecraft:blackstone
fill 464 220 479 464 220 480 minecraft:blackstone
setblock 464 220 481 minecraft:polished_blackstone_bricks
fill 464 220 482 464 220 485 minecraft:blackstone
setblock 464 220 486 minecraft:polished_blackstone_bricks
fill 464 220 487 464 220 490 minecraft:blackstone
setblock 464 220 491 minecraft:polished_blackstone_bricks
fill 464 220 492 464 220 495 minecraft:blackstone
setblock 464 220 496 minecraft:polished_blackstone_bricks
fill 464 220 497 464 223 497 minecraft:blackstone
setblock 464 220 501 minecraft:polished_blackstone_bricks
fill 464 220 502 464 223 502 minecraft:blackstone
setblock 424 221 465 minecraft:polished_blackstone_bricks
fill 424 221 466 424 224 466 minecraft:blackstone
setblock 424 221 470 minecraft:polished_blackstone_bricks
fill 424 221 471 424 223 472 minecraft:blackstone
fill 424 221 478 424 221 479 minecraft:blackstone
setblock 424 221 480 minecraft:polished_blackstone_bricks
fill 424 221 481 424 224 481 minecraft:blackstone
setblock 424 221 485 minecraft:polished_blackstone_bricks
fill 424 221 486 424 224 486 minecraft:blackstone
setblock 424 221 489 minecraft:blackstone
setblock 424 221 490 minecraft:polished_blackstone_bricks
fill 424 221 491 424 224 491 minecraft:blackstone
setblock 424 221 495 minecraft:polished_blackstone_bricks
fill 424 221 496 424 224 496 minecraft:blackstone
setblock 424 221 500 minecraft:polished_blackstone_bricks
fill 424 221 501 424 224 501 minecraft:blackstone
setblock 425 221 464 minecraft:polished_blackstone_bricks
fill 425 221 465 425 224 465 minecraft:blackstone
setblock 425 221 469 minecraft:polished_blackstone_bricks
fill 425 221 480 425 223 480 minecraft:blackstone
setblock 425 221 483 minecraft:blackstone
setblock 425 221 484 minecraft:polished_blackstone_bricks
fill 425 221 485 425 224 485 minecraft:blackstone
setblock 425 221 488 minecraft:blackstone
setblock 425 221 489 minecraft:polished_blackstone_bricks
fill 425 221 490 425 224 490 minecraft:blackstone
setblock 425 221 494 minecraft:polished_blackstone_bricks
fill 425 221 495 425 224 495 minecraft:blackstone
setblock 425 221 499 minecraft:polished_blackstone_bricks
fill 425 221 500 425 224 500 minecraft:blackstone
setblock 425 221 504 minecraft:polished_blackstone_bricks
fill 426 221 464 426 224 464 minecraft:blackstone
setblock 426 221 467 minecraft:blackstone
setblock 426 221 483 minecraft:polished_blackstone_bricks
fill 426 221 484 426 224 484 minecraft:blackstone
setblock 426 221 488 minecraft:polished_blackstone_bricks
fill 426 221 489 426 224 489 minecraft:blackstone
setblock 426 221 492 minecraft:blackstone
setblock 426 221 493 minecraft:polished_blackstone_bricks
fill 426 221 494 426 224 494 minecraft:blackstone
fill 426 221 496 426 222 496 minecraft:blackstone
setblock 426 221 498 minecraft:polished_blackstone_bricks
fill 426 221 499 426 223 499 minecraft:blackstone
setblock 426 221 503 minecraft:polished_blackstone_bricks
fill 426 221 504 426 224 504 minecraft:blackstone
setblock 427 221 487 minecraft:polished_blackstone_bricks
fill 427 221 488 427 224 488 minecraft:blackstone
setblock 427 221 491 minecraft:blackstone
setblock 427 221 492 minecraft:polished_blackstone_bricks
setblock 427 221 502 minecraft:polished_blackstone_bricks
fill 427 221 503 427 224 503 minecraft:blackstone
setblock 428 221 466 minecraft:polished_blackstone_bricks
fill 428 221 502 428 222 502 minecraft:blackstone
setblock 429 221 465 minecraft:polished_blackstone_bricks
setblock 430 221 464 minecraft:polished_blackstone_bricks
fill 430 221 465 430 223 465 minecraft:blackstone
setblock 430 221 504 minecraft:polished_blackstone_bricks
fill 431 221 464 431 224 464 minecraft:blackstone
setblock 431 221 503 minecraft:polished_blackstone_bricks
fill 431 221 504 431 224 504 minecraft:blackstone
setblock 432 221 503 minecraft:blackstone
setblock 435 221 464 minecraft:polished_blackstone_bricks
setblock 435 221 504 minecraft:polished_blackstone_bricks
fill 436 221 464 439 221 464 minecraft:blackstone
setblock 440 221 464 minecraft:polished_blackstone_bricks
fill 441 221 464 441 223 465 minecraft:blackstone
fill 441 221 504 441 223 504 minecraft:blackstone
setblock 443 221 466 minecraft:polished_blackstone_bricks
setblock 444 221 464 minecraft:blackstone
setblock 444 221 465 minecraft:polished_blackstone_bricks
fill 444 221 466 444 224 466 minecraft:blackstone
setblock 445 221 464 minecraft:polished_blackstone_bricks
fill 445 221 465 445 224 465 minecraft:blackstone
fill 445 221 467 446 221 467 minecraft:blackstone
setblock 445 221 504 minecraft:polished_blackstone_bricks
fill 446 221 464 446 224 464 minecraft:blackstone
setblock 446 221 503 minecraft:polished_blackstone_bricks
fill 446 221 504 446 224 504 minecraft:blackstone
setblock 447 221 466 minecraft:blackstone
setblock 447 221 467 minecraft:polished_blackstone_bricks
fill 447 221 488 448 221 492 minecraft:cyan_concrete
fill 447 221 503 447 223 503 minecraft:blackstone
setblock 448 221 466 minecraft:polished_blackstone_bricks
fill 448 221 467 448 224 467 minecraft:blackstone
fill 448 221 487 454 221 487 minecraft:cyan_concrete
fill 448 221 493 456 221 493 minecraft:cyan_concrete
setblock 449 221 465 minecraft:polished_blackstone_bricks
fill 449 221 466 449 224 466 minecraft:blackstone
fill 449 221 486 453 221 486 minecraft:cyan_concrete
fill 449 221 488 449 223 488 minecraft:cyan_concrete
fill 449 221 492 449 223 492 minecraft:cyan_concrete
fill 449 221 494 453 221 494 minecraft:cyan_concrete
setblock 450 221 464 minecraft:polished_blackstone_bricks
fill 450 221 465 450 224 465 minecraft:blackstone
setblock 450 221 504 minecraft:polished_blackstone_bricks
fill 451 221 464 451 224 464 minecraft:blackstone
setblock 451 221 503 minecraft:polished_blackstone_bricks
fill 451 221 504 451 224 504 minecraft:blackstone
setblock 452 221 466 minecraft:blackstone
setblock 452 221 467 minecraft:polished_blackstone_bricks
fill 452 221 495 452 221 496 minecraft:cyan_concrete
setblock 452 221 503 minecraft:blackstone
setblock 453 221 466 minecraft:polished_blackstone_bricks
fill 453 221 488 455 221 488 minecraft:cyan_concrete
fill 453 221 492 455 221 492 minecraft:cyan_concrete
fill 453 221 496 453 221 497 minecraft:cyan_concrete
setblock 454 221 465 minecraft:polished_blackstone_bricks
fill 454 221 466 454 224 466 minecraft:blackstone
fill 454 221 489 455 221 491 minecraft:cyan_concrete
fill 454 221 497 455 221 497 minecraft:cyan_concrete
setblock 455 221 464 minecraft:polished_blackstone_bricks
fill 455 221 465 458 221 465 minecraft:blackstone
setblock 455 221 504 minecraft:polished_blackstone_bricks
fill 456 221 464 456 224 464 minecraft:blackstone
fill 456 221 494 456 222 496 minecraft:cyan_concrete
fill 456 221 498 457 221 501 minecraft:cyan_concrete
fill 456 221 504 456 224 504 minecraft:blackstone
setblock 457 221 466 minecraft:blackstone
fill 457 221 494 457 221 495 minecraft:cyan_concrete
fill 457 221 497 462 221 497 minecraft:cyan_concrete
fill 457 221 502 462 221 502 minecraft:cyan_concrete
setblock 458 221 466 minecraft:polished_blackstone_bricks
fill 458 221 496 460 221 496 minecraft:cyan_concrete
fill 458 221 498 458 223 498 minecraft:cyan_concrete
fill 458 221 501 458 223 501 minecraft:cyan_concrete
setblock 459 221 465 minecraft:polished_blackstone_bricks
fill 459 221 466 460 223 466 minecraft:blackstone
setblock 459 221 503 minecraft:cyan_concrete
setblock 460 221 464 minecraft:polished_blackstone_bricks
fill 460 221 465 460 224 465 minecraft:blackstone
setblock 460 221 504 minecraft:polished_blackstone_bricks
fill 461 221 464 461 224 464 minecraft:blackstone
fill 461 221 498 462 222 498 minecraft:cyan_concrete
fill 461 221 501 462 222 501 minecraft:cyan_concrete
setblock 461 221 503 minecraft:polished_blackstone_bricks
fill 461 221 504 461 224 504 minecraft:blackstone
setblock 462 221 466 minecraft:blackstone
setblock 462 221 467 minecraft:polished_blackstone_bricks
fill 462 221 468 462 224 468 minecraft:blackstone
fill 462 221 499 462 222 500 minecraft:cyan_concrete
fill 462 221 503 462 224 503 minecraft:blackstone
setblock 463 221 466 minecraft:polished_blackstone_bricks
fill 463 221 467 463 224 467 minecraft:blackstone
setblock 463 221 470 minecraft:blackstone
fill 463 221 484 463 221 485 minecraft:blackstone
setblock 463 221 486 minecraft:polished_blackstone_bricks
fill 463 221 487 463 221 490 minecraft:blackstone
setblock 463 221 499 minecraft:cyan_concrete
setblock 463 221 501 minecraft:polished_blackstone_bricks
fill 463 221 502 463 224 502 minecraft:blackstone
setblock 464 221 465 minecraft:polished_blackstone_bricks
fill 464 221 466 464 224 466 minecraft:blackstone
setblock 464 221 469 minecraft:blackstone
setblock 464 221 470 minecraft:polished_blackstone_bricks
fill 464 221 471 464 224 471 minecraft:blackstone
setblock 464 221 474 minecraft:blackstone
setblock 464 221 479 minecraft:blackstone
setblock 464 221 480 minecraft:polished_blackstone_bricks
fill 464 221 481 464 221 484 minecraft:blackstone
setblock 464 221 485 minecraft:polished_blackstone_bricks
fill 464 221 486 464 221 489 minecraft:blackstone
setblock 464 221 490 minecraft:polished_blackstone_bricks
fill 464 221 491 464 221 494 minecraft:blackstone
setblock 464 221 495 minecraft:polished_blackstone_bricks
fill 464 221 496 464 224 496 minecraft:blackstone
setblock 464 221 500 minecraft:polished_blackstone_bricks
fill 464 221 501 464 224 501 minecraft:blackstone
setblock 424 222 464 minecraft:polished_blackstone_bricks
fill 424 222 465 424 224 465 minecraft:blackstone
setblock 424 222 468 minecraft:blackstone
setblock 424 222 469 minecraft:polished_blackstone_bricks
fill 424 222 470 425 224 470 minecraft:blackstone
setblock 424 222 473 minecraft:blackstone
setblock 424 222 478 minecraft:blackstone
setblock 424 222 479 minecraft:polished_blackstone_bricks
fill 424 222 480 424 224 480 minecraft:blackstone
setblock 424 222 484 minecraft:polished_blackstone_bricks
fill 424 222 485 424 224 485 minecraft:blackstone
setblock 424 222 489 minecraft:polished_blackstone_bricks
fill 424 222 490 424 224 490 minecraft:blackstone
setblock 424 222 493 minecraft:blackstone
setblock 424 222 494 minecraft:polished_blackstone_bricks
fill 424 222 495 424 224 495 minecraft:blackstone
setblock 424 222 499 minecraft:polished_blackstone_bricks
fill 424 222 500 424 224 500 minecraft:blackstone
setblock 424 222 504 minecraft:polished_blackstone_bricks
fill 425 222 464 425 224 464 minecraft:blackstone
fill 425 222 466 426 222 466 minecraft:blackstone
setblock 425 222 468 minecraft:polished_blackstone_bricks
fill 425 222 469 425 224 469 minecraft:blackstone
setblock 425 222 482 minecraft:blackstone
setblock 425 222 483 minecraft:polished_blackstone_bricks
fill 425 222 484 425 224 484 minecraft:blackstone
setblock 425 222 488 minecraft:polished_blackstone_bricks
fill 425 222 489 425 224 489 minecraft:blackstone
setblock 425 222 493 minecraft:polished_blackstone_bricks
fill 425 222 494 425 224 494 minecraft:blackstone
setblock 425 222 498 minecraft:polished_blackstone_bricks
fill 425 222 499 425 224 499 minecraft:blackstone
setblock 425 222 503 minecraft:polished_blackstone_bricks
fill 425 222 504 425 224 504 minecraft:blackstone
setblock 426 222 467 minecraft:polished_blackstone_bricks
setblock 426 222 474 minecraft:light[level=11]
setblock 426 222 482 minecraft:polished_blackstone_bricks
fill 426 222 483 426 224 483 minecraft:blackstone
setblock 426 222 486 minecraft:blackstone
setblock 426 222 487 minecraft:polished_blackstone_bricks
fill 426 222 488 426 224 488 minecraft:blackstone
setblock 426 222 492 minecraft:polished_blackstone_bricks
fill 426 222 493 427 224 493 minecraft:blackstone
setblock 426 222 497 minecraft:polished_blackstone_bricks
fill 426 222 498 426 223 498 minecraft:blackstone
setblock 426 222 502 minecraft:polished_blackstone_bricks
fill 426 222 503 426 224 503 minecraft:blackstone
setblock 427 222 466 minecraft:polished_blackstone_bricks
setblock 427 222 486 minecraft:polished_blackstone_bricks
fill 427 222 487 427 224 487 minecraft:blackstone
setblock 427 222 491 minecraft:polished_blackstone_bricks
fill 427 222 492 427 224 492 minecraft:blackstone
fill 427 222 502 427 223 502 minecraft:blackstone
setblock 428 222 465 minecraft:polished_blackstone_bricks
setblock 428 222 466 minecraft:blackstone
setblock 429 222 464 minecraft:polished_blackstone_bricks
fill 429 222 465 429 224 465 minecraft:blackstone
setblock 429 222 504 minecraft:polished_blackstone_bricks
fill 430 222 464 430 224 464 minecraft:blackstone
setblock 430 222 503 minecraft:polished_blackstone_bricks
fill 430 222 504 430 224 504 minecraft:blackstone
fill 431 222 465 431 223 465 minecraft:blackstone
setblock 431 222 503 minecraft:blackstone
setblock 434 222 464 minecraft:polished_blackstone_bricks
setblock 434 222 466 minecraft:light[level=11]
setblock 434 222 474 minecraft:light[level=11]
setblock 434 222 482 minecraft:light[level=11]
setblock 434 222 490 minecraft:light[level=11]
setblock 434 222 498 minecraft:light[level=11]
setblock 434 222 504 minecraft:polished_blackstone_bricks
fill 435 222 464 438 222 464 minecraft:blackstone
setblock 439 222 464 minecraft:polished_blackstone_bricks
fill 440 222 464 440 224 465 minecraft:blackstone
setblock 442 222 466 minecraft:polished_blackstone_bricks
setblock 442 222 474 minecraft:light[level=11]
setblock 442 222 482 minecraft:light[level=11]
setblock 442 222 490 minecraft:light[level=11]
setblock 442 222 498 minecraft:light[level=11]
setblock 443 222 464 minecraft:blackstone
setblock 443 222 465 minecraft:polished_blackstone_bricks
fill 443 222 466 443 224 466 minecraft:blackstone
setblock 444 222 464 minecraft:polished_blackstone_bricks
fill 444 222 465 444 224 465 minecraft:blackstone
fill 444 222 467 445 222 467 minecraft:blackstone
setblock 444 222 504 minecraft:polished_blackstone_bricks
fill 445 222 464 445 224 464 minecraft:blackstone
setblock 445 222 503 minecraft:polished_blackstone_bricks
fill 445 222 504 445 224 504 minecraft:blackstone
setblock 446 222 467 minecraft:polished_blackstone_bricks
fill 446 222 503 446 223 503 minecraft:blackstone
setblock 447 222 466 minecraft:polished_blackstone_bricks
fill 447 222 467 447 224 467 minecraft:blackstone
setblock 448 222 465 minecraft:polished_blackstone_bricks
fill 448 222 466 448 224 466 minecraft:blackstone
fill 448 222 488 448 222 492 minecraft:cyan_concrete
setblock 449 222 464 minecraft:polished_blackstone_bricks
fill 449 222 465 449 224 465 minecraft:blackstone
fill 449 222 467 450 222 467 minecraft:blackstone
fill 449 222 487 453 222 487 minecraft:cyan_concrete
fill 449 222 493 455 222 493 minecraft:cyan_concrete
setblock 449 222 504 minecraft:polished_blackstone_bricks
fill 450 222 464 450 224 464 minecraft:blackstone
setblock 450 222 474 minecraft:light[level=11]
setblock 450 222 482 minecraft:light[level=11]
fill 450 222 486 452 222 486 minecraft:cyan_concrete
setblock 450 222 498 minecraft:light[level=11]
setblock 450 222 503 minecraft:polished_blackstone_bricks
fill 450 222 504 450 224 504 minecraft:blackstone
setblock 451 222 467 minecraft:polished_blackstone_bricks
setblock 452 222 466 minecraft:polished_blackstone_bricks
setblock 452 222 467 minecraft:blackstone
setblock 453 222 465 minecraft:polished_blackstone_bricks
fill 453 222 466 453 224 466 minecraft:blackstone
fill 453 222 488 454 222 488 minecraft:cyan_concrete
fill 453 222 492 454 222 492 minecraft:cyan_concrete
fill 453 222 494 453 223 494 minecraft:cyan_concrete
fill 453 222 496 453 223 496 minecraft:cyan_concrete
setblock 454 222 464 minecraft:polished_blackstone_bricks
fill 454 222 465 457 222 465 minecraft:blackstone
fill 454 222 489 454 223 491 minecraft:cyan_concrete
setblock 454 222 497 minecraft:cyan_concrete
setblock 454 222 504 minecraft:polished_blackstone_bricks
fill 455 222 464 455 224 464 minecraft:blackstone
setblock 455 222 490 minecraft:cyan_concrete
fill 455 222 504 455 224 504 minecraft:blackstone
setblock 457 222 466 minecraft:polished_blackstone_bricks
fill 457 222 498 457 222 501 minecraft:cyan_concrete
setblock 458 222 465 minecraft:polished_blackstone_bricks
fill 458 222 466 458 224 466 minecraft:blackstone
setblock 458 222 474 minecraft:light[level=11]
setblock 458 222 482 minecraft:light[level=11]
setblock 458 222 490 minecraft:light[level=11]
fill 458 222 497 461 222 497 minecraft:cyan_concrete
fill 458 222 502 461 222 502 minecraft:cyan_concrete
setblock 459 222 464 minecraft:polished_blackstone_bricks
fill 459 222 465 459 224 465 minecraft:blackstone
setblock 459 222 504 minecraft:polished_blackstone_bricks
fill 460 222 464 460 224 464 minecraft:blackstone
setblock 460 222 503 minecraft:polished_blackstone_bricks
fill 460 222 504 460 224 504 minecraft:blackstone
fill 461 222 503 461 224 503 minecraft:blackstone
setblock 462 222 466 minecraft:polished_blackstone_bricks
fill 462 222 467 462 224 467 minecraft:blackstone
setblock 463 222 465 minecraft:polished_blackstone_bricks
fill 463 222 466 463 224 466 minecraft:blackstone
setblock 463 222 470 minecraft:polished_blackstone_bricks
fill 463 222 471 463 224 471 minecraft:blackstone
setblock 463 222 484 minecraft:blackstone
setblock 463 222 485 minecraft:polished_blackstone_bricks
fill 463 222 486 463 222 489 minecraft:blackstone
setblock 463 222 490 minecraft:polished_blackstone_bricks
fill 463 222 491 464 222 493 minecraft:blackstone
setblock 463 222 499 minecraft:blackstone
setblock 463 222 500 minecraft:polished_blackstone_bricks
fill 463 222 501 463 224 501 minecraft:blackstone
setblock 464 222 464 minecraft:polished_blackstone_bricks
fill 464 222 465 464 224 465 minecraft:blackstone
setblock 464 222 469 minecraft:polished_blackstone_bricks
fill 464 222 470 464 224 470 minecraft:blackstone
setblock 464 222 474 minecraft:polished_blackstone_bricks
fill 464 222 475 464 224 475 minecraft:blackstone
setblock 464 222 479 minecraft:polished_blackstone_bricks
fill 464 222 480 464 222 483 minecraft:blackstone
setblock 464 222 484 minecraft:polished_blackstone_bricks
fill 464 222 485 464 222 488 minecraft:blackstone
setblock 464 222 489 minecraft:polished_blackstone_bricks
fill 464 222 490 464 224 490 minecraft:blackstone
setblock 464 222 494 minecraft:polished_blackstone_bricks
fill 464 222 495 464 224 495 minecraft:blackstone
setblock 464 222 499 minecraft:polished_blackstone_bricks
fill 464 222 500 464 224 500 minecraft:blackstone
setblock 464 222 504 minecraft:polished_blackstone_bricks
fill 424 223 464 424 224 464 minecraft:blackstone
setblock 424 223 468 minecraft:polished_blackstone_bricks
fill 424 223 469 424 224 469 minecraft:blackstone
setblock 424 223 473 minecraft:polished_blackstone_bricks
fill 424 223 474 424 224 474 minecraft:blackstone
setblock 424 223 477 minecraft:blackstone
setblock 424 223 478 minecraft:polished_blackstone_bricks
fill 424 223 479 424 224 479 minecraft:blackstone
setblock 424 223 483 minecraft:polished_blackstone_bricks
fill 424 223 484 424 224 484 minecraft:blackstone
setblock 424 223 488 minecraft:polished_blackstone_bricks
fill 424 223 489 424 224 489 minecraft:blackstone
setblock 424 223 493 minecraft:polished_blackstone_bricks
fill 424 223 494 424 224 494 minecraft:blackstone
setblock 424 223 498 minecraft:polished_blackstone_bricks
fill 424 223 499 424 224 499 minecraft:blackstone
setblock 424 223 503 minecraft:polished_blackstone_bricks
fill 424 223 504 424 224 504 minecraft:blackstone
setblock 425 223 466 minecraft:blackstone
setblock 425 223 467 minecraft:polished_blackstone_bricks
fill 425 223 468 425 224 468 minecraft:blackstone
setblock 425 223 471 minecraft:blackstone
setblock 425 223 482 minecraft:polished_blackstone_bricks
fill 425 223 483 425 224 483 minecraft:blackstone
setblock 425 223 487 minecraft:polished_blackstone_bricks
fill 425 223 488 425 224 488 minecraft:blackstone
setblock 425 223 492 minecraft:polished_blackstone_bricks
fill 425 223 493 425 224 493 minecraft:blackstone
setblock 425 223 497 minecraft:polished_blackstone_bricks
fill 425 223 498 425 224 498 minecraft:blackstone
setblock 425 223 502 minecraft:polished_blackstone_bricks
fill 425 223 503 425 224 503 minecraft:blackstone
setblock 426 223 466 minecraft:polished_blackstone_bricks
fill 426 223 467 426 224 467 minecraft:blackstone
setblock 426 223 482 minecraft:blackstone
setblock 426 223 486 minecraft:polished_blackstone_bricks
fill 426 223 487 426 224 487 minecraft:blackstone
setblock 426 223 490 minecraft:blackstone
setblock 426 223 491 minecraft:polished_blackstone_bricks
fill 426 223 492 426 224 492 minecraft:blackstone
setblock 426 223 496 minecraft:polished_blackstone_bricks
fill 426 223 497 426 224 497 minecraft:blackstone
setblock 426 223 501 minecraft:polished_blackstone_bricks
setblock 426 223 502 minecraft:blackstone
setblock 427 223 465 minecraft:polished_blackstone_bricks
setblock 427 223 466 minecraft:blackstone
setblock 427 223 485 minecraft:polished_blackstone_bricks
fill 427 223 486 427 224 486 minecraft:blackstone
setblock 427 223 490 minecraft:polished_blackstone_bricks
fill 427 223 491 427 224 491 minecraft:blackstone
setblock 428 223 464 minecraft:polished_blackstone_bricks
fill 428 223 465 428 224 465 minecraft:blackstone
setblock 428 223 504 minecraft:polished_blackstone_bricks
fill 429 223 464 429 224 464 minecraft:blackstone
setblock 429 223 503 minecraft:polished_blackstone_bricks
fill 429 223 504 429 224 504 minecraft:blackstone
setblock 430 223 503 minecraft:blackstone
setblock 433 223 464 minecraft:polished_blackstone_bricks
setblock 434 223 464 minecraft:blackstone
setblock 437 223 464 minecraft:blackstone
setblock 438 223 464 minecraft:polished_blackstone_bricks
fill 439 223 464 439 224 464 minecraft:blackstone
setblock 442 223 464 minecraft:blackstone
setblock 442 223 465 minecraft:polished_blackstone_bricks
fill 442 223 466 442 224 466 minecraft:blackstone
setblock 443 223 464 minecraft:polished_blackstone_bricks
fill 443 223 465 443 224 465 minecraft:blackstone
setblock 443 223 504 minecraft:polished_blackstone_bricks
fill 444 223 464 444 224 464 minecraft:blackstone
setblock 444 223 467 minecraft:blackstone
fill 444 223 504 444 224 504 minecraft:blackstone
setblock 445 223 467 minecraft:polished_blackstone_bricks
setblock 446 223 466 minecraft:polished_blackstone_bricks
fill 446 223 467 446 224 467 minecraft:blackstone
setblock 447 223 465 minecraft:polished_blackstone_bricks
fill 447 223 466 447 224 466 minecraft:blackstone
setblock 448 223 464 minecraft:polished_blackstone_bricks
fill 448 223 465 448 224 465 minecraft:blackstone
fill 448 223 489 448 223 490 minecraft:cyan_concrete
setblock 448 223 504 minecraft:polished_blackstone_bricks
fill 449 223 464 449 224 464 minecraft:blackstone
setblock 449 223 467 minecraft:blackstone
fill 449 223 504 449 224 504 minecraft:blackstone
setblock 450 223 467 minecraft:polished_blackstone_bricks
fill 450 223 487 452 223 487 minecraft:cyan_concrete
setblock 451 223 466 minecraft:polished_blackstone_bricks
setblock 451 223 467 minecraft:blackstone
setblock 451 223 493 minecraft:cyan_concrete
setblock 452 223 465 minecraft:polished_blackstone_bricks
fill 452 223 466 452 224 466 minecraft:blackstone
setblock 453 223 464 minecraft:polished_blackstone_bricks
fill 453 223 465 456 223 465 minecraft:blackstone
setblock 453 223 488 minecraft:cyan_concrete
setblock 453 223 492 minecraft:cyan_concrete
setblock 453 223 504 minecraft:polished_blackstone_bricks
fill 454 223 464 454 224 464 minecraft:blackstone
fill 454 223 493 455 223 493 minecraft:cyan_concrete
fill 454 223 504 454 224 504 minecraft:blackstone
setblock 455 223 466 minecraft:blackstone
setblock 456 223 466 minecraft:polished_blackstone_bricks
fill 456 223 494 456 223 495 minecraft:cyan_concrete
setblock 457 223 465 minecraft:polished_blackstone_bricks
setblock 457 223 466 minecraft:blackstone
fill 457 223 499 457 223 500 minecraft:cyan_concrete
setblock 458 223 464 minecraft:polished_blackstone_bricks
fill 458 223 465 458 224 465 minecraft:blackstone
setblock 458 223 504 minecraft:polished_blackstone_bricks
fill 459 223 464 459 224 464 minecraft:blackstone
fill 459 223 497 460 223 497 minecraft:cyan_concrete
fill 459 223 502 460 223 502 minecraft:cyan_concrete
fill 459 223 504 459 224 504 minecraft:blackstone
fill 460 223 503 460 224 503 minecraft:blackstone
setblock 461 223 465 minecraft:blackstone
setblock 461 223 466 minecraft:polished_blackstone_bricks
setblock 461 223 498 minecraft:cyan_concrete
setblock 461 223 501 minecraft:cyan_concrete
setblock 462 223 465 minecraft:polished_blackstone_bricks
fill 462 223 466 462 224 466 minecraft:blackstone
setblock 462 223 469 minecraft:blackstone
setblock 463 223 464 minecraft:polished_blackstone_bricks
fill 463 223 465 463 224 465 minecraft:blackstone
setblock 463 223 468 minecraft:blackstone
setblock 463 223 469 minecraft:polished_blackstone_bricks
fill 463 223 470 463 224 470 minecraft:blackstone
fill 463 223 472 464 223 472 minecraft:blackstone
setblock 463 223 484 minecraft:polished_blackstone_bricks
fill 463 223 485 463 223 488 minecraft:blackstone
setblock 463 223 489 minecraft:polished_blackstone_bricks
fill 463 223 490 463 223 493 minecraft:blackstone
setblock 463 223 494 minecraft:polished_blackstone_bricks
fill 463 223 495 463 223 498 minecraft:blackstone
setblock 463 223 499 minecraft:polished_blackstone_bricks
fill 463 223 500 463 224 500 minecraft:blackstone
setblock 463 223 504 minecraft:polished_blackstone_bricks
fill 464 223 464 464 224 464 minecraft:blackstone
setblock 464 223 468 minecraft:polished_blackstone_bricks
fill 464 223 469 464 224 469 minecraft:blackstone
setblock 464 223 473 minecraft:polished_blackstone_bricks
fill 464 223 474 464 224 474 minecraft:blackstone
fill 464 223 480 464 223 482 minecraft:blackstone
setblock 464 223 483 minecraft:polished_blackstone_bricks
fill 464 223 484 464 223 487 minecraft:blackstone
setblock 464 223 488 minecraft:polished_blackstone_bricks
fill 464 223 489 464 224 489 minecraft:blackstone
fill 464 223 491 464 223 492 minecraft:blackstone
setblock 464 223 493 minecraft:polished_blackstone_bricks
fill 464 223 494 464 224 494 minecraft:blackstone
setblock 464 223 498 minecraft:polished_blackstone_bricks
fill 464 223 499 464 224 499 minecraft:blackstone
setblock 464 223 503 minecraft:polished_blackstone_bricks
fill 464 223 504 464 224 504 minecraft:blackstone
setblock 424 224 467 minecraft:polished_blackstone_bricks
setblock 424 224 468 minecraft:blackstone
setblock 424 224 471 minecraft:blackstone
setblock 424 224 472 minecraft:polished_blackstone_bricks
setblock 424 224 473 minecraft:blackstone
setblock 424 224 475 minecraft:blackstone
setblock 424 224 478 minecraft:blackstone
setblock 424 224 482 minecraft:polished_blackstone_bricks
setblock 424 224 483 minecraft:blackstone
setblock 424 224 487 minecraft:polished_blackstone_bricks
setblock 424 224 488 minecraft:blackstone
setblock 424 224 492 minecraft:polished_blackstone_bricks
setblock 424 224 493 minecraft:blackstone
setblock 424 224 497 minecraft:polished_blackstone_bricks
setblock 424 224 498 minecraft:blackstone
setblock 424 224 502 minecraft:polished_blackstone_bricks
setblock 424 224 503 minecraft:blackstone
setblock 425 224 466 minecraft:polished_blackstone_bricks
setblock 425 224 467 minecraft:blackstone
setblock 425 224 471 minecraft:polished_blackstone_bricks
setblock 425 224 481 minecraft:polished_blackstone_bricks
setblock 425 224 482 minecraft:blackstone
setblock 425 224 486 minecraft:polished_blackstone_bricks
setblock 425 224 487 minecraft:blackstone
setblock 425 224 491 minecraft:polished_blackstone_bricks
setblock 425 224 492 minecraft:blackstone
setblock 425 224 496 minecraft:polished_blackstone_bricks
setblock 425 224 497 minecraft:blackstone
setblock 425 224 501 minecraft:polished_blackstone_bricks
setblock 425 224 502 minecraft:blackstone
setblock 426 224 465 minecraft:polished_blackstone_bricks
setblock 426 224 466 minecraft:blackstone
setblock 426 224 485 minecraft:polished_blackstone_bricks
setblock 426 224 486 minecraft:blackstone
setblock 426 224 490 minecraft:polished_blackstone_bricks
setblock 426 224 491 minecraft:blackstone
setblock 426 224 495 minecraft:polished_blackstone_bricks
setblock 426 224 496 minecraft:blackstone
setblock 427 224 464 minecraft:polished_blackstone_bricks
setblock 427 224 465 minecraft:blackstone
setblock 427 224 485 minecraft:blackstone
setblock 427 224 489 minecraft:polished_blackstone_bricks
setblock 427 224 490 minecraft:blackstone
setblock 427 224 504 minecraft:polished_blackstone_bricks
setblock 428 224 464 minecraft:blackstone
setblock 428 224 503 minecraft:polished_blackstone_bricks
setblock 428 224 504 minecraft:blackstone
setblock 432 224 464 minecraft:polished_blackstone_bricks
setblock 438 224 464 minecraft:blackstone
setblock 441 224 464 minecraft:blackstone
setblock 441 224 465 minecraft:polished_blackstone_bricks
setblock 441 224 466 minecraft:blackstone
setblock 442 224 464 minecraft:polished_blackstone_bricks
setblock 442 224 465 minecraft:blackstone
setblock 442 224 504 minecraft:polished_blackstone_bricks
setblock 443 224 464 minecraft:blackstone
setblock 443 224 467 minecraft:blackstone
setblock 443 224 504 minecraft:blackstone
setblock 444 224 467 minecraft:polished_blackstone_bricks
setblock 445 224 466 minecraft:polished_blackstone_bricks
setblock 445 224 467 minecraft:blackstone
setblock 446 224 465 minecraft:polished_blackstone_bricks
setblock 446 224 466 minecraft:blackstone
setblock 447 224 464 minecraft:polished_blackstone_bricks
setblock 447 224 465 minecraft:blackstone
setblock 447 224 504 minecraft:polished_blackstone_bricks
setblock 448 224 464 minecraft:blackstone
setblock 448 224 504 minecraft:blackstone
setblock 449 224 467 minecraft:polished_blackstone_bricks
setblock 450 224 466 minecraft:polished_blackstone_bricks
setblock 450 224 467 minecraft:blackstone
setblock 451 224 465 minecraft:polished_blackstone_bricks
setblock 451 224 466 minecraft:blackstone
setblock 452 224 464 minecraft:polished_blackstone_bricks
fill 452 224 465 455 224 465 minecraft:blackstone
setblock 452 224 504 minecraft:polished_blackstone_bricks
setblock 453 224 464 minecraft:blackstone
setblock 453 224 504 minecraft:blackstone
setblock 455 224 466 minecraft:polished_blackstone_bricks
setblock 456 224 465 minecraft:polished_blackstone_bricks
setblock 457 224 464 minecraft:polished_blackstone_bricks
setblock 457 224 465 minecraft:blackstone
setblock 457 224 504 minecraft:polished_blackstone_bricks
setblock 458 224 464 minecraft:blackstone
setblock 458 224 504 minecraft:blackstone
setblock 459 224 466 minecraft:blackstone
setblock 460 224 466 minecraft:polished_blackstone_bricks
setblock 461 224 465 minecraft:polished_blackstone_bricks
setblock 461 224 466 minecraft:blackstone
setblock 462 224 464 minecraft:polished_blackstone_bricks
setblock 462 224 465 minecraft:blackstone
setblock 462 224 469 minecraft:polished_blackstone_bricks
setblock 462 224 504 minecraft:polished_blackstone_bricks
setblock 463 224 464 minecraft:blackstone
setblock 463 224 468 minecraft:polished_blackstone_bricks
setblock 463 224 469 minecraft:blackstone
setblock 463 224 472 minecraft:blackstone
fill 463 224 484 463 224 487 minecraft:blackstone
setblock 463 224 488 minecraft:polished_blackstone_bricks
fill 463 224 489 463 224 492 minecraft:blackstone
setblock 463 224 493 minecraft:polished_blackstone_bricks
fill 463 224 494 463 224 497 minecraft:blackstone
setblock 463 224 498 minecraft:polished_blackstone_bricks
setblock 463 224 499 minecraft:blackstone
setblock 463 224 503 minecraft:polished_blackstone_bricks
setblock 463 224 504 minecraft:blackstone
setblock 464 224 467 minecraft:polished_blackstone_bricks
setblock 464 224 468 minecraft:blackstone
setblock 464 224 472 minecraft:polished_blackstone_bricks
setblock 464 224 473 minecraft:blackstone
setblock 464 224 481 minecraft:blackstone
setblock 464 224 482 minecraft:polished_blackstone_bricks
fill 464 224 483 464 224 486 minecraft:blackstone
setblock 464 224 487 minecraft:polished_blackstone_bricks
setblock 464 224 488 minecraft:blackstone
setblock 464 224 491 minecraft:blackstone
setblock 464 224 492 minecraft:polished_blackstone_bricks
setblock 464 224 493 minecraft:blackstone
setblock 464 224 497 minecraft:polished_blackstone_bricks
setblock 464 224 498 minecraft:blackstone
setblock 464 224 502 minecraft:polished_blackstone_bricks
setblock 464 224 503 minecraft:blackstone
fill 424 230 464 424 231 465 minecraft:blackstone
fill 424 230 466 424 230 470 minecraft:soul_soil
fill 424 230 471 424 230 475 minecraft:blackstone
fill 424 230 476 424 230 480 minecraft:soul_soil
fill 424 230 481 424 230 485 minecraft:blackstone
fill 424 230 486 424 230 490 minecraft:soul_soil
fill 424 230 491 424 230 495 minecraft:blackstone
fill 424 230 496 424 230 500 minecraft:soul_soil
fill 424 230 501 424 230 504 minecraft:blackstone
fill 425 230 464 429 230 465 minecraft:soul_soil
fill 425 230 466 429 230 470 minecraft:blackstone
fill 425 230 471 429 230 475 minecraft:soul_soil
fill 425 230 476 429 230 480 minecraft:blackstone
fill 425 230 481 429 230 485 minecraft:soul_soil
fill 425 230 486 429 230 490 minecraft:blackstone
fill 425 230 491 429 230 495 minecraft:soul_soil
fill 425 230 496 429 230 500 minecraft:blackstone
fill 425 230 501 429 230 504 minecraft:soul_soil
fill 430 230 464 434 230 465 minecraft:blackstone
fill 430 230 466 434 230 470 minecraft:soul_soil
fill 430 230 471 434 230 475 minecraft:blackstone
fill 430 230 476 434 230 480 minecraft:soul_soil
fill 430 230 481 434 230 485 minecraft:blackstone
fill 430 230 486 434 230 490 minecraft:soul_soil
fill 430 230 491 434 230 495 minecraft:blackstone
fill 430 230 496 434 230 500 minecraft:soul_soil
fill 430 230 501 434 230 504 minecraft:blackstone
fill 435 230 464 439 230 465 minecraft:soul_soil
fill 435 230 466 439 230 470 minecraft:blackstone
fill 435 230 471 439 230 475 minecraft:soul_soil
fill 435 230 476 439 230 480 minecraft:blackstone
fill 435 230 481 439 230 485 minecraft:soul_soil
fill 435 230 486 439 230 490 minecraft:blackstone
fill 435 230 491 439 230 495 minecraft:soul_soil
fill 435 230 496 439 230 500 minecraft:blackstone
fill 435 230 501 439 230 504 minecraft:soul_soil
fill 440 230 464 444 230 465 minecraft:blackstone
fill 440 230 466 444 230 470 minecraft:soul_soil
fill 440 230 471 444 230 475 minecraft:blackstone
fill 440 230 476 444 230 480 minecraft:soul_soil
fill 440 230 481 443 230 485 minecraft:blackstone
fill 440 230 486 442 230 490 minecraft:soul_soil
fill 440 230 491 444 230 495 minecraft:blackstone
fill 440 230 496 444 230 500 minecraft:soul_soil
fill 440 230 501 444 230 504 minecraft:blackstone
fill 443 230 487 443 230 490 minecraft:soul_soil
fill 444 230 481 444 230 484 minecraft:blackstone
fill 444 230 488 444 230 490 minecraft:soul_soil
fill 445 230 464 449 230 465 minecraft:soul_soil
fill 445 230 466 449 230 470 minecraft:blackstone
fill 445 230 471 449 230 475 minecraft:soul_soil
fill 445 230 476 449 230 480 minecraft:blackstone
fill 445 230 481 449 230 483 minecraft:soul_soil
fill 445 230 489 449 230 490 minecraft:blackstone
fill 445 230 491 449 230 495 minecraft:soul_soil
fill 445 230 496 449 230 500 minecraft:blackstone
fill 445 230 501 449 230 504 minecraft:soul_soil
fill 446 230 484 449 230 484 minecraft:soul_soil
fill 446 230 488 449 230 488 minecraft:blackstone
fill 447 230 485 449 230 485 minecraft:soul_soil
fill 447 230 487 449 230 487 minecraft:blackstone
fill 448 230 486 449 230 486 minecraft:blackstone
fill 450 230 464 454 230 465 minecraft:blackstone
fill 450 230 466 454 230 470 minecraft:soul_soil
fill 450 230 471 454 230 475 minecraft:blackstone
fill 450 230 476 454 230 480 minecraft:soul_soil
fill 450 230 481 454 230 485 minecraft:blackstone
fill 450 230 486 454 230 490 minecraft:soul_soil
fill 450 230 491 454 230 495 minecraft:blackstone
fill 450 230 496 454 230 500 minecraft:soul_soil
fill 450 230 501 454 230 504 minecraft:blackstone
fill 455 230 464 459 230 465 minecraft:soul_soil
fill 455 230 466 459 230 470 minecraft:blackstone
fill 455 230 471 459 230 475 minecraft:soul_soil
fill 455 230 476 459 230 480 minecraft:blackstone
fill 455 230 481 459 230 485 minecraft:soul_soil
fill 455 230 486 459 230 490 minecraft:blackstone
fill 455 230 491 459 230 495 minecraft:soul_soil
fill 455 230 496 459 230 500 minecraft:blackstone
fill 455 230 501 459 230 504 minecraft:soul_soil
fill 460 230 464 464 230 465 minecraft:blackstone
fill 460 230 466 464 230 470 minecraft:soul_soil
fill 460 230 471 464 230 475 minecraft:blackstone
fill 460 230 476 464 230 480 minecraft:soul_soil
fill 460 230 481 464 230 485 minecraft:blackstone
fill 460 230 486 464 230 490 minecraft:soul_soil
fill 460 230 491 464 230 495 minecraft:blackstone
fill 460 230 496 464 230 500 minecraft:soul_soil
fill 460 230 501 464 230 504 minecraft:blackstone
fill 424 231 466 464 231 466 minecraft:polished_blackstone
fill 424 231 467 424 231 470 minecraft:soul_soil
fill 424 231 471 464 231 471 minecraft:polished_blackstone
fill 424 231 472 424 231 475 minecraft:blackstone
fill 424 231 476 464 231 476 minecraft:polished_blackstone
fill 424 231 477 424 231 480 minecraft:soul_soil
fill 424 231 481 464 231 481 minecraft:polished_blackstone
fill 424 231 482 424 231 485 minecraft:blackstone
fill 424 231 486 441 231 486 minecraft:polished_blackstone
fill 424 231 487 424 231 490 minecraft:soul_soil
fill 424 231 491 464 231 491 minecraft:polished_blackstone
fill 424 231 492 424 231 495 minecraft:blackstone
fill 424 231 496 464 231 496 minecraft:polished_blackstone
fill 424 231 497 424 231 500 minecraft:soul_soil
fill 424 231 501 464 231 501 minecraft:polished_blackstone
fill 424 231 502 424 231 504 minecraft:blackstone
fill 425 231 464 425 231 465 minecraft:polished_blackstone
fill 425 231 467 425 231 470 minecraft:polished_blackstone
fill 425 231 472 425 231 475 minecraft:polished_blackstone
fill 425 231 477 425 231 480 minecraft:polished_blackstone
fill 425 231 482 425 231 485 minecraft:polished_blackstone
fill 425 231 487 425 231 490 minecraft:polished_blackstone
fill 425 231 492 425 231 495 minecraft:polished_blackstone
fill 425 231 497 425 231 500 minecraft:polished_blackstone
fill 425 231 502 425 231 504 minecraft:polished_blackstone
fill 426 231 464 429 231 465 minecraft:soul_soil
fill 426 231 467 429 231 470 minecraft:blackstone
fill 426 231 472 429 231 475 minecraft:soul_soil
fill 426 231 477 429 231 480 minecraft:blackstone
fill 426 231 482 429 231 485 minecraft:soul_soil
fill 426 231 487 429 231 490 minecraft:blackstone
fill 426 231 492 429 231 495 minecraft:soul_soil
fill 426 231 497 429 231 500 minecraft:blackstone
fill 426 231 502 429 231 504 minecraft:soul_soil
fill 430 231 464 430 231 465 minecraft:polished_blackstone
fill 430 231 467 430 231 470 minecraft:polished_blackstone
fill 430 231 472 430 231 475 minecraft:polished_blackstone
fill 430 231 477 430 231 480 minecraft:polished_blackstone
fill 430 231 482 430 231 485 minecraft:polished_blackstone
fill 430 231 487 430 231 490 minecraft:polished_blackstone
fill 430 231 492 430 231 495 minecraft:polished_blackstone
fill 430 231 497 430 231 500 minecraft:polished_blackstone
fill 430 231 502 430 231 504 minecraft:polished_blackstone
fill 431 231 464 434 231 465 minecraft:blackstone
fill 431 231 467 434 231 470 minecraft:soul_soil
fill 431 231 472 434 231 475 minecraft:blackstone
fill 431 231 477 434 231 480 minecraft:soul_soil
fill 431 231 482 434 231 485 minecraft:blackstone
fill 431 231 487 434 231 490 minecraft:soul_soil
fill 431 231 492 434 231 495 minecraft:blackstone
fill 431 231 497 434 231 500 minecraft:soul_soil
fill 431 231 502 434 231 504 minecraft:blackstone
fill 435 231 464 435 231 465 minecraft:polished_blackstone
fill 435 231 467 435 231 470 minecraft:polished_blackstone
fill 435 231 472 435 231 475 minecraft:polished_blackstone
fill 435 231 477 435 231 480 minecraft:polished_blackstone
fill 435 231 482 435 231 485 minecraft:polished_blackstone
fill 435 231 487 435 231 490 minecraft:polished_blackstone
fill 435 231 492 435 231 495 minecraft:polished_blackstone
fill 435 231 497 435 231 500 minecraft:polished_blackstone
fill 435 231 502 435 231 504 minecraft:polished_blackstone
fill 436 231 464 439 231 465 minecraft:soul_soil
fill 436 231 467 439 231 470 minecraft:blackstone
fill 436 231 472 439 231 475 minecraft:soul_soil
fill 436 231 477 439 231 480 minecraft:blackstone
fill 436 231 482 439 231 485 minecraft:soul_soil
fill 436 231 487 439 231 490 minecraft:blackstone
fill 436 231 492 439 231 495 minecraft:soul_soil
fill 436 231 497 439 231 500 minecraft:blackstone
fill 436 231 502 439 231 504 minecraft:soul_soil
fill 440 231 464 440 231 465 minecraft:polished_blackstone
fill 440 231 467 440 231 470 minecraft:polished_blackstone
fill 440 231 472 440 231 475 minecraft:polished_blackstone
fill 440 231 477 440 231 480 minecraft:polished_blackstone
fill 440 231 482 440 231 485 minecraft:polished_blackstone
fill 440 231 487 440 231 490 minecraft:polished_blackstone
fill 440 231 492 440 231 495 minecraft:polished_blackstone
fill 440 231 497 440 231 500 minecraft:polished_blackstone
fill 440 231 502 440 231 504 minecraft:polished_blackstone
fill 441 231 464 444 231 465 minecraft:blackstone
fill 441 231 467 444 231 470 minecraft:soul_soil
fill 441 231 472 444 231 475 minecraft:blackstone
fill 441 231 477 444 231 480 minecraft:soul_soil
fill 441 231 482 441 231 485 minecraft:blackstone
fill 441 231 487 441 231 490 minecraft:soul_soil
fill 441 231 492 444 231 495 minecraft:blackstone
fill 441 231 497 444 231 500 minecraft:soul_soil
fill 441 231 502 444 231 504 minecraft:blackstone
fill 442 231 482 442 231 484 minecraft:blackstone
fill 442 231 485 442 231 487 minecraft:sea_lantern
fill 442 231 488 442 231 490 minecraft:soul_soil
fill 443 231 482 443 231 483 minecraft:blackstone
fill 443 231 484 443 231 485 minecraft:sea_lantern
fill 443 231 487 443 231 488 minecraft:sea_lantern
fill 443 231 489 443 231 490 minecraft:soul_soil
setblock 444 231 482 minecraft:blackstone
fill 444 231 483 444 231 484 minecraft:sea_lantern
fill 444 231 488 444 231 489 minecraft:sea_lantern
setblock 444 231 490 minecraft:soul_soil
fill 445 231 464 445 231 465 minecraft:polished_blackstone
fill 445 231 467 445 231 470 minecraft:polished_blackstone
fill 445 231 472 445 231 475 minecraft:polished_blackstone
fill 445 231 477 445 231 480 minecraft:polished_blackstone
setblock 445 231 482 minecraft:polished_blackstone
fill 445 231 483 446 231 483 minecraft:sea_lantern
fill 445 231 489 446 231 489 minecraft:sea_lantern
setblock 445 231 490 minecraft:polished_blackstone
fill 445 231 492 445 231 495 minecraft:polished_blackstone
fill 445 231 497 445 231 500 minecraft:polished_blackstone
fill 445 231 502 445 231 504 minecraft:polished_blackstone
fill 446 231 464 449 231 465 minecraft:soul_soil
fill 446 231 467 449 231 470 minecraft:blackstone
fill 446 231 472 449 231 475 minecraft:soul_soil
fill 446 231 477 449 231 480 minecraft:blackstone
fill 446 231 482 449 231 482 minecraft:soul_soil
fill 446 231 484 447 231 484 minecraft:sea_lantern
fill 446 231 488 447 231 488 minecraft:sea_lantern
fill 446 231 490 449 231 490 minecraft:blackstone
fill 446 231 492 449 231 495 minecraft:soul_soil
fill 446 231 497 449 231 500 minecraft:blackstone
fill 446 231 502 449 231 504 minecraft:soul_soil
fill 447 231 483 449 231 483 minecraft:soul_soil
fill 447 231 485 448 231 485 minecraft:sea_lantern
fill 447 231 487 448 231 487 minecraft:sea_lantern
fill 447 231 489 449 231 489 minecraft:blackstone
fill 448 231 484 449 231 484 minecraft:soul_soil
setblock 448 231 486 minecraft:sea_lantern
fill 448 231 488 449 231 488 minecraft:blackstone
setblock 449 231 485 minecraft:soul_soil
fill 449 231 486 464 231 486 minecraft:polished_blackstone
setblock 449 231 487 minecraft:blackstone
fill 450 231 464 450 231 465 minecraft:polished_blackstone
fill 450 231 467 450 231 470 minecraft:polished_blackstone
fill 450 231 472 450 231 475 minecraft:polished_blackstone
fill 450 231 477 450 231 480 minecraft:polished_blackstone
fill 450 231 482 450 231 485 minecraft:polished_blackstone
fill 450 231 487 450 231 490 minecraft:polished_blackstone
fill 450 231 492 450 231 495 minecraft:polished_blackstone
fill 450 231 497 450 231 500 minecraft:polished_blackstone
fill 450 231 502 450 231 504 minecraft:polished_blackstone
fill 451 231 464 454 231 465 minecraft:blackstone
fill 451 231 467 454 231 470 minecraft:soul_soil
fill 451 231 472 454 231 475 minecraft:blackstone
fill 451 231 477 454 231 480 minecraft:soul_soil
fill 451 231 482 454 231 485 minecraft:blackstone
fill 451 231 487 454 231 490 minecraft:soul_soil
fill 451 231 492 454 231 495 minecraft:blackstone
fill 451 231 497 454 231 500 minecraft:soul_soil
fill 451 231 502 454 231 504 minecraft:blackstone
fill 455 231 464 455 231 465 minecraft:polished_blackstone
fill 455 231 467 455 231 470 minecraft:polished_blackstone
fill 455 231 472 455 231 475 minecraft:polished_blackstone
fill 455 231 477 455 231 480 minecraft:polished_blackstone
fill 455 231 482 455 231 485 minecraft:polished_blackstone
fill 455 231 487 455 231 490 minecraft:polished_blackstone
fill 455 231 492 455 231 495 minecraft:polished_blackstone
fill 455 231 497 455 231 500 minecraft:polished_blackstone
fill 455 231 502 455 231 504 minecraft:polished_blackstone
fill 456 231 464 459 231 465 minecraft:soul_soil
fill 456 231 467 459 231 470 minecraft:blackstone
fill 456 231 472 459 231 475 minecraft:soul_soil
fill 456 231 477 459 231 480 minecraft:blackstone
fill 456 231 482 459 231 485 minecraft:soul_soil
fill 456 231 487 459 231 490 minecraft:blackstone
fill 456 231 492 459 231 495 minecraft:soul_soil
fill 456 231 497 459 231 500 minecraft:blackstone
fill 456 231 502 459 231 504 minecraft:soul_soil
fill 460 231 464 460 231 465 minecraft:polished_blackstone
fill 460 231 467 460 231 470 minecraft:polished_blackstone
fill 460 231 472 460 231 475 minecraft:polished_blackstone
fill 460 231 477 460 231 480 minecraft:polished_blackstone
fill 460 231 482 460 231 485 minecraft:polished_blackstone
fill 460 231 487 460 231 490 minecraft:polished_blackstone
fill 460 231 492 460 231 495 minecraft:polished_blackstone
fill 460 231 497 460 231 500 minecraft:polished_blackstone
fill 460 231 502 460 231 504 minecraft:polished_blackstone
fill 461 231 464 464 231 465 minecraft:blackstone
fill 461 231 467 464 231 470 minecraft:soul_soil
fill 461 231 472 464 231 475 minecraft:blackstone
fill 461 231 477 464 231 480 minecraft:soul_soil
fill 461 231 482 464 231 485 minecraft:blackstone
fill 461 231 487 464 231 490 minecraft:soul_soil
fill 461 231 492 464 231 495 minecraft:blackstone
fill 461 231 497 464 231 500 minecraft:soul_soil
fill 461 231 502 464 231 504 minecraft:blackstone
fill 424 235 469 424 235 470 minecraft:blackstone
setblock 424 235 471 minecraft:polished_blackstone_bricks
fill 424 235 472 424 235 475 minecraft:blackstone
setblock 424 235 476 minecraft:polished_blackstone_bricks
fill 424 235 477 424 235 480 minecraft:blackstone
setblock 424 235 481 minecraft:polished_blackstone_bricks
fill 424 235 482 424 235 485 minecraft:blackstone
setblock 424 235 486 minecraft:polished_blackstone_bricks
fill 424 235 487 424 235 490 minecraft:blackstone
setblock 424 235 491 minecraft:polished_blackstone_bricks
fill 424 235 492 424 235 495 minecraft:blackstone
setblock 424 235 496 minecraft:polished_blackstone_bricks
fill 424 235 497 424 235 500 minecraft:blackstone
setblock 424 235 501 minecraft:polished_blackstone_bricks
fill 424 235 502 424 237 503 minecraft:blackstone
fill 425 235 472 425 235 474 minecraft:blackstone
setblock 425 235 475 minecraft:polished_blackstone_bricks
fill 425 235 476 425 235 479 minecraft:blackstone
setblock 425 235 480 minecraft:polished_blackstone_bricks
fill 425 235 481 425 237 482 minecraft:blackstone
fill 425 235 488 425 235 489 minecraft:blackstone
setblock 425 235 490 minecraft:polished_blackstone_bricks
fill 425 235 491 425 235 494 minecraft:blackstone
setblock 425 235 495 minecraft:polished_blackstone_bricks
fill 425 235 496 425 235 499 minecraft:blackstone
setblock 425 235 500 minecraft:polished_blackstone_bricks
setblock 435 235 464 minecraft:blackstone
setblock 436 235 464 minecraft:polished_blackstone_bricks
fill 437 235 464 439 235 465 minecraft:blackstone
fill 437 235 504 440 235 504 minecraft:blackstone
setblock 440 235 464 minecraft:blackstone
setblock 440 235 465 minecraft:polished_blackstone_bricks
fill 440 235 466 441 235 466 minecraft:blackstone
setblock 441 235 464 minecraft:polished_blackstone_bricks
fill 441 235 465 444 235 465 minecraft:blackstone
setblock 441 235 504 minecraft:polished_blackstone_bricks
fill 442 235 464 445 235 464 minecraft:blackstone
fill 442 235 504 445 235 504 minecraft:blackstone
fill 445 235 495 446 235 496 minecraft:cyan_stained_glass
setblock 446 235 464 minecraft:polished_blackstone_bricks
setblock 446 235 504 minecraft:polished_blackstone_bricks
fill 447 235 464 448 237 464 minecraft:blackstone
setblock 451 235 504 minecraft:polished_blackstone_bricks
fill 452 235 464 455 235 464 minecraft:blackstone
fill 452 235 504 455 235 504 minecraft:blackstone
fill 454 235 503 456 235 503 minecraft:blackstone
fill 455 235 502 457 235 502 minecraft:blackstone
setblock 456 235 464 minecraft:polished_blackstone_bricks
setblock 456 235 504 minecraft:polished_blackstone_bricks
fill 457 235 464 459 235 465 minecraft:blackstone
setblock 457 235 503 minecraft:polished_blackstone_bricks
fill 457 235 504 460 235 504 minecraft:blackstone
setblock 458 235 501 minecraft:blackstone
setblock 458 235 502 minecraft:polished_blackstone_bricks
fill 458 235 503 461 235 503 minecraft:blackstone
setblock 459 235 501 minecraft:polished_blackstone_bricks
fill 459 235 502 462 235 502 minecraft:blackstone
setblock 460 235 464 minecraft:blackstone
setblock 460 235 465 minecraft:polished_blackstone_bricks
setblock 460 235 495 minecraft:polished_blackstone_bricks
fill 460 235 496 461 235 498 minecraft:blackstone
fill 460 235 501 463 235 501 minecraft:blackstone
setblock 461 235 464 minecraft:polished_blackstone_bricks
fill 461 235 492 461 235 493 minecraft:blackstone
setblock 461 235 494 minecraft:polished_blackstone_bricks
fill 461 235 495 464 235 495 minecraft:blackstone
setblock 461 235 499 minecraft:polished_blackstone_bricks
fill 461 235 500 464 235 500 minecraft:blackstone
setblock 461 235 504 minecraft:polished_blackstone_bricks
fill 462 235 464 463 235 464 minecraft:blackstone
fill 462 235 490 462 235 492 minecraft:blackstone
setblock 462 235 493 minecraft:polished_blackstone_bricks
fill 462 235 494 464 236 494 minecraft:blackstone
fill 462 235 496 462 235 497 minecraft:blackstone
setblock 462 235 498 minecraft:polished_blackstone_bricks
fill 462 235 499 464 236 499 minecraft:blackstone
setblock 462 235 503 minecraft:polished_blackstone_bricks
fill 462 235 504 464 236 504 minecraft:blackstone
setblock 463 235 471 minecraft:blackstone
setblock 463 235 472 minecraft:polished_blackstone_bricks
fill 463 235 473 463 235 476 minecraft:blackstone
setblock 463 235 477 minecraft:polished_blackstone_bricks
fill 463 235 478 464 236 479 minecraft:blackstone
fill 463 235 488 463 235 491 minecraft:blackstone
setblock 463 235 492 minecraft:polished_blackstone_bricks
fill 463 235 493 464 237 493 minecraft:blackstone
setblock 463 235 496 minecraft:blackstone
setblock 463 235 497 minecraft:polished_blackstone_bricks
fill 463 235 498 464 237 498 minecraft:blackstone
setblock 463 235 502 minecraft:polished_blackstone_bricks
fill 463 235 503 464 237 503 minecraft:blackstone
fill 464 235 468 464 235 470 minecraft:blackstone
setblock 464 235 471 minecraft:polished_blackstone_bricks
fill 464 235 472 464 235 475 minecraft:blackstone
setblock 464 235 476 minecraft:polished_blackstone_bricks
fill 464 235 477 464 238 477 minecraft:blackstone
setblock 464 235 480 minecraft:blackstone
setblock 464 235 481 minecraft:polished_blackstone_bricks
fill 464 235 482 464 235 485 minecraft:blackstone
setblock 464 235 486 minecraft:polished_blackstone_bricks
fill 464 235 487 464 235 490 minecraft:blackstone
setblock 464 235 491 minecraft:polished_blackstone_bricks
fill 464 235 492 464 238 492 minecraft:blackstone
setblock 464 235 496 minecraft:polished_blackstone_bricks
fill 464 235 497 464 238 497 minecraft:blackstone
setblock 464 235 501 minecraft:polished_blackstone_bricks
fill 464 235 502 464 238 502 minecraft:blackstone
setblock 424 236 469 minecraft:blackstone
setblock 424 236 470 minecraft:polished_blackstone_bricks
fill 424 236 471 424 236 474 minecraft:blackstone
setblock 424 236 475 minecraft:polished_blackstone_bricks
fill 424 236 476 424 236 479 minecraft:blackstone
setblock 424 236 480 minecraft:polished_blackstone_bricks
fill 424 236 481 424 236 484 minecraft:blackstone
setblock 424 236 485 minecraft:polished_blackstone_bricks
fill 424 236 486 424 236 489 minecraft:blackstone
setblock 424 236 490 minecraft:polished_blackstone_bricks
fill 424 236 491 424 236 494 minecraft:blackstone
setblock 424 236 495 minecraft:polished_blackstone_bricks
fill 424 236 496 424 236 499 minecraft:blackstone
setblock 424 236 500 minecraft:polished_blackstone_bricks
fill 424 236 501 424 239 501 minecraft:blackstone
fill 425 236 472 425 236 473 minecraft:blackstone
setblock 425 236 474 minecraft:polished_blackstone_bricks
fill 425 236 475 425 236 478 minecraft:blackstone
setblock 425 236 479 minecraft:polished_blackstone_bricks
fill 425 236 480 430 237 480 minecraft:blackstone
fill 425 236 483 430 236 483 minecraft:blackstone
setblock 425 236 489 minecraft:polished_blackstone_bricks
fill 425 236 490 425 236 493 minecraft:blackstone
setblock 425 236 494 minecraft:polished_blackstone_bricks
fill 425 236 495 425 236 498 minecraft:blackstone
setblock 425 236 499 minecraft:polished_blackstone_bricks
fill 425 236 500 425 237 500 minecraft:blackstone
fill 426 236 481 430 237 482 minecraft:blackstone
fill 426 236 484 430 237 484 minecraft:blackstone
setblock 435 236 464 minecraft:polished_blackstone_bricks
fill 436 236 464 439 236 464 minecraft:blackstone
fill 436 236 504 439 236 504 minecraft:blackstone
fill 437 236 465 438 236 465 minecraft:blackstone
fill 438 236 503 440 236 503 minecraft:blackstone
setblock 439 236 465 minecraft:polished_blackstone_bricks
fill 439 236 466 440 236 466 minecraft:blackstone
setblock 440 236 464 minecraft:polished_blackstone_bricks
fill 440 236 465 443 236 465 minecraft:blackstone
setblock 440 236 504 minecraft:polished_blackstone_bricks
fill 441 236 464 444 236 464 minecraft:blackstone
setblock 441 236 503 minecraft:polished_blackstone_bricks
fill 441 236 504 444 236 504 minecraft:blackstone
fill 442 236 503 443 238 503 minecraft:blackstone
setblock 444 236 465 minecraft:polished_blackstone_bricks
setblock 445 236 464 minecraft:polished_blackstone_bricks
setblock 445 236 504 minecraft:polished_blackstone_bricks
fill 446 236 464 446 239 464 minecraft:blackstone
fill 446 236 504 449 236 504 minecraft:blackstone
setblock 449 236 464 minecraft:blackstone
setblock 450 236 464 minecraft:polished_blackstone_bricks
setblock 450 236 504 minecraft:polished_blackstone_bricks
fill 451 236 464 454 236 464 minecraft:blackstone
fill 451 236 504 454 236 504 minecraft:blackstone
fill 452 236 503 455 236 503 minecraft:blackstone
fill 454 236 502 456 236 502 minecraft:blackstone
setblock 455 236 464 minecraft:polished_blackstone_bricks
setblock 455 236 504 minecraft:polished_blackstone_bricks
fill 456 236 464 458 236 465 minecraft:blackstone
fill 456 236 501 457 236 501 minecraft:blackstone
setblock 456 236 503 minecraft:polished_blackstone_bricks
fill 456 236 504 459 236 504 minecraft:blackstone
setblock 457 236 502 minecraft:polished_blackstone_bricks
fill 457 236 503 460 236 503 minecraft:blackstone
setblock 458 236 501 minecraft:polished_blackstone_bricks
fill 458 236 502 461 236 502 minecraft:blackstone
setblock 459 236 464 minecraft:blackstone
setblock 459 236 465 minecraft:polished_blackstone_bricks
setblock 459 236 500 minecraft:polished_blackstone_bricks
fill 459 236 501 462 236 501 minecraft:blackstone
setblock 460 236 464 minecraft:polished_blackstone_bricks
fill 460 236 495 460 236 498 minecraft:blackstone
setblock 460 236 499 minecraft:polished_blackstone_bricks
setblock 460 236 504 minecraft:polished_blackstone_bricks
fill 461 236 464 462 237 464 minecraft:blackstone
setblock 461 236 493 minecraft:polished_blackstone_bricks
fill 461 236 494 461 236 497 minecraft:blackstone
setblock 461 236 498 minecraft:polished_blackstone_bricks
fill 461 236 499 461 238 500 minecraft:blackstone
setblock 461 236 503 minecraft:polished_blackstone_bricks
fill 461 236 504 461 239 504 minecraft:blackstone
fill 462 236 490 462 236 491 minecraft:blackstone
setblock 462 236 492 minecraft:polished_blackstone_bricks
fill 462 236 493 462 238 493 minecraft:blackstone
fill 462 236 495 462 236 496 minecraft:blackstone
setblock 462 236 497 minecraft:polished_blackstone_bricks
fill 462 236 498 462 239 498 minecraft:blackstone
fill 462 236 500 463 236 500 minecraft:blackstone
setblock 462 236 502 minecraft:polished_blackstone_bricks
fill 462 236 503 462 239 503 minecraft:blackstone
fill 463 236 472 463 236 475 minecraft:blackstone
setblock 463 236 476 minecraft:polished_blackstone_bricks
fill 463 236 477 463 239 477 minecraft:blackstone
setblock 463 236 480 minecraft:blackstone
fill 463 236 488 463 236 490 minecraft:blackstone
setblock 463 236 491 minecraft:polished_blackstone_bricks
fill 463 236 492 463 239 492 minecraft:blackstone
setblock 463 236 495 minecraft:blackstone
setblock 463 236 496 minecraft:polished_blackstone_bricks
fill 463 236 497 463 239 497 minecraft:blackstone
setblock 463 236 501 minecraft:polished_blackstone_bricks
fill 463 236 502 463 239 502 minecraft:blackstone
setblock 464 236 470 minecraft:polished_blackstone_bricks
fill 464 236 471 464 236 474 minecraft:blackstone
setblock 464 236 475 minecraft:polished_blackstone_bricks
fill 464 236 476 464 239 476 minecraft:blackstone
setblock 464 236 480 minecraft:polished_blackstone_bricks
fill 464 236 481 464 236 484 minecraft:blackstone
setblock 464 236 485 minecraft:polished_blackstone_bricks
fill 464 236 486 464 236 489 minecraft:blackstone
setblock 464 236 490 minecraft:polished_blackstone_bricks
fill 464 236 491 464 239 491 minecraft:blackstone
setblock 464 236 495 minecraft:polished_blackstone_bricks
fill 464 236 496 464 239 496 minecraft:blackstone
setblock 464 236 500 minecraft:polished_blackstone_bricks
fill 464 236 501 464 239 501 minecraft:blackstone
fill 424 237 470 424 237 473 minecraft:blackstone
setblock 424 237 474 minecraft:polished_blackstone_bricks
fill 424 237 475 424 237 478 minecraft:blackstone
setblock 424 237 479 minecraft:polished_blackstone_bricks
fill 424 237 480 424 237 483 minecraft:blackstone
setblock 424 237 484 minecraft:polished_blackstone_bricks
fill 424 237 485 424 237 488 minecraft:blackstone
setblock 424 237 489 minecraft:polished_blackstone_bricks
fill 424 237 490 424 237 493 minecraft:blackstone
setblock 424 237 494 minecraft:polished_blackstone_bricks
fill 424 237 495 424 237 498 minecraft:blackstone
setblock 424 237 499 minecraft:polished_blackstone_bricks
fill 424 237 500 424 240 500 minecraft:blackstone
setblock 425 237 473 minecraft:polished_blackstone_bricks
fill 425 237 474 425 237 477 minecraft:blackstone
setblock 425 237 478 minecraft:polished_blackstone_bricks
fill 425 237 479 425 240 479 minecraft:blackstone
setblock 425 237 483 minecraft:polished_blackstone_bricks
fill 425 237 491 425 237 492 minecraft:blackstone
setblock 425 237 493 minecraft:polished_blackstone_bricks
fill 425 237 494 425 237 497 minecraft:blackstone
setblock 425 237 498 minecraft:polished_blackstone_bricks
fill 425 237 499 425 238 499 minecraft:blackstone
fill 426 237 483 430 237 483 minecraft:blackstone
setblock 434 237 464 minecraft:polished_blackstone_bricks
setblock 434 237 504 minecraft:polished_blackstone_bricks
fill 435 237 464 438 237 464 minecraft:blackstone
fill 435 237 504 438 237 504 minecraft:blackstone
fill 436 237 465 437 237 465 minecraft:blackstone
fill 437 237 503 439 237 503 minecraft:blackstone
setblock 438 237 465 minecraft:polished_blackstone_bricks
setblock 439 237 464 minecraft:polished_blackstone_bricks
fill 439 237 465 442 237 465 minecraft:blackstone
setblock 439 237 504 minecraft:polished_blackstone_bricks
fill 440 237 464 443 237 464 minecraft:blackstone
setblock 440 237 503 minecraft:polished_blackstone_bricks
fill 440 237 504 443 237 504 minecraft:blackstone
fill 441 237 503 441 240 503 minecraft:blackstone
setblock 443 237 465 minecraft:polished_blackstone_bricks
setblock 444 237 464 minecraft:polished_blackstone_bricks
setblock 444 237 504 minecraft:polished_blackstone_bricks
fill 445 237 464 445 240 464 minecraft:blackstone
fill 445 237 504 448 237 504 minecraft:blackstone
setblock 449 237 464 minecraft:polished_blackstone_bricks
setblock 449 237 504 minecraft:polished_blackstone_bricks
fill 450 237 464 453 237 464 minecraft:blackstone
fill 450 237 504 453 237 504 minecraft:blackstone
fill 451 237 503 454 237 503 minecraft:blackstone
fill 453 237 502 455 237 502 minecraft:blackstone
setblock 454 237 464 minecraft:polished_blackstone_bricks
setblock 454 237 504 minecraft:polished_blackstone_bricks
fill 455 237 464 458 237 464 minecraft:blackstone
fill 455 237 501 456 237 501 minecraft:blackstone
setblock 455 237 503 minecraft:polished_blackstone_bricks
fill 455 237 504 458 237 504 minecraft:blackstone
fill 456 237 465 457 237 465 minecraft:blackstone
setblock 456 237 502 minecraft:polished_blackstone_bricks
fill 456 237 503 459 237 503 minecraft:blackstone
setblock 457 237 501 minecraft:polished_blackstone_bricks
fill 457 237 502 460 237 502 minecraft:blackstone
setblock 458 237 465 minecraft:polished_blackstone_bricks
setblock 458 237 500 minecraft:polished_blackstone_bricks
fill 458 237 501 461 237 501 minecraft:blackstone
setblock 459 237 464 minecraft:polished_blackstone_bricks
fill 459 237 500 460 237 500 minecraft:blackstone
setblock 459 237 504 minecraft:polished_blackstone_bricks
fill 460 237 464 460 240 464 minecraft:blackstone
fill 460 237 496 460 237 497 minecraft:blackstone
setblock 460 237 498 minecraft:polished_blackstone_bricks
fill 460 237 499 460 238 499 minecraft:blackstone
setblock 460 237 503 minecraft:polished_blackstone_bricks
fill 460 237 504 460 240 504 minecraft:blackstone
fill 461 237 493 461 237 496 minecraft:blackstone
setblock 461 237 497 minecraft:polished_blackstone_bricks
fill 461 237 498 461 239 498 minecraft:blackstone
setblock 461 237 502 minecraft:polished_blackstone_bricks
fill 461 237 503 461 240 503 minecraft:blackstone
setblock 462 237 491 minecraft:polished_blackstone_bricks
fill 462 237 492 462 238 492 minecraft:blackstone
fill 462 237 494 462 237 495 minecraft:blackstone
setblock 462 237 496 minecraft:polished_blackstone_bricks
fill 462 237 497 462 240 497 minecraft:blackstone
fill 462 237 499 462 237 500 minecraft:blackstone
setblock 462 237 501 minecraft:polished_blackstone_bricks
fill 462 237 502 462 240 502 minecraft:blackstone
fill 462 237 504 463 237 504 minecraft:blackstone
fill 463 237 473 463 237 474 minecraft:blackstone
setblock 463 237 475 minecraft:polished_blackstone_bricks
fill 463 237 476 463 238 476 minecraft:blackstone
fill 463 237 478 463 237 479 minecraft:blackstone
setblock 463 237 480 minecraft:polished_blackstone_bricks
fill 463 237 481 464 239 481 minecraft:blackstone
setblock 463 237 489 minecraft:blackstone
setblock 463 237 490 minecraft:polished_blackstone_bricks
fill 463 237 491 463 238 491 minecraft:blackstone
setblock 463 237 494 minecraft:blackstone
setblock 463 237 495 minecraft:polished_blackstone_bricks
fill 463 237 496 463 240 496 minecraft:blackstone
setblock 463 237 499 minecraft:blackstone
setblock 463 237 500 minecraft:polished_blackstone_bricks
fill 463 237 501 463 240 501 minecraft:blackstone
fill 464 237 471 464 237 473 minecraft:blackstone
setblock 464 237 474 minecraft:polished_blackstone_bricks
fill 464 237 475 464 239 475 minecraft:blackstone
setblock 464 237 478 minecraft:blackstone
setblock 464 237 479 minecraft:polished_blackstone_bricks
fill 464 237 480 464 240 480 minecraft:blackstone
fill 464 237 482 464 237 483 minecraft:blackstone
setblock 464 237 484 minecraft:polished_blackstone_bricks
fill 464 237 485 464 237 488 minecraft:blackstone
setblock 464 237 489 minecraft:polished_blackstone_bricks
fill 464 237 490 464 239 490 minecraft:blackstone
setblock 464 237 494 minecraft:polished_blackstone_bricks
fill 464 237 495 464 240 495 minecraft:blackstone
setblock 464 237 499 minecraft:polished_blackstone_bricks
fill 464 237 500 464 240 500 minecraft:blackstone
setblock 464 237 504 minecraft:polished_blackstone_bricks
fill 424 238 471 424 238 472 minecraft:blackstone
setblock 424 238 473 minecraft:polished_blackstone_bricks
fill 424 238 474 424 238 477 minecraft:blackstone
setblock 424 238 478 minecraft:polished_blackstone_bricks
fill 424 238 479 424 238 482 minecraft:blackstone
setblock 424 238 483 minecraft:polished_blackstone_bricks
fill 424 238 484 424 238 487 minecraft:blackstone
setblock 424 238 488 minecraft:polished_blackstone_bricks
fill 424 238 489 424 238 492 minecraft:blackstone
setblock 424 238 493 minecraft:polished_blackstone_bricks
fill 424 238 494 424 238 497 minecraft:blackstone
setblock 424 238 498 minecraft:polished_blackstone_bricks
fill 424 238 499 424 241 499 minecraft:blackstone
setblock 424 238 502 minecraft:blackstone
setblock 424 238 503 minecraft:polished_blackstone_bricks
fill 425 238 474 425 238 476 minecraft:blackstone
setblock 425 238 477 minecraft:polished_blackstone_bricks
fill 425 238 478 425 241 478 minecraft:blackstone
fill 425 238 480 425 238 481 minecraft:blackstone
setblock 425 238 482 minecraft:polished_blackstone_bricks
setblock 425 238 483 minecraft:blackstone
fill 425 238 494 425 238 496 minecraft:blackstone
setblock 425 238 497 minecraft:polished_blackstone_bricks
setblock 425 238 498 minecraft:blackstone
setblock 426 238 466 minecraft:light[level=11]
setblock 426 238 474 minecraft:light[level=11]
setblock 426 238 482 minecraft:light[level=11]
setblock 426 238 490 minecraft:light[level=11]
setblock 426 238 498 minecraft:light[level=11]
fill 427 238 482 429 242 482 minecraft:polished_blackstone_bricks
setblock 433 238 464 minecraft:polished_blackstone_bricks
fill 434 238 464 437 238 464 minecraft:blackstone
setblock 434 238 466 minecraft:light[level=11]
setblock 434 238 474 minecraft:light[level=11]
setblock 434 238 482 minecraft:light[level=11]
setblock 434 238 490 minecraft:light[level=11]
setblock 434 238 498 minecraft:light[level=11]
fill 434 238 504 437 238 504 minecraft:blackstone
setblock 436 238 465 minecraft:blackstone
fill 436 238 503 438 238 503 minecraft:blackstone
setblock 437 238 465 minecraft:polished_blackstone_bricks
setblock 438 238 464 minecraft:polished_blackstone_bricks
fill 438 238 465 441 238 465 minecraft:blackstone
setblock 438 238 504 minecraft:polished_blackstone_bricks
fill 439 238 464 442 238 464 minecraft:blackstone
setblock 439 238 503 minecraft:polished_blackstone_bricks
fill 439 238 504 442 238 504 minecraft:blackstone
fill 440 238 503 440 241 503 minecraft:blackstone
fill 441 238 480 442 273 481 minecraft:polished_blackstone_bricks
setblock 442 238 465 minecraft:polished_blackstone_bricks
setblock 442 238 466 minecraft:light[level=11]
setblock 442 238 474 minecraft:light[level=11]
setblock 442 238 482 minecraft:light[level=11]
setblock 442 238 490 minecraft:light[level=11]
setblock 442 238 498 minecraft:light[level=11]
setblock 443 238 464 minecraft:polished_blackstone_bricks
setblock 443 238 504 minecraft:polished_blackstone_bricks
fill 444 238 464 444 241 464 minecraft:blackstone
fill 444 238 504 447 238 504 minecraft:blackstone
setblock 447 238 464 minecraft:blackstone
setblock 448 238 464 minecraft:polished_blackstone_bricks
setblock 448 238 504 minecraft:polished_blackstone_bricks
fill 449 238 464 452 238 464 minecraft:blackstone
fill 449 238 504 452 238 504 minecraft:blackstone
setblock 450 238 466 minecraft:light[level=11]
setblock 450 238 474 minecraft:light[level=11]
setblock 450 238 482 minecraft:light[level=11]
setblock 450 238 490 minecraft:light[level=11]
setblock 450 238 498 minecraft:light[level=11]
fill 450 238 503 453 238 503 minecraft:blackstone
fill 452 238 502 454 238 502 minecraft:blackstone
setblock 453 238 464 minecraft:polished_blackstone_bricks
setblock 453 238 504 minecraft:polished_blackstone_bricks
fill 454 238 464 457 238 464 minecraft:blackstone
fill 454 238 501 455 238 501 minecraft:blackstone
setblock 454 238 503 minecraft:polished_blackstone_bricks
fill 454 238 504 457 238 504 minecraft:blackstone
setblock 455 238 502 minecraft:polished_blackstone_bricks
fill 455 238 503 458 238 503 minecraft:blackstone
setblock 456 238 501 minecraft:polished_blackstone_bricks
fill 456 238 502 459 238 502 minecraft:blackstone
setblock 457 238 500 minecraft:polished_blackstone_bricks
fill 457 238 501 460 238 501 minecraft:blackstone
setblock 458 238 464 minecraft:polished_blackstone_bricks
setblock 458 238 466 minecraft:light[level=11]
setblock 458 238 474 minecraft:light[level=11]
setblock 458 238 482 minecraft:light[level=11]
setblock 458 238 490 minecraft:light[level=11]
setblock 458 238 498 minecraft:light[level=11]
fill 458 238 500 459 238 500 minecraft:blackstone
setblock 458 238 504 minecraft:polished_blackstone_bricks
fill 459 238 464 459 241 464 minecraft:blackstone
setblock 459 238 503 minecraft:polished_blackstone_bricks
fill 459 238 504 459 241 504 minecraft:blackstone
setblock 460 238 497 minecraft:polished_blackstone_bricks
setblock 460 238 498 minecraft:blackstone
setblock 460 238 502 minecraft:polished_blackstone_bricks
fill 460 238 503 460 241 503 minecraft:blackstone
fill 461 238 464 461 239 464 minecraft:blackstone
fill 461 238 494 461 238 495 minecraft:blackstone
setblock 461 238 496 minecraft:polished_blackstone_bricks
fill 461 238 497 461 239 497 minecraft:blackstone
setblock 461 238 501 minecraft:polished_blackstone_bricks
fill 461 238 502 461 241 502 minecraft:blackstone
setblock 462 238 494 minecraft:blackstone
setblock 462 238 495 minecraft:polished_blackstone_bricks
fill 462 238 496 462 240 496 minecraft:blackstone
setblock 462 238 499 minecraft:blackstone
setblock 462 238 500 minecraft:polished_blackstone_bricks
fill 462 238 501 462 241 501 minecraft:blackstone
setblock 462 238 504 minecraft:blackstone
setblock 463 238 475 minecraft:blackstone
setblock 463 238 478 minecraft:blackstone
setblock 463 238 479 minecraft:polished_blackstone_bricks
fill 463 238 480 463 239 480 minecraft:blackstone
setblock 463 238 490 minecraft:blackstone
setblock 463 238 493 minecraft:blackstone
setblock 463 238 494 minecraft:polished_blackstone_bricks
fill 463 238 495 463 240 495 minecraft:blackstone
setblock 463 238 498 minecraft:blackstone
setblock 463 238 499 minecraft:polished_blackstone_bricks
fill 463 238 500 463 241 500 minecraft:blackstone
setblock 463 238 503 minecraft:blackstone
setblock 463 238 504 minecraft:polished_blackstone_bricks
setblock 464 238 473 minecraft:polished_blackstone_bricks
fill 464 238 474 464 239 474 minecraft:blackstone
setblock 464 238 478 minecraft:polished_blackstone_bricks
fill 464 238 479 464 241 479 minecraft:blackstone
setblock 464 238 482 minecraft:blackstone
setblock 464 238 483 minecraft:polished_blackstone_bricks
fill 464 238 484 464 238 487 minecraft:blackstone
setblock 464 238 488 minecraft:polished_blackstone_bricks
fill 464 238 489 464 239 489 minecraft:blackstone
setblock 464 238 493 minecraft:polished_blackstone_bricks
fill 464 238 494 464 241 494 minecraft:blackstone
setblock 464 238 498 minecraft:polished_blackstone_bricks
fill 464 238 499 464 241 499 minecraft:blackstone
setblock 464 238 503 minecraft:polished_blackstone_bricks
fill 464 238 504 464 241 504 minecraft:blackstone
setblock 424 239 472 minecraft:polished_blackstone_bricks
fill 424 239 473 424 239 476 minecraft:blackstone
setblock 424 239 477 minecraft:polished_blackstone_bricks
fill 424 239 478 424 239 481 minecraft:blackstone
setblock 424 239 482 minecraft:polished_blackstone_bricks
fill 424 239 483 424 239 486 minecraft:blackstone
setblock 424 239 487 minecraft:polished_blackstone_bricks
fill 424 239 488 424 239 491 minecraft:blackstone
setblock 424 239 492 minecraft:polished_blackstone_bricks
fill 424 239 493 424 239 496 minecraft:blackstone
setblock 424 239 497 minecraft:polished_blackstone_bricks
fill 424 239 498 424 241 498 minecraft:blackstone
setblock 424 239 502 minecraft:polished_blackstone_bricks
setblock 425 239 475 minecraft:blackstone
setblock 425 239 476 minecraft:polished_blackstone_bricks
fill 425 239 477 425 241 477 minecraft:blackstone
setblock 425 239 480 minecraft:blackstone
setblock 425 239 481 minecraft:polished_blackstone_bricks
fill 425 239 482 425 242 482 minecraft:blackstone
fill 433 239 464 436 239 464 minecraft:blackstone
fill 433 239 504 436 239 504 minecraft:blackstone
setblock 435 239 465 minecraft:blackstone
fill 435 239 503 437 239 503 minecraft:blackstone
setblock 436 239 465 minecraft:polished_blackstone_bricks
setblock 437 239 464 minecraft:polished_blackstone_bricks
fill 437 239 465 440 239 465 minecraft:blackstone
setblock 437 239 504 minecraft:polished_blackstone_bricks
fill 438 239 464 441 239 464 minecraft:blackstone
setblock 438 239 503 minecraft:polished_blackstone_bricks
fill 438 239 504 441 239 504 minecraft:blackstone
fill 439 239 503 439 242 503 minecraft:blackstone
fill 440 239 480 440 240 481 minecraft:blackstone
setblock 441 239 465 minecraft:polished_blackstone_bricks
fill 441 239 479 442 240 479 minecraft:blackstone
fill 441 239 482 442 240 482 minecraft:blackstone
setblock 442 239 464 minecraft:polished_blackstone_bricks
setblock 442 239 465 minecraft:blackstone
setblock 442 239 503 minecraft:blackstone
setblock 442 239 504 minecraft:polished_blackstone_bricks
fill 443 239 464 443 242 464 minecraft:blackstone
fill 443 239 480 443 240 481 minecraft:blackstone
setblock 443 239 503 minecraft:polished_blackstone_bricks
fill 443 239 504 446 239 504 minecraft:blackstone
setblock 447 239 504 minecraft:polished_blackstone_bricks
fill 448 239 504 451 239 504 minecraft:blackstone
fill 449 239 464 451 239 464 minecraft:blackstone
fill 449 239 503 452 239 503 minecraft:blackstone
setblock 452 239 464 minecraft:polished_blackstone_bricks
fill 452 239 502 453 239 502 minecraft:blackstone
setblock 452 239 504 minecraft:polished_blackstone_bricks
fill 453 239 464 456 239 464 minecraft:blackstone
setblock 453 239 503 minecraft:polished_blackstone_bricks
fill 453 239 504 456 239 504 minecraft:blackstone
setblock 454 239 501 minecraft:blackstone
setblock 454 239 502 minecraft:polished_blackstone_bricks
fill 454 239 503 457 239 503 minecraft:blackstone
setblock 455 239 501 minecraft:polished_blackstone_bricks
fill 455 239 502 458 239 502 minecraft:blackstone
fill 456 239 501 459 239 501 minecraft:blackstone
setblock 457 239 464 minecraft:polished_blackstone_bricks
fill 457 239 500 458 239 500 minecraft:blackstone
setblock 457 239 504 minecraft:polished_blackstone_bricks
fill 458 239 464 458 242 464 minecraft:blackstone
setblock 458 239 503 minecraft:polished_blackstone_bricks
fill 458 239 504 458 242 504 minecraft:blackstone
setblock 459 239 502 minecraft:polished_blackstone_bricks
fill 459 239 503 459 242 503 minecraft:blackstone
setblock 460 239 501 minecraft:polished_blackstone_bricks
fill 460 239 502 460 242 502 minecraft:blackstone
setblock 461 239 496 minecraft:blackstone
setblock 461 239 499 minecraft:blackstone
setblock 461 239 500 minecraft:polished_blackstone_bricks
setblock 461 239 501 minecraft:blackstone
setblock 462 239 494 minecraft:polished_blackstone_bricks
setblock 462 239 495 minecraft:blackstone
setblock 462 239 499 minecraft:polished_blackstone_bricks
fill 462 239 500 462 241 500 minecraft:blackstone
setblock 462 239 504 minecraft:polished_blackstone_bricks
setblock 463 239 478 minecraft:polished_blackstone_bricks
setblock 463 239 479 minecraft:blackstone
setblock 463 239 493 minecraft:polished_blackstone_bricks
fill 463 239 494 463 240 494 minecraft:blackstone
setblock 463 239 498 minecraft:polished_blackstone_bricks
fill 463 239 499 463 242 499 minecraft:blackstone
setblock 463 239 503 minecraft:polished_blackstone_bricks
fill 463 239 504 463 242 504 minecraft:blackstone
setblock 464 239 477 minecraft:polished_blackstone_bricks
fill 464 239 478 464 242 478 minecraft:blackstone
setblock 464 239 482 minecraft:polished_blackstone_bricks
fill 464 239 483 464 239 486 minecraft:blackstone
setblock 464 239 487 minecraft:polished_blackstone_bricks
setblock 464 239 488 minecraft:blackstone
setblock 464 239 492 minecraft:polished_blackstone_bricks
fill 464 239 493 464 241 493 minecraft:blackstone
setblock 464 239 497 minecraft:polished_blackstone_bricks
fill 464 239 498 464 242 498 minecraft:blackstone
setblock 464 239 502 minecraft:polished_blackstone_bricks
fill 464 239 503 464 242 503 minecraft:blackstone
fill 424 240 473 424 240 475 minecraft:blackstone
setblock 424 240 476 minecraft:polished_blackstone_bricks
fill 424 240 477 424 240 480 minecraft:blackstone
setblock 424 240 481 minecraft:polished_blackstone_bricks
fill 424 240 482 424 240 485 minecraft:blackstone
setblock 424 240 486 minecraft:polished_blackstone_bricks
fill 424 240 489 430 240 489 minecraft:blackstone
fill 424 240 494 424 240 495 minecraft:blackstone
setblock 424 240 496 minecraft:polished_blackstone_bricks
setblock 424 240 497 minecraft:blackstone
setblock 424 240 501 minecraft:polished_blackstone_bricks
setblock 424 240 502 minecraft:blackstone
setblock 425 240 476 minecraft:blackstone
setblock 425 240 480 minecraft:polished_blackstone_bricks
fill 425 240 481 425 243 481 minecraft:blackstone
fill 426 240 487 430 241 488 minecraft:blackstone
fill 426 240 490 430 241 491 minecraft:blackstone
fill 432 240 504 435 240 504 minecraft:blackstone
fill 433 240 464 435 240 464 minecraft:blackstone
fill 434 240 503 436 240 503 minecraft:blackstone
setblock 435 240 465 minecraft:polished_blackstone_bricks
setblock 436 240 464 minecraft:polished_blackstone_bricks
fill 436 240 465 439 240 465 minecraft:blackstone
setblock 436 240 504 minecraft:polished_blackstone_bricks
fill 437 240 464 440 240 464 minecraft:blackstone
setblock 437 240 503 minecraft:polished_blackstone_bricks
fill 437 240 504 440 240 504 minecraft:blackstone
fill 438 240 503 438 243 503 minecraft:blackstone
setblock 440 240 465 minecraft:polished_blackstone_bricks
setblock 440 240 479 minecraft:blackstone
setblock 440 240 482 minecraft:blackstone
setblock 441 240 464 minecraft:polished_blackstone_bricks
setblock 441 240 465 minecraft:blackstone
schedule function dropper:buildpart/117_8 1t
