fill 182 46 278 182 49 278 minecraft:packed_ice
setblock 182 46 282 minecraft:snow_block
fill 182 46 283 182 49 283 minecraft:packed_ice
setblock 182 46 287 minecraft:snow_block
fill 182 46 288 182 49 288 minecraft:packed_ice
setblock 182 46 292 minecraft:snow_block
fill 182 46 293 182 49 293 minecraft:packed_ice
setblock 182 46 297 minecraft:snow_block
setblock 182 46 306 minecraft:packed_ice
setblock 182 46 307 minecraft:snow_block
fill 182 46 308 182 46 311 minecraft:packed_ice
setblock 182 46 312 minecraft:snow_block
fill 182 46 313 182 49 313 minecraft:packed_ice
fill 183 46 281 183 89 281 minecraft:packed_ice
fill 183 46 307 183 55 307 minecraft:packed_ice
setblock 183 46 315 minecraft:light_blue_concrete
setblock 142 47 276 minecraft:snow_block
fill 142 47 277 142 50 277 minecraft:packed_ice
setblock 142 47 286 minecraft:snow_block
fill 142 47 287 142 48 287 minecraft:packed_ice
setblock 142 47 291 minecraft:snow_block
fill 142 47 292 142 50 292 minecraft:packed_ice
setblock 142 47 295 minecraft:packed_ice
setblock 142 47 296 minecraft:snow_block
fill 142 47 297 142 47 300 minecraft:packed_ice
setblock 142 47 301 minecraft:snow_block
fill 142 47 302 143 49 302 minecraft:packed_ice
setblock 142 47 306 minecraft:snow_block
fill 142 47 307 142 50 307 minecraft:packed_ice
setblock 142 47 311 minecraft:snow_block
fill 142 47 312 142 49 313 minecraft:packed_ice
setblock 142 47 315 minecraft:packed_ice
setblock 142 47 316 minecraft:snow_block
fill 143 47 276 143 50 276 minecraft:packed_ice
setblock 143 47 290 minecraft:snow_block
fill 143 47 291 143 50 291 minecraft:packed_ice
setblock 143 47 295 minecraft:snow_block
fill 143 47 296 144 49 296 minecraft:packed_ice
setblock 143 47 300 minecraft:snow_block
fill 143 47 301 143 50 301 minecraft:packed_ice
setblock 143 47 305 minecraft:snow_block
fill 143 47 306 143 50 306 minecraft:packed_ice
setblock 143 47 310 minecraft:snow_block
fill 143 47 311 143 50 311 minecraft:packed_ice
fill 143 47 313 144 47 313 minecraft:packed_ice
setblock 143 47 315 minecraft:snow_block
fill 143 47 316 143 50 316 minecraft:packed_ice
setblock 144 47 294 minecraft:snow_block
fill 144 47 295 144 50 295 minecraft:packed_ice
setblock 144 47 309 minecraft:snow_block
fill 144 47 310 144 50 310 minecraft:packed_ice
setblock 144 47 314 minecraft:snow_block
fill 144 47 315 144 50 315 minecraft:packed_ice
setblock 145 47 309 minecraft:packed_ice
setblock 145 47 313 minecraft:snow_block
fill 145 47 314 145 50 314 minecraft:packed_ice
fill 146 47 311 146 105 312 minecraft:snow_block
fill 146 47 313 146 48 313 minecraft:packed_ice
setblock 147 47 276 minecraft:snow_block
setblock 147 47 316 minecraft:snow_block
fill 148 47 276 148 50 276 minecraft:packed_ice
setblock 148 47 315 minecraft:snow_block
fill 148 47 316 148 50 316 minecraft:packed_ice
setblock 149 47 314 minecraft:snow_block
fill 149 47 315 149 50 315 minecraft:packed_ice
setblock 150 47 314 minecraft:packed_ice
fill 152 47 302 152 52 302 minecraft:packed_ice
setblock 152 47 316 minecraft:snow_block
fill 153 47 303 153 52 303 minecraft:packed_ice
fill 153 47 316 153 48 316 minecraft:packed_ice
setblock 155 47 316 minecraft:packed_ice
fill 158 47 316 161 47 316 minecraft:packed_ice
setblock 161 47 276 minecraft:packed_ice
fill 161 47 315 162 47 315 minecraft:packed_ice
setblock 162 47 276 minecraft:snow_block
setblock 162 47 316 minecraft:snow_block
fill 163 47 276 163 49 277 minecraft:packed_ice
setblock 163 47 315 minecraft:snow_block
fill 163 47 316 166 47 316 minecraft:packed_ice
fill 164 47 315 164 50 315 minecraft:packed_ice
setblock 166 47 276 minecraft:packed_ice
setblock 166 47 277 minecraft:snow_block
setblock 167 47 276 minecraft:snow_block
fill 167 47 277 167 50 277 minecraft:packed_ice
setblock 167 47 316 minecraft:snow_block
fill 168 47 276 168 50 276 minecraft:packed_ice
setblock 168 47 315 minecraft:snow_block
fill 168 47 316 168 50 316 minecraft:packed_ice
fill 169 47 315 169 48 315 minecraft:packed_ice
setblock 171 47 277 minecraft:snow_block
setblock 172 47 276 minecraft:snow_block
setblock 172 47 316 minecraft:snow_block
fill 173 47 276 176 47 276 minecraft:packed_ice
fill 173 47 316 176 47 316 minecraft:packed_ice
setblock 177 47 276 minecraft:snow_block
setblock 177 47 315 minecraft:packed_ice
setblock 177 47 316 minecraft:snow_block
fill 178 47 276 178 50 276 minecraft:packed_ice
setblock 178 47 315 minecraft:snow_block
fill 178 47 316 178 50 316 minecraft:packed_ice
fill 179 47 277 179 48 277 minecraft:packed_ice
fill 179 47 315 179 50 315 minecraft:packed_ice
setblock 180 47 313 minecraft:snow_block
fill 180 47 314 180 50 314 minecraft:packed_ice
setblock 181 47 277 minecraft:snow_block
fill 181 47 278 181 50 278 minecraft:packed_ice
setblock 181 47 291 minecraft:packed_ice
setblock 181 47 292 minecraft:snow_block
fill 181 47 293 181 48 293 minecraft:packed_ice
fill 181 47 309 181 47 311 minecraft:packed_ice
setblock 181 47 312 minecraft:snow_block
fill 181 47 313 181 50 313 minecraft:packed_ice
setblock 182 47 276 minecraft:snow_block
fill 182 47 277 182 50 277 minecraft:packed_ice
setblock 182 47 281 minecraft:snow_block
fill 182 47 282 182 50 282 minecraft:packed_ice
setblock 182 47 286 minecraft:snow_block
fill 182 47 287 182 49 287 minecraft:packed_ice
setblock 182 47 291 minecraft:snow_block
fill 182 47 292 182 50 292 minecraft:packed_ice
setblock 182 47 296 minecraft:snow_block
fill 182 47 297 182 49 298 minecraft:packed_ice
setblock 182 47 306 minecraft:snow_block
fill 182 47 307 182 47 310 minecraft:packed_ice
setblock 182 47 311 minecraft:snow_block
fill 182 47 312 182 50 312 minecraft:packed_ice
setblock 182 47 316 minecraft:snow_block
fill 183 47 286 183 73 286 minecraft:packed_ice
fill 183 47 315 183 94 315 minecraft:packed_ice
setblock 141 48 299 minecraft:light_blue_concrete
fill 141 48 301 142 51 301 minecraft:packed_ice
setblock 141 48 302 minecraft:white_concrete
fill 141 48 303 141 55 317 minecraft:packed_ice
fill 142 48 276 142 51 276 minecraft:packed_ice
setblock 142 48 290 minecraft:snow_block
fill 142 48 291 142 51 291 minecraft:packed_ice
setblock 142 48 295 minecraft:snow_block
fill 142 48 296 142 48 299 minecraft:packed_ice
setblock 142 48 300 minecraft:snow_block
setblock 142 48 305 minecraft:snow_block
fill 142 48 306 142 51 306 minecraft:packed_ice
setblock 142 48 310 minecraft:snow_block
fill 142 48 311 142 51 311 minecraft:packed_ice
setblock 142 48 315 minecraft:snow_block
fill 142 48 316 142 51 316 minecraft:packed_ice
fill 143 48 277 144 48 277 minecraft:packed_ice
setblock 143 48 290 minecraft:packed_ice
setblock 143 48 293 minecraft:packed_ice
setblock 143 48 294 minecraft:snow_block
fill 143 48 295 143 51 295 minecraft:packed_ice
fill 143 48 297 143 48 298 minecraft:packed_ice
setblock 143 48 299 minecraft:snow_block
fill 143 48 300 143 51 300 minecraft:packed_ice
setblock 143 48 304 minecraft:snow_block
fill 143 48 305 143 51 305 minecraft:packed_ice
setblock 143 48 309 minecraft:snow_block
fill 143 48 310 143 51 310 minecraft:packed_ice
setblock 143 48 313 minecraft:packed_ice
setblock 143 48 314 minecraft:snow_block
fill 143 48 315 143 51 315 minecraft:packed_ice
setblock 144 48 278 minecraft:light[level=15]
setblock 144 48 285 minecraft:light[level=12]
setblock 144 48 286 minecraft:light[level=15]
setblock 144 48 292 minecraft:light[level=12]
setblock 144 48 293 minecraft:snow_block
fill 144 48 294 144 50 294 minecraft:packed_ice
setblock 144 48 297 minecraft:packed_ice
setblock 144 48 299 minecraft:light[level=12]
setblock 144 48 302 minecraft:light[level=15]
setblock 144 48 306 minecraft:light[level=12]
setblock 144 48 308 minecraft:snow_block
fill 144 48 309 144 49 309 minecraft:packed_ice
setblock 144 48 313 minecraft:snow_block
fill 144 48 314 144 51 314 minecraft:packed_ice
fill 145 48 312 145 105 312 minecraft:snow_block
fill 145 48 313 145 49 313 minecraft:packed_ice
setblock 146 48 276 minecraft:snow_block
setblock 146 48 316 minecraft:snow_block
fill 147 48 276 147 51 276 minecraft:packed_ice
setblock 147 48 315 minecraft:snow_block
fill 147 48 316 147 51 316 minecraft:packed_ice
setblock 148 48 314 minecraft:snow_block
fill 148 48 315 148 51 315 minecraft:packed_ice
setblock 149 48 314 minecraft:packed_ice
setblock 151 48 278 minecraft:light[level=12]
setblock 151 48 285 minecraft:light[level=12]
setblock 151 48 292 minecraft:light[level=12]
setblock 151 48 299 minecraft:light[level=12]
setblock 151 48 306 minecraft:light[level=12]
setblock 151 48 313 minecraft:light[level=12]
setblock 151 48 316 minecraft:snow_block
setblock 152 48 278 minecraft:light[level=15]
setblock 152 48 286 minecraft:light[level=15]
setblock 152 48 294 minecraft:light[level=15]
fill 152 48 301 153 52 301 minecraft:packed_ice
fill 152 48 303 152 52 303 minecraft:packed_ice
setblock 152 48 310 minecraft:light[level=15]
fill 152 48 316 152 49 316 minecraft:packed_ice
fill 154 48 302 154 52 303 minecraft:packed_ice
setblock 158 48 278 minecraft:light[level=12]
setblock 158 48 285 minecraft:light[level=12]
setblock 158 48 292 minecraft:light[level=12]
setblock 158 48 299 minecraft:light[level=12]
setblock 158 48 306 minecraft:light[level=12]
setblock 158 48 313 minecraft:light[level=12]
fill 158 48 316 160 48 316 minecraft:packed_ice
setblock 160 48 276 minecraft:packed_ice
setblock 160 48 278 minecraft:light[level=15]
setblock 160 48 286 minecraft:light[level=15]
setblock 160 48 294 minecraft:light[level=15]
setblock 160 48 302 minecraft:light[level=15]
setblock 160 48 310 minecraft:light[level=15]
setblock 161 48 276 minecraft:snow_block
setblock 161 48 315 minecraft:packed_ice
setblock 161 48 316 minecraft:snow_block
fill 162 48 276 162 51 276 minecraft:packed_ice
setblock 162 48 315 minecraft:snow_block
fill 162 48 316 165 48 316 minecraft:packed_ice
fill 163 48 315 163 51 315 minecraft:packed_ice
setblock 165 48 276 minecraft:packed_ice
setblock 165 48 277 minecraft:snow_block
setblock 165 48 278 minecraft:light[level=12]
setblock 165 48 285 minecraft:light[level=12]
setblock 165 48 292 minecraft:light[level=12]
setblock 165 48 299 minecraft:light[level=12]
setblock 165 48 306 minecraft:light[level=12]
setblock 165 48 313 minecraft:light[level=12]
setblock 166 48 276 minecraft:snow_block
fill 166 48 277 166 51 277 minecraft:packed_ice
setblock 166 48 316 minecraft:snow_block
fill 167 48 276 167 51 276 minecraft:packed_ice
setblock 167 48 315 minecraft:snow_block
fill 167 48 316 167 51 316 minecraft:packed_ice
setblock 168 48 278 minecraft:light[level=15]
setblock 168 48 286 minecraft:light[level=15]
setblock 168 48 294 minecraft:light[level=15]
setblock 168 48 302 minecraft:light[level=15]
setblock 168 48 310 minecraft:light[level=15]
fill 168 48 315 168 49 315 minecraft:packed_ice
setblock 170 48 277 minecraft:snow_block
setblock 171 48 276 minecraft:snow_block
setblock 171 48 316 minecraft:snow_block
fill 172 48 276 175 48 276 minecraft:packed_ice
setblock 172 48 278 minecraft:light[level=12]
setblock 172 48 285 minecraft:light[level=12]
setblock 172 48 292 minecraft:light[level=12]
setblock 172 48 299 minecraft:light[level=12]
setblock 172 48 306 minecraft:light[level=12]
setblock 172 48 313 minecraft:light[level=12]
fill 172 48 316 175 48 316 minecraft:packed_ice
setblock 176 48 276 minecraft:snow_block
setblock 176 48 278 minecraft:light[level=15]
setblock 176 48 286 minecraft:light[level=15]
setblock 176 48 294 minecraft:light[level=15]
setblock 176 48 302 minecraft:light[level=15]
setblock 176 48 310 minecraft:light[level=15]
setblock 176 48 316 minecraft:snow_block
fill 177 48 276 177 51 276 minecraft:packed_ice
setblock 177 48 315 minecraft:snow_block
fill 177 48 316 177 51 316 minecraft:packed_ice
fill 178 48 315 178 51 315 minecraft:packed_ice
setblock 179 48 278 minecraft:light[level=12]
setblock 179 48 285 minecraft:light[level=12]
setblock 179 48 292 minecraft:light[level=12]
setblock 179 48 299 minecraft:light[level=12]
setblock 179 48 306 minecraft:light[level=12]
setblock 179 48 313 minecraft:light[level=12]
setblock 180 48 277 minecraft:snow_block
setblock 181 48 276 minecraft:snow_block
fill 181 48 277 181 51 277 minecraft:packed_ice
setblock 181 48 291 minecraft:snow_block
setblock 181 48 292 minecraft:packed_ice
setblock 181 48 310 minecraft:packed_ice
setblock 181 48 311 minecraft:snow_block
fill 181 48 312 181 51 312 minecraft:packed_ice
setblock 181 48 316 minecraft:snow_block
fill 182 48 276 182 51 276 minecraft:packed_ice
setblock 182 48 280 minecraft:snow_block
fill 182 48 281 182 51 281 minecraft:packed_ice
setblock 182 48 285 minecraft:snow_block
fill 182 48 286 182 49 286 minecraft:packed_ice
setblock 182 48 290 minecraft:snow_block
fill 182 48 291 182 51 291 minecraft:packed_ice
setblock 182 48 295 minecraft:snow_block
fill 182 48 296 182 51 296 minecraft:packed_ice
setblock 182 48 299 minecraft:packed_ice
fill 182 48 306 182 48 309 minecraft:packed_ice
setblock 182 48 310 minecraft:snow_block
fill 182 48 311 182 51 311 minecraft:packed_ice
setblock 182 48 315 minecraft:snow_block
fill 182 48 316 182 51 316 minecraft:packed_ice
fill 183 48 285 183 89 285 minecraft:packed_ice
fill 141 49 299 141 91 299 minecraft:packed_ice
fill 141 49 302 141 93 302 minecraft:packed_ice
setblock 142 49 279 minecraft:snow_block
setblock 142 49 289 minecraft:snow_block
fill 142 49 290 142 52 290 minecraft:packed_ice
setblock 142 49 294 minecraft:snow_block
fill 142 49 295 142 49 298 minecraft:packed_ice
setblock 142 49 299 minecraft:snow_block
fill 142 49 300 142 52 300 minecraft:packed_ice
setblock 142 49 304 minecraft:snow_block
fill 142 49 305 142 52 305 minecraft:packed_ice
setblock 142 49 309 minecraft:snow_block
fill 142 49 310 142 52 310 minecraft:packed_ice
setblock 142 49 314 minecraft:snow_block
fill 142 49 315 142 52 315 minecraft:packed_ice
setblock 143 49 277 minecraft:packed_ice
setblock 143 49 293 minecraft:snow_block
fill 143 49 294 143 52 294 minecraft:packed_ice
setblock 143 49 297 minecraft:packed_ice
setblock 143 49 298 minecraft:snow_block
fill 143 49 299 143 52 299 minecraft:packed_ice
setblock 143 49 303 minecraft:snow_block
fill 143 49 304 143 52 304 minecraft:packed_ice
setblock 143 49 308 minecraft:snow_block
fill 143 49 309 143 52 309 minecraft:packed_ice
setblock 143 49 313 minecraft:snow_block
fill 143 49 314 143 52 314 minecraft:packed_ice
setblock 144 49 277 minecraft:snow_block
setblock 144 49 293 minecraft:packed_ice
setblock 144 49 297 minecraft:snow_block
setblock 144 49 312 minecraft:snow_block
fill 144 49 313 144 52 313 minecraft:packed_ice
setblock 145 49 276 minecraft:snow_block
setblock 145 49 316 minecraft:snow_block
fill 146 49 276 146 52 276 minecraft:packed_ice
fill 146 49 313 146 105 313 minecraft:snow_block
setblock 146 49 315 minecraft:snow_block
fill 146 49 316 146 52 316 minecraft:packed_ice
setblock 147 49 314 minecraft:snow_block
fill 147 49 315 147 52 315 minecraft:packed_ice
setblock 148 49 314 minecraft:packed_ice
setblock 150 49 316 minecraft:snow_block
fill 151 49 302 151 52 303 minecraft:packed_ice
fill 151 49 316 151 50 316 minecraft:packed_ice
fill 153 49 304 153 52 304 minecraft:packed_ice
fill 154 49 301 154 52 301 minecraft:packed_ice
fill 157 49 300 159 53 302 minecraft:snow_block
fill 158 49 316 159 49 316 minecraft:packed_ice
setblock 160 49 276 minecraft:snow_block
setblock 160 49 316 minecraft:snow_block
fill 161 49 276 161 52 276 minecraft:packed_ice
fill 161 49 316 164 49 316 minecraft:packed_ice
fill 162 49 277 162 50 277 minecraft:packed_ice
fill 162 49 315 162 50 315 minecraft:packed_ice
setblock 164 49 276 minecraft:packed_ice
setblock 164 49 277 minecraft:snow_block
setblock 165 49 276 minecraft:snow_block
fill 165 49 277 165 52 277 minecraft:packed_ice
setblock 165 49 316 minecraft:snow_block
fill 166 49 276 166 52 276 minecraft:packed_ice
setblock 166 49 315 minecraft:snow_block
fill 166 49 316 166 52 316 minecraft:packed_ice
setblock 167 49 315 minecraft:packed_ice
setblock 169 49 277 minecraft:snow_block
setblock 170 49 276 minecraft:snow_block
fill 170 49 277 170 52 277 minecraft:packed_ice
setblock 170 49 316 minecraft:snow_block
fill 171 49 276 174 49 276 minecraft:packed_ice
fill 171 49 316 174 49 316 minecraft:packed_ice
setblock 175 49 276 minecraft:snow_block
setblock 175 49 316 minecraft:snow_block
fill 176 49 276 176 52 276 minecraft:packed_ice
fill 176 49 316 176 52 316 minecraft:packed_ice
fill 177 49 315 177 52 315 minecraft:packed_ice
setblock 178 49 277 minecraft:packed_ice
setblock 179 49 277 minecraft:snow_block
setblock 180 49 276 minecraft:snow_block
fill 180 49 277 180 52 277 minecraft:packed_ice
setblock 180 49 316 minecraft:snow_block
fill 181 49 276 181 52 276 minecraft:packed_ice
setblock 181 49 279 minecraft:packed_ice
setblock 181 49 310 minecraft:snow_block
fill 181 49 311 181 52 311 minecraft:packed_ice
setblock 181 49 315 minecraft:snow_block
fill 181 49 316 181 52 316 minecraft:packed_ice
setblock 182 49 279 minecraft:snow_block
fill 182 49 280 182 52 280 minecraft:packed_ice
setblock 182 49 289 minecraft:snow_block
fill 182 49 290 182 51 290 minecraft:packed_ice
setblock 182 49 294 minecraft:snow_block
fill 182 49 295 182 52 295 minecraft:packed_ice
setblock 182 49 299 minecraft:snow_block
fill 182 49 307 182 49 308 minecraft:packed_ice
setblock 182 49 309 minecraft:snow_block
fill 182 49 310 182 52 310 minecraft:packed_ice
setblock 182 49 314 minecraft:snow_block
fill 182 49 315 182 52 315 minecraft:packed_ice
setblock 142 50 278 minecraft:snow_block
fill 142 50 279 142 53 279 minecraft:packed_ice
setblock 142 50 289 minecraft:packed_ice
setblock 142 50 293 minecraft:snow_block
fill 142 50 294 142 50 297 minecraft:packed_ice
setblock 142 50 298 minecraft:snow_block
fill 142 50 299 142 53 299 minecraft:packed_ice
setblock 142 50 302 minecraft:packed_ice
setblock 142 50 303 minecraft:snow_block
fill 142 50 304 142 53 304 minecraft:packed_ice
setblock 142 50 308 minecraft:snow_block
fill 142 50 309 142 53 309 minecraft:packed_ice
setblock 142 50 312 minecraft:packed_ice
setblock 142 50 313 minecraft:snow_block
fill 142 50 314 142 53 314 minecraft:packed_ice
setblock 143 50 277 minecraft:snow_block
setblock 143 50 292 minecraft:snow_block
fill 143 50 293 143 53 293 minecraft:packed_ice
setblock 143 50 296 minecraft:packed_ice
setblock 143 50 297 minecraft:snow_block
fill 143 50 298 144 52 298 minecraft:packed_ice
setblock 143 50 302 minecraft:snow_block
fill 143 50 303 143 53 303 minecraft:packed_ice
setblock 143 50 307 minecraft:snow_block
fill 143 50 308 143 53 308 minecraft:packed_ice
setblock 143 50 312 minecraft:snow_block
fill 143 50 313 143 53 313 minecraft:packed_ice
setblock 144 50 276 minecraft:snow_block
setblock 144 50 296 minecraft:snow_block
fill 144 50 297 144 53 297 minecraft:packed_ice
setblock 144 50 311 minecraft:snow_block
fill 144 50 312 144 51 312 minecraft:packed_ice
setblock 144 50 316 minecraft:snow_block
fill 145 50 276 145 53 276 minecraft:packed_ice
setblock 145 50 315 minecraft:snow_block
fill 145 50 316 145 53 316 minecraft:packed_ice
setblock 146 50 314 minecraft:snow_block
fill 146 50 315 146 53 315 minecraft:packed_ice
setblock 147 50 314 minecraft:packed_ice
setblock 149 50 316 minecraft:snow_block
fill 150 50 316 150 51 316 minecraft:packed_ice
fill 151 50 301 151 52 301 minecraft:packed_ice
fill 152 50 300 154 52 300 minecraft:packed_ice
fill 152 50 304 152 52 304 minecraft:packed_ice
fill 154 50 304 154 52 304 minecraft:packed_ice
fill 155 50 302 155 52 303 minecraft:packed_ice
fill 156 50 301 156 51 302 minecraft:packed_ice
fill 157 50 303 159 51 303 minecraft:packed_ice
setblock 159 50 276 minecraft:snow_block
setblock 159 50 316 minecraft:snow_block
fill 160 50 276 160 53 276 minecraft:packed_ice
fill 160 50 300 160 51 302 minecraft:packed_ice
fill 160 50 316 163 50 316 minecraft:packed_ice
setblock 163 50 276 minecraft:packed_ice
setblock 163 50 277 minecraft:snow_block
setblock 164 50 276 minecraft:snow_block
fill 164 50 277 164 53 277 minecraft:packed_ice
setblock 164 50 316 minecraft:snow_block
fill 165 50 276 165 53 276 minecraft:packed_ice
setblock 165 50 315 minecraft:snow_block
fill 165 50 316 165 53 316 minecraft:packed_ice
setblock 166 50 315 minecraft:packed_ice
setblock 168 50 277 minecraft:snow_block
setblock 169 50 276 minecraft:snow_block
fill 169 50 277 169 53 277 minecraft:packed_ice
setblock 169 50 316 minecraft:snow_block
fill 170 50 276 173 50 276 minecraft:packed_ice
fill 170 50 316 173 50 316 minecraft:packed_ice
setblock 174 50 276 minecraft:snow_block
setblock 174 50 316 minecraft:snow_block
fill 175 50 276 175 53 276 minecraft:packed_ice
fill 175 50 316 175 53 316 minecraft:packed_ice
setblock 178 50 277 minecraft:snow_block
setblock 179 50 276 minecraft:snow_block
fill 179 50 277 179 53 277 minecraft:packed_ice
setblock 179 50 316 minecraft:snow_block
fill 180 50 276 180 53 276 minecraft:packed_ice
setblock 180 50 315 minecraft:snow_block
fill 180 50 316 180 53 316 minecraft:packed_ice
setblock 181 50 279 minecraft:snow_block
setblock 181 50 314 minecraft:snow_block
fill 181 50 315 181 53 315 minecraft:packed_ice
setblock 182 50 278 minecraft:snow_block
fill 182 50 279 182 53 279 minecraft:packed_ice
setblock 182 50 289 minecraft:packed_ice
setblock 182 50 293 minecraft:snow_block
fill 182 50 294 182 53 294 minecraft:packed_ice
setblock 182 50 297 minecraft:packed_ice
setblock 182 50 298 minecraft:snow_block
fill 182 50 299 182 52 300 minecraft:packed_ice
setblock 182 50 307 minecraft:packed_ice
setblock 182 50 308 minecraft:snow_block
fill 182 50 309 182 53 309 minecraft:packed_ice
setblock 182 50 313 minecraft:snow_block
fill 182 50 314 182 53 314 minecraft:packed_ice
setblock 141 51 285 minecraft:white_concrete
fill 141 51 286 141 93 286 minecraft:packed_ice
setblock 142 51 277 minecraft:snow_block
fill 142 51 278 142 54 278 minecraft:packed_ice
setblock 142 51 292 minecraft:snow_block
fill 142 51 293 142 51 296 minecraft:packed_ice
setblock 142 51 297 minecraft:snow_block
fill 142 51 298 142 54 298 minecraft:packed_ice
setblock 142 51 302 minecraft:snow_block
fill 142 51 303 142 54 303 minecraft:packed_ice
setblock 142 51 307 minecraft:snow_block
fill 142 51 308 142 54 308 minecraft:packed_ice
setblock 142 51 312 minecraft:snow_block
fill 142 51 313 142 54 313 minecraft:packed_ice
setblock 143 51 276 minecraft:snow_block
fill 143 51 277 143 54 277 minecraft:packed_ice
fill 143 51 292 143 53 292 minecraft:packed_ice
setblock 143 51 296 minecraft:snow_block
fill 143 51 297 143 54 297 minecraft:packed_ice
setblock 143 51 301 minecraft:snow_block
fill 143 51 302 143 54 302 minecraft:packed_ice
setblock 143 51 306 minecraft:snow_block
fill 143 51 307 143 54 307 minecraft:packed_ice
setblock 143 51 311 minecraft:snow_block
fill 143 51 312 143 54 312 minecraft:packed_ice
setblock 143 51 316 minecraft:snow_block
fill 144 51 276 144 54 276 minecraft:packed_ice
setblock 144 51 295 minecraft:snow_block
fill 144 51 296 144 54 296 minecraft:packed_ice
setblock 144 51 299 minecraft:packed_ice
setblock 144 51 315 minecraft:snow_block
fill 144 51 316 144 54 316 minecraft:packed_ice
fill 145 51 313 145 53 313 minecraft:blue_ice
setblock 145 51 314 minecraft:snow_block
fill 145 51 315 145 54 315 minecraft:packed_ice
fill 146 51 283 146 52 283 minecraft:blue_ice
setblock 147 51 313 minecraft:blue_ice
setblock 148 51 316 minecraft:snow_block
fill 149 51 316 149 52 316 minecraft:packed_ice
fill 150 51 302 150 52 303 minecraft:packed_ice
fill 151 51 300 151 52 300 minecraft:packed_ice
fill 151 51 304 151 52 304 minecraft:packed_ice
fill 152 51 282 153 52 283 minecraft:white_concrete
fill 153 51 305 153 52 305 minecraft:packed_ice
setblock 153 51 317 minecraft:light_blue_concrete
fill 155 51 301 155 52 301 minecraft:packed_ice
fill 156 51 303 156 52 303 minecraft:packed_ice
setblock 158 51 276 minecraft:snow_block
setblock 158 51 304 minecraft:packed_ice
setblock 158 51 316 minecraft:snow_block
fill 159 51 276 159 54 276 minecraft:packed_ice
fill 159 51 299 160 51 299 minecraft:packed_ice
fill 159 51 316 162 51 316 minecraft:packed_ice
setblock 160 51 303 minecraft:packed_ice
setblock 161 51 277 minecraft:packed_ice
setblock 161 51 301 minecraft:packed_ice
setblock 162 51 277 minecraft:snow_block
setblock 163 51 276 minecraft:snow_block
fill 163 51 277 163 54 277 minecraft:packed_ice
setblock 163 51 316 minecraft:snow_block
fill 164 51 276 164 54 276 minecraft:packed_ice
setblock 164 51 315 minecraft:snow_block
fill 164 51 316 164 54 316 minecraft:packed_ice
setblock 165 51 315 minecraft:packed_ice
setblock 167 51 277 minecraft:snow_block
setblock 168 51 276 minecraft:snow_block
fill 168 51 277 168 54 277 minecraft:packed_ice
setblock 168 51 316 minecraft:snow_block
fill 169 51 276 172 51 276 minecraft:packed_ice
fill 169 51 316 172 51 316 minecraft:packed_ice
setblock 173 51 276 minecraft:snow_block
setblock 173 51 316 minecraft:snow_block
fill 174 51 276 174 54 276 minecraft:packed_ice
fill 174 51 316 174 54 316 minecraft:packed_ice
setblock 177 51 277 minecraft:snow_block
setblock 178 51 276 minecraft:snow_block
fill 178 51 277 178 54 277 minecraft:packed_ice
setblock 178 51 316 minecraft:snow_block
fill 179 51 276 179 54 276 minecraft:packed_ice
setblock 179 51 315 minecraft:snow_block
fill 179 51 316 179 54 316 minecraft:packed_ice
setblock 180 51 314 minecraft:snow_block
fill 180 51 315 180 54 315 minecraft:packed_ice
setblock 181 51 278 minecraft:snow_block
fill 181 51 279 181 54 279 minecraft:packed_ice
setblock 181 51 313 minecraft:snow_block
fill 181 51 314 181 54 314 minecraft:packed_ice
setblock 182 51 277 minecraft:snow_block
fill 182 51 278 182 54 278 minecraft:packed_ice
setblock 182 51 282 minecraft:snow_block
setblock 182 51 292 minecraft:snow_block
fill 182 51 293 182 54 293 minecraft:packed_ice
setblock 182 51 297 minecraft:snow_block
fill 182 51 298 182 54 298 minecraft:packed_ice
setblock 182 51 301 minecraft:packed_ice
setblock 182 51 302 minecraft:snow_block
setblock 182 51 307 minecraft:snow_block
fill 182 51 308 182 54 308 minecraft:packed_ice
setblock 182 51 312 minecraft:snow_block
fill 182 51 313 182 54 313 minecraft:packed_ice
fill 141 52 285 141 93 285 minecraft:packed_ice
fill 141 52 301 141 93 301 minecraft:packed_ice
setblock 142 52 276 minecraft:snow_block
fill 142 52 277 142 55 277 minecraft:packed_ice
setblock 142 52 280 minecraft:packed_ice
setblock 142 52 291 minecraft:snow_block
fill 142 52 292 142 52 295 minecraft:packed_ice
setblock 142 52 296 minecraft:snow_block
fill 142 52 297 142 55 297 minecraft:packed_ice
setblock 142 52 301 minecraft:snow_block
fill 142 52 302 142 55 302 minecraft:packed_ice
setblock 142 52 306 minecraft:snow_block
fill 142 52 307 142 55 307 minecraft:packed_ice
setblock 142 52 311 minecraft:snow_block
fill 142 52 312 142 55 312 minecraft:packed_ice
setblock 142 52 316 minecraft:snow_block
fill 143 52 276 143 55 276 minecraft:packed_ice
setblock 143 52 295 minecraft:snow_block
fill 143 52 296 143 55 296 minecraft:packed_ice
setblock 143 52 300 minecraft:snow_block
fill 143 52 301 143 55 301 minecraft:packed_ice
setblock 143 52 305 minecraft:snow_block
fill 143 52 306 143 55 306 minecraft:packed_ice
setblock 143 52 310 minecraft:snow_block
fill 143 52 311 143 55 311 minecraft:packed_ice
setblock 143 52 315 minecraft:snow_block
fill 143 52 316 143 55 316 minecraft:packed_ice
fill 144 52 295 144 55 295 minecraft:packed_ice
setblock 144 52 299 minecraft:snow_block
fill 144 52 300 144 55 300 minecraft:packed_ice
fill 144 52 312 144 53 312 minecraft:blue_ice
setblock 144 52 314 minecraft:snow_block
fill 144 52 315 144 55 315 minecraft:packed_ice
fill 145 52 277 147 52 280 minecraft:blue_ice
setblock 145 52 314 minecraft:blue_ice
fill 146 52 281 146 52 282 minecraft:blue_ice
setblock 147 52 276 minecraft:snow_block
setblock 147 52 316 minecraft:snow_block
fill 148 52 316 148 54 316 minecraft:packed_ice
setblock 150 52 301 minecraft:packed_ice
setblock 150 52 304 minecraft:packed_ice
fill 151 52 305 152 52 305 minecraft:packed_ice
fill 152 52 299 153 52 299 minecraft:packed_ice
fill 153 52 317 153 93 317 minecraft:packed_ice
setblock 154 52 305 minecraft:packed_ice
setblock 155 52 300 minecraft:packed_ice
setblock 155 52 304 minecraft:packed_ice
setblock 156 52 302 minecraft:packed_ice
setblock 157 52 276 minecraft:snow_block
fill 158 52 276 158 55 276 minecraft:packed_ice
fill 158 52 316 161 52 316 minecraft:packed_ice
setblock 160 52 277 minecraft:packed_ice
setblock 161 52 277 minecraft:snow_block
setblock 162 52 276 minecraft:snow_block
fill 162 52 277 162 55 277 minecraft:packed_ice
setblock 162 52 316 minecraft:snow_block
fill 163 52 276 163 55 276 minecraft:packed_ice
fill 163 52 316 163 55 316 minecraft:packed_ice
setblock 164 52 278 minecraft:packed_ice
setblock 166 52 277 minecraft:snow_block
setblock 167 52 276 minecraft:snow_block
fill 167 52 277 167 55 277 minecraft:packed_ice
setblock 167 52 316 minecraft:snow_block
fill 168 52 276 171 52 276 minecraft:packed_ice
fill 168 52 316 171 52 316 minecraft:packed_ice
setblock 172 52 276 minecraft:snow_block
setblock 172 52 316 minecraft:snow_block
fill 173 52 276 173 55 276 minecraft:packed_ice
fill 173 52 316 173 55 316 minecraft:packed_ice
setblock 175 52 277 minecraft:packed_ice
setblock 176 52 277 minecraft:snow_block
setblock 177 52 276 minecraft:snow_block
fill 177 52 277 177 55 277 minecraft:packed_ice
setblock 177 52 316 minecraft:snow_block
fill 178 52 276 178 55 276 minecraft:packed_ice
setblock 178 52 315 minecraft:snow_block
fill 178 52 316 178 55 316 minecraft:packed_ice
fill 179 52 315 179 55 315 minecraft:packed_ice
fill 180 52 314 180 55 314 minecraft:packed_ice
setblock 181 52 277 minecraft:snow_block
fill 181 52 278 181 55 278 minecraft:packed_ice
fill 181 52 280 181 53 280 minecraft:packed_ice
setblock 181 52 296 minecraft:packed_ice
setblock 181 52 312 minecraft:snow_block
fill 181 52 313 181 55 313 minecraft:packed_ice
setblock 182 52 276 minecraft:snow_block
fill 182 52 277 182 55 277 minecraft:packed_ice
setblock 182 52 281 minecraft:snow_block
fill 182 52 282 182 55 282 minecraft:packed_ice
setblock 182 52 291 minecraft:snow_block
fill 182 52 292 182 55 292 minecraft:packed_ice
setblock 182 52 296 minecraft:snow_block
fill 182 52 297 182 55 297 minecraft:packed_ice
setblock 182 52 301 minecraft:snow_block
fill 182 52 302 182 52 305 minecraft:packed_ice
setblock 182 52 306 minecraft:snow_block
fill 182 52 307 182 55 307 minecraft:packed_ice
setblock 182 52 311 minecraft:snow_block
fill 182 52 312 182 55 312 minecraft:packed_ice
setblock 182 52 316 minecraft:snow_block
setblock 141 53 298 minecraft:white_concrete
fill 142 53 276 142 56 276 minecraft:packed_ice
setblock 142 53 280 minecraft:snow_block
fill 142 53 281 142 56 281 minecraft:packed_ice
setblock 142 53 290 minecraft:snow_block
fill 142 53 291 142 53 294 minecraft:packed_ice
setblock 142 53 295 minecraft:snow_block
fill 142 53 296 142 56 296 minecraft:packed_ice
setblock 142 53 300 minecraft:snow_block
fill 142 53 301 142 56 301 minecraft:packed_ice
setblock 142 53 305 minecraft:snow_block
fill 142 53 306 142 56 306 minecraft:packed_ice
setblock 142 53 310 minecraft:snow_block
fill 142 53 311 142 56 311 minecraft:packed_ice
setblock 142 53 315 minecraft:snow_block
fill 142 53 316 142 56 316 minecraft:packed_ice
setblock 143 53 294 minecraft:snow_block
fill 143 53 295 143 56 295 minecraft:packed_ice
setblock 143 53 298 minecraft:packed_ice
setblock 143 53 299 minecraft:snow_block
fill 143 53 300 143 56 300 minecraft:packed_ice
setblock 143 53 304 minecraft:snow_block
fill 143 53 305 143 56 305 minecraft:packed_ice
setblock 143 53 309 minecraft:snow_block
fill 143 53 310 143 56 310 minecraft:packed_ice
setblock 143 53 314 minecraft:snow_block
fill 143 53 315 143 56 315 minecraft:packed_ice
setblock 144 53 277 minecraft:packed_ice
setblock 144 53 298 minecraft:snow_block
fill 144 53 299 144 56 299 minecraft:packed_ice
fill 144 53 301 144 54 301 minecraft:packed_ice
fill 144 53 313 144 53 314 minecraft:blue_ice
fill 145 53 277 147 53 279 minecraft:blue_ice
setblock 146 53 276 minecraft:snow_block
fill 146 53 280 146 53 281 minecraft:blue_ice
setblock 146 53 316 minecraft:snow_block
fill 147 53 276 147 56 276 minecraft:packed_ice
fill 147 53 316 147 56 316 minecraft:packed_ice
fill 152 53 302 153 53 303 minecraft:blue_ice
setblock 153 53 301 minecraft:blue_ice
setblock 154 53 302 minecraft:blue_ice
setblock 156 53 276 minecraft:snow_block
fill 157 53 276 157 56 276 minecraft:packed_ice
fill 158 53 316 160 53 316 minecraft:packed_ice
setblock 159 53 277 minecraft:packed_ice
setblock 160 53 277 minecraft:snow_block
setblock 161 53 276 minecraft:snow_block
fill 161 53 277 161 55 278 minecraft:packed_ice
setblock 161 53 316 minecraft:snow_block
fill 162 53 276 162 56 276 minecraft:packed_ice
fill 162 53 278 163 53 278 minecraft:packed_ice
fill 162 53 316 162 56 316 minecraft:packed_ice
setblock 164 53 278 minecraft:snow_block
setblock 165 53 277 minecraft:snow_block
fill 165 53 278 166 55 278 minecraft:packed_ice
setblock 166 53 276 minecraft:snow_block
fill 166 53 277 166 56 277 minecraft:packed_ice
setblock 166 53 316 minecraft:snow_block
fill 167 53 276 170 53 276 minecraft:packed_ice
fill 167 53 316 170 53 316 minecraft:packed_ice
setblock 170 53 277 minecraft:snow_block
setblock 171 53 276 minecraft:snow_block
fill 171 53 277 174 53 277 minecraft:packed_ice
setblock 171 53 316 minecraft:snow_block
fill 172 53 276 172 56 276 minecraft:packed_ice
fill 172 53 316 172 56 316 minecraft:packed_ice
setblock 175 53 277 minecraft:snow_block
setblock 176 53 276 minecraft:snow_block
fill 176 53 277 176 56 277 minecraft:packed_ice
setblock 176 53 316 minecraft:snow_block
fill 177 53 276 177 56 276 minecraft:packed_ice
setblock 177 53 315 minecraft:snow_block
fill 177 53 316 177 56 316 minecraft:packed_ice
fill 178 53 315 178 56 315 minecraft:packed_ice
setblock 179 53 278 minecraft:snow_block
setblock 180 53 277 minecraft:snow_block
fill 180 53 278 180 56 278 minecraft:packed_ice
setblock 181 53 276 minecraft:snow_block
fill 181 53 277 181 56 277 minecraft:packed_ice
setblock 181 53 295 minecraft:packed_ice
setblock 181 53 296 minecraft:snow_block
fill 181 53 297 181 53 300 minecraft:packed_ice
setblock 181 53 311 minecraft:snow_block
fill 181 53 312 181 56 312 minecraft:packed_ice
setblock 181 53 316 minecraft:snow_block
fill 182 53 276 182 56 276 minecraft:packed_ice
setblock 182 53 280 minecraft:snow_block
fill 182 53 281 182 56 281 minecraft:packed_ice
fill 182 53 283 182 54 283 minecraft:packed_ice
fill 182 53 291 182 56 291 minecraft:packed_ice
setblock 182 53 295 minecraft:snow_block
fill 182 53 296 182 56 296 minecraft:packed_ice
setblock 182 53 299 minecraft:packed_ice
setblock 182 53 300 minecraft:snow_block
fill 182 53 301 182 53 304 minecraft:packed_ice
setblock 182 53 305 minecraft:snow_block
fill 182 53 306 182 56 306 minecraft:packed_ice
setblock 182 53 310 minecraft:snow_block
fill 182 53 311 182 56 311 minecraft:packed_ice
setblock 182 53 315 minecraft:snow_block
fill 182 53 316 182 56 316 minecraft:packed_ice
fill 141 54 298 141 93 298 minecraft:packed_ice
setblock 142 54 279 minecraft:snow_block
fill 142 54 280 142 57 280 minecraft:packed_ice
fill 142 54 282 142 55 282 minecraft:packed_ice
fill 142 54 290 142 54 293 minecraft:packed_ice
setblock 142 54 294 minecraft:snow_block
fill 142 54 295 142 57 295 minecraft:packed_ice
setblock 142 54 299 minecraft:snow_block
fill 142 54 300 142 57 300 minecraft:packed_ice
setblock 142 54 304 minecraft:snow_block
fill 142 54 305 142 57 305 minecraft:packed_ice
setblock 142 54 309 minecraft:snow_block
fill 142 54 310 142 57 310 minecraft:packed_ice
setblock 142 54 314 minecraft:snow_block
fill 142 54 315 142 57 315 minecraft:packed_ice
setblock 143 54 278 minecraft:snow_block
setblock 143 54 293 minecraft:snow_block
fill 143 54 294 143 57 294 minecraft:packed_ice
setblock 143 54 298 minecraft:snow_block
fill 143 54 299 143 57 299 minecraft:packed_ice
setblock 143 54 303 minecraft:snow_block
fill 143 54 304 143 57 304 minecraft:packed_ice
setblock 143 54 308 minecraft:snow_block
fill 143 54 309 143 57 309 minecraft:packed_ice
setblock 143 54 313 minecraft:snow_block
fill 143 54 314 143 57 314 minecraft:packed_ice
setblock 144 54 277 minecraft:snow_block
setblock 144 54 278 minecraft:light[level=12]
setblock 144 54 285 minecraft:light[level=12]
setblock 144 54 292 minecraft:light[level=12]
setblock 144 54 297 minecraft:snow_block
fill 144 54 298 144 57 298 minecraft:packed_ice
setblock 144 54 302 minecraft:snow_block
fill 144 54 303 144 57 303 minecraft:packed_ice
setblock 144 54 306 minecraft:light[level=12]
setblock 144 54 313 minecraft:light[level=12]
setblock 145 54 276 minecraft:snow_block
fill 145 54 277 147 54 278 minecraft:blue_ice
setblock 145 54 316 minecraft:snow_block
fill 146 54 276 146 57 276 minecraft:packed_ice
setblock 146 54 279 minecraft:blue_ice
fill 146 54 316 146 57 316 minecraft:packed_ice
setblock 151 54 278 minecraft:light[level=12]
setblock 151 54 285 minecraft:light[level=12]
setblock 151 54 292 minecraft:light[level=12]
setblock 151 54 299 minecraft:light[level=12]
setblock 151 54 306 minecraft:light[level=12]
setblock 151 54 313 minecraft:light[level=12]
fill 152 54 302 153 55 302 minecraft:blue_ice
setblock 153 54 303 minecraft:blue_ice
fill 154 54 317 158 55 317 minecraft:packed_ice
setblock 155 54 276 minecraft:snow_block
fill 156 54 276 156 57 276 minecraft:packed_ice
fill 157 54 277 158 54 277 minecraft:packed_ice
fill 157 54 301 159 105 302 minecraft:snow_block
fill 157 54 312 157 60 312 minecraft:packed_ice
fill 157 54 316 159 54 316 minecraft:packed_ice
setblock 158 54 278 minecraft:light[level=12]
setblock 158 54 285 minecraft:light[level=12]
setblock 158 54 292 minecraft:light[level=12]
setblock 158 54 299 minecraft:light[level=12]
fill 158 54 300 159 105 300 minecraft:snow_block
setblock 158 54 306 minecraft:light[level=12]
setblock 158 54 313 minecraft:light[level=12]
setblock 159 54 277 minecraft:snow_block
setblock 159 54 317 minecraft:light_blue_concrete
setblock 160 54 276 minecraft:snow_block
fill 160 54 277 160 56 278 minecraft:packed_ice
setblock 160 54 316 minecraft:snow_block
fill 160 54 317 160 91 317 minecraft:packed_ice
fill 161 54 276 161 57 276 minecraft:packed_ice
fill 161 54 316 161 57 316 minecraft:packed_ice
setblock 162 54 278 minecraft:packed_ice
setblock 163 54 278 minecraft:snow_block
setblock 164 54 277 minecraft:snow_block
fill 164 54 278 164 57 278 minecraft:packed_ice
setblock 165 54 276 minecraft:snow_block
fill 165 54 277 165 57 277 minecraft:packed_ice
setblock 165 54 285 minecraft:light[level=12]
setblock 165 54 292 minecraft:light[level=12]
setblock 165 54 299 minecraft:light[level=12]
setblock 165 54 306 minecraft:light[level=12]
setblock 165 54 313 minecraft:light[level=12]
setblock 165 54 316 minecraft:snow_block
fill 166 54 276 169 54 276 minecraft:packed_ice
fill 166 54 316 169 54 316 minecraft:packed_ice
setblock 169 54 277 minecraft:snow_block
setblock 170 54 276 minecraft:snow_block
fill 170 54 277 173 54 277 minecraft:packed_ice
setblock 170 54 316 minecraft:snow_block
fill 171 54 276 171 57 276 minecraft:packed_ice
fill 171 54 316 171 57 316 minecraft:packed_ice
setblock 172 54 278 minecraft:light[level=12]
setblock 172 54 285 minecraft:light[level=12]
setblock 172 54 292 minecraft:light[level=12]
setblock 172 54 299 minecraft:light[level=12]
setblock 172 54 306 minecraft:light[level=12]
setblock 172 54 313 minecraft:light[level=12]
setblock 174 54 277 minecraft:snow_block
setblock 175 54 276 minecraft:snow_block
fill 175 54 277 175 57 277 minecraft:packed_ice
setblock 175 54 316 minecraft:snow_block
fill 176 54 276 176 57 276 minecraft:packed_ice
setblock 176 54 315 minecraft:snow_block
fill 176 54 316 176 57 316 minecraft:packed_ice
setblock 177 54 278 minecraft:packed_ice
fill 177 54 315 177 57 315 minecraft:packed_ice
setblock 178 54 278 minecraft:snow_block
setblock 179 54 277 minecraft:snow_block
fill 179 54 278 179 57 278 minecraft:packed_ice
setblock 179 54 285 minecraft:light[level=12]
setblock 179 54 292 minecraft:light[level=12]
setblock 179 54 299 minecraft:light[level=12]
setblock 179 54 306 minecraft:light[level=12]
setblock 179 54 313 minecraft:light[level=12]
fill 179 54 314 179 56 314 minecraft:packed_ice
setblock 180 54 276 minecraft:snow_block
fill 180 54 277 180 57 277 minecraft:packed_ice
fill 180 54 279 180 55 279 minecraft:packed_ice
setblock 180 54 316 minecraft:snow_block
fill 181 54 276 181 57 276 minecraft:packed_ice
setblock 181 54 280 minecraft:snow_block
fill 181 54 281 181 57 281 minecraft:packed_ice
setblock 181 54 295 minecraft:snow_block
fill 181 54 296 181 54 299 minecraft:packed_ice
setblock 181 54 300 minecraft:snow_block
fill 181 54 301 182 54 303 minecraft:packed_ice
setblock 181 54 310 minecraft:snow_block
fill 181 54 311 181 57 311 minecraft:packed_ice
setblock 181 54 315 minecraft:snow_block
fill 181 54 316 181 57 316 minecraft:packed_ice
setblock 182 54 279 minecraft:snow_block
fill 182 54 280 182 57 280 minecraft:packed_ice
setblock 182 54 294 minecraft:snow_block
fill 182 54 295 182 57 295 minecraft:packed_ice
setblock 182 54 299 minecraft:snow_block
fill 182 54 300 183 57 300 minecraft:packed_ice
setblock 182 54 304 minecraft:snow_block
fill 182 54 305 182 57 305 minecraft:packed_ice
setblock 182 54 309 minecraft:snow_block
fill 182 54 310 182 57 310 minecraft:packed_ice
setblock 182 54 314 minecraft:snow_block
fill 182 54 315 182 57 315 minecraft:packed_ice
setblock 183 54 276 minecraft:light_blue_concrete
fill 183 54 283 183 93 283 minecraft:packed_ice
setblock 183 54 284 minecraft:light_blue_concrete
setblock 183 54 295 minecraft:light_blue_concrete
fill 183 54 296 183 89 299 minecraft:packed_ice
setblock 141 55 289 minecraft:light_blue_concrete
setblock 142 55 278 minecraft:snow_block
fill 142 55 279 143 57 279 minecraft:packed_ice
setblock 142 55 283 minecraft:snow_block
fill 142 55 290 142 55 292 minecraft:packed_ice
setblock 142 55 293 minecraft:snow_block
fill 142 55 294 142 58 294 minecraft:packed_ice
setblock 142 55 298 minecraft:snow_block
fill 142 55 299 142 58 299 minecraft:packed_ice
setblock 142 55 303 minecraft:snow_block
fill 142 55 304 142 58 304 minecraft:packed_ice
setblock 142 55 308 minecraft:snow_block
fill 142 55 309 142 58 309 minecraft:packed_ice
setblock 142 55 313 minecraft:snow_block
fill 142 55 314 142 58 314 minecraft:packed_ice
setblock 143 55 277 minecraft:snow_block
fill 143 55 278 143 58 278 minecraft:packed_ice
fill 143 55 293 143 58 293 minecraft:packed_ice
setblock 143 55 297 minecraft:snow_block
fill 143 55 298 143 58 298 minecraft:packed_ice
setblock 143 55 302 minecraft:snow_block
fill 143 55 303 143 58 303 minecraft:packed_ice
setblock 143 55 307 minecraft:snow_block
fill 143 55 308 143 58 308 minecraft:packed_ice
setblock 143 55 312 minecraft:snow_block
fill 143 55 313 143 57 313 minecraft:packed_ice
setblock 144 55 276 minecraft:snow_block
fill 144 55 277 144 58 277 minecraft:packed_ice
setblock 144 55 296 minecraft:snow_block
fill 144 55 297 144 58 297 minecraft:packed_ice
setblock 144 55 301 minecraft:snow_block
fill 144 55 302 144 58 302 minecraft:packed_ice
fill 144 55 304 144 56 304 minecraft:packed_ice
setblock 144 55 316 minecraft:snow_block
fill 145 55 276 145 58 276 minecraft:packed_ice
setblock 145 55 315 minecraft:snow_block
fill 145 55 316 145 58 316 minecraft:packed_ice
setblock 146 55 277 minecraft:blue_ice
fill 149 55 275 153 62 275 minecraft:packed_ice
setblock 154 55 275 minecraft:light_blue_concrete
setblock 154 55 276 minecraft:snow_block
fill 155 55 275 155 58 276 minecraft:packed_ice
fill 156 55 277 157 55 277 minecraft:packed_ice
fill 157 55 316 158 55 316 minecraft:packed_ice
setblock 158 55 277 minecraft:snow_block
fill 158 55 278 159 57 278 minecraft:packed_ice
setblock 159 55 276 minecraft:snow_block
fill 159 55 277 159 58 277 minecraft:packed_ice
setblock 159 55 316 minecraft:snow_block
setblock 159 55 317 minecraft:packed_ice
fill 160 55 276 160 58 276 minecraft:packed_ice
fill 160 55 316 160 58 316 minecraft:packed_ice
setblock 162 55 278 minecraft:snow_block
setblock 163 55 277 minecraft:snow_block
fill 163 55 278 163 58 278 minecraft:packed_ice
setblock 164 55 276 minecraft:snow_block
fill 164 55 277 164 58 277 minecraft:packed_ice
setblock 164 55 316 minecraft:snow_block
fill 165 55 276 168 55 276 minecraft:packed_ice
fill 165 55 316 168 55 316 minecraft:packed_ice
setblock 167 55 278 minecraft:snow_block
setblock 168 55 277 minecraft:snow_block
setblock 169 55 276 minecraft:snow_block
fill 169 55 277 172 55 277 minecraft:packed_ice
setblock 169 55 316 minecraft:snow_block
fill 170 55 276 170 58 276 minecraft:packed_ice
fill 170 55 316 170 58 316 minecraft:packed_ice
setblock 173 55 277 minecraft:snow_block
setblock 174 55 276 minecraft:snow_block
fill 174 55 277 174 58 277 minecraft:packed_ice
setblock 174 55 316 minecraft:snow_block
fill 175 55 276 175 58 276 minecraft:packed_ice
fill 175 55 278 176 55 278 minecraft:packed_ice
setblock 175 55 315 minecraft:snow_block
fill 175 55 316 175 58 316 minecraft:packed_ice
fill 176 55 315 176 58 315 minecraft:packed_ice
setblock 177 55 278 minecraft:snow_block
setblock 178 55 277 minecraft:snow_block
fill 178 55 278 178 58 278 minecraft:packed_ice
setblock 179 55 276 minecraft:snow_block
fill 179 55 277 179 58 277 minecraft:packed_ice
setblock 179 55 316 minecraft:snow_block
fill 180 55 276 180 58 276 minecraft:packed_ice
setblock 180 55 280 minecraft:snow_block
fill 180 55 313 180 56 313 minecraft:packed_ice
setblock 180 55 315 minecraft:snow_block
fill 180 55 316 180 58 316 minecraft:packed_ice
setblock 181 55 279 minecraft:snow_block
fill 181 55 280 181 58 280 minecraft:packed_ice
fill 181 55 282 181 56 282 minecraft:packed_ice
fill 181 55 295 181 55 298 minecraft:packed_ice
setblock 181 55 299 minecraft:snow_block
fill 181 55 300 181 55 303 minecraft:packed_ice
setblock 181 55 304 minecraft:snow_block
fill 181 55 305 181 55 308 minecraft:packed_ice
setblock 181 55 309 minecraft:snow_block
fill 181 55 310 181 58 310 minecraft:packed_ice
setblock 181 55 314 minecraft:snow_block
fill 181 55 315 181 58 315 minecraft:packed_ice
setblock 182 55 278 minecraft:snow_block
fill 182 55 279 182 58 279 minecraft:packed_ice
setblock 182 55 283 minecraft:snow_block
fill 182 55 284 183 58 284 minecraft:packed_ice
setblock 182 55 293 minecraft:snow_block
fill 182 55 294 182 58 294 minecraft:packed_ice
setblock 182 55 298 minecraft:snow_block
fill 182 55 299 182 58 299 minecraft:packed_ice
fill 182 55 301 182 55 302 minecraft:packed_ice
setblock 182 55 303 minecraft:snow_block
fill 182 55 304 182 58 304 minecraft:packed_ice
setblock 182 55 308 minecraft:snow_block
fill 182 55 309 182 58 309 minecraft:packed_ice
setblock 182 55 313 minecraft:snow_block
fill 182 55 314 182 58 314 minecraft:packed_ice
fill 183 55 276 183 57 276 minecraft:packed_ice
fill 183 55 295 183 91 295 minecraft:packed_ice
fill 141 56 289 142 58 289 minecraft:packed_ice
fill 141 56 303 141 64 306 minecraft:packed_ice
setblock 141 56 307 minecraft:white_concrete
fill 141 56 308 141 59 317 minecraft:packed_ice
setblock 142 56 277 minecraft:snow_block
fill 142 56 278 142 59 278 minecraft:packed_ice
setblock 142 56 282 minecraft:snow_block
fill 142 56 283 142 58 284 minecraft:packed_ice
fill 142 56 290 142 56 291 minecraft:packed_ice
setblock 142 56 292 minecraft:snow_block
fill 142 56 293 142 59 293 minecraft:packed_ice
setblock 142 56 297 minecraft:snow_block
fill 142 56 298 142 59 298 minecraft:packed_ice
setblock 142 56 302 minecraft:snow_block
fill 142 56 303 142 59 303 minecraft:packed_ice
setblock 142 56 307 minecraft:snow_block
fill 142 56 308 142 59 308 minecraft:packed_ice
setblock 142 56 312 minecraft:snow_block
fill 142 56 313 142 59 313 minecraft:packed_ice
setblock 143 56 276 minecraft:snow_block
fill 143 56 277 143 59 277 minecraft:packed_ice
setblock 143 56 280 minecraft:packed_ice
setblock 143 56 296 minecraft:snow_block
fill 143 56 297 143 59 297 minecraft:packed_ice
setblock 143 56 301 minecraft:snow_block
fill 143 56 302 143 59 302 minecraft:packed_ice
setblock 143 56 306 minecraft:snow_block
fill 143 56 307 143 59 307 minecraft:packed_ice
setblock 143 56 311 minecraft:snow_block
fill 143 56 312 143 57 312 minecraft:packed_ice
setblock 143 56 316 minecraft:snow_block
fill 144 56 276 144 59 276 minecraft:packed_ice
setblock 144 56 278 minecraft:light[level=15]
setblock 144 56 286 minecraft:light[level=15]
setblock 144 56 294 minecraft:light[level=15]
setblock 144 56 295 minecraft:snow_block
fill 144 56 296 144 58 296 minecraft:packed_ice
setblock 144 56 300 minecraft:snow_block
fill 144 56 301 144 59 301 minecraft:packed_ice
setblock 144 56 305 minecraft:snow_block
setblock 144 56 310 minecraft:light[level=15]
setblock 144 56 315 minecraft:snow_block
fill 144 56 316 144 59 316 minecraft:packed_ice
fill 150 56 281 150 62 281 minecraft:packed_ice
setblock 152 56 278 minecraft:light[level=15]
setblock 152 56 286 minecraft:light[level=15]
setblock 152 56 294 minecraft:light[level=15]
setblock 152 56 302 minecraft:light[level=15]
setblock 152 56 310 minecraft:light[level=15]
setblock 153 56 276 minecraft:snow_block
fill 153 56 302 153 57 302 minecraft:blue_ice
fill 154 56 275 154 59 276 minecraft:packed_ice
setblock 154 56 317 minecraft:white_concrete
fill 155 56 277 156 56 277 minecraft:packed_ice
fill 155 56 317 158 78 317 minecraft:packed_ice
fill 156 56 316 157 56 316 minecraft:packed_ice
setblock 157 56 277 minecraft:snow_block
fill 157 56 278 157 59 278 minecraft:packed_ice
setblock 158 56 276 minecraft:snow_block
fill 158 56 277 158 59 277 minecraft:packed_ice
setblock 158 56 316 minecraft:snow_block
fill 159 56 276 159 59 276 minecraft:packed_ice
fill 159 56 316 159 59 316 minecraft:packed_ice
setblock 159 56 317 minecraft:light_blue_concrete
fill 160 56 279 160 56 281 minecraft:snow_block
setblock 160 56 286 minecraft:light[level=15]
setblock 160 56 294 minecraft:light[level=15]
setblock 160 56 302 minecraft:light[level=15]
setblock 160 56 310 minecraft:light[level=15]
setblock 161 56 277 minecraft:packed_ice
setblock 161 56 278 minecraft:snow_block
fill 161 56 279 164 56 279 minecraft:packed_ice
setblock 162 56 277 minecraft:snow_block
fill 162 56 278 162 59 278 minecraft:packed_ice
setblock 163 56 276 minecraft:snow_block
fill 163 56 277 163 59 277 minecraft:packed_ice
setblock 163 56 316 minecraft:snow_block
fill 164 56 276 167 56 276 minecraft:packed_ice
fill 164 56 316 167 56 316 minecraft:packed_ice
setblock 165 56 278 minecraft:packed_ice
setblock 166 56 278 minecraft:snow_block
setblock 167 56 277 minecraft:snow_block
fill 167 56 278 168 58 278 minecraft:packed_ice
setblock 168 56 276 minecraft:snow_block
fill 168 56 277 171 56 277 minecraft:packed_ice
setblock 168 56 286 minecraft:light[level=15]
setblock 168 56 294 minecraft:light[level=15]
setblock 168 56 302 minecraft:light[level=15]
setblock 168 56 310 minecraft:light[level=15]
setblock 168 56 316 minecraft:snow_block
fill 169 56 276 169 59 276 minecraft:packed_ice
fill 169 56 316 169 59 316 minecraft:packed_ice
setblock 172 56 277 minecraft:snow_block
setblock 173 56 276 minecraft:snow_block
fill 173 56 277 173 58 278 minecraft:packed_ice
setblock 173 56 316 minecraft:snow_block
fill 174 56 276 174 59 276 minecraft:packed_ice
fill 174 56 278 175 56 278 minecraft:packed_ice
fill 174 56 316 174 59 316 minecraft:packed_ice
fill 175 56 315 175 59 315 minecraft:packed_ice
setblock 176 56 278 minecraft:snow_block
setblock 176 56 286 minecraft:light[level=15]
setblock 176 56 294 minecraft:light[level=15]
setblock 176 56 302 minecraft:light[level=15]
setblock 176 56 310 minecraft:light[level=15]
setblock 177 56 277 minecraft:snow_block
fill 177 56 278 177 59 278 minecraft:packed_ice
setblock 178 56 276 minecraft:snow_block
fill 178 56 277 178 59 277 minecraft:packed_ice
fill 178 56 314 178 57 314 minecraft:packed_ice
setblock 178 56 316 minecraft:snow_block
fill 179 56 276 179 59 276 minecraft:packed_ice
setblock 179 56 315 minecraft:snow_block
fill 179 56 316 179 59 316 minecraft:packed_ice
setblock 180 56 279 minecraft:snow_block
fill 180 56 280 180 58 281 minecraft:packed_ice
fill 180 56 288 182 57 288 minecraft:blue_ice
setblock 180 56 298 minecraft:packed_ice
setblock 180 56 299 minecraft:snow_block
fill 180 56 300 180 56 303 minecraft:packed_ice
setblock 180 56 314 minecraft:snow_block
fill 180 56 315 180 59 315 minecraft:packed_ice
setblock 181 56 278 minecraft:snow_block
fill 181 56 279 181 59 279 minecraft:packed_ice
setblock 181 56 283 minecraft:snow_block
fill 181 56 287 181 57 287 minecraft:blue_ice
fill 181 56 289 181 57 289 minecraft:blue_ice
fill 181 56 294 181 56 297 minecraft:packed_ice
setblock 181 56 298 minecraft:snow_block
fill 181 56 299 181 56 302 minecraft:packed_ice
setblock 181 56 303 minecraft:snow_block
fill 181 56 304 181 56 307 minecraft:packed_ice
setblock 181 56 308 minecraft:snow_block
fill 181 56 309 181 59 309 minecraft:packed_ice
setblock 181 56 313 minecraft:snow_block
fill 181 56 314 181 59 314 minecraft:packed_ice
setblock 182 56 277 minecraft:snow_block
fill 182 56 278 182 59 278 minecraft:packed_ice
setblock 182 56 282 minecraft:snow_block
fill 182 56 283 182 59 283 minecraft:packed_ice
fill 182 56 285 182 57 285 minecraft:packed_ice
setblock 182 56 292 minecraft:snow_block
fill 182 56 293 183 59 293 minecraft:packed_ice
setblock 182 56 297 minecraft:snow_block
fill 182 56 298 182 59 298 minecraft:packed_ice
setblock 182 56 301 minecraft:packed_ice
setblock 182 56 302 minecraft:snow_block
fill 182 56 303 182 59 303 minecraft:packed_ice
setblock 182 56 307 minecraft:snow_block
fill 182 56 308 182 59 308 minecraft:packed_ice
setblock 182 56 312 minecraft:snow_block
fill 182 56 313 182 59 313 minecraft:packed_ice
fill 183 56 288 183 93 288 minecraft:packed_ice
setblock 183 56 289 minecraft:white_concrete
fill 183 56 290 183 90 292 minecraft:packed_ice
setblock 183 56 305 minecraft:light_blue_concrete
setblock 183 56 307 minecraft:white_concrete
fill 141 57 307 142 60 307 minecraft:packed_ice
setblock 142 57 276 minecraft:snow_block
fill 142 57 277 142 60 277 minecraft:packed_ice
setblock 142 57 281 minecraft:snow_block
fill 142 57 282 142 60 282 minecraft:packed_ice
setblock 142 57 285 minecraft:packed_ice
setblock 142 57 286 minecraft:snow_block
fill 142 57 287 142 59 288 minecraft:packed_ice
setblock 142 57 290 minecraft:packed_ice
setblock 142 57 291 minecraft:snow_block
fill 142 57 292 142 60 292 minecraft:packed_ice
setblock 142 57 296 minecraft:snow_block
fill 142 57 297 142 60 297 minecraft:packed_ice
setblock 142 57 301 minecraft:snow_block
fill 142 57 302 142 60 302 minecraft:packed_ice
setblock 142 57 306 minecraft:snow_block
setblock 142 57 311 minecraft:snow_block
fill 142 57 312 142 60 312 minecraft:packed_ice
setblock 142 57 316 minecraft:snow_block
fill 143 57 276 143 60 276 minecraft:packed_ice
setblock 143 57 280 minecraft:snow_block
fill 143 57 281 143 60 281 minecraft:packed_ice
setblock 143 57 295 minecraft:snow_block
fill 143 57 296 143 60 296 minecraft:packed_ice
setblock 143 57 300 minecraft:snow_block
fill 143 57 301 143 60 301 minecraft:packed_ice
setblock 143 57 305 minecraft:snow_block
fill 143 57 306 143 60 306 minecraft:packed_ice
setblock 143 57 310 minecraft:snow_block
fill 143 57 311 143 58 311 minecraft:packed_ice
setblock 143 57 315 minecraft:snow_block
fill 143 57 316 143 60 316 minecraft:packed_ice
setblock 144 57 295 minecraft:packed_ice
setblock 144 57 299 minecraft:snow_block
fill 144 57 300 145 58 300 minecraft:packed_ice
setblock 144 57 304 minecraft:snow_block
fill 144 57 305 144 60 305 minecraft:packed_ice
setblock 144 57 315 minecraft:packed_ice
setblock 147 57 276 minecraft:snow_block
setblock 149 57 317 minecraft:white_concrete
fill 150 57 317 150 68 317 minecraft:packed_ice
setblock 151 57 317 minecraft:white_concrete
setblock 152 57 276 minecraft:snow_block
fill 152 57 317 152 79 317 minecraft:packed_ice
fill 153 57 276 153 60 276 minecraft:packed_ice
fill 154 57 277 155 57 277 minecraft:packed_ice
fill 154 57 317 154 69 317 minecraft:packed_ice
setblock 156 57 277 minecraft:snow_block
fill 156 57 278 156 60 278 minecraft:packed_ice
setblock 156 57 316 minecraft:packed_ice
setblock 157 57 276 minecraft:snow_block
fill 157 57 277 157 60 277 minecraft:packed_ice
setblock 157 57 316 minecraft:snow_block
fill 158 57 276 158 60 276 minecraft:packed_ice
setblock 158 57 279 minecraft:packed_ice
fill 158 57 316 158 60 316 minecraft:packed_ice
setblock 159 57 279 minecraft:snow_block
fill 159 57 317 159 94 317 minecraft:packed_ice
setblock 160 57 277 minecraft:packed_ice
setblock 160 57 278 minecraft:snow_block
fill 160 57 279 163 57 279 minecraft:packed_ice
fill 160 57 280 160 57 281 minecraft:snow_block
setblock 161 57 277 minecraft:snow_block
fill 161 57 278 161 60 278 minecraft:packed_ice
setblock 162 57 276 minecraft:snow_block
fill 162 57 277 162 60 277 minecraft:packed_ice
setblock 162 57 316 minecraft:snow_block
fill 162 57 317 162 84 317 minecraft:packed_ice
fill 163 57 276 166 57 276 minecraft:packed_ice
fill 163 57 316 166 57 316 minecraft:packed_ice
setblock 163 57 317 minecraft:white_concrete
setblock 164 57 279 minecraft:snow_block
fill 164 57 317 167 57 317 minecraft:packed_ice
setblock 165 57 275 minecraft:light_blue_concrete
setblock 165 57 278 minecraft:snow_block
fill 165 57 279 165 58 279 minecraft:packed_ice
fill 166 57 275 166 74 275 minecraft:packed_ice
setblock 166 57 277 minecraft:snow_block
fill 166 57 278 166 60 278 minecraft:packed_ice
setblock 167 57 276 minecraft:snow_block
fill 167 57 277 170 57 277 minecraft:packed_ice
setblock 167 57 316 minecraft:snow_block
fill 168 57 276 168 60 276 minecraft:packed_ice
fill 168 57 316 168 58 316 minecraft:packed_ice
setblock 169 57 278 minecraft:packed_ice
setblock 170 57 278 minecraft:snow_block
setblock 171 57 277 minecraft:snow_block
fill 171 57 278 172 59 278 minecraft:packed_ice
setblock 172 57 276 minecraft:snow_block
fill 172 57 277 172 60 277 minecraft:packed_ice
setblock 172 57 316 minecraft:snow_block
fill 173 57 276 173 60 276 minecraft:packed_ice
fill 173 57 316 173 60 316 minecraft:packed_ice
setblock 174 57 278 minecraft:packed_ice
fill 174 57 315 174 60 315 minecraft:packed_ice
setblock 175 57 278 minecraft:snow_block
setblock 176 57 277 minecraft:snow_block
fill 176 57 278 176 60 278 minecraft:packed_ice
setblock 177 57 276 minecraft:snow_block
fill 177 57 277 177 60 277 minecraft:packed_ice
fill 177 57 279 178 57 279 minecraft:packed_ice
setblock 177 57 316 minecraft:snow_block
fill 178 57 276 178 60 276 minecraft:packed_ice
fill 178 57 288 179 58 288 minecraft:blue_ice
setblock 178 57 315 minecraft:snow_block
fill 178 57 316 178 60 316 minecraft:packed_ice
setblock 179 57 279 minecraft:snow_block
fill 179 57 287 180 57 287 minecraft:blue_ice
fill 179 57 289 180 57 289 minecraft:blue_ice
setblock 179 57 314 minecraft:snow_block
fill 179 57 315 179 60 315 minecraft:packed_ice
setblock 180 57 278 minecraft:snow_block
fill 180 57 279 180 60 279 minecraft:packed_ice
setblock 180 57 282 minecraft:packed_ice
setblock 180 57 297 minecraft:packed_ice
setblock 180 57 298 minecraft:snow_block
fill 180 57 299 180 57 302 minecraft:packed_ice
setblock 180 57 303 minecraft:snow_block
fill 180 57 304 181 57 306 minecraft:packed_ice
setblock 180 57 312 minecraft:packed_ice
setblock 180 57 313 minecraft:snow_block
fill 180 57 314 180 60 314 minecraft:packed_ice
setblock 181 57 277 minecraft:snow_block
fill 181 57 278 181 60 278 minecraft:packed_ice
setblock 181 57 282 minecraft:snow_block
fill 181 57 283 181 59 284 minecraft:packed_ice
fill 181 57 294 181 57 296 minecraft:packed_ice
setblock 181 57 297 minecraft:snow_block
fill 181 57 298 181 57 301 minecraft:packed_ice
setblock 181 57 302 minecraft:snow_block
fill 181 57 303 181 60 303 minecraft:packed_ice
setblock 181 57 307 minecraft:snow_block
fill 181 57 308 181 60 308 minecraft:packed_ice
setblock 181 57 312 minecraft:snow_block
fill 181 57 313 181 60 313 minecraft:packed_ice
setblock 182 57 276 minecraft:snow_block
fill 182 57 277 182 60 277 minecraft:packed_ice
setblock 182 57 281 minecraft:snow_block
fill 182 57 282 182 60 282 minecraft:packed_ice
setblock 182 57 286 minecraft:snow_block
fill 182 57 292 182 58 292 minecraft:packed_ice
setblock 182 57 296 minecraft:snow_block
fill 182 57 297 182 60 297 minecraft:packed_ice
setblock 182 57 301 minecraft:snow_block
fill 182 57 302 182 60 302 minecraft:packed_ice
setblock 182 57 306 minecraft:snow_block
fill 182 57 307 183 60 307 minecraft:packed_ice
setblock 182 57 311 minecraft:snow_block
fill 182 57 312 182 60 312 minecraft:packed_ice
setblock 182 57 316 minecraft:snow_block
fill 183 57 289 183 90 289 minecraft:packed_ice
fill 183 57 305 183 58 305 minecraft:packed_ice
fill 142 58 276 142 61 276 minecraft:packed_ice
setblock 142 58 279 minecraft:packed_ice
setblock 142 58 280 minecraft:snow_block
fill 142 58 281 142 61 281 minecraft:packed_ice
setblock 142 58 285 minecraft:snow_block
fill 142 58 286 142 61 286 minecraft:packed_ice
setblock 142 58 290 minecraft:snow_block
fill 142 58 291 142 61 291 minecraft:packed_ice
setblock 142 58 295 minecraft:snow_block
fill 142 58 296 142 61 296 minecraft:packed_ice
setblock 142 58 300 minecraft:snow_block
fill 142 58 301 142 61 301 minecraft:packed_ice
setblock 142 58 305 minecraft:snow_block
fill 142 58 306 142 61 306 minecraft:packed_ice
setblock 142 58 310 minecraft:snow_block
fill 142 58 311 142 61 311 minecraft:packed_ice
setblock 142 58 315 minecraft:snow_block
fill 142 58 316 142 61 316 minecraft:packed_ice
setblock 143 58 279 minecraft:snow_block
fill 143 58 280 143 60 280 minecraft:packed_ice
fill 143 58 282 143 59 282 minecraft:packed_ice
setblock 143 58 294 minecraft:snow_block
fill 143 58 295 143 60 295 minecraft:packed_ice
setblock 143 58 299 minecraft:snow_block
fill 143 58 300 143 61 300 minecraft:packed_ice
setblock 143 58 304 minecraft:snow_block
fill 143 58 305 143 61 305 minecraft:packed_ice
setblock 143 58 309 minecraft:snow_block
fill 143 58 310 143 59 310 minecraft:packed_ice
setblock 143 58 314 minecraft:snow_block
setblock 143 58 315 minecraft:packed_ice
setblock 144 58 298 minecraft:snow_block
fill 144 58 299 144 61 299 minecraft:packed_ice
setblock 144 58 303 minecraft:snow_block
fill 144 58 304 144 61 304 minecraft:packed_ice
fill 144 58 306 144 59 306 minecraft:packed_ice
setblock 145 58 301 minecraft:packed_ice
setblock 146 58 276 minecraft:snow_block
fill 146 58 278 146 67 278 minecraft:packed_ice
fill 149 58 317 149 69 317 minecraft:packed_ice
setblock 151 58 276 minecraft:snow_block
fill 151 58 317 151 93 317 minecraft:packed_ice
fill 152 58 276 152 61 276 minecraft:packed_ice
fill 153 58 277 154 58 277 minecraft:packed_ice
setblock 155 58 277 minecraft:snow_block
fill 155 58 278 155 61 278 minecraft:packed_ice
setblock 155 58 316 minecraft:packed_ice
setblock 156 58 276 minecraft:snow_block
fill 156 58 277 156 61 277 minecraft:packed_ice
setblock 156 58 316 minecraft:snow_block
fill 157 58 276 157 61 276 minecraft:packed_ice
setblock 157 58 279 minecraft:packed_ice
fill 157 58 316 157 61 316 minecraft:packed_ice
setblock 158 58 278 minecraft:packed_ice
setblock 158 58 279 minecraft:snow_block
setblock 159 58 278 minecraft:snow_block
fill 159 58 279 162 58 279 minecraft:packed_ice
setblock 160 58 277 minecraft:snow_block
fill 160 58 278 160 61 278 minecraft:packed_ice
setblock 161 58 276 minecraft:snow_block
fill 161 58 277 161 61 277 minecraft:packed_ice
setblock 161 58 316 minecraft:snow_block
fill 162 58 276 165 58 276 minecraft:packed_ice
fill 162 58 316 165 58 316 minecraft:packed_ice
setblock 163 58 279 minecraft:snow_block
fill 163 58 317 165 90 317 minecraft:packed_ice
setblock 164 58 278 minecraft:snow_block
fill 164 58 279 164 59 279 minecraft:packed_ice
fill 165 58 275 165 89 275 minecraft:packed_ice
setblock 165 58 277 minecraft:snow_block
fill 165 58 278 165 61 278 minecraft:packed_ice
setblock 166 58 276 minecraft:snow_block
fill 166 58 277 169 58 277 minecraft:packed_ice
setblock 166 58 316 minecraft:snow_block
setblock 166 58 317 minecraft:white_concrete
fill 167 58 276 167 61 276 minecraft:packed_ice
fill 167 58 316 167 58 317 minecraft:packed_ice
setblock 169 58 278 minecraft:snow_block
setblock 170 58 277 minecraft:snow_block
fill 170 58 278 170 60 278 minecraft:packed_ice
setblock 171 58 276 minecraft:snow_block
fill 171 58 277 171 61 277 minecraft:packed_ice
setblock 171 58 316 minecraft:snow_block
fill 172 58 276 172 61 276 minecraft:packed_ice
fill 172 58 316 172 61 316 minecraft:packed_ice
setblock 174 58 278 minecraft:snow_block
setblock 175 58 277 minecraft:snow_block
fill 175 58 278 175 61 278 minecraft:packed_ice
setblock 176 58 276 minecraft:snow_block
fill 176 58 277 176 61 277 minecraft:packed_ice
fill 176 58 279 177 58 279 minecraft:packed_ice
setblock 176 58 316 minecraft:snow_block
fill 177 58 276 177 61 276 minecraft:packed_ice
setblock 177 58 288 minecraft:blue_ice
setblock 177 58 314 minecraft:packed_ice
setblock 177 58 315 minecraft:snow_block
fill 177 58 316 177 61 316 minecraft:packed_ice
setblock 178 58 279 minecraft:snow_block
setblock 178 58 314 minecraft:snow_block
fill 178 58 315 178 61 315 minecraft:packed_ice
setblock 179 58 278 minecraft:snow_block
fill 179 58 279 179 60 280 minecraft:packed_ice
fill 179 58 314 179 61 314 minecraft:packed_ice
setblock 180 58 277 minecraft:snow_block
fill 180 58 278 180 61 278 minecraft:packed_ice
setblock 180 58 282 minecraft:snow_block
setblock 180 58 288 minecraft:blue_ice
setblock 180 58 297 minecraft:snow_block
fill 180 58 298 180 58 301 minecraft:packed_ice
setblock 180 58 302 minecraft:snow_block
fill 180 58 303 180 58 306 minecraft:packed_ice
setblock 180 58 307 minecraft:snow_block
fill 180 58 308 180 58 311 minecraft:packed_ice
setblock 180 58 312 minecraft:snow_block
fill 180 58 313 180 60 313 minecraft:packed_ice
setblock 181 58 276 minecraft:snow_block
fill 181 58 277 181 61 277 minecraft:packed_ice
setblock 181 58 281 minecraft:snow_block
fill 181 58 282 181 61 282 minecraft:packed_ice
setblock 181 58 295 minecraft:packed_ice
setblock 181 58 296 minecraft:snow_block
fill 181 58 297 181 58 300 minecraft:packed_ice
setblock 181 58 301 minecraft:snow_block
fill 181 58 302 181 61 302 minecraft:packed_ice
fill 181 58 304 181 58 305 minecraft:packed_ice
setblock 181 58 306 minecraft:snow_block
fill 181 58 307 181 61 307 minecraft:packed_ice
setblock 181 58 311 minecraft:snow_block
fill 181 58 312 181 61 312 minecraft:packed_ice
setblock 181 58 316 minecraft:snow_block
fill 182 58 276 182 61 276 minecraft:packed_ice
setblock 182 58 280 minecraft:snow_block
fill 182 58 281 182 61 281 minecraft:packed_ice
setblock 182 58 285 minecraft:snow_block
fill 182 58 286 182 60 287 minecraft:packed_ice
setblock 182 58 295 minecraft:snow_block
fill 182 58 296 182 61 296 minecraft:packed_ice
setblock 182 58 300 minecraft:snow_block
fill 182 58 301 182 61 301 minecraft:packed_ice
setblock 182 58 305 minecraft:snow_block
fill 182 58 306 182 61 306 minecraft:packed_ice
setblock 182 58 310 minecraft:snow_block
fill 182 58 311 182 61 311 minecraft:packed_ice
setblock 182 58 315 minecraft:snow_block
fill 182 58 316 182 61 316 minecraft:packed_ice
setblock 183 58 276 minecraft:white_concrete
setblock 183 58 287 minecraft:light_blue_concrete
fill 183 58 300 183 91 300 minecraft:packed_ice
setblock 183 58 316 minecraft:light_blue_concrete
fill 141 59 289 141 84 289 minecraft:packed_ice
setblock 142 59 279 minecraft:snow_block
fill 142 59 280 142 62 280 minecraft:packed_ice
setblock 142 59 283 minecraft:packed_ice
setblock 142 59 284 minecraft:snow_block
fill 142 59 285 142 62 285 minecraft:packed_ice
setblock 142 59 289 minecraft:snow_block
fill 142 59 290 142 61 290 minecraft:packed_ice
setblock 142 59 294 minecraft:snow_block
fill 142 59 295 142 62 295 minecraft:packed_ice
setblock 142 59 299 minecraft:snow_block
fill 142 59 300 142 62 300 minecraft:packed_ice
setblock 142 59 304 minecraft:snow_block
fill 142 59 305 142 62 305 minecraft:packed_ice
setblock 142 59 309 minecraft:snow_block
fill 142 59 310 142 62 310 minecraft:packed_ice
setblock 142 59 314 minecraft:snow_block
fill 142 59 315 142 61 315 minecraft:packed_ice
setblock 143 59 278 minecraft:snow_block
fill 143 59 279 143 60 279 minecraft:packed_ice
setblock 143 59 294 minecraft:packed_ice
setblock 143 59 298 minecraft:snow_block
fill 143 59 299 143 62 299 minecraft:packed_ice
setblock 143 59 303 minecraft:snow_block
fill 143 59 304 143 62 304 minecraft:packed_ice
setblock 143 59 308 minecraft:snow_block
fill 143 59 309 143 61 309 minecraft:packed_ice
setblock 144 59 297 minecraft:snow_block
fill 144 59 298 144 60 298 minecraft:packed_ice
fill 144 59 300 144 60 300 minecraft:packed_ice
setblock 144 59 302 minecraft:snow_block
fill 144 59 303 144 62 303 minecraft:packed_ice
setblock 145 59 276 minecraft:snow_block
fill 151 59 276 151 60 276 minecraft:packed_ice
setblock 153 59 277 minecraft:packed_ice
setblock 154 59 277 minecraft:snow_block
fill 155 59 275 155 93 275 minecraft:packed_ice
setblock 155 59 276 minecraft:snow_block
fill 155 59 277 155 62 277 minecraft:packed_ice
setblock 155 59 316 minecraft:snow_block
fill 156 59 276 156 62 276 minecraft:packed_ice
setblock 156 59 279 minecraft:packed_ice
fill 156 59 312 156 60 312 minecraft:packed_ice
fill 156 59 316 156 61 316 minecraft:packed_ice
setblock 157 59 279 minecraft:snow_block
fill 157 59 311 157 60 311 minecraft:packed_ice
fill 157 59 313 157 60 313 minecraft:packed_ice
setblock 158 59 278 minecraft:snow_block
fill 158 59 279 161 59 279 minecraft:packed_ice
fill 158 59 312 158 60 312 minecraft:packed_ice
setblock 159 59 277 minecraft:snow_block
fill 159 59 278 159 62 278 minecraft:packed_ice
fill 159 59 280 160 59 280 minecraft:packed_ice
setblock 160 59 276 minecraft:snow_block
fill 160 59 277 160 62 277 minecraft:packed_ice
setblock 160 59 316 minecraft:snow_block
fill 161 59 276 164 59 276 minecraft:packed_ice
fill 161 59 316 164 59 316 minecraft:packed_ice
setblock 162 59 279 minecraft:snow_block
setblock 163 59 278 minecraft:snow_block
fill 163 59 279 163 60 279 minecraft:packed_ice
setblock 164 59 277 minecraft:snow_block
fill 164 59 278 164 61 278 minecraft:packed_ice
setblock 165 59 276 minecraft:snow_block
fill 165 59 277 168 59 277 minecraft:packed_ice
setblock 165 59 316 minecraft:snow_block
fill 166 59 276 166 62 276 minecraft:packed_ice
fill 166 59 316 166 59 317 minecraft:packed_ice
setblock 167 59 278 minecraft:packed_ice
fill 167 59 317 167 72 317 minecraft:packed_ice
setblock 168 59 278 minecraft:snow_block
setblock 169 59 277 minecraft:snow_block
setblock 169 59 278 minecraft:packed_ice
setblock 170 59 276 minecraft:snow_block
fill 170 59 277 170 62 277 minecraft:packed_ice
setblock 170 59 316 minecraft:snow_block
fill 171 59 276 171 62 276 minecraft:packed_ice
fill 171 59 316 171 62 316 minecraft:packed_ice
setblock 173 59 277 minecraft:packed_ice
setblock 173 59 278 minecraft:snow_block
setblock 174 59 277 minecraft:snow_block
fill 174 59 278 174 62 278 minecraft:packed_ice
setblock 175 59 276 minecraft:snow_block
fill 175 59 277 175 62 277 minecraft:packed_ice
fill 175 59 279 176 59 279 minecraft:packed_ice
setblock 175 59 316 minecraft:snow_block
fill 176 59 276 176 62 276 minecraft:packed_ice
setblock 176 59 315 minecraft:snow_block
fill 176 59 316 176 62 316 minecraft:packed_ice
setblock 177 59 279 minecraft:snow_block
setblock 177 59 314 minecraft:snow_block
fill 177 59 315 177 62 315 minecraft:packed_ice
setblock 178 59 278 minecraft:snow_block
fill 178 59 279 178 60 279 minecraft:packed_ice
fill 178 59 314 178 61 314 minecraft:packed_ice
setblock 179 59 277 minecraft:snow_block
fill 179 59 278 179 62 278 minecraft:packed_ice
setblock 179 59 301 minecraft:packed_ice
setblock 179 59 302 minecraft:snow_block
fill 179 59 303 180 60 304 minecraft:packed_ice
setblock 180 59 276 minecraft:snow_block
fill 180 59 277 180 62 277 minecraft:packed_ice
setblock 180 59 280 minecraft:packed_ice
setblock 180 59 281 minecraft:snow_block
fill 180 59 282 180 60 283 minecraft:packed_ice
fill 180 59 298 180 59 300 minecraft:packed_ice
setblock 180 59 301 minecraft:snow_block
fill 180 59 302 180 62 302 minecraft:packed_ice
setblock 180 59 305 minecraft:packed_ice
setblock 180 59 306 minecraft:snow_block
fill 180 59 307 180 59 310 minecraft:packed_ice
setblock 180 59 311 minecraft:snow_block
fill 180 59 312 180 60 312 minecraft:packed_ice
setblock 180 59 316 minecraft:snow_block
fill 181 59 276 181 62 276 minecraft:packed_ice
setblock 181 59 280 minecraft:snow_block
fill 181 59 281 181 62 281 minecraft:packed_ice
setblock 181 59 285 minecraft:snow_block
setblock 181 59 295 minecraft:snow_block
fill 181 59 296 181 59 299 minecraft:packed_ice
setblock 181 59 300 minecraft:snow_block
fill 181 59 301 181 62 301 minecraft:packed_ice
setblock 181 59 304 minecraft:packed_ice
setblock 181 59 305 minecraft:snow_block
fill 181 59 306 181 62 306 minecraft:packed_ice
setblock 181 59 310 minecraft:snow_block
fill 181 59 311 181 62 311 minecraft:packed_ice
setblock 181 59 315 minecraft:snow_block
fill 181 59 316 181 62 316 minecraft:packed_ice
setblock 182 59 279 minecraft:snow_block
fill 182 59 280 182 62 280 minecraft:packed_ice
setblock 182 59 284 minecraft:snow_block
fill 182 59 285 182 62 285 minecraft:packed_ice
setblock 182 59 294 minecraft:snow_block
fill 182 59 295 182 61 295 minecraft:packed_ice
setblock 182 59 299 minecraft:snow_block
fill 182 59 300 182 62 300 minecraft:packed_ice
setblock 182 59 304 minecraft:snow_block
fill 182 59 305 182 62 305 minecraft:packed_ice
setblock 182 59 309 minecraft:snow_block
fill 182 59 310 182 62 310 minecraft:packed_ice
setblock 182 59 314 minecraft:snow_block
fill 182 59 315 182 62 315 minecraft:packed_ice
fill 183 59 276 183 61 276 minecraft:packed_ice
fill 183 59 284 183 64 284 minecraft:packed_ice
fill 183 59 287 183 93 287 minecraft:packed_ice
setblock 183 59 305 minecraft:white_concrete
fill 183 59 316 183 91 316 minecraft:packed_ice
fill 141 60 308 141 65 311 minecraft:packed_ice
setblock 141 60 312 minecraft:white_concrete
fill 141 60 313 141 60 317 minecraft:packed_ice
setblock 142 60 278 minecraft:snow_block
fill 142 60 279 142 62 279 minecraft:packed_ice
setblock 142 60 283 minecraft:snow_block
fill 142 60 284 142 63 284 minecraft:packed_ice
setblock 142 60 287 minecraft:packed_ice
setblock 142 60 288 minecraft:snow_block
fill 142 60 289 142 61 289 minecraft:packed_ice
setblock 142 60 293 minecraft:snow_block
fill 142 60 294 142 62 294 minecraft:packed_ice
setblock 142 60 298 minecraft:snow_block
fill 142 60 299 142 63 299 minecraft:packed_ice
setblock 142 60 303 minecraft:snow_block
fill 142 60 304 142 63 304 minecraft:packed_ice
setblock 142 60 308 minecraft:snow_block
fill 142 60 309 142 63 309 minecraft:packed_ice
setblock 142 60 313 minecraft:snow_block
fill 142 60 314 142 61 314 minecraft:packed_ice
setblock 143 60 282 minecraft:snow_block
fill 143 60 290 143 65 290 minecraft:packed_ice
setblock 143 60 297 minecraft:snow_block
fill 143 60 298 143 62 298 minecraft:packed_ice
setblock 143 60 302 minecraft:snow_block
fill 143 60 303 143 63 303 minecraft:packed_ice
setblock 143 60 307 minecraft:snow_block
fill 143 60 308 143 62 308 minecraft:packed_ice
setblock 144 60 276 minecraft:snow_block
setblock 144 60 278 minecraft:light[level=12]
setblock 144 60 285 minecraft:light[level=12]
setblock 144 60 292 minecraft:light[level=12]
setblock 144 60 301 minecraft:snow_block
fill 144 60 302 144 62 302 minecraft:packed_ice
setblock 144 60 306 minecraft:snow_block
setblock 144 60 313 minecraft:light[level=12]
setblock 151 60 278 minecraft:light[level=12]
setblock 151 60 285 minecraft:light[level=12]
setblock 151 60 292 minecraft:light[level=12]
setblock 151 60 299 minecraft:light[level=12]
setblock 151 60 306 minecraft:light[level=12]
setblock 151 60 313 minecraft:light[level=12]
setblock 153 60 277 minecraft:snow_block
fill 154 60 275 154 89 275 minecraft:packed_ice
setblock 154 60 276 minecraft:snow_block
fill 154 60 277 154 61 278 minecraft:packed_ice
fill 155 60 276 155 63 276 minecraft:packed_ice
setblock 156 60 279 minecraft:snow_block
setblock 157 60 278 minecraft:snow_block
fill 157 60 279 160 60 279 minecraft:packed_ice
setblock 158 60 277 minecraft:snow_block
fill 158 60 278 158 63 278 minecraft:packed_ice
setblock 158 60 285 minecraft:light[level=12]
setblock 158 60 292 minecraft:light[level=12]
setblock 158 60 299 minecraft:light[level=12]
setblock 158 60 306 minecraft:light[level=12]
setblock 158 60 313 minecraft:light[level=12]
setblock 159 60 276 minecraft:snow_block
fill 159 60 277 159 63 277 minecraft:packed_ice
setblock 159 60 280 minecraft:packed_ice
setblock 159 60 316 minecraft:snow_block
fill 160 60 276 163 60 276 minecraft:packed_ice
fill 160 60 316 163 60 316 minecraft:packed_ice
setblock 161 60 279 minecraft:snow_block
setblock 162 60 278 minecraft:snow_block
fill 162 60 279 162 61 279 minecraft:packed_ice
setblock 163 60 277 minecraft:snow_block
fill 163 60 278 163 62 278 minecraft:packed_ice
setblock 164 60 276 minecraft:snow_block
fill 164 60 277 167 60 277 minecraft:packed_ice
setblock 164 60 316 minecraft:snow_block
fill 165 60 276 165 63 276 minecraft:packed_ice
setblock 165 60 285 minecraft:light[level=12]
setblock 165 60 292 minecraft:light[level=12]
setblock 165 60 299 minecraft:light[level=12]
setblock 165 60 306 minecraft:light[level=12]
setblock 165 60 313 minecraft:light[level=12]
fill 166 60 317 166 89 317 minecraft:packed_ice
setblock 167 60 278 minecraft:snow_block
setblock 168 60 277 minecraft:snow_block
setblock 168 60 278 minecraft:packed_ice
setblock 169 60 276 minecraft:snow_block
fill 169 60 277 169 62 277 minecraft:packed_ice
fill 170 60 276 170 63 276 minecraft:packed_ice
setblock 170 60 316 minecraft:packed_ice
setblock 171 60 278 minecraft:packed_ice
setblock 172 60 278 minecraft:snow_block
setblock 172 60 285 minecraft:light[level=12]
setblock 172 60 292 minecraft:light[level=12]
setblock 172 60 299 minecraft:light[level=12]
setblock 172 60 306 minecraft:light[level=12]
setblock 172 60 313 minecraft:light[level=12]
setblock 173 60 277 minecraft:snow_block
fill 173 60 278 173 62 278 minecraft:packed_ice
setblock 174 60 276 minecraft:snow_block
fill 174 60 277 174 63 277 minecraft:packed_ice
setblock 174 60 316 minecraft:snow_block
fill 175 60 276 175 63 276 minecraft:packed_ice
setblock 175 60 279 minecraft:packed_ice
setblock 175 60 315 minecraft:snow_block
fill 175 60 316 175 63 316 minecraft:packed_ice
setblock 176 60 279 minecraft:snow_block
fill 176 60 315 176 63 315 minecraft:packed_ice
setblock 177 60 278 minecraft:snow_block
fill 177 60 279 177 61 279 minecraft:packed_ice
setblock 177 60 314 minecraft:packed_ice
setblock 178 60 277 minecraft:snow_block
fill 178 60 278 178 62 278 minecraft:packed_ice
setblock 179 60 276 minecraft:snow_block
fill 179 60 277 179 63 277 minecraft:packed_ice
setblock 179 60 285 minecraft:light[level=12]
setblock 179 60 292 minecraft:light[level=12]
setblock 179 60 299 minecraft:light[level=12]
setblock 179 60 301 minecraft:snow_block
fill 179 60 302 179 61 302 minecraft:packed_ice
setblock 179 60 305 minecraft:packed_ice
setblock 179 60 306 minecraft:snow_block
setblock 179 60 313 minecraft:light[level=12]
setblock 179 60 316 minecraft:snow_block
fill 180 60 276 180 63 276 minecraft:packed_ice
setblock 180 60 280 minecraft:snow_block
fill 180 60 281 180 61 281 minecraft:packed_ice
fill 180 60 298 180 60 299 minecraft:packed_ice
setblock 180 60 300 minecraft:snow_block
fill 180 60 301 180 63 301 minecraft:packed_ice
setblock 180 60 305 minecraft:snow_block
fill 180 60 306 180 60 309 minecraft:packed_ice
setblock 180 60 310 minecraft:snow_block
fill 180 60 311 180 61 311 minecraft:packed_ice
setblock 180 60 315 minecraft:snow_block
fill 180 60 316 180 63 316 minecraft:packed_ice
setblock 181 60 279 minecraft:snow_block
fill 181 60 280 181 62 280 minecraft:packed_ice
setblock 181 60 283 minecraft:packed_ice
setblock 181 60 284 minecraft:snow_block
setblock 181 60 285 minecraft:packed_ice
fill 181 60 296 181 60 298 minecraft:packed_ice
setblock 181 60 299 minecraft:snow_block
fill 181 60 300 181 63 300 minecraft:packed_ice
setblock 181 60 304 minecraft:snow_block
fill 181 60 305 181 63 305 minecraft:packed_ice
setblock 181 60 309 minecraft:snow_block
fill 181 60 310 181 63 310 minecraft:packed_ice
setblock 181 60 314 minecraft:snow_block
fill 181 60 315 181 62 315 minecraft:packed_ice
setblock 182 60 278 minecraft:snow_block
fill 182 60 279 182 63 279 minecraft:packed_ice
setblock 182 60 283 minecraft:snow_block
fill 182 60 284 182 63 284 minecraft:packed_ice
setblock 182 60 294 minecraft:packed_ice
setblock 182 60 298 minecraft:snow_block
fill 182 60 299 182 63 299 minecraft:packed_ice
setblock 182 60 303 minecraft:snow_block
fill 182 60 304 182 63 304 minecraft:packed_ice
setblock 182 60 308 minecraft:snow_block
fill 182 60 309 182 63 309 minecraft:packed_ice
setblock 182 60 313 minecraft:snow_block
fill 182 60 314 182 63 314 minecraft:packed_ice
fill 183 60 293 183 93 293 minecraft:packed_ice
fill 183 60 305 183 93 305 minecraft:packed_ice
fill 141 61 307 141 90 307 minecraft:packed_ice
fill 141 61 312 141 93 314 minecraft:packed_ice
setblock 141 61 315 minecraft:light_blue_concrete
fill 141 61 316 141 89 317 minecraft:packed_ice
setblock 142 61 277 minecraft:snow_block
fill 142 61 278 142 62 278 minecraft:packed_ice
setblock 142 61 282 minecraft:snow_block
fill 142 61 283 142 64 283 minecraft:packed_ice
setblock 142 61 287 minecraft:snow_block
fill 142 61 288 142 63 288 minecraft:packed_ice
setblock 142 61 292 minecraft:snow_block
fill 142 61 293 142 62 293 minecraft:packed_ice
setblock 142 61 297 minecraft:snow_block
fill 142 61 298 142 64 298 minecraft:packed_ice
setblock 142 61 302 minecraft:snow_block
fill 142 61 303 142 64 303 minecraft:packed_ice
setblock 142 61 307 minecraft:snow_block
fill 142 61 308 142 64 308 minecraft:packed_ice
setblock 142 61 312 minecraft:snow_block
setblock 142 61 313 minecraft:packed_ice
setblock 143 61 296 minecraft:snow_block
fill 143 61 297 143 62 297 minecraft:packed_ice
setblock 143 61 301 minecraft:snow_block
fill 143 61 302 143 64 302 minecraft:packed_ice
setblock 143 61 306 minecraft:snow_block
fill 143 61 307 143 64 307 minecraft:packed_ice
setblock 144 61 300 minecraft:snow_block
fill 144 61 301 144 62 301 minecraft:packed_ice
setblock 144 61 305 minecraft:snow_block
fill 149 61 281 149 62 281 minecraft:packed_ice
fill 150 61 280 150 62 280 minecraft:packed_ice
fill 150 61 282 150 62 282 minecraft:packed_ice
fill 151 61 281 151 62 281 minecraft:packed_ice
setblock 153 61 276 minecraft:snow_block
fill 153 61 277 153 62 277 minecraft:packed_ice
fill 154 61 276 154 64 276 minecraft:packed_ice
setblock 156 61 278 minecraft:snow_block
fill 156 61 279 159 61 279 minecraft:packed_ice
setblock 157 61 277 minecraft:snow_block
fill 157 61 278 157 64 278 minecraft:packed_ice
setblock 158 61 276 minecraft:snow_block
fill 158 61 277 158 64 277 minecraft:packed_ice
setblock 158 61 316 minecraft:snow_block
fill 159 61 276 162 61 276 minecraft:packed_ice
fill 159 61 316 162 61 316 minecraft:packed_ice
setblock 160 61 279 minecraft:snow_block
setblock 161 61 278 minecraft:snow_block
setblock 161 61 279 minecraft:packed_ice
setblock 162 61 277 minecraft:snow_block
fill 162 61 278 162 62 278 minecraft:packed_ice
setblock 163 61 276 minecraft:snow_block
fill 163 61 277 166 61 277 minecraft:packed_ice
fill 164 61 276 164 64 276 minecraft:packed_ice
setblock 167 61 277 minecraft:snow_block
fill 168 61 275 180 61 275 minecraft:packed_ice
setblock 168 61 276 minecraft:snow_block
fill 168 61 277 168 62 277 minecraft:packed_ice
fill 169 61 276 169 64 276 minecraft:packed_ice
setblock 171 61 278 minecraft:snow_block
setblock 172 61 277 minecraft:snow_block
setblock 172 61 278 minecraft:packed_ice
setblock 173 61 276 minecraft:snow_block
fill 173 61 277 173 64 277 minecraft:packed_ice
setblock 173 61 316 minecraft:snow_block
fill 174 61 276 174 64 276 minecraft:packed_ice
setblock 174 61 315 minecraft:snow_block
fill 174 61 316 174 64 316 minecraft:packed_ice
fill 175 61 315 175 64 315 minecraft:packed_ice
setblock 176 61 278 minecraft:snow_block
setblock 176 61 279 minecraft:packed_ice
setblock 177 61 277 minecraft:snow_block
fill 177 61 278 177 63 278 minecraft:packed_ice
setblock 178 61 276 minecraft:snow_block
fill 178 61 277 178 64 277 minecraft:packed_ice
setblock 178 61 316 minecraft:snow_block
fill 179 61 276 179 64 276 minecraft:packed_ice
fill 179 61 303 179 61 304 minecraft:packed_ice
setblock 179 61 305 minecraft:snow_block
fill 179 61 306 180 62 306 minecraft:packed_ice
setblock 179 61 315 minecraft:snow_block
fill 179 61 316 179 64 316 minecraft:packed_ice
setblock 180 61 279 minecraft:snow_block
setblock 180 61 280 minecraft:packed_ice
setblock 180 61 282 minecraft:packed_ice
setblock 180 61 299 minecraft:snow_block
fill 180 61 300 180 62 300 minecraft:packed_ice
setblock 180 61 303 minecraft:packed_ice
setblock 180 61 304 minecraft:snow_block
fill 180 61 305 180 64 305 minecraft:packed_ice
fill 180 61 307 180 61 308 minecraft:packed_ice
setblock 180 61 309 minecraft:snow_block
fill 180 61 310 180 62 310 minecraft:packed_ice
fill 180 61 315 180 63 315 minecraft:packed_ice
setblock 181 61 275 minecraft:light_blue_concrete
setblock 181 61 278 minecraft:snow_block
fill 181 61 279 181 62 279 minecraft:packed_ice
setblock 181 61 283 minecraft:snow_block
fill 181 61 284 181 62 284 minecraft:packed_ice
setblock 181 61 297 minecraft:packed_ice
setblock 181 61 298 minecraft:snow_block
fill 181 61 299 181 63 299 minecraft:packed_ice
setblock 181 61 303 minecraft:snow_block
fill 181 61 304 181 64 304 minecraft:packed_ice
setblock 181 61 308 minecraft:snow_block
fill 181 61 309 181 64 309 minecraft:packed_ice
setblock 181 61 313 minecraft:snow_block
fill 181 61 314 181 62 314 minecraft:packed_ice
fill 182 61 275 183 93 275 minecraft:packed_ice
setblock 182 61 277 minecraft:snow_block
fill 182 61 278 182 63 278 minecraft:packed_ice
setblock 182 61 282 minecraft:snow_block
fill 182 61 283 182 64 283 minecraft:packed_ice
setblock 182 61 286 minecraft:packed_ice
setblock 182 61 297 minecraft:snow_block
fill 182 61 298 182 63 298 minecraft:packed_ice
setblock 182 61 302 minecraft:snow_block
fill 182 61 303 182 64 303 minecraft:packed_ice
setblock 182 61 307 minecraft:snow_block
fill 182 61 308 182 64 308 minecraft:packed_ice
setblock 182 61 312 minecraft:snow_block
fill 182 61 313 182 64 313 minecraft:packed_ice
fill 183 61 307 183 71 307 minecraft:packed_ice
fill 141 62 315 141 93 315 minecraft:packed_ice
setblock 142 62 281 minecraft:snow_block
fill 142 62 282 142 64 282 minecraft:packed_ice
setblock 142 62 286 minecraft:snow_block
fill 142 62 287 142 65 287 minecraft:packed_ice
setblock 142 62 296 minecraft:snow_block
fill 142 62 297 142 64 297 minecraft:packed_ice
setblock 142 62 301 minecraft:snow_block
fill 142 62 302 142 65 302 minecraft:packed_ice
setblock 142 62 306 minecraft:snow_block
fill 142 62 307 142 65 307 minecraft:packed_ice
setblock 142 62 311 minecraft:snow_block
setblock 142 62 312 minecraft:packed_ice
setblock 143 62 300 minecraft:snow_block
fill 143 62 301 143 64 301 minecraft:packed_ice
setblock 143 62 305 minecraft:snow_block
fill 143 62 306 143 65 306 minecraft:packed_ice
setblock 144 62 304 minecraft:snow_block
fill 144 62 311 144 68 311 minecraft:snow_block
setblock 152 62 276 minecraft:snow_block
fill 153 62 276 153 65 276 minecraft:packed_ice
fill 154 62 277 154 63 277 minecraft:packed_ice
setblock 155 62 278 minecraft:snow_block
setblock 156 62 277 minecraft:snow_block
fill 156 62 278 156 62 279 minecraft:packed_ice
setblock 157 62 276 minecraft:snow_block
fill 157 62 277 157 65 277 minecraft:packed_ice
fill 157 62 279 158 62 279 minecraft:packed_ice
setblock 157 62 316 minecraft:snow_block
fill 158 62 276 161 62 276 minecraft:packed_ice
fill 158 62 316 159 62 316 minecraft:packed_ice
setblock 159 62 279 minecraft:snow_block
setblock 160 62 278 minecraft:snow_block
setblock 160 62 279 minecraft:packed_ice
setblock 161 62 277 minecraft:snow_block
fill 161 62 278 161 63 278 minecraft:packed_ice
setblock 162 62 276 minecraft:snow_block
fill 162 62 277 165 62 277 minecraft:packed_ice
fill 163 62 276 163 64 276 minecraft:packed_ice
setblock 166 62 277 minecraft:snow_block
setblock 167 62 276 minecraft:snow_block
setblock 167 62 277 minecraft:packed_ice
fill 168 62 275 168 63 276 minecraft:packed_ice
fill 169 62 275 175 72 275 minecraft:packed_ice
setblock 171 62 277 minecraft:snow_block
setblock 172 62 276 minecraft:snow_block
fill 172 62 277 172 64 277 minecraft:packed_ice
setblock 172 62 316 minecraft:snow_block
fill 173 62 276 173 65 276 minecraft:packed_ice
fill 173 62 316 173 65 316 minecraft:packed_ice
fill 174 62 315 174 65 315 minecraft:packed_ice
setblock 175 62 278 minecraft:snow_block
setblock 176 62 275 minecraft:light_blue_concrete
setblock 176 62 277 minecraft:snow_block
fill 176 62 278 176 63 278 minecraft:packed_ice
fill 177 62 275 181 89 275 minecraft:packed_ice
setblock 177 62 276 minecraft:snow_block
fill 177 62 277 177 64 277 minecraft:packed_ice
setblock 177 62 316 minecraft:snow_block
fill 178 62 276 178 65 276 minecraft:packed_ice
setblock 178 62 315 minecraft:snow_block
fill 178 62 316 178 65 316 minecraft:packed_ice
setblock 179 62 303 minecraft:packed_ice
setblock 179 62 304 minecraft:snow_block
fill 179 62 305 179 63 305 minecraft:packed_ice
fill 179 62 315 179 63 315 minecraft:packed_ice
setblock 180 62 303 minecraft:snow_block
fill 180 62 304 180 65 304 minecraft:packed_ice
setblock 180 62 307 minecraft:packed_ice
setblock 180 62 308 minecraft:snow_block
fill 180 62 309 180 65 309 minecraft:packed_ice
setblock 181 62 277 minecraft:snow_block
setblock 181 62 278 minecraft:packed_ice
setblock 181 62 282 minecraft:snow_block
setblock 181 62 283 minecraft:packed_ice
setblock 181 62 298 minecraft:packed_ice
setblock 181 62 302 minecraft:snow_block
fill 181 62 303 181 65 303 minecraft:packed_ice
setblock 181 62 307 minecraft:snow_block
fill 181 62 308 181 65 308 minecraft:packed_ice
setblock 181 62 312 minecraft:snow_block
setblock 181 62 313 minecraft:packed_ice
setblock 182 62 276 minecraft:snow_block
fill 182 62 277 182 63 277 minecraft:packed_ice
setblock 182 62 281 minecraft:snow_block
fill 182 62 282 182 64 282 minecraft:packed_ice
setblock 182 62 286 minecraft:snow_block
setblock 182 62 296 minecraft:snow_block
setblock 182 62 297 minecraft:packed_ice
setblock 182 62 301 minecraft:snow_block
fill 182 62 302 182 65 302 minecraft:packed_ice
setblock 182 62 306 minecraft:snow_block
fill 182 62 307 182 65 307 minecraft:packed_ice
setblock 182 62 311 minecraft:snow_block
fill 182 62 312 182 65 312 minecraft:packed_ice
setblock 182 62 316 minecraft:snow_block
setblock 183 62 276 minecraft:light_blue_concrete
setblock 142 63 280 minecraft:snow_block
setblock 142 63 281 minecraft:packed_ice
setblock 142 63 285 minecraft:snow_block
fill 142 63 286 142 66 286 minecraft:packed_ice
fill 142 63 290 142 65 290 minecraft:packed_ice
setblock 142 63 295 minecraft:snow_block
setblock 142 63 296 minecraft:packed_ice
setblock 142 63 300 minecraft:snow_block
fill 142 63 301 142 66 301 minecraft:packed_ice
setblock 142 63 305 minecraft:snow_block
fill 142 63 306 142 66 306 minecraft:packed_ice
setblock 142 63 310 minecraft:snow_block
setblock 142 63 311 minecraft:packed_ice
fill 143 63 289 143 65 289 minecraft:packed_ice
fill 143 63 291 143 65 291 minecraft:packed_ice
setblock 143 63 299 minecraft:snow_block
setblock 143 63 300 minecraft:packed_ice
setblock 143 63 304 minecraft:snow_block
fill 143 63 305 143 65 305 minecraft:packed_ice
fill 144 63 290 144 65 290 minecraft:packed_ice
fill 145 63 278 145 67 278 minecraft:packed_ice
fill 146 63 277 146 67 277 minecraft:packed_ice
fill 146 63 279 146 67 279 minecraft:packed_ice
fill 147 63 278 147 67 278 minecraft:packed_ice
fill 149 63 275 151 74 275 minecraft:packed_ice
setblock 152 63 275 minecraft:light_blue_concrete
fill 153 63 275 153 93 275 minecraft:packed_ice
setblock 155 63 277 minecraft:snow_block
fill 155 63 278 156 63 278 minecraft:packed_ice
setblock 156 63 276 minecraft:snow_block
fill 156 63 277 156 66 277 minecraft:packed_ice
fill 157 63 276 160 63 276 minecraft:packed_ice
setblock 159 63 278 minecraft:snow_block
setblock 160 63 277 minecraft:snow_block
setblock 160 63 278 minecraft:packed_ice
setblock 161 63 276 minecraft:snow_block
fill 161 63 277 163 63 277 minecraft:packed_ice
fill 162 63 276 162 64 276 minecraft:packed_ice
setblock 166 63 276 minecraft:snow_block
setblock 167 63 276 minecraft:packed_ice
setblock 171 63 276 minecraft:snow_block
setblock 171 63 277 minecraft:packed_ice
setblock 171 63 316 minecraft:snow_block
fill 172 63 276 172 66 276 minecraft:packed_ice
fill 172 63 316 172 66 316 minecraft:packed_ice
setblock 174 63 278 minecraft:snow_block
setblock 175 63 277 minecraft:snow_block
setblock 175 63 278 minecraft:packed_ice
fill 176 63 275 176 93 275 minecraft:packed_ice
setblock 176 63 276 minecraft:snow_block
fill 176 63 277 176 64 277 minecraft:packed_ice
setblock 176 63 316 minecraft:snow_block
fill 177 63 276 177 66 276 minecraft:packed_ice
setblock 177 63 315 minecraft:snow_block
fill 177 63 316 177 66 316 minecraft:packed_ice
fill 178 63 315 178 64 315 minecraft:packed_ice
setblock 180 63 302 minecraft:snow_block
fill 180 63 303 180 64 303 minecraft:packed_ice
setblock 180 63 306 minecraft:packed_ice
setblock 180 63 307 minecraft:snow_block
fill 180 63 308 180 66 308 minecraft:packed_ice
setblock 181 63 276 minecraft:snow_block
setblock 181 63 281 minecraft:snow_block
setblock 181 63 301 minecraft:snow_block
fill 181 63 302 181 65 302 minecraft:packed_ice
setblock 181 63 306 minecraft:snow_block
fill 181 63 307 181 66 307 minecraft:packed_ice
setblock 181 63 311 minecraft:snow_block
setblock 181 63 312 minecraft:packed_ice
setblock 181 63 316 minecraft:snow_block
setblock 182 63 280 minecraft:snow_block
fill 182 63 281 182 64 281 minecraft:packed_ice
setblock 182 63 285 minecraft:snow_block
setblock 182 63 300 minecraft:snow_block
fill 182 63 301 182 66 301 minecraft:packed_ice
setblock 182 63 305 minecraft:snow_block
fill 182 63 306 182 66 306 minecraft:packed_ice
setblock 182 63 310 minecraft:snow_block
fill 182 63 311 182 66 311 minecraft:packed_ice
setblock 182 63 315 minecraft:snow_block
setblock 182 63 316 minecraft:packed_ice
fill 183 63 276 183 74 276 minecraft:packed_ice
setblock 142 64 284 minecraft:snow_block
fill 142 64 285 142 67 285 minecraft:packed_ice
fill 142 64 289 142 65 289 minecraft:packed_ice
fill 142 64 291 142 65 291 minecraft:packed_ice
setblock 142 64 299 minecraft:snow_block
fill 142 64 300 142 66 300 minecraft:packed_ice
setblock 142 64 304 minecraft:snow_block
fill 142 64 305 142 67 305 minecraft:packed_ice
setblock 142 64 309 minecraft:snow_block
fill 142 64 310 142 65 310 minecraft:packed_ice
setblock 143 64 303 minecraft:snow_block
fill 143 64 304 143 65 304 minecraft:packed_ice
setblock 144 64 278 minecraft:light[level=15]
setblock 144 64 286 minecraft:light[level=15]
fill 144 64 289 144 65 289 minecraft:packed_ice
fill 144 64 291 144 65 291 minecraft:packed_ice
setblock 144 64 294 minecraft:light[level=15]
setblock 144 64 302 minecraft:light[level=15]
setblock 144 64 310 minecraft:light[level=15]
fill 147 64 294 147 65 294 minecraft:blue_ice
fill 152 64 275 152 93 275 minecraft:packed_ice
setblock 152 64 278 minecraft:light[level=15]
setblock 152 64 286 minecraft:light[level=15]
setblock 152 64 294 minecraft:light[level=15]
setblock 152 64 302 minecraft:light[level=15]
setblock 152 64 310 minecraft:light[level=15]
setblock 154 64 277 minecraft:snow_block
setblock 155 64 276 minecraft:snow_block
fill 155 64 277 155 65 277 minecraft:packed_ice
fill 156 64 276 159 64 276 minecraft:packed_ice
setblock 156 64 278 minecraft:packed_ice
setblock 158 64 278 minecraft:snow_block
setblock 159 64 277 minecraft:snow_block
setblock 160 64 276 minecraft:snow_block
fill 160 64 277 161 64 277 minecraft:packed_ice
setblock 160 64 278 minecraft:light[level=15]
setblock 160 64 286 minecraft:light[level=15]
setblock 160 64 294 minecraft:light[level=15]
setblock 160 64 302 minecraft:light[level=15]
setblock 160 64 310 minecraft:light[level=15]
fill 161 64 276 161 65 276 minecraft:packed_ice
fill 168 64 275 168 90 275 minecraft:packed_ice
setblock 168 64 278 minecraft:light[level=15]
setblock 168 64 286 minecraft:light[level=15]
setblock 168 64 294 minecraft:light[level=15]
setblock 168 64 302 minecraft:light[level=15]
setblock 168 64 310 minecraft:light[level=15]
setblock 170 64 276 minecraft:snow_block
fill 171 64 276 171 67 276 minecraft:packed_ice
fill 171 64 316 171 67 316 minecraft:packed_ice
setblock 174 64 277 minecraft:snow_block
setblock 175 64 276 minecraft:snow_block
fill 175 64 277 175 65 277 minecraft:packed_ice
setblock 175 64 316 minecraft:snow_block
fill 176 64 276 176 67 276 minecraft:packed_ice
setblock 176 64 278 minecraft:light[level=15]
setblock 176 64 286 minecraft:light[level=15]
setblock 176 64 294 minecraft:light[level=15]
setblock 176 64 302 minecraft:light[level=15]
setblock 176 64 310 minecraft:light[level=15]
setblock 176 64 315 minecraft:snow_block
fill 176 64 316 176 67 316 minecraft:packed_ice
fill 177 64 315 177 67 315 minecraft:packed_ice
setblock 180 64 276 minecraft:snow_block
setblock 180 64 302 minecraft:packed_ice
setblock 180 64 306 minecraft:snow_block
fill 180 64 307 180 67 307 minecraft:packed_ice
setblock 180 64 316 minecraft:snow_block
setblock 181 64 300 minecraft:snow_block
setblock 181 64 301 minecraft:packed_ice
setblock 181 64 305 minecraft:snow_block
fill 181 64 306 181 67 306 minecraft:packed_ice
setblock 181 64 310 minecraft:snow_block
fill 181 64 311 181 67 311 minecraft:packed_ice
setblock 181 64 316 minecraft:packed_ice
setblock 182 64 284 minecraft:snow_block
setblock 182 64 299 minecraft:snow_block
fill 182 64 300 182 65 300 minecraft:packed_ice
setblock 182 64 304 minecraft:snow_block
fill 182 64 305 182 67 305 minecraft:packed_ice
setblock 182 64 309 minecraft:snow_block
fill 182 64 310 182 67 310 minecraft:packed_ice
fill 141 65 275 141 90 275 minecraft:packed_ice
setblock 141 65 276 minecraft:light_blue_concrete
setblock 141 65 303 minecraft:light_blue_concrete
fill 141 65 304 141 86 306 minecraft:packed_ice
setblock 142 65 283 minecraft:snow_block
fill 142 65 284 142 66 284 minecraft:packed_ice
setblock 142 65 298 minecraft:snow_block
setblock 142 65 299 minecraft:packed_ice
setblock 142 65 303 minecraft:snow_block
fill 142 65 304 142 68 304 minecraft:packed_ice
setblock 142 65 308 minecraft:snow_block
fill 142 65 309 142 68 309 minecraft:packed_ice
setblock 143 65 303 minecraft:packed_ice
fill 145 65 277 145 67 277 minecraft:packed_ice
fill 145 65 279 145 67 279 minecraft:packed_ice
fill 147 65 277 147 67 277 minecraft:packed_ice
fill 147 65 279 147 67 279 minecraft:packed_ice
setblock 154 65 276 minecraft:snow_block
fill 155 65 276 158 65 276 minecraft:packed_ice
setblock 158 65 277 minecraft:snow_block
setblock 159 65 276 minecraft:snow_block
setblock 159 65 277 minecraft:packed_ice
fill 160 65 276 160 66 276 minecraft:packed_ice
fill 170 65 276 170 68 276 minecraft:packed_ice
setblock 174 65 276 minecraft:snow_block
setblock 174 65 277 minecraft:packed_ice
setblock 174 65 316 minecraft:snow_block
fill 175 65 276 175 68 276 minecraft:packed_ice
setblock 175 65 315 minecraft:snow_block
fill 175 65 316 175 68 316 minecraft:packed_ice
fill 176 65 315 176 68 315 minecraft:packed_ice
setblock 179 65 316 minecraft:snow_block
setblock 180 65 305 minecraft:snow_block
fill 180 65 306 180 68 306 minecraft:packed_ice
setblock 180 65 316 minecraft:packed_ice
setblock 181 65 304 minecraft:snow_block
fill 181 65 305 181 68 305 minecraft:packed_ice
setblock 181 65 309 minecraft:snow_block
fill 181 65 310 181 68 310 minecraft:packed_ice
setblock 182 65 303 minecraft:snow_block
fill 182 65 304 182 68 304 minecraft:packed_ice
setblock 182 65 308 minecraft:snow_block
fill 182 65 309 182 68 309 minecraft:packed_ice
setblock 183 65 284 minecraft:white_concrete
fill 141 66 276 141 77 276 minecraft:packed_ice
fill 141 66 278 141 70 280 minecraft:packed_ice
setblock 141 66 281 minecraft:light_blue_concrete
fill 141 66 282 141 93 283 minecraft:packed_ice
fill 141 66 303 142 69 303 minecraft:packed_ice
fill 141 66 308 141 81 310 minecraft:packed_ice
setblock 141 66 311 minecraft:light_blue_concrete
setblock 142 66 287 minecraft:snow_block
fill 142 66 288 142 69 288 minecraft:packed_ice
setblock 142 66 302 minecraft:snow_block
setblock 142 66 307 minecraft:snow_block
fill 142 66 308 142 69 308 minecraft:packed_ice
setblock 144 66 278 minecraft:light[level=12]
setblock 144 66 285 minecraft:light[level=12]
setblock 144 66 292 minecraft:light[level=12]
setblock 144 66 299 minecraft:light[level=12]
setblock 144 66 306 minecraft:light[level=12]
setblock 144 66 313 minecraft:light[level=12]
setblock 145 66 311 minecraft:packed_ice
fill 145 66 313 145 67 313 minecraft:packed_ice
fill 147 66 294 147 75 294 minecraft:packed_ice
fill 147 66 313 147 67 313 minecraft:packed_ice
setblock 151 66 278 minecraft:light[level=12]
setblock 151 66 285 minecraft:light[level=12]
setblock 151 66 292 minecraft:light[level=12]
setblock 151 66 299 minecraft:light[level=12]
setblock 151 66 306 minecraft:light[level=12]
setblock 151 66 313 minecraft:light[level=12]
setblock 153 66 276 minecraft:snow_block
fill 154 66 276 157 66 276 minecraft:packed_ice
setblock 157 66 277 minecraft:snow_block
setblock 158 66 276 minecraft:snow_block
setblock 158 66 278 minecraft:light[level=12]
setblock 158 66 285 minecraft:light[level=12]
setblock 158 66 292 minecraft:light[level=12]
setblock 158 66 299 minecraft:light[level=12]
setblock 158 66 306 minecraft:light[level=12]
setblock 158 66 313 minecraft:light[level=12]
fill 159 66 276 159 69 276 minecraft:packed_ice
setblock 165 66 278 minecraft:light[level=12]
setblock 165 66 285 minecraft:light[level=12]
setblock 165 66 292 minecraft:light[level=12]
setblock 165 66 299 minecraft:light[level=12]
setblock 165 66 306 minecraft:light[level=12]
setblock 165 66 313 minecraft:light[level=12]
setblock 172 66 278 minecraft:light[level=12]
setblock 172 66 285 minecraft:light[level=12]
setblock 172 66 292 minecraft:light[level=12]
setblock 172 66 299 minecraft:light[level=12]
setblock 172 66 306 minecraft:light[level=12]
setblock 172 66 313 minecraft:light[level=12]
setblock 173 66 276 minecraft:snow_block
setblock 173 66 315 minecraft:packed_ice
setblock 173 66 316 minecraft:snow_block
fill 174 66 276 174 69 276 minecraft:packed_ice
setblock 174 66 315 minecraft:snow_block
fill 174 66 316 174 69 316 minecraft:packed_ice
fill 175 66 315 175 69 315 minecraft:packed_ice
setblock 178 66 316 minecraft:snow_block
setblock 179 66 278 minecraft:light[level=12]
setblock 179 66 285 minecraft:light[level=12]
setblock 179 66 292 minecraft:light[level=12]
setblock 179 66 299 minecraft:light[level=12]
setblock 179 66 306 minecraft:light[level=12]
setblock 179 66 313 minecraft:light[level=12]
fill 179 66 316 179 69 316 minecraft:packed_ice
setblock 180 66 305 minecraft:packed_ice
setblock 181 66 303 minecraft:snow_block
fill 181 66 304 181 69 304 minecraft:packed_ice
setblock 181 66 308 minecraft:snow_block
fill 181 66 309 181 69 309 minecraft:packed_ice
setblock 182 66 302 minecraft:snow_block
fill 182 66 303 182 69 303 minecraft:packed_ice
setblock 182 66 307 minecraft:snow_block
fill 182 66 308 182 69 308 minecraft:packed_ice
setblock 182 66 312 minecraft:snow_block
fill 183 66 284 183 93 284 minecraft:packed_ice
fill 141 67 281 141 91 281 minecraft:packed_ice
fill 141 67 311 141 93 311 minecraft:packed_ice
setblock 142 67 286 minecraft:snow_block
fill 142 67 287 142 70 287 minecraft:packed_ice
fill 142 67 289 142 68 289 minecraft:packed_ice
setblock 142 67 301 minecraft:snow_block
fill 142 67 302 142 69 302 minecraft:packed_ice
setblock 142 67 306 minecraft:snow_block
fill 142 67 307 142 70 307 minecraft:packed_ice
fill 143 67 311 143 68 311 minecraft:snow_block
fill 144 67 310 144 68 310 minecraft:snow_block
fill 144 67 312 144 68 312 minecraft:snow_block
fill 145 67 311 145 69 311 minecraft:snow_block
fill 146 67 294 146 75 294 minecraft:packed_ice
fill 153 67 276 156 67 276 minecraft:packed_ice
setblock 157 67 276 minecraft:snow_block
fill 158 67 276 158 70 276 minecraft:packed_ice
fill 170 67 316 170 68 316 minecraft:packed_ice
setblock 172 67 276 minecraft:snow_block
setblock 172 67 315 minecraft:packed_ice
setblock 172 67 316 minecraft:snow_block
fill 173 67 276 173 70 276 minecraft:packed_ice
setblock 173 67 315 minecraft:snow_block
fill 173 67 316 173 70 316 minecraft:packed_ice
fill 174 67 315 174 70 315 minecraft:packed_ice
setblock 177 67 316 minecraft:snow_block
fill 178 67 316 178 70 316 minecraft:packed_ice
setblock 180 67 308 minecraft:snow_block
setblock 181 67 303 minecraft:packed_ice
setblock 181 67 307 minecraft:snow_block
fill 181 67 308 181 70 308 minecraft:packed_ice
setblock 182 67 301 minecraft:snow_block
fill 182 67 302 182 70 302 minecraft:packed_ice
setblock 182 67 306 minecraft:snow_block
fill 182 67 307 182 70 307 minecraft:packed_ice
setblock 182 67 311 minecraft:snow_block
fill 182 67 312 182 70 312 minecraft:packed_ice
setblock 141 68 287 minecraft:light_blue_concrete
fill 141 68 288 141 93 288 minecraft:packed_ice
setblock 142 68 285 minecraft:snow_block
fill 142 68 286 142 71 286 minecraft:packed_ice
setblock 142 68 290 minecraft:snow_block
fill 142 68 291 142 71 291 minecraft:packed_ice
setblock 142 68 305 minecraft:snow_block
fill 142 68 306 142 71 306 minecraft:packed_ice
setblock 142 68 310 minecraft:snow_block
fill 145 68 313 145 69 313 minecraft:snow_block
fill 146 68 293 147 75 293 minecraft:packed_ice
fill 147 68 313 147 69 313 minecraft:snow_block
fill 150 68 311 150 78 311 minecraft:snow_block
fill 152 68 276 155 68 276 minecraft:packed_ice
setblock 156 68 276 minecraft:snow_block
fill 157 68 276 157 71 276 minecraft:packed_ice
fill 157 68 300 157 105 300 minecraft:snow_block
fill 169 68 316 169 69 316 minecraft:packed_ice
setblock 171 68 276 minecraft:snow_block
setblock 171 68 315 minecraft:packed_ice
setblock 171 68 316 minecraft:snow_block
fill 172 68 276 172 71 276 minecraft:packed_ice
setblock 172 68 315 minecraft:snow_block
fill 172 68 316 172 71 316 minecraft:packed_ice
fill 173 68 315 173 71 315 minecraft:packed_ice
setblock 173 68 317 minecraft:light_blue_concrete
fill 174 68 314 175 70 314 minecraft:packed_ice
setblock 176 68 276 minecraft:snow_block
setblock 176 68 316 minecraft:snow_block
setblock 177 68 315 minecraft:snow_block
fill 177 68 316 177 71 316 minecraft:packed_ice
setblock 180 68 307 minecraft:snow_block
fill 180 68 308 180 70 309 minecraft:packed_ice
setblock 181 68 306 minecraft:snow_block
fill 181 68 307 181 71 307 minecraft:packed_ice
setblock 181 68 311 minecraft:snow_block
setblock 182 68 305 minecraft:snow_block
fill 182 68 306 182 71 306 minecraft:packed_ice
setblock 182 68 310 minecraft:snow_block
fill 182 68 311 182 71 311 minecraft:packed_ice
fill 182 68 313 182 69 313 minecraft:packed_ice
fill 141 69 287 141 93 287 minecraft:packed_ice
setblock 142 69 284 minecraft:snow_block
fill 142 69 285 142 72 285 minecraft:packed_ice
setblock 142 69 289 minecraft:snow_block
fill 142 69 290 142 72 290 minecraft:packed_ice
fill 142 69 292 142 69 293 minecraft:packed_ice
setblock 142 69 304 minecraft:snow_block
fill 142 69 305 142 72 305 minecraft:packed_ice
setblock 142 69 309 minecraft:snow_block
fill 142 69 310 142 72 310 minecraft:packed_ice
fill 145 69 294 145 75 294 minecraft:packed_ice
fill 146 69 295 147 75 295 minecraft:packed_ice
fill 148 69 293 148 75 294 minecraft:packed_ice
setblock 150 69 317 minecraft:light_blue_concrete
fill 151 69 276 154 69 276 minecraft:packed_ice
fill 153 69 316 154 69 316 minecraft:packed_ice
setblock 154 69 277 minecraft:snow_block
setblock 155 69 276 minecraft:snow_block
fill 155 69 277 155 72 277 minecraft:packed_ice
setblock 155 69 316 minecraft:snow_block
fill 156 69 276 156 72 276 minecraft:packed_ice
fill 156 69 316 156 72 316 minecraft:packed_ice
fill 157 69 275 157 91 275 minecraft:packed_ice
setblock 158 69 275 minecraft:white_concrete
fill 159 69 275 159 93 275 minecraft:packed_ice
setblock 160 69 275 minecraft:white_concrete
fill 167 69 316 168 70 316 minecraft:packed_ice
setblock 169 69 276 minecraft:packed_ice
fill 169 69 315 170 69 315 minecraft:packed_ice
setblock 170 69 276 minecraft:snow_block
setblock 170 69 316 minecraft:snow_block
fill 171 69 276 171 72 276 minecraft:packed_ice
setblock 171 69 314 minecraft:packed_ice
setblock 171 69 315 minecraft:snow_block
fill 171 69 316 171 72 316 minecraft:packed_ice
setblock 172 69 314 minecraft:snow_block
fill 172 69 315 172 72 315 minecraft:packed_ice
fill 173 69 314 173 72 314 minecraft:packed_ice
fill 173 69 317 173 89 317 minecraft:packed_ice
setblock 175 69 276 minecraft:snow_block
setblock 175 69 316 minecraft:snow_block
setblock 176 69 314 minecraft:packed_ice
setblock 176 69 315 minecraft:snow_block
fill 176 69 316 176 72 316 minecraft:packed_ice
fill 177 69 315 178 71 315 minecraft:packed_ice
fill 180 69 307 180 70 307 minecraft:packed_ice
setblock 181 69 305 minecraft:snow_block
fill 181 69 306 181 72 306 minecraft:packed_ice
setblock 181 69 310 minecraft:snow_block
fill 181 69 311 181 72 311 minecraft:packed_ice
setblock 182 69 304 minecraft:snow_block
fill 182 69 305 182 72 305 minecraft:packed_ice
setblock 182 69 309 minecraft:snow_block
fill 182 69 310 182 72 310 minecraft:packed_ice
fill 141 70 303 141 93 303 minecraft:packed_ice
fill 142 70 284 142 73 284 minecraft:packed_ice
setblock 142 70 288 minecraft:snow_block
fill 142 70 289 143 72 289 minecraft:packed_ice
setblock 142 70 292 minecraft:packed_ice
setblock 142 70 293 minecraft:snow_block
fill 142 70 294 142 73 294 minecraft:packed_ice
setblock 142 70 303 minecraft:snow_block
fill 142 70 304 142 72 304 minecraft:packed_ice
setblock 142 70 308 minecraft:snow_block
fill 142 70 309 142 73 309 minecraft:packed_ice
fill 142 70 311 142 71 311 minecraft:packed_ice
setblock 143 70 287 minecraft:snow_block
fill 143 70 288 143 73 288 minecraft:packed_ice
fill 143 70 290 143 71 290 minecraft:packed_ice
setblock 145 70 275 minecraft:white_concrete
fill 145 70 293 145 76 293 minecraft:packed_ice
fill 145 70 295 145 75 295 minecraft:packed_ice
fill 146 70 292 148 75 292 minecraft:packed_ice
fill 148 70 295 148 75 295 minecraft:packed_ice
setblock 149 70 317 minecraft:light_blue_concrete
fill 150 70 276 153 70 276 minecraft:packed_ice
fill 150 70 317 150 75 317 minecraft:packed_ice
fill 151 70 316 153 70 316 minecraft:packed_ice
setblock 152 70 277 minecraft:packed_ice
setblock 153 70 277 minecraft:snow_block
setblock 154 70 276 minecraft:snow_block
fill 154 70 277 154 73 277 minecraft:packed_ice
setblock 154 70 316 minecraft:snow_block
setblock 154 70 317 minecraft:white_concrete
fill 155 70 276 155 73 276 minecraft:packed_ice
fill 155 70 316 155 73 316 minecraft:packed_ice
fill 156 70 277 156 71 277 minecraft:packed_ice
fill 157 70 316 158 70 316 minecraft:packed_ice
fill 158 70 275 158 89 275 minecraft:packed_ice
setblock 159 70 276 minecraft:snow_block
fill 159 70 311 159 71 312 minecraft:snow_block
fill 160 70 275 160 93 275 minecraft:packed_ice
fill 165 70 316 166 72 316 minecraft:packed_ice
fill 167 70 276 168 70 276 minecraft:packed_ice
fill 168 70 315 169 70 315 minecraft:packed_ice
setblock 169 70 276 minecraft:snow_block
fill 169 70 314 170 70 314 minecraft:packed_ice
setblock 169 70 316 minecraft:snow_block
fill 170 70 276 170 73 276 minecraft:packed_ice
setblock 170 70 315 minecraft:snow_block
fill 170 70 316 170 73 316 minecraft:packed_ice
setblock 171 70 314 minecraft:snow_block
fill 171 70 315 171 73 315 minecraft:packed_ice
schedule function dropper:buildpart/63_2 1t
