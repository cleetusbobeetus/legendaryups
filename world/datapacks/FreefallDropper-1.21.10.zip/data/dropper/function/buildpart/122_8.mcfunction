setblock 126 191 511 minecraft:smooth_basalt
setblock 126 191 551 minecraft:smooth_basalt
fill 127 191 511 127 194 511 minecraft:blackstone
setblock 127 191 550 minecraft:smooth_basalt
fill 127 191 551 127 194 551 minecraft:blackstone
setblock 128 191 550 minecraft:blackstone
setblock 131 191 511 minecraft:smooth_basalt
setblock 131 191 551 minecraft:smooth_basalt
fill 132 191 511 132 194 511 minecraft:blackstone
setblock 132 191 550 minecraft:smooth_basalt
fill 132 191 551 132 194 551 minecraft:blackstone
setblock 133 191 549 minecraft:smooth_basalt
fill 133 191 550 133 194 550 minecraft:blackstone
setblock 134 191 548 minecraft:smooth_basalt
fill 134 191 549 134 194 549 minecraft:blackstone
setblock 135 191 512 minecraft:smooth_basalt
fill 135 191 513 135 193 514 minecraft:blackstone
setblock 135 191 527 minecraft:smooth_basalt
fill 135 191 528 135 194 528 minecraft:blackstone
setblock 135 191 532 minecraft:smooth_basalt
fill 135 191 533 135 194 533 minecraft:blackstone
setblock 135 191 537 minecraft:smooth_basalt
fill 135 191 538 135 194 538 minecraft:blackstone
setblock 135 191 542 minecraft:smooth_basalt
fill 135 191 543 135 194 543 minecraft:blackstone
setblock 135 191 547 minecraft:smooth_basalt
fill 135 191 548 135 194 548 minecraft:blackstone
fill 94 192 510 94 193 511 minecraft:blackstone
setblock 94 192 512 minecraft:basalt
setblock 94 192 520 minecraft:basalt
setblock 94 192 527 minecraft:basalt
fill 94 192 537 94 195 538 minecraft:blackstone
setblock 94 192 539 minecraft:basalt
fill 94 192 540 94 195 541 minecraft:blackstone
setblock 94 192 542 minecraft:basalt
setblock 94 192 544 minecraft:basalt
fill 94 192 545 94 195 547 minecraft:blackstone
fill 94 192 550 94 192 551 minecraft:basalt
fill 94 192 552 94 195 552 minecraft:blackstone
setblock 95 192 511 minecraft:smooth_basalt
fill 95 192 512 95 194 513 minecraft:blackstone
setblock 95 192 526 minecraft:smooth_basalt
fill 95 192 527 95 195 527 minecraft:blackstone
setblock 95 192 531 minecraft:smooth_basalt
fill 95 192 532 95 195 532 minecraft:blackstone
setblock 95 192 536 minecraft:smooth_basalt
fill 95 192 537 95 195 537 minecraft:blackstone
setblock 95 192 541 minecraft:smooth_basalt
fill 95 192 542 95 192 545 minecraft:blackstone
setblock 95 192 546 minecraft:smooth_basalt
fill 95 192 547 95 195 547 minecraft:blackstone
setblock 95 192 551 minecraft:smooth_basalt
fill 96 192 511 96 195 511 minecraft:blackstone
setblock 96 192 525 minecraft:smooth_basalt
fill 96 192 526 96 195 526 minecraft:blackstone
setblock 96 192 530 minecraft:smooth_basalt
fill 96 192 531 96 195 531 minecraft:blackstone
setblock 96 192 535 minecraft:smooth_basalt
fill 96 192 536 96 195 536 minecraft:blackstone
setblock 96 192 540 minecraft:smooth_basalt
setblock 96 192 545 minecraft:smooth_basalt
fill 96 192 546 96 193 546 minecraft:blackstone
setblock 96 192 550 minecraft:smooth_basalt
fill 96 192 551 96 195 551 minecraft:blackstone
setblock 97 192 529 minecraft:smooth_basalt
fill 97 192 530 97 195 530 minecraft:blackstone
setblock 97 192 534 minecraft:smooth_basalt
fill 97 192 535 97 195 535 minecraft:blackstone
fill 97 192 550 97 195 550 minecraft:blackstone
setblock 98 192 533 minecraft:smooth_basalt
setblock 99 192 552 minecraft:basalt
setblock 100 192 511 minecraft:smooth_basalt
setblock 100 192 551 minecraft:smooth_basalt
fill 100 192 552 100 195 552 minecraft:blackstone
fill 101 192 511 101 195 511 minecraft:blackstone
fill 101 192 551 101 194 551 minecraft:blackstone
setblock 101 192 552 minecraft:basalt
fill 106 192 552 107 195 552 minecraft:blackstone
setblock 108 192 552 minecraft:basalt
fill 109 192 552 113 192 552 minecraft:blackstone
setblock 110 192 511 minecraft:smooth_basalt
fill 111 192 511 111 195 511 minecraft:blackstone
fill 112 192 551 114 192 551 minecraft:blackstone
setblock 113 192 512 minecraft:blackstone
setblock 114 192 512 minecraft:smooth_basalt
setblock 114 192 552 minecraft:basalt
setblock 115 192 511 minecraft:smooth_basalt
fill 115 192 512 115 195 512 minecraft:blackstone
setblock 115 192 550 minecraft:blackstone
setblock 115 192 551 minecraft:smooth_basalt
fill 115 192 552 116 193 552 minecraft:blackstone
fill 116 192 511 116 195 511 minecraft:blackstone
setblock 116 192 550 minecraft:smooth_basalt
fill 116 192 551 116 195 551 minecraft:blackstone
setblock 117 192 510 minecraft:basalt
fill 117 192 550 117 195 550 minecraft:blackstone
fill 118 192 510 124 192 510 minecraft:blackstone
setblock 118 192 513 minecraft:smooth_basalt
setblock 119 192 512 minecraft:smooth_basalt
fill 119 192 513 119 195 513 minecraft:blackstone
setblock 120 192 511 minecraft:smooth_basalt
fill 120 192 512 120 195 512 minecraft:blackstone
setblock 120 192 551 minecraft:smooth_basalt
fill 121 192 511 121 195 511 minecraft:blackstone
setblock 121 192 550 minecraft:smooth_basalt
fill 121 192 551 124 192 551 minecraft:blackstone
fill 122 192 550 125 192 550 minecraft:blackstone
setblock 124 192 512 minecraft:smooth_basalt
fill 124 192 552 124 193 552 minecraft:basalt
setblock 125 192 510 minecraft:basalt
setblock 125 192 511 minecraft:smooth_basalt
setblock 125 192 551 minecraft:smooth_basalt
fill 126 192 510 126 195 511 minecraft:blackstone
fill 126 192 551 126 195 551 minecraft:blackstone
fill 127 192 510 128 193 510 minecraft:blackstone
fill 130 192 510 134 192 510 minecraft:blackstone
setblock 130 192 511 minecraft:smooth_basalt
setblock 130 192 551 minecraft:smooth_basalt
fill 131 192 511 131 195 511 minecraft:blackstone
setblock 131 192 550 minecraft:smooth_basalt
fill 131 192 551 131 195 551 minecraft:blackstone
fill 132 192 550 132 195 550 minecraft:blackstone
setblock 134 192 547 minecraft:smooth_basalt
fill 134 192 548 134 195 548 minecraft:blackstone
setblock 135 192 510 minecraft:basalt
setblock 135 192 511 minecraft:smooth_basalt
fill 135 192 512 135 195 512 minecraft:blackstone
setblock 135 192 526 minecraft:smooth_basalt
fill 135 192 527 135 195 527 minecraft:blackstone
setblock 135 192 531 minecraft:smooth_basalt
fill 135 192 532 135 195 532 minecraft:blackstone
setblock 135 192 535 minecraft:blackstone
setblock 135 192 536 minecraft:smooth_basalt
fill 135 192 537 136 195 537 minecraft:blackstone
setblock 135 192 541 minecraft:smooth_basalt
fill 135 192 542 135 195 542 minecraft:blackstone
setblock 135 192 546 minecraft:smooth_basalt
fill 135 192 547 135 195 547 minecraft:blackstone
setblock 135 192 551 minecraft:smooth_basalt
fill 136 192 522 136 195 522 minecraft:blackstone
fill 136 192 523 136 193 523 minecraft:basalt
setblock 136 192 526 minecraft:basalt
fill 136 192 531 136 195 531 minecraft:blackstone
fill 136 192 532 136 192 533 minecraft:basalt
fill 136 192 534 136 195 534 minecraft:blackstone
setblock 136 192 536 minecraft:basalt
setblock 136 192 543 minecraft:basalt
fill 94 193 512 94 196 512 minecraft:blackstone
fill 94 193 520 94 195 520 minecraft:blackstone
fill 94 193 527 94 195 530 minecraft:blackstone
setblock 94 193 531 minecraft:basalt
fill 94 193 532 94 195 533 minecraft:blackstone
setblock 94 193 534 minecraft:basalt
fill 94 193 535 94 195 535 minecraft:blackstone
setblock 94 193 539 minecraft:blackstone
fill 94 193 542 95 193 542 minecraft:blackstone
fill 94 193 544 95 193 544 minecraft:blackstone
setblock 94 193 550 minecraft:basalt
fill 94 193 551 95 195 551 minecraft:blackstone
setblock 95 193 510 minecraft:basalt
fill 95 193 511 95 196 511 minecraft:blackstone
setblock 95 193 514 minecraft:blackstone
setblock 95 193 525 minecraft:smooth_basalt
fill 95 193 526 95 196 526 minecraft:blackstone
setblock 95 193 530 minecraft:smooth_basalt
fill 95 193 531 95 196 531 minecraft:blackstone
setblock 95 193 535 minecraft:smooth_basalt
fill 95 193 536 95 196 536 minecraft:blackstone
setblock 95 193 540 minecraft:smooth_basalt
fill 95 193 541 95 196 541 minecraft:blackstone
fill 95 193 543 95 194 543 minecraft:blackstone
setblock 95 193 545 minecraft:smooth_basalt
fill 95 193 546 95 196 546 minecraft:blackstone
setblock 95 193 550 minecraft:smooth_basalt
fill 95 193 552 96 195 552 minecraft:blackstone
fill 96 193 525 96 196 525 minecraft:blackstone
setblock 96 193 529 minecraft:smooth_basalt
fill 96 193 530 96 196 530 minecraft:blackstone
setblock 96 193 534 minecraft:smooth_basalt
fill 96 193 535 96 196 535 minecraft:blackstone
setblock 96 193 539 minecraft:smooth_basalt
fill 96 193 540 96 196 540 minecraft:blackstone
setblock 96 193 549 minecraft:smooth_basalt
fill 96 193 550 96 196 550 minecraft:blackstone
fill 97 193 510 100 195 510 minecraft:blackstone
setblock 97 193 528 minecraft:smooth_basalt
fill 97 193 529 97 196 529 minecraft:blackstone
setblock 97 193 533 minecraft:smooth_basalt
fill 97 193 534 97 196 534 minecraft:blackstone
setblock 97 193 537 minecraft:blackstone
setblock 97 193 552 minecraft:basalt
setblock 98 193 532 minecraft:smooth_basalt
fill 98 193 533 98 196 533 minecraft:blackstone
setblock 99 193 511 minecraft:smooth_basalt
setblock 99 193 551 minecraft:smooth_basalt
fill 99 193 552 99 195 552 minecraft:blackstone
fill 100 193 511 100 196 511 minecraft:blackstone
fill 100 193 551 100 196 551 minecraft:blackstone
setblock 101 193 510 minecraft:basalt
fill 101 193 552 101 195 552 minecraft:blackstone
fill 102 193 510 103 195 510 minecraft:blackstone
fill 105 193 510 108 193 510 minecraft:blackstone
fill 108 193 552 109 195 552 minecraft:blackstone
setblock 109 193 510 minecraft:basalt
setblock 109 193 511 minecraft:smooth_basalt
fill 110 193 510 110 196 511 minecraft:blackstone
setblock 110 193 552 minecraft:basalt
fill 111 193 552 111 195 552 minecraft:blackstone
fill 112 193 510 112 194 510 minecraft:basalt
setblock 112 193 512 minecraft:blackstone
fill 112 193 551 113 193 551 minecraft:blackstone
fill 112 193 552 112 194 552 minecraft:basalt
fill 113 193 510 119 195 510 minecraft:blackstone
setblock 113 193 512 minecraft:smooth_basalt
fill 113 193 552 114 195 552 minecraft:blackstone
setblock 114 193 511 minecraft:smooth_basalt
fill 114 193 512 114 195 513 minecraft:blackstone
setblock 114 193 551 minecraft:smooth_basalt
fill 115 193 511 115 196 511 minecraft:blackstone
fill 115 193 513 115 194 513 minecraft:blackstone
setblock 115 193 550 minecraft:smooth_basalt
fill 115 193 551 115 196 551 minecraft:blackstone
fill 116 193 550 116 196 550 minecraft:blackstone
setblock 117 193 512 minecraft:blackstone
setblock 117 193 513 minecraft:smooth_basalt
setblock 118 193 512 minecraft:smooth_basalt
fill 118 193 513 118 196 513 minecraft:blackstone
setblock 118 193 552 minecraft:blackstone
setblock 119 193 511 minecraft:smooth_basalt
fill 119 193 512 119 196 512 minecraft:blackstone
setblock 119 193 551 minecraft:smooth_basalt
setblock 119 193 552 minecraft:basalt
setblock 120 193 510 minecraft:basalt
fill 120 193 511 120 196 511 minecraft:blackstone
setblock 120 193 550 minecraft:smooth_basalt
fill 120 193 551 120 195 552 minecraft:blackstone
fill 121 193 510 125 193 510 minecraft:blackstone
fill 121 193 550 123 193 551 minecraft:blackstone
setblock 121 193 552 minecraft:basalt
setblock 122 193 552 minecraft:blackstone
setblock 123 193 512 minecraft:smooth_basalt
setblock 124 193 511 minecraft:smooth_basalt
fill 124 193 512 124 196 512 minecraft:blackstone
setblock 124 193 550 minecraft:blackstone
setblock 124 193 551 minecraft:smooth_basalt
fill 125 193 511 125 196 511 minecraft:blackstone
fill 125 193 551 125 196 551 minecraft:blackstone
setblock 129 193 511 minecraft:smooth_basalt
setblock 129 193 551 minecraft:smooth_basalt
fill 130 193 510 130 195 511 minecraft:blackstone
setblock 130 193 550 minecraft:smooth_basalt
fill 130 193 551 130 196 551 minecraft:blackstone
setblock 131 193 510 minecraft:basalt
fill 131 193 550 131 196 550 minecraft:blackstone
fill 132 193 510 135 195 510 minecraft:blackstone
setblock 132 193 552 minecraft:basalt
fill 133 193 552 134 195 552 minecraft:blackstone
setblock 134 193 511 minecraft:smooth_basalt
fill 134 193 512 134 196 512 minecraft:blackstone
setblock 134 193 530 minecraft:blackstone
setblock 134 193 531 minecraft:smooth_basalt
fill 134 193 532 134 193 535 minecraft:blackstone
setblock 134 193 546 minecraft:smooth_basalt
fill 134 193 547 134 196 547 minecraft:blackstone
setblock 134 193 551 minecraft:smooth_basalt
fill 135 193 511 135 196 511 minecraft:blackstone
setblock 135 193 515 minecraft:smooth_basalt
fill 135 193 526 136 195 526 minecraft:blackstone
setblock 135 193 530 minecraft:smooth_basalt
fill 135 193 531 135 196 531 minecraft:blackstone
setblock 135 193 535 minecraft:smooth_basalt
fill 135 193 536 136 195 536 minecraft:blackstone
setblock 135 193 540 minecraft:smooth_basalt
fill 135 193 541 135 196 541 minecraft:blackstone
setblock 135 193 545 minecraft:smooth_basalt
fill 135 193 546 135 196 546 minecraft:blackstone
setblock 135 193 550 minecraft:smooth_basalt
fill 135 193 551 135 196 551 minecraft:blackstone
fill 136 193 532 136 195 533 minecraft:blackstone
fill 136 193 543 136 195 543 minecraft:blackstone
setblock 94 194 510 minecraft:basalt
fill 94 194 511 94 195 511 minecraft:blackstone
fill 94 194 516 94 195 517 minecraft:blackstone
setblock 94 194 518 minecraft:basalt
fill 94 194 519 94 195 519 minecraft:blackstone
fill 94 194 531 94 196 531 minecraft:blackstone
fill 94 194 534 94 195 534 minecraft:blackstone
setblock 94 194 539 minecraft:basalt
setblock 94 194 542 minecraft:basalt
fill 94 194 544 94 195 544 minecraft:blackstone
setblock 94 194 548 minecraft:basalt
fill 94 194 550 95 195 550 minecraft:blackstone
fill 95 194 510 95 195 510 minecraft:blackstone
setblock 95 194 514 minecraft:smooth_basalt
fill 95 194 515 95 197 515 minecraft:blackstone
setblock 95 194 523 minecraft:blackstone
setblock 95 194 524 minecraft:smooth_basalt
fill 95 194 525 95 197 525 minecraft:blackstone
setblock 95 194 529 minecraft:smooth_basalt
fill 95 194 530 95 197 530 minecraft:blackstone
setblock 95 194 534 minecraft:smooth_basalt
fill 95 194 535 95 197 535 minecraft:blackstone
setblock 95 194 539 minecraft:smooth_basalt
fill 95 194 540 95 197 540 minecraft:blackstone
fill 95 194 542 95 195 542 minecraft:blackstone
setblock 95 194 544 minecraft:smooth_basalt
fill 95 194 545 95 197 545 minecraft:blackstone
setblock 95 194 549 minecraft:smooth_basalt
setblock 96 194 512 minecraft:blackstone
setblock 96 194 528 minecraft:smooth_basalt
fill 96 194 529 96 197 529 minecraft:blackstone
setblock 96 194 533 minecraft:smooth_basalt
fill 96 194 534 96 197 534 minecraft:blackstone
setblock 96 194 538 minecraft:smooth_basalt
fill 96 194 539 96 197 539 minecraft:blackstone
fill 96 194 541 96 195 541 minecraft:blackstone
setblock 96 194 548 minecraft:smooth_basalt
fill 96 194 549 96 196 549 minecraft:blackstone
setblock 97 194 512 minecraft:smooth_basalt
setblock 97 194 527 minecraft:smooth_basalt
fill 97 194 528 97 197 528 minecraft:blackstone
setblock 97 194 532 minecraft:smooth_basalt
fill 97 194 533 97 197 533 minecraft:blackstone
setblock 97 194 537 minecraft:smooth_basalt
fill 97 194 552 97 195 552 minecraft:blackstone
setblock 98 194 511 minecraft:smooth_basalt
setblock 98 194 531 minecraft:smooth_basalt
fill 98 194 532 98 197 532 minecraft:blackstone
fill 98 194 534 98 195 534 minecraft:blackstone
setblock 98 194 551 minecraft:smooth_basalt
fill 99 194 511 99 197 511 minecraft:blackstone
fill 99 194 551 99 197 551 minecraft:blackstone
fill 101 194 510 101 195 510 minecraft:blackstone
setblock 105 194 510 minecraft:basalt
setblock 105 194 552 minecraft:basalt
fill 106 194 510 106 195 510 minecraft:blackstone
setblock 107 194 510 minecraft:basalt
fill 108 194 510 109 195 510 minecraft:blackstone
setblock 108 194 511 minecraft:smooth_basalt
fill 109 194 511 109 197 511 minecraft:blackstone
fill 110 194 552 110 195 552 minecraft:blackstone
setblock 111 194 512 minecraft:blackstone
fill 111 194 551 112 194 551 minecraft:blackstone
setblock 112 194 512 minecraft:smooth_basalt
setblock 113 194 511 minecraft:smooth_basalt
fill 113 194 512 113 196 513 minecraft:blackstone
setblock 113 194 551 minecraft:smooth_basalt
fill 114 194 511 114 197 511 minecraft:blackstone
fill 114 194 551 114 197 551 minecraft:blackstone
fill 115 194 550 115 197 550 minecraft:blackstone
fill 115 194 552 115 195 552 minecraft:blackstone
setblock 116 194 512 minecraft:blackstone
setblock 116 194 513 minecraft:smooth_basalt
setblock 116 194 552 minecraft:basalt
setblock 117 194 512 minecraft:smooth_basalt
fill 117 194 513 117 197 513 minecraft:blackstone
setblock 118 194 511 minecraft:smooth_basalt
fill 118 194 512 118 197 512 minecraft:blackstone
setblock 118 194 551 minecraft:smooth_basalt
setblock 118 194 552 minecraft:basalt
fill 119 194 511 119 197 511 minecraft:blackstone
setblock 119 194 550 minecraft:smooth_basalt
fill 119 194 551 119 195 552 minecraft:blackstone
fill 120 194 510 122 195 510 minecraft:blackstone
fill 120 194 550 122 195 550 minecraft:blackstone
setblock 121 194 513 minecraft:smooth_basalt
fill 121 194 551 121 195 552 minecraft:blackstone
setblock 122 194 512 minecraft:smooth_basalt
setblock 122 194 551 minecraft:blackstone
setblock 122 194 552 minecraft:basalt
setblock 123 194 510 minecraft:basalt
setblock 123 194 511 minecraft:smooth_basalt
fill 123 194 512 123 197 512 minecraft:blackstone
setblock 123 194 551 minecraft:smooth_basalt
fill 124 194 510 124 195 511 minecraft:blackstone
fill 124 194 551 124 195 552 minecraft:blackstone
fill 125 194 510 125 195 510 minecraft:blackstone
fill 127 194 510 127 195 510 minecraft:blackstone
fill 127 194 552 128 195 552 minecraft:blackstone
setblock 128 194 510 minecraft:basalt
setblock 128 194 511 minecraft:smooth_basalt
setblock 128 194 551 minecraft:smooth_basalt
fill 129 194 511 129 197 511 minecraft:blackstone
fill 129 194 551 129 197 551 minecraft:blackstone
setblock 129 194 552 minecraft:basalt
fill 130 194 550 130 197 550 minecraft:blackstone
fill 131 194 510 131 195 510 minecraft:blackstone
setblock 132 194 512 minecraft:smooth_basalt
fill 132 194 552 132 195 552 minecraft:blackstone
setblock 133 194 511 minecraft:smooth_basalt
fill 133 194 512 133 197 512 minecraft:blackstone
setblock 133 194 551 minecraft:smooth_basalt
fill 134 194 511 134 197 511 minecraft:blackstone
fill 134 194 513 135 194 513 minecraft:blackstone
setblock 134 194 530 minecraft:smooth_basalt
fill 134 194 531 134 194 534 minecraft:blackstone
setblock 134 194 535 minecraft:smooth_basalt
fill 134 194 536 134 195 538 minecraft:blackstone
setblock 134 194 545 minecraft:smooth_basalt
fill 134 194 546 134 197 546 minecraft:blackstone
setblock 134 194 550 minecraft:smooth_basalt
fill 134 194 551 134 197 551 minecraft:blackstone
setblock 135 194 514 minecraft:smooth_basalt
fill 135 194 515 135 197 515 minecraft:blackstone
setblock 135 194 529 minecraft:smooth_basalt
fill 135 194 530 135 197 530 minecraft:blackstone
setblock 135 194 534 minecraft:smooth_basalt
fill 135 194 535 135 197 535 minecraft:blackstone
setblock 135 194 539 minecraft:smooth_basalt
fill 135 194 540 135 197 540 minecraft:blackstone
setblock 135 194 544 minecraft:smooth_basalt
fill 135 194 545 135 197 545 minecraft:blackstone
setblock 135 194 549 minecraft:smooth_basalt
fill 135 194 550 135 197 550 minecraft:blackstone
setblock 136 194 510 minecraft:basalt
setblock 136 194 515 minecraft:basalt
fill 136 194 523 136 195 523 minecraft:blackstone
setblock 136 194 525 minecraft:basalt
setblock 136 194 528 minecraft:basalt
setblock 136 194 539 minecraft:basalt
setblock 136 194 542 minecraft:basalt
setblock 136 194 546 minecraft:basalt
fill 136 194 547 136 195 547 minecraft:blackstone
fill 136 194 550 136 194 551 minecraft:basalt
setblock 94 195 510 minecraft:blackstone
setblock 94 195 518 minecraft:blackstone
fill 94 195 539 95 195 539 minecraft:blackstone
setblock 94 195 542 minecraft:blackstone
setblock 94 195 548 minecraft:blackstone
setblock 95 195 512 minecraft:blackstone
setblock 95 195 513 minecraft:smooth_basalt
fill 95 195 514 96 197 514 minecraft:blackstone
fill 95 195 516 95 195 517 minecraft:blackstone
setblock 95 195 518 minecraft:smooth_basalt
setblock 95 195 523 minecraft:smooth_basalt
fill 95 195 524 95 198 524 minecraft:blackstone
setblock 95 195 528 minecraft:smooth_basalt
fill 95 195 529 95 198 529 minecraft:blackstone
setblock 95 195 533 minecraft:smooth_basalt
fill 95 195 534 95 198 534 minecraft:blackstone
setblock 95 195 538 minecraft:smooth_basalt
setblock 95 195 543 minecraft:smooth_basalt
fill 95 195 544 95 198 544 minecraft:blackstone
setblock 95 195 548 minecraft:smooth_basalt
fill 95 195 549 95 198 549 minecraft:blackstone
setblock 96 195 512 minecraft:smooth_basalt
fill 96 195 513 96 198 513 minecraft:blackstone
setblock 96 195 527 minecraft:smooth_basalt
fill 96 195 528 96 198 528 minecraft:blackstone
setblock 96 195 532 minecraft:smooth_basalt
fill 96 195 533 96 198 533 minecraft:blackstone
setblock 96 195 537 minecraft:smooth_basalt
fill 96 195 538 97 197 538 minecraft:blackstone
setblock 96 195 542 minecraft:smooth_basalt
setblock 96 195 548 minecraft:blackstone
setblock 97 195 511 minecraft:smooth_basalt
fill 97 195 512 98 197 512 minecraft:blackstone
setblock 97 195 531 minecraft:smooth_basalt
fill 97 195 532 97 198 532 minecraft:blackstone
setblock 97 195 536 minecraft:smooth_basalt
fill 97 195 537 97 198 537 minecraft:blackstone
setblock 97 195 551 minecraft:smooth_basalt
fill 98 195 511 98 198 511 minecraft:blackstone
fill 98 195 531 98 198 531 minecraft:blackstone
fill 98 195 551 98 198 551 minecraft:blackstone
setblock 102 195 511 minecraft:smooth_basalt
fill 103 195 511 103 198 511 minecraft:blackstone
fill 104 195 522 105 196 522 minecraft:gold_block
setblock 105 195 510 minecraft:blackstone
setblock 105 195 552 minecraft:blackstone
setblock 106 195 511 minecraft:blackstone
setblock 107 195 510 minecraft:blackstone
setblock 107 195 511 minecraft:smooth_basalt
fill 108 195 511 108 198 511 minecraft:blackstone
setblock 110 195 512 minecraft:blackstone
setblock 111 195 512 minecraft:smooth_basalt
setblock 111 195 551 minecraft:blackstone
fill 112 195 510 112 196 510 minecraft:blackstone
setblock 112 195 511 minecraft:smooth_basalt
fill 112 195 512 112 197 513 minecraft:blackstone
setblock 112 195 551 minecraft:smooth_basalt
setblock 112 195 552 minecraft:blackstone
fill 113 195 511 113 198 511 minecraft:blackstone
fill 113 195 551 113 198 551 minecraft:blackstone
fill 114 195 550 114 198 550 minecraft:blackstone
setblock 115 195 513 minecraft:smooth_basalt
fill 115 195 514 117 196 514 minecraft:blackstone
setblock 116 195 512 minecraft:smooth_basalt
fill 116 195 513 116 198 513 minecraft:blackstone
setblock 116 195 552 minecraft:blackstone
setblock 117 195 511 minecraft:smooth_basalt
fill 117 195 512 117 198 512 minecraft:blackstone
setblock 117 195 551 minecraft:smooth_basalt
fill 118 195 511 118 198 511 minecraft:blackstone
setblock 118 195 550 minecraft:smooth_basalt
fill 118 195 551 118 195 552 minecraft:blackstone
fill 119 195 550 119 198 550 minecraft:blackstone
setblock 120 195 513 minecraft:smooth_basalt
setblock 121 195 512 minecraft:smooth_basalt
fill 121 195 513 121 198 513 minecraft:blackstone
setblock 122 195 511 minecraft:smooth_basalt
fill 122 195 512 122 198 512 minecraft:blackstone
setblock 122 195 551 minecraft:smooth_basalt
setblock 122 195 552 minecraft:blackstone
fill 123 195 510 123 195 511 minecraft:blackstone
fill 123 195 551 123 198 551 minecraft:blackstone
setblock 125 195 512 minecraft:blackstone
setblock 127 195 511 minecraft:smooth_basalt
setblock 127 195 551 minecraft:smooth_basalt
fill 128 195 510 128 195 511 minecraft:blackstone
fill 128 195 551 128 198 551 minecraft:blackstone
fill 129 195 550 129 198 550 minecraft:blackstone
setblock 129 195 552 minecraft:blackstone
setblock 131 195 512 minecraft:smooth_basalt
setblock 132 195 511 minecraft:smooth_basalt
fill 132 195 512 132 198 512 minecraft:blackstone
setblock 132 195 551 minecraft:smooth_basalt
fill 133 195 511 133 198 511 minecraft:blackstone
setblock 133 195 550 minecraft:smooth_basalt
fill 133 195 551 133 198 551 minecraft:blackstone
setblock 134 195 513 minecraft:blackstone
setblock 134 195 514 minecraft:smooth_basalt
setblock 134 195 529 minecraft:smooth_basalt
fill 134 195 530 134 195 533 minecraft:blackstone
setblock 134 195 534 minecraft:smooth_basalt
fill 134 195 535 134 198 535 minecraft:blackstone
setblock 134 195 539 minecraft:smooth_basalt
fill 134 195 540 134 195 543 minecraft:blackstone
setblock 134 195 544 minecraft:smooth_basalt
fill 134 195 545 134 198 545 minecraft:blackstone
setblock 134 195 549 minecraft:smooth_basalt
fill 134 195 550 134 198 550 minecraft:blackstone
setblock 135 195 513 minecraft:smooth_basalt
fill 135 195 514 135 198 514 minecraft:blackstone
fill 135 195 516 135 196 516 minecraft:blackstone
setblock 135 195 528 minecraft:smooth_basalt
fill 135 195 529 135 198 529 minecraft:blackstone
setblock 135 195 533 minecraft:smooth_basalt
fill 135 195 534 135 198 534 minecraft:blackstone
setblock 135 195 538 minecraft:smooth_basalt
fill 135 195 539 136 195 539 minecraft:blackstone
setblock 135 195 543 minecraft:smooth_basalt
fill 135 195 544 135 198 544 minecraft:blackstone
setblock 135 195 548 minecraft:smooth_basalt
fill 135 195 549 135 198 549 minecraft:blackstone
setblock 136 195 510 minecraft:blackstone
setblock 136 195 515 minecraft:blackstone
setblock 136 195 525 minecraft:blackstone
setblock 136 195 528 minecraft:blackstone
setblock 136 195 542 minecraft:blackstone
setblock 136 195 546 minecraft:blackstone
fill 136 195 550 136 195 551 minecraft:blackstone
fill 94 196 510 94 197 511 minecraft:basalt
fill 94 196 513 94 196 524 minecraft:basalt
setblock 94 196 525 minecraft:blackstone
fill 94 196 526 94 307 528 minecraft:basalt
fill 94 196 529 94 197 529 minecraft:blackstone
fill 94 196 530 94 307 530 minecraft:basalt
fill 94 196 532 94 196 537 minecraft:basalt
fill 94 196 538 95 196 538 minecraft:blackstone
fill 94 196 539 94 197 542 minecraft:basalt
fill 94 196 544 94 307 552 minecraft:basalt
fill 95 196 510 96 307 510 minecraft:basalt
setblock 95 196 512 minecraft:smooth_basalt
fill 95 196 513 95 199 513 minecraft:blackstone
setblock 95 196 516 minecraft:blackstone
setblock 95 196 517 minecraft:smooth_basalt
fill 95 196 518 95 196 521 minecraft:blackstone
setblock 95 196 522 minecraft:smooth_basalt
fill 95 196 523 95 199 523 minecraft:blackstone
setblock 95 196 527 minecraft:smooth_basalt
fill 95 196 528 95 199 528 minecraft:blackstone
setblock 95 196 532 minecraft:smooth_basalt
fill 95 196 533 95 199 533 minecraft:blackstone
setblock 95 196 537 minecraft:smooth_basalt
fill 95 196 539 95 198 539 minecraft:blackstone
setblock 95 196 542 minecraft:smooth_basalt
fill 95 196 543 95 199 543 minecraft:blackstone
setblock 95 196 547 minecraft:smooth_basalt
fill 95 196 548 95 199 548 minecraft:blackstone
fill 95 196 550 95 196 552 minecraft:blackstone
setblock 96 196 511 minecraft:smooth_basalt
fill 96 196 512 96 199 512 minecraft:blackstone
setblock 96 196 515 minecraft:blackstone
setblock 96 196 516 minecraft:smooth_basalt
setblock 96 196 526 minecraft:smooth_basalt
fill 96 196 527 96 199 527 minecraft:blackstone
setblock 96 196 531 minecraft:smooth_basalt
fill 96 196 532 96 199 532 minecraft:blackstone
setblock 96 196 536 minecraft:smooth_basalt
fill 96 196 537 96 199 537 minecraft:blackstone
setblock 96 196 541 minecraft:smooth_basalt
fill 96 196 542 96 199 542 minecraft:blackstone
setblock 96 196 551 minecraft:smooth_basalt
fill 96 196 552 136 196 552 minecraft:basalt
fill 97 196 510 97 196 511 minecraft:blackstone
setblock 97 196 530 minecraft:smooth_basalt
fill 97 196 531 97 199 531 minecraft:blackstone
setblock 97 196 535 minecraft:smooth_basalt
fill 97 196 536 97 199 536 minecraft:blackstone
setblock 97 196 539 minecraft:blackstone
fill 97 196 551 97 199 551 minecraft:blackstone
fill 98 196 510 103 197 510 minecraft:basalt
setblock 98 196 534 minecraft:smooth_basalt
fill 98 196 535 98 199 535 minecraft:blackstone
setblock 99 196 512 minecraft:blackstone
setblock 101 196 511 minecraft:smooth_basalt
fill 102 196 511 102 199 511 minecraft:blackstone
fill 104 196 511 105 196 511 minecraft:blackstone
fill 105 196 510 109 197 510 minecraft:basalt
setblock 106 196 511 minecraft:smooth_basalt
fill 107 196 511 107 199 511 minecraft:blackstone
fill 108 196 512 109 196 512 minecraft:blackstone
setblock 110 196 512 minecraft:smooth_basalt
setblock 110 196 551 minecraft:blackstone
fill 111 196 510 111 307 510 minecraft:basalt
setblock 111 196 511 minecraft:smooth_basalt
fill 111 196 512 111 198 513 minecraft:blackstone
setblock 111 196 551 minecraft:smooth_basalt
fill 112 196 511 112 199 511 minecraft:blackstone
fill 112 196 551 112 199 551 minecraft:blackstone
fill 113 196 510 131 197 510 minecraft:basalt
setblock 113 196 514 minecraft:smooth_basalt
setblock 114 196 512 minecraft:blackstone
setblock 114 196 513 minecraft:smooth_basalt
fill 114 196 514 114 199 514 minecraft:blackstone
setblock 115 196 512 minecraft:smooth_basalt
fill 115 196 513 115 199 513 minecraft:blackstone
setblock 116 196 511 minecraft:smooth_basalt
fill 116 196 512 116 199 512 minecraft:blackstone
setblock 116 196 551 minecraft:smooth_basalt
fill 117 196 511 117 199 511 minecraft:blackstone
setblock 117 196 550 minecraft:smooth_basalt
fill 117 196 551 120 196 551 minecraft:blackstone
setblock 118 196 514 minecraft:smooth_basalt
fill 118 196 550 118 199 550 minecraft:blackstone
setblock 119 196 513 minecraft:smooth_basalt
setblock 120 196 512 minecraft:smooth_basalt
fill 120 196 513 120 199 513 minecraft:blackstone
fill 120 196 550 121 196 550 minecraft:blackstone
setblock 121 196 511 minecraft:smooth_basalt
fill 121 196 512 121 199 512 minecraft:blackstone
setblock 121 196 551 minecraft:smooth_basalt
fill 122 196 511 124 197 511 minecraft:blackstone
fill 122 196 551 122 199 551 minecraft:blackstone
fill 124 196 551 124 197 551 minecraft:blackstone
setblock 125 196 512 minecraft:smooth_basalt
setblock 126 196 511 minecraft:smooth_basalt
fill 126 196 512 129 196 512 minecraft:blackstone
setblock 126 196 551 minecraft:smooth_basalt
fill 127 196 511 128 198 511 minecraft:blackstone
fill 127 196 551 127 199 551 minecraft:blackstone
setblock 130 196 511 minecraft:blackstone
setblock 130 196 512 minecraft:smooth_basalt
setblock 131 196 511 minecraft:smooth_basalt
fill 131 196 512 131 199 512 minecraft:blackstone
setblock 131 196 551 minecraft:smooth_basalt
fill 132 196 510 132 196 511 minecraft:blackstone
setblock 132 196 550 minecraft:smooth_basalt
fill 132 196 551 132 199 551 minecraft:blackstone
fill 133 196 510 136 196 510 minecraft:basalt
fill 133 196 532 133 196 533 minecraft:blackstone
setblock 133 196 534 minecraft:smooth_basalt
fill 133 196 535 133 197 537 minecraft:blackstone
setblock 133 196 549 minecraft:smooth_basalt
fill 133 196 550 133 199 550 minecraft:blackstone
setblock 134 196 513 minecraft:smooth_basalt
fill 134 196 514 134 198 515 minecraft:blackstone
fill 134 196 529 134 196 532 minecraft:blackstone
setblock 134 196 533 minecraft:smooth_basalt
fill 134 196 534 134 199 534 minecraft:blackstone
fill 134 196 536 134 196 537 minecraft:blackstone
setblock 134 196 538 minecraft:smooth_basalt
fill 134 196 539 134 196 542 minecraft:blackstone
setblock 134 196 543 minecraft:smooth_basalt
fill 134 196 544 134 199 544 minecraft:blackstone
setblock 134 196 548 minecraft:smooth_basalt
fill 134 196 549 134 199 549 minecraft:blackstone
setblock 135 196 512 minecraft:smooth_basalt
fill 135 196 513 135 199 513 minecraft:blackstone
setblock 135 196 517 minecraft:smooth_basalt
fill 135 196 518 135 199 518 minecraft:blackstone
setblock 135 196 526 minecraft:blackstone
setblock 135 196 527 minecraft:smooth_basalt
fill 135 196 528 135 199 528 minecraft:blackstone
setblock 135 196 532 minecraft:smooth_basalt
fill 135 196 533 135 199 533 minecraft:blackstone
setblock 135 196 536 minecraft:blackstone
setblock 135 196 537 minecraft:smooth_basalt
fill 135 196 538 135 198 539 minecraft:blackstone
setblock 135 196 542 minecraft:smooth_basalt
fill 135 196 543 135 199 543 minecraft:blackstone
setblock 135 196 547 minecraft:smooth_basalt
fill 135 196 548 135 199 548 minecraft:blackstone
fill 136 196 511 136 197 518 minecraft:basalt
setblock 136 196 519 minecraft:blackstone
fill 136 196 520 136 196 551 minecraft:basalt
fill 94 197 512 94 307 516 minecraft:basalt
fill 94 197 517 96 198 517 minecraft:blackstone
fill 94 197 518 94 197 522 minecraft:basalt
fill 94 197 523 94 198 523 minecraft:blackstone
fill 94 197 524 94 307 525 minecraft:basalt
fill 94 197 531 94 307 531 minecraft:basalt
fill 94 197 532 95 197 532 minecraft:blackstone
fill 94 197 533 94 307 538 minecraft:basalt
fill 94 197 543 94 307 543 minecraft:basalt
setblock 95 197 511 minecraft:smooth_basalt
fill 95 197 512 95 200 512 minecraft:blackstone
setblock 95 197 516 minecraft:smooth_basalt
fill 95 197 518 95 197 520 minecraft:blackstone
setblock 95 197 521 minecraft:smooth_basalt
fill 95 197 522 95 200 522 minecraft:blackstone
setblock 95 197 526 minecraft:smooth_basalt
fill 95 197 527 95 200 527 minecraft:blackstone
setblock 95 197 531 minecraft:smooth_basalt
setblock 95 197 536 minecraft:smooth_basalt
fill 95 197 537 95 199 538 minecraft:blackstone
setblock 95 197 541 minecraft:smooth_basalt
fill 95 197 542 95 200 542 minecraft:blackstone
setblock 95 197 546 minecraft:smooth_basalt
fill 95 197 547 95 200 547 minecraft:blackstone
setblock 95 197 550 minecraft:blackstone
setblock 95 197 551 minecraft:smooth_basalt
fill 95 197 552 98 307 552 minecraft:basalt
fill 96 197 511 97 199 511 minecraft:blackstone
setblock 96 197 515 minecraft:smooth_basalt
fill 96 197 516 96 200 516 minecraft:blackstone
fill 96 197 518 96 198 518 minecraft:blackstone
setblock 96 197 524 minecraft:blackstone
setblock 96 197 525 minecraft:smooth_basalt
fill 96 197 526 96 200 526 minecraft:blackstone
setblock 96 197 530 minecraft:smooth_basalt
fill 96 197 531 96 200 531 minecraft:blackstone
setblock 96 197 535 minecraft:smooth_basalt
fill 96 197 536 96 200 536 minecraft:blackstone
setblock 96 197 540 minecraft:smooth_basalt
fill 96 197 541 96 200 541 minecraft:blackstone
fill 96 197 543 96 198 543 minecraft:blackstone
setblock 96 197 550 minecraft:smooth_basalt
fill 96 197 551 96 200 551 minecraft:blackstone
fill 97 197 510 97 307 510 minecraft:basalt
setblock 97 197 513 minecraft:light[level=12]
setblock 97 197 521 minecraft:light[level=12]
setblock 97 197 529 minecraft:smooth_basalt
fill 97 197 530 97 200 530 minecraft:blackstone
setblock 97 197 534 minecraft:smooth_basalt
fill 97 197 535 97 200 535 minecraft:blackstone
setblock 97 197 539 minecraft:smooth_basalt
setblock 97 197 545 minecraft:light[level=12]
setblock 98 197 533 minecraft:smooth_basalt
fill 98 197 534 98 200 534 minecraft:blackstone
fill 98 197 536 98 198 536 minecraft:blackstone
setblock 99 197 512 minecraft:smooth_basalt
setblock 99 197 552 minecraft:blackstone
setblock 100 197 511 minecraft:smooth_basalt
fill 100 197 512 100 199 512 minecraft:blackstone
fill 100 197 552 106 307 552 minecraft:basalt
fill 101 197 511 101 200 511 minecraft:blackstone
setblock 104 197 510 minecraft:basalt
setblock 104 197 511 minecraft:blackstone
setblock 105 197 511 minecraft:smooth_basalt
setblock 105 197 513 minecraft:light[level=12]
setblock 105 197 521 minecraft:light[level=12]
setblock 105 197 529 minecraft:light[level=12]
setblock 105 197 537 minecraft:light[level=12]
setblock 105 197 545 minecraft:light[level=12]
fill 106 197 511 106 200 511 minecraft:blackstone
fill 107 197 512 108 197 512 minecraft:blackstone
setblock 107 197 552 minecraft:blackstone
fill 108 197 552 109 307 552 minecraft:basalt
setblock 109 197 512 minecraft:smooth_basalt
fill 109 197 513 110 199 513 minecraft:blackstone
setblock 110 197 510 minecraft:basalt
setblock 110 197 511 minecraft:smooth_basalt
fill 110 197 512 110 200 512 minecraft:blackstone
setblock 110 197 551 minecraft:smooth_basalt
setblock 110 197 552 minecraft:blackstone
fill 111 197 511 111 200 511 minecraft:blackstone
fill 111 197 551 111 200 551 minecraft:blackstone
fill 111 197 552 127 307 552 minecraft:basalt
fill 112 197 510 112 307 510 minecraft:basalt
setblock 112 197 514 minecraft:smooth_basalt
setblock 113 197 512 minecraft:blackstone
setblock 113 197 513 minecraft:smooth_basalt
fill 113 197 514 113 200 514 minecraft:blackstone
setblock 113 197 521 minecraft:light[level=12]
setblock 113 197 529 minecraft:light[level=12]
setblock 113 197 537 minecraft:light[level=12]
setblock 113 197 545 minecraft:light[level=12]
fill 113 197 550 113 199 550 minecraft:blackstone
setblock 114 197 512 minecraft:smooth_basalt
fill 114 197 513 114 200 513 minecraft:blackstone
setblock 115 197 511 minecraft:smooth_basalt
fill 115 197 512 115 200 512 minecraft:blackstone
fill 115 197 514 116 197 514 minecraft:blackstone
setblock 115 197 551 minecraft:smooth_basalt
fill 116 197 511 116 200 511 minecraft:blackstone
setblock 116 197 550 minecraft:smooth_basalt
fill 116 197 551 119 197 551 minecraft:blackstone
setblock 117 197 514 minecraft:smooth_basalt
fill 117 197 550 117 200 550 minecraft:blackstone
setblock 118 197 513 minecraft:smooth_basalt
fill 118 197 514 119 199 514 minecraft:blackstone
setblock 119 197 512 minecraft:smooth_basalt
fill 119 197 513 119 200 513 minecraft:blackstone
setblock 120 197 511 minecraft:smooth_basalt
fill 120 197 512 120 200 512 minecraft:blackstone
setblock 120 197 550 minecraft:blackstone
setblock 120 197 551 minecraft:smooth_basalt
fill 121 197 511 121 200 511 minecraft:blackstone
setblock 121 197 521 minecraft:light[level=12]
setblock 121 197 529 minecraft:light[level=12]
setblock 121 197 537 minecraft:light[level=12]
setblock 121 197 545 minecraft:light[level=12]
setblock 121 197 550 minecraft:smooth_basalt
fill 121 197 551 121 200 551 minecraft:blackstone
setblock 122 197 513 minecraft:blackstone
setblock 124 197 512 minecraft:smooth_basalt
setblock 125 197 511 minecraft:smooth_basalt
fill 125 197 512 128 197 512 minecraft:blackstone
setblock 125 197 551 minecraft:smooth_basalt
fill 126 197 511 126 200 511 minecraft:blackstone
fill 126 197 551 126 200 551 minecraft:blackstone
fill 128 197 550 128 199 550 minecraft:blackstone
setblock 128 197 552 minecraft:blackstone
setblock 129 197 512 minecraft:smooth_basalt
setblock 129 197 513 minecraft:light[level=12]
setblock 129 197 521 minecraft:light[level=12]
setblock 129 197 529 minecraft:light[level=12]
setblock 129 197 537 minecraft:light[level=12]
setblock 129 197 545 minecraft:light[level=12]
fill 129 197 552 136 197 552 minecraft:basalt
setblock 130 197 511 minecraft:smooth_basalt
fill 130 197 512 130 200 512 minecraft:blackstone
setblock 130 197 551 minecraft:smooth_basalt
fill 131 197 511 132 199 511 minecraft:blackstone
setblock 131 197 550 minecraft:smooth_basalt
fill 131 197 551 131 200 551 minecraft:blackstone
fill 132 197 510 134 197 510 minecraft:basalt
fill 132 197 550 132 200 550 minecraft:blackstone
setblock 133 197 513 minecraft:smooth_basalt
fill 133 197 531 133 197 532 minecraft:blackstone
setblock 133 197 533 minecraft:smooth_basalt
fill 133 197 534 133 200 534 minecraft:blackstone
setblock 133 197 538 minecraft:smooth_basalt
fill 133 197 539 134 198 540 minecraft:blackstone
fill 133 197 549 133 200 549 minecraft:blackstone
setblock 134 197 512 minecraft:smooth_basalt
fill 134 197 513 134 200 513 minecraft:blackstone
setblock 134 197 516 minecraft:blackstone
fill 134 197 528 134 197 531 minecraft:blackstone
setblock 134 197 532 minecraft:smooth_basalt
fill 134 197 533 134 200 533 minecraft:blackstone
setblock 134 197 536 minecraft:blackstone
setblock 134 197 537 minecraft:smooth_basalt
fill 134 197 538 134 200 538 minecraft:blackstone
setblock 134 197 541 minecraft:blackstone
setblock 134 197 542 minecraft:smooth_basalt
fill 134 197 543 134 200 543 minecraft:blackstone
setblock 134 197 547 minecraft:smooth_basalt
fill 134 197 548 134 200 548 minecraft:blackstone
setblock 135 197 510 minecraft:blackstone
setblock 135 197 511 minecraft:smooth_basalt
fill 135 197 512 135 200 512 minecraft:blackstone
setblock 135 197 516 minecraft:smooth_basalt
fill 135 197 517 135 200 517 minecraft:blackstone
fill 135 197 519 135 197 520 minecraft:blackstone
setblock 135 197 525 minecraft:blackstone
setblock 135 197 526 minecraft:smooth_basalt
fill 135 197 527 135 200 527 minecraft:blackstone
setblock 135 197 531 minecraft:smooth_basalt
fill 135 197 532 135 200 532 minecraft:blackstone
setblock 135 197 536 minecraft:smooth_basalt
fill 135 197 537 135 200 537 minecraft:blackstone
setblock 135 197 541 minecraft:smooth_basalt
fill 135 197 542 135 200 542 minecraft:blackstone
setblock 135 197 546 minecraft:smooth_basalt
fill 135 197 547 135 200 547 minecraft:blackstone
setblock 135 197 551 minecraft:smooth_basalt
fill 136 197 510 136 307 510 minecraft:basalt
fill 136 197 519 136 307 527 minecraft:basalt
setblock 136 197 528 minecraft:blackstone
fill 136 197 529 136 197 543 minecraft:basalt
setblock 136 197 544 minecraft:blackstone
fill 136 197 545 136 197 551 minecraft:basalt
fill 94 198 510 94 307 510 minecraft:basalt
fill 94 198 511 95 198 511 minecraft:blackstone
fill 94 198 518 94 307 521 minecraft:basalt
setblock 94 198 522 minecraft:blackstone
fill 94 198 529 94 307 529 minecraft:basalt
fill 94 198 532 94 307 532 minecraft:basalt
fill 94 198 539 94 307 541 minecraft:basalt
setblock 94 198 542 minecraft:blackstone
setblock 95 198 514 minecraft:blackstone
setblock 95 198 515 minecraft:smooth_basalt
fill 95 198 516 95 201 516 minecraft:blackstone
fill 95 198 518 95 198 519 minecraft:blackstone
setblock 95 198 520 minecraft:smooth_basalt
fill 95 198 521 96 200 521 minecraft:blackstone
setblock 95 198 525 minecraft:smooth_basalt
fill 95 198 526 95 201 526 minecraft:blackstone
setblock 95 198 530 minecraft:smooth_basalt
fill 95 198 531 95 200 532 minecraft:blackstone
setblock 95 198 535 minecraft:smooth_basalt
fill 95 198 536 95 201 536 minecraft:blackstone
setblock 95 198 540 minecraft:smooth_basalt
fill 95 198 541 95 201 541 minecraft:blackstone
setblock 95 198 545 minecraft:smooth_basalt
fill 95 198 546 95 201 546 minecraft:blackstone
setblock 95 198 550 minecraft:smooth_basalt
fill 95 198 551 95 201 551 minecraft:blackstone
setblock 96 198 514 minecraft:smooth_basalt
fill 96 198 515 96 201 515 minecraft:blackstone
setblock 96 198 519 minecraft:smooth_basalt
fill 96 198 520 96 201 520 minecraft:blackstone
fill 96 198 522 96 198 523 minecraft:blackstone
setblock 96 198 524 minecraft:smooth_basalt
fill 96 198 525 96 201 525 minecraft:blackstone
setblock 96 198 529 minecraft:smooth_basalt
fill 96 198 530 96 201 530 minecraft:blackstone
setblock 96 198 534 minecraft:smooth_basalt
fill 96 198 535 96 201 535 minecraft:blackstone
setblock 96 198 538 minecraft:blackstone
setblock 96 198 539 minecraft:smooth_basalt
fill 96 198 540 97 200 540 minecraft:blackstone
setblock 97 198 512 minecraft:blackstone
setblock 97 198 528 minecraft:smooth_basalt
fill 97 198 529 97 200 529 minecraft:blackstone
setblock 97 198 533 minecraft:smooth_basalt
fill 97 198 534 97 201 534 minecraft:blackstone
setblock 97 198 538 minecraft:smooth_basalt
fill 97 198 539 97 201 539 minecraft:blackstone
fill 98 198 510 102 307 510 minecraft:basalt
setblock 98 198 512 minecraft:smooth_basalt
setblock 98 198 532 minecraft:smooth_basalt
fill 98 198 533 98 199 533 minecraft:blackstone
setblock 99 198 511 minecraft:smooth_basalt
fill 99 198 512 99 200 512 minecraft:blackstone
setblock 99 198 551 minecraft:smooth_basalt
fill 99 198 552 99 307 552 minecraft:basalt
fill 100 198 511 100 201 511 minecraft:blackstone
fill 103 198 510 104 198 510 minecraft:blackstone
setblock 104 198 511 minecraft:smooth_basalt
fill 105 198 510 106 307 510 minecraft:basalt
fill 105 198 511 105 201 511 minecraft:blackstone
fill 106 198 512 107 198 512 minecraft:blackstone
setblock 107 198 510 minecraft:blackstone
fill 107 198 552 107 307 552 minecraft:basalt
fill 108 198 510 109 307 510 minecraft:basalt
setblock 108 198 512 minecraft:smooth_basalt
fill 108 198 513 108 201 513 minecraft:blackstone
setblock 109 198 511 minecraft:smooth_basalt
fill 109 198 512 109 201 512 minecraft:blackstone
setblock 109 198 551 minecraft:smooth_basalt
fill 110 198 510 110 198 511 minecraft:blackstone
setblock 110 198 514 minecraft:blackstone
fill 110 198 551 110 201 551 minecraft:blackstone
fill 110 198 552 110 307 552 minecraft:basalt
setblock 111 198 514 minecraft:smooth_basalt
setblock 112 198 512 minecraft:blackstone
setblock 112 198 513 minecraft:smooth_basalt
fill 112 198 514 112 201 514 minecraft:blackstone
fill 112 198 550 112 200 550 minecraft:blackstone
fill 113 198 510 117 307 510 minecraft:basalt
setblock 113 198 512 minecraft:smooth_basalt
fill 113 198 513 113 201 513 minecraft:blackstone
fill 113 198 539 113 199 539 minecraft:gilded_blackstone
setblock 114 198 511 minecraft:smooth_basalt
fill 114 198 512 114 201 512 minecraft:blackstone
setblock 114 198 515 minecraft:blackstone
setblock 114 198 551 minecraft:smooth_basalt
fill 115 198 511 115 201 511 minecraft:blackstone
setblock 115 198 514 minecraft:blackstone
setblock 115 198 515 minecraft:smooth_basalt
setblock 115 198 550 minecraft:smooth_basalt
fill 115 198 551 118 198 551 minecraft:blackstone
setblock 116 198 514 minecraft:smooth_basalt
fill 116 198 550 116 201 550 minecraft:blackstone
setblock 117 198 513 minecraft:smooth_basalt
fill 117 198 514 117 201 514 minecraft:blackstone
setblock 118 198 510 minecraft:blackstone
setblock 118 198 512 minecraft:smooth_basalt
fill 118 198 513 118 201 513 minecraft:blackstone
fill 119 198 510 129 307 510 minecraft:basalt
setblock 119 198 511 minecraft:smooth_basalt
fill 119 198 512 119 201 512 minecraft:blackstone
setblock 119 198 551 minecraft:smooth_basalt
fill 120 198 511 120 201 511 minecraft:blackstone
setblock 120 198 550 minecraft:smooth_basalt
fill 120 198 551 120 201 551 minecraft:blackstone
fill 122 198 511 123 198 511 minecraft:blackstone
setblock 122 198 513 minecraft:smooth_basalt
setblock 123 198 512 minecraft:smooth_basalt
setblock 124 198 511 minecraft:smooth_basalt
fill 124 198 512 127 198 512 minecraft:blackstone
setblock 124 198 551 minecraft:smooth_basalt
fill 125 198 511 125 201 511 minecraft:blackstone
fill 125 198 551 125 201 551 minecraft:blackstone
setblock 128 198 512 minecraft:smooth_basalt
fill 128 198 552 132 307 552 minecraft:basalt
setblock 129 198 511 minecraft:smooth_basalt
fill 129 198 512 129 201 512 minecraft:blackstone
setblock 129 198 551 minecraft:smooth_basalt
fill 130 198 510 130 198 511 minecraft:blackstone
setblock 130 198 550 minecraft:smooth_basalt
fill 130 198 551 130 201 551 minecraft:blackstone
fill 131 198 510 133 307 510 minecraft:basalt
setblock 131 198 513 minecraft:blackstone
fill 131 198 550 131 201 550 minecraft:blackstone
setblock 132 198 513 minecraft:smooth_basalt
fill 132 198 535 132 198 537 minecraft:blackstone
fill 132 198 549 132 200 549 minecraft:blackstone
setblock 133 198 512 minecraft:smooth_basalt
fill 133 198 513 133 200 514 minecraft:blackstone
setblock 133 198 531 minecraft:blackstone
setblock 133 198 532 minecraft:smooth_basalt
fill 133 198 533 133 201 533 minecraft:blackstone
fill 133 198 535 133 198 536 minecraft:blackstone
setblock 133 198 537 minecraft:smooth_basalt
fill 133 198 538 133 201 538 minecraft:blackstone
setblock 133 198 541 minecraft:blackstone
setblock 133 198 542 minecraft:smooth_basalt
fill 133 198 543 133 201 543 minecraft:blackstone
fill 133 198 548 133 200 548 minecraft:blackstone
setblock 133 198 552 minecraft:blackstone
setblock 134 198 510 minecraft:blackstone
setblock 134 198 511 minecraft:smooth_basalt
fill 134 198 512 134 201 512 minecraft:blackstone
setblock 134 198 516 minecraft:smooth_basalt
fill 134 198 517 134 200 518 minecraft:blackstone
fill 134 198 528 134 198 530 minecraft:blackstone
setblock 134 198 531 minecraft:smooth_basalt
fill 134 198 532 134 201 532 minecraft:blackstone
setblock 134 198 536 minecraft:smooth_basalt
fill 134 198 537 134 201 537 minecraft:blackstone
setblock 134 198 541 minecraft:smooth_basalt
fill 134 198 542 134 201 542 minecraft:blackstone
setblock 134 198 546 minecraft:smooth_basalt
fill 134 198 547 134 201 547 minecraft:blackstone
setblock 134 198 551 minecraft:smooth_basalt
fill 134 198 552 136 307 552 minecraft:basalt
fill 135 198 510 135 307 510 minecraft:basalt
fill 135 198 511 135 201 511 minecraft:blackstone
setblock 135 198 515 minecraft:smooth_basalt
fill 135 198 516 136 198 516 minecraft:blackstone
setblock 135 198 519 minecraft:blackstone
setblock 135 198 520 minecraft:smooth_basalt
fill 135 198 521 135 198 524 minecraft:blackstone
setblock 135 198 525 minecraft:smooth_basalt
fill 135 198 526 135 201 526 minecraft:blackstone
setblock 135 198 530 minecraft:smooth_basalt
fill 135 198 531 135 201 531 minecraft:blackstone
setblock 135 198 535 minecraft:smooth_basalt
fill 135 198 536 136 198 536 minecraft:blackstone
setblock 135 198 540 minecraft:smooth_basalt
fill 135 198 541 135 201 541 minecraft:blackstone
setblock 135 198 545 minecraft:smooth_basalt
fill 135 198 546 135 201 546 minecraft:blackstone
setblock 135 198 550 minecraft:smooth_basalt
fill 135 198 551 135 201 551 minecraft:blackstone
fill 136 198 511 136 307 515 minecraft:basalt
fill 136 198 517 136 307 518 minecraft:basalt
fill 136 198 528 136 307 535 minecraft:basalt
setblock 136 198 537 minecraft:blackstone
fill 136 198 538 136 307 539 minecraft:basalt
setblock 136 198 540 minecraft:blackstone
fill 136 198 541 136 307 542 minecraft:basalt
setblock 136 198 543 minecraft:blackstone
fill 136 198 544 136 307 548 minecraft:basalt
fill 136 198 549 136 198 550 minecraft:blackstone
fill 136 198 551 136 307 551 minecraft:basalt
fill 94 199 511 94 307 511 minecraft:basalt
fill 94 199 517 94 307 517 minecraft:basalt
fill 94 199 522 94 307 523 minecraft:basalt
fill 94 199 542 94 307 542 minecraft:basalt
fill 95 199 511 95 201 511 minecraft:blackstone
setblock 95 199 514 minecraft:smooth_basalt
fill 95 199 515 95 202 515 minecraft:blackstone
fill 95 199 517 95 199 518 minecraft:blackstone
setblock 95 199 519 minecraft:smooth_basalt
fill 95 199 520 95 202 520 minecraft:blackstone
setblock 95 199 524 minecraft:smooth_basalt
fill 95 199 525 95 202 525 minecraft:blackstone
setblock 95 199 529 minecraft:smooth_basalt
fill 95 199 530 95 202 530 minecraft:blackstone
setblock 95 199 534 minecraft:smooth_basalt
fill 95 199 535 95 202 535 minecraft:blackstone
setblock 95 199 539 minecraft:smooth_basalt
fill 95 199 540 95 202 540 minecraft:blackstone
setblock 95 199 544 minecraft:smooth_basalt
fill 95 199 545 95 202 545 minecraft:blackstone
setblock 95 199 549 minecraft:smooth_basalt
fill 95 199 550 95 201 550 minecraft:blackstone
setblock 96 199 513 minecraft:smooth_basalt
fill 96 199 514 97 200 514 minecraft:blackstone
setblock 96 199 517 minecraft:blackstone
setblock 96 199 518 minecraft:smooth_basalt
fill 96 199 519 96 202 519 minecraft:blackstone
setblock 96 199 522 minecraft:blackstone
setblock 96 199 523 minecraft:smooth_basalt
fill 96 199 524 96 202 524 minecraft:blackstone
setblock 96 199 528 minecraft:smooth_basalt
fill 96 199 529 96 202 529 minecraft:blackstone
setblock 96 199 533 minecraft:smooth_basalt
fill 96 199 534 96 202 534 minecraft:blackstone
setblock 96 199 538 minecraft:smooth_basalt
fill 96 199 539 96 202 539 minecraft:blackstone
setblock 96 199 543 minecraft:smooth_basalt
fill 96 199 544 96 200 544 minecraft:blackstone
setblock 97 199 512 minecraft:smooth_basalt
fill 97 199 515 97 199 516 minecraft:blackstone
setblock 97 199 528 minecraft:blackstone
setblock 97 199 532 minecraft:smooth_basalt
fill 97 199 533 97 202 533 minecraft:blackstone
setblock 97 199 537 minecraft:smooth_basalt
fill 97 199 538 97 202 538 minecraft:blackstone
setblock 98 199 511 minecraft:smooth_basalt
fill 98 199 512 98 201 512 minecraft:blackstone
setblock 98 199 532 minecraft:blackstone
setblock 98 199 536 minecraft:smooth_basalt
setblock 98 199 551 minecraft:smooth_basalt
fill 99 199 511 99 202 511 minecraft:blackstone
fill 103 199 510 104 307 510 minecraft:basalt
setblock 103 199 511 minecraft:smooth_basalt
fill 104 199 511 104 202 511 minecraft:blackstone
fill 105 199 512 106 199 512 minecraft:blackstone
fill 107 199 510 107 307 510 minecraft:basalt
setblock 107 199 512 minecraft:smooth_basalt
fill 107 199 513 107 202 513 minecraft:blackstone
setblock 108 199 511 minecraft:smooth_basalt
fill 108 199 512 108 202 512 minecraft:blackstone
fill 109 199 511 110 201 511 minecraft:blackstone
setblock 109 199 514 minecraft:blackstone
fill 109 199 551 109 202 551 minecraft:blackstone
fill 110 199 510 110 307 510 minecraft:basalt
setblock 110 199 514 minecraft:smooth_basalt
setblock 111 199 512 minecraft:blackstone
setblock 111 199 513 minecraft:smooth_basalt
fill 111 199 514 111 202 514 minecraft:blackstone
setblock 112 199 512 minecraft:smooth_basalt
fill 112 199 513 112 202 513 minecraft:blackstone
fill 112 199 515 113 199 515 minecraft:blackstone
setblock 113 199 511 minecraft:smooth_basalt
fill 113 199 512 113 202 512 minecraft:blackstone
setblock 113 199 551 minecraft:smooth_basalt
fill 114 199 511 114 202 511 minecraft:blackstone
setblock 114 199 515 minecraft:smooth_basalt
setblock 114 199 550 minecraft:smooth_basalt
fill 114 199 551 117 199 551 minecraft:blackstone
setblock 115 199 514 minecraft:smooth_basalt
fill 115 199 515 116 199 515 minecraft:blackstone
fill 115 199 550 115 202 550 minecraft:blackstone
setblock 116 199 513 minecraft:smooth_basalt
fill 116 199 514 116 202 514 minecraft:blackstone
setblock 117 199 512 minecraft:smooth_basalt
fill 117 199 513 117 202 513 minecraft:blackstone
fill 118 199 510 118 307 510 minecraft:basalt
setblock 118 199 511 minecraft:smooth_basalt
fill 118 199 512 118 202 512 minecraft:blackstone
setblock 118 199 551 minecraft:smooth_basalt
fill 119 199 511 119 202 511 minecraft:blackstone
setblock 119 199 550 minecraft:smooth_basalt
fill 119 199 551 119 202 551 minecraft:blackstone
setblock 121 199 513 minecraft:smooth_basalt
setblock 122 199 511 minecraft:blackstone
setblock 122 199 512 minecraft:smooth_basalt
setblock 123 199 511 minecraft:smooth_basalt
fill 123 199 512 126 199 512 minecraft:blackstone
setblock 123 199 551 minecraft:smooth_basalt
fill 124 199 511 124 202 511 minecraft:blackstone
fill 124 199 551 124 202 551 minecraft:blackstone
setblock 127 199 511 minecraft:blackstone
setblock 127 199 512 minecraft:smooth_basalt
fill 127 199 550 127 200 550 minecraft:blackstone
setblock 128 199 511 minecraft:smooth_basalt
fill 128 199 512 128 202 512 minecraft:blackstone
setblock 128 199 551 minecraft:smooth_basalt
fill 129 199 511 130 201 511 minecraft:blackstone
setblock 129 199 550 minecraft:smooth_basalt
fill 129 199 551 129 202 551 minecraft:blackstone
fill 130 199 510 130 307 510 minecraft:basalt
setblock 130 199 513 minecraft:blackstone
fill 130 199 550 130 202 550 minecraft:blackstone
setblock 131 199 513 minecraft:smooth_basalt
setblock 132 199 512 minecraft:smooth_basalt
fill 132 199 513 132 201 513 minecraft:blackstone
fill 132 199 534 132 199 536 minecraft:blackstone
setblock 132 199 537 minecraft:smooth_basalt
fill 132 199 538 132 200 540 minecraft:blackstone
setblock 133 199 511 minecraft:smooth_basalt
fill 133 199 512 133 202 512 minecraft:blackstone
setblock 133 199 515 minecraft:blackstone
setblock 133 199 531 minecraft:smooth_basalt
fill 133 199 532 133 202 532 minecraft:blackstone
setblock 133 199 535 minecraft:blackstone
setblock 133 199 536 minecraft:smooth_basalt
fill 133 199 537 133 202 537 minecraft:blackstone
fill 133 199 539 133 199 540 minecraft:blackstone
setblock 133 199 541 minecraft:smooth_basalt
fill 133 199 542 133 202 542 minecraft:blackstone
fill 133 199 544 133 199 545 minecraft:blackstone
setblock 133 199 546 minecraft:smooth_basalt
fill 133 199 547 133 201 547 minecraft:blackstone
setblock 133 199 551 minecraft:smooth_basalt
fill 133 199 552 133 307 552 minecraft:basalt
fill 134 199 510 134 307 510 minecraft:basalt
fill 134 199 511 134 202 511 minecraft:blackstone
setblock 134 199 514 minecraft:blackstone
setblock 134 199 515 minecraft:smooth_basalt
fill 134 199 516 135 201 516 minecraft:blackstone
setblock 134 199 519 minecraft:blackstone
fill 134 199 528 134 199 529 minecraft:blackstone
setblock 134 199 530 minecraft:smooth_basalt
fill 134 199 531 134 202 531 minecraft:blackstone
setblock 134 199 535 minecraft:smooth_basalt
fill 134 199 536 135 201 536 minecraft:blackstone
setblock 134 199 539 minecraft:blackstone
setblock 134 199 540 minecraft:smooth_basalt
fill 134 199 541 134 202 541 minecraft:blackstone
setblock 134 199 545 minecraft:smooth_basalt
fill 134 199 546 134 202 546 minecraft:blackstone
setblock 134 199 550 minecraft:smooth_basalt
fill 134 199 551 134 202 551 minecraft:blackstone
setblock 135 199 514 minecraft:smooth_basalt
fill 135 199 515 135 202 515 minecraft:blackstone
setblock 135 199 519 minecraft:smooth_basalt
fill 135 199 520 135 199 523 minecraft:blackstone
setblock 135 199 524 minecraft:smooth_basalt
fill 135 199 525 135 202 525 minecraft:blackstone
setblock 135 199 529 minecraft:smooth_basalt
fill 135 199 530 135 202 530 minecraft:blackstone
setblock 135 199 534 minecraft:smooth_basalt
fill 135 199 535 135 202 535 minecraft:blackstone
setblock 135 199 538 minecraft:blackstone
setblock 135 199 539 minecraft:smooth_basalt
fill 135 199 540 135 202 540 minecraft:blackstone
setblock 135 199 544 minecraft:smooth_basalt
fill 135 199 545 135 202 545 minecraft:blackstone
setblock 135 199 549 minecraft:smooth_basalt
fill 135 199 550 135 202 550 minecraft:blackstone
fill 136 199 516 136 307 516 minecraft:basalt
fill 136 199 536 136 307 537 minecraft:basalt
fill 136 199 540 136 307 540 minecraft:basalt
fill 136 199 543 136 307 543 minecraft:basalt
fill 136 199 549 136 307 550 minecraft:basalt
setblock 95 200 513 minecraft:smooth_basalt
fill 95 200 514 95 203 514 minecraft:blackstone
setblock 95 200 517 minecraft:blackstone
setblock 95 200 518 minecraft:smooth_basalt
fill 95 200 519 95 203 519 minecraft:blackstone
setblock 95 200 523 minecraft:smooth_basalt
fill 95 200 524 95 203 524 minecraft:blackstone
setblock 95 200 528 minecraft:smooth_basalt
fill 95 200 529 95 203 529 minecraft:blackstone
setblock 95 200 533 minecraft:smooth_basalt
fill 95 200 534 95 203 534 minecraft:blackstone
setblock 95 200 537 minecraft:blackstone
setblock 95 200 538 minecraft:smooth_basalt
fill 95 200 539 95 203 539 minecraft:blackstone
setblock 95 200 543 minecraft:smooth_basalt
fill 95 200 544 95 203 544 minecraft:blackstone
setblock 95 200 548 minecraft:smooth_basalt
fill 95 200 549 95 201 549 minecraft:blackstone
setblock 96 200 511 minecraft:blackstone
setblock 96 200 512 minecraft:smooth_basalt
fill 96 200 513 96 202 513 minecraft:blackstone
setblock 96 200 517 minecraft:smooth_basalt
fill 96 200 518 97 202 518 minecraft:blackstone
setblock 96 200 522 minecraft:smooth_basalt
fill 96 200 523 96 203 523 minecraft:blackstone
setblock 96 200 527 minecraft:smooth_basalt
fill 96 200 528 96 202 528 minecraft:blackstone
setblock 96 200 532 minecraft:smooth_basalt
fill 96 200 533 96 203 533 minecraft:blackstone
setblock 96 200 537 minecraft:smooth_basalt
fill 96 200 538 96 203 538 minecraft:blackstone
setblock 96 200 542 minecraft:smooth_basalt
fill 96 200 543 96 202 543 minecraft:blackstone
setblock 97 200 511 minecraft:smooth_basalt
fill 97 200 512 97 201 512 minecraft:blackstone
setblock 97 200 515 minecraft:blackstone
setblock 97 200 516 minecraft:smooth_basalt
fill 97 200 517 97 202 517 minecraft:blackstone
setblock 97 200 531 minecraft:smooth_basalt
fill 97 200 532 97 202 532 minecraft:blackstone
setblock 97 200 536 minecraft:smooth_basalt
fill 97 200 537 97 203 537 minecraft:blackstone
setblock 97 200 551 minecraft:smooth_basalt
fill 98 200 511 98 202 511 minecraft:blackstone
setblock 98 200 535 minecraft:smooth_basalt
setblock 98 200 536 minecraft:blackstone
setblock 102 200 511 minecraft:smooth_basalt
fill 103 200 511 103 202 511 minecraft:blackstone
fill 104 200 512 105 200 512 minecraft:blackstone
setblock 106 200 512 minecraft:smooth_basalt
setblock 107 200 511 minecraft:smooth_basalt
fill 107 200 512 107 203 512 minecraft:blackstone
fill 108 200 511 108 203 511 minecraft:blackstone
fill 108 200 551 108 202 551 minecraft:blackstone
setblock 109 200 513 minecraft:blackstone
setblock 109 200 514 minecraft:smooth_basalt
setblock 110 200 513 minecraft:smooth_basalt
fill 110 200 514 110 203 514 minecraft:blackstone
setblock 111 200 512 minecraft:smooth_basalt
fill 111 200 513 111 203 513 minecraft:blackstone
fill 111 200 515 112 200 515 minecraft:blackstone
setblock 112 200 511 minecraft:smooth_basalt
fill 112 200 512 112 203 512 minecraft:blackstone
setblock 112 200 551 minecraft:smooth_basalt
fill 113 200 511 113 203 511 minecraft:blackstone
setblock 113 200 515 minecraft:smooth_basalt
setblock 113 200 550 minecraft:smooth_basalt
fill 113 200 551 116 200 551 minecraft:blackstone
setblock 114 200 514 minecraft:smooth_basalt
fill 114 200 515 115 201 515 minecraft:blackstone
fill 114 200 550 114 202 550 minecraft:blackstone
setblock 115 200 513 minecraft:smooth_basalt
fill 115 200 514 115 203 514 minecraft:blackstone
setblock 116 200 512 minecraft:smooth_basalt
fill 116 200 513 116 203 513 minecraft:blackstone
setblock 117 200 511 minecraft:smooth_basalt
fill 117 200 512 117 203 512 minecraft:blackstone
setblock 117 200 551 minecraft:smooth_basalt
fill 118 200 511 118 203 511 minecraft:blackstone
setblock 118 200 514 minecraft:blackstone
setblock 118 200 550 minecraft:smooth_basalt
fill 118 200 551 118 203 551 minecraft:blackstone
setblock 120 200 513 minecraft:smooth_basalt
setblock 121 200 512 minecraft:smooth_basalt
setblock 121 200 513 minecraft:blackstone
setblock 122 200 511 minecraft:smooth_basalt
fill 122 200 512 125 200 512 minecraft:blackstone
setblock 122 200 551 minecraft:smooth_basalt
fill 123 200 511 123 203 511 minecraft:blackstone
fill 123 200 551 123 202 551 minecraft:blackstone
setblock 126 200 512 minecraft:smooth_basalt
setblock 127 200 511 minecraft:smooth_basalt
fill 127 200 512 127 202 512 minecraft:blackstone
setblock 127 200 551 minecraft:smooth_basalt
fill 128 200 511 128 203 511 minecraft:blackstone
fill 128 200 517 132 201 521 minecraft:blackstone
setblock 128 200 550 minecraft:smooth_basalt
fill 128 200 551 128 203 551 minecraft:blackstone
fill 129 200 550 129 203 550 minecraft:blackstone
setblock 130 200 513 minecraft:smooth_basalt
setblock 131 200 511 minecraft:blackstone
setblock 131 200 512 minecraft:smooth_basalt
fill 131 200 513 131 201 513 minecraft:blackstone
setblock 132 200 511 minecraft:smooth_basalt
fill 132 200 512 132 203 512 minecraft:blackstone
fill 132 200 534 132 200 535 minecraft:blackstone
setblock 132 200 536 minecraft:smooth_basalt
fill 132 200 537 132 203 537 minecraft:blackstone
setblock 132 200 541 minecraft:smooth_basalt
fill 132 200 542 132 203 542 minecraft:blackstone
setblock 132 200 551 minecraft:smooth_basalt
fill 133 200 511 133 203 511 minecraft:blackstone
setblock 133 200 515 minecraft:smooth_basalt
fill 133 200 516 133 202 516 minecraft:blackstone
setblock 133 200 519 minecraft:blackstone
fill 133 200 531 133 201 531 minecraft:blackstone
setblock 133 200 535 minecraft:smooth_basalt
fill 133 200 536 133 203 536 minecraft:blackstone
setblock 133 200 539 minecraft:blackstone
setblock 133 200 540 minecraft:smooth_basalt
fill 133 200 541 133 203 541 minecraft:blackstone
setblock 133 200 544 minecraft:blackstone
setblock 133 200 545 minecraft:smooth_basalt
fill 133 200 546 133 202 546 minecraft:blackstone
setblock 133 200 550 minecraft:smooth_basalt
fill 133 200 551 133 203 551 minecraft:blackstone
setblock 134 200 514 minecraft:smooth_basalt
fill 134 200 515 134 203 515 minecraft:blackstone
setblock 134 200 519 minecraft:smooth_basalt
fill 134 200 520 135 202 520 minecraft:blackstone
setblock 134 200 528 minecraft:blackstone
setblock 134 200 529 minecraft:smooth_basalt
fill 134 200 530 134 203 530 minecraft:blackstone
setblock 134 200 534 minecraft:smooth_basalt
fill 134 200 535 134 203 535 minecraft:blackstone
setblock 134 200 539 minecraft:smooth_basalt
fill 134 200 540 134 203 540 minecraft:blackstone
setblock 134 200 544 minecraft:smooth_basalt
fill 134 200 545 134 203 545 minecraft:blackstone
setblock 134 200 549 minecraft:smooth_basalt
fill 134 200 550 134 202 550 minecraft:blackstone
setblock 135 200 513 minecraft:smooth_basalt
fill 135 200 514 135 203 514 minecraft:blackstone
setblock 135 200 518 minecraft:smooth_basalt
fill 135 200 519 135 203 519 minecraft:blackstone
fill 135 200 521 135 200 522 minecraft:blackstone
setblock 135 200 523 minecraft:smooth_basalt
fill 135 200 524 135 203 524 minecraft:blackstone
setblock 135 200 528 minecraft:smooth_basalt
fill 135 200 529 135 203 529 minecraft:blackstone
setblock 135 200 533 minecraft:smooth_basalt
fill 135 200 534 135 203 534 minecraft:blackstone
setblock 135 200 538 minecraft:smooth_basalt
fill 135 200 539 135 203 539 minecraft:blackstone
setblock 135 200 543 minecraft:smooth_basalt
fill 135 200 544 135 203 544 minecraft:blackstone
setblock 135 200 548 minecraft:smooth_basalt
fill 135 200 549 135 203 549 minecraft:blackstone
setblock 95 201 512 minecraft:smooth_basalt
fill 95 201 513 95 204 513 minecraft:blackstone
setblock 95 201 517 minecraft:smooth_basalt
fill 95 201 518 95 204 518 minecraft:blackstone
setblock 95 201 521 minecraft:blackstone
setblock 95 201 522 minecraft:smooth_basalt
fill 95 201 523 95 204 523 minecraft:blackstone
setblock 95 201 527 minecraft:smooth_basalt
fill 95 201 528 95 204 528 minecraft:blackstone
setblock 95 201 531 minecraft:blackstone
setblock 95 201 532 minecraft:smooth_basalt
fill 95 201 533 95 204 533 minecraft:blackstone
setblock 95 201 537 minecraft:smooth_basalt
fill 95 201 538 95 204 538 minecraft:blackstone
setblock 95 201 542 minecraft:smooth_basalt
fill 95 201 543 95 204 543 minecraft:blackstone
setblock 95 201 547 minecraft:smooth_basalt
setblock 95 201 548 minecraft:blackstone
setblock 96 201 511 minecraft:smooth_basalt
fill 96 201 512 96 202 512 minecraft:blackstone
fill 96 201 514 96 202 514 minecraft:blackstone
setblock 96 201 516 minecraft:smooth_basalt
fill 96 201 517 96 204 517 minecraft:blackstone
setblock 96 201 521 minecraft:smooth_basalt
fill 96 201 522 96 204 522 minecraft:blackstone
setblock 96 201 526 minecraft:smooth_basalt
fill 96 201 527 96 202 527 minecraft:blackstone
setblock 96 201 531 minecraft:smooth_basalt
fill 96 201 532 96 204 532 minecraft:blackstone
setblock 96 201 536 minecraft:smooth_basalt
fill 96 201 537 96 204 537 minecraft:blackstone
setblock 96 201 540 minecraft:blackstone
setblock 96 201 541 minecraft:smooth_basalt
fill 96 201 542 96 204 542 minecraft:blackstone
setblock 96 201 551 minecraft:smooth_basalt
fill 97 201 511 97 202 511 minecraft:blackstone
setblock 97 201 515 minecraft:smooth_basalt
setblock 97 201 516 minecraft:blackstone
setblock 97 201 530 minecraft:smooth_basalt
setblock 97 201 531 minecraft:blackstone
setblock 97 201 535 minecraft:smooth_basalt
fill 97 201 536 97 203 536 minecraft:blackstone
setblock 97 201 540 minecraft:smooth_basalt
setblock 101 201 511 minecraft:smooth_basalt
setblock 102 201 511 minecraft:blackstone
setblock 105 201 512 minecraft:smooth_basalt
setblock 106 201 511 minecraft:smooth_basalt
fill 106 201 512 106 202 513 minecraft:blackstone
fill 107 201 511 107 204 511 minecraft:blackstone
setblock 108 201 514 minecraft:smooth_basalt
setblock 109 201 513 minecraft:smooth_basalt
fill 109 201 514 109 204 514 minecraft:blackstone
setblock 110 201 512 minecraft:smooth_basalt
fill 110 201 513 110 204 513 minecraft:blackstone
setblock 111 201 511 minecraft:smooth_basalt
fill 111 201 512 111 204 512 minecraft:blackstone
setblock 111 201 515 minecraft:blackstone
setblock 111 201 551 minecraft:smooth_basalt
fill 112 201 511 112 204 511 minecraft:blackstone
setblock 112 201 515 minecraft:smooth_basalt
setblock 112 201 550 minecraft:smooth_basalt
fill 112 201 551 115 201 551 minecraft:blackstone
setblock 113 201 514 minecraft:smooth_basalt
fill 113 201 515 113 202 515 minecraft:blackstone
fill 113 201 550 113 202 550 minecraft:blackstone
setblock 114 201 513 minecraft:smooth_basalt
fill 114 201 514 114 203 514 minecraft:blackstone
setblock 115 201 512 minecraft:smooth_basalt
fill 115 201 513 115 204 513 minecraft:blackstone
setblock 116 201 511 minecraft:smooth_basalt
fill 116 201 512 116 204 512 minecraft:blackstone
setblock 116 201 551 minecraft:smooth_basalt
fill 117 201 511 117 204 511 minecraft:blackstone
setblock 117 201 550 minecraft:smooth_basalt
fill 117 201 551 117 204 551 minecraft:blackstone
setblock 119 201 513 minecraft:smooth_basalt
setblock 120 201 512 minecraft:smooth_basalt
setblock 120 201 513 minecraft:blackstone
setblock 121 201 511 minecraft:smooth_basalt
fill 121 201 512 124 201 512 minecraft:blackstone
setblock 121 201 551 minecraft:smooth_basalt
fill 122 201 511 122 203 511 minecraft:blackstone
fill 122 201 551 122 202 551 minecraft:blackstone
setblock 125 201 512 minecraft:smooth_basalt
setblock 126 201 511 minecraft:smooth_basalt
fill 126 201 512 126 202 512 minecraft:blackstone
setblock 126 201 551 minecraft:smooth_basalt
fill 127 201 511 127 204 511 minecraft:blackstone
fill 127 201 551 127 204 551 minecraft:blackstone
fill 128 201 550 128 203 550 minecraft:blackstone
setblock 130 201 512 minecraft:smooth_basalt
setblock 130 201 513 minecraft:blackstone
setblock 131 201 511 minecraft:smooth_basalt
fill 131 201 512 131 203 512 minecraft:blackstone
setblock 131 201 551 minecraft:smooth_basalt
fill 132 201 511 132 204 511 minecraft:blackstone
setblock 132 201 534 minecraft:blackstone
setblock 132 201 535 minecraft:smooth_basalt
fill 132 201 536 132 204 536 minecraft:blackstone
fill 132 201 538 132 201 539 minecraft:blackstone
setblock 132 201 540 minecraft:smooth_basalt
fill 132 201 541 132 204 541 minecraft:blackstone
setblock 132 201 550 minecraft:smooth_basalt
fill 132 201 551 132 204 551 minecraft:blackstone
setblock 133 201 513 minecraft:blackstone
setblock 133 201 514 minecraft:smooth_basalt
fill 133 201 515 133 202 515 minecraft:blackstone
fill 133 201 517 134 201 517 minecraft:blackstone
setblock 133 201 534 minecraft:smooth_basalt
fill 133 201 535 133 204 535 minecraft:blackstone
setblock 133 201 539 minecraft:smooth_basalt
fill 133 201 540 133 204 540 minecraft:blackstone
setblock 133 201 544 minecraft:smooth_basalt
fill 133 201 545 133 204 545 minecraft:blackstone
fill 133 201 550 133 203 550 minecraft:blackstone
setblock 134 201 513 minecraft:smooth_basalt
fill 134 201 514 134 203 514 minecraft:blackstone
setblock 134 201 518 minecraft:smooth_basalt
fill 134 201 519 134 204 519 minecraft:blackstone
fill 134 201 521 135 201 521 minecraft:blackstone
setblock 134 201 528 minecraft:smooth_basalt
fill 134 201 529 134 202 529 minecraft:blackstone
setblock 134 201 533 minecraft:smooth_basalt
fill 134 201 534 134 204 534 minecraft:blackstone
setblock 134 201 538 minecraft:smooth_basalt
fill 134 201 539 134 204 539 minecraft:blackstone
setblock 134 201 543 minecraft:smooth_basalt
fill 134 201 544 134 204 544 minecraft:blackstone
setblock 134 201 548 minecraft:smooth_basalt
fill 134 201 549 134 202 549 minecraft:blackstone
setblock 135 201 512 minecraft:smooth_basalt
fill 135 201 513 135 204 513 minecraft:blackstone
setblock 135 201 517 minecraft:smooth_basalt
fill 135 201 518 135 204 518 minecraft:blackstone
setblock 135 201 522 minecraft:smooth_basalt
fill 135 201 523 135 204 523 minecraft:blackstone
setblock 135 201 527 minecraft:smooth_basalt
fill 135 201 528 135 204 528 minecraft:blackstone
setblock 135 201 532 minecraft:smooth_basalt
fill 135 201 533 135 204 533 minecraft:blackstone
setblock 135 201 537 minecraft:smooth_basalt
fill 135 201 538 135 204 538 minecraft:blackstone
setblock 135 201 542 minecraft:smooth_basalt
fill 135 201 543 135 204 543 minecraft:blackstone
setblock 135 201 547 minecraft:smooth_basalt
fill 135 201 548 135 204 548 minecraft:blackstone
setblock 95 202 511 minecraft:smooth_basalt
fill 95 202 512 95 204 512 minecraft:blackstone
setblock 95 202 516 minecraft:smooth_basalt
fill 95 202 517 95 205 517 minecraft:blackstone
setblock 95 202 521 minecraft:smooth_basalt
fill 95 202 522 95 205 522 minecraft:blackstone
setblock 95 202 526 minecraft:smooth_basalt
fill 95 202 527 95 205 527 minecraft:blackstone
setblock 95 202 531 minecraft:smooth_basalt
fill 95 202 532 95 205 532 minecraft:blackstone
setblock 95 202 536 minecraft:smooth_basalt
fill 95 202 537 95 205 537 minecraft:blackstone
setblock 95 202 541 minecraft:smooth_basalt
fill 95 202 542 95 205 542 minecraft:blackstone
setblock 95 202 546 minecraft:smooth_basalt
setblock 95 202 547 minecraft:blackstone
fill 96 202 511 96 203 511 minecraft:blackstone
setblock 96 202 515 minecraft:smooth_basalt
fill 96 202 516 96 205 516 minecraft:blackstone
setblock 96 202 520 minecraft:smooth_basalt
fill 96 202 521 96 205 521 minecraft:blackstone
setblock 96 202 525 minecraft:smooth_basalt
setblock 96 202 526 minecraft:blackstone
setblock 96 202 530 minecraft:smooth_basalt
fill 96 202 531 96 203 531 minecraft:blackstone
setblock 96 202 535 minecraft:smooth_basalt
fill 96 202 536 96 205 536 minecraft:blackstone
setblock 96 202 540 minecraft:smooth_basalt
fill 96 202 541 96 205 541 minecraft:blackstone
setblock 97 202 534 minecraft:smooth_basalt
fill 97 202 535 97 203 535 minecraft:blackstone
setblock 97 202 539 minecraft:smooth_basalt
setblock 105 202 511 minecraft:smooth_basalt
fill 105 202 512 105 203 512 minecraft:blackstone
fill 106 202 511 106 205 511 minecraft:blackstone
setblock 108 202 513 minecraft:smooth_basalt
fill 108 202 514 108 203 514 minecraft:blackstone
setblock 109 202 511 minecraft:blackstone
setblock 109 202 512 minecraft:smooth_basalt
fill 109 202 513 109 205 513 minecraft:blackstone
setblock 110 202 511 minecraft:smooth_basalt
fill 110 202 512 110 205 512 minecraft:blackstone
setblock 110 202 551 minecraft:smooth_basalt
fill 111 202 511 111 205 511 minecraft:blackstone
setblock 111 202 515 minecraft:smooth_basalt
fill 111 202 551 114 202 551 minecraft:blackstone
setblock 112 202 514 minecraft:smooth_basalt
setblock 112 202 515 minecraft:blackstone
setblock 112 202 550 minecraft:blackstone
setblock 113 202 513 minecraft:smooth_basalt
fill 113 202 514 113 204 514 minecraft:blackstone
setblock 114 202 512 minecraft:smooth_basalt
fill 114 202 513 114 205 513 minecraft:blackstone
setblock 114 202 515 minecraft:blackstone
setblock 115 202 511 minecraft:smooth_basalt
fill 115 202 512 115 205 512 minecraft:blackstone
setblock 115 202 551 minecraft:smooth_basalt
fill 116 202 511 116 205 511 minecraft:blackstone
fill 116 202 551 116 204 551 minecraft:blackstone
setblock 118 202 513 minecraft:smooth_basalt
setblock 119 202 512 minecraft:smooth_basalt
setblock 120 202 511 minecraft:smooth_basalt
fill 120 202 512 121 202 512 minecraft:blackstone
setblock 120 202 551 minecraft:smooth_basalt
fill 121 202 511 121 203 511 minecraft:blackstone
setblock 121 202 551 minecraft:blackstone
setblock 125 202 511 minecraft:smooth_basalt
setblock 125 202 551 minecraft:smooth_basalt
fill 126 202 511 126 204 511 minecraft:blackstone
fill 126 202 551 126 205 551 minecraft:blackstone
setblock 129 202 511 minecraft:blackstone
setblock 129 202 512 minecraft:smooth_basalt
fill 129 202 518 131 203 520 minecraft:smooth_basalt
setblock 130 202 511 minecraft:smooth_basalt
fill 130 202 512 130 203 512 minecraft:blackstone
setblock 130 202 551 minecraft:smooth_basalt
fill 131 202 511 131 205 511 minecraft:blackstone
setblock 131 202 550 minecraft:smooth_basalt
fill 131 202 551 131 205 551 minecraft:blackstone
setblock 132 202 534 minecraft:smooth_basalt
fill 132 202 535 132 203 535 minecraft:blackstone
setblock 132 202 538 minecraft:blackstone
setblock 132 202 539 minecraft:smooth_basalt
fill 132 202 540 132 205 540 minecraft:blackstone
setblock 132 202 543 minecraft:blackstone
fill 132 202 550 132 203 550 minecraft:blackstone
setblock 133 202 514 minecraft:blackstone
setblock 133 202 517 minecraft:blackstone
setblock 133 202 533 minecraft:smooth_basalt
fill 133 202 534 133 204 534 minecraft:blackstone
setblock 133 202 538 minecraft:smooth_basalt
fill 133 202 539 133 205 539 minecraft:blackstone
setblock 133 202 543 minecraft:smooth_basalt
fill 133 202 544 133 205 544 minecraft:blackstone
setblock 134 202 512 minecraft:smooth_basalt
fill 134 202 513 134 203 513 minecraft:blackstone
setblock 134 202 516 minecraft:blackstone
setblock 134 202 517 minecraft:smooth_basalt
fill 134 202 518 134 205 518 minecraft:blackstone
setblock 134 202 521 minecraft:blackstone
setblock 134 202 532 minecraft:smooth_basalt
fill 134 202 533 134 205 533 minecraft:blackstone
setblock 134 202 536 minecraft:blackstone
setblock 134 202 537 minecraft:smooth_basalt
fill 134 202 538 134 205 538 minecraft:blackstone
setblock 134 202 542 minecraft:smooth_basalt
fill 134 202 543 134 205 543 minecraft:blackstone
setblock 134 202 547 minecraft:smooth_basalt
fill 134 202 548 134 203 548 minecraft:blackstone
setblock 135 202 511 minecraft:smooth_basalt
fill 135 202 512 135 204 512 minecraft:blackstone
setblock 135 202 516 minecraft:smooth_basalt
fill 135 202 517 135 205 517 minecraft:blackstone
setblock 135 202 521 minecraft:smooth_basalt
fill 135 202 522 135 205 522 minecraft:blackstone
setblock 135 202 526 minecraft:smooth_basalt
fill 135 202 527 135 204 527 minecraft:blackstone
setblock 135 202 531 minecraft:smooth_basalt
fill 135 202 532 135 205 532 minecraft:blackstone
setblock 135 202 536 minecraft:smooth_basalt
fill 135 202 537 135 205 537 minecraft:blackstone
setblock 135 202 541 minecraft:smooth_basalt
fill 135 202 542 135 205 542 minecraft:blackstone
setblock 135 202 546 minecraft:smooth_basalt
fill 135 202 547 135 205 547 minecraft:blackstone
setblock 135 202 551 minecraft:smooth_basalt
setblock 95 203 511 minecraft:blackstone
setblock 95 203 515 minecraft:smooth_basalt
fill 95 203 516 95 206 516 minecraft:blackstone
setblock 95 203 520 minecraft:smooth_basalt
fill 95 203 521 95 206 521 minecraft:blackstone
setblock 95 203 525 minecraft:smooth_basalt
fill 95 203 526 95 206 526 minecraft:blackstone
setblock 95 203 530 minecraft:smooth_basalt
fill 95 203 531 95 206 531 minecraft:blackstone
setblock 95 203 535 minecraft:smooth_basalt
fill 95 203 536 95 206 536 minecraft:blackstone
setblock 95 203 540 minecraft:smooth_basalt
fill 95 203 541 95 206 541 minecraft:blackstone
setblock 95 203 545 minecraft:smooth_basalt
setblock 95 203 546 minecraft:blackstone
setblock 96 203 514 minecraft:smooth_basalt
fill 96 203 515 96 204 515 minecraft:blackstone
setblock 96 203 518 minecraft:blackstone
setblock 96 203 519 minecraft:smooth_basalt
fill 96 203 520 96 206 520 minecraft:blackstone
setblock 96 203 524 minecraft:smooth_basalt
setblock 96 203 525 minecraft:blackstone
setblock 96 203 529 minecraft:smooth_basalt
setblock 96 203 530 minecraft:blackstone
setblock 96 203 534 minecraft:smooth_basalt
fill 96 203 535 96 205 535 minecraft:blackstone
setblock 96 203 539 minecraft:smooth_basalt
fill 96 203 540 96 205 540 minecraft:blackstone
setblock 97 203 538 minecraft:smooth_basalt
setblock 104 203 511 minecraft:smooth_basalt
fill 105 203 511 105 206 511 minecraft:blackstone
fill 106 203 512 106 204 512 minecraft:blackstone
setblock 107 203 513 minecraft:smooth_basalt
setblock 108 203 512 minecraft:smooth_basalt
fill 108 203 513 108 205 513 minecraft:blackstone
setblock 109 203 511 minecraft:smooth_basalt
fill 109 203 512 109 206 512 minecraft:blackstone
setblock 109 203 551 minecraft:smooth_basalt
fill 110 203 511 110 206 511 minecraft:blackstone
fill 110 203 551 113 203 551 minecraft:blackstone
setblock 111 203 514 minecraft:smooth_basalt
setblock 112 203 513 minecraft:smooth_basalt
fill 112 203 514 112 204 514 minecraft:blackstone
setblock 113 203 512 minecraft:smooth_basalt
fill 113 203 513 113 205 513 minecraft:blackstone
setblock 114 203 511 minecraft:smooth_basalt
fill 114 203 512 114 206 512 minecraft:blackstone
setblock 114 203 551 minecraft:smooth_basalt
fill 115 203 511 115 206 511 minecraft:blackstone
fill 115 203 551 115 205 551 minecraft:blackstone
setblock 117 203 513 minecraft:smooth_basalt
setblock 118 203 512 minecraft:smooth_basalt
setblock 119 203 511 minecraft:smooth_basalt
setblock 119 203 512 minecraft:blackstone
setblock 119 203 551 minecraft:smooth_basalt
fill 120 203 511 120 204 511 minecraft:blackstone
setblock 124 203 511 minecraft:smooth_basalt
setblock 124 203 551 minecraft:smooth_basalt
setblock 125 203 511 minecraft:blackstone
fill 125 203 551 125 204 551 minecraft:blackstone
setblock 128 203 512 minecraft:smooth_basalt
setblock 129 203 511 minecraft:smooth_basalt
setblock 129 203 512 minecraft:blackstone
setblock 129 203 551 minecraft:smooth_basalt
fill 130 203 511 130 205 511 minecraft:blackstone
setblock 130 203 550 minecraft:smooth_basalt
fill 130 203 551 130 206 551 minecraft:blackstone
fill 131 203 550 131 204 550 minecraft:blackstone
setblock 132 203 538 minecraft:smooth_basalt
fill 132 203 539 132 206 539 minecraft:blackstone
setblock 132 203 543 minecraft:smooth_basalt
setblock 133 203 512 minecraft:smooth_basalt
setblock 133 203 532 minecraft:smooth_basalt
fill 133 203 533 133 204 533 minecraft:blackstone
setblock 133 203 537 minecraft:smooth_basalt
fill 133 203 538 133 206 538 minecraft:blackstone
setblock 133 203 542 minecraft:smooth_basalt
fill 133 203 543 133 206 543 minecraft:blackstone
setblock 134 203 511 minecraft:smooth_basalt
setblock 134 203 516 minecraft:smooth_basalt
fill 134 203 517 134 204 517 minecraft:blackstone
setblock 134 203 520 minecraft:blackstone
setblock 134 203 521 minecraft:smooth_basalt
setblock 134 203 531 minecraft:smooth_basalt
fill 134 203 532 134 205 532 minecraft:blackstone
setblock 134 203 536 minecraft:smooth_basalt
fill 134 203 537 134 206 537 minecraft:blackstone
setblock 134 203 541 minecraft:smooth_basalt
fill 134 203 542 134 206 542 minecraft:blackstone
setblock 134 203 546 minecraft:smooth_basalt
fill 134 203 547 134 204 547 minecraft:blackstone
setblock 134 203 551 minecraft:smooth_basalt
setblock 135 203 511 minecraft:blackstone
setblock 135 203 515 minecraft:smooth_basalt
fill 135 203 516 135 206 516 minecraft:blackstone
setblock 135 203 520 minecraft:smooth_basalt
fill 135 203 521 135 206 521 minecraft:blackstone
setblock 135 203 525 minecraft:smooth_basalt
fill 135 203 526 135 205 526 minecraft:blackstone
setblock 135 203 530 minecraft:smooth_basalt
fill 135 203 531 135 206 531 minecraft:blackstone
setblock 135 203 535 minecraft:smooth_basalt
fill 135 203 536 135 206 536 minecraft:blackstone
setblock 135 203 540 minecraft:smooth_basalt
fill 135 203 541 135 206 541 minecraft:blackstone
setblock 135 203 545 minecraft:smooth_basalt
fill 135 203 546 135 206 546 minecraft:blackstone
setblock 135 203 550 minecraft:smooth_basalt
setblock 135 203 551 minecraft:blackstone
setblock 95 204 514 minecraft:smooth_basalt
fill 95 204 515 95 207 515 minecraft:blackstone
setblock 95 204 519 minecraft:smooth_basalt
fill 95 204 520 95 207 520 minecraft:blackstone
setblock 95 204 524 minecraft:smooth_basalt
fill 95 204 525 95 207 525 minecraft:blackstone
setblock 95 204 529 minecraft:smooth_basalt
fill 95 204 530 95 206 530 minecraft:blackstone
setblock 95 204 534 minecraft:smooth_basalt
fill 95 204 535 95 207 535 minecraft:blackstone
setblock 95 204 539 minecraft:smooth_basalt
fill 95 204 540 95 207 540 minecraft:blackstone
setblock 95 204 544 minecraft:smooth_basalt
setblock 95 204 545 minecraft:blackstone
setblock 96 204 518 minecraft:smooth_basalt
fill 96 204 519 96 207 519 minecraft:blackstone
setblock 96 204 523 minecraft:smooth_basalt
setblock 96 204 524 minecraft:blackstone
setblock 96 204 533 minecraft:smooth_basalt
setblock 96 204 534 minecraft:blackstone
setblock 96 204 538 minecraft:smooth_basalt
fill 96 204 539 96 205 539 minecraft:blackstone
setblock 107 204 512 minecraft:smooth_basalt
setblock 107 204 513 minecraft:blackstone
setblock 108 204 511 minecraft:smooth_basalt
fill 108 204 512 108 207 512 minecraft:blackstone
fill 109 204 511 109 207 511 minecraft:blackstone
fill 109 204 551 112 204 551 minecraft:blackstone
setblock 110 204 514 minecraft:smooth_basalt
setblock 111 204 513 minecraft:smooth_basalt
setblock 111 204 514 minecraft:blackstone
setblock 112 204 512 minecraft:smooth_basalt
fill 112 204 513 112 206 513 minecraft:blackstone
setblock 113 204 511 minecraft:smooth_basalt
fill 113 204 512 113 207 512 minecraft:blackstone
setblock 113 204 551 minecraft:smooth_basalt
fill 114 204 511 114 207 511 minecraft:blackstone
fill 114 204 551 114 206 551 minecraft:blackstone
setblock 117 204 512 minecraft:smooth_basalt
setblock 118 204 511 minecraft:smooth_basalt
setblock 119 204 511 minecraft:blackstone
setblock 128 204 511 minecraft:smooth_basalt
setblock 128 204 551 minecraft:smooth_basalt
fill 129 204 511 129 205 511 minecraft:blackstone
fill 129 204 519 131 206 519 minecraft:smooth_basalt
setblock 129 204 550 minecraft:smooth_basalt
fill 129 204 551 129 207 551 minecraft:blackstone
fill 130 204 518 130 206 518 minecraft:smooth_basalt
fill 130 204 520 130 206 520 minecraft:smooth_basalt
setblock 130 204 550 minecraft:blackstone
setblock 132 204 537 minecraft:smooth_basalt
fill 132 204 538 132 206 538 minecraft:blackstone
setblock 132 204 542 minecraft:smooth_basalt
fill 132 204 543 132 205 543 minecraft:blackstone
setblock 133 204 511 minecraft:smooth_basalt
setblock 133 204 536 minecraft:smooth_basalt
fill 133 204 537 133 207 537 minecraft:blackstone
setblock 133 204 541 minecraft:smooth_basalt
fill 133 204 542 133 207 542 minecraft:blackstone
setblock 133 204 551 minecraft:smooth_basalt
setblock 134 204 511 minecraft:blackstone
setblock 134 204 515 minecraft:smooth_basalt
setblock 134 204 516 minecraft:blackstone
setblock 134 204 520 minecraft:smooth_basalt
setblock 134 204 521 minecraft:blackstone
setblock 134 204 531 minecraft:blackstone
setblock 134 204 535 minecraft:smooth_basalt
fill 134 204 536 134 207 536 minecraft:blackstone
setblock 134 204 540 minecraft:smooth_basalt
fill 134 204 541 134 207 541 minecraft:blackstone
setblock 134 204 545 minecraft:smooth_basalt
fill 134 204 546 134 206 546 minecraft:blackstone
setblock 134 204 551 minecraft:blackstone
setblock 135 204 514 minecraft:smooth_basalt
fill 135 204 515 135 205 515 minecraft:blackstone
setblock 135 204 519 minecraft:smooth_basalt
fill 135 204 520 135 207 520 minecraft:blackstone
setblock 135 204 524 minecraft:smooth_basalt
fill 135 204 525 135 207 525 minecraft:blackstone
setblock 135 204 529 minecraft:smooth_basalt
fill 135 204 530 135 205 530 minecraft:blackstone
setblock 135 204 534 minecraft:smooth_basalt
fill 135 204 535 135 207 535 minecraft:blackstone
setblock 135 204 539 minecraft:smooth_basalt
fill 135 204 540 135 207 540 minecraft:blackstone
setblock 135 204 544 minecraft:smooth_basalt
fill 135 204 545 135 207 545 minecraft:blackstone
setblock 135 204 549 minecraft:smooth_basalt
setblock 95 205 513 minecraft:smooth_basalt
fill 95 205 514 95 206 514 minecraft:blackstone
setblock 95 205 518 minecraft:smooth_basalt
fill 95 205 519 95 208 519 minecraft:blackstone
setblock 95 205 523 minecraft:smooth_basalt
fill 95 205 524 95 208 524 minecraft:blackstone
setblock 95 205 528 minecraft:smooth_basalt
fill 95 205 529 95 206 529 minecraft:blackstone
setblock 95 205 533 minecraft:smooth_basalt
fill 95 205 534 95 207 534 minecraft:blackstone
setblock 95 205 538 minecraft:smooth_basalt
fill 95 205 539 95 208 539 minecraft:blackstone
setblock 95 205 543 minecraft:smooth_basalt
fill 95 205 544 95 206 544 minecraft:blackstone
setblock 96 205 517 minecraft:smooth_basalt
fill 96 205 518 96 207 518 minecraft:blackstone
setblock 96 205 522 minecraft:smooth_basalt
fill 96 205 523 96 208 523 minecraft:blackstone
setblock 96 205 537 minecraft:smooth_basalt
setblock 96 205 538 minecraft:blackstone
setblock 97 205 513 minecraft:light[level=12]
setblock 97 205 521 minecraft:light[level=12]
setblock 97 205 529 minecraft:light[level=12]
setblock 97 205 537 minecraft:light[level=12]
setblock 97 205 545 minecraft:light[level=12]
setblock 105 205 513 minecraft:light[level=12]
setblock 105 205 521 minecraft:light[level=12]
setblock 105 205 529 minecraft:light[level=12]
setblock 105 205 537 minecraft:light[level=12]
setblock 105 205 545 minecraft:light[level=12]
setblock 106 205 512 minecraft:smooth_basalt
setblock 107 205 511 minecraft:smooth_basalt
fill 107 205 512 107 208 512 minecraft:blackstone
fill 108 205 511 108 208 511 minecraft:blackstone
fill 109 205 551 111 205 551 minecraft:blackstone
setblock 110 205 513 minecraft:smooth_basalt
setblock 111 205 512 minecraft:smooth_basalt
fill 111 205 513 111 206 513 minecraft:blackstone
setblock 112 205 511 minecraft:smooth_basalt
fill 112 205 512 112 207 512 minecraft:blackstone
setblock 112 205 551 minecraft:smooth_basalt
fill 113 205 511 113 208 511 minecraft:blackstone
setblock 113 205 521 minecraft:light[level=12]
setblock 113 205 529 minecraft:light[level=12]
setblock 113 205 537 minecraft:light[level=12]
setblock 113 205 545 minecraft:light[level=12]
fill 113 205 551 113 208 551 minecraft:blackstone
setblock 116 205 512 minecraft:smooth_basalt
setblock 117 205 511 minecraft:smooth_basalt
setblock 118 205 511 minecraft:blackstone
setblock 121 205 513 minecraft:light[level=12]
setblock 121 205 521 minecraft:light[level=12]
setblock 121 205 529 minecraft:light[level=12]
setblock 121 205 537 minecraft:light[level=12]
setblock 121 205 545 minecraft:light[level=12]
setblock 127 205 551 minecraft:smooth_basalt
setblock 128 205 511 minecraft:blackstone
fill 128 205 551 128 208 551 minecraft:blackstone
setblock 129 205 513 minecraft:light[level=12]
setblock 129 205 521 minecraft:light[level=12]
setblock 129 205 529 minecraft:light[level=12]
setblock 129 205 537 minecraft:light[level=12]
setblock 129 205 545 minecraft:light[level=12]
setblock 132 205 511 minecraft:smooth_basalt
setblock 132 205 537 minecraft:blackstone
setblock 132 205 541 minecraft:smooth_basalt
fill 132 205 542 132 206 542 minecraft:blackstone
setblock 132 205 551 minecraft:smooth_basalt
setblock 133 205 535 minecraft:smooth_basalt
fill 133 205 536 133 206 536 minecraft:blackstone
setblock 133 205 540 minecraft:smooth_basalt
fill 133 205 541 133 208 541 minecraft:blackstone
setblock 133 205 545 minecraft:smooth_basalt
setblock 133 205 551 minecraft:blackstone
setblock 134 205 519 minecraft:smooth_basalt
setblock 134 205 520 minecraft:blackstone
setblock 134 205 534 minecraft:smooth_basalt
fill 134 205 535 134 207 535 minecraft:blackstone
setblock 134 205 539 minecraft:smooth_basalt
fill 134 205 540 134 208 540 minecraft:blackstone
setblock 134 205 544 minecraft:smooth_basalt
fill 134 205 545 134 208 545 minecraft:blackstone
setblock 135 205 514 minecraft:blackstone
setblock 135 205 518 minecraft:smooth_basalt
fill 135 205 519 135 208 519 minecraft:blackstone
setblock 135 205 523 minecraft:smooth_basalt
fill 135 205 524 135 208 524 minecraft:blackstone
setblock 135 205 529 minecraft:blackstone
setblock 135 205 533 minecraft:smooth_basalt
fill 135 205 534 135 208 534 minecraft:blackstone
setblock 135 205 538 minecraft:smooth_basalt
fill 135 205 539 135 208 539 minecraft:blackstone
setblock 135 205 543 minecraft:smooth_basalt
fill 135 205 544 135 208 544 minecraft:blackstone
setblock 135 205 548 minecraft:smooth_basalt
setblock 95 206 517 minecraft:smooth_basalt
fill 95 206 518 95 209 518 minecraft:blackstone
setblock 95 206 522 minecraft:smooth_basalt
fill 95 206 523 95 209 523 minecraft:blackstone
setblock 95 206 527 minecraft:smooth_basalt
fill 95 206 528 95 209 528 minecraft:blackstone
setblock 95 206 532 minecraft:smooth_basalt
setblock 95 206 533 minecraft:blackstone
setblock 95 206 537 minecraft:smooth_basalt
fill 95 206 538 95 208 538 minecraft:blackstone
setblock 95 206 542 minecraft:smooth_basalt
fill 95 206 543 95 209 543 minecraft:blackstone
setblock 96 206 517 minecraft:blackstone
setblock 96 206 521 minecraft:smooth_basalt
fill 96 206 522 96 209 522 minecraft:blackstone
setblock 106 206 511 minecraft:smooth_basalt
fill 107 206 511 107 209 511 minecraft:blackstone
setblock 109 206 513 minecraft:smooth_basalt
fill 109 206 551 110 206 551 minecraft:blackstone
setblock 110 206 512 minecraft:smooth_basalt
setblock 110 206 513 minecraft:blackstone
setblock 111 206 511 minecraft:smooth_basalt
fill 111 206 512 111 209 512 minecraft:blackstone
setblock 111 206 551 minecraft:smooth_basalt
fill 112 206 511 112 209 511 minecraft:blackstone
fill 112 206 551 112 209 551 minecraft:blackstone
setblock 116 206 511 minecraft:smooth_basalt
setblock 126 206 551 minecraft:smooth_basalt
fill 127 206 551 127 209 551 minecraft:blackstone
setblock 131 206 551 minecraft:smooth_basalt
setblock 132 206 540 minecraft:smooth_basalt
fill 132 206 541 132 207 541 minecraft:blackstone
setblock 132 206 551 minecraft:blackstone
setblock 133 206 539 minecraft:smooth_basalt
fill 133 206 540 133 209 540 minecraft:blackstone
setblock 133 206 544 minecraft:smooth_basalt
setblock 134 206 534 minecraft:blackstone
setblock 134 206 538 minecraft:smooth_basalt
fill 134 206 539 134 209 539 minecraft:blackstone
setblock 134 206 543 minecraft:smooth_basalt
fill 134 206 544 134 209 544 minecraft:blackstone
setblock 135 206 517 minecraft:smooth_basalt
fill 135 206 518 135 208 518 minecraft:blackstone
setblock 135 206 522 minecraft:smooth_basalt
fill 135 206 523 135 209 523 minecraft:blackstone
setblock 135 206 532 minecraft:smooth_basalt
fill 135 206 533 135 207 533 minecraft:blackstone
setblock 135 206 537 minecraft:smooth_basalt
fill 135 206 538 135 209 538 minecraft:blackstone
setblock 135 206 542 minecraft:smooth_basalt
fill 135 206 543 135 209 543 minecraft:blackstone
setblock 135 206 547 minecraft:smooth_basalt
setblock 95 207 516 minecraft:smooth_basalt
fill 95 207 517 95 210 517 minecraft:blackstone
setblock 95 207 521 minecraft:smooth_basalt
fill 95 207 522 95 210 522 minecraft:blackstone
setblock 95 207 526 minecraft:smooth_basalt
fill 95 207 527 95 210 527 minecraft:blackstone
setblock 95 207 536 minecraft:smooth_basalt
fill 95 207 537 95 208 537 minecraft:blackstone
setblock 95 207 541 minecraft:smooth_basalt
fill 95 207 542 95 210 542 minecraft:blackstone
setblock 96 207 520 minecraft:smooth_basalt
fill 96 207 521 96 210 521 minecraft:blackstone
fill 101 207 528 102 208 529 minecraft:gold_block
setblock 105 207 511 minecraft:smooth_basalt
fill 106 207 511 106 210 511 minecraft:blackstone
setblock 109 207 512 minecraft:smooth_basalt
setblock 109 207 551 minecraft:blackstone
setblock 110 207 511 minecraft:smooth_basalt
fill 110 207 512 110 210 512 minecraft:blackstone
setblock 110 207 551 minecraft:smooth_basalt
fill 111 207 511 111 210 511 minecraft:blackstone
fill 111 207 551 111 210 551 minecraft:blackstone
setblock 115 207 511 minecraft:smooth_basalt
fill 126 207 551 126 210 551 minecraft:blackstone
fill 130 207 519 130 211 519 minecraft:smooth_basalt
setblock 130 207 551 minecraft:smooth_basalt
fill 131 207 551 131 210 551 minecraft:blackstone
setblock 132 207 540 minecraft:blackstone
setblock 133 207 538 minecraft:smooth_basalt
fill 133 207 539 133 209 539 minecraft:blackstone
setblock 133 207 543 minecraft:smooth_basalt
fill 133 207 544 133 210 544 minecraft:blackstone
setblock 134 207 537 minecraft:smooth_basalt
fill 134 207 538 134 210 538 minecraft:blackstone
setblock 134 207 542 minecraft:smooth_basalt
fill 134 207 543 134 210 543 minecraft:blackstone
setblock 135 207 521 minecraft:smooth_basalt
fill 135 207 522 135 210 522 minecraft:blackstone
setblock 135 207 532 minecraft:blackstone
setblock 135 207 536 minecraft:smooth_basalt
fill 135 207 537 135 210 537 minecraft:blackstone
setblock 135 207 541 minecraft:smooth_basalt
fill 135 207 542 135 210 542 minecraft:blackstone
setblock 135 207 546 minecraft:smooth_basalt
setblock 135 207 547 minecraft:blackstone
fill 95 208 516 95 209 516 minecraft:blackstone
setblock 95 208 520 minecraft:smooth_basalt
fill 95 208 521 95 211 521 minecraft:blackstone
setblock 95 208 525 minecraft:smooth_basalt
fill 95 208 526 95 211 526 minecraft:blackstone
setblock 95 208 540 minecraft:smooth_basalt
fill 95 208 541 95 210 541 minecraft:blackstone
setblock 96 208 519 minecraft:smooth_basalt
fill 96 208 520 96 211 520 minecraft:blackstone
fill 105 208 511 105 211 511 minecraft:blackstone
setblock 108 208 512 minecraft:smooth_basalt
setblock 108 208 551 minecraft:blackstone
setblock 109 208 511 minecraft:smooth_basalt
fill 109 208 512 109 211 512 minecraft:blackstone
setblock 109 208 551 minecraft:smooth_basalt
fill 110 208 511 110 211 511 minecraft:blackstone
fill 110 208 551 110 211 551 minecraft:blackstone
setblock 114 208 511 minecraft:smooth_basalt
fill 125 208 551 125 211 551 minecraft:blackstone
setblock 129 208 551 minecraft:smooth_basalt
fill 130 208 551 130 211 551 minecraft:blackstone
setblock 133 208 538 minecraft:blackstone
setblock 133 208 542 minecraft:smooth_basalt
fill 133 208 543 133 211 543 minecraft:blackstone
setblock 134 208 536 minecraft:smooth_basalt
fill 134 208 537 134 209 537 minecraft:blackstone
setblock 134 208 541 minecraft:smooth_basalt
fill 134 208 542 134 211 542 minecraft:blackstone
setblock 135 208 520 minecraft:smooth_basalt
fill 135 208 521 135 211 521 minecraft:blackstone
setblock 135 208 525 minecraft:smooth_basalt
fill 135 208 526 135 211 526 minecraft:blackstone
setblock 135 208 535 minecraft:smooth_basalt
fill 135 208 536 135 211 536 minecraft:blackstone
setblock 135 208 540 minecraft:smooth_basalt
fill 135 208 541 135 211 541 minecraft:blackstone
setblock 135 208 545 minecraft:smooth_basalt
fill 135 208 546 135 211 546 minecraft:blackstone
setblock 95 209 519 minecraft:smooth_basalt
fill 95 209 520 95 212 520 minecraft:blackstone
setblock 95 209 524 minecraft:smooth_basalt
fill 95 209 525 95 212 525 minecraft:blackstone
setblock 95 209 539 minecraft:smooth_basalt
setblock 95 209 540 minecraft:blackstone
fill 96 209 519 96 212 519 minecraft:blackstone
setblock 96 209 523 minecraft:smooth_basalt
fill 96 209 524 96 212 524 minecraft:blackstone
fill 104 209 511 104 212 511 minecraft:blackstone
setblock 106 209 512 minecraft:blackstone
fill 106 209 551 107 209 551 minecraft:blackstone
setblock 107 209 512 minecraft:smooth_basalt
setblock 108 209 511 minecraft:smooth_basalt
fill 108 209 512 108 212 512 minecraft:blackstone
setblock 108 209 551 minecraft:smooth_basalt
fill 109 209 511 109 212 511 minecraft:blackstone
fill 109 209 551 109 212 551 minecraft:blackstone
setblock 113 209 511 minecraft:smooth_basalt
setblock 113 209 551 minecraft:smooth_basalt
fill 114 209 551 114 212 551 minecraft:blackstone
setblock 123 209 551 minecraft:smooth_basalt
fill 124 209 551 124 212 551 minecraft:blackstone
fill 126 209 550 128 209 550 minecraft:blackstone
setblock 128 209 551 minecraft:smooth_basalt
setblock 129 209 550 minecraft:smooth_basalt
fill 129 209 551 129 212 551 minecraft:blackstone
setblock 133 209 541 minecraft:smooth_basalt
fill 133 209 542 133 211 542 minecraft:blackstone
setblock 134 209 540 minecraft:smooth_basalt
fill 134 209 541 134 212 541 minecraft:blackstone
setblock 134 209 545 minecraft:smooth_basalt
setblock 135 209 519 minecraft:smooth_basalt
fill 135 209 520 135 212 520 minecraft:blackstone
setblock 135 209 524 minecraft:smooth_basalt
fill 135 209 525 135 212 525 minecraft:blackstone
fill 135 209 527 135 210 527 minecraft:blackstone
fill 135 209 535 135 210 535 minecraft:blackstone
setblock 135 209 539 minecraft:smooth_basalt
fill 135 209 540 135 212 540 minecraft:blackstone
setblock 135 209 544 minecraft:smooth_basalt
fill 135 209 545 135 212 545 minecraft:blackstone
fill 135 209 547 135 210 547 minecraft:blackstone
setblock 95 210 518 minecraft:smooth_basalt
fill 95 210 519 95 213 519 minecraft:blackstone
setblock 95 210 523 minecraft:smooth_basalt
fill 95 210 524 95 213 524 minecraft:blackstone
setblock 95 210 528 minecraft:smooth_basalt
fill 95 210 529 95 213 529 minecraft:blackstone
setblock 95 210 543 minecraft:smooth_basalt
setblock 96 210 522 minecraft:smooth_basalt
fill 96 210 523 96 213 523 minecraft:blackstone
fill 96 210 525 96 211 525 minecraft:blackstone
fill 103 210 511 103 213 511 minecraft:blackstone
fill 105 210 551 106 210 551 minecraft:blackstone
setblock 106 210 512 minecraft:smooth_basalt
setblock 107 210 511 minecraft:smooth_basalt
fill 107 210 512 107 213 512 minecraft:blackstone
setblock 107 210 550 minecraft:blackstone
setblock 107 210 551 minecraft:smooth_basalt
fill 108 210 511 108 213 511 minecraft:blackstone
setblock 108 210 550 minecraft:smooth_basalt
fill 108 210 551 108 213 551 minecraft:blackstone
fill 109 210 550 111 211 550 minecraft:blackstone
setblock 112 210 511 minecraft:smooth_basalt
setblock 112 210 551 minecraft:smooth_basalt
fill 113 210 511 113 213 511 minecraft:blackstone
fill 113 210 551 113 213 551 minecraft:blackstone
fill 115 210 551 115 211 551 minecraft:blackstone
setblock 121 210 551 minecraft:blackstone
setblock 122 210 551 minecraft:smooth_basalt
fill 123 210 551 123 213 551 minecraft:blackstone
fill 124 210 550 127 210 550 minecraft:blackstone
setblock 127 210 551 minecraft:smooth_basalt
setblock 128 210 550 minecraft:smooth_basalt
fill 128 210 551 128 213 551 minecraft:blackstone
fill 129 210 550 129 213 550 minecraft:blackstone
setblock 133 210 540 minecraft:smooth_basalt
setblock 133 210 541 minecraft:blackstone
fill 134 210 522 134 210 523 minecraft:blackstone
setblock 134 210 524 minecraft:smooth_basalt
fill 134 210 525 134 213 525 minecraft:blackstone
setblock 134 210 539 minecraft:smooth_basalt
fill 134 210 540 134 212 540 minecraft:blackstone
setblock 134 210 544 minecraft:smooth_basalt
fill 134 210 545 134 213 545 minecraft:blackstone
fill 135 210 519 135 213 519 minecraft:blackstone
setblock 135 210 523 minecraft:smooth_basalt
fill 135 210 524 135 213 524 minecraft:blackstone
setblock 135 210 528 minecraft:smooth_basalt
fill 135 210 529 135 213 529 minecraft:blackstone
setblock 135 210 538 minecraft:smooth_basalt
fill 135 210 539 135 213 539 minecraft:blackstone
setblock 135 210 543 minecraft:smooth_basalt
fill 135 210 544 135 213 544 minecraft:blackstone
setblock 95 211 517 minecraft:smooth_basalt
fill 95 211 518 95 214 518 minecraft:blackstone
setblock 95 211 522 minecraft:smooth_basalt
fill 95 211 523 95 214 523 minecraft:blackstone
setblock 95 211 527 minecraft:smooth_basalt
fill 95 211 528 95 214 528 minecraft:blackstone
setblock 96 211 521 minecraft:smooth_basalt
fill 96 211 522 96 214 522 minecraft:blackstone
setblock 96 211 526 minecraft:smooth_basalt
fill 102 211 511 102 214 511 minecraft:blackstone
fill 103 211 551 105 211 551 minecraft:blackstone
setblock 104 211 512 minecraft:blackstone
setblock 105 211 512 minecraft:smooth_basalt
fill 105 211 550 106 211 550 minecraft:blackstone
setblock 106 211 511 minecraft:smooth_basalt
fill 106 211 512 106 214 512 minecraft:blackstone
setblock 106 211 551 minecraft:smooth_basalt
fill 107 211 511 107 214 511 minecraft:blackstone
setblock 107 211 550 minecraft:smooth_basalt
fill 107 211 551 107 214 551 minecraft:blackstone
fill 108 211 550 108 214 550 minecraft:blackstone
setblock 110 211 512 minecraft:smooth_basalt
setblock 111 211 511 minecraft:smooth_basalt
setblock 111 211 551 minecraft:smooth_basalt
fill 112 211 511 112 214 511 minecraft:blackstone
setblock 112 211 550 minecraft:smooth_basalt
fill 112 211 551 112 214 551 minecraft:blackstone
fill 113 211 550 113 214 550 minecraft:blackstone
fill 114 211 544 118 212 548 minecraft:blackstone
fill 116 211 549 116 211 550 minecraft:blackstone
setblock 116 211 551 minecraft:smooth_basalt
fill 117 211 551 120 211 551 minecraft:blackstone
setblock 121 211 551 minecraft:smooth_basalt
setblock 122 211 550 minecraft:smooth_basalt
fill 122 211 551 122 214 551 minecraft:blackstone
fill 123 211 550 126 211 550 minecraft:blackstone
fill 124 211 549 127 211 549 minecraft:blackstone
setblock 126 211 551 minecraft:smooth_basalt
setblock 127 211 550 minecraft:smooth_basalt
fill 127 211 551 127 214 551 minecraft:blackstone
fill 128 211 536 129 212 537 minecraft:gilded_blackstone
setblock 128 211 549 minecraft:smooth_basalt
fill 128 211 550 128 214 550 minecraft:blackstone
fill 129 211 549 129 214 549 minecraft:blackstone
fill 130 211 550 130 212 550 minecraft:blackstone
setblock 131 211 551 minecraft:smooth_basalt
setblock 133 211 544 minecraft:smooth_basalt
setblock 134 211 522 minecraft:blackstone
setblock 134 211 523 minecraft:smooth_basalt
fill 134 211 524 134 214 524 minecraft:blackstone
fill 134 211 526 134 211 527 minecraft:blackstone
setblock 134 211 539 minecraft:blackstone
setblock 134 211 543 minecraft:smooth_basalt
fill 134 211 544 134 214 544 minecraft:blackstone
fill 134 211 546 134 212 546 minecraft:blackstone
setblock 135 211 522 minecraft:smooth_basalt
fill 135 211 523 135 214 523 minecraft:blackstone
setblock 135 211 527 minecraft:smooth_basalt
fill 135 211 528 135 214 528 minecraft:blackstone
fill 135 211 530 135 211 531 minecraft:blackstone
setblock 135 211 537 minecraft:smooth_basalt
fill 135 211 538 135 213 538 minecraft:blackstone
setblock 135 211 542 minecraft:smooth_basalt
fill 135 211 543 135 214 543 minecraft:blackstone
setblock 135 211 547 minecraft:smooth_basalt
fill 95 212 517 95 215 517 minecraft:blackstone
setblock 95 212 521 minecraft:smooth_basalt
fill 95 212 522 95 215 522 minecraft:blackstone
setblock 95 212 526 minecraft:smooth_basalt
fill 95 212 527 96 214 527 minecraft:blackstone
setblock 95 212 530 minecraft:blackstone
setblock 96 212 520 minecraft:smooth_basalt
fill 96 212 521 96 215 521 minecraft:blackstone
setblock 96 212 525 minecraft:smooth_basalt
fill 96 212 526 96 215 526 minecraft:blackstone
fill 101 212 511 101 215 511 minecraft:blackstone
fill 102 212 551 104 212 551 minecraft:blackstone
setblock 103 212 512 minecraft:blackstone
setblock 104 212 512 minecraft:smooth_basalt
fill 104 212 550 105 212 550 minecraft:blackstone
setblock 105 212 511 minecraft:smooth_basalt
fill 105 212 512 105 215 512 minecraft:blackstone
setblock 105 212 551 minecraft:smooth_basalt
fill 106 212 511 106 215 511 minecraft:blackstone
setblock 106 212 549 minecraft:blackstone
setblock 106 212 550 minecraft:smooth_basalt
fill 106 212 551 106 215 551 minecraft:blackstone
setblock 107 212 549 minecraft:smooth_basalt
fill 107 212 550 107 215 550 minecraft:blackstone
fill 108 212 549 111 212 549 minecraft:blackstone
setblock 109 212 512 minecraft:smooth_basalt
fill 109 212 550 110 212 550 minecraft:blackstone
setblock 110 212 511 minecraft:smooth_basalt
fill 110 212 512 110 215 512 minecraft:blackstone
setblock 110 212 551 minecraft:smooth_basalt
fill 111 212 511 111 215 511 minecraft:blackstone
setblock 111 212 550 minecraft:smooth_basalt
fill 111 212 551 111 215 551 minecraft:blackstone
fill 112 212 550 112 215 550 minecraft:blackstone
fill 114 212 550 114 213 550 minecraft:blackstone
setblock 115 212 551 minecraft:smooth_basalt
fill 116 212 551 119 212 551 minecraft:blackstone
fill 119 212 550 120 212 550 minecraft:blackstone
setblock 120 212 551 minecraft:smooth_basalt
setblock 121 212 550 minecraft:smooth_basalt
fill 121 212 551 121 215 551 minecraft:blackstone
setblock 122 212 549 minecraft:smooth_basalt
fill 122 212 550 125 212 550 minecraft:blackstone
fill 123 212 549 126 212 549 minecraft:blackstone
setblock 125 212 511 minecraft:smooth_basalt
fill 125 212 548 127 212 548 minecraft:blackstone
setblock 125 212 551 minecraft:smooth_basalt
fill 126 212 511 127 214 511 minecraft:blackstone
setblock 126 212 550 minecraft:smooth_basalt
fill 126 212 551 126 215 551 minecraft:blackstone
setblock 127 212 549 minecraft:smooth_basalt
fill 127 212 550 127 215 550 minecraft:blackstone
fill 128 212 549 128 215 549 minecraft:blackstone
setblock 130 212 519 minecraft:shroomlight
setblock 130 212 551 minecraft:smooth_basalt
setblock 131 212 550 minecraft:smooth_basalt
fill 131 212 551 132 214 551 minecraft:blackstone
setblock 134 212 521 minecraft:blackstone
setblock 134 212 522 minecraft:smooth_basalt
fill 134 212 523 134 215 523 minecraft:blackstone
setblock 134 212 526 minecraft:blackstone
setblock 134 212 527 minecraft:smooth_basalt
fill 134 212 528 134 215 528 minecraft:blackstone
setblock 134 212 542 minecraft:smooth_basalt
fill 134 212 543 134 214 543 minecraft:blackstone
setblock 135 212 521 minecraft:smooth_basalt
fill 135 212 522 135 215 522 minecraft:blackstone
setblock 135 212 526 minecraft:smooth_basalt
fill 135 212 527 135 215 527 minecraft:blackstone
setblock 135 212 530 minecraft:blackstone
setblock 135 212 531 minecraft:smooth_basalt
fill 135 212 532 135 215 532 minecraft:blackstone
setblock 135 212 536 minecraft:smooth_basalt
fill 135 212 537 135 213 537 minecraft:blackstone
setblock 135 212 541 minecraft:smooth_basalt
fill 135 212 542 135 215 542 minecraft:blackstone
setblock 135 212 546 minecraft:smooth_basalt
fill 135 212 547 135 214 548 minecraft:blackstone
setblock 95 213 520 minecraft:smooth_basalt
fill 95 213 521 95 216 521 minecraft:blackstone
setblock 95 213 525 minecraft:smooth_basalt
fill 95 213 526 95 216 526 minecraft:blackstone
setblock 95 213 530 minecraft:smooth_basalt
fill 95 213 531 95 216 531 minecraft:blackstone
setblock 95 213 545 minecraft:smooth_basalt
setblock 96 213 519 minecraft:smooth_basalt
fill 96 213 520 96 216 520 minecraft:blackstone
setblock 96 213 524 minecraft:smooth_basalt
fill 96 213 525 96 216 525 minecraft:blackstone
setblock 96 213 528 minecraft:blackstone
setblock 97 213 513 minecraft:light[level=12]
setblock 97 213 521 minecraft:light[level=12]
setblock 97 213 523 minecraft:smooth_basalt
fill 97 213 524 97 216 524 minecraft:blackstone
setblock 97 213 529 minecraft:light[level=12]
fill 97 213 530 98 213 533 minecraft:gold_block
setblock 97 213 537 minecraft:light[level=12]
setblock 97 213 545 minecraft:light[level=12]
fill 98 213 529 103 213 529 minecraft:gold_block
fill 98 213 534 103 213 534 minecraft:gold_block
fill 99 213 530 99 215 530 minecraft:gold_block
fill 99 213 533 99 215 533 minecraft:gold_block
fill 99 213 535 102 213 535 minecraft:gold_block
fill 100 213 511 100 216 511 minecraft:blackstone
fill 100 213 515 101 213 515 minecraft:gold_block
fill 100 213 528 101 213 528 minecraft:gold_block
fill 100 213 551 103 213 551 minecraft:blackstone
fill 101 213 513 101 213 514 minecraft:gold_block
fill 101 213 516 101 213 517 minecraft:gold_block
setblock 102 213 512 minecraft:blackstone
fill 102 213 513 104 213 513 minecraft:gold_block
fill 102 213 517 105 213 517 minecraft:gold_block
fill 102 213 530 104 213 530 minecraft:gold_block
fill 102 213 550 104 213 550 minecraft:blackstone
setblock 103 213 512 minecraft:smooth_basalt
setblock 103 213 518 minecraft:gold_block
fill 103 213 531 104 213 533 minecraft:gold_block
setblock 104 213 511 minecraft:smooth_basalt
fill 104 213 512 104 216 512 minecraft:blackstone
fill 104 213 549 105 213 549 minecraft:blackstone
setblock 104 213 551 minecraft:smooth_basalt
fill 105 213 511 105 216 511 minecraft:blackstone
fill 105 213 513 106 213 513 minecraft:blackstone
fill 105 213 514 106 213 516 minecraft:gold_block
setblock 105 213 521 minecraft:light[level=12]
setblock 105 213 529 minecraft:light[level=12]
setblock 105 213 537 minecraft:light[level=12]
setblock 105 213 545 minecraft:light[level=12]
setblock 105 213 550 minecraft:smooth_basalt
fill 105 213 551 105 216 551 minecraft:blackstone
setblock 106 213 549 minecraft:smooth_basalt
fill 106 213 550 106 216 550 minecraft:blackstone
setblock 107 213 513 minecraft:smooth_basalt
fill 107 213 549 110 213 549 minecraft:blackstone
setblock 108 213 512 minecraft:smooth_basalt
setblock 109 213 511 minecraft:smooth_basalt
fill 109 213 512 109 216 512 minecraft:blackstone
setblock 109 213 550 minecraft:blackstone
setblock 109 213 551 minecraft:smooth_basalt
fill 110 213 511 110 216 511 minecraft:blackstone
setblock 110 213 550 minecraft:smooth_basalt
fill 110 213 551 110 216 551 minecraft:blackstone
setblock 111 213 549 minecraft:smooth_basalt
fill 111 213 550 111 216 550 minecraft:blackstone
fill 112 213 549 112 216 549 minecraft:blackstone
setblock 113 213 513 minecraft:light[level=12]
setblock 113 213 521 minecraft:light[level=12]
setblock 113 213 529 minecraft:light[level=12]
setblock 113 213 537 minecraft:light[level=12]
setblock 113 213 545 minecraft:light[level=12]
setblock 114 213 551 minecraft:smooth_basalt
fill 115 213 545 117 214 547 minecraft:smooth_basalt
setblock 115 213 550 minecraft:smooth_basalt
fill 115 213 551 118 213 551 minecraft:blackstone
fill 116 213 550 119 213 550 minecraft:blackstone
setblock 119 213 551 minecraft:smooth_basalt
setblock 120 213 549 minecraft:blackstone
setblock 120 213 550 minecraft:smooth_basalt
fill 120 213 551 120 216 551 minecraft:blackstone
setblock 121 213 513 minecraft:light[level=12]
setblock 121 213 521 minecraft:light[level=12]
setblock 121 213 529 minecraft:light[level=12]
setblock 121 213 537 minecraft:light[level=12]
setblock 121 213 545 minecraft:light[level=12]
setblock 121 213 549 minecraft:smooth_basalt
fill 121 213 550 124 213 550 minecraft:blackstone
setblock 122 213 548 minecraft:smooth_basalt
fill 122 213 549 125 213 549 minecraft:blackstone
setblock 123 213 511 minecraft:blackstone
fill 123 213 548 126 213 548 minecraft:blackstone
setblock 124 213 511 minecraft:smooth_basalt
setblock 124 213 551 minecraft:smooth_basalt
fill 125 213 511 125 216 511 minecraft:blackstone
setblock 125 213 550 minecraft:smooth_basalt
fill 125 213 551 125 216 551 minecraft:blackstone
setblock 126 213 549 minecraft:smooth_basalt
fill 126 213 550 126 216 550 minecraft:blackstone
setblock 127 213 548 minecraft:smooth_basalt
fill 127 213 549 127 216 549 minecraft:blackstone
setblock 128 213 511 minecraft:blackstone
fill 128 213 548 128 215 548 minecraft:blackstone
setblock 129 213 513 minecraft:light[level=12]
setblock 129 213 521 minecraft:light[level=12]
setblock 129 213 529 minecraft:light[level=12]
setblock 129 213 537 minecraft:light[level=12]
setblock 129 213 545 minecraft:light[level=12]
setblock 129 213 551 minecraft:smooth_basalt
setblock 130 213 549 minecraft:blackstone
setblock 130 213 550 minecraft:smooth_basalt
fill 130 213 551 130 216 551 minecraft:blackstone
fill 131 213 550 131 215 550 minecraft:blackstone
fill 133 213 525 133 214 525 minecraft:blackstone
setblock 134 213 521 minecraft:smooth_basalt
fill 134 213 522 134 215 522 minecraft:blackstone
setblock 134 213 526 minecraft:smooth_basalt
fill 134 213 527 134 216 527 minecraft:blackstone
fill 134 213 529 134 213 530 minecraft:blackstone
setblock 134 213 541 minecraft:smooth_basalt
setblock 134 213 542 minecraft:blackstone
setblock 134 213 546 minecraft:smooth_basalt
setblock 135 213 520 minecraft:smooth_basalt
fill 135 213 521 135 216 521 minecraft:blackstone
setblock 135 213 525 minecraft:smooth_basalt
fill 135 213 526 135 216 526 minecraft:blackstone
setblock 135 213 530 minecraft:smooth_basalt
fill 135 213 531 135 216 531 minecraft:blackstone
fill 135 213 533 135 213 534 minecraft:blackstone
setblock 135 213 540 minecraft:smooth_basalt
fill 135 213 541 135 215 541 minecraft:blackstone
setblock 135 213 545 minecraft:smooth_basalt
fill 135 213 546 135 216 546 minecraft:blackstone
setblock 95 214 519 minecraft:smooth_basalt
fill 95 214 520 95 216 520 minecraft:blackstone
setblock 95 214 524 minecraft:smooth_basalt
fill 95 214 525 95 216 525 minecraft:blackstone
setblock 95 214 529 minecraft:smooth_basalt
fill 95 214 530 95 216 530 minecraft:blackstone
fill 95 214 545 95 214 547 minecraft:blackstone
setblock 96 214 519 minecraft:blackstone
setblock 96 214 523 minecraft:smooth_basalt
fill 96 214 524 96 216 524 minecraft:blackstone
setblock 96 214 528 minecraft:smooth_basalt
setblock 97 214 522 minecraft:smooth_basalt
fill 97 214 523 97 216 523 minecraft:blackstone
fill 97 214 525 97 215 525 minecraft:blackstone
fill 98 214 530 98 214 533 minecraft:gold_block
fill 99 214 511 99 216 511 minecraft:blackstone
fill 99 214 529 102 214 529 minecraft:gold_block
fill 99 214 534 102 214 534 minecraft:gold_block
fill 99 214 551 102 214 551 minecraft:blackstone
setblock 101 214 512 minecraft:blackstone
fill 101 214 514 101 214 516 minecraft:gold_block
fill 101 214 550 103 214 550 minecraft:blackstone
setblock 102 214 512 minecraft:smooth_basalt
fill 102 214 513 103 214 513 minecraft:gold_block
fill 102 214 517 104 214 517 minecraft:gold_block
fill 102 214 530 103 214 530 minecraft:gold_block
setblock 103 214 511 minecraft:smooth_basalt
schedule function dropper:buildpart/122_9 1t
