setblock 370 145 500 minecraft:pink_terracotta
setblock 370 145 501 minecraft:red_nether_bricks
fill 370 145 502 370 148 502 minecraft:pink_terracotta
setblock 330 146 464 minecraft:pink_terracotta
setblock 330 146 465 minecraft:red_nether_bricks
fill 330 146 466 330 149 466 minecraft:pink_terracotta
setblock 330 146 470 minecraft:red_nether_bricks
fill 330 146 471 330 149 471 minecraft:pink_terracotta
setblock 330 146 475 minecraft:red_nether_bricks
fill 330 146 476 330 149 476 minecraft:pink_terracotta
setblock 330 146 480 minecraft:red_nether_bricks
fill 330 146 481 330 149 481 minecraft:pink_terracotta
setblock 330 146 485 minecraft:red_nether_bricks
fill 330 146 486 330 148 487 minecraft:pink_terracotta
fill 330 146 491 330 147 491 minecraft:pink_terracotta
setblock 330 146 495 minecraft:red_nether_bricks
fill 330 146 496 330 149 496 minecraft:pink_terracotta
setblock 330 146 500 minecraft:red_nether_bricks
fill 330 146 501 330 149 501 minecraft:pink_terracotta
setblock 331 146 464 minecraft:red_nether_bricks
fill 331 146 465 331 149 465 minecraft:pink_terracotta
setblock 331 146 469 minecraft:red_nether_bricks
fill 331 146 470 331 149 470 minecraft:pink_terracotta
setblock 331 146 474 minecraft:red_nether_bricks
fill 331 146 475 331 149 475 minecraft:pink_terracotta
setblock 331 146 479 minecraft:red_nether_bricks
fill 331 146 480 332 147 480 minecraft:pink_terracotta
setblock 331 146 483 minecraft:pink_terracotta
setblock 331 146 494 minecraft:red_nether_bricks
fill 331 146 495 331 148 495 minecraft:pink_terracotta
setblock 331 146 499 minecraft:red_nether_bricks
fill 331 146 500 331 149 500 minecraft:pink_terracotta
setblock 331 146 503 minecraft:pink_terracotta
setblock 331 146 504 minecraft:red_nether_bricks
fill 332 146 464 332 149 464 minecraft:pink_terracotta
setblock 332 146 473 minecraft:red_nether_bricks
fill 332 146 474 332 147 474 minecraft:pink_terracotta
setblock 332 146 478 minecraft:red_nether_bricks
fill 332 146 479 332 148 479 minecraft:pink_terracotta
setblock 332 146 497 minecraft:pink_terracotta
setblock 332 146 498 minecraft:red_nether_bricks
fill 332 146 499 332 149 499 minecraft:pink_terracotta
setblock 332 146 502 minecraft:pink_terracotta
setblock 332 146 503 minecraft:red_nether_bricks
fill 332 146 504 332 149 504 minecraft:pink_terracotta
setblock 333 146 502 minecraft:red_nether_bricks
fill 333 146 503 333 149 503 minecraft:pink_terracotta
fill 334 146 502 334 149 502 minecraft:pink_terracotta
setblock 336 146 464 minecraft:red_nether_bricks
setblock 336 146 503 minecraft:pink_terracotta
setblock 336 146 504 minecraft:red_nether_bricks
fill 337 146 464 337 149 464 minecraft:pink_terracotta
setblock 337 146 503 minecraft:red_nether_bricks
fill 337 146 504 340 146 504 minecraft:pink_terracotta
fill 338 146 503 341 146 503 minecraft:pink_terracotta
setblock 341 146 504 minecraft:red_nether_bricks
setblock 342 146 502 minecraft:pink_terracotta
setblock 342 146 503 minecraft:red_nether_bricks
fill 342 146 504 342 149 504 minecraft:pink_terracotta
setblock 343 146 464 minecraft:white_concrete
setblock 343 146 502 minecraft:red_nether_bricks
fill 343 146 503 343 149 503 minecraft:pink_terracotta
fill 344 146 464 345 146 464 minecraft:pink_terracotta
fill 344 146 502 347 146 502 minecraft:pink_terracotta
fill 345 146 501 348 146 501 minecraft:pink_terracotta
setblock 346 146 464 minecraft:red_nether_bricks
setblock 346 146 503 minecraft:pink_terracotta
setblock 346 146 504 minecraft:red_nether_bricks
fill 347 146 464 347 149 464 minecraft:pink_terracotta
setblock 347 146 503 minecraft:red_nether_bricks
fill 347 146 504 347 149 504 minecraft:pink_terracotta
fill 348 146 500 349 146 500 minecraft:pink_terracotta
setblock 348 146 502 minecraft:red_nether_bricks
fill 348 146 503 348 149 503 minecraft:pink_terracotta
setblock 349 146 501 minecraft:red_nether_bricks
fill 349 146 502 349 149 502 minecraft:pink_terracotta
fill 350 146 501 350 149 501 minecraft:pink_terracotta
setblock 351 146 464 minecraft:red_nether_bricks
setblock 351 146 504 minecraft:red_nether_bricks
fill 352 146 464 352 149 464 minecraft:pink_terracotta
setblock 352 146 503 minecraft:red_nether_bricks
fill 352 146 504 352 149 504 minecraft:pink_terracotta
setblock 353 146 502 minecraft:red_nether_bricks
fill 353 146 503 353 149 503 minecraft:pink_terracotta
fill 354 146 502 354 147 502 minecraft:pink_terracotta
fill 355 146 503 355 147 503 minecraft:pink_terracotta
setblock 356 146 504 minecraft:red_nether_bricks
fill 357 146 504 357 147 504 minecraft:white_concrete
setblock 365 146 504 minecraft:pink_terracotta
setblock 366 146 464 minecraft:red_nether_bricks
setblock 366 146 504 minecraft:red_nether_bricks
fill 367 146 464 367 149 464 minecraft:pink_terracotta
fill 367 146 474 367 149 474 minecraft:pink_terracotta
setblock 367 146 478 minecraft:red_nether_bricks
fill 367 146 479 367 149 479 minecraft:pink_terracotta
fill 367 146 481 368 146 481 minecraft:pink_terracotta
setblock 367 146 503 minecraft:red_nether_bricks
fill 367 146 504 367 149 504 minecraft:pink_terracotta
setblock 368 146 471 minecraft:pink_terracotta
setblock 368 146 472 minecraft:red_nether_bricks
fill 368 146 473 368 149 473 minecraft:pink_terracotta
setblock 368 146 477 minecraft:red_nether_bricks
fill 368 146 478 368 149 478 minecraft:pink_terracotta
fill 368 146 480 368 147 480 minecraft:pink_terracotta
setblock 368 146 482 minecraft:red_nether_bricks
fill 368 146 483 368 148 484 minecraft:pink_terracotta
fill 368 146 503 369 148 503 minecraft:pink_terracotta
setblock 369 146 465 minecraft:pink_terracotta
setblock 369 146 466 minecraft:red_nether_bricks
fill 369 146 467 369 149 467 minecraft:pink_terracotta
setblock 369 146 471 minecraft:red_nether_bricks
fill 369 146 472 369 149 472 minecraft:pink_terracotta
setblock 369 146 476 minecraft:red_nether_bricks
fill 369 146 477 369 149 477 minecraft:pink_terracotta
setblock 369 146 481 minecraft:red_nether_bricks
fill 369 146 482 369 149 482 minecraft:pink_terracotta
setblock 369 146 486 minecraft:red_nether_bricks
fill 369 146 487 369 149 487 minecraft:pink_terracotta
setblock 369 146 496 minecraft:red_nether_bricks
fill 369 146 497 369 149 497 minecraft:pink_terracotta
setblock 369 146 501 minecraft:red_nether_bricks
fill 369 146 502 369 149 502 minecraft:pink_terracotta
setblock 370 146 464 minecraft:pink_terracotta
setblock 370 146 465 minecraft:red_nether_bricks
fill 370 146 466 370 149 466 minecraft:pink_terracotta
setblock 370 146 470 minecraft:red_nether_bricks
fill 370 146 471 370 149 471 minecraft:pink_terracotta
setblock 370 146 475 minecraft:red_nether_bricks
fill 370 146 476 370 149 476 minecraft:pink_terracotta
setblock 370 146 480 minecraft:red_nether_bricks
fill 370 146 481 370 149 481 minecraft:pink_terracotta
setblock 370 146 485 minecraft:red_nether_bricks
fill 370 146 486 370 149 486 minecraft:pink_terracotta
setblock 370 146 490 minecraft:red_nether_bricks
fill 370 146 491 370 149 491 minecraft:pink_terracotta
setblock 370 146 495 minecraft:red_nether_bricks
fill 370 146 496 370 149 496 minecraft:pink_terracotta
setblock 370 146 500 minecraft:red_nether_bricks
fill 370 146 501 370 149 501 minecraft:pink_terracotta
setblock 330 147 464 minecraft:red_nether_bricks
fill 330 147 465 330 150 465 minecraft:pink_terracotta
setblock 330 147 469 minecraft:red_nether_bricks
fill 330 147 470 330 150 470 minecraft:pink_terracotta
setblock 330 147 474 minecraft:red_nether_bricks
fill 330 147 475 330 150 475 minecraft:pink_terracotta
setblock 330 147 479 minecraft:red_nether_bricks
fill 330 147 480 330 150 480 minecraft:pink_terracotta
setblock 330 147 484 minecraft:red_nether_bricks
fill 330 147 485 330 150 485 minecraft:pink_terracotta
setblock 330 147 494 minecraft:red_nether_bricks
fill 330 147 495 330 150 495 minecraft:pink_terracotta
setblock 330 147 499 minecraft:red_nether_bricks
fill 330 147 500 330 150 500 minecraft:pink_terracotta
setblock 330 147 504 minecraft:red_nether_bricks
fill 331 147 464 331 150 464 minecraft:pink_terracotta
setblock 331 147 468 minecraft:red_nether_bricks
fill 331 147 469 331 149 469 minecraft:pink_terracotta
setblock 331 147 473 minecraft:red_nether_bricks
fill 331 147 474 331 150 474 minecraft:pink_terracotta
setblock 331 147 478 minecraft:red_nether_bricks
fill 331 147 479 331 150 479 minecraft:pink_terracotta
setblock 331 147 483 minecraft:red_nether_bricks
setblock 331 147 498 minecraft:red_nether_bricks
fill 331 147 499 331 150 499 minecraft:pink_terracotta
setblock 331 147 503 minecraft:red_nether_bricks
fill 331 147 504 331 150 504 minecraft:pink_terracotta
setblock 332 147 473 minecraft:pink_terracotta
setblock 332 147 477 minecraft:red_nether_bricks
fill 332 147 478 332 148 478 minecraft:pink_terracotta
fill 332 147 498 332 148 498 minecraft:pink_terracotta
setblock 332 147 502 minecraft:red_nether_bricks
fill 332 147 503 332 150 503 minecraft:pink_terracotta
fill 333 147 502 333 150 502 minecraft:pink_terracotta
setblock 334 147 465 minecraft:red_nether_bricks
setblock 335 147 464 minecraft:red_nether_bricks
fill 335 147 502 336 147 502 minecraft:pink_terracotta
setblock 335 147 504 minecraft:red_nether_bricks
fill 336 147 464 336 150 464 minecraft:pink_terracotta
setblock 336 147 503 minecraft:red_nether_bricks
fill 336 147 504 339 147 504 minecraft:pink_terracotta
fill 337 147 503 340 147 503 minecraft:pink_terracotta
fill 338 147 464 339 147 464 minecraft:pink_terracotta
setblock 340 147 464 minecraft:red_nether_bricks
fill 340 147 502 341 147 502 minecraft:pink_terracotta
setblock 340 147 504 minecraft:red_nether_bricks
fill 341 147 464 344 147 464 minecraft:pink_terracotta
setblock 341 147 503 minecraft:red_nether_bricks
fill 341 147 504 341 150 504 minecraft:pink_terracotta
setblock 342 147 502 minecraft:red_nether_bricks
fill 342 147 503 342 150 503 minecraft:pink_terracotta
fill 343 147 502 346 147 502 minecraft:pink_terracotta
fill 344 147 501 347 147 501 minecraft:pink_terracotta
setblock 345 147 464 minecraft:red_nether_bricks
setblock 345 147 504 minecraft:red_nether_bricks
fill 346 147 464 346 150 464 minecraft:pink_terracotta
setblock 346 147 503 minecraft:red_nether_bricks
fill 346 147 504 346 150 504 minecraft:pink_terracotta
fill 347 147 500 348 147 500 minecraft:pink_terracotta
setblock 347 147 502 minecraft:red_nether_bricks
fill 347 147 503 347 150 503 minecraft:pink_terracotta
setblock 348 147 501 minecraft:red_nether_bricks
fill 348 147 502 348 150 502 minecraft:pink_terracotta
setblock 349 147 464 minecraft:pink_terracotta
setblock 349 147 500 minecraft:red_nether_bricks
fill 349 147 501 349 150 501 minecraft:pink_terracotta
setblock 350 147 464 minecraft:red_nether_bricks
setblock 350 147 500 minecraft:pink_terracotta
setblock 350 147 504 minecraft:red_nether_bricks
fill 351 147 464 351 150 464 minecraft:pink_terracotta
setblock 351 147 503 minecraft:red_nether_bricks
fill 351 147 504 351 150 504 minecraft:pink_terracotta
setblock 352 147 502 minecraft:red_nether_bricks
fill 352 147 503 352 150 503 minecraft:pink_terracotta
fill 353 147 502 353 149 502 minecraft:pink_terracotta
setblock 355 147 504 minecraft:red_nether_bricks
fill 356 147 504 356 150 504 minecraft:pink_terracotta
setblock 362 147 464 minecraft:white_concrete
fill 363 147 504 364 147 504 minecraft:pink_terracotta
setblock 365 147 464 minecraft:red_nether_bricks
setblock 365 147 504 minecraft:red_nether_bricks
fill 366 147 464 366 150 464 minecraft:pink_terracotta
setblock 366 147 503 minecraft:red_nether_bricks
fill 366 147 504 366 150 504 minecraft:pink_terracotta
fill 367 147 465 368 147 465 minecraft:pink_terracotta
setblock 367 147 476 minecraft:pink_terracotta
setblock 367 147 477 minecraft:red_nether_bricks
fill 367 147 478 367 150 478 minecraft:pink_terracotta
setblock 367 147 481 minecraft:pink_terracotta
setblock 367 147 482 minecraft:red_nether_bricks
fill 367 147 503 367 150 503 minecraft:pink_terracotta
setblock 368 147 470 minecraft:pink_terracotta
setblock 368 147 471 minecraft:red_nether_bricks
fill 368 147 472 368 150 472 minecraft:pink_terracotta
setblock 368 147 476 minecraft:red_nether_bricks
fill 368 147 477 368 150 477 minecraft:pink_terracotta
setblock 368 147 481 minecraft:red_nether_bricks
fill 368 147 482 368 150 482 minecraft:pink_terracotta
setblock 368 147 485 minecraft:pink_terracotta
fill 368 147 498 368 147 500 minecraft:pink_terracotta
setblock 368 147 501 minecraft:red_nether_bricks
setblock 369 147 465 minecraft:red_nether_bricks
fill 369 147 466 369 150 466 minecraft:pink_terracotta
setblock 369 147 470 minecraft:red_nether_bricks
fill 369 147 471 369 150 471 minecraft:pink_terracotta
setblock 369 147 475 minecraft:red_nether_bricks
fill 369 147 476 369 150 476 minecraft:pink_terracotta
setblock 369 147 480 minecraft:red_nether_bricks
fill 369 147 481 369 150 481 minecraft:pink_terracotta
setblock 369 147 484 minecraft:pink_terracotta
setblock 369 147 485 minecraft:red_nether_bricks
fill 369 147 486 369 150 486 minecraft:pink_terracotta
fill 369 147 488 369 148 488 minecraft:pink_terracotta
setblock 369 147 495 minecraft:red_nether_bricks
fill 369 147 496 369 149 496 minecraft:pink_terracotta
setblock 369 147 499 minecraft:pink_terracotta
setblock 369 147 500 minecraft:red_nether_bricks
fill 369 147 501 369 150 501 minecraft:pink_terracotta
setblock 369 147 504 minecraft:pink_terracotta
setblock 370 147 464 minecraft:red_nether_bricks
fill 370 147 465 370 150 465 minecraft:pink_terracotta
setblock 370 147 469 minecraft:red_nether_bricks
fill 370 147 470 370 150 470 minecraft:pink_terracotta
setblock 370 147 474 minecraft:red_nether_bricks
fill 370 147 475 370 150 475 minecraft:pink_terracotta
setblock 370 147 479 minecraft:red_nether_bricks
fill 370 147 480 370 150 480 minecraft:pink_terracotta
setblock 370 147 484 minecraft:red_nether_bricks
fill 370 147 485 370 150 485 minecraft:pink_terracotta
setblock 370 147 489 minecraft:red_nether_bricks
fill 370 147 490 370 149 490 minecraft:pink_terracotta
setblock 370 147 494 minecraft:red_nether_bricks
fill 370 147 495 370 150 495 minecraft:pink_terracotta
setblock 370 147 499 minecraft:red_nether_bricks
fill 370 147 500 370 150 500 minecraft:pink_terracotta
setblock 370 147 504 minecraft:red_nether_bricks
fill 330 148 464 330 151 464 minecraft:pink_terracotta
setblock 330 148 468 minecraft:red_nether_bricks
fill 330 148 469 330 151 469 minecraft:pink_terracotta
setblock 330 148 473 minecraft:red_nether_bricks
fill 330 148 474 330 151 474 minecraft:pink_terracotta
setblock 330 148 478 minecraft:red_nether_bricks
fill 330 148 479 330 151 479 minecraft:pink_terracotta
setblock 330 148 482 minecraft:pink_terracotta
setblock 330 148 483 minecraft:red_nether_bricks
fill 330 148 484 330 151 484 minecraft:pink_terracotta
setblock 330 148 488 minecraft:red_nether_bricks
setblock 330 148 493 minecraft:red_nether_bricks
fill 330 148 494 330 150 494 minecraft:pink_terracotta
setblock 330 148 498 minecraft:red_nether_bricks
fill 330 148 499 330 151 499 minecraft:pink_terracotta
setblock 330 148 503 minecraft:red_nether_bricks
fill 330 148 504 330 151 504 minecraft:pink_terracotta
setblock 331 148 467 minecraft:red_nether_bricks
fill 331 148 468 331 150 468 minecraft:pink_terracotta
setblock 331 148 472 minecraft:red_nether_bricks
fill 331 148 473 331 149 473 minecraft:pink_terracotta
setblock 331 148 477 minecraft:red_nether_bricks
fill 331 148 478 331 151 478 minecraft:pink_terracotta
fill 331 148 480 331 149 480 minecraft:pink_terracotta
setblock 331 148 482 minecraft:red_nether_bricks
fill 331 148 483 331 150 483 minecraft:pink_terracotta
setblock 331 148 497 minecraft:red_nether_bricks
fill 331 148 498 331 151 498 minecraft:pink_terracotta
setblock 331 148 501 minecraft:pink_terracotta
setblock 331 148 502 minecraft:red_nether_bricks
fill 331 148 503 331 151 503 minecraft:pink_terracotta
setblock 332 148 476 minecraft:red_nether_bricks
setblock 332 148 477 minecraft:pink_terracotta
setblock 332 148 501 minecraft:red_nether_bricks
fill 332 148 502 332 151 502 minecraft:pink_terracotta
setblock 333 148 465 minecraft:red_nether_bricks
setblock 334 148 464 minecraft:red_nether_bricks
fill 334 148 465 334 149 465 minecraft:pink_terracotta
setblock 334 148 504 minecraft:red_nether_bricks
fill 335 148 464 335 151 464 minecraft:pink_terracotta
setblock 335 148 502 minecraft:pink_terracotta
setblock 335 148 503 minecraft:red_nether_bricks
fill 335 148 504 338 148 504 minecraft:pink_terracotta
setblock 336 148 502 minecraft:red_nether_bricks
fill 336 148 503 339 148 503 minecraft:pink_terracotta
fill 337 148 502 340 148 502 minecraft:pink_terracotta
setblock 338 148 464 minecraft:pink_terracotta
setblock 339 148 464 minecraft:red_nether_bricks
setblock 339 148 504 minecraft:red_nether_bricks
fill 340 148 464 343 148 464 minecraft:pink_terracotta
setblock 340 148 503 minecraft:red_nether_bricks
fill 340 148 504 340 151 504 minecraft:pink_terracotta
setblock 341 148 502 minecraft:red_nether_bricks
fill 341 148 503 341 151 503 minecraft:pink_terracotta
fill 342 148 502 345 148 502 minecraft:pink_terracotta
fill 343 148 501 346 148 501 minecraft:pink_terracotta
setblock 344 148 464 minecraft:red_nether_bricks
setblock 344 148 504 minecraft:red_nether_bricks
fill 345 148 464 345 151 464 minecraft:pink_terracotta
setblock 345 148 503 minecraft:red_nether_bricks
fill 345 148 504 345 151 504 minecraft:pink_terracotta
fill 346 148 500 347 148 500 minecraft:pink_terracotta
setblock 346 148 502 minecraft:red_nether_bricks
fill 346 148 503 346 151 503 minecraft:pink_terracotta
setblock 347 148 501 minecraft:red_nether_bricks
fill 347 148 502 347 151 502 minecraft:pink_terracotta
setblock 348 148 500 minecraft:red_nether_bricks
fill 348 148 501 348 151 501 minecraft:pink_terracotta
setblock 349 148 464 minecraft:red_nether_bricks
setblock 349 148 500 minecraft:pink_terracotta
setblock 349 148 504 minecraft:red_nether_bricks
fill 350 148 464 350 151 464 minecraft:pink_terracotta
setblock 350 148 503 minecraft:red_nether_bricks
fill 350 148 504 350 151 504 minecraft:pink_terracotta
setblock 351 148 501 minecraft:pink_terracotta
setblock 351 148 502 minecraft:red_nether_bricks
fill 351 148 503 351 151 503 minecraft:pink_terracotta
setblock 352 148 501 minecraft:red_nether_bricks
fill 352 148 502 352 150 502 minecraft:pink_terracotta
setblock 354 148 504 minecraft:red_nether_bricks
setblock 355 148 503 minecraft:red_nether_bricks
fill 355 148 504 355 151 504 minecraft:pink_terracotta
setblock 356 148 464 minecraft:white_concrete
fill 357 148 504 357 149 504 minecraft:pink_terracotta
fill 362 148 504 363 148 504 minecraft:pink_terracotta
setblock 364 148 464 minecraft:red_nether_bricks
setblock 364 148 503 minecraft:pink_terracotta
setblock 364 148 504 minecraft:red_nether_bricks
fill 365 148 464 365 151 464 minecraft:pink_terracotta
setblock 365 148 503 minecraft:red_nether_bricks
fill 365 148 504 365 151 504 minecraft:pink_terracotta
fill 366 148 465 367 148 465 minecraft:pink_terracotta
fill 366 148 478 366 149 480 minecraft:pink_terracotta
fill 366 148 503 366 151 503 minecraft:pink_terracotta
setblock 367 148 476 minecraft:red_nether_bricks
fill 367 148 477 367 151 477 minecraft:pink_terracotta
setblock 367 148 481 minecraft:red_nether_bricks
fill 367 148 482 367 150 483 minecraft:pink_terracotta
fill 367 148 502 368 150 502 minecraft:pink_terracotta
setblock 368 148 465 minecraft:red_nether_bricks
setblock 368 148 470 minecraft:red_nether_bricks
fill 368 148 471 368 150 471 minecraft:pink_terracotta
setblock 368 148 475 minecraft:red_nether_bricks
fill 368 148 476 368 151 476 minecraft:pink_terracotta
setblock 368 148 480 minecraft:red_nether_bricks
fill 368 148 481 368 151 481 minecraft:pink_terracotta
setblock 368 148 485 minecraft:red_nether_bricks
setblock 368 148 499 minecraft:pink_terracotta
setblock 368 148 500 minecraft:red_nether_bricks
fill 368 148 501 368 150 501 minecraft:pink_terracotta
setblock 369 148 464 minecraft:red_nether_bricks
fill 369 148 465 369 151 465 minecraft:pink_terracotta
setblock 369 148 469 minecraft:red_nether_bricks
fill 369 148 470 369 151 470 minecraft:pink_terracotta
setblock 369 148 474 minecraft:red_nether_bricks
fill 369 148 475 369 151 475 minecraft:pink_terracotta
setblock 369 148 479 minecraft:red_nether_bricks
fill 369 148 480 369 151 480 minecraft:pink_terracotta
setblock 369 148 484 minecraft:red_nether_bricks
fill 369 148 485 369 151 485 minecraft:pink_terracotta
setblock 369 148 495 minecraft:pink_terracotta
setblock 369 148 499 minecraft:red_nether_bricks
fill 369 148 500 369 151 500 minecraft:pink_terracotta
setblock 369 148 504 minecraft:red_nether_bricks
fill 370 148 464 370 151 464 minecraft:pink_terracotta
setblock 370 148 468 minecraft:red_nether_bricks
fill 370 148 469 370 151 469 minecraft:pink_terracotta
setblock 370 148 473 minecraft:red_nether_bricks
fill 370 148 474 370 151 474 minecraft:pink_terracotta
setblock 370 148 478 minecraft:red_nether_bricks
fill 370 148 479 370 151 479 minecraft:pink_terracotta
setblock 370 148 483 minecraft:red_nether_bricks
fill 370 148 484 370 151 484 minecraft:pink_terracotta
setblock 370 148 488 minecraft:red_nether_bricks
fill 370 148 489 370 150 489 minecraft:pink_terracotta
setblock 370 148 493 minecraft:red_nether_bricks
fill 370 148 494 370 149 494 minecraft:pink_terracotta
setblock 370 148 498 minecraft:red_nether_bricks
fill 370 148 499 370 151 499 minecraft:pink_terracotta
setblock 370 148 503 minecraft:red_nether_bricks
fill 370 148 504 370 151 504 minecraft:pink_terracotta
setblock 330 149 467 minecraft:red_nether_bricks
fill 330 149 468 330 152 468 minecraft:pink_terracotta
setblock 330 149 472 minecraft:red_nether_bricks
fill 330 149 473 330 152 473 minecraft:pink_terracotta
setblock 330 149 477 minecraft:red_nether_bricks
fill 330 149 478 330 152 478 minecraft:pink_terracotta
setblock 330 149 482 minecraft:red_nether_bricks
fill 330 149 483 330 152 483 minecraft:pink_terracotta
setblock 330 149 486 minecraft:pink_terracotta
setblock 330 149 487 minecraft:red_nether_bricks
setblock 330 149 493 minecraft:pink_terracotta
setblock 330 149 497 minecraft:red_nether_bricks
fill 330 149 498 330 152 498 minecraft:pink_terracotta
setblock 330 149 502 minecraft:red_nether_bricks
fill 330 149 503 330 152 503 minecraft:pink_terracotta
setblock 331 149 466 minecraft:red_nether_bricks
fill 331 149 467 331 151 467 minecraft:pink_terracotta
setblock 331 149 471 minecraft:red_nether_bricks
setblock 331 149 472 minecraft:pink_terracotta
setblock 331 149 476 minecraft:red_nether_bricks
fill 331 149 477 331 150 477 minecraft:pink_terracotta
setblock 331 149 481 minecraft:red_nether_bricks
fill 331 149 482 331 151 482 minecraft:pink_terracotta
setblock 331 149 496 minecraft:red_nether_bricks
fill 331 149 497 331 150 497 minecraft:pink_terracotta
setblock 331 149 501 minecraft:red_nether_bricks
fill 331 149 502 331 152 502 minecraft:pink_terracotta
setblock 332 149 465 minecraft:red_nether_bricks
setblock 332 149 500 minecraft:red_nether_bricks
fill 332 149 501 332 151 501 minecraft:pink_terracotta
setblock 333 149 464 minecraft:red_nether_bricks
fill 333 149 465 333 151 465 minecraft:pink_terracotta
setblock 333 149 504 minecraft:red_nether_bricks
fill 334 149 464 334 152 464 minecraft:pink_terracotta
setblock 334 149 503 minecraft:red_nether_bricks
fill 334 149 504 337 149 504 minecraft:pink_terracotta
setblock 335 149 502 minecraft:red_nether_bricks
fill 335 149 503 338 149 503 minecraft:pink_terracotta
fill 336 149 502 339 149 502 minecraft:pink_terracotta
setblock 338 149 464 minecraft:red_nether_bricks
setblock 338 149 504 minecraft:red_nether_bricks
fill 339 149 464 342 149 464 minecraft:pink_terracotta
setblock 339 149 503 minecraft:red_nether_bricks
fill 339 149 504 339 152 504 minecraft:pink_terracotta
setblock 340 149 502 minecraft:red_nether_bricks
fill 340 149 503 340 152 503 minecraft:pink_terracotta
fill 341 149 502 344 149 502 minecraft:pink_terracotta
fill 342 149 501 345 149 501 minecraft:pink_terracotta
setblock 343 149 464 minecraft:red_nether_bricks
setblock 343 149 504 minecraft:red_nether_bricks
fill 344 149 464 344 152 464 minecraft:pink_terracotta
setblock 344 149 503 minecraft:red_nether_bricks
fill 344 149 504 344 152 504 minecraft:pink_terracotta
setblock 345 149 502 minecraft:red_nether_bricks
fill 345 149 503 345 152 503 minecraft:pink_terracotta
setblock 346 149 500 minecraft:pink_terracotta
setblock 346 149 501 minecraft:red_nether_bricks
fill 346 149 502 346 152 502 minecraft:pink_terracotta
setblock 347 149 500 minecraft:red_nether_bricks
fill 347 149 501 347 152 501 minecraft:pink_terracotta
setblock 348 149 464 minecraft:red_nether_bricks
setblock 348 149 500 minecraft:pink_terracotta
setblock 348 149 504 minecraft:red_nether_bricks
fill 349 149 464 349 152 464 minecraft:pink_terracotta
setblock 349 149 503 minecraft:red_nether_bricks
fill 349 149 504 349 152 504 minecraft:pink_terracotta
setblock 350 149 502 minecraft:red_nether_bricks
fill 350 149 503 350 152 503 minecraft:pink_terracotta
setblock 351 149 501 minecraft:red_nether_bricks
fill 351 149 502 351 151 502 minecraft:pink_terracotta
setblock 353 149 504 minecraft:red_nether_bricks
setblock 354 149 503 minecraft:red_nether_bricks
fill 354 149 504 354 152 504 minecraft:pink_terracotta
fill 361 149 504 362 149 504 minecraft:pink_terracotta
setblock 363 149 464 minecraft:red_nether_bricks
setblock 363 149 504 minecraft:red_nether_bricks
fill 364 149 464 364 152 464 minecraft:pink_terracotta
setblock 364 149 503 minecraft:red_nether_bricks
fill 364 149 504 364 152 504 minecraft:pink_terracotta
fill 365 149 465 366 149 465 minecraft:pink_terracotta
fill 365 149 503 365 152 503 minecraft:pink_terracotta
setblock 367 149 465 minecraft:red_nether_bricks
setblock 367 149 475 minecraft:red_nether_bricks
fill 367 149 476 367 151 476 minecraft:pink_terracotta
setblock 367 149 480 minecraft:red_nether_bricks
fill 367 149 481 367 152 481 minecraft:pink_terracotta
setblock 368 149 464 minecraft:red_nether_bricks
fill 368 149 465 368 152 465 minecraft:pink_terracotta
setblock 368 149 470 minecraft:pink_terracotta
setblock 368 149 474 minecraft:red_nether_bricks
fill 368 149 475 368 152 475 minecraft:pink_terracotta
setblock 368 149 479 minecraft:red_nether_bricks
fill 368 149 480 368 152 480 minecraft:pink_terracotta
setblock 368 149 483 minecraft:pink_terracotta
setblock 368 149 484 minecraft:red_nether_bricks
fill 368 149 485 368 149 486 minecraft:pink_terracotta
setblock 368 149 500 minecraft:pink_terracotta
setblock 368 149 503 minecraft:pink_terracotta
setblock 368 149 504 minecraft:red_nether_bricks
fill 369 149 464 369 152 464 minecraft:pink_terracotta
setblock 369 149 468 minecraft:red_nether_bricks
fill 369 149 469 369 152 469 minecraft:pink_terracotta
setblock 369 149 473 minecraft:red_nether_bricks
fill 369 149 474 369 152 474 minecraft:pink_terracotta
setblock 369 149 478 minecraft:red_nether_bricks
fill 369 149 479 369 152 479 minecraft:pink_terracotta
setblock 369 149 483 minecraft:red_nether_bricks
fill 369 149 484 369 152 484 minecraft:pink_terracotta
setblock 369 149 488 minecraft:red_nether_bricks
setblock 369 149 498 minecraft:red_nether_bricks
fill 369 149 499 369 151 499 minecraft:pink_terracotta
setblock 369 149 503 minecraft:red_nether_bricks
fill 369 149 504 369 152 504 minecraft:pink_terracotta
setblock 370 149 467 minecraft:red_nether_bricks
fill 370 149 468 370 152 468 minecraft:pink_terracotta
setblock 370 149 472 minecraft:red_nether_bricks
fill 370 149 473 370 152 473 minecraft:pink_terracotta
setblock 370 149 477 minecraft:red_nether_bricks
fill 370 149 478 370 152 478 minecraft:pink_terracotta
setblock 370 149 482 minecraft:red_nether_bricks
fill 370 149 483 370 152 483 minecraft:pink_terracotta
setblock 370 149 487 minecraft:red_nether_bricks
fill 370 149 488 370 152 488 minecraft:pink_terracotta
setblock 370 149 492 minecraft:red_nether_bricks
setblock 370 149 493 minecraft:pink_terracotta
setblock 370 149 497 minecraft:red_nether_bricks
fill 370 149 498 370 151 498 minecraft:pink_terracotta
setblock 370 149 502 minecraft:red_nether_bricks
fill 370 149 503 370 152 503 minecraft:pink_terracotta
setblock 330 150 466 minecraft:red_nether_bricks
fill 330 150 467 330 153 467 minecraft:pink_terracotta
setblock 330 150 471 minecraft:red_nether_bricks
fill 330 150 472 330 152 472 minecraft:pink_terracotta
setblock 330 150 476 minecraft:red_nether_bricks
fill 330 150 477 330 152 477 minecraft:pink_terracotta
setblock 330 150 481 minecraft:red_nether_bricks
fill 330 150 482 330 153 482 minecraft:pink_terracotta
setblock 330 150 486 minecraft:red_nether_bricks
setblock 330 150 487 minecraft:pink_terracotta
setblock 330 150 496 minecraft:red_nether_bricks
fill 330 150 497 330 152 497 minecraft:pink_terracotta
setblock 330 150 501 minecraft:red_nether_bricks
fill 330 150 502 330 153 502 minecraft:pink_terracotta
setblock 331 150 465 minecraft:red_nether_bricks
fill 331 150 466 331 153 466 minecraft:pink_terracotta
setblock 331 150 475 minecraft:red_nether_bricks
setblock 331 150 476 minecraft:pink_terracotta
setblock 331 150 480 minecraft:red_nether_bricks
fill 331 150 481 331 151 481 minecraft:pink_terracotta
setblock 331 150 500 minecraft:red_nether_bricks
fill 331 150 501 331 153 501 minecraft:pink_terracotta
setblock 332 150 464 minecraft:red_nether_bricks
fill 332 150 465 332 152 465 minecraft:pink_terracotta
setblock 332 150 500 minecraft:pink_terracotta
setblock 332 150 504 minecraft:red_nether_bricks
fill 333 150 464 333 153 464 minecraft:pink_terracotta
setblock 333 150 503 minecraft:red_nether_bricks
fill 333 150 504 336 150 504 minecraft:pink_terracotta
setblock 334 150 502 minecraft:red_nether_bricks
fill 334 150 503 337 150 503 minecraft:pink_terracotta
setblock 335 150 502 minecraft:pink_terracotta
setblock 337 150 464 minecraft:red_nether_bricks
setblock 337 150 504 minecraft:red_nether_bricks
fill 338 150 464 341 150 464 minecraft:pink_terracotta
setblock 338 150 502 minecraft:pink_terracotta
setblock 338 150 503 minecraft:red_nether_bricks
fill 338 150 504 338 153 504 minecraft:pink_terracotta
setblock 339 150 502 minecraft:red_nether_bricks
fill 339 150 503 339 153 503 minecraft:pink_terracotta
fill 340 150 502 343 150 502 minecraft:pink_terracotta
setblock 342 150 464 minecraft:red_nether_bricks
fill 342 150 501 344 150 501 minecraft:pink_terracotta
setblock 342 150 504 minecraft:red_nether_bricks
fill 343 150 464 343 153 464 minecraft:pink_terracotta
setblock 343 150 503 minecraft:red_nether_bricks
fill 343 150 504 343 153 504 minecraft:pink_terracotta
setblock 344 150 502 minecraft:red_nether_bricks
fill 344 150 503 344 153 503 minecraft:pink_terracotta
setblock 345 150 501 minecraft:red_nether_bricks
fill 345 150 502 345 153 502 minecraft:pink_terracotta
setblock 346 150 465 minecraft:red_nether_bricks
fill 346 150 501 346 152 501 minecraft:pink_terracotta
setblock 347 150 464 minecraft:red_nether_bricks
setblock 347 150 504 minecraft:red_nether_bricks
fill 348 150 464 348 153 464 minecraft:pink_terracotta
setblock 348 150 503 minecraft:red_nether_bricks
fill 348 150 504 348 153 504 minecraft:pink_terracotta
setblock 349 150 502 minecraft:red_nether_bricks
fill 349 150 503 349 153 503 minecraft:pink_terracotta
setblock 350 150 501 minecraft:red_nether_bricks
fill 350 150 502 350 152 502 minecraft:pink_terracotta
setblock 352 150 464 minecraft:red_nether_bricks
setblock 352 150 504 minecraft:red_nether_bricks
setblock 353 150 503 minecraft:red_nether_bricks
fill 353 150 504 353 153 504 minecraft:pink_terracotta
setblock 354 150 503 minecraft:pink_terracotta
fill 360 150 504 361 150 504 minecraft:pink_terracotta
setblock 362 150 464 minecraft:red_nether_bricks
setblock 362 150 504 minecraft:red_nether_bricks
fill 363 150 464 363 153 464 minecraft:pink_terracotta
setblock 363 150 503 minecraft:red_nether_bricks
fill 363 150 504 363 153 504 minecraft:pink_terracotta
fill 364 150 465 365 150 465 minecraft:pink_terracotta
fill 364 150 503 364 153 503 minecraft:pink_terracotta
setblock 366 150 465 minecraft:red_nether_bricks
setblock 366 150 480 minecraft:red_nether_bricks
setblock 367 150 464 minecraft:red_nether_bricks
fill 367 150 465 367 153 465 minecraft:pink_terracotta
setblock 367 150 475 minecraft:pink_terracotta
setblock 367 150 479 minecraft:red_nether_bricks
fill 367 150 480 367 152 480 minecraft:pink_terracotta
setblock 367 150 484 minecraft:red_nether_bricks
setblock 367 150 504 minecraft:red_nether_bricks
fill 368 150 464 368 153 464 minecraft:pink_terracotta
setblock 368 150 473 minecraft:red_nether_bricks
fill 368 150 474 368 151 474 minecraft:pink_terracotta
setblock 368 150 478 minecraft:red_nether_bricks
fill 368 150 479 368 153 479 minecraft:pink_terracotta
setblock 368 150 483 minecraft:red_nether_bricks
fill 368 150 484 368 152 485 minecraft:pink_terracotta
setblock 368 150 503 minecraft:red_nether_bricks
fill 368 150 504 368 153 504 minecraft:pink_terracotta
setblock 369 150 467 minecraft:red_nether_bricks
fill 369 150 468 369 153 468 minecraft:pink_terracotta
setblock 369 150 472 minecraft:red_nether_bricks
fill 369 150 473 369 152 473 minecraft:pink_terracotta
setblock 369 150 477 minecraft:red_nether_bricks
fill 369 150 478 369 153 478 minecraft:pink_terracotta
setblock 369 150 482 minecraft:red_nether_bricks
fill 369 150 483 369 153 483 minecraft:pink_terracotta
setblock 369 150 487 minecraft:red_nether_bricks
setblock 369 150 498 minecraft:pink_terracotta
setblock 369 150 502 minecraft:red_nether_bricks
fill 369 150 503 369 153 503 minecraft:pink_terracotta
setblock 370 150 466 minecraft:red_nether_bricks
fill 370 150 467 370 153 467 minecraft:pink_terracotta
setblock 370 150 471 minecraft:red_nether_bricks
fill 370 150 472 370 153 472 minecraft:pink_terracotta
setblock 370 150 476 minecraft:red_nether_bricks
fill 370 150 477 370 153 477 minecraft:pink_terracotta
setblock 370 150 481 minecraft:red_nether_bricks
fill 370 150 482 370 153 482 minecraft:pink_terracotta
setblock 370 150 486 minecraft:red_nether_bricks
fill 370 150 487 370 153 487 minecraft:pink_terracotta
setblock 370 150 496 minecraft:red_nether_bricks
fill 370 150 497 370 151 497 minecraft:pink_terracotta
setblock 370 150 501 minecraft:red_nether_bricks
fill 370 150 502 370 153 502 minecraft:pink_terracotta
setblock 330 151 465 minecraft:red_nether_bricks
fill 330 151 466 330 154 466 minecraft:pink_terracotta
setblock 330 151 470 minecraft:red_nether_bricks
fill 330 151 471 330 152 471 minecraft:pink_terracotta
setblock 330 151 475 minecraft:red_nether_bricks
fill 330 151 476 330 152 476 minecraft:pink_terracotta
setblock 330 151 480 minecraft:red_nether_bricks
fill 330 151 481 330 154 481 minecraft:pink_terracotta
setblock 330 151 485 minecraft:red_nether_bricks
fill 330 151 486 330 152 486 minecraft:pink_terracotta
setblock 330 151 492 minecraft:white_concrete
setblock 330 151 496 minecraft:pink_terracotta
setblock 330 151 500 minecraft:red_nether_bricks
fill 330 151 501 330 154 501 minecraft:pink_terracotta
setblock 331 151 464 minecraft:red_nether_bricks
fill 331 151 465 331 154 465 minecraft:pink_terracotta
setblock 331 151 479 minecraft:red_nether_bricks
setblock 331 151 480 minecraft:pink_terracotta
setblock 331 151 499 minecraft:red_nether_bricks
fill 331 151 500 331 152 500 minecraft:pink_terracotta
setblock 331 151 504 minecraft:red_nether_bricks
fill 332 151 464 332 154 464 minecraft:pink_terracotta
setblock 332 151 503 minecraft:red_nether_bricks
fill 332 151 504 335 151 504 minecraft:pink_terracotta
setblock 333 151 502 minecraft:red_nether_bricks
fill 333 151 503 336 151 503 minecraft:pink_terracotta
setblock 336 151 464 minecraft:red_nether_bricks
setblock 336 151 504 minecraft:red_nether_bricks
fill 337 151 464 340 151 464 minecraft:pink_terracotta
setblock 337 151 503 minecraft:red_nether_bricks
fill 337 151 504 337 154 504 minecraft:pink_terracotta
fill 338 151 503 338 154 503 minecraft:pink_terracotta
fill 339 151 502 342 151 502 minecraft:pink_terracotta
setblock 341 151 464 minecraft:red_nether_bricks
setblock 341 151 504 minecraft:red_nether_bricks
fill 342 151 464 342 154 464 minecraft:pink_terracotta
setblock 342 151 503 minecraft:red_nether_bricks
fill 342 151 504 342 154 504 minecraft:pink_terracotta
setblock 343 151 501 minecraft:pink_terracotta
setblock 343 151 502 minecraft:red_nether_bricks
fill 343 151 503 343 154 503 minecraft:pink_terracotta
setblock 344 151 501 minecraft:red_nether_bricks
fill 344 151 502 344 154 502 minecraft:pink_terracotta
fill 345 151 501 345 152 501 minecraft:pink_terracotta
setblock 346 151 464 minecraft:red_nether_bricks
setblock 346 151 465 minecraft:pink_terracotta
setblock 346 151 504 minecraft:red_nether_bricks
fill 347 151 464 347 154 464 minecraft:pink_terracotta
setblock 347 151 503 minecraft:red_nether_bricks
fill 347 151 504 347 154 504 minecraft:pink_terracotta
setblock 348 151 502 minecraft:red_nether_bricks
fill 348 151 503 348 154 503 minecraft:pink_terracotta
setblock 349 151 501 minecraft:red_nether_bricks
fill 349 151 502 349 152 502 minecraft:pink_terracotta
setblock 351 151 464 minecraft:red_nether_bricks
setblock 351 151 504 minecraft:red_nether_bricks
setblock 352 151 503 minecraft:red_nether_bricks
fill 352 151 504 352 153 504 minecraft:pink_terracotta
setblock 353 151 503 minecraft:pink_terracotta
setblock 357 151 464 minecraft:white_concrete
setblock 360 151 504 minecraft:pink_terracotta
setblock 361 151 464 minecraft:red_nether_bricks
setblock 361 151 504 minecraft:red_nether_bricks
fill 362 151 464 362 154 464 minecraft:pink_terracotta
fill 362 151 504 362 154 504 minecraft:pink_terracotta
fill 363 151 503 363 152 503 minecraft:pink_terracotta
setblock 364 151 465 minecraft:pink_terracotta
setblock 365 151 465 minecraft:red_nether_bricks
setblock 366 151 464 minecraft:red_nether_bricks
fill 366 151 465 366 154 465 minecraft:pink_terracotta
setblock 366 151 504 minecraft:red_nether_bricks
fill 367 151 464 367 154 464 minecraft:pink_terracotta
setblock 367 151 478 minecraft:red_nether_bricks
fill 367 151 479 367 152 479 minecraft:pink_terracotta
setblock 367 151 482 minecraft:pink_terracotta
setblock 367 151 483 minecraft:red_nether_bricks
setblock 367 151 503 minecraft:red_nether_bricks
fill 367 151 504 367 154 504 minecraft:pink_terracotta
setblock 368 151 466 minecraft:pink_terracotta
setblock 368 151 473 minecraft:pink_terracotta
setblock 368 151 477 minecraft:red_nether_bricks
fill 368 151 478 368 153 478 minecraft:pink_terracotta
setblock 368 151 482 minecraft:red_nether_bricks
fill 368 151 483 368 154 483 minecraft:pink_terracotta
fill 368 151 503 368 154 503 minecraft:pink_terracotta
setblock 369 151 466 minecraft:red_nether_bricks
fill 369 151 467 369 154 467 minecraft:pink_terracotta
setblock 369 151 471 minecraft:red_nether_bricks
fill 369 151 472 369 152 472 minecraft:pink_terracotta
setblock 369 151 476 minecraft:red_nether_bricks
fill 369 151 477 369 154 477 minecraft:pink_terracotta
setblock 369 151 481 minecraft:red_nether_bricks
fill 369 151 482 369 154 482 minecraft:pink_terracotta
setblock 369 151 486 minecraft:red_nether_bricks
setblock 369 151 487 minecraft:pink_terracotta
setblock 369 151 501 minecraft:red_nether_bricks
fill 369 151 502 369 153 502 minecraft:pink_terracotta
setblock 370 151 465 minecraft:red_nether_bricks
fill 370 151 466 370 154 466 minecraft:pink_terracotta
setblock 370 151 470 minecraft:red_nether_bricks
fill 370 151 471 370 154 471 minecraft:pink_terracotta
setblock 370 151 475 minecraft:red_nether_bricks
fill 370 151 476 370 154 476 minecraft:pink_terracotta
setblock 370 151 480 minecraft:red_nether_bricks
fill 370 151 481 370 154 481 minecraft:pink_terracotta
setblock 370 151 485 minecraft:red_nether_bricks
fill 370 151 486 370 154 486 minecraft:pink_terracotta
setblock 370 151 495 minecraft:white_concrete
setblock 370 151 500 minecraft:red_nether_bricks
fill 370 151 501 370 154 501 minecraft:pink_terracotta
setblock 330 152 464 minecraft:red_nether_bricks
fill 330 152 465 330 155 465 minecraft:pink_terracotta
setblock 330 152 469 minecraft:red_nether_bricks
setblock 330 152 470 minecraft:pink_terracotta
setblock 330 152 474 minecraft:red_nether_bricks
setblock 330 152 475 minecraft:pink_terracotta
setblock 330 152 479 minecraft:red_nether_bricks
fill 330 152 480 330 153 480 minecraft:pink_terracotta
setblock 330 152 484 minecraft:red_nether_bricks
fill 330 152 485 330 153 485 minecraft:pink_terracotta
setblock 330 152 499 minecraft:red_nether_bricks
fill 330 152 500 330 155 500 minecraft:pink_terracotta
setblock 330 152 504 minecraft:red_nether_bricks
fill 331 152 464 331 155 464 minecraft:pink_terracotta
setblock 331 152 503 minecraft:red_nether_bricks
fill 331 152 504 334 152 504 minecraft:pink_terracotta
fill 332 152 503 335 152 503 minecraft:pink_terracotta
setblock 335 152 464 minecraft:red_nether_bricks
setblock 335 152 504 minecraft:red_nether_bricks
fill 336 152 464 339 152 464 minecraft:pink_terracotta
setblock 336 152 503 minecraft:red_nether_bricks
fill 336 152 504 336 155 504 minecraft:pink_terracotta
fill 337 152 503 337 155 503 minecraft:pink_terracotta
setblock 340 152 464 minecraft:red_nether_bricks
fill 340 152 502 341 152 502 minecraft:pink_terracotta
setblock 340 152 504 minecraft:red_nether_bricks
fill 341 152 464 341 155 464 minecraft:pink_terracotta
setblock 341 152 503 minecraft:red_nether_bricks
fill 341 152 504 341 155 504 minecraft:pink_terracotta
setblock 342 152 502 minecraft:red_nether_bricks
fill 342 152 503 342 155 503 minecraft:pink_terracotta
fill 343 152 502 343 155 502 minecraft:pink_terracotta
setblock 344 152 501 minecraft:pink_terracotta
setblock 345 152 464 minecraft:red_nether_bricks
setblock 345 152 504 minecraft:red_nether_bricks
fill 346 152 464 346 155 464 minecraft:pink_terracotta
setblock 346 152 503 minecraft:red_nether_bricks
fill 346 152 504 346 155 504 minecraft:pink_terracotta
setblock 347 152 502 minecraft:red_nether_bricks
fill 347 152 503 347 155 503 minecraft:pink_terracotta
fill 348 152 502 348 153 502 minecraft:pink_terracotta
setblock 350 152 464 minecraft:red_nether_bricks
setblock 350 152 504 minecraft:red_nether_bricks
setblock 351 152 464 minecraft:white_concrete
setblock 351 152 503 minecraft:red_nether_bricks
fill 351 152 504 351 154 504 minecraft:pink_terracotta
setblock 352 152 503 minecraft:pink_terracotta
setblock 360 152 504 minecraft:red_nether_bricks
fill 361 152 464 361 155 464 minecraft:pink_terracotta
fill 361 152 504 361 155 504 minecraft:pink_terracotta
setblock 363 152 465 minecraft:pink_terracotta
setblock 364 152 465 minecraft:red_nether_bricks
setblock 365 152 464 minecraft:red_nether_bricks
fill 365 152 465 365 155 465 minecraft:pink_terracotta
setblock 365 152 504 minecraft:red_nether_bricks
fill 366 152 464 366 155 464 minecraft:pink_terracotta
setblock 366 152 503 minecraft:red_nether_bricks
fill 366 152 504 366 155 504 minecraft:pink_terracotta
setblock 367 152 466 minecraft:pink_terracotta
setblock 367 152 478 minecraft:pink_terracotta
setblock 367 152 482 minecraft:red_nether_bricks
setblock 367 152 483 minecraft:pink_terracotta
fill 367 152 503 367 155 503 minecraft:pink_terracotta
setblock 368 152 466 minecraft:red_nether_bricks
setblock 368 152 476 minecraft:red_nether_bricks
fill 368 152 477 368 153 477 minecraft:pink_terracotta
setblock 368 152 481 minecraft:red_nether_bricks
fill 368 152 482 368 154 482 minecraft:pink_terracotta
setblock 369 152 465 minecraft:red_nether_bricks
fill 369 152 466 369 155 466 minecraft:pink_terracotta
setblock 369 152 470 minecraft:red_nether_bricks
setblock 369 152 471 minecraft:pink_terracotta
setblock 369 152 475 minecraft:red_nether_bricks
fill 369 152 476 369 153 476 minecraft:pink_terracotta
setblock 369 152 480 minecraft:red_nether_bricks
fill 369 152 481 369 155 481 minecraft:pink_terracotta
setblock 369 152 485 minecraft:red_nether_bricks
fill 369 152 486 369 153 486 minecraft:pink_terracotta
setblock 369 152 501 minecraft:pink_terracotta
setblock 370 152 464 minecraft:red_nether_bricks
fill 370 152 465 370 155 465 minecraft:pink_terracotta
setblock 370 152 469 minecraft:red_nether_bricks
fill 370 152 470 370 155 470 minecraft:pink_terracotta
setblock 370 152 474 minecraft:red_nether_bricks
fill 370 152 475 370 154 475 minecraft:pink_terracotta
setblock 370 152 479 minecraft:red_nether_bricks
fill 370 152 480 370 155 480 minecraft:pink_terracotta
setblock 370 152 484 minecraft:red_nether_bricks
fill 370 152 485 370 155 485 minecraft:pink_terracotta
setblock 370 152 489 minecraft:white_concrete
setblock 370 152 499 minecraft:red_nether_bricks
fill 370 152 500 370 153 500 minecraft:pink_terracotta
setblock 370 152 504 minecraft:red_nether_bricks
fill 330 153 464 330 156 464 minecraft:pink_terracotta
setblock 330 153 468 minecraft:red_nether_bricks
fill 330 153 469 330 154 469 minecraft:pink_terracotta
setblock 330 153 478 minecraft:red_nether_bricks
setblock 330 153 479 minecraft:pink_terracotta
setblock 330 153 483 minecraft:red_nether_bricks
fill 330 153 484 330 154 484 minecraft:pink_terracotta
setblock 330 153 498 minecraft:red_nether_bricks
fill 330 153 499 330 154 499 minecraft:pink_terracotta
setblock 330 153 503 minecraft:red_nether_bricks
fill 330 153 504 333 153 504 minecraft:pink_terracotta
setblock 331 153 502 minecraft:red_nether_bricks
fill 331 153 503 334 153 503 minecraft:pink_terracotta
setblock 332 153 466 minecraft:light[level=12]
setblock 332 153 474 minecraft:light[level=12]
setblock 332 153 482 minecraft:light[level=12]
setblock 332 153 490 minecraft:light[level=12]
setblock 332 153 498 minecraft:light[level=12]
setblock 334 153 464 minecraft:red_nether_bricks
setblock 334 153 504 minecraft:red_nether_bricks
fill 335 153 464 338 153 464 minecraft:pink_terracotta
setblock 335 153 503 minecraft:red_nether_bricks
fill 335 153 504 335 156 504 minecraft:pink_terracotta
fill 336 153 503 336 154 503 minecraft:pink_terracotta
setblock 339 153 464 minecraft:red_nether_bricks
setblock 339 153 504 minecraft:red_nether_bricks
fill 340 153 464 340 156 464 minecraft:pink_terracotta
setblock 340 153 466 minecraft:light[level=12]
setblock 340 153 474 minecraft:light[level=12]
setblock 340 153 482 minecraft:light[level=12]
setblock 340 153 490 minecraft:light[level=12]
setblock 340 153 498 minecraft:light[level=12]
setblock 340 153 502 minecraft:pink_terracotta
setblock 340 153 503 minecraft:red_nether_bricks
fill 340 153 504 340 156 504 minecraft:pink_terracotta
setblock 341 153 502 minecraft:red_nether_bricks
fill 341 153 503 341 156 503 minecraft:pink_terracotta
fill 342 153 502 342 156 502 minecraft:pink_terracotta
setblock 344 153 464 minecraft:red_nether_bricks
setblock 344 153 504 minecraft:red_nether_bricks
fill 345 153 464 345 156 464 minecraft:pink_terracotta
setblock 345 153 503 minecraft:red_nether_bricks
fill 345 153 504 345 156 504 minecraft:pink_terracotta
setblock 346 153 502 minecraft:red_nether_bricks
fill 346 153 503 346 156 503 minecraft:pink_terracotta
fill 347 153 502 347 154 502 minecraft:pink_terracotta
setblock 348 153 466 minecraft:light[level=12]
setblock 348 153 474 minecraft:light[level=12]
setblock 348 153 482 minecraft:light[level=12]
setblock 348 153 490 minecraft:light[level=12]
setblock 348 153 498 minecraft:light[level=12]
setblock 349 153 464 minecraft:red_nether_bricks
setblock 349 153 504 minecraft:red_nether_bricks
setblock 350 153 464 minecraft:pink_terracotta
setblock 350 153 503 minecraft:red_nether_bricks
fill 350 153 504 350 156 504 minecraft:pink_terracotta
setblock 355 153 504 minecraft:white_concrete
setblock 356 153 466 minecraft:light[level=12]
setblock 356 153 474 minecraft:light[level=12]
setblock 356 153 482 minecraft:light[level=12]
setblock 356 153 490 minecraft:light[level=12]
setblock 356 153 498 minecraft:light[level=12]
fill 360 153 464 360 156 464 minecraft:pink_terracotta
fill 360 153 504 360 156 504 minecraft:pink_terracotta
setblock 363 153 465 minecraft:red_nether_bricks
setblock 364 153 464 minecraft:red_nether_bricks
fill 364 153 465 364 156 465 minecraft:pink_terracotta
setblock 364 153 466 minecraft:light[level=12]
setblock 364 153 474 minecraft:light[level=12]
setblock 364 153 482 minecraft:light[level=12]
setblock 364 153 490 minecraft:light[level=12]
setblock 364 153 498 minecraft:light[level=12]
setblock 364 153 504 minecraft:red_nether_bricks
fill 365 153 464 365 156 464 minecraft:pink_terracotta
setblock 365 153 503 minecraft:red_nether_bricks
fill 365 153 504 365 156 504 minecraft:pink_terracotta
setblock 366 153 466 minecraft:pink_terracotta
fill 366 153 503 366 155 503 minecraft:pink_terracotta
setblock 367 153 466 minecraft:red_nether_bricks
setblock 368 153 465 minecraft:red_nether_bricks
setblock 368 153 480 minecraft:red_nether_bricks
fill 368 153 481 368 154 481 minecraft:pink_terracotta
setblock 368 153 484 minecraft:pink_terracotta
setblock 369 153 464 minecraft:red_nether_bricks
fill 369 153 465 369 156 465 minecraft:pink_terracotta
setblock 369 153 469 minecraft:red_nether_bricks
setblock 369 153 470 minecraft:pink_terracotta
setblock 369 153 474 minecraft:red_nether_bricks
setblock 369 153 475 minecraft:pink_terracotta
setblock 369 153 479 minecraft:red_nether_bricks
fill 369 153 480 369 155 480 minecraft:pink_terracotta
setblock 369 153 484 minecraft:red_nether_bricks
fill 369 153 485 369 154 485 minecraft:pink_terracotta
setblock 369 153 504 minecraft:red_nether_bricks
fill 370 153 464 370 156 464 minecraft:pink_terracotta
setblock 370 153 468 minecraft:red_nether_bricks
fill 370 153 469 370 156 469 minecraft:pink_terracotta
setblock 370 153 473 minecraft:red_nether_bricks
fill 370 153 474 370 154 474 minecraft:pink_terracotta
setblock 370 153 478 minecraft:red_nether_bricks
fill 370 153 479 370 155 479 minecraft:pink_terracotta
setblock 370 153 483 minecraft:red_nether_bricks
fill 370 153 484 370 156 484 minecraft:pink_terracotta
setblock 370 153 503 minecraft:red_nether_bricks
fill 370 153 504 370 156 504 minecraft:pink_terracotta
setblock 330 154 467 minecraft:red_nether_bricks
fill 330 154 468 330 157 468 minecraft:pink_terracotta
setblock 330 154 482 minecraft:red_nether_bricks
setblock 330 154 483 minecraft:pink_terracotta
setblock 330 154 491 minecraft:white_concrete
setblock 330 154 502 minecraft:red_nether_bricks
fill 330 154 503 332 154 504 minecraft:pink_terracotta
setblock 331 154 502 minecraft:pink_terracotta
setblock 333 154 464 minecraft:red_nether_bricks
setblock 333 154 503 minecraft:pink_terracotta
setblock 333 154 504 minecraft:red_nether_bricks
fill 334 154 464 337 154 464 minecraft:pink_terracotta
setblock 334 154 503 minecraft:red_nether_bricks
fill 334 154 504 334 157 504 minecraft:pink_terracotta
setblock 335 154 503 minecraft:pink_terracotta
setblock 338 154 464 minecraft:red_nether_bricks
setblock 338 154 504 minecraft:red_nether_bricks
fill 339 154 464 339 157 464 minecraft:pink_terracotta
setblock 339 154 503 minecraft:red_nether_bricks
fill 339 154 504 339 157 504 minecraft:pink_terracotta
fill 340 154 503 340 157 503 minecraft:pink_terracotta
fill 341 154 502 341 155 502 minecraft:pink_terracotta
setblock 343 154 464 minecraft:red_nether_bricks
setblock 343 154 504 minecraft:red_nether_bricks
fill 344 154 464 344 156 465 minecraft:pink_terracotta
setblock 344 154 503 minecraft:red_nether_bricks
fill 344 154 504 344 157 504 minecraft:pink_terracotta
setblock 345 154 502 minecraft:red_nether_bricks
fill 345 154 503 345 157 503 minecraft:pink_terracotta
setblock 346 154 502 minecraft:pink_terracotta
setblock 348 154 464 minecraft:red_nether_bricks
setblock 348 154 504 minecraft:red_nether_bricks
fill 349 154 464 349 157 464 minecraft:pink_terracotta
setblock 349 154 503 minecraft:red_nether_bricks
fill 349 154 504 349 157 504 minecraft:pink_terracotta
fill 358 154 464 358 155 464 minecraft:white_concrete
setblock 362 154 465 minecraft:red_nether_bricks
setblock 363 154 464 minecraft:red_nether_bricks
fill 363 154 465 363 157 465 minecraft:pink_terracotta
setblock 363 154 504 minecraft:red_nether_bricks
fill 364 154 464 364 157 464 minecraft:pink_terracotta
setblock 364 154 503 minecraft:red_nether_bricks
fill 364 154 504 364 157 504 minecraft:pink_terracotta
setblock 365 154 466 minecraft:pink_terracotta
fill 365 154 503 365 155 503 minecraft:pink_terracotta
setblock 366 154 466 minecraft:red_nether_bricks
setblock 367 154 465 minecraft:red_nether_bricks
fill 367 154 466 367 157 466 minecraft:pink_terracotta
setblock 368 154 464 minecraft:red_nether_bricks
fill 368 154 465 368 157 465 minecraft:pink_terracotta
setblock 368 154 480 minecraft:pink_terracotta
setblock 368 154 504 minecraft:red_nether_bricks
fill 369 154 464 369 157 464 minecraft:pink_terracotta
setblock 369 154 468 minecraft:red_nether_bricks
fill 369 154 469 369 157 469 minecraft:pink_terracotta
setblock 369 154 478 minecraft:red_nether_bricks
setblock 369 154 479 minecraft:pink_terracotta
setblock 369 154 483 minecraft:red_nether_bricks
fill 369 154 484 369 155 484 minecraft:pink_terracotta
setblock 369 154 503 minecraft:red_nether_bricks
fill 369 154 504 369 157 504 minecraft:pink_terracotta
setblock 370 154 467 minecraft:red_nether_bricks
fill 370 154 468 370 157 468 minecraft:pink_terracotta
setblock 370 154 472 minecraft:red_nether_bricks
setblock 370 154 473 minecraft:pink_terracotta
setblock 370 154 477 minecraft:red_nether_bricks
fill 370 154 478 370 155 478 minecraft:pink_terracotta
setblock 370 154 482 minecraft:red_nether_bricks
fill 370 154 483 370 157 483 minecraft:pink_terracotta
setblock 370 154 487 minecraft:red_nether_bricks
setblock 370 154 502 minecraft:red_nether_bricks
fill 370 154 503 370 157 503 minecraft:pink_terracotta
setblock 330 155 466 minecraft:red_nether_bricks
fill 330 155 467 330 158 467 minecraft:pink_terracotta
setblock 330 155 472 minecraft:white_concrete
setblock 330 155 497 minecraft:white_concrete
setblock 330 155 501 minecraft:red_nether_bricks
fill 330 155 502 330 156 504 minecraft:pink_terracotta
setblock 331 155 465 minecraft:red_nether_bricks
fill 331 155 503 331 155 504 minecraft:pink_terracotta
setblock 332 155 464 minecraft:red_nether_bricks
setblock 332 155 503 minecraft:pink_terracotta
setblock 332 155 504 minecraft:red_nether_bricks
fill 333 155 464 336 155 464 minecraft:pink_terracotta
fill 333 155 504 333 158 504 minecraft:pink_terracotta
setblock 337 155 464 minecraft:red_nether_bricks
setblock 337 155 504 minecraft:red_nether_bricks
fill 338 155 464 338 158 464 minecraft:pink_terracotta
setblock 338 155 503 minecraft:red_nether_bricks
fill 338 155 504 338 158 504 minecraft:pink_terracotta
fill 339 155 503 339 158 503 minecraft:pink_terracotta
setblock 342 155 464 minecraft:red_nether_bricks
fill 342 155 465 343 157 465 minecraft:pink_terracotta
setblock 342 155 504 minecraft:red_nether_bricks
fill 343 155 464 343 158 464 minecraft:pink_terracotta
setblock 343 155 503 minecraft:red_nether_bricks
fill 343 155 504 343 158 504 minecraft:pink_terracotta
setblock 344 155 502 minecraft:red_nether_bricks
fill 344 155 503 344 158 503 minecraft:pink_terracotta
setblock 345 155 502 minecraft:pink_terracotta
setblock 347 155 464 minecraft:red_nether_bricks
setblock 347 155 504 minecraft:red_nether_bricks
fill 348 155 464 348 158 464 minecraft:pink_terracotta
setblock 348 155 503 minecraft:red_nether_bricks
fill 348 155 504 348 158 504 minecraft:pink_terracotta
setblock 352 155 464 minecraft:white_concrete
fill 359 155 464 359 157 464 minecraft:pink_terracotta
setblock 361 155 465 minecraft:red_nether_bricks
setblock 362 155 464 minecraft:red_nether_bricks
fill 362 155 465 362 158 465 minecraft:pink_terracotta
setblock 362 155 504 minecraft:red_nether_bricks
fill 363 155 464 363 158 464 minecraft:pink_terracotta
fill 363 155 504 363 158 504 minecraft:pink_terracotta
setblock 364 155 466 minecraft:pink_terracotta
setblock 365 155 466 minecraft:red_nether_bricks
setblock 366 155 465 minecraft:red_nether_bricks
fill 366 155 466 366 158 466 minecraft:pink_terracotta
setblock 367 155 464 minecraft:red_nether_bricks
fill 367 155 465 367 158 465 minecraft:pink_terracotta
setblock 367 155 504 minecraft:red_nether_bricks
fill 368 155 464 368 158 464 minecraft:pink_terracotta
fill 368 155 466 368 156 466 minecraft:pink_terracotta
fill 368 155 504 368 158 504 minecraft:pink_terracotta
setblock 369 155 467 minecraft:red_nether_bricks
fill 369 155 468 369 158 468 minecraft:pink_terracotta
setblock 369 155 482 minecraft:red_nether_bricks
setblock 369 155 483 minecraft:pink_terracotta
setblock 370 155 466 minecraft:red_nether_bricks
fill 370 155 467 370 158 467 minecraft:pink_terracotta
setblock 370 155 471 minecraft:red_nether_bricks
setblock 370 155 477 minecraft:pink_terracotta
setblock 370 155 481 minecraft:red_nether_bricks
fill 370 155 482 370 157 482 minecraft:pink_terracotta
setblock 370 155 486 minecraft:red_nether_bricks
fill 370 155 490 370 156 490 minecraft:white_concrete
setblock 370 155 496 minecraft:white_concrete
setblock 370 155 502 minecraft:pink_terracotta
setblock 330 156 465 minecraft:red_nether_bricks
fill 330 156 466 330 159 466 minecraft:pink_terracotta
setblock 330 156 478 minecraft:white_concrete
fill 330 156 501 330 159 501 minecraft:pink_terracotta
setblock 331 156 464 minecraft:red_nether_bricks
fill 331 156 465 331 159 465 minecraft:pink_terracotta
setblock 331 156 504 minecraft:red_nether_bricks
fill 332 156 464 335 156 464 minecraft:pink_terracotta
fill 332 156 504 332 159 504 minecraft:pink_terracotta
setblock 336 156 464 minecraft:red_nether_bricks
setblock 336 156 504 minecraft:red_nether_bricks
fill 337 156 464 337 159 464 minecraft:pink_terracotta
setblock 337 156 503 minecraft:red_nether_bricks
fill 337 156 504 337 159 504 minecraft:pink_terracotta
fill 338 156 503 338 159 503 minecraft:pink_terracotta
setblock 341 156 464 minecraft:red_nether_bricks
fill 341 156 465 341 159 465 minecraft:pink_terracotta
setblock 341 156 504 minecraft:red_nether_bricks
fill 342 156 464 342 159 464 minecraft:pink_terracotta
setblock 342 156 503 minecraft:red_nether_bricks
fill 342 156 504 342 159 504 minecraft:pink_terracotta
setblock 343 156 502 minecraft:red_nether_bricks
fill 343 156 503 343 159 503 minecraft:pink_terracotta
setblock 344 156 502 minecraft:pink_terracotta
setblock 345 156 465 minecraft:red_nether_bricks
setblock 346 156 464 minecraft:red_nether_bricks
setblock 346 156 504 minecraft:red_nether_bricks
fill 347 156 464 347 159 464 minecraft:pink_terracotta
setblock 347 156 503 minecraft:red_nether_bricks
fill 347 156 504 347 159 504 minecraft:pink_terracotta
fill 354 156 504 354 157 504 minecraft:white_concrete
fill 358 156 464 358 158 464 minecraft:pink_terracotta
setblock 360 156 465 minecraft:red_nether_bricks
setblock 361 156 464 minecraft:red_nether_bricks
fill 361 156 465 361 159 465 minecraft:pink_terracotta
setblock 361 156 504 minecraft:red_nether_bricks
fill 362 156 464 362 159 464 minecraft:pink_terracotta
fill 362 156 504 362 159 504 minecraft:pink_terracotta
setblock 363 156 466 minecraft:pink_terracotta
setblock 364 156 466 minecraft:red_nether_bricks
setblock 365 156 465 minecraft:red_nether_bricks
fill 365 156 466 365 159 466 minecraft:pink_terracotta
setblock 366 156 464 minecraft:red_nether_bricks
fill 366 156 465 366 159 465 minecraft:pink_terracotta
setblock 366 156 504 minecraft:red_nether_bricks
fill 367 156 464 367 159 464 minecraft:pink_terracotta
fill 367 156 504 367 159 504 minecraft:pink_terracotta
setblock 369 156 466 minecraft:red_nether_bricks
fill 369 156 467 369 159 467 minecraft:pink_terracotta
setblock 370 156 465 minecraft:red_nether_bricks
fill 370 156 466 370 159 466 minecraft:pink_terracotta
setblock 370 156 470 minecraft:red_nether_bricks
fill 370 156 471 370 159 471 minecraft:pink_terracotta
setblock 370 156 480 minecraft:red_nether_bricks
setblock 370 156 481 minecraft:pink_terracotta
setblock 370 156 485 minecraft:red_nether_bricks
fill 370 156 486 370 159 486 minecraft:pink_terracotta
setblock 330 157 464 minecraft:red_nether_bricks
fill 330 157 465 330 160 465 minecraft:pink_terracotta
setblock 330 157 484 minecraft:white_concrete
fill 330 157 490 330 158 490 minecraft:white_concrete
fill 330 157 502 330 157 503 minecraft:pink_terracotta
setblock 330 157 504 minecraft:red_nether_bricks
fill 331 157 464 334 157 464 minecraft:pink_terracotta
fill 331 157 504 331 160 504 minecraft:pink_terracotta
setblock 335 157 464 minecraft:red_nether_bricks
setblock 335 157 504 minecraft:red_nether_bricks
fill 336 157 464 336 160 464 minecraft:pink_terracotta
fill 336 157 504 336 160 504 minecraft:pink_terracotta
fill 337 157 503 337 160 503 minecraft:pink_terracotta
setblock 339 157 465 minecraft:red_nether_bricks
setblock 340 157 464 minecraft:red_nether_bricks
fill 340 157 465 340 160 465 minecraft:pink_terracotta
setblock 340 157 504 minecraft:red_nether_bricks
fill 341 157 464 341 160 464 minecraft:pink_terracotta
setblock 341 157 503 minecraft:red_nether_bricks
fill 341 157 504 341 160 504 minecraft:pink_terracotta
setblock 342 157 502 minecraft:red_nether_bricks
fill 342 157 503 342 160 503 minecraft:pink_terracotta
setblock 343 157 502 minecraft:pink_terracotta
setblock 344 157 464 minecraft:pink_terracotta
setblock 344 157 465 minecraft:red_nether_bricks
setblock 345 157 464 minecraft:red_nether_bricks
fill 345 157 465 345 160 465 minecraft:pink_terracotta
setblock 345 157 504 minecraft:red_nether_bricks
fill 346 157 464 346 160 464 minecraft:pink_terracotta
setblock 346 157 503 minecraft:red_nether_bricks
fill 346 157 504 346 160 504 minecraft:pink_terracotta
setblock 347 157 503 minecraft:pink_terracotta
fill 357 157 464 357 159 464 minecraft:pink_terracotta
setblock 359 157 465 minecraft:red_nether_bricks
setblock 360 157 464 minecraft:red_nether_bricks
fill 360 157 465 360 160 465 minecraft:pink_terracotta
setblock 360 157 504 minecraft:red_nether_bricks
fill 361 157 464 361 160 464 minecraft:pink_terracotta
fill 361 157 466 362 157 466 minecraft:pink_terracotta
fill 361 157 504 361 160 504 minecraft:pink_terracotta
setblock 363 157 466 minecraft:red_nether_bricks
setblock 364 157 465 minecraft:red_nether_bricks
fill 364 157 466 364 160 466 minecraft:pink_terracotta
setblock 365 157 464 minecraft:red_nether_bricks
fill 365 157 465 365 160 465 minecraft:pink_terracotta
setblock 365 157 504 minecraft:red_nether_bricks
fill 366 157 464 366 160 464 minecraft:pink_terracotta
fill 366 157 504 366 160 504 minecraft:pink_terracotta
setblock 368 157 466 minecraft:red_nether_bricks
fill 368 157 467 368 160 467 minecraft:pink_terracotta
setblock 369 157 465 minecraft:red_nether_bricks
fill 369 157 466 369 160 466 minecraft:pink_terracotta
setblock 370 157 464 minecraft:red_nether_bricks
fill 370 157 465 370 160 465 minecraft:pink_terracotta
setblock 370 157 469 minecraft:red_nether_bricks
fill 370 157 470 370 160 470 minecraft:pink_terracotta
setblock 370 157 478 minecraft:white_concrete
setblock 370 157 484 minecraft:red_nether_bricks
fill 370 157 485 370 158 485 minecraft:pink_terracotta
setblock 370 157 504 minecraft:red_nether_bricks
fill 330 158 464 333 158 464 minecraft:pink_terracotta
setblock 330 158 468 minecraft:red_nether_bricks
fill 330 158 469 330 161 469 minecraft:pink_terracotta
setblock 330 158 471 minecraft:white_concrete
setblock 330 158 496 minecraft:white_concrete
setblock 330 158 502 minecraft:pink_terracotta
setblock 330 158 503 minecraft:red_nether_bricks
fill 330 158 504 330 161 504 minecraft:pink_terracotta
setblock 334 158 464 minecraft:red_nether_bricks
setblock 334 158 504 minecraft:red_nether_bricks
fill 335 158 464 335 161 464 minecraft:pink_terracotta
fill 335 158 504 335 161 504 minecraft:pink_terracotta
fill 336 158 503 336 161 503 minecraft:pink_terracotta
setblock 338 158 465 minecraft:red_nether_bricks
setblock 339 158 464 minecraft:red_nether_bricks
fill 339 158 465 339 161 465 minecraft:pink_terracotta
setblock 339 158 504 minecraft:red_nether_bricks
fill 340 158 464 340 161 464 minecraft:pink_terracotta
setblock 340 158 503 minecraft:red_nether_bricks
fill 340 158 504 340 161 504 minecraft:pink_terracotta
fill 341 158 503 341 161 503 minecraft:pink_terracotta
setblock 342 158 465 minecraft:pink_terracotta
setblock 343 158 465 minecraft:red_nether_bricks
setblock 344 158 464 minecraft:red_nether_bricks
fill 344 158 465 344 161 465 minecraft:pink_terracotta
setblock 344 158 504 minecraft:red_nether_bricks
fill 345 158 464 345 161 464 minecraft:pink_terracotta
setblock 345 158 503 minecraft:red_nether_bricks
fill 345 158 504 345 161 504 minecraft:pink_terracotta
fill 346 158 465 346 159 465 minecraft:pink_terracotta
setblock 346 158 503 minecraft:pink_terracotta
setblock 349 158 464 minecraft:red_nether_bricks
fill 356 158 464 356 160 464 minecraft:pink_terracotta
setblock 358 158 465 minecraft:red_nether_bricks
setblock 359 158 464 minecraft:red_nether_bricks
fill 359 158 465 359 161 465 minecraft:pink_terracotta
setblock 359 158 504 minecraft:red_nether_bricks
fill 360 158 464 360 161 464 minecraft:pink_terracotta
fill 360 158 466 361 158 466 minecraft:pink_terracotta
fill 360 158 504 360 161 504 minecraft:pink_terracotta
setblock 362 158 466 minecraft:red_nether_bricks
setblock 363 158 465 minecraft:red_nether_bricks
fill 363 158 466 363 160 467 minecraft:pink_terracotta
setblock 364 158 464 minecraft:red_nether_bricks
fill 364 158 465 364 161 465 minecraft:pink_terracotta
fill 364 158 467 365 158 467 minecraft:pink_terracotta
setblock 364 158 504 minecraft:red_nether_bricks
fill 365 158 464 365 161 464 minecraft:pink_terracotta
fill 365 158 504 365 161 504 minecraft:pink_terracotta
setblock 367 158 466 minecraft:red_nether_bricks
setblock 368 158 465 minecraft:red_nether_bricks
fill 368 158 466 368 161 466 minecraft:pink_terracotta
fill 368 158 468 368 159 468 minecraft:pink_terracotta
setblock 369 158 464 minecraft:red_nether_bricks
fill 369 158 465 369 161 465 minecraft:pink_terracotta
setblock 369 158 469 minecraft:red_nether_bricks
fill 369 158 470 369 161 470 minecraft:pink_terracotta
setblock 369 158 504 minecraft:red_nether_bricks
fill 370 158 464 370 161 464 minecraft:pink_terracotta
setblock 370 158 468 minecraft:red_nether_bricks
fill 370 158 469 370 161 469 minecraft:pink_terracotta
setblock 370 158 472 minecraft:pink_terracotta
setblock 370 158 484 minecraft:pink_terracotta
setblock 370 158 497 minecraft:white_concrete
setblock 370 158 503 minecraft:red_nether_bricks
fill 370 158 504 370 161 504 minecraft:pink_terracotta
fill 330 159 464 332 159 464 minecraft:pink_terracotta
setblock 330 159 467 minecraft:red_nether_bricks
fill 330 159 468 330 162 468 minecraft:pink_terracotta
setblock 330 159 477 minecraft:white_concrete
fill 330 159 488 330 162 488 minecraft:pink_terracotta
setblock 330 159 502 minecraft:red_nether_bricks
fill 330 159 503 330 162 503 minecraft:pink_terracotta
setblock 331 159 466 minecraft:red_nether_bricks
setblock 332 159 465 minecraft:red_nether_bricks
setblock 333 159 464 minecraft:red_nether_bricks
setblock 333 159 504 minecraft:red_nether_bricks
fill 334 159 464 334 162 464 minecraft:pink_terracotta
fill 334 159 504 334 162 504 minecraft:pink_terracotta
setblock 336 159 465 minecraft:pink_terracotta
setblock 337 159 465 minecraft:red_nether_bricks
setblock 338 159 464 minecraft:red_nether_bricks
fill 338 159 465 338 162 465 minecraft:pink_terracotta
setblock 338 159 504 minecraft:red_nether_bricks
fill 339 159 464 339 162 464 minecraft:pink_terracotta
setblock 339 159 503 minecraft:red_nether_bricks
fill 339 159 504 339 162 504 minecraft:pink_terracotta
fill 340 159 503 340 162 503 minecraft:pink_terracotta
setblock 342 159 465 minecraft:red_nether_bricks
setblock 343 159 464 minecraft:red_nether_bricks
fill 343 159 465 343 162 465 minecraft:pink_terracotta
setblock 343 159 504 minecraft:red_nether_bricks
fill 344 159 464 344 162 464 minecraft:pink_terracotta
setblock 344 159 503 minecraft:red_nether_bricks
fill 344 159 504 344 162 504 minecraft:pink_terracotta
fill 345 159 503 345 160 503 minecraft:pink_terracotta
setblock 348 159 464 minecraft:red_nether_bricks
setblock 348 159 504 minecraft:red_nether_bricks
fill 349 159 464 349 160 464 minecraft:pink_terracotta
setblock 353 159 464 minecraft:white_concrete
fill 355 159 464 355 161 464 minecraft:pink_terracotta
setblock 357 159 465 minecraft:red_nether_bricks
setblock 358 159 464 minecraft:red_nether_bricks
fill 358 159 465 358 162 465 minecraft:pink_terracotta
setblock 358 159 504 minecraft:red_nether_bricks
fill 359 159 464 359 162 464 minecraft:pink_terracotta
fill 359 159 466 360 159 466 minecraft:pink_terracotta
fill 359 159 504 359 162 504 minecraft:pink_terracotta
setblock 361 159 466 minecraft:red_nether_bricks
fill 361 159 467 362 161 467 minecraft:pink_terracotta
setblock 362 159 465 minecraft:red_nether_bricks
fill 362 159 466 362 162 466 minecraft:pink_terracotta
setblock 363 159 464 minecraft:red_nether_bricks
fill 363 159 465 363 162 465 minecraft:pink_terracotta
setblock 363 159 504 minecraft:red_nether_bricks
fill 364 159 464 364 162 464 minecraft:pink_terracotta
setblock 364 159 467 minecraft:pink_terracotta
fill 364 159 504 364 162 504 minecraft:pink_terracotta
setblock 365 159 467 minecraft:red_nether_bricks
setblock 366 159 466 minecraft:red_nether_bricks
fill 366 159 467 366 162 467 minecraft:pink_terracotta
setblock 367 159 465 minecraft:red_nether_bricks
fill 367 159 466 367 162 466 minecraft:pink_terracotta
setblock 368 159 464 minecraft:red_nether_bricks
fill 368 159 465 368 162 465 minecraft:pink_terracotta
setblock 368 159 469 minecraft:red_nether_bricks
setblock 368 159 504 minecraft:red_nether_bricks
fill 369 159 464 369 162 464 minecraft:pink_terracotta
setblock 369 159 468 minecraft:red_nether_bricks
fill 369 159 469 369 162 469 minecraft:pink_terracotta
fill 369 159 504 369 162 504 minecraft:pink_terracotta
setblock 370 159 467 minecraft:red_nether_bricks
fill 370 159 468 370 162 468 minecraft:pink_terracotta
setblock 370 159 472 minecraft:red_nether_bricks
setblock 370 159 491 minecraft:white_concrete
fill 330 160 464 331 160 464 minecraft:pink_terracotta
setblock 330 160 466 minecraft:red_nether_bricks
fill 330 160 467 330 163 467 minecraft:pink_terracotta
setblock 330 160 470 minecraft:pink_terracotta
setblock 330 160 483 minecraft:white_concrete
fill 330 160 487 330 163 487 minecraft:pink_terracotta
fill 330 160 489 330 160 490 minecraft:pink_terracotta
setblock 330 160 491 minecraft:red_nether_bricks
fill 330 160 492 330 163 492 minecraft:pink_terracotta
setblock 330 160 501 minecraft:red_nether_bricks
fill 330 160 502 330 163 502 minecraft:pink_terracotta
setblock 331 160 465 minecraft:red_nether_bricks
fill 331 160 466 331 163 466 minecraft:pink_terracotta
setblock 332 160 464 minecraft:red_nether_bricks
fill 332 160 465 335 160 465 minecraft:pink_terracotta
setblock 332 160 504 minecraft:red_nether_bricks
fill 333 160 464 333 163 464 minecraft:pink_terracotta
fill 333 160 504 333 163 504 minecraft:pink_terracotta
fill 335 160 503 335 162 503 minecraft:pink_terracotta
setblock 336 160 465 minecraft:red_nether_bricks
setblock 337 160 464 minecraft:red_nether_bricks
fill 337 160 465 337 163 465 minecraft:pink_terracotta
setblock 337 160 504 minecraft:red_nether_bricks
fill 338 160 464 338 163 464 minecraft:pink_terracotta
setblock 338 160 503 minecraft:red_nether_bricks
fill 338 160 504 338 163 504 minecraft:pink_terracotta
fill 339 160 503 339 163 503 minecraft:pink_terracotta
setblock 340 160 466 minecraft:red_nether_bricks
setblock 341 160 465 minecraft:red_nether_bricks
fill 341 160 466 342 162 466 minecraft:pink_terracotta
setblock 342 160 464 minecraft:red_nether_bricks
fill 342 160 465 342 163 465 minecraft:pink_terracotta
setblock 342 160 504 minecraft:red_nether_bricks
fill 343 160 464 343 163 464 minecraft:pink_terracotta
setblock 343 160 503 minecraft:red_nether_bricks
fill 343 160 504 343 163 504 minecraft:pink_terracotta
fill 344 160 503 344 161 503 minecraft:pink_terracotta
setblock 346 160 465 minecraft:red_nether_bricks
setblock 347 160 464 minecraft:red_nether_bricks
setblock 347 160 504 minecraft:red_nether_bricks
fill 348 160 464 348 161 464 minecraft:pink_terracotta
setblock 353 160 504 minecraft:white_concrete
fill 354 160 464 354 162 464 minecraft:pink_terracotta
setblock 356 160 465 minecraft:red_nether_bricks
setblock 357 160 464 minecraft:red_nether_bricks
fill 357 160 465 357 163 465 minecraft:pink_terracotta
fill 358 160 464 358 163 464 minecraft:pink_terracotta
fill 358 160 466 359 160 466 minecraft:pink_terracotta
fill 358 160 504 358 163 504 minecraft:pink_terracotta
setblock 360 160 466 minecraft:red_nether_bricks
fill 360 160 467 360 163 467 minecraft:pink_terracotta
setblock 361 160 465 minecraft:red_nether_bricks
fill 361 160 466 361 163 466 minecraft:pink_terracotta
setblock 362 160 464 minecraft:red_nether_bricks
fill 362 160 465 362 163 465 minecraft:pink_terracotta
setblock 362 160 504 minecraft:red_nether_bricks
fill 363 160 464 363 163 464 minecraft:pink_terracotta
fill 363 160 504 363 163 504 minecraft:pink_terracotta
setblock 364 160 467 minecraft:red_nether_bricks
setblock 365 160 466 minecraft:red_nether_bricks
fill 365 160 467 365 163 467 minecraft:pink_terracotta
setblock 366 160 465 minecraft:red_nether_bricks
fill 366 160 466 366 163 466 minecraft:pink_terracotta
setblock 367 160 464 minecraft:red_nether_bricks
fill 367 160 465 367 163 465 minecraft:pink_terracotta
setblock 367 160 504 minecraft:red_nether_bricks
fill 368 160 464 368 163 464 minecraft:pink_terracotta
setblock 368 160 468 minecraft:red_nether_bricks
fill 368 160 469 368 163 469 minecraft:pink_terracotta
fill 368 160 504 368 163 504 minecraft:pink_terracotta
setblock 369 160 467 minecraft:red_nether_bricks
fill 369 160 468 369 163 468 minecraft:pink_terracotta
setblock 369 160 471 minecraft:pink_terracotta
setblock 370 160 466 minecraft:red_nether_bricks
fill 370 160 467 370 163 467 minecraft:pink_terracotta
setblock 370 160 471 minecraft:red_nether_bricks
fill 370 160 472 370 162 473 minecraft:pink_terracotta
setblock 370 160 485 minecraft:white_concrete
fill 370 160 487 370 161 487 minecraft:pink_terracotta
setblock 330 161 464 minecraft:pink_terracotta
setblock 330 161 465 minecraft:red_nether_bricks
fill 330 161 466 330 164 466 minecraft:pink_terracotta
setblock 330 161 470 minecraft:red_nether_bricks
fill 330 161 486 330 162 486 minecraft:pink_terracotta
setblock 330 161 489 minecraft:pink_terracotta
setblock 330 161 490 minecraft:red_nether_bricks
fill 330 161 491 330 164 491 minecraft:pink_terracotta
fill 330 161 493 330 161 494 minecraft:pink_terracotta
fill 330 161 501 330 163 501 minecraft:pink_terracotta
setblock 331 161 464 minecraft:red_nether_bricks
fill 331 161 465 334 161 465 minecraft:pink_terracotta
fill 331 161 467 331 162 467 minecraft:pink_terracotta
setblock 331 161 504 minecraft:red_nether_bricks
fill 332 161 464 332 164 464 minecraft:pink_terracotta
setblock 332 161 466 minecraft:light[level=12]
setblock 332 161 474 minecraft:light[level=12]
setblock 332 161 482 minecraft:light[level=12]
setblock 332 161 490 minecraft:light[level=12]
setblock 332 161 498 minecraft:light[level=12]
fill 332 161 504 332 164 504 minecraft:pink_terracotta
setblock 335 161 465 minecraft:red_nether_bricks
setblock 336 161 464 minecraft:red_nether_bricks
fill 336 161 465 336 164 465 minecraft:pink_terracotta
setblock 336 161 504 minecraft:red_nether_bricks
fill 337 161 464 337 164 464 minecraft:pink_terracotta
setblock 337 161 503 minecraft:red_nether_bricks
fill 337 161 504 337 164 504 minecraft:pink_terracotta
fill 338 161 503 338 164 503 minecraft:pink_terracotta
setblock 339 161 466 minecraft:red_nether_bricks
setblock 340 161 465 minecraft:red_nether_bricks
fill 340 161 466 340 163 466 minecraft:pink_terracotta
setblock 340 161 474 minecraft:light[level=12]
setblock 340 161 482 minecraft:light[level=12]
setblock 340 161 490 minecraft:light[level=12]
setblock 340 161 498 minecraft:light[level=12]
setblock 341 161 464 minecraft:red_nether_bricks
fill 341 161 465 341 164 465 minecraft:pink_terracotta
setblock 341 161 504 minecraft:red_nether_bricks
fill 342 161 464 342 164 464 minecraft:pink_terracotta
setblock 342 161 503 minecraft:red_nether_bricks
fill 342 161 504 342 164 504 minecraft:pink_terracotta
fill 343 161 503 343 162 503 minecraft:pink_terracotta
setblock 345 161 465 minecraft:red_nether_bricks
setblock 346 161 464 minecraft:red_nether_bricks
setblock 346 161 465 minecraft:pink_terracotta
setblock 346 161 504 minecraft:red_nether_bricks
fill 347 161 464 347 162 464 minecraft:pink_terracotta
setblock 347 161 504 minecraft:pink_terracotta
setblock 348 161 466 minecraft:light[level=12]
setblock 348 161 474 minecraft:light[level=12]
setblock 348 161 482 minecraft:light[level=12]
setblock 348 161 490 minecraft:light[level=12]
setblock 348 161 498 minecraft:light[level=12]
fill 353 161 464 353 163 464 minecraft:pink_terracotta
setblock 355 161 465 minecraft:red_nether_bricks
setblock 356 161 464 minecraft:red_nether_bricks
fill 356 161 465 356 164 465 minecraft:pink_terracotta
setblock 356 161 466 minecraft:light[level=12]
setblock 356 161 474 minecraft:light[level=12]
setblock 356 161 482 minecraft:light[level=12]
setblock 356 161 490 minecraft:light[level=12]
setblock 356 161 498 minecraft:light[level=12]
fill 357 161 464 357 164 464 minecraft:pink_terracotta
fill 357 161 466 358 161 466 minecraft:pink_terracotta
fill 357 161 504 357 164 504 minecraft:pink_terracotta
setblock 358 161 467 minecraft:red_nether_bricks
setblock 359 161 466 minecraft:red_nether_bricks
fill 359 161 467 359 164 467 minecraft:pink_terracotta
setblock 360 161 465 minecraft:red_nether_bricks
fill 360 161 466 360 164 466 minecraft:pink_terracotta
setblock 361 161 464 minecraft:red_nether_bricks
fill 361 161 465 361 164 465 minecraft:pink_terracotta
setblock 361 161 504 minecraft:red_nether_bricks
fill 362 161 464 362 164 464 minecraft:pink_terracotta
setblock 362 161 468 minecraft:red_nether_bricks
fill 362 161 504 362 164 504 minecraft:pink_terracotta
setblock 363 161 466 minecraft:pink_terracotta
setblock 363 161 467 minecraft:red_nether_bricks
setblock 364 161 466 minecraft:red_nether_bricks
fill 364 161 467 364 164 467 minecraft:pink_terracotta
setblock 364 161 474 minecraft:light[level=12]
setblock 364 161 482 minecraft:light[level=12]
setblock 364 161 490 minecraft:light[level=12]
setblock 364 161 498 minecraft:light[level=12]
setblock 365 161 465 minecraft:red_nether_bricks
fill 365 161 466 365 164 466 minecraft:pink_terracotta
setblock 366 161 464 minecraft:red_nether_bricks
fill 366 161 465 366 164 465 minecraft:pink_terracotta
setblock 366 161 504 minecraft:red_nether_bricks
fill 367 161 464 367 164 464 minecraft:pink_terracotta
setblock 367 161 467 minecraft:pink_terracotta
fill 367 161 504 367 163 504 minecraft:pink_terracotta
setblock 368 161 467 minecraft:red_nether_bricks
fill 368 161 468 368 164 468 minecraft:pink_terracotta
fill 368 161 470 368 162 470 minecraft:pink_terracotta
setblock 369 161 466 minecraft:red_nether_bricks
fill 369 161 467 369 164 467 minecraft:pink_terracotta
setblock 369 161 471 minecraft:red_nether_bricks
fill 369 161 472 369 164 472 minecraft:pink_terracotta
setblock 370 161 465 minecraft:red_nether_bricks
fill 370 161 466 370 164 466 minecraft:pink_terracotta
setblock 370 161 470 minecraft:red_nether_bricks
fill 370 161 471 370 164 471 minecraft:pink_terracotta
setblock 370 161 479 minecraft:white_concrete
fill 370 161 488 370 161 489 minecraft:pink_terracotta
setblock 370 161 498 minecraft:white_concrete
setblock 330 162 464 minecraft:red_nether_bricks
fill 330 162 465 333 162 465 minecraft:pink_terracotta
setblock 330 162 469 minecraft:red_nether_bricks
fill 330 162 470 330 164 471 minecraft:pink_terracotta
setblock 330 162 476 minecraft:white_concrete
setblock 330 162 489 minecraft:red_nether_bricks
fill 330 162 490 330 165 490 minecraft:pink_terracotta
setblock 330 162 493 minecraft:pink_terracotta
setblock 330 162 494 minecraft:red_nether_bricks
fill 330 162 495 330 164 496 minecraft:pink_terracotta
setblock 330 162 504 minecraft:red_nether_bricks
fill 331 162 464 331 165 464 minecraft:pink_terracotta
fill 331 162 504 331 165 504 minecraft:pink_terracotta
setblock 334 162 465 minecraft:red_nether_bricks
setblock 335 162 464 minecraft:red_nether_bricks
fill 335 162 465 335 164 465 minecraft:pink_terracotta
setblock 335 162 504 minecraft:red_nether_bricks
fill 336 162 464 336 165 464 minecraft:pink_terracotta
setblock 336 162 503 minecraft:red_nether_bricks
fill 336 162 504 336 165 504 minecraft:pink_terracotta
fill 337 162 503 337 165 503 minecraft:pink_terracotta
setblock 338 162 466 minecraft:red_nether_bricks
setblock 339 162 465 minecraft:red_nether_bricks
fill 339 162 466 339 163 466 minecraft:pink_terracotta
fill 339 162 467 339 163 467 minecraft:red_concrete
setblock 340 162 464 minecraft:red_nether_bricks
fill 340 162 465 340 165 465 minecraft:pink_terracotta
setblock 340 162 504 minecraft:red_nether_bricks
fill 341 162 464 341 165 464 minecraft:pink_terracotta
setblock 341 162 503 minecraft:red_nether_bricks
fill 341 162 504 341 165 504 minecraft:pink_terracotta
fill 342 162 503 342 163 503 minecraft:pink_terracotta
setblock 344 162 465 minecraft:red_nether_bricks
setblock 345 162 464 minecraft:red_nether_bricks
setblock 345 162 465 minecraft:pink_terracotta
setblock 345 162 504 minecraft:red_nether_bricks
fill 346 162 464 346 163 464 minecraft:pink_terracotta
setblock 346 162 504 minecraft:pink_terracotta
setblock 354 162 465 minecraft:red_nether_bricks
setblock 355 162 464 minecraft:red_nether_bricks
fill 355 162 465 355 165 465 minecraft:pink_terracotta
fill 356 162 464 356 165 464 minecraft:pink_terracotta
fill 356 162 466 357 162 466 minecraft:pink_terracotta
setblock 358 162 466 minecraft:red_nether_bricks
fill 358 162 467 358 165 467 minecraft:pink_terracotta
setblock 359 162 465 minecraft:red_nether_bricks
fill 359 162 466 359 165 466 minecraft:pink_terracotta
setblock 360 162 464 minecraft:red_nether_bricks
fill 360 162 465 360 165 465 minecraft:pink_terracotta
setblock 360 162 468 minecraft:pink_terracotta
setblock 360 162 504 minecraft:red_nether_bricks
fill 361 162 464 361 165 464 minecraft:pink_terracotta
setblock 361 162 467 minecraft:pink_terracotta
setblock 361 162 468 minecraft:red_nether_bricks
fill 361 162 504 361 165 504 minecraft:pink_terracotta
setblock 362 162 467 minecraft:red_nether_bricks
fill 362 162 468 363 163 468 minecraft:pink_terracotta
setblock 363 162 466 minecraft:red_nether_bricks
fill 363 162 467 363 165 467 minecraft:pink_terracotta
setblock 364 162 465 minecraft:red_nether_bricks
fill 364 162 466 364 165 466 minecraft:pink_terracotta
setblock 365 162 464 minecraft:red_nether_bricks
fill 365 162 465 365 165 465 minecraft:pink_terracotta
setblock 365 162 504 minecraft:red_nether_bricks
fill 366 162 464 366 165 464 minecraft:pink_terracotta
fill 366 162 504 366 164 504 minecraft:pink_terracotta
setblock 368 162 466 minecraft:red_nether_bricks
fill 368 162 467 368 164 467 minecraft:pink_terracotta
setblock 369 162 465 minecraft:red_nether_bricks
fill 369 162 466 369 165 466 minecraft:pink_terracotta
setblock 369 162 470 minecraft:red_nether_bricks
fill 369 162 471 369 165 471 minecraft:pink_terracotta
setblock 370 162 464 minecraft:red_nether_bricks
fill 370 162 465 370 165 465 minecraft:pink_terracotta
setblock 370 162 469 minecraft:red_nether_bricks
fill 370 162 470 370 165 470 minecraft:pink_terracotta
setblock 370 162 488 minecraft:pink_terracotta
setblock 370 162 489 minecraft:red_nether_bricks
fill 370 162 490 370 164 490 minecraft:pink_terracotta
setblock 370 162 492 minecraft:white_concrete
setblock 370 162 504 minecraft:red_nether_bricks
fill 330 163 464 330 165 465 minecraft:pink_terracotta
setblock 330 163 468 minecraft:red_nether_bricks
fill 330 163 469 330 166 469 minecraft:pink_terracotta
setblock 330 163 482 minecraft:white_concrete
setblock 330 163 488 minecraft:red_nether_bricks
fill 330 163 489 331 164 489 minecraft:pink_terracotta
setblock 330 163 493 minecraft:red_nether_bricks
fill 330 163 494 330 166 494 minecraft:pink_terracotta
setblock 330 163 497 minecraft:pink_terracotta
setblock 330 163 498 minecraft:red_nether_bricks
setblock 330 163 503 minecraft:red_nether_bricks
fill 330 163 504 330 164 504 minecraft:pink_terracotta
fill 331 163 490 331 163 491 minecraft:pink_terracotta
setblock 331 163 492 minecraft:red_nether_bricks
fill 331 163 493 331 166 493 minecraft:pink_terracotta
setblock 333 163 465 minecraft:red_nether_bricks
setblock 334 163 464 minecraft:red_nether_bricks
fill 334 163 465 334 164 465 minecraft:pink_terracotta
setblock 334 163 504 minecraft:red_nether_bricks
fill 335 163 464 335 166 464 minecraft:pink_terracotta
setblock 335 163 503 minecraft:red_nether_bricks
fill 335 163 504 335 166 504 minecraft:pink_terracotta
fill 336 163 503 336 165 503 minecraft:pink_terracotta
setblock 338 163 465 minecraft:red_nether_bricks
setblock 338 163 466 minecraft:pink_terracotta
setblock 339 163 464 minecraft:red_nether_bricks
fill 339 163 465 339 165 465 minecraft:pink_terracotta
setblock 339 163 504 minecraft:red_nether_bricks
fill 340 163 464 340 166 464 minecraft:pink_terracotta
setblock 340 163 503 minecraft:red_nether_bricks
fill 340 163 504 340 166 504 minecraft:pink_terracotta
setblock 341 163 466 minecraft:pink_terracotta
fill 341 163 503 341 164 503 minecraft:pink_terracotta
setblock 343 163 465 minecraft:red_nether_bricks
setblock 344 163 464 minecraft:red_nether_bricks
setblock 344 163 465 minecraft:pink_terracotta
setblock 344 163 504 minecraft:red_nether_bricks
fill 345 163 464 345 164 464 minecraft:pink_terracotta
setblock 345 163 504 minecraft:pink_terracotta
setblock 348 163 464 minecraft:white_concrete
setblock 352 163 504 minecraft:white_concrete
setblock 354 163 464 minecraft:red_nether_bricks
fill 354 163 465 354 164 465 minecraft:pink_terracotta
fill 355 163 464 355 166 464 minecraft:pink_terracotta
setblock 356 163 466 minecraft:pink_terracotta
setblock 357 163 466 minecraft:red_nether_bricks
fill 357 163 467 357 165 467 minecraft:pink_terracotta
setblock 358 163 465 minecraft:red_nether_bricks
fill 358 163 466 358 166 466 minecraft:pink_terracotta
fill 358 163 478 358 164 479 minecraft:pink_concrete
setblock 359 163 464 minecraft:red_nether_bricks
fill 359 163 465 359 166 465 minecraft:pink_terracotta
setblock 359 163 468 minecraft:pink_terracotta
setblock 359 163 504 minecraft:red_nether_bricks
fill 360 163 464 360 166 464 minecraft:pink_terracotta
setblock 360 163 468 minecraft:red_nether_bricks
fill 360 163 504 360 166 504 minecraft:pink_terracotta
setblock 361 163 467 minecraft:red_nether_bricks
fill 361 163 468 361 164 468 minecraft:pink_terracotta
setblock 362 163 466 minecraft:red_nether_bricks
fill 362 163 467 362 165 467 minecraft:pink_terracotta
setblock 363 163 465 minecraft:red_nether_bricks
fill 363 163 466 363 166 466 minecraft:pink_terracotta
setblock 364 163 464 minecraft:red_nether_bricks
fill 364 163 465 364 166 465 minecraft:pink_terracotta
setblock 364 163 504 minecraft:red_nether_bricks
fill 365 163 464 365 166 464 minecraft:pink_terracotta
fill 365 163 504 365 164 504 minecraft:pink_terracotta
setblock 366 163 467 minecraft:red_nether_bricks
setblock 367 163 466 minecraft:red_nether_bricks
setblock 368 163 465 minecraft:red_nether_bricks
setblock 368 163 466 minecraft:pink_terracotta
setblock 368 163 470 minecraft:red_nether_bricks
setblock 369 163 464 minecraft:red_nether_bricks
fill 369 163 465 369 165 465 minecraft:pink_terracotta
setblock 369 163 469 minecraft:red_nether_bricks
fill 369 163 470 369 166 470 minecraft:pink_terracotta
fill 369 163 475 369 168 475 minecraft:white_concrete
setblock 369 163 504 minecraft:red_nether_bricks
fill 370 163 464 370 166 464 minecraft:pink_terracotta
setblock 370 163 468 minecraft:red_nether_bricks
fill 370 163 469 370 166 469 minecraft:pink_terracotta
setblock 370 163 472 minecraft:pink_terracotta
setblock 370 163 473 minecraft:red_nether_bricks
fill 370 163 474 370 166 474 minecraft:pink_terracotta
setblock 370 163 486 minecraft:white_concrete
setblock 370 163 489 minecraft:pink_terracotta
fill 370 163 491 370 163 492 minecraft:pink_terracotta
setblock 370 163 504 minecraft:pink_terracotta
setblock 330 164 467 minecraft:red_nether_bricks
fill 330 164 468 330 166 468 minecraft:pink_terracotta
setblock 330 164 487 minecraft:red_nether_bricks
fill 330 164 488 330 166 488 minecraft:pink_terracotta
setblock 330 164 492 minecraft:red_nether_bricks
fill 330 164 493 330 167 493 minecraft:pink_terracotta
setblock 330 164 497 minecraft:red_nether_bricks
fill 330 164 498 330 166 499 minecraft:pink_terracotta
setblock 330 164 503 minecraft:pink_terracotta
setblock 331 164 490 minecraft:pink_terracotta
setblock 331 164 491 minecraft:red_nether_bricks
fill 331 164 492 331 167 492 minecraft:pink_terracotta
fill 331 164 494 331 164 495 minecraft:pink_terracotta
setblock 333 164 464 minecraft:red_nether_bricks
setblock 333 164 504 minecraft:red_nether_bricks
fill 334 164 464 334 166 464 minecraft:pink_terracotta
fill 334 164 504 334 167 504 minecraft:pink_terracotta
setblock 335 164 503 minecraft:pink_terracotta
setblock 337 164 465 minecraft:red_nether_bricks
setblock 338 164 464 minecraft:red_nether_bricks
fill 338 164 465 338 165 465 minecraft:pink_terracotta
setblock 338 164 504 minecraft:red_nether_bricks
fill 339 164 464 339 166 464 minecraft:pink_terracotta
setblock 339 164 466 minecraft:white_concrete
fill 339 164 467 339 176 467 minecraft:red_nether_bricks
setblock 339 164 503 minecraft:red_nether_bricks
fill 339 164 504 339 167 504 minecraft:pink_terracotta
setblock 340 164 503 minecraft:pink_terracotta
setblock 342 164 465 minecraft:red_nether_bricks
setblock 343 164 464 minecraft:red_nether_bricks
setblock 343 164 504 minecraft:red_nether_bricks
setblock 344 164 464 minecraft:pink_terracotta
setblock 344 164 504 minecraft:pink_terracotta
setblock 353 164 464 minecraft:red_nether_bricks
fill 354 164 464 354 167 464 minecraft:pink_terracotta
setblock 356 164 466 minecraft:red_nether_bricks
setblock 357 164 465 minecraft:red_nether_bricks
fill 357 164 466 357 167 466 minecraft:pink_terracotta
setblock 358 164 464 minecraft:red_nether_bricks
fill 358 164 465 358 167 465 minecraft:pink_terracotta
setblock 358 164 504 minecraft:red_nether_bricks
fill 359 164 464 359 167 464 minecraft:pink_terracotta
setblock 359 164 468 minecraft:red_nether_bricks
fill 359 164 504 359 166 504 minecraft:pink_terracotta
setblock 360 164 467 minecraft:red_nether_bricks
setblock 360 164 468 minecraft:pink_terracotta
setblock 361 164 466 minecraft:red_nether_bricks
fill 361 164 467 361 166 467 minecraft:pink_terracotta
setblock 362 164 465 minecraft:red_nether_bricks
fill 362 164 466 362 167 466 minecraft:pink_terracotta
setblock 362 164 468 minecraft:pink_terracotta
setblock 363 164 464 minecraft:red_nether_bricks
fill 363 164 465 363 167 465 minecraft:pink_terracotta
setblock 363 164 504 minecraft:red_nether_bricks
fill 364 164 464 364 167 464 minecraft:pink_terracotta
fill 364 164 504 364 165 504 minecraft:pink_terracotta
setblock 365 164 467 minecraft:red_nether_bricks
setblock 366 164 466 minecraft:red_nether_bricks
setblock 367 164 465 minecraft:red_nether_bricks
setblock 367 164 466 minecraft:pink_terracotta
fill 367 164 475 368 167 475 minecraft:white_concrete
setblock 368 164 464 minecraft:red_nether_bricks
fill 368 164 465 368 165 465 minecraft:pink_terracotta
setblock 368 164 469 minecraft:red_nether_bricks
setblock 368 164 470 minecraft:pink_terracotta
fill 368 164 474 369 167 474 minecraft:white_concrete
fill 368 164 476 370 167 476 minecraft:white_concrete
fill 369 164 464 369 166 464 minecraft:pink_terracotta
setblock 369 164 468 minecraft:red_nether_bricks
fill 369 164 469 369 166 469 minecraft:pink_terracotta
fill 369 164 473 369 167 473 minecraft:white_concrete
fill 369 164 477 369 167 477 minecraft:white_concrete
setblock 370 164 467 minecraft:red_nether_bricks
fill 370 164 468 370 167 468 minecraft:pink_terracotta
setblock 370 164 472 minecraft:red_nether_bricks
fill 370 164 473 370 167 473 minecraft:pink_terracotta
fill 370 164 475 370 168 475 minecraft:white_concrete
setblock 370 164 480 minecraft:white_concrete
setblock 370 164 491 minecraft:pink_terracotta
setblock 370 164 492 minecraft:red_nether_bricks
fill 370 164 493 370 167 493 minecraft:pink_terracotta
setblock 330 165 466 minecraft:red_nether_bricks
fill 330 165 467 330 166 467 minecraft:pink_terracotta
setblock 330 165 470 minecraft:pink_terracotta
setblock 330 165 471 minecraft:red_nether_bricks
fill 330 165 489 330 166 489 minecraft:pink_terracotta
setblock 330 165 491 minecraft:red_nether_bricks
fill 330 165 492 330 168 492 minecraft:pink_terracotta
setblock 330 165 495 minecraft:pink_terracotta
setblock 330 165 496 minecraft:red_nether_bricks
fill 330 165 497 330 168 497 minecraft:pink_terracotta
setblock 331 165 490 minecraft:red_nether_bricks
fill 331 165 491 331 168 491 minecraft:pink_terracotta
setblock 331 165 494 minecraft:pink_terracotta
setblock 331 165 495 minecraft:red_nether_bricks
fill 331 165 496 331 168 496 minecraft:pink_terracotta
setblock 332 165 464 minecraft:red_nether_bricks
setblock 332 165 504 minecraft:red_nether_bricks
setblock 333 165 464 minecraft:pink_terracotta
fill 333 165 504 333 168 504 minecraft:pink_terracotta
setblock 336 165 465 minecraft:red_nether_bricks
setblock 337 165 464 minecraft:red_nether_bricks
setblock 337 165 465 minecraft:pink_terracotta
setblock 337 165 504 minecraft:red_nether_bricks
fill 338 165 464 338 167 464 minecraft:pink_terracotta
setblock 338 165 503 minecraft:red_nether_bricks
fill 338 165 504 338 168 504 minecraft:pink_terracotta
setblock 339 165 503 minecraft:pink_terracotta
setblock 342 165 464 minecraft:red_nether_bricks
setblock 342 165 504 minecraft:red_nether_bricks
setblock 343 165 464 minecraft:pink_terracotta
setblock 353 165 464 minecraft:pink_terracotta
setblock 356 165 465 minecraft:red_nether_bricks
fill 356 165 466 356 166 466 minecraft:pink_terracotta
setblock 357 165 464 minecraft:red_nether_bricks
fill 357 165 465 357 168 465 minecraft:pink_terracotta
fill 358 165 464 358 168 464 minecraft:pink_terracotta
setblock 358 165 504 minecraft:pink_terracotta
setblock 359 165 467 minecraft:red_nether_bricks
setblock 360 165 466 minecraft:red_nether_bricks
fill 360 165 467 360 166 467 minecraft:pink_terracotta
setblock 361 165 465 minecraft:red_nether_bricks
fill 361 165 466 361 167 466 minecraft:pink_terracotta
setblock 362 165 464 minecraft:red_nether_bricks
fill 362 165 465 362 168 465 minecraft:pink_terracotta
setblock 362 165 504 minecraft:red_nether_bricks
fill 363 165 464 363 168 464 minecraft:pink_terracotta
setblock 363 165 504 minecraft:pink_terracotta
setblock 365 165 466 minecraft:red_nether_bricks
setblock 366 165 465 minecraft:red_nether_bricks
setblock 366 165 466 minecraft:pink_terracotta
setblock 367 165 464 minecraft:red_nether_bricks
setblock 367 165 465 minecraft:pink_terracotta
fill 367 165 474 367 166 474 minecraft:white_concrete
fill 367 165 476 367 166 476 minecraft:white_concrete
fill 368 165 464 368 166 464 minecraft:pink_terracotta
fill 368 165 473 368 166 473 minecraft:white_concrete
fill 368 165 477 368 166 477 minecraft:white_concrete
setblock 369 165 467 minecraft:red_nether_bricks
fill 369 165 468 369 166 468 minecraft:pink_terracotta
setblock 369 165 472 minecraft:red_nether_bricks
setblock 370 165 466 minecraft:red_nether_bricks
fill 370 165 467 370 168 467 minecraft:pink_terracotta
setblock 370 165 471 minecraft:red_nether_bricks
fill 370 165 472 370 168 472 minecraft:pink_terracotta
fill 370 165 477 370 166 477 minecraft:white_concrete
setblock 370 165 491 minecraft:red_nether_bricks
fill 370 165 492 370 166 492 minecraft:pink_terracotta
setblock 370 165 499 minecraft:white_concrete
setblock 330 166 470 minecraft:red_nether_bricks
setblock 330 166 475 minecraft:white_concrete
setblock 330 166 490 minecraft:red_nether_bricks
fill 330 166 491 330 169 491 minecraft:pink_terracotta
setblock 330 166 495 minecraft:red_nether_bricks
fill 330 166 496 330 169 496 minecraft:pink_terracotta
setblock 330 166 500 minecraft:red_nether_bricks
setblock 331 166 490 minecraft:pink_terracotta
setblock 331 166 494 minecraft:red_nether_bricks
fill 331 166 495 331 169 495 minecraft:pink_terracotta
fill 331 166 497 331 167 497 minecraft:pink_terracotta
setblock 332 166 493 minecraft:red_nether_bricks
setblock 332 166 504 minecraft:pink_terracotta
setblock 336 166 464 minecraft:red_nether_bricks
setblock 336 166 504 minecraft:red_nether_bricks
fill 337 166 464 337 167 464 minecraft:pink_terracotta
fill 337 166 504 337 169 504 minecraft:pink_terracotta
setblock 341 166 464 minecraft:red_nether_bricks
setblock 341 166 504 minecraft:red_nether_bricks
setblock 345 166 504 minecraft:white_concrete
setblock 349 166 464 minecraft:white_concrete
fill 351 166 504 351 167 504 minecraft:white_concrete
setblock 355 166 465 minecraft:red_nether_bricks
setblock 356 166 464 minecraft:red_nether_bricks
fill 356 166 465 356 169 465 minecraft:pink_terracotta
fill 357 166 464 357 169 464 minecraft:pink_terracotta
setblock 358 166 467 minecraft:red_nether_bricks
setblock 359 166 466 minecraft:red_nether_bricks
setblock 359 166 467 minecraft:pink_terracotta
setblock 360 166 465 minecraft:red_nether_bricks
fill 360 166 466 360 167 466 minecraft:pink_terracotta
setblock 361 166 464 minecraft:red_nether_bricks
fill 361 166 465 361 168 465 minecraft:pink_terracotta
setblock 361 166 504 minecraft:red_nether_bricks
fill 362 166 464 362 169 464 minecraft:pink_terracotta
setblock 362 166 504 minecraft:pink_terracotta
setblock 364 166 466 minecraft:red_nether_bricks
setblock 365 166 465 minecraft:red_nether_bricks
setblock 366 166 464 minecraft:red_nether_bricks
setblock 366 166 465 minecraft:pink_terracotta
setblock 366 166 475 minecraft:black_concrete
fill 367 166 464 367 167 464 minecraft:pink_terracotta
setblock 369 166 467 minecraft:pink_terracotta
setblock 369 166 471 minecraft:red_nether_bricks
setblock 370 166 465 minecraft:red_nether_bricks
fill 370 166 466 370 168 466 minecraft:pink_terracotta
setblock 370 166 470 minecraft:red_nether_bricks
fill 370 166 471 370 169 471 minecraft:pink_terracotta
setblock 370 166 487 minecraft:white_concrete
setblock 370 166 494 minecraft:pink_terracotta
setblock 370 166 504 minecraft:white_concrete
setblock 330 167 481 minecraft:white_concrete
fill 330 167 487 330 168 487 minecraft:white_concrete
setblock 330 167 489 minecraft:red_nether_bricks
fill 330 167 490 330 170 490 minecraft:pink_terracotta
setblock 330 167 494 minecraft:red_nether_bricks
fill 330 167 495 330 170 495 minecraft:pink_terracotta
setblock 330 167 498 minecraft:pink_terracotta
setblock 330 167 499 minecraft:red_nether_bricks
fill 330 167 500 330 170 500 minecraft:pink_terracotta
setblock 331 167 493 minecraft:red_nether_bricks
fill 331 167 494 332 169 494 minecraft:pink_terracotta
fill 332 167 493 332 170 493 minecraft:pink_terracotta
setblock 332 167 504 minecraft:white_concrete
setblock 335 167 504 minecraft:red_nether_bricks
setblock 336 167 464 minecraft:pink_terracotta
fill 336 167 504 336 170 504 minecraft:pink_terracotta
setblock 343 167 464 minecraft:white_concrete
setblock 355 167 464 minecraft:red_nether_bricks
setblock 355 167 465 minecraft:pink_terracotta
fill 356 167 464 356 170 464 minecraft:pink_terracotta
setblock 357 167 504 minecraft:white_concrete
setblock 358 167 466 minecraft:red_nether_bricks
setblock 359 167 465 minecraft:red_nether_bricks
fill 359 167 466 359 168 466 minecraft:pink_terracotta
setblock 360 167 464 minecraft:red_nether_bricks
fill 360 167 465 360 169 465 minecraft:pink_terracotta
fill 361 167 464 361 170 464 minecraft:pink_terracotta
setblock 364 167 465 minecraft:red_nether_bricks
setblock 365 167 464 minecraft:red_nether_bricks
setblock 366 167 464 minecraft:pink_terracotta
setblock 368 167 464 minecraft:white_concrete
setblock 370 167 465 minecraft:pink_terracotta
setblock 370 167 469 minecraft:red_nether_bricks
fill 370 167 470 370 170 470 minecraft:pink_terracotta
setblock 370 167 474 minecraft:white_concrete
setblock 370 167 481 minecraft:white_concrete
setblock 370 167 494 minecraft:red_nether_bricks
fill 370 167 495 370 170 495 minecraft:pink_terracotta
setblock 330 168 468 minecraft:white_concrete
setblock 330 168 489 minecraft:pink_terracotta
setblock 330 168 493 minecraft:red_nether_bricks
fill 330 168 494 330 171 494 minecraft:pink_terracotta
setblock 330 168 498 minecraft:red_nether_bricks
fill 330 168 499 330 171 499 minecraft:pink_terracotta
setblock 331 168 492 minecraft:red_nether_bricks
fill 331 168 493 331 171 493 minecraft:pink_terracotta
setblock 331 168 497 minecraft:red_nether_bricks
fill 331 168 498 331 171 498 minecraft:pink_terracotta
setblock 332 168 495 minecraft:pink_terracotta
setblock 334 168 504 minecraft:red_nether_bricks
fill 335 168 504 335 171 504 minecraft:pink_terracotta
setblock 337 168 464 minecraft:white_concrete
setblock 354 168 464 minecraft:red_nether_bricks
fill 355 168 464 355 171 464 minecraft:pink_terracotta
setblock 358 168 465 minecraft:red_nether_bricks
setblock 358 168 466 minecraft:pink_terracotta
setblock 359 168 464 minecraft:red_nether_bricks
fill 359 168 465 359 169 465 minecraft:pink_terracotta
fill 360 168 464 360 171 464 minecraft:pink_terracotta
setblock 363 168 504 minecraft:white_concrete
setblock 364 168 464 minecraft:red_nether_bricks
setblock 370 168 468 minecraft:red_nether_bricks
fill 370 168 469 370 171 469 minecraft:pink_terracotta
setblock 370 168 473 minecraft:red_nether_bricks
setblock 370 168 493 minecraft:red_nether_bricks
fill 370 168 494 370 171 494 minecraft:pink_terracotta
fill 370 168 496 370 168 497 minecraft:pink_terracotta
setblock 370 168 500 minecraft:white_concrete
setblock 330 169 474 minecraft:white_concrete
setblock 330 169 492 minecraft:red_nether_bricks
fill 330 169 493 330 172 493 minecraft:pink_terracotta
setblock 330 169 497 minecraft:red_nether_bricks
fill 330 169 498 330 172 498 minecraft:pink_terracotta
setblock 330 169 501 minecraft:pink_terracotta
setblock 331 169 464 minecraft:white_concrete
setblock 331 169 491 minecraft:red_nether_bricks
fill 331 169 492 331 172 492 minecraft:pink_terracotta
setblock 331 169 496 minecraft:red_nether_bricks
fill 331 169 497 332 171 497 minecraft:pink_terracotta
fill 331 169 499 331 170 499 minecraft:pink_terracotta
setblock 332 169 466 minecraft:light[level=12]
setblock 332 169 474 minecraft:light[level=12]
setblock 332 169 482 minecraft:light[level=12]
setblock 332 169 490 minecraft:light[level=12]
setblock 332 169 495 minecraft:red_nether_bricks
fill 332 169 496 332 172 496 minecraft:pink_terracotta
setblock 332 169 498 minecraft:light[level=12]
setblock 333 169 504 minecraft:red_nether_bricks
fill 334 169 504 334 172 504 minecraft:pink_terracotta
setblock 340 169 466 minecraft:light[level=12]
setblock 340 169 474 minecraft:light[level=12]
setblock 340 169 482 minecraft:light[level=12]
setblock 340 169 490 minecraft:light[level=12]
setblock 340 169 498 minecraft:light[level=12]
setblock 344 169 504 minecraft:white_concrete
setblock 348 169 466 minecraft:light[level=12]
setblock 348 169 474 minecraft:light[level=12]
setblock 348 169 482 minecraft:light[level=12]
setblock 348 169 490 minecraft:light[level=12]
setblock 348 169 498 minecraft:light[level=12]
fill 354 169 464 354 172 464 minecraft:pink_terracotta
setblock 356 169 466 minecraft:light[level=12]
setblock 356 169 474 minecraft:light[level=12]
setblock 356 169 482 minecraft:light[level=12]
setblock 356 169 490 minecraft:light[level=12]
setblock 356 169 498 minecraft:light[level=12]
setblock 357 169 465 minecraft:red_nether_bricks
setblock 358 169 464 minecraft:red_nether_bricks
fill 358 169 465 358 170 465 minecraft:pink_terracotta
fill 359 169 464 359 172 464 minecraft:pink_terracotta
setblock 363 169 464 minecraft:red_nether_bricks
setblock 364 169 466 minecraft:light[level=12]
setblock 364 169 474 minecraft:light[level=12]
setblock 364 169 482 minecraft:light[level=12]
setblock 364 169 490 minecraft:light[level=12]
setblock 364 169 498 minecraft:light[level=12]
setblock 369 169 504 minecraft:white_concrete
setblock 370 169 468 minecraft:pink_terracotta
setblock 370 169 472 minecraft:red_nether_bricks
fill 370 169 473 370 172 473 minecraft:pink_terracotta
fill 370 169 493 370 172 493 minecraft:pink_terracotta
setblock 370 169 496 minecraft:pink_terracotta
setblock 370 169 497 minecraft:red_nether_bricks
fill 370 169 498 370 171 499 minecraft:pink_terracotta
setblock 330 170 480 minecraft:white_concrete
setblock 330 170 491 minecraft:red_nether_bricks
fill 330 170 492 330 173 492 minecraft:pink_terracotta
setblock 330 170 496 minecraft:red_nether_bricks
fill 330 170 497 330 173 497 minecraft:pink_terracotta
setblock 330 170 501 minecraft:red_nether_bricks
fill 330 170 502 330 173 502 minecraft:pink_terracotta
fill 331 170 491 331 173 491 minecraft:pink_terracotta
setblock 331 170 494 minecraft:pink_terracotta
setblock 331 170 495 minecraft:red_nether_bricks
fill 331 170 496 331 173 496 minecraft:pink_terracotta
setblock 331 170 500 minecraft:red_nether_bricks
setblock 331 170 504 minecraft:white_concrete
fill 332 170 492 332 171 492 minecraft:pink_terracotta
setblock 332 170 494 minecraft:red_nether_bricks
fill 332 170 495 332 173 495 minecraft:pink_terracotta
setblock 332 170 498 minecraft:pink_terracotta
fill 333 170 504 333 173 504 minecraft:pink_terracotta
setblock 337 170 504 minecraft:red_nether_bricks
setblock 350 170 464 minecraft:white_concrete
setblock 350 170 504 minecraft:white_concrete
setblock 357 170 464 minecraft:red_nether_bricks
fill 357 170 465 357 173 465 minecraft:pink_terracotta
fill 358 170 464 358 173 464 minecraft:pink_terracotta
setblock 369 170 464 minecraft:white_concrete
setblock 370 170 471 minecraft:red_nether_bricks
fill 370 170 472 370 173 472 minecraft:pink_terracotta
fill 370 170 474 370 171 474 minecraft:pink_terracotta
setblock 370 170 488 minecraft:white_concrete
setblock 370 170 496 minecraft:red_nether_bricks
fill 370 170 497 370 173 497 minecraft:pink_terracotta
setblock 370 170 500 minecraft:pink_terracotta
setblock 370 170 501 minecraft:red_nether_bricks
setblock 330 171 467 minecraft:white_concrete
setblock 330 171 486 minecraft:white_concrete
setblock 330 171 489 minecraft:pink_terracotta
setblock 330 171 490 minecraft:red_nether_bricks
fill 330 171 491 330 174 491 minecraft:pink_terracotta
setblock 330 171 495 minecraft:red_nether_bricks
fill 330 171 496 330 174 496 minecraft:pink_terracotta
setblock 330 171 500 minecraft:red_nether_bricks
fill 330 171 501 331 173 501 minecraft:pink_terracotta
fill 330 171 503 330 172 503 minecraft:pink_terracotta
setblock 331 171 494 minecraft:red_nether_bricks
fill 331 171 495 331 174 495 minecraft:pink_terracotta
setblock 331 171 499 minecraft:red_nether_bricks
fill 331 171 500 331 174 500 minecraft:pink_terracotta
setblock 331 171 504 minecraft:red_nether_bricks
setblock 332 171 493 minecraft:red_nether_bricks
fill 332 171 494 332 174 494 minecraft:pink_terracotta
setblock 332 171 498 minecraft:red_nether_bricks
fill 332 171 499 332 174 499 minecraft:pink_terracotta
fill 332 171 504 332 174 504 minecraft:pink_terracotta
fill 333 171 495 333 171 496 minecraft:pink_terracotta
setblock 336 171 504 minecraft:red_nether_bricks
fill 337 171 504 337 174 504 minecraft:pink_terracotta
setblock 344 171 464 minecraft:white_concrete
setblock 356 171 464 minecraft:red_nether_bricks
fill 356 171 465 356 174 465 minecraft:pink_terracotta
setblock 356 171 504 minecraft:white_concrete
fill 357 171 464 357 174 464 minecraft:pink_terracotta
setblock 361 171 464 minecraft:red_nether_bricks
setblock 363 171 464 minecraft:white_concrete
setblock 370 171 470 minecraft:red_nether_bricks
fill 370 171 471 370 174 471 minecraft:pink_terracotta
setblock 370 171 475 minecraft:red_nether_bricks
setblock 370 171 482 minecraft:white_concrete
fill 370 171 492 370 173 492 minecraft:pink_terracotta
setblock 370 171 495 minecraft:red_nether_bricks
fill 370 171 496 370 174 496 minecraft:pink_terracotta
setblock 370 171 500 minecraft:red_nether_bricks
fill 370 171 501 370 172 503 minecraft:pink_terracotta
setblock 330 172 473 minecraft:pink_terracotta
setblock 330 172 474 minecraft:red_nether_bricks
fill 330 172 475 330 173 477 minecraft:pink_terracotta
setblock 330 172 489 minecraft:red_nether_bricks
fill 330 172 490 331 174 490 minecraft:pink_terracotta
setblock 330 172 494 minecraft:red_nether_bricks
fill 330 172 495 330 175 495 minecraft:pink_terracotta
setblock 330 172 499 minecraft:red_nether_bricks
fill 330 172 500 330 175 500 minecraft:pink_terracotta
setblock 330 172 504 minecraft:red_nether_bricks
setblock 331 172 493 minecraft:red_nether_bricks
fill 331 172 494 331 175 494 minecraft:pink_terracotta
setblock 331 172 497 minecraft:pink_terracotta
setblock 331 172 498 minecraft:red_nether_bricks
fill 331 172 499 331 175 499 minecraft:pink_terracotta
setblock 331 172 502 minecraft:pink_terracotta
fill 331 172 504 331 175 504 minecraft:pink_terracotta
setblock 332 172 492 minecraft:red_nether_bricks
fill 332 172 493 332 175 493 minecraft:pink_terracotta
setblock 332 172 497 minecraft:red_nether_bricks
fill 332 172 498 333 174 498 minecraft:pink_terracotta
fill 332 172 500 332 173 500 minecraft:pink_terracotta
fill 332 172 503 335 172 503 minecraft:pink_terracotta
fill 333 172 494 333 172 495 minecraft:pink_terracotta
setblock 333 172 496 minecraft:red_nether_bricks
fill 333 172 497 333 175 497 minecraft:pink_terracotta
setblock 335 172 504 minecraft:red_nether_bricks
fill 336 172 491 336 176 491 minecraft:iron_block
fill 336 172 504 336 175 504 minecraft:pink_terracotta
setblock 338 172 464 minecraft:white_concrete
setblock 343 172 504 minecraft:white_concrete
fill 353 172 464 353 173 464 minecraft:pink_terracotta
setblock 355 172 464 minecraft:red_nether_bricks
fill 355 172 465 355 175 465 minecraft:pink_terracotta
setblock 355 172 504 minecraft:red_nether_bricks
fill 356 172 464 356 175 464 minecraft:pink_terracotta
fill 356 172 504 359 172 504 minecraft:pink_terracotta
setblock 360 172 464 minecraft:red_nether_bricks
fill 361 172 464 361 175 464 minecraft:pink_terracotta
setblock 362 172 504 minecraft:white_concrete
fill 369 172 496 369 172 499 minecraft:pink_terracotta
setblock 369 172 504 minecraft:pink_terracotta
setblock 370 172 469 minecraft:red_nether_bricks
fill 370 172 470 370 175 470 minecraft:pink_terracotta
setblock 370 172 474 minecraft:red_nether_bricks
fill 370 172 475 370 174 476 minecraft:pink_terracotta
setblock 370 172 494 minecraft:red_nether_bricks
fill 370 172 495 370 175 495 minecraft:pink_terracotta
setblock 370 172 498 minecraft:pink_terracotta
setblock 370 172 499 minecraft:red_nether_bricks
fill 370 172 500 370 175 500 minecraft:pink_terracotta
setblock 370 172 504 minecraft:red_nether_bricks
setblock 330 173 472 minecraft:pink_terracotta
setblock 330 173 473 minecraft:red_nether_bricks
fill 330 173 474 330 176 474 minecraft:pink_terracotta
setblock 330 173 478 minecraft:red_nether_bricks
fill 330 173 479 330 174 481 minecraft:pink_terracotta
setblock 330 173 488 minecraft:red_nether_bricks
fill 330 173 489 330 176 489 minecraft:pink_terracotta
setblock 330 173 493 minecraft:red_nether_bricks
fill 330 173 494 330 176 494 minecraft:pink_terracotta
setblock 330 173 498 minecraft:red_nether_bricks
fill 330 173 499 330 176 499 minecraft:pink_terracotta
setblock 330 173 503 minecraft:red_nether_bricks
fill 330 173 504 330 176 504 minecraft:pink_terracotta
fill 331 173 475 331 173 476 minecraft:pink_terracotta
setblock 331 173 477 minecraft:red_nether_bricks
fill 331 173 478 331 176 478 minecraft:pink_terracotta
setblock 331 173 492 minecraft:red_nether_bricks
fill 331 173 493 331 176 493 minecraft:pink_terracotta
setblock 331 173 497 minecraft:red_nether_bricks
fill 331 173 498 331 176 498 minecraft:pink_terracotta
setblock 331 173 502 minecraft:red_nether_bricks
fill 331 173 503 334 173 503 minecraft:pink_terracotta
setblock 332 173 464 minecraft:white_concrete
setblock 332 173 491 minecraft:red_nether_bricks
fill 332 173 492 332 176 492 minecraft:pink_terracotta
setblock 332 173 496 minecraft:red_nether_bricks
fill 332 173 497 332 176 497 minecraft:pink_terracotta
setblock 332 173 501 minecraft:red_nether_bricks
setblock 333 173 494 minecraft:pink_terracotta
setblock 333 173 495 minecraft:red_nether_bricks
fill 333 173 496 333 176 496 minecraft:pink_terracotta
setblock 333 173 499 minecraft:pink_terracotta
fill 333 173 502 334 174 502 minecraft:pink_terracotta
setblock 334 173 504 minecraft:red_nether_bricks
setblock 335 173 503 minecraft:red_nether_bricks
fill 335 173 504 335 176 504 minecraft:pink_terracotta
fill 336 173 503 336 176 503 minecraft:pink_terracotta
fill 337 173 467 337 174 468 minecraft:white_concrete
fill 338 173 466 339 173 466 minecraft:white_concrete
fill 338 173 469 339 173 469 minecraft:white_concrete
setblock 338 173 504 minecraft:pink_terracotta
fill 340 173 467 340 173 468 minecraft:white_concrete
setblock 349 173 504 minecraft:white_concrete
setblock 351 173 464 minecraft:white_concrete
fill 352 173 464 352 174 464 minecraft:pink_terracotta
setblock 353 173 504 minecraft:pink_terracotta
setblock 354 173 464 minecraft:red_nether_bricks
fill 354 173 465 354 176 465 minecraft:pink_terracotta
setblock 354 173 504 minecraft:red_nether_bricks
fill 355 173 464 355 176 464 minecraft:pink_terracotta
fill 355 173 504 358 173 504 minecraft:pink_terracotta
setblock 358 173 465 minecraft:red_nether_bricks
setblock 359 173 464 minecraft:red_nether_bricks
setblock 359 173 504 minecraft:red_nether_bricks
fill 360 173 464 360 176 464 minecraft:pink_terracotta
fill 360 173 475 360 174 476 minecraft:pink_concrete
fill 360 173 504 360 176 504 minecraft:pink_terracotta
fill 367 173 504 368 173 504 minecraft:pink_terracotta
fill 369 173 495 369 173 498 minecraft:pink_terracotta
setblock 369 173 499 minecraft:red_nether_bricks
fill 369 173 500 369 174 502 minecraft:pink_terracotta
setblock 369 173 504 minecraft:red_nether_bricks
fill 370 173 469 370 176 469 minecraft:pink_terracotta
setblock 370 173 473 minecraft:red_nether_bricks
fill 370 173 474 370 176 474 minecraft:pink_terracotta
setblock 370 173 477 minecraft:pink_terracotta
setblock 370 173 478 minecraft:red_nether_bricks
setblock 370 173 489 minecraft:white_concrete
fill 370 173 491 370 174 491 minecraft:pink_terracotta
setblock 370 173 493 minecraft:red_nether_bricks
fill 370 173 494 370 176 494 minecraft:pink_terracotta
setblock 370 173 498 minecraft:red_nether_bricks
fill 370 173 499 370 176 499 minecraft:pink_terracotta
fill 370 173 501 370 173 502 minecraft:pink_terracotta
setblock 370 173 503 minecraft:red_nether_bricks
fill 370 173 504 370 176 504 minecraft:pink_terracotta
setblock 330 174 471 minecraft:pink_terracotta
setblock 330 174 472 minecraft:red_nether_bricks
fill 330 174 473 331 176 473 minecraft:pink_terracotta
fill 330 174 475 330 174 476 minecraft:pink_terracotta
setblock 330 174 477 minecraft:red_nether_bricks
fill 330 174 478 330 176 478 minecraft:pink_terracotta
setblock 330 174 482 minecraft:red_nether_bricks
fill 330 174 483 330 174 486 minecraft:pink_terracotta
setblock 330 174 487 minecraft:red_nether_bricks
fill 330 174 488 331 176 488 minecraft:pink_terracotta
setblock 330 174 492 minecraft:red_nether_bricks
fill 330 174 493 330 176 493 minecraft:pink_terracotta
setblock 330 174 497 minecraft:red_nether_bricks
fill 330 174 498 330 176 498 minecraft:pink_terracotta
setblock 330 174 501 minecraft:pink_terracotta
setblock 330 174 502 minecraft:red_nether_bricks
fill 330 174 503 333 174 503 minecraft:pink_terracotta
fill 331 174 474 331 174 475 minecraft:pink_terracotta
setblock 331 174 476 minecraft:red_nether_bricks
fill 331 174 477 332 176 477 minecraft:pink_terracotta
fill 331 174 479 331 174 480 minecraft:pink_terracotta
setblock 331 174 481 minecraft:red_nether_bricks
fill 331 174 482 331 176 482 minecraft:pink_terracotta
fill 331 174 489 331 175 489 minecraft:pink_terracotta
setblock 331 174 491 minecraft:red_nether_bricks
fill 331 174 492 331 176 492 minecraft:pink_terracotta
setblock 331 174 496 minecraft:red_nether_bricks
fill 331 174 497 331 176 497 minecraft:pink_terracotta
setblock 331 174 501 minecraft:red_nether_bricks
fill 331 174 502 332 176 502 minecraft:pink_terracotta
fill 332 174 478 332 175 478 minecraft:pink_terracotta
fill 332 174 491 332 176 491 minecraft:pink_terracotta
setblock 332 174 495 minecraft:red_nether_bricks
fill 332 174 496 332 176 496 minecraft:pink_terracotta
setblock 332 174 500 minecraft:red_nether_bricks
fill 332 174 501 332 176 501 minecraft:pink_terracotta
setblock 333 174 493 minecraft:pink_terracotta
setblock 333 174 494 minecraft:red_nether_bricks
fill 333 174 495 333 176 495 minecraft:pink_terracotta
setblock 333 174 499 minecraft:red_nether_bricks
fill 333 174 500 333 176 500 minecraft:pink_terracotta
setblock 333 174 504 minecraft:red_nether_bricks
setblock 334 174 503 minecraft:red_nether_bricks
fill 334 174 504 334 176 504 minecraft:pink_terracotta
setblock 335 174 502 minecraft:red_nether_bricks
fill 335 174 503 335 176 503 minecraft:pink_terracotta
fill 337 174 503 337 175 503 minecraft:pink_terracotta
setblock 338 174 466 minecraft:white_concrete
setblock 338 174 469 minecraft:white_concrete
setblock 338 174 504 minecraft:red_nether_bricks
setblock 345 174 464 minecraft:white_concrete
fill 351 174 464 351 175 464 minecraft:pink_terracotta
fill 351 174 504 352 174 504 minecraft:pink_terracotta
setblock 353 174 464 minecraft:red_nether_bricks
fill 353 174 465 353 176 465 minecraft:pink_terracotta
setblock 353 174 504 minecraft:red_nether_bricks
fill 354 174 464 354 176 464 minecraft:pink_terracotta
setblock 354 174 503 minecraft:red_nether_bricks
fill 354 174 504 357 174 504 minecraft:pink_terracotta
fill 355 174 503 358 174 503 minecraft:pink_terracotta
setblock 357 174 465 minecraft:red_nether_bricks
setblock 358 174 464 minecraft:red_nether_bricks
fill 358 174 465 358 176 465 minecraft:pink_terracotta
setblock 358 174 504 minecraft:red_nether_bricks
fill 359 174 464 359 176 464 minecraft:pink_terracotta
fill 359 174 504 359 176 504 minecraft:pink_terracotta
fill 361 174 504 362 174 504 minecraft:pink_terracotta
setblock 363 174 504 minecraft:red_nether_bricks
fill 364 174 464 364 175 464 minecraft:white_concrete
fill 364 174 504 367 174 504 minecraft:pink_terracotta
setblock 368 174 503 minecraft:pink_terracotta
setblock 368 174 504 minecraft:red_nether_bricks
fill 369 174 464 370 176 464 minecraft:pink_terracotta
fill 369 174 494 369 174 497 minecraft:pink_terracotta
setblock 369 174 498 minecraft:red_nether_bricks
fill 369 174 499 369 176 499 minecraft:pink_terracotta
setblock 369 174 503 minecraft:red_nether_bricks
fill 369 174 504 369 176 504 minecraft:pink_terracotta
fill 370 174 465 370 174 466 minecraft:pink_terracotta
setblock 370 174 467 minecraft:red_nether_bricks
fill 370 174 468 370 176 468 minecraft:pink_terracotta
setblock 370 174 472 minecraft:red_nether_bricks
fill 370 174 473 370 176 473 minecraft:pink_terracotta
setblock 370 174 477 minecraft:red_nether_bricks
fill 370 174 478 370 175 480 minecraft:pink_terracotta
setblock 370 174 483 minecraft:white_concrete
setblock 370 174 492 minecraft:red_nether_bricks
fill 370 174 493 370 176 493 minecraft:pink_terracotta
setblock 370 174 497 minecraft:red_nether_bricks
fill 370 174 498 370 176 498 minecraft:pink_terracotta
setblock 370 174 501 minecraft:pink_terracotta
setblock 370 174 502 minecraft:red_nether_bricks
fill 370 174 503 370 176 503 minecraft:pink_terracotta
setblock 330 175 466 minecraft:white_concrete
setblock 330 175 471 minecraft:red_nether_bricks
fill 330 175 472 330 176 472 minecraft:pink_terracotta
setblock 330 175 475 minecraft:pink_terracotta
setblock 330 175 476 minecraft:red_nether_bricks
fill 330 175 477 330 176 477 minecraft:pink_terracotta
fill 330 175 479 330 175 480 minecraft:pink_terracotta
setblock 330 175 481 minecraft:red_nether_bricks
fill 330 175 482 330 175 485 minecraft:pink_terracotta
setblock 330 175 486 minecraft:red_nether_bricks
fill 330 175 487 331 176 487 minecraft:pink_terracotta
setblock 330 175 490 minecraft:pink_terracotta
setblock 330 175 491 minecraft:red_nether_bricks
fill 330 175 492 330 176 492 minecraft:pink_terracotta
setblock 330 175 496 minecraft:red_nether_bricks
fill 330 175 497 330 176 497 minecraft:pink_terracotta
setblock 330 175 501 minecraft:red_nether_bricks
fill 330 175 502 330 176 503 minecraft:pink_terracotta
setblock 331 175 474 minecraft:pink_terracotta
setblock 331 175 475 minecraft:red_nether_bricks
fill 331 175 476 332 176 476 minecraft:pink_terracotta
setblock 331 175 479 minecraft:pink_terracotta
setblock 331 175 480 minecraft:red_nether_bricks
fill 331 175 481 332 176 481 minecraft:pink_terracotta
fill 331 175 483 331 175 484 minecraft:pink_terracotta
setblock 331 175 485 minecraft:red_nether_bricks
fill 331 175 486 331 176 486 minecraft:pink_terracotta
setblock 331 175 490 minecraft:red_nether_bricks
fill 331 175 491 331 176 491 minecraft:pink_terracotta
setblock 331 175 495 minecraft:red_nether_bricks
fill 331 175 496 331 176 496 minecraft:pink_terracotta
setblock 331 175 500 minecraft:red_nether_bricks
fill 331 175 501 331 176 501 minecraft:pink_terracotta
fill 331 175 503 332 175 503 minecraft:pink_terracotta
setblock 332 175 464 minecraft:red_nether_bricks
fill 332 175 475 332 176 475 minecraft:pink_terracotta
setblock 332 175 479 minecraft:red_nether_bricks
fill 332 175 480 332 176 480 minecraft:pink_terracotta
fill 332 175 482 332 176 482 minecraft:pink_terracotta
fill 332 175 490 332 176 490 minecraft:pink_terracotta
setblock 332 175 494 minecraft:red_nether_bricks
fill 332 175 495 332 176 495 minecraft:pink_terracotta
setblock 332 175 498 minecraft:pink_terracotta
setblock 332 175 499 minecraft:red_nether_bricks
fill 332 175 500 332 176 500 minecraft:pink_terracotta
setblock 332 175 504 minecraft:red_nether_bricks
fill 333 175 464 334 176 464 minecraft:pink_terracotta
setblock 333 175 493 minecraft:red_nether_bricks
fill 333 175 494 333 176 494 minecraft:pink_terracotta
setblock 333 175 498 minecraft:red_nether_bricks
fill 333 175 499 333 176 499 minecraft:pink_terracotta
fill 333 175 501 333 175 502 minecraft:pink_terracotta
setblock 333 175 503 minecraft:red_nether_bricks
fill 333 175 504 333 176 504 minecraft:pink_terracotta
setblock 334 175 501 minecraft:pink_terracotta
setblock 334 175 502 minecraft:red_nether_bricks
fill 334 175 503 334 176 503 minecraft:pink_terracotta
fill 335 175 502 336 176 502 minecraft:pink_terracotta
setblock 337 175 504 minecraft:red_nether_bricks
fill 338 175 504 338 176 504 minecraft:pink_terracotta
setblock 339 175 464 minecraft:white_concrete
fill 349 175 464 350 176 464 minecraft:pink_terracotta
fill 349 175 504 351 175 504 minecraft:pink_terracotta
setblock 351 175 465 minecraft:red_nether_bricks
fill 351 175 503 352 175 503 minecraft:pink_terracotta
setblock 352 175 464 minecraft:red_nether_bricks
fill 352 175 465 352 176 465 minecraft:pink_terracotta
setblock 352 175 504 minecraft:red_nether_bricks
fill 353 175 464 353 176 464 minecraft:pink_terracotta
setblock 353 175 503 minecraft:red_nether_bricks
fill 353 175 504 356 175 504 minecraft:pink_terracotta
fill 354 175 503 357 175 503 minecraft:pink_terracotta
setblock 356 175 465 minecraft:red_nether_bricks
setblock 357 175 464 minecraft:red_nether_bricks
fill 357 175 465 357 176 465 minecraft:pink_terracotta
setblock 357 175 504 minecraft:red_nether_bricks
fill 358 175 464 358 176 464 minecraft:pink_terracotta
setblock 358 175 503 minecraft:red_nether_bricks
fill 358 175 504 358 176 504 minecraft:pink_terracotta
fill 359 175 503 360 176 503 minecraft:pink_terracotta
setblock 361 175 504 minecraft:pink_terracotta
setblock 362 175 464 minecraft:red_nether_bricks
setblock 362 175 504 minecraft:red_nether_bricks
fill 363 175 504 366 175 504 minecraft:pink_terracotta
fill 365 175 503 367 175 503 minecraft:pink_terracotta
setblock 367 175 464 minecraft:red_nether_bricks
setblock 367 175 504 minecraft:red_nether_bricks
fill 368 175 464 368 176 464 minecraft:pink_terracotta
setblock 368 175 497 minecraft:pink_terracotta
setblock 368 175 498 minecraft:red_nether_bricks
fill 368 175 499 368 175 502 minecraft:pink_terracotta
setblock 368 175 503 minecraft:red_nether_bricks
fill 368 175 504 368 176 504 minecraft:pink_terracotta
fill 369 175 475 369 175 476 minecraft:pink_terracotta
setblock 369 175 477 minecraft:red_nether_bricks
fill 369 175 493 369 175 496 minecraft:pink_terracotta
setblock 369 175 497 minecraft:red_nether_bricks
fill 369 175 498 369 176 498 minecraft:pink_terracotta
fill 369 175 500 369 175 501 minecraft:pink_terracotta
setblock 369 175 502 minecraft:red_nether_bricks
fill 369 175 503 369 176 503 minecraft:pink_terracotta
setblock 370 175 465 minecraft:pink_terracotta
setblock 370 175 466 minecraft:red_nether_bricks
fill 370 175 467 370 176 467 minecraft:pink_terracotta
setblock 370 175 471 minecraft:red_nether_bricks
fill 370 175 472 370 176 472 minecraft:pink_terracotta
setblock 370 175 475 minecraft:pink_terracotta
setblock 370 175 476 minecraft:red_nether_bricks
fill 370 175 477 370 176 477 minecraft:pink_terracotta
setblock 370 175 481 minecraft:red_nether_bricks
fill 370 175 482 370 176 483 minecraft:pink_terracotta
setblock 370 175 490 minecraft:pink_terracotta
setblock 370 175 491 minecraft:red_nether_bricks
fill 370 175 492 370 176 492 minecraft:pink_terracotta
setblock 370 175 496 minecraft:red_nether_bricks
fill 370 175 497 370 176 497 minecraft:pink_terracotta
setblock 370 175 501 minecraft:red_nether_bricks
fill 370 175 502 370 176 502 minecraft:pink_terracotta
setblock 330 176 464 minecraft:pink_terracotta
setblock 330 176 470 minecraft:red_nether_bricks
setblock 330 176 471 minecraft:pink_terracotta
setblock 330 176 475 minecraft:red_nether_bricks
setblock 330 176 476 minecraft:pink_terracotta
setblock 330 176 479 minecraft:pink_terracotta
setblock 330 176 480 minecraft:red_nether_bricks
fill 330 176 481 330 176 484 minecraft:pink_terracotta
setblock 330 176 485 minecraft:red_nether_bricks
setblock 330 176 486 minecraft:pink_terracotta
setblock 330 176 490 minecraft:red_nether_bricks
setblock 330 176 491 minecraft:pink_terracotta
setblock 330 176 495 minecraft:red_nether_bricks
setblock 330 176 496 minecraft:pink_terracotta
setblock 330 176 500 minecraft:red_nether_bricks
setblock 330 176 501 minecraft:pink_terracotta
setblock 331 176 464 minecraft:red_nether_bricks
setblock 331 176 474 minecraft:red_nether_bricks
setblock 331 176 475 minecraft:pink_terracotta
setblock 331 176 479 minecraft:red_nether_bricks
setblock 331 176 480 minecraft:pink_terracotta
setblock 331 176 483 minecraft:pink_terracotta
setblock 331 176 484 minecraft:red_nether_bricks
fill 331 176 485 332 176 485 minecraft:pink_terracotta
setblock 331 176 489 minecraft:red_nether_bricks
setblock 331 176 490 minecraft:pink_terracotta
setblock 331 176 494 minecraft:red_nether_bricks
setblock 331 176 495 minecraft:pink_terracotta
setblock 331 176 499 minecraft:red_nether_bricks
setblock 331 176 500 minecraft:pink_terracotta
setblock 331 176 503 minecraft:pink_terracotta
setblock 331 176 504 minecraft:red_nether_bricks
setblock 332 176 464 minecraft:pink_terracotta
setblock 332 176 478 minecraft:red_nether_bricks
fill 332 176 479 333 176 479 minecraft:pink_terracotta
setblock 332 176 483 minecraft:red_nether_bricks
setblock 332 176 484 minecraft:pink_terracotta
setblock 332 176 486 minecraft:pink_terracotta
setblock 332 176 489 minecraft:pink_terracotta
setblock 332 176 493 minecraft:red_nether_bricks
setblock 332 176 494 minecraft:pink_terracotta
setblock 332 176 498 minecraft:red_nether_bricks
setblock 332 176 499 minecraft:pink_terracotta
setblock 332 176 503 minecraft:red_nether_bricks
setblock 332 176 504 minecraft:pink_terracotta
setblock 333 176 478 minecraft:pink_terracotta
fill 333 176 480 333 176 481 minecraft:pink_terracotta
setblock 333 176 493 minecraft:pink_terracotta
schedule function dropper:buildpart/115_5 1t
