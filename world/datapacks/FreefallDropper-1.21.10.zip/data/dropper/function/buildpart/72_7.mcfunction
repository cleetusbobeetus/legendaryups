fill 15 193 324 18 193 324 minecraft:honeycomb_block
setblock 15 193 363 minecraft:yellow_terracotta
fill 16 193 323 16 196 323 minecraft:honeycomb_block
setblock 16 193 362 minecraft:yellow_terracotta
fill 16 193 363 16 196 363 minecraft:honeycomb_block
setblock 17 193 361 minecraft:yellow_terracotta
fill 17 193 362 17 196 362 minecraft:honeycomb_block
fill 18 193 361 18 195 361 minecraft:honeycomb_block
setblock 19 193 324 minecraft:yellow_terracotta
setblock 20 193 323 minecraft:yellow_terracotta
fill 20 193 324 23 193 324 minecraft:honeycomb_block
setblock 20 193 363 minecraft:yellow_terracotta
fill 21 193 323 21 196 323 minecraft:honeycomb_block
setblock 21 193 362 minecraft:yellow_terracotta
fill 21 193 363 21 196 363 minecraft:honeycomb_block
setblock 22 193 361 minecraft:yellow_terracotta
fill 22 193 362 22 196 362 minecraft:honeycomb_block
setblock 23 193 360 minecraft:yellow_terracotta
fill 23 193 361 23 195 361 minecraft:honeycomb_block
fill 24 193 324 24 193 325 minecraft:yellow_terracotta
setblock 25 193 323 minecraft:yellow_terracotta
fill 25 193 324 25 196 324 minecraft:honeycomb_block
fill 25 193 325 25 195 326 minecraft:yellow_terracotta
setblock 25 193 327 minecraft:brown_terracotta
fill 25 193 359 25 195 360 minecraft:yellow_terracotta
setblock 25 193 363 minecraft:yellow_terracotta
fill 26 193 323 26 196 323 minecraft:honeycomb_block
fill 26 193 325 26 194 325 minecraft:yellow_terracotta
setblock 26 193 326 minecraft:brown_terracotta
fill 26 193 328 26 194 328 minecraft:brown_terracotta
fill 26 193 360 26 194 360 minecraft:yellow_terracotta
setblock 26 193 362 minecraft:yellow_terracotta
fill 26 193 363 26 196 363 minecraft:honeycomb_block
fill 27 193 327 27 196 327 minecraft:brown_terracotta
setblock 27 193 361 minecraft:yellow_terracotta
fill 27 193 362 27 195 362 minecraft:honeycomb_block
setblock 30 193 323 minecraft:yellow_terracotta
setblock 30 193 363 minecraft:yellow_terracotta
fill 31 193 323 31 195 323 minecraft:honeycomb_block
fill 31 193 363 31 194 363 minecraft:honeycomb_block
fill 33 193 323 34 193 323 minecraft:honeycomb_block
setblock 33 193 363 minecraft:honeycomb_block
setblock 35 193 323 minecraft:yellow_terracotta
fill 36 193 323 36 196 323 minecraft:honeycomb_block
fill 36 193 363 36 194 363 minecraft:honeycomb_block
setblock 38 193 324 minecraft:honeycomb_block
setblock 39 193 323 minecraft:honeycomb_block
setblock 39 193 324 minecraft:yellow_terracotta
setblock 39 193 339 minecraft:yellow_terracotta
fill 39 193 340 39 196 340 minecraft:honeycomb_block
setblock 39 193 344 minecraft:yellow_terracotta
fill 39 193 345 39 196 345 minecraft:honeycomb_block
fill 39 193 347 40 193 347 minecraft:honeycomb_block
setblock 40 193 323 minecraft:yellow_terracotta
fill 40 193 324 40 193 327 minecraft:honeycomb_block
setblock 40 193 328 minecraft:yellow_terracotta
fill 40 193 329 40 193 332 minecraft:honeycomb_block
setblock 40 193 333 minecraft:yellow_terracotta
fill 40 193 334 40 196 334 minecraft:honeycomb_block
setblock 40 193 338 minecraft:yellow_terracotta
fill 40 193 339 40 196 339 minecraft:honeycomb_block
setblock 40 193 343 minecraft:yellow_terracotta
fill 40 193 344 40 196 344 minecraft:honeycomb_block
fill 40 193 346 40 194 346 minecraft:honeycomb_block
setblock 40 193 348 minecraft:yellow_terracotta
fill 40 193 349 40 195 350 minecraft:honeycomb_block
setblock 40 193 362 minecraft:honeycomb_block
setblock 40 193 363 minecraft:yellow_terracotta
fill 41 193 323 41 193 326 minecraft:honeycomb_block
setblock 41 193 327 minecraft:yellow_terracotta
fill 41 193 328 41 196 328 minecraft:honeycomb_block
setblock 41 193 332 minecraft:yellow_terracotta
fill 41 193 333 41 196 333 minecraft:honeycomb_block
setblock 41 193 337 minecraft:yellow_terracotta
fill 41 193 338 41 196 338 minecraft:honeycomb_block
setblock 41 193 342 minecraft:yellow_terracotta
fill 41 193 343 41 196 343 minecraft:honeycomb_block
setblock 41 193 347 minecraft:yellow_terracotta
fill 41 193 348 41 196 348 minecraft:honeycomb_block
setblock 41 193 352 minecraft:yellow_terracotta
fill 41 193 353 41 196 353 minecraft:honeycomb_block
setblock 41 193 354 minecraft:honey_block
setblock 41 193 357 minecraft:yellow_terracotta
fill 41 193 358 41 194 358 minecraft:honeycomb_block
setblock 41 193 362 minecraft:yellow_terracotta
fill 41 193 363 41 196 363 minecraft:honeycomb_block
setblock 0 194 347 minecraft:orange_terracotta
setblock 1 194 326 minecraft:yellow_terracotta
fill 1 194 327 1 197 327 minecraft:honeycomb_block
setblock 1 194 331 minecraft:yellow_terracotta
fill 1 194 332 1 197 332 minecraft:honeycomb_block
setblock 1 194 336 minecraft:yellow_terracotta
fill 1 194 337 1 197 337 minecraft:honeycomb_block
setblock 1 194 341 minecraft:yellow_terracotta
fill 1 194 342 1 197 342 minecraft:honeycomb_block
setblock 1 194 346 minecraft:yellow_terracotta
fill 1 194 347 1 197 347 minecraft:honeycomb_block
setblock 1 194 351 minecraft:yellow_terracotta
fill 1 194 352 1 194 355 minecraft:honeycomb_block
setblock 1 194 356 minecraft:yellow_terracotta
fill 1 194 357 1 197 357 minecraft:honeycomb_block
setblock 1 194 361 minecraft:yellow_terracotta
fill 1 194 362 1 197 362 minecraft:honeycomb_block
setblock 2 194 325 minecraft:yellow_terracotta
fill 2 194 326 2 197 326 minecraft:honeycomb_block
setblock 2 194 329 minecraft:honeycomb_block
setblock 2 194 330 minecraft:yellow_terracotta
fill 2 194 331 2 197 331 minecraft:honeycomb_block
setblock 2 194 335 minecraft:yellow_terracotta
fill 2 194 336 2 195 336 minecraft:honeycomb_block
setblock 2 194 340 minecraft:yellow_terracotta
fill 2 194 341 2 196 341 minecraft:honeycomb_block
setblock 2 194 344 minecraft:honeycomb_block
setblock 2 194 345 minecraft:yellow_terracotta
fill 2 194 346 2 197 346 minecraft:honeycomb_block
setblock 2 194 360 minecraft:yellow_terracotta
fill 2 194 361 2 197 361 minecraft:honeycomb_block
setblock 3 194 324 minecraft:yellow_terracotta
fill 3 194 325 3 197 325 minecraft:honeycomb_block
setblock 3 194 329 minecraft:yellow_terracotta
fill 3 194 330 3 197 330 minecraft:honeycomb_block
setblock 3 194 340 minecraft:honeycomb_block
setblock 3 194 344 minecraft:yellow_terracotta
fill 3 194 345 3 195 345 minecraft:honeycomb_block
setblock 4 194 323 minecraft:yellow_terracotta
fill 4 194 324 4 197 324 minecraft:honeycomb_block
setblock 4 194 328 minecraft:yellow_terracotta
setblock 4 194 363 minecraft:yellow_terracotta
fill 5 194 323 5 197 323 minecraft:honeycomb_block
setblock 5 194 362 minecraft:yellow_terracotta
fill 5 194 363 8 194 363 minecraft:honeycomb_block
setblock 6 194 326 minecraft:yellow_terracotta
setblock 6 194 361 minecraft:yellow_terracotta
fill 6 194 362 6 197 362 minecraft:honeycomb_block
setblock 7 194 325 minecraft:yellow_terracotta
setblock 7 194 361 minecraft:honeycomb_block
fill 7 194 364 7 295 364 minecraft:honeycomb_block
setblock 8 194 324 minecraft:yellow_terracotta
fill 8 194 325 9 195 325 minecraft:honeycomb_block
setblock 9 194 323 minecraft:yellow_terracotta
fill 9 194 324 9 197 324 minecraft:honeycomb_block
setblock 9 194 363 minecraft:yellow_terracotta
fill 10 194 323 10 197 323 minecraft:honeycomb_block
setblock 10 194 362 minecraft:yellow_terracotta
fill 10 194 363 10 197 363 minecraft:honeycomb_block
fill 11 194 362 11 195 362 minecraft:honeycomb_block
setblock 12 194 324 minecraft:honeycomb_block
fill 12 194 364 12 199 364 minecraft:honeycomb_block
fill 13 194 322 13 217 322 minecraft:honeycomb_block
setblock 13 194 324 minecraft:yellow_terracotta
setblock 14 194 323 minecraft:yellow_terracotta
fill 14 194 324 17 194 324 minecraft:honeycomb_block
setblock 14 194 363 minecraft:yellow_terracotta
fill 15 194 323 15 197 323 minecraft:honeycomb_block
setblock 15 194 362 minecraft:yellow_terracotta
fill 15 194 363 15 197 363 minecraft:honeycomb_block
fill 16 194 362 16 197 362 minecraft:honeycomb_block
setblock 17 194 361 minecraft:honeycomb_block
setblock 18 194 324 minecraft:yellow_terracotta
setblock 19 194 323 minecraft:yellow_terracotta
fill 19 194 324 22 194 324 minecraft:honeycomb_block
setblock 19 194 363 minecraft:yellow_terracotta
fill 20 194 323 20 197 323 minecraft:honeycomb_block
setblock 20 194 362 minecraft:yellow_terracotta
fill 20 194 363 20 197 363 minecraft:honeycomb_block
setblock 21 194 325 minecraft:honeycomb_block
setblock 21 194 361 minecraft:yellow_terracotta
fill 21 194 362 21 197 362 minecraft:honeycomb_block
setblock 22 194 325 minecraft:yellow_terracotta
fill 22 194 361 22 196 361 minecraft:honeycomb_block
setblock 23 194 324 minecraft:yellow_terracotta
fill 23 194 325 23 195 325 minecraft:honeycomb_block
setblock 24 194 323 minecraft:yellow_terracotta
fill 24 194 324 24 197 324 minecraft:honeycomb_block
fill 24 194 325 24 194 327 minecraft:yellow_terracotta
fill 24 194 358 24 195 359 minecraft:yellow_terracotta
setblock 24 194 363 minecraft:yellow_terracotta
fill 25 194 323 25 197 323 minecraft:honeycomb_block
fill 25 194 327 26 195 327 minecraft:yellow_terracotta
fill 25 194 358 26 195 358 minecraft:yellow_terracotta
setblock 25 194 362 minecraft:yellow_terracotta
fill 25 194 363 25 197 363 minecraft:honeycomb_block
fill 26 194 326 26 195 326 minecraft:yellow_terracotta
fill 26 194 359 26 195 359 minecraft:yellow_terracotta
setblock 26 194 361 minecraft:yellow_terracotta
fill 26 194 362 26 195 362 minecraft:honeycomb_block
setblock 28 194 324 minecraft:yellow_terracotta
setblock 29 194 323 minecraft:yellow_terracotta
setblock 29 194 363 minecraft:yellow_terracotta
fill 30 194 323 30 195 323 minecraft:honeycomb_block
fill 30 194 363 30 195 363 minecraft:honeycomb_block
setblock 33 194 323 minecraft:honeycomb_block
setblock 34 194 323 minecraft:yellow_terracotta
fill 35 194 323 35 197 323 minecraft:honeycomb_block
setblock 37 194 324 minecraft:honeycomb_block
setblock 38 194 324 minecraft:yellow_terracotta
setblock 39 194 323 minecraft:yellow_terracotta
fill 39 194 324 40 194 326 minecraft:honeycomb_block
setblock 39 194 338 minecraft:yellow_terracotta
fill 39 194 339 39 196 339 minecraft:honeycomb_block
setblock 39 194 343 minecraft:yellow_terracotta
fill 39 194 344 39 197 344 minecraft:honeycomb_block
setblock 39 194 347 minecraft:honeycomb_block
setblock 39 194 348 minecraft:yellow_terracotta
setblock 39 194 363 minecraft:yellow_terracotta
fill 40 194 323 41 196 323 minecraft:honeycomb_block
setblock 40 194 327 minecraft:yellow_terracotta
fill 40 194 328 40 194 331 minecraft:honeycomb_block
setblock 40 194 332 minecraft:yellow_terracotta
fill 40 194 333 40 197 333 minecraft:honeycomb_block
setblock 40 194 337 minecraft:yellow_terracotta
fill 40 194 338 40 197 338 minecraft:honeycomb_block
setblock 40 194 342 minecraft:yellow_terracotta
fill 40 194 343 40 197 343 minecraft:honeycomb_block
setblock 40 194 347 minecraft:yellow_terracotta
fill 40 194 348 40 197 348 minecraft:honeycomb_block
setblock 40 194 362 minecraft:yellow_terracotta
fill 40 194 363 40 197 363 minecraft:honeycomb_block
fill 41 194 324 41 194 325 minecraft:honeycomb_block
setblock 41 194 326 minecraft:yellow_terracotta
fill 41 194 327 41 197 327 minecraft:honeycomb_block
setblock 41 194 331 minecraft:yellow_terracotta
fill 41 194 332 41 197 332 minecraft:honeycomb_block
setblock 41 194 336 minecraft:yellow_terracotta
fill 41 194 337 41 197 337 minecraft:honeycomb_block
setblock 41 194 341 minecraft:yellow_terracotta
fill 41 194 342 41 197 342 minecraft:honeycomb_block
setblock 41 194 346 minecraft:yellow_terracotta
fill 41 194 347 41 197 347 minecraft:honeycomb_block
setblock 41 194 350 minecraft:honeycomb_block
setblock 41 194 351 minecraft:yellow_terracotta
fill 41 194 352 41 197 352 minecraft:honeycomb_block
fill 41 194 354 41 195 354 minecraft:honeycomb_block
setblock 41 194 361 minecraft:yellow_terracotta
fill 41 194 362 41 197 362 minecraft:honeycomb_block
fill 0 195 347 0 226 347 minecraft:honeycomb_block
setblock 1 195 325 minecraft:yellow_terracotta
fill 1 195 326 1 198 326 minecraft:honeycomb_block
setblock 1 195 330 minecraft:yellow_terracotta
fill 1 195 331 1 198 331 minecraft:honeycomb_block
setblock 1 195 335 minecraft:yellow_terracotta
fill 1 195 336 1 198 336 minecraft:honeycomb_block
setblock 1 195 340 minecraft:yellow_terracotta
fill 1 195 341 1 198 341 minecraft:honeycomb_block
setblock 1 195 345 minecraft:yellow_terracotta
fill 1 195 346 1 198 346 minecraft:honeycomb_block
setblock 1 195 349 minecraft:honeycomb_block
setblock 1 195 350 minecraft:yellow_terracotta
fill 1 195 351 1 195 354 minecraft:honeycomb_block
setblock 1 195 355 minecraft:yellow_terracotta
fill 1 195 356 1 197 356 minecraft:honeycomb_block
setblock 1 195 360 minecraft:yellow_terracotta
fill 1 195 361 1 198 361 minecraft:honeycomb_block
setblock 2 195 324 minecraft:yellow_terracotta
fill 2 195 325 2 198 325 minecraft:honeycomb_block
setblock 2 195 329 minecraft:yellow_terracotta
fill 2 195 330 2 198 330 minecraft:honeycomb_block
setblock 2 195 334 minecraft:yellow_terracotta
fill 2 195 335 2 196 335 minecraft:honeycomb_block
setblock 2 195 339 minecraft:yellow_terracotta
fill 2 195 340 2 196 340 minecraft:honeycomb_block
setblock 2 195 344 minecraft:yellow_terracotta
fill 2 195 345 2 198 345 minecraft:honeycomb_block
setblock 2 195 349 minecraft:yellow_terracotta
fill 2 195 350 2 198 350 minecraft:honeycomb_block
fill 2 195 351 2 203 351 minecraft:yellow_terracotta
setblock 2 195 359 minecraft:yellow_terracotta
fill 2 195 360 2 196 360 minecraft:honeycomb_block
setblock 3 195 323 minecraft:yellow_terracotta
fill 3 195 324 3 198 324 minecraft:honeycomb_block
setblock 3 195 327 minecraft:honeycomb_block
setblock 3 195 328 minecraft:yellow_terracotta
fill 3 195 329 3 198 329 minecraft:honeycomb_block
setblock 3 195 332 minecraft:light[level=12]
setblock 3 195 339 minecraft:light[level=12]
setblock 3 195 343 minecraft:yellow_terracotta
setblock 3 195 344 minecraft:honeycomb_block
setblock 3 195 353 minecraft:light[level=12]
setblock 3 195 360 minecraft:light[level=12]
setblock 3 195 363 minecraft:yellow_terracotta
fill 4 195 323 4 198 323 minecraft:honeycomb_block
setblock 4 195 327 minecraft:yellow_terracotta
setblock 4 195 328 minecraft:honeycomb_block
setblock 4 195 362 minecraft:yellow_terracotta
fill 4 195 363 7 195 363 minecraft:honeycomb_block
setblock 5 195 326 minecraft:yellow_terracotta
setblock 5 195 361 minecraft:yellow_terracotta
fill 5 195 362 5 197 362 minecraft:honeycomb_block
setblock 6 195 325 minecraft:yellow_terracotta
setblock 6 195 326 minecraft:honeycomb_block
setblock 7 195 324 minecraft:yellow_terracotta
fill 7 195 325 7 197 325 minecraft:honeycomb_block
setblock 8 195 323 minecraft:yellow_terracotta
fill 8 195 324 8 198 324 minecraft:honeycomb_block
setblock 8 195 363 minecraft:yellow_terracotta
fill 9 195 323 9 198 323 minecraft:honeycomb_block
setblock 9 195 362 minecraft:yellow_terracotta
fill 9 195 363 9 198 363 minecraft:honeycomb_block
setblock 10 195 325 minecraft:light[level=12]
setblock 10 195 332 minecraft:light[level=12]
setblock 10 195 339 minecraft:light[level=12]
setblock 10 195 346 minecraft:light[level=12]
setblock 10 195 353 minecraft:light[level=12]
setblock 10 195 360 minecraft:light[level=12]
setblock 10 195 362 minecraft:honeycomb_block
setblock 12 195 324 minecraft:yellow_terracotta
setblock 13 195 323 minecraft:yellow_terracotta
fill 13 195 324 16 195 324 minecraft:honeycomb_block
setblock 13 195 363 minecraft:yellow_terracotta
fill 14 195 323 14 198 323 minecraft:honeycomb_block
setblock 14 195 362 minecraft:yellow_terracotta
fill 14 195 363 14 198 363 minecraft:honeycomb_block
fill 15 195 362 15 196 362 minecraft:honeycomb_block
setblock 17 195 324 minecraft:yellow_terracotta
setblock 17 195 325 minecraft:light[level=12]
setblock 17 195 332 minecraft:light[level=12]
setblock 17 195 339 minecraft:light[level=12]
setblock 17 195 346 minecraft:light[level=12]
setblock 17 195 353 minecraft:light[level=12]
setblock 17 195 360 minecraft:light[level=12]
setblock 18 195 323 minecraft:yellow_terracotta
fill 18 195 324 21 195 324 minecraft:honeycomb_block
setblock 18 195 363 minecraft:yellow_terracotta
fill 19 195 323 19 198 323 minecraft:honeycomb_block
setblock 19 195 362 minecraft:yellow_terracotta
fill 19 195 363 19 198 363 minecraft:honeycomb_block
setblock 20 195 361 minecraft:yellow_terracotta
fill 20 195 362 20 198 362 minecraft:honeycomb_block
setblock 21 195 325 minecraft:yellow_terracotta
fill 21 195 361 21 196 361 minecraft:honeycomb_block
setblock 22 195 324 minecraft:yellow_terracotta
setblock 22 195 325 minecraft:honeycomb_block
setblock 23 195 323 minecraft:yellow_terracotta
fill 23 195 324 23 198 324 minecraft:honeycomb_block
setblock 23 195 363 minecraft:yellow_terracotta
fill 24 195 323 24 198 323 minecraft:honeycomb_block
setblock 24 195 325 minecraft:light[level=12]
fill 24 195 326 24 195 328 minecraft:yellow_terracotta
setblock 24 195 332 minecraft:light[level=12]
setblock 24 195 339 minecraft:light[level=12]
setblock 24 195 346 minecraft:light[level=12]
setblock 24 195 353 minecraft:light[level=12]
fill 24 195 357 26 196 357 minecraft:yellow_terracotta
setblock 24 195 360 minecraft:light[level=12]
setblock 24 195 362 minecraft:yellow_terracotta
fill 24 195 363 24 198 363 minecraft:honeycomb_block
fill 25 195 328 25 197 329 minecraft:yellow_terracotta
fill 25 195 356 25 197 356 minecraft:yellow_terracotta
setblock 25 195 361 minecraft:honey_block
fill 25 195 362 25 196 362 minecraft:honeycomb_block
fill 26 195 328 26 196 328 minecraft:yellow_terracotta
setblock 27 195 324 minecraft:yellow_terracotta
fill 27 195 326 27 196 326 minecraft:brown_terracotta
fill 27 195 328 27 196 328 minecraft:brown_terracotta
setblock 28 195 323 minecraft:yellow_terracotta
setblock 28 195 363 minecraft:yellow_terracotta
setblock 28 195 364 minecraft:orange_terracotta
fill 29 195 323 29 196 323 minecraft:honeycomb_block
setblock 29 195 363 minecraft:honeycomb_block
setblock 31 195 325 minecraft:light[level=12]
setblock 31 195 332 minecraft:light[level=12]
setblock 31 195 339 minecraft:light[level=12]
setblock 31 195 346 minecraft:light[level=12]
setblock 31 195 353 minecraft:light[level=12]
setblock 31 195 360 minecraft:light[level=12]
setblock 33 195 323 minecraft:yellow_terracotta
fill 34 195 323 34 197 323 minecraft:honeycomb_block
setblock 36 195 324 minecraft:honeycomb_block
setblock 37 195 324 minecraft:yellow_terracotta
setblock 38 195 323 minecraft:yellow_terracotta
fill 38 195 324 40 195 325 minecraft:honeycomb_block
setblock 38 195 332 minecraft:light[level=12]
setblock 38 195 339 minecraft:light[level=12]
setblock 38 195 346 minecraft:light[level=12]
setblock 38 195 353 minecraft:light[level=12]
setblock 38 195 360 minecraft:light[level=12]
setblock 38 195 363 minecraft:yellow_terracotta
fill 39 195 323 39 198 323 minecraft:honeycomb_block
setblock 39 195 326 minecraft:honeycomb_block
setblock 39 195 327 minecraft:yellow_terracotta
fill 39 195 328 40 197 328 minecraft:honeycomb_block
setblock 39 195 338 minecraft:honeycomb_block
setblock 39 195 342 minecraft:yellow_terracotta
fill 39 195 343 39 198 343 minecraft:honeycomb_block
setblock 39 195 347 minecraft:yellow_terracotta
fill 39 195 348 39 198 348 minecraft:honeycomb_block
fill 39 195 363 39 198 363 minecraft:honeycomb_block
setblock 40 195 326 minecraft:yellow_terracotta
fill 40 195 327 40 198 327 minecraft:honeycomb_block
fill 40 195 329 40 195 330 minecraft:honeycomb_block
setblock 40 195 331 minecraft:yellow_terracotta
fill 40 195 332 40 198 332 minecraft:honeycomb_block
setblock 40 195 336 minecraft:yellow_terracotta
fill 40 195 337 40 198 337 minecraft:honeycomb_block
setblock 40 195 341 minecraft:yellow_terracotta
fill 40 195 342 40 198 342 minecraft:honeycomb_block
setblock 40 195 346 minecraft:yellow_terracotta
fill 40 195 347 40 198 347 minecraft:honeycomb_block
setblock 40 195 351 minecraft:yellow_terracotta
setblock 41 195 324 minecraft:honeycomb_block
setblock 41 195 325 minecraft:yellow_terracotta
fill 41 195 326 41 198 326 minecraft:honeycomb_block
setblock 41 195 330 minecraft:yellow_terracotta
fill 41 195 331 41 198 331 minecraft:honeycomb_block
setblock 41 195 335 minecraft:yellow_terracotta
fill 41 195 336 41 198 336 minecraft:honeycomb_block
setblock 41 195 340 minecraft:yellow_terracotta
fill 41 195 341 41 198 341 minecraft:honeycomb_block
setblock 41 195 345 minecraft:yellow_terracotta
fill 41 195 346 41 198 346 minecraft:honeycomb_block
setblock 41 195 350 minecraft:yellow_terracotta
fill 41 195 351 41 198 351 minecraft:honeycomb_block
setblock 41 195 360 minecraft:yellow_terracotta
fill 41 195 361 41 197 361 minecraft:honeycomb_block
setblock 42 195 363 minecraft:yellow_concrete
setblock 1 196 324 minecraft:yellow_terracotta
fill 1 196 325 1 199 325 minecraft:honeycomb_block
setblock 1 196 329 minecraft:yellow_terracotta
fill 1 196 330 1 199 330 minecraft:honeycomb_block
setblock 1 196 334 minecraft:yellow_terracotta
fill 1 196 335 1 199 335 minecraft:honeycomb_block
setblock 1 196 339 minecraft:yellow_terracotta
fill 1 196 340 1 198 340 minecraft:honeycomb_block
setblock 1 196 344 minecraft:yellow_terracotta
fill 1 196 345 1 199 345 minecraft:honeycomb_block
setblock 1 196 349 minecraft:yellow_terracotta
fill 1 196 350 1 196 353 minecraft:honeycomb_block
setblock 1 196 354 minecraft:yellow_terracotta
fill 1 196 355 1 199 355 minecraft:honeycomb_block
setblock 1 196 359 minecraft:yellow_terracotta
fill 1 196 360 1 199 360 minecraft:honeycomb_block
setblock 2 196 323 minecraft:yellow_terracotta
fill 2 196 324 2 199 324 minecraft:honeycomb_block
setblock 2 196 328 minecraft:yellow_terracotta
fill 2 196 329 2 199 329 minecraft:honeycomb_block
setblock 2 196 333 minecraft:yellow_terracotta
setblock 2 196 334 minecraft:honeycomb_block
setblock 2 196 338 minecraft:yellow_terracotta
setblock 2 196 339 minecraft:honeycomb_block
setblock 2 196 343 minecraft:yellow_terracotta
fill 2 196 344 2 198 344 minecraft:honeycomb_block
setblock 2 196 348 minecraft:yellow_terracotta
fill 2 196 349 2 199 349 minecraft:honeycomb_block
setblock 2 196 363 minecraft:yellow_terracotta
fill 3 196 323 3 199 323 minecraft:honeycomb_block
setblock 3 196 327 minecraft:yellow_terracotta
fill 3 196 328 3 199 328 minecraft:honeycomb_block
setblock 3 196 362 minecraft:yellow_terracotta
fill 3 196 363 6 196 363 minecraft:honeycomb_block
setblock 4 196 326 minecraft:yellow_terracotta
setblock 4 196 327 minecraft:honeycomb_block
fill 4 196 362 4 198 362 minecraft:honeycomb_block
setblock 5 196 325 minecraft:yellow_terracotta
setblock 5 196 326 minecraft:honeycomb_block
setblock 6 196 324 minecraft:yellow_terracotta
fill 6 196 325 6 198 325 minecraft:honeycomb_block
setblock 7 196 323 minecraft:yellow_terracotta
fill 7 196 324 7 199 324 minecraft:honeycomb_block
setblock 7 196 363 minecraft:yellow_terracotta
fill 8 196 323 8 199 323 minecraft:honeycomb_block
setblock 8 196 325 minecraft:honeycomb_block
setblock 8 196 362 minecraft:yellow_terracotta
fill 8 196 363 8 199 363 minecraft:honeycomb_block
setblock 9 196 362 minecraft:honeycomb_block
setblock 9 196 364 minecraft:orange_terracotta
setblock 11 196 324 minecraft:yellow_terracotta
setblock 12 196 323 minecraft:yellow_terracotta
fill 12 196 324 15 196 324 minecraft:honeycomb_block
setblock 12 196 363 minecraft:yellow_terracotta
fill 13 196 323 13 199 323 minecraft:honeycomb_block
fill 13 196 363 13 199 363 minecraft:honeycomb_block
setblock 14 196 362 minecraft:honeycomb_block
setblock 15 196 364 minecraft:yellow_terracotta
setblock 16 196 324 minecraft:yellow_terracotta
setblock 17 196 323 minecraft:yellow_terracotta
fill 17 196 324 20 196 324 minecraft:honeycomb_block
setblock 17 196 363 minecraft:yellow_terracotta
fill 18 196 323 18 199 323 minecraft:honeycomb_block
setblock 18 196 362 minecraft:yellow_terracotta
fill 18 196 363 18 199 363 minecraft:honeycomb_block
setblock 19 196 361 minecraft:yellow_terracotta
fill 19 196 362 19 199 362 minecraft:honeycomb_block
setblock 19 196 364 minecraft:yellow_concrete
setblock 20 196 361 minecraft:honeycomb_block
setblock 21 196 324 minecraft:yellow_terracotta
setblock 21 196 325 minecraft:honeycomb_block
setblock 22 196 323 minecraft:yellow_terracotta
fill 22 196 324 22 198 324 minecraft:honeycomb_block
setblock 22 196 363 minecraft:yellow_terracotta
fill 23 196 323 23 199 323 minecraft:honeycomb_block
setblock 23 196 362 minecraft:yellow_terracotta
fill 23 196 363 23 199 363 minecraft:honeycomb_block
fill 24 196 328 24 196 329 minecraft:yellow_terracotta
fill 24 196 356 24 197 356 minecraft:yellow_terracotta
fill 24 196 362 24 197 362 minecraft:honeycomb_block
setblock 25 196 326 minecraft:honey_block
setblock 25 196 327 minecraft:yellow_terracotta
fill 25 196 330 25 198 330 minecraft:yellow_terracotta
fill 25 196 355 25 198 355 minecraft:yellow_terracotta
setblock 25 196 358 minecraft:yellow_terracotta
setblock 25 196 359 minecraft:honey_block
setblock 26 196 324 minecraft:yellow_terracotta
fill 26 196 326 26 196 327 minecraft:brown_terracotta
fill 26 196 329 26 197 329 minecraft:yellow_terracotta
fill 26 196 356 26 197 356 minecraft:yellow_terracotta
fill 26 196 361 26 202 361 minecraft:brown_terracotta
fill 27 196 322 27 196 323 minecraft:yellow_terracotta
setblock 27 196 363 minecraft:yellow_terracotta
setblock 28 196 323 minecraft:honeycomb_block
fill 28 196 363 28 196 364 minecraft:honeycomb_block
setblock 32 196 363 minecraft:honey_block
setblock 36 196 324 minecraft:yellow_terracotta
setblock 37 196 323 minecraft:yellow_terracotta
fill 37 196 324 40 196 324 minecraft:honeycomb_block
setblock 37 196 363 minecraft:yellow_terracotta
fill 38 196 323 38 199 323 minecraft:honeycomb_block
fill 38 196 325 39 196 325 minecraft:honeycomb_block
fill 38 196 363 38 197 363 minecraft:honeycomb_block
setblock 39 196 326 minecraft:yellow_terracotta
fill 39 196 327 39 199 327 minecraft:honeycomb_block
fill 39 196 329 39 196 330 minecraft:honeycomb_block
setblock 39 196 341 minecraft:yellow_terracotta
fill 39 196 342 39 197 342 minecraft:honeycomb_block
setblock 39 196 346 minecraft:yellow_terracotta
fill 39 196 347 39 199 347 minecraft:honeycomb_block
setblock 40 196 325 minecraft:yellow_terracotta
fill 40 196 326 40 199 326 minecraft:honeycomb_block
setblock 40 196 329 minecraft:honeycomb_block
setblock 40 196 330 minecraft:yellow_terracotta
fill 40 196 331 40 199 331 minecraft:honeycomb_block
setblock 40 196 335 minecraft:yellow_terracotta
fill 40 196 336 40 199 336 minecraft:honeycomb_block
setblock 40 196 340 minecraft:yellow_terracotta
fill 40 196 341 40 199 341 minecraft:honeycomb_block
setblock 40 196 345 minecraft:yellow_terracotta
fill 40 196 346 40 199 346 minecraft:honeycomb_block
setblock 40 196 349 minecraft:honeycomb_block
setblock 40 196 350 minecraft:yellow_terracotta
fill 40 196 351 40 199 351 minecraft:honeycomb_block
setblock 41 196 324 minecraft:yellow_terracotta
fill 41 196 325 41 199 325 minecraft:honeycomb_block
setblock 41 196 329 minecraft:yellow_terracotta
fill 41 196 330 41 199 330 minecraft:honeycomb_block
setblock 41 196 334 minecraft:yellow_terracotta
fill 41 196 335 41 199 335 minecraft:honeycomb_block
setblock 41 196 339 minecraft:yellow_terracotta
fill 41 196 340 41 199 340 minecraft:honeycomb_block
setblock 41 196 344 minecraft:yellow_terracotta
fill 41 196 345 41 199 345 minecraft:honeycomb_block
setblock 41 196 349 minecraft:yellow_terracotta
fill 41 196 350 41 199 350 minecraft:honeycomb_block
setblock 41 196 354 minecraft:yellow_terracotta
setblock 41 196 355 minecraft:honey_block
setblock 41 196 360 minecraft:honeycomb_block
fill 42 196 363 42 308 363 minecraft:honeycomb_block
setblock 1 197 323 minecraft:yellow_terracotta
fill 1 197 324 1 200 324 minecraft:honeycomb_block
setblock 1 197 328 minecraft:yellow_terracotta
fill 1 197 329 1 200 329 minecraft:honeycomb_block
setblock 1 197 333 minecraft:yellow_terracotta
fill 1 197 334 1 200 334 minecraft:honeycomb_block
setblock 1 197 338 minecraft:yellow_terracotta
fill 1 197 339 1 198 339 minecraft:honeycomb_block
setblock 1 197 343 minecraft:yellow_terracotta
fill 1 197 344 1 200 344 minecraft:honeycomb_block
setblock 1 197 348 minecraft:yellow_terracotta
fill 1 197 349 1 197 352 minecraft:honeycomb_block
setblock 1 197 353 minecraft:yellow_terracotta
fill 1 197 354 1 200 354 minecraft:honeycomb_block
setblock 1 197 358 minecraft:yellow_terracotta
fill 1 197 359 1 199 359 minecraft:honeycomb_block
setblock 1 197 363 minecraft:yellow_terracotta
fill 2 197 323 2 200 323 minecraft:honeycomb_block
setblock 2 197 327 minecraft:yellow_terracotta
fill 2 197 328 2 200 328 minecraft:honeycomb_block
setblock 2 197 332 minecraft:yellow_terracotta
fill 2 197 333 2 198 333 minecraft:honeycomb_block
setblock 2 197 342 minecraft:yellow_terracotta
setblock 2 197 343 minecraft:honeycomb_block
setblock 2 197 347 minecraft:yellow_terracotta
fill 2 197 348 2 199 348 minecraft:honeycomb_block
setblock 2 197 362 minecraft:yellow_terracotta
fill 2 197 363 5 197 363 minecraft:honeycomb_block
setblock 3 197 326 minecraft:yellow_terracotta
fill 3 197 327 3 200 327 minecraft:honeycomb_block
fill 3 197 362 3 198 362 minecraft:honeycomb_block
setblock 4 197 325 minecraft:yellow_terracotta
setblock 4 197 326 minecraft:honeycomb_block
setblock 5 197 324 minecraft:yellow_terracotta
fill 5 197 325 5 199 325 minecraft:honeycomb_block
setblock 6 197 323 minecraft:yellow_terracotta
fill 6 197 324 6 200 324 minecraft:honeycomb_block
setblock 6 197 363 minecraft:yellow_terracotta
fill 7 197 323 7 200 323 minecraft:honeycomb_block
fill 7 197 363 7 199 363 minecraft:honeycomb_block
fill 9 197 364 9 308 364 minecraft:honeycomb_block
setblock 10 197 324 minecraft:yellow_terracotta
setblock 11 197 323 minecraft:yellow_terracotta
setblock 11 197 363 minecraft:yellow_terracotta
fill 12 197 323 12 199 323 minecraft:honeycomb_block
fill 12 197 363 12 198 363 minecraft:honeycomb_block
setblock 15 197 324 minecraft:yellow_terracotta
fill 15 197 364 15 251 364 minecraft:honeycomb_block
setblock 16 197 323 minecraft:yellow_terracotta
fill 16 197 324 19 197 324 minecraft:honeycomb_block
setblock 16 197 363 minecraft:yellow_terracotta
fill 17 197 323 17 200 323 minecraft:honeycomb_block
setblock 17 197 362 minecraft:yellow_terracotta
fill 17 197 363 17 200 363 minecraft:honeycomb_block
fill 18 197 362 18 198 362 minecraft:honeycomb_block
fill 19 197 364 19 272 364 minecraft:honeycomb_block
setblock 20 197 324 minecraft:yellow_terracotta
setblock 21 197 323 minecraft:yellow_terracotta
fill 21 197 324 21 199 324 minecraft:honeycomb_block
setblock 21 197 363 minecraft:yellow_terracotta
fill 22 197 323 22 200 323 minecraft:honeycomb_block
setblock 22 197 362 minecraft:yellow_terracotta
fill 22 197 363 22 200 363 minecraft:honeycomb_block
setblock 23 197 362 minecraft:honeycomb_block
fill 24 197 329 24 197 331 minecraft:yellow_terracotta
fill 24 197 354 24 197 355 minecraft:yellow_terracotta
setblock 25 197 324 minecraft:yellow_terracotta
setblock 25 197 327 minecraft:honey_block
fill 25 197 331 25 199 332 minecraft:yellow_terracotta
fill 25 197 353 25 199 354 minecraft:yellow_terracotta
setblock 25 197 357 minecraft:yellow_terracotta
setblock 25 197 358 minecraft:honey_block
setblock 26 197 323 minecraft:yellow_terracotta
fill 26 197 330 26 197 331 minecraft:yellow_terracotta
fill 26 197 354 26 197 355 minecraft:yellow_terracotta
setblock 26 197 363 minecraft:yellow_terracotta
fill 27 197 322 27 197 323 minecraft:honeycomb_block
fill 28 197 364 28 264 364 minecraft:honeycomb_block
setblock 36 197 323 minecraft:yellow_terracotta
fill 36 197 324 39 197 324 minecraft:honeycomb_block
fill 37 197 323 37 200 323 minecraft:honeycomb_block
setblock 38 197 325 minecraft:honeycomb_block
setblock 39 197 325 minecraft:yellow_terracotta
fill 39 197 326 39 200 326 minecraft:honeycomb_block
setblock 39 197 329 minecraft:honeycomb_block
setblock 39 197 330 minecraft:yellow_terracotta
fill 39 197 331 39 200 331 minecraft:honeycomb_block
setblock 39 197 341 minecraft:honeycomb_block
setblock 39 197 345 minecraft:yellow_terracotta
fill 39 197 346 39 199 346 minecraft:honeycomb_block
setblock 40 197 323 minecraft:honeycomb_block
setblock 40 197 324 minecraft:yellow_terracotta
fill 40 197 325 40 200 325 minecraft:honeycomb_block
setblock 40 197 329 minecraft:yellow_terracotta
fill 40 197 330 40 200 330 minecraft:honeycomb_block
setblock 40 197 334 minecraft:yellow_terracotta
fill 40 197 335 40 200 335 minecraft:honeycomb_block
setblock 40 197 339 minecraft:yellow_terracotta
fill 40 197 340 40 199 340 minecraft:honeycomb_block
setblock 40 197 344 minecraft:yellow_terracotta
fill 40 197 345 40 200 345 minecraft:honeycomb_block
setblock 40 197 349 minecraft:yellow_terracotta
fill 40 197 350 40 200 350 minecraft:honeycomb_block
setblock 41 197 323 minecraft:yellow_terracotta
fill 41 197 324 41 200 324 minecraft:honeycomb_block
setblock 41 197 328 minecraft:yellow_terracotta
fill 41 197 329 41 200 329 minecraft:honeycomb_block
setblock 41 197 333 minecraft:yellow_terracotta
fill 41 197 334 41 200 334 minecraft:honeycomb_block
setblock 41 197 338 minecraft:yellow_terracotta
fill 41 197 339 41 200 339 minecraft:honeycomb_block
setblock 41 197 343 minecraft:yellow_terracotta
fill 41 197 344 41 200 344 minecraft:honeycomb_block
setblock 41 197 348 minecraft:yellow_terracotta
fill 41 197 349 41 200 349 minecraft:honeycomb_block
setblock 41 197 353 minecraft:yellow_terracotta
setblock 41 197 354 minecraft:honeycomb_block
setblock 41 197 363 minecraft:yellow_terracotta
setblock 0 198 344 minecraft:yellow_concrete
fill 1 198 323 1 201 323 minecraft:honeycomb_block
setblock 1 198 327 minecraft:yellow_terracotta
fill 1 198 328 1 201 328 minecraft:honeycomb_block
setblock 1 198 332 minecraft:yellow_terracotta
fill 1 198 333 1 201 333 minecraft:honeycomb_block
setblock 1 198 337 minecraft:yellow_terracotta
setblock 1 198 338 minecraft:honeycomb_block
setblock 1 198 342 minecraft:yellow_terracotta
fill 1 198 343 1 200 343 minecraft:honeycomb_block
setblock 1 198 347 minecraft:yellow_terracotta
fill 1 198 348 1 198 351 minecraft:honeycomb_block
setblock 1 198 352 minecraft:yellow_terracotta
fill 1 198 353 1 201 353 minecraft:honeycomb_block
setblock 1 198 358 minecraft:honeycomb_block
setblock 1 198 362 minecraft:yellow_terracotta
fill 1 198 363 4 198 363 minecraft:honeycomb_block
setblock 2 198 326 minecraft:yellow_terracotta
fill 2 198 327 2 201 327 minecraft:honeycomb_block
setblock 2 198 331 minecraft:yellow_terracotta
fill 2 198 332 2 201 332 minecraft:honeycomb_block
setblock 2 198 346 minecraft:yellow_terracotta
fill 2 198 347 2 199 347 minecraft:honeycomb_block
setblock 2 198 362 minecraft:honeycomb_block
setblock 3 198 325 minecraft:yellow_terracotta
fill 3 198 326 3 201 326 minecraft:honeycomb_block
setblock 4 198 324 minecraft:yellow_terracotta
fill 4 198 325 4 200 325 minecraft:honeycomb_block
setblock 5 198 323 minecraft:yellow_terracotta
fill 5 198 324 5 201 324 minecraft:honeycomb_block
setblock 5 198 363 minecraft:yellow_terracotta
fill 6 198 323 6 201 323 minecraft:honeycomb_block
fill 6 198 363 6 200 363 minecraft:honeycomb_block
setblock 10 198 323 minecraft:yellow_terracotta
setblock 10 198 363 minecraft:yellow_terracotta
fill 11 198 323 11 199 323 minecraft:honeycomb_block
setblock 11 198 363 minecraft:honeycomb_block
setblock 15 198 323 minecraft:yellow_terracotta
setblock 15 198 363 minecraft:yellow_terracotta
fill 16 198 323 16 198 324 minecraft:honeycomb_block
fill 16 198 363 16 201 363 minecraft:honeycomb_block
fill 17 198 324 18 198 324 minecraft:honeycomb_block
setblock 17 198 362 minecraft:honeycomb_block
setblock 19 198 324 minecraft:yellow_terracotta
setblock 20 198 323 minecraft:yellow_terracotta
fill 20 198 324 20 199 324 minecraft:honeycomb_block
setblock 20 198 363 minecraft:yellow_terracotta
fill 21 198 323 21 201 323 minecraft:honeycomb_block
setblock 21 198 362 minecraft:yellow_terracotta
fill 21 198 363 21 201 363 minecraft:honeycomb_block
setblock 22 198 362 minecraft:honeycomb_block
fill 24 198 331 24 198 333 minecraft:yellow_terracotta
fill 24 198 352 24 198 354 minecraft:yellow_terracotta
setblock 24 198 364 minecraft:orange_terracotta
setblock 25 198 323 minecraft:yellow_terracotta
setblock 25 198 329 minecraft:honey_block
fill 25 198 333 25 199 334 minecraft:yellow_terracotta
fill 25 198 351 25 200 352 minecraft:yellow_terracotta
setblock 25 198 356 minecraft:honey_block
setblock 25 198 363 minecraft:yellow_terracotta
setblock 26 198 323 minecraft:honeycomb_block
fill 26 198 331 26 198 333 minecraft:yellow_terracotta
fill 26 198 352 26 198 354 minecraft:yellow_terracotta
fill 27 198 322 27 308 322 minecraft:honeycomb_block
setblock 35 198 323 minecraft:yellow_terracotta
fill 36 198 323 36 200 324 minecraft:honeycomb_block
fill 37 198 324 38 198 324 minecraft:honeycomb_block
setblock 38 198 325 minecraft:yellow_terracotta
setblock 39 198 324 minecraft:yellow_terracotta
fill 39 198 325 39 201 325 minecraft:honeycomb_block
setblock 39 198 328 minecraft:honeycomb_block
setblock 39 198 329 minecraft:yellow_terracotta
fill 39 198 330 39 201 330 minecraft:honeycomb_block
setblock 39 198 344 minecraft:yellow_terracotta
setblock 39 198 345 minecraft:honeycomb_block
setblock 40 198 323 minecraft:yellow_terracotta
fill 40 198 324 40 201 324 minecraft:honeycomb_block
setblock 40 198 328 minecraft:yellow_terracotta
fill 40 198 329 40 201 329 minecraft:honeycomb_block
setblock 40 198 333 minecraft:yellow_terracotta
fill 40 198 334 40 201 334 minecraft:honeycomb_block
setblock 40 198 338 minecraft:yellow_terracotta
fill 40 198 339 40 199 339 minecraft:honeycomb_block
setblock 40 198 343 minecraft:yellow_terracotta
fill 40 198 344 40 201 344 minecraft:honeycomb_block
setblock 40 198 348 minecraft:yellow_terracotta
fill 40 198 349 40 201 349 minecraft:honeycomb_block
setblock 40 198 363 minecraft:yellow_terracotta
fill 41 198 323 41 201 323 minecraft:honeycomb_block
setblock 41 198 327 minecraft:yellow_terracotta
fill 41 198 328 41 201 328 minecraft:honeycomb_block
setblock 41 198 332 minecraft:yellow_terracotta
fill 41 198 333 41 201 333 minecraft:honeycomb_block
setblock 41 198 337 minecraft:yellow_terracotta
fill 41 198 338 41 201 338 minecraft:honeycomb_block
setblock 41 198 342 minecraft:yellow_terracotta
fill 41 198 343 41 201 343 minecraft:honeycomb_block
setblock 41 198 347 minecraft:yellow_terracotta
fill 41 198 348 41 201 348 minecraft:honeycomb_block
setblock 41 198 352 minecraft:yellow_terracotta
fill 41 198 353 41 201 353 minecraft:honeycomb_block
setblock 41 198 362 minecraft:yellow_terracotta
fill 41 198 363 41 200 363 minecraft:honeycomb_block
setblock 42 198 341 minecraft:orange_terracotta
fill 0 199 344 0 308 344 minecraft:honeycomb_block
setblock 1 199 326 minecraft:yellow_terracotta
fill 1 199 327 1 202 327 minecraft:honeycomb_block
setblock 1 199 331 minecraft:yellow_terracotta
fill 1 199 332 1 202 332 minecraft:honeycomb_block
setblock 1 199 336 minecraft:yellow_terracotta
setblock 1 199 341 minecraft:yellow_terracotta
setblock 1 199 342 minecraft:honeycomb_block
setblock 1 199 346 minecraft:yellow_terracotta
fill 1 199 347 1 199 350 minecraft:honeycomb_block
setblock 1 199 351 minecraft:yellow_terracotta
fill 1 199 352 1 202 352 minecraft:honeycomb_block
setblock 1 199 361 minecraft:yellow_terracotta
fill 1 199 362 1 201 363 minecraft:honeycomb_block
setblock 1 199 364 minecraft:orange_terracotta
setblock 2 199 325 minecraft:yellow_terracotta
fill 2 199 326 2 202 326 minecraft:honeycomb_block
setblock 2 199 330 minecraft:yellow_terracotta
fill 2 199 331 2 202 331 minecraft:honeycomb_block
fill 2 199 350 2 202 350 minecraft:yellow_terracotta
fill 2 199 352 2 202 352 minecraft:yellow_terracotta
fill 2 199 363 3 199 363 minecraft:honeycomb_block
setblock 3 199 324 minecraft:yellow_terracotta
fill 3 199 325 3 201 325 minecraft:honeycomb_block
setblock 3 199 329 minecraft:yellow_terracotta
setblock 3 199 333 minecraft:light[level=15]
setblock 3 199 341 minecraft:light[level=15]
setblock 3 199 349 minecraft:light[level=15]
fill 3 199 351 3 202 351 minecraft:yellow_terracotta
setblock 3 199 357 minecraft:light[level=15]
setblock 4 199 323 minecraft:yellow_terracotta
fill 4 199 324 4 202 324 minecraft:honeycomb_block
setblock 4 199 363 minecraft:yellow_terracotta
fill 5 199 323 5 202 323 minecraft:honeycomb_block
fill 5 199 363 5 200 363 minecraft:honeycomb_block
setblock 9 199 323 minecraft:yellow_terracotta
setblock 10 199 323 minecraft:honeycomb_block
setblock 11 199 325 minecraft:light[level=15]
setblock 11 199 333 minecraft:light[level=15]
setblock 11 199 341 minecraft:light[level=15]
setblock 11 199 349 minecraft:light[level=15]
setblock 11 199 357 minecraft:light[level=15]
setblock 14 199 323 minecraft:yellow_terracotta
setblock 14 199 363 minecraft:yellow_terracotta
fill 15 199 323 16 201 323 minecraft:honeycomb_block
fill 15 199 363 15 202 363 minecraft:honeycomb_block
setblock 18 199 324 minecraft:yellow_terracotta
setblock 19 199 323 minecraft:yellow_terracotta
setblock 19 199 324 minecraft:honeycomb_block
setblock 19 199 325 minecraft:light[level=15]
setblock 19 199 333 minecraft:light[level=15]
setblock 19 199 341 minecraft:light[level=15]
setblock 19 199 349 minecraft:light[level=15]
setblock 19 199 357 minecraft:light[level=15]
setblock 19 199 363 minecraft:yellow_terracotta
fill 20 199 323 20 202 323 minecraft:honeycomb_block
setblock 20 199 362 minecraft:yellow_terracotta
fill 20 199 363 20 202 363 minecraft:honeycomb_block
setblock 24 199 323 minecraft:yellow_terracotta
fill 24 199 332 24 199 335 minecraft:yellow_terracotta
fill 24 199 350 24 199 353 minecraft:yellow_terracotta
fill 24 199 364 24 207 364 minecraft:honeycomb_block
setblock 25 199 330 minecraft:honey_block
fill 25 199 335 25 201 336 minecraft:yellow_terracotta
fill 25 199 349 25 201 350 minecraft:yellow_terracotta
setblock 25 199 355 minecraft:honey_block
fill 26 199 332 26 199 335 minecraft:yellow_terracotta
fill 26 199 350 26 199 353 minecraft:yellow_terracotta
setblock 27 199 325 minecraft:light[level=15]
setblock 27 199 333 minecraft:light[level=15]
setblock 27 199 341 minecraft:light[level=15]
setblock 27 199 349 minecraft:light[level=15]
setblock 27 199 357 minecraft:light[level=15]
setblock 31 199 363 minecraft:honey_block
setblock 35 199 322 minecraft:yellow_concrete
fill 35 199 323 35 202 323 minecraft:honeycomb_block
setblock 35 199 325 minecraft:light[level=15]
setblock 35 199 333 minecraft:light[level=15]
setblock 35 199 341 minecraft:light[level=15]
setblock 35 199 349 minecraft:light[level=15]
setblock 35 199 357 minecraft:light[level=15]
setblock 37 199 324 minecraft:honeycomb_block
setblock 38 199 322 minecraft:yellow_terracotta
setblock 38 199 324 minecraft:yellow_terracotta
fill 38 199 325 38 202 325 minecraft:honeycomb_block
setblock 39 199 323 minecraft:yellow_terracotta
fill 39 199 324 39 202 324 minecraft:honeycomb_block
setblock 39 199 328 minecraft:yellow_terracotta
fill 39 199 329 39 202 329 minecraft:honeycomb_block
setblock 39 199 332 minecraft:honeycomb_block
fill 39 199 364 39 200 364 minecraft:orange_terracotta
fill 40 199 323 40 202 323 minecraft:honeycomb_block
setblock 40 199 327 minecraft:yellow_terracotta
fill 40 199 328 40 202 328 minecraft:honeycomb_block
setblock 40 199 332 minecraft:yellow_terracotta
fill 40 199 333 40 202 333 minecraft:honeycomb_block
setblock 40 199 337 minecraft:yellow_terracotta
setblock 40 199 338 minecraft:honeycomb_block
setblock 40 199 342 minecraft:yellow_terracotta
fill 40 199 343 40 200 343 minecraft:honeycomb_block
setblock 40 199 347 minecraft:yellow_terracotta
fill 40 199 348 40 202 348 minecraft:honeycomb_block
setblock 40 199 363 minecraft:honeycomb_block
setblock 41 199 326 minecraft:yellow_terracotta
fill 41 199 327 41 202 327 minecraft:honeycomb_block
setblock 41 199 331 minecraft:yellow_terracotta
fill 41 199 332 41 202 332 minecraft:honeycomb_block
setblock 41 199 336 minecraft:yellow_terracotta
fill 41 199 337 41 202 337 minecraft:honeycomb_block
setblock 41 199 341 minecraft:yellow_terracotta
fill 41 199 342 41 202 342 minecraft:honeycomb_block
setblock 41 199 346 minecraft:yellow_terracotta
fill 41 199 347 41 202 347 minecraft:honeycomb_block
setblock 41 199 351 minecraft:yellow_terracotta
fill 41 199 352 41 202 352 minecraft:honeycomb_block
setblock 41 199 362 minecraft:honey_block
fill 42 199 341 42 248 341 minecraft:honeycomb_block
setblock 42 199 354 minecraft:yellow_terracotta
setblock 42 199 362 minecraft:orange_terracotta
setblock 1 200 325 minecraft:yellow_terracotta
fill 1 200 326 1 203 326 minecraft:honeycomb_block
setblock 1 200 330 minecraft:yellow_terracotta
fill 1 200 331 1 203 331 minecraft:honeycomb_block
setblock 1 200 335 minecraft:yellow_terracotta
setblock 1 200 345 minecraft:yellow_terracotta
fill 1 200 346 1 200 349 minecraft:honeycomb_block
setblock 1 200 350 minecraft:yellow_terracotta
fill 1 200 351 1 203 351 minecraft:honeycomb_block
setblock 1 200 355 minecraft:yellow_terracotta
fill 1 200 356 1 203 356 minecraft:honeycomb_block
setblock 1 200 360 minecraft:yellow_terracotta
fill 1 200 361 1 203 361 minecraft:honeycomb_block
fill 1 200 364 1 242 364 minecraft:honeycomb_block
setblock 2 200 324 minecraft:yellow_terracotta
fill 2 200 325 2 203 325 minecraft:honeycomb_block
setblock 2 200 329 minecraft:yellow_terracotta
fill 2 200 330 2 203 330 minecraft:honeycomb_block
setblock 2 200 363 minecraft:honeycomb_block
setblock 3 200 323 minecraft:yellow_terracotta
fill 3 200 324 3 203 324 minecraft:honeycomb_block
setblock 3 200 328 minecraft:yellow_terracotta
fill 3 200 350 3 202 350 minecraft:yellow_terracotta
fill 3 200 352 3 202 352 minecraft:yellow_terracotta
setblock 3 200 363 minecraft:yellow_terracotta
fill 4 200 323 4 203 323 minecraft:honeycomb_block
fill 4 200 363 4 202 363 minecraft:honeycomb_block
setblock 8 200 323 minecraft:yellow_terracotta
setblock 12 200 363 minecraft:honey_block
setblock 12 200 364 minecraft:yellow_concrete
setblock 14 200 323 minecraft:honeycomb_block
fill 14 200 363 14 203 363 minecraft:honeycomb_block
setblock 18 200 323 minecraft:yellow_terracotta
setblock 18 200 363 minecraft:yellow_terracotta
fill 19 200 323 19 203 323 minecraft:honeycomb_block
fill 19 200 363 19 203 363 minecraft:honeycomb_block
setblock 22 200 364 minecraft:yellow_concrete
setblock 23 200 323 minecraft:yellow_terracotta
fill 24 200 329 24 201 329 minecraft:black_concrete
fill 24 200 334 24 200 337 minecraft:yellow_terracotta
fill 24 200 348 24 200 351 minecraft:yellow_terracotta
fill 25 200 329 25 201 329 minecraft:yellow_concrete
fill 25 200 332 25 200 333 minecraft:honey_block
fill 25 200 334 26 200 334 minecraft:yellow_terracotta
fill 25 200 337 26 201 337 minecraft:yellow_terracotta
fill 25 200 345 25 201 348 minecraft:yellow_terracotta
setblock 25 200 353 minecraft:honey_block
fill 25 200 361 25 202 361 minecraft:brown_terracotta
fill 26 200 335 26 200 336 minecraft:yellow_terracotta
fill 26 200 348 26 200 351 minecraft:yellow_terracotta
fill 26 200 360 26 202 360 minecraft:brown_terracotta
fill 26 200 362 26 202 362 minecraft:brown_terracotta
fill 27 200 361 27 202 361 minecraft:brown_terracotta
setblock 30 200 323 minecraft:honey_block
fill 35 200 322 35 219 322 minecraft:honeycomb_block
setblock 37 200 324 minecraft:yellow_terracotta
setblock 37 200 363 minecraft:honey_block
setblock 37 200 364 minecraft:orange_terracotta
fill 38 200 322 38 222 322 minecraft:honeycomb_block
setblock 38 200 323 minecraft:yellow_terracotta
fill 38 200 324 38 203 324 minecraft:honeycomb_block
fill 39 200 323 39 203 323 minecraft:honeycomb_block
setblock 39 200 327 minecraft:yellow_terracotta
fill 39 200 328 39 203 328 minecraft:honeycomb_block
setblock 39 200 332 minecraft:yellow_terracotta
fill 39 200 333 39 203 333 minecraft:honeycomb_block
setblock 40 200 326 minecraft:yellow_terracotta
fill 40 200 327 40 203 327 minecraft:honeycomb_block
setblock 40 200 331 minecraft:yellow_terracotta
fill 40 200 332 40 203 332 minecraft:honeycomb_block
setblock 40 200 336 minecraft:yellow_terracotta
setblock 40 200 342 minecraft:honeycomb_block
setblock 40 200 346 minecraft:yellow_terracotta
fill 40 200 347 40 203 347 minecraft:honeycomb_block
setblock 40 200 351 minecraft:yellow_terracotta
setblock 41 200 325 minecraft:yellow_terracotta
fill 41 200 326 41 203 326 minecraft:honeycomb_block
setblock 41 200 330 minecraft:yellow_terracotta
fill 41 200 331 41 203 331 minecraft:honeycomb_block
setblock 41 200 335 minecraft:yellow_terracotta
fill 41 200 336 41 203 336 minecraft:honeycomb_block
setblock 41 200 340 minecraft:yellow_terracotta
fill 41 200 341 41 203 341 minecraft:honeycomb_block
setblock 41 200 345 minecraft:yellow_terracotta
fill 41 200 346 41 203 346 minecraft:honeycomb_block
setblock 41 200 350 minecraft:yellow_terracotta
fill 41 200 351 41 203 351 minecraft:honeycomb_block
fill 41 200 354 42 200 354 minecraft:honeycomb_block
setblock 41 200 356 minecraft:honey_block
fill 42 200 362 42 235 362 minecraft:honeycomb_block
setblock 0 201 338 minecraft:yellow_concrete
setblock 1 201 324 minecraft:yellow_terracotta
fill 1 201 325 1 204 325 minecraft:honeycomb_block
setblock 1 201 329 minecraft:yellow_terracotta
fill 1 201 330 1 204 330 minecraft:honeycomb_block
setblock 1 201 334 minecraft:yellow_terracotta
fill 1 201 335 1 204 335 minecraft:honeycomb_block
setblock 1 201 336 minecraft:honey_block
fill 1 201 345 1 201 348 minecraft:honeycomb_block
setblock 1 201 349 minecraft:yellow_terracotta
fill 1 201 350 1 204 350 minecraft:honeycomb_block
setblock 1 201 354 minecraft:yellow_terracotta
fill 1 201 355 1 204 355 minecraft:honeycomb_block
fill 1 201 357 1 201 358 minecraft:honeycomb_block
setblock 1 201 359 minecraft:yellow_terracotta
fill 1 201 360 1 204 360 minecraft:honeycomb_block
setblock 2 201 323 minecraft:yellow_terracotta
fill 2 201 324 2 204 324 minecraft:honeycomb_block
setblock 2 201 328 minecraft:yellow_terracotta
fill 2 201 329 2 204 329 minecraft:honeycomb_block
setblock 2 201 363 minecraft:yellow_terracotta
fill 3 201 323 3 204 323 minecraft:honeycomb_block
setblock 3 201 327 minecraft:yellow_terracotta
setblock 3 201 328 minecraft:honeycomb_block
setblock 3 201 332 minecraft:light[level=12]
setblock 3 201 339 minecraft:light[level=12]
setblock 3 201 346 minecraft:light[level=12]
setblock 3 201 353 minecraft:light[level=12]
setblock 3 201 360 minecraft:light[level=12]
fill 3 201 363 3 204 363 minecraft:honeycomb_block
setblock 7 201 323 minecraft:yellow_terracotta
setblock 10 201 325 minecraft:light[level=12]
setblock 10 201 332 minecraft:light[level=12]
setblock 10 201 339 minecraft:light[level=12]
setblock 10 201 346 minecraft:light[level=12]
setblock 10 201 353 minecraft:light[level=12]
setblock 10 201 360 minecraft:light[level=12]
fill 12 201 364 12 285 364 minecraft:honeycomb_block
setblock 17 201 323 minecraft:yellow_terracotta
setblock 17 201 325 minecraft:light[level=12]
setblock 17 201 332 minecraft:light[level=12]
setblock 17 201 339 minecraft:light[level=12]
setblock 17 201 346 minecraft:light[level=12]
setblock 17 201 353 minecraft:light[level=12]
setblock 17 201 360 minecraft:light[level=12]
setblock 17 201 363 minecraft:yellow_terracotta
fill 18 201 323 18 204 323 minecraft:honeycomb_block
fill 18 201 363 18 204 363 minecraft:honeycomb_block
fill 22 201 364 22 236 364 minecraft:honeycomb_block
setblock 24 201 323 minecraft:honey_block
setblock 24 201 325 minecraft:light[level=12]
setblock 24 201 332 minecraft:light[level=12]
fill 24 201 336 24 201 337 minecraft:yellow_terracotta
setblock 24 201 339 minecraft:light[level=12]
fill 24 201 345 24 201 349 minecraft:yellow_terracotta
setblock 24 201 353 minecraft:light[level=12]
setblock 24 201 360 minecraft:light[level=12]
fill 25 201 333 25 201 334 minecraft:honey_block
fill 25 201 338 26 201 338 minecraft:yellow_terracotta
fill 25 201 351 25 201 352 minecraft:honey_block
fill 25 201 360 25 202 360 minecraft:brown_terracotta
fill 25 201 362 25 202 362 minecraft:brown_terracotta
setblock 26 201 336 minecraft:yellow_terracotta
fill 26 201 345 26 201 349 minecraft:yellow_terracotta
fill 27 201 360 27 202 360 minecraft:brown_terracotta
fill 27 201 362 27 202 362 minecraft:brown_terracotta
setblock 31 201 325 minecraft:light[level=12]
setblock 31 201 332 minecraft:light[level=12]
setblock 31 201 339 minecraft:light[level=12]
setblock 31 201 346 minecraft:light[level=12]
setblock 31 201 353 minecraft:light[level=12]
setblock 31 201 360 minecraft:light[level=12]
setblock 33 201 364 minecraft:orange_terracotta
setblock 36 201 323 minecraft:honeycomb_block
setblock 36 201 324 minecraft:yellow_terracotta
setblock 37 201 323 minecraft:yellow_terracotta
fill 37 201 324 37 203 325 minecraft:honeycomb_block
fill 37 201 364 37 308 364 minecraft:honeycomb_block
fill 38 201 323 38 204 323 minecraft:honeycomb_block
fill 38 201 328 38 203 329 minecraft:honeycomb_block
setblock 38 201 332 minecraft:light[level=12]
setblock 38 201 339 minecraft:light[level=12]
setblock 38 201 346 minecraft:light[level=12]
setblock 38 201 353 minecraft:light[level=12]
setblock 38 201 360 minecraft:light[level=12]
setblock 39 201 326 minecraft:yellow_terracotta
fill 39 201 327 39 204 327 minecraft:honeycomb_block
setblock 39 201 331 minecraft:yellow_terracotta
fill 39 201 332 39 204 332 minecraft:honeycomb_block
fill 39 201 364 39 202 364 minecraft:honeycomb_block
setblock 40 201 325 minecraft:yellow_terracotta
fill 40 201 326 40 204 326 minecraft:honeycomb_block
setblock 40 201 330 minecraft:yellow_terracotta
fill 40 201 331 40 204 331 minecraft:honeycomb_block
setblock 40 201 335 minecraft:yellow_terracotta
fill 40 201 336 40 204 336 minecraft:honeycomb_block
setblock 40 201 345 minecraft:yellow_terracotta
fill 40 201 346 40 202 346 minecraft:honeycomb_block
setblock 40 201 350 minecraft:yellow_terracotta
fill 40 201 351 40 204 351 minecraft:honeycomb_block
setblock 41 201 324 minecraft:yellow_terracotta
fill 41 201 325 41 204 325 minecraft:honeycomb_block
setblock 41 201 329 minecraft:yellow_terracotta
fill 41 201 330 41 204 330 minecraft:honeycomb_block
setblock 41 201 334 minecraft:yellow_terracotta
fill 41 201 335 41 204 335 minecraft:honeycomb_block
setblock 41 201 339 minecraft:yellow_terracotta
fill 41 201 340 41 204 340 minecraft:honeycomb_block
setblock 41 201 344 minecraft:yellow_terracotta
fill 41 201 345 41 204 345 minecraft:honeycomb_block
setblock 41 201 349 minecraft:yellow_terracotta
fill 41 201 350 41 204 350 minecraft:honeycomb_block
setblock 41 201 354 minecraft:yellow_terracotta
setblock 42 201 338 minecraft:orange_terracotta
fill 42 201 354 42 308 354 minecraft:honeycomb_block
fill 0 202 338 0 259 338 minecraft:honeycomb_block
setblock 1 202 323 minecraft:yellow_terracotta
fill 1 202 324 1 205 324 minecraft:honeycomb_block
setblock 1 202 328 minecraft:yellow_terracotta
fill 1 202 329 1 205 329 minecraft:honeycomb_block
setblock 1 202 333 minecraft:yellow_terracotta
fill 1 202 334 1 205 334 minecraft:honeycomb_block
setblock 1 202 342 minecraft:honey_block
fill 1 202 346 1 202 347 minecraft:honeycomb_block
setblock 1 202 348 minecraft:yellow_terracotta
fill 1 202 349 1 205 349 minecraft:honeycomb_block
setblock 1 202 353 minecraft:yellow_terracotta
fill 1 202 354 1 205 354 minecraft:honeycomb_block
setblock 1 202 357 minecraft:honeycomb_block
setblock 1 202 358 minecraft:yellow_terracotta
fill 1 202 359 1 205 359 minecraft:honeycomb_block
setblock 1 202 362 minecraft:honeycomb_block
setblock 1 202 363 minecraft:yellow_terracotta
fill 2 202 323 2 205 323 minecraft:honeycomb_block
setblock 2 202 327 minecraft:yellow_terracotta
fill 2 202 328 2 205 328 minecraft:honeycomb_block
setblock 2 202 332 minecraft:yellow_terracotta
fill 2 202 363 2 205 363 minecraft:honeycomb_block
setblock 5 202 363 minecraft:honey_block
setblock 6 202 323 minecraft:yellow_terracotta
fill 11 202 354 12 202 356 minecraft:honey_block
fill 12 202 353 16 202 353 minecraft:honey_block
fill 12 202 357 16 202 357 minecraft:honey_block
fill 13 202 352 15 202 352 minecraft:honey_block
fill 13 202 358 15 202 358 minecraft:honey_block
setblock 15 202 323 minecraft:honeycomb_block
setblock 16 202 323 minecraft:yellow_terracotta
fill 16 202 354 17 202 356 minecraft:honey_block
setblock 16 202 363 minecraft:yellow_terracotta
fill 17 202 323 17 205 323 minecraft:honeycomb_block
fill 17 202 363 17 205 363 minecraft:honeycomb_block
setblock 24 202 363 minecraft:honey_block
fill 25 202 335 25 202 337 minecraft:honey_block
setblock 25 202 338 minecraft:yellow_terracotta
fill 25 202 345 25 202 347 minecraft:yellow_terracotta
fill 25 202 348 25 202 350 minecraft:honey_block
fill 26 202 327 27 202 329 minecraft:honey_block
setblock 26 202 345 minecraft:yellow_terracotta
fill 27 202 325 28 202 326 minecraft:honey_block
fill 27 202 330 32 202 330 minecraft:honey_block
fill 28 202 331 31 202 331 minecraft:honey_block
fill 29 202 325 31 202 325 minecraft:honey_block
fill 30 202 326 32 202 326 minecraft:honey_block
fill 31 202 329 32 203 329 minecraft:honey_block
fill 32 202 327 32 203 328 minecraft:honey_block
setblock 33 202 328 minecraft:honey_block
fill 33 202 364 33 308 364 minecraft:honeycomb_block
fill 34 202 323 34 203 323 minecraft:honeycomb_block
setblock 36 202 323 minecraft:yellow_terracotta
fill 36 202 324 36 205 324 minecraft:honeycomb_block
fill 37 202 323 37 205 323 minecraft:honeycomb_block
fill 38 202 327 38 205 327 minecraft:honeycomb_block
setblock 38 202 330 minecraft:honeycomb_block
setblock 38 202 331 minecraft:yellow_terracotta
setblock 39 202 325 minecraft:yellow_terracotta
fill 39 202 326 39 205 326 minecraft:honeycomb_block
setblock 39 202 330 minecraft:yellow_terracotta
fill 39 202 331 39 205 331 minecraft:honeycomb_block
setblock 39 202 334 minecraft:honeycomb_block
setblock 40 202 324 minecraft:yellow_terracotta
fill 40 202 325 40 205 325 minecraft:honeycomb_block
setblock 40 202 329 minecraft:yellow_terracotta
fill 40 202 330 40 205 330 minecraft:honeycomb_block
setblock 40 202 334 minecraft:yellow_terracotta
fill 40 202 335 40 205 335 minecraft:honeycomb_block
fill 40 202 337 40 203 337 minecraft:honeycomb_block
setblock 40 202 349 minecraft:yellow_terracotta
fill 40 202 350 40 205 350 minecraft:honeycomb_block
fill 40 202 352 40 203 352 minecraft:honeycomb_block
setblock 41 202 323 minecraft:yellow_terracotta
fill 41 202 324 41 205 324 minecraft:honeycomb_block
setblock 41 202 328 minecraft:yellow_terracotta
fill 41 202 329 41 205 329 minecraft:honeycomb_block
setblock 41 202 333 minecraft:yellow_terracotta
fill 41 202 334 41 205 334 minecraft:honeycomb_block
setblock 41 202 338 minecraft:yellow_terracotta
fill 41 202 339 41 205 339 minecraft:honeycomb_block
setblock 41 202 343 minecraft:yellow_terracotta
fill 41 202 344 41 203 344 minecraft:honeycomb_block
setblock 41 202 348 minecraft:yellow_terracotta
fill 41 202 349 41 205 349 minecraft:honeycomb_block
setblock 41 202 353 minecraft:yellow_terracotta
fill 41 202 354 41 204 355 minecraft:honeycomb_block
fill 42 202 338 42 303 338 minecraft:honeycomb_block
fill 1 203 323 1 205 323 minecraft:honeycomb_block
setblock 1 203 327 minecraft:yellow_terracotta
fill 1 203 328 1 205 328 minecraft:honeycomb_block
setblock 1 203 332 minecraft:yellow_terracotta
fill 1 203 333 1 205 333 minecraft:honeycomb_block
setblock 1 203 346 minecraft:honeycomb_block
setblock 1 203 347 minecraft:yellow_terracotta
fill 1 203 348 1 205 348 minecraft:honeycomb_block
setblock 1 203 352 minecraft:yellow_terracotta
fill 1 203 353 2 205 353 minecraft:honeycomb_block
setblock 1 203 357 minecraft:yellow_terracotta
fill 1 203 358 1 205 358 minecraft:honeycomb_block
setblock 1 203 362 minecraft:yellow_terracotta
fill 1 203 363 1 205 363 minecraft:honeycomb_block
setblock 2 203 326 minecraft:yellow_terracotta
fill 2 203 327 2 205 327 minecraft:honeycomb_block
setblock 2 203 331 minecraft:yellow_terracotta
fill 2 203 332 2 205 332 minecraft:honeycomb_block
fill 2 203 352 2 205 352 minecraft:honeycomb_block
fill 2 203 354 2 204 354 minecraft:honeycomb_block
setblock 5 203 323 minecraft:yellow_terracotta
fill 6 203 323 6 204 323 minecraft:honey_block
setblock 11 203 363 minecraft:honey_block
setblock 12 203 323 minecraft:honey_block
fill 12 203 354 12 203 356 minecraft:honey_block
fill 13 203 353 16 203 353 minecraft:honey_block
fill 13 203 357 15 203 357 minecraft:honey_block
fill 13 203 363 13 204 363 minecraft:honeycomb_block
setblock 15 203 323 minecraft:yellow_terracotta
setblock 15 203 363 minecraft:yellow_terracotta
fill 16 203 323 16 205 323 minecraft:honeycomb_block
fill 16 203 354 16 204 356 minecraft:honey_block
fill 16 203 363 16 205 363 minecraft:honeycomb_block
setblock 20 203 363 minecraft:yellow_terracotta
setblock 25 203 338 minecraft:honey_block
fill 25 203 345 25 203 347 minecraft:honey_block
fill 27 203 326 27 203 330 minecraft:honey_block
fill 28 203 326 28 204 326 minecraft:honey_block
fill 28 203 330 31 203 330 minecraft:honey_block
fill 29 203 325 30 203 325 minecraft:honey_block
fill 29 203 331 30 203 331 minecraft:honey_block
fill 30 203 326 31 203 326 minecraft:honey_block
setblock 30 203 363 minecraft:honey_block
setblock 31 203 323 minecraft:honey_block
setblock 35 203 323 minecraft:yellow_terracotta
fill 35 203 324 35 205 324 minecraft:honeycomb_block
fill 36 203 323 36 205 323 minecraft:honeycomb_block
fill 36 203 325 36 204 325 minecraft:honeycomb_block
setblock 38 203 325 minecraft:yellow_terracotta
setblock 38 203 330 minecraft:yellow_terracotta
fill 38 203 331 38 205 332 minecraft:honeycomb_block
setblock 39 203 324 minecraft:yellow_terracotta
fill 39 203 325 39 205 325 minecraft:honeycomb_block
setblock 39 203 329 minecraft:yellow_terracotta
fill 39 203 330 39 205 330 minecraft:honeycomb_block
setblock 39 203 334 minecraft:yellow_terracotta
fill 39 203 335 39 205 335 minecraft:honeycomb_block
setblock 39 203 364 minecraft:orange_terracotta
setblock 40 203 323 minecraft:yellow_terracotta
fill 40 203 324 40 205 324 minecraft:honeycomb_block
setblock 40 203 328 minecraft:yellow_terracotta
fill 40 203 329 40 205 329 minecraft:honeycomb_block
setblock 40 203 333 minecraft:yellow_terracotta
fill 40 203 334 40 205 334 minecraft:honeycomb_block
setblock 40 203 348 minecraft:yellow_terracotta
fill 40 203 349 40 205 349 minecraft:honeycomb_block
setblock 40 203 353 minecraft:yellow_terracotta
fill 41 203 323 41 205 323 minecraft:honeycomb_block
setblock 41 203 327 minecraft:yellow_terracotta
fill 41 203 328 41 205 328 minecraft:honeycomb_block
setblock 41 203 332 minecraft:yellow_terracotta
fill 41 203 333 41 205 333 minecraft:honeycomb_block
setblock 41 203 337 minecraft:yellow_terracotta
fill 41 203 338 41 205 338 minecraft:honeycomb_block
setblock 41 203 343 minecraft:honeycomb_block
setblock 41 203 347 minecraft:yellow_terracotta
fill 41 203 348 41 205 348 minecraft:honeycomb_block
setblock 41 203 352 minecraft:yellow_terracotta
fill 41 203 353 41 205 353 minecraft:honeycomb_block
setblock 41 203 356 minecraft:honeycomb_block
setblock 41 203 357 minecraft:honey_block
setblock 42 203 330 minecraft:yellow_concrete
setblock 1 204 326 minecraft:yellow_terracotta
fill 1 204 327 1 205 327 minecraft:honeycomb_block
setblock 1 204 331 minecraft:yellow_terracotta
fill 1 204 332 1 205 332 minecraft:honeycomb_block
setblock 1 204 336 minecraft:yellow_terracotta
fill 1 204 347 1 205 347 minecraft:honeycomb_block
setblock 1 204 351 minecraft:yellow_terracotta
fill 1 204 352 1 205 352 minecraft:honeycomb_block
setblock 1 204 356 minecraft:yellow_terracotta
fill 1 204 357 1 205 357 minecraft:honeycomb_block
setblock 1 204 361 minecraft:yellow_terracotta
fill 1 204 362 1 205 362 minecraft:honeycomb_block
setblock 2 204 325 minecraft:yellow_terracotta
fill 2 204 326 2 205 326 minecraft:honeycomb_block
setblock 2 204 330 minecraft:yellow_terracotta
fill 2 204 331 2 205 331 minecraft:honeycomb_block
fill 2 204 333 2 205 333 minecraft:honeycomb_block
fill 2 204 351 2 205 351 minecraft:honeycomb_block
setblock 2 204 355 minecraft:yellow_terracotta
fill 2 204 356 2 205 356 minecraft:honeycomb_block
setblock 4 204 323 minecraft:yellow_terracotta
setblock 12 204 355 minecraft:honey_block
fill 12 204 363 12 205 363 minecraft:honeycomb_block
fill 13 204 353 15 204 353 minecraft:honey_block
setblock 14 204 323 minecraft:yellow_terracotta
setblock 14 204 357 minecraft:honey_block
setblock 14 204 363 minecraft:yellow_terracotta
fill 15 204 323 15 205 323 minecraft:honeycomb_block
fill 15 204 363 15 205 363 minecraft:honeycomb_block
setblock 19 204 323 minecraft:yellow_terracotta
setblock 19 204 363 minecraft:yellow_terracotta
setblock 21 204 364 minecraft:yellow_terracotta
setblock 25 204 323 minecraft:honey_block
fill 27 204 327 27 204 329 minecraft:honey_block
fill 27 204 333 27 205 334 minecraft:honey_block
fill 28 204 330 30 204 330 minecraft:honey_block
fill 28 204 334 28 205 334 minecraft:honey_block
setblock 30 204 326 minecraft:honey_block
setblock 31 204 329 minecraft:honey_block
setblock 33 204 323 minecraft:honeycomb_block
setblock 34 204 323 minecraft:yellow_terracotta
fill 35 204 323 35 205 323 minecraft:honeycomb_block
setblock 36 204 363 minecraft:honey_block
setblock 37 204 324 minecraft:honeycomb_block
setblock 37 204 325 minecraft:yellow_terracotta
setblock 38 204 324 minecraft:yellow_terracotta
fill 38 204 325 38 205 325 minecraft:honeycomb_block
setblock 38 204 328 minecraft:honeycomb_block
setblock 38 204 329 minecraft:yellow_terracotta
fill 38 204 330 38 205 330 minecraft:honeycomb_block
setblock 38 204 333 minecraft:honeycomb_block
setblock 38 204 334 minecraft:yellow_terracotta
setblock 39 204 323 minecraft:yellow_terracotta
fill 39 204 324 39 205 324 minecraft:honeycomb_block
setblock 39 204 328 minecraft:yellow_terracotta
fill 39 204 329 39 205 329 minecraft:honeycomb_block
setblock 39 204 333 minecraft:yellow_terracotta
fill 39 204 334 39 205 334 minecraft:honeycomb_block
fill 39 204 336 39 205 336 minecraft:honeycomb_block
setblock 39 204 363 minecraft:yellow_terracotta
fill 39 204 364 39 248 364 minecraft:honeycomb_block
fill 40 204 323 40 205 323 minecraft:honeycomb_block
setblock 40 204 327 minecraft:yellow_terracotta
fill 40 204 328 40 205 328 minecraft:honeycomb_block
setblock 40 204 332 minecraft:yellow_terracotta
fill 40 204 333 40 205 333 minecraft:honeycomb_block
setblock 40 204 337 minecraft:yellow_terracotta
fill 40 204 338 40 205 338 minecraft:honeycomb_block
setblock 40 204 348 minecraft:honeycomb_block
setblock 40 204 352 minecraft:yellow_terracotta
fill 40 204 353 40 205 354 minecraft:honeycomb_block
setblock 41 204 322 minecraft:yellow_concrete
setblock 41 204 326 minecraft:yellow_terracotta
fill 41 204 327 41 205 327 minecraft:honeycomb_block
setblock 41 204 331 minecraft:yellow_terracotta
fill 41 204 332 41 205 332 minecraft:honeycomb_block
setblock 41 204 336 minecraft:yellow_terracotta
fill 41 204 337 41 205 337 minecraft:honeycomb_block
setblock 41 204 346 minecraft:yellow_terracotta
fill 41 204 347 41 205 347 minecraft:honeycomb_block
setblock 41 204 351 minecraft:yellow_terracotta
fill 41 204 352 41 205 352 minecraft:honeycomb_block
setblock 41 204 356 minecraft:yellow_terracotta
fill 41 204 357 41 205 358 minecraft:honeycomb_block
fill 42 204 330 42 207 330 minecraft:honeycomb_block
setblock 0 205 335 minecraft:orange_terracotta
setblock 0 205 354 minecraft:orange_terracotta
setblock 0 205 362 minecraft:yellow_terracotta
setblock 1 205 325 minecraft:yellow_terracotta
setblock 1 205 326 minecraft:honeycomb_block
setblock 1 205 330 minecraft:yellow_terracotta
setblock 1 205 331 minecraft:honeycomb_block
setblock 1 205 335 minecraft:yellow_terracotta
setblock 1 205 336 minecraft:honeycomb_block
setblock 1 205 341 minecraft:honey_block
setblock 1 205 350 minecraft:yellow_terracotta
setblock 1 205 351 minecraft:honeycomb_block
setblock 1 205 355 minecraft:yellow_terracotta
setblock 1 205 356 minecraft:honeycomb_block
setblock 1 205 360 minecraft:yellow_terracotta
setblock 1 205 361 minecraft:honeycomb_block
setblock 2 205 324 minecraft:yellow_terracotta
setblock 2 205 325 minecraft:honeycomb_block
setblock 2 205 329 minecraft:yellow_terracotta
setblock 2 205 330 minecraft:honeycomb_block
setblock 2 205 350 minecraft:honeycomb_block
setblock 2 205 354 minecraft:yellow_terracotta
setblock 2 205 355 minecraft:honeycomb_block
fill 2 205 357 2 205 358 minecraft:honeycomb_block
setblock 3 205 323 minecraft:yellow_terracotta
setblock 3 205 363 minecraft:yellow_terracotta
setblock 4 205 323 minecraft:honeycomb_block
setblock 4 205 363 minecraft:honeycomb_block
setblock 11 205 363 minecraft:honeycomb_block
setblock 13 205 363 minecraft:yellow_terracotta
setblock 14 205 323 minecraft:honeycomb_block
setblock 14 205 363 minecraft:honeycomb_block
fill 15 205 362 17 205 362 minecraft:honeycomb_block
setblock 18 205 323 minecraft:yellow_terracotta
setblock 18 205 363 minecraft:yellow_terracotta
setblock 19 205 323 minecraft:honey_block
setblock 19 205 363 minecraft:honeycomb_block
fill 21 205 364 21 225 364 minecraft:honeycomb_block
setblock 23 205 363 minecraft:honey_block
setblock 32 205 322 minecraft:yellow_concrete
setblock 33 205 323 minecraft:yellow_terracotta
fill 34 205 323 34 205 324 minecraft:honeycomb_block
setblock 35 205 325 minecraft:honeycomb_block
setblock 36 205 325 minecraft:yellow_terracotta
setblock 37 205 324 minecraft:yellow_terracotta
setblock 37 205 325 minecraft:honeycomb_block
fill 37 205 330 37 205 331 minecraft:honeycomb_block
setblock 37 205 363 minecraft:honeycomb_block
setblock 38 205 323 minecraft:yellow_terracotta
setblock 38 205 324 minecraft:honeycomb_block
setblock 38 205 326 minecraft:honeycomb_block
setblock 38 205 328 minecraft:yellow_terracotta
setblock 38 205 329 minecraft:honeycomb_block
setblock 38 205 333 minecraft:yellow_terracotta
fill 38 205 334 38 205 335 minecraft:honeycomb_block
setblock 38 205 363 minecraft:yellow_terracotta
setblock 39 205 323 minecraft:honeycomb_block
setblock 39 205 327 minecraft:yellow_terracotta
setblock 39 205 328 minecraft:honeycomb_block
setblock 39 205 332 minecraft:yellow_terracotta
setblock 39 205 333 minecraft:honeycomb_block
fill 39 205 363 41 205 363 minecraft:honeycomb_block
setblock 40 205 326 minecraft:yellow_terracotta
setblock 40 205 327 minecraft:honeycomb_block
setblock 40 205 331 minecraft:yellow_terracotta
setblock 40 205 332 minecraft:honeycomb_block
setblock 40 205 336 minecraft:yellow_terracotta
setblock 40 205 337 minecraft:honeycomb_block
setblock 40 205 351 minecraft:yellow_terracotta
setblock 40 205 352 minecraft:honeycomb_block
setblock 40 205 355 minecraft:honeycomb_block
setblock 40 205 356 minecraft:yellow_terracotta
fill 41 205 322 41 209 322 minecraft:honeycomb_block
setblock 41 205 325 minecraft:yellow_terracotta
setblock 41 205 326 minecraft:honeycomb_block
setblock 41 205 330 minecraft:yellow_terracotta
setblock 41 205 331 minecraft:honeycomb_block
setblock 41 205 335 minecraft:yellow_terracotta
setblock 41 205 336 minecraft:honeycomb_block
setblock 41 205 340 minecraft:yellow_terracotta
setblock 41 205 345 minecraft:honey_block
setblock 41 205 346 minecraft:honeycomb_block
setblock 41 205 350 minecraft:yellow_terracotta
setblock 41 205 351 minecraft:honeycomb_block
setblock 41 205 354 minecraft:honeycomb_block
setblock 41 205 355 minecraft:yellow_terracotta
setblock 41 205 356 minecraft:honeycomb_block
setblock 41 205 359 minecraft:honeycomb_block
setblock 41 205 360 minecraft:yellow_terracotta
fill 0 206 335 0 245 335 minecraft:honeycomb_block
setblock 0 206 346 minecraft:orange_terracotta
fill 0 206 354 0 298 354 minecraft:honeycomb_block
fill 0 206 362 0 273 362 minecraft:honeycomb_block
fill 32 206 322 32 308 322 minecraft:honeycomb_block
fill 0 207 346 0 245 346 minecraft:honeycomb_block
setblock 3 207 325 minecraft:light[level=15]
setblock 3 207 332 minecraft:light[level=12]
setblock 3 207 333 minecraft:light[level=15]
setblock 3 207 339 minecraft:light[level=12]
setblock 3 207 341 minecraft:light[level=15]
setblock 3 207 346 minecraft:light[level=12]
setblock 3 207 349 minecraft:light[level=15]
setblock 3 207 353 minecraft:light[level=12]
setblock 3 207 357 minecraft:light[level=15]
setblock 3 207 360 minecraft:light[level=12]
setblock 10 207 325 minecraft:light[level=12]
setblock 10 207 332 minecraft:light[level=12]
setblock 10 207 339 minecraft:light[level=12]
setblock 10 207 346 minecraft:light[level=12]
setblock 10 207 353 minecraft:light[level=12]
setblock 10 207 360 minecraft:light[level=12]
setblock 11 207 325 minecraft:light[level=15]
setblock 11 207 333 minecraft:light[level=15]
setblock 11 207 341 minecraft:light[level=15]
setblock 11 207 349 minecraft:light[level=15]
setblock 11 207 357 minecraft:light[level=15]
setblock 17 207 325 minecraft:light[level=12]
setblock 17 207 332 minecraft:light[level=12]
setblock 17 207 339 minecraft:light[level=12]
setblock 17 207 346 minecraft:light[level=12]
setblock 17 207 353 minecraft:light[level=12]
setblock 17 207 360 minecraft:light[level=12]
setblock 19 207 325 minecraft:light[level=15]
setblock 19 207 333 minecraft:light[level=15]
setblock 19 207 341 minecraft:light[level=15]
setblock 19 207 349 minecraft:light[level=15]
setblock 19 207 357 minecraft:light[level=15]
setblock 24 207 325 minecraft:light[level=12]
setblock 24 207 332 minecraft:light[level=12]
setblock 24 207 339 minecraft:light[level=12]
setblock 24 207 346 minecraft:light[level=12]
setblock 24 207 353 minecraft:light[level=12]
setblock 24 207 360 minecraft:light[level=12]
setblock 27 207 325 minecraft:light[level=15]
setblock 27 207 333 minecraft:light[level=15]
setblock 27 207 341 minecraft:light[level=15]
setblock 27 207 349 minecraft:light[level=15]
setblock 27 207 357 minecraft:light[level=15]
setblock 31 207 325 minecraft:light[level=12]
setblock 31 207 332 minecraft:light[level=12]
setblock 31 207 339 minecraft:light[level=12]
setblock 31 207 346 minecraft:light[level=12]
setblock 31 207 353 minecraft:light[level=12]
setblock 31 207 360 minecraft:light[level=12]
setblock 35 207 325 minecraft:light[level=15]
setblock 35 207 333 minecraft:light[level=15]
setblock 35 207 341 minecraft:light[level=15]
setblock 35 207 349 minecraft:light[level=15]
setblock 35 207 357 minecraft:light[level=15]
setblock 38 207 325 minecraft:light[level=12]
setblock 38 207 332 minecraft:light[level=12]
setblock 38 207 339 minecraft:light[level=12]
setblock 38 207 346 minecraft:light[level=12]
setblock 38 207 353 minecraft:light[level=12]
setblock 38 207 360 minecraft:light[level=12]
setblock 42 207 334 minecraft:yellow_terracotta
setblock 24 208 364 minecraft:orange_terracotta
setblock 30 208 364 minecraft:yellow_terracotta
setblock 42 208 330 minecraft:orange_terracotta
fill 42 208 334 42 211 334 minecraft:honeycomb_block
fill 24 209 364 24 258 364 minecraft:honeycomb_block
setblock 26 209 364 minecraft:yellow_concrete
fill 30 209 364 30 308 364 minecraft:honeycomb_block
fill 42 209 330 42 271 330 minecraft:honeycomb_block
setblock 0 210 324 minecraft:yellow_concrete
setblock 26 210 322 minecraft:orange_terracotta
fill 26 210 364 26 263 364 minecraft:honeycomb_block
setblock 36 210 364 minecraft:yellow_concrete
setblock 41 210 322 minecraft:yellow_terracotta
setblock 42 210 346 minecraft:yellow_terracotta
fill 0 211 324 0 287 324 minecraft:honeycomb_block
setblock 0 211 333 minecraft:orange_terracotta
fill 15 211 338 15 211 344 minecraft:yellow_terracotta
fill 16 211 336 16 211 340 minecraft:yellow_terracotta
setblock 16 211 341 minecraft:orange_stained_glass
fill 16 211 342 16 211 346 minecraft:yellow_terracotta
fill 17 211 335 17 211 337 minecraft:yellow_terracotta
setblock 17 211 338 minecraft:yellow_stained_glass
fill 17 211 339 17 211 340 minecraft:orange_stained_glass
setblock 17 211 341 minecraft:yellow_stained_glass
fill 17 211 342 17 211 343 minecraft:orange_stained_glass
setblock 17 211 344 minecraft:yellow_stained_glass
fill 17 211 345 17 211 347 minecraft:yellow_terracotta
fill 18 211 334 18 211 335 minecraft:yellow_terracotta
setblock 18 211 336 minecraft:orange_stained_glass
setblock 18 211 337 minecraft:yellow_stained_glass
fill 18 211 338 18 211 339 minecraft:orange_stained_glass
setblock 18 211 340 minecraft:yellow_stained_glass
fill 18 211 341 18 211 342 minecraft:orange_stained_glass
setblock 18 211 343 minecraft:yellow_stained_glass
fill 18 211 344 18 211 345 minecraft:orange_stained_glass
setblock 18 211 346 minecraft:yellow_stained_glass
fill 18 211 347 18 211 348 minecraft:yellow_terracotta
fill 19 211 333 20 211 334 minecraft:yellow_terracotta
setblock 19 211 335 minecraft:orange_stained_glass
setblock 19 211 336 minecraft:yellow_stained_glass
fill 19 211 337 19 211 338 minecraft:orange_stained_glass
setblock 19 211 339 minecraft:yellow_stained_glass
fill 19 211 340 19 211 341 minecraft:orange_stained_glass
setblock 19 211 342 minecraft:yellow_stained_glass
fill 19 211 343 19 211 344 minecraft:orange_stained_glass
setblock 19 211 345 minecraft:yellow_stained_glass
fill 19 211 346 19 211 347 minecraft:orange_stained_glass
fill 19 211 348 20 211 349 minecraft:yellow_terracotta
setblock 20 211 335 minecraft:yellow_stained_glass
fill 20 211 336 20 211 337 minecraft:orange_stained_glass
setblock 20 211 338 minecraft:yellow_stained_glass
fill 20 211 339 20 211 340 minecraft:orange_stained_glass
setblock 20 211 341 minecraft:yellow_stained_glass
fill 20 211 342 20 211 343 minecraft:orange_stained_glass
setblock 20 211 344 minecraft:yellow_stained_glass
fill 20 211 345 20 211 346 minecraft:orange_stained_glass
setblock 20 211 347 minecraft:yellow_stained_glass
fill 21 211 332 23 211 333 minecraft:yellow_terracotta
setblock 21 211 334 minecraft:yellow_stained_glass
fill 21 211 335 21 211 336 minecraft:orange_stained_glass
setblock 21 211 337 minecraft:yellow_stained_glass
fill 21 211 338 21 211 339 minecraft:orange_stained_glass
setblock 21 211 340 minecraft:yellow_stained_glass
fill 21 211 341 21 211 342 minecraft:orange_stained_glass
setblock 21 211 343 minecraft:yellow_stained_glass
fill 21 211 344 21 211 345 minecraft:orange_stained_glass
setblock 21 211 346 minecraft:yellow_stained_glass
fill 21 211 347 21 211 348 minecraft:orange_stained_glass
fill 21 211 349 23 211 350 minecraft:yellow_terracotta
fill 22 211 334 22 211 335 minecraft:orange_stained_glass
setblock 22 211 336 minecraft:yellow_stained_glass
fill 22 211 337 22 211 338 minecraft:orange_stained_glass
setblock 22 211 339 minecraft:yellow_stained_glass
fill 22 211 343 22 211 344 minecraft:orange_stained_glass
setblock 22 211 345 minecraft:yellow_stained_glass
fill 22 211 346 22 211 347 minecraft:orange_stained_glass
setblock 22 211 348 minecraft:yellow_stained_glass
setblock 23 211 334 minecraft:orange_stained_glass
setblock 23 211 335 minecraft:yellow_stained_glass
fill 23 211 336 23 211 337 minecraft:orange_stained_glass
setblock 23 211 338 minecraft:yellow_stained_glass
setblock 23 211 344 minecraft:yellow_stained_glass
fill 23 211 345 23 211 346 minecraft:orange_stained_glass
setblock 23 211 347 minecraft:yellow_stained_glass
fill 23 211 348 24 211 348 minecraft:orange_stained_glass
fill 24 211 332 27 211 332 minecraft:yellow_terracotta
setblock 24 211 333 minecraft:orange_stained_glass
setblock 24 211 334 minecraft:yellow_stained_glass
fill 24 211 335 24 211 336 minecraft:orange_stained_glass
setblock 24 211 337 minecraft:yellow_stained_glass
fill 24 211 338 25 211 338 minecraft:orange_stained_glass
fill 24 211 344 24 211 345 minecraft:orange_stained_glass
setblock 24 211 346 minecraft:yellow_stained_glass
fill 24 211 347 25 211 347 minecraft:orange_stained_glass
setblock 24 211 349 minecraft:yellow_stained_glass
fill 24 211 350 27 211 350 minecraft:yellow_terracotta
fill 25 211 333 29 211 333 minecraft:yellow_terracotta
fill 25 211 334 25 211 335 minecraft:orange_stained_glass
setblock 25 211 336 minecraft:yellow_stained_glass
fill 25 211 337 26 211 337 minecraft:orange_stained_glass
setblock 25 211 344 minecraft:orange_stained_glass
setblock 25 211 345 minecraft:yellow_stained_glass
fill 25 211 346 26 211 346 minecraft:orange_stained_glass
setblock 25 211 348 minecraft:yellow_stained_glass
fill 25 211 349 29 211 349 minecraft:yellow_terracotta
fill 26 211 322 26 221 322 minecraft:honeycomb_block
setblock 26 211 334 minecraft:orange_stained_glass
setblock 26 211 335 minecraft:yellow_stained_glass
fill 26 211 336 27 211 336 minecraft:orange_stained_glass
setblock 26 211 338 minecraft:yellow_stained_glass
fill 26 211 339 27 211 339 minecraft:orange_stained_glass
setblock 26 211 343 minecraft:orange_stained_glass
setblock 26 211 344 minecraft:yellow_stained_glass
fill 26 211 345 27 211 345 minecraft:orange_stained_glass
setblock 26 211 347 minecraft:yellow_stained_glass
fill 26 211 348 27 211 348 minecraft:orange_stained_glass
setblock 27 211 334 minecraft:yellow_stained_glass
fill 27 211 335 28 211 335 minecraft:orange_stained_glass
setblock 27 211 337 minecraft:yellow_stained_glass
fill 27 211 338 28 211 338 minecraft:orange_stained_glass
setblock 27 211 340 minecraft:yellow_stained_glass
fill 27 211 341 27 211 342 minecraft:orange_stained_glass
setblock 27 211 343 minecraft:yellow_stained_glass
fill 27 211 344 28 211 344 minecraft:orange_stained_glass
setblock 27 211 346 minecraft:yellow_stained_glass
fill 27 211 347 28 211 347 minecraft:orange_stained_glass
setblock 28 211 322 minecraft:yellow_concrete
fill 28 211 334 30 211 334 minecraft:yellow_terracotta
setblock 28 211 336 minecraft:yellow_stained_glass
fill 28 211 337 29 211 337 minecraft:orange_stained_glass
setblock 28 211 339 minecraft:yellow_stained_glass
fill 28 211 340 28 211 341 minecraft:orange_stained_glass
setblock 28 211 342 minecraft:yellow_stained_glass
fill 28 211 343 29 211 343 minecraft:orange_stained_glass
setblock 28 211 345 minecraft:yellow_stained_glass
fill 28 211 346 29 211 346 minecraft:orange_stained_glass
fill 28 211 348 30 211 348 minecraft:yellow_terracotta
setblock 29 211 335 minecraft:yellow_stained_glass
fill 29 211 336 30 211 336 minecraft:orange_stained_glass
setblock 29 211 338 minecraft:yellow_stained_glass
fill 29 211 339 29 211 340 minecraft:orange_stained_glass
setblock 29 211 341 minecraft:yellow_stained_glass
fill 29 211 342 30 211 342 minecraft:orange_stained_glass
setblock 29 211 344 minecraft:yellow_stained_glass
fill 29 211 345 30 211 345 minecraft:orange_stained_glass
setblock 29 211 347 minecraft:yellow_stained_glass
fill 30 211 335 31 211 335 minecraft:yellow_terracotta
setblock 30 211 337 minecraft:yellow_stained_glass
fill 30 211 338 30 211 339 minecraft:orange_stained_glass
setblock 30 211 340 minecraft:yellow_stained_glass
fill 30 211 341 31 211 341 minecraft:orange_stained_glass
setblock 30 211 343 minecraft:yellow_stained_glass
fill 30 211 344 31 211 344 minecraft:orange_stained_glass
setblock 30 211 346 minecraft:yellow_stained_glass
fill 30 211 347 31 211 347 minecraft:yellow_terracotta
fill 31 211 336 32 211 337 minecraft:yellow_terracotta
setblock 31 211 338 minecraft:orange_stained_glass
setblock 31 211 339 minecraft:yellow_stained_glass
setblock 31 211 340 minecraft:orange_stained_glass
setblock 31 211 342 minecraft:yellow_stained_glass
setblock 31 211 343 minecraft:orange_stained_glass
fill 31 211 345 32 211 346 minecraft:yellow_terracotta
fill 32 211 338 33 211 340 minecraft:yellow_terracotta
setblock 32 211 341 minecraft:yellow_stained_glass
fill 32 211 342 33 211 344 minecraft:yellow_terracotta
setblock 33 211 341 minecraft:yellow_terracotta
fill 36 211 364 36 215 364 minecraft:honeycomb_block
fill 40 211 364 41 211 364 minecraft:yellow_concrete
fill 41 211 322 41 308 322 minecraft:honeycomb_block
fill 42 211 346 42 237 346 minecraft:honeycomb_block
fill 0 212 333 0 237 333 minecraft:honeycomb_block
fill 1 212 323 1 212 327 minecraft:orange_terracotta
setblock 1 212 328 minecraft:white_concrete
fill 1 212 329 1 212 335 minecraft:orange_terracotta
setblock 1 212 336 minecraft:white_concrete
fill 1 212 337 1 212 343 minecraft:orange_terracotta
setblock 1 212 344 minecraft:white_concrete
fill 1 212 345 1 212 351 minecraft:orange_terracotta
setblock 1 212 352 minecraft:white_concrete
fill 1 212 353 1 212 359 minecraft:orange_terracotta
setblock 1 212 360 minecraft:white_concrete
fill 1 212 361 5 212 363 minecraft:orange_terracotta
fill 2 212 323 2 212 326 minecraft:orange_terracotta
setblock 2 212 327 minecraft:white_concrete
fill 2 212 328 2 212 334 minecraft:orange_terracotta
setblock 2 212 335 minecraft:white_concrete
fill 2 212 336 2 212 342 minecraft:orange_terracotta
setblock 2 212 343 minecraft:white_concrete
fill 2 212 344 2 212 350 minecraft:orange_terracotta
setblock 2 212 351 minecraft:white_concrete
fill 2 212 352 2 212 358 minecraft:orange_terracotta
setblock 2 212 359 minecraft:white_concrete
fill 2 212 360 8 212 360 minecraft:orange_terracotta
fill 3 212 323 3 212 325 minecraft:orange_terracotta
setblock 3 212 326 minecraft:white_concrete
fill 3 212 327 3 212 333 minecraft:orange_terracotta
setblock 3 212 334 minecraft:white_concrete
fill 3 212 335 3 212 341 minecraft:orange_terracotta
setblock 3 212 342 minecraft:white_concrete
fill 3 212 343 3 212 349 minecraft:orange_terracotta
setblock 3 212 350 minecraft:white_concrete
fill 3 212 351 3 212 357 minecraft:orange_terracotta
setblock 3 212 358 minecraft:white_concrete
fill 3 212 359 9 212 359 minecraft:orange_terracotta
fill 4 212 323 4 212 324 minecraft:orange_terracotta
setblock 4 212 325 minecraft:white_concrete
fill 4 212 326 4 212 332 minecraft:orange_terracotta
setblock 4 212 333 minecraft:white_concrete
fill 4 212 334 4 212 340 minecraft:orange_terracotta
setblock 4 212 341 minecraft:white_concrete
fill 4 212 342 4 212 348 minecraft:orange_terracotta
setblock 4 212 349 minecraft:white_concrete
fill 4 212 350 4 212 356 minecraft:orange_terracotta
setblock 4 212 357 minecraft:white_concrete
fill 4 212 358 10 212 358 minecraft:orange_terracotta
setblock 5 212 323 minecraft:orange_terracotta
setblock 5 212 324 minecraft:white_concrete
fill 5 212 325 5 212 331 minecraft:orange_terracotta
setblock 5 212 332 minecraft:white_concrete
fill 5 212 333 5 212 339 minecraft:orange_terracotta
setblock 5 212 340 minecraft:white_concrete
fill 5 212 341 5 212 347 minecraft:orange_terracotta
setblock 5 212 348 minecraft:white_concrete
fill 5 212 349 5 212 355 minecraft:orange_terracotta
setblock 5 212 356 minecraft:white_concrete
fill 5 212 357 11 212 357 minecraft:orange_terracotta
setblock 6 212 323 minecraft:white_concrete
fill 6 212 324 6 212 330 minecraft:orange_terracotta
setblock 6 212 331 minecraft:white_concrete
fill 6 212 332 6 212 338 minecraft:orange_terracotta
setblock 6 212 339 minecraft:white_concrete
fill 6 212 340 6 212 346 minecraft:orange_terracotta
setblock 6 212 347 minecraft:white_concrete
fill 6 212 348 6 212 354 minecraft:orange_terracotta
setblock 6 212 355 minecraft:white_concrete
fill 6 212 356 12 212 356 minecraft:orange_terracotta
fill 6 212 361 6 212 362 minecraft:orange_terracotta
setblock 6 212 363 minecraft:white_concrete
fill 7 212 323 7 212 329 minecraft:orange_terracotta
setblock 7 212 330 minecraft:white_concrete
fill 7 212 331 7 212 337 minecraft:orange_terracotta
setblock 7 212 338 minecraft:white_concrete
fill 7 212 339 7 212 345 minecraft:orange_terracotta
setblock 7 212 346 minecraft:white_concrete
fill 7 212 347 7 212 353 minecraft:orange_terracotta
setblock 7 212 354 minecraft:white_concrete
fill 7 212 355 13 212 355 minecraft:orange_terracotta
setblock 7 212 361 minecraft:orange_terracotta
setblock 7 212 362 minecraft:white_concrete
fill 7 212 363 13 212 363 minecraft:orange_terracotta
fill 8 212 323 8 212 328 minecraft:orange_terracotta
setblock 8 212 329 minecraft:white_concrete
fill 8 212 330 8 212 336 minecraft:orange_terracotta
setblock 8 212 337 minecraft:white_concrete
fill 8 212 338 8 212 344 minecraft:orange_terracotta
setblock 8 212 345 minecraft:white_concrete
fill 8 212 346 8 212 352 minecraft:orange_terracotta
setblock 8 212 353 minecraft:white_concrete
fill 8 212 354 14 212 354 minecraft:orange_terracotta
setblock 8 212 361 minecraft:white_concrete
fill 8 212 362 14 212 362 minecraft:orange_terracotta
fill 9 212 323 9 212 327 minecraft:orange_terracotta
setblock 9 212 328 minecraft:white_concrete
fill 9 212 329 9 212 335 minecraft:orange_terracotta
setblock 9 212 336 minecraft:white_concrete
fill 9 212 337 9 212 343 minecraft:orange_terracotta
setblock 9 212 344 minecraft:white_concrete
fill 9 212 345 9 212 351 minecraft:orange_terracotta
setblock 9 212 352 minecraft:white_concrete
fill 9 212 353 15 212 353 minecraft:orange_terracotta
setblock 9 212 360 minecraft:white_concrete
fill 9 212 361 15 212 361 minecraft:orange_terracotta
fill 10 212 323 10 212 326 minecraft:orange_terracotta
setblock 10 212 327 minecraft:white_concrete
fill 10 212 328 10 212 334 minecraft:orange_terracotta
setblock 10 212 335 minecraft:white_concrete
fill 10 212 336 10 212 342 minecraft:orange_terracotta
setblock 10 212 343 minecraft:white_concrete
fill 10 212 344 10 212 350 minecraft:orange_terracotta
setblock 10 212 351 minecraft:white_concrete
fill 10 212 352 16 212 352 minecraft:orange_terracotta
setblock 10 212 359 minecraft:white_concrete
fill 10 212 360 16 212 360 minecraft:orange_terracotta
fill 11 212 323 11 212 325 minecraft:orange_terracotta
setblock 11 212 326 minecraft:white_concrete
fill 11 212 327 11 212 333 minecraft:orange_terracotta
setblock 11 212 334 minecraft:white_concrete
fill 11 212 335 11 212 341 minecraft:orange_terracotta
setblock 11 212 342 minecraft:white_concrete
fill 11 212 343 11 212 349 minecraft:orange_terracotta
setblock 11 212 350 minecraft:white_concrete
fill 11 212 351 17 212 351 minecraft:orange_terracotta
setblock 11 212 358 minecraft:white_concrete
fill 11 212 359 17 212 359 minecraft:orange_terracotta
fill 12 212 323 12 212 324 minecraft:orange_terracotta
setblock 12 212 325 minecraft:white_concrete
fill 12 212 326 12 212 332 minecraft:orange_terracotta
setblock 12 212 333 minecraft:white_concrete
fill 12 212 334 12 212 340 minecraft:orange_terracotta
setblock 12 212 341 minecraft:white_concrete
fill 12 212 342 12 212 348 minecraft:orange_terracotta
setblock 12 212 349 minecraft:white_concrete
fill 12 212 350 18 212 350 minecraft:orange_terracotta
setblock 12 212 357 minecraft:white_concrete
fill 12 212 358 18 212 358 minecraft:orange_terracotta
setblock 13 212 323 minecraft:orange_terracotta
setblock 13 212 324 minecraft:white_concrete
fill 13 212 325 13 212 331 minecraft:orange_terracotta
setblock 13 212 332 minecraft:white_concrete
fill 13 212 333 13 212 339 minecraft:orange_terracotta
setblock 13 212 340 minecraft:white_concrete
fill 13 212 341 13 212 347 minecraft:orange_terracotta
setblock 13 212 348 minecraft:white_concrete
fill 13 212 349 19 212 349 minecraft:orange_terracotta
setblock 13 212 356 minecraft:white_concrete
fill 13 212 357 19 212 357 minecraft:orange_terracotta
setblock 14 212 323 minecraft:white_concrete
fill 14 212 324 14 212 330 minecraft:orange_terracotta
setblock 14 212 331 minecraft:white_concrete
fill 14 212 332 14 212 338 minecraft:orange_terracotta
setblock 14 212 339 minecraft:white_concrete
fill 14 212 340 14 212 346 minecraft:orange_terracotta
setblock 14 212 347 minecraft:white_concrete
fill 14 212 348 20 212 348 minecraft:orange_terracotta
setblock 14 212 355 minecraft:white_concrete
fill 14 212 356 20 212 356 minecraft:orange_terracotta
setblock 14 212 363 minecraft:white_concrete
fill 15 212 323 15 212 329 minecraft:orange_terracotta
setblock 15 212 330 minecraft:white_concrete
fill 15 212 331 15 212 337 minecraft:orange_terracotta
setblock 15 212 338 minecraft:white_concrete
fill 15 212 339 15 212 345 minecraft:orange_terracotta
setblock 15 212 346 minecraft:white_concrete
fill 15 212 347 21 212 347 minecraft:orange_terracotta
setblock 15 212 354 minecraft:white_concrete
fill 15 212 355 21 212 355 minecraft:orange_terracotta
setblock 15 212 362 minecraft:white_concrete
fill 15 212 363 21 212 363 minecraft:orange_terracotta
fill 16 212 323 16 212 328 minecraft:orange_terracotta
setblock 16 212 329 minecraft:white_concrete
fill 16 212 330 16 212 336 minecraft:orange_terracotta
setblock 16 212 337 minecraft:white_concrete
fill 16 212 338 16 212 344 minecraft:orange_terracotta
setblock 16 212 345 minecraft:white_concrete
fill 16 212 346 22 212 346 minecraft:orange_terracotta
setblock 16 212 353 minecraft:white_concrete
fill 16 212 354 22 212 354 minecraft:orange_terracotta
setblock 16 212 361 minecraft:white_concrete
fill 16 212 362 22 212 362 minecraft:orange_terracotta
fill 17 212 323 17 212 327 minecraft:orange_terracotta
setblock 17 212 328 minecraft:white_concrete
fill 17 212 329 17 212 335 minecraft:orange_terracotta
setblock 17 212 336 minecraft:white_concrete
fill 17 212 337 17 212 343 minecraft:orange_terracotta
setblock 17 212 344 minecraft:white_concrete
fill 17 212 345 23 212 345 minecraft:orange_terracotta
setblock 17 212 352 minecraft:white_concrete
fill 17 212 353 23 212 353 minecraft:orange_terracotta
setblock 17 212 360 minecraft:white_concrete
fill 17 212 361 23 212 361 minecraft:orange_terracotta
fill 18 212 323 18 212 326 minecraft:orange_terracotta
setblock 18 212 327 minecraft:white_concrete
fill 18 212 328 18 212 334 minecraft:orange_terracotta
setblock 18 212 335 minecraft:white_concrete
fill 18 212 336 18 212 342 minecraft:orange_terracotta
setblock 18 212 343 minecraft:white_concrete
fill 18 212 344 22 212 344 minecraft:orange_terracotta
setblock 18 212 351 minecraft:white_concrete
fill 18 212 352 24 212 352 minecraft:orange_terracotta
setblock 18 212 359 minecraft:white_concrete
fill 18 212 360 24 212 360 minecraft:orange_terracotta
fill 19 212 323 19 212 325 minecraft:orange_terracotta
setblock 19 212 326 minecraft:white_concrete
fill 19 212 327 19 212 333 minecraft:orange_terracotta
setblock 19 212 334 minecraft:white_concrete
fill 19 212 335 19 212 341 minecraft:orange_terracotta
fill 19 212 342 19 213 342 minecraft:white_concrete
fill 19 212 343 21 212 343 minecraft:orange_terracotta
setblock 19 212 350 minecraft:white_concrete
fill 19 212 351 25 212 351 minecraft:orange_terracotta
setblock 19 212 358 minecraft:white_concrete
fill 19 212 359 25 212 359 minecraft:orange_terracotta
fill 20 212 323 20 212 324 minecraft:orange_terracotta
setblock 20 212 325 minecraft:white_concrete
fill 20 212 326 20 212 332 minecraft:orange_terracotta
setblock 20 212 333 minecraft:white_concrete
fill 20 212 334 20 212 340 minecraft:orange_terracotta
setblock 20 212 341 minecraft:white_concrete
setblock 20 212 342 minecraft:orange_terracotta
setblock 20 212 349 minecraft:white_concrete
fill 20 212 350 26 212 350 minecraft:orange_terracotta
setblock 20 212 357 minecraft:white_concrete
fill 20 212 358 26 212 358 minecraft:orange_terracotta
setblock 21 212 323 minecraft:orange_terracotta
setblock 21 212 324 minecraft:white_concrete
fill 21 212 325 21 212 331 minecraft:orange_terracotta
setblock 21 212 332 minecraft:white_concrete
fill 21 212 333 21 212 339 minecraft:orange_terracotta
fill 21 212 340 21 213 342 minecraft:orange_concrete
setblock 21 212 348 minecraft:white_concrete
fill 21 212 349 27 212 349 minecraft:orange_terracotta
setblock 21 212 356 minecraft:white_concrete
fill 21 212 357 27 212 357 minecraft:orange_terracotta
setblock 22 212 323 minecraft:white_concrete
fill 22 212 324 22 212 330 minecraft:orange_terracotta
setblock 22 212 331 minecraft:white_concrete
fill 22 212 332 22 212 338 minecraft:orange_terracotta
fill 22 212 339 22 213 339 minecraft:orange_concrete
fill 22 212 343 22 213 343 minecraft:orange_concrete
setblock 22 212 347 minecraft:white_concrete
fill 22 212 348 28 212 348 minecraft:orange_terracotta
setblock 22 212 355 minecraft:white_concrete
fill 22 212 356 28 212 356 minecraft:orange_terracotta
setblock 22 212 363 minecraft:white_concrete
fill 23 212 323 23 212 329 minecraft:orange_terracotta
setblock 23 212 330 minecraft:white_concrete
fill 23 212 331 23 212 337 minecraft:orange_terracotta
fill 23 212 338 25 213 338 minecraft:orange_concrete
fill 23 212 344 25 213 344 minecraft:orange_concrete
setblock 23 212 346 minecraft:white_concrete
fill 23 212 347 29 212 347 minecraft:orange_terracotta
setblock 23 212 354 minecraft:white_concrete
fill 23 212 355 29 212 355 minecraft:orange_terracotta
setblock 23 212 362 minecraft:white_concrete
fill 23 212 363 29 212 363 minecraft:orange_terracotta
fill 24 212 323 24 212 328 minecraft:orange_terracotta
setblock 24 212 329 minecraft:white_concrete
fill 24 212 330 24 212 336 minecraft:orange_terracotta
setblock 24 212 337 minecraft:white_concrete
setblock 24 212 345 minecraft:white_concrete
fill 24 212 346 30 212 346 minecraft:orange_terracotta
setblock 24 212 353 minecraft:white_concrete
fill 24 212 354 30 212 354 minecraft:orange_terracotta
setblock 24 212 361 minecraft:white_concrete
fill 24 212 362 30 212 362 minecraft:orange_terracotta
fill 25 212 323 25 212 327 minecraft:orange_terracotta
setblock 25 212 328 minecraft:white_concrete
fill 25 212 329 25 212 335 minecraft:orange_terracotta
setblock 25 212 336 minecraft:white_concrete
fill 25 212 337 31 212 337 minecraft:orange_terracotta
fill 25 212 345 31 212 345 minecraft:orange_terracotta
setblock 25 212 352 minecraft:white_concrete
fill 25 212 353 31 212 353 minecraft:orange_terracotta
setblock 25 212 360 minecraft:white_concrete
fill 25 212 361 31 212 361 minecraft:orange_terracotta
fill 26 212 323 26 212 326 minecraft:orange_terracotta
setblock 26 212 327 minecraft:white_concrete
fill 26 212 328 26 212 334 minecraft:orange_terracotta
setblock 26 212 335 minecraft:white_concrete
fill 26 212 336 32 212 336 minecraft:orange_terracotta
fill 26 212 338 30 212 338 minecraft:orange_terracotta
fill 26 212 339 26 213 339 minecraft:orange_concrete
fill 26 212 343 26 213 343 minecraft:orange_concrete
fill 26 212 344 32 212 344 minecraft:orange_terracotta
setblock 26 212 351 minecraft:white_concrete
fill 26 212 352 32 212 352 minecraft:orange_terracotta
setblock 26 212 359 minecraft:white_concrete
fill 26 212 360 32 212 360 minecraft:orange_terracotta
fill 27 212 323 27 212 325 minecraft:orange_terracotta
setblock 27 212 326 minecraft:white_concrete
fill 27 212 327 27 212 333 minecraft:orange_terracotta
setblock 27 212 334 minecraft:white_concrete
fill 27 212 335 33 212 335 minecraft:orange_terracotta
fill 27 212 339 29 212 339 minecraft:orange_terracotta
fill 27 212 340 27 213 342 minecraft:orange_concrete
fill 27 212 343 33 212 343 minecraft:orange_terracotta
setblock 27 212 350 minecraft:white_concrete
fill 27 212 351 33 212 351 minecraft:orange_terracotta
setblock 27 212 358 minecraft:white_concrete
fill 27 212 359 33 212 359 minecraft:orange_terracotta
fill 28 212 322 28 284 322 minecraft:honeycomb_block
fill 28 212 323 28 212 324 minecraft:orange_terracotta
setblock 28 212 325 minecraft:white_concrete
fill 28 212 326 28 212 332 minecraft:orange_terracotta
setblock 28 212 333 minecraft:white_concrete
fill 28 212 334 34 212 334 minecraft:orange_terracotta
setblock 28 212 340 minecraft:orange_terracotta
setblock 28 212 341 minecraft:white_concrete
fill 28 212 342 34 212 342 minecraft:orange_terracotta
setblock 28 212 349 minecraft:white_concrete
fill 28 212 350 34 212 350 minecraft:orange_terracotta
setblock 28 212 357 minecraft:white_concrete
fill 28 212 358 34 212 358 minecraft:orange_terracotta
setblock 29 212 323 minecraft:orange_terracotta
setblock 29 212 324 minecraft:white_concrete
fill 29 212 325 29 212 331 minecraft:orange_terracotta
setblock 29 212 332 minecraft:white_concrete
fill 29 212 333 35 212 333 minecraft:orange_terracotta
setblock 29 212 340 minecraft:white_concrete
fill 29 212 341 35 212 341 minecraft:orange_terracotta
setblock 29 212 348 minecraft:white_concrete
fill 29 212 349 35 212 349 minecraft:orange_terracotta
setblock 29 212 356 minecraft:white_concrete
fill 29 212 357 35 212 357 minecraft:orange_terracotta
setblock 30 212 323 minecraft:white_concrete
fill 30 212 324 30 212 330 minecraft:orange_terracotta
setblock 30 212 331 minecraft:white_concrete
fill 30 212 332 36 212 332 minecraft:orange_terracotta
setblock 30 212 339 minecraft:white_concrete
fill 30 212 340 36 212 340 minecraft:orange_terracotta
setblock 30 212 347 minecraft:white_concrete
fill 30 212 348 36 212 348 minecraft:orange_terracotta
setblock 30 212 355 minecraft:white_concrete
fill 30 212 356 36 212 356 minecraft:orange_terracotta
setblock 30 212 363 minecraft:white_concrete
fill 31 212 323 31 212 329 minecraft:orange_terracotta
setblock 31 212 330 minecraft:white_concrete
fill 31 212 331 37 212 331 minecraft:orange_terracotta
setblock 31 212 338 minecraft:white_concrete
fill 31 212 339 37 212 339 minecraft:orange_terracotta
setblock 31 212 346 minecraft:white_concrete
fill 31 212 347 37 212 347 minecraft:orange_terracotta
setblock 31 212 354 minecraft:white_concrete
fill 31 212 355 37 212 355 minecraft:orange_terracotta
setblock 31 212 362 minecraft:white_concrete
fill 31 212 363 37 212 363 minecraft:orange_terracotta
fill 32 212 323 32 212 328 minecraft:orange_terracotta
setblock 32 212 329 minecraft:white_concrete
fill 32 212 330 38 212 330 minecraft:orange_terracotta
setblock 32 212 337 minecraft:white_concrete
fill 32 212 338 38 212 338 minecraft:orange_terracotta
setblock 32 212 345 minecraft:white_concrete
fill 32 212 346 38 212 346 minecraft:orange_terracotta
setblock 32 212 353 minecraft:white_concrete
fill 32 212 354 38 212 354 minecraft:orange_terracotta
setblock 32 212 361 minecraft:white_concrete
fill 32 212 362 38 212 362 minecraft:orange_terracotta
fill 33 212 323 33 212 327 minecraft:orange_terracotta
setblock 33 212 328 minecraft:white_concrete
fill 33 212 329 39 212 329 minecraft:orange_terracotta
setblock 33 212 336 minecraft:white_concrete
fill 33 212 337 39 212 337 minecraft:orange_terracotta
setblock 33 212 344 minecraft:white_concrete
fill 33 212 345 39 212 345 minecraft:orange_terracotta
setblock 33 212 352 minecraft:white_concrete
fill 33 212 353 39 212 353 minecraft:orange_terracotta
setblock 33 212 360 minecraft:white_concrete
fill 33 212 361 39 212 361 minecraft:orange_terracotta
fill 34 212 323 34 212 326 minecraft:orange_terracotta
setblock 34 212 327 minecraft:white_concrete
fill 34 212 328 40 212 328 minecraft:orange_terracotta
setblock 34 212 335 minecraft:white_concrete
fill 34 212 336 40 212 336 minecraft:orange_terracotta
setblock 34 212 343 minecraft:white_concrete
fill 34 212 344 40 212 344 minecraft:orange_terracotta
setblock 34 212 351 minecraft:white_concrete
fill 34 212 352 40 212 352 minecraft:orange_terracotta
setblock 34 212 359 minecraft:white_concrete
fill 34 212 360 40 212 360 minecraft:orange_terracotta
fill 35 212 323 35 212 325 minecraft:orange_terracotta
setblock 35 212 326 minecraft:white_concrete
fill 35 212 327 41 212 327 minecraft:orange_terracotta
setblock 35 212 334 minecraft:white_concrete
fill 35 212 335 41 212 335 minecraft:orange_terracotta
setblock 35 212 342 minecraft:white_concrete
fill 35 212 343 41 212 343 minecraft:orange_terracotta
setblock 35 212 350 minecraft:white_concrete
fill 35 212 351 41 212 351 minecraft:orange_terracotta
setblock 35 212 358 minecraft:white_concrete
fill 35 212 359 41 212 359 minecraft:orange_terracotta
fill 36 212 323 36 212 324 minecraft:orange_terracotta
setblock 36 212 325 minecraft:white_concrete
fill 36 212 326 41 212 326 minecraft:orange_terracotta
setblock 36 212 333 minecraft:white_concrete
fill 36 212 334 41 212 334 minecraft:orange_terracotta
setblock 36 212 341 minecraft:white_concrete
fill 36 212 342 41 212 342 minecraft:orange_terracotta
setblock 36 212 349 minecraft:white_concrete
fill 36 212 350 41 212 350 minecraft:orange_terracotta
setblock 36 212 357 minecraft:white_concrete
fill 36 212 358 41 212 358 minecraft:orange_terracotta
setblock 37 212 323 minecraft:orange_terracotta
setblock 37 212 324 minecraft:white_concrete
fill 37 212 325 41 212 325 minecraft:orange_terracotta
setblock 37 212 332 minecraft:white_concrete
fill 37 212 333 41 212 333 minecraft:orange_terracotta
setblock 37 212 340 minecraft:white_concrete
fill 37 212 341 41 212 341 minecraft:orange_terracotta
setblock 37 212 348 minecraft:white_concrete
fill 37 212 349 41 212 349 minecraft:orange_terracotta
setblock 37 212 356 minecraft:white_concrete
fill 37 212 357 41 212 357 minecraft:orange_terracotta
setblock 38 212 323 minecraft:white_concrete
fill 38 212 324 41 212 324 minecraft:orange_terracotta
setblock 38 212 331 minecraft:white_concrete
fill 38 212 332 42 212 332 minecraft:orange_terracotta
setblock 38 212 339 minecraft:white_concrete
fill 38 212 340 41 212 340 minecraft:orange_terracotta
setblock 38 212 347 minecraft:white_concrete
fill 38 212 348 41 212 348 minecraft:orange_terracotta
setblock 38 212 355 minecraft:white_concrete
fill 38 212 356 41 212 356 minecraft:orange_terracotta
setblock 38 212 363 minecraft:white_concrete
fill 39 212 323 41 212 323 minecraft:orange_terracotta
setblock 39 212 330 minecraft:white_concrete
fill 39 212 331 41 212 331 minecraft:orange_terracotta
setblock 39 212 338 minecraft:white_concrete
fill 39 212 339 41 212 339 minecraft:orange_terracotta
setblock 39 212 346 minecraft:white_concrete
fill 39 212 347 41 212 347 minecraft:orange_terracotta
setblock 39 212 354 minecraft:white_concrete
fill 39 212 355 41 212 355 minecraft:orange_terracotta
setblock 39 212 362 minecraft:white_concrete
fill 39 212 363 41 212 363 minecraft:orange_terracotta
setblock 40 212 329 minecraft:white_concrete
fill 40 212 330 41 212 330 minecraft:orange_terracotta
setblock 40 212 337 minecraft:white_concrete
fill 40 212 338 41 212 338 minecraft:orange_terracotta
setblock 40 212 345 minecraft:white_concrete
fill 40 212 346 41 212 346 minecraft:orange_terracotta
setblock 40 212 353 minecraft:white_concrete
fill 40 212 354 41 212 354 minecraft:orange_terracotta
setblock 40 212 361 minecraft:white_concrete
fill 40 212 362 41 212 362 minecraft:orange_terracotta
fill 40 212 364 41 239 364 minecraft:honeycomb_block
setblock 41 212 328 minecraft:white_concrete
setblock 41 212 329 minecraft:orange_terracotta
setblock 41 212 336 minecraft:white_concrete
setblock 41 212 337 minecraft:orange_terracotta
setblock 41 212 344 minecraft:white_concrete
setblock 41 212 345 minecraft:orange_terracotta
setblock 41 212 352 minecraft:white_concrete
setblock 41 212 353 minecraft:orange_terracotta
setblock 41 212 360 minecraft:white_concrete
setblock 41 212 361 minecraft:orange_terracotta
setblock 42 212 334 minecraft:yellow_terracotta
setblock 3 213 325 minecraft:light[level=12]
setblock 3 213 332 minecraft:light[level=12]
setblock 3 213 339 minecraft:light[level=12]
setblock 3 213 346 minecraft:light[level=12]
setblock 3 213 353 minecraft:light[level=12]
setblock 3 213 360 minecraft:light[level=12]
setblock 10 213 325 minecraft:light[level=12]
setblock 10 213 332 minecraft:light[level=12]
setblock 10 213 339 minecraft:light[level=12]
setblock 10 213 346 minecraft:light[level=12]
setblock 10 213 353 minecraft:light[level=12]
setblock 10 213 360 minecraft:light[level=12]
fill 15 213 338 17 213 344 minecraft:yellow_terracotta
fill 16 213 336 18 213 337 minecraft:yellow_terracotta
fill 16 213 345 18 213 346 minecraft:yellow_terracotta
setblock 17 213 325 minecraft:light[level=12]
setblock 17 213 332 minecraft:light[level=12]
fill 17 213 335 21 213 335 minecraft:yellow_terracotta
fill 17 213 347 21 213 347 minecraft:yellow_terracotta
setblock 17 213 353 minecraft:light[level=12]
setblock 17 213 360 minecraft:light[level=12]
fill 18 213 334 30 213 334 minecraft:yellow_terracotta
setblock 18 213 338 minecraft:yellow_terracotta
setblock 18 213 344 minecraft:yellow_terracotta
fill 18 213 348 30 213 348 minecraft:yellow_terracotta
fill 19 213 333 29 213 333 minecraft:yellow_terracotta
fill 19 213 336 19 213 341 minecraft:white_concrete
fill 19 213 343 19 213 346 minecraft:white_concrete
fill 19 213 349 29 213 349 minecraft:yellow_terracotta
fill 21 213 332 27 213 332 minecraft:yellow_terracotta
fill 21 213 350 27 213 350 minecraft:yellow_terracotta
setblock 24 213 325 minecraft:light[level=12]
setblock 24 213 346 minecraft:light[level=12]
setblock 24 213 353 minecraft:light[level=12]
setblock 24 213 360 minecraft:light[level=12]
fill 27 213 335 31 213 335 minecraft:yellow_terracotta
fill 27 213 347 31 213 347 minecraft:yellow_terracotta
fill 29 213 336 32 213 336 minecraft:yellow_terracotta
fill 29 213 346 32 213 346 minecraft:yellow_terracotta
fill 30 213 337 32 213 338 minecraft:yellow_terracotta
fill 30 213 344 32 213 345 minecraft:yellow_terracotta
setblock 31 213 325 minecraft:light[level=12]
setblock 31 213 332 minecraft:light[level=12]
fill 31 213 339 33 213 343 minecraft:yellow_terracotta
setblock 31 213 353 minecraft:light[level=12]
setblock 31 213 360 minecraft:light[level=12]
setblock 33 213 338 minecraft:yellow_terracotta
setblock 33 213 344 minecraft:yellow_terracotta
setblock 38 213 325 minecraft:light[level=12]
setblock 38 213 332 minecraft:light[level=12]
setblock 38 213 339 minecraft:light[level=12]
setblock 38 213 346 minecraft:light[level=12]
setblock 38 213 353 minecraft:light[level=12]
setblock 38 213 360 minecraft:light[level=12]
fill 42 213 332 42 270 332 minecraft:honeycomb_block
fill 42 213 334 42 241 334 minecraft:honeycomb_block
fill 19 214 336 19 219 338 minecraft:white_concrete
fill 19 214 339 19 217 343 minecraft:red_concrete
fill 19 214 344 19 219 346 minecraft:white_concrete
setblock 3 215 325 minecraft:light[level=15]
setblock 3 215 333 minecraft:light[level=15]
setblock 3 215 341 minecraft:light[level=15]
setblock 3 215 349 minecraft:light[level=15]
setblock 3 215 357 minecraft:light[level=15]
setblock 5 215 364 minecraft:yellow_terracotta
setblock 11 215 325 minecraft:light[level=15]
setblock 11 215 333 minecraft:light[level=15]
setblock 11 215 341 minecraft:light[level=15]
setblock 11 215 349 minecraft:light[level=15]
setblock 11 215 357 minecraft:light[level=15]
setblock 19 215 325 minecraft:light[level=15]
setblock 19 215 333 minecraft:light[level=15]
setblock 19 215 349 minecraft:light[level=15]
setblock 19 215 357 minecraft:light[level=15]
setblock 27 215 325 minecraft:light[level=15]
setblock 27 215 333 minecraft:light[level=15]
setblock 27 215 341 minecraft:light[level=15]
setblock 27 215 349 minecraft:light[level=15]
setblock 27 215 357 minecraft:light[level=15]
setblock 35 215 325 minecraft:light[level=15]
setblock 35 215 333 minecraft:light[level=15]
setblock 35 215 341 minecraft:light[level=15]
setblock 35 215 349 minecraft:light[level=15]
setblock 35 215 357 minecraft:light[level=15]
setblock 1 216 344 minecraft:honey_block
fill 1 216 356 1 216 358 minecraft:honeycomb_block
setblock 1 216 359 minecraft:yellow_terracotta
fill 1 216 360 1 216 363 minecraft:honeycomb_block
setblock 2 216 322 minecraft:orange_terracotta
setblock 2 216 358 minecraft:yellow_terracotta
fill 2 216 359 2 216 362 minecraft:honeycomb_block
setblock 2 216 363 minecraft:yellow_terracotta
setblock 3 216 362 minecraft:yellow_terracotta
fill 3 216 363 6 216 363 minecraft:honeycomb_block
fill 4 216 362 7 216 362 minecraft:honeycomb_block
fill 5 216 364 5 308 364 minecraft:honeycomb_block
fill 7 216 346 8 217 346 minecraft:yellow_concrete
fill 7 216 357 7 222 357 minecraft:flowering_azalea_leaves[persistent=true]
fill 7 216 361 8 216 361 minecraft:honeycomb_block
setblock 7 216 363 minecraft:yellow_terracotta
setblock 8 216 362 minecraft:yellow_terracotta
fill 8 216 363 11 216 363 minecraft:honeycomb_block
setblock 9 216 361 minecraft:yellow_terracotta
fill 9 216 362 12 216 362 minecraft:honeycomb_block
fill 10 216 361 12 217 361 minecraft:honeycomb_block
setblock 12 216 363 minecraft:yellow_terracotta
setblock 13 216 362 minecraft:yellow_terracotta
fill 13 216 363 16 216 363 minecraft:honeycomb_block
fill 14 216 362 14 219 362 minecraft:honeycomb_block
setblock 16 216 323 minecraft:honey_block
fill 26 216 349 33 216 352 minecraft:brown_terracotta
setblock 26 216 363 minecraft:honey_block
setblock 27 216 323 minecraft:yellow_terracotta
fill 27 216 348 33 216 348 minecraft:brown_terracotta
fill 27 216 353 32 216 354 minecraft:brown_terracotta
setblock 27 216 363 minecraft:yellow_terracotta
fill 28 216 323 31 216 323 minecraft:honeycomb_block
fill 28 216 335 33 218 337 minecraft:brown_terracotta
fill 28 216 347 32 216 347 minecraft:brown_terracotta
fill 28 216 363 31 216 363 minecraft:honeycomb_block
fill 29 216 334 32 218 334 minecraft:brown_terracotta
fill 29 216 338 32 218 338 minecraft:brown_terracotta
fill 29 216 355 31 216 355 minecraft:brown_terracotta
fill 29 216 362 32 216 362 minecraft:honeycomb_block
setblock 30 216 324 minecraft:honeycomb_block
fill 30 216 333 31 218 333 minecraft:brown_terracotta
setblock 31 216 324 minecraft:yellow_terracotta
setblock 32 216 323 minecraft:yellow_terracotta
fill 32 216 324 35 216 324 minecraft:honeycomb_block
setblock 32 216 363 minecraft:yellow_terracotta
fill 33 216 323 36 216 323 minecraft:honeycomb_block
setblock 33 216 353 minecraft:brown_terracotta
setblock 33 216 362 minecraft:yellow_terracotta
fill 33 216 363 36 216 363 minecraft:honeycomb_block
fill 34 216 350 34 216 352 minecraft:brown_terracotta
fill 34 216 362 37 216 362 minecraft:honeycomb_block
fill 36 216 354 36 224 354 minecraft:brown_terracotta
setblock 36 216 364 minecraft:yellow_concrete
setblock 37 216 323 minecraft:yellow_terracotta
setblock 37 216 363 minecraft:yellow_terracotta
fill 38 216 323 39 218 323 minecraft:honeycomb_block
fill 38 216 363 41 216 363 minecraft:honeycomb_block
setblock 41 216 342 minecraft:honey_block
setblock 41 216 358 minecraft:honeycomb_block
setblock 41 216 359 minecraft:yellow_terracotta
fill 41 216 360 41 217 362 minecraft:honeycomb_block
setblock 1 217 325 minecraft:honey_block
fill 1 217 331 1 218 331 minecraft:honey_block
setblock 1 217 350 minecraft:honey_block
fill 1 217 356 1 217 357 minecraft:honeycomb_block
setblock 1 217 358 minecraft:yellow_terracotta
fill 1 217 359 1 217 362 minecraft:honeycomb_block
setblock 1 217 363 minecraft:yellow_terracotta
fill 2 217 322 2 308 322 minecraft:honeycomb_block
fill 2 217 358 2 217 361 minecraft:honeycomb_block
setblock 2 217 362 minecraft:yellow_terracotta
fill 2 217 363 5 217 363 minecraft:honeycomb_block
fill 3 217 362 6 217 362 minecraft:honeycomb_block
fill 6 217 361 7 217 361 minecraft:honeycomb_block
setblock 6 217 363 minecraft:yellow_terracotta
setblock 7 217 362 minecraft:yellow_terracotta
fill 7 217 363 10 217 363 minecraft:honeycomb_block
fill 8 217 323 10 217 323 minecraft:honeycomb_block
setblock 8 217 361 minecraft:yellow_terracotta
fill 8 217 362 11 217 362 minecraft:honeycomb_block
fill 9 217 361 9 220 361 minecraft:honeycomb_block
setblock 11 217 323 minecraft:yellow_terracotta
setblock 11 217 363 minecraft:yellow_terracotta
fill 12 217 323 12 220 323 minecraft:honeycomb_block
setblock 12 217 362 minecraft:yellow_terracotta
fill 12 217 363 15 217 363 minecraft:honeycomb_block
fill 13 217 362 13 220 362 minecraft:honeycomb_block
setblock 16 217 363 minecraft:yellow_terracotta
setblock 26 217 323 minecraft:yellow_terracotta
setblock 26 217 363 minecraft:yellow_terracotta
fill 27 217 323 30 217 323 minecraft:honeycomb_block
fill 27 217 363 30 217 363 minecraft:honeycomb_block
fill 28 217 324 29 217 324 minecraft:honeycomb_block
fill 28 217 334 28 218 334 minecraft:brown_terracotta
fill 28 217 338 28 218 338 minecraft:brown_terracotta
fill 28 217 343 30 271 345 minecraft:yellow_terracotta
fill 28 217 362 31 217 362 minecraft:honeycomb_block
fill 29 217 333 29 218 333 minecraft:brown_terracotta
fill 29 217 342 29 271 342 minecraft:yellow_terracotta
setblock 30 217 324 minecraft:yellow_terracotta
fill 30 217 339 31 218 339 minecraft:brown_terracotta
fill 30 217 351 30 220 351 minecraft:yellow_terracotta
setblock 31 217 322 minecraft:yellow_concrete
setblock 31 217 323 minecraft:yellow_terracotta
fill 31 217 324 34 217 324 minecraft:honeycomb_block
setblock 31 217 363 minecraft:yellow_terracotta
fill 32 217 323 35 217 323 minecraft:honeycomb_block
fill 32 217 333 32 218 333 minecraft:brown_terracotta
setblock 32 217 362 minecraft:yellow_terracotta
fill 32 217 363 35 217 363 minecraft:honeycomb_block
fill 33 217 334 33 218 334 minecraft:brown_terracotta
fill 33 217 338 33 218 338 minecraft:brown_terracotta
fill 33 217 362 36 217 362 minecraft:honeycomb_block
setblock 35 217 324 minecraft:yellow_terracotta
setblock 36 217 323 minecraft:yellow_terracotta
setblock 36 217 363 minecraft:yellow_terracotta
fill 36 217 364 36 308 364 minecraft:honeycomb_block
fill 37 217 323 37 220 323 minecraft:honeycomb_block
setblock 37 217 362 minecraft:yellow_terracotta
fill 37 217 363 40 217 363 minecraft:honeycomb_block
fill 38 217 362 38 220 362 minecraft:honeycomb_block
setblock 40 217 323 minecraft:honeycomb_block
setblock 41 217 323 minecraft:yellow_terracotta
setblock 41 217 336 minecraft:honey_block
setblock 41 217 355 minecraft:honey_block
setblock 41 217 358 minecraft:yellow_terracotta
fill 41 217 359 41 220 359 minecraft:honeycomb_block
setblock 41 217 363 minecraft:yellow_terracotta
setblock 1 218 337 minecraft:honey_block
setblock 1 218 356 minecraft:honeycomb_block
setblock 1 218 357 minecraft:yellow_terracotta
fill 1 218 358 1 218 361 minecraft:honeycomb_block
setblock 1 218 362 minecraft:yellow_terracotta
fill 1 218 363 4 218 363 minecraft:honeycomb_block
fill 2 218 358 2 218 360 minecraft:honeycomb_block
setblock 2 218 361 minecraft:yellow_terracotta
fill 2 218 362 5 218 362 minecraft:honeycomb_block
setblock 4 218 323 minecraft:honey_block
fill 4 218 325 5 252 326 minecraft:yellow_terracotta
fill 4 218 361 6 218 361 minecraft:honeycomb_block
setblock 5 218 323 minecraft:yellow_terracotta
setblock 5 218 363 minecraft:yellow_terracotta
fill 6 218 323 9 218 323 minecraft:honeycomb_block
setblock 6 218 362 minecraft:yellow_terracotta
fill 6 218 363 9 218 363 minecraft:honeycomb_block
setblock 7 218 361 minecraft:yellow_terracotta
fill 7 218 362 10 218 362 minecraft:honeycomb_block
fill 8 218 361 8 221 361 minecraft:honeycomb_block
setblock 10 218 323 minecraft:yellow_terracotta
fill 10 218 361 11 218 361 minecraft:honeycomb_block
setblock 10 218 363 minecraft:yellow_terracotta
fill 11 218 323 11 221 323 minecraft:honeycomb_block
setblock 11 218 362 minecraft:yellow_terracotta
fill 11 218 363 14 218 363 minecraft:honeycomb_block
setblock 12 218 361 minecraft:yellow_terracotta
fill 12 218 362 12 221 362 minecraft:honeycomb_block
setblock 13 218 322 minecraft:orange_terracotta
fill 13 218 323 13 219 323 minecraft:honeycomb_block
setblock 15 218 363 minecraft:yellow_terracotta
fill 16 218 363 16 221 363 minecraft:honeycomb_block
fill 19 218 339 19 219 343 minecraft:white_concrete
setblock 19 218 363 minecraft:honey_block
setblock 23 218 323 minecraft:honey_block
setblock 24 218 323 minecraft:honeycomb_block
setblock 24 218 363 minecraft:honeycomb_block
setblock 25 218 323 minecraft:yellow_terracotta
setblock 25 218 363 minecraft:yellow_terracotta
fill 26 218 323 29 218 323 minecraft:honeycomb_block
fill 26 218 363 29 218 363 minecraft:honeycomb_block
fill 27 218 324 28 218 324 minecraft:honeycomb_block
fill 27 218 335 27 218 337 minecraft:brown_terracotta
fill 27 218 343 27 219 344 minecraft:brown_terracotta
fill 27 218 362 30 218 362 minecraft:honeycomb_block
setblock 28 218 333 minecraft:brown_terracotta
fill 28 218 342 28 219 342 minecraft:brown_terracotta
setblock 29 218 324 minecraft:yellow_terracotta
setblock 29 218 339 minecraft:brown_terracotta
fill 29 218 346 30 219 346 minecraft:brown_terracotta
setblock 30 218 323 minecraft:yellow_terracotta
fill 30 218 324 31 219 325 minecraft:honeycomb_block
fill 30 218 332 31 218 332 minecraft:brown_terracotta
fill 30 218 342 31 219 342 minecraft:brown_terracotta
setblock 30 218 363 minecraft:yellow_terracotta
fill 31 218 322 31 221 323 minecraft:honeycomb_block
fill 31 218 343 31 219 345 minecraft:brown_terracotta
setblock 31 218 361 minecraft:honeycomb_block
setblock 31 218 362 minecraft:yellow_terracotta
fill 31 218 363 34 218 363 minecraft:honeycomb_block
fill 32 218 323 33 218 324 minecraft:honeycomb_block
setblock 32 218 339 minecraft:brown_terracotta
setblock 32 218 361 minecraft:yellow_terracotta
fill 32 218 362 35 218 362 minecraft:honeycomb_block
setblock 33 218 333 minecraft:brown_terracotta
setblock 34 218 323 minecraft:honeycomb_block
setblock 34 218 324 minecraft:yellow_terracotta
fill 34 218 334 34 218 337 minecraft:brown_terracotta
setblock 35 218 323 minecraft:yellow_terracotta
fill 35 218 324 36 220 324 minecraft:honeycomb_block
setblock 35 218 363 minecraft:yellow_terracotta
fill 36 218 323 36 221 323 minecraft:honeycomb_block
setblock 36 218 362 minecraft:yellow_terracotta
fill 36 218 363 39 218 363 minecraft:honeycomb_block
fill 37 218 362 37 221 362 minecraft:honeycomb_block
fill 39 218 362 40 218 362 minecraft:honeycomb_block
setblock 40 218 323 minecraft:yellow_terracotta
fill 40 218 361 41 218 361 minecraft:honeycomb_block
setblock 40 218 363 minecraft:yellow_terracotta
fill 41 218 323 41 220 324 minecraft:honeycomb_block
setblock 41 218 330 minecraft:honey_block
setblock 41 218 349 minecraft:honey_block
fill 41 218 358 41 221 358 minecraft:honeycomb_block
fill 41 218 360 41 219 360 minecraft:honeycomb_block
setblock 41 218 362 minecraft:yellow_terracotta
fill 41 218 363 41 221 363 minecraft:honeycomb_block
setblock 42 218 342 minecraft:yellow_concrete
setblock 1 219 340 minecraft:honeycomb_block
setblock 1 219 341 minecraft:yellow_terracotta
fill 1 219 342 1 220 344 minecraft:honeycomb_block
setblock 1 219 355 minecraft:honeycomb_block
setblock 1 219 356 minecraft:yellow_terracotta
fill 1 219 357 1 219 360 minecraft:honeycomb_block
setblock 1 219 361 minecraft:yellow_terracotta
fill 1 219 362 3 219 363 minecraft:honeycomb_block
fill 2 219 323 3 219 323 minecraft:honeycomb_block
fill 2 219 357 2 219 359 minecraft:honeycomb_block
setblock 2 219 360 minecraft:yellow_terracotta
fill 2 219 361 5 219 361 minecraft:honeycomb_block
fill 3 219 325 3 220 326 minecraft:brown_terracotta
setblock 3 219 332 minecraft:light[level=12]
setblock 3 219 339 minecraft:light[level=12]
setblock 3 219 346 minecraft:light[level=12]
setblock 3 219 353 minecraft:light[level=12]
setblock 3 219 360 minecraft:light[level=12]
setblock 4 219 323 minecraft:yellow_terracotta
fill 4 219 324 5 220 324 minecraft:brown_terracotta
fill 4 219 327 5 220 327 minecraft:brown_terracotta
setblock 4 219 362 minecraft:honeycomb_block
setblock 4 219 363 minecraft:yellow_terracotta
fill 5 219 323 8 219 323 minecraft:honeycomb_block
setblock 5 219 362 minecraft:yellow_terracotta
fill 5 219 363 8 219 363 minecraft:honeycomb_block
fill 6 219 325 6 220 326 minecraft:brown_terracotta
setblock 6 219 361 minecraft:yellow_terracotta
fill 6 219 362 9 219 362 minecraft:honeycomb_block
fill 7 219 361 7 222 361 minecraft:honeycomb_block
setblock 9 219 323 minecraft:yellow_terracotta
setblock 9 219 363 minecraft:yellow_terracotta
fill 10 219 323 10 222 323 minecraft:honeycomb_block
setblock 10 219 325 minecraft:light[level=12]
setblock 10 219 332 minecraft:light[level=12]
setblock 10 219 339 minecraft:light[level=12]
setblock 10 219 346 minecraft:light[level=12]
setblock 10 219 353 minecraft:light[level=12]
setblock 10 219 360 minecraft:light[level=12]
setblock 10 219 361 minecraft:honeycomb_block
setblock 10 219 362 minecraft:yellow_terracotta
fill 10 219 363 13 219 363 minecraft:honeycomb_block
setblock 11 219 322 minecraft:yellow_concrete
setblock 11 219 361 minecraft:yellow_terracotta
fill 11 219 362 11 222 362 minecraft:honeycomb_block
setblock 12 219 361 minecraft:honeycomb_block
fill 13 219 322 13 244 322 minecraft:honeycomb_block
setblock 14 219 323 minecraft:yellow_terracotta
setblock 14 219 363 minecraft:yellow_terracotta
fill 15 219 363 15 222 363 minecraft:honeycomb_block
setblock 17 219 323 minecraft:honey_block
setblock 17 219 325 minecraft:light[level=12]
setblock 17 219 332 minecraft:light[level=12]
setblock 17 219 339 minecraft:light[level=12]
setblock 17 219 346 minecraft:light[level=12]
setblock 17 219 353 minecraft:light[level=12]
setblock 17 219 360 minecraft:light[level=12]
fill 22 219 323 23 219 323 minecraft:honeycomb_block
setblock 23 219 363 minecraft:honeycomb_block
setblock 24 219 323 minecraft:yellow_terracotta
setblock 24 219 325 minecraft:light[level=12]
schedule function dropper:buildpart/72_8 1t
