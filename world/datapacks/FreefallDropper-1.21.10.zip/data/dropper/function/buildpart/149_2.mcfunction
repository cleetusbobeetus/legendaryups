fill 259 235 638 270 235 638 minecraft:light_gray_concrete
fill 260 235 611 269 235 611 minecraft:light_gray_concrete
fill 260 235 617 273 235 617 minecraft:light_gray_concrete
fill 260 235 618 261 235 618 minecraft:gray_concrete
fill 260 235 631 261 235 631 minecraft:gray_concrete
fill 260 235 632 274 235 632 minecraft:light_gray_concrete
fill 260 235 637 271 235 637 minecraft:light_gray_concrete
fill 261 235 605 262 273 605 minecraft:gray_concrete
fill 262 235 618 274 235 618 minecraft:light_gray_concrete
setblock 262 235 619 minecraft:gray_concrete
setblock 262 235 623 minecraft:light[level=14]
setblock 262 235 630 minecraft:gray_concrete
fill 262 235 631 274 235 631 minecraft:light_gray_concrete
fill 263 235 619 274 235 619 minecraft:light_gray_concrete
fill 263 235 620 263 235 621 minecraft:gray_concrete
fill 263 235 628 263 235 629 minecraft:gray_concrete
fill 263 235 630 274 235 630 minecraft:light_gray_concrete
fill 264 235 620 270 235 621 minecraft:light_gray_concrete
fill 264 235 622 264 235 628 minecraft:gray_concrete
fill 264 235 629 275 235 629 minecraft:light_gray_concrete
fill 265 235 622 275 235 622 minecraft:light_gray_concrete
fill 265 235 626 275 235 628 minecraft:light_gray_concrete
fill 266 235 645 267 273 645 minecraft:gray_concrete
fill 269 235 605 270 273 605 minecraft:gray_concrete
fill 269 235 614 272 235 615 minecraft:light_gray_concrete
fill 269 235 633 273 235 634 minecraft:light_gray_concrete
setblock 270 235 607 minecraft:light[level=14]
setblock 270 235 639 minecraft:light[level=14]
fill 271 235 620 274 236 620 minecraft:light_gray_concrete
fill 272 235 623 275 235 623 minecraft:light_gray_concrete
fill 272 235 625 275 235 625 minecraft:light_gray_concrete
fill 273 235 624 275 235 624 minecraft:light_gray_concrete
fill 274 235 645 275 273 645 minecraft:gray_concrete
fill 276 235 606 276 273 607 minecraft:gray_concrete
fill 276 235 614 276 273 615 minecraft:gray_concrete
fill 276 235 622 276 273 623 minecraft:gray_concrete
fill 276 235 630 276 273 631 minecraft:gray_concrete
fill 276 235 638 276 273 639 minecraft:gray_concrete
fill 238 236 620 243 236 630 minecraft:light_gray_concrete
fill 239 236 617 249 236 619 minecraft:light_gray_concrete
fill 239 236 631 247 236 633 minecraft:light_gray_concrete
fill 240 236 616 253 236 616 minecraft:light_gray_concrete
fill 240 236 634 247 236 634 minecraft:light_gray_concrete
fill 241 236 614 247 236 615 minecraft:light_gray_concrete
fill 241 236 635 256 236 636 minecraft:light_gray_concrete
fill 242 236 613 247 236 613 minecraft:light_gray_concrete
fill 242 236 637 256 236 637 minecraft:light_gray_concrete
fill 243 236 612 257 236 612 minecraft:light_gray_concrete
fill 243 236 638 256 236 638 minecraft:light_gray_concrete
fill 244 236 611 256 236 611 minecraft:light_gray_concrete
fill 244 236 620 247 236 622 minecraft:light_gray_concrete
fill 244 236 626 247 236 630 minecraft:light_gray_concrete
fill 244 236 639 268 236 639 minecraft:light_gray_concrete
fill 245 236 610 257 236 610 minecraft:light_gray_concrete
fill 245 236 640 267 236 640 minecraft:light_gray_concrete
fill 246 236 623 247 236 623 minecraft:light_gray_concrete
fill 246 236 625 247 236 625 minecraft:light_gray_concrete
fill 247 236 609 265 236 609 minecraft:light_gray_concrete
setblock 247 236 624 minecraft:light_gray_concrete
fill 247 236 641 265 236 641 minecraft:light_gray_concrete
fill 248 236 608 264 236 608 minecraft:light_gray_concrete
fill 248 236 620 248 236 621 minecraft:light_gray_concrete
fill 248 236 622 248 236 627 minecraft:gray_concrete
fill 248 236 628 248 236 632 minecraft:light_gray_concrete
fill 248 236 642 264 236 642 minecraft:light_gray_concrete
fill 249 236 620 249 236 622 minecraft:gray_concrete
fill 249 236 627 249 236 629 minecraft:gray_concrete
fill 249 236 630 249 236 632 minecraft:light_gray_concrete
fill 250 236 617 250 236 618 minecraft:light_gray_concrete
fill 250 236 619 250 236 620 minecraft:gray_concrete
fill 250 236 629 250 236 631 minecraft:gray_concrete
fill 250 236 632 251 236 634 minecraft:light_gray_concrete
fill 251 236 607 261 236 607 minecraft:light_gray_concrete
setblock 251 236 617 minecraft:light_gray_concrete
fill 251 236 618 251 236 619 minecraft:gray_concrete
setblock 251 236 631 minecraft:gray_concrete
fill 251 236 643 261 236 643 minecraft:light_gray_concrete
fill 252 236 617 252 236 618 minecraft:gray_concrete
fill 252 236 632 253 236 632 minecraft:gray_concrete
fill 252 236 633 252 236 634 minecraft:light_gray_concrete
fill 253 236 617 254 236 617 minecraft:gray_concrete
fill 253 236 633 260 236 633 minecraft:gray_concrete
fill 253 236 634 266 236 634 minecraft:light_gray_concrete
fill 254 236 616 259 236 616 minecraft:gray_concrete
fill 257 236 635 271 236 635 minecraft:light_gray_concrete
fill 258 236 613 270 236 613 minecraft:light_gray_concrete
fill 259 236 610 267 236 610 minecraft:light_gray_concrete
fill 259 236 612 269 236 612 minecraft:light_gray_concrete
fill 259 236 636 271 236 636 minecraft:light_gray_concrete
fill 259 236 638 269 236 638 minecraft:light_gray_concrete
fill 260 236 611 268 236 611 minecraft:light_gray_concrete
fill 260 236 616 272 236 616 minecraft:light_gray_concrete
fill 260 236 617 261 236 617 minecraft:gray_concrete
fill 260 236 632 262 236 632 minecraft:gray_concrete
fill 260 236 637 270 236 637 minecraft:light_gray_concrete
fill 261 236 633 266 236 633 minecraft:light_gray_concrete
fill 262 236 617 273 236 617 minecraft:light_gray_concrete
setblock 262 236 618 minecraft:gray_concrete
fill 262 236 631 263 236 631 minecraft:gray_concrete
fill 263 236 618 273 236 618 minecraft:light_gray_concrete
setblock 263 236 619 minecraft:gray_concrete
fill 263 236 630 264 236 630 minecraft:gray_concrete
fill 263 236 632 273 236 632 minecraft:light_gray_concrete
fill 264 236 619 273 236 619 minecraft:light_gray_concrete
fill 264 236 620 264 236 621 minecraft:gray_concrete
setblock 264 236 629 minecraft:gray_concrete
fill 264 236 631 273 236 631 minecraft:light_gray_concrete
fill 265 236 620 270 236 621 minecraft:light_gray_concrete
fill 265 236 622 265 236 628 minecraft:gray_concrete
fill 265 236 629 274 236 630 minecraft:light_gray_concrete
fill 266 236 622 269 236 628 minecraft:light_gray_concrete
fill 269 236 614 271 236 615 minecraft:light_gray_concrete
fill 269 236 633 272 236 634 minecraft:light_gray_concrete
fill 270 236 622 274 236 622 minecraft:light_gray_concrete
fill 270 236 626 274 236 628 minecraft:light_gray_concrete
fill 271 236 621 274 236 621 minecraft:light_gray_concrete
fill 272 236 623 274 236 623 minecraft:light_gray_concrete
fill 272 236 625 274 236 625 minecraft:light_gray_concrete
fill 273 236 624 274 236 624 minecraft:light_gray_concrete
setblock 273 236 633 minecraft:light_gray_concrete
fill 239 237 620 243 237 630 minecraft:light_gray_concrete
fill 240 237 617 247 237 619 minecraft:light_gray_concrete
fill 240 237 631 247 237 633 minecraft:light_gray_concrete
fill 241 237 616 251 237 616 minecraft:light_gray_concrete
fill 241 237 634 247 237 634 minecraft:light_gray_concrete
fill 242 237 614 247 237 615 minecraft:light_gray_concrete
fill 242 237 635 254 237 636 minecraft:light_gray_concrete
fill 243 237 613 247 237 613 minecraft:light_gray_concrete
fill 243 237 637 256 237 637 minecraft:light_gray_concrete
fill 244 237 612 257 237 612 minecraft:light_gray_concrete
fill 244 237 620 246 237 622 minecraft:light_gray_concrete
fill 244 237 626 246 237 630 minecraft:light_gray_concrete
fill 244 237 638 256 237 638 minecraft:light_gray_concrete
fill 245 237 611 256 237 611 minecraft:light_gray_concrete
fill 245 237 639 267 237 639 minecraft:light_gray_concrete
setblock 246 237 623 minecraft:light_gray_concrete
setblock 246 237 625 minecraft:light_gray_concrete
fill 247 237 610 257 237 610 minecraft:light_gray_concrete
setblock 247 237 620 minecraft:light_gray_concrete
fill 247 237 621 247 237 629 minecraft:gold_block
setblock 247 237 630 minecraft:light_gray_concrete
fill 247 237 640 265 237 640 minecraft:light_gray_concrete
fill 248 237 609 264 237 609 minecraft:light_gray_concrete
fill 248 237 617 248 237 618 minecraft:light_gray_concrete
fill 248 237 619 248 237 621 minecraft:gold_block
fill 248 237 628 248 237 630 minecraft:gold_block
fill 248 237 631 248 237 632 minecraft:light_gray_concrete
fill 248 237 641 264 237 641 minecraft:light_gray_concrete
setblock 249 237 617 minecraft:light_gray_concrete
fill 249 237 618 249 237 619 minecraft:gold_block
fill 249 237 630 249 237 632 minecraft:gold_block
fill 250 237 614 253 237 615 minecraft:light_gray_concrete
fill 250 237 617 250 237 618 minecraft:gold_block
fill 250 237 623 251 238 625 minecraft:cyan_concrete
fill 250 237 632 251 237 632 minecraft:gold_block
fill 250 237 633 250 237 634 minecraft:light_gray_concrete
fill 251 237 608 261 237 608 minecraft:light_gray_concrete
setblock 251 237 617 minecraft:gold_block
fill 251 237 620 251 238 622 minecraft:cyan_concrete
fill 251 237 626 251 238 628 minecraft:cyan_concrete
fill 251 237 633 252 237 633 minecraft:gold_block
setblock 251 237 634 minecraft:light_gray_concrete
fill 251 237 642 261 237 642 minecraft:light_gray_concrete
fill 252 237 616 253 237 616 minecraft:gold_block
fill 252 237 619 252 238 620 minecraft:cyan_concrete
fill 252 237 628 252 238 629 minecraft:cyan_concrete
fill 252 237 634 260 237 634 minecraft:gold_block
fill 253 237 618 253 238 619 minecraft:cyan_concrete
fill 253 237 629 253 238 630 minecraft:cyan_concrete
fill 254 237 614 266 237 614 minecraft:light_gray_concrete
fill 254 237 615 259 237 615 minecraft:gold_block
fill 254 237 617 254 238 618 minecraft:cyan_concrete
fill 254 237 630 254 238 631 minecraft:cyan_concrete
fill 255 237 617 262 238 617 minecraft:cyan_concrete
fill 255 237 631 262 238 631 minecraft:cyan_concrete
fill 255 237 635 257 237 635 minecraft:gold_block
fill 255 237 636 256 237 636 minecraft:light_gray_concrete
fill 257 237 616 259 238 616 minecraft:cyan_concrete
fill 257 237 632 259 238 632 minecraft:cyan_concrete
fill 258 237 613 269 237 613 minecraft:light_gray_concrete
fill 258 237 635 270 237 635 minecraft:light_gray_concrete
fill 259 237 610 265 237 610 minecraft:light_gray_concrete
fill 259 237 612 268 237 612 minecraft:light_gray_concrete
fill 259 237 636 270 237 636 minecraft:light_gray_concrete
fill 259 237 638 268 237 638 minecraft:light_gray_concrete
fill 260 237 611 267 237 611 minecraft:light_gray_concrete
fill 260 237 615 266 237 615 minecraft:light_gray_concrete
fill 260 237 616 261 237 616 minecraft:gold_block
fill 260 237 637 269 237 637 minecraft:light_gray_concrete
fill 261 237 633 262 237 633 minecraft:gold_block
fill 261 237 634 266 237 634 minecraft:light_gray_concrete
fill 262 237 616 271 237 616 minecraft:light_gray_concrete
fill 262 237 618 263 238 618 minecraft:cyan_concrete
fill 262 237 630 263 238 630 minecraft:cyan_concrete
fill 263 237 617 272 237 617 minecraft:light_gray_concrete
fill 263 237 619 264 238 619 minecraft:cyan_concrete
fill 263 237 629 264 238 629 minecraft:cyan_concrete
setblock 263 237 632 minecraft:gold_block
fill 263 237 633 266 237 633 minecraft:light_gray_concrete
setblock 264 237 618 minecraft:gold_block
fill 264 237 620 265 238 620 minecraft:cyan_concrete
fill 264 237 628 265 238 628 minecraft:cyan_concrete
setblock 264 237 631 minecraft:gold_block
fill 264 237 632 272 237 632 minecraft:light_gray_concrete
fill 265 237 618 272 237 619 minecraft:light_gray_concrete
fill 265 237 621 265 238 627 minecraft:cyan_concrete
fill 265 237 629 265 237 630 minecraft:gold_block
fill 265 237 631 272 237 631 minecraft:light_gray_concrete
fill 266 237 620 273 237 621 minecraft:light_gray_concrete
setblock 266 237 622 minecraft:gold_block
fill 266 237 623 266 238 625 minecraft:cyan_concrete
fill 266 237 626 266 237 628 minecraft:gold_block
fill 266 237 629 273 237 630 minecraft:light_gray_concrete
fill 267 237 622 269 237 628 minecraft:light_gray_concrete
fill 269 237 614 270 237 615 minecraft:light_gray_concrete
fill 269 237 633 271 237 634 minecraft:light_gray_concrete
fill 270 237 622 273 237 622 minecraft:light_gray_concrete
fill 270 237 626 273 237 628 minecraft:light_gray_concrete
fill 272 237 623 273 237 623 minecraft:light_gray_concrete
fill 272 237 625 273 237 625 minecraft:light_gray_concrete
setblock 272 237 633 minecraft:light_gray_concrete
setblock 273 237 624 minecraft:light_gray_concrete
fill 236 238 605 236 239 610 minecraft:gray_concrete
fill 236 238 613 237 238 618 minecraft:gray_concrete
fill 236 238 621 237 238 626 minecraft:gray_concrete
fill 236 238 629 237 238 634 minecraft:gray_concrete
fill 236 238 637 237 238 642 minecraft:gray_concrete
fill 236 238 645 241 239 645 minecraft:gray_concrete
fill 237 238 606 237 238 612 minecraft:gray_concrete
fill 237 238 619 237 238 620 minecraft:gray_concrete
fill 237 238 627 237 238 628 minecraft:gray_concrete
fill 237 238 635 237 238 636 minecraft:gray_concrete
fill 237 238 643 237 238 644 minecraft:gray_concrete
fill 238 238 606 275 238 606 minecraft:gray_concrete
fill 238 238 644 276 238 644 minecraft:gray_concrete
fill 239 238 605 244 239 605 minecraft:gray_concrete
fill 240 238 620 243 238 630 minecraft:light_gray_concrete
fill 241 238 618 246 238 619 minecraft:light_gray_concrete
fill 241 238 631 246 238 632 minecraft:light_gray_concrete
fill 242 238 616 247 238 617 minecraft:light_gray_concrete
fill 242 238 633 247 238 634 minecraft:light_gray_concrete
fill 243 238 615 247 238 615 minecraft:light_gray_concrete
fill 243 238 635 250 238 635 minecraft:light_gray_concrete
fill 244 238 614 247 238 614 minecraft:light_gray_concrete
fill 244 238 620 245 238 622 minecraft:light_gray_concrete
fill 244 238 626 244 238 630 minecraft:light_gray_concrete
fill 244 238 636 253 238 636 minecraft:light_gray_concrete
fill 244 238 645 249 239 645 minecraft:gray_concrete
fill 245 238 613 247 238 613 minecraft:light_gray_concrete
fill 245 238 626 246 238 627 minecraft:gray_concrete
fill 245 238 628 245 238 630 minecraft:light_gray_concrete
fill 245 238 637 256 238 637 minecraft:light_gray_concrete
fill 246 238 612 257 238 612 minecraft:light_gray_concrete
fill 246 238 620 246 238 623 minecraft:gray_concrete
setblock 246 238 625 minecraft:gray_concrete
fill 246 238 628 246 238 630 minecraft:gray_concrete
fill 246 238 638 256 238 638 minecraft:light_gray_concrete
fill 247 238 605 252 239 605 minecraft:gray_concrete
fill 247 238 611 256 238 611 minecraft:light_gray_concrete
setblock 247 238 618 minecraft:light_gray_concrete
fill 247 238 619 247 238 620 minecraft:gray_concrete
fill 247 238 630 247 238 631 minecraft:gray_concrete
setblock 247 238 632 minecraft:light_gray_concrete
fill 247 238 639 265 238 639 minecraft:light_gray_concrete
setblock 248 238 616 minecraft:light_gray_concrete
fill 248 238 617 248 238 618 minecraft:gray_concrete
fill 248 238 631 248 238 632 minecraft:gray_concrete
fill 249 238 610 257 238 610 minecraft:light_gray_concrete
fill 249 238 616 249 238 617 minecraft:gray_concrete
fill 249 238 640 263 238 640 minecraft:light_gray_concrete
fill 250 238 614 250 238 615 minecraft:light_gray_concrete
fill 250 238 616 251 238 616 minecraft:gray_concrete
fill 250 238 633 250 238 634 minecraft:gray_concrete
fill 251 238 609 261 238 609 minecraft:light_gray_concrete
fill 251 238 614 252 238 614 minecraft:light_gray_concrete
fill 251 238 615 253 238 615 minecraft:gray_concrete
fill 251 238 634 251 238 635 minecraft:gray_concrete
fill 251 238 641 261 238 641 minecraft:light_gray_concrete
fill 252 238 635 254 238 635 minecraft:gray_concrete
fill 252 238 645 257 239 645 minecraft:gray_concrete
fill 253 238 614 259 238 614 minecraft:gray_concrete
fill 254 238 636 257 238 636 minecraft:gray_concrete
fill 255 238 605 260 239 605 minecraft:gray_concrete
fill 258 238 613 267 238 613 minecraft:light_gray_concrete
fill 258 238 635 261 238 635 minecraft:gray_concrete
fill 259 238 610 263 238 610 minecraft:light_gray_concrete
fill 259 238 612 266 238 612 minecraft:light_gray_concrete
setblock 259 238 636 minecraft:gray_concrete
fill 259 238 638 266 238 638 minecraft:light_gray_concrete
fill 260 238 611 265 238 611 minecraft:light_gray_concrete
fill 260 238 614 266 238 614 minecraft:light_gray_concrete
fill 260 238 615 261 238 615 minecraft:gray_concrete
fill 260 238 636 267 238 637 minecraft:light_gray_concrete
fill 260 238 645 265 239 645 minecraft:gray_concrete
fill 261 238 634 263 238 634 minecraft:gray_concrete
fill 262 238 615 266 238 615 minecraft:light_gray_concrete
fill 262 238 616 263 238 616 minecraft:gray_concrete
fill 262 238 635 269 238 635 minecraft:light_gray_concrete
fill 263 238 605 268 239 605 minecraft:gray_concrete
fill 263 238 617 264 238 617 minecraft:gray_concrete
fill 263 238 633 264 238 633 minecraft:gray_concrete
fill 264 238 616 270 238 616 minecraft:light_gray_concrete
fill 264 238 632 265 238 632 minecraft:gray_concrete
fill 264 238 634 266 238 634 minecraft:light_gray_concrete
fill 265 238 617 270 238 617 minecraft:light_gray_concrete
fill 265 238 618 265 238 619 minecraft:gray_concrete
setblock 265 238 631 minecraft:gray_concrete
fill 265 238 633 266 238 633 minecraft:light_gray_concrete
fill 266 238 618 271 238 619 minecraft:light_gray_concrete
fill 266 238 620 266 238 621 minecraft:gray_concrete
fill 266 238 629 266 238 630 minecraft:gray_concrete
fill 266 238 631 271 238 632 minecraft:light_gray_concrete
fill 267 238 620 272 238 621 minecraft:light_gray_concrete
fill 267 238 622 267 238 628 minecraft:gray_concrete
fill 267 238 629 272 238 630 minecraft:light_gray_concrete
fill 268 238 622 269 238 628 minecraft:light_gray_concrete
setblock 268 238 636 minecraft:light_gray_concrete
fill 268 238 645 273 239 645 minecraft:gray_concrete
setblock 269 238 615 minecraft:light_gray_concrete
fill 269 238 633 270 238 634 minecraft:light_gray_concrete
fill 270 238 622 272 238 622 minecraft:light_gray_concrete
fill 270 238 626 272 238 628 minecraft:light_gray_concrete
fill 271 238 605 276 239 605 minecraft:gray_concrete
setblock 272 238 623 minecraft:light_gray_concrete
setblock 272 238 625 minecraft:light_gray_concrete
fill 275 238 607 275 238 643 minecraft:gray_concrete
fill 276 238 608 276 239 613 minecraft:gray_concrete
fill 276 238 616 276 239 621 minecraft:gray_concrete
fill 276 238 624 276 239 629 minecraft:gray_concrete
fill 276 238 632 276 239 637 minecraft:gray_concrete
fill 276 238 640 276 239 643 minecraft:gray_concrete
fill 276 238 645 276 239 645 minecraft:gray_concrete
fill 236 239 613 236 239 618 minecraft:gray_concrete
fill 236 239 621 236 239 626 minecraft:gray_concrete
fill 236 239 629 236 239 634 minecraft:gray_concrete
fill 236 239 637 236 239 642 minecraft:gray_concrete
fill 241 239 623 243 239 627 minecraft:light_gray_concrete
fill 242 239 620 244 239 622 minecraft:light_gray_concrete
fill 242 239 628 244 239 630 minecraft:light_gray_concrete
fill 243 239 618 245 239 619 minecraft:light_gray_concrete
fill 243 239 631 245 239 632 minecraft:light_gray_concrete
fill 244 239 616 246 239 617 minecraft:light_gray_concrete
setblock 244 239 623 minecraft:gray_concrete
fill 244 239 625 244 239 627 minecraft:gray_concrete
fill 244 239 633 247 239 634 minecraft:light_gray_concrete
fill 245 239 615 247 239 615 minecraft:light_gray_concrete
fill 245 239 620 245 239 622 minecraft:gray_concrete
fill 245 239 628 245 239 630 minecraft:gray_concrete
fill 245 239 635 249 239 635 minecraft:light_gray_concrete
fill 246 239 614 247 239 614 minecraft:light_gray_concrete
setblock 246 239 618 minecraft:light_gray_concrete
setblock 246 239 619 minecraft:gray_concrete
setblock 246 239 631 minecraft:gray_concrete
setblock 246 239 632 minecraft:light_gray_concrete
fill 246 239 636 250 239 636 minecraft:light_gray_concrete
fill 247 239 613 252 239 613 minecraft:light_gray_concrete
setblock 247 239 616 minecraft:light_gray_concrete
fill 247 239 617 247 239 618 minecraft:gray_concrete
setblock 247 239 632 minecraft:gray_concrete
fill 247 239 637 253 239 637 minecraft:light_gray_concrete
setblock 248 239 616 minecraft:gray_concrete
fill 249 239 612 257 239 612 minecraft:light_gray_concrete
fill 249 239 638 256 239 638 minecraft:light_gray_concrete
setblock 250 239 614 minecraft:light_gray_concrete
setblock 250 239 615 minecraft:gray_concrete
setblock 250 239 635 minecraft:gray_concrete
fill 251 239 611 256 239 611 minecraft:light_gray_concrete
fill 251 239 614 252 239 614 minecraft:gray_concrete
fill 251 239 636 253 239 636 minecraft:gray_concrete
fill 251 239 639 261 239 639 minecraft:light_gray_concrete
fill 253 239 613 259 239 613 minecraft:gray_concrete
fill 254 239 610 257 239 610 minecraft:light_gray_concrete
fill 254 239 637 256 239 637 minecraft:gray_concrete
fill 254 239 640 258 239 640 minecraft:light_gray_concrete
fill 259 239 612 263 239 612 minecraft:light_gray_concrete
fill 259 239 638 263 239 638 minecraft:light_gray_concrete
fill 260 239 611 261 239 611 minecraft:light_gray_concrete
fill 260 239 613 265 239 613 minecraft:light_gray_concrete
fill 260 239 614 261 239 614 minecraft:gray_concrete
fill 260 239 636 261 239 636 minecraft:gray_concrete
fill 260 239 637 265 239 637 minecraft:light_gray_concrete
fill 262 239 614 266 239 614 minecraft:light_gray_concrete
fill 262 239 615 263 239 615 minecraft:gray_concrete
fill 262 239 635 263 239 635 minecraft:gray_concrete
fill 262 239 636 266 239 636 minecraft:light_gray_concrete
fill 264 239 615 266 239 615 minecraft:light_gray_concrete
setblock 264 239 616 minecraft:gray_concrete
setblock 264 239 634 minecraft:gray_concrete
fill 264 239 635 267 239 635 minecraft:light_gray_concrete
fill 265 239 616 268 239 616 minecraft:light_gray_concrete
setblock 265 239 617 minecraft:gray_concrete
setblock 265 239 633 minecraft:gray_concrete
fill 265 239 634 266 239 634 minecraft:light_gray_concrete
fill 266 239 617 268 239 617 minecraft:light_gray_concrete
fill 266 239 618 266 239 619 minecraft:gray_concrete
fill 266 239 631 266 239 632 minecraft:gray_concrete
setblock 266 239 633 minecraft:light_gray_concrete
fill 267 239 618 269 239 619 minecraft:light_gray_concrete
fill 267 239 620 267 239 621 minecraft:gray_concrete
fill 267 239 629 267 239 630 minecraft:gray_concrete
fill 267 239 631 269 239 632 minecraft:light_gray_concrete
fill 268 239 620 270 239 621 minecraft:light_gray_concrete
fill 268 239 622 268 239 628 minecraft:gray_concrete
fill 268 239 629 270 239 630 minecraft:light_gray_concrete
fill 269 239 622 269 239 628 minecraft:light_gray_concrete
setblock 270 239 622 minecraft:light_gray_concrete
fill 270 239 626 270 239 628 minecraft:light_gray_concrete
fill 271 239 626 271 239 627 minecraft:light_gray_concrete
setblock 276 239 644 minecraft:gray_concrete
fill 262 240 640 262 241 640 minecraft:gold_block
fill 248 241 623 249 242 625 minecraft:lime_concrete
fill 249 241 620 249 242 622 minecraft:lime_concrete
fill 249 241 626 249 242 628 minecraft:lime_concrete
fill 250 241 618 250 242 620 minecraft:lime_concrete
fill 250 241 628 250 242 630 minecraft:lime_concrete
fill 251 241 617 251 242 618 minecraft:lime_concrete
fill 251 241 630 251 242 631 minecraft:lime_concrete
fill 252 241 616 252 242 617 minecraft:lime_concrete
fill 252 241 631 252 242 632 minecraft:lime_concrete
fill 253 241 616 254 242 616 minecraft:lime_concrete
fill 253 241 632 254 242 632 minecraft:lime_concrete
fill 254 241 615 262 242 615 minecraft:lime_concrete
fill 254 241 633 262 242 633 minecraft:lime_concrete
fill 257 241 614 259 242 614 minecraft:lime_concrete
fill 257 241 634 259 242 634 minecraft:lime_concrete
fill 262 241 616 264 242 616 minecraft:lime_concrete
fill 262 241 632 264 242 632 minecraft:lime_concrete
fill 264 241 617 265 242 617 minecraft:lime_concrete
fill 264 241 631 265 242 631 minecraft:lime_concrete
fill 265 241 618 266 242 618 minecraft:lime_concrete
fill 265 241 630 266 242 630 minecraft:lime_concrete
fill 266 241 619 266 242 620 minecraft:lime_concrete
fill 266 241 628 266 242 629 minecraft:lime_concrete
fill 267 241 620 267 242 628 minecraft:lime_concrete
fill 268 241 623 268 242 625 minecraft:lime_concrete
fill 235 242 608 235 307 608 minecraft:white_concrete
fill 235 242 609 235 247 609 minecraft:sea_lantern
fill 235 242 610 235 307 616 minecraft:white_concrete
fill 235 242 617 235 247 617 minecraft:sea_lantern
fill 235 242 623 235 307 624 minecraft:white_concrete
fill 235 242 625 235 247 625 minecraft:sea_lantern
fill 235 242 633 235 247 633 minecraft:sea_lantern
fill 235 242 640 235 307 640 minecraft:white_concrete
fill 235 242 641 235 247 641 minecraft:sea_lantern
fill 238 242 646 238 247 646 minecraft:sea_lantern
fill 239 242 646 241 307 646 minecraft:white_concrete
fill 242 242 604 242 247 604 minecraft:sea_lantern
fill 244 242 604 249 307 604 minecraft:white_concrete
fill 246 242 646 246 247 646 minecraft:sea_lantern
fill 247 242 646 253 307 646 minecraft:white_concrete
fill 250 242 604 250 247 604 minecraft:sea_lantern
fill 251 242 604 254 307 604 minecraft:white_concrete
fill 254 242 646 254 247 646 minecraft:sea_lantern
fill 255 242 646 257 307 646 minecraft:white_concrete
fill 256 242 604 257 307 604 minecraft:white_concrete
fill 258 242 604 258 247 604 minecraft:sea_lantern
fill 259 242 604 261 307 604 minecraft:white_concrete
fill 261 242 646 261 307 646 minecraft:white_concrete
fill 262 242 646 262 247 646 minecraft:sea_lantern
fill 263 242 646 264 307 646 minecraft:white_concrete
fill 266 242 604 266 247 604 minecraft:sea_lantern
fill 266 242 646 269 307 646 minecraft:white_concrete
fill 267 242 604 273 307 604 minecraft:white_concrete
fill 270 242 646 270 247 646 minecraft:sea_lantern
fill 271 242 646 271 307 646 minecraft:white_concrete
fill 274 242 604 274 247 604 minecraft:sea_lantern
fill 275 242 604 277 307 604 minecraft:white_concrete
fill 277 242 608 277 307 608 minecraft:white_concrete
fill 277 242 609 277 247 609 minecraft:sea_lantern
fill 277 242 610 277 307 612 minecraft:white_concrete
fill 277 242 614 277 307 616 minecraft:white_concrete
fill 277 242 617 277 247 617 minecraft:sea_lantern
fill 277 242 618 277 307 624 minecraft:white_concrete
fill 277 242 625 277 247 625 minecraft:sea_lantern
fill 277 242 626 277 307 629 minecraft:white_concrete
fill 277 242 633 277 247 633 minecraft:sea_lantern
fill 277 242 641 277 247 641 minecraft:sea_lantern
fill 277 242 642 277 307 644 minecraft:white_concrete
setblock 238 243 607 minecraft:light[level=14]
setblock 238 243 615 minecraft:light[level=14]
setblock 238 243 623 minecraft:light[level=14]
setblock 238 243 631 minecraft:light[level=14]
setblock 238 243 639 minecraft:light[level=14]
setblock 246 243 607 minecraft:light[level=14]
setblock 246 243 615 minecraft:light[level=14]
setblock 246 243 623 minecraft:light[level=14]
setblock 246 243 631 minecraft:light[level=14]
setblock 246 243 639 minecraft:light[level=14]
setblock 254 243 607 minecraft:light[level=14]
setblock 254 243 615 minecraft:light[level=14]
setblock 254 243 623 minecraft:light[level=14]
setblock 254 243 631 minecraft:light[level=14]
setblock 254 243 639 minecraft:light[level=14]
setblock 262 243 607 minecraft:light[level=14]
setblock 262 243 615 minecraft:light[level=14]
setblock 262 243 623 minecraft:light[level=14]
setblock 262 243 631 minecraft:light[level=14]
setblock 262 243 639 minecraft:light[level=14]
setblock 270 243 607 minecraft:light[level=14]
setblock 270 243 615 minecraft:light[level=14]
setblock 270 243 623 minecraft:light[level=14]
setblock 270 243 631 minecraft:light[level=14]
setblock 270 243 639 minecraft:light[level=14]
fill 244 247 624 246 247 624 minecraft:glowstone
setblock 245 247 623 minecraft:glowstone
setblock 245 247 625 minecraft:glowstone
fill 248 247 614 249 247 615 minecraft:glowstone
fill 248 247 633 249 247 634 minecraft:glowstone
setblock 249 247 616 minecraft:glowstone
setblock 249 247 632 minecraft:glowstone
setblock 250 247 615 minecraft:glowstone
setblock 250 247 633 minecraft:glowstone
fill 257 247 611 259 247 611 minecraft:glowstone
fill 257 247 637 259 247 637 minecraft:glowstone
setblock 258 247 610 minecraft:glowstone
setblock 258 247 612 minecraft:glowstone
setblock 258 247 636 minecraft:glowstone
setblock 258 247 638 minecraft:glowstone
fill 266 247 615 268 247 615 minecraft:glowstone
fill 266 247 633 268 247 633 minecraft:glowstone
fill 267 247 614 268 247 614 minecraft:glowstone
setblock 267 247 616 minecraft:glowstone
setblock 267 247 632 minecraft:glowstone
fill 267 247 634 268 247 634 minecraft:glowstone
fill 270 247 624 272 247 624 minecraft:glowstone
setblock 271 247 623 minecraft:glowstone
setblock 271 247 625 minecraft:glowstone
fill 235 248 609 235 255 609 minecraft:white_concrete
fill 235 248 617 235 255 617 minecraft:white_concrete
fill 235 248 625 235 255 625 minecraft:white_concrete
fill 235 248 633 235 255 633 minecraft:white_concrete
fill 235 248 641 235 255 641 minecraft:white_concrete
fill 238 248 646 238 255 646 minecraft:white_concrete
fill 242 248 604 242 255 604 minecraft:white_concrete
fill 246 248 646 246 255 646 minecraft:white_concrete
fill 250 248 604 250 255 604 minecraft:white_concrete
fill 254 248 646 254 255 646 minecraft:white_concrete
fill 258 248 604 258 255 604 minecraft:white_concrete
fill 262 248 646 262 255 646 minecraft:white_concrete
fill 266 248 604 266 255 604 minecraft:white_concrete
fill 270 248 646 270 255 646 minecraft:white_concrete
fill 274 248 604 274 255 604 minecraft:white_concrete
fill 277 248 609 277 255 609 minecraft:white_concrete
fill 277 248 617 277 255 617 minecraft:white_concrete
fill 277 248 625 277 255 625 minecraft:white_concrete
fill 277 248 633 277 255 633 minecraft:white_concrete
fill 277 248 641 277 255 641 minecraft:white_concrete
setblock 238 251 607 minecraft:light[level=14]
setblock 238 251 615 minecraft:light[level=14]
setblock 238 251 623 minecraft:light[level=14]
setblock 238 251 631 minecraft:light[level=14]
setblock 238 251 639 minecraft:light[level=14]
setblock 246 251 607 minecraft:light[level=14]
setblock 246 251 615 minecraft:light[level=14]
setblock 246 251 623 minecraft:light[level=14]
setblock 246 251 631 minecraft:light[level=14]
setblock 246 251 639 minecraft:light[level=14]
setblock 254 251 607 minecraft:light[level=14]
setblock 254 251 615 minecraft:light[level=14]
setblock 254 251 623 minecraft:light[level=14]
setblock 254 251 631 minecraft:light[level=14]
setblock 254 251 639 minecraft:light[level=14]
setblock 262 251 607 minecraft:light[level=14]
setblock 262 251 615 minecraft:light[level=14]
setblock 262 251 623 minecraft:light[level=14]
setblock 262 251 631 minecraft:light[level=14]
setblock 262 251 639 minecraft:light[level=14]
setblock 270 251 607 minecraft:light[level=14]
setblock 270 251 615 minecraft:light[level=14]
setblock 270 251 623 minecraft:light[level=14]
setblock 270 251 631 minecraft:light[level=14]
setblock 270 251 639 minecraft:light[level=14]
fill 236 252 605 236 253 610 minecraft:gray_concrete
fill 236 252 613 237 252 618 minecraft:gray_concrete
fill 236 252 621 237 252 626 minecraft:gray_concrete
fill 236 252 629 237 252 634 minecraft:gray_concrete
fill 236 252 637 237 252 642 minecraft:gray_concrete
fill 236 252 645 241 253 645 minecraft:gray_concrete
fill 237 252 606 237 252 612 minecraft:gray_concrete
fill 237 252 619 237 252 620 minecraft:gray_concrete
fill 237 252 627 237 252 628 minecraft:gray_concrete
fill 237 252 635 237 252 636 minecraft:gray_concrete
fill 237 252 643 237 252 644 minecraft:gray_concrete
fill 238 252 606 275 252 606 minecraft:gray_concrete
fill 238 252 644 276 252 644 minecraft:gray_concrete
fill 239 252 605 244 253 605 minecraft:gray_concrete
fill 244 252 645 249 253 645 minecraft:gray_concrete
fill 247 252 605 252 253 605 minecraft:gray_concrete
fill 252 252 645 257 253 645 minecraft:gray_concrete
fill 255 252 605 260 253 605 minecraft:gray_concrete
fill 260 252 645 265 253 645 minecraft:gray_concrete
fill 263 252 605 268 253 605 minecraft:gray_concrete
fill 268 252 645 273 253 645 minecraft:gray_concrete
fill 271 252 605 276 253 605 minecraft:gray_concrete
fill 275 252 607 275 252 643 minecraft:gray_concrete
fill 276 252 608 276 253 613 minecraft:gray_concrete
fill 276 252 616 276 253 621 minecraft:gray_concrete
fill 276 252 624 276 253 629 minecraft:gray_concrete
fill 276 252 632 276 253 637 minecraft:gray_concrete
fill 276 252 640 276 253 643 minecraft:gray_concrete
fill 276 252 645 276 253 645 minecraft:gray_concrete
fill 236 253 613 236 253 618 minecraft:gray_concrete
fill 236 253 621 236 253 626 minecraft:gray_concrete
fill 236 253 629 236 253 634 minecraft:gray_concrete
fill 236 253 637 236 253 642 minecraft:gray_concrete
setblock 276 253 644 minecraft:gray_concrete
fill 235 256 609 235 261 609 minecraft:sea_lantern
fill 235 256 617 235 261 617 minecraft:sea_lantern
fill 235 256 625 235 261 625 minecraft:sea_lantern
fill 235 256 633 235 261 633 minecraft:sea_lantern
fill 235 256 641 235 261 641 minecraft:sea_lantern
fill 238 256 646 238 261 646 minecraft:sea_lantern
fill 242 256 604 242 261 604 minecraft:sea_lantern
fill 246 256 646 246 261 646 minecraft:sea_lantern
fill 250 256 604 250 261 604 minecraft:sea_lantern
fill 254 256 646 254 261 646 minecraft:sea_lantern
fill 258 256 604 258 261 604 minecraft:sea_lantern
fill 262 256 646 262 261 646 minecraft:sea_lantern
fill 266 256 604 266 261 604 minecraft:sea_lantern
fill 270 256 646 270 261 646 minecraft:sea_lantern
fill 274 256 604 274 261 604 minecraft:sea_lantern
fill 277 256 609 277 261 609 minecraft:sea_lantern
fill 277 256 617 277 261 617 minecraft:sea_lantern
fill 277 256 625 277 261 625 minecraft:sea_lantern
fill 277 256 633 277 261 633 minecraft:sea_lantern
fill 277 256 641 277 261 641 minecraft:sea_lantern
setblock 238 259 607 minecraft:light[level=14]
setblock 238 259 615 minecraft:light[level=14]
setblock 238 259 623 minecraft:light[level=14]
setblock 238 259 631 minecraft:light[level=14]
setblock 238 259 639 minecraft:light[level=14]
setblock 246 259 607 minecraft:light[level=14]
setblock 246 259 615 minecraft:light[level=14]
setblock 246 259 623 minecraft:light[level=14]
setblock 246 259 631 minecraft:light[level=14]
setblock 246 259 639 minecraft:light[level=14]
setblock 254 259 607 minecraft:light[level=14]
setblock 254 259 615 minecraft:light[level=14]
setblock 254 259 623 minecraft:light[level=14]
setblock 254 259 631 minecraft:light[level=14]
setblock 254 259 639 minecraft:light[level=14]
setblock 262 259 607 minecraft:light[level=14]
setblock 262 259 615 minecraft:light[level=14]
setblock 262 259 623 minecraft:light[level=14]
setblock 262 259 631 minecraft:light[level=14]
setblock 262 259 639 minecraft:light[level=14]
setblock 270 259 607 minecraft:light[level=14]
setblock 270 259 615 minecraft:light[level=14]
setblock 270 259 623 minecraft:light[level=14]
setblock 270 259 631 minecraft:light[level=14]
setblock 270 259 639 minecraft:light[level=14]
fill 235 262 609 235 269 609 minecraft:white_concrete
fill 235 262 617 235 269 617 minecraft:white_concrete
fill 235 262 625 235 269 625 minecraft:white_concrete
fill 235 262 633 235 269 633 minecraft:white_concrete
fill 235 262 641 235 269 641 minecraft:white_concrete
fill 238 262 646 238 269 646 minecraft:white_concrete
fill 242 262 604 242 269 604 minecraft:white_concrete
fill 246 262 646 246 269 646 minecraft:white_concrete
fill 250 262 604 250 269 604 minecraft:white_concrete
fill 254 262 646 254 269 646 minecraft:white_concrete
fill 258 262 604 258 269 604 minecraft:white_concrete
fill 262 262 646 262 269 646 minecraft:white_concrete
fill 266 262 604 266 269 604 minecraft:white_concrete
fill 270 262 646 270 269 646 minecraft:white_concrete
fill 274 262 604 274 269 604 minecraft:white_concrete
fill 277 262 609 277 269 609 minecraft:white_concrete
fill 277 262 617 277 269 617 minecraft:white_concrete
fill 277 262 625 277 269 625 minecraft:white_concrete
fill 277 262 633 277 269 633 minecraft:white_concrete
fill 277 262 641 277 269 641 minecraft:white_concrete
fill 236 266 605 236 267 610 minecraft:gray_concrete
fill 236 266 613 237 266 618 minecraft:gray_concrete
fill 236 266 621 237 266 626 minecraft:gray_concrete
fill 236 266 629 237 266 634 minecraft:gray_concrete
fill 236 266 637 237 266 642 minecraft:gray_concrete
fill 236 266 645 241 267 645 minecraft:gray_concrete
fill 237 266 606 237 266 612 minecraft:gray_concrete
fill 237 266 619 237 266 620 minecraft:gray_concrete
fill 237 266 627 237 266 628 minecraft:gray_concrete
fill 237 266 635 237 266 636 minecraft:gray_concrete
fill 237 266 643 237 266 644 minecraft:gray_concrete
fill 238 266 606 275 266 606 minecraft:gray_concrete
fill 238 266 644 276 266 644 minecraft:gray_concrete
fill 239 266 605 244 267 605 minecraft:gray_concrete
fill 244 266 645 249 267 645 minecraft:gray_concrete
fill 247 266 605 252 267 605 minecraft:gray_concrete
fill 252 266 645 257 267 645 minecraft:gray_concrete
fill 255 266 605 260 267 605 minecraft:gray_concrete
fill 260 266 645 265 267 645 minecraft:gray_concrete
fill 263 266 605 268 267 605 minecraft:gray_concrete
fill 268 266 645 273 267 645 minecraft:gray_concrete
fill 271 266 605 276 267 605 minecraft:gray_concrete
fill 275 266 607 275 266 643 minecraft:gray_concrete
fill 276 266 608 276 267 613 minecraft:gray_concrete
fill 276 266 616 276 267 621 minecraft:gray_concrete
fill 276 266 624 276 267 629 minecraft:gray_concrete
fill 276 266 632 276 267 637 minecraft:gray_concrete
fill 276 266 640 276 267 643 minecraft:gray_concrete
fill 276 266 645 276 267 645 minecraft:gray_concrete
fill 236 267 613 236 267 618 minecraft:gray_concrete
fill 236 267 621 236 267 626 minecraft:gray_concrete
fill 236 267 629 236 267 634 minecraft:gray_concrete
fill 236 267 637 236 267 642 minecraft:gray_concrete
setblock 238 267 607 minecraft:light[level=14]
setblock 238 267 615 minecraft:light[level=14]
setblock 238 267 623 minecraft:light[level=14]
setblock 238 267 631 minecraft:light[level=14]
setblock 238 267 639 minecraft:light[level=14]
setblock 246 267 607 minecraft:light[level=14]
setblock 246 267 615 minecraft:light[level=14]
setblock 246 267 623 minecraft:light[level=14]
setblock 246 267 631 minecraft:light[level=14]
setblock 246 267 639 minecraft:light[level=14]
setblock 254 267 607 minecraft:light[level=14]
setblock 254 267 615 minecraft:light[level=14]
setblock 254 267 623 minecraft:light[level=14]
setblock 254 267 631 minecraft:light[level=14]
setblock 254 267 639 minecraft:light[level=14]
setblock 262 267 607 minecraft:light[level=14]
setblock 262 267 615 minecraft:light[level=14]
setblock 262 267 623 minecraft:light[level=14]
setblock 262 267 631 minecraft:light[level=14]
setblock 262 267 639 minecraft:light[level=14]
setblock 270 267 607 minecraft:light[level=14]
setblock 270 267 615 minecraft:light[level=14]
setblock 270 267 623 minecraft:light[level=14]
setblock 270 267 631 minecraft:light[level=14]
setblock 270 267 639 minecraft:light[level=14]
setblock 276 267 644 minecraft:gray_concrete
fill 235 270 609 235 273 609 minecraft:sea_lantern
fill 235 270 617 235 273 617 minecraft:sea_lantern
fill 235 270 625 235 273 625 minecraft:sea_lantern
fill 235 270 633 235 273 633 minecraft:sea_lantern
fill 235 270 641 235 273 641 minecraft:sea_lantern
fill 238 270 646 238 273 646 minecraft:sea_lantern
fill 242 270 604 242 273 604 minecraft:sea_lantern
fill 246 270 646 246 273 646 minecraft:sea_lantern
fill 250 270 604 250 273 604 minecraft:sea_lantern
fill 254 270 646 254 273 646 minecraft:sea_lantern
fill 258 270 604 258 273 604 minecraft:sea_lantern
fill 262 270 646 262 273 646 minecraft:sea_lantern
fill 266 270 604 266 273 604 minecraft:sea_lantern
fill 270 270 646 270 273 646 minecraft:sea_lantern
fill 274 270 604 274 273 604 minecraft:sea_lantern
fill 277 270 609 277 273 609 minecraft:sea_lantern
fill 277 270 617 277 273 617 minecraft:sea_lantern
fill 277 270 625 277 273 625 minecraft:sea_lantern
fill 277 270 633 277 273 633 minecraft:sea_lantern
fill 277 270 641 277 273 641 minecraft:sea_lantern
fill 252 272 642 252 273 644 minecraft:iron_block
fill 235 274 609 235 283 609 minecraft:white_concrete
fill 235 274 617 235 283 617 minecraft:white_concrete
fill 235 274 625 235 283 625 minecraft:white_concrete
fill 235 274 633 235 283 633 minecraft:white_concrete
fill 235 274 641 235 283 641 minecraft:white_concrete
fill 238 274 646 238 283 646 minecraft:white_concrete
fill 242 274 604 242 283 604 minecraft:white_concrete
fill 246 274 646 246 283 646 minecraft:white_concrete
fill 250 274 604 250 283 604 minecraft:white_concrete
fill 254 274 646 254 283 646 minecraft:white_concrete
fill 258 274 604 258 283 604 minecraft:white_concrete
fill 262 274 646 262 283 646 minecraft:white_concrete
fill 266 274 604 266 283 604 minecraft:white_concrete
fill 270 274 646 270 283 646 minecraft:white_concrete
fill 274 274 604 274 283 604 minecraft:white_concrete
fill 277 274 609 277 283 609 minecraft:white_concrete
fill 277 274 617 277 283 617 minecraft:white_concrete
fill 277 274 625 277 283 625 minecraft:white_concrete
fill 277 274 633 277 283 633 minecraft:white_concrete
fill 277 274 641 277 283 641 minecraft:white_concrete
setblock 238 275 607 minecraft:light[level=14]
setblock 238 275 615 minecraft:light[level=14]
setblock 238 275 623 minecraft:light[level=14]
setblock 238 275 631 minecraft:light[level=14]
setblock 238 275 639 minecraft:light[level=14]
setblock 246 275 607 minecraft:light[level=14]
setblock 246 275 615 minecraft:light[level=14]
setblock 246 275 623 minecraft:light[level=14]
setblock 246 275 631 minecraft:light[level=14]
setblock 246 275 639 minecraft:light[level=14]
setblock 254 275 607 minecraft:light[level=14]
setblock 254 275 615 minecraft:light[level=14]
setblock 254 275 623 minecraft:light[level=14]
setblock 254 275 631 minecraft:light[level=14]
setblock 254 275 639 minecraft:light[level=14]
setblock 262 275 607 minecraft:light[level=14]
setblock 262 275 615 minecraft:light[level=14]
setblock 262 275 623 minecraft:light[level=14]
setblock 262 275 631 minecraft:light[level=14]
setblock 262 275 639 minecraft:light[level=14]
setblock 270 275 607 minecraft:light[level=14]
setblock 270 275 615 minecraft:light[level=14]
setblock 270 275 623 minecraft:light[level=14]
setblock 270 275 631 minecraft:light[level=14]
setblock 270 275 639 minecraft:light[level=14]
fill 253 278 625 255 278 627 minecraft:redstone_block
fill 262 278 622 264 278 624 minecraft:redstone_block
fill 262 278 628 264 278 630 minecraft:redstone_block
fill 236 279 609 252 279 641 minecraft:white_concrete
fill 237 279 608 275 280 608 minecraft:white_concrete
fill 237 279 642 275 280 642 minecraft:white_concrete
fill 238 279 607 274 280 607 minecraft:white_concrete
fill 238 279 643 274 280 643 minecraft:white_concrete
fill 239 279 606 273 280 606 minecraft:white_concrete
fill 239 279 644 273 280 644 minecraft:white_concrete
fill 240 279 605 272 280 605 minecraft:white_concrete
fill 240 279 645 272 280 645 minecraft:white_concrete
fill 253 279 609 257 279 624 minecraft:white_concrete
fill 253 279 628 257 279 641 minecraft:white_concrete
fill 256 279 625 256 279 627 minecraft:white_concrete
fill 257 279 625 257 279 627 minecraft:gold_block
fill 258 279 609 261 279 623 minecraft:white_concrete
fill 258 279 624 260 279 624 minecraft:gold_block
fill 258 279 628 260 279 628 minecraft:gold_block
fill 258 279 629 261 279 641 minecraft:white_concrete
setblock 261 279 624 minecraft:white_concrete
fill 261 279 625 261 279 627 minecraft:gold_block
setblock 261 279 628 minecraft:white_concrete
fill 262 279 609 276 279 621 minecraft:white_concrete
fill 262 279 625 276 279 627 minecraft:white_concrete
fill 262 279 631 276 279 641 minecraft:white_concrete
fill 265 279 622 276 279 624 minecraft:white_concrete
fill 265 279 628 276 279 630 minecraft:white_concrete
fill 236 280 605 236 280 645 minecraft:white_concrete
fill 237 280 605 237 280 607 minecraft:white_concrete
fill 237 280 609 251 280 641 minecraft:white_concrete
fill 237 280 643 237 280 645 minecraft:white_concrete
fill 238 280 605 238 280 606 minecraft:white_concrete
fill 238 280 644 238 280 645 minecraft:white_concrete
setblock 239 280 605 minecraft:white_concrete
setblock 239 280 645 minecraft:white_concrete
fill 252 280 609 255 280 623 minecraft:white_concrete
fill 252 280 624 252 280 628 minecraft:sea_lantern
fill 252 280 629 256 280 641 minecraft:white_concrete
fill 253 280 624 261 280 624 minecraft:sea_lantern
fill 253 280 625 255 280 627 minecraft:white_concrete
fill 253 280 628 261 280 628 minecraft:sea_lantern
fill 256 280 609 257 280 622 minecraft:white_concrete
fill 256 280 623 260 280 623 minecraft:light_gray_concrete
fill 256 280 625 257 280 627 minecraft:sea_lantern
fill 257 280 629 260 280 629 minecraft:light_gray_concrete
fill 257 280 630 260 280 641 minecraft:white_concrete
fill 258 280 609 260 280 621 minecraft:white_concrete
fill 258 280 622 259 280 622 minecraft:light_gray_concrete
setblock 260 280 622 minecraft:white_concrete
fill 261 280 609 276 280 620 minecraft:white_concrete
fill 261 280 621 261 280 623 minecraft:sea_lantern
fill 261 280 625 261 280 627 minecraft:sea_lantern
fill 261 280 629 261 280 631 minecraft:sea_lantern
fill 261 280 632 276 280 641 minecraft:white_concrete
fill 262 280 621 265 280 621 minecraft:sea_lantern
fill 262 280 622 264 280 624 minecraft:white_concrete
fill 262 280 625 265 280 625 minecraft:sea_lantern
setblock 262 280 626 minecraft:light_gray_concrete
fill 262 280 627 265 280 627 minecraft:sea_lantern
fill 262 280 628 264 280 630 minecraft:white_concrete
fill 262 280 631 265 280 631 minecraft:sea_lantern
fill 263 280 626 276 280 626 minecraft:white_concrete
fill 265 280 622 265 280 624 minecraft:sea_lantern
fill 265 280 628 265 280 630 minecraft:sea_lantern
fill 266 280 621 276 283 625 minecraft:white_concrete
fill 266 280 627 276 283 631 minecraft:white_concrete
fill 273 280 605 276 280 605 minecraft:white_concrete
fill 273 280 645 276 280 645 minecraft:white_concrete
fill 274 280 606 276 280 606 minecraft:white_concrete
fill 274 280 644 276 280 644 minecraft:white_concrete
fill 275 280 607 276 280 607 minecraft:white_concrete
fill 275 280 643 276 280 643 minecraft:white_concrete
setblock 276 280 608 minecraft:white_concrete
setblock 276 280 642 minecraft:white_concrete
fill 236 281 611 252 281 639 minecraft:white_concrete
fill 237 281 610 275 281 610 minecraft:white_concrete
fill 237 281 640 275 281 640 minecraft:white_concrete
fill 238 281 609 274 281 609 minecraft:white_concrete
fill 238 281 641 274 281 641 minecraft:white_concrete
fill 239 281 608 273 281 608 minecraft:white_concrete
fill 239 281 642 273 281 642 minecraft:white_concrete
fill 240 281 607 272 281 607 minecraft:white_concrete
fill 240 281 643 272 281 643 minecraft:white_concrete
fill 241 281 606 271 281 606 minecraft:white_concrete
fill 241 281 644 271 281 644 minecraft:white_concrete
fill 242 281 605 270 281 605 minecraft:white_concrete
fill 242 281 645 270 281 645 minecraft:white_concrete
fill 253 281 611 253 281 624 minecraft:white_concrete
fill 253 281 625 254 281 627 minecraft:light_gray_concrete
fill 253 281 628 253 281 639 minecraft:white_concrete
fill 254 281 611 254 281 622 minecraft:white_concrete
fill 254 281 623 255 281 624 minecraft:light_gray_concrete
fill 254 281 628 255 281 629 minecraft:light_gray_concrete
fill 254 281 630 254 281 639 minecraft:white_concrete
fill 255 281 611 255 281 621 minecraft:white_concrete
fill 255 281 622 257 281 622 minecraft:light_gray_concrete
fill 255 281 630 261 281 630 minecraft:light_gray_concrete
fill 255 281 631 257 281 639 minecraft:white_concrete
fill 256 281 611 276 281 620 minecraft:white_concrete
fill 256 281 621 260 281 621 minecraft:light_gray_concrete
setblock 256 281 629 minecraft:light_gray_concrete
fill 258 281 631 259 281 631 minecraft:light_gray_concrete
fill 258 281 632 276 281 639 minecraft:white_concrete
fill 260 281 622 262 281 622 minecraft:light_gray_concrete
fill 260 281 631 265 281 631 minecraft:white_concrete
fill 261 281 621 265 281 621 minecraft:white_concrete
fill 261 281 629 262 281 629 minecraft:light_gray_concrete
fill 262 281 623 262 281 624 minecraft:light_gray_concrete
fill 262 281 628 263 281 628 minecraft:light_gray_concrete
fill 262 281 630 265 281 630 minecraft:white_concrete
fill 263 281 622 265 281 623 minecraft:white_concrete
fill 263 281 624 263 281 627 minecraft:light_gray_concrete
fill 263 281 629 265 281 629 minecraft:white_concrete
fill 264 281 624 265 281 628 minecraft:white_concrete
fill 266 281 626 276 283 626 minecraft:white_concrete
fill 236 282 612 250 282 638 minecraft:white_concrete
fill 237 282 611 275 282 611 minecraft:white_concrete
fill 237 282 639 275 282 639 minecraft:white_concrete
fill 238 282 610 274 282 610 minecraft:white_concrete
fill 238 282 640 274 282 640 minecraft:white_concrete
fill 239 282 609 273 282 609 minecraft:white_concrete
fill 239 282 641 273 282 641 minecraft:white_concrete
fill 240 282 608 272 282 608 minecraft:white_concrete
fill 240 282 642 272 282 642 minecraft:white_concrete
fill 241 282 607 271 282 607 minecraft:white_concrete
fill 241 282 643 271 282 643 minecraft:white_concrete
fill 242 282 606 270 282 606 minecraft:white_concrete
fill 242 282 644 270 282 644 minecraft:white_concrete
fill 243 282 605 269 282 605 minecraft:white_concrete
fill 243 282 645 269 282 645 minecraft:white_concrete
fill 251 282 612 251 282 624 minecraft:white_concrete
fill 251 282 625 252 282 626 minecraft:gold_block
fill 251 282 627 251 282 638 minecraft:white_concrete
fill 252 282 612 252 282 621 minecraft:white_concrete
fill 252 282 622 253 282 624 minecraft:gold_block
fill 252 282 627 252 282 629 minecraft:gold_block
fill 252 282 630 252 282 638 minecraft:white_concrete
fill 253 282 612 253 282 620 minecraft:white_concrete
fill 253 282 621 255 282 621 minecraft:gold_block
fill 253 282 628 253 282 630 minecraft:gold_block
fill 253 282 631 253 282 638 minecraft:white_concrete
fill 254 282 612 255 282 619 minecraft:white_concrete
fill 254 282 620 261 282 620 minecraft:gold_block
setblock 254 282 622 minecraft:gold_block
fill 254 282 630 254 282 631 minecraft:gold_block
fill 254 282 632 255 282 638 minecraft:white_concrete
fill 255 282 631 257 282 631 minecraft:gold_block
fill 256 282 612 276 282 618 minecraft:white_concrete
fill 256 282 619 259 282 619 minecraft:gold_block
fill 256 282 632 260 282 632 minecraft:gold_block
fill 256 282 633 276 282 638 minecraft:white_concrete
fill 260 282 619 276 282 619 minecraft:white_concrete
fill 260 282 631 262 282 631 minecraft:gold_block
fill 261 282 621 262 282 621 minecraft:gold_block
fill 261 282 632 276 282 632 minecraft:white_concrete
fill 262 282 620 276 282 620 minecraft:white_concrete
fill 262 282 630 263 282 630 minecraft:gold_block
fill 263 282 621 265 282 621 minecraft:white_concrete
fill 263 282 622 263 282 623 minecraft:gold_block
setblock 263 282 629 minecraft:gold_block
fill 263 282 631 265 282 631 minecraft:white_concrete
fill 264 282 622 265 282 622 minecraft:white_concrete
fill 264 282 623 264 282 628 minecraft:gold_block
fill 264 282 629 265 282 630 minecraft:white_concrete
fill 265 282 623 265 282 628 minecraft:white_concrete
fill 236 283 613 249 283 637 minecraft:white_concrete
fill 237 283 612 275 283 612 minecraft:white_concrete
fill 237 283 638 275 283 638 minecraft:white_concrete
setblock 238 283 607 minecraft:light[level=14]
fill 238 283 611 274 283 611 minecraft:white_concrete
fill 238 283 639 274 283 639 minecraft:white_concrete
fill 239 283 610 273 283 610 minecraft:white_concrete
fill 239 283 640 273 283 640 minecraft:white_concrete
fill 240 283 609 272 284 609 minecraft:white_concrete
fill 240 283 641 272 284 641 minecraft:white_concrete
fill 241 283 608 271 283 608 minecraft:white_concrete
fill 241 283 642 271 283 642 minecraft:white_concrete
fill 242 283 607 270 283 607 minecraft:white_concrete
fill 242 283 643 270 283 643 minecraft:white_concrete
fill 243 283 606 269 283 606 minecraft:white_concrete
fill 243 283 644 269 283 644 minecraft:white_concrete
fill 244 283 605 268 283 605 minecraft:white_concrete
fill 244 283 645 268 283 645 minecraft:white_concrete
fill 250 283 613 250 283 621 minecraft:white_concrete
fill 250 283 622 250 283 629 minecraft:light_gray_concrete
fill 250 283 630 250 283 637 minecraft:white_concrete
fill 251 283 613 251 283 620 minecraft:white_concrete
fill 251 283 621 251 283 624 minecraft:light_gray_concrete
fill 251 283 627 251 283 630 minecraft:light_gray_concrete
fill 251 283 631 251 283 637 minecraft:white_concrete
fill 252 283 613 252 283 619 minecraft:white_concrete
fill 252 283 620 252 283 621 minecraft:light_gray_concrete
fill 252 283 630 252 283 631 minecraft:light_gray_concrete
fill 252 283 632 252 283 637 minecraft:white_concrete
fill 253 283 613 253 283 618 minecraft:white_concrete
fill 253 283 619 253 283 620 minecraft:light_gray_concrete
fill 253 283 631 253 283 632 minecraft:light_gray_concrete
fill 253 283 633 253 283 637 minecraft:white_concrete
fill 254 283 613 276 283 617 minecraft:white_concrete
fill 254 283 618 255 283 619 minecraft:light_gray_concrete
setblock 254 283 623 minecraft:light[level=14]
setblock 254 283 631 minecraft:light[level=14]
fill 254 283 632 255 283 633 minecraft:light_gray_concrete
fill 254 283 634 276 283 637 minecraft:white_concrete
fill 256 283 618 261 283 618 minecraft:light_gray_concrete
fill 256 283 633 261 283 633 minecraft:light_gray_concrete
fill 260 283 619 262 283 619 minecraft:light_gray_concrete
fill 261 283 632 262 283 632 minecraft:light_gray_concrete
fill 262 283 618 276 283 618 minecraft:white_concrete
fill 262 283 620 263 283 620 minecraft:light_gray_concrete
setblock 262 283 623 minecraft:light[level=14]
setblock 262 283 631 minecraft:light[level=14]
fill 262 283 633 276 283 633 minecraft:white_concrete
fill 263 283 619 276 283 619 minecraft:white_concrete
fill 263 283 621 264 283 621 minecraft:light_gray_concrete
setblock 263 283 631 minecraft:light_gray_concrete
fill 263 283 632 276 283 632 minecraft:white_concrete
fill 264 283 620 276 283 620 minecraft:white_concrete
fill 264 283 622 265 283 622 minecraft:light_gray_concrete
fill 264 283 629 264 283 630 minecraft:light_gray_concrete
fill 264 283 631 265 283 631 minecraft:white_concrete
setblock 265 283 621 minecraft:white_concrete
fill 265 283 623 265 283 629 minecraft:light_gray_concrete
setblock 265 283 630 minecraft:white_concrete
fill 235 284 609 235 289 609 minecraft:sea_lantern
fill 235 284 617 235 289 617 minecraft:sea_lantern
fill 235 284 625 235 289 625 minecraft:sea_lantern
fill 235 284 633 235 289 633 minecraft:sea_lantern
fill 235 284 641 235 289 641 minecraft:sea_lantern
fill 236 284 611 236 300 612 minecraft:gray_concrete
fill 236 284 615 247 284 635 minecraft:white_concrete
fill 236 284 636 236 300 636 minecraft:gray_concrete
fill 236 284 643 236 300 644 minecraft:gray_concrete
fill 237 284 605 238 300 605 minecraft:gray_concrete
fill 237 284 613 275 284 614 minecraft:white_concrete
fill 237 284 636 275 284 637 minecraft:white_concrete
fill 238 284 612 274 284 612 minecraft:white_concrete
fill 238 284 638 274 284 638 minecraft:white_concrete
setblock 238 284 640 minecraft:black_concrete
fill 238 284 641 239 300 641 minecraft:gray_concrete
fill 238 284 642 238 284 643 minecraft:black_concrete
fill 238 284 646 238 289 646 minecraft:sea_lantern
fill 239 284 611 273 284 611 minecraft:white_concrete
fill 239 284 639 273 284 639 minecraft:white_concrete
fill 239 284 640 239 300 640 minecraft:gray_concrete
fill 239 284 642 239 300 642 minecraft:gray_concrete
fill 239 284 643 241 284 643 minecraft:black_concrete
fill 240 284 610 272 284 610 minecraft:white_concrete
fill 240 284 640 272 284 640 minecraft:white_concrete
fill 240 284 642 240 285 642 minecraft:black_concrete
fill 241 284 642 241 300 642 minecraft:gray_concrete
fill 242 284 604 242 289 604 minecraft:sea_lantern
fill 242 284 608 270 284 608 minecraft:white_concrete
fill 242 284 642 270 284 642 minecraft:white_concrete
fill 242 284 645 243 300 645 minecraft:gray_concrete
fill 243 284 607 269 284 607 minecraft:white_concrete
fill 243 284 643 269 284 643 minecraft:white_concrete
fill 244 284 606 268 284 606 minecraft:white_concrete
fill 244 284 644 268 284 644 minecraft:white_concrete
fill 245 284 605 245 300 605 minecraft:gray_concrete
fill 246 284 605 266 284 605 minecraft:white_concrete
fill 246 284 645 266 284 645 minecraft:white_concrete
fill 246 284 646 246 289 646 minecraft:sea_lantern
fill 248 284 615 248 284 621 minecraft:white_concrete
fill 248 284 622 249 284 628 minecraft:light_gray_concrete
fill 248 284 629 248 284 635 minecraft:white_concrete
fill 249 284 615 249 284 619 minecraft:white_concrete
fill 249 284 620 250 284 621 minecraft:light_gray_concrete
fill 249 284 629 249 284 630 minecraft:light_gray_concrete
fill 249 284 631 249 284 635 minecraft:white_concrete
fill 250 284 604 250 289 604 minecraft:sea_lantern
fill 250 284 615 250 284 618 minecraft:white_concrete
fill 250 284 619 252 284 619 minecraft:light_gray_concrete
fill 250 284 630 250 284 632 minecraft:light_gray_concrete
fill 250 284 633 250 284 635 minecraft:white_concrete
fill 251 284 615 252 284 617 minecraft:white_concrete
fill 251 284 618 253 284 618 minecraft:light_gray_concrete
setblock 251 284 620 minecraft:light_gray_concrete
fill 251 284 631 251 284 633 minecraft:light_gray_concrete
fill 251 284 634 252 284 635 minecraft:white_concrete
fill 252 284 632 252 284 633 minecraft:light_gray_concrete
fill 253 284 615 254 284 616 minecraft:white_concrete
fill 253 284 617 262 284 617 minecraft:light_gray_concrete
fill 253 284 633 253 284 634 minecraft:light_gray_concrete
fill 253 284 635 255 284 635 minecraft:white_concrete
fill 254 284 634 261 284 634 minecraft:light_gray_concrete
fill 254 284 646 254 289 646 minecraft:sea_lantern
fill 255 284 615 276 284 615 minecraft:white_concrete
fill 255 284 616 260 284 616 minecraft:light_gray_concrete
fill 256 284 635 259 284 635 minecraft:light_gray_concrete
fill 258 284 604 258 289 604 minecraft:sea_lantern
fill 260 284 635 276 284 635 minecraft:white_concrete
fill 261 284 616 276 284 616 minecraft:white_concrete
fill 262 284 618 263 284 618 minecraft:light_gray_concrete
fill 262 284 633 263 284 633 minecraft:light_gray_concrete
fill 262 284 634 276 284 634 minecraft:white_concrete
fill 262 284 646 262 289 646 minecraft:sea_lantern
fill 263 284 617 276 284 617 minecraft:white_concrete
fill 263 284 619 264 284 619 minecraft:light_gray_concrete
fill 263 284 632 264 284 632 minecraft:light_gray_concrete
fill 264 284 618 276 284 618 minecraft:white_concrete
fill 264 284 620 265 284 620 minecraft:light_gray_concrete
fill 264 284 631 265 284 631 minecraft:light_gray_concrete
fill 264 284 633 276 284 633 minecraft:white_concrete
fill 265 284 619 276 284 619 minecraft:white_concrete
setblock 265 284 621 minecraft:light_gray_concrete
setblock 265 284 630 minecraft:light_gray_concrete
fill 265 284 632 276 284 632 minecraft:white_concrete
fill 266 284 604 266 289 604 minecraft:sea_lantern
fill 266 284 620 276 284 621 minecraft:white_concrete
fill 266 284 622 266 284 629 minecraft:light_gray_concrete
fill 266 284 630 276 284 631 minecraft:white_concrete
fill 267 284 622 276 284 629 minecraft:white_concrete
fill 267 284 645 267 300 645 minecraft:gray_concrete
fill 269 284 605 270 300 605 minecraft:gray_concrete
fill 270 284 646 270 289 646 minecraft:sea_lantern
fill 271 284 642 273 300 642 minecraft:gray_concrete
fill 271 284 643 273 284 643 minecraft:black_concrete
fill 273 284 640 273 300 641 minecraft:gray_concrete
fill 274 284 604 274 289 604 minecraft:sea_lantern
fill 274 284 640 274 284 642 minecraft:black_concrete
fill 274 284 645 275 300 645 minecraft:gray_concrete
fill 276 284 606 276 300 607 minecraft:gray_concrete
fill 276 284 614 276 300 614 minecraft:gray_concrete
fill 276 284 638 276 300 639 minecraft:gray_concrete
fill 277 284 609 277 289 609 minecraft:sea_lantern
fill 277 284 617 277 289 617 minecraft:sea_lantern
fill 277 284 625 277 289 625 minecraft:sea_lantern
fill 277 284 633 277 289 633 minecraft:sea_lantern
fill 277 284 641 277 289 641 minecraft:sea_lantern
fill 236 285 617 245 285 633 minecraft:white_concrete
fill 236 285 635 236 300 635 minecraft:gray_concrete
fill 237 285 615 250 285 616 minecraft:white_concrete
fill 237 285 634 249 285 635 minecraft:white_concrete
fill 238 285 613 256 285 614 minecraft:white_concrete
fill 238 285 636 253 285 637 minecraft:white_concrete
fill 239 285 612 273 285 612 minecraft:white_concrete
fill 239 285 638 273 285 638 minecraft:white_concrete
fill 240 285 611 272 285 611 minecraft:white_concrete
fill 240 285 639 272 285 639 minecraft:white_concrete
fill 240 285 640 240 300 641 minecraft:gray_concrete
fill 240 285 643 240 286 643 minecraft:black_concrete
fill 241 285 610 271 285 610 minecraft:white_concrete
fill 241 285 640 271 285 640 minecraft:white_concrete
fill 241 285 641 241 300 641 minecraft:gray_concrete
fill 242 285 609 270 285 609 minecraft:white_concrete
fill 242 285 641 270 285 641 minecraft:white_concrete
fill 243 285 606 243 285 607 minecraft:black_concrete
fill 243 285 608 269 285 608 minecraft:white_concrete
fill 243 285 642 269 285 642 minecraft:white_concrete
fill 244 285 607 268 285 607 minecraft:white_concrete
fill 244 285 643 268 285 643 minecraft:white_concrete
fill 245 285 606 245 286 606 minecraft:black_concrete
fill 246 285 605 246 300 605 minecraft:gray_concrete
fill 246 285 606 266 285 606 minecraft:white_concrete
fill 246 285 617 246 285 622 minecraft:white_concrete
fill 246 285 623 247 285 628 minecraft:gold_block
fill 246 285 629 246 285 633 minecraft:white_concrete
fill 246 285 644 266 285 644 minecraft:white_concrete
fill 247 285 617 247 285 619 minecraft:white_concrete
fill 247 285 620 247 285 622 minecraft:gold_block
fill 247 285 629 248 285 630 minecraft:gold_block
fill 247 285 631 247 285 633 minecraft:white_concrete
fill 248 285 605 264 285 605 minecraft:white_concrete
fill 248 285 617 248 285 618 minecraft:white_concrete
fill 248 285 619 248 285 621 minecraft:gold_block
fill 248 285 631 249 285 632 minecraft:gold_block
setblock 248 285 633 minecraft:white_concrete
fill 248 285 645 264 285 645 minecraft:white_concrete
setblock 249 285 617 minecraft:white_concrete
fill 249 285 618 249 285 619 minecraft:gold_block
fill 249 285 633 250 285 633 minecraft:gold_block
fill 250 285 617 250 285 618 minecraft:gold_block
fill 250 285 634 252 285 634 minecraft:gold_block
fill 250 285 635 251 285 635 minecraft:white_concrete
fill 251 285 615 252 285 615 minecraft:white_concrete
fill 251 285 616 252 285 617 minecraft:gold_block
fill 252 285 635 255 285 635 minecraft:gold_block
fill 253 285 615 254 285 616 minecraft:gold_block
fill 254 285 636 260 285 636 minecraft:gold_block
fill 254 285 637 274 285 637 minecraft:white_concrete
fill 255 285 615 261 285 615 minecraft:gold_block
fill 257 285 613 274 285 613 minecraft:white_concrete
setblock 257 285 614 minecraft:gold_block
fill 258 285 614 274 285 614 minecraft:white_concrete
fill 260 285 635 262 285 635 minecraft:gold_block
fill 261 285 616 263 285 616 minecraft:gold_block
fill 261 285 636 274 285 636 minecraft:white_concrete
fill 262 285 615 275 285 615 minecraft:white_concrete
fill 262 285 634 264 285 634 minecraft:gold_block
fill 263 285 617 264 285 617 minecraft:gold_block
fill 263 285 635 275 285 635 minecraft:white_concrete
fill 264 285 616 275 285 616 minecraft:white_concrete
fill 264 285 618 265 285 618 minecraft:gold_block
fill 264 285 633 265 285 633 minecraft:gold_block
fill 265 285 617 276 285 617 minecraft:white_concrete
fill 265 285 619 266 285 619 minecraft:gold_block
setblock 265 285 632 minecraft:gold_block
fill 265 285 634 275 285 634 minecraft:white_concrete
fill 266 285 618 276 285 618 minecraft:white_concrete
fill 266 285 620 266 285 621 minecraft:gold_block
fill 266 285 630 266 285 631 minecraft:gold_block
fill 266 285 632 276 285 633 minecraft:white_concrete
fill 266 285 645 266 300 645 minecraft:gray_concrete
fill 267 285 606 267 286 606 minecraft:black_concrete
fill 267 285 619 276 285 620 minecraft:white_concrete
fill 267 285 621 267 285 630 minecraft:gold_block
fill 267 285 631 276 285 631 minecraft:white_concrete
fill 268 285 621 276 285 623 minecraft:white_concrete
fill 268 285 624 268 285 627 minecraft:gold_block
fill 268 285 628 276 285 630 minecraft:white_concrete
fill 269 285 624 276 285 627 minecraft:white_concrete
fill 271 285 641 272 300 641 minecraft:gray_concrete
fill 272 285 640 272 300 640 minecraft:gray_concrete
fill 273 285 639 274 285 639 minecraft:black_concrete
fill 276 285 615 276 300 615 minecraft:gray_concrete
fill 236 286 619 243 286 631 minecraft:white_concrete
fill 237 286 617 245 286 618 minecraft:white_concrete
fill 237 286 632 245 286 633 minecraft:white_concrete
fill 238 286 615 247 286 616 minecraft:white_concrete
fill 238 286 634 247 286 635 minecraft:white_concrete
fill 239 286 613 250 286 614 minecraft:white_concrete
fill 239 286 636 249 286 637 minecraft:white_concrete
fill 240 286 612 272 286 612 minecraft:white_concrete
fill 240 286 638 272 286 638 minecraft:white_concrete
fill 240 286 642 240 300 642 minecraft:gray_concrete
fill 240 286 644 240 287 644 minecraft:black_concrete
fill 241 286 611 271 286 611 minecraft:white_concrete
fill 241 286 639 271 286 639 minecraft:white_concrete
setblock 241 286 640 minecraft:gray_concrete
fill 242 286 610 270 286 610 minecraft:white_concrete
fill 242 286 640 270 286 640 minecraft:white_concrete
fill 243 286 605 243 286 606 minecraft:black_concrete
fill 243 286 609 269 286 609 minecraft:white_concrete
fill 243 286 641 269 286 641 minecraft:white_concrete
fill 244 286 608 268 286 608 minecraft:white_concrete
fill 244 286 619 244 286 622 minecraft:white_concrete
fill 244 286 623 245 286 627 minecraft:light_gray_concrete
fill 244 286 628 244 286 631 minecraft:white_concrete
fill 244 286 642 268 286 642 minecraft:white_concrete
setblock 245 286 619 minecraft:white_concrete
fill 245 286 620 246 286 622 minecraft:light_gray_concrete
fill 245 286 628 245 286 630 minecraft:light_gray_concrete
setblock 245 286 631 minecraft:white_concrete
fill 246 286 607 266 286 607 minecraft:white_concrete
setblock 246 286 617 minecraft:white_concrete
fill 246 286 618 247 286 619 minecraft:light_gray_concrete
fill 246 286 629 246 286 632 minecraft:light_gray_concrete
setblock 246 286 633 minecraft:white_concrete
fill 246 286 643 266 286 643 minecraft:white_concrete
fill 246 286 644 246 287 644 minecraft:black_concrete
fill 247 286 617 249 286 617 minecraft:light_gray_concrete
fill 247 286 631 247 286 633 minecraft:light_gray_concrete
fill 248 286 606 264 286 606 minecraft:white_concrete
setblock 248 286 615 minecraft:white_concrete
fill 248 286 616 250 286 616 minecraft:light_gray_concrete
setblock 248 286 618 minecraft:light_gray_concrete
fill 248 286 633 248 286 634 minecraft:light_gray_concrete
setblock 248 286 635 minecraft:white_concrete
fill 248 286 644 264 286 644 minecraft:white_concrete
fill 249 286 615 252 286 615 minecraft:light_gray_concrete
fill 249 286 634 249 286 635 minecraft:light_gray_concrete
fill 250 286 605 262 286 605 minecraft:white_concrete
fill 250 286 635 251 286 636 minecraft:light_gray_concrete
fill 250 286 637 251 286 637 minecraft:white_concrete
fill 250 286 645 262 286 645 minecraft:white_concrete
fill 251 286 613 252 286 613 minecraft:white_concrete
fill 251 286 614 256 286 614 minecraft:light_gray_concrete
fill 252 286 636 253 286 637 minecraft:light_gray_concrete
fill 253 286 613 260 286 613 minecraft:light_gray_concrete
fill 254 286 637 261 286 637 minecraft:light_gray_concrete
fill 258 286 614 262 286 614 minecraft:light_gray_concrete
fill 261 286 613 273 286 613 minecraft:white_concrete
fill 261 286 636 263 286 636 minecraft:light_gray_concrete
fill 262 286 615 264 286 615 minecraft:light_gray_concrete
fill 262 286 637 273 286 637 minecraft:white_concrete
fill 263 286 614 273 286 614 minecraft:white_concrete
fill 263 286 635 264 286 635 minecraft:light_gray_concrete
fill 264 286 616 265 286 616 minecraft:light_gray_concrete
fill 264 286 636 273 286 636 minecraft:white_concrete
fill 265 286 615 274 286 615 minecraft:white_concrete
fill 265 286 617 266 286 617 minecraft:light_gray_concrete
setblock 265 286 634 minecraft:light_gray_concrete
fill 265 286 635 274 286 635 minecraft:white_concrete
fill 266 286 616 274 286 616 minecraft:white_concrete
fill 266 286 618 267 286 618 minecraft:light_gray_concrete
fill 266 286 632 266 286 633 minecraft:light_gray_concrete
fill 266 286 634 274 286 634 minecraft:white_concrete
fill 267 286 605 267 287 605 minecraft:black_concrete
fill 267 286 617 275 286 617 minecraft:white_concrete
fill 267 286 619 267 286 620 minecraft:light_gray_concrete
fill 267 286 631 267 286 632 minecraft:light_gray_concrete
fill 267 286 633 275 286 633 minecraft:white_concrete
fill 268 286 618 275 286 619 minecraft:white_concrete
fill 268 286 620 268 286 623 minecraft:light_gray_concrete
fill 268 286 628 268 286 630 minecraft:light_gray_concrete
fill 268 286 631 275 286 632 minecraft:white_concrete
fill 269 286 620 276 286 622 minecraft:white_concrete
fill 269 286 623 269 286 627 minecraft:light_gray_concrete
fill 269 286 628 276 286 630 minecraft:white_concrete
fill 270 286 623 276 286 627 minecraft:white_concrete
fill 270 286 641 270 300 641 minecraft:gray_concrete
setblock 271 286 640 minecraft:gray_concrete
fill 274 286 639 275 286 639 minecraft:black_concrete
setblock 276 286 619 minecraft:white_concrete
setblock 276 286 631 minecraft:white_concrete
fill 236 287 619 236 300 620 minecraft:gray_concrete
fill 236 287 627 236 300 628 minecraft:gray_concrete
setblock 236 287 629 minecraft:black_concrete
fill 237 287 620 241 287 630 minecraft:white_concrete
fill 238 287 617 243 287 619 minecraft:white_concrete
fill 238 287 631 243 287 633 minecraft:white_concrete
fill 239 287 615 245 287 616 minecraft:white_concrete
fill 239 287 634 245 287 635 minecraft:white_concrete
fill 240 287 614 247 287 614 minecraft:white_concrete
fill 240 287 636 247 287 636 minecraft:white_concrete
setblock 241 287 610 minecraft:sea_lantern
fill 241 287 613 248 287 613 minecraft:white_concrete
fill 241 287 637 248 287 637 minecraft:white_concrete
setblock 241 287 640 minecraft:sea_lantern
fill 242 287 611 250 287 612 minecraft:white_concrete
fill 242 287 620 242 287 623 minecraft:white_concrete
fill 242 287 624 243 287 626 minecraft:light_gray_concrete
fill 242 287 627 242 287 630 minecraft:white_concrete
fill 242 287 638 250 287 639 minecraft:white_concrete
setblock 243 287 605 minecraft:black_concrete
fill 243 287 620 243 287 623 minecraft:light_gray_concrete
fill 243 287 627 243 287 630 minecraft:light_gray_concrete
fill 244 287 610 268 287 610 minecraft:white_concrete
setblock 244 287 617 minecraft:white_concrete
fill 244 287 618 244 287 622 minecraft:light_gray_concrete
fill 244 287 628 244 287 632 minecraft:light_gray_concrete
setblock 244 287 633 minecraft:white_concrete
fill 244 287 640 268 287 640 minecraft:white_concrete
fill 245 287 609 267 287 609 minecraft:white_concrete
fill 245 287 617 245 287 619 minecraft:light_gray_concrete
fill 245 287 631 245 287 633 minecraft:light_gray_concrete
fill 245 287 641 267 287 641 minecraft:white_concrete
fill 246 287 608 266 287 608 minecraft:white_concrete
setblock 246 287 615 minecraft:white_concrete
fill 246 287 616 246 287 617 minecraft:light_gray_concrete
fill 246 287 633 246 287 635 minecraft:light_gray_concrete
fill 246 287 642 266 287 642 minecraft:white_concrete
fill 247 287 615 247 287 616 minecraft:light_gray_concrete
fill 247 287 634 247 287 635 minecraft:light_gray_concrete
fill 248 287 607 264 287 607 minecraft:white_concrete
fill 248 287 614 248 287 615 minecraft:light_gray_concrete
fill 248 287 635 248 287 636 minecraft:light_gray_concrete
fill 248 287 643 264 287 643 minecraft:white_concrete
fill 249 287 613 250 287 614 minecraft:light_gray_concrete
fill 249 287 636 249 287 637 minecraft:light_gray_concrete
fill 250 287 637 251 287 637 minecraft:light_gray_concrete
fill 250 287 645 251 300 645 minecraft:gray_concrete
fill 251 287 606 261 287 606 minecraft:white_concrete
fill 251 287 611 253 287 611 minecraft:white_concrete
fill 251 287 612 252 287 613 minecraft:light_gray_concrete
fill 251 287 638 262 287 638 minecraft:light_gray_concrete
fill 251 287 639 253 287 639 minecraft:white_concrete
fill 251 287 644 261 287 644 minecraft:white_concrete
fill 253 287 605 254 300 605 minecraft:gray_concrete
fill 253 287 612 261 287 612 minecraft:light_gray_concrete
fill 254 287 611 258 287 611 minecraft:light_gray_concrete
fill 254 287 639 259 287 639 minecraft:light_gray_concrete
setblock 256 287 605 minecraft:black_concrete
fill 258 287 645 259 300 645 minecraft:gray_concrete
fill 259 287 611 270 287 611 minecraft:white_concrete
fill 260 287 639 270 287 639 minecraft:white_concrete
fill 261 287 605 262 300 605 minecraft:gray_concrete
fill 261 287 613 263 287 613 minecraft:light_gray_concrete
fill 262 287 612 270 287 612 minecraft:white_concrete
fill 262 287 637 263 287 637 minecraft:light_gray_concrete
fill 263 287 614 265 287 614 minecraft:light_gray_concrete
fill 263 287 638 270 287 638 minecraft:white_concrete
fill 264 287 613 271 287 613 minecraft:white_concrete
fill 264 287 636 265 287 636 minecraft:light_gray_concrete
fill 264 287 637 271 287 637 minecraft:white_concrete
fill 265 287 615 266 287 615 minecraft:light_gray_concrete
fill 265 287 635 266 287 635 minecraft:light_gray_concrete
fill 266 287 614 272 287 614 minecraft:white_concrete
fill 266 287 616 267 287 616 minecraft:light_gray_concrete
fill 266 287 634 267 287 634 minecraft:light_gray_concrete
fill 266 287 636 272 287 636 minecraft:white_concrete
fill 267 287 615 273 287 615 minecraft:white_concrete
setblock 267 287 617 minecraft:light_gray_concrete
fill 267 287 633 268 287 633 minecraft:light_gray_concrete
fill 267 287 635 273 287 635 minecraft:white_concrete
fill 268 287 616 273 287 617 minecraft:white_concrete
fill 268 287 618 268 287 619 minecraft:light_gray_concrete
fill 268 287 631 268 287 632 minecraft:light_gray_concrete
fill 268 287 634 273 287 634 minecraft:white_concrete
fill 269 287 618 274 287 618 minecraft:white_concrete
fill 269 287 619 269 287 622 minecraft:light_gray_concrete
fill 269 287 628 269 287 631 minecraft:light_gray_concrete
fill 269 287 632 274 287 633 minecraft:white_concrete
fill 270 287 619 274 287 621 minecraft:white_concrete
fill 270 287 622 270 287 628 minecraft:light_gray_concrete
fill 270 287 629 274 287 631 minecraft:white_concrete
setblock 271 287 610 minecraft:sea_lantern
fill 271 287 622 275 287 628 minecraft:white_concrete
setblock 271 287 640 minecraft:sea_lantern
setblock 274 287 617 minecraft:white_concrete
fill 275 287 620 275 287 621 minecraft:white_concrete
fill 275 287 629 275 287 630 minecraft:white_concrete
setblock 275 287 639 minecraft:black_concrete
fill 276 287 622 276 300 623 minecraft:gray_concrete
fill 276 287 630 276 300 631 minecraft:gray_concrete
fill 236 288 605 236 288 610 minecraft:gray_concrete
fill 236 288 613 239 288 618 minecraft:gray_concrete
fill 236 288 621 237 288 626 minecraft:gray_concrete
fill 236 288 629 238 288 634 minecraft:gray_concrete
fill 236 288 637 237 288 642 minecraft:gray_concrete
fill 236 288 645 241 288 645 minecraft:gray_concrete
fill 237 288 606 241 288 612 minecraft:gray_concrete
fill 237 288 619 238 288 620 minecraft:gray_concrete
fill 237 288 627 237 288 628 minecraft:gray_concrete
fill 237 288 635 240 288 636 minecraft:gray_concrete
fill 237 288 643 253 288 644 minecraft:gray_concrete
fill 238 288 621 238 288 622 minecraft:gray_concrete
fill 238 288 623 240 288 627 minecraft:white_concrete
setblock 238 288 628 minecraft:gray_concrete
fill 238 288 637 238 288 640 minecraft:gray_concrete
setblock 238 288 642 minecraft:gray_concrete
fill 239 288 605 244 288 605 minecraft:gray_concrete
fill 239 288 619 241 288 622 minecraft:white_concrete
fill 239 288 628 241 288 631 minecraft:white_concrete
fill 239 288 632 239 288 634 minecraft:gray_concrete
fill 239 288 637 241 288 639 minecraft:gray_concrete
fill 240 288 613 240 288 616 minecraft:gray_concrete
fill 240 288 617 242 288 618 minecraft:white_concrete
fill 240 288 632 242 288 633 minecraft:white_concrete
setblock 240 288 634 minecraft:gray_concrete
fill 241 288 613 241 288 614 minecraft:gray_concrete
fill 241 288 615 243 288 616 minecraft:white_concrete
setblock 241 288 623 minecraft:white_concrete
fill 241 288 624 241 289 626 minecraft:gold_block
setblock 241 288 627 minecraft:white_concrete
fill 241 288 634 243 288 635 minecraft:white_concrete
setblock 241 288 636 minecraft:gray_concrete
fill 241 288 640 245 288 640 minecraft:gray_concrete
fill 242 288 606 245 288 610 minecraft:gray_concrete
fill 242 288 614 245 288 614 minecraft:white_concrete
setblock 242 288 619 minecraft:white_concrete
fill 242 288 620 242 288 623 minecraft:gold_block
fill 242 288 627 242 288 630 minecraft:gold_block
setblock 242 288 631 minecraft:white_concrete
fill 242 288 636 245 288 636 minecraft:white_concrete
fill 242 288 641 247 288 642 minecraft:gray_concrete
fill 243 288 613 246 288 613 minecraft:white_concrete
setblock 243 288 617 minecraft:white_concrete
fill 243 288 618 243 288 619 minecraft:gold_block
fill 243 288 631 243 288 632 minecraft:gold_block
setblock 243 288 633 minecraft:white_concrete
fill 243 288 637 246 288 637 minecraft:white_concrete
fill 244 288 612 248 288 612 minecraft:white_concrete
setblock 244 288 615 minecraft:white_concrete
fill 244 288 616 244 288 617 minecraft:gold_block
fill 244 288 633 244 288 634 minecraft:gold_block
setblock 244 288 635 minecraft:white_concrete
fill 244 288 638 248 288 638 minecraft:white_concrete
fill 244 288 645 249 288 645 minecraft:gray_concrete
fill 245 288 611 250 288 611 minecraft:white_concrete
fill 245 288 615 245 288 616 minecraft:gold_block
fill 245 288 634 245 288 635 minecraft:gold_block
fill 245 288 639 250 288 639 minecraft:white_concrete
fill 246 288 606 247 288 609 minecraft:gray_concrete
fill 246 288 610 253 288 610 minecraft:white_concrete
fill 246 288 614 246 288 615 minecraft:gold_block
fill 246 288 636 247 288 636 minecraft:gold_block
fill 246 288 640 253 288 640 minecraft:white_concrete
fill 247 288 605 252 288 605 minecraft:gray_concrete
fill 247 288 613 247 288 614 minecraft:gold_block
fill 247 288 637 248 288 637 minecraft:gold_block
fill 248 288 606 249 288 608 minecraft:gray_concrete
fill 248 288 609 264 288 609 minecraft:white_concrete
setblock 248 288 613 minecraft:gold_block
fill 248 288 641 264 288 641 minecraft:white_concrete
fill 248 288 642 249 288 642 minecraft:gray_concrete
fill 249 288 612 250 288 612 minecraft:gold_block
fill 249 288 638 250 288 638 minecraft:gold_block
fill 250 288 606 253 288 607 minecraft:gray_concrete
fill 250 288 608 262 288 608 minecraft:white_concrete
fill 250 288 642 262 288 642 minecraft:white_concrete
fill 251 288 611 253 288 611 minecraft:gold_block
fill 251 288 639 253 288 639 minecraft:gold_block
fill 252 288 645 257 288 645 minecraft:gray_concrete
fill 254 288 606 275 288 606 minecraft:gray_concrete
fill 254 288 607 258 288 607 minecraft:white_concrete
fill 254 288 610 258 289 610 minecraft:gold_block
fill 254 288 640 259 289 640 minecraft:gold_block
fill 254 288 643 258 288 643 minecraft:white_concrete
fill 254 288 644 276 288 644 minecraft:gray_concrete
fill 255 288 605 260 288 605 minecraft:gray_concrete
fill 259 288 607 275 288 607 minecraft:gray_concrete
fill 259 288 610 266 288 610 minecraft:white_concrete
fill 259 288 611 261 288 611 minecraft:gold_block
fill 259 288 643 276 288 643 minecraft:gray_concrete
fill 260 288 639 262 288 639 minecraft:gold_block
fill 260 288 640 266 288 640 minecraft:white_concrete
fill 260 288 645 265 288 645 minecraft:gray_concrete
fill 262 288 611 267 288 611 minecraft:white_concrete
fill 262 288 612 263 288 612 minecraft:gold_block
fill 263 288 605 268 288 605 minecraft:gray_concrete
fill 263 288 608 276 288 608 minecraft:gray_concrete
setblock 263 288 638 minecraft:gold_block
fill 263 288 639 267 288 639 minecraft:white_concrete
fill 263 288 642 270 288 642 minecraft:gray_concrete
fill 264 288 612 268 288 612 minecraft:white_concrete
fill 264 288 613 265 288 613 minecraft:gold_block
fill 264 288 637 265 288 637 minecraft:gold_block
fill 264 288 638 268 288 638 minecraft:white_concrete
fill 265 288 609 276 288 609 minecraft:gray_concrete
fill 265 288 641 269 288 641 minecraft:gray_concrete
fill 266 288 613 269 288 613 minecraft:white_concrete
setblock 266 288 614 minecraft:gold_block
setblock 266 288 636 minecraft:gold_block
fill 266 288 637 269 288 637 minecraft:white_concrete
fill 267 288 610 276 288 610 minecraft:gray_concrete
fill 267 288 614 270 288 614 minecraft:white_concrete
setblock 267 288 615 minecraft:gold_block
setblock 267 288 635 minecraft:gold_block
fill 267 288 636 270 288 636 minecraft:white_concrete
fill 267 288 640 271 288 640 minecraft:gray_concrete
fill 268 288 615 271 288 615 minecraft:white_concrete
fill 268 288 616 268 288 617 minecraft:gold_block
setblock 268 288 634 minecraft:gold_block
fill 268 288 635 271 288 635 minecraft:white_concrete
fill 268 288 645 273 288 645 minecraft:gray_concrete
fill 269 288 616 271 288 617 minecraft:white_concrete
setblock 269 288 618 minecraft:gold_block
fill 269 288 632 269 288 633 minecraft:gold_block
fill 269 288 634 271 288 634 minecraft:white_concrete
fill 270 288 618 272 288 618 minecraft:white_concrete
fill 270 288 619 270 288 621 minecraft:gold_block
fill 270 288 629 270 288 631 minecraft:gold_block
fill 270 288 632 272 288 633 minecraft:white_concrete
fill 271 288 605 276 288 605 minecraft:gray_concrete
fill 271 288 611 275 288 614 minecraft:gray_concrete
fill 271 288 619 273 288 621 minecraft:white_concrete
fill 271 288 622 271 289 628 minecraft:gold_block
fill 271 288 629 273 288 631 minecraft:white_concrete
fill 271 288 636 275 288 639 minecraft:gray_concrete
fill 272 288 615 275 288 616 minecraft:gray_concrete
setblock 272 288 617 minecraft:white_concrete
fill 272 288 622 273 288 628 minecraft:white_concrete
fill 272 288 634 276 288 635 minecraft:gray_concrete
fill 273 288 617 276 288 618 minecraft:gray_concrete
fill 273 288 632 276 288 633 minecraft:gray_concrete
fill 274 288 619 275 288 622 minecraft:gray_concrete
fill 274 288 623 274 288 627 minecraft:white_concrete
fill 274 288 628 275 288 631 minecraft:gray_concrete
fill 274 288 640 276 288 642 minecraft:gray_concrete
fill 275 288 623 275 288 627 minecraft:gray_concrete
fill 276 288 611 276 288 613 minecraft:gray_concrete
setblock 276 288 616 minecraft:gray_concrete
fill 276 288 619 276 288 621 minecraft:gray_concrete
fill 276 288 624 276 288 629 minecraft:gray_concrete
fill 276 288 636 276 288 637 minecraft:gray_concrete
setblock 276 288 645 minecraft:gray_concrete
fill 241 289 610 241 289 623 minecraft:gold_block
fill 241 289 627 241 289 640 minecraft:gold_block
fill 242 289 610 253 289 610 minecraft:gold_block
fill 242 289 640 253 289 640 minecraft:gold_block
fill 259 289 610 271 289 610 minecraft:gold_block
fill 260 289 640 271 289 640 minecraft:gold_block
fill 271 289 611 271 289 621 minecraft:gold_block
fill 271 289 629 271 289 639 minecraft:gold_block
fill 235 290 609 235 297 609 minecraft:white_concrete
fill 235 290 617 235 297 617 minecraft:white_concrete
fill 235 290 625 235 297 625 minecraft:white_concrete
fill 235 290 633 235 297 633 minecraft:white_concrete
fill 235 290 641 235 297 641 minecraft:white_concrete
fill 238 290 646 238 297 646 minecraft:white_concrete
fill 241 290 640 241 300 640 minecraft:gray_concrete
fill 242 290 604 242 297 604 minecraft:white_concrete
fill 246 290 646 246 297 646 minecraft:white_concrete
fill 250 290 604 250 297 604 minecraft:white_concrete
fill 254 290 646 254 297 646 minecraft:white_concrete
fill 258 290 604 258 297 604 minecraft:white_concrete
fill 262 290 646 262 297 646 minecraft:white_concrete
fill 266 290 604 266 297 604 minecraft:white_concrete
fill 270 290 646 270 297 646 minecraft:white_concrete
fill 271 290 640 271 300 640 minecraft:gray_concrete
fill 274 290 604 274 297 604 minecraft:white_concrete
fill 277 290 609 277 297 609 minecraft:white_concrete
fill 277 290 617 277 297 617 minecraft:white_concrete
fill 277 290 625 277 297 625 minecraft:white_concrete
fill 277 290 633 277 297 633 minecraft:white_concrete
fill 277 290 641 277 297 641 minecraft:white_concrete
setblock 238 291 607 minecraft:light[level=14]
setblock 238 291 615 minecraft:light[level=14]
setblock 238 291 623 minecraft:light[level=14]
setblock 238 291 631 minecraft:light[level=14]
setblock 238 291 639 minecraft:light[level=14]
setblock 246 291 607 minecraft:light[level=14]
setblock 246 291 615 minecraft:light[level=14]
setblock 246 291 623 minecraft:light[level=14]
setblock 246 291 631 minecraft:light[level=14]
setblock 246 291 639 minecraft:light[level=14]
setblock 254 291 607 minecraft:light[level=14]
setblock 254 291 615 minecraft:light[level=14]
setblock 254 291 623 minecraft:light[level=14]
setblock 254 291 631 minecraft:light[level=14]
setblock 254 291 639 minecraft:light[level=14]
setblock 262 291 607 minecraft:light[level=14]
setblock 262 291 615 minecraft:light[level=14]
setblock 262 291 623 minecraft:light[level=14]
setblock 262 291 631 minecraft:light[level=14]
setblock 262 291 639 minecraft:light[level=14]
setblock 270 291 607 minecraft:light[level=14]
setblock 270 291 615 minecraft:light[level=14]
setblock 270 291 623 minecraft:light[level=14]
setblock 270 291 631 minecraft:light[level=14]
setblock 270 291 639 minecraft:light[level=14]
setblock 238 292 640 minecraft:black_concrete
fill 238 292 642 238 292 643 minecraft:black_concrete
fill 239 292 639 241 292 639 minecraft:black_concrete
fill 239 292 643 241 292 643 minecraft:black_concrete
fill 242 292 640 242 292 642 minecraft:black_concrete
fill 270 292 639 270 292 640 minecraft:black_concrete
setblock 270 292 642 minecraft:black_concrete
fill 271 292 639 273 292 639 minecraft:black_concrete
fill 271 292 643 273 292 643 minecraft:black_concrete
fill 274 292 640 274 292 642 minecraft:black_concrete
fill 236 294 605 236 295 610 minecraft:gray_concrete
fill 236 294 613 237 294 618 minecraft:gray_concrete
fill 236 294 621 237 294 626 minecraft:gray_concrete
fill 236 294 629 237 294 634 minecraft:gray_concrete
fill 236 294 637 237 294 642 minecraft:gray_concrete
fill 236 294 645 241 295 645 minecraft:gray_concrete
fill 237 294 606 237 294 612 minecraft:gray_concrete
fill 237 294 619 237 294 620 minecraft:gray_concrete
fill 237 294 627 237 294 628 minecraft:gray_concrete
fill 237 294 635 237 294 636 minecraft:gray_concrete
fill 237 294 643 237 294 644 minecraft:gray_concrete
fill 238 294 606 275 294 606 minecraft:gray_concrete
fill 238 294 644 276 294 644 minecraft:gray_concrete
fill 239 294 605 244 295 605 minecraft:gray_concrete
fill 244 294 645 249 295 645 minecraft:gray_concrete
fill 247 294 605 252 295 605 minecraft:gray_concrete
fill 252 294 645 257 295 645 minecraft:gray_concrete
fill 255 294 605 260 295 605 minecraft:gray_concrete
fill 260 294 645 265 295 645 minecraft:gray_concrete
fill 263 294 605 268 295 605 minecraft:gray_concrete
fill 268 294 645 273 295 645 minecraft:gray_concrete
fill 271 294 605 276 295 605 minecraft:gray_concrete
fill 275 294 607 275 294 643 minecraft:gray_concrete
fill 276 294 608 276 295 613 minecraft:gray_concrete
fill 276 294 616 276 295 621 minecraft:gray_concrete
fill 276 294 624 276 295 629 minecraft:gray_concrete
fill 276 294 632 276 295 637 minecraft:gray_concrete
fill 276 294 640 276 295 643 minecraft:gray_concrete
fill 276 294 645 276 295 645 minecraft:gray_concrete
fill 236 295 613 236 295 618 minecraft:gray_concrete
fill 236 295 621 236 295 626 minecraft:gray_concrete
fill 236 295 629 236 295 634 minecraft:gray_concrete
fill 236 295 637 236 295 642 minecraft:gray_concrete
fill 249 295 642 249 296 644 minecraft:iron_block
fill 257 295 614 259 296 614 minecraft:gold_block
fill 258 295 615 259 296 615 minecraft:gold_block
setblock 276 295 644 minecraft:gray_concrete
fill 235 298 609 235 300 609 minecraft:sea_lantern
fill 235 298 617 235 300 617 minecraft:sea_lantern
fill 235 298 625 235 300 625 minecraft:sea_lantern
fill 235 298 633 235 300 633 minecraft:sea_lantern
fill 235 298 641 235 300 641 minecraft:sea_lantern
fill 238 298 646 238 300 646 minecraft:sea_lantern
fill 242 298 604 242 300 604 minecraft:sea_lantern
fill 246 298 646 246 300 646 minecraft:sea_lantern
fill 250 298 604 250 300 604 minecraft:sea_lantern
fill 254 298 646 254 300 646 minecraft:sea_lantern
fill 258 298 604 258 300 604 minecraft:sea_lantern
fill 262 298 646 262 300 646 minecraft:sea_lantern
fill 266 298 604 266 300 604 minecraft:sea_lantern
fill 270 298 646 270 300 646 minecraft:sea_lantern
fill 274 298 604 274 300 604 minecraft:sea_lantern
fill 277 298 609 277 300 609 minecraft:sea_lantern
fill 277 298 617 277 300 617 minecraft:sea_lantern
fill 277 298 625 277 300 625 minecraft:sea_lantern
fill 277 298 633 277 300 633 minecraft:sea_lantern
fill 277 298 641 277 300 641 minecraft:sea_lantern
setblock 238 299 607 minecraft:light[level=14]
setblock 238 299 615 minecraft:light[level=14]
setblock 238 299 623 minecraft:light[level=14]
setblock 238 299 631 minecraft:light[level=14]
setblock 238 299 639 minecraft:light[level=14]
fill 238 299 640 238 300 640 minecraft:gold_block
fill 238 299 642 238 300 642 minecraft:gold_block
fill 239 299 639 240 300 639 minecraft:gold_block
fill 239 299 643 241 300 643 minecraft:gold_block
fill 242 299 641 242 300 641 minecraft:gold_block
setblock 246 299 607 minecraft:light[level=14]
setblock 246 299 615 minecraft:light[level=14]
setblock 246 299 623 minecraft:light[level=14]
setblock 246 299 631 minecraft:light[level=14]
setblock 246 299 639 minecraft:light[level=14]
setblock 254 299 607 minecraft:light[level=14]
setblock 254 299 615 minecraft:light[level=14]
setblock 254 299 623 minecraft:light[level=14]
setblock 254 299 631 minecraft:light[level=14]
setblock 254 299 639 minecraft:light[level=14]
setblock 262 299 607 minecraft:light[level=14]
setblock 262 299 615 minecraft:light[level=14]
setblock 262 299 623 minecraft:light[level=14]
setblock 262 299 631 minecraft:light[level=14]
setblock 262 299 639 minecraft:light[level=14]
setblock 270 299 607 minecraft:light[level=14]
setblock 270 299 615 minecraft:light[level=14]
setblock 270 299 623 minecraft:light[level=14]
setblock 270 299 631 minecraft:light[level=14]
setblock 270 299 639 minecraft:light[level=14]
fill 270 299 640 270 300 640 minecraft:gold_block
fill 270 299 642 270 300 642 minecraft:gold_block
fill 271 299 639 273 300 639 minecraft:gold_block
fill 271 299 643 272 300 643 minecraft:gold_block
fill 274 299 641 274 300 641 minecraft:gold_block
fill 235 301 609 235 307 609 minecraft:white_concrete
fill 235 301 617 235 307 617 minecraft:white_concrete
fill 235 301 625 235 307 625 minecraft:white_concrete
fill 235 301 633 235 307 633 minecraft:white_concrete
fill 235 301 641 235 307 641 minecraft:white_concrete
fill 238 301 646 238 307 646 minecraft:white_concrete
fill 242 301 604 242 307 604 minecraft:white_concrete
fill 246 301 646 246 307 646 minecraft:white_concrete
fill 250 301 604 250 307 604 minecraft:white_concrete
fill 254 301 646 254 307 646 minecraft:white_concrete
fill 258 301 604 258 307 604 minecraft:white_concrete
fill 262 301 646 262 307 646 minecraft:white_concrete
fill 266 301 604 266 307 604 minecraft:white_concrete
fill 270 301 646 270 307 646 minecraft:white_concrete
fill 274 301 604 274 307 604 minecraft:white_concrete
fill 277 301 609 277 307 609 minecraft:white_concrete
fill 277 301 617 277 307 617 minecraft:white_concrete
fill 277 301 625 277 307 625 minecraft:white_concrete
fill 277 301 633 277 307 633 minecraft:white_concrete
fill 277 301 641 277 307 641 minecraft:white_concrete
