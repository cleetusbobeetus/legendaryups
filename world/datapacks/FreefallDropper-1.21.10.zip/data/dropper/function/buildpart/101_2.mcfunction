fill 241 285 444 245 285 444 minecraft:obsidian
fill 242 285 424 251 285 424 minecraft:obsidian
fill 242 285 442 244 285 443 minecraft:obsidian
fill 243 285 423 254 285 423 minecraft:obsidian
fill 243 285 428 246 285 428 minecraft:obsidian
setblock 243 285 434 minecraft:obsidian
fill 243 285 441 244 285 441 minecraft:obsidian
fill 244 285 431 244 285 432 minecraft:obsidian
setblock 244 285 433 minecraft:purple_concrete
fill 245 285 448 248 285 448 minecraft:obsidian
fill 246 285 427 247 285 427 minecraft:obsidian
fill 246 285 447 247 285 447 minecraft:obsidian
fill 246 285 449 249 285 454 minecraft:obsidian
setblock 249 285 425 minecraft:obsidian
fill 250 285 450 250 285 454 minecraft:obsidian
fill 251 285 450 251 285 451 minecraft:purple_concrete
fill 252 285 451 254 285 453 minecraft:obsidian
fill 255 285 452 256 285 453 minecraft:obsidian
fill 258 285 452 265 285 452 minecraft:obsidian
fill 261 285 416 262 307 416 minecraft:black_concrete
fill 262 285 423 264 285 423 minecraft:obsidian
fill 262 285 451 265 285 451 minecraft:obsidian
fill 265 285 423 265 285 424 minecraft:purple_concrete
fill 265 285 450 274 285 450 minecraft:obsidian
fill 266 285 423 270 285 424 minecraft:obsidian
fill 267 285 425 270 285 425 minecraft:obsidian
fill 267 285 449 275 285 449 minecraft:obsidian
fill 268 285 426 270 285 426 minecraft:obsidian
fill 268 285 448 275 285 448 minecraft:obsidian
setblock 269 285 416 minecraft:white_concrete
fill 269 285 427 270 285 427 minecraft:obsidian
fill 269 285 447 270 285 447 minecraft:obsidian
fill 270 285 446 276 285 446 minecraft:obsidian
fill 271 285 429 275 285 430 minecraft:obsidian
fill 271 285 444 277 285 445 minecraft:obsidian
fill 272 285 431 272 285 433 minecraft:obsidian
setblock 272 285 441 minecraft:purple_concrete
fill 272 285 442 277 285 443 minecraft:obsidian
fill 273 285 431 274 285 432 minecraft:obsidian
fill 273 285 436 273 285 440 minecraft:obsidian
setblock 273 285 458 minecraft:crying_obsidian
fill 274 285 436 277 285 438 minecraft:obsidian
fill 275 285 432 277 286 432 minecraft:obsidian
fill 276 285 429 277 286 429 minecraft:obsidian
setblock 236 286 458 minecraft:white_concrete
fill 239 286 429 242 286 430 minecraft:obsidian
fill 239 286 436 240 286 436 minecraft:obsidian
fill 240 286 445 242 286 447 minecraft:obsidian
fill 241 286 425 244 286 426 minecraft:obsidian
fill 241 286 431 241 286 433 minecraft:obsidian
setblock 241 286 434 minecraft:purple_concrete
fill 241 286 440 241 286 442 minecraft:obsidian
fill 241 286 444 242 286 444 minecraft:obsidian
fill 242 286 424 246 286 424 minecraft:obsidian
fill 243 286 423 248 286 423 minecraft:obsidian
fill 243 286 427 244 286 427 minecraft:purple_concrete
setblock 243 286 428 minecraft:obsidian
fill 243 286 446 243 286 447 minecraft:obsidian
setblock 244 286 447 minecraft:obsidian
setblock 245 286 425 minecraft:obsidian
fill 246 286 420 255 286 420 minecraft:obsidian
fill 246 286 450 246 286 454 minecraft:obsidian
fill 247 286 451 248 286 454 minecraft:obsidian
fill 248 286 421 251 286 421 minecraft:obsidian
setblock 249 286 422 minecraft:purple_concrete
fill 249 286 452 249 286 454 minecraft:obsidian
fill 250 286 453 251 286 454 minecraft:obsidian
fill 253 286 454 255 286 455 minecraft:obsidian
fill 256 286 455 258 286 455 minecraft:obsidian
setblock 259 286 458 minecraft:amethyst_block
fill 261 286 420 263 286 420 minecraft:obsidian
fill 261 286 454 270 286 454 minecraft:obsidian
fill 265 286 421 270 286 421 minecraft:obsidian
fill 265 286 453 268 286 453 minecraft:obsidian
fill 267 286 422 270 286 422 minecraft:obsidian
setblock 267 286 452 minecraft:purple_concrete
fill 268 286 423 270 286 423 minecraft:obsidian
fill 268 286 451 273 286 451 minecraft:obsidian
fill 269 286 416 269 307 416 minecraft:black_concrete
setblock 270 286 424 minecraft:obsidian
fill 270 286 450 274 286 450 minecraft:obsidian
fill 271 286 449 275 286 449 minecraft:obsidian
fill 272 286 426 275 286 427 minecraft:obsidian
fill 272 286 447 273 286 447 minecraft:purple_concrete
fill 272 286 448 275 286 448 minecraft:obsidian
fill 273 286 428 275 286 428 minecraft:obsidian
fill 273 286 446 276 286 446 minecraft:obsidian
fill 273 286 458 273 307 458 minecraft:black_concrete
fill 274 286 429 275 286 430 minecraft:obsidian
fill 274 286 444 277 286 445 minecraft:obsidian
fill 275 286 434 277 286 434 minecraft:obsidian
setblock 275 286 440 minecraft:purple_concrete
fill 275 286 441 277 286 443 minecraft:obsidian
fill 276 286 435 277 286 438 minecraft:obsidian
setblock 277 286 452 minecraft:crying_obsidian
setblock 235 287 423 minecraft:crying_obsidian
setblock 236 287 416 minecraft:amethyst_block
fill 236 287 458 236 301 458 minecraft:black_concrete
fill 258 287 416 258 307 416 minecraft:black_concrete
fill 258 287 458 259 307 458 minecraft:black_concrete
setblock 277 287 419 minecraft:crying_obsidian
fill 277 287 429 277 299 434 minecraft:black_concrete
setblock 277 287 435 minecraft:white_concrete
fill 277 287 436 277 287 445 minecraft:black_concrete
setblock 277 287 448 minecraft:white_concrete
fill 277 287 452 277 307 452 minecraft:black_concrete
fill 235 288 423 235 307 423 minecraft:black_concrete
fill 235 288 424 235 290 424 minecraft:purple_concrete
setblock 235 288 439 minecraft:white_concrete
fill 235 288 440 235 290 440 minecraft:purple_concrete
setblock 235 288 444 minecraft:white_concrete
setblock 235 288 445 minecraft:crying_obsidian
fill 235 288 456 235 290 456 minecraft:purple_concrete
fill 236 288 416 236 307 416 minecraft:black_concrete
setblock 238 288 419 minecraft:light[level=12]
setblock 238 288 427 minecraft:light[level=12]
setblock 238 288 435 minecraft:light[level=12]
setblock 238 288 443 minecraft:light[level=12]
setblock 238 288 451 minecraft:light[level=12]
fill 239 288 416 239 290 416 minecraft:purple_concrete
setblock 246 288 419 minecraft:light[level=12]
setblock 246 288 427 minecraft:light[level=12]
setblock 246 288 435 minecraft:light[level=12]
setblock 246 288 443 minecraft:light[level=12]
setblock 246 288 451 minecraft:light[level=12]
fill 249 288 458 249 290 458 minecraft:purple_concrete
setblock 254 288 419 minecraft:light[level=12]
setblock 254 288 427 minecraft:light[level=12]
setblock 254 288 435 minecraft:light[level=12]
setblock 254 288 443 minecraft:light[level=12]
setblock 254 288 451 minecraft:light[level=12]
fill 255 288 416 255 290 416 minecraft:purple_concrete
setblock 262 288 419 minecraft:light[level=12]
setblock 262 288 427 minecraft:light[level=12]
setblock 262 288 435 minecraft:light[level=12]
setblock 262 288 443 minecraft:light[level=12]
setblock 262 288 451 minecraft:light[level=12]
fill 265 288 458 265 290 458 minecraft:purple_concrete
setblock 270 288 419 minecraft:light[level=12]
setblock 270 288 427 minecraft:light[level=12]
setblock 270 288 435 minecraft:light[level=12]
setblock 270 288 443 minecraft:light[level=12]
setblock 270 288 451 minecraft:light[level=12]
fill 271 288 416 271 290 416 minecraft:purple_concrete
fill 277 288 419 277 305 419 minecraft:black_concrete
setblock 277 288 420 minecraft:amethyst_block
fill 277 288 426 277 290 426 minecraft:purple_concrete
fill 277 288 435 277 289 441 minecraft:black_concrete
fill 277 288 442 277 290 442 minecraft:purple_concrete
fill 277 288 443 277 302 445 minecraft:black_concrete
fill 277 288 448 277 298 448 minecraft:black_concrete
setblock 277 288 451 minecraft:amethyst_block
setblock 235 289 420 minecraft:amethyst_block
fill 235 289 439 235 307 439 minecraft:black_concrete
fill 235 289 444 235 307 445 minecraft:black_concrete
setblock 235 289 448 minecraft:white_concrete
fill 235 289 449 235 307 449 minecraft:black_concrete
setblock 240 289 458 minecraft:amethyst_block
setblock 241 289 416 minecraft:crying_obsidian
setblock 268 289 416 minecraft:crying_obsidian
setblock 274 289 416 minecraft:amethyst_block
setblock 275 289 458 minecraft:white_concrete
fill 277 289 420 277 307 420 minecraft:black_concrete
setblock 277 289 423 minecraft:crying_obsidian
setblock 277 289 425 minecraft:crying_obsidian
fill 277 289 451 277 307 451 minecraft:black_concrete
fill 235 290 420 235 302 420 minecraft:black_concrete
fill 235 290 448 235 293 448 minecraft:black_concrete
fill 240 290 458 240 302 458 minecraft:black_concrete
fill 241 290 416 241 302 416 minecraft:black_concrete
setblock 245 290 458 minecraft:white_concrete
fill 268 290 416 268 307 416 minecraft:black_concrete
fill 274 290 416 274 307 416 minecraft:black_concrete
fill 275 290 458 275 292 458 minecraft:black_concrete
fill 277 290 423 277 291 423 minecraft:black_concrete
setblock 277 290 425 minecraft:black_concrete
fill 277 290 435 277 297 437 minecraft:black_concrete
setblock 277 290 438 minecraft:crying_obsidian
fill 277 290 439 277 307 441 minecraft:black_concrete
fill 235 291 424 235 296 424 minecraft:black_concrete
fill 235 291 440 235 296 440 minecraft:black_concrete
fill 235 291 456 235 296 456 minecraft:black_concrete
fill 239 291 416 239 296 416 minecraft:black_concrete
setblock 245 291 416 minecraft:white_concrete
fill 245 291 458 245 307 458 minecraft:black_concrete
setblock 248 291 458 minecraft:amethyst_block
fill 249 291 458 249 296 458 minecraft:black_concrete
fill 255 291 416 255 296 416 minecraft:black_concrete
fill 265 291 458 265 296 458 minecraft:black_concrete
fill 271 291 416 271 296 416 minecraft:black_concrete
setblock 277 291 425 minecraft:amethyst_block
fill 277 291 426 277 296 426 minecraft:black_concrete
fill 277 291 438 277 302 438 minecraft:black_concrete
fill 277 291 442 277 296 442 minecraft:black_concrete
fill 242 292 448 243 293 449 minecraft:crying_obsidian
fill 243 292 450 243 293 450 minecraft:crying_obsidian
fill 245 292 416 245 307 416 minecraft:black_concrete
fill 248 292 458 248 307 458 minecraft:black_concrete
setblock 251 292 416 minecraft:amethyst_block
setblock 267 292 458 minecraft:white_concrete
setblock 277 292 423 minecraft:crying_obsidian
fill 277 292 425 277 307 425 minecraft:black_concrete
fill 251 293 416 251 307 416 minecraft:black_concrete
fill 267 293 458 267 297 458 minecraft:black_concrete
fill 268 293 429 269 294 430 minecraft:crying_obsidian
fill 270 293 430 270 294 430 minecraft:crying_obsidian
setblock 275 293 458 minecraft:amethyst_block
setblock 276 293 416 minecraft:amethyst_block
fill 277 293 423 277 299 423 minecraft:black_concrete
setblock 235 294 448 minecraft:crying_obsidian
setblock 253 294 416 minecraft:white_concrete
setblock 256 294 416 minecraft:crying_obsidian
fill 275 294 458 275 307 458 minecraft:black_concrete
fill 276 294 416 276 295 416 minecraft:black_concrete
setblock 235 295 422 minecraft:white_concrete
fill 235 295 448 235 307 448 minecraft:black_concrete
setblock 235 295 455 minecraft:white_concrete
fill 253 295 416 253 307 416 minecraft:black_concrete
fill 256 295 416 256 307 416 minecraft:black_concrete
fill 235 296 422 235 307 422 minecraft:black_concrete
fill 235 296 455 235 307 455 minecraft:black_concrete
setblock 238 296 419 minecraft:light[level=12]
setblock 238 296 427 minecraft:light[level=12]
setblock 238 296 435 minecraft:light[level=12]
setblock 238 296 443 minecraft:light[level=12]
setblock 238 296 451 minecraft:light[level=12]
setblock 246 296 419 minecraft:light[level=12]
setblock 246 296 427 minecraft:light[level=12]
setblock 246 296 435 minecraft:light[level=12]
setblock 246 296 443 minecraft:light[level=12]
setblock 246 296 451 minecraft:light[level=12]
setblock 254 296 419 minecraft:light[level=12]
setblock 254 296 427 minecraft:light[level=12]
setblock 254 296 435 minecraft:light[level=12]
setblock 254 296 443 minecraft:light[level=12]
setblock 254 296 451 minecraft:light[level=12]
setblock 258 296 451 minecraft:amethyst_block
setblock 262 296 419 minecraft:light[level=12]
setblock 262 296 427 minecraft:light[level=12]
setblock 262 296 435 minecraft:light[level=12]
setblock 262 296 443 minecraft:light[level=12]
setblock 262 296 451 minecraft:light[level=12]
setblock 270 296 419 minecraft:light[level=12]
setblock 270 296 427 minecraft:light[level=12]
setblock 270 296 435 minecraft:light[level=12]
setblock 270 296 443 minecraft:light[level=12]
setblock 270 296 451 minecraft:light[level=12]
setblock 276 296 416 minecraft:crying_obsidian
fill 235 297 424 235 299 424 minecraft:purple_concrete
fill 235 297 440 235 299 440 minecraft:purple_concrete
fill 235 297 456 235 299 456 minecraft:purple_concrete
fill 239 297 416 239 299 416 minecraft:purple_concrete
setblock 241 297 458 minecraft:amethyst_block
fill 249 297 458 249 299 458 minecraft:purple_concrete
fill 255 297 416 255 299 416 minecraft:purple_concrete
fill 258 297 452 258 297 455 minecraft:amethyst_block
setblock 263 297 458 minecraft:amethyst_block
fill 265 297 458 265 299 458 minecraft:purple_concrete
fill 271 297 416 271 299 416 minecraft:purple_concrete
fill 276 297 416 276 307 416 minecraft:black_concrete
fill 277 297 426 277 299 426 minecraft:purple_concrete
fill 277 297 442 277 299 442 minecraft:purple_concrete
fill 235 298 418 235 299 418 minecraft:amethyst_block
setblock 235 298 451 minecraft:crying_obsidian
fill 241 298 458 241 307 458 minecraft:black_concrete
fill 257 298 454 259 298 456 minecraft:amethyst_block
setblock 258 298 453 minecraft:amethyst_block
fill 258 298 457 258 299 457 minecraft:amethyst_block
fill 263 298 458 263 307 458 minecraft:black_concrete
setblock 267 298 458 minecraft:amethyst_block
setblock 277 298 435 minecraft:crying_obsidian
fill 277 298 436 277 307 437 minecraft:black_concrete
setblock 235 299 430 minecraft:crying_obsidian
fill 235 299 451 235 307 451 minecraft:black_concrete
fill 257 299 456 259 299 456 minecraft:amethyst_block
setblock 258 299 455 minecraft:amethyst_block
fill 267 299 458 267 307 458 minecraft:black_concrete
fill 277 299 435 277 307 435 minecraft:black_concrete
setblock 277 299 448 minecraft:crying_obsidian
fill 235 300 418 235 307 418 minecraft:black_concrete
fill 235 300 424 235 307 424 minecraft:black_concrete
setblock 235 300 430 minecraft:black_concrete
fill 235 300 440 235 307 440 minecraft:black_concrete
fill 235 300 456 235 307 456 minecraft:black_concrete
fill 239 300 416 239 307 416 minecraft:black_concrete
fill 249 300 458 249 307 458 minecraft:black_concrete
fill 255 300 416 255 307 416 minecraft:black_concrete
fill 265 300 458 265 307 458 minecraft:black_concrete
fill 271 300 416 271 307 416 minecraft:black_concrete
setblock 277 300 423 minecraft:amethyst_block
fill 277 300 426 277 307 426 minecraft:black_concrete
setblock 277 300 429 minecraft:white_concrete
fill 277 300 430 277 307 434 minecraft:black_concrete
fill 277 300 442 277 307 442 minecraft:black_concrete
fill 277 300 448 277 307 448 minecraft:black_concrete
setblock 235 301 417 minecraft:crying_obsidian
setblock 235 301 430 minecraft:white_concrete
setblock 235 301 442 minecraft:amethyst_block
setblock 272 301 458 minecraft:white_concrete
fill 277 301 423 277 307 423 minecraft:black_concrete
fill 277 301 429 277 307 429 minecraft:black_concrete
fill 235 302 417 235 307 417 minecraft:black_concrete
fill 235 302 430 235 307 430 minecraft:black_concrete
fill 235 302 442 235 307 442 minecraft:black_concrete
setblock 236 302 458 minecraft:white_concrete
setblock 257 302 458 minecraft:amethyst_block
fill 272 302 458 272 307 458 minecraft:black_concrete
setblock 235 303 420 minecraft:crying_obsidian
fill 236 303 458 236 307 458 minecraft:black_concrete
setblock 240 303 458 minecraft:white_concrete
setblock 241 303 416 minecraft:white_concrete
fill 257 303 458 257 307 458 minecraft:black_concrete
setblock 260 303 458 minecraft:amethyst_block
setblock 277 303 438 minecraft:amethyst_block
fill 277 303 443 277 307 444 minecraft:black_concrete
setblock 277 303 445 minecraft:crying_obsidian
fill 235 304 420 235 307 420 minecraft:black_concrete
setblock 235 304 434 minecraft:amethyst_block
fill 240 304 458 240 307 458 minecraft:black_concrete
fill 241 304 416 241 307 416 minecraft:black_concrete
setblock 244 304 458 minecraft:amethyst_block
fill 260 304 458 260 307 458 minecraft:black_concrete
fill 277 304 438 277 307 438 minecraft:black_concrete
fill 277 304 445 277 307 445 minecraft:black_concrete
fill 235 305 434 235 307 434 minecraft:black_concrete
fill 235 305 437 235 307 437 minecraft:black_concrete
setblock 235 305 438 minecraft:white_concrete
setblock 240 305 416 minecraft:amethyst_block
fill 244 305 458 244 307 458 minecraft:black_concrete
setblock 274 305 458 minecraft:white_concrete
setblock 235 306 428 minecraft:crying_obsidian
fill 235 306 438 235 307 438 minecraft:black_concrete
fill 240 306 416 240 307 416 minecraft:black_concrete
setblock 244 306 416 minecraft:crying_obsidian
setblock 247 306 416 minecraft:amethyst_block
setblock 263 306 416 minecraft:crying_obsidian
fill 274 306 458 274 307 458 minecraft:black_concrete
setblock 277 306 419 minecraft:crying_obsidian
setblock 235 307 428 minecraft:black_concrete
setblock 244 307 416 minecraft:black_concrete
setblock 247 307 416 minecraft:black_concrete
setblock 263 307 416 minecraft:black_concrete
setblock 272 307 416 minecraft:crying_obsidian
setblock 277 307 419 minecraft:black_concrete
