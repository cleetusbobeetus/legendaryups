fill 268 159 232 268 160 232 minecraft:cyan_terracotta
fill 268 159 234 268 160 234 minecraft:cyan_terracotta
fill 268 159 236 268 160 236 minecraft:cyan_terracotta
fill 268 159 262 268 160 262 minecraft:light_gray_concrete
fill 268 159 264 268 163 264 minecraft:gray_concrete
fill 268 159 266 268 160 266 minecraft:gray_concrete
fill 268 159 268 268 160 268 minecraft:gray_concrete
fill 269 159 229 269 160 229 minecraft:cyan_terracotta
fill 269 159 237 269 160 237 minecraft:cyan_terracotta
fill 269 159 256 271 159 256 minecraft:magenta_concrete
fill 269 159 261 269 160 261 minecraft:light_gray_concrete
fill 269 159 269 269 160 269 minecraft:light_gray_concrete
fill 271 159 229 271 160 229 minecraft:cyan_terracotta
fill 271 159 237 271 160 237 minecraft:cyan_terracotta
fill 271 159 243 271 160 243 minecraft:light_gray_concrete
fill 271 159 245 271 160 245 minecraft:light_gray_concrete
fill 271 159 247 271 160 247 minecraft:light_gray_concrete
fill 271 159 249 271 160 249 minecraft:light_gray_concrete
fill 271 159 251 271 160 251 minecraft:light_gray_concrete
fill 271 159 253 271 160 253 minecraft:light_gray_concrete
fill 271 159 261 271 160 261 minecraft:light_gray_concrete
fill 271 159 269 271 160 269 minecraft:light_gray_concrete
fill 272 159 242 272 160 242 minecraft:light_gray_concrete
fill 272 159 255 272 160 255 minecraft:light_gray_concrete
fill 272 159 257 276 159 257 minecraft:magenta_concrete
fill 273 159 229 273 160 229 minecraft:cyan_terracotta
fill 273 159 237 273 160 237 minecraft:cyan_terracotta
fill 273 159 261 273 160 261 minecraft:light_gray_concrete
fill 273 159 269 273 160 269 minecraft:light_gray_concrete
fill 274 159 242 274 160 242 minecraft:light_gray_concrete
fill 274 159 255 274 160 255 minecraft:light_gray_concrete
fill 275 159 229 275 160 229 minecraft:cyan_terracotta
fill 275 159 237 275 160 237 minecraft:cyan_terracotta
fill 275 159 261 275 160 261 minecraft:light_gray_concrete
fill 275 159 269 275 160 269 minecraft:light_gray_concrete
fill 276 159 230 276 160 230 minecraft:cyan_terracotta
fill 276 159 232 276 160 232 minecraft:cyan_terracotta
fill 276 159 234 276 160 234 minecraft:cyan_terracotta
fill 276 159 236 276 160 236 minecraft:cyan_terracotta
fill 276 159 243 276 160 243 minecraft:light_gray_concrete
fill 276 159 245 276 160 245 minecraft:light_gray_concrete
fill 276 159 247 276 160 247 minecraft:light_gray_concrete
fill 276 159 249 276 160 249 minecraft:light_gray_concrete
fill 276 159 251 276 160 251 minecraft:light_gray_concrete
fill 276 159 253 276 160 253 minecraft:light_gray_concrete
fill 276 159 262 276 160 262 minecraft:light_gray_concrete
fill 276 159 264 276 160 264 minecraft:light_gray_concrete
fill 276 159 266 276 160 266 minecraft:light_gray_concrete
fill 276 159 268 276 160 268 minecraft:light_gray_concrete
setblock 277 159 259 minecraft:pearlescent_froglight
fill 277 159 267 277 202 267 minecraft:black_concrete
fill 235 160 254 235 174 254 minecraft:black_concrete
fill 236 160 253 238 160 254 minecraft:gray_concrete
fill 236 160 255 236 183 255 minecraft:light_gray_concrete
fill 239 160 253 240 168 253 minecraft:light_gray_concrete
fill 239 160 254 249 160 255 minecraft:gray_concrete
fill 241 160 230 242 164 233 minecraft:light_gray_concrete
fill 243 160 230 244 160 230 minecraft:cyan_wool
fill 243 160 231 243 164 233 minecraft:light_gray_concrete
fill 243 160 236 243 160 237 minecraft:light_gray_concrete
setblock 244 160 228 minecraft:sea_lantern
setblock 244 160 236 minecraft:light_gray_concrete
fill 244 160 237 244 161 239 minecraft:magenta_stained_glass
fill 245 160 237 246 161 237 minecraft:magenta_stained_glass
fill 245 160 239 246 161 239 minecraft:magenta_stained_glass
fill 246 160 230 247 167 230 minecraft:cyan_wool
fill 246 160 238 246 161 238 minecraft:magenta_stained_glass
fill 250 160 255 255 160 255 minecraft:gray_concrete
fill 256 160 255 258 160 255 minecraft:magenta_concrete
setblock 257 160 270 minecraft:cyan_concrete
fill 259 160 256 267 160 256 minecraft:magenta_concrete
setblock 260 160 263 minecraft:sea_lantern
setblock 260 160 265 minecraft:sea_lantern
setblock 260 160 267 minecraft:sea_lantern
setblock 260 160 269 minecraft:sea_lantern
setblock 261 160 264 minecraft:sea_lantern
setblock 261 160 266 minecraft:sea_lantern
setblock 261 160 268 minecraft:sea_lantern
setblock 262 160 263 minecraft:sea_lantern
setblock 262 160 265 minecraft:sea_lantern
setblock 262 160 267 minecraft:sea_lantern
setblock 262 160 269 minecraft:sea_lantern
setblock 263 160 264 minecraft:sea_lantern
setblock 263 160 266 minecraft:sea_lantern
setblock 263 160 268 minecraft:sea_lantern
setblock 264 160 263 minecraft:sea_lantern
setblock 264 160 265 minecraft:sea_lantern
setblock 264 160 267 minecraft:sea_lantern
setblock 264 160 269 minecraft:sea_lantern
setblock 265 160 230 minecraft:sea_lantern
setblock 265 160 232 minecraft:sea_lantern
setblock 265 160 234 minecraft:sea_lantern
setblock 265 160 264 minecraft:sea_lantern
setblock 265 160 266 minecraft:sea_lantern
setblock 265 160 268 minecraft:sea_lantern
setblock 266 160 229 minecraft:sea_lantern
setblock 266 160 231 minecraft:sea_lantern
setblock 266 160 233 minecraft:sea_lantern
setblock 266 160 263 minecraft:sea_lantern
setblock 266 160 265 minecraft:sea_lantern
setblock 266 160 267 minecraft:sea_lantern
setblock 266 160 269 minecraft:sea_lantern
setblock 267 160 230 minecraft:sea_lantern
setblock 267 160 232 minecraft:sea_lantern
setblock 267 160 234 minecraft:sea_lantern
setblock 267 160 264 minecraft:sea_lantern
setblock 267 160 266 minecraft:sea_lantern
setblock 267 160 268 minecraft:sea_lantern
setblock 268 160 229 minecraft:sea_lantern
setblock 268 160 231 minecraft:sea_lantern
setblock 268 160 233 minecraft:sea_lantern
setblock 268 160 263 minecraft:sea_lantern
setblock 268 160 265 minecraft:sea_lantern
setblock 268 160 267 minecraft:sea_lantern
setblock 268 160 269 minecraft:sea_lantern
setblock 269 160 230 minecraft:sea_lantern
setblock 269 160 232 minecraft:sea_lantern
setblock 269 160 234 minecraft:sea_lantern
setblock 270 160 229 minecraft:sea_lantern
setblock 270 160 231 minecraft:sea_lantern
setblock 270 160 233 minecraft:sea_lantern
setblock 271 160 228 minecraft:sea_lantern
setblock 271 160 230 minecraft:sea_lantern
setblock 271 160 232 minecraft:sea_lantern
setblock 271 160 234 minecraft:sea_lantern
setblock 272 160 229 minecraft:sea_lantern
setblock 272 160 231 minecraft:sea_lantern
setblock 272 160 233 minecraft:sea_lantern
setblock 273 160 230 minecraft:sea_lantern
setblock 273 160 232 minecraft:sea_lantern
setblock 273 160 234 minecraft:sea_lantern
fill 277 160 259 277 204 259 minecraft:black_concrete
setblock 235 161 247 minecraft:cyan_concrete
setblock 236 161 230 minecraft:light_blue_stained_glass
setblock 236 161 232 minecraft:black_stained_glass
setblock 236 161 234 minecraft:light_blue_stained_glass
setblock 236 161 236 minecraft:cyan_stained_glass
setblock 236 161 243 minecraft:sea_lantern
setblock 236 161 245 minecraft:black_stained_glass
setblock 236 161 247 minecraft:black_stained_glass
setblock 236 161 249 minecraft:black_stained_glass
setblock 236 161 251 minecraft:light_blue_stained_glass
setblock 236 161 253 minecraft:cyan_stained_glass
fill 236 161 254 241 161 254 minecraft:gray_concrete
setblock 236 161 262 minecraft:sea_lantern
setblock 236 161 264 minecraft:black_stained_glass
setblock 236 161 266 minecraft:black_stained_glass
setblock 236 161 268 minecraft:ochre_froglight
setblock 237 161 228 minecraft:sea_lantern
setblock 237 161 229 minecraft:light_blue_stained_glass
setblock 237 161 237 minecraft:black_stained_glass
setblock 237 161 242 minecraft:pearlescent_froglight
fill 237 161 253 238 169 253 minecraft:light_gray_concrete
setblock 237 161 255 minecraft:cyan_stained_glass
setblock 237 161 261 minecraft:sea_lantern
setblock 237 161 269 minecraft:black_stained_glass
fill 238 161 228 238 178 228 minecraft:black_concrete
setblock 239 161 229 minecraft:ochre_froglight
setblock 239 161 237 minecraft:black_stained_glass
setblock 239 161 242 minecraft:black_stained_glass
setblock 239 161 255 minecraft:magenta_stained_glass
setblock 239 161 261 minecraft:black_stained_glass
setblock 239 161 269 minecraft:ochre_froglight
fill 240 161 255 241 169 255 minecraft:light_gray_concrete
setblock 241 161 229 minecraft:ochre_froglight
setblock 241 161 237 minecraft:sea_lantern
setblock 241 161 243 minecraft:black_stained_glass
setblock 241 161 245 minecraft:black_stained_glass
setblock 241 161 247 minecraft:pearlescent_froglight
setblock 241 161 249 minecraft:pearlescent_froglight
setblock 241 161 251 minecraft:ochre_froglight
setblock 241 161 253 minecraft:cyan_stained_glass
setblock 241 161 261 minecraft:ochre_froglight
setblock 241 161 269 minecraft:black_stained_glass
fill 242 161 254 245 161 254 minecraft:magenta_concrete
setblock 243 161 229 minecraft:black_stained_glass
fill 243 161 230 243 167 230 minecraft:cyan_wool
fill 243 161 236 243 225 236 minecraft:light_gray_concrete
setblock 243 161 237 minecraft:black_stained_glass
setblock 243 161 261 minecraft:black_stained_glass
setblock 243 161 269 minecraft:black_stained_glass
fill 244 161 228 244 308 228 minecraft:black_concrete
setblock 244 161 230 minecraft:ochre_froglight
setblock 244 161 232 minecraft:black_stained_glass
setblock 244 161 234 minecraft:light_blue_stained_glass
setblock 244 161 236 minecraft:black_stained_glass
setblock 244 161 262 minecraft:sea_lantern
setblock 244 161 264 minecraft:cyan_stained_glass
setblock 244 161 266 minecraft:magenta_stained_glass
setblock 244 161 268 minecraft:black_stained_glass
fill 245 161 255 254 161 255 minecraft:magenta_concrete
setblock 249 161 230 minecraft:ochre_froglight
setblock 249 161 232 minecraft:ochre_froglight
setblock 250 161 229 minecraft:black_stained_glass
setblock 250 161 234 minecraft:black_stained_glass
setblock 252 161 229 minecraft:pearlescent_froglight
setblock 252 161 234 minecraft:black_stained_glass
setblock 252 161 266 minecraft:ochre_froglight
setblock 252 161 267 minecraft:pearlescent_froglight
setblock 254 161 229 minecraft:light_blue_stained_glass
setblock 254 161 234 minecraft:ochre_froglight
fill 254 161 266 254 161 267 minecraft:black_stained_glass
setblock 256 161 229 minecraft:black_stained_glass
setblock 256 161 234 minecraft:black_stained_glass
fill 256 161 266 256 161 267 minecraft:black_stained_glass
fill 257 161 270 257 208 270 minecraft:black_concrete
setblock 258 161 229 minecraft:magenta_stained_glass
setblock 258 161 234 minecraft:cyan_stained_glass
setblock 258 161 266 minecraft:pearlescent_froglight
setblock 258 161 267 minecraft:magenta_stained_glass
setblock 260 161 229 minecraft:pearlescent_froglight
setblock 260 161 234 minecraft:black_stained_glass
fill 260 161 263 260 162 263 minecraft:gray_concrete
fill 260 161 265 260 162 265 minecraft:gray_concrete
fill 260 161 267 260 162 267 minecraft:cyan_terracotta
fill 260 161 269 260 162 269 minecraft:gray_concrete
fill 261 161 264 261 162 264 minecraft:gray_concrete
fill 261 161 266 261 162 266 minecraft:gray_concrete
fill 261 161 268 261 162 268 minecraft:gray_concrete
setblock 262 161 230 minecraft:black_stained_glass
setblock 262 161 232 minecraft:black_stained_glass
fill 262 161 263 262 162 263 minecraft:gray_concrete
fill 262 161 265 262 162 265 minecraft:gray_concrete
fill 262 161 267 262 162 267 minecraft:gray_concrete
fill 262 161 269 262 162 269 minecraft:gray_concrete
fill 263 161 264 263 162 264 minecraft:gray_concrete
fill 263 161 266 263 162 266 minecraft:gray_concrete
fill 263 161 268 263 162 268 minecraft:gray_concrete
fill 264 161 263 264 162 263 minecraft:gray_concrete
fill 264 161 265 264 162 265 minecraft:gray_concrete
fill 264 161 267 264 162 267 minecraft:gray_concrete
fill 264 161 269 264 162 269 minecraft:gray_concrete
fill 265 161 230 265 162 230 minecraft:gray_concrete
fill 265 161 232 265 162 232 minecraft:gray_concrete
fill 265 161 234 265 162 234 minecraft:gray_concrete
fill 265 161 264 265 162 264 minecraft:gray_concrete
fill 265 161 266 265 162 266 minecraft:gray_concrete
fill 265 161 268 265 162 268 minecraft:gray_concrete
fill 266 161 229 266 162 229 minecraft:gray_concrete
fill 266 161 231 266 162 231 minecraft:gray_concrete
fill 266 161 233 266 162 233 minecraft:gray_concrete
fill 266 161 263 266 162 263 minecraft:gray_concrete
fill 266 161 265 266 162 265 minecraft:gray_concrete
fill 266 161 267 266 162 267 minecraft:gray_concrete
fill 266 161 269 266 162 269 minecraft:gray_concrete
fill 267 161 230 267 162 230 minecraft:gray_concrete
fill 267 161 232 267 162 232 minecraft:gray_concrete
fill 267 161 234 267 162 234 minecraft:gray_concrete
fill 267 161 264 267 162 264 minecraft:gray_concrete
fill 267 161 266 267 162 266 minecraft:gray_concrete
fill 267 161 268 267 162 268 minecraft:gray_concrete
fill 268 161 229 268 162 229 minecraft:cyan_terracotta
setblock 268 161 230 minecraft:ochre_froglight
fill 268 161 231 268 162 231 minecraft:cyan_terracotta
setblock 268 161 232 minecraft:magenta_stained_glass
fill 268 161 233 268 162 233 minecraft:cyan_terracotta
setblock 268 161 234 minecraft:black_stained_glass
setblock 268 161 236 minecraft:black_stained_glass
setblock 268 161 262 minecraft:sea_lantern
fill 268 161 263 268 162 263 minecraft:gray_concrete
fill 268 161 265 268 162 265 minecraft:gray_concrete
setblock 268 161 266 minecraft:black_stained_glass
fill 268 161 267 268 162 267 minecraft:gray_concrete
setblock 268 161 268 minecraft:cyan_stained_glass
fill 268 161 269 268 162 269 minecraft:gray_concrete
setblock 269 161 229 minecraft:black_stained_glass
fill 269 161 230 269 162 230 minecraft:cyan_terracotta
fill 269 161 232 269 162 232 minecraft:cyan_terracotta
fill 269 161 234 269 162 234 minecraft:cyan_terracotta
setblock 269 161 237 minecraft:ochre_froglight
setblock 269 161 261 minecraft:black_stained_glass
setblock 269 161 269 minecraft:black_stained_glass
fill 270 161 229 270 162 229 minecraft:cyan_terracotta
fill 270 161 231 270 162 231 minecraft:cyan_terracotta
fill 270 161 233 270 162 233 minecraft:cyan_terracotta
fill 271 161 228 271 233 228 minecraft:black_concrete
setblock 271 161 229 minecraft:black_stained_glass
fill 271 161 230 271 162 230 minecraft:cyan_terracotta
fill 271 161 232 271 162 232 minecraft:cyan_terracotta
fill 271 161 234 271 162 234 minecraft:cyan_terracotta
setblock 271 161 237 minecraft:ochre_froglight
setblock 271 161 243 minecraft:magenta_stained_glass
setblock 271 161 245 minecraft:sea_lantern
setblock 271 161 247 minecraft:light_blue_stained_glass
setblock 271 161 249 minecraft:pearlescent_froglight
setblock 271 161 251 minecraft:black_stained_glass
setblock 271 161 253 minecraft:magenta_stained_glass
setblock 271 161 261 minecraft:magenta_stained_glass
setblock 271 161 269 minecraft:ochre_froglight
setblock 271 161 270 minecraft:pearlescent_froglight
fill 272 161 229 272 162 229 minecraft:cyan_terracotta
fill 272 161 231 272 162 231 minecraft:cyan_terracotta
fill 272 161 233 272 162 233 minecraft:cyan_terracotta
setblock 272 161 242 minecraft:sea_lantern
setblock 272 161 255 minecraft:ochre_froglight
setblock 273 161 229 minecraft:black_stained_glass
fill 273 161 230 273 162 230 minecraft:cyan_terracotta
fill 273 161 232 273 162 232 minecraft:cyan_terracotta
fill 273 161 234 273 162 234 minecraft:cyan_terracotta
setblock 273 161 237 minecraft:black_stained_glass
setblock 273 161 261 minecraft:black_stained_glass
setblock 273 161 269 minecraft:cyan_stained_glass
setblock 274 161 242 minecraft:black_stained_glass
setblock 274 161 255 minecraft:light_blue_stained_glass
setblock 275 161 229 minecraft:magenta_stained_glass
setblock 275 161 237 minecraft:ochre_froglight
setblock 275 161 261 minecraft:black_stained_glass
setblock 275 161 269 minecraft:black_stained_glass
setblock 276 161 230 minecraft:black_stained_glass
setblock 276 161 232 minecraft:ochre_froglight
setblock 276 161 234 minecraft:sea_lantern
setblock 276 161 236 minecraft:black_stained_glass
setblock 276 161 243 minecraft:cyan_stained_glass
setblock 276 161 245 minecraft:cyan_stained_glass
setblock 276 161 247 minecraft:black_stained_glass
setblock 276 161 249 minecraft:sea_lantern
setblock 276 161 251 minecraft:magenta_stained_glass
setblock 276 161 253 minecraft:black_stained_glass
setblock 276 161 262 minecraft:magenta_stained_glass
setblock 276 161 264 minecraft:sea_lantern
setblock 276 161 266 minecraft:black_stained_glass
setblock 276 161 268 minecraft:cyan_stained_glass
fill 235 162 247 235 235 247 minecraft:black_concrete
fill 236 162 230 236 163 230 minecraft:light_gray_concrete
fill 236 162 232 236 163 232 minecraft:light_gray_concrete
fill 236 162 234 236 163 234 minecraft:light_gray_concrete
fill 236 162 236 236 163 236 minecraft:light_gray_concrete
fill 236 162 243 236 163 243 minecraft:light_gray_concrete
fill 236 162 245 236 163 245 minecraft:light_gray_concrete
fill 236 162 247 236 163 247 minecraft:light_gray_concrete
fill 236 162 249 236 163 249 minecraft:light_gray_concrete
fill 236 162 251 236 163 251 minecraft:light_gray_concrete
fill 236 162 253 236 163 253 minecraft:light_gray_concrete
fill 236 162 254 241 162 254 minecraft:magenta_concrete
fill 236 162 262 236 163 262 minecraft:cyan_terracotta
fill 236 162 264 236 163 264 minecraft:cyan_terracotta
fill 236 162 266 236 163 266 minecraft:cyan_terracotta
fill 236 162 268 236 163 268 minecraft:cyan_terracotta
fill 237 162 228 237 199 228 minecraft:black_concrete
fill 237 162 229 237 163 229 minecraft:light_gray_concrete
fill 237 162 237 237 163 237 minecraft:light_gray_concrete
fill 237 162 242 237 163 242 minecraft:light_gray_concrete
fill 237 162 255 237 163 255 minecraft:light_gray_concrete
fill 237 162 261 237 163 261 minecraft:cyan_terracotta
fill 237 162 269 237 163 269 minecraft:cyan_terracotta
fill 239 162 229 239 163 229 minecraft:light_gray_concrete
fill 239 162 237 239 163 237 minecraft:light_gray_concrete
fill 239 162 242 239 163 242 minecraft:light_gray_concrete
fill 239 162 255 239 163 255 minecraft:light_gray_concrete
fill 239 162 261 239 163 261 minecraft:cyan_terracotta
fill 239 162 269 239 163 269 minecraft:cyan_terracotta
fill 241 162 229 241 163 229 minecraft:light_gray_concrete
fill 241 162 237 241 163 237 minecraft:light_gray_concrete
fill 241 162 243 241 163 243 minecraft:light_gray_concrete
fill 241 162 245 241 163 245 minecraft:light_gray_concrete
fill 241 162 247 241 163 247 minecraft:light_gray_concrete
fill 241 162 249 241 163 249 minecraft:light_gray_concrete
fill 241 162 251 241 163 251 minecraft:light_gray_concrete
fill 241 162 253 241 163 253 minecraft:light_gray_concrete
fill 241 162 261 241 163 261 minecraft:cyan_terracotta
fill 241 162 269 241 163 269 minecraft:cyan_terracotta
fill 243 162 229 243 163 229 minecraft:light_gray_concrete
fill 243 162 237 244 163 237 minecraft:light_gray_concrete
fill 243 162 261 243 163 261 minecraft:cyan_terracotta
fill 243 162 269 243 163 269 minecraft:cyan_terracotta
fill 244 162 230 244 166 230 minecraft:cyan_wool
fill 244 162 232 244 163 232 minecraft:light_gray_concrete
fill 244 162 234 244 163 234 minecraft:light_gray_concrete
fill 244 162 236 244 163 236 minecraft:light_gray_concrete
fill 244 162 262 244 163 262 minecraft:cyan_terracotta
fill 244 162 264 244 163 264 minecraft:cyan_terracotta
fill 244 162 266 244 163 266 minecraft:cyan_terracotta
fill 244 162 268 244 163 268 minecraft:cyan_terracotta
fill 245 162 238 245 163 238 minecraft:magenta_stained_glass
fill 249 162 230 249 163 230 minecraft:light_gray_concrete
fill 249 162 232 249 163 232 minecraft:light_gray_concrete
fill 250 162 229 250 163 229 minecraft:light_gray_concrete
fill 250 162 234 250 163 234 minecraft:light_gray_concrete
fill 252 162 229 252 163 229 minecraft:light_gray_concrete
fill 252 162 234 252 163 234 minecraft:light_gray_concrete
fill 252 162 266 252 163 267 minecraft:cyan_terracotta
fill 254 162 229 254 163 229 minecraft:light_gray_concrete
fill 254 162 234 254 163 234 minecraft:light_gray_concrete
fill 254 162 266 254 163 267 minecraft:cyan_terracotta
fill 256 162 229 256 163 229 minecraft:light_gray_concrete
fill 256 162 234 256 163 234 minecraft:light_gray_concrete
fill 256 162 266 256 163 267 minecraft:cyan_terracotta
fill 258 162 229 258 163 229 minecraft:light_gray_concrete
fill 258 162 234 258 163 234 minecraft:light_gray_concrete
fill 258 162 266 258 163 267 minecraft:cyan_terracotta
fill 260 162 229 260 163 229 minecraft:light_gray_concrete
fill 260 162 234 260 163 234 minecraft:light_gray_concrete
fill 262 162 230 262 163 230 minecraft:light_gray_concrete
fill 262 162 232 262 163 232 minecraft:light_gray_concrete
setblock 264 162 270 minecraft:purple_concrete
fill 268 162 230 268 163 230 minecraft:cyan_terracotta
fill 268 162 232 268 163 232 minecraft:cyan_terracotta
fill 268 162 234 268 163 234 minecraft:cyan_terracotta
fill 268 162 236 268 163 236 minecraft:cyan_terracotta
fill 268 162 262 268 163 262 minecraft:light_gray_concrete
fill 268 162 266 268 163 266 minecraft:gray_concrete
fill 268 162 268 268 166 268 minecraft:gray_concrete
fill 269 162 229 269 163 229 minecraft:cyan_terracotta
fill 269 162 237 269 163 237 minecraft:cyan_terracotta
fill 269 162 261 269 163 261 minecraft:light_gray_concrete
fill 269 162 269 269 163 269 minecraft:light_gray_concrete
fill 271 162 229 271 163 229 minecraft:cyan_terracotta
fill 271 162 237 271 163 237 minecraft:cyan_terracotta
fill 271 162 243 271 163 243 minecraft:light_gray_concrete
fill 271 162 245 271 163 245 minecraft:light_gray_concrete
fill 271 162 247 271 163 247 minecraft:light_gray_concrete
fill 271 162 249 271 163 249 minecraft:light_gray_concrete
fill 271 162 251 271 163 251 minecraft:light_gray_concrete
fill 271 162 253 271 163 253 minecraft:light_gray_concrete
fill 271 162 261 271 163 261 minecraft:light_gray_concrete
fill 271 162 269 271 163 269 minecraft:light_gray_concrete
fill 271 162 270 271 188 270 minecraft:black_concrete
fill 272 162 242 272 163 242 minecraft:light_gray_concrete
fill 272 162 255 272 163 255 minecraft:light_gray_concrete
fill 273 162 229 273 163 229 minecraft:cyan_terracotta
fill 273 162 237 273 163 237 minecraft:cyan_terracotta
fill 273 162 261 273 163 261 minecraft:light_gray_concrete
fill 273 162 269 273 163 269 minecraft:light_gray_concrete
fill 274 162 242 274 163 242 minecraft:light_gray_concrete
fill 274 162 255 274 163 255 minecraft:light_gray_concrete
fill 275 162 229 275 163 229 minecraft:cyan_terracotta
fill 275 162 237 275 163 237 minecraft:cyan_terracotta
fill 275 162 261 275 163 261 minecraft:light_gray_concrete
fill 275 162 269 275 163 269 minecraft:light_gray_concrete
fill 276 162 230 276 163 230 minecraft:cyan_terracotta
fill 276 162 232 276 163 232 minecraft:cyan_terracotta
fill 276 162 234 276 163 234 minecraft:cyan_terracotta
fill 276 162 236 276 163 236 minecraft:cyan_terracotta
fill 276 162 243 276 163 243 minecraft:light_gray_concrete
fill 276 162 245 276 163 245 minecraft:light_gray_concrete
fill 276 162 247 276 163 247 minecraft:light_gray_concrete
fill 276 162 249 276 163 249 minecraft:light_gray_concrete
fill 276 162 251 276 163 251 minecraft:light_gray_concrete
fill 276 162 253 276 163 253 minecraft:light_gray_concrete
fill 276 162 262 276 163 262 minecraft:light_gray_concrete
fill 276 162 264 276 163 264 minecraft:light_gray_concrete
fill 276 162 266 276 163 266 minecraft:light_gray_concrete
fill 276 162 268 276 163 268 minecraft:light_gray_concrete
fill 277 162 233 277 172 233 minecraft:black_concrete
setblock 277 162 234 minecraft:sea_lantern
setblock 235 163 234 minecraft:cyan_concrete
fill 236 163 254 241 168 254 minecraft:light_gray_concrete
setblock 238 163 238 minecraft:light[level=12]
setblock 238 163 259 minecraft:light[level=12]
setblock 245 163 231 minecraft:light[level=12]
setblock 245 163 245 minecraft:light[level=12]
setblock 245 163 252 minecraft:light[level=12]
setblock 245 163 259 minecraft:light[level=12]
setblock 245 163 266 minecraft:light[level=12]
setblock 252 163 238 minecraft:light[level=12]
setblock 252 163 245 minecraft:light[level=12]
setblock 252 163 252 minecraft:light[level=12]
setblock 252 163 259 minecraft:light[level=12]
setblock 259 163 238 minecraft:light[level=12]
setblock 259 163 245 minecraft:light[level=12]
setblock 259 163 252 minecraft:light[level=12]
setblock 259 163 259 minecraft:light[level=12]
setblock 260 163 263 minecraft:sea_lantern
setblock 260 163 265 minecraft:sea_lantern
setblock 260 163 267 minecraft:sea_lantern
setblock 260 163 269 minecraft:sea_lantern
setblock 261 163 264 minecraft:sea_lantern
setblock 261 163 266 minecraft:sea_lantern
setblock 261 163 268 minecraft:sea_lantern
setblock 262 163 263 minecraft:sea_lantern
setblock 262 163 265 minecraft:sea_lantern
setblock 262 163 267 minecraft:sea_lantern
setblock 262 163 269 minecraft:sea_lantern
setblock 263 163 264 minecraft:sea_lantern
setblock 263 163 266 minecraft:sea_lantern
setblock 263 163 268 minecraft:sea_lantern
setblock 264 163 263 minecraft:sea_lantern
setblock 264 163 265 minecraft:sea_lantern
setblock 264 163 267 minecraft:sea_lantern
setblock 264 163 269 minecraft:sea_lantern
fill 264 163 270 264 174 270 minecraft:black_concrete
setblock 265 163 230 minecraft:sea_lantern
setblock 265 163 232 minecraft:sea_lantern
setblock 265 163 234 minecraft:sea_lantern
setblock 265 163 264 minecraft:sea_lantern
setblock 265 163 266 minecraft:sea_lantern
setblock 265 163 268 minecraft:sea_lantern
setblock 266 163 229 minecraft:sea_lantern
setblock 266 163 231 minecraft:sea_lantern
setblock 266 163 233 minecraft:sea_lantern
setblock 266 163 238 minecraft:light[level=12]
setblock 266 163 245 minecraft:light[level=12]
setblock 266 163 252 minecraft:light[level=12]
setblock 266 163 259 minecraft:light[level=12]
setblock 266 163 263 minecraft:sea_lantern
setblock 266 163 265 minecraft:sea_lantern
setblock 266 163 267 minecraft:sea_lantern
setblock 266 163 269 minecraft:sea_lantern
setblock 267 163 230 minecraft:sea_lantern
setblock 267 163 232 minecraft:sea_lantern
setblock 267 163 234 minecraft:sea_lantern
setblock 267 163 264 minecraft:sea_lantern
setblock 267 163 266 minecraft:sea_lantern
setblock 267 163 268 minecraft:sea_lantern
setblock 268 163 229 minecraft:sea_lantern
setblock 268 163 231 minecraft:sea_lantern
setblock 268 163 233 minecraft:sea_lantern
setblock 268 163 263 minecraft:sea_lantern
setblock 268 163 265 minecraft:sea_lantern
setblock 268 163 267 minecraft:sea_lantern
setblock 268 163 269 minecraft:sea_lantern
setblock 269 163 230 minecraft:sea_lantern
setblock 269 163 232 minecraft:sea_lantern
setblock 269 163 234 minecraft:sea_lantern
setblock 270 163 229 minecraft:sea_lantern
setblock 270 163 231 minecraft:sea_lantern
setblock 270 163 233 minecraft:sea_lantern
setblock 271 163 230 minecraft:sea_lantern
setblock 271 163 232 minecraft:sea_lantern
setblock 271 163 234 minecraft:sea_lantern
setblock 272 163 229 minecraft:sea_lantern
setblock 272 163 231 minecraft:sea_lantern
setblock 272 163 233 minecraft:sea_lantern
setblock 273 163 230 minecraft:sea_lantern
setblock 273 163 232 minecraft:sea_lantern
setblock 273 163 234 minecraft:sea_lantern
setblock 273 163 238 minecraft:light[level=12]
setblock 273 163 259 minecraft:light[level=12]
fill 277 163 234 277 181 234 minecraft:black_concrete
fill 235 164 234 235 179 234 minecraft:black_concrete
setblock 236 164 230 minecraft:black_stained_glass
setblock 236 164 232 minecraft:pearlescent_froglight
setblock 236 164 234 minecraft:black_stained_glass
setblock 236 164 236 minecraft:ochre_froglight
setblock 236 164 243 minecraft:black_stained_glass
setblock 236 164 245 minecraft:black_stained_glass
setblock 236 164 247 minecraft:magenta_stained_glass
setblock 236 164 249 minecraft:black_stained_glass
setblock 236 164 251 minecraft:sea_lantern
setblock 236 164 253 minecraft:sea_lantern
setblock 236 164 262 minecraft:ochre_froglight
setblock 236 164 264 minecraft:cyan_stained_glass
setblock 236 164 266 minecraft:black_stained_glass
setblock 236 164 268 minecraft:black_stained_glass
setblock 237 164 229 minecraft:magenta_stained_glass
setblock 237 164 237 minecraft:black_stained_glass
setblock 237 164 242 minecraft:black_stained_glass
setblock 237 164 255 minecraft:magenta_stained_glass
setblock 237 164 261 minecraft:sea_lantern
setblock 237 164 269 minecraft:ochre_froglight
setblock 238 164 239 minecraft:light[level=15]
setblock 239 164 229 minecraft:pearlescent_froglight
setblock 239 164 237 minecraft:black_stained_glass
setblock 239 164 242 minecraft:pearlescent_froglight
setblock 239 164 255 minecraft:light_blue_stained_glass
setblock 239 164 261 minecraft:light_blue_stained_glass
setblock 239 164 269 minecraft:ochre_froglight
setblock 241 164 229 minecraft:ochre_froglight
setblock 241 164 237 minecraft:cyan_stained_glass
setblock 241 164 243 minecraft:black_stained_glass
setblock 241 164 245 minecraft:black_stained_glass
setblock 241 164 247 minecraft:light_blue_stained_glass
setblock 241 164 249 minecraft:sea_lantern
setblock 241 164 251 minecraft:magenta_stained_glass
setblock 241 164 253 minecraft:black_stained_glass
setblock 241 164 261 minecraft:light_blue_stained_glass
setblock 241 164 269 minecraft:cyan_stained_glass
setblock 243 164 229 minecraft:ochre_froglight
setblock 243 164 237 minecraft:black_stained_glass
setblock 243 164 261 minecraft:pearlescent_froglight
setblock 243 164 269 minecraft:sea_lantern
setblock 244 164 232 minecraft:pearlescent_froglight
setblock 244 164 234 minecraft:black_stained_glass
setblock 244 164 236 minecraft:black_stained_glass
fill 244 164 237 244 225 237 minecraft:light_gray_concrete
setblock 244 164 262 minecraft:cyan_stained_glass
setblock 244 164 264 minecraft:black_stained_glass
setblock 244 164 266 minecraft:black_stained_glass
setblock 244 164 268 minecraft:black_stained_glass
setblock 246 164 231 minecraft:light[level=15]
setblock 246 164 239 minecraft:light[level=15]
setblock 246 164 247 minecraft:light[level=15]
setblock 246 164 255 minecraft:light[level=15]
setblock 246 164 263 minecraft:light[level=15]
setblock 249 164 230 minecraft:magenta_stained_glass
fill 249 164 232 249 166 232 minecraft:sea_lantern
setblock 250 164 229 minecraft:black_stained_glass
setblock 250 164 234 minecraft:black_stained_glass
setblock 252 164 229 minecraft:light_blue_stained_glass
setblock 252 164 234 minecraft:magenta_stained_glass
setblock 252 164 266 minecraft:black_stained_glass
setblock 252 164 267 minecraft:ochre_froglight
setblock 252 164 270 minecraft:verdant_froglight
fill 253 164 270 253 176 270 minecraft:black_concrete
setblock 254 164 229 minecraft:black_stained_glass
setblock 254 164 234 minecraft:cyan_stained_glass
setblock 254 164 239 minecraft:light[level=15]
setblock 254 164 247 minecraft:light[level=15]
setblock 254 164 255 minecraft:light[level=15]
fill 254 164 266 254 164 267 minecraft:sea_lantern
setblock 256 164 229 minecraft:sea_lantern
setblock 256 164 234 minecraft:black_stained_glass
setblock 256 164 266 minecraft:black_stained_glass
setblock 256 164 267 minecraft:sea_lantern
setblock 258 164 229 minecraft:black_stained_glass
setblock 258 164 234 minecraft:black_stained_glass
setblock 258 164 266 minecraft:gray_concrete
setblock 258 164 267 minecraft:ochre_froglight
setblock 260 164 229 minecraft:black_stained_glass
setblock 260 164 234 minecraft:black_stained_glass
fill 260 164 263 260 165 263 minecraft:gray_concrete
fill 260 164 265 260 165 265 minecraft:gray_concrete
fill 260 164 267 260 165 267 minecraft:cyan_terracotta
fill 260 164 269 260 165 269 minecraft:gray_concrete
fill 261 164 264 261 165 264 minecraft:gray_concrete
fill 261 164 266 261 165 266 minecraft:gray_concrete
fill 261 164 268 261 165 268 minecraft:gray_concrete
setblock 262 164 230 minecraft:black_stained_glass
setblock 262 164 232 minecraft:magenta_stained_glass
setblock 262 164 239 minecraft:light[level=15]
setblock 262 164 247 minecraft:light[level=15]
setblock 262 164 255 minecraft:light[level=15]
fill 262 164 263 262 165 263 minecraft:gray_concrete
fill 262 164 265 262 165 265 minecraft:gray_concrete
fill 262 164 267 262 165 267 minecraft:gray_concrete
fill 262 164 269 262 165 269 minecraft:gray_concrete
fill 263 164 264 263 165 264 minecraft:gray_concrete
fill 263 164 266 263 165 266 minecraft:gray_concrete
fill 263 164 268 263 165 268 minecraft:gray_concrete
fill 264 164 263 264 165 263 minecraft:gray_concrete
fill 264 164 265 264 165 265 minecraft:gray_concrete
fill 264 164 267 264 165 267 minecraft:gray_concrete
fill 264 164 269 264 165 269 minecraft:gray_concrete
fill 265 164 230 265 166 230 minecraft:gray_concrete
fill 265 164 232 265 166 232 minecraft:gray_concrete
fill 265 164 234 265 166 234 minecraft:gray_concrete
fill 265 164 264 265 165 264 minecraft:gray_concrete
fill 265 164 266 265 165 266 minecraft:gray_concrete
fill 265 164 268 265 165 268 minecraft:gray_concrete
fill 266 164 229 266 166 229 minecraft:gray_concrete
fill 266 164 231 266 166 231 minecraft:gray_concrete
fill 266 164 233 266 166 233 minecraft:gray_concrete
fill 266 164 263 266 165 263 minecraft:gray_concrete
fill 266 164 265 266 165 265 minecraft:gray_concrete
fill 266 164 267 266 165 267 minecraft:gray_concrete
fill 266 164 269 266 165 269 minecraft:gray_concrete
fill 267 164 230 267 166 230 minecraft:gray_concrete
fill 267 164 232 267 166 232 minecraft:gray_concrete
fill 267 164 234 267 166 234 minecraft:gray_concrete
fill 267 164 264 267 165 264 minecraft:gray_concrete
fill 267 164 266 267 165 266 minecraft:gray_concrete
fill 267 164 268 267 165 268 minecraft:gray_concrete
fill 268 164 229 268 208 229 minecraft:cyan_terracotta
setblock 268 164 230 minecraft:ochre_froglight
fill 268 164 231 268 208 231 minecraft:cyan_terracotta
setblock 268 164 232 minecraft:sea_lantern
fill 268 164 233 268 167 233 minecraft:cyan_terracotta
setblock 268 164 234 minecraft:black_stained_glass
setblock 268 164 236 minecraft:black_stained_glass
setblock 268 164 262 minecraft:black_stained_glass
fill 268 164 263 268 165 263 minecraft:gray_concrete
setblock 268 164 264 minecraft:black_stained_glass
fill 268 164 265 268 165 265 minecraft:gray_concrete
setblock 268 164 266 minecraft:black_stained_glass
fill 268 164 267 268 165 267 minecraft:gray_concrete
fill 268 164 269 268 165 269 minecraft:gray_concrete
setblock 269 164 229 minecraft:ochre_froglight
fill 269 164 230 269 208 230 minecraft:cyan_terracotta
fill 269 164 232 269 167 232 minecraft:cyan_terracotta
fill 269 164 234 269 208 234 minecraft:cyan_terracotta
setblock 269 164 237 minecraft:light_blue_stained_glass
setblock 269 164 261 minecraft:black_stained_glass
setblock 269 164 269 minecraft:magenta_stained_glass
fill 270 164 229 270 208 229 minecraft:cyan_terracotta
fill 270 164 231 270 208 231 minecraft:cyan_terracotta
fill 270 164 233 270 166 233 minecraft:cyan_terracotta
setblock 270 164 239 minecraft:light[level=15]
setblock 270 164 247 minecraft:light[level=15]
setblock 270 164 255 minecraft:light[level=15]
setblock 271 164 229 minecraft:cyan_stained_glass
fill 271 164 230 271 208 230 minecraft:cyan_terracotta
fill 271 164 232 271 167 232 minecraft:cyan_terracotta
fill 271 164 234 271 167 234 minecraft:cyan_terracotta
setblock 271 164 237 minecraft:ochre_froglight
setblock 271 164 243 minecraft:pearlescent_froglight
setblock 271 164 245 minecraft:black_stained_glass
setblock 271 164 247 minecraft:pearlescent_froglight
setblock 271 164 249 minecraft:ochre_froglight
setblock 271 164 251 minecraft:black_stained_glass
setblock 271 164 253 minecraft:pearlescent_froglight
setblock 271 164 261 minecraft:cyan_stained_glass
setblock 271 164 269 minecraft:black_stained_glass
fill 272 164 229 272 208 229 minecraft:cyan_terracotta
fill 272 164 231 272 208 231 minecraft:cyan_terracotta
fill 272 164 233 272 166 233 minecraft:cyan_terracotta
setblock 272 164 242 minecraft:black_stained_glass
setblock 272 164 255 minecraft:light_blue_stained_glass
setblock 273 164 229 minecraft:gray_concrete
fill 273 164 230 273 208 230 minecraft:cyan_terracotta
fill 273 164 232 273 208 232 minecraft:cyan_terracotta
fill 273 164 234 273 199 234 minecraft:cyan_terracotta
setblock 273 164 237 minecraft:light_blue_stained_glass
setblock 273 164 261 minecraft:light_blue_stained_glass
setblock 273 164 269 minecraft:black_stained_glass
setblock 274 164 242 minecraft:light_blue_stained_glass
setblock 274 164 255 minecraft:pearlescent_froglight
setblock 275 164 229 minecraft:ochre_froglight
setblock 275 164 237 minecraft:light_blue_stained_glass
setblock 275 164 261 minecraft:light_blue_stained_glass
setblock 275 164 269 minecraft:black_stained_glass
setblock 276 164 230 minecraft:light_blue_stained_glass
setblock 276 164 232 minecraft:black_stained_glass
setblock 276 164 234 minecraft:black_stained_glass
setblock 276 164 236 minecraft:black_stained_glass
setblock 276 164 243 minecraft:black_stained_glass
setblock 276 164 245 minecraft:black_stained_glass
setblock 276 164 247 minecraft:magenta_stained_glass
setblock 276 164 249 minecraft:sea_lantern
setblock 276 164 251 minecraft:light_blue_stained_glass
setblock 276 164 253 minecraft:black_stained_glass
setblock 276 164 262 minecraft:pearlescent_froglight
setblock 276 164 264 minecraft:black_stained_glass
setblock 276 164 266 minecraft:pearlescent_froglight
setblock 276 164 268 minecraft:magenta_stained_glass
fill 236 165 230 236 166 230 minecraft:light_gray_concrete
fill 236 165 232 236 166 232 minecraft:light_gray_concrete
fill 236 165 234 236 166 234 minecraft:light_gray_concrete
fill 236 165 236 236 166 236 minecraft:light_gray_concrete
fill 236 165 243 236 166 243 minecraft:light_gray_concrete
fill 236 165 245 236 166 245 minecraft:light_gray_concrete
fill 236 165 247 236 166 247 minecraft:light_gray_concrete
fill 236 165 249 236 166 249 minecraft:light_gray_concrete
fill 236 165 251 236 166 251 minecraft:light_gray_concrete
fill 236 165 253 236 166 253 minecraft:light_gray_concrete
fill 236 165 262 236 166 262 minecraft:cyan_terracotta
fill 236 165 264 236 166 264 minecraft:cyan_terracotta
fill 236 165 266 236 166 266 minecraft:cyan_terracotta
fill 236 165 268 236 166 268 minecraft:cyan_terracotta
fill 237 165 229 237 166 229 minecraft:light_gray_concrete
fill 237 165 237 237 166 237 minecraft:light_gray_concrete
fill 237 165 242 237 166 242 minecraft:light_gray_concrete
fill 237 165 255 237 166 255 minecraft:light_gray_concrete
fill 237 165 261 237 166 261 minecraft:cyan_terracotta
fill 237 165 269 237 166 269 minecraft:cyan_terracotta
fill 239 165 229 239 165 237 minecraft:light_gray_concrete
fill 239 165 242 239 166 242 minecraft:light_gray_concrete
fill 239 165 255 239 166 255 minecraft:light_gray_concrete
fill 239 165 261 239 166 261 minecraft:cyan_terracotta
fill 239 165 269 239 166 269 minecraft:cyan_terracotta
fill 240 165 230 242 165 232 minecraft:light_gray_concrete
fill 240 165 233 243 166 233 minecraft:sea_lantern
fill 240 165 234 240 165 236 minecraft:light_gray_concrete
fill 241 165 229 241 166 229 minecraft:light_gray_concrete
fill 241 165 237 241 166 237 minecraft:light_gray_concrete
fill 241 165 243 241 166 243 minecraft:light_gray_concrete
fill 241 165 245 241 166 245 minecraft:light_gray_concrete
fill 241 165 247 241 166 247 minecraft:light_gray_concrete
fill 241 165 249 241 166 249 minecraft:light_gray_concrete
fill 241 165 251 241 166 251 minecraft:light_gray_concrete
fill 241 165 253 241 166 253 minecraft:light_gray_concrete
fill 241 165 261 241 166 261 minecraft:cyan_terracotta
fill 241 165 269 241 166 269 minecraft:cyan_terracotta
fill 243 165 229 243 166 229 minecraft:light_gray_concrete
fill 243 165 231 243 165 232 minecraft:light_gray_concrete
fill 243 165 237 243 166 237 minecraft:light_gray_concrete
fill 243 165 261 243 166 261 minecraft:cyan_terracotta
fill 243 165 269 243 166 269 minecraft:cyan_terracotta
setblock 244 165 232 minecraft:light_gray_concrete
fill 244 165 234 244 166 234 minecraft:light_gray_concrete
fill 244 165 236 244 166 236 minecraft:light_gray_concrete
fill 244 165 262 244 166 262 minecraft:cyan_terracotta
fill 244 165 264 244 166 264 minecraft:cyan_terracotta
fill 244 165 266 244 166 266 minecraft:cyan_terracotta
fill 244 165 268 244 166 268 minecraft:cyan_terracotta
fill 247 165 232 248 166 232 minecraft:sea_lantern
fill 249 165 230 249 166 230 minecraft:light_gray_concrete
fill 250 165 229 250 166 229 minecraft:light_gray_concrete
fill 250 165 232 253 166 232 minecraft:sea_lantern
fill 250 165 233 250 165 234 minecraft:light_gray_concrete
fill 251 165 233 261 165 233 minecraft:light_gray_concrete
fill 252 165 229 252 166 229 minecraft:light_gray_concrete
fill 252 165 234 252 166 234 minecraft:light_gray_concrete
fill 252 165 266 252 166 267 minecraft:cyan_terracotta
fill 252 165 270 252 262 270 minecraft:black_concrete
fill 254 165 229 254 166 229 minecraft:light_gray_concrete
fill 254 165 232 262 165 232 minecraft:light_gray_concrete
fill 254 165 234 254 166 234 minecraft:light_gray_concrete
fill 254 165 266 254 166 267 minecraft:cyan_terracotta
fill 256 165 229 256 166 229 minecraft:light_gray_concrete
fill 256 165 234 256 166 234 minecraft:light_gray_concrete
fill 256 165 266 256 166 267 minecraft:cyan_terracotta
fill 258 165 229 258 166 229 minecraft:light_gray_concrete
fill 258 165 234 258 166 234 minecraft:light_gray_concrete
fill 258 165 266 258 166 267 minecraft:cyan_terracotta
fill 260 165 229 260 166 229 minecraft:light_gray_concrete
fill 260 165 234 260 166 234 minecraft:light_gray_concrete
fill 262 165 230 262 166 230 minecraft:light_gray_concrete
fill 268 165 230 268 166 230 minecraft:cyan_terracotta
fill 268 165 232 268 166 232 minecraft:cyan_terracotta
fill 268 165 234 268 166 234 minecraft:cyan_terracotta
fill 268 165 236 268 166 236 minecraft:cyan_terracotta
fill 268 165 262 268 166 262 minecraft:light_gray_concrete
fill 268 165 264 268 166 264 minecraft:gray_concrete
fill 268 165 266 268 166 266 minecraft:gray_concrete
fill 269 165 229 269 166 229 minecraft:cyan_terracotta
fill 269 165 237 269 166 237 minecraft:cyan_terracotta
fill 269 165 261 269 166 261 minecraft:light_gray_concrete
fill 269 165 269 269 166 269 minecraft:light_gray_concrete
fill 271 165 229 271 166 229 minecraft:cyan_terracotta
fill 271 165 237 271 166 237 minecraft:cyan_terracotta
fill 271 165 243 271 166 243 minecraft:light_gray_concrete
fill 271 165 245 271 166 245 minecraft:light_gray_concrete
fill 271 165 247 271 166 247 minecraft:light_gray_concrete
fill 271 165 249 271 166 249 minecraft:light_gray_concrete
fill 271 165 251 271 166 251 minecraft:light_gray_concrete
fill 271 165 253 271 166 253 minecraft:light_gray_concrete
fill 271 165 261 271 166 261 minecraft:light_gray_concrete
fill 271 165 269 271 166 269 minecraft:light_gray_concrete
fill 272 165 242 272 166 242 minecraft:light_gray_concrete
fill 272 165 255 272 166 255 minecraft:light_gray_concrete
fill 273 165 229 273 166 229 minecraft:cyan_terracotta
fill 273 165 237 273 166 237 minecraft:cyan_terracotta
fill 273 165 261 273 166 261 minecraft:light_gray_concrete
fill 273 165 269 273 166 269 minecraft:light_gray_concrete
fill 274 165 242 274 166 242 minecraft:light_gray_concrete
fill 274 165 255 274 166 255 minecraft:light_gray_concrete
fill 275 165 229 275 166 229 minecraft:cyan_terracotta
fill 275 165 237 275 166 237 minecraft:cyan_terracotta
fill 275 165 261 275 166 261 minecraft:light_gray_concrete
fill 275 165 269 275 166 269 minecraft:light_gray_concrete
fill 276 165 230 276 166 230 minecraft:cyan_terracotta
fill 276 165 232 276 166 232 minecraft:cyan_terracotta
fill 276 165 234 276 166 234 minecraft:cyan_terracotta
fill 276 165 236 276 166 236 minecraft:cyan_terracotta
fill 276 165 243 276 166 243 minecraft:light_gray_concrete
fill 276 165 245 276 166 245 minecraft:light_gray_concrete
fill 276 165 247 276 166 247 minecraft:light_gray_concrete
fill 276 165 249 276 166 249 minecraft:light_gray_concrete
fill 276 165 251 276 166 251 minecraft:light_gray_concrete
fill 276 165 253 276 166 253 minecraft:light_gray_concrete
fill 276 165 262 276 166 262 minecraft:light_gray_concrete
fill 276 165 264 276 166 264 minecraft:light_gray_concrete
fill 276 165 266 276 166 266 minecraft:light_gray_concrete
fill 276 165 268 276 166 268 minecraft:light_gray_concrete
fill 239 166 229 239 166 232 minecraft:light_gray_concrete
fill 239 166 233 239 167 233 minecraft:light_blue_stained_glass
fill 239 166 234 239 166 237 minecraft:light_gray_concrete
fill 240 166 230 242 167 231 minecraft:light_gray_concrete
fill 240 166 232 246 167 232 minecraft:light_blue_stained_glass
fill 240 166 234 242 167 234 minecraft:light_blue_stained_glass
fill 240 166 235 242 170 236 minecraft:light_gray_concrete
fill 243 166 231 243 225 231 minecraft:light_gray_concrete
fill 244 166 233 252 167 233 minecraft:light_blue_stained_glass
fill 249 166 231 256 167 231 minecraft:light_blue_stained_glass
setblock 250 166 234 minecraft:light_gray_concrete
fill 253 166 233 261 167 233 minecraft:light_gray_concrete
fill 254 166 232 256 167 232 minecraft:light_blue_stained_glass
fill 257 166 231 262 166 232 minecraft:light_gray_concrete
setblock 260 166 263 minecraft:sea_lantern
setblock 260 166 265 minecraft:sea_lantern
setblock 260 166 267 minecraft:sea_lantern
setblock 260 166 269 minecraft:sea_lantern
setblock 261 166 264 minecraft:sea_lantern
setblock 261 166 266 minecraft:sea_lantern
setblock 261 166 268 minecraft:sea_lantern
setblock 262 166 263 minecraft:sea_lantern
setblock 262 166 265 minecraft:sea_lantern
setblock 262 166 267 minecraft:sea_lantern
setblock 262 166 269 minecraft:sea_lantern
setblock 263 166 264 minecraft:sea_lantern
setblock 263 166 266 minecraft:sea_lantern
setblock 263 166 268 minecraft:sea_lantern
setblock 264 166 263 minecraft:sea_lantern
setblock 264 166 265 minecraft:sea_lantern
setblock 264 166 267 minecraft:sea_lantern
setblock 264 166 269 minecraft:sea_lantern
setblock 265 166 264 minecraft:sea_lantern
setblock 265 166 266 minecraft:sea_lantern
setblock 265 166 268 minecraft:sea_lantern
setblock 266 166 263 minecraft:sea_lantern
setblock 266 166 265 minecraft:sea_lantern
setblock 266 166 267 minecraft:sea_lantern
setblock 266 166 269 minecraft:sea_lantern
setblock 267 166 264 minecraft:sea_lantern
setblock 267 166 266 minecraft:sea_lantern
setblock 267 166 268 minecraft:sea_lantern
setblock 268 166 263 minecraft:sea_lantern
setblock 268 166 265 minecraft:sea_lantern
setblock 268 166 267 minecraft:sea_lantern
setblock 268 166 269 minecraft:sea_lantern
setblock 277 166 236 minecraft:purple_concrete
setblock 235 167 233 minecraft:magenta_concrete
setblock 236 167 230 minecraft:black_stained_glass
setblock 236 167 232 minecraft:pearlescent_froglight
setblock 236 167 234 minecraft:black_stained_glass
setblock 236 167 236 minecraft:black_stained_glass
setblock 236 167 243 minecraft:sea_lantern
setblock 236 167 245 minecraft:cyan_stained_glass
setblock 236 167 247 minecraft:black_stained_glass
setblock 236 167 249 minecraft:black_stained_glass
setblock 236 167 251 minecraft:black_stained_glass
setblock 236 167 253 minecraft:magenta_stained_glass
setblock 236 167 262 minecraft:sea_lantern
setblock 236 167 264 minecraft:magenta_stained_glass
setblock 236 167 266 minecraft:black_stained_glass
setblock 236 167 268 minecraft:sea_lantern
setblock 237 167 229 minecraft:pearlescent_froglight
setblock 237 167 237 minecraft:cyan_stained_glass
setblock 237 167 242 minecraft:black_stained_glass
setblock 237 167 255 minecraft:light_blue_stained_glass
setblock 237 167 261 minecraft:sea_lantern
setblock 237 167 269 minecraft:sea_lantern
setblock 239 167 229 minecraft:pearlescent_froglight
fill 239 167 230 239 225 232 minecraft:light_gray_concrete
fill 239 167 234 239 171 236 minecraft:light_gray_concrete
setblock 239 167 237 minecraft:black_stained_glass
setblock 239 167 242 minecraft:black_stained_glass
setblock 239 167 255 minecraft:black_stained_glass
setblock 239 167 261 minecraft:black_stained_glass
setblock 239 167 269 minecraft:pearlescent_froglight
fill 240 167 233 243 167 233 minecraft:light_blue_stained_glass
setblock 241 167 229 minecraft:black_stained_glass
setblock 241 167 237 minecraft:ochre_froglight
setblock 241 167 243 minecraft:magenta_stained_glass
setblock 241 167 245 minecraft:cyan_stained_glass
setblock 241 167 247 minecraft:black_stained_glass
setblock 241 167 249 minecraft:cyan_stained_glass
setblock 241 167 251 minecraft:cyan_stained_glass
setblock 241 167 253 minecraft:cyan_stained_glass
setblock 241 167 261 minecraft:black_stained_glass
setblock 241 167 269 minecraft:cyan_stained_glass
setblock 243 167 229 minecraft:ochre_froglight
setblock 243 167 237 minecraft:black_stained_glass
setblock 243 167 261 minecraft:magenta_stained_glass
setblock 243 167 269 minecraft:black_stained_glass
setblock 244 167 230 minecraft:sea_lantern
setblock 244 167 234 minecraft:black_stained_glass
setblock 244 167 236 minecraft:sea_lantern
setblock 244 167 262 minecraft:black_stained_glass
setblock 244 167 264 minecraft:black_stained_glass
setblock 244 167 266 minecraft:light_blue_stained_glass
setblock 244 167 268 minecraft:black_stained_glass
fill 247 167 232 253 167 232 minecraft:light_blue_stained_glass
setblock 249 167 230 minecraft:black_stained_glass
setblock 250 167 229 minecraft:black_stained_glass
setblock 250 167 234 minecraft:black_stained_glass
setblock 252 167 229 minecraft:light_blue_stained_glass
setblock 252 167 234 minecraft:black_stained_glass
setblock 252 167 266 minecraft:ochre_froglight
setblock 252 167 267 minecraft:black_stained_glass
setblock 254 167 229 minecraft:light_blue_stained_glass
setblock 254 167 234 minecraft:black_stained_glass
fill 254 167 266 254 167 267 minecraft:black_stained_glass
setblock 256 167 229 minecraft:magenta_stained_glass
setblock 256 167 234 minecraft:sea_lantern
setblock 256 167 266 minecraft:black_stained_glass
setblock 256 167 267 minecraft:cyan_stained_glass
fill 257 167 231 257 167 232 minecraft:light_gray_concrete
setblock 258 167 229 minecraft:ochre_froglight
fill 258 167 231 262 167 231 minecraft:light_gray_concrete
fill 258 167 232 264 168 232 minecraft:sea_lantern
setblock 258 167 234 minecraft:black_stained_glass
setblock 258 167 266 minecraft:ochre_froglight
setblock 258 167 267 minecraft:black_stained_glass
setblock 260 167 229 minecraft:magenta_stained_glass
setblock 260 167 234 minecraft:magenta_stained_glass
fill 260 167 263 260 169 263 minecraft:gray_concrete
fill 260 167 265 260 169 265 minecraft:gray_concrete
fill 260 167 267 260 169 267 minecraft:cyan_terracotta
fill 260 167 269 260 169 269 minecraft:gray_concrete
fill 261 167 264 261 169 264 minecraft:gray_concrete
fill 261 167 266 261 169 266 minecraft:gray_concrete
fill 261 167 268 261 169 268 minecraft:gray_concrete
setblock 262 167 230 minecraft:magenta_stained_glass
fill 262 167 263 262 169 263 minecraft:gray_concrete
fill 262 167 265 262 169 265 minecraft:gray_concrete
fill 262 167 267 262 169 267 minecraft:gray_concrete
fill 262 167 269 262 169 269 minecraft:gray_concrete
fill 263 167 264 263 169 264 minecraft:gray_concrete
fill 263 167 266 263 169 266 minecraft:gray_concrete
fill 263 167 268 263 169 268 minecraft:gray_concrete
fill 264 167 263 264 168 263 minecraft:gray_concrete
fill 264 167 265 264 168 265 minecraft:gray_concrete
fill 264 167 267 264 168 267 minecraft:gray_concrete
fill 264 167 269 264 168 269 minecraft:gray_concrete
fill 265 167 264 265 168 264 minecraft:gray_concrete
fill 265 167 266 265 168 266 minecraft:gray_concrete
fill 265 167 268 265 168 268 minecraft:gray_concrete
fill 266 167 263 266 168 263 minecraft:gray_concrete
fill 266 167 265 266 168 265 minecraft:gray_concrete
fill 266 167 267 266 168 267 minecraft:gray_concrete
fill 266 167 269 266 168 269 minecraft:gray_concrete
fill 267 167 264 267 168 264 minecraft:gray_concrete
fill 267 167 266 267 168 266 minecraft:gray_concrete
fill 267 167 268 267 168 268 minecraft:gray_concrete
setblock 268 167 230 minecraft:ochre_froglight
setblock 268 167 232 minecraft:black_stained_glass
setblock 268 167 234 minecraft:cyan_stained_glass
setblock 268 167 236 minecraft:black_stained_glass
setblock 268 167 262 minecraft:sea_lantern
fill 268 167 263 268 168 263 minecraft:gray_concrete
setblock 268 167 264 minecraft:black_stained_glass
fill 268 167 265 268 168 265 minecraft:gray_concrete
setblock 268 167 266 minecraft:black_stained_glass
fill 268 167 267 268 168 267 minecraft:gray_concrete
setblock 268 167 268 minecraft:black_stained_glass
fill 268 167 269 268 168 269 minecraft:gray_concrete
setblock 269 167 229 minecraft:black_stained_glass
fill 269 167 233 272 168 233 minecraft:sea_lantern
setblock 269 167 237 minecraft:sea_lantern
setblock 269 167 261 minecraft:cyan_stained_glass
setblock 269 167 269 minecraft:black_stained_glass
setblock 271 167 229 minecraft:black_stained_glass
setblock 271 167 237 minecraft:black_stained_glass
setblock 271 167 243 minecraft:cyan_stained_glass
setblock 271 167 245 minecraft:black_stained_glass
setblock 271 167 247 minecraft:black_stained_glass
setblock 271 167 249 minecraft:light_blue_stained_glass
setblock 271 167 251 minecraft:magenta_stained_glass
setblock 271 167 253 minecraft:sea_lantern
setblock 271 167 261 minecraft:magenta_stained_glass
setblock 271 167 269 minecraft:cyan_stained_glass
setblock 272 167 242 minecraft:magenta_stained_glass
setblock 272 167 255 minecraft:pearlescent_froglight
setblock 273 167 229 minecraft:black_stained_glass
setblock 273 167 237 minecraft:black_stained_glass
setblock 273 167 261 minecraft:cyan_stained_glass
setblock 273 167 269 minecraft:ochre_froglight
setblock 274 167 242 minecraft:magenta_stained_glass
setblock 274 167 255 minecraft:pearlescent_froglight
setblock 275 167 229 minecraft:ochre_froglight
setblock 275 167 237 minecraft:black_stained_glass
setblock 275 167 261 minecraft:ochre_froglight
setblock 275 167 269 minecraft:ochre_froglight
setblock 276 167 230 minecraft:black_stained_glass
setblock 276 167 232 minecraft:cyan_stained_glass
setblock 276 167 234 minecraft:magenta_stained_glass
setblock 276 167 236 minecraft:cyan_stained_glass
setblock 276 167 243 minecraft:pearlescent_froglight
setblock 276 167 245 minecraft:black_stained_glass
setblock 276 167 247 minecraft:pearlescent_froglight
setblock 276 167 249 minecraft:pearlescent_froglight
setblock 276 167 251 minecraft:pearlescent_froglight
setblock 276 167 253 minecraft:black_stained_glass
setblock 276 167 262 minecraft:magenta_stained_glass
setblock 276 167 264 minecraft:black_stained_glass
setblock 276 167 266 minecraft:ochre_froglight
setblock 276 167 268 minecraft:magenta_stained_glass
fill 277 167 236 277 171 236 minecraft:black_concrete
fill 235 168 233 235 170 233 minecraft:black_concrete
setblock 235 168 245 minecraft:ochre_froglight
setblock 235 168 252 minecraft:ochre_froglight
fill 236 168 230 236 169 230 minecraft:light_gray_concrete
fill 236 168 232 236 169 232 minecraft:light_gray_concrete
fill 236 168 234 236 169 234 minecraft:light_gray_concrete
fill 236 168 236 236 169 236 minecraft:light_gray_concrete
fill 236 168 243 236 169 243 minecraft:light_gray_concrete
fill 236 168 245 236 169 245 minecraft:light_gray_concrete
fill 236 168 247 236 169 247 minecraft:light_gray_concrete
fill 236 168 249 236 169 249 minecraft:light_gray_concrete
fill 236 168 251 236 169 251 minecraft:light_gray_concrete
fill 236 168 253 236 169 253 minecraft:light_gray_concrete
fill 236 168 262 236 169 262 minecraft:cyan_terracotta
fill 236 168 264 236 169 264 minecraft:cyan_terracotta
fill 236 168 266 236 169 266 minecraft:cyan_terracotta
fill 236 168 268 236 169 268 minecraft:cyan_terracotta
fill 237 168 229 237 169 229 minecraft:light_gray_concrete
fill 237 168 237 237 169 237 minecraft:light_gray_concrete
fill 237 168 242 237 169 242 minecraft:light_gray_concrete
fill 237 168 255 237 169 255 minecraft:light_gray_concrete
fill 237 168 261 237 169 261 minecraft:cyan_terracotta
fill 237 168 269 237 169 269 minecraft:cyan_terracotta
fill 239 168 229 239 169 229 minecraft:light_gray_concrete
fill 239 168 233 244 170 233 minecraft:light_gray_concrete
fill 239 168 237 239 169 237 minecraft:light_gray_concrete
fill 239 168 242 239 169 242 minecraft:light_gray_concrete
setblock 239 168 255 minecraft:light_gray_concrete
fill 239 168 261 239 169 261 minecraft:cyan_terracotta
fill 239 168 269 239 169 269 minecraft:cyan_terracotta
fill 240 168 230 241 171 232 minecraft:light_gray_concrete
fill 240 168 234 242 170 234 minecraft:light_gray_concrete
fill 241 168 229 241 169 229 minecraft:light_gray_concrete
fill 241 168 237 241 169 237 minecraft:light_gray_concrete
fill 241 168 243 241 169 243 minecraft:light_gray_concrete
fill 241 168 245 241 169 245 minecraft:light_gray_concrete
fill 241 168 247 241 169 247 minecraft:light_gray_concrete
fill 241 168 249 241 169 249 minecraft:light_gray_concrete
fill 241 168 251 241 169 251 minecraft:light_gray_concrete
fill 241 168 253 241 169 253 minecraft:light_gray_concrete
fill 241 168 261 241 169 261 minecraft:cyan_terracotta
fill 241 168 269 241 169 269 minecraft:cyan_terracotta
fill 242 168 230 248 169 230 minecraft:iron_block
fill 242 168 231 242 225 232 minecraft:light_gray_concrete
fill 243 168 229 243 169 229 minecraft:light_gray_concrete
fill 243 168 232 244 169 232 minecraft:light_gray_concrete
fill 243 168 237 243 169 237 minecraft:light_gray_concrete
fill 243 168 261 243 169 261 minecraft:cyan_terracotta
fill 243 168 269 243 169 269 minecraft:cyan_terracotta
fill 244 168 234 244 169 234 minecraft:light_gray_concrete
fill 244 168 236 244 169 236 minecraft:light_gray_concrete
fill 244 168 262 244 169 262 minecraft:cyan_terracotta
fill 244 168 264 244 169 264 minecraft:cyan_terracotta
fill 244 168 266 244 169 266 minecraft:cyan_terracotta
fill 244 168 268 244 169 268 minecraft:cyan_terracotta
fill 249 168 230 249 169 233 minecraft:light_gray_concrete
fill 250 168 229 250 169 229 minecraft:light_gray_concrete
fill 250 168 231 250 169 234 minecraft:light_gray_concrete
fill 251 168 231 254 175 233 minecraft:light_gray_concrete
fill 252 168 229 252 169 229 minecraft:light_gray_concrete
fill 252 168 234 252 169 234 minecraft:light_gray_concrete
fill 252 168 266 252 169 267 minecraft:cyan_terracotta
fill 254 168 229 254 169 229 minecraft:light_gray_concrete
fill 254 168 234 254 169 234 minecraft:light_gray_concrete
fill 254 168 266 254 169 267 minecraft:cyan_terracotta
fill 255 168 231 257 169 232 minecraft:light_blue_stained_glass
fill 255 168 233 258 175 233 minecraft:light_gray_concrete
fill 256 168 229 256 169 229 minecraft:light_gray_concrete
fill 256 168 234 256 169 234 minecraft:light_gray_concrete
fill 256 168 266 256 169 267 minecraft:cyan_terracotta
fill 258 168 229 258 169 229 minecraft:light_gray_concrete
fill 258 168 231 263 169 231 minecraft:light_blue_stained_glass
fill 258 168 234 258 169 234 minecraft:light_gray_concrete
fill 258 168 266 258 169 267 minecraft:cyan_terracotta
fill 259 168 233 268 169 233 minecraft:light_blue_stained_glass
fill 260 168 229 260 169 229 minecraft:light_gray_concrete
fill 260 168 234 260 169 234 minecraft:light_gray_concrete
fill 262 168 230 262 169 230 minecraft:light_gray_concrete
fill 265 168 232 272 169 232 minecraft:light_blue_stained_glass
fill 268 168 230 268 169 230 minecraft:cyan_terracotta
fill 268 168 234 268 169 234 minecraft:cyan_terracotta
fill 268 168 236 268 169 236 minecraft:cyan_terracotta
fill 268 168 262 268 169 262 minecraft:light_gray_concrete
setblock 268 168 264 minecraft:gray_concrete
setblock 268 168 266 minecraft:gray_concrete
setblock 268 168 268 minecraft:gray_concrete
fill 269 168 229 269 169 229 minecraft:cyan_terracotta
fill 269 168 237 269 169 237 minecraft:cyan_terracotta
fill 269 168 261 269 169 261 minecraft:light_gray_concrete
fill 269 168 269 269 169 269 minecraft:light_gray_concrete
fill 270 168 234 272 169 234 minecraft:light_blue_stained_glass
fill 271 168 229 271 169 229 minecraft:cyan_terracotta
fill 271 168 237 271 169 237 minecraft:cyan_terracotta
fill 271 168 243 271 169 243 minecraft:light_gray_concrete
fill 271 168 245 271 169 245 minecraft:light_gray_concrete
fill 271 168 247 271 169 247 minecraft:light_gray_concrete
fill 271 168 249 271 169 249 minecraft:light_gray_concrete
fill 271 168 251 271 169 251 minecraft:light_gray_concrete
fill 271 168 253 271 169 253 minecraft:light_gray_concrete
fill 271 168 261 271 169 261 minecraft:light_gray_concrete
fill 271 168 269 271 169 269 minecraft:light_gray_concrete
fill 272 168 242 272 169 242 minecraft:light_gray_concrete
fill 272 168 255 272 169 255 minecraft:light_gray_concrete
fill 273 168 229 273 169 229 minecraft:cyan_terracotta
fill 273 168 233 273 169 233 minecraft:light_blue_stained_glass
fill 273 168 237 273 169 237 minecraft:cyan_terracotta
fill 273 168 261 273 169 261 minecraft:light_gray_concrete
fill 273 168 269 273 169 269 minecraft:light_gray_concrete
fill 274 168 242 274 169 242 minecraft:light_gray_concrete
fill 274 168 255 274 169 255 minecraft:light_gray_concrete
fill 275 168 229 275 169 229 minecraft:cyan_terracotta
fill 275 168 237 275 169 237 minecraft:cyan_terracotta
fill 275 168 261 275 169 261 minecraft:light_gray_concrete
fill 275 168 269 275 169 269 minecraft:light_gray_concrete
fill 276 168 230 276 169 230 minecraft:cyan_terracotta
fill 276 168 232 276 169 232 minecraft:cyan_terracotta
fill 276 168 234 276 169 234 minecraft:cyan_terracotta
fill 276 168 236 276 169 236 minecraft:cyan_terracotta
fill 276 168 243 276 169 243 minecraft:light_gray_concrete
fill 276 168 245 276 169 245 minecraft:light_gray_concrete
fill 276 168 247 276 169 247 minecraft:light_gray_concrete
fill 276 168 249 276 169 249 minecraft:light_gray_concrete
fill 276 168 251 276 169 251 minecraft:light_gray_concrete
fill 276 168 253 276 169 253 minecraft:light_gray_concrete
fill 276 168 262 276 169 262 minecraft:light_gray_concrete
fill 276 168 264 276 169 264 minecraft:light_gray_concrete
fill 276 168 266 276 169 266 minecraft:light_gray_concrete
fill 276 168 268 276 169 268 minecraft:light_gray_concrete
setblock 235 169 238 minecraft:verdant_froglight
fill 235 169 245 235 204 245 minecraft:black_concrete
fill 235 169 252 235 175 252 minecraft:black_concrete
fill 236 169 252 238 169 252 minecraft:light_gray_concrete
fill 236 169 254 238 169 254 minecraft:light_gray_concrete
fill 236 169 263 239 169 263 minecraft:cyan_terracotta
fill 236 169 265 239 169 265 minecraft:cyan_terracotta
fill 237 169 251 238 169 251 minecraft:light_gray_concrete
setblock 238 169 238 minecraft:light[level=12]
setblock 238 169 259 minecraft:light[level=12]
fill 239 169 251 239 170 257 minecraft:sea_lantern
fill 240 169 251 240 169 254 minecraft:light_gray_concrete
fill 240 169 262 240 170 265 minecraft:sea_lantern
fill 241 169 252 241 183 252 minecraft:light_gray_concrete
fill 241 169 254 241 183 254 minecraft:light_gray_concrete
fill 241 169 263 243 169 265 minecraft:cyan_terracotta
fill 244 169 263 244 198 263 minecraft:cyan_terracotta
fill 244 169 265 244 198 265 minecraft:cyan_terracotta
setblock 245 169 231 minecraft:light[level=12]
setblock 245 169 238 minecraft:light[level=12]
setblock 245 169 245 minecraft:light[level=12]
setblock 245 169 252 minecraft:light[level=12]
setblock 245 169 259 minecraft:light[level=12]
setblock 245 169 266 minecraft:light[level=12]
setblock 252 169 238 minecraft:light[level=12]
setblock 252 169 245 minecraft:light[level=12]
setblock 252 169 252 minecraft:light[level=12]
setblock 252 169 259 minecraft:light[level=12]
fill 258 169 232 264 169 232 minecraft:light_blue_stained_glass
setblock 259 169 238 minecraft:light[level=12]
setblock 259 169 245 minecraft:light[level=12]
setblock 259 169 252 minecraft:light[level=12]
setblock 259 169 259 minecraft:light[level=12]
fill 264 169 267 264 173 267 minecraft:cyan_wool
setblock 266 169 231 minecraft:light[level=12]
setblock 266 169 238 minecraft:light[level=12]
setblock 266 169 245 minecraft:light[level=12]
setblock 266 169 252 minecraft:light[level=12]
setblock 266 169 259 minecraft:light[level=12]
setblock 266 169 266 minecraft:light[level=12]
fill 268 169 263 268 169 269 minecraft:light_gray_concrete
fill 269 169 233 272 169 233 minecraft:light_blue_stained_glass
setblock 273 169 238 minecraft:light[level=12]
setblock 273 169 259 minecraft:light[level=12]
setblock 277 169 248 minecraft:ochre_froglight
fill 235 170 238 235 177 238 minecraft:black_concrete
setblock 235 170 243 minecraft:pearlescent_froglight
setblock 235 170 267 minecraft:verdant_froglight
setblock 236 170 230 minecraft:black_stained_glass
setblock 236 170 232 minecraft:black_stained_glass
setblock 236 170 234 minecraft:light_blue_stained_glass
setblock 236 170 236 minecraft:pearlescent_froglight
setblock 236 170 243 minecraft:sea_lantern
setblock 236 170 245 minecraft:ochre_froglight
setblock 236 170 247 minecraft:sea_lantern
fill 236 170 248 237 183 248 minecraft:light_gray_concrete
setblock 236 170 249 minecraft:sea_lantern
fill 236 170 250 237 183 250 minecraft:light_gray_concrete
setblock 236 170 251 minecraft:cyan_stained_glass
fill 236 170 252 237 183 252 minecraft:light_gray_concrete
setblock 236 170 253 minecraft:sea_lantern
fill 236 170 254 237 183 254 minecraft:light_gray_concrete
setblock 236 170 262 minecraft:black_stained_glass
fill 236 170 263 238 198 263 minecraft:cyan_terracotta
setblock 236 170 264 minecraft:ochre_froglight
fill 236 170 265 238 198 265 minecraft:cyan_terracotta
setblock 236 170 266 minecraft:pearlescent_froglight
setblock 236 170 268 minecraft:black_stained_glass
setblock 237 170 229 minecraft:black_stained_glass
setblock 237 170 237 minecraft:ochre_froglight
setblock 237 170 242 minecraft:black_stained_glass
fill 237 170 249 237 183 249 minecraft:light_gray_concrete
fill 237 170 251 237 183 251 minecraft:light_gray_concrete
fill 237 170 253 237 183 253 minecraft:light_gray_concrete
setblock 237 170 255 minecraft:black_stained_glass
setblock 237 170 261 minecraft:cyan_stained_glass
setblock 237 170 269 minecraft:black_stained_glass
fill 238 170 248 238 171 256 minecraft:light_blue_stained_glass
setblock 239 170 229 minecraft:ochre_froglight
setblock 239 170 237 minecraft:cyan_stained_glass
setblock 239 170 242 minecraft:magenta_stained_glass
fill 239 170 248 239 171 250 minecraft:light_blue_stained_glass
fill 239 170 258 239 171 265 minecraft:light_blue_stained_glass
setblock 239 170 269 minecraft:magenta_stained_glass
fill 240 170 248 240 183 251 minecraft:light_gray_concrete
fill 240 170 252 240 171 261 minecraft:light_blue_stained_glass
fill 240 170 266 240 171 266 minecraft:light_blue_stained_glass
setblock 241 170 229 minecraft:cyan_stained_glass
setblock 241 170 237 minecraft:black_stained_glass
setblock 241 170 243 minecraft:black_stained_glass
setblock 241 170 245 minecraft:cyan_stained_glass
setblock 241 170 247 minecraft:cyan_stained_glass
setblock 241 170 249 minecraft:cyan_stained_glass
setblock 241 170 251 minecraft:magenta_stained_glass
setblock 241 170 253 minecraft:magenta_stained_glass
fill 241 170 255 241 183 255 minecraft:light_gray_concrete
setblock 241 170 261 minecraft:pearlescent_froglight
fill 241 170 263 241 171 265 minecraft:light_blue_stained_glass
fill 241 170 266 243 198 266 minecraft:cyan_terracotta
setblock 241 170 269 minecraft:black_stained_glass
fill 242 170 230 243 225 230 minecraft:light_gray_concrete
fill 242 170 263 243 198 265 minecraft:cyan_terracotta
setblock 243 170 229 minecraft:sea_lantern
fill 243 170 232 243 225 232 minecraft:light_gray_concrete
setblock 243 170 237 minecraft:black_stained_glass
setblock 243 170 261 minecraft:cyan_stained_glass
setblock 243 170 269 minecraft:pearlescent_froglight
setblock 244 170 230 minecraft:magenta_stained_glass
setblock 244 170 232 minecraft:black_stained_glass
setblock 244 170 234 minecraft:black_stained_glass
setblock 244 170 236 minecraft:magenta_stained_glass
setblock 244 170 262 minecraft:ochre_froglight
setblock 244 170 264 minecraft:magenta_stained_glass
setblock 244 170 266 minecraft:black_stained_glass
setblock 244 170 268 minecraft:sea_lantern
setblock 249 170 230 minecraft:black_stained_glass
fill 249 170 231 250 175 231 minecraft:light_gray_concrete
setblock 249 170 232 minecraft:black_stained_glass
fill 249 170 233 250 175 233 minecraft:light_gray_concrete
setblock 250 170 229 minecraft:ochre_froglight
fill 250 170 232 250 175 232 minecraft:light_gray_concrete
setblock 250 170 234 minecraft:light_blue_stained_glass
setblock 252 170 229 minecraft:black_stained_glass
setblock 252 170 234 minecraft:pearlescent_froglight
setblock 254 170 229 minecraft:ochre_froglight
setblock 254 170 234 minecraft:light_blue_stained_glass
fill 255 170 231 261 175 232 minecraft:light_gray_concrete
setblock 256 170 229 minecraft:ochre_froglight
setblock 256 170 234 minecraft:magenta_stained_glass
setblock 258 170 229 minecraft:magenta_stained_glass
setblock 258 170 234 minecraft:black_stained_glass
fill 259 170 233 262 175 233 minecraft:light_gray_concrete
setblock 259 170 270 minecraft:blue_concrete
setblock 260 170 229 minecraft:sea_lantern
setblock 260 170 234 minecraft:ochre_froglight
fill 260 170 267 263 173 267 minecraft:cyan_wool
setblock 262 170 230 minecraft:magenta_stained_glass
fill 262 170 231 262 175 231 minecraft:light_gray_concrete
setblock 262 170 232 minecraft:light_blue_stained_glass
setblock 268 170 230 minecraft:sea_lantern
setblock 268 170 232 minecraft:light_blue_stained_glass
fill 268 170 233 273 198 233 minecraft:cyan_terracotta
setblock 268 170 234 minecraft:black_stained_glass
setblock 268 170 236 minecraft:pearlescent_froglight
setblock 268 170 262 minecraft:magenta_stained_glass
fill 268 170 263 268 191 263 minecraft:light_gray_concrete
setblock 268 170 264 minecraft:cyan_stained_glass
fill 268 170 265 268 237 265 minecraft:light_gray_concrete
setblock 268 170 266 minecraft:black_stained_glass
fill 268 170 267 268 237 267 minecraft:light_gray_concrete
setblock 268 170 268 minecraft:cyan_stained_glass
fill 268 170 269 268 237 269 minecraft:light_gray_concrete
setblock 269 170 229 minecraft:black_stained_glass
fill 269 170 232 272 199 232 minecraft:cyan_terracotta
setblock 269 170 237 minecraft:magenta_stained_glass
setblock 269 170 261 minecraft:black_stained_glass
setblock 269 170 269 minecraft:cyan_stained_glass
fill 270 170 234 272 198 234 minecraft:cyan_terracotta
setblock 271 170 229 minecraft:black_stained_glass
setblock 271 170 237 minecraft:black_stained_glass
setblock 271 170 243 minecraft:black_stained_glass
setblock 271 170 245 minecraft:black_stained_glass
setblock 271 170 247 minecraft:sea_lantern
setblock 271 170 249 minecraft:black_stained_glass
setblock 271 170 251 minecraft:pearlescent_froglight
setblock 271 170 253 minecraft:magenta_stained_glass
setblock 271 170 261 minecraft:sea_lantern
setblock 271 170 269 minecraft:sea_lantern
setblock 272 170 242 minecraft:cyan_stained_glass
setblock 272 170 255 minecraft:sea_lantern
setblock 273 170 229 minecraft:light_blue_stained_glass
setblock 273 170 237 minecraft:ochre_froglight
setblock 273 170 261 minecraft:pearlescent_froglight
setblock 273 170 269 minecraft:ochre_froglight
setblock 274 170 242 minecraft:black_stained_glass
setblock 274 170 255 minecraft:black_stained_glass
setblock 275 170 229 minecraft:black_stained_glass
setblock 275 170 237 minecraft:ochre_froglight
setblock 275 170 261 minecraft:magenta_stained_glass
setblock 275 170 269 minecraft:cyan_stained_glass
setblock 276 170 230 minecraft:light_blue_stained_glass
setblock 276 170 232 minecraft:cyan_stained_glass
setblock 276 170 234 minecraft:black_stained_glass
setblock 276 170 236 minecraft:ochre_froglight
setblock 276 170 243 minecraft:cyan_stained_glass
setblock 276 170 245 minecraft:light_blue_stained_glass
setblock 276 170 247 minecraft:pearlescent_froglight
setblock 276 170 249 minecraft:black_stained_glass
setblock 276 170 251 minecraft:black_stained_glass
setblock 276 170 253 minecraft:black_stained_glass
setblock 276 170 262 minecraft:cyan_stained_glass
setblock 276 170 264 minecraft:black_stained_glass
setblock 276 170 266 minecraft:cyan_stained_glass
setblock 276 170 268 minecraft:cyan_stained_glass
fill 277 170 248 277 180 248 minecraft:black_concrete
setblock 235 171 233 minecraft:blue_concrete
fill 235 171 243 235 188 243 minecraft:black_concrete
fill 235 171 267 235 185 267 minecraft:black_concrete
fill 236 171 230 236 172 230 minecraft:light_gray_concrete
fill 236 171 232 236 172 232 minecraft:light_gray_concrete
fill 236 171 234 236 172 234 minecraft:light_gray_concrete
fill 236 171 236 236 172 236 minecraft:light_gray_concrete
fill 236 171 243 236 172 243 minecraft:light_gray_concrete
fill 236 171 245 236 172 245 minecraft:light_gray_concrete
fill 236 171 247 236 172 247 minecraft:light_gray_concrete
fill 236 171 249 236 172 249 minecraft:light_gray_concrete
fill 236 171 251 236 172 251 minecraft:light_gray_concrete
fill 236 171 253 236 172 253 minecraft:light_gray_concrete
fill 236 171 262 236 172 262 minecraft:cyan_terracotta
fill 236 171 264 236 172 264 minecraft:cyan_terracotta
fill 236 171 266 236 172 266 minecraft:cyan_terracotta
fill 236 171 268 236 172 268 minecraft:cyan_terracotta
fill 237 171 229 237 172 229 minecraft:light_gray_concrete
fill 237 171 237 237 172 237 minecraft:light_gray_concrete
fill 237 171 242 237 172 242 minecraft:light_gray_concrete
fill 237 171 255 237 172 255 minecraft:light_gray_concrete
fill 237 171 261 237 172 261 minecraft:cyan_terracotta
fill 237 171 269 237 172 269 minecraft:cyan_terracotta
setblock 238 171 239 minecraft:light[level=15]
fill 238 171 243 238 171 246 minecraft:light_gray_concrete
fill 239 171 229 239 172 229 minecraft:light_gray_concrete
setblock 239 171 233 minecraft:light_gray_concrete
setblock 239 171 237 minecraft:light_gray_concrete
fill 239 171 240 239 172 246 minecraft:sea_lantern
fill 239 171 251 239 171 257 minecraft:light_blue_stained_glass
fill 239 171 269 239 172 269 minecraft:cyan_terracotta
fill 240 171 233 240 172 236 minecraft:sea_lantern
fill 240 171 243 240 171 246 minecraft:light_gray_concrete
fill 240 171 262 240 171 265 minecraft:light_blue_stained_glass
fill 241 171 229 241 172 229 minecraft:light_gray_concrete
fill 241 171 233 241 171 237 minecraft:light_gray_concrete
fill 241 171 243 241 172 243 minecraft:light_gray_concrete
fill 241 171 245 241 172 247 minecraft:light_gray_concrete
fill 241 171 249 241 172 249 minecraft:light_gray_concrete
fill 241 171 251 241 172 251 minecraft:light_gray_concrete
fill 241 171 253 241 172 253 minecraft:light_gray_concrete
fill 241 171 261 241 172 261 minecraft:cyan_terracotta
fill 241 171 269 241 172 269 minecraft:cyan_terracotta
fill 242 171 233 242 225 236 minecraft:light_gray_concrete
fill 243 171 229 243 172 229 minecraft:light_gray_concrete
fill 243 171 233 244 225 233 minecraft:light_gray_concrete
fill 243 171 237 243 172 237 minecraft:light_gray_concrete
fill 243 171 261 243 172 261 minecraft:cyan_terracotta
fill 243 171 269 243 172 269 minecraft:cyan_terracotta
fill 244 171 230 244 172 230 minecraft:light_gray_concrete
fill 244 171 232 244 172 232 minecraft:light_gray_concrete
fill 244 171 234 244 172 234 minecraft:light_gray_concrete
fill 244 171 236 244 172 236 minecraft:light_gray_concrete
fill 244 171 262 244 172 262 minecraft:cyan_terracotta
fill 244 171 264 244 172 264 minecraft:cyan_terracotta
fill 244 171 266 244 172 266 minecraft:cyan_terracotta
fill 244 171 268 244 172 268 minecraft:cyan_terracotta
setblock 246 171 231 minecraft:light[level=15]
setblock 246 171 239 minecraft:light[level=15]
setblock 246 171 247 minecraft:light[level=15]
setblock 246 171 255 minecraft:light[level=15]
setblock 246 171 263 minecraft:light[level=15]
fill 249 171 230 249 172 230 minecraft:light_gray_concrete
fill 249 171 232 249 172 232 minecraft:light_gray_concrete
fill 250 171 229 250 172 229 minecraft:light_gray_concrete
fill 250 171 234 250 172 234 minecraft:light_gray_concrete
fill 252 171 229 252 172 229 minecraft:light_gray_concrete
fill 252 171 234 252 172 234 minecraft:light_gray_concrete
fill 254 171 229 254 172 229 minecraft:light_gray_concrete
fill 254 171 234 254 172 234 minecraft:light_gray_concrete
setblock 254 171 239 minecraft:light[level=15]
setblock 254 171 247 minecraft:light[level=15]
setblock 254 171 255 minecraft:light[level=15]
setblock 254 171 263 minecraft:light[level=15]
setblock 254 171 270 minecraft:pearlescent_froglight
fill 256 171 229 256 172 229 minecraft:light_gray_concrete
fill 256 171 234 256 172 234 minecraft:light_gray_concrete
setblock 257 171 228 minecraft:cyan_concrete
fill 258 171 229 258 172 229 minecraft:light_gray_concrete
fill 258 171 234 258 172 234 minecraft:light_gray_concrete
fill 259 171 270 259 277 270 minecraft:black_concrete
fill 260 171 229 260 172 229 minecraft:light_gray_concrete
fill 260 171 234 260 172 234 minecraft:light_gray_concrete
fill 262 171 230 262 172 230 minecraft:light_gray_concrete
fill 262 171 232 262 172 232 minecraft:light_gray_concrete
setblock 262 171 239 minecraft:light[level=15]
setblock 262 171 247 minecraft:light[level=15]
setblock 262 171 255 minecraft:light[level=15]
setblock 262 171 263 minecraft:light[level=15]
fill 268 171 230 268 172 230 minecraft:cyan_terracotta
fill 268 171 232 268 172 232 minecraft:cyan_terracotta
fill 268 171 234 268 172 234 minecraft:cyan_terracotta
fill 268 171 236 268 172 236 minecraft:cyan_terracotta
fill 268 171 262 268 172 262 minecraft:light_gray_concrete
fill 268 171 264 268 172 264 minecraft:light_gray_concrete
fill 268 171 266 268 172 266 minecraft:light_gray_concrete
fill 268 171 268 268 172 268 minecraft:light_gray_concrete
fill 269 171 229 269 172 229 minecraft:cyan_terracotta
fill 269 171 237 269 172 237 minecraft:cyan_terracotta
fill 269 171 261 269 172 261 minecraft:light_gray_concrete
fill 269 171 269 269 172 269 minecraft:light_gray_concrete
setblock 270 171 239 minecraft:light[level=15]
setblock 270 171 247 minecraft:light[level=15]
setblock 270 171 255 minecraft:light[level=15]
fill 271 171 229 271 172 229 minecraft:cyan_terracotta
fill 271 171 237 271 172 237 minecraft:cyan_terracotta
fill 271 171 243 271 172 243 minecraft:light_gray_concrete
fill 271 171 245 271 172 245 minecraft:light_gray_concrete
fill 271 171 247 271 172 247 minecraft:light_gray_concrete
fill 271 171 249 271 172 249 minecraft:light_gray_concrete
fill 271 171 251 271 172 251 minecraft:light_gray_concrete
fill 271 171 253 271 172 253 minecraft:light_gray_concrete
fill 271 171 261 271 172 261 minecraft:light_gray_concrete
fill 271 171 269 271 172 269 minecraft:light_gray_concrete
fill 272 171 242 272 172 242 minecraft:light_gray_concrete
fill 272 171 255 272 172 255 minecraft:light_gray_concrete
fill 273 171 229 273 172 229 minecraft:cyan_terracotta
fill 273 171 237 273 172 237 minecraft:cyan_terracotta
fill 273 171 261 273 172 261 minecraft:light_gray_concrete
fill 273 171 269 273 172 269 minecraft:light_gray_concrete
setblock 273 171 270 minecraft:cyan_concrete
fill 274 171 242 274 172 242 minecraft:light_gray_concrete
fill 274 171 255 274 172 255 minecraft:light_gray_concrete
fill 275 171 229 275 172 229 minecraft:cyan_terracotta
fill 275 171 237 275 172 237 minecraft:cyan_terracotta
fill 275 171 261 275 172 261 minecraft:light_gray_concrete
fill 275 171 269 275 172 269 minecraft:light_gray_concrete
fill 276 171 230 276 172 230 minecraft:cyan_terracotta
fill 276 171 232 276 172 232 minecraft:cyan_terracotta
fill 276 171 234 276 172 234 minecraft:cyan_terracotta
fill 276 171 236 276 172 236 minecraft:cyan_terracotta
fill 276 171 243 276 172 243 minecraft:light_gray_concrete
fill 276 171 245 276 172 245 minecraft:light_gray_concrete
fill 276 171 247 276 172 247 minecraft:light_gray_concrete
fill 276 171 249 276 172 249 minecraft:light_gray_concrete
fill 276 171 251 276 172 251 minecraft:light_gray_concrete
fill 276 171 253 276 172 253 minecraft:light_gray_concrete
fill 276 171 262 276 172 262 minecraft:light_gray_concrete
fill 276 171 264 276 172 264 minecraft:light_gray_concrete
fill 276 171 266 276 172 266 minecraft:light_gray_concrete
fill 276 171 268 276 172 268 minecraft:light_gray_concrete
fill 235 172 233 235 181 233 minecraft:black_concrete
fill 237 172 247 237 183 247 minecraft:light_gray_concrete
fill 238 172 242 238 173 249 minecraft:light_blue_stained_glass
fill 238 172 250 239 172 255 minecraft:light_gray_concrete
fill 239 172 233 239 173 239 minecraft:light_blue_stained_glass
fill 239 172 247 239 173 249 minecraft:light_blue_stained_glass
fill 239 172 261 240 172 265 minecraft:cyan_terracotta
fill 240 172 230 241 225 231 minecraft:light_gray_concrete
fill 240 172 232 240 173 232 minecraft:light_blue_stained_glass
fill 240 172 237 240 173 245 minecraft:light_blue_stained_glass
fill 240 172 246 240 183 247 minecraft:light_gray_concrete
fill 240 172 252 240 183 255 minecraft:light_gray_concrete
fill 240 172 266 240 198 266 minecraft:cyan_terracotta
fill 241 172 232 241 225 232 minecraft:light_gray_concrete
fill 241 172 233 241 173 235 minecraft:light_blue_stained_glass
fill 241 172 236 241 172 237 minecraft:light_gray_concrete
fill 241 172 263 241 198 265 minecraft:cyan_terracotta
setblock 246 172 270 minecraft:sea_lantern
fill 254 172 270 254 188 270 minecraft:black_concrete
fill 257 172 228 257 305 228 minecraft:black_concrete
fill 273 172 270 273 174 270 minecraft:black_concrete
setblock 277 172 236 minecraft:cyan_concrete
setblock 277 172 240 minecraft:cyan_concrete
setblock 235 173 249 minecraft:ochre_froglight
setblock 236 173 230 minecraft:ochre_froglight
setblock 236 173 232 minecraft:pearlescent_froglight
setblock 236 173 234 minecraft:light_blue_stained_glass
setblock 236 173 236 minecraft:magenta_stained_glass
setblock 236 173 243 minecraft:black_stained_glass
setblock 236 173 245 minecraft:black_stained_glass
setblock 236 173 247 minecraft:black_stained_glass
setblock 236 173 249 minecraft:light_blue_stained_glass
setblock 236 173 251 minecraft:black_stained_glass
setblock 236 173 253 minecraft:ochre_froglight
setblock 236 173 262 minecraft:magenta_stained_glass
setblock 236 173 264 minecraft:magenta_stained_glass
setblock 236 173 266 minecraft:black_stained_glass
setblock 236 173 268 minecraft:black_stained_glass
setblock 237 173 229 minecraft:light_blue_stained_glass
setblock 237 173 237 minecraft:black_stained_glass
setblock 237 173 242 minecraft:pearlescent_froglight
setblock 237 173 255 minecraft:magenta_stained_glass
setblock 237 173 261 minecraft:sea_lantern
setblock 237 173 269 minecraft:black_stained_glass
fill 238 173 250 238 183 255 minecraft:light_gray_concrete
setblock 239 173 229 minecraft:cyan_stained_glass
fill 239 173 240 239 173 246 minecraft:light_blue_stained_glass
fill 239 173 250 239 183 254 minecraft:light_gray_concrete
setblock 239 173 255 minecraft:black_stained_glass
setblock 239 173 261 minecraft:black_stained_glass
fill 239 173 262 240 198 265 minecraft:cyan_terracotta
setblock 239 173 269 minecraft:ochre_froglight
fill 240 173 233 240 173 236 minecraft:light_blue_stained_glass
fill 240 173 261 240 198 261 minecraft:cyan_terracotta
setblock 241 173 229 minecraft:black_stained_glass
fill 241 173 236 241 225 236 minecraft:light_gray_concrete
setblock 241 173 237 minecraft:pearlescent_froglight
setblock 241 173 243 minecraft:magenta_stained_glass
setblock 241 173 245 minecraft:ochre_froglight
fill 241 173 246 241 183 246 minecraft:light_gray_concrete
setblock 241 173 247 minecraft:cyan_stained_glass
setblock 241 173 249 minecraft:ochre_froglight
setblock 241 173 251 minecraft:cyan_stained_glass
setblock 241 173 253 minecraft:sea_lantern
setblock 241 173 261 minecraft:magenta_stained_glass
setblock 241 173 269 minecraft:black_stained_glass
setblock 243 173 229 minecraft:pearlescent_froglight
setblock 243 173 237 minecraft:magenta_stained_glass
setblock 243 173 261 minecraft:light_blue_stained_glass
setblock 243 173 269 minecraft:ochre_froglight
setblock 244 173 230 minecraft:cyan_stained_glass
setblock 244 173 232 minecraft:black_stained_glass
setblock 244 173 234 minecraft:cyan_stained_glass
setblock 244 173 236 minecraft:light_blue_stained_glass
setblock 244 173 262 minecraft:sea_lantern
setblock 244 173 264 minecraft:magenta_stained_glass
setblock 244 173 266 minecraft:cyan_stained_glass
setblock 244 173 268 minecraft:cyan_stained_glass
fill 246 173 270 246 229 270 minecraft:black_concrete
setblock 247 173 228 minecraft:cyan_concrete
setblock 249 173 230 minecraft:magenta_stained_glass
setblock 249 173 232 minecraft:magenta_stained_glass
setblock 250 173 229 minecraft:light_blue_stained_glass
setblock 250 173 234 minecraft:ochre_froglight
setblock 252 173 229 minecraft:ochre_froglight
setblock 252 173 234 minecraft:pearlescent_froglight
setblock 254 173 229 minecraft:black_stained_glass
setblock 254 173 234 minecraft:black_stained_glass
setblock 256 173 229 minecraft:black_stained_glass
setblock 256 173 234 minecraft:black_stained_glass
setblock 258 173 229 minecraft:black_stained_glass
setblock 258 173 234 minecraft:light_blue_stained_glass
setblock 260 173 228 minecraft:ochre_froglight
setblock 260 173 229 minecraft:sea_lantern
setblock 260 173 234 minecraft:black_stained_glass
setblock 262 173 230 minecraft:cyan_stained_glass
setblock 262 173 232 minecraft:cyan_stained_glass
setblock 268 173 230 minecraft:black_stained_glass
setblock 268 173 232 minecraft:black_stained_glass
setblock 268 173 234 minecraft:black_stained_glass
setblock 268 173 236 minecraft:magenta_stained_glass
setblock 268 173 262 minecraft:pearlescent_froglight
setblock 268 173 264 minecraft:pearlescent_froglight
setblock 268 173 266 minecraft:ochre_froglight
setblock 268 173 268 minecraft:ochre_froglight
setblock 269 173 229 minecraft:black_stained_glass
setblock 269 173 237 minecraft:pearlescent_froglight
setblock 269 173 261 minecraft:light_blue_stained_glass
setblock 269 173 269 minecraft:pearlescent_froglight
setblock 271 173 229 minecraft:black_stained_glass
setblock 271 173 237 minecraft:cyan_stained_glass
setblock 271 173 243 minecraft:pearlescent_froglight
setblock 271 173 245 minecraft:magenta_stained_glass
setblock 271 173 247 minecraft:pearlescent_froglight
setblock 271 173 249 minecraft:black_stained_glass
setblock 271 173 251 minecraft:black_stained_glass
setblock 271 173 253 minecraft:sea_lantern
setblock 271 173 261 minecraft:ochre_froglight
setblock 271 173 269 minecraft:pearlescent_froglight
setblock 272 173 242 minecraft:magenta_stained_glass
setblock 272 173 255 minecraft:black_stained_glass
setblock 273 173 229 minecraft:light_blue_stained_glass
setblock 273 173 237 minecraft:black_stained_glass
setblock 273 173 261 minecraft:sea_lantern
setblock 273 173 269 minecraft:black_stained_glass
setblock 274 173 242 minecraft:cyan_stained_glass
setblock 274 173 255 minecraft:pearlescent_froglight
setblock 275 173 229 minecraft:black_stained_glass
setblock 275 173 237 minecraft:cyan_stained_glass
setblock 275 173 261 minecraft:black_stained_glass
setblock 275 173 269 minecraft:magenta_stained_glass
setblock 276 173 230 minecraft:sea_lantern
setblock 276 173 232 minecraft:black_stained_glass
setblock 276 173 234 minecraft:cyan_stained_glass
setblock 276 173 236 minecraft:black_stained_glass
setblock 276 173 243 minecraft:black_stained_glass
setblock 276 173 245 minecraft:black_stained_glass
setblock 276 173 247 minecraft:black_stained_glass
setblock 276 173 249 minecraft:light_blue_stained_glass
setblock 276 173 251 minecraft:ochre_froglight
setblock 276 173 253 minecraft:pearlescent_froglight
setblock 276 173 262 minecraft:black_stained_glass
setblock 276 173 264 minecraft:magenta_stained_glass
setblock 276 173 266 minecraft:black_stained_glass
setblock 276 173 268 minecraft:black_stained_glass
setblock 277 173 233 minecraft:blue_concrete
fill 277 173 236 277 223 236 minecraft:black_concrete
fill 277 173 240 277 254 240 minecraft:black_concrete
setblock 235 174 241 minecraft:magenta_concrete
fill 235 174 249 235 244 249 minecraft:black_concrete
fill 236 174 230 236 175 230 minecraft:light_gray_concrete
fill 236 174 232 236 175 232 minecraft:light_gray_concrete
fill 236 174 234 236 175 234 minecraft:light_gray_concrete
fill 236 174 236 236 175 236 minecraft:light_gray_concrete
fill 236 174 243 236 175 243 minecraft:light_gray_concrete
fill 236 174 245 236 175 245 minecraft:light_gray_concrete
fill 236 174 247 236 175 247 minecraft:light_gray_concrete
fill 236 174 249 236 175 249 minecraft:light_gray_concrete
fill 236 174 251 236 175 251 minecraft:light_gray_concrete
fill 236 174 253 236 175 253 minecraft:light_gray_concrete
fill 236 174 262 236 175 262 minecraft:cyan_terracotta
fill 236 174 264 236 175 264 minecraft:cyan_terracotta
fill 236 174 266 236 175 266 minecraft:cyan_terracotta
fill 236 174 268 236 175 268 minecraft:cyan_terracotta
fill 237 174 229 237 175 229 minecraft:light_gray_concrete
fill 237 174 237 237 175 237 minecraft:light_gray_concrete
fill 237 174 242 240 175 242 minecraft:light_gray_concrete
fill 237 174 255 237 175 255 minecraft:light_gray_concrete
fill 237 174 261 237 175 261 minecraft:cyan_terracotta
fill 237 174 269 237 175 269 minecraft:cyan_terracotta
fill 238 174 243 239 183 249 minecraft:light_gray_concrete
fill 239 174 229 239 175 229 minecraft:light_gray_concrete
fill 239 174 233 240 175 237 minecraft:light_gray_concrete
fill 239 174 255 239 175 255 minecraft:light_gray_concrete
fill 239 174 261 239 175 261 minecraft:cyan_terracotta
fill 239 174 269 239 175 269 minecraft:cyan_terracotta
fill 240 174 232 240 225 232 minecraft:light_gray_concrete
fill 240 174 243 240 183 245 minecraft:light_gray_concrete
fill 241 174 229 241 175 229 minecraft:light_gray_concrete
fill 241 174 233 241 225 235 minecraft:light_gray_concrete
fill 241 174 237 241 175 237 minecraft:light_gray_concrete
fill 241 174 243 241 175 243 minecraft:light_gray_concrete
fill 241 174 245 241 175 245 minecraft:light_gray_concrete
fill 241 174 247 241 175 247 minecraft:light_gray_concrete
fill 241 174 249 241 175 249 minecraft:light_gray_concrete
fill 241 174 251 241 175 251 minecraft:light_gray_concrete
fill 241 174 253 241 175 253 minecraft:light_gray_concrete
fill 241 174 261 241 175 261 minecraft:cyan_terracotta
fill 241 174 269 241 175 269 minecraft:cyan_terracotta
fill 243 174 229 243 175 229 minecraft:light_gray_concrete
fill 243 174 237 243 175 237 minecraft:light_gray_concrete
fill 243 174 261 243 175 261 minecraft:cyan_terracotta
fill 243 174 269 243 175 269 minecraft:cyan_terracotta
fill 244 174 230 244 175 230 minecraft:light_gray_concrete
fill 244 174 232 244 175 232 minecraft:light_gray_concrete
fill 244 174 234 244 175 234 minecraft:light_gray_concrete
fill 244 174 236 244 175 236 minecraft:light_gray_concrete
fill 244 174 262 244 175 262 minecraft:cyan_terracotta
fill 244 174 264 244 175 264 minecraft:cyan_terracotta
fill 244 174 266 244 175 266 minecraft:cyan_terracotta
fill 244 174 268 244 175 268 minecraft:cyan_terracotta
fill 247 174 228 247 186 228 minecraft:black_concrete
fill 249 174 230 249 175 230 minecraft:light_gray_concrete
fill 249 174 232 249 175 232 minecraft:light_gray_concrete
fill 250 174 229 250 175 229 minecraft:light_gray_concrete
fill 250 174 234 250 175 234 minecraft:light_gray_concrete
fill 252 174 229 252 175 229 minecraft:light_gray_concrete
fill 252 174 234 252 175 234 minecraft:light_gray_concrete
fill 254 174 229 254 175 229 minecraft:light_gray_concrete
fill 254 174 234 254 175 234 minecraft:light_gray_concrete
fill 256 174 229 256 175 229 minecraft:light_gray_concrete
fill 256 174 234 256 175 234 minecraft:light_gray_concrete
fill 258 174 229 258 175 229 minecraft:light_gray_concrete
fill 258 174 234 258 175 234 minecraft:light_gray_concrete
fill 259 174 267 265 175 267 minecraft:iron_block
fill 260 174 228 260 183 228 minecraft:black_concrete
fill 260 174 229 260 175 229 minecraft:light_gray_concrete
fill 260 174 234 260 175 234 minecraft:light_gray_concrete
setblock 261 174 270 minecraft:blue_concrete
fill 262 174 230 262 175 230 minecraft:light_gray_concrete
fill 262 174 232 262 175 232 minecraft:light_gray_concrete
fill 268 174 230 268 175 230 minecraft:cyan_terracotta
fill 268 174 232 268 175 232 minecraft:cyan_terracotta
fill 268 174 234 268 175 234 minecraft:cyan_terracotta
fill 268 174 236 268 175 236 minecraft:cyan_terracotta
fill 268 174 262 268 175 262 minecraft:light_gray_concrete
fill 268 174 264 268 175 264 minecraft:light_gray_concrete
fill 268 174 266 268 175 266 minecraft:light_gray_concrete
fill 268 174 268 268 175 268 minecraft:light_gray_concrete
fill 269 174 229 269 175 229 minecraft:cyan_terracotta
fill 269 174 237 269 175 237 minecraft:cyan_terracotta
fill 269 174 261 269 175 261 minecraft:light_gray_concrete
fill 269 174 269 269 175 269 minecraft:light_gray_concrete
fill 271 174 229 271 175 229 minecraft:cyan_terracotta
fill 271 174 237 271 175 237 minecraft:cyan_terracotta
fill 271 174 243 271 175 243 minecraft:light_gray_concrete
fill 271 174 245 271 175 245 minecraft:light_gray_concrete
fill 271 174 247 271 175 247 minecraft:light_gray_concrete
fill 271 174 249 271 175 249 minecraft:light_gray_concrete
fill 271 174 251 271 175 251 minecraft:light_gray_concrete
fill 271 174 253 271 175 253 minecraft:light_gray_concrete
fill 271 174 261 271 175 261 minecraft:light_gray_concrete
fill 271 174 269 271 175 269 minecraft:light_gray_concrete
fill 272 174 242 272 175 242 minecraft:light_gray_concrete
fill 272 174 255 272 175 255 minecraft:light_gray_concrete
fill 273 174 229 273 175 229 minecraft:cyan_terracotta
fill 273 174 237 273 175 237 minecraft:cyan_terracotta
fill 273 174 261 273 175 261 minecraft:light_gray_concrete
fill 273 174 269 273 175 269 minecraft:light_gray_concrete
fill 274 174 242 274 175 242 minecraft:light_gray_concrete
fill 274 174 255 274 175 255 minecraft:light_gray_concrete
fill 275 174 229 275 175 229 minecraft:cyan_terracotta
fill 275 174 237 275 175 237 minecraft:cyan_terracotta
fill 275 174 261 275 175 261 minecraft:light_gray_concrete
fill 275 174 269 275 175 269 minecraft:light_gray_concrete
fill 276 174 230 276 175 230 minecraft:cyan_terracotta
fill 276 174 232 276 175 232 minecraft:cyan_terracotta
fill 276 174 234 276 175 234 minecraft:cyan_terracotta
fill 276 174 236 276 175 236 minecraft:cyan_terracotta
fill 276 174 243 276 175 243 minecraft:light_gray_concrete
fill 276 174 245 276 175 245 minecraft:light_gray_concrete
fill 276 174 247 276 175 247 minecraft:light_gray_concrete
fill 276 174 249 276 175 249 minecraft:light_gray_concrete
fill 276 174 251 276 175 251 minecraft:light_gray_concrete
fill 276 174 253 276 175 253 minecraft:light_gray_concrete
fill 276 174 262 276 175 262 minecraft:light_gray_concrete
fill 276 174 264 276 175 264 minecraft:light_gray_concrete
fill 276 174 266 276 175 266 minecraft:light_gray_concrete
fill 276 174 268 276 175 268 minecraft:light_gray_concrete
setblock 277 174 229 minecraft:purple_concrete
fill 277 174 233 277 212 233 minecraft:black_concrete
fill 235 175 241 235 201 241 minecraft:black_concrete
setblock 235 175 254 minecraft:purple_concrete
setblock 238 175 238 minecraft:light[level=12]
setblock 238 175 259 minecraft:light[level=12]
setblock 245 175 231 minecraft:light[level=12]
setblock 245 175 238 minecraft:light[level=12]
setblock 245 175 245 minecraft:light[level=12]
setblock 245 175 252 minecraft:light[level=12]
setblock 245 175 259 minecraft:light[level=12]
setblock 245 175 266 minecraft:light[level=12]
setblock 250 175 270 minecraft:sea_lantern
setblock 252 175 238 minecraft:light[level=12]
setblock 252 175 245 minecraft:light[level=12]
setblock 252 175 252 minecraft:light[level=12]
setblock 252 175 259 minecraft:light[level=12]
setblock 252 175 266 minecraft:light[level=12]
setblock 259 175 238 minecraft:light[level=12]
setblock 259 175 245 minecraft:light[level=12]
setblock 259 175 252 minecraft:light[level=12]
setblock 259 175 259 minecraft:light[level=12]
setblock 259 175 266 minecraft:light[level=12]
setblock 260 175 270 minecraft:verdant_froglight
fill 261 175 270 261 239 270 minecraft:black_concrete
setblock 264 175 270 minecraft:blue_concrete
setblock 266 175 231 minecraft:light[level=12]
setblock 266 175 238 minecraft:light[level=12]
setblock 266 175 245 minecraft:light[level=12]
setblock 266 175 252 minecraft:light[level=12]
setblock 266 175 259 minecraft:light[level=12]
setblock 266 175 266 minecraft:light[level=12]
setblock 273 175 238 minecraft:light[level=12]
setblock 273 175 259 minecraft:light[level=12]
setblock 273 175 270 minecraft:verdant_froglight
fill 277 175 229 277 181 229 minecraft:black_concrete
setblock 235 176 252 minecraft:pearlescent_froglight
fill 235 176 254 235 190 254 minecraft:black_concrete
setblock 236 176 230 minecraft:black_stained_glass
setblock 236 176 232 minecraft:ochre_froglight
setblock 236 176 234 minecraft:black_stained_glass
setblock 236 176 236 minecraft:light_blue_stained_glass
setblock 236 176 243 minecraft:black_stained_glass
setblock 236 176 245 minecraft:black_stained_glass
setblock 236 176 247 minecraft:sea_lantern
setblock 236 176 249 minecraft:magenta_stained_glass
setblock 236 176 251 minecraft:cyan_stained_glass
setblock 236 176 253 minecraft:pearlescent_froglight
setblock 236 176 262 minecraft:black_stained_glass
setblock 236 176 264 minecraft:pearlescent_froglight
setblock 236 176 266 minecraft:pearlescent_froglight
setblock 236 176 268 minecraft:cyan_stained_glass
setblock 237 176 229 minecraft:pearlescent_froglight
setblock 237 176 237 minecraft:black_stained_glass
setblock 237 176 242 minecraft:light_blue_stained_glass
setblock 237 176 255 minecraft:black_stained_glass
setblock 237 176 261 minecraft:black_stained_glass
setblock 237 176 269 minecraft:sea_lantern
fill 238 176 242 238 183 242 minecraft:light_gray_concrete
setblock 239 176 229 minecraft:cyan_stained_glass
fill 239 176 233 240 225 236 minecraft:light_gray_concrete
setblock 239 176 237 minecraft:black_stained_glass
setblock 239 176 242 minecraft:magenta_stained_glass
setblock 239 176 255 minecraft:light_blue_stained_glass
setblock 239 176 261 minecraft:pearlescent_froglight
setblock 239 176 269 minecraft:black_stained_glass
fill 240 176 237 240 225 237 minecraft:light_gray_concrete
fill 240 176 242 240 183 242 minecraft:light_gray_concrete
setblock 241 176 229 minecraft:ochre_froglight
setblock 241 176 237 minecraft:magenta_stained_glass
setblock 241 176 243 minecraft:magenta_stained_glass
setblock 241 176 245 minecraft:ochre_froglight
setblock 241 176 247 minecraft:magenta_stained_glass
setblock 241 176 249 minecraft:black_stained_glass
setblock 241 176 251 minecraft:black_stained_glass
setblock 241 176 253 minecraft:light_blue_stained_glass
setblock 241 176 261 minecraft:sea_lantern
setblock 241 176 269 minecraft:black_stained_glass
setblock 243 176 229 minecraft:sea_lantern
setblock 243 176 237 minecraft:cyan_stained_glass
setblock 243 176 261 minecraft:cyan_stained_glass
setblock 243 176 269 minecraft:black_stained_glass
setblock 244 176 230 minecraft:pearlescent_froglight
setblock 244 176 232 minecraft:black_stained_glass
setblock 244 176 234 minecraft:black_stained_glass
setblock 244 176 236 minecraft:black_stained_glass
setblock 244 176 262 minecraft:ochre_froglight
setblock 244 176 264 minecraft:black_stained_glass
setblock 244 176 266 minecraft:black_stained_glass
setblock 244 176 268 minecraft:sea_lantern
fill 249 176 229 262 176 234 minecraft:black_concrete
fill 250 176 270 250 200 270 minecraft:black_concrete
fill 260 176 270 260 243 270 minecraft:black_concrete
fill 264 176 270 264 308 270 minecraft:black_concrete
setblock 268 176 230 minecraft:black_stained_glass
setblock 268 176 232 minecraft:black_stained_glass
setblock 268 176 234 minecraft:black_stained_glass
setblock 268 176 236 minecraft:black_stained_glass
setblock 268 176 262 minecraft:ochre_froglight
setblock 268 176 264 minecraft:black_stained_glass
setblock 268 176 266 minecraft:cyan_stained_glass
setblock 268 176 268 minecraft:magenta_stained_glass
setblock 269 176 228 minecraft:purple_concrete
setblock 269 176 229 minecraft:light_blue_stained_glass
setblock 269 176 237 minecraft:magenta_stained_glass
setblock 269 176 261 minecraft:sea_lantern
setblock 269 176 269 minecraft:pearlescent_froglight
setblock 271 176 229 minecraft:ochre_froglight
setblock 271 176 237 minecraft:black_stained_glass
setblock 271 176 243 minecraft:sea_lantern
setblock 271 176 245 minecraft:cyan_stained_glass
setblock 271 176 247 minecraft:black_stained_glass
setblock 271 176 249 minecraft:sea_lantern
setblock 271 176 251 minecraft:black_stained_glass
setblock 271 176 253 minecraft:cyan_stained_glass
setblock 271 176 261 minecraft:sea_lantern
setblock 271 176 269 minecraft:black_stained_glass
setblock 272 176 242 minecraft:magenta_stained_glass
setblock 272 176 255 minecraft:black_stained_glass
setblock 273 176 229 minecraft:ochre_froglight
setblock 273 176 237 minecraft:black_stained_glass
setblock 273 176 261 minecraft:light_blue_stained_glass
setblock 273 176 269 minecraft:black_stained_glass
fill 273 176 270 273 224 270 minecraft:black_concrete
setblock 274 176 242 minecraft:pearlescent_froglight
setblock 274 176 255 minecraft:black_stained_glass
setblock 275 176 229 minecraft:black_stained_glass
setblock 275 176 237 minecraft:magenta_stained_glass
setblock 275 176 261 minecraft:sea_lantern
setblock 275 176 269 minecraft:black_stained_glass
setblock 276 176 230 minecraft:black_stained_glass
setblock 276 176 232 minecraft:black_stained_glass
setblock 276 176 234 minecraft:black_stained_glass
setblock 276 176 236 minecraft:light_blue_stained_glass
setblock 276 176 243 minecraft:magenta_stained_glass
setblock 276 176 245 minecraft:pearlescent_froglight
setblock 276 176 247 minecraft:ochre_froglight
setblock 276 176 249 minecraft:black_stained_glass
setblock 276 176 251 minecraft:cyan_stained_glass
setblock 276 176 253 minecraft:black_stained_glass
setblock 276 176 262 minecraft:cyan_stained_glass
setblock 276 176 264 minecraft:magenta_stained_glass
setblock 276 176 266 minecraft:black_stained_glass
setblock 276 176 268 minecraft:light_blue_stained_glass
setblock 277 176 264 minecraft:blue_concrete
fill 235 177 252 235 304 252 minecraft:black_concrete
fill 236 177 230 236 178 230 minecraft:light_gray_concrete
fill 236 177 232 236 178 232 minecraft:light_gray_concrete
fill 236 177 234 236 178 234 minecraft:light_gray_concrete
fill 236 177 236 236 178 236 minecraft:light_gray_concrete
fill 236 177 243 236 178 243 minecraft:light_gray_concrete
fill 236 177 245 236 178 245 minecraft:light_gray_concrete
fill 236 177 247 236 178 247 minecraft:light_gray_concrete
fill 236 177 249 236 178 249 minecraft:light_gray_concrete
fill 236 177 251 236 178 251 minecraft:light_gray_concrete
fill 236 177 253 236 178 253 minecraft:light_gray_concrete
fill 236 177 262 236 178 262 minecraft:cyan_terracotta
fill 236 177 264 236 178 264 minecraft:cyan_terracotta
fill 236 177 266 236 178 266 minecraft:cyan_terracotta
fill 236 177 268 236 178 268 minecraft:cyan_terracotta
fill 237 177 229 237 178 229 minecraft:light_gray_concrete
fill 237 177 237 237 178 237 minecraft:light_gray_concrete
fill 237 177 242 237 178 242 minecraft:light_gray_concrete
fill 237 177 255 237 178 255 minecraft:light_gray_concrete
fill 237 177 261 237 178 261 minecraft:cyan_terracotta
fill 237 177 269 237 178 269 minecraft:cyan_terracotta
fill 239 177 229 239 178 229 minecraft:light_gray_concrete
fill 239 177 237 239 178 237 minecraft:light_gray_concrete
fill 239 177 242 239 178 242 minecraft:light_gray_concrete
fill 239 177 255 239 178 255 minecraft:light_gray_concrete
fill 239 177 261 239 178 261 minecraft:cyan_terracotta
fill 239 177 269 239 178 269 minecraft:cyan_terracotta
fill 241 177 229 241 178 229 minecraft:light_gray_concrete
fill 241 177 237 241 178 237 minecraft:light_gray_concrete
fill 241 177 243 241 178 243 minecraft:light_gray_concrete
fill 241 177 245 241 178 245 minecraft:light_gray_concrete
fill 241 177 247 241 178 247 minecraft:light_gray_concrete
fill 241 177 249 241 178 249 minecraft:light_gray_concrete
fill 241 177 251 241 178 251 minecraft:light_gray_concrete
fill 241 177 253 241 178 253 minecraft:light_gray_concrete
fill 241 177 261 241 178 261 minecraft:cyan_terracotta
fill 241 177 269 241 178 269 minecraft:cyan_terracotta
fill 243 177 229 243 178 229 minecraft:light_gray_concrete
fill 243 177 237 243 178 237 minecraft:light_gray_concrete
fill 243 177 261 243 178 261 minecraft:cyan_terracotta
fill 243 177 269 243 178 269 minecraft:cyan_terracotta
fill 244 177 230 244 178 230 minecraft:light_gray_concrete
fill 244 177 232 244 178 232 minecraft:light_gray_concrete
fill 244 177 234 244 178 234 minecraft:light_gray_concrete
fill 244 177 236 244 178 236 minecraft:light_gray_concrete
fill 244 177 262 244 178 262 minecraft:cyan_terracotta
fill 244 177 264 244 178 264 minecraft:cyan_terracotta
fill 244 177 266 244 178 266 minecraft:cyan_terracotta
fill 244 177 268 244 178 268 minecraft:cyan_terracotta
fill 249 177 229 249 177 234 minecraft:sea_lantern
fill 250 177 229 262 177 229 minecraft:sea_lantern
fill 250 177 234 262 177 234 minecraft:sea_lantern
setblock 253 177 270 minecraft:blue_concrete
fill 255 177 231 255 183 231 minecraft:iron_bars
fill 262 177 230 262 177 233 minecraft:sea_lantern
fill 268 177 230 268 178 230 minecraft:cyan_terracotta
fill 268 177 232 268 178 232 minecraft:cyan_terracotta
fill 268 177 234 268 178 234 minecraft:cyan_terracotta
fill 268 177 236 268 178 236 minecraft:cyan_terracotta
fill 268 177 262 268 178 262 minecraft:light_gray_concrete
fill 268 177 264 268 178 264 minecraft:light_gray_concrete
fill 268 177 266 268 178 266 minecraft:light_gray_concrete
fill 268 177 268 268 178 268 minecraft:light_gray_concrete
fill 269 177 228 269 206 228 minecraft:black_concrete
fill 269 177 229 269 178 229 minecraft:cyan_terracotta
fill 269 177 237 269 178 237 minecraft:cyan_terracotta
fill 269 177 261 269 178 261 minecraft:light_gray_concrete
fill 269 177 269 269 178 269 minecraft:light_gray_concrete
fill 271 177 229 271 178 229 minecraft:cyan_terracotta
fill 271 177 237 271 178 237 minecraft:cyan_terracotta
fill 271 177 243 271 178 243 minecraft:light_gray_concrete
fill 271 177 245 271 178 245 minecraft:light_gray_concrete
fill 271 177 247 271 178 247 minecraft:light_gray_concrete
fill 271 177 249 271 178 249 minecraft:light_gray_concrete
fill 271 177 251 271 178 251 minecraft:light_gray_concrete
fill 271 177 253 271 178 253 minecraft:light_gray_concrete
fill 271 177 261 271 178 261 minecraft:light_gray_concrete
fill 271 177 269 271 178 269 minecraft:light_gray_concrete
fill 272 177 242 272 178 242 minecraft:light_gray_concrete
fill 272 177 255 272 178 255 minecraft:light_gray_concrete
fill 273 177 229 273 178 229 minecraft:cyan_terracotta
fill 273 177 237 273 178 237 minecraft:cyan_terracotta
fill 273 177 261 273 178 261 minecraft:light_gray_concrete
fill 273 177 269 273 178 269 minecraft:light_gray_concrete
fill 274 177 242 274 178 242 minecraft:light_gray_concrete
fill 274 177 255 274 178 255 minecraft:light_gray_concrete
fill 275 177 229 275 178 229 minecraft:cyan_terracotta
fill 275 177 237 275 178 237 minecraft:cyan_terracotta
fill 275 177 261 275 178 261 minecraft:light_gray_concrete
fill 275 177 269 275 178 269 minecraft:light_gray_concrete
fill 276 177 230 276 178 230 minecraft:cyan_terracotta
fill 276 177 232 276 178 232 minecraft:cyan_terracotta
fill 276 177 234 276 178 234 minecraft:cyan_terracotta
fill 276 177 236 276 178 236 minecraft:cyan_terracotta
fill 276 177 243 276 178 243 minecraft:light_gray_concrete
fill 276 177 245 276 178 245 minecraft:light_gray_concrete
fill 276 177 247 276 178 247 minecraft:light_gray_concrete
fill 276 177 249 276 178 249 minecraft:light_gray_concrete
fill 276 177 251 276 178 251 minecraft:light_gray_concrete
fill 276 177 253 276 178 253 minecraft:light_gray_concrete
fill 276 177 262 276 178 262 minecraft:light_gray_concrete
fill 276 177 264 276 178 264 minecraft:light_gray_concrete
fill 276 177 266 276 178 266 minecraft:light_gray_concrete
fill 276 177 268 276 178 268 minecraft:light_gray_concrete
fill 277 177 264 277 182 264 minecraft:black_concrete
setblock 235 178 238 minecraft:verdant_froglight
setblock 235 178 269 minecraft:pearlescent_froglight
setblock 238 178 239 minecraft:light[level=15]
setblock 246 178 231 minecraft:light[level=15]
setblock 246 178 239 minecraft:light[level=15]
setblock 246 178 247 minecraft:light[level=15]
setblock 246 178 255 minecraft:light[level=15]
setblock 246 178 263 minecraft:light[level=15]
fill 253 178 270 253 246 270 minecraft:black_concrete
setblock 254 178 231 minecraft:light[level=15]
setblock 254 178 239 minecraft:light[level=15]
setblock 254 178 247 minecraft:light[level=15]
setblock 254 178 255 minecraft:light[level=15]
setblock 254 178 263 minecraft:light[level=15]
setblock 256 178 228 minecraft:sea_lantern
setblock 262 178 231 minecraft:light[level=15]
setblock 262 178 239 minecraft:light[level=15]
setblock 262 178 247 minecraft:light[level=15]
setblock 262 178 255 minecraft:light[level=15]
setblock 262 178 263 minecraft:light[level=15]
setblock 270 178 239 minecraft:light[level=15]
setblock 270 178 247 minecraft:light[level=15]
setblock 270 178 255 minecraft:light[level=15]
setblock 277 178 239 minecraft:verdant_froglight
fill 235 179 238 235 252 238 minecraft:black_concrete
fill 235 179 269 235 208 269 minecraft:black_concrete
setblock 236 179 230 minecraft:black_stained_glass
setblock 236 179 232 minecraft:ochre_froglight
setblock 236 179 234 minecraft:light_blue_stained_glass
setblock 236 179 236 minecraft:black_stained_glass
setblock 236 179 243 minecraft:ochre_froglight
setblock 236 179 245 minecraft:pearlescent_froglight
setblock 236 179 247 minecraft:light_blue_stained_glass
setblock 236 179 249 minecraft:cyan_stained_glass
setblock 236 179 251 minecraft:black_stained_glass
setblock 236 179 253 minecraft:black_stained_glass
setblock 236 179 262 minecraft:black_stained_glass
setblock 236 179 264 minecraft:sea_lantern
setblock 236 179 266 minecraft:magenta_stained_glass
setblock 236 179 268 minecraft:magenta_stained_glass
setblock 237 179 229 minecraft:light_blue_stained_glass
setblock 237 179 237 minecraft:black_stained_glass
setblock 237 179 242 minecraft:black_stained_glass
setblock 237 179 255 minecraft:light_blue_stained_glass
setblock 237 179 261 minecraft:magenta_stained_glass
setblock 237 179 269 minecraft:black_stained_glass
setblock 238 179 228 minecraft:magenta_concrete
setblock 239 179 229 minecraft:black_stained_glass
setblock 239 179 237 minecraft:black_stained_glass
setblock 239 179 242 minecraft:black_stained_glass
setblock 239 179 255 minecraft:magenta_stained_glass
setblock 239 179 261 minecraft:magenta_stained_glass
setblock 239 179 269 minecraft:magenta_stained_glass
setblock 241 179 229 minecraft:black_stained_glass
setblock 241 179 237 minecraft:cyan_stained_glass
setblock 241 179 243 minecraft:black_stained_glass
setblock 241 179 245 minecraft:black_stained_glass
setblock 241 179 247 minecraft:cyan_stained_glass
setblock 241 179 249 minecraft:black_stained_glass
setblock 241 179 251 minecraft:light_blue_stained_glass
setblock 241 179 253 minecraft:light_blue_stained_glass
setblock 241 179 261 minecraft:black_stained_glass
setblock 241 179 269 minecraft:ochre_froglight
setblock 243 179 229 minecraft:sea_lantern
setblock 243 179 237 minecraft:cyan_stained_glass
setblock 243 179 261 minecraft:light_blue_stained_glass
setblock 243 179 269 minecraft:black_stained_glass
setblock 244 179 230 minecraft:black_stained_glass
setblock 244 179 232 minecraft:black_stained_glass
setblock 244 179 234 minecraft:black_stained_glass
setblock 244 179 236 minecraft:light_blue_stained_glass
setblock 244 179 262 minecraft:cyan_stained_glass
setblock 244 179 264 minecraft:black_stained_glass
setblock 244 179 266 minecraft:cyan_stained_glass
setblock 244 179 268 minecraft:black_stained_glass
fill 256 179 228 256 223 228 minecraft:black_concrete
setblock 268 179 230 minecraft:black_stained_glass
setblock 268 179 232 minecraft:black_stained_glass
setblock 268 179 234 minecraft:light_blue_stained_glass
setblock 268 179 236 minecraft:pearlescent_froglight
setblock 268 179 262 minecraft:black_stained_glass
setblock 268 179 264 minecraft:pearlescent_froglight
setblock 268 179 266 minecraft:ochre_froglight
setblock 268 179 268 minecraft:light_blue_stained_glass
setblock 269 179 229 minecraft:black_stained_glass
setblock 269 179 237 minecraft:sea_lantern
setblock 269 179 261 minecraft:black_stained_glass
setblock 269 179 269 minecraft:black_stained_glass
setblock 271 179 229 minecraft:black_stained_glass
setblock 271 179 237 minecraft:black_stained_glass
setblock 271 179 243 minecraft:sea_lantern
setblock 271 179 245 minecraft:sea_lantern
setblock 271 179 247 minecraft:black_stained_glass
setblock 271 179 249 minecraft:black_stained_glass
setblock 271 179 251 minecraft:ochre_froglight
setblock 271 179 253 minecraft:black_stained_glass
setblock 271 179 261 minecraft:black_stained_glass
setblock 271 179 269 minecraft:sea_lantern
setblock 272 179 242 minecraft:black_stained_glass
setblock 272 179 255 minecraft:light_blue_stained_glass
setblock 273 179 229 minecraft:magenta_stained_glass
setblock 273 179 237 minecraft:black_stained_glass
setblock 273 179 261 minecraft:black_stained_glass
setblock 273 179 269 minecraft:black_stained_glass
setblock 274 179 242 minecraft:magenta_stained_glass
setblock 274 179 255 minecraft:ochre_froglight
setblock 275 179 229 minecraft:cyan_stained_glass
setblock 275 179 237 minecraft:black_stained_glass
setblock 275 179 261 minecraft:black_stained_glass
setblock 275 179 269 minecraft:magenta_stained_glass
setblock 276 179 230 minecraft:black_stained_glass
setblock 276 179 232 minecraft:pearlescent_froglight
setblock 276 179 234 minecraft:ochre_froglight
setblock 276 179 236 minecraft:magenta_stained_glass
setblock 276 179 243 minecraft:light_blue_stained_glass
setblock 276 179 245 minecraft:magenta_stained_glass
setblock 276 179 247 minecraft:black_stained_glass
setblock 276 179 249 minecraft:black_stained_glass
setblock 276 179 251 minecraft:ochre_froglight
setblock 276 179 253 minecraft:cyan_stained_glass
setblock 276 179 262 minecraft:black_stained_glass
setblock 276 179 264 minecraft:black_stained_glass
setblock 276 179 266 minecraft:pearlescent_froglight
setblock 276 179 268 minecraft:light_blue_stained_glass
fill 277 179 239 277 190 239 minecraft:black_concrete
setblock 235 180 234 minecraft:cyan_concrete
setblock 235 180 262 minecraft:purple_concrete
fill 236 180 230 236 181 230 minecraft:light_gray_concrete
fill 236 180 232 236 181 232 minecraft:light_gray_concrete
fill 236 180 234 236 181 234 minecraft:light_gray_concrete
fill 236 180 236 236 181 236 minecraft:light_gray_concrete
fill 236 180 243 236 181 243 minecraft:light_gray_concrete
fill 236 180 245 236 181 245 minecraft:light_gray_concrete
fill 236 180 247 236 181 247 minecraft:light_gray_concrete
fill 236 180 249 236 181 249 minecraft:light_gray_concrete
fill 236 180 251 236 181 251 minecraft:light_gray_concrete
fill 236 180 253 236 181 253 minecraft:light_gray_concrete
fill 236 180 262 236 181 262 minecraft:cyan_terracotta
fill 236 180 264 236 181 264 minecraft:cyan_terracotta
fill 236 180 266 236 181 266 minecraft:cyan_terracotta
fill 236 180 268 236 181 268 minecraft:cyan_terracotta
fill 237 180 229 237 181 229 minecraft:light_gray_concrete
fill 237 180 237 237 181 237 minecraft:light_gray_concrete
fill 237 180 242 237 181 242 minecraft:light_gray_concrete
fill 237 180 255 237 181 255 minecraft:light_gray_concrete
fill 237 180 261 237 181 261 minecraft:cyan_terracotta
fill 237 180 269 237 181 269 minecraft:cyan_terracotta
fill 238 180 228 238 237 228 minecraft:black_concrete
fill 239 180 229 239 181 229 minecraft:light_gray_concrete
fill 239 180 237 239 181 237 minecraft:light_gray_concrete
fill 239 180 242 239 181 242 minecraft:light_gray_concrete
fill 239 180 255 239 181 255 minecraft:light_gray_concrete
fill 239 180 261 239 181 261 minecraft:cyan_terracotta
fill 239 180 269 239 181 269 minecraft:cyan_terracotta
fill 241 180 229 241 181 229 minecraft:light_gray_concrete
fill 241 180 237 241 181 237 minecraft:light_gray_concrete
fill 241 180 243 241 181 243 minecraft:light_gray_concrete
fill 241 180 245 241 181 245 minecraft:light_gray_concrete
fill 241 180 247 241 181 247 minecraft:light_gray_concrete
fill 241 180 249 241 181 249 minecraft:light_gray_concrete
fill 241 180 251 241 181 251 minecraft:light_gray_concrete
fill 241 180 253 241 181 253 minecraft:light_gray_concrete
fill 241 180 261 241 181 261 minecraft:cyan_terracotta
fill 241 180 269 241 181 269 minecraft:cyan_terracotta
fill 243 180 229 243 181 229 minecraft:light_gray_concrete
fill 243 180 237 243 181 237 minecraft:light_gray_concrete
fill 243 180 261 243 181 261 minecraft:cyan_terracotta
fill 243 180 269 243 181 269 minecraft:cyan_terracotta
fill 244 180 230 244 181 230 minecraft:light_gray_concrete
fill 244 180 232 244 181 232 minecraft:light_gray_concrete
fill 244 180 234 244 181 234 minecraft:light_gray_concrete
fill 244 180 236 244 181 236 minecraft:light_gray_concrete
fill 244 180 262 244 181 262 minecraft:cyan_terracotta
fill 244 180 264 244 181 264 minecraft:cyan_terracotta
fill 244 180 266 244 181 266 minecraft:cyan_terracotta
fill 244 180 268 244 181 268 minecraft:cyan_terracotta
fill 268 180 230 268 181 230 minecraft:cyan_terracotta
fill 268 180 232 268 181 232 minecraft:cyan_terracotta
fill 268 180 234 268 181 234 minecraft:cyan_terracotta
fill 268 180 236 268 181 236 minecraft:cyan_terracotta
fill 268 180 262 268 181 262 minecraft:light_gray_concrete
fill 268 180 264 268 181 264 minecraft:light_gray_concrete
fill 268 180 266 268 181 266 minecraft:light_gray_concrete
fill 268 180 268 268 181 268 minecraft:light_gray_concrete
fill 269 180 229 269 181 229 minecraft:cyan_terracotta
fill 269 180 237 269 181 237 minecraft:cyan_terracotta
fill 269 180 261 269 181 261 minecraft:light_gray_concrete
fill 269 180 269 269 181 269 minecraft:light_gray_concrete
fill 271 180 229 271 181 229 minecraft:cyan_terracotta
fill 271 180 237 271 181 237 minecraft:cyan_terracotta
fill 271 180 243 271 181 243 minecraft:light_gray_concrete
fill 271 180 245 271 181 245 minecraft:light_gray_concrete
fill 271 180 247 271 181 247 minecraft:light_gray_concrete
fill 271 180 249 271 181 249 minecraft:light_gray_concrete
fill 271 180 251 271 181 251 minecraft:light_gray_concrete
fill 271 180 253 271 181 253 minecraft:light_gray_concrete
fill 271 180 261 271 181 261 minecraft:light_gray_concrete
fill 271 180 269 271 181 269 minecraft:light_gray_concrete
fill 272 180 242 272 181 242 minecraft:light_gray_concrete
fill 272 180 255 272 181 255 minecraft:light_gray_concrete
fill 273 180 229 273 181 229 minecraft:cyan_terracotta
fill 273 180 237 273 181 237 minecraft:cyan_terracotta
fill 273 180 261 273 181 261 minecraft:light_gray_concrete
fill 273 180 269 273 181 269 minecraft:light_gray_concrete
fill 274 180 242 274 181 242 minecraft:light_gray_concrete
fill 274 180 255 274 181 255 minecraft:light_gray_concrete
fill 275 180 229 275 181 229 minecraft:cyan_terracotta
fill 275 180 237 275 181 237 minecraft:cyan_terracotta
fill 275 180 261 275 181 261 minecraft:light_gray_concrete
fill 275 180 269 275 181 269 minecraft:light_gray_concrete
fill 276 180 230 276 181 230 minecraft:cyan_terracotta
fill 276 180 232 276 181 232 minecraft:cyan_terracotta
fill 276 180 234 276 181 234 minecraft:cyan_terracotta
fill 276 180 236 276 181 236 minecraft:cyan_terracotta
fill 276 180 243 276 181 243 minecraft:light_gray_concrete
fill 276 180 245 276 181 245 minecraft:light_gray_concrete
fill 276 180 247 276 181 247 minecraft:light_gray_concrete
fill 276 180 249 276 181 249 minecraft:light_gray_concrete
fill 276 180 251 276 181 251 minecraft:light_gray_concrete
fill 276 180 253 276 181 253 minecraft:light_gray_concrete
fill 276 180 262 276 181 262 minecraft:light_gray_concrete
fill 276 180 264 276 181 264 minecraft:light_gray_concrete
fill 276 180 266 276 181 266 minecraft:light_gray_concrete
fill 276 180 268 276 181 268 minecraft:light_gray_concrete
fill 235 181 234 235 303 234 minecraft:black_concrete
fill 235 181 262 235 231 262 minecraft:black_concrete
setblock 236 181 228 minecraft:purple_concrete
setblock 238 181 238 minecraft:light[level=12]
setblock 238 181 259 minecraft:light[level=12]
setblock 239 181 270 minecraft:pearlescent_froglight
setblock 245 181 231 minecraft:light[level=12]
setblock 245 181 238 minecraft:light[level=12]
setblock 245 181 245 minecraft:light[level=12]
setblock 245 181 252 minecraft:light[level=12]
setblock 245 181 259 minecraft:light[level=12]
setblock 245 181 266 minecraft:light[level=12]
setblock 252 181 231 minecraft:light[level=12]
setblock 252 181 238 minecraft:light[level=12]
setblock 252 181 245 minecraft:light[level=12]
setblock 252 181 252 minecraft:light[level=12]
setblock 252 181 259 minecraft:light[level=12]
setblock 252 181 266 minecraft:light[level=12]
setblock 255 181 270 minecraft:cyan_concrete
setblock 259 181 231 minecraft:light[level=12]
setblock 259 181 238 minecraft:light[level=12]
setblock 259 181 245 minecraft:light[level=12]
setblock 259 181 252 minecraft:light[level=12]
setblock 259 181 259 minecraft:light[level=12]
setblock 259 181 266 minecraft:light[level=12]
setblock 266 181 231 minecraft:light[level=12]
setblock 266 181 238 minecraft:light[level=12]
setblock 266 181 245 minecraft:light[level=12]
setblock 266 181 252 minecraft:light[level=12]
setblock 266 181 259 minecraft:light[level=12]
setblock 266 181 266 minecraft:light[level=12]
setblock 273 181 238 minecraft:light[level=12]
setblock 273 181 259 minecraft:light[level=12]
setblock 277 181 248 minecraft:cyan_concrete
setblock 235 182 233 minecraft:ochre_froglight
fill 236 182 228 236 194 228 minecraft:black_concrete
setblock 236 182 230 minecraft:pearlescent_froglight
setblock 236 182 232 minecraft:black_stained_glass
setblock 236 182 234 minecraft:light_blue_stained_glass
setblock 236 182 236 minecraft:black_stained_glass
setblock 236 182 243 minecraft:ochre_froglight
setblock 236 182 245 minecraft:light_blue_stained_glass
setblock 236 182 247 minecraft:magenta_stained_glass
setblock 236 182 249 minecraft:cyan_stained_glass
setblock 236 182 251 minecraft:light_blue_stained_glass
setblock 236 182 253 minecraft:black_stained_glass
setblock 236 182 262 minecraft:black_stained_glass
setblock 236 182 264 minecraft:black_stained_glass
setblock 236 182 266 minecraft:cyan_stained_glass
setblock 236 182 268 minecraft:pearlescent_froglight
setblock 237 182 229 minecraft:ochre_froglight
setblock 237 182 237 minecraft:black_stained_glass
setblock 237 182 242 minecraft:black_stained_glass
setblock 237 182 255 minecraft:cyan_stained_glass
setblock 237 182 261 minecraft:black_stained_glass
setblock 237 182 269 minecraft:black_stained_glass
setblock 239 182 229 minecraft:black_stained_glass
setblock 239 182 237 minecraft:cyan_stained_glass
setblock 239 182 242 minecraft:ochre_froglight
setblock 239 182 255 minecraft:magenta_stained_glass
setblock 239 182 261 minecraft:black_stained_glass
setblock 239 182 269 minecraft:black_stained_glass
fill 239 182 270 239 183 270 minecraft:black_concrete
setblock 241 182 229 minecraft:black_stained_glass
setblock 241 182 237 minecraft:black_stained_glass
setblock 241 182 243 minecraft:ochre_froglight
setblock 241 182 245 minecraft:black_stained_glass
setblock 241 182 247 minecraft:pearlescent_froglight
setblock 241 182 249 minecraft:black_stained_glass
setblock 241 182 251 minecraft:light_blue_stained_glass
setblock 241 182 253 minecraft:magenta_stained_glass
setblock 241 182 261 minecraft:pearlescent_froglight
setblock 241 182 269 minecraft:magenta_stained_glass
setblock 243 182 229 minecraft:black_stained_glass
setblock 243 182 237 minecraft:pearlescent_froglight
setblock 243 182 261 minecraft:ochre_froglight
setblock 243 182 269 minecraft:black_stained_glass
setblock 244 182 230 minecraft:light_blue_stained_glass
setblock 244 182 232 minecraft:black_stained_glass
setblock 244 182 234 minecraft:magenta_stained_glass
setblock 244 182 236 minecraft:magenta_stained_glass
setblock 244 182 262 minecraft:pearlescent_froglight
setblock 244 182 264 minecraft:ochre_froglight
setblock 244 182 266 minecraft:sea_lantern
setblock 244 182 268 minecraft:black_stained_glass
setblock 255 182 270 minecraft:black_concrete
setblock 268 182 230 minecraft:black_stained_glass
setblock 268 182 232 minecraft:black_stained_glass
setblock 268 182 234 minecraft:light_blue_stained_glass
setblock 268 182 236 minecraft:magenta_stained_glass
setblock 268 182 262 minecraft:pearlescent_froglight
setblock 268 182 264 minecraft:pearlescent_froglight
setblock 268 182 266 minecraft:black_stained_glass
setblock 268 182 268 minecraft:cyan_stained_glass
setblock 269 182 229 minecraft:black_stained_glass
setblock 269 182 237 minecraft:sea_lantern
setblock 269 182 261 minecraft:pearlescent_froglight
setblock 269 182 269 minecraft:black_stained_glass
setblock 271 182 229 minecraft:black_stained_glass
setblock 271 182 237 minecraft:pearlescent_froglight
setblock 271 182 243 minecraft:sea_lantern
setblock 271 182 245 minecraft:ochre_froglight
setblock 271 182 247 minecraft:black_stained_glass
setblock 271 182 249 minecraft:black_stained_glass
setblock 271 182 251 minecraft:sea_lantern
setblock 271 182 253 minecraft:ochre_froglight
setblock 271 182 261 minecraft:black_stained_glass
setblock 271 182 269 minecraft:cyan_stained_glass
setblock 272 182 242 minecraft:black_stained_glass
setblock 272 182 255 minecraft:sea_lantern
setblock 273 182 229 minecraft:light_blue_stained_glass
setblock 273 182 237 minecraft:black_stained_glass
setblock 273 182 261 minecraft:black_stained_glass
setblock 273 182 269 minecraft:black_stained_glass
setblock 274 182 242 minecraft:black_stained_glass
setblock 274 182 255 minecraft:light_blue_stained_glass
setblock 275 182 229 minecraft:black_stained_glass
setblock 275 182 237 minecraft:magenta_stained_glass
setblock 275 182 261 minecraft:pearlescent_froglight
setblock 275 182 269 minecraft:sea_lantern
setblock 276 182 230 minecraft:pearlescent_froglight
setblock 276 182 232 minecraft:magenta_stained_glass
setblock 276 182 234 minecraft:black_stained_glass
setblock 276 182 236 minecraft:black_stained_glass
setblock 276 182 243 minecraft:black_stained_glass
setblock 276 182 245 minecraft:magenta_stained_glass
setblock 276 182 247 minecraft:light_blue_stained_glass
setblock 276 182 249 minecraft:cyan_stained_glass
setblock 276 182 251 minecraft:magenta_stained_glass
setblock 276 182 253 minecraft:light_blue_stained_glass
setblock 276 182 262 minecraft:cyan_stained_glass
setblock 276 182 264 minecraft:black_stained_glass
setblock 276 182 266 minecraft:magenta_stained_glass
setblock 276 182 268 minecraft:cyan_stained_glass
setblock 277 182 229 minecraft:pearlescent_froglight
setblock 277 182 234 minecraft:pearlescent_froglight
fill 277 182 248 277 207 248 minecraft:black_concrete
fill 235 183 233 235 205 233 minecraft:black_concrete
fill 236 183 230 236 184 230 minecraft:light_gray_concrete
fill 236 183 232 236 184 232 minecraft:light_gray_concrete
fill 236 183 234 236 184 234 minecraft:light_gray_concrete
fill 236 183 236 236 184 236 minecraft:light_gray_concrete
setblock 236 183 243 minecraft:light_gray_concrete
setblock 236 183 245 minecraft:light_gray_concrete
setblock 236 183 247 minecraft:light_gray_concrete
setblock 236 183 249 minecraft:light_gray_concrete
setblock 236 183 251 minecraft:light_gray_concrete
setblock 236 183 253 minecraft:light_gray_concrete
fill 236 183 262 236 184 262 minecraft:cyan_terracotta
fill 236 183 264 236 184 264 minecraft:cyan_terracotta
fill 236 183 266 236 184 266 minecraft:cyan_terracotta
fill 236 183 268 236 184 268 minecraft:cyan_terracotta
fill 237 183 229 237 184 229 minecraft:light_gray_concrete
fill 237 183 237 237 184 237 minecraft:light_gray_concrete
setblock 237 183 242 minecraft:light_gray_concrete
setblock 237 183 255 minecraft:light_gray_concrete
fill 237 183 261 237 184 261 minecraft:cyan_terracotta
fill 237 183 269 237 184 269 minecraft:cyan_terracotta
setblock 237 183 270 minecraft:pearlescent_froglight
fill 239 183 229 239 184 229 minecraft:light_gray_concrete
fill 239 183 237 239 184 237 minecraft:light_gray_concrete
setblock 239 183 242 minecraft:light_gray_concrete
setblock 239 183 255 minecraft:light_gray_concrete
fill 239 183 261 239 184 261 minecraft:cyan_terracotta
fill 239 183 269 239 184 269 minecraft:cyan_terracotta
setblock 241 183 228 minecraft:verdant_froglight
fill 241 183 229 241 184 229 minecraft:light_gray_concrete
fill 241 183 237 241 184 237 minecraft:light_gray_concrete
setblock 241 183 243 minecraft:light_gray_concrete
setblock 241 183 245 minecraft:light_gray_concrete
setblock 241 183 247 minecraft:light_gray_concrete
setblock 241 183 249 minecraft:light_gray_concrete
setblock 241 183 251 minecraft:light_gray_concrete
setblock 241 183 253 minecraft:light_gray_concrete
fill 241 183 261 241 184 261 minecraft:cyan_terracotta
fill 241 183 269 241 184 269 minecraft:cyan_terracotta
fill 243 183 229 243 184 229 minecraft:light_gray_concrete
fill 243 183 237 243 184 237 minecraft:light_gray_concrete
fill 243 183 261 243 184 261 minecraft:cyan_terracotta
fill 243 183 269 243 184 269 minecraft:cyan_terracotta
fill 244 183 230 244 184 230 minecraft:light_gray_concrete
fill 244 183 232 244 184 232 minecraft:light_gray_concrete
fill 244 183 234 244 184 234 minecraft:light_gray_concrete
fill 244 183 236 244 184 236 minecraft:light_gray_concrete
fill 244 183 262 244 184 262 minecraft:cyan_terracotta
fill 244 183 264 244 184 264 minecraft:cyan_terracotta
fill 244 183 266 244 184 266 minecraft:cyan_terracotta
fill 244 183 268 244 184 268 minecraft:cyan_terracotta
setblock 255 183 270 minecraft:blue_concrete
fill 268 183 230 268 184 230 minecraft:cyan_terracotta
fill 268 183 232 268 184 232 minecraft:cyan_terracotta
fill 268 183 234 268 184 234 minecraft:cyan_terracotta
fill 268 183 236 268 184 236 minecraft:cyan_terracotta
fill 268 183 262 268 184 262 minecraft:light_gray_concrete
fill 268 183 264 268 184 264 minecraft:light_gray_concrete
fill 268 183 266 268 184 266 minecraft:light_gray_concrete
fill 268 183 268 268 184 268 minecraft:light_gray_concrete
fill 269 183 229 269 184 229 minecraft:cyan_terracotta
fill 269 183 237 269 184 237 minecraft:cyan_terracotta
fill 269 183 261 269 184 261 minecraft:light_gray_concrete
fill 269 183 269 269 184 269 minecraft:light_gray_concrete
fill 271 183 229 271 184 229 minecraft:cyan_terracotta
fill 271 183 237 271 184 237 minecraft:cyan_terracotta
fill 271 183 243 271 184 243 minecraft:light_gray_concrete
fill 271 183 245 271 184 245 minecraft:light_gray_concrete
fill 271 183 247 271 184 247 minecraft:light_gray_concrete
fill 271 183 249 271 184 249 minecraft:light_gray_concrete
fill 271 183 251 271 184 251 minecraft:light_gray_concrete
fill 271 183 253 271 184 253 minecraft:light_gray_concrete
fill 271 183 261 271 184 261 minecraft:light_gray_concrete
fill 271 183 269 271 184 269 minecraft:light_gray_concrete
fill 272 183 242 272 184 242 minecraft:light_gray_concrete
fill 272 183 255 272 184 255 minecraft:light_gray_concrete
fill 273 183 229 273 184 229 minecraft:cyan_terracotta
fill 273 183 237 273 184 237 minecraft:cyan_terracotta
fill 273 183 261 273 184 261 minecraft:light_gray_concrete
fill 273 183 269 273 184 269 minecraft:light_gray_concrete
fill 274 183 242 274 184 242 minecraft:light_gray_concrete
fill 274 183 255 274 184 255 minecraft:light_gray_concrete
fill 275 183 229 275 184 229 minecraft:cyan_terracotta
fill 275 183 237 275 184 237 minecraft:cyan_terracotta
fill 275 183 261 275 184 261 minecraft:light_gray_concrete
fill 275 183 269 275 184 269 minecraft:light_gray_concrete
fill 276 183 230 276 184 230 minecraft:cyan_terracotta
fill 276 183 232 276 184 232 minecraft:cyan_terracotta
fill 276 183 234 276 184 234 minecraft:cyan_terracotta
fill 276 183 236 276 184 236 minecraft:cyan_terracotta
fill 276 183 243 276 184 243 minecraft:light_gray_concrete
fill 276 183 245 276 184 245 minecraft:light_gray_concrete
fill 276 183 247 276 184 247 minecraft:light_gray_concrete
fill 276 183 249 276 184 249 minecraft:light_gray_concrete
fill 276 183 251 276 184 251 minecraft:light_gray_concrete
fill 276 183 253 276 184 253 minecraft:light_gray_concrete
fill 276 183 262 276 184 262 minecraft:light_gray_concrete
fill 276 183 264 276 184 264 minecraft:light_gray_concrete
fill 276 183 266 276 184 266 minecraft:light_gray_concrete
fill 276 183 268 276 184 268 minecraft:light_gray_concrete
fill 277 183 229 277 241 229 minecraft:black_concrete
fill 277 183 234 277 195 234 minecraft:black_concrete
setblock 277 183 264 minecraft:ochre_froglight
fill 236 184 242 241 184 255 minecraft:black_concrete
fill 237 184 270 237 308 270 minecraft:black_concrete
setblock 239 184 228 minecraft:blue_concrete
setblock 239 184 270 minecraft:blue_concrete
schedule function dropper:buildpart/53_6 1t
