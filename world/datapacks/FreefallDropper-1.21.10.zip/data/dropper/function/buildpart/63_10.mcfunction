setblock 176 258 276 minecraft:snow_block
fill 176 258 277 177 260 277 minecraft:packed_ice
setblock 176 258 316 minecraft:snow_block
fill 177 258 276 177 261 276 minecraft:packed_ice
setblock 177 258 315 minecraft:snow_block
fill 177 258 316 177 261 316 minecraft:packed_ice
fill 178 258 315 178 261 315 minecraft:packed_ice
setblock 179 258 278 minecraft:light[level=12]
setblock 179 258 285 minecraft:light[level=12]
setblock 179 258 292 minecraft:light[level=12]
setblock 179 258 299 minecraft:light[level=12]
setblock 179 258 306 minecraft:light[level=12]
setblock 179 258 313 minecraft:light[level=12]
fill 180 258 315 181 258 315 minecraft:packed_ice
setblock 181 258 276 minecraft:snow_block
setblock 181 258 316 minecraft:snow_block
fill 182 258 276 182 261 276 minecraft:packed_ice
fill 182 258 311 182 261 311 minecraft:packed_ice
setblock 182 258 315 minecraft:snow_block
fill 182 258 316 182 261 316 minecraft:packed_ice
fill 183 258 305 183 308 305 minecraft:snow_block
fill 141 259 308 141 260 308 minecraft:snow_block
fill 142 259 295 142 261 296 minecraft:packed_ice
setblock 142 259 309 minecraft:snow_block
fill 142 259 310 142 262 310 minecraft:packed_ice
setblock 142 259 314 minecraft:snow_block
fill 142 259 315 145 259 315 minecraft:packed_ice
setblock 143 259 313 minecraft:snow_block
fill 143 259 314 143 262 314 minecraft:packed_ice
setblock 145 259 276 minecraft:snow_block
setblock 145 259 316 minecraft:snow_block
fill 146 259 276 149 259 276 minecraft:packed_ice
setblock 146 259 314 minecraft:packed_ice
setblock 146 259 315 minecraft:snow_block
fill 146 259 316 146 262 316 minecraft:packed_ice
setblock 147 259 314 minecraft:snow_block
fill 147 259 315 147 262 315 minecraft:packed_ice
fill 148 259 314 148 262 314 minecraft:packed_ice
fill 150 259 275 150 259 276 minecraft:snow_block
setblock 150 259 316 minecraft:snow_block
fill 151 259 275 152 266 275 minecraft:snow_block
fill 151 259 276 151 262 276 minecraft:packed_ice
setblock 151 259 315 minecraft:snow_block
fill 151 259 316 151 262 316 minecraft:packed_ice
setblock 152 259 314 minecraft:snow_block
fill 152 259 315 152 262 315 minecraft:packed_ice
setblock 153 259 275 minecraft:light_blue_concrete
fill 154 259 275 157 297 275 minecraft:snow_block
setblock 155 259 276 minecraft:snow_block
setblock 155 259 316 minecraft:snow_block
fill 156 259 316 156 262 316 minecraft:packed_ice
setblock 164 259 276 minecraft:packed_ice
setblock 165 259 276 minecraft:snow_block
setblock 165 259 316 minecraft:snow_block
fill 166 259 276 166 261 277 minecraft:packed_ice
fill 166 259 316 166 262 316 minecraft:packed_ice
fill 167 259 277 167 260 277 minecraft:packed_ice
fill 167 259 315 167 262 315 minecraft:packed_ice
setblock 169 259 277 minecraft:snow_block
fill 169 259 278 171 260 278 minecraft:packed_ice
setblock 170 259 276 minecraft:snow_block
fill 170 259 277 170 262 277 minecraft:packed_ice
setblock 170 259 316 minecraft:snow_block
fill 171 259 276 171 262 276 minecraft:packed_ice
setblock 171 259 315 minecraft:snow_block
fill 171 259 316 171 262 316 minecraft:packed_ice
setblock 172 259 314 minecraft:snow_block
fill 172 259 315 172 262 315 minecraft:packed_ice
setblock 173 259 278 minecraft:snow_block
setblock 174 259 277 minecraft:snow_block
fill 174 259 278 174 262 278 minecraft:packed_ice
setblock 175 259 276 minecraft:snow_block
fill 175 259 277 175 262 277 minecraft:packed_ice
setblock 175 259 316 minecraft:snow_block
fill 176 259 276 176 262 276 minecraft:packed_ice
setblock 176 259 315 minecraft:snow_block
fill 176 259 316 176 262 316 minecraft:packed_ice
fill 177 259 315 177 262 315 minecraft:packed_ice
setblock 178 259 277 minecraft:packed_ice
setblock 180 259 276 minecraft:snow_block
setblock 180 259 315 minecraft:packed_ice
setblock 180 259 316 minecraft:snow_block
fill 181 259 276 181 262 276 minecraft:packed_ice
setblock 181 259 314 minecraft:packed_ice
setblock 181 259 315 minecraft:snow_block
fill 181 259 316 181 262 316 minecraft:packed_ice
fill 182 259 277 182 260 277 minecraft:packed_ice
setblock 182 259 314 minecraft:snow_block
fill 182 259 315 182 262 315 minecraft:packed_ice
fill 183 259 281 183 305 283 minecraft:snow_block
setblock 183 259 284 minecraft:white_concrete
fill 142 260 276 143 260 276 minecraft:packed_ice
setblock 142 260 293 minecraft:snow_block
fill 142 260 294 142 263 294 minecraft:packed_ice
setblock 142 260 297 minecraft:packed_ice
setblock 142 260 298 minecraft:snow_block
fill 142 260 299 142 261 301 minecraft:packed_ice
fill 142 260 309 142 263 309 minecraft:packed_ice
setblock 142 260 313 minecraft:snow_block
fill 142 260 314 142 262 315 minecraft:packed_ice
setblock 143 260 311 minecraft:packed_ice
setblock 143 260 312 minecraft:snow_block
fill 143 260 313 143 263 313 minecraft:packed_ice
fill 143 260 315 144 260 315 minecraft:packed_ice
setblock 144 260 276 minecraft:snow_block
setblock 144 260 316 minecraft:snow_block
fill 145 260 276 148 260 276 minecraft:packed_ice
setblock 145 260 314 minecraft:packed_ice
setblock 145 260 315 minecraft:snow_block
fill 145 260 316 145 263 316 minecraft:packed_ice
setblock 146 260 314 minecraft:snow_block
fill 146 260 315 146 263 315 minecraft:packed_ice
setblock 147 260 275 minecraft:light_blue_concrete
fill 147 260 314 147 263 314 minecraft:packed_ice
fill 148 260 275 148 273 275 minecraft:snow_block
setblock 148 260 277 minecraft:snow_block
setblock 149 260 276 minecraft:snow_block
fill 149 260 277 151 261 277 minecraft:packed_ice
setblock 149 260 316 minecraft:snow_block
fill 150 260 275 150 261 275 minecraft:snow_block
fill 150 260 276 150 263 276 minecraft:packed_ice
setblock 150 260 315 minecraft:snow_block
fill 150 260 316 150 263 316 minecraft:packed_ice
setblock 151 260 314 minecraft:snow_block
fill 151 260 315 151 263 315 minecraft:packed_ice
setblock 152 260 314 minecraft:packed_ice
fill 153 260 275 153 302 275 minecraft:snow_block
setblock 154 260 276 minecraft:snow_block
setblock 154 260 316 minecraft:snow_block
fill 155 260 276 156 262 276 minecraft:packed_ice
fill 155 260 316 155 263 316 minecraft:packed_ice
fill 162 260 276 163 260 276 minecraft:packed_ice
setblock 163 260 316 minecraft:packed_ice
setblock 164 260 276 minecraft:snow_block
setblock 164 260 316 minecraft:snow_block
fill 165 260 276 165 262 277 minecraft:packed_ice
fill 165 260 316 165 263 316 minecraft:packed_ice
fill 166 260 315 166 263 315 minecraft:packed_ice
setblock 167 260 278 minecraft:snow_block
setblock 168 260 277 minecraft:snow_block
fill 168 260 278 168 263 278 minecraft:packed_ice
setblock 169 260 276 minecraft:snow_block
fill 169 260 277 169 263 277 minecraft:packed_ice
setblock 169 260 316 minecraft:snow_block
fill 170 260 276 170 263 276 minecraft:packed_ice
setblock 170 260 314 minecraft:packed_ice
setblock 170 260 315 minecraft:snow_block
fill 170 260 316 170 263 316 minecraft:packed_ice
setblock 171 260 314 minecraft:snow_block
fill 171 260 315 171 263 315 minecraft:packed_ice
setblock 172 260 278 minecraft:snow_block
fill 172 260 314 173 261 314 minecraft:packed_ice
setblock 173 260 277 minecraft:snow_block
fill 173 260 278 173 263 278 minecraft:packed_ice
setblock 174 260 276 minecraft:snow_block
fill 174 260 277 174 263 277 minecraft:packed_ice
setblock 174 260 316 minecraft:snow_block
fill 175 260 276 175 263 276 minecraft:packed_ice
fill 175 260 278 175 261 278 minecraft:packed_ice
setblock 175 260 315 minecraft:snow_block
fill 175 260 316 175 263 316 minecraft:packed_ice
setblock 175 260 317 minecraft:white_concrete
fill 176 260 315 176 263 315 minecraft:packed_ice
fill 177 260 304 177 261 304 minecraft:packed_ice
setblock 178 260 277 minecraft:snow_block
fill 178 260 303 178 261 303 minecraft:packed_ice
fill 178 260 305 178 261 305 minecraft:packed_ice
setblock 179 260 276 minecraft:snow_block
fill 179 260 277 179 263 277 minecraft:packed_ice
fill 179 260 304 179 261 304 minecraft:packed_ice
setblock 179 260 316 minecraft:snow_block
fill 180 260 276 180 263 276 minecraft:packed_ice
setblock 180 260 315 minecraft:snow_block
fill 180 260 316 180 263 316 minecraft:packed_ice
setblock 181 260 314 minecraft:snow_block
fill 181 260 315 181 263 315 minecraft:packed_ice
setblock 182 260 278 minecraft:snow_block
setblock 182 260 313 minecraft:snow_block
fill 182 260 314 182 263 314 minecraft:packed_ice
setblock 183 260 279 minecraft:white_concrete
fill 183 260 284 183 308 284 minecraft:snow_block
fill 141 261 308 141 262 308 minecraft:white_concrete
setblock 142 261 276 minecraft:packed_ice
setblock 142 261 277 minecraft:snow_block
setblock 142 261 292 minecraft:snow_block
fill 142 261 293 142 264 293 minecraft:packed_ice
setblock 142 261 297 minecraft:snow_block
fill 142 261 298 144 262 298 minecraft:packed_ice
setblock 142 261 302 minecraft:snow_block
fill 142 261 303 142 261 306 minecraft:packed_ice
setblock 142 261 307 minecraft:snow_block
fill 142 261 308 142 264 308 minecraft:packed_ice
setblock 142 261 312 minecraft:snow_block
fill 142 261 313 142 264 313 minecraft:packed_ice
setblock 143 261 276 minecraft:snow_block
fill 143 261 294 143 261 295 minecraft:packed_ice
setblock 143 261 296 minecraft:snow_block
fill 143 261 297 144 263 297 minecraft:packed_ice
fill 143 261 299 143 261 300 minecraft:packed_ice
setblock 143 261 301 minecraft:snow_block
setblock 143 261 311 minecraft:snow_block
fill 143 261 312 143 264 312 minecraft:packed_ice
setblock 143 261 315 minecraft:packed_ice
setblock 143 261 316 minecraft:snow_block
fill 144 261 276 147 261 276 minecraft:packed_ice
setblock 144 261 314 minecraft:packed_ice
setblock 144 261 315 minecraft:snow_block
fill 144 261 316 144 264 316 minecraft:packed_ice
setblock 145 261 314 minecraft:snow_block
fill 145 261 315 145 264 315 minecraft:packed_ice
setblock 146 261 277 minecraft:packed_ice
fill 146 261 314 146 264 314 minecraft:packed_ice
fill 147 261 275 147 308 275 minecraft:snow_block
setblock 147 261 277 minecraft:snow_block
setblock 148 261 276 minecraft:snow_block
fill 148 261 277 148 264 277 minecraft:packed_ice
setblock 148 261 316 minecraft:snow_block
fill 149 261 276 149 264 276 minecraft:packed_ice
setblock 149 261 315 minecraft:snow_block
fill 149 261 316 149 264 316 minecraft:packed_ice
setblock 150 261 314 minecraft:snow_block
fill 150 261 315 150 264 315 minecraft:packed_ice
fill 151 261 314 151 262 314 minecraft:packed_ice
setblock 152 261 277 minecraft:snow_block
setblock 153 261 276 minecraft:snow_block
fill 153 261 277 153 264 277 minecraft:packed_ice
setblock 153 261 316 minecraft:snow_block
fill 154 261 276 154 264 276 minecraft:packed_ice
setblock 154 261 315 minecraft:snow_block
fill 154 261 316 154 264 316 minecraft:packed_ice
setblock 157 261 276 minecraft:packed_ice
setblock 158 261 276 minecraft:snow_block
fill 159 261 276 162 261 276 minecraft:packed_ice
setblock 160 261 275 minecraft:white_concrete
fill 161 261 275 164 266 275 minecraft:snow_block
setblock 162 261 316 minecraft:packed_ice
setblock 163 261 276 minecraft:snow_block
fill 163 261 277 164 263 277 minecraft:packed_ice
setblock 163 261 316 minecraft:snow_block
fill 164 261 276 164 264 276 minecraft:packed_ice
fill 164 261 316 164 264 316 minecraft:packed_ice
setblock 166 261 278 minecraft:snow_block
setblock 167 261 277 minecraft:snow_block
fill 167 261 278 167 264 278 minecraft:packed_ice
setblock 168 261 276 minecraft:snow_block
fill 168 261 277 168 264 277 minecraft:packed_ice
setblock 168 261 316 minecraft:snow_block
fill 169 261 276 169 264 276 minecraft:packed_ice
fill 169 261 278 169 261 279 minecraft:packed_ice
setblock 169 261 314 minecraft:packed_ice
setblock 169 261 315 minecraft:snow_block
fill 169 261 316 169 264 316 minecraft:packed_ice
setblock 170 261 278 minecraft:packed_ice
setblock 170 261 279 minecraft:snow_block
setblock 170 261 314 minecraft:snow_block
fill 170 261 315 170 264 315 minecraft:packed_ice
setblock 171 261 278 minecraft:snow_block
fill 171 261 279 171 264 279 minecraft:packed_ice
fill 171 261 314 171 263 314 minecraft:packed_ice
setblock 172 261 277 minecraft:snow_block
fill 172 261 278 172 264 278 minecraft:packed_ice
setblock 173 261 276 minecraft:snow_block
fill 173 261 277 173 264 277 minecraft:packed_ice
setblock 173 261 316 minecraft:snow_block
fill 174 261 276 174 264 276 minecraft:packed_ice
setblock 174 261 315 minecraft:snow_block
fill 174 261 316 174 264 316 minecraft:packed_ice
fill 175 261 315 175 264 315 minecraft:packed_ice
fill 175 261 317 175 308 317 minecraft:snow_block
setblock 176 261 277 minecraft:packed_ice
setblock 177 261 277 minecraft:snow_block
setblock 178 261 276 minecraft:snow_block
fill 178 261 277 178 264 277 minecraft:packed_ice
setblock 178 261 316 minecraft:snow_block
fill 179 261 276 179 264 276 minecraft:packed_ice
fill 179 261 297 179 271 297 minecraft:packed_ice
setblock 179 261 315 minecraft:snow_block
fill 179 261 316 179 264 316 minecraft:packed_ice
fill 180 261 277 181 261 277 minecraft:packed_ice
fill 180 261 315 180 264 315 minecraft:packed_ice
setblock 181 261 313 minecraft:snow_block
fill 181 261 314 181 264 314 minecraft:packed_ice
setblock 182 261 277 minecraft:snow_block
fill 182 261 278 182 263 279 minecraft:packed_ice
fill 182 261 295 182 261 296 minecraft:packed_ice
setblock 182 261 297 minecraft:snow_block
fill 182 261 310 182 262 310 minecraft:packed_ice
setblock 182 261 312 minecraft:snow_block
fill 182 261 313 182 264 313 minecraft:packed_ice
fill 183 261 279 183 308 279 minecraft:snow_block
setblock 142 262 276 minecraft:snow_block
fill 142 262 277 142 264 278 minecraft:packed_ice
fill 142 262 292 142 265 292 minecraft:packed_ice
setblock 142 262 295 minecraft:packed_ice
setblock 142 262 296 minecraft:snow_block
fill 142 262 297 142 265 297 minecraft:packed_ice
fill 142 262 299 142 262 300 minecraft:packed_ice
setblock 142 262 301 minecraft:snow_block
fill 142 262 302 142 262 305 minecraft:packed_ice
setblock 142 262 306 minecraft:snow_block
fill 142 262 307 142 265 307 minecraft:packed_ice
setblock 142 262 311 minecraft:snow_block
fill 142 262 312 142 265 312 minecraft:packed_ice
setblock 142 262 316 minecraft:snow_block
fill 143 262 276 146 262 276 minecraft:packed_ice
fill 143 262 293 143 262 294 minecraft:packed_ice
setblock 143 262 295 minecraft:snow_block
fill 143 262 296 144 264 296 minecraft:packed_ice
setblock 143 262 299 minecraft:packed_ice
setblock 143 262 300 minecraft:snow_block
fill 143 262 301 143 262 304 minecraft:packed_ice
setblock 143 262 310 minecraft:snow_block
fill 143 262 311 143 265 311 minecraft:packed_ice
setblock 143 262 315 minecraft:snow_block
fill 143 262 316 143 265 316 minecraft:packed_ice
fill 144 262 277 145 262 277 minecraft:packed_ice
fill 144 262 295 144 265 295 minecraft:packed_ice
setblock 144 262 299 minecraft:snow_block
fill 144 262 300 144 264 301 minecraft:packed_ice
setblock 144 262 314 minecraft:snow_block
fill 144 262 315 144 265 315 minecraft:packed_ice
setblock 145 262 297 minecraft:packed_ice
setblock 145 262 298 minecraft:snow_block
fill 145 262 314 145 264 314 minecraft:packed_ice
setblock 146 262 277 minecraft:snow_block
setblock 147 262 276 minecraft:snow_block
fill 147 262 277 147 265 277 minecraft:packed_ice
setblock 147 262 316 minecraft:snow_block
fill 148 262 276 148 265 276 minecraft:packed_ice
setblock 148 262 315 minecraft:snow_block
fill 148 262 316 148 265 316 minecraft:packed_ice
fill 149 262 277 150 262 277 minecraft:packed_ice
setblock 149 262 314 minecraft:snow_block
fill 149 262 315 149 265 315 minecraft:packed_ice
setblock 150 262 275 minecraft:light_blue_concrete
fill 150 262 314 150 263 314 minecraft:packed_ice
setblock 151 262 277 minecraft:snow_block
setblock 152 262 276 minecraft:snow_block
fill 152 262 277 152 265 277 minecraft:packed_ice
setblock 152 262 316 minecraft:snow_block
fill 153 262 276 153 265 276 minecraft:packed_ice
setblock 153 262 315 minecraft:snow_block
fill 153 262 316 153 265 316 minecraft:packed_ice
setblock 157 262 276 minecraft:snow_block
fill 158 262 276 161 262 276 minecraft:packed_ice
fill 160 262 275 160 293 275 minecraft:snow_block
setblock 161 262 316 minecraft:packed_ice
setblock 162 262 276 minecraft:snow_block
fill 162 262 277 162 265 277 minecraft:packed_ice
setblock 162 262 316 minecraft:snow_block
fill 163 262 276 163 265 276 minecraft:packed_ice
fill 163 262 316 163 265 316 minecraft:packed_ice
setblock 164 262 278 minecraft:packed_ice
setblock 165 262 278 minecraft:snow_block
fill 165 262 315 165 264 315 minecraft:packed_ice
setblock 166 262 276 minecraft:packed_ice
setblock 166 262 277 minecraft:snow_block
fill 166 262 278 166 265 278 minecraft:packed_ice
setblock 167 262 276 minecraft:snow_block
fill 167 262 277 167 265 277 minecraft:packed_ice
fill 167 262 279 168 262 279 minecraft:packed_ice
setblock 167 262 316 minecraft:snow_block
fill 168 262 276 168 265 276 minecraft:packed_ice
setblock 168 262 315 minecraft:snow_block
fill 168 262 316 168 265 316 minecraft:packed_ice
setblock 169 262 278 minecraft:packed_ice
setblock 169 262 279 minecraft:snow_block
setblock 169 262 314 minecraft:snow_block
fill 169 262 315 169 265 315 minecraft:packed_ice
setblock 170 262 278 minecraft:snow_block
fill 170 262 279 170 265 279 minecraft:packed_ice
fill 170 262 314 170 263 314 minecraft:packed_ice
setblock 171 262 277 minecraft:snow_block
fill 171 262 278 171 265 278 minecraft:packed_ice
setblock 172 262 276 minecraft:snow_block
fill 172 262 277 172 265 277 minecraft:packed_ice
fill 172 262 279 172 263 279 minecraft:packed_ice
setblock 172 262 314 minecraft:packed_ice
setblock 172 262 316 minecraft:snow_block
fill 173 262 276 173 265 276 minecraft:packed_ice
setblock 173 262 315 minecraft:snow_block
fill 173 262 316 173 265 316 minecraft:packed_ice
fill 174 262 315 174 265 315 minecraft:packed_ice
setblock 175 262 278 minecraft:snow_block
setblock 176 262 277 minecraft:snow_block
fill 176 262 278 176 264 278 minecraft:packed_ice
setblock 177 262 276 minecraft:snow_block
fill 177 262 277 177 265 277 minecraft:packed_ice
setblock 177 262 316 minecraft:snow_block
fill 178 262 276 178 265 276 minecraft:packed_ice
fill 178 262 280 181 263 280 minecraft:blue_ice
setblock 178 262 315 minecraft:snow_block
fill 178 262 316 178 265 316 minecraft:packed_ice
fill 179 262 315 179 265 315 minecraft:packed_ice
setblock 180 262 277 minecraft:packed_ice
fill 180 262 279 181 262 279 minecraft:blue_ice
fill 180 262 281 181 264 281 minecraft:blue_ice
setblock 181 262 277 minecraft:snow_block
fill 181 262 278 181 265 278 minecraft:packed_ice
fill 181 262 313 181 264 313 minecraft:packed_ice
setblock 182 262 276 minecraft:snow_block
fill 182 262 277 182 265 277 minecraft:packed_ice
setblock 182 262 280 minecraft:packed_ice
fill 182 262 294 182 262 295 minecraft:packed_ice
setblock 182 262 296 minecraft:snow_block
fill 182 262 297 182 262 300 minecraft:packed_ice
setblock 182 262 301 minecraft:snow_block
setblock 182 262 311 minecraft:snow_block
fill 182 262 312 182 265 312 minecraft:packed_ice
setblock 182 262 316 minecraft:snow_block
fill 183 262 306 183 263 306 minecraft:light_blue_concrete
fill 183 262 307 183 282 308 minecraft:snow_block
fill 141 263 308 141 271 308 minecraft:snow_block
fill 142 263 276 145 263 276 minecraft:packed_ice
setblock 142 263 279 minecraft:packed_ice
setblock 142 263 295 minecraft:snow_block
fill 142 263 296 142 266 296 minecraft:packed_ice
fill 142 263 298 142 263 299 minecraft:packed_ice
setblock 142 263 300 minecraft:snow_block
fill 142 263 301 142 263 304 minecraft:packed_ice
setblock 142 263 305 minecraft:snow_block
fill 142 263 306 143 265 306 minecraft:packed_ice
setblock 142 263 310 minecraft:snow_block
fill 142 263 311 142 266 311 minecraft:packed_ice
setblock 142 263 314 minecraft:packed_ice
setblock 142 263 315 minecraft:snow_block
fill 142 263 316 142 266 316 minecraft:packed_ice
fill 143 263 277 144 263 277 minecraft:packed_ice
setblock 143 263 293 minecraft:packed_ice
setblock 143 263 294 minecraft:snow_block
fill 143 263 295 143 266 295 minecraft:packed_ice
setblock 143 263 298 minecraft:packed_ice
setblock 143 263 299 minecraft:snow_block
fill 143 263 300 143 263 303 minecraft:packed_ice
setblock 143 263 304 minecraft:snow_block
fill 143 263 305 143 266 305 minecraft:packed_ice
fill 143 263 307 143 263 308 minecraft:packed_ice
setblock 143 263 309 minecraft:snow_block
fill 143 263 310 143 266 310 minecraft:packed_ice
setblock 143 263 314 minecraft:snow_block
fill 143 263 315 143 266 315 minecraft:packed_ice
fill 144 263 294 144 266 294 minecraft:packed_ice
setblock 144 263 298 minecraft:snow_block
fill 144 263 299 145 265 299 minecraft:packed_ice
setblock 144 263 302 minecraft:packed_ice
setblock 144 263 303 minecraft:snow_block
setblock 144 263 314 minecraft:packed_ice
setblock 145 263 277 minecraft:snow_block
setblock 145 263 296 minecraft:packed_ice
setblock 145 263 297 minecraft:snow_block
fill 145 263 298 145 266 298 minecraft:packed_ice
fill 145 263 300 145 263 301 minecraft:packed_ice
setblock 146 263 276 minecraft:snow_block
fill 146 263 277 146 266 277 minecraft:packed_ice
setblock 146 263 316 minecraft:snow_block
fill 147 263 276 147 266 276 minecraft:packed_ice
setblock 147 263 315 minecraft:snow_block
fill 147 263 316 147 266 316 minecraft:packed_ice
setblock 148 263 314 minecraft:snow_block
fill 148 263 315 148 266 315 minecraft:packed_ice
setblock 149 263 277 minecraft:packed_ice
setblock 149 263 314 minecraft:packed_ice
fill 150 263 275 150 308 275 minecraft:snow_block
setblock 150 263 277 minecraft:snow_block
setblock 151 263 276 minecraft:snow_block
fill 151 263 277 151 266 277 minecraft:packed_ice
setblock 151 263 316 minecraft:snow_block
fill 152 263 276 152 266 276 minecraft:packed_ice
setblock 152 263 315 minecraft:snow_block
fill 152 263 316 152 265 316 minecraft:packed_ice
setblock 154 263 277 minecraft:packed_ice
setblock 155 263 276 minecraft:packed_ice
setblock 156 263 276 minecraft:snow_block
setblock 156 263 316 minecraft:snow_block
fill 157 263 276 160 263 276 minecraft:packed_ice
setblock 160 263 277 minecraft:snow_block
setblock 161 263 276 minecraft:snow_block
fill 161 263 277 161 266 277 minecraft:packed_ice
setblock 161 263 316 minecraft:snow_block
fill 162 263 276 162 266 276 minecraft:packed_ice
fill 162 263 316 162 266 316 minecraft:packed_ice
setblock 163 263 278 minecraft:packed_ice
setblock 164 263 278 minecraft:snow_block
setblock 165 263 276 minecraft:packed_ice
setblock 165 263 277 minecraft:snow_block
fill 165 263 278 165 266 278 minecraft:packed_ice
setblock 166 263 276 minecraft:snow_block
fill 166 263 277 166 266 277 minecraft:packed_ice
fill 166 263 279 167 263 279 minecraft:packed_ice
setblock 166 263 316 minecraft:snow_block
fill 167 263 276 167 266 276 minecraft:packed_ice
setblock 167 263 315 minecraft:snow_block
fill 167 263 316 167 266 316 minecraft:packed_ice
setblock 168 263 279 minecraft:snow_block
fill 168 263 315 168 266 315 minecraft:packed_ice
setblock 169 263 278 minecraft:snow_block
fill 169 263 279 169 266 279 minecraft:packed_ice
setblock 169 263 314 minecraft:packed_ice
setblock 170 263 277 minecraft:snow_block
fill 170 263 278 170 266 278 minecraft:packed_ice
setblock 171 263 276 minecraft:snow_block
fill 171 263 277 171 266 277 minecraft:packed_ice
setblock 171 263 316 minecraft:snow_block
fill 172 263 276 172 266 276 minecraft:packed_ice
setblock 172 263 315 minecraft:snow_block
fill 172 263 316 172 266 316 minecraft:packed_ice
fill 173 263 315 173 265 315 minecraft:packed_ice
setblock 174 263 278 minecraft:snow_block
setblock 175 263 277 minecraft:snow_block
fill 175 263 278 175 265 278 minecraft:packed_ice
setblock 176 263 276 minecraft:snow_block
fill 176 263 277 176 266 277 minecraft:packed_ice
setblock 176 263 316 minecraft:snow_block
fill 177 263 276 177 266 276 minecraft:packed_ice
setblock 177 263 315 minecraft:snow_block
fill 177 263 316 177 266 316 minecraft:packed_ice
fill 178 263 279 180 263 279 minecraft:blue_ice
fill 178 263 315 178 265 315 minecraft:packed_ice
fill 179 263 281 179 264 281 minecraft:blue_ice
setblock 180 263 277 minecraft:snow_block
setblock 181 263 276 minecraft:snow_block
fill 181 263 277 181 266 277 minecraft:packed_ice
fill 181 263 279 181 264 279 minecraft:packed_ice
setblock 181 263 316 minecraft:snow_block
fill 182 263 276 182 266 276 minecraft:packed_ice
setblock 182 263 280 minecraft:snow_block
fill 182 263 281 182 266 281 minecraft:packed_ice
setblock 182 263 294 minecraft:packed_ice
setblock 182 263 295 minecraft:snow_block
fill 182 263 296 182 263 299 minecraft:packed_ice
setblock 182 263 300 minecraft:snow_block
fill 182 263 301 182 263 304 minecraft:packed_ice
fill 182 263 308 182 263 309 minecraft:packed_ice
setblock 182 263 310 minecraft:snow_block
fill 182 263 311 182 266 311 minecraft:packed_ice
setblock 182 263 315 minecraft:snow_block
fill 182 263 316 182 266 316 minecraft:packed_ice
setblock 183 263 277 minecraft:light_blue_concrete
setblock 183 263 300 minecraft:white_concrete
setblock 141 264 295 minecraft:light_blue_concrete
fill 141 264 296 141 308 296 minecraft:snow_block
fill 141 264 306 141 308 306 minecraft:snow_block
setblock 141 264 307 minecraft:white_concrete
fill 141 264 309 141 275 310 minecraft:snow_block
setblock 141 264 311 minecraft:light_blue_concrete
fill 142 264 276 144 264 276 minecraft:packed_ice
setblock 142 264 279 minecraft:snow_block
fill 142 264 280 142 267 280 minecraft:packed_ice
setblock 142 264 294 minecraft:snow_block
fill 142 264 295 142 267 295 minecraft:packed_ice
setblock 142 264 298 minecraft:packed_ice
setblock 142 264 299 minecraft:snow_block
fill 142 264 300 142 264 303 minecraft:packed_ice
setblock 142 264 304 minecraft:snow_block
fill 142 264 305 142 267 305 minecraft:packed_ice
setblock 142 264 309 minecraft:snow_block
fill 142 264 310 142 267 310 minecraft:packed_ice
setblock 142 264 314 minecraft:snow_block
fill 142 264 315 142 267 315 minecraft:packed_ice
setblock 143 264 277 minecraft:packed_ice
setblock 143 264 278 minecraft:snow_block
setblock 143 264 293 minecraft:snow_block
fill 143 264 294 143 267 294 minecraft:packed_ice
setblock 143 264 297 minecraft:packed_ice
setblock 143 264 298 minecraft:snow_block
fill 143 264 299 143 264 302 minecraft:packed_ice
setblock 143 264 303 minecraft:snow_block
fill 143 264 304 144 266 304 minecraft:packed_ice
setblock 143 264 307 minecraft:packed_ice
setblock 143 264 308 minecraft:snow_block
fill 143 264 309 143 267 309 minecraft:packed_ice
setblock 143 264 313 minecraft:snow_block
fill 143 264 314 143 266 314 minecraft:packed_ice
setblock 144 264 277 minecraft:snow_block
setblock 144 264 278 minecraft:light[level=15]
setblock 144 264 285 minecraft:light[level=12]
setblock 144 264 286 minecraft:light[level=15]
setblock 144 264 292 minecraft:light[level=12]
setblock 144 264 297 minecraft:snow_block
fill 144 264 298 144 267 298 minecraft:packed_ice
setblock 144 264 302 minecraft:snow_block
fill 144 264 303 145 266 303 minecraft:packed_ice
fill 144 264 305 144 265 305 minecraft:packed_ice
setblock 144 264 306 minecraft:light[level=12]
setblock 144 264 310 minecraft:light[level=15]
setblock 144 264 313 minecraft:light[level=12]
setblock 145 264 276 minecraft:snow_block
fill 145 264 277 145 267 277 minecraft:packed_ice
setblock 145 264 295 minecraft:packed_ice
setblock 145 264 296 minecraft:snow_block
fill 145 264 297 145 267 297 minecraft:packed_ice
setblock 145 264 300 minecraft:packed_ice
setblock 145 264 301 minecraft:snow_block
fill 145 264 302 145 267 302 minecraft:packed_ice
setblock 145 264 316 minecraft:snow_block
fill 146 264 276 146 267 276 minecraft:packed_ice
fill 146 264 298 146 264 299 minecraft:packed_ice
setblock 146 264 315 minecraft:snow_block
fill 146 264 316 146 267 316 minecraft:packed_ice
setblock 147 264 278 minecraft:packed_ice
setblock 147 264 314 minecraft:snow_block
fill 147 264 315 147 266 315 minecraft:packed_ice
setblock 148 264 278 minecraft:snow_block
setblock 148 264 314 minecraft:packed_ice
setblock 149 264 277 minecraft:snow_block
setblock 149 264 278 minecraft:packed_ice
setblock 150 264 276 minecraft:snow_block
fill 150 264 277 150 267 277 minecraft:packed_ice
setblock 150 264 316 minecraft:snow_block
fill 151 264 276 151 267 276 minecraft:packed_ice
setblock 151 264 278 minecraft:light[level=12]
setblock 151 264 285 minecraft:light[level=12]
setblock 151 264 292 minecraft:light[level=12]
setblock 151 264 299 minecraft:light[level=12]
setblock 151 264 306 minecraft:light[level=12]
setblock 151 264 313 minecraft:light[level=12]
setblock 151 264 315 minecraft:snow_block
fill 151 264 316 151 266 316 minecraft:packed_ice
setblock 152 264 278 minecraft:light[level=15]
setblock 152 264 286 minecraft:light[level=15]
setblock 152 264 294 minecraft:light[level=15]
setblock 152 264 302 minecraft:light[level=15]
setblock 152 264 310 minecraft:light[level=15]
setblock 154 264 277 minecraft:snow_block
setblock 155 264 276 minecraft:snow_block
fill 156 264 276 159 264 276 minecraft:packed_ice
setblock 158 264 278 minecraft:light[level=12]
setblock 158 264 285 minecraft:light[level=12]
setblock 158 264 292 minecraft:light[level=12]
setblock 158 264 299 minecraft:light[level=12]
setblock 158 264 306 minecraft:light[level=12]
setblock 158 264 313 minecraft:light[level=12]
setblock 159 264 277 minecraft:snow_block
setblock 160 264 276 minecraft:snow_block
fill 160 264 277 160 267 277 minecraft:packed_ice
setblock 160 264 278 minecraft:light[level=15]
setblock 160 264 286 minecraft:light[level=15]
setblock 160 264 302 minecraft:light[level=15]
setblock 160 264 310 minecraft:light[level=15]
fill 161 264 276 161 267 276 minecraft:packed_ice
fill 161 264 316 161 265 316 minecraft:packed_ice
setblock 162 264 278 minecraft:packed_ice
setblock 163 264 277 minecraft:packed_ice
setblock 163 264 278 minecraft:snow_block
setblock 164 264 277 minecraft:snow_block
fill 164 264 278 164 267 278 minecraft:packed_ice
setblock 165 264 276 minecraft:snow_block
fill 165 264 277 165 267 277 minecraft:packed_ice
fill 165 264 279 166 264 279 minecraft:packed_ice
setblock 165 264 285 minecraft:light[level=12]
setblock 165 264 292 minecraft:light[level=12]
setblock 165 264 299 minecraft:light[level=12]
setblock 165 264 306 minecraft:light[level=12]
setblock 165 264 313 minecraft:light[level=12]
setblock 165 264 316 minecraft:snow_block
fill 166 264 276 166 267 276 minecraft:packed_ice
setblock 166 264 315 minecraft:snow_block
fill 166 264 316 166 267 316 minecraft:packed_ice
setblock 167 264 279 minecraft:snow_block
fill 167 264 315 167 267 315 minecraft:packed_ice
setblock 168 264 278 minecraft:snow_block
fill 168 264 279 168 267 279 minecraft:packed_ice
setblock 168 264 286 minecraft:light[level=15]
setblock 168 264 294 minecraft:light[level=15]
setblock 168 264 302 minecraft:light[level=15]
setblock 168 264 310 minecraft:light[level=15]
setblock 169 264 277 minecraft:snow_block
fill 169 264 278 169 267 278 minecraft:packed_ice
setblock 170 264 276 minecraft:snow_block
fill 170 264 277 170 267 277 minecraft:packed_ice
setblock 170 264 316 minecraft:snow_block
fill 171 264 276 171 267 276 minecraft:packed_ice
setblock 171 264 315 minecraft:snow_block
fill 171 264 316 171 267 316 minecraft:packed_ice
setblock 172 264 279 minecraft:snow_block
setblock 172 264 285 minecraft:light[level=12]
setblock 172 264 292 minecraft:light[level=12]
setblock 172 264 299 minecraft:light[level=12]
setblock 172 264 306 minecraft:light[level=12]
setblock 172 264 313 minecraft:light[level=12]
fill 172 264 315 172 266 315 minecraft:packed_ice
setblock 173 264 278 minecraft:snow_block
setblock 174 264 277 minecraft:snow_block
fill 174 264 278 174 266 278 minecraft:packed_ice
setblock 175 264 276 minecraft:snow_block
fill 175 264 277 175 267 277 minecraft:packed_ice
setblock 175 264 316 minecraft:snow_block
fill 176 264 276 176 267 276 minecraft:packed_ice
setblock 176 264 286 minecraft:light[level=15]
setblock 176 264 294 minecraft:light[level=15]
setblock 176 264 302 minecraft:light[level=15]
setblock 176 264 310 minecraft:light[level=15]
setblock 176 264 315 minecraft:snow_block
fill 176 264 316 176 267 316 minecraft:packed_ice
setblock 177 264 315 minecraft:packed_ice
setblock 179 264 277 minecraft:snow_block
setblock 179 264 278 minecraft:light[level=12]
fill 179 264 279 180 264 280 minecraft:blue_ice
setblock 179 264 285 minecraft:light[level=12]
fill 179 264 292 179 270 292 minecraft:packed_ice
setblock 179 264 299 minecraft:light[level=12]
setblock 179 264 306 minecraft:light[level=12]
setblock 179 264 313 minecraft:light[level=12]
setblock 180 264 276 minecraft:snow_block
fill 180 264 277 180 267 277 minecraft:packed_ice
setblock 180 264 316 minecraft:snow_block
fill 181 264 276 181 267 276 minecraft:packed_ice
setblock 181 264 280 minecraft:blue_ice
setblock 181 264 315 minecraft:snow_block
fill 181 264 316 181 267 316 minecraft:packed_ice
setblock 182 264 278 minecraft:packed_ice
setblock 182 264 279 minecraft:snow_block
fill 182 264 280 182 267 280 minecraft:packed_ice
fill 182 264 282 182 265 282 minecraft:packed_ice
setblock 182 264 294 minecraft:snow_block
fill 182 264 295 182 264 298 minecraft:packed_ice
setblock 182 264 299 minecraft:snow_block
fill 182 264 300 182 264 303 minecraft:packed_ice
setblock 182 264 304 minecraft:snow_block
fill 182 264 305 182 264 308 minecraft:packed_ice
setblock 182 264 309 minecraft:snow_block
fill 182 264 310 182 267 310 minecraft:packed_ice
setblock 182 264 314 minecraft:snow_block
fill 182 264 315 182 267 315 minecraft:packed_ice
fill 183 264 277 183 308 277 minecraft:snow_block
fill 183 264 300 183 308 300 minecraft:snow_block
fill 183 264 306 183 308 306 minecraft:snow_block
fill 141 265 295 141 268 295 minecraft:snow_block
fill 141 265 307 141 267 307 minecraft:snow_block
fill 141 265 311 141 308 311 minecraft:snow_block
fill 142 265 276 142 265 277 minecraft:packed_ice
setblock 142 265 278 minecraft:snow_block
fill 142 265 279 143 267 279 minecraft:packed_ice
fill 142 265 281 142 266 281 minecraft:packed_ice
setblock 142 265 293 minecraft:snow_block
fill 142 265 294 142 268 294 minecraft:packed_ice
setblock 142 265 298 minecraft:snow_block
fill 142 265 299 142 265 302 minecraft:packed_ice
setblock 142 265 303 minecraft:snow_block
fill 142 265 304 142 268 304 minecraft:packed_ice
setblock 142 265 308 minecraft:snow_block
fill 142 265 309 142 268 309 minecraft:packed_ice
setblock 142 265 313 minecraft:snow_block
fill 142 265 314 142 268 314 minecraft:packed_ice
setblock 143 265 276 minecraft:packed_ice
setblock 143 265 277 minecraft:snow_block
fill 143 265 278 143 268 278 minecraft:packed_ice
fill 143 265 293 143 266 293 minecraft:packed_ice
setblock 143 265 296 minecraft:packed_ice
setblock 143 265 297 minecraft:snow_block
fill 143 265 298 143 265 301 minecraft:packed_ice
setblock 143 265 302 minecraft:snow_block
fill 143 265 303 143 268 303 minecraft:packed_ice
setblock 143 265 307 minecraft:snow_block
fill 143 265 308 143 268 308 minecraft:packed_ice
setblock 143 265 312 minecraft:snow_block
fill 143 265 313 143 266 313 minecraft:packed_ice
setblock 144 265 276 minecraft:snow_block
fill 144 265 277 144 268 277 minecraft:packed_ice
setblock 144 265 296 minecraft:snow_block
fill 144 265 297 144 268 297 minecraft:packed_ice
setblock 144 265 300 minecraft:packed_ice
setblock 144 265 301 minecraft:snow_block
fill 144 265 302 144 268 302 minecraft:packed_ice
setblock 144 265 306 minecraft:snow_block
setblock 144 265 316 minecraft:snow_block
fill 145 265 276 145 268 276 minecraft:packed_ice
fill 145 265 296 145 266 296 minecraft:packed_ice
setblock 145 265 300 minecraft:snow_block
fill 145 265 301 145 268 301 minecraft:packed_ice
setblock 145 265 315 minecraft:snow_block
fill 145 265 316 145 268 316 minecraft:packed_ice
setblock 146 265 298 minecraft:packed_ice
setblock 146 265 299 minecraft:snow_block
fill 146 265 300 146 266 300 minecraft:packed_ice
fill 146 265 315 146 267 315 minecraft:packed_ice
setblock 147 265 278 minecraft:snow_block
setblock 148 265 277 minecraft:snow_block
setblock 148 265 278 minecraft:packed_ice
setblock 149 265 276 minecraft:snow_block
fill 149 265 277 149 267 277 minecraft:packed_ice
setblock 149 265 316 minecraft:snow_block
fill 150 265 276 150 268 276 minecraft:packed_ice
setblock 150 265 315 minecraft:snow_block
fill 150 265 316 150 267 316 minecraft:packed_ice
setblock 153 265 277 minecraft:snow_block
setblock 154 265 276 minecraft:snow_block
fill 155 265 276 158 265 276 minecraft:packed_ice
setblock 159 265 276 minecraft:snow_block
fill 159 265 277 159 268 277 minecraft:packed_ice
fill 160 265 276 160 268 276 minecraft:packed_ice
setblock 162 265 278 minecraft:snow_block
setblock 163 265 277 minecraft:snow_block
fill 163 265 278 163 268 278 minecraft:packed_ice
setblock 164 265 276 minecraft:snow_block
fill 164 265 277 164 268 277 minecraft:packed_ice
fill 164 265 279 165 265 279 minecraft:packed_ice
setblock 164 265 316 minecraft:snow_block
fill 165 265 276 165 268 276 minecraft:packed_ice
setblock 165 265 315 minecraft:snow_block
fill 165 265 316 165 268 316 minecraft:packed_ice
setblock 166 265 279 minecraft:snow_block
fill 166 265 315 166 267 315 minecraft:packed_ice
setblock 167 265 278 minecraft:snow_block
fill 167 265 279 167 272 279 minecraft:packed_ice
setblock 168 265 277 minecraft:snow_block
fill 168 265 278 168 268 278 minecraft:packed_ice
setblock 169 265 276 minecraft:snow_block
fill 169 265 277 169 268 277 minecraft:packed_ice
setblock 169 265 316 minecraft:snow_block
fill 170 265 276 170 268 276 minecraft:packed_ice
setblock 170 265 315 minecraft:snow_block
fill 170 265 316 170 268 316 minecraft:packed_ice
setblock 171 265 279 minecraft:snow_block
fill 171 265 315 171 266 315 minecraft:packed_ice
setblock 172 265 278 minecraft:snow_block
setblock 172 265 279 minecraft:packed_ice
setblock 173 265 277 minecraft:snow_block
fill 173 265 278 173 267 278 minecraft:packed_ice
setblock 174 265 276 minecraft:snow_block
fill 174 265 277 174 268 277 minecraft:packed_ice
setblock 174 265 316 minecraft:snow_block
fill 175 265 276 175 268 276 minecraft:packed_ice
setblock 175 265 315 minecraft:snow_block
fill 175 265 316 175 268 316 minecraft:packed_ice
setblock 178 265 277 minecraft:snow_block
setblock 179 265 276 minecraft:snow_block
fill 179 265 277 179 267 277 minecraft:packed_ice
setblock 179 265 316 minecraft:snow_block
fill 180 265 276 180 268 276 minecraft:packed_ice
setblock 180 265 280 minecraft:blue_ice
setblock 180 265 315 minecraft:snow_block
fill 180 265 316 180 268 316 minecraft:packed_ice
setblock 181 265 279 minecraft:snow_block
fill 181 265 280 181 268 280 minecraft:packed_ice
setblock 181 265 281 minecraft:blue_ice
setblock 181 265 314 minecraft:snow_block
fill 181 265 315 181 267 315 minecraft:packed_ice
setblock 182 265 278 minecraft:snow_block
fill 182 265 279 182 268 279 minecraft:packed_ice
fill 182 265 294 182 265 297 minecraft:packed_ice
setblock 182 265 298 minecraft:snow_block
fill 182 265 299 182 265 302 minecraft:packed_ice
setblock 182 265 303 minecraft:snow_block
fill 182 265 304 182 265 307 minecraft:packed_ice
setblock 182 265 308 minecraft:snow_block
fill 182 265 309 182 268 309 minecraft:packed_ice
setblock 182 265 313 minecraft:snow_block
fill 182 265 314 182 268 314 minecraft:packed_ice
setblock 141 266 282 minecraft:white_concrete
fill 141 266 283 141 296 284 minecraft:snow_block
setblock 142 266 276 minecraft:packed_ice
setblock 142 266 277 minecraft:snow_block
fill 142 266 278 142 269 278 minecraft:packed_ice
setblock 142 266 282 minecraft:snow_block
setblock 142 266 292 minecraft:snow_block
fill 142 266 293 142 269 293 minecraft:packed_ice
setblock 142 266 297 minecraft:snow_block
fill 142 266 298 142 266 301 minecraft:packed_ice
setblock 142 266 302 minecraft:snow_block
fill 142 266 303 142 269 303 minecraft:packed_ice
setblock 142 266 306 minecraft:packed_ice
setblock 142 266 307 minecraft:snow_block
fill 142 266 308 142 269 308 minecraft:packed_ice
setblock 142 266 312 minecraft:snow_block
fill 142 266 313 142 269 313 minecraft:packed_ice
setblock 143 266 276 minecraft:snow_block
fill 143 266 277 143 268 277 minecraft:packed_ice
setblock 143 266 280 minecraft:packed_ice
setblock 143 266 296 minecraft:snow_block
fill 143 266 297 143 266 300 minecraft:packed_ice
setblock 143 266 301 minecraft:snow_block
fill 143 266 302 143 269 302 minecraft:packed_ice
setblock 143 266 306 minecraft:snow_block
fill 143 266 307 143 269 307 minecraft:packed_ice
setblock 143 266 312 minecraft:packed_ice
setblock 143 266 316 minecraft:snow_block
fill 144 266 276 144 269 276 minecraft:packed_ice
setblock 144 266 295 minecraft:snow_block
fill 144 266 296 144 269 296 minecraft:packed_ice
setblock 144 266 299 minecraft:packed_ice
setblock 144 266 300 minecraft:snow_block
fill 144 266 301 144 269 301 minecraft:packed_ice
setblock 144 266 305 minecraft:snow_block
fill 144 266 306 144 269 306 minecraft:packed_ice
setblock 144 266 315 minecraft:snow_block
fill 144 266 316 144 269 316 minecraft:packed_ice
setblock 145 266 299 minecraft:snow_block
fill 145 266 300 145 269 300 minecraft:packed_ice
setblock 145 266 304 minecraft:snow_block
fill 145 266 315 145 267 315 minecraft:packed_ice
setblock 146 266 299 minecraft:packed_ice
setblock 147 266 277 minecraft:snow_block
setblock 148 266 276 minecraft:snow_block
fill 148 266 277 148 268 277 minecraft:packed_ice
setblock 148 266 316 minecraft:snow_block
fill 149 266 276 149 269 276 minecraft:packed_ice
fill 149 266 316 149 267 316 minecraft:packed_ice
setblock 152 266 277 minecraft:snow_block
setblock 153 266 276 minecraft:snow_block
fill 154 266 276 157 266 276 minecraft:packed_ice
setblock 158 266 276 minecraft:snow_block
fill 159 266 276 159 269 276 minecraft:packed_ice
setblock 161 266 278 minecraft:snow_block
setblock 162 266 277 minecraft:snow_block
fill 162 266 278 162 269 278 minecraft:packed_ice
setblock 163 266 276 minecraft:snow_block
fill 163 266 277 163 269 277 minecraft:packed_ice
fill 163 266 279 164 266 279 minecraft:packed_ice
setblock 163 266 316 minecraft:snow_block
fill 164 266 276 164 269 276 minecraft:packed_ice
fill 164 266 316 164 269 316 minecraft:packed_ice
setblock 165 266 279 minecraft:snow_block
setblock 165 266 315 minecraft:packed_ice
setblock 166 266 278 minecraft:snow_block
fill 166 266 279 166 269 279 minecraft:packed_ice
setblock 167 266 277 minecraft:snow_block
fill 167 266 278 167 269 278 minecraft:packed_ice
setblock 168 266 276 minecraft:snow_block
fill 168 266 277 168 269 277 minecraft:packed_ice
setblock 168 266 316 minecraft:snow_block
fill 169 266 276 169 269 276 minecraft:packed_ice
setblock 169 266 315 minecraft:snow_block
fill 169 266 316 169 269 316 minecraft:packed_ice
setblock 170 266 279 minecraft:snow_block
setblock 170 266 315 minecraft:packed_ice
setblock 171 266 278 minecraft:snow_block
setblock 171 266 279 minecraft:packed_ice
setblock 172 266 277 minecraft:snow_block
fill 172 266 278 172 268 278 minecraft:packed_ice
setblock 173 266 276 minecraft:snow_block
fill 173 266 277 173 269 277 minecraft:packed_ice
setblock 173 266 316 minecraft:snow_block
fill 174 266 276 174 269 276 minecraft:packed_ice
fill 174 266 316 174 268 316 minecraft:packed_ice
setblock 177 266 277 minecraft:snow_block
setblock 178 266 276 minecraft:snow_block
fill 178 266 277 178 267 277 minecraft:packed_ice
setblock 178 266 316 minecraft:snow_block
fill 179 266 276 179 269 276 minecraft:packed_ice
fill 179 266 287 179 272 287 minecraft:packed_ice
fill 179 266 316 179 269 316 minecraft:packed_ice
setblock 180 266 315 minecraft:packed_ice
setblock 181 266 278 minecraft:snow_block
fill 181 266 279 181 269 279 minecraft:packed_ice
fill 181 266 299 181 266 302 minecraft:packed_ice
setblock 181 266 314 minecraft:packed_ice
setblock 182 266 277 minecraft:snow_block
fill 182 266 278 182 269 278 minecraft:packed_ice
setblock 182 266 282 minecraft:snow_block
fill 182 266 283 182 269 283 minecraft:packed_ice
fill 182 266 295 182 266 296 minecraft:packed_ice
setblock 182 266 297 minecraft:snow_block
fill 182 266 298 182 266 301 minecraft:packed_ice
setblock 182 266 302 minecraft:snow_block
fill 182 266 303 182 266 306 minecraft:packed_ice
setblock 182 266 307 minecraft:snow_block
fill 182 266 308 182 269 308 minecraft:packed_ice
setblock 182 266 312 minecraft:snow_block
fill 182 266 313 182 269 313 minecraft:packed_ice
setblock 183 266 304 minecraft:light_blue_concrete
fill 141 267 282 141 308 282 minecraft:snow_block
setblock 142 267 276 minecraft:snow_block
fill 142 267 277 142 270 277 minecraft:packed_ice
setblock 142 267 281 minecraft:snow_block
fill 142 267 282 142 269 283 minecraft:packed_ice
setblock 142 267 292 minecraft:packed_ice
setblock 142 267 296 minecraft:snow_block
fill 142 267 297 142 267 300 minecraft:packed_ice
setblock 142 267 301 minecraft:snow_block
fill 142 267 302 142 270 302 minecraft:packed_ice
setblock 142 267 306 minecraft:snow_block
fill 142 267 307 142 270 307 minecraft:packed_ice
setblock 142 267 311 minecraft:snow_block
fill 142 267 312 142 270 312 minecraft:packed_ice
setblock 142 267 316 minecraft:snow_block
fill 143 267 276 143 270 276 minecraft:packed_ice
setblock 143 267 280 minecraft:snow_block
setblock 143 267 295 minecraft:snow_block
fill 143 267 296 143 267 299 minecraft:packed_ice
setblock 143 267 300 minecraft:snow_block
fill 143 267 301 143 270 301 minecraft:packed_ice
setblock 143 267 304 minecraft:packed_ice
setblock 143 267 305 minecraft:snow_block
fill 143 267 306 143 270 306 minecraft:packed_ice
setblock 143 267 315 minecraft:snow_block
fill 143 267 316 143 270 316 minecraft:packed_ice
setblock 144 267 295 minecraft:packed_ice
setblock 144 267 299 minecraft:snow_block
fill 144 267 300 144 270 300 minecraft:packed_ice
setblock 144 267 303 minecraft:packed_ice
setblock 144 267 304 minecraft:snow_block
fill 144 267 305 144 270 305 minecraft:packed_ice
setblock 144 267 315 minecraft:packed_ice
setblock 145 267 298 minecraft:snow_block
fill 145 267 299 145 269 299 minecraft:packed_ice
setblock 145 267 303 minecraft:snow_block
fill 145 267 304 145 270 304 minecraft:packed_ice
setblock 146 267 277 minecraft:snow_block
setblock 147 267 276 minecraft:snow_block
fill 147 267 277 147 268 277 minecraft:packed_ice
setblock 147 267 316 minecraft:snow_block
fill 148 267 276 148 269 276 minecraft:packed_ice
fill 148 267 316 148 268 316 minecraft:packed_ice
fill 151 267 275 151 308 275 minecraft:snow_block
setblock 152 267 275 minecraft:light_blue_concrete
setblock 152 267 276 minecraft:snow_block
fill 153 267 276 154 267 276 minecraft:packed_ice
setblock 156 267 276 minecraft:packed_ice
setblock 157 267 276 minecraft:snow_block
fill 158 267 276 158 270 276 minecraft:packed_ice
fill 161 267 275 161 307 275 minecraft:snow_block
setblock 161 267 277 minecraft:snow_block
fill 161 267 278 161 270 278 minecraft:packed_ice
setblock 162 267 275 minecraft:light_blue_concrete
setblock 162 267 276 minecraft:snow_block
fill 162 267 277 162 270 277 minecraft:packed_ice
setblock 162 267 316 minecraft:snow_block
fill 163 267 275 164 308 275 minecraft:snow_block
fill 163 267 276 163 270 276 minecraft:packed_ice
setblock 163 267 279 minecraft:packed_ice
fill 163 267 316 163 270 316 minecraft:packed_ice
setblock 164 267 279 minecraft:snow_block
setblock 165 267 278 minecraft:snow_block
fill 165 267 279 165 270 279 minecraft:packed_ice
setblock 166 267 277 minecraft:snow_block
fill 166 267 278 166 270 278 minecraft:packed_ice
setblock 167 267 276 minecraft:snow_block
fill 167 267 277 167 270 277 minecraft:packed_ice
setblock 167 267 316 minecraft:snow_block
fill 168 267 276 168 270 276 minecraft:packed_ice
setblock 168 267 315 minecraft:snow_block
fill 168 267 316 168 270 316 minecraft:packed_ice
setblock 169 267 279 minecraft:snow_block
setblock 169 267 315 minecraft:packed_ice
setblock 170 267 278 minecraft:snow_block
setblock 170 267 279 minecraft:packed_ice
setblock 171 267 277 minecraft:snow_block
fill 171 267 278 171 268 278 minecraft:packed_ice
setblock 172 267 276 minecraft:snow_block
fill 172 267 277 172 269 277 minecraft:packed_ice
setblock 172 267 316 minecraft:snow_block
fill 173 267 276 173 270 276 minecraft:packed_ice
fill 173 267 316 173 268 316 minecraft:packed_ice
setblock 176 267 277 minecraft:snow_block
setblock 177 267 276 minecraft:snow_block
setblock 177 267 277 minecraft:packed_ice
setblock 177 267 316 minecraft:snow_block
fill 178 267 276 178 270 276 minecraft:packed_ice
fill 178 267 316 178 269 316 minecraft:packed_ice
setblock 181 267 277 minecraft:snow_block
fill 181 267 278 181 269 278 minecraft:packed_ice
fill 181 267 299 181 267 301 minecraft:packed_ice
setblock 181 267 302 minecraft:snow_block
fill 181 267 303 182 268 304 minecraft:packed_ice
setblock 182 267 276 minecraft:snow_block
fill 182 267 277 182 270 277 minecraft:packed_ice
setblock 182 267 281 minecraft:snow_block
fill 182 267 282 182 270 282 minecraft:packed_ice
setblock 182 267 295 minecraft:packed_ice
setblock 182 267 296 minecraft:snow_block
fill 182 267 297 182 267 300 minecraft:packed_ice
setblock 182 267 301 minecraft:snow_block
fill 182 267 302 182 270 302 minecraft:packed_ice
setblock 182 267 305 minecraft:packed_ice
setblock 182 267 306 minecraft:snow_block
fill 182 267 307 182 270 307 minecraft:packed_ice
setblock 182 267 311 minecraft:snow_block
fill 182 267 312 182 270 312 minecraft:packed_ice
setblock 182 267 316 minecraft:snow_block
fill 183 267 304 183 308 304 minecraft:snow_block
setblock 141 268 292 minecraft:white_concrete
setblock 141 268 307 minecraft:light_blue_concrete
fill 142 268 276 142 270 276 minecraft:packed_ice
setblock 142 268 279 minecraft:packed_ice
setblock 142 268 280 minecraft:snow_block
fill 142 268 281 143 270 281 minecraft:packed_ice
setblock 142 268 284 minecraft:packed_ice
setblock 142 268 295 minecraft:snow_block
fill 142 268 296 142 268 299 minecraft:packed_ice
setblock 142 268 300 minecraft:snow_block
fill 142 268 301 142 271 301 minecraft:packed_ice
setblock 142 268 305 minecraft:snow_block
fill 142 268 306 142 271 306 minecraft:packed_ice
setblock 142 268 310 minecraft:snow_block
fill 142 268 311 142 271 311 minecraft:packed_ice
setblock 142 268 315 minecraft:snow_block
fill 142 268 316 142 270 316 minecraft:packed_ice
setblock 143 268 279 minecraft:snow_block
fill 143 268 280 143 271 280 minecraft:packed_ice
setblock 143 268 294 minecraft:snow_block
fill 143 268 295 143 268 298 minecraft:packed_ice
setblock 143 268 299 minecraft:snow_block
fill 143 268 300 143 271 300 minecraft:packed_ice
setblock 143 268 304 minecraft:snow_block
fill 143 268 305 143 271 305 minecraft:packed_ice
setblock 143 268 309 minecraft:snow_block
setblock 144 268 298 minecraft:snow_block
fill 144 268 299 144 271 299 minecraft:packed_ice
setblock 144 268 303 minecraft:snow_block
fill 144 268 304 144 271 304 minecraft:packed_ice
setblock 145 268 277 minecraft:snow_block
setblock 145 268 298 minecraft:packed_ice
setblock 145 268 302 minecraft:snow_block
fill 145 268 303 145 271 303 minecraft:packed_ice
setblock 146 268 276 minecraft:snow_block
setblock 146 268 277 minecraft:packed_ice
setblock 146 268 316 minecraft:snow_block
fill 147 268 276 147 270 276 minecraft:packed_ice
setblock 147 268 316 minecraft:packed_ice
setblock 151 268 276 minecraft:snow_block
fill 152 268 275 152 283 275 minecraft:snow_block
setblock 160 268 277 minecraft:snow_block
setblock 161 268 276 minecraft:snow_block
fill 161 268 277 161 271 277 minecraft:packed_ice
fill 162 268 275 162 308 275 minecraft:snow_block
fill 162 268 276 162 271 276 minecraft:packed_ice
setblock 163 268 279 minecraft:snow_block
setblock 164 268 278 minecraft:snow_block
fill 164 268 279 164 271 279 minecraft:packed_ice
setblock 165 268 277 minecraft:snow_block
fill 165 268 278 165 271 278 minecraft:packed_ice
fill 166 268 275 166 268 276 minecraft:snow_block
fill 166 268 277 166 271 277 minecraft:packed_ice
setblock 166 268 316 minecraft:snow_block
fill 167 268 275 168 269 275 minecraft:snow_block
fill 167 268 276 167 271 276 minecraft:packed_ice
fill 167 268 316 167 271 316 minecraft:packed_ice
setblock 168 268 279 minecraft:snow_block
setblock 169 268 275 minecraft:white_concrete
setblock 169 268 278 minecraft:snow_block
setblock 169 268 279 minecraft:packed_ice
setblock 170 268 277 minecraft:snow_block
fill 170 268 278 170 269 278 minecraft:packed_ice
setblock 171 268 276 minecraft:snow_block
fill 171 268 277 171 270 277 minecraft:packed_ice
setblock 171 268 316 minecraft:snow_block
fill 172 268 276 172 271 276 minecraft:packed_ice
setblock 172 268 316 minecraft:packed_ice
setblock 175 268 277 minecraft:snow_block
setblock 176 268 276 minecraft:snow_block
setblock 176 268 316 minecraft:snow_block
fill 177 268 276 177 270 276 minecraft:packed_ice
setblock 177 268 316 minecraft:packed_ice
setblock 180 268 277 minecraft:snow_block
setblock 181 268 276 minecraft:snow_block
fill 181 268 277 181 269 277 minecraft:packed_ice
fill 181 268 299 181 268 300 minecraft:packed_ice
setblock 181 268 301 minecraft:snow_block
fill 181 268 302 181 271 302 minecraft:packed_ice
setblock 181 268 305 minecraft:packed_ice
setblock 181 268 306 minecraft:snow_block
setblock 181 268 316 minecraft:snow_block
fill 182 268 276 182 271 276 minecraft:packed_ice
setblock 182 268 280 minecraft:snow_block
fill 182 268 281 182 271 281 minecraft:packed_ice
fill 182 268 296 182 268 299 minecraft:packed_ice
setblock 182 268 300 minecraft:snow_block
fill 182 268 301 182 271 301 minecraft:packed_ice
setblock 182 268 305 minecraft:snow_block
fill 182 268 306 182 271 306 minecraft:packed_ice
setblock 182 268 310 minecraft:snow_block
fill 182 268 311 182 271 311 minecraft:packed_ice
setblock 182 268 315 minecraft:snow_block
fill 182 268 316 182 271 316 minecraft:packed_ice
fill 141 269 292 141 308 292 minecraft:snow_block
setblock 141 269 295 minecraft:light_blue_concrete
fill 141 269 307 141 308 307 minecraft:snow_block
setblock 142 269 279 minecraft:snow_block
fill 142 269 280 142 272 280 minecraft:packed_ice
setblock 142 269 284 minecraft:snow_block
fill 142 269 285 142 272 285 minecraft:packed_ice
setblock 142 269 294 minecraft:snow_block
fill 142 269 295 142 269 298 minecraft:packed_ice
setblock 142 269 299 minecraft:snow_block
fill 142 269 300 142 272 300 minecraft:packed_ice
setblock 142 269 304 minecraft:snow_block
fill 142 269 305 142 272 305 minecraft:packed_ice
setblock 142 269 309 minecraft:snow_block
fill 142 269 310 142 272 310 minecraft:packed_ice
setblock 142 269 314 minecraft:snow_block
setblock 142 269 315 minecraft:packed_ice
setblock 143 269 279 minecraft:packed_ice
fill 143 269 295 143 269 297 minecraft:packed_ice
setblock 143 269 298 minecraft:snow_block
fill 143 269 299 143 272 299 minecraft:packed_ice
setblock 143 269 303 minecraft:snow_block
fill 143 269 304 143 272 304 minecraft:packed_ice
setblock 143 269 308 minecraft:snow_block
fill 143 269 309 143 272 309 minecraft:packed_ice
setblock 144 269 297 minecraft:snow_block
fill 144 269 298 144 272 298 minecraft:packed_ice
setblock 144 269 302 minecraft:snow_block
fill 144 269 303 144 272 303 minecraft:packed_ice
setblock 144 269 307 minecraft:snow_block
setblock 145 269 276 minecraft:snow_block
setblock 145 269 301 minecraft:snow_block
fill 145 269 302 145 272 302 minecraft:packed_ice
setblock 145 269 316 minecraft:snow_block
fill 146 269 276 146 270 276 minecraft:packed_ice
setblock 146 269 316 minecraft:packed_ice
fill 157 269 317 159 308 317 minecraft:snow_block
setblock 160 269 276 minecraft:snow_block
fill 160 269 277 160 272 277 minecraft:packed_ice
fill 160 269 289 161 269 290 minecraft:blue_ice
setblock 160 269 317 minecraft:light_blue_concrete
fill 161 269 276 161 272 276 minecraft:packed_ice
fill 161 269 288 165 269 288 minecraft:blue_ice
fill 161 269 317 163 275 317 minecraft:snow_block
fill 162 269 287 164 269 287 minecraft:blue_ice
setblock 163 269 278 minecraft:snow_block
fill 163 269 279 163 272 279 minecraft:packed_ice
setblock 164 269 277 minecraft:snow_block
fill 164 269 278 164 272 278 minecraft:packed_ice
fill 164 269 292 165 269 292 minecraft:blue_ice
setblock 165 269 276 minecraft:snow_block
fill 165 269 277 165 272 277 minecraft:packed_ice
fill 165 269 289 165 270 291 minecraft:blue_ice
setblock 165 269 316 minecraft:snow_block
fill 166 269 275 166 308 275 minecraft:snow_block
fill 166 269 276 166 272 276 minecraft:packed_ice
fill 166 269 316 166 272 316 minecraft:packed_ice
setblock 168 269 278 minecraft:snow_block
setblock 168 269 279 minecraft:packed_ice
fill 169 269 275 169 308 275 minecraft:snow_block
setblock 169 269 277 minecraft:snow_block
fill 169 269 278 169 270 278 minecraft:packed_ice
setblock 170 269 276 minecraft:snow_block
fill 170 269 277 170 271 277 minecraft:packed_ice
setblock 170 269 316 minecraft:snow_block
fill 171 269 276 171 272 276 minecraft:packed_ice
setblock 171 269 316 minecraft:packed_ice
fill 174 269 281 175 269 283 minecraft:blue_ice
setblock 175 269 276 minecraft:snow_block
fill 175 269 279 176 269 280 minecraft:blue_ice
fill 175 269 284 180 269 284 minecraft:blue_ice
fill 176 269 276 176 270 276 minecraft:packed_ice
fill 176 269 285 179 269 285 minecraft:blue_ice
fill 177 269 279 179 269 279 minecraft:blue_ice
fill 178 269 280 180 269 280 minecraft:blue_ice
fill 178 269 292 178 270 292 minecraft:packed_ice
fill 178 269 297 178 271 297 minecraft:packed_ice
fill 179 269 281 180 270 281 minecraft:blue_ice
fill 179 269 283 180 270 283 minecraft:blue_ice
fill 179 269 291 179 270 291 minecraft:packed_ice
fill 179 269 293 179 270 293 minecraft:packed_ice
fill 179 269 296 179 271 296 minecraft:packed_ice
fill 179 269 298 179 271 298 minecraft:packed_ice
setblock 180 269 276 minecraft:snow_block
fill 180 269 282 181 269 282 minecraft:blue_ice
fill 180 269 292 180 270 292 minecraft:packed_ice
fill 180 269 297 180 271 297 minecraft:packed_ice
setblock 180 269 316 minecraft:snow_block
fill 181 269 276 181 272 276 minecraft:packed_ice
setblock 181 269 280 minecraft:snow_block
setblock 181 269 300 minecraft:snow_block
fill 181 269 301 181 272 301 minecraft:packed_ice
fill 181 269 303 181 269 304 minecraft:packed_ice
setblock 181 269 305 minecraft:snow_block
fill 181 269 306 181 271 307 minecraft:packed_ice
fill 181 269 316 181 272 316 minecraft:packed_ice
setblock 182 269 279 minecraft:snow_block
fill 182 269 280 182 272 280 minecraft:packed_ice
setblock 182 269 284 minecraft:snow_block
fill 182 269 296 182 269 298 minecraft:packed_ice
setblock 182 269 299 minecraft:snow_block
fill 182 269 300 182 272 300 minecraft:packed_ice
setblock 182 269 303 minecraft:packed_ice
setblock 182 269 304 minecraft:snow_block
fill 182 269 305 182 272 305 minecraft:packed_ice
setblock 182 269 309 minecraft:snow_block
fill 182 269 310 182 272 310 minecraft:packed_ice
setblock 182 269 314 minecraft:snow_block
fill 182 269 315 182 272 315 minecraft:packed_ice
fill 141 270 295 141 299 295 minecraft:snow_block
setblock 142 270 278 minecraft:snow_block
fill 142 270 279 142 272 279 minecraft:packed_ice
setblock 142 270 282 minecraft:packed_ice
setblock 142 270 283 minecraft:snow_block
fill 142 270 284 142 272 284 minecraft:packed_ice
fill 142 270 286 142 271 286 minecraft:packed_ice
setblock 142 270 293 minecraft:snow_block
fill 142 270 294 142 270 297 minecraft:packed_ice
setblock 142 270 298 minecraft:snow_block
fill 142 270 299 142 272 299 minecraft:packed_ice
setblock 142 270 303 minecraft:snow_block
fill 142 270 304 142 272 304 minecraft:packed_ice
setblock 142 270 308 minecraft:snow_block
fill 142 270 309 142 272 309 minecraft:packed_ice
setblock 142 270 313 minecraft:snow_block
setblock 143 270 282 minecraft:snow_block
fill 143 270 283 143 272 283 minecraft:packed_ice
fill 143 270 295 143 270 296 minecraft:packed_ice
setblock 143 270 297 minecraft:snow_block
fill 143 270 298 143 272 298 minecraft:packed_ice
setblock 143 270 302 minecraft:snow_block
fill 143 270 303 143 272 303 minecraft:packed_ice
setblock 143 270 307 minecraft:snow_block
fill 143 270 308 143 272 308 minecraft:packed_ice
setblock 144 270 276 minecraft:snow_block
setblock 144 270 278 minecraft:light[level=12]
setblock 144 270 285 minecraft:light[level=12]
setblock 144 270 292 minecraft:light[level=12]
fill 144 270 297 144 271 297 minecraft:packed_ice
setblock 144 270 301 minecraft:snow_block
fill 144 270 302 144 272 302 minecraft:packed_ice
setblock 144 270 306 minecraft:snow_block
fill 144 270 307 144 272 307 minecraft:packed_ice
setblock 144 270 313 minecraft:light[level=12]
setblock 144 270 316 minecraft:snow_block
fill 145 270 276 145 271 276 minecraft:packed_ice
setblock 145 270 300 minecraft:snow_block
fill 145 270 301 145 271 301 minecraft:packed_ice
setblock 151 270 278 minecraft:light[level=12]
setblock 151 270 285 minecraft:light[level=12]
setblock 151 270 292 minecraft:light[level=12]
setblock 151 270 299 minecraft:light[level=12]
setblock 151 270 306 minecraft:light[level=12]
setblock 151 270 313 minecraft:light[level=12]
fill 158 270 277 159 271 278 minecraft:blue_ice
setblock 158 270 285 minecraft:light[level=12]
setblock 158 270 292 minecraft:light[level=12]
setblock 158 270 299 minecraft:light[level=12]
setblock 158 270 306 minecraft:light[level=12]
setblock 158 270 313 minecraft:light[level=12]
setblock 159 270 276 minecraft:snow_block
fill 159 270 279 159 271 280 minecraft:blue_ice
fill 160 270 276 160 272 276 minecraft:packed_ice
fill 160 270 278 160 271 278 minecraft:blue_ice
fill 160 270 290 161 270 290 minecraft:blue_ice
fill 160 270 317 160 308 317 minecraft:snow_block
fill 161 270 288 161 270 289 minecraft:blue_ice
setblock 162 270 278 minecraft:snow_block
fill 162 270 288 164 270 288 minecraft:blue_ice
setblock 163 270 277 minecraft:snow_block
fill 163 270 278 163 272 278 minecraft:packed_ice
setblock 164 270 276 minecraft:snow_block
fill 164 270 277 164 272 277 minecraft:packed_ice
setblock 164 270 292 minecraft:blue_ice
setblock 164 270 316 minecraft:snow_block
fill 165 270 276 165 272 276 minecraft:packed_ice
setblock 165 270 285 minecraft:light[level=12]
setblock 165 270 292 minecraft:light[level=12]
setblock 165 270 299 minecraft:light[level=12]
setblock 165 270 306 minecraft:light[level=12]
setblock 165 270 313 minecraft:light[level=12]
fill 165 270 316 165 272 316 minecraft:packed_ice
setblock 166 270 279 minecraft:snow_block
setblock 167 270 275 minecraft:white_concrete
setblock 167 270 278 minecraft:snow_block
fill 168 270 275 168 308 275 minecraft:snow_block
setblock 168 270 277 minecraft:snow_block
fill 168 270 278 168 271 278 minecraft:packed_ice
setblock 169 270 276 minecraft:snow_block
fill 169 270 277 169 272 277 minecraft:packed_ice
setblock 169 270 316 minecraft:snow_block
fill 170 270 276 170 272 276 minecraft:packed_ice
setblock 172 270 278 minecraft:light[level=12]
setblock 172 270 285 minecraft:light[level=12]
setblock 172 270 292 minecraft:light[level=12]
setblock 172 270 299 minecraft:light[level=12]
setblock 172 270 306 minecraft:light[level=12]
setblock 172 270 313 minecraft:light[level=12]
setblock 174 270 276 minecraft:snow_block
setblock 175 270 276 minecraft:packed_ice
fill 175 270 280 175 270 284 minecraft:blue_ice
fill 176 270 280 176 271 280 minecraft:blue_ice
fill 176 270 284 179 270 284 minecraft:blue_ice
fill 177 270 279 178 270 279 minecraft:blue_ice
fill 177 270 285 178 270 285 minecraft:blue_ice
fill 178 270 280 179 270 280 minecraft:blue_ice
setblock 179 270 276 minecraft:snow_block
setblock 179 270 278 minecraft:light[level=12]
setblock 179 270 285 minecraft:light[level=12]
setblock 179 270 299 minecraft:light[level=12]
setblock 179 270 306 minecraft:light[level=12]
setblock 179 270 313 minecraft:light[level=12]
setblock 179 270 316 minecraft:snow_block
fill 180 270 276 180 272 276 minecraft:packed_ice
setblock 180 270 282 minecraft:blue_ice
fill 180 270 316 180 272 316 minecraft:packed_ice
setblock 181 270 279 minecraft:snow_block
fill 181 270 300 181 272 300 minecraft:packed_ice
setblock 181 270 303 minecraft:packed_ice
setblock 181 270 304 minecraft:snow_block
fill 181 270 305 181 272 305 minecraft:packed_ice
setblock 181 270 308 minecraft:packed_ice
setblock 182 270 278 minecraft:snow_block
fill 182 270 279 182 272 279 minecraft:packed_ice
setblock 182 270 283 minecraft:snow_block
fill 182 270 284 182 272 284 minecraft:packed_ice
fill 182 270 296 182 270 297 minecraft:packed_ice
setblock 182 270 298 minecraft:snow_block
fill 182 270 299 182 272 299 minecraft:packed_ice
setblock 182 270 303 minecraft:snow_block
fill 182 270 304 182 272 304 minecraft:packed_ice
setblock 182 270 308 minecraft:snow_block
fill 182 270 309 182 272 309 minecraft:packed_ice
setblock 182 270 313 minecraft:snow_block
fill 182 270 314 182 272 314 minecraft:packed_ice
setblock 142 271 277 minecraft:snow_block
fill 142 271 278 142 272 278 minecraft:packed_ice
setblock 142 271 281 minecraft:packed_ice
setblock 142 271 282 minecraft:snow_block
fill 142 271 283 142 272 283 minecraft:packed_ice
setblock 142 271 287 minecraft:snow_block
fill 142 271 288 142 271 291 minecraft:packed_ice
setblock 142 271 292 minecraft:snow_block
fill 142 271 293 142 271 296 minecraft:packed_ice
setblock 142 271 297 minecraft:snow_block
fill 142 271 298 142 272 298 minecraft:packed_ice
setblock 142 271 302 minecraft:snow_block
fill 142 271 303 142 272 303 minecraft:packed_ice
setblock 142 271 307 minecraft:snow_block
fill 142 271 308 142 272 308 minecraft:packed_ice
setblock 142 271 312 minecraft:snow_block
fill 142 271 313 142 272 313 minecraft:packed_ice
setblock 143 271 276 minecraft:snow_block
setblock 143 271 281 minecraft:snow_block
fill 143 271 282 143 272 282 minecraft:packed_ice
fill 143 271 284 143 271 285 minecraft:packed_ice
setblock 143 271 295 minecraft:packed_ice
setblock 143 271 296 minecraft:snow_block
fill 143 271 297 143 272 297 minecraft:packed_ice
setblock 143 271 301 minecraft:snow_block
fill 143 271 302 143 272 302 minecraft:packed_ice
setblock 143 271 306 minecraft:snow_block
fill 143 271 307 143 272 307 minecraft:packed_ice
setblock 143 271 310 minecraft:packed_ice
setblock 144 271 276 minecraft:packed_ice
setblock 144 271 300 minecraft:snow_block
fill 144 271 301 144 272 301 minecraft:packed_ice
setblock 144 271 305 minecraft:snow_block
fill 144 271 306 144 272 306 minecraft:packed_ice
setblock 145 271 304 minecraft:snow_block
fill 146 271 302 147 272 302 minecraft:snow_block
fill 153 271 317 153 283 317 minecraft:snow_block
setblock 154 271 317 minecraft:light_blue_concrete
fill 155 271 317 155 277 317 minecraft:snow_block
setblock 158 271 276 minecraft:snow_block
setblock 158 271 279 minecraft:blue_ice
fill 159 271 276 159 272 276 minecraft:packed_ice
fill 159 271 281 159 271 282 minecraft:blue_ice
setblock 160 271 279 minecraft:blue_ice
setblock 161 271 278 minecraft:snow_block
fill 161 271 289 161 271 290 minecraft:blue_ice
setblock 162 271 277 minecraft:snow_block
fill 162 271 278 162 272 278 minecraft:packed_ice
fill 162 271 288 163 271 288 minecraft:blue_ice
setblock 163 271 276 minecraft:snow_block
fill 163 271 277 163 272 277 minecraft:packed_ice
setblock 163 271 316 minecraft:snow_block
fill 164 271 276 164 272 276 minecraft:packed_ice
fill 164 271 316 164 272 316 minecraft:packed_ice
setblock 165 271 279 minecraft:snow_block
setblock 166 271 278 minecraft:snow_block
fill 166 271 279 166 272 279 minecraft:packed_ice
fill 167 271 275 167 308 275 minecraft:snow_block
setblock 167 271 277 minecraft:snow_block
fill 167 271 278 167 272 278 minecraft:packed_ice
fill 167 271 280 167 272 280 minecraft:packed_ice
setblock 168 271 276 minecraft:snow_block
fill 168 271 277 168 272 277 minecraft:packed_ice
fill 168 271 279 168 272 279 minecraft:packed_ice
setblock 168 271 316 minecraft:snow_block
fill 169 271 276 169 272 276 minecraft:packed_ice
setblock 173 271 276 minecraft:snow_block
setblock 175 271 275 minecraft:light_blue_concrete
fill 175 271 281 175 271 283 minecraft:blue_ice
fill 176 271 284 178 271 284 minecraft:blue_ice
setblock 178 271 280 minecraft:blue_ice
fill 178 271 287 178 272 287 minecraft:packed_ice
fill 179 271 276 179 272 276 minecraft:packed_ice
setblock 179 271 281 minecraft:blue_ice
setblock 179 271 283 minecraft:blue_ice
fill 179 271 286 179 272 286 minecraft:packed_ice
fill 179 271 288 179 272 288 minecraft:packed_ice
fill 179 271 316 179 272 316 minecraft:packed_ice
fill 180 271 287 180 272 287 minecraft:packed_ice
fill 181 271 299 181 272 299 minecraft:packed_ice
setblock 181 271 303 minecraft:snow_block
fill 181 271 304 181 272 304 minecraft:packed_ice
setblock 181 271 308 minecraft:snow_block
fill 181 271 309 181 272 310 minecraft:packed_ice
setblock 182 271 277 minecraft:snow_block
fill 182 271 278 182 272 278 minecraft:packed_ice
setblock 182 271 282 minecraft:snow_block
fill 182 271 283 182 272 283 minecraft:packed_ice
fill 182 271 285 182 272 285 minecraft:packed_ice
setblock 182 271 296 minecraft:packed_ice
setblock 182 271 297 minecraft:snow_block
fill 182 271 298 182 272 298 minecraft:packed_ice
setblock 182 271 302 minecraft:snow_block
fill 182 271 303 182 272 303 minecraft:packed_ice
setblock 182 271 307 minecraft:snow_block
fill 182 271 308 182 272 308 minecraft:packed_ice
setblock 182 271 312 minecraft:snow_block
fill 182 271 313 182 272 313 minecraft:packed_ice
fill 141 272 302 141 308 302 minecraft:snow_block
setblock 141 272 303 minecraft:light_blue_concrete
setblock 141 272 308 minecraft:white_concrete
setblock 142 272 277 minecraft:packed_ice
setblock 142 272 281 minecraft:snow_block
setblock 142 272 282 minecraft:packed_ice
setblock 142 272 286 minecraft:snow_block
fill 142 272 287 142 272 290 minecraft:packed_ice
setblock 142 272 291 minecraft:snow_block
fill 142 272 292 142 272 295 minecraft:packed_ice
setblock 142 272 296 minecraft:snow_block
setblock 142 272 297 minecraft:packed_ice
setblock 142 272 301 minecraft:snow_block
setblock 142 272 302 minecraft:packed_ice
setblock 142 272 306 minecraft:snow_block
setblock 142 272 307 minecraft:packed_ice
setblock 142 272 311 minecraft:snow_block
setblock 142 272 312 minecraft:packed_ice
setblock 143 272 280 minecraft:snow_block
setblock 143 272 281 minecraft:packed_ice
setblock 143 272 284 minecraft:packed_ice
setblock 143 272 285 minecraft:snow_block
fill 143 272 286 143 272 287 minecraft:packed_ice
setblock 143 272 295 minecraft:snow_block
setblock 143 272 296 minecraft:packed_ice
setblock 143 272 300 minecraft:snow_block
setblock 143 272 301 minecraft:packed_ice
setblock 143 272 305 minecraft:snow_block
setblock 143 272 306 minecraft:packed_ice
setblock 143 272 310 minecraft:snow_block
setblock 144 272 278 minecraft:light[level=15]
setblock 144 272 286 minecraft:light[level=15]
setblock 144 272 294 minecraft:light[level=15]
setblock 144 272 299 minecraft:snow_block
setblock 144 272 300 minecraft:packed_ice
setblock 144 272 304 minecraft:snow_block
setblock 144 272 305 minecraft:packed_ice
setblock 144 272 308 minecraft:packed_ice
setblock 144 272 310 minecraft:light[level=15]
fill 145 272 301 154 272 301 minecraft:snow_block
setblock 145 272 303 minecraft:snow_block
setblock 145 272 304 minecraft:packed_ice
setblock 146 272 275 minecraft:white_concrete
fill 148 272 302 161 272 302 minecraft:snow_block
setblock 152 272 278 minecraft:light[level=15]
setblock 152 272 286 minecraft:light[level=15]
setblock 152 272 294 minecraft:light[level=15]
setblock 152 272 310 minecraft:light[level=15]
setblock 154 272 317 minecraft:white_concrete
setblock 158 272 276 minecraft:packed_ice
setblock 159 272 277 minecraft:packed_ice
setblock 160 272 278 minecraft:light[level=15]
setblock 160 272 286 minecraft:light[level=15]
setblock 160 272 310 minecraft:light[level=15]
setblock 161 272 277 minecraft:snow_block
setblock 161 272 278 minecraft:packed_ice
setblock 162 272 276 minecraft:snow_block
setblock 162 272 277 minecraft:packed_ice
setblock 163 272 276 minecraft:packed_ice
setblock 163 272 316 minecraft:packed_ice
setblock 164 272 279 minecraft:snow_block
setblock 165 272 278 minecraft:snow_block
setblock 166 272 277 minecraft:snow_block
setblock 166 272 278 minecraft:packed_ice
setblock 167 272 276 minecraft:snow_block
setblock 167 272 277 minecraft:packed_ice
setblock 167 272 316 minecraft:snow_block
setblock 168 272 276 minecraft:packed_ice
setblock 168 272 278 minecraft:light[level=15]
setblock 168 272 286 minecraft:light[level=15]
setblock 168 272 294 minecraft:light[level=15]
setblock 168 272 302 minecraft:light[level=15]
setblock 168 272 310 minecraft:light[level=15]
fill 175 272 275 175 308 275 minecraft:snow_block
setblock 176 272 278 minecraft:light[level=15]
setblock 176 272 286 minecraft:light[level=15]
setblock 176 272 294 minecraft:light[level=15]
setblock 176 272 302 minecraft:light[level=15]
setblock 176 272 310 minecraft:light[level=15]
setblock 180 272 303 minecraft:snow_block
fill 180 272 304 180 272 306 minecraft:packed_ice
fill 181 272 280 181 272 281 minecraft:packed_ice
setblock 181 272 302 minecraft:snow_block
setblock 181 272 303 minecraft:packed_ice
setblock 181 272 306 minecraft:packed_ice
setblock 181 272 307 minecraft:snow_block
setblock 181 272 308 minecraft:packed_ice
setblock 181 272 311 minecraft:packed_ice
setblock 181 272 312 minecraft:snow_block
setblock 182 272 276 minecraft:snow_block
setblock 182 272 277 minecraft:packed_ice
setblock 182 272 281 minecraft:snow_block
setblock 182 272 282 minecraft:packed_ice
setblock 182 272 286 minecraft:snow_block
setblock 182 272 287 minecraft:packed_ice
setblock 182 272 296 minecraft:snow_block
setblock 182 272 297 minecraft:packed_ice
setblock 182 272 301 minecraft:snow_block
setblock 182 272 302 minecraft:packed_ice
setblock 182 272 306 minecraft:snow_block
setblock 182 272 307 minecraft:packed_ice
setblock 182 272 311 minecraft:snow_block
setblock 182 272 312 minecraft:packed_ice
setblock 182 272 316 minecraft:snow_block
fill 141 273 303 141 277 303 minecraft:snow_block
fill 141 273 308 141 308 308 minecraft:snow_block
fill 146 273 275 146 308 275 minecraft:snow_block
fill 154 273 317 154 308 317 minecraft:snow_block
setblock 148 274 275 minecraft:white_concrete
fill 148 275 275 148 295 275 minecraft:snow_block
fill 169 275 315 169 279 315 minecraft:packed_ice
fill 141 276 309 141 308 309 minecraft:snow_block
setblock 141 276 310 minecraft:white_concrete
setblock 144 276 278 minecraft:light[level=12]
setblock 144 276 285 minecraft:light[level=12]
setblock 144 276 292 minecraft:light[level=12]
setblock 144 276 299 minecraft:light[level=12]
setblock 144 276 306 minecraft:light[level=12]
setblock 144 276 313 minecraft:light[level=12]
setblock 151 276 278 minecraft:light[level=12]
setblock 151 276 285 minecraft:light[level=12]
setblock 151 276 292 minecraft:light[level=12]
setblock 151 276 299 minecraft:light[level=12]
setblock 151 276 306 minecraft:light[level=12]
setblock 151 276 313 minecraft:light[level=12]
setblock 158 276 278 minecraft:light[level=12]
setblock 158 276 285 minecraft:light[level=12]
setblock 158 276 292 minecraft:light[level=12]
setblock 158 276 299 minecraft:light[level=12]
setblock 158 276 306 minecraft:light[level=12]
setblock 158 276 313 minecraft:light[level=12]
setblock 161 276 317 minecraft:white_concrete
fill 162 276 317 163 303 317 minecraft:snow_block
setblock 165 276 278 minecraft:light[level=12]
setblock 165 276 285 minecraft:light[level=12]
setblock 165 276 292 minecraft:light[level=12]
setblock 165 276 299 minecraft:light[level=12]
setblock 165 276 306 minecraft:light[level=12]
setblock 165 276 313 minecraft:light[level=12]
setblock 172 276 278 minecraft:light[level=12]
setblock 172 276 285 minecraft:light[level=12]
setblock 172 276 292 minecraft:light[level=12]
setblock 172 276 299 minecraft:light[level=12]
setblock 172 276 306 minecraft:light[level=12]
setblock 172 276 313 minecraft:light[level=12]
setblock 179 276 278 minecraft:light[level=12]
setblock 179 276 285 minecraft:light[level=12]
setblock 179 276 292 minecraft:light[level=12]
setblock 179 276 299 minecraft:light[level=12]
setblock 179 276 306 minecraft:light[level=12]
setblock 179 276 313 minecraft:light[level=12]
fill 141 277 310 141 308 310 minecraft:snow_block
setblock 142 277 275 minecraft:light_blue_concrete
fill 161 277 317 161 301 317 minecraft:snow_block
setblock 183 277 280 minecraft:light_blue_concrete
setblock 183 277 298 minecraft:white_concrete
setblock 141 278 303 minecraft:white_concrete
fill 142 278 275 142 308 275 minecraft:snow_block
fill 148 278 286 148 279 287 minecraft:blue_ice
fill 148 278 301 148 279 302 minecraft:blue_ice
fill 149 278 287 150 279 287 minecraft:blue_ice
fill 149 278 301 150 279 301 minecraft:blue_ice
fill 150 278 288 152 279 288 minecraft:blue_ice
fill 150 278 291 150 279 297 minecraft:blue_ice
fill 150 278 300 152 279 300 minecraft:blue_ice
fill 151 278 289 151 279 290 minecraft:blue_ice
fill 151 278 298 151 279 299 minecraft:blue_ice
fill 152 278 287 153 279 287 minecraft:blue_ice
fill 152 278 289 153 279 289 minecraft:blue_ice
fill 152 278 299 153 279 299 minecraft:blue_ice
fill 152 278 301 153 279 301 minecraft:blue_ice
fill 153 278 286 154 279 286 minecraft:blue_ice
fill 153 278 302 154 279 302 minecraft:blue_ice
fill 154 278 285 155 279 285 minecraft:blue_ice
fill 154 278 290 154 279 290 minecraft:blue_ice
fill 154 278 298 154 279 298 minecraft:blue_ice
fill 154 278 303 155 279 303 minecraft:blue_ice
fill 155 278 292 155 279 296 minecraft:blue_ice
setblock 155 278 317 minecraft:white_concrete
fill 156 278 284 157 279 284 minecraft:blue_ice
fill 156 278 290 156 279 291 minecraft:blue_ice
fill 156 278 297 156 279 298 minecraft:blue_ice
fill 156 278 304 157 279 304 minecraft:blue_ice
fill 157 278 289 157 279 290 minecraft:blue_ice
fill 157 278 298 157 279 299 minecraft:blue_ice
fill 158 278 283 164 279 283 minecraft:blue_ice
fill 158 278 289 158 279 289 minecraft:blue_ice
setblock 158 278 293 minecraft:snow_block
setblock 158 278 295 minecraft:snow_block
fill 158 278 299 158 279 299 minecraft:blue_ice
fill 158 278 305 164 279 305 minecraft:blue_ice
fill 159 278 288 163 279 288 minecraft:blue_ice
fill 159 278 300 163 279 300 minecraft:blue_ice
setblock 160 278 291 minecraft:snow_block
setblock 160 278 297 minecraft:snow_block
fill 161 278 279 161 279 282 minecraft:blue_ice
fill 161 278 284 161 279 287 minecraft:blue_ice
fill 161 278 289 161 278 290 minecraft:blue_ice
fill 161 278 298 161 278 299 minecraft:blue_ice
fill 161 278 301 161 279 304 minecraft:blue_ice
fill 161 278 306 161 279 309 minecraft:blue_ice
setblock 162 278 291 minecraft:snow_block
setblock 162 278 297 minecraft:snow_block
fill 164 278 289 165 279 289 minecraft:blue_ice
setblock 164 278 293 minecraft:snow_block
setblock 164 278 295 minecraft:snow_block
fill 164 278 299 165 279 299 minecraft:blue_ice
fill 165 278 284 166 279 284 minecraft:blue_ice
fill 165 278 290 166 279 290 minecraft:blue_ice
fill 165 278 298 166 279 298 minecraft:blue_ice
fill 165 278 304 166 279 304 minecraft:blue_ice
fill 166 278 291 166 279 291 minecraft:blue_ice
fill 166 278 297 166 279 297 minecraft:blue_ice
fill 167 278 285 168 279 285 minecraft:blue_ice
fill 167 278 292 167 279 296 minecraft:blue_ice
fill 167 278 303 168 279 303 minecraft:blue_ice
fill 168 278 286 169 279 286 minecraft:blue_ice
fill 168 278 290 168 279 290 minecraft:blue_ice
fill 168 278 298 168 279 298 minecraft:blue_ice
fill 168 278 302 169 279 302 minecraft:blue_ice
fill 169 278 287 170 279 287 minecraft:blue_ice
fill 169 278 289 171 279 289 minecraft:blue_ice
fill 169 278 299 171 279 299 minecraft:blue_ice
fill 169 278 301 170 279 301 minecraft:blue_ice
fill 170 278 288 172 279 288 minecraft:blue_ice
fill 170 278 300 172 279 300 minecraft:blue_ice
fill 171 278 290 171 279 290 minecraft:blue_ice
fill 171 278 298 171 279 298 minecraft:blue_ice
fill 172 278 287 174 279 287 minecraft:blue_ice
fill 172 278 291 172 279 297 minecraft:blue_ice
fill 172 278 301 174 279 301 minecraft:blue_ice
fill 174 278 286 174 279 286 minecraft:blue_ice
fill 174 278 302 174 279 302 minecraft:blue_ice
fill 183 278 280 183 308 280 minecraft:snow_block
fill 183 278 298 183 308 298 minecraft:snow_block
fill 141 279 303 141 308 303 minecraft:snow_block
fill 142 279 276 182 279 277 minecraft:white_stained_glass
setblock 142 279 278 minecraft:light_blue_stained_glass
fill 142 279 279 142 279 283 minecraft:white_stained_glass
setblock 142 279 284 minecraft:light_blue_stained_glass
fill 142 279 285 142 279 289 minecraft:white_stained_glass
setblock 142 279 290 minecraft:light_blue_stained_glass
fill 142 279 291 142 279 295 minecraft:white_stained_glass
setblock 142 279 296 minecraft:light_blue_stained_glass
fill 142 279 297 142 279 301 minecraft:white_stained_glass
setblock 142 279 302 minecraft:light_blue_stained_glass
fill 142 279 303 142 279 307 minecraft:white_stained_glass
setblock 142 279 308 minecraft:light_blue_stained_glass
fill 142 279 309 142 279 313 minecraft:white_stained_glass
setblock 142 279 314 minecraft:light_blue_stained_glass
fill 142 279 315 168 279 316 minecraft:white_stained_glass
fill 143 279 278 143 279 280 minecraft:white_stained_glass
setblock 143 279 281 minecraft:light_blue_stained_glass
fill 143 279 282 143 279 286 minecraft:white_stained_glass
setblock 143 279 287 minecraft:light_blue_stained_glass
fill 143 279 288 143 279 292 minecraft:white_stained_glass
setblock 143 279 293 minecraft:light_blue_stained_glass
fill 143 279 294 143 279 298 minecraft:white_stained_glass
setblock 143 279 299 minecraft:light_blue_stained_glass
fill 143 279 300 143 279 304 minecraft:white_stained_glass
setblock 143 279 305 minecraft:light_blue_stained_glass
fill 143 279 306 143 279 310 minecraft:white_stained_glass
setblock 143 279 311 minecraft:light_blue_stained_glass
fill 143 279 312 143 279 314 minecraft:white_stained_glass
setblock 144 279 278 minecraft:light_blue_stained_glass
fill 144 279 279 144 279 283 minecraft:white_stained_glass
setblock 144 279 284 minecraft:light_blue_stained_glass
fill 144 279 285 144 279 289 minecraft:white_stained_glass
setblock 144 279 290 minecraft:light_blue_stained_glass
fill 144 279 291 144 279 295 minecraft:white_stained_glass
setblock 144 279 296 minecraft:light_blue_stained_glass
fill 144 279 297 144 279 301 minecraft:white_stained_glass
setblock 144 279 302 minecraft:light_blue_stained_glass
fill 144 279 303 144 279 307 minecraft:white_stained_glass
setblock 144 279 308 minecraft:light_blue_stained_glass
fill 144 279 309 144 279 313 minecraft:white_stained_glass
setblock 144 279 314 minecraft:light_blue_stained_glass
fill 145 279 278 145 279 280 minecraft:white_stained_glass
setblock 145 279 281 minecraft:light_blue_stained_glass
fill 145 279 282 145 279 286 minecraft:white_stained_glass
setblock 145 279 287 minecraft:light_blue_stained_glass
fill 145 279 288 145 279 292 minecraft:white_stained_glass
setblock 145 279 293 minecraft:light_blue_stained_glass
fill 145 279 294 145 279 298 minecraft:white_stained_glass
setblock 145 279 299 minecraft:light_blue_stained_glass
fill 145 279 300 145 279 304 minecraft:white_stained_glass
setblock 145 279 305 minecraft:light_blue_stained_glass
fill 145 279 306 145 279 310 minecraft:white_stained_glass
setblock 145 279 311 minecraft:light_blue_stained_glass
fill 145 279 312 145 279 314 minecraft:white_stained_glass
setblock 146 279 278 minecraft:light_blue_stained_glass
fill 146 279 279 146 279 283 minecraft:white_stained_glass
setblock 146 279 284 minecraft:light_blue_stained_glass
fill 146 279 285 146 279 289 minecraft:white_stained_glass
setblock 146 279 290 minecraft:light_blue_stained_glass
fill 146 279 291 146 279 295 minecraft:white_stained_glass
setblock 146 279 296 minecraft:light_blue_stained_glass
fill 146 279 297 146 279 301 minecraft:white_stained_glass
setblock 146 279 302 minecraft:light_blue_stained_glass
fill 146 279 303 146 279 307 minecraft:white_stained_glass
setblock 146 279 308 minecraft:light_blue_stained_glass
fill 146 279 309 146 279 313 minecraft:white_stained_glass
setblock 146 279 314 minecraft:light_blue_stained_glass
fill 147 279 278 147 279 280 minecraft:white_stained_glass
setblock 147 279 281 minecraft:light_blue_stained_glass
fill 147 279 282 147 279 286 minecraft:white_stained_glass
setblock 147 279 287 minecraft:light_blue_stained_glass
fill 147 279 288 147 279 292 minecraft:white_stained_glass
setblock 147 279 293 minecraft:light_blue_stained_glass
fill 147 279 294 147 279 298 minecraft:white_stained_glass
setblock 147 279 299 minecraft:light_blue_stained_glass
fill 147 279 300 147 279 304 minecraft:white_stained_glass
setblock 147 279 305 minecraft:light_blue_stained_glass
fill 147 279 306 147 279 310 minecraft:white_stained_glass
setblock 147 279 311 minecraft:light_blue_stained_glass
fill 147 279 312 147 279 314 minecraft:white_stained_glass
setblock 148 279 278 minecraft:light_blue_stained_glass
fill 148 279 279 148 279 283 minecraft:white_stained_glass
setblock 148 279 284 minecraft:light_blue_stained_glass
fill 148 279 285 153 279 285 minecraft:white_stained_glass
fill 148 279 288 149 279 289 minecraft:white_stained_glass
setblock 148 279 290 minecraft:light_blue_stained_glass
fill 148 279 291 148 279 295 minecraft:white_stained_glass
setblock 148 279 296 minecraft:light_blue_stained_glass
fill 148 279 297 148 279 300 minecraft:white_stained_glass
fill 148 279 303 148 279 307 minecraft:white_stained_glass
setblock 148 279 308 minecraft:light_blue_stained_glass
fill 148 279 309 148 279 313 minecraft:white_stained_glass
setblock 148 279 314 minecraft:light_blue_stained_glass
fill 149 279 278 149 279 280 minecraft:white_stained_glass
setblock 149 279 281 minecraft:light_blue_stained_glass
fill 149 279 282 149 279 284 minecraft:white_stained_glass
fill 149 279 286 152 279 286 minecraft:white_stained_glass
fill 149 279 290 149 279 292 minecraft:white_stained_glass
setblock 149 279 293 minecraft:light_blue_stained_glass
fill 149 279 294 149 279 298 minecraft:white_stained_glass
setblock 149 279 299 minecraft:light_blue_stained_glass
setblock 149 279 300 minecraft:white_stained_glass
fill 149 279 302 149 279 304 minecraft:white_stained_glass
setblock 149 279 305 minecraft:light_blue_stained_glass
fill 149 279 306 149 279 310 minecraft:white_stained_glass
setblock 149 279 311 minecraft:light_blue_stained_glass
fill 149 279 312 149 279 314 minecraft:white_stained_glass
setblock 150 279 278 minecraft:light_blue_stained_glass
fill 150 279 279 150 279 283 minecraft:white_stained_glass
setblock 150 279 284 minecraft:light_blue_stained_glass
setblock 150 279 289 minecraft:white_stained_glass
setblock 150 279 290 minecraft:light_blue_stained_glass
fill 150 279 298 150 279 299 minecraft:white_stained_glass
setblock 150 279 302 minecraft:light_blue_stained_glass
fill 150 279 303 150 279 307 minecraft:white_stained_glass
setblock 150 279 308 minecraft:light_blue_stained_glass
fill 150 279 309 150 279 313 minecraft:white_stained_glass
setblock 150 279 314 minecraft:light_blue_stained_glass
fill 151 279 278 151 279 280 minecraft:white_stained_glass
setblock 151 279 281 minecraft:light_blue_stained_glass
fill 151 279 282 151 279 284 minecraft:white_stained_glass
setblock 151 279 287 minecraft:light_blue_stained_glass
fill 151 279 291 154 279 292 minecraft:white_stained_glass
setblock 151 279 293 minecraft:light_blue_stained_glass
fill 151 279 294 151 279 297 minecraft:white_stained_glass
fill 151 279 301 151 279 304 minecraft:white_stained_glass
setblock 151 279 305 minecraft:light_blue_stained_glass
fill 151 279 306 151 279 310 minecraft:white_stained_glass
setblock 151 279 311 minecraft:light_blue_stained_glass
fill 151 279 312 151 279 314 minecraft:white_stained_glass
setblock 152 279 278 minecraft:light_blue_stained_glass
fill 152 279 279 152 279 283 minecraft:white_stained_glass
setblock 152 279 284 minecraft:light_blue_stained_glass
setblock 152 279 290 minecraft:light_blue_stained_glass
fill 152 279 293 152 279 295 minecraft:white_stained_glass
setblock 152 279 296 minecraft:light_blue_stained_glass
fill 152 279 297 153 279 298 minecraft:white_stained_glass
setblock 152 279 302 minecraft:light_blue_stained_glass
fill 152 279 303 152 279 307 minecraft:white_stained_glass
setblock 152 279 308 minecraft:light_blue_stained_glass
fill 152 279 309 152 279 313 minecraft:white_stained_glass
setblock 152 279 314 minecraft:light_blue_stained_glass
fill 153 279 278 153 279 280 minecraft:white_stained_glass
setblock 153 279 281 minecraft:light_blue_stained_glass
fill 153 279 282 153 279 284 minecraft:white_stained_glass
fill 153 279 288 158 279 288 minecraft:white_stained_glass
setblock 153 279 290 minecraft:white_stained_glass
setblock 153 279 293 minecraft:light_blue_stained_glass
fill 153 279 294 153 279 296 minecraft:white_stained_glass
fill 153 279 300 158 279 300 minecraft:white_stained_glass
fill 153 279 303 153 279 304 minecraft:white_stained_glass
setblock 153 279 305 minecraft:light_blue_stained_glass
fill 153 279 306 153 279 310 minecraft:white_stained_glass
setblock 153 279 311 minecraft:light_blue_stained_glass
fill 153 279 312 153 279 314 minecraft:white_stained_glass
setblock 154 279 278 minecraft:light_blue_stained_glass
fill 154 279 279 154 279 283 minecraft:white_stained_glass
setblock 154 279 284 minecraft:light_blue_stained_glass
setblock 154 279 287 minecraft:white_stained_glass
fill 154 279 289 156 279 289 minecraft:white_stained_glass
fill 154 279 293 154 279 295 minecraft:white_stained_glass
setblock 154 279 296 minecraft:light_blue_stained_glass
fill 154 279 297 155 279 297 minecraft:white_stained_glass
setblock 154 279 299 minecraft:white_stained_glass
fill 154 279 301 160 279 301 minecraft:white_stained_glass
fill 154 279 304 154 279 307 minecraft:white_stained_glass
setblock 154 279 308 minecraft:light_blue_stained_glass
fill 154 279 309 154 279 313 minecraft:white_stained_glass
setblock 154 279 314 minecraft:light_blue_stained_glass
fill 155 279 278 155 279 280 minecraft:white_stained_glass
setblock 155 279 281 minecraft:light_blue_stained_glass
fill 155 279 282 155 279 284 minecraft:white_stained_glass
fill 155 279 286 160 279 286 minecraft:white_stained_glass
setblock 155 279 287 minecraft:light_blue_stained_glass
fill 155 279 290 155 279 291 minecraft:white_stained_glass
setblock 155 279 298 minecraft:white_stained_glass
setblock 155 279 299 minecraft:light_blue_stained_glass
setblock 155 279 302 minecraft:white_stained_glass
setblock 155 279 304 minecraft:white_stained_glass
setblock 155 279 305 minecraft:light_blue_stained_glass
fill 155 279 306 155 279 310 minecraft:white_stained_glass
setblock 155 279 311 minecraft:light_blue_stained_glass
fill 155 279 312 155 279 314 minecraft:white_stained_glass
fill 155 279 317 155 308 317 minecraft:snow_block
setblock 156 279 278 minecraft:light_blue_stained_glass
fill 156 279 279 156 279 283 minecraft:white_stained_glass
fill 156 279 285 160 279 285 minecraft:white_stained_glass
setblock 156 279 287 minecraft:white_stained_glass
fill 156 279 292 156 279 295 minecraft:white_stained_glass
setblock 156 279 296 minecraft:light_blue_stained_glass
setblock 156 279 299 minecraft:white_stained_glass
setblock 156 279 302 minecraft:light_blue_stained_glass
fill 156 279 303 160 279 303 minecraft:white_stained_glass
fill 156 279 305 156 279 307 minecraft:white_stained_glass
setblock 156 279 308 minecraft:light_blue_stained_glass
fill 156 279 309 156 279 313 minecraft:white_stained_glass
setblock 156 279 314 minecraft:light_blue_stained_glass
fill 157 279 278 157 279 280 minecraft:white_stained_glass
setblock 157 279 281 minecraft:light_blue_stained_glass
fill 157 279 282 157 279 283 minecraft:white_stained_glass
setblock 157 279 287 minecraft:light_blue_stained_glass
fill 157 279 291 157 279 292 minecraft:white_stained_glass
fill 157 279 293 157 279 295 minecraft:sea_lantern
fill 157 279 296 157 279 297 minecraft:white_stained_glass
setblock 157 279 302 minecraft:white_stained_glass
setblock 157 279 305 minecraft:light_blue_stained_glass
fill 157 279 306 157 279 310 minecraft:white_stained_glass
setblock 157 279 311 minecraft:light_blue_stained_glass
fill 157 279 312 157 279 314 minecraft:white_stained_glass
setblock 158 279 278 minecraft:light_blue_stained_glass
fill 158 279 279 158 279 282 minecraft:white_stained_glass
setblock 158 279 284 minecraft:light_blue_stained_glass
setblock 158 279 287 minecraft:white_stained_glass
setblock 158 279 290 minecraft:light_blue_stained_glass
setblock 158 279 291 minecraft:sea_lantern
fill 158 279 292 158 279 293 minecraft:shroomlight
fill 158 279 295 158 279 296 minecraft:shroomlight
setblock 158 279 297 minecraft:sea_lantern
fill 158 279 298 159 279 298 minecraft:white_stained_glass
setblock 158 279 302 minecraft:light_blue_stained_glass
fill 158 279 304 160 279 304 minecraft:white_stained_glass
fill 158 279 306 160 279 307 minecraft:white_stained_glass
setblock 158 279 308 minecraft:light_blue_stained_glass
fill 158 279 309 158 279 313 minecraft:white_stained_glass
setblock 158 279 314 minecraft:light_blue_stained_glass
fill 159 279 278 159 279 280 minecraft:white_stained_glass
setblock 159 279 281 minecraft:light_blue_stained_glass
fill 159 279 282 160 279 282 minecraft:white_stained_glass
setblock 159 279 284 minecraft:white_stained_glass
setblock 159 279 287 minecraft:light_blue_stained_glass
fill 159 279 289 159 279 290 minecraft:white_stained_glass
fill 159 279 291 160 279 291 minecraft:shroomlight
fill 159 279 297 160 279 297 minecraft:shroomlight
setblock 159 279 299 minecraft:light_blue_stained_glass
setblock 159 279 302 minecraft:white_stained_glass
fill 159 279 308 159 279 310 minecraft:white_stained_glass
setblock 159 279 311 minecraft:light_blue_stained_glass
fill 159 279 312 159 279 314 minecraft:white_stained_glass
setblock 160 279 278 minecraft:light_blue_stained_glass
fill 160 279 279 160 279 281 minecraft:white_stained_glass
setblock 160 279 284 minecraft:light_blue_stained_glass
setblock 160 279 287 minecraft:white_stained_glass
setblock 160 279 289 minecraft:white_stained_glass
fill 160 279 290 162 279 290 minecraft:sea_lantern
fill 160 279 298 162 279 298 minecraft:sea_lantern
setblock 160 279 299 minecraft:white_stained_glass
setblock 160 279 302 minecraft:light_blue_stained_glass
setblock 160 279 308 minecraft:light_blue_stained_glass
fill 160 279 309 160 279 313 minecraft:white_stained_glass
setblock 160 279 314 minecraft:light_blue_stained_glass
setblock 161 279 278 minecraft:white_stained_glass
setblock 161 279 289 minecraft:blue_ice
setblock 161 279 299 minecraft:blue_ice
fill 161 279 310 182 279 310 minecraft:white_stained_glass
setblock 161 279 311 minecraft:light_blue_stained_glass
fill 161 279 312 161 279 314 minecraft:white_stained_glass
setblock 162 279 278 minecraft:light_blue_stained_glass
fill 162 279 279 162 279 282 minecraft:white_stained_glass
setblock 162 279 284 minecraft:light_blue_stained_glass
fill 162 279 285 162 279 287 minecraft:white_stained_glass
fill 162 279 289 163 279 289 minecraft:white_stained_glass
fill 162 279 291 163 279 291 minecraft:shroomlight
fill 162 279 297 163 279 297 minecraft:shroomlight
setblock 162 279 299 minecraft:white_stained_glass
fill 162 279 301 168 279 301 minecraft:white_stained_glass
setblock 162 279 302 minecraft:light_blue_stained_glass
fill 162 279 303 164 279 304 minecraft:white_stained_glass
fill 162 279 306 182 279 307 minecraft:white_stained_glass
setblock 162 279 308 minecraft:light_blue_stained_glass
fill 162 279 309 182 279 309 minecraft:white_stained_glass
fill 162 279 311 162 279 313 minecraft:white_stained_glass
setblock 162 279 314 minecraft:light_blue_stained_glass
fill 163 279 278 163 279 280 minecraft:white_stained_glass
setblock 163 279 281 minecraft:light_blue_stained_glass
fill 163 279 282 182 279 282 minecraft:white_stained_glass
fill 163 279 284 163 279 286 minecraft:white_stained_glass
setblock 163 279 287 minecraft:light_blue_stained_glass
setblock 163 279 290 minecraft:white_stained_glass
fill 163 279 298 164 279 298 minecraft:white_stained_glass
setblock 163 279 299 minecraft:light_blue_stained_glass
setblock 163 279 302 minecraft:white_stained_glass
setblock 163 279 308 minecraft:white_stained_glass
setblock 163 279 311 minecraft:light_blue_stained_glass
fill 163 279 312 163 279 314 minecraft:white_stained_glass
setblock 164 279 278 minecraft:light_blue_stained_glass
fill 164 279 279 164 279 281 minecraft:white_stained_glass
setblock 164 279 284 minecraft:light_blue_stained_glass
fill 164 279 285 164 279 288 minecraft:white_stained_glass
setblock 164 279 290 minecraft:light_blue_stained_glass
setblock 164 279 291 minecraft:sea_lantern
fill 164 279 292 164 279 293 minecraft:shroomlight
fill 164 279 295 164 279 296 minecraft:shroomlight
setblock 164 279 297 minecraft:sea_lantern
fill 164 279 300 169 279 300 minecraft:white_stained_glass
setblock 164 279 302 minecraft:light_blue_stained_glass
setblock 164 279 308 minecraft:light_blue_stained_glass
fill 164 279 311 164 279 313 minecraft:white_stained_glass
setblock 164 279 314 minecraft:light_blue_stained_glass
fill 165 279 278 165 279 280 minecraft:white_stained_glass
setblock 165 279 281 minecraft:light_blue_stained_glass
fill 165 279 283 182 279 283 minecraft:white_stained_glass
fill 165 279 285 166 279 286 minecraft:white_stained_glass
setblock 165 279 287 minecraft:light_blue_stained_glass
fill 165 279 288 169 279 288 minecraft:white_stained_glass
fill 165 279 291 165 279 292 minecraft:white_stained_glass
fill 165 279 293 165 279 295 minecraft:sea_lantern
fill 165 279 296 165 279 297 minecraft:white_stained_glass
fill 165 279 302 165 279 303 minecraft:white_stained_glass
setblock 165 279 305 minecraft:light_blue_stained_glass
setblock 165 279 308 minecraft:white_stained_glass
setblock 165 279 311 minecraft:light_blue_stained_glass
fill 165 279 312 165 279 314 minecraft:white_stained_glass
setblock 166 279 278 minecraft:light_blue_stained_glass
fill 166 279 279 166 279 281 minecraft:white_stained_glass
setblock 166 279 287 minecraft:white_stained_glass
fill 166 279 289 168 279 289 minecraft:white_stained_glass
fill 166 279 292 166 279 295 minecraft:white_stained_glass
setblock 166 279 296 minecraft:light_blue_stained_glass
setblock 166 279 299 minecraft:white_stained_glass
setblock 166 279 302 minecraft:light_blue_stained_glass
setblock 166 279 303 minecraft:white_stained_glass
setblock 166 279 305 minecraft:white_stained_glass
setblock 166 279 308 minecraft:light_blue_stained_glass
fill 166 279 311 166 279 313 minecraft:white_stained_glass
setblock 166 279 314 minecraft:light_blue_stained_glass
fill 167 279 278 167 279 280 minecraft:white_stained_glass
setblock 167 279 281 minecraft:light_blue_stained_glass
setblock 167 279 284 minecraft:white_stained_glass
setblock 167 279 286 minecraft:white_stained_glass
setblock 167 279 287 minecraft:light_blue_stained_glass
fill 167 279 290 167 279 291 minecraft:white_stained_glass
fill 167 279 297 167 279 298 minecraft:white_stained_glass
setblock 167 279 299 minecraft:light_blue_stained_glass
setblock 167 279 302 minecraft:white_stained_glass
fill 167 279 304 182 279 304 minecraft:white_stained_glass
setblock 167 279 305 minecraft:light_blue_stained_glass
setblock 167 279 308 minecraft:white_stained_glass
setblock 167 279 311 minecraft:light_blue_stained_glass
fill 167 279 312 167 279 314 minecraft:white_stained_glass
setblock 168 279 278 minecraft:light_blue_stained_glass
fill 168 279 279 168 279 281 minecraft:white_stained_glass
setblock 168 279 284 minecraft:light_blue_stained_glass
setblock 168 279 287 minecraft:white_stained_glass
fill 168 279 291 168 279 295 minecraft:white_stained_glass
setblock 168 279 296 minecraft:light_blue_stained_glass
fill 168 279 297 171 279 297 minecraft:white_stained_glass
setblock 168 279 299 minecraft:white_stained_glass
setblock 168 279 305 minecraft:white_stained_glass
setblock 168 279 308 minecraft:light_blue_stained_glass
fill 168 279 311 168 279 313 minecraft:white_stained_glass
setblock 168 279 314 minecraft:light_blue_stained_glass
fill 169 279 278 169 279 280 minecraft:white_stained_glass
setblock 169 279 281 minecraft:light_blue_stained_glass
fill 169 279 284 169 279 285 minecraft:white_stained_glass
fill 169 279 290 169 279 292 minecraft:white_stained_glass
setblock 169 279 293 minecraft:light_blue_stained_glass
fill 169 279 294 169 279 296 minecraft:white_stained_glass
fill 169 279 298 170 279 298 minecraft:white_stained_glass
fill 169 279 303 182 279 303 minecraft:white_stained_glass
setblock 169 279 305 minecraft:light_blue_stained_glass
setblock 169 279 308 minecraft:white_stained_glass
setblock 169 279 311 minecraft:light_blue_stained_glass
fill 169 279 312 169 279 314 minecraft:white_stained_glass
fill 169 279 316 182 279 316 minecraft:white_stained_glass
setblock 170 279 278 minecraft:light_blue_stained_glass
fill 170 279 279 170 279 281 minecraft:white_stained_glass
setblock 170 279 284 minecraft:light_blue_stained_glass
fill 170 279 285 173 279 286 minecraft:white_stained_glass
setblock 170 279 290 minecraft:light_blue_stained_glass
fill 170 279 291 170 279 295 minecraft:white_stained_glass
setblock 170 279 296 minecraft:light_blue_stained_glass
setblock 170 279 302 minecraft:light_blue_stained_glass
setblock 170 279 305 minecraft:white_stained_glass
setblock 170 279 308 minecraft:light_blue_stained_glass
fill 170 279 311 170 279 313 minecraft:white_stained_glass
setblock 170 279 314 minecraft:light_blue_stained_glass
fill 170 279 315 182 279 315 minecraft:white_stained_glass
fill 171 279 278 171 279 280 minecraft:white_stained_glass
setblock 171 279 281 minecraft:light_blue_stained_glass
setblock 171 279 284 minecraft:white_stained_glass
setblock 171 279 287 minecraft:light_blue_stained_glass
fill 171 279 291 171 279 292 minecraft:white_stained_glass
setblock 171 279 293 minecraft:light_blue_stained_glass
fill 171 279 294 171 279 296 minecraft:white_stained_glass
fill 171 279 301 171 279 302 minecraft:white_stained_glass
setblock 171 279 305 minecraft:light_blue_stained_glass
setblock 171 279 308 minecraft:white_stained_glass
setblock 171 279 311 minecraft:light_blue_stained_glass
fill 171 279 312 171 279 314 minecraft:white_stained_glass
setblock 172 279 278 minecraft:light_blue_stained_glass
fill 172 279 279 172 279 281 minecraft:white_stained_glass
setblock 172 279 284 minecraft:light_blue_stained_glass
fill 172 279 289 182 279 289 minecraft:white_stained_glass
setblock 172 279 290 minecraft:light_blue_stained_glass
fill 172 279 298 172 279 299 minecraft:white_stained_glass
setblock 172 279 302 minecraft:light_blue_stained_glass
setblock 172 279 305 minecraft:white_stained_glass
setblock 172 279 308 minecraft:light_blue_stained_glass
fill 172 279 311 172 279 313 minecraft:white_stained_glass
setblock 172 279 314 minecraft:light_blue_stained_glass
fill 173 279 278 173 279 280 minecraft:white_stained_glass
setblock 173 279 281 minecraft:light_blue_stained_glass
setblock 173 279 284 minecraft:white_stained_glass
fill 173 279 288 182 279 288 minecraft:white_stained_glass
fill 173 279 290 173 279 292 minecraft:white_stained_glass
setblock 173 279 293 minecraft:light_blue_stained_glass
fill 173 279 294 173 279 298 minecraft:white_stained_glass
setblock 173 279 299 minecraft:light_blue_stained_glass
fill 173 279 300 182 279 300 minecraft:white_stained_glass
setblock 173 279 302 minecraft:white_stained_glass
setblock 173 279 305 minecraft:light_blue_stained_glass
setblock 173 279 308 minecraft:white_stained_glass
setblock 173 279 311 minecraft:light_blue_stained_glass
fill 173 279 312 173 279 314 minecraft:white_stained_glass
setblock 174 279 278 minecraft:light_blue_stained_glass
fill 174 279 279 174 279 281 minecraft:white_stained_glass
setblock 174 279 284 minecraft:light_blue_stained_glass
fill 174 279 285 182 279 285 minecraft:white_stained_glass
setblock 174 279 290 minecraft:light_blue_stained_glass
fill 174 279 291 174 279 295 minecraft:white_stained_glass
setblock 174 279 296 minecraft:light_blue_stained_glass
fill 174 279 297 174 279 299 minecraft:white_stained_glass
setblock 174 279 305 minecraft:white_stained_glass
setblock 174 279 308 minecraft:light_blue_stained_glass
fill 174 279 311 174 279 313 minecraft:white_stained_glass
setblock 174 279 314 minecraft:light_blue_stained_glass
fill 175 279 278 175 279 280 minecraft:white_stained_glass
setblock 175 279 281 minecraft:light_blue_stained_glass
setblock 175 279 284 minecraft:white_stained_glass
fill 175 279 286 182 279 286 minecraft:white_stained_glass
setblock 175 279 287 minecraft:light_blue_stained_glass
fill 175 279 290 175 279 292 minecraft:white_stained_glass
setblock 175 279 293 minecraft:light_blue_stained_glass
fill 175 279 294 175 279 298 minecraft:white_stained_glass
setblock 175 279 299 minecraft:light_blue_stained_glass
fill 175 279 301 175 279 302 minecraft:white_stained_glass
setblock 175 279 305 minecraft:light_blue_stained_glass
setblock 175 279 308 minecraft:white_stained_glass
setblock 175 279 311 minecraft:light_blue_stained_glass
fill 175 279 312 175 279 314 minecraft:white_stained_glass
setblock 176 279 278 minecraft:light_blue_stained_glass
fill 176 279 279 176 279 281 minecraft:white_stained_glass
setblock 176 279 284 minecraft:light_blue_stained_glass
setblock 176 279 287 minecraft:white_stained_glass
setblock 176 279 290 minecraft:light_blue_stained_glass
fill 176 279 291 176 279 295 minecraft:white_stained_glass
setblock 176 279 296 minecraft:light_blue_stained_glass
fill 176 279 297 176 279 299 minecraft:white_stained_glass
fill 176 279 301 182 279 301 minecraft:white_stained_glass
setblock 176 279 302 minecraft:light_blue_stained_glass
setblock 176 279 305 minecraft:white_stained_glass
setblock 176 279 308 minecraft:light_blue_stained_glass
fill 176 279 311 176 279 313 minecraft:white_stained_glass
setblock 176 279 314 minecraft:light_blue_stained_glass
fill 177 279 278 177 279 280 minecraft:white_stained_glass
setblock 177 279 281 minecraft:light_blue_stained_glass
setblock 177 279 284 minecraft:white_stained_glass
setblock 177 279 287 minecraft:light_blue_stained_glass
fill 177 279 290 177 279 292 minecraft:white_stained_glass
setblock 177 279 293 minecraft:light_blue_stained_glass
fill 177 279 294 177 279 298 minecraft:white_stained_glass
setblock 177 279 299 minecraft:light_blue_stained_glass
setblock 177 279 302 minecraft:white_stained_glass
setblock 177 279 305 minecraft:light_blue_stained_glass
setblock 177 279 308 minecraft:white_stained_glass
setblock 177 279 311 minecraft:light_blue_stained_glass
fill 177 279 312 177 279 314 minecraft:white_stained_glass
setblock 178 279 278 minecraft:light_blue_stained_glass
fill 178 279 279 178 279 281 minecraft:white_stained_glass
setblock 178 279 284 minecraft:light_blue_stained_glass
setblock 178 279 287 minecraft:white_stained_glass
setblock 178 279 290 minecraft:light_blue_stained_glass
fill 178 279 291 178 279 295 minecraft:white_stained_glass
setblock 178 279 296 minecraft:light_blue_stained_glass
fill 178 279 297 178 279 299 minecraft:white_stained_glass
setblock 178 279 302 minecraft:light_blue_stained_glass
setblock 178 279 305 minecraft:white_stained_glass
setblock 178 279 308 minecraft:light_blue_stained_glass
fill 178 279 311 178 279 313 minecraft:white_stained_glass
setblock 178 279 314 minecraft:light_blue_stained_glass
fill 179 279 278 179 279 280 minecraft:white_stained_glass
setblock 179 279 281 minecraft:light_blue_stained_glass
setblock 179 279 284 minecraft:white_stained_glass
setblock 179 279 287 minecraft:light_blue_stained_glass
fill 179 279 290 179 279 292 minecraft:white_stained_glass
setblock 179 279 293 minecraft:light_blue_stained_glass
fill 179 279 294 179 279 298 minecraft:white_stained_glass
setblock 179 279 299 minecraft:light_blue_stained_glass
setblock 179 279 302 minecraft:white_stained_glass
setblock 179 279 305 minecraft:light_blue_stained_glass
setblock 179 279 308 minecraft:white_stained_glass
setblock 179 279 311 minecraft:light_blue_stained_glass
fill 179 279 312 179 279 314 minecraft:white_stained_glass
setblock 180 279 278 minecraft:light_blue_stained_glass
fill 180 279 279 180 279 281 minecraft:white_stained_glass
setblock 180 279 284 minecraft:light_blue_stained_glass
setblock 180 279 287 minecraft:white_stained_glass
setblock 180 279 290 minecraft:light_blue_stained_glass
fill 180 279 291 180 279 295 minecraft:white_stained_glass
setblock 180 279 296 minecraft:light_blue_stained_glass
fill 180 279 297 180 279 299 minecraft:white_stained_glass
setblock 180 279 302 minecraft:light_blue_stained_glass
setblock 180 279 305 minecraft:white_stained_glass
setblock 180 279 308 minecraft:light_blue_stained_glass
fill 180 279 311 180 279 313 minecraft:white_stained_glass
setblock 180 279 314 minecraft:light_blue_stained_glass
fill 181 279 278 181 279 280 minecraft:white_stained_glass
setblock 181 279 281 minecraft:light_blue_stained_glass
setblock 181 279 284 minecraft:white_stained_glass
setblock 181 279 287 minecraft:light_blue_stained_glass
fill 181 279 290 181 279 292 minecraft:white_stained_glass
setblock 181 279 293 minecraft:light_blue_stained_glass
fill 181 279 294 181 279 298 minecraft:white_stained_glass
setblock 181 279 299 minecraft:light_blue_stained_glass
setblock 181 279 302 minecraft:white_stained_glass
setblock 181 279 305 minecraft:light_blue_stained_glass
setblock 181 279 308 minecraft:white_stained_glass
setblock 181 279 311 minecraft:light_blue_stained_glass
fill 181 279 312 181 279 314 minecraft:white_stained_glass
setblock 182 279 278 minecraft:light_blue_stained_glass
fill 182 279 279 182 279 281 minecraft:white_stained_glass
setblock 182 279 284 minecraft:light_blue_stained_glass
setblock 182 279 287 minecraft:white_stained_glass
setblock 182 279 290 minecraft:light_blue_stained_glass
fill 182 279 291 182 279 295 minecraft:white_stained_glass
setblock 182 279 296 minecraft:light_blue_stained_glass
fill 182 279 297 182 279 299 minecraft:white_stained_glass
setblock 182 279 302 minecraft:light_blue_stained_glass
setblock 182 279 305 minecraft:white_stained_glass
setblock 182 279 308 minecraft:light_blue_stained_glass
fill 182 279 311 182 279 313 minecraft:white_stained_glass
setblock 182 279 314 minecraft:light_blue_stained_glass
fill 142 280 279 143 280 309 minecraft:basalt
setblock 143 280 278 minecraft:basalt
fill 143 280 310 146 280 310 minecraft:basalt
fill 144 280 277 146 280 277 minecraft:basalt
setblock 144 280 278 minecraft:magma_block
fill 144 280 279 146 282 280 minecraft:basalt
setblock 144 280 281 minecraft:magma_block
fill 144 280 282 146 284 283 minecraft:basalt
setblock 144 280 284 minecraft:magma_block
fill 144 280 285 146 285 286 minecraft:basalt
setblock 144 280 287 minecraft:magma_block
fill 144 280 288 146 287 289 minecraft:basalt
setblock 144 280 290 minecraft:magma_block
fill 144 280 291 145 288 292 minecraft:basalt
setblock 144 280 293 minecraft:magma_block
fill 144 280 294 145 288 295 minecraft:basalt
setblock 144 280 296 minecraft:magma_block
fill 144 280 297 145 288 298 minecraft:basalt
setblock 144 280 299 minecraft:magma_block
fill 144 280 300 146 287 301 minecraft:basalt
setblock 144 280 302 minecraft:magma_block
fill 144 280 303 146 285 304 minecraft:basalt
setblock 144 280 305 minecraft:magma_block
fill 144 280 306 146 282 307 minecraft:basalt
setblock 144 280 308 minecraft:magma_block
fill 144 280 309 149 282 309 minecraft:basalt
setblock 144 280 311 minecraft:magma_block
fill 145 280 276 149 280 276 minecraft:basalt
fill 145 280 278 152 281 278 minecraft:basalt
fill 145 280 281 152 284 281 minecraft:basalt
fill 145 280 284 148 286 284 minecraft:basalt
fill 145 280 287 146 288 287 minecraft:basalt
fill 145 280 290 145 289 290 minecraft:basalt
fill 145 280 293 145 289 293 minecraft:basalt
fill 145 280 296 145 289 296 minecraft:basalt
fill 145 280 299 146 288 299 minecraft:basalt
fill 145 280 302 147 287 302 minecraft:basalt
fill 145 280 305 149 285 305 minecraft:basalt
fill 145 280 308 152 283 308 minecraft:basalt
fill 145 280 311 149 280 312 minecraft:basalt
setblock 146 280 313 minecraft:basalt
setblock 147 280 277 minecraft:magma_block
fill 147 280 279 149 284 279 minecraft:basalt
setblock 147 280 280 minecraft:magma_block
fill 147 280 282 149 286 282 minecraft:basalt
setblock 147 280 283 minecraft:magma_block
fill 147 280 285 148 289 285 minecraft:basalt
setblock 147 280 286 minecraft:magma_block
fill 147 280 303 148 289 303 minecraft:basalt
setblock 147 280 304 minecraft:magma_block
fill 147 280 306 149 286 306 minecraft:basalt
setblock 147 280 307 minecraft:magma_block
setblock 147 280 310 minecraft:magma_block
setblock 147 280 313 minecraft:magma_block
fill 147 280 314 152 280 314 minecraft:basalt
fill 148 280 277 155 283 277 minecraft:basalt
fill 148 280 280 153 286 280 minecraft:basalt
fill 148 280 283 149 288 283 minecraft:basalt
fill 148 280 304 148 289 304 minecraft:basalt
fill 148 280 307 152 280 307 minecraft:basalt
fill 148 280 310 155 284 310 minecraft:basalt
fill 148 280 313 155 281 313 minecraft:basalt
setblock 149 280 315 minecraft:basalt
setblock 150 280 276 minecraft:magma_block
setblock 150 280 279 minecraft:magma_block
setblock 150 280 282 minecraft:magma_block
setblock 150 280 306 minecraft:magma_block
setblock 150 280 309 minecraft:magma_block
fill 150 280 311 152 284 311 minecraft:basalt
setblock 150 280 312 minecraft:magma_block
setblock 150 280 315 minecraft:magma_block
fill 151 280 276 158 284 276 minecraft:basalt
fill 151 280 279 156 287 279 minecraft:basalt
fill 151 280 309 156 287 309 minecraft:basalt
fill 151 280 312 158 284 312 minecraft:basalt
fill 151 280 315 155 280 316 minecraft:basalt
setblock 152 280 286 minecraft:light[level=15]
setblock 152 280 294 minecraft:light[level=15]
setblock 152 280 302 minecraft:light[level=15]
setblock 153 280 278 minecraft:magma_block
setblock 153 280 308 minecraft:magma_block
setblock 153 280 311 minecraft:magma_block
setblock 153 280 314 minecraft:magma_block
fill 154 280 278 161 288 278 minecraft:basalt
fill 154 280 311 161 287 311 minecraft:basalt
fill 154 280 314 161 283 314 minecraft:basalt
setblock 156 280 277 minecraft:magma_block
setblock 156 280 310 minecraft:magma_block
setblock 156 280 313 minecraft:magma_block
fill 156 280 315 158 282 315 minecraft:basalt
setblock 156 280 316 minecraft:magma_block
fill 157 280 277 164 287 277 minecraft:basalt
fill 157 280 310 164 280 310 minecraft:basalt
fill 157 280 313 164 285 313 minecraft:basalt
fill 157 280 316 164 281 316 minecraft:basalt
setblock 159 280 276 minecraft:magma_block
setblock 159 280 312 minecraft:magma_block
setblock 159 280 315 minecraft:magma_block
fill 160 280 276 167 286 276 minecraft:basalt
setblock 160 280 286 minecraft:light[level=15]
setblock 160 280 302 minecraft:light[level=15]
fill 160 280 312 167 286 312 minecraft:basalt
fill 160 280 315 167 282 315 minecraft:basalt
setblock 162 280 278 minecraft:magma_block
setblock 162 280 311 minecraft:magma_block
setblock 162 280 314 minecraft:magma_block
fill 163 280 278 170 286 278 minecraft:basalt
fill 163 280 311 170 286 311 minecraft:basalt
fill 163 280 314 170 282 314 minecraft:basalt
setblock 165 280 277 minecraft:magma_block
setblock 165 280 310 minecraft:magma_block
setblock 165 280 313 minecraft:magma_block
setblock 165 280 316 minecraft:magma_block
fill 166 280 277 173 284 277 minecraft:basalt
fill 166 280 279 167 289 279 minecraft:basalt
fill 166 280 309 167 288 310 minecraft:basalt
fill 166 280 313 173 282 313 minecraft:basalt
fill 166 280 316 171 280 316 minecraft:basalt
setblock 168 280 276 minecraft:magma_block
setblock 168 280 279 minecraft:magma_block
setblock 168 280 286 minecraft:light[level=15]
setblock 168 280 294 minecraft:light[level=15]
setblock 168 280 302 minecraft:light[level=15]
setblock 168 280 309 minecraft:magma_block
fill 168 280 310 173 284 310 minecraft:basalt
setblock 168 280 312 minecraft:magma_block
setblock 168 280 315 minecraft:magma_block
fill 169 280 276 176 281 276 minecraft:basalt
fill 169 280 279 173 286 280 minecraft:basalt
fill 169 280 308 170 288 309 minecraft:basalt
fill 169 280 312 176 281 312 minecraft:basalt
fill 169 280 315 173 280 315 minecraft:basalt
fill 170 280 281 170 290 281 minecraft:basalt
fill 170 280 307 173 280 307 minecraft:basalt
setblock 171 280 278 minecraft:magma_block
setblock 171 280 281 minecraft:magma_block
setblock 171 280 308 minecraft:magma_block
fill 171 280 309 176 283 309 minecraft:basalt
setblock 171 280 311 minecraft:magma_block
setblock 171 280 314 minecraft:magma_block
fill 172 280 278 179 280 278 minecraft:basalt
fill 172 280 281 176 285 282 minecraft:basalt
fill 172 280 306 176 286 306 minecraft:basalt
fill 172 280 308 179 282 308 minecraft:basalt
fill 172 280 311 178 280 311 minecraft:basalt
fill 172 280 314 175 280 314 minecraft:basalt
fill 173 280 283 173 289 283 minecraft:basalt
fill 173 280 305 179 283 305 minecraft:basalt
setblock 174 280 277 minecraft:magma_block
fill 174 280 279 176 283 279 minecraft:basalt
setblock 174 280 280 minecraft:magma_block
setblock 174 280 283 minecraft:magma_block
fill 174 280 284 176 287 285 minecraft:basalt
fill 174 280 303 176 288 303 minecraft:basalt
setblock 174 280 304 minecraft:magma_block
setblock 174 280 307 minecraft:magma_block
setblock 174 280 310 minecraft:magma_block
setblock 174 280 313 minecraft:magma_block
fill 175 280 277 178 280 277 minecraft:basalt
fill 175 280 280 181 280 280 minecraft:basalt
fill 175 280 283 182 280 283 minecraft:basalt
fill 175 280 286 182 282 286 minecraft:basalt
fill 175 280 302 179 285 302 minecraft:basalt
fill 175 280 304 182 281 304 minecraft:basalt
fill 175 280 307 181 280 307 minecraft:basalt
fill 175 280 310 179 280 310 minecraft:basalt
fill 175 280 313 176 280 313 minecraft:basalt
fill 176 280 287 176 289 289 minecraft:basalt
setblock 176 280 294 minecraft:light[level=15]
fill 176 280 299 176 280 301 minecraft:basalt
setblock 177 280 276 minecraft:magma_block
setblock 177 280 279 minecraft:magma_block
fill 177 280 281 179 282 281 minecraft:basalt
setblock 177 280 282 minecraft:magma_block
fill 177 280 284 179 284 284 minecraft:basalt
setblock 177 280 285 minecraft:magma_block
fill 177 280 287 179 285 287 minecraft:basalt
setblock 177 280 288 minecraft:magma_block
fill 177 280 289 179 286 290 minecraft:basalt
setblock 177 280 291 minecraft:magma_block
fill 177 280 292 179 286 293 minecraft:basalt
setblock 177 280 294 minecraft:magma_block
fill 177 280 295 179 286 296 minecraft:basalt
setblock 177 280 297 minecraft:magma_block
fill 177 280 298 179 286 299 minecraft:basalt
setblock 177 280 300 minecraft:magma_block
fill 177 280 301 182 282 301 minecraft:basalt
setblock 177 280 303 minecraft:magma_block
setblock 177 280 306 minecraft:magma_block
setblock 177 280 309 minecraft:magma_block
setblock 177 280 312 minecraft:magma_block
fill 178 280 279 180 280 279 minecraft:basalt
fill 178 280 282 182 280 282 minecraft:basalt
fill 178 280 285 182 280 285 minecraft:basalt
fill 178 280 288 182 283 288 minecraft:basalt
fill 178 280 291 182 283 291 minecraft:basalt
fill 178 280 294 182 284 294 minecraft:basalt
fill 178 280 297 182 283 297 minecraft:basalt
fill 178 280 300 182 283 300 minecraft:basalt
fill 178 280 303 182 280 303 minecraft:basalt
fill 178 280 306 182 280 306 minecraft:basalt
fill 178 280 309 180 280 309 minecraft:basalt
setblock 180 280 281 minecraft:magma_block
setblock 180 280 284 minecraft:magma_block
setblock 180 280 287 minecraft:magma_block
fill 180 280 289 182 283 289 minecraft:basalt
setblock 180 280 290 minecraft:magma_block
fill 180 280 292 182 283 292 minecraft:basalt
setblock 180 280 293 minecraft:magma_block
fill 180 280 295 182 284 295 minecraft:basalt
setblock 180 280 296 minecraft:magma_block
fill 180 280 298 182 283 298 minecraft:basalt
setblock 180 280 299 minecraft:magma_block
setblock 180 280 302 minecraft:magma_block
setblock 180 280 305 minecraft:magma_block
setblock 180 280 308 minecraft:magma_block
setblock 181 280 281 minecraft:basalt
fill 181 280 284 182 281 284 minecraft:basalt
fill 181 280 287 182 282 287 minecraft:basalt
fill 181 280 290 182 283 290 minecraft:basalt
fill 181 280 293 182 283 293 minecraft:basalt
fill 181 280 296 182 283 296 minecraft:basalt
fill 181 280 299 182 283 299 minecraft:basalt
fill 181 280 302 182 282 302 minecraft:basalt
fill 181 280 305 182 280 305 minecraft:basalt
setblock 181 280 308 minecraft:basalt
setblock 141 281 286 minecraft:light_blue_concrete
fill 142 281 280 143 281 308 minecraft:basalt
setblock 143 281 279 minecraft:basalt
setblock 143 281 309 minecraft:basalt
setblock 144 281 278 minecraft:basalt
fill 144 281 281 144 283 281 minecraft:basalt
fill 144 281 284 144 285 284 minecraft:basalt
fill 144 281 287 144 287 287 minecraft:basalt
schedule function dropper:buildpart/63_11 1t
