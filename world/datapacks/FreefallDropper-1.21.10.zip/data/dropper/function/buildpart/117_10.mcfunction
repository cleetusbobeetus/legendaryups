setblock 425 298 492 minecraft:polished_blackstone_bricks
fill 425 298 493 425 300 493 minecraft:blackstone
setblock 425 298 497 minecraft:polished_blackstone_bricks
fill 425 298 498 425 300 498 minecraft:blackstone
setblock 425 298 502 minecraft:polished_blackstone_bricks
fill 425 298 503 425 300 503 minecraft:blackstone
setblock 426 298 476 minecraft:polished_blackstone_bricks
fill 426 298 477 426 300 477 minecraft:blackstone
setblock 426 298 481 minecraft:polished_blackstone_bricks
fill 426 298 482 426 300 482 minecraft:blackstone
setblock 426 298 491 minecraft:polished_blackstone_bricks
fill 426 298 492 426 299 492 minecraft:blackstone
setblock 426 298 496 minecraft:polished_blackstone_bricks
fill 426 298 497 426 300 497 minecraft:blackstone
setblock 426 298 501 minecraft:polished_blackstone_bricks
fill 426 298 502 426 300 502 minecraft:blackstone
setblock 427 298 495 minecraft:polished_blackstone_bricks
setblock 427 298 496 minecraft:blackstone
setblock 428 298 504 minecraft:polished_blackstone_bricks
fill 429 298 504 429 299 504 minecraft:blackstone
fill 441 298 464 442 298 464 minecraft:blackstone
setblock 442 298 504 minecraft:blackstone
setblock 443 298 464 minecraft:polished_blackstone_bricks
setblock 443 298 504 minecraft:polished_blackstone_bricks
fill 444 298 464 446 298 465 minecraft:blackstone
setblock 444 298 503 minecraft:polished_blackstone_bricks
fill 444 298 504 444 300 504 minecraft:blackstone
fill 445 298 503 445 300 503 minecraft:blackstone
setblock 447 298 464 minecraft:blackstone
setblock 447 298 465 minecraft:polished_blackstone_bricks
setblock 448 298 464 minecraft:polished_blackstone_bricks
fill 448 298 465 448 299 465 minecraft:blackstone
setblock 448 298 503 minecraft:blackstone
setblock 448 298 504 minecraft:polished_blackstone_bricks
fill 449 298 464 449 300 464 minecraft:blackstone
fill 449 298 497 449 299 497 minecraft:light_blue_stained_glass
setblock 449 298 503 minecraft:polished_blackstone_bricks
fill 449 298 504 449 300 504 minecraft:blackstone
fill 450 298 503 450 299 503 minecraft:blackstone
setblock 453 298 464 minecraft:polished_blackstone_bricks
setblock 453 298 504 minecraft:polished_blackstone_bricks
fill 454 298 504 457 298 504 minecraft:blackstone
setblock 458 298 503 minecraft:blackstone
setblock 458 298 504 minecraft:polished_blackstone_bricks
setblock 459 298 503 minecraft:polished_blackstone_bricks
fill 459 298 504 459 300 504 minecraft:blackstone
setblock 460 298 502 minecraft:polished_blackstone_bricks
fill 460 298 503 460 300 503 minecraft:blackstone
fill 461 298 502 461 300 502 minecraft:blackstone
setblock 462 298 495 minecraft:polished_blackstone_bricks
fill 462 298 496 462 298 499 minecraft:blackstone
setblock 462 298 500 minecraft:polished_blackstone_bricks
fill 462 298 501 462 300 501 minecraft:blackstone
setblock 463 298 464 minecraft:polished_blackstone_bricks
setblock 463 298 474 minecraft:polished_blackstone_bricks
fill 463 298 475 463 299 475 minecraft:blackstone
setblock 463 298 479 minecraft:polished_blackstone_bricks
fill 463 298 480 463 300 480 minecraft:blackstone
fill 463 298 492 463 298 493 minecraft:blackstone
setblock 463 298 494 minecraft:polished_blackstone_bricks
fill 463 298 495 463 300 495 minecraft:blackstone
setblock 463 298 498 minecraft:blackstone
setblock 463 298 499 minecraft:polished_blackstone_bricks
fill 463 298 500 463 300 500 minecraft:blackstone
setblock 463 298 504 minecraft:polished_blackstone_bricks
fill 464 298 464 464 300 464 minecraft:blackstone
setblock 464 298 468 minecraft:polished_blackstone_bricks
fill 464 298 469 464 299 469 minecraft:blackstone
setblock 464 298 473 minecraft:polished_blackstone_bricks
fill 464 298 474 464 300 474 minecraft:blackstone
setblock 464 298 478 minecraft:polished_blackstone_bricks
fill 464 298 479 464 300 479 minecraft:blackstone
setblock 464 298 483 minecraft:polished_blackstone_bricks
fill 464 298 484 464 298 487 minecraft:blackstone
setblock 464 298 488 minecraft:polished_blackstone_bricks
fill 464 298 489 464 298 492 minecraft:blackstone
setblock 464 298 493 minecraft:polished_blackstone_bricks
fill 464 298 494 464 300 494 minecraft:blackstone
setblock 464 298 498 minecraft:polished_blackstone_bricks
fill 464 298 499 464 300 499 minecraft:blackstone
setblock 464 298 503 minecraft:polished_blackstone_bricks
fill 464 298 504 464 300 504 minecraft:blackstone
setblock 424 299 471 minecraft:blackstone
setblock 424 299 472 minecraft:polished_blackstone_bricks
fill 424 299 473 424 299 476 minecraft:blackstone
setblock 424 299 477 minecraft:polished_blackstone_bricks
fill 424 299 478 424 300 478 minecraft:blackstone
setblock 424 299 482 minecraft:polished_blackstone_bricks
fill 424 299 483 424 300 483 minecraft:blackstone
setblock 424 299 487 minecraft:polished_blackstone_bricks
fill 424 299 488 424 300 488 minecraft:blackstone
setblock 424 299 492 minecraft:polished_blackstone_bricks
fill 424 299 493 424 300 493 minecraft:blackstone
setblock 424 299 497 minecraft:polished_blackstone_bricks
fill 424 299 498 424 299 501 minecraft:blackstone
setblock 424 299 502 minecraft:polished_blackstone_bricks
fill 424 299 503 424 300 503 minecraft:blackstone
setblock 425 299 476 minecraft:polished_blackstone_bricks
fill 425 299 477 425 300 477 minecraft:blackstone
setblock 425 299 481 minecraft:polished_blackstone_bricks
fill 425 299 482 425 300 482 minecraft:blackstone
setblock 425 299 486 minecraft:polished_blackstone_bricks
fill 425 299 487 425 300 487 minecraft:blackstone
setblock 425 299 491 minecraft:polished_blackstone_bricks
fill 425 299 492 425 300 492 minecraft:blackstone
setblock 425 299 496 minecraft:polished_blackstone_bricks
fill 425 299 497 425 300 497 minecraft:blackstone
setblock 425 299 501 minecraft:polished_blackstone_bricks
fill 425 299 502 425 300 502 minecraft:blackstone
setblock 426 299 476 minecraft:blackstone
setblock 426 299 480 minecraft:polished_blackstone_bricks
fill 426 299 481 426 300 481 minecraft:blackstone
setblock 426 299 495 minecraft:polished_blackstone_bricks
fill 426 299 496 426 300 496 minecraft:blackstone
setblock 426 299 500 minecraft:polished_blackstone_bricks
fill 426 299 501 426 300 501 minecraft:blackstone
setblock 427 299 504 minecraft:polished_blackstone_bricks
setblock 428 299 503 minecraft:polished_blackstone_bricks
fill 428 299 504 428 300 504 minecraft:blackstone
setblock 441 299 464 minecraft:blackstone
setblock 441 299 504 minecraft:blackstone
setblock 442 299 464 minecraft:polished_blackstone_bricks
setblock 442 299 504 minecraft:polished_blackstone_bricks
fill 443 299 464 446 299 464 minecraft:blackstone
setblock 443 299 503 minecraft:polished_blackstone_bricks
fill 443 299 504 443 300 504 minecraft:blackstone
fill 444 299 465 445 299 465 minecraft:blackstone
fill 444 299 503 444 300 503 minecraft:blackstone
setblock 446 299 465 minecraft:polished_blackstone_bricks
setblock 447 299 464 minecraft:polished_blackstone_bricks
fill 447 299 465 447 300 465 minecraft:blackstone
setblock 447 299 504 minecraft:polished_blackstone_bricks
fill 448 299 464 448 300 464 minecraft:blackstone
setblock 448 299 503 minecraft:polished_blackstone_bricks
fill 448 299 504 448 300 504 minecraft:blackstone
fill 449 299 503 449 300 503 minecraft:blackstone
setblock 452 299 464 minecraft:polished_blackstone_bricks
setblock 452 299 504 minecraft:polished_blackstone_bricks
fill 453 299 504 456 299 504 minecraft:blackstone
setblock 457 299 504 minecraft:polished_blackstone_bricks
setblock 458 299 503 minecraft:polished_blackstone_bricks
fill 458 299 504 458 300 504 minecraft:blackstone
fill 459 299 503 459 300 503 minecraft:blackstone
fill 460 299 502 460 300 502 minecraft:blackstone
setblock 462 299 464 minecraft:polished_blackstone_bricks
fill 462 299 495 462 299 498 minecraft:blackstone
setblock 462 299 499 minecraft:polished_blackstone_bricks
fill 462 299 500 462 300 500 minecraft:blackstone
setblock 462 299 504 minecraft:polished_blackstone_bricks
fill 463 299 464 463 300 464 minecraft:blackstone
setblock 463 299 477 minecraft:blackstone
setblock 463 299 478 minecraft:polished_blackstone_bricks
fill 463 299 479 463 300 479 minecraft:blackstone
setblock 463 299 492 minecraft:blackstone
setblock 463 299 493 minecraft:polished_blackstone_bricks
fill 463 299 494 463 300 494 minecraft:blackstone
setblock 463 299 498 minecraft:polished_blackstone_bricks
fill 463 299 499 463 300 499 minecraft:blackstone
setblock 463 299 503 minecraft:polished_blackstone_bricks
fill 463 299 504 463 300 504 minecraft:blackstone
setblock 464 299 467 minecraft:polished_blackstone_bricks
setblock 464 299 472 minecraft:polished_blackstone_bricks
fill 464 299 473 464 300 473 minecraft:blackstone
setblock 464 299 477 minecraft:polished_blackstone_bricks
fill 464 299 478 464 300 478 minecraft:blackstone
setblock 464 299 482 minecraft:polished_blackstone_bricks
fill 464 299 483 464 299 486 minecraft:blackstone
setblock 464 299 487 minecraft:polished_blackstone_bricks
fill 464 299 488 464 299 491 minecraft:blackstone
setblock 464 299 492 minecraft:polished_blackstone_bricks
fill 464 299 493 464 300 493 minecraft:blackstone
setblock 464 299 497 minecraft:polished_blackstone_bricks
fill 464 299 498 464 300 498 minecraft:blackstone
setblock 464 299 502 minecraft:polished_blackstone_bricks
fill 464 299 503 464 300 503 minecraft:blackstone
fill 424 300 472 424 300 475 minecraft:blackstone
setblock 424 300 476 minecraft:polished_blackstone_bricks
setblock 424 300 477 minecraft:blackstone
setblock 424 300 481 minecraft:polished_blackstone_bricks
setblock 424 300 482 minecraft:blackstone
setblock 424 300 486 minecraft:polished_blackstone_bricks
setblock 424 300 487 minecraft:blackstone
setblock 424 300 491 minecraft:polished_blackstone_bricks
setblock 424 300 492 minecraft:blackstone
setblock 424 300 496 minecraft:polished_blackstone_bricks
fill 424 300 497 424 300 500 minecraft:blackstone
setblock 424 300 501 minecraft:polished_blackstone_bricks
setblock 424 300 502 minecraft:blackstone
setblock 425 300 475 minecraft:polished_blackstone_bricks
setblock 425 300 476 minecraft:blackstone
setblock 425 300 480 minecraft:polished_blackstone_bricks
setblock 425 300 481 minecraft:blackstone
setblock 425 300 485 minecraft:polished_blackstone_bricks
setblock 425 300 486 minecraft:blackstone
setblock 425 300 490 minecraft:polished_blackstone_bricks
setblock 425 300 491 minecraft:blackstone
setblock 425 300 495 minecraft:polished_blackstone_bricks
setblock 425 300 496 minecraft:blackstone
setblock 425 300 500 minecraft:polished_blackstone_bricks
setblock 425 300 501 minecraft:blackstone
setblock 426 300 479 minecraft:polished_blackstone_bricks
setblock 426 300 480 minecraft:blackstone
setblock 426 300 495 minecraft:blackstone
setblock 426 300 499 minecraft:polished_blackstone_bricks
setblock 426 300 500 minecraft:blackstone
setblock 426 300 504 minecraft:polished_blackstone_bricks
setblock 427 300 503 minecraft:polished_blackstone_bricks
setblock 427 300 504 minecraft:blackstone
setblock 441 300 464 minecraft:polished_blackstone_bricks
setblock 441 300 504 minecraft:polished_blackstone_bricks
fill 442 300 464 445 300 464 minecraft:blackstone
setblock 442 300 504 minecraft:blackstone
fill 443 300 465 444 300 465 minecraft:blackstone
setblock 443 300 503 minecraft:blackstone
setblock 445 300 465 minecraft:polished_blackstone_bricks
setblock 446 300 464 minecraft:polished_blackstone_bricks
setblock 446 300 465 minecraft:blackstone
setblock 446 300 504 minecraft:polished_blackstone_bricks
setblock 447 300 464 minecraft:blackstone
setblock 447 300 503 minecraft:polished_blackstone_bricks
setblock 447 300 504 minecraft:blackstone
setblock 448 300 503 minecraft:blackstone
setblock 451 300 464 minecraft:polished_blackstone_bricks
setblock 451 300 504 minecraft:polished_blackstone_bricks
fill 452 300 504 455 300 504 minecraft:blackstone
setblock 456 300 504 minecraft:polished_blackstone_bricks
setblock 457 300 503 minecraft:polished_blackstone_bricks
setblock 457 300 504 minecraft:blackstone
setblock 458 300 503 minecraft:blackstone
setblock 459 300 464 minecraft:blackstone
setblock 461 300 464 minecraft:polished_blackstone_bricks
setblock 461 300 504 minecraft:polished_blackstone_bricks
setblock 462 300 464 minecraft:blackstone
fill 462 300 496 462 300 497 minecraft:blackstone
setblock 462 300 498 minecraft:polished_blackstone_bricks
setblock 462 300 499 minecraft:blackstone
setblock 462 300 503 minecraft:polished_blackstone_bricks
setblock 462 300 504 minecraft:blackstone
setblock 463 300 477 minecraft:polished_blackstone_bricks
setblock 463 300 478 minecraft:blackstone
setblock 463 300 481 minecraft:blackstone
setblock 463 300 493 minecraft:blackstone
setblock 463 300 497 minecraft:polished_blackstone_bricks
setblock 463 300 498 minecraft:blackstone
setblock 463 300 502 minecraft:polished_blackstone_bricks
setblock 463 300 503 minecraft:blackstone
setblock 464 300 472 minecraft:blackstone
setblock 464 300 476 minecraft:polished_blackstone_bricks
setblock 464 300 477 minecraft:blackstone
setblock 464 300 481 minecraft:polished_blackstone_bricks
fill 464 300 482 464 300 485 minecraft:blackstone
setblock 464 300 486 minecraft:polished_blackstone_bricks
fill 464 300 487 464 300 490 minecraft:blackstone
setblock 464 300 491 minecraft:polished_blackstone_bricks
setblock 464 300 492 minecraft:blackstone
setblock 464 300 496 minecraft:polished_blackstone_bricks
setblock 464 300 497 minecraft:blackstone
setblock 464 300 501 minecraft:polished_blackstone_bricks
setblock 464 300 502 minecraft:blackstone
setblock 426 302 466 minecraft:light[level=11]
setblock 426 302 474 minecraft:light[level=11]
setblock 426 302 482 minecraft:light[level=11]
setblock 426 302 490 minecraft:light[level=11]
setblock 426 302 498 minecraft:light[level=11]
setblock 434 302 466 minecraft:light[level=11]
setblock 434 302 474 minecraft:light[level=11]
setblock 434 302 482 minecraft:light[level=11]
setblock 434 302 490 minecraft:light[level=11]
setblock 434 302 498 minecraft:light[level=11]
setblock 442 302 466 minecraft:light[level=11]
setblock 442 302 474 minecraft:light[level=11]
setblock 442 302 482 minecraft:light[level=11]
setblock 442 302 490 minecraft:light[level=11]
setblock 442 302 498 minecraft:light[level=11]
setblock 450 302 466 minecraft:light[level=11]
setblock 450 302 474 minecraft:light[level=11]
setblock 450 302 482 minecraft:light[level=11]
setblock 450 302 490 minecraft:light[level=11]
setblock 450 302 498 minecraft:light[level=11]
setblock 458 302 466 minecraft:light[level=11]
setblock 458 302 474 minecraft:light[level=11]
setblock 458 302 482 minecraft:light[level=11]
setblock 458 302 490 minecraft:light[level=11]
setblock 458 302 498 minecraft:light[level=11]
