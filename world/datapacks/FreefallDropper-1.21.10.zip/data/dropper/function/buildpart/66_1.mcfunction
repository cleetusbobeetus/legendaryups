setblock 309 33 278 minecraft:light[level=15]
setblock 309 33 286 minecraft:light[level=15]
setblock 309 33 294 minecraft:light[level=15]
setblock 309 33 302 minecraft:light[level=15]
setblock 309 33 310 minecraft:light[level=15]
setblock 313 33 317 minecraft:iron_block
setblock 314 33 317 minecraft:redstone_block
setblock 315 33 317 minecraft:iron_block
setblock 317 33 278 minecraft:light[level=15]
setblock 317 33 286 minecraft:light[level=15]
setblock 317 33 294 minecraft:light[level=15]
setblock 317 33 302 minecraft:light[level=15]
setblock 317 33 310 minecraft:light[level=15]
setblock 321 33 317 minecraft:iron_block
fill 282 34 275 282 35 276 minecraft:yellow_concrete
fill 282 34 277 282 35 278 minecraft:black_concrete
fill 282 34 279 282 35 280 minecraft:yellow_concrete
fill 282 34 281 282 35 282 minecraft:black_concrete
fill 282 34 283 282 35 284 minecraft:yellow_concrete
fill 282 34 285 282 35 286 minecraft:black_concrete
fill 282 34 287 282 35 288 minecraft:yellow_concrete
fill 282 34 289 282 35 290 minecraft:black_concrete
fill 282 34 291 282 35 292 minecraft:yellow_concrete
fill 282 34 293 282 35 294 minecraft:black_concrete
fill 282 34 295 282 35 296 minecraft:yellow_concrete
fill 282 34 297 282 35 298 minecraft:black_concrete
fill 282 34 299 282 35 300 minecraft:yellow_concrete
fill 282 34 301 282 35 302 minecraft:black_concrete
fill 282 34 303 282 35 304 minecraft:yellow_concrete
fill 282 34 305 282 35 306 minecraft:black_concrete
fill 282 34 307 282 35 308 minecraft:yellow_concrete
fill 282 34 309 282 35 310 minecraft:black_concrete
fill 282 34 311 282 35 312 minecraft:yellow_concrete
fill 282 34 313 282 35 314 minecraft:black_concrete
fill 282 34 315 282 35 316 minecraft:yellow_concrete
fill 282 34 317 282 35 317 minecraft:black_concrete
fill 283 34 275 283 35 275 minecraft:yellow_concrete
fill 283 34 317 283 35 317 minecraft:yellow_concrete
fill 284 34 275 285 35 275 minecraft:black_concrete
fill 284 34 317 285 35 317 minecraft:black_concrete
fill 286 34 275 287 35 275 minecraft:yellow_concrete
fill 286 34 317 287 35 317 minecraft:yellow_concrete
fill 288 34 275 289 35 275 minecraft:black_concrete
fill 288 34 317 289 35 317 minecraft:black_concrete
fill 290 34 275 291 35 275 minecraft:yellow_concrete
fill 290 34 317 291 35 317 minecraft:yellow_concrete
fill 292 34 275 293 35 275 minecraft:black_concrete
fill 292 34 317 293 35 317 minecraft:black_concrete
fill 294 34 275 295 35 275 minecraft:yellow_concrete
fill 294 34 317 295 35 317 minecraft:yellow_concrete
fill 296 34 275 297 35 275 minecraft:black_concrete
fill 296 34 317 297 35 317 minecraft:black_concrete
fill 298 34 275 299 35 275 minecraft:yellow_concrete
fill 298 34 317 299 35 317 minecraft:yellow_concrete
fill 300 34 275 301 35 275 minecraft:black_concrete
fill 300 34 317 301 35 317 minecraft:black_concrete
fill 302 34 275 303 35 275 minecraft:yellow_concrete
fill 302 34 317 303 35 317 minecraft:yellow_concrete
fill 304 34 275 305 35 275 minecraft:black_concrete
fill 304 34 317 305 35 317 minecraft:black_concrete
fill 306 34 275 307 35 275 minecraft:yellow_concrete
fill 306 34 317 307 35 317 minecraft:yellow_concrete
fill 308 34 275 309 35 275 minecraft:black_concrete
fill 308 34 317 309 35 317 minecraft:black_concrete
fill 310 34 275 311 35 275 minecraft:yellow_concrete
fill 310 34 317 311 35 317 minecraft:yellow_concrete
fill 312 34 275 313 35 275 minecraft:black_concrete
fill 312 34 317 313 35 317 minecraft:black_concrete
fill 314 34 275 315 35 275 minecraft:yellow_concrete
fill 314 34 317 315 35 317 minecraft:yellow_concrete
fill 316 34 275 317 35 275 minecraft:black_concrete
fill 316 34 317 317 35 317 minecraft:black_concrete
fill 318 34 275 319 35 275 minecraft:yellow_concrete
fill 318 34 317 319 35 317 minecraft:yellow_concrete
fill 320 34 275 321 35 275 minecraft:black_concrete
fill 320 34 317 321 35 317 minecraft:black_concrete
fill 322 34 275 323 35 275 minecraft:yellow_concrete
fill 322 34 317 323 35 317 minecraft:yellow_concrete
fill 324 34 275 324 35 275 minecraft:black_concrete
fill 324 34 276 324 35 276 minecraft:yellow_concrete
fill 324 34 277 324 35 278 minecraft:black_concrete
fill 324 34 279 324 35 280 minecraft:yellow_concrete
fill 324 34 281 324 35 282 minecraft:black_concrete
fill 324 34 283 324 35 284 minecraft:yellow_concrete
fill 324 34 285 324 35 286 minecraft:black_concrete
fill 324 34 287 324 35 288 minecraft:yellow_concrete
fill 324 34 289 324 35 290 minecraft:black_concrete
fill 324 34 291 324 35 292 minecraft:yellow_concrete
fill 324 34 293 324 35 294 minecraft:black_concrete
fill 324 34 295 324 35 296 minecraft:yellow_concrete
fill 324 34 297 324 35 298 minecraft:black_concrete
fill 324 34 299 324 35 300 minecraft:yellow_concrete
fill 324 34 301 324 35 302 minecraft:black_concrete
fill 324 34 303 324 35 304 minecraft:yellow_concrete
fill 324 34 305 324 35 306 minecraft:black_concrete
fill 324 34 307 324 35 308 minecraft:yellow_concrete
fill 324 34 309 324 35 310 minecraft:black_concrete
fill 324 34 311 324 35 312 minecraft:yellow_concrete
fill 324 34 313 324 35 314 minecraft:black_concrete
fill 324 34 315 324 35 316 minecraft:yellow_concrete
fill 324 34 317 324 35 317 minecraft:black_concrete
fill 318 35 304 318 35 306 minecraft:iron_block
fill 319 35 304 320 35 304 minecraft:iron_block
fill 319 35 306 320 35 306 minecraft:iron_block
setblock 320 35 305 minecraft:iron_block
fill 282 36 275 282 39 317 minecraft:iron_block
fill 283 36 275 324 39 275 minecraft:iron_block
setblock 283 36 278 minecraft:iron_block
fill 283 36 280 283 36 283 minecraft:iron_block
setblock 283 36 288 minecraft:iron_block
fill 283 36 290 283 36 293 minecraft:iron_block
setblock 283 36 298 minecraft:iron_block
fill 283 36 300 283 36 303 minecraft:iron_block
setblock 283 36 308 minecraft:iron_block
fill 283 36 310 283 36 313 minecraft:iron_block
fill 283 36 317 294 39 317 minecraft:iron_block
fill 284 36 276 287 36 276 minecraft:iron_block
setblock 285 36 316 minecraft:iron_block
fill 287 36 316 290 36 316 minecraft:iron_block
setblock 289 36 276 minecraft:iron_block
fill 294 36 276 297 36 276 minecraft:iron_block
setblock 295 36 316 minecraft:iron_block
setblock 295 36 317 minecraft:sea_lantern
fill 296 36 317 324 38 317 minecraft:iron_block
fill 297 36 316 300 36 316 minecraft:iron_block
setblock 299 36 276 minecraft:iron_block
fill 304 36 276 307 36 276 minecraft:iron_block
setblock 305 36 316 minecraft:iron_block
fill 307 36 316 310 36 316 minecraft:iron_block
setblock 309 36 276 minecraft:iron_block
fill 314 36 276 317 36 276 minecraft:iron_block
setblock 315 36 316 minecraft:iron_block
fill 317 36 316 320 36 316 minecraft:iron_block
setblock 319 36 276 minecraft:iron_block
fill 320 36 296 322 37 296 minecraft:iron_block
fill 323 36 277 324 36 280 minecraft:iron_block
fill 323 36 282 324 36 282 minecraft:iron_block
fill 323 36 287 324 36 290 minecraft:iron_block
fill 323 36 292 324 36 292 minecraft:iron_block
fill 323 36 297 324 36 300 minecraft:iron_block
fill 323 36 302 324 36 302 minecraft:iron_block
fill 323 36 307 324 36 310 minecraft:iron_block
fill 323 36 312 324 36 312 minecraft:iron_block
setblock 324 36 276 minecraft:sea_lantern
fill 324 36 281 324 61 281 minecraft:iron_block
fill 324 36 283 324 39 286 minecraft:iron_block
fill 324 36 291 324 61 291 minecraft:iron_block
fill 324 36 293 324 39 296 minecraft:iron_block
fill 324 36 301 324 61 301 minecraft:iron_block
fill 324 36 303 324 39 306 minecraft:iron_block
fill 324 36 311 324 61 311 minecraft:iron_block
fill 324 36 313 324 39 316 minecraft:iron_block
fill 283 37 281 323 37 281 minecraft:iron_block
fill 283 37 286 291 38 286 minecraft:iron_block
fill 283 37 291 285 38 291 minecraft:iron_block
fill 283 37 296 293 37 296 minecraft:iron_block
fill 283 37 301 322 38 301 minecraft:iron_block
fill 283 37 306 286 38 306 minecraft:iron_block
fill 283 37 311 323 37 311 minecraft:iron_block
setblock 285 37 278 minecraft:light[level=12]
setblock 285 37 285 minecraft:light[level=12]
setblock 285 37 292 minecraft:light[level=12]
setblock 285 37 299 minecraft:light[level=12]
setblock 285 37 313 minecraft:light[level=12]
setblock 292 37 278 minecraft:light[level=12]
setblock 292 37 285 minecraft:light[level=12]
setblock 292 37 292 minecraft:light[level=12]
setblock 292 37 299 minecraft:light[level=12]
setblock 292 37 306 minecraft:light[level=12]
setblock 292 37 313 minecraft:light[level=12]
fill 295 37 317 295 61 317 minecraft:iron_block
setblock 299 37 278 minecraft:light[level=12]
setblock 299 37 285 minecraft:light[level=12]
setblock 299 37 292 minecraft:light[level=12]
setblock 299 37 299 minecraft:light[level=12]
setblock 299 37 306 minecraft:light[level=12]
setblock 299 37 313 minecraft:light[level=12]
fill 299 37 314 299 52 314 minecraft:iron_block
fill 301 37 296 319 37 296 minecraft:iron_block
setblock 306 37 278 minecraft:light[level=12]
setblock 306 37 285 minecraft:light[level=12]
setblock 306 37 292 minecraft:light[level=12]
setblock 306 37 299 minecraft:light[level=12]
setblock 306 37 306 minecraft:light[level=12]
setblock 306 37 313 minecraft:light[level=12]
setblock 313 37 278 minecraft:light[level=12]
setblock 313 37 285 minecraft:light[level=12]
setblock 313 37 292 minecraft:light[level=12]
setblock 313 37 299 minecraft:light[level=12]
setblock 313 37 306 minecraft:light[level=12]
setblock 313 37 313 minecraft:light[level=12]
setblock 320 37 278 minecraft:light[level=12]
setblock 320 37 285 minecraft:light[level=12]
setblock 320 37 292 minecraft:light[level=12]
setblock 320 37 299 minecraft:light[level=12]
setblock 320 37 306 minecraft:light[level=12]
setblock 320 37 313 minecraft:light[level=12]
fill 324 37 276 324 39 280 minecraft:iron_block
fill 324 37 282 324 40 282 minecraft:iron_block
fill 324 37 287 324 37 290 minecraft:iron_block
fill 324 37 292 324 44 292 minecraft:iron_block
fill 324 37 297 324 39 300 minecraft:iron_block
fill 324 37 302 324 61 302 minecraft:iron_block
fill 324 37 307 324 39 310 minecraft:iron_block
fill 324 37 312 324 61 312 minecraft:iron_block
fill 283 38 281 293 38 281 minecraft:iron_block
fill 283 38 296 286 38 296 minecraft:iron_block
fill 283 38 311 288 38 311 minecraft:iron_block
fill 286 38 291 295 38 291 minecraft:iron_block
fill 287 38 306 322 38 306 minecraft:iron_block
fill 292 38 286 323 38 286 minecraft:iron_block
fill 298 38 291 311 38 291 minecraft:iron_block
fill 313 38 305 313 39 305 minecraft:iron_block
fill 313 38 307 313 38 316 minecraft:iron_block
fill 324 38 287 324 39 289 minecraft:iron_block
setblock 324 38 290 minecraft:redstone_block
fill 288 39 276 288 40 315 minecraft:iron_block
setblock 292 39 278 minecraft:iron_block
setblock 292 39 280 minecraft:iron_block
fill 293 39 276 293 40 277 minecraft:iron_block
fill 293 39 281 293 40 315 minecraft:iron_block
setblock 294 39 278 minecraft:iron_block
setblock 294 39 280 minecraft:iron_block
fill 296 39 317 307 39 317 minecraft:iron_block
fill 298 39 276 298 40 279 minecraft:iron_block
fill 303 39 276 303 40 278 minecraft:iron_block
fill 307 39 291 323 39 291 minecraft:iron_block
fill 308 39 276 308 40 280 minecraft:iron_block
setblock 308 39 317 minecraft:sea_lantern
fill 309 39 317 324 39 317 minecraft:iron_block
fill 313 39 276 313 39 290 minecraft:iron_block
fill 313 39 292 313 39 304 minecraft:iron_block
fill 313 39 306 313 39 310 minecraft:iron_block
fill 318 39 276 318 40 278 minecraft:iron_block
fill 318 39 306 322 39 306 minecraft:iron_block
fill 324 39 290 324 48 290 minecraft:iron_block
fill 282 40 275 282 61 280 minecraft:iron_block
fill 282 40 281 282 40 284 minecraft:pearlescent_froglight
fill 282 40 285 282 52 290 minecraft:iron_block
fill 282 40 291 282 40 294 minecraft:pearlescent_froglight
fill 282 40 295 282 61 300 minecraft:iron_block
fill 282 40 301 282 40 304 minecraft:pearlescent_froglight
fill 282 40 305 282 61 310 minecraft:iron_block
fill 282 40 311 282 40 314 minecraft:pearlescent_froglight
fill 282 40 315 282 53 317 minecraft:iron_block
fill 283 40 275 284 61 275 minecraft:iron_block
fill 283 40 317 285 61 317 minecraft:iron_block
fill 285 40 275 288 40 275 minecraft:pearlescent_froglight
fill 286 40 317 289 40 317 minecraft:pearlescent_froglight
fill 289 40 275 291 60 275 minecraft:iron_block
fill 290 40 317 294 61 317 minecraft:iron_block
setblock 292 40 275 minecraft:redstone_block
fill 293 40 275 294 61 275 minecraft:iron_block
fill 295 40 275 298 40 275 minecraft:pearlescent_froglight
fill 296 40 317 299 40 317 minecraft:pearlescent_froglight
fill 298 40 280 298 40 290 minecraft:iron_block
fill 298 40 298 298 40 315 minecraft:iron_block
fill 299 40 275 304 61 275 minecraft:iron_block
fill 300 40 317 305 42 317 minecraft:iron_block
fill 302 40 276 302 41 278 minecraft:iron_block
fill 303 40 279 303 40 306 minecraft:iron_block
fill 305 40 275 308 40 275 minecraft:pearlescent_froglight
fill 306 40 317 309 40 317 minecraft:pearlescent_froglight
fill 308 40 281 308 40 315 minecraft:iron_block
fill 309 40 275 312 50 275 minecraft:iron_block
fill 310 40 317 315 61 317 minecraft:iron_block
setblock 313 40 275 minecraft:redstone_block
fill 313 40 276 313 40 278 minecraft:iron_block
fill 314 40 275 314 61 275 minecraft:iron_block
fill 315 40 275 318 40 275 minecraft:pearlescent_froglight
fill 316 40 317 319 40 317 minecraft:pearlescent_froglight
fill 318 40 279 318 40 305 minecraft:iron_block
fill 319 40 275 324 48 275 minecraft:iron_block
fill 320 40 317 324 61 317 minecraft:iron_block
fill 324 40 276 324 40 279 minecraft:pearlescent_froglight
fill 324 40 280 324 61 280 minecraft:iron_block
fill 324 40 283 324 61 285 minecraft:iron_block
fill 324 40 286 324 40 289 minecraft:pearlescent_froglight
fill 324 40 293 324 61 295 minecraft:iron_block
fill 324 40 296 324 40 299 minecraft:pearlescent_froglight
fill 324 40 300 324 61 300 minecraft:iron_block
fill 324 40 303 324 47 305 minecraft:iron_block
fill 324 40 306 324 40 309 minecraft:pearlescent_froglight
fill 324 40 310 324 61 310 minecraft:iron_block
fill 324 40 313 324 44 315 minecraft:iron_block
setblock 324 40 316 minecraft:pearlescent_froglight
fill 282 41 281 282 48 284 minecraft:iron_block
fill 282 41 291 282 48 294 minecraft:iron_block
fill 282 41 301 282 48 304 minecraft:iron_block
fill 282 41 311 282 48 314 minecraft:iron_block
fill 285 41 275 288 47 275 minecraft:iron_block
setblock 285 41 278 minecraft:light[level=15]
setblock 285 41 286 minecraft:light[level=15]
setblock 285 41 294 minecraft:light[level=15]
setblock 285 41 302 minecraft:light[level=15]
setblock 285 41 310 minecraft:light[level=15]
fill 286 41 317 289 48 317 minecraft:iron_block
fill 292 41 275 292 51 275 minecraft:iron_block
setblock 293 41 286 minecraft:light[level=15]
setblock 293 41 294 minecraft:light[level=15]
setblock 293 41 302 minecraft:light[level=15]
setblock 293 41 310 minecraft:light[level=15]
fill 295 41 275 298 48 275 minecraft:iron_block
fill 296 41 317 299 48 317 minecraft:iron_block
fill 298 41 314 298 41 315 minecraft:iron_block
setblock 301 41 278 minecraft:light[level=15]
setblock 301 41 286 minecraft:light[level=15]
setblock 301 41 294 minecraft:light[level=15]
setblock 301 41 302 minecraft:light[level=15]
setblock 301 41 310 minecraft:light[level=15]
fill 303 41 302 303 41 316 minecraft:iron_block
fill 305 41 275 308 43 275 minecraft:iron_block
fill 306 41 317 309 48 317 minecraft:iron_block
setblock 309 41 278 minecraft:light[level=15]
setblock 309 41 286 minecraft:light[level=15]
setblock 309 41 294 minecraft:light[level=15]
setblock 309 41 302 minecraft:light[level=15]
setblock 309 41 310 minecraft:light[level=15]
fill 313 41 275 313 61 275 minecraft:iron_block
fill 315 41 275 318 48 275 minecraft:iron_block
fill 316 41 317 319 48 317 minecraft:iron_block
setblock 317 41 278 minecraft:light[level=15]
setblock 317 41 286 minecraft:light[level=15]
setblock 317 41 294 minecraft:light[level=15]
setblock 317 41 302 minecraft:light[level=15]
setblock 317 41 310 minecraft:light[level=15]
fill 318 41 301 318 41 316 minecraft:iron_block
fill 324 41 276 324 48 279 minecraft:iron_block
setblock 324 41 282 minecraft:sea_lantern
fill 324 41 286 324 48 289 minecraft:iron_block
fill 324 41 296 324 48 299 minecraft:iron_block
fill 324 41 306 324 48 309 minecraft:iron_block
fill 324 41 316 324 48 316 minecraft:iron_block
setblock 283 42 278 minecraft:iron_block
setblock 283 42 288 minecraft:iron_block
setblock 283 42 298 minecraft:iron_block
setblock 283 42 308 minecraft:iron_block
setblock 285 42 316 minecraft:iron_block
setblock 289 42 276 minecraft:iron_block
setblock 295 42 316 minecraft:iron_block
setblock 299 42 276 minecraft:iron_block
setblock 305 42 316 minecraft:iron_block
setblock 309 42 276 minecraft:iron_block
setblock 315 42 316 minecraft:iron_block
fill 318 42 304 318 42 306 minecraft:iron_block
setblock 319 42 276 minecraft:iron_block
fill 319 42 304 320 42 304 minecraft:iron_block
fill 319 42 306 320 42 306 minecraft:iron_block
setblock 320 42 305 minecraft:iron_block
fill 323 42 282 324 42 282 minecraft:iron_block
setblock 323 42 292 minecraft:iron_block
setblock 323 42 302 minecraft:iron_block
setblock 323 42 312 minecraft:iron_block
setblock 285 43 278 minecraft:light[level=12]
setblock 285 43 285 minecraft:light[level=12]
setblock 285 43 292 minecraft:light[level=12]
setblock 285 43 299 minecraft:light[level=12]
setblock 285 43 306 minecraft:light[level=12]
setblock 285 43 313 minecraft:light[level=12]
setblock 292 43 278 minecraft:light[level=12]
setblock 292 43 285 minecraft:light[level=12]
setblock 292 43 292 minecraft:light[level=12]
setblock 292 43 299 minecraft:light[level=12]
setblock 292 43 306 minecraft:light[level=12]
setblock 292 43 313 minecraft:light[level=12]
setblock 299 43 278 minecraft:light[level=12]
setblock 299 43 285 minecraft:light[level=12]
setblock 299 43 292 minecraft:light[level=12]
setblock 299 43 299 minecraft:light[level=12]
setblock 299 43 306 minecraft:light[level=12]
setblock 299 43 313 minecraft:light[level=12]
fill 300 43 317 303 61 317 minecraft:iron_block
setblock 304 43 317 minecraft:sea_lantern
fill 305 43 317 305 61 317 minecraft:iron_block
setblock 306 43 278 minecraft:light[level=12]
setblock 306 43 285 minecraft:light[level=12]
setblock 306 43 292 minecraft:light[level=12]
setblock 306 43 299 minecraft:light[level=12]
setblock 306 43 306 minecraft:light[level=12]
setblock 306 43 313 minecraft:light[level=12]
setblock 313 43 278 minecraft:light[level=12]
setblock 313 43 285 minecraft:light[level=12]
setblock 313 43 292 minecraft:light[level=12]
setblock 313 43 299 minecraft:light[level=12]
setblock 313 43 306 minecraft:light[level=12]
setblock 313 43 313 minecraft:light[level=12]
setblock 320 43 278 minecraft:light[level=12]
setblock 320 43 285 minecraft:light[level=12]
setblock 320 43 292 minecraft:light[level=12]
setblock 320 43 299 minecraft:light[level=12]
setblock 320 43 306 minecraft:light[level=12]
setblock 320 43 313 minecraft:light[level=12]
fill 324 43 282 324 61 282 minecraft:iron_block
fill 304 44 317 304 61 317 minecraft:iron_block
fill 305 44 275 306 48 275 minecraft:iron_block
setblock 307 44 275 minecraft:sea_lantern
fill 308 44 275 308 48 275 minecraft:iron_block
fill 283 45 280 283 45 283 minecraft:iron_block
fill 283 45 290 283 45 293 minecraft:iron_block
fill 283 45 300 283 45 303 minecraft:iron_block
fill 283 45 310 283 45 313 minecraft:iron_block
fill 284 45 276 287 45 276 minecraft:iron_block
fill 287 45 316 290 45 316 minecraft:iron_block
fill 294 45 276 297 45 276 minecraft:iron_block
fill 297 45 316 300 45 316 minecraft:iron_block
fill 304 45 276 307 45 276 minecraft:iron_block
fill 307 45 275 307 48 275 minecraft:iron_block
fill 307 45 316 310 45 316 minecraft:iron_block
fill 314 45 276 317 45 276 minecraft:iron_block
fill 317 45 316 320 45 316 minecraft:iron_block
fill 323 45 277 323 45 280 minecraft:iron_block
fill 323 45 287 323 45 290 minecraft:iron_block
fill 323 45 297 323 45 300 minecraft:iron_block
fill 323 45 307 323 45 310 minecraft:iron_block
setblock 324 45 292 minecraft:sea_lantern
fill 324 45 313 324 61 313 minecraft:iron_block
setblock 324 45 314 minecraft:redstone_block
fill 324 45 315 324 61 315 minecraft:iron_block
fill 283 46 301 284 47 302 minecraft:iron_block
fill 285 46 301 289 47 301 minecraft:iron_block
fill 324 46 292 324 61 292 minecraft:iron_block
fill 324 46 314 324 61 314 minecraft:iron_block
fill 285 47 302 292 47 302 minecraft:iron_block
fill 290 47 301 302 48 301 minecraft:iron_block
setblock 292 47 278 minecraft:iron_block
setblock 292 47 280 minecraft:iron_block
setblock 294 47 278 minecraft:iron_block
setblock 294 47 280 minecraft:iron_block
setblock 283 48 278 minecraft:iron_block
setblock 283 48 288 minecraft:iron_block
setblock 283 48 298 minecraft:iron_block
fill 283 48 301 289 48 301 minecraft:light_gray_concrete
setblock 283 48 308 minecraft:iron_block
fill 285 48 275 287 48 275 minecraft:iron_block
setblock 285 48 316 minecraft:iron_block
setblock 288 48 275 minecraft:sea_lantern
setblock 289 48 276 minecraft:iron_block
setblock 295 48 316 minecraft:iron_block
fill 297 48 300 314 48 300 minecraft:iron_block
setblock 299 48 276 minecraft:iron_block
fill 303 48 301 313 49 301 minecraft:iron_block
setblock 305 48 316 minecraft:iron_block
setblock 309 48 276 minecraft:iron_block
setblock 315 48 316 minecraft:iron_block
setblock 319 48 276 minecraft:iron_block
setblock 323 48 282 minecraft:iron_block
setblock 323 48 292 minecraft:iron_block
setblock 323 48 302 minecraft:iron_block
setblock 323 48 312 minecraft:iron_block
fill 324 48 303 324 61 303 minecraft:iron_block
setblock 324 48 304 minecraft:sea_lantern
fill 324 48 305 324 61 305 minecraft:iron_block
fill 282 49 281 282 49 284 minecraft:pearlescent_froglight
fill 282 49 291 282 49 294 minecraft:pearlescent_froglight
fill 282 49 301 282 49 304 minecraft:pearlescent_froglight
fill 282 49 311 282 49 314 minecraft:pearlescent_froglight
fill 285 49 275 288 49 275 minecraft:pearlescent_froglight
setblock 285 49 278 minecraft:light[level=15]
setblock 285 49 285 minecraft:light[level=12]
setblock 285 49 286 minecraft:light[level=15]
setblock 285 49 292 minecraft:light[level=12]
setblock 285 49 294 minecraft:light[level=15]
setblock 285 49 299 minecraft:light[level=12]
setblock 285 49 302 minecraft:light[level=15]
setblock 285 49 306 minecraft:light[level=12]
setblock 285 49 310 minecraft:light[level=15]
setblock 285 49 313 minecraft:light[level=12]
fill 286 49 317 289 49 317 minecraft:pearlescent_froglight
fill 290 49 301 302 49 301 minecraft:light_gray_concrete
setblock 292 49 278 minecraft:light[level=12]
setblock 292 49 285 minecraft:light[level=12]
setblock 292 49 292 minecraft:light[level=12]
setblock 292 49 299 minecraft:light[level=12]
setblock 292 49 306 minecraft:light[level=12]
setblock 292 49 313 minecraft:light[level=12]
setblock 293 49 286 minecraft:light[level=15]
setblock 293 49 294 minecraft:light[level=15]
setblock 293 49 302 minecraft:light[level=15]
setblock 293 49 310 minecraft:light[level=15]
fill 295 49 275 298 49 275 minecraft:pearlescent_froglight
fill 296 49 317 299 49 317 minecraft:pearlescent_froglight
setblock 299 49 278 minecraft:light[level=12]
setblock 299 49 285 minecraft:light[level=12]
setblock 299 49 292 minecraft:light[level=12]
setblock 299 49 299 minecraft:light[level=12]
setblock 299 49 306 minecraft:light[level=12]
setblock 299 49 313 minecraft:light[level=12]
setblock 301 49 278 minecraft:light[level=15]
setblock 301 49 286 minecraft:light[level=15]
setblock 301 49 294 minecraft:light[level=15]
setblock 301 49 302 minecraft:light[level=15]
setblock 301 49 310 minecraft:light[level=15]
fill 305 49 275 308 49 275 minecraft:pearlescent_froglight
setblock 306 49 278 minecraft:light[level=12]
setblock 306 49 285 minecraft:light[level=12]
setblock 306 49 292 minecraft:light[level=12]
setblock 306 49 299 minecraft:light[level=12]
fill 306 49 300 323 49 300 minecraft:iron_block
setblock 306 49 306 minecraft:light[level=12]
setblock 306 49 313 minecraft:light[level=12]
fill 306 49 317 309 49 317 minecraft:pearlescent_froglight
setblock 309 49 278 minecraft:light[level=15]
setblock 309 49 286 minecraft:light[level=15]
setblock 309 49 294 minecraft:light[level=15]
setblock 309 49 302 minecraft:light[level=15]
setblock 309 49 310 minecraft:light[level=15]
setblock 313 49 278 minecraft:light[level=12]
setblock 313 49 285 minecraft:light[level=12]
setblock 313 49 292 minecraft:light[level=12]
setblock 313 49 299 minecraft:light[level=12]
setblock 313 49 306 minecraft:light[level=12]
setblock 313 49 313 minecraft:light[level=12]
fill 314 49 301 322 49 301 minecraft:iron_block
fill 315 49 275 318 49 275 minecraft:pearlescent_froglight
fill 316 49 317 319 49 317 minecraft:pearlescent_froglight
setblock 317 49 278 minecraft:light[level=15]
setblock 317 49 286 minecraft:light[level=15]
setblock 317 49 294 minecraft:light[level=15]
setblock 317 49 302 minecraft:light[level=15]
setblock 317 49 310 minecraft:light[level=15]
fill 318 49 304 318 49 306 minecraft:iron_block
fill 319 49 275 322 61 275 minecraft:iron_block
fill 319 49 304 320 49 304 minecraft:iron_block
fill 319 49 306 320 49 306 minecraft:iron_block
setblock 320 49 278 minecraft:light[level=12]
setblock 320 49 285 minecraft:light[level=12]
setblock 320 49 292 minecraft:light[level=12]
setblock 320 49 299 minecraft:light[level=12]
setblock 320 49 305 minecraft:iron_block
setblock 320 49 313 minecraft:light[level=12]
setblock 323 49 275 minecraft:sea_lantern
fill 324 49 275 324 61 275 minecraft:iron_block
fill 324 49 276 324 49 279 minecraft:pearlescent_froglight
fill 324 49 286 324 49 289 minecraft:pearlescent_froglight
setblock 324 49 290 minecraft:redstone_block
fill 324 49 296 324 49 299 minecraft:pearlescent_froglight
fill 324 49 304 324 61 304 minecraft:iron_block
fill 324 49 306 324 49 309 minecraft:pearlescent_froglight
setblock 324 49 316 minecraft:pearlescent_froglight
fill 282 50 281 282 57 284 minecraft:iron_block
fill 282 50 291 282 57 294 minecraft:iron_block
fill 282 50 301 282 57 304 minecraft:iron_block
fill 282 50 311 282 57 314 minecraft:iron_block
fill 285 50 275 288 57 275 minecraft:iron_block
fill 286 50 317 289 56 317 minecraft:iron_block
fill 295 50 275 298 57 275 minecraft:iron_block
fill 296 50 317 299 53 317 minecraft:iron_block
fill 305 50 275 308 57 275 minecraft:iron_block
fill 305 50 301 312 50 301 minecraft:light_gray_concrete
fill 306 50 317 309 52 317 minecraft:iron_block
fill 310 50 300 316 50 300 minecraft:light_gray_concrete
fill 315 50 275 318 57 275 minecraft:iron_block
fill 316 50 317 319 52 317 minecraft:iron_block
fill 317 50 300 323 50 300 minecraft:iron_block
fill 321 50 301 322 50 301 minecraft:iron_block
fill 323 50 275 323 61 275 minecraft:iron_block
fill 324 50 276 324 57 279 minecraft:iron_block
fill 324 50 286 324 57 290 minecraft:iron_block
fill 324 50 296 324 57 299 minecraft:iron_block
fill 324 50 306 324 57 309 minecraft:iron_block
fill 324 50 316 324 57 316 minecraft:iron_block
setblock 309 51 275 minecraft:redstone_block
fill 310 51 275 312 61 275 minecraft:iron_block
fill 318 51 300 323 51 300 minecraft:light_gray_concrete
setblock 292 52 275 minecraft:redstone_block
fill 309 52 275 309 61 275 minecraft:iron_block
fill 282 53 285 282 61 286 minecraft:iron_block
setblock 282 53 287 minecraft:redstone_block
fill 282 53 288 282 55 290 minecraft:iron_block
fill 292 53 275 292 56 275 minecraft:iron_block
fill 306 53 317 308 57 317 minecraft:iron_block
setblock 309 53 317 minecraft:sea_lantern
setblock 316 53 317 minecraft:redstone_block
fill 317 53 317 319 57 317 minecraft:iron_block
fill 282 54 287 282 61 287 minecraft:iron_block
fill 282 54 315 282 61 315 minecraft:iron_block
setblock 282 54 316 minecraft:redstone_block
fill 282 54 317 282 61 317 minecraft:iron_block
setblock 283 54 278 minecraft:iron_block
fill 283 54 280 283 54 283 minecraft:iron_block
setblock 283 54 288 minecraft:iron_block
fill 283 54 290 283 54 293 minecraft:iron_block
setblock 283 54 298 minecraft:iron_block
fill 283 54 300 283 54 303 minecraft:iron_block
setblock 283 54 308 minecraft:iron_block
fill 283 54 310 283 54 313 minecraft:iron_block
fill 284 54 276 287 54 276 minecraft:iron_block
setblock 285 54 316 minecraft:iron_block
fill 287 54 316 290 54 316 minecraft:iron_block
setblock 289 54 276 minecraft:iron_block
fill 294 54 276 297 54 276 minecraft:iron_block
setblock 295 54 316 minecraft:iron_block
fill 296 54 317 297 57 317 minecraft:iron_block
fill 297 54 316 300 54 316 minecraft:iron_block
setblock 298 54 317 minecraft:redstone_block
setblock 299 54 276 minecraft:iron_block
fill 299 54 317 299 57 317 minecraft:iron_block
fill 304 54 276 307 54 276 minecraft:iron_block
setblock 305 54 316 minecraft:iron_block
fill 307 54 316 310 54 316 minecraft:iron_block
setblock 309 54 276 minecraft:iron_block
fill 309 54 317 309 57 317 minecraft:iron_block
fill 314 54 276 317 54 276 minecraft:iron_block
setblock 315 54 316 minecraft:iron_block
fill 316 54 317 316 57 317 minecraft:iron_block
fill 317 54 316 320 54 316 minecraft:iron_block
setblock 319 54 276 minecraft:iron_block
fill 323 54 277 323 54 280 minecraft:iron_block
setblock 323 54 282 minecraft:iron_block
fill 323 54 287 323 54 290 minecraft:iron_block
setblock 323 54 292 minecraft:iron_block
fill 323 54 297 323 54 300 minecraft:iron_block
setblock 323 54 302 minecraft:iron_block
fill 323 54 307 323 54 310 minecraft:iron_block
setblock 323 54 312 minecraft:iron_block
fill 282 55 316 282 61 316 minecraft:iron_block
setblock 285 55 278 minecraft:light[level=12]
setblock 285 55 285 minecraft:light[level=12]
setblock 285 55 292 minecraft:light[level=12]
setblock 285 55 299 minecraft:light[level=12]
setblock 285 55 306 minecraft:light[level=12]
setblock 285 55 313 minecraft:light[level=12]
setblock 292 55 278 minecraft:iron_block
setblock 292 55 280 minecraft:iron_block
setblock 292 55 285 minecraft:light[level=12]
setblock 292 55 292 minecraft:light[level=12]
setblock 292 55 299 minecraft:light[level=12]
setblock 292 55 306 minecraft:light[level=12]
setblock 292 55 313 minecraft:light[level=12]
setblock 294 55 278 minecraft:iron_block
setblock 294 55 280 minecraft:iron_block
fill 298 55 317 298 57 317 minecraft:iron_block
setblock 299 55 278 minecraft:light[level=12]
setblock 299 55 285 minecraft:light[level=12]
setblock 299 55 292 minecraft:light[level=12]
setblock 299 55 299 minecraft:light[level=12]
setblock 299 55 306 minecraft:light[level=12]
setblock 299 55 313 minecraft:light[level=12]
setblock 306 55 278 minecraft:light[level=12]
setblock 306 55 285 minecraft:light[level=12]
setblock 306 55 292 minecraft:light[level=12]
setblock 306 55 299 minecraft:light[level=12]
setblock 306 55 306 minecraft:light[level=12]
setblock 306 55 313 minecraft:light[level=12]
setblock 313 55 278 minecraft:light[level=12]
setblock 313 55 285 minecraft:light[level=12]
setblock 313 55 292 minecraft:light[level=12]
setblock 313 55 299 minecraft:light[level=12]
setblock 313 55 306 minecraft:light[level=12]
setblock 313 55 313 minecraft:light[level=12]
setblock 320 55 278 minecraft:light[level=12]
setblock 320 55 285 minecraft:light[level=12]
setblock 320 55 292 minecraft:light[level=12]
setblock 320 55 299 minecraft:light[level=12]
setblock 320 55 306 minecraft:light[level=12]
setblock 320 55 313 minecraft:light[level=12]
fill 282 56 288 282 57 289 minecraft:iron_block
setblock 282 56 290 minecraft:redstone_block
fill 318 56 304 318 56 306 minecraft:iron_block
fill 319 56 304 320 56 304 minecraft:iron_block
fill 319 56 306 320 56 306 minecraft:iron_block
setblock 320 56 305 minecraft:iron_block
fill 282 57 290 282 61 290 minecraft:iron_block
setblock 285 57 278 minecraft:light[level=15]
setblock 285 57 286 minecraft:light[level=15]
setblock 285 57 294 minecraft:light[level=15]
setblock 285 57 302 minecraft:light[level=15]
setblock 285 57 310 minecraft:light[level=15]
setblock 286 57 317 minecraft:redstone_block
fill 287 57 317 289 57 317 minecraft:iron_block
setblock 292 57 275 minecraft:redstone_block
setblock 293 57 286 minecraft:light[level=15]
setblock 293 57 294 minecraft:light[level=15]
setblock 293 57 302 minecraft:light[level=15]
setblock 293 57 310 minecraft:light[level=15]
setblock 301 57 278 minecraft:light[level=15]
setblock 301 57 286 minecraft:light[level=15]
setblock 301 57 294 minecraft:light[level=15]
setblock 301 57 302 minecraft:light[level=15]
setblock 301 57 310 minecraft:light[level=15]
setblock 309 57 278 minecraft:light[level=15]
setblock 309 57 286 minecraft:light[level=15]
setblock 309 57 294 minecraft:light[level=15]
setblock 309 57 302 minecraft:light[level=15]
setblock 309 57 310 minecraft:light[level=15]
setblock 317 57 278 minecraft:light[level=15]
setblock 317 57 286 minecraft:light[level=15]
setblock 317 57 294 minecraft:light[level=15]
setblock 317 57 302 minecraft:light[level=15]
setblock 317 57 310 minecraft:light[level=15]
fill 282 58 281 282 58 284 minecraft:pearlescent_froglight
setblock 282 58 288 minecraft:sea_lantern
fill 282 58 289 282 61 289 minecraft:iron_block
fill 282 58 291 282 58 294 minecraft:pearlescent_froglight
fill 282 58 301 282 58 304 minecraft:pearlescent_froglight
fill 282 58 311 282 58 314 minecraft:pearlescent_froglight
fill 285 58 275 288 58 275 minecraft:pearlescent_froglight
fill 286 58 317 289 58 317 minecraft:pearlescent_froglight
fill 292 58 275 292 61 275 minecraft:iron_block
fill 295 58 275 298 58 275 minecraft:pearlescent_froglight
fill 296 58 317 299 58 317 minecraft:pearlescent_froglight
fill 305 58 275 308 58 275 minecraft:pearlescent_froglight
fill 306 58 317 309 58 317 minecraft:pearlescent_froglight
fill 315 58 275 318 58 275 minecraft:pearlescent_froglight
fill 316 58 317 319 58 317 minecraft:pearlescent_froglight
fill 324 58 276 324 58 279 minecraft:pearlescent_froglight
fill 324 58 286 324 58 289 minecraft:pearlescent_froglight
fill 324 58 290 324 61 290 minecraft:iron_block
fill 324 58 296 324 58 299 minecraft:pearlescent_froglight
fill 324 58 306 324 58 309 minecraft:pearlescent_froglight
setblock 324 58 316 minecraft:pearlescent_froglight
fill 282 59 281 282 61 284 minecraft:iron_block
fill 282 59 288 282 61 288 minecraft:iron_block
fill 282 59 291 282 61 294 minecraft:iron_block
fill 282 59 301 282 61 304 minecraft:iron_block
fill 282 59 311 282 61 314 minecraft:iron_block
fill 285 59 275 288 61 275 minecraft:iron_block
fill 286 59 317 289 61 317 minecraft:iron_block
fill 295 59 275 298 61 275 minecraft:iron_block
fill 296 59 317 299 61 317 minecraft:iron_block
fill 305 59 275 308 61 275 minecraft:iron_block
setblock 306 59 317 minecraft:redstone_block
fill 307 59 317 309 61 317 minecraft:iron_block
fill 315 59 275 318 61 275 minecraft:iron_block
fill 316 59 317 319 61 317 minecraft:iron_block
fill 324 59 276 324 61 279 minecraft:iron_block
fill 324 59 286 324 61 289 minecraft:iron_block
fill 324 59 296 324 61 299 minecraft:iron_block
fill 324 59 306 324 60 309 minecraft:iron_block
fill 324 59 316 324 61 316 minecraft:iron_block
setblock 283 60 278 minecraft:iron_block
setblock 283 60 288 minecraft:iron_block
setblock 283 60 298 minecraft:iron_block
setblock 283 60 308 minecraft:iron_block
setblock 285 60 316 minecraft:iron_block
setblock 289 60 276 minecraft:iron_block
setblock 295 60 316 minecraft:iron_block
setblock 299 60 276 minecraft:iron_block
setblock 305 60 316 minecraft:iron_block
fill 306 60 317 306 61 317 minecraft:iron_block
setblock 309 60 276 minecraft:iron_block
setblock 315 60 316 minecraft:iron_block
setblock 319 60 276 minecraft:iron_block
setblock 323 60 282 minecraft:iron_block
setblock 323 60 292 minecraft:iron_block
setblock 323 60 302 minecraft:iron_block
setblock 323 60 312 minecraft:iron_block
setblock 285 61 278 minecraft:light[level=12]
setblock 285 61 285 minecraft:light[level=12]
setblock 285 61 292 minecraft:light[level=12]
setblock 285 61 299 minecraft:light[level=12]
setblock 285 61 306 minecraft:light[level=12]
setblock 285 61 313 minecraft:light[level=12]
setblock 289 61 275 minecraft:sea_lantern
fill 290 61 275 291 61 275 minecraft:iron_block
setblock 292 61 278 minecraft:light[level=12]
setblock 292 61 285 minecraft:light[level=12]
setblock 292 61 292 minecraft:light[level=12]
setblock 292 61 299 minecraft:light[level=12]
setblock 292 61 306 minecraft:light[level=12]
setblock 292 61 313 minecraft:light[level=12]
setblock 299 61 278 minecraft:light[level=12]
setblock 299 61 285 minecraft:light[level=12]
setblock 299 61 292 minecraft:light[level=12]
setblock 299 61 299 minecraft:light[level=12]
setblock 299 61 306 minecraft:light[level=12]
setblock 299 61 313 minecraft:light[level=12]
setblock 306 61 278 minecraft:light[level=12]
setblock 306 61 285 minecraft:light[level=12]
setblock 306 61 292 minecraft:light[level=12]
setblock 306 61 299 minecraft:light[level=12]
setblock 306 61 306 minecraft:light[level=12]
setblock 306 61 313 minecraft:light[level=12]
setblock 313 61 278 minecraft:light[level=12]
setblock 313 61 285 minecraft:light[level=12]
setblock 313 61 292 minecraft:light[level=12]
setblock 313 61 299 minecraft:light[level=12]
setblock 313 61 306 minecraft:light[level=12]
setblock 313 61 313 minecraft:light[level=12]
fill 317 61 280 317 68 280 minecraft:iron_block
setblock 320 61 278 minecraft:light[level=12]
setblock 320 61 285 minecraft:light[level=12]
setblock 320 61 292 minecraft:light[level=12]
setblock 320 61 299 minecraft:light[level=12]
setblock 320 61 306 minecraft:light[level=12]
setblock 320 61 313 minecraft:light[level=12]
fill 324 61 306 324 61 307 minecraft:iron_block
setblock 324 61 308 minecraft:redstone_block
setblock 324 61 309 minecraft:iron_block
fill 282 62 275 282 63 276 minecraft:yellow_concrete
fill 282 62 277 282 63 278 minecraft:black_concrete
fill 282 62 279 282 63 280 minecraft:yellow_concrete
fill 282 62 281 282 63 282 minecraft:black_concrete
fill 282 62 283 282 63 284 minecraft:yellow_concrete
fill 282 62 285 282 63 286 minecraft:black_concrete
fill 282 62 287 282 63 288 minecraft:yellow_concrete
fill 282 62 289 282 63 290 minecraft:black_concrete
fill 282 62 291 282 63 292 minecraft:yellow_concrete
fill 282 62 293 282 63 294 minecraft:black_concrete
fill 282 62 295 282 63 296 minecraft:yellow_concrete
fill 282 62 297 282 63 298 minecraft:black_concrete
fill 282 62 299 282 63 300 minecraft:yellow_concrete
fill 282 62 301 282 63 302 minecraft:black_concrete
fill 282 62 303 282 63 304 minecraft:yellow_concrete
fill 282 62 305 282 63 306 minecraft:black_concrete
fill 282 62 307 282 63 308 minecraft:yellow_concrete
fill 282 62 309 282 63 310 minecraft:black_concrete
fill 282 62 311 282 63 312 minecraft:yellow_concrete
fill 282 62 313 282 63 314 minecraft:black_concrete
fill 282 62 315 282 63 316 minecraft:yellow_concrete
fill 282 62 317 282 63 317 minecraft:black_concrete
fill 283 62 275 283 63 275 minecraft:yellow_concrete
fill 283 62 317 283 63 317 minecraft:yellow_concrete
fill 284 62 275 285 63 275 minecraft:black_concrete
fill 284 62 317 285 63 317 minecraft:black_concrete
fill 286 62 275 287 63 275 minecraft:yellow_concrete
fill 286 62 317 287 63 317 minecraft:yellow_concrete
fill 288 62 275 289 63 275 minecraft:black_concrete
fill 288 62 317 289 63 317 minecraft:black_concrete
fill 290 62 275 291 63 275 minecraft:yellow_concrete
fill 290 62 317 291 63 317 minecraft:yellow_concrete
fill 292 62 275 293 63 275 minecraft:black_concrete
fill 292 62 317 293 63 317 minecraft:black_concrete
fill 294 62 275 295 63 275 minecraft:yellow_concrete
fill 294 62 317 295 63 317 minecraft:yellow_concrete
fill 296 62 275 297 63 275 minecraft:black_concrete
fill 296 62 317 297 63 317 minecraft:black_concrete
fill 298 62 275 299 63 275 minecraft:yellow_concrete
fill 298 62 317 299 63 317 minecraft:yellow_concrete
fill 300 62 275 301 63 275 minecraft:black_concrete
fill 300 62 317 301 63 317 minecraft:black_concrete
fill 302 62 275 303 63 275 minecraft:yellow_concrete
fill 302 62 317 303 63 317 minecraft:yellow_concrete
fill 304 62 275 305 63 275 minecraft:black_concrete
fill 304 62 317 305 63 317 minecraft:black_concrete
fill 306 62 275 307 63 275 minecraft:yellow_concrete
fill 306 62 317 307 63 317 minecraft:yellow_concrete
fill 308 62 275 309 63 275 minecraft:black_concrete
fill 308 62 317 309 63 317 minecraft:black_concrete
fill 310 62 275 311 63 275 minecraft:yellow_concrete
fill 310 62 317 311 63 317 minecraft:yellow_concrete
fill 312 62 275 313 63 275 minecraft:black_concrete
fill 312 62 317 313 63 317 minecraft:black_concrete
fill 314 62 275 315 63 275 minecraft:yellow_concrete
fill 314 62 317 315 63 317 minecraft:yellow_concrete
fill 316 62 275 317 63 275 minecraft:black_concrete
fill 316 62 317 317 63 317 minecraft:black_concrete
fill 318 62 275 319 63 275 minecraft:yellow_concrete
fill 318 62 317 319 63 317 minecraft:yellow_concrete
fill 320 62 275 321 63 275 minecraft:black_concrete
fill 320 62 317 321 63 317 minecraft:black_concrete
fill 322 62 275 323 63 275 minecraft:yellow_concrete
fill 322 62 317 323 63 317 minecraft:yellow_concrete
fill 324 62 275 324 63 275 minecraft:black_concrete
fill 324 62 276 324 63 276 minecraft:yellow_concrete
fill 324 62 277 324 63 278 minecraft:black_concrete
fill 324 62 279 324 63 280 minecraft:yellow_concrete
fill 324 62 281 324 63 282 minecraft:black_concrete
fill 324 62 283 324 63 284 minecraft:yellow_concrete
fill 324 62 285 324 63 286 minecraft:black_concrete
fill 324 62 287 324 63 288 minecraft:yellow_concrete
fill 324 62 289 324 63 290 minecraft:black_concrete
fill 324 62 291 324 63 292 minecraft:yellow_concrete
fill 324 62 293 324 63 294 minecraft:black_concrete
fill 324 62 295 324 63 296 minecraft:yellow_concrete
fill 324 62 297 324 63 298 minecraft:black_concrete
fill 324 62 299 324 63 300 minecraft:yellow_concrete
fill 324 62 301 324 63 302 minecraft:black_concrete
fill 324 62 303 324 63 304 minecraft:yellow_concrete
fill 324 62 305 324 63 306 minecraft:black_concrete
fill 324 62 307 324 63 308 minecraft:yellow_concrete
fill 324 62 309 324 63 310 minecraft:black_concrete
fill 324 62 311 324 63 312 minecraft:yellow_concrete
fill 324 62 313 324 63 314 minecraft:black_concrete
fill 324 62 315 324 63 316 minecraft:yellow_concrete
fill 324 62 317 324 63 317 minecraft:black_concrete
fill 283 63 280 283 63 283 minecraft:iron_block
fill 283 63 290 283 63 293 minecraft:iron_block
fill 283 63 300 283 63 303 minecraft:iron_block
fill 283 63 310 283 63 313 minecraft:iron_block
fill 284 63 276 287 63 276 minecraft:iron_block
fill 287 63 316 290 63 316 minecraft:iron_block
setblock 292 63 278 minecraft:iron_block
setblock 292 63 280 minecraft:iron_block
fill 294 63 276 297 63 276 minecraft:iron_block
setblock 294 63 278 minecraft:iron_block
setblock 294 63 280 minecraft:iron_block
fill 297 63 316 300 63 316 minecraft:iron_block
fill 304 63 276 307 63 276 minecraft:iron_block
fill 307 63 316 310 63 316 minecraft:iron_block
fill 314 63 276 317 63 276 minecraft:iron_block
fill 317 63 316 320 63 316 minecraft:iron_block
fill 318 63 304 318 63 306 minecraft:iron_block
fill 319 63 304 320 63 304 minecraft:iron_block
fill 319 63 306 320 63 306 minecraft:iron_block
setblock 320 63 305 minecraft:iron_block
fill 323 63 277 323 63 280 minecraft:iron_block
fill 323 63 287 323 63 290 minecraft:iron_block
fill 323 63 297 323 63 300 minecraft:iron_block
fill 323 63 307 323 63 310 minecraft:iron_block
fill 282 64 275 282 65 317 minecraft:iron_block
fill 283 64 275 324 66 275 minecraft:iron_block
fill 283 64 317 324 64 317 minecraft:iron_block
fill 324 64 276 324 66 316 minecraft:iron_block
fill 283 65 317 283 89 317 minecraft:iron_block
setblock 284 65 317 minecraft:sea_lantern
setblock 285 65 278 minecraft:light[level=15]
setblock 285 65 286 minecraft:light[level=15]
setblock 285 65 294 minecraft:light[level=15]
setblock 285 65 302 minecraft:light[level=15]
setblock 285 65 310 minecraft:light[level=15]
fill 285 65 317 324 66 317 minecraft:iron_block
setblock 293 65 286 minecraft:light[level=15]
setblock 293 65 294 minecraft:light[level=15]
setblock 293 65 302 minecraft:light[level=15]
setblock 293 65 310 minecraft:light[level=15]
setblock 301 65 278 minecraft:light[level=15]
setblock 301 65 286 minecraft:light[level=15]
setblock 301 65 294 minecraft:light[level=15]
setblock 301 65 302 minecraft:light[level=15]
setblock 301 65 310 minecraft:light[level=15]
setblock 309 65 278 minecraft:light[level=15]
setblock 309 65 286 minecraft:light[level=15]
setblock 309 65 294 minecraft:light[level=15]
setblock 309 65 302 minecraft:light[level=15]
setblock 309 65 310 minecraft:light[level=15]
setblock 317 65 278 minecraft:light[level=15]
setblock 317 65 286 minecraft:light[level=15]
setblock 317 65 294 minecraft:light[level=15]
setblock 317 65 302 minecraft:light[level=15]
setblock 317 65 310 minecraft:light[level=15]
fill 282 66 275 282 66 293 minecraft:iron_block
setblock 282 66 294 minecraft:sea_lantern
fill 282 66 295 282 89 298 minecraft:iron_block
setblock 282 66 299 minecraft:sea_lantern
fill 282 66 300 282 66 317 minecraft:iron_block
setblock 283 66 278 minecraft:iron_block
setblock 283 66 288 minecraft:iron_block
setblock 283 66 298 minecraft:iron_block
setblock 283 66 308 minecraft:iron_block
fill 284 66 317 284 69 317 minecraft:iron_block
setblock 285 66 316 minecraft:iron_block
setblock 289 66 276 minecraft:iron_block
setblock 295 66 316 minecraft:iron_block
setblock 299 66 276 minecraft:iron_block
setblock 305 66 316 minecraft:iron_block
setblock 309 66 276 minecraft:iron_block
fill 311 66 314 311 81 314 minecraft:iron_block
setblock 315 66 316 minecraft:iron_block
setblock 319 66 276 minecraft:iron_block
setblock 323 66 282 minecraft:iron_block
setblock 323 66 292 minecraft:iron_block
setblock 323 66 302 minecraft:iron_block
setblock 323 66 312 minecraft:iron_block
fill 282 67 275 282 76 280 minecraft:iron_block
fill 282 67 281 282 67 284 minecraft:pearlescent_froglight
fill 282 67 285 282 70 290 minecraft:iron_block
fill 282 67 291 282 67 294 minecraft:pearlescent_froglight
fill 282 67 299 282 89 300 minecraft:iron_block
fill 282 67 301 282 67 304 minecraft:pearlescent_froglight
fill 282 67 305 282 89 310 minecraft:iron_block
fill 282 67 311 282 67 314 minecraft:pearlescent_froglight
fill 282 67 315 282 89 317 minecraft:iron_block
fill 283 67 275 284 78 275 minecraft:iron_block
fill 285 67 275 288 67 275 minecraft:pearlescent_froglight
setblock 285 67 278 minecraft:light[level=12]
setblock 285 67 285 minecraft:light[level=12]
setblock 285 67 292 minecraft:light[level=12]
setblock 285 67 299 minecraft:light[level=12]
setblock 285 67 306 minecraft:light[level=12]
setblock 285 67 313 minecraft:light[level=12]
fill 285 67 317 285 89 317 minecraft:iron_block
fill 286 67 317 289 67 317 minecraft:pearlescent_froglight
fill 289 67 275 294 89 275 minecraft:iron_block
fill 290 67 317 295 83 317 minecraft:iron_block
setblock 292 67 278 minecraft:light[level=12]
setblock 292 67 285 minecraft:light[level=12]
setblock 292 67 292 minecraft:light[level=12]
setblock 292 67 299 minecraft:light[level=12]
setblock 292 67 306 minecraft:light[level=12]
setblock 292 67 313 minecraft:light[level=12]
fill 295 67 275 298 67 275 minecraft:pearlescent_froglight
fill 296 67 317 299 67 317 minecraft:pearlescent_froglight
fill 299 67 275 304 89 275 minecraft:iron_block
setblock 299 67 278 minecraft:light[level=12]
setblock 299 67 285 minecraft:light[level=12]
setblock 299 67 292 minecraft:light[level=12]
setblock 299 67 299 minecraft:light[level=12]
setblock 299 67 306 minecraft:light[level=12]
setblock 299 67 313 minecraft:light[level=12]
fill 300 67 317 305 89 317 minecraft:iron_block
fill 305 67 275 308 67 275 minecraft:pearlescent_froglight
setblock 306 67 278 minecraft:light[level=12]
setblock 306 67 285 minecraft:light[level=12]
setblock 306 67 292 minecraft:light[level=12]
setblock 306 67 299 minecraft:light[level=12]
setblock 306 67 306 minecraft:light[level=12]
setblock 306 67 313 minecraft:light[level=12]
fill 306 67 317 309 67 317 minecraft:pearlescent_froglight
fill 309 67 275 314 80 275 minecraft:iron_block
fill 310 67 317 315 79 317 minecraft:iron_block
setblock 313 67 278 minecraft:light[level=12]
setblock 313 67 285 minecraft:light[level=12]
setblock 313 67 292 minecraft:light[level=12]
setblock 313 67 299 minecraft:light[level=12]
setblock 313 67 306 minecraft:light[level=12]
setblock 313 67 313 minecraft:light[level=12]
fill 315 67 275 318 67 275 minecraft:pearlescent_froglight
fill 316 67 317 319 67 317 minecraft:pearlescent_froglight
fill 319 67 275 324 75 275 minecraft:iron_block
setblock 320 67 278 minecraft:light[level=12]
setblock 320 67 285 minecraft:light[level=12]
setblock 320 67 292 minecraft:light[level=12]
setblock 320 67 299 minecraft:light[level=12]
setblock 320 67 306 minecraft:light[level=12]
setblock 320 67 313 minecraft:light[level=12]
fill 320 67 317 324 74 317 minecraft:iron_block
fill 324 67 276 324 67 279 minecraft:pearlescent_froglight
fill 324 67 280 324 69 285 minecraft:iron_block
fill 324 67 286 324 67 289 minecraft:pearlescent_froglight
fill 324 67 290 324 89 295 minecraft:iron_block
fill 324 67 296 324 67 299 minecraft:pearlescent_froglight
fill 324 67 300 324 89 305 minecraft:iron_block
fill 324 67 306 324 67 309 minecraft:pearlescent_froglight
fill 324 67 310 324 89 315 minecraft:iron_block
setblock 324 67 316 minecraft:pearlescent_froglight
fill 282 68 281 282 75 284 minecraft:iron_block
fill 282 68 291 282 75 294 minecraft:iron_block
fill 282 68 301 282 75 304 minecraft:iron_block
fill 282 68 311 282 75 314 minecraft:iron_block
fill 285 68 275 288 74 275 minecraft:iron_block
fill 286 68 317 289 75 317 minecraft:iron_block
fill 295 68 275 298 75 275 minecraft:iron_block
fill 296 68 317 299 75 317 minecraft:iron_block
fill 305 68 275 308 75 275 minecraft:iron_block
fill 306 68 317 309 75 317 minecraft:iron_block
fill 315 68 275 318 75 275 minecraft:iron_block
fill 316 68 317 319 75 317 minecraft:iron_block
fill 324 68 276 324 75 279 minecraft:iron_block
fill 324 68 286 324 75 289 minecraft:iron_block
fill 324 68 296 324 75 299 minecraft:iron_block
fill 324 68 306 324 75 309 minecraft:iron_block
fill 324 68 316 324 75 316 minecraft:iron_block
setblock 284 70 317 minecraft:redstone_block
fill 318 70 304 318 70 306 minecraft:iron_block
fill 319 70 304 320 70 304 minecraft:iron_block
fill 319 70 306 320 70 306 minecraft:iron_block
setblock 320 70 305 minecraft:iron_block
fill 324 70 280 324 81 283 minecraft:iron_block
setblock 324 70 284 minecraft:sea_lantern
fill 324 70 285 324 89 285 minecraft:iron_block
fill 282 71 285 282 89 287 minecraft:iron_block
setblock 282 71 288 minecraft:redstone_block
fill 282 71 289 282 86 290 minecraft:iron_block
fill 284 71 317 284 89 317 minecraft:iron_block
setblock 292 71 278 minecraft:iron_block
setblock 292 71 280 minecraft:iron_block
setblock 294 71 278 minecraft:iron_block
setblock 294 71 280 minecraft:iron_block
fill 324 71 284 324 89 284 minecraft:iron_block
fill 282 72 288 283 74 288 minecraft:iron_block
setblock 283 72 278 minecraft:iron_block
fill 283 72 280 283 72 283 minecraft:iron_block
fill 283 72 290 283 72 293 minecraft:iron_block
setblock 283 72 298 minecraft:iron_block
fill 283 72 300 283 72 303 minecraft:iron_block
setblock 283 72 308 minecraft:iron_block
fill 283 72 310 283 72 313 minecraft:iron_block
fill 284 72 276 287 72 276 minecraft:iron_block
setblock 285 72 316 minecraft:iron_block
fill 287 72 316 290 72 316 minecraft:iron_block
fill 288 72 295 288 73 295 minecraft:gray_concrete
setblock 289 72 276 minecraft:iron_block
fill 294 72 276 297 72 276 minecraft:iron_block
setblock 295 72 316 minecraft:iron_block
fill 297 72 281 297 73 281 minecraft:gray_concrete
fill 297 72 316 300 72 316 minecraft:iron_block
fill 298 72 310 298 73 310 minecraft:gray_concrete
setblock 299 72 276 minecraft:iron_block
fill 304 72 276 307 72 276 minecraft:iron_block
setblock 305 72 316 minecraft:iron_block
fill 307 72 316 310 72 316 minecraft:iron_block
setblock 309 72 276 minecraft:iron_block
fill 314 72 276 317 72 276 minecraft:iron_block
setblock 315 72 316 minecraft:iron_block
fill 317 72 304 317 73 304 minecraft:gray_concrete
fill 317 72 306 317 73 306 minecraft:gray_concrete
fill 317 72 316 320 72 316 minecraft:iron_block
setblock 319 72 276 minecraft:iron_block
fill 323 72 277 323 72 280 minecraft:iron_block
setblock 323 72 282 minecraft:iron_block
fill 323 72 287 323 72 290 minecraft:iron_block
setblock 323 72 292 minecraft:iron_block
fill 323 72 297 323 72 300 minecraft:iron_block
setblock 323 72 302 minecraft:iron_block
fill 323 72 307 323 72 310 minecraft:iron_block
setblock 323 72 312 minecraft:iron_block
fill 284 73 288 288 74 288 minecraft:iron_block
setblock 285 73 278 minecraft:light[level=15]
setblock 285 73 285 minecraft:light[level=12]
setblock 285 73 286 minecraft:light[level=15]
setblock 285 73 292 minecraft:light[level=12]
setblock 285 73 294 minecraft:light[level=15]
setblock 285 73 299 minecraft:light[level=12]
setblock 285 73 302 minecraft:light[level=15]
setblock 285 73 306 minecraft:light[level=12]
setblock 285 73 310 minecraft:light[level=15]
setblock 285 73 313 minecraft:light[level=12]
fill 287 73 295 287 74 295 minecraft:gray_concrete
setblock 292 73 278 minecraft:light[level=12]
setblock 292 73 285 minecraft:light[level=12]
setblock 292 73 292 minecraft:light[level=12]
setblock 292 73 299 minecraft:light[level=12]
setblock 292 73 306 minecraft:light[level=12]
setblock 292 73 313 minecraft:light[level=12]
setblock 293 73 286 minecraft:light[level=15]
setblock 293 73 294 minecraft:light[level=15]
setblock 293 73 302 minecraft:light[level=15]
setblock 293 73 310 minecraft:light[level=15]
fill 297 73 280 297 74 280 minecraft:gray_concrete
fill 298 73 311 298 74 311 minecraft:gray_concrete
setblock 299 73 278 minecraft:light[level=12]
setblock 299 73 285 minecraft:light[level=12]
setblock 299 73 292 minecraft:light[level=12]
setblock 299 73 299 minecraft:light[level=12]
setblock 299 73 306 minecraft:light[level=12]
setblock 299 73 313 minecraft:light[level=12]
setblock 301 73 278 minecraft:light[level=15]
setblock 301 73 286 minecraft:light[level=15]
setblock 301 73 294 minecraft:light[level=15]
setblock 301 73 302 minecraft:light[level=15]
setblock 301 73 310 minecraft:light[level=15]
setblock 306 73 278 minecraft:light[level=12]
setblock 306 73 285 minecraft:light[level=12]
setblock 306 73 292 minecraft:light[level=12]
setblock 306 73 299 minecraft:light[level=12]
setblock 306 73 306 minecraft:light[level=12]
setblock 306 73 313 minecraft:light[level=12]
setblock 309 73 278 minecraft:light[level=15]
setblock 309 73 286 minecraft:light[level=15]
setblock 309 73 294 minecraft:light[level=15]
setblock 309 73 302 minecraft:light[level=15]
setblock 309 73 310 minecraft:light[level=15]
setblock 313 73 278 minecraft:light[level=12]
setblock 313 73 285 minecraft:light[level=12]
setblock 313 73 292 minecraft:light[level=12]
setblock 313 73 299 minecraft:light[level=12]
setblock 313 73 306 minecraft:light[level=12]
setblock 313 73 313 minecraft:light[level=12]
setblock 317 73 278 minecraft:light[level=15]
setblock 317 73 286 minecraft:light[level=15]
setblock 317 73 294 minecraft:light[level=15]
setblock 317 73 302 minecraft:light[level=15]
setblock 317 73 310 minecraft:light[level=15]
fill 318 73 304 318 74 304 minecraft:gray_concrete
fill 318 73 306 318 74 306 minecraft:gray_concrete
setblock 320 73 278 minecraft:light[level=12]
setblock 320 73 285 minecraft:light[level=12]
setblock 320 73 292 minecraft:light[level=12]
setblock 320 73 299 minecraft:light[level=12]
setblock 320 73 306 minecraft:light[level=12]
setblock 320 73 313 minecraft:light[level=12]
fill 284 74 287 302 74 287 minecraft:iron_block
fill 286 74 295 286 75 295 minecraft:gray_concrete
fill 289 74 288 296 74 288 minecraft:iron_block
fill 297 74 279 297 75 279 minecraft:gray_concrete
fill 298 74 312 298 75 312 minecraft:gray_concrete
fill 319 74 304 319 75 304 minecraft:gray_concrete
fill 319 74 306 319 75 306 minecraft:gray_concrete
fill 282 75 288 282 89 288 minecraft:iron_block
fill 283 75 288 288 75 288 minecraft:light_gray_concrete
setblock 285 75 275 minecraft:sea_lantern
fill 285 75 295 285 76 295 minecraft:gray_concrete
fill 286 75 275 288 75 275 minecraft:iron_block
fill 291 75 287 312 75 287 minecraft:iron_block
fill 292 75 288 298 75 288 minecraft:iron_block
fill 297 75 278 297 76 278 minecraft:gray_concrete
fill 298 75 313 298 76 313 minecraft:gray_concrete
fill 300 75 286 315 75 286 minecraft:iron_block
fill 320 75 304 320 76 304 minecraft:gray_concrete
fill 320 75 306 320 76 306 minecraft:gray_concrete
fill 320 75 317 322 89 317 minecraft:iron_block
setblock 323 75 317 minecraft:redstone_block
fill 324 75 317 324 89 317 minecraft:iron_block
fill 282 76 281 282 76 284 minecraft:pearlescent_froglight
fill 282 76 291 282 76 294 minecraft:pearlescent_froglight
fill 282 76 301 282 76 304 minecraft:pearlescent_froglight
fill 282 76 311 282 76 314 minecraft:pearlescent_froglight
fill 284 76 295 284 77 295 minecraft:gray_concrete
fill 285 76 275 288 76 275 minecraft:pearlescent_froglight
fill 286 76 317 289 76 317 minecraft:pearlescent_froglight
fill 293 76 287 302 76 287 minecraft:light_gray_concrete
fill 295 76 275 298 76 275 minecraft:pearlescent_froglight
fill 296 76 317 299 76 317 minecraft:pearlescent_froglight
fill 297 76 277 297 77 277 minecraft:gray_concrete
fill 298 76 314 298 77 314 minecraft:gray_concrete
fill 303 76 287 318 76 287 minecraft:iron_block
fill 305 76 275 308 76 275 minecraft:pearlescent_froglight
fill 306 76 286 323 76 286 minecraft:iron_block
fill 306 76 317 309 76 317 minecraft:pearlescent_froglight
fill 315 76 275 318 76 275 minecraft:pearlescent_froglight
fill 316 76 317 319 76 317 minecraft:pearlescent_froglight
fill 319 76 275 320 84 275 minecraft:iron_block
fill 319 76 285 322 76 285 minecraft:iron_block
setblock 321 76 275 minecraft:redstone_block
fill 321 76 304 321 77 304 minecraft:gray_concrete
fill 321 76 306 321 77 306 minecraft:gray_concrete
fill 322 76 275 324 89 275 minecraft:iron_block
fill 323 76 317 323 89 317 minecraft:iron_block
fill 324 76 276 324 76 279 minecraft:pearlescent_froglight
fill 324 76 286 324 76 289 minecraft:pearlescent_froglight
fill 324 76 296 324 76 299 minecraft:pearlescent_froglight
fill 324 76 306 324 76 309 minecraft:pearlescent_froglight
setblock 324 76 316 minecraft:pearlescent_froglight
fill 282 77 275 282 89 275 minecraft:iron_block
setblock 282 77 276 minecraft:sea_lantern
fill 282 77 277 282 89 284 minecraft:iron_block
fill 282 77 291 282 89 294 minecraft:iron_block
fill 282 77 301 282 77 304 minecraft:iron_block
fill 282 77 311 282 89 314 minecraft:iron_block
fill 283 77 295 283 78 295 minecraft:gray_concrete
fill 285 77 275 288 89 275 minecraft:iron_block
fill 286 77 317 289 89 317 minecraft:iron_block
fill 291 77 288 291 84 288 minecraft:iron_block
fill 295 77 275 298 89 275 minecraft:iron_block
fill 296 77 317 299 89 317 minecraft:iron_block
fill 297 77 276 297 78 276 minecraft:gray_concrete
fill 298 77 315 298 78 315 minecraft:gray_concrete
fill 304 77 287 309 77 287 minecraft:light_gray_concrete
fill 305 77 275 308 79 275 minecraft:iron_block
fill 306 77 317 309 89 317 minecraft:iron_block
fill 309 77 286 315 77 286 minecraft:light_gray_concrete
fill 315 77 275 318 83 275 minecraft:iron_block
fill 316 77 286 324 77 286 minecraft:iron_block
fill 316 77 317 319 79 317 minecraft:iron_block
fill 318 77 304 318 77 306 minecraft:iron_block
fill 319 77 304 320 77 304 minecraft:iron_block
fill 319 77 306 320 77 306 minecraft:iron_block
setblock 320 77 305 minecraft:iron_block
fill 321 77 275 321 89 275 minecraft:iron_block
setblock 322 77 285 minecraft:iron_block
fill 322 77 304 322 78 304 minecraft:gray_concrete
fill 322 77 306 322 78 306 minecraft:gray_concrete
fill 324 77 276 324 89 279 minecraft:iron_block
fill 324 77 287 324 89 289 minecraft:iron_block
fill 324 77 296 324 82 296 minecraft:iron_block
setblock 324 77 297 minecraft:sea_lantern
fill 324 77 298 324 83 299 minecraft:iron_block
fill 324 77 306 324 80 309 minecraft:iron_block
fill 324 77 316 324 89 316 minecraft:iron_block
fill 282 78 276 282 89 276 minecraft:iron_block
fill 282 78 301 282 89 303 minecraft:iron_block
setblock 282 78 304 minecraft:sea_lantern
fill 283 78 278 283 79 278 minecraft:iron_block
fill 283 78 288 283 79 288 minecraft:iron_block
setblock 283 78 298 minecraft:iron_block
fill 283 78 308 283 79 308 minecraft:iron_block
fill 285 78 316 285 79 316 minecraft:iron_block
setblock 288 78 281 minecraft:pearlescent_froglight
setblock 288 78 287 minecraft:pearlescent_froglight
setblock 288 78 293 minecraft:pearlescent_froglight
setblock 288 78 299 minecraft:pearlescent_froglight
setblock 288 78 305 minecraft:pearlescent_froglight
setblock 288 78 311 minecraft:pearlescent_froglight
fill 289 78 276 289 79 276 minecraft:iron_block
fill 293 78 276 293 79 277 minecraft:iron_block
setblock 294 78 281 minecraft:pearlescent_froglight
setblock 294 78 311 minecraft:pearlescent_froglight
setblock 295 78 316 minecraft:iron_block
setblock 299 78 276 minecraft:iron_block
setblock 300 78 281 minecraft:pearlescent_froglight
setblock 300 78 311 minecraft:pearlescent_froglight
fill 305 78 316 305 79 316 minecraft:iron_block
setblock 306 78 281 minecraft:pearlescent_froglight
setblock 306 78 311 minecraft:pearlescent_froglight
fill 309 78 276 309 79 276 minecraft:iron_block
setblock 312 78 281 minecraft:pearlescent_froglight
setblock 312 78 311 minecraft:pearlescent_froglight
fill 315 78 316 315 79 316 minecraft:iron_block
fill 317 78 286 322 78 286 minecraft:light_gray_concrete
setblock 318 78 281 minecraft:pearlescent_froglight
setblock 318 78 287 minecraft:pearlescent_froglight
setblock 318 78 293 minecraft:pearlescent_froglight
setblock 318 78 299 minecraft:pearlescent_froglight
setblock 318 78 305 minecraft:pearlescent_froglight
setblock 318 78 311 minecraft:pearlescent_froglight
fill 319 78 276 319 79 276 minecraft:iron_block
setblock 323 78 282 minecraft:iron_block
fill 323 78 292 323 79 292 minecraft:iron_block
fill 323 78 302 323 79 302 minecraft:iron_block
setblock 323 78 312 minecraft:iron_block
fill 324 78 286 324 89 286 minecraft:iron_block
fill 324 78 297 324 89 297 minecraft:iron_block
fill 282 79 304 282 89 304 minecraft:iron_block
setblock 283 79 275 minecraft:sea_lantern
setblock 283 79 276 minecraft:iron_block
setblock 283 79 279 minecraft:iron_block
fill 283 79 281 283 79 282 minecraft:iron_block
fill 283 79 284 283 79 285 minecraft:iron_block
fill 283 79 290 283 79 291 minecraft:iron_block
fill 283 79 293 283 79 294 minecraft:iron_block
fill 283 79 296 284 79 296 minecraft:iron_block
fill 283 79 299 283 79 300 minecraft:iron_block
fill 283 79 302 283 79 303 minecraft:iron_block
fill 283 79 305 283 79 306 minecraft:iron_block
setblock 283 79 309 minecraft:iron_block
fill 283 79 311 283 79 312 minecraft:iron_block
fill 283 79 314 283 79 315 minecraft:iron_block
fill 284 79 275 284 88 275 minecraft:iron_block
fill 284 79 277 284 79 278 minecraft:iron_block
fill 284 79 280 284 79 281 minecraft:iron_block
fill 284 79 283 284 79 284 minecraft:iron_block
fill 284 79 286 284 79 287 minecraft:iron_block
fill 284 79 289 284 79 290 minecraft:iron_block
fill 284 79 292 284 79 293 minecraft:iron_block
fill 284 79 295 285 79 295 minecraft:iron_block
fill 284 79 298 284 79 299 minecraft:iron_block
fill 284 79 301 284 79 302 minecraft:iron_block
fill 284 79 304 284 79 305 minecraft:iron_block
fill 284 79 307 284 79 308 minecraft:iron_block
fill 284 79 310 284 79 311 minecraft:iron_block
fill 284 79 313 284 79 314 minecraft:iron_block
fill 285 79 276 285 79 277 minecraft:iron_block
setblock 285 79 278 minecraft:light[level=12]
fill 285 79 279 285 79 280 minecraft:iron_block
fill 285 79 282 285 79 283 minecraft:iron_block
fill 285 79 285 285 79 286 minecraft:iron_block
fill 285 79 288 285 79 289 minecraft:iron_block
fill 285 79 291 285 79 292 minecraft:iron_block
fill 285 79 294 286 79 294 minecraft:iron_block
fill 285 79 297 285 79 298 minecraft:iron_block
setblock 285 79 299 minecraft:light[level=12]
fill 285 79 300 285 79 301 minecraft:iron_block
fill 285 79 303 285 79 304 minecraft:iron_block
fill 285 79 306 285 79 307 minecraft:iron_block
fill 285 79 309 285 79 310 minecraft:iron_block
fill 285 79 312 285 79 313 minecraft:iron_block
fill 285 79 315 286 79 315 minecraft:iron_block
setblock 286 79 276 minecraft:iron_block
fill 286 79 278 286 79 279 minecraft:iron_block
fill 286 79 281 286 79 282 minecraft:iron_block
fill 286 79 284 286 79 285 minecraft:iron_block
fill 286 79 287 286 79 288 minecraft:iron_block
fill 286 79 290 286 79 291 minecraft:iron_block
fill 286 79 293 287 79 293 minecraft:iron_block
fill 286 79 296 286 79 297 minecraft:iron_block
fill 286 79 299 286 79 300 minecraft:iron_block
fill 286 79 302 286 79 303 minecraft:iron_block
fill 286 79 305 286 79 306 minecraft:iron_block
fill 286 79 308 286 79 309 minecraft:iron_block
fill 286 79 311 286 79 312 minecraft:iron_block
fill 286 79 314 287 79 314 minecraft:iron_block
fill 287 79 277 287 79 278 minecraft:iron_block
fill 287 79 280 287 79 281 minecraft:iron_block
fill 287 79 283 287 79 284 minecraft:iron_block
fill 287 79 286 287 79 287 minecraft:iron_block
fill 287 79 289 287 79 290 minecraft:iron_block
fill 287 79 292 288 79 292 minecraft:iron_block
fill 287 79 295 287 79 296 minecraft:iron_block
fill 287 79 298 287 79 299 minecraft:iron_block
fill 287 79 301 287 79 302 minecraft:iron_block
fill 287 79 304 287 79 305 minecraft:iron_block
fill 287 79 307 287 79 308 minecraft:iron_block
fill 287 79 310 287 79 311 minecraft:iron_block
fill 287 79 313 288 79 313 minecraft:iron_block
fill 287 79 316 288 79 316 minecraft:iron_block
fill 288 79 276 288 79 277 minecraft:iron_block
fill 288 79 279 288 79 280 minecraft:iron_block
fill 288 79 282 288 79 283 minecraft:iron_block
fill 288 79 285 288 79 286 minecraft:iron_block
fill 288 79 288 288 79 289 minecraft:iron_block
setblock 288 79 291 minecraft:iron_block
fill 288 79 294 288 79 295 minecraft:iron_block
fill 288 79 297 288 79 298 minecraft:iron_block
fill 288 79 300 288 79 301 minecraft:iron_block
fill 288 79 303 288 79 304 minecraft:iron_block
fill 288 79 306 288 79 307 minecraft:iron_block
fill 288 79 309 288 79 310 minecraft:iron_block
fill 288 79 311 288 80 311 minecraft:gray_concrete
fill 288 79 312 289 79 312 minecraft:iron_block
fill 288 79 315 289 79 315 minecraft:iron_block
fill 289 79 278 289 79 279 minecraft:iron_block
fill 289 79 281 290 79 281 minecraft:iron_block
fill 289 79 309 292 80 310 minecraft:gray_concrete
fill 289 79 311 290 79 311 minecraft:iron_block
fill 289 79 313 289 80 313 minecraft:gray_concrete
fill 289 79 314 290 79 314 minecraft:iron_block
fill 290 79 277 290 79 278 minecraft:iron_block
fill 290 79 280 292 79 280 minecraft:iron_block
fill 290 79 312 290 80 312 minecraft:gray_concrete
fill 290 79 313 291 79 313 minecraft:iron_block
setblock 290 79 315 minecraft:gray_concrete
fill 290 79 316 291 79 316 minecraft:iron_block
fill 291 79 276 291 79 277 minecraft:iron_block
setblock 291 79 279 minecraft:iron_block
fill 291 79 311 291 80 311 minecraft:gray_concrete
fill 291 79 312 292 79 312 minecraft:iron_block
fill 291 79 315 292 79 315 minecraft:iron_block
setblock 292 79 276 minecraft:iron_block
setblock 292 79 278 minecraft:iron_block
fill 292 79 281 293 79 281 minecraft:iron_block
setblock 292 79 285 minecraft:light[level=12]
setblock 292 79 292 minecraft:light[level=12]
setblock 292 79 299 minecraft:light[level=12]
setblock 292 79 306 minecraft:light[level=12]
fill 292 79 311 293 79 311 minecraft:iron_block
fill 292 79 313 292 80 313 minecraft:gray_concrete
fill 292 79 314 293 79 314 minecraft:iron_block
fill 293 79 313 294 79 313 minecraft:iron_block
setblock 293 79 316 minecraft:iron_block
fill 294 79 276 294 79 278 minecraft:iron_block
setblock 294 79 280 minecraft:iron_block
fill 294 79 312 295 79 312 minecraft:iron_block
fill 294 79 315 295 79 315 minecraft:iron_block
setblock 295 79 276 minecraft:iron_block
fill 295 79 278 295 79 279 minecraft:iron_block
fill 295 79 281 296 79 281 minecraft:iron_block
fill 295 79 311 296 79 311 minecraft:iron_block
fill 295 79 314 296 79 314 minecraft:iron_block
fill 296 79 277 296 79 278 minecraft:iron_block
fill 296 79 280 297 79 280 minecraft:iron_block
fill 296 79 313 297 79 313 minecraft:iron_block
fill 296 79 316 297 79 316 minecraft:iron_block
fill 297 79 276 297 79 277 minecraft:iron_block
fill 297 79 279 298 79 279 minecraft:iron_block
fill 297 79 312 298 79 312 minecraft:iron_block
fill 297 79 315 298 79 315 minecraft:iron_block
setblock 298 79 276 minecraft:iron_block
fill 298 79 278 299 79 278 minecraft:iron_block
fill 298 79 281 299 79 281 minecraft:iron_block
fill 298 79 311 299 79 311 minecraft:iron_block
fill 298 79 314 299 79 314 minecraft:iron_block
fill 299 79 277 300 79 277 minecraft:iron_block
fill 299 79 280 300 79 280 minecraft:iron_block
setblock 299 79 285 minecraft:light[level=12]
setblock 299 79 292 minecraft:light[level=12]
setblock 299 79 299 minecraft:light[level=12]
setblock 299 79 306 minecraft:light[level=12]
fill 299 79 313 300 79 313 minecraft:iron_block
fill 299 79 316 300 79 316 minecraft:iron_block
fill 300 79 279 301 79 279 minecraft:iron_block
fill 300 79 312 301 79 312 minecraft:iron_block
fill 300 79 315 301 79 315 minecraft:iron_block
setblock 301 79 276 minecraft:iron_block
fill 301 79 278 302 79 278 minecraft:iron_block
fill 301 79 281 302 79 281 minecraft:iron_block
fill 301 79 311 302 79 311 minecraft:iron_block
fill 301 79 314 302 79 314 minecraft:iron_block
fill 302 79 277 303 79 277 minecraft:iron_block
fill 302 79 280 303 79 280 minecraft:iron_block
fill 302 79 313 303 79 313 minecraft:iron_block
fill 302 79 316 303 79 316 minecraft:iron_block
fill 303 79 276 304 79 276 minecraft:iron_block
fill 303 79 279 304 79 279 minecraft:iron_block
fill 303 79 312 304 79 312 minecraft:iron_block
fill 303 79 315 304 79 315 minecraft:iron_block
fill 304 79 278 305 79 278 minecraft:iron_block
fill 304 79 281 305 79 281 minecraft:iron_block
fill 304 79 311 305 79 311 minecraft:iron_block
fill 304 79 314 305 79 314 minecraft:iron_block
fill 305 79 277 306 79 277 minecraft:iron_block
fill 305 79 280 306 79 280 minecraft:iron_block
fill 305 79 313 306 79 313 minecraft:iron_block
fill 306 79 276 307 79 276 minecraft:iron_block
setblock 306 79 278 minecraft:light[level=12]
fill 306 79 279 307 79 279 minecraft:iron_block
setblock 306 79 285 minecraft:light[level=12]
setblock 306 79 292 minecraft:light[level=12]
setblock 306 79 299 minecraft:light[level=12]
setblock 306 79 306 minecraft:light[level=12]
fill 306 79 312 307 79 312 minecraft:iron_block
fill 306 79 315 306 79 316 minecraft:iron_block
fill 307 79 278 308 79 278 minecraft:iron_block
fill 307 79 281 308 79 281 minecraft:iron_block
fill 307 79 311 308 79 311 minecraft:iron_block
fill 307 79 314 307 79 315 minecraft:iron_block
fill 308 79 277 309 79 277 minecraft:iron_block
fill 308 79 280 309 79 280 minecraft:iron_block
fill 308 79 313 308 79 314 minecraft:iron_block
fill 308 79 316 309 79 316 minecraft:iron_block
fill 309 79 279 310 79 279 minecraft:iron_block
fill 309 79 312 309 79 313 minecraft:iron_block
fill 309 79 315 310 79 315 minecraft:iron_block
fill 310 79 278 311 79 278 minecraft:iron_block
fill 310 79 281 311 79 281 minecraft:iron_block
fill 310 79 311 310 79 312 minecraft:iron_block
setblock 310 79 314 minecraft:iron_block
fill 311 79 277 312 79 277 minecraft:iron_block
fill 311 79 280 312 79 280 minecraft:iron_block
setblock 311 79 311 minecraft:iron_block
fill 311 79 313 312 79 313 minecraft:iron_block
fill 311 79 316 312 79 316 minecraft:iron_block
fill 312 79 276 313 79 276 minecraft:iron_block
fill 312 79 279 313 79 279 minecraft:iron_block
fill 312 79 312 313 79 312 minecraft:iron_block
fill 312 79 315 313 79 315 minecraft:iron_block
fill 313 79 278 314 79 278 minecraft:iron_block
fill 313 79 281 314 79 281 minecraft:iron_block
setblock 313 79 285 minecraft:light[level=12]
setblock 313 79 292 minecraft:light[level=12]
setblock 313 79 299 minecraft:light[level=12]
setblock 313 79 306 minecraft:light[level=12]
fill 313 79 311 314 79 311 minecraft:iron_block
setblock 313 79 313 minecraft:light[level=12]
fill 313 79 314 314 79 314 minecraft:iron_block
fill 314 79 277 315 79 277 minecraft:iron_block
fill 314 79 280 315 79 280 minecraft:iron_block
fill 314 79 313 315 79 313 minecraft:iron_block
fill 315 79 276 316 79 276 minecraft:iron_block
fill 315 79 279 316 79 279 minecraft:iron_block
fill 315 79 312 316 79 312 minecraft:iron_block
fill 315 79 315 316 79 315 minecraft:iron_block
fill 316 79 278 317 79 278 minecraft:iron_block
fill 316 79 281 317 79 281 minecraft:iron_block
fill 316 79 311 317 79 311 minecraft:iron_block
fill 316 79 314 317 79 314 minecraft:iron_block
fill 317 79 277 318 79 277 minecraft:iron_block
fill 317 79 280 318 79 280 minecraft:iron_block
fill 317 79 313 318 79 313 minecraft:iron_block
fill 317 79 316 318 79 316 minecraft:iron_block
setblock 318 79 276 minecraft:iron_block
fill 318 79 279 319 79 279 minecraft:iron_block
fill 318 79 282 318 79 283 minecraft:iron_block
fill 318 79 285 318 79 286 minecraft:iron_block
fill 318 79 288 318 79 289 minecraft:iron_block
fill 318 79 291 318 79 292 minecraft:iron_block
fill 318 79 294 318 79 295 minecraft:iron_block
fill 318 79 297 318 79 298 minecraft:iron_block
fill 318 79 300 318 79 301 minecraft:iron_block
fill 318 79 303 318 79 304 minecraft:iron_block
fill 318 79 306 318 79 307 minecraft:iron_block
fill 318 79 309 318 79 310 minecraft:iron_block
fill 318 79 312 319 79 312 minecraft:iron_block
fill 318 79 315 319 79 315 minecraft:iron_block
fill 319 79 278 320 79 278 minecraft:iron_block
fill 319 79 281 319 79 282 minecraft:iron_block
fill 319 79 284 319 79 285 minecraft:iron_block
fill 319 79 287 319 79 288 minecraft:iron_block
fill 319 79 290 319 79 291 minecraft:iron_block
fill 319 79 293 319 79 294 minecraft:iron_block
fill 319 79 296 319 79 297 minecraft:iron_block
fill 319 79 299 319 79 300 minecraft:iron_block
fill 319 79 302 319 79 303 minecraft:iron_block
setblock 319 79 306 minecraft:iron_block
fill 319 79 308 319 79 309 minecraft:iron_block
fill 319 79 311 320 79 311 minecraft:iron_block
fill 319 79 314 320 79 314 minecraft:iron_block
fill 320 79 277 321 79 277 minecraft:iron_block
fill 320 79 280 320 79 281 minecraft:iron_block
fill 320 79 283 320 79 284 minecraft:iron_block
setblock 320 79 285 minecraft:light[level=12]
fill 320 79 286 320 79 287 minecraft:iron_block
fill 320 79 289 320 79 290 minecraft:iron_block
fill 320 79 292 320 79 293 minecraft:iron_block
fill 320 79 295 320 79 296 minecraft:iron_block
fill 320 79 298 320 79 299 minecraft:iron_block
fill 320 79 301 320 79 302 minecraft:iron_block
fill 320 79 304 320 79 305 minecraft:iron_block
setblock 320 79 306 minecraft:light[level=12]
fill 320 79 307 320 79 308 minecraft:iron_block
fill 320 79 310 321 79 310 minecraft:iron_block
fill 320 79 313 321 79 313 minecraft:iron_block
fill 320 79 316 321 79 316 minecraft:iron_block
fill 321 79 276 322 79 276 minecraft:iron_block
fill 321 79 279 321 79 280 minecraft:iron_block
fill 321 79 282 321 79 283 minecraft:iron_block
fill 321 79 285 321 79 286 minecraft:iron_block
fill 321 79 288 321 79 289 minecraft:iron_block
fill 321 79 291 321 79 292 minecraft:iron_block
fill 321 79 294 321 79 295 minecraft:iron_block
fill 321 79 297 321 79 298 minecraft:iron_block
fill 321 79 300 321 79 301 minecraft:iron_block
fill 321 79 303 321 79 304 minecraft:iron_block
fill 321 79 306 321 79 307 minecraft:iron_block
fill 321 79 309 322 79 309 minecraft:iron_block
fill 321 79 312 322 79 312 minecraft:iron_block
fill 321 79 315 322 79 315 minecraft:iron_block
fill 322 79 278 322 79 279 minecraft:iron_block
fill 322 79 281 322 79 282 minecraft:iron_block
fill 322 79 284 322 79 285 minecraft:iron_block
fill 322 79 287 322 79 288 minecraft:iron_block
fill 322 79 290 322 79 291 minecraft:iron_block
fill 322 79 293 322 79 294 minecraft:iron_block
fill 322 79 296 322 79 297 minecraft:iron_block
fill 322 79 299 322 79 300 minecraft:iron_block
fill 322 79 302 322 79 303 minecraft:iron_block
fill 322 79 305 322 79 306 minecraft:iron_block
fill 322 79 308 323 79 308 minecraft:iron_block
fill 322 79 311 323 79 311 minecraft:iron_block
fill 322 79 314 323 79 314 minecraft:iron_block
fill 323 79 277 323 79 278 minecraft:iron_block
fill 323 79 280 323 79 281 minecraft:iron_block
setblock 323 79 284 minecraft:iron_block
fill 323 79 286 323 79 287 minecraft:iron_block
fill 323 79 289 323 79 290 minecraft:iron_block
fill 323 79 295 323 79 296 minecraft:iron_block
fill 323 79 298 323 79 299 minecraft:iron_block
setblock 323 79 301 minecraft:iron_block
fill 323 79 304 323 79 305 minecraft:iron_block
setblock 323 79 307 minecraft:iron_block
setblock 323 79 310 minecraft:iron_block
setblock 323 79 316 minecraft:iron_block
fill 283 80 275 283 89 275 minecraft:iron_block
fill 288 80 281 288 80 308 minecraft:light_gray_concrete
fill 288 80 309 288 80 310 minecraft:gray_concrete
fill 288 80 312 288 80 313 minecraft:gray_concrete
fill 289 80 281 318 80 281 minecraft:light_gray_concrete
fill 289 80 311 289 80 312 minecraft:gray_concrete
setblock 290 80 311 minecraft:gray_concrete
fill 290 80 313 291 80 313 minecraft:gray_concrete
fill 291 80 312 292 80 312 minecraft:gray_concrete
setblock 292 80 311 minecraft:gray_concrete
fill 293 80 311 318 80 311 minecraft:light_gray_concrete
fill 305 80 275 307 89 275 minecraft:iron_block
setblock 308 80 275 minecraft:sea_lantern
setblock 310 80 317 minecraft:redstone_block
fill 311 80 317 315 89 317 minecraft:iron_block
setblock 316 80 317 minecraft:sea_lantern
fill 317 80 317 319 89 317 minecraft:iron_block
fill 318 80 282 318 80 310 minecraft:light_gray_concrete
fill 320 80 305 322 81 305 minecraft:iron_block
fill 283 81 280 283 81 283 minecraft:iron_block
fill 283 81 290 283 81 293 minecraft:iron_block
fill 283 81 300 283 81 303 minecraft:iron_block
fill 283 81 310 283 81 313 minecraft:iron_block
fill 284 81 276 287 81 276 minecraft:iron_block
setblock 285 81 278 minecraft:light[level=15]
setblock 285 81 286 minecraft:light[level=15]
setblock 285 81 294 minecraft:light[level=15]
setblock 285 81 302 minecraft:light[level=15]
setblock 285 81 310 minecraft:light[level=15]
fill 287 81 316 290 81 316 minecraft:iron_block
setblock 293 81 286 minecraft:light[level=15]
setblock 293 81 294 minecraft:light[level=15]
setblock 293 81 302 minecraft:light[level=15]
setblock 293 81 310 minecraft:light[level=15]
fill 294 81 276 297 81 276 minecraft:iron_block
fill 297 81 316 300 81 316 minecraft:iron_block
setblock 301 81 278 minecraft:light[level=15]
setblock 301 81 286 minecraft:light[level=15]
setblock 301 81 294 minecraft:light[level=15]
setblock 301 81 302 minecraft:light[level=15]
setblock 301 81 310 minecraft:light[level=15]
fill 304 81 276 307 81 276 minecraft:iron_block
fill 307 81 316 310 81 316 minecraft:iron_block
fill 308 81 275 308 89 275 minecraft:iron_block
setblock 309 81 275 minecraft:sea_lantern
setblock 309 81 278 minecraft:light[level=15]
setblock 309 81 286 minecraft:light[level=15]
setblock 309 81 294 minecraft:light[level=15]
setblock 309 81 302 minecraft:light[level=15]
setblock 309 81 310 minecraft:light[level=15]
fill 310 81 275 313 89 275 minecraft:iron_block
fill 310 81 317 310 89 317 minecraft:iron_block
setblock 314 81 275 minecraft:redstone_block
fill 314 81 276 317 81 276 minecraft:iron_block
fill 316 81 317 316 89 317 minecraft:iron_block
setblock 317 81 278 minecraft:light[level=15]
setblock 317 81 286 minecraft:light[level=15]
setblock 317 81 294 minecraft:light[level=15]
setblock 317 81 302 minecraft:light[level=15]
setblock 317 81 310 minecraft:light[level=15]
fill 317 81 316 320 81 316 minecraft:iron_block
setblock 318 81 305 minecraft:pearlescent_froglight
fill 323 81 277 323 81 280 minecraft:iron_block
fill 323 81 287 323 81 290 minecraft:iron_block
fill 323 81 297 323 81 300 minecraft:iron_block
fill 323 81 307 323 81 310 minecraft:iron_block
fill 324 81 306 324 89 306 minecraft:iron_block
setblock 324 81 307 minecraft:redstone_block
fill 324 81 308 324 89 309 minecraft:iron_block
fill 309 82 275 309 89 275 minecraft:iron_block
setblock 314 82 275 minecraft:iron_block
fill 324 82 280 324 89 282 minecraft:iron_block
setblock 324 82 283 minecraft:sea_lantern
fill 324 82 307 324 89 307 minecraft:iron_block
setblock 314 83 275 minecraft:sea_lantern
fill 324 83 283 324 89 283 minecraft:iron_block
setblock 324 83 296 minecraft:redstone_block
setblock 283 84 278 minecraft:iron_block
setblock 283 84 288 minecraft:iron_block
setblock 283 84 298 minecraft:iron_block
setblock 283 84 308 minecraft:iron_block
setblock 285 84 316 minecraft:iron_block
fill 287 84 309 287 84 313 minecraft:iron_block
fill 288 84 308 288 84 309 minecraft:iron_block
fill 288 84 311 293 84 311 minecraft:iron_block
fill 288 84 313 288 84 314 minecraft:iron_block
setblock 289 84 276 minecraft:iron_block
fill 289 84 308 292 84 308 minecraft:iron_block
fill 289 84 314 292 84 314 minecraft:iron_block
fill 290 84 309 290 84 310 minecraft:iron_block
fill 290 84 312 290 84 313 minecraft:iron_block
fill 290 84 317 293 89 317 minecraft:iron_block
fill 292 84 309 293 84 309 minecraft:iron_block
fill 292 84 313 293 84 313 minecraft:iron_block
setblock 293 84 310 minecraft:iron_block
setblock 293 84 312 minecraft:iron_block
setblock 294 84 317 minecraft:sea_lantern
fill 295 84 316 295 84 317 minecraft:iron_block
setblock 299 84 276 minecraft:iron_block
setblock 305 84 316 minecraft:iron_block
setblock 309 84 276 minecraft:iron_block
fill 314 84 275 314 89 275 minecraft:iron_block
setblock 315 84 275 minecraft:sea_lantern
setblock 315 84 316 minecraft:iron_block
fill 316 84 275 318 89 275 minecraft:iron_block
setblock 319 84 276 minecraft:iron_block
setblock 323 84 282 minecraft:iron_block
setblock 323 84 292 minecraft:iron_block
setblock 323 84 302 minecraft:iron_block
setblock 323 84 312 minecraft:iron_block
fill 324 84 296 324 89 296 minecraft:iron_block
fill 324 84 298 324 89 298 minecraft:iron_block
setblock 324 84 299 minecraft:redstone_block
setblock 285 85 278 minecraft:light[level=12]
setblock 285 85 285 minecraft:light[level=12]
setblock 285 85 292 minecraft:light[level=12]
setblock 285 85 299 minecraft:light[level=12]
setblock 285 85 306 minecraft:light[level=12]
setblock 285 85 313 minecraft:light[level=12]
setblock 292 85 278 minecraft:light[level=12]
setblock 292 85 285 minecraft:light[level=12]
setblock 292 85 292 minecraft:light[level=12]
setblock 292 85 299 minecraft:light[level=12]
setblock 292 85 306 minecraft:light[level=12]
setblock 292 85 313 minecraft:light[level=12]
fill 294 85 317 294 89 317 minecraft:iron_block
setblock 295 85 317 minecraft:redstone_block
setblock 299 85 278 minecraft:light[level=12]
setblock 299 85 285 minecraft:light[level=12]
setblock 299 85 292 minecraft:light[level=12]
setblock 299 85 299 minecraft:light[level=12]
setblock 299 85 306 minecraft:light[level=12]
setblock 299 85 313 minecraft:light[level=12]
setblock 306 85 278 minecraft:light[level=12]
setblock 306 85 285 minecraft:light[level=12]
setblock 306 85 292 minecraft:light[level=12]
setblock 306 85 299 minecraft:light[level=12]
setblock 306 85 306 minecraft:light[level=12]
setblock 306 85 313 minecraft:light[level=12]
setblock 313 85 278 minecraft:light[level=12]
setblock 313 85 285 minecraft:light[level=12]
setblock 313 85 292 minecraft:light[level=12]
setblock 313 85 299 minecraft:light[level=12]
setblock 313 85 306 minecraft:light[level=12]
setblock 313 85 313 minecraft:light[level=12]
fill 315 85 275 315 89 275 minecraft:iron_block
setblock 319 85 275 minecraft:sea_lantern
fill 320 85 275 320 89 275 minecraft:iron_block
setblock 320 85 278 minecraft:light[level=12]
setblock 320 85 285 minecraft:light[level=12]
setblock 320 85 292 minecraft:light[level=12]
setblock 320 85 299 minecraft:light[level=12]
setblock 320 85 306 minecraft:light[level=12]
setblock 320 85 313 minecraft:light[level=12]
fill 324 85 299 324 89 299 minecraft:iron_block
fill 295 86 317 295 89 317 minecraft:iron_block
fill 319 86 275 319 89 275 minecraft:iron_block
fill 282 87 289 282 89 289 minecraft:iron_block
setblock 282 87 290 minecraft:redstone_block
fill 282 88 290 282 89 290 minecraft:iron_block
setblock 284 89 275 minecraft:sea_lantern
setblock 285 89 278 minecraft:light[level=15]
setblock 285 89 286 minecraft:light[level=15]
setblock 285 89 294 minecraft:light[level=15]
setblock 285 89 302 minecraft:light[level=15]
setblock 285 89 310 minecraft:light[level=15]
setblock 293 89 278 minecraft:light[level=15]
setblock 293 89 286 minecraft:light[level=15]
setblock 293 89 294 minecraft:light[level=15]
setblock 293 89 302 minecraft:light[level=15]
setblock 293 89 310 minecraft:light[level=15]
setblock 301 89 278 minecraft:light[level=15]
setblock 301 89 286 minecraft:light[level=15]
setblock 301 89 302 minecraft:light[level=15]
setblock 301 89 310 minecraft:light[level=15]
setblock 309 89 278 minecraft:light[level=15]
setblock 309 89 286 minecraft:light[level=15]
setblock 309 89 294 minecraft:light[level=15]
setblock 309 89 302 minecraft:light[level=15]
setblock 309 89 310 minecraft:light[level=15]
setblock 317 89 278 minecraft:light[level=15]
setblock 317 89 286 minecraft:light[level=15]
setblock 317 89 294 minecraft:light[level=15]
setblock 317 89 302 minecraft:light[level=15]
setblock 317 89 310 minecraft:light[level=15]
fill 282 90 275 282 91 276 minecraft:yellow_concrete
fill 282 90 277 282 91 278 minecraft:black_concrete
fill 282 90 279 282 91 280 minecraft:yellow_concrete
fill 282 90 281 282 91 282 minecraft:black_concrete
fill 282 90 283 282 91 284 minecraft:yellow_concrete
fill 282 90 285 282 91 286 minecraft:black_concrete
fill 282 90 287 282 91 288 minecraft:yellow_concrete
fill 282 90 289 282 91 290 minecraft:black_concrete
fill 282 90 291 282 91 292 minecraft:yellow_concrete
fill 282 90 293 282 91 294 minecraft:black_concrete
fill 282 90 295 282 91 296 minecraft:yellow_concrete
fill 282 90 297 282 91 298 minecraft:black_concrete
fill 282 90 299 282 91 300 minecraft:yellow_concrete
fill 282 90 301 282 91 302 minecraft:black_concrete
fill 282 90 303 282 91 304 minecraft:yellow_concrete
fill 282 90 305 282 91 306 minecraft:black_concrete
fill 282 90 307 282 91 308 minecraft:yellow_concrete
fill 282 90 309 282 91 310 minecraft:black_concrete
fill 282 90 311 282 91 312 minecraft:yellow_concrete
fill 282 90 313 282 91 314 minecraft:black_concrete
fill 282 90 315 282 91 316 minecraft:yellow_concrete
fill 282 90 317 282 91 317 minecraft:black_concrete
fill 283 90 275 283 91 275 minecraft:yellow_concrete
fill 283 90 276 283 91 276 minecraft:red_stained_glass
fill 283 90 277 286 91 278 minecraft:black_stained_glass
fill 283 90 279 283 91 279 minecraft:red_stained_glass
fill 283 90 280 283 91 281 minecraft:black_stained_glass
fill 283 90 282 283 91 282 minecraft:red_stained_glass
fill 283 90 283 286 91 284 minecraft:black_stained_glass
fill 283 90 285 283 91 285 minecraft:red_stained_glass
fill 283 90 286 283 91 287 minecraft:black_stained_glass
fill 283 90 288 283 91 288 minecraft:red_stained_glass
fill 283 90 289 286 91 290 minecraft:black_stained_glass
fill 283 90 291 283 91 291 minecraft:red_stained_glass
fill 283 90 292 283 91 293 minecraft:black_stained_glass
fill 283 90 294 283 91 294 minecraft:red_stained_glass
fill 283 90 295 286 91 296 minecraft:black_stained_glass
fill 283 90 297 283 91 297 minecraft:red_stained_glass
fill 283 90 298 283 91 299 minecraft:black_stained_glass
fill 283 90 300 283 91 300 minecraft:red_stained_glass
fill 283 90 301 286 91 302 minecraft:black_stained_glass
fill 283 90 303 283 91 303 minecraft:red_stained_glass
fill 283 90 304 283 91 305 minecraft:black_stained_glass
fill 283 90 306 283 91 306 minecraft:red_stained_glass
fill 283 90 307 286 91 308 minecraft:black_stained_glass
fill 283 90 309 283 91 309 minecraft:red_stained_glass
fill 283 90 310 283 91 311 minecraft:black_stained_glass
fill 283 90 312 283 91 312 minecraft:red_stained_glass
fill 283 90 313 286 91 314 minecraft:black_stained_glass
fill 283 90 315 283 91 315 minecraft:red_stained_glass
fill 283 90 316 283 91 316 minecraft:black_stained_glass
fill 283 90 317 283 91 317 minecraft:yellow_concrete
fill 284 90 275 285 91 275 minecraft:black_concrete
fill 284 90 276 285 91 276 minecraft:black_stained_glass
fill 284 90 279 285 91 279 minecraft:black_stained_glass
fill 284 90 280 285 91 281 minecraft:red_stained_glass
fill 284 90 282 285 91 282 minecraft:black_stained_glass
fill 284 90 285 285 91 285 minecraft:black_stained_glass
fill 284 90 286 285 91 287 minecraft:red_stained_glass
fill 284 90 288 285 91 288 minecraft:black_stained_glass
fill 284 90 291 285 91 291 minecraft:black_stained_glass
fill 284 90 292 285 91 293 minecraft:red_stained_glass
fill 284 90 294 285 91 294 minecraft:black_stained_glass
fill 284 90 297 285 91 297 minecraft:black_stained_glass
fill 284 90 298 285 91 299 minecraft:red_stained_glass
fill 284 90 300 285 91 300 minecraft:black_stained_glass
fill 284 90 303 285 91 303 minecraft:black_stained_glass
fill 284 90 304 285 91 305 minecraft:red_stained_glass
fill 284 90 306 285 91 306 minecraft:black_stained_glass
fill 284 90 309 285 91 309 minecraft:black_stained_glass
fill 284 90 310 285 91 311 minecraft:red_stained_glass
fill 284 90 312 285 91 312 minecraft:black_stained_glass
fill 284 90 315 285 91 315 minecraft:black_stained_glass
fill 284 90 316 285 91 316 minecraft:red_stained_glass
fill 284 90 317 285 91 317 minecraft:black_concrete
fill 286 90 275 287 91 275 minecraft:yellow_concrete
fill 286 90 276 286 91 276 minecraft:red_stained_glass
fill 286 90 279 286 91 279 minecraft:red_stained_glass
fill 286 90 280 289 91 281 minecraft:black_stained_glass
fill 286 90 282 286 91 282 minecraft:red_stained_glass
fill 286 90 285 286 91 285 minecraft:red_stained_glass
fill 286 90 286 289 91 287 minecraft:black_stained_glass
fill 286 90 288 286 91 288 minecraft:red_stained_glass
fill 286 90 291 286 91 291 minecraft:red_stained_glass
fill 286 90 292 289 91 293 minecraft:black_stained_glass
fill 286 90 294 286 91 294 minecraft:red_stained_glass
fill 286 90 297 286 91 297 minecraft:red_stained_glass
fill 286 90 298 289 91 299 minecraft:black_stained_glass
fill 286 90 300 286 91 300 minecraft:red_stained_glass
fill 286 90 303 286 91 303 minecraft:red_stained_glass
fill 286 90 304 289 91 305 minecraft:black_stained_glass
fill 286 90 306 286 91 306 minecraft:red_stained_glass
fill 286 90 309 286 91 309 minecraft:red_stained_glass
fill 286 90 310 289 91 311 minecraft:black_stained_glass
fill 286 90 312 286 91 312 minecraft:red_stained_glass
fill 286 90 315 286 91 315 minecraft:red_stained_glass
fill 286 90 316 289 91 316 minecraft:black_stained_glass
fill 286 90 317 287 91 317 minecraft:yellow_concrete
fill 287 90 276 288 91 276 minecraft:black_stained_glass
fill 287 90 277 288 91 278 minecraft:red_stained_glass
fill 287 90 279 288 91 279 minecraft:black_stained_glass
fill 287 90 282 288 91 282 minecraft:black_stained_glass
fill 287 90 283 288 91 284 minecraft:red_stained_glass
fill 287 90 285 288 91 285 minecraft:black_stained_glass
fill 287 90 288 288 91 288 minecraft:black_stained_glass
fill 287 90 289 288 91 290 minecraft:red_stained_glass
fill 287 90 291 288 91 291 minecraft:black_stained_glass
fill 287 90 294 288 91 294 minecraft:black_stained_glass
fill 287 90 295 288 91 296 minecraft:red_stained_glass
fill 287 90 297 288 91 297 minecraft:black_stained_glass
fill 287 90 300 288 91 300 minecraft:black_stained_glass
fill 287 90 301 288 91 302 minecraft:red_stained_glass
fill 287 90 303 288 91 303 minecraft:black_stained_glass
fill 287 90 306 288 91 306 minecraft:black_stained_glass
fill 287 90 307 288 91 308 minecraft:red_stained_glass
fill 287 90 309 288 91 309 minecraft:black_stained_glass
fill 287 90 312 288 91 312 minecraft:black_stained_glass
fill 287 90 313 288 91 314 minecraft:red_stained_glass
fill 287 90 315 288 91 315 minecraft:black_stained_glass
fill 288 90 275 289 91 275 minecraft:black_concrete
fill 288 90 317 289 91 317 minecraft:black_concrete
fill 289 90 276 289 91 276 minecraft:red_stained_glass
fill 289 90 277 292 91 278 minecraft:black_stained_glass
fill 289 90 279 289 91 279 minecraft:red_stained_glass
fill 289 90 282 289 91 282 minecraft:red_stained_glass
fill 289 90 283 292 91 284 minecraft:black_stained_glass
fill 289 90 285 289 91 285 minecraft:red_stained_glass
fill 289 90 288 289 91 288 minecraft:red_stained_glass
fill 289 90 289 292 91 290 minecraft:black_stained_glass
fill 289 90 291 289 91 291 minecraft:red_stained_glass
fill 289 90 294 289 91 294 minecraft:red_stained_glass
fill 289 90 295 292 91 296 minecraft:black_stained_glass
fill 289 90 297 289 91 297 minecraft:red_stained_glass
fill 289 90 300 289 91 300 minecraft:red_stained_glass
fill 289 90 301 292 91 302 minecraft:black_stained_glass
fill 289 90 303 289 91 303 minecraft:red_stained_glass
fill 289 90 306 289 91 306 minecraft:red_stained_glass
fill 289 90 307 292 91 308 minecraft:black_stained_glass
fill 289 90 309 289 91 309 minecraft:red_stained_glass
fill 289 90 312 289 91 312 minecraft:red_stained_glass
fill 289 90 313 292 91 314 minecraft:black_stained_glass
fill 289 90 315 289 91 315 minecraft:red_stained_glass
fill 290 90 275 291 91 275 minecraft:yellow_concrete
fill 290 90 276 291 91 276 minecraft:black_stained_glass
fill 290 90 279 291 91 279 minecraft:black_stained_glass
fill 290 90 280 291 91 281 minecraft:red_stained_glass
fill 290 90 282 291 91 282 minecraft:black_stained_glass
fill 290 90 285 291 91 285 minecraft:black_stained_glass
fill 290 90 286 291 91 287 minecraft:red_stained_glass
fill 290 90 288 291 91 288 minecraft:black_stained_glass
fill 290 90 291 291 91 291 minecraft:black_stained_glass
fill 290 90 292 291 91 293 minecraft:red_stained_glass
fill 290 90 294 291 91 294 minecraft:black_stained_glass
fill 290 90 297 291 91 297 minecraft:black_stained_glass
fill 290 90 298 291 91 299 minecraft:red_stained_glass
fill 290 90 300 291 91 300 minecraft:black_stained_glass
fill 290 90 303 291 91 303 minecraft:black_stained_glass
fill 290 90 304 291 91 305 minecraft:red_stained_glass
fill 290 90 306 291 91 306 minecraft:black_stained_glass
fill 290 90 309 291 91 309 minecraft:black_stained_glass
fill 290 90 310 291 91 311 minecraft:red_stained_glass
fill 290 90 312 291 91 312 minecraft:black_stained_glass
fill 290 90 315 291 91 315 minecraft:black_stained_glass
fill 290 90 316 291 91 316 minecraft:red_stained_glass
fill 290 90 317 291 91 317 minecraft:yellow_concrete
fill 292 90 275 293 91 275 minecraft:black_concrete
fill 292 90 276 292 91 276 minecraft:red_stained_glass
fill 292 90 279 292 91 279 minecraft:red_stained_glass
fill 292 90 280 295 91 281 minecraft:black_stained_glass
fill 292 90 282 292 91 282 minecraft:red_stained_glass
fill 292 90 285 292 91 285 minecraft:red_stained_glass
fill 292 90 286 295 91 287 minecraft:black_stained_glass
fill 292 90 288 292 91 288 minecraft:red_stained_glass
fill 292 90 291 292 91 291 minecraft:red_stained_glass
fill 292 90 292 295 90 293 minecraft:black_stained_glass
fill 292 90 294 292 91 294 minecraft:red_stained_glass
fill 292 90 297 292 91 297 minecraft:red_stained_glass
fill 292 90 298 295 91 299 minecraft:black_stained_glass
fill 292 90 300 292 91 300 minecraft:red_stained_glass
fill 292 90 303 292 91 303 minecraft:red_stained_glass
fill 292 90 304 295 91 305 minecraft:black_stained_glass
fill 292 90 306 292 91 306 minecraft:red_stained_glass
fill 292 90 309 292 91 309 minecraft:red_stained_glass
fill 292 90 310 295 91 311 minecraft:black_stained_glass
fill 292 90 312 292 91 312 minecraft:red_stained_glass
fill 292 90 315 292 91 315 minecraft:red_stained_glass
fill 292 90 316 295 91 316 minecraft:black_stained_glass
fill 292 90 317 293 91 317 minecraft:black_concrete
fill 293 90 276 294 91 276 minecraft:black_stained_glass
fill 293 90 277 294 91 278 minecraft:red_stained_glass
fill 293 90 279 294 91 279 minecraft:black_stained_glass
fill 293 90 282 294 91 282 minecraft:black_stained_glass
fill 293 90 283 294 91 284 minecraft:red_stained_glass
fill 293 90 285 294 91 285 minecraft:black_stained_glass
fill 293 90 288 294 91 288 minecraft:black_stained_glass
fill 293 90 289 294 91 290 minecraft:red_stained_glass
fill 293 90 291 294 91 291 minecraft:black_stained_glass
fill 293 90 294 294 91 294 minecraft:black_stained_glass
fill 293 90 295 294 91 296 minecraft:red_stained_glass
fill 293 90 297 294 91 297 minecraft:black_stained_glass
fill 293 90 300 294 91 300 minecraft:black_stained_glass
fill 293 90 301 294 91 302 minecraft:red_stained_glass
fill 293 90 303 294 91 303 minecraft:black_stained_glass
fill 293 90 306 294 91 306 minecraft:black_stained_glass
fill 293 90 307 294 91 308 minecraft:red_stained_glass
fill 293 90 309 294 91 309 minecraft:black_stained_glass
fill 293 90 312 294 91 312 minecraft:black_stained_glass
fill 293 90 313 294 91 314 minecraft:red_stained_glass
fill 293 90 315 294 91 315 minecraft:black_stained_glass
fill 294 90 275 295 91 275 minecraft:yellow_concrete
fill 294 90 317 295 91 317 minecraft:yellow_concrete
fill 295 90 276 295 91 276 minecraft:red_stained_glass
fill 295 90 277 298 91 278 minecraft:black_stained_glass
fill 295 90 279 295 91 279 minecraft:red_stained_glass
fill 295 90 282 295 91 282 minecraft:red_stained_glass
fill 295 90 283 298 91 284 minecraft:black_stained_glass
fill 295 90 285 295 91 285 minecraft:red_stained_glass
fill 295 90 288 295 91 288 minecraft:red_stained_glass
fill 295 90 289 298 90 290 minecraft:black_stained_glass
fill 295 90 291 295 91 291 minecraft:red_stained_glass
setblock 295 90 294 minecraft:red_stained_glass
fill 295 90 295 296 90 296 minecraft:black_stained_glass
fill 295 90 297 295 91 297 minecraft:red_stained_glass
fill 295 90 300 295 91 300 minecraft:red_stained_glass
fill 295 90 301 298 91 302 minecraft:black_stained_glass
fill 295 90 303 295 91 303 minecraft:red_stained_glass
fill 295 90 306 295 91 306 minecraft:red_stained_glass
fill 295 90 307 298 91 308 minecraft:black_stained_glass
fill 295 90 309 295 91 309 minecraft:red_stained_glass
fill 295 90 312 295 91 312 minecraft:red_stained_glass
fill 295 90 313 298 91 314 minecraft:black_stained_glass
fill 295 90 315 295 91 315 minecraft:red_stained_glass
fill 296 90 275 297 91 275 minecraft:black_concrete
fill 296 90 276 297 91 276 minecraft:black_stained_glass
fill 296 90 279 297 91 279 minecraft:black_stained_glass
fill 296 90 280 297 91 281 minecraft:red_stained_glass
fill 296 90 282 297 91 282 minecraft:black_stained_glass
fill 296 90 285 297 91 285 minecraft:black_stained_glass
fill 296 90 286 297 91 287 minecraft:red_stained_glass
fill 296 90 288 297 91 288 minecraft:black_stained_glass
fill 296 90 291 297 90 291 minecraft:black_stained_glass
fill 296 90 292 296 90 293 minecraft:red_stained_glass
fill 296 90 297 297 90 297 minecraft:black_stained_glass
fill 296 90 298 297 91 299 minecraft:red_stained_glass
fill 296 90 300 297 91 300 minecraft:black_stained_glass
fill 296 90 303 297 91 303 minecraft:black_stained_glass
fill 296 90 304 297 91 305 minecraft:red_stained_glass
fill 296 90 306 297 91 306 minecraft:black_stained_glass
fill 296 90 309 297 91 309 minecraft:black_stained_glass
fill 296 90 310 297 91 311 minecraft:red_stained_glass
fill 296 90 312 297 91 312 minecraft:black_stained_glass
fill 296 90 315 297 91 315 minecraft:black_stained_glass
fill 296 90 316 297 91 316 minecraft:red_stained_glass
fill 296 90 317 297 91 317 minecraft:black_concrete
fill 298 90 275 299 91 275 minecraft:yellow_concrete
fill 298 90 276 298 91 276 minecraft:red_stained_glass
fill 298 90 279 298 91 279 minecraft:red_stained_glass
fill 298 90 280 301 91 281 minecraft:black_stained_glass
fill 298 90 282 298 91 282 minecraft:red_stained_glass
fill 298 90 285 298 91 285 minecraft:red_stained_glass
fill 298 90 286 301 91 287 minecraft:black_stained_glass
fill 298 90 288 298 91 288 minecraft:red_stained_glass
setblock 298 90 291 minecraft:red_stained_glass
setblock 298 90 297 minecraft:red_stained_glass
fill 298 90 298 301 90 299 minecraft:black_stained_glass
fill 298 90 300 298 91 300 minecraft:red_stained_glass
fill 298 90 303 298 91 303 minecraft:red_stained_glass
fill 298 90 304 301 91 305 minecraft:black_stained_glass
fill 298 90 306 298 91 306 minecraft:red_stained_glass
fill 298 90 309 298 91 309 minecraft:red_stained_glass
fill 298 90 310 301 91 311 minecraft:black_stained_glass
fill 298 90 312 298 91 312 minecraft:red_stained_glass
fill 298 90 315 298 91 315 minecraft:red_stained_glass
fill 298 90 316 301 91 316 minecraft:black_stained_glass
fill 298 90 317 299 91 317 minecraft:yellow_concrete
fill 299 90 276 300 91 276 minecraft:black_stained_glass
fill 299 90 277 300 91 278 minecraft:red_stained_glass
fill 299 90 279 300 91 279 minecraft:black_stained_glass
fill 299 90 282 300 91 282 minecraft:black_stained_glass
fill 299 90 283 300 91 284 minecraft:red_stained_glass
fill 299 90 285 300 91 285 minecraft:black_stained_glass
fill 299 90 288 300 91 288 minecraft:black_stained_glass
fill 299 90 289 300 90 290 minecraft:red_stained_glass
fill 299 90 300 300 91 300 minecraft:black_stained_glass
fill 299 90 301 300 91 302 minecraft:red_stained_glass
fill 299 90 303 300 91 303 minecraft:black_stained_glass
fill 299 90 306 300 91 306 minecraft:black_stained_glass
fill 299 90 307 300 91 308 minecraft:red_stained_glass
fill 299 90 309 300 91 309 minecraft:black_stained_glass
fill 299 90 312 300 91 312 minecraft:black_stained_glass
fill 299 90 313 300 91 314 minecraft:red_stained_glass
fill 299 90 315 300 91 315 minecraft:black_stained_glass
fill 300 90 275 301 91 275 minecraft:black_concrete
setblock 300 90 291 minecraft:black_stained_glass
setblock 300 90 297 minecraft:black_stained_glass
fill 300 90 317 301 91 317 minecraft:black_concrete
fill 301 90 276 301 91 276 minecraft:red_stained_glass
fill 301 90 277 304 91 278 minecraft:black_stained_glass
fill 301 90 279 301 91 279 minecraft:red_stained_glass
fill 301 90 282 301 91 282 minecraft:red_stained_glass
fill 301 90 283 304 91 284 minecraft:black_stained_glass
fill 301 90 285 301 91 285 minecraft:red_stained_glass
fill 301 90 288 301 91 288 minecraft:red_stained_glass
fill 301 90 289 304 91 290 minecraft:black_stained_glass
setblock 301 90 291 minecraft:red_stained_glass
setblock 301 90 297 minecraft:red_stained_glass
fill 301 90 300 301 91 300 minecraft:red_stained_glass
fill 301 90 301 304 91 302 minecraft:black_stained_glass
fill 301 90 303 301 91 303 minecraft:red_stained_glass
fill 301 90 306 301 91 306 minecraft:red_stained_glass
fill 301 90 307 304 91 308 minecraft:black_stained_glass
fill 301 90 309 301 91 309 minecraft:red_stained_glass
fill 301 90 312 301 91 312 minecraft:red_stained_glass
fill 301 90 313 304 91 314 minecraft:black_stained_glass
fill 301 90 315 301 91 315 minecraft:red_stained_glass
fill 302 90 275 303 91 275 minecraft:yellow_concrete
fill 302 90 276 303 91 276 minecraft:black_stained_glass
fill 302 90 279 303 91 279 minecraft:black_stained_glass
fill 302 90 280 303 91 281 minecraft:red_stained_glass
fill 302 90 282 303 91 282 minecraft:black_stained_glass
fill 302 90 285 303 91 285 minecraft:black_stained_glass
fill 302 90 286 303 91 287 minecraft:red_stained_glass
fill 302 90 288 303 91 288 minecraft:black_stained_glass
fill 302 90 291 303 90 291 minecraft:black_stained_glass
fill 302 90 292 303 90 293 minecraft:red_stained_glass
fill 302 90 295 303 90 297 minecraft:black_stained_glass
fill 302 90 298 303 91 299 minecraft:red_stained_glass
fill 302 90 300 303 91 300 minecraft:black_stained_glass
fill 302 90 303 303 91 303 minecraft:black_stained_glass
fill 302 90 304 303 91 305 minecraft:red_stained_glass
fill 302 90 306 303 91 306 minecraft:black_stained_glass
fill 302 90 309 303 91 309 minecraft:black_stained_glass
fill 302 90 310 303 91 311 minecraft:red_stained_glass
fill 302 90 312 303 91 312 minecraft:black_stained_glass
fill 302 90 315 303 91 315 minecraft:black_stained_glass
fill 302 90 316 303 91 316 minecraft:red_stained_glass
fill 302 90 317 303 91 317 minecraft:yellow_concrete
setblock 303 90 294 minecraft:black_stained_glass
fill 304 90 275 305 91 275 minecraft:black_concrete
fill 304 90 276 304 91 276 minecraft:red_stained_glass
fill 304 90 279 304 91 279 minecraft:red_stained_glass
fill 304 90 280 307 91 281 minecraft:black_stained_glass
fill 304 90 282 304 91 282 minecraft:red_stained_glass
fill 304 90 285 304 91 285 minecraft:red_stained_glass
fill 304 90 286 307 91 287 minecraft:black_stained_glass
fill 304 90 288 304 91 288 minecraft:red_stained_glass
fill 304 90 291 304 91 291 minecraft:red_stained_glass
fill 304 90 292 307 91 293 minecraft:black_stained_glass
fill 304 90 294 304 91 294 minecraft:red_stained_glass
fill 304 90 295 304 91 296 minecraft:black_stained_glass
fill 304 90 297 304 91 297 minecraft:red_stained_glass
fill 304 90 298 307 91 299 minecraft:black_stained_glass
fill 304 90 300 304 91 300 minecraft:red_stained_glass
fill 304 90 303 304 91 303 minecraft:red_stained_glass
fill 304 90 304 307 91 305 minecraft:black_stained_glass
fill 304 90 306 304 91 306 minecraft:red_stained_glass
fill 304 90 309 304 91 309 minecraft:red_stained_glass
fill 304 90 310 307 91 311 minecraft:black_stained_glass
fill 304 90 312 304 91 312 minecraft:red_stained_glass
fill 304 90 315 304 91 315 minecraft:red_stained_glass
fill 304 90 316 307 91 316 minecraft:black_stained_glass
fill 304 90 317 305 91 317 minecraft:black_concrete
fill 305 90 276 306 91 276 minecraft:black_stained_glass
fill 305 90 277 306 91 278 minecraft:red_stained_glass
fill 305 90 279 306 91 279 minecraft:black_stained_glass
fill 305 90 282 306 91 282 minecraft:black_stained_glass
fill 305 90 283 306 91 284 minecraft:red_stained_glass
fill 305 90 285 306 91 285 minecraft:black_stained_glass
fill 305 90 288 306 91 288 minecraft:black_stained_glass
fill 305 90 289 306 91 290 minecraft:red_stained_glass
fill 305 90 291 306 91 291 minecraft:black_stained_glass
fill 305 90 294 306 91 294 minecraft:black_stained_glass
fill 305 90 295 306 91 296 minecraft:red_stained_glass
fill 305 90 297 306 91 297 minecraft:black_stained_glass
fill 305 90 300 306 91 300 minecraft:black_stained_glass
fill 305 90 301 306 91 302 minecraft:red_stained_glass
fill 305 90 303 306 91 303 minecraft:black_stained_glass
fill 305 90 306 306 91 306 minecraft:black_stained_glass
fill 305 90 307 306 91 308 minecraft:red_stained_glass
fill 305 90 309 306 91 309 minecraft:black_stained_glass
fill 305 90 312 306 91 312 minecraft:black_stained_glass
fill 305 90 313 306 91 314 minecraft:red_stained_glass
fill 305 90 315 306 91 315 minecraft:black_stained_glass
fill 306 90 275 307 91 275 minecraft:yellow_concrete
fill 306 90 317 307 91 317 minecraft:yellow_concrete
fill 307 90 276 307 91 276 minecraft:red_stained_glass
fill 307 90 277 310 91 278 minecraft:black_stained_glass
fill 307 90 279 307 91 279 minecraft:red_stained_glass
fill 307 90 282 307 91 282 minecraft:red_stained_glass
fill 307 90 283 310 91 284 minecraft:black_stained_glass
fill 307 90 285 307 91 285 minecraft:red_stained_glass
fill 307 90 288 307 91 288 minecraft:red_stained_glass
fill 307 90 289 310 91 290 minecraft:black_stained_glass
fill 307 90 291 307 91 291 minecraft:red_stained_glass
fill 307 90 294 307 91 294 minecraft:red_stained_glass
fill 307 90 295 310 91 296 minecraft:black_stained_glass
fill 307 90 297 307 91 297 minecraft:red_stained_glass
fill 307 90 300 307 91 300 minecraft:red_stained_glass
fill 307 90 301 310 91 302 minecraft:black_stained_glass
fill 307 90 303 307 91 303 minecraft:red_stained_glass
fill 307 90 306 307 91 306 minecraft:red_stained_glass
fill 307 90 307 310 91 308 minecraft:black_stained_glass
fill 307 90 309 307 91 309 minecraft:red_stained_glass
fill 307 90 312 307 91 312 minecraft:red_stained_glass
fill 307 90 313 310 91 314 minecraft:black_stained_glass
fill 307 90 315 307 91 315 minecraft:red_stained_glass
fill 308 90 275 309 91 275 minecraft:black_concrete
fill 308 90 276 309 91 276 minecraft:black_stained_glass
fill 308 90 279 309 91 279 minecraft:black_stained_glass
fill 308 90 280 309 91 281 minecraft:red_stained_glass
fill 308 90 282 309 91 282 minecraft:black_stained_glass
fill 308 90 285 309 91 285 minecraft:black_stained_glass
fill 308 90 286 309 91 287 minecraft:red_stained_glass
fill 308 90 288 309 91 288 minecraft:black_stained_glass
fill 308 90 291 309 91 291 minecraft:black_stained_glass
fill 308 90 292 309 91 293 minecraft:red_stained_glass
fill 308 90 294 309 91 294 minecraft:black_stained_glass
fill 308 90 297 309 91 297 minecraft:black_stained_glass
fill 308 90 298 309 91 299 minecraft:red_stained_glass
fill 308 90 300 309 91 300 minecraft:black_stained_glass
fill 308 90 303 309 91 303 minecraft:black_stained_glass
fill 308 90 304 309 91 305 minecraft:red_stained_glass
fill 308 90 306 309 91 306 minecraft:black_stained_glass
fill 308 90 309 309 91 309 minecraft:black_stained_glass
fill 308 90 310 309 91 311 minecraft:red_stained_glass
fill 308 90 312 309 91 312 minecraft:black_stained_glass
fill 308 90 315 309 91 315 minecraft:black_stained_glass
fill 308 90 316 309 91 316 minecraft:red_stained_glass
fill 308 90 317 309 91 317 minecraft:black_concrete
fill 310 90 275 311 91 275 minecraft:yellow_concrete
fill 310 90 276 310 91 276 minecraft:red_stained_glass
fill 310 90 279 310 91 279 minecraft:red_stained_glass
fill 310 90 280 313 91 281 minecraft:black_stained_glass
fill 310 90 282 310 91 282 minecraft:red_stained_glass
fill 310 90 285 310 91 285 minecraft:red_stained_glass
fill 310 90 286 313 91 287 minecraft:black_stained_glass
fill 310 90 288 310 91 288 minecraft:red_stained_glass
fill 310 90 291 310 91 291 minecraft:red_stained_glass
fill 310 90 292 313 91 293 minecraft:black_stained_glass
fill 310 90 294 310 91 294 minecraft:red_stained_glass
fill 310 90 297 310 91 297 minecraft:red_stained_glass
fill 310 90 298 313 91 299 minecraft:black_stained_glass
fill 310 90 300 310 91 300 minecraft:red_stained_glass
fill 310 90 303 310 91 303 minecraft:red_stained_glass
fill 310 90 304 313 91 305 minecraft:black_stained_glass
fill 310 90 306 310 91 306 minecraft:red_stained_glass
fill 310 90 309 310 91 309 minecraft:red_stained_glass
fill 310 90 310 313 91 311 minecraft:black_stained_glass
fill 310 90 312 310 91 312 minecraft:red_stained_glass
fill 310 90 315 310 91 315 minecraft:red_stained_glass
fill 310 90 316 313 91 316 minecraft:black_stained_glass
fill 310 90 317 311 91 317 minecraft:yellow_concrete
fill 311 90 276 312 91 276 minecraft:black_stained_glass
fill 311 90 277 312 91 278 minecraft:red_stained_glass
fill 311 90 279 312 91 279 minecraft:black_stained_glass
fill 311 90 282 312 91 282 minecraft:black_stained_glass
fill 311 90 283 312 91 284 minecraft:red_stained_glass
fill 311 90 285 312 91 285 minecraft:black_stained_glass
fill 311 90 288 312 91 288 minecraft:black_stained_glass
fill 311 90 289 312 91 290 minecraft:red_stained_glass
fill 311 90 291 312 91 291 minecraft:black_stained_glass
fill 311 90 294 312 91 294 minecraft:black_stained_glass
fill 311 90 295 312 91 296 minecraft:red_stained_glass
fill 311 90 297 312 91 297 minecraft:black_stained_glass
fill 311 90 300 312 91 300 minecraft:black_stained_glass
fill 311 90 301 312 91 302 minecraft:red_stained_glass
fill 311 90 303 312 91 303 minecraft:black_stained_glass
fill 311 90 306 312 91 306 minecraft:black_stained_glass
fill 311 90 307 312 91 308 minecraft:red_stained_glass
fill 311 90 309 312 91 309 minecraft:black_stained_glass
fill 311 90 312 312 91 312 minecraft:black_stained_glass
fill 311 90 313 312 91 314 minecraft:red_stained_glass
fill 311 90 315 312 91 315 minecraft:black_stained_glass
fill 312 90 275 313 91 275 minecraft:black_concrete
fill 312 90 317 313 91 317 minecraft:black_concrete
fill 313 90 276 313 91 276 minecraft:red_stained_glass
fill 313 90 277 316 91 278 minecraft:black_stained_glass
fill 313 90 279 313 91 279 minecraft:red_stained_glass
fill 313 90 282 313 91 282 minecraft:red_stained_glass
fill 313 90 283 316 91 284 minecraft:black_stained_glass
fill 313 90 285 313 91 285 minecraft:red_stained_glass
fill 313 90 288 313 91 288 minecraft:red_stained_glass
fill 313 90 289 316 91 290 minecraft:black_stained_glass
fill 313 90 291 313 91 291 minecraft:red_stained_glass
fill 313 90 294 313 91 294 minecraft:red_stained_glass
fill 313 90 295 316 91 296 minecraft:black_stained_glass
fill 313 90 297 313 91 297 minecraft:red_stained_glass
fill 313 90 300 313 91 300 minecraft:red_stained_glass
fill 313 90 301 316 91 302 minecraft:black_stained_glass
fill 313 90 303 313 91 303 minecraft:red_stained_glass
fill 313 90 306 313 91 306 minecraft:red_stained_glass
fill 313 90 307 316 91 308 minecraft:black_stained_glass
fill 313 90 309 313 91 309 minecraft:red_stained_glass
fill 313 90 312 313 91 312 minecraft:red_stained_glass
fill 313 90 313 316 91 314 minecraft:black_stained_glass
fill 313 90 315 313 91 315 minecraft:red_stained_glass
fill 314 90 275 315 91 275 minecraft:yellow_concrete
fill 314 90 276 315 91 276 minecraft:black_stained_glass
fill 314 90 279 315 91 279 minecraft:black_stained_glass
fill 314 90 280 315 91 281 minecraft:red_stained_glass
fill 314 90 282 315 91 282 minecraft:black_stained_glass
fill 314 90 285 315 91 285 minecraft:black_stained_glass
fill 314 90 286 315 91 287 minecraft:red_stained_glass
fill 314 90 288 315 91 288 minecraft:black_stained_glass
fill 314 90 291 315 91 291 minecraft:black_stained_glass
fill 314 90 292 315 91 293 minecraft:red_stained_glass
fill 314 90 294 315 91 294 minecraft:black_stained_glass
fill 314 90 297 315 91 297 minecraft:black_stained_glass
fill 314 90 298 315 91 299 minecraft:red_stained_glass
fill 314 90 300 315 91 300 minecraft:black_stained_glass
fill 314 90 303 315 91 303 minecraft:black_stained_glass
fill 314 90 304 315 91 305 minecraft:red_stained_glass
fill 314 90 306 315 91 306 minecraft:black_stained_glass
fill 314 90 309 315 91 309 minecraft:black_stained_glass
fill 314 90 310 315 91 311 minecraft:red_stained_glass
fill 314 90 312 315 91 312 minecraft:black_stained_glass
fill 314 90 315 315 91 315 minecraft:black_stained_glass
fill 314 90 316 315 91 316 minecraft:red_stained_glass
fill 314 90 317 315 91 317 minecraft:yellow_concrete
fill 316 90 275 317 91 275 minecraft:black_concrete
fill 316 90 276 316 91 276 minecraft:red_stained_glass
fill 316 90 279 316 91 279 minecraft:red_stained_glass
fill 316 90 280 319 91 281 minecraft:black_stained_glass
fill 316 90 282 316 91 282 minecraft:red_stained_glass
fill 316 90 285 316 91 285 minecraft:red_stained_glass
fill 316 90 286 319 91 287 minecraft:black_stained_glass
fill 316 90 288 316 91 288 minecraft:red_stained_glass
fill 316 90 291 316 91 291 minecraft:red_stained_glass
fill 316 90 292 319 91 293 minecraft:black_stained_glass
fill 316 90 294 316 91 294 minecraft:red_stained_glass
fill 316 90 297 316 91 297 minecraft:red_stained_glass
fill 316 90 298 319 91 299 minecraft:black_stained_glass
fill 316 90 300 316 91 300 minecraft:red_stained_glass
fill 316 90 303 316 91 303 minecraft:red_stained_glass
fill 316 90 304 319 91 305 minecraft:black_stained_glass
fill 316 90 306 316 91 306 minecraft:red_stained_glass
fill 316 90 309 316 91 309 minecraft:red_stained_glass
fill 316 90 310 319 91 311 minecraft:black_stained_glass
fill 316 90 312 316 91 312 minecraft:red_stained_glass
fill 316 90 315 316 91 315 minecraft:red_stained_glass
fill 316 90 316 319 91 316 minecraft:black_stained_glass
fill 316 90 317 317 91 317 minecraft:black_concrete
fill 317 90 276 318 91 276 minecraft:black_stained_glass
fill 317 90 277 318 91 278 minecraft:red_stained_glass
fill 317 90 279 318 91 279 minecraft:black_stained_glass
fill 317 90 282 318 91 282 minecraft:black_stained_glass
fill 317 90 283 318 91 284 minecraft:red_stained_glass
fill 317 90 285 318 91 285 minecraft:black_stained_glass
fill 317 90 288 318 91 288 minecraft:black_stained_glass
fill 317 90 289 318 91 290 minecraft:red_stained_glass
fill 317 90 291 318 91 291 minecraft:black_stained_glass
fill 317 90 294 318 91 294 minecraft:black_stained_glass
fill 317 90 295 318 91 296 minecraft:red_stained_glass
fill 317 90 297 318 91 297 minecraft:black_stained_glass
fill 317 90 300 318 91 300 minecraft:black_stained_glass
fill 317 90 301 318 91 302 minecraft:red_stained_glass
fill 317 90 303 318 91 303 minecraft:black_stained_glass
fill 317 90 306 318 91 306 minecraft:black_stained_glass
fill 317 90 307 318 91 308 minecraft:red_stained_glass
fill 317 90 309 318 91 309 minecraft:black_stained_glass
fill 317 90 312 318 91 312 minecraft:black_stained_glass
fill 317 90 313 318 91 314 minecraft:red_stained_glass
fill 317 90 315 318 91 315 minecraft:black_stained_glass
fill 318 90 275 319 91 275 minecraft:yellow_concrete
fill 318 90 317 319 91 317 minecraft:yellow_concrete
fill 319 90 276 319 91 276 minecraft:red_stained_glass
fill 319 90 277 322 91 278 minecraft:black_stained_glass
fill 319 90 279 319 91 279 minecraft:red_stained_glass
fill 319 90 282 319 91 282 minecraft:red_stained_glass
fill 319 90 283 322 91 284 minecraft:black_stained_glass
fill 319 90 285 319 91 285 minecraft:red_stained_glass
fill 319 90 288 319 91 288 minecraft:red_stained_glass
fill 319 90 289 322 91 290 minecraft:black_stained_glass
fill 319 90 291 319 91 291 minecraft:red_stained_glass
fill 319 90 294 319 91 294 minecraft:red_stained_glass
fill 319 90 295 322 91 296 minecraft:black_stained_glass
fill 319 90 297 319 91 297 minecraft:red_stained_glass
fill 319 90 300 319 91 300 minecraft:red_stained_glass
fill 319 90 301 322 91 302 minecraft:black_stained_glass
fill 319 90 303 319 91 303 minecraft:red_stained_glass
fill 319 90 306 319 91 306 minecraft:red_stained_glass
fill 319 90 307 322 91 308 minecraft:black_stained_glass
fill 319 90 309 319 91 309 minecraft:red_stained_glass
fill 319 90 312 319 91 312 minecraft:red_stained_glass
fill 319 90 313 322 91 314 minecraft:black_stained_glass
fill 319 90 315 319 91 315 minecraft:red_stained_glass
fill 320 90 275 321 91 275 minecraft:black_concrete
fill 320 90 276 321 91 276 minecraft:black_stained_glass
fill 320 90 279 321 91 279 minecraft:black_stained_glass
fill 320 90 280 321 91 281 minecraft:red_stained_glass
fill 320 90 282 321 91 282 minecraft:black_stained_glass
fill 320 90 285 321 91 285 minecraft:black_stained_glass
fill 320 90 286 321 91 287 minecraft:red_stained_glass
fill 320 90 288 321 91 288 minecraft:black_stained_glass
fill 320 90 291 321 91 291 minecraft:black_stained_glass
fill 320 90 292 321 91 293 minecraft:red_stained_glass
fill 320 90 294 321 91 294 minecraft:black_stained_glass
fill 320 90 297 321 91 297 minecraft:black_stained_glass
fill 320 90 298 321 91 299 minecraft:red_stained_glass
fill 320 90 300 321 91 300 minecraft:black_stained_glass
fill 320 90 303 321 91 303 minecraft:black_stained_glass
fill 320 90 304 321 91 305 minecraft:red_stained_glass
fill 320 90 306 321 91 306 minecraft:black_stained_glass
fill 320 90 309 321 91 309 minecraft:black_stained_glass
fill 320 90 310 321 91 311 minecraft:red_stained_glass
fill 320 90 312 321 91 312 minecraft:black_stained_glass
fill 320 90 315 321 91 315 minecraft:black_stained_glass
fill 320 90 316 321 91 316 minecraft:red_stained_glass
fill 320 90 317 321 91 317 minecraft:black_concrete
fill 322 90 275 323 91 275 minecraft:yellow_concrete
fill 322 90 276 322 91 276 minecraft:red_stained_glass
fill 322 90 279 322 91 279 minecraft:red_stained_glass
fill 322 90 280 323 91 281 minecraft:black_stained_glass
fill 322 90 282 322 91 282 minecraft:red_stained_glass
fill 322 90 285 322 91 285 minecraft:red_stained_glass
fill 322 90 286 323 91 287 minecraft:black_stained_glass
fill 322 90 288 322 91 288 minecraft:red_stained_glass
fill 322 90 291 322 91 291 minecraft:red_stained_glass
fill 322 90 292 323 91 293 minecraft:black_stained_glass
fill 322 90 294 322 91 294 minecraft:red_stained_glass
fill 322 90 297 322 91 297 minecraft:red_stained_glass
fill 322 90 298 323 91 299 minecraft:black_stained_glass
fill 322 90 300 322 91 300 minecraft:red_stained_glass
fill 322 90 303 322 91 303 minecraft:red_stained_glass
fill 322 90 304 323 91 305 minecraft:black_stained_glass
fill 322 90 306 322 91 306 minecraft:red_stained_glass
fill 322 90 309 322 91 309 minecraft:red_stained_glass
fill 322 90 310 323 91 311 minecraft:black_stained_glass
fill 322 90 312 322 91 312 minecraft:red_stained_glass
fill 322 90 315 322 91 315 minecraft:red_stained_glass
fill 322 90 316 323 91 316 minecraft:black_stained_glass
fill 322 90 317 323 91 317 minecraft:yellow_concrete
fill 323 90 276 323 91 276 minecraft:black_stained_glass
fill 323 90 277 323 91 278 minecraft:red_stained_glass
fill 323 90 279 323 91 279 minecraft:black_stained_glass
fill 323 90 282 323 91 282 minecraft:black_stained_glass
fill 323 90 283 323 91 284 minecraft:red_stained_glass
fill 323 90 285 323 91 285 minecraft:black_stained_glass
fill 323 90 288 323 91 288 minecraft:black_stained_glass
fill 323 90 289 323 91 290 minecraft:red_stained_glass
fill 323 90 291 323 91 291 minecraft:black_stained_glass
fill 323 90 294 323 91 294 minecraft:black_stained_glass
fill 323 90 295 323 91 296 minecraft:red_stained_glass
fill 323 90 297 323 91 297 minecraft:black_stained_glass
fill 323 90 300 323 91 300 minecraft:black_stained_glass
fill 323 90 301 323 91 302 minecraft:red_stained_glass
fill 323 90 303 323 91 303 minecraft:black_stained_glass
fill 323 90 306 323 91 306 minecraft:black_stained_glass
fill 323 90 307 323 91 308 minecraft:red_stained_glass
fill 323 90 309 323 91 309 minecraft:black_stained_glass
fill 323 90 312 323 91 312 minecraft:black_stained_glass
fill 323 90 313 323 91 314 minecraft:red_stained_glass
fill 323 90 315 323 91 315 minecraft:black_stained_glass
fill 324 90 275 324 91 275 minecraft:black_concrete
fill 324 90 276 324 91 276 minecraft:yellow_concrete
fill 324 90 277 324 91 278 minecraft:black_concrete
fill 324 90 279 324 91 280 minecraft:yellow_concrete
fill 324 90 281 324 91 282 minecraft:black_concrete
fill 324 90 283 324 91 284 minecraft:yellow_concrete
fill 324 90 285 324 91 286 minecraft:black_concrete
fill 324 90 287 324 91 288 minecraft:yellow_concrete
fill 324 90 289 324 91 290 minecraft:black_concrete
fill 324 90 291 324 91 292 minecraft:yellow_concrete
fill 324 90 293 324 91 294 minecraft:black_concrete
fill 324 90 295 324 91 296 minecraft:yellow_concrete
fill 324 90 297 324 91 298 minecraft:black_concrete
fill 324 90 299 324 91 300 minecraft:yellow_concrete
fill 324 90 301 324 91 302 minecraft:black_concrete
fill 324 90 303 324 91 304 minecraft:yellow_concrete
fill 324 90 305 324 91 306 minecraft:black_concrete
fill 324 90 307 324 91 308 minecraft:yellow_concrete
fill 324 90 309 324 91 310 minecraft:black_concrete
fill 324 90 311 324 91 312 minecraft:yellow_concrete
fill 324 90 313 324 91 314 minecraft:black_concrete
fill 324 90 315 324 91 316 minecraft:yellow_concrete
fill 324 90 317 324 91 317 minecraft:black_concrete
fill 292 91 292 294 91 293 minecraft:black_stained_glass
fill 295 91 289 297 91 290 minecraft:black_stained_glass
setblock 295 91 292 minecraft:black_stained_glass
fill 295 91 293 295 91 295 minecraft:redstone_block
setblock 295 91 296 minecraft:black_stained_glass
fill 296 91 291 296 91 293 minecraft:redstone_block
fill 296 91 295 296 91 297 minecraft:redstone_block
fill 297 91 291 298 91 291 minecraft:redstone_block
fill 297 91 297 298 91 297 minecraft:redstone_block
setblock 298 91 289 minecraft:black_stained_glass
fill 298 91 290 300 91 290 minecraft:redstone_block
fill 298 91 298 300 91 298 minecraft:redstone_block
fill 298 91 299 301 91 299 minecraft:black_stained_glass
fill 299 91 289 300 91 289 minecraft:red_stained_glass
fill 300 91 291 302 91 291 minecraft:redstone_block
fill 300 91 297 302 91 297 minecraft:redstone_block
setblock 301 91 298 minecraft:black_stained_glass
fill 302 91 292 302 91 293 minecraft:redstone_block
fill 302 91 295 302 91 296 minecraft:redstone_block
setblock 303 91 291 minecraft:black_stained_glass
setblock 303 91 292 minecraft:red_stained_glass
fill 303 91 293 303 91 295 minecraft:redstone_block
fill 303 91 296 303 91 297 minecraft:black_stained_glass
fill 282 92 275 282 92 317 minecraft:iron_block
fill 283 92 275 324 94 275 minecraft:iron_block
fill 283 92 317 324 94 317 minecraft:iron_block
fill 324 92 276 324 93 316 minecraft:iron_block
fill 282 93 275 282 93 300 minecraft:iron_block
setblock 282 93 301 minecraft:sea_lantern
fill 282 93 302 282 98 317 minecraft:iron_block
fill 282 94 275 282 99 282 minecraft:iron_block
setblock 282 94 283 minecraft:redstone_block
fill 282 94 284 282 98 301 minecraft:iron_block
setblock 324 94 276 minecraft:redstone_block
fill 324 94 277 324 98 316 minecraft:iron_block
fill 282 95 283 282 98 283 minecraft:iron_block
fill 283 95 275 302 98 275 minecraft:iron_block
schedule function dropper:buildpart/66_2 1t
