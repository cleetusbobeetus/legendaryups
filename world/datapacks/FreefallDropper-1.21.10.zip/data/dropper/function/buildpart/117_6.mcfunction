setblock 427 183 480 minecraft:polished_blackstone_bricks
setblock 428 183 464 minecraft:polished_blackstone_bricks
fill 428 183 465 428 186 465 minecraft:blackstone
setblock 428 183 504 minecraft:polished_blackstone_bricks
fill 429 183 464 429 186 464 minecraft:blackstone
setblock 429 183 503 minecraft:polished_blackstone_bricks
fill 429 183 504 429 186 504 minecraft:blackstone
fill 430 183 503 430 186 503 minecraft:blackstone
setblock 432 183 465 minecraft:polished_blackstone_bricks
setblock 433 183 464 minecraft:polished_blackstone_bricks
setblock 433 183 504 minecraft:polished_blackstone_bricks
fill 434 183 464 437 183 464 minecraft:blackstone
fill 434 183 504 437 183 504 minecraft:blackstone
setblock 438 183 464 minecraft:polished_blackstone_bricks
setblock 438 183 504 minecraft:polished_blackstone_bricks
fill 439 183 464 442 183 464 minecraft:blackstone
setblock 439 183 503 minecraft:polished_blackstone_bricks
fill 439 183 504 442 183 504 minecraft:blackstone
fill 440 183 503 443 183 503 minecraft:blackstone
fill 442 183 502 444 183 502 minecraft:blackstone
setblock 443 183 464 minecraft:polished_blackstone_bricks
setblock 443 183 504 minecraft:polished_blackstone_bricks
fill 444 183 464 444 186 464 minecraft:blackstone
setblock 444 183 503 minecraft:polished_blackstone_bricks
fill 444 183 504 444 186 504 minecraft:blackstone
setblock 445 183 501 minecraft:blackstone
setblock 445 183 502 minecraft:polished_blackstone_bricks
fill 445 183 503 445 186 503 minecraft:blackstone
setblock 446 183 501 minecraft:polished_blackstone_bricks
fill 446 183 502 446 186 502 minecraft:blackstone
fill 447 183 501 447 185 501 minecraft:blackstone
setblock 448 183 464 minecraft:polished_blackstone_bricks
setblock 448 183 504 minecraft:polished_blackstone_bricks
fill 449 183 464 449 186 464 minecraft:blackstone
setblock 449 183 503 minecraft:polished_blackstone_bricks
fill 449 183 504 449 186 504 minecraft:blackstone
setblock 450 183 502 minecraft:polished_blackstone_bricks
fill 450 183 503 450 186 503 minecraft:blackstone
fill 451 183 502 451 185 502 minecraft:blackstone
fill 452 183 494 452 183 495 minecraft:blackstone
setblock 453 183 493 minecraft:blackstone
setblock 453 183 504 minecraft:polished_blackstone_bricks
fill 454 183 497 455 183 497 minecraft:blackstone
setblock 454 183 503 minecraft:polished_blackstone_bricks
fill 454 183 504 454 186 504 minecraft:blackstone
setblock 456 183 493 minecraft:blackstone
setblock 456 183 496 minecraft:blackstone
fill 463 183 476 463 183 478 minecraft:blackstone
setblock 463 183 479 minecraft:polished_blackstone_bricks
fill 463 183 480 463 186 480 minecraft:blackstone
setblock 463 183 483 minecraft:blackstone
setblock 463 183 484 minecraft:polished_blackstone_bricks
fill 463 183 485 463 186 485 minecraft:blackstone
setblock 463 183 504 minecraft:polished_blackstone_bricks
setblock 464 183 473 minecraft:polished_blackstone_bricks
fill 464 183 474 464 186 474 minecraft:blackstone
setblock 464 183 478 minecraft:polished_blackstone_bricks
fill 464 183 479 464 186 479 minecraft:blackstone
setblock 464 183 483 minecraft:polished_blackstone_bricks
fill 464 183 484 464 186 484 minecraft:blackstone
setblock 464 183 488 minecraft:polished_blackstone_bricks
fill 464 183 489 464 186 489 minecraft:blackstone
setblock 464 183 493 minecraft:polished_blackstone_bricks
fill 464 183 494 464 184 494 minecraft:blackstone
setblock 464 183 498 minecraft:polished_blackstone_bricks
fill 464 183 499 464 186 499 minecraft:blackstone
setblock 464 183 503 minecraft:polished_blackstone_bricks
fill 464 183 504 464 186 504 minecraft:blackstone
setblock 424 184 467 minecraft:polished_blackstone_bricks
fill 424 184 468 424 187 468 minecraft:blackstone
setblock 424 184 472 minecraft:polished_blackstone_bricks
fill 424 184 473 424 187 473 minecraft:blackstone
setblock 424 184 477 minecraft:polished_blackstone_bricks
fill 424 184 478 424 187 478 minecraft:blackstone
setblock 424 184 482 minecraft:polished_blackstone_bricks
fill 424 184 483 424 187 483 minecraft:blackstone
setblock 424 184 487 minecraft:polished_blackstone_bricks
fill 424 184 488 424 187 488 minecraft:blackstone
setblock 424 184 498 minecraft:blackstone
setblock 424 184 502 minecraft:polished_blackstone_bricks
fill 424 184 503 424 187 503 minecraft:blackstone
setblock 425 184 466 minecraft:polished_blackstone_bricks
fill 425 184 472 425 187 472 minecraft:blackstone
setblock 425 184 476 minecraft:polished_blackstone_bricks
fill 425 184 477 425 187 477 minecraft:blackstone
setblock 425 184 481 minecraft:polished_blackstone_bricks
fill 425 184 482 425 187 482 minecraft:blackstone
setblock 425 184 486 minecraft:polished_blackstone_bricks
setblock 425 184 501 minecraft:polished_blackstone_bricks
fill 425 184 502 425 187 502 minecraft:blackstone
setblock 426 184 464 minecraft:blackstone
setblock 426 184 465 minecraft:polished_blackstone_bricks
setblock 426 184 475 minecraft:polished_blackstone_bricks
fill 426 184 476 426 185 476 minecraft:blackstone
setblock 426 184 480 minecraft:polished_blackstone_bricks
fill 426 184 481 426 187 481 minecraft:blackstone
setblock 427 184 464 minecraft:polished_blackstone_bricks
fill 427 184 465 427 187 465 minecraft:blackstone
setblock 427 184 504 minecraft:polished_blackstone_bricks
fill 428 184 464 428 187 464 minecraft:blackstone
setblock 428 184 503 minecraft:polished_blackstone_bricks
fill 428 184 504 428 187 504 minecraft:blackstone
fill 429 184 503 429 187 503 minecraft:blackstone
setblock 431 184 465 minecraft:polished_blackstone_bricks
setblock 432 184 464 minecraft:polished_blackstone_bricks
fill 432 184 465 432 187 465 minecraft:blackstone
setblock 432 184 504 minecraft:polished_blackstone_bricks
fill 433 184 464 436 184 464 minecraft:blackstone
fill 433 184 504 436 184 504 minecraft:blackstone
setblock 437 184 464 minecraft:polished_blackstone_bricks
setblock 437 184 504 minecraft:polished_blackstone_bricks
fill 438 184 464 441 184 464 minecraft:blackstone
fill 438 184 504 441 184 504 minecraft:blackstone
fill 439 184 503 442 184 503 minecraft:blackstone
setblock 442 184 464 minecraft:polished_blackstone_bricks
fill 442 184 502 443 184 502 minecraft:blackstone
setblock 442 184 504 minecraft:polished_blackstone_bricks
fill 443 184 464 443 187 464 minecraft:blackstone
setblock 443 184 503 minecraft:polished_blackstone_bricks
fill 443 184 504 443 187 504 minecraft:blackstone
setblock 444 184 502 minecraft:polished_blackstone_bricks
fill 444 184 503 444 187 503 minecraft:blackstone
setblock 445 184 465 minecraft:blackstone
setblock 445 184 501 minecraft:polished_blackstone_bricks
fill 445 184 502 445 187 502 minecraft:blackstone
setblock 446 184 465 minecraft:polished_blackstone_bricks
fill 446 184 501 446 185 501 minecraft:blackstone
setblock 447 184 464 minecraft:polished_blackstone_bricks
setblock 447 184 504 minecraft:polished_blackstone_bricks
fill 448 184 464 448 187 464 minecraft:blackstone
setblock 448 184 503 minecraft:polished_blackstone_bricks
fill 448 184 504 448 187 504 minecraft:blackstone
setblock 449 184 502 minecraft:polished_blackstone_bricks
fill 449 184 503 449 187 503 minecraft:blackstone
fill 450 184 502 450 186 502 minecraft:blackstone
setblock 452 184 504 minecraft:polished_blackstone_bricks
setblock 453 184 503 minecraft:polished_blackstone_bricks
fill 453 184 504 453 187 504 minecraft:blackstone
fill 462 184 481 462 185 482 minecraft:blackstone
setblock 462 184 504 minecraft:polished_blackstone_bricks
fill 463 184 476 463 184 477 minecraft:blackstone
setblock 463 184 478 minecraft:polished_blackstone_bricks
fill 463 184 479 463 187 479 minecraft:blackstone
setblock 463 184 483 minecraft:polished_blackstone_bricks
fill 463 184 484 463 187 484 minecraft:blackstone
setblock 463 184 487 minecraft:blackstone
fill 463 184 504 463 187 504 minecraft:blackstone
fill 464 184 473 464 187 473 minecraft:blackstone
setblock 464 184 477 minecraft:polished_blackstone_bricks
fill 464 184 478 464 187 478 minecraft:blackstone
setblock 464 184 482 minecraft:polished_blackstone_bricks
fill 464 184 483 464 187 483 minecraft:blackstone
setblock 464 184 487 minecraft:polished_blackstone_bricks
fill 464 184 488 464 187 488 minecraft:blackstone
setblock 464 184 492 minecraft:polished_blackstone_bricks
setblock 464 184 497 minecraft:polished_blackstone_bricks
fill 464 184 498 464 187 498 minecraft:blackstone
setblock 464 184 502 minecraft:polished_blackstone_bricks
fill 464 184 503 464 187 503 minecraft:blackstone
setblock 424 185 466 minecraft:polished_blackstone_bricks
fill 424 185 467 425 187 467 minecraft:blackstone
setblock 424 185 471 minecraft:polished_blackstone_bricks
fill 424 185 472 424 188 472 minecraft:blackstone
setblock 424 185 476 minecraft:polished_blackstone_bricks
fill 424 185 477 424 188 477 minecraft:blackstone
setblock 424 185 481 minecraft:polished_blackstone_bricks
fill 424 185 482 424 188 482 minecraft:blackstone
setblock 424 185 486 minecraft:polished_blackstone_bricks
fill 424 185 487 424 188 487 minecraft:blackstone
setblock 424 185 501 minecraft:polished_blackstone_bricks
fill 424 185 502 424 188 502 minecraft:blackstone
setblock 425 185 465 minecraft:polished_blackstone_bricks
fill 425 185 466 425 188 466 minecraft:blackstone
fill 425 185 468 425 185 469 minecraft:blackstone
fill 425 185 471 425 188 471 minecraft:blackstone
setblock 425 185 475 minecraft:polished_blackstone_bricks
fill 425 185 476 425 188 476 minecraft:blackstone
setblock 425 185 480 minecraft:polished_blackstone_bricks
fill 425 185 481 425 188 481 minecraft:blackstone
setblock 425 185 484 minecraft:blackstone
setblock 425 185 485 minecraft:polished_blackstone_bricks
fill 425 185 486 425 188 486 minecraft:blackstone
setblock 426 185 464 minecraft:polished_blackstone_bricks
fill 426 185 465 426 188 465 minecraft:blackstone
setblock 426 185 479 minecraft:polished_blackstone_bricks
fill 426 185 480 426 188 480 minecraft:blackstone
setblock 426 185 484 minecraft:polished_blackstone_bricks
setblock 426 185 504 minecraft:polished_blackstone_bricks
fill 427 185 464 427 188 464 minecraft:blackstone
setblock 427 185 503 minecraft:polished_blackstone_bricks
fill 427 185 504 427 188 504 minecraft:blackstone
fill 428 185 503 428 188 503 minecraft:blackstone
setblock 430 185 465 minecraft:polished_blackstone_bricks
setblock 431 185 464 minecraft:polished_blackstone_bricks
fill 431 185 465 431 188 465 minecraft:blackstone
setblock 431 185 504 minecraft:polished_blackstone_bricks
fill 432 185 464 435 185 464 minecraft:blackstone
setblock 432 185 503 minecraft:polished_blackstone_bricks
fill 432 185 504 435 185 504 minecraft:blackstone
setblock 436 185 464 minecraft:polished_blackstone_bricks
setblock 436 185 504 minecraft:polished_blackstone_bricks
fill 437 185 464 440 185 464 minecraft:blackstone
fill 437 185 504 440 185 504 minecraft:blackstone
fill 439 185 503 441 185 503 minecraft:blackstone
setblock 441 185 464 minecraft:polished_blackstone_bricks
setblock 441 185 504 minecraft:polished_blackstone_bricks
fill 442 185 464 442 188 464 minecraft:blackstone
setblock 442 185 502 minecraft:blackstone
setblock 442 185 503 minecraft:polished_blackstone_bricks
fill 442 185 504 442 188 504 minecraft:blackstone
setblock 443 185 502 minecraft:polished_blackstone_bricks
fill 443 185 503 443 188 503 minecraft:blackstone
setblock 444 185 465 minecraft:blackstone
fill 444 185 502 444 188 502 minecraft:blackstone
setblock 445 185 465 minecraft:polished_blackstone_bricks
setblock 446 185 464 minecraft:polished_blackstone_bricks
fill 446 185 465 447 187 465 minecraft:blackstone
setblock 446 185 504 minecraft:polished_blackstone_bricks
fill 447 185 464 447 188 464 minecraft:blackstone
setblock 447 185 503 minecraft:polished_blackstone_bricks
fill 447 185 504 447 188 504 minecraft:blackstone
setblock 448 185 502 minecraft:polished_blackstone_bricks
fill 448 185 503 448 188 503 minecraft:blackstone
fill 449 185 502 449 188 502 minecraft:blackstone
setblock 451 185 464 minecraft:polished_blackstone_bricks
setblock 451 185 504 minecraft:polished_blackstone_bricks
setblock 452 185 503 minecraft:polished_blackstone_bricks
fill 452 185 504 452 188 504 minecraft:blackstone
setblock 453 185 503 minecraft:blackstone
setblock 461 185 504 minecraft:polished_blackstone_bricks
setblock 462 185 483 minecraft:polished_blackstone_bricks
fill 462 185 484 462 188 484 minecraft:blackstone
fill 462 185 504 462 188 504 minecraft:blackstone
setblock 463 185 477 minecraft:polished_blackstone_bricks
fill 463 185 478 463 188 478 minecraft:blackstone
setblock 463 185 482 minecraft:polished_blackstone_bricks
fill 463 185 483 463 188 483 minecraft:blackstone
setblock 463 185 487 minecraft:polished_blackstone_bricks
fill 463 185 488 463 188 488 minecraft:blackstone
fill 464 185 464 464 185 465 minecraft:blackstone
setblock 464 185 476 minecraft:polished_blackstone_bricks
fill 464 185 477 464 188 477 minecraft:blackstone
setblock 464 185 481 minecraft:polished_blackstone_bricks
fill 464 185 482 464 188 482 minecraft:blackstone
setblock 464 185 486 minecraft:polished_blackstone_bricks
fill 464 185 487 464 188 487 minecraft:blackstone
setblock 464 185 491 minecraft:polished_blackstone_bricks
fill 464 185 492 464 188 492 minecraft:blackstone
setblock 464 185 496 minecraft:polished_blackstone_bricks
fill 464 185 497 464 186 497 minecraft:blackstone
setblock 464 185 501 minecraft:polished_blackstone_bricks
fill 464 185 502 464 188 502 minecraft:blackstone
setblock 424 186 465 minecraft:polished_blackstone_bricks
fill 424 186 466 424 189 466 minecraft:blackstone
setblock 424 186 470 minecraft:polished_blackstone_bricks
fill 424 186 471 424 189 471 minecraft:blackstone
setblock 424 186 475 minecraft:polished_blackstone_bricks
fill 424 186 476 424 189 476 minecraft:blackstone
setblock 424 186 480 minecraft:polished_blackstone_bricks
fill 424 186 481 424 189 481 minecraft:blackstone
setblock 424 186 485 minecraft:polished_blackstone_bricks
fill 424 186 486 424 189 486 minecraft:blackstone
setblock 424 186 489 minecraft:blackstone
setblock 424 186 500 minecraft:polished_blackstone_bricks
fill 424 186 501 424 189 501 minecraft:blackstone
setblock 425 186 464 minecraft:polished_blackstone_bricks
fill 425 186 465 425 189 465 minecraft:blackstone
setblock 425 186 468 minecraft:blackstone
setblock 425 186 469 minecraft:polished_blackstone_bricks
fill 425 186 470 425 189 470 minecraft:blackstone
setblock 425 186 474 minecraft:polished_blackstone_bricks
fill 425 186 475 425 189 475 minecraft:blackstone
setblock 425 186 479 minecraft:polished_blackstone_bricks
fill 425 186 480 425 189 480 minecraft:blackstone
setblock 425 186 484 minecraft:polished_blackstone_bricks
fill 425 186 485 425 189 485 minecraft:blackstone
fill 425 186 487 425 187 487 minecraft:blackstone
setblock 425 186 504 minecraft:polished_blackstone_bricks
fill 426 186 464 426 189 464 minecraft:blackstone
fill 426 186 466 427 186 466 minecraft:blackstone
setblock 426 186 478 minecraft:polished_blackstone_bricks
fill 426 186 479 426 188 479 minecraft:blackstone
setblock 426 186 483 minecraft:polished_blackstone_bricks
fill 426 186 484 426 189 484 minecraft:blackstone
setblock 426 186 503 minecraft:polished_blackstone_bricks
fill 426 186 504 426 189 504 minecraft:blackstone
fill 427 186 503 427 189 503 minecraft:blackstone
setblock 429 186 465 minecraft:polished_blackstone_bricks
setblock 430 186 464 minecraft:polished_blackstone_bricks
fill 430 186 465 430 189 465 minecraft:blackstone
setblock 430 186 504 minecraft:polished_blackstone_bricks
fill 431 186 464 434 186 464 minecraft:blackstone
setblock 431 186 503 minecraft:polished_blackstone_bricks
fill 431 186 504 434 186 504 minecraft:blackstone
setblock 435 186 464 minecraft:polished_blackstone_bricks
setblock 435 186 504 minecraft:polished_blackstone_bricks
fill 436 186 464 439 186 464 minecraft:blackstone
fill 436 186 504 439 186 504 minecraft:blackstone
fill 438 186 503 440 186 503 minecraft:blackstone
setblock 440 186 464 minecraft:polished_blackstone_bricks
setblock 440 186 504 minecraft:polished_blackstone_bricks
fill 441 186 464 441 189 464 minecraft:blackstone
setblock 441 186 502 minecraft:blackstone
setblock 441 186 503 minecraft:polished_blackstone_bricks
fill 441 186 504 441 189 504 minecraft:blackstone
fill 442 186 465 443 186 465 minecraft:blackstone
setblock 442 186 502 minecraft:polished_blackstone_bricks
fill 442 186 503 442 189 503 minecraft:blackstone
fill 443 186 502 443 189 502 minecraft:blackstone
setblock 444 186 465 minecraft:polished_blackstone_bricks
setblock 445 186 464 minecraft:polished_blackstone_bricks
fill 445 186 465 445 189 465 minecraft:blackstone
setblock 445 186 504 minecraft:polished_blackstone_bricks
fill 446 186 464 446 189 464 minecraft:blackstone
setblock 446 186 503 minecraft:polished_blackstone_bricks
fill 446 186 504 446 189 504 minecraft:blackstone
setblock 447 186 502 minecraft:polished_blackstone_bricks
fill 447 186 503 447 189 503 minecraft:blackstone
fill 448 186 502 448 189 502 minecraft:blackstone
setblock 450 186 464 minecraft:polished_blackstone_bricks
setblock 450 186 504 minecraft:polished_blackstone_bricks
fill 451 186 464 451 189 464 minecraft:blackstone
setblock 451 186 503 minecraft:polished_blackstone_bricks
fill 451 186 504 451 189 504 minecraft:blackstone
fill 452 186 503 452 187 503 minecraft:blackstone
setblock 455 186 504 minecraft:polished_blackstone_bricks
fill 461 186 504 461 189 504 minecraft:blackstone
fill 462 186 480 462 186 481 minecraft:blackstone
setblock 462 186 482 minecraft:polished_blackstone_bricks
fill 462 186 483 462 189 483 minecraft:blackstone
fill 462 186 485 462 187 485 minecraft:blackstone
fill 463 186 464 464 186 464 minecraft:blackstone
setblock 463 186 476 minecraft:polished_blackstone_bricks
fill 463 186 477 463 189 477 minecraft:blackstone
setblock 463 186 481 minecraft:polished_blackstone_bricks
fill 463 186 482 463 189 482 minecraft:blackstone
setblock 463 186 486 minecraft:polished_blackstone_bricks
fill 463 186 487 463 189 487 minecraft:blackstone
fill 463 186 489 463 187 489 minecraft:blackstone
setblock 464 186 465 minecraft:polished_blackstone_bricks
fill 464 186 466 464 187 468 minecraft:blackstone
fill 464 186 472 464 188 472 minecraft:blackstone
setblock 464 186 475 minecraft:polished_blackstone_bricks
fill 464 186 476 464 189 476 minecraft:blackstone
setblock 464 186 480 minecraft:polished_blackstone_bricks
fill 464 186 481 464 189 481 minecraft:blackstone
setblock 464 186 485 minecraft:polished_blackstone_bricks
fill 464 186 486 464 189 486 minecraft:blackstone
setblock 464 186 490 minecraft:polished_blackstone_bricks
fill 464 186 491 464 189 491 minecraft:blackstone
setblock 464 186 500 minecraft:polished_blackstone_bricks
fill 464 186 501 464 189 501 minecraft:blackstone
setblock 424 187 464 minecraft:polished_blackstone_bricks
fill 424 187 465 424 190 465 minecraft:blackstone
setblock 424 187 469 minecraft:polished_blackstone_bricks
fill 424 187 470 424 190 470 minecraft:blackstone
setblock 424 187 474 minecraft:polished_blackstone_bricks
fill 424 187 475 424 190 475 minecraft:blackstone
setblock 424 187 479 minecraft:polished_blackstone_bricks
fill 424 187 480 424 190 480 minecraft:blackstone
setblock 424 187 484 minecraft:polished_blackstone_bricks
fill 424 187 485 424 190 485 minecraft:blackstone
setblock 424 187 489 minecraft:polished_blackstone_bricks
fill 424 187 490 424 190 490 minecraft:blackstone
setblock 424 187 499 minecraft:polished_blackstone_bricks
fill 424 187 500 424 190 500 minecraft:blackstone
setblock 424 187 504 minecraft:polished_blackstone_bricks
fill 425 187 464 425 190 464 minecraft:blackstone
setblock 425 187 468 minecraft:polished_blackstone_bricks
fill 425 187 469 425 190 469 minecraft:blackstone
setblock 425 187 473 minecraft:polished_blackstone_bricks
fill 425 187 474 425 190 474 minecraft:blackstone
setblock 425 187 478 minecraft:polished_blackstone_bricks
fill 425 187 479 425 190 479 minecraft:blackstone
setblock 425 187 483 minecraft:polished_blackstone_bricks
fill 425 187 484 425 190 484 minecraft:blackstone
setblock 425 187 503 minecraft:polished_blackstone_bricks
fill 425 187 504 425 190 504 minecraft:blackstone
setblock 426 187 466 minecraft:blackstone
setblock 426 187 467 minecraft:polished_blackstone_bricks
setblock 426 187 478 minecraft:blackstone
setblock 426 187 482 minecraft:polished_blackstone_bricks
fill 426 187 483 426 190 483 minecraft:blackstone
fill 426 187 503 426 190 503 minecraft:blackstone
setblock 427 187 466 minecraft:polished_blackstone_bricks
setblock 428 187 465 minecraft:polished_blackstone_bricks
fill 428 187 466 428 190 466 minecraft:blackstone
setblock 429 187 464 minecraft:polished_blackstone_bricks
fill 429 187 465 429 190 465 minecraft:blackstone
setblock 429 187 504 minecraft:polished_blackstone_bricks
fill 430 187 464 433 187 464 minecraft:blackstone
setblock 430 187 503 minecraft:polished_blackstone_bricks
fill 430 187 504 433 187 504 minecraft:blackstone
fill 431 187 503 431 190 503 minecraft:blackstone
setblock 433 187 465 minecraft:polished_blackstone_bricks
setblock 434 187 464 minecraft:polished_blackstone_bricks
setblock 434 187 504 minecraft:polished_blackstone_bricks
fill 435 187 464 438 187 464 minecraft:blackstone
fill 435 187 504 438 187 504 minecraft:blackstone
fill 437 187 503 439 187 503 minecraft:blackstone
setblock 439 187 464 minecraft:polished_blackstone_bricks
setblock 439 187 504 minecraft:polished_blackstone_bricks
fill 440 187 464 440 189 465 minecraft:blackstone
setblock 440 187 503 minecraft:polished_blackstone_bricks
fill 440 187 504 440 190 504 minecraft:blackstone
fill 441 187 465 442 187 465 minecraft:blackstone
setblock 441 187 502 minecraft:polished_blackstone_bricks
fill 441 187 503 441 190 503 minecraft:blackstone
fill 442 187 502 442 190 502 minecraft:blackstone
setblock 443 187 465 minecraft:polished_blackstone_bricks
setblock 444 187 464 minecraft:polished_blackstone_bricks
fill 444 187 465 444 190 465 minecraft:blackstone
setblock 444 187 504 minecraft:polished_blackstone_bricks
fill 445 187 464 445 190 464 minecraft:blackstone
setblock 445 187 503 minecraft:polished_blackstone_bricks
fill 445 187 504 445 190 504 minecraft:blackstone
setblock 446 187 502 minecraft:polished_blackstone_bricks
fill 446 187 503 446 190 503 minecraft:blackstone
fill 447 187 502 447 190 502 minecraft:blackstone
setblock 448 187 465 minecraft:polished_blackstone_bricks
setblock 449 187 464 minecraft:polished_blackstone_bricks
setblock 449 187 504 minecraft:polished_blackstone_bricks
fill 450 187 464 450 190 464 minecraft:blackstone
setblock 450 187 503 minecraft:polished_blackstone_bricks
fill 450 187 504 450 190 504 minecraft:blackstone
fill 451 187 503 451 189 503 minecraft:blackstone
setblock 454 187 504 minecraft:polished_blackstone_bricks
fill 460 187 504 460 190 504 minecraft:blackstone
fill 461 187 464 463 187 464 minecraft:blackstone
setblock 462 187 480 minecraft:blackstone
setblock 462 187 481 minecraft:polished_blackstone_bricks
fill 462 187 482 462 190 482 minecraft:blackstone
setblock 462 187 486 minecraft:polished_blackstone_bricks
fill 462 187 487 462 190 487 minecraft:blackstone
fill 463 187 476 463 190 476 minecraft:blackstone
setblock 463 187 480 minecraft:polished_blackstone_bricks
fill 463 187 481 463 190 481 minecraft:blackstone
setblock 463 187 485 minecraft:polished_blackstone_bricks
fill 463 187 486 463 190 486 minecraft:blackstone
setblock 463 187 490 minecraft:polished_blackstone_bricks
setblock 464 187 464 minecraft:polished_blackstone_bricks
fill 464 187 465 464 190 465 minecraft:blackstone
setblock 464 187 469 minecraft:polished_blackstone_bricks
fill 464 187 470 464 189 471 minecraft:blackstone
setblock 464 187 474 minecraft:polished_blackstone_bricks
fill 464 187 475 464 190 475 minecraft:blackstone
setblock 464 187 479 minecraft:polished_blackstone_bricks
fill 464 187 480 464 190 480 minecraft:blackstone
setblock 464 187 484 minecraft:polished_blackstone_bricks
fill 464 187 485 464 190 485 minecraft:blackstone
setblock 464 187 489 minecraft:polished_blackstone_bricks
fill 464 187 490 464 190 490 minecraft:blackstone
setblock 464 187 493 minecraft:blackstone
setblock 464 187 499 minecraft:polished_blackstone_bricks
fill 464 187 500 464 190 500 minecraft:blackstone
setblock 464 187 504 minecraft:polished_blackstone_bricks
fill 424 188 464 424 191 464 minecraft:blackstone
setblock 424 188 467 minecraft:blackstone
setblock 424 188 468 minecraft:polished_blackstone_bricks
fill 424 188 469 424 191 469 minecraft:blackstone
setblock 424 188 473 minecraft:polished_blackstone_bricks
fill 424 188 474 424 191 474 minecraft:blackstone
setblock 424 188 478 minecraft:polished_blackstone_bricks
fill 424 188 479 424 191 479 minecraft:blackstone
setblock 424 188 483 minecraft:polished_blackstone_bricks
fill 424 188 484 424 191 484 minecraft:blackstone
setblock 424 188 488 minecraft:polished_blackstone_bricks
fill 424 188 489 424 191 489 minecraft:blackstone
fill 424 188 491 424 189 491 minecraft:blackstone
fill 424 188 499 424 191 499 minecraft:blackstone
setblock 424 188 503 minecraft:polished_blackstone_bricks
fill 424 188 504 424 191 504 minecraft:blackstone
setblock 425 188 467 minecraft:polished_blackstone_bricks
fill 425 188 468 426 190 468 minecraft:blackstone
setblock 425 188 472 minecraft:polished_blackstone_bricks
fill 425 188 473 425 191 473 minecraft:blackstone
setblock 425 188 477 minecraft:polished_blackstone_bricks
fill 425 188 478 425 191 478 minecraft:blackstone
setblock 425 188 482 minecraft:polished_blackstone_bricks
fill 425 188 483 425 191 483 minecraft:blackstone
setblock 425 188 487 minecraft:polished_blackstone_bricks
fill 425 188 488 425 191 488 minecraft:blackstone
setblock 425 188 502 minecraft:polished_blackstone_bricks
fill 425 188 503 425 191 503 minecraft:blackstone
setblock 426 188 466 minecraft:polished_blackstone_bricks
fill 426 188 467 426 191 467 minecraft:blackstone
fill 426 188 469 426 189 469 minecraft:blackstone
setblock 426 188 481 minecraft:polished_blackstone_bricks
fill 426 188 482 426 190 482 minecraft:blackstone
setblock 426 188 485 minecraft:blackstone
setblock 427 188 465 minecraft:polished_blackstone_bricks
fill 427 188 466 427 191 466 minecraft:blackstone
setblock 428 188 464 minecraft:polished_blackstone_bricks
fill 428 188 465 428 191 465 minecraft:blackstone
setblock 428 188 504 minecraft:polished_blackstone_bricks
fill 429 188 464 432 188 464 minecraft:blackstone
fill 429 188 466 429 189 466 minecraft:blackstone
setblock 429 188 503 minecraft:polished_blackstone_bricks
fill 429 188 504 432 188 504 minecraft:blackstone
fill 430 188 503 430 191 503 minecraft:blackstone
setblock 432 188 465 minecraft:polished_blackstone_bricks
setblock 433 188 464 minecraft:polished_blackstone_bricks
fill 433 188 465 435 189 465 minecraft:blackstone
setblock 433 188 504 minecraft:polished_blackstone_bricks
fill 434 188 464 437 188 464 minecraft:blackstone
fill 434 188 504 437 188 504 minecraft:blackstone
fill 436 188 503 438 188 503 minecraft:blackstone
setblock 437 188 465 minecraft:polished_blackstone_bricks
setblock 438 188 464 minecraft:polished_blackstone_bricks
fill 438 188 465 439 190 465 minecraft:blackstone
setblock 438 188 504 minecraft:polished_blackstone_bricks
fill 439 188 464 439 191 464 minecraft:blackstone
setblock 439 188 503 minecraft:polished_blackstone_bricks
fill 439 188 504 439 191 504 minecraft:blackstone
setblock 440 188 502 minecraft:polished_blackstone_bricks
fill 440 188 503 440 191 503 minecraft:blackstone
setblock 441 188 465 minecraft:blackstone
fill 441 188 502 441 191 502 minecraft:blackstone
setblock 442 188 465 minecraft:polished_blackstone_bricks
setblock 443 188 464 minecraft:polished_blackstone_bricks
fill 443 188 465 443 191 465 minecraft:blackstone
setblock 443 188 504 minecraft:polished_blackstone_bricks
fill 444 188 464 444 191 464 minecraft:blackstone
setblock 444 188 503 minecraft:polished_blackstone_bricks
fill 444 188 504 444 191 504 minecraft:blackstone
setblock 445 188 502 minecraft:polished_blackstone_bricks
fill 445 188 503 445 191 503 minecraft:blackstone
setblock 446 188 465 minecraft:blackstone
fill 446 188 502 446 191 502 minecraft:blackstone
setblock 447 188 465 minecraft:polished_blackstone_bricks
setblock 448 188 464 minecraft:polished_blackstone_bricks
fill 448 188 465 448 191 465 minecraft:blackstone
setblock 448 188 504 minecraft:polished_blackstone_bricks
fill 449 188 464 449 191 464 minecraft:blackstone
fill 449 188 489 453 224 491 minecraft:polished_blackstone_bricks
setblock 449 188 503 minecraft:polished_blackstone_bricks
fill 449 188 504 449 191 504 minecraft:blackstone
fill 450 188 488 452 224 488 minecraft:polished_blackstone_bricks
fill 450 188 492 452 224 492 minecraft:polished_blackstone_bricks
fill 450 188 503 450 191 503 minecraft:blackstone
setblock 453 188 504 minecraft:polished_blackstone_bricks
fill 454 188 504 454 191 504 minecraft:blackstone
setblock 458 188 504 minecraft:polished_blackstone_bricks
fill 459 188 504 459 191 504 minecraft:blackstone
fill 460 188 464 462 188 464 minecraft:blackstone
setblock 462 188 479 minecraft:blackstone
setblock 462 188 480 minecraft:polished_blackstone_bricks
fill 462 188 481 462 191 481 minecraft:blackstone
setblock 462 188 485 minecraft:polished_blackstone_bricks
fill 462 188 486 462 191 486 minecraft:blackstone
fill 462 188 488 462 189 488 minecraft:blackstone
setblock 463 188 464 minecraft:polished_blackstone_bricks
fill 463 188 465 463 189 467 minecraft:blackstone
fill 463 188 475 463 191 475 minecraft:blackstone
setblock 463 188 479 minecraft:polished_blackstone_bricks
fill 463 188 480 463 191 480 minecraft:blackstone
setblock 463 188 484 minecraft:polished_blackstone_bricks
fill 463 188 485 463 191 485 minecraft:blackstone
setblock 463 188 489 minecraft:polished_blackstone_bricks
fill 463 188 490 463 190 491 minecraft:blackstone
setblock 463 188 503 minecraft:blackstone
setblock 463 188 504 minecraft:polished_blackstone_bricks
fill 464 188 464 464 191 464 minecraft:blackstone
fill 464 188 466 464 188 467 minecraft:blackstone
setblock 464 188 468 minecraft:polished_blackstone_bricks
fill 464 188 469 464 191 469 minecraft:blackstone
setblock 464 188 473 minecraft:polished_blackstone_bricks
fill 464 188 474 464 191 474 minecraft:blackstone
setblock 464 188 478 minecraft:polished_blackstone_bricks
fill 464 188 479 464 191 479 minecraft:blackstone
setblock 464 188 483 minecraft:polished_blackstone_bricks
fill 464 188 484 464 191 484 minecraft:blackstone
setblock 464 188 488 minecraft:polished_blackstone_bricks
fill 464 188 489 464 191 489 minecraft:blackstone
setblock 464 188 493 minecraft:polished_blackstone_bricks
fill 464 188 494 464 190 495 minecraft:blackstone
setblock 464 188 498 minecraft:polished_blackstone_bricks
fill 464 188 499 464 191 499 minecraft:blackstone
setblock 464 188 503 minecraft:polished_blackstone_bricks
fill 464 188 504 464 191 504 minecraft:blackstone
setblock 424 189 467 minecraft:polished_blackstone_bricks
fill 424 189 468 424 192 468 minecraft:blackstone
setblock 424 189 472 minecraft:polished_blackstone_bricks
fill 424 189 473 424 192 473 minecraft:blackstone
setblock 424 189 477 minecraft:polished_blackstone_bricks
fill 424 189 478 424 192 478 minecraft:blackstone
setblock 424 189 482 minecraft:polished_blackstone_bricks
fill 424 189 483 424 192 483 minecraft:blackstone
setblock 424 189 487 minecraft:polished_blackstone_bricks
fill 424 189 488 424 192 488 minecraft:blackstone
setblock 424 189 492 minecraft:polished_blackstone_bricks
setblock 424 189 502 minecraft:polished_blackstone_bricks
fill 424 189 503 424 192 503 minecraft:blackstone
setblock 425 189 466 minecraft:polished_blackstone_bricks
fill 425 189 467 425 192 467 minecraft:blackstone
setblock 425 189 471 minecraft:polished_blackstone_bricks
fill 425 189 472 425 192 472 minecraft:blackstone
setblock 425 189 476 minecraft:polished_blackstone_bricks
fill 425 189 477 425 192 477 minecraft:blackstone
setblock 425 189 481 minecraft:polished_blackstone_bricks
fill 425 189 482 425 192 482 minecraft:blackstone
setblock 425 189 486 minecraft:polished_blackstone_bricks
fill 425 189 487 425 192 487 minecraft:blackstone
fill 425 189 489 425 190 489 minecraft:blackstone
setblock 425 189 501 minecraft:polished_blackstone_bricks
fill 425 189 502 425 192 502 minecraft:blackstone
setblock 426 189 465 minecraft:polished_blackstone_bricks
fill 426 189 466 426 192 466 minecraft:blackstone
setblock 426 189 470 minecraft:polished_blackstone_bricks
setblock 426 189 480 minecraft:polished_blackstone_bricks
fill 426 189 481 426 190 481 minecraft:blackstone
setblock 426 189 485 minecraft:polished_blackstone_bricks
setblock 427 189 464 minecraft:polished_blackstone_bricks
fill 427 189 465 427 192 465 minecraft:blackstone
setblock 427 189 504 minecraft:polished_blackstone_bricks
fill 428 189 464 431 189 464 minecraft:blackstone
setblock 428 189 503 minecraft:polished_blackstone_bricks
fill 428 189 504 431 189 504 minecraft:blackstone
fill 429 189 503 429 192 503 minecraft:blackstone
setblock 430 189 466 minecraft:polished_blackstone_bricks
setblock 431 189 465 minecraft:polished_blackstone_bricks
setblock 432 189 464 minecraft:polished_blackstone_bricks
fill 432 189 465 432 192 465 minecraft:blackstone
setblock 432 189 504 minecraft:polished_blackstone_bricks
fill 433 189 464 436 189 464 minecraft:blackstone
fill 433 189 504 436 189 504 minecraft:blackstone
fill 435 189 503 437 189 503 minecraft:blackstone
setblock 436 189 465 minecraft:polished_blackstone_bricks
setblock 437 189 464 minecraft:polished_blackstone_bricks
fill 437 189 465 437 192 465 minecraft:blackstone
setblock 437 189 504 minecraft:polished_blackstone_bricks
fill 438 189 464 438 192 464 minecraft:blackstone
setblock 438 189 503 minecraft:polished_blackstone_bricks
fill 438 189 504 438 192 504 minecraft:blackstone
fill 439 189 503 439 192 503 minecraft:blackstone
fill 440 189 502 440 192 502 minecraft:blackstone
setblock 441 189 465 minecraft:polished_blackstone_bricks
setblock 442 189 464 minecraft:polished_blackstone_bricks
fill 442 189 465 442 191 466 minecraft:blackstone
setblock 442 189 504 minecraft:polished_blackstone_bricks
fill 443 189 464 443 192 464 minecraft:blackstone
fill 443 189 466 444 189 466 minecraft:blackstone
setblock 443 189 503 minecraft:polished_blackstone_bricks
fill 443 189 504 443 192 504 minecraft:blackstone
setblock 444 189 502 minecraft:polished_blackstone_bricks
fill 444 189 503 444 192 503 minecraft:blackstone
fill 445 189 502 445 192 502 minecraft:blackstone
setblock 446 189 465 minecraft:polished_blackstone_bricks
setblock 447 189 464 minecraft:polished_blackstone_bricks
fill 447 189 465 447 192 465 minecraft:blackstone
setblock 447 189 504 minecraft:polished_blackstone_bricks
fill 448 189 464 448 192 464 minecraft:blackstone
fill 448 189 489 448 190 491 minecraft:blackstone
setblock 448 189 503 minecraft:polished_blackstone_bricks
fill 448 189 504 448 192 504 minecraft:blackstone
fill 449 189 487 449 190 488 minecraft:blackstone
fill 449 189 492 449 190 492 minecraft:blackstone
fill 449 189 503 449 192 503 minecraft:blackstone
fill 450 189 487 453 190 487 minecraft:blackstone
fill 450 189 493 452 190 493 minecraft:blackstone
setblock 452 189 504 minecraft:polished_blackstone_bricks
fill 453 189 488 454 190 488 minecraft:blackstone
fill 453 189 492 453 190 492 minecraft:blackstone
fill 453 189 504 453 191 504 minecraft:blackstone
fill 454 189 489 454 190 491 minecraft:blackstone
fill 455 189 504 455 190 504 minecraft:blackstone
setblock 457 189 504 minecraft:polished_blackstone_bricks
fill 458 189 464 461 189 464 minecraft:blackstone
fill 458 189 504 458 192 504 minecraft:blackstone
setblock 461 189 465 minecraft:polished_blackstone_bricks
fill 461 189 482 461 189 484 minecraft:blackstone
setblock 461 189 485 minecraft:polished_blackstone_bricks
fill 461 189 486 461 192 486 minecraft:blackstone
setblock 462 189 464 minecraft:polished_blackstone_bricks
fill 462 189 465 462 192 465 minecraft:blackstone
setblock 462 189 479 minecraft:polished_blackstone_bricks
fill 462 189 480 462 192 480 minecraft:blackstone
setblock 462 189 484 minecraft:polished_blackstone_bricks
fill 462 189 485 462 192 485 minecraft:blackstone
setblock 462 189 489 minecraft:polished_blackstone_bricks
setblock 462 189 503 minecraft:blackstone
setblock 462 189 504 minecraft:polished_blackstone_bricks
fill 463 189 464 463 192 464 minecraft:blackstone
setblock 463 189 468 minecraft:polished_blackstone_bricks
fill 463 189 469 463 189 472 minecraft:blackstone
setblock 463 189 473 minecraft:polished_blackstone_bricks
fill 463 189 474 463 192 474 minecraft:blackstone
setblock 463 189 478 minecraft:polished_blackstone_bricks
fill 463 189 479 463 192 479 minecraft:blackstone
setblock 463 189 483 minecraft:polished_blackstone_bricks
fill 463 189 484 463 192 484 minecraft:blackstone
setblock 463 189 488 minecraft:polished_blackstone_bricks
fill 463 189 489 463 192 489 minecraft:blackstone
setblock 463 189 492 minecraft:blackstone
setblock 463 189 503 minecraft:polished_blackstone_bricks
fill 463 189 504 463 192 504 minecraft:blackstone
setblock 464 189 466 minecraft:blackstone
setblock 464 189 467 minecraft:polished_blackstone_bricks
fill 464 189 468 464 192 468 minecraft:blackstone
setblock 464 189 472 minecraft:polished_blackstone_bricks
fill 464 189 473 464 192 473 minecraft:blackstone
setblock 464 189 477 minecraft:polished_blackstone_bricks
fill 464 189 478 464 192 478 minecraft:blackstone
setblock 464 189 482 minecraft:polished_blackstone_bricks
fill 464 189 483 464 192 483 minecraft:blackstone
setblock 464 189 487 minecraft:polished_blackstone_bricks
fill 464 189 488 464 192 488 minecraft:blackstone
setblock 464 189 492 minecraft:polished_blackstone_bricks
fill 464 189 493 464 192 493 minecraft:blackstone
setblock 464 189 496 minecraft:blackstone
setblock 464 189 497 minecraft:polished_blackstone_bricks
fill 464 189 498 464 192 498 minecraft:blackstone
setblock 464 189 502 minecraft:polished_blackstone_bricks
fill 464 189 503 464 192 503 minecraft:blackstone
setblock 424 190 466 minecraft:polished_blackstone_bricks
fill 424 190 467 424 193 467 minecraft:blackstone
setblock 424 190 471 minecraft:polished_blackstone_bricks
fill 424 190 472 424 193 472 minecraft:blackstone
setblock 424 190 476 minecraft:polished_blackstone_bricks
fill 424 190 477 424 193 477 minecraft:blackstone
setblock 424 190 481 minecraft:polished_blackstone_bricks
fill 424 190 482 424 193 482 minecraft:blackstone
setblock 424 190 486 minecraft:polished_blackstone_bricks
fill 424 190 487 424 193 487 minecraft:blackstone
setblock 424 190 491 minecraft:polished_blackstone_bricks
fill 424 190 492 424 192 493 minecraft:blackstone
fill 424 190 498 424 192 498 minecraft:blackstone
setblock 424 190 501 minecraft:polished_blackstone_bricks
fill 424 190 502 424 193 502 minecraft:blackstone
setblock 425 190 465 minecraft:polished_blackstone_bricks
fill 425 190 466 425 193 466 minecraft:blackstone
setblock 425 190 470 minecraft:polished_blackstone_bricks
fill 425 190 471 426 192 471 minecraft:blackstone
setblock 425 190 475 minecraft:polished_blackstone_bricks
fill 425 190 476 425 193 476 minecraft:blackstone
setblock 425 190 480 minecraft:polished_blackstone_bricks
fill 425 190 481 425 193 481 minecraft:blackstone
setblock 425 190 485 minecraft:polished_blackstone_bricks
fill 425 190 486 426 191 486 minecraft:blackstone
setblock 425 190 490 minecraft:polished_blackstone_bricks
setblock 425 190 501 minecraft:blackstone
setblock 426 190 464 minecraft:polished_blackstone_bricks
fill 426 190 465 426 193 465 minecraft:blackstone
setblock 426 190 469 minecraft:polished_blackstone_bricks
fill 426 190 470 426 193 470 minecraft:blackstone
setblock 426 190 474 minecraft:light[level=11]
setblock 426 190 484 minecraft:polished_blackstone_bricks
fill 426 190 485 426 191 485 minecraft:blackstone
setblock 426 190 490 minecraft:light[level=11]
setblock 426 190 498 minecraft:light[level=11]
setblock 426 190 504 minecraft:polished_blackstone_bricks
fill 427 190 464 430 190 464 minecraft:blackstone
setblock 427 190 467 minecraft:blackstone
setblock 427 190 503 minecraft:polished_blackstone_bricks
fill 427 190 504 430 190 504 minecraft:blackstone
fill 428 190 503 428 192 503 minecraft:blackstone
setblock 429 190 466 minecraft:polished_blackstone_bricks
setblock 430 190 465 minecraft:polished_blackstone_bricks
fill 430 190 466 431 192 466 minecraft:blackstone
setblock 431 190 464 minecraft:polished_blackstone_bricks
fill 431 190 465 431 193 465 minecraft:blackstone
setblock 431 190 504 minecraft:polished_blackstone_bricks
fill 432 190 464 435 190 464 minecraft:blackstone
fill 432 190 504 435 190 504 minecraft:blackstone
fill 433 190 465 434 190 465 minecraft:blackstone
setblock 434 190 466 minecraft:light[level=11]
setblock 434 190 474 minecraft:light[level=11]
setblock 434 190 482 minecraft:light[level=11]
setblock 434 190 490 minecraft:light[level=11]
setblock 434 190 498 minecraft:light[level=11]
setblock 435 190 465 minecraft:polished_blackstone_bricks
fill 435 190 503 436 190 503 minecraft:blackstone
setblock 436 190 464 minecraft:polished_blackstone_bricks
fill 436 190 465 436 193 465 minecraft:blackstone
setblock 436 190 504 minecraft:polished_blackstone_bricks
fill 437 190 464 437 193 464 minecraft:blackstone
setblock 437 190 503 minecraft:polished_blackstone_bricks
fill 437 190 504 437 193 504 minecraft:blackstone
fill 438 190 503 438 193 503 minecraft:blackstone
setblock 439 190 466 minecraft:polished_blackstone_bricks
fill 439 190 502 439 193 502 minecraft:blackstone
setblock 440 190 464 minecraft:blackstone
setblock 440 190 465 minecraft:polished_blackstone_bricks
fill 440 190 466 441 192 466 minecraft:blackstone
setblock 441 190 464 minecraft:polished_blackstone_bricks
fill 441 190 465 441 193 465 minecraft:blackstone
setblock 441 190 504 minecraft:polished_blackstone_bricks
fill 442 190 464 442 193 464 minecraft:blackstone
setblock 442 190 474 minecraft:light[level=11]
setblock 442 190 482 minecraft:light[level=11]
setblock 442 190 490 minecraft:light[level=11]
setblock 442 190 498 minecraft:light[level=11]
setblock 442 190 503 minecraft:polished_blackstone_bricks
fill 442 190 504 442 193 504 minecraft:blackstone
setblock 443 190 466 minecraft:blackstone
setblock 443 190 502 minecraft:polished_blackstone_bricks
fill 443 190 503 443 193 503 minecraft:blackstone
setblock 444 190 466 minecraft:polished_blackstone_bricks
fill 444 190 502 444 193 502 minecraft:blackstone
setblock 445 190 465 minecraft:polished_blackstone_bricks
fill 445 190 466 445 193 466 minecraft:blackstone
setblock 446 190 464 minecraft:polished_blackstone_bricks
fill 446 190 465 446 193 465 minecraft:blackstone
setblock 446 190 504 minecraft:polished_blackstone_bricks
fill 447 190 464 447 193 464 minecraft:blackstone
fill 447 190 488 447 190 491 minecraft:blackstone
setblock 447 190 503 minecraft:polished_blackstone_bricks
fill 447 190 504 447 193 504 minecraft:blackstone
fill 448 190 487 448 190 488 minecraft:blackstone
fill 448 190 492 448 190 493 minecraft:blackstone
setblock 448 190 502 minecraft:polished_blackstone_bricks
fill 448 190 503 448 193 503 minecraft:blackstone
fill 449 190 486 453 190 486 minecraft:blackstone
setblock 449 190 493 minecraft:blackstone
setblock 450 190 466 minecraft:light[level=11]
setblock 450 190 474 minecraft:light[level=11]
setblock 450 190 482 minecraft:light[level=11]
fill 450 190 494 452 190 494 minecraft:blackstone
setblock 450 190 498 minecraft:light[level=11]
setblock 451 190 464 minecraft:polished_blackstone_bricks
setblock 451 190 504 minecraft:polished_blackstone_bricks
fill 452 190 464 452 192 464 minecraft:blackstone
fill 452 190 504 452 192 504 minecraft:blackstone
fill 453 190 493 454 190 493 minecraft:blackstone
setblock 454 190 487 minecraft:blackstone
setblock 454 190 492 minecraft:blackstone
fill 455 190 488 455 190 491 minecraft:blackstone
setblock 456 190 504 minecraft:polished_blackstone_bricks
fill 457 190 464 460 190 464 minecraft:blackstone
fill 457 190 504 457 193 504 minecraft:blackstone
setblock 458 190 466 minecraft:light[level=11]
setblock 458 190 474 minecraft:light[level=11]
setblock 458 190 482 minecraft:light[level=11]
setblock 458 190 490 minecraft:light[level=11]
setblock 458 190 498 minecraft:light[level=11]
setblock 460 190 465 minecraft:polished_blackstone_bricks
setblock 461 190 464 minecraft:polished_blackstone_bricks
fill 461 190 465 461 193 465 minecraft:blackstone
fill 461 190 482 461 190 483 minecraft:blackstone
setblock 461 190 484 minecraft:polished_blackstone_bricks
fill 461 190 485 461 193 485 minecraft:blackstone
fill 461 190 487 461 190 488 minecraft:blackstone
setblock 461 190 504 minecraft:polished_blackstone_bricks
fill 462 190 464 462 193 464 minecraft:blackstone
fill 462 190 466 463 190 466 minecraft:blackstone
setblock 462 190 478 minecraft:polished_blackstone_bricks
fill 462 190 479 462 193 479 minecraft:blackstone
setblock 462 190 483 minecraft:polished_blackstone_bricks
fill 462 190 484 462 193 484 minecraft:blackstone
setblock 462 190 488 minecraft:polished_blackstone_bricks
fill 462 190 489 462 192 490 minecraft:blackstone
setblock 462 190 503 minecraft:polished_blackstone_bricks
fill 462 190 504 462 193 504 minecraft:blackstone
fill 463 190 465 463 191 465 minecraft:blackstone
setblock 463 190 467 minecraft:polished_blackstone_bricks
fill 463 190 468 463 190 471 minecraft:blackstone
setblock 463 190 472 minecraft:polished_blackstone_bricks
fill 463 190 473 463 193 473 minecraft:blackstone
setblock 463 190 477 minecraft:polished_blackstone_bricks
fill 463 190 478 463 193 478 minecraft:blackstone
setblock 463 190 482 minecraft:polished_blackstone_bricks
fill 463 190 483 463 193 483 minecraft:blackstone
setblock 463 190 487 minecraft:polished_blackstone_bricks
fill 463 190 488 463 193 488 minecraft:blackstone
setblock 463 190 492 minecraft:polished_blackstone_bricks
fill 463 190 493 463 193 493 minecraft:blackstone
setblock 463 190 502 minecraft:polished_blackstone_bricks
fill 463 190 503 463 192 503 minecraft:blackstone
setblock 464 190 466 minecraft:polished_blackstone_bricks
fill 464 190 467 464 193 467 minecraft:blackstone
setblock 464 190 470 minecraft:blackstone
setblock 464 190 471 minecraft:polished_blackstone_bricks
fill 464 190 472 464 193 472 minecraft:blackstone
setblock 464 190 476 minecraft:polished_blackstone_bricks
fill 464 190 477 464 193 477 minecraft:blackstone
setblock 464 190 481 minecraft:polished_blackstone_bricks
fill 464 190 482 464 193 482 minecraft:blackstone
setblock 464 190 486 minecraft:polished_blackstone_bricks
fill 464 190 487 464 193 487 minecraft:blackstone
setblock 464 190 491 minecraft:polished_blackstone_bricks
fill 464 190 492 464 193 492 minecraft:blackstone
setblock 464 190 496 minecraft:polished_blackstone_bricks
fill 464 190 497 464 193 497 minecraft:blackstone
setblock 464 190 501 minecraft:polished_blackstone_bricks
fill 464 190 502 464 193 502 minecraft:blackstone
setblock 424 191 465 minecraft:polished_blackstone_bricks
fill 424 191 466 424 194 466 minecraft:blackstone
setblock 424 191 470 minecraft:polished_blackstone_bricks
fill 424 191 471 424 194 471 minecraft:blackstone
setblock 424 191 475 minecraft:polished_blackstone_bricks
fill 424 191 476 424 194 476 minecraft:blackstone
setblock 424 191 480 minecraft:polished_blackstone_bricks
fill 424 191 481 424 194 481 minecraft:blackstone
setblock 424 191 485 minecraft:polished_blackstone_bricks
fill 424 191 486 424 194 486 minecraft:blackstone
setblock 424 191 490 minecraft:polished_blackstone_bricks
fill 424 191 491 425 193 491 minecraft:blackstone
setblock 424 191 494 minecraft:blackstone
setblock 424 191 495 minecraft:polished_blackstone_bricks
setblock 424 191 500 minecraft:polished_blackstone_bricks
fill 424 191 501 424 194 501 minecraft:blackstone
setblock 425 191 464 minecraft:polished_blackstone_bricks
fill 425 191 465 425 194 465 minecraft:blackstone
setblock 425 191 468 minecraft:blackstone
setblock 425 191 469 minecraft:polished_blackstone_bricks
fill 425 191 470 425 194 470 minecraft:blackstone
setblock 425 191 474 minecraft:polished_blackstone_bricks
fill 425 191 475 425 194 475 minecraft:blackstone
setblock 425 191 479 minecraft:polished_blackstone_bricks
fill 425 191 480 425 193 480 minecraft:blackstone
setblock 425 191 484 minecraft:polished_blackstone_bricks
fill 425 191 485 425 194 485 minecraft:blackstone
setblock 425 191 489 minecraft:polished_blackstone_bricks
fill 425 191 490 425 194 490 minecraft:blackstone
setblock 425 191 504 minecraft:polished_blackstone_bricks
fill 426 191 464 429 191 464 minecraft:blackstone
setblock 426 191 468 minecraft:polished_blackstone_bricks
fill 426 191 469 426 194 469 minecraft:blackstone
setblock 426 191 483 minecraft:polished_blackstone_bricks
setblock 426 191 484 minecraft:blackstone
setblock 426 191 503 minecraft:polished_blackstone_bricks
fill 426 191 504 429 191 504 minecraft:blackstone
setblock 427 191 467 minecraft:polished_blackstone_bricks
fill 427 191 468 427 193 468 minecraft:blackstone
fill 427 191 503 427 193 503 minecraft:blackstone
setblock 428 191 466 minecraft:polished_blackstone_bricks
setblock 429 191 465 minecraft:polished_blackstone_bricks
fill 429 191 466 429 194 466 minecraft:blackstone
setblock 430 191 464 minecraft:polished_blackstone_bricks
fill 430 191 465 430 194 465 minecraft:blackstone
setblock 430 191 504 minecraft:polished_blackstone_bricks
fill 431 191 464 434 191 464 minecraft:blackstone
fill 431 191 504 434 191 504 minecraft:blackstone
setblock 433 191 465 minecraft:blackstone
setblock 434 191 465 minecraft:polished_blackstone_bricks
fill 434 191 503 435 191 503 minecraft:blackstone
setblock 435 191 464 minecraft:polished_blackstone_bricks
fill 435 191 465 435 194 465 minecraft:blackstone
setblock 435 191 504 minecraft:polished_blackstone_bricks
fill 436 191 464 436 194 464 minecraft:blackstone
setblock 436 191 503 minecraft:polished_blackstone_bricks
fill 436 191 504 436 194 504 minecraft:blackstone
setblock 437 191 466 minecraft:blackstone
fill 437 191 503 437 194 503 minecraft:blackstone
setblock 438 191 465 minecraft:blackstone
setblock 438 191 466 minecraft:polished_blackstone_bricks
setblock 439 191 465 minecraft:polished_blackstone_bricks
fill 439 191 466 439 194 466 minecraft:blackstone
setblock 440 191 464 minecraft:polished_blackstone_bricks
fill 440 191 465 440 194 465 minecraft:blackstone
setblock 440 191 504 minecraft:polished_blackstone_bricks
fill 441 191 464 441 194 464 minecraft:blackstone
setblock 441 191 503 minecraft:polished_blackstone_bricks
fill 441 191 504 441 194 504 minecraft:blackstone
setblock 442 191 502 minecraft:polished_blackstone_bricks
fill 442 191 503 442 194 503 minecraft:blackstone
setblock 443 191 466 minecraft:polished_blackstone_bricks
fill 443 191 502 443 194 502 minecraft:blackstone
setblock 444 191 465 minecraft:polished_blackstone_bricks
fill 444 191 466 444 194 466 minecraft:blackstone
setblock 445 191 464 minecraft:polished_blackstone_bricks
fill 445 191 465 445 194 465 minecraft:blackstone
setblock 445 191 504 minecraft:polished_blackstone_bricks
fill 446 191 464 446 194 464 minecraft:blackstone
setblock 446 191 466 minecraft:blackstone
setblock 446 191 503 minecraft:polished_blackstone_bricks
fill 446 191 504 446 194 504 minecraft:blackstone
setblock 447 191 502 minecraft:polished_blackstone_bricks
fill 447 191 503 447 193 503 minecraft:blackstone
setblock 450 191 464 minecraft:polished_blackstone_bricks
setblock 450 191 504 minecraft:polished_blackstone_bricks
fill 451 191 464 451 193 464 minecraft:blackstone
fill 451 191 504 451 193 504 minecraft:blackstone
setblock 455 191 464 minecraft:polished_blackstone_bricks
setblock 455 191 504 minecraft:polished_blackstone_bricks
fill 456 191 464 459 191 464 minecraft:blackstone
fill 456 191 504 456 192 504 minecraft:blackstone
setblock 458 191 465 minecraft:blackstone
setblock 459 191 465 minecraft:polished_blackstone_bricks
setblock 460 191 464 minecraft:polished_blackstone_bricks
fill 460 191 465 460 194 465 minecraft:blackstone
setblock 460 191 504 minecraft:polished_blackstone_bricks
fill 461 191 464 461 194 464 minecraft:blackstone
fill 461 191 466 462 191 466 minecraft:blackstone
fill 461 191 481 461 191 482 minecraft:blackstone
setblock 461 191 483 minecraft:polished_blackstone_bricks
fill 461 191 484 461 194 484 minecraft:blackstone
setblock 461 191 487 minecraft:blackstone
setblock 461 191 488 minecraft:polished_blackstone_bricks
fill 461 191 489 461 194 489 minecraft:blackstone
setblock 461 191 503 minecraft:polished_blackstone_bricks
fill 461 191 504 461 194 504 minecraft:blackstone
setblock 462 191 467 minecraft:polished_blackstone_bricks
fill 462 191 468 463 191 470 minecraft:blackstone
setblock 462 191 477 minecraft:polished_blackstone_bricks
fill 462 191 478 462 194 478 minecraft:blackstone
setblock 462 191 482 minecraft:polished_blackstone_bricks
fill 462 191 483 462 194 483 minecraft:blackstone
setblock 462 191 487 minecraft:polished_blackstone_bricks
fill 462 191 488 462 194 488 minecraft:blackstone
setblock 462 191 491 minecraft:blackstone
fill 462 191 503 462 192 503 minecraft:blackstone
setblock 463 191 466 minecraft:polished_blackstone_bricks
fill 463 191 467 463 194 467 minecraft:blackstone
setblock 463 191 471 minecraft:polished_blackstone_bricks
fill 463 191 472 463 194 472 minecraft:blackstone
setblock 463 191 476 minecraft:polished_blackstone_bricks
fill 463 191 477 463 194 477 minecraft:blackstone
setblock 463 191 481 minecraft:polished_blackstone_bricks
fill 463 191 482 463 194 482 minecraft:blackstone
setblock 463 191 486 minecraft:polished_blackstone_bricks
fill 463 191 487 463 194 487 minecraft:blackstone
setblock 463 191 490 minecraft:blackstone
setblock 463 191 491 minecraft:polished_blackstone_bricks
fill 463 191 492 463 194 492 minecraft:blackstone
fill 463 191 494 464 191 494 minecraft:blackstone
setblock 464 191 465 minecraft:polished_blackstone_bricks
fill 464 191 466 464 194 466 minecraft:blackstone
setblock 464 191 470 minecraft:polished_blackstone_bricks
fill 464 191 471 464 194 471 minecraft:blackstone
setblock 464 191 475 minecraft:polished_blackstone_bricks
fill 464 191 476 464 194 476 minecraft:blackstone
setblock 464 191 480 minecraft:polished_blackstone_bricks
fill 464 191 481 464 194 481 minecraft:blackstone
setblock 464 191 485 minecraft:polished_blackstone_bricks
fill 464 191 486 464 194 486 minecraft:blackstone
setblock 464 191 490 minecraft:polished_blackstone_bricks
fill 464 191 491 464 194 491 minecraft:blackstone
setblock 464 191 495 minecraft:polished_blackstone_bricks
fill 464 191 496 464 194 496 minecraft:blackstone
setblock 464 191 500 minecraft:polished_blackstone_bricks
fill 464 191 501 464 193 501 minecraft:blackstone
setblock 424 192 464 minecraft:polished_blackstone_bricks
fill 424 192 465 424 195 465 minecraft:blackstone
setblock 424 192 469 minecraft:polished_blackstone_bricks
fill 424 192 470 424 195 470 minecraft:blackstone
setblock 424 192 474 minecraft:polished_blackstone_bricks
fill 424 192 475 424 195 475 minecraft:blackstone
setblock 424 192 479 minecraft:polished_blackstone_bricks
fill 424 192 480 424 195 480 minecraft:blackstone
setblock 424 192 484 minecraft:polished_blackstone_bricks
fill 424 192 485 424 195 485 minecraft:blackstone
setblock 424 192 489 minecraft:polished_blackstone_bricks
fill 424 192 490 424 195 490 minecraft:blackstone
setblock 424 192 494 minecraft:polished_blackstone_bricks
fill 424 192 495 424 193 497 minecraft:blackstone
setblock 424 192 499 minecraft:polished_blackstone_bricks
fill 424 192 500 424 194 500 minecraft:blackstone
setblock 424 192 504 minecraft:polished_blackstone_bricks
fill 425 192 464 428 192 464 minecraft:blackstone
setblock 425 192 468 minecraft:polished_blackstone_bricks
fill 425 192 469 425 195 469 minecraft:blackstone
setblock 425 192 473 minecraft:polished_blackstone_bricks
fill 425 192 474 425 195 474 minecraft:blackstone
setblock 425 192 478 minecraft:polished_blackstone_bricks
fill 425 192 479 425 193 479 minecraft:blackstone
setblock 425 192 483 minecraft:polished_blackstone_bricks
fill 425 192 484 425 194 484 minecraft:blackstone
fill 425 192 486 425 193 486 minecraft:blackstone
setblock 425 192 488 minecraft:polished_blackstone_bricks
fill 425 192 489 425 195 489 minecraft:blackstone
setblock 425 192 503 minecraft:polished_blackstone_bricks
fill 425 192 504 428 192 504 minecraft:blackstone
setblock 426 192 467 minecraft:polished_blackstone_bricks
fill 426 192 468 426 195 468 minecraft:blackstone
setblock 426 192 472 minecraft:polished_blackstone_bricks
fill 426 192 503 426 193 503 minecraft:blackstone
setblock 427 192 466 minecraft:polished_blackstone_bricks
fill 427 192 467 427 194 467 minecraft:blackstone
setblock 428 192 465 minecraft:polished_blackstone_bricks
fill 428 192 466 428 195 466 minecraft:blackstone
setblock 429 192 464 minecraft:polished_blackstone_bricks
fill 429 192 465 429 195 465 minecraft:blackstone
setblock 429 192 504 minecraft:polished_blackstone_bricks
fill 430 192 464 433 192 464 minecraft:blackstone
fill 430 192 504 433 192 504 minecraft:blackstone
setblock 432 192 466 minecraft:polished_blackstone_bricks
setblock 433 192 465 minecraft:polished_blackstone_bricks
setblock 434 192 464 minecraft:polished_blackstone_bricks
fill 434 192 465 434 195 465 minecraft:blackstone
setblock 434 192 503 minecraft:blackstone
setblock 434 192 504 minecraft:polished_blackstone_bricks
fill 435 192 464 435 195 464 minecraft:blackstone
setblock 435 192 503 minecraft:polished_blackstone_bricks
fill 435 192 504 435 195 504 minecraft:blackstone
setblock 436 192 466 minecraft:blackstone
fill 436 192 503 436 195 503 minecraft:blackstone
setblock 437 192 466 minecraft:polished_blackstone_bricks
setblock 438 192 465 minecraft:polished_blackstone_bricks
fill 438 192 466 438 195 466 minecraft:blackstone
fill 438 192 502 438 193 502 minecraft:blackstone
setblock 439 192 464 minecraft:polished_blackstone_bricks
fill 439 192 465 439 195 465 minecraft:blackstone
setblock 439 192 504 minecraft:polished_blackstone_bricks
fill 440 192 464 440 195 464 minecraft:blackstone
setblock 440 192 503 minecraft:polished_blackstone_bricks
fill 440 192 504 440 195 504 minecraft:blackstone
setblock 441 192 502 minecraft:polished_blackstone_bricks
fill 441 192 503 441 195 503 minecraft:blackstone
setblock 442 192 465 minecraft:blackstone
setblock 442 192 466 minecraft:polished_blackstone_bricks
fill 442 192 502 442 195 502 minecraft:blackstone
setblock 443 192 465 minecraft:polished_blackstone_bricks
fill 443 192 466 443 195 466 minecraft:blackstone
setblock 444 192 464 minecraft:polished_blackstone_bricks
fill 444 192 465 444 195 465 minecraft:blackstone
setblock 444 192 504 minecraft:polished_blackstone_bricks
fill 445 192 464 445 195 464 minecraft:blackstone
setblock 445 192 503 minecraft:polished_blackstone_bricks
fill 445 192 504 445 195 504 minecraft:blackstone
setblock 446 192 502 minecraft:polished_blackstone_bricks
fill 446 192 503 446 194 503 minecraft:blackstone
setblock 448 192 465 minecraft:polished_blackstone_bricks
setblock 449 192 464 minecraft:polished_blackstone_bricks
setblock 449 192 504 minecraft:polished_blackstone_bricks
fill 450 192 464 450 193 464 minecraft:blackstone
fill 450 192 504 450 193 504 minecraft:blackstone
setblock 454 192 464 minecraft:polished_blackstone_bricks
fill 455 192 464 458 192 464 minecraft:blackstone
setblock 458 192 465 minecraft:polished_blackstone_bricks
setblock 459 192 464 minecraft:polished_blackstone_bricks
fill 459 192 465 459 195 465 minecraft:blackstone
setblock 459 192 504 minecraft:polished_blackstone_bricks
fill 460 192 464 460 195 464 minecraft:blackstone
fill 460 192 466 461 192 466 minecraft:blackstone
fill 460 192 504 460 195 504 minecraft:blackstone
setblock 461 192 481 minecraft:blackstone
setblock 461 192 482 minecraft:polished_blackstone_bricks
fill 461 192 483 461 194 483 minecraft:blackstone
setblock 461 192 487 minecraft:polished_blackstone_bricks
fill 461 192 488 461 195 488 minecraft:blackstone
fill 461 192 490 461 193 490 minecraft:blackstone
setblock 462 192 466 minecraft:polished_blackstone_bricks
fill 462 192 467 462 192 470 minecraft:blackstone
setblock 462 192 471 minecraft:polished_blackstone_bricks
fill 462 192 472 462 193 474 minecraft:blackstone
setblock 462 192 476 minecraft:polished_blackstone_bricks
fill 462 192 477 462 194 477 minecraft:blackstone
setblock 462 192 481 minecraft:polished_blackstone_bricks
fill 462 192 482 462 195 482 minecraft:blackstone
setblock 462 192 486 minecraft:polished_blackstone_bricks
fill 462 192 487 462 195 487 minecraft:blackstone
setblock 462 192 491 minecraft:polished_blackstone_bricks
fill 462 192 492 462 195 492 minecraft:blackstone
setblock 463 192 465 minecraft:polished_blackstone_bricks
fill 463 192 466 463 195 466 minecraft:blackstone
fill 463 192 468 463 192 469 minecraft:blackstone
setblock 463 192 470 minecraft:polished_blackstone_bricks
fill 463 192 471 463 195 471 minecraft:blackstone
setblock 463 192 475 minecraft:polished_blackstone_bricks
fill 463 192 476 463 195 476 minecraft:blackstone
setblock 463 192 480 minecraft:polished_blackstone_bricks
fill 463 192 481 463 195 481 minecraft:blackstone
setblock 463 192 485 minecraft:polished_blackstone_bricks
fill 463 192 486 463 195 486 minecraft:blackstone
setblock 463 192 490 minecraft:polished_blackstone_bricks
fill 463 192 491 463 195 491 minecraft:blackstone
setblock 463 192 494 minecraft:blackstone
setblock 464 192 464 minecraft:polished_blackstone_bricks
fill 464 192 465 464 195 465 minecraft:blackstone
setblock 464 192 469 minecraft:polished_blackstone_bricks
fill 464 192 470 464 195 470 minecraft:blackstone
setblock 464 192 474 minecraft:polished_blackstone_bricks
fill 464 192 475 464 195 475 minecraft:blackstone
setblock 464 192 479 minecraft:polished_blackstone_bricks
fill 464 192 480 464 195 480 minecraft:blackstone
setblock 464 192 484 minecraft:polished_blackstone_bricks
fill 464 192 485 464 195 485 minecraft:blackstone
setblock 464 192 489 minecraft:polished_blackstone_bricks
fill 464 192 490 464 195 490 minecraft:blackstone
setblock 464 192 494 minecraft:polished_blackstone_bricks
fill 464 192 495 464 195 495 minecraft:blackstone
setblock 464 192 499 minecraft:polished_blackstone_bricks
fill 464 192 500 464 193 500 minecraft:blackstone
setblock 464 192 504 minecraft:polished_blackstone_bricks
fill 424 193 464 427 193 464 minecraft:blackstone
setblock 424 193 468 minecraft:polished_blackstone_bricks
fill 424 193 469 424 196 469 minecraft:blackstone
setblock 424 193 473 minecraft:polished_blackstone_bricks
fill 424 193 474 424 196 474 minecraft:blackstone
setblock 424 193 478 minecraft:polished_blackstone_bricks
fill 424 193 479 424 195 479 minecraft:blackstone
setblock 424 193 483 minecraft:polished_blackstone_bricks
fill 424 193 484 424 196 484 minecraft:blackstone
setblock 424 193 488 minecraft:polished_blackstone_bricks
fill 424 193 489 424 196 489 minecraft:blackstone
setblock 424 193 492 minecraft:blackstone
setblock 424 193 493 minecraft:polished_blackstone_bricks
fill 424 193 494 424 196 494 minecraft:blackstone
setblock 424 193 498 minecraft:polished_blackstone_bricks
fill 424 193 499 424 194 499 minecraft:blackstone
setblock 424 193 503 minecraft:polished_blackstone_bricks
fill 424 193 504 427 193 504 minecraft:blackstone
setblock 425 193 467 minecraft:polished_blackstone_bricks
fill 425 193 468 425 196 468 minecraft:blackstone
setblock 425 193 471 minecraft:blackstone
setblock 425 193 472 minecraft:polished_blackstone_bricks
fill 425 193 473 425 196 473 minecraft:blackstone
setblock 425 193 477 minecraft:polished_blackstone_bricks
setblock 425 193 478 minecraft:blackstone
setblock 425 193 482 minecraft:polished_blackstone_bricks
fill 425 193 483 425 194 483 minecraft:blackstone
setblock 425 193 487 minecraft:polished_blackstone_bricks
fill 425 193 488 425 195 488 minecraft:blackstone
setblock 425 193 502 minecraft:polished_blackstone_bricks
fill 425 193 503 425 194 503 minecraft:blackstone
setblock 426 193 466 minecraft:polished_blackstone_bricks
fill 426 193 467 426 196 467 minecraft:blackstone
setblock 426 193 471 minecraft:polished_blackstone_bricks
setblock 426 193 472 minecraft:blackstone
setblock 427 193 465 minecraft:polished_blackstone_bricks
fill 427 193 466 427 196 466 minecraft:blackstone
setblock 428 193 464 minecraft:polished_blackstone_bricks
fill 428 193 465 428 196 465 minecraft:blackstone
setblock 428 193 504 minecraft:polished_blackstone_bricks
fill 429 193 464 432 193 464 minecraft:blackstone
fill 429 193 504 432 193 504 minecraft:blackstone
setblock 430 193 466 minecraft:blackstone
setblock 431 193 466 minecraft:polished_blackstone_bricks
setblock 432 193 465 minecraft:polished_blackstone_bricks
setblock 433 193 464 minecraft:polished_blackstone_bricks
fill 433 193 465 433 196 465 minecraft:blackstone
setblock 433 193 504 minecraft:polished_blackstone_bricks
fill 434 193 464 434 196 464 minecraft:blackstone
fill 434 193 504 434 196 504 minecraft:blackstone
setblock 435 193 466 minecraft:blackstone
fill 435 193 503 435 194 503 minecraft:blackstone
setblock 436 193 466 minecraft:polished_blackstone_bricks
setblock 437 193 465 minecraft:polished_blackstone_bricks
fill 437 193 466 437 196 466 minecraft:blackstone
setblock 438 193 464 minecraft:polished_blackstone_bricks
fill 438 193 465 438 196 465 minecraft:blackstone
setblock 438 193 504 minecraft:polished_blackstone_bricks
fill 439 193 464 439 196 464 minecraft:blackstone
setblock 439 193 503 minecraft:polished_blackstone_bricks
fill 439 193 504 439 196 504 minecraft:blackstone
setblock 440 193 466 minecraft:blackstone
setblock 440 193 502 minecraft:polished_blackstone_bricks
fill 440 193 503 440 196 503 minecraft:blackstone
setblock 441 193 466 minecraft:polished_blackstone_bricks
fill 441 193 502 441 195 502 minecraft:blackstone
setblock 442 193 465 minecraft:polished_blackstone_bricks
fill 442 193 466 442 195 466 minecraft:blackstone
setblock 443 193 464 minecraft:polished_blackstone_bricks
fill 443 193 465 443 196 465 minecraft:blackstone
setblock 443 193 504 minecraft:polished_blackstone_bricks
fill 444 193 464 444 196 464 minecraft:blackstone
setblock 444 193 503 minecraft:polished_blackstone_bricks
fill 444 193 504 444 196 504 minecraft:blackstone
setblock 445 193 502 minecraft:polished_blackstone_bricks
fill 445 193 503 445 195 503 minecraft:blackstone
setblock 447 193 465 minecraft:polished_blackstone_bricks
setblock 448 193 464 minecraft:polished_blackstone_bricks
setblock 448 193 465 minecraft:blackstone
setblock 448 193 504 minecraft:polished_blackstone_bricks
fill 449 193 464 449 194 464 minecraft:blackstone
fill 449 193 504 449 194 504 minecraft:blackstone
fill 454 193 464 457 193 464 minecraft:blackstone
setblock 457 193 465 minecraft:polished_blackstone_bricks
setblock 458 193 464 minecraft:polished_blackstone_bricks
fill 458 193 465 458 196 465 minecraft:blackstone
setblock 458 193 504 minecraft:polished_blackstone_bricks
fill 459 193 464 459 196 464 minecraft:blackstone
fill 459 193 466 460 193 466 minecraft:blackstone
fill 459 193 504 459 195 504 minecraft:blackstone
setblock 461 193 466 minecraft:polished_blackstone_bricks
setblock 461 193 482 minecraft:blackstone
setblock 461 193 486 minecraft:polished_blackstone_bricks
fill 461 193 487 461 195 487 minecraft:blackstone
setblock 462 193 465 minecraft:polished_blackstone_bricks
fill 462 193 466 462 193 469 minecraft:blackstone
setblock 462 193 470 minecraft:polished_blackstone_bricks
fill 462 193 471 462 196 471 minecraft:blackstone
setblock 462 193 475 minecraft:polished_blackstone_bricks
fill 462 193 476 462 195 476 minecraft:blackstone
setblock 462 193 480 minecraft:polished_blackstone_bricks
fill 462 193 481 462 195 481 minecraft:blackstone
setblock 462 193 485 minecraft:polished_blackstone_bricks
fill 462 193 486 462 196 486 minecraft:blackstone
setblock 462 193 489 minecraft:blackstone
setblock 462 193 490 minecraft:polished_blackstone_bricks
fill 462 193 491 462 196 491 minecraft:blackstone
setblock 463 193 464 minecraft:polished_blackstone_bricks
fill 463 193 465 463 196 465 minecraft:blackstone
setblock 463 193 468 minecraft:blackstone
setblock 463 193 469 minecraft:polished_blackstone_bricks
fill 463 193 470 463 196 470 minecraft:blackstone
setblock 463 193 474 minecraft:polished_blackstone_bricks
fill 463 193 475 463 196 475 minecraft:blackstone
setblock 463 193 479 minecraft:polished_blackstone_bricks
fill 463 193 480 463 196 480 minecraft:blackstone
setblock 463 193 484 minecraft:polished_blackstone_bricks
fill 463 193 485 463 196 485 minecraft:blackstone
setblock 463 193 489 minecraft:polished_blackstone_bricks
fill 463 193 490 463 196 490 minecraft:blackstone
setblock 463 193 494 minecraft:polished_blackstone_bricks
setblock 463 193 504 minecraft:polished_blackstone_bricks
fill 464 193 464 464 196 464 minecraft:blackstone
setblock 464 193 468 minecraft:polished_blackstone_bricks
fill 464 193 469 464 196 469 minecraft:blackstone
setblock 464 193 473 minecraft:polished_blackstone_bricks
fill 464 193 474 464 196 474 minecraft:blackstone
setblock 464 193 478 minecraft:polished_blackstone_bricks
fill 464 193 479 464 196 479 minecraft:blackstone
setblock 464 193 483 minecraft:polished_blackstone_bricks
fill 464 193 484 464 196 484 minecraft:blackstone
setblock 464 193 488 minecraft:polished_blackstone_bricks
fill 464 193 489 464 196 489 minecraft:blackstone
setblock 464 193 493 minecraft:polished_blackstone_bricks
fill 464 193 494 464 196 494 minecraft:blackstone
setblock 464 193 498 minecraft:polished_blackstone_bricks
setblock 464 193 499 minecraft:blackstone
setblock 464 193 503 minecraft:polished_blackstone_bricks
fill 464 193 504 464 195 504 minecraft:blackstone
fill 424 194 464 426 194 464 minecraft:blackstone
setblock 424 194 467 minecraft:polished_blackstone_bricks
fill 424 194 468 424 197 468 minecraft:blackstone
setblock 424 194 472 minecraft:polished_blackstone_bricks
fill 424 194 473 424 197 473 minecraft:blackstone
setblock 424 194 477 minecraft:polished_blackstone_bricks
fill 424 194 478 424 196 478 minecraft:blackstone
setblock 424 194 482 minecraft:polished_blackstone_bricks
fill 424 194 483 424 196 483 minecraft:blackstone
setblock 424 194 487 minecraft:polished_blackstone_bricks
fill 424 194 488 424 197 488 minecraft:blackstone
setblock 424 194 491 minecraft:blackstone
setblock 424 194 492 minecraft:polished_blackstone_bricks
fill 424 194 493 424 197 493 minecraft:blackstone
fill 424 194 495 424 194 496 minecraft:blackstone
setblock 424 194 502 minecraft:polished_blackstone_bricks
fill 424 194 503 424 196 504 minecraft:blackstone
setblock 425 194 466 minecraft:polished_blackstone_bricks
fill 425 194 467 425 197 467 minecraft:blackstone
setblock 425 194 471 minecraft:polished_blackstone_bricks
fill 425 194 472 425 197 472 minecraft:blackstone
setblock 425 194 486 minecraft:polished_blackstone_bricks
fill 425 194 487 425 195 487 minecraft:blackstone
setblock 425 194 491 minecraft:polished_blackstone_bricks
fill 425 194 504 426 194 504 minecraft:blackstone
setblock 426 194 465 minecraft:polished_blackstone_bricks
fill 426 194 466 426 196 466 minecraft:blackstone
setblock 426 194 470 minecraft:polished_blackstone_bricks
fill 426 194 471 426 195 471 minecraft:blackstone
setblock 427 194 464 minecraft:polished_blackstone_bricks
fill 427 194 465 427 197 465 minecraft:blackstone
setblock 427 194 504 minecraft:polished_blackstone_bricks
fill 428 194 464 431 194 464 minecraft:blackstone
fill 428 194 504 431 194 504 minecraft:blackstone
setblock 430 194 466 minecraft:polished_blackstone_bricks
setblock 431 194 465 minecraft:polished_blackstone_bricks
setblock 432 194 464 minecraft:polished_blackstone_bricks
fill 432 194 465 432 196 465 minecraft:blackstone
setblock 432 194 504 minecraft:polished_blackstone_bricks
fill 433 194 464 433 197 464 minecraft:blackstone
fill 433 194 504 433 197 504 minecraft:blackstone
setblock 435 194 466 minecraft:polished_blackstone_bricks
setblock 436 194 465 minecraft:polished_blackstone_bricks
fill 436 194 466 436 195 466 minecraft:blackstone
setblock 437 194 464 minecraft:polished_blackstone_bricks
fill 437 194 465 437 197 465 minecraft:blackstone
setblock 437 194 504 minecraft:polished_blackstone_bricks
fill 438 194 464 438 197 464 minecraft:blackstone
setblock 438 194 503 minecraft:polished_blackstone_bricks
fill 438 194 504 438 197 504 minecraft:blackstone
setblock 439 194 502 minecraft:polished_blackstone_bricks
fill 439 194 503 439 197 503 minecraft:blackstone
setblock 440 194 466 minecraft:polished_blackstone_bricks
fill 440 194 502 440 195 502 minecraft:blackstone
setblock 441 194 465 minecraft:polished_blackstone_bricks
fill 441 194 466 441 196 466 minecraft:blackstone
setblock 442 194 464 minecraft:polished_blackstone_bricks
fill 442 194 465 442 197 465 minecraft:blackstone
setblock 442 194 504 minecraft:polished_blackstone_bricks
fill 443 194 464 443 197 464 minecraft:blackstone
setblock 443 194 503 minecraft:polished_blackstone_bricks
fill 443 194 504 443 197 504 minecraft:blackstone
setblock 444 194 502 minecraft:polished_blackstone_bricks
fill 444 194 503 444 195 503 minecraft:blackstone
setblock 446 194 465 minecraft:polished_blackstone_bricks
setblock 447 194 464 minecraft:polished_blackstone_bricks
setblock 447 194 465 minecraft:blackstone
setblock 447 194 504 minecraft:polished_blackstone_bricks
setblock 448 194 464 minecraft:blackstone
setblock 448 194 504 minecraft:blackstone
fill 455 194 464 456 194 464 minecraft:blackstone
setblock 457 194 464 minecraft:polished_blackstone_bricks
fill 457 194 465 457 196 465 minecraft:blackstone
fill 458 194 464 458 197 464 minecraft:blackstone
fill 458 194 504 458 195 504 minecraft:blackstone
setblock 459 194 466 minecraft:blackstone
setblock 460 194 466 minecraft:polished_blackstone_bricks
setblock 461 194 465 minecraft:polished_blackstone_bricks
fill 461 194 466 461 194 469 minecraft:blackstone
setblock 461 194 470 minecraft:polished_blackstone_bricks
setblock 461 194 485 minecraft:polished_blackstone_bricks
fill 461 194 486 461 195 486 minecraft:blackstone
setblock 461 194 490 minecraft:polished_blackstone_bricks
setblock 462 194 464 minecraft:polished_blackstone_bricks
fill 462 194 465 462 194 468 minecraft:blackstone
setblock 462 194 469 minecraft:polished_blackstone_bricks
fill 462 194 470 462 197 470 minecraft:blackstone
fill 462 194 472 462 194 473 minecraft:blackstone
setblock 462 194 474 minecraft:polished_blackstone_bricks
fill 462 194 475 462 197 475 minecraft:blackstone
setblock 462 194 479 minecraft:polished_blackstone_bricks
fill 462 194 480 462 195 480 minecraft:blackstone
setblock 462 194 484 minecraft:polished_blackstone_bricks
fill 462 194 485 462 196 485 minecraft:blackstone
setblock 462 194 489 minecraft:polished_blackstone_bricks
fill 462 194 490 462 197 490 minecraft:blackstone
setblock 462 194 504 minecraft:polished_blackstone_bricks
fill 463 194 464 463 197 464 minecraft:blackstone
setblock 463 194 468 minecraft:polished_blackstone_bricks
fill 463 194 469 463 197 469 minecraft:blackstone
setblock 463 194 473 minecraft:polished_blackstone_bricks
fill 463 194 474 463 197 474 minecraft:blackstone
setblock 463 194 478 minecraft:polished_blackstone_bricks
fill 463 194 479 463 197 479 minecraft:blackstone
setblock 463 194 483 minecraft:polished_blackstone_bricks
fill 463 194 484 463 197 484 minecraft:blackstone
setblock 463 194 488 minecraft:polished_blackstone_bricks
fill 463 194 489 463 197 489 minecraft:blackstone
setblock 463 194 493 minecraft:polished_blackstone_bricks
fill 463 194 494 463 196 494 minecraft:blackstone
fill 463 194 504 463 195 504 minecraft:blackstone
setblock 464 194 467 minecraft:polished_blackstone_bricks
fill 464 194 468 464 197 468 minecraft:blackstone
setblock 464 194 472 minecraft:polished_blackstone_bricks
fill 464 194 473 464 197 473 minecraft:blackstone
setblock 464 194 477 minecraft:polished_blackstone_bricks
fill 464 194 478 464 197 478 minecraft:blackstone
setblock 464 194 482 minecraft:polished_blackstone_bricks
fill 464 194 483 464 197 483 minecraft:blackstone
setblock 464 194 487 minecraft:polished_blackstone_bricks
fill 464 194 488 464 197 488 minecraft:blackstone
setblock 464 194 492 minecraft:polished_blackstone_bricks
fill 464 194 493 464 197 493 minecraft:blackstone
setblock 464 194 497 minecraft:polished_blackstone_bricks
setblock 464 194 502 minecraft:polished_blackstone_bricks
fill 464 194 503 464 195 503 minecraft:blackstone
fill 424 195 464 425 195 464 minecraft:blackstone
setblock 424 195 466 minecraft:polished_blackstone_bricks
fill 424 195 467 424 198 467 minecraft:blackstone
setblock 424 195 471 minecraft:polished_blackstone_bricks
fill 424 195 472 424 198 472 minecraft:blackstone
setblock 424 195 476 minecraft:polished_blackstone_bricks
fill 424 195 477 424 197 477 minecraft:blackstone
setblock 424 195 481 minecraft:polished_blackstone_bricks
fill 424 195 482 424 196 482 minecraft:blackstone
setblock 424 195 486 minecraft:polished_blackstone_bricks
fill 424 195 487 424 197 487 minecraft:blackstone
setblock 424 195 491 minecraft:polished_blackstone_bricks
fill 424 195 492 424 198 492 minecraft:blackstone
setblock 424 195 495 minecraft:blackstone
setblock 424 195 496 minecraft:polished_blackstone_bricks
setblock 424 195 501 minecraft:polished_blackstone_bricks
setblock 424 195 502 minecraft:blackstone
setblock 425 195 465 minecraft:polished_blackstone_bricks
fill 425 195 466 425 198 466 minecraft:blackstone
setblock 425 195 470 minecraft:polished_blackstone_bricks
fill 425 195 471 425 198 471 minecraft:blackstone
setblock 425 195 486 minecraft:blackstone
setblock 425 195 490 minecraft:polished_blackstone_bricks
setblock 425 195 504 minecraft:blackstone
setblock 426 195 464 minecraft:polished_blackstone_bricks
fill 426 195 465 426 198 465 minecraft:blackstone
setblock 426 195 469 minecraft:polished_blackstone_bricks
fill 426 195 470 426 196 470 minecraft:blackstone
setblock 426 195 504 minecraft:polished_blackstone_bricks
fill 427 195 464 430 195 464 minecraft:blackstone
fill 427 195 504 430 195 504 minecraft:blackstone
setblock 429 195 466 minecraft:polished_blackstone_bricks
setblock 430 195 465 minecraft:polished_blackstone_bricks
setblock 431 195 464 minecraft:polished_blackstone_bricks
fill 431 195 465 431 196 465 minecraft:blackstone
setblock 431 195 504 minecraft:polished_blackstone_bricks
fill 432 195 464 432 198 464 minecraft:blackstone
fill 432 195 504 432 196 504 minecraft:blackstone
setblock 435 195 465 minecraft:polished_blackstone_bricks
setblock 436 195 464 minecraft:polished_blackstone_bricks
fill 436 195 465 436 198 465 minecraft:blackstone
setblock 436 195 504 minecraft:polished_blackstone_bricks
fill 437 195 464 437 198 464 minecraft:blackstone
setblock 437 195 503 minecraft:polished_blackstone_bricks
fill 437 195 504 437 198 504 minecraft:blackstone
fill 438 195 503 438 198 503 minecraft:blackstone
setblock 439 195 466 minecraft:polished_blackstone_bricks
setblock 440 195 465 minecraft:polished_blackstone_bricks
fill 440 195 466 440 196 466 minecraft:blackstone
setblock 441 195 464 minecraft:polished_blackstone_bricks
fill 441 195 465 441 197 465 minecraft:blackstone
setblock 441 195 504 minecraft:polished_blackstone_bricks
fill 442 195 464 442 198 464 minecraft:blackstone
setblock 442 195 503 minecraft:polished_blackstone_bricks
fill 442 195 504 442 198 504 minecraft:blackstone
fill 443 195 503 443 196 503 minecraft:blackstone
setblock 445 195 465 minecraft:polished_blackstone_bricks
setblock 446 195 464 minecraft:polished_blackstone_bricks
setblock 446 195 504 minecraft:polished_blackstone_bricks
setblock 447 195 464 minecraft:blackstone
setblock 447 195 504 minecraft:blackstone
setblock 455 195 464 minecraft:blackstone
setblock 456 195 464 minecraft:polished_blackstone_bricks
fill 457 195 464 457 198 464 minecraft:blackstone
setblock 459 195 466 minecraft:polished_blackstone_bricks
setblock 460 195 465 minecraft:polished_blackstone_bricks
fill 460 195 466 462 196 466 minecraft:blackstone
setblock 461 195 464 minecraft:polished_blackstone_bricks
fill 461 195 465 462 197 465 minecraft:blackstone
fill 461 195 467 461 195 468 minecraft:blackstone
setblock 461 195 469 minecraft:polished_blackstone_bricks
fill 461 195 470 461 197 471 minecraft:blackstone
setblock 461 195 484 minecraft:polished_blackstone_bricks
setblock 461 195 485 minecraft:blackstone
setblock 461 195 489 minecraft:polished_blackstone_bricks
setblock 461 195 490 minecraft:blackstone
setblock 461 195 504 minecraft:polished_blackstone_bricks
fill 462 195 464 462 198 464 minecraft:blackstone
setblock 462 195 467 minecraft:blackstone
setblock 462 195 468 minecraft:polished_blackstone_bricks
fill 462 195 469 462 198 469 minecraft:blackstone
setblock 462 195 472 minecraft:blackstone
setblock 462 195 473 minecraft:polished_blackstone_bricks
fill 462 195 474 462 198 474 minecraft:blackstone
setblock 462 195 483 minecraft:polished_blackstone_bricks
fill 462 195 484 462 196 484 minecraft:blackstone
setblock 462 195 488 minecraft:polished_blackstone_bricks
fill 462 195 489 462 197 489 minecraft:blackstone
fill 462 195 504 462 196 504 minecraft:blackstone
setblock 463 195 467 minecraft:polished_blackstone_bricks
fill 463 195 468 463 198 468 minecraft:blackstone
setblock 463 195 472 minecraft:polished_blackstone_bricks
fill 463 195 473 463 198 473 minecraft:blackstone
setblock 463 195 477 minecraft:polished_blackstone_bricks
fill 463 195 478 463 197 478 minecraft:blackstone
setblock 463 195 482 minecraft:polished_blackstone_bricks
fill 463 195 483 463 197 483 minecraft:blackstone
setblock 463 195 487 minecraft:polished_blackstone_bricks
fill 463 195 488 463 198 488 minecraft:blackstone
setblock 463 195 492 minecraft:polished_blackstone_bricks
fill 463 195 493 463 197 493 minecraft:blackstone
setblock 464 195 466 minecraft:polished_blackstone_bricks
fill 464 195 467 464 198 467 minecraft:blackstone
setblock 464 195 471 minecraft:polished_blackstone_bricks
fill 464 195 472 464 198 472 minecraft:blackstone
setblock 464 195 476 minecraft:polished_blackstone_bricks
fill 464 195 477 464 198 477 minecraft:blackstone
setblock 464 195 481 minecraft:polished_blackstone_bricks
fill 464 195 482 464 198 482 minecraft:blackstone
setblock 464 195 486 minecraft:polished_blackstone_bricks
fill 464 195 487 464 198 487 minecraft:blackstone
setblock 464 195 491 minecraft:polished_blackstone_bricks
fill 464 195 492 464 198 492 minecraft:blackstone
setblock 464 195 496 minecraft:polished_blackstone_bricks
setblock 424 196 464 minecraft:blackstone
setblock 424 196 465 minecraft:polished_blackstone_bricks
fill 424 196 466 424 199 466 minecraft:blackstone
setblock 424 196 470 minecraft:polished_blackstone_bricks
fill 424 196 471 424 199 471 minecraft:blackstone
setblock 424 196 475 minecraft:polished_blackstone_bricks
fill 424 196 476 424 198 476 minecraft:blackstone
setblock 424 196 485 minecraft:polished_blackstone_bricks
fill 424 196 486 424 197 486 minecraft:blackstone
setblock 424 196 490 minecraft:polished_blackstone_bricks
fill 424 196 491 424 199 491 minecraft:blackstone
setblock 424 196 495 minecraft:polished_blackstone_bricks
setblock 425 196 464 minecraft:polished_blackstone_bricks
fill 425 196 465 425 198 465 minecraft:blackstone
setblock 425 196 469 minecraft:polished_blackstone_bricks
fill 425 196 470 425 199 470 minecraft:blackstone
setblock 425 196 474 minecraft:polished_blackstone_bricks
setblock 425 196 504 minecraft:polished_blackstone_bricks
fill 426 196 464 429 196 464 minecraft:blackstone
setblock 426 196 468 minecraft:polished_blackstone_bricks
fill 426 196 469 426 197 469 minecraft:blackstone
fill 426 196 504 427 196 504 minecraft:blackstone
setblock 429 196 465 minecraft:polished_blackstone_bricks
setblock 430 196 464 minecraft:polished_blackstone_bricks
setblock 430 196 465 minecraft:blackstone
fill 431 196 464 431 198 464 minecraft:blackstone
setblock 434 196 465 minecraft:polished_blackstone_bricks
setblock 435 196 464 minecraft:polished_blackstone_bricks
fill 435 196 465 435 197 465 minecraft:blackstone
setblock 435 196 504 minecraft:polished_blackstone_bricks
fill 436 196 464 436 199 464 minecraft:blackstone
setblock 436 196 503 minecraft:polished_blackstone_bricks
fill 436 196 504 436 199 504 minecraft:blackstone
fill 437 196 503 437 198 503 minecraft:blackstone
setblock 438 196 466 minecraft:polished_blackstone_bricks
setblock 439 196 465 minecraft:polished_blackstone_bricks
setblock 439 196 466 minecraft:blackstone
setblock 440 196 464 minecraft:polished_blackstone_bricks
fill 440 196 465 440 198 465 minecraft:blackstone
setblock 440 196 504 minecraft:polished_blackstone_bricks
fill 441 196 464 441 199 464 minecraft:blackstone
setblock 441 196 503 minecraft:polished_blackstone_bricks
fill 441 196 504 441 199 504 minecraft:blackstone
fill 442 196 503 442 197 503 minecraft:blackstone
setblock 444 196 465 minecraft:polished_blackstone_bricks
setblock 445 196 464 minecraft:polished_blackstone_bricks
setblock 445 196 504 minecraft:polished_blackstone_bricks
setblock 446 196 464 minecraft:blackstone
setblock 446 196 504 minecraft:blackstone
fill 456 196 464 456 197 464 minecraft:blackstone
setblock 459 196 465 minecraft:polished_blackstone_bricks
fill 459 196 466 459 197 466 minecraft:blackstone
setblock 460 196 464 minecraft:polished_blackstone_bricks
fill 460 196 465 460 199 465 minecraft:blackstone
setblock 460 196 504 minecraft:polished_blackstone_bricks
fill 461 196 464 461 199 464 minecraft:blackstone
setblock 461 196 468 minecraft:polished_blackstone_bricks
fill 461 196 469 461 197 469 minecraft:blackstone
setblock 461 196 488 minecraft:polished_blackstone_bricks
setblock 461 196 504 minecraft:blackstone
setblock 462 196 467 minecraft:polished_blackstone_bricks
fill 462 196 468 462 199 468 minecraft:blackstone
setblock 462 196 472 minecraft:polished_blackstone_bricks
fill 462 196 473 462 199 473 minecraft:blackstone
setblock 462 196 483 minecraft:blackstone
setblock 462 196 487 minecraft:polished_blackstone_bricks
fill 462 196 488 462 197 488 minecraft:blackstone
setblock 462 196 492 minecraft:polished_blackstone_bricks
setblock 463 196 466 minecraft:polished_blackstone_bricks
fill 463 196 467 463 199 467 minecraft:blackstone
setblock 463 196 471 minecraft:polished_blackstone_bricks
fill 463 196 472 463 199 472 minecraft:blackstone
setblock 463 196 476 minecraft:polished_blackstone_bricks
fill 463 196 477 463 199 477 minecraft:blackstone
setblock 463 196 481 minecraft:polished_blackstone_bricks
fill 463 196 482 463 197 482 minecraft:blackstone
setblock 463 196 486 minecraft:polished_blackstone_bricks
fill 463 196 487 463 198 487 minecraft:blackstone
setblock 463 196 491 minecraft:polished_blackstone_bricks
fill 463 196 492 463 198 492 minecraft:blackstone
setblock 464 196 465 minecraft:polished_blackstone_bricks
fill 464 196 466 464 199 466 minecraft:blackstone
setblock 464 196 470 minecraft:polished_blackstone_bricks
fill 464 196 471 464 199 471 minecraft:blackstone
setblock 464 196 475 minecraft:polished_blackstone_bricks
fill 464 196 476 464 199 476 minecraft:blackstone
setblock 464 196 480 minecraft:polished_blackstone_bricks
fill 464 196 481 464 198 481 minecraft:blackstone
setblock 464 196 485 minecraft:polished_blackstone_bricks
fill 464 196 486 464 198 486 minecraft:blackstone
setblock 464 196 490 minecraft:polished_blackstone_bricks
fill 464 196 491 464 199 491 minecraft:blackstone
setblock 464 196 495 minecraft:polished_blackstone_bricks
setblock 424 197 464 minecraft:polished_blackstone_bricks
fill 424 197 465 424 200 465 minecraft:blackstone
setblock 424 197 469 minecraft:polished_blackstone_bricks
fill 424 197 470 424 200 470 minecraft:blackstone
setblock 424 197 474 minecraft:polished_blackstone_bricks
fill 424 197 475 424 200 475 minecraft:blackstone
setblock 424 197 489 minecraft:polished_blackstone_bricks
fill 424 197 490 424 198 490 minecraft:blackstone
setblock 424 197 494 minecraft:polished_blackstone_bricks
setblock 424 197 495 minecraft:blackstone
setblock 424 197 504 minecraft:polished_blackstone_bricks
fill 425 197 464 428 197 464 minecraft:blackstone
setblock 425 197 468 minecraft:polished_blackstone_bricks
fill 425 197 469 425 200 469 minecraft:blackstone
setblock 425 197 473 minecraft:polished_blackstone_bricks
setblock 425 197 504 minecraft:blackstone
setblock 426 197 467 minecraft:polished_blackstone_bricks
setblock 426 197 468 minecraft:blackstone
setblock 428 197 465 minecraft:polished_blackstone_bricks
setblock 429 197 464 minecraft:polished_blackstone_bricks
fill 430 197 464 430 198 464 minecraft:blackstone
setblock 434 197 464 minecraft:polished_blackstone_bricks
setblock 434 197 465 minecraft:blackstone
setblock 434 197 504 minecraft:polished_blackstone_bricks
fill 435 197 464 435 200 464 minecraft:blackstone
fill 435 197 504 435 200 504 minecraft:blackstone
setblock 438 197 465 minecraft:polished_blackstone_bricks
setblock 439 197 464 minecraft:polished_blackstone_bricks
fill 439 197 465 439 198 465 minecraft:blackstone
setblock 439 197 504 minecraft:polished_blackstone_bricks
fill 440 197 464 440 200 464 minecraft:blackstone
setblock 440 197 503 minecraft:polished_blackstone_bricks
fill 440 197 504 440 200 504 minecraft:blackstone
fill 441 197 496 442 198 497 minecraft:cyan_stained_glass
setblock 441 197 503 minecraft:blackstone
fill 442 197 498 442 198 498 minecraft:cyan_stained_glass
setblock 444 197 464 minecraft:polished_blackstone_bricks
setblock 444 197 504 minecraft:polished_blackstone_bricks
setblock 458 197 465 minecraft:polished_blackstone_bricks
setblock 459 197 464 minecraft:polished_blackstone_bricks
fill 459 197 465 459 200 465 minecraft:blackstone
fill 460 197 464 460 200 464 minecraft:blackstone
fill 460 197 466 461 197 466 minecraft:blackstone
setblock 462 197 466 minecraft:polished_blackstone_bricks
fill 462 197 467 462 199 467 minecraft:blackstone
setblock 462 197 471 minecraft:polished_blackstone_bricks
fill 462 197 472 462 200 472 minecraft:blackstone
setblock 462 197 486 minecraft:polished_blackstone_bricks
setblock 462 197 487 minecraft:blackstone
setblock 462 197 491 minecraft:polished_blackstone_bricks
setblock 463 197 465 minecraft:polished_blackstone_bricks
fill 463 197 466 463 200 466 minecraft:blackstone
setblock 463 197 470 minecraft:polished_blackstone_bricks
fill 463 197 471 463 200 471 minecraft:blackstone
setblock 463 197 475 minecraft:polished_blackstone_bricks
fill 463 197 476 463 200 476 minecraft:blackstone
setblock 463 197 485 minecraft:polished_blackstone_bricks
fill 463 197 486 463 198 486 minecraft:blackstone
setblock 463 197 490 minecraft:polished_blackstone_bricks
fill 463 197 491 463 198 491 minecraft:blackstone
setblock 464 197 464 minecraft:polished_blackstone_bricks
fill 464 197 465 464 200 465 minecraft:blackstone
setblock 464 197 469 minecraft:polished_blackstone_bricks
fill 464 197 470 464 200 470 minecraft:blackstone
setblock 464 197 474 minecraft:polished_blackstone_bricks
fill 464 197 475 464 200 475 minecraft:blackstone
setblock 464 197 479 minecraft:polished_blackstone_bricks
fill 464 197 480 464 198 480 minecraft:blackstone
setblock 464 197 484 minecraft:polished_blackstone_bricks
fill 464 197 485 464 198 485 minecraft:blackstone
setblock 464 197 489 minecraft:polished_blackstone_bricks
fill 464 197 490 464 200 490 minecraft:blackstone
setblock 464 197 494 minecraft:polished_blackstone_bricks
setblock 464 197 495 minecraft:blackstone
fill 424 198 464 427 198 464 minecraft:blackstone
setblock 424 198 468 minecraft:polished_blackstone_bricks
fill 424 198 469 424 201 469 minecraft:blackstone
setblock 424 198 473 minecraft:polished_blackstone_bricks
fill 424 198 474 424 201 474 minecraft:blackstone
setblock 424 198 489 minecraft:blackstone
setblock 424 198 493 minecraft:polished_blackstone_bricks
fill 424 198 494 424 199 494 minecraft:blackstone
setblock 425 198 467 minecraft:polished_blackstone_bricks
fill 425 198 468 425 200 468 minecraft:blackstone
setblock 425 198 472 minecraft:polished_blackstone_bricks
setblock 426 198 466 minecraft:light[level=11]
setblock 426 198 474 minecraft:light[level=11]
setblock 426 198 482 minecraft:light[level=11]
setblock 426 198 490 minecraft:light[level=11]
setblock 426 198 498 minecraft:light[level=11]
setblock 428 198 464 minecraft:polished_blackstone_bricks
setblock 429 198 464 minecraft:blackstone
setblock 433 198 464 minecraft:polished_blackstone_bricks
fill 434 198 464 434 201 464 minecraft:blackstone
setblock 434 198 466 minecraft:light[level=11]
setblock 434 198 474 minecraft:light[level=11]
setblock 434 198 482 minecraft:light[level=11]
setblock 434 198 490 minecraft:light[level=11]
setblock 434 198 498 minecraft:light[level=11]
fill 434 198 504 434 201 504 minecraft:blackstone
setblock 437 198 465 minecraft:polished_blackstone_bricks
setblock 438 198 464 minecraft:polished_blackstone_bricks
setblock 438 198 465 minecraft:blackstone
setblock 438 198 504 minecraft:polished_blackstone_bricks
fill 439 198 464 439 201 464 minecraft:blackstone
setblock 439 198 503 minecraft:polished_blackstone_bricks
fill 439 198 504 439 201 504 minecraft:blackstone
setblock 440 198 503 minecraft:blackstone
setblock 442 198 466 minecraft:light[level=11]
setblock 442 198 474 minecraft:light[level=11]
setblock 442 198 482 minecraft:light[level=11]
setblock 442 198 490 minecraft:light[level=11]
setblock 443 198 464 minecraft:polished_blackstone_bricks
setblock 443 198 504 minecraft:polished_blackstone_bricks
setblock 450 198 466 minecraft:light[level=11]
setblock 450 198 474 minecraft:light[level=11]
setblock 450 198 482 minecraft:light[level=11]
setblock 450 198 498 minecraft:light[level=11]
setblock 458 198 464 minecraft:polished_blackstone_bricks
setblock 458 198 465 minecraft:blackstone
setblock 458 198 466 minecraft:light[level=11]
setblock 458 198 474 minecraft:light[level=11]
setblock 458 198 482 minecraft:light[level=11]
setblock 458 198 490 minecraft:light[level=11]
setblock 458 198 498 minecraft:light[level=11]
fill 459 198 464 459 201 464 minecraft:blackstone
setblock 461 198 465 minecraft:blackstone
setblock 461 198 466 minecraft:polished_blackstone_bricks
setblock 461 198 470 minecraft:blackstone
setblock 461 198 471 minecraft:polished_blackstone_bricks
setblock 462 198 465 minecraft:polished_blackstone_bricks
setblock 462 198 466 minecraft:blackstone
setblock 462 198 470 minecraft:polished_blackstone_bricks
fill 462 198 471 462 201 471 minecraft:blackstone
setblock 462 198 475 minecraft:polished_blackstone_bricks
setblock 463 198 464 minecraft:polished_blackstone_bricks
fill 463 198 465 463 199 465 minecraft:blackstone
setblock 463 198 469 minecraft:polished_blackstone_bricks
fill 463 198 470 463 201 470 minecraft:blackstone
setblock 463 198 474 minecraft:polished_blackstone_bricks
fill 463 198 475 463 201 475 minecraft:blackstone
setblock 463 198 489 minecraft:polished_blackstone_bricks
setblock 463 198 490 minecraft:blackstone
fill 464 198 464 464 200 464 minecraft:blackstone
setblock 464 198 468 minecraft:polished_blackstone_bricks
fill 464 198 469 464 201 469 minecraft:blackstone
setblock 464 198 473 minecraft:polished_blackstone_bricks
fill 464 198 474 464 201 474 minecraft:blackstone
setblock 464 198 478 minecraft:polished_blackstone_bricks
fill 464 198 479 464 199 479 minecraft:blackstone
setblock 464 198 483 minecraft:polished_blackstone_bricks
setblock 464 198 484 minecraft:blackstone
setblock 464 198 488 minecraft:polished_blackstone_bricks
fill 464 198 489 464 199 489 minecraft:blackstone
setblock 464 198 493 minecraft:polished_blackstone_bricks
fill 464 198 494 464 199 494 minecraft:blackstone
fill 424 199 464 426 199 464 minecraft:blackstone
setblock 424 199 467 minecraft:polished_blackstone_bricks
fill 424 199 468 424 202 468 minecraft:blackstone
setblock 424 199 472 minecraft:polished_blackstone_bricks
fill 424 199 473 424 202 473 minecraft:blackstone
setblock 424 199 492 minecraft:polished_blackstone_bricks
setblock 424 199 493 minecraft:blackstone
setblock 425 199 466 minecraft:polished_blackstone_bricks
setblock 425 199 467 minecraft:blackstone
setblock 425 199 471 minecraft:polished_blackstone_bricks
setblock 425 199 472 minecraft:blackstone
setblock 427 199 464 minecraft:polished_blackstone_bricks
setblock 433 199 464 minecraft:blackstone
setblock 437 199 464 minecraft:polished_blackstone_bricks
setblock 437 199 504 minecraft:polished_blackstone_bricks
fill 438 199 464 438 202 464 minecraft:blackstone
setblock 438 199 503 minecraft:polished_blackstone_bricks
fill 438 199 504 438 202 504 minecraft:blackstone
setblock 442 199 504 minecraft:polished_blackstone_bricks
setblock 457 199 464 minecraft:polished_blackstone_bricks
fill 458 199 464 458 202 464 minecraft:blackstone
setblock 461 199 465 minecraft:polished_blackstone_bricks
setblock 462 199 464 minecraft:polished_blackstone_bricks
setblock 462 199 465 minecraft:blackstone
setblock 462 199 469 minecraft:polished_blackstone_bricks
fill 462 199 470 462 202 470 minecraft:blackstone
setblock 462 199 474 minecraft:polished_blackstone_bricks
fill 462 199 475 462 202 475 minecraft:blackstone
fill 463 199 464 463 201 464 minecraft:blackstone
setblock 463 199 468 minecraft:polished_blackstone_bricks
fill 463 199 469 463 202 469 minecraft:blackstone
setblock 463 199 473 minecraft:polished_blackstone_bricks
fill 463 199 474 463 202 474 minecraft:blackstone
setblock 464 199 467 minecraft:polished_blackstone_bricks
fill 464 199 468 464 202 468 minecraft:blackstone
setblock 464 199 472 minecraft:polished_blackstone_bricks
fill 464 199 473 464 202 473 minecraft:blackstone
setblock 464 199 477 minecraft:polished_blackstone_bricks
fill 464 199 478 464 202 478 minecraft:blackstone
setblock 464 199 487 minecraft:polished_blackstone_bricks
setblock 464 199 488 minecraft:blackstone
setblock 464 199 492 minecraft:polished_blackstone_bricks
fill 464 199 493 464 200 493 minecraft:blackstone
fill 424 200 464 425 200 464 minecraft:blackstone
setblock 424 200 466 minecraft:polished_blackstone_bricks
fill 424 200 467 424 203 467 minecraft:blackstone
setblock 424 200 471 minecraft:polished_blackstone_bricks
fill 424 200 472 424 203 472 minecraft:blackstone
setblock 425 200 470 minecraft:polished_blackstone_bricks
setblock 425 200 471 minecraft:blackstone
setblock 436 200 464 minecraft:polished_blackstone_bricks
setblock 436 200 504 minecraft:polished_blackstone_bricks
fill 437 200 464 437 203 464 minecraft:blackstone
fill 437 200 504 437 203 504 minecraft:blackstone
setblock 441 200 504 minecraft:polished_blackstone_bricks
fill 457 200 464 457 203 464 minecraft:blackstone
setblock 460 200 465 minecraft:polished_blackstone_bricks
setblock 461 200 464 minecraft:polished_blackstone_bricks
setblock 461 200 465 minecraft:blackstone
fill 462 200 464 462 203 464 minecraft:blackstone
setblock 462 200 468 minecraft:polished_blackstone_bricks
fill 462 200 469 462 202 469 minecraft:blackstone
setblock 462 200 473 minecraft:polished_blackstone_bricks
fill 462 200 474 462 203 474 minecraft:blackstone
setblock 463 200 467 minecraft:polished_blackstone_bricks
fill 463 200 468 463 203 468 minecraft:blackstone
setblock 463 200 472 minecraft:polished_blackstone_bricks
fill 463 200 473 463 203 473 minecraft:blackstone
setblock 463 200 477 minecraft:polished_blackstone_bricks
setblock 464 200 466 minecraft:polished_blackstone_bricks
fill 464 200 467 464 203 467 minecraft:blackstone
setblock 464 200 471 minecraft:polished_blackstone_bricks
fill 464 200 472 464 203 472 minecraft:blackstone
setblock 464 200 476 minecraft:polished_blackstone_bricks
fill 464 200 477 464 203 477 minecraft:blackstone
setblock 464 200 491 minecraft:polished_blackstone_bricks
setblock 464 200 492 minecraft:blackstone
setblock 424 201 464 minecraft:blackstone
setblock 424 201 465 minecraft:polished_blackstone_bricks
fill 424 201 466 424 204 466 minecraft:blackstone
setblock 424 201 470 minecraft:polished_blackstone_bricks
fill 424 201 471 424 204 471 minecraft:blackstone
setblock 424 201 475 minecraft:polished_blackstone_bricks
setblock 424 201 494 minecraft:blackstone
setblock 424 201 495 minecraft:polished_blackstone_bricks
fill 433 201 504 433 202 504 minecraft:blackstone
setblock 435 201 464 minecraft:polished_blackstone_bricks
setblock 435 201 504 minecraft:polished_blackstone_bricks
fill 436 201 464 436 204 464 minecraft:blackstone
fill 436 201 504 436 204 504 minecraft:blackstone
fill 437 201 503 438 203 503 minecraft:blackstone
setblock 440 201 504 minecraft:polished_blackstone_bricks
setblock 441 201 504 minecraft:blackstone
setblock 460 201 464 minecraft:polished_blackstone_bricks
fill 461 201 464 461 204 464 minecraft:blackstone
setblock 462 201 472 minecraft:polished_blackstone_bricks
fill 462 201 473 462 204 473 minecraft:blackstone
fill 463 201 467 463 202 467 minecraft:blackstone
setblock 463 201 471 minecraft:polished_blackstone_bricks
fill 463 201 472 463 204 472 minecraft:blackstone
setblock 463 201 476 minecraft:polished_blackstone_bricks
fill 463 201 477 463 204 477 minecraft:blackstone
setblock 464 201 465 minecraft:polished_blackstone_bricks
fill 464 201 466 464 204 466 minecraft:blackstone
setblock 464 201 470 minecraft:polished_blackstone_bricks
fill 464 201 471 464 204 471 minecraft:blackstone
setblock 464 201 475 minecraft:polished_blackstone_bricks
fill 464 201 476 464 204 476 minecraft:blackstone
fill 424 202 465 424 203 465 minecraft:blackstone
setblock 424 202 469 minecraft:polished_blackstone_bricks
fill 424 202 470 424 205 470 minecraft:blackstone
setblock 424 202 474 minecraft:polished_blackstone_bricks
fill 424 202 475 424 205 475 minecraft:blackstone
setblock 424 202 494 minecraft:polished_blackstone_bricks
fill 424 202 495 424 203 497 minecraft:blackstone
fill 432 202 504 432 203 504 minecraft:blackstone
setblock 434 202 464 minecraft:polished_blackstone_bricks
setblock 434 202 504 minecraft:polished_blackstone_bricks
fill 435 202 464 435 205 464 minecraft:blackstone
setblock 435 202 503 minecraft:polished_blackstone_bricks
fill 435 202 504 435 205 504 minecraft:blackstone
fill 436 202 503 436 205 503 minecraft:blackstone
setblock 439 202 504 minecraft:polished_blackstone_bricks
fill 440 202 504 440 205 504 minecraft:blackstone
fill 456 202 464 456 204 464 minecraft:blackstone
setblock 459 202 464 minecraft:polished_blackstone_bricks
fill 460 202 464 460 205 464 minecraft:blackstone
setblock 462 202 471 minecraft:polished_blackstone_bricks
fill 462 202 472 462 205 472 minecraft:blackstone
setblock 462 202 476 minecraft:polished_blackstone_bricks
setblock 463 202 470 minecraft:polished_blackstone_bricks
fill 463 202 471 463 205 471 minecraft:blackstone
setblock 463 202 475 minecraft:polished_blackstone_bricks
fill 463 202 476 463 205 476 minecraft:blackstone
setblock 464 202 465 minecraft:blackstone
setblock 464 202 469 minecraft:polished_blackstone_bricks
fill 464 202 470 464 205 470 minecraft:blackstone
setblock 464 202 474 minecraft:polished_blackstone_bricks
fill 464 202 475 464 205 475 minecraft:blackstone
setblock 423 203 471 minecraft:soul_soil
fill 423 203 478 423 206 479 minecraft:blackstone
setblock 423 203 480 minecraft:soul_soil
fill 423 203 481 423 204 481 minecraft:blackstone
fill 423 203 498 423 204 503 minecraft:blackstone
fill 423 203 504 423 204 504 minecraft:soul_soil
fill 423 203 505 423 206 505 minecraft:blackstone
setblock 424 203 468 minecraft:polished_blackstone_bricks
fill 424 203 469 424 206 469 minecraft:blackstone
setblock 424 203 473 minecraft:polished_blackstone_bricks
fill 424 203 474 424 206 474 minecraft:blackstone
fill 424 203 476 424 204 476 minecraft:blackstone
setblock 424 203 493 minecraft:polished_blackstone_bricks
fill 424 203 494 424 206 494 minecraft:blackstone
setblock 424 203 498 minecraft:polished_blackstone_bricks
fill 424 203 499 424 206 499 minecraft:blackstone
fill 425 203 505 427 204 505 minecraft:blackstone
setblock 428 203 505 minecraft:soul_soil
fill 429 203 505 429 206 505 minecraft:blackstone
fill 430 203 504 431 204 504 minecraft:blackstone
setblock 430 203 505 minecraft:soul_soil
fill 431 203 505 431 206 505 minecraft:blackstone
fill 432 203 463 433 203 463 minecraft:blackstone
setblock 433 203 464 minecraft:polished_blackstone_bricks
setblock 433 203 503 minecraft:blackstone
setblock 433 203 504 minecraft:polished_blackstone_bricks
setblock 434 203 463 minecraft:soul_soil
fill 434 203 464 434 206 464 minecraft:blackstone
setblock 434 203 503 minecraft:polished_blackstone_bricks
fill 434 203 504 434 206 504 minecraft:blackstone
fill 435 203 503 435 206 503 minecraft:blackstone
fill 438 203 463 438 206 463 minecraft:blackstone
setblock 438 203 464 minecraft:polished_blackstone_bricks
setblock 438 203 504 minecraft:polished_blackstone_bricks
setblock 439 203 463 minecraft:soul_soil
setblock 439 203 503 minecraft:polished_blackstone_bricks
fill 439 203 504 439 206 504 minecraft:blackstone
fill 440 203 463 449 203 463 minecraft:blackstone
fill 456 203 463 457 203 463 minecraft:soul_soil
setblock 458 203 464 minecraft:polished_blackstone_bricks
setblock 458 203 505 minecraft:soul_soil
fill 459 203 464 459 206 464 minecraft:blackstone
fill 459 203 505 459 204 505 minecraft:blackstone
fill 461 203 472 461 203 473 minecraft:blackstone
setblock 462 203 470 minecraft:polished_blackstone_bricks
fill 462 203 471 462 206 471 minecraft:blackstone
setblock 462 203 475 minecraft:polished_blackstone_bricks
fill 462 203 476 462 206 476 minecraft:blackstone
setblock 463 203 463 minecraft:soul_soil
setblock 463 203 469 minecraft:polished_blackstone_bricks
fill 463 203 470 463 206 470 minecraft:blackstone
setblock 463 203 474 minecraft:polished_blackstone_bricks
fill 463 203 475 463 206 475 minecraft:blackstone
setblock 464 203 468 minecraft:polished_blackstone_bricks
fill 464 203 469 464 206 469 minecraft:blackstone
setblock 464 203 473 minecraft:polished_blackstone_bricks
fill 464 203 474 464 206 474 minecraft:blackstone
setblock 464 203 478 minecraft:polished_blackstone_bricks
fill 464 203 479 464 206 479 minecraft:blackstone
fill 465 203 476 465 206 478 minecraft:blackstone
fill 465 203 479 465 204 479 minecraft:soul_soil
fill 465 203 497 465 203 498 minecraft:blackstone
fill 465 203 499 465 204 499 minecraft:soul_soil
fill 423 204 463 423 204 464 minecraft:soul_soil
fill 423 204 465 423 206 469 minecraft:blackstone
fill 423 204 471 423 206 471 minecraft:blackstone
fill 423 204 480 423 206 480 minecraft:blackstone
setblock 423 204 484 minecraft:soul_soil
fill 423 204 485 423 206 487 minecraft:blackstone
setblock 423 204 488 minecraft:soul_soil
fill 423 204 489 423 206 490 minecraft:blackstone
fill 423 204 492 423 206 492 minecraft:blackstone
setblock 423 204 493 minecraft:soul_soil
setblock 423 204 497 minecraft:soul_soil
setblock 424 204 467 minecraft:polished_blackstone_bricks
fill 424 204 468 424 206 468 minecraft:blackstone
setblock 424 204 472 minecraft:polished_blackstone_bricks
fill 424 204 473 424 207 473 minecraft:blackstone
fill 424 204 493 424 207 493 minecraft:blackstone
fill 424 204 495 424 204 496 minecraft:blackstone
setblock 424 204 497 minecraft:polished_blackstone_bricks
fill 424 204 498 424 207 498 minecraft:blackstone
fill 424 204 500 424 204 501 minecraft:blackstone
setblock 424 204 502 minecraft:polished_blackstone_bricks
fill 428 204 505 428 206 505 minecraft:blackstone
fill 429 204 504 429 206 504 minecraft:blackstone
fill 430 204 473 432 205 473 minecraft:cyan_stained_glass
fill 430 204 505 430 206 505 minecraft:blackstone
fill 431 204 472 431 205 472 minecraft:cyan_stained_glass
fill 431 204 474 431 205 474 minecraft:cyan_stained_glass
fill 431 204 503 432 204 503 minecraft:blackstone
fill 432 204 463 432 206 463 minecraft:blackstone
setblock 432 204 464 minecraft:polished_blackstone_bricks
setblock 432 204 504 minecraft:polished_blackstone_bricks
fill 433 204 463 433 205 463 minecraft:soul_soil
fill 433 204 464 433 207 464 minecraft:blackstone
setblock 433 204 502 minecraft:blackstone
setblock 433 204 503 minecraft:polished_blackstone_bricks
fill 433 204 504 433 207 504 minecraft:blackstone
fill 434 204 463 434 206 463 minecraft:blackstone
setblock 434 204 502 minecraft:polished_blackstone_bricks
fill 434 204 503 434 207 503 minecraft:blackstone
fill 435 204 502 438 204 502 minecraft:blackstone
setblock 437 204 464 minecraft:polished_blackstone_bricks
setblock 437 204 503 minecraft:blackstone
setblock 437 204 504 minecraft:polished_blackstone_bricks
setblock 438 204 503 minecraft:polished_blackstone_bricks
fill 438 204 504 438 207 504 minecraft:blackstone
fill 439 204 463 442 206 463 minecraft:blackstone
fill 439 204 503 439 207 503 minecraft:blackstone
setblock 441 204 504 minecraft:blackstone
setblock 443 204 463 minecraft:soul_soil
fill 444 204 463 449 206 463 minecraft:blackstone
fill 455 204 464 455 205 464 minecraft:blackstone
fill 456 204 463 457 206 463 minecraft:blackstone
setblock 457 204 464 minecraft:polished_blackstone_bricks
fill 458 204 464 458 206 465 minecraft:blackstone
setblock 458 204 505 minecraft:blackstone
fill 461 204 473 461 204 474 minecraft:blackstone
setblock 462 204 464 minecraft:polished_blackstone_bricks
fill 462 204 470 462 205 470 minecraft:blackstone
setblock 462 204 474 minecraft:polished_blackstone_bricks
fill 462 204 475 462 207 475 minecraft:blackstone
fill 462 204 477 462 205 477 minecraft:blackstone
fill 463 204 463 463 206 463 minecraft:blackstone
setblock 463 204 468 minecraft:polished_blackstone_bricks
fill 463 204 469 463 206 469 minecraft:blackstone
setblock 463 204 473 minecraft:polished_blackstone_bricks
fill 463 204 474 463 207 474 minecraft:blackstone
setblock 463 204 478 minecraft:polished_blackstone_bricks
setblock 464 204 467 minecraft:polished_blackstone_bricks
fill 464 204 468 464 207 468 minecraft:blackstone
setblock 464 204 472 minecraft:polished_blackstone_bricks
fill 464 204 473 464 207 473 minecraft:blackstone
setblock 464 204 477 minecraft:polished_blackstone_bricks
fill 464 204 478 464 207 478 minecraft:blackstone
fill 465 204 463 465 206 463 minecraft:blackstone
setblock 465 204 464 minecraft:soul_soil
fill 465 204 465 465 206 465 minecraft:blackstone
setblock 465 204 470 minecraft:soul_soil
setblock 465 204 489 minecraft:soul_soil
fill 465 204 497 465 206 497 minecraft:blackstone
setblock 465 204 498 minecraft:soul_soil
setblock 465 204 500 minecraft:soul_soil
fill 465 204 501 465 206 501 minecraft:blackstone
fill 423 205 463 424 206 463 minecraft:blackstone
setblock 423 205 464 minecraft:soul_soil
setblock 423 205 473 minecraft:soul_soil
fill 423 205 474 423 206 474 minecraft:blackstone
setblock 423 205 481 minecraft:soul_soil
fill 423 205 484 423 206 484 minecraft:blackstone
fill 423 205 488 423 206 488 minecraft:blackstone
fill 423 205 493 423 206 493 minecraft:blackstone
fill 423 205 497 423 206 500 minecraft:blackstone
setblock 423 205 501 minecraft:soul_soil
fill 423 205 502 424 206 504 minecraft:blackstone
setblock 424 205 467 minecraft:blackstone
setblock 424 205 471 minecraft:polished_blackstone_bricks
fill 424 205 472 424 208 472 minecraft:blackstone
setblock 424 205 476 minecraft:polished_blackstone_bricks
fill 424 205 477 424 208 477 minecraft:blackstone
setblock 424 205 495 minecraft:blackstone
setblock 424 205 496 minecraft:polished_blackstone_bricks
fill 424 205 497 425 207 497 minecraft:blackstone
setblock 424 205 500 minecraft:blackstone
setblock 424 205 501 minecraft:polished_blackstone_bricks
setblock 425 205 463 minecraft:soul_soil
fill 425 205 498 425 205 499 minecraft:blackstone
setblock 425 205 504 minecraft:blackstone
setblock 425 205 505 minecraft:soul_soil
setblock 426 205 504 minecraft:polished_blackstone_bricks
fill 426 205 505 427 206 505 minecraft:blackstone
fill 427 205 504 428 207 504 minecraft:blackstone
fill 429 205 503 431 205 503 minecraft:blackstone
setblock 430 205 464 minecraft:blackstone
setblock 430 205 504 minecraft:blackstone
setblock 431 205 464 minecraft:polished_blackstone_bricks
setblock 431 205 504 minecraft:polished_blackstone_bricks
fill 432 205 464 432 208 464 minecraft:blackstone
setblock 432 205 502 minecraft:blackstone
setblock 432 205 503 minecraft:polished_blackstone_bricks
fill 432 205 504 432 208 504 minecraft:blackstone
setblock 433 205 502 minecraft:polished_blackstone_bricks
fill 433 205 503 433 208 503 minecraft:blackstone
setblock 434 205 501 minecraft:polished_blackstone_bricks
fill 434 205 502 437 205 502 minecraft:blackstone
fill 435 205 501 436 207 501 minecraft:blackstone
fill 436 205 463 436 206 463 minecraft:blackstone
setblock 436 205 464 minecraft:polished_blackstone_bricks
setblock 436 205 504 minecraft:polished_blackstone_bricks
setblock 437 205 463 minecraft:soul_soil
fill 437 205 464 437 207 464 minecraft:blackstone
setblock 437 205 503 minecraft:polished_blackstone_bricks
fill 437 205 504 437 208 504 minecraft:blackstone
setblock 438 205 502 minecraft:polished_blackstone_bricks
fill 438 205 503 438 208 503 minecraft:blackstone
setblock 441 205 504 minecraft:polished_blackstone_bricks
fill 443 205 463 443 206 463 minecraft:blackstone
fill 444 205 505 445 205 505 minecraft:soul_soil
fill 454 205 464 454 206 464 minecraft:blackstone
fill 454 205 504 455 205 504 minecraft:blackstone
setblock 455 205 505 minecraft:soul_soil
setblock 456 205 464 minecraft:polished_blackstone_bricks
fill 456 205 465 457 207 465 minecraft:blackstone
setblock 456 205 504 minecraft:polished_blackstone_bricks
fill 457 205 464 457 208 464 minecraft:blackstone
fill 457 205 504 459 206 504 minecraft:blackstone
fill 458 205 505 459 205 505 minecraft:soul_soil
setblock 459 205 465 minecraft:blackstone
setblock 461 205 464 minecraft:polished_blackstone_bricks
setblock 461 205 473 minecraft:blackstone
setblock 461 205 474 minecraft:polished_blackstone_bricks
setblock 461 205 475 minecraft:blackstone
fill 462 205 464 463 207 464 minecraft:blackstone
setblock 462 205 473 minecraft:polished_blackstone_bricks
fill 462 205 474 462 207 474 minecraft:blackstone
setblock 463 205 468 minecraft:blackstone
setblock 463 205 472 minecraft:polished_blackstone_bricks
fill 463 205 473 463 208 473 minecraft:blackstone
setblock 463 205 477 minecraft:polished_blackstone_bricks
fill 463 205 478 463 208 478 minecraft:blackstone
setblock 464 205 465 minecraft:blackstone
setblock 464 205 466 minecraft:polished_blackstone_bricks
fill 464 205 467 464 208 467 minecraft:blackstone
setblock 464 205 471 minecraft:polished_blackstone_bricks
fill 464 205 472 464 208 472 minecraft:blackstone
setblock 464 205 476 minecraft:polished_blackstone_bricks
fill 464 205 477 464 208 477 minecraft:blackstone
setblock 464 205 480 minecraft:blackstone
setblock 464 205 495 minecraft:blackstone
setblock 464 205 496 minecraft:polished_blackstone_bricks
fill 464 205 497 464 207 498 minecraft:blackstone
fill 465 205 464 465 206 464 minecraft:blackstone
fill 465 205 470 465 206 470 minecraft:blackstone
setblock 465 205 472 minecraft:soul_soil
setblock 465 205 474 minecraft:soul_soil
fill 465 205 479 465 207 479 minecraft:blackstone
setblock 465 205 488 minecraft:soul_soil
fill 465 205 489 465 206 489 minecraft:blackstone
setblock 465 205 492 minecraft:soul_soil
fill 465 205 498 465 206 500 minecraft:blackstone
setblock 423 206 464 minecraft:blackstone
setblock 423 206 473 minecraft:blackstone
setblock 423 206 481 minecraft:blackstone
fill 423 206 501 425 206 501 minecraft:blackstone
setblock 424 206 470 minecraft:polished_blackstone_bricks
fill 424 206 471 424 207 471 minecraft:blackstone
setblock 424 206 475 minecraft:polished_blackstone_bricks
fill 424 206 476 424 209 476 minecraft:blackstone
setblock 424 206 495 minecraft:polished_blackstone_bricks
fill 424 206 496 425 208 496 minecraft:blackstone
setblock 424 206 500 minecraft:polished_blackstone_bricks
setblock 425 206 463 minecraft:blackstone
setblock 425 206 498 minecraft:blackstone
setblock 425 206 499 minecraft:polished_blackstone_bricks
fill 425 206 500 425 209 500 minecraft:blackstone
setblock 425 206 504 minecraft:polished_blackstone_bricks
fill 425 206 505 425 207 505 minecraft:blackstone
setblock 426 206 466 minecraft:light[level=11]
setblock 426 206 474 minecraft:light[level=11]
setblock 426 206 482 minecraft:light[level=11]
setblock 426 206 490 minecraft:light[level=11]
setblock 426 206 498 minecraft:light[level=11]
fill 426 206 504 426 209 504 minecraft:blackstone
fill 428 206 503 430 206 503 minecraft:blackstone
setblock 429 206 464 minecraft:blackstone
setblock 430 206 464 minecraft:polished_blackstone_bricks
fill 430 206 502 431 206 502 minecraft:blackstone
setblock 430 206 504 minecraft:polished_blackstone_bricks
fill 431 206 464 431 209 464 minecraft:blackstone
setblock 431 206 503 minecraft:polished_blackstone_bricks
fill 431 206 504 431 209 504 minecraft:blackstone
setblock 432 206 501 minecraft:blackstone
setblock 432 206 502 minecraft:polished_blackstone_bricks
fill 432 206 503 432 209 503 minecraft:blackstone
setblock 433 206 463 minecraft:blackstone
setblock 433 206 501 minecraft:polished_blackstone_bricks
fill 433 206 502 436 206 502 minecraft:blackstone
setblock 434 206 466 minecraft:light[level=11]
setblock 434 206 474 minecraft:light[level=11]
setblock 434 206 482 minecraft:light[level=11]
setblock 434 206 490 minecraft:light[level=11]
setblock 434 206 498 minecraft:light[level=11]
fill 434 206 501 434 209 501 minecraft:blackstone
setblock 435 206 464 minecraft:polished_blackstone_bricks
setblock 435 206 504 minecraft:polished_blackstone_bricks
fill 436 206 464 436 209 464 minecraft:blackstone
setblock 436 206 503 minecraft:polished_blackstone_bricks
fill 436 206 504 436 209 504 minecraft:blackstone
setblock 437 206 463 minecraft:blackstone
setblock 437 206 501 minecraft:blackstone
setblock 437 206 502 minecraft:polished_blackstone_bricks
fill 437 206 503 437 209 503 minecraft:blackstone
fill 438 206 502 438 209 502 minecraft:blackstone
setblock 440 206 503 minecraft:blackstone
setblock 440 206 504 minecraft:polished_blackstone_bricks
fill 441 206 504 441 208 504 minecraft:blackstone
setblock 442 206 466 minecraft:light[level=11]
setblock 442 206 474 minecraft:light[level=11]
setblock 442 206 482 minecraft:light[level=11]
setblock 442 206 490 minecraft:light[level=11]
setblock 442 206 498 minecraft:light[level=11]
fill 444 206 505 445 206 505 minecraft:blackstone
setblock 450 206 466 minecraft:light[level=11]
setblock 450 206 474 minecraft:light[level=11]
setblock 450 206 482 minecraft:light[level=11]
setblock 450 206 498 minecraft:light[level=11]
fill 453 206 464 453 207 464 minecraft:blackstone
fill 453 206 504 454 206 504 minecraft:blackstone
setblock 455 206 464 minecraft:polished_blackstone_bricks
fill 455 206 465 455 209 465 minecraft:blackstone
setblock 455 206 504 minecraft:polished_blackstone_bricks
setblock 455 206 505 minecraft:blackstone
fill 456 206 464 456 209 464 minecraft:blackstone
fill 456 206 504 456 209 504 minecraft:blackstone
setblock 458 206 466 minecraft:light[level=11]
setblock 458 206 474 minecraft:light[level=11]
setblock 458 206 482 minecraft:light[level=11]
setblock 458 206 490 minecraft:light[level=11]
setblock 458 206 498 minecraft:light[level=11]
fill 458 206 505 459 206 505 minecraft:blackstone
setblock 459 206 465 minecraft:polished_blackstone_bricks
setblock 460 206 464 minecraft:polished_blackstone_bricks
setblock 460 206 504 minecraft:polished_blackstone_bricks
fill 461 206 464 461 209 464 minecraft:blackstone
setblock 462 206 472 minecraft:polished_blackstone_bricks
fill 462 206 473 462 207 473 minecraft:blackstone
setblock 462 206 477 minecraft:polished_blackstone_bricks
setblock 463 206 471 minecraft:polished_blackstone_bricks
fill 463 206 472 463 208 472 minecraft:blackstone
setblock 463 206 476 minecraft:polished_blackstone_bricks
fill 463 206 477 463 209 477 minecraft:blackstone
fill 463 206 479 463 207 479 minecraft:blackstone
setblock 464 206 465 minecraft:polished_blackstone_bricks
fill 464 206 466 464 208 466 minecraft:blackstone
setblock 464 206 470 minecraft:polished_blackstone_bricks
fill 464 206 471 464 209 471 minecraft:blackstone
setblock 464 206 475 minecraft:polished_blackstone_bricks
fill 464 206 476 464 209 476 minecraft:blackstone
setblock 464 206 480 minecraft:polished_blackstone_bricks
setblock 464 206 495 minecraft:polished_blackstone_bricks
fill 464 206 496 464 208 496 minecraft:blackstone
setblock 464 206 499 minecraft:blackstone
setblock 464 206 500 minecraft:polished_blackstone_bricks
fill 464 206 501 464 209 501 minecraft:blackstone
setblock 465 206 472 minecraft:blackstone
setblock 465 206 474 minecraft:blackstone
setblock 465 206 488 minecraft:blackstone
setblock 465 206 492 minecraft:blackstone
fill 423 207 463 423 207 498 minecraft:soul_soil
setblock 423 207 499 minecraft:blackstone
fill 423 207 500 423 207 502 minecraft:soul_soil
fill 423 207 503 424 207 503 minecraft:blackstone
fill 423 207 504 423 307 505 minecraft:soul_soil
fill 424 207 463 425 307 463 minecraft:soul_soil
setblock 424 207 470 minecraft:blackstone
setblock 424 207 474 minecraft:polished_blackstone_bricks
fill 424 207 475 424 209 475 minecraft:blackstone
setblock 424 207 478 minecraft:blackstone
setblock 424 207 494 minecraft:polished_blackstone_bricks
fill 424 207 495 424 210 495 minecraft:blackstone
setblock 424 207 499 minecraft:polished_blackstone_bricks
fill 424 207 500 424 208 502 minecraft:blackstone
setblock 424 207 504 minecraft:polished_blackstone_bricks
setblock 424 207 505 minecraft:soul_soil
setblock 425 207 498 minecraft:polished_blackstone_bricks
fill 425 207 499 425 210 499 minecraft:blackstone
fill 425 207 501 425 207 502 minecraft:blackstone
setblock 425 207 503 minecraft:polished_blackstone_bricks
fill 425 207 504 425 210 504 minecraft:blackstone
fill 426 207 503 429 207 503 minecraft:blackstone
fill 426 207 505 431 307 505 minecraft:soul_soil
fill 427 207 463 441 207 463 minecraft:soul_soil
setblock 428 207 464 minecraft:blackstone
fill 428 207 502 430 207 502 minecraft:blackstone
setblock 429 207 464 minecraft:polished_blackstone_bricks
setblock 429 207 504 minecraft:polished_blackstone_bricks
fill 430 207 464 430 210 464 minecraft:blackstone
setblock 430 207 503 minecraft:polished_blackstone_bricks
fill 430 207 504 430 210 504 minecraft:blackstone
setblock 431 207 501 minecraft:blackstone
setblock 431 207 502 minecraft:polished_blackstone_bricks
fill 431 207 503 431 210 503 minecraft:blackstone
setblock 432 207 501 minecraft:polished_blackstone_bricks
fill 432 207 502 435 207 502 minecraft:blackstone
setblock 433 207 500 minecraft:polished_blackstone_bricks
fill 433 207 501 433 210 501 minecraft:blackstone
fill 433 207 505 438 207 505 minecraft:soul_soil
setblock 434 207 464 minecraft:polished_blackstone_bricks
fill 434 207 500 435 208 500 minecraft:blackstone
setblock 434 207 504 minecraft:polished_blackstone_bricks
fill 435 207 464 435 210 464 minecraft:blackstone
setblock 435 207 503 minecraft:polished_blackstone_bricks
fill 435 207 504 435 210 504 minecraft:blackstone
setblock 436 207 502 minecraft:polished_blackstone_bricks
fill 436 207 503 436 210 503 minecraft:blackstone
setblock 437 207 501 minecraft:polished_blackstone_bricks
fill 437 207 502 437 210 502 minecraft:blackstone
setblock 439 207 502 minecraft:blackstone
setblock 439 207 504 minecraft:polished_blackstone_bricks
fill 439 207 505 440 207 505 minecraft:blackstone
setblock 440 207 503 minecraft:polished_blackstone_bricks
fill 440 207 504 440 210 504 minecraft:blackstone
fill 441 207 505 443 208 505 minecraft:soul_soil
setblock 442 207 463 minecraft:blackstone
fill 443 207 463 458 208 463 minecraft:soul_soil
setblock 444 207 505 minecraft:blackstone
fill 445 207 505 447 307 505 minecraft:soul_soil
setblock 448 207 505 minecraft:blackstone
fill 449 207 505 455 208 505 minecraft:soul_soil
fill 451 207 504 453 207 504 minecraft:blackstone
fill 452 207 464 452 208 464 minecraft:blackstone
setblock 454 207 464 minecraft:polished_blackstone_bricks
fill 454 207 465 454 210 465 minecraft:blackstone
setblock 454 207 503 minecraft:blackstone
setblock 454 207 504 minecraft:polished_blackstone_bricks
fill 455 207 464 455 210 464 minecraft:blackstone
setblock 455 207 503 minecraft:polished_blackstone_bricks
fill 455 207 504 455 210 504 minecraft:blackstone
fill 456 207 503 457 209 503 minecraft:blackstone
setblock 456 207 505 minecraft:blackstone
fill 457 207 504 458 207 504 minecraft:blackstone
fill 457 207 505 458 307 505 minecraft:soul_soil
setblock 458 207 464 minecraft:blackstone
setblock 458 207 465 minecraft:polished_blackstone_bricks
setblock 459 207 464 minecraft:polished_blackstone_bricks
setblock 459 207 504 minecraft:polished_blackstone_bricks
fill 459 207 505 459 208 505 minecraft:blackstone
fill 460 207 463 463 307 463 minecraft:soul_soil
fill 460 207 464 460 210 464 minecraft:blackstone
fill 460 207 491 460 208 493 minecraft:light_blue_stained_glass
fill 460 207 504 461 209 504 minecraft:blackstone
fill 460 207 505 465 207 505 minecraft:soul_soil
fill 461 207 492 461 208 492 minecraft:light_blue_stained_glass
setblock 462 207 472 minecraft:blackstone
setblock 462 207 476 minecraft:polished_blackstone_bricks
setblock 462 207 477 minecraft:blackstone
setblock 463 207 470 minecraft:polished_blackstone_bricks
fill 463 207 471 463 208 471 minecraft:blackstone
setblock 463 207 475 minecraft:polished_blackstone_bricks
fill 463 207 476 463 209 476 minecraft:blackstone
setblock 464 207 464 minecraft:polished_blackstone_bricks
fill 464 207 465 464 208 465 minecraft:blackstone
setblock 464 207 469 minecraft:polished_blackstone_bricks
fill 464 207 470 464 209 470 minecraft:blackstone
setblock 464 207 474 minecraft:polished_blackstone_bricks
fill 464 207 475 464 210 475 minecraft:blackstone
setblock 464 207 479 minecraft:polished_blackstone_bricks
fill 464 207 480 464 210 480 minecraft:blackstone
setblock 464 207 499 minecraft:polished_blackstone_bricks
fill 464 207 500 465 208 500 minecraft:blackstone
fill 464 207 502 465 207 502 minecraft:blackstone
fill 465 207 463 465 207 467 minecraft:soul_soil
fill 465 207 469 465 207 472 minecraft:soul_soil
fill 465 207 474 465 207 478 minecraft:soul_soil
fill 465 207 480 465 307 480 minecraft:soul_soil
fill 465 207 482 465 208 484 minecraft:soul_soil
setblock 465 207 485 minecraft:blackstone
fill 465 207 486 465 208 492 minecraft:soul_soil
fill 465 207 494 465 208 499 minecraft:soul_soil
setblock 465 207 501 minecraft:soul_soil
fill 465 207 503 465 207 504 minecraft:soul_soil
fill 423 208 463 423 208 467 minecraft:soul_soil
setblock 423 208 468 minecraft:blackstone
fill 423 208 469 423 208 471 minecraft:soul_soil
setblock 423 208 472 minecraft:blackstone
fill 423 208 473 423 208 489 minecraft:soul_soil
setblock 423 208 490 minecraft:blackstone
fill 423 208 491 423 208 500 minecraft:soul_soil
setblock 423 208 501 minecraft:blackstone
fill 423 208 502 423 208 503 minecraft:soul_soil
setblock 424 208 473 minecraft:polished_blackstone_bricks
setblock 424 208 474 minecraft:blackstone
setblock 424 208 478 minecraft:polished_blackstone_bricks
fill 424 208 494 424 209 494 minecraft:blackstone
setblock 424 208 497 minecraft:blackstone
setblock 424 208 498 minecraft:polished_blackstone_bricks
fill 424 208 499 424 211 499 minecraft:blackstone
setblock 424 208 503 minecraft:polished_blackstone_bricks
fill 424 208 504 424 208 505 minecraft:blackstone
setblock 425 208 497 minecraft:polished_blackstone_bricks
fill 425 208 498 426 209 498 minecraft:blackstone
setblock 425 208 501 minecraft:blackstone
setblock 425 208 502 minecraft:polished_blackstone_bricks
fill 425 208 503 428 208 503 minecraft:blackstone
fill 425 208 505 425 307 505 minecraft:soul_soil
fill 426 208 463 426 307 463 minecraft:soul_soil
fill 426 208 499 426 208 500 minecraft:blackstone
fill 427 208 463 427 208 464 minecraft:blackstone
fill 427 208 502 429 208 502 minecraft:blackstone
setblock 427 208 504 minecraft:blackstone
fill 428 208 463 434 208 463 minecraft:soul_soil
setblock 428 208 464 minecraft:polished_blackstone_bricks
setblock 428 208 504 minecraft:polished_blackstone_bricks
fill 429 208 464 429 211 464 minecraft:blackstone
setblock 429 208 503 minecraft:polished_blackstone_bricks
fill 429 208 504 429 211 504 minecraft:blackstone
setblock 430 208 501 minecraft:blackstone
setblock 430 208 502 minecraft:polished_blackstone_bricks
fill 430 208 503 430 211 503 minecraft:blackstone
setblock 431 208 501 minecraft:polished_blackstone_bricks
fill 431 208 502 434 208 502 minecraft:blackstone
setblock 432 208 500 minecraft:polished_blackstone_bricks
fill 432 208 501 432 211 501 minecraft:blackstone
fill 432 208 505 437 307 505 minecraft:soul_soil
setblock 433 208 464 minecraft:polished_blackstone_bricks
fill 433 208 500 433 209 500 minecraft:blackstone
setblock 433 208 504 minecraft:polished_blackstone_bricks
fill 434 208 464 434 211 464 minecraft:blackstone
setblock 434 208 503 minecraft:polished_blackstone_bricks
fill 434 208 504 434 211 504 minecraft:blackstone
setblock 435 208 463 minecraft:blackstone
setblock 435 208 501 minecraft:blackstone
setblock 435 208 502 minecraft:polished_blackstone_bricks
fill 435 208 503 435 211 503 minecraft:blackstone
fill 436 208 463 437 208 463 minecraft:soul_soil
setblock 436 208 501 minecraft:polished_blackstone_bricks
fill 436 208 502 436 211 502 minecraft:blackstone
setblock 437 208 501 minecraft:blackstone
setblock 438 208 463 minecraft:blackstone
setblock 438 208 504 minecraft:polished_blackstone_bricks
setblock 438 208 505 minecraft:blackstone
fill 439 208 463 440 307 463 minecraft:soul_soil
setblock 439 208 503 minecraft:polished_blackstone_bricks
fill 439 208 504 439 211 504 minecraft:blackstone
fill 439 208 505 439 307 505 minecraft:soul_soil
setblock 440 208 505 minecraft:blackstone
setblock 441 208 463 minecraft:blackstone
fill 442 208 463 442 307 463 minecraft:soul_soil
fill 444 208 505 444 307 505 minecraft:soul_soil
fill 448 208 505 448 307 505 minecraft:soul_soil
fill 450 208 504 452 208 504 minecraft:blackstone
fill 451 208 464 451 209 464 minecraft:blackstone
fill 452 208 503 453 208 503 minecraft:blackstone
setblock 453 208 464 minecraft:polished_blackstone_bricks
setblock 453 208 504 minecraft:polished_blackstone_bricks
fill 454 208 464 454 211 464 minecraft:blackstone
setblock 454 208 503 minecraft:polished_blackstone_bricks
fill 454 208 504 454 211 504 minecraft:blackstone
fill 455 208 503 455 211 503 minecraft:blackstone
setblock 456 208 465 minecraft:blackstone
fill 456 208 505 456 307 505 minecraft:soul_soil
setblock 457 208 465 minecraft:polished_blackstone_bricks
setblock 457 208 504 minecraft:blackstone
setblock 458 208 464 minecraft:polished_blackstone_bricks
setblock 458 208 465 minecraft:blackstone
setblock 458 208 504 minecraft:polished_blackstone_bricks
fill 459 208 463 459 307 463 minecraft:soul_soil
fill 459 208 464 459 211 464 minecraft:blackstone
fill 459 208 504 459 211 504 minecraft:blackstone
fill 460 208 505 461 208 505 minecraft:blackstone
setblock 462 208 464 minecraft:blackstone
setblock 462 208 475 minecraft:polished_blackstone_bricks
setblock 462 208 476 minecraft:blackstone
setblock 462 208 504 minecraft:blackstone
fill 462 208 505 462 307 505 minecraft:soul_soil
setblock 463 208 464 minecraft:polished_blackstone_bricks
setblock 463 208 474 minecraft:polished_blackstone_bricks
schedule function dropper:buildpart/117_7 1t
