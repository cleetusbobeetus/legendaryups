setblock 95 112 333 minecraft:stripped_spruce_log
setblock 95 112 334 minecraft:stone
setblock 95 112 337 minecraft:stone
setblock 95 112 338 minecraft:stripped_spruce_log
fill 95 112 339 95 112 340 minecraft:stone
fill 95 112 346 99 112 346 minecraft:stripped_spruce_log
setblock 95 112 353 minecraft:stripped_spruce_log
setblock 95 112 354 minecraft:stone
fill 95 112 356 95 112 357 minecraft:stone
setblock 95 112 358 minecraft:stripped_spruce_log
setblock 95 112 359 minecraft:stone
setblock 95 112 361 minecraft:stone
fill 96 112 323 99 112 323 minecraft:stone
fill 96 112 324 96 113 324 minecraft:spruce_log
setblock 96 112 327 minecraft:stripped_spruce_log
setblock 96 112 328 minecraft:stone
setblock 96 112 332 minecraft:stripped_spruce_log
setblock 96 112 333 minecraft:stone
setblock 96 112 337 minecraft:stripped_spruce_log
setblock 96 112 338 minecraft:stone
fill 96 112 339 113 112 339 minecraft:stripped_spruce_log
fill 96 112 343 96 113 343 minecraft:spruce_log
setblock 96 112 357 minecraft:stripped_spruce_log
setblock 96 112 358 minecraft:stone
fill 96 112 360 98 112 360 minecraft:stripped_spruce_log
fill 96 112 362 96 113 362 minecraft:spruce_log
fill 96 112 363 99 112 363 minecraft:stone
fill 97 112 324 98 112 324 minecraft:stone
setblock 97 112 331 minecraft:stripped_spruce_log
fill 97 112 332 97 114 332 minecraft:stone
setblock 97 112 336 minecraft:stripped_spruce_log
fill 98 112 353 123 112 353 minecraft:stripped_spruce_log
setblock 99 112 324 minecraft:stripped_spruce_log
setblock 100 112 323 minecraft:stripped_spruce_log
setblock 100 112 324 minecraft:stone
fill 100 112 361 101 112 361 minecraft:stone
setblock 100 112 363 minecraft:stripped_spruce_log
fill 101 112 323 104 112 323 minecraft:stone
setblock 101 112 362 minecraft:stripped_spruce_log
setblock 101 112 363 minecraft:stone
setblock 102 112 361 minecraft:stripped_spruce_log
setblock 102 112 362 minecraft:stone
setblock 103 112 361 minecraft:stone
setblock 105 112 323 minecraft:stripped_spruce_log
setblock 105 112 363 minecraft:stripped_spruce_log
setblock 106 112 323 minecraft:stone
setblock 106 112 362 minecraft:stripped_spruce_log
setblock 106 112 363 minecraft:stone
setblock 114 112 363 minecraft:stone
fill 115 112 324 115 113 324 minecraft:spruce_log
fill 115 112 362 115 113 362 minecraft:spruce_log
setblock 115 112 363 minecraft:stripped_spruce_log
fill 116 112 363 119 112 363 minecraft:stone
setblock 117 112 362 minecraft:stone
setblock 120 112 363 minecraft:stripped_spruce_log
fill 121 112 339 134 112 339 minecraft:stripped_spruce_log
setblock 121 112 362 minecraft:stripped_spruce_log
setblock 121 112 363 minecraft:stone
fill 124 112 322 129 112 322 minecraft:deepslate
setblock 130 112 322 minecraft:raw_iron_block
fill 131 112 322 131 174 322 minecraft:deepslate
setblock 132 112 322 minecraft:gold_block
fill 134 112 324 134 113 324 minecraft:spruce_log
setblock 134 112 329 minecraft:stripped_spruce_log
setblock 134 112 330 minecraft:stone
setblock 134 112 334 minecraft:stripped_spruce_log
setblock 134 112 335 minecraft:stone
fill 134 112 343 134 113 343 minecraft:spruce_log
fill 134 112 362 134 113 362 minecraft:spruce_log
setblock 135 112 328 minecraft:stripped_spruce_log
setblock 135 112 329 minecraft:stone
setblock 135 112 333 minecraft:stripped_spruce_log
setblock 135 112 334 minecraft:stone
setblock 135 112 338 minecraft:stripped_spruce_log
setblock 135 112 339 minecraft:stone
setblock 135 112 353 minecraft:stripped_spruce_log
setblock 135 112 354 minecraft:stone
setblock 135 112 358 minecraft:stripped_spruce_log
fill 94 113 324 94 170 324 minecraft:deepslate
fill 94 113 325 94 114 325 minecraft:diamond_block
fill 94 113 326 94 124 328 minecraft:deepslate
fill 95 113 323 95 113 363 minecraft:spruce_planks
fill 96 113 323 135 113 323 minecraft:spruce_planks
fill 96 113 325 96 113 342 minecraft:spruce_planks
fill 96 113 344 96 113 361 minecraft:spruce_planks
fill 96 113 363 135 113 363 minecraft:spruce_planks
fill 97 113 324 114 113 324 minecraft:spruce_planks
fill 97 113 325 97 114 325 minecraft:iron_bars
setblock 97 113 330 minecraft:stripped_spruce_log
fill 97 113 331 97 114 331 minecraft:stone
setblock 97 113 335 minecraft:stripped_spruce_log
fill 97 113 336 97 114 336 minecraft:stone
fill 97 113 362 114 113 362 minecraft:spruce_planks
fill 98 113 334 98 115 334 minecraft:cobbled_deepslate
setblock 100 113 361 minecraft:stone
setblock 101 113 361 minecraft:stripped_spruce_log
fill 102 113 361 102 116 361 minecraft:stone
fill 104 113 325 104 114 361 minecraft:iron_bars
fill 111 113 325 111 114 326 minecraft:iron_bars
fill 114 113 364 115 128 364 minecraft:deepslate
fill 116 113 324 133 113 324 minecraft:spruce_planks
fill 116 113 362 133 113 362 minecraft:spruce_planks
setblock 116 113 364 minecraft:raw_gold_block
fill 118 113 325 118 113 336 minecraft:iron_bars
fill 118 113 344 118 113 361 minecraft:iron_bars
fill 119 113 353 133 113 353 minecraft:stripped_spruce_log
fill 124 113 322 126 116 322 minecraft:deepslate
fill 125 113 325 125 114 327 minecraft:iron_bars
setblock 127 113 322 minecraft:raw_gold_block
fill 128 113 322 130 128 322 minecraft:deepslate
fill 132 113 322 132 114 322 minecraft:deepslate
fill 132 113 325 132 114 326 minecraft:iron_bars
fill 134 113 325 135 113 342 minecraft:spruce_planks
fill 134 113 344 135 113 361 minecraft:spruce_planks
setblock 135 113 324 minecraft:spruce_planks
setblock 135 113 343 minecraft:spruce_planks
setblock 135 113 362 minecraft:spruce_planks
fill 136 113 337 136 117 340 minecraft:deepslate
setblock 136 113 341 minecraft:gold_block
fill 136 113 342 136 164 342 minecraft:deepslate
setblock 136 113 352 minecraft:raw_iron_block
fill 136 113 353 136 134 354 minecraft:deepslate
setblock 94 114 354 minecraft:raw_gold_block
fill 94 114 355 94 129 356 minecraft:deepslate
fill 94 114 358 94 127 360 minecraft:deepslate
setblock 94 114 361 minecraft:raw_gold_block
fill 94 114 362 94 167 362 minecraft:deepslate
fill 95 114 323 95 114 325 minecraft:stone
setblock 95 114 326 minecraft:stripped_spruce_log
fill 95 114 327 95 114 330 minecraft:stone
setblock 95 114 331 minecraft:stripped_spruce_log
fill 95 114 332 95 114 335 minecraft:stone
setblock 95 114 336 minecraft:stripped_spruce_log
fill 95 114 337 95 114 340 minecraft:stone
fill 95 114 353 95 114 355 minecraft:stone
setblock 95 114 356 minecraft:stripped_spruce_log
fill 95 114 357 95 114 360 minecraft:stone
setblock 95 114 361 minecraft:stripped_spruce_log
fill 95 114 362 95 116 363 minecraft:stone
fill 96 114 323 97 114 323 minecraft:stone
fill 96 114 327 96 114 329 minecraft:stone
setblock 96 114 330 minecraft:stripped_spruce_log
fill 96 114 331 96 114 334 minecraft:stone
setblock 96 114 335 minecraft:stripped_spruce_log
fill 96 114 336 96 115 338 minecraft:stone
fill 96 114 340 97 114 340 minecraft:iron_bars
setblock 96 114 355 minecraft:stripped_spruce_log
fill 96 114 356 96 114 359 minecraft:stone
setblock 96 114 360 minecraft:stripped_spruce_log
fill 96 114 361 96 117 361 minecraft:stone
fill 96 114 363 97 114 363 minecraft:stone
setblock 97 114 324 minecraft:stripped_spruce_log
fill 97 114 326 97 114 330 minecraft:iron_bars
setblock 97 114 334 minecraft:stripped_spruce_log
fill 97 114 335 97 115 335 minecraft:stone
fill 97 114 337 97 114 339 minecraft:iron_bars
fill 97 114 341 97 114 352 minecraft:iron_bars
setblock 97 114 353 minecraft:light[level=12]
setblock 97 114 357 minecraft:light[level=15]
setblock 97 114 360 minecraft:light[level=12]
fill 97 114 362 98 114 362 minecraft:stone
setblock 98 114 323 minecraft:stripped_spruce_log
fill 98 114 324 100 114 324 minecraft:stone
fill 98 114 333 98 115 333 minecraft:cobbled_deepslate
fill 98 114 335 98 115 335 minecraft:cobbled_deepslate
setblock 98 114 363 minecraft:stripped_spruce_log
fill 99 114 323 102 114 323 minecraft:stone
setblock 99 114 361 minecraft:stone
setblock 99 114 362 minecraft:stripped_spruce_log
fill 99 114 363 102 114 363 minecraft:stone
setblock 100 114 361 minecraft:stripped_spruce_log
fill 100 114 362 103 114 362 minecraft:stone
fill 101 114 361 101 117 361 minecraft:stone
setblock 103 114 323 minecraft:stripped_spruce_log
setblock 103 114 363 minecraft:stripped_spruce_log
fill 103 114 364 106 117 364 minecraft:deepslate
setblock 104 114 323 minecraft:stone
setblock 104 114 324 minecraft:iron_bars
setblock 104 114 362 minecraft:stripped_spruce_log
fill 104 114 363 107 114 363 minecraft:stone
setblock 105 114 325 minecraft:light[level=15]
setblock 105 114 333 minecraft:light[level=15]
setblock 105 114 341 minecraft:light[level=15]
setblock 105 114 349 minecraft:light[level=15]
setblock 105 114 357 minecraft:light[level=15]
fill 105 114 362 105 117 362 minecraft:stone
setblock 107 114 364 minecraft:raw_gold_block
fill 108 114 364 111 124 364 minecraft:deepslate
fill 111 114 323 111 114 324 minecraft:iron_bars
fill 111 114 327 111 114 362 minecraft:iron_bars
setblock 113 114 325 minecraft:light[level=15]
setblock 113 114 333 minecraft:light[level=15]
setblock 113 114 341 minecraft:light[level=15]
setblock 113 114 349 minecraft:light[level=15]
setblock 113 114 357 minecraft:light[level=15]
setblock 113 114 363 minecraft:stripped_spruce_log
fill 114 114 363 117 114 363 minecraft:stone
fill 116 114 362 118 114 362 minecraft:stone
fill 116 114 364 116 125 364 minecraft:deepslate
fill 118 114 323 118 114 327 minecraft:iron_bars
setblock 118 114 332 minecraft:light[level=12]
setblock 118 114 339 minecraft:light[level=12]
setblock 118 114 346 minecraft:light[level=12]
setblock 118 114 353 minecraft:light[level=12]
setblock 118 114 360 minecraft:light[level=12]
setblock 118 114 363 minecraft:stripped_spruce_log
setblock 119 114 362 minecraft:stripped_spruce_log
fill 119 114 363 122 114 363 minecraft:stone
fill 120 114 362 120 117 362 minecraft:stone
setblock 121 114 325 minecraft:light[level=15]
setblock 121 114 333 minecraft:light[level=15]
setblock 121 114 341 minecraft:light[level=15]
setblock 121 114 349 minecraft:light[level=15]
setblock 121 114 357 minecraft:light[level=15]
fill 125 114 323 125 114 324 minecraft:iron_bars
fill 125 114 328 125 114 363 minecraft:iron_bars
fill 127 114 322 127 123 322 minecraft:deepslate
setblock 129 114 325 minecraft:light[level=15]
setblock 129 114 333 minecraft:light[level=15]
setblock 129 114 341 minecraft:light[level=15]
setblock 129 114 349 minecraft:light[level=15]
setblock 129 114 357 minecraft:light[level=15]
fill 132 114 323 132 114 324 minecraft:iron_bars
fill 132 114 327 132 114 362 minecraft:iron_bars
fill 133 114 347 134 115 347 minecraft:iron_bars
fill 134 114 330 134 114 331 minecraft:stone
setblock 134 114 332 minecraft:stripped_spruce_log
fill 134 114 333 134 114 336 minecraft:stone
setblock 134 114 337 minecraft:stripped_spruce_log
fill 134 114 338 135 115 339 minecraft:stone
fill 135 114 327 135 114 330 minecraft:stone
setblock 135 114 331 minecraft:stripped_spruce_log
fill 135 114 332 135 114 335 minecraft:stone
setblock 135 114 336 minecraft:stripped_spruce_log
fill 135 114 337 135 117 337 minecraft:stone
setblock 135 114 340 minecraft:stone
setblock 135 114 341 minecraft:stripped_spruce_log
fill 135 114 342 135 117 342 minecraft:stone
fill 135 114 353 135 114 355 minecraft:stone
setblock 135 114 356 minecraft:stripped_spruce_log
fill 135 114 357 135 115 359 minecraft:stone
fill 136 114 341 136 123 341 minecraft:deepslate
fill 136 114 352 136 174 352 minecraft:deepslate
fill 136 114 355 136 172 355 minecraft:deepslate
setblock 136 114 356 minecraft:gold_block
fill 94 115 325 94 174 325 minecraft:deepslate
fill 94 115 354 94 152 354 minecraft:deepslate
fill 94 115 361 94 136 361 minecraft:deepslate
fill 95 115 323 95 115 324 minecraft:stone
setblock 95 115 325 minecraft:stripped_spruce_log
fill 95 115 326 95 115 329 minecraft:stone
setblock 95 115 330 minecraft:stripped_spruce_log
fill 95 115 331 95 115 334 minecraft:stone
setblock 95 115 335 minecraft:stripped_spruce_log
fill 95 115 336 95 115 339 minecraft:stone
setblock 95 115 340 minecraft:stripped_spruce_log
setblock 95 115 354 minecraft:stone
setblock 95 115 355 minecraft:stripped_spruce_log
fill 95 115 356 95 115 359 minecraft:stone
setblock 95 115 360 minecraft:stripped_spruce_log
fill 95 115 361 95 118 361 minecraft:stone
setblock 96 115 323 minecraft:stone
setblock 96 115 328 minecraft:stone
setblock 96 115 329 minecraft:stripped_spruce_log
fill 96 115 330 96 115 333 minecraft:stone
setblock 96 115 334 minecraft:stripped_spruce_log
fill 96 115 335 96 118 335 minecraft:stone
setblock 96 115 339 minecraft:stripped_spruce_log
fill 96 115 340 96 116 340 minecraft:iron_bars
fill 96 115 355 96 115 358 minecraft:stone
setblock 96 115 359 minecraft:stripped_spruce_log
fill 96 115 360 96 118 360 minecraft:stone
fill 96 115 362 96 115 363 minecraft:stone
setblock 97 115 323 minecraft:stripped_spruce_log
fill 97 115 324 99 116 324 minecraft:stone
setblock 97 115 332 minecraft:cobbled_deepslate
setblock 97 115 333 minecraft:stripped_spruce_log
setblock 97 115 334 minecraft:stone
setblock 97 115 336 minecraft:cobbled_deepslate
fill 97 115 347 97 115 358 minecraft:iron_bars
fill 97 115 359 97 118 359 minecraft:stone
fill 97 115 360 97 115 361 minecraft:iron_bars
setblock 97 115 362 minecraft:stone
setblock 97 115 363 minecraft:stripped_spruce_log
fill 98 115 323 101 115 323 minecraft:stone
setblock 98 115 361 minecraft:stone
setblock 98 115 362 minecraft:stripped_spruce_log
fill 98 115 363 101 115 363 minecraft:stone
setblock 99 115 334 minecraft:cobbled_deepslate
setblock 99 115 361 minecraft:stripped_spruce_log
fill 99 115 362 102 115 362 minecraft:stone
fill 100 115 361 100 118 361 minecraft:stone
setblock 102 115 323 minecraft:stripped_spruce_log
setblock 102 115 363 minecraft:stripped_spruce_log
setblock 103 115 323 minecraft:stone
setblock 103 115 362 minecraft:stripped_spruce_log
fill 103 115 363 106 115 363 minecraft:stone
fill 104 115 362 104 118 362 minecraft:stone
setblock 107 115 363 minecraft:stripped_spruce_log
fill 107 115 364 107 170 364 minecraft:deepslate
fill 111 115 359 111 121 359 minecraft:stripped_spruce_log
fill 111 115 360 111 115 362 minecraft:iron_bars
setblock 112 115 363 minecraft:stripped_spruce_log
fill 113 115 363 116 115 363 minecraft:stone
fill 115 115 362 117 115 362 minecraft:stone
setblock 117 115 363 minecraft:stripped_spruce_log
setblock 118 115 362 minecraft:stripped_spruce_log
fill 118 115 363 121 115 363 minecraft:stone
fill 119 115 362 119 118 362 minecraft:stone
setblock 122 115 363 minecraft:stripped_spruce_log
fill 131 115 355 131 118 355 minecraft:cobbled_deepslate
setblock 132 115 322 minecraft:raw_iron_block
setblock 132 115 347 minecraft:iron_bars
fill 132 115 356 132 115 362 minecraft:iron_bars
setblock 134 115 331 minecraft:stripped_spruce_log
fill 134 115 332 134 115 335 minecraft:stone
setblock 134 115 336 minecraft:stripped_spruce_log
fill 134 115 337 134 118 337 minecraft:stone
setblock 134 115 340 minecraft:stone
fill 135 115 326 135 115 329 minecraft:stone
setblock 135 115 330 minecraft:stripped_spruce_log
fill 135 115 331 135 115 334 minecraft:stone
setblock 135 115 335 minecraft:stripped_spruce_log
fill 135 115 336 135 118 336 minecraft:stone
setblock 135 115 340 minecraft:stripped_spruce_log
fill 135 115 341 135 118 341 minecraft:stone
fill 135 115 343 135 116 343 minecraft:stone
setblock 135 115 354 minecraft:stone
setblock 135 115 355 minecraft:stripped_spruce_log
fill 135 115 356 135 118 356 minecraft:stone
setblock 135 115 360 minecraft:stripped_spruce_log
fill 136 115 356 136 153 356 minecraft:deepslate
setblock 95 116 323 minecraft:stone
setblock 95 116 324 minecraft:stripped_spruce_log
fill 95 116 325 95 116 328 minecraft:stone
setblock 95 116 329 minecraft:stripped_spruce_log
fill 95 116 330 95 116 333 minecraft:stone
setblock 95 116 334 minecraft:stripped_spruce_log
fill 95 116 335 95 116 338 minecraft:stone
setblock 95 116 339 minecraft:stripped_spruce_log
fill 95 116 340 95 118 341 minecraft:stone
setblock 95 116 354 minecraft:stripped_spruce_log
fill 95 116 355 95 116 358 minecraft:stone
setblock 95 116 359 minecraft:stripped_spruce_log
fill 95 116 360 95 119 360 minecraft:stone
setblock 96 116 323 minecraft:stripped_spruce_log
fill 96 116 324 96 119 324 minecraft:stone
fill 96 116 329 96 116 332 minecraft:stone
setblock 96 116 333 minecraft:stripped_spruce_log
fill 96 116 334 96 119 334 minecraft:stone
fill 96 116 336 96 116 337 minecraft:stone
setblock 96 116 338 minecraft:stripped_spruce_log
fill 96 116 339 96 119 339 minecraft:stone
fill 96 116 355 96 116 357 minecraft:stone
setblock 96 116 358 minecraft:stripped_spruce_log
fill 96 116 359 96 119 359 minecraft:stone
setblock 96 116 362 minecraft:stone
setblock 96 116 363 minecraft:stripped_spruce_log
fill 97 116 323 100 116 323 minecraft:stone
setblock 97 116 333 minecraft:iron_bars
fill 97 116 358 97 119 358 minecraft:stone
fill 97 116 360 97 116 361 minecraft:stone
setblock 97 116 362 minecraft:stripped_spruce_log
fill 97 116 363 100 116 363 minecraft:stone
setblock 98 116 361 minecraft:stripped_spruce_log
fill 98 116 362 101 116 362 minecraft:stone
fill 99 116 361 99 119 361 minecraft:stone
setblock 101 116 323 minecraft:stripped_spruce_log
setblock 101 116 363 minecraft:stripped_spruce_log
fill 102 116 323 102 119 323 minecraft:stone
setblock 102 116 362 minecraft:stripped_spruce_log
fill 102 116 363 105 116 363 minecraft:stone
fill 103 116 362 103 119 362 minecraft:stone
setblock 106 116 363 minecraft:stripped_spruce_log
setblock 107 116 322 minecraft:raw_iron_block
fill 107 116 363 110 116 363 minecraft:stone
setblock 111 116 363 minecraft:stripped_spruce_log
fill 112 116 363 115 116 363 minecraft:stone
fill 114 116 362 116 116 362 minecraft:stone
setblock 116 116 363 minecraft:stripped_spruce_log
setblock 117 116 362 minecraft:stripped_spruce_log
fill 117 116 363 120 116 363 minecraft:stone
fill 118 116 362 118 119 362 minecraft:stone
setblock 121 116 363 minecraft:stripped_spruce_log
fill 132 116 322 132 128 322 minecraft:deepslate
setblock 133 116 322 minecraft:raw_gold_block
setblock 133 116 336 minecraft:stripped_spruce_log
fill 134 116 322 135 117 322 minecraft:deepslate
fill 134 116 331 134 116 334 minecraft:stone
setblock 134 116 335 minecraft:stripped_spruce_log
fill 134 116 336 134 119 336 minecraft:stone
fill 134 116 338 134 116 339 minecraft:stone
setblock 134 116 340 minecraft:stripped_spruce_log
fill 134 116 341 134 119 341 minecraft:stone
setblock 135 116 323 minecraft:stone
setblock 135 116 324 minecraft:stripped_spruce_log
fill 135 116 325 135 116 328 minecraft:stone
setblock 135 116 329 minecraft:stripped_spruce_log
fill 135 116 330 135 116 333 minecraft:stone
setblock 135 116 334 minecraft:stripped_spruce_log
fill 135 116 335 135 119 335 minecraft:stone
setblock 135 116 338 minecraft:stone
setblock 135 116 339 minecraft:stripped_spruce_log
fill 135 116 340 135 119 340 minecraft:stone
fill 135 116 355 135 119 355 minecraft:stone
fill 135 116 357 135 116 358 minecraft:stone
setblock 135 116 359 minecraft:stripped_spruce_log
fill 135 116 360 135 117 362 minecraft:stone
setblock 136 116 327 minecraft:gold_block
fill 136 116 328 136 174 328 minecraft:deepslate
setblock 136 116 332 minecraft:diamond_block
setblock 94 117 363 minecraft:diamond_block
fill 94 117 364 94 174 364 minecraft:deepslate
setblock 95 117 323 minecraft:stripped_spruce_log
fill 95 117 324 95 117 327 minecraft:stone
setblock 95 117 328 minecraft:stripped_spruce_log
fill 95 117 329 95 117 332 minecraft:stone
setblock 95 117 333 minecraft:stripped_spruce_log
fill 95 117 334 95 117 337 minecraft:stone
setblock 95 117 338 minecraft:stripped_spruce_log
fill 95 117 339 95 120 339 minecraft:stone
setblock 95 117 342 minecraft:stone
fill 95 117 354 95 117 357 minecraft:stone
setblock 95 117 358 minecraft:stripped_spruce_log
fill 95 117 359 95 120 359 minecraft:stone
setblock 95 117 362 minecraft:stone
setblock 95 117 363 minecraft:stripped_spruce_log
fill 96 117 323 99 117 323 minecraft:stone
fill 96 117 325 96 118 325 minecraft:stone
fill 96 117 329 96 117 331 minecraft:stone
setblock 96 117 332 minecraft:stripped_spruce_log
fill 96 117 333 96 120 333 minecraft:stone
setblock 96 117 336 minecraft:stone
setblock 96 117 337 minecraft:stripped_spruce_log
fill 96 117 338 96 120 338 minecraft:stone
fill 96 117 340 96 118 340 minecraft:stone
fill 96 117 355 96 117 356 minecraft:stone
setblock 96 117 357 minecraft:stripped_spruce_log
fill 96 117 358 96 120 358 minecraft:stone
setblock 96 117 362 minecraft:stripped_spruce_log
fill 96 117 363 99 117 363 minecraft:stone
fill 97 117 324 98 117 324 minecraft:stone
fill 97 117 357 97 120 357 minecraft:stone
setblock 97 117 360 minecraft:stone
setblock 97 117 361 minecraft:stripped_spruce_log
fill 97 117 362 100 117 362 minecraft:stone
fill 98 117 361 98 120 361 minecraft:stone
setblock 99 117 324 minecraft:stripped_spruce_log
setblock 100 117 323 minecraft:stripped_spruce_log
setblock 100 117 363 minecraft:stripped_spruce_log
fill 101 117 322 102 123 322 minecraft:deepslate
fill 101 117 323 101 120 323 minecraft:stone
setblock 101 117 362 minecraft:stripped_spruce_log
fill 101 117 363 104 117 363 minecraft:stone
setblock 102 117 361 minecraft:stripped_spruce_log
fill 102 117 362 102 120 362 minecraft:stone
setblock 103 117 322 minecraft:raw_gold_block
setblock 105 117 363 minecraft:stripped_spruce_log
fill 106 117 363 109 117 363 minecraft:stone
fill 107 117 322 107 172 322 minecraft:deepslate
setblock 110 117 363 minecraft:stripped_spruce_log
fill 111 117 363 114 117 363 minecraft:stone
fill 112 117 362 115 117 362 minecraft:stone
fill 115 117 361 116 117 361 minecraft:stone
setblock 115 117 363 minecraft:stripped_spruce_log
setblock 116 117 362 minecraft:stripped_spruce_log
fill 116 117 363 119 117 363 minecraft:stone
setblock 117 117 361 minecraft:stripped_spruce_log
fill 117 117 362 117 120 362 minecraft:stone
fill 118 117 361 118 120 361 minecraft:stone
setblock 120 117 363 minecraft:stripped_spruce_log
fill 121 117 348 135 117 348 minecraft:stripped_spruce_log
fill 121 117 363 121 120 363 minecraft:stone
setblock 124 117 322 minecraft:diamond_block
fill 125 117 322 126 174 322 minecraft:deepslate
fill 127 117 327 134 117 327 minecraft:stripped_spruce_log
fill 133 117 322 133 174 322 minecraft:deepslate
fill 133 117 328 134 118 329 minecraft:raw_gold_block
setblock 133 117 335 minecraft:stripped_spruce_log
fill 133 117 336 133 118 338 minecraft:stone
setblock 134 117 323 minecraft:stone
fill 134 117 331 134 117 333 minecraft:stone
setblock 134 117 334 minecraft:stripped_spruce_log
fill 134 117 335 134 120 335 minecraft:stone
setblock 134 117 338 minecraft:stone
setblock 134 117 339 minecraft:stripped_spruce_log
fill 134 117 340 134 120 340 minecraft:stone
setblock 134 117 363 minecraft:stone
setblock 135 117 323 minecraft:stripped_spruce_log
fill 135 117 324 135 117 327 minecraft:stone
setblock 135 117 328 minecraft:stripped_spruce_log
fill 135 117 329 135 117 332 minecraft:stone
setblock 135 117 333 minecraft:stripped_spruce_log
fill 135 117 334 135 120 334 minecraft:stone
setblock 135 117 338 minecraft:stripped_spruce_log
fill 135 117 339 135 120 339 minecraft:stone
setblock 135 117 343 minecraft:stripped_spruce_log
fill 135 117 344 135 120 344 minecraft:stone
setblock 135 117 357 minecraft:stone
setblock 135 117 358 minecraft:stripped_spruce_log
fill 135 117 359 135 120 359 minecraft:stone
setblock 135 117 363 minecraft:stripped_spruce_log
setblock 136 117 323 minecraft:diamond_block
fill 136 117 327 136 126 327 minecraft:deepslate
fill 136 117 332 136 153 332 minecraft:deepslate
fill 94 118 363 94 174 363 minecraft:deepslate
fill 95 118 323 95 118 326 minecraft:stone
setblock 95 118 327 minecraft:stripped_spruce_log
fill 95 118 328 95 118 331 minecraft:stone
setblock 95 118 332 minecraft:stripped_spruce_log
fill 95 118 333 95 118 336 minecraft:stone
setblock 95 118 337 minecraft:stripped_spruce_log
fill 95 118 338 95 121 338 minecraft:stone
setblock 95 118 342 minecraft:stripped_spruce_log
fill 95 118 343 95 121 343 minecraft:stone
fill 95 118 348 126 118 348 minecraft:stripped_spruce_log
fill 95 118 353 95 118 356 minecraft:stone
setblock 95 118 357 minecraft:stripped_spruce_log
fill 95 118 358 95 121 358 minecraft:stone
setblock 95 118 362 minecraft:stripped_spruce_log
fill 95 118 363 98 118 363 minecraft:stone
fill 96 118 323 98 118 323 minecraft:stone
setblock 96 118 326 minecraft:stripped_spruce_log
fill 96 118 327 96 121 327 minecraft:stone
fill 96 118 329 96 118 330 minecraft:stone
setblock 96 118 331 minecraft:stripped_spruce_log
fill 96 118 332 96 121 332 minecraft:stone
setblock 96 118 336 minecraft:stripped_spruce_log
fill 96 118 337 96 121 337 minecraft:stone
fill 96 118 341 113 118 341 minecraft:stripped_spruce_log
setblock 96 118 355 minecraft:stone
setblock 96 118 356 minecraft:stripped_spruce_log
fill 96 118 357 96 121 357 minecraft:stone
setblock 96 118 361 minecraft:stripped_spruce_log
fill 96 118 362 99 118 362 minecraft:stone
setblock 97 118 324 minecraft:stone
fill 97 118 327 133 118 327 minecraft:stripped_spruce_log
fill 97 118 334 105 119 334 minecraft:stripped_spruce_log
fill 97 118 355 129 118 355 minecraft:stripped_spruce_log
setblock 97 118 360 minecraft:stripped_spruce_log
fill 97 118 361 97 121 361 minecraft:stone
setblock 98 118 324 minecraft:stripped_spruce_log
setblock 99 118 323 minecraft:stripped_spruce_log
fill 99 118 324 99 121 324 minecraft:stone
setblock 99 118 363 minecraft:stripped_spruce_log
fill 100 118 323 100 121 323 minecraft:stone
setblock 100 118 362 minecraft:stripped_spruce_log
fill 100 118 363 103 118 363 minecraft:stone
setblock 101 118 361 minecraft:stripped_spruce_log
fill 101 118 362 101 121 362 minecraft:stone
fill 102 118 361 103 120 361 minecraft:stone
fill 103 118 322 103 161 322 minecraft:deepslate
setblock 103 118 323 minecraft:stone
fill 103 118 364 105 123 364 minecraft:deepslate
setblock 104 118 363 minecraft:stripped_spruce_log
setblock 105 118 362 minecraft:stripped_spruce_log
fill 105 118 363 108 118 363 minecraft:stone
fill 106 118 362 106 121 362 minecraft:stone
setblock 106 118 364 minecraft:gold_block
setblock 109 118 362 minecraft:stone
setblock 109 118 363 minecraft:stripped_spruce_log
fill 110 118 359 110 121 359 minecraft:stripped_spruce_log
setblock 110 118 362 minecraft:stripped_spruce_log
fill 110 118 363 113 118 363 minecraft:stone
fill 111 118 358 111 121 358 minecraft:stripped_spruce_log
fill 111 118 360 111 121 360 minecraft:stripped_spruce_log
fill 111 118 362 114 118 362 minecraft:stone
fill 112 118 359 112 121 359 minecraft:stripped_spruce_log
fill 113 118 361 115 118 361 minecraft:stone
setblock 114 118 363 minecraft:stripped_spruce_log
setblock 115 118 362 minecraft:stripped_spruce_log
fill 115 118 363 118 118 363 minecraft:stone
setblock 116 118 361 minecraft:stripped_spruce_log
fill 116 118 362 116 121 362 minecraft:stone
fill 117 118 361 117 121 361 minecraft:stone
setblock 119 118 363 minecraft:stripped_spruce_log
setblock 120 118 362 minecraft:stripped_spruce_log
fill 120 118 363 120 121 363 minecraft:stone
fill 121 118 341 133 118 341 minecraft:stripped_spruce_log
fill 122 118 363 122 119 363 minecraft:stone
fill 124 118 322 124 174 322 minecraft:deepslate
setblock 130 118 355 minecraft:cobbled_deepslate
fill 131 118 354 131 119 354 minecraft:cobbled_deepslate
fill 131 118 356 131 119 356 minecraft:cobbled_deepslate
fill 132 118 328 132 121 329 minecraft:raw_gold_block
setblock 132 118 355 minecraft:cobbled_deepslate
setblock 133 118 323 minecraft:stone
fill 133 118 326 134 119 326 minecraft:raw_gold_block
fill 133 118 330 133 119 330 minecraft:raw_gold_block
fill 133 118 335 133 121 335 minecraft:stone
setblock 133 118 339 minecraft:stripped_spruce_log
setblock 133 118 363 minecraft:stone
setblock 134 118 322 minecraft:gold_block
setblock 134 118 323 minecraft:stripped_spruce_log
fill 134 118 327 134 119 327 minecraft:raw_gold_block
fill 134 118 330 134 118 332 minecraft:stone
setblock 134 118 333 minecraft:stripped_spruce_log
fill 134 118 334 134 121 334 minecraft:stone
setblock 134 118 338 minecraft:stripped_spruce_log
fill 134 118 339 134 121 339 minecraft:stone
setblock 134 118 342 minecraft:stone
setblock 134 118 363 minecraft:stripped_spruce_log
fill 135 118 322 135 127 322 minecraft:deepslate
fill 135 118 323 135 118 326 minecraft:stone
setblock 135 118 327 minecraft:stripped_spruce_log
fill 135 118 328 135 118 331 minecraft:stone
setblock 135 118 332 minecraft:stripped_spruce_log
fill 135 118 333 135 121 333 minecraft:stone
setblock 135 118 337 minecraft:stripped_spruce_log
fill 135 118 338 135 121 338 minecraft:stone
setblock 135 118 342 minecraft:stripped_spruce_log
fill 135 118 343 135 121 343 minecraft:stone
fill 135 118 345 135 119 345 minecraft:stone
setblock 135 118 357 minecraft:stripped_spruce_log
fill 135 118 358 135 121 358 minecraft:stone
fill 135 118 360 135 118 361 minecraft:stone
setblock 135 118 362 minecraft:stripped_spruce_log
fill 135 118 363 135 121 363 minecraft:stone
fill 136 118 323 136 141 323 minecraft:deepslate
fill 136 118 337 136 170 337 minecraft:deepslate
setblock 136 118 338 minecraft:raw_iron_block
fill 136 118 339 136 170 340 minecraft:deepslate
fill 95 119 323 95 119 325 minecraft:stone
setblock 95 119 326 minecraft:stripped_spruce_log
fill 95 119 327 95 119 330 minecraft:stone
setblock 95 119 331 minecraft:stripped_spruce_log
fill 95 119 332 95 119 335 minecraft:stone
setblock 95 119 336 minecraft:stripped_spruce_log
fill 95 119 337 95 122 337 minecraft:stone
setblock 95 119 340 minecraft:stone
setblock 95 119 341 minecraft:stripped_spruce_log
fill 95 119 342 96 121 342 minecraft:stone
fill 95 119 344 95 119 345 minecraft:stone
fill 95 119 348 97 119 348 minecraft:stripped_spruce_log
fill 95 119 353 95 119 355 minecraft:stone
setblock 95 119 356 minecraft:stripped_spruce_log
fill 95 119 357 95 122 357 minecraft:stone
setblock 95 119 361 minecraft:stripped_spruce_log
fill 95 119 362 97 119 363 minecraft:stone
fill 96 119 323 97 119 323 minecraft:stone
setblock 96 119 325 minecraft:stripped_spruce_log
fill 96 119 326 96 122 326 minecraft:stone
fill 96 119 328 96 119 329 minecraft:stone
setblock 96 119 330 minecraft:stripped_spruce_log
fill 96 119 331 96 122 331 minecraft:stone
setblock 96 119 335 minecraft:stripped_spruce_log
fill 96 119 336 96 122 336 minecraft:stone
setblock 96 119 340 minecraft:stripped_spruce_log
fill 96 119 341 96 122 341 minecraft:stone
fill 96 119 355 98 119 355 minecraft:stripped_spruce_log
fill 96 119 356 96 122 356 minecraft:stone
setblock 96 119 360 minecraft:stripped_spruce_log
fill 96 119 361 96 122 361 minecraft:stone
setblock 97 119 324 minecraft:stripped_spruce_log
fill 97 119 327 98 119 327 minecraft:stripped_spruce_log
fill 97 119 341 99 119 341 minecraft:stripped_spruce_log
setblock 97 119 359 minecraft:stripped_spruce_log
fill 97 119 360 99 120 360 minecraft:stone
setblock 98 119 323 minecraft:stripped_spruce_log
fill 98 119 324 98 122 324 minecraft:stone
setblock 98 119 362 minecraft:stone
setblock 98 119 363 minecraft:stripped_spruce_log
fill 99 119 323 99 122 323 minecraft:stone
fill 99 119 352 99 119 359 minecraft:iron_bars
setblock 99 119 362 minecraft:stripped_spruce_log
fill 99 119 363 102 119 363 minecraft:stone
fill 100 119 324 100 120 324 minecraft:stone
fill 100 119 355 134 119 355 minecraft:stripped_spruce_log
setblock 100 119 361 minecraft:stripped_spruce_log
fill 100 119 362 100 122 362 minecraft:stone
fill 101 119 361 101 122 361 minecraft:stone
setblock 103 119 323 minecraft:stripped_spruce_log
setblock 103 119 363 minecraft:stripped_spruce_log
setblock 104 119 362 minecraft:stripped_spruce_log
fill 104 119 363 107 119 363 minecraft:stone
fill 105 119 362 105 122 362 minecraft:stone
fill 106 119 334 132 119 334 minecraft:stripped_spruce_log
fill 106 119 364 106 161 364 minecraft:deepslate
fill 107 119 362 108 119 362 minecraft:stone
setblock 108 119 363 minecraft:stripped_spruce_log
setblock 109 119 362 minecraft:stripped_spruce_log
fill 109 119 363 112 119 363 minecraft:stone
fill 110 119 362 113 119 362 minecraft:stone
fill 111 119 361 114 119 361 minecraft:stone
setblock 113 119 363 minecraft:stripped_spruce_log
fill 114 119 323 117 119 323 minecraft:stone
setblock 114 119 362 minecraft:stripped_spruce_log
fill 114 119 363 117 119 363 minecraft:stone
setblock 115 119 361 minecraft:stripped_spruce_log
fill 115 119 362 115 122 362 minecraft:stone
fill 116 119 361 116 122 361 minecraft:stone
setblock 118 119 323 minecraft:stripped_spruce_log
setblock 118 119 363 minecraft:stripped_spruce_log
setblock 119 119 361 minecraft:stone
setblock 119 119 362 minecraft:stripped_spruce_log
fill 119 119 363 119 122 363 minecraft:stone
fill 120 119 362 120 122 362 minecraft:stone
fill 121 119 362 126 119 362 minecraft:stripped_spruce_log
fill 125 119 328 125 119 332 minecraft:stripped_dark_oak_log
fill 126 119 328 126 120 329 minecraft:stripped_dark_oak_log
fill 126 119 331 126 119 333 minecraft:stripped_dark_oak_log
fill 127 119 327 129 119 328 minecraft:stripped_dark_oak_log
fill 127 119 333 130 119 333 minecraft:stripped_dark_oak_log
fill 130 119 328 131 119 332 minecraft:stripped_dark_oak_log
setblock 130 119 354 minecraft:cobbled_deepslate
setblock 130 119 356 minecraft:cobbled_deepslate
fill 131 119 323 132 119 323 minecraft:stone
fill 131 119 327 133 120 327 minecraft:raw_gold_block
setblock 132 119 354 minecraft:cobbled_deepslate
setblock 132 119 356 minecraft:cobbled_deepslate
setblock 132 119 363 minecraft:stone
fill 132 119 364 133 124 364 minecraft:deepslate
setblock 133 119 323 minecraft:stripped_spruce_log
fill 133 119 328 133 120 329 minecraft:raw_gold_block
fill 133 119 334 133 122 334 minecraft:stone
fill 133 119 336 133 119 337 minecraft:stone
setblock 133 119 338 minecraft:stripped_spruce_log
fill 133 119 339 133 120 341 minecraft:stone
setblock 133 119 363 minecraft:stripped_spruce_log
fill 134 119 322 134 147 322 minecraft:deepslate
fill 134 119 323 135 119 325 minecraft:stone
fill 134 119 328 134 119 331 minecraft:stone
setblock 134 119 332 minecraft:stripped_spruce_log
fill 134 119 333 134 122 333 minecraft:stone
setblock 134 119 337 minecraft:stripped_spruce_log
fill 134 119 338 134 122 338 minecraft:stone
setblock 134 119 342 minecraft:stripped_spruce_log
fill 134 119 343 134 121 344 minecraft:stone
fill 134 119 359 134 119 361 minecraft:stone
setblock 134 119 362 minecraft:stripped_spruce_log
fill 134 119 363 134 122 363 minecraft:stone
setblock 134 119 364 minecraft:raw_gold_block
setblock 135 119 326 minecraft:stripped_spruce_log
fill 135 119 327 135 119 330 minecraft:stone
setblock 135 119 331 minecraft:stripped_spruce_log
fill 135 119 332 135 122 332 minecraft:stone
setblock 135 119 336 minecraft:stripped_spruce_log
fill 135 119 337 135 122 337 minecraft:stone
setblock 135 119 341 minecraft:stripped_spruce_log
fill 135 119 342 135 122 342 minecraft:stone
setblock 135 119 346 minecraft:stripped_spruce_log
fill 135 119 354 135 120 354 minecraft:stone
setblock 135 119 356 minecraft:stripped_spruce_log
fill 135 119 357 135 122 357 minecraft:stone
setblock 135 119 360 minecraft:stone
setblock 135 119 361 minecraft:stripped_spruce_log
fill 135 119 362 135 122 362 minecraft:stone
fill 136 119 338 136 170 338 minecraft:deepslate
fill 95 120 323 95 120 324 minecraft:stone
setblock 95 120 325 minecraft:stripped_spruce_log
fill 95 120 326 95 120 329 minecraft:stone
setblock 95 120 330 minecraft:stripped_spruce_log
fill 95 120 331 95 120 334 minecraft:stone
setblock 95 120 335 minecraft:stripped_spruce_log
fill 95 120 336 95 122 336 minecraft:stone
setblock 95 120 340 minecraft:stripped_spruce_log
fill 95 120 341 95 122 341 minecraft:stone
setblock 95 120 344 minecraft:stone
setblock 95 120 345 minecraft:stripped_spruce_log
fill 95 120 346 95 122 346 minecraft:stone
fill 95 120 352 95 120 354 minecraft:stone
setblock 95 120 355 minecraft:stripped_spruce_log
fill 95 120 356 95 122 356 minecraft:stone
setblock 95 120 360 minecraft:stripped_spruce_log
fill 95 120 361 95 121 363 minecraft:stone
setblock 96 120 323 minecraft:stone
setblock 96 120 324 minecraft:stripped_spruce_log
fill 96 120 325 96 122 325 minecraft:stone
setblock 96 120 328 minecraft:stone
setblock 96 120 329 minecraft:stripped_spruce_log
fill 96 120 330 96 122 330 minecraft:stone
setblock 96 120 334 minecraft:stripped_spruce_log
fill 96 120 335 96 122 335 minecraft:stone
setblock 96 120 339 minecraft:stripped_spruce_log
fill 96 120 340 96 122 340 minecraft:stone
setblock 96 120 343 minecraft:stone
fill 96 120 355 96 122 355 minecraft:stone
setblock 96 120 359 minecraft:stripped_spruce_log
fill 96 120 360 96 122 360 minecraft:stone
fill 96 120 362 96 120 363 minecraft:stone
setblock 97 120 323 minecraft:stripped_spruce_log
fill 97 120 324 97 122 324 minecraft:stone
setblock 97 120 325 minecraft:light[level=12]
setblock 97 120 332 minecraft:light[level=12]
setblock 97 120 339 minecraft:light[level=12]
setblock 97 120 346 minecraft:light[level=12]
setblock 97 120 353 minecraft:light[level=12]
setblock 97 120 358 minecraft:stripped_spruce_log
fill 97 120 359 98 122 359 minecraft:stone
setblock 97 120 362 minecraft:stone
setblock 97 120 363 minecraft:stripped_spruce_log
fill 98 120 323 98 122 323 minecraft:stone
setblock 98 120 362 minecraft:stripped_spruce_log
fill 98 120 363 101 120 363 minecraft:stone
fill 99 120 325 99 120 358 minecraft:iron_bars
setblock 99 120 361 minecraft:stripped_spruce_log
fill 99 120 362 99 122 362 minecraft:stone
setblock 100 120 360 minecraft:stripped_spruce_log
fill 100 120 361 100 122 361 minecraft:stone
setblock 102 120 323 minecraft:stripped_spruce_log
setblock 102 120 363 minecraft:stripped_spruce_log
fill 103 120 323 104 122 323 minecraft:stone
setblock 103 120 362 minecraft:stripped_spruce_log
fill 103 120 363 106 120 363 minecraft:stone
setblock 104 120 325 minecraft:light[level=12]
setblock 104 120 332 minecraft:light[level=12]
setblock 104 120 339 minecraft:light[level=12]
setblock 104 120 346 minecraft:light[level=12]
setblock 104 120 353 minecraft:light[level=12]
setblock 104 120 360 minecraft:light[level=12]
setblock 104 120 361 minecraft:stripped_spruce_log
fill 104 120 362 104 122 362 minecraft:stone
fill 106 120 323 106 120 361 minecraft:iron_bars
setblock 107 120 362 minecraft:stone
setblock 107 120 363 minecraft:stripped_spruce_log
setblock 108 120 362 minecraft:stripped_spruce_log
fill 108 120 363 111 120 363 minecraft:stone
fill 109 120 362 112 120 362 minecraft:stone
fill 110 120 361 113 120 361 minecraft:stone
setblock 111 120 325 minecraft:light[level=12]
setblock 111 120 332 minecraft:light[level=12]
setblock 111 120 339 minecraft:light[level=12]
setblock 111 120 346 minecraft:light[level=12]
setblock 111 120 353 minecraft:light[level=12]
setblock 112 120 323 minecraft:stripped_spruce_log
setblock 112 120 363 minecraft:stripped_spruce_log
fill 113 120 323 116 120 323 minecraft:stone
fill 113 120 324 113 121 359 minecraft:iron_bars
setblock 113 120 362 minecraft:stripped_spruce_log
fill 113 120 363 116 120 363 minecraft:stone
setblock 114 120 361 minecraft:stripped_spruce_log
fill 114 120 362 114 122 362 minecraft:stone
setblock 115 120 360 minecraft:stripped_spruce_log
fill 115 120 361 115 122 361 minecraft:stone
setblock 117 120 323 minecraft:stripped_spruce_log
setblock 117 120 363 minecraft:stripped_spruce_log
fill 118 120 323 120 121 323 minecraft:stone
setblock 118 120 325 minecraft:light[level=12]
setblock 118 120 332 minecraft:light[level=12]
setblock 118 120 339 minecraft:light[level=12]
setblock 118 120 346 minecraft:light[level=12]
setblock 118 120 353 minecraft:light[level=12]
setblock 118 120 360 minecraft:light[level=12]
setblock 118 120 362 minecraft:stripped_spruce_log
fill 118 120 363 118 122 363 minecraft:stone
setblock 119 120 361 minecraft:stripped_spruce_log
fill 119 120 362 119 122 362 minecraft:stone
fill 120 120 324 120 121 338 minecraft:iron_bars
fill 120 120 342 120 120 361 minecraft:iron_bars
fill 121 120 362 121 121 362 minecraft:stone
fill 122 120 362 122 120 363 minecraft:stripped_spruce_log
fill 123 120 362 126 120 362 minecraft:stripped_spruce_log
fill 123 120 363 123 122 363 minecraft:stone
setblock 125 120 325 minecraft:light[level=12]
fill 125 120 330 125 120 331 minecraft:stripped_dark_oak_log
setblock 125 120 332 minecraft:light[level=12]
setblock 125 120 339 minecraft:light[level=12]
setblock 125 120 346 minecraft:light[level=12]
setblock 125 120 353 minecraft:light[level=12]
setblock 125 120 360 minecraft:light[level=12]
fill 126 120 330 126 122 330 minecraft:stripped_spruce_log
fill 126 120 331 126 121 332 minecraft:stripped_dark_oak_log
fill 127 120 323 127 120 363 minecraft:iron_bars
fill 128 120 328 130 120 328 minecraft:stripped_dark_oak_log
fill 128 120 329 129 122 332 minecraft:stripped_spruce_log
fill 128 120 333 129 120 333 minecraft:stripped_dark_oak_log
fill 128 120 362 131 120 362 minecraft:stripped_spruce_log
fill 130 120 323 131 120 323 minecraft:stone
fill 130 120 329 130 121 332 minecraft:stripped_dark_oak_log
fill 130 120 363 131 120 363 minecraft:stone
fill 131 120 328 131 121 329 minecraft:raw_gold_block
fill 131 120 330 131 120 331 minecraft:stripped_dark_oak_log
setblock 132 120 323 minecraft:stripped_spruce_log
fill 132 120 324 135 120 324 minecraft:stone
setblock 132 120 325 minecraft:light[level=12]
setblock 132 120 332 minecraft:light[level=12]
setblock 132 120 339 minecraft:light[level=12]
setblock 132 120 346 minecraft:light[level=12]
setblock 132 120 353 minecraft:light[level=12]
setblock 132 120 360 minecraft:light[level=12]
setblock 132 120 362 minecraft:stone
setblock 132 120 363 minecraft:stripped_spruce_log
fill 133 120 323 135 121 323 minecraft:stone
fill 133 120 333 133 122 333 minecraft:stone
setblock 133 120 336 minecraft:stone
setblock 133 120 337 minecraft:stripped_spruce_log
fill 133 120 338 133 122 338 minecraft:stone
setblock 133 120 342 minecraft:stripped_spruce_log
setblock 133 120 362 minecraft:stripped_spruce_log
fill 133 120 363 133 122 363 minecraft:stone
setblock 134 120 325 minecraft:stone
setblock 134 120 326 minecraft:stripped_spruce_log
fill 134 120 327 134 120 330 minecraft:stone
setblock 134 120 331 minecraft:stripped_spruce_log
fill 134 120 332 134 122 332 minecraft:stone
setblock 134 120 336 minecraft:stripped_spruce_log
fill 134 120 337 134 122 337 minecraft:stone
setblock 134 120 341 minecraft:stripped_spruce_log
fill 134 120 342 134 122 342 minecraft:stone
setblock 134 120 345 minecraft:stone
fill 134 120 358 134 120 360 minecraft:stone
setblock 134 120 361 minecraft:stripped_spruce_log
fill 134 120 362 134 122 362 minecraft:stone
fill 134 120 364 134 174 364 minecraft:deepslate
setblock 135 120 325 minecraft:stripped_spruce_log
fill 135 120 326 135 120 329 minecraft:stone
setblock 135 120 330 minecraft:stripped_spruce_log
fill 135 120 331 135 122 331 minecraft:stone
setblock 135 120 335 minecraft:stripped_spruce_log
fill 135 120 336 135 122 336 minecraft:stone
setblock 135 120 340 minecraft:stripped_spruce_log
fill 135 120 341 135 122 341 minecraft:stone
setblock 135 120 345 minecraft:stripped_spruce_log
fill 135 120 346 135 122 347 minecraft:stone
setblock 135 120 355 minecraft:stripped_spruce_log
fill 135 120 356 135 122 356 minecraft:stone
setblock 135 120 360 minecraft:stripped_spruce_log
fill 135 120 361 135 122 361 minecraft:stone
setblock 95 121 323 minecraft:stone
setblock 95 121 324 minecraft:stripped_spruce_log
fill 95 121 325 95 121 328 minecraft:stone
setblock 95 121 329 minecraft:stripped_spruce_log
fill 95 121 330 95 121 333 minecraft:stone
setblock 95 121 334 minecraft:stripped_spruce_log
fill 95 121 335 95 122 335 minecraft:stone
setblock 95 121 339 minecraft:stripped_spruce_log
fill 95 121 340 95 122 340 minecraft:stone
setblock 95 121 344 minecraft:stripped_spruce_log
fill 95 121 345 96 122 345 minecraft:stone
fill 95 121 347 95 121 348 minecraft:stone
setblock 95 121 349 minecraft:stripped_spruce_log
fill 95 121 350 95 121 353 minecraft:stone
setblock 95 121 354 minecraft:stripped_spruce_log
fill 95 121 355 95 122 355 minecraft:stone
setblock 95 121 359 minecraft:stripped_spruce_log
fill 95 121 360 95 122 360 minecraft:stone
setblock 96 121 323 minecraft:stripped_spruce_log
fill 96 121 324 96 122 324 minecraft:stone
setblock 96 121 328 minecraft:stripped_spruce_log
fill 96 121 329 96 122 329 minecraft:stone
setblock 96 121 333 minecraft:stripped_spruce_log
fill 96 121 334 96 122 334 minecraft:stone
setblock 96 121 338 minecraft:stripped_spruce_log
fill 96 121 339 96 122 339 minecraft:stone
setblock 96 121 343 minecraft:stripped_spruce_log
fill 96 121 344 96 122 344 minecraft:stone
fill 96 121 354 96 122 354 minecraft:stone
setblock 96 121 358 minecraft:stripped_spruce_log
fill 96 121 359 96 122 359 minecraft:stone
setblock 96 121 362 minecraft:stone
setblock 96 121 363 minecraft:stripped_spruce_log
fill 97 121 323 97 122 323 minecraft:stone
fill 97 121 325 97 122 325 minecraft:stone
setblock 97 121 357 minecraft:stripped_spruce_log
fill 97 121 358 97 122 358 minecraft:stone
fill 97 121 360 98 121 360 minecraft:stone
setblock 97 121 362 minecraft:stripped_spruce_log
fill 97 121 363 100 121 363 minecraft:stone
setblock 98 121 361 minecraft:stripped_spruce_log
fill 98 121 362 98 122 362 minecraft:stone
setblock 99 121 325 minecraft:iron_bars
setblock 99 121 360 minecraft:stripped_spruce_log
fill 99 121 361 99 122 361 minecraft:stone
setblock 100 121 324 minecraft:stripped_spruce_log
setblock 100 121 360 minecraft:stone
setblock 101 121 323 minecraft:stripped_spruce_log
fill 101 121 324 101 122 324 minecraft:stone
setblock 101 121 363 minecraft:stripped_spruce_log
fill 102 121 323 102 122 323 minecraft:stone
setblock 102 121 361 minecraft:stone
setblock 102 121 362 minecraft:stripped_spruce_log
fill 102 121 363 105 121 363 minecraft:stone
setblock 103 121 361 minecraft:stripped_spruce_log
fill 103 121 362 103 122 362 minecraft:stone
fill 104 121 361 104 122 361 minecraft:stone
setblock 105 121 323 minecraft:stone
fill 106 121 323 106 121 329 minecraft:iron_bars
setblock 106 121 363 minecraft:stripped_spruce_log
setblock 107 121 362 minecraft:stripped_spruce_log
fill 107 121 363 110 121 363 minecraft:stone
setblock 108 121 361 minecraft:stripped_spruce_log
fill 108 121 362 111 121 362 minecraft:stone
fill 109 121 323 110 121 323 minecraft:stone
fill 109 121 361 112 121 361 minecraft:stone
setblock 110 121 358 minecraft:stripped_spruce_log
setblock 110 121 360 minecraft:stripped_spruce_log
setblock 111 121 323 minecraft:stripped_spruce_log
setblock 111 121 363 minecraft:stripped_spruce_log
fill 112 121 323 115 121 323 minecraft:stone
setblock 112 121 358 minecraft:stripped_spruce_log
setblock 112 121 360 minecraft:stripped_spruce_log
setblock 112 121 362 minecraft:stripped_spruce_log
fill 112 121 363 115 121 363 minecraft:stone
setblock 113 121 360 minecraft:stone
setblock 113 121 361 minecraft:stripped_spruce_log
fill 113 121 362 113 122 362 minecraft:stone
setblock 114 121 360 minecraft:stripped_spruce_log
fill 114 121 361 114 122 361 minecraft:stone
fill 115 121 360 115 122 360 minecraft:stone
setblock 116 121 323 minecraft:stripped_spruce_log
setblock 116 121 363 minecraft:stripped_spruce_log
fill 117 121 323 117 122 323 minecraft:stone
setblock 117 121 362 minecraft:stripped_spruce_log
fill 117 121 363 117 122 363 minecraft:stone
setblock 118 121 361 minecraft:stripped_spruce_log
fill 118 121 362 118 122 362 minecraft:stone
setblock 119 121 361 minecraft:stone
fill 120 121 342 120 121 347 minecraft:iron_bars
setblock 121 121 323 minecraft:stripped_spruce_log
setblock 121 121 363 minecraft:stripped_spruce_log
fill 122 121 363 122 122 363 minecraft:stone
setblock 126 121 329 minecraft:stripped_dark_oak_log
fill 127 121 323 127 121 330 minecraft:iron_bars
fill 127 121 331 127 122 332 minecraft:stripped_spruce_log
fill 128 121 323 130 121 323 minecraft:stone
fill 128 121 328 129 121 328 minecraft:stripped_dark_oak_log
fill 128 121 363 130 121 363 minecraft:stone
setblock 130 121 328 minecraft:raw_gold_block
setblock 131 121 323 minecraft:stripped_spruce_log
fill 131 121 324 134 121 324 minecraft:stone
fill 131 121 327 132 121 327 minecraft:raw_gold_block
setblock 131 121 362 minecraft:stone
setblock 131 121 363 minecraft:stripped_spruce_log
fill 132 121 323 132 122 323 minecraft:stone
fill 132 121 339 133 122 339 minecraft:stone
setblock 132 121 362 minecraft:stripped_spruce_log
fill 132 121 363 132 122 363 minecraft:stone
setblock 133 121 328 minecraft:raw_gold_block
setblock 133 121 336 minecraft:stripped_spruce_log
fill 133 121 337 133 122 337 minecraft:stone
setblock 133 121 340 minecraft:stone
setblock 133 121 341 minecraft:stripped_spruce_log
fill 133 121 342 133 122 343 minecraft:stone
fill 133 121 362 133 122 362 minecraft:stone
setblock 134 121 325 minecraft:stripped_spruce_log
fill 134 121 326 134 121 329 minecraft:stone
setblock 134 121 330 minecraft:stripped_spruce_log
fill 134 121 331 134 122 331 minecraft:stone
setblock 134 121 335 minecraft:stripped_spruce_log
fill 134 121 336 134 122 336 minecraft:stone
setblock 134 121 340 minecraft:stripped_spruce_log
fill 134 121 341 134 122 341 minecraft:stone
setblock 134 121 345 minecraft:stripped_spruce_log
fill 134 121 346 134 122 346 minecraft:stone
fill 134 121 347 134 121 356 minecraft:iron_bars
fill 134 121 357 134 121 359 minecraft:stone
setblock 134 121 360 minecraft:stripped_spruce_log
fill 134 121 361 134 122 361 minecraft:stone
setblock 135 121 324 minecraft:stripped_spruce_log
fill 135 121 325 135 121 328 minecraft:stone
setblock 135 121 329 minecraft:stripped_spruce_log
fill 135 121 330 135 122 330 minecraft:stone
setblock 135 121 334 minecraft:stripped_spruce_log
fill 135 121 335 135 122 335 minecraft:stone
setblock 135 121 339 minecraft:stripped_spruce_log
fill 135 121 340 135 122 340 minecraft:stone
setblock 135 121 344 minecraft:stripped_spruce_log
fill 135 121 345 135 122 345 minecraft:stone
setblock 135 121 348 minecraft:stone
setblock 135 121 349 minecraft:stripped_spruce_log
setblock 135 121 354 minecraft:stripped_spruce_log
fill 135 121 355 135 122 355 minecraft:stone
setblock 135 121 359 minecraft:stripped_spruce_log
fill 135 121 360 135 122 360 minecraft:stone
setblock 136 121 357 minecraft:gold_block
setblock 94 122 337 minecraft:diamond_block
fill 94 122 338 94 133 340 minecraft:deepslate
setblock 94 122 341 minecraft:raw_iron_block
setblock 95 122 323 minecraft:stripped_spruce_log
fill 95 122 324 95 122 327 minecraft:stone
setblock 95 122 328 minecraft:stripped_spruce_log
fill 95 122 329 95 122 332 minecraft:stone
setblock 95 122 333 minecraft:stripped_spruce_log
setblock 95 122 334 minecraft:stone
setblock 95 122 338 minecraft:stripped_spruce_log
setblock 95 122 339 minecraft:stone
setblock 95 122 342 minecraft:stone
setblock 95 122 343 minecraft:stripped_spruce_log
setblock 95 122 344 minecraft:stone
setblock 95 122 347 minecraft:stone
setblock 95 122 348 minecraft:stripped_spruce_log
fill 95 122 349 95 122 352 minecraft:stone
setblock 95 122 353 minecraft:stripped_spruce_log
setblock 95 122 354 minecraft:stone
setblock 95 122 358 minecraft:stripped_spruce_log
setblock 95 122 359 minecraft:stone
fill 95 122 361 95 122 362 minecraft:stone
setblock 95 122 363 minecraft:stripped_spruce_log
setblock 96 122 323 minecraft:stone
setblock 96 122 327 minecraft:stripped_spruce_log
setblock 96 122 328 minecraft:stone
setblock 96 122 332 minecraft:stripped_spruce_log
setblock 96 122 333 minecraft:stone
setblock 96 122 337 minecraft:stripped_spruce_log
setblock 96 122 338 minecraft:stone
setblock 96 122 342 minecraft:stripped_spruce_log
setblock 96 122 343 minecraft:stone
setblock 96 122 346 minecraft:stone
setblock 96 122 357 minecraft:stripped_spruce_log
setblock 96 122 358 minecraft:stone
setblock 96 122 362 minecraft:stripped_spruce_log
fill 96 122 363 99 122 363 minecraft:stone
setblock 97 122 326 minecraft:stripped_spruce_log
setblock 97 122 333 minecraft:light[level=15]
setblock 97 122 341 minecraft:light[level=15]
setblock 97 122 349 minecraft:light[level=15]
setblock 97 122 357 minecraft:stone
setblock 97 122 360 minecraft:stone
setblock 97 122 361 minecraft:stripped_spruce_log
setblock 97 122 362 minecraft:stone
setblock 98 122 325 minecraft:stripped_spruce_log
setblock 98 122 360 minecraft:stripped_spruce_log
setblock 98 122 361 minecraft:stone
setblock 99 122 324 minecraft:stripped_spruce_log
setblock 99 122 360 minecraft:stone
setblock 100 122 323 minecraft:stripped_spruce_log
setblock 100 122 324 minecraft:stone
setblock 100 122 363 minecraft:stripped_spruce_log
setblock 101 122 323 minecraft:stone
setblock 101 122 362 minecraft:stripped_spruce_log
fill 101 122 363 104 122 363 minecraft:stone
setblock 102 122 361 minecraft:stripped_spruce_log
setblock 102 122 362 minecraft:stone
setblock 103 122 361 minecraft:stone
setblock 105 122 323 minecraft:stripped_spruce_log
setblock 105 122 325 minecraft:light[level=15]
setblock 105 122 333 minecraft:light[level=15]
setblock 105 122 341 minecraft:light[level=15]
setblock 105 122 349 minecraft:light[level=15]
setblock 105 122 357 minecraft:light[level=15]
fill 105 122 361 106 122 361 minecraft:stone
setblock 105 122 363 minecraft:stripped_spruce_log
fill 106 122 323 109 122 323 minecraft:stone
setblock 106 122 362 minecraft:stripped_spruce_log
fill 106 122 363 109 122 363 minecraft:stone
setblock 107 122 361 minecraft:stripped_spruce_log
fill 107 122 362 110 122 362 minecraft:stone
fill 108 122 322 108 174 322 minecraft:deepslate
fill 108 122 361 111 122 361 minecraft:stone
setblock 109 122 322 minecraft:raw_gold_block
setblock 110 122 323 minecraft:stripped_spruce_log
setblock 110 122 363 minecraft:stripped_spruce_log
fill 111 122 323 114 122 323 minecraft:stone
setblock 111 122 362 minecraft:stripped_spruce_log
fill 111 122 363 114 122 363 minecraft:stone
setblock 112 122 360 minecraft:stone
setblock 112 122 361 minecraft:stripped_spruce_log
setblock 112 122 362 minecraft:stone
setblock 113 122 324 minecraft:stone
setblock 113 122 325 minecraft:light[level=15]
setblock 113 122 333 minecraft:light[level=15]
setblock 113 122 341 minecraft:light[level=15]
setblock 113 122 349 minecraft:light[level=15]
setblock 113 122 357 minecraft:light[level=15]
setblock 113 122 360 minecraft:stripped_spruce_log
setblock 113 122 361 minecraft:stone
setblock 114 122 324 minecraft:stripped_spruce_log
setblock 114 122 360 minecraft:stone
setblock 115 122 323 minecraft:stripped_spruce_log
fill 115 122 324 117 122 324 minecraft:stone
setblock 115 122 363 minecraft:stripped_spruce_log
setblock 116 122 323 minecraft:stone
setblock 116 122 362 minecraft:stripped_spruce_log
setblock 116 122 363 minecraft:stone
setblock 117 122 361 minecraft:stripped_spruce_log
setblock 117 122 362 minecraft:stone
fill 118 122 323 119 122 323 minecraft:stone
setblock 118 122 361 minecraft:stone
setblock 120 122 323 minecraft:stripped_spruce_log
setblock 120 122 363 minecraft:stripped_spruce_log
fill 121 122 323 122 122 323 minecraft:stone
setblock 121 122 325 minecraft:light[level=15]
setblock 121 122 333 minecraft:light[level=15]
setblock 121 122 341 minecraft:light[level=15]
setblock 121 122 349 minecraft:light[level=15]
setblock 121 122 357 minecraft:light[level=15]
setblock 121 122 363 minecraft:stone
setblock 123 122 322 minecraft:raw_iron_block
setblock 124 122 363 minecraft:stone
fill 126 122 323 129 122 323 minecraft:stone
fill 126 122 363 129 122 363 minecraft:stone
fill 127 122 329 127 122 330 minecraft:stripped_spruce_log
setblock 129 122 324 minecraft:stripped_spruce_log
setblock 129 122 325 minecraft:light[level=15]
setblock 129 122 333 minecraft:light[level=15]
setblock 129 122 341 minecraft:light[level=15]
setblock 129 122 349 minecraft:light[level=15]
setblock 129 122 357 minecraft:light[level=15]
setblock 130 122 323 minecraft:stripped_spruce_log
fill 130 122 324 133 122 324 minecraft:stone
setblock 130 122 362 minecraft:stone
setblock 130 122 363 minecraft:stripped_spruce_log
setblock 131 122 323 minecraft:stone
setblock 131 122 362 minecraft:stripped_spruce_log
setblock 131 122 363 minecraft:stone
setblock 132 122 325 minecraft:stone
setblock 132 122 338 minecraft:stone
setblock 132 122 340 minecraft:stone
setblock 132 122 341 minecraft:stripped_spruce_log
setblock 132 122 362 minecraft:stone
fill 133 122 323 134 122 323 minecraft:stone
setblock 133 122 325 minecraft:stripped_spruce_log
fill 133 122 326 135 122 327 minecraft:stone
setblock 133 122 332 minecraft:stone
setblock 133 122 335 minecraft:stripped_spruce_log
setblock 133 122 336 minecraft:stone
setblock 133 122 340 minecraft:stripped_spruce_log
setblock 133 122 341 minecraft:stone
setblock 133 122 344 minecraft:stone
setblock 133 122 361 minecraft:stone
setblock 134 122 324 minecraft:stripped_spruce_log
fill 134 122 325 135 122 325 minecraft:stone
setblock 134 122 328 minecraft:stone
setblock 134 122 329 minecraft:stripped_spruce_log
setblock 134 122 330 minecraft:stone
setblock 134 122 334 minecraft:stripped_spruce_log
setblock 134 122 335 minecraft:stone
setblock 134 122 339 minecraft:stripped_spruce_log
setblock 134 122 340 minecraft:stone
setblock 134 122 343 minecraft:stone
setblock 134 122 344 minecraft:stripped_spruce_log
setblock 134 122 345 minecraft:stone
setblock 134 122 347 minecraft:stone
fill 134 122 357 134 122 358 minecraft:stone
setblock 134 122 359 minecraft:stripped_spruce_log
setblock 134 122 360 minecraft:stone
setblock 135 122 323 minecraft:stripped_spruce_log
setblock 135 122 324 minecraft:stone
setblock 135 122 328 minecraft:stripped_spruce_log
setblock 135 122 329 minecraft:stone
setblock 135 122 333 minecraft:stripped_spruce_log
setblock 135 122 334 minecraft:stone
setblock 135 122 338 minecraft:stripped_spruce_log
setblock 135 122 339 minecraft:stone
setblock 135 122 343 minecraft:stripped_spruce_log
setblock 135 122 344 minecraft:stone
setblock 135 122 348 minecraft:stripped_spruce_log
fill 135 122 349 135 122 350 minecraft:stone
setblock 135 122 353 minecraft:stripped_spruce_log
setblock 135 122 354 minecraft:stone
setblock 135 122 358 minecraft:stripped_spruce_log
setblock 135 122 359 minecraft:stone
setblock 135 122 363 minecraft:stripped_spruce_log
fill 136 122 357 136 161 357 minecraft:deepslate
fill 94 123 337 94 170 337 minecraft:deepslate
fill 94 123 341 94 170 341 minecraft:deepslate
fill 96 123 324 96 126 324 minecraft:spruce_log
fill 96 123 343 96 126 343 minecraft:spruce_log
fill 96 123 362 96 126 362 minecraft:spruce_log
fill 109 123 322 109 145 322 minecraft:deepslate
fill 115 123 324 115 126 324 minecraft:spruce_log
fill 115 123 362 115 126 362 minecraft:spruce_log
fill 123 123 322 123 175 322 minecraft:deepslate
fill 134 123 324 134 126 324 minecraft:spruce_log
fill 134 123 343 134 126 343 minecraft:spruce_log
fill 134 123 362 134 126 362 minecraft:spruce_log
setblock 94 124 333 minecraft:gold_block
fill 101 124 322 101 174 322 minecraft:deepslate
setblock 102 124 322 minecraft:gold_block
setblock 103 124 364 minecraft:diamond_block
fill 104 124 364 105 171 364 minecraft:deepslate
setblock 127 124 322 minecraft:raw_gold_block
setblock 136 124 341 minecraft:raw_iron_block
fill 94 125 326 94 174 326 minecraft:deepslate
setblock 94 125 327 minecraft:raw_iron_block
fill 94 125 328 94 142 328 minecraft:deepslate
fill 94 125 333 94 140 333 minecraft:deepslate
fill 102 125 322 102 132 322 minecraft:deepslate
fill 103 125 364 103 126 364 minecraft:deepslate
setblock 108 125 364 minecraft:raw_gold_block
fill 109 125 364 111 157 364 minecraft:deepslate
fill 127 125 322 127 174 322 minecraft:deepslate
fill 132 125 364 132 168 364 minecraft:deepslate
setblock 133 125 364 minecraft:diamond_block
fill 136 125 341 136 153 341 minecraft:deepslate
fill 94 126 327 94 137 327 minecraft:deepslate
fill 94 126 331 94 174 331 minecraft:deepslate
setblock 94 126 332 minecraft:diamond_block
fill 94 126 349 94 130 352 minecraft:deepslate
setblock 94 126 353 minecraft:raw_gold_block
setblock 97 126 325 minecraft:light[level=12]
setblock 97 126 332 minecraft:light[level=12]
setblock 97 126 339 minecraft:light[level=12]
setblock 97 126 346 minecraft:light[level=12]
setblock 97 126 353 minecraft:light[level=12]
setblock 97 126 360 minecraft:light[level=12]
setblock 104 126 325 minecraft:light[level=12]
setblock 104 126 332 minecraft:light[level=12]
setblock 104 126 339 minecraft:light[level=12]
setblock 104 126 346 minecraft:light[level=12]
setblock 104 126 353 minecraft:light[level=12]
setblock 104 126 360 minecraft:light[level=12]
fill 108 126 364 108 152 364 minecraft:deepslate
setblock 111 126 325 minecraft:light[level=12]
setblock 111 126 332 minecraft:light[level=12]
setblock 111 126 339 minecraft:light[level=12]
setblock 111 126 346 minecraft:light[level=12]
setblock 111 126 353 minecraft:light[level=12]
setblock 111 126 360 minecraft:light[level=12]
setblock 116 126 364 minecraft:raw_gold_block
setblock 118 126 325 minecraft:light[level=12]
setblock 118 126 332 minecraft:light[level=12]
setblock 118 126 339 minecraft:light[level=12]
setblock 118 126 346 minecraft:light[level=12]
setblock 118 126 353 minecraft:light[level=12]
setblock 118 126 360 minecraft:light[level=12]
setblock 125 126 325 minecraft:light[level=12]
setblock 125 126 332 minecraft:light[level=12]
setblock 125 126 339 minecraft:light[level=12]
setblock 125 126 346 minecraft:light[level=12]
setblock 125 126 353 minecraft:light[level=12]
setblock 125 126 360 minecraft:light[level=12]
setblock 132 126 325 minecraft:light[level=12]
setblock 132 126 332 minecraft:light[level=12]
setblock 132 126 339 minecraft:light[level=12]
setblock 132 126 346 minecraft:light[level=12]
setblock 132 126 353 minecraft:light[level=12]
setblock 132 126 360 minecraft:light[level=12]
fill 133 126 364 133 172 364 minecraft:deepslate
fill 94 127 332 94 174 332 minecraft:deepslate
setblock 94 127 348 minecraft:diamond_block
fill 94 127 353 94 133 353 minecraft:deepslate
setblock 96 127 324 minecraft:glowstone
setblock 96 127 343 minecraft:glowstone
setblock 96 127 362 minecraft:glowstone
setblock 103 127 364 minecraft:raw_gold_block
setblock 115 127 324 minecraft:glowstone
setblock 115 127 362 minecraft:glowstone
fill 116 127 364 116 170 364 minecraft:deepslate
setblock 128 127 364 minecraft:gold_block
setblock 134 127 324 minecraft:glowstone
setblock 134 127 343 minecraft:glowstone
setblock 134 127 362 minecraft:glowstone
setblock 136 127 327 minecraft:diamond_block
fill 136 127 344 136 174 344 minecraft:deepslate
setblock 136 127 345 minecraft:raw_iron_block
fill 136 127 346 136 139 350 minecraft:deepslate
fill 94 128 348 94 153 348 minecraft:deepslate
setblock 94 128 358 minecraft:raw_gold_block
fill 94 128 359 94 144 360 minecraft:deepslate
fill 96 128 324 96 129 324 minecraft:spruce_log
fill 96 128 343 96 129 343 minecraft:spruce_log
fill 96 128 362 96 129 362 minecraft:spruce_log
fill 103 128 364 103 174 364 minecraft:deepslate
fill 110 128 333 110 129 347 minecraft:iron_block
fill 111 128 333 124 129 333 minecraft:iron_block
fill 111 128 334 114 128 346 minecraft:spruce_planks
fill 111 128 347 124 129 347 minecraft:iron_block
fill 115 128 324 115 129 324 minecraft:spruce_log
fill 115 128 334 115 128 338 minecraft:spruce_planks
fill 115 128 342 115 128 346 minecraft:spruce_planks
fill 115 128 362 115 129 362 minecraft:spruce_log
fill 116 128 334 123 128 337 minecraft:spruce_planks
fill 116 128 343 123 128 346 minecraft:spruce_planks
fill 119 128 338 123 128 338 minecraft:spruce_planks
fill 119 128 342 123 128 342 minecraft:spruce_planks
fill 120 128 339 123 128 341 minecraft:spruce_planks
fill 124 128 334 124 129 346 minecraft:iron_block
fill 128 128 364 128 174 364 minecraft:deepslate
fill 134 128 324 134 129 324 minecraft:spruce_log
fill 134 128 343 134 129 343 minecraft:spruce_log
fill 134 128 362 134 129 362 minecraft:spruce_log
setblock 135 128 322 minecraft:raw_iron_block
fill 136 128 327 136 129 327 minecraft:deepslate
fill 136 128 345 136 134 345 minecraft:deepslate
fill 94 129 358 94 174 358 minecraft:deepslate
fill 95 129 323 95 129 363 minecraft:spruce_planks
fill 96 129 323 135 129 323 minecraft:spruce_planks
fill 96 129 325 96 129 342 minecraft:spruce_planks
fill 96 129 344 96 129 361 minecraft:spruce_planks
fill 96 129 363 135 129 363 minecraft:spruce_planks
fill 97 129 324 114 129 324 minecraft:spruce_planks
fill 97 129 325 100 129 361 minecraft:deepslate
fill 97 129 362 114 129 362 minecraft:spruce_planks
fill 101 129 325 101 129 361 minecraft:raw_gold_block
fill 102 129 325 107 129 361 minecraft:deepslate
fill 108 129 325 108 129 361 minecraft:raw_gold_block
fill 109 129 325 109 129 361 minecraft:deepslate
setblock 110 129 322 minecraft:gold_block
fill 110 129 325 114 129 332 minecraft:deepslate
fill 110 129 348 114 129 361 minecraft:deepslate
fill 111 129 334 113 129 346 minecraft:spruce_planks
fill 114 129 334 114 129 337 minecraft:spruce_planks
fill 114 129 338 114 129 342 minecraft:glowstone
fill 114 129 343 114 129 346 minecraft:spruce_planks
setblock 114 129 364 minecraft:raw_iron_block
fill 115 129 325 115 129 332 minecraft:raw_gold_block
fill 115 129 334 123 129 336 minecraft:spruce_planks
fill 115 129 337 115 129 338 minecraft:glowstone
fill 115 129 342 115 129 343 minecraft:glowstone
fill 115 129 344 123 129 346 minecraft:spruce_planks
fill 115 129 348 115 129 361 minecraft:raw_gold_block
fill 115 129 364 115 141 364 minecraft:deepslate
fill 116 129 324 133 129 324 minecraft:spruce_planks
fill 116 129 325 121 129 332 minecraft:deepslate
fill 116 129 337 119 129 337 minecraft:glowstone
fill 116 129 343 119 129 343 minecraft:glowstone
fill 116 129 348 121 129 361 minecraft:deepslate
fill 116 129 362 133 129 362 minecraft:spruce_planks
fill 119 129 338 120 129 338 minecraft:glowstone
fill 119 129 342 120 129 342 minecraft:glowstone
fill 120 129 337 123 129 337 minecraft:spruce_planks
fill 120 129 339 120 129 341 minecraft:glowstone
fill 120 129 343 123 129 343 minecraft:spruce_planks
fill 121 129 338 123 129 342 minecraft:spruce_planks
fill 122 129 325 122 129 332 minecraft:raw_gold_block
fill 122 129 348 122 129 361 minecraft:raw_gold_block
fill 123 129 325 128 129 332 minecraft:deepslate
fill 123 129 348 128 129 361 minecraft:deepslate
fill 125 129 333 128 129 347 minecraft:deepslate
fill 128 129 322 129 165 322 minecraft:deepslate
fill 129 129 325 129 129 361 minecraft:raw_gold_block
setblock 130 129 322 minecraft:raw_iron_block
fill 130 129 325 133 129 361 minecraft:deepslate
setblock 132 129 322 minecraft:gold_block
fill 134 129 325 135 129 342 minecraft:spruce_planks
fill 134 129 344 135 129 361 minecraft:spruce_planks
fill 135 129 322 135 163 322 minecraft:deepslate
setblock 135 129 324 minecraft:spruce_planks
setblock 135 129 343 minecraft:spruce_planks
setblock 135 129 362 minecraft:spruce_planks
setblock 94 130 355 minecraft:diamond_block
fill 94 130 356 94 143 356 minecraft:deepslate
setblock 97 130 325 minecraft:light[level=15]
setblock 97 130 333 minecraft:light[level=15]
setblock 97 130 341 minecraft:light[level=15]
setblock 97 130 349 minecraft:light[level=15]
setblock 97 130 357 minecraft:light[level=15]
setblock 105 130 325 minecraft:light[level=15]
setblock 105 130 333 minecraft:light[level=15]
setblock 105 130 341 minecraft:light[level=15]
setblock 105 130 349 minecraft:light[level=15]
setblock 105 130 357 minecraft:light[level=15]
fill 110 130 322 110 174 322 minecraft:deepslate
fill 110 130 333 110 149 333 minecraft:iron_bars
fill 110 130 347 110 149 347 minecraft:iron_bars
setblock 113 130 325 minecraft:light[level=15]
setblock 113 130 333 minecraft:light[level=15]
setblock 113 130 341 minecraft:light[level=15]
setblock 113 130 349 minecraft:light[level=15]
setblock 113 130 357 minecraft:light[level=15]
fill 114 130 364 114 174 364 minecraft:deepslate
setblock 121 130 325 minecraft:light[level=15]
setblock 121 130 333 minecraft:light[level=15]
setblock 121 130 341 minecraft:light[level=15]
setblock 121 130 349 minecraft:light[level=15]
setblock 121 130 357 minecraft:light[level=15]
fill 122 130 364 125 142 364 minecraft:deepslate
fill 124 130 333 124 149 333 minecraft:iron_bars
fill 124 130 347 124 149 347 minecraft:iron_bars
setblock 126 130 364 minecraft:raw_iron_block
fill 127 130 364 127 171 364 minecraft:deepslate
setblock 129 130 325 minecraft:light[level=15]
setblock 129 130 333 minecraft:light[level=15]
setblock 129 130 341 minecraft:light[level=15]
setblock 129 130 349 minecraft:light[level=15]
setblock 129 130 357 minecraft:light[level=15]
setblock 129 130 364 minecraft:raw_gold_block
fill 130 130 322 130 157 322 minecraft:deepslate
setblock 130 130 364 minecraft:deepslate
fill 132 130 322 132 174 322 minecraft:deepslate
setblock 136 130 327 minecraft:diamond_block
setblock 94 131 349 minecraft:diamond_block
fill 94 131 350 94 139 352 minecraft:deepslate
fill 94 131 355 94 174 355 minecraft:deepslate
fill 126 131 364 126 174 364 minecraft:deepslate
fill 129 131 364 129 134 364 minecraft:deepslate
setblock 130 131 364 minecraft:gold_block
fill 136 131 327 136 174 327 minecraft:deepslate
setblock 136 131 329 minecraft:raw_iron_block
fill 94 132 349 94 155 349 minecraft:deepslate
setblock 97 132 325 minecraft:light[level=12]
setblock 97 132 332 minecraft:light[level=12]
setblock 97 132 339 minecraft:light[level=12]
setblock 97 132 346 minecraft:light[level=12]
setblock 97 132 353 minecraft:light[level=12]
setblock 97 132 360 minecraft:light[level=12]
fill 104 132 322 104 174 322 minecraft:deepslate
setblock 104 132 325 minecraft:light[level=12]
setblock 104 132 332 minecraft:light[level=12]
setblock 104 132 339 minecraft:light[level=12]
setblock 104 132 346 minecraft:light[level=12]
setblock 104 132 353 minecraft:light[level=12]
setblock 104 132 360 minecraft:light[level=12]
setblock 105 132 322 minecraft:diamond_block
setblock 111 132 325 minecraft:light[level=12]
setblock 111 132 332 minecraft:light[level=12]
setblock 111 132 339 minecraft:light[level=12]
setblock 111 132 346 minecraft:light[level=12]
setblock 111 132 353 minecraft:light[level=12]
setblock 111 132 360 minecraft:light[level=12]
setblock 118 132 325 minecraft:light[level=12]
setblock 118 132 332 minecraft:light[level=12]
setblock 118 132 339 minecraft:light[level=12]
setblock 118 132 346 minecraft:light[level=12]
setblock 118 132 353 minecraft:light[level=12]
setblock 118 132 360 minecraft:light[level=12]
setblock 125 132 325 minecraft:light[level=12]
setblock 125 132 332 minecraft:light[level=12]
setblock 125 132 339 minecraft:light[level=12]
setblock 125 132 346 minecraft:light[level=12]
setblock 125 132 353 minecraft:light[level=12]
setblock 125 132 360 minecraft:light[level=12]
fill 130 132 364 130 174 364 minecraft:deepslate
setblock 132 132 325 minecraft:light[level=12]
setblock 132 132 332 minecraft:light[level=12]
setblock 132 132 339 minecraft:light[level=12]
setblock 132 132 346 minecraft:light[level=12]
setblock 132 132 353 minecraft:light[level=12]
setblock 132 132 360 minecraft:light[level=12]
fill 136 132 329 136 174 329 minecraft:deepslate
setblock 94 133 343 minecraft:raw_iron_block
fill 94 133 344 94 147 347 minecraft:deepslate
fill 95 133 323 95 133 326 minecraft:stone
setblock 95 133 327 minecraft:stripped_spruce_log
fill 95 133 328 95 135 329 minecraft:stone
fill 95 133 345 97 135 345 minecraft:cobbled_deepslate
setblock 95 133 346 minecraft:stone
setblock 95 133 347 minecraft:stripped_spruce_log
fill 95 133 348 95 133 351 minecraft:stone
setblock 95 133 352 minecraft:stripped_spruce_log
fill 95 133 353 95 133 356 minecraft:stone
setblock 95 133 357 minecraft:stripped_spruce_log
setblock 95 133 361 minecraft:stone
setblock 95 133 362 minecraft:stripped_spruce_log
fill 95 133 363 96 133 363 minecraft:stone
setblock 96 133 323 minecraft:stone
fill 96 133 344 96 135 344 minecraft:cobbled_deepslate
fill 96 133 346 96 135 346 minecraft:cobbled_deepslate
setblock 96 133 350 minecraft:stone
setblock 102 133 322 minecraft:gold_block
fill 105 133 322 105 155 322 minecraft:deepslate
fill 105 133 323 108 133 323 minecraft:stone
fill 105 133 363 108 133 363 minecraft:stone
setblock 109 133 323 minecraft:stripped_spruce_log
fill 109 133 324 110 135 324 minecraft:stone
setblock 109 133 363 minecraft:stripped_spruce_log
fill 110 133 323 113 133 323 minecraft:stone
fill 110 133 363 110 134 363 minecraft:stone
fill 122 133 323 123 133 323 minecraft:stone
setblock 123 133 324 minecraft:stripped_spruce_log
setblock 124 133 323 minecraft:stripped_spruce_log
fill 124 133 324 127 133 324 minecraft:stone
fill 125 133 323 128 133 323 minecraft:stone
fill 125 133 325 126 133 325 minecraft:stone
setblock 127 133 325 minecraft:stripped_spruce_log
fill 127 133 326 130 133 326 minecraft:stone
fill 127 133 363 128 133 363 minecraft:stone
setblock 128 133 324 minecraft:stripped_spruce_log
fill 128 133 325 131 133 325 minecraft:stone
setblock 129 133 323 minecraft:stripped_spruce_log
fill 129 133 324 132 133 324 minecraft:stone
setblock 129 133 363 minecraft:stripped_spruce_log
fill 130 133 323 133 133 323 minecraft:stone
fill 130 133 363 133 133 363 minecraft:stone
setblock 131 133 326 minecraft:stripped_spruce_log
fill 131 133 344 135 134 344 minecraft:raw_gold_block
setblock 132 133 325 minecraft:stripped_spruce_log
fill 132 133 326 133 133 328 minecraft:stone
fill 132 133 343 135 133 343 minecraft:raw_gold_block
fill 132 133 345 135 133 345 minecraft:raw_gold_block
setblock 133 133 324 minecraft:stripped_spruce_log
fill 133 133 325 135 134 325 minecraft:stone
setblock 133 133 329 minecraft:stripped_spruce_log
fill 133 133 330 135 134 330 minecraft:stone
setblock 134 133 323 minecraft:stripped_spruce_log
fill 134 133 324 135 135 324 minecraft:stone
fill 134 133 326 134 133 327 minecraft:stone
setblock 134 133 328 minecraft:stripped_spruce_log
fill 134 133 329 135 135 329 minecraft:stone
fill 134 133 331 135 133 331 minecraft:stone
setblock 134 133 363 minecraft:stripped_spruce_log
fill 135 133 323 135 136 323 minecraft:stone
setblock 135 133 326 minecraft:stone
setblock 135 133 327 minecraft:stripped_spruce_log
fill 135 133 328 135 136 328 minecraft:stone
setblock 135 133 332 minecraft:stripped_spruce_log
setblock 135 133 347 minecraft:stripped_spruce_log
fill 135 133 348 135 133 351 minecraft:stone
setblock 135 133 352 minecraft:stripped_spruce_log
fill 135 133 363 135 136 363 minecraft:stone
fill 94 134 338 94 174 338 minecraft:deepslate
setblock 94 134 339 minecraft:raw_iron_block
fill 94 134 340 94 174 340 minecraft:deepslate
fill 94 134 343 94 140 343 minecraft:deepslate
setblock 94 134 353 minecraft:diamond_block
fill 95 134 322 97 155 322 minecraft:deepslate
fill 95 134 323 95 134 325 minecraft:stone
setblock 95 134 326 minecraft:stripped_spruce_log
fill 95 134 327 95 137 327 minecraft:stone
setblock 95 134 330 minecraft:stone
fill 95 134 344 95 135 344 minecraft:cobbled_deepslate
setblock 95 134 346 minecraft:stripped_spruce_log
fill 95 134 347 95 134 350 minecraft:stone
setblock 95 134 351 minecraft:stripped_spruce_log
fill 95 134 352 95 134 355 minecraft:stone
setblock 95 134 356 minecraft:stripped_spruce_log
fill 95 134 357 95 134 360 minecraft:stone
setblock 95 134 361 minecraft:stripped_spruce_log
fill 95 134 362 95 136 363 minecraft:stone
setblock 96 134 349 minecraft:stone
setblock 96 134 350 minecraft:stripped_spruce_log
fill 96 134 351 96 135 353 minecraft:stone
fill 97 134 344 97 135 344 minecraft:cobbled_deepslate
fill 97 134 346 97 135 346 minecraft:cobbled_deepslate
setblock 98 134 322 minecraft:diamond_block
fill 102 134 322 102 174 322 minecraft:deepslate
fill 105 134 323 107 134 323 minecraft:stone
fill 105 134 363 107 134 363 minecraft:stone
setblock 108 134 323 minecraft:stripped_spruce_log
fill 108 134 324 108 136 324 minecraft:stone
setblock 108 134 363 minecraft:stripped_spruce_log
fill 109 134 323 112 134 323 minecraft:stone
fill 109 134 363 109 137 363 minecraft:stone
setblock 113 134 323 minecraft:stripped_spruce_log
setblock 116 134 322 minecraft:raw_iron_block
fill 117 134 322 117 137 322 minecraft:deepslate
fill 121 134 323 122 134 323 minecraft:stone
setblock 123 134 323 minecraft:stripped_spruce_log
fill 123 134 324 126 134 324 minecraft:stone
fill 124 134 323 127 134 323 minecraft:stone
fill 124 134 325 125 134 325 minecraft:stone
setblock 126 134 325 minecraft:stripped_spruce_log
fill 126 134 326 129 134 326 minecraft:stone
fill 126 134 363 127 134 363 minecraft:stone
setblock 127 134 324 minecraft:stripped_spruce_log
fill 127 134 325 130 134 325 minecraft:stone
setblock 128 134 323 minecraft:stripped_spruce_log
fill 128 134 324 131 134 324 minecraft:stone
setblock 128 134 363 minecraft:stripped_spruce_log
fill 129 134 323 132 134 323 minecraft:stone
fill 129 134 363 132 134 363 minecraft:stone
setblock 130 134 326 minecraft:stripped_spruce_log
fill 130 134 344 130 135 344 minecraft:raw_gold_block
setblock 131 134 325 minecraft:stripped_spruce_log
fill 131 134 326 134 134 326 minecraft:stone
setblock 132 134 324 minecraft:stripped_spruce_log
fill 132 134 325 132 137 325 minecraft:stone
fill 132 134 327 132 134 328 minecraft:stone
fill 132 134 343 134 134 343 minecraft:raw_gold_block
fill 132 134 345 134 134 345 minecraft:raw_gold_block
setblock 133 134 323 minecraft:stripped_spruce_log
fill 133 134 324 133 137 324 minecraft:stone
setblock 133 134 327 minecraft:stone
setblock 133 134 328 minecraft:stripped_spruce_log
fill 133 134 329 133 137 329 minecraft:stone
setblock 133 134 363 minecraft:stripped_spruce_log
fill 134 134 323 134 137 323 minecraft:stone
setblock 134 134 327 minecraft:stripped_spruce_log
fill 134 134 328 134 137 328 minecraft:stone
setblock 134 134 331 minecraft:stone
setblock 134 134 332 minecraft:stripped_spruce_log
fill 134 134 363 134 137 363 minecraft:stone
setblock 135 134 326 minecraft:stripped_spruce_log
fill 135 134 327 135 137 327 minecraft:stone
setblock 135 134 331 minecraft:stripped_spruce_log
fill 135 134 332 135 136 333 minecraft:stone
fill 135 134 348 135 134 350 minecraft:stone
setblock 135 134 351 minecraft:stripped_spruce_log
fill 135 134 352 135 135 354 minecraft:stone
fill 136 134 358 136 164 359 minecraft:deepslate
setblock 136 134 360 minecraft:diamond_block
fill 136 134 361 136 153 361 minecraft:deepslate
fill 94 135 339 94 174 339 minecraft:deepslate
setblock 94 135 353 minecraft:raw_iron_block
fill 95 135 323 95 135 324 minecraft:stone
setblock 95 135 325 minecraft:stripped_spruce_log
fill 95 135 326 95 137 326 minecraft:stone
fill 95 135 330 95 135 331 minecraft:stripped_spruce_log
fill 95 135 346 95 135 349 minecraft:stone
setblock 95 135 350 minecraft:stripped_spruce_log
fill 95 135 351 95 135 354 minecraft:stone
setblock 95 135 355 minecraft:stripped_spruce_log
fill 95 135 356 95 135 359 minecraft:stone
setblock 95 135 360 minecraft:stripped_spruce_log
fill 95 135 361 95 138 361 minecraft:stone
fill 96 135 331 101 136 331 minecraft:stripped_spruce_log
setblock 96 135 348 minecraft:stone
setblock 96 135 349 minecraft:stripped_spruce_log
fill 96 135 350 96 138 350 minecraft:stone
setblock 96 135 354 minecraft:stripped_spruce_log
fill 96 135 355 96 138 355 minecraft:stone
fill 98 135 322 98 174 322 minecraft:deepslate
fill 104 135 323 106 135 323 minecraft:stone
fill 104 135 363 106 135 363 minecraft:stone
setblock 107 135 323 minecraft:stripped_spruce_log
fill 107 135 324 107 137 324 minecraft:stone
setblock 107 135 363 minecraft:stripped_spruce_log
fill 108 135 323 111 135 323 minecraft:stone
fill 108 135 363 108 138 363 minecraft:stone
setblock 112 135 323 minecraft:stripped_spruce_log
setblock 113 135 323 minecraft:stone
setblock 115 135 322 minecraft:gold_block
fill 116 135 322 116 174 322 minecraft:deepslate
setblock 121 135 323 minecraft:stone
setblock 122 135 323 minecraft:stripped_spruce_log
fill 122 135 324 125 135 324 minecraft:stone
fill 123 135 323 126 135 323 minecraft:stone
fill 123 135 325 124 135 325 minecraft:stone
setblock 125 135 325 minecraft:stripped_spruce_log
fill 125 135 326 128 135 326 minecraft:stone
fill 125 135 363 126 135 363 minecraft:stone
setblock 126 135 324 minecraft:stripped_spruce_log
fill 126 135 325 129 135 325 minecraft:stone
setblock 127 135 323 minecraft:stripped_spruce_log
fill 127 135 324 130 135 324 minecraft:stone
setblock 127 135 363 minecraft:stripped_spruce_log
fill 128 135 323 131 135 323 minecraft:stone
fill 128 135 363 131 135 363 minecraft:stone
setblock 129 135 326 minecraft:stripped_spruce_log
setblock 129 135 364 minecraft:diamond_block
setblock 130 135 325 minecraft:stripped_spruce_log
fill 130 135 326 133 135 326 minecraft:stone
setblock 131 135 324 minecraft:stripped_spruce_log
fill 131 135 325 131 138 325 minecraft:stone
setblock 131 135 344 minecraft:raw_gold_block
setblock 132 135 323 minecraft:stripped_spruce_log
fill 132 135 324 132 138 324 minecraft:stone
setblock 132 135 327 minecraft:stone
setblock 132 135 328 minecraft:stripped_spruce_log
setblock 132 135 329 minecraft:stone
setblock 132 135 363 minecraft:stripped_spruce_log
fill 133 135 323 133 138 323 minecraft:stone
fill 133 135 325 134 135 325 minecraft:stone
setblock 133 135 327 minecraft:stripped_spruce_log
fill 133 135 328 133 137 328 minecraft:stone
fill 133 135 330 133 135 331 minecraft:stone
fill 133 135 363 133 138 363 minecraft:stone
setblock 134 135 326 minecraft:stripped_spruce_log
fill 134 135 327 134 138 327 minecraft:stone
setblock 134 135 330 minecraft:stone
setblock 134 135 331 minecraft:stripped_spruce_log
fill 134 135 332 134 138 332 minecraft:stone
setblock 135 135 325 minecraft:stripped_spruce_log
fill 135 135 326 135 138 326 minecraft:stone
setblock 135 135 330 minecraft:stripped_spruce_log
fill 135 135 331 135 138 331 minecraft:stone
fill 135 135 348 135 135 349 minecraft:stone
setblock 135 135 350 minecraft:stripped_spruce_log
fill 135 135 351 135 138 351 minecraft:stone
setblock 135 135 355 minecraft:stripped_spruce_log
fill 135 135 356 135 138 356 minecraft:stone
fill 135 135 362 135 137 362 minecraft:stone
setblock 136 135 345 minecraft:diamond_block
setblock 136 135 353 minecraft:raw_iron_block
fill 136 135 354 136 155 354 minecraft:deepslate
fill 136 135 360 136 163 360 minecraft:deepslate
fill 94 136 353 94 170 353 minecraft:deepslate
setblock 95 136 325 minecraft:stone
setblock 95 136 328 minecraft:stone
setblock 95 136 329 minecraft:stripped_spruce_log
fill 95 136 330 95 138 331 minecraft:stone
fill 95 136 346 95 136 348 minecraft:stone
setblock 95 136 349 minecraft:stripped_spruce_log
fill 95 136 350 95 136 353 minecraft:stone
setblock 95 136 354 minecraft:stripped_spruce_log
fill 95 136 355 95 136 358 minecraft:stone
setblock 95 136 359 minecraft:stripped_spruce_log
fill 95 136 360 95 139 360 minecraft:stone
fill 96 136 330 101 136 330 minecraft:stripped_spruce_log
setblock 96 136 348 minecraft:stripped_spruce_log
fill 96 136 349 96 139 349 minecraft:stone
fill 96 136 351 96 136 352 minecraft:stone
setblock 96 136 353 minecraft:stripped_spruce_log
fill 96 136 354 96 139 354 minecraft:stone
fill 96 136 356 96 137 356 minecraft:stone
fill 102 136 331 110 136 332 minecraft:stripped_spruce_log
fill 103 136 363 105 136 363 minecraft:stone
fill 104 136 323 105 136 323 minecraft:stone
setblock 106 136 323 minecraft:stripped_spruce_log
setblock 106 136 363 minecraft:stripped_spruce_log
fill 107 136 323 110 136 323 minecraft:stone
fill 107 136 363 107 139 363 minecraft:stone
setblock 109 136 324 minecraft:stone
setblock 111 136 323 minecraft:stripped_spruce_log
fill 111 136 331 113 137 331 minecraft:stripped_spruce_log
setblock 112 136 323 minecraft:stone
fill 115 136 322 115 172 322 minecraft:deepslate
setblock 120 136 323 minecraft:stone
setblock 121 136 323 minecraft:stripped_spruce_log
fill 121 136 324 124 136 324 minecraft:stone
fill 122 136 323 125 136 323 minecraft:stone
setblock 123 136 325 minecraft:stone
setblock 124 136 325 minecraft:stripped_spruce_log
fill 124 136 326 127 136 326 minecraft:stone
fill 124 136 363 125 136 363 minecraft:stone
setblock 125 136 324 minecraft:stripped_spruce_log
fill 125 136 325 128 136 325 minecraft:stone
setblock 126 136 323 minecraft:stripped_spruce_log
fill 126 136 324 129 136 324 minecraft:stone
setblock 126 136 363 minecraft:stripped_spruce_log
fill 127 136 323 130 136 323 minecraft:stone
setblock 127 136 327 minecraft:stripped_spruce_log
fill 127 136 363 130 136 363 minecraft:stone
setblock 128 136 326 minecraft:stripped_spruce_log
setblock 128 136 327 minecraft:stone
fill 128 136 362 130 137 362 minecraft:stone
setblock 129 136 325 minecraft:stripped_spruce_log
fill 129 136 326 131 136 326 minecraft:stone
fill 129 136 364 129 171 364 minecraft:deepslate
setblock 130 136 324 minecraft:stripped_spruce_log
fill 130 136 325 130 139 325 minecraft:stone
setblock 131 136 323 minecraft:stripped_spruce_log
fill 131 136 324 131 139 324 minecraft:stone
setblock 131 136 363 minecraft:stripped_spruce_log
fill 132 136 323 132 139 323 minecraft:stone
setblock 132 136 328 minecraft:stone
fill 132 136 363 132 139 363 minecraft:stone
setblock 133 136 325 minecraft:stone
setblock 133 136 326 minecraft:stripped_spruce_log
fill 133 136 327 133 137 327 minecraft:stone
setblock 133 136 330 minecraft:stone
setblock 133 136 331 minecraft:stripped_spruce_log
setblock 134 136 324 minecraft:stone
setblock 134 136 325 minecraft:stripped_spruce_log
fill 134 136 326 134 138 326 minecraft:stone
setblock 134 136 329 minecraft:stone
setblock 134 136 330 minecraft:stripped_spruce_log
fill 134 136 331 134 139 331 minecraft:stone
fill 134 136 351 134 137 353 minecraft:stone
setblock 135 136 324 minecraft:stripped_spruce_log
fill 135 136 325 135 139 325 minecraft:stone
setblock 135 136 329 minecraft:stripped_spruce_log
fill 135 136 330 135 139 330 minecraft:stone
setblock 135 136 334 minecraft:stripped_spruce_log
setblock 135 136 348 minecraft:stone
setblock 135 136 349 minecraft:stripped_spruce_log
fill 135 136 350 135 139 350 minecraft:stone
fill 135 136 352 135 136 353 minecraft:stone
setblock 135 136 354 minecraft:stripped_spruce_log
fill 135 136 355 135 139 355 minecraft:stone
fill 135 136 357 135 136 358 minecraft:stone
setblock 135 136 359 minecraft:stripped_spruce_log
fill 136 136 345 136 174 345 minecraft:deepslate
fill 136 136 353 136 172 353 minecraft:deepslate
setblock 94 137 361 minecraft:diamond_block
setblock 95 137 328 minecraft:stripped_spruce_log
fill 95 137 329 95 138 329 minecraft:stone
setblock 95 137 332 minecraft:stone
fill 95 137 346 95 137 347 minecraft:stone
setblock 95 137 348 minecraft:stripped_spruce_log
fill 95 137 349 95 137 352 minecraft:stone
setblock 95 137 353 minecraft:stripped_spruce_log
fill 95 137 354 95 137 357 minecraft:stone
setblock 95 137 358 minecraft:stripped_spruce_log
fill 95 137 359 95 140 359 minecraft:stone
setblock 95 137 362 minecraft:stone
fill 96 137 331 101 137 331 minecraft:stripped_dark_oak_log
setblock 96 137 348 minecraft:stone
setblock 96 137 351 minecraft:stone
setblock 96 137 352 minecraft:stripped_spruce_log
fill 96 137 353 97 139 353 minecraft:stone
setblock 96 137 357 minecraft:stripped_spruce_log
fill 97 137 352 97 140 352 minecraft:stone
fill 102 137 331 110 137 331 minecraft:stripped_spruce_log
fill 102 137 363 104 137 363 minecraft:stone
fill 103 137 323 104 137 323 minecraft:stone
setblock 105 137 323 minecraft:stripped_spruce_log
setblock 105 137 363 minecraft:stripped_spruce_log
fill 106 137 323 109 137 323 minecraft:stone
fill 106 137 363 106 140 363 minecraft:stone
fill 107 137 332 127 137 332 minecraft:stripped_spruce_log
setblock 110 137 323 minecraft:stripped_spruce_log
setblock 111 137 323 minecraft:stone
fill 114 137 331 123 137 331 minecraft:stripped_spruce_log
setblock 120 137 323 minecraft:stripped_spruce_log
fill 121 137 323 123 137 324 minecraft:stone
setblock 122 137 325 minecraft:stone
setblock 123 137 325 minecraft:stripped_spruce_log
setblock 124 137 323 minecraft:stone
setblock 124 137 324 minecraft:stripped_spruce_log
fill 124 137 325 126 137 326 minecraft:stone
setblock 124 137 363 minecraft:stone
setblock 125 137 323 minecraft:stripped_spruce_log
fill 125 137 324 128 137 324 minecraft:stone
setblock 125 137 363 minecraft:stripped_spruce_log
fill 126 137 323 129 137 323 minecraft:stone
fill 126 137 363 129 137 363 minecraft:stone
setblock 127 137 325 minecraft:stone
setblock 127 137 326 minecraft:stripped_spruce_log
setblock 127 137 327 minecraft:stone
fill 127 137 362 127 140 362 minecraft:stone
setblock 128 137 325 minecraft:stripped_spruce_log
fill 128 137 326 130 137 326 minecraft:stone
setblock 129 137 324 minecraft:stripped_spruce_log
fill 129 137 325 129 139 325 minecraft:stone
setblock 130 137 323 minecraft:stripped_spruce_log
fill 130 137 324 130 140 324 minecraft:stone
setblock 130 137 363 minecraft:stripped_spruce_log
fill 131 137 323 131 140 323 minecraft:stone
fill 131 137 363 131 140 363 minecraft:stone
setblock 133 137 326 minecraft:stone
setblock 133 137 330 minecraft:stripped_spruce_log
setblock 133 137 331 minecraft:stone
setblock 134 137 324 minecraft:stripped_spruce_log
fill 134 137 325 134 138 325 minecraft:stone
setblock 134 137 329 minecraft:stripped_spruce_log
fill 134 137 330 134 139 330 minecraft:stone
setblock 134 137 354 minecraft:stripped_spruce_log
fill 134 137 355 134 140 355 minecraft:stone
setblock 135 137 323 minecraft:stripped_spruce_log
fill 135 137 324 135 139 324 minecraft:stone
setblock 135 137 328 minecraft:stripped_spruce_log
fill 135 137 329 135 140 329 minecraft:stone
setblock 135 137 332 minecraft:stone
setblock 135 137 333 minecraft:stripped_spruce_log
fill 135 137 334 135 140 334 minecraft:stone
setblock 135 137 348 minecraft:stripped_spruce_log
fill 135 137 349 135 138 349 minecraft:stone
setblock 135 137 352 minecraft:stone
setblock 135 137 353 minecraft:stripped_spruce_log
fill 135 137 354 135 140 354 minecraft:stone
setblock 135 137 357 minecraft:stone
setblock 135 137 358 minecraft:stripped_spruce_log
fill 135 137 359 135 138 361 minecraft:stone
setblock 135 137 363 minecraft:stripped_spruce_log
setblock 94 138 327 minecraft:gold_block
fill 94 138 361 94 167 361 minecraft:deepslate
setblock 95 138 328 minecraft:stone
setblock 95 138 332 minecraft:stripped_spruce_log
setblock 95 138 347 minecraft:stripped_spruce_log
fill 95 138 348 95 138 351 minecraft:stone
setblock 95 138 352 minecraft:stripped_spruce_log
fill 95 138 353 95 138 356 minecraft:stone
setblock 95 138 357 minecraft:stripped_spruce_log
fill 95 138 358 96 140 358 minecraft:stone
setblock 96 138 351 minecraft:stripped_spruce_log
fill 96 138 352 96 141 352 minecraft:stone
setblock 96 138 356 minecraft:stripped_spruce_log
fill 96 138 357 96 141 357 minecraft:stone
setblock 97 138 325 minecraft:light[level=15]
setblock 97 138 332 minecraft:light[level=12]
setblock 97 138 333 minecraft:light[level=15]
setblock 97 138 339 minecraft:light[level=12]
setblock 97 138 341 minecraft:light[level=15]
setblock 97 138 346 minecraft:light[level=12]
setblock 97 138 349 minecraft:light[level=15]
setblock 97 138 351 minecraft:stone
setblock 97 138 354 minecraft:stone
setblock 97 138 357 minecraft:light[level=15]
setblock 97 138 360 minecraft:light[level=12]
fill 102 138 331 114 138 331 minecraft:stripped_dark_oak_log
fill 102 138 363 103 138 363 minecraft:stone
setblock 104 138 323 minecraft:stripped_spruce_log
setblock 104 138 325 minecraft:light[level=12]
setblock 104 138 332 minecraft:light[level=12]
setblock 104 138 339 minecraft:light[level=12]
setblock 104 138 346 minecraft:light[level=12]
setblock 104 138 353 minecraft:light[level=12]
setblock 104 138 360 minecraft:light[level=12]
setblock 104 138 363 minecraft:stripped_spruce_log
fill 105 138 323 108 138 323 minecraft:stone
setblock 105 138 325 minecraft:light[level=15]
setblock 105 138 333 minecraft:light[level=15]
setblock 105 138 341 minecraft:light[level=15]
setblock 105 138 349 minecraft:light[level=15]
setblock 105 138 357 minecraft:light[level=15]
fill 105 138 363 105 141 363 minecraft:stone
setblock 109 138 323 minecraft:stripped_spruce_log
setblock 110 138 323 minecraft:stone
setblock 111 138 325 minecraft:light[level=12]
setblock 111 138 332 minecraft:light[level=12]
setblock 111 138 339 minecraft:light[level=12]
setblock 111 138 346 minecraft:light[level=12]
setblock 111 138 353 minecraft:light[level=12]
setblock 111 138 360 minecraft:light[level=12]
setblock 113 138 325 minecraft:light[level=15]
setblock 113 138 333 minecraft:light[level=15]
setblock 113 138 341 minecraft:light[level=15]
setblock 113 138 349 minecraft:light[level=15]
setblock 113 138 357 minecraft:light[level=15]
fill 116 138 331 131 138 331 minecraft:stripped_spruce_log
setblock 117 138 322 minecraft:raw_gold_block
fill 117 138 332 133 138 332 minecraft:stripped_spruce_log
setblock 118 138 325 minecraft:light[level=12]
setblock 118 138 339 minecraft:light[level=12]
setblock 118 138 346 minecraft:light[level=12]
setblock 118 138 353 minecraft:light[level=12]
setblock 118 138 360 minecraft:light[level=12]
fill 120 138 323 123 138 323 minecraft:stone
fill 121 138 324 122 138 324 minecraft:stone
setblock 121 138 325 minecraft:light[level=15]
setblock 121 138 333 minecraft:light[level=15]
setblock 121 138 341 minecraft:light[level=15]
setblock 121 138 349 minecraft:light[level=15]
setblock 121 138 357 minecraft:light[level=15]
setblock 122 138 325 minecraft:stripped_spruce_log
setblock 123 138 324 minecraft:stripped_spruce_log
fill 123 138 325 126 138 325 minecraft:stone
setblock 123 138 363 minecraft:stone
setblock 124 138 323 minecraft:stripped_spruce_log
fill 124 138 324 127 138 324 minecraft:stone
fill 124 138 326 125 138 326 minecraft:stone
setblock 124 138 363 minecraft:stripped_spruce_log
fill 125 138 323 128 138 323 minecraft:stone
setblock 125 138 339 minecraft:light[level=12]
setblock 125 138 346 minecraft:light[level=12]
setblock 125 138 353 minecraft:light[level=12]
setblock 125 138 360 minecraft:light[level=12]
fill 125 138 363 128 138 363 minecraft:stone
setblock 126 138 326 minecraft:stripped_spruce_log
fill 126 138 362 126 141 362 minecraft:stone
setblock 127 138 325 minecraft:stripped_spruce_log
fill 127 138 326 129 138 326 minecraft:stone
setblock 128 138 324 minecraft:stripped_spruce_log
fill 128 138 325 128 140 325 minecraft:stone
fill 128 138 362 129 138 362 minecraft:stone
setblock 129 138 323 minecraft:stripped_spruce_log
fill 129 138 324 129 141 324 minecraft:stone
setblock 129 138 333 minecraft:light[level=15]
setblock 129 138 341 minecraft:light[level=15]
setblock 129 138 349 minecraft:light[level=15]
setblock 129 138 357 minecraft:light[level=15]
setblock 129 138 363 minecraft:stripped_spruce_log
fill 130 138 323 130 141 323 minecraft:stone
setblock 130 138 362 minecraft:stripped_spruce_log
fill 130 138 363 130 141 363 minecraft:stone
setblock 132 138 325 minecraft:light[level=12]
setblock 132 138 339 minecraft:light[level=12]
setblock 132 138 346 minecraft:light[level=12]
setblock 132 138 353 minecraft:light[level=12]
setblock 132 138 360 minecraft:light[level=12]
setblock 133 138 324 minecraft:stripped_spruce_log
setblock 133 138 329 minecraft:stripped_spruce_log
setblock 134 138 323 minecraft:stripped_spruce_log
setblock 134 138 328 minecraft:stripped_spruce_log
fill 134 138 329 134 139 329 minecraft:stone
setblock 134 138 352 minecraft:stone
setblock 134 138 353 minecraft:stripped_spruce_log
fill 134 138 354 134 141 354 minecraft:stone
fill 134 138 356 134 138 357 minecraft:stone
setblock 134 138 363 minecraft:stripped_spruce_log
setblock 135 138 323 minecraft:stone
setblock 135 138 327 minecraft:stripped_spruce_log
fill 135 138 328 135 140 328 minecraft:stone
setblock 135 138 332 minecraft:stripped_spruce_log
fill 135 138 333 135 140 333 minecraft:stone
setblock 135 138 352 minecraft:stripped_spruce_log
fill 135 138 353 135 141 353 minecraft:stone
setblock 135 138 357 minecraft:stripped_spruce_log
fill 135 138 358 135 141 358 minecraft:stone
setblock 135 138 362 minecraft:stripped_spruce_log
fill 135 138 363 135 139 363 minecraft:stone
fill 136 138 324 136 174 324 minecraft:deepslate
setblock 136 138 325 minecraft:raw_iron_block
fill 136 138 326 136 174 326 minecraft:deepslate
fill 94 139 327 94 174 327 minecraft:deepslate
setblock 95 139 331 minecraft:stripped_spruce_log
fill 95 139 347 95 139 350 minecraft:stone
setblock 95 139 351 minecraft:stripped_spruce_log
fill 95 139 352 95 139 355 minecraft:stone
setblock 95 139 356 minecraft:stripped_spruce_log
fill 95 139 357 95 142 357 minecraft:stone
setblock 95 139 361 minecraft:stripped_spruce_log
fill 96 139 324 96 142 324 minecraft:spruce_log
fill 96 139 343 96 142 343 minecraft:spruce_log
setblock 96 139 350 minecraft:stripped_spruce_log
fill 96 139 351 96 142 351 minecraft:stone
setblock 96 139 355 minecraft:stripped_spruce_log
fill 96 139 356 96 142 356 minecraft:stone
fill 96 139 362 96 142 362 minecraft:spruce_log
setblock 97 139 354 minecraft:stripped_spruce_log
fill 97 139 355 97 141 355 minecraft:stone
fill 101 139 363 102 139 363 minecraft:stone
setblock 103 139 363 minecraft:stripped_spruce_log
fill 104 139 323 107 139 323 minecraft:stone
fill 104 139 363 104 142 363 minecraft:stone
setblock 108 139 323 minecraft:stripped_spruce_log
fill 115 139 324 115 142 324 minecraft:spruce_log
fill 115 139 362 115 142 362 minecraft:spruce_log
fill 117 139 322 117 145 322 minecraft:deepslate
fill 119 139 332 127 139 332 minecraft:stripped_dark_oak_log
fill 120 139 323 122 139 323 minecraft:stone
setblock 121 139 324 minecraft:stone
setblock 122 139 324 minecraft:stripped_spruce_log
fill 122 139 325 125 139 325 minecraft:stone
setblock 123 139 323 minecraft:stripped_spruce_log
fill 123 139 324 126 139 324 minecraft:stone
setblock 123 139 363 minecraft:stripped_spruce_log
fill 124 139 323 127 139 323 minecraft:stone
setblock 124 139 326 minecraft:stone
fill 124 139 363 127 139 363 minecraft:stone
setblock 125 139 326 minecraft:stripped_spruce_log
fill 125 139 362 125 142 362 minecraft:stone
setblock 126 139 325 minecraft:stripped_spruce_log
fill 126 139 326 128 139 326 minecraft:stone
setblock 127 139 324 minecraft:stripped_spruce_log
fill 127 139 325 127 140 325 minecraft:stone
setblock 128 139 323 minecraft:stripped_spruce_log
fill 128 139 324 128 142 324 minecraft:stone
fill 128 139 332 134 139 332 minecraft:stripped_spruce_log
setblock 128 139 362 minecraft:stone
setblock 128 139 363 minecraft:stripped_spruce_log
fill 129 139 323 129 142 323 minecraft:stone
setblock 129 139 362 minecraft:stripped_spruce_log
fill 129 139 363 129 142 363 minecraft:stone
setblock 130 139 362 minecraft:stone
setblock 132 139 324 minecraft:stripped_spruce_log
setblock 133 139 323 minecraft:stripped_spruce_log
setblock 133 139 363 minecraft:stripped_spruce_log
setblock 134 139 323 minecraft:stone
fill 134 139 324 134 142 324 minecraft:spruce_log
setblock 134 139 328 minecraft:stone
fill 134 139 343 134 142 343 minecraft:spruce_log
setblock 134 139 352 minecraft:stripped_spruce_log
fill 134 139 353 134 140 353 minecraft:stone
setblock 134 139 356 minecraft:stone
setblock 134 139 357 minecraft:stripped_spruce_log
fill 134 139 362 134 142 362 minecraft:spruce_log
fill 134 139 363 134 140 363 minecraft:stone
setblock 135 139 326 minecraft:stripped_spruce_log
fill 135 139 327 135 140 327 minecraft:stone
setblock 135 139 331 minecraft:stripped_spruce_log
fill 135 139 332 135 141 332 minecraft:stone
setblock 135 139 351 minecraft:stripped_spruce_log
fill 135 139 352 135 142 352 minecraft:stone
setblock 135 139 356 minecraft:stripped_spruce_log
fill 135 139 357 135 142 357 minecraft:stone
fill 135 139 359 135 139 360 minecraft:stone
setblock 135 139 361 minecraft:stripped_spruce_log
fill 135 139 362 135 142 362 minecraft:stone
fill 136 139 325 136 150 325 minecraft:deepslate
setblock 94 140 336 minecraft:diamond_block
setblock 94 140 350 minecraft:deepslate
setblock 94 140 351 minecraft:gold_block
fill 94 140 352 94 174 352 minecraft:deepslate
fill 95 140 348 95 140 349 minecraft:stone
setblock 95 140 350 minecraft:stripped_spruce_log
fill 95 140 351 95 140 354 minecraft:stone
setblock 95 140 355 minecraft:stripped_spruce_log
fill 95 140 356 95 143 356 minecraft:stone
setblock 95 140 360 minecraft:stripped_spruce_log
fill 95 140 361 95 143 361 minecraft:stone
fill 96 140 347 96 144 347 minecraft:stripped_spruce_log
setblock 96 140 350 minecraft:stone
setblock 96 140 353 minecraft:stone
setblock 96 140 354 minecraft:stripped_spruce_log
fill 96 140 355 96 143 355 minecraft:stone
setblock 97 140 353 minecraft:stripped_spruce_log
fill 97 140 354 97 141 354 minecraft:stone
setblock 99 140 322 minecraft:raw_gold_block
fill 100 140 322 100 172 322 minecraft:deepslate
setblock 101 140 363 minecraft:stone
setblock 102 140 363 minecraft:stripped_spruce_log
fill 103 140 363 103 143 363 minecraft:stone
setblock 107 140 363 minecraft:stripped_spruce_log
fill 120 140 323 121 140 323 minecraft:stone
setblock 121 140 324 minecraft:stripped_spruce_log
setblock 122 140 323 minecraft:stripped_spruce_log
fill 122 140 324 125 140 324 minecraft:stone
setblock 122 140 363 minecraft:stripped_spruce_log
fill 123 140 323 126 140 323 minecraft:stone
fill 123 140 325 124 140 325 minecraft:stone
fill 123 140 363 126 140 363 minecraft:stone
setblock 125 140 325 minecraft:stripped_spruce_log
setblock 126 140 324 minecraft:stripped_spruce_log
fill 126 140 325 126 141 325 minecraft:stone
setblock 127 140 323 minecraft:stripped_spruce_log
fill 127 140 324 127 142 324 minecraft:stone
setblock 127 140 363 minecraft:stripped_spruce_log
fill 128 140 323 128 143 323 minecraft:stone
setblock 128 140 362 minecraft:stripped_spruce_log
fill 128 140 363 128 143 363 minecraft:stone
fill 129 140 332 134 140 332 minecraft:stripped_dark_oak_log
fill 129 140 362 129 141 362 minecraft:stone
setblock 132 140 323 minecraft:stripped_spruce_log
setblock 132 140 363 minecraft:stripped_spruce_log
setblock 133 140 323 minecraft:stone
fill 133 140 363 133 141 363 minecraft:stone
setblock 134 140 356 minecraft:stripped_spruce_log
fill 134 140 357 134 142 357 minecraft:stone
setblock 135 140 330 minecraft:stripped_spruce_log
fill 135 140 331 135 141 331 minecraft:stone
setblock 135 140 350 minecraft:stripped_spruce_log
fill 135 140 351 135 141 351 minecraft:stone
setblock 135 140 355 minecraft:stripped_spruce_log
fill 135 140 356 135 143 356 minecraft:stone
setblock 135 140 359 minecraft:stone
setblock 135 140 360 minecraft:stripped_spruce_log
fill 135 140 361 135 143 361 minecraft:stone
fill 136 140 346 136 174 346 minecraft:deepslate
setblock 136 140 347 minecraft:gold_block
fill 136 140 348 136 155 350 minecraft:deepslate
fill 94 141 329 94 166 329 minecraft:deepslate
setblock 94 141 330 minecraft:raw_gold_block
setblock 94 141 333 minecraft:raw_iron_block
fill 94 141 336 94 161 336 minecraft:deepslate
setblock 94 141 343 minecraft:diamond_block
setblock 94 141 350 minecraft:diamond_block
fill 94 141 351 94 175 351 minecraft:deepslate
setblock 95 141 349 minecraft:stripped_spruce_log
fill 95 141 350 95 141 353 minecraft:stone
setblock 95 141 354 minecraft:stripped_spruce_log
fill 95 141 355 95 144 355 minecraft:stone
setblock 95 141 358 minecraft:stone
setblock 95 141 359 minecraft:stripped_spruce_log
fill 95 141 360 95 144 360 minecraft:stone
setblock 96 141 353 minecraft:stripped_spruce_log
fill 96 141 354 96 144 354 minecraft:stone
setblock 96 141 358 minecraft:stripped_spruce_log
setblock 97 141 353 minecraft:stone
fill 99 141 322 99 170 322 minecraft:deepslate
setblock 101 141 363 minecraft:stripped_spruce_log
fill 102 141 363 102 144 363 minecraft:stone
setblock 106 141 363 minecraft:stripped_spruce_log
setblock 120 141 323 minecraft:stone
setblock 121 141 323 minecraft:stripped_spruce_log
fill 121 141 324 124 141 324 minecraft:stone
fill 122 141 323 125 141 323 minecraft:stone
fill 122 141 363 125 141 363 minecraft:stone
setblock 124 141 325 minecraft:stripped_spruce_log
fill 124 141 362 124 143 362 minecraft:stone
setblock 125 141 324 minecraft:stripped_spruce_log
setblock 125 141 325 minecraft:stone
setblock 126 141 323 minecraft:stripped_spruce_log
fill 126 141 324 126 143 324 minecraft:stone
setblock 126 141 363 minecraft:stripped_spruce_log
fill 127 141 323 127 144 323 minecraft:stone
setblock 127 141 362 minecraft:stripped_spruce_log
fill 127 141 363 127 144 363 minecraft:stone
fill 128 141 362 128 144 362 minecraft:stone
setblock 131 141 323 minecraft:stripped_spruce_log
setblock 131 141 363 minecraft:stripped_spruce_log
fill 132 141 363 132 142 363 minecraft:stone
setblock 134 141 355 minecraft:stripped_spruce_log
fill 134 141 356 134 142 356 minecraft:stone
setblock 135 141 354 minecraft:stripped_spruce_log
fill 135 141 355 135 144 355 minecraft:stone
setblock 135 141 359 minecraft:stripped_spruce_log
fill 135 141 360 135 144 360 minecraft:stone
setblock 135 141 364 minecraft:gold_block
fill 136 141 347 136 150 347 minecraft:deepslate
fill 94 142 330 94 144 330 minecraft:deepslate
fill 94 142 333 94 174 333 minecraft:deepslate
fill 94 142 343 94 174 343 minecraft:deepslate
fill 94 142 350 94 174 350 minecraft:deepslate
fill 95 142 349 95 142 352 minecraft:stone
setblock 95 142 353 minecraft:stripped_spruce_log
fill 95 142 354 95 144 354 minecraft:stone
setblock 95 142 358 minecraft:stripped_spruce_log
fill 95 142 359 95 144 359 minecraft:stone
setblock 96 142 352 minecraft:stripped_spruce_log
fill 96 142 353 96 144 353 minecraft:stone
setblock 96 142 357 minecraft:stripped_spruce_log
fill 96 142 358 96 144 358 minecraft:stone
fill 101 142 363 101 144 363 minecraft:stone
setblock 105 142 363 minecraft:stripped_spruce_log
setblock 115 142 364 minecraft:raw_iron_block
setblock 118 142 364 minecraft:raw_iron_block
fill 119 142 364 120 152 364 minecraft:deepslate
setblock 120 142 323 minecraft:stripped_spruce_log
fill 121 142 323 124 142 323 minecraft:stone
fill 121 142 363 124 142 363 minecraft:stone
fill 122 142 324 123 142 324 minecraft:stone
setblock 124 142 324 minecraft:stripped_spruce_log
setblock 125 142 323 minecraft:stripped_spruce_log
fill 125 142 324 125 144 324 minecraft:stone
setblock 125 142 363 minecraft:stripped_spruce_log
fill 126 142 323 126 144 323 minecraft:stone
setblock 126 142 362 minecraft:stripped_spruce_log
fill 126 142 363 126 144 363 minecraft:stone
fill 127 142 362 127 144 362 minecraft:stone
setblock 130 142 323 minecraft:stripped_spruce_log
setblock 130 142 363 minecraft:stripped_spruce_log
fill 131 142 363 131 144 363 minecraft:stone
setblock 135 142 353 minecraft:stripped_spruce_log
fill 135 142 354 135 144 354 minecraft:stone
setblock 135 142 358 minecraft:stripped_spruce_log
fill 135 142 359 135 144 359 minecraft:stone
fill 135 142 364 135 143 364 minecraft:deepslate
setblock 136 142 323 minecraft:raw_iron_block
setblock 94 143 328 minecraft:raw_iron_block
fill 95 143 350 95 143 351 minecraft:stone
setblock 95 143 352 minecraft:stripped_spruce_log
fill 95 143 353 95 144 353 minecraft:stone
setblock 95 143 357 minecraft:stripped_spruce_log
fill 95 143 358 95 144 358 minecraft:stone
setblock 96 143 324 minecraft:glowstone
setblock 96 143 343 minecraft:glowstone
setblock 96 143 352 minecraft:stone
setblock 96 143 356 minecraft:stripped_spruce_log
fill 96 143 357 96 144 357 minecraft:stone
setblock 96 143 362 minecraft:glowstone
setblock 104 143 363 minecraft:stripped_spruce_log
setblock 115 143 324 minecraft:glowstone
setblock 115 143 362 minecraft:glowstone
fill 115 143 364 115 145 364 minecraft:deepslate
fill 118 143 364 118 171 364 minecraft:deepslate
fill 120 143 323 123 143 323 minecraft:stone
fill 121 143 363 123 143 363 minecraft:stone
setblock 122 143 324 minecraft:stone
fill 122 143 364 122 172 364 minecraft:deepslate
setblock 123 143 324 minecraft:stripped_spruce_log
fill 123 143 362 123 144 362 minecraft:stone
setblock 123 143 364 minecraft:raw_iron_block
setblock 124 143 323 minecraft:stripped_spruce_log
fill 124 143 324 124 144 324 minecraft:stone
setblock 124 143 363 minecraft:stripped_spruce_log
fill 124 143 364 125 155 364 minecraft:deepslate
fill 125 143 323 125 144 323 minecraft:stone
setblock 125 143 362 minecraft:stripped_spruce_log
fill 125 143 363 125 144 363 minecraft:stone
fill 126 143 362 126 144 362 minecraft:stone
setblock 129 143 323 minecraft:stripped_spruce_log
setblock 129 143 363 minecraft:stripped_spruce_log
fill 130 143 363 130 144 363 minecraft:stone
setblock 134 143 324 minecraft:glowstone
setblock 134 143 343 minecraft:glowstone
setblock 134 143 362 minecraft:glowstone
fill 135 143 353 135 144 353 minecraft:stone
setblock 135 143 357 minecraft:stripped_spruce_log
fill 135 143 358 135 144 358 minecraft:stone
setblock 135 143 362 minecraft:stripped_spruce_log
fill 136 143 323 136 162 323 minecraft:deepslate
fill 94 144 328 94 174 328 minecraft:deepslate
setblock 94 144 356 minecraft:gold_block
setblock 95 144 347 minecraft:stripped_spruce_log
setblock 95 144 351 minecraft:stripped_spruce_log
setblock 95 144 352 minecraft:stone
setblock 95 144 356 minecraft:stripped_spruce_log
setblock 95 144 357 minecraft:stone
setblock 95 144 361 minecraft:stripped_spruce_log
fill 96 144 324 96 145 324 minecraft:spruce_log
fill 96 144 343 96 145 343 minecraft:spruce_log
setblock 96 144 346 minecraft:stripped_spruce_log
setblock 96 144 348 minecraft:stripped_spruce_log
setblock 96 144 355 minecraft:stripped_spruce_log
setblock 96 144 356 minecraft:stone
setblock 96 144 359 minecraft:stone
fill 96 144 362 96 145 362 minecraft:spruce_log
setblock 97 144 325 minecraft:light[level=12]
setblock 97 144 332 minecraft:light[level=12]
setblock 97 144 339 minecraft:light[level=12]
setblock 97 144 346 minecraft:light[level=12]
fill 97 144 347 97 147 347 minecraft:stripped_spruce_log
setblock 97 144 353 minecraft:light[level=12]
setblock 97 144 360 minecraft:light[level=12]
fill 98 144 364 101 158 364 minecraft:deepslate
setblock 100 144 363 minecraft:stone
setblock 102 144 364 minecraft:raw_gold_block
setblock 103 144 363 minecraft:stripped_spruce_log
setblock 104 144 325 minecraft:light[level=12]
setblock 104 144 332 minecraft:light[level=12]
setblock 104 144 339 minecraft:light[level=12]
setblock 104 144 346 minecraft:light[level=12]
setblock 104 144 353 minecraft:light[level=12]
setblock 104 144 360 minecraft:light[level=12]
setblock 104 144 363 minecraft:stone
setblock 111 144 325 minecraft:light[level=12]
setblock 111 144 332 minecraft:light[level=12]
setblock 111 144 339 minecraft:light[level=12]
setblock 111 144 346 minecraft:light[level=12]
setblock 111 144 353 minecraft:light[level=12]
setblock 111 144 360 minecraft:light[level=12]
setblock 113 144 364 minecraft:raw_iron_block
fill 115 144 324 115 145 324 minecraft:spruce_log
fill 115 144 362 115 145 362 minecraft:spruce_log
setblock 118 144 325 minecraft:light[level=12]
setblock 118 144 332 minecraft:light[level=12]
setblock 118 144 339 minecraft:light[level=12]
setblock 118 144 346 minecraft:light[level=12]
setblock 118 144 353 minecraft:light[level=12]
setblock 118 144 360 minecraft:light[level=12]
fill 119 144 323 122 144 323 minecraft:stone
fill 120 144 363 122 144 363 minecraft:stone
setblock 122 144 324 minecraft:stripped_spruce_log
setblock 122 144 362 minecraft:stone
setblock 123 144 323 minecraft:stripped_spruce_log
setblock 123 144 324 minecraft:stone
setblock 123 144 363 minecraft:stripped_spruce_log
fill 123 144 364 123 167 364 minecraft:deepslate
setblock 124 144 323 minecraft:stone
setblock 124 144 362 minecraft:stripped_spruce_log
setblock 124 144 363 minecraft:stone
setblock 125 144 325 minecraft:light[level=12]
setblock 125 144 332 minecraft:light[level=12]
setblock 125 144 339 minecraft:light[level=12]
setblock 125 144 346 minecraft:light[level=12]
setblock 125 144 353 minecraft:light[level=12]
setblock 125 144 360 minecraft:light[level=12]
setblock 125 144 362 minecraft:stone
setblock 128 144 323 minecraft:stripped_spruce_log
setblock 128 144 363 minecraft:stripped_spruce_log
setblock 129 144 363 minecraft:stone
setblock 132 144 325 minecraft:light[level=12]
setblock 132 144 332 minecraft:light[level=12]
setblock 132 144 339 minecraft:light[level=12]
setblock 132 144 346 minecraft:light[level=12]
setblock 132 144 353 minecraft:light[level=12]
setblock 132 144 360 minecraft:light[level=12]
fill 134 144 324 134 145 324 minecraft:spruce_log
fill 134 144 343 134 145 343 minecraft:spruce_log
fill 134 144 362 134 145 362 minecraft:spruce_log
setblock 135 144 356 minecraft:stripped_spruce_log
setblock 135 144 357 minecraft:stone
setblock 135 144 361 minecraft:stripped_spruce_log
setblock 135 144 362 minecraft:stone
setblock 135 144 364 minecraft:diamond_block
setblock 94 145 330 minecraft:raw_iron_block
fill 94 145 356 94 174 356 minecraft:deepslate
fill 94 145 359 94 174 359 minecraft:deepslate
setblock 94 145 360 minecraft:diamond_block
fill 95 145 323 95 145 363 minecraft:spruce_planks
fill 96 145 323 135 145 323 minecraft:spruce_planks
fill 96 145 325 96 145 342 minecraft:spruce_planks
fill 96 145 344 96 145 361 minecraft:spruce_planks
fill 96 145 363 135 145 363 minecraft:spruce_planks
fill 97 145 324 114 145 324 minecraft:spruce_planks
fill 97 145 346 97 147 346 minecraft:stripped_spruce_log
fill 97 145 348 97 147 348 minecraft:stripped_spruce_log
fill 97 145 362 114 145 362 minecraft:spruce_planks
fill 102 145 364 102 173 364 minecraft:deepslate
fill 113 145 364 113 174 364 minecraft:deepslate
fill 116 145 324 133 145 324 minecraft:spruce_planks
fill 116 145 362 133 145 362 minecraft:spruce_planks
fill 134 145 325 135 145 342 minecraft:spruce_planks
fill 134 145 344 135 145 361 minecraft:spruce_planks
setblock 135 145 324 minecraft:spruce_planks
setblock 135 145 343 minecraft:spruce_planks
setblock 135 145 362 minecraft:spruce_planks
fill 135 145 364 135 174 364 minecraft:deepslate
fill 94 146 330 94 161 330 minecraft:deepslate
fill 94 146 360 94 175 360 minecraft:deepslate
fill 95 146 336 95 146 338 minecraft:stone
setblock 95 146 339 minecraft:stripped_spruce_log
fill 95 146 340 95 149 340 minecraft:stone
fill 95 146 346 96 147 348 minecraft:stripped_spruce_log
fill 95 146 351 95 146 353 minecraft:stone
setblock 95 146 354 minecraft:stripped_spruce_log
fill 95 146 355 95 146 358 minecraft:stone
setblock 95 146 359 minecraft:stripped_spruce_log
fill 95 146 360 95 147 362 minecraft:stone
fill 96 146 354 96 146 357 minecraft:stone
setblock 96 146 358 minecraft:stripped_spruce_log
fill 96 146 359 96 148 360 minecraft:stone
setblock 97 146 325 minecraft:light[level=15]
setblock 97 146 333 minecraft:light[level=15]
setblock 97 146 341 minecraft:light[level=15]
setblock 97 146 349 minecraft:light[level=15]
setblock 97 146 357 minecraft:light[level=15]
fill 97 146 363 100 146 363 minecraft:stone
setblock 101 146 362 minecraft:stone
setblock 101 146 363 minecraft:stripped_spruce_log
fill 102 146 363 104 147 363 minecraft:stone
setblock 105 146 325 minecraft:light[level=15]
setblock 105 146 333 minecraft:light[level=15]
setblock 105 146 341 minecraft:light[level=15]
setblock 105 146 349 minecraft:light[level=15]
setblock 105 146 357 minecraft:light[level=15]
setblock 109 146 322 minecraft:gold_block
setblock 113 146 325 minecraft:light[level=15]
setblock 113 146 333 minecraft:light[level=15]
setblock 113 146 341 minecraft:light[level=15]
setblock 113 146 349 minecraft:light[level=15]
setblock 113 146 357 minecraft:light[level=15]
setblock 115 146 364 minecraft:diamond_block
setblock 117 146 322 minecraft:raw_gold_block
fill 118 146 323 120 146 323 minecraft:stone
fill 118 146 363 120 146 363 minecraft:stone
fill 120 146 362 121 146 362 minecraft:stone
setblock 121 146 323 minecraft:stripped_spruce_log
fill 121 146 324 124 146 324 minecraft:stone
setblock 121 146 325 minecraft:light[level=15]
setblock 121 146 333 minecraft:light[level=15]
setblock 121 146 341 minecraft:light[level=15]
setblock 121 146 349 minecraft:light[level=15]
setblock 121 146 357 minecraft:light[level=15]
setblock 121 146 363 minecraft:stripped_spruce_log
fill 122 146 323 125 146 323 minecraft:stone
setblock 122 146 362 minecraft:stripped_spruce_log
fill 122 146 363 125 146 363 minecraft:stone
setblock 123 146 361 minecraft:stripped_spruce_log
fill 123 146 362 126 146 362 minecraft:stone
fill 124 146 341 126 204 343 minecraft:stripped_spruce_log
fill 124 146 361 124 149 361 minecraft:stone
fill 125 146 340 125 204 340 minecraft:stripped_spruce_log
setblock 126 146 323 minecraft:stripped_spruce_log
setblock 126 146 363 minecraft:stripped_spruce_log
fill 127 146 323 127 149 323 minecraft:stone
fill 127 146 342 127 204 342 minecraft:stripped_spruce_log
setblock 127 146 362 minecraft:stripped_spruce_log
fill 127 146 363 130 146 363 minecraft:stone
fill 128 146 362 128 149 362 minecraft:stone
setblock 129 146 325 minecraft:light[level=15]
setblock 129 146 333 minecraft:light[level=15]
setblock 129 146 341 minecraft:light[level=15]
setblock 129 146 349 minecraft:light[level=15]
setblock 129 146 357 minecraft:light[level=15]
setblock 131 146 363 minecraft:stripped_spruce_log
fill 132 146 363 135 146 363 minecraft:stone
fill 134 146 357 134 146 359 minecraft:stone
setblock 134 146 360 minecraft:stripped_spruce_log
setblock 135 146 353 minecraft:stone
setblock 135 146 354 minecraft:stripped_spruce_log
fill 135 146 355 135 146 358 minecraft:stone
setblock 135 146 359 minecraft:stripped_spruce_log
fill 135 146 360 135 147 362 minecraft:stone
fill 95 147 335 95 147 337 minecraft:stone
setblock 95 147 338 minecraft:stripped_spruce_log
fill 95 147 339 96 149 339 minecraft:stone
schedule function dropper:buildpart/74_4 1t
