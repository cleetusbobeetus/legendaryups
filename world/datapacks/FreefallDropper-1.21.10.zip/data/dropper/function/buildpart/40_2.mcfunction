setblock 207 250 208 minecraft:light[level=12]
setblock 207 250 216 minecraft:light[level=12]
setblock 215 250 184 minecraft:light[level=12]
setblock 215 250 192 minecraft:light[level=12]
setblock 215 250 200 minecraft:light[level=12]
setblock 215 250 208 minecraft:light[level=12]
setblock 215 250 216 minecraft:light[level=12]
setblock 223 250 184 minecraft:light[level=12]
setblock 223 250 192 minecraft:light[level=12]
setblock 223 250 200 minecraft:light[level=12]
fill 223 250 201 223 252 203 minecraft:purple_concrete
setblock 223 250 208 minecraft:light[level=12]
setblock 223 250 216 minecraft:light[level=12]
fill 225 250 201 225 252 201 minecraft:purple_concrete
fill 225 250 203 225 252 203 minecraft:purple_concrete
fill 224 251 200 224 252 200 minecraft:purple_concrete
fill 224 251 204 224 252 204 minecraft:purple_concrete
fill 226 251 201 226 252 203 minecraft:purple_concrete
fill 188 252 187 188 265 187 minecraft:deepslate_bricks
fill 188 252 188 188 252 189 minecraft:crying_obsidian
fill 188 252 190 188 265 190 minecraft:deepslate_bricks
fill 188 252 199 188 265 199 minecraft:deepslate_bricks
fill 188 252 200 188 252 201 minecraft:crying_obsidian
fill 188 252 202 188 265 202 minecraft:deepslate_bricks
fill 188 252 211 188 265 211 minecraft:deepslate_bricks
fill 188 252 212 188 252 213 minecraft:crying_obsidian
fill 188 252 214 188 265 214 minecraft:deepslate_bricks
fill 188 252 223 188 265 223 minecraft:deepslate_bricks
fill 189 252 223 190 252 223 minecraft:crying_obsidian
fill 191 252 223 191 265 223 minecraft:deepslate_bricks
fill 195 252 181 195 265 181 minecraft:deepslate_bricks
fill 196 252 181 197 252 181 minecraft:crying_obsidian
fill 198 252 181 198 265 181 minecraft:deepslate_bricks
fill 200 252 223 200 265 223 minecraft:deepslate_bricks
fill 201 252 223 202 252 223 minecraft:crying_obsidian
fill 203 252 223 203 265 223 minecraft:deepslate_bricks
fill 207 252 181 207 265 181 minecraft:deepslate_bricks
fill 208 252 181 209 252 181 minecraft:crying_obsidian
fill 210 252 181 210 265 181 minecraft:deepslate_bricks
fill 212 252 223 212 265 223 minecraft:deepslate_bricks
fill 213 252 223 214 252 223 minecraft:crying_obsidian
fill 215 252 223 215 265 223 minecraft:deepslate_bricks
fill 219 252 181 219 265 181 minecraft:deepslate_bricks
fill 220 252 181 221 252 181 minecraft:crying_obsidian
fill 222 252 181 222 265 181 minecraft:deepslate_bricks
fill 222 252 201 222 252 203 minecraft:purple_concrete
setblock 223 252 200 minecraft:purple_concrete
setblock 223 252 204 minecraft:purple_concrete
fill 224 252 223 224 265 223 minecraft:deepslate_bricks
setblock 225 252 200 minecraft:purple_concrete
setblock 225 252 204 minecraft:purple_concrete
fill 225 252 223 226 252 223 minecraft:crying_obsidian
fill 227 252 223 227 265 223 minecraft:deepslate_bricks
fill 230 252 182 230 265 182 minecraft:deepslate_bricks
fill 230 252 183 230 252 184 minecraft:crying_obsidian
fill 230 252 185 230 265 185 minecraft:deepslate_bricks
fill 230 252 194 230 265 194 minecraft:deepslate_bricks
fill 230 252 195 230 252 196 minecraft:crying_obsidian
fill 230 252 197 230 265 197 minecraft:deepslate_bricks
fill 230 252 206 230 265 206 minecraft:deepslate_bricks
fill 230 252 207 230 252 208 minecraft:crying_obsidian
fill 230 252 209 230 265 209 minecraft:deepslate_bricks
fill 230 252 218 230 265 218 minecraft:deepslate_bricks
fill 230 252 219 230 252 220 minecraft:crying_obsidian
fill 230 252 221 230 265 221 minecraft:deepslate_bricks
fill 188 253 188 188 265 189 minecraft:deepslate_bricks
fill 188 253 200 188 265 201 minecraft:deepslate_bricks
fill 188 253 212 188 265 213 minecraft:deepslate_bricks
fill 189 253 223 190 265 223 minecraft:deepslate_bricks
fill 196 253 181 197 265 181 minecraft:deepslate_bricks
fill 201 253 223 202 265 223 minecraft:deepslate_bricks
fill 208 253 181 209 265 181 minecraft:deepslate_bricks
fill 213 253 223 214 265 223 minecraft:deepslate_bricks
fill 220 253 181 221 265 181 minecraft:deepslate_bricks
fill 220 253 199 228 255 205 minecraft:polished_deepslate
fill 225 253 223 226 265 223 minecraft:deepslate_bricks
fill 229 253 199 229 255 201 minecraft:polished_deepslate
fill 229 253 205 229 271 205 minecraft:polished_deepslate
fill 230 253 183 230 265 184 minecraft:deepslate_bricks
fill 230 253 195 230 265 196 minecraft:deepslate_bricks
fill 230 253 207 230 265 208 minecraft:deepslate_bricks
fill 230 253 219 230 265 220 minecraft:deepslate_bricks
setblock 220 256 199 minecraft:crying_obsidian
fill 220 256 200 220 271 200 minecraft:polished_deepslate
setblock 220 256 201 minecraft:crying_obsidian
fill 220 256 202 220 271 202 minecraft:polished_deepslate
setblock 220 256 203 minecraft:crying_obsidian
fill 220 256 204 220 271 204 minecraft:polished_deepslate
setblock 220 256 205 minecraft:crying_obsidian
fill 221 256 199 221 271 199 minecraft:polished_deepslate
setblock 221 256 200 minecraft:crying_obsidian
fill 221 256 201 221 271 201 minecraft:polished_deepslate
setblock 221 256 202 minecraft:crying_obsidian
fill 221 256 203 221 271 203 minecraft:polished_deepslate
setblock 221 256 204 minecraft:crying_obsidian
fill 221 256 205 221 271 205 minecraft:polished_deepslate
setblock 222 256 199 minecraft:crying_obsidian
fill 222 256 200 222 271 200 minecraft:polished_deepslate
setblock 222 256 201 minecraft:crying_obsidian
fill 222 256 202 222 271 202 minecraft:polished_deepslate
setblock 222 256 203 minecraft:crying_obsidian
fill 222 256 204 222 271 204 minecraft:polished_deepslate
setblock 222 256 205 minecraft:crying_obsidian
fill 223 256 199 223 271 199 minecraft:polished_deepslate
setblock 223 256 200 minecraft:crying_obsidian
fill 223 256 201 223 271 201 minecraft:polished_deepslate
setblock 223 256 202 minecraft:crying_obsidian
fill 223 256 203 223 271 203 minecraft:polished_deepslate
setblock 223 256 204 minecraft:crying_obsidian
fill 223 256 205 223 271 205 minecraft:polished_deepslate
setblock 224 256 199 minecraft:crying_obsidian
fill 224 256 200 224 271 200 minecraft:polished_deepslate
setblock 224 256 201 minecraft:crying_obsidian
fill 224 256 202 224 271 202 minecraft:polished_deepslate
setblock 224 256 203 minecraft:crying_obsidian
fill 224 256 204 224 271 204 minecraft:polished_deepslate
setblock 224 256 205 minecraft:crying_obsidian
fill 225 256 199 225 271 199 minecraft:polished_deepslate
setblock 225 256 200 minecraft:crying_obsidian
fill 225 256 201 225 271 201 minecraft:polished_deepslate
setblock 225 256 202 minecraft:crying_obsidian
fill 225 256 203 225 271 203 minecraft:polished_deepslate
setblock 225 256 204 minecraft:crying_obsidian
fill 225 256 205 225 271 205 minecraft:polished_deepslate
setblock 226 256 199 minecraft:crying_obsidian
fill 226 256 200 226 271 200 minecraft:polished_deepslate
setblock 226 256 201 minecraft:crying_obsidian
fill 226 256 202 226 271 202 minecraft:polished_deepslate
setblock 226 256 203 minecraft:crying_obsidian
fill 226 256 204 226 271 204 minecraft:polished_deepslate
setblock 226 256 205 minecraft:crying_obsidian
fill 227 256 199 227 271 199 minecraft:polished_deepslate
setblock 227 256 200 minecraft:crying_obsidian
fill 227 256 201 227 271 201 minecraft:polished_deepslate
setblock 227 256 202 minecraft:crying_obsidian
fill 227 256 203 227 271 203 minecraft:polished_deepslate
setblock 227 256 204 minecraft:crying_obsidian
fill 227 256 205 227 271 205 minecraft:polished_deepslate
setblock 228 256 199 minecraft:crying_obsidian
fill 228 256 200 228 271 200 minecraft:polished_deepslate
setblock 228 256 201 minecraft:crying_obsidian
fill 228 256 202 228 271 202 minecraft:polished_deepslate
setblock 228 256 203 minecraft:crying_obsidian
fill 228 256 204 228 271 204 minecraft:polished_deepslate
setblock 228 256 205 minecraft:crying_obsidian
fill 229 256 199 229 264 199 minecraft:polished_deepslate
setblock 229 256 200 minecraft:crying_obsidian
fill 229 256 201 229 271 201 minecraft:polished_deepslate
setblock 229 256 202 minecraft:crying_obsidian
fill 229 256 203 229 271 203 minecraft:polished_deepslate
setblock 229 256 204 minecraft:crying_obsidian
fill 220 257 199 220 258 199 minecraft:polished_deepslate
fill 220 257 201 220 258 201 minecraft:polished_deepslate
fill 220 257 203 220 258 203 minecraft:polished_deepslate
fill 220 257 205 220 258 205 minecraft:polished_deepslate
fill 221 257 200 221 258 200 minecraft:polished_deepslate
fill 221 257 202 221 258 202 minecraft:polished_deepslate
fill 221 257 204 221 258 204 minecraft:polished_deepslate
fill 222 257 199 222 258 199 minecraft:polished_deepslate
fill 222 257 201 222 258 201 minecraft:polished_deepslate
fill 222 257 203 222 258 203 minecraft:polished_deepslate
fill 222 257 205 222 258 205 minecraft:polished_deepslate
fill 223 257 200 223 258 200 minecraft:polished_deepslate
fill 223 257 202 223 258 202 minecraft:polished_deepslate
fill 223 257 204 223 258 204 minecraft:polished_deepslate
fill 224 257 199 224 258 199 minecraft:polished_deepslate
fill 224 257 201 224 258 201 minecraft:polished_deepslate
fill 224 257 203 224 258 203 minecraft:polished_deepslate
fill 224 257 205 224 258 205 minecraft:polished_deepslate
fill 225 257 200 225 258 200 minecraft:polished_deepslate
fill 225 257 202 225 258 202 minecraft:polished_deepslate
fill 225 257 204 225 258 204 minecraft:polished_deepslate
fill 226 257 199 226 258 199 minecraft:polished_deepslate
fill 226 257 201 226 258 201 minecraft:polished_deepslate
fill 226 257 203 226 258 203 minecraft:polished_deepslate
fill 226 257 205 226 258 205 minecraft:polished_deepslate
fill 227 257 200 227 258 200 minecraft:polished_deepslate
fill 227 257 202 227 258 202 minecraft:polished_deepslate
fill 227 257 204 227 258 204 minecraft:polished_deepslate
fill 228 257 199 228 258 199 minecraft:polished_deepslate
fill 228 257 201 228 258 201 minecraft:polished_deepslate
fill 228 257 203 228 258 203 minecraft:polished_deepslate
fill 228 257 205 228 258 205 minecraft:polished_deepslate
fill 229 257 200 229 258 200 minecraft:polished_deepslate
fill 229 257 202 229 258 202 minecraft:polished_deepslate
fill 229 257 204 229 258 204 minecraft:polished_deepslate
setblock 191 258 184 minecraft:light[level=12]
setblock 191 258 192 minecraft:light[level=12]
setblock 191 258 200 minecraft:light[level=12]
setblock 191 258 208 minecraft:light[level=12]
setblock 191 258 216 minecraft:light[level=12]
setblock 199 258 184 minecraft:light[level=12]
setblock 199 258 192 minecraft:light[level=12]
setblock 199 258 200 minecraft:light[level=12]
setblock 199 258 208 minecraft:light[level=12]
setblock 199 258 216 minecraft:light[level=12]
setblock 207 258 184 minecraft:light[level=12]
setblock 207 258 192 minecraft:light[level=12]
setblock 207 258 200 minecraft:light[level=12]
setblock 207 258 208 minecraft:light[level=12]
setblock 207 258 216 minecraft:light[level=12]
setblock 215 258 184 minecraft:light[level=12]
setblock 215 258 192 minecraft:light[level=12]
setblock 215 258 200 minecraft:light[level=12]
setblock 215 258 208 minecraft:light[level=12]
setblock 215 258 216 minecraft:light[level=12]
setblock 223 258 184 minecraft:light[level=12]
setblock 223 258 192 minecraft:light[level=12]
setblock 223 258 208 minecraft:light[level=12]
setblock 223 258 216 minecraft:light[level=12]
setblock 220 259 199 minecraft:crying_obsidian
setblock 220 259 201 minecraft:crying_obsidian
setblock 220 259 203 minecraft:crying_obsidian
setblock 220 259 205 minecraft:crying_obsidian
setblock 221 259 200 minecraft:crying_obsidian
setblock 221 259 202 minecraft:crying_obsidian
setblock 221 259 204 minecraft:crying_obsidian
setblock 222 259 199 minecraft:crying_obsidian
setblock 222 259 201 minecraft:crying_obsidian
setblock 222 259 203 minecraft:crying_obsidian
setblock 222 259 205 minecraft:crying_obsidian
setblock 223 259 200 minecraft:crying_obsidian
setblock 223 259 202 minecraft:crying_obsidian
setblock 223 259 204 minecraft:crying_obsidian
setblock 224 259 199 minecraft:crying_obsidian
setblock 224 259 201 minecraft:crying_obsidian
setblock 224 259 203 minecraft:crying_obsidian
setblock 224 259 205 minecraft:crying_obsidian
setblock 225 259 200 minecraft:crying_obsidian
setblock 225 259 202 minecraft:crying_obsidian
setblock 225 259 204 minecraft:crying_obsidian
setblock 226 259 199 minecraft:crying_obsidian
setblock 226 259 201 minecraft:crying_obsidian
setblock 226 259 203 minecraft:crying_obsidian
setblock 226 259 205 minecraft:crying_obsidian
setblock 227 259 200 minecraft:crying_obsidian
setblock 227 259 202 minecraft:crying_obsidian
setblock 227 259 204 minecraft:crying_obsidian
setblock 228 259 199 minecraft:crying_obsidian
setblock 228 259 201 minecraft:crying_obsidian
setblock 228 259 203 minecraft:crying_obsidian
setblock 228 259 205 minecraft:crying_obsidian
setblock 229 259 200 minecraft:crying_obsidian
setblock 229 259 202 minecraft:crying_obsidian
setblock 229 259 204 minecraft:crying_obsidian
fill 190 260 191 190 265 193 minecraft:polished_deepslate
fill 190 260 203 190 265 205 minecraft:polished_deepslate
fill 190 260 215 190 265 217 minecraft:polished_deepslate
fill 196 260 221 198 265 221 minecraft:polished_deepslate
fill 200 260 183 202 265 183 minecraft:polished_deepslate
fill 208 260 221 210 265 221 minecraft:polished_deepslate
fill 212 260 183 214 265 183 minecraft:polished_deepslate
fill 220 260 199 220 261 199 minecraft:polished_deepslate
fill 220 260 201 220 261 201 minecraft:polished_deepslate
fill 220 260 203 220 261 203 minecraft:polished_deepslate
fill 220 260 205 220 261 205 minecraft:polished_deepslate
fill 220 260 221 222 265 221 minecraft:polished_deepslate
fill 221 260 200 221 261 200 minecraft:polished_deepslate
fill 221 260 202 221 261 202 minecraft:polished_deepslate
fill 221 260 204 221 261 204 minecraft:polished_deepslate
fill 222 260 199 222 261 199 minecraft:polished_deepslate
fill 222 260 201 222 261 201 minecraft:polished_deepslate
fill 222 260 203 222 261 203 minecraft:polished_deepslate
fill 222 260 205 222 261 205 minecraft:polished_deepslate
fill 223 260 200 223 261 200 minecraft:polished_deepslate
fill 223 260 202 223 261 202 minecraft:polished_deepslate
fill 223 260 204 223 261 204 minecraft:polished_deepslate
fill 224 260 183 226 265 183 minecraft:polished_deepslate
fill 224 260 199 224 261 199 minecraft:polished_deepslate
fill 224 260 201 224 261 201 minecraft:polished_deepslate
fill 224 260 203 224 261 203 minecraft:polished_deepslate
fill 224 260 205 224 261 205 minecraft:polished_deepslate
fill 225 260 200 225 261 200 minecraft:polished_deepslate
fill 225 260 202 225 261 202 minecraft:polished_deepslate
fill 225 260 204 225 261 204 minecraft:polished_deepslate
fill 226 260 199 226 261 199 minecraft:polished_deepslate
fill 226 260 201 226 261 201 minecraft:polished_deepslate
fill 226 260 203 226 261 203 minecraft:polished_deepslate
fill 226 260 205 226 261 205 minecraft:polished_deepslate
fill 227 260 200 227 261 200 minecraft:polished_deepslate
fill 227 260 202 227 261 202 minecraft:polished_deepslate
fill 227 260 204 227 261 204 minecraft:polished_deepslate
fill 228 260 191 228 265 193 minecraft:polished_deepslate
fill 228 260 199 228 261 199 minecraft:polished_deepslate
fill 228 260 201 228 261 201 minecraft:polished_deepslate
fill 228 260 203 228 261 203 minecraft:polished_deepslate
fill 228 260 205 228 261 205 minecraft:polished_deepslate
fill 228 260 215 228 265 217 minecraft:polished_deepslate
fill 229 260 200 229 261 200 minecraft:polished_deepslate
fill 229 260 202 229 261 202 minecraft:polished_deepslate
fill 229 260 204 229 261 204 minecraft:polished_deepslate
setblock 220 262 199 minecraft:crying_obsidian
setblock 220 262 201 minecraft:crying_obsidian
setblock 220 262 203 minecraft:crying_obsidian
setblock 220 262 205 minecraft:crying_obsidian
setblock 221 262 200 minecraft:crying_obsidian
setblock 221 262 202 minecraft:crying_obsidian
setblock 221 262 204 minecraft:crying_obsidian
setblock 222 262 199 minecraft:crying_obsidian
setblock 222 262 201 minecraft:crying_obsidian
setblock 222 262 203 minecraft:crying_obsidian
setblock 222 262 205 minecraft:crying_obsidian
setblock 223 262 200 minecraft:crying_obsidian
setblock 223 262 202 minecraft:crying_obsidian
setblock 223 262 204 minecraft:crying_obsidian
setblock 224 262 199 minecraft:crying_obsidian
setblock 224 262 201 minecraft:crying_obsidian
setblock 224 262 203 minecraft:crying_obsidian
setblock 224 262 205 minecraft:crying_obsidian
setblock 225 262 200 minecraft:crying_obsidian
setblock 225 262 202 minecraft:crying_obsidian
setblock 225 262 204 minecraft:crying_obsidian
setblock 226 262 199 minecraft:crying_obsidian
setblock 226 262 201 minecraft:crying_obsidian
setblock 226 262 203 minecraft:crying_obsidian
setblock 226 262 205 minecraft:crying_obsidian
setblock 227 262 200 minecraft:crying_obsidian
setblock 227 262 202 minecraft:crying_obsidian
setblock 227 262 204 minecraft:crying_obsidian
setblock 228 262 199 minecraft:crying_obsidian
setblock 228 262 201 minecraft:crying_obsidian
setblock 228 262 203 minecraft:crying_obsidian
setblock 228 262 205 minecraft:crying_obsidian
setblock 229 262 200 minecraft:crying_obsidian
setblock 229 262 202 minecraft:crying_obsidian
setblock 229 262 204 minecraft:crying_obsidian
fill 220 263 199 220 264 199 minecraft:polished_deepslate
fill 220 263 201 220 264 201 minecraft:polished_deepslate
fill 220 263 203 220 264 203 minecraft:polished_deepslate
fill 220 263 205 220 264 205 minecraft:polished_deepslate
fill 221 263 200 221 264 200 minecraft:polished_deepslate
fill 221 263 202 221 264 202 minecraft:polished_deepslate
fill 221 263 204 221 264 204 minecraft:polished_deepslate
fill 222 263 199 222 264 199 minecraft:polished_deepslate
fill 222 263 201 222 264 201 minecraft:polished_deepslate
fill 222 263 203 222 264 203 minecraft:polished_deepslate
fill 222 263 205 222 264 205 minecraft:polished_deepslate
fill 223 263 200 223 264 200 minecraft:polished_deepslate
fill 223 263 202 223 264 202 minecraft:polished_deepslate
fill 223 263 204 223 264 204 minecraft:polished_deepslate
fill 224 263 199 224 264 199 minecraft:polished_deepslate
fill 224 263 201 224 264 201 minecraft:polished_deepslate
fill 224 263 203 224 264 203 minecraft:polished_deepslate
fill 224 263 205 224 264 205 minecraft:polished_deepslate
fill 225 263 200 225 264 200 minecraft:polished_deepslate
fill 225 263 202 225 264 202 minecraft:polished_deepslate
fill 225 263 204 225 264 204 minecraft:polished_deepslate
fill 226 263 199 226 264 199 minecraft:polished_deepslate
fill 226 263 201 226 264 201 minecraft:polished_deepslate
fill 226 263 203 226 264 203 minecraft:polished_deepslate
fill 226 263 205 226 264 205 minecraft:polished_deepslate
fill 227 263 200 227 264 200 minecraft:polished_deepslate
fill 227 263 202 227 264 202 minecraft:polished_deepslate
fill 227 263 204 227 264 204 minecraft:polished_deepslate
fill 228 263 199 228 264 199 minecraft:polished_deepslate
fill 228 263 201 228 264 201 minecraft:polished_deepslate
fill 228 263 203 228 264 203 minecraft:polished_deepslate
fill 228 263 205 228 264 205 minecraft:polished_deepslate
fill 229 263 200 229 264 200 minecraft:polished_deepslate
fill 229 263 202 229 264 202 minecraft:polished_deepslate
fill 229 263 204 229 264 204 minecraft:polished_deepslate
fill 189 265 185 189 265 190 minecraft:obsidian
fill 189 265 197 189 265 202 minecraft:obsidian
fill 189 265 209 189 265 214 minecraft:obsidian
fill 189 265 221 189 265 222 minecraft:obsidian
fill 190 265 222 193 265 222 minecraft:obsidian
fill 193 265 182 198 265 182 minecraft:obsidian
fill 200 265 222 205 265 222 minecraft:obsidian
fill 205 265 182 210 265 182 minecraft:obsidian
fill 212 265 222 217 265 222 minecraft:obsidian
fill 217 265 182 222 265 182 minecraft:obsidian
setblock 220 265 199 minecraft:crying_obsidian
setblock 220 265 201 minecraft:crying_obsidian
setblock 220 265 203 minecraft:crying_obsidian
setblock 220 265 205 minecraft:crying_obsidian
setblock 221 265 200 minecraft:crying_obsidian
setblock 221 265 202 minecraft:crying_obsidian
setblock 221 265 204 minecraft:crying_obsidian
setblock 222 265 199 minecraft:crying_obsidian
setblock 222 265 201 minecraft:crying_obsidian
setblock 222 265 203 minecraft:crying_obsidian
setblock 222 265 205 minecraft:crying_obsidian
setblock 223 265 200 minecraft:crying_obsidian
setblock 223 265 202 minecraft:crying_obsidian
setblock 223 265 204 minecraft:crying_obsidian
setblock 224 265 199 minecraft:crying_obsidian
setblock 224 265 201 minecraft:crying_obsidian
setblock 224 265 203 minecraft:crying_obsidian
setblock 224 265 205 minecraft:crying_obsidian
fill 224 265 222 229 265 222 minecraft:obsidian
setblock 225 265 200 minecraft:crying_obsidian
setblock 225 265 202 minecraft:crying_obsidian
setblock 225 265 204 minecraft:crying_obsidian
setblock 226 265 199 minecraft:crying_obsidian
setblock 226 265 201 minecraft:crying_obsidian
setblock 226 265 203 minecraft:crying_obsidian
setblock 226 265 205 minecraft:crying_obsidian
setblock 227 265 200 minecraft:crying_obsidian
setblock 227 265 202 minecraft:crying_obsidian
setblock 227 265 204 minecraft:crying_obsidian
setblock 228 265 199 minecraft:crying_obsidian
setblock 228 265 201 minecraft:crying_obsidian
setblock 228 265 203 minecraft:crying_obsidian
setblock 228 265 205 minecraft:crying_obsidian
fill 229 265 182 229 265 187 minecraft:obsidian
fill 229 265 194 229 265 199 minecraft:obsidian
setblock 229 265 200 minecraft:crying_obsidian
setblock 229 265 202 minecraft:crying_obsidian
setblock 229 265 204 minecraft:crying_obsidian
fill 229 265 206 229 265 211 minecraft:obsidian
fill 229 265 218 229 265 221 minecraft:obsidian
fill 188 266 187 188 271 190 minecraft:crying_obsidian
fill 188 266 199 188 271 202 minecraft:crying_obsidian
fill 188 266 211 188 271 214 minecraft:crying_obsidian
fill 188 266 223 191 271 223 minecraft:crying_obsidian
setblock 191 266 184 minecraft:light[level=12]
setblock 191 266 192 minecraft:light[level=12]
setblock 191 266 200 minecraft:light[level=12]
setblock 191 266 208 minecraft:light[level=12]
setblock 191 266 216 minecraft:light[level=12]
fill 195 266 181 198 271 181 minecraft:crying_obsidian
setblock 199 266 184 minecraft:light[level=12]
setblock 199 266 192 minecraft:light[level=12]
setblock 199 266 200 minecraft:light[level=12]
setblock 199 266 208 minecraft:light[level=12]
setblock 199 266 216 minecraft:light[level=12]
fill 200 266 223 203 271 223 minecraft:crying_obsidian
fill 207 266 181 210 271 181 minecraft:crying_obsidian
setblock 207 266 184 minecraft:light[level=12]
setblock 207 266 192 minecraft:light[level=12]
setblock 207 266 200 minecraft:light[level=12]
setblock 207 266 208 minecraft:light[level=12]
setblock 207 266 216 minecraft:light[level=12]
fill 212 266 223 215 271 223 minecraft:crying_obsidian
setblock 215 266 184 minecraft:light[level=12]
setblock 215 266 192 minecraft:light[level=12]
setblock 215 266 200 minecraft:light[level=12]
setblock 215 266 208 minecraft:light[level=12]
setblock 215 266 216 minecraft:light[level=12]
fill 219 266 181 222 271 181 minecraft:crying_obsidian
fill 220 266 199 220 267 199 minecraft:polished_deepslate
fill 220 266 201 220 267 201 minecraft:polished_deepslate
fill 220 266 203 220 267 203 minecraft:polished_deepslate
fill 220 266 205 220 267 205 minecraft:polished_deepslate
fill 221 266 200 221 267 200 minecraft:polished_deepslate
fill 221 266 202 221 267 202 minecraft:polished_deepslate
fill 221 266 204 221 267 204 minecraft:polished_deepslate
fill 222 266 199 222 267 199 minecraft:polished_deepslate
fill 222 266 201 222 267 201 minecraft:polished_deepslate
fill 222 266 203 222 267 203 minecraft:polished_deepslate
fill 222 266 205 222 267 205 minecraft:polished_deepslate
setblock 223 266 184 minecraft:light[level=12]
setblock 223 266 192 minecraft:light[level=12]
fill 223 266 200 223 267 200 minecraft:polished_deepslate
fill 223 266 202 223 267 202 minecraft:polished_deepslate
fill 223 266 204 223 267 204 minecraft:polished_deepslate
setblock 223 266 208 minecraft:light[level=12]
setblock 223 266 216 minecraft:light[level=12]
fill 224 266 199 224 267 199 minecraft:polished_deepslate
fill 224 266 201 224 267 201 minecraft:polished_deepslate
fill 224 266 203 224 267 203 minecraft:polished_deepslate
fill 224 266 205 224 267 205 minecraft:polished_deepslate
fill 224 266 223 227 271 223 minecraft:crying_obsidian
fill 225 266 200 225 267 200 minecraft:polished_deepslate
fill 225 266 202 225 267 202 minecraft:polished_deepslate
fill 225 266 204 225 267 204 minecraft:polished_deepslate
fill 226 266 199 226 267 199 minecraft:polished_deepslate
fill 226 266 201 226 267 201 minecraft:polished_deepslate
fill 226 266 203 226 267 203 minecraft:polished_deepslate
fill 226 266 205 226 267 205 minecraft:polished_deepslate
fill 227 266 200 227 267 200 minecraft:polished_deepslate
fill 227 266 202 227 267 202 minecraft:polished_deepslate
fill 227 266 204 227 267 204 minecraft:polished_deepslate
fill 228 266 199 229 267 199 minecraft:polished_deepslate
fill 228 266 201 228 267 201 minecraft:polished_deepslate
fill 228 266 203 228 267 203 minecraft:polished_deepslate
fill 228 266 205 228 267 205 minecraft:polished_deepslate
fill 229 266 200 229 267 200 minecraft:polished_deepslate
fill 229 266 202 229 267 202 minecraft:polished_deepslate
fill 229 266 204 229 267 204 minecraft:polished_deepslate
fill 230 266 182 230 271 185 minecraft:crying_obsidian
fill 230 266 194 230 271 197 minecraft:crying_obsidian
fill 230 266 206 230 271 209 minecraft:crying_obsidian
fill 230 266 218 230 271 221 minecraft:crying_obsidian
setblock 220 268 199 minecraft:crying_obsidian
setblock 220 268 201 minecraft:crying_obsidian
setblock 220 268 203 minecraft:crying_obsidian
setblock 220 268 205 minecraft:crying_obsidian
setblock 221 268 200 minecraft:crying_obsidian
setblock 221 268 202 minecraft:crying_obsidian
setblock 221 268 204 minecraft:crying_obsidian
setblock 222 268 199 minecraft:crying_obsidian
setblock 222 268 201 minecraft:crying_obsidian
setblock 222 268 203 minecraft:crying_obsidian
setblock 222 268 205 minecraft:crying_obsidian
setblock 223 268 200 minecraft:crying_obsidian
setblock 223 268 202 minecraft:crying_obsidian
setblock 223 268 204 minecraft:crying_obsidian
setblock 224 268 199 minecraft:crying_obsidian
setblock 224 268 201 minecraft:crying_obsidian
setblock 224 268 203 minecraft:crying_obsidian
setblock 224 268 205 minecraft:crying_obsidian
setblock 225 268 200 minecraft:crying_obsidian
setblock 225 268 202 minecraft:crying_obsidian
setblock 225 268 204 minecraft:crying_obsidian
setblock 226 268 199 minecraft:crying_obsidian
setblock 226 268 201 minecraft:crying_obsidian
setblock 226 268 203 minecraft:crying_obsidian
setblock 226 268 205 minecraft:crying_obsidian
setblock 227 268 200 minecraft:crying_obsidian
setblock 227 268 202 minecraft:crying_obsidian
setblock 227 268 204 minecraft:crying_obsidian
setblock 228 268 199 minecraft:crying_obsidian
setblock 228 268 201 minecraft:crying_obsidian
setblock 228 268 203 minecraft:crying_obsidian
setblock 228 268 205 minecraft:crying_obsidian
fill 229 268 199 229 271 199 minecraft:polished_deepslate
setblock 229 268 200 minecraft:crying_obsidian
setblock 229 268 202 minecraft:crying_obsidian
setblock 229 268 204 minecraft:crying_obsidian
fill 220 269 199 220 271 199 minecraft:polished_deepslate
fill 220 269 201 220 271 201 minecraft:polished_deepslate
fill 220 269 203 220 271 203 minecraft:polished_deepslate
fill 220 269 205 220 271 205 minecraft:polished_deepslate
fill 221 269 200 221 271 200 minecraft:polished_deepslate
fill 221 269 202 221 271 202 minecraft:polished_deepslate
fill 221 269 204 221 271 204 minecraft:polished_deepslate
fill 222 269 199 222 271 199 minecraft:polished_deepslate
fill 222 269 201 222 271 201 minecraft:polished_deepslate
fill 222 269 203 222 271 203 minecraft:polished_deepslate
fill 222 269 205 222 271 205 minecraft:polished_deepslate
fill 223 269 200 223 271 200 minecraft:polished_deepslate
fill 223 269 202 223 271 202 minecraft:polished_deepslate
fill 223 269 204 223 271 204 minecraft:polished_deepslate
fill 224 269 199 224 271 199 minecraft:polished_deepslate
fill 224 269 201 224 271 201 minecraft:polished_deepslate
fill 224 269 203 224 271 203 minecraft:polished_deepslate
fill 224 269 205 224 271 205 minecraft:polished_deepslate
fill 225 269 200 225 271 200 minecraft:polished_deepslate
fill 225 269 202 225 271 202 minecraft:polished_deepslate
fill 225 269 204 225 271 204 minecraft:polished_deepslate
fill 226 269 199 226 271 199 minecraft:polished_deepslate
fill 226 269 201 226 271 201 minecraft:polished_deepslate
fill 226 269 203 226 271 203 minecraft:polished_deepslate
fill 226 269 205 226 271 205 minecraft:polished_deepslate
fill 227 269 200 227 271 200 minecraft:polished_deepslate
fill 227 269 202 227 271 202 minecraft:polished_deepslate
fill 227 269 204 227 271 204 minecraft:polished_deepslate
fill 228 269 199 228 271 199 minecraft:polished_deepslate
fill 228 269 201 228 271 201 minecraft:polished_deepslate
fill 228 269 203 228 271 203 minecraft:polished_deepslate
fill 228 269 205 228 271 205 minecraft:polished_deepslate
fill 229 269 200 229 271 200 minecraft:polished_deepslate
fill 229 269 202 229 271 202 minecraft:polished_deepslate
fill 229 269 204 229 271 204 minecraft:polished_deepslate
fill 188 272 187 188 285 190 minecraft:deepslate_bricks
fill 188 272 199 188 285 202 minecraft:deepslate_bricks
fill 188 272 211 188 285 214 minecraft:deepslate_bricks
fill 188 272 223 191 285 223 minecraft:deepslate_bricks
fill 195 272 181 198 285 181 minecraft:deepslate_bricks
fill 200 272 223 203 285 223 minecraft:deepslate_bricks
fill 207 272 181 210 285 181 minecraft:deepslate_bricks
fill 212 272 223 215 285 223 minecraft:deepslate_bricks
fill 219 272 181 222 285 181 minecraft:deepslate_bricks
fill 224 272 223 227 285 223 minecraft:deepslate_bricks
fill 230 272 182 230 285 185 minecraft:deepslate_bricks
fill 230 272 194 230 285 197 minecraft:deepslate_bricks
fill 230 272 206 230 285 209 minecraft:deepslate_bricks
fill 230 272 218 230 285 221 minecraft:deepslate_bricks
setblock 191 274 184 minecraft:light[level=12]
setblock 191 274 192 minecraft:light[level=12]
setblock 191 274 200 minecraft:light[level=12]
setblock 191 274 208 minecraft:light[level=12]
setblock 191 274 216 minecraft:light[level=12]
setblock 199 274 184 minecraft:light[level=12]
setblock 199 274 192 minecraft:light[level=12]
setblock 199 274 200 minecraft:light[level=12]
setblock 199 274 208 minecraft:light[level=12]
setblock 199 274 216 minecraft:light[level=12]
setblock 207 274 184 minecraft:light[level=12]
setblock 207 274 192 minecraft:light[level=12]
setblock 207 274 200 minecraft:light[level=12]
setblock 207 274 208 minecraft:light[level=12]
setblock 207 274 216 minecraft:light[level=12]
setblock 215 274 184 minecraft:light[level=12]
setblock 215 274 192 minecraft:light[level=12]
setblock 215 274 200 minecraft:light[level=12]
setblock 215 274 208 minecraft:light[level=12]
setblock 215 274 216 minecraft:light[level=12]
setblock 223 274 184 minecraft:light[level=12]
setblock 223 274 192 minecraft:light[level=12]
setblock 223 274 200 minecraft:light[level=12]
setblock 223 274 208 minecraft:light[level=12]
setblock 223 274 216 minecraft:light[level=12]
fill 189 277 182 190 279 192 minecraft:obsidian
fill 189 277 193 229 279 193 minecraft:polished_deepslate
fill 189 277 194 190 279 204 minecraft:obsidian
fill 189 277 205 208 278 205 minecraft:polished_deepslate
fill 189 277 206 190 279 216 minecraft:obsidian
fill 189 277 217 229 279 217 minecraft:polished_deepslate
fill 189 277 218 190 279 222 minecraft:obsidian
fill 191 277 182 191 279 192 minecraft:deepslate_bricks
fill 191 277 194 191 279 204 minecraft:deepslate_bricks
fill 191 277 206 191 279 216 minecraft:deepslate_bricks
fill 191 277 218 191 279 222 minecraft:deepslate_bricks
fill 192 277 182 193 279 192 minecraft:obsidian
fill 192 277 194 193 279 204 minecraft:obsidian
fill 192 277 206 193 279 216 minecraft:obsidian
fill 192 277 218 193 279 222 minecraft:obsidian
fill 194 277 182 194 279 192 minecraft:deepslate_bricks
fill 194 277 194 194 279 204 minecraft:deepslate_bricks
fill 194 277 206 194 279 216 minecraft:deepslate_bricks
fill 194 277 218 194 279 222 minecraft:deepslate_bricks
fill 195 277 182 196 279 192 minecraft:obsidian
fill 195 277 194 196 279 204 minecraft:obsidian
fill 195 277 206 196 279 216 minecraft:obsidian
fill 195 277 218 196 279 222 minecraft:obsidian
fill 197 277 182 197 279 192 minecraft:deepslate_bricks
fill 197 277 194 197 279 204 minecraft:deepslate_bricks
fill 197 277 206 197 279 216 minecraft:deepslate_bricks
fill 197 277 218 197 279 222 minecraft:deepslate_bricks
fill 198 277 182 199 279 192 minecraft:obsidian
fill 198 277 194 199 279 204 minecraft:obsidian
fill 198 277 206 199 279 216 minecraft:obsidian
fill 198 277 218 199 279 222 minecraft:obsidian
fill 200 277 182 200 279 192 minecraft:deepslate_bricks
fill 200 277 194 200 279 204 minecraft:deepslate_bricks
fill 200 277 206 200 279 216 minecraft:deepslate_bricks
fill 200 277 218 200 279 222 minecraft:deepslate_bricks
fill 201 277 182 202 279 192 minecraft:obsidian
fill 201 277 194 202 279 204 minecraft:obsidian
fill 201 277 206 202 279 216 minecraft:obsidian
fill 201 277 218 202 279 222 minecraft:obsidian
fill 203 277 182 203 279 192 minecraft:deepslate_bricks
fill 203 277 194 203 279 204 minecraft:deepslate_bricks
fill 203 277 206 203 279 216 minecraft:deepslate_bricks
fill 203 277 218 203 279 222 minecraft:deepslate_bricks
fill 204 277 182 205 279 192 minecraft:obsidian
fill 204 277 194 205 279 204 minecraft:obsidian
fill 204 277 206 205 279 216 minecraft:obsidian
fill 204 277 218 205 279 222 minecraft:obsidian
fill 206 277 182 206 279 192 minecraft:deepslate_bricks
fill 206 277 194 206 279 204 minecraft:deepslate_bricks
fill 206 277 206 206 279 216 minecraft:deepslate_bricks
fill 206 277 218 206 279 222 minecraft:deepslate_bricks
fill 207 277 182 208 279 192 minecraft:obsidian
fill 207 277 194 207 278 204 minecraft:obsidian
fill 207 277 206 208 278 216 minecraft:obsidian
fill 207 277 218 208 279 222 minecraft:obsidian
fill 208 277 194 208 278 202 minecraft:obsidian
fill 208 277 204 208 278 204 minecraft:obsidian
fill 209 277 182 209 279 192 minecraft:deepslate_bricks
fill 209 277 194 209 278 200 minecraft:deepslate_bricks
fill 209 277 206 209 278 216 minecraft:deepslate_bricks
fill 209 277 218 209 279 222 minecraft:deepslate_bricks
fill 210 277 182 211 279 192 minecraft:obsidian
fill 210 277 194 210 278 200 minecraft:obsidian
fill 210 277 206 210 278 216 minecraft:obsidian
fill 210 277 218 211 279 222 minecraft:obsidian
fill 211 277 194 211 278 199 minecraft:obsidian
fill 211 277 207 211 278 216 minecraft:obsidian
fill 212 277 182 212 279 192 minecraft:deepslate_bricks
fill 212 277 194 212 278 200 minecraft:deepslate_bricks
fill 212 277 206 212 278 216 minecraft:deepslate_bricks
fill 212 277 218 212 279 222 minecraft:deepslate_bricks
fill 213 277 182 214 279 192 minecraft:obsidian
fill 213 277 194 214 278 200 minecraft:obsidian
fill 213 277 206 214 278 216 minecraft:obsidian
fill 213 277 218 214 279 222 minecraft:obsidian
fill 214 277 201 214 278 202 minecraft:obsidian
fill 214 277 204 214 278 204 minecraft:obsidian
fill 214 277 205 229 278 205 minecraft:polished_deepslate
fill 215 277 182 215 279 192 minecraft:deepslate_bricks
fill 215 277 194 215 278 204 minecraft:deepslate_bricks
fill 215 277 206 215 279 216 minecraft:deepslate_bricks
fill 215 277 218 215 279 222 minecraft:deepslate_bricks
fill 216 277 182 217 279 192 minecraft:obsidian
fill 216 277 194 217 279 204 minecraft:obsidian
fill 216 277 206 217 279 216 minecraft:obsidian
fill 216 277 218 217 279 222 minecraft:obsidian
fill 218 277 182 218 279 192 minecraft:deepslate_bricks
fill 218 277 194 218 279 204 minecraft:deepslate_bricks
fill 218 277 206 218 279 216 minecraft:deepslate_bricks
fill 218 277 218 218 279 222 minecraft:deepslate_bricks
fill 219 277 182 220 279 192 minecraft:obsidian
fill 219 277 194 220 279 204 minecraft:obsidian
fill 219 277 206 220 279 216 minecraft:obsidian
fill 219 277 218 220 279 222 minecraft:obsidian
fill 221 277 182 221 279 192 minecraft:deepslate_bricks
fill 221 277 194 221 279 204 minecraft:deepslate_bricks
fill 221 277 206 221 279 216 minecraft:deepslate_bricks
fill 221 277 218 221 279 222 minecraft:deepslate_bricks
fill 222 277 182 223 279 192 minecraft:obsidian
fill 222 277 194 223 279 204 minecraft:obsidian
fill 222 277 206 223 279 216 minecraft:obsidian
fill 222 277 218 223 279 222 minecraft:obsidian
fill 224 277 182 224 279 192 minecraft:deepslate_bricks
fill 224 277 194 224 279 204 minecraft:deepslate_bricks
fill 224 277 206 224 279 216 minecraft:deepslate_bricks
fill 224 277 218 224 279 222 minecraft:deepslate_bricks
fill 225 277 182 226 279 192 minecraft:obsidian
fill 225 277 194 226 279 204 minecraft:obsidian
fill 225 277 206 226 279 216 minecraft:obsidian
fill 225 277 218 226 279 222 minecraft:obsidian
fill 227 277 182 227 279 192 minecraft:deepslate_bricks
fill 227 277 194 227 279 204 minecraft:deepslate_bricks
fill 227 277 206 227 279 216 minecraft:deepslate_bricks
fill 227 277 218 227 279 222 minecraft:deepslate_bricks
fill 228 277 182 229 279 192 minecraft:obsidian
fill 228 277 194 229 279 204 minecraft:obsidian
fill 228 277 206 229 279 216 minecraft:obsidian
fill 228 277 218 229 279 222 minecraft:obsidian
fill 189 279 205 207 279 205 minecraft:polished_deepslate
fill 207 279 194 207 279 201 minecraft:obsidian
fill 207 279 202 207 279 204 minecraft:crying_obsidian
fill 207 279 206 207 279 216 minecraft:obsidian
fill 208 279 194 208 279 199 minecraft:obsidian
fill 208 279 200 208 279 202 minecraft:crying_obsidian
fill 208 279 204 208 279 206 minecraft:crying_obsidian
fill 208 279 207 208 279 216 minecraft:obsidian
fill 209 279 194 209 279 199 minecraft:deepslate_bricks
fill 209 279 200 210 279 200 minecraft:crying_obsidian
fill 209 279 206 210 279 206 minecraft:crying_obsidian
fill 209 279 207 209 279 216 minecraft:deepslate_bricks
fill 210 279 194 211 279 198 minecraft:obsidian
fill 210 279 199 212 279 199 minecraft:crying_obsidian
fill 210 279 207 212 279 207 minecraft:crying_obsidian
fill 210 279 208 211 279 216 minecraft:obsidian
fill 212 279 194 212 279 198 minecraft:deepslate_bricks
fill 212 279 200 214 279 200 minecraft:crying_obsidian
fill 212 279 206 214 279 206 minecraft:crying_obsidian
fill 212 279 208 212 279 216 minecraft:deepslate_bricks
fill 213 279 194 214 279 199 minecraft:obsidian
fill 213 279 207 214 279 216 minecraft:obsidian
fill 214 279 201 214 279 202 minecraft:crying_obsidian
fill 214 279 204 214 279 205 minecraft:crying_obsidian
fill 215 279 194 215 279 201 minecraft:deepslate_bricks
fill 215 279 202 215 279 204 minecraft:crying_obsidian
fill 215 279 205 229 279 205 minecraft:polished_deepslate
setblock 191 282 184 minecraft:light[level=12]
setblock 191 282 192 minecraft:light[level=12]
setblock 191 282 200 minecraft:light[level=12]
setblock 191 282 208 minecraft:light[level=12]
setblock 191 282 216 minecraft:light[level=12]
setblock 199 282 184 minecraft:light[level=12]
setblock 199 282 192 minecraft:light[level=12]
setblock 199 282 200 minecraft:light[level=12]
setblock 199 282 208 minecraft:light[level=12]
setblock 199 282 216 minecraft:light[level=12]
setblock 207 282 184 minecraft:light[level=12]
setblock 207 282 192 minecraft:light[level=12]
setblock 207 282 200 minecraft:light[level=12]
setblock 207 282 208 minecraft:light[level=12]
setblock 207 282 216 minecraft:light[level=12]
setblock 215 282 184 minecraft:light[level=12]
setblock 215 282 192 minecraft:light[level=12]
setblock 215 282 200 minecraft:light[level=12]
setblock 215 282 208 minecraft:light[level=12]
setblock 215 282 216 minecraft:light[level=12]
setblock 223 282 184 minecraft:light[level=12]
setblock 223 282 192 minecraft:light[level=12]
setblock 223 282 200 minecraft:light[level=12]
setblock 223 282 208 minecraft:light[level=12]
setblock 223 282 216 minecraft:light[level=12]
fill 189 283 182 191 300 182 minecraft:polished_deepslate
fill 189 283 192 189 300 194 minecraft:polished_deepslate
fill 189 283 204 189 300 206 minecraft:polished_deepslate
fill 189 283 216 189 300 218 minecraft:polished_deepslate
fill 190 283 191 190 285 193 minecraft:polished_deepslate
fill 190 283 203 190 285 205 minecraft:polished_deepslate
fill 190 283 215 190 285 217 minecraft:polished_deepslate
fill 195 283 222 197 300 222 minecraft:polished_deepslate
fill 196 283 221 198 285 221 minecraft:polished_deepslate
fill 200 283 183 202 285 183 minecraft:polished_deepslate
fill 201 283 182 203 300 182 minecraft:polished_deepslate
fill 207 283 222 209 300 222 minecraft:polished_deepslate
fill 208 283 221 210 285 221 minecraft:polished_deepslate
fill 212 283 183 214 285 183 minecraft:polished_deepslate
fill 213 283 182 215 300 182 minecraft:polished_deepslate
fill 219 283 222 221 300 222 minecraft:polished_deepslate
fill 220 283 221 222 285 221 minecraft:polished_deepslate
fill 224 283 183 226 285 183 minecraft:polished_deepslate
fill 225 283 182 227 300 182 minecraft:polished_deepslate
fill 226 283 214 227 283 216 minecraft:purple_concrete
fill 228 283 191 228 285 193 minecraft:polished_deepslate
fill 228 283 203 228 285 205 minecraft:polished_deepslate
fill 228 283 215 228 285 217 minecraft:polished_deepslate
fill 229 283 190 229 300 192 minecraft:polished_deepslate
fill 229 283 202 229 300 204 minecraft:polished_deepslate
fill 229 283 214 229 285 216 minecraft:polished_deepslate
fill 225 284 212 227 285 218 minecraft:polished_deepslate
fill 228 284 212 228 285 214 minecraft:polished_deepslate
fill 228 284 218 229 284 218 minecraft:polished_deepslate
fill 229 284 212 229 285 213 minecraft:polished_deepslate
fill 229 284 217 229 300 217 minecraft:polished_deepslate
fill 189 285 185 189 285 190 minecraft:obsidian
fill 189 285 197 189 285 202 minecraft:obsidian
fill 189 285 209 189 285 214 minecraft:obsidian
fill 189 285 221 189 285 222 minecraft:obsidian
fill 190 285 222 193 285 222 minecraft:obsidian
fill 193 285 182 198 285 182 minecraft:obsidian
fill 200 285 222 205 285 222 minecraft:obsidian
fill 205 285 182 210 285 182 minecraft:obsidian
fill 212 285 222 217 285 222 minecraft:obsidian
fill 217 285 182 222 285 182 minecraft:obsidian
fill 224 285 222 229 285 222 minecraft:obsidian
fill 228 285 218 228 300 218 minecraft:polished_deepslate
fill 229 285 182 229 285 187 minecraft:obsidian
fill 229 285 194 229 285 199 minecraft:obsidian
fill 229 285 206 229 285 211 minecraft:obsidian
fill 229 285 218 229 285 221 minecraft:obsidian
fill 188 286 187 188 291 190 minecraft:crying_obsidian
fill 188 286 199 188 291 202 minecraft:crying_obsidian
fill 188 286 211 188 291 214 minecraft:crying_obsidian
fill 188 286 223 191 291 223 minecraft:crying_obsidian
fill 195 286 181 198 291 181 minecraft:crying_obsidian
fill 200 286 223 203 291 223 minecraft:crying_obsidian
fill 207 286 181 210 291 181 minecraft:crying_obsidian
fill 212 286 223 215 291 223 minecraft:crying_obsidian
fill 219 286 181 222 291 181 minecraft:crying_obsidian
fill 224 286 223 227 291 223 minecraft:crying_obsidian
setblock 225 286 212 minecraft:crying_obsidian
fill 225 286 213 225 300 213 minecraft:polished_deepslate
setblock 225 286 214 minecraft:crying_obsidian
fill 225 286 215 225 300 215 minecraft:polished_deepslate
setblock 225 286 216 minecraft:crying_obsidian
fill 225 286 217 225 300 217 minecraft:polished_deepslate
setblock 225 286 218 minecraft:crying_obsidian
fill 226 286 212 226 300 212 minecraft:polished_deepslate
setblock 226 286 213 minecraft:crying_obsidian
fill 226 286 214 226 300 214 minecraft:polished_deepslate
setblock 226 286 215 minecraft:crying_obsidian
fill 226 286 216 226 300 216 minecraft:polished_deepslate
setblock 226 286 217 minecraft:crying_obsidian
fill 226 286 218 226 300 218 minecraft:polished_deepslate
setblock 227 286 212 minecraft:crying_obsidian
fill 227 286 213 227 300 213 minecraft:polished_deepslate
setblock 227 286 214 minecraft:crying_obsidian
fill 227 286 215 227 300 215 minecraft:polished_deepslate
setblock 227 286 216 minecraft:crying_obsidian
fill 227 286 217 227 300 217 minecraft:polished_deepslate
setblock 227 286 218 minecraft:crying_obsidian
fill 228 286 212 228 300 212 minecraft:polished_deepslate
setblock 228 286 213 minecraft:crying_obsidian
fill 228 286 214 228 300 214 minecraft:polished_deepslate
setblock 228 286 215 minecraft:crying_obsidian
fill 228 286 216 228 300 216 minecraft:polished_deepslate
setblock 228 286 217 minecraft:crying_obsidian
setblock 229 286 212 minecraft:crying_obsidian
fill 229 286 213 229 300 213 minecraft:polished_deepslate
setblock 229 286 214 minecraft:crying_obsidian
fill 229 286 215 229 300 215 minecraft:polished_deepslate
setblock 229 286 216 minecraft:crying_obsidian
fill 229 286 218 230 286 218 minecraft:crying_obsidian
fill 230 286 182 230 291 185 minecraft:crying_obsidian
fill 230 286 194 230 291 197 minecraft:crying_obsidian
fill 230 286 206 230 291 209 minecraft:crying_obsidian
fill 230 286 219 230 291 221 minecraft:crying_obsidian
fill 225 287 212 225 288 212 minecraft:polished_deepslate
fill 225 287 214 225 288 214 minecraft:polished_deepslate
fill 225 287 216 225 288 216 minecraft:polished_deepslate
fill 225 287 218 225 288 218 minecraft:polished_deepslate
fill 226 287 213 226 288 213 minecraft:polished_deepslate
fill 226 287 215 226 288 215 minecraft:polished_deepslate
fill 226 287 217 226 288 217 minecraft:polished_deepslate
fill 227 287 212 227 288 212 minecraft:polished_deepslate
fill 227 287 214 227 288 214 minecraft:polished_deepslate
fill 227 287 216 227 288 216 minecraft:polished_deepslate
fill 227 287 218 227 288 218 minecraft:polished_deepslate
fill 228 287 213 228 288 213 minecraft:polished_deepslate
fill 228 287 215 228 288 215 minecraft:polished_deepslate
fill 228 287 217 228 288 217 minecraft:polished_deepslate
fill 229 287 212 229 288 212 minecraft:polished_deepslate
fill 229 287 214 229 288 214 minecraft:polished_deepslate
fill 229 287 216 229 288 216 minecraft:polished_deepslate
fill 229 287 218 229 288 218 minecraft:polished_deepslate
fill 230 287 218 230 291 218 minecraft:crying_obsidian
setblock 225 289 212 minecraft:crying_obsidian
setblock 225 289 214 minecraft:crying_obsidian
setblock 225 289 216 minecraft:crying_obsidian
setblock 225 289 218 minecraft:crying_obsidian
setblock 226 289 213 minecraft:crying_obsidian
setblock 226 289 215 minecraft:crying_obsidian
setblock 226 289 217 minecraft:crying_obsidian
setblock 227 289 212 minecraft:crying_obsidian
setblock 227 289 214 minecraft:crying_obsidian
setblock 227 289 216 minecraft:crying_obsidian
setblock 227 289 218 minecraft:crying_obsidian
setblock 228 289 213 minecraft:crying_obsidian
setblock 228 289 215 minecraft:crying_obsidian
setblock 228 289 217 minecraft:crying_obsidian
setblock 229 289 212 minecraft:crying_obsidian
setblock 229 289 214 minecraft:crying_obsidian
setblock 229 289 216 minecraft:crying_obsidian
setblock 229 289 218 minecraft:crying_obsidian
setblock 191 290 184 minecraft:light[level=12]
setblock 191 290 192 minecraft:light[level=12]
setblock 191 290 200 minecraft:light[level=12]
setblock 191 290 208 minecraft:light[level=12]
setblock 191 290 216 minecraft:light[level=12]
setblock 199 290 184 minecraft:light[level=12]
setblock 199 290 192 minecraft:light[level=12]
setblock 199 290 200 minecraft:light[level=12]
setblock 199 290 208 minecraft:light[level=12]
setblock 199 290 216 minecraft:light[level=12]
setblock 207 290 184 minecraft:light[level=12]
setblock 207 290 192 minecraft:light[level=12]
setblock 207 290 200 minecraft:light[level=12]
setblock 207 290 208 minecraft:light[level=12]
setblock 207 290 216 minecraft:light[level=12]
setblock 215 290 184 minecraft:light[level=12]
setblock 215 290 192 minecraft:light[level=12]
setblock 215 290 200 minecraft:light[level=12]
setblock 215 290 208 minecraft:light[level=12]
setblock 215 290 216 minecraft:light[level=12]
setblock 223 290 184 minecraft:light[level=12]
setblock 223 290 192 minecraft:light[level=12]
setblock 223 290 200 minecraft:light[level=12]
setblock 223 290 208 minecraft:light[level=12]
setblock 223 290 216 minecraft:light[level=12]
fill 225 290 212 225 291 212 minecraft:polished_deepslate
fill 225 290 214 225 291 214 minecraft:polished_deepslate
fill 225 290 216 225 291 216 minecraft:polished_deepslate
fill 225 290 218 225 291 218 minecraft:polished_deepslate
fill 226 290 213 226 291 213 minecraft:polished_deepslate
fill 226 290 215 226 291 215 minecraft:polished_deepslate
fill 226 290 217 226 291 217 minecraft:polished_deepslate
fill 227 290 212 227 291 212 minecraft:polished_deepslate
fill 227 290 214 227 291 214 minecraft:polished_deepslate
fill 227 290 216 227 291 216 minecraft:polished_deepslate
fill 227 290 218 227 291 218 minecraft:polished_deepslate
fill 228 290 213 228 291 213 minecraft:polished_deepslate
fill 228 290 215 228 291 215 minecraft:polished_deepslate
fill 228 290 217 228 291 217 minecraft:polished_deepslate
fill 229 290 212 229 291 212 minecraft:polished_deepslate
fill 229 290 214 229 291 214 minecraft:polished_deepslate
fill 229 290 216 229 291 216 minecraft:polished_deepslate
fill 229 290 218 229 291 218 minecraft:polished_deepslate
fill 188 292 187 188 307 187 minecraft:deepslate_bricks
fill 188 292 188 188 292 189 minecraft:crying_obsidian
fill 188 292 190 188 307 190 minecraft:deepslate_bricks
fill 188 292 199 188 307 199 minecraft:deepslate_bricks
fill 188 292 200 188 292 201 minecraft:crying_obsidian
fill 188 292 202 188 307 202 minecraft:deepslate_bricks
fill 188 292 211 188 307 211 minecraft:deepslate_bricks
fill 188 292 212 188 292 213 minecraft:crying_obsidian
fill 188 292 214 188 307 214 minecraft:deepslate_bricks
fill 188 292 223 188 307 223 minecraft:deepslate_bricks
fill 189 292 223 190 292 223 minecraft:crying_obsidian
fill 191 292 223 191 307 223 minecraft:deepslate_bricks
fill 195 292 181 195 307 181 minecraft:deepslate_bricks
fill 196 292 181 197 292 181 minecraft:crying_obsidian
fill 198 292 181 198 307 181 minecraft:deepslate_bricks
fill 200 292 223 200 307 223 minecraft:deepslate_bricks
fill 201 292 223 202 292 223 minecraft:crying_obsidian
fill 203 292 223 203 307 223 minecraft:deepslate_bricks
fill 207 292 181 207 307 181 minecraft:deepslate_bricks
fill 208 292 181 209 292 181 minecraft:crying_obsidian
fill 210 292 181 210 307 181 minecraft:deepslate_bricks
fill 212 292 223 212 307 223 minecraft:deepslate_bricks
fill 213 292 223 214 292 223 minecraft:crying_obsidian
fill 215 292 223 215 307 223 minecraft:deepslate_bricks
fill 219 292 181 219 307 181 minecraft:deepslate_bricks
fill 220 292 181 221 292 181 minecraft:crying_obsidian
fill 222 292 181 222 307 181 minecraft:deepslate_bricks
fill 224 292 223 224 307 223 minecraft:deepslate_bricks
setblock 225 292 212 minecraft:crying_obsidian
setblock 225 292 214 minecraft:crying_obsidian
setblock 225 292 216 minecraft:crying_obsidian
setblock 225 292 218 minecraft:crying_obsidian
fill 225 292 223 226 292 223 minecraft:crying_obsidian
setblock 226 292 213 minecraft:crying_obsidian
setblock 226 292 215 minecraft:crying_obsidian
setblock 226 292 217 minecraft:crying_obsidian
setblock 227 292 212 minecraft:crying_obsidian
setblock 227 292 214 minecraft:crying_obsidian
setblock 227 292 216 minecraft:crying_obsidian
setblock 227 292 218 minecraft:crying_obsidian
fill 227 292 223 227 307 223 minecraft:deepslate_bricks
setblock 228 292 213 minecraft:crying_obsidian
setblock 228 292 215 minecraft:crying_obsidian
setblock 228 292 217 minecraft:crying_obsidian
setblock 229 292 212 minecraft:crying_obsidian
setblock 229 292 214 minecraft:crying_obsidian
setblock 229 292 216 minecraft:crying_obsidian
setblock 229 292 218 minecraft:crying_obsidian
fill 230 292 182 230 307 182 minecraft:deepslate_bricks
fill 230 292 183 230 292 184 minecraft:crying_obsidian
fill 230 292 185 230 307 185 minecraft:deepslate_bricks
fill 230 292 194 230 307 194 minecraft:deepslate_bricks
fill 230 292 195 230 292 196 minecraft:crying_obsidian
fill 230 292 197 230 307 197 minecraft:deepslate_bricks
fill 230 292 206 230 307 206 minecraft:deepslate_bricks
fill 230 292 207 230 292 208 minecraft:crying_obsidian
fill 230 292 209 230 307 209 minecraft:deepslate_bricks
fill 230 292 218 230 307 218 minecraft:deepslate_bricks
fill 230 292 219 230 292 220 minecraft:crying_obsidian
fill 230 292 221 230 307 221 minecraft:deepslate_bricks
fill 188 293 188 188 307 189 minecraft:deepslate_bricks
fill 188 293 200 188 307 201 minecraft:deepslate_bricks
fill 188 293 212 188 307 213 minecraft:deepslate_bricks
fill 189 293 223 190 307 223 minecraft:deepslate_bricks
fill 196 293 181 197 307 181 minecraft:deepslate_bricks
fill 201 293 223 202 307 223 minecraft:deepslate_bricks
fill 208 293 181 209 307 181 minecraft:deepslate_bricks
fill 213 293 223 214 307 223 minecraft:deepslate_bricks
fill 220 293 181 221 307 181 minecraft:deepslate_bricks
fill 225 293 212 225 294 212 minecraft:polished_deepslate
fill 225 293 214 225 294 214 minecraft:polished_deepslate
fill 225 293 216 225 294 216 minecraft:polished_deepslate
fill 225 293 218 225 294 218 minecraft:polished_deepslate
fill 225 293 223 226 307 223 minecraft:deepslate_bricks
fill 226 293 213 226 294 213 minecraft:polished_deepslate
fill 226 293 215 226 294 215 minecraft:polished_deepslate
fill 226 293 217 226 294 217 minecraft:polished_deepslate
fill 227 293 212 227 294 212 minecraft:polished_deepslate
fill 227 293 214 227 294 214 minecraft:polished_deepslate
fill 227 293 216 227 294 216 minecraft:polished_deepslate
fill 227 293 218 227 294 218 minecraft:polished_deepslate
fill 228 293 213 228 294 213 minecraft:polished_deepslate
fill 228 293 215 228 294 215 minecraft:polished_deepslate
fill 228 293 217 228 294 217 minecraft:polished_deepslate
fill 229 293 212 229 294 212 minecraft:polished_deepslate
fill 229 293 214 229 294 214 minecraft:polished_deepslate
fill 229 293 216 229 294 216 minecraft:polished_deepslate
fill 229 293 218 229 294 218 minecraft:polished_deepslate
fill 230 293 183 230 307 184 minecraft:deepslate_bricks
fill 230 293 195 230 307 196 minecraft:deepslate_bricks
fill 230 293 207 230 307 208 minecraft:deepslate_bricks
fill 230 293 219 230 307 220 minecraft:deepslate_bricks
setblock 225 295 212 minecraft:crying_obsidian
setblock 225 295 214 minecraft:crying_obsidian
setblock 225 295 216 minecraft:crying_obsidian
setblock 225 295 218 minecraft:crying_obsidian
setblock 226 295 213 minecraft:crying_obsidian
setblock 226 295 215 minecraft:crying_obsidian
setblock 226 295 217 minecraft:crying_obsidian
setblock 227 295 212 minecraft:crying_obsidian
setblock 227 295 214 minecraft:crying_obsidian
setblock 227 295 216 minecraft:crying_obsidian
setblock 227 295 218 minecraft:crying_obsidian
setblock 228 295 213 minecraft:crying_obsidian
setblock 228 295 215 minecraft:crying_obsidian
setblock 228 295 217 minecraft:crying_obsidian
setblock 229 295 212 minecraft:crying_obsidian
setblock 229 295 214 minecraft:crying_obsidian
setblock 229 295 216 minecraft:crying_obsidian
setblock 229 295 218 minecraft:crying_obsidian
fill 225 296 212 225 297 212 minecraft:polished_deepslate
fill 225 296 214 225 297 214 minecraft:polished_deepslate
fill 225 296 216 225 297 216 minecraft:polished_deepslate
fill 225 296 218 225 297 218 minecraft:polished_deepslate
fill 226 296 213 226 297 213 minecraft:polished_deepslate
fill 226 296 215 226 297 215 minecraft:polished_deepslate
fill 226 296 217 226 297 217 minecraft:polished_deepslate
fill 227 296 212 227 297 212 minecraft:polished_deepslate
fill 227 296 214 227 297 214 minecraft:polished_deepslate
fill 227 296 216 227 297 216 minecraft:polished_deepslate
fill 227 296 218 227 297 218 minecraft:polished_deepslate
fill 228 296 213 228 297 213 minecraft:polished_deepslate
fill 228 296 215 228 297 215 minecraft:polished_deepslate
fill 228 296 217 228 297 217 minecraft:polished_deepslate
fill 229 296 212 229 297 212 minecraft:polished_deepslate
fill 229 296 214 229 297 214 minecraft:polished_deepslate
fill 229 296 216 229 297 216 minecraft:polished_deepslate
fill 229 296 218 229 297 218 minecraft:polished_deepslate
setblock 191 298 184 minecraft:light[level=12]
setblock 191 298 192 minecraft:light[level=12]
setblock 191 298 200 minecraft:light[level=12]
setblock 191 298 208 minecraft:light[level=12]
setblock 191 298 216 minecraft:light[level=12]
setblock 199 298 184 minecraft:light[level=12]
setblock 199 298 192 minecraft:light[level=12]
setblock 199 298 200 minecraft:light[level=12]
setblock 199 298 208 minecraft:light[level=12]
setblock 199 298 216 minecraft:light[level=12]
setblock 207 298 184 minecraft:light[level=12]
setblock 207 298 192 minecraft:light[level=12]
setblock 207 298 200 minecraft:light[level=12]
setblock 207 298 208 minecraft:light[level=12]
setblock 207 298 216 minecraft:light[level=12]
setblock 215 298 184 minecraft:light[level=12]
setblock 215 298 192 minecraft:light[level=12]
setblock 215 298 200 minecraft:light[level=12]
setblock 215 298 208 minecraft:light[level=12]
setblock 215 298 216 minecraft:light[level=12]
setblock 223 298 184 minecraft:light[level=12]
setblock 223 298 192 minecraft:light[level=12]
setblock 223 298 200 minecraft:light[level=12]
setblock 223 298 208 minecraft:light[level=12]
setblock 223 298 216 minecraft:light[level=12]
setblock 225 298 212 minecraft:crying_obsidian
setblock 225 298 214 minecraft:crying_obsidian
setblock 225 298 216 minecraft:crying_obsidian
setblock 225 298 218 minecraft:crying_obsidian
setblock 226 298 213 minecraft:crying_obsidian
setblock 226 298 215 minecraft:crying_obsidian
setblock 226 298 217 minecraft:crying_obsidian
setblock 227 298 212 minecraft:crying_obsidian
setblock 227 298 214 minecraft:crying_obsidian
setblock 227 298 216 minecraft:crying_obsidian
setblock 227 298 218 minecraft:crying_obsidian
setblock 228 298 213 minecraft:crying_obsidian
setblock 228 298 215 minecraft:crying_obsidian
setblock 228 298 217 minecraft:crying_obsidian
setblock 229 298 212 minecraft:crying_obsidian
setblock 229 298 214 minecraft:crying_obsidian
setblock 229 298 216 minecraft:crying_obsidian
setblock 229 298 218 minecraft:crying_obsidian
fill 225 299 212 225 300 212 minecraft:polished_deepslate
fill 225 299 214 225 300 214 minecraft:polished_deepslate
fill 225 299 216 225 300 216 minecraft:polished_deepslate
fill 225 299 218 225 300 218 minecraft:polished_deepslate
fill 226 299 213 226 300 213 minecraft:polished_deepslate
fill 226 299 215 226 300 215 minecraft:polished_deepslate
fill 226 299 217 226 300 217 minecraft:polished_deepslate
fill 227 299 212 227 300 212 minecraft:polished_deepslate
fill 227 299 214 227 300 214 minecraft:polished_deepslate
fill 227 299 216 227 300 216 minecraft:polished_deepslate
fill 227 299 218 227 300 218 minecraft:polished_deepslate
fill 228 299 213 228 300 213 minecraft:polished_deepslate
fill 228 299 215 228 300 215 minecraft:polished_deepslate
fill 228 299 217 228 300 217 minecraft:polished_deepslate
fill 229 299 212 229 300 212 minecraft:polished_deepslate
fill 229 299 214 229 300 214 minecraft:polished_deepslate
fill 229 299 216 229 300 216 minecraft:polished_deepslate
fill 229 299 218 229 300 218 minecraft:polished_deepslate
fill 190 300 191 190 300 193 minecraft:polished_deepslate
fill 190 300 203 190 300 205 minecraft:polished_deepslate
fill 190 300 215 190 300 217 minecraft:polished_deepslate
fill 196 300 221 198 300 221 minecraft:polished_deepslate
fill 200 300 183 202 300 183 minecraft:polished_deepslate
fill 208 300 221 210 300 221 minecraft:polished_deepslate
fill 212 300 183 214 300 183 minecraft:polished_deepslate
fill 220 300 221 222 300 221 minecraft:polished_deepslate
fill 224 300 183 226 300 183 minecraft:polished_deepslate
fill 228 300 191 228 300 193 minecraft:polished_deepslate
fill 228 300 203 228 300 205 minecraft:polished_deepslate
