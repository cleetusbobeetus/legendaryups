setblock 387 232 276 minecraft:shroomlight
fill 387 232 277 387 242 277 minecraft:stripped_oak_log
setblock 387 232 278 minecraft:shroomlight
setblock 387 232 280 minecraft:shroomlight
setblock 387 232 282 minecraft:shroomlight
setblock 387 232 284 minecraft:shroomlight
setblock 388 232 277 minecraft:shroomlight
setblock 388 232 279 minecraft:shroomlight
setblock 388 232 281 minecraft:shroomlight
setblock 388 232 283 minecraft:shroomlight
setblock 389 232 276 minecraft:shroomlight
setblock 389 232 277 minecraft:terracotta
setblock 389 232 278 minecraft:shroomlight
setblock 389 232 279 minecraft:terracotta
setblock 389 232 280 minecraft:shroomlight
setblock 389 232 282 minecraft:shroomlight
setblock 389 232 284 minecraft:shroomlight
setblock 390 232 277 minecraft:shroomlight
fill 390 232 278 391 232 278 minecraft:terracotta
setblock 390 232 279 minecraft:shroomlight
setblock 390 232 281 minecraft:shroomlight
setblock 390 232 283 minecraft:shroomlight
setblock 391 232 277 minecraft:terracotta
setblock 391 232 279 minecraft:terracotta
setblock 392 232 276 minecraft:stripped_oak_log
setblock 392 232 316 minecraft:stripped_oak_log
fill 393 232 276 393 235 276 minecraft:red_terracotta
fill 393 232 316 396 232 316 minecraft:red_terracotta
setblock 397 232 276 minecraft:stripped_oak_log
setblock 397 232 316 minecraft:stripped_oak_log
fill 398 232 276 398 235 276 minecraft:red_terracotta
fill 398 232 316 398 235 316 minecraft:red_terracotta
fill 400 232 276 400 233 276 minecraft:red_terracotta
setblock 400 232 277 minecraft:shroomlight
setblock 400 232 279 minecraft:shroomlight
setblock 400 232 281 minecraft:shroomlight
setblock 401 232 276 minecraft:shroomlight
fill 401 232 277 401 238 277 minecraft:stripped_oak_log
setblock 401 232 278 minecraft:shroomlight
setblock 401 232 280 minecraft:shroomlight
setblock 401 232 282 minecraft:shroomlight
fill 402 232 276 402 238 276 minecraft:stripped_oak_log
setblock 402 232 277 minecraft:shroomlight
setblock 402 232 279 minecraft:shroomlight
setblock 402 232 281 minecraft:shroomlight
setblock 403 232 276 minecraft:shroomlight
setblock 403 232 278 minecraft:shroomlight
setblock 403 232 280 minecraft:shroomlight
setblock 403 232 282 minecraft:shroomlight
fill 404 232 276 404 238 276 minecraft:stripped_oak_log
setblock 404 232 277 minecraft:shroomlight
setblock 404 232 279 minecraft:shroomlight
setblock 404 232 281 minecraft:shroomlight
setblock 405 232 276 minecraft:shroomlight
setblock 405 232 278 minecraft:shroomlight
setblock 405 232 280 minecraft:shroomlight
setblock 405 232 282 minecraft:shroomlight
setblock 406 232 277 minecraft:shroomlight
setblock 406 232 279 minecraft:shroomlight
setblock 406 232 281 minecraft:shroomlight
setblock 407 232 276 minecraft:shroomlight
setblock 407 232 278 minecraft:shroomlight
setblock 407 232 280 minecraft:shroomlight
setblock 407 232 282 minecraft:shroomlight
setblock 408 232 277 minecraft:shroomlight
setblock 408 232 279 minecraft:shroomlight
setblock 408 232 281 minecraft:shroomlight
setblock 409 232 276 minecraft:shroomlight
setblock 409 232 278 minecraft:shroomlight
setblock 409 232 280 minecraft:shroomlight
setblock 409 232 282 minecraft:shroomlight
setblock 410 232 277 minecraft:shroomlight
setblock 410 232 279 minecraft:shroomlight
setblock 410 232 281 minecraft:shroomlight
setblock 411 232 276 minecraft:shroomlight
setblock 411 232 278 minecraft:shroomlight
setblock 411 232 280 minecraft:shroomlight
setblock 411 232 282 minecraft:shroomlight
setblock 412 232 277 minecraft:shroomlight
setblock 412 232 279 minecraft:shroomlight
setblock 412 232 281 minecraft:shroomlight
fill 413 232 276 413 235 276 minecraft:red_terracotta
setblock 413 232 302 minecraft:shroomlight
setblock 413 232 304 minecraft:shroomlight
setblock 413 232 306 minecraft:shroomlight
setblock 413 232 308 minecraft:shroomlight
setblock 413 232 310 minecraft:shroomlight
setblock 413 232 312 minecraft:shroomlight
setblock 413 232 314 minecraft:shroomlight
fill 414 232 277 415 232 277 minecraft:red_terracotta
setblock 414 232 303 minecraft:shroomlight
setblock 414 232 305 minecraft:shroomlight
setblock 414 232 307 minecraft:shroomlight
setblock 414 232 309 minecraft:shroomlight
setblock 414 232 311 minecraft:shroomlight
setblock 414 232 313 minecraft:shroomlight
fill 415 232 279 415 235 279 minecraft:red_terracotta
setblock 415 232 283 minecraft:stripped_oak_log
fill 415 232 284 415 235 284 minecraft:red_terracotta
setblock 415 232 302 minecraft:shroomlight
setblock 415 232 304 minecraft:shroomlight
setblock 415 232 306 minecraft:shroomlight
setblock 415 232 308 minecraft:shroomlight
setblock 415 232 310 minecraft:shroomlight
setblock 415 232 312 minecraft:shroomlight
setblock 415 232 314 minecraft:shroomlight
setblock 416 232 277 minecraft:stripped_oak_log
fill 416 232 278 416 235 278 minecraft:red_terracotta
setblock 416 232 282 minecraft:stripped_oak_log
fill 416 232 283 416 235 283 minecraft:red_terracotta
setblock 416 232 287 minecraft:stripped_oak_log
fill 416 232 288 416 234 289 minecraft:red_terracotta
setblock 416 232 297 minecraft:stripped_oak_log
fill 416 232 298 416 235 298 minecraft:red_terracotta
setblock 416 232 301 minecraft:red_terracotta
setblock 416 232 302 minecraft:stripped_oak_log
setblock 416 232 303 minecraft:shroomlight
fill 416 232 304 416 234 304 minecraft:red_terracotta
setblock 416 232 305 minecraft:shroomlight
setblock 416 232 307 minecraft:shroomlight
setblock 416 232 309 minecraft:shroomlight
setblock 416 232 311 minecraft:shroomlight
setblock 416 232 313 minecraft:shroomlight
setblock 417 232 276 minecraft:stripped_oak_log
fill 417 232 277 417 235 277 minecraft:red_terracotta
setblock 417 232 281 minecraft:stripped_oak_log
fill 417 232 282 417 235 282 minecraft:red_terracotta
setblock 417 232 286 minecraft:stripped_oak_log
fill 417 232 287 417 235 287 minecraft:red_terracotta
setblock 417 232 291 minecraft:stripped_oak_log
fill 417 232 292 417 235 292 minecraft:red_terracotta
setblock 417 232 296 minecraft:stripped_oak_log
fill 417 232 297 417 235 297 minecraft:red_terracotta
setblock 417 232 301 minecraft:stripped_oak_log
setblock 417 232 302 minecraft:shroomlight
setblock 417 232 304 minecraft:shroomlight
setblock 417 232 306 minecraft:shroomlight
fill 417 232 307 417 235 307 minecraft:red_terracotta
setblock 417 232 308 minecraft:shroomlight
setblock 417 232 310 minecraft:shroomlight
setblock 417 232 312 minecraft:shroomlight
setblock 417 232 314 minecraft:shroomlight
fill 418 232 276 418 235 316 minecraft:yellow_terracotta
fill 377 233 276 377 233 279 minecraft:red_terracotta
setblock 377 233 280 minecraft:stripped_oak_log
fill 377 233 281 378 234 281 minecraft:red_terracotta
setblock 377 233 285 minecraft:stripped_oak_log
fill 377 233 286 377 236 286 minecraft:red_terracotta
setblock 377 233 290 minecraft:stripped_oak_log
fill 377 233 291 377 236 291 minecraft:red_terracotta
fill 377 233 296 377 234 296 minecraft:red_terracotta
setblock 377 233 300 minecraft:stripped_oak_log
fill 377 233 301 377 236 301 minecraft:red_terracotta
setblock 377 233 305 minecraft:stripped_oak_log
fill 377 233 306 378 235 306 minecraft:red_terracotta
setblock 377 233 309 minecraft:red_terracotta
setblock 377 233 310 minecraft:stripped_oak_log
fill 377 233 311 377 234 313 minecraft:red_terracotta
setblock 377 233 315 minecraft:stripped_oak_log
fill 377 233 316 380 233 316 minecraft:red_terracotta
fill 378 233 277 378 234 277 minecraft:red_terracotta
setblock 378 233 279 minecraft:stripped_oak_log
fill 378 233 280 379 234 280 minecraft:red_terracotta
setblock 378 233 283 minecraft:red_terracotta
setblock 378 233 284 minecraft:stripped_oak_log
fill 378 233 285 378 236 285 minecraft:red_terracotta
setblock 378 233 304 minecraft:stripped_oak_log
fill 378 233 305 378 236 305 minecraft:red_terracotta
fill 379 233 276 379 234 276 minecraft:red_terracotta
setblock 379 233 278 minecraft:stripped_oak_log
fill 379 233 279 379 236 279 minecraft:red_terracotta
setblock 379 233 282 minecraft:red_terracotta
fill 379 233 283 380 233 283 minecraft:stripped_oak_log
fill 379 233 284 379 234 284 minecraft:red_terracotta
setblock 379 233 285 minecraft:light[level=12]
setblock 379 233 292 minecraft:light[level=12]
setblock 379 233 299 minecraft:light[level=12]
setblock 379 233 306 minecraft:light[level=12]
setblock 379 233 313 minecraft:light[level=12]
setblock 380 233 277 minecraft:stripped_oak_log
fill 380 233 278 381 233 278 minecraft:red_terracotta
fill 380 233 279 380 234 279 minecraft:stripped_oak_log
fill 380 233 281 380 234 281 minecraft:stripped_oak_log
setblock 381 233 276 minecraft:stripped_oak_log
fill 381 233 277 382 234 277 minecraft:red_terracotta
fill 381 233 280 381 234 280 minecraft:stripped_oak_log
fill 381 233 282 381 234 282 minecraft:stripped_oak_log
fill 381 233 284 381 234 284 minecraft:stripped_oak_log
setblock 381 233 316 minecraft:stripped_oak_log
fill 382 233 276 383 234 276 minecraft:red_terracotta
fill 382 233 278 382 234 279 minecraft:stripped_oak_log
fill 382 233 281 382 234 281 minecraft:stripped_oak_log
fill 382 233 283 382 234 283 minecraft:stripped_oak_log
fill 382 233 316 383 235 316 minecraft:red_terracotta
fill 383 233 278 383 234 278 minecraft:stripped_oak_log
fill 383 233 280 383 234 280 minecraft:stripped_oak_log
fill 383 233 282 383 234 282 minecraft:stripped_oak_log
fill 383 233 284 383 234 284 minecraft:stripped_oak_log
fill 384 233 277 384 234 277 minecraft:stripped_oak_log
fill 384 233 279 384 234 279 minecraft:stripped_oak_log
fill 384 233 281 384 234 281 minecraft:stripped_oak_log
fill 384 233 283 384 234 283 minecraft:stripped_oak_log
setblock 385 233 276 minecraft:red_terracotta
fill 385 233 278 385 234 278 minecraft:stripped_oak_log
fill 385 233 280 385 234 280 minecraft:stripped_oak_log
fill 385 233 282 385 234 282 minecraft:stripped_oak_log
fill 385 233 284 385 234 284 minecraft:stripped_oak_log
fill 386 233 276 386 234 277 minecraft:stripped_oak_log
fill 386 233 279 386 234 279 minecraft:stripped_oak_log
fill 386 233 281 386 234 281 minecraft:stripped_oak_log
fill 386 233 283 386 234 283 minecraft:stripped_oak_log
setblock 386 233 285 minecraft:light[level=12]
setblock 386 233 292 minecraft:light[level=12]
setblock 386 233 299 minecraft:light[level=12]
setblock 386 233 306 minecraft:light[level=12]
setblock 386 233 313 minecraft:light[level=12]
fill 387 233 276 387 234 276 minecraft:stripped_oak_log
fill 387 233 278 387 234 278 minecraft:stripped_oak_log
fill 387 233 280 387 234 280 minecraft:stripped_oak_log
fill 387 233 282 387 234 282 minecraft:stripped_oak_log
fill 387 233 284 387 234 284 minecraft:stripped_oak_log
fill 388 233 277 390 234 277 minecraft:stripped_oak_log
fill 388 233 279 390 234 279 minecraft:stripped_oak_log
fill 388 233 281 388 234 281 minecraft:stripped_oak_log
fill 388 233 283 388 234 283 minecraft:stripped_oak_log
fill 389 233 276 389 234 276 minecraft:stripped_oak_log
fill 389 233 278 389 234 278 minecraft:stripped_oak_log
fill 389 233 280 389 234 280 minecraft:stripped_oak_log
fill 389 233 282 389 234 282 minecraft:stripped_oak_log
fill 389 233 284 389 234 284 minecraft:stripped_oak_log
fill 390 233 278 390 239 278 minecraft:green_concrete
fill 390 233 281 390 234 281 minecraft:stripped_oak_log
fill 390 233 283 390 234 283 minecraft:stripped_oak_log
fill 392 233 276 392 236 276 minecraft:red_terracotta
fill 392 233 316 395 233 316 minecraft:red_terracotta
setblock 393 233 278 minecraft:light[level=12]
setblock 393 233 285 minecraft:light[level=12]
setblock 393 233 292 minecraft:light[level=12]
setblock 393 233 299 minecraft:light[level=12]
setblock 393 233 306 minecraft:light[level=12]
setblock 393 233 313 minecraft:light[level=12]
setblock 396 233 276 minecraft:stripped_oak_log
setblock 396 233 316 minecraft:stripped_oak_log
fill 397 233 276 397 236 276 minecraft:red_terracotta
fill 397 233 316 397 236 316 minecraft:red_terracotta
fill 400 233 277 400 234 277 minecraft:stripped_oak_log
fill 400 233 279 400 234 279 minecraft:stripped_oak_log
fill 400 233 281 400 234 281 minecraft:stripped_oak_log
setblock 400 233 285 minecraft:light[level=12]
setblock 400 233 292 minecraft:light[level=12]
setblock 400 233 299 minecraft:light[level=12]
setblock 400 233 306 minecraft:light[level=12]
setblock 400 233 313 minecraft:light[level=12]
fill 401 233 276 401 234 276 minecraft:stripped_oak_log
fill 401 233 278 401 234 278 minecraft:stripped_oak_log
fill 401 233 280 401 234 280 minecraft:stripped_oak_log
fill 401 233 282 401 234 282 minecraft:stripped_oak_log
fill 402 233 277 402 234 277 minecraft:stripped_oak_log
fill 402 233 279 402 234 279 minecraft:stripped_oak_log
fill 402 233 281 402 234 281 minecraft:stripped_oak_log
fill 403 233 276 403 234 276 minecraft:stripped_oak_log
fill 403 233 278 403 234 278 minecraft:stripped_oak_log
fill 403 233 280 403 234 280 minecraft:stripped_oak_log
fill 403 233 282 403 234 282 minecraft:stripped_oak_log
fill 404 233 277 404 234 277 minecraft:stripped_oak_log
fill 404 233 279 404 234 279 minecraft:stripped_oak_log
fill 404 233 281 404 234 281 minecraft:stripped_oak_log
fill 405 233 276 405 234 276 minecraft:stripped_oak_log
fill 405 233 278 405 234 278 minecraft:stripped_oak_log
fill 405 233 280 405 234 280 minecraft:stripped_oak_log
fill 405 233 282 405 234 282 minecraft:stripped_oak_log
fill 406 233 277 406 234 277 minecraft:stripped_oak_log
fill 406 233 279 406 234 279 minecraft:stripped_oak_log
fill 406 233 281 406 234 281 minecraft:stripped_oak_log
fill 407 233 276 407 234 276 minecraft:stripped_oak_log
fill 407 233 278 407 234 278 minecraft:stripped_oak_log
fill 407 233 280 407 234 280 minecraft:stripped_oak_log
fill 407 233 282 407 234 282 minecraft:stripped_oak_log
setblock 407 233 285 minecraft:light[level=12]
setblock 407 233 292 minecraft:light[level=12]
setblock 407 233 299 minecraft:light[level=12]
setblock 407 233 306 minecraft:light[level=12]
setblock 407 233 313 minecraft:light[level=12]
fill 408 233 277 408 234 277 minecraft:stripped_oak_log
fill 408 233 279 408 234 279 minecraft:stripped_oak_log
fill 408 233 281 408 234 281 minecraft:stripped_oak_log
fill 409 233 276 409 234 276 minecraft:stripped_oak_log
fill 409 233 278 409 234 278 minecraft:stripped_oak_log
fill 409 233 280 409 234 280 minecraft:stripped_oak_log
fill 409 233 282 409 234 282 minecraft:stripped_oak_log
fill 410 233 277 410 234 277 minecraft:stripped_oak_log
fill 410 233 279 410 234 279 minecraft:stripped_oak_log
fill 410 233 281 410 234 281 minecraft:stripped_oak_log
fill 411 233 276 411 234 276 minecraft:stripped_oak_log
fill 411 233 278 411 234 278 minecraft:stripped_oak_log
fill 411 233 280 411 234 280 minecraft:stripped_oak_log
fill 411 233 282 411 234 282 minecraft:stripped_oak_log
fill 412 233 277 412 234 277 minecraft:stripped_oak_log
fill 412 233 279 412 234 279 minecraft:stripped_oak_log
fill 412 233 281 412 234 281 minecraft:stripped_oak_log
fill 413 233 302 413 234 302 minecraft:stripped_oak_log
fill 413 233 304 413 234 304 minecraft:stripped_oak_log
fill 413 233 306 413 234 306 minecraft:stripped_oak_log
fill 413 233 308 413 234 308 minecraft:stripped_oak_log
fill 413 233 310 413 234 310 minecraft:stripped_oak_log
fill 413 233 312 413 234 312 minecraft:stripped_oak_log
fill 413 233 314 413 234 314 minecraft:stripped_oak_log
setblock 414 233 277 minecraft:red_terracotta
setblock 414 233 278 minecraft:light[level=12]
setblock 414 233 285 minecraft:light[level=12]
setblock 414 233 292 minecraft:light[level=12]
setblock 414 233 299 minecraft:light[level=12]
fill 414 233 303 414 234 303 minecraft:stripped_oak_log
fill 414 233 305 414 234 305 minecraft:stripped_oak_log
fill 414 233 307 414 234 307 minecraft:stripped_oak_log
fill 414 233 309 414 234 309 minecraft:stripped_oak_log
fill 414 233 311 414 234 311 minecraft:stripped_oak_log
fill 414 233 313 414 234 313 minecraft:stripped_oak_log
setblock 415 233 277 minecraft:stripped_oak_log
fill 415 233 278 415 236 278 minecraft:red_terracotta
fill 415 233 280 415 233 281 minecraft:red_terracotta
setblock 415 233 282 minecraft:stripped_oak_log
fill 415 233 283 415 236 283 minecraft:red_terracotta
fill 415 233 285 415 233 286 minecraft:red_terracotta
fill 415 233 302 415 234 302 minecraft:stripped_oak_log
fill 415 233 304 415 234 304 minecraft:stripped_oak_log
fill 415 233 306 415 234 306 minecraft:stripped_oak_log
fill 415 233 308 415 234 308 minecraft:stripped_oak_log
fill 415 233 310 415 234 310 minecraft:stripped_oak_log
fill 415 233 312 415 234 312 minecraft:stripped_oak_log
fill 415 233 314 415 234 314 minecraft:stripped_oak_log
setblock 416 233 276 minecraft:stripped_oak_log
fill 416 233 277 416 236 277 minecraft:red_terracotta
setblock 416 233 281 minecraft:stripped_oak_log
fill 416 233 282 416 236 282 minecraft:red_terracotta
setblock 416 233 285 minecraft:red_terracotta
setblock 416 233 286 minecraft:stripped_oak_log
fill 416 233 287 416 236 287 minecraft:red_terracotta
setblock 416 233 290 minecraft:red_terracotta
setblock 416 233 291 minecraft:stripped_oak_log
setblock 416 233 296 minecraft:stripped_oak_log
fill 416 233 297 416 236 297 minecraft:red_terracotta
setblock 416 233 301 minecraft:stripped_oak_log
fill 416 233 302 416 234 303 minecraft:red_terracotta
setblock 416 233 305 minecraft:red_terracotta
fill 416 233 307 416 234 307 minecraft:stripped_oak_log
fill 416 233 309 416 234 309 minecraft:stripped_oak_log
fill 416 233 311 416 234 311 minecraft:stripped_oak_log
fill 416 233 313 416 234 313 minecraft:stripped_oak_log
fill 417 233 276 417 236 276 minecraft:red_terracotta
setblock 417 233 280 minecraft:stripped_oak_log
fill 417 233 281 417 236 281 minecraft:red_terracotta
setblock 417 233 285 minecraft:stripped_oak_log
fill 417 233 286 417 236 286 minecraft:red_terracotta
setblock 417 233 290 minecraft:stripped_oak_log
fill 417 233 291 417 236 291 minecraft:red_terracotta
setblock 417 233 295 minecraft:stripped_oak_log
fill 417 233 296 417 236 296 minecraft:red_terracotta
setblock 417 233 300 minecraft:stripped_oak_log
fill 417 233 301 417 234 302 minecraft:red_terracotta
setblock 417 233 304 minecraft:red_terracotta
setblock 417 233 305 minecraft:stripped_oak_log
fill 417 233 306 417 234 306 minecraft:red_terracotta
fill 417 233 308 417 234 308 minecraft:red_terracotta
setblock 417 233 310 minecraft:stripped_oak_log
fill 417 233 312 417 234 312 minecraft:stripped_oak_log
fill 417 233 314 417 234 314 minecraft:stripped_oak_log
fill 377 234 276 377 234 278 minecraft:red_terracotta
setblock 377 234 279 minecraft:stripped_oak_log
fill 377 234 280 377 237 280 minecraft:red_terracotta
setblock 377 234 284 minecraft:stripped_oak_log
fill 377 234 285 377 237 285 minecraft:red_terracotta
setblock 377 234 289 minecraft:stripped_oak_log
fill 377 234 290 377 237 290 minecraft:red_terracotta
setblock 377 234 299 minecraft:stripped_oak_log
fill 377 234 300 377 237 300 minecraft:red_terracotta
setblock 377 234 303 minecraft:red_terracotta
setblock 377 234 304 minecraft:stripped_oak_log
fill 377 234 305 377 237 305 minecraft:red_terracotta
setblock 377 234 309 minecraft:stripped_oak_log
fill 377 234 310 377 237 310 minecraft:red_terracotta
setblock 377 234 314 minecraft:stripped_oak_log
fill 377 234 315 377 236 316 minecraft:red_terracotta
setblock 378 234 278 minecraft:stripped_oak_log
setblock 378 234 279 minecraft:red_terracotta
setblock 378 234 283 minecraft:stripped_oak_log
fill 378 234 284 378 237 284 minecraft:red_terracotta
setblock 378 234 288 minecraft:stripped_oak_log
setblock 378 234 303 minecraft:stripped_oak_log
fill 378 234 304 378 237 304 minecraft:red_terracotta
setblock 378 234 307 minecraft:red_terracotta
setblock 378 234 308 minecraft:stripped_oak_log
fill 378 234 316 379 234 316 minecraft:red_terracotta
setblock 379 234 277 minecraft:stripped_oak_log
fill 379 234 278 380 234 278 minecraft:red_terracotta
setblock 379 234 282 minecraft:stripped_oak_log
fill 379 234 283 379 237 283 minecraft:red_terracotta
fill 379 234 285 379 235 285 minecraft:red_terracotta
setblock 380 234 276 minecraft:stripped_oak_log
setblock 380 234 277 minecraft:red_terracotta
setblock 380 234 283 minecraft:stripped_oak_log
setblock 380 234 316 minecraft:stripped_oak_log
setblock 381 234 276 minecraft:red_terracotta
setblock 381 234 278 minecraft:stripped_oak_log
fill 381 234 316 381 237 316 minecraft:red_terracotta
fill 383 234 277 383 242 277 minecraft:stripped_oak_log
setblock 385 234 276 minecraft:stripped_oak_log
fill 391 234 316 394 234 316 minecraft:red_terracotta
setblock 395 234 276 minecraft:stripped_oak_log
setblock 395 234 316 minecraft:stripped_oak_log
fill 396 234 276 396 237 276 minecraft:red_terracotta
fill 396 234 316 396 237 316 minecraft:red_terracotta
fill 400 234 276 400 238 276 minecraft:stripped_oak_log
fill 402 234 311 402 235 311 minecraft:shroomlight
fill 412 234 276 412 236 276 minecraft:red_terracotta
setblock 413 234 277 minecraft:red_terracotta
setblock 414 234 277 minecraft:stripped_oak_log
fill 414 234 278 414 237 278 minecraft:red_terracotta
setblock 414 234 282 minecraft:stripped_oak_log
fill 414 234 283 414 237 283 minecraft:red_terracotta
setblock 415 234 276 minecraft:stripped_oak_log
fill 415 234 277 415 237 277 minecraft:red_terracotta
setblock 415 234 280 minecraft:red_terracotta
setblock 415 234 281 minecraft:stripped_oak_log
fill 415 234 282 415 237 282 minecraft:red_terracotta
setblock 415 234 285 minecraft:red_terracotta
setblock 415 234 286 minecraft:stripped_oak_log
fill 415 234 287 415 236 288 minecraft:red_terracotta
fill 416 234 276 416 237 276 minecraft:red_terracotta
setblock 416 234 280 minecraft:stripped_oak_log
fill 416 234 281 416 237 281 minecraft:red_terracotta
setblock 416 234 285 minecraft:stripped_oak_log
fill 416 234 286 416 237 286 minecraft:red_terracotta
setblock 416 234 290 minecraft:stripped_oak_log
fill 416 234 291 416 234 294 minecraft:red_terracotta
setblock 416 234 295 minecraft:stripped_oak_log
fill 416 234 296 416 237 296 minecraft:red_terracotta
setblock 416 234 300 minecraft:stripped_oak_log
fill 416 234 301 416 237 301 minecraft:red_terracotta
setblock 416 234 305 minecraft:stripped_oak_log
fill 416 234 306 416 237 306 minecraft:red_terracotta
setblock 417 234 279 minecraft:stripped_oak_log
fill 417 234 280 417 237 280 minecraft:red_terracotta
setblock 417 234 284 minecraft:stripped_oak_log
fill 417 234 285 417 237 285 minecraft:red_terracotta
setblock 417 234 289 minecraft:stripped_oak_log
fill 417 234 290 417 237 290 minecraft:red_terracotta
setblock 417 234 294 minecraft:stripped_oak_log
fill 417 234 295 417 237 295 minecraft:red_terracotta
setblock 417 234 299 minecraft:stripped_oak_log
fill 417 234 300 417 237 300 minecraft:red_terracotta
setblock 417 234 304 minecraft:stripped_oak_log
fill 417 234 305 417 237 305 minecraft:red_terracotta
setblock 417 234 310 minecraft:red_terracotta
fill 377 235 276 377 235 277 minecraft:red_terracotta
setblock 377 235 278 minecraft:stripped_oak_log
fill 377 235 279 377 238 279 minecraft:red_terracotta
fill 377 235 281 377 236 281 minecraft:red_terracotta
setblock 377 235 283 minecraft:stripped_oak_log
fill 377 235 284 377 238 284 minecraft:red_terracotta
setblock 377 235 287 minecraft:red_terracotta
setblock 377 235 288 minecraft:stripped_oak_log
fill 377 235 289 377 238 289 minecraft:red_terracotta
setblock 377 235 292 minecraft:red_terracotta
setblock 377 235 298 minecraft:stripped_oak_log
fill 377 235 299 377 238 299 minecraft:red_terracotta
setblock 377 235 303 minecraft:stripped_oak_log
fill 377 235 304 377 238 304 minecraft:red_terracotta
setblock 377 235 307 minecraft:red_terracotta
setblock 377 235 308 minecraft:stripped_oak_log
fill 377 235 309 378 237 309 minecraft:red_terracotta
fill 377 235 311 377 235 312 minecraft:red_terracotta
setblock 377 235 313 minecraft:stripped_oak_log
fill 377 235 314 377 238 314 minecraft:red_terracotta
setblock 378 235 277 minecraft:shroomlight
fill 378 235 278 378 238 278 minecraft:red_terracotta
setblock 378 235 279 minecraft:shroomlight
fill 378 235 280 378 236 280 minecraft:red_terracotta
setblock 378 235 281 minecraft:shroomlight
setblock 378 235 282 minecraft:stripped_oak_log
setblock 378 235 283 minecraft:shroomlight
setblock 378 235 287 minecraft:stripped_oak_log
fill 378 235 288 378 238 288 minecraft:red_terracotta
setblock 378 235 302 minecraft:stripped_oak_log
fill 378 235 303 378 238 303 minecraft:red_terracotta
setblock 378 235 307 minecraft:stripped_oak_log
fill 378 235 308 378 238 308 minecraft:red_terracotta
fill 378 235 310 378 235 311 minecraft:red_terracotta
setblock 378 235 316 minecraft:red_terracotta
setblock 379 235 276 minecraft:shroomlight
fill 379 235 277 379 238 277 minecraft:red_terracotta
setblock 379 235 278 minecraft:shroomlight
setblock 379 235 280 minecraft:shroomlight
setblock 379 235 281 minecraft:stripped_oak_log
setblock 379 235 282 minecraft:shroomlight
setblock 379 235 284 minecraft:shroomlight
setblock 379 235 316 minecraft:stripped_oak_log
fill 380 235 276 380 238 276 minecraft:red_terracotta
setblock 380 235 277 minecraft:shroomlight
setblock 380 235 278 minecraft:red_terracotta
setblock 380 235 279 minecraft:shroomlight
setblock 380 235 281 minecraft:shroomlight
setblock 380 235 283 minecraft:shroomlight
fill 380 235 316 380 238 316 minecraft:red_terracotta
setblock 381 235 276 minecraft:shroomlight
fill 381 235 277 381 236 277 minecraft:red_terracotta
setblock 381 235 278 minecraft:shroomlight
setblock 381 235 280 minecraft:shroomlight
setblock 381 235 282 minecraft:shroomlight
setblock 381 235 284 minecraft:shroomlight
fill 382 235 276 382 236 276 minecraft:red_terracotta
setblock 382 235 277 minecraft:shroomlight
fill 382 235 278 382 242 278 minecraft:stripped_oak_log
setblock 382 235 279 minecraft:shroomlight
setblock 382 235 281 minecraft:shroomlight
setblock 382 235 283 minecraft:shroomlight
setblock 383 235 276 minecraft:shroomlight
setblock 383 235 278 minecraft:shroomlight
setblock 383 235 280 minecraft:shroomlight
setblock 383 235 282 minecraft:shroomlight
setblock 383 235 284 minecraft:shroomlight
fill 384 235 276 384 242 276 minecraft:stripped_oak_log
setblock 384 235 277 minecraft:shroomlight
setblock 384 235 279 minecraft:shroomlight
setblock 384 235 281 minecraft:shroomlight
setblock 384 235 283 minecraft:shroomlight
setblock 385 235 276 minecraft:shroomlight
setblock 385 235 278 minecraft:shroomlight
setblock 385 235 280 minecraft:shroomlight
setblock 385 235 282 minecraft:shroomlight
setblock 385 235 284 minecraft:shroomlight
fill 386 235 276 386 242 276 minecraft:stripped_oak_log
setblock 386 235 277 minecraft:shroomlight
setblock 386 235 279 minecraft:shroomlight
setblock 386 235 281 minecraft:shroomlight
setblock 386 235 283 minecraft:shroomlight
setblock 387 235 276 minecraft:shroomlight
setblock 387 235 278 minecraft:shroomlight
setblock 387 235 280 minecraft:shroomlight
setblock 387 235 282 minecraft:shroomlight
setblock 387 235 284 minecraft:shroomlight
setblock 388 235 277 minecraft:shroomlight
setblock 388 235 279 minecraft:shroomlight
setblock 388 235 281 minecraft:shroomlight
setblock 388 235 283 minecraft:shroomlight
setblock 389 235 276 minecraft:shroomlight
fill 389 235 277 389 242 277 minecraft:stripped_oak_log
setblock 389 235 278 minecraft:shroomlight
fill 389 235 279 389 242 279 minecraft:stripped_oak_log
setblock 389 235 280 minecraft:shroomlight
setblock 389 235 282 minecraft:shroomlight
setblock 389 235 284 minecraft:shroomlight
setblock 390 235 277 minecraft:shroomlight
setblock 390 235 279 minecraft:shroomlight
setblock 390 235 281 minecraft:shroomlight
setblock 390 235 283 minecraft:shroomlight
fill 390 235 316 393 235 316 minecraft:red_terracotta
fill 391 235 276 391 237 276 minecraft:red_terracotta
setblock 394 235 276 minecraft:stripped_oak_log
setblock 394 235 315 minecraft:red_terracotta
setblock 394 235 316 minecraft:stripped_oak_log
fill 395 235 276 395 238 276 minecraft:red_terracotta
setblock 395 235 315 minecraft:stripped_oak_log
fill 395 235 316 395 238 316 minecraft:red_terracotta
setblock 399 235 276 minecraft:stripped_oak_log
setblock 399 235 316 minecraft:stripped_oak_log
setblock 400 235 277 minecraft:shroomlight
setblock 400 235 279 minecraft:shroomlight
setblock 400 235 281 minecraft:shroomlight
setblock 401 235 276 minecraft:shroomlight
setblock 401 235 278 minecraft:shroomlight
setblock 401 235 280 minecraft:shroomlight
setblock 401 235 282 minecraft:shroomlight
setblock 402 235 277 minecraft:shroomlight
setblock 402 235 279 minecraft:shroomlight
setblock 402 235 281 minecraft:shroomlight
setblock 403 235 276 minecraft:shroomlight
setblock 403 235 278 minecraft:shroomlight
setblock 403 235 280 minecraft:shroomlight
setblock 403 235 282 minecraft:shroomlight
setblock 404 235 277 minecraft:shroomlight
setblock 404 235 279 minecraft:shroomlight
setblock 404 235 281 minecraft:shroomlight
setblock 405 235 276 minecraft:shroomlight
setblock 405 235 278 minecraft:shroomlight
setblock 405 235 280 minecraft:shroomlight
setblock 405 235 282 minecraft:shroomlight
setblock 406 235 277 minecraft:shroomlight
setblock 406 235 279 minecraft:shroomlight
setblock 406 235 281 minecraft:shroomlight
setblock 407 235 276 minecraft:shroomlight
setblock 407 235 278 minecraft:shroomlight
setblock 407 235 280 minecraft:shroomlight
setblock 407 235 282 minecraft:shroomlight
setblock 408 235 277 minecraft:shroomlight
setblock 408 235 279 minecraft:shroomlight
setblock 408 235 281 minecraft:shroomlight
setblock 409 235 276 minecraft:shroomlight
setblock 409 235 278 minecraft:shroomlight
setblock 409 235 280 minecraft:shroomlight
setblock 409 235 282 minecraft:shroomlight
setblock 410 235 277 minecraft:shroomlight
setblock 410 235 279 minecraft:shroomlight
setblock 410 235 281 minecraft:shroomlight
setblock 411 235 276 minecraft:shroomlight
setblock 411 235 278 minecraft:shroomlight
setblock 411 235 280 minecraft:shroomlight
setblock 411 235 282 minecraft:shroomlight
setblock 412 235 277 minecraft:shroomlight
setblock 412 235 279 minecraft:shroomlight
setblock 412 235 281 minecraft:shroomlight
setblock 413 235 277 minecraft:stripped_oak_log
setblock 413 235 302 minecraft:shroomlight
setblock 413 235 304 minecraft:shroomlight
setblock 413 235 306 minecraft:shroomlight
setblock 413 235 308 minecraft:shroomlight
setblock 413 235 310 minecraft:shroomlight
setblock 413 235 312 minecraft:shroomlight
setblock 413 235 314 minecraft:shroomlight
setblock 414 235 276 minecraft:stripped_oak_log
fill 414 235 277 414 238 277 minecraft:red_terracotta
setblock 414 235 280 minecraft:red_terracotta
setblock 414 235 281 minecraft:stripped_oak_log
fill 414 235 282 414 238 282 minecraft:red_terracotta
fill 414 235 284 414 235 285 minecraft:red_terracotta
setblock 414 235 286 minecraft:stripped_oak_log
setblock 414 235 303 minecraft:shroomlight
setblock 414 235 305 minecraft:shroomlight
setblock 414 235 307 minecraft:shroomlight
setblock 414 235 309 minecraft:shroomlight
setblock 414 235 311 minecraft:shroomlight
setblock 414 235 313 minecraft:shroomlight
fill 415 235 276 415 238 276 minecraft:red_terracotta
setblock 415 235 280 minecraft:stripped_oak_log
fill 415 235 281 415 238 281 minecraft:red_terracotta
setblock 415 235 285 minecraft:stripped_oak_log
fill 415 235 286 415 238 286 minecraft:red_terracotta
setblock 415 235 289 minecraft:red_terracotta
setblock 415 235 302 minecraft:shroomlight
fill 415 235 303 415 236 303 minecraft:red_terracotta
setblock 415 235 304 minecraft:shroomlight
setblock 415 235 306 minecraft:shroomlight
setblock 415 235 308 minecraft:shroomlight
setblock 415 235 310 minecraft:shroomlight
setblock 415 235 312 minecraft:shroomlight
setblock 415 235 314 minecraft:shroomlight
setblock 416 235 279 minecraft:stripped_oak_log
fill 416 235 280 416 238 280 minecraft:red_terracotta
setblock 416 235 284 minecraft:stripped_oak_log
fill 416 235 285 416 238 285 minecraft:red_terracotta
setblock 416 235 288 minecraft:red_terracotta
setblock 416 235 289 minecraft:stripped_oak_log
fill 416 235 290 416 235 293 minecraft:red_terracotta
setblock 416 235 294 minecraft:stripped_oak_log
fill 416 235 295 416 238 295 minecraft:red_terracotta
setblock 416 235 299 minecraft:stripped_oak_log
fill 416 235 300 416 238 300 minecraft:red_terracotta
fill 416 235 302 416 236 302 minecraft:red_terracotta
setblock 416 235 303 minecraft:shroomlight
setblock 416 235 304 minecraft:stripped_oak_log
setblock 416 235 305 minecraft:shroomlight
setblock 416 235 307 minecraft:shroomlight
setblock 416 235 308 minecraft:red_terracotta
setblock 416 235 309 minecraft:shroomlight
setblock 416 235 311 minecraft:shroomlight
setblock 416 235 313 minecraft:shroomlight
fill 416 235 316 417 236 316 minecraft:red_terracotta
setblock 417 235 278 minecraft:stripped_oak_log
fill 417 235 279 417 238 279 minecraft:red_terracotta
setblock 417 235 283 minecraft:stripped_oak_log
fill 417 235 284 417 238 284 minecraft:red_terracotta
setblock 417 235 288 minecraft:stripped_oak_log
fill 417 235 289 417 238 289 minecraft:red_terracotta
setblock 417 235 293 minecraft:stripped_oak_log
fill 417 235 294 417 238 294 minecraft:red_terracotta
setblock 417 235 298 minecraft:stripped_oak_log
fill 417 235 299 417 238 299 minecraft:red_terracotta
fill 417 235 301 417 236 301 minecraft:red_terracotta
setblock 417 235 302 minecraft:shroomlight
setblock 417 235 303 minecraft:stripped_oak_log
setblock 417 235 304 minecraft:shroomlight
setblock 417 235 306 minecraft:shroomlight
setblock 417 235 308 minecraft:shroomlight
fill 417 235 309 417 238 309 minecraft:red_terracotta
setblock 417 235 310 minecraft:shroomlight
fill 417 235 311 417 236 311 minecraft:red_terracotta
setblock 417 235 312 minecraft:shroomlight
setblock 417 235 314 minecraft:shroomlight
fill 376 236 275 376 239 317 minecraft:white_terracotta
fill 377 236 275 418 239 275 minecraft:white_terracotta
setblock 377 236 276 minecraft:red_terracotta
setblock 377 236 277 minecraft:stripped_oak_log
fill 377 236 278 377 239 278 minecraft:red_terracotta
setblock 377 236 282 minecraft:stripped_oak_log
fill 377 236 283 378 237 283 minecraft:red_terracotta
setblock 377 236 287 minecraft:stripped_oak_log
fill 377 236 288 377 239 288 minecraft:red_terracotta
setblock 377 236 292 minecraft:stripped_oak_log
fill 377 236 293 377 239 293 minecraft:red_terracotta
setblock 377 236 297 minecraft:stripped_oak_log
fill 377 236 298 377 237 298 minecraft:red_terracotta
setblock 377 236 302 minecraft:stripped_oak_log
fill 377 236 303 377 239 303 minecraft:red_terracotta
setblock 377 236 306 minecraft:red_terracotta
setblock 377 236 307 minecraft:stripped_oak_log
fill 377 236 308 377 239 308 minecraft:red_terracotta
setblock 377 236 311 minecraft:red_terracotta
setblock 377 236 312 minecraft:stripped_oak_log
fill 377 236 313 378 238 313 minecraft:red_terracotta
fill 377 236 317 418 239 317 minecraft:white_terracotta
setblock 378 236 276 minecraft:stripped_oak_log
fill 378 236 277 378 237 277 minecraft:red_terracotta
fill 378 236 279 378 237 279 minecraft:red_terracotta
setblock 378 236 281 minecraft:stripped_oak_log
fill 378 236 282 379 237 282 minecraft:red_terracotta
setblock 378 236 286 minecraft:stripped_oak_log
fill 378 236 287 378 239 287 minecraft:red_terracotta
fill 378 236 289 378 237 289 minecraft:red_terracotta
setblock 378 236 301 minecraft:stripped_oak_log
fill 378 236 302 378 238 302 minecraft:red_terracotta
setblock 378 236 306 minecraft:stripped_oak_log
fill 378 236 307 378 239 307 minecraft:red_terracotta
setblock 378 236 310 minecraft:red_terracotta
setblock 378 236 311 minecraft:stripped_oak_log
fill 378 236 312 378 239 312 minecraft:red_terracotta
fill 378 236 314 378 236 315 minecraft:red_terracotta
setblock 378 236 316 minecraft:stripped_oak_log
fill 379 236 276 379 237 276 minecraft:red_terracotta
fill 379 236 278 379 237 278 minecraft:red_terracotta
setblock 379 236 280 minecraft:stripped_oak_log
fill 379 236 281 379 238 281 minecraft:red_terracotta
setblock 379 236 284 minecraft:red_terracotta
setblock 379 236 285 minecraft:stripped_oak_log
fill 379 236 316 379 239 316 minecraft:red_terracotta
fill 380 236 277 380 237 277 minecraft:red_terracotta
fill 380 236 278 380 237 279 minecraft:stripped_oak_log
fill 380 236 281 380 237 281 minecraft:stripped_oak_log
fill 380 236 283 380 237 283 minecraft:stripped_oak_log
fill 381 236 276 381 237 276 minecraft:red_terracotta
fill 381 236 278 381 237 278 minecraft:stripped_oak_log
fill 381 236 280 381 237 280 minecraft:stripped_oak_log
fill 381 236 282 381 237 282 minecraft:stripped_oak_log
fill 381 236 284 381 237 284 minecraft:stripped_oak_log
fill 382 236 277 382 237 277 minecraft:stripped_oak_log
fill 382 236 279 382 237 279 minecraft:stripped_oak_log
fill 382 236 281 382 237 281 minecraft:stripped_oak_log
fill 382 236 283 382 237 283 minecraft:stripped_oak_log
setblock 382 236 316 minecraft:red_terracotta
setblock 383 236 276 minecraft:stripped_oak_log
fill 383 236 278 383 237 278 minecraft:stripped_oak_log
fill 383 236 280 383 237 280 minecraft:stripped_oak_log
fill 383 236 282 383 237 282 minecraft:stripped_oak_log
fill 383 236 284 383 237 284 minecraft:stripped_oak_log
setblock 383 236 316 minecraft:stripped_oak_log
fill 384 236 277 384 237 277 minecraft:stripped_oak_log
fill 384 236 279 384 237 279 minecraft:stripped_oak_log
fill 384 236 281 384 237 281 minecraft:stripped_oak_log
fill 384 236 283 384 237 283 minecraft:stripped_oak_log
fill 385 236 276 385 237 276 minecraft:stripped_oak_log
fill 385 236 278 385 237 278 minecraft:stripped_oak_log
fill 385 236 280 385 237 280 minecraft:stripped_oak_log
fill 385 236 282 385 237 282 minecraft:stripped_oak_log
fill 385 236 284 385 237 284 minecraft:stripped_oak_log
fill 386 236 277 386 237 277 minecraft:stripped_oak_log
fill 386 236 279 386 237 279 minecraft:stripped_oak_log
fill 386 236 281 386 237 281 minecraft:stripped_oak_log
fill 386 236 283 386 237 283 minecraft:stripped_oak_log
fill 387 236 276 387 237 276 minecraft:stripped_oak_log
fill 387 236 278 387 237 278 minecraft:stripped_oak_log
fill 387 236 280 387 237 280 minecraft:stripped_oak_log
fill 387 236 282 387 237 282 minecraft:stripped_oak_log
fill 387 236 284 387 237 284 minecraft:stripped_oak_log
fill 388 236 277 388 237 277 minecraft:stripped_oak_log
fill 388 236 279 388 237 279 minecraft:stripped_oak_log
fill 388 236 281 388 237 281 minecraft:stripped_oak_log
fill 388 236 283 388 237 283 minecraft:stripped_oak_log
setblock 388 236 316 minecraft:stripped_oak_log
fill 389 236 276 389 237 276 minecraft:stripped_oak_log
fill 389 236 278 389 237 278 minecraft:stripped_oak_log
fill 389 236 280 389 237 280 minecraft:stripped_oak_log
fill 389 236 282 389 237 282 minecraft:stripped_oak_log
fill 389 236 284 389 237 284 minecraft:stripped_oak_log
fill 389 236 316 392 236 316 minecraft:red_terracotta
fill 390 236 277 390 237 277 minecraft:stripped_oak_log
fill 390 236 279 390 237 279 minecraft:stripped_oak_log
fill 390 236 281 390 237 281 minecraft:stripped_oak_log
fill 390 236 283 390 237 283 minecraft:stripped_oak_log
fill 391 236 278 391 238 278 minecraft:green_concrete
fill 392 236 315 393 236 315 minecraft:red_terracotta
setblock 393 236 276 minecraft:stripped_oak_log
setblock 393 236 316 minecraft:stripped_oak_log
fill 394 236 276 394 239 276 minecraft:red_terracotta
fill 394 236 305 398 271 308 minecraft:stripped_oak_log
setblock 394 236 315 minecraft:stripped_oak_log
fill 394 236 316 394 239 316 minecraft:red_terracotta
fill 395 236 304 397 271 304 minecraft:stripped_oak_log
fill 395 236 315 396 238 315 minecraft:red_terracotta
fill 396 236 309 397 271 309 minecraft:stripped_oak_log
setblock 398 236 276 minecraft:stripped_oak_log
setblock 398 236 316 minecraft:stripped_oak_log
fill 400 236 277 400 238 277 minecraft:stripped_oak_log
fill 400 236 279 400 238 279 minecraft:stripped_oak_log
fill 400 236 281 400 238 281 minecraft:stripped_oak_log
fill 401 236 276 401 238 276 minecraft:stripped_oak_log
fill 401 236 278 401 238 278 minecraft:stripped_oak_log
fill 401 236 280 401 238 280 minecraft:stripped_oak_log
fill 401 236 282 401 238 282 minecraft:stripped_oak_log
fill 402 236 277 402 238 277 minecraft:stripped_oak_log
fill 402 236 279 402 238 279 minecraft:stripped_oak_log
fill 402 236 281 402 238 281 minecraft:stripped_oak_log
fill 402 236 311 402 246 311 minecraft:brown_terracotta
fill 403 236 276 403 238 276 minecraft:stripped_oak_log
fill 403 236 278 403 238 278 minecraft:stripped_oak_log
fill 403 236 280 403 238 280 minecraft:stripped_oak_log
fill 403 236 282 403 238 282 minecraft:stripped_oak_log
fill 404 236 277 404 238 277 minecraft:stripped_oak_log
fill 404 236 279 404 238 279 minecraft:stripped_oak_log
fill 404 236 281 404 238 281 minecraft:stripped_oak_log
fill 405 236 276 405 238 276 minecraft:stripped_oak_log
fill 405 236 278 405 238 278 minecraft:stripped_oak_log
fill 405 236 280 405 238 280 minecraft:stripped_oak_log
fill 405 236 282 405 238 282 minecraft:stripped_oak_log
fill 406 236 277 406 238 277 minecraft:stripped_oak_log
fill 406 236 279 406 238 279 minecraft:stripped_oak_log
fill 406 236 281 406 238 281 minecraft:stripped_oak_log
fill 407 236 276 407 238 276 minecraft:stripped_oak_log
fill 407 236 278 407 238 278 minecraft:stripped_oak_log
fill 407 236 280 407 238 280 minecraft:stripped_oak_log
fill 407 236 282 407 238 282 minecraft:stripped_oak_log
fill 408 236 277 408 238 277 minecraft:stripped_oak_log
fill 408 236 279 408 238 279 minecraft:stripped_oak_log
fill 408 236 281 408 238 281 minecraft:stripped_oak_log
fill 409 236 276 409 238 276 minecraft:stripped_oak_log
fill 409 236 278 409 238 278 minecraft:stripped_oak_log
fill 409 236 280 409 238 280 minecraft:stripped_oak_log
fill 409 236 282 409 238 282 minecraft:stripped_oak_log
fill 410 236 277 410 238 277 minecraft:stripped_oak_log
fill 410 236 279 410 238 279 minecraft:stripped_oak_log
fill 410 236 281 410 238 281 minecraft:stripped_oak_log
fill 411 236 276 411 237 276 minecraft:red_terracotta
fill 411 236 278 411 238 278 minecraft:stripped_oak_log
fill 411 236 280 411 238 280 minecraft:stripped_oak_log
fill 411 236 282 411 238 282 minecraft:stripped_oak_log
setblock 412 236 277 minecraft:stripped_oak_log
fill 412 236 279 412 238 279 minecraft:stripped_oak_log
fill 412 236 281 412 238 281 minecraft:stripped_oak_log
setblock 413 236 276 minecraft:stripped_oak_log
fill 413 236 277 413 238 278 minecraft:red_terracotta
fill 413 236 302 413 237 302 minecraft:stripped_oak_log
fill 413 236 304 413 237 304 minecraft:stripped_oak_log
fill 413 236 306 413 237 306 minecraft:stripped_oak_log
fill 413 236 308 413 237 308 minecraft:stripped_oak_log
fill 413 236 310 413 237 310 minecraft:stripped_oak_log
fill 413 236 312 413 237 312 minecraft:stripped_oak_log
fill 413 236 314 413 237 314 minecraft:stripped_oak_log
fill 414 236 276 414 239 276 minecraft:red_terracotta
setblock 414 236 280 minecraft:stripped_oak_log
fill 414 236 281 414 239 281 minecraft:red_terracotta
setblock 414 236 284 minecraft:red_terracotta
setblock 414 236 285 minecraft:stripped_oak_log
fill 414 236 286 414 237 288 minecraft:red_terracotta
fill 414 236 303 414 237 303 minecraft:stripped_oak_log
fill 414 236 305 414 237 305 minecraft:stripped_oak_log
fill 414 236 307 414 237 307 minecraft:stripped_oak_log
fill 414 236 309 414 237 309 minecraft:stripped_oak_log
fill 414 236 311 414 237 311 minecraft:stripped_oak_log
fill 414 236 313 414 237 313 minecraft:stripped_oak_log
setblock 415 236 279 minecraft:stripped_oak_log
fill 415 236 280 415 239 280 minecraft:red_terracotta
setblock 415 236 284 minecraft:stripped_oak_log
fill 415 236 285 415 239 285 minecraft:red_terracotta
setblock 415 236 289 minecraft:stripped_oak_log
fill 415 236 290 416 237 291 minecraft:red_terracotta
fill 415 236 302 415 237 302 minecraft:red_terracotta
setblock 415 236 304 minecraft:stripped_oak_log
fill 415 236 305 416 238 305 minecraft:red_terracotta
setblock 415 236 306 minecraft:stripped_oak_log
fill 415 236 308 416 236 308 minecraft:stripped_oak_log
fill 415 236 310 415 237 310 minecraft:stripped_oak_log
fill 415 236 312 415 237 312 minecraft:stripped_oak_log
fill 415 236 314 415 237 314 minecraft:stripped_oak_log
fill 415 236 316 415 238 316 minecraft:red_terracotta
setblock 416 236 278 minecraft:stripped_oak_log
fill 416 236 279 416 239 279 minecraft:red_terracotta
setblock 416 236 283 minecraft:stripped_oak_log
fill 416 236 284 416 239 284 minecraft:red_terracotta
setblock 416 236 288 minecraft:stripped_oak_log
fill 416 236 289 416 239 289 minecraft:red_terracotta
setblock 416 236 292 minecraft:red_terracotta
setblock 416 236 293 minecraft:stripped_oak_log
fill 416 236 294 416 239 294 minecraft:red_terracotta
setblock 416 236 298 minecraft:stripped_oak_log
fill 416 236 299 416 238 299 minecraft:red_terracotta
setblock 416 236 303 minecraft:stripped_oak_log
fill 416 236 304 417 238 304 minecraft:red_terracotta
setblock 416 236 307 minecraft:red_terracotta
fill 416 236 309 416 239 309 minecraft:red_terracotta
setblock 416 236 311 minecraft:stripped_oak_log
fill 416 236 313 416 237 313 minecraft:stripped_oak_log
setblock 417 236 277 minecraft:stripped_oak_log
fill 417 236 278 417 239 278 minecraft:red_terracotta
setblock 417 236 282 minecraft:stripped_oak_log
fill 417 236 283 417 239 283 minecraft:red_terracotta
setblock 417 236 287 minecraft:stripped_oak_log
fill 417 236 288 417 239 288 minecraft:red_terracotta
setblock 417 236 292 minecraft:stripped_oak_log
fill 417 236 293 417 239 293 minecraft:red_terracotta
setblock 417 236 297 minecraft:stripped_oak_log
fill 417 236 298 417 239 298 minecraft:red_terracotta
setblock 417 236 302 minecraft:stripped_oak_log
fill 417 236 303 417 239 303 minecraft:red_terracotta
setblock 417 236 306 minecraft:red_terracotta
setblock 417 236 307 minecraft:stripped_oak_log
fill 417 236 308 417 239 308 minecraft:red_terracotta
fill 417 236 310 417 237 310 minecraft:red_terracotta
setblock 417 236 312 minecraft:stripped_oak_log
fill 417 236 313 417 237 315 minecraft:red_terracotta
fill 418 236 276 418 239 316 minecraft:white_terracotta
setblock 377 237 276 minecraft:stripped_oak_log
fill 377 237 277 377 240 277 minecraft:red_terracotta
setblock 377 237 281 minecraft:stripped_oak_log
fill 377 237 282 377 240 282 minecraft:red_terracotta
setblock 377 237 286 minecraft:stripped_oak_log
fill 377 237 287 377 240 287 minecraft:red_terracotta
setblock 377 237 291 minecraft:stripped_oak_log
fill 377 237 292 377 240 292 minecraft:red_terracotta
setblock 377 237 301 minecraft:stripped_oak_log
fill 377 237 302 377 240 302 minecraft:red_terracotta
setblock 377 237 306 minecraft:stripped_oak_log
fill 377 237 307 377 240 307 minecraft:red_terracotta
setblock 377 237 311 minecraft:stripped_oak_log
fill 377 237 312 377 240 312 minecraft:red_terracotta
setblock 377 237 315 minecraft:red_terracotta
setblock 377 237 316 minecraft:stripped_oak_log
fill 378 237 276 378 240 276 minecraft:red_terracotta
setblock 378 237 280 minecraft:stripped_oak_log
setblock 378 237 281 minecraft:red_terracotta
setblock 378 237 285 minecraft:stripped_oak_log
fill 378 237 286 378 240 286 minecraft:red_terracotta
setblock 378 237 305 minecraft:stripped_oak_log
fill 378 237 306 379 238 306 minecraft:red_terracotta
setblock 378 237 310 minecraft:stripped_oak_log
fill 378 237 311 378 240 311 minecraft:red_terracotta
setblock 378 237 314 minecraft:red_terracotta
setblock 378 237 315 minecraft:stripped_oak_log
fill 378 237 316 378 240 316 minecraft:red_terracotta
fill 379 237 279 379 242 279 minecraft:stripped_oak_log
setblock 379 237 280 minecraft:red_terracotta
setblock 379 237 284 minecraft:stripped_oak_log
fill 379 237 285 379 238 285 minecraft:red_terracotta
fill 379 237 307 379 237 308 minecraft:red_terracotta
fill 379 237 315 379 240 315 minecraft:red_terracotta
fill 381 237 277 381 242 277 minecraft:stripped_oak_log
setblock 382 237 276 minecraft:stripped_oak_log
setblock 382 237 316 minecraft:stripped_oak_log
setblock 383 237 276 minecraft:red_terracotta
fill 383 237 316 383 240 316 minecraft:red_terracotta
setblock 387 237 316 minecraft:stripped_oak_log
fill 388 237 316 391 237 316 minecraft:red_terracotta
fill 390 237 276 390 238 276 minecraft:red_terracotta
fill 391 237 315 392 237 315 minecraft:red_terracotta
setblock 392 237 276 minecraft:stripped_oak_log
setblock 392 237 316 minecraft:stripped_oak_log
fill 393 237 276 393 240 276 minecraft:red_terracotta
fill 393 237 305 393 238 308 minecraft:brown_terracotta
setblock 393 237 315 minecraft:stripped_oak_log
fill 393 237 316 393 240 316 minecraft:red_terracotta
fill 394 237 304 394 238 304 minecraft:brown_terracotta
fill 394 237 309 395 238 309 minecraft:brown_terracotta
fill 394 237 315 394 240 315 minecraft:red_terracotta
fill 395 237 303 397 238 303 minecraft:brown_terracotta
fill 395 237 310 397 238 310 minecraft:brown_terracotta
setblock 397 237 276 minecraft:stripped_oak_log
setblock 397 237 316 minecraft:stripped_oak_log
fill 398 237 304 399 238 304 minecraft:brown_terracotta
fill 398 237 309 399 238 309 minecraft:brown_terracotta
fill 398 237 316 398 238 316 minecraft:red_terracotta
fill 399 237 305 399 238 308 minecraft:brown_terracotta
fill 402 237 310 403 246 310 minecraft:brown_terracotta
fill 403 237 311 403 246 311 minecraft:brown_terracotta
fill 410 237 276 410 238 276 minecraft:red_terracotta
setblock 412 237 276 minecraft:stripped_oak_log
fill 412 237 277 412 240 277 minecraft:red_terracotta
fill 413 237 276 413 240 276 minecraft:red_terracotta
setblock 413 237 284 minecraft:red_terracotta
setblock 413 237 285 minecraft:stripped_oak_log
fill 414 237 280 414 239 280 minecraft:red_terracotta
setblock 414 237 284 minecraft:stripped_oak_log
fill 414 237 285 414 240 285 minecraft:red_terracotta
setblock 414 237 289 minecraft:stripped_oak_log
fill 414 237 316 414 239 316 minecraft:red_terracotta
setblock 415 237 278 minecraft:stripped_oak_log
fill 415 237 279 415 240 279 minecraft:red_terracotta
setblock 415 237 283 minecraft:stripped_oak_log
fill 415 237 284 415 240 284 minecraft:red_terracotta
setblock 415 237 287 minecraft:red_terracotta
setblock 415 237 288 minecraft:stripped_oak_log
fill 415 237 289 415 240 289 minecraft:red_terracotta
setblock 415 237 303 minecraft:stripped_oak_log
fill 415 237 304 415 238 304 minecraft:red_terracotta
fill 415 237 306 415 237 307 minecraft:red_terracotta
setblock 415 237 308 minecraft:stripped_oak_log
setblock 416 237 277 minecraft:stripped_oak_log
fill 416 237 278 416 240 278 minecraft:red_terracotta
setblock 416 237 282 minecraft:stripped_oak_log
fill 416 237 283 416 240 283 minecraft:red_terracotta
setblock 416 237 287 minecraft:stripped_oak_log
fill 416 237 288 416 240 288 minecraft:red_terracotta
setblock 416 237 292 minecraft:stripped_oak_log
fill 416 237 293 416 240 293 minecraft:red_terracotta
setblock 416 237 297 minecraft:stripped_oak_log
setblock 416 237 298 minecraft:red_terracotta
setblock 416 237 302 minecraft:stripped_oak_log
fill 416 237 303 416 240 303 minecraft:red_terracotta
setblock 416 237 307 minecraft:stripped_oak_log
fill 416 237 308 416 240 308 minecraft:red_terracotta
fill 416 237 310 416 237 311 minecraft:red_terracotta
setblock 416 237 316 minecraft:red_terracotta
setblock 417 237 276 minecraft:stripped_oak_log
fill 417 237 277 417 240 277 minecraft:red_terracotta
setblock 417 237 281 minecraft:stripped_oak_log
fill 417 237 282 417 240 282 minecraft:red_terracotta
setblock 417 237 286 minecraft:stripped_oak_log
fill 417 237 287 417 240 287 minecraft:red_terracotta
setblock 417 237 291 minecraft:stripped_oak_log
fill 417 237 292 417 240 292 minecraft:red_terracotta
setblock 417 237 296 minecraft:stripped_oak_log
fill 417 237 297 417 239 297 minecraft:red_terracotta
setblock 417 237 301 minecraft:stripped_oak_log
fill 417 237 302 417 240 302 minecraft:red_terracotta
setblock 417 237 306 minecraft:stripped_oak_log
fill 417 237 307 417 240 307 minecraft:red_terracotta
setblock 417 237 311 minecraft:stripped_oak_log
fill 417 237 312 417 240 312 minecraft:red_terracotta
setblock 417 237 316 minecraft:stripped_oak_log
fill 377 238 276 377 241 276 minecraft:red_terracotta
setblock 377 238 280 minecraft:stripped_oak_log
fill 377 238 281 377 241 281 minecraft:red_terracotta
fill 377 238 283 377 239 283 minecraft:red_terracotta
setblock 377 238 285 minecraft:stripped_oak_log
fill 377 238 286 377 241 286 minecraft:red_terracotta
setblock 377 238 290 minecraft:stripped_oak_log
fill 377 238 291 377 241 291 minecraft:red_terracotta
setblock 377 238 300 minecraft:stripped_oak_log
fill 377 238 301 377 240 301 minecraft:red_terracotta
setblock 377 238 305 minecraft:stripped_oak_log
fill 377 238 306 377 241 306 minecraft:red_terracotta
setblock 377 238 309 minecraft:red_terracotta
setblock 377 238 310 minecraft:stripped_oak_log
fill 377 238 311 377 241 311 minecraft:red_terracotta
setblock 377 238 315 minecraft:stripped_oak_log
fill 377 238 316 377 241 316 minecraft:red_terracotta
setblock 378 238 277 minecraft:shroomlight
setblock 378 238 279 minecraft:shroomlight
fill 378 238 280 378 240 280 minecraft:red_terracotta
setblock 378 238 281 minecraft:shroomlight
fill 378 238 282 378 239 282 minecraft:red_terracotta
setblock 378 238 283 minecraft:shroomlight
setblock 378 238 284 minecraft:stripped_oak_log
fill 378 238 285 378 241 285 minecraft:red_terracotta
setblock 378 238 289 minecraft:stripped_oak_log
setblock 378 238 304 minecraft:stripped_oak_log
fill 378 238 305 378 241 305 minecraft:red_terracotta
setblock 378 238 309 minecraft:stripped_oak_log
fill 378 238 310 379 240 310 minecraft:red_terracotta
setblock 378 238 314 minecraft:stripped_oak_log
fill 378 238 315 378 241 315 minecraft:red_terracotta
setblock 379 238 276 minecraft:shroomlight
setblock 379 238 278 minecraft:shroomlight
setblock 379 238 280 minecraft:shroomlight
setblock 379 238 282 minecraft:shroomlight
fill 379 238 283 379 242 283 minecraft:stripped_oak_log
setblock 379 238 284 minecraft:shroomlight
setblock 379 238 307 minecraft:red_terracotta
setblock 379 238 308 minecraft:stripped_oak_log
fill 379 238 309 379 240 309 minecraft:red_terracotta
setblock 380 238 277 minecraft:shroomlight
fill 380 238 278 380 242 278 minecraft:stripped_oak_log
setblock 380 238 279 minecraft:shroomlight
setblock 380 238 281 minecraft:shroomlight
setblock 380 238 283 minecraft:shroomlight
setblock 381 238 276 minecraft:shroomlight
setblock 381 238 278 minecraft:shroomlight
setblock 381 238 280 minecraft:shroomlight
setblock 381 238 282 minecraft:shroomlight
setblock 381 238 284 minecraft:shroomlight
setblock 381 238 316 minecraft:stripped_oak_log
setblock 382 238 276 minecraft:red_terracotta
setblock 382 238 277 minecraft:shroomlight
setblock 382 238 279 minecraft:shroomlight
setblock 382 238 281 minecraft:shroomlight
setblock 382 238 283 minecraft:shroomlight
fill 382 238 316 382 241 316 minecraft:red_terracotta
setblock 383 238 276 minecraft:shroomlight
setblock 383 238 278 minecraft:shroomlight
setblock 383 238 280 minecraft:shroomlight
setblock 383 238 282 minecraft:shroomlight
setblock 383 238 284 minecraft:shroomlight
setblock 384 238 277 minecraft:shroomlight
setblock 384 238 279 minecraft:shroomlight
setblock 384 238 281 minecraft:shroomlight
setblock 384 238 283 minecraft:shroomlight
fill 384 238 316 385 238 316 minecraft:red_terracotta
setblock 385 238 276 minecraft:shroomlight
setblock 385 238 278 minecraft:shroomlight
setblock 385 238 280 minecraft:shroomlight
setblock 385 238 282 minecraft:shroomlight
setblock 385 238 284 minecraft:shroomlight
setblock 386 238 277 minecraft:shroomlight
setblock 386 238 279 minecraft:shroomlight
setblock 386 238 281 minecraft:shroomlight
setblock 386 238 283 minecraft:shroomlight
setblock 386 238 316 minecraft:stripped_oak_log
setblock 387 238 276 minecraft:shroomlight
setblock 387 238 278 minecraft:shroomlight
setblock 387 238 280 minecraft:shroomlight
setblock 387 238 282 minecraft:shroomlight
setblock 387 238 284 minecraft:shroomlight
fill 387 238 316 390 238 316 minecraft:red_terracotta
setblock 388 238 277 minecraft:shroomlight
setblock 388 238 279 minecraft:shroomlight
setblock 388 238 281 minecraft:shroomlight
setblock 388 238 283 minecraft:shroomlight
setblock 389 238 276 minecraft:shroomlight
setblock 389 238 278 minecraft:shroomlight
setblock 389 238 280 minecraft:shroomlight
setblock 389 238 282 minecraft:shroomlight
setblock 389 238 284 minecraft:shroomlight
setblock 390 238 277 minecraft:shroomlight
setblock 390 238 279 minecraft:shroomlight
setblock 390 238 281 minecraft:shroomlight
setblock 390 238 283 minecraft:shroomlight
fill 390 238 315 391 238 315 minecraft:red_terracotta
setblock 391 238 276 minecraft:stripped_oak_log
setblock 391 238 316 minecraft:stripped_oak_log
fill 392 238 276 392 240 276 minecraft:red_terracotta
fill 392 238 304 392 238 309 minecraft:brown_terracotta
setblock 392 238 315 minecraft:stripped_oak_log
fill 392 238 316 392 241 316 minecraft:red_terracotta
fill 393 238 303 393 238 304 minecraft:brown_terracotta
fill 393 238 309 393 238 310 minecraft:brown_terracotta
fill 393 238 315 393 241 315 minecraft:red_terracotta
fill 394 238 302 394 238 303 minecraft:brown_terracotta
setblock 394 238 310 minecraft:brown_terracotta
fill 395 238 302 398 238 302 minecraft:brown_terracotta
fill 395 238 311 397 238 311 minecraft:brown_terracotta
setblock 396 238 276 minecraft:stripped_oak_log
setblock 396 238 316 minecraft:stripped_oak_log
fill 397 238 316 397 240 316 minecraft:red_terracotta
fill 398 238 303 399 238 303 minecraft:brown_terracotta
fill 398 238 310 399 238 310 minecraft:brown_terracotta
fill 400 238 304 400 238 309 minecraft:brown_terracotta
fill 401 238 306 401 238 307 minecraft:brown_terracotta
fill 401 238 311 401 246 311 minecraft:brown_terracotta
fill 402 238 312 403 246 312 minecraft:brown_terracotta
setblock 411 238 276 minecraft:stripped_oak_log
fill 411 238 277 411 241 277 minecraft:red_terracotta
fill 412 238 276 412 241 276 minecraft:red_terracotta
setblock 413 238 283 minecraft:red_terracotta
setblock 413 238 284 minecraft:stripped_oak_log
fill 413 238 285 413 239 287 minecraft:red_terracotta
fill 413 238 316 413 240 316 minecraft:red_terracotta
setblock 414 238 278 minecraft:stripped_oak_log
setblock 414 238 283 minecraft:stripped_oak_log
fill 414 238 284 414 241 284 minecraft:red_terracotta
fill 414 238 286 414 238 287 minecraft:red_terracotta
setblock 414 238 288 minecraft:stripped_oak_log
fill 414 238 289 414 240 290 minecraft:red_terracotta
setblock 415 238 277 minecraft:stripped_oak_log
fill 415 238 278 415 240 278 minecraft:red_terracotta
setblock 415 238 282 minecraft:stripped_oak_log
fill 415 238 283 415 241 283 minecraft:red_terracotta
setblock 415 238 287 minecraft:stripped_oak_log
fill 415 238 288 415 241 288 minecraft:red_terracotta
fill 415 238 290 415 238 291 minecraft:red_terracotta
setblock 415 238 292 minecraft:stripped_oak_log
setblock 415 238 303 minecraft:red_terracotta
setblock 415 238 306 minecraft:red_terracotta
setblock 415 238 307 minecraft:stripped_oak_log
fill 415 238 308 415 240 308 minecraft:red_terracotta
setblock 416 238 276 minecraft:stripped_oak_log
fill 416 238 277 416 241 277 minecraft:red_terracotta
setblock 416 238 281 minecraft:stripped_oak_log
fill 416 238 282 416 241 282 minecraft:red_terracotta
setblock 416 238 286 minecraft:stripped_oak_log
fill 416 238 287 416 241 287 minecraft:red_terracotta
setblock 416 238 290 minecraft:red_terracotta
setblock 416 238 291 minecraft:stripped_oak_log
fill 416 238 292 416 241 292 minecraft:red_terracotta
setblock 416 238 301 minecraft:stripped_oak_log
fill 416 238 302 416 239 302 minecraft:red_terracotta
setblock 416 238 306 minecraft:stripped_oak_log
fill 416 238 307 416 241 307 minecraft:red_terracotta
setblock 416 238 310 minecraft:red_terracotta
setblock 416 238 311 minecraft:stripped_oak_log
fill 416 238 312 416 241 312 minecraft:red_terracotta
setblock 416 238 316 minecraft:stripped_oak_log
fill 417 238 276 417 241 276 minecraft:red_terracotta
setblock 417 238 280 minecraft:stripped_oak_log
fill 417 238 281 417 241 281 minecraft:red_terracotta
setblock 417 238 285 minecraft:stripped_oak_log
fill 417 238 286 417 241 286 minecraft:red_terracotta
setblock 417 238 290 minecraft:stripped_oak_log
fill 417 238 291 417 241 291 minecraft:red_terracotta
setblock 417 238 295 minecraft:stripped_oak_log
fill 417 238 296 417 240 296 minecraft:red_terracotta
setblock 417 238 300 minecraft:stripped_oak_log
fill 417 238 301 417 240 301 minecraft:red_terracotta
setblock 417 238 305 minecraft:stripped_oak_log
fill 417 238 306 417 241 306 minecraft:red_terracotta
setblock 417 238 310 minecraft:stripped_oak_log
fill 417 238 311 417 241 311 minecraft:red_terracotta
fill 417 238 313 417 238 314 minecraft:red_terracotta
setblock 417 238 315 minecraft:stripped_oak_log
fill 417 238 316 417 241 316 minecraft:red_terracotta
setblock 377 239 279 minecraft:stripped_oak_log
fill 377 239 280 377 242 280 minecraft:red_terracotta
setblock 377 239 284 minecraft:stripped_oak_log
fill 377 239 285 377 242 285 minecraft:red_terracotta
setblock 377 239 289 minecraft:stripped_oak_log
fill 377 239 290 377 242 290 minecraft:red_terracotta
setblock 377 239 300 minecraft:red_terracotta
setblock 377 239 304 minecraft:stripped_oak_log
fill 377 239 305 377 242 305 minecraft:red_terracotta
setblock 377 239 309 minecraft:stripped_oak_log
fill 377 239 310 377 242 310 minecraft:red_terracotta
setblock 377 239 313 minecraft:red_terracotta
setblock 377 239 314 minecraft:stripped_oak_log
fill 377 239 315 377 242 315 minecraft:red_terracotta
setblock 378 239 277 minecraft:red_terracotta
fill 378 239 278 379 239 278 minecraft:stripped_oak_log
fill 378 239 279 378 240 279 minecraft:red_terracotta
fill 378 239 281 378 240 281 minecraft:red_terracotta
setblock 378 239 283 minecraft:stripped_oak_log
fill 378 239 284 378 241 284 minecraft:red_terracotta
setblock 378 239 288 minecraft:stripped_oak_log
fill 378 239 289 378 240 289 minecraft:red_terracotta
fill 378 239 291 379 240 291 minecraft:iron_bars
setblock 378 239 303 minecraft:stripped_oak_log
fill 378 239 304 378 240 304 minecraft:red_terracotta
fill 378 239 306 378 240 306 minecraft:red_terracotta
setblock 378 239 308 minecraft:stripped_oak_log
fill 378 239 309 378 242 309 minecraft:red_terracotta
setblock 378 239 313 minecraft:stripped_oak_log
fill 378 239 314 378 242 314 minecraft:red_terracotta
setblock 379 239 276 minecraft:red_terracotta
fill 379 239 277 380 240 277 minecraft:stripped_oak_log
fill 379 239 280 379 240 282 minecraft:stripped_oak_log
fill 379 239 284 379 240 284 minecraft:stripped_oak_log
setblock 379 239 285 minecraft:light[level=12]
setblock 379 239 286 minecraft:light[level=15]
setblock 379 239 292 minecraft:light[level=12]
setblock 379 239 294 minecraft:light[level=15]
setblock 379 239 299 minecraft:light[level=12]
setblock 379 239 302 minecraft:light[level=15]
setblock 379 239 306 minecraft:light[level=12]
setblock 379 239 307 minecraft:stripped_oak_log
fill 379 239 308 379 240 308 minecraft:red_terracotta
setblock 379 239 313 minecraft:light[level=12]
setblock 380 239 276 minecraft:stripped_oak_log
fill 380 239 279 380 240 279 minecraft:stripped_oak_log
fill 380 239 281 380 240 281 minecraft:stripped_oak_log
fill 380 239 283 380 240 283 minecraft:stripped_oak_log
setblock 380 239 316 minecraft:stripped_oak_log
setblock 381 239 276 minecraft:red_terracotta
fill 381 239 278 381 240 278 minecraft:stripped_oak_log
fill 381 239 280 381 240 280 minecraft:stripped_oak_log
fill 381 239 282 381 240 282 minecraft:stripped_oak_log
fill 381 239 284 381 240 284 minecraft:stripped_oak_log
fill 381 239 316 381 242 316 minecraft:red_terracotta
fill 382 239 276 382 240 277 minecraft:stripped_oak_log
fill 382 239 279 382 240 279 minecraft:stripped_oak_log
fill 382 239 281 382 240 281 minecraft:stripped_oak_log
fill 382 239 283 382 240 283 minecraft:stripped_oak_log
fill 383 239 276 383 240 276 minecraft:stripped_oak_log
fill 383 239 278 383 240 278 minecraft:stripped_oak_log
fill 383 239 280 383 240 280 minecraft:stripped_oak_log
fill 383 239 282 383 240 282 minecraft:stripped_oak_log
fill 383 239 284 383 240 284 minecraft:stripped_oak_log
fill 384 239 277 384 240 277 minecraft:stripped_oak_log
fill 384 239 279 384 240 279 minecraft:stripped_oak_log
fill 384 239 281 384 240 281 minecraft:stripped_oak_log
fill 384 239 283 384 240 283 minecraft:stripped_oak_log
setblock 384 239 316 minecraft:red_terracotta
fill 385 239 276 385 240 276 minecraft:stripped_oak_log
fill 385 239 278 385 240 278 minecraft:stripped_oak_log
fill 385 239 280 385 240 280 minecraft:stripped_oak_log
fill 385 239 282 385 240 282 minecraft:stripped_oak_log
fill 385 239 284 385 240 284 minecraft:stripped_oak_log
setblock 385 239 316 minecraft:stripped_oak_log
fill 386 239 277 386 240 277 minecraft:stripped_oak_log
fill 386 239 279 386 240 279 minecraft:stripped_oak_log
fill 386 239 281 386 240 281 minecraft:stripped_oak_log
fill 386 239 283 386 240 283 minecraft:stripped_oak_log
setblock 386 239 285 minecraft:light[level=12]
setblock 386 239 292 minecraft:light[level=12]
setblock 386 239 299 minecraft:light[level=12]
setblock 386 239 306 minecraft:light[level=12]
setblock 386 239 313 minecraft:light[level=12]
fill 386 239 316 389 239 316 minecraft:red_terracotta
fill 387 239 276 387 240 276 minecraft:stripped_oak_log
fill 387 239 278 387 240 278 minecraft:stripped_oak_log
fill 387 239 280 387 240 280 minecraft:stripped_oak_log
fill 387 239 282 387 240 282 minecraft:stripped_oak_log
fill 387 239 284 387 240 284 minecraft:stripped_oak_log
setblock 387 239 286 minecraft:light[level=15]
setblock 387 239 294 minecraft:light[level=15]
setblock 387 239 302 minecraft:light[level=15]
setblock 387 239 310 minecraft:light[level=15]
fill 388 239 277 388 240 277 minecraft:stripped_oak_log
fill 388 239 279 388 240 279 minecraft:stripped_oak_log
fill 388 239 281 388 240 281 minecraft:stripped_oak_log
fill 388 239 283 388 240 283 minecraft:stripped_oak_log
fill 389 239 276 390 240 276 minecraft:stripped_oak_log
fill 389 239 278 389 240 278 minecraft:stripped_oak_log
fill 389 239 280 389 240 280 minecraft:stripped_oak_log
fill 389 239 282 389 240 282 minecraft:stripped_oak_log
fill 389 239 284 389 240 284 minecraft:stripped_oak_log
fill 389 239 315 390 239 315 minecraft:red_terracotta
fill 390 239 277 390 240 277 minecraft:stripped_oak_log
fill 390 239 279 390 240 279 minecraft:stripped_oak_log
fill 390 239 281 390 240 281 minecraft:stripped_oak_log
fill 390 239 283 390 240 283 minecraft:stripped_oak_log
setblock 390 239 316 minecraft:stripped_oak_log
fill 391 239 276 391 240 276 minecraft:red_terracotta
setblock 391 239 314 minecraft:red_terracotta
setblock 391 239 315 minecraft:stripped_oak_log
fill 391 239 316 391 242 316 minecraft:red_terracotta
setblock 392 239 314 minecraft:stripped_oak_log
fill 392 239 315 392 242 315 minecraft:red_terracotta
setblock 393 239 278 minecraft:light[level=12]
setblock 393 239 285 minecraft:light[level=12]
setblock 393 239 292 minecraft:light[level=12]
setblock 393 239 299 minecraft:light[level=12]
setblock 393 239 306 minecraft:light[level=12]
setblock 393 239 313 minecraft:light[level=12]
fill 393 239 314 394 240 314 minecraft:red_terracotta
setblock 395 239 276 minecraft:stripped_oak_log
setblock 395 239 278 minecraft:light[level=15]
setblock 395 239 286 minecraft:light[level=15]
setblock 395 239 294 minecraft:light[level=15]
setblock 395 239 302 minecraft:light[level=15]
setblock 395 239 310 minecraft:light[level=15]
setblock 395 239 315 minecraft:red_terracotta
setblock 395 239 316 minecraft:stripped_oak_log
setblock 396 239 315 minecraft:stripped_oak_log
fill 396 239 316 396 242 316 minecraft:red_terracotta
setblock 400 239 278 minecraft:light[level=12]
setblock 400 239 285 minecraft:light[level=12]
setblock 400 239 292 minecraft:light[level=12]
setblock 400 239 299 minecraft:light[level=12]
setblock 400 239 306 minecraft:light[level=12]
setblock 400 239 313 minecraft:light[level=12]
fill 401 239 310 401 246 310 minecraft:brown_terracotta
fill 401 239 312 401 246 312 minecraft:brown_terracotta
fill 402 239 309 403 246 309 minecraft:brown_terracotta
setblock 403 239 278 minecraft:light[level=15]
setblock 403 239 286 minecraft:light[level=15]
setblock 403 239 294 minecraft:light[level=15]
setblock 403 239 302 minecraft:light[level=15]
fill 404 239 310 404 246 311 minecraft:brown_terracotta
setblock 407 239 278 minecraft:light[level=12]
fill 407 239 281 407 240 281 minecraft:iron_bars
setblock 407 239 285 minecraft:light[level=12]
setblock 407 239 292 minecraft:light[level=12]
setblock 407 239 299 minecraft:light[level=12]
setblock 407 239 306 minecraft:light[level=12]
setblock 407 239 313 minecraft:light[level=12]
setblock 410 239 276 minecraft:stripped_oak_log
fill 411 239 276 411 242 276 minecraft:red_terracotta
setblock 411 239 278 minecraft:light[level=15]
setblock 411 239 286 minecraft:light[level=15]
setblock 411 239 294 minecraft:light[level=15]
setblock 411 239 302 minecraft:light[level=15]
setblock 411 239 310 minecraft:light[level=15]
fill 412 239 316 412 241 316 minecraft:red_terracotta
setblock 413 239 277 minecraft:red_terracotta
setblock 413 239 278 minecraft:stripped_oak_log
setblock 413 239 283 minecraft:stripped_oak_log
fill 413 239 284 413 240 284 minecraft:red_terracotta
setblock 414 239 277 minecraft:stripped_oak_log
fill 414 239 278 414 240 278 minecraft:red_terracotta
setblock 414 239 282 minecraft:stripped_oak_log
fill 414 239 283 414 242 283 minecraft:red_terracotta
setblock 414 239 286 minecraft:red_terracotta
setblock 414 239 287 minecraft:stripped_oak_log
fill 414 239 288 414 242 288 minecraft:red_terracotta
setblock 414 239 292 minecraft:light[level=12]
setblock 414 239 299 minecraft:light[level=12]
setblock 414 239 306 minecraft:light[level=12]
setblock 414 239 313 minecraft:light[level=12]
setblock 415 239 276 minecraft:stripped_oak_log
fill 415 239 277 415 242 277 minecraft:red_terracotta
setblock 415 239 281 minecraft:stripped_oak_log
fill 415 239 282 415 242 282 minecraft:red_terracotta
setblock 415 239 286 minecraft:stripped_oak_log
fill 415 239 287 415 242 287 minecraft:red_terracotta
setblock 415 239 290 minecraft:red_terracotta
setblock 415 239 291 minecraft:stripped_oak_log
fill 415 239 292 415 241 292 minecraft:red_terracotta
setblock 415 239 305 minecraft:red_terracotta
setblock 415 239 306 minecraft:stripped_oak_log
fill 415 239 307 415 240 307 minecraft:red_terracotta
setblock 415 239 309 minecraft:red_terracotta
setblock 415 239 316 minecraft:stripped_oak_log
fill 416 239 276 416 242 276 minecraft:red_terracotta
setblock 416 239 280 minecraft:stripped_oak_log
fill 416 239 281 416 242 281 minecraft:red_terracotta
setblock 416 239 285 minecraft:stripped_oak_log
fill 416 239 286 416 242 286 minecraft:red_terracotta
setblock 416 239 290 minecraft:stripped_oak_log
fill 416 239 291 416 242 291 minecraft:red_terracotta
setblock 416 239 301 minecraft:red_terracotta
setblock 416 239 304 minecraft:red_terracotta
setblock 416 239 305 minecraft:stripped_oak_log
fill 416 239 306 416 241 306 minecraft:red_terracotta
setblock 416 239 310 minecraft:stripped_oak_log
fill 416 239 311 416 242 311 minecraft:red_terracotta
fill 416 239 313 417 239 313 minecraft:red_terracotta
fill 416 239 316 416 242 316 minecraft:red_terracotta
setblock 417 239 279 minecraft:stripped_oak_log
fill 417 239 280 417 242 280 minecraft:red_terracotta
setblock 417 239 284 minecraft:stripped_oak_log
fill 417 239 285 417 242 285 minecraft:red_terracotta
setblock 417 239 289 minecraft:stripped_oak_log
fill 417 239 290 417 242 290 minecraft:red_terracotta
setblock 417 239 294 minecraft:stripped_oak_log
fill 417 239 295 417 240 295 minecraft:red_terracotta
setblock 417 239 299 minecraft:stripped_oak_log
fill 417 239 300 417 240 300 minecraft:red_terracotta
setblock 417 239 304 minecraft:stripped_oak_log
fill 417 239 305 417 242 305 minecraft:red_terracotta
setblock 417 239 309 minecraft:stripped_oak_log
fill 417 239 310 417 242 310 minecraft:red_terracotta
setblock 417 239 314 minecraft:stripped_oak_log
fill 417 239 315 417 242 315 minecraft:red_terracotta
fill 376 240 275 376 243 317 minecraft:terracotta
fill 377 240 275 418 242 275 minecraft:terracotta
setblock 377 240 278 minecraft:stripped_oak_log
fill 377 240 279 377 242 279 minecraft:red_terracotta
setblock 377 240 283 minecraft:stripped_oak_log
fill 377 240 284 377 243 284 minecraft:red_terracotta
setblock 377 240 288 minecraft:stripped_oak_log
fill 377 240 289 377 243 289 minecraft:red_terracotta
setblock 377 240 303 minecraft:stripped_oak_log
fill 377 240 304 377 242 304 minecraft:red_terracotta
setblock 377 240 308 minecraft:stripped_oak_log
fill 377 240 309 377 243 309 minecraft:red_terracotta
setblock 377 240 313 minecraft:stripped_oak_log
fill 377 240 314 377 243 314 minecraft:red_terracotta
fill 377 240 317 418 243 317 minecraft:terracotta
setblock 378 240 277 minecraft:stripped_oak_log
setblock 378 240 278 minecraft:red_terracotta
setblock 378 240 282 minecraft:stripped_oak_log
setblock 378 240 283 minecraft:red_terracotta
setblock 378 240 287 minecraft:stripped_oak_log
fill 378 240 288 378 241 288 minecraft:red_terracotta
setblock 378 240 307 minecraft:stripped_oak_log
fill 378 240 308 378 243 308 minecraft:red_terracotta
setblock 378 240 312 minecraft:stripped_oak_log
fill 378 240 313 378 243 313 minecraft:red_terracotta
setblock 379 240 276 minecraft:stripped_oak_log
setblock 379 240 278 minecraft:stripped_oak_log
setblock 379 240 316 minecraft:stripped_oak_log
setblock 380 240 276 minecraft:red_terracotta
fill 380 240 316 380 243 316 minecraft:red_terracotta
setblock 381 240 276 minecraft:stripped_oak_log
setblock 384 240 316 minecraft:stripped_oak_log
fill 385 240 316 388 240 316 minecraft:red_terracotta
fill 388 240 315 389 240 315 minecraft:red_terracotta
setblock 389 240 316 minecraft:stripped_oak_log
fill 390 240 278 390 242 278 minecraft:stripped_oak_log
setblock 390 240 314 minecraft:red_terracotta
setblock 390 240 315 minecraft:stripped_oak_log
fill 390 240 316 390 243 316 minecraft:red_terracotta
setblock 391 240 314 minecraft:stripped_oak_log
fill 391 240 315 391 243 315 minecraft:red_terracotta
fill 392 240 314 392 243 314 minecraft:red_terracotta
setblock 394 240 276 minecraft:stripped_oak_log
setblock 394 240 316 minecraft:stripped_oak_log
setblock 395 240 315 minecraft:stripped_oak_log
fill 395 240 316 395 243 316 minecraft:red_terracotta
fill 400 240 310 400 246 311 minecraft:brown_terracotta
fill 401 240 309 401 246 309 minecraft:brown_terracotta
fill 402 240 313 403 246 313 minecraft:brown_terracotta
fill 404 240 309 404 246 309 minecraft:brown_terracotta
fill 404 240 312 404 246 312 minecraft:brown_terracotta
setblock 409 240 276 minecraft:stripped_oak_log
fill 410 240 276 410 243 276 minecraft:red_terracotta
fill 411 240 316 411 242 316 minecraft:red_terracotta
setblock 413 240 277 minecraft:stripped_oak_log
setblock 413 240 278 minecraft:red_terracotta
fill 413 240 285 413 240 286 minecraft:red_terracotta
setblock 413 240 287 minecraft:stripped_oak_log
setblock 413 240 288 minecraft:red_terracotta
setblock 414 240 276 minecraft:stripped_oak_log
fill 414 240 277 414 243 277 minecraft:red_terracotta
setblock 414 240 281 minecraft:stripped_oak_log
fill 414 240 282 414 241 282 minecraft:red_terracotta
setblock 414 240 286 minecraft:stripped_oak_log
fill 414 240 287 414 243 287 minecraft:red_terracotta
setblock 414 240 316 minecraft:stripped_oak_log
fill 415 240 276 415 243 276 minecraft:red_terracotta
setblock 415 240 280 minecraft:stripped_oak_log
fill 415 240 281 415 242 281 minecraft:red_terracotta
setblock 415 240 285 minecraft:stripped_oak_log
fill 415 240 286 415 243 286 minecraft:red_terracotta
setblock 415 240 290 minecraft:stripped_oak_log
fill 415 240 291 415 242 291 minecraft:red_terracotta
fill 415 240 316 415 243 316 minecraft:red_terracotta
setblock 416 240 279 minecraft:stripped_oak_log
fill 416 240 280 416 243 280 minecraft:red_terracotta
setblock 416 240 284 minecraft:stripped_oak_log
fill 416 240 285 416 243 285 minecraft:red_terracotta
setblock 416 240 289 minecraft:stripped_oak_log
fill 416 240 290 416 243 290 minecraft:red_terracotta
setblock 416 240 294 minecraft:stripped_oak_log
setblock 416 240 304 minecraft:stripped_oak_log
fill 416 240 305 416 241 305 minecraft:red_terracotta
setblock 416 240 309 minecraft:stripped_oak_log
fill 416 240 310 416 243 310 minecraft:red_terracotta
setblock 416 240 313 minecraft:red_terracotta
setblock 417 240 278 minecraft:stripped_oak_log
fill 417 240 279 417 243 279 minecraft:red_terracotta
setblock 417 240 283 minecraft:stripped_oak_log
fill 417 240 284 417 243 284 minecraft:red_terracotta
setblock 417 240 288 minecraft:stripped_oak_log
fill 417 240 289 417 243 289 minecraft:red_terracotta
setblock 417 240 293 minecraft:stripped_oak_log
fill 417 240 294 417 242 294 minecraft:red_terracotta
setblock 417 240 303 minecraft:stripped_oak_log
fill 417 240 304 417 241 304 minecraft:red_terracotta
setblock 417 240 308 minecraft:stripped_oak_log
fill 417 240 309 417 243 309 minecraft:red_terracotta
setblock 417 240 313 minecraft:stripped_oak_log
fill 417 240 314 417 243 314 minecraft:red_terracotta
fill 418 240 276 418 243 316 minecraft:terracotta
setblock 377 241 277 minecraft:stripped_oak_log
fill 377 241 278 377 242 278 minecraft:red_terracotta
setblock 377 241 282 minecraft:stripped_oak_log
fill 377 241 283 377 243 283 minecraft:red_terracotta
setblock 377 241 287 minecraft:stripped_oak_log
fill 377 241 288 377 244 288 minecraft:red_terracotta
setblock 377 241 292 minecraft:stripped_oak_log
setblock 377 241 303 minecraft:red_terracotta
setblock 377 241 307 minecraft:stripped_oak_log
fill 377 241 308 377 244 308 minecraft:red_terracotta
setblock 377 241 312 minecraft:stripped_oak_log
fill 377 241 313 377 244 313 minecraft:red_terracotta
fill 378 241 276 378 242 276 minecraft:stripped_oak_log
setblock 378 241 277 minecraft:shroomlight
fill 378 241 278 378 242 278 minecraft:stripped_oak_log
setblock 378 241 279 minecraft:shroomlight
fill 378 241 280 378 242 280 minecraft:stripped_oak_log
setblock 378 241 281 minecraft:shroomlight
setblock 378 241 282 minecraft:red_terracotta
setblock 378 241 283 minecraft:shroomlight
setblock 378 241 286 minecraft:stripped_oak_log
setblock 378 241 287 minecraft:red_terracotta
setblock 378 241 306 minecraft:stripped_oak_log
fill 378 241 307 378 242 307 minecraft:red_terracotta
setblock 378 241 310 minecraft:red_terracotta
setblock 378 241 311 minecraft:stripped_oak_log
fill 378 241 312 378 244 312 minecraft:red_terracotta
setblock 378 241 316 minecraft:stripped_oak_log
setblock 379 241 276 minecraft:shroomlight
fill 379 241 277 379 242 277 minecraft:stripped_oak_log
setblock 379 241 278 minecraft:shroomlight
setblock 379 241 280 minecraft:shroomlight
fill 379 241 281 379 242 281 minecraft:stripped_oak_log
setblock 379 241 282 minecraft:shroomlight
setblock 379 241 284 minecraft:shroomlight
fill 379 241 316 379 244 316 minecraft:red_terracotta
fill 380 241 276 380 242 276 minecraft:stripped_oak_log
setblock 380 241 277 minecraft:shroomlight
setblock 380 241 279 minecraft:shroomlight
setblock 380 241 281 minecraft:shroomlight
setblock 380 241 283 minecraft:shroomlight
setblock 381 241 276 minecraft:shroomlight
setblock 381 241 278 minecraft:shroomlight
setblock 381 241 280 minecraft:shroomlight
setblock 381 241 282 minecraft:shroomlight
setblock 381 241 284 minecraft:shroomlight
fill 382 241 276 382 242 276 minecraft:stripped_oak_log
setblock 382 241 277 minecraft:shroomlight
setblock 382 241 279 minecraft:shroomlight
setblock 382 241 281 minecraft:shroomlight
setblock 382 241 283 minecraft:shroomlight
setblock 383 241 276 minecraft:shroomlight
setblock 383 241 278 minecraft:shroomlight
setblock 383 241 280 minecraft:shroomlight
setblock 383 241 282 minecraft:shroomlight
setblock 383 241 284 minecraft:shroomlight
setblock 383 241 316 minecraft:stripped_oak_log
setblock 384 241 277 minecraft:shroomlight
setblock 384 241 279 minecraft:shroomlight
setblock 384 241 281 minecraft:shroomlight
setblock 384 241 283 minecraft:shroomlight
fill 384 241 316 387 241 316 minecraft:red_terracotta
setblock 385 241 276 minecraft:shroomlight
setblock 385 241 278 minecraft:shroomlight
setblock 385 241 280 minecraft:shroomlight
setblock 385 241 282 minecraft:shroomlight
setblock 385 241 284 minecraft:shroomlight
setblock 386 241 277 minecraft:shroomlight
setblock 386 241 279 minecraft:shroomlight
setblock 386 241 281 minecraft:shroomlight
setblock 386 241 283 minecraft:shroomlight
setblock 387 241 276 minecraft:shroomlight
setblock 387 241 278 minecraft:shroomlight
setblock 387 241 280 minecraft:shroomlight
setblock 387 241 282 minecraft:shroomlight
setblock 387 241 284 minecraft:shroomlight
fill 387 241 315 388 241 315 minecraft:red_terracotta
setblock 388 241 277 minecraft:shroomlight
setblock 388 241 279 minecraft:shroomlight
setblock 388 241 281 minecraft:shroomlight
setblock 388 241 283 minecraft:shroomlight
setblock 388 241 316 minecraft:stripped_oak_log
setblock 389 241 276 minecraft:shroomlight
setblock 389 241 278 minecraft:shroomlight
setblock 389 241 280 minecraft:shroomlight
setblock 389 241 282 minecraft:shroomlight
setblock 389 241 284 minecraft:shroomlight
setblock 389 241 315 minecraft:stripped_oak_log
fill 389 241 316 389 244 316 minecraft:red_terracotta
fill 390 241 276 390 242 276 minecraft:stripped_oak_log
setblock 390 241 277 minecraft:shroomlight
setblock 390 241 279 minecraft:shroomlight
setblock 390 241 281 minecraft:shroomlight
setblock 390 241 283 minecraft:shroomlight
setblock 390 241 314 minecraft:stripped_oak_log
fill 390 241 315 390 244 315 minecraft:red_terracotta
fill 391 241 314 391 244 314 minecraft:red_terracotta
fill 393 241 314 393 242 314 minecraft:red_terracotta
setblock 393 241 316 minecraft:stripped_oak_log
setblock 394 241 315 minecraft:stripped_oak_log
fill 394 241 316 394 244 316 minecraft:red_terracotta
setblock 395 241 315 minecraft:red_terracotta
fill 400 241 309 400 246 309 minecraft:brown_terracotta
fill 400 241 312 400 246 312 minecraft:brown_terracotta
fill 401 241 313 401 246 313 minecraft:brown_terracotta
fill 402 241 276 408 241 281 minecraft:brown_terracotta
fill 402 241 308 403 246 308 minecraft:brown_terracotta
fill 404 241 313 404 246 313 minecraft:brown_terracotta
fill 405 241 310 405 246 312 minecraft:brown_terracotta
fill 409 241 276 409 244 276 minecraft:red_terracotta
fill 409 241 277 410 241 281 minecraft:brown_terracotta
fill 411 241 278 412 241 281 minecraft:brown_terracotta
setblock 412 241 277 minecraft:stripped_oak_log
setblock 413 241 276 minecraft:stripped_oak_log
fill 413 241 277 413 243 277 minecraft:red_terracotta
setblock 413 241 286 minecraft:stripped_oak_log
setblock 413 241 287 minecraft:red_terracotta
setblock 413 241 316 minecraft:stripped_oak_log
fill 414 241 276 414 244 276 minecraft:red_terracotta
setblock 414 241 285 minecraft:stripped_oak_log
fill 414 241 286 414 243 286 minecraft:red_terracotta
setblock 414 241 289 minecraft:red_terracotta
setblock 414 241 290 minecraft:stripped_oak_log
fill 414 241 316 414 244 316 minecraft:red_terracotta
setblock 415 241 279 minecraft:stripped_oak_log
setblock 415 241 280 minecraft:red_terracotta
setblock 415 241 284 minecraft:stripped_oak_log
fill 415 241 285 415 244 285 minecraft:red_terracotta
setblock 415 241 289 minecraft:stripped_oak_log
fill 415 241 290 415 243 290 minecraft:red_terracotta
setblock 416 241 278 minecraft:stripped_oak_log
fill 416 241 279 416 242 279 minecraft:red_terracotta
setblock 416 241 283 minecraft:stripped_oak_log
fill 416 241 284 416 244 284 minecraft:red_terracotta
setblock 416 241 288 minecraft:stripped_oak_log
fill 416 241 289 416 244 289 minecraft:red_terracotta
setblock 416 241 293 minecraft:stripped_oak_log
setblock 416 241 308 minecraft:stripped_oak_log
fill 416 241 309 416 242 309 minecraft:red_terracotta
setblock 416 241 313 minecraft:stripped_oak_log
setblock 417 241 277 minecraft:stripped_oak_log
fill 417 241 278 417 244 278 minecraft:red_terracotta
setblock 417 241 282 minecraft:stripped_oak_log
fill 417 241 283 417 244 283 minecraft:red_terracotta
setblock 417 241 287 minecraft:stripped_oak_log
fill 417 241 288 417 244 288 minecraft:red_terracotta
setblock 417 241 292 minecraft:stripped_oak_log
fill 417 241 293 417 243 293 minecraft:red_terracotta
setblock 417 241 303 minecraft:red_terracotta
setblock 417 241 307 minecraft:stripped_oak_log
fill 417 241 308 417 244 308 minecraft:red_terracotta
setblock 417 241 312 minecraft:stripped_oak_log
fill 417 241 313 417 244 313 minecraft:red_terracotta
setblock 377 242 276 minecraft:stripped_oak_log
setblock 377 242 277 minecraft:red_terracotta
fill 377 242 281 378 242 281 minecraft:stripped_oak_log
fill 377 242 282 377 243 282 minecraft:red_terracotta
setblock 377 242 286 minecraft:stripped_oak_log
fill 377 242 287 377 244 287 minecraft:red_terracotta
setblock 377 242 291 minecraft:stripped_oak_log
setblock 377 242 306 minecraft:stripped_oak_log
fill 377 242 307 377 245 307 minecraft:red_terracotta
setblock 377 242 311 minecraft:stripped_oak_log
fill 377 242 312 377 245 312 minecraft:red_terracotta
setblock 377 242 316 minecraft:stripped_oak_log
setblock 378 242 277 minecraft:stripped_oak_log
setblock 378 242 279 minecraft:stripped_oak_log
fill 378 242 282 378 242 284 minecraft:stripped_oak_log
setblock 378 242 310 minecraft:stripped_oak_log
fill 378 242 311 378 245 311 minecraft:red_terracotta
setblock 378 242 315 minecraft:stripped_oak_log
fill 378 242 316 378 245 316 minecraft:red_terracotta
setblock 379 242 276 minecraft:stripped_oak_log
setblock 379 242 278 minecraft:stripped_oak_log
setblock 379 242 280 minecraft:stripped_oak_log
setblock 379 242 282 minecraft:stripped_oak_log
setblock 379 242 284 minecraft:stripped_oak_log
setblock 380 242 277 minecraft:stripped_oak_log
setblock 380 242 279 minecraft:stripped_oak_log
setblock 380 242 281 minecraft:stripped_oak_log
setblock 380 242 283 minecraft:stripped_oak_log
setblock 381 242 276 minecraft:stripped_oak_log
setblock 381 242 278 minecraft:stripped_oak_log
setblock 381 242 280 minecraft:stripped_oak_log
setblock 381 242 282 minecraft:stripped_oak_log
setblock 381 242 284 minecraft:stripped_oak_log
setblock 382 242 277 minecraft:stripped_oak_log
setblock 382 242 279 minecraft:stripped_oak_log
setblock 382 242 281 minecraft:stripped_oak_log
setblock 382 242 283 minecraft:stripped_oak_log
setblock 382 242 316 minecraft:stripped_oak_log
setblock 383 242 276 minecraft:stripped_oak_log
setblock 383 242 278 minecraft:stripped_oak_log
setblock 383 242 280 minecraft:stripped_oak_log
setblock 383 242 282 minecraft:stripped_oak_log
setblock 383 242 284 minecraft:stripped_oak_log
fill 383 242 316 386 242 316 minecraft:red_terracotta
setblock 384 242 277 minecraft:stripped_oak_log
setblock 384 242 279 minecraft:stripped_oak_log
setblock 384 242 281 minecraft:stripped_oak_log
setblock 384 242 283 minecraft:stripped_oak_log
setblock 385 242 276 minecraft:stripped_oak_log
setblock 385 242 278 minecraft:stripped_oak_log
setblock 385 242 280 minecraft:stripped_oak_log
setblock 385 242 282 minecraft:stripped_oak_log
setblock 385 242 284 minecraft:stripped_oak_log
setblock 386 242 277 minecraft:stripped_oak_log
setblock 386 242 279 minecraft:stripped_oak_log
setblock 386 242 281 minecraft:stripped_oak_log
setblock 386 242 283 minecraft:stripped_oak_log
setblock 387 242 276 minecraft:stripped_oak_log
setblock 387 242 278 minecraft:stripped_oak_log
setblock 387 242 280 minecraft:stripped_oak_log
setblock 387 242 282 minecraft:stripped_oak_log
setblock 387 242 284 minecraft:stripped_oak_log
setblock 387 242 315 minecraft:red_terracotta
setblock 387 242 316 minecraft:stripped_oak_log
setblock 388 242 277 minecraft:stripped_oak_log
setblock 388 242 279 minecraft:stripped_oak_log
setblock 388 242 281 minecraft:stripped_oak_log
setblock 388 242 283 minecraft:stripped_oak_log
setblock 388 242 315 minecraft:stripped_oak_log
fill 388 242 316 388 245 316 minecraft:red_terracotta
setblock 389 242 276 minecraft:stripped_oak_log
setblock 389 242 278 minecraft:stripped_oak_log
setblock 389 242 280 minecraft:stripped_oak_log
setblock 389 242 282 minecraft:stripped_oak_log
setblock 389 242 284 minecraft:stripped_oak_log
setblock 389 242 314 minecraft:stripped_oak_log
fill 389 242 315 389 245 315 minecraft:red_terracotta
setblock 390 242 277 minecraft:stripped_oak_log
setblock 390 242 279 minecraft:stripped_oak_log
setblock 390 242 281 minecraft:stripped_oak_log
setblock 390 242 283 minecraft:stripped_oak_log
fill 390 242 314 390 245 314 minecraft:red_terracotta
setblock 392 242 316 minecraft:stripped_oak_log
setblock 393 242 315 minecraft:stripped_oak_log
fill 393 242 316 393 245 316 minecraft:red_terracotta
fill 394 242 315 394 243 315 minecraft:red_terracotta
fill 399 242 310 399 246 311 minecraft:brown_terracotta
fill 400 242 313 400 246 313 minecraft:brown_terracotta
fill 401 242 308 401 246 308 minecraft:brown_terracotta
fill 402 242 276 408 242 281 minecraft:stripped_oak_log
fill 402 242 314 403 246 314 minecraft:brown_terracotta
fill 404 242 308 404 246 308 minecraft:brown_terracotta
fill 405 242 309 405 246 309 minecraft:brown_terracotta
fill 409 242 277 411 242 281 minecraft:stripped_oak_log
fill 410 242 316 410 243 316 minecraft:red_terracotta
setblock 412 242 276 minecraft:stripped_oak_log
fill 412 242 277 412 245 277 minecraft:red_terracotta
fill 412 242 278 412 242 281 minecraft:stripped_oak_log
setblock 412 242 316 minecraft:stripped_oak_log
fill 413 242 276 413 245 276 minecraft:red_terracotta
fill 413 242 316 413 245 316 minecraft:red_terracotta
setblock 414 242 284 minecraft:stripped_oak_log
setblock 414 242 285 minecraft:red_terracotta
setblock 414 242 289 minecraft:stripped_oak_log
setblock 415 242 283 minecraft:stripped_oak_log
fill 415 242 284 415 243 284 minecraft:red_terracotta
setblock 415 242 288 minecraft:stripped_oak_log
fill 415 242 289 415 244 289 minecraft:red_terracotta
setblock 416 242 277 minecraft:stripped_oak_log
setblock 416 242 278 minecraft:red_terracotta
setblock 416 242 282 minecraft:stripped_oak_log
fill 416 242 283 416 244 283 minecraft:red_terracotta
setblock 416 242 287 minecraft:stripped_oak_log
fill 416 242 288 416 245 288 minecraft:red_terracotta
setblock 416 242 292 minecraft:stripped_oak_log
setblock 416 242 308 minecraft:red_terracotta
setblock 416 242 312 minecraft:stripped_oak_log
setblock 416 242 313 minecraft:red_terracotta
setblock 417 242 276 minecraft:stripped_oak_log
fill 417 242 277 417 244 277 minecraft:red_terracotta
setblock 417 242 281 minecraft:stripped_oak_log
fill 417 242 282 417 244 282 minecraft:red_terracotta
setblock 417 242 286 minecraft:stripped_oak_log
fill 417 242 287 417 245 287 minecraft:red_terracotta
setblock 417 242 291 minecraft:stripped_oak_log
fill 417 242 292 417 245 292 minecraft:red_terracotta
setblock 417 242 306 minecraft:stripped_oak_log
fill 417 242 307 417 243 307 minecraft:red_terracotta
setblock 417 242 311 minecraft:stripped_oak_log
fill 417 242 312 417 245 312 minecraft:red_terracotta
setblock 417 242 316 minecraft:stripped_oak_log
fill 377 243 275 405 243 275 minecraft:terracotta
setblock 377 243 285 minecraft:stripped_oak_log
setblock 377 243 286 minecraft:red_terracotta
setblock 377 243 290 minecraft:stripped_oak_log
setblock 377 243 305 minecraft:stripped_oak_log
fill 377 243 306 377 244 306 minecraft:red_terracotta
setblock 377 243 310 minecraft:stripped_oak_log
fill 377 243 311 377 246 311 minecraft:red_terracotta
setblock 377 243 315 minecraft:stripped_oak_log
fill 377 243 316 377 246 316 minecraft:red_terracotta
setblock 378 243 309 minecraft:stripped_oak_log
fill 378 243 310 378 245 310 minecraft:red_terracotta
setblock 378 243 314 minecraft:stripped_oak_log
setblock 381 243 316 minecraft:stripped_oak_log
fill 382 243 316 385 243 316 minecraft:red_terracotta
setblock 386 243 315 minecraft:red_terracotta
setblock 386 243 316 minecraft:stripped_oak_log
setblock 387 243 315 minecraft:stripped_oak_log
fill 387 243 316 387 246 316 minecraft:red_terracotta
fill 388 243 315 388 246 315 minecraft:red_terracotta
fill 389 243 314 389 246 314 minecraft:red_terracotta
setblock 391 243 316 minecraft:stripped_oak_log
setblock 392 243 315 minecraft:stripped_oak_log
fill 392 243 316 392 246 316 minecraft:red_terracotta
fill 393 243 315 393 246 315 minecraft:red_terracotta
fill 399 243 309 399 246 309 minecraft:brown_terracotta
fill 399 243 312 399 246 312 minecraft:brown_terracotta
fill 400 243 308 400 246 308 minecraft:brown_terracotta
fill 401 243 307 403 246 307 minecraft:brown_terracotta
fill 401 243 314 401 246 314 minecraft:brown_terracotta
fill 402 243 281 412 243 281 minecraft:orange_terracotta
fill 404 243 314 404 246 314 minecraft:brown_terracotta
fill 405 243 308 405 246 308 minecraft:brown_terracotta
fill 405 243 313 405 246 313 minecraft:brown_terracotta
fill 406 243 275 408 246 275 minecraft:shroomlight
fill 406 243 310 406 246 312 minecraft:brown_terracotta
fill 409 243 275 418 243 275 minecraft:terracotta
setblock 411 243 276 minecraft:stripped_oak_log
setblock 411 243 316 minecraft:stripped_oak_log
fill 412 243 276 412 246 276 minecraft:red_terracotta
fill 412 243 316 412 246 316 minecraft:red_terracotta
setblock 414 243 288 minecraft:stripped_oak_log
setblock 415 243 283 minecraft:red_terracotta
setblock 415 243 287 minecraft:stripped_oak_log
fill 415 243 288 415 244 288 minecraft:red_terracotta
setblock 416 243 276 minecraft:stripped_oak_log
setblock 416 243 281 minecraft:stripped_oak_log
setblock 416 243 282 minecraft:red_terracotta
setblock 416 243 286 minecraft:stripped_oak_log
fill 416 243 287 416 245 287 minecraft:red_terracotta
setblock 416 243 291 minecraft:stripped_oak_log
setblock 416 243 292 minecraft:red_terracotta
setblock 416 243 311 minecraft:stripped_oak_log
setblock 416 243 312 minecraft:red_terracotta
setblock 416 243 316 minecraft:stripped_oak_log
fill 417 243 276 417 246 276 minecraft:red_terracotta
setblock 417 243 280 minecraft:stripped_oak_log
fill 417 243 281 417 244 281 minecraft:red_terracotta
setblock 417 243 285 minecraft:stripped_oak_log
fill 417 243 286 417 246 286 minecraft:red_terracotta
setblock 417 243 290 minecraft:stripped_oak_log
fill 417 243 291 417 246 291 minecraft:red_terracotta
setblock 417 243 310 minecraft:stripped_oak_log
fill 417 243 311 417 246 311 minecraft:red_terracotta
setblock 417 243 315 minecraft:stripped_oak_log
fill 417 243 316 417 246 316 minecraft:red_terracotta
fill 376 244 275 376 247 317 minecraft:brown_terracotta
fill 377 244 275 405 247 275 minecraft:brown_terracotta
setblock 377 244 289 minecraft:stripped_oak_log
setblock 377 244 309 minecraft:stripped_oak_log
fill 377 244 310 377 247 310 minecraft:red_terracotta
setblock 377 244 314 minecraft:stripped_oak_log
fill 377 244 315 377 247 315 minecraft:red_terracotta
fill 377 244 317 418 247 317 minecraft:brown_terracotta
setblock 378 244 309 minecraft:red_terracotta
setblock 378 244 313 minecraft:stripped_oak_log
fill 378 244 314 378 247 314 minecraft:red_terracotta
setblock 380 244 316 minecraft:stripped_oak_log
fill 381 244 316 384 244 316 minecraft:red_terracotta
setblock 385 244 316 minecraft:stripped_oak_log
setblock 386 244 315 minecraft:stripped_oak_log
fill 386 244 316 386 247 316 minecraft:red_terracotta
fill 387 244 315 387 247 315 minecraft:red_terracotta
fill 388 244 314 388 247 314 minecraft:red_terracotta
setblock 390 244 316 minecraft:stripped_oak_log
setblock 391 244 315 minecraft:stripped_oak_log
fill 391 244 316 391 247 316 minecraft:red_terracotta
fill 392 244 315 392 247 315 minecraft:red_terracotta
setblock 395 244 316 minecraft:stripped_oak_log
fill 398 244 310 398 246 311 minecraft:brown_terracotta
fill 399 244 308 399 246 308 minecraft:brown_terracotta
fill 399 244 313 399 246 313 minecraft:brown_terracotta
fill 400 244 307 400 246 307 minecraft:brown_terracotta
fill 400 244 314 400 246 314 minecraft:brown_terracotta
setblock 402 244 281 minecraft:stripped_oak_log
fill 402 244 315 403 246 315 minecraft:brown_terracotta
fill 404 244 307 404 246 307 minecraft:brown_terracotta
fill 405 244 314 405 246 314 minecraft:brown_terracotta
fill 406 244 309 406 246 309 minecraft:brown_terracotta
fill 406 244 313 406 246 313 minecraft:brown_terracotta
setblock 407 244 281 minecraft:stripped_oak_log
fill 409 244 275 418 247 275 minecraft:brown_terracotta
setblock 409 244 316 minecraft:red_terracotta
setblock 410 244 276 minecraft:stripped_oak_log
setblock 410 244 316 minecraft:stripped_oak_log
fill 411 244 276 411 247 276 minecraft:red_terracotta
fill 411 244 316 411 247 316 minecraft:red_terracotta
setblock 412 244 281 minecraft:stripped_oak_log
fill 413 244 315 413 246 315 minecraft:red_terracotta
setblock 415 244 276 minecraft:stripped_oak_log
setblock 415 244 286 minecraft:stripped_oak_log
setblock 415 244 287 minecraft:red_terracotta
setblock 415 244 316 minecraft:stripped_oak_log
fill 416 244 276 416 247 276 minecraft:red_terracotta
setblock 416 244 285 minecraft:stripped_oak_log
fill 416 244 286 416 245 286 minecraft:red_terracotta
setblock 416 244 290 minecraft:stripped_oak_log
setblock 416 244 291 minecraft:red_terracotta
fill 416 244 316 416 247 316 minecraft:red_terracotta
setblock 417 244 279 minecraft:stripped_oak_log
setblock 417 244 280 minecraft:red_terracotta
setblock 417 244 284 minecraft:stripped_oak_log
fill 417 244 285 417 246 285 minecraft:red_terracotta
setblock 417 244 289 minecraft:stripped_oak_log
fill 417 244 290 417 247 290 minecraft:red_terracotta
setblock 417 244 309 minecraft:stripped_oak_log
fill 417 244 310 417 246 310 minecraft:red_terracotta
setblock 417 244 314 minecraft:stripped_oak_log
fill 417 244 315 417 247 315 minecraft:red_terracotta
fill 418 244 276 418 247 316 minecraft:brown_terracotta
setblock 377 245 308 minecraft:stripped_oak_log
fill 377 245 309 377 248 309 minecraft:red_terracotta
setblock 377 245 313 minecraft:stripped_oak_log
fill 377 245 314 377 248 314 minecraft:red_terracotta
setblock 378 245 312 minecraft:stripped_oak_log
fill 378 245 313 378 248 313 minecraft:red_terracotta
setblock 379 245 278 minecraft:light[level=12]
setblock 379 245 285 minecraft:light[level=12]
setblock 379 245 292 minecraft:light[level=12]
setblock 379 245 299 minecraft:light[level=12]
setblock 379 245 306 minecraft:light[level=12]
setblock 379 245 313 minecraft:light[level=12]
setblock 379 245 316 minecraft:stripped_oak_log
fill 380 245 316 383 245 316 minecraft:red_terracotta
setblock 384 245 316 minecraft:stripped_oak_log
setblock 385 245 315 minecraft:stripped_oak_log
fill 385 245 316 385 248 316 minecraft:red_terracotta
setblock 386 245 278 minecraft:light[level=12]
setblock 386 245 285 minecraft:light[level=12]
setblock 386 245 292 minecraft:light[level=12]
setblock 386 245 299 minecraft:light[level=12]
setblock 386 245 306 minecraft:light[level=12]
setblock 386 245 313 minecraft:light[level=12]
fill 386 245 315 386 248 315 minecraft:red_terracotta
fill 387 245 314 387 248 314 minecraft:red_terracotta
setblock 389 245 316 minecraft:stripped_oak_log
setblock 390 245 315 minecraft:stripped_oak_log
fill 390 245 316 390 248 316 minecraft:red_terracotta
setblock 391 245 314 minecraft:stripped_oak_log
fill 391 245 315 391 248 315 minecraft:red_terracotta
setblock 393 245 278 minecraft:light[level=12]
setblock 393 245 285 minecraft:light[level=12]
setblock 393 245 292 minecraft:light[level=12]
setblock 393 245 299 minecraft:light[level=12]
setblock 393 245 306 minecraft:light[level=12]
setblock 393 245 313 minecraft:light[level=12]
setblock 394 245 316 minecraft:stripped_oak_log
fill 398 245 309 398 246 309 minecraft:brown_terracotta
fill 398 245 312 398 246 313 minecraft:brown_terracotta
fill 399 245 314 399 246 314 minecraft:brown_terracotta
setblock 400 245 278 minecraft:light[level=12]
setblock 400 245 285 minecraft:light[level=12]
setblock 400 245 292 minecraft:light[level=12]
setblock 400 245 299 minecraft:light[level=12]
setblock 400 245 306 minecraft:light[level=12]
fill 400 245 315 401 246 315 minecraft:brown_terracotta
fill 401 245 306 403 246 306 minecraft:brown_terracotta
fill 404 245 315 404 246 315 minecraft:brown_terracotta
fill 405 245 307 405 246 307 minecraft:brown_terracotta
fill 406 245 308 406 246 308 minecraft:brown_terracotta
fill 406 245 314 406 246 314 minecraft:brown_terracotta
setblock 407 245 278 minecraft:light[level=12]
setblock 407 245 285 minecraft:light[level=12]
setblock 407 245 292 minecraft:light[level=12]
setblock 407 245 299 minecraft:light[level=12]
setblock 407 245 306 minecraft:light[level=12]
fill 407 245 310 407 246 312 minecraft:brown_terracotta
setblock 407 245 313 minecraft:light[level=12]
setblock 408 245 276 minecraft:red_terracotta
setblock 408 245 316 minecraft:red_terracotta
setblock 409 245 276 minecraft:stripped_oak_log
setblock 409 245 316 minecraft:stripped_oak_log
fill 410 245 276 410 248 276 minecraft:red_terracotta
fill 410 245 316 410 248 316 minecraft:red_terracotta
fill 411 245 315 412 247 315 minecraft:red_terracotta
setblock 414 245 276 minecraft:stripped_oak_log
setblock 414 245 278 minecraft:light[level=12]
setblock 414 245 285 minecraft:light[level=12]
setblock 414 245 292 minecraft:light[level=12]
setblock 414 245 299 minecraft:light[level=12]
setblock 414 245 306 minecraft:light[level=12]
setblock 414 245 313 minecraft:light[level=12]
setblock 414 245 316 minecraft:stripped_oak_log
fill 415 245 276 415 248 276 minecraft:red_terracotta
fill 415 245 316 415 248 316 minecraft:red_terracotta
setblock 416 245 285 minecraft:red_terracotta
setblock 416 245 289 minecraft:stripped_oak_log
setblock 416 245 290 minecraft:red_terracotta
setblock 417 245 283 minecraft:stripped_oak_log
setblock 417 245 284 minecraft:red_terracotta
setblock 417 245 288 minecraft:stripped_oak_log
fill 417 245 289 417 247 289 minecraft:red_terracotta
setblock 417 245 313 minecraft:stripped_oak_log
fill 417 245 314 417 248 314 minecraft:red_terracotta
fill 377 246 308 377 249 308 minecraft:red_terracotta
setblock 377 246 312 minecraft:stripped_oak_log
fill 377 246 313 377 249 313 minecraft:red_terracotta
setblock 378 246 311 minecraft:stripped_oak_log
fill 378 246 312 378 249 312 minecraft:red_terracotta
setblock 378 246 316 minecraft:stripped_oak_log
fill 379 246 316 382 246 316 minecraft:red_terracotta
setblock 383 246 315 minecraft:red_terracotta
setblock 383 246 316 minecraft:stripped_oak_log
setblock 384 246 315 minecraft:stripped_oak_log
fill 384 246 316 384 249 316 minecraft:red_terracotta
fill 385 246 315 385 249 315 minecraft:red_terracotta
fill 386 246 314 386 249 314 minecraft:red_terracotta
setblock 388 246 316 minecraft:stripped_oak_log
setblock 389 246 315 minecraft:stripped_oak_log
fill 389 246 316 389 249 316 minecraft:red_terracotta
setblock 390 246 314 minecraft:stripped_oak_log
fill 390 246 315 390 249 315 minecraft:red_terracotta
fill 391 246 314 391 249 314 minecraft:red_terracotta
setblock 393 246 316 minecraft:stripped_oak_log
fill 394 246 316 394 249 316 minecraft:red_terracotta
fill 397 246 310 397 246 311 minecraft:brown_terracotta
setblock 398 246 314 minecraft:brown_terracotta
setblock 399 246 307 minecraft:brown_terracotta
setblock 399 246 315 minecraft:brown_terracotta
setblock 400 246 306 minecraft:brown_terracotta
fill 401 246 316 403 246 316 minecraft:brown_terracotta
fill 404 246 306 405 246 306 minecraft:brown_terracotta
setblock 405 246 315 minecraft:brown_terracotta
setblock 406 246 307 minecraft:brown_terracotta
setblock 407 246 276 minecraft:red_terracotta
fill 407 246 308 407 246 309 minecraft:brown_terracotta
setblock 407 246 313 minecraft:brown_terracotta
setblock 407 246 316 minecraft:red_terracotta
setblock 408 246 276 minecraft:stripped_oak_log
setblock 408 246 316 minecraft:stripped_oak_log
fill 409 246 276 409 249 276 minecraft:red_terracotta
setblock 409 246 315 minecraft:stripped_oak_log
fill 409 246 316 409 249 316 minecraft:red_terracotta
fill 410 246 277 411 246 277 minecraft:red_terracotta
fill 410 246 315 410 249 315 minecraft:red_terracotta
setblock 412 246 277 minecraft:stripped_oak_log
setblock 413 246 276 minecraft:stripped_oak_log
setblock 413 246 316 minecraft:stripped_oak_log
fill 414 246 276 414 249 276 minecraft:red_terracotta
setblock 414 246 315 minecraft:stripped_oak_log
fill 414 246 316 414 249 316 minecraft:red_terracotta
setblock 417 246 287 minecraft:stripped_oak_log
fill 417 246 288 417 247 288 minecraft:red_terracotta
setblock 417 246 292 minecraft:stripped_oak_log
setblock 417 246 312 minecraft:stripped_oak_log
fill 417 246 313 417 249 313 minecraft:red_terracotta
setblock 377 247 311 minecraft:stripped_oak_log
fill 377 247 312 377 250 312 minecraft:red_terracotta
setblock 377 247 316 minecraft:stripped_oak_log
fill 378 247 311 378 250 311 minecraft:red_terracotta
setblock 378 247 315 minecraft:stripped_oak_log
fill 378 247 316 381 247 316 minecraft:red_terracotta
setblock 379 247 278 minecraft:light[level=15]
setblock 379 247 286 minecraft:light[level=15]
setblock 379 247 294 minecraft:light[level=15]
setblock 379 247 302 minecraft:light[level=15]
setblock 379 247 310 minecraft:light[level=15]
fill 381 247 315 382 247 315 minecraft:red_terracotta
setblock 382 247 316 minecraft:stripped_oak_log
setblock 383 247 315 minecraft:stripped_oak_log
fill 383 247 316 383 250 316 minecraft:red_terracotta
fill 384 247 315 384 250 315 minecraft:red_terracotta
fill 385 247 314 385 250 314 minecraft:red_terracotta
setblock 387 247 278 minecraft:light[level=15]
setblock 387 247 286 minecraft:light[level=15]
setblock 387 247 294 minecraft:light[level=15]
setblock 387 247 302 minecraft:light[level=15]
setblock 387 247 310 minecraft:light[level=15]
setblock 387 247 316 minecraft:stripped_oak_log
setblock 388 247 315 minecraft:stripped_oak_log
fill 388 247 316 388 250 316 minecraft:red_terracotta
setblock 389 247 314 minecraft:stripped_oak_log
fill 389 247 315 389 250 315 minecraft:red_terracotta
fill 390 247 314 390 250 314 minecraft:red_terracotta
setblock 392 247 316 minecraft:stripped_oak_log
setblock 393 247 315 minecraft:stripped_oak_log
fill 393 247 316 393 250 316 minecraft:red_terracotta
setblock 395 247 278 minecraft:light[level=15]
setblock 395 247 286 minecraft:light[level=15]
setblock 395 247 294 minecraft:light[level=15]
setblock 395 247 302 minecraft:light[level=15]
setblock 395 247 310 minecraft:light[level=15]
fill 401 247 310 401 249 310 minecraft:stripped_oak_log
setblock 403 247 278 minecraft:light[level=15]
setblock 403 247 286 minecraft:light[level=15]
setblock 403 247 294 minecraft:light[level=15]
setblock 403 247 302 minecraft:light[level=15]
fill 403 247 310 403 248 310 minecraft:stripped_oak_log
fill 403 247 312 403 251 312 minecraft:stripped_oak_log
fill 406 247 275 408 247 275 minecraft:brown_terracotta
setblock 406 247 276 minecraft:red_terracotta
setblock 406 247 316 minecraft:red_terracotta
setblock 407 247 276 minecraft:stripped_oak_log
setblock 407 247 316 minecraft:stripped_oak_log
fill 408 247 276 408 250 276 minecraft:red_terracotta
setblock 408 247 315 minecraft:stripped_oak_log
fill 408 247 316 408 250 316 minecraft:red_terracotta
fill 409 247 277 410 247 277 minecraft:red_terracotta
fill 409 247 315 409 250 315 minecraft:red_terracotta
setblock 411 247 277 minecraft:stripped_oak_log
setblock 411 247 278 minecraft:light[level=15]
setblock 411 247 286 minecraft:light[level=15]
setblock 411 247 294 minecraft:light[level=15]
setblock 411 247 302 minecraft:light[level=15]
setblock 411 247 310 minecraft:light[level=15]
setblock 412 247 276 minecraft:stripped_oak_log
fill 412 247 277 413 249 277 minecraft:red_terracotta
setblock 412 247 316 minecraft:stripped_oak_log
fill 413 247 276 413 250 276 minecraft:red_terracotta
setblock 413 247 315 minecraft:stripped_oak_log
fill 413 247 316 413 250 316 minecraft:red_terracotta
fill 414 247 315 415 249 315 minecraft:red_terracotta
setblock 417 247 276 minecraft:stripped_oak_log
setblock 417 247 287 minecraft:red_terracotta
setblock 417 247 291 minecraft:stripped_oak_log
setblock 417 247 311 minecraft:stripped_oak_log
fill 417 247 312 417 250 312 minecraft:red_terracotta
setblock 417 247 316 minecraft:stripped_oak_log
fill 376 248 275 376 251 317 minecraft:light_gray_terracotta
fill 377 248 275 418 251 275 minecraft:light_gray_terracotta
setblock 377 248 310 minecraft:stripped_oak_log
fill 377 248 311 377 251 311 minecraft:red_terracotta
setblock 377 248 315 minecraft:stripped_oak_log
fill 377 248 316 380 248 316 minecraft:red_terracotta
fill 377 248 317 418 251 317 minecraft:light_gray_terracotta
setblock 378 248 314 minecraft:stripped_oak_log
fill 378 248 315 381 248 315 minecraft:red_terracotta
setblock 381 248 316 minecraft:stripped_oak_log
setblock 382 248 315 minecraft:stripped_oak_log
fill 382 248 316 382 251 316 minecraft:red_terracotta
fill 383 248 315 383 251 315 minecraft:red_terracotta
fill 384 248 314 384 251 314 minecraft:red_terracotta
setblock 386 248 276 minecraft:stripped_oak_log
setblock 386 248 316 minecraft:stripped_oak_log
fill 387 248 276 390 248 276 minecraft:red_terracotta
setblock 387 248 315 minecraft:stripped_oak_log
fill 387 248 316 387 251 316 minecraft:red_terracotta
setblock 388 248 314 minecraft:stripped_oak_log
fill 388 248 315 388 251 315 minecraft:red_terracotta
fill 389 248 314 389 251 314 minecraft:red_terracotta
setblock 391 248 316 minecraft:stripped_oak_log
setblock 392 248 315 minecraft:stripped_oak_log
fill 392 248 316 392 251 316 minecraft:red_terracotta
fill 393 248 315 393 251 315 minecraft:red_terracotta
fill 404 248 276 405 248 276 minecraft:red_terracotta
fill 404 248 316 405 248 316 minecraft:red_terracotta
setblock 406 248 276 minecraft:stripped_oak_log
setblock 406 248 316 minecraft:stripped_oak_log
fill 407 248 276 407 250 277 minecraft:red_terracotta
setblock 407 248 315 minecraft:stripped_oak_log
fill 407 248 316 407 251 316 minecraft:red_terracotta
fill 408 248 277 409 248 277 minecraft:red_terracotta
fill 408 248 315 408 251 315 minecraft:red_terracotta
setblock 410 248 277 minecraft:stripped_oak_log
setblock 411 248 276 minecraft:stripped_oak_log
fill 411 248 277 411 251 277 minecraft:red_terracotta
setblock 411 248 315 minecraft:red_terracotta
setblock 411 248 316 minecraft:stripped_oak_log
fill 412 248 276 412 251 276 minecraft:red_terracotta
setblock 412 248 315 minecraft:stripped_oak_log
fill 412 248 316 412 251 316 minecraft:red_terracotta
fill 413 248 315 413 251 315 minecraft:red_terracotta
setblock 414 248 277 minecraft:red_terracotta
setblock 416 248 276 minecraft:stripped_oak_log
fill 416 248 314 416 248 315 minecraft:red_terracotta
setblock 416 248 316 minecraft:stripped_oak_log
fill 417 248 276 417 250 277 minecraft:red_terracotta
setblock 417 248 290 minecraft:stripped_oak_log
setblock 417 248 291 minecraft:red_terracotta
fill 417 248 311 417 251 311 minecraft:red_terracotta
setblock 417 248 315 minecraft:stripped_oak_log
fill 417 248 316 417 251 316 minecraft:red_terracotta
fill 418 248 276 418 251 316 minecraft:light_gray_terracotta
setblock 377 249 309 minecraft:stripped_oak_log
fill 377 249 310 377 252 310 minecraft:red_terracotta
setblock 377 249 314 minecraft:stripped_oak_log
fill 377 249 315 379 249 316 minecraft:red_terracotta
setblock 378 249 313 minecraft:stripped_oak_log
fill 378 249 314 378 252 314 minecraft:red_terracotta
setblock 380 249 315 minecraft:red_terracotta
setblock 380 249 316 minecraft:stripped_oak_log
setblock 381 249 315 minecraft:stripped_oak_log
fill 381 249 316 381 252 316 minecraft:red_terracotta
setblock 382 249 314 minecraft:stripped_oak_log
fill 382 249 315 382 252 315 minecraft:red_terracotta
fill 383 249 314 383 252 314 minecraft:red_terracotta
setblock 384 249 276 minecraft:red_terracotta
setblock 385 249 276 minecraft:stripped_oak_log
setblock 385 249 316 minecraft:stripped_oak_log
fill 386 249 276 389 249 276 minecraft:red_terracotta
setblock 386 249 315 minecraft:stripped_oak_log
fill 386 249 316 386 252 316 minecraft:red_terracotta
setblock 387 249 313 minecraft:red_terracotta
setblock 387 249 314 minecraft:stripped_oak_log
fill 387 249 315 387 252 315 minecraft:red_terracotta
setblock 388 249 313 minecraft:stripped_oak_log
fill 388 249 314 388 252 314 minecraft:red_terracotta
setblock 390 249 276 minecraft:stripped_oak_log
setblock 390 249 316 minecraft:stripped_oak_log
fill 391 249 276 391 252 276 minecraft:red_terracotta
setblock 391 249 315 minecraft:stripped_oak_log
fill 391 249 316 391 252 316 minecraft:red_terracotta
fill 392 249 315 392 252 315 minecraft:red_terracotta
setblock 395 249 316 minecraft:stripped_oak_log
fill 403 249 276 404 249 276 minecraft:red_terracotta
fill 403 249 316 404 249 316 minecraft:red_terracotta
setblock 405 249 276 minecraft:stripped_oak_log
fill 405 249 277 406 251 277 minecraft:red_terracotta
setblock 405 249 315 minecraft:red_terracotta
setblock 405 249 316 minecraft:stripped_oak_log
fill 406 249 276 406 252 276 minecraft:red_terracotta
setblock 406 249 315 minecraft:stripped_oak_log
fill 406 249 316 406 252 316 minecraft:red_terracotta
fill 407 249 315 407 252 315 minecraft:red_terracotta
setblock 408 249 277 minecraft:red_terracotta
setblock 409 249 277 minecraft:stripped_oak_log
fill 409 249 314 411 249 314 minecraft:red_terracotta
setblock 410 249 276 minecraft:stripped_oak_log
fill 410 249 277 410 252 277 minecraft:red_terracotta
setblock 410 249 316 minecraft:stripped_oak_log
fill 411 249 276 411 252 276 minecraft:red_terracotta
setblock 411 249 315 minecraft:stripped_oak_log
fill 411 249 316 411 252 316 minecraft:red_terracotta
fill 412 249 315 412 252 315 minecraft:red_terracotta
setblock 414 249 277 minecraft:stripped_oak_log
setblock 415 249 276 minecraft:stripped_oak_log
setblock 415 249 316 minecraft:stripped_oak_log
fill 416 249 276 416 252 276 minecraft:red_terracotta
fill 416 249 313 416 249 314 minecraft:red_terracotta
setblock 416 249 315 minecraft:stripped_oak_log
fill 416 249 316 416 252 316 minecraft:red_terracotta
setblock 417 249 278 minecraft:red_terracotta
setblock 417 249 314 minecraft:stripped_oak_log
fill 417 249 315 417 252 315 minecraft:red_terracotta
fill 377 250 276 378 250 276 minecraft:red_terracotta
setblock 377 250 308 minecraft:stripped_oak_log
fill 377 250 309 377 253 309 minecraft:red_terracotta
setblock 377 250 313 minecraft:stripped_oak_log
fill 377 250 314 377 251 316 minecraft:red_terracotta
setblock 378 250 312 minecraft:stripped_oak_log
fill 378 250 313 378 253 313 minecraft:red_terracotta
fill 378 250 315 378 250 316 minecraft:red_terracotta
setblock 379 250 315 minecraft:red_terracotta
setblock 379 250 316 minecraft:stripped_oak_log
setblock 380 250 315 minecraft:stripped_oak_log
fill 380 250 316 380 253 316 minecraft:red_terracotta
fill 381 250 276 383 250 276 minecraft:red_terracotta
setblock 381 250 314 minecraft:stripped_oak_log
fill 381 250 315 381 253 315 minecraft:red_terracotta
fill 382 250 314 382 253 314 minecraft:red_terracotta
setblock 384 250 276 minecraft:stripped_oak_log
setblock 384 250 316 minecraft:stripped_oak_log
fill 385 250 276 388 250 276 minecraft:red_terracotta
fill 385 250 313 386 250 313 minecraft:red_terracotta
setblock 385 250 315 minecraft:stripped_oak_log
fill 385 250 316 385 253 316 minecraft:red_terracotta
setblock 386 250 314 minecraft:stripped_oak_log
fill 386 250 315 386 253 315 minecraft:red_terracotta
setblock 387 250 313 minecraft:stripped_oak_log
fill 387 250 314 387 253 314 minecraft:red_terracotta
fill 388 250 313 388 251 313 minecraft:red_terracotta
setblock 389 250 276 minecraft:stripped_oak_log
setblock 389 250 316 minecraft:stripped_oak_log
fill 390 250 276 390 253 276 minecraft:red_terracotta
setblock 390 250 315 minecraft:stripped_oak_log
fill 390 250 316 390 253 316 minecraft:red_terracotta
setblock 391 250 314 minecraft:stripped_oak_log
fill 391 250 315 391 253 315 minecraft:red_terracotta
fill 392 250 276 392 251 276 minecraft:red_terracotta
setblock 394 250 316 minecraft:stripped_oak_log
fill 395 250 316 395 253 316 minecraft:red_terracotta
fill 401 250 276 403 250 276 minecraft:red_terracotta
fill 401 250 316 403 250 316 minecraft:red_terracotta
setblock 404 250 276 minecraft:stripped_oak_log
fill 404 250 277 404 253 277 minecraft:red_terracotta
setblock 404 250 315 minecraft:red_terracotta
setblock 404 250 316 minecraft:stripped_oak_log
fill 405 250 276 405 253 276 minecraft:red_terracotta
setblock 405 250 315 minecraft:stripped_oak_log
fill 405 250 316 405 253 316 minecraft:red_terracotta
setblock 406 250 278 minecraft:red_terracotta
fill 406 250 315 406 253 315 minecraft:red_terracotta
setblock 407 250 278 minecraft:stripped_oak_log
fill 407 250 314 410 250 314 minecraft:red_terracotta
setblock 408 250 277 minecraft:stripped_oak_log
fill 408 250 278 411 250 278 minecraft:red_terracotta
setblock 409 250 276 minecraft:stripped_oak_log
fill 409 250 277 409 253 277 minecraft:red_terracotta
setblock 409 250 316 minecraft:stripped_oak_log
fill 410 250 276 410 253 276 minecraft:red_terracotta
setblock 410 250 315 minecraft:stripped_oak_log
fill 410 250 316 410 253 316 minecraft:red_terracotta
setblock 411 250 314 minecraft:stripped_oak_log
fill 411 250 315 411 253 315 minecraft:red_terracotta
setblock 412 250 277 minecraft:red_terracotta
fill 412 250 314 412 252 314 minecraft:red_terracotta
setblock 413 250 277 minecraft:stripped_oak_log
setblock 414 250 276 minecraft:stripped_oak_log
fill 414 250 277 415 252 277 minecraft:red_terracotta
setblock 414 250 315 minecraft:red_terracotta
setblock 414 250 316 minecraft:stripped_oak_log
fill 415 250 276 415 253 276 minecraft:red_terracotta
setblock 415 250 315 minecraft:stripped_oak_log
fill 415 250 316 415 253 316 minecraft:red_terracotta
setblock 416 250 313 minecraft:red_terracotta
setblock 416 250 314 minecraft:stripped_oak_log
fill 416 250 315 416 253 315 minecraft:red_terracotta
setblock 417 250 278 minecraft:stripped_oak_log
setblock 417 250 313 minecraft:stripped_oak_log
fill 417 250 314 417 253 314 minecraft:red_terracotta
setblock 377 251 276 minecraft:red_terracotta
setblock 377 251 277 minecraft:stripped_oak_log
fill 377 251 294 377 251 296 minecraft:red_terracotta
setblock 377 251 297 minecraft:stripped_oak_log
fill 377 251 308 377 254 308 minecraft:red_terracotta
setblock 377 251 312 minecraft:stripped_oak_log
fill 377 251 313 377 254 313 minecraft:red_terracotta
setblock 378 251 276 minecraft:stripped_oak_log
setblock 378 251 311 minecraft:stripped_oak_log
fill 378 251 312 378 254 312 minecraft:red_terracotta
setblock 378 251 315 minecraft:red_terracotta
setblock 378 251 316 minecraft:stripped_oak_log
fill 379 251 276 382 251 276 minecraft:red_terracotta
setblock 379 251 278 minecraft:light[level=12]
setblock 379 251 285 minecraft:light[level=12]
setblock 379 251 292 minecraft:light[level=12]
setblock 379 251 299 minecraft:light[level=12]
setblock 379 251 306 minecraft:light[level=12]
setblock 379 251 313 minecraft:light[level=12]
setblock 379 251 314 minecraft:red_terracotta
setblock 379 251 315 minecraft:stripped_oak_log
fill 379 251 316 379 254 316 minecraft:red_terracotta
setblock 380 251 314 minecraft:stripped_oak_log
fill 380 251 315 380 254 315 minecraft:red_terracotta
fill 381 251 314 381 254 314 minecraft:red_terracotta
setblock 383 251 276 minecraft:stripped_oak_log
setblock 383 251 316 minecraft:stripped_oak_log
fill 384 251 276 387 251 276 minecraft:red_terracotta
fill 384 251 313 385 251 313 minecraft:red_terracotta
setblock 384 251 315 minecraft:stripped_oak_log
fill 384 251 316 384 254 316 minecraft:red_terracotta
fill 385 251 277 386 251 277 minecraft:red_terracotta
setblock 385 251 314 minecraft:stripped_oak_log
fill 385 251 315 385 254 315 minecraft:red_terracotta
setblock 386 251 278 minecraft:light[level=12]
setblock 386 251 285 minecraft:light[level=12]
setblock 386 251 292 minecraft:light[level=12]
setblock 386 251 299 minecraft:light[level=12]
setblock 386 251 306 minecraft:light[level=12]
setblock 386 251 313 minecraft:stripped_oak_log
fill 386 251 314 386 254 314 minecraft:red_terracotta
setblock 387 251 277 minecraft:stripped_oak_log
fill 387 251 313 387 252 313 minecraft:red_terracotta
setblock 388 251 276 minecraft:stripped_oak_log
fill 388 251 277 389 253 277 minecraft:red_terracotta
setblock 388 251 316 minecraft:stripped_oak_log
fill 389 251 276 389 254 276 minecraft:red_terracotta
setblock 389 251 315 minecraft:stripped_oak_log
fill 389 251 316 389 254 316 minecraft:red_terracotta
setblock 390 251 314 minecraft:stripped_oak_log
fill 390 251 315 390 254 315 minecraft:red_terracotta
setblock 391 251 314 minecraft:red_terracotta
setblock 393 251 276 minecraft:stripped_oak_log
setblock 393 251 278 minecraft:light[level=12]
setblock 393 251 285 minecraft:light[level=12]
setblock 393 251 292 minecraft:light[level=12]
setblock 393 251 299 minecraft:light[level=12]
setblock 393 251 306 minecraft:light[level=12]
setblock 393 251 313 minecraft:light[level=12]
setblock 393 251 316 minecraft:stripped_oak_log
fill 394 251 316 394 254 316 minecraft:red_terracotta
fill 396 251 316 396 252 316 minecraft:red_terracotta
fill 399 251 276 402 251 276 minecraft:red_terracotta
setblock 400 251 278 minecraft:light[level=12]
setblock 400 251 285 minecraft:light[level=12]
setblock 400 251 292 minecraft:light[level=12]
setblock 400 251 299 minecraft:light[level=12]
setblock 400 251 306 minecraft:light[level=12]
setblock 400 251 313 minecraft:light[level=12]
fill 400 251 316 402 251 316 minecraft:red_terracotta
setblock 402 251 277 minecraft:stripped_oak_log
setblock 403 251 276 minecraft:stripped_oak_log
fill 403 251 277 403 254 277 minecraft:red_terracotta
setblock 403 251 315 minecraft:red_terracotta
setblock 403 251 316 minecraft:stripped_oak_log
fill 404 251 276 404 254 276 minecraft:red_terracotta
setblock 404 251 315 minecraft:stripped_oak_log
fill 404 251 316 404 254 316 minecraft:red_terracotta
setblock 405 251 278 minecraft:red_terracotta
fill 405 251 315 405 254 315 minecraft:red_terracotta
setblock 406 251 278 minecraft:stripped_oak_log
fill 406 251 314 409 251 314 minecraft:red_terracotta
setblock 407 251 276 minecraft:red_terracotta
setblock 407 251 277 minecraft:stripped_oak_log
fill 407 251 278 410 251 278 minecraft:red_terracotta
setblock 407 251 285 minecraft:light[level=12]
setblock 407 251 292 minecraft:light[level=12]
setblock 407 251 299 minecraft:light[level=12]
setblock 407 251 306 minecraft:light[level=12]
setblock 407 251 313 minecraft:light[level=12]
setblock 408 251 276 minecraft:stripped_oak_log
fill 408 251 277 408 254 277 minecraft:red_terracotta
setblock 408 251 316 minecraft:stripped_oak_log
fill 409 251 276 409 254 276 minecraft:red_terracotta
setblock 409 251 315 minecraft:stripped_oak_log
fill 409 251 316 409 254 316 minecraft:red_terracotta
setblock 410 251 314 minecraft:stripped_oak_log
fill 410 251 315 410 254 315 minecraft:red_terracotta
setblock 411 251 278 minecraft:stripped_oak_log
fill 411 251 314 411 253 314 minecraft:red_terracotta
setblock 412 251 277 minecraft:stripped_oak_log
fill 412 251 278 412 254 278 minecraft:red_terracotta
setblock 413 251 276 minecraft:stripped_oak_log
fill 413 251 277 413 254 277 minecraft:red_terracotta
setblock 413 251 316 minecraft:stripped_oak_log
fill 414 251 276 414 254 276 minecraft:red_terracotta
setblock 414 251 278 minecraft:light[level=12]
setblock 414 251 285 minecraft:light[level=12]
setblock 414 251 292 minecraft:light[level=12]
setblock 414 251 299 minecraft:light[level=12]
setblock 414 251 306 minecraft:light[level=12]
setblock 414 251 313 minecraft:light[level=12]
setblock 414 251 315 minecraft:stripped_oak_log
fill 414 251 316 414 254 316 minecraft:red_terracotta
fill 415 251 315 415 254 315 minecraft:red_terracotta
setblock 416 251 277 minecraft:red_terracotta
setblock 416 251 313 minecraft:stripped_oak_log
fill 416 251 314 416 254 314 minecraft:red_terracotta
setblock 417 251 276 minecraft:red_terracotta
setblock 417 251 277 minecraft:stripped_oak_log
fill 417 251 278 417 253 279 minecraft:red_terracotta
setblock 417 251 293 minecraft:red_terracotta
setblock 417 251 312 minecraft:stripped_oak_log
fill 417 251 313 417 254 313 minecraft:red_terracotta
fill 376 252 275 376 255 317 minecraft:orange_terracotta
fill 377 252 275 418 255 275 minecraft:orange_terracotta
setblock 377 252 276 minecraft:stripped_oak_log
fill 377 252 277 377 255 277 minecraft:red_terracotta
fill 377 252 293 377 252 295 minecraft:red_terracotta
setblock 377 252 296 minecraft:stripped_oak_log
fill 377 252 297 377 253 299 minecraft:red_terracotta
setblock 377 252 311 minecraft:stripped_oak_log
fill 377 252 312 377 255 312 minecraft:red_terracotta
fill 377 252 314 377 252 315 minecraft:red_terracotta
setblock 377 252 316 minecraft:stripped_oak_log
fill 377 252 317 418 255 317 minecraft:orange_terracotta
fill 378 252 276 381 252 276 minecraft:red_terracotta
fill 378 252 311 378 253 311 minecraft:red_terracotta
setblock 378 252 315 minecraft:stripped_oak_log
fill 378 252 316 378 255 316 minecraft:red_terracotta
setblock 379 252 314 minecraft:stripped_oak_log
fill 379 252 315 379 255 315 minecraft:red_terracotta
fill 380 252 314 380 254 314 minecraft:red_terracotta
setblock 382 252 276 minecraft:stripped_oak_log
setblock 382 252 316 minecraft:stripped_oak_log
fill 383 252 276 385 252 277 minecraft:red_terracotta
setblock 383 252 315 minecraft:stripped_oak_log
fill 383 252 316 383 255 316 minecraft:red_terracotta
setblock 384 252 313 minecraft:red_terracotta
schedule function dropper:buildpart/68_9 1t
