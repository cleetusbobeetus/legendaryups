setblock 333 176 497 minecraft:red_nether_bricks
setblock 333 176 498 minecraft:pink_terracotta
setblock 333 176 501 minecraft:pink_terracotta
setblock 333 176 502 minecraft:red_nether_bricks
setblock 333 176 503 minecraft:pink_terracotta
setblock 334 176 501 minecraft:red_nether_bricks
setblock 334 176 502 minecraft:pink_terracotta
setblock 335 176 464 minecraft:pink_terracotta
setblock 336 176 504 minecraft:red_nether_bricks
setblock 337 176 503 minecraft:red_nether_bricks
setblock 337 176 504 minecraft:pink_terracotta
setblock 339 176 504 minecraft:pink_terracotta
setblock 342 176 504 minecraft:white_concrete
setblock 348 176 464 minecraft:pink_terracotta
fill 348 176 504 350 176 504 minecraft:pink_terracotta
setblock 350 176 465 minecraft:red_nether_bricks
fill 350 176 503 351 176 503 minecraft:pink_terracotta
setblock 351 176 464 minecraft:red_nether_bricks
setblock 351 176 465 minecraft:pink_terracotta
setblock 351 176 504 minecraft:red_nether_bricks
setblock 352 176 464 minecraft:pink_terracotta
setblock 352 176 502 minecraft:pink_terracotta
setblock 352 176 503 minecraft:red_nether_bricks
fill 352 176 504 355 176 504 minecraft:pink_terracotta
setblock 353 176 502 minecraft:red_nether_bricks
fill 353 176 503 356 176 503 minecraft:pink_terracotta
setblock 354 176 466 minecraft:red_nether_bricks
fill 354 176 502 357 176 502 minecraft:pink_terracotta
setblock 355 176 465 minecraft:red_nether_bricks
setblock 356 176 464 minecraft:red_nether_bricks
setblock 356 176 465 minecraft:pink_terracotta
setblock 356 176 504 minecraft:red_nether_bricks
setblock 357 176 464 minecraft:pink_terracotta
setblock 357 176 503 minecraft:red_nether_bricks
setblock 357 176 504 minecraft:pink_terracotta
setblock 358 176 503 minecraft:pink_terracotta
setblock 361 176 464 minecraft:red_nether_bricks
setblock 361 176 503 minecraft:pink_terracotta
setblock 361 176 504 minecraft:red_nether_bricks
fill 362 176 464 365 176 464 minecraft:pink_terracotta
setblock 362 176 503 minecraft:red_nether_bricks
fill 362 176 504 365 176 504 minecraft:pink_terracotta
fill 363 176 503 366 176 503 minecraft:pink_terracotta
setblock 366 176 464 minecraft:red_nether_bricks
setblock 366 176 504 minecraft:red_nether_bricks
setblock 367 176 464 minecraft:pink_terracotta
setblock 367 176 502 minecraft:pink_terracotta
setblock 367 176 503 minecraft:red_nether_bricks
setblock 367 176 504 minecraft:pink_terracotta
setblock 368 176 496 minecraft:pink_terracotta
setblock 368 176 497 minecraft:red_nether_bricks
fill 368 176 498 368 176 501 minecraft:pink_terracotta
setblock 368 176 502 minecraft:red_nether_bricks
setblock 368 176 503 minecraft:pink_terracotta
fill 369 176 474 369 176 475 minecraft:pink_terracotta
setblock 369 176 476 minecraft:red_nether_bricks
fill 369 176 477 369 176 479 minecraft:pink_terracotta
fill 369 176 493 369 176 495 minecraft:pink_terracotta
setblock 369 176 496 minecraft:red_nether_bricks
setblock 369 176 497 minecraft:pink_terracotta
setblock 369 176 500 minecraft:pink_terracotta
setblock 369 176 501 minecraft:red_nether_bricks
setblock 369 176 502 minecraft:pink_terracotta
setblock 370 176 465 minecraft:red_nether_bricks
setblock 370 176 466 minecraft:pink_terracotta
setblock 370 176 470 minecraft:red_nether_bricks
setblock 370 176 471 minecraft:pink_terracotta
setblock 370 176 475 minecraft:red_nether_bricks
setblock 370 176 476 minecraft:pink_terracotta
fill 370 176 478 370 176 479 minecraft:pink_terracotta
setblock 370 176 480 minecraft:red_nether_bricks
setblock 370 176 481 minecraft:pink_terracotta
setblock 370 176 484 minecraft:pink_terracotta
setblock 370 176 485 minecraft:red_nether_bricks
fill 370 176 486 370 176 489 minecraft:pink_terracotta
setblock 370 176 490 minecraft:red_nether_bricks
setblock 370 176 491 minecraft:pink_terracotta
setblock 370 176 495 minecraft:red_nether_bricks
setblock 370 176 496 minecraft:pink_terracotta
setblock 370 176 500 minecraft:red_nether_bricks
setblock 370 176 501 minecraft:pink_terracotta
setblock 332 177 466 minecraft:light[level=12]
setblock 332 177 474 minecraft:light[level=12]
setblock 332 177 482 minecraft:light[level=12]
setblock 332 177 490 minecraft:light[level=12]
setblock 332 177 498 minecraft:light[level=12]
setblock 340 177 466 minecraft:light[level=12]
setblock 340 177 474 minecraft:light[level=12]
setblock 340 177 482 minecraft:light[level=12]
setblock 340 177 490 minecraft:light[level=12]
setblock 340 177 498 minecraft:light[level=12]
setblock 348 177 466 minecraft:light[level=12]
setblock 348 177 474 minecraft:light[level=12]
setblock 348 177 482 minecraft:light[level=12]
setblock 348 177 490 minecraft:light[level=12]
setblock 348 177 498 minecraft:light[level=12]
setblock 356 177 466 minecraft:light[level=12]
setblock 356 177 474 minecraft:light[level=12]
setblock 356 177 482 minecraft:light[level=12]
setblock 356 177 490 minecraft:light[level=12]
setblock 356 177 498 minecraft:light[level=12]
setblock 364 177 466 minecraft:light[level=12]
setblock 364 177 474 minecraft:light[level=12]
setblock 364 177 482 minecraft:light[level=12]
setblock 364 177 490 minecraft:light[level=12]
setblock 364 177 498 minecraft:light[level=12]
fill 345 181 482 345 181 488 minecraft:pink_concrete
fill 346 181 481 346 181 484 minecraft:pink_concrete
fill 346 181 486 346 181 489 minecraft:pink_concrete
fill 347 181 480 347 181 481 minecraft:pink_concrete
fill 347 181 488 349 181 490 minecraft:redstone_block
fill 348 181 479 349 181 480 minecraft:pink_concrete
fill 348 181 491 354 181 491 minecraft:pink_concrete
fill 350 181 479 352 181 481 minecraft:redstone_block
setblock 350 181 490 minecraft:pink_concrete
fill 352 181 490 355 181 490 minecraft:pink_concrete
fill 353 181 479 354 181 480 minecraft:pink_concrete
fill 355 181 480 355 181 481 minecraft:pink_concrete
fill 355 181 484 357 181 486 minecraft:redstone_block
fill 355 181 489 356 181 489 minecraft:pink_concrete
fill 356 181 481 356 181 483 minecraft:pink_concrete
fill 356 181 487 357 181 488 minecraft:pink_concrete
fill 357 181 482 357 182 483 minecraft:pink_concrete
fill 344 182 482 344 184 488 minecraft:pink_concrete
fill 345 182 480 345 184 484 minecraft:pink_concrete
fill 345 182 485 349 182 485 minecraft:red_terracotta
fill 345 182 486 345 184 490 minecraft:pink_concrete
fill 346 182 479 346 184 481 minecraft:pink_concrete
fill 346 182 482 349 182 484 minecraft:red_terracotta
fill 346 182 486 346 182 488 minecraft:red_terracotta
fill 346 182 489 346 182 491 minecraft:pink_concrete
fill 347 182 479 347 184 480 minecraft:pink_concrete
fill 347 182 481 349 182 481 minecraft:red_terracotta
fill 347 182 486 349 182 487 minecraft:red_terracotta
fill 347 182 491 350 182 491 minecraft:pink_concrete
fill 348 182 478 349 182 479 minecraft:pink_concrete
fill 348 182 480 349 182 480 minecraft:red_terracotta
fill 348 182 492 354 184 492 minecraft:pink_concrete
fill 350 182 478 354 182 478 minecraft:pink_concrete
fill 350 182 482 356 182 483 minecraft:red_terracotta
fill 350 182 487 354 182 490 minecraft:red_terracotta
fill 351 182 491 351 183 491 minecraft:red_terracotta
fill 352 182 491 356 184 491 minecraft:pink_concrete
fill 353 182 479 356 182 479 minecraft:pink_concrete
fill 353 182 480 354 182 481 minecraft:red_terracotta
fill 353 182 484 354 182 486 minecraft:red_terracotta
fill 355 182 480 357 184 480 minecraft:pink_concrete
fill 355 182 481 355 183 481 minecraft:red_terracotta
fill 355 182 487 355 182 489 minecraft:red_terracotta
fill 355 182 490 357 184 490 minecraft:pink_concrete
fill 356 182 481 357 184 481 minecraft:pink_concrete
fill 356 182 487 356 182 488 minecraft:red_terracotta
fill 356 182 489 357 184 489 minecraft:pink_concrete
fill 357 182 487 358 182 488 minecraft:pink_concrete
fill 358 182 482 358 182 486 minecraft:pink_concrete
fill 330 183 464 342 183 504 minecraft:red_terracotta
fill 343 183 464 343 183 483 minecraft:red_terracotta
fill 343 183 484 343 183 486 minecraft:pink_concrete
fill 343 183 487 343 183 504 minecraft:red_terracotta
fill 344 183 464 344 183 480 minecraft:red_terracotta
setblock 344 183 481 minecraft:pink_concrete
setblock 344 183 489 minecraft:pink_concrete
fill 344 183 490 344 183 504 minecraft:red_terracotta
fill 345 183 464 345 183 479 minecraft:red_terracotta
fill 345 183 485 348 183 485 minecraft:red_terracotta
fill 345 183 491 345 183 504 minecraft:red_terracotta
fill 346 183 464 346 183 478 minecraft:red_terracotta
fill 346 183 482 348 183 484 minecraft:red_terracotta
fill 346 183 486 348 183 486 minecraft:red_terracotta
fill 346 183 487 346 183 491 minecraft:shroomlight
fill 346 183 492 346 183 504 minecraft:red_terracotta
fill 347 183 464 349 183 477 minecraft:red_terracotta
fill 347 183 478 348 183 478 minecraft:pink_concrete
fill 347 183 481 348 183 481 minecraft:red_terracotta
fill 347 183 487 349 183 487 minecraft:shroomlight
fill 347 183 488 349 183 490 minecraft:red_terracotta
fill 347 183 491 350 183 491 minecraft:shroomlight
setblock 347 183 492 minecraft:pink_concrete
fill 347 183 493 349 183 504 minecraft:red_terracotta
fill 348 183 479 348 185 479 minecraft:pink_concrete
setblock 348 183 480 minecraft:red_terracotta
fill 349 183 478 349 183 483 minecraft:shroomlight
fill 349 183 484 349 183 486 minecraft:ochre_froglight
fill 350 183 464 370 183 476 minecraft:red_terracotta
fill 350 183 477 352 183 477 minecraft:pink_concrete
fill 350 183 478 353 183 478 minecraft:shroomlight
fill 350 183 479 352 183 481 minecraft:red_terracotta
fill 350 183 482 353 183 482 minecraft:shroomlight
fill 350 183 483 352 183 483 minecraft:ochre_froglight
fill 350 183 487 352 183 487 minecraft:ochre_froglight
fill 350 183 488 350 183 490 minecraft:shroomlight
fill 350 183 493 352 183 493 minecraft:pink_concrete
fill 350 183 494 370 183 504 minecraft:red_terracotta
fill 351 183 488 354 183 490 minecraft:red_terracotta
fill 353 183 477 370 183 477 minecraft:red_terracotta
fill 353 183 479 353 183 481 minecraft:shroomlight
fill 353 183 483 358 183 483 minecraft:shroomlight
fill 353 183 484 353 183 486 minecraft:ochre_froglight
fill 353 183 487 358 183 487 minecraft:shroomlight
fill 353 183 493 370 183 493 minecraft:red_terracotta
fill 354 183 478 355 183 479 minecraft:pink_concrete
fill 354 183 480 354 183 482 minecraft:red_terracotta
fill 354 183 484 354 183 486 minecraft:shroomlight
fill 355 183 482 356 183 482 minecraft:red_terracotta
fill 355 183 484 357 183 486 minecraft:red_terracotta
fill 355 183 488 355 183 489 minecraft:red_terracotta
setblock 355 183 492 minecraft:pink_concrete
fill 356 183 478 370 183 478 minecraft:red_terracotta
fill 356 183 479 356 184 479 minecraft:pink_concrete
setblock 356 183 488 minecraft:red_terracotta
fill 356 183 492 370 183 492 minecraft:red_terracotta
fill 357 183 479 370 183 479 minecraft:red_terracotta
fill 357 183 482 358 184 482 minecraft:pink_concrete
fill 357 183 488 358 184 488 minecraft:pink_concrete
fill 357 183 491 370 183 491 minecraft:red_terracotta
fill 358 183 480 370 183 480 minecraft:red_terracotta
setblock 358 183 481 minecraft:pink_concrete
fill 358 183 484 358 183 486 minecraft:shroomlight
setblock 358 183 489 minecraft:pink_concrete
fill 358 183 490 370 183 490 minecraft:red_terracotta
fill 359 183 481 370 183 483 minecraft:red_terracotta
fill 359 183 484 359 183 486 minecraft:pink_concrete
fill 359 183 487 370 183 489 minecraft:red_terracotta
fill 360 183 484 370 183 486 minecraft:red_terracotta
fill 342 184 476 342 185 476 minecraft:bone_block
fill 342 184 485 342 190 485 minecraft:bone_block
fill 342 184 494 342 185 494 minecraft:bone_block
fill 345 184 476 345 185 476 minecraft:bone_block
fill 345 184 485 345 190 485 minecraft:bone_block
fill 345 184 494 345 185 494 minecraft:bone_block
fill 346 184 482 346 184 491 minecraft:pink_concrete
fill 347 184 481 347 184 484 minecraft:pink_concrete
fill 347 184 486 347 184 491 minecraft:pink_concrete
fill 348 184 476 348 185 476 minecraft:bone_block
fill 348 184 478 354 184 478 minecraft:pink_concrete
fill 348 184 480 348 184 482 minecraft:pink_concrete
fill 348 184 485 348 190 485 minecraft:bone_block
fill 348 184 488 348 184 491 minecraft:pink_concrete
fill 348 184 494 348 185 494 minecraft:bone_block
fill 349 184 479 350 184 481 minecraft:pink_concrete
fill 349 184 489 350 184 491 minecraft:pink_concrete
fill 351 184 476 351 185 476 minecraft:bone_block
fill 351 184 479 354 184 480 minecraft:pink_concrete
fill 351 184 490 351 184 491 minecraft:pink_concrete
fill 351 184 494 351 185 494 minecraft:bone_block
fill 352 184 481 355 184 481 minecraft:pink_concrete
fill 352 184 489 354 184 490 minecraft:pink_concrete
fill 354 184 476 354 185 476 minecraft:bone_block
fill 354 184 482 356 184 482 minecraft:pink_concrete
fill 354 184 485 354 190 485 minecraft:bone_block
fill 354 184 488 356 184 488 minecraft:pink_concrete
fill 354 184 494 354 185 494 minecraft:bone_block
setblock 355 184 479 minecraft:pink_concrete
fill 355 184 483 358 184 484 minecraft:pink_concrete
fill 355 184 486 358 184 487 minecraft:pink_concrete
fill 355 184 489 355 185 489 minecraft:pink_concrete
setblock 356 184 485 minecraft:pink_concrete
fill 357 184 476 357 185 476 minecraft:bone_block
fill 357 184 485 357 190 485 minecraft:bone_block
fill 357 184 494 357 185 494 minecraft:bone_block
setblock 358 184 485 minecraft:pink_concrete
fill 360 184 476 360 185 476 minecraft:bone_block
fill 360 184 485 360 190 485 minecraft:bone_block
fill 360 184 494 360 185 494 minecraft:bone_block
setblock 332 185 466 minecraft:light[level=12]
setblock 332 185 474 minecraft:light[level=12]
setblock 332 185 482 minecraft:light[level=12]
setblock 332 185 490 minecraft:light[level=12]
setblock 332 185 498 minecraft:light[level=12]
setblock 340 185 466 minecraft:light[level=12]
setblock 340 185 474 minecraft:light[level=12]
setblock 340 185 482 minecraft:light[level=12]
setblock 340 185 490 minecraft:light[level=12]
setblock 340 185 498 minecraft:light[level=12]
fill 345 185 482 346 185 484 minecraft:pink_concrete
fill 345 185 486 346 185 488 minecraft:pink_concrete
fill 346 185 481 347 185 481 minecraft:pink_concrete
fill 346 185 489 347 185 489 minecraft:pink_concrete
fill 347 185 480 350 185 480 minecraft:pink_concrete
fill 347 185 490 350 185 490 minecraft:pink_concrete
setblock 348 185 466 minecraft:light[level=12]
setblock 348 185 474 minecraft:light[level=12]
setblock 348 185 482 minecraft:light[level=12]
fill 348 185 491 354 185 491 minecraft:pink_concrete
setblock 348 185 498 minecraft:light[level=12]
fill 349 185 479 354 185 479 minecraft:pink_concrete
fill 352 185 480 355 185 480 minecraft:pink_concrete
fill 352 185 490 355 185 490 minecraft:pink_concrete
fill 355 185 481 356 185 481 minecraft:pink_concrete
setblock 356 185 466 minecraft:light[level=12]
setblock 356 185 474 minecraft:light[level=12]
fill 356 185 482 357 185 484 minecraft:pink_concrete
fill 356 185 486 356 185 489 minecraft:pink_concrete
setblock 356 185 490 minecraft:light[level=12]
setblock 356 185 498 minecraft:light[level=12]
fill 357 185 486 357 185 488 minecraft:pink_concrete
setblock 364 185 466 minecraft:light[level=12]
setblock 364 185 474 minecraft:light[level=12]
setblock 364 185 482 minecraft:light[level=12]
setblock 364 185 490 minecraft:light[level=12]
setblock 364 185 498 minecraft:light[level=12]
fill 342 186 477 342 187 477 minecraft:bone_block
fill 342 186 493 342 187 493 minecraft:bone_block
fill 345 186 477 345 187 477 minecraft:bone_block
fill 345 186 493 345 187 493 minecraft:bone_block
fill 348 186 477 348 187 477 minecraft:bone_block
fill 348 186 493 348 187 493 minecraft:bone_block
fill 351 186 477 351 187 477 minecraft:bone_block
fill 351 186 493 351 187 493 minecraft:bone_block
fill 354 186 477 354 187 477 minecraft:bone_block
fill 354 186 493 354 187 493 minecraft:bone_block
fill 357 186 477 357 187 477 minecraft:bone_block
fill 357 186 493 357 187 493 minecraft:bone_block
fill 360 186 477 360 187 477 minecraft:bone_block
fill 360 186 493 360 187 493 minecraft:bone_block
setblock 330 187 464 minecraft:red_nether_bricks
fill 330 187 465 330 187 468 minecraft:pink_terracotta
setblock 330 187 469 minecraft:red_nether_bricks
fill 330 187 470 330 190 470 minecraft:pink_terracotta
setblock 330 187 475 minecraft:white_concrete
fill 330 187 476 330 187 478 minecraft:pink_terracotta
setblock 330 187 479 minecraft:red_nether_bricks
fill 330 187 480 330 187 483 minecraft:pink_terracotta
setblock 330 187 484 minecraft:red_nether_bricks
fill 330 187 485 330 187 488 minecraft:pink_terracotta
setblock 330 187 489 minecraft:red_nether_bricks
fill 330 187 490 330 187 493 minecraft:pink_terracotta
setblock 330 187 494 minecraft:red_nether_bricks
fill 330 187 495 330 187 498 minecraft:pink_terracotta
setblock 330 187 499 minecraft:red_nether_bricks
fill 330 187 500 330 187 503 minecraft:pink_terracotta
setblock 330 187 504 minecraft:red_nether_bricks
fill 331 187 464 333 188 464 minecraft:pink_terracotta
fill 331 187 479 331 187 482 minecraft:pink_terracotta
setblock 331 187 483 minecraft:red_nether_bricks
fill 331 187 484 331 187 487 minecraft:pink_terracotta
setblock 331 187 488 minecraft:red_nether_bricks
fill 331 187 489 331 187 492 minecraft:pink_terracotta
fill 331 187 504 332 187 504 minecraft:pink_terracotta
fill 332 187 483 332 187 486 minecraft:pink_terracotta
setblock 332 187 487 minecraft:red_nether_bricks
fill 332 187 488 332 190 488 minecraft:pink_terracotta
fill 336 187 491 336 189 491 minecraft:iron_block
fill 338 187 464 339 187 464 minecraft:pink_terracotta
setblock 340 187 464 minecraft:red_nether_bricks
fill 341 187 464 343 187 465 minecraft:pink_terracotta
fill 342 187 504 344 187 504 minecraft:pink_terracotta
setblock 343 187 466 minecraft:red_nether_bricks
setblock 344 187 464 minecraft:pink_terracotta
setblock 344 187 465 minecraft:red_nether_bricks
fill 344 187 466 347 187 466 minecraft:pink_terracotta
setblock 345 187 464 minecraft:red_nether_bricks
fill 345 187 465 348 187 465 minecraft:pink_terracotta
setblock 345 187 504 minecraft:red_nether_bricks
fill 346 187 464 349 187 464 minecraft:pink_terracotta
setblock 346 187 467 minecraft:pink_terracotta
setblock 346 187 503 minecraft:red_nether_bricks
fill 346 187 504 349 187 504 minecraft:pink_terracotta
setblock 347 187 467 minecraft:red_nether_bricks
fill 347 187 503 350 187 503 minecraft:pink_terracotta
setblock 348 187 466 minecraft:red_nether_bricks
fill 348 187 467 349 189 467 minecraft:pink_terracotta
fill 348 187 500 348 195 500 minecraft:iron_block
setblock 349 187 465 minecraft:red_nether_bricks
fill 349 187 466 352 187 466 minecraft:pink_terracotta
setblock 350 187 464 minecraft:red_nether_bricks
fill 350 187 465 353 187 465 minecraft:pink_terracotta
setblock 350 187 504 minecraft:red_nether_bricks
fill 351 187 464 354 187 464 minecraft:pink_terracotta
setblock 351 187 503 minecraft:red_nether_bricks
fill 351 187 504 354 187 504 minecraft:pink_terracotta
fill 352 187 503 352 188 503 minecraft:pink_terracotta
setblock 353 187 466 minecraft:red_nether_bricks
setblock 354 187 465 minecraft:red_nether_bricks
setblock 355 187 464 minecraft:red_nether_bricks
fill 355 187 465 358 187 465 minecraft:pink_terracotta
setblock 355 187 504 minecraft:red_nether_bricks
fill 356 187 464 359 187 464 minecraft:pink_terracotta
fill 356 187 504 359 187 504 minecraft:pink_terracotta
setblock 359 187 465 minecraft:red_nether_bricks
setblock 360 187 464 minecraft:red_nether_bricks
fill 360 187 465 363 187 465 minecraft:pink_terracotta
setblock 360 187 503 minecraft:pink_terracotta
setblock 360 187 504 minecraft:red_nether_bricks
fill 361 187 464 364 187 464 minecraft:pink_terracotta
setblock 361 187 503 minecraft:red_nether_bricks
fill 361 187 504 364 187 504 minecraft:pink_terracotta
fill 362 187 503 365 187 503 minecraft:pink_terracotta
setblock 364 187 465 minecraft:red_nether_bricks
fill 364 187 502 366 187 502 minecraft:pink_terracotta
setblock 365 187 464 minecraft:red_nether_bricks
fill 365 187 465 368 187 465 minecraft:pink_terracotta
setblock 365 187 504 minecraft:red_nether_bricks
fill 366 187 464 369 187 464 minecraft:pink_terracotta
setblock 366 187 503 minecraft:red_nether_bricks
fill 366 187 504 369 187 504 minecraft:pink_terracotta
setblock 367 187 502 minecraft:red_nether_bricks
fill 367 187 503 370 187 503 minecraft:pink_terracotta
fill 368 187 483 368 187 485 minecraft:pink_terracotta
setblock 368 187 486 minecraft:red_nether_bricks
fill 368 187 487 368 187 490 minecraft:pink_terracotta
setblock 368 187 491 minecraft:red_nether_bricks
setblock 368 187 501 minecraft:red_nether_bricks
fill 368 187 502 370 188 502 minecraft:pink_terracotta
setblock 369 187 465 minecraft:red_nether_bricks
fill 369 187 466 370 188 467 minecraft:pink_terracotta
fill 369 187 481 369 187 484 minecraft:pink_terracotta
setblock 369 187 485 minecraft:red_nether_bricks
fill 369 187 486 369 187 489 minecraft:pink_terracotta
setblock 369 187 490 minecraft:red_nether_bricks
fill 369 187 491 369 187 494 minecraft:pink_terracotta
setblock 369 187 495 minecraft:red_nether_bricks
fill 369 187 496 369 187 499 minecraft:pink_terracotta
setblock 369 187 500 minecraft:red_nether_bricks
fill 369 187 501 370 189 501 minecraft:pink_terracotta
setblock 370 187 464 minecraft:red_nether_bricks
fill 370 187 465 370 190 465 minecraft:pink_terracotta
setblock 370 187 468 minecraft:pink_terracotta
setblock 370 187 469 minecraft:red_nether_bricks
setblock 370 187 479 minecraft:red_nether_bricks
fill 370 187 480 370 187 483 minecraft:pink_terracotta
setblock 370 187 484 minecraft:red_nether_bricks
fill 370 187 485 370 187 488 minecraft:pink_terracotta
setblock 370 187 489 minecraft:red_nether_bricks
fill 370 187 490 370 187 493 minecraft:pink_terracotta
setblock 370 187 494 minecraft:red_nether_bricks
fill 370 187 495 370 187 498 minecraft:pink_terracotta
setblock 370 187 499 minecraft:red_nether_bricks
fill 370 187 500 370 190 500 minecraft:pink_terracotta
setblock 370 187 504 minecraft:red_nether_bricks
fill 330 188 464 330 188 467 minecraft:pink_terracotta
setblock 330 188 468 minecraft:red_nether_bricks
fill 330 188 469 330 191 469 minecraft:pink_terracotta
fill 330 188 471 330 188 472 minecraft:pink_terracotta
setblock 330 188 473 minecraft:red_nether_bricks
fill 330 188 474 330 188 477 minecraft:pink_terracotta
setblock 330 188 478 minecraft:red_nether_bricks
fill 330 188 479 330 188 482 minecraft:pink_terracotta
setblock 330 188 483 minecraft:red_nether_bricks
fill 330 188 484 330 188 487 minecraft:pink_terracotta
setblock 330 188 488 minecraft:red_nether_bricks
fill 330 188 489 330 188 492 minecraft:pink_terracotta
setblock 330 188 493 minecraft:red_nether_bricks
fill 330 188 494 330 188 497 minecraft:pink_terracotta
fill 330 188 500 330 188 502 minecraft:pink_terracotta
setblock 330 188 503 minecraft:red_nether_bricks
fill 330 188 504 331 189 504 minecraft:pink_terracotta
fill 331 188 480 331 188 481 minecraft:pink_terracotta
setblock 331 188 482 minecraft:red_nether_bricks
fill 331 188 483 331 188 486 minecraft:pink_terracotta
setblock 331 188 487 minecraft:red_nether_bricks
fill 331 188 488 331 188 491 minecraft:pink_terracotta
setblock 331 188 492 minecraft:red_nether_bricks
fill 332 188 483 332 188 485 minecraft:pink_terracotta
setblock 332 188 486 minecraft:red_nether_bricks
fill 332 188 487 332 191 487 minecraft:pink_terracotta
setblock 332 188 504 minecraft:white_concrete
setblock 334 188 464 minecraft:red_nether_bricks
fill 335 188 464 338 188 464 minecraft:pink_terracotta
fill 336 188 485 340 194 485 minecraft:bone_block
fill 337 188 484 339 195 484 minecraft:bone_block
fill 337 188 486 340 194 486 minecraft:bone_block
fill 338 188 483 338 195 483 minecraft:bone_block
setblock 339 188 464 minecraft:red_nether_bricks
fill 340 188 464 342 188 465 minecraft:pink_terracotta
setblock 342 188 466 minecraft:red_nether_bricks
fill 342 188 478 342 189 478 minecraft:bone_block
fill 342 188 492 342 189 492 minecraft:bone_block
fill 342 188 504 343 188 504 minecraft:pink_terracotta
setblock 343 188 464 minecraft:pink_terracotta
setblock 343 188 465 minecraft:red_nether_bricks
fill 343 188 466 346 188 466 minecraft:pink_terracotta
setblock 344 188 464 minecraft:red_nether_bricks
fill 344 188 465 347 188 465 minecraft:pink_terracotta
fill 344 188 467 345 188 467 minecraft:pink_terracotta
setblock 344 188 504 minecraft:red_nether_bricks
fill 345 188 464 348 188 464 minecraft:pink_terracotta
fill 345 188 478 345 189 478 minecraft:bone_block
fill 345 188 492 345 189 492 minecraft:bone_block
setblock 345 188 503 minecraft:red_nether_bricks
fill 345 188 504 348 188 504 minecraft:pink_terracotta
setblock 346 188 467 minecraft:red_nether_bricks
fill 346 188 503 349 188 503 minecraft:pink_terracotta
setblock 347 188 466 minecraft:red_nether_bricks
fill 347 188 467 347 191 467 minecraft:pink_terracotta
setblock 348 188 465 minecraft:red_nether_bricks
fill 348 188 466 351 188 466 minecraft:pink_terracotta
fill 348 188 478 348 189 478 minecraft:bone_block
fill 348 188 492 348 189 492 minecraft:bone_block
setblock 349 188 464 minecraft:red_nether_bricks
fill 349 188 465 352 188 465 minecraft:pink_terracotta
setblock 349 188 504 minecraft:red_nether_bricks
fill 350 188 464 353 188 464 minecraft:pink_terracotta
setblock 350 188 467 minecraft:pink_terracotta
setblock 350 188 503 minecraft:red_nether_bricks
fill 350 188 504 353 188 504 minecraft:pink_terracotta
fill 351 188 478 351 189 478 minecraft:bone_block
fill 351 188 492 351 189 492 minecraft:bone_block
fill 351 188 503 351 190 503 minecraft:pink_terracotta
setblock 352 188 466 minecraft:red_nether_bricks
setblock 353 188 465 minecraft:red_nether_bricks
fill 353 188 466 353 191 466 minecraft:pink_terracotta
setblock 354 188 464 minecraft:red_nether_bricks
fill 354 188 465 357 188 465 minecraft:pink_terracotta
fill 354 188 478 354 189 478 minecraft:bone_block
fill 354 188 492 354 189 492 minecraft:bone_block
setblock 354 188 504 minecraft:red_nether_bricks
fill 355 188 464 358 188 464 minecraft:pink_terracotta
fill 355 188 504 358 188 504 minecraft:pink_terracotta
fill 357 188 478 357 189 478 minecraft:bone_block
fill 357 188 492 357 189 492 minecraft:bone_block
setblock 358 188 465 minecraft:red_nether_bricks
setblock 359 188 464 minecraft:red_nether_bricks
fill 359 188 465 362 188 465 minecraft:pink_terracotta
setblock 359 188 504 minecraft:red_nether_bricks
fill 360 188 464 363 188 464 minecraft:pink_terracotta
fill 360 188 478 360 189 478 minecraft:bone_block
fill 360 188 492 360 189 492 minecraft:bone_block
setblock 360 188 503 minecraft:red_nether_bricks
fill 360 188 504 363 188 504 minecraft:pink_terracotta
fill 361 188 503 364 188 503 minecraft:pink_terracotta
setblock 363 188 465 minecraft:red_nether_bricks
setblock 364 188 464 minecraft:red_nether_bricks
fill 364 188 465 367 188 465 minecraft:pink_terracotta
fill 364 188 502 365 188 502 minecraft:pink_terracotta
setblock 364 188 504 minecraft:red_nether_bricks
fill 365 188 464 368 188 464 minecraft:pink_terracotta
fill 365 188 466 366 188 466 minecraft:pink_terracotta
setblock 365 188 503 minecraft:red_nether_bricks
fill 365 188 504 368 188 504 minecraft:pink_terracotta
setblock 366 188 502 minecraft:red_nether_bricks
fill 366 188 503 369 188 503 minecraft:pink_terracotta
fill 367 188 488 369 188 488 minecraft:pink_terracotta
fill 367 188 502 367 191 502 minecraft:pink_terracotta
setblock 368 188 465 minecraft:red_nether_bricks
fill 368 188 483 368 188 484 minecraft:pink_terracotta
setblock 368 188 485 minecraft:red_nether_bricks
fill 368 188 486 370 188 487 minecraft:pink_terracotta
setblock 368 188 489 minecraft:pink_terracotta
setblock 368 188 490 minecraft:red_nether_bricks
fill 368 188 491 369 188 493 minecraft:pink_terracotta
setblock 368 188 501 minecraft:pink_terracotta
setblock 369 188 464 minecraft:red_nether_bricks
fill 369 188 465 369 191 465 minecraft:pink_terracotta
setblock 369 188 468 minecraft:pink_terracotta
fill 369 188 481 369 188 483 minecraft:pink_terracotta
setblock 369 188 484 minecraft:red_nether_bricks
fill 369 188 485 370 190 485 minecraft:pink_terracotta
setblock 369 188 489 minecraft:red_nether_bricks
fill 369 188 490 370 190 490 minecraft:pink_terracotta
setblock 369 188 494 minecraft:red_nether_bricks
fill 369 188 495 369 188 498 minecraft:pink_terracotta
setblock 369 188 499 minecraft:red_nether_bricks
fill 369 188 500 369 191 500 minecraft:pink_terracotta
setblock 369 188 504 minecraft:red_nether_bricks
fill 370 188 464 370 191 464 minecraft:pink_terracotta
setblock 370 188 468 minecraft:red_nether_bricks
fill 370 188 469 370 190 470 minecraft:pink_terracotta
fill 370 188 479 370 188 482 minecraft:pink_terracotta
setblock 370 188 483 minecraft:red_nether_bricks
fill 370 188 484 370 191 484 minecraft:pink_terracotta
setblock 370 188 488 minecraft:red_nether_bricks
fill 370 188 489 370 191 489 minecraft:pink_terracotta
fill 370 188 491 370 188 492 minecraft:pink_terracotta
setblock 370 188 493 minecraft:red_nether_bricks
fill 370 188 494 370 188 497 minecraft:pink_terracotta
setblock 370 188 498 minecraft:red_nether_bricks
fill 370 188 499 370 191 499 minecraft:pink_terracotta
setblock 370 188 503 minecraft:red_nether_bricks
fill 370 188 504 370 191 504 minecraft:pink_terracotta
fill 330 189 464 330 189 466 minecraft:pink_terracotta
setblock 330 189 467 minecraft:red_nether_bricks
fill 330 189 468 330 192 468 minecraft:pink_terracotta
setblock 330 189 471 minecraft:pink_terracotta
setblock 330 189 472 minecraft:red_nether_bricks
fill 330 189 473 330 189 476 minecraft:pink_terracotta
setblock 330 189 477 minecraft:red_nether_bricks
fill 330 189 478 330 189 481 minecraft:pink_terracotta
setblock 330 189 482 minecraft:red_nether_bricks
fill 330 189 483 330 189 486 minecraft:pink_terracotta
setblock 330 189 487 minecraft:red_nether_bricks
fill 330 189 488 330 189 491 minecraft:pink_terracotta
setblock 330 189 492 minecraft:red_nether_bricks
fill 330 189 493 330 189 496 minecraft:pink_terracotta
setblock 330 189 497 minecraft:red_nether_bricks
setblock 330 189 502 minecraft:red_nether_bricks
fill 330 189 503 330 190 503 minecraft:pink_terracotta
fill 331 189 464 332 189 464 minecraft:pink_terracotta
setblock 331 189 466 minecraft:red_nether_bricks
fill 331 189 467 331 192 467 minecraft:pink_terracotta
setblock 331 189 480 minecraft:pink_terracotta
setblock 331 189 481 minecraft:red_nether_bricks
fill 331 189 482 331 189 485 minecraft:pink_terracotta
setblock 331 189 486 minecraft:red_nether_bricks
fill 331 189 487 331 189 490 minecraft:pink_terracotta
setblock 331 189 491 minecraft:red_nether_bricks
fill 331 189 492 331 192 492 minecraft:pink_terracotta
fill 332 189 483 332 189 484 minecraft:pink_terracotta
setblock 332 189 485 minecraft:red_nether_bricks
fill 332 189 486 332 191 486 minecraft:pink_terracotta
setblock 332 189 489 minecraft:pink_terracotta
setblock 333 189 464 minecraft:red_nether_bricks
fill 334 189 464 337 189 464 minecraft:pink_terracotta
fill 335 189 485 335 193 486 minecraft:bone_block
fill 336 189 483 336 194 484 minecraft:bone_block
fill 336 189 486 336 194 487 minecraft:bone_block
fill 337 189 483 337 194 483 minecraft:bone_block
fill 337 189 487 340 194 487 minecraft:bone_block
setblock 338 189 464 minecraft:red_nether_bricks
fill 338 189 482 338 194 482 minecraft:bone_block
setblock 338 189 504 minecraft:white_concrete
fill 339 189 464 341 189 465 minecraft:pink_terracotta
fill 339 189 483 340 194 483 minecraft:bone_block
fill 340 189 484 340 194 484 minecraft:bone_block
setblock 341 189 466 minecraft:red_nether_bricks
fill 341 189 485 341 193 486 minecraft:bone_block
fill 341 189 504 342 189 504 minecraft:pink_terracotta
setblock 342 189 464 minecraft:pink_terracotta
setblock 342 189 465 minecraft:red_nether_bricks
fill 342 189 466 345 189 466 minecraft:pink_terracotta
fill 342 189 479 342 191 479 minecraft:bone_block
fill 342 189 491 342 191 491 minecraft:bone_block
setblock 343 189 464 minecraft:red_nether_bricks
fill 343 189 465 346 189 465 minecraft:pink_terracotta
fill 343 189 467 344 189 467 minecraft:pink_terracotta
setblock 343 189 504 minecraft:red_nether_bricks
fill 344 189 464 347 189 464 minecraft:pink_terracotta
setblock 344 189 503 minecraft:red_nether_bricks
fill 344 189 504 347 189 504 minecraft:pink_terracotta
setblock 345 189 467 minecraft:red_nether_bricks
fill 345 189 479 345 191 479 minecraft:bone_block
fill 345 189 491 345 191 491 minecraft:bone_block
fill 345 189 503 348 189 503 minecraft:pink_terracotta
setblock 346 189 466 minecraft:red_nether_bricks
fill 346 189 467 346 192 467 minecraft:pink_terracotta
setblock 347 189 465 minecraft:red_nether_bricks
fill 347 189 466 350 189 466 minecraft:pink_terracotta
setblock 348 189 464 minecraft:red_nether_bricks
fill 348 189 465 351 189 465 minecraft:pink_terracotta
fill 348 189 479 348 191 479 minecraft:bone_block
fill 348 189 491 348 191 491 minecraft:bone_block
setblock 348 189 504 minecraft:red_nether_bricks
fill 349 189 464 352 189 464 minecraft:pink_terracotta
setblock 349 189 503 minecraft:red_nether_bricks
fill 349 189 504 352 189 504 minecraft:pink_terracotta
setblock 350 189 467 minecraft:red_nether_bricks
fill 350 189 503 350 191 503 minecraft:pink_terracotta
setblock 351 189 466 minecraft:red_nether_bricks
fill 351 189 479 351 191 479 minecraft:bone_block
fill 351 189 491 351 191 491 minecraft:bone_block
setblock 352 189 465 minecraft:red_nether_bricks
fill 352 189 466 352 192 466 minecraft:pink_terracotta
setblock 353 189 464 minecraft:red_nether_bricks
fill 353 189 465 356 189 465 minecraft:pink_terracotta
setblock 353 189 504 minecraft:red_nether_bricks
fill 354 189 464 357 189 464 minecraft:pink_terracotta
fill 354 189 479 354 191 479 minecraft:bone_block
fill 354 189 491 354 191 491 minecraft:bone_block
fill 354 189 504 357 189 504 minecraft:pink_terracotta
setblock 357 189 465 minecraft:red_nether_bricks
fill 357 189 479 357 191 479 minecraft:bone_block
fill 357 189 491 357 191 491 minecraft:bone_block
setblock 358 189 464 minecraft:red_nether_bricks
fill 358 189 465 361 189 465 minecraft:pink_terracotta
setblock 358 189 504 minecraft:red_nether_bricks
fill 359 189 464 362 189 464 minecraft:pink_terracotta
setblock 359 189 503 minecraft:red_nether_bricks
fill 359 189 504 362 189 504 minecraft:pink_terracotta
fill 360 189 479 360 191 479 minecraft:bone_block
fill 360 189 491 360 191 491 minecraft:bone_block
fill 360 189 503 363 189 503 minecraft:pink_terracotta
setblock 362 189 465 minecraft:red_nether_bricks
fill 362 189 466 365 189 466 minecraft:pink_terracotta
setblock 363 189 464 minecraft:red_nether_bricks
fill 363 189 465 366 189 465 minecraft:pink_terracotta
fill 363 189 502 364 189 502 minecraft:pink_terracotta
setblock 363 189 504 minecraft:red_nether_bricks
fill 364 189 464 367 189 464 minecraft:pink_terracotta
setblock 364 189 503 minecraft:red_nether_bricks
fill 364 189 504 367 189 504 minecraft:pink_terracotta
setblock 365 189 502 minecraft:red_nether_bricks
fill 365 189 503 368 189 503 minecraft:pink_terracotta
setblock 366 189 466 minecraft:red_nether_bricks
fill 366 189 502 366 191 502 minecraft:pink_terracotta
setblock 367 189 465 minecraft:red_nether_bricks
fill 367 189 466 367 192 466 minecraft:pink_terracotta
fill 367 189 486 367 189 489 minecraft:pink_terracotta
setblock 367 189 490 minecraft:red_nether_bricks
fill 367 189 491 370 189 491 minecraft:pink_terracotta
setblock 368 189 464 minecraft:red_nether_bricks
fill 368 189 465 368 192 465 minecraft:pink_terracotta
setblock 368 189 483 minecraft:pink_terracotta
setblock 368 189 484 minecraft:red_nether_bricks
fill 368 189 485 368 189 488 minecraft:pink_terracotta
setblock 368 189 489 minecraft:red_nether_bricks
fill 368 189 490 368 192 490 minecraft:pink_terracotta
fill 368 189 492 368 189 493 minecraft:pink_terracotta
setblock 368 189 494 minecraft:red_nether_bricks
fill 368 189 495 370 190 495 minecraft:pink_terracotta
fill 368 189 502 369 189 502 minecraft:pink_terracotta
setblock 368 189 504 minecraft:red_nether_bricks
fill 369 189 464 369 192 464 minecraft:pink_terracotta
fill 369 189 466 369 189 467 minecraft:pink_terracotta
setblock 369 189 468 minecraft:red_nether_bricks
fill 369 189 481 369 189 482 minecraft:pink_terracotta
setblock 369 189 483 minecraft:red_nether_bricks
fill 369 189 484 369 192 484 minecraft:pink_terracotta
fill 369 189 486 369 189 487 minecraft:pink_terracotta
setblock 369 189 488 minecraft:red_nether_bricks
fill 369 189 489 369 192 489 minecraft:pink_terracotta
setblock 369 189 492 minecraft:pink_terracotta
setblock 369 189 493 minecraft:red_nether_bricks
fill 369 189 494 370 191 494 minecraft:pink_terracotta
fill 369 189 496 369 189 497 minecraft:pink_terracotta
setblock 369 189 498 minecraft:red_nether_bricks
fill 369 189 499 369 192 499 minecraft:pink_terracotta
setblock 369 189 503 minecraft:red_nether_bricks
fill 369 189 504 369 192 504 minecraft:pink_terracotta
setblock 370 189 466 minecraft:pink_terracotta
setblock 370 189 467 minecraft:red_nether_bricks
fill 370 189 468 370 192 468 minecraft:pink_terracotta
setblock 370 189 471 minecraft:pink_terracotta
setblock 370 189 475 minecraft:white_concrete
fill 370 189 479 370 189 481 minecraft:pink_terracotta
setblock 370 189 482 minecraft:red_nether_bricks
fill 370 189 483 370 192 483 minecraft:pink_terracotta
setblock 370 189 486 minecraft:pink_terracotta
setblock 370 189 487 minecraft:red_nether_bricks
fill 370 189 488 370 192 488 minecraft:pink_terracotta
setblock 370 189 492 minecraft:red_nether_bricks
fill 370 189 493 370 192 493 minecraft:pink_terracotta
setblock 370 189 496 minecraft:pink_terracotta
setblock 370 189 497 minecraft:red_nether_bricks
fill 370 189 498 370 192 498 minecraft:pink_terracotta
setblock 370 189 502 minecraft:red_nether_bricks
fill 370 189 503 370 192 503 minecraft:pink_terracotta
fill 330 190 464 330 190 465 minecraft:pink_terracotta
setblock 330 190 466 minecraft:red_nether_bricks
fill 330 190 467 330 193 467 minecraft:pink_terracotta
setblock 330 190 471 minecraft:red_nether_bricks
fill 330 190 472 330 190 475 minecraft:pink_terracotta
setblock 330 190 476 minecraft:red_nether_bricks
fill 330 190 477 330 190 480 minecraft:pink_terracotta
setblock 330 190 481 minecraft:red_nether_bricks
fill 330 190 482 330 190 485 minecraft:pink_terracotta
setblock 330 190 486 minecraft:red_nether_bricks
fill 330 190 487 330 190 490 minecraft:pink_terracotta
setblock 330 190 491 minecraft:red_nether_bricks
fill 330 190 492 330 190 495 minecraft:pink_terracotta
setblock 330 190 496 minecraft:red_nether_bricks
fill 330 190 497 330 191 497 minecraft:pink_terracotta
setblock 330 190 499 minecraft:white_concrete
setblock 330 190 504 minecraft:pink_terracotta
setblock 331 190 464 minecraft:pink_terracotta
setblock 331 190 465 minecraft:red_nether_bricks
fill 331 190 466 331 192 466 minecraft:pink_terracotta
fill 331 190 468 331 190 469 minecraft:pink_terracotta
setblock 331 190 480 minecraft:red_nether_bricks
fill 331 190 481 331 190 484 minecraft:pink_terracotta
setblock 331 190 485 minecraft:red_nether_bricks
fill 331 190 486 331 190 489 minecraft:pink_terracotta
setblock 331 190 490 minecraft:red_nether_bricks
fill 331 190 491 331 193 491 minecraft:pink_terracotta
fill 331 190 493 331 191 493 minecraft:pink_terracotta
setblock 332 190 464 minecraft:red_nether_bricks
setblock 332 190 484 minecraft:red_nether_bricks
fill 332 190 485 332 191 485 minecraft:pink_terracotta
setblock 332 190 489 minecraft:red_nether_bricks
fill 333 190 464 336 190 464 minecraft:pink_terracotta
fill 335 190 483 335 193 484 minecraft:bone_block
fill 335 190 487 335 193 487 minecraft:bone_block
fill 336 190 482 337 193 482 minecraft:bone_block
fill 336 190 488 340 192 488 minecraft:bone_block
setblock 337 190 464 minecraft:red_nether_bricks
fill 337 190 465 340 190 465 minecraft:pink_terracotta
fill 338 190 464 341 190 464 minecraft:pink_terracotta
fill 339 190 482 340 193 482 minecraft:bone_block
setblock 340 190 466 minecraft:red_nether_bricks
fill 340 190 504 341 190 504 minecraft:pink_terracotta
setblock 341 190 465 minecraft:red_nether_bricks
fill 341 190 466 344 190 466 minecraft:pink_terracotta
fill 341 190 483 341 193 484 minecraft:bone_block
fill 341 190 487 341 192 487 minecraft:bone_block
setblock 342 190 464 minecraft:red_nether_bricks
fill 342 190 465 345 190 465 minecraft:pink_terracotta
fill 342 190 467 343 190 467 minecraft:pink_terracotta
fill 342 190 484 342 193 484 minecraft:bone_block
fill 342 190 486 342 193 486 minecraft:bone_block
setblock 342 190 504 minecraft:red_nether_bricks
fill 343 190 464 346 190 464 minecraft:pink_terracotta
fill 343 190 504 346 190 504 minecraft:pink_terracotta
setblock 344 190 467 minecraft:red_nether_bricks
fill 344 190 503 347 190 503 minecraft:pink_terracotta
setblock 345 190 466 minecraft:red_nether_bricks
fill 345 190 467 345 192 468 minecraft:pink_terracotta
fill 345 190 484 345 193 484 minecraft:bone_block
fill 345 190 486 345 193 486 minecraft:bone_block
setblock 346 190 465 minecraft:red_nether_bricks
fill 346 190 466 349 190 466 minecraft:pink_terracotta
fill 346 190 468 346 191 468 minecraft:pink_terracotta
setblock 347 190 464 minecraft:red_nether_bricks
fill 347 190 465 350 190 465 minecraft:pink_terracotta
setblock 347 190 504 minecraft:red_nether_bricks
fill 348 190 464 351 190 464 minecraft:pink_terracotta
setblock 348 190 467 minecraft:pink_terracotta
fill 348 190 484 348 193 484 minecraft:bone_block
fill 348 190 486 348 193 486 minecraft:bone_block
setblock 348 190 503 minecraft:red_nether_bricks
fill 348 190 504 351 190 504 minecraft:pink_terracotta
setblock 349 190 467 minecraft:red_nether_bricks
fill 349 190 503 349 192 503 minecraft:pink_terracotta
setblock 350 190 466 minecraft:red_nether_bricks
fill 350 190 467 350 192 467 minecraft:pink_terracotta
setblock 351 190 465 minecraft:red_nether_bricks
fill 351 190 466 351 193 466 minecraft:pink_terracotta
fill 351 190 486 351 193 486 minecraft:bone_block
setblock 352 190 464 minecraft:red_nether_bricks
fill 352 190 465 355 190 465 minecraft:pink_terracotta
setblock 352 190 504 minecraft:red_nether_bricks
fill 353 190 464 356 190 464 minecraft:pink_terracotta
fill 353 190 504 356 190 504 minecraft:pink_terracotta
fill 354 190 484 354 193 484 minecraft:bone_block
fill 354 190 486 354 193 486 minecraft:bone_block
setblock 356 190 465 minecraft:red_nether_bricks
setblock 357 190 464 minecraft:red_nether_bricks
fill 357 190 465 360 190 465 minecraft:pink_terracotta
fill 357 190 484 357 193 484 minecraft:bone_block
fill 357 190 486 357 193 486 minecraft:bone_block
setblock 357 190 504 minecraft:red_nether_bricks
fill 358 190 464 361 190 464 minecraft:pink_terracotta
fill 358 190 504 361 190 504 minecraft:pink_terracotta
fill 359 190 503 362 190 503 minecraft:pink_terracotta
fill 360 190 484 360 193 484 minecraft:bone_block
fill 360 190 486 360 193 486 minecraft:bone_block
setblock 361 190 465 minecraft:red_nether_bricks
fill 361 190 466 364 190 466 minecraft:pink_terracotta
setblock 362 190 464 minecraft:red_nether_bricks
fill 362 190 465 365 190 465 minecraft:pink_terracotta
setblock 362 190 504 minecraft:red_nether_bricks
fill 363 190 464 366 190 464 minecraft:pink_terracotta
setblock 363 190 502 minecraft:pink_terracotta
setblock 363 190 503 minecraft:red_nether_bricks
fill 363 190 504 366 190 504 minecraft:pink_terracotta
setblock 364 190 502 minecraft:red_nether_bricks
fill 364 190 503 367 190 503 minecraft:pink_terracotta
setblock 365 190 466 minecraft:red_nether_bricks
fill 365 190 502 365 192 502 minecraft:pink_terracotta
setblock 366 190 465 minecraft:red_nether_bricks
fill 366 190 466 366 192 466 minecraft:pink_terracotta
setblock 367 190 464 minecraft:red_nether_bricks
fill 367 190 465 367 193 465 minecraft:pink_terracotta
fill 367 190 486 367 190 488 minecraft:pink_terracotta
setblock 367 190 489 minecraft:red_nether_bricks
fill 367 190 490 367 190 493 minecraft:pink_terracotta
setblock 367 190 504 minecraft:red_nether_bricks
fill 368 190 464 368 193 464 minecraft:pink_terracotta
fill 368 190 466 369 190 466 minecraft:pink_terracotta
setblock 368 190 483 minecraft:red_nether_bricks
fill 368 190 484 368 190 487 minecraft:pink_terracotta
setblock 368 190 488 minecraft:red_nether_bricks
fill 368 190 489 368 193 489 minecraft:pink_terracotta
fill 368 190 491 368 190 492 minecraft:pink_terracotta
setblock 368 190 493 minecraft:red_nether_bricks
fill 368 190 494 368 193 494 minecraft:pink_terracotta
fill 368 190 496 369 190 496 minecraft:pink_terracotta
setblock 368 190 503 minecraft:red_nether_bricks
fill 368 190 504 368 193 504 minecraft:pink_terracotta
setblock 369 190 467 minecraft:red_nether_bricks
fill 369 190 468 369 192 469 minecraft:pink_terracotta
setblock 369 190 481 minecraft:pink_terracotta
setblock 369 190 482 minecraft:red_nether_bricks
fill 369 190 483 369 193 483 minecraft:pink_terracotta
setblock 369 190 486 minecraft:pink_terracotta
setblock 369 190 487 minecraft:red_nether_bricks
fill 369 190 488 369 193 488 minecraft:pink_terracotta
setblock 369 190 491 minecraft:pink_terracotta
setblock 369 190 492 minecraft:red_nether_bricks
fill 369 190 493 369 193 493 minecraft:pink_terracotta
setblock 369 190 497 minecraft:red_nether_bricks
fill 369 190 498 369 193 498 minecraft:pink_terracotta
setblock 369 190 501 minecraft:pink_terracotta
setblock 369 190 502 minecraft:red_nether_bricks
fill 369 190 503 369 191 503 minecraft:pink_terracotta
setblock 370 190 466 minecraft:red_nether_bricks
fill 370 190 467 370 193 467 minecraft:pink_terracotta
setblock 370 190 471 minecraft:red_nether_bricks
fill 370 190 472 370 193 472 minecraft:pink_terracotta
fill 370 190 479 370 190 480 minecraft:pink_terracotta
setblock 370 190 481 minecraft:red_nether_bricks
fill 370 190 482 370 193 482 minecraft:pink_terracotta
setblock 370 190 486 minecraft:red_nether_bricks
fill 370 190 487 370 193 487 minecraft:pink_terracotta
setblock 370 190 491 minecraft:red_nether_bricks
fill 370 190 492 370 193 492 minecraft:pink_terracotta
setblock 370 190 496 minecraft:red_nether_bricks
fill 370 190 497 370 193 497 minecraft:pink_terracotta
setblock 370 190 501 minecraft:red_nether_bricks
fill 370 190 502 370 192 502 minecraft:pink_terracotta
setblock 330 191 464 minecraft:pink_terracotta
setblock 330 191 465 minecraft:red_nether_bricks
fill 330 191 466 330 194 466 minecraft:pink_terracotta
setblock 330 191 470 minecraft:red_nether_bricks
fill 330 191 471 330 191 474 minecraft:pink_terracotta
setblock 330 191 475 minecraft:red_nether_bricks
fill 330 191 476 330 191 479 minecraft:pink_terracotta
setblock 330 191 480 minecraft:red_nether_bricks
fill 330 191 481 330 191 484 minecraft:pink_terracotta
setblock 330 191 485 minecraft:red_nether_bricks
fill 330 191 486 330 191 489 minecraft:pink_terracotta
setblock 330 191 490 minecraft:red_nether_bricks
fill 330 191 491 330 191 494 minecraft:pink_terracotta
setblock 330 191 495 minecraft:red_nether_bricks
fill 330 191 496 330 193 496 minecraft:pink_terracotta
setblock 331 191 464 minecraft:red_nether_bricks
setblock 331 191 468 minecraft:pink_terracotta
setblock 331 191 469 minecraft:red_nether_bricks
fill 331 191 470 331 193 471 minecraft:pink_terracotta
fill 331 191 481 331 191 483 minecraft:pink_terracotta
setblock 331 191 484 minecraft:red_nether_bricks
fill 331 191 485 331 191 488 minecraft:pink_terracotta
setblock 331 191 489 minecraft:red_nether_bricks
fill 331 191 490 331 194 490 minecraft:pink_terracotta
setblock 331 191 504 minecraft:white_concrete
fill 332 191 464 335 191 464 minecraft:pink_terracotta
setblock 332 191 488 minecraft:red_nether_bricks
setblock 332 191 489 minecraft:pink_terracotta
setblock 336 191 464 minecraft:red_nether_bricks
fill 337 191 464 339 191 465 minecraft:pink_terracotta
fill 337 191 489 338 192 489 minecraft:bone_block
setblock 339 191 466 minecraft:red_nether_bricks
setblock 340 191 464 minecraft:pink_terracotta
setblock 340 191 465 minecraft:red_nether_bricks
fill 340 191 466 343 191 466 minecraft:pink_terracotta
setblock 340 191 504 minecraft:pink_terracotta
setblock 341 191 464 minecraft:red_nether_bricks
fill 341 191 465 344 191 465 minecraft:pink_terracotta
fill 341 191 467 342 191 467 minecraft:pink_terracotta
setblock 341 191 504 minecraft:red_nether_bricks
fill 342 191 464 345 191 464 minecraft:pink_terracotta
fill 342 191 480 342 192 480 minecraft:bone_block
fill 342 191 490 342 192 490 minecraft:bone_block
fill 342 191 504 345 191 504 minecraft:pink_terracotta
setblock 343 191 467 minecraft:red_nether_bricks
fill 343 191 468 344 193 468 minecraft:pink_terracotta
setblock 344 191 466 minecraft:red_nether_bricks
fill 344 191 467 344 194 467 minecraft:pink_terracotta
fill 344 191 503 346 191 503 minecraft:pink_terracotta
setblock 345 191 465 minecraft:red_nether_bricks
fill 345 191 466 348 191 466 minecraft:pink_terracotta
fill 345 191 480 345 192 480 minecraft:bone_block
fill 345 191 490 345 192 490 minecraft:bone_block
setblock 346 191 464 minecraft:red_nether_bricks
fill 346 191 465 349 191 465 minecraft:pink_terracotta
setblock 346 191 504 minecraft:red_nether_bricks
fill 347 191 464 350 191 464 minecraft:pink_terracotta
setblock 347 191 468 minecraft:red_nether_bricks
setblock 347 191 503 minecraft:red_nether_bricks
fill 347 191 504 350 191 504 minecraft:pink_terracotta
setblock 348 191 467 minecraft:red_nether_bricks
fill 348 191 480 348 192 480 minecraft:bone_block
fill 348 191 490 348 192 490 minecraft:bone_block
fill 348 191 503 348 192 503 minecraft:pink_terracotta
setblock 349 191 466 minecraft:red_nether_bricks
fill 349 191 467 349 193 467 minecraft:pink_terracotta
setblock 350 191 465 minecraft:red_nether_bricks
fill 350 191 466 350 194 466 minecraft:pink_terracotta
setblock 351 191 464 minecraft:red_nether_bricks
fill 351 191 465 354 191 465 minecraft:pink_terracotta
fill 351 191 480 351 192 480 minecraft:bone_block
fill 351 191 490 351 192 490 minecraft:bone_block
setblock 351 191 504 minecraft:red_nether_bricks
fill 352 191 464 355 191 464 minecraft:pink_terracotta
fill 352 191 504 355 191 504 minecraft:pink_terracotta
fill 354 191 480 354 192 480 minecraft:bone_block
fill 354 191 490 354 192 490 minecraft:bone_block
setblock 355 191 465 minecraft:red_nether_bricks
setblock 356 191 464 minecraft:red_nether_bricks
fill 356 191 465 359 191 465 minecraft:pink_terracotta
setblock 356 191 504 minecraft:red_nether_bricks
fill 357 191 464 360 191 464 minecraft:pink_terracotta
fill 357 191 480 357 192 480 minecraft:bone_block
fill 357 191 490 357 192 490 minecraft:bone_block
fill 357 191 504 360 191 504 minecraft:pink_terracotta
fill 358 191 503 361 191 503 minecraft:pink_terracotta
setblock 360 191 465 minecraft:red_nether_bricks
fill 360 191 466 363 191 466 minecraft:pink_terracotta
fill 360 191 480 360 192 480 minecraft:bone_block
fill 360 191 490 360 192 490 minecraft:bone_block
setblock 361 191 464 minecraft:red_nether_bricks
fill 361 191 465 364 191 465 minecraft:pink_terracotta
setblock 361 191 504 minecraft:red_nether_bricks
fill 362 191 464 365 191 464 minecraft:pink_terracotta
setblock 362 191 502 minecraft:pink_terracotta
setblock 362 191 503 minecraft:red_nether_bricks
fill 362 191 504 365 191 504 minecraft:pink_terracotta
setblock 363 191 502 minecraft:red_nether_bricks
fill 363 191 503 366 191 503 minecraft:pink_terracotta
setblock 364 191 466 minecraft:red_nether_bricks
fill 364 191 502 364 193 502 minecraft:pink_terracotta
setblock 365 191 465 minecraft:red_nether_bricks
fill 365 191 466 365 193 466 minecraft:pink_terracotta
setblock 366 191 464 minecraft:red_nether_bricks
fill 366 191 465 366 194 465 minecraft:pink_terracotta
setblock 366 191 504 minecraft:red_nether_bricks
fill 367 191 464 367 194 464 minecraft:pink_terracotta
fill 367 191 486 367 191 487 minecraft:pink_terracotta
setblock 367 191 488 minecraft:red_nether_bricks
fill 367 191 489 367 191 492 minecraft:pink_terracotta
setblock 367 191 493 minecraft:red_nether_bricks
fill 367 191 494 367 194 494 minecraft:pink_terracotta
setblock 367 191 503 minecraft:red_nether_bricks
fill 367 191 504 367 194 504 minecraft:pink_terracotta
fill 368 191 483 368 191 486 minecraft:pink_terracotta
setblock 368 191 487 minecraft:red_nether_bricks
fill 368 191 488 368 194 488 minecraft:pink_terracotta
setblock 368 191 491 minecraft:pink_terracotta
setblock 368 191 492 minecraft:red_nether_bricks
fill 368 191 493 368 194 493 minecraft:pink_terracotta
fill 368 191 495 368 191 496 minecraft:pink_terracotta
fill 368 191 503 368 192 503 minecraft:pink_terracotta
setblock 369 191 466 minecraft:red_nether_bricks
fill 369 191 467 369 193 467 minecraft:pink_terracotta
setblock 369 191 470 minecraft:pink_terracotta
fill 369 191 482 369 192 482 minecraft:pink_terracotta
setblock 369 191 485 minecraft:pink_terracotta
setblock 369 191 486 minecraft:red_nether_bricks
fill 369 191 487 369 194 487 minecraft:pink_terracotta
setblock 369 191 490 minecraft:pink_terracotta
setblock 369 191 491 minecraft:red_nether_bricks
fill 369 191 492 369 194 492 minecraft:pink_terracotta
setblock 369 191 495 minecraft:pink_terracotta
setblock 369 191 496 minecraft:red_nether_bricks
fill 369 191 497 369 194 497 minecraft:pink_terracotta
setblock 369 191 501 minecraft:red_nether_bricks
setblock 369 191 502 minecraft:pink_terracotta
setblock 370 191 465 minecraft:red_nether_bricks
fill 370 191 466 370 194 466 minecraft:pink_terracotta
setblock 370 191 469 minecraft:pink_terracotta
setblock 370 191 470 minecraft:red_nether_bricks
fill 370 191 471 370 194 471 minecraft:pink_terracotta
fill 370 191 473 370 192 473 minecraft:pink_terracotta
setblock 370 191 479 minecraft:pink_terracotta
setblock 370 191 480 minecraft:red_nether_bricks
fill 370 191 481 370 193 481 minecraft:pink_terracotta
setblock 370 191 485 minecraft:red_nether_bricks
fill 370 191 486 370 194 486 minecraft:pink_terracotta
setblock 370 191 490 minecraft:red_nether_bricks
fill 370 191 491 370 194 491 minecraft:pink_terracotta
setblock 370 191 495 minecraft:red_nether_bricks
fill 370 191 496 370 194 496 minecraft:pink_terracotta
setblock 370 191 500 minecraft:red_nether_bricks
fill 370 191 501 370 192 501 minecraft:pink_terracotta
setblock 330 192 464 minecraft:red_nether_bricks
fill 330 192 465 330 194 465 minecraft:pink_terracotta
setblock 330 192 469 minecraft:red_nether_bricks
fill 330 192 470 330 192 473 minecraft:pink_terracotta
setblock 330 192 474 minecraft:red_nether_bricks
fill 330 192 475 330 192 478 minecraft:pink_terracotta
setblock 330 192 479 minecraft:red_nether_bricks
fill 330 192 480 330 192 483 minecraft:pink_terracotta
setblock 330 192 484 minecraft:red_nether_bricks
fill 330 192 485 330 192 488 minecraft:pink_terracotta
setblock 330 192 489 minecraft:red_nether_bricks
fill 330 192 490 330 192 493 minecraft:pink_terracotta
setblock 330 192 494 minecraft:red_nether_bricks
fill 330 192 495 330 195 495 minecraft:pink_terracotta
fill 331 192 464 334 192 464 minecraft:pink_terracotta
setblock 331 192 468 minecraft:red_nether_bricks
fill 331 192 469 331 194 469 minecraft:pink_terracotta
setblock 331 192 472 minecraft:pink_terracotta
setblock 331 192 482 minecraft:pink_terracotta
setblock 331 192 483 minecraft:red_nether_bricks
fill 331 192 484 331 192 487 minecraft:pink_terracotta
setblock 331 192 488 minecraft:red_nether_bricks
fill 331 192 489 331 195 489 minecraft:pink_terracotta
setblock 331 192 493 minecraft:red_nether_bricks
setblock 332 192 487 minecraft:red_nether_bricks
setblock 332 192 488 minecraft:pink_terracotta
setblock 335 192 464 minecraft:red_nether_bricks
fill 336 192 464 338 192 465 minecraft:pink_terracotta
setblock 337 192 504 minecraft:white_concrete
setblock 338 192 466 minecraft:red_nether_bricks
setblock 339 192 464 minecraft:pink_terracotta
setblock 339 192 465 minecraft:red_nether_bricks
fill 339 192 466 342 192 466 minecraft:pink_terracotta
setblock 340 192 464 minecraft:red_nether_bricks
fill 340 192 465 343 192 465 minecraft:pink_terracotta
fill 340 192 467 341 192 467 minecraft:pink_terracotta
setblock 340 192 504 minecraft:red_nether_bricks
fill 341 192 464 344 192 464 minecraft:pink_terracotta
fill 341 192 504 344 192 504 minecraft:pink_terracotta
setblock 342 192 467 minecraft:red_nether_bricks
fill 342 192 468 342 194 468 minecraft:pink_terracotta
fill 342 192 481 342 193 481 minecraft:bone_block
fill 342 192 489 342 193 489 minecraft:bone_block
setblock 343 192 466 minecraft:red_nether_bricks
fill 343 192 467 343 195 467 minecraft:pink_terracotta
setblock 344 192 465 minecraft:red_nether_bricks
fill 344 192 466 347 192 466 minecraft:pink_terracotta
fill 344 192 503 345 192 503 minecraft:pink_terracotta
setblock 345 192 464 minecraft:red_nether_bricks
fill 345 192 465 348 192 465 minecraft:pink_terracotta
fill 345 192 481 345 193 481 minecraft:bone_block
fill 345 192 489 345 193 489 minecraft:bone_block
setblock 345 192 504 minecraft:red_nether_bricks
fill 346 192 464 349 192 464 minecraft:pink_terracotta
setblock 346 192 468 minecraft:red_nether_bricks
setblock 346 192 503 minecraft:red_nether_bricks
fill 346 192 504 349 192 504 minecraft:pink_terracotta
setblock 347 192 467 minecraft:red_nether_bricks
setblock 347 192 468 minecraft:pink_terracotta
fill 347 192 503 347 193 503 minecraft:pink_terracotta
setblock 348 192 466 minecraft:red_nether_bricks
fill 348 192 467 348 194 467 minecraft:pink_terracotta
fill 348 192 481 348 193 481 minecraft:bone_block
fill 348 192 489 348 193 489 minecraft:bone_block
setblock 349 192 465 minecraft:red_nether_bricks
fill 349 192 466 349 194 466 minecraft:pink_terracotta
setblock 350 192 464 minecraft:red_nether_bricks
fill 350 192 465 353 192 465 minecraft:pink_terracotta
setblock 350 192 504 minecraft:red_nether_bricks
fill 351 192 464 354 192 464 minecraft:pink_terracotta
fill 351 192 481 351 193 481 minecraft:bone_block
fill 351 192 489 351 193 489 minecraft:bone_block
fill 351 192 504 354 192 504 minecraft:pink_terracotta
setblock 354 192 465 minecraft:red_nether_bricks
fill 354 192 481 354 193 481 minecraft:bone_block
fill 354 192 489 354 193 489 minecraft:bone_block
setblock 355 192 464 minecraft:red_nether_bricks
fill 355 192 465 358 192 465 minecraft:pink_terracotta
setblock 355 192 504 minecraft:red_nether_bricks
fill 356 192 464 359 192 464 minecraft:pink_terracotta
fill 356 192 504 359 192 504 minecraft:pink_terracotta
fill 357 192 481 357 193 481 minecraft:bone_block
fill 357 192 489 357 193 489 minecraft:bone_block
fill 358 192 503 360 192 503 minecraft:pink_terracotta
setblock 359 192 465 minecraft:red_nether_bricks
setblock 360 192 464 minecraft:red_nether_bricks
fill 360 192 465 362 192 466 minecraft:pink_terracotta
fill 360 192 481 360 193 481 minecraft:bone_block
fill 360 192 489 360 193 489 minecraft:bone_block
setblock 360 192 504 minecraft:red_nether_bricks
fill 361 192 464 364 192 464 minecraft:pink_terracotta
setblock 361 192 503 minecraft:red_nether_bricks
fill 361 192 504 364 192 504 minecraft:pink_terracotta
setblock 362 192 502 minecraft:red_nether_bricks
fill 362 192 503 365 192 503 minecraft:pink_terracotta
setblock 363 192 465 minecraft:pink_terracotta
setblock 363 192 466 minecraft:red_nether_bricks
fill 363 192 502 363 193 502 minecraft:pink_terracotta
setblock 364 192 465 minecraft:red_nether_bricks
fill 364 192 466 364 193 466 minecraft:pink_terracotta
setblock 365 192 464 minecraft:red_nether_bricks
fill 365 192 465 365 195 465 minecraft:pink_terracotta
setblock 365 192 504 minecraft:red_nether_bricks
fill 366 192 464 366 195 464 minecraft:pink_terracotta
fill 366 192 490 367 192 491 minecraft:pink_terracotta
setblock 366 192 503 minecraft:red_nether_bricks
fill 366 192 504 366 195 504 minecraft:pink_terracotta
fill 367 192 479 368 193 480 minecraft:red_concrete
setblock 367 192 486 minecraft:pink_terracotta
setblock 367 192 487 minecraft:red_nether_bricks
fill 367 192 488 367 194 489 minecraft:pink_terracotta
setblock 367 192 492 minecraft:red_nether_bricks
fill 367 192 493 367 195 493 minecraft:pink_terracotta
fill 367 192 503 367 193 503 minecraft:pink_terracotta
fill 368 192 484 368 192 485 minecraft:pink_terracotta
setblock 368 192 486 minecraft:red_nether_bricks
fill 368 192 487 368 195 487 minecraft:pink_terracotta
setblock 368 192 491 minecraft:red_nether_bricks
fill 368 192 492 368 195 492 minecraft:pink_terracotta
setblock 368 192 495 minecraft:pink_terracotta
setblock 368 192 496 minecraft:red_nether_bricks
setblock 369 192 465 minecraft:red_nether_bricks
setblock 369 192 466 minecraft:pink_terracotta
setblock 369 192 470 minecraft:red_nether_bricks
setblock 369 192 485 minecraft:red_nether_bricks
fill 369 192 486 369 195 486 minecraft:pink_terracotta
setblock 369 192 490 minecraft:red_nether_bricks
fill 369 192 491 369 195 491 minecraft:pink_terracotta
setblock 369 192 494 minecraft:pink_terracotta
setblock 369 192 495 minecraft:red_nether_bricks
fill 369 192 496 369 195 496 minecraft:pink_terracotta
setblock 370 192 464 minecraft:red_nether_bricks
fill 370 192 465 370 193 465 minecraft:pink_terracotta
setblock 370 192 469 minecraft:red_nether_bricks
fill 370 192 470 370 195 470 minecraft:pink_terracotta
setblock 370 192 480 minecraft:pink_terracotta
setblock 370 192 484 minecraft:red_nether_bricks
fill 370 192 485 370 195 485 minecraft:pink_terracotta
setblock 370 192 489 minecraft:red_nether_bricks
fill 370 192 490 370 195 490 minecraft:pink_terracotta
setblock 370 192 494 minecraft:red_nether_bricks
fill 370 192 495 370 195 495 minecraft:pink_terracotta
setblock 370 192 499 minecraft:red_nether_bricks
fill 370 192 500 370 193 500 minecraft:pink_terracotta
setblock 370 192 504 minecraft:red_nether_bricks
fill 330 193 464 331 193 464 minecraft:pink_terracotta
setblock 330 193 468 minecraft:red_nether_bricks
fill 330 193 469 330 193 472 minecraft:pink_terracotta
setblock 330 193 473 minecraft:red_nether_bricks
fill 330 193 474 330 193 477 minecraft:pink_terracotta
setblock 330 193 478 minecraft:red_nether_bricks
fill 330 193 479 330 193 482 minecraft:pink_terracotta
setblock 330 193 483 minecraft:red_nether_bricks
fill 330 193 484 330 193 487 minecraft:pink_terracotta
setblock 330 193 488 minecraft:red_nether_bricks
fill 330 193 489 330 193 492 minecraft:pink_terracotta
setblock 330 193 493 minecraft:red_nether_bricks
fill 330 193 494 330 196 494 minecraft:pink_terracotta
setblock 331 193 467 minecraft:red_nether_bricks
fill 331 193 468 331 194 468 minecraft:pink_terracotta
setblock 331 193 472 minecraft:red_nether_bricks
fill 331 193 473 331 195 473 minecraft:pink_terracotta
fill 331 193 483 331 193 486 minecraft:pink_terracotta
setblock 331 193 487 minecraft:red_nether_bricks
fill 331 193 488 331 194 488 minecraft:pink_terracotta
setblock 331 193 492 minecraft:red_nether_bricks
setblock 331 193 493 minecraft:pink_terracotta
fill 332 193 464 332 194 464 minecraft:white_concrete
setblock 332 193 466 minecraft:light[level=12]
setblock 332 193 474 minecraft:light[level=12]
setblock 332 193 482 minecraft:light[level=12]
setblock 332 193 490 minecraft:light[level=12]
setblock 332 193 498 minecraft:light[level=12]
setblock 334 193 464 minecraft:red_nether_bricks
fill 335 193 464 338 193 464 minecraft:pink_terracotta
fill 336 193 465 337 193 465 minecraft:pink_terracotta
fill 336 193 488 339 193 488 minecraft:bone_block
setblock 338 193 465 minecraft:red_nether_bricks
fill 338 193 466 341 193 466 minecraft:pink_terracotta
setblock 338 193 489 minecraft:bone_block
setblock 339 193 464 minecraft:red_nether_bricks
fill 339 193 465 342 193 465 minecraft:pink_terracotta
fill 340 193 464 343 193 464 minecraft:pink_terracotta
setblock 340 193 467 minecraft:pink_terracotta
setblock 340 193 474 minecraft:light[level=12]
setblock 340 193 490 minecraft:light[level=12]
setblock 340 193 498 minecraft:light[level=12]
fill 340 193 504 343 193 504 minecraft:pink_terracotta
setblock 341 193 467 minecraft:red_nether_bricks
setblock 342 193 466 minecraft:red_nether_bricks
fill 342 193 467 342 196 467 minecraft:pink_terracotta
fill 342 193 482 342 193 483 minecraft:bone_block
fill 342 193 485 349 194 485 minecraft:bone_block
fill 342 193 487 342 193 488 minecraft:bone_block
setblock 343 193 465 minecraft:red_nether_bricks
fill 343 193 466 346 193 466 minecraft:pink_terracotta
setblock 344 193 464 minecraft:red_nether_bricks
fill 344 193 465 347 193 465 minecraft:pink_terracotta
setblock 344 193 503 minecraft:pink_terracotta
setblock 344 193 504 minecraft:red_nether_bricks
fill 345 193 464 348 193 464 minecraft:pink_terracotta
setblock 345 193 467 minecraft:pink_terracotta
setblock 345 193 468 minecraft:red_nether_bricks
fill 345 193 482 345 193 483 minecraft:bone_block
fill 345 193 487 345 193 488 minecraft:bone_block
setblock 345 193 503 minecraft:red_nether_bricks
fill 345 193 504 348 193 504 minecraft:pink_terracotta
setblock 346 193 467 minecraft:red_nether_bricks
setblock 346 193 468 minecraft:pink_terracotta
setblock 346 193 503 minecraft:pink_terracotta
setblock 347 193 466 minecraft:red_nether_bricks
fill 347 193 467 347 194 467 minecraft:pink_terracotta
setblock 348 193 465 minecraft:red_nether_bricks
fill 348 193 466 348 195 466 minecraft:pink_terracotta
setblock 348 193 474 minecraft:light[level=12]
fill 348 193 482 348 193 483 minecraft:bone_block
fill 348 193 487 348 193 488 minecraft:bone_block
setblock 348 193 490 minecraft:light[level=12]
setblock 348 193 498 minecraft:light[level=12]
setblock 349 193 464 minecraft:red_nether_bricks
fill 349 193 465 352 193 465 minecraft:pink_terracotta
setblock 349 193 504 minecraft:red_nether_bricks
fill 350 193 464 353 193 464 minecraft:pink_terracotta
fill 350 193 504 353 193 504 minecraft:pink_terracotta
fill 351 193 482 351 193 483 minecraft:bone_block
fill 351 193 485 362 194 485 minecraft:bone_block
fill 351 193 487 351 193 488 minecraft:bone_block
setblock 353 193 465 minecraft:red_nether_bricks
setblock 354 193 464 minecraft:red_nether_bricks
fill 354 193 465 357 193 465 minecraft:pink_terracotta
fill 354 193 482 354 193 483 minecraft:bone_block
fill 354 193 487 354 193 488 minecraft:bone_block
setblock 354 193 504 minecraft:red_nether_bricks
fill 355 193 464 358 193 464 minecraft:pink_terracotta
fill 355 193 504 358 193 504 minecraft:pink_terracotta
setblock 356 193 466 minecraft:light[level=12]
setblock 356 193 474 minecraft:light[level=12]
setblock 356 193 482 minecraft:light[level=12]
setblock 356 193 490 minecraft:light[level=12]
setblock 356 193 498 minecraft:light[level=12]
fill 357 193 482 357 193 483 minecraft:bone_block
fill 357 193 487 357 193 488 minecraft:bone_block
setblock 358 193 465 minecraft:red_nether_bricks
setblock 359 193 464 minecraft:red_nether_bricks
fill 359 193 465 362 193 465 minecraft:pink_terracotta
setblock 359 193 503 minecraft:pink_terracotta
setblock 359 193 504 minecraft:red_nether_bricks
fill 360 193 464 363 193 464 minecraft:pink_terracotta
fill 360 193 466 361 193 466 minecraft:pink_terracotta
fill 360 193 482 360 193 483 minecraft:bone_block
fill 360 193 487 360 193 488 minecraft:bone_block
setblock 360 193 503 minecraft:red_nether_bricks
fill 360 193 504 363 193 504 minecraft:pink_terracotta
fill 361 193 503 364 193 503 minecraft:pink_terracotta
setblock 362 193 466 minecraft:red_nether_bricks
setblock 363 193 465 minecraft:red_nether_bricks
fill 363 193 466 363 194 466 minecraft:pink_terracotta
setblock 364 193 464 minecraft:red_nether_bricks
fill 364 193 465 364 195 465 minecraft:pink_terracotta
setblock 364 193 474 minecraft:light[level=12]
setblock 364 193 482 minecraft:light[level=12]
setblock 364 193 490 minecraft:light[level=12]
setblock 364 193 498 minecraft:light[level=12]
setblock 364 193 504 minecraft:red_nether_bricks
fill 365 193 464 365 196 464 minecraft:pink_terracotta
setblock 365 193 503 minecraft:red_nether_bricks
fill 365 193 504 365 196 504 minecraft:pink_terracotta
setblock 366 193 491 minecraft:pink_terracotta
fill 366 193 503 366 194 503 minecraft:pink_terracotta
setblock 367 193 487 minecraft:pink_terracotta
setblock 367 193 490 minecraft:pink_terracotta
setblock 367 193 491 minecraft:red_nether_bricks
fill 367 193 492 367 195 492 minecraft:pink_terracotta
setblock 368 193 465 minecraft:red_nether_bricks
setblock 368 193 485 minecraft:red_nether_bricks
fill 368 193 486 368 194 486 minecraft:pink_terracotta
setblock 368 193 490 minecraft:red_nether_bricks
fill 368 193 491 368 196 491 minecraft:pink_terracotta
setblock 368 193 495 minecraft:red_nether_bricks
fill 368 193 496 368 194 496 minecraft:pink_terracotta
setblock 369 193 464 minecraft:red_nether_bricks
setblock 369 193 468 minecraft:pink_terracotta
setblock 369 193 469 minecraft:red_nether_bricks
setblock 369 193 470 minecraft:pink_terracotta
setblock 369 193 484 minecraft:red_nether_bricks
fill 369 193 485 369 194 485 minecraft:pink_terracotta
setblock 369 193 489 minecraft:red_nether_bricks
fill 369 193 490 369 196 490 minecraft:pink_terracotta
setblock 369 193 494 minecraft:red_nether_bricks
fill 369 193 495 369 196 495 minecraft:pink_terracotta
setblock 369 193 504 minecraft:red_nether_bricks
setblock 370 193 464 minecraft:pink_terracotta
setblock 370 193 468 minecraft:red_nether_bricks
fill 370 193 469 370 195 469 minecraft:pink_terracotta
setblock 370 193 473 minecraft:red_nether_bricks
fill 370 193 474 370 194 474 minecraft:pink_terracotta
setblock 370 193 476 minecraft:white_concrete
setblock 370 193 483 minecraft:red_nether_bricks
fill 370 193 484 370 195 484 minecraft:pink_terracotta
setblock 370 193 488 minecraft:red_nether_bricks
fill 370 193 489 370 196 489 minecraft:pink_terracotta
setblock 370 193 493 minecraft:red_nether_bricks
fill 370 193 494 370 196 494 minecraft:pink_terracotta
setblock 370 193 498 minecraft:red_nether_bricks
fill 370 193 499 370 194 499 minecraft:pink_terracotta
setblock 370 193 504 minecraft:pink_terracotta
setblock 330 194 467 minecraft:red_nether_bricks
fill 330 194 468 330 194 471 minecraft:pink_terracotta
setblock 330 194 472 minecraft:red_nether_bricks
fill 330 194 473 330 194 476 minecraft:pink_terracotta
setblock 330 194 477 minecraft:red_nether_bricks
fill 330 194 478 330 194 481 minecraft:pink_terracotta
setblock 330 194 482 minecraft:red_nether_bricks
fill 330 194 483 330 194 486 minecraft:pink_terracotta
setblock 330 194 487 minecraft:red_nether_bricks
fill 330 194 488 330 194 491 minecraft:pink_terracotta
setblock 330 194 492 minecraft:red_nether_bricks
fill 330 194 493 330 197 493 minecraft:pink_terracotta
setblock 330 194 498 minecraft:white_concrete
setblock 331 194 470 minecraft:pink_terracotta
setblock 331 194 471 minecraft:red_nether_bricks
fill 331 194 472 331 196 472 minecraft:pink_terracotta
setblock 331 194 486 minecraft:red_nether_bricks
setblock 331 194 487 minecraft:pink_terracotta
setblock 331 194 491 minecraft:red_nether_bricks
setblock 331 194 492 minecraft:pink_terracotta
fill 335 194 464 337 194 464 minecraft:pink_terracotta
setblock 335 194 484 minecraft:bone_block
setblock 337 194 465 minecraft:red_nether_bricks
setblock 337 194 482 minecraft:bone_block
fill 337 194 488 338 194 488 minecraft:bone_block
setblock 338 194 464 minecraft:red_nether_bricks
fill 338 194 465 340 194 466 minecraft:pink_terracotta
fill 339 194 464 342 194 464 minecraft:pink_terracotta
setblock 340 194 467 minecraft:red_nether_bricks
fill 340 194 504 342 194 504 minecraft:pink_terracotta
setblock 341 194 465 minecraft:pink_terracotta
setblock 341 194 466 minecraft:red_nether_bricks
fill 341 194 467 341 196 467 minecraft:pink_terracotta
fill 341 194 484 341 194 485 minecraft:bone_block
setblock 342 194 465 minecraft:red_nether_bricks
fill 342 194 466 345 194 466 minecraft:pink_terracotta
setblock 343 194 464 minecraft:red_nether_bricks
fill 343 194 465 346 194 465 minecraft:pink_terracotta
setblock 343 194 468 minecraft:pink_terracotta
setblock 343 194 504 minecraft:red_nether_bricks
fill 344 194 464 347 194 464 minecraft:pink_terracotta
setblock 344 194 468 minecraft:red_nether_bricks
fill 344 194 504 347 194 504 minecraft:pink_terracotta
setblock 345 194 467 minecraft:red_nether_bricks
setblock 345 194 468 minecraft:pink_terracotta
setblock 346 194 466 minecraft:red_nether_bricks
fill 346 194 467 346 195 467 minecraft:pink_terracotta
setblock 347 194 465 minecraft:red_nether_bricks
fill 347 194 466 347 195 466 minecraft:pink_terracotta
setblock 348 194 464 minecraft:red_nether_bricks
fill 348 194 465 351 194 465 minecraft:pink_terracotta
setblock 348 194 504 minecraft:red_nether_bricks
fill 349 194 464 352 194 464 minecraft:pink_terracotta
fill 349 194 504 352 194 504 minecraft:pink_terracotta
setblock 350 194 485 minecraft:bone_block
setblock 352 194 465 minecraft:red_nether_bricks
setblock 353 194 464 minecraft:red_nether_bricks
setblock 353 194 465 minecraft:pink_terracotta
setblock 353 194 504 minecraft:red_nether_bricks
fill 354 194 464 357 194 464 minecraft:pink_terracotta
fill 354 194 504 357 194 504 minecraft:pink_terracotta
fill 355 194 493 356 230 494 minecraft:red_nether_bricks
setblock 356 194 465 minecraft:pink_terracotta
setblock 357 194 465 minecraft:red_nether_bricks
fill 357 194 498 359 230 499 minecraft:red_nether_bricks
setblock 358 194 464 minecraft:red_nether_bricks
fill 358 194 465 361 194 465 minecraft:pink_terracotta
fill 358 194 497 359 230 497 minecraft:red_nether_bricks
setblock 358 194 504 minecraft:red_nether_bricks
fill 359 194 464 362 194 464 minecraft:pink_terracotta
setblock 359 194 503 minecraft:red_nether_bricks
fill 359 194 504 362 194 504 minecraft:pink_terracotta
fill 360 194 503 363 194 503 minecraft:pink_terracotta
setblock 362 194 465 minecraft:red_nether_bricks
setblock 362 194 466 minecraft:pink_terracotta
setblock 363 194 464 minecraft:red_nether_bricks
fill 363 194 465 363 195 465 minecraft:pink_terracotta
setblock 363 194 504 minecraft:red_nether_bricks
fill 364 194 464 364 196 464 minecraft:pink_terracotta
setblock 364 194 503 minecraft:red_nether_bricks
fill 364 194 504 364 197 504 minecraft:pink_terracotta
fill 365 194 503 365 195 503 minecraft:pink_terracotta
setblock 367 194 490 minecraft:red_nether_bricks
fill 367 194 491 367 195 491 minecraft:pink_terracotta
setblock 368 194 464 minecraft:red_nether_bricks
setblock 368 194 489 minecraft:red_nether_bricks
fill 368 194 490 368 196 490 minecraft:pink_terracotta
setblock 368 194 494 minecraft:red_nether_bricks
fill 368 194 495 368 195 495 minecraft:pink_terracotta
setblock 368 194 504 minecraft:red_nether_bricks
setblock 369 194 484 minecraft:pink_terracotta
setblock 369 194 488 minecraft:red_nether_bricks
fill 369 194 489 369 197 489 minecraft:pink_terracotta
setblock 369 194 493 minecraft:red_nether_bricks
fill 369 194 494 369 197 494 minecraft:pink_terracotta
fill 370 194 464 370 195 464 minecraft:white_concrete
setblock 370 194 467 minecraft:red_nether_bricks
fill 370 194 468 370 195 468 minecraft:pink_terracotta
setblock 370 194 472 minecraft:red_nether_bricks
fill 370 194 473 370 196 473 minecraft:pink_terracotta
setblock 370 194 482 minecraft:red_nether_bricks
fill 370 194 483 370 195 483 minecraft:pink_terracotta
setblock 370 194 487 minecraft:red_nether_bricks
fill 370 194 488 370 197 488 minecraft:pink_terracotta
setblock 370 194 492 minecraft:red_nether_bricks
fill 370 194 493 370 197 493 minecraft:pink_terracotta
setblock 370 194 497 minecraft:red_nether_bricks
fill 370 194 498 370 195 498 minecraft:pink_terracotta
setblock 330 195 466 minecraft:red_nether_bricks
fill 330 195 467 330 195 470 minecraft:pink_terracotta
setblock 330 195 471 minecraft:red_nether_bricks
fill 330 195 472 330 195 475 minecraft:pink_terracotta
setblock 330 195 476 minecraft:red_nether_bricks
fill 330 195 477 330 195 479 minecraft:pink_terracotta
fill 330 195 482 330 195 485 minecraft:pink_terracotta
setblock 330 195 486 minecraft:red_nether_bricks
fill 330 195 487 330 195 490 minecraft:pink_terracotta
setblock 330 195 491 minecraft:red_nether_bricks
fill 330 195 492 330 197 492 minecraft:pink_terracotta
setblock 330 195 504 minecraft:white_concrete
setblock 331 195 470 minecraft:red_nether_bricks
fill 331 195 471 331 196 471 minecraft:pink_terracotta
setblock 331 195 490 minecraft:red_nether_bricks
setblock 331 195 491 minecraft:pink_terracotta
setblock 336 195 464 minecraft:pink_terracotta
setblock 337 195 464 minecraft:red_nether_bricks
fill 337 195 465 340 195 465 minecraft:pink_terracotta
fill 337 195 485 339 195 486 minecraft:bone_block
fill 338 195 464 341 195 464 minecraft:pink_terracotta
fill 338 195 466 339 195 466 minecraft:pink_terracotta
setblock 340 195 466 minecraft:red_nether_bricks
setblock 340 195 467 minecraft:pink_terracotta
fill 340 195 504 341 195 504 minecraft:pink_terracotta
setblock 341 195 465 minecraft:red_nether_bricks
fill 341 195 466 344 195 466 minecraft:pink_terracotta
setblock 342 195 464 minecraft:red_nether_bricks
fill 342 195 465 345 195 465 minecraft:pink_terracotta
setblock 342 195 504 minecraft:red_nether_bricks
fill 343 195 464 346 195 464 minecraft:pink_terracotta
fill 343 195 504 346 195 504 minecraft:pink_terracotta
setblock 344 195 467 minecraft:red_nether_bricks
setblock 345 195 466 minecraft:red_nether_bricks
setblock 345 195 467 minecraft:pink_terracotta
setblock 346 195 465 minecraft:red_nether_bricks
fill 346 195 466 346 196 466 minecraft:pink_terracotta
setblock 347 195 464 minecraft:red_nether_bricks
fill 347 195 465 350 195 465 minecraft:pink_terracotta
setblock 347 195 504 minecraft:red_nether_bricks
fill 348 195 464 351 195 464 minecraft:pink_terracotta
fill 348 195 504 349 195 504 minecraft:pink_terracotta
setblock 352 195 464 minecraft:red_nether_bricks
fill 353 195 464 356 195 464 minecraft:pink_terracotta
fill 355 195 492 356 196 492 minecraft:red_terracotta
setblock 355 195 504 minecraft:white_concrete
setblock 356 195 504 minecraft:pink_terracotta
setblock 357 195 464 minecraft:red_nether_bricks
fill 357 195 493 357 196 493 minecraft:red_terracotta
fill 357 195 497 357 196 497 minecraft:red_terracotta
setblock 357 195 504 minecraft:red_nether_bricks
fill 358 195 464 361 195 464 minecraft:pink_terracotta
fill 358 195 500 359 196 500 minecraft:red_terracotta
fill 358 195 504 361 195 504 minecraft:pink_terracotta
fill 359 195 465 360 195 465 minecraft:pink_terracotta
fill 359 195 503 362 195 503 minecraft:pink_terracotta
fill 360 195 498 360 196 499 minecraft:red_terracotta
setblock 361 195 465 minecraft:red_nether_bricks
setblock 362 195 464 minecraft:red_nether_bricks
setblock 362 195 465 minecraft:pink_terracotta
setblock 362 195 504 minecraft:red_nether_bricks
fill 363 195 464 363 197 464 minecraft:pink_terracotta
setblock 363 195 503 minecraft:red_nether_bricks
fill 363 195 504 363 198 504 minecraft:pink_terracotta
setblock 364 195 503 minecraft:pink_terracotta
setblock 367 195 464 minecraft:red_nether_bricks
setblock 367 195 490 minecraft:pink_terracotta
setblock 367 195 504 minecraft:red_nether_bricks
setblock 368 195 488 minecraft:red_nether_bricks
fill 368 195 489 368 196 489 minecraft:pink_terracotta
setblock 368 195 493 minecraft:red_nether_bricks
fill 368 195 494 368 196 494 minecraft:pink_terracotta
setblock 369 195 487 minecraft:red_nether_bricks
fill 369 195 488 369 196 488 minecraft:pink_terracotta
setblock 369 195 492 minecraft:red_nether_bricks
fill 369 195 493 369 198 493 minecraft:pink_terracotta
setblock 369 195 497 minecraft:red_nether_bricks
setblock 370 195 471 minecraft:red_nether_bricks
fill 370 195 472 370 196 472 minecraft:pink_terracotta
setblock 370 195 486 minecraft:red_nether_bricks
fill 370 195 487 370 197 487 minecraft:pink_terracotta
setblock 370 195 491 minecraft:red_nether_bricks
fill 370 195 492 370 198 492 minecraft:pink_terracotta
setblock 370 195 496 minecraft:red_nether_bricks
fill 370 195 497 370 198 497 minecraft:pink_terracotta
fill 370 195 502 370 196 502 minecraft:white_concrete
setblock 330 196 466 minecraft:white_concrete
fill 330 196 467 330 196 469 minecraft:pink_terracotta
setblock 330 196 470 minecraft:red_nether_bricks
fill 330 196 471 330 196 474 minecraft:pink_terracotta
setblock 330 196 475 minecraft:red_nether_bricks
fill 330 196 476 330 198 477 minecraft:pink_terracotta
setblock 330 196 485 minecraft:red_nether_bricks
fill 330 196 486 330 196 489 minecraft:pink_terracotta
setblock 330 196 490 minecraft:red_nether_bricks
fill 330 196 491 330 197 491 minecraft:pink_terracotta
setblock 336 196 464 minecraft:red_nether_bricks
setblock 336 196 504 minecraft:white_concrete
fill 337 196 464 340 196 464 minecraft:pink_terracotta
fill 338 196 465 339 196 465 minecraft:pink_terracotta
setblock 339 196 466 minecraft:red_nether_bricks
setblock 340 196 465 minecraft:red_nether_bricks
fill 340 196 466 343 196 466 minecraft:pink_terracotta
setblock 341 196 464 minecraft:red_nether_bricks
fill 341 196 465 344 196 465 minecraft:pink_terracotta
setblock 341 196 504 minecraft:red_nether_bricks
fill 342 196 464 345 196 464 minecraft:pink_terracotta
fill 342 196 504 345 196 504 minecraft:pink_terracotta
setblock 343 196 467 minecraft:red_nether_bricks
setblock 344 196 466 minecraft:red_nether_bricks
setblock 344 196 467 minecraft:pink_terracotta
setblock 345 196 465 minecraft:red_nether_bricks
fill 345 196 466 345 197 466 minecraft:pink_terracotta
setblock 346 196 464 minecraft:red_nether_bricks
fill 346 196 465 348 196 465 minecraft:pink_terracotta
setblock 346 196 504 minecraft:red_nether_bricks
fill 347 196 464 350 196 464 minecraft:pink_terracotta
setblock 347 196 504 minecraft:pink_terracotta
setblock 351 196 464 minecraft:red_nether_bricks
fill 354 196 493 354 196 494 minecraft:red_terracotta
fill 355 196 495 356 196 495 minecraft:red_terracotta
setblock 356 196 464 minecraft:red_nether_bricks
fill 356 196 497 356 196 499 minecraft:red_terracotta
setblock 356 196 504 minecraft:red_nether_bricks
fill 357 196 464 360 196 464 minecraft:pink_terracotta
setblock 357 196 492 minecraft:red_terracotta
setblock 357 196 494 minecraft:red_terracotta
fill 357 196 496 359 196 496 minecraft:red_terracotta
setblock 357 196 500 minecraft:red_terracotta
fill 357 196 504 360 196 504 minecraft:pink_terracotta
setblock 360 196 497 minecraft:red_terracotta
setblock 360 196 500 minecraft:red_terracotta
fill 360 196 503 361 196 503 minecraft:pink_terracotta
setblock 361 196 464 minecraft:red_nether_bricks
setblock 361 196 504 minecraft:red_nether_bricks
fill 362 196 464 362 197 464 minecraft:pink_terracotta
setblock 362 196 503 minecraft:red_nether_bricks
fill 362 196 504 362 199 504 minecraft:pink_terracotta
setblock 363 196 503 minecraft:pink_terracotta
setblock 366 196 504 minecraft:red_nether_bricks
setblock 368 196 492 minecraft:red_nether_bricks
fill 368 196 493 368 197 493 minecraft:pink_terracotta
setblock 369 196 487 minecraft:pink_terracotta
setblock 369 196 491 minecraft:red_nether_bricks
fill 369 196 492 369 198 492 minecraft:pink_terracotta
setblock 369 196 496 minecraft:red_nether_bricks
setblock 370 196 471 minecraft:pink_terracotta
setblock 370 196 477 minecraft:white_concrete
setblock 370 196 485 minecraft:red_nether_bricks
fill 370 196 486 370 197 486 minecraft:pink_terracotta
setblock 370 196 490 minecraft:red_nether_bricks
fill 370 196 491 370 199 491 minecraft:pink_terracotta
setblock 370 196 495 minecraft:red_nether_bricks
fill 370 196 496 370 199 496 minecraft:pink_terracotta
setblock 330 197 468 minecraft:pink_terracotta
setblock 330 197 469 minecraft:red_nether_bricks
fill 330 197 470 330 197 473 minecraft:pink_terracotta
setblock 330 197 474 minecraft:red_nether_bricks
fill 330 197 475 330 200 475 minecraft:pink_terracotta
fill 330 197 478 330 198 478 minecraft:white_concrete
setblock 330 197 488 minecraft:pink_terracotta
setblock 330 197 489 minecraft:red_nether_bricks
setblock 330 197 490 minecraft:pink_terracotta
setblock 330 197 497 minecraft:white_concrete
setblock 333 197 464 minecraft:white_concrete
fill 337 197 464 339 197 464 minecraft:pink_terracotta
setblock 338 197 465 minecraft:pink_terracotta
setblock 339 197 465 minecraft:red_nether_bricks
fill 339 197 466 342 197 466 minecraft:pink_terracotta
setblock 340 197 464 minecraft:red_nether_bricks
fill 340 197 465 343 197 465 minecraft:pink_terracotta
fill 341 197 464 344 197 464 minecraft:pink_terracotta
fill 341 197 504 344 197 504 minecraft:pink_terracotta
setblock 343 197 466 minecraft:red_nether_bricks
setblock 344 197 465 minecraft:red_nether_bricks
setblock 344 197 466 minecraft:pink_terracotta
setblock 345 197 464 minecraft:red_nether_bricks
fill 345 197 465 347 197 465 minecraft:pink_terracotta
setblock 345 197 504 minecraft:red_nether_bricks
fill 346 197 464 349 197 464 minecraft:pink_terracotta
setblock 348 197 504 minecraft:white_concrete
setblock 352 197 464 minecraft:white_concrete
fill 355 197 495 355 198 495 minecraft:pink_concrete
fill 357 197 504 359 197 504 minecraft:pink_terracotta
fill 358 197 464 359 197 464 minecraft:pink_terracotta
setblock 360 197 464 minecraft:red_nether_bricks
setblock 360 197 504 minecraft:red_nether_bricks
setblock 361 197 464 minecraft:pink_terracotta
setblock 361 197 503 minecraft:red_nether_bricks
fill 361 197 504 361 200 504 minecraft:pink_terracotta
setblock 367 197 504 minecraft:white_concrete
setblock 368 197 491 minecraft:red_nether_bricks
setblock 368 197 492 minecraft:pink_terracotta
setblock 369 197 490 minecraft:red_nether_bricks
fill 369 197 491 369 198 491 minecraft:pink_terracotta
setblock 369 197 495 minecraft:red_nether_bricks
setblock 370 197 471 minecraft:white_concrete
setblock 370 197 489 minecraft:red_nether_bricks
fill 370 197 490 370 200 490 minecraft:pink_terracotta
setblock 370 197 494 minecraft:red_nether_bricks
fill 370 197 495 370 200 495 minecraft:pink_terracotta
fill 330 198 469 330 198 472 minecraft:pink_terracotta
setblock 330 198 473 minecraft:red_nether_bricks
fill 330 198 474 330 201 474 minecraft:pink_terracotta
setblock 330 198 484 minecraft:white_concrete
setblock 330 198 503 minecraft:white_concrete
fill 337 198 464 338 198 464 minecraft:pink_terracotta
setblock 338 198 465 minecraft:red_nether_bricks
setblock 339 198 464 minecraft:red_nether_bricks
fill 339 198 465 342 198 465 minecraft:pink_terracotta
fill 340 198 464 343 198 464 minecraft:pink_terracotta
fill 340 198 466 341 198 466 minecraft:pink_terracotta
fill 341 198 504 343 198 504 minecraft:pink_terracotta
setblock 342 198 466 minecraft:red_nether_bricks
setblock 343 198 465 minecraft:red_nether_bricks
setblock 343 198 466 minecraft:pink_terracotta
setblock 344 198 464 minecraft:red_nether_bricks
fill 344 198 465 345 198 465 minecraft:pink_terracotta
setblock 344 198 504 minecraft:red_nether_bricks
fill 345 198 464 347 198 464 minecraft:pink_terracotta
setblock 354 198 504 minecraft:white_concrete
fill 357 198 504 358 198 504 minecraft:pink_terracotta
setblock 359 198 504 minecraft:red_nether_bricks
setblock 360 198 464 minecraft:pink_terracotta
fill 360 198 504 360 201 504 minecraft:pink_terracotta
setblock 369 198 490 minecraft:pink_terracotta
setblock 369 198 494 minecraft:red_nether_bricks
setblock 369 198 495 minecraft:pink_terracotta
setblock 370 198 465 minecraft:white_concrete
setblock 370 198 484 minecraft:white_concrete
setblock 370 198 488 minecraft:red_nether_bricks
fill 370 198 489 370 199 489 minecraft:pink_terracotta
setblock 370 198 493 minecraft:red_nether_bricks
fill 370 198 494 370 201 494 minecraft:pink_terracotta
setblock 330 199 465 minecraft:white_concrete
fill 330 199 470 330 199 471 minecraft:pink_terracotta
setblock 330 199 472 minecraft:red_nether_bricks
fill 330 199 473 330 202 473 minecraft:pink_terracotta
setblock 330 199 476 minecraft:pink_terracotta
setblock 330 199 477 minecraft:red_nether_bricks
fill 330 199 478 330 202 478 minecraft:pink_terracotta
setblock 330 199 490 minecraft:white_concrete
setblock 335 199 504 minecraft:white_concrete
setblock 337 199 464 minecraft:pink_terracotta
setblock 338 199 464 minecraft:red_nether_bricks
fill 338 199 465 341 199 465 minecraft:pink_terracotta
fill 339 199 464 342 199 464 minecraft:pink_terracotta
fill 341 199 504 342 199 504 minecraft:pink_terracotta
setblock 342 199 465 minecraft:red_nether_bricks
setblock 343 199 464 minecraft:red_nether_bricks
fill 343 199 465 344 199 465 minecraft:pink_terracotta
setblock 343 199 504 minecraft:red_nether_bricks
fill 344 199 464 346 199 464 minecraft:pink_terracotta
fill 344 199 504 344 202 504 minecraft:pink_terracotta
fill 356 199 504 357 199 504 minecraft:pink_terracotta
setblock 358 199 504 minecraft:red_nether_bricks
fill 359 199 504 359 202 504 minecraft:pink_terracotta
setblock 363 199 504 minecraft:red_nether_bricks
setblock 365 199 464 minecraft:white_concrete
setblock 369 199 493 minecraft:red_nether_bricks
setblock 369 199 494 minecraft:pink_terracotta
setblock 370 199 478 minecraft:white_concrete
setblock 370 199 492 minecraft:red_nether_bricks
fill 370 199 493 370 202 493 minecraft:pink_terracotta
setblock 370 199 503 minecraft:white_concrete
setblock 330 200 470 minecraft:pink_terracotta
setblock 330 200 471 minecraft:red_nether_bricks
fill 330 200 472 330 203 472 minecraft:pink_terracotta
setblock 330 200 476 minecraft:red_nether_bricks
fill 330 200 477 330 203 477 minecraft:pink_terracotta
setblock 330 200 496 minecraft:white_concrete
fill 331 200 473 331 200 474 minecraft:pink_terracotta
setblock 331 200 475 minecraft:red_nether_bricks
setblock 334 200 464 minecraft:white_concrete
setblock 336 200 464 minecraft:pink_terracotta
setblock 337 200 464 minecraft:red_nether_bricks
fill 338 200 464 340 200 465 minecraft:pink_terracotta
fill 339 200 504 341 200 504 minecraft:pink_terracotta
setblock 341 200 464 minecraft:pink_terracotta
setblock 341 200 465 minecraft:red_nether_bricks
setblock 342 200 464 minecraft:red_nether_bricks
fill 342 200 465 343 200 465 minecraft:pink_terracotta
setblock 342 200 504 minecraft:red_nether_bricks
fill 343 200 464 345 201 464 minecraft:pink_terracotta
fill 343 200 504 343 203 504 minecraft:pink_terracotta
fill 355 200 504 356 200 504 minecraft:pink_terracotta
setblock 357 200 504 minecraft:red_nether_bricks
setblock 358 200 503 minecraft:red_nether_bricks
fill 358 200 504 358 203 504 minecraft:pink_terracotta
setblock 359 200 464 minecraft:white_concrete
fill 359 200 503 360 202 503 minecraft:pink_terracotta
setblock 362 200 504 minecraft:red_nether_bricks
fill 363 200 504 363 203 504 minecraft:pink_terracotta
setblock 366 200 504 minecraft:white_concrete
setblock 370 200 472 minecraft:white_concrete
fill 370 200 474 370 200 475 minecraft:pink_terracotta
setblock 370 200 476 minecraft:red_nether_bricks
setblock 370 200 491 minecraft:red_nether_bricks
fill 370 200 492 370 203 492 minecraft:pink_terracotta
setblock 370 200 496 minecraft:red_nether_bricks
fill 370 200 497 370 203 497 minecraft:pink_terracotta
setblock 330 201 470 minecraft:red_nether_bricks
fill 330 201 471 330 204 471 minecraft:pink_terracotta
setblock 330 201 475 minecraft:red_nether_bricks
fill 330 201 476 331 203 476 minecraft:pink_terracotta
setblock 330 201 479 minecraft:pink_terracotta
setblock 330 201 502 minecraft:white_concrete
fill 331 201 472 331 201 473 minecraft:pink_terracotta
setblock 331 201 474 minecraft:red_nether_bricks
fill 331 201 475 331 204 475 minecraft:pink_terracotta
fill 331 201 477 331 202 477 minecraft:pink_terracotta
setblock 332 201 466 minecraft:light[level=12]
setblock 332 201 474 minecraft:light[level=12]
setblock 332 201 482 minecraft:light[level=12]
setblock 332 201 490 minecraft:light[level=12]
setblock 332 201 498 minecraft:light[level=12]
setblock 336 201 464 minecraft:red_nether_bricks
fill 337 201 464 340 201 464 minecraft:pink_terracotta
fill 338 201 465 339 201 465 minecraft:pink_terracotta
fill 338 201 504 340 201 504 minecraft:pink_terracotta
setblock 340 201 465 minecraft:red_nether_bricks
setblock 340 201 466 minecraft:light[level=12]
setblock 340 201 474 minecraft:light[level=12]
setblock 340 201 482 minecraft:light[level=12]
setblock 340 201 490 minecraft:light[level=12]
setblock 340 201 498 minecraft:light[level=12]
setblock 341 201 464 minecraft:red_nether_bricks
fill 341 201 465 342 203 465 minecraft:pink_terracotta
setblock 341 201 504 minecraft:red_nether_bricks
fill 342 201 464 342 204 464 minecraft:pink_terracotta
fill 342 201 504 342 204 504 minecraft:pink_terracotta
setblock 347 201 504 minecraft:white_concrete
setblock 348 201 466 minecraft:light[level=12]
setblock 348 201 474 minecraft:light[level=12]
setblock 348 201 482 minecraft:light[level=12]
setblock 348 201 490 minecraft:light[level=12]
setblock 348 201 498 minecraft:light[level=12]
setblock 353 201 464 minecraft:white_concrete
fill 354 201 504 355 201 504 minecraft:pink_terracotta
setblock 356 201 466 minecraft:light[level=12]
setblock 356 201 474 minecraft:light[level=12]
setblock 356 201 482 minecraft:light[level=12]
setblock 356 201 490 minecraft:light[level=12]
setblock 356 201 498 minecraft:light[level=12]
setblock 356 201 503 minecraft:pink_terracotta
setblock 356 201 504 minecraft:red_nether_bricks
setblock 357 201 503 minecraft:red_nether_bricks
fill 357 201 504 357 204 504 minecraft:pink_terracotta
fill 358 201 503 358 204 503 minecraft:pink_terracotta
setblock 361 201 503 minecraft:pink_terracotta
setblock 361 201 504 minecraft:red_nether_bricks
fill 362 201 504 362 204 504 minecraft:pink_terracotta
setblock 364 201 466 minecraft:light[level=12]
setblock 364 201 474 minecraft:light[level=12]
setblock 364 201 482 minecraft:light[level=12]
setblock 364 201 490 minecraft:light[level=12]
setblock 364 201 498 minecraft:light[level=12]
setblock 370 201 466 minecraft:white_concrete
fill 370 201 473 370 201 474 minecraft:pink_terracotta
setblock 370 201 475 minecraft:red_nether_bricks
fill 370 201 476 370 202 478 minecraft:pink_terracotta
fill 370 201 491 370 204 491 minecraft:pink_terracotta
setblock 370 201 495 minecraft:red_nether_bricks
fill 370 201 496 370 204 496 minecraft:pink_terracotta
setblock 330 202 464 minecraft:white_concrete
fill 330 202 470 330 205 470 minecraft:pink_terracotta
setblock 330 202 474 minecraft:red_nether_bricks
fill 330 202 475 330 205 475 minecraft:pink_terracotta
setblock 330 202 479 minecraft:red_nether_bricks
fill 330 202 480 330 205 480 minecraft:pink_terracotta
setblock 330 202 483 minecraft:white_concrete
fill 331 202 471 331 202 472 minecraft:pink_terracotta
setblock 331 202 473 minecraft:red_nether_bricks
fill 331 202 474 331 205 474 minecraft:pink_terracotta
setblock 331 202 478 minecraft:red_nether_bricks
fill 332 202 475 332 203 475 minecraft:pink_terracotta
setblock 334 202 504 minecraft:white_concrete
setblock 335 202 464 minecraft:red_nether_bricks
fill 336 202 464 339 202 464 minecraft:pink_terracotta
fill 336 202 504 339 202 504 minecraft:pink_terracotta
fill 337 202 465 338 202 465 minecraft:pink_terracotta
setblock 339 202 465 minecraft:red_nether_bricks
fill 339 202 503 340 202 503 minecraft:pink_terracotta
setblock 340 202 464 minecraft:red_nether_bricks
fill 340 202 465 340 205 465 minecraft:pink_terracotta
setblock 340 202 504 minecraft:red_nether_bricks
fill 341 202 464 341 205 464 minecraft:pink_terracotta
setblock 341 202 503 minecraft:red_nether_bricks
fill 341 202 504 341 205 504 minecraft:pink_terracotta
fill 342 202 503 342 205 503 minecraft:pink_terracotta
fill 343 202 464 344 202 464 minecraft:pink_terracotta
setblock 345 202 464 minecraft:red_nether_bricks
setblock 345 202 504 minecraft:red_nether_bricks
fill 346 202 504 346 205 504 minecraft:pink_terracotta
setblock 347 202 464 minecraft:white_concrete
fill 352 202 504 354 202 504 minecraft:pink_terracotta
fill 354 202 503 355 202 503 minecraft:pink_terracotta
setblock 355 202 504 minecraft:red_nether_bricks
setblock 356 202 503 minecraft:red_nether_bricks
fill 356 202 504 356 205 504 minecraft:pink_terracotta
setblock 357 202 502 minecraft:red_nether_bricks
fill 357 202 503 357 205 503 minecraft:pink_terracotta
fill 358 202 502 360 203 502 minecraft:pink_terracotta
setblock 360 202 504 minecraft:red_nether_bricks
setblock 361 202 503 minecraft:red_nether_bricks
fill 361 202 504 361 205 504 minecraft:pink_terracotta
setblock 366 202 464 minecraft:white_concrete
fill 370 202 472 370 202 473 minecraft:pink_terracotta
setblock 370 202 474 minecraft:red_nether_bricks
fill 370 202 475 370 205 475 minecraft:pink_terracotta
setblock 370 202 479 minecraft:red_nether_bricks
fill 370 202 480 370 204 481 minecraft:pink_terracotta
setblock 370 202 485 minecraft:white_concrete
setblock 370 202 494 minecraft:red_nether_bricks
fill 370 202 495 370 205 495 minecraft:pink_terracotta
setblock 370 202 498 minecraft:pink_terracotta
fill 330 203 469 330 206 469 minecraft:pink_terracotta
setblock 330 203 473 minecraft:red_nether_bricks
fill 330 203 474 330 206 474 minecraft:pink_terracotta
setblock 330 203 478 minecraft:red_nether_bricks
fill 330 203 479 331 205 479 minecraft:pink_terracotta
fill 330 203 481 330 203 482 minecraft:pink_terracotta
setblock 330 203 489 minecraft:white_concrete
setblock 331 203 471 minecraft:pink_terracotta
setblock 331 203 472 minecraft:red_nether_bricks
fill 331 203 473 332 205 473 minecraft:pink_terracotta
setblock 331 203 477 minecraft:red_nether_bricks
fill 331 203 478 331 206 478 minecraft:pink_terracotta
fill 331 203 480 331 204 480 minecraft:pink_terracotta
fill 332 203 474 332 204 474 minecraft:pink_terracotta
setblock 332 203 476 minecraft:red_nether_bricks
fill 332 203 477 332 206 477 minecraft:pink_terracotta
setblock 334 203 464 minecraft:red_nether_bricks
fill 335 203 464 338 203 464 minecraft:pink_terracotta
fill 335 203 504 338 203 504 minecraft:pink_terracotta
fill 336 203 465 337 203 465 minecraft:pink_terracotta
fill 337 203 503 339 203 503 minecraft:pink_terracotta
setblock 338 203 465 minecraft:red_nether_bricks
setblock 339 203 464 minecraft:red_nether_bricks
fill 339 203 465 339 206 465 minecraft:pink_terracotta
setblock 339 203 504 minecraft:red_nether_bricks
fill 340 203 464 340 206 464 minecraft:pink_terracotta
setblock 340 203 503 minecraft:red_nether_bricks
fill 340 203 504 340 206 504 minecraft:pink_terracotta
fill 341 203 503 341 206 503 minecraft:pink_terracotta
setblock 343 203 464 minecraft:pink_terracotta
fill 343 203 503 343 204 503 minecraft:pink_terracotta
setblock 344 203 464 minecraft:red_nether_bricks
setblock 344 203 504 minecraft:red_nether_bricks
fill 345 203 464 345 206 464 minecraft:pink_terracotta
fill 345 203 504 345 206 504 minecraft:pink_terracotta
fill 347 203 504 348 203 504 minecraft:pink_terracotta
setblock 349 203 504 minecraft:red_nether_bricks
fill 350 203 504 353 203 504 minecraft:pink_terracotta
fill 352 203 503 354 203 503 minecraft:pink_terracotta
setblock 354 203 504 minecraft:red_nether_bricks
setblock 355 203 502 minecraft:pink_terracotta
setblock 355 203 503 minecraft:red_nether_bricks
fill 355 203 504 355 206 504 minecraft:pink_terracotta
setblock 356 203 502 minecraft:red_nether_bricks
fill 356 203 503 356 206 503 minecraft:pink_terracotta
fill 357 203 464 358 203 464 minecraft:pink_terracotta
setblock 357 203 501 minecraft:red_nether_bricks
fill 357 203 502 357 206 502 minecraft:pink_terracotta
fill 358 203 501 358 206 501 minecraft:pink_terracotta
setblock 359 203 503 minecraft:pink_terracotta
setblock 359 203 504 minecraft:red_nether_bricks
setblock 360 203 464 minecraft:white_concrete
setblock 360 203 503 minecraft:red_nether_bricks
fill 360 203 504 360 206 504 minecraft:pink_terracotta
setblock 361 203 502 minecraft:red_nether_bricks
fill 361 203 503 362 205 503 minecraft:pink_terracotta
fill 369 203 476 369 203 478 minecraft:pink_terracotta
setblock 370 203 472 minecraft:pink_terracotta
setblock 370 203 473 minecraft:red_nether_bricks
fill 370 203 474 370 206 474 minecraft:pink_terracotta
fill 370 203 476 370 203 477 minecraft:pink_terracotta
setblock 370 203 478 minecraft:red_nether_bricks
fill 370 203 479 370 206 479 minecraft:pink_terracotta
setblock 370 203 482 minecraft:pink_terracotta
setblock 370 203 483 minecraft:red_nether_bricks
setblock 370 203 493 minecraft:red_nether_bricks
fill 370 203 494 370 206 494 minecraft:pink_terracotta
setblock 370 203 498 minecraft:red_nether_bricks
fill 370 203 499 370 206 499 minecraft:pink_terracotta
setblock 330 204 472 minecraft:red_nether_bricks
fill 330 204 473 330 207 473 minecraft:pink_terracotta
setblock 330 204 476 minecraft:pink_terracotta
setblock 330 204 477 minecraft:red_nether_bricks
fill 330 204 478 330 207 478 minecraft:pink_terracotta
setblock 330 204 481 minecraft:pink_terracotta
setblock 330 204 482 minecraft:red_nether_bricks
fill 330 204 483 330 207 483 minecraft:pink_terracotta
setblock 330 204 495 minecraft:white_concrete
setblock 330 204 497 minecraft:red_nether_bricks
fill 330 204 498 330 207 498 minecraft:pink_terracotta
setblock 331 204 470 minecraft:pink_terracotta
setblock 331 204 471 minecraft:red_nether_bricks
fill 331 204 472 332 206 472 minecraft:pink_terracotta
setblock 331 204 476 minecraft:red_nether_bricks
fill 331 204 477 331 207 477 minecraft:pink_terracotta
setblock 331 204 481 minecraft:red_nether_bricks
setblock 332 204 464 minecraft:pink_terracotta
setblock 332 204 475 minecraft:red_nether_bricks
fill 332 204 476 332 207 476 minecraft:pink_terracotta
fill 332 204 478 332 204 479 minecraft:pink_terracotta
setblock 333 204 464 minecraft:red_nether_bricks
fill 333 204 475 333 207 475 minecraft:pink_terracotta
setblock 333 204 504 minecraft:red_nether_bricks
fill 334 204 464 337 204 464 minecraft:pink_terracotta
fill 334 204 504 337 204 504 minecraft:pink_terracotta
fill 335 204 465 336 204 465 minecraft:pink_terracotta
fill 335 204 503 338 204 503 minecraft:pink_terracotta
setblock 337 204 465 minecraft:red_nether_bricks
fill 337 204 502 339 204 502 minecraft:pink_terracotta
setblock 338 204 464 minecraft:red_nether_bricks
fill 338 204 465 338 206 466 minecraft:pink_terracotta
setblock 338 204 504 minecraft:red_nether_bricks
fill 339 204 464 339 207 464 minecraft:pink_terracotta
setblock 339 204 503 minecraft:red_nether_bricks
fill 339 204 504 339 207 504 minecraft:pink_terracotta
setblock 340 204 502 minecraft:red_nether_bricks
fill 340 204 503 340 207 503 minecraft:pink_terracotta
setblock 341 204 465 minecraft:pink_terracotta
fill 341 204 502 341 207 502 minecraft:pink_terracotta
setblock 342 204 465 minecraft:red_nether_bricks
setblock 343 204 464 minecraft:red_nether_bricks
setblock 343 204 504 minecraft:red_nether_bricks
fill 344 204 464 344 207 464 minecraft:pink_terracotta
setblock 344 204 503 minecraft:red_nether_bricks
fill 344 204 504 344 207 504 minecraft:pink_terracotta
fill 345 204 503 345 207 503 minecraft:pink_terracotta
setblock 347 204 504 minecraft:pink_terracotta
setblock 348 204 504 minecraft:red_nether_bricks
fill 349 204 504 352 204 504 minecraft:pink_terracotta
fill 350 204 503 353 204 503 minecraft:pink_terracotta
fill 353 204 502 354 204 502 minecraft:pink_terracotta
setblock 353 204 504 minecraft:red_nether_bricks
fill 354 204 464 357 204 464 minecraft:pink_terracotta
setblock 354 204 503 minecraft:red_nether_bricks
fill 354 204 504 354 207 504 minecraft:pink_terracotta
setblock 355 204 501 minecraft:pink_terracotta
setblock 355 204 502 minecraft:red_nether_bricks
fill 355 204 503 355 207 503 minecraft:pink_terracotta
setblock 356 204 501 minecraft:red_nether_bricks
fill 356 204 502 356 207 502 minecraft:pink_terracotta
fill 357 204 501 357 207 501 minecraft:pink_terracotta
setblock 358 204 464 minecraft:red_nether_bricks
fill 358 204 502 359 204 502 minecraft:pink_terracotta
setblock 358 204 504 minecraft:red_nether_bricks
fill 359 204 464 359 207 464 minecraft:pink_terracotta
fill 359 204 501 360 204 501 minecraft:pink_terracotta
setblock 359 204 503 minecraft:red_nether_bricks
fill 359 204 504 359 207 504 minecraft:pink_terracotta
setblock 360 204 502 minecraft:red_nether_bricks
fill 360 204 503 360 207 503 minecraft:pink_terracotta
fill 361 204 502 361 207 502 minecraft:pink_terracotta
setblock 363 204 504 minecraft:red_nether_bricks
setblock 365 204 504 minecraft:white_concrete
fill 369 204 475 369 204 477 minecraft:pink_terracotta
setblock 369 204 478 minecraft:red_nether_bricks
fill 369 204 479 369 206 480 minecraft:pink_terracotta
fill 370 204 467 370 205 467 minecraft:white_concrete
setblock 370 204 471 minecraft:pink_terracotta
setblock 370 204 472 minecraft:red_nether_bricks
fill 370 204 473 370 207 473 minecraft:pink_terracotta
setblock 370 204 476 minecraft:pink_terracotta
setblock 370 204 477 minecraft:red_nether_bricks
fill 370 204 478 370 207 478 minecraft:pink_terracotta
setblock 370 204 482 minecraft:red_nether_bricks
fill 370 204 483 370 205 485 minecraft:pink_terracotta
setblock 370 204 492 minecraft:red_nether_bricks
fill 370 204 493 370 207 493 minecraft:pink_terracotta
setblock 370 204 497 minecraft:red_nether_bricks
fill 370 204 498 370 207 498 minecraft:pink_terracotta
fill 370 204 500 370 205 500 minecraft:pink_terracotta
fill 330 205 468 330 207 468 minecraft:pink_terracotta
setblock 330 205 471 minecraft:red_nether_bricks
fill 330 205 472 330 208 472 minecraft:pink_terracotta
setblock 330 205 476 minecraft:red_nether_bricks
fill 330 205 477 330 208 477 minecraft:pink_terracotta
setblock 330 205 481 minecraft:red_nether_bricks
fill 330 205 482 331 207 482 minecraft:pink_terracotta
fill 330 205 484 330 206 484 minecraft:pink_terracotta
setblock 330 205 496 minecraft:red_nether_bricks
fill 330 205 497 330 208 497 minecraft:pink_terracotta
fill 330 205 499 330 205 500 minecraft:pink_terracotta
setblock 330 205 501 minecraft:red_nether_bricks
setblock 331 205 464 minecraft:pink_terracotta
setblock 331 205 470 minecraft:red_nether_bricks
fill 331 205 471 331 208 471 minecraft:pink_terracotta
setblock 331 205 475 minecraft:red_nether_bricks
fill 331 205 476 331 208 476 minecraft:pink_terracotta
setblock 331 205 480 minecraft:red_nether_bricks
fill 331 205 481 331 208 481 minecraft:pink_terracotta
setblock 332 205 464 minecraft:red_nether_bricks
setblock 332 205 474 minecraft:red_nether_bricks
fill 332 205 475 332 208 475 minecraft:pink_terracotta
setblock 332 205 478 minecraft:pink_terracotta
setblock 332 205 479 minecraft:red_nether_bricks
fill 332 205 480 332 208 480 minecraft:pink_terracotta
setblock 332 205 504 minecraft:red_nether_bricks
fill 333 205 464 335 205 465 minecraft:pink_terracotta
fill 333 205 474 333 207 474 minecraft:pink_terracotta
fill 333 205 476 333 205 477 minecraft:pink_terracotta
setblock 333 205 478 minecraft:red_nether_bricks
fill 333 205 504 336 205 504 minecraft:pink_terracotta
fill 334 205 503 337 205 503 minecraft:pink_terracotta
setblock 336 205 464 minecraft:pink_terracotta
setblock 336 205 465 minecraft:red_nether_bricks
fill 336 205 466 337 207 466 minecraft:pink_terracotta
fill 336 205 502 338 205 502 minecraft:pink_terracotta
setblock 337 205 464 minecraft:red_nether_bricks
fill 337 205 465 337 208 465 minecraft:pink_terracotta
setblock 337 205 504 minecraft:red_nether_bricks
fill 338 205 464 338 208 464 minecraft:pink_terracotta
setblock 338 205 503 minecraft:red_nether_bricks
fill 338 205 504 338 208 504 minecraft:pink_terracotta
setblock 339 205 466 minecraft:pink_terracotta
setblock 339 205 502 minecraft:red_nether_bricks
fill 339 205 503 339 208 503 minecraft:pink_terracotta
fill 340 205 502 340 208 502 minecraft:pink_terracotta
setblock 341 205 465 minecraft:red_nether_bricks
setblock 342 205 464 minecraft:red_nether_bricks
fill 342 205 465 342 206 465 minecraft:pink_terracotta
fill 342 205 502 343 205 502 minecraft:pink_terracotta
setblock 342 205 504 minecraft:red_nether_bricks
fill 343 205 464 343 208 464 minecraft:pink_terracotta
setblock 343 205 503 minecraft:red_nether_bricks
fill 343 205 504 343 208 504 minecraft:pink_terracotta
fill 344 205 503 344 208 503 minecraft:pink_terracotta
fill 346 205 503 347 205 503 minecraft:pink_terracotta
setblock 347 205 504 minecraft:red_nether_bricks
setblock 348 205 464 minecraft:white_concrete
setblock 348 205 503 minecraft:red_nether_bricks
fill 348 205 504 351 205 504 minecraft:pink_terracotta
fill 349 205 503 352 205 503 minecraft:pink_terracotta
fill 351 205 502 353 205 502 minecraft:pink_terracotta
setblock 352 205 504 minecraft:red_nether_bricks
fill 353 205 464 356 205 464 minecraft:pink_terracotta
fill 353 205 501 354 205 501 minecraft:pink_terracotta
setblock 353 205 503 minecraft:red_nether_bricks
fill 353 205 504 353 208 504 minecraft:pink_terracotta
setblock 354 205 502 minecraft:red_nether_bricks
fill 354 205 503 354 208 503 minecraft:pink_terracotta
setblock 355 205 501 minecraft:red_nether_bricks
fill 355 205 502 355 208 502 minecraft:pink_terracotta
setblock 356 205 500 minecraft:red_nether_bricks
fill 356 205 501 356 208 501 minecraft:pink_terracotta
setblock 357 205 464 minecraft:red_nether_bricks
fill 357 205 500 357 207 500 minecraft:pink_terracotta
setblock 357 205 504 minecraft:red_nether_bricks
fill 358 205 464 358 208 464 minecraft:pink_terracotta
setblock 358 205 502 minecraft:pink_terracotta
setblock 358 205 503 minecraft:red_nether_bricks
fill 358 205 504 358 208 504 minecraft:pink_terracotta
setblock 359 205 501 minecraft:pink_terracotta
setblock 359 205 502 minecraft:red_nether_bricks
fill 359 205 503 359 208 503 minecraft:pink_terracotta
fill 360 205 464 360 206 464 minecraft:pink_terracotta
setblock 360 205 501 minecraft:red_nether_bricks
fill 360 205 502 360 208 502 minecraft:pink_terracotta
setblock 362 205 504 minecraft:red_nether_bricks
setblock 363 205 503 minecraft:red_nether_bricks
fill 363 205 504 364 207 504 minecraft:pink_terracotta
setblock 367 205 464 minecraft:white_concrete
fill 369 205 474 369 205 476 minecraft:pink_terracotta
setblock 369 205 477 minecraft:red_nether_bricks
fill 369 205 478 369 208 478 minecraft:pink_terracotta
setblock 369 205 481 minecraft:pink_terracotta
setblock 369 205 482 minecraft:red_nether_bricks
setblock 370 205 471 minecraft:red_nether_bricks
fill 370 205 472 370 208 472 minecraft:pink_terracotta
setblock 370 205 476 minecraft:red_nether_bricks
fill 370 205 477 370 208 477 minecraft:pink_terracotta
setblock 370 205 480 minecraft:pink_terracotta
setblock 370 205 481 minecraft:red_nether_bricks
fill 370 205 482 370 208 482 minecraft:pink_terracotta
setblock 370 205 486 minecraft:red_nether_bricks
fill 370 205 487 370 208 487 minecraft:pink_terracotta
setblock 370 205 491 minecraft:red_nether_bricks
fill 370 205 492 370 207 492 minecraft:pink_terracotta
setblock 370 205 496 minecraft:red_nether_bricks
fill 370 205 497 370 208 497 minecraft:pink_terracotta
setblock 370 205 501 minecraft:red_nether_bricks
setblock 330 206 464 minecraft:pink_terracotta
setblock 330 206 465 minecraft:red_nether_bricks
fill 330 206 466 330 208 467 minecraft:pink_terracotta
setblock 330 206 470 minecraft:red_nether_bricks
fill 330 206 471 330 209 471 minecraft:pink_terracotta
setblock 330 206 475 minecraft:red_nether_bricks
fill 330 206 476 330 209 476 minecraft:pink_terracotta
setblock 330 206 479 minecraft:pink_terracotta
setblock 330 206 480 minecraft:red_nether_bricks
fill 330 206 481 330 209 481 minecraft:pink_terracotta
setblock 330 206 485 minecraft:red_nether_bricks
setblock 330 206 488 minecraft:white_concrete
fill 330 206 496 330 207 496 minecraft:pink_terracotta
setblock 330 206 499 minecraft:pink_terracotta
setblock 330 206 500 minecraft:red_nether_bricks
fill 330 206 501 330 206 504 minecraft:pink_terracotta
setblock 331 206 464 minecraft:red_nether_bricks
setblock 331 206 469 minecraft:red_nether_bricks
fill 331 206 470 331 209 470 minecraft:pink_terracotta
setblock 331 206 473 minecraft:pink_terracotta
setblock 331 206 474 minecraft:red_nether_bricks
fill 331 206 475 331 209 475 minecraft:pink_terracotta
setblock 331 206 479 minecraft:red_nether_bricks
fill 331 206 480 331 209 480 minecraft:pink_terracotta
setblock 331 206 483 minecraft:pink_terracotta
setblock 331 206 504 minecraft:red_nether_bricks
fill 332 206 464 334 206 465 minecraft:pink_terracotta
setblock 332 206 473 minecraft:red_nether_bricks
fill 332 206 474 332 209 474 minecraft:pink_terracotta
setblock 332 206 478 minecraft:red_nether_bricks
fill 332 206 479 333 208 479 minecraft:pink_terracotta
fill 332 206 481 332 207 481 minecraft:pink_terracotta
setblock 332 206 503 minecraft:red_nether_bricks
fill 332 206 504 335 206 504 minecraft:pink_terracotta
setblock 333 206 476 minecraft:pink_terracotta
setblock 333 206 477 minecraft:red_nether_bricks
fill 333 206 478 333 209 478 minecraft:pink_terracotta
fill 333 206 503 336 206 503 minecraft:pink_terracotta
fill 334 206 502 337 206 502 minecraft:pink_terracotta
setblock 335 206 464 minecraft:pink_terracotta
setblock 335 206 465 minecraft:red_nether_bricks
fill 335 206 466 335 209 466 minecraft:pink_terracotta
setblock 336 206 464 minecraft:red_nether_bricks
fill 336 206 465 336 209 465 minecraft:pink_terracotta
setblock 336 206 504 minecraft:red_nether_bricks
fill 337 206 464 337 209 464 minecraft:pink_terracotta
setblock 337 206 503 minecraft:red_nether_bricks
fill 337 206 504 337 209 504 minecraft:pink_terracotta
setblock 338 206 501 minecraft:pink_terracotta
setblock 338 206 502 minecraft:red_nether_bricks
fill 338 206 503 338 209 503 minecraft:pink_terracotta
fill 339 206 502 339 209 502 minecraft:pink_terracotta
setblock 340 206 465 minecraft:red_nether_bricks
setblock 341 206 464 minecraft:red_nether_bricks
fill 341 206 465 341 208 465 minecraft:pink_terracotta
setblock 341 206 504 minecraft:red_nether_bricks
fill 342 206 464 342 209 464 minecraft:pink_terracotta
setblock 342 206 502 minecraft:pink_terracotta
setblock 342 206 503 minecraft:red_nether_bricks
fill 342 206 504 342 209 504 minecraft:pink_terracotta
setblock 343 206 502 minecraft:red_nether_bricks
fill 343 206 503 343 209 503 minecraft:pink_terracotta
fill 344 206 502 344 208 502 minecraft:pink_terracotta
setblock 346 206 464 minecraft:red_nether_bricks
setblock 346 206 503 minecraft:pink_terracotta
setblock 346 206 504 minecraft:red_nether_bricks
setblock 347 206 503 minecraft:red_nether_bricks
fill 347 206 504 350 206 504 minecraft:pink_terracotta
fill 348 206 503 351 206 503 minecraft:pink_terracotta
fill 349 206 502 352 206 502 minecraft:pink_terracotta
setblock 351 206 464 minecraft:red_nether_bricks
setblock 351 206 504 minecraft:red_nether_bricks
fill 352 206 464 355 206 464 minecraft:pink_terracotta
fill 352 206 501 353 206 501 minecraft:pink_terracotta
setblock 352 206 503 minecraft:red_nether_bricks
fill 352 206 504 352 209 504 minecraft:pink_terracotta
setblock 353 206 502 minecraft:red_nether_bricks
fill 353 206 503 353 209 503 minecraft:pink_terracotta
setblock 354 206 501 minecraft:red_nether_bricks
fill 354 206 502 354 209 502 minecraft:pink_terracotta
setblock 355 206 500 minecraft:red_nether_bricks
fill 355 206 501 355 209 501 minecraft:pink_terracotta
setblock 356 206 464 minecraft:red_nether_bricks
fill 356 206 500 356 208 500 minecraft:pink_terracotta
setblock 356 206 504 minecraft:red_nether_bricks
fill 357 206 464 357 209 464 minecraft:pink_terracotta
setblock 357 206 503 minecraft:red_nether_bricks
fill 357 206 504 357 209 504 minecraft:pink_terracotta
setblock 358 206 500 minecraft:pink_terracotta
setblock 358 206 502 minecraft:red_nether_bricks
fill 358 206 503 358 209 503 minecraft:pink_terracotta
setblock 359 206 501 minecraft:red_nether_bricks
fill 359 206 502 359 209 502 minecraft:pink_terracotta
setblock 360 206 501 minecraft:pink_terracotta
setblock 361 206 464 minecraft:white_concrete
setblock 361 206 503 minecraft:pink_terracotta
setblock 361 206 504 minecraft:red_nether_bricks
setblock 362 206 503 minecraft:red_nether_bricks
fill 362 206 504 362 209 504 minecraft:pink_terracotta
setblock 363 206 503 minecraft:pink_terracotta
fill 369 206 474 369 206 475 minecraft:pink_terracotta
setblock 369 206 476 minecraft:red_nether_bricks
fill 369 206 477 369 209 477 minecraft:pink_terracotta
setblock 369 206 481 minecraft:red_nether_bricks
fill 369 206 482 369 208 483 minecraft:pink_terracotta
fill 370 206 471 370 209 471 minecraft:pink_terracotta
setblock 370 206 475 minecraft:red_nether_bricks
fill 370 206 476 370 209 476 minecraft:pink_terracotta
setblock 370 206 480 minecraft:red_nether_bricks
fill 370 206 481 370 209 481 minecraft:pink_terracotta
fill 370 206 483 370 206 484 minecraft:pink_terracotta
setblock 370 206 485 minecraft:red_nether_bricks
fill 370 206 486 370 209 486 minecraft:pink_terracotta
fill 370 206 488 370 206 489 minecraft:pink_terracotta
setblock 370 206 491 minecraft:pink_terracotta
setblock 370 206 495 minecraft:red_nether_bricks
fill 370 206 496 370 209 496 minecraft:pink_terracotta
setblock 370 206 500 minecraft:red_nether_bricks
fill 370 206 501 370 208 502 minecraft:pink_terracotta
setblock 330 207 464 minecraft:red_nether_bricks
fill 330 207 465 330 210 465 minecraft:pink_terracotta
setblock 330 207 469 minecraft:red_nether_bricks
fill 330 207 470 330 210 470 minecraft:pink_terracotta
setblock 330 207 474 minecraft:red_nether_bricks
fill 330 207 475 330 210 475 minecraft:pink_terracotta
setblock 330 207 479 minecraft:red_nether_bricks
fill 330 207 480 330 210 480 minecraft:pink_terracotta
setblock 330 207 484 minecraft:red_nether_bricks
fill 330 207 485 330 210 485 minecraft:pink_terracotta
setblock 330 207 494 minecraft:white_concrete
setblock 330 207 499 minecraft:red_nether_bricks
fill 330 207 500 330 207 503 minecraft:pink_terracotta
setblock 330 207 504 minecraft:red_nether_bricks
fill 331 207 464 334 207 464 minecraft:pink_terracotta
fill 331 207 469 331 210 469 minecraft:pink_terracotta
setblock 331 207 472 minecraft:pink_terracotta
setblock 331 207 473 minecraft:red_nether_bricks
fill 331 207 474 331 210 474 minecraft:pink_terracotta
setblock 331 207 478 minecraft:red_nether_bricks
fill 331 207 479 331 210 479 minecraft:pink_terracotta
setblock 331 207 483 minecraft:red_nether_bricks
fill 331 207 499 331 207 502 minecraft:pink_terracotta
setblock 331 207 503 minecraft:red_nether_bricks
fill 331 207 504 334 207 504 minecraft:pink_terracotta
fill 332 207 465 333 207 465 minecraft:pink_terracotta
setblock 332 207 472 minecraft:red_nether_bricks
fill 332 207 473 332 209 473 minecraft:pink_terracotta
setblock 332 207 477 minecraft:red_nether_bricks
fill 332 207 478 332 210 478 minecraft:pink_terracotta
setblock 332 207 482 minecraft:red_nether_bricks
fill 332 207 503 335 207 503 minecraft:pink_terracotta
setblock 333 207 476 minecraft:red_nether_bricks
fill 333 207 477 333 208 477 minecraft:pink_terracotta
fill 333 207 502 336 207 502 minecraft:pink_terracotta
setblock 334 207 465 minecraft:red_nether_bricks
fill 334 207 466 334 210 466 minecraft:pink_terracotta
setblock 335 207 464 minecraft:red_nether_bricks
fill 335 207 465 335 210 465 minecraft:pink_terracotta
setblock 335 207 504 minecraft:red_nether_bricks
fill 336 207 464 336 210 464 minecraft:pink_terracotta
setblock 336 207 503 minecraft:red_nether_bricks
fill 336 207 504 336 210 504 minecraft:pink_terracotta
setblock 337 207 501 minecraft:pink_terracotta
setblock 337 207 502 minecraft:red_nether_bricks
fill 337 207 503 337 210 503 minecraft:pink_terracotta
setblock 338 207 465 minecraft:pink_terracotta
setblock 338 207 466 minecraft:red_nether_bricks
setblock 338 207 501 minecraft:red_nether_bricks
fill 338 207 502 338 210 502 minecraft:pink_terracotta
setblock 339 207 465 minecraft:red_nether_bricks
setblock 339 207 501 minecraft:pink_terracotta
setblock 340 207 464 minecraft:red_nether_bricks
fill 340 207 465 340 210 465 minecraft:pink_terracotta
setblock 340 207 504 minecraft:red_nether_bricks
fill 341 207 464 341 210 464 minecraft:pink_terracotta
setblock 341 207 503 minecraft:red_nether_bricks
fill 341 207 504 341 210 504 minecraft:pink_terracotta
setblock 342 207 502 minecraft:red_nether_bricks
fill 342 207 503 342 210 503 minecraft:pink_terracotta
fill 343 207 502 343 208 502 minecraft:pink_terracotta
setblock 345 207 464 minecraft:red_nether_bricks
setblock 345 207 504 minecraft:red_nether_bricks
fill 346 207 464 346 210 464 minecraft:pink_terracotta
setblock 346 207 503 minecraft:red_nether_bricks
fill 346 207 504 349 207 504 minecraft:pink_terracotta
setblock 347 207 502 minecraft:red_nether_bricks
fill 347 207 503 350 207 503 minecraft:pink_terracotta
fill 348 207 502 351 207 502 minecraft:pink_terracotta
setblock 349 207 464 minecraft:pink_terracotta
setblock 350 207 464 minecraft:red_nether_bricks
setblock 350 207 504 minecraft:red_nether_bricks
fill 351 207 464 354 207 464 minecraft:pink_terracotta
fill 351 207 501 352 207 501 minecraft:pink_terracotta
setblock 351 207 503 minecraft:red_nether_bricks
fill 351 207 504 351 210 504 minecraft:pink_terracotta
setblock 352 207 502 minecraft:red_nether_bricks
fill 352 207 503 352 210 503 minecraft:pink_terracotta
setblock 353 207 501 minecraft:red_nether_bricks
fill 353 207 502 353 210 502 minecraft:pink_terracotta
setblock 354 207 500 minecraft:red_nether_bricks
fill 354 207 501 354 210 501 minecraft:pink_terracotta
setblock 355 207 464 minecraft:red_nether_bricks
fill 355 207 500 355 208 500 minecraft:pink_terracotta
setblock 355 207 504 minecraft:red_nether_bricks
fill 356 207 464 356 210 464 minecraft:pink_terracotta
setblock 356 207 503 minecraft:red_nether_bricks
fill 356 207 504 356 210 504 minecraft:pink_terracotta
setblock 357 207 502 minecraft:red_nether_bricks
fill 357 207 503 357 210 503 minecraft:pink_terracotta
setblock 358 207 501 minecraft:red_nether_bricks
fill 358 207 502 358 210 502 minecraft:pink_terracotta
fill 359 207 501 359 208 501 minecraft:pink_terracotta
setblock 360 207 464 minecraft:red_nether_bricks
setblock 360 207 504 minecraft:red_nether_bricks
setblock 361 207 503 minecraft:red_nether_bricks
fill 361 207 504 361 210 504 minecraft:pink_terracotta
fill 362 207 503 362 208 503 minecraft:pink_terracotta
fill 368 207 478 368 207 480 minecraft:pink_terracotta
setblock 369 207 474 minecraft:pink_terracotta
setblock 369 207 475 minecraft:red_nether_bricks
fill 369 207 476 369 210 476 minecraft:pink_terracotta
setblock 369 207 479 minecraft:pink_terracotta
setblock 369 207 480 minecraft:red_nether_bricks
fill 369 207 481 369 210 481 minecraft:pink_terracotta
setblock 369 207 484 minecraft:pink_terracotta
setblock 370 207 474 minecraft:red_nether_bricks
fill 370 207 475 370 210 475 minecraft:pink_terracotta
setblock 370 207 479 minecraft:red_nether_bricks
fill 370 207 480 370 210 480 minecraft:pink_terracotta
setblock 370 207 483 minecraft:pink_terracotta
setblock 370 207 484 minecraft:red_nether_bricks
fill 370 207 485 370 210 485 minecraft:pink_terracotta
setblock 370 207 488 minecraft:pink_terracotta
setblock 370 207 489 minecraft:red_nether_bricks
setblock 370 207 494 minecraft:red_nether_bricks
fill 370 207 495 370 208 495 minecraft:pink_terracotta
setblock 370 207 499 minecraft:red_nether_bricks
fill 370 207 500 370 210 500 minecraft:pink_terracotta
setblock 370 207 503 minecraft:pink_terracotta
fill 330 208 464 333 208 464 minecraft:pink_terracotta
setblock 330 208 468 minecraft:red_nether_bricks
fill 330 208 469 330 211 469 minecraft:pink_terracotta
setblock 330 208 473 minecraft:red_nether_bricks
fill 330 208 474 330 211 474 minecraft:pink_terracotta
setblock 330 208 478 minecraft:red_nether_bricks
fill 330 208 479 330 211 479 minecraft:pink_terracotta
setblock 330 208 482 minecraft:pink_terracotta
setblock 330 208 483 minecraft:red_nether_bricks
fill 330 208 484 331 210 484 minecraft:pink_terracotta
fill 330 208 486 330 209 486 minecraft:pink_terracotta
setblock 330 208 498 minecraft:red_nether_bricks
fill 330 208 499 330 208 502 minecraft:pink_terracotta
setblock 330 208 503 minecraft:red_nether_bricks
fill 330 208 504 333 208 504 minecraft:pink_terracotta
fill 331 208 465 331 208 466 minecraft:pink_terracotta
setblock 331 208 467 minecraft:red_nether_bricks
fill 331 208 468 331 211 468 minecraft:pink_terracotta
setblock 331 208 472 minecraft:red_nether_bricks
fill 331 208 473 331 211 473 minecraft:pink_terracotta
setblock 331 208 477 minecraft:red_nether_bricks
fill 331 208 478 331 211 478 minecraft:pink_terracotta
setblock 331 208 482 minecraft:red_nether_bricks
fill 331 208 483 331 211 483 minecraft:pink_terracotta
fill 331 208 499 331 208 501 minecraft:pink_terracotta
setblock 331 208 502 minecraft:red_nether_bricks
fill 331 208 503 334 208 503 minecraft:pink_terracotta
setblock 332 208 465 minecraft:pink_terracotta
setblock 332 208 472 minecraft:pink_terracotta
setblock 332 208 476 minecraft:red_nether_bricks
fill 332 208 477 332 211 477 minecraft:pink_terracotta
setblock 332 208 481 minecraft:red_nether_bricks
fill 332 208 482 332 211 482 minecraft:pink_terracotta
setblock 333 208 465 minecraft:red_nether_bricks
setblock 333 208 475 minecraft:red_nether_bricks
setblock 333 208 476 minecraft:pink_terracotta
fill 333 208 502 335 208 502 minecraft:pink_terracotta
setblock 334 208 464 minecraft:red_nether_bricks
fill 334 208 465 334 211 465 minecraft:pink_terracotta
setblock 334 208 504 minecraft:red_nether_bricks
fill 335 208 464 335 211 464 minecraft:pink_terracotta
setblock 335 208 503 minecraft:red_nether_bricks
fill 335 208 504 335 211 504 minecraft:pink_terracotta
setblock 336 208 466 minecraft:pink_terracotta
setblock 336 208 501 minecraft:pink_terracotta
setblock 336 208 502 minecraft:red_nether_bricks
fill 336 208 503 336 211 503 minecraft:pink_terracotta
setblock 337 208 466 minecraft:red_nether_bricks
setblock 337 208 501 minecraft:red_nether_bricks
fill 337 208 502 337 211 502 minecraft:pink_terracotta
setblock 338 208 465 minecraft:red_nether_bricks
setblock 338 208 466 minecraft:pink_terracotta
setblock 338 208 501 minecraft:pink_terracotta
setblock 339 208 464 minecraft:red_nether_bricks
fill 339 208 465 339 211 465 minecraft:pink_terracotta
setblock 339 208 504 minecraft:red_nether_bricks
fill 340 208 464 340 211 464 minecraft:pink_terracotta
setblock 340 208 503 minecraft:red_nether_bricks
fill 340 208 504 340 211 504 minecraft:pink_terracotta
setblock 341 208 502 minecraft:red_nether_bricks
fill 341 208 503 341 211 503 minecraft:pink_terracotta
fill 342 208 502 342 209 502 minecraft:pink_terracotta
setblock 344 208 464 minecraft:red_nether_bricks
setblock 344 208 504 minecraft:red_nether_bricks
fill 345 208 464 345 211 464 minecraft:pink_terracotta
setblock 345 208 503 minecraft:red_nether_bricks
fill 345 208 504 348 208 504 minecraft:pink_terracotta
fill 346 208 503 349 208 503 minecraft:pink_terracotta
fill 347 208 464 348 208 464 minecraft:pink_terracotta
fill 347 208 502 350 208 502 minecraft:pink_terracotta
setblock 349 208 464 minecraft:red_nether_bricks
setblock 349 208 504 minecraft:red_nether_bricks
fill 350 208 464 353 208 464 minecraft:pink_terracotta
setblock 350 208 503 minecraft:red_nether_bricks
fill 350 208 504 350 211 504 minecraft:pink_terracotta
setblock 351 208 501 minecraft:pink_terracotta
setblock 351 208 502 minecraft:red_nether_bricks
fill 351 208 503 351 211 503 minecraft:pink_terracotta
setblock 352 208 501 minecraft:red_nether_bricks
fill 352 208 502 352 211 502 minecraft:pink_terracotta
fill 353 208 501 353 211 501 minecraft:pink_terracotta
setblock 354 208 464 minecraft:red_nether_bricks
setblock 354 208 504 minecraft:red_nether_bricks
fill 355 208 464 355 211 464 minecraft:pink_terracotta
setblock 355 208 503 minecraft:red_nether_bricks
fill 355 208 504 355 211 504 minecraft:pink_terracotta
setblock 356 208 502 minecraft:red_nether_bricks
fill 356 208 503 356 211 503 minecraft:pink_terracotta
setblock 357 208 501 minecraft:red_nether_bricks
fill 357 208 502 357 211 502 minecraft:pink_terracotta
fill 358 208 501 358 209 501 minecraft:pink_terracotta
setblock 359 208 464 minecraft:red_nether_bricks
setblock 359 208 504 minecraft:red_nether_bricks
setblock 360 208 503 minecraft:red_nether_bricks
fill 360 208 504 360 211 504 minecraft:pink_terracotta
fill 361 208 503 361 209 503 minecraft:pink_terracotta
setblock 363 208 504 minecraft:pink_terracotta
setblock 364 208 504 minecraft:red_nether_bricks
fill 368 208 478 368 208 479 minecraft:pink_terracotta
setblock 368 208 480 minecraft:red_nether_bricks
fill 368 208 481 368 211 481 minecraft:pink_terracotta
setblock 369 208 474 minecraft:red_nether_bricks
fill 369 208 475 369 210 475 minecraft:pink_terracotta
setblock 369 208 479 minecraft:red_nether_bricks
fill 369 208 480 369 211 480 minecraft:pink_terracotta
setblock 369 208 484 minecraft:red_nether_bricks
fill 369 208 485 369 211 485 minecraft:pink_terracotta
setblock 370 208 468 minecraft:white_concrete
setblock 370 208 473 minecraft:red_nether_bricks
fill 370 208 474 370 211 474 minecraft:pink_terracotta
schedule function dropper:buildpart/115_6 1t
