fill 473 293 276 473 293 277 minecraft:deepslate_tiles
setblock 473 293 278 minecraft:light[level=13]
setblock 473 293 286 minecraft:light[level=13]
setblock 473 293 287 minecraft:deepslate_tiles
setblock 473 293 288 minecraft:cobbled_deepslate
fill 473 293 289 473 296 289 minecraft:deepslate_tiles
setblock 473 293 292 minecraft:deepslate_tiles
setblock 473 293 293 minecraft:cobbled_deepslate
setblock 473 293 294 minecraft:light[level=13]
setblock 473 293 302 minecraft:light[level=13]
setblock 473 293 310 minecraft:light[level=13]
setblock 474 293 276 minecraft:deepslate_tiles
setblock 474 293 277 minecraft:cobbled_deepslate
fill 474 293 314 476 293 314 minecraft:deepslate_tiles
setblock 475 293 276 minecraft:cobbled_deepslate
fill 475 293 277 475 295 278 minecraft:deepslate_tiles
setblock 475 293 316 minecraft:cobbled_deepslate
fill 476 293 276 479 293 276 minecraft:deepslate_tiles
fill 476 293 278 477 293 278 minecraft:deepslate_tiles
fill 476 293 313 477 293 313 minecraft:deepslate_tiles
setblock 476 293 315 minecraft:cobbled_deepslate
fill 476 293 316 479 293 316 minecraft:deepslate_tiles
setblock 477 293 314 minecraft:cobbled_deepslate
fill 477 293 315 477 296 315 minecraft:deepslate_tiles
setblock 478 293 278 minecraft:cobbled_deepslate
setblock 478 293 313 minecraft:cobbled_deepslate
fill 478 293 314 478 296 314 minecraft:deepslate_tiles
setblock 479 293 277 minecraft:cobbled_deepslate
fill 479 293 278 480 295 278 minecraft:deepslate_tiles
fill 479 293 313 479 296 313 minecraft:deepslate_tiles
setblock 480 293 276 minecraft:cobbled_deepslate
fill 480 293 277 480 296 277 minecraft:deepslate_tiles
setblock 480 293 316 minecraft:cobbled_deepslate
fill 481 293 276 481 296 276 minecraft:deepslate_tiles
setblock 481 293 278 minecraft:light[level=13]
setblock 481 293 286 minecraft:light[level=13]
setblock 481 293 294 minecraft:light[level=13]
setblock 481 293 302 minecraft:light[level=13]
setblock 481 293 310 minecraft:light[level=13]
setblock 481 293 315 minecraft:cobbled_deepslate
fill 481 293 316 481 296 316 minecraft:deepslate_tiles
setblock 482 293 313 minecraft:deepslate_tiles
setblock 482 293 314 minecraft:cobbled_deepslate
fill 482 293 315 482 296 315 minecraft:deepslate_tiles
fill 483 293 314 483 296 314 minecraft:deepslate_tiles
setblock 485 293 276 minecraft:cobbled_deepslate
setblock 485 293 316 minecraft:cobbled_deepslate
fill 486 293 275 486 296 276 minecraft:deepslate_tiles
setblock 486 293 314 minecraft:deepslate_tiles
setblock 486 293 315 minecraft:cobbled_deepslate
fill 486 293 316 489 293 316 minecraft:deepslate_tiles
fill 487 293 276 487 295 276 minecraft:deepslate_tiles
setblock 487 293 314 minecraft:cobbled_deepslate
fill 487 293 315 490 293 315 minecraft:deepslate_tiles
fill 488 293 314 491 293 314 minecraft:deepslate_tiles
setblock 489 293 278 minecraft:light[level=13]
setblock 489 293 286 minecraft:light[level=13]
setblock 489 293 294 minecraft:light[level=13]
setblock 489 293 302 minecraft:light[level=13]
setblock 489 293 310 minecraft:light[level=13]
setblock 490 293 316 minecraft:cobbled_deepslate
fill 491 293 306 492 300 306 minecraft:black_concrete
fill 491 293 308 492 300 308 minecraft:black_concrete
setblock 491 293 315 minecraft:cobbled_deepslate
fill 491 293 316 494 293 316 minecraft:deepslate_tiles
fill 492 293 275 492 295 276 minecraft:deepslate_tiles
setblock 492 293 314 minecraft:cobbled_deepslate
fill 492 293 315 492 296 315 minecraft:deepslate_tiles
fill 493 293 276 494 293 276 minecraft:deepslate_tiles
setblock 493 293 313 minecraft:cobbled_deepslate
fill 493 293 314 496 293 314 minecraft:deepslate_tiles
fill 494 293 313 497 293 313 minecraft:deepslate_tiles
setblock 495 293 276 minecraft:cobbled_deepslate
setblock 495 293 316 minecraft:cobbled_deepslate
fill 496 293 276 496 296 276 minecraft:deepslate_tiles
setblock 496 293 315 minecraft:cobbled_deepslate
fill 496 293 316 496 296 316 minecraft:deepslate_tiles
setblock 497 293 278 minecraft:light[level=13]
setblock 497 293 286 minecraft:light[level=13]
setblock 497 293 294 minecraft:light[level=13]
setblock 497 293 302 minecraft:light[level=13]
setblock 497 293 310 minecraft:light[level=13]
setblock 497 293 314 minecraft:cobbled_deepslate
fill 497 293 315 497 296 315 minecraft:deepslate_tiles
fill 498 293 276 499 293 276 minecraft:deepslate_tiles
setblock 498 293 313 minecraft:cobbled_deepslate
fill 498 293 314 498 296 314 minecraft:deepslate_tiles
fill 499 293 313 499 295 313 minecraft:deepslate_tiles
fill 500 293 275 500 308 275 minecraft:deepslate_tiles
setblock 500 293 276 minecraft:cobbled_deepslate
setblock 500 293 316 minecraft:cobbled_deepslate
fill 501 293 276 502 295 276 minecraft:deepslate_tiles
setblock 501 293 315 minecraft:cobbled_deepslate
fill 501 293 316 501 296 316 minecraft:deepslate_tiles
setblock 502 293 314 minecraft:cobbled_deepslate
fill 502 293 315 502 296 315 minecraft:deepslate_tiles
setblock 504 293 315 minecraft:deepslate_tiles
setblock 505 293 278 minecraft:light[level=13]
setblock 505 293 286 minecraft:light[level=13]
setblock 505 293 294 minecraft:light[level=13]
setblock 505 293 302 minecraft:light[level=13]
setblock 505 293 310 minecraft:light[level=13]
setblock 505 293 316 minecraft:cobbled_deepslate
fill 509 293 290 509 293 291 minecraft:deepslate_tiles
setblock 509 293 292 minecraft:cobbled_deepslate
fill 509 293 293 509 296 293 minecraft:deepslate_tiles
fill 510 293 287 510 296 287 minecraft:deepslate_tiles
setblock 510 293 291 minecraft:cobbled_deepslate
fill 510 293 292 510 296 292 minecraft:deepslate_tiles
setblock 510 293 295 minecraft:deepslate_tiles
setblock 510 293 296 minecraft:cobbled_deepslate
fill 511 293 283 511 294 283 minecraft:deepslate_tiles
setblock 511 293 285 minecraft:cobbled_deepslate
fill 511 293 286 511 296 286 minecraft:deepslate_tiles
setblock 511 293 290 minecraft:cobbled_deepslate
fill 511 293 291 511 296 291 minecraft:deepslate_tiles
setblock 511 293 295 minecraft:cobbled_deepslate
fill 511 293 296 511 296 296 minecraft:deepslate_tiles
setblock 511 293 299 minecraft:deepslate_tiles
setblock 511 293 310 minecraft:cobbled_deepslate
fill 511 293 311 511 296 311 minecraft:deepslate_tiles
setblock 511 293 314 minecraft:deepslate_tiles
setblock 511 293 315 minecraft:cobbled_deepslate
fill 511 293 316 511 296 316 minecraft:deepslate_tiles
fill 470 294 288 470 308 288 minecraft:deepslate_tiles
setblock 470 294 289 minecraft:white_wool
fill 470 294 306 470 308 306 minecraft:deepslate_tiles
setblock 470 294 307 minecraft:white_wool
fill 471 294 276 471 294 278 minecraft:deepslate_tiles
setblock 471 294 279 minecraft:cobbled_deepslate
fill 471 294 280 472 296 280 minecraft:deepslate_tiles
setblock 471 294 284 minecraft:cobbled_deepslate
fill 471 294 285 471 297 285 minecraft:deepslate_tiles
setblock 471 294 289 minecraft:cobbled_deepslate
fill 471 294 290 471 297 290 minecraft:deepslate_tiles
setblock 471 294 293 minecraft:deepslate_tiles
setblock 471 294 294 minecraft:cobbled_deepslate
fill 471 294 295 471 297 295 minecraft:deepslate_tiles
setblock 471 294 298 minecraft:deepslate_tiles
fill 471 294 310 471 297 310 minecraft:deepslate_tiles
setblock 471 294 314 minecraft:cobbled_deepslate
fill 471 294 315 473 294 316 minecraft:deepslate_tiles
fill 472 294 276 472 294 277 minecraft:deepslate_tiles
setblock 472 294 278 minecraft:cobbled_deepslate
fill 472 294 279 472 297 279 minecraft:deepslate_tiles
fill 472 294 281 472 294 282 minecraft:deepslate_tiles
setblock 472 294 283 minecraft:cobbled_deepslate
fill 472 294 284 472 296 284 minecraft:deepslate_tiles
setblock 472 294 288 minecraft:cobbled_deepslate
fill 472 294 289 472 297 289 minecraft:deepslate_tiles
setblock 472 294 293 minecraft:cobbled_deepslate
fill 472 294 294 473 296 294 minecraft:deepslate_tiles
fill 472 294 296 472 295 296 minecraft:deepslate_tiles
fill 472 294 311 472 294 312 minecraft:deepslate_tiles
setblock 472 294 313 minecraft:cobbled_deepslate
fill 472 294 314 475 294 314 minecraft:deepslate_tiles
setblock 473 294 276 minecraft:deepslate_tiles
setblock 473 294 277 minecraft:cobbled_deepslate
setblock 473 294 287 minecraft:cobbled_deepslate
fill 473 294 288 473 295 288 minecraft:deepslate_tiles
setblock 473 294 292 minecraft:cobbled_deepslate
fill 473 294 293 473 297 293 minecraft:deepslate_tiles
fill 473 294 313 473 297 313 minecraft:deepslate_tiles
setblock 474 294 276 minecraft:cobbled_deepslate
fill 474 294 277 474 296 278 minecraft:deepslate_tiles
setblock 474 294 315 minecraft:deepslate_tiles
setblock 474 294 316 minecraft:cobbled_deepslate
fill 475 294 276 478 294 276 minecraft:deepslate_tiles
setblock 475 294 315 minecraft:cobbled_deepslate
fill 475 294 316 478 294 316 minecraft:deepslate_tiles
setblock 476 294 278 minecraft:deepslate_tiles
setblock 476 294 313 minecraft:deepslate_tiles
setblock 476 294 314 minecraft:cobbled_deepslate
fill 476 294 315 476 297 315 minecraft:deepslate_tiles
setblock 477 294 278 minecraft:cobbled_deepslate
setblock 477 294 313 minecraft:cobbled_deepslate
fill 477 294 314 477 297 314 minecraft:deepslate_tiles
setblock 478 294 277 minecraft:cobbled_deepslate
fill 478 294 278 478 297 278 minecraft:deepslate_tiles
fill 478 294 313 478 296 313 minecraft:deepslate_tiles
setblock 479 294 276 minecraft:cobbled_deepslate
fill 479 294 277 479 297 277 minecraft:deepslate_tiles
setblock 479 294 316 minecraft:cobbled_deepslate
fill 480 294 276 480 297 276 minecraft:deepslate_tiles
setblock 480 294 315 minecraft:cobbled_deepslate
fill 480 294 316 480 297 316 minecraft:deepslate_tiles
setblock 481 294 314 minecraft:cobbled_deepslate
fill 481 294 315 481 297 315 minecraft:deepslate_tiles
setblock 482 294 313 minecraft:cobbled_deepslate
fill 482 294 314 482 297 314 minecraft:deepslate_tiles
setblock 483 294 277 minecraft:cobbled_deepslate
setblock 484 294 276 minecraft:cobbled_deepslate
setblock 484 294 316 minecraft:cobbled_deepslate
fill 485 294 276 485 297 276 minecraft:deepslate_tiles
setblock 485 294 315 minecraft:cobbled_deepslate
fill 485 294 316 488 294 316 minecraft:deepslate_tiles
setblock 486 294 314 minecraft:cobbled_deepslate
fill 486 294 315 489 294 315 minecraft:deepslate_tiles
fill 487 294 314 490 294 314 minecraft:deepslate_tiles
setblock 488 294 276 minecraft:deepslate_tiles
setblock 489 294 276 minecraft:cobbled_deepslate
setblock 489 294 316 minecraft:cobbled_deepslate
fill 490 294 276 491 296 276 minecraft:deepslate_tiles
fill 490 294 306 490 300 307 minecraft:black_concrete
setblock 490 294 315 minecraft:cobbled_deepslate
fill 490 294 316 493 294 316 minecraft:deepslate_tiles
setblock 491 294 314 minecraft:cobbled_deepslate
fill 491 294 315 491 297 315 minecraft:deepslate_tiles
fill 492 294 314 495 294 314 minecraft:deepslate_tiles
setblock 493 294 276 minecraft:deepslate_tiles
fill 493 294 306 493 300 308 minecraft:black_concrete
fill 493 294 313 496 294 313 minecraft:deepslate_tiles
setblock 494 294 276 minecraft:cobbled_deepslate
setblock 494 294 316 minecraft:cobbled_deepslate
fill 495 294 276 495 297 276 minecraft:deepslate_tiles
setblock 495 294 315 minecraft:cobbled_deepslate
fill 495 294 316 495 297 316 minecraft:deepslate_tiles
setblock 496 294 314 minecraft:cobbled_deepslate
fill 496 294 315 496 297 315 minecraft:deepslate_tiles
setblock 497 294 313 minecraft:cobbled_deepslate
fill 497 294 314 497 297 314 minecraft:deepslate_tiles
setblock 498 294 276 minecraft:deepslate_tiles
fill 498 294 313 498 295 313 minecraft:deepslate_tiles
setblock 499 294 276 minecraft:cobbled_deepslate
setblock 499 294 316 minecraft:cobbled_deepslate
fill 500 294 276 500 297 276 minecraft:deepslate_tiles
setblock 500 294 315 minecraft:cobbled_deepslate
fill 500 294 316 500 297 316 minecraft:deepslate_tiles
setblock 501 294 314 minecraft:cobbled_deepslate
fill 501 294 315 501 297 315 minecraft:deepslate_tiles
setblock 502 294 275 minecraft:redstone_block
setblock 502 294 314 minecraft:deepslate_tiles
setblock 504 294 316 minecraft:cobbled_deepslate
fill 505 294 316 506 295 316 minecraft:deepslate_tiles
setblock 509 294 290 minecraft:deepslate_tiles
setblock 509 294 291 minecraft:cobbled_deepslate
fill 509 294 292 509 297 292 minecraft:deepslate_tiles
fill 509 294 294 509 295 294 minecraft:deepslate_tiles
setblock 510 294 290 minecraft:cobbled_deepslate
fill 510 294 291 510 297 291 minecraft:deepslate_tiles
setblock 510 294 295 minecraft:cobbled_deepslate
fill 510 294 296 510 296 297 minecraft:deepslate_tiles
fill 510 294 316 510 297 316 minecraft:deepslate_tiles
fill 511 294 276 511 295 277 minecraft:deepslate_tiles
fill 511 294 282 511 295 282 minecraft:deepslate_tiles
setblock 511 294 284 minecraft:cobbled_deepslate
fill 511 294 285 511 297 285 minecraft:deepslate_tiles
setblock 511 294 289 minecraft:cobbled_deepslate
fill 511 294 290 511 297 290 minecraft:deepslate_tiles
setblock 511 294 294 minecraft:cobbled_deepslate
fill 511 294 295 511 297 295 minecraft:deepslate_tiles
setblock 511 294 299 minecraft:cobbled_deepslate
fill 511 294 300 511 297 300 minecraft:deepslate_tiles
setblock 511 294 310 minecraft:deepslate_tiles
setblock 511 294 314 minecraft:cobbled_deepslate
fill 511 294 315 511 297 315 minecraft:deepslate_tiles
setblock 512 294 292 minecraft:white_wool
fill 470 295 289 471 298 289 minecraft:deepslate_tiles
fill 470 295 307 470 308 307 minecraft:deepslate_tiles
fill 471 295 276 471 295 277 minecraft:deepslate_tiles
setblock 471 295 278 minecraft:cobbled_deepslate
fill 471 295 279 471 298 279 minecraft:deepslate_tiles
setblock 471 295 283 minecraft:cobbled_deepslate
fill 471 295 284 471 298 284 minecraft:deepslate_tiles
setblock 471 295 288 minecraft:cobbled_deepslate
setblock 471 295 293 minecraft:cobbled_deepslate
fill 471 295 294 471 298 294 minecraft:deepslate_tiles
setblock 471 295 298 minecraft:cobbled_deepslate
setblock 471 295 313 minecraft:cobbled_deepslate
fill 471 295 314 472 295 316 minecraft:deepslate_tiles
setblock 472 295 276 minecraft:deepslate_tiles
setblock 472 295 277 minecraft:cobbled_deepslate
fill 472 295 278 473 297 278 minecraft:deepslate_tiles
setblock 472 295 281 minecraft:deepslate_tiles
setblock 472 295 282 minecraft:cobbled_deepslate
fill 472 295 283 472 298 283 minecraft:deepslate_tiles
setblock 472 295 287 minecraft:cobbled_deepslate
fill 472 295 288 472 297 288 minecraft:deepslate_tiles
setblock 472 295 291 minecraft:deepslate_tiles
setblock 472 295 292 minecraft:cobbled_deepslate
fill 472 295 293 472 298 293 minecraft:deepslate_tiles
setblock 472 295 311 minecraft:deepslate_tiles
setblock 472 295 312 minecraft:cobbled_deepslate
fill 472 295 313 472 298 313 minecraft:deepslate_tiles
setblock 473 295 276 minecraft:cobbled_deepslate
fill 473 295 277 473 298 277 minecraft:deepslate_tiles
setblock 473 295 285 minecraft:light[level=12]
setblock 473 295 291 minecraft:cobbled_deepslate
fill 473 295 292 473 297 292 minecraft:deepslate_tiles
setblock 473 295 299 minecraft:light[level=12]
setblock 473 295 306 minecraft:light[level=12]
fill 473 295 314 473 295 315 minecraft:deepslate_tiles
setblock 473 295 316 minecraft:cobbled_deepslate
fill 474 295 276 477 295 276 minecraft:deepslate_tiles
setblock 474 295 314 minecraft:deepslate_tiles
setblock 474 295 315 minecraft:cobbled_deepslate
fill 474 295 316 477 295 316 minecraft:deepslate_tiles
setblock 475 295 313 minecraft:deepslate_tiles
setblock 475 295 314 minecraft:cobbled_deepslate
fill 475 295 315 475 298 315 minecraft:deepslate_tiles
setblock 476 295 278 minecraft:cobbled_deepslate
setblock 476 295 313 minecraft:cobbled_deepslate
fill 476 295 314 476 298 314 minecraft:deepslate_tiles
setblock 477 295 277 minecraft:cobbled_deepslate
fill 477 295 278 477 298 278 minecraft:deepslate_tiles
fill 477 295 313 477 296 313 minecraft:deepslate_tiles
setblock 478 295 276 minecraft:cobbled_deepslate
fill 478 295 277 478 298 277 minecraft:deepslate_tiles
setblock 478 295 316 minecraft:cobbled_deepslate
fill 479 295 276 479 298 276 minecraft:deepslate_tiles
setblock 479 295 315 minecraft:cobbled_deepslate
fill 479 295 316 479 298 316 minecraft:deepslate_tiles
setblock 480 295 285 minecraft:light[level=12]
setblock 480 295 292 minecraft:light[level=12]
setblock 480 295 299 minecraft:light[level=12]
setblock 480 295 306 minecraft:light[level=12]
setblock 480 295 314 minecraft:cobbled_deepslate
fill 480 295 315 480 298 315 minecraft:deepslate_tiles
setblock 481 295 313 minecraft:cobbled_deepslate
fill 481 295 314 481 298 314 minecraft:deepslate_tiles
setblock 482 295 277 minecraft:cobbled_deepslate
setblock 483 295 276 minecraft:cobbled_deepslate
fill 483 295 277 483 296 277 minecraft:deepslate_tiles
setblock 483 295 316 minecraft:cobbled_deepslate
fill 484 295 276 484 298 276 minecraft:deepslate_tiles
setblock 484 295 315 minecraft:cobbled_deepslate
fill 484 295 316 487 295 316 minecraft:deepslate_tiles
setblock 485 295 314 minecraft:cobbled_deepslate
fill 485 295 315 488 295 315 minecraft:deepslate_tiles
fill 486 295 314 489 295 314 minecraft:deepslate_tiles
setblock 487 295 278 minecraft:light[level=12]
setblock 487 295 285 minecraft:light[level=12]
setblock 487 295 292 minecraft:light[level=12]
setblock 487 295 299 minecraft:light[level=12]
setblock 487 295 306 minecraft:light[level=12]
setblock 487 295 313 minecraft:light[level=12]
setblock 488 295 276 minecraft:cobbled_deepslate
setblock 488 295 316 minecraft:cobbled_deepslate
fill 489 295 276 489 298 276 minecraft:deepslate_tiles
setblock 489 295 315 minecraft:cobbled_deepslate
fill 489 295 316 492 295 316 minecraft:deepslate_tiles
fill 490 295 308 490 300 308 minecraft:black_concrete
setblock 490 295 314 minecraft:cobbled_deepslate
fill 490 295 315 490 298 315 minecraft:deepslate_tiles
fill 491 295 305 493 300 305 minecraft:black_concrete
fill 491 295 309 492 300 309 minecraft:black_concrete
fill 491 295 314 494 295 314 minecraft:deepslate_tiles
setblock 493 295 276 minecraft:cobbled_deepslate
fill 493 295 313 495 295 313 minecraft:deepslate_tiles
setblock 493 295 316 minecraft:cobbled_deepslate
fill 494 295 276 494 298 276 minecraft:deepslate_tiles
setblock 494 295 278 minecraft:light[level=12]
setblock 494 295 285 minecraft:light[level=12]
setblock 494 295 292 minecraft:light[level=12]
setblock 494 295 299 minecraft:light[level=12]
setblock 494 295 306 minecraft:light[level=12]
setblock 494 295 315 minecraft:cobbled_deepslate
fill 494 295 316 494 298 316 minecraft:deepslate_tiles
setblock 495 295 314 minecraft:cobbled_deepslate
fill 495 295 315 495 298 315 minecraft:deepslate_tiles
setblock 496 295 277 minecraft:deepslate_tiles
setblock 496 295 313 minecraft:cobbled_deepslate
fill 496 295 314 496 298 314 minecraft:deepslate_tiles
setblock 497 295 277 minecraft:cobbled_deepslate
fill 497 295 313 497 296 313 minecraft:deepslate_tiles
setblock 498 295 276 minecraft:cobbled_deepslate
setblock 498 295 316 minecraft:cobbled_deepslate
fill 499 295 276 499 298 276 minecraft:deepslate_tiles
fill 499 295 307 501 296 307 minecraft:white_wool
setblock 499 295 315 minecraft:cobbled_deepslate
fill 499 295 316 499 298 316 minecraft:deepslate_tiles
fill 500 295 306 501 296 306 minecraft:white_wool
setblock 500 295 314 minecraft:cobbled_deepslate
fill 500 295 315 500 298 315 minecraft:deepslate_tiles
setblock 501 295 278 minecraft:light[level=12]
setblock 501 295 285 minecraft:light[level=12]
setblock 501 295 292 minecraft:light[level=12]
setblock 501 295 299 minecraft:light[level=12]
setblock 501 295 313 minecraft:light[level=12]
setblock 501 295 314 minecraft:deepslate_tiles
fill 502 295 275 502 308 275 minecraft:deepslate_tiles
setblock 503 295 276 minecraft:cobbled_deepslate
setblock 503 295 316 minecraft:cobbled_deepslate
fill 504 295 316 504 297 316 minecraft:deepslate_tiles
setblock 508 295 278 minecraft:light[level=12]
setblock 508 295 285 minecraft:light[level=12]
setblock 508 295 292 minecraft:light[level=12]
setblock 508 295 299 minecraft:light[level=12]
setblock 508 295 306 minecraft:light[level=12]
fill 508 295 308 508 299 308 minecraft:cobbled_deepslate
setblock 508 295 313 minecraft:light[level=12]
setblock 509 295 290 minecraft:cobbled_deepslate
fill 509 295 291 509 296 291 minecraft:deepslate_tiles
setblock 509 295 295 minecraft:cobbled_deepslate
fill 509 295 307 509 299 307 minecraft:cobbled_deepslate
fill 509 295 309 509 299 309 minecraft:cobbled_deepslate
fill 509 295 316 509 298 316 minecraft:deepslate_tiles
fill 510 295 276 510 297 276 minecraft:deepslate_tiles
setblock 510 295 289 minecraft:cobbled_deepslate
fill 510 295 290 510 298 290 minecraft:deepslate_tiles
setblock 510 295 294 minecraft:cobbled_deepslate
fill 510 295 295 510 298 295 minecraft:deepslate_tiles
setblock 510 295 298 minecraft:deepslate_tiles
fill 510 295 308 510 299 308 minecraft:cobbled_deepslate
setblock 511 295 278 minecraft:cobbled_deepslate
fill 511 295 279 511 296 281 minecraft:deepslate_tiles
setblock 511 295 283 minecraft:cobbled_deepslate
fill 511 295 284 511 298 284 minecraft:deepslate_tiles
setblock 511 295 288 minecraft:cobbled_deepslate
fill 511 295 289 511 298 289 minecraft:deepslate_tiles
setblock 511 295 293 minecraft:cobbled_deepslate
fill 511 295 294 511 298 294 minecraft:deepslate_tiles
setblock 511 295 297 minecraft:deepslate_tiles
setblock 511 295 298 minecraft:cobbled_deepslate
fill 511 295 299 511 298 299 minecraft:deepslate_tiles
setblock 511 295 312 minecraft:deepslate_tiles
setblock 511 295 313 minecraft:cobbled_deepslate
fill 511 295 314 511 298 314 minecraft:deepslate_tiles
fill 512 295 292 512 308 292 minecraft:deepslate_tiles
setblock 471 296 276 minecraft:deepslate_tiles
setblock 471 296 277 minecraft:cobbled_deepslate
fill 471 296 278 471 299 278 minecraft:deepslate_tiles
setblock 471 296 282 minecraft:cobbled_deepslate
fill 471 296 283 471 299 283 minecraft:deepslate_tiles
setblock 471 296 287 minecraft:cobbled_deepslate
fill 471 296 288 471 299 288 minecraft:deepslate_tiles
setblock 471 296 292 minecraft:cobbled_deepslate
fill 471 296 293 471 299 293 minecraft:deepslate_tiles
setblock 471 296 296 minecraft:deepslate_tiles
setblock 471 296 297 minecraft:cobbled_deepslate
fill 471 296 298 471 298 299 minecraft:deepslate_tiles
setblock 471 296 312 minecraft:cobbled_deepslate
fill 471 296 313 471 296 316 minecraft:deepslate_tiles
setblock 472 296 276 minecraft:cobbled_deepslate
fill 472 296 277 472 299 277 minecraft:deepslate_tiles
setblock 472 296 281 minecraft:cobbled_deepslate
fill 472 296 282 472 299 282 minecraft:deepslate_tiles
setblock 472 296 286 minecraft:cobbled_deepslate
fill 472 296 287 472 297 287 minecraft:deepslate_tiles
setblock 472 296 291 minecraft:cobbled_deepslate
fill 472 296 292 472 299 292 minecraft:deepslate_tiles
setblock 472 296 296 minecraft:cobbled_deepslate
fill 472 296 297 472 299 297 minecraft:deepslate_tiles
setblock 472 296 311 minecraft:cobbled_deepslate
fill 472 296 312 472 298 312 minecraft:deepslate_tiles
fill 472 296 314 472 296 315 minecraft:deepslate_tiles
setblock 472 296 316 minecraft:cobbled_deepslate
fill 473 296 276 476 296 276 minecraft:deepslate_tiles
setblock 473 296 279 minecraft:deepslate_tiles
setblock 473 296 290 minecraft:cobbled_deepslate
setblock 473 296 291 minecraft:deepslate_tiles
setblock 473 296 314 minecraft:deepslate_tiles
setblock 473 296 315 minecraft:cobbled_deepslate
fill 473 296 316 476 296 316 minecraft:deepslate_tiles
setblock 474 296 314 minecraft:cobbled_deepslate
fill 474 296 315 474 299 315 minecraft:deepslate_tiles
setblock 475 296 277 minecraft:deepslate_tiles
setblock 475 296 278 minecraft:cobbled_deepslate
fill 475 296 314 475 299 314 minecraft:deepslate_tiles
setblock 476 296 277 minecraft:cobbled_deepslate
fill 476 296 278 476 299 278 minecraft:deepslate_tiles
setblock 476 296 313 minecraft:deepslate_tiles
setblock 477 296 276 minecraft:cobbled_deepslate
fill 477 296 277 477 299 277 minecraft:deepslate_tiles
setblock 477 296 316 minecraft:cobbled_deepslate
fill 478 296 276 478 299 276 minecraft:deepslate_tiles
setblock 478 296 315 minecraft:cobbled_deepslate
fill 478 296 316 478 299 316 minecraft:deepslate_tiles
setblock 479 296 278 minecraft:deepslate_tiles
setblock 479 296 314 minecraft:cobbled_deepslate
fill 479 296 315 479 299 315 minecraft:deepslate_tiles
setblock 480 296 313 minecraft:cobbled_deepslate
fill 480 296 314 480 298 314 minecraft:deepslate_tiles
setblock 481 296 277 minecraft:cobbled_deepslate
setblock 482 296 276 minecraft:cobbled_deepslate
fill 482 296 277 482 297 277 minecraft:deepslate_tiles
setblock 482 296 316 minecraft:cobbled_deepslate
fill 483 296 276 483 299 276 minecraft:deepslate_tiles
setblock 483 296 315 minecraft:cobbled_deepslate
fill 483 296 316 486 296 316 minecraft:deepslate_tiles
setblock 484 296 314 minecraft:cobbled_deepslate
fill 484 296 315 487 296 315 minecraft:deepslate_tiles
setblock 484 296 317 minecraft:redstone_block
fill 485 296 314 488 296 314 minecraft:deepslate_tiles
setblock 487 296 276 minecraft:cobbled_deepslate
setblock 487 296 316 minecraft:cobbled_deepslate
fill 488 296 276 488 299 276 minecraft:deepslate_tiles
setblock 488 296 315 minecraft:cobbled_deepslate
fill 488 296 316 491 296 316 minecraft:deepslate_tiles
fill 489 296 306 489 300 307 minecraft:black_concrete
setblock 489 296 314 minecraft:cobbled_deepslate
fill 489 296 315 489 299 315 minecraft:deepslate_tiles
fill 490 296 305 490 300 305 minecraft:black_concrete
fill 490 296 309 490 300 309 minecraft:black_concrete
fill 490 296 314 493 296 314 minecraft:deepslate_tiles
fill 492 296 275 492 308 275 minecraft:deepslate_tiles
setblock 492 296 276 minecraft:cobbled_deepslate
setblock 492 296 316 minecraft:cobbled_deepslate
fill 493 296 276 493 299 276 minecraft:deepslate_tiles
fill 493 296 309 493 300 309 minecraft:black_concrete
fill 493 296 313 494 296 313 minecraft:deepslate_tiles
setblock 493 296 315 minecraft:cobbled_deepslate
fill 493 296 316 493 299 316 minecraft:deepslate_tiles
fill 494 296 306 494 300 308 minecraft:black_concrete
setblock 494 296 314 minecraft:cobbled_deepslate
fill 494 296 315 494 299 315 minecraft:deepslate_tiles
setblock 495 296 277 minecraft:deepslate_tiles
setblock 495 296 313 minecraft:cobbled_deepslate
fill 495 296 314 495 299 314 minecraft:deepslate_tiles
setblock 496 296 277 minecraft:cobbled_deepslate
setblock 496 296 313 minecraft:deepslate_tiles
setblock 497 296 276 minecraft:cobbled_deepslate
fill 497 296 277 498 296 277 minecraft:deepslate_tiles
setblock 497 296 316 minecraft:cobbled_deepslate
fill 498 296 276 498 299 276 minecraft:deepslate_tiles
setblock 498 296 315 minecraft:cobbled_deepslate
fill 498 296 316 498 299 316 minecraft:deepslate_tiles
setblock 499 296 314 minecraft:cobbled_deepslate
fill 499 296 315 499 298 315 minecraft:deepslate_tiles
setblock 500 296 314 minecraft:deepslate_tiles
setblock 501 296 276 minecraft:deepslate_tiles
setblock 502 296 276 minecraft:cobbled_deepslate
setblock 502 296 316 minecraft:cobbled_deepslate
fill 503 296 316 503 297 316 minecraft:deepslate_tiles
setblock 505 296 316 minecraft:deepslate_tiles
fill 508 296 307 508 299 307 minecraft:cobbled_deepslate
fill 508 296 309 508 299 309 minecraft:cobbled_deepslate
fill 509 296 276 509 298 276 minecraft:deepslate_tiles
setblock 509 296 294 minecraft:cobbled_deepslate
fill 509 296 295 509 297 295 minecraft:deepslate_tiles
setblock 510 296 288 minecraft:cobbled_deepslate
fill 510 296 289 510 298 289 minecraft:deepslate_tiles
setblock 510 296 293 minecraft:cobbled_deepslate
fill 510 296 294 510 299 294 minecraft:deepslate_tiles
setblock 510 296 298 minecraft:cobbled_deepslate
fill 510 296 307 510 299 307 minecraft:cobbled_deepslate
fill 510 296 309 510 299 309 minecraft:cobbled_deepslate
setblock 511 296 276 minecraft:deepslate_tiles
setblock 511 296 277 minecraft:cobbled_deepslate
fill 511 296 278 511 299 278 minecraft:deepslate_tiles
setblock 511 296 282 minecraft:cobbled_deepslate
fill 511 296 283 511 299 283 minecraft:deepslate_tiles
setblock 511 296 287 minecraft:cobbled_deepslate
fill 511 296 288 511 299 288 minecraft:deepslate_tiles
setblock 511 296 292 minecraft:cobbled_deepslate
fill 511 296 293 511 299 293 minecraft:deepslate_tiles
setblock 511 296 297 minecraft:cobbled_deepslate
fill 511 296 298 511 299 298 minecraft:deepslate_tiles
setblock 511 296 301 minecraft:deepslate_tiles
setblock 511 296 312 minecraft:cobbled_deepslate
fill 511 296 313 511 298 313 minecraft:deepslate_tiles
setblock 512 296 307 minecraft:white_wool
setblock 471 297 276 minecraft:cobbled_deepslate
fill 471 297 277 471 300 277 minecraft:deepslate_tiles
setblock 471 297 280 minecraft:deepslate_tiles
setblock 471 297 281 minecraft:cobbled_deepslate
fill 471 297 282 471 300 282 minecraft:deepslate_tiles
setblock 471 297 286 minecraft:cobbled_deepslate
fill 471 297 287 471 300 287 minecraft:deepslate_tiles
setblock 471 297 291 minecraft:cobbled_deepslate
fill 471 297 292 471 300 292 minecraft:deepslate_tiles
setblock 471 297 296 minecraft:cobbled_deepslate
fill 471 297 297 471 300 297 minecraft:deepslate_tiles
setblock 471 297 311 minecraft:cobbled_deepslate
fill 471 297 312 471 297 315 minecraft:deepslate_tiles
setblock 471 297 316 minecraft:cobbled_deepslate
fill 472 297 276 475 297 276 minecraft:deepslate_tiles
setblock 472 297 280 minecraft:cobbled_deepslate
fill 472 297 281 472 300 281 minecraft:deepslate_tiles
setblock 472 297 286 minecraft:deepslate_tiles
setblock 472 297 290 minecraft:cobbled_deepslate
fill 472 297 291 472 299 291 minecraft:deepslate_tiles
setblock 472 297 294 minecraft:deepslate_tiles
setblock 472 297 295 minecraft:cobbled_deepslate
fill 472 297 296 472 300 296 minecraft:deepslate_tiles
setblock 472 297 314 minecraft:deepslate_tiles
setblock 472 297 315 minecraft:cobbled_deepslate
fill 472 297 316 475 297 316 minecraft:deepslate_tiles
setblock 473 297 279 minecraft:cobbled_deepslate
fill 473 297 280 473 300 280 minecraft:deepslate_tiles
setblock 473 297 294 minecraft:cobbled_deepslate
setblock 473 297 314 minecraft:cobbled_deepslate
fill 473 297 315 473 300 315 minecraft:deepslate_tiles
setblock 474 297 277 minecraft:deepslate_tiles
setblock 474 297 278 minecraft:cobbled_deepslate
fill 474 297 314 474 300 314 minecraft:deepslate_tiles
setblock 475 297 277 minecraft:cobbled_deepslate
fill 475 297 278 475 300 278 minecraft:deepslate_tiles
setblock 476 297 276 minecraft:cobbled_deepslate
fill 476 297 277 476 300 277 minecraft:deepslate_tiles
setblock 476 297 316 minecraft:cobbled_deepslate
fill 477 297 276 477 300 276 minecraft:deepslate_tiles
setblock 477 297 315 minecraft:cobbled_deepslate
fill 477 297 316 477 300 316 minecraft:deepslate_tiles
setblock 478 297 314 minecraft:cobbled_deepslate
fill 478 297 315 478 300 315 minecraft:deepslate_tiles
setblock 479 297 278 minecraft:cobbled_deepslate
fill 479 297 314 479 299 314 minecraft:deepslate_tiles
setblock 480 297 277 minecraft:cobbled_deepslate
setblock 481 297 276 minecraft:cobbled_deepslate
fill 481 297 277 481 299 277 minecraft:deepslate_tiles
setblock 481 297 316 minecraft:cobbled_deepslate
fill 482 297 276 482 300 276 minecraft:deepslate_tiles
setblock 482 297 315 minecraft:cobbled_deepslate
fill 482 297 316 485 297 316 minecraft:deepslate_tiles
setblock 483 297 314 minecraft:cobbled_deepslate
fill 483 297 315 486 297 315 minecraft:deepslate_tiles
fill 484 297 317 484 308 317 minecraft:deepslate_tiles
fill 486 297 275 486 308 275 minecraft:deepslate_tiles
setblock 486 297 276 minecraft:cobbled_deepslate
setblock 486 297 316 minecraft:cobbled_deepslate
fill 487 297 276 487 300 276 minecraft:deepslate_tiles
setblock 487 297 315 minecraft:cobbled_deepslate
fill 487 297 316 490 297 316 minecraft:deepslate_tiles
fill 488 297 315 488 300 315 minecraft:deepslate_tiles
fill 489 297 305 489 300 305 minecraft:black_concrete
fill 489 297 308 489 300 308 minecraft:black_concrete
fill 489 297 314 492 297 314 minecraft:deepslate_tiles
setblock 490 297 276 minecraft:deepslate_tiles
fill 490 297 304 493 300 304 minecraft:black_concrete
setblock 491 297 276 minecraft:cobbled_deepslate
fill 491 297 310 492 300 310 minecraft:black_concrete
setblock 491 297 316 minecraft:cobbled_deepslate
fill 492 297 276 492 300 276 minecraft:deepslate_tiles
setblock 492 297 315 minecraft:cobbled_deepslate
fill 492 297 316 492 300 316 minecraft:deepslate_tiles
setblock 493 297 314 minecraft:cobbled_deepslate
fill 493 297 315 493 300 315 minecraft:deepslate_tiles
setblock 494 297 277 minecraft:deepslate_tiles
fill 494 297 305 494 300 305 minecraft:black_concrete
fill 494 297 309 494 300 309 minecraft:black_concrete
fill 494 297 314 494 299 314 minecraft:deepslate_tiles
setblock 495 297 277 minecraft:cobbled_deepslate
setblock 496 297 276 minecraft:cobbled_deepslate
fill 496 297 277 497 298 277 minecraft:deepslate_tiles
setblock 496 297 316 minecraft:cobbled_deepslate
fill 497 297 276 497 300 276 minecraft:deepslate_tiles
setblock 497 297 315 minecraft:cobbled_deepslate
fill 497 297 316 497 300 316 minecraft:deepslate_tiles
setblock 498 297 314 minecraft:cobbled_deepslate
fill 498 297 315 498 299 315 minecraft:deepslate_tiles
setblock 499 297 314 minecraft:deepslate_tiles
setblock 501 297 276 minecraft:cobbled_deepslate
setblock 501 297 316 minecraft:cobbled_deepslate
setblock 502 297 276 minecraft:deepslate_tiles
fill 502 297 316 502 298 316 minecraft:deepslate_tiles
fill 508 297 276 508 299 276 minecraft:deepslate_tiles
setblock 509 297 293 minecraft:cobbled_deepslate
setblock 509 297 294 minecraft:deepslate_tiles
setblock 510 297 288 minecraft:deepslate_tiles
setblock 510 297 292 minecraft:cobbled_deepslate
fill 510 297 293 510 300 293 minecraft:deepslate_tiles
setblock 510 297 296 minecraft:deepslate_tiles
setblock 510 297 297 minecraft:cobbled_deepslate
fill 510 297 298 510 300 298 minecraft:deepslate_tiles
setblock 511 297 276 minecraft:cobbled_deepslate
fill 511 297 277 511 300 277 minecraft:deepslate_tiles
fill 511 297 279 511 297 280 minecraft:deepslate_tiles
setblock 511 297 281 minecraft:cobbled_deepslate
fill 511 297 282 511 300 282 minecraft:deepslate_tiles
setblock 511 297 286 minecraft:cobbled_deepslate
fill 511 297 287 511 300 287 minecraft:deepslate_tiles
setblock 511 297 291 minecraft:cobbled_deepslate
fill 511 297 292 511 300 292 minecraft:deepslate_tiles
setblock 511 297 296 minecraft:cobbled_deepslate
fill 511 297 297 511 300 297 minecraft:deepslate_tiles
setblock 511 297 301 minecraft:cobbled_deepslate
setblock 511 297 312 minecraft:deepslate_tiles
setblock 511 297 316 minecraft:cobbled_deepslate
fill 512 297 307 512 308 307 minecraft:deepslate_tiles
setblock 512 297 315 minecraft:white_wool
fill 471 298 276 474 298 276 minecraft:deepslate_tiles
setblock 471 298 280 minecraft:cobbled_deepslate
fill 471 298 281 471 300 281 minecraft:deepslate_tiles
setblock 471 298 285 minecraft:cobbled_deepslate
fill 471 298 286 471 300 286 minecraft:deepslate_tiles
setblock 471 298 290 minecraft:cobbled_deepslate
fill 471 298 291 471 300 291 minecraft:deepslate_tiles
setblock 471 298 295 minecraft:cobbled_deepslate
fill 471 298 296 471 300 296 minecraft:deepslate_tiles
setblock 471 298 300 minecraft:cobbled_deepslate
fill 471 298 311 471 298 314 minecraft:deepslate_tiles
setblock 471 298 315 minecraft:cobbled_deepslate
fill 471 298 316 474 298 316 minecraft:deepslate_tiles
setblock 472 298 278 minecraft:deepslate_tiles
setblock 472 298 279 minecraft:cobbled_deepslate
fill 472 298 280 472 300 280 minecraft:deepslate_tiles
setblock 472 298 289 minecraft:cobbled_deepslate
setblock 472 298 290 minecraft:deepslate_tiles
setblock 472 298 294 minecraft:cobbled_deepslate
fill 472 298 295 472 300 295 minecraft:deepslate_tiles
setblock 472 298 314 minecraft:cobbled_deepslate
fill 472 298 315 472 300 315 minecraft:deepslate_tiles
setblock 473 298 278 minecraft:cobbled_deepslate
fill 473 298 279 473 300 279 minecraft:deepslate_tiles
fill 473 298 314 473 299 314 minecraft:deepslate_tiles
setblock 474 298 277 minecraft:cobbled_deepslate
fill 474 298 278 474 300 278 minecraft:deepslate_tiles
setblock 475 298 276 minecraft:cobbled_deepslate
fill 475 298 277 475 300 277 minecraft:deepslate_tiles
setblock 475 298 316 minecraft:cobbled_deepslate
fill 476 298 276 476 300 276 minecraft:deepslate_tiles
setblock 476 298 315 minecraft:cobbled_deepslate
fill 476 298 316 476 300 316 minecraft:deepslate_tiles
setblock 477 298 314 minecraft:cobbled_deepslate
fill 477 298 315 477 300 315 minecraft:deepslate_tiles
setblock 478 298 278 minecraft:cobbled_deepslate
fill 478 298 314 478 299 314 minecraft:deepslate_tiles
setblock 479 298 277 minecraft:cobbled_deepslate
setblock 480 298 276 minecraft:cobbled_deepslate
fill 480 298 277 480 300 277 minecraft:deepslate_tiles
setblock 480 298 316 minecraft:cobbled_deepslate
fill 481 298 276 481 300 276 minecraft:deepslate_tiles
setblock 481 298 315 minecraft:cobbled_deepslate
fill 481 298 316 484 298 316 minecraft:deepslate_tiles
fill 482 298 315 485 298 315 minecraft:deepslate_tiles
setblock 485 298 276 minecraft:cobbled_deepslate
setblock 485 298 316 minecraft:cobbled_deepslate
fill 486 298 276 486 300 276 minecraft:deepslate_tiles
setblock 486 298 315 minecraft:cobbled_deepslate
fill 486 298 316 489 298 316 minecraft:deepslate_tiles
fill 487 298 315 487 299 315 minecraft:deepslate_tiles
fill 488 298 306 488 300 307 minecraft:black_concrete
fill 489 298 309 489 300 309 minecraft:black_concrete
setblock 490 298 276 minecraft:cobbled_deepslate
fill 490 298 310 490 300 310 minecraft:black_concrete
fill 490 298 314 491 298 314 minecraft:deepslate_tiles
setblock 490 298 316 minecraft:cobbled_deepslate
fill 491 298 276 491 300 276 minecraft:deepslate_tiles
setblock 491 298 315 minecraft:cobbled_deepslate
fill 491 298 316 491 300 316 minecraft:deepslate_tiles
setblock 492 298 314 minecraft:cobbled_deepslate
fill 492 298 315 492 300 315 minecraft:deepslate_tiles
fill 493 298 310 493 300 310 minecraft:black_concrete
fill 493 298 314 493 299 314 minecraft:deepslate_tiles
setblock 494 298 277 minecraft:cobbled_deepslate
fill 494 298 304 494 300 304 minecraft:black_concrete
setblock 495 298 276 minecraft:cobbled_deepslate
fill 495 298 277 495 300 277 minecraft:deepslate_tiles
fill 495 298 306 495 300 308 minecraft:black_concrete
setblock 495 298 316 minecraft:cobbled_deepslate
fill 496 298 276 496 300 276 minecraft:deepslate_tiles
setblock 496 298 315 minecraft:cobbled_deepslate
fill 496 298 316 496 300 316 minecraft:deepslate_tiles
setblock 497 298 314 minecraft:cobbled_deepslate
fill 497 298 315 497 300 315 minecraft:deepslate_tiles
setblock 500 298 276 minecraft:cobbled_deepslate
setblock 500 298 316 minecraft:cobbled_deepslate
setblock 501 298 276 minecraft:deepslate_tiles
fill 501 298 316 501 299 316 minecraft:deepslate_tiles
fill 508 298 275 508 308 275 minecraft:deepslate_tiles
setblock 509 298 275 minecraft:redstone_block
setblock 510 298 276 minecraft:cobbled_deepslate
fill 510 298 277 510 300 277 minecraft:deepslate_tiles
setblock 510 298 291 minecraft:cobbled_deepslate
fill 510 298 292 510 300 292 minecraft:deepslate_tiles
setblock 510 298 296 minecraft:cobbled_deepslate
fill 510 298 297 510 300 297 minecraft:deepslate_tiles
fill 510 298 299 510 299 299 minecraft:deepslate_tiles
setblock 510 298 316 minecraft:cobbled_deepslate
fill 511 298 276 511 300 276 minecraft:deepslate_tiles
setblock 511 298 279 minecraft:deepslate_tiles
setblock 511 298 280 minecraft:cobbled_deepslate
fill 511 298 281 511 300 281 minecraft:deepslate_tiles
setblock 511 298 285 minecraft:cobbled_deepslate
fill 511 298 286 511 300 286 minecraft:deepslate_tiles
setblock 511 298 290 minecraft:cobbled_deepslate
fill 511 298 291 511 300 291 minecraft:deepslate_tiles
setblock 511 298 295 minecraft:cobbled_deepslate
fill 511 298 296 511 300 296 minecraft:deepslate_tiles
setblock 511 298 300 minecraft:cobbled_deepslate
fill 511 298 301 511 300 301 minecraft:deepslate_tiles
setblock 511 298 315 minecraft:cobbled_deepslate
fill 511 298 316 511 300 316 minecraft:deepslate_tiles
fill 512 298 315 512 308 315 minecraft:deepslate_tiles
fill 470 299 289 470 308 289 minecraft:deepslate_tiles
fill 471 299 276 473 299 276 minecraft:deepslate_tiles
setblock 471 299 279 minecraft:cobbled_deepslate
fill 471 299 280 471 300 280 minecraft:deepslate_tiles
setblock 471 299 284 minecraft:cobbled_deepslate
fill 471 299 285 471 300 285 minecraft:deepslate_tiles
setblock 471 299 289 minecraft:cobbled_deepslate
fill 471 299 290 471 300 290 minecraft:deepslate_tiles
setblock 471 299 294 minecraft:cobbled_deepslate
fill 471 299 295 471 300 295 minecraft:deepslate_tiles
setblock 471 299 298 minecraft:deepslate_tiles
setblock 471 299 299 minecraft:cobbled_deepslate
fill 471 299 300 471 300 300 minecraft:deepslate_tiles
fill 471 299 311 471 299 313 minecraft:deepslate_tiles
setblock 471 299 314 minecraft:cobbled_deepslate
fill 471 299 315 471 300 316 minecraft:deepslate_tiles
setblock 472 299 278 minecraft:cobbled_deepslate
fill 472 299 279 472 300 279 minecraft:deepslate_tiles
setblock 472 299 293 minecraft:cobbled_deepslate
fill 472 299 294 472 300 294 minecraft:deepslate_tiles
setblock 472 299 313 minecraft:cobbled_deepslate
fill 472 299 314 472 300 314 minecraft:deepslate_tiles
fill 472 299 316 473 299 316 minecraft:deepslate_tiles
setblock 473 299 277 minecraft:cobbled_deepslate
fill 473 299 278 473 300 278 minecraft:deepslate_tiles
setblock 474 299 276 minecraft:cobbled_deepslate
fill 474 299 277 474 300 277 minecraft:deepslate_tiles
setblock 474 299 316 minecraft:cobbled_deepslate
fill 475 299 276 475 300 276 minecraft:deepslate_tiles
setblock 475 299 315 minecraft:cobbled_deepslate
fill 475 299 316 475 300 316 minecraft:deepslate_tiles
setblock 476 299 314 minecraft:cobbled_deepslate
fill 476 299 315 476 300 315 minecraft:deepslate_tiles
setblock 477 299 278 minecraft:cobbled_deepslate
fill 477 299 314 477 300 314 minecraft:deepslate_tiles
setblock 478 299 277 minecraft:cobbled_deepslate
setblock 478 299 278 minecraft:deepslate_tiles
setblock 479 299 276 minecraft:cobbled_deepslate
fill 479 299 277 479 300 277 minecraft:deepslate_tiles
setblock 479 299 316 minecraft:cobbled_deepslate
fill 480 299 276 480 300 276 minecraft:deepslate_tiles
setblock 480 299 315 minecraft:cobbled_deepslate
fill 480 299 316 483 299 316 minecraft:deepslate_tiles
fill 481 299 315 484 299 315 minecraft:deepslate_tiles
setblock 484 299 276 minecraft:cobbled_deepslate
setblock 484 299 316 minecraft:cobbled_deepslate
fill 485 299 276 485 300 276 minecraft:deepslate_tiles
setblock 485 299 315 minecraft:cobbled_deepslate
fill 485 299 316 488 299 316 minecraft:deepslate_tiles
setblock 486 299 315 minecraft:deepslate_tiles
fill 488 299 305 488 300 305 minecraft:black_concrete
fill 488 299 308 488 300 309 minecraft:black_concrete
setblock 489 299 276 minecraft:cobbled_deepslate
fill 489 299 304 489 300 304 minecraft:black_concrete
fill 489 299 310 489 300 310 minecraft:black_concrete
setblock 489 299 316 minecraft:cobbled_deepslate
fill 490 299 276 490 300 276 minecraft:deepslate_tiles
fill 490 299 303 493 300 303 minecraft:black_concrete
setblock 490 299 315 minecraft:cobbled_deepslate
fill 490 299 316 490 300 316 minecraft:deepslate_tiles
fill 491 299 311 492 300 311 minecraft:black_concrete
fill 491 299 315 491 300 315 minecraft:deepslate_tiles
setblock 492 299 314 minecraft:deepslate_tiles
setblock 493 299 277 minecraft:cobbled_deepslate
setblock 494 299 276 minecraft:cobbled_deepslate
fill 494 299 277 494 300 277 minecraft:deepslate_tiles
fill 494 299 310 494 300 310 minecraft:black_concrete
setblock 494 299 316 minecraft:cobbled_deepslate
fill 495 299 276 495 300 276 minecraft:deepslate_tiles
fill 495 299 305 495 300 305 minecraft:black_concrete
fill 495 299 309 495 300 309 minecraft:black_concrete
setblock 495 299 315 minecraft:cobbled_deepslate
fill 495 299 316 495 300 316 minecraft:deepslate_tiles
setblock 496 299 277 minecraft:deepslate_tiles
fill 496 299 315 496 300 315 minecraft:deepslate_tiles
setblock 499 299 276 minecraft:cobbled_deepslate
setblock 499 299 316 minecraft:cobbled_deepslate
fill 500 299 276 500 300 276 minecraft:deepslate_tiles
setblock 500 299 316 minecraft:deepslate_tiles
fill 507 299 276 507 300 276 minecraft:deepslate_tiles
setblock 507 299 308 minecraft:cobbled_deepslate
fill 509 299 275 509 308 275 minecraft:deepslate_tiles
setblock 509 299 276 minecraft:cobbled_deepslate
setblock 509 299 306 minecraft:cobbled_deepslate
setblock 509 299 310 minecraft:cobbled_deepslate
setblock 509 299 316 minecraft:cobbled_deepslate
fill 510 299 276 510 300 276 minecraft:deepslate_tiles
fill 510 299 278 510 299 279 minecraft:deepslate_tiles
setblock 510 299 290 minecraft:cobbled_deepslate
fill 510 299 291 510 300 291 minecraft:deepslate_tiles
setblock 510 299 295 minecraft:cobbled_deepslate
fill 510 299 296 510 300 296 minecraft:deepslate_tiles
fill 510 299 316 510 300 316 minecraft:deepslate_tiles
setblock 511 299 279 minecraft:cobbled_deepslate
fill 511 299 280 511 300 280 minecraft:deepslate_tiles
setblock 511 299 284 minecraft:cobbled_deepslate
fill 511 299 285 511 300 285 minecraft:deepslate_tiles
setblock 511 299 289 minecraft:cobbled_deepslate
fill 511 299 290 511 300 290 minecraft:deepslate_tiles
setblock 511 299 294 minecraft:cobbled_deepslate
fill 511 299 295 511 300 295 minecraft:deepslate_tiles
setblock 511 299 299 minecraft:cobbled_deepslate
fill 511 299 300 511 300 300 minecraft:deepslate_tiles
setblock 511 299 308 minecraft:cobbled_deepslate
setblock 511 299 314 minecraft:cobbled_deepslate
fill 511 299 315 511 300 315 minecraft:deepslate_tiles
fill 471 300 276 472 300 276 minecraft:deepslate_tiles
setblock 471 300 278 minecraft:cobbled_deepslate
setblock 471 300 279 minecraft:deepslate_tiles
setblock 471 300 283 minecraft:cobbled_deepslate
setblock 471 300 284 minecraft:deepslate_tiles
setblock 471 300 288 minecraft:cobbled_deepslate
setblock 471 300 289 minecraft:deepslate_tiles
setblock 471 300 293 minecraft:cobbled_deepslate
setblock 471 300 294 minecraft:deepslate_tiles
setblock 471 300 298 minecraft:cobbled_deepslate
setblock 471 300 299 minecraft:deepslate_tiles
setblock 471 300 301 minecraft:deepslate_tiles
setblock 471 300 312 minecraft:deepslate_tiles
setblock 471 300 313 minecraft:cobbled_deepslate
setblock 471 300 314 minecraft:deepslate_tiles
setblock 472 300 277 minecraft:cobbled_deepslate
setblock 472 300 278 minecraft:deepslate_tiles
setblock 472 300 282 minecraft:cobbled_deepslate
setblock 472 300 293 minecraft:deepslate_tiles
setblock 472 300 297 minecraft:cobbled_deepslate
setblock 472 300 298 minecraft:deepslate_tiles
setblock 472 300 313 minecraft:deepslate_tiles
setblock 472 300 316 minecraft:deepslate_tiles
setblock 473 300 276 minecraft:cobbled_deepslate
setblock 473 300 277 minecraft:deepslate_tiles
setblock 473 300 316 minecraft:cobbled_deepslate
setblock 474 300 276 minecraft:deepslate_tiles
setblock 474 300 315 minecraft:cobbled_deepslate
setblock 474 300 316 minecraft:deepslate_tiles
setblock 475 300 314 minecraft:cobbled_deepslate
setblock 475 300 315 minecraft:deepslate_tiles
setblock 476 300 278 minecraft:cobbled_deepslate
setblock 476 300 314 minecraft:deepslate_tiles
setblock 477 300 277 minecraft:cobbled_deepslate
setblock 477 300 278 minecraft:deepslate_tiles
setblock 478 300 276 minecraft:cobbled_deepslate
setblock 478 300 277 minecraft:deepslate_tiles
setblock 478 300 316 minecraft:cobbled_deepslate
setblock 479 300 276 minecraft:deepslate_tiles
setblock 479 300 315 minecraft:cobbled_deepslate
fill 479 300 316 482 300 316 minecraft:deepslate_tiles
fill 480 300 315 482 300 315 minecraft:deepslate_tiles
fill 481 300 275 481 308 275 minecraft:deepslate_tiles
setblock 482 300 275 minecraft:redstone_block
setblock 483 300 276 minecraft:cobbled_deepslate
setblock 483 300 316 minecraft:cobbled_deepslate
setblock 484 300 276 minecraft:deepslate_tiles
fill 484 300 316 487 300 316 minecraft:deepslate_tiles
fill 487 300 306 487 300 307 minecraft:black_concrete
setblock 488 300 276 minecraft:cobbled_deepslate
setblock 488 300 304 minecraft:black_concrete
setblock 488 300 316 minecraft:cobbled_deepslate
setblock 489 300 276 minecraft:deepslate_tiles
setblock 489 300 303 minecraft:black_concrete
setblock 489 300 315 minecraft:cobbled_deepslate
setblock 489 300 316 minecraft:deepslate_tiles
setblock 490 300 311 minecraft:black_concrete
setblock 490 300 315 minecraft:deepslate_tiles
setblock 493 300 276 minecraft:cobbled_deepslate
setblock 493 300 277 minecraft:deepslate_tiles
setblock 493 300 311 minecraft:black_concrete
setblock 493 300 316 minecraft:cobbled_deepslate
setblock 494 300 276 minecraft:deepslate_tiles
setblock 494 300 303 minecraft:black_concrete
setblock 494 300 315 minecraft:cobbled_deepslate
setblock 494 300 316 minecraft:deepslate_tiles
setblock 495 300 304 minecraft:black_concrete
setblock 495 300 310 minecraft:black_concrete
setblock 495 300 315 minecraft:deepslate_tiles
fill 496 300 305 496 300 308 minecraft:black_concrete
setblock 498 300 276 minecraft:cobbled_deepslate
setblock 498 300 316 minecraft:cobbled_deepslate
setblock 499 300 276 minecraft:deepslate_tiles
setblock 499 300 316 minecraft:deepslate_tiles
setblock 508 300 276 minecraft:cobbled_deepslate
fill 509 300 276 509 300 277 minecraft:deepslate_tiles
setblock 510 300 278 minecraft:deepslate_tiles
setblock 510 300 279 minecraft:cobbled_deepslate
setblock 510 300 280 minecraft:deepslate_tiles
setblock 510 300 294 minecraft:cobbled_deepslate
setblock 510 300 295 minecraft:deepslate_tiles
setblock 510 300 299 minecraft:cobbled_deepslate
setblock 511 300 278 minecraft:cobbled_deepslate
setblock 511 300 279 minecraft:deepslate_tiles
setblock 511 300 283 minecraft:cobbled_deepslate
setblock 511 300 284 minecraft:deepslate_tiles
setblock 511 300 288 minecraft:cobbled_deepslate
setblock 511 300 289 minecraft:deepslate_tiles
setblock 511 300 293 minecraft:cobbled_deepslate
setblock 511 300 294 minecraft:deepslate_tiles
setblock 511 300 298 minecraft:cobbled_deepslate
setblock 511 300 299 minecraft:deepslate_tiles
setblock 511 300 302 minecraft:deepslate_tiles
setblock 511 300 314 minecraft:deepslate_tiles
setblock 473 301 278 minecraft:light[level=13]
setblock 473 301 285 minecraft:light[level=12]
setblock 473 301 286 minecraft:light[level=13]
setblock 473 301 292 minecraft:light[level=12]
setblock 473 301 294 minecraft:light[level=13]
setblock 473 301 299 minecraft:light[level=12]
setblock 473 301 302 minecraft:light[level=13]
setblock 473 301 306 minecraft:light[level=12]
setblock 473 301 310 minecraft:light[level=13]
setblock 473 301 313 minecraft:light[level=12]
setblock 480 301 278 minecraft:light[level=12]
setblock 480 301 285 minecraft:light[level=12]
setblock 480 301 292 minecraft:light[level=12]
setblock 480 301 299 minecraft:light[level=12]
setblock 480 301 306 minecraft:light[level=12]
setblock 480 301 313 minecraft:light[level=12]
setblock 481 301 278 minecraft:light[level=13]
setblock 481 301 286 minecraft:light[level=13]
setblock 481 301 294 minecraft:light[level=13]
setblock 481 301 302 minecraft:light[level=13]
setblock 481 301 310 minecraft:light[level=13]
fill 482 301 275 482 308 275 minecraft:deepslate_tiles
setblock 487 301 278 minecraft:light[level=12]
setblock 487 301 285 minecraft:light[level=12]
setblock 487 301 292 minecraft:light[level=12]
setblock 487 301 299 minecraft:light[level=12]
setblock 487 301 306 minecraft:light[level=12]
setblock 487 301 313 minecraft:light[level=12]
setblock 489 301 278 minecraft:light[level=13]
setblock 489 301 286 minecraft:light[level=13]
setblock 489 301 294 minecraft:light[level=13]
setblock 489 301 302 minecraft:light[level=13]
setblock 489 301 310 minecraft:light[level=13]
setblock 494 301 278 minecraft:light[level=12]
setblock 494 301 285 minecraft:light[level=12]
setblock 494 301 292 minecraft:light[level=12]
setblock 494 301 299 minecraft:light[level=12]
setblock 494 301 306 minecraft:light[level=12]
setblock 494 301 313 minecraft:light[level=12]
setblock 497 301 278 minecraft:light[level=13]
setblock 497 301 286 minecraft:light[level=13]
setblock 497 301 294 minecraft:light[level=13]
setblock 497 301 302 minecraft:light[level=13]
setblock 497 301 310 minecraft:light[level=13]
setblock 501 301 278 minecraft:light[level=12]
setblock 501 301 285 minecraft:light[level=12]
setblock 501 301 292 minecraft:light[level=12]
setblock 501 301 299 minecraft:light[level=12]
setblock 501 301 306 minecraft:light[level=12]
setblock 501 301 313 minecraft:light[level=12]
setblock 505 301 278 minecraft:light[level=13]
setblock 505 301 286 minecraft:light[level=13]
setblock 505 301 294 minecraft:light[level=13]
setblock 505 301 302 minecraft:light[level=13]
setblock 505 301 310 minecraft:light[level=13]
setblock 508 301 278 minecraft:light[level=12]
setblock 508 301 285 minecraft:light[level=12]
setblock 508 301 292 minecraft:light[level=12]
setblock 508 301 299 minecraft:light[level=12]
setblock 508 301 306 minecraft:light[level=12]
setblock 508 301 313 minecraft:light[level=12]
setblock 484 302 275 minecraft:redstone_block
fill 484 303 275 484 308 275 minecraft:deepslate_tiles
fill 496 303 317 497 308 317 minecraft:deepslate_tiles
setblock 498 303 317 minecraft:white_wool
fill 498 304 317 498 308 317 minecraft:deepslate_tiles
setblock 483 305 275 minecraft:redstone_block
setblock 485 305 275 minecraft:redstone_block
setblock 512 305 293 minecraft:white_wool
setblock 470 306 305 minecraft:redstone_block
fill 483 306 275 483 308 275 minecraft:deepslate_tiles
fill 485 306 275 485 308 275 minecraft:deepslate_tiles
fill 512 306 293 512 308 293 minecraft:deepslate_tiles
fill 470 307 305 470 308 305 minecraft:deepslate_tiles
fill 470 307 308 470 308 308 minecraft:deepslate_tiles
setblock 470 307 309 minecraft:white_wool
fill 470 307 310 470 308 310 minecraft:deepslate_tiles
setblock 470 308 309 minecraft:deepslate_tiles
