setblock 223 114 216 minecraft:light[level=12]
fill 189 117 182 191 170 182 minecraft:polished_deepslate
fill 189 117 192 189 170 194 minecraft:polished_deepslate
fill 189 117 204 189 170 206 minecraft:polished_deepslate
fill 189 117 216 189 156 218 minecraft:polished_deepslate
fill 195 117 222 197 170 222 minecraft:polished_deepslate
fill 201 117 182 203 170 182 minecraft:polished_deepslate
fill 207 117 222 209 170 222 minecraft:polished_deepslate
fill 213 117 182 215 170 182 minecraft:polished_deepslate
fill 219 117 222 221 170 222 minecraft:polished_deepslate
fill 225 117 182 227 170 182 minecraft:polished_deepslate
fill 229 117 190 229 170 192 minecraft:polished_deepslate
fill 229 117 202 229 170 204 minecraft:polished_deepslate
fill 229 117 214 229 170 216 minecraft:polished_deepslate
fill 190 120 191 190 125 193 minecraft:polished_deepslate
fill 190 120 203 190 125 205 minecraft:polished_deepslate
fill 190 120 215 190 125 217 minecraft:polished_deepslate
fill 196 120 221 198 125 221 minecraft:polished_deepslate
fill 200 120 183 202 125 183 minecraft:polished_deepslate
fill 208 120 221 210 125 221 minecraft:polished_deepslate
fill 212 120 183 214 125 183 minecraft:polished_deepslate
fill 220 120 221 222 125 221 minecraft:polished_deepslate
fill 224 120 183 226 125 183 minecraft:polished_deepslate
fill 228 120 191 228 125 193 minecraft:polished_deepslate
fill 228 120 203 228 125 205 minecraft:polished_deepslate
fill 228 120 215 228 125 217 minecraft:polished_deepslate
setblock 191 122 184 minecraft:light[level=12]
setblock 191 122 192 minecraft:light[level=12]
setblock 191 122 200 minecraft:light[level=12]
setblock 191 122 208 minecraft:light[level=12]
setblock 191 122 216 minecraft:light[level=12]
setblock 199 122 184 minecraft:light[level=12]
setblock 199 122 192 minecraft:light[level=12]
setblock 199 122 200 minecraft:light[level=12]
setblock 199 122 208 minecraft:light[level=12]
setblock 199 122 216 minecraft:light[level=12]
setblock 207 122 184 minecraft:light[level=12]
setblock 207 122 192 minecraft:light[level=12]
setblock 207 122 200 minecraft:light[level=12]
setblock 207 122 208 minecraft:light[level=12]
setblock 207 122 216 minecraft:light[level=12]
setblock 215 122 184 minecraft:light[level=12]
setblock 215 122 192 minecraft:light[level=12]
setblock 215 122 200 minecraft:light[level=12]
setblock 215 122 208 minecraft:light[level=12]
setblock 215 122 216 minecraft:light[level=12]
setblock 223 122 184 minecraft:light[level=12]
setblock 223 122 192 minecraft:light[level=12]
setblock 223 122 200 minecraft:light[level=12]
setblock 223 122 208 minecraft:light[level=12]
setblock 223 122 216 minecraft:light[level=12]
fill 189 125 185 189 125 190 minecraft:obsidian
fill 189 125 197 189 125 202 minecraft:obsidian
fill 189 125 209 189 125 214 minecraft:obsidian
fill 189 125 221 189 125 222 minecraft:obsidian
fill 190 125 222 193 125 222 minecraft:obsidian
fill 193 125 182 198 125 182 minecraft:obsidian
fill 200 125 222 205 125 222 minecraft:obsidian
fill 205 125 182 210 125 182 minecraft:obsidian
fill 212 125 222 217 125 222 minecraft:obsidian
fill 217 125 182 222 125 182 minecraft:obsidian
fill 224 125 222 229 125 222 minecraft:obsidian
fill 229 125 182 229 125 187 minecraft:obsidian
fill 229 125 194 229 125 199 minecraft:obsidian
fill 229 125 206 229 125 211 minecraft:obsidian
fill 229 125 218 229 125 221 minecraft:obsidian
fill 188 126 187 188 131 190 minecraft:crying_obsidian
fill 188 126 199 188 131 202 minecraft:crying_obsidian
fill 188 126 211 188 131 214 minecraft:crying_obsidian
fill 188 126 223 191 131 223 minecraft:crying_obsidian
fill 195 126 181 198 131 181 minecraft:crying_obsidian
fill 200 126 223 203 131 223 minecraft:crying_obsidian
fill 207 126 181 210 131 181 minecraft:crying_obsidian
fill 212 126 223 215 131 223 minecraft:crying_obsidian
fill 219 126 181 222 131 181 minecraft:crying_obsidian
fill 224 126 223 227 131 223 minecraft:crying_obsidian
fill 230 126 182 230 131 185 minecraft:crying_obsidian
fill 230 126 194 230 131 197 minecraft:crying_obsidian
fill 230 126 206 230 131 209 minecraft:crying_obsidian
fill 230 126 218 230 131 221 minecraft:crying_obsidian
setblock 191 130 184 minecraft:light[level=12]
setblock 191 130 192 minecraft:light[level=12]
setblock 191 130 200 minecraft:light[level=12]
setblock 191 130 208 minecraft:light[level=12]
setblock 191 130 216 minecraft:light[level=12]
setblock 199 130 184 minecraft:light[level=12]
setblock 199 130 192 minecraft:light[level=12]
setblock 199 130 200 minecraft:light[level=12]
setblock 199 130 208 minecraft:light[level=12]
setblock 199 130 216 minecraft:light[level=12]
setblock 207 130 184 minecraft:light[level=12]
setblock 207 130 192 minecraft:light[level=12]
setblock 207 130 200 minecraft:light[level=12]
setblock 207 130 208 minecraft:light[level=12]
setblock 207 130 216 minecraft:light[level=12]
setblock 215 130 184 minecraft:light[level=12]
setblock 215 130 192 minecraft:light[level=12]
setblock 215 130 200 minecraft:light[level=12]
setblock 215 130 208 minecraft:light[level=12]
setblock 215 130 216 minecraft:light[level=12]
setblock 223 130 184 minecraft:light[level=12]
setblock 223 130 192 minecraft:light[level=12]
setblock 223 130 200 minecraft:light[level=12]
setblock 223 130 208 minecraft:light[level=12]
setblock 223 130 216 minecraft:light[level=12]
fill 188 132 187 188 145 187 minecraft:cracked_deepslate_bricks
fill 188 132 188 188 132 189 minecraft:crying_obsidian
fill 188 132 190 188 145 190 minecraft:cracked_deepslate_bricks
fill 188 132 199 188 145 199 minecraft:cracked_deepslate_bricks
fill 188 132 200 188 132 201 minecraft:crying_obsidian
fill 188 132 202 188 145 202 minecraft:cracked_deepslate_bricks
fill 188 132 211 188 145 211 minecraft:cracked_deepslate_bricks
fill 188 132 212 188 132 213 minecraft:crying_obsidian
fill 188 132 214 188 145 214 minecraft:cracked_deepslate_bricks
fill 188 132 223 188 145 223 minecraft:cracked_deepslate_bricks
fill 189 132 223 190 132 223 minecraft:crying_obsidian
fill 191 132 223 191 145 223 minecraft:cracked_deepslate_bricks
fill 195 132 181 195 145 181 minecraft:cracked_deepslate_bricks
fill 196 132 181 197 132 181 minecraft:crying_obsidian
fill 198 132 181 198 145 181 minecraft:cracked_deepslate_bricks
fill 200 132 223 200 145 223 minecraft:cracked_deepslate_bricks
fill 201 132 223 202 132 223 minecraft:crying_obsidian
fill 203 132 223 203 145 223 minecraft:cracked_deepslate_bricks
fill 207 132 181 207 145 181 minecraft:cracked_deepslate_bricks
fill 208 132 181 209 132 181 minecraft:crying_obsidian
fill 210 132 181 210 145 181 minecraft:cracked_deepslate_bricks
fill 212 132 223 212 145 223 minecraft:cracked_deepslate_bricks
fill 213 132 223 214 132 223 minecraft:crying_obsidian
fill 215 132 223 215 145 223 minecraft:cracked_deepslate_bricks
fill 219 132 181 219 145 181 minecraft:cracked_deepslate_bricks
fill 220 132 181 221 132 181 minecraft:crying_obsidian
fill 222 132 181 222 145 181 minecraft:cracked_deepslate_bricks
fill 224 132 223 224 145 223 minecraft:cracked_deepslate_bricks
fill 225 132 223 226 132 223 minecraft:crying_obsidian
fill 227 132 223 227 145 223 minecraft:cracked_deepslate_bricks
fill 230 132 182 230 145 182 minecraft:cracked_deepslate_bricks
fill 230 132 183 230 132 184 minecraft:crying_obsidian
fill 230 132 185 230 145 185 minecraft:cracked_deepslate_bricks
fill 230 132 194 230 145 194 minecraft:cracked_deepslate_bricks
fill 230 132 195 230 132 196 minecraft:crying_obsidian
fill 230 132 197 230 145 197 minecraft:cracked_deepslate_bricks
fill 230 132 206 230 145 206 minecraft:cracked_deepslate_bricks
fill 230 132 207 230 132 208 minecraft:crying_obsidian
fill 230 132 209 230 145 209 minecraft:cracked_deepslate_bricks
fill 230 132 218 230 145 218 minecraft:cracked_deepslate_bricks
fill 230 132 219 230 132 220 minecraft:crying_obsidian
fill 230 132 221 230 145 221 minecraft:cracked_deepslate_bricks
fill 188 133 188 188 145 189 minecraft:cracked_deepslate_bricks
fill 188 133 200 188 145 201 minecraft:cracked_deepslate_bricks
fill 188 133 212 188 145 213 minecraft:cracked_deepslate_bricks
fill 189 133 223 190 145 223 minecraft:cracked_deepslate_bricks
fill 196 133 181 197 145 181 minecraft:cracked_deepslate_bricks
fill 201 133 223 202 145 223 minecraft:cracked_deepslate_bricks
fill 208 133 181 209 145 181 minecraft:cracked_deepslate_bricks
fill 213 133 223 214 145 223 minecraft:cracked_deepslate_bricks
fill 220 133 181 221 145 181 minecraft:cracked_deepslate_bricks
fill 225 133 223 226 145 223 minecraft:cracked_deepslate_bricks
fill 230 133 183 230 145 184 minecraft:cracked_deepslate_bricks
fill 230 133 195 230 145 196 minecraft:cracked_deepslate_bricks
fill 230 133 207 230 145 208 minecraft:cracked_deepslate_bricks
fill 230 133 219 230 145 220 minecraft:cracked_deepslate_bricks
setblock 191 138 184 minecraft:light[level=12]
setblock 191 138 192 minecraft:light[level=12]
setblock 191 138 200 minecraft:light[level=12]
setblock 191 138 208 minecraft:light[level=12]
setblock 191 138 216 minecraft:light[level=12]
setblock 199 138 184 minecraft:light[level=12]
setblock 199 138 192 minecraft:light[level=12]
setblock 199 138 200 minecraft:light[level=12]
setblock 199 138 208 minecraft:light[level=12]
setblock 199 138 216 minecraft:light[level=12]
setblock 207 138 184 minecraft:light[level=12]
setblock 207 138 192 minecraft:light[level=12]
setblock 207 138 200 minecraft:light[level=12]
setblock 207 138 208 minecraft:light[level=12]
setblock 207 138 216 minecraft:light[level=12]
setblock 215 138 184 minecraft:light[level=12]
setblock 215 138 192 minecraft:light[level=12]
setblock 215 138 200 minecraft:light[level=12]
setblock 215 138 208 minecraft:light[level=12]
setblock 215 138 216 minecraft:light[level=12]
setblock 223 138 184 minecraft:light[level=12]
setblock 223 138 192 minecraft:light[level=12]
setblock 223 138 200 minecraft:light[level=12]
setblock 223 138 208 minecraft:light[level=12]
setblock 223 138 216 minecraft:light[level=12]
fill 190 140 191 190 145 193 minecraft:polished_deepslate
fill 190 140 203 190 145 205 minecraft:polished_deepslate
fill 190 140 215 190 145 217 minecraft:polished_deepslate
fill 196 140 221 198 145 221 minecraft:polished_deepslate
fill 200 140 183 202 145 183 minecraft:polished_deepslate
fill 208 140 221 210 145 221 minecraft:polished_deepslate
fill 212 140 183 214 145 183 minecraft:polished_deepslate
fill 220 140 221 222 145 221 minecraft:polished_deepslate
fill 224 140 183 226 145 183 minecraft:polished_deepslate
fill 228 140 191 228 145 193 minecraft:polished_deepslate
fill 228 140 203 228 145 205 minecraft:polished_deepslate
fill 228 140 215 228 145 217 minecraft:polished_deepslate
fill 228 144 213 228 149 213 minecraft:amethyst_block
fill 189 145 185 189 145 190 minecraft:obsidian
fill 189 145 197 189 145 202 minecraft:obsidian
fill 189 145 209 189 145 214 minecraft:obsidian
fill 189 145 221 189 145 222 minecraft:obsidian
fill 190 145 222 193 145 222 minecraft:obsidian
fill 193 145 182 198 145 182 minecraft:obsidian
fill 200 145 222 205 145 222 minecraft:obsidian
fill 205 145 182 210 145 182 minecraft:obsidian
fill 212 145 222 217 145 222 minecraft:obsidian
fill 217 145 182 222 145 182 minecraft:obsidian
fill 224 145 222 229 145 222 minecraft:obsidian
fill 226 145 213 227 149 213 minecraft:amethyst_block
fill 227 145 212 229 148 212 minecraft:amethyst_block
fill 227 145 214 228 148 214 minecraft:amethyst_block
fill 228 145 211 228 148 211 minecraft:amethyst_block
fill 229 145 182 229 145 187 minecraft:obsidian
fill 229 145 194 229 145 199 minecraft:obsidian
fill 229 145 206 229 145 211 minecraft:obsidian
fill 229 145 213 229 148 213 minecraft:amethyst_block
fill 229 145 218 229 145 221 minecraft:obsidian
fill 188 146 187 188 151 190 minecraft:crying_obsidian
fill 188 146 199 188 151 202 minecraft:crying_obsidian
fill 188 146 211 188 151 214 minecraft:crying_obsidian
fill 188 146 223 191 151 223 minecraft:crying_obsidian
setblock 191 146 184 minecraft:light[level=12]
setblock 191 146 192 minecraft:light[level=12]
setblock 191 146 200 minecraft:light[level=12]
setblock 191 146 208 minecraft:light[level=12]
setblock 191 146 216 minecraft:light[level=12]
fill 195 146 181 198 151 181 minecraft:crying_obsidian
setblock 199 146 184 minecraft:light[level=12]
setblock 199 146 192 minecraft:light[level=12]
setblock 199 146 200 minecraft:light[level=12]
setblock 199 146 208 minecraft:light[level=12]
setblock 199 146 216 minecraft:light[level=12]
fill 200 146 223 203 151 223 minecraft:crying_obsidian
fill 207 146 181 210 151 181 minecraft:crying_obsidian
setblock 207 146 184 minecraft:light[level=12]
setblock 207 146 192 minecraft:light[level=12]
setblock 207 146 200 minecraft:light[level=12]
setblock 207 146 208 minecraft:light[level=12]
setblock 207 146 216 minecraft:light[level=12]
fill 212 146 223 215 151 223 minecraft:crying_obsidian
setblock 215 146 184 minecraft:light[level=12]
setblock 215 146 192 minecraft:light[level=12]
setblock 215 146 200 minecraft:light[level=12]
setblock 215 146 208 minecraft:light[level=12]
setblock 215 146 216 minecraft:light[level=12]
fill 219 146 181 222 151 181 minecraft:crying_obsidian
setblock 223 146 184 minecraft:light[level=12]
setblock 223 146 192 minecraft:light[level=12]
setblock 223 146 200 minecraft:light[level=12]
setblock 223 146 208 minecraft:light[level=12]
setblock 223 146 216 minecraft:light[level=12]
fill 224 146 223 227 151 223 minecraft:crying_obsidian
fill 225 146 212 225 149 214 minecraft:amethyst_block
fill 226 146 212 226 148 212 minecraft:amethyst_block
fill 226 146 214 226 148 214 minecraft:amethyst_block
fill 227 146 211 227 147 211 minecraft:amethyst_block
fill 227 146 215 228 147 215 minecraft:amethyst_block
fill 229 146 211 229 147 211 minecraft:amethyst_block
fill 230 146 182 230 151 185 minecraft:crying_obsidian
fill 230 146 194 230 151 197 minecraft:crying_obsidian
fill 230 146 206 230 151 209 minecraft:crying_obsidian
fill 230 146 218 230 151 221 minecraft:crying_obsidian
fill 223 147 213 224 149 213 minecraft:amethyst_block
fill 224 147 212 224 149 212 minecraft:amethyst_block
fill 224 147 214 224 149 214 minecraft:amethyst_block
setblock 226 147 211 minecraft:amethyst_block
setblock 226 147 215 minecraft:amethyst_block
fill 222 148 213 222 149 213 minecraft:amethyst_block
fill 223 148 212 223 149 212 minecraft:amethyst_block
fill 223 148 214 223 149 214 minecraft:amethyst_block
setblock 228 148 215 minecraft:amethyst_block
fill 221 149 213 221 150 213 minecraft:amethyst_block
setblock 222 149 212 minecraft:amethyst_block
setblock 222 149 214 minecraft:amethyst_block
fill 190 150 213 190 155 213 minecraft:purple_concrete
fill 188 152 187 188 165 187 minecraft:cracked_deepslate_bricks
fill 188 152 188 188 152 189 minecraft:crying_obsidian
fill 188 152 190 188 165 190 minecraft:cracked_deepslate_bricks
fill 188 152 199 188 165 199 minecraft:cracked_deepslate_bricks
fill 188 152 200 188 152 201 minecraft:crying_obsidian
fill 188 152 202 188 165 202 minecraft:cracked_deepslate_bricks
fill 188 152 211 188 165 211 minecraft:cracked_deepslate_bricks
fill 188 152 212 188 152 213 minecraft:crying_obsidian
fill 188 152 214 188 165 214 minecraft:cracked_deepslate_bricks
fill 188 152 223 188 165 223 minecraft:cracked_deepslate_bricks
fill 189 152 223 190 152 223 minecraft:crying_obsidian
fill 191 152 213 191 155 213 minecraft:purple_concrete
fill 191 152 223 191 165 223 minecraft:cracked_deepslate_bricks
fill 195 152 181 195 165 181 minecraft:cracked_deepslate_bricks
fill 196 152 181 197 152 181 minecraft:crying_obsidian
fill 198 152 181 198 165 181 minecraft:cracked_deepslate_bricks
fill 200 152 223 200 165 223 minecraft:cracked_deepslate_bricks
fill 201 152 223 202 152 223 minecraft:crying_obsidian
fill 203 152 223 203 165 223 minecraft:cracked_deepslate_bricks
fill 207 152 181 207 165 181 minecraft:cracked_deepslate_bricks
fill 208 152 181 209 152 181 minecraft:crying_obsidian
fill 210 152 181 210 165 181 minecraft:cracked_deepslate_bricks
fill 212 152 223 212 165 223 minecraft:cracked_deepslate_bricks
fill 213 152 223 214 152 223 minecraft:crying_obsidian
fill 215 152 223 215 165 223 minecraft:cracked_deepslate_bricks
fill 219 152 181 219 165 181 minecraft:cracked_deepslate_bricks
fill 220 152 181 221 152 181 minecraft:crying_obsidian
fill 222 152 181 222 165 181 minecraft:cracked_deepslate_bricks
fill 224 152 223 224 165 223 minecraft:cracked_deepslate_bricks
fill 225 152 223 226 152 223 minecraft:crying_obsidian
fill 227 152 223 227 165 223 minecraft:cracked_deepslate_bricks
fill 230 152 182 230 165 182 minecraft:cracked_deepslate_bricks
fill 230 152 183 230 152 184 minecraft:crying_obsidian
fill 230 152 185 230 165 185 minecraft:cracked_deepslate_bricks
fill 230 152 194 230 165 194 minecraft:cracked_deepslate_bricks
fill 230 152 195 230 152 196 minecraft:crying_obsidian
fill 230 152 197 230 165 197 minecraft:cracked_deepslate_bricks
fill 230 152 206 230 165 206 minecraft:cracked_deepslate_bricks
fill 230 152 207 230 152 208 minecraft:crying_obsidian
fill 230 152 209 230 165 209 minecraft:cracked_deepslate_bricks
fill 230 152 218 230 165 218 minecraft:cracked_deepslate_bricks
fill 230 152 219 230 152 220 minecraft:crying_obsidian
fill 230 152 221 230 165 221 minecraft:cracked_deepslate_bricks
fill 188 153 188 188 165 189 minecraft:cracked_deepslate_bricks
fill 188 153 200 188 165 201 minecraft:cracked_deepslate_bricks
fill 188 153 212 188 165 213 minecraft:cracked_deepslate_bricks
fill 189 153 223 190 165 223 minecraft:cracked_deepslate_bricks
fill 196 153 181 197 165 181 minecraft:cracked_deepslate_bricks
fill 201 153 223 202 165 223 minecraft:cracked_deepslate_bricks
fill 208 153 181 209 165 181 minecraft:cracked_deepslate_bricks
fill 213 153 223 214 165 223 minecraft:cracked_deepslate_bricks
fill 220 153 181 221 165 181 minecraft:cracked_deepslate_bricks
fill 225 153 223 226 165 223 minecraft:cracked_deepslate_bricks
fill 230 153 183 230 165 184 minecraft:cracked_deepslate_bricks
fill 230 153 195 230 165 196 minecraft:cracked_deepslate_bricks
fill 230 153 207 230 165 208 minecraft:cracked_deepslate_bricks
fill 230 153 219 230 165 220 minecraft:cracked_deepslate_bricks
fill 189 154 213 189 155 213 minecraft:purple_concrete
fill 190 154 212 191 155 212 minecraft:purple_concrete
fill 190 154 214 191 155 214 minecraft:purple_concrete
setblock 191 154 184 minecraft:light[level=12]
setblock 191 154 192 minecraft:light[level=12]
setblock 191 154 200 minecraft:light[level=12]
setblock 191 154 208 minecraft:light[level=12]
setblock 191 154 216 minecraft:light[level=12]
setblock 199 154 184 minecraft:light[level=12]
setblock 199 154 192 minecraft:light[level=12]
setblock 199 154 200 minecraft:light[level=12]
setblock 199 154 208 minecraft:light[level=12]
setblock 199 154 216 minecraft:light[level=12]
setblock 207 154 184 minecraft:light[level=12]
setblock 207 154 192 minecraft:light[level=12]
setblock 207 154 200 minecraft:light[level=12]
setblock 207 154 208 minecraft:light[level=12]
setblock 207 154 216 minecraft:light[level=12]
setblock 215 154 184 minecraft:light[level=12]
setblock 215 154 192 minecraft:light[level=12]
setblock 215 154 200 minecraft:light[level=12]
setblock 215 154 208 minecraft:light[level=12]
setblock 215 154 216 minecraft:light[level=12]
setblock 223 154 184 minecraft:light[level=12]
setblock 223 154 192 minecraft:light[level=12]
setblock 223 154 200 minecraft:light[level=12]
setblock 223 154 208 minecraft:light[level=12]
setblock 223 154 216 minecraft:light[level=12]
fill 189 156 210 192 156 215 minecraft:polished_deepslate
fill 190 156 216 192 156 216 minecraft:polished_deepslate
setblock 189 157 210 minecraft:crying_obsidian
fill 189 157 211 189 164 211 minecraft:polished_deepslate
setblock 189 157 212 minecraft:crying_obsidian
fill 189 157 213 189 164 213 minecraft:polished_deepslate
setblock 189 157 214 minecraft:crying_obsidian
fill 189 157 215 189 170 215 minecraft:polished_deepslate
setblock 189 157 216 minecraft:crying_obsidian
fill 189 157 217 189 170 218 minecraft:polished_deepslate
fill 190 157 210 190 170 210 minecraft:polished_deepslate
setblock 190 157 211 minecraft:crying_obsidian
fill 190 157 212 190 170 212 minecraft:polished_deepslate
setblock 190 157 213 minecraft:crying_obsidian
fill 190 157 214 190 170 214 minecraft:polished_deepslate
setblock 190 157 215 minecraft:crying_obsidian
fill 190 157 216 190 170 216 minecraft:polished_deepslate
setblock 191 157 210 minecraft:crying_obsidian
fill 191 157 211 191 170 211 minecraft:polished_deepslate
setblock 191 157 212 minecraft:crying_obsidian
fill 191 157 213 191 170 213 minecraft:polished_deepslate
setblock 191 157 214 minecraft:crying_obsidian
fill 191 157 215 191 170 215 minecraft:polished_deepslate
setblock 191 157 216 minecraft:crying_obsidian
fill 192 157 210 192 170 210 minecraft:polished_deepslate
setblock 192 157 211 minecraft:crying_obsidian
fill 192 157 212 192 170 212 minecraft:polished_deepslate
setblock 192 157 213 minecraft:crying_obsidian
fill 192 157 214 192 170 214 minecraft:polished_deepslate
setblock 192 157 215 minecraft:crying_obsidian
fill 192 157 216 192 170 216 minecraft:polished_deepslate
fill 189 158 210 189 159 210 minecraft:polished_deepslate
fill 189 158 212 189 159 212 minecraft:polished_deepslate
fill 189 158 214 189 159 214 minecraft:polished_deepslate
fill 189 158 216 189 159 216 minecraft:polished_deepslate
fill 190 158 211 190 159 211 minecraft:polished_deepslate
fill 190 158 213 190 159 213 minecraft:polished_deepslate
fill 190 158 215 190 159 215 minecraft:polished_deepslate
fill 191 158 210 191 159 210 minecraft:polished_deepslate
fill 191 158 212 191 159 212 minecraft:polished_deepslate
fill 191 158 214 191 159 214 minecraft:polished_deepslate
fill 191 158 216 191 159 216 minecraft:polished_deepslate
fill 192 158 211 192 159 211 minecraft:polished_deepslate
fill 192 158 213 192 159 213 minecraft:polished_deepslate
fill 192 158 215 192 159 215 minecraft:polished_deepslate
setblock 189 160 210 minecraft:crying_obsidian
setblock 189 160 212 minecraft:crying_obsidian
setblock 189 160 214 minecraft:crying_obsidian
setblock 189 160 216 minecraft:crying_obsidian
fill 190 160 191 190 165 193 minecraft:polished_deepslate
fill 190 160 203 190 165 205 minecraft:polished_deepslate
setblock 190 160 211 minecraft:crying_obsidian
setblock 190 160 213 minecraft:crying_obsidian
setblock 190 160 215 minecraft:crying_obsidian
fill 190 160 217 190 165 217 minecraft:polished_deepslate
setblock 191 160 210 minecraft:crying_obsidian
setblock 191 160 212 minecraft:crying_obsidian
setblock 191 160 214 minecraft:crying_obsidian
setblock 191 160 216 minecraft:crying_obsidian
setblock 192 160 211 minecraft:crying_obsidian
setblock 192 160 213 minecraft:crying_obsidian
setblock 192 160 215 minecraft:crying_obsidian
fill 196 160 221 198 165 221 minecraft:polished_deepslate
fill 200 160 183 202 165 183 minecraft:polished_deepslate
fill 208 160 221 210 165 221 minecraft:polished_deepslate
fill 212 160 183 214 165 183 minecraft:polished_deepslate
fill 220 160 221 222 165 221 minecraft:polished_deepslate
fill 224 160 183 226 165 183 minecraft:polished_deepslate
fill 228 160 191 228 165 193 minecraft:polished_deepslate
fill 228 160 203 228 165 205 minecraft:polished_deepslate
fill 228 160 215 228 165 217 minecraft:polished_deepslate
fill 189 161 210 189 162 210 minecraft:polished_deepslate
fill 189 161 212 189 162 212 minecraft:polished_deepslate
fill 189 161 214 189 162 214 minecraft:polished_deepslate
fill 189 161 216 189 162 216 minecraft:polished_deepslate
fill 190 161 211 190 162 211 minecraft:polished_deepslate
fill 190 161 213 190 162 213 minecraft:polished_deepslate
fill 190 161 215 190 162 215 minecraft:polished_deepslate
fill 191 161 210 191 162 210 minecraft:polished_deepslate
fill 191 161 212 191 162 212 minecraft:polished_deepslate
fill 191 161 214 191 162 214 minecraft:polished_deepslate
fill 191 161 216 191 162 216 minecraft:polished_deepslate
fill 192 161 211 192 162 211 minecraft:polished_deepslate
fill 192 161 213 192 162 213 minecraft:polished_deepslate
fill 192 161 215 192 162 215 minecraft:polished_deepslate
setblock 191 162 184 minecraft:light[level=12]
setblock 191 162 192 minecraft:light[level=12]
setblock 191 162 200 minecraft:light[level=12]
setblock 191 162 208 minecraft:light[level=12]
setblock 199 162 184 minecraft:light[level=12]
setblock 199 162 192 minecraft:light[level=12]
setblock 199 162 200 minecraft:light[level=12]
setblock 199 162 208 minecraft:light[level=12]
setblock 199 162 216 minecraft:light[level=12]
setblock 207 162 184 minecraft:light[level=12]
setblock 207 162 192 minecraft:light[level=12]
setblock 207 162 200 minecraft:light[level=12]
setblock 207 162 208 minecraft:light[level=12]
setblock 207 162 216 minecraft:light[level=12]
setblock 215 162 184 minecraft:light[level=12]
setblock 215 162 192 minecraft:light[level=12]
setblock 215 162 200 minecraft:light[level=12]
setblock 215 162 208 minecraft:light[level=12]
setblock 215 162 216 minecraft:light[level=12]
setblock 223 162 184 minecraft:light[level=12]
setblock 223 162 192 minecraft:light[level=12]
setblock 223 162 200 minecraft:light[level=12]
setblock 223 162 208 minecraft:light[level=12]
setblock 223 162 216 minecraft:light[level=12]
setblock 189 163 210 minecraft:crying_obsidian
setblock 189 163 212 minecraft:crying_obsidian
setblock 189 163 214 minecraft:crying_obsidian
setblock 189 163 216 minecraft:crying_obsidian
setblock 190 163 211 minecraft:crying_obsidian
setblock 190 163 213 minecraft:crying_obsidian
setblock 190 163 215 minecraft:crying_obsidian
setblock 191 163 210 minecraft:crying_obsidian
setblock 191 163 212 minecraft:crying_obsidian
setblock 191 163 214 minecraft:crying_obsidian
setblock 191 163 216 minecraft:crying_obsidian
setblock 192 163 211 minecraft:crying_obsidian
setblock 192 163 213 minecraft:crying_obsidian
setblock 192 163 215 minecraft:crying_obsidian
setblock 189 164 210 minecraft:polished_deepslate
setblock 189 164 212 minecraft:polished_deepslate
setblock 189 164 214 minecraft:polished_deepslate
fill 189 164 216 189 165 216 minecraft:polished_deepslate
fill 190 164 211 190 165 211 minecraft:polished_deepslate
fill 190 164 213 190 165 213 minecraft:polished_deepslate
fill 190 164 215 190 165 215 minecraft:polished_deepslate
fill 191 164 210 191 165 210 minecraft:polished_deepslate
fill 191 164 212 191 165 212 minecraft:polished_deepslate
fill 191 164 214 191 165 214 minecraft:polished_deepslate
fill 191 164 216 191 165 216 minecraft:polished_deepslate
fill 192 164 211 192 165 211 minecraft:polished_deepslate
fill 192 164 213 192 165 213 minecraft:polished_deepslate
fill 192 164 215 192 165 215 minecraft:polished_deepslate
fill 189 165 185 189 165 190 minecraft:obsidian
fill 189 165 197 189 165 202 minecraft:obsidian
fill 189 165 209 189 165 214 minecraft:obsidian
fill 189 165 221 189 165 222 minecraft:obsidian
fill 190 165 222 193 165 222 minecraft:obsidian
fill 193 165 182 198 165 182 minecraft:obsidian
fill 200 165 222 205 165 222 minecraft:obsidian
fill 205 165 182 210 165 182 minecraft:obsidian
fill 212 165 222 217 165 222 minecraft:obsidian
fill 217 165 182 222 165 182 minecraft:obsidian
fill 224 165 222 229 165 222 minecraft:obsidian
fill 229 165 182 229 165 187 minecraft:obsidian
fill 229 165 194 229 165 199 minecraft:obsidian
fill 229 165 206 229 165 211 minecraft:obsidian
fill 229 165 218 229 165 221 minecraft:obsidian
fill 188 166 187 188 170 190 minecraft:crying_obsidian
fill 188 166 199 188 170 202 minecraft:crying_obsidian
fill 188 166 211 188 170 214 minecraft:crying_obsidian
fill 188 166 223 191 170 223 minecraft:crying_obsidian
setblock 189 166 210 minecraft:crying_obsidian
fill 189 166 211 189 170 211 minecraft:polished_deepslate
setblock 189 166 212 minecraft:crying_obsidian
fill 189 166 213 189 170 213 minecraft:polished_deepslate
setblock 189 166 214 minecraft:crying_obsidian
setblock 189 166 216 minecraft:crying_obsidian
setblock 190 166 211 minecraft:crying_obsidian
setblock 190 166 213 minecraft:crying_obsidian
setblock 190 166 215 minecraft:crying_obsidian
setblock 191 166 210 minecraft:crying_obsidian
setblock 191 166 212 minecraft:crying_obsidian
setblock 191 166 214 minecraft:crying_obsidian
setblock 191 166 216 minecraft:crying_obsidian
setblock 192 166 211 minecraft:crying_obsidian
setblock 192 166 213 minecraft:crying_obsidian
setblock 192 166 215 minecraft:crying_obsidian
fill 195 166 181 198 170 181 minecraft:crying_obsidian
fill 200 166 223 203 170 223 minecraft:crying_obsidian
fill 207 166 181 210 170 181 minecraft:crying_obsidian
fill 212 166 223 215 170 223 minecraft:crying_obsidian
fill 219 166 181 222 170 181 minecraft:crying_obsidian
fill 224 166 223 227 170 223 minecraft:crying_obsidian
fill 230 166 182 230 170 185 minecraft:crying_obsidian
fill 230 166 194 230 170 197 minecraft:crying_obsidian
fill 230 166 206 230 170 209 minecraft:crying_obsidian
fill 230 166 218 230 170 221 minecraft:crying_obsidian
fill 189 167 210 189 168 210 minecraft:polished_deepslate
fill 189 167 212 189 168 212 minecraft:polished_deepslate
fill 189 167 214 189 168 214 minecraft:polished_deepslate
fill 189 167 216 189 168 216 minecraft:polished_deepslate
fill 190 167 211 190 168 211 minecraft:polished_deepslate
fill 190 167 213 190 168 213 minecraft:polished_deepslate
fill 190 167 215 190 168 215 minecraft:polished_deepslate
fill 191 167 210 191 168 210 minecraft:polished_deepslate
fill 191 167 212 191 168 212 minecraft:polished_deepslate
fill 191 167 214 191 168 214 minecraft:polished_deepslate
fill 191 167 216 191 168 216 minecraft:polished_deepslate
fill 192 167 211 192 168 211 minecraft:polished_deepslate
fill 192 167 213 192 168 213 minecraft:polished_deepslate
fill 192 167 215 192 168 215 minecraft:polished_deepslate
setblock 189 169 210 minecraft:crying_obsidian
setblock 189 169 212 minecraft:crying_obsidian
setblock 189 169 214 minecraft:crying_obsidian
setblock 189 169 216 minecraft:crying_obsidian
setblock 190 169 211 minecraft:crying_obsidian
setblock 190 169 213 minecraft:crying_obsidian
setblock 190 169 215 minecraft:crying_obsidian
setblock 191 169 210 minecraft:crying_obsidian
setblock 191 169 212 minecraft:crying_obsidian
setblock 191 169 214 minecraft:crying_obsidian
setblock 191 169 216 minecraft:crying_obsidian
setblock 192 169 211 minecraft:crying_obsidian
setblock 192 169 213 minecraft:crying_obsidian
setblock 192 169 215 minecraft:crying_obsidian
setblock 189 170 210 minecraft:polished_deepslate
setblock 189 170 212 minecraft:polished_deepslate
setblock 189 170 214 minecraft:polished_deepslate
setblock 189 170 216 minecraft:polished_deepslate
setblock 190 170 211 minecraft:polished_deepslate
setblock 190 170 213 minecraft:polished_deepslate
setblock 190 170 215 minecraft:polished_deepslate
setblock 191 170 184 minecraft:light[level=12]
setblock 191 170 192 minecraft:light[level=12]
setblock 191 170 200 minecraft:light[level=12]
setblock 191 170 208 minecraft:light[level=12]
setblock 191 170 210 minecraft:polished_deepslate
setblock 191 170 212 minecraft:polished_deepslate
setblock 191 170 214 minecraft:polished_deepslate
setblock 191 170 216 minecraft:polished_deepslate
setblock 192 170 211 minecraft:polished_deepslate
setblock 192 170 213 minecraft:polished_deepslate
setblock 192 170 215 minecraft:polished_deepslate
setblock 199 170 184 minecraft:light[level=12]
setblock 199 170 192 minecraft:light[level=12]
setblock 199 170 200 minecraft:light[level=12]
setblock 199 170 208 minecraft:light[level=12]
setblock 199 170 216 minecraft:light[level=12]
setblock 207 170 184 minecraft:light[level=12]
setblock 207 170 192 minecraft:light[level=12]
setblock 207 170 200 minecraft:light[level=12]
setblock 207 170 208 minecraft:light[level=12]
setblock 207 170 216 minecraft:light[level=12]
setblock 215 170 184 minecraft:light[level=12]
setblock 215 170 192 minecraft:light[level=12]
setblock 215 170 200 minecraft:light[level=12]
setblock 215 170 208 minecraft:light[level=12]
setblock 215 170 216 minecraft:light[level=12]
setblock 223 170 184 minecraft:light[level=12]
setblock 223 170 192 minecraft:light[level=12]
setblock 223 170 200 minecraft:light[level=12]
setblock 223 170 208 minecraft:light[level=12]
setblock 223 170 216 minecraft:light[level=12]
fill 188 171 187 188 185 190 minecraft:cracked_deepslate_bricks
fill 188 171 199 188 185 202 minecraft:cracked_deepslate_bricks
fill 188 171 211 188 185 214 minecraft:cracked_deepslate_bricks
fill 188 171 223 191 185 223 minecraft:cracked_deepslate_bricks
fill 195 171 181 198 185 181 minecraft:cracked_deepslate_bricks
fill 200 171 223 203 185 223 minecraft:cracked_deepslate_bricks
fill 207 171 181 210 185 181 minecraft:cracked_deepslate_bricks
fill 208 171 202 208 171 204 minecraft:amethyst_block
fill 209 171 201 211 171 202 minecraft:amethyst_block
fill 209 171 205 211 171 205 minecraft:amethyst_block
fill 211 171 203 212 171 204 minecraft:amethyst_block
setblock 212 171 202 minecraft:amethyst_block
fill 212 171 223 215 185 223 minecraft:cracked_deepslate_bricks
fill 219 171 181 222 185 181 minecraft:cracked_deepslate_bricks
fill 224 171 223 227 185 223 minecraft:cracked_deepslate_bricks
fill 230 171 182 230 185 185 minecraft:cracked_deepslate_bricks
fill 230 171 194 230 185 197 minecraft:cracked_deepslate_bricks
fill 230 171 206 230 185 209 minecraft:cracked_deepslate_bricks
fill 230 171 218 230 185 221 minecraft:cracked_deepslate_bricks
fill 206 172 202 207 172 204 minecraft:amethyst_block
fill 207 172 200 208 172 201 minecraft:amethyst_block
fill 207 172 205 208 172 206 minecraft:amethyst_block
fill 208 172 202 208 174 204 minecraft:deepslate_bricks
fill 209 172 199 211 172 200 minecraft:amethyst_block
fill 209 172 201 211 174 202 minecraft:deepslate_bricks
fill 209 172 205 211 174 205 minecraft:deepslate_bricks
fill 209 172 206 211 172 207 minecraft:amethyst_block
fill 211 172 203 212 174 204 minecraft:deepslate_bricks
fill 212 172 200 213 172 201 minecraft:amethyst_block
fill 212 172 202 212 174 202 minecraft:deepslate_bricks
fill 212 172 205 213 172 206 minecraft:amethyst_block
fill 213 172 202 214 172 204 minecraft:amethyst_block
fill 205 173 202 205 173 204 minecraft:amethyst_block
fill 206 173 200 206 173 201 minecraft:amethyst_block
fill 206 173 202 207 178 204 minecraft:deepslate_bricks
fill 206 173 205 206 173 206 minecraft:amethyst_block
fill 207 173 199 208 173 199 minecraft:amethyst_block
fill 207 173 200 208 178 201 minecraft:deepslate_bricks
fill 207 173 205 208 178 206 minecraft:deepslate_bricks
fill 207 173 207 208 173 207 minecraft:amethyst_block
fill 209 173 198 211 173 198 minecraft:amethyst_block
fill 209 173 199 211 178 200 minecraft:deepslate_bricks
fill 209 173 206 211 174 207 minecraft:deepslate_bricks
fill 209 173 208 211 173 208 minecraft:amethyst_block
fill 212 173 199 213 173 199 minecraft:amethyst_block
fill 212 173 200 213 178 201 minecraft:deepslate_bricks
fill 212 173 205 213 174 206 minecraft:deepslate_bricks
fill 212 173 207 213 173 207 minecraft:amethyst_block
fill 213 173 202 214 174 204 minecraft:deepslate_bricks
fill 214 173 200 214 173 201 minecraft:amethyst_block
fill 214 173 205 214 173 206 minecraft:amethyst_block
fill 215 173 202 215 173 204 minecraft:amethyst_block
fill 204 174 203 204 181 203 minecraft:amethyst_block
fill 205 174 200 205 174 202 minecraft:amethyst_block
fill 205 174 203 205 181 203 minecraft:deepslate_bricks
fill 205 174 204 205 174 206 minecraft:amethyst_block
setblock 206 174 199 minecraft:amethyst_block
fill 206 174 200 206 181 201 minecraft:deepslate_bricks
fill 206 174 205 206 181 206 minecraft:deepslate_bricks
setblock 206 174 207 minecraft:amethyst_block
fill 207 174 198 209 174 198 minecraft:amethyst_block
fill 207 174 199 208 181 199 minecraft:deepslate_bricks
fill 207 174 207 208 178 207 minecraft:deepslate_bricks
fill 207 174 208 209 174 208 minecraft:amethyst_block
fill 210 174 197 210 181 197 minecraft:amethyst_block
fill 210 174 198 210 181 198 minecraft:deepslate_bricks
fill 210 174 208 210 178 208 minecraft:deepslate_bricks
fill 210 174 209 210 181 209 minecraft:amethyst_block
fill 211 174 198 213 174 198 minecraft:amethyst_block
fill 211 174 208 213 174 208 minecraft:amethyst_block
fill 212 174 199 213 181 199 minecraft:deepslate_bricks
fill 212 174 207 213 178 207 minecraft:deepslate_bricks
setblock 214 174 199 minecraft:amethyst_block
fill 214 174 200 214 178 201 minecraft:deepslate_bricks
fill 214 174 205 214 178 206 minecraft:deepslate_bricks
setblock 214 174 207 minecraft:amethyst_block
fill 215 174 200 215 174 202 minecraft:amethyst_block
fill 215 174 203 215 178 203 minecraft:deepslate_bricks
fill 215 174 204 215 174 206 minecraft:amethyst_block
fill 216 174 203 216 181 203 minecraft:amethyst_block
fill 204 175 201 204 180 202 minecraft:amethyst_block
fill 204 175 204 204 180 205 minecraft:amethyst_block
fill 205 175 199 205 175 200 minecraft:amethyst_block
fill 205 175 201 205 180 202 minecraft:deepslate_bricks
fill 205 175 204 205 180 205 minecraft:deepslate_bricks
fill 205 175 206 205 175 207 minecraft:amethyst_block
fill 206 175 198 207 175 198 minecraft:amethyst_block
fill 206 175 199 206 180 199 minecraft:deepslate_bricks
fill 206 175 207 206 180 207 minecraft:deepslate_bricks
fill 206 175 208 207 175 208 minecraft:amethyst_block
fill 208 175 197 209 180 197 minecraft:amethyst_block
fill 208 175 198 209 180 198 minecraft:deepslate_bricks
fill 208 175 202 208 178 203 minecraft:deepslate_bricks
fill 208 175 208 209 180 208 minecraft:deepslate_bricks
fill 208 175 209 209 180 209 minecraft:amethyst_block
fill 209 175 201 210 178 201 minecraft:deepslate_bricks
fill 209 175 207 210 178 207 minecraft:deepslate_bricks
fill 211 175 197 212 180 197 minecraft:amethyst_block
fill 211 175 198 212 180 198 minecraft:deepslate_bricks
fill 211 175 208 212 178 208 minecraft:deepslate_bricks
fill 211 175 209 212 180 209 minecraft:amethyst_block
fill 213 175 198 214 175 198 minecraft:amethyst_block
fill 213 175 208 214 175 208 minecraft:amethyst_block
fill 214 175 199 214 180 199 minecraft:deepslate_bricks
fill 214 175 202 214 178 203 minecraft:deepslate_bricks
fill 214 175 207 214 178 207 minecraft:deepslate_bricks
fill 215 175 199 215 175 200 minecraft:amethyst_block
fill 215 175 201 215 180 202 minecraft:deepslate_bricks
fill 215 175 204 215 178 205 minecraft:deepslate_bricks
fill 215 175 206 215 175 207 minecraft:amethyst_block
fill 216 175 201 216 180 202 minecraft:amethyst_block
fill 216 175 204 216 180 205 minecraft:amethyst_block
fill 204 176 200 204 179 200 minecraft:amethyst_block
fill 204 176 206 204 179 206 minecraft:amethyst_block
fill 205 176 199 205 180 199 minecraft:amethyst_block
fill 205 176 200 205 179 200 minecraft:deepslate_bricks
fill 205 176 206 205 179 206 minecraft:deepslate_bricks
fill 205 176 207 205 180 207 minecraft:amethyst_block
fill 206 176 198 206 180 198 minecraft:amethyst_block
fill 206 176 208 206 180 208 minecraft:amethyst_block
fill 207 176 197 207 179 197 minecraft:amethyst_block
fill 207 176 198 207 179 198 minecraft:deepslate_bricks
fill 207 176 208 207 179 208 minecraft:deepslate_bricks
fill 207 176 209 207 179 209 minecraft:amethyst_block
fill 213 176 197 213 179 197 minecraft:amethyst_block
fill 213 176 198 213 179 198 minecraft:deepslate_bricks
fill 213 176 208 213 179 208 minecraft:deepslate_bricks
fill 213 176 209 213 179 209 minecraft:amethyst_block
fill 214 176 198 214 180 198 minecraft:amethyst_block
fill 214 176 208 214 180 208 minecraft:amethyst_block
fill 215 176 199 215 180 199 minecraft:amethyst_block
fill 215 176 200 215 179 200 minecraft:deepslate_bricks
fill 215 176 206 215 179 206 minecraft:deepslate_bricks
fill 215 176 207 215 180 207 minecraft:amethyst_block
fill 216 176 200 216 179 200 minecraft:amethyst_block
fill 216 176 206 216 179 206 minecraft:amethyst_block
setblock 191 178 184 minecraft:light[level=12]
setblock 191 178 192 minecraft:light[level=12]
setblock 191 178 200 minecraft:light[level=12]
setblock 191 178 208 minecraft:light[level=12]
setblock 191 178 216 minecraft:light[level=12]
setblock 199 178 184 minecraft:light[level=12]
setblock 199 178 192 minecraft:light[level=12]
setblock 199 178 200 minecraft:light[level=12]
setblock 199 178 208 minecraft:light[level=12]
setblock 199 178 216 minecraft:light[level=12]
setblock 207 178 184 minecraft:light[level=12]
setblock 207 178 192 minecraft:light[level=12]
setblock 207 178 216 minecraft:light[level=12]
setblock 215 178 184 minecraft:light[level=12]
setblock 215 178 192 minecraft:light[level=12]
setblock 215 178 208 minecraft:light[level=12]
setblock 215 178 216 minecraft:light[level=12]
setblock 223 178 184 minecraft:light[level=12]
setblock 223 178 192 minecraft:light[level=12]
setblock 223 178 200 minecraft:light[level=12]
setblock 223 178 208 minecraft:light[level=12]
setblock 223 178 216 minecraft:light[level=12]
fill 189 179 182 203 179 222 minecraft:obsidian
fill 204 179 182 204 179 199 minecraft:obsidian
fill 204 179 207 204 179 222 minecraft:obsidian
fill 205 179 182 205 179 198 minecraft:obsidian
fill 205 179 208 205 179 222 minecraft:obsidian
fill 206 179 182 206 179 197 minecraft:obsidian
fill 206 179 202 206 182 204 minecraft:deepslate_bricks
fill 206 179 209 206 179 222 minecraft:obsidian
fill 207 179 182 229 179 196 minecraft:obsidian
fill 207 179 200 207 182 202 minecraft:deepslate_bricks
fill 207 179 203 207 179 205 minecraft:crying_obsidian
fill 207 179 206 207 181 207 minecraft:deepslate_bricks
fill 207 179 210 229 179 222 minecraft:obsidian
fill 208 179 200 209 182 200 minecraft:deepslate_bricks
fill 208 179 201 208 179 203 minecraft:crying_obsidian
fill 208 179 205 208 179 207 minecraft:crying_obsidian
fill 209 179 199 211 182 199 minecraft:deepslate_bricks
fill 209 179 201 210 179 201 minecraft:crying_obsidian
fill 209 179 207 210 179 207 minecraft:crying_obsidian
fill 210 179 200 212 179 200 minecraft:crying_obsidian
fill 210 179 208 212 179 208 minecraft:crying_obsidian
fill 212 179 201 214 179 201 minecraft:crying_obsidian
fill 212 179 207 214 179 207 minecraft:crying_obsidian
fill 213 179 200 214 181 200 minecraft:deepslate_bricks
fill 214 179 197 229 179 197 minecraft:obsidian
fill 214 179 202 214 179 203 minecraft:crying_obsidian
fill 214 179 205 214 179 206 minecraft:crying_obsidian
fill 214 179 209 229 179 209 minecraft:obsidian
fill 215 179 198 229 179 198 minecraft:obsidian
fill 215 179 203 215 179 205 minecraft:crying_obsidian
fill 215 179 208 229 179 208 minecraft:obsidian
fill 216 179 199 229 179 199 minecraft:obsidian
fill 216 179 207 229 179 207 minecraft:obsidian
fill 217 179 200 229 179 206 minecraft:obsidian
fill 205 180 200 205 181 200 minecraft:amethyst_block
fill 205 180 206 205 181 206 minecraft:amethyst_block
fill 207 180 198 207 181 198 minecraft:amethyst_block
fill 207 180 203 207 182 205 minecraft:deepslate_bricks
fill 207 180 208 207 181 208 minecraft:amethyst_block
fill 208 180 201 208 182 202 minecraft:deepslate_bricks
fill 208 180 205 208 181 207 minecraft:deepslate_bricks
fill 209 180 201 210 183 201 minecraft:deepslate_bricks
fill 209 180 207 210 182 207 minecraft:deepslate_bricks
fill 210 180 200 212 182 200 minecraft:deepslate_bricks
fill 210 180 208 212 180 208 minecraft:deepslate_bricks
fill 212 180 201 214 181 201 minecraft:deepslate_bricks
fill 212 180 207 214 180 207 minecraft:deepslate_bricks
fill 213 180 198 213 181 198 minecraft:amethyst_block
fill 213 180 208 213 181 208 minecraft:amethyst_block
fill 214 180 202 214 182 203 minecraft:deepslate_bricks
fill 214 180 205 214 181 206 minecraft:deepslate_bricks
fill 215 180 200 215 181 200 minecraft:amethyst_block
fill 215 180 203 215 180 205 minecraft:deepslate_bricks
fill 215 180 206 215 181 206 minecraft:amethyst_block
fill 205 181 201 205 181 202 minecraft:amethyst_block
fill 205 181 204 205 181 205 minecraft:amethyst_block
setblock 206 181 199 minecraft:amethyst_block
setblock 206 181 207 minecraft:amethyst_block
fill 208 181 198 209 181 198 minecraft:amethyst_block
fill 208 181 208 209 181 208 minecraft:amethyst_block
setblock 210 181 208 minecraft:deepslate_bricks
fill 211 181 198 212 181 198 minecraft:amethyst_block
fill 211 181 208 212 181 208 minecraft:amethyst_block
fill 212 181 207 213 181 207 minecraft:deepslate_bricks
setblock 214 181 199 minecraft:amethyst_block
setblock 214 181 207 minecraft:amethyst_block
fill 215 181 201 215 181 202 minecraft:amethyst_block
setblock 215 181 203 minecraft:deepslate_bricks
fill 215 181 204 215 181 205 minecraft:amethyst_block
fill 205 182 202 205 182 204 minecraft:amethyst_block
fill 206 182 200 206 182 201 minecraft:amethyst_block
fill 206 182 205 206 182 206 minecraft:amethyst_block
fill 207 182 199 208 182 199 minecraft:amethyst_block
fill 207 182 206 213 182 206 minecraft:deepslate_bricks
fill 207 182 207 208 182 207 minecraft:amethyst_block
fill 208 182 204 208 182 205 minecraft:deepslate_bricks
fill 209 182 198 211 182 198 minecraft:amethyst_block
fill 209 182 205 213 182 205 minecraft:deepslate_bricks
fill 209 182 208 211 182 208 minecraft:amethyst_block
fill 210 182 202 213 182 202 minecraft:deepslate_bricks
fill 211 182 201 213 182 201 minecraft:deepslate_bricks
fill 211 182 203 213 182 204 minecraft:deepslate_bricks
setblock 211 182 207 minecraft:deepslate_bricks
fill 212 182 199 213 182 199 minecraft:amethyst_block
fill 212 182 207 213 182 207 minecraft:amethyst_block
setblock 213 182 200 minecraft:deepslate_bricks
fill 214 182 200 214 182 201 minecraft:amethyst_block
setblock 214 182 204 minecraft:deepslate_bricks
fill 214 182 205 214 182 206 minecraft:amethyst_block
fill 215 182 202 215 182 204 minecraft:amethyst_block
fill 189 183 182 191 227 182 minecraft:polished_deepslate
fill 189 183 192 189 227 194 minecraft:polished_deepslate
fill 189 183 204 189 227 206 minecraft:polished_deepslate
fill 189 183 216 189 227 218 minecraft:polished_deepslate
fill 190 183 191 190 185 193 minecraft:polished_deepslate
fill 190 183 203 190 185 205 minecraft:polished_deepslate
fill 190 183 215 190 185 217 minecraft:polished_deepslate
fill 195 183 222 197 227 222 minecraft:polished_deepslate
fill 196 183 221 198 185 221 minecraft:polished_deepslate
fill 200 183 183 202 185 183 minecraft:polished_deepslate
fill 201 183 182 203 227 182 minecraft:polished_deepslate
fill 206 183 202 207 183 204 minecraft:amethyst_block
fill 207 183 200 208 183 201 minecraft:amethyst_block
fill 207 183 205 208 183 206 minecraft:amethyst_block
fill 207 183 222 209 227 222 minecraft:polished_deepslate
setblock 208 183 202 minecraft:deepslate_bricks
setblock 208 183 204 minecraft:deepslate_bricks
fill 208 183 221 210 185 221 minecraft:polished_deepslate
fill 209 183 199 211 183 200 minecraft:amethyst_block
fill 209 183 205 211 183 205 minecraft:deepslate_bricks
fill 209 183 206 211 183 207 minecraft:amethyst_block
fill 210 183 202 212 183 202 minecraft:deepslate_bricks
setblock 211 183 201 minecraft:deepslate_bricks
fill 211 183 203 212 183 204 minecraft:deepslate_bricks
fill 212 183 183 214 185 183 minecraft:polished_deepslate
fill 212 183 200 213 183 201 minecraft:amethyst_block
fill 212 183 205 213 183 206 minecraft:amethyst_block
fill 213 183 182 215 227 182 minecraft:polished_deepslate
fill 213 183 202 214 183 204 minecraft:amethyst_block
fill 219 183 222 221 227 222 minecraft:polished_deepslate
fill 220 183 221 222 185 221 minecraft:polished_deepslate
fill 224 183 183 226 185 183 minecraft:polished_deepslate
fill 225 183 182 227 227 182 minecraft:polished_deepslate
fill 228 183 191 228 185 193 minecraft:polished_deepslate
fill 228 183 203 228 185 205 minecraft:polished_deepslate
fill 228 183 215 228 185 217 minecraft:polished_deepslate
fill 229 183 190 229 227 192 minecraft:polished_deepslate
fill 229 183 202 229 227 204 minecraft:polished_deepslate
fill 229 183 214 229 213 216 minecraft:polished_deepslate
setblock 208 184 202 minecraft:amethyst_block
setblock 208 184 204 minecraft:amethyst_block
fill 209 184 201 211 184 201 minecraft:amethyst_block
fill 209 184 205 211 184 205 minecraft:amethyst_block
fill 210 184 202 212 184 202 minecraft:amethyst_block
fill 210 184 204 212 184 204 minecraft:amethyst_block
fill 211 184 203 212 184 203 minecraft:amethyst_block
fill 189 185 185 189 185 190 minecraft:obsidian
fill 189 185 197 189 185 202 minecraft:obsidian
fill 189 185 209 189 185 214 minecraft:obsidian
fill 189 185 221 189 185 222 minecraft:obsidian
fill 190 185 222 193 185 222 minecraft:obsidian
fill 193 185 182 198 185 182 minecraft:obsidian
fill 200 185 222 205 185 222 minecraft:obsidian
fill 205 185 182 210 185 182 minecraft:obsidian
fill 212 185 222 217 185 222 minecraft:obsidian
fill 217 185 182 222 185 182 minecraft:obsidian
fill 224 185 222 229 185 222 minecraft:obsidian
fill 229 185 182 229 185 187 minecraft:obsidian
fill 229 185 194 229 185 199 minecraft:obsidian
fill 229 185 206 229 185 211 minecraft:obsidian
fill 229 185 218 229 185 221 minecraft:obsidian
fill 188 186 187 188 191 190 minecraft:crying_obsidian
fill 188 186 199 188 191 202 minecraft:crying_obsidian
fill 188 186 211 188 191 214 minecraft:crying_obsidian
fill 188 186 223 191 191 223 minecraft:crying_obsidian
setblock 191 186 184 minecraft:light[level=12]
setblock 191 186 192 minecraft:light[level=12]
setblock 191 186 200 minecraft:light[level=12]
fill 191 186 207 195 187 207 minecraft:amethyst_block
setblock 191 186 208 minecraft:light[level=12]
setblock 191 186 216 minecraft:light[level=12]
fill 195 186 181 198 191 181 minecraft:crying_obsidian
setblock 199 186 184 minecraft:light[level=12]
setblock 199 186 192 minecraft:light[level=12]
setblock 199 186 200 minecraft:light[level=12]
setblock 199 186 208 minecraft:light[level=12]
setblock 199 186 216 minecraft:light[level=12]
fill 200 186 223 203 191 223 minecraft:crying_obsidian
fill 207 186 181 210 191 181 minecraft:crying_obsidian
setblock 207 186 184 minecraft:light[level=12]
setblock 207 186 192 minecraft:light[level=12]
setblock 207 186 200 minecraft:light[level=12]
setblock 207 186 208 minecraft:light[level=12]
setblock 207 186 216 minecraft:light[level=12]
fill 212 186 223 215 191 223 minecraft:crying_obsidian
setblock 215 186 184 minecraft:light[level=12]
setblock 215 186 192 minecraft:light[level=12]
setblock 215 186 200 minecraft:light[level=12]
setblock 215 186 208 minecraft:light[level=12]
setblock 215 186 216 minecraft:light[level=12]
fill 219 186 181 222 191 181 minecraft:crying_obsidian
setblock 223 186 184 minecraft:light[level=12]
setblock 223 186 192 minecraft:light[level=12]
setblock 223 186 200 minecraft:light[level=12]
setblock 223 186 208 minecraft:light[level=12]
setblock 223 186 216 minecraft:light[level=12]
fill 224 186 223 227 191 223 minecraft:crying_obsidian
fill 230 186 182 230 191 185 minecraft:crying_obsidian
fill 230 186 194 230 191 197 minecraft:crying_obsidian
fill 230 186 206 230 191 209 minecraft:crying_obsidian
fill 230 186 218 230 191 221 minecraft:crying_obsidian
fill 189 187 207 190 190 208 minecraft:amethyst_block
fill 190 187 206 194 187 206 minecraft:amethyst_block
fill 191 187 208 194 187 208 minecraft:amethyst_block
fill 228 187 214 228 190 214 minecraft:amethyst_block
fill 188 188 203 188 191 203 minecraft:cracked_deepslate_bricks
setblock 188 188 204 minecraft:deepslate_bricks
fill 188 188 205 188 191 205 minecraft:cracked_deepslate_bricks
fill 188 188 215 188 189 219 minecraft:cracked_deepslate_bricks
fill 188 188 220 188 188 221 minecraft:deepslate_bricks
fill 189 188 209 190 189 209 minecraft:amethyst_block
fill 190 188 181 192 191 181 minecraft:cracked_deepslate_bricks
fill 190 188 205 190 189 206 minecraft:amethyst_block
fill 191 188 206 193 188 208 minecraft:amethyst_block
fill 193 188 181 194 188 181 minecraft:deepslate_bricks
fill 196 188 223 197 188 223 minecraft:cracked_deepslate_bricks
fill 198 188 223 199 188 223 minecraft:deepslate_bricks
fill 203 188 181 205 189 181 minecraft:cracked_deepslate_bricks
setblock 206 188 181 minecraft:deepslate_bricks
fill 220 188 223 221 188 223 minecraft:deepslate_bricks
fill 224 188 214 227 189 214 minecraft:amethyst_block
fill 227 188 213 229 189 213 minecraft:amethyst_block
fill 227 188 215 228 189 215 minecraft:amethyst_block
fill 228 188 181 229 188 181 minecraft:deepslate_bricks
fill 229 188 223 229 192 223 minecraft:cracked_deepslate_bricks
fill 230 188 181 230 189 181 minecraft:cracked_deepslate_bricks
fill 230 188 198 230 188 200 minecraft:cracked_deepslate_bricks
setblock 230 188 201 minecraft:deepslate_bricks
fill 230 188 202 230 191 204 minecraft:cracked_deepslate_bricks
fill 230 188 205 230 189 205 minecraft:deepslate_bricks
fill 230 188 210 230 191 216 minecraft:cracked_deepslate_bricks
setblock 230 188 217 minecraft:deepslate_bricks
setblock 230 188 223 minecraft:deepslate_bricks
fill 188 189 181 188 191 184 minecraft:cracked_deepslate_bricks
setblock 188 189 185 minecraft:deepslate_bricks
setblock 188 189 204 minecraft:cracked_deepslate_bricks
fill 188 189 220 188 191 221 minecraft:cracked_deepslate_bricks
fill 191 189 206 191 189 208 minecraft:amethyst_block
setblock 192 189 207 minecraft:amethyst_block
fill 193 189 181 193 192 181 minecraft:cracked_deepslate_bricks
setblock 194 189 181 minecraft:deepslate_bricks
setblock 196 189 223 minecraft:deepslate_bricks
fill 197 189 223 199 189 223 minecraft:cracked_deepslate_bricks
fill 206 189 181 206 191 181 minecraft:cracked_deepslate_bricks
setblock 206 189 223 minecraft:deepslate_bricks
fill 207 189 223 208 191 223 minecraft:cracked_deepslate_bricks
setblock 209 189 223 minecraft:deepslate_bricks
setblock 213 189 181 minecraft:deepslate_bricks
fill 220 189 223 222 191 223 minecraft:cracked_deepslate_bricks
fill 221 189 214 223 189 214 minecraft:amethyst_block
setblock 223 189 181 minecraft:deepslate_bricks
setblock 223 189 223 minecraft:deepslate_bricks
fill 224 189 181 225 191 181 minecraft:cracked_deepslate_bricks
fill 225 189 213 226 189 213 minecraft:amethyst_block
fill 225 189 215 226 189 215 minecraft:amethyst_block
fill 228 189 181 229 191 181 minecraft:cracked_deepslate_bricks
setblock 230 189 186 minecraft:deepslate_bricks
fill 230 189 187 230 191 193 minecraft:cracked_deepslate_bricks
fill 230 189 198 230 189 200 minecraft:deepslate_bricks
fill 230 189 201 230 192 201 minecraft:cracked_deepslate_bricks
fill 230 189 217 230 191 217 minecraft:cracked_deepslate_bricks
fill 230 189 223 230 191 223 minecraft:cracked_deepslate_bricks
fill 188 190 185 188 191 185 minecraft:cracked_deepslate_bricks
setblock 188 190 191 minecraft:deepslate_bricks
fill 188 190 192 188 191 194 minecraft:cracked_deepslate_bricks
setblock 188 190 195 minecraft:deepslate_bricks
fill 188 190 196 188 191 196 minecraft:cracked_deepslate_bricks
setblock 188 190 204 minecraft:deepslate_bricks
fill 188 190 206 188 191 206 minecraft:cracked_deepslate_bricks
setblock 188 190 207 minecraft:deepslate_bricks
fill 188 190 215 188 191 215 minecraft:cracked_deepslate_bricks
setblock 188 190 216 minecraft:deepslate_bricks
fill 188 190 217 188 191 218 minecraft:cracked_deepslate_bricks
setblock 188 190 219 minecraft:deepslate_bricks
setblock 190 190 206 minecraft:amethyst_block
setblock 191 190 207 minecraft:amethyst_block
fill 194 190 181 194 191 181 minecraft:cracked_deepslate_bricks
fill 196 190 223 196 191 223 minecraft:cracked_deepslate_bricks
setblock 197 190 223 minecraft:deepslate_bricks
fill 198 190 223 198 191 223 minecraft:cracked_deepslate_bricks
setblock 199 190 223 minecraft:deepslate_bricks
setblock 202 190 181 minecraft:deepslate_bricks
fill 203 190 181 203 191 181 minecraft:cracked_deepslate_bricks
setblock 204 190 181 minecraft:deepslate_bricks
fill 205 190 181 205 191 181 minecraft:cracked_deepslate_bricks
fill 206 190 223 206 191 223 minecraft:cracked_deepslate_bricks
fill 209 190 223 209 191 223 minecraft:cracked_deepslate_bricks
fill 213 190 181 213 191 181 minecraft:cracked_deepslate_bricks
setblock 217 190 181 minecraft:deepslate_bricks
fill 218 190 181 218 191 181 minecraft:cracked_deepslate_bricks
fill 223 190 181 223 191 181 minecraft:cracked_deepslate_bricks
fill 223 190 223 223 191 223 minecraft:cracked_deepslate_bricks
setblock 230 190 181 minecraft:deepslate_bricks
fill 230 190 186 230 192 186 minecraft:cracked_deepslate_bricks
fill 230 190 198 230 191 200 minecraft:cracked_deepslate_bricks
fill 230 190 205 230 191 205 minecraft:cracked_deepslate_bricks
setblock 188 191 191 minecraft:cracked_deepslate_bricks
setblock 188 191 195 minecraft:cracked_deepslate_bricks
setblock 188 191 204 minecraft:cracked_deepslate_bricks
setblock 188 191 207 minecraft:cracked_deepslate_bricks
setblock 188 191 216 minecraft:cracked_deepslate_bricks
setblock 188 191 219 minecraft:cracked_deepslate_bricks
setblock 197 191 223 minecraft:cracked_deepslate_bricks
setblock 199 191 223 minecraft:cracked_deepslate_bricks
fill 202 191 181 202 192 181 minecraft:cracked_deepslate_bricks
setblock 204 191 181 minecraft:cracked_deepslate_bricks
setblock 217 191 181 minecraft:cracked_deepslate_bricks
setblock 230 191 181 minecraft:cracked_deepslate_bricks
fill 188 192 181 188 205 187 minecraft:deepslate_bricks
fill 188 192 188 188 192 189 minecraft:crying_obsidian
setblock 188 192 190 minecraft:cracked_deepslate_bricks
fill 188 192 191 188 307 191 minecraft:deepslate_bricks
setblock 188 192 192 minecraft:cracked_deepslate_bricks
fill 188 192 193 188 307 196 minecraft:deepslate_bricks
fill 188 192 198 188 307 198 minecraft:deepslate_bricks
setblock 188 192 199 minecraft:cracked_deepslate_bricks
fill 188 192 200 188 192 201 minecraft:crying_obsidian
fill 188 192 202 188 193 211 minecraft:deepslate_bricks
fill 188 192 212 188 192 213 minecraft:crying_obsidian
fill 188 192 214 188 193 223 minecraft:deepslate_bricks
fill 189 192 181 192 192 181 minecraft:deepslate_bricks
fill 189 192 223 190 192 223 minecraft:crying_obsidian
fill 191 192 223 193 192 223 minecraft:deepslate_bricks
fill 194 192 181 194 307 181 minecraft:deepslate_bricks
setblock 194 192 223 minecraft:cracked_deepslate_bricks
setblock 195 192 181 minecraft:cracked_deepslate_bricks
fill 195 192 223 199 307 223 minecraft:deepslate_bricks
fill 196 192 181 197 192 181 minecraft:crying_obsidian
fill 198 192 181 199 205 181 minecraft:deepslate_bricks
setblock 200 192 181 minecraft:cracked_deepslate_bricks
setblock 200 192 223 minecraft:cracked_deepslate_bricks
fill 201 192 181 201 307 181 minecraft:deepslate_bricks
fill 201 192 223 202 192 223 minecraft:crying_obsidian
fill 203 192 181 207 205 181 minecraft:deepslate_bricks
fill 203 192 223 212 192 223 minecraft:deepslate_bricks
fill 208 192 181 209 192 181 minecraft:crying_obsidian
setblock 210 192 181 minecraft:cracked_deepslate_bricks
fill 211 192 181 219 192 181 minecraft:deepslate_bricks
fill 213 192 223 214 192 223 minecraft:crying_obsidian
setblock 215 192 223 minecraft:cracked_deepslate_bricks
fill 216 192 223 217 307 223 minecraft:deepslate_bricks
setblock 218 192 223 minecraft:cracked_deepslate_bricks
fill 219 192 223 219 307 223 minecraft:deepslate_bricks
fill 220 192 181 221 192 181 minecraft:crying_obsidian
setblock 220 192 223 minecraft:cracked_deepslate_bricks
fill 221 192 223 224 192 223 minecraft:deepslate_bricks
fill 222 192 181 226 205 181 minecraft:deepslate_bricks
fill 225 192 223 226 192 223 minecraft:crying_obsidian
fill 227 192 223 228 192 223 minecraft:deepslate_bricks
fill 228 192 181 230 193 181 minecraft:deepslate_bricks
fill 230 192 182 230 193 182 minecraft:deepslate_bricks
fill 230 192 183 230 192 184 minecraft:crying_obsidian
setblock 230 192 185 minecraft:cracked_deepslate_bricks
fill 230 192 187 230 192 194 minecraft:deepslate_bricks
fill 230 192 195 230 192 196 minecraft:crying_obsidian
fill 230 192 197 230 205 200 minecraft:deepslate_bricks
fill 230 192 202 230 307 203 minecraft:deepslate_bricks
setblock 230 192 204 minecraft:cracked_deepslate_bricks
fill 230 192 205 230 307 205 minecraft:deepslate_bricks
setblock 230 192 206 minecraft:cracked_deepslate_bricks
fill 230 192 207 230 192 208 minecraft:crying_obsidian
fill 230 192 209 230 205 210 minecraft:deepslate_bricks
fill 230 192 211 230 193 211 minecraft:cracked_deepslate_bricks
fill 230 192 212 230 193 218 minecraft:deepslate_bricks
fill 230 192 219 230 192 220 minecraft:crying_obsidian
fill 230 192 221 230 192 223 minecraft:deepslate_bricks
fill 188 193 188 188 205 188 minecraft:deepslate_bricks
setblock 188 193 189 minecraft:cracked_deepslate_bricks
fill 188 193 190 188 205 190 minecraft:deepslate_bricks
fill 188 193 192 188 307 192 minecraft:deepslate_bricks
fill 188 193 199 188 205 201 minecraft:deepslate_bricks
fill 188 193 212 188 205 213 minecraft:deepslate_bricks
fill 189 193 181 190 307 181 minecraft:deepslate_bricks
fill 189 193 223 191 205 223 minecraft:deepslate_bricks
setblock 191 193 181 minecraft:cracked_deepslate_bricks
fill 192 193 181 193 307 181 minecraft:deepslate_bricks
setblock 192 193 223 minecraft:cracked_deepslate_bricks
fill 193 193 223 194 307 223 minecraft:deepslate_bricks
fill 195 193 181 197 205 181 minecraft:deepslate_bricks
fill 200 193 181 200 307 181 minecraft:deepslate_bricks
fill 200 193 223 204 205 223 minecraft:deepslate_bricks
fill 202 193 181 202 307 181 minecraft:deepslate_bricks
fill 205 193 223 205 194 223 minecraft:cracked_deepslate_bricks
fill 206 193 223 210 307 223 minecraft:deepslate_bricks
fill 208 193 181 211 205 181 minecraft:deepslate_bricks
fill 211 193 223 211 194 223 minecraft:cracked_deepslate_bricks
fill 212 193 181 213 193 181 minecraft:cracked_deepslate_bricks
fill 212 193 223 215 193 223 minecraft:deepslate_bricks
fill 214 193 181 221 205 181 minecraft:deepslate_bricks
fill 218 193 223 218 307 223 minecraft:deepslate_bricks
fill 220 193 223 223 193 223 minecraft:deepslate_bricks
setblock 224 193 223 minecraft:cracked_deepslate_bricks
fill 225 193 223 226 205 223 minecraft:deepslate_bricks
fill 227 193 181 227 307 181 minecraft:deepslate_bricks
setblock 227 193 223 minecraft:cracked_deepslate_bricks
fill 228 193 223 229 307 223 minecraft:deepslate_bricks
setblock 230 193 183 minecraft:cracked_deepslate_bricks
fill 230 193 184 230 193 190 minecraft:deepslate_bricks
setblock 230 193 191 minecraft:cracked_deepslate_bricks
fill 230 193 192 230 205 196 minecraft:deepslate_bricks
fill 230 193 201 230 307 201 minecraft:deepslate_bricks
fill 230 193 204 230 307 204 minecraft:deepslate_bricks
fill 230 193 206 230 205 208 minecraft:deepslate_bricks
fill 230 193 219 230 205 222 minecraft:deepslate_bricks
setblock 230 193 223 minecraft:cracked_deepslate_bricks
fill 188 194 189 188 205 189 minecraft:deepslate_bricks
fill 188 194 197 188 307 197 minecraft:deepslate_bricks
setblock 188 194 202 minecraft:cracked_deepslate_bricks
fill 188 194 203 188 205 211 minecraft:deepslate_bricks
setblock 188 194 214 minecraft:cracked_deepslate_bricks
fill 188 194 215 188 307 217 minecraft:deepslate_bricks
setblock 188 194 218 minecraft:cracked_deepslate_bricks
fill 188 194 219 188 205 223 minecraft:deepslate_bricks
fill 191 194 181 191 307 181 minecraft:deepslate_bricks
setblock 191 194 184 minecraft:light[level=12]
setblock 191 194 192 minecraft:light[level=12]
setblock 191 194 200 minecraft:light[level=12]
setblock 191 194 208 minecraft:light[level=12]
setblock 191 194 216 minecraft:light[level=12]
fill 192 194 223 192 307 223 minecraft:deepslate_bricks
setblock 199 194 184 minecraft:light[level=12]
setblock 199 194 192 minecraft:light[level=12]
setblock 199 194 200 minecraft:light[level=12]
setblock 199 194 208 minecraft:light[level=12]
setblock 199 194 216 minecraft:light[level=12]
setblock 207 194 184 minecraft:light[level=12]
setblock 207 194 192 minecraft:light[level=12]
setblock 207 194 200 minecraft:light[level=12]
setblock 207 194 208 minecraft:light[level=12]
setblock 207 194 216 minecraft:light[level=12]
fill 212 194 181 213 307 181 minecraft:deepslate_bricks
setblock 212 194 223 minecraft:cracked_deepslate_bricks
fill 213 194 223 215 205 223 minecraft:deepslate_bricks
setblock 215 194 184 minecraft:light[level=12]
setblock 215 194 192 minecraft:light[level=12]
setblock 215 194 200 minecraft:light[level=12]
setblock 215 194 208 minecraft:light[level=12]
setblock 215 194 216 minecraft:light[level=12]
fill 220 194 223 222 307 223 minecraft:deepslate_bricks
setblock 223 194 184 minecraft:light[level=12]
setblock 223 194 192 minecraft:light[level=12]
setblock 223 194 200 minecraft:light[level=12]
setblock 223 194 208 minecraft:light[level=12]
setblock 223 194 216 minecraft:light[level=12]
setblock 223 194 223 minecraft:cracked_deepslate_bricks
fill 224 194 223 224 205 223 minecraft:deepslate_bricks
fill 227 194 223 227 205 223 minecraft:deepslate_bricks
fill 228 194 181 229 307 181 minecraft:deepslate_bricks
fill 230 194 181 230 194 182 minecraft:cracked_deepslate_bricks
fill 230 194 183 230 205 183 minecraft:deepslate_bricks
setblock 230 194 184 minecraft:cracked_deepslate_bricks
fill 230 194 185 230 205 188 minecraft:deepslate_bricks
setblock 230 194 189 minecraft:cracked_deepslate_bricks
fill 230 194 190 230 307 191 minecraft:deepslate_bricks
fill 230 194 211 230 307 215 minecraft:deepslate_bricks
setblock 230 194 216 minecraft:cracked_deepslate_bricks
fill 230 194 217 230 205 218 minecraft:deepslate_bricks
fill 230 194 223 230 307 223 minecraft:deepslate_bricks
fill 188 195 202 188 205 202 minecraft:deepslate_bricks
fill 188 195 214 188 205 214 minecraft:deepslate_bricks
fill 188 195 218 188 307 218 minecraft:deepslate_bricks
fill 205 195 223 205 307 223 minecraft:deepslate_bricks
fill 211 195 223 212 205 223 minecraft:deepslate_bricks
fill 223 195 223 223 307 223 minecraft:deepslate_bricks
fill 230 195 181 230 205 182 minecraft:deepslate_bricks
fill 230 195 184 230 205 184 minecraft:deepslate_bricks
fill 230 195 189 230 307 189 minecraft:deepslate_bricks
fill 230 195 216 230 307 216 minecraft:deepslate_bricks
fill 190 200 191 190 205 193 minecraft:polished_deepslate
fill 190 200 203 190 205 205 minecraft:polished_deepslate
fill 190 200 215 190 205 217 minecraft:polished_deepslate
fill 196 200 221 198 205 221 minecraft:polished_deepslate
fill 200 200 183 202 205 183 minecraft:polished_deepslate
fill 208 200 221 210 205 221 minecraft:polished_deepslate
fill 212 200 183 214 205 183 minecraft:polished_deepslate
fill 220 200 221 222 205 221 minecraft:polished_deepslate
fill 224 200 183 226 205 183 minecraft:polished_deepslate
fill 228 200 191 228 205 193 minecraft:polished_deepslate
fill 228 200 203 228 205 205 minecraft:polished_deepslate
fill 228 200 215 228 205 217 minecraft:polished_deepslate
setblock 191 202 184 minecraft:light[level=12]
setblock 191 202 192 minecraft:light[level=12]
setblock 191 202 200 minecraft:light[level=12]
setblock 191 202 208 minecraft:light[level=12]
setblock 191 202 216 minecraft:light[level=12]
setblock 199 202 184 minecraft:light[level=12]
setblock 199 202 192 minecraft:light[level=12]
setblock 199 202 200 minecraft:light[level=12]
setblock 199 202 208 minecraft:light[level=12]
setblock 199 202 216 minecraft:light[level=12]
setblock 207 202 184 minecraft:light[level=12]
setblock 207 202 192 minecraft:light[level=12]
setblock 207 202 200 minecraft:light[level=12]
setblock 207 202 208 minecraft:light[level=12]
setblock 207 202 216 minecraft:light[level=12]
setblock 215 202 184 minecraft:light[level=12]
setblock 215 202 192 minecraft:light[level=12]
setblock 215 202 200 minecraft:light[level=12]
setblock 215 202 208 minecraft:light[level=12]
setblock 215 202 216 minecraft:light[level=12]
setblock 223 202 184 minecraft:light[level=12]
setblock 223 202 192 minecraft:light[level=12]
setblock 223 202 200 minecraft:light[level=12]
setblock 223 202 208 minecraft:light[level=12]
setblock 223 202 216 minecraft:light[level=12]
fill 191 203 198 191 208 198 minecraft:purple_concrete
fill 205 204 183 205 216 183 minecraft:purple_concrete
fill 189 205 185 189 205 190 minecraft:obsidian
fill 189 205 197 189 205 202 minecraft:obsidian
fill 189 205 209 189 205 214 minecraft:obsidian
fill 189 205 221 189 205 222 minecraft:obsidian
fill 190 205 222 193 205 222 minecraft:obsidian
fill 191 205 197 191 208 197 minecraft:purple_concrete
fill 191 205 199 191 208 199 minecraft:purple_concrete
fill 192 205 198 192 208 198 minecraft:purple_concrete
fill 193 205 182 198 205 182 minecraft:obsidian
fill 200 205 222 205 205 222 minecraft:obsidian
fill 203 205 183 204 216 183 minecraft:purple_concrete
fill 205 205 182 210 205 182 minecraft:obsidian
fill 206 205 183 207 216 183 minecraft:purple_concrete
fill 212 205 222 217 205 222 minecraft:obsidian
fill 217 205 182 222 205 182 minecraft:obsidian
fill 224 205 222 229 205 222 minecraft:obsidian
fill 229 205 182 229 205 187 minecraft:obsidian
fill 229 205 194 229 205 199 minecraft:obsidian
fill 229 205 206 229 205 211 minecraft:obsidian
fill 229 205 218 229 205 221 minecraft:obsidian
fill 188 206 181 188 307 186 minecraft:deepslate_bricks
fill 188 206 187 188 211 190 minecraft:crying_obsidian
fill 188 206 199 188 211 202 minecraft:crying_obsidian
fill 188 206 203 188 307 210 minecraft:deepslate_bricks
fill 188 206 211 188 211 214 minecraft:crying_obsidian
fill 188 206 219 188 307 222 minecraft:deepslate_bricks
fill 188 206 223 191 211 223 minecraft:crying_obsidian
fill 190 206 198 190 208 198 minecraft:purple_concrete
fill 192 206 197 192 208 197 minecraft:purple_concrete
fill 192 206 199 192 208 199 minecraft:purple_concrete
fill 195 206 181 198 211 181 minecraft:crying_obsidian
fill 199 206 181 199 307 181 minecraft:deepslate_bricks
fill 200 206 223 203 211 223 minecraft:crying_obsidian
fill 203 206 181 206 307 181 minecraft:deepslate_bricks
fill 204 206 223 204 307 223 minecraft:deepslate_bricks
fill 207 206 181 210 211 181 minecraft:crying_obsidian
fill 211 206 181 211 307 181 minecraft:deepslate_bricks
fill 211 206 223 211 307 223 minecraft:deepslate_bricks
fill 212 206 223 215 211 223 minecraft:crying_obsidian
fill 214 206 181 218 307 181 minecraft:deepslate_bricks
fill 219 206 181 222 211 181 minecraft:crying_obsidian
fill 223 206 181 226 307 181 minecraft:deepslate_bricks
fill 224 206 223 227 211 223 minecraft:crying_obsidian
fill 226 206 213 226 211 213 minecraft:purple_concrete
fill 230 206 181 230 307 181 minecraft:deepslate_bricks
fill 230 206 182 230 211 185 minecraft:crying_obsidian
fill 230 206 186 230 307 188 minecraft:deepslate_bricks
fill 230 206 192 230 307 193 minecraft:deepslate_bricks
fill 230 206 194 230 211 197 minecraft:crying_obsidian
fill 230 206 198 230 307 200 minecraft:deepslate_bricks
fill 230 206 206 230 211 209 minecraft:crying_obsidian
fill 230 206 210 230 307 210 minecraft:deepslate_bricks
fill 230 206 217 230 307 217 minecraft:deepslate_bricks
fill 230 206 218 230 211 221 minecraft:crying_obsidian
fill 230 206 222 230 307 222 minecraft:deepslate_bricks
fill 190 207 197 190 208 197 minecraft:purple_concrete
fill 190 207 199 190 208 199 minecraft:purple_concrete
fill 193 207 198 193 208 198 minecraft:purple_concrete
setblock 189 208 198 minecraft:purple_concrete
fill 191 208 196 192 208 196 minecraft:purple_concrete
fill 191 208 200 192 208 200 minecraft:purple_concrete
setblock 193 208 197 minecraft:purple_concrete
setblock 193 208 199 minecraft:purple_concrete
fill 227 208 213 227 211 213 minecraft:purple_concrete
fill 189 209 195 194 210 201 minecraft:polished_deepslate
fill 225 209 213 225 211 213 minecraft:purple_concrete
fill 226 209 212 227 211 212 minecraft:purple_concrete
fill 226 209 214 227 211 214 minecraft:purple_concrete
setblock 191 210 184 minecraft:light[level=12]
setblock 191 210 192 minecraft:light[level=12]
setblock 191 210 208 minecraft:light[level=12]
setblock 191 210 216 minecraft:light[level=12]
setblock 199 210 184 minecraft:light[level=12]
setblock 199 210 192 minecraft:light[level=12]
setblock 199 210 200 minecraft:light[level=12]
setblock 199 210 208 minecraft:light[level=12]
setblock 199 210 216 minecraft:light[level=12]
setblock 207 210 184 minecraft:light[level=12]
setblock 207 210 192 minecraft:light[level=12]
setblock 207 210 200 minecraft:light[level=12]
setblock 207 210 208 minecraft:light[level=12]
setblock 207 210 216 minecraft:light[level=12]
setblock 215 210 184 minecraft:light[level=12]
setblock 215 210 192 minecraft:light[level=12]
setblock 215 210 200 minecraft:light[level=12]
setblock 215 210 208 minecraft:light[level=12]
setblock 215 210 216 minecraft:light[level=12]
setblock 223 210 184 minecraft:light[level=12]
setblock 223 210 192 minecraft:light[level=12]
setblock 223 210 200 minecraft:light[level=12]
setblock 223 210 208 minecraft:light[level=12]
setblock 223 210 216 minecraft:light[level=12]
fill 189 211 195 189 227 195 minecraft:polished_deepslate
setblock 189 211 196 minecraft:crying_obsidian
fill 189 211 197 189 224 197 minecraft:polished_deepslate
setblock 189 211 198 minecraft:crying_obsidian
fill 189 211 199 189 224 199 minecraft:polished_deepslate
setblock 189 211 200 minecraft:crying_obsidian
fill 189 211 201 189 224 201 minecraft:polished_deepslate
setblock 190 211 195 minecraft:crying_obsidian
fill 190 211 196 190 227 196 minecraft:polished_deepslate
setblock 190 211 197 minecraft:crying_obsidian
fill 190 211 198 190 227 198 minecraft:polished_deepslate
setblock 190 211 199 minecraft:crying_obsidian
fill 190 211 200 190 227 200 minecraft:polished_deepslate
setblock 190 211 201 minecraft:crying_obsidian
fill 191 211 195 191 227 195 minecraft:polished_deepslate
setblock 191 211 196 minecraft:crying_obsidian
fill 191 211 197 191 227 197 minecraft:polished_deepslate
setblock 191 211 198 minecraft:crying_obsidian
fill 191 211 199 191 227 199 minecraft:polished_deepslate
setblock 191 211 200 minecraft:crying_obsidian
fill 191 211 201 191 227 201 minecraft:polished_deepslate
setblock 192 211 195 minecraft:crying_obsidian
fill 192 211 196 192 227 196 minecraft:polished_deepslate
setblock 192 211 197 minecraft:crying_obsidian
fill 192 211 198 192 227 198 minecraft:polished_deepslate
setblock 192 211 199 minecraft:crying_obsidian
fill 192 211 200 192 227 200 minecraft:polished_deepslate
setblock 192 211 201 minecraft:crying_obsidian
fill 193 211 195 193 227 195 minecraft:polished_deepslate
setblock 193 211 196 minecraft:crying_obsidian
fill 193 211 197 193 227 197 minecraft:polished_deepslate
setblock 193 211 198 minecraft:crying_obsidian
fill 193 211 199 193 227 199 minecraft:polished_deepslate
setblock 193 211 200 minecraft:crying_obsidian
fill 193 211 201 193 227 201 minecraft:polished_deepslate
setblock 194 211 195 minecraft:crying_obsidian
fill 194 211 196 194 227 196 minecraft:polished_deepslate
setblock 194 211 197 minecraft:crying_obsidian
fill 194 211 198 194 227 198 minecraft:polished_deepslate
setblock 194 211 199 minecraft:crying_obsidian
fill 194 211 200 194 227 200 minecraft:polished_deepslate
setblock 194 211 201 minecraft:crying_obsidian
setblock 225 211 212 minecraft:purple_concrete
setblock 225 211 214 minecraft:purple_concrete
setblock 228 211 213 minecraft:purple_concrete
fill 188 212 187 188 225 187 minecraft:deepslate_bricks
fill 188 212 188 188 212 189 minecraft:crying_obsidian
fill 188 212 190 188 225 190 minecraft:deepslate_bricks
fill 188 212 199 188 225 199 minecraft:deepslate_bricks
fill 188 212 200 188 212 201 minecraft:crying_obsidian
fill 188 212 202 188 225 202 minecraft:deepslate_bricks
fill 188 212 211 188 225 211 minecraft:deepslate_bricks
fill 188 212 212 188 212 213 minecraft:crying_obsidian
fill 188 212 214 188 225 214 minecraft:deepslate_bricks
fill 188 212 223 188 225 223 minecraft:deepslate_bricks
fill 189 212 196 189 213 196 minecraft:polished_deepslate
fill 189 212 198 189 213 198 minecraft:polished_deepslate
fill 189 212 200 189 213 200 minecraft:polished_deepslate
fill 189 212 223 190 212 223 minecraft:crying_obsidian
fill 190 212 195 190 213 195 minecraft:polished_deepslate
fill 190 212 197 190 213 197 minecraft:polished_deepslate
fill 190 212 199 190 213 199 minecraft:polished_deepslate
fill 190 212 201 190 213 201 minecraft:polished_deepslate
fill 190 212 209 190 223 209 minecraft:purple_concrete
fill 191 212 196 191 213 196 minecraft:polished_deepslate
fill 191 212 198 191 213 198 minecraft:polished_deepslate
fill 191 212 200 191 213 200 minecraft:polished_deepslate
fill 191 212 223 191 225 223 minecraft:deepslate_bricks
fill 192 212 195 192 213 195 minecraft:polished_deepslate
fill 192 212 197 192 213 197 minecraft:polished_deepslate
fill 192 212 199 192 213 199 minecraft:polished_deepslate
fill 192 212 201 192 213 201 minecraft:polished_deepslate
fill 193 212 196 193 213 196 minecraft:polished_deepslate
fill 193 212 198 193 213 198 minecraft:polished_deepslate
fill 193 212 200 193 213 200 minecraft:polished_deepslate
fill 194 212 195 194 213 195 minecraft:polished_deepslate
fill 194 212 197 194 213 197 minecraft:polished_deepslate
fill 194 212 199 194 213 199 minecraft:polished_deepslate
fill 194 212 201 194 213 201 minecraft:polished_deepslate
fill 195 212 181 195 225 181 minecraft:deepslate_bricks
fill 196 212 181 197 212 181 minecraft:crying_obsidian
fill 198 212 181 198 225 181 minecraft:deepslate_bricks
fill 200 212 223 200 225 223 minecraft:deepslate_bricks
fill 201 212 223 202 212 223 minecraft:crying_obsidian
fill 203 212 223 203 225 223 minecraft:deepslate_bricks
fill 207 212 181 207 225 181 minecraft:deepslate_bricks
fill 208 212 181 209 212 181 minecraft:crying_obsidian
fill 210 212 181 210 225 181 minecraft:deepslate_bricks
fill 212 212 223 212 225 223 minecraft:deepslate_bricks
fill 213 212 223 214 212 223 minecraft:crying_obsidian
fill 215 212 223 215 225 223 minecraft:deepslate_bricks
fill 219 212 181 219 225 181 minecraft:deepslate_bricks
fill 220 212 181 221 212 181 minecraft:crying_obsidian
fill 222 212 181 222 225 181 minecraft:deepslate_bricks
fill 224 212 207 228 213 219 minecraft:polished_deepslate
fill 224 212 223 224 225 223 minecraft:deepslate_bricks
fill 225 212 223 226 212 223 minecraft:crying_obsidian
fill 227 212 223 227 225 223 minecraft:deepslate_bricks
fill 229 212 207 229 213 213 minecraft:polished_deepslate
fill 229 212 217 229 213 219 minecraft:polished_deepslate
fill 230 212 182 230 225 182 minecraft:deepslate_bricks
fill 230 212 183 230 212 184 minecraft:crying_obsidian
fill 230 212 185 230 225 185 minecraft:deepslate_bricks
fill 230 212 194 230 225 194 minecraft:deepslate_bricks
fill 230 212 195 230 212 196 minecraft:crying_obsidian
fill 230 212 197 230 225 197 minecraft:deepslate_bricks
fill 230 212 206 230 225 206 minecraft:deepslate_bricks
fill 230 212 207 230 212 208 minecraft:crying_obsidian
fill 230 212 209 230 225 209 minecraft:deepslate_bricks
fill 230 212 218 230 225 218 minecraft:deepslate_bricks
fill 230 212 219 230 212 220 minecraft:crying_obsidian
fill 230 212 221 230 225 221 minecraft:deepslate_bricks
fill 188 213 188 188 225 189 minecraft:deepslate_bricks
fill 188 213 200 188 225 201 minecraft:deepslate_bricks
fill 188 213 212 188 225 213 minecraft:deepslate_bricks
fill 189 213 223 190 225 223 minecraft:deepslate_bricks
fill 190 213 207 190 223 208 minecraft:purple_concrete
fill 190 213 210 190 223 211 minecraft:purple_concrete
fill 196 213 181 197 225 181 minecraft:deepslate_bricks
fill 201 213 223 202 225 223 minecraft:deepslate_bricks
fill 208 213 181 209 225 181 minecraft:deepslate_bricks
fill 213 213 223 214 225 223 minecraft:deepslate_bricks
fill 220 213 181 221 225 181 minecraft:deepslate_bricks
fill 225 213 223 226 225 223 minecraft:deepslate_bricks
fill 230 213 183 230 225 184 minecraft:deepslate_bricks
fill 230 213 195 230 225 196 minecraft:deepslate_bricks
fill 230 213 207 230 225 208 minecraft:deepslate_bricks
fill 230 213 219 230 225 220 minecraft:deepslate_bricks
setblock 189 214 196 minecraft:crying_obsidian
setblock 189 214 198 minecraft:crying_obsidian
setblock 189 214 200 minecraft:crying_obsidian
setblock 190 214 195 minecraft:crying_obsidian
setblock 190 214 197 minecraft:crying_obsidian
setblock 190 214 199 minecraft:crying_obsidian
setblock 190 214 201 minecraft:crying_obsidian
setblock 191 214 196 minecraft:crying_obsidian
setblock 191 214 198 minecraft:crying_obsidian
setblock 191 214 200 minecraft:crying_obsidian
setblock 192 214 195 minecraft:crying_obsidian
setblock 192 214 197 minecraft:crying_obsidian
setblock 192 214 199 minecraft:crying_obsidian
setblock 192 214 201 minecraft:crying_obsidian
setblock 193 214 196 minecraft:crying_obsidian
setblock 193 214 198 minecraft:crying_obsidian
setblock 193 214 200 minecraft:crying_obsidian
setblock 194 214 195 minecraft:crying_obsidian
setblock 194 214 197 minecraft:crying_obsidian
setblock 194 214 199 minecraft:crying_obsidian
setblock 194 214 201 minecraft:crying_obsidian
setblock 224 214 207 minecraft:crying_obsidian
fill 224 214 208 224 227 208 minecraft:polished_deepslate
setblock 224 214 209 minecraft:crying_obsidian
fill 224 214 210 224 227 210 minecraft:polished_deepslate
setblock 224 214 211 minecraft:crying_obsidian
fill 224 214 212 224 227 212 minecraft:polished_deepslate
setblock 224 214 213 minecraft:crying_obsidian
fill 224 214 214 224 227 214 minecraft:polished_deepslate
setblock 224 214 215 minecraft:crying_obsidian
fill 224 214 216 224 227 216 minecraft:polished_deepslate
setblock 224 214 217 minecraft:crying_obsidian
fill 224 214 218 224 227 218 minecraft:polished_deepslate
setblock 224 214 219 minecraft:crying_obsidian
fill 225 214 207 225 227 207 minecraft:polished_deepslate
setblock 225 214 208 minecraft:crying_obsidian
fill 225 214 209 225 227 209 minecraft:polished_deepslate
setblock 225 214 210 minecraft:crying_obsidian
fill 225 214 211 225 227 211 minecraft:polished_deepslate
setblock 225 214 212 minecraft:crying_obsidian
fill 225 214 213 225 227 213 minecraft:polished_deepslate
setblock 225 214 214 minecraft:crying_obsidian
fill 225 214 215 225 227 215 minecraft:polished_deepslate
setblock 225 214 216 minecraft:crying_obsidian
fill 225 214 217 225 227 217 minecraft:polished_deepslate
setblock 225 214 218 minecraft:crying_obsidian
fill 225 214 219 225 227 219 minecraft:polished_deepslate
setblock 226 214 207 minecraft:crying_obsidian
fill 226 214 208 226 227 208 minecraft:polished_deepslate
setblock 226 214 209 minecraft:crying_obsidian
fill 226 214 210 226 227 210 minecraft:polished_deepslate
setblock 226 214 211 minecraft:crying_obsidian
fill 226 214 212 226 227 212 minecraft:polished_deepslate
setblock 226 214 213 minecraft:crying_obsidian
fill 226 214 214 226 227 214 minecraft:polished_deepslate
setblock 226 214 215 minecraft:crying_obsidian
fill 226 214 216 226 227 216 minecraft:polished_deepslate
setblock 226 214 217 minecraft:crying_obsidian
fill 226 214 218 226 227 218 minecraft:polished_deepslate
setblock 226 214 219 minecraft:crying_obsidian
fill 227 214 207 227 227 207 minecraft:polished_deepslate
setblock 227 214 208 minecraft:crying_obsidian
fill 227 214 209 227 227 209 minecraft:polished_deepslate
setblock 227 214 210 minecraft:crying_obsidian
fill 227 214 211 227 227 211 minecraft:polished_deepslate
setblock 227 214 212 minecraft:crying_obsidian
fill 227 214 213 227 227 213 minecraft:polished_deepslate
setblock 227 214 214 minecraft:crying_obsidian
fill 227 214 215 227 227 215 minecraft:polished_deepslate
setblock 227 214 216 minecraft:crying_obsidian
fill 227 214 217 227 227 217 minecraft:polished_deepslate
setblock 227 214 218 minecraft:crying_obsidian
fill 227 214 219 227 227 219 minecraft:polished_deepslate
setblock 228 214 207 minecraft:crying_obsidian
fill 228 214 208 228 227 208 minecraft:polished_deepslate
setblock 228 214 209 minecraft:crying_obsidian
fill 228 214 210 228 227 210 minecraft:polished_deepslate
setblock 228 214 211 minecraft:crying_obsidian
fill 228 214 212 228 227 212 minecraft:polished_deepslate
setblock 228 214 213 minecraft:crying_obsidian
fill 228 214 214 228 227 214 minecraft:polished_deepslate
setblock 228 214 215 minecraft:crying_obsidian
fill 228 214 216 228 227 216 minecraft:polished_deepslate
setblock 228 214 217 minecraft:crying_obsidian
fill 228 214 218 228 227 218 minecraft:polished_deepslate
setblock 228 214 219 minecraft:crying_obsidian
fill 229 214 207 229 224 207 minecraft:polished_deepslate
setblock 229 214 208 minecraft:crying_obsidian
fill 229 214 209 229 224 209 minecraft:polished_deepslate
setblock 229 214 210 minecraft:crying_obsidian
fill 229 214 211 229 224 211 minecraft:polished_deepslate
setblock 229 214 212 minecraft:crying_obsidian
fill 229 214 213 229 227 213 minecraft:polished_deepslate
setblock 229 214 214 minecraft:crying_obsidian
fill 229 214 215 229 227 215 minecraft:polished_deepslate
setblock 229 214 216 minecraft:crying_obsidian
fill 229 214 217 229 227 217 minecraft:polished_deepslate
setblock 229 214 218 minecraft:crying_obsidian
fill 229 214 219 229 224 219 minecraft:polished_deepslate
fill 189 215 196 189 216 196 minecraft:polished_deepslate
fill 189 215 198 189 216 198 minecraft:polished_deepslate
fill 189 215 200 189 216 200 minecraft:polished_deepslate
fill 190 215 195 190 216 195 minecraft:polished_deepslate
fill 190 215 197 190 216 197 minecraft:polished_deepslate
fill 190 215 199 190 216 199 minecraft:polished_deepslate
fill 190 215 201 190 216 201 minecraft:polished_deepslate
fill 191 215 196 191 216 196 minecraft:polished_deepslate
fill 191 215 198 191 216 198 minecraft:polished_deepslate
fill 191 215 200 191 216 200 minecraft:polished_deepslate
fill 192 215 195 192 216 195 minecraft:polished_deepslate
fill 192 215 197 192 216 197 minecraft:polished_deepslate
fill 192 215 199 192 216 199 minecraft:polished_deepslate
fill 192 215 201 192 216 201 minecraft:polished_deepslate
fill 193 215 196 193 216 196 minecraft:polished_deepslate
fill 193 215 198 193 216 198 minecraft:polished_deepslate
fill 193 215 200 193 216 200 minecraft:polished_deepslate
fill 194 215 195 194 216 195 minecraft:polished_deepslate
fill 194 215 197 194 216 197 minecraft:polished_deepslate
fill 194 215 199 194 216 199 minecraft:polished_deepslate
fill 194 215 201 194 216 201 minecraft:polished_deepslate
fill 224 215 207 224 216 207 minecraft:polished_deepslate
fill 224 215 209 224 216 209 minecraft:polished_deepslate
fill 224 215 211 224 216 211 minecraft:polished_deepslate
fill 224 215 213 224 216 213 minecraft:polished_deepslate
fill 224 215 215 224 216 215 minecraft:polished_deepslate
fill 224 215 217 224 216 217 minecraft:polished_deepslate
fill 224 215 219 224 216 219 minecraft:polished_deepslate
fill 225 215 208 225 216 208 minecraft:polished_deepslate
fill 225 215 210 225 216 210 minecraft:polished_deepslate
fill 225 215 212 225 216 212 minecraft:polished_deepslate
fill 225 215 214 225 216 214 minecraft:polished_deepslate
fill 225 215 216 225 216 216 minecraft:polished_deepslate
fill 225 215 218 225 216 218 minecraft:polished_deepslate
fill 226 215 207 226 216 207 minecraft:polished_deepslate
fill 226 215 209 226 216 209 minecraft:polished_deepslate
fill 226 215 211 226 216 211 minecraft:polished_deepslate
fill 226 215 213 226 216 213 minecraft:polished_deepslate
fill 226 215 215 226 216 215 minecraft:polished_deepslate
fill 226 215 217 226 216 217 minecraft:polished_deepslate
fill 226 215 219 226 216 219 minecraft:polished_deepslate
fill 227 215 208 227 216 208 minecraft:polished_deepslate
fill 227 215 210 227 216 210 minecraft:polished_deepslate
fill 227 215 212 227 216 212 minecraft:polished_deepslate
fill 227 215 214 227 216 214 minecraft:polished_deepslate
fill 227 215 216 227 216 216 minecraft:polished_deepslate
fill 227 215 218 227 216 218 minecraft:polished_deepslate
fill 228 215 207 228 216 207 minecraft:polished_deepslate
fill 228 215 209 228 216 209 minecraft:polished_deepslate
fill 228 215 211 228 216 211 minecraft:polished_deepslate
fill 228 215 213 228 216 213 minecraft:polished_deepslate
fill 228 215 215 228 216 215 minecraft:polished_deepslate
fill 228 215 217 228 216 217 minecraft:polished_deepslate
fill 228 215 219 228 216 219 minecraft:polished_deepslate
fill 229 215 208 229 216 208 minecraft:polished_deepslate
fill 229 215 210 229 216 210 minecraft:polished_deepslate
fill 229 215 212 229 216 212 minecraft:polished_deepslate
fill 229 215 214 229 216 214 minecraft:polished_deepslate
fill 229 215 216 229 216 216 minecraft:polished_deepslate
fill 229 215 218 229 216 218 minecraft:polished_deepslate
setblock 189 217 196 minecraft:crying_obsidian
setblock 189 217 198 minecraft:crying_obsidian
setblock 189 217 200 minecraft:crying_obsidian
setblock 190 217 195 minecraft:crying_obsidian
setblock 190 217 197 minecraft:crying_obsidian
setblock 190 217 199 minecraft:crying_obsidian
setblock 190 217 201 minecraft:crying_obsidian
setblock 191 217 196 minecraft:crying_obsidian
setblock 191 217 198 minecraft:crying_obsidian
setblock 191 217 200 minecraft:crying_obsidian
setblock 192 217 195 minecraft:crying_obsidian
setblock 192 217 197 minecraft:crying_obsidian
setblock 192 217 199 minecraft:crying_obsidian
setblock 192 217 201 minecraft:crying_obsidian
setblock 193 217 196 minecraft:crying_obsidian
setblock 193 217 198 minecraft:crying_obsidian
setblock 193 217 200 minecraft:crying_obsidian
setblock 194 217 195 minecraft:crying_obsidian
setblock 194 217 197 minecraft:crying_obsidian
setblock 194 217 199 minecraft:crying_obsidian
setblock 194 217 201 minecraft:crying_obsidian
fill 202 217 183 208 218 183 minecraft:obsidian
setblock 224 217 207 minecraft:crying_obsidian
setblock 224 217 209 minecraft:crying_obsidian
setblock 224 217 211 minecraft:crying_obsidian
setblock 224 217 213 minecraft:crying_obsidian
setblock 224 217 215 minecraft:crying_obsidian
setblock 224 217 217 minecraft:crying_obsidian
setblock 224 217 219 minecraft:crying_obsidian
setblock 225 217 208 minecraft:crying_obsidian
setblock 225 217 210 minecraft:crying_obsidian
setblock 225 217 212 minecraft:crying_obsidian
setblock 225 217 214 minecraft:crying_obsidian
setblock 225 217 216 minecraft:crying_obsidian
setblock 225 217 218 minecraft:crying_obsidian
setblock 226 217 207 minecraft:crying_obsidian
setblock 226 217 209 minecraft:crying_obsidian
setblock 226 217 211 minecraft:crying_obsidian
setblock 226 217 213 minecraft:crying_obsidian
setblock 226 217 215 minecraft:crying_obsidian
setblock 226 217 217 minecraft:crying_obsidian
setblock 226 217 219 minecraft:crying_obsidian
setblock 227 217 208 minecraft:crying_obsidian
setblock 227 217 210 minecraft:crying_obsidian
setblock 227 217 212 minecraft:crying_obsidian
setblock 227 217 214 minecraft:crying_obsidian
setblock 227 217 216 minecraft:crying_obsidian
setblock 227 217 218 minecraft:crying_obsidian
setblock 228 217 207 minecraft:crying_obsidian
setblock 228 217 209 minecraft:crying_obsidian
setblock 228 217 211 minecraft:crying_obsidian
setblock 228 217 213 minecraft:crying_obsidian
setblock 228 217 215 minecraft:crying_obsidian
setblock 228 217 217 minecraft:crying_obsidian
setblock 228 217 219 minecraft:crying_obsidian
setblock 229 217 208 minecraft:crying_obsidian
setblock 229 217 210 minecraft:crying_obsidian
setblock 229 217 212 minecraft:crying_obsidian
setblock 229 217 214 minecraft:crying_obsidian
setblock 229 217 216 minecraft:crying_obsidian
setblock 229 217 218 minecraft:crying_obsidian
fill 189 218 196 189 219 196 minecraft:polished_deepslate
fill 189 218 198 189 219 198 minecraft:polished_deepslate
fill 189 218 200 189 219 200 minecraft:polished_deepslate
fill 190 218 195 190 219 195 minecraft:polished_deepslate
fill 190 218 197 190 219 197 minecraft:polished_deepslate
fill 190 218 199 190 219 199 minecraft:polished_deepslate
fill 190 218 201 190 219 201 minecraft:polished_deepslate
setblock 191 218 184 minecraft:light[level=12]
setblock 191 218 192 minecraft:light[level=12]
fill 191 218 196 191 219 196 minecraft:polished_deepslate
fill 191 218 198 191 219 198 minecraft:polished_deepslate
fill 191 218 200 191 219 200 minecraft:polished_deepslate
setblock 191 218 208 minecraft:light[level=12]
setblock 191 218 216 minecraft:light[level=12]
fill 192 218 195 192 219 195 minecraft:polished_deepslate
fill 192 218 197 192 219 197 minecraft:polished_deepslate
fill 192 218 199 192 219 199 minecraft:polished_deepslate
fill 192 218 201 192 219 201 minecraft:polished_deepslate
fill 193 218 196 193 219 196 minecraft:polished_deepslate
fill 193 218 198 193 219 198 minecraft:polished_deepslate
fill 193 218 200 193 219 200 minecraft:polished_deepslate
fill 194 218 195 194 219 195 minecraft:polished_deepslate
fill 194 218 197 194 219 197 minecraft:polished_deepslate
fill 194 218 199 194 219 199 minecraft:polished_deepslate
fill 194 218 201 194 219 201 minecraft:polished_deepslate
setblock 199 218 184 minecraft:light[level=12]
setblock 199 218 192 minecraft:light[level=12]
setblock 199 218 200 minecraft:light[level=12]
setblock 199 218 208 minecraft:light[level=12]
setblock 199 218 216 minecraft:light[level=12]
setblock 207 218 184 minecraft:light[level=12]
setblock 207 218 192 minecraft:light[level=12]
setblock 207 218 200 minecraft:light[level=12]
setblock 207 218 208 minecraft:light[level=12]
setblock 207 218 216 minecraft:light[level=12]
setblock 215 218 184 minecraft:light[level=12]
setblock 215 218 192 minecraft:light[level=12]
setblock 215 218 200 minecraft:light[level=12]
setblock 215 218 208 minecraft:light[level=12]
setblock 215 218 216 minecraft:light[level=12]
setblock 223 218 184 minecraft:light[level=12]
setblock 223 218 192 minecraft:light[level=12]
setblock 223 218 200 minecraft:light[level=12]
setblock 223 218 208 minecraft:light[level=12]
setblock 223 218 216 minecraft:light[level=12]
fill 224 218 207 224 219 207 minecraft:polished_deepslate
fill 224 218 209 224 219 209 minecraft:polished_deepslate
fill 224 218 211 224 219 211 minecraft:polished_deepslate
fill 224 218 213 224 219 213 minecraft:polished_deepslate
fill 224 218 215 224 219 215 minecraft:polished_deepslate
fill 224 218 217 224 219 217 minecraft:polished_deepslate
fill 224 218 219 224 219 219 minecraft:polished_deepslate
fill 225 218 208 225 219 208 minecraft:polished_deepslate
fill 225 218 210 225 219 210 minecraft:polished_deepslate
fill 225 218 212 225 219 212 minecraft:polished_deepslate
fill 225 218 214 225 219 214 minecraft:polished_deepslate
fill 225 218 216 225 219 216 minecraft:polished_deepslate
fill 225 218 218 225 219 218 minecraft:polished_deepslate
fill 226 218 207 226 219 207 minecraft:polished_deepslate
fill 226 218 209 226 219 209 minecraft:polished_deepslate
fill 226 218 211 226 219 211 minecraft:polished_deepslate
fill 226 218 213 226 219 213 minecraft:polished_deepslate
fill 226 218 215 226 219 215 minecraft:polished_deepslate
fill 226 218 217 226 219 217 minecraft:polished_deepslate
fill 226 218 219 226 219 219 minecraft:polished_deepslate
fill 227 218 208 227 219 208 minecraft:polished_deepslate
fill 227 218 210 227 219 210 minecraft:polished_deepslate
fill 227 218 212 227 219 212 minecraft:polished_deepslate
fill 227 218 214 227 219 214 minecraft:polished_deepslate
fill 227 218 216 227 219 216 minecraft:polished_deepslate
fill 227 218 218 227 219 218 minecraft:polished_deepslate
fill 228 218 207 228 219 207 minecraft:polished_deepslate
fill 228 218 209 228 219 209 minecraft:polished_deepslate
fill 228 218 211 228 219 211 minecraft:polished_deepslate
fill 228 218 213 228 219 213 minecraft:polished_deepslate
fill 228 218 215 228 219 215 minecraft:polished_deepslate
fill 228 218 217 228 219 217 minecraft:polished_deepslate
fill 228 218 219 228 219 219 minecraft:polished_deepslate
fill 229 218 208 229 219 208 minecraft:polished_deepslate
fill 229 218 210 229 219 210 minecraft:polished_deepslate
fill 229 218 212 229 219 212 minecraft:polished_deepslate
fill 229 218 214 229 219 214 minecraft:polished_deepslate
fill 229 218 216 229 219 216 minecraft:polished_deepslate
fill 229 218 218 229 219 218 minecraft:polished_deepslate
setblock 189 220 196 minecraft:crying_obsidian
setblock 189 220 198 minecraft:crying_obsidian
setblock 189 220 200 minecraft:crying_obsidian
fill 190 220 191 190 225 193 minecraft:polished_deepslate
setblock 190 220 195 minecraft:crying_obsidian
setblock 190 220 197 minecraft:crying_obsidian
setblock 190 220 199 minecraft:crying_obsidian
setblock 190 220 201 minecraft:crying_obsidian
fill 190 220 203 190 225 205 minecraft:polished_deepslate
fill 190 220 215 190 225 217 minecraft:polished_deepslate
setblock 191 220 196 minecraft:crying_obsidian
setblock 191 220 198 minecraft:crying_obsidian
setblock 191 220 200 minecraft:crying_obsidian
setblock 192 220 195 minecraft:crying_obsidian
setblock 192 220 197 minecraft:crying_obsidian
setblock 192 220 199 minecraft:crying_obsidian
setblock 192 220 201 minecraft:crying_obsidian
setblock 193 220 196 minecraft:crying_obsidian
setblock 193 220 198 minecraft:crying_obsidian
setblock 193 220 200 minecraft:crying_obsidian
setblock 194 220 195 minecraft:crying_obsidian
setblock 194 220 197 minecraft:crying_obsidian
setblock 194 220 199 minecraft:crying_obsidian
setblock 194 220 201 minecraft:crying_obsidian
fill 196 220 221 198 225 221 minecraft:polished_deepslate
fill 200 220 183 202 225 183 minecraft:polished_deepslate
fill 208 220 221 210 225 221 minecraft:polished_deepslate
fill 212 220 183 214 225 183 minecraft:polished_deepslate
fill 220 220 221 222 225 221 minecraft:polished_deepslate
fill 224 220 183 226 225 183 minecraft:polished_deepslate
setblock 224 220 207 minecraft:crying_obsidian
setblock 224 220 209 minecraft:crying_obsidian
setblock 224 220 211 minecraft:crying_obsidian
setblock 224 220 213 minecraft:crying_obsidian
setblock 224 220 215 minecraft:crying_obsidian
setblock 224 220 217 minecraft:crying_obsidian
setblock 224 220 219 minecraft:crying_obsidian
setblock 225 220 208 minecraft:crying_obsidian
setblock 225 220 210 minecraft:crying_obsidian
setblock 225 220 212 minecraft:crying_obsidian
setblock 225 220 214 minecraft:crying_obsidian
setblock 225 220 216 minecraft:crying_obsidian
setblock 225 220 218 minecraft:crying_obsidian
setblock 226 220 207 minecraft:crying_obsidian
setblock 226 220 209 minecraft:crying_obsidian
setblock 226 220 211 minecraft:crying_obsidian
setblock 226 220 213 minecraft:crying_obsidian
setblock 226 220 215 minecraft:crying_obsidian
setblock 226 220 217 minecraft:crying_obsidian
setblock 226 220 219 minecraft:crying_obsidian
setblock 227 220 208 minecraft:crying_obsidian
setblock 227 220 210 minecraft:crying_obsidian
setblock 227 220 212 minecraft:crying_obsidian
setblock 227 220 214 minecraft:crying_obsidian
setblock 227 220 216 minecraft:crying_obsidian
setblock 227 220 218 minecraft:crying_obsidian
fill 228 220 191 228 225 193 minecraft:polished_deepslate
fill 228 220 203 228 225 205 minecraft:polished_deepslate
setblock 228 220 207 minecraft:crying_obsidian
setblock 228 220 209 minecraft:crying_obsidian
setblock 228 220 211 minecraft:crying_obsidian
setblock 228 220 213 minecraft:crying_obsidian
setblock 228 220 215 minecraft:crying_obsidian
setblock 228 220 217 minecraft:crying_obsidian
setblock 228 220 219 minecraft:crying_obsidian
setblock 229 220 208 minecraft:crying_obsidian
setblock 229 220 210 minecraft:crying_obsidian
setblock 229 220 212 minecraft:crying_obsidian
setblock 229 220 214 minecraft:crying_obsidian
setblock 229 220 216 minecraft:crying_obsidian
setblock 229 220 218 minecraft:crying_obsidian
fill 189 221 196 189 222 196 minecraft:polished_deepslate
fill 189 221 198 189 222 198 minecraft:polished_deepslate
fill 189 221 200 189 222 200 minecraft:polished_deepslate
fill 190 221 195 190 222 195 minecraft:polished_deepslate
fill 190 221 197 190 222 197 minecraft:polished_deepslate
fill 190 221 199 190 222 199 minecraft:polished_deepslate
fill 190 221 201 190 222 201 minecraft:polished_deepslate
fill 191 221 196 191 222 196 minecraft:polished_deepslate
fill 191 221 198 191 222 198 minecraft:polished_deepslate
fill 191 221 200 191 222 200 minecraft:polished_deepslate
fill 192 221 195 192 222 195 minecraft:polished_deepslate
fill 192 221 197 192 222 197 minecraft:polished_deepslate
fill 192 221 199 192 222 199 minecraft:polished_deepslate
fill 192 221 201 192 222 201 minecraft:polished_deepslate
fill 193 221 196 193 222 196 minecraft:polished_deepslate
fill 193 221 198 193 222 198 minecraft:polished_deepslate
fill 193 221 200 193 222 200 minecraft:polished_deepslate
fill 194 221 195 194 222 195 minecraft:polished_deepslate
fill 194 221 197 194 222 197 minecraft:polished_deepslate
fill 194 221 199 194 222 199 minecraft:polished_deepslate
fill 194 221 201 194 222 201 minecraft:polished_deepslate
fill 224 221 207 224 222 207 minecraft:polished_deepslate
fill 224 221 209 224 222 209 minecraft:polished_deepslate
fill 224 221 211 224 222 211 minecraft:polished_deepslate
fill 224 221 213 224 222 213 minecraft:polished_deepslate
fill 224 221 215 224 222 215 minecraft:polished_deepslate
fill 224 221 217 224 222 217 minecraft:polished_deepslate
fill 224 221 219 224 222 219 minecraft:polished_deepslate
fill 225 221 208 225 222 208 minecraft:polished_deepslate
fill 225 221 210 225 222 210 minecraft:polished_deepslate
fill 225 221 212 225 222 212 minecraft:polished_deepslate
fill 225 221 214 225 222 214 minecraft:polished_deepslate
fill 225 221 216 225 222 216 minecraft:polished_deepslate
fill 225 221 218 225 222 218 minecraft:polished_deepslate
fill 226 221 207 226 222 207 minecraft:polished_deepslate
fill 226 221 209 226 222 209 minecraft:polished_deepslate
fill 226 221 211 226 222 211 minecraft:polished_deepslate
fill 226 221 213 226 222 213 minecraft:polished_deepslate
fill 226 221 215 226 222 215 minecraft:polished_deepslate
fill 226 221 217 226 222 217 minecraft:polished_deepslate
fill 226 221 219 226 222 219 minecraft:polished_deepslate
fill 227 221 208 227 222 208 minecraft:polished_deepslate
fill 227 221 210 227 222 210 minecraft:polished_deepslate
fill 227 221 212 227 222 212 minecraft:polished_deepslate
fill 227 221 214 227 222 214 minecraft:polished_deepslate
fill 227 221 216 227 222 216 minecraft:polished_deepslate
fill 227 221 218 227 222 218 minecraft:polished_deepslate
fill 228 221 207 228 222 207 minecraft:polished_deepslate
fill 228 221 209 228 222 209 minecraft:polished_deepslate
fill 228 221 211 228 222 211 minecraft:polished_deepslate
fill 228 221 213 228 222 213 minecraft:polished_deepslate
fill 228 221 215 228 222 215 minecraft:polished_deepslate
fill 228 221 217 228 222 217 minecraft:polished_deepslate
fill 228 221 219 228 222 219 minecraft:polished_deepslate
fill 229 221 208 229 222 208 minecraft:polished_deepslate
fill 229 221 210 229 222 210 minecraft:polished_deepslate
fill 229 221 212 229 222 212 minecraft:polished_deepslate
fill 229 221 214 229 222 214 minecraft:polished_deepslate
fill 229 221 216 229 222 216 minecraft:polished_deepslate
fill 229 221 218 229 222 218 minecraft:polished_deepslate
setblock 189 223 196 minecraft:crying_obsidian
setblock 189 223 198 minecraft:crying_obsidian
setblock 189 223 200 minecraft:crying_obsidian
setblock 190 223 195 minecraft:crying_obsidian
setblock 190 223 197 minecraft:crying_obsidian
setblock 190 223 199 minecraft:crying_obsidian
setblock 190 223 201 minecraft:crying_obsidian
setblock 191 223 196 minecraft:crying_obsidian
setblock 191 223 198 minecraft:crying_obsidian
setblock 191 223 200 minecraft:crying_obsidian
setblock 192 223 195 minecraft:crying_obsidian
setblock 192 223 197 minecraft:crying_obsidian
setblock 192 223 199 minecraft:crying_obsidian
setblock 192 223 201 minecraft:crying_obsidian
setblock 193 223 196 minecraft:crying_obsidian
setblock 193 223 198 minecraft:crying_obsidian
setblock 193 223 200 minecraft:crying_obsidian
setblock 194 223 195 minecraft:crying_obsidian
setblock 194 223 197 minecraft:crying_obsidian
setblock 194 223 199 minecraft:crying_obsidian
setblock 194 223 201 minecraft:crying_obsidian
setblock 224 223 207 minecraft:crying_obsidian
setblock 224 223 209 minecraft:crying_obsidian
setblock 224 223 211 minecraft:crying_obsidian
setblock 224 223 213 minecraft:crying_obsidian
setblock 224 223 215 minecraft:crying_obsidian
setblock 224 223 217 minecraft:crying_obsidian
setblock 224 223 219 minecraft:crying_obsidian
setblock 225 223 208 minecraft:crying_obsidian
setblock 225 223 210 minecraft:crying_obsidian
setblock 225 223 212 minecraft:crying_obsidian
setblock 225 223 214 minecraft:crying_obsidian
setblock 225 223 216 minecraft:crying_obsidian
setblock 225 223 218 minecraft:crying_obsidian
setblock 226 223 207 minecraft:crying_obsidian
setblock 226 223 209 minecraft:crying_obsidian
setblock 226 223 211 minecraft:crying_obsidian
setblock 226 223 213 minecraft:crying_obsidian
setblock 226 223 215 minecraft:crying_obsidian
setblock 226 223 217 minecraft:crying_obsidian
setblock 226 223 219 minecraft:crying_obsidian
setblock 227 223 208 minecraft:crying_obsidian
setblock 227 223 210 minecraft:crying_obsidian
setblock 227 223 212 minecraft:crying_obsidian
setblock 227 223 214 minecraft:crying_obsidian
setblock 227 223 216 minecraft:crying_obsidian
setblock 227 223 218 minecraft:crying_obsidian
setblock 228 223 207 minecraft:crying_obsidian
setblock 228 223 209 minecraft:crying_obsidian
setblock 228 223 211 minecraft:crying_obsidian
setblock 228 223 213 minecraft:crying_obsidian
setblock 228 223 215 minecraft:crying_obsidian
setblock 228 223 217 minecraft:crying_obsidian
setblock 228 223 219 minecraft:crying_obsidian
setblock 229 223 208 minecraft:crying_obsidian
setblock 229 223 210 minecraft:crying_obsidian
setblock 229 223 212 minecraft:crying_obsidian
setblock 229 223 214 minecraft:crying_obsidian
setblock 229 223 216 minecraft:crying_obsidian
setblock 229 223 218 minecraft:crying_obsidian
fill 189 224 196 189 225 196 minecraft:polished_deepslate
setblock 189 224 198 minecraft:polished_deepslate
setblock 189 224 200 minecraft:polished_deepslate
fill 190 224 195 190 225 195 minecraft:polished_deepslate
fill 190 224 197 190 225 197 minecraft:polished_deepslate
fill 190 224 199 190 225 199 minecraft:polished_deepslate
fill 190 224 201 190 225 201 minecraft:polished_deepslate
fill 190 224 206 190 225 212 minecraft:obsidian
fill 191 224 196 191 225 196 minecraft:polished_deepslate
fill 191 224 198 191 225 198 minecraft:polished_deepslate
fill 191 224 200 191 225 200 minecraft:polished_deepslate
fill 192 224 195 192 225 195 minecraft:polished_deepslate
fill 192 224 197 192 225 197 minecraft:polished_deepslate
fill 192 224 199 192 225 199 minecraft:polished_deepslate
fill 192 224 201 192 225 201 minecraft:polished_deepslate
fill 193 224 196 193 225 196 minecraft:polished_deepslate
fill 193 224 198 193 225 198 minecraft:polished_deepslate
fill 193 224 200 193 225 200 minecraft:polished_deepslate
fill 194 224 195 194 225 195 minecraft:polished_deepslate
fill 194 224 197 194 225 197 minecraft:polished_deepslate
fill 194 224 199 194 225 199 minecraft:polished_deepslate
fill 194 224 201 194 225 201 minecraft:polished_deepslate
fill 224 224 207 224 225 207 minecraft:polished_deepslate
fill 224 224 209 224 225 209 minecraft:polished_deepslate
fill 224 224 211 224 225 211 minecraft:polished_deepslate
fill 224 224 213 224 225 213 minecraft:polished_deepslate
fill 224 224 215 224 225 215 minecraft:polished_deepslate
fill 224 224 217 224 225 217 minecraft:polished_deepslate
fill 224 224 219 224 225 219 minecraft:polished_deepslate
fill 225 224 208 225 225 208 minecraft:polished_deepslate
fill 225 224 210 225 225 210 minecraft:polished_deepslate
fill 225 224 212 225 225 212 minecraft:polished_deepslate
fill 225 224 214 225 225 214 minecraft:polished_deepslate
fill 225 224 216 225 225 216 minecraft:polished_deepslate
fill 225 224 218 225 225 218 minecraft:polished_deepslate
fill 226 224 207 226 225 207 minecraft:polished_deepslate
fill 226 224 209 226 225 209 minecraft:polished_deepslate
fill 226 224 211 226 225 211 minecraft:polished_deepslate
fill 226 224 213 226 225 213 minecraft:polished_deepslate
fill 226 224 215 226 225 215 minecraft:polished_deepslate
fill 226 224 217 226 225 217 minecraft:polished_deepslate
fill 226 224 219 226 225 219 minecraft:polished_deepslate
fill 227 224 208 227 225 208 minecraft:polished_deepslate
fill 227 224 210 227 225 210 minecraft:polished_deepslate
fill 227 224 212 227 225 212 minecraft:polished_deepslate
fill 227 224 214 227 225 214 minecraft:polished_deepslate
fill 227 224 216 227 225 216 minecraft:polished_deepslate
fill 227 224 218 227 225 218 minecraft:polished_deepslate
fill 228 224 207 228 225 207 minecraft:polished_deepslate
fill 228 224 209 228 225 209 minecraft:polished_deepslate
fill 228 224 211 228 225 211 minecraft:polished_deepslate
fill 228 224 213 228 225 213 minecraft:polished_deepslate
fill 228 224 215 228 225 215 minecraft:polished_deepslate
fill 228 224 217 228 225 217 minecraft:polished_deepslate
fill 228 224 219 228 225 219 minecraft:polished_deepslate
setblock 229 224 208 minecraft:polished_deepslate
setblock 229 224 210 minecraft:polished_deepslate
fill 229 224 212 229 225 212 minecraft:polished_deepslate
fill 229 224 214 229 225 214 minecraft:polished_deepslate
fill 229 224 216 229 225 216 minecraft:polished_deepslate
setblock 229 224 218 minecraft:polished_deepslate
fill 189 225 185 189 225 190 minecraft:obsidian
fill 189 225 197 189 225 202 minecraft:obsidian
fill 189 225 209 189 225 214 minecraft:obsidian
fill 189 225 221 189 225 222 minecraft:obsidian
fill 190 225 222 193 225 222 minecraft:obsidian
fill 193 225 182 198 225 182 minecraft:obsidian
fill 200 225 222 205 225 222 minecraft:obsidian
fill 205 225 182 210 225 182 minecraft:obsidian
fill 212 225 222 217 225 222 minecraft:obsidian
fill 217 225 182 222 225 182 minecraft:obsidian
fill 224 225 222 229 225 222 minecraft:obsidian
fill 229 225 182 229 225 187 minecraft:obsidian
fill 229 225 194 229 225 199 minecraft:obsidian
fill 229 225 206 229 225 211 minecraft:obsidian
fill 229 225 218 229 225 221 minecraft:obsidian
fill 188 226 187 188 227 190 minecraft:crying_obsidian
fill 188 226 199 188 227 202 minecraft:crying_obsidian
fill 188 226 211 188 227 214 minecraft:crying_obsidian
fill 188 226 223 191 227 223 minecraft:crying_obsidian
setblock 189 226 196 minecraft:crying_obsidian
fill 189 226 197 189 227 197 minecraft:polished_deepslate
setblock 189 226 198 minecraft:crying_obsidian
fill 189 226 199 189 227 199 minecraft:polished_deepslate
setblock 189 226 200 minecraft:crying_obsidian
fill 189 226 201 189 227 201 minecraft:polished_deepslate
setblock 190 226 195 minecraft:crying_obsidian
setblock 190 226 197 minecraft:crying_obsidian
setblock 190 226 199 minecraft:crying_obsidian
setblock 190 226 201 minecraft:crying_obsidian
setblock 191 226 184 minecraft:light[level=12]
setblock 191 226 192 minecraft:light[level=12]
setblock 191 226 196 minecraft:crying_obsidian
setblock 191 226 198 minecraft:crying_obsidian
setblock 191 226 200 minecraft:crying_obsidian
setblock 191 226 208 minecraft:light[level=12]
setblock 191 226 216 minecraft:light[level=12]
setblock 192 226 195 minecraft:crying_obsidian
setblock 192 226 197 minecraft:crying_obsidian
setblock 192 226 199 minecraft:crying_obsidian
setblock 192 226 201 minecraft:crying_obsidian
setblock 193 226 196 minecraft:crying_obsidian
setblock 193 226 198 minecraft:crying_obsidian
setblock 193 226 200 minecraft:crying_obsidian
setblock 194 226 195 minecraft:crying_obsidian
setblock 194 226 197 minecraft:crying_obsidian
setblock 194 226 199 minecraft:crying_obsidian
setblock 194 226 201 minecraft:crying_obsidian
fill 195 226 181 198 227 181 minecraft:crying_obsidian
setblock 199 226 184 minecraft:light[level=12]
setblock 199 226 192 minecraft:light[level=12]
setblock 199 226 200 minecraft:light[level=12]
setblock 199 226 208 minecraft:light[level=12]
setblock 199 226 216 minecraft:light[level=12]
fill 200 226 223 203 227 223 minecraft:crying_obsidian
fill 207 226 181 210 227 181 minecraft:crying_obsidian
setblock 207 226 184 minecraft:light[level=12]
setblock 207 226 192 minecraft:light[level=12]
setblock 207 226 200 minecraft:light[level=12]
setblock 207 226 208 minecraft:light[level=12]
setblock 207 226 216 minecraft:light[level=12]
fill 212 226 223 215 227 223 minecraft:crying_obsidian
setblock 215 226 184 minecraft:light[level=12]
setblock 215 226 192 minecraft:light[level=12]
setblock 215 226 200 minecraft:light[level=12]
setblock 215 226 208 minecraft:light[level=12]
setblock 215 226 216 minecraft:light[level=12]
fill 219 226 181 222 227 181 minecraft:crying_obsidian
setblock 223 226 184 minecraft:light[level=12]
setblock 223 226 192 minecraft:light[level=12]
setblock 223 226 200 minecraft:light[level=12]
setblock 223 226 208 minecraft:light[level=12]
setblock 223 226 216 minecraft:light[level=12]
setblock 224 226 207 minecraft:crying_obsidian
setblock 224 226 209 minecraft:crying_obsidian
setblock 224 226 211 minecraft:crying_obsidian
setblock 224 226 213 minecraft:crying_obsidian
setblock 224 226 215 minecraft:crying_obsidian
setblock 224 226 217 minecraft:crying_obsidian
setblock 224 226 219 minecraft:crying_obsidian
fill 224 226 223 227 227 223 minecraft:crying_obsidian
setblock 225 226 208 minecraft:crying_obsidian
setblock 225 226 210 minecraft:crying_obsidian
setblock 225 226 212 minecraft:crying_obsidian
setblock 225 226 214 minecraft:crying_obsidian
setblock 225 226 216 minecraft:crying_obsidian
setblock 225 226 218 minecraft:crying_obsidian
setblock 226 226 207 minecraft:crying_obsidian
setblock 226 226 209 minecraft:crying_obsidian
setblock 226 226 211 minecraft:crying_obsidian
setblock 226 226 213 minecraft:crying_obsidian
setblock 226 226 215 minecraft:crying_obsidian
setblock 226 226 217 minecraft:crying_obsidian
setblock 226 226 219 minecraft:crying_obsidian
setblock 227 226 208 minecraft:crying_obsidian
setblock 227 226 210 minecraft:crying_obsidian
setblock 227 226 212 minecraft:crying_obsidian
setblock 227 226 214 minecraft:crying_obsidian
setblock 227 226 216 minecraft:crying_obsidian
setblock 227 226 218 minecraft:crying_obsidian
setblock 228 226 207 minecraft:crying_obsidian
setblock 228 226 209 minecraft:crying_obsidian
setblock 228 226 211 minecraft:crying_obsidian
setblock 228 226 213 minecraft:crying_obsidian
setblock 228 226 215 minecraft:crying_obsidian
setblock 228 226 217 minecraft:crying_obsidian
setblock 228 226 219 minecraft:crying_obsidian
fill 229 226 207 229 227 207 minecraft:polished_deepslate
fill 229 226 208 230 226 208 minecraft:crying_obsidian
fill 229 226 209 229 227 209 minecraft:polished_deepslate
setblock 229 226 210 minecraft:crying_obsidian
fill 229 226 211 229 227 211 minecraft:polished_deepslate
setblock 229 226 212 minecraft:crying_obsidian
setblock 229 226 214 minecraft:crying_obsidian
setblock 229 226 216 minecraft:crying_obsidian
fill 229 226 218 230 226 218 minecraft:crying_obsidian
fill 229 226 219 229 227 219 minecraft:polished_deepslate
fill 230 226 182 230 227 185 minecraft:crying_obsidian
fill 230 226 194 230 227 197 minecraft:crying_obsidian
fill 230 226 206 230 227 207 minecraft:crying_obsidian
fill 230 226 209 230 227 209 minecraft:crying_obsidian
fill 230 226 219 230 227 221 minecraft:crying_obsidian
setblock 189 227 196 minecraft:polished_deepslate
setblock 189 227 198 minecraft:polished_deepslate
setblock 189 227 200 minecraft:polished_deepslate
setblock 190 227 195 minecraft:polished_deepslate
setblock 190 227 197 minecraft:polished_deepslate
setblock 190 227 199 minecraft:polished_deepslate
setblock 190 227 201 minecraft:polished_deepslate
setblock 191 227 196 minecraft:polished_deepslate
setblock 191 227 198 minecraft:polished_deepslate
setblock 191 227 200 minecraft:polished_deepslate
setblock 192 227 195 minecraft:polished_deepslate
setblock 192 227 197 minecraft:polished_deepslate
setblock 192 227 199 minecraft:polished_deepslate
setblock 192 227 201 minecraft:polished_deepslate
setblock 193 227 196 minecraft:polished_deepslate
setblock 193 227 198 minecraft:polished_deepslate
setblock 193 227 200 minecraft:polished_deepslate
setblock 194 227 195 minecraft:polished_deepslate
setblock 194 227 197 minecraft:polished_deepslate
setblock 194 227 199 minecraft:polished_deepslate
setblock 194 227 201 minecraft:polished_deepslate
setblock 224 227 207 minecraft:polished_deepslate
setblock 224 227 209 minecraft:polished_deepslate
setblock 224 227 211 minecraft:polished_deepslate
setblock 224 227 213 minecraft:polished_deepslate
setblock 224 227 215 minecraft:polished_deepslate
setblock 224 227 217 minecraft:polished_deepslate
setblock 224 227 219 minecraft:polished_deepslate
setblock 225 227 208 minecraft:polished_deepslate
setblock 225 227 210 minecraft:polished_deepslate
setblock 225 227 212 minecraft:polished_deepslate
setblock 225 227 214 minecraft:polished_deepslate
setblock 225 227 216 minecraft:polished_deepslate
setblock 225 227 218 minecraft:polished_deepslate
setblock 226 227 207 minecraft:polished_deepslate
setblock 226 227 209 minecraft:polished_deepslate
setblock 226 227 211 minecraft:polished_deepslate
setblock 226 227 213 minecraft:polished_deepslate
setblock 226 227 215 minecraft:polished_deepslate
setblock 226 227 217 minecraft:polished_deepslate
setblock 226 227 219 minecraft:polished_deepslate
setblock 227 227 208 minecraft:polished_deepslate
setblock 227 227 210 minecraft:polished_deepslate
setblock 227 227 212 minecraft:polished_deepslate
setblock 227 227 214 minecraft:polished_deepslate
setblock 227 227 216 minecraft:polished_deepslate
setblock 227 227 218 minecraft:polished_deepslate
setblock 228 227 207 minecraft:polished_deepslate
setblock 228 227 209 minecraft:polished_deepslate
setblock 228 227 211 minecraft:polished_deepslate
setblock 228 227 213 minecraft:polished_deepslate
setblock 228 227 215 minecraft:polished_deepslate
setblock 228 227 217 minecraft:polished_deepslate
setblock 228 227 219 minecraft:polished_deepslate
setblock 229 227 208 minecraft:polished_deepslate
setblock 229 227 210 minecraft:polished_deepslate
setblock 229 227 212 minecraft:polished_deepslate
setblock 229 227 214 minecraft:polished_deepslate
setblock 229 227 216 minecraft:polished_deepslate
setblock 229 227 218 minecraft:polished_deepslate
setblock 230 227 208 minecraft:crying_obsidian
setblock 230 227 218 minecraft:crying_obsidian
fill 188 228 187 188 245 190 minecraft:deepslate_bricks
fill 188 228 199 188 245 202 minecraft:deepslate_bricks
fill 188 228 211 188 245 214 minecraft:deepslate_bricks
fill 188 228 223 191 245 223 minecraft:deepslate_bricks
fill 195 228 181 198 245 181 minecraft:deepslate_bricks
fill 200 228 223 203 245 223 minecraft:deepslate_bricks
fill 207 228 181 210 245 181 minecraft:deepslate_bricks
fill 212 228 223 215 245 223 minecraft:deepslate_bricks
fill 219 228 181 222 245 181 minecraft:deepslate_bricks
fill 224 228 223 227 245 223 minecraft:deepslate_bricks
fill 230 228 182 230 245 185 minecraft:deepslate_bricks
fill 230 228 194 230 245 197 minecraft:deepslate_bricks
fill 230 228 206 230 245 209 minecraft:deepslate_bricks
fill 230 228 218 230 245 221 minecraft:deepslate_bricks
fill 194 233 188 195 233 216 minecraft:obsidian
fill 196 233 188 222 233 189 minecraft:obsidian
fill 196 233 190 204 233 214 minecraft:black_concrete
fill 196 233 215 222 233 216 minecraft:obsidian
fill 205 233 190 205 233 201 minecraft:black_concrete
fill 205 233 203 205 233 214 minecraft:black_concrete
fill 206 233 190 207 233 199 minecraft:black_concrete
fill 206 233 205 207 233 214 minecraft:black_concrete
fill 208 233 190 220 233 198 minecraft:black_concrete
fill 208 233 206 220 233 214 minecraft:black_concrete
fill 209 233 199 220 233 199 minecraft:black_concrete
fill 209 233 205 220 233 205 minecraft:black_concrete
fill 211 233 200 220 233 201 minecraft:black_concrete
fill 211 233 203 220 233 204 minecraft:black_concrete
fill 212 233 202 220 233 202 minecraft:black_concrete
fill 221 233 190 222 233 214 minecraft:obsidian
fill 189 234 182 193 234 222 minecraft:polished_deepslate
fill 194 234 182 229 234 187 minecraft:polished_deepslate
fill 194 234 188 194 234 190 minecraft:obsidian
setblock 194 234 191 minecraft:crying_obsidian
fill 194 234 192 194 234 194 minecraft:obsidian
setblock 194 234 195 minecraft:crying_obsidian
fill 194 234 196 194 234 198 minecraft:obsidian
setblock 194 234 199 minecraft:crying_obsidian
fill 194 234 200 194 234 202 minecraft:obsidian
setblock 194 234 203 minecraft:crying_obsidian
fill 194 234 204 194 234 206 minecraft:obsidian
setblock 194 234 207 minecraft:crying_obsidian
fill 194 234 208 194 234 210 minecraft:obsidian
setblock 194 234 211 minecraft:crying_obsidian
fill 194 234 212 194 234 214 minecraft:obsidian
setblock 194 234 215 minecraft:crying_obsidian
fill 194 234 216 196 234 216 minecraft:obsidian
fill 194 234 217 229 234 222 minecraft:polished_deepslate
fill 195 234 188 195 238 189 minecraft:obsidian
setblock 195 234 190 minecraft:crying_obsidian
fill 195 234 191 195 234 193 minecraft:obsidian
setblock 195 234 194 minecraft:crying_obsidian
fill 195 234 195 195 234 197 minecraft:obsidian
setblock 195 234 198 minecraft:crying_obsidian
fill 195 234 199 195 234 201 minecraft:obsidian
setblock 195 234 202 minecraft:crying_obsidian
fill 195 234 203 195 234 205 minecraft:obsidian
setblock 195 234 206 minecraft:crying_obsidian
fill 195 234 207 195 234 209 minecraft:obsidian
setblock 195 234 210 minecraft:crying_obsidian
fill 195 234 211 195 234 213 minecraft:obsidian
setblock 195 234 214 minecraft:crying_obsidian
fill 195 234 215 197 234 215 minecraft:obsidian
setblock 196 234 188 minecraft:obsidian
setblock 196 234 189 minecraft:crying_obsidian
fill 196 234 190 203 234 214 minecraft:black_concrete
setblock 197 234 188 minecraft:crying_obsidian
fill 197 234 189 199 234 189 minecraft:obsidian
setblock 197 234 216 minecraft:crying_obsidian
fill 198 234 188 200 234 188 minecraft:obsidian
setblock 198 234 215 minecraft:crying_obsidian
fill 198 234 216 200 234 216 minecraft:obsidian
fill 199 234 215 201 234 215 minecraft:obsidian
setblock 200 234 189 minecraft:crying_obsidian
setblock 201 234 188 minecraft:crying_obsidian
fill 201 234 189 203 234 189 minecraft:obsidian
setblock 201 234 216 minecraft:crying_obsidian
fill 202 234 188 204 234 188 minecraft:obsidian
setblock 202 234 215 minecraft:crying_obsidian
fill 202 234 216 204 234 216 minecraft:obsidian
fill 203 234 215 205 234 215 minecraft:obsidian
setblock 204 234 189 minecraft:crying_obsidian
fill 204 234 190 204 234 200 minecraft:black_concrete
fill 204 234 201 204 234 203 minecraft:crying_obsidian
fill 204 234 204 204 234 214 minecraft:black_concrete
setblock 205 234 188 minecraft:crying_obsidian
fill 205 234 189 207 234 189 minecraft:obsidian
fill 205 234 190 206 234 198 minecraft:black_concrete
fill 205 234 199 205 234 201 minecraft:crying_obsidian
fill 205 234 203 205 234 205 minecraft:crying_obsidian
fill 205 234 206 206 234 214 minecraft:black_concrete
setblock 205 234 216 minecraft:crying_obsidian
fill 206 234 188 208 234 188 minecraft:obsidian
fill 206 234 199 207 234 199 minecraft:crying_obsidian
fill 206 234 205 207 234 205 minecraft:crying_obsidian
setblock 206 234 215 minecraft:crying_obsidian
fill 206 234 216 208 234 216 minecraft:obsidian
fill 207 234 190 220 234 197 minecraft:black_concrete
fill 207 234 198 209 234 198 minecraft:crying_obsidian
fill 207 234 206 209 234 206 minecraft:crying_obsidian
fill 207 234 207 220 234 214 minecraft:black_concrete
fill 207 234 215 209 234 215 minecraft:obsidian
setblock 208 234 189 minecraft:crying_obsidian
setblock 209 234 188 minecraft:crying_obsidian
fill 209 234 189 211 234 189 minecraft:obsidian
fill 209 234 199 211 234 199 minecraft:crying_obsidian
fill 209 234 205 211 234 205 minecraft:crying_obsidian
setblock 209 234 216 minecraft:crying_obsidian
fill 210 234 188 212 234 188 minecraft:obsidian
fill 210 234 198 220 234 198 minecraft:black_concrete
fill 210 234 206 220 234 206 minecraft:black_concrete
setblock 210 234 215 minecraft:crying_obsidian
fill 210 234 216 212 234 216 minecraft:obsidian
fill 211 234 200 211 234 201 minecraft:crying_obsidian
fill 211 234 203 211 234 204 minecraft:crying_obsidian
fill 211 234 215 213 234 215 minecraft:obsidian
setblock 212 234 189 minecraft:crying_obsidian
fill 212 234 199 220 234 200 minecraft:black_concrete
fill 212 234 201 212 234 203 minecraft:crying_obsidian
fill 212 234 204 220 234 205 minecraft:black_concrete
setblock 213 234 188 minecraft:crying_obsidian
fill 213 234 189 215 234 189 minecraft:obsidian
fill 213 234 201 220 234 203 minecraft:black_concrete
setblock 213 234 216 minecraft:crying_obsidian
fill 214 234 188 216 234 188 minecraft:obsidian
setblock 214 234 215 minecraft:crying_obsidian
fill 214 234 216 216 234 216 minecraft:obsidian
fill 215 234 215 217 234 215 minecraft:obsidian
setblock 216 234 189 minecraft:crying_obsidian
setblock 217 234 188 minecraft:crying_obsidian
fill 217 234 189 219 234 189 minecraft:obsidian
setblock 217 234 216 minecraft:crying_obsidian
fill 218 234 188 220 234 188 minecraft:obsidian
setblock 218 234 215 minecraft:crying_obsidian
fill 218 234 216 220 234 216 minecraft:obsidian
fill 219 234 215 221 234 215 minecraft:obsidian
setblock 220 234 189 minecraft:crying_obsidian
setblock 221 234 188 minecraft:crying_obsidian
fill 221 234 189 221 234 191 minecraft:obsidian
setblock 221 234 192 minecraft:crying_obsidian
fill 221 234 193 221 234 195 minecraft:obsidian
setblock 221 234 196 minecraft:crying_obsidian
fill 221 234 197 221 234 199 minecraft:obsidian
setblock 221 234 200 minecraft:crying_obsidian
fill 221 234 201 221 234 203 minecraft:obsidian
setblock 221 234 204 minecraft:crying_obsidian
fill 221 234 205 221 234 207 minecraft:obsidian
setblock 221 234 208 minecraft:crying_obsidian
fill 221 234 209 221 234 211 minecraft:obsidian
setblock 221 234 212 minecraft:crying_obsidian
fill 221 234 213 222 234 214 minecraft:obsidian
setblock 221 234 216 minecraft:crying_obsidian
fill 222 234 188 222 234 190 minecraft:obsidian
setblock 222 234 191 minecraft:crying_obsidian
fill 222 234 192 222 234 194 minecraft:obsidian
setblock 222 234 195 minecraft:crying_obsidian
fill 222 234 196 222 234 198 minecraft:obsidian
setblock 222 234 199 minecraft:crying_obsidian
fill 222 234 200 222 234 202 minecraft:obsidian
setblock 222 234 203 minecraft:crying_obsidian
fill 222 234 204 222 234 206 minecraft:obsidian
setblock 222 234 207 minecraft:crying_obsidian
fill 222 234 208 222 234 210 minecraft:obsidian
setblock 222 234 211 minecraft:crying_obsidian
setblock 222 234 212 minecraft:obsidian
setblock 222 234 215 minecraft:crying_obsidian
setblock 222 234 216 minecraft:obsidian
fill 223 234 188 229 234 216 minecraft:polished_deepslate
fill 194 235 189 194 238 189 minecraft:obsidian
fill 194 235 215 196 238 215 minecraft:obsidian
fill 195 235 190 195 238 190 minecraft:obsidian
fill 195 235 214 195 238 214 minecraft:obsidian
fill 195 235 216 195 238 216 minecraft:obsidian
fill 196 235 189 196 238 189 minecraft:obsidian
fill 220 235 189 222 238 189 minecraft:obsidian
fill 220 235 215 222 238 215 minecraft:obsidian
fill 221 235 188 221 238 188 minecraft:obsidian
fill 221 235 190 221 238 190 minecraft:obsidian
fill 221 235 214 221 238 214 minecraft:obsidian
fill 221 235 216 221 238 216 minecraft:obsidian
fill 189 238 182 191 271 182 minecraft:polished_deepslate
fill 189 238 192 189 271 194 minecraft:polished_deepslate
fill 189 238 204 189 271 206 minecraft:polished_deepslate
fill 189 238 216 189 271 218 minecraft:polished_deepslate
fill 195 238 222 197 271 222 minecraft:polished_deepslate
fill 201 238 182 203 271 182 minecraft:polished_deepslate
fill 207 238 222 209 271 222 minecraft:polished_deepslate
fill 213 238 182 215 271 182 minecraft:polished_deepslate
fill 219 238 222 221 271 222 minecraft:polished_deepslate
fill 225 238 182 227 271 182 minecraft:polished_deepslate
fill 229 238 190 229 271 192 minecraft:polished_deepslate
fill 229 238 202 229 255 204 minecraft:polished_deepslate
fill 229 238 214 229 271 216 minecraft:polished_deepslate
fill 190 240 191 190 245 193 minecraft:polished_deepslate
fill 190 240 203 190 245 205 minecraft:polished_deepslate
fill 190 240 215 190 245 217 minecraft:polished_deepslate
fill 196 240 221 198 245 221 minecraft:polished_deepslate
fill 200 240 183 202 245 183 minecraft:polished_deepslate
fill 208 240 221 210 245 221 minecraft:polished_deepslate
fill 212 240 183 214 245 183 minecraft:polished_deepslate
fill 220 240 221 222 245 221 minecraft:polished_deepslate
fill 224 240 183 226 245 183 minecraft:polished_deepslate
fill 228 240 191 228 245 193 minecraft:polished_deepslate
fill 228 240 203 228 245 205 minecraft:polished_deepslate
fill 228 240 215 228 245 217 minecraft:polished_deepslate
setblock 191 242 184 minecraft:light[level=12]
setblock 191 242 192 minecraft:light[level=12]
setblock 191 242 200 minecraft:light[level=12]
setblock 191 242 208 minecraft:light[level=12]
setblock 191 242 216 minecraft:light[level=12]
setblock 199 242 184 minecraft:light[level=12]
setblock 199 242 192 minecraft:light[level=12]
setblock 199 242 200 minecraft:light[level=12]
setblock 199 242 208 minecraft:light[level=12]
setblock 199 242 216 minecraft:light[level=12]
setblock 207 242 184 minecraft:light[level=12]
setblock 207 242 192 minecraft:light[level=12]
setblock 207 242 200 minecraft:light[level=12]
setblock 207 242 208 minecraft:light[level=12]
setblock 207 242 216 minecraft:light[level=12]
setblock 215 242 184 minecraft:light[level=12]
setblock 215 242 192 minecraft:light[level=12]
setblock 215 242 200 minecraft:light[level=12]
setblock 215 242 208 minecraft:light[level=12]
setblock 215 242 216 minecraft:light[level=12]
setblock 223 242 184 minecraft:light[level=12]
setblock 223 242 192 minecraft:light[level=12]
setblock 223 242 200 minecraft:light[level=12]
setblock 223 242 208 minecraft:light[level=12]
setblock 223 242 216 minecraft:light[level=12]
fill 189 245 185 189 245 190 minecraft:obsidian
fill 189 245 197 189 245 202 minecraft:obsidian
fill 189 245 209 189 245 214 minecraft:obsidian
fill 189 245 221 189 245 222 minecraft:obsidian
fill 190 245 222 193 245 222 minecraft:obsidian
fill 193 245 182 198 245 182 minecraft:obsidian
fill 200 245 222 205 245 222 minecraft:obsidian
fill 205 245 182 210 245 182 minecraft:obsidian
fill 212 245 222 217 245 222 minecraft:obsidian
fill 217 245 182 222 245 182 minecraft:obsidian
fill 224 245 222 229 245 222 minecraft:obsidian
fill 229 245 182 229 245 187 minecraft:obsidian
fill 229 245 194 229 245 199 minecraft:obsidian
fill 229 245 206 229 245 211 minecraft:obsidian
fill 229 245 218 229 245 221 minecraft:obsidian
fill 188 246 187 188 251 190 minecraft:crying_obsidian
fill 188 246 199 188 251 202 minecraft:crying_obsidian
fill 188 246 211 188 251 214 minecraft:crying_obsidian
fill 188 246 223 191 251 223 minecraft:crying_obsidian
fill 195 246 181 198 251 181 minecraft:crying_obsidian
fill 200 246 223 203 251 223 minecraft:crying_obsidian
fill 207 246 181 210 251 181 minecraft:crying_obsidian
fill 212 246 223 215 251 223 minecraft:crying_obsidian
fill 219 246 181 222 251 181 minecraft:crying_obsidian
fill 224 246 223 227 251 223 minecraft:crying_obsidian
fill 230 246 182 230 251 185 minecraft:crying_obsidian
fill 230 246 194 230 251 197 minecraft:crying_obsidian
fill 230 246 206 230 251 209 minecraft:crying_obsidian
fill 230 246 218 230 251 221 minecraft:crying_obsidian
fill 224 247 202 224 252 202 minecraft:purple_concrete
fill 224 249 201 224 252 201 minecraft:purple_concrete
fill 224 249 203 224 252 203 minecraft:purple_concrete
fill 225 249 202 225 252 202 minecraft:purple_concrete
setblock 191 250 184 minecraft:light[level=12]
setblock 191 250 192 minecraft:light[level=12]
setblock 191 250 200 minecraft:light[level=12]
setblock 191 250 208 minecraft:light[level=12]
setblock 191 250 216 minecraft:light[level=12]
setblock 199 250 184 minecraft:light[level=12]
setblock 199 250 192 minecraft:light[level=12]
setblock 199 250 200 minecraft:light[level=12]
setblock 199 250 208 minecraft:light[level=12]
setblock 199 250 216 minecraft:light[level=12]
setblock 207 250 184 minecraft:light[level=12]
setblock 207 250 192 minecraft:light[level=12]
setblock 207 250 200 minecraft:light[level=12]
schedule function dropper:buildpart/40_2 1t
