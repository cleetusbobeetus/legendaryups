setblock 461 125 268 minecraft:light_blue_concrete
setblock 461 125 269 minecraft:white_concrete
setblock 462 125 265 minecraft:light_blue_concrete
setblock 462 125 266 minecraft:white_concrete
setblock 463 125 268 minecraft:light_blue_concrete
setblock 463 125 269 minecraft:white_concrete
setblock 464 125 266 minecraft:white_concrete
fill 465 125 264 465 128 264 minecraft:black_concrete
setblock 423 126 249 minecraft:ochre_froglight
setblock 430 126 270 minecraft:purple_terracotta
fill 441 126 228 441 204 228 minecraft:black_concrete
fill 445 126 266 445 127 266 minecraft:iron_bars
fill 450 126 228 450 189 228 minecraft:black_concrete
setblock 460 126 270 minecraft:pearlescent_froglight
setblock 465 126 253 minecraft:ochre_froglight
fill 423 127 249 423 166 249 minecraft:black_concrete
setblock 423 127 251 minecraft:ochre_froglight
setblock 425 127 270 minecraft:purple_terracotta
fill 430 127 270 430 151 270 minecraft:black_concrete
fill 436 127 232 436 128 232 minecraft:iron_bars
fill 437 127 246 438 128 247 minecraft:andesite
fill 460 127 270 460 130 270 minecraft:black_concrete
fill 465 127 253 465 201 253 minecraft:black_concrete
fill 423 128 251 423 135 251 minecraft:black_concrete
setblock 423 128 256 minecraft:ochre_froglight
fill 425 128 270 425 217 270 minecraft:black_concrete
setblock 436 128 228 minecraft:white_concrete
setblock 439 128 246 minecraft:andesite
setblock 447 128 228 minecraft:pearlescent_froglight
setblock 465 128 265 minecraft:sea_lantern
setblock 423 129 234 minecraft:pearlescent_froglight
fill 423 129 256 423 175 256 minecraft:black_concrete
setblock 426 129 231 minecraft:light[level=15]
setblock 426 129 239 minecraft:light[level=15]
setblock 426 129 247 minecraft:light[level=15]
setblock 426 129 255 minecraft:light[level=15]
setblock 426 129 263 minecraft:light[level=15]
setblock 434 129 231 minecraft:light[level=15]
setblock 434 129 239 minecraft:light[level=15]
setblock 434 129 247 minecraft:light[level=15]
setblock 434 129 255 minecraft:light[level=15]
setblock 434 129 263 minecraft:light[level=15]
fill 436 129 228 436 154 228 minecraft:black_concrete
fill 439 129 263 440 130 263 minecraft:end_stone
setblock 440 129 228 minecraft:white_concrete
setblock 442 129 231 minecraft:light[level=15]
setblock 442 129 239 minecraft:light[level=15]
setblock 442 129 247 minecraft:light[level=15]
setblock 442 129 255 minecraft:light[level=15]
setblock 442 129 263 minecraft:light[level=15]
fill 447 129 228 447 260 228 minecraft:black_concrete
setblock 450 129 231 minecraft:light[level=15]
setblock 450 129 239 minecraft:light[level=15]
setblock 450 129 247 minecraft:light[level=15]
setblock 450 129 255 minecraft:light[level=15]
setblock 450 129 263 minecraft:light[level=15]
setblock 458 129 231 minecraft:light[level=15]
setblock 458 129 239 minecraft:light[level=15]
setblock 458 129 247 minecraft:light[level=15]
setblock 458 129 255 minecraft:light[level=15]
setblock 458 129 263 minecraft:light[level=15]
setblock 465 129 264 minecraft:sea_lantern
fill 465 129 265 465 132 265 minecraft:black_concrete
fill 423 130 234 423 149 234 minecraft:black_concrete
setblock 426 130 231 minecraft:light[level=12]
setblock 426 130 238 minecraft:light[level=12]
setblock 426 130 245 minecraft:light[level=12]
setblock 426 130 252 minecraft:light[level=12]
setblock 426 130 259 minecraft:light[level=12]
setblock 426 130 266 minecraft:light[level=12]
setblock 433 130 231 minecraft:light[level=12]
setblock 433 130 238 minecraft:light[level=12]
setblock 433 130 245 minecraft:light[level=12]
setblock 433 130 252 minecraft:light[level=12]
setblock 433 130 259 minecraft:light[level=12]
setblock 433 130 266 minecraft:light[level=12]
setblock 434 130 228 minecraft:pearlescent_froglight
setblock 438 130 270 minecraft:pearlescent_froglight
fill 440 130 228 440 235 228 minecraft:black_concrete
setblock 440 130 231 minecraft:light[level=12]
setblock 440 130 238 minecraft:light[level=12]
setblock 440 130 245 minecraft:light[level=12]
setblock 440 130 252 minecraft:light[level=12]
setblock 440 130 259 minecraft:light[level=12]
setblock 440 130 266 minecraft:light[level=12]
setblock 447 130 231 minecraft:light[level=12]
setblock 447 130 238 minecraft:light[level=12]
setblock 447 130 245 minecraft:light[level=12]
setblock 447 130 252 minecraft:light[level=12]
setblock 447 130 259 minecraft:light[level=12]
setblock 447 130 266 minecraft:light[level=12]
setblock 454 130 231 minecraft:light[level=12]
setblock 454 130 238 minecraft:light[level=12]
setblock 454 130 245 minecraft:light[level=12]
setblock 454 130 252 minecraft:light[level=12]
setblock 454 130 259 minecraft:light[level=12]
setblock 454 130 266 minecraft:light[level=12]
setblock 458 130 228 minecraft:ochre_froglight
setblock 461 130 231 minecraft:light[level=12]
setblock 461 130 238 minecraft:light[level=12]
setblock 461 130 245 minecraft:light[level=12]
setblock 461 130 252 minecraft:light[level=12]
setblock 461 130 259 minecraft:light[level=12]
setblock 461 130 266 minecraft:light[level=12]
setblock 462 130 270 minecraft:pearlescent_froglight
setblock 465 130 236 minecraft:sea_lantern
setblock 465 130 237 minecraft:purple_terracotta
setblock 465 130 254 minecraft:pearlescent_froglight
fill 465 130 264 465 133 264 minecraft:black_concrete
fill 434 131 228 434 252 228 minecraft:black_concrete
fill 438 131 270 438 133 270 minecraft:black_concrete
setblock 453 131 270 minecraft:white_concrete
fill 456 131 257 456 132 257 minecraft:pearlescent_froglight
fill 458 131 228 458 195 228 minecraft:black_concrete
fill 460 131 228 460 304 228 minecraft:black_concrete
setblock 460 131 270 minecraft:pearlescent_froglight
setblock 461 131 228 minecraft:ochre_froglight
fill 462 131 270 462 137 270 minecraft:black_concrete
fill 465 131 236 465 154 237 minecraft:black_concrete
fill 465 131 254 465 155 254 minecraft:black_concrete
setblock 465 131 262 minecraft:ochre_froglight
setblock 452 132 270 minecraft:ochre_froglight
fill 453 132 270 453 148 270 minecraft:black_concrete
fill 460 132 270 460 208 270 minecraft:black_concrete
fill 461 132 228 461 139 228 minecraft:black_concrete
setblock 465 132 258 minecraft:pearlescent_froglight
fill 465 132 262 465 135 262 minecraft:black_concrete
setblock 465 132 263 minecraft:blue_concrete
setblock 450 133 270 minecraft:ochre_froglight
fill 452 133 270 452 145 270 minecraft:black_concrete
fill 456 133 257 456 143 257 minecraft:gray_concrete
fill 465 133 258 465 181 258 minecraft:black_concrete
fill 465 133 263 465 134 263 minecraft:black_concrete
setblock 465 133 265 minecraft:pearlescent_froglight
setblock 423 134 232 minecraft:pearlescent_froglight
setblock 423 134 260 minecraft:ochre_froglight
setblock 432 134 270 minecraft:ochre_froglight
setblock 438 134 270 minecraft:pearlescent_froglight
fill 450 134 270 450 223 270 minecraft:black_concrete
setblock 462 134 228 minecraft:sea_lantern
setblock 464 134 270 minecraft:white_concrete
setblock 465 134 234 minecraft:ochre_froglight
setblock 465 134 257 minecraft:white_concrete
setblock 465 134 264 minecraft:white_concrete
fill 465 134 265 465 148 265 minecraft:black_concrete
fill 423 135 232 423 156 232 minecraft:black_concrete
fill 423 135 260 423 176 260 minecraft:black_concrete
setblock 424 135 228 minecraft:white_concrete
fill 432 135 270 432 203 270 minecraft:black_concrete
fill 438 135 270 438 178 270 minecraft:black_concrete
fill 455 135 257 455 143 257 minecraft:gray_concrete
fill 456 135 256 456 143 256 minecraft:gray_concrete
fill 456 135 258 456 143 258 minecraft:gray_concrete
fill 457 135 257 457 143 257 minecraft:gray_concrete
fill 462 135 228 462 243 228 minecraft:black_concrete
fill 464 135 270 464 158 270 minecraft:black_concrete
fill 465 135 234 465 145 234 minecraft:black_concrete
setblock 465 135 244 minecraft:white_concrete
fill 465 135 257 465 179 257 minecraft:black_concrete
setblock 465 135 263 minecraft:white_concrete
fill 465 135 264 465 166 264 minecraft:black_concrete
setblock 423 136 251 minecraft:pearlescent_froglight
fill 424 136 228 424 267 228 minecraft:black_concrete
setblock 426 136 231 minecraft:light[level=15]
setblock 426 136 238 minecraft:light[level=12]
setblock 426 136 239 minecraft:light[level=15]
setblock 426 136 245 minecraft:light[level=12]
setblock 426 136 247 minecraft:light[level=15]
setblock 426 136 252 minecraft:light[level=12]
setblock 426 136 255 minecraft:light[level=15]
setblock 426 136 259 minecraft:light[level=12]
setblock 426 136 263 minecraft:light[level=15]
setblock 426 136 266 minecraft:light[level=12]
setblock 433 136 231 minecraft:light[level=12]
setblock 433 136 238 minecraft:light[level=12]
setblock 433 136 245 minecraft:light[level=12]
setblock 433 136 252 minecraft:light[level=12]
setblock 433 136 259 minecraft:light[level=12]
setblock 433 136 266 minecraft:light[level=12]
setblock 434 136 231 minecraft:light[level=15]
setblock 434 136 239 minecraft:light[level=15]
setblock 434 136 247 minecraft:light[level=15]
setblock 434 136 255 minecraft:light[level=15]
setblock 434 136 263 minecraft:light[level=15]
fill 437 136 257 437 137 258 minecraft:end_stone
setblock 440 136 231 minecraft:light[level=12]
setblock 440 136 238 minecraft:light[level=12]
setblock 440 136 245 minecraft:light[level=12]
setblock 440 136 252 minecraft:light[level=12]
setblock 440 136 259 minecraft:light[level=12]
setblock 440 136 266 minecraft:light[level=12]
setblock 442 136 231 minecraft:light[level=15]
setblock 442 136 239 minecraft:light[level=15]
setblock 442 136 247 minecraft:light[level=15]
setblock 442 136 255 minecraft:light[level=15]
setblock 442 136 263 minecraft:light[level=15]
setblock 442 136 270 minecraft:pearlescent_froglight
setblock 446 136 270 minecraft:pearlescent_froglight
setblock 447 136 231 minecraft:light[level=12]
setblock 447 136 238 minecraft:light[level=12]
setblock 447 136 245 minecraft:light[level=12]
setblock 447 136 252 minecraft:light[level=12]
setblock 447 136 259 minecraft:light[level=12]
setblock 447 136 266 minecraft:light[level=12]
setblock 447 136 270 minecraft:purple_concrete
setblock 450 136 231 minecraft:light[level=15]
setblock 450 136 239 minecraft:light[level=15]
fill 450 136 242 452 137 242 minecraft:gray_concrete
setblock 450 136 247 minecraft:light[level=15]
setblock 450 136 255 minecraft:light[level=15]
setblock 450 136 263 minecraft:light[level=15]
fill 451 136 243 451 137 243 minecraft:gray_concrete
setblock 454 136 231 minecraft:light[level=12]
setblock 454 136 238 minecraft:light[level=12]
setblock 454 136 245 minecraft:light[level=12]
setblock 454 136 252 minecraft:light[level=12]
setblock 454 136 259 minecraft:light[level=12]
setblock 454 136 266 minecraft:light[level=12]
fill 455 136 256 455 143 256 minecraft:gray_concrete
fill 455 136 258 455 143 258 minecraft:gray_concrete
fill 457 136 256 457 143 256 minecraft:gray_concrete
fill 457 136 258 457 143 258 minecraft:gray_concrete
setblock 458 136 231 minecraft:light[level=15]
setblock 458 136 239 minecraft:light[level=15]
setblock 458 136 247 minecraft:light[level=15]
setblock 458 136 255 minecraft:light[level=15]
setblock 458 136 263 minecraft:light[level=15]
setblock 461 136 231 minecraft:light[level=12]
setblock 461 136 238 minecraft:light[level=12]
setblock 461 136 245 minecraft:light[level=12]
setblock 461 136 252 minecraft:light[level=12]
setblock 461 136 259 minecraft:light[level=12]
setblock 461 136 266 minecraft:light[level=12]
fill 465 136 244 465 137 244 minecraft:black_concrete
setblock 465 136 251 minecraft:pearlescent_froglight
setblock 465 136 262 minecraft:white_concrete
fill 465 136 263 465 209 263 minecraft:black_concrete
fill 423 137 251 423 169 251 minecraft:black_concrete
fill 432 137 250 432 138 250 minecraft:pearlescent_froglight
fill 442 137 270 442 189 270 minecraft:black_concrete
fill 446 137 270 447 161 270 minecraft:black_concrete
fill 454 137 257 454 143 257 minecraft:gray_concrete
fill 456 137 255 456 143 255 minecraft:gray_concrete
fill 456 137 259 457 143 259 minecraft:gray_concrete
setblock 456 137 270 minecraft:sea_lantern
fill 458 137 257 458 143 258 minecraft:gray_concrete
setblock 465 137 232 minecraft:sea_lantern
setblock 465 137 241 minecraft:pearlescent_froglight
fill 465 137 251 465 140 251 minecraft:black_concrete
fill 465 137 262 465 206 262 minecraft:black_concrete
setblock 465 137 267 minecraft:purple_concrete
fill 454 138 256 454 143 256 minecraft:gray_concrete
fill 454 138 258 454 143 258 minecraft:gray_concrete
fill 455 138 255 455 143 255 minecraft:gray_concrete
fill 455 138 259 455 143 259 minecraft:gray_concrete
fill 456 138 270 456 203 270 minecraft:black_concrete
fill 457 138 255 457 143 255 minecraft:gray_concrete
fill 458 138 256 458 143 256 minecraft:gray_concrete
setblock 462 138 270 minecraft:ochre_froglight
setblock 463 138 228 minecraft:white_concrete
fill 465 138 232 465 155 232 minecraft:black_concrete
fill 465 138 241 465 185 241 minecraft:black_concrete
setblock 465 138 244 minecraft:white_concrete
fill 465 138 267 465 176 267 minecraft:black_concrete
setblock 465 138 268 minecraft:pearlescent_froglight
fill 432 139 250 432 146 250 minecraft:gray_concrete
fill 453 139 257 453 143 257 minecraft:gray_concrete
fill 454 139 255 454 143 255 minecraft:gray_concrete
fill 454 139 259 454 143 259 minecraft:gray_concrete
fill 455 139 260 457 143 260 minecraft:gray_concrete
fill 456 139 254 456 143 254 minecraft:gray_concrete
fill 458 139 255 458 143 255 minecraft:gray_concrete
fill 458 139 259 458 143 259 minecraft:gray_concrete
fill 459 139 256 459 143 258 minecraft:gray_concrete
fill 462 139 270 462 214 270 minecraft:black_concrete
fill 463 139 228 463 201 228 minecraft:black_concrete
setblock 465 139 230 minecraft:pearlescent_froglight
fill 465 139 244 465 160 244 minecraft:black_concrete
fill 465 139 268 465 210 268 minecraft:black_concrete
setblock 423 140 264 minecraft:blue_concrete
setblock 423 140 267 minecraft:pearlescent_froglight
fill 453 140 256 453 143 256 minecraft:gray_concrete
fill 453 140 258 453 143 258 minecraft:gray_concrete
fill 454 140 260 454 143 260 minecraft:gray_concrete
fill 455 140 254 455 143 254 minecraft:gray_concrete
fill 457 140 254 457 143 254 minecraft:gray_concrete
fill 458 140 260 458 143 260 minecraft:gray_concrete
fill 459 140 255 459 143 255 minecraft:gray_concrete
fill 459 140 259 459 143 259 minecraft:gray_concrete
setblock 461 140 228 minecraft:pearlescent_froglight
fill 465 140 230 465 160 230 minecraft:black_concrete
setblock 423 141 239 minecraft:purple_concrete
fill 423 141 264 423 170 264 minecraft:black_concrete
fill 423 141 267 423 143 267 minecraft:black_concrete
setblock 427 141 228 minecraft:sea_lantern
fill 431 141 249 431 146 250 minecraft:gray_concrete
fill 432 141 249 432 146 249 minecraft:gray_concrete
fill 432 141 251 432 146 251 minecraft:gray_concrete
fill 433 141 250 433 146 250 minecraft:gray_concrete
setblock 434 141 270 minecraft:ochre_froglight
fill 452 141 257 452 143 257 minecraft:gray_concrete
fill 453 141 255 453 143 255 minecraft:gray_concrete
fill 453 141 259 453 143 259 minecraft:gray_concrete
fill 454 141 254 454 143 254 minecraft:gray_concrete
fill 455 141 261 457 143 261 minecraft:gray_concrete
setblock 456 141 228 minecraft:pearlescent_froglight
fill 458 141 254 458 143 254 minecraft:gray_concrete
fill 459 141 260 459 143 260 minecraft:gray_concrete
fill 460 141 256 460 143 258 minecraft:gray_concrete
fill 461 141 228 461 172 228 minecraft:black_concrete
setblock 465 141 251 minecraft:pearlescent_froglight
fill 423 142 239 423 244 239 minecraft:black_concrete
setblock 426 142 231 minecraft:light[level=12]
setblock 426 142 238 minecraft:light[level=12]
setblock 426 142 245 minecraft:light[level=12]
setblock 426 142 252 minecraft:light[level=12]
setblock 426 142 259 minecraft:light[level=12]
setblock 426 142 266 minecraft:light[level=12]
fill 427 142 228 427 147 228 minecraft:black_concrete
fill 431 142 251 431 146 251 minecraft:gray_concrete
setblock 433 142 231 minecraft:light[level=12]
setblock 433 142 238 minecraft:light[level=12]
setblock 433 142 245 minecraft:light[level=12]
fill 433 142 249 433 146 249 minecraft:gray_concrete
fill 433 142 251 433 146 251 minecraft:gray_concrete
setblock 433 142 252 minecraft:light[level=12]
setblock 433 142 259 minecraft:light[level=12]
setblock 433 142 266 minecraft:light[level=12]
setblock 433 142 270 minecraft:sea_lantern
fill 434 142 270 434 239 270 minecraft:black_concrete
setblock 440 142 231 minecraft:light[level=12]
setblock 440 142 238 minecraft:light[level=12]
setblock 440 142 245 minecraft:light[level=12]
setblock 440 142 252 minecraft:light[level=12]
setblock 440 142 259 minecraft:light[level=12]
setblock 440 142 266 minecraft:light[level=12]
setblock 447 142 231 minecraft:light[level=12]
setblock 447 142 238 minecraft:light[level=12]
setblock 447 142 245 minecraft:light[level=12]
setblock 447 142 252 minecraft:light[level=12]
setblock 447 142 259 minecraft:light[level=12]
setblock 447 142 266 minecraft:light[level=12]
setblock 451 142 228 minecraft:white_concrete
fill 452 142 256 452 143 256 minecraft:gray_concrete
fill 452 142 258 452 143 259 minecraft:gray_concrete
fill 453 142 254 453 143 254 minecraft:gray_concrete
fill 453 142 260 453 143 260 minecraft:gray_concrete
setblock 454 142 231 minecraft:light[level=12]
setblock 454 142 238 minecraft:light[level=12]
setblock 454 142 245 minecraft:light[level=12]
setblock 454 142 252 minecraft:light[level=12]
fill 454 142 261 454 143 261 minecraft:gray_concrete
setblock 454 142 266 minecraft:light[level=12]
fill 455 142 253 458 143 253 minecraft:gray_concrete
fill 456 142 228 456 164 228 minecraft:black_concrete
fill 458 142 261 458 143 261 minecraft:gray_concrete
fill 459 142 254 459 143 254 minecraft:gray_concrete
fill 460 142 255 460 143 255 minecraft:gray_concrete
fill 460 142 259 460 143 259 minecraft:gray_concrete
setblock 461 142 231 minecraft:light[level=12]
setblock 461 142 238 minecraft:light[level=12]
setblock 461 142 245 minecraft:light[level=12]
setblock 461 142 252 minecraft:light[level=12]
setblock 461 142 259 minecraft:light[level=12]
setblock 461 142 266 minecraft:light[level=12]
setblock 463 142 270 minecraft:purple_terracotta
fill 465 142 251 465 162 251 minecraft:black_concrete
setblock 423 143 238 minecraft:sea_lantern
setblock 426 143 231 minecraft:light[level=15]
setblock 426 143 239 minecraft:light[level=15]
setblock 426 143 247 minecraft:light[level=15]
setblock 426 143 255 minecraft:light[level=15]
setblock 426 143 263 minecraft:light[level=15]
setblock 426 143 270 minecraft:sea_lantern
fill 430 143 249 430 146 250 minecraft:gray_concrete
fill 431 143 248 433 146 248 minecraft:gray_concrete
fill 432 143 252 432 146 252 minecraft:gray_concrete
fill 433 143 270 433 180 270 minecraft:black_concrete
setblock 434 143 231 minecraft:light[level=15]
setblock 434 143 239 minecraft:light[level=15]
setblock 434 143 247 minecraft:light[level=15]
fill 434 143 249 434 146 250 minecraft:gray_concrete
setblock 434 143 255 minecraft:light[level=15]
setblock 434 143 263 minecraft:light[level=15]
setblock 442 143 231 minecraft:light[level=15]
setblock 442 143 239 minecraft:light[level=15]
setblock 442 143 247 minecraft:light[level=15]
setblock 442 143 255 minecraft:light[level=15]
setblock 442 143 263 minecraft:light[level=15]
setblock 450 143 231 minecraft:light[level=15]
setblock 450 143 239 minecraft:light[level=15]
setblock 450 143 247 minecraft:light[level=15]
setblock 450 143 255 minecraft:light[level=15]
setblock 450 143 263 minecraft:light[level=15]
fill 451 143 228 451 251 228 minecraft:black_concrete
setblock 452 143 255 minecraft:gray_concrete
setblock 452 143 260 minecraft:gray_concrete
setblock 453 143 261 minecraft:gray_concrete
setblock 454 143 253 minecraft:gray_concrete
fill 455 143 262 457 143 262 minecraft:gray_concrete
setblock 458 143 231 minecraft:light[level=15]
setblock 458 143 239 minecraft:light[level=15]
setblock 458 143 247 minecraft:light[level=15]
setblock 458 143 263 minecraft:light[level=15]
setblock 459 143 253 minecraft:gray_concrete
setblock 459 143 261 minecraft:gray_concrete
setblock 460 143 254 minecraft:gray_concrete
setblock 460 143 260 minecraft:gray_concrete
fill 461 143 256 461 143 258 minecraft:gray_concrete
fill 463 143 270 463 165 270 minecraft:black_concrete
setblock 464 143 228 minecraft:sea_lantern
setblock 465 143 243 minecraft:magenta_terracotta
setblock 465 143 266 minecraft:pearlescent_froglight
fill 423 144 238 423 161 238 minecraft:black_concrete
setblock 423 144 252 minecraft:pearlescent_froglight
setblock 423 144 267 minecraft:white_concrete
setblock 424 144 270 minecraft:ochre_froglight
setblock 426 144 270 minecraft:blue_concrete
setblock 428 144 228 minecraft:purple_concrete
fill 430 144 251 430 146 251 minecraft:gray_concrete
fill 431 144 252 431 146 252 minecraft:gray_concrete
fill 433 144 252 433 146 252 minecraft:gray_concrete
fill 434 144 251 434 146 251 minecraft:gray_concrete
fill 434 144 252 435 145 255 minecraft:andesite
setblock 449 144 270 minecraft:ochre_froglight
fill 455 144 257 457 144 257 minecraft:pearlescent_froglight
setblock 456 144 256 minecraft:pearlescent_froglight
fill 456 144 258 457 144 258 minecraft:pearlescent_froglight
fill 464 144 228 464 158 228 minecraft:black_concrete
fill 465 144 243 465 179 243 minecraft:black_concrete
fill 465 144 266 465 235 266 minecraft:black_concrete
fill 423 145 252 423 155 252 minecraft:black_concrete
setblock 423 145 261 minecraft:magenta_terracotta
fill 423 145 267 423 308 267 minecraft:black_concrete
fill 424 145 270 424 177 270 minecraft:black_concrete
fill 426 145 270 426 152 270 minecraft:black_concrete
fill 428 145 228 428 154 228 minecraft:black_concrete
fill 429 145 249 429 146 251 minecraft:gray_concrete
fill 430 145 248 430 146 248 minecraft:gray_concrete
fill 430 145 252 430 146 252 minecraft:gray_concrete
fill 431 145 247 433 146 247 minecraft:gray_concrete
fill 432 145 253 432 146 253 minecraft:gray_concrete
fill 433 145 254 433 147 255 minecraft:andesite
fill 434 145 248 434 146 248 minecraft:gray_concrete
fill 434 145 256 435 146 256 minecraft:andesite
fill 435 145 249 435 146 250 minecraft:gray_concrete
fill 436 145 253 436 146 255 minecraft:andesite
setblock 438 145 228 minecraft:sea_lantern
fill 449 145 270 449 155 270 minecraft:black_concrete
fill 456 145 257 456 145 258 minecraft:pearlescent_froglight
setblock 457 145 257 minecraft:pearlescent_froglight
fill 423 146 261 423 156 261 minecraft:black_concrete
setblock 427 146 270 minecraft:pearlescent_froglight
setblock 429 146 248 minecraft:gray_concrete
setblock 429 146 252 minecraft:gray_concrete
setblock 430 146 247 minecraft:gray_concrete
setblock 431 146 253 minecraft:gray_concrete
setblock 433 146 253 minecraft:gray_concrete
setblock 434 146 247 minecraft:gray_concrete
setblock 434 146 252 minecraft:gray_concrete
fill 434 146 253 435 146 255 minecraft:andesite
setblock 435 146 248 minecraft:gray_concrete
setblock 435 146 251 minecraft:gray_concrete
fill 435 146 252 436 146 252 minecraft:andesite
setblock 437 146 270 minecraft:pearlescent_froglight
fill 438 146 228 438 176 228 minecraft:black_concrete
setblock 452 146 270 minecraft:sea_lantern
fill 456 146 257 456 148 257 minecraft:pearlescent_froglight
setblock 465 146 234 minecraft:purple_terracotta
setblock 465 146 250 minecraft:ochre_froglight
fill 427 147 270 427 173 270 minecraft:black_concrete
fill 431 147 250 433 148 250 minecraft:pearlescent_froglight
fill 432 147 249 432 148 249 minecraft:pearlescent_froglight
setblock 432 147 251 minecraft:pearlescent_froglight
fill 434 147 254 434 147 255 minecraft:andesite
fill 435 147 253 436 147 254 minecraft:andesite
setblock 437 147 270 minecraft:white_concrete
fill 452 147 270 452 208 270 minecraft:black_concrete
setblock 454 147 270 minecraft:purple_concrete
fill 465 147 234 465 199 234 minecraft:black_concrete
fill 465 147 250 465 161 250 minecraft:black_concrete
setblock 426 148 231 minecraft:light[level=12]
setblock 426 148 238 minecraft:light[level=12]
setblock 426 148 245 minecraft:light[level=12]
setblock 426 148 252 minecraft:light[level=12]
setblock 426 148 259 minecraft:light[level=12]
setblock 426 148 266 minecraft:light[level=12]
setblock 427 148 228 minecraft:ochre_froglight
setblock 433 148 231 minecraft:light[level=12]
setblock 433 148 238 minecraft:light[level=12]
setblock 433 148 245 minecraft:light[level=12]
setblock 433 148 252 minecraft:light[level=12]
setblock 433 148 259 minecraft:light[level=12]
setblock 433 148 266 minecraft:light[level=12]
fill 437 148 270 437 151 270 minecraft:black_concrete
setblock 440 148 231 minecraft:light[level=12]
setblock 440 148 238 minecraft:light[level=12]
setblock 440 148 245 minecraft:light[level=12]
setblock 440 148 252 minecraft:light[level=12]
setblock 440 148 259 minecraft:light[level=12]
setblock 440 148 266 minecraft:light[level=12]
setblock 447 148 231 minecraft:light[level=12]
setblock 447 148 238 minecraft:light[level=12]
setblock 447 148 245 minecraft:light[level=12]
setblock 447 148 252 minecraft:light[level=12]
setblock 447 148 259 minecraft:light[level=12]
setblock 447 148 266 minecraft:light[level=12]
setblock 454 148 231 minecraft:light[level=12]
setblock 454 148 238 minecraft:light[level=12]
setblock 454 148 245 minecraft:light[level=12]
setblock 454 148 252 minecraft:light[level=12]
setblock 454 148 259 minecraft:light[level=12]
setblock 454 148 266 minecraft:light[level=12]
fill 454 148 270 454 153 270 minecraft:black_concrete
setblock 461 148 231 minecraft:light[level=12]
setblock 461 148 238 minecraft:light[level=12]
setblock 461 148 245 minecraft:light[level=12]
setblock 461 148 252 minecraft:light[level=12]
setblock 461 148 259 minecraft:light[level=12]
setblock 461 148 266 minecraft:light[level=12]
setblock 465 148 238 minecraft:ochre_froglight
setblock 423 149 253 minecraft:pearlescent_froglight
fill 427 149 228 427 164 228 minecraft:black_concrete
fill 432 149 250 432 151 250 minecraft:pearlescent_froglight
setblock 453 149 270 minecraft:blue_concrete
fill 465 149 238 465 163 238 minecraft:black_concrete
setblock 465 149 248 minecraft:purple_concrete
setblock 465 149 265 minecraft:pearlescent_froglight
setblock 423 150 234 minecraft:pearlescent_froglight
fill 423 150 253 423 155 253 minecraft:black_concrete
setblock 426 150 231 minecraft:light[level=15]
setblock 426 150 239 minecraft:light[level=15]
setblock 426 150 247 minecraft:light[level=15]
setblock 426 150 255 minecraft:light[level=15]
setblock 426 150 263 minecraft:light[level=15]
setblock 434 150 231 minecraft:light[level=15]
setblock 434 150 239 minecraft:light[level=15]
setblock 434 150 247 minecraft:light[level=15]
setblock 434 150 255 minecraft:light[level=15]
setblock 434 150 263 minecraft:light[level=15]
fill 436 150 256 436 151 257 minecraft:end_stone
setblock 442 150 231 minecraft:light[level=15]
setblock 442 150 239 minecraft:light[level=15]
setblock 442 150 247 minecraft:light[level=15]
setblock 442 150 255 minecraft:light[level=15]
setblock 442 150 263 minecraft:light[level=15]
setblock 450 150 231 minecraft:light[level=15]
setblock 450 150 239 minecraft:light[level=15]
setblock 450 150 247 minecraft:light[level=15]
setblock 450 150 255 minecraft:light[level=15]
setblock 450 150 263 minecraft:light[level=15]
fill 453 150 270 453 169 270 minecraft:black_concrete
setblock 458 150 231 minecraft:light[level=15]
setblock 458 150 239 minecraft:light[level=15]
setblock 458 150 247 minecraft:light[level=15]
setblock 458 150 255 minecraft:light[level=15]
setblock 458 150 263 minecraft:light[level=15]
setblock 465 150 246 minecraft:ochre_froglight
fill 465 150 248 465 162 248 minecraft:black_concrete
setblock 465 150 259 minecraft:white_concrete
setblock 465 150 260 minecraft:pearlescent_froglight
fill 465 150 265 465 172 265 minecraft:black_concrete
fill 423 151 234 423 232 234 minecraft:black_concrete
setblock 423 151 243 minecraft:purple_terracotta
setblock 423 151 259 minecraft:sea_lantern
setblock 432 151 228 minecraft:ochre_froglight
setblock 461 151 270 minecraft:white_concrete
setblock 465 151 233 minecraft:sea_lantern
fill 465 151 246 465 168 246 minecraft:black_concrete
fill 465 151 259 465 152 260 minecraft:black_concrete
setblock 423 152 241 minecraft:pearlescent_froglight
fill 423 152 243 423 195 243 minecraft:black_concrete
fill 423 152 259 423 166 259 minecraft:black_concrete
setblock 423 152 268 minecraft:purple_concrete
setblock 430 152 270 minecraft:blue_concrete
fill 432 152 228 432 160 228 minecraft:black_concrete
setblock 437 152 270 minecraft:blue_concrete
fill 461 152 270 461 185 270 minecraft:black_concrete
fill 465 152 233 465 185 233 minecraft:black_concrete
fill 423 153 241 423 175 241 minecraft:black_concrete
setblock 423 153 244 minecraft:white_concrete
fill 423 153 268 423 159 268 minecraft:black_concrete
setblock 426 153 270 minecraft:pearlescent_froglight
fill 430 153 270 430 209 270 minecraft:black_concrete
fill 437 153 270 437 203 270 minecraft:black_concrete
setblock 440 153 270 minecraft:pearlescent_froglight
setblock 455 153 270 minecraft:purple_terracotta
setblock 465 153 259 minecraft:white_concrete
setblock 465 153 260 minecraft:magenta_terracotta
setblock 423 154 230 minecraft:ochre_froglight
fill 423 154 244 423 166 244 minecraft:black_concrete
setblock 426 154 231 minecraft:light[level=12]
setblock 426 154 238 minecraft:light[level=12]
setblock 426 154 245 minecraft:light[level=12]
setblock 426 154 252 minecraft:light[level=12]
setblock 426 154 259 minecraft:light[level=12]
setblock 426 154 266 minecraft:light[level=12]
fill 426 154 270 426 157 270 minecraft:black_concrete
setblock 433 154 228 minecraft:sea_lantern
setblock 433 154 231 minecraft:light[level=12]
setblock 433 154 238 minecraft:light[level=12]
setblock 433 154 245 minecraft:light[level=12]
setblock 433 154 252 minecraft:light[level=12]
setblock 433 154 259 minecraft:light[level=12]
setblock 433 154 266 minecraft:light[level=12]
setblock 440 154 231 minecraft:light[level=12]
setblock 440 154 238 minecraft:light[level=12]
setblock 440 154 245 minecraft:light[level=12]
setblock 440 154 252 minecraft:light[level=12]
setblock 440 154 259 minecraft:light[level=12]
setblock 440 154 266 minecraft:light[level=12]
fill 440 154 270 440 190 270 minecraft:black_concrete
setblock 447 154 231 minecraft:light[level=12]
setblock 447 154 238 minecraft:light[level=12]
setblock 447 154 245 minecraft:light[level=12]
setblock 447 154 252 minecraft:light[level=12]
setblock 447 154 259 minecraft:light[level=12]
setblock 447 154 266 minecraft:light[level=12]
setblock 454 154 231 minecraft:light[level=12]
setblock 454 154 238 minecraft:light[level=12]
setblock 454 154 245 minecraft:light[level=12]
setblock 454 154 252 minecraft:light[level=12]
setblock 454 154 259 minecraft:light[level=12]
setblock 454 154 266 minecraft:light[level=12]
setblock 454 154 270 minecraft:white_concrete
fill 455 154 270 455 162 270 minecraft:black_concrete
setblock 461 154 231 minecraft:light[level=12]
setblock 461 154 238 minecraft:light[level=12]
setblock 461 154 245 minecraft:light[level=12]
setblock 461 154 252 minecraft:light[level=12]
setblock 461 154 259 minecraft:light[level=12]
setblock 461 154 266 minecraft:light[level=12]
fill 465 154 259 465 161 260 minecraft:black_concrete
fill 423 155 230 423 231 230 minecraft:black_concrete
setblock 423 155 235 minecraft:sea_lantern
setblock 423 155 265 minecraft:sea_lantern
setblock 426 155 228 minecraft:white_concrete
setblock 428 155 228 minecraft:sea_lantern
fill 433 155 228 433 239 228 minecraft:black_concrete
setblock 436 155 228 minecraft:white_concrete
fill 454 155 270 454 308 270 minecraft:black_concrete
setblock 465 155 236 minecraft:ochre_froglight
fill 465 155 237 465 163 237 minecraft:black_concrete
setblock 465 155 252 minecraft:ochre_froglight
fill 423 156 235 423 197 235 minecraft:black_concrete
fill 423 156 252 423 156 253 minecraft:white_concrete
fill 423 156 265 423 171 265 minecraft:black_concrete
fill 426 156 228 426 160 228 minecraft:black_concrete
fill 428 156 228 428 173 228 minecraft:black_concrete
fill 436 156 228 436 230 228 minecraft:black_concrete
setblock 446 156 228 minecraft:sea_lantern
setblock 449 156 270 minecraft:purple_concrete
setblock 465 156 232 minecraft:ochre_froglight
fill 465 156 236 465 159 236 minecraft:black_concrete
fill 465 156 252 465 207 252 minecraft:black_concrete
setblock 465 156 254 minecraft:pearlescent_froglight
setblock 423 157 232 minecraft:purple_concrete
fill 423 157 252 423 168 253 minecraft:black_concrete
setblock 423 157 261 minecraft:white_concrete
setblock 426 157 231 minecraft:light[level=15]
setblock 426 157 239 minecraft:light[level=15]
setblock 426 157 247 minecraft:light[level=15]
setblock 426 157 255 minecraft:light[level=15]
setblock 426 157 263 minecraft:light[level=15]
setblock 434 157 231 minecraft:light[level=15]
setblock 434 157 239 minecraft:light[level=15]
setblock 434 157 247 minecraft:light[level=15]
setblock 434 157 255 minecraft:light[level=15]
setblock 434 157 263 minecraft:light[level=15]
setblock 442 157 231 minecraft:light[level=15]
setblock 442 157 239 minecraft:light[level=15]
setblock 442 157 247 minecraft:light[level=15]
setblock 442 157 255 minecraft:light[level=15]
setblock 442 157 263 minecraft:light[level=15]
fill 446 157 228 446 233 228 minecraft:black_concrete
fill 449 157 270 449 163 270 minecraft:black_concrete
setblock 450 157 231 minecraft:light[level=15]
setblock 450 157 239 minecraft:light[level=15]
setblock 450 157 247 minecraft:light[level=15]
setblock 450 157 255 minecraft:light[level=15]
setblock 450 157 263 minecraft:light[level=15]
setblock 458 157 231 minecraft:light[level=15]
setblock 458 157 239 minecraft:light[level=15]
setblock 458 157 247 minecraft:light[level=15]
setblock 458 157 255 minecraft:light[level=15]
setblock 458 157 263 minecraft:light[level=15]
fill 465 157 232 465 239 232 minecraft:black_concrete
fill 465 157 254 465 198 254 minecraft:black_concrete
fill 423 158 232 423 159 232 minecraft:black_concrete
fill 423 158 261 423 207 261 minecraft:black_concrete
setblock 426 158 270 minecraft:ochre_froglight
setblock 431 158 228 minecraft:sea_lantern
fill 454 158 250 455 160 250 minecraft:andesite
fill 454 158 252 455 159 252 minecraft:andesite
fill 455 158 251 455 161 251 minecraft:andesite
setblock 465 158 245 minecraft:pearlescent_froglight
setblock 423 159 248 minecraft:magenta_terracotta
fill 426 159 270 426 175 270 minecraft:black_concrete
setblock 429 159 228 minecraft:ochre_froglight
fill 431 159 228 431 163 228 minecraft:black_concrete
setblock 442 159 228 minecraft:sea_lantern
fill 454 159 251 454 160 251 minecraft:andesite
fill 456 159 250 456 160 251 minecraft:andesite
setblock 459 159 228 minecraft:white_concrete
setblock 464 159 228 minecraft:pearlescent_froglight
setblock 464 159 270 minecraft:white_concrete
fill 465 159 245 465 194 245 minecraft:black_concrete
setblock 423 160 232 minecraft:white_concrete
fill 423 160 248 423 176 248 minecraft:black_concrete
setblock 423 160 268 minecraft:sea_lantern
setblock 426 160 231 minecraft:light[level=12]
setblock 426 160 238 minecraft:light[level=12]
setblock 426 160 245 minecraft:light[level=12]
setblock 426 160 252 minecraft:light[level=12]
setblock 426 160 259 minecraft:light[level=12]
setblock 426 160 266 minecraft:light[level=12]
fill 429 160 228 429 177 228 minecraft:black_concrete
setblock 433 160 231 minecraft:light[level=12]
setblock 433 160 238 minecraft:light[level=12]
setblock 433 160 245 minecraft:light[level=12]
setblock 433 160 252 minecraft:light[level=12]
setblock 433 160 259 minecraft:light[level=12]
setblock 433 160 266 minecraft:light[level=12]
setblock 440 160 231 minecraft:light[level=12]
setblock 440 160 238 minecraft:light[level=12]
setblock 440 160 245 minecraft:light[level=12]
setblock 440 160 252 minecraft:light[level=12]
setblock 440 160 259 minecraft:light[level=12]
setblock 440 160 266 minecraft:light[level=12]
fill 442 160 228 442 222 228 minecraft:black_concrete
setblock 447 160 231 minecraft:light[level=12]
setblock 447 160 238 minecraft:light[level=12]
setblock 447 160 245 minecraft:light[level=12]
setblock 447 160 252 minecraft:light[level=12]
setblock 447 160 259 minecraft:light[level=12]
setblock 447 160 266 minecraft:light[level=12]
setblock 453 160 251 minecraft:andesite
setblock 454 160 231 minecraft:light[level=12]
setblock 454 160 238 minecraft:light[level=12]
setblock 454 160 245 minecraft:light[level=12]
setblock 454 160 252 minecraft:light[level=12]
setblock 454 160 259 minecraft:light[level=12]
setblock 454 160 266 minecraft:light[level=12]
fill 459 160 228 459 245 228 minecraft:black_concrete
setblock 461 160 231 minecraft:light[level=12]
setblock 461 160 238 minecraft:light[level=12]
setblock 461 160 245 minecraft:light[level=12]
setblock 461 160 252 minecraft:light[level=12]
setblock 461 160 259 minecraft:light[level=12]
setblock 461 160 266 minecraft:light[level=12]
fill 464 160 228 464 164 228 minecraft:black_concrete
fill 464 160 270 464 181 270 minecraft:black_concrete
setblock 465 160 236 minecraft:ochre_froglight
setblock 465 160 269 minecraft:white_concrete
fill 423 161 232 423 196 232 minecraft:black_concrete
fill 423 161 268 423 213 268 minecraft:black_concrete
setblock 426 161 228 minecraft:purple_concrete
setblock 432 161 228 minecraft:white_concrete
setblock 455 161 250 minecraft:andesite
setblock 465 161 230 minecraft:sea_lantern
setblock 465 161 236 minecraft:white_concrete
setblock 465 161 244 minecraft:purple_terracotta
fill 465 161 269 465 187 269 minecraft:black_concrete
setblock 423 162 238 minecraft:pearlescent_froglight
fill 426 162 228 426 206 228 minecraft:black_concrete
fill 432 162 228 432 170 228 minecraft:black_concrete
fill 446 162 270 446 234 270 minecraft:black_concrete
setblock 447 162 270 minecraft:white_concrete
setblock 448 162 228 minecraft:pearlescent_froglight
setblock 453 162 228 minecraft:sea_lantern
fill 465 162 230 465 238 230 minecraft:black_concrete
fill 465 162 236 465 181 236 minecraft:black_concrete
fill 465 162 244 465 197 244 minecraft:black_concrete
setblock 465 162 250 minecraft:pearlescent_froglight
fill 465 162 259 465 208 259 minecraft:black_concrete
setblock 465 162 260 minecraft:blue_concrete
fill 423 163 238 423 271 238 minecraft:black_concrete
fill 447 163 270 447 165 270 minecraft:black_concrete
fill 448 163 228 448 208 228 minecraft:black_concrete
fill 453 163 228 453 178 228 minecraft:black_concrete
setblock 455 163 270 minecraft:ochre_froglight
setblock 465 163 239 minecraft:white_concrete
setblock 465 163 248 minecraft:sea_lantern
fill 465 163 250 465 173 250 minecraft:black_concrete
setblock 465 163 251 minecraft:magenta_terracotta
fill 465 163 260 465 172 260 minecraft:black_concrete
setblock 465 163 261 minecraft:sea_lantern
setblock 426 164 231 minecraft:light[level=15]
setblock 426 164 239 minecraft:light[level=15]
setblock 426 164 247 minecraft:light[level=15]
setblock 426 164 255 minecraft:light[level=15]
setblock 426 164 263 minecraft:light[level=15]
setblock 431 164 228 minecraft:purple_concrete
setblock 434 164 231 minecraft:light[level=15]
setblock 434 164 239 minecraft:light[level=15]
setblock 434 164 247 minecraft:light[level=15]
setblock 434 164 255 minecraft:light[level=15]
setblock 434 164 263 minecraft:light[level=15]
setblock 442 164 231 minecraft:light[level=15]
setblock 442 164 239 minecraft:light[level=15]
setblock 442 164 247 minecraft:light[level=15]
setblock 442 164 255 minecraft:light[level=15]
setblock 442 164 263 minecraft:light[level=15]
setblock 449 164 270 minecraft:purple_terracotta
setblock 450 164 231 minecraft:light[level=15]
setblock 450 164 239 minecraft:light[level=15]
setblock 450 164 247 minecraft:light[level=15]
setblock 450 164 255 minecraft:light[level=15]
setblock 450 164 263 minecraft:light[level=15]
setblock 452 164 228 minecraft:ochre_froglight
fill 455 164 270 455 236 270 minecraft:black_concrete
setblock 457 164 228 minecraft:magenta_terracotta
setblock 458 164 231 minecraft:light[level=15]
setblock 458 164 239 minecraft:light[level=15]
setblock 458 164 247 minecraft:light[level=15]
setblock 458 164 255 minecraft:light[level=15]
setblock 458 164 263 minecraft:light[level=15]
setblock 465 164 237 minecraft:white_concrete
setblock 465 164 238 minecraft:magenta_terracotta
fill 465 164 239 465 186 239 minecraft:black_concrete
setblock 465 164 248 minecraft:white_concrete
fill 465 164 251 465 180 251 minecraft:black_concrete
fill 465 164 261 465 225 261 minecraft:black_concrete
setblock 427 165 228 minecraft:sea_lantern
fill 431 165 228 431 172 228 minecraft:black_concrete
setblock 431 165 270 minecraft:ochre_froglight
fill 449 165 270 449 293 270 minecraft:black_concrete
fill 452 165 228 452 213 228 minecraft:black_concrete
setblock 456 165 228 minecraft:blue_concrete
fill 457 165 228 457 183 228 minecraft:black_concrete
setblock 457 165 270 minecraft:pearlescent_froglight
setblock 464 165 228 minecraft:ochre_froglight
fill 465 165 237 465 210 238 minecraft:black_concrete
fill 465 165 248 465 244 248 minecraft:black_concrete
setblock 426 166 231 minecraft:light[level=12]
setblock 426 166 238 minecraft:light[level=12]
setblock 426 166 245 minecraft:light[level=12]
setblock 426 166 252 minecraft:light[level=12]
setblock 426 166 259 minecraft:light[level=12]
setblock 426 166 266 minecraft:light[level=12]
fill 427 166 228 427 177 228 minecraft:black_concrete
fill 431 166 270 431 185 270 minecraft:black_concrete
setblock 433 166 231 minecraft:light[level=12]
setblock 433 166 238 minecraft:light[level=12]
setblock 433 166 245 minecraft:light[level=12]
setblock 433 166 252 minecraft:light[level=12]
setblock 433 166 259 minecraft:light[level=12]
setblock 433 166 266 minecraft:light[level=12]
setblock 440 166 231 minecraft:light[level=12]
setblock 440 166 238 minecraft:light[level=12]
setblock 440 166 245 minecraft:light[level=12]
setblock 440 166 252 minecraft:light[level=12]
setblock 440 166 259 minecraft:light[level=12]
setblock 440 166 266 minecraft:light[level=12]
setblock 447 166 231 minecraft:light[level=12]
setblock 447 166 238 minecraft:light[level=12]
setblock 447 166 245 minecraft:light[level=12]
setblock 447 166 252 minecraft:light[level=12]
setblock 447 166 259 minecraft:light[level=12]
setblock 447 166 266 minecraft:light[level=12]
setblock 447 166 270 minecraft:pearlescent_froglight
setblock 454 166 231 minecraft:light[level=12]
setblock 454 166 238 minecraft:light[level=12]
setblock 454 166 245 minecraft:light[level=12]
setblock 454 166 252 minecraft:light[level=12]
setblock 454 166 259 minecraft:light[level=12]
setblock 454 166 266 minecraft:light[level=12]
fill 456 166 228 456 180 228 minecraft:black_concrete
fill 457 166 270 457 241 270 minecraft:black_concrete
setblock 461 166 231 minecraft:light[level=12]
setblock 461 166 238 minecraft:light[level=12]
setblock 461 166 245 minecraft:light[level=12]
setblock 461 166 252 minecraft:light[level=12]
setblock 461 166 259 minecraft:light[level=12]
setblock 461 166 266 minecraft:light[level=12]
setblock 463 166 270 minecraft:ochre_froglight
fill 464 166 228 464 192 228 minecraft:black_concrete
setblock 423 167 244 minecraft:white_concrete
setblock 423 167 249 minecraft:sea_lantern
setblock 423 167 259 minecraft:white_concrete
fill 447 167 270 447 219 270 minecraft:black_concrete
fill 463 167 270 463 194 270 minecraft:black_concrete
setblock 465 167 264 minecraft:ochre_froglight
fill 423 168 244 423 308 244 minecraft:black_concrete
fill 423 168 249 423 173 249 minecraft:black_concrete
fill 423 168 259 423 223 259 minecraft:black_concrete
fill 437 168 243 437 171 243 minecraft:andesite
fill 465 168 264 465 210 264 minecraft:black_concrete
fill 423 169 252 423 174 252 minecraft:black_concrete
setblock 423 169 253 minecraft:pearlescent_froglight
fill 436 169 243 436 170 244 minecraft:andesite
fill 437 169 244 438 170 244 minecraft:andesite
fill 438 169 243 438 170 243 minecraft:andesite
setblock 465 169 246 minecraft:white_concrete
setblock 423 170 245 minecraft:ochre_froglight
setblock 423 170 251 minecraft:pearlescent_froglight
fill 423 170 253 423 187 253 minecraft:black_concrete
setblock 453 170 270 minecraft:white_concrete
setblock 459 170 270 minecraft:ochre_froglight
fill 465 170 246 465 227 246 minecraft:black_concrete
fill 423 171 245 423 287 245 minecraft:black_concrete
fill 423 171 251 423 243 251 minecraft:black_concrete
setblock 423 171 255 minecraft:sea_lantern
setblock 423 171 264 minecraft:pearlescent_froglight
setblock 426 171 231 minecraft:light[level=15]
setblock 426 171 239 minecraft:light[level=15]
setblock 426 171 247 minecraft:light[level=15]
setblock 426 171 255 minecraft:light[level=15]
setblock 426 171 263 minecraft:light[level=15]
setblock 432 171 228 minecraft:magenta_terracotta
setblock 434 171 231 minecraft:light[level=15]
setblock 434 171 239 minecraft:light[level=15]
setblock 434 171 247 minecraft:light[level=15]
setblock 434 171 255 minecraft:light[level=15]
setblock 434 171 263 minecraft:light[level=15]
setblock 442 171 231 minecraft:light[level=15]
setblock 442 171 239 minecraft:light[level=15]
setblock 442 171 247 minecraft:light[level=15]
setblock 442 171 255 minecraft:light[level=15]
setblock 442 171 263 minecraft:light[level=15]
setblock 450 171 231 minecraft:light[level=15]
setblock 450 171 239 minecraft:light[level=15]
setblock 450 171 247 minecraft:light[level=15]
setblock 450 171 255 minecraft:light[level=15]
setblock 450 171 263 minecraft:light[level=15]
fill 453 171 270 453 232 270 minecraft:black_concrete
setblock 458 171 231 minecraft:light[level=15]
setblock 458 171 239 minecraft:light[level=15]
setblock 458 171 247 minecraft:light[level=15]
setblock 458 171 255 minecraft:light[level=15]
setblock 458 171 263 minecraft:light[level=15]
fill 459 171 270 459 182 270 minecraft:black_concrete
fill 423 172 255 423 179 255 minecraft:black_concrete
fill 423 172 264 423 305 264 minecraft:black_concrete
setblock 423 172 265 minecraft:blue_concrete
setblock 426 172 231 minecraft:light[level=12]
setblock 426 172 238 minecraft:light[level=12]
setblock 426 172 245 minecraft:light[level=12]
setblock 426 172 252 minecraft:light[level=12]
setblock 426 172 259 minecraft:light[level=12]
setblock 426 172 266 minecraft:light[level=12]
fill 432 172 228 432 207 228 minecraft:black_concrete
setblock 433 172 231 minecraft:light[level=12]
setblock 433 172 238 minecraft:light[level=12]
setblock 433 172 245 minecraft:light[level=12]
setblock 433 172 252 minecraft:light[level=12]
setblock 433 172 259 minecraft:light[level=12]
setblock 433 172 266 minecraft:light[level=12]
setblock 437 172 228 minecraft:white_concrete
setblock 440 172 231 minecraft:light[level=12]
setblock 440 172 238 minecraft:light[level=12]
setblock 440 172 245 minecraft:light[level=12]
setblock 440 172 252 minecraft:light[level=12]
setblock 440 172 259 minecraft:light[level=12]
setblock 440 172 266 minecraft:light[level=12]
setblock 447 172 231 minecraft:light[level=12]
setblock 447 172 238 minecraft:light[level=12]
setblock 447 172 245 minecraft:light[level=12]
setblock 447 172 252 minecraft:light[level=12]
setblock 447 172 259 minecraft:light[level=12]
setblock 447 172 266 minecraft:light[level=12]
setblock 454 172 231 minecraft:light[level=12]
setblock 454 172 238 minecraft:light[level=12]
setblock 454 172 245 minecraft:light[level=12]
setblock 454 172 252 minecraft:light[level=12]
setblock 454 172 259 minecraft:light[level=12]
setblock 454 172 266 minecraft:light[level=12]
setblock 461 172 231 minecraft:light[level=12]
setblock 461 172 238 minecraft:light[level=12]
setblock 461 172 245 minecraft:light[level=12]
setblock 461 172 252 minecraft:light[level=12]
setblock 461 172 259 minecraft:light[level=12]
setblock 461 172 266 minecraft:light[level=12]
setblock 465 172 231 minecraft:purple_concrete
setblock 465 172 249 minecraft:sea_lantern
fill 423 173 265 423 308 265 minecraft:black_concrete
setblock 431 173 228 minecraft:purple_concrete
setblock 436 173 270 minecraft:white_concrete
fill 437 173 228 437 232 228 minecraft:black_concrete
setblock 461 173 228 minecraft:sea_lantern
fill 465 173 231 465 193 231 minecraft:black_concrete
fill 465 173 249 465 211 249 minecraft:black_concrete
setblock 465 173 260 minecraft:sea_lantern
setblock 465 173 265 minecraft:white_concrete
setblock 423 174 249 minecraft:ochre_froglight
setblock 427 174 270 minecraft:ochre_froglight
setblock 428 174 228 minecraft:ochre_froglight
fill 431 174 228 431 237 228 minecraft:black_concrete
fill 436 174 270 436 213 270 minecraft:black_concrete
setblock 444 174 228 minecraft:ochre_froglight
setblock 451 174 270 minecraft:blue_concrete
fill 461 174 228 461 178 228 minecraft:black_concrete
setblock 465 174 250 minecraft:white_concrete
fill 465 174 260 465 179 260 minecraft:black_concrete
fill 465 174 265 465 308 265 minecraft:black_concrete
fill 423 175 249 423 179 249 minecraft:black_concrete
setblock 423 175 252 minecraft:white_concrete
setblock 427 175 270 minecraft:white_concrete
fill 428 175 228 428 183 228 minecraft:black_concrete
fill 444 175 228 444 214 228 minecraft:black_concrete
fill 447 175 247 448 177 247 minecraft:tuff
fill 448 175 246 448 176 246 minecraft:tuff
fill 451 175 270 451 196 270 minecraft:black_concrete
setblock 458 175 270 minecraft:magenta_terracotta
fill 465 175 250 465 205 250 minecraft:black_concrete
setblock 465 175 255 minecraft:purple_terracotta
setblock 423 176 241 minecraft:white_concrete
fill 423 176 252 423 202 252 minecraft:black_concrete
setblock 423 176 256 minecraft:blue_concrete
setblock 423 176 266 minecraft:pearlescent_froglight
setblock 426 176 270 minecraft:ochre_froglight
fill 427 176 270 427 284 270 minecraft:black_concrete
fill 437 176 249 449 176 249 minecraft:tuff
fill 438 176 250 448 176 250 minecraft:tuff
fill 440 176 247 446 176 248 minecraft:tuff
fill 440 176 251 443 176 251 minecraft:tuff
setblock 443 176 228 minecraft:pearlescent_froglight
fill 444 176 246 447 176 246 minecraft:tuff
fill 445 176 251 446 176 251 minecraft:tuff
fill 446 176 245 451 176 245 minecraft:tuff
fill 447 176 244 450 176 244 minecraft:tuff
fill 447 176 248 450 176 248 minecraft:tuff
fill 449 176 246 451 176 247 minecraft:tuff
fill 458 176 270 458 185 270 minecraft:black_concrete
fill 465 176 255 465 214 255 minecraft:black_concrete
fill 423 177 241 423 193 241 minecraft:black_concrete
setblock 423 177 248 minecraft:ochre_froglight
fill 423 177 256 423 207 256 minecraft:black_concrete
setblock 423 177 260 minecraft:pearlescent_froglight
fill 423 177 266 423 186 266 minecraft:black_concrete
fill 426 177 270 426 181 270 minecraft:black_concrete
fill 428 177 270 428 178 270 minecraft:black_concrete
setblock 429 177 270 minecraft:pearlescent_froglight
fill 436 177 249 437 178 249 minecraft:tuff
setblock 436 177 250 minecraft:andesite
setblock 437 177 247 minecraft:cobbled_deepslate
setblock 437 177 248 minecraft:tuff
fill 437 177 250 439 177 250 minecraft:tuff
setblock 437 177 251 minecraft:andesite
setblock 438 177 228 minecraft:sea_lantern
fill 438 177 246 439 177 247 minecraft:tuff
setblock 438 177 248 minecraft:andesite
setblock 438 177 249 minecraft:cobbled_deepslate
fill 438 177 251 438 179 251 minecraft:tuff
setblock 438 177 252 minecraft:andesite
setblock 439 177 245 minecraft:andesite
fill 439 177 248 441 177 248 minecraft:tuff
setblock 439 177 249 minecraft:andesite
setblock 439 177 251 minecraft:cobbled_deepslate
fill 439 177 252 440 178 252 minecraft:tuff
fill 440 177 245 442 177 245 minecraft:tuff
setblock 440 177 246 minecraft:andesite
setblock 440 177 247 minecraft:tuff
fill 440 177 249 442 177 249 minecraft:tuff
setblock 440 177 250 minecraft:andesite
setblock 440 177 251 minecraft:tuff
fill 440 177 253 441 190 253 minecraft:obsidian
setblock 441 177 246 minecraft:cobbled_deepslate
setblock 441 177 247 minecraft:andesite
fill 441 177 250 442 178 250 minecraft:tuff
fill 441 177 251 441 190 252 minecraft:obsidian
fill 442 177 246 443 177 247 minecraft:tuff
setblock 442 177 248 minecraft:cobbled_deepslate
fill 442 177 251 443 190 251 minecraft:obsidian
fill 443 177 228 443 271 228 minecraft:black_concrete
setblock 443 177 245 minecraft:andesite
fill 443 177 248 445 177 248 minecraft:tuff
setblock 443 177 249 minecraft:andesite
fill 443 177 250 445 190 250 minecraft:obsidian
fill 444 177 244 444 178 245 minecraft:tuff
setblock 444 177 246 minecraft:andesite
setblock 444 177 247 minecraft:tuff
fill 444 177 249 446 177 249 minecraft:tuff
setblock 445 177 244 minecraft:tuff
setblock 445 177 245 minecraft:cobbled_deepslate
fill 445 177 246 447 177 246 minecraft:tuff
setblock 445 177 247 minecraft:andesite
fill 445 177 251 447 190 251 minecraft:obsidian
fill 446 177 243 448 177 243 minecraft:tuff
setblock 446 177 244 minecraft:andesite
setblock 446 177 245 minecraft:tuff
setblock 446 177 247 minecraft:cobbled_deepslate
setblock 446 177 248 minecraft:andesite
fill 446 177 250 447 177 250 minecraft:tuff
fill 447 177 244 448 178 244 minecraft:tuff
setblock 447 177 245 minecraft:andesite
fill 447 177 248 449 177 248 minecraft:tuff
setblock 447 177 249 minecraft:cobbled_deepslate
fill 447 177 252 447 190 253 minecraft:obsidian
setblock 448 177 242 minecraft:cobbled_deepslate
fill 448 177 245 450 177 245 minecraft:tuff
setblock 448 177 246 minecraft:andesite
fill 448 177 249 450 177 249 minecraft:tuff
setblock 448 177 250 minecraft:andesite
setblock 448 177 251 minecraft:cobbled_deepslate
fill 448 177 252 448 178 252 minecraft:tuff
fill 448 177 253 448 190 253 minecraft:obsidian
fill 449 177 242 449 179 242 minecraft:tuff
setblock 449 177 243 minecraft:andesite
setblock 449 177 244 minecraft:cobbled_deepslate
fill 449 177 246 449 179 246 minecraft:tuff
setblock 449 177 247 minecraft:andesite
fill 449 177 250 450 177 250 minecraft:tuff
setblock 449 177 251 minecraft:andesite
fill 450 177 243 451 177 243 minecraft:tuff
setblock 450 177 244 minecraft:andesite
setblock 450 177 246 minecraft:cobbled_deepslate
fill 450 177 247 452 177 247 minecraft:tuff
setblock 450 177 248 minecraft:andesite
fill 451 177 244 452 178 244 minecraft:tuff
setblock 451 177 245 minecraft:andesite
setblock 451 177 246 minecraft:tuff
setblock 451 177 248 minecraft:cobbled_deepslate
setblock 451 177 249 minecraft:andesite
fill 452 177 245 452 179 245 minecraft:tuff
setblock 452 177 246 minecraft:andesite
fill 452 177 248 452 178 248 minecraft:tuff
setblock 465 177 267 minecraft:white_concrete
setblock 423 178 231 minecraft:white_concrete
fill 423 178 248 423 192 248 minecraft:black_concrete
setblock 423 178 257 minecraft:white_concrete
fill 423 178 260 423 202 260 minecraft:black_concrete
setblock 424 178 270 minecraft:pearlescent_froglight
setblock 426 178 231 minecraft:light[level=15]
setblock 426 178 238 minecraft:light[level=12]
setblock 426 178 239 minecraft:light[level=15]
setblock 426 178 245 minecraft:light[level=12]
setblock 426 178 247 minecraft:light[level=15]
setblock 426 178 252 minecraft:light[level=12]
setblock 426 178 255 minecraft:light[level=15]
setblock 426 178 259 minecraft:light[level=12]
setblock 426 178 263 minecraft:light[level=15]
setblock 426 178 266 minecraft:light[level=12]
setblock 427 178 228 minecraft:ochre_froglight
setblock 429 178 228 minecraft:pearlescent_froglight
fill 429 178 270 429 195 270 minecraft:black_concrete
setblock 433 178 231 minecraft:light[level=12]
setblock 433 178 238 minecraft:light[level=12]
setblock 433 178 245 minecraft:light[level=12]
setblock 433 178 252 minecraft:light[level=12]
setblock 433 178 259 minecraft:light[level=12]
setblock 433 178 266 minecraft:light[level=12]
setblock 434 178 231 minecraft:light[level=15]
setblock 434 178 239 minecraft:light[level=15]
setblock 434 178 247 minecraft:light[level=15]
setblock 434 178 255 minecraft:light[level=15]
setblock 434 178 263 minecraft:light[level=15]
setblock 435 178 249 minecraft:cobbled_deepslate
setblock 435 178 250 minecraft:andesite
setblock 435 178 251 minecraft:tuff
fill 436 178 246 437 179 246 minecraft:tuff
setblock 436 178 247 minecraft:andesite
setblock 436 178 248 minecraft:tuff
fill 436 178 250 438 178 250 minecraft:tuff
setblock 436 178 251 minecraft:cobbled_deepslate
setblock 436 178 252 minecraft:tuff
setblock 437 178 245 minecraft:tuff
fill 437 178 247 439 178 247 minecraft:tuff
setblock 437 178 248 minecraft:andesite
fill 437 178 251 437 180 251 minecraft:tuff
setblock 437 178 252 minecraft:andesite
setblock 437 178 253 minecraft:cobbled_deepslate
fill 438 178 228 438 276 228 minecraft:black_concrete
fill 438 178 244 440 178 244 minecraft:tuff
setblock 438 178 245 minecraft:andesite
setblock 438 178 246 minecraft:cobbled_deepslate
fill 438 178 248 438 180 248 minecraft:tuff
setblock 438 178 249 minecraft:andesite
setblock 438 178 252 minecraft:tuff
setblock 438 178 253 minecraft:andesite
fill 439 178 245 441 178 245 minecraft:tuff
setblock 439 178 246 minecraft:andesite
setblock 439 178 248 minecraft:cobbled_deepslate
fill 439 178 249 441 178 249 minecraft:tuff
setblock 439 178 250 minecraft:andesite
setblock 439 178 251 minecraft:tuff
fill 439 178 253 439 180 253 minecraft:tuff
setblock 439 178 254 minecraft:andesite
setblock 440 178 231 minecraft:light[level=12]
setblock 440 178 238 minecraft:light[level=12]
setblock 440 178 243 minecraft:andesite
fill 440 178 246 442 178 246 minecraft:tuff
setblock 440 178 247 minecraft:andesite
setblock 440 178 248 minecraft:tuff
setblock 440 178 250 minecraft:cobbled_deepslate
setblock 440 178 251 minecraft:andesite
fill 440 178 254 440 189 255 minecraft:obsidian
setblock 440 178 259 minecraft:light[level=12]
setblock 440 178 266 minecraft:light[level=12]
setblock 441 178 243 minecraft:cobbled_deepslate
setblock 441 178 244 minecraft:andesite
fill 441 178 247 442 179 247 minecraft:tuff
setblock 441 178 248 minecraft:andesite
fill 441 178 255 441 189 256 minecraft:obsidian
setblock 442 178 231 minecraft:light[level=15]
setblock 442 178 239 minecraft:light[level=15]
fill 442 178 243 443 178 244 minecraft:tuff
setblock 442 178 245 minecraft:cobbled_deepslate
fill 442 178 248 444 178 248 minecraft:tuff
setblock 442 178 249 minecraft:andesite
setblock 442 178 263 minecraft:light[level=15]
fill 443 178 245 443 180 245 minecraft:tuff
setblock 443 178 246 minecraft:andesite
setblock 443 178 247 minecraft:cobbled_deepslate
fill 443 178 249 443 180 249 minecraft:tuff
fill 443 178 257 443 189 257 minecraft:obsidian
setblock 444 178 243 minecraft:andesite
fill 444 178 246 446 178 246 minecraft:tuff
setblock 444 178 247 minecraft:andesite
setblock 444 178 249 minecraft:cobbled_deepslate
setblock 445 178 242 minecraft:cobbled_deepslate
fill 445 178 243 447 178 243 minecraft:tuff
setblock 445 178 244 minecraft:andesite
setblock 445 178 245 minecraft:tuff
fill 445 178 247 447 178 247 minecraft:tuff
setblock 445 178 248 minecraft:andesite
setblock 445 178 249 minecraft:tuff
fill 445 178 257 446 189 257 minecraft:obsidian
setblock 446 178 242 minecraft:tuff
setblock 446 178 244 minecraft:cobbled_deepslate
setblock 446 178 245 minecraft:andesite
fill 446 178 248 447 179 248 minecraft:tuff
setblock 446 178 249 minecraft:andesite
setblock 446 178 250 minecraft:tuff
setblock 447 178 231 minecraft:light[level=12]
setblock 447 178 238 minecraft:light[level=12]
setblock 447 178 242 minecraft:andesite
fill 447 178 245 449 178 245 minecraft:tuff
setblock 447 178 246 minecraft:cobbled_deepslate
fill 447 178 249 449 178 249 minecraft:tuff
setblock 447 178 250 minecraft:andesite
fill 447 178 255 447 189 256 minecraft:obsidian
setblock 447 178 259 minecraft:light[level=12]
setblock 447 178 266 minecraft:light[level=12]
fill 448 178 241 448 179 242 minecraft:tuff
setblock 448 178 243 minecraft:andesite
fill 448 178 246 448 180 246 minecraft:tuff
setblock 448 178 247 minecraft:andesite
setblock 448 178 248 minecraft:cobbled_deepslate
fill 448 178 250 448 180 250 minecraft:tuff
setblock 448 178 251 minecraft:andesite
fill 448 178 254 448 190 255 minecraft:obsidian
setblock 449 178 241 minecraft:cobbled_deepslate
fill 449 178 243 449 180 243 minecraft:tuff
setblock 449 178 244 minecraft:andesite
fill 449 178 247 451 178 247 minecraft:tuff
setblock 449 178 248 minecraft:andesite
setblock 449 178 250 minecraft:cobbled_deepslate
fill 449 178 251 451 178 251 minecraft:tuff
setblock 449 178 252 minecraft:andesite
fill 449 178 253 449 178 254 minecraft:tuff
setblock 450 178 231 minecraft:light[level=15]
setblock 450 178 239 minecraft:light[level=15]
setblock 450 178 242 minecraft:tuff
setblock 450 178 243 minecraft:cobbled_deepslate
fill 450 178 244 450 180 244 minecraft:tuff
setblock 450 178 245 minecraft:andesite
setblock 450 178 246 minecraft:tuff
fill 450 178 248 451 179 248 minecraft:tuff
setblock 450 178 249 minecraft:andesite
setblock 450 178 250 minecraft:tuff
setblock 450 178 252 minecraft:cobbled_deepslate
setblock 450 178 255 minecraft:light[level=15]
setblock 450 178 263 minecraft:light[level=15]
setblock 451 178 242 minecraft:andesite
setblock 451 178 243 minecraft:tuff
setblock 451 178 245 minecraft:cobbled_deepslate
setblock 451 178 246 minecraft:andesite
fill 451 178 249 452 179 249 minecraft:tuff
setblock 451 178 250 minecraft:andesite
setblock 452 178 243 minecraft:andesite
fill 452 178 246 453 178 246 minecraft:tuff
setblock 452 178 247 minecraft:cobbled_deepslate
fill 452 178 250 452 179 250 minecraft:tuff
setblock 453 178 244 minecraft:andesite
setblock 453 178 245 minecraft:tuff
fill 453 178 247 453 180 247 minecraft:tuff
setblock 453 178 248 minecraft:andesite
setblock 454 178 231 minecraft:light[level=12]
setblock 454 178 238 minecraft:light[level=12]
setblock 454 178 245 minecraft:light[level=12]
setblock 454 178 252 minecraft:light[level=12]
setblock 454 178 259 minecraft:light[level=12]
setblock 454 178 266 minecraft:light[level=12]
setblock 458 178 231 minecraft:light[level=15]
setblock 458 178 239 minecraft:light[level=15]
setblock 458 178 247 minecraft:light[level=15]
setblock 458 178 255 minecraft:light[level=15]
setblock 458 178 263 minecraft:light[level=15]
setblock 461 178 231 minecraft:light[level=12]
setblock 461 178 238 minecraft:light[level=12]
setblock 461 178 245 minecraft:light[level=12]
setblock 461 178 252 minecraft:light[level=12]
setblock 461 178 259 minecraft:light[level=12]
setblock 461 178 266 minecraft:light[level=12]
fill 465 178 267 465 308 267 minecraft:black_concrete
fill 423 179 231 423 190 231 minecraft:black_concrete
fill 423 179 257 423 308 257 minecraft:black_concrete
fill 424 179 270 424 295 270 minecraft:black_concrete
fill 427 179 228 427 207 228 minecraft:black_concrete
setblock 428 179 270 minecraft:pearlescent_froglight
fill 429 179 228 429 228 228 minecraft:black_concrete
fill 434 179 249 436 179 249 minecraft:tuff
setblock 434 179 250 minecraft:andesite
setblock 434 179 251 minecraft:tuff
setblock 435 179 246 minecraft:cobbled_deepslate
setblock 435 179 247 minecraft:andesite
setblock 435 179 248 minecraft:tuff
fill 435 179 250 436 180 250 minecraft:tuff
setblock 435 179 251 minecraft:andesite
fill 435 179 252 435 179 253 minecraft:tuff
setblock 436 179 244 minecraft:andesite
setblock 436 179 245 minecraft:tuff
fill 436 179 247 438 179 247 minecraft:tuff
setblock 436 179 248 minecraft:cobbled_deepslate
fill 436 179 251 436 180 251 minecraft:tuff
setblock 436 179 252 minecraft:andesite
fill 436 179 253 436 179 254 minecraft:tuff
fill 437 179 244 439 179 244 minecraft:tuff
setblock 437 179 245 minecraft:andesite
fill 437 179 248 437 181 248 minecraft:tuff
setblock 437 179 249 minecraft:andesite
setblock 437 179 250 minecraft:cobbled_deepslate
fill 437 179 252 437 181 252 minecraft:tuff
setblock 437 179 253 minecraft:andesite
setblock 437 179 254 minecraft:tuff
setblock 438 179 243 minecraft:cobbled_deepslate
fill 438 179 245 438 181 245 minecraft:tuff
setblock 438 179 246 minecraft:andesite
fill 438 179 249 440 179 249 minecraft:tuff
setblock 438 179 250 minecraft:andesite
setblock 438 179 252 minecraft:cobbled_deepslate
fill 438 179 253 438 181 253 minecraft:tuff
setblock 438 179 254 minecraft:andesite
setblock 438 179 255 minecraft:tuff
setblock 438 179 270 minecraft:pearlescent_froglight
setblock 439 179 243 minecraft:andesite
setblock 439 179 245 minecraft:cobbled_deepslate
fill 439 179 246 441 179 246 minecraft:tuff
setblock 439 179 247 minecraft:andesite
setblock 439 179 248 minecraft:tuff
fill 439 179 250 441 179 250 minecraft:tuff
setblock 439 179 251 minecraft:andesite
setblock 439 179 252 minecraft:tuff
setblock 439 179 254 minecraft:cobbled_deepslate
setblock 439 179 255 minecraft:andesite
setblock 439 179 256 minecraft:tuff
fill 440 179 242 441 179 243 minecraft:tuff
setblock 440 179 244 minecraft:andesite
setblock 440 179 245 minecraft:tuff
setblock 440 179 247 minecraft:cobbled_deepslate
setblock 440 179 248 minecraft:andesite
fill 440 179 251 440 181 251 minecraft:tuff
setblock 440 179 252 minecraft:andesite
setblock 440 179 256 minecraft:cobbled_deepslate
setblock 440 179 257 minecraft:tuff
fill 441 179 244 442 180 244 minecraft:tuff
setblock 441 179 245 minecraft:andesite
fill 441 179 248 443 179 248 minecraft:tuff
setblock 441 179 249 minecraft:cobbled_deepslate
fill 441 179 257 442 189 257 minecraft:obsidian
setblock 442 179 242 minecraft:cobbled_deepslate
setblock 442 179 243 minecraft:tuff
fill 442 179 245 442 180 245 minecraft:tuff
setblock 442 179 246 minecraft:andesite
fill 442 179 249 442 181 249 minecraft:tuff
setblock 442 179 250 minecraft:andesite
setblock 442 179 258 minecraft:andesite
fill 443 179 242 445 179 242 minecraft:tuff
setblock 443 179 243 minecraft:andesite
setblock 443 179 244 minecraft:cobbled_deepslate
fill 443 179 246 443 181 246 minecraft:tuff
setblock 443 179 247 minecraft:andesite
fill 443 179 258 445 188 258 minecraft:obsidian
setblock 444 179 241 minecraft:tuff
fill 444 179 243 446 179 243 minecraft:tuff
setblock 444 179 244 minecraft:andesite
setblock 444 179 245 minecraft:tuff
setblock 444 179 246 minecraft:cobbled_deepslate
fill 444 179 247 446 179 247 minecraft:tuff
setblock 444 179 248 minecraft:andesite
setblock 444 179 249 minecraft:tuff
setblock 445 179 241 minecraft:andesite
fill 445 179 244 447 179 244 minecraft:tuff
setblock 445 179 245 minecraft:andesite
setblock 445 179 246 minecraft:tuff
setblock 445 179 248 minecraft:cobbled_deepslate
setblock 445 179 249 minecraft:andesite
setblock 446 179 241 minecraft:cobbled_deepslate
setblock 446 179 242 minecraft:andesite
fill 446 179 245 447 180 245 minecraft:tuff
setblock 446 179 246 minecraft:andesite
fill 446 179 249 448 179 249 minecraft:tuff
setblock 446 179 250 minecraft:cobbled_deepslate
setblock 446 179 258 minecraft:andesite
fill 447 179 241 447 180 242 minecraft:tuff
setblock 447 179 243 minecraft:cobbled_deepslate
fill 447 179 246 447 180 246 minecraft:tuff
setblock 447 179 247 minecraft:andesite
fill 447 179 250 447 181 250 minecraft:tuff
fill 447 179 257 447 188 257 minecraft:obsidian
fill 448 179 243 448 181 243 minecraft:tuff
setblock 448 179 244 minecraft:andesite
setblock 448 179 245 minecraft:cobbled_deepslate
fill 448 179 247 448 181 247 minecraft:tuff
setblock 448 179 248 minecraft:andesite
fill 448 179 251 450 179 251 minecraft:tuff
setblock 448 179 252 minecraft:andesite
setblock 448 179 256 minecraft:andesite
setblock 448 179 257 minecraft:tuff
setblock 449 179 241 minecraft:andesite
setblock 449 179 244 minecraft:tuff
setblock 449 179 245 minecraft:andesite
setblock 449 179 247 minecraft:cobbled_deepslate
fill 449 179 248 449 181 248 minecraft:tuff
setblock 449 179 249 minecraft:andesite
setblock 449 179 250 minecraft:tuff
fill 449 179 252 451 179 252 minecraft:tuff
setblock 449 179 253 minecraft:andesite
fill 449 179 254 449 179 255 minecraft:tuff
setblock 449 179 256 minecraft:cobbled_deepslate
fill 450 179 241 451 180 241 minecraft:tuff
setblock 450 179 242 minecraft:andesite
setblock 450 179 243 minecraft:tuff
fill 450 179 245 451 180 245 minecraft:tuff
setblock 450 179 246 minecraft:andesite
setblock 450 179 247 minecraft:tuff
setblock 450 179 249 minecraft:cobbled_deepslate
setblock 450 179 250 minecraft:andesite
fill 450 179 253 451 180 253 minecraft:tuff
setblock 450 179 254 minecraft:andesite
setblock 451 179 242 minecraft:cobbled_deepslate
setblock 451 179 243 minecraft:andesite
setblock 451 179 244 minecraft:tuff
fill 451 179 246 452 180 246 minecraft:tuff
setblock 451 179 247 minecraft:andesite
fill 451 179 250 451 181 250 minecraft:tuff
setblock 451 179 251 minecraft:cobbled_deepslate
fill 452 179 242 452 180 243 minecraft:tuff
setblock 452 179 244 minecraft:cobbled_deepslate
fill 452 179 247 452 180 247 minecraft:tuff
setblock 452 179 248 minecraft:andesite
fill 452 179 251 452 181 251 minecraft:tuff
setblock 452 179 252 minecraft:andesite
setblock 453 179 228 minecraft:white_concrete
fill 453 179 243 453 179 244 minecraft:tuff
setblock 453 179 245 minecraft:andesite
setblock 453 179 246 minecraft:cobbled_deepslate
fill 453 179 248 453 181 248 minecraft:tuff
setblock 453 179 249 minecraft:andesite
setblock 453 179 250 minecraft:tuff
setblock 454 179 245 minecraft:tuff
setblock 454 179 246 minecraft:andesite
setblock 454 179 247 minecraft:tuff
setblock 454 179 248 minecraft:cobbled_deepslate
setblock 461 179 228 minecraft:pearlescent_froglight
setblock 423 180 249 minecraft:ochre_froglight
setblock 423 180 255 minecraft:sea_lantern
fill 428 180 270 428 248 270 minecraft:black_concrete
fill 433 180 249 435 180 249 minecraft:tuff
setblock 434 180 247 minecraft:andesite
setblock 434 180 248 minecraft:tuff
setblock 434 180 250 minecraft:cobbled_deepslate
setblock 434 180 251 minecraft:andesite
setblock 434 180 252 minecraft:tuff
fill 435 180 245 435 180 247 minecraft:tuff
setblock 435 180 248 minecraft:andesite
fill 435 180 251 435 182 251 minecraft:tuff
setblock 435 180 252 minecraft:cobbled_deepslate
fill 435 180 253 435 180 254 minecraft:tuff
fill 436 180 243 437 180 244 minecraft:tuff
setblock 436 180 245 minecraft:cobbled_deepslate
fill 436 180 246 436 180 248 minecraft:tuff
setblock 436 180 249 minecraft:andesite
fill 436 180 252 436 182 252 minecraft:tuff
setblock 436 180 253 minecraft:andesite
setblock 436 180 254 minecraft:cobbled_deepslate
fill 436 180 255 437 180 255 minecraft:tuff
fill 437 180 245 437 182 245 minecraft:tuff
setblock 437 180 246 minecraft:andesite
setblock 437 180 247 minecraft:cobbled_deepslate
fill 437 180 249 437 182 249 minecraft:tuff
setblock 437 180 250 minecraft:andesite
setblock 437 180 253 minecraft:tuff
setblock 437 180 254 minecraft:andesite
setblock 437 180 256 minecraft:cobbled_deepslate
fill 438 180 242 438 182 242 minecraft:tuff
setblock 438 180 243 minecraft:andesite
setblock 438 180 244 minecraft:tuff
fill 438 180 246 440 180 246 minecraft:tuff
setblock 438 180 247 minecraft:andesite
setblock 438 180 249 minecraft:cobbled_deepslate
fill 438 180 250 440 180 250 minecraft:tuff
setblock 438 180 251 minecraft:andesite
setblock 438 180 252 minecraft:tuff
fill 438 180 254 439 181 254 minecraft:tuff
setblock 438 180 255 minecraft:andesite
fill 438 180 256 438 180 257 minecraft:tuff
fill 438 180 270 438 186 270 minecraft:black_concrete
setblock 439 180 242 minecraft:cobbled_deepslate
fill 439 180 243 441 180 243 minecraft:tuff
setblock 439 180 244 minecraft:andesite
setblock 439 180 245 minecraft:tuff
fill 439 180 247 441 180 247 minecraft:tuff
setblock 439 180 248 minecraft:andesite
setblock 439 180 249 minecraft:tuff
setblock 439 180 251 minecraft:cobbled_deepslate
setblock 439 180 252 minecraft:andesite
fill 439 180 255 439 182 255 minecraft:tuff
setblock 439 180 256 minecraft:andesite
setblock 439 180 257 minecraft:tuff
setblock 440 180 241 minecraft:andesite
setblock 440 180 242 minecraft:tuff
setblock 440 180 244 minecraft:cobbled_deepslate
setblock 440 180 245 minecraft:andesite
fill 440 180 248 441 181 248 minecraft:tuff
setblock 440 180 249 minecraft:andesite
fill 440 180 252 440 182 252 minecraft:tuff
fill 440 180 256 440 181 256 minecraft:tuff
setblock 440 180 257 minecraft:andesite
setblock 440 180 258 minecraft:tuff
fill 441 180 241 442 181 241 minecraft:tuff
setblock 441 180 242 minecraft:andesite
fill 441 180 245 441 182 245 minecraft:tuff
setblock 441 180 246 minecraft:cobbled_deepslate
fill 441 180 249 441 181 249 minecraft:tuff
setblock 441 180 250 minecraft:andesite
setblock 441 180 258 minecraft:andesite
fill 442 180 242 444 180 242 minecraft:tuff
setblock 442 180 243 minecraft:andesite
fill 442 180 246 442 182 246 minecraft:tuff
setblock 442 180 247 minecraft:andesite
setblock 442 180 248 minecraft:cobbled_deepslate
fill 442 180 250 442 182 250 minecraft:tuff
fill 442 180 258 442 182 258 minecraft:tuff
setblock 443 180 240 minecraft:andesite
setblock 443 180 241 minecraft:cobbled_deepslate
fill 443 180 243 443 182 243 minecraft:tuff
setblock 443 180 244 minecraft:andesite
fill 443 180 247 445 180 247 minecraft:tuff
setblock 443 180 248 minecraft:andesite
setblock 443 180 259 minecraft:cobbled_deepslate
fill 444 180 240 446 180 240 minecraft:tuff
setblock 444 180 241 minecraft:andesite
setblock 444 180 243 minecraft:cobbled_deepslate
fill 444 180 244 446 180 244 minecraft:tuff
setblock 444 180 245 minecraft:andesite
setblock 444 180 246 minecraft:tuff
fill 444 180 248 446 180 248 minecraft:tuff
setblock 444 180 249 minecraft:andesite
fill 444 180 259 445 180 259 minecraft:tuff
fill 445 180 241 446 181 241 minecraft:tuff
setblock 445 180 242 minecraft:andesite
setblock 445 180 243 minecraft:tuff
setblock 445 180 245 minecraft:cobbled_deepslate
setblock 445 180 246 minecraft:andesite
fill 445 180 249 446 181 249 minecraft:tuff
fill 446 180 242 446 182 242 minecraft:tuff
setblock 446 180 243 minecraft:andesite
fill 446 180 246 446 182 246 minecraft:tuff
setblock 446 180 247 minecraft:cobbled_deepslate
fill 446 180 250 446 181 250 minecraft:tuff
fill 446 180 258 446 182 258 minecraft:tuff
setblock 447 180 240 minecraft:cobbled_deepslate
fill 447 180 243 447 181 243 minecraft:tuff
setblock 447 180 244 minecraft:andesite
fill 447 180 247 447 182 247 minecraft:tuff
setblock 447 180 248 minecraft:andesite
setblock 447 180 249 minecraft:cobbled_deepslate
setblock 447 180 258 minecraft:cobbled_deepslate
fill 448 180 240 450 180 240 minecraft:tuff
setblock 448 180 241 minecraft:andesite
setblock 448 180 242 minecraft:cobbled_deepslate
fill 448 180 244 448 182 244 minecraft:tuff
setblock 448 180 245 minecraft:andesite
setblock 448 180 248 minecraft:tuff
setblock 448 180 249 minecraft:andesite
setblock 448 180 251 minecraft:cobbled_deepslate
fill 448 180 252 450 180 252 minecraft:tuff
fill 448 180 256 450 180 256 minecraft:tuff
setblock 448 180 257 minecraft:andesite
setblock 449 180 241 minecraft:tuff
setblock 449 180 242 minecraft:andesite
setblock 449 180 244 minecraft:cobbled_deepslate
fill 449 180 245 449 182 245 minecraft:tuff
setblock 449 180 246 minecraft:andesite
setblock 449 180 247 minecraft:tuff
fill 449 180 249 451 180 249 minecraft:tuff
setblock 449 180 250 minecraft:andesite
setblock 449 180 251 minecraft:tuff
setblock 449 180 253 minecraft:cobbled_deepslate
setblock 449 180 254 minecraft:andesite
setblock 449 180 255 minecraft:tuff
fill 449 180 257 449 182 257 minecraft:tuff
fill 450 180 242 451 181 242 minecraft:tuff
setblock 450 180 243 minecraft:andesite
setblock 450 180 246 minecraft:cobbled_deepslate
setblock 450 180 247 minecraft:andesite
setblock 450 180 248 minecraft:tuff
fill 450 180 250 450 182 250 minecraft:tuff
setblock 450 180 251 minecraft:andesite
fill 450 180 254 451 180 254 minecraft:tuff
setblock 450 180 255 minecraft:cobbled_deepslate
fill 451 180 243 451 182 243 minecraft:tuff
setblock 451 180 244 minecraft:andesite
fill 451 180 247 451 182 247 minecraft:tuff
setblock 451 180 248 minecraft:cobbled_deepslate
fill 451 180 251 451 181 251 minecraft:tuff
setblock 451 180 252 minecraft:andesite
fill 451 180 255 451 182 255 minecraft:tuff
setblock 452 180 241 minecraft:cobbled_deepslate
fill 452 180 244 454 180 244 minecraft:tuff
setblock 452 180 245 minecraft:andesite
fill 452 180 248 452 182 248 minecraft:tuff
setblock 452 180 249 minecraft:andesite
setblock 452 180 250 minecraft:cobbled_deepslate
fill 452 180 252 452 182 252 minecraft:tuff
setblock 452 180 253 minecraft:andesite
fill 453 180 228 453 226 228 minecraft:black_concrete
setblock 453 180 242 minecraft:andesite
setblock 453 180 243 minecraft:cobbled_deepslate
fill 453 180 245 453 182 245 minecraft:tuff
setblock 453 180 246 minecraft:andesite
fill 453 180 249 454 180 249 minecraft:tuff
setblock 453 180 250 minecraft:andesite
setblock 453 180 251 minecraft:tuff
setblock 453 180 252 minecraft:cobbled_deepslate
setblock 454 180 245 minecraft:cobbled_deepslate
fill 454 180 246 454 182 246 minecraft:tuff
setblock 454 180 247 minecraft:andesite
setblock 454 180 248 minecraft:tuff
fill 454 180 250 454 182 250 minecraft:tuff
fill 461 180 228 461 196 228 minecraft:black_concrete
setblock 465 180 243 minecraft:pearlescent_froglight
setblock 465 180 257 minecraft:blue_concrete
setblock 465 180 260 minecraft:ochre_froglight
fill 423 181 249 423 277 249 minecraft:black_concrete
fill 423 181 255 423 305 255 minecraft:black_concrete
setblock 423 181 258 minecraft:ochre_froglight
fill 433 181 249 434 181 250 minecraft:tuff
setblock 433 181 251 minecraft:andesite
setblock 433 181 270 minecraft:sea_lantern
fill 434 181 246 435 181 246 minecraft:tuff
setblock 434 181 247 minecraft:cobbled_deepslate
setblock 434 181 248 minecraft:andesite
fill 434 181 251 434 183 251 minecraft:tuff
setblock 434 181 252 minecraft:andesite
fill 434 181 253 434 181 254 minecraft:tuff
fill 435 181 244 436 182 244 minecraft:tuff
setblock 435 181 245 minecraft:andesite
fill 435 181 247 436 181 248 minecraft:tuff
setblock 435 181 249 minecraft:cobbled_deepslate
setblock 435 181 250 minecraft:tuff
fill 435 181 252 435 182 252 minecraft:tuff
setblock 435 181 253 minecraft:andesite
fill 435 181 254 435 181 255 minecraft:tuff
setblock 436 181 243 minecraft:tuff
fill 436 181 245 436 182 245 minecraft:tuff
setblock 436 181 246 minecraft:andesite
fill 436 181 249 436 183 249 minecraft:tuff
setblock 436 181 250 minecraft:andesite
setblock 436 181 251 minecraft:cobbled_deepslate
fill 436 181 253 436 183 253 minecraft:tuff
setblock 436 181 254 minecraft:andesite
fill 436 181 255 436 181 256 minecraft:tuff
fill 437 181 242 437 183 242 minecraft:tuff
setblock 437 181 243 minecraft:andesite
setblock 437 181 244 minecraft:cobbled_deepslate
fill 437 181 246 437 183 246 minecraft:tuff
setblock 437 181 247 minecraft:andesite
fill 437 181 250 439 181 250 minecraft:tuff
setblock 437 181 251 minecraft:andesite
setblock 437 181 253 minecraft:cobbled_deepslate
fill 437 181 254 437 183 254 minecraft:tuff
setblock 437 181 255 minecraft:andesite
fill 437 181 256 437 181 257 minecraft:tuff
setblock 438 181 241 minecraft:tuff
fill 438 181 243 440 181 243 minecraft:tuff
setblock 438 181 244 minecraft:andesite
setblock 438 181 246 minecraft:cobbled_deepslate
fill 438 181 247 440 181 247 minecraft:tuff
setblock 438 181 248 minecraft:andesite
setblock 438 181 249 minecraft:tuff
fill 438 181 251 439 182 251 minecraft:tuff
setblock 438 181 252 minecraft:andesite
setblock 438 181 255 minecraft:cobbled_deepslate
setblock 438 181 256 minecraft:andesite
fill 438 181 257 438 181 258 minecraft:tuff
setblock 439 181 241 minecraft:andesite
setblock 439 181 242 minecraft:tuff
fill 439 181 244 441 181 244 minecraft:tuff
setblock 439 181 245 minecraft:andesite
setblock 439 181 246 minecraft:tuff
setblock 439 181 248 minecraft:cobbled_deepslate
setblock 439 181 249 minecraft:andesite
fill 439 181 252 439 183 252 minecraft:tuff
setblock 439 181 253 minecraft:andesite
fill 439 181 256 439 183 256 minecraft:tuff
setblock 439 181 257 minecraft:cobbled_deepslate
setblock 439 181 258 minecraft:tuff
fill 440 181 240 441 181 240 minecraft:tuff
setblock 440 181 241 minecraft:cobbled_deepslate
setblock 440 181 242 minecraft:andesite
fill 440 181 245 440 183 245 minecraft:tuff
setblock 440 181 246 minecraft:andesite
fill 440 181 249 440 183 249 minecraft:tuff
setblock 440 181 250 minecraft:cobbled_deepslate
fill 440 181 257 440 183 257 minecraft:tuff
setblock 440 181 258 minecraft:andesite
setblock 440 181 259 minecraft:cobbled_deepslate
fill 441 181 242 443 181 242 minecraft:tuff
setblock 441 181 243 minecraft:cobbled_deepslate
fill 441 181 246 441 182 246 minecraft:tuff
setblock 441 181 247 minecraft:andesite
fill 441 181 250 441 183 250 minecraft:tuff
setblock 441 181 258 minecraft:tuff
setblock 441 181 259 minecraft:andesite
setblock 442 181 240 minecraft:andesite
fill 442 181 243 442 183 243 minecraft:tuff
setblock 442 181 244 minecraft:andesite
setblock 442 181 245 minecraft:cobbled_deepslate
fill 442 181 247 442 183 247 minecraft:tuff
setblock 442 181 248 minecraft:andesite
fill 442 181 259 444 181 259 minecraft:tuff
fill 443 181 239 443 182 240 minecraft:tuff
setblock 443 181 241 minecraft:andesite
fill 443 181 244 445 181 244 minecraft:tuff
setblock 443 181 245 minecraft:andesite
setblock 443 181 247 minecraft:cobbled_deepslate
fill 443 181 248 445 181 248 minecraft:tuff
setblock 443 181 249 minecraft:andesite
setblock 444 181 239 minecraft:tuff
setblock 444 181 240 minecraft:cobbled_deepslate
fill 444 181 241 444 183 241 minecraft:tuff
setblock 444 181 242 minecraft:andesite
setblock 444 181 243 minecraft:tuff
fill 444 181 245 446 181 245 minecraft:tuff
setblock 444 181 246 minecraft:andesite
setblock 444 181 247 minecraft:tuff
setblock 444 181 249 minecraft:cobbled_deepslate
setblock 445 181 239 minecraft:andesite
setblock 445 181 240 minecraft:tuff
setblock 445 181 242 minecraft:cobbled_deepslate
setblock 445 181 243 minecraft:andesite
fill 445 181 246 445 183 246 minecraft:tuff
setblock 445 181 247 minecraft:andesite
setblock 445 181 259 minecraft:andesite
fill 446 181 239 447 182 239 minecraft:tuff
setblock 446 181 240 minecraft:andesite
fill 446 181 243 446 183 243 minecraft:tuff
setblock 446 181 244 minecraft:cobbled_deepslate
fill 446 181 247 446 182 247 minecraft:tuff
setblock 446 181 248 minecraft:andesite
setblock 446 181 259 minecraft:tuff
fill 447 181 240 449 181 240 minecraft:tuff
setblock 447 181 241 minecraft:andesite
setblock 447 181 242 minecraft:tuff
fill 447 181 244 447 183 244 minecraft:tuff
setblock 447 181 245 minecraft:andesite
setblock 447 181 246 minecraft:cobbled_deepslate
fill 447 181 248 447 183 248 minecraft:tuff
setblock 447 181 249 minecraft:andesite
setblock 447 181 258 minecraft:tuff
setblock 448 181 239 minecraft:cobbled_deepslate
fill 448 181 241 448 183 241 minecraft:tuff
setblock 448 181 242 minecraft:andesite
setblock 448 181 245 minecraft:tuff
setblock 448 181 246 minecraft:andesite
setblock 448 181 248 minecraft:cobbled_deepslate
fill 448 181 249 450 181 249 minecraft:tuff
setblock 448 181 250 minecraft:andesite
fill 448 181 251 448 181 252 minecraft:tuff
fill 448 181 256 449 181 256 minecraft:tuff
setblock 448 181 257 minecraft:cobbled_deepslate
setblock 448 181 258 minecraft:andesite
setblock 449 181 241 minecraft:cobbled_deepslate
fill 449 181 242 449 183 242 minecraft:tuff
setblock 449 181 243 minecraft:andesite
setblock 449 181 244 minecraft:tuff
fill 449 181 246 451 181 246 minecraft:tuff
setblock 449 181 247 minecraft:andesite
setblock 449 181 250 minecraft:cobbled_deepslate
setblock 449 181 251 minecraft:andesite
fill 449 181 252 449 181 254 minecraft:tuff
setblock 449 181 255 minecraft:andesite
setblock 450 181 240 minecraft:andesite
setblock 450 181 241 minecraft:tuff
setblock 450 181 243 minecraft:cobbled_deepslate
setblock 450 181 244 minecraft:andesite
setblock 450 181 245 minecraft:tuff
fill 450 181 247 450 183 247 minecraft:tuff
setblock 450 181 248 minecraft:andesite
fill 450 181 251 450 183 251 minecraft:tuff
setblock 450 181 252 minecraft:cobbled_deepslate
fill 450 181 253 450 181 255 minecraft:tuff
setblock 450 181 256 minecraft:andesite
setblock 450 181 257 minecraft:tuff
setblock 451 181 241 minecraft:andesite
fill 451 181 244 453 181 244 minecraft:tuff
setblock 451 181 245 minecraft:cobbled_deepslate
fill 451 181 248 451 182 248 minecraft:tuff
setblock 451 181 249 minecraft:andesite
fill 451 181 252 451 183 252 minecraft:tuff
setblock 451 181 253 minecraft:andesite
setblock 451 181 254 minecraft:cobbled_deepslate
fill 451 181 256 451 183 256 minecraft:tuff
fill 452 181 241 452 182 241 minecraft:tuff
setblock 452 181 242 minecraft:andesite
setblock 452 181 243 minecraft:tuff
fill 452 181 245 452 183 245 minecraft:tuff
setblock 452 181 246 minecraft:andesite
setblock 452 181 247 minecraft:cobbled_deepslate
fill 452 181 249 452 183 249 minecraft:tuff
setblock 452 181 250 minecraft:andesite
fill 452 181 253 453 181 253 minecraft:tuff
setblock 452 181 254 minecraft:andesite
setblock 452 181 255 minecraft:tuff
setblock 453 181 242 minecraft:tuff
setblock 453 181 243 minecraft:andesite
setblock 453 181 246 minecraft:tuff
setblock 453 181 247 minecraft:andesite
setblock 453 181 249 minecraft:cobbled_deepslate
fill 453 181 250 453 183 250 minecraft:tuff
setblock 453 181 251 minecraft:andesite
setblock 453 181 252 minecraft:tuff
fill 453 181 254 453 183 254 minecraft:tuff
setblock 454 181 244 minecraft:andesite
setblock 454 181 245 minecraft:tuff
fill 454 181 247 455 182 247 minecraft:tuff
setblock 454 181 248 minecraft:andesite
setblock 454 181 249 minecraft:tuff
setblock 454 181 251 minecraft:cobbled_deepslate
setblock 454 181 252 minecraft:andesite
fill 455 181 248 455 183 248 minecraft:tuff
setblock 455 181 249 minecraft:andesite
setblock 456 181 228 minecraft:pearlescent_froglight
setblock 465 181 235 minecraft:white_concrete
fill 465 181 243 465 205 243 minecraft:black_concrete
setblock 465 181 251 minecraft:sea_lantern
fill 465 181 257 465 188 257 minecraft:black_concrete
fill 465 181 260 465 239 260 minecraft:black_concrete
setblock 423 182 247 minecraft:pearlescent_froglight
fill 423 182 258 423 228 258 minecraft:black_concrete
setblock 426 182 270 minecraft:white_concrete
fill 433 182 247 435 182 247 minecraft:tuff
setblock 433 182 248 minecraft:andesite
fill 433 182 249 433 182 250 minecraft:tuff
setblock 433 182 251 minecraft:cobbled_deepslate
setblock 433 182 252 minecraft:andesite
fill 433 182 270 433 190 270 minecraft:black_concrete
setblock 434 182 245 minecraft:andesite
setblock 434 182 246 minecraft:tuff
fill 434 182 248 435 183 248 minecraft:tuff
setblock 434 182 249 minecraft:andesite
setblock 434 182 250 minecraft:tuff
fill 434 182 252 434 184 252 minecraft:tuff
setblock 434 182 253 minecraft:cobbled_deepslate
fill 434 182 254 434 182 255 minecraft:tuff
fill 435 182 245 435 184 245 minecraft:tuff
setblock 435 182 246 minecraft:cobbled_deepslate
fill 435 182 249 435 183 249 minecraft:tuff
setblock 435 182 250 minecraft:andesite
fill 435 182 253 435 184 253 minecraft:tuff
setblock 435 182 254 minecraft:andesite
setblock 435 182 255 minecraft:cobbled_deepslate
fill 435 182 256 436 182 256 minecraft:tuff
fill 436 182 242 436 183 242 minecraft:tuff
setblock 436 182 243 minecraft:andesite
fill 436 182 246 436 184 246 minecraft:tuff
setblock 436 182 247 minecraft:andesite
setblock 436 182 248 minecraft:cobbled_deepslate
fill 436 182 250 436 184 250 minecraft:tuff
setblock 436 182 251 minecraft:andesite
setblock 436 182 254 minecraft:tuff
setblock 436 182 255 minecraft:andesite
setblock 436 182 257 minecraft:cobbled_deepslate
setblock 437 182 241 minecraft:cobbled_deepslate
fill 437 182 243 437 184 243 minecraft:tuff
setblock 437 182 244 minecraft:andesite
fill 437 182 247 439 182 247 minecraft:tuff
setblock 437 182 248 minecraft:andesite
setblock 437 182 250 minecraft:cobbled_deepslate
fill 437 182 251 437 184 251 minecraft:tuff
setblock 437 182 252 minecraft:andesite
setblock 437 182 253 minecraft:tuff
fill 437 182 255 438 183 255 minecraft:tuff
setblock 437 182 256 minecraft:andesite
fill 437 182 257 437 182 258 minecraft:tuff
setblock 438 182 241 minecraft:andesite
setblock 438 182 243 minecraft:cobbled_deepslate
fill 438 182 244 440 182 244 minecraft:tuff
setblock 438 182 245 minecraft:andesite
setblock 438 182 246 minecraft:tuff
fill 438 182 248 440 182 248 minecraft:tuff
setblock 438 182 249 minecraft:andesite
setblock 438 182 250 minecraft:tuff
setblock 438 182 252 minecraft:cobbled_deepslate
setblock 438 182 253 minecraft:andesite
setblock 438 182 254 minecraft:tuff
fill 438 182 256 438 184 256 minecraft:tuff
setblock 438 182 257 minecraft:andesite
setblock 438 182 258 minecraft:tuff
fill 439 182 240 440 182 241 minecraft:tuff
setblock 439 182 242 minecraft:andesite
setblock 439 182 243 minecraft:tuff
setblock 439 182 245 minecraft:cobbled_deepslate
setblock 439 182 246 minecraft:andesite
fill 439 182 249 439 184 249 minecraft:tuff
setblock 439 182 250 minecraft:andesite
fill 439 182 253 439 184 253 minecraft:tuff
setblock 439 182 254 minecraft:cobbled_deepslate
fill 439 182 257 439 183 257 minecraft:tuff
setblock 439 182 258 minecraft:andesite
setblock 439 182 259 minecraft:tuff
fill 440 182 242 441 183 242 minecraft:tuff
setblock 440 182 243 minecraft:andesite
fill 440 182 246 440 184 246 minecraft:tuff
setblock 440 182 247 minecraft:cobbled_deepslate
fill 440 182 250 440 183 250 minecraft:tuff
setblock 440 182 251 minecraft:andesite
setblock 440 182 256 minecraft:cobbled_deepslate
fill 440 182 258 440 184 258 minecraft:tuff
setblock 440 182 259 minecraft:andesite
fill 441 182 239 442 182 239 minecraft:tuff
setblock 441 182 240 minecraft:cobbled_deepslate
setblock 441 182 241 minecraft:tuff
fill 441 182 243 441 183 243 minecraft:tuff
setblock 441 182 244 minecraft:andesite
fill 441 182 247 441 184 247 minecraft:tuff
setblock 441 182 248 minecraft:andesite
setblock 441 182 249 minecraft:cobbled_deepslate
setblock 441 182 258 minecraft:cobbled_deepslate
fill 441 182 259 443 182 259 minecraft:tuff
fill 442 182 240 442 184 240 minecraft:tuff
setblock 442 182 241 minecraft:andesite
setblock 442 182 242 minecraft:cobbled_deepslate
fill 442 182 244 442 184 244 minecraft:tuff
setblock 442 182 245 minecraft:andesite
fill 442 182 248 444 182 248 minecraft:tuff
setblock 442 182 249 minecraft:andesite
setblock 443 182 241 minecraft:tuff
setblock 443 182 242 minecraft:andesite
setblock 443 182 244 minecraft:cobbled_deepslate
fill 443 182 245 445 182 245 minecraft:tuff
setblock 443 182 246 minecraft:andesite
setblock 443 182 247 minecraft:tuff
fill 443 182 249 445 182 249 minecraft:tuff
fill 444 182 238 445 183 238 minecraft:tuff
setblock 444 182 239 minecraft:andesite
setblock 444 182 240 minecraft:tuff
fill 444 182 242 445 183 242 minecraft:tuff
setblock 444 182 243 minecraft:andesite
setblock 444 182 244 minecraft:tuff
setblock 444 182 246 minecraft:cobbled_deepslate
setblock 444 182 247 minecraft:andesite
setblock 444 182 259 minecraft:andesite
setblock 445 182 239 minecraft:cobbled_deepslate
setblock 445 182 240 minecraft:andesite
setblock 445 182 241 minecraft:tuff
fill 445 182 243 445 184 243 minecraft:tuff
setblock 445 182 244 minecraft:andesite
fill 445 182 247 445 184 247 minecraft:tuff
setblock 445 182 248 minecraft:cobbled_deepslate
fill 445 182 259 445 184 259 minecraft:tuff
fill 446 182 240 448 182 240 minecraft:tuff
setblock 446 182 241 minecraft:cobbled_deepslate
fill 446 182 244 446 183 244 minecraft:tuff
setblock 446 182 245 minecraft:andesite
fill 446 182 248 446 184 248 minecraft:tuff
setblock 446 182 249 minecraft:andesite
setblock 446 182 250 minecraft:cobbled_deepslate
setblock 446 182 259 minecraft:cobbled_deepslate
fill 447 182 241 447 184 241 minecraft:tuff
setblock 447 182 242 minecraft:andesite
setblock 447 182 243 minecraft:cobbled_deepslate
fill 447 182 245 447 184 245 minecraft:tuff
setblock 447 182 246 minecraft:andesite
fill 447 182 249 449 182 249 minecraft:tuff
setblock 447 182 250 minecraft:andesite
setblock 447 182 258 minecraft:andesite
setblock 447 182 259 minecraft:tuff
setblock 448 182 239 minecraft:andesite
setblock 448 182 242 minecraft:tuff
setblock 448 182 243 minecraft:andesite
setblock 448 182 245 minecraft:cobbled_deepslate
fill 448 182 246 450 182 246 minecraft:tuff
setblock 448 182 247 minecraft:andesite
setblock 448 182 248 minecraft:tuff
fill 448 182 250 449 183 250 minecraft:tuff
setblock 448 182 251 minecraft:andesite
setblock 448 182 252 minecraft:tuff
fill 448 182 256 448 182 258 minecraft:tuff
setblock 448 182 270 minecraft:magenta_terracotta
fill 449 182 239 449 184 239 minecraft:tuff
setblock 449 182 240 minecraft:andesite
setblock 449 182 241 minecraft:tuff
fill 449 182 243 450 183 243 minecraft:tuff
setblock 449 182 244 minecraft:andesite
setblock 449 182 247 minecraft:cobbled_deepslate
setblock 449 182 248 minecraft:andesite
fill 449 182 251 449 184 251 minecraft:tuff
setblock 449 182 252 minecraft:andesite
fill 449 182 253 449 182 255 minecraft:tuff
setblock 449 182 256 minecraft:cobbled_deepslate
fill 449 182 258 449 183 258 minecraft:tuff
setblock 450 182 240 minecraft:cobbled_deepslate
setblock 450 182 241 minecraft:andesite
setblock 450 182 242 minecraft:tuff
fill 450 182 244 451 183 244 minecraft:tuff
setblock 450 182 245 minecraft:andesite
fill 450 182 248 450 184 248 minecraft:tuff
setblock 450 182 249 minecraft:cobbled_deepslate
fill 450 182 252 450 183 252 minecraft:tuff
setblock 450 182 253 minecraft:andesite
fill 450 182 254 450 182 256 minecraft:tuff
setblock 450 182 257 minecraft:andesite
fill 451 182 241 451 184 241 minecraft:tuff
setblock 451 182 242 minecraft:cobbled_deepslate
fill 451 182 245 451 183 245 minecraft:tuff
setblock 451 182 246 minecraft:andesite
fill 451 182 249 451 184 249 minecraft:tuff
setblock 451 182 250 minecraft:andesite
setblock 451 182 251 minecraft:cobbled_deepslate
fill 451 182 253 451 184 253 minecraft:tuff
setblock 451 182 254 minecraft:andesite
setblock 451 182 257 minecraft:tuff
fill 452 182 242 452 184 242 minecraft:tuff
setblock 452 182 243 minecraft:andesite
setblock 452 182 244 minecraft:cobbled_deepslate
fill 452 182 246 452 184 246 minecraft:tuff
setblock 452 182 247 minecraft:andesite
setblock 452 182 250 minecraft:tuff
setblock 452 182 251 minecraft:andesite
setblock 452 182 253 minecraft:cobbled_deepslate
fill 452 182 254 452 184 254 minecraft:tuff
setblock 452 182 255 minecraft:andesite
setblock 452 182 256 minecraft:tuff
setblock 453 182 243 minecraft:tuff
setblock 453 182 244 minecraft:andesite
setblock 453 182 246 minecraft:cobbled_deepslate
fill 453 182 247 453 184 247 minecraft:tuff
setblock 453 182 248 minecraft:andesite
setblock 453 182 249 minecraft:tuff
fill 453 182 251 455 182 251 minecraft:tuff
setblock 453 182 252 minecraft:andesite
setblock 453 182 253 minecraft:tuff
setblock 453 182 255 minecraft:cobbled_deepslate
setblock 454 182 244 minecraft:tuff
setblock 454 182 245 minecraft:andesite
setblock 454 182 248 minecraft:cobbled_deepslate
setblock 454 182 249 minecraft:andesite
fill 454 182 252 454 184 252 minecraft:tuff
setblock 454 182 253 minecraft:andesite
setblock 455 182 228 minecraft:ochre_froglight
fill 455 182 249 455 184 249 minecraft:tuff
setblock 455 182 250 minecraft:cobbled_deepslate
fill 456 182 228 456 194 228 minecraft:black_concrete
setblock 464 182 270 minecraft:sea_lantern
fill 465 182 235 465 206 235 minecraft:black_concrete
setblock 465 182 236 minecraft:ochre_froglight
fill 465 182 251 465 244 251 minecraft:black_concrete
setblock 465 182 256 minecraft:white_concrete
setblock 465 182 258 minecraft:pearlescent_froglight
fill 423 183 247 423 184 247 minecraft:black_concrete
setblock 423 183 250 minecraft:pearlescent_froglight
setblock 425 183 228 minecraft:ochre_froglight
fill 426 183 270 426 226 270 minecraft:black_concrete
fill 433 183 247 434 183 247 minecraft:tuff
setblock 433 183 248 minecraft:cobbled_deepslate
fill 433 183 250 433 183 252 minecraft:tuff
setblock 433 183 253 minecraft:andesite
fill 434 183 245 434 184 245 minecraft:tuff
setblock 434 183 246 minecraft:andesite
fill 434 183 249 434 185 249 minecraft:tuff
setblock 434 183 250 minecraft:cobbled_deepslate
fill 434 183 253 434 184 253 minecraft:tuff
setblock 434 183 254 minecraft:andesite
setblock 434 183 255 minecraft:tuff
setblock 435 183 243 minecraft:cobbled_deepslate
setblock 435 183 244 minecraft:tuff
fill 435 183 246 435 184 246 minecraft:tuff
setblock 435 183 247 minecraft:andesite
fill 435 183 250 435 185 250 minecraft:tuff
setblock 435 183 251 minecraft:andesite
setblock 435 183 252 minecraft:cobbled_deepslate
fill 435 183 254 435 185 254 minecraft:tuff
setblock 435 183 255 minecraft:andesite
fill 435 183 256 435 183 257 minecraft:tuff
fill 436 183 243 436 185 243 minecraft:tuff
setblock 436 183 244 minecraft:andesite
setblock 436 183 245 minecraft:cobbled_deepslate
fill 436 183 247 436 185 247 minecraft:tuff
setblock 436 183 248 minecraft:andesite
setblock 436 183 251 minecraft:tuff
setblock 436 183 252 minecraft:andesite
setblock 436 183 254 minecraft:cobbled_deepslate
fill 436 183 255 436 185 255 minecraft:tuff
setblock 436 183 256 minecraft:andesite
fill 436 183 257 436 183 258 minecraft:tuff
setblock 437 183 241 minecraft:andesite
fill 437 183 244 439 183 244 minecraft:tuff
setblock 437 183 245 minecraft:andesite
setblock 437 183 247 minecraft:cobbled_deepslate
fill 437 183 248 439 183 248 minecraft:tuff
setblock 437 183 249 minecraft:andesite
setblock 437 183 250 minecraft:tuff
fill 437 183 252 438 184 252 minecraft:tuff
setblock 437 183 253 minecraft:andesite
setblock 437 183 256 minecraft:cobbled_deepslate
setblock 437 183 257 minecraft:andesite
setblock 437 183 258 minecraft:tuff
setblock 438 183 240 minecraft:cobbled_deepslate
fill 438 183 241 440 183 241 minecraft:tuff
setblock 438 183 242 minecraft:andesite
setblock 438 183 243 minecraft:tuff
fill 438 183 245 439 184 245 minecraft:tuff
setblock 438 183 246 minecraft:andesite
setblock 438 183 247 minecraft:tuff
setblock 438 183 249 minecraft:cobbled_deepslate
setblock 438 183 250 minecraft:andesite
setblock 438 183 251 minecraft:tuff
fill 438 183 253 438 185 253 minecraft:tuff
setblock 438 183 254 minecraft:andesite
fill 438 183 257 438 185 257 minecraft:tuff
setblock 438 183 258 minecraft:cobbled_deepslate
setblock 438 183 259 minecraft:tuff
setblock 439 183 240 minecraft:tuff
setblock 439 183 242 minecraft:cobbled_deepslate
setblock 439 183 243 minecraft:andesite
fill 439 183 246 439 185 246 minecraft:tuff
setblock 439 183 247 minecraft:andesite
fill 439 183 250 439 185 250 minecraft:tuff
setblock 439 183 251 minecraft:cobbled_deepslate
fill 439 183 254 439 184 254 minecraft:tuff
setblock 439 183 255 minecraft:andesite
fill 439 183 258 439 185 258 minecraft:tuff
setblock 439 183 259 minecraft:andesite
fill 440 183 239 441 184 239 minecraft:tuff
setblock 440 183 240 minecraft:andesite
fill 440 183 243 440 185 243 minecraft:tuff
setblock 440 183 244 minecraft:cobbled_deepslate
fill 440 183 247 440 184 247 minecraft:tuff
setblock 440 183 248 minecraft:andesite
fill 440 183 251 440 185 251 minecraft:tuff
setblock 440 183 252 minecraft:andesite
setblock 440 183 256 minecraft:andesite
fill 440 183 259 442 183 259 minecraft:tuff
fill 441 183 240 441 184 240 minecraft:tuff
setblock 441 183 241 minecraft:andesite
fill 441 183 244 441 185 244 minecraft:tuff
setblock 441 183 245 minecraft:andesite
setblock 441 183 246 minecraft:cobbled_deepslate
fill 441 183 248 441 185 248 minecraft:tuff
setblock 441 183 249 minecraft:andesite
setblock 441 183 258 minecraft:tuff
fill 441 183 260 443 183 260 minecraft:tuff
setblock 442 183 238 minecraft:andesite
setblock 442 183 239 minecraft:cobbled_deepslate
fill 442 183 241 442 185 241 minecraft:tuff
setblock 442 183 242 minecraft:andesite
fill 442 183 245 444 183 245 minecraft:tuff
setblock 442 183 246 minecraft:andesite
setblock 442 183 248 minecraft:cobbled_deepslate
fill 442 183 249 444 183 249 minecraft:tuff
setblock 442 183 250 minecraft:andesite
setblock 442 183 258 minecraft:andesite
setblock 443 183 238 minecraft:tuff
setblock 443 183 239 minecraft:andesite
setblock 443 183 240 minecraft:tuff
setblock 443 183 241 minecraft:cobbled_deepslate
fill 443 183 242 443 185 242 minecraft:tuff
setblock 443 183 243 minecraft:andesite
setblock 443 183 244 minecraft:tuff
fill 443 183 246 444 184 246 minecraft:tuff
setblock 443 183 247 minecraft:andesite
setblock 443 183 248 minecraft:tuff
setblock 443 183 259 minecraft:cobbled_deepslate
fill 444 183 239 446 183 239 minecraft:tuff
setblock 444 183 240 minecraft:andesite
setblock 444 183 243 minecraft:cobbled_deepslate
setblock 444 183 244 minecraft:andesite
fill 444 183 247 444 185 247 minecraft:tuff
setblock 444 183 248 minecraft:andesite
fill 444 183 259 444 185 259 minecraft:tuff
fill 445 183 240 446 184 240 minecraft:tuff
setblock 445 183 241 minecraft:andesite
fill 445 183 244 445 185 244 minecraft:tuff
setblock 445 183 245 minecraft:cobbled_deepslate
fill 445 183 248 445 184 248 minecraft:tuff
setblock 445 183 249 minecraft:andesite
setblock 445 183 270 minecraft:white_concrete
setblock 446 183 238 minecraft:cobbled_deepslate
fill 446 183 241 446 184 241 minecraft:tuff
setblock 446 183 242 minecraft:andesite
fill 446 183 245 446 185 245 minecraft:tuff
setblock 446 183 246 minecraft:andesite
setblock 446 183 247 minecraft:cobbled_deepslate
fill 446 183 249 446 185 249 minecraft:tuff
setblock 446 183 250 minecraft:andesite
setblock 446 183 258 minecraft:andesite
setblock 446 183 259 minecraft:tuff
fill 447 183 238 447 185 238 minecraft:tuff
setblock 447 183 239 minecraft:andesite
setblock 447 183 240 minecraft:cobbled_deepslate
fill 447 183 242 447 185 242 minecraft:tuff
setblock 447 183 243 minecraft:andesite
fill 447 183 246 449 183 246 minecraft:tuff
setblock 447 183 247 minecraft:andesite
setblock 447 183 249 minecraft:cobbled_deepslate
fill 447 183 250 447 185 250 minecraft:tuff
setblock 447 183 258 minecraft:cobbled_deepslate
setblock 447 183 259 minecraft:andesite
setblock 448 183 239 minecraft:tuff
setblock 448 183 240 minecraft:andesite
setblock 448 183 242 minecraft:cobbled_deepslate
fill 448 183 243 448 185 243 minecraft:tuff
setblock 448 183 244 minecraft:andesite
setblock 448 183 245 minecraft:tuff
fill 448 183 247 449 184 247 minecraft:tuff
setblock 448 183 248 minecraft:andesite
setblock 448 183 249 minecraft:tuff
setblock 448 183 251 minecraft:cobbled_deepslate
setblock 448 183 252 minecraft:andesite
setblock 448 183 256 minecraft:andesite
fill 448 183 257 448 183 258 minecraft:tuff
fill 448 183 270 448 188 270 minecraft:black_concrete
fill 449 183 240 450 184 240 minecraft:tuff
setblock 449 183 241 minecraft:andesite
setblock 449 183 244 minecraft:cobbled_deepslate
setblock 449 183 245 minecraft:andesite
fill 449 183 248 449 185 248 minecraft:tuff
setblock 449 183 249 minecraft:andesite
fill 449 183 252 449 185 252 minecraft:tuff
setblock 449 183 253 minecraft:cobbled_deepslate
fill 449 183 254 449 183 256 minecraft:tuff
setblock 449 183 257 minecraft:andesite
fill 450 183 241 450 185 241 minecraft:tuff
setblock 450 183 242 minecraft:andesite
fill 450 183 245 450 185 245 minecraft:tuff
setblock 450 183 246 minecraft:cobbled_deepslate
fill 450 183 249 450 184 249 minecraft:tuff
setblock 450 183 250 minecraft:andesite
fill 450 183 253 450 185 253 minecraft:tuff
setblock 450 183 254 minecraft:andesite
setblock 450 183 255 minecraft:cobbled_deepslate
fill 450 183 256 450 184 257 minecraft:tuff
setblock 450 183 258 minecraft:andesite
fill 451 183 242 451 184 242 minecraft:tuff
setblock 451 183 243 minecraft:andesite
fill 451 183 246 451 185 246 minecraft:tuff
setblock 451 183 247 minecraft:andesite
setblock 451 183 248 minecraft:cobbled_deepslate
fill 451 183 250 451 185 250 minecraft:tuff
setblock 451 183 251 minecraft:andesite
setblock 451 183 254 minecraft:tuff
setblock 451 183 255 minecraft:andesite
setblock 451 183 257 minecraft:cobbled_deepslate
fill 452 183 243 452 185 243 minecraft:tuff
setblock 452 183 244 minecraft:andesite
setblock 452 183 247 minecraft:tuff
setblock 452 183 248 minecraft:andesite
setblock 452 183 250 minecraft:cobbled_deepslate
fill 452 183 251 454 183 251 minecraft:tuff
setblock 452 183 252 minecraft:andesite
setblock 452 183 253 minecraft:tuff
fill 452 183 255 453 184 255 minecraft:tuff
setblock 452 183 256 minecraft:andesite
setblock 453 183 243 minecraft:cobbled_deepslate
fill 453 183 244 453 184 244 minecraft:tuff
setblock 453 183 245 minecraft:andesite
setblock 453 183 246 minecraft:tuff
fill 453 183 248 454 184 248 minecraft:tuff
setblock 453 183 249 minecraft:andesite
setblock 453 183 252 minecraft:cobbled_deepslate
setblock 453 183 253 minecraft:andesite
setblock 454 183 245 minecraft:cobbled_deepslate
setblock 454 183 246 minecraft:andesite
setblock 454 183 247 minecraft:tuff
fill 454 183 249 454 185 249 minecraft:tuff
setblock 454 183 250 minecraft:andesite
fill 454 183 253 454 185 253 minecraft:tuff
setblock 454 183 254 minecraft:cobbled_deepslate
fill 455 183 228 455 211 228 minecraft:black_concrete
setblock 455 183 247 minecraft:cobbled_deepslate
fill 455 183 250 455 184 250 minecraft:tuff
setblock 455 183 251 minecraft:andesite
setblock 455 183 252 minecraft:tuff
setblock 459 183 270 minecraft:ochre_froglight
fill 464 183 270 464 250 270 minecraft:black_concrete
fill 465 183 236 465 218 236 minecraft:black_concrete
setblock 465 183 247 minecraft:pearlescent_froglight
fill 465 183 256 465 198 256 minecraft:black_concrete
fill 465 183 258 465 229 258 minecraft:black_concrete
fill 423 184 250 423 195 250 minecraft:black_concrete
fill 425 184 228 425 200 228 minecraft:black_concrete
setblock 426 184 231 minecraft:light[level=12]
setblock 426 184 238 minecraft:light[level=12]
setblock 426 184 245 minecraft:light[level=12]
setblock 426 184 252 minecraft:light[level=12]
setblock 426 184 259 minecraft:light[level=12]
setblock 426 184 266 minecraft:light[level=12]
setblock 428 184 228 minecraft:sea_lantern
setblock 433 184 231 minecraft:light[level=12]
setblock 433 184 238 minecraft:light[level=12]
setblock 433 184 245 minecraft:light[level=12]
fill 433 184 247 433 184 248 minecraft:tuff
setblock 433 184 252 minecraft:tuff
setblock 433 184 259 minecraft:light[level=12]
setblock 433 184 266 minecraft:light[level=12]
fill 434 184 246 434 186 246 minecraft:tuff
setblock 434 184 247 minecraft:cobbled_deepslate
setblock 434 184 248 minecraft:tuff
fill 434 184 250 434 185 250 minecraft:tuff
setblock 434 184 251 minecraft:andesite
fill 434 184 254 434 186 254 minecraft:tuff
setblock 434 184 255 minecraft:andesite
setblock 434 184 256 minecraft:cobbled_deepslate
setblock 435 184 244 minecraft:andesite
fill 435 184 247 435 186 247 minecraft:tuff
setblock 435 184 248 minecraft:andesite
setblock 435 184 249 minecraft:cobbled_deepslate
fill 435 184 251 435 186 251 minecraft:tuff
setblock 435 184 252 minecraft:andesite
setblock 435 184 255 minecraft:tuff
setblock 435 184 256 minecraft:andesite
setblock 435 184 257 minecraft:tuff
setblock 436 184 242 minecraft:cobbled_deepslate
fill 436 184 244 436 186 244 minecraft:tuff
setblock 436 184 245 minecraft:andesite
fill 436 184 248 438 184 248 minecraft:tuff
setblock 436 184 249 minecraft:andesite
setblock 436 184 251 minecraft:cobbled_deepslate
fill 436 184 252 436 186 252 minecraft:tuff
setblock 436 184 253 minecraft:andesite
setblock 436 184 254 minecraft:tuff
fill 436 184 256 437 185 256 minecraft:tuff
setblock 436 184 257 minecraft:andesite
setblock 436 184 258 minecraft:tuff
fill 437 184 241 439 184 241 minecraft:tuff
setblock 437 184 242 minecraft:andesite
setblock 437 184 244 minecraft:cobbled_deepslate
fill 437 184 245 437 186 245 minecraft:tuff
setblock 437 184 246 minecraft:andesite
setblock 437 184 247 minecraft:tuff
fill 437 184 249 438 185 249 minecraft:tuff
setblock 437 184 250 minecraft:andesite
setblock 437 184 253 minecraft:cobbled_deepslate
setblock 437 184 254 minecraft:andesite
setblock 437 184 255 minecraft:tuff
fill 437 184 257 437 186 257 minecraft:tuff
setblock 437 184 258 minecraft:andesite
setblock 437 184 259 minecraft:tuff
setblock 438 184 240 minecraft:tuff
fill 438 184 242 440 184 242 minecraft:tuff
setblock 438 184 243 minecraft:andesite
setblock 438 184 244 minecraft:tuff
setblock 438 184 246 minecraft:cobbled_deepslate
setblock 438 184 247 minecraft:andesite
fill 438 184 250 438 186 250 minecraft:tuff
setblock 438 184 251 minecraft:andesite
fill 438 184 254 438 186 254 minecraft:tuff
setblock 438 184 255 minecraft:cobbled_deepslate
fill 438 184 258 438 185 258 minecraft:tuff
setblock 438 184 259 minecraft:andesite
setblock 439 184 239 minecraft:cobbled_deepslate
setblock 439 184 240 minecraft:andesite
fill 439 184 243 439 186 243 minecraft:tuff
setblock 439 184 244 minecraft:andesite
fill 439 184 247 439 186 247 minecraft:tuff
setblock 439 184 248 minecraft:cobbled_deepslate
fill 439 184 251 439 185 251 minecraft:tuff
setblock 439 184 252 minecraft:andesite
fill 439 184 255 439 186 255 minecraft:tuff
setblock 439 184 256 minecraft:andesite
setblock 439 184 257 minecraft:cobbled_deepslate
fill 439 184 259 439 186 259 minecraft:tuff
setblock 440 184 231 minecraft:light[level=12]
setblock 440 184 238 minecraft:light[level=12]
fill 440 184 240 440 186 240 minecraft:tuff
setblock 440 184 241 minecraft:cobbled_deepslate
fill 440 184 244 440 185 244 minecraft:tuff
setblock 440 184 245 minecraft:andesite
fill 440 184 248 440 186 248 minecraft:tuff
setblock 440 184 249 minecraft:andesite
setblock 440 184 250 minecraft:cobbled_deepslate
fill 440 184 252 440 186 252 minecraft:tuff
setblock 440 184 256 minecraft:tuff
setblock 440 184 257 minecraft:andesite
setblock 440 184 259 minecraft:cobbled_deepslate
fill 440 184 260 442 184 260 minecraft:tuff
setblock 440 184 266 minecraft:light[level=12]
setblock 441 184 238 minecraft:andesite
fill 441 184 241 441 186 241 minecraft:tuff
setblock 441 184 242 minecraft:andesite
setblock 441 184 243 minecraft:cobbled_deepslate
fill 441 184 245 441 186 245 minecraft:tuff
setblock 441 184 246 minecraft:andesite
fill 441 184 249 443 184 249 minecraft:tuff
setblock 441 184 250 minecraft:andesite
setblock 441 184 258 minecraft:andesite
setblock 441 184 259 minecraft:tuff
fill 442 184 238 442 186 238 minecraft:tuff
setblock 442 184 239 minecraft:andesite
setblock 442 184 242 minecraft:tuff
setblock 442 184 243 minecraft:andesite
setblock 442 184 245 minecraft:cobbled_deepslate
fill 442 184 246 442 186 246 minecraft:tuff
setblock 442 184 247 minecraft:andesite
setblock 442 184 248 minecraft:tuff
fill 442 184 250 442 186 250 minecraft:tuff
fill 442 184 258 442 186 258 minecraft:tuff
setblock 442 184 259 minecraft:andesite
setblock 443 184 238 minecraft:cobbled_deepslate
fill 443 184 239 445 184 239 minecraft:tuff
setblock 443 184 240 minecraft:andesite
setblock 443 184 241 minecraft:tuff
fill 443 184 243 444 185 243 minecraft:tuff
setblock 443 184 244 minecraft:andesite
setblock 443 184 245 minecraft:tuff
setblock 443 184 247 minecraft:cobbled_deepslate
setblock 443 184 248 minecraft:andesite
fill 443 184 259 443 185 259 minecraft:tuff
setblock 443 184 260 minecraft:andesite
setblock 444 184 238 minecraft:tuff
setblock 444 184 240 minecraft:cobbled_deepslate
setblock 444 184 241 minecraft:andesite
setblock 444 184 242 minecraft:tuff
fill 444 184 244 444 186 244 minecraft:tuff
setblock 444 184 245 minecraft:andesite
fill 444 184 248 444 186 248 minecraft:tuff
setblock 444 184 249 minecraft:cobbled_deepslate
setblock 445 184 238 minecraft:andesite
fill 445 184 241 445 186 241 minecraft:tuff
setblock 445 184 242 minecraft:cobbled_deepslate
fill 445 184 245 445 185 245 minecraft:tuff
setblock 445 184 246 minecraft:andesite
fill 445 184 249 445 186 249 minecraft:tuff
fill 445 184 270 445 302 270 minecraft:black_concrete
fill 446 184 238 446 185 238 minecraft:tuff
setblock 446 184 239 minecraft:andesite
fill 446 184 242 446 186 242 minecraft:tuff
setblock 446 184 243 minecraft:andesite
setblock 446 184 244 minecraft:cobbled_deepslate
fill 446 184 246 446 186 246 minecraft:tuff
setblock 446 184 247 minecraft:andesite
setblock 446 184 250 minecraft:tuff
fill 446 184 258 448 184 258 minecraft:tuff
setblock 446 184 259 minecraft:andesite
setblock 447 184 231 minecraft:light[level=12]
fill 447 184 239 447 186 239 minecraft:tuff
setblock 447 184 240 minecraft:andesite
setblock 447 184 243 minecraft:tuff
setblock 447 184 244 minecraft:andesite
setblock 447 184 246 minecraft:cobbled_deepslate
fill 447 184 247 447 186 247 minecraft:tuff
setblock 447 184 248 minecraft:andesite
setblock 447 184 249 minecraft:tuff
fill 447 184 259 447 185 259 minecraft:tuff
setblock 447 184 266 minecraft:light[level=12]
setblock 448 184 239 minecraft:cobbled_deepslate
fill 448 184 240 448 186 240 minecraft:tuff
setblock 448 184 241 minecraft:andesite
setblock 448 184 242 minecraft:tuff
fill 448 184 244 450 184 244 minecraft:tuff
setblock 448 184 245 minecraft:andesite
setblock 448 184 246 minecraft:tuff
setblock 448 184 248 minecraft:cobbled_deepslate
setblock 448 184 249 minecraft:andesite
fill 448 184 250 448 184 252 minecraft:tuff
fill 448 184 256 449 184 256 minecraft:tuff
setblock 448 184 257 minecraft:cobbled_deepslate
setblock 449 184 241 minecraft:cobbled_deepslate
setblock 449 184 242 minecraft:andesite
setblock 449 184 243 minecraft:tuff
fill 449 184 245 449 186 245 minecraft:tuff
setblock 449 184 246 minecraft:andesite
fill 449 184 249 449 186 249 minecraft:tuff
setblock 449 184 250 minecraft:cobbled_deepslate
fill 449 184 253 449 185 253 minecraft:tuff
setblock 449 184 254 minecraft:andesite
setblock 449 184 255 minecraft:tuff
fill 449 184 257 449 186 257 minecraft:tuff
setblock 449 184 258 minecraft:andesite
fill 450 184 242 450 186 242 minecraft:tuff
setblock 450 184 243 minecraft:cobbled_deepslate
fill 450 184 246 450 185 246 minecraft:tuff
setblock 450 184 247 minecraft:andesite
fill 450 184 250 450 186 250 minecraft:tuff
setblock 450 184 251 minecraft:andesite
setblock 450 184 252 minecraft:cobbled_deepslate
fill 450 184 254 450 186 254 minecraft:tuff
setblock 450 184 255 minecraft:andesite
setblock 450 184 258 minecraft:tuff
fill 451 184 243 451 186 243 minecraft:tuff
setblock 451 184 244 minecraft:andesite
setblock 451 184 245 minecraft:cobbled_deepslate
fill 451 184 247 451 186 247 minecraft:tuff
setblock 451 184 248 minecraft:andesite
fill 451 184 251 453 184 251 minecraft:tuff
setblock 451 184 252 minecraft:andesite
schedule function dropper:buildpart/57_3 1t
