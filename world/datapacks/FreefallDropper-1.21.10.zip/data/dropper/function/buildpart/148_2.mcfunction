fill 189 211 629 189 211 634 minecraft:black_concrete
fill 189 211 637 189 211 642 minecraft:black_concrete
setblock 229 211 644 minecraft:black_concrete
fill 213 213 617 215 214 617 minecraft:yellow_concrete
fill 214 213 616 214 214 616 minecraft:yellow_concrete
fill 214 213 618 214 214 618 minecraft:yellow_concrete
fill 188 214 609 188 219 609 minecraft:sea_lantern
fill 188 214 617 188 219 617 minecraft:sea_lantern
fill 188 214 625 188 219 625 minecraft:sea_lantern
fill 188 214 633 188 219 633 minecraft:sea_lantern
fill 188 214 641 188 219 641 minecraft:sea_lantern
setblock 191 214 607 minecraft:light[level=14]
setblock 191 214 615 minecraft:light[level=14]
setblock 191 214 623 minecraft:light[level=14]
setblock 191 214 631 minecraft:light[level=14]
setblock 191 214 639 minecraft:light[level=14]
fill 191 214 646 191 219 646 minecraft:sea_lantern
fill 195 214 604 195 219 604 minecraft:sea_lantern
setblock 199 214 607 minecraft:light[level=14]
setblock 199 214 615 minecraft:light[level=14]
setblock 199 214 623 minecraft:light[level=14]
setblock 199 214 631 minecraft:light[level=14]
setblock 199 214 639 minecraft:light[level=14]
fill 199 214 646 199 219 646 minecraft:sea_lantern
fill 203 214 604 203 219 604 minecraft:sea_lantern
setblock 207 214 607 minecraft:light[level=14]
setblock 207 214 615 minecraft:light[level=14]
setblock 207 214 623 minecraft:light[level=14]
setblock 207 214 631 minecraft:light[level=14]
setblock 207 214 639 minecraft:light[level=14]
fill 207 214 646 207 219 646 minecraft:sea_lantern
fill 211 214 604 211 219 604 minecraft:sea_lantern
fill 214 214 631 214 215 632 minecraft:magenta_concrete
setblock 215 214 607 minecraft:light[level=14]
setblock 215 214 615 minecraft:light[level=14]
setblock 215 214 623 minecraft:light[level=14]
setblock 215 214 631 minecraft:light[level=14]
setblock 215 214 639 minecraft:light[level=14]
fill 215 214 646 215 219 646 minecraft:sea_lantern
fill 219 214 604 219 219 604 minecraft:sea_lantern
setblock 223 214 607 minecraft:light[level=14]
setblock 223 214 615 minecraft:light[level=14]
setblock 223 214 623 minecraft:light[level=14]
setblock 223 214 631 minecraft:light[level=14]
setblock 223 214 639 minecraft:light[level=14]
fill 223 214 646 223 219 646 minecraft:sea_lantern
fill 227 214 604 227 219 604 minecraft:sea_lantern
fill 230 214 609 230 219 609 minecraft:sea_lantern
fill 230 214 617 230 219 617 minecraft:sea_lantern
fill 230 214 625 230 219 625 minecraft:sea_lantern
fill 230 214 633 230 219 633 minecraft:sea_lantern
fill 230 214 641 230 219 641 minecraft:sea_lantern
fill 226 216 610 226 221 610 minecraft:white_concrete
fill 227 218 610 227 221 610 minecraft:white_concrete
fill 225 219 610 225 221 610 minecraft:white_concrete
fill 226 219 609 227 221 609 minecraft:white_concrete
fill 226 219 611 227 221 611 minecraft:white_concrete
fill 188 220 609 188 227 609 minecraft:magenta_concrete
fill 188 220 617 188 227 617 minecraft:magenta_concrete
fill 188 220 625 188 227 625 minecraft:magenta_concrete
fill 188 220 633 188 227 633 minecraft:magenta_concrete
fill 188 220 641 188 227 641 minecraft:magenta_concrete
fill 191 220 646 191 227 646 minecraft:magenta_concrete
fill 195 220 604 195 227 604 minecraft:magenta_concrete
fill 199 220 646 199 227 646 minecraft:magenta_concrete
fill 203 220 604 203 227 604 minecraft:magenta_concrete
fill 207 220 646 207 227 646 minecraft:magenta_concrete
fill 211 220 604 211 227 604 minecraft:magenta_concrete
fill 215 220 646 215 227 646 minecraft:magenta_concrete
fill 219 220 604 219 227 604 minecraft:magenta_concrete
fill 223 220 646 223 227 646 minecraft:magenta_concrete
fill 227 220 604 227 227 604 minecraft:magenta_concrete
fill 230 220 609 230 227 609 minecraft:magenta_concrete
fill 230 220 617 230 227 617 minecraft:magenta_concrete
fill 230 220 625 230 227 625 minecraft:magenta_concrete
fill 230 220 633 230 227 633 minecraft:magenta_concrete
fill 230 220 641 230 227 641 minecraft:magenta_concrete
setblock 225 221 609 minecraft:white_concrete
setblock 225 221 611 minecraft:white_concrete
setblock 228 221 610 minecraft:white_concrete
setblock 191 222 607 minecraft:light[level=14]
setblock 191 222 615 minecraft:light[level=14]
setblock 191 222 623 minecraft:light[level=14]
setblock 191 222 631 minecraft:light[level=14]
setblock 191 222 639 minecraft:light[level=14]
setblock 199 222 607 minecraft:light[level=14]
setblock 199 222 615 minecraft:light[level=14]
setblock 199 222 623 minecraft:light[level=14]
setblock 199 222 631 minecraft:light[level=14]
setblock 199 222 639 minecraft:light[level=14]
setblock 207 222 607 minecraft:light[level=14]
setblock 207 222 615 minecraft:light[level=14]
setblock 207 222 623 minecraft:light[level=14]
setblock 207 222 631 minecraft:light[level=14]
setblock 207 222 639 minecraft:light[level=14]
setblock 215 222 607 minecraft:light[level=14]
setblock 215 222 615 minecraft:light[level=14]
setblock 215 222 623 minecraft:light[level=14]
setblock 215 222 631 minecraft:light[level=14]
setblock 215 222 639 minecraft:light[level=14]
setblock 223 222 607 minecraft:light[level=14]
setblock 223 222 615 minecraft:light[level=14]
setblock 223 222 623 minecraft:light[level=14]
setblock 223 222 631 minecraft:light[level=14]
setblock 223 222 639 minecraft:light[level=14]
fill 224 222 605 228 232 616 minecraft:black_concrete
fill 229 222 605 229 232 605 minecraft:black_concrete
fill 229 222 608 229 232 613 minecraft:black_concrete
fill 229 222 616 229 232 616 minecraft:black_concrete
fill 189 224 605 189 225 610 minecraft:black_concrete
fill 189 224 613 190 224 618 minecraft:black_concrete
fill 189 224 621 190 224 626 minecraft:black_concrete
fill 189 224 629 190 224 634 minecraft:black_concrete
fill 189 224 637 190 224 642 minecraft:black_concrete
fill 189 224 645 194 225 645 minecraft:black_concrete
fill 190 224 606 190 224 612 minecraft:black_concrete
fill 190 224 619 190 224 620 minecraft:black_concrete
fill 190 224 627 190 224 628 minecraft:black_concrete
fill 190 224 635 190 224 636 minecraft:black_concrete
fill 190 224 643 190 224 644 minecraft:black_concrete
fill 191 224 606 223 224 606 minecraft:black_concrete
fill 191 224 644 229 224 644 minecraft:black_concrete
fill 192 224 605 197 225 605 minecraft:black_concrete
fill 197 224 645 202 225 645 minecraft:black_concrete
fill 200 224 605 205 225 605 minecraft:black_concrete
fill 205 224 645 210 225 645 minecraft:black_concrete
fill 208 224 605 213 225 605 minecraft:black_concrete
fill 213 224 645 218 225 645 minecraft:black_concrete
fill 216 224 605 221 225 605 minecraft:black_concrete
fill 221 224 645 226 225 645 minecraft:black_concrete
fill 228 224 617 228 224 643 minecraft:black_concrete
fill 229 224 617 229 225 621 minecraft:black_concrete
fill 229 224 624 229 225 629 minecraft:black_concrete
fill 229 224 632 229 225 637 minecraft:black_concrete
fill 229 224 640 229 225 643 minecraft:black_concrete
fill 229 224 645 229 225 645 minecraft:black_concrete
fill 189 225 613 189 225 618 minecraft:black_concrete
fill 189 225 621 189 225 626 minecraft:black_concrete
fill 189 225 629 189 225 634 minecraft:black_concrete
fill 189 225 637 189 225 642 minecraft:black_concrete
setblock 229 225 644 minecraft:black_concrete
fill 188 228 609 188 232 609 minecraft:sea_lantern
fill 188 228 617 188 232 617 minecraft:sea_lantern
fill 188 228 625 188 232 625 minecraft:sea_lantern
fill 188 228 633 188 232 633 minecraft:sea_lantern
fill 188 228 641 188 232 641 minecraft:sea_lantern
fill 191 228 646 191 232 646 minecraft:sea_lantern
fill 195 228 604 195 232 604 minecraft:sea_lantern
fill 199 228 646 199 232 646 minecraft:sea_lantern
fill 203 228 604 203 232 604 minecraft:sea_lantern
fill 207 228 646 207 232 646 minecraft:sea_lantern
fill 211 228 604 211 232 604 minecraft:sea_lantern
fill 215 228 646 215 232 646 minecraft:sea_lantern
fill 218 228 628 218 229 628 minecraft:lime_concrete
fill 219 228 604 219 232 604 minecraft:sea_lantern
fill 223 228 646 223 232 646 minecraft:sea_lantern
fill 224 228 625 225 229 625 minecraft:magenta_concrete
fill 227 228 604 227 232 604 minecraft:sea_lantern
fill 230 228 609 230 232 609 minecraft:sea_lantern
fill 230 228 617 230 232 617 minecraft:sea_lantern
fill 230 228 625 230 232 625 minecraft:sea_lantern
fill 230 228 633 230 232 633 minecraft:sea_lantern
fill 230 228 641 230 232 641 minecraft:sea_lantern
setblock 191 230 607 minecraft:light[level=14]
setblock 191 230 615 minecraft:light[level=14]
setblock 191 230 623 minecraft:light[level=14]
setblock 191 230 631 minecraft:light[level=14]
setblock 191 230 639 minecraft:light[level=14]
setblock 199 230 607 minecraft:light[level=14]
setblock 199 230 615 minecraft:light[level=14]
setblock 199 230 623 minecraft:light[level=14]
setblock 199 230 631 minecraft:light[level=14]
setblock 199 230 639 minecraft:light[level=14]
setblock 207 230 607 minecraft:light[level=14]
setblock 207 230 615 minecraft:light[level=14]
setblock 207 230 623 minecraft:light[level=14]
setblock 207 230 631 minecraft:light[level=14]
setblock 207 230 639 minecraft:light[level=14]
setblock 215 230 607 minecraft:light[level=14]
setblock 215 230 615 minecraft:light[level=14]
setblock 215 230 623 minecraft:light[level=14]
setblock 215 230 631 minecraft:light[level=14]
setblock 215 230 639 minecraft:light[level=14]
setblock 223 230 607 minecraft:light[level=14]
setblock 223 230 615 minecraft:light[level=14]
setblock 223 230 623 minecraft:light[level=14]
setblock 223 230 631 minecraft:light[level=14]
setblock 223 230 639 minecraft:light[level=14]
fill 188 233 609 188 234 609 minecraft:magenta_concrete
fill 188 233 617 188 237 617 minecraft:magenta_concrete
fill 188 233 625 188 237 625 minecraft:magenta_concrete
fill 188 233 633 188 237 633 minecraft:magenta_concrete
fill 188 233 641 188 237 641 minecraft:magenta_concrete
fill 191 233 646 191 238 646 minecraft:magenta_concrete
fill 195 233 604 195 237 604 minecraft:magenta_concrete
fill 199 233 646 199 237 646 minecraft:magenta_concrete
setblock 203 233 604 minecraft:magenta_concrete
fill 207 233 646 207 238 646 minecraft:magenta_concrete
fill 211 233 604 211 237 604 minecraft:magenta_concrete
fill 215 233 646 215 238 646 minecraft:magenta_concrete
fill 219 233 604 219 237 604 minecraft:magenta_concrete
fill 223 233 646 223 238 646 minecraft:magenta_concrete
setblock 227 233 604 minecraft:magenta_concrete
fill 230 233 609 230 237 609 minecraft:magenta_concrete
fill 230 233 617 230 238 617 minecraft:magenta_concrete
fill 230 233 625 230 237 625 minecraft:magenta_concrete
fill 230 233 633 230 237 633 minecraft:magenta_concrete
fill 230 233 641 230 237 641 minecraft:magenta_concrete
setblock 188 234 604 minecraft:lime_concrete
fill 188 234 605 188 234 607 minecraft:magenta_concrete
setblock 188 234 608 minecraft:lime_concrete
setblock 188 234 611 minecraft:lime_concrete
fill 188 234 614 188 234 615 minecraft:lime_concrete
setblock 188 234 616 minecraft:magenta_concrete
fill 188 234 618 188 237 619 minecraft:magenta_concrete
fill 188 234 620 188 234 621 minecraft:lime_concrete
fill 188 234 622 188 235 623 minecraft:magenta_concrete
fill 188 234 626 188 237 626 minecraft:magenta_concrete
setblock 188 234 627 minecraft:lime_concrete
setblock 188 234 628 minecraft:magenta_concrete
setblock 188 234 629 minecraft:lime_concrete
fill 188 234 630 188 237 630 minecraft:magenta_concrete
setblock 188 234 634 minecraft:lime_concrete
fill 192 234 646 194 234 646 minecraft:magenta_concrete
fill 193 234 604 194 234 604 minecraft:lime_concrete
setblock 195 234 646 minecraft:lime_concrete
fill 196 234 646 198 234 646 minecraft:magenta_concrete
setblock 203 234 604 minecraft:lime_concrete
fill 207 234 604 208 234 604 minecraft:magenta_concrete
fill 208 234 646 212 235 646 minecraft:magenta_concrete
setblock 209 234 604 minecraft:lime_concrete
fill 210 234 604 210 238 604 minecraft:magenta_concrete
setblock 213 234 646 minecraft:lime_concrete
fill 214 234 646 214 237 646 minecraft:magenta_concrete
setblock 218 234 604 minecraft:lime_concrete
fill 220 234 604 220 237 604 minecraft:magenta_concrete
setblock 221 234 604 minecraft:lime_concrete
setblock 224 234 646 minecraft:lime_concrete
fill 225 234 646 226 237 646 minecraft:magenta_concrete
setblock 227 234 604 minecraft:lime_concrete
fill 227 234 646 227 235 646 minecraft:lime_concrete
fill 230 234 618 230 234 619 minecraft:lime_concrete
fill 230 234 620 230 237 620 minecraft:magenta_concrete
fill 188 235 604 189 237 604 minecraft:magenta_concrete
setblock 188 235 605 minecraft:lime_concrete
fill 188 235 606 188 235 608 minecraft:magenta_concrete
setblock 188 235 609 minecraft:lime_concrete
fill 188 235 611 188 237 611 minecraft:magenta_concrete
fill 188 235 614 188 235 615 minecraft:magenta_concrete
setblock 188 235 616 minecraft:lime_concrete
fill 188 235 620 188 235 621 minecraft:magenta_concrete
fill 188 235 627 188 237 627 minecraft:magenta_concrete
setblock 188 235 628 minecraft:lime_concrete
fill 188 235 629 188 237 629 minecraft:magenta_concrete
fill 188 235 634 188 237 634 minecraft:magenta_concrete
setblock 190 235 604 minecraft:lime_concrete
fill 191 235 604 194 237 604 minecraft:magenta_concrete
fill 192 235 646 193 237 646 minecraft:magenta_concrete
setblock 194 235 646 minecraft:lime_concrete
fill 195 235 646 195 237 646 minecraft:magenta_concrete
fill 196 235 604 198 237 604 minecraft:magenta_concrete
setblock 196 235 646 minecraft:lime_concrete
fill 197 235 646 198 235 646 minecraft:magenta_concrete
fill 199 235 604 200 235 604 minecraft:lime_concrete
fill 203 235 604 203 237 604 minecraft:magenta_concrete
fill 204 235 604 205 235 604 minecraft:lime_concrete
fill 207 235 604 207 237 604 minecraft:magenta_concrete
setblock 208 235 604 minecraft:lime_concrete
fill 209 235 604 209 237 604 minecraft:magenta_concrete
fill 213 235 646 213 237 646 minecraft:magenta_concrete
setblock 214 235 604 minecraft:lime_concrete
fill 216 235 646 221 237 646 minecraft:magenta_concrete
fill 218 235 604 218 237 604 minecraft:magenta_concrete
fill 221 235 604 221 237 604 minecraft:magenta_concrete
setblock 222 235 646 minecraft:lime_concrete
fill 224 235 646 224 237 646 minecraft:magenta_concrete
fill 227 235 604 227 237 604 minecraft:magenta_concrete
fill 230 235 606 230 236 606 minecraft:lime_concrete
fill 230 235 607 230 237 608 minecraft:magenta_concrete
fill 230 235 615 230 236 615 minecraft:lime_concrete
setblock 230 235 618 minecraft:lime_concrete
fill 230 235 619 230 237 619 minecraft:magenta_concrete
fill 230 235 626 230 237 627 minecraft:magenta_concrete
setblock 230 235 628 minecraft:lime_concrete
fill 230 235 629 230 237 629 minecraft:magenta_concrete
fill 230 235 636 230 235 637 minecraft:magenta_concrete
setblock 230 235 638 minecraft:lime_concrete
fill 230 235 639 230 235 640 minecraft:magenta_concrete
fill 188 236 605 188 237 606 minecraft:magenta_concrete
setblock 188 236 607 minecraft:lime_concrete
fill 188 236 608 188 237 609 minecraft:magenta_concrete
fill 188 236 614 188 237 614 minecraft:magenta_concrete
setblock 188 236 615 minecraft:lime_concrete
fill 188 236 616 188 237 616 minecraft:magenta_concrete
fill 188 236 620 188 236 622 minecraft:lime_concrete
fill 188 236 623 188 237 623 minecraft:magenta_concrete
fill 188 236 628 188 237 628 minecraft:magenta_concrete
setblock 188 236 631 minecraft:lime_concrete
fill 188 236 632 188 237 632 minecraft:magenta_concrete
fill 188 236 635 188 237 635 minecraft:magenta_concrete
setblock 188 236 636 minecraft:lime_concrete
fill 188 236 637 188 238 637 minecraft:magenta_concrete
fill 190 236 604 190 237 604 minecraft:magenta_concrete
fill 194 236 646 194 237 646 minecraft:magenta_concrete
fill 196 236 646 196 237 646 minecraft:magenta_concrete
fill 197 236 646 198 236 646 minecraft:lime_concrete
fill 199 236 604 200 237 604 minecraft:magenta_concrete
fill 204 236 604 205 237 604 minecraft:magenta_concrete
setblock 206 236 604 minecraft:lime_concrete
fill 208 236 604 208 237 604 minecraft:magenta_concrete
fill 208 236 646 210 237 646 minecraft:magenta_concrete
setblock 211 236 646 minecraft:lime_concrete
fill 212 236 646 212 237 646 minecraft:magenta_concrete
fill 214 236 604 214 239 604 minecraft:magenta_concrete
setblock 215 236 604 minecraft:lime_concrete
fill 222 236 646 222 237 646 minecraft:magenta_concrete
fill 227 236 646 227 238 646 minecraft:magenta_concrete
fill 228 236 604 228 237 604 minecraft:magenta_concrete
setblock 229 236 604 minecraft:lime_concrete
fill 230 236 604 230 237 604 minecraft:magenta_concrete
fill 230 236 618 230 237 618 minecraft:magenta_concrete
fill 230 236 622 230 237 622 minecraft:magenta_concrete
setblock 230 236 623 minecraft:lime_concrete
fill 230 236 624 230 238 624 minecraft:magenta_concrete
fill 230 236 628 230 237 628 minecraft:magenta_concrete
fill 230 236 636 230 237 636 minecraft:magenta_concrete
setblock 230 236 637 minecraft:lime_concrete
fill 230 236 638 230 238 638 minecraft:magenta_concrete
setblock 230 236 639 minecraft:lime_concrete
fill 230 236 640 230 237 640 minecraft:magenta_concrete
setblock 230 236 646 minecraft:lime_concrete
setblock 188 237 607 minecraft:magenta_concrete
setblock 188 237 615 minecraft:magenta_concrete
fill 188 237 620 188 237 622 minecraft:magenta_concrete
fill 188 237 631 188 238 631 minecraft:magenta_concrete
setblock 188 237 636 minecraft:magenta_concrete
fill 197 237 646 198 237 646 minecraft:magenta_concrete
fill 203 237 621 205 237 623 minecraft:redstone_block
setblock 206 237 604 minecraft:magenta_concrete
fill 209 237 615 211 237 617 minecraft:redstone_block
setblock 211 237 646 minecraft:magenta_concrete
fill 213 237 621 215 237 623 minecraft:redstone_block
setblock 215 237 604 minecraft:magenta_concrete
setblock 229 237 604 minecraft:magenta_concrete
setblock 230 237 606 minecraft:magenta_concrete
setblock 230 237 615 minecraft:magenta_concrete
fill 230 237 623 230 238 623 minecraft:magenta_concrete
setblock 230 237 637 minecraft:magenta_concrete
setblock 230 237 639 minecraft:magenta_concrete
setblock 230 237 646 minecraft:magenta_concrete
fill 188 238 604 188 238 621 minecraft:lime_concrete
fill 188 238 622 202 238 622 minecraft:magenta_concrete
fill 188 238 623 188 238 630 minecraft:lime_concrete
fill 188 238 632 188 238 636 minecraft:lime_concrete
fill 188 238 638 188 238 646 minecraft:lime_concrete
fill 189 238 604 200 242 604 minecraft:lime_concrete
fill 189 238 605 202 238 621 minecraft:magenta_concrete
fill 189 238 623 202 238 645 minecraft:magenta_concrete
fill 189 238 646 190 238 646 minecraft:lime_concrete
fill 192 238 646 196 239 646 minecraft:lime_concrete
setblock 197 238 646 minecraft:magenta_concrete
fill 198 238 646 203 239 646 minecraft:lime_concrete
setblock 201 238 604 minecraft:magenta_concrete
fill 202 238 604 209 238 604 minecraft:lime_concrete
fill 203 238 605 207 238 620 minecraft:magenta_concrete
fill 203 238 624 229 238 645 minecraft:magenta_concrete
fill 204 238 646 206 238 646 minecraft:magenta_concrete
fill 206 238 621 207 238 623 minecraft:magenta_concrete
fill 208 238 605 208 238 619 minecraft:magenta_concrete
fill 208 238 623 212 238 623 minecraft:magenta_concrete
fill 208 238 646 209 307 646 minecraft:lime_concrete
fill 209 238 605 229 238 614 minecraft:magenta_concrete
fill 209 238 618 229 238 619 minecraft:magenta_concrete
setblock 210 238 646 minecraft:magenta_concrete
fill 211 238 604 213 242 604 minecraft:lime_concrete
fill 211 238 620 212 238 622 minecraft:magenta_concrete
fill 211 238 646 214 239 646 minecraft:lime_concrete
fill 212 238 615 229 238 617 minecraft:magenta_concrete
fill 213 238 620 229 238 620 minecraft:magenta_concrete
fill 215 238 604 230 238 604 minecraft:lime_concrete
setblock 215 238 623 minecraft:light[level=14]
fill 216 238 621 229 238 623 minecraft:magenta_concrete
fill 216 238 646 222 307 646 minecraft:lime_concrete
fill 224 238 646 226 238 646 minecraft:lime_concrete
fill 228 238 646 230 238 646 minecraft:lime_concrete
fill 230 238 606 230 238 616 minecraft:lime_concrete
fill 230 238 618 230 238 622 minecraft:lime_concrete
fill 230 238 625 230 238 631 minecraft:lime_concrete
fill 230 238 633 230 238 637 minecraft:lime_concrete
fill 230 238 639 230 239 645 minecraft:lime_concrete
fill 188 239 604 188 307 606 minecraft:lime_concrete
fill 188 239 607 229 239 607 minecraft:magenta_concrete
fill 188 239 608 188 242 612 minecraft:lime_concrete
fill 188 239 613 229 239 613 minecraft:magenta_concrete
fill 188 239 614 188 239 620 minecraft:lime_concrete
setblock 188 239 621 minecraft:magenta_concrete
fill 188 239 622 188 307 623 minecraft:lime_concrete
setblock 188 239 624 minecraft:magenta_concrete
fill 188 239 625 188 242 633 minecraft:lime_concrete
fill 188 239 634 190 239 635 minecraft:magenta_concrete
fill 188 239 636 188 239 639 minecraft:lime_concrete
fill 188 239 640 190 239 640 minecraft:magenta_concrete
fill 188 239 641 188 242 645 minecraft:lime_concrete
setblock 188 239 646 minecraft:magenta_concrete
fill 189 239 605 190 239 605 minecraft:magenta_concrete
fill 189 239 606 229 239 606 minecraft:black_concrete
fill 189 239 608 229 239 608 minecraft:magenta_concrete
fill 189 239 609 229 239 609 minecraft:black_concrete
fill 189 239 610 190 239 611 minecraft:magenta_concrete
fill 189 239 612 229 239 612 minecraft:black_concrete
fill 189 239 614 207 239 614 minecraft:magenta_concrete
fill 189 239 615 207 239 615 minecraft:black_concrete
fill 189 239 616 190 239 617 minecraft:magenta_concrete
fill 189 239 618 207 239 618 minecraft:black_concrete
fill 189 239 619 201 239 620 minecraft:magenta_concrete
fill 189 239 621 201 239 621 minecraft:black_concrete
fill 189 239 622 190 239 623 minecraft:magenta_concrete
fill 189 239 624 201 239 624 minecraft:black_concrete
fill 189 239 625 229 239 626 minecraft:magenta_concrete
fill 189 239 627 229 239 627 minecraft:black_concrete
fill 189 239 628 190 239 629 minecraft:magenta_concrete
fill 189 239 630 229 239 630 minecraft:black_concrete
fill 189 239 631 229 239 632 minecraft:magenta_concrete
fill 189 239 633 229 239 633 minecraft:black_concrete
fill 189 239 636 229 239 636 minecraft:black_concrete
fill 189 239 637 229 239 638 minecraft:magenta_concrete
fill 189 239 639 229 239 639 minecraft:black_concrete
fill 189 239 641 190 239 641 minecraft:magenta_concrete
fill 189 239 642 229 239 642 minecraft:black_concrete
fill 189 239 643 229 239 644 minecraft:magenta_concrete
fill 189 239 645 229 239 645 minecraft:black_concrete
fill 189 239 646 189 307 646 minecraft:lime_concrete
setblock 190 239 646 minecraft:magenta_concrete
setblock 191 239 605 minecraft:black_concrete
fill 191 239 610 191 239 611 minecraft:black_concrete
fill 191 239 616 191 239 617 minecraft:black_concrete
fill 191 239 622 191 239 623 minecraft:black_concrete
fill 191 239 628 191 239 629 minecraft:black_concrete
fill 191 239 634 191 239 635 minecraft:black_concrete
fill 191 239 640 191 239 641 minecraft:black_concrete
fill 191 239 646 191 242 646 minecraft:lime_concrete
fill 192 239 605 193 239 605 minecraft:magenta_concrete
fill 192 239 610 193 239 611 minecraft:magenta_concrete
fill 192 239 616 193 239 617 minecraft:magenta_concrete
fill 192 239 622 193 239 623 minecraft:magenta_concrete
fill 192 239 628 193 239 629 minecraft:magenta_concrete
fill 192 239 634 193 239 635 minecraft:magenta_concrete
fill 192 239 640 193 239 641 minecraft:magenta_concrete
setblock 194 239 605 minecraft:black_concrete
fill 194 239 610 194 239 611 minecraft:black_concrete
fill 194 239 616 194 239 617 minecraft:black_concrete
fill 194 239 622 194 239 623 minecraft:black_concrete
fill 194 239 628 194 239 629 minecraft:black_concrete
fill 194 239 634 194 239 635 minecraft:black_concrete
fill 194 239 640 194 239 641 minecraft:black_concrete
fill 195 239 605 196 239 605 minecraft:magenta_concrete
fill 195 239 610 196 239 611 minecraft:magenta_concrete
fill 195 239 616 196 239 617 minecraft:magenta_concrete
fill 195 239 622 196 239 623 minecraft:magenta_concrete
fill 195 239 628 196 239 629 minecraft:magenta_concrete
fill 195 239 634 196 239 635 minecraft:magenta_concrete
fill 195 239 640 196 239 641 minecraft:magenta_concrete
setblock 197 239 605 minecraft:black_concrete
fill 197 239 610 197 239 611 minecraft:black_concrete
fill 197 239 616 197 239 617 minecraft:black_concrete
fill 197 239 622 197 239 623 minecraft:black_concrete
fill 197 239 628 197 239 629 minecraft:black_concrete
fill 197 239 634 197 239 635 minecraft:black_concrete
fill 197 239 640 197 239 641 minecraft:black_concrete
fill 197 239 646 197 307 646 minecraft:lime_concrete
fill 198 239 605 199 239 605 minecraft:magenta_concrete
fill 198 239 610 199 239 611 minecraft:magenta_concrete
fill 198 239 616 199 239 617 minecraft:magenta_concrete
fill 198 239 622 199 239 623 minecraft:magenta_concrete
fill 198 239 628 199 239 629 minecraft:magenta_concrete
fill 198 239 634 199 239 635 minecraft:magenta_concrete
fill 198 239 640 199 239 641 minecraft:magenta_concrete
setblock 200 239 605 minecraft:black_concrete
fill 200 239 610 200 239 611 minecraft:black_concrete
fill 200 239 616 200 239 617 minecraft:black_concrete
fill 200 239 622 200 239 623 minecraft:black_concrete
fill 200 239 628 200 239 629 minecraft:black_concrete
fill 200 239 634 200 239 635 minecraft:black_concrete
fill 200 239 640 200 239 641 minecraft:black_concrete
fill 201 239 604 203 242 604 minecraft:lime_concrete
fill 201 239 605 202 239 605 minecraft:magenta_concrete
fill 201 239 610 202 239 611 minecraft:magenta_concrete
fill 201 239 616 202 239 617 minecraft:magenta_concrete
fill 201 239 622 201 239 623 minecraft:magenta_concrete
fill 201 239 628 202 239 629 minecraft:magenta_concrete
fill 201 239 634 202 239 635 minecraft:magenta_concrete
fill 201 239 640 202 239 641 minecraft:magenta_concrete
fill 202 239 619 206 239 619 minecraft:magenta_concrete
fill 202 239 620 202 239 624 minecraft:sea_lantern
setblock 203 239 605 minecraft:black_concrete
fill 203 239 610 203 239 611 minecraft:black_concrete
fill 203 239 616 203 239 617 minecraft:black_concrete
fill 203 239 620 207 239 620 minecraft:sea_lantern
fill 203 239 621 205 239 623 minecraft:magenta_concrete
fill 203 239 624 206 239 624 minecraft:sea_lantern
fill 203 239 628 203 239 629 minecraft:black_concrete
fill 203 239 634 203 239 635 minecraft:black_concrete
fill 203 239 640 203 239 641 minecraft:black_concrete
fill 204 239 604 204 239 605 minecraft:magenta_concrete
fill 204 239 610 205 239 611 minecraft:magenta_concrete
fill 204 239 616 205 239 617 minecraft:magenta_concrete
fill 204 239 628 205 239 629 minecraft:magenta_concrete
fill 204 239 634 205 239 635 minecraft:magenta_concrete
fill 204 239 640 205 239 641 minecraft:magenta_concrete
fill 204 239 646 207 242 646 minecraft:lime_concrete
fill 205 239 604 205 307 604 minecraft:lime_concrete
setblock 205 239 605 minecraft:magenta_concrete
fill 206 239 604 206 240 604 minecraft:magenta_concrete
setblock 206 239 605 minecraft:black_concrete
fill 206 239 610 206 239 611 minecraft:black_concrete
fill 206 239 616 206 239 617 minecraft:black_concrete
fill 206 239 621 207 239 623 minecraft:sea_lantern
fill 206 239 628 206 239 629 minecraft:black_concrete
fill 206 239 634 206 239 635 minecraft:black_concrete
fill 206 239 640 206 239 641 minecraft:black_concrete
fill 207 239 604 210 239 604 minecraft:lime_concrete
fill 207 239 605 208 239 605 minecraft:magenta_concrete
fill 207 239 610 208 239 611 minecraft:magenta_concrete
fill 207 239 616 207 239 617 minecraft:magenta_concrete
fill 207 239 619 211 239 619 minecraft:sea_lantern
fill 207 239 624 211 239 624 minecraft:black_concrete
fill 207 239 628 208 239 629 minecraft:magenta_concrete
fill 207 239 634 208 239 635 minecraft:magenta_concrete
fill 207 239 640 208 239 641 minecraft:magenta_concrete
fill 208 239 614 208 239 618 minecraft:sea_lantern
fill 208 239 623 212 239 623 minecraft:sea_lantern
setblock 209 239 605 minecraft:black_concrete
fill 209 239 610 209 239 611 minecraft:black_concrete
fill 209 239 614 212 239 614 minecraft:sea_lantern
fill 209 239 615 211 239 617 minecraft:magenta_concrete
fill 209 239 618 212 239 618 minecraft:sea_lantern
fill 209 239 628 209 239 629 minecraft:black_concrete
fill 209 239 634 209 239 635 minecraft:black_concrete
fill 209 239 640 209 239 641 minecraft:black_concrete
fill 210 239 605 211 239 605 minecraft:magenta_concrete
fill 210 239 610 211 239 611 minecraft:magenta_concrete
fill 210 239 628 211 239 629 minecraft:magenta_concrete
fill 210 239 634 211 239 635 minecraft:magenta_concrete
fill 210 239 640 211 239 641 minecraft:magenta_concrete
fill 210 239 646 210 307 646 minecraft:lime_concrete
fill 211 239 620 212 239 622 minecraft:sea_lantern
setblock 212 239 605 minecraft:black_concrete
fill 212 239 610 212 239 611 minecraft:black_concrete
fill 212 239 615 212 239 617 minecraft:sea_lantern
fill 212 239 619 229 239 619 minecraft:magenta_concrete
fill 212 239 624 216 239 624 minecraft:sea_lantern
fill 212 239 628 212 239 629 minecraft:black_concrete
fill 212 239 634 212 239 635 minecraft:black_concrete
fill 212 239 640 212 239 641 minecraft:black_concrete
fill 213 239 605 214 239 605 minecraft:magenta_concrete
fill 213 239 610 214 239 611 minecraft:magenta_concrete
fill 213 239 614 229 239 614 minecraft:magenta_concrete
fill 213 239 615 229 239 615 minecraft:black_concrete
fill 213 239 616 214 239 617 minecraft:magenta_concrete
fill 213 239 618 229 239 618 minecraft:black_concrete
fill 213 239 620 216 239 620 minecraft:sea_lantern
fill 213 239 621 215 239 623 minecraft:magenta_concrete
fill 213 239 628 214 239 629 minecraft:magenta_concrete
fill 213 239 634 214 239 635 minecraft:magenta_concrete
fill 213 239 640 214 239 641 minecraft:magenta_concrete
fill 215 239 604 220 242 604 minecraft:lime_concrete
setblock 215 239 605 minecraft:black_concrete
fill 215 239 610 215 239 611 minecraft:black_concrete
fill 215 239 616 215 239 617 minecraft:black_concrete
fill 215 239 628 215 239 629 minecraft:black_concrete
fill 215 239 634 215 239 635 minecraft:black_concrete
fill 215 239 640 215 239 641 minecraft:black_concrete
fill 215 239 646 215 242 646 minecraft:lime_concrete
fill 216 239 605 217 239 605 minecraft:magenta_concrete
fill 216 239 610 217 239 611 minecraft:magenta_concrete
fill 216 239 616 217 239 617 minecraft:magenta_concrete
fill 216 239 621 216 239 623 minecraft:sea_lantern
fill 216 239 628 217 239 629 minecraft:magenta_concrete
fill 216 239 634 217 239 635 minecraft:magenta_concrete
fill 216 239 640 217 239 641 minecraft:magenta_concrete
fill 217 239 620 230 239 620 minecraft:magenta_concrete
fill 217 239 621 229 239 621 minecraft:black_concrete
fill 217 239 622 217 239 623 minecraft:magenta_concrete
fill 217 239 624 229 239 624 minecraft:black_concrete
setblock 218 239 605 minecraft:black_concrete
fill 218 239 610 218 239 611 minecraft:black_concrete
fill 218 239 616 218 239 617 minecraft:black_concrete
fill 218 239 622 218 239 623 minecraft:black_concrete
fill 218 239 628 218 239 629 minecraft:black_concrete
fill 218 239 634 218 239 635 minecraft:black_concrete
fill 218 239 640 218 239 641 minecraft:black_concrete
fill 219 239 605 220 239 605 minecraft:magenta_concrete
fill 219 239 610 220 239 611 minecraft:magenta_concrete
fill 219 239 616 220 239 617 minecraft:magenta_concrete
fill 219 239 622 220 239 623 minecraft:magenta_concrete
fill 219 239 628 220 239 629 minecraft:magenta_concrete
fill 219 239 634 220 239 635 minecraft:magenta_concrete
fill 219 239 640 220 239 641 minecraft:magenta_concrete
setblock 221 239 604 minecraft:magenta_concrete
setblock 221 239 605 minecraft:black_concrete
fill 221 239 610 221 239 611 minecraft:black_concrete
fill 221 239 616 221 239 617 minecraft:black_concrete
fill 221 239 622 221 239 623 minecraft:black_concrete
fill 221 239 628 221 239 629 minecraft:black_concrete
fill 221 239 634 221 239 635 minecraft:black_concrete
fill 221 239 640 221 239 641 minecraft:black_concrete
fill 222 239 604 230 239 604 minecraft:lime_concrete
fill 222 239 605 223 239 605 minecraft:magenta_concrete
fill 222 239 610 223 239 611 minecraft:magenta_concrete
fill 222 239 616 223 239 617 minecraft:magenta_concrete
fill 222 239 622 223 239 623 minecraft:magenta_concrete
fill 222 239 628 223 239 629 minecraft:magenta_concrete
fill 222 239 634 223 239 635 minecraft:magenta_concrete
fill 222 239 640 223 239 641 minecraft:magenta_concrete
fill 223 239 646 223 242 646 minecraft:lime_concrete
setblock 224 239 605 minecraft:black_concrete
fill 224 239 610 224 239 611 minecraft:black_concrete
fill 224 239 616 224 239 617 minecraft:black_concrete
fill 224 239 622 224 239 623 minecraft:black_concrete
fill 224 239 628 224 239 629 minecraft:black_concrete
fill 224 239 634 224 239 635 minecraft:black_concrete
fill 224 239 640 224 239 641 minecraft:black_concrete
fill 224 239 646 224 240 646 minecraft:magenta_concrete
fill 225 239 605 226 239 605 minecraft:magenta_concrete
fill 225 239 610 226 239 611 minecraft:magenta_concrete
fill 225 239 616 226 239 617 minecraft:magenta_concrete
fill 225 239 622 226 239 623 minecraft:magenta_concrete
fill 225 239 628 226 239 629 minecraft:magenta_concrete
fill 225 239 634 226 239 635 minecraft:magenta_concrete
fill 225 239 640 226 239 641 minecraft:magenta_concrete
fill 225 239 646 225 307 646 minecraft:lime_concrete
setblock 226 239 646 minecraft:magenta_concrete
setblock 227 239 605 minecraft:black_concrete
fill 227 239 610 227 239 611 minecraft:black_concrete
fill 227 239 616 227 239 617 minecraft:black_concrete
fill 227 239 622 227 239 623 minecraft:black_concrete
fill 227 239 628 227 239 629 minecraft:black_concrete
fill 227 239 634 227 239 635 minecraft:black_concrete
fill 227 239 640 227 239 641 minecraft:black_concrete
fill 227 239 646 229 307 646 minecraft:lime_concrete
fill 228 239 605 229 239 605 minecraft:magenta_concrete
fill 228 239 610 229 239 611 minecraft:magenta_concrete
fill 228 239 616 229 239 617 minecraft:magenta_concrete
fill 228 239 622 229 239 623 minecraft:magenta_concrete
fill 228 239 628 229 239 629 minecraft:magenta_concrete
fill 228 239 634 229 239 635 minecraft:magenta_concrete
fill 228 239 640 229 239 641 minecraft:magenta_concrete
fill 230 239 605 230 307 608 minecraft:lime_concrete
setblock 230 239 609 minecraft:magenta_concrete
fill 230 239 610 230 242 619 minecraft:lime_concrete
fill 230 239 621 230 242 627 minecraft:lime_concrete
setblock 230 239 628 minecraft:magenta_concrete
fill 230 239 629 230 239 636 minecraft:lime_concrete
setblock 230 239 637 minecraft:magenta_concrete
setblock 230 239 638 minecraft:lime_concrete
setblock 230 239 646 minecraft:magenta_concrete
fill 188 240 607 188 307 607 minecraft:lime_concrete
setblock 188 240 613 minecraft:magenta_concrete
fill 188 240 614 188 307 616 minecraft:lime_concrete
fill 188 240 617 188 240 618 minecraft:magenta_concrete
fill 188 240 619 188 307 621 minecraft:lime_concrete
fill 188 240 624 188 307 624 minecraft:lime_concrete
fill 188 240 634 188 307 634 minecraft:lime_concrete
setblock 188 240 635 minecraft:magenta_concrete
fill 188 240 636 188 307 636 minecraft:lime_concrete
setblock 188 240 637 minecraft:magenta_concrete
fill 188 240 638 188 307 640 minecraft:lime_concrete
fill 188 240 646 188 307 646 minecraft:lime_concrete
fill 190 240 646 190 307 646 minecraft:lime_concrete
fill 192 240 646 195 307 646 minecraft:lime_concrete
setblock 196 240 646 minecraft:magenta_concrete
fill 198 240 646 200 242 646 minecraft:lime_concrete
setblock 201 240 646 minecraft:magenta_concrete
fill 202 240 646 203 307 646 minecraft:lime_concrete
fill 204 240 604 204 307 604 minecraft:lime_concrete
fill 207 240 604 207 307 604 minecraft:lime_concrete
setblock 208 240 604 minecraft:magenta_concrete
fill 209 240 604 210 307 604 minecraft:lime_concrete
fill 211 240 646 213 307 646 minecraft:lime_concrete
fill 214 240 604 214 307 604 minecraft:lime_concrete
setblock 214 240 646 minecraft:magenta_concrete
fill 221 240 604 221 307 604 minecraft:lime_concrete
setblock 222 240 604 minecraft:magenta_concrete
fill 223 240 604 225 307 604 minecraft:lime_concrete
setblock 226 240 604 minecraft:magenta_concrete
fill 226 240 646 226 307 646 minecraft:lime_concrete
fill 227 240 604 230 242 604 minecraft:lime_concrete
fill 230 240 609 230 242 609 minecraft:lime_concrete
fill 230 240 620 230 307 620 minecraft:lime_concrete
fill 230 240 628 230 307 632 minecraft:lime_concrete
setblock 230 240 633 minecraft:magenta_concrete
fill 230 240 634 230 307 637 minecraft:lime_concrete
setblock 230 240 638 minecraft:magenta_concrete
fill 230 240 639 230 307 640 minecraft:lime_concrete
fill 230 240 641 230 240 642 minecraft:magenta_concrete
fill 230 240 643 230 307 644 minecraft:lime_concrete
setblock 230 240 645 minecraft:magenta_concrete
fill 230 240 646 230 307 646 minecraft:lime_concrete
fill 188 241 613 188 307 613 minecraft:lime_concrete
fill 188 241 617 188 242 618 minecraft:lime_concrete
fill 188 241 635 188 307 635 minecraft:lime_concrete
fill 188 241 637 188 307 637 minecraft:lime_concrete
fill 196 241 646 196 307 646 minecraft:lime_concrete
fill 201 241 646 201 307 646 minecraft:lime_concrete
fill 206 241 604 206 307 604 minecraft:lime_concrete
fill 208 241 604 208 307 604 minecraft:lime_concrete
fill 214 241 646 214 307 646 minecraft:lime_concrete
fill 222 241 604 222 307 604 minecraft:lime_concrete
fill 224 241 646 224 307 646 minecraft:lime_concrete
fill 226 241 604 226 307 604 minecraft:lime_concrete
fill 230 241 633 230 242 633 minecraft:lime_concrete
fill 230 241 638 230 307 638 minecraft:lime_concrete
fill 230 241 641 230 242 642 minecraft:lime_concrete
fill 230 241 645 230 307 645 minecraft:lime_concrete
fill 188 243 608 188 307 608 minecraft:lime_concrete
fill 188 243 609 188 247 609 minecraft:sea_lantern
fill 188 243 610 188 307 612 minecraft:lime_concrete
fill 188 243 617 188 247 617 minecraft:sea_lantern
fill 188 243 618 188 307 618 minecraft:lime_concrete
fill 188 243 625 188 247 625 minecraft:sea_lantern
fill 188 243 626 188 307 632 minecraft:lime_concrete
fill 188 243 633 188 247 633 minecraft:sea_lantern
fill 188 243 641 188 247 641 minecraft:sea_lantern
fill 188 243 642 188 307 645 minecraft:lime_concrete
fill 189 243 604 194 307 604 minecraft:lime_concrete
fill 189 243 611 189 273 612 minecraft:black_concrete
fill 189 243 619 189 273 620 minecraft:black_concrete
fill 189 243 627 189 273 628 minecraft:black_concrete
fill 189 243 635 189 273 636 minecraft:black_concrete
fill 189 243 643 189 273 644 minecraft:black_concrete
fill 190 243 605 191 273 605 minecraft:black_concrete
fill 191 243 646 191 247 646 minecraft:sea_lantern
fill 195 243 604 195 247 604 minecraft:sea_lantern
fill 195 243 645 196 273 645 minecraft:black_concrete
fill 196 243 604 202 307 604 minecraft:lime_concrete
fill 198 243 605 199 273 605 minecraft:black_concrete
fill 198 243 646 198 307 646 minecraft:lime_concrete
fill 199 243 646 199 247 646 minecraft:sea_lantern
fill 200 243 646 200 307 646 minecraft:lime_concrete
fill 203 243 604 203 247 604 minecraft:sea_lantern
fill 203 243 645 204 273 645 minecraft:black_concrete
fill 204 243 646 206 307 646 minecraft:lime_concrete
fill 206 243 605 207 273 605 minecraft:black_concrete
fill 207 243 646 207 247 646 minecraft:sea_lantern
fill 211 243 604 211 247 604 minecraft:sea_lantern
fill 211 243 645 212 273 645 minecraft:black_concrete
fill 212 243 604 213 307 604 minecraft:lime_concrete
fill 214 243 605 215 273 605 minecraft:black_concrete
fill 215 243 604 218 307 604 minecraft:lime_concrete
fill 215 243 646 215 247 646 minecraft:sea_lantern
fill 219 243 604 219 247 604 minecraft:sea_lantern
fill 219 243 645 220 273 645 minecraft:black_concrete
fill 220 243 604 220 307 604 minecraft:lime_concrete
fill 222 243 605 223 273 605 minecraft:black_concrete
fill 223 243 646 223 247 646 minecraft:sea_lantern
fill 227 243 604 227 247 604 minecraft:sea_lantern
fill 227 243 645 228 273 645 minecraft:black_concrete
fill 228 243 604 230 307 604 minecraft:lime_concrete
fill 229 243 606 229 273 607 minecraft:black_concrete
fill 229 243 614 229 273 615 minecraft:black_concrete
fill 229 243 622 229 273 623 minecraft:black_concrete
fill 229 243 630 229 273 631 minecraft:black_concrete
fill 229 243 638 229 273 639 minecraft:black_concrete
fill 230 243 609 230 247 609 minecraft:sea_lantern
fill 230 243 610 230 307 616 minecraft:lime_concrete
fill 230 243 617 230 247 617 minecraft:sea_lantern
fill 230 243 618 230 307 619 minecraft:lime_concrete
fill 230 243 621 230 307 624 minecraft:lime_concrete
fill 230 243 625 230 247 625 minecraft:sea_lantern
fill 230 243 626 230 307 627 minecraft:lime_concrete
fill 230 243 633 230 247 633 minecraft:sea_lantern
fill 230 243 641 230 247 641 minecraft:sea_lantern
fill 230 243 642 230 307 642 minecraft:lime_concrete
setblock 191 246 607 minecraft:light[level=14]
setblock 191 246 615 minecraft:light[level=14]
setblock 191 246 623 minecraft:light[level=14]
setblock 191 246 631 minecraft:light[level=14]
setblock 191 246 639 minecraft:light[level=14]
setblock 199 246 607 minecraft:light[level=14]
setblock 199 246 615 minecraft:light[level=14]
setblock 199 246 623 minecraft:light[level=14]
setblock 199 246 631 minecraft:light[level=14]
setblock 199 246 639 minecraft:light[level=14]
setblock 207 246 607 minecraft:light[level=14]
setblock 207 246 615 minecraft:light[level=14]
setblock 207 246 623 minecraft:light[level=14]
setblock 207 246 631 minecraft:light[level=14]
setblock 207 246 639 minecraft:light[level=14]
setblock 215 246 607 minecraft:light[level=14]
setblock 215 246 615 minecraft:light[level=14]
setblock 215 246 623 minecraft:light[level=14]
setblock 215 246 631 minecraft:light[level=14]
setblock 215 246 639 minecraft:light[level=14]
setblock 223 246 607 minecraft:light[level=14]
setblock 223 246 615 minecraft:light[level=14]
setblock 223 246 623 minecraft:light[level=14]
setblock 223 246 631 minecraft:light[level=14]
setblock 223 246 639 minecraft:light[level=14]
fill 188 248 609 188 255 609 minecraft:lime_concrete
fill 188 248 617 188 255 617 minecraft:lime_concrete
fill 188 248 625 188 255 625 minecraft:lime_concrete
fill 188 248 633 188 255 633 minecraft:lime_concrete
fill 188 248 641 188 255 641 minecraft:lime_concrete
fill 191 248 646 191 255 646 minecraft:lime_concrete
fill 195 248 604 195 255 604 minecraft:lime_concrete
fill 199 248 646 199 255 646 minecraft:lime_concrete
fill 203 248 604 203 255 604 minecraft:lime_concrete
fill 207 248 646 207 255 646 minecraft:lime_concrete
fill 211 248 604 211 255 604 minecraft:lime_concrete
fill 215 248 646 215 255 646 minecraft:lime_concrete
fill 219 248 604 219 255 604 minecraft:lime_concrete
fill 223 248 646 223 255 646 minecraft:lime_concrete
fill 227 248 604 227 255 604 minecraft:lime_concrete
fill 230 248 609 230 255 609 minecraft:lime_concrete
fill 230 248 617 230 255 617 minecraft:lime_concrete
fill 230 248 625 230 255 625 minecraft:lime_concrete
fill 230 248 633 230 255 633 minecraft:lime_concrete
fill 230 248 641 230 255 641 minecraft:lime_concrete
fill 197 249 633 197 250 634 minecraft:cyan_concrete
fill 189 252 605 189 253 610 minecraft:black_concrete
fill 189 252 613 190 252 618 minecraft:black_concrete
fill 189 252 621 190 252 626 minecraft:black_concrete
fill 189 252 629 190 252 634 minecraft:black_concrete
fill 189 252 637 190 252 642 minecraft:black_concrete
fill 189 252 645 194 253 645 minecraft:black_concrete
fill 190 252 606 190 252 612 minecraft:black_concrete
fill 190 252 619 190 252 620 minecraft:black_concrete
fill 190 252 627 190 252 628 minecraft:black_concrete
fill 190 252 635 190 252 636 minecraft:black_concrete
fill 190 252 643 190 252 644 minecraft:black_concrete
fill 191 252 606 228 252 606 minecraft:black_concrete
fill 191 252 644 229 252 644 minecraft:black_concrete
fill 192 252 605 197 253 605 minecraft:black_concrete
fill 197 252 645 202 253 645 minecraft:black_concrete
fill 200 252 605 205 253 605 minecraft:black_concrete
fill 205 252 645 210 253 645 minecraft:black_concrete
fill 208 252 605 213 253 605 minecraft:black_concrete
fill 208 252 636 209 253 637 minecraft:yellow_concrete
fill 213 252 645 218 253 645 minecraft:black_concrete
fill 216 252 605 221 253 605 minecraft:black_concrete
fill 221 252 645 226 253 645 minecraft:black_concrete
fill 224 252 605 229 253 605 minecraft:black_concrete
fill 228 252 607 228 252 643 minecraft:black_concrete
fill 229 252 608 229 253 613 minecraft:black_concrete
fill 229 252 616 229 253 621 minecraft:black_concrete
fill 229 252 624 229 253 629 minecraft:black_concrete
fill 229 252 632 229 253 637 minecraft:black_concrete
fill 229 252 640 229 253 643 minecraft:black_concrete
fill 229 252 645 229 253 645 minecraft:black_concrete
fill 189 253 613 189 253 618 minecraft:black_concrete
fill 189 253 621 189 253 626 minecraft:black_concrete
fill 189 253 629 189 253 634 minecraft:black_concrete
fill 189 253 637 189 253 642 minecraft:black_concrete
setblock 229 253 644 minecraft:black_concrete
setblock 191 254 607 minecraft:light[level=14]
setblock 191 254 615 minecraft:light[level=14]
setblock 191 254 623 minecraft:light[level=14]
setblock 191 254 631 minecraft:light[level=14]
setblock 191 254 639 minecraft:light[level=14]
fill 197 254 632 197 255 632 minecraft:lime_concrete
setblock 199 254 607 minecraft:light[level=14]
setblock 199 254 615 minecraft:light[level=14]
setblock 199 254 623 minecraft:light[level=14]
setblock 199 254 631 minecraft:light[level=14]
setblock 199 254 639 minecraft:light[level=14]
setblock 207 254 607 minecraft:light[level=14]
setblock 207 254 615 minecraft:light[level=14]
setblock 207 254 623 minecraft:light[level=14]
setblock 207 254 631 minecraft:light[level=14]
setblock 207 254 639 minecraft:light[level=14]
setblock 215 254 607 minecraft:light[level=14]
setblock 215 254 615 minecraft:light[level=14]
setblock 215 254 623 minecraft:light[level=14]
setblock 215 254 631 minecraft:light[level=14]
setblock 215 254 639 minecraft:light[level=14]
setblock 223 254 607 minecraft:light[level=14]
setblock 223 254 615 minecraft:light[level=14]
setblock 223 254 623 minecraft:light[level=14]
setblock 223 254 631 minecraft:light[level=14]
setblock 223 254 639 minecraft:light[level=14]
fill 188 256 609 188 261 609 minecraft:sea_lantern
fill 188 256 617 188 261 617 minecraft:sea_lantern
fill 188 256 625 188 261 625 minecraft:sea_lantern
fill 188 256 633 188 261 633 minecraft:sea_lantern
fill 188 256 641 188 261 641 minecraft:sea_lantern
fill 191 256 646 191 261 646 minecraft:sea_lantern
fill 195 256 604 195 261 604 minecraft:sea_lantern
fill 199 256 646 199 261 646 minecraft:sea_lantern
fill 203 256 604 203 261 604 minecraft:sea_lantern
fill 207 256 646 207 261 646 minecraft:sea_lantern
fill 211 256 604 211 261 604 minecraft:sea_lantern
fill 215 256 646 215 261 646 minecraft:sea_lantern
fill 219 256 604 219 261 604 minecraft:sea_lantern
fill 223 256 646 223 261 646 minecraft:sea_lantern
fill 227 256 604 227 261 604 minecraft:sea_lantern
fill 230 256 609 230 261 609 minecraft:sea_lantern
fill 230 256 617 230 261 617 minecraft:sea_lantern
fill 230 256 625 230 261 625 minecraft:sea_lantern
fill 230 256 633 230 261 633 minecraft:sea_lantern
fill 230 256 641 230 261 641 minecraft:sea_lantern
fill 198 259 620 199 260 620 minecraft:cyan_concrete
fill 199 259 619 199 260 619 minecraft:cyan_concrete
fill 188 262 609 188 269 609 minecraft:lime_concrete
fill 188 262 617 188 269 617 minecraft:lime_concrete
fill 188 262 625 188 269 625 minecraft:lime_concrete
fill 188 262 633 188 269 633 minecraft:lime_concrete
fill 188 262 641 188 269 641 minecraft:lime_concrete
setblock 191 262 607 minecraft:light[level=14]
setblock 191 262 615 minecraft:light[level=14]
setblock 191 262 623 minecraft:light[level=14]
setblock 191 262 631 minecraft:light[level=14]
setblock 191 262 639 minecraft:light[level=14]
fill 191 262 646 191 269 646 minecraft:lime_concrete
fill 195 262 604 195 269 604 minecraft:lime_concrete
setblock 199 262 607 minecraft:light[level=14]
setblock 199 262 615 minecraft:light[level=14]
setblock 199 262 623 minecraft:light[level=14]
setblock 199 262 631 minecraft:light[level=14]
setblock 199 262 639 minecraft:light[level=14]
fill 199 262 646 199 269 646 minecraft:lime_concrete
fill 203 262 604 203 269 604 minecraft:lime_concrete
setblock 207 262 607 minecraft:light[level=14]
setblock 207 262 615 minecraft:light[level=14]
setblock 207 262 623 minecraft:light[level=14]
setblock 207 262 631 minecraft:light[level=14]
setblock 207 262 639 minecraft:light[level=14]
fill 207 262 646 207 269 646 minecraft:lime_concrete
fill 211 262 604 211 269 604 minecraft:lime_concrete
setblock 215 262 607 minecraft:light[level=14]
setblock 215 262 615 minecraft:light[level=14]
setblock 215 262 623 minecraft:light[level=14]
setblock 215 262 631 minecraft:light[level=14]
setblock 215 262 639 minecraft:light[level=14]
fill 215 262 646 215 269 646 minecraft:lime_concrete
fill 219 262 604 219 269 604 minecraft:lime_concrete
setblock 223 262 607 minecraft:light[level=14]
setblock 223 262 615 minecraft:light[level=14]
setblock 223 262 623 minecraft:light[level=14]
setblock 223 262 631 minecraft:light[level=14]
setblock 223 262 639 minecraft:light[level=14]
fill 223 262 646 223 269 646 minecraft:lime_concrete
fill 227 262 604 227 269 604 minecraft:lime_concrete
fill 230 262 609 230 269 609 minecraft:lime_concrete
fill 230 262 617 230 269 617 minecraft:lime_concrete
fill 230 262 625 230 269 625 minecraft:lime_concrete
fill 230 262 633 230 269 633 minecraft:lime_concrete
fill 230 262 641 230 269 641 minecraft:lime_concrete
fill 189 266 605 189 267 610 minecraft:black_concrete
fill 189 266 613 190 266 618 minecraft:black_concrete
fill 189 266 621 190 266 626 minecraft:black_concrete
fill 189 266 629 190 266 634 minecraft:black_concrete
fill 189 266 637 190 266 642 minecraft:black_concrete
fill 189 266 645 194 267 645 minecraft:black_concrete
fill 190 266 606 190 266 612 minecraft:black_concrete
fill 190 266 619 190 266 620 minecraft:black_concrete
fill 190 266 627 190 266 628 minecraft:black_concrete
fill 190 266 635 190 266 636 minecraft:black_concrete
fill 190 266 643 190 266 644 minecraft:black_concrete
fill 191 266 606 228 266 606 minecraft:black_concrete
fill 191 266 623 192 267 627 minecraft:black_concrete
fill 191 266 644 229 266 644 minecraft:black_concrete
fill 192 266 605 197 267 605 minecraft:black_concrete
fill 192 266 619 192 267 622 minecraft:black_concrete
fill 192 266 628 192 267 631 minecraft:black_concrete
fill 193 266 617 193 267 619 minecraft:black_concrete
fill 193 266 631 193 267 633 minecraft:black_concrete
fill 194 266 615 194 267 617 minecraft:black_concrete
fill 194 266 633 194 267 635 minecraft:black_concrete
fill 195 266 614 195 267 615 minecraft:black_concrete
fill 195 266 635 195 267 636 minecraft:black_concrete
fill 196 266 613 196 267 614 minecraft:black_concrete
fill 196 266 636 196 267 637 minecraft:black_concrete
fill 197 266 612 197 267 613 minecraft:black_concrete
fill 197 266 637 197 267 638 minecraft:black_concrete
fill 197 266 645 202 267 645 minecraft:black_concrete
fill 198 266 611 198 267 612 minecraft:black_concrete
fill 198 266 638 198 267 639 minecraft:black_concrete
fill 199 266 610 199 267 611 minecraft:black_concrete
fill 199 266 639 199 267 640 minecraft:black_concrete
fill 200 266 605 205 267 605 minecraft:black_concrete
fill 200 266 610 201 267 610 minecraft:black_concrete
fill 200 266 640 201 267 640 minecraft:black_concrete
fill 201 266 609 203 267 609 minecraft:black_concrete
fill 201 266 641 203 267 641 minecraft:black_concrete
fill 203 266 608 215 267 608 minecraft:black_concrete
fill 203 266 642 215 267 642 minecraft:black_concrete
fill 205 266 645 210 267 645 minecraft:black_concrete
fill 207 266 607 211 267 607 minecraft:black_concrete
fill 207 266 643 211 267 643 minecraft:black_concrete
fill 208 266 605 213 267 605 minecraft:black_concrete
fill 213 266 645 218 267 645 minecraft:black_concrete
fill 215 266 609 217 267 609 minecraft:black_concrete
fill 215 266 641 217 267 641 minecraft:black_concrete
fill 216 266 605 221 267 605 minecraft:black_concrete
fill 217 266 610 219 267 610 minecraft:black_concrete
fill 217 266 640 219 267 640 minecraft:black_concrete
fill 219 266 611 220 267 611 minecraft:black_concrete
fill 219 266 639 220 267 639 minecraft:black_concrete
fill 220 266 612 221 267 612 minecraft:black_concrete
fill 220 266 638 221 267 638 minecraft:black_concrete
fill 221 266 613 222 267 613 minecraft:black_concrete
fill 221 266 637 222 267 637 minecraft:black_concrete
fill 221 266 645 226 267 645 minecraft:black_concrete
fill 222 266 614 223 267 614 minecraft:black_concrete
fill 222 266 636 223 267 636 minecraft:black_concrete
fill 223 266 615 224 267 615 minecraft:black_concrete
fill 223 266 635 224 267 635 minecraft:black_concrete
fill 224 266 605 229 267 605 minecraft:black_concrete
fill 224 266 616 224 267 617 minecraft:black_concrete
fill 224 266 633 224 267 634 minecraft:black_concrete
fill 225 266 617 225 267 619 minecraft:black_concrete
fill 225 266 631 225 267 633 minecraft:black_concrete
fill 226 266 619 226 267 631 minecraft:black_concrete
fill 227 266 623 228 266 627 minecraft:black_concrete
fill 228 266 607 228 266 622 minecraft:black_concrete
fill 228 266 628 228 266 643 minecraft:black_concrete
fill 229 266 608 229 267 613 minecraft:black_concrete
fill 229 266 616 229 267 621 minecraft:black_concrete
fill 229 266 624 229 267 629 minecraft:black_concrete
fill 229 266 632 229 267 637 minecraft:black_concrete
fill 229 266 640 229 267 643 minecraft:black_concrete
fill 229 266 645 229 267 645 minecraft:black_concrete
fill 189 267 613 189 267 618 minecraft:black_concrete
fill 189 267 621 189 267 626 minecraft:black_concrete
fill 189 267 629 189 267 634 minecraft:black_concrete
fill 189 267 637 189 267 642 minecraft:black_concrete
fill 219 267 636 220 268 637 minecraft:lime_concrete
fill 227 267 623 227 267 627 minecraft:black_concrete
setblock 229 267 644 minecraft:black_concrete
fill 191 268 621 191 268 629 minecraft:sea_lantern
fill 192 268 618 192 268 620 minecraft:sea_lantern
fill 192 268 630 192 268 632 minecraft:sea_lantern
fill 193 268 616 193 268 617 minecraft:sea_lantern
fill 193 268 633 193 268 634 minecraft:sea_lantern
setblock 194 268 615 minecraft:sea_lantern
setblock 194 268 635 minecraft:sea_lantern
fill 195 268 613 195 268 614 minecraft:sea_lantern
fill 195 268 636 195 268 637 minecraft:sea_lantern
fill 196 268 612 196 268 613 minecraft:sea_lantern
fill 196 268 637 196 268 638 minecraft:sea_lantern
fill 197 268 611 197 268 612 minecraft:sea_lantern
fill 197 268 638 197 268 639 minecraft:sea_lantern
setblock 198 268 611 minecraft:sea_lantern
setblock 198 268 639 minecraft:sea_lantern
setblock 199 268 610 minecraft:sea_lantern
setblock 199 268 640 minecraft:sea_lantern
fill 200 268 609 201 268 609 minecraft:sea_lantern
fill 200 268 641 201 268 641 minecraft:sea_lantern
fill 202 268 608 204 268 608 minecraft:sea_lantern
fill 205 268 607 213 268 607 minecraft:sea_lantern
fill 214 268 608 216 268 608 minecraft:sea_lantern
fill 214 268 642 216 268 642 minecraft:sea_lantern
fill 215 268 618 215 269 618 minecraft:lime_concrete
fill 217 268 609 218 268 609 minecraft:sea_lantern
fill 217 268 641 218 268 641 minecraft:sea_lantern
setblock 219 268 610 minecraft:sea_lantern
setblock 219 268 640 minecraft:sea_lantern
fill 220 268 611 221 268 611 minecraft:sea_lantern
fill 220 268 639 221 268 639 minecraft:sea_lantern
fill 221 268 612 222 268 612 minecraft:sea_lantern
fill 221 268 638 222 268 638 minecraft:sea_lantern
fill 222 268 613 223 268 613 minecraft:sea_lantern
fill 222 268 637 223 268 637 minecraft:sea_lantern
setblock 223 268 614 minecraft:sea_lantern
setblock 223 268 636 minecraft:sea_lantern
setblock 224 268 615 minecraft:sea_lantern
setblock 224 268 635 minecraft:sea_lantern
fill 225 268 616 225 268 617 minecraft:sea_lantern
fill 225 268 633 225 268 634 minecraft:sea_lantern
fill 226 268 618 226 268 620 minecraft:sea_lantern
fill 226 268 630 226 268 632 minecraft:sea_lantern
fill 227 268 621 227 268 629 minecraft:sea_lantern
fill 188 270 609 188 273 609 minecraft:sea_lantern
fill 188 270 617 188 273 617 minecraft:sea_lantern
fill 188 270 625 188 273 625 minecraft:sea_lantern
fill 188 270 633 188 273 633 minecraft:sea_lantern
fill 188 270 641 188 273 641 minecraft:sea_lantern
setblock 191 270 607 minecraft:light[level=14]
setblock 191 270 615 minecraft:light[level=14]
setblock 191 270 623 minecraft:light[level=14]
setblock 191 270 631 minecraft:light[level=14]
setblock 191 270 639 minecraft:light[level=14]
fill 191 270 646 191 273 646 minecraft:sea_lantern
fill 195 270 604 195 273 604 minecraft:sea_lantern
setblock 199 270 607 minecraft:light[level=14]
setblock 199 270 615 minecraft:light[level=14]
setblock 199 270 623 minecraft:light[level=14]
setblock 199 270 631 minecraft:light[level=14]
setblock 199 270 639 minecraft:light[level=14]
fill 199 270 646 199 273 646 minecraft:sea_lantern
fill 203 270 604 203 273 604 minecraft:sea_lantern
setblock 207 270 607 minecraft:light[level=14]
setblock 207 270 615 minecraft:light[level=14]
setblock 207 270 631 minecraft:light[level=14]
setblock 207 270 639 minecraft:light[level=14]
fill 207 270 646 207 273 646 minecraft:sea_lantern
fill 211 270 604 211 273 604 minecraft:sea_lantern
setblock 215 270 607 minecraft:light[level=14]
setblock 215 270 615 minecraft:light[level=14]
setblock 215 270 623 minecraft:light[level=14]
setblock 215 270 631 minecraft:light[level=14]
setblock 215 270 639 minecraft:light[level=14]
fill 215 270 646 215 273 646 minecraft:sea_lantern
fill 219 270 604 219 273 604 minecraft:sea_lantern
setblock 223 270 607 minecraft:light[level=14]
setblock 223 270 615 minecraft:light[level=14]
setblock 223 270 623 minecraft:light[level=14]
setblock 223 270 631 minecraft:light[level=14]
setblock 223 270 639 minecraft:light[level=14]
fill 223 270 646 223 273 646 minecraft:sea_lantern
fill 227 270 604 227 273 604 minecraft:sea_lantern
fill 230 270 609 230 273 609 minecraft:sea_lantern
fill 230 270 617 230 273 617 minecraft:sea_lantern
fill 230 270 625 230 273 625 minecraft:sea_lantern
fill 230 270 633 230 273 633 minecraft:sea_lantern
fill 230 270 641 230 273 641 minecraft:sea_lantern
fill 188 274 609 188 283 609 minecraft:lime_concrete
fill 188 274 617 188 283 617 minecraft:lime_concrete
fill 188 274 625 188 283 625 minecraft:lime_concrete
fill 188 274 633 188 283 633 minecraft:lime_concrete
fill 188 274 641 188 283 641 minecraft:lime_concrete
fill 191 274 646 191 283 646 minecraft:lime_concrete
fill 195 274 604 195 283 604 minecraft:lime_concrete
fill 199 274 646 199 283 646 minecraft:lime_concrete
fill 203 274 604 203 283 604 minecraft:lime_concrete
fill 207 274 646 207 283 646 minecraft:lime_concrete
fill 211 274 604 211 283 604 minecraft:lime_concrete
fill 215 274 646 215 283 646 minecraft:lime_concrete
fill 219 274 604 219 283 604 minecraft:lime_concrete
fill 223 274 646 223 283 646 minecraft:lime_concrete
fill 227 274 604 227 283 604 minecraft:lime_concrete
fill 230 274 609 230 283 609 minecraft:lime_concrete
fill 230 274 617 230 283 617 minecraft:lime_concrete
fill 230 274 625 230 283 625 minecraft:lime_concrete
fill 230 274 633 230 283 633 minecraft:lime_concrete
fill 230 274 641 230 283 641 minecraft:lime_concrete
setblock 191 278 607 minecraft:light[level=14]
setblock 191 278 615 minecraft:light[level=14]
setblock 191 278 623 minecraft:light[level=14]
setblock 191 278 631 minecraft:light[level=14]
setblock 191 278 639 minecraft:light[level=14]
setblock 199 278 607 minecraft:light[level=14]
setblock 199 278 615 minecraft:light[level=14]
setblock 199 278 623 minecraft:light[level=14]
setblock 199 278 631 minecraft:light[level=14]
setblock 199 278 639 minecraft:light[level=14]
fill 202 278 621 204 278 623 minecraft:redstone_block
fill 206 278 627 208 278 629 minecraft:redstone_block
setblock 207 278 607 minecraft:light[level=14]
setblock 207 278 615 minecraft:light[level=14]
setblock 207 278 631 minecraft:light[level=14]
setblock 207 278 639 minecraft:light[level=14]
fill 210 278 618 212 278 620 minecraft:redstone_block
fill 211 278 625 213 278 627 minecraft:redstone_block
setblock 215 278 607 minecraft:light[level=14]
setblock 215 278 615 minecraft:light[level=14]
setblock 215 278 623 minecraft:light[level=14]
setblock 215 278 631 minecraft:light[level=14]
setblock 215 278 639 minecraft:light[level=14]
setblock 223 278 607 minecraft:light[level=14]
setblock 223 278 615 minecraft:light[level=14]
setblock 223 278 623 minecraft:light[level=14]
setblock 223 278 631 minecraft:light[level=14]
setblock 223 278 639 minecraft:light[level=14]
fill 189 279 605 189 280 607 minecraft:lime_concrete
fill 189 279 608 189 280 610 minecraft:black_concrete
fill 189 279 611 189 280 613 minecraft:lime_concrete
fill 189 279 614 189 280 616 minecraft:black_concrete
fill 189 279 617 189 280 619 minecraft:lime_concrete
fill 189 279 620 189 280 622 minecraft:black_concrete
fill 189 279 623 189 280 625 minecraft:lime_concrete
fill 189 279 626 189 280 628 minecraft:black_concrete
fill 189 279 629 189 280 631 minecraft:lime_concrete
fill 189 279 632 189 280 634 minecraft:black_concrete
fill 189 279 635 189 280 637 minecraft:lime_concrete
fill 189 279 638 189 280 640 minecraft:black_concrete
fill 189 279 641 189 280 643 minecraft:lime_concrete
fill 189 279 644 189 280 645 minecraft:black_concrete
fill 190 279 605 192 280 607 minecraft:black_concrete
fill 190 279 608 192 280 610 minecraft:lime_concrete
fill 190 279 611 192 280 613 minecraft:black_concrete
fill 190 279 614 192 280 616 minecraft:lime_concrete
fill 190 279 617 192 280 619 minecraft:black_concrete
fill 190 279 620 192 280 622 minecraft:lime_concrete
fill 190 279 623 192 280 625 minecraft:black_concrete
fill 190 279 626 192 280 628 minecraft:lime_concrete
fill 190 279 629 192 280 631 minecraft:black_concrete
fill 190 279 632 192 280 634 minecraft:lime_concrete
fill 190 279 635 192 280 637 minecraft:black_concrete
fill 190 279 638 192 280 640 minecraft:lime_concrete
fill 190 279 641 192 280 643 minecraft:black_concrete
fill 190 279 644 192 280 645 minecraft:lime_concrete
fill 193 279 605 195 280 607 minecraft:lime_concrete
fill 193 279 608 195 280 610 minecraft:black_concrete
fill 193 279 611 195 280 613 minecraft:lime_concrete
fill 193 279 614 195 280 616 minecraft:black_concrete
fill 193 279 617 195 280 619 minecraft:lime_concrete
fill 193 279 620 195 280 622 minecraft:black_concrete
fill 193 279 623 195 280 625 minecraft:lime_concrete
fill 193 279 626 195 280 628 minecraft:black_concrete
fill 193 279 629 195 280 631 minecraft:lime_concrete
fill 193 279 632 195 280 634 minecraft:black_concrete
fill 193 279 635 195 280 637 minecraft:lime_concrete
fill 193 279 638 195 280 640 minecraft:black_concrete
fill 193 279 641 195 280 643 minecraft:lime_concrete
fill 193 279 644 195 280 645 minecraft:black_concrete
fill 196 279 605 198 280 607 minecraft:black_concrete
fill 196 279 608 198 280 610 minecraft:lime_concrete
fill 196 279 611 198 280 613 minecraft:black_concrete
fill 196 279 614 198 280 616 minecraft:lime_concrete
fill 196 279 617 198 280 619 minecraft:black_concrete
fill 196 279 620 198 280 622 minecraft:lime_concrete
fill 196 279 623 198 280 625 minecraft:black_concrete
fill 196 279 626 198 280 628 minecraft:lime_concrete
fill 196 279 629 198 280 631 minecraft:black_concrete
fill 196 279 632 198 280 634 minecraft:lime_concrete
fill 196 279 635 198 280 637 minecraft:black_concrete
fill 196 279 638 198 280 640 minecraft:lime_concrete
fill 196 279 641 198 280 643 minecraft:black_concrete
fill 196 279 644 198 280 645 minecraft:lime_concrete
fill 199 279 605 201 280 607 minecraft:lime_concrete
fill 199 279 608 201 280 610 minecraft:black_concrete
fill 199 279 611 201 280 613 minecraft:lime_concrete
fill 199 279 614 201 280 616 minecraft:black_concrete
fill 199 279 617 201 280 619 minecraft:lime_concrete
fill 199 279 620 201 279 622 minecraft:black_concrete
fill 199 279 623 201 279 625 minecraft:lime_concrete
fill 199 279 626 201 280 628 minecraft:black_concrete
fill 199 279 629 201 280 631 minecraft:lime_concrete
fill 199 279 632 201 280 634 minecraft:black_concrete
fill 199 279 635 201 280 637 minecraft:lime_concrete
fill 199 279 638 201 280 640 minecraft:black_concrete
fill 199 279 641 201 280 643 minecraft:lime_concrete
fill 199 279 644 201 280 645 minecraft:black_concrete
fill 202 279 605 204 280 607 minecraft:black_concrete
fill 202 279 608 204 280 610 minecraft:lime_concrete
fill 202 279 611 204 280 613 minecraft:black_concrete
fill 202 279 614 204 280 616 minecraft:lime_concrete
fill 202 279 617 204 280 619 minecraft:black_concrete
fill 202 279 620 204 279 620 minecraft:lime_concrete
fill 202 279 624 204 279 625 minecraft:black_concrete
fill 202 279 626 204 280 628 minecraft:lime_concrete
fill 202 279 629 204 280 631 minecraft:black_concrete
fill 202 279 632 204 280 634 minecraft:lime_concrete
fill 202 279 635 204 280 637 minecraft:black_concrete
fill 202 279 638 204 280 640 minecraft:lime_concrete
fill 202 279 641 204 280 643 minecraft:black_concrete
fill 202 279 644 204 280 645 minecraft:lime_concrete
fill 205 279 605 207 280 607 minecraft:lime_concrete
fill 205 279 608 207 280 610 minecraft:black_concrete
fill 205 279 611 207 280 613 minecraft:lime_concrete
fill 205 279 614 207 280 616 minecraft:black_concrete
fill 205 279 617 207 280 619 minecraft:lime_concrete
fill 205 279 620 206 279 622 minecraft:black_concrete
fill 205 279 623 206 279 625 minecraft:lime_concrete
fill 205 279 626 205 279 628 minecraft:black_concrete
fill 205 279 629 205 279 631 minecraft:lime_concrete
fill 205 279 632 207 280 634 minecraft:black_concrete
fill 205 279 635 207 280 637 minecraft:lime_concrete
fill 205 279 638 207 280 640 minecraft:black_concrete
fill 205 279 641 207 280 643 minecraft:lime_concrete
fill 205 279 644 207 280 645 minecraft:black_concrete
fill 206 279 626 207 279 626 minecraft:black_concrete
fill 206 279 630 207 279 631 minecraft:lime_concrete
fill 207 279 620 207 279 621 minecraft:black_concrete
setblock 207 279 625 minecraft:lime_concrete
fill 208 279 605 210 280 607 minecraft:black_concrete
fill 208 279 608 210 280 610 minecraft:lime_concrete
fill 208 279 611 210 280 613 minecraft:black_concrete
fill 208 279 614 210 280 616 minecraft:lime_concrete
fill 208 279 617 209 279 619 minecraft:black_concrete
fill 208 279 620 209 279 621 minecraft:lime_concrete
fill 208 279 625 210 279 625 minecraft:black_concrete
fill 208 279 626 210 279 626 minecraft:lime_concrete
fill 208 279 630 210 279 631 minecraft:black_concrete
fill 208 279 632 210 280 634 minecraft:lime_concrete
fill 208 279 635 210 280 637 minecraft:black_concrete
fill 208 279 638 210 280 640 minecraft:lime_concrete
fill 208 279 641 210 280 643 minecraft:black_concrete
fill 208 279 644 210 280 645 minecraft:lime_concrete
fill 209 279 627 210 279 628 minecraft:lime_concrete
fill 209 279 629 210 279 629 minecraft:black_concrete
setblock 210 279 617 minecraft:black_concrete
fill 210 279 621 210 279 622 minecraft:lime_concrete
fill 210 279 623 210 279 624 minecraft:black_concrete
fill 211 279 605 213 280 607 minecraft:lime_concrete
fill 211 279 608 213 280 610 minecraft:black_concrete
fill 211 279 611 213 280 613 minecraft:lime_concrete
fill 211 279 614 213 280 616 minecraft:black_concrete
fill 211 279 617 213 279 617 minecraft:lime_concrete
fill 211 279 621 213 279 622 minecraft:black_concrete
fill 211 279 623 213 279 624 minecraft:lime_concrete
fill 211 279 628 213 279 628 minecraft:black_concrete
fill 211 279 629 213 280 631 minecraft:lime_concrete
fill 211 279 632 213 280 634 minecraft:black_concrete
fill 211 279 635 213 280 637 minecraft:lime_concrete
fill 211 279 638 213 280 640 minecraft:black_concrete
fill 211 279 641 213 280 643 minecraft:lime_concrete
fill 211 279 644 213 280 645 minecraft:black_concrete
fill 213 279 618 213 279 619 minecraft:lime_concrete
setblock 213 279 620 minecraft:black_concrete
fill 214 279 605 216 280 607 minecraft:black_concrete
fill 214 279 608 216 280 610 minecraft:lime_concrete
fill 214 279 611 216 280 613 minecraft:black_concrete
fill 214 279 614 216 280 616 minecraft:lime_concrete
fill 214 279 617 216 280 619 minecraft:black_concrete
fill 214 279 620 216 280 622 minecraft:lime_concrete
fill 214 279 623 216 279 625 minecraft:black_concrete
fill 214 279 626 216 279 628 minecraft:lime_concrete
fill 214 279 629 216 280 631 minecraft:black_concrete
fill 214 279 632 216 280 634 minecraft:lime_concrete
fill 214 279 635 216 280 637 minecraft:black_concrete
fill 214 279 638 216 280 640 minecraft:lime_concrete
fill 214 279 641 216 280 643 minecraft:black_concrete
fill 214 279 644 216 280 645 minecraft:lime_concrete
fill 217 279 605 219 280 607 minecraft:lime_concrete
fill 217 279 608 219 280 610 minecraft:black_concrete
fill 217 279 611 219 280 613 minecraft:lime_concrete
fill 217 279 614 219 280 616 minecraft:black_concrete
fill 217 279 617 219 280 619 minecraft:lime_concrete
fill 217 279 620 219 280 622 minecraft:black_concrete
fill 217 279 623 219 280 625 minecraft:lime_concrete
fill 217 279 626 219 280 628 minecraft:black_concrete
fill 217 279 629 219 280 631 minecraft:lime_concrete
fill 217 279 632 219 280 634 minecraft:black_concrete
fill 217 279 635 219 280 637 minecraft:lime_concrete
fill 217 279 638 219 280 640 minecraft:black_concrete
fill 217 279 641 219 280 643 minecraft:lime_concrete
fill 217 279 644 219 280 645 minecraft:black_concrete
fill 220 279 605 222 280 607 minecraft:black_concrete
fill 220 279 608 222 280 610 minecraft:lime_concrete
fill 220 279 611 222 280 613 minecraft:black_concrete
fill 220 279 614 222 280 616 minecraft:lime_concrete
fill 220 279 617 222 280 619 minecraft:black_concrete
fill 220 279 620 222 280 622 minecraft:lime_concrete
fill 220 279 623 222 280 625 minecraft:black_concrete
fill 220 279 626 222 280 628 minecraft:lime_concrete
fill 220 279 629 222 280 631 minecraft:black_concrete
fill 220 279 632 222 280 634 minecraft:lime_concrete
fill 220 279 635 222 280 637 minecraft:black_concrete
fill 220 279 638 222 280 640 minecraft:lime_concrete
fill 220 279 641 222 280 643 minecraft:black_concrete
fill 220 279 644 222 280 645 minecraft:lime_concrete
fill 223 279 605 225 280 607 minecraft:lime_concrete
fill 223 279 608 225 280 610 minecraft:black_concrete
fill 223 279 611 225 280 613 minecraft:lime_concrete
fill 223 279 614 225 280 616 minecraft:black_concrete
fill 223 279 617 225 280 619 minecraft:lime_concrete
fill 223 279 620 225 280 622 minecraft:black_concrete
fill 223 279 623 225 280 625 minecraft:lime_concrete
fill 223 279 626 225 280 628 minecraft:black_concrete
fill 223 279 629 225 280 631 minecraft:lime_concrete
fill 223 279 632 225 280 634 minecraft:black_concrete
fill 223 279 635 225 280 637 minecraft:lime_concrete
fill 223 279 638 225 280 640 minecraft:black_concrete
fill 223 279 641 225 280 643 minecraft:lime_concrete
fill 223 279 644 225 280 645 minecraft:black_concrete
fill 226 279 605 228 280 607 minecraft:black_concrete
fill 226 279 608 228 280 610 minecraft:lime_concrete
fill 226 279 611 228 280 613 minecraft:black_concrete
fill 226 279 614 228 280 616 minecraft:lime_concrete
fill 226 279 617 228 280 619 minecraft:black_concrete
fill 226 279 620 228 280 622 minecraft:lime_concrete
fill 226 279 623 228 280 625 minecraft:black_concrete
fill 226 279 626 228 280 628 minecraft:lime_concrete
fill 226 279 629 228 280 631 minecraft:black_concrete
fill 226 279 632 228 280 634 minecraft:lime_concrete
fill 226 279 635 228 280 637 minecraft:black_concrete
fill 226 279 638 228 280 640 minecraft:lime_concrete
fill 226 279 641 228 280 643 minecraft:black_concrete
fill 226 279 644 228 280 645 minecraft:lime_concrete
fill 229 279 605 229 280 607 minecraft:lime_concrete
fill 229 279 608 229 280 610 minecraft:black_concrete
fill 229 279 611 229 280 613 minecraft:lime_concrete
fill 229 279 614 229 280 616 minecraft:black_concrete
fill 229 279 617 229 280 619 minecraft:lime_concrete
fill 229 279 620 229 280 622 minecraft:black_concrete
fill 229 279 623 229 280 625 minecraft:lime_concrete
fill 229 279 626 229 280 628 minecraft:black_concrete
fill 229 279 629 229 280 631 minecraft:lime_concrete
fill 229 279 632 229 280 634 minecraft:black_concrete
fill 229 279 635 229 280 637 minecraft:lime_concrete
fill 229 279 638 229 280 640 minecraft:black_concrete
fill 229 279 641 229 280 643 minecraft:lime_concrete
fill 229 279 644 229 280 645 minecraft:black_concrete
fill 199 280 620 200 280 622 minecraft:black_concrete
fill 199 280 623 200 280 625 minecraft:lime_concrete
fill 201 280 620 201 280 624 minecraft:sea_lantern
setblock 201 280 625 minecraft:lime_concrete
fill 202 280 620 205 280 620 minecraft:sea_lantern
fill 202 280 621 204 280 623 minecraft:lime_concrete
fill 202 280 624 206 280 624 minecraft:sea_lantern
fill 202 280 625 204 280 625 minecraft:black_concrete
fill 205 280 621 206 280 623 minecraft:sea_lantern
setblock 205 280 625 minecraft:lime_concrete
fill 205 280 626 205 280 630 minecraft:sea_lantern
fill 205 280 631 207 280 631 minecraft:lime_concrete
fill 206 280 620 207 280 620 minecraft:black_concrete
fill 206 280 625 210 280 626 minecraft:sea_lantern
fill 206 280 627 208 280 629 minecraft:lime_concrete
fill 206 280 630 209 280 630 minecraft:sea_lantern
fill 207 280 621 213 280 621 minecraft:sea_lantern
fill 208 280 617 208 280 619 minecraft:black_concrete
setblock 208 280 620 minecraft:lime_concrete
fill 208 280 631 210 280 631 minecraft:black_concrete
fill 209 280 617 209 280 620 minecraft:sea_lantern
fill 209 280 627 209 280 629 minecraft:sea_lantern
fill 210 280 617 213 280 617 minecraft:sea_lantern
fill 210 280 618 212 280 620 minecraft:lime_concrete
fill 210 280 622 210 280 624 minecraft:sea_lantern
fill 210 280 627 210 280 628 minecraft:sea_lantern
fill 210 280 629 210 280 630 minecraft:black_concrete
fill 211 280 622 213 280 622 minecraft:black_concrete
fill 211 280 623 213 280 623 minecraft:lime_concrete
fill 211 280 624 214 280 624 minecraft:sea_lantern
fill 211 280 625 213 280 627 minecraft:lime_concrete
fill 211 280 628 214 280 628 minecraft:sea_lantern
fill 213 280 618 213 280 620 minecraft:sea_lantern
fill 214 280 623 216 280 623 minecraft:black_concrete
fill 214 280 625 214 280 627 minecraft:sea_lantern
fill 215 280 624 216 280 625 minecraft:black_concrete
fill 215 280 626 216 280 628 minecraft:lime_concrete
fill 188 284 609 188 289 609 minecraft:sea_lantern
fill 188 284 617 188 289 617 minecraft:sea_lantern
fill 188 284 625 188 289 625 minecraft:sea_lantern
fill 188 284 633 188 289 633 minecraft:sea_lantern
fill 188 284 641 188 289 641 minecraft:sea_lantern
fill 189 284 611 189 300 612 minecraft:black_concrete
fill 189 284 619 189 300 620 minecraft:black_concrete
fill 189 284 627 189 300 628 minecraft:black_concrete
fill 189 284 635 189 300 636 minecraft:black_concrete
fill 189 284 643 189 300 644 minecraft:black_concrete
fill 190 284 605 191 300 605 minecraft:black_concrete
fill 191 284 646 191 289 646 minecraft:sea_lantern
fill 195 284 604 195 289 604 minecraft:sea_lantern
fill 195 284 645 196 300 645 minecraft:black_concrete
fill 196 284 623 198 284 624 minecraft:lime_concrete
fill 198 284 605 199 300 605 minecraft:black_concrete
fill 199 284 646 199 289 646 minecraft:sea_lantern
fill 201 284 605 213 285 608 minecraft:black_concrete
fill 203 284 604 203 289 604 minecraft:sea_lantern
fill 203 284 645 204 300 645 minecraft:black_concrete
fill 207 284 646 207 289 646 minecraft:sea_lantern
fill 211 284 604 211 289 604 minecraft:sea_lantern
fill 211 284 645 212 300 645 minecraft:black_concrete
fill 214 284 605 215 300 605 minecraft:black_concrete
fill 215 284 646 215 289 646 minecraft:sea_lantern
fill 219 284 604 219 289 604 minecraft:sea_lantern
fill 219 284 645 220 300 645 minecraft:black_concrete
fill 222 284 605 223 300 605 minecraft:black_concrete
fill 223 284 646 223 289 646 minecraft:sea_lantern
fill 227 284 604 227 289 604 minecraft:sea_lantern
fill 227 284 645 228 300 645 minecraft:black_concrete
fill 229 284 606 229 300 607 minecraft:black_concrete
fill 229 284 614 229 300 615 minecraft:black_concrete
fill 229 284 622 229 300 623 minecraft:black_concrete
fill 229 284 630 229 300 631 minecraft:black_concrete
fill 229 284 638 229 300 639 minecraft:black_concrete
fill 230 284 609 230 289 609 minecraft:sea_lantern
fill 230 284 617 230 289 617 minecraft:sea_lantern
fill 230 284 625 230 289 625 minecraft:sea_lantern
fill 230 284 633 230 289 633 minecraft:sea_lantern
fill 230 284 641 230 289 641 minecraft:sea_lantern
setblock 191 286 607 minecraft:light[level=14]
setblock 191 286 615 minecraft:light[level=14]
setblock 191 286 623 minecraft:light[level=14]
setblock 191 286 631 minecraft:light[level=14]
setblock 191 286 639 minecraft:light[level=14]
setblock 199 286 607 minecraft:light[level=14]
setblock 199 286 615 minecraft:light[level=14]
setblock 199 286 623 minecraft:light[level=14]
setblock 199 286 631 minecraft:light[level=14]
setblock 199 286 639 minecraft:light[level=14]
setblock 201 286 605 minecraft:sea_lantern
fill 201 286 606 201 300 606 minecraft:black_concrete
setblock 201 286 607 minecraft:sea_lantern
fill 201 286 608 201 300 608 minecraft:black_concrete
fill 202 286 605 202 300 605 minecraft:black_concrete
setblock 202 286 606 minecraft:sea_lantern
fill 202 286 607 202 300 607 minecraft:black_concrete
setblock 202 286 608 minecraft:sea_lantern
setblock 203 286 605 minecraft:sea_lantern
fill 203 286 606 203 300 606 minecraft:black_concrete
setblock 203 286 607 minecraft:sea_lantern
fill 203 286 608 203 300 608 minecraft:black_concrete
fill 204 286 605 204 300 605 minecraft:black_concrete
setblock 204 286 606 minecraft:sea_lantern
fill 204 286 607 204 300 607 minecraft:black_concrete
setblock 204 286 608 minecraft:sea_lantern
setblock 205 286 605 minecraft:sea_lantern
fill 205 286 606 205 300 606 minecraft:black_concrete
setblock 205 286 607 minecraft:sea_lantern
fill 205 286 608 205 300 608 minecraft:black_concrete
fill 206 286 605 206 300 605 minecraft:black_concrete
setblock 206 286 606 minecraft:sea_lantern
fill 206 286 607 206 300 607 minecraft:black_concrete
setblock 206 286 608 minecraft:sea_lantern
setblock 207 286 605 minecraft:sea_lantern
fill 207 286 606 207 300 606 minecraft:black_concrete
setblock 207 286 607 minecraft:sea_lantern
fill 207 286 608 207 300 608 minecraft:black_concrete
setblock 207 286 615 minecraft:light[level=14]
setblock 207 286 631 minecraft:light[level=14]
setblock 207 286 639 minecraft:light[level=14]
fill 208 286 605 208 300 605 minecraft:black_concrete
setblock 208 286 606 minecraft:sea_lantern
fill 208 286 607 208 300 607 minecraft:black_concrete
setblock 208 286 608 minecraft:sea_lantern
setblock 209 286 605 minecraft:sea_lantern
fill 209 286 606 209 300 606 minecraft:black_concrete
setblock 209 286 607 minecraft:sea_lantern
fill 209 286 608 209 300 608 minecraft:black_concrete
fill 210 286 605 210 300 605 minecraft:black_concrete
setblock 210 286 606 minecraft:sea_lantern
fill 210 286 607 210 300 607 minecraft:black_concrete
setblock 210 286 608 minecraft:sea_lantern
setblock 211 286 605 minecraft:sea_lantern
fill 211 286 606 211 300 606 minecraft:black_concrete
setblock 211 286 607 minecraft:sea_lantern
fill 211 286 608 211 300 608 minecraft:black_concrete
fill 212 286 605 212 300 605 minecraft:black_concrete
setblock 212 286 606 minecraft:sea_lantern
fill 212 286 607 212 300 607 minecraft:black_concrete
setblock 212 286 608 minecraft:sea_lantern
setblock 213 286 605 minecraft:sea_lantern
fill 213 286 606 213 300 606 minecraft:black_concrete
setblock 213 286 607 minecraft:sea_lantern
fill 213 286 608 213 300 608 minecraft:black_concrete
setblock 215 286 607 minecraft:light[level=14]
setblock 215 286 615 minecraft:light[level=14]
setblock 215 286 623 minecraft:light[level=14]
setblock 215 286 631 minecraft:light[level=14]
setblock 215 286 639 minecraft:light[level=14]
setblock 223 286 607 minecraft:light[level=14]
setblock 223 286 615 minecraft:light[level=14]
setblock 223 286 623 minecraft:light[level=14]
setblock 223 286 631 minecraft:light[level=14]
setblock 223 286 639 minecraft:light[level=14]
fill 201 287 605 201 288 605 minecraft:black_concrete
fill 201 287 607 201 288 607 minecraft:black_concrete
fill 201 287 632 201 288 632 minecraft:lime_concrete
fill 202 287 606 202 288 606 minecraft:black_concrete
fill 202 287 608 202 288 608 minecraft:black_concrete
fill 203 287 605 203 288 605 minecraft:black_concrete
fill 203 287 607 203 288 607 minecraft:black_concrete
fill 204 287 606 204 288 606 minecraft:black_concrete
fill 204 287 608 204 288 608 minecraft:black_concrete
fill 205 287 605 205 288 605 minecraft:black_concrete
fill 205 287 607 205 288 607 minecraft:black_concrete
fill 206 287 606 206 288 606 minecraft:black_concrete
fill 206 287 608 206 288 608 minecraft:black_concrete
fill 207 287 605 207 288 605 minecraft:black_concrete
fill 207 287 607 207 288 607 minecraft:black_concrete
fill 208 287 606 208 288 606 minecraft:black_concrete
fill 208 287 608 208 288 608 minecraft:black_concrete
fill 209 287 605 209 288 605 minecraft:black_concrete
fill 209 287 607 209 288 607 minecraft:black_concrete
fill 210 287 606 210 288 606 minecraft:black_concrete
fill 210 287 608 210 288 608 minecraft:black_concrete
fill 211 287 605 211 288 605 minecraft:black_concrete
fill 211 287 607 211 288 607 minecraft:black_concrete
fill 212 287 606 212 288 606 minecraft:black_concrete
fill 212 287 608 212 288 608 minecraft:black_concrete
fill 213 287 605 213 288 605 minecraft:black_concrete
fill 213 287 607 213 288 607 minecraft:black_concrete
setblock 201 289 605 minecraft:sea_lantern
setblock 201 289 607 minecraft:sea_lantern
setblock 202 289 606 minecraft:sea_lantern
setblock 202 289 608 minecraft:sea_lantern
setblock 203 289 605 minecraft:sea_lantern
setblock 203 289 607 minecraft:sea_lantern
setblock 204 289 606 minecraft:sea_lantern
setblock 204 289 608 minecraft:sea_lantern
setblock 205 289 605 minecraft:sea_lantern
setblock 205 289 607 minecraft:sea_lantern
setblock 206 289 606 minecraft:sea_lantern
setblock 206 289 608 minecraft:sea_lantern
setblock 207 289 605 minecraft:sea_lantern
setblock 207 289 607 minecraft:sea_lantern
setblock 208 289 606 minecraft:sea_lantern
setblock 208 289 608 minecraft:sea_lantern
setblock 209 289 605 minecraft:sea_lantern
setblock 209 289 607 minecraft:sea_lantern
setblock 210 289 606 minecraft:sea_lantern
setblock 210 289 608 minecraft:sea_lantern
setblock 211 289 605 minecraft:sea_lantern
setblock 211 289 607 minecraft:sea_lantern
setblock 212 289 606 minecraft:sea_lantern
setblock 212 289 608 minecraft:sea_lantern
setblock 213 289 605 minecraft:sea_lantern
setblock 213 289 607 minecraft:sea_lantern
fill 188 290 609 188 297 609 minecraft:lime_concrete
fill 188 290 617 188 297 617 minecraft:lime_concrete
fill 188 290 625 188 297 625 minecraft:lime_concrete
fill 188 290 633 188 297 633 minecraft:lime_concrete
fill 188 290 641 188 297 641 minecraft:lime_concrete
fill 191 290 646 191 297 646 minecraft:lime_concrete
fill 195 290 604 195 297 604 minecraft:lime_concrete
fill 199 290 646 199 297 646 minecraft:lime_concrete
fill 201 290 605 201 291 605 minecraft:black_concrete
fill 201 290 607 201 291 607 minecraft:black_concrete
fill 202 290 606 202 291 606 minecraft:black_concrete
fill 202 290 608 202 291 608 minecraft:black_concrete
fill 203 290 604 203 297 604 minecraft:lime_concrete
fill 203 290 605 203 291 605 minecraft:black_concrete
fill 203 290 607 203 291 607 minecraft:black_concrete
fill 204 290 606 204 291 606 minecraft:black_concrete
fill 204 290 608 204 291 608 minecraft:black_concrete
fill 205 290 605 205 291 605 minecraft:black_concrete
fill 205 290 607 205 291 607 minecraft:black_concrete
fill 206 290 606 206 291 606 minecraft:black_concrete
fill 206 290 608 206 291 608 minecraft:black_concrete
fill 207 290 605 207 291 605 minecraft:black_concrete
fill 207 290 607 207 291 607 minecraft:black_concrete
fill 207 290 646 207 297 646 minecraft:lime_concrete
fill 208 290 606 208 291 606 minecraft:black_concrete
fill 208 290 608 208 291 608 minecraft:black_concrete
fill 209 290 605 209 291 605 minecraft:black_concrete
fill 209 290 607 209 291 607 minecraft:black_concrete
fill 210 290 606 210 291 606 minecraft:black_concrete
fill 210 290 608 210 291 608 minecraft:black_concrete
fill 211 290 604 211 297 604 minecraft:lime_concrete
fill 211 290 605 211 291 605 minecraft:black_concrete
fill 211 290 607 211 291 607 minecraft:black_concrete
fill 212 290 606 212 291 606 minecraft:black_concrete
fill 212 290 608 212 291 608 minecraft:black_concrete
fill 213 290 605 213 291 605 minecraft:black_concrete
fill 213 290 607 213 291 607 minecraft:black_concrete
fill 215 290 646 215 297 646 minecraft:lime_concrete
fill 219 290 604 219 297 604 minecraft:lime_concrete
fill 223 290 646 223 297 646 minecraft:lime_concrete
fill 227 290 604 227 297 604 minecraft:lime_concrete
fill 230 290 609 230 297 609 minecraft:lime_concrete
fill 230 290 617 230 297 617 minecraft:lime_concrete
fill 230 290 625 230 297 625 minecraft:lime_concrete
fill 230 290 633 230 297 633 minecraft:lime_concrete
fill 230 290 641 230 297 641 minecraft:lime_concrete
fill 210 291 643 210 292 643 minecraft:magenta_concrete
setblock 201 292 605 minecraft:sea_lantern
setblock 201 292 607 minecraft:sea_lantern
setblock 202 292 606 minecraft:sea_lantern
setblock 202 292 608 minecraft:sea_lantern
setblock 203 292 605 minecraft:sea_lantern
setblock 203 292 607 minecraft:sea_lantern
setblock 204 292 606 minecraft:sea_lantern
setblock 204 292 608 minecraft:sea_lantern
setblock 205 292 605 minecraft:sea_lantern
setblock 205 292 607 minecraft:sea_lantern
setblock 206 292 606 minecraft:sea_lantern
setblock 206 292 608 minecraft:sea_lantern
setblock 207 292 605 minecraft:sea_lantern
setblock 207 292 607 minecraft:sea_lantern
setblock 208 292 606 minecraft:sea_lantern
setblock 208 292 608 minecraft:sea_lantern
setblock 209 292 605 minecraft:sea_lantern
setblock 209 292 607 minecraft:sea_lantern
setblock 210 292 606 minecraft:sea_lantern
setblock 210 292 608 minecraft:sea_lantern
setblock 211 292 605 minecraft:sea_lantern
setblock 211 292 607 minecraft:sea_lantern
setblock 212 292 606 minecraft:sea_lantern
setblock 212 292 608 minecraft:sea_lantern
setblock 213 292 605 minecraft:sea_lantern
setblock 213 292 607 minecraft:sea_lantern
fill 201 293 605 201 294 605 minecraft:black_concrete
fill 201 293 607 201 294 607 minecraft:black_concrete
fill 202 293 606 202 294 606 minecraft:black_concrete
fill 202 293 608 202 294 608 minecraft:black_concrete
fill 203 293 605 203 294 605 minecraft:black_concrete
fill 203 293 607 203 294 607 minecraft:black_concrete
fill 204 293 606 204 294 606 minecraft:black_concrete
fill 204 293 608 204 294 608 minecraft:black_concrete
fill 205 293 605 205 294 605 minecraft:black_concrete
fill 205 293 607 205 294 607 minecraft:black_concrete
fill 206 293 606 206 294 606 minecraft:black_concrete
fill 206 293 608 206 294 608 minecraft:black_concrete
fill 207 293 605 207 294 605 minecraft:black_concrete
fill 207 293 607 207 294 607 minecraft:black_concrete
fill 208 293 606 208 294 606 minecraft:black_concrete
fill 208 293 608 208 294 608 minecraft:black_concrete
fill 209 293 605 209 294 605 minecraft:black_concrete
fill 209 293 607 209 294 607 minecraft:black_concrete
fill 210 293 606 210 294 606 minecraft:black_concrete
fill 210 293 608 210 294 608 minecraft:black_concrete
fill 211 293 605 211 294 605 minecraft:black_concrete
fill 211 293 607 211 294 607 minecraft:black_concrete
fill 212 293 606 212 294 606 minecraft:black_concrete
fill 212 293 608 212 294 608 minecraft:black_concrete
fill 213 293 605 213 294 605 minecraft:black_concrete
fill 213 293 607 213 294 607 minecraft:black_concrete
fill 189 294 605 189 295 610 minecraft:black_concrete
fill 189 294 613 190 294 618 minecraft:black_concrete
fill 189 294 621 190 294 626 minecraft:black_concrete
fill 189 294 629 190 294 634 minecraft:black_concrete
fill 189 294 637 190 294 642 minecraft:black_concrete
fill 189 294 645 194 295 645 minecraft:black_concrete
fill 190 294 606 190 294 612 minecraft:black_concrete
fill 190 294 619 190 294 620 minecraft:black_concrete
fill 190 294 627 190 294 628 minecraft:black_concrete
fill 190 294 635 190 294 636 minecraft:black_concrete
fill 190 294 643 190 294 644 minecraft:black_concrete
fill 191 294 606 200 294 606 minecraft:black_concrete
setblock 191 294 607 minecraft:light[level=14]
setblock 191 294 615 minecraft:light[level=14]
setblock 191 294 623 minecraft:light[level=14]
setblock 191 294 631 minecraft:light[level=14]
setblock 191 294 639 minecraft:light[level=14]
fill 191 294 644 229 294 644 minecraft:black_concrete
fill 192 294 605 197 295 605 minecraft:black_concrete
fill 197 294 645 202 295 645 minecraft:black_concrete
setblock 199 294 607 minecraft:light[level=14]
setblock 199 294 615 minecraft:light[level=14]
setblock 199 294 623 minecraft:light[level=14]
setblock 199 294 631 minecraft:light[level=14]
setblock 199 294 639 minecraft:light[level=14]
fill 200 294 605 200 295 605 minecraft:black_concrete
fill 205 294 645 210 295 645 minecraft:black_concrete
setblock 207 294 615 minecraft:light[level=14]
setblock 207 294 631 minecraft:light[level=14]
setblock 207 294 639 minecraft:light[level=14]
fill 213 294 645 218 295 645 minecraft:black_concrete
fill 214 294 606 228 294 606 minecraft:black_concrete
setblock 215 294 607 minecraft:light[level=14]
setblock 215 294 615 minecraft:light[level=14]
setblock 215 294 623 minecraft:light[level=14]
setblock 215 294 631 minecraft:light[level=14]
setblock 215 294 639 minecraft:light[level=14]
fill 216 294 605 221 295 605 minecraft:black_concrete
fill 221 294 645 226 295 645 minecraft:black_concrete
setblock 223 294 607 minecraft:light[level=14]
setblock 223 294 615 minecraft:light[level=14]
setblock 223 294 623 minecraft:light[level=14]
setblock 223 294 631 minecraft:light[level=14]
setblock 223 294 639 minecraft:light[level=14]
fill 224 294 605 229 295 605 minecraft:black_concrete
fill 226 294 627 226 295 629 minecraft:lime_concrete
fill 227 294 628 227 295 629 minecraft:lime_concrete
fill 228 294 607 228 294 643 minecraft:black_concrete
fill 229 294 608 229 295 613 minecraft:black_concrete
fill 229 294 616 229 295 621 minecraft:black_concrete
fill 229 294 624 229 295 629 minecraft:black_concrete
fill 229 294 632 229 295 637 minecraft:black_concrete
fill 229 294 640 229 295 643 minecraft:black_concrete
fill 229 294 645 229 295 645 minecraft:black_concrete
fill 189 295 613 189 295 618 minecraft:black_concrete
fill 189 295 621 189 295 626 minecraft:black_concrete
fill 189 295 629 189 295 634 minecraft:black_concrete
fill 189 295 637 189 295 642 minecraft:black_concrete
setblock 201 295 605 minecraft:sea_lantern
setblock 201 295 607 minecraft:sea_lantern
setblock 202 295 606 minecraft:sea_lantern
setblock 202 295 608 minecraft:sea_lantern
setblock 203 295 605 minecraft:sea_lantern
setblock 203 295 607 minecraft:sea_lantern
setblock 204 295 606 minecraft:sea_lantern
setblock 204 295 608 minecraft:sea_lantern
setblock 205 295 605 minecraft:sea_lantern
setblock 205 295 607 minecraft:sea_lantern
setblock 206 295 606 minecraft:sea_lantern
setblock 206 295 608 minecraft:sea_lantern
setblock 207 295 605 minecraft:sea_lantern
setblock 207 295 607 minecraft:sea_lantern
setblock 208 295 606 minecraft:sea_lantern
setblock 208 295 608 minecraft:sea_lantern
setblock 209 295 605 minecraft:sea_lantern
setblock 209 295 607 minecraft:sea_lantern
setblock 210 295 606 minecraft:sea_lantern
setblock 210 295 608 minecraft:sea_lantern
setblock 211 295 605 minecraft:sea_lantern
setblock 211 295 607 minecraft:sea_lantern
setblock 212 295 606 minecraft:sea_lantern
setblock 212 295 608 minecraft:sea_lantern
setblock 213 295 605 minecraft:sea_lantern
setblock 213 295 607 minecraft:sea_lantern
fill 214 295 637 215 296 637 minecraft:yellow_concrete
setblock 229 295 644 minecraft:black_concrete
fill 201 296 605 201 297 605 minecraft:black_concrete
fill 201 296 607 201 297 607 minecraft:black_concrete
fill 202 296 606 202 297 606 minecraft:black_concrete
fill 202 296 608 202 297 608 minecraft:black_concrete
fill 203 296 605 203 297 605 minecraft:black_concrete
fill 203 296 607 203 297 607 minecraft:black_concrete
fill 204 296 606 204 297 606 minecraft:black_concrete
fill 204 296 608 204 297 608 minecraft:black_concrete
fill 205 296 605 205 297 605 minecraft:black_concrete
fill 205 296 607 205 297 607 minecraft:black_concrete
fill 206 296 606 206 297 606 minecraft:black_concrete
fill 206 296 608 206 297 608 minecraft:black_concrete
fill 207 296 605 207 297 605 minecraft:black_concrete
fill 207 296 607 207 297 607 minecraft:black_concrete
fill 208 296 606 208 297 606 minecraft:black_concrete
fill 208 296 608 208 297 608 minecraft:black_concrete
fill 209 296 605 209 297 605 minecraft:black_concrete
fill 209 296 607 209 297 607 minecraft:black_concrete
fill 210 296 606 210 297 606 minecraft:black_concrete
fill 210 296 608 210 297 608 minecraft:black_concrete
fill 211 296 605 211 297 605 minecraft:black_concrete
fill 211 296 607 211 297 607 minecraft:black_concrete
fill 212 296 606 212 297 606 minecraft:black_concrete
fill 212 296 608 212 297 608 minecraft:black_concrete
fill 213 296 605 213 297 605 minecraft:black_concrete
fill 213 296 607 213 297 607 minecraft:black_concrete
fill 188 298 609 188 300 609 minecraft:sea_lantern
fill 188 298 617 188 300 617 minecraft:sea_lantern
fill 188 298 625 188 300 625 minecraft:sea_lantern
fill 188 298 633 188 300 633 minecraft:sea_lantern
fill 188 298 641 188 300 641 minecraft:sea_lantern
fill 191 298 646 191 300 646 minecraft:sea_lantern
fill 195 298 604 195 300 604 minecraft:sea_lantern
fill 198 298 625 200 299 626 minecraft:magenta_concrete
fill 199 298 646 199 300 646 minecraft:sea_lantern
setblock 201 298 605 minecraft:sea_lantern
setblock 201 298 607 minecraft:sea_lantern
setblock 202 298 606 minecraft:sea_lantern
setblock 202 298 608 minecraft:sea_lantern
fill 203 298 604 203 298 605 minecraft:sea_lantern
setblock 203 298 607 minecraft:sea_lantern
setblock 204 298 606 minecraft:sea_lantern
setblock 204 298 608 minecraft:sea_lantern
setblock 205 298 605 minecraft:sea_lantern
setblock 205 298 607 minecraft:sea_lantern
setblock 206 298 606 minecraft:sea_lantern
setblock 206 298 608 minecraft:sea_lantern
setblock 207 298 605 minecraft:sea_lantern
setblock 207 298 607 minecraft:sea_lantern
fill 207 298 646 207 300 646 minecraft:sea_lantern
setblock 208 298 606 minecraft:sea_lantern
setblock 208 298 608 minecraft:sea_lantern
setblock 209 298 605 minecraft:sea_lantern
setblock 209 298 607 minecraft:sea_lantern
setblock 210 298 606 minecraft:sea_lantern
setblock 210 298 608 minecraft:sea_lantern
fill 211 298 604 211 298 605 minecraft:sea_lantern
setblock 211 298 607 minecraft:sea_lantern
setblock 212 298 606 minecraft:sea_lantern
setblock 212 298 608 minecraft:sea_lantern
setblock 213 298 605 minecraft:sea_lantern
setblock 213 298 607 minecraft:sea_lantern
fill 215 298 646 215 300 646 minecraft:sea_lantern
fill 219 298 604 219 300 604 minecraft:sea_lantern
fill 223 298 646 223 300 646 minecraft:sea_lantern
fill 227 298 604 227 300 604 minecraft:sea_lantern
fill 230 298 609 230 300 609 minecraft:sea_lantern
fill 230 298 617 230 300 617 minecraft:sea_lantern
fill 230 298 625 230 300 625 minecraft:sea_lantern
fill 230 298 633 230 300 633 minecraft:sea_lantern
fill 230 298 641 230 300 641 minecraft:sea_lantern
fill 201 299 605 201 300 605 minecraft:black_concrete
fill 201 299 607 201 300 607 minecraft:black_concrete
fill 202 299 606 202 300 606 minecraft:black_concrete
fill 202 299 608 202 300 608 minecraft:black_concrete
fill 203 299 604 203 300 604 minecraft:sea_lantern
fill 203 299 605 203 300 605 minecraft:black_concrete
fill 203 299 607 203 300 607 minecraft:black_concrete
fill 204 299 606 204 300 606 minecraft:black_concrete
fill 204 299 608 204 300 608 minecraft:black_concrete
fill 205 299 605 205 300 605 minecraft:black_concrete
fill 205 299 607 205 300 607 minecraft:black_concrete
fill 206 299 606 206 300 606 minecraft:black_concrete
fill 206 299 608 206 300 608 minecraft:black_concrete
fill 207 299 605 207 300 605 minecraft:black_concrete
fill 207 299 607 207 300 607 minecraft:black_concrete
fill 208 299 606 208 300 606 minecraft:black_concrete
fill 208 299 608 208 300 608 minecraft:black_concrete
fill 209 299 605 209 300 605 minecraft:black_concrete
fill 209 299 607 209 300 607 minecraft:black_concrete
fill 210 299 606 210 300 606 minecraft:black_concrete
fill 210 299 608 210 300 608 minecraft:black_concrete
fill 211 299 604 211 300 604 minecraft:sea_lantern
fill 211 299 605 211 300 605 minecraft:black_concrete
fill 211 299 607 211 300 607 minecraft:black_concrete
fill 212 299 606 212 300 606 minecraft:black_concrete
fill 212 299 608 212 300 608 minecraft:black_concrete
fill 213 299 605 213 300 605 minecraft:black_concrete
fill 213 299 607 213 300 607 minecraft:black_concrete
fill 188 301 609 188 307 609 minecraft:lime_concrete
fill 188 301 617 188 307 617 minecraft:lime_concrete
fill 188 301 625 188 307 625 minecraft:lime_concrete
fill 188 301 633 188 307 633 minecraft:lime_concrete
fill 188 301 641 188 307 641 minecraft:lime_concrete
fill 191 301 646 191 307 646 minecraft:lime_concrete
fill 195 301 604 195 307 604 minecraft:lime_concrete
fill 199 301 646 199 307 646 minecraft:lime_concrete
fill 203 301 604 203 307 604 minecraft:lime_concrete
fill 207 301 646 207 307 646 minecraft:lime_concrete
fill 211 301 604 211 307 604 minecraft:lime_concrete
fill 215 301 646 215 307 646 minecraft:lime_concrete
fill 219 301 604 219 307 604 minecraft:lime_concrete
fill 223 301 646 223 307 646 minecraft:lime_concrete
fill 227 301 604 227 307 604 minecraft:lime_concrete
fill 230 301 609 230 307 609 minecraft:lime_concrete
fill 230 301 617 230 307 617 minecraft:lime_concrete
fill 230 301 625 230 307 625 minecraft:lime_concrete
fill 230 301 633 230 307 633 minecraft:lime_concrete
fill 230 301 641 230 307 641 minecraft:lime_concrete
setblock 191 302 607 minecraft:light[level=14]
setblock 191 302 615 minecraft:light[level=14]
setblock 191 302 623 minecraft:light[level=14]
setblock 191 302 631 minecraft:light[level=14]
setblock 191 302 639 minecraft:light[level=14]
setblock 199 302 607 minecraft:light[level=14]
setblock 199 302 615 minecraft:light[level=14]
setblock 199 302 623 minecraft:light[level=14]
setblock 199 302 631 minecraft:light[level=14]
setblock 199 302 639 minecraft:light[level=14]
setblock 207 302 607 minecraft:light[level=14]
setblock 207 302 615 minecraft:light[level=14]
setblock 207 302 623 minecraft:light[level=14]
setblock 207 302 631 minecraft:light[level=14]
setblock 207 302 639 minecraft:light[level=14]
setblock 215 302 607 minecraft:light[level=14]
setblock 215 302 615 minecraft:light[level=14]
setblock 215 302 623 minecraft:light[level=14]
setblock 215 302 631 minecraft:light[level=14]
setblock 215 302 639 minecraft:light[level=14]
setblock 223 302 607 minecraft:light[level=14]
setblock 223 302 615 minecraft:light[level=14]
setblock 223 302 623 minecraft:light[level=14]
setblock 223 302 631 minecraft:light[level=14]
setblock 223 302 639 minecraft:light[level=14]
