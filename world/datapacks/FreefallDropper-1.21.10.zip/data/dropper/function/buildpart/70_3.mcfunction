setblock 491 59 278 minecraft:deepslate_tiles
fill 491 59 315 491 61 315 minecraft:deepslate_tiles
setblock 493 59 277 minecraft:cobbled_deepslate
setblock 494 59 276 minecraft:cobbled_deepslate
fill 494 59 277 497 59 277 minecraft:deepslate_tiles
setblock 494 59 315 minecraft:deepslate_tiles
setblock 494 59 316 minecraft:cobbled_deepslate
fill 495 59 276 495 62 276 minecraft:deepslate_tiles
setblock 495 59 315 minecraft:cobbled_deepslate
fill 495 59 316 495 62 316 minecraft:deepslate_tiles
fill 496 59 315 496 62 315 minecraft:deepslate_tiles
setblock 498 59 277 minecraft:cobbled_deepslate
setblock 499 59 276 minecraft:cobbled_deepslate
fill 499 59 277 499 62 277 minecraft:deepslate_tiles
setblock 499 59 316 minecraft:cobbled_deepslate
fill 500 59 276 500 62 276 minecraft:deepslate_tiles
fill 500 59 278 501 59 278 minecraft:deepslate_tiles
setblock 500 59 315 minecraft:cobbled_deepslate
fill 500 59 316 500 62 316 minecraft:deepslate_tiles
setblock 501 59 314 minecraft:cobbled_deepslate
fill 501 59 315 501 62 315 minecraft:deepslate_tiles
setblock 502 59 277 minecraft:deepslate_tiles
setblock 502 59 278 minecraft:cobbled_deepslate
setblock 502 59 313 minecraft:cobbled_deepslate
fill 502 59 314 502 62 314 minecraft:deepslate_tiles
setblock 503 59 277 minecraft:cobbled_deepslate
fill 503 59 278 503 62 278 minecraft:deepslate_tiles
fill 503 59 313 503 61 313 minecraft:deepslate_tiles
setblock 504 59 276 minecraft:cobbled_deepslate
fill 504 59 277 504 62 277 minecraft:deepslate_tiles
setblock 504 59 316 minecraft:cobbled_deepslate
fill 505 59 276 505 62 276 minecraft:deepslate_tiles
fill 505 59 288 505 60 288 minecraft:white_wool
setblock 505 59 315 minecraft:cobbled_deepslate
fill 505 59 316 505 62 316 minecraft:deepslate_tiles
setblock 506 59 278 minecraft:deepslate_tiles
setblock 506 59 314 minecraft:cobbled_deepslate
fill 506 59 315 506 62 315 minecraft:deepslate_tiles
setblock 507 59 313 minecraft:cobbled_deepslate
fill 507 59 314 507 62 314 minecraft:deepslate_tiles
setblock 508 59 277 minecraft:cobbled_deepslate
setblock 508 59 313 minecraft:deepslate_tiles
setblock 509 59 276 minecraft:cobbled_deepslate
fill 509 59 277 510 60 277 minecraft:deepslate_tiles
setblock 509 59 295 minecraft:deepslate_tiles
setblock 509 59 296 minecraft:cobbled_deepslate
fill 509 59 297 510 59 299 minecraft:deepslate_tiles
setblock 509 59 311 minecraft:cobbled_deepslate
fill 509 59 312 509 60 312 minecraft:deepslate_tiles
setblock 509 59 316 minecraft:cobbled_deepslate
fill 510 59 276 510 62 276 minecraft:deepslate_tiles
setblock 510 59 295 minecraft:cobbled_deepslate
fill 510 59 296 510 62 296 minecraft:deepslate_tiles
setblock 510 59 300 minecraft:cobbled_deepslate
fill 510 59 301 510 62 301 minecraft:deepslate_tiles
fill 510 59 303 510 59 304 minecraft:deepslate_tiles
setblock 510 59 310 minecraft:cobbled_deepslate
fill 510 59 311 510 61 311 minecraft:deepslate_tiles
setblock 510 59 315 minecraft:cobbled_deepslate
fill 510 59 316 510 62 316 minecraft:deepslate_tiles
setblock 511 59 294 minecraft:cobbled_deepslate
fill 511 59 295 511 62 295 minecraft:deepslate_tiles
setblock 511 59 298 minecraft:deepslate_tiles
setblock 511 59 299 minecraft:cobbled_deepslate
fill 511 59 300 511 62 300 minecraft:deepslate_tiles
setblock 511 59 304 minecraft:cobbled_deepslate
fill 511 59 305 511 62 305 minecraft:deepslate_tiles
setblock 511 59 309 minecraft:cobbled_deepslate
fill 511 59 310 511 62 310 minecraft:deepslate_tiles
setblock 511 59 314 minecraft:cobbled_deepslate
fill 511 59 315 511 62 315 minecraft:deepslate_tiles
setblock 471 60 278 minecraft:cobbled_deepslate
fill 471 60 289 471 61 289 minecraft:deepslate_tiles
setblock 471 60 293 minecraft:cobbled_deepslate
fill 471 60 294 471 62 294 minecraft:deepslate_tiles
setblock 471 60 298 minecraft:cobbled_deepslate
fill 471 60 299 471 62 299 minecraft:deepslate_tiles
setblock 471 60 303 minecraft:cobbled_deepslate
fill 471 60 304 471 62 304 minecraft:deepslate_tiles
setblock 471 60 313 minecraft:cobbled_deepslate
fill 471 60 314 471 61 314 minecraft:deepslate_tiles
setblock 472 60 292 minecraft:cobbled_deepslate
fill 472 60 293 472 62 293 minecraft:deepslate_tiles
setblock 472 60 297 minecraft:cobbled_deepslate
fill 472 60 298 473 62 298 minecraft:deepslate_tiles
setblock 473 60 276 minecraft:cobbled_deepslate
setblock 473 60 296 minecraft:cobbled_deepslate
fill 473 60 297 473 62 297 minecraft:deepslate_tiles
setblock 473 60 316 minecraft:cobbled_deepslate
fill 474 60 276 477 60 276 minecraft:deepslate_tiles
fill 474 60 316 477 60 316 minecraft:deepslate_tiles
setblock 478 60 276 minecraft:cobbled_deepslate
fill 478 60 277 478 62 277 minecraft:deepslate_tiles
setblock 478 60 316 minecraft:cobbled_deepslate
fill 479 60 275 479 94 275 minecraft:cobbled_deepslate
fill 479 60 276 479 62 276 minecraft:deepslate_tiles
fill 479 60 316 479 62 316 minecraft:deepslate_tiles
setblock 480 60 278 minecraft:deepslate_tiles
fill 480 60 315 480 62 315 minecraft:deepslate_tiles
setblock 481 60 278 minecraft:cobbled_deepslate
setblock 482 60 276 minecraft:deepslate_tiles
setblock 482 60 277 minecraft:cobbled_deepslate
fill 482 60 278 485 60 278 minecraft:deepslate_tiles
setblock 483 60 276 minecraft:cobbled_deepslate
fill 483 60 277 483 62 277 minecraft:deepslate_tiles
fill 483 60 279 484 60 279 minecraft:deepslate_tiles
setblock 483 60 316 minecraft:cobbled_deepslate
fill 484 60 276 484 62 276 minecraft:deepslate_tiles
setblock 484 60 315 minecraft:cobbled_deepslate
fill 484 60 316 484 62 316 minecraft:deepslate_tiles
setblock 485 60 279 minecraft:cobbled_deepslate
fill 485 60 315 485 62 315 minecraft:deepslate_tiles
setblock 486 60 278 minecraft:cobbled_deepslate
fill 486 60 279 487 62 279 minecraft:deepslate_tiles
setblock 487 60 277 minecraft:cobbled_deepslate
fill 487 60 278 487 62 278 minecraft:deepslate_tiles
setblock 488 60 276 minecraft:cobbled_deepslate
fill 488 60 277 488 62 277 minecraft:deepslate_tiles
setblock 488 60 316 minecraft:cobbled_deepslate
fill 489 60 276 489 62 276 minecraft:deepslate_tiles
setblock 489 60 315 minecraft:cobbled_deepslate
fill 489 60 316 492 60 316 minecraft:deepslate_tiles
fill 490 60 315 490 61 315 minecraft:deepslate_tiles
setblock 491 60 278 minecraft:cobbled_deepslate
setblock 492 60 277 minecraft:cobbled_deepslate
setblock 493 60 276 minecraft:cobbled_deepslate
fill 493 60 277 496 60 277 minecraft:deepslate_tiles
setblock 493 60 316 minecraft:cobbled_deepslate
fill 494 60 276 494 62 276 minecraft:deepslate_tiles
setblock 494 60 315 minecraft:cobbled_deepslate
fill 494 60 316 494 62 316 minecraft:deepslate_tiles
fill 495 60 315 495 62 315 minecraft:deepslate_tiles
setblock 497 60 277 minecraft:cobbled_deepslate
setblock 498 60 276 minecraft:cobbled_deepslate
fill 498 60 277 498 62 278 minecraft:deepslate_tiles
fill 498 60 314 498 61 314 minecraft:deepslate_tiles
setblock 498 60 316 minecraft:cobbled_deepslate
fill 499 60 276 499 62 276 minecraft:deepslate_tiles
fill 499 60 278 500 60 278 minecraft:deepslate_tiles
setblock 499 60 315 minecraft:cobbled_deepslate
fill 499 60 316 499 62 316 minecraft:deepslate_tiles
setblock 500 60 314 minecraft:cobbled_deepslate
fill 500 60 315 500 62 315 minecraft:deepslate_tiles
setblock 501 60 278 minecraft:cobbled_deepslate
fill 501 60 314 501 62 314 minecraft:deepslate_tiles
setblock 502 60 277 minecraft:cobbled_deepslate
fill 502 60 278 502 62 278 minecraft:deepslate_tiles
fill 502 60 313 502 61 313 minecraft:deepslate_tiles
setblock 503 60 276 minecraft:cobbled_deepslate
fill 503 60 277 503 62 277 minecraft:deepslate_tiles
setblock 503 60 316 minecraft:cobbled_deepslate
fill 504 60 276 504 62 276 minecraft:deepslate_tiles
setblock 504 60 315 minecraft:cobbled_deepslate
fill 504 60 316 504 62 316 minecraft:deepslate_tiles
setblock 505 60 314 minecraft:cobbled_deepslate
fill 505 60 315 505 62 315 minecraft:deepslate_tiles
setblock 506 60 278 minecraft:cobbled_deepslate
setblock 506 60 313 minecraft:cobbled_deepslate
fill 506 60 314 506 62 314 minecraft:deepslate_tiles
setblock 507 60 277 minecraft:cobbled_deepslate
setblock 507 60 313 minecraft:deepslate_tiles
setblock 508 60 276 minecraft:cobbled_deepslate
fill 508 60 277 508 62 277 minecraft:deepslate_tiles
setblock 508 60 316 minecraft:cobbled_deepslate
fill 509 60 276 509 62 276 minecraft:deepslate_tiles
setblock 509 60 295 minecraft:cobbled_deepslate
fill 509 60 296 509 60 299 minecraft:deepslate_tiles
setblock 509 60 300 minecraft:cobbled_deepslate
fill 509 60 301 509 62 301 minecraft:deepslate_tiles
setblock 509 60 315 minecraft:cobbled_deepslate
fill 509 60 316 509 62 316 minecraft:deepslate_tiles
setblock 510 60 294 minecraft:cobbled_deepslate
fill 510 60 295 510 62 295 minecraft:deepslate_tiles
fill 510 60 297 510 60 298 minecraft:deepslate_tiles
setblock 510 60 299 minecraft:cobbled_deepslate
fill 510 60 300 510 62 300 minecraft:deepslate_tiles
setblock 510 60 303 minecraft:deepslate_tiles
setblock 510 60 304 minecraft:cobbled_deepslate
fill 510 60 305 510 61 305 minecraft:deepslate_tiles
setblock 510 60 309 minecraft:cobbled_deepslate
setblock 510 60 310 minecraft:deepslate_tiles
setblock 510 60 314 minecraft:cobbled_deepslate
fill 510 60 315 510 62 315 minecraft:deepslate_tiles
setblock 511 60 278 minecraft:cobbled_deepslate
setblock 511 60 293 minecraft:cobbled_deepslate
fill 511 60 294 511 62 294 minecraft:deepslate_tiles
setblock 511 60 298 minecraft:cobbled_deepslate
fill 511 60 299 511 62 299 minecraft:deepslate_tiles
setblock 511 60 303 minecraft:cobbled_deepslate
fill 511 60 304 511 62 304 minecraft:deepslate_tiles
setblock 511 60 308 minecraft:cobbled_deepslate
fill 511 60 309 511 62 309 minecraft:deepslate_tiles
setblock 511 60 313 minecraft:cobbled_deepslate
fill 511 60 314 511 62 314 minecraft:deepslate_tiles
setblock 471 61 277 minecraft:cobbled_deepslate
fill 471 61 278 471 62 278 minecraft:deepslate_tiles
setblock 471 61 292 minecraft:cobbled_deepslate
fill 471 61 293 471 62 293 minecraft:deepslate_tiles
setblock 471 61 297 minecraft:cobbled_deepslate
fill 471 61 298 471 62 298 minecraft:deepslate_tiles
setblock 471 61 302 minecraft:cobbled_deepslate
fill 471 61 303 471 62 303 minecraft:deepslate_tiles
setblock 472 61 276 minecraft:cobbled_deepslate
setblock 472 61 292 minecraft:deepslate_tiles
setblock 472 61 295 minecraft:deepslate_tiles
setblock 472 61 296 minecraft:cobbled_deepslate
fill 472 61 297 472 62 297 minecraft:deepslate_tiles
setblock 472 61 301 minecraft:cobbled_deepslate
fill 472 61 302 472 62 302 minecraft:deepslate_tiles
setblock 472 61 316 minecraft:cobbled_deepslate
fill 473 61 276 476 61 276 minecraft:deepslate_tiles
setblock 473 61 278 minecraft:light[level=13]
setblock 473 61 285 minecraft:light[level=12]
setblock 473 61 286 minecraft:light[level=13]
setblock 473 61 292 minecraft:light[level=12]
setblock 473 61 294 minecraft:light[level=13]
setblock 473 61 295 minecraft:cobbled_deepslate
fill 473 61 296 473 62 296 minecraft:deepslate_tiles
setblock 473 61 299 minecraft:light[level=12]
setblock 473 61 302 minecraft:light[level=13]
setblock 473 61 306 minecraft:light[level=12]
setblock 473 61 310 minecraft:light[level=13]
setblock 473 61 313 minecraft:light[level=12]
setblock 476 61 316 minecraft:deepslate_tiles
setblock 477 61 276 minecraft:cobbled_deepslate
fill 477 61 277 477 62 277 minecraft:deepslate_tiles
setblock 477 61 316 minecraft:cobbled_deepslate
fill 478 61 276 478 62 276 minecraft:deepslate_tiles
fill 478 61 316 478 62 316 minecraft:deepslate_tiles
setblock 479 61 278 minecraft:deepslate_tiles
setblock 480 61 277 minecraft:deepslate_tiles
setblock 480 61 278 minecraft:cobbled_deepslate
setblock 480 61 285 minecraft:light[level=12]
setblock 480 61 292 minecraft:light[level=12]
setblock 480 61 299 minecraft:light[level=12]
setblock 480 61 306 minecraft:light[level=12]
setblock 480 61 313 minecraft:light[level=12]
setblock 481 61 277 minecraft:cobbled_deepslate
fill 481 61 278 484 61 278 minecraft:deepslate_tiles
setblock 481 61 286 minecraft:light[level=13]
setblock 481 61 294 minecraft:light[level=13]
setblock 481 61 302 minecraft:light[level=13]
setblock 481 61 310 minecraft:light[level=13]
setblock 482 61 276 minecraft:cobbled_deepslate
fill 482 61 277 482 62 277 minecraft:deepslate_tiles
fill 482 61 279 483 61 279 minecraft:deepslate_tiles
setblock 482 61 316 minecraft:cobbled_deepslate
fill 483 61 276 483 62 276 minecraft:deepslate_tiles
setblock 483 61 315 minecraft:cobbled_deepslate
fill 483 61 316 483 62 316 minecraft:deepslate_tiles
setblock 484 61 279 minecraft:cobbled_deepslate
fill 484 61 315 484 62 315 minecraft:deepslate_tiles
setblock 485 61 278 minecraft:cobbled_deepslate
fill 485 61 279 485 62 279 minecraft:deepslate_tiles
setblock 486 61 277 minecraft:cobbled_deepslate
fill 486 61 278 486 62 278 minecraft:deepslate_tiles
setblock 487 61 276 minecraft:cobbled_deepslate
fill 487 61 277 487 62 277 minecraft:deepslate_tiles
setblock 487 61 285 minecraft:light[level=12]
setblock 487 61 292 minecraft:light[level=12]
setblock 487 61 299 minecraft:light[level=12]
setblock 487 61 306 minecraft:light[level=12]
setblock 487 61 313 minecraft:light[level=12]
setblock 487 61 316 minecraft:cobbled_deepslate
fill 488 61 276 488 62 276 minecraft:deepslate_tiles
setblock 488 61 315 minecraft:cobbled_deepslate
fill 488 61 316 491 61 316 minecraft:deepslate_tiles
setblock 489 61 278 minecraft:deepslate_tiles
setblock 489 61 286 minecraft:light[level=13]
setblock 489 61 294 minecraft:light[level=13]
setblock 489 61 302 minecraft:light[level=13]
setblock 489 61 310 minecraft:light[level=13]
fill 489 61 315 489 62 315 minecraft:deepslate_tiles
setblock 490 61 278 minecraft:cobbled_deepslate
setblock 491 61 277 minecraft:cobbled_deepslate
fill 491 61 278 492 61 278 minecraft:deepslate_tiles
setblock 492 61 276 minecraft:cobbled_deepslate
fill 492 61 277 495 61 277 minecraft:deepslate_tiles
setblock 492 61 316 minecraft:cobbled_deepslate
fill 493 61 276 493 62 276 minecraft:deepslate_tiles
setblock 493 61 315 minecraft:cobbled_deepslate
fill 493 61 316 493 62 316 minecraft:deepslate_tiles
setblock 494 61 278 minecraft:light[level=12]
setblock 494 61 285 minecraft:light[level=12]
setblock 494 61 292 minecraft:light[level=12]
setblock 494 61 299 minecraft:light[level=12]
setblock 494 61 306 minecraft:light[level=12]
setblock 494 61 313 minecraft:light[level=12]
setblock 494 61 315 minecraft:deepslate_tiles
setblock 496 61 277 minecraft:cobbled_deepslate
setblock 497 61 276 minecraft:cobbled_deepslate
fill 497 61 277 497 62 278 minecraft:deepslate_tiles
setblock 497 61 286 minecraft:light[level=13]
setblock 497 61 294 minecraft:light[level=13]
setblock 497 61 302 minecraft:light[level=13]
setblock 497 61 310 minecraft:light[level=13]
setblock 497 61 316 minecraft:cobbled_deepslate
fill 498 61 276 498 62 276 minecraft:deepslate_tiles
setblock 498 61 315 minecraft:cobbled_deepslate
fill 498 61 316 498 62 316 minecraft:deepslate_tiles
setblock 499 61 278 minecraft:deepslate_tiles
setblock 499 61 314 minecraft:cobbled_deepslate
fill 499 61 315 499 62 315 minecraft:deepslate_tiles
setblock 500 61 278 minecraft:cobbled_deepslate
fill 500 61 314 500 62 314 minecraft:deepslate_tiles
setblock 501 61 277 minecraft:cobbled_deepslate
fill 501 61 278 501 62 278 minecraft:deepslate_tiles
setblock 501 61 285 minecraft:light[level=12]
setblock 501 61 292 minecraft:light[level=12]
setblock 501 61 299 minecraft:light[level=12]
setblock 501 61 306 minecraft:light[level=12]
setblock 501 61 313 minecraft:light[level=12]
setblock 502 61 276 minecraft:cobbled_deepslate
fill 502 61 277 502 62 277 minecraft:deepslate_tiles
setblock 502 61 316 minecraft:cobbled_deepslate
fill 503 61 276 503 62 276 minecraft:deepslate_tiles
setblock 503 61 315 minecraft:cobbled_deepslate
fill 503 61 316 503 62 316 minecraft:deepslate_tiles
setblock 504 61 278 minecraft:deepslate_tiles
setblock 504 61 314 minecraft:cobbled_deepslate
fill 504 61 315 504 62 315 minecraft:deepslate_tiles
setblock 505 61 278 minecraft:cobbled_deepslate
setblock 505 61 286 minecraft:light[level=13]
setblock 505 61 294 minecraft:light[level=13]
setblock 505 61 302 minecraft:light[level=13]
setblock 505 61 310 minecraft:light[level=13]
setblock 505 61 313 minecraft:cobbled_deepslate
fill 505 61 314 505 62 314 minecraft:deepslate_tiles
setblock 506 61 277 minecraft:cobbled_deepslate
fill 506 61 278 506 62 278 minecraft:deepslate_tiles
setblock 506 61 313 minecraft:deepslate_tiles
setblock 507 61 276 minecraft:cobbled_deepslate
fill 507 61 277 507 62 277 minecraft:deepslate_tiles
setblock 507 61 316 minecraft:cobbled_deepslate
fill 508 61 276 508 62 276 minecraft:deepslate_tiles
setblock 508 61 278 minecraft:light[level=12]
setblock 508 61 285 minecraft:light[level=12]
setblock 508 61 292 minecraft:light[level=12]
setblock 508 61 299 minecraft:light[level=12]
setblock 508 61 306 minecraft:light[level=12]
setblock 508 61 313 minecraft:light[level=12]
setblock 508 61 315 minecraft:cobbled_deepslate
fill 508 61 316 508 62 316 minecraft:deepslate_tiles
fill 509 61 277 509 62 277 minecraft:deepslate_tiles
fill 509 61 296 509 61 298 minecraft:deepslate_tiles
setblock 509 61 299 minecraft:cobbled_deepslate
fill 509 61 300 509 62 300 minecraft:deepslate_tiles
setblock 509 61 314 minecraft:cobbled_deepslate
fill 509 61 315 509 62 315 minecraft:deepslate_tiles
fill 510 61 294 510 62 294 minecraft:deepslate_tiles
setblock 510 61 297 minecraft:deepslate_tiles
setblock 510 61 298 minecraft:cobbled_deepslate
fill 510 61 299 510 62 299 minecraft:deepslate_tiles
setblock 510 61 303 minecraft:cobbled_deepslate
fill 510 61 304 510 62 304 minecraft:deepslate_tiles
setblock 510 61 313 minecraft:cobbled_deepslate
fill 510 61 314 510 62 314 minecraft:deepslate_tiles
setblock 511 61 277 minecraft:cobbled_deepslate
fill 511 61 278 511 62 278 minecraft:deepslate_tiles
setblock 511 61 292 minecraft:cobbled_deepslate
fill 511 61 293 511 62 293 minecraft:deepslate_tiles
setblock 511 61 297 minecraft:cobbled_deepslate
fill 511 61 298 511 62 298 minecraft:deepslate_tiles
setblock 511 61 302 minecraft:cobbled_deepslate
fill 511 61 303 511 62 303 minecraft:deepslate_tiles
setblock 511 61 307 minecraft:cobbled_deepslate
fill 511 61 308 511 62 308 minecraft:deepslate_tiles
setblock 511 61 312 minecraft:cobbled_deepslate
fill 511 61 313 511 62 313 minecraft:deepslate_tiles
setblock 471 62 276 minecraft:cobbled_deepslate
setblock 471 62 277 minecraft:deepslate_tiles
setblock 471 62 279 minecraft:deepslate_tiles
setblock 471 62 291 minecraft:cobbled_deepslate
setblock 471 62 292 minecraft:deepslate_tiles
setblock 471 62 296 minecraft:cobbled_deepslate
setblock 471 62 297 minecraft:deepslate_tiles
setblock 471 62 301 minecraft:cobbled_deepslate
setblock 471 62 302 minecraft:deepslate_tiles
fill 472 62 276 475 62 276 minecraft:deepslate_tiles
setblock 472 62 295 minecraft:cobbled_deepslate
setblock 472 62 296 minecraft:deepslate_tiles
setblock 472 62 300 minecraft:cobbled_deepslate
setblock 472 62 301 minecraft:deepslate_tiles
setblock 476 62 276 minecraft:cobbled_deepslate
setblock 476 62 277 minecraft:deepslate_tiles
setblock 477 62 276 minecraft:deepslate_tiles
setblock 477 62 316 minecraft:deepslate_tiles
setblock 479 62 278 minecraft:cobbled_deepslate
setblock 480 62 277 minecraft:cobbled_deepslate
fill 480 62 278 483 62 278 minecraft:deepslate_tiles
setblock 481 62 276 minecraft:cobbled_deepslate
setblock 481 62 277 minecraft:deepslate_tiles
fill 481 62 279 482 62 279 minecraft:deepslate_tiles
setblock 481 62 316 minecraft:cobbled_deepslate
setblock 482 62 276 minecraft:deepslate_tiles
setblock 482 62 315 minecraft:cobbled_deepslate
setblock 482 62 316 minecraft:deepslate_tiles
setblock 483 62 279 minecraft:cobbled_deepslate
setblock 483 62 315 minecraft:deepslate_tiles
setblock 484 62 278 minecraft:cobbled_deepslate
setblock 484 62 279 minecraft:deepslate_tiles
setblock 485 62 277 minecraft:cobbled_deepslate
setblock 485 62 278 minecraft:deepslate_tiles
setblock 486 62 276 minecraft:cobbled_deepslate
setblock 486 62 277 minecraft:deepslate_tiles
setblock 486 62 316 minecraft:cobbled_deepslate
setblock 487 62 276 minecraft:deepslate_tiles
setblock 487 62 315 minecraft:cobbled_deepslate
fill 487 62 316 490 62 316 minecraft:deepslate_tiles
setblock 488 62 315 minecraft:deepslate_tiles
setblock 489 62 278 minecraft:cobbled_deepslate
setblock 490 62 277 minecraft:cobbled_deepslate
fill 490 62 278 491 62 278 minecraft:deepslate_tiles
setblock 491 62 276 minecraft:cobbled_deepslate
fill 491 62 277 494 62 277 minecraft:deepslate_tiles
setblock 491 62 316 minecraft:cobbled_deepslate
setblock 492 62 276 minecraft:deepslate_tiles
setblock 492 62 316 minecraft:deepslate_tiles
setblock 495 62 277 minecraft:cobbled_deepslate
setblock 496 62 276 minecraft:cobbled_deepslate
fill 496 62 277 496 62 278 minecraft:deepslate_tiles
setblock 496 62 316 minecraft:cobbled_deepslate
setblock 497 62 276 minecraft:deepslate_tiles
setblock 497 62 315 minecraft:cobbled_deepslate
setblock 497 62 316 minecraft:deepslate_tiles
setblock 498 62 315 minecraft:deepslate_tiles
setblock 499 62 278 minecraft:cobbled_deepslate
setblock 499 62 314 minecraft:deepslate_tiles
setblock 500 62 277 minecraft:cobbled_deepslate
setblock 500 62 278 minecraft:deepslate_tiles
setblock 501 62 276 minecraft:cobbled_deepslate
setblock 501 62 277 minecraft:deepslate_tiles
setblock 501 62 316 minecraft:cobbled_deepslate
setblock 502 62 276 minecraft:deepslate_tiles
setblock 502 62 315 minecraft:cobbled_deepslate
setblock 502 62 316 minecraft:deepslate_tiles
setblock 503 62 314 minecraft:cobbled_deepslate
setblock 503 62 315 minecraft:deepslate_tiles
setblock 504 62 278 minecraft:cobbled_deepslate
setblock 504 62 314 minecraft:deepslate_tiles
setblock 505 62 277 minecraft:cobbled_deepslate
setblock 505 62 278 minecraft:deepslate_tiles
setblock 506 62 276 minecraft:cobbled_deepslate
setblock 506 62 277 minecraft:deepslate_tiles
setblock 506 62 316 minecraft:cobbled_deepslate
setblock 507 62 276 minecraft:deepslate_tiles
setblock 507 62 315 minecraft:cobbled_deepslate
setblock 507 62 316 minecraft:deepslate_tiles
setblock 508 62 314 minecraft:cobbled_deepslate
setblock 508 62 315 minecraft:deepslate_tiles
setblock 509 62 297 minecraft:deepslate_tiles
setblock 509 62 298 minecraft:cobbled_deepslate
setblock 509 62 299 minecraft:deepslate_tiles
setblock 510 62 297 minecraft:cobbled_deepslate
setblock 510 62 298 minecraft:deepslate_tiles
setblock 510 62 302 minecraft:cobbled_deepslate
setblock 510 62 303 minecraft:deepslate_tiles
setblock 511 62 276 minecraft:cobbled_deepslate
setblock 511 62 277 minecraft:deepslate_tiles
setblock 511 62 296 minecraft:cobbled_deepslate
setblock 511 62 297 minecraft:deepslate_tiles
setblock 511 62 301 minecraft:cobbled_deepslate
setblock 511 62 302 minecraft:deepslate_tiles
setblock 511 62 306 minecraft:cobbled_deepslate
setblock 511 62 307 minecraft:deepslate_tiles
setblock 511 62 311 minecraft:cobbled_deepslate
setblock 511 62 312 minecraft:deepslate_tiles
setblock 511 62 316 minecraft:cobbled_deepslate
setblock 511 64 317 minecraft:white_wool
fill 512 64 317 512 94 317 minecraft:cobbled_deepslate
fill 470 65 305 470 94 305 minecraft:cobbled_deepslate
setblock 470 65 306 minecraft:white_wool
fill 511 65 317 511 94 317 minecraft:cobbled_deepslate
fill 470 66 306 470 88 306 minecraft:cobbled_deepslate
setblock 473 67 278 minecraft:light[level=12]
setblock 473 67 285 minecraft:light[level=12]
setblock 473 67 292 minecraft:light[level=12]
setblock 473 67 299 minecraft:light[level=12]
setblock 473 67 306 minecraft:light[level=12]
setblock 473 67 313 minecraft:light[level=12]
setblock 480 67 278 minecraft:light[level=12]
setblock 480 67 285 minecraft:light[level=12]
setblock 480 67 292 minecraft:light[level=12]
setblock 480 67 299 minecraft:light[level=12]
setblock 480 67 306 minecraft:light[level=12]
setblock 480 67 313 minecraft:light[level=12]
setblock 487 67 278 minecraft:light[level=12]
setblock 487 67 285 minecraft:light[level=12]
setblock 487 67 292 minecraft:light[level=12]
setblock 487 67 299 minecraft:light[level=12]
setblock 487 67 306 minecraft:light[level=12]
setblock 487 67 313 minecraft:light[level=12]
setblock 494 67 278 minecraft:light[level=12]
setblock 494 67 285 minecraft:light[level=12]
setblock 494 67 292 minecraft:light[level=12]
setblock 494 67 299 minecraft:light[level=12]
setblock 494 67 306 minecraft:light[level=12]
setblock 494 67 313 minecraft:light[level=12]
setblock 501 67 278 minecraft:light[level=12]
setblock 501 67 285 minecraft:light[level=12]
setblock 501 67 292 minecraft:light[level=12]
setblock 501 67 299 minecraft:light[level=12]
setblock 501 67 306 minecraft:light[level=12]
setblock 501 67 313 minecraft:light[level=12]
setblock 508 67 278 minecraft:light[level=12]
setblock 508 67 285 minecraft:light[level=12]
setblock 508 67 292 minecraft:light[level=12]
setblock 508 67 299 minecraft:light[level=12]
setblock 508 67 306 minecraft:light[level=12]
setblock 508 67 313 minecraft:light[level=12]
fill 471 68 276 479 68 316 minecraft:gray_stained_glass
fill 480 68 276 480 68 295 minecraft:gray_stained_glass
fill 480 68 299 480 68 316 minecraft:gray_stained_glass
fill 481 68 276 511 68 294 minecraft:gray_stained_glass
fill 481 68 300 511 68 316 minecraft:gray_stained_glass
fill 484 68 295 511 68 295 minecraft:gray_stained_glass
fill 484 68 299 511 68 299 minecraft:gray_stained_glass
fill 485 68 296 511 68 298 minecraft:gray_stained_glass
fill 471 69 276 471 69 286 minecraft:gray_stained_glass
fill 471 69 287 471 69 288 minecraft:white_wool
fill 471 69 289 471 69 292 minecraft:gray_stained_glass
setblock 471 69 293 minecraft:white_wool
fill 471 69 294 472 69 301 minecraft:gray_stained_glass
setblock 471 69 302 minecraft:white_wool
fill 471 69 303 471 69 305 minecraft:gray_stained_glass
setblock 471 69 306 minecraft:white_wool
fill 471 69 307 476 69 307 minecraft:gray_stained_glass
setblock 471 69 308 minecraft:white_wool
fill 471 69 309 471 69 311 minecraft:gray_stained_glass
setblock 471 69 312 minecraft:white_wool
fill 471 69 313 471 69 316 minecraft:gray_stained_glass
fill 472 69 276 472 69 277 minecraft:white_wool
setblock 472 69 278 minecraft:gray_stained_glass
fill 472 69 279 473 69 279 minecraft:white_wool
fill 472 69 280 472 69 288 minecraft:gray_stained_glass
setblock 472 69 289 minecraft:white_wool
setblock 472 69 290 minecraft:gray_stained_glass
setblock 472 69 291 minecraft:white_wool
fill 472 69 292 473 69 293 minecraft:gray_stained_glass
fill 472 69 302 473 69 303 minecraft:gray_stained_glass
fill 472 69 304 472 69 305 minecraft:white_wool
fill 472 69 306 478 69 306 minecraft:gray_stained_glass
fill 472 69 308 475 69 308 minecraft:gray_stained_glass
setblock 472 69 309 minecraft:white_wool
fill 472 69 310 472 69 315 minecraft:gray_stained_glass
fill 472 69 316 473 69 316 minecraft:white_wool
fill 473 69 276 481 69 276 minecraft:gray_stained_glass
fill 473 69 277 473 69 278 minecraft:white_wool
fill 473 69 280 473 69 281 minecraft:gray_stained_glass
setblock 473 69 282 minecraft:white_wool
fill 473 69 283 473 69 289 minecraft:gray_stained_glass
setblock 473 69 290 minecraft:white_wool
fill 473 69 291 475 69 291 minecraft:gray_stained_glass
fill 473 69 294 476 69 294 minecraft:gray_stained_glass
fill 473 69 295 473 69 299 minecraft:white_wool
fill 473 69 300 476 69 301 minecraft:gray_stained_glass
setblock 473 69 304 minecraft:white_wool
fill 473 69 305 476 69 305 minecraft:gray_stained_glass
fill 473 69 309 474 69 312 minecraft:gray_stained_glass
fill 473 69 313 474 69 313 minecraft:white_wool
setblock 473 69 314 minecraft:gray_stained_glass
setblock 473 69 315 minecraft:white_wool
fill 474 69 277 477 69 277 minecraft:gray_stained_glass
fill 474 69 278 475 69 278 minecraft:white_wool
fill 474 69 279 481 69 279 minecraft:gray_stained_glass
fill 474 69 280 474 69 281 minecraft:white_wool
fill 474 69 282 474 69 284 minecraft:gray_stained_glass
setblock 474 69 285 minecraft:white_wool
fill 474 69 286 474 69 290 minecraft:gray_stained_glass
setblock 474 69 292 minecraft:gray_stained_glass
setblock 474 69 293 minecraft:white_wool
setblock 474 69 295 minecraft:white_wool
fill 474 69 296 475 69 298 minecraft:gray_stained_glass
setblock 474 69 299 minecraft:white_wool
setblock 474 69 302 minecraft:white_wool
fill 474 69 303 474 69 304 minecraft:gray_stained_glass
fill 474 69 314 475 69 314 minecraft:white_wool
fill 474 69 315 476 69 316 minecraft:gray_stained_glass
fill 475 69 280 477 69 280 minecraft:gray_stained_glass
fill 475 69 281 475 69 283 minecraft:white_wool
fill 475 69 284 475 69 287 minecraft:gray_stained_glass
setblock 475 69 288 minecraft:white_wool
fill 475 69 289 476 69 290 minecraft:gray_stained_glass
fill 475 69 292 476 69 292 minecraft:white_wool
fill 475 69 293 476 69 293 minecraft:gray_stained_glass
fill 475 69 295 478 69 295 minecraft:gray_stained_glass
setblock 475 69 299 minecraft:gray_stained_glass
setblock 475 69 302 minecraft:gray_stained_glass
setblock 475 69 303 minecraft:white_wool
setblock 475 69 304 minecraft:gray_stained_glass
fill 475 69 309 475 69 310 minecraft:gray_stained_glass
fill 475 69 311 475 69 312 minecraft:white_wool
fill 475 69 313 481 69 313 minecraft:gray_stained_glass
fill 476 69 278 481 69 278 minecraft:gray_stained_glass
fill 476 69 281 477 69 283 minecraft:gray_stained_glass
fill 476 69 284 476 69 285 minecraft:white_wool
setblock 476 69 286 minecraft:gray_stained_glass
fill 476 69 287 477 69 287 minecraft:white_wool
fill 476 69 288 481 69 288 minecraft:gray_stained_glass
setblock 476 69 291 minecraft:white_wool
fill 476 69 296 476 69 299 minecraft:white_wool
setblock 476 69 302 minecraft:white_wool
fill 476 69 303 478 69 303 minecraft:gray_stained_glass
setblock 476 69 304 minecraft:white_wool
fill 476 69 308 476 69 310 minecraft:white_wool
fill 476 69 311 476 69 312 minecraft:gray_stained_glass
fill 476 69 314 481 69 314 minecraft:gray_stained_glass
fill 477 69 284 481 69 285 minecraft:gray_stained_glass
setblock 477 69 286 minecraft:white_wool
setblock 477 69 289 minecraft:gray_stained_glass
setblock 477 69 290 minecraft:white_wool
fill 477 69 291 478 69 292 minecraft:gray_stained_glass
fill 477 69 293 477 69 294 minecraft:white_wool
fill 477 69 296 477 69 300 minecraft:gray_stained_glass
setblock 477 69 301 minecraft:white_wool
setblock 477 69 302 minecraft:gray_stained_glass
fill 477 69 304 481 69 304 minecraft:gray_stained_glass
fill 477 69 305 478 69 305 minecraft:white_wool
fill 477 69 307 477 69 308 minecraft:white_wool
fill 477 69 309 477 69 311 minecraft:gray_stained_glass
fill 477 69 312 478 69 312 minecraft:white_wool
fill 477 69 315 478 69 315 minecraft:white_wool
fill 477 69 316 481 69 316 minecraft:gray_stained_glass
fill 478 69 277 480 69 277 minecraft:white_wool
fill 478 69 280 480 69 280 minecraft:white_wool
fill 478 69 281 481 69 282 minecraft:gray_stained_glass
fill 478 69 283 480 69 283 minecraft:white_wool
fill 478 69 286 478 69 287 minecraft:gray_stained_glass
fill 478 69 289 480 69 289 minecraft:white_wool
fill 478 69 290 481 69 290 minecraft:gray_stained_glass
setblock 478 69 293 minecraft:white_wool
fill 478 69 294 479 69 294 minecraft:gray_stained_glass
setblock 478 69 296 minecraft:white_wool
setblock 478 69 297 minecraft:gray_stained_glass
setblock 478 69 298 minecraft:white_wool
fill 478 69 299 478 69 301 minecraft:gray_stained_glass
setblock 478 69 302 minecraft:white_wool
fill 478 69 307 481 69 308 minecraft:gray_stained_glass
setblock 478 69 309 minecraft:white_wool
fill 478 69 310 481 69 311 minecraft:gray_stained_glass
fill 479 69 286 480 69 286 minecraft:white_wool
fill 479 69 287 481 69 287 minecraft:gray_stained_glass
setblock 479 69 291 minecraft:white_wool
fill 479 69 292 479 69 293 minecraft:gray_stained_glass
fill 479 69 295 479 69 299 minecraft:redstone_block
fill 479 69 300 479 69 302 minecraft:gray_stained_glass
setblock 479 69 303 minecraft:white_wool
fill 479 69 305 481 69 305 minecraft:gray_stained_glass
setblock 479 69 306 minecraft:white_wool
fill 479 69 309 481 69 309 minecraft:gray_stained_glass
fill 479 69 312 481 69 312 minecraft:gray_stained_glass
fill 479 69 315 481 69 315 minecraft:gray_stained_glass
fill 480 69 291 481 69 291 minecraft:gray_stained_glass
fill 480 69 292 480 69 293 minecraft:white_wool
fill 480 69 294 480 69 295 minecraft:redstone_block
fill 480 69 299 480 69 300 minecraft:redstone_block
setblock 480 69 301 minecraft:white_wool
fill 480 69 302 481 69 303 minecraft:gray_stained_glass
fill 480 69 306 481 69 306 minecraft:gray_stained_glass
setblock 481 69 277 minecraft:gray_stained_glass
setblock 481 69 280 minecraft:gray_stained_glass
setblock 481 69 283 minecraft:gray_stained_glass
setblock 481 69 286 minecraft:gray_stained_glass
setblock 481 69 289 minecraft:gray_stained_glass
fill 481 69 292 481 69 293 minecraft:gray_stained_glass
fill 481 69 294 484 69 294 minecraft:redstone_block
fill 481 69 300 484 69 300 minecraft:redstone_block
setblock 481 69 301 minecraft:gray_stained_glass
fill 482 69 276 482 69 293 minecraft:white_wool
fill 482 69 301 482 69 316 minecraft:white_wool
fill 483 69 276 490 69 276 minecraft:gray_stained_glass
fill 483 69 277 485 69 277 minecraft:white_wool
fill 483 69 278 487 69 279 minecraft:gray_stained_glass
fill 483 69 280 485 69 280 minecraft:white_wool
fill 483 69 281 487 69 282 minecraft:gray_stained_glass
fill 483 69 283 485 69 283 minecraft:white_wool
fill 483 69 284 486 69 285 minecraft:gray_stained_glass
fill 483 69 286 484 69 286 minecraft:white_wool
fill 483 69 287 486 69 288 minecraft:gray_stained_glass
fill 483 69 289 484 69 289 minecraft:white_wool
fill 483 69 290 484 69 291 minecraft:gray_stained_glass
setblock 483 69 292 minecraft:white_wool
setblock 483 69 293 minecraft:gray_stained_glass
fill 483 69 301 483 69 316 minecraft:gray_stained_glass
fill 484 69 292 487 69 292 minecraft:gray_stained_glass
fill 484 69 293 485 69 293 minecraft:white_wool
fill 484 69 295 485 69 295 minecraft:redstone_block
fill 484 69 299 485 69 299 minecraft:redstone_block
setblock 484 69 301 minecraft:white_wool
fill 484 69 302 484 69 316 minecraft:gray_stained_glass
fill 485 69 286 486 69 286 minecraft:gray_stained_glass
fill 485 69 289 485 69 290 minecraft:gray_stained_glass
setblock 485 69 291 minecraft:white_wool
setblock 485 69 294 minecraft:gray_stained_glass
fill 485 69 296 485 69 298 minecraft:redstone_block
setblock 485 69 300 minecraft:white_wool
fill 485 69 301 486 69 302 minecraft:gray_stained_glass
fill 485 69 303 486 69 303 minecraft:white_wool
fill 485 69 304 485 69 316 minecraft:gray_stained_glass
fill 486 69 277 490 69 277 minecraft:gray_stained_glass
fill 486 69 280 489 69 280 minecraft:gray_stained_glass
fill 486 69 283 488 69 283 minecraft:gray_stained_glass
fill 486 69 289 486 69 290 minecraft:white_wool
setblock 486 69 291 minecraft:gray_stained_glass
setblock 486 69 293 minecraft:gray_stained_glass
setblock 486 69 294 minecraft:white_wool
fill 486 69 295 489 69 295 minecraft:gray_stained_glass
setblock 486 69 296 minecraft:white_wool
fill 486 69 297 511 69 297 minecraft:gray_stained_glass
fill 486 69 298 486 69 299 minecraft:white_wool
fill 486 69 300 491 69 300 minecraft:gray_stained_glass
fill 486 69 304 490 69 304 minecraft:gray_stained_glass
fill 486 69 305 486 69 306 minecraft:white_wool
fill 486 69 307 486 69 316 minecraft:gray_stained_glass
fill 487 69 284 488 69 284 minecraft:white_wool
setblock 487 69 285 minecraft:gray_stained_glass
fill 487 69 286 487 69 287 minecraft:white_wool
fill 487 69 288 487 69 290 minecraft:gray_stained_glass
setblock 487 69 291 minecraft:white_wool
setblock 487 69 293 minecraft:white_wool
fill 487 69 294 488 69 294 minecraft:gray_stained_glass
fill 487 69 296 511 69 296 minecraft:gray_stained_glass
fill 487 69 298 488 69 299 minecraft:gray_stained_glass
fill 487 69 301 488 69 302 minecraft:white_wool
fill 487 69 303 489 69 303 minecraft:gray_stained_glass
fill 487 69 305 487 69 306 minecraft:gray_stained_glass
fill 487 69 307 487 69 309 minecraft:white_wool
fill 487 69 310 487 69 311 minecraft:gray_stained_glass
setblock 487 69 312 minecraft:white_wool
fill 487 69 313 489 69 314 minecraft:gray_stained_glass
fill 487 69 315 488 69 315 minecraft:white_wool
fill 487 69 316 490 69 316 minecraft:gray_stained_glass
fill 488 69 278 489 69 278 minecraft:white_wool
fill 488 69 279 490 69 279 minecraft:gray_stained_glass
setblock 488 69 281 minecraft:white_wool
setblock 488 69 282 minecraft:gray_stained_glass
fill 488 69 285 489 69 285 minecraft:white_wool
fill 488 69 286 493 69 287 minecraft:gray_stained_glass
setblock 488 69 288 minecraft:white_wool
fill 488 69 289 489 69 291 minecraft:gray_stained_glass
setblock 488 69 292 minecraft:white_wool
fill 488 69 293 491 69 293 minecraft:gray_stained_glass
setblock 488 69 305 minecraft:white_wool
fill 488 69 306 488 69 308 minecraft:gray_stained_glass
fill 488 69 309 488 69 310 minecraft:white_wool
fill 488 69 311 488 69 312 minecraft:gray_stained_glass
setblock 489 69 281 minecraft:gray_stained_glass
fill 489 69 282 489 69 283 minecraft:white_wool
fill 489 69 284 492 69 284 minecraft:gray_stained_glass
fill 489 69 288 492 69 288 minecraft:gray_stained_glass
fill 489 69 292 497 69 292 minecraft:gray_stained_glass
setblock 489 69 294 minecraft:white_wool
fill 489 69 298 511 69 298 minecraft:gray_stained_glass
fill 489 69 299 492 69 299 minecraft:white_wool
fill 489 69 301 490 69 302 minecraft:gray_stained_glass
fill 489 69 305 491 69 307 minecraft:gray_stained_glass
setblock 489 69 308 minecraft:white_wool
fill 489 69 309 492 69 310 minecraft:gray_stained_glass
fill 489 69 311 489 69 312 minecraft:white_wool
fill 489 69 315 490 69 315 minecraft:gray_stained_glass
setblock 490 69 278 minecraft:gray_stained_glass
fill 490 69 280 490 69 282 minecraft:white_wool
fill 490 69 283 495 69 283 minecraft:gray_stained_glass
fill 490 69 285 493 69 285 minecraft:gray_stained_glass
fill 490 69 289 491 69 289 minecraft:gray_stained_glass
fill 490 69 290 491 69 290 minecraft:white_wool
setblock 490 69 291 minecraft:gray_stained_glass
fill 490 69 294 491 69 294 minecraft:gray_stained_glass
fill 490 69 295 491 69 295 minecraft:white_wool
setblock 490 69 303 minecraft:white_wool
fill 490 69 308 493 69 308 minecraft:gray_stained_glass
setblock 490 69 311 minecraft:white_wool
fill 490 69 312 493 69 312 minecraft:gray_stained_glass
fill 490 69 313 490 69 314 minecraft:white_wool
fill 491 69 276 491 69 279 minecraft:white_wool
fill 491 69 280 493 69 282 minecraft:gray_stained_glass
setblock 491 69 291 minecraft:white_wool
fill 491 69 301 497 69 301 minecraft:gray_stained_glass
setblock 491 69 302 minecraft:white_wool
fill 491 69 303 493 69 303 minecraft:gray_stained_glass
setblock 491 69 304 minecraft:white_wool
fill 491 69 311 494 69 311 minecraft:gray_stained_glass
fill 491 69 313 491 69 314 minecraft:gray_stained_glass
fill 491 69 315 491 69 316 minecraft:white_wool
fill 492 69 276 492 69 277 minecraft:white_wool
fill 492 69 278 494 69 279 minecraft:gray_stained_glass
fill 492 69 289 493 69 289 minecraft:white_wool
fill 492 69 290 493 69 291 minecraft:gray_stained_glass
fill 492 69 293 492 69 294 minecraft:white_wool
fill 492 69 295 511 69 295 minecraft:gray_stained_glass
setblock 492 69 300 minecraft:white_wool
fill 492 69 302 501 69 302 minecraft:gray_stained_glass
setblock 492 69 304 minecraft:gray_stained_glass
setblock 492 69 305 minecraft:white_wool
fill 492 69 306 492 69 307 minecraft:gray_stained_glass
setblock 492 69 313 minecraft:white_wool
fill 492 69 314 492 69 316 minecraft:gray_stained_glass
fill 493 69 276 496 69 276 minecraft:gray_stained_glass
setblock 493 69 277 minecraft:white_wool
setblock 493 69 284 minecraft:white_wool
setblock 493 69 288 minecraft:white_wool
fill 493 69 293 493 69 294 minecraft:gray_stained_glass
fill 493 69 299 493 69 300 minecraft:gray_stained_glass
setblock 493 69 304 minecraft:white_wool
fill 493 69 305 495 69 305 minecraft:gray_stained_glass
setblock 493 69 306 minecraft:white_wool
setblock 493 69 307 minecraft:gray_stained_glass
setblock 493 69 309 minecraft:white_wool
fill 493 69 310 495 69 310 minecraft:gray_stained_glass
fill 493 69 313 494 69 315 minecraft:gray_stained_glass
setblock 493 69 316 minecraft:white_wool
fill 494 69 277 502 69 277 minecraft:gray_stained_glass
fill 494 69 280 502 69 280 minecraft:gray_stained_glass
setblock 494 69 281 minecraft:white_wool
setblock 494 69 282 minecraft:gray_stained_glass
fill 494 69 284 496 69 284 minecraft:gray_stained_glass
setblock 494 69 285 minecraft:white_wool
setblock 494 69 286 minecraft:gray_stained_glass
fill 494 69 287 495 69 287 minecraft:white_wool
fill 494 69 288 495 69 289 minecraft:gray_stained_glass
setblock 494 69 290 minecraft:white_wool
fill 494 69 291 503 69 291 minecraft:gray_stained_glass
setblock 494 69 293 minecraft:gray_stained_glass
fill 494 69 294 496 69 294 minecraft:white_wool
fill 494 69 299 511 69 299 minecraft:gray_stained_glass
fill 494 69 300 496 69 300 minecraft:white_wool
setblock 494 69 303 minecraft:white_wool
fill 494 69 304 499 69 304 minecraft:gray_stained_glass
fill 494 69 306 498 69 306 minecraft:gray_stained_glass
fill 494 69 307 494 69 308 minecraft:white_wool
fill 494 69 309 496 69 309 minecraft:gray_stained_glass
setblock 494 69 312 minecraft:white_wool
fill 494 69 316 502 69 316 minecraft:gray_stained_glass
setblock 495 69 278 minecraft:white_wool
setblock 495 69 279 minecraft:gray_stained_glass
fill 495 69 281 500 69 281 minecraft:gray_stained_glass
setblock 495 69 282 minecraft:white_wool
fill 495 69 285 496 69 285 minecraft:gray_stained_glass
fill 495 69 286 496 69 286 minecraft:white_wool
fill 495 69 290 496 69 290 minecraft:gray_stained_glass
setblock 495 69 293 minecraft:white_wool
fill 495 69 303 496 69 303 minecraft:gray_stained_glass
setblock 495 69 307 minecraft:white_wool
setblock 495 69 308 minecraft:gray_stained_glass
setblock 495 69 311 minecraft:white_wool
fill 495 69 312 495 69 314 minecraft:gray_stained_glass
setblock 495 69 315 minecraft:white_wool
fill 496 69 278 504 69 278 minecraft:gray_stained_glass
setblock 496 69 279 minecraft:white_wool
fill 496 69 282 498 69 282 minecraft:gray_stained_glass
setblock 496 69 283 minecraft:white_wool
fill 496 69 287 498 69 287 minecraft:gray_stained_glass
setblock 496 69 288 minecraft:white_wool
fill 496 69 289 499 69 289 minecraft:gray_stained_glass
fill 496 69 293 497 69 293 minecraft:gray_stained_glass
setblock 496 69 305 minecraft:white_wool
fill 496 69 307 501 69 307 minecraft:gray_stained_glass
setblock 496 69 308 minecraft:white_wool
setblock 496 69 310 minecraft:white_wool
fill 496 69 311 496 69 313 minecraft:gray_stained_glass
setblock 496 69 314 minecraft:white_wool
fill 496 69 315 503 69 315 minecraft:gray_stained_glass
setblock 497 69 276 minecraft:white_wool
fill 497 69 279 503 69 279 minecraft:gray_stained_glass
fill 497 69 283 498 69 283 minecraft:gray_stained_glass
fill 497 69 284 498 69 285 minecraft:white_wool
fill 497 69 286 501 69 286 minecraft:gray_stained_glass
fill 497 69 288 502 69 288 minecraft:gray_stained_glass
setblock 497 69 290 minecraft:white_wool
fill 497 69 294 511 69 294 minecraft:gray_stained_glass
setblock 497 69 300 minecraft:gray_stained_glass
setblock 497 69 303 minecraft:white_wool
fill 497 69 305 502 69 305 minecraft:gray_stained_glass
setblock 497 69 308 minecraft:gray_stained_glass
setblock 497 69 309 minecraft:white_wool
fill 497 69 310 497 69 312 minecraft:gray_stained_glass
setblock 497 69 313 minecraft:white_wool
fill 497 69 314 502 69 314 minecraft:gray_stained_glass
fill 498 69 276 501 69 276 minecraft:gray_stained_glass
fill 498 69 290 509 69 290 minecraft:gray_stained_glass
fill 498 69 292 498 69 293 minecraft:white_wool
fill 498 69 300 498 69 301 minecraft:white_wool
fill 498 69 303 505 69 303 minecraft:gray_stained_glass
setblock 498 69 308 minecraft:white_wool
fill 498 69 309 503 69 309 minecraft:gray_stained_glass
fill 498 69 310 500 69 310 minecraft:white_wool
setblock 498 69 311 minecraft:gray_stained_glass
setblock 498 69 312 minecraft:white_wool
fill 498 69 313 500 69 313 minecraft:gray_stained_glass
fill 499 69 282 499 69 284 minecraft:white_wool
fill 499 69 285 504 69 285 minecraft:gray_stained_glass
setblock 499 69 287 minecraft:white_wool
fill 499 69 292 500 69 292 minecraft:gray_stained_glass
fill 499 69 293 501 69 293 minecraft:white_wool
fill 499 69 300 500 69 300 minecraft:gray_stained_glass
fill 499 69 301 501 69 301 minecraft:white_wool
setblock 499 69 306 minecraft:white_wool
fill 499 69 308 504 69 308 minecraft:gray_stained_glass
fill 499 69 311 500 69 311 minecraft:white_wool
setblock 499 69 312 minecraft:gray_stained_glass
fill 500 69 282 500 69 283 minecraft:white_wool
fill 500 69 284 503 69 284 minecraft:gray_stained_glass
fill 500 69 287 508 69 287 minecraft:gray_stained_glass
setblock 500 69 289 minecraft:white_wool
setblock 500 69 304 minecraft:white_wool
fill 500 69 306 508 69 306 minecraft:gray_stained_glass
fill 500 69 312 502 69 312 minecraft:white_wool
fill 501 69 281 501 69 282 minecraft:white_wool
fill 501 69 283 506 69 283 minecraft:gray_stained_glass
fill 501 69 289 502 69 289 minecraft:gray_stained_glass
fill 501 69 292 507 69 292 minecraft:white_wool
setblock 501 69 300 minecraft:white_wool
fill 501 69 304 502 69 304 minecraft:gray_stained_glass
fill 501 69 310 502 69 311 minecraft:gray_stained_glass
fill 501 69 313 503 69 313 minecraft:white_wool
setblock 502 69 276 minecraft:white_wool
fill 502 69 281 503 69 281 minecraft:white_wool
setblock 502 69 282 minecraft:gray_stained_glass
setblock 502 69 286 minecraft:white_wool
fill 502 69 293 511 69 293 minecraft:gray_stained_glass
fill 502 69 300 503 69 301 minecraft:gray_stained_glass
fill 502 69 302 507 69 302 minecraft:white_wool
setblock 502 69 307 minecraft:white_wool
fill 503 69 276 505 69 276 minecraft:gray_stained_glass
setblock 503 69 277 minecraft:white_wool
fill 503 69 280 505 69 280 minecraft:white_wool
setblock 503 69 282 minecraft:white_wool
fill 503 69 286 504 69 286 minecraft:gray_stained_glass
fill 503 69 288 503 69 289 minecraft:white_wool
fill 503 69 304 503 69 305 minecraft:white_wool
fill 503 69 307 511 69 307 minecraft:gray_stained_glass
fill 503 69 310 506 69 310 minecraft:gray_stained_glass
setblock 503 69 311 minecraft:white_wool
fill 503 69 312 505 69 312 minecraft:gray_stained_glass
fill 503 69 314 504 69 314 minecraft:white_wool
setblock 503 69 316 minecraft:white_wool
fill 504 69 277 505 69 277 minecraft:gray_stained_glass
fill 504 69 279 505 69 279 minecraft:white_wool
fill 504 69 281 505 69 282 minecraft:gray_stained_glass
setblock 504 69 284 minecraft:white_wool
fill 504 69 288 505 69 289 minecraft:gray_stained_glass
setblock 504 69 291 minecraft:white_wool
fill 504 69 300 511 69 300 minecraft:gray_stained_glass
setblock 504 69 301 minecraft:white_wool
fill 504 69 304 505 69 305 minecraft:gray_stained_glass
setblock 504 69 309 minecraft:white_wool
fill 504 69 311 509 69 311 minecraft:gray_stained_glass
setblock 504 69 313 minecraft:gray_stained_glass
fill 504 69 315 505 69 315 minecraft:white_wool
setblock 504 69 316 minecraft:gray_stained_glass
fill 505 69 278 507 69 278 minecraft:white_wool
fill 505 69 284 510 69 284 minecraft:gray_stained_glass
fill 505 69 285 505 69 286 minecraft:white_wool
setblock 505 69 291 minecraft:gray_stained_glass
fill 505 69 301 506 69 301 minecraft:gray_stained_glass
setblock 505 69 308 minecraft:white_wool
fill 505 69 309 510 69 309 minecraft:gray_stained_glass
setblock 505 69 313 minecraft:white_wool
fill 505 69 314 507 69 314 minecraft:gray_stained_glass
fill 505 69 316 507 69 316 minecraft:white_wool
fill 506 69 276 508 69 277 minecraft:white_wool
fill 506 69 279 507 69 280 minecraft:gray_stained_glass
setblock 506 69 281 minecraft:white_wool
fill 506 69 282 509 69 282 minecraft:gray_stained_glass
fill 506 69 285 507 69 286 minecraft:gray_stained_glass
setblock 506 69 288 minecraft:white_wool
fill 506 69 289 511 69 289 minecraft:gray_stained_glass
fill 506 69 291 511 69 291 minecraft:white_wool
fill 506 69 303 511 69 303 minecraft:white_wool
fill 506 69 304 509 69 304 minecraft:gray_stained_glass
setblock 506 69 305 minecraft:white_wool
fill 506 69 308 507 69 308 minecraft:gray_stained_glass
setblock 506 69 312 minecraft:white_wool
fill 506 69 313 508 69 313 minecraft:gray_stained_glass
fill 506 69 315 510 69 315 minecraft:gray_stained_glass
fill 507 69 281 511 69 281 minecraft:gray_stained_glass
setblock 507 69 283 minecraft:white_wool
fill 507 69 288 508 69 288 minecraft:gray_stained_glass
setblock 507 69 301 minecraft:white_wool
fill 507 69 305 508 69 305 minecraft:gray_stained_glass
setblock 507 69 310 minecraft:white_wool
fill 507 69 312 511 69 312 minecraft:gray_stained_glass
fill 508 69 278 510 69 278 minecraft:gray_stained_glass
setblock 508 69 279 minecraft:white_wool
setblock 508 69 280 minecraft:gray_stained_glass
fill 508 69 283 511 69 283 minecraft:gray_stained_glass
setblock 508 69 285 minecraft:white_wool
fill 508 69 286 511 69 286 minecraft:gray_stained_glass
fill 508 69 292 509 69 292 minecraft:gray_stained_glass
fill 508 69 301 509 69 302 minecraft:gray_stained_glass
setblock 508 69 308 minecraft:white_wool
fill 508 69 310 511 69 310 minecraft:gray_stained_glass
setblock 508 69 314 minecraft:white_wool
fill 508 69 316 511 69 316 minecraft:gray_stained_glass
fill 509 69 276 510 69 276 minecraft:white_wool
fill 509 69 277 511 69 277 minecraft:gray_stained_glass
fill 509 69 279 511 69 279 minecraft:gray_stained_glass
setblock 509 69 280 minecraft:white_wool
fill 509 69 285 511 69 285 minecraft:gray_stained_glass
fill 509 69 287 509 69 288 minecraft:white_wool
fill 509 69 305 509 69 306 minecraft:white_wool
fill 509 69 308 511 69 308 minecraft:gray_stained_glass
setblock 509 69 313 minecraft:white_wool
fill 509 69 314 511 69 314 minecraft:gray_stained_glass
fill 510 69 280 511 69 280 minecraft:gray_stained_glass
setblock 510 69 282 minecraft:white_wool
fill 510 69 287 511 69 288 minecraft:gray_stained_glass
fill 510 69 290 511 69 290 minecraft:white_wool
setblock 510 69 292 minecraft:white_wool
fill 510 69 301 510 69 302 minecraft:white_wool
fill 510 69 304 511 69 304 minecraft:white_wool
fill 510 69 305 511 69 306 minecraft:gray_stained_glass
setblock 510 69 311 minecraft:white_wool
fill 510 69 313 511 69 313 minecraft:gray_stained_glass
setblock 511 69 276 minecraft:gray_stained_glass
setblock 511 69 278 minecraft:white_wool
setblock 511 69 282 minecraft:gray_stained_glass
setblock 511 69 284 minecraft:white_wool
setblock 511 69 292 minecraft:gray_stained_glass
fill 511 69 301 511 69 302 minecraft:gray_stained_glass
setblock 511 69 309 minecraft:white_wool
setblock 511 69 311 minecraft:gray_stained_glass
setblock 511 69 315 minecraft:white_wool
fill 470 70 275 470 92 278 minecraft:cobbled_deepslate
setblock 470 70 279 minecraft:white_wool
setblock 470 70 309 minecraft:white_wool
fill 470 71 279 470 91 279 minecraft:cobbled_deepslate
fill 470 71 309 470 94 309 minecraft:cobbled_deepslate
fill 512 71 298 512 91 299 minecraft:cobbled_deepslate
setblock 512 71 300 minecraft:redstone_block
fill 512 71 301 512 91 301 minecraft:cobbled_deepslate
setblock 503 72 315 minecraft:white_wool
setblock 504 72 314 minecraft:white_wool
setblock 505 72 313 minecraft:white_wool
setblock 506 72 312 minecraft:white_wool
fill 512 72 300 512 90 300 minecraft:cobbled_deepslate
fill 471 73 277 471 73 279 minecraft:deepslate_tiles
setblock 471 73 280 minecraft:cobbled_deepslate
fill 471 73 281 471 73 284 minecraft:deepslate_tiles
setblock 471 73 285 minecraft:cobbled_deepslate
fill 471 73 286 471 73 289 minecraft:deepslate_tiles
setblock 471 73 290 minecraft:cobbled_deepslate
fill 471 73 291 471 73 294 minecraft:deepslate_tiles
setblock 471 73 295 minecraft:cobbled_deepslate
fill 471 73 296 471 73 299 minecraft:deepslate_tiles
setblock 471 73 300 minecraft:cobbled_deepslate
fill 471 73 301 471 73 304 minecraft:deepslate_tiles
setblock 471 73 305 minecraft:cobbled_deepslate
fill 471 73 306 471 73 309 minecraft:deepslate_tiles
fill 472 73 276 474 73 276 minecraft:deepslate_tiles
setblock 472 73 278 minecraft:deepslate_tiles
setblock 472 73 279 minecraft:cobbled_deepslate
fill 472 73 280 472 73 283 minecraft:deepslate_tiles
setblock 472 73 284 minecraft:cobbled_deepslate
fill 472 73 285 472 73 288 minecraft:deepslate_tiles
setblock 472 73 289 minecraft:cobbled_deepslate
fill 472 73 290 472 74 292 minecraft:deepslate_tiles
fill 472 73 300 472 73 303 minecraft:deepslate_tiles
setblock 472 73 304 minecraft:cobbled_deepslate
fill 472 73 305 472 74 307 minecraft:deepslate_tiles
setblock 473 73 277 minecraft:deepslate_tiles
setblock 473 73 278 minecraft:light[level=12]
fill 473 73 279 473 73 282 minecraft:deepslate_tiles
setblock 473 73 283 minecraft:cobbled_deepslate
fill 473 73 284 473 73 287 minecraft:deepslate_tiles
setblock 473 73 288 minecraft:cobbled_deepslate
fill 473 73 289 473 75 290 minecraft:deepslate_tiles
setblock 473 73 292 minecraft:light[level=12]
setblock 473 73 299 minecraft:light[level=12]
setblock 473 73 306 minecraft:light[level=12]
setblock 473 73 313 minecraft:light[level=12]
setblock 474 73 277 minecraft:cobbled_deepslate
setblock 474 73 281 minecraft:deepslate_tiles
setblock 474 73 282 minecraft:cobbled_deepslate
fill 474 73 283 474 73 286 minecraft:deepslate_tiles
setblock 474 73 287 minecraft:cobbled_deepslate
fill 474 73 288 474 76 288 minecraft:deepslate_tiles
setblock 475 73 276 minecraft:cobbled_deepslate
fill 475 73 277 477 73 278 minecraft:deepslate_tiles
fill 475 73 284 475 74 284 minecraft:deepslate_tiles
setblock 475 73 316 minecraft:cobbled_deepslate
fill 476 73 276 479 73 276 minecraft:deepslate_tiles
setblock 476 73 279 minecraft:deepslate_tiles
fill 476 73 316 479 73 316 minecraft:deepslate_tiles
setblock 477 73 279 minecraft:cobbled_deepslate
setblock 478 73 277 minecraft:deepslate_tiles
setblock 478 73 278 minecraft:cobbled_deepslate
fill 478 73 279 479 73 279 minecraft:deepslate_tiles
setblock 479 73 277 minecraft:cobbled_deepslate
fill 479 73 278 481 73 278 minecraft:deepslate_tiles
setblock 480 73 276 minecraft:cobbled_deepslate
fill 480 73 277 483 73 277 minecraft:deepslate_tiles
setblock 480 73 285 minecraft:light[level=12]
setblock 480 73 292 minecraft:light[level=12]
setblock 480 73 299 minecraft:light[level=12]
setblock 480 73 306 minecraft:light[level=12]
setblock 480 73 313 minecraft:light[level=12]
setblock 480 73 316 minecraft:cobbled_deepslate
fill 481 73 276 484 73 276 minecraft:deepslate_tiles
fill 481 73 316 482 75 316 minecraft:deepslate_tiles
setblock 485 73 276 minecraft:cobbled_deepslate
fill 486 73 276 489 73 276 minecraft:deepslate_tiles
setblock 487 73 278 minecraft:light[level=12]
setblock 487 73 285 minecraft:light[level=12]
setblock 487 73 292 minecraft:light[level=12]
setblock 487 73 299 minecraft:light[level=12]
setblock 487 73 306 minecraft:light[level=12]
setblock 487 73 313 minecraft:light[level=12]
setblock 490 73 276 minecraft:cobbled_deepslate
setblock 490 73 316 minecraft:cobbled_deepslate
fill 491 73 276 494 73 276 minecraft:deepslate_tiles
fill 491 73 316 494 73 316 minecraft:deepslate_tiles
setblock 493 73 277 minecraft:deepslate_tiles
fill 493 73 315 495 73 315 minecraft:deepslate_tiles
setblock 494 73 277 minecraft:cobbled_deepslate
setblock 494 73 278 minecraft:light[level=12]
setblock 494 73 285 minecraft:light[level=12]
setblock 494 73 292 minecraft:light[level=12]
setblock 494 73 299 minecraft:light[level=12]
setblock 494 73 306 minecraft:light[level=12]
setblock 494 73 313 minecraft:light[level=12]
setblock 495 73 276 minecraft:cobbled_deepslate
fill 495 73 277 498 73 277 minecraft:deepslate_tiles
fill 495 73 314 496 73 314 minecraft:deepslate_tiles
setblock 495 73 316 minecraft:cobbled_deepslate
fill 496 73 276 499 73 276 minecraft:deepslate_tiles
setblock 496 73 315 minecraft:cobbled_deepslate
fill 496 73 316 499 73 316 minecraft:deepslate_tiles
setblock 497 73 314 minecraft:cobbled_deepslate
fill 497 73 315 500 73 315 minecraft:deepslate_tiles
fill 498 73 314 498 76 314 minecraft:deepslate_tiles
setblock 500 73 276 minecraft:cobbled_deepslate
setblock 500 73 316 minecraft:cobbled_deepslate
setblock 501 73 276 minecraft:deepslate_tiles
setblock 501 73 278 minecraft:light[level=12]
setblock 501 73 285 minecraft:light[level=12]
setblock 501 73 292 minecraft:light[level=12]
setblock 501 73 299 minecraft:light[level=12]
setblock 501 73 306 minecraft:light[level=12]
setblock 501 73 313 minecraft:light[level=12]
fill 501 73 316 502 75 316 minecraft:deepslate_tiles
fill 504 73 302 504 74 302 minecraft:white_wool
fill 506 73 286 508 73 288 minecraft:black_concrete
setblock 507 73 311 minecraft:white_wool
setblock 508 73 278 minecraft:light[level=12]
setblock 508 73 285 minecraft:light[level=12]
setblock 508 73 292 minecraft:light[level=12]
setblock 508 73 299 minecraft:light[level=12]
setblock 508 73 306 minecraft:light[level=12]
setblock 508 73 310 minecraft:white_wool
setblock 508 73 313 minecraft:light[level=12]
setblock 509 73 309 minecraft:white_wool
setblock 510 73 285 minecraft:deepslate_tiles
setblock 510 73 300 minecraft:deepslate_tiles
setblock 510 73 301 minecraft:cobbled_deepslate
fill 510 73 302 510 73 305 minecraft:deepslate_tiles
setblock 510 73 306 minecraft:cobbled_deepslate
fill 510 73 307 511 75 307 minecraft:deepslate_tiles
setblock 510 73 308 minecraft:white_wool
fill 510 73 309 511 73 309 minecraft:deepslate_tiles
setblock 511 73 280 minecraft:cobbled_deepslate
fill 511 73 281 511 73 284 minecraft:deepslate_tiles
setblock 511 73 285 minecraft:cobbled_deepslate
fill 511 73 286 511 73 289 minecraft:deepslate_tiles
setblock 511 73 290 minecraft:cobbled_deepslate
fill 511 73 291 511 73 294 minecraft:deepslate_tiles
setblock 511 73 295 minecraft:cobbled_deepslate
fill 511 73 296 511 73 299 minecraft:deepslate_tiles
setblock 511 73 300 minecraft:cobbled_deepslate
fill 511 73 301 511 73 304 minecraft:deepslate_tiles
setblock 511 73 305 minecraft:cobbled_deepslate
fill 511 73 306 511 76 306 minecraft:deepslate_tiles
fill 511 73 308 511 74 308 minecraft:deepslate_tiles
setblock 511 73 310 minecraft:cobbled_deepslate
fill 511 73 311 511 76 311 minecraft:deepslate_tiles
fill 471 74 276 471 74 278 minecraft:deepslate_tiles
setblock 471 74 279 minecraft:cobbled_deepslate
fill 471 74 280 471 74 283 minecraft:deepslate_tiles
setblock 471 74 284 minecraft:cobbled_deepslate
fill 471 74 285 471 74 288 minecraft:deepslate_tiles
setblock 471 74 289 minecraft:cobbled_deepslate
fill 471 74 290 471 74 293 minecraft:deepslate_tiles
setblock 471 74 294 minecraft:cobbled_deepslate
fill 471 74 295 471 74 298 minecraft:deepslate_tiles
setblock 471 74 299 minecraft:cobbled_deepslate
fill 471 74 300 471 74 303 minecraft:deepslate_tiles
setblock 471 74 304 minecraft:cobbled_deepslate
fill 471 74 305 471 74 308 minecraft:deepslate_tiles
setblock 471 74 309 minecraft:cobbled_deepslate
fill 471 74 310 471 76 311 minecraft:deepslate_tiles
fill 471 74 317 476 90 317 minecraft:cobbled_deepslate
fill 472 74 276 473 74 276 minecraft:deepslate_tiles
setblock 472 74 278 minecraft:cobbled_deepslate
fill 472 74 279 472 74 282 minecraft:deepslate_tiles
setblock 472 74 283 minecraft:cobbled_deepslate
fill 472 74 284 472 74 287 minecraft:deepslate_tiles
setblock 472 74 288 minecraft:cobbled_deepslate
fill 472 74 289 472 77 289 minecraft:deepslate_tiles
setblock 472 74 293 minecraft:cobbled_deepslate
fill 472 74 294 472 77 294 minecraft:deepslate_tiles
fill 472 74 300 472 74 302 minecraft:deepslate_tiles
setblock 472 74 303 minecraft:cobbled_deepslate
fill 472 74 304 472 77 304 minecraft:deepslate_tiles
setblock 472 74 308 minecraft:cobbled_deepslate
fill 472 74 309 472 77 309 minecraft:deepslate_tiles
setblock 473 74 277 minecraft:cobbled_deepslate
fill 473 74 279 473 74 281 minecraft:deepslate_tiles
setblock 473 74 282 minecraft:cobbled_deepslate
fill 473 74 283 473 74 286 minecraft:deepslate_tiles
setblock 473 74 287 minecraft:cobbled_deepslate
fill 473 74 288 473 77 288 minecraft:deepslate_tiles
setblock 473 74 291 minecraft:deepslate_tiles
setblock 474 74 276 minecraft:cobbled_deepslate
fill 474 74 277 476 74 278 minecraft:deepslate_tiles
setblock 474 74 281 minecraft:cobbled_deepslate
fill 474 74 282 474 74 285 minecraft:deepslate_tiles
setblock 474 74 286 minecraft:cobbled_deepslate
fill 474 74 287 474 77 287 minecraft:deepslate_tiles
fill 474 74 289 474 75 289 minecraft:deepslate_tiles
setblock 474 74 316 minecraft:cobbled_deepslate
fill 475 74 276 478 74 276 minecraft:deepslate_tiles
fill 475 74 283 475 75 283 minecraft:deepslate_tiles
setblock 475 74 285 minecraft:cobbled_deepslate
fill 475 74 286 475 77 286 minecraft:deepslate_tiles
fill 475 74 316 478 74 316 minecraft:deepslate_tiles
setblock 476 74 279 minecraft:cobbled_deepslate
setblock 477 74 277 minecraft:deepslate_tiles
setblock 477 74 278 minecraft:cobbled_deepslate
fill 477 74 279 478 74 279 minecraft:deepslate_tiles
setblock 477 74 317 minecraft:white_wool
setblock 478 74 277 minecraft:cobbled_deepslate
fill 478 74 278 480 74 278 minecraft:deepslate_tiles
setblock 479 74 276 minecraft:cobbled_deepslate
fill 479 74 277 482 74 277 minecraft:deepslate_tiles
setblock 479 74 316 minecraft:cobbled_deepslate
fill 480 74 276 483 74 276 minecraft:deepslate_tiles
fill 480 74 279 480 97 279 minecraft:white_wool
fill 480 74 316 480 77 316 minecraft:deepslate_tiles
setblock 483 74 277 minecraft:cobbled_deepslate
setblock 484 74 276 minecraft:cobbled_deepslate
fill 485 74 276 488 74 276 minecraft:deepslate_tiles
setblock 488 74 316 minecraft:deepslate_tiles
setblock 489 74 276 minecraft:cobbled_deepslate
setblock 489 74 316 minecraft:cobbled_deepslate
fill 490 74 276 493 74 276 minecraft:deepslate_tiles
fill 490 74 316 493 74 316 minecraft:deepslate_tiles
fill 491 74 315 494 74 315 minecraft:deepslate_tiles
setblock 493 74 277 minecraft:cobbled_deepslate
setblock 494 74 276 minecraft:cobbled_deepslate
fill 494 74 277 497 74 277 minecraft:deepslate_tiles
fill 494 74 314 495 74 314 minecraft:deepslate_tiles
setblock 494 74 316 minecraft:cobbled_deepslate
fill 495 74 276 498 74 276 minecraft:deepslate_tiles
setblock 495 74 315 minecraft:cobbled_deepslate
fill 495 74 316 498 74 316 minecraft:deepslate_tiles
setblock 496 74 314 minecraft:cobbled_deepslate
fill 496 74 315 499 74 315 minecraft:deepslate_tiles
fill 497 74 314 497 77 314 minecraft:deepslate_tiles
setblock 498 74 277 minecraft:cobbled_deepslate
setblock 499 74 276 minecraft:cobbled_deepslate
fill 499 74 314 499 75 314 minecraft:deepslate_tiles
setblock 499 74 316 minecraft:cobbled_deepslate
setblock 500 74 276 minecraft:deepslate_tiles
setblock 500 74 315 minecraft:cobbled_deepslate
fill 500 74 316 500 77 316 minecraft:deepslate_tiles
fill 509 74 304 509 74 305 minecraft:deepslate_tiles
setblock 509 74 306 minecraft:cobbled_deepslate
fill 510 74 283 510 74 284 minecraft:deepslate_tiles
setblock 510 74 285 minecraft:cobbled_deepslate
fill 510 74 286 510 74 289 minecraft:deepslate_tiles
setblock 510 74 290 minecraft:cobbled_deepslate
setblock 510 74 299 minecraft:deepslate_tiles
setblock 510 74 300 minecraft:cobbled_deepslate
fill 510 74 301 510 74 304 minecraft:deepslate_tiles
setblock 510 74 305 minecraft:cobbled_deepslate
fill 510 74 306 510 77 306 minecraft:deepslate_tiles
fill 510 74 308 510 74 309 minecraft:deepslate_tiles
setblock 510 74 310 minecraft:cobbled_deepslate
fill 511 74 280 511 74 283 minecraft:deepslate_tiles
setblock 511 74 284 minecraft:cobbled_deepslate
fill 511 74 285 511 74 288 minecraft:deepslate_tiles
setblock 511 74 289 minecraft:cobbled_deepslate
fill 511 74 290 511 74 293 minecraft:deepslate_tiles
setblock 511 74 294 minecraft:cobbled_deepslate
fill 511 74 295 511 74 298 minecraft:deepslate_tiles
setblock 511 74 299 minecraft:cobbled_deepslate
fill 511 74 300 511 74 303 minecraft:deepslate_tiles
setblock 511 74 304 minecraft:cobbled_deepslate
fill 511 74 305 511 77 305 minecraft:deepslate_tiles
setblock 511 74 309 minecraft:cobbled_deepslate
fill 511 74 310 511 77 310 minecraft:deepslate_tiles
fill 511 74 312 511 75 312 minecraft:deepslate_tiles
fill 471 75 276 471 75 277 minecraft:deepslate_tiles
setblock 471 75 278 minecraft:cobbled_deepslate
fill 471 75 279 471 75 282 minecraft:deepslate_tiles
setblock 471 75 283 minecraft:cobbled_deepslate
fill 471 75 284 471 75 287 minecraft:deepslate_tiles
setblock 471 75 288 minecraft:cobbled_deepslate
fill 471 75 289 471 75 292 minecraft:deepslate_tiles
setblock 471 75 293 minecraft:cobbled_deepslate
fill 471 75 294 471 75 297 minecraft:deepslate_tiles
setblock 471 75 298 minecraft:cobbled_deepslate
fill 471 75 299 471 75 302 minecraft:deepslate_tiles
setblock 471 75 303 minecraft:cobbled_deepslate
fill 471 75 304 471 75 307 minecraft:deepslate_tiles
setblock 471 75 308 minecraft:cobbled_deepslate
fill 471 75 309 471 78 309 minecraft:deepslate_tiles
setblock 471 75 312 minecraft:deepslate_tiles
setblock 472 75 276 minecraft:deepslate_tiles
setblock 472 75 277 minecraft:cobbled_deepslate
fill 472 75 278 472 75 281 minecraft:deepslate_tiles
setblock 472 75 282 minecraft:cobbled_deepslate
fill 472 75 283 472 75 286 minecraft:deepslate_tiles
setblock 472 75 287 minecraft:cobbled_deepslate
fill 472 75 288 472 78 288 minecraft:deepslate_tiles
fill 472 75 290 472 75 291 minecraft:deepslate_tiles
setblock 472 75 292 minecraft:cobbled_deepslate
fill 472 75 293 472 78 293 minecraft:deepslate_tiles
fill 472 75 295 472 76 295 minecraft:deepslate_tiles
setblock 472 75 301 minecraft:deepslate_tiles
setblock 472 75 302 minecraft:cobbled_deepslate
fill 472 75 303 472 77 303 minecraft:deepslate_tiles
fill 472 75 305 472 75 306 minecraft:deepslate_tiles
setblock 472 75 307 minecraft:cobbled_deepslate
fill 472 75 308 472 78 308 minecraft:deepslate_tiles
fill 472 75 310 472 76 310 minecraft:deepslate_tiles
setblock 473 75 276 minecraft:cobbled_deepslate
fill 473 75 277 476 75 277 minecraft:deepslate_tiles
fill 473 75 279 473 75 280 minecraft:deepslate_tiles
setblock 473 75 281 minecraft:cobbled_deepslate
fill 473 75 282 473 75 285 minecraft:deepslate_tiles
setblock 473 75 286 minecraft:cobbled_deepslate
fill 473 75 287 473 78 287 minecraft:deepslate_tiles
setblock 473 75 291 minecraft:cobbled_deepslate
fill 473 75 292 473 78 292 minecraft:deepslate_tiles
setblock 473 75 316 minecraft:cobbled_deepslate
fill 474 75 276 477 75 276 minecraft:deepslate_tiles
fill 474 75 278 475 75 278 minecraft:deepslate_tiles
fill 474 75 281 474 75 284 minecraft:deepslate_tiles
setblock 474 75 285 minecraft:cobbled_deepslate
fill 474 75 286 474 78 286 minecraft:deepslate_tiles
setblock 474 75 290 minecraft:cobbled_deepslate
fill 474 75 316 477 75 316 minecraft:deepslate_tiles
setblock 475 75 284 minecraft:cobbled_deepslate
fill 475 75 285 475 77 285 minecraft:deepslate_tiles
fill 475 75 287 475 76 287 minecraft:deepslate_tiles
setblock 476 75 278 minecraft:cobbled_deepslate
setblock 477 75 277 minecraft:cobbled_deepslate
fill 477 75 278 479 75 278 minecraft:deepslate_tiles
fill 477 75 317 477 95 317 minecraft:cobbled_deepslate
setblock 478 75 276 minecraft:cobbled_deepslate
fill 478 75 277 481 75 277 minecraft:deepslate_tiles
setblock 478 75 316 minecraft:cobbled_deepslate
fill 479 75 276 482 75 276 minecraft:deepslate_tiles
fill 479 75 316 479 78 316 minecraft:deepslate_tiles
setblock 482 75 277 minecraft:cobbled_deepslate
setblock 483 75 276 minecraft:cobbled_deepslate
setblock 483 75 316 minecraft:cobbled_deepslate
fill 484 75 276 487 75 276 minecraft:deepslate_tiles
setblock 487 75 316 minecraft:deepslate_tiles
setblock 488 75 276 minecraft:cobbled_deepslate
setblock 488 75 316 minecraft:cobbled_deepslate
fill 489 75 276 492 75 276 minecraft:deepslate_tiles
fill 489 75 316 492 75 316 minecraft:deepslate_tiles
fill 490 75 315 493 75 315 minecraft:deepslate_tiles
fill 492 75 314 494 75 314 minecraft:deepslate_tiles
setblock 493 75 276 minecraft:cobbled_deepslate
fill 493 75 277 496 75 277 minecraft:deepslate_tiles
setblock 493 75 316 minecraft:cobbled_deepslate
fill 494 75 276 497 75 276 minecraft:deepslate_tiles
setblock 494 75 315 minecraft:cobbled_deepslate
fill 494 75 316 497 75 316 minecraft:deepslate_tiles
setblock 495 75 313 minecraft:deepslate_tiles
setblock 495 75 314 minecraft:cobbled_deepslate
fill 495 75 315 498 75 315 minecraft:deepslate_tiles
setblock 496 75 313 minecraft:cobbled_deepslate
fill 496 75 314 496 78 314 minecraft:deepslate_tiles
fill 497 75 313 497 77 313 minecraft:deepslate_tiles
setblock 498 75 276 minecraft:cobbled_deepslate
setblock 498 75 316 minecraft:cobbled_deepslate
setblock 499 75 276 minecraft:deepslate_tiles
setblock 499 75 315 minecraft:cobbled_deepslate
fill 499 75 316 499 78 316 minecraft:deepslate_tiles
fill 500 75 315 500 77 315 minecraft:deepslate_tiles
setblock 509 75 305 minecraft:cobbled_deepslate
fill 509 75 306 509 76 307 minecraft:deepslate_tiles
setblock 510 75 283 minecraft:deepslate_tiles
setblock 510 75 284 minecraft:cobbled_deepslate
fill 510 75 285 510 75 288 minecraft:deepslate_tiles
setblock 510 75 289 minecraft:cobbled_deepslate
fill 510 75 290 511 75 292 minecraft:deepslate_tiles
setblock 510 75 299 minecraft:cobbled_deepslate
fill 510 75 300 510 75 303 minecraft:deepslate_tiles
setblock 510 75 304 minecraft:cobbled_deepslate
fill 510 75 305 510 78 305 minecraft:deepslate_tiles
setblock 510 75 308 minecraft:deepslate_tiles
setblock 510 75 309 minecraft:cobbled_deepslate
fill 510 75 310 510 78 310 minecraft:deepslate_tiles
fill 511 75 279 511 75 282 minecraft:deepslate_tiles
setblock 511 75 283 minecraft:cobbled_deepslate
fill 511 75 284 511 75 287 minecraft:deepslate_tiles
setblock 511 75 288 minecraft:cobbled_deepslate
fill 511 75 289 511 78 289 minecraft:deepslate_tiles
setblock 511 75 293 minecraft:cobbled_deepslate
fill 511 75 294 511 75 297 minecraft:deepslate_tiles
setblock 511 75 298 minecraft:cobbled_deepslate
fill 511 75 299 511 75 302 minecraft:deepslate_tiles
setblock 511 75 303 minecraft:cobbled_deepslate
fill 511 75 304 511 78 304 minecraft:deepslate_tiles
setblock 511 75 308 minecraft:cobbled_deepslate
fill 511 75 309 511 78 309 minecraft:deepslate_tiles
setblock 511 75 313 minecraft:cobbled_deepslate
setblock 471 76 276 minecraft:deepslate_tiles
setblock 471 76 277 minecraft:cobbled_deepslate
fill 471 76 278 471 76 281 minecraft:deepslate_tiles
setblock 471 76 282 minecraft:cobbled_deepslate
fill 471 76 283 471 76 286 minecraft:deepslate_tiles
setblock 471 76 287 minecraft:cobbled_deepslate
fill 471 76 288 471 76 291 minecraft:deepslate_tiles
setblock 471 76 292 minecraft:cobbled_deepslate
fill 471 76 293 471 76 296 minecraft:deepslate_tiles
setblock 471 76 297 minecraft:cobbled_deepslate
fill 471 76 298 471 76 301 minecraft:deepslate_tiles
setblock 471 76 302 minecraft:cobbled_deepslate
fill 471 76 303 471 76 306 minecraft:deepslate_tiles
setblock 471 76 307 minecraft:cobbled_deepslate
fill 471 76 308 471 79 308 minecraft:deepslate_tiles
setblock 471 76 312 minecraft:cobbled_deepslate
fill 471 76 313 471 78 314 minecraft:deepslate_tiles
setblock 472 76 276 minecraft:cobbled_deepslate
fill 472 76 277 472 76 280 minecraft:deepslate_tiles
setblock 472 76 281 minecraft:cobbled_deepslate
fill 472 76 282 472 76 285 minecraft:deepslate_tiles
setblock 472 76 286 minecraft:cobbled_deepslate
fill 472 76 287 472 79 287 minecraft:deepslate_tiles
setblock 472 76 290 minecraft:deepslate_tiles
setblock 472 76 291 minecraft:cobbled_deepslate
fill 472 76 292 472 79 292 minecraft:deepslate_tiles
setblock 472 76 302 minecraft:deepslate_tiles
setblock 472 76 305 minecraft:deepslate_tiles
setblock 472 76 306 minecraft:cobbled_deepslate
fill 472 76 307 472 79 307 minecraft:deepslate_tiles
setblock 472 76 311 minecraft:cobbled_deepslate
setblock 472 76 316 minecraft:cobbled_deepslate
fill 473 76 276 475 76 277 minecraft:deepslate_tiles
setblock 473 76 279 minecraft:deepslate_tiles
setblock 473 76 280 minecraft:cobbled_deepslate
fill 473 76 281 473 76 284 minecraft:deepslate_tiles
setblock 473 76 285 minecraft:cobbled_deepslate
fill 473 76 286 473 79 286 minecraft:deepslate_tiles
setblock 473 76 289 minecraft:deepslate_tiles
setblock 473 76 290 minecraft:cobbled_deepslate
fill 473 76 291 473 79 291 minecraft:deepslate_tiles
fill 473 76 293 473 77 293 minecraft:deepslate_tiles
fill 473 76 316 476 76 316 minecraft:deepslate_tiles
setblock 474 76 278 minecraft:deepslate_tiles
fill 474 76 281 474 76 283 minecraft:deepslate_tiles
setblock 474 76 284 minecraft:cobbled_deepslate
fill 474 76 285 474 79 285 minecraft:deepslate_tiles
setblock 474 76 289 minecraft:cobbled_deepslate
fill 474 76 290 474 79 290 minecraft:deepslate_tiles
setblock 475 76 278 minecraft:cobbled_deepslate
setblock 475 76 283 minecraft:cobbled_deepslate
setblock 475 76 284 minecraft:deepslate_tiles
setblock 475 76 288 minecraft:cobbled_deepslate
fill 475 76 315 477 76 315 minecraft:deepslate_tiles
setblock 476 76 276 minecraft:deepslate_tiles
setblock 476 76 277 minecraft:cobbled_deepslate
fill 476 76 278 478 76 278 minecraft:deepslate_tiles
setblock 477 76 276 minecraft:cobbled_deepslate
fill 477 76 277 480 76 277 minecraft:deepslate_tiles
setblock 477 76 316 minecraft:cobbled_deepslate
fill 478 76 276 481 76 276 minecraft:deepslate_tiles
setblock 478 76 315 minecraft:cobbled_deepslate
fill 478 76 316 478 79 316 minecraft:deepslate_tiles
setblock 481 76 277 minecraft:cobbled_deepslate
setblock 481 76 316 minecraft:deepslate_tiles
setblock 482 76 276 minecraft:cobbled_deepslate
setblock 482 76 316 minecraft:cobbled_deepslate
fill 483 76 276 484 76 276 minecraft:deepslate_tiles
fill 483 76 316 483 79 316 minecraft:deepslate_tiles
fill 485 76 316 486 76 316 minecraft:deepslate_tiles
setblock 485 76 317 minecraft:redstone_block
fill 486 76 317 486 94 317 minecraft:cobbled_deepslate
setblock 487 76 316 minecraft:cobbled_deepslate
fill 488 76 276 491 76 276 minecraft:deepslate_tiles
fill 488 76 316 491 76 316 minecraft:deepslate_tiles
fill 489 76 315 492 76 315 minecraft:deepslate_tiles
fill 491 76 314 493 76 314 minecraft:deepslate_tiles
setblock 492 76 276 minecraft:cobbled_deepslate
setblock 492 76 316 minecraft:cobbled_deepslate
fill 493 76 276 495 76 277 minecraft:deepslate_tiles
fill 493 76 313 494 76 313 minecraft:deepslate_tiles
setblock 493 76 315 minecraft:cobbled_deepslate
fill 493 76 316 496 76 316 minecraft:deepslate_tiles
setblock 494 76 314 minecraft:cobbled_deepslate
fill 494 76 315 497 76 315 minecraft:deepslate_tiles
setblock 495 76 313 minecraft:cobbled_deepslate
fill 495 76 314 495 79 314 minecraft:deepslate_tiles
setblock 496 76 276 minecraft:deepslate_tiles
fill 496 76 313 496 79 313 minecraft:deepslate_tiles
setblock 497 76 276 minecraft:cobbled_deepslate
setblock 497 76 316 minecraft:cobbled_deepslate
setblock 498 76 276 minecraft:deepslate_tiles
setblock 498 76 315 minecraft:cobbled_deepslate
fill 498 76 316 498 79 316 minecraft:deepslate_tiles
setblock 499 76 314 minecraft:cobbled_deepslate
fill 499 76 315 499 78 315 minecraft:deepslate_tiles
setblock 501 76 316 minecraft:deepslate_tiles
setblock 510 76 283 minecraft:cobbled_deepslate
fill 510 76 284 510 76 287 minecraft:deepslate_tiles
setblock 510 76 288 minecraft:cobbled_deepslate
fill 510 76 289 510 76 292 minecraft:deepslate_tiles
setblock 510 76 293 minecraft:cobbled_deepslate
fill 510 76 294 511 78 294 minecraft:deepslate_tiles
fill 510 76 299 510 76 302 minecraft:deepslate_tiles
setblock 510 76 303 minecraft:cobbled_deepslate
fill 510 76 304 510 79 304 minecraft:deepslate_tiles
setblock 510 76 307 minecraft:deepslate_tiles
setblock 510 76 308 minecraft:cobbled_deepslate
fill 510 76 309 510 79 309 minecraft:deepslate_tiles
fill 510 76 311 510 77 311 minecraft:deepslate_tiles
fill 511 76 279 511 76 281 minecraft:deepslate_tiles
setblock 511 76 282 minecraft:cobbled_deepslate
fill 511 76 283 511 76 286 minecraft:deepslate_tiles
setblock 511 76 287 minecraft:cobbled_deepslate
fill 511 76 288 511 79 288 minecraft:deepslate_tiles
fill 511 76 290 511 76 291 minecraft:deepslate_tiles
setblock 511 76 292 minecraft:cobbled_deepslate
fill 511 76 293 511 79 293 minecraft:deepslate_tiles
fill 511 76 295 511 76 296 minecraft:deepslate_tiles
setblock 511 76 297 minecraft:cobbled_deepslate
fill 511 76 298 511 76 301 minecraft:deepslate_tiles
setblock 511 76 302 minecraft:cobbled_deepslate
fill 511 76 303 511 79 303 minecraft:deepslate_tiles
setblock 511 76 307 minecraft:cobbled_deepslate
fill 511 76 308 511 79 308 minecraft:deepslate_tiles
setblock 511 76 312 minecraft:cobbled_deepslate
fill 511 76 313 511 78 314 minecraft:deepslate_tiles
setblock 471 77 276 minecraft:cobbled_deepslate
fill 471 77 277 471 77 280 minecraft:deepslate_tiles
setblock 471 77 281 minecraft:cobbled_deepslate
fill 471 77 282 471 77 285 minecraft:deepslate_tiles
setblock 471 77 286 minecraft:cobbled_deepslate
fill 471 77 287 471 77 290 minecraft:deepslate_tiles
setblock 471 77 291 minecraft:cobbled_deepslate
fill 471 77 292 471 77 295 minecraft:deepslate_tiles
setblock 471 77 296 minecraft:cobbled_deepslate
fill 471 77 297 471 77 300 minecraft:deepslate_tiles
setblock 471 77 301 minecraft:cobbled_deepslate
fill 471 77 302 471 77 305 minecraft:deepslate_tiles
setblock 471 77 306 minecraft:cobbled_deepslate
fill 471 77 307 471 80 307 minecraft:deepslate_tiles
setblock 471 77 310 minecraft:deepslate_tiles
setblock 471 77 311 minecraft:cobbled_deepslate
fill 471 77 312 472 79 312 minecraft:deepslate_tiles
setblock 471 77 315 minecraft:deepslate_tiles
fill 472 77 276 472 77 279 minecraft:deepslate_tiles
setblock 472 77 280 minecraft:cobbled_deepslate
fill 472 77 281 472 77 284 minecraft:deepslate_tiles
setblock 472 77 285 minecraft:cobbled_deepslate
fill 472 77 286 472 80 286 minecraft:deepslate_tiles
setblock 472 77 290 minecraft:cobbled_deepslate
fill 472 77 291 472 80 291 minecraft:deepslate_tiles
setblock 472 77 295 minecraft:cobbled_deepslate
setblock 472 77 305 minecraft:cobbled_deepslate
fill 472 77 306 472 78 306 minecraft:deepslate_tiles
setblock 472 77 310 minecraft:cobbled_deepslate
fill 472 77 311 472 80 311 minecraft:deepslate_tiles
fill 472 77 316 475 77 316 minecraft:deepslate_tiles
fill 473 77 276 474 77 277 minecraft:deepslate_tiles
setblock 473 77 278 minecraft:light[level=13]
setblock 473 77 279 minecraft:cobbled_deepslate
fill 473 77 280 473 77 283 minecraft:deepslate_tiles
setblock 473 77 284 minecraft:cobbled_deepslate
fill 473 77 285 473 80 285 minecraft:deepslate_tiles
setblock 473 77 289 minecraft:cobbled_deepslate
fill 473 77 290 473 80 290 minecraft:deepslate_tiles
setblock 473 77 294 minecraft:light[level=13]
setblock 473 77 302 minecraft:light[level=13]
setblock 473 77 310 minecraft:light[level=13]
setblock 474 77 282 minecraft:deepslate_tiles
setblock 474 77 283 minecraft:cobbled_deepslate
fill 474 77 284 474 79 284 minecraft:deepslate_tiles
setblock 474 77 288 minecraft:cobbled_deepslate
fill 474 77 289 474 80 289 minecraft:deepslate_tiles
setblock 474 77 291 minecraft:deepslate_tiles
fill 474 77 315 476 77 315 minecraft:deepslate_tiles
setblock 475 77 276 minecraft:deepslate_tiles
setblock 475 77 277 minecraft:cobbled_deepslate
fill 475 77 278 476 77 278 minecraft:deepslate_tiles
setblock 475 77 287 minecraft:cobbled_deepslate
setblock 476 77 276 minecraft:cobbled_deepslate
fill 476 77 277 479 77 277 minecraft:deepslate_tiles
setblock 476 77 316 minecraft:cobbled_deepslate
fill 477 77 276 480 77 276 minecraft:deepslate_tiles
setblock 477 77 315 minecraft:cobbled_deepslate
fill 477 77 316 477 80 316 minecraft:deepslate_tiles
fill 478 77 315 478 78 315 minecraft:deepslate_tiles
setblock 481 77 276 minecraft:cobbled_deepslate
setblock 481 77 278 minecraft:light[level=13]
setblock 481 77 286 minecraft:light[level=13]
setblock 481 77 294 minecraft:light[level=13]
setblock 481 77 302 minecraft:light[level=13]
setblock 481 77 310 minecraft:light[level=13]
setblock 481 77 316 minecraft:cobbled_deepslate
fill 482 77 276 483 77 276 minecraft:deepslate_tiles
fill 482 77 316 482 80 316 minecraft:deepslate_tiles
fill 484 77 316 485 77 316 minecraft:deepslate_tiles
fill 485 77 317 485 94 317 minecraft:cobbled_deepslate
setblock 486 77 316 minecraft:cobbled_deepslate
fill 487 77 316 490 77 316 minecraft:deepslate_tiles
fill 488 77 276 490 77 276 minecraft:deepslate_tiles
fill 488 77 315 491 77 315 minecraft:deepslate_tiles
setblock 489 77 278 minecraft:light[level=13]
setblock 489 77 286 minecraft:light[level=13]
setblock 489 77 294 minecraft:light[level=13]
setblock 489 77 302 minecraft:light[level=13]
setblock 489 77 310 minecraft:light[level=13]
fill 490 77 314 492 77 314 minecraft:deepslate_tiles
setblock 491 77 276 minecraft:cobbled_deepslate
setblock 491 77 316 minecraft:cobbled_deepslate
fill 492 77 276 495 77 276 minecraft:deepslate_tiles
setblock 492 77 315 minecraft:cobbled_deepslate
fill 492 77 316 495 77 316 minecraft:deepslate_tiles
setblock 493 77 313 minecraft:deepslate_tiles
setblock 493 77 314 minecraft:cobbled_deepslate
fill 493 77 315 496 77 315 minecraft:deepslate_tiles
setblock 494 77 313 minecraft:cobbled_deepslate
fill 494 77 314 494 80 314 minecraft:deepslate_tiles
fill 495 77 313 495 80 313 minecraft:deepslate_tiles
setblock 496 77 276 minecraft:cobbled_deepslate
setblock 496 77 316 minecraft:cobbled_deepslate
setblock 497 77 276 minecraft:deepslate_tiles
setblock 497 77 278 minecraft:light[level=13]
setblock 497 77 286 minecraft:light[level=13]
setblock 497 77 294 minecraft:light[level=13]
setblock 497 77 302 minecraft:light[level=13]
setblock 497 77 310 minecraft:light[level=13]
setblock 497 77 315 minecraft:cobbled_deepslate
fill 497 77 316 497 80 316 minecraft:deepslate_tiles
setblock 498 77 314 minecraft:cobbled_deepslate
fill 498 77 315 498 80 315 minecraft:deepslate_tiles
setblock 501 77 316 minecraft:cobbled_deepslate
setblock 505 77 278 minecraft:light[level=13]
setblock 505 77 286 minecraft:light[level=13]
setblock 505 77 294 minecraft:light[level=13]
setblock 505 77 302 minecraft:light[level=13]
setblock 505 77 310 minecraft:light[level=13]
setblock 509 77 288 minecraft:cobbled_deepslate
fill 509 77 289 510 79 289 minecraft:deepslate_tiles
fill 510 77 283 510 77 286 minecraft:deepslate_tiles
setblock 510 77 287 minecraft:cobbled_deepslate
fill 510 77 288 510 80 288 minecraft:deepslate_tiles
fill 510 77 290 510 77 291 minecraft:deepslate_tiles
setblock 510 77 292 minecraft:cobbled_deepslate
fill 510 77 293 510 80 293 minecraft:deepslate_tiles
fill 510 77 295 510 77 296 minecraft:deepslate_tiles
fill 510 77 300 510 77 301 minecraft:deepslate_tiles
setblock 510 77 302 minecraft:cobbled_deepslate
fill 510 77 303 510 78 303 minecraft:deepslate_tiles
setblock 510 77 307 minecraft:cobbled_deepslate
fill 510 77 308 510 80 308 minecraft:deepslate_tiles
fill 511 77 279 511 77 280 minecraft:deepslate_tiles
setblock 511 77 281 minecraft:cobbled_deepslate
fill 511 77 282 511 77 285 minecraft:deepslate_tiles
setblock 511 77 286 minecraft:cobbled_deepslate
fill 511 77 287 511 80 287 minecraft:deepslate_tiles
setblock 511 77 290 minecraft:deepslate_tiles
setblock 511 77 291 minecraft:cobbled_deepslate
fill 511 77 292 511 80 292 minecraft:deepslate_tiles
setblock 511 77 295 minecraft:deepslate_tiles
setblock 511 77 296 minecraft:cobbled_deepslate
fill 511 77 297 511 77 300 minecraft:deepslate_tiles
setblock 511 77 301 minecraft:cobbled_deepslate
fill 511 77 302 511 80 302 minecraft:deepslate_tiles
setblock 511 77 306 minecraft:cobbled_deepslate
fill 511 77 307 511 80 307 minecraft:deepslate_tiles
setblock 511 77 311 minecraft:cobbled_deepslate
fill 511 77 312 511 80 312 minecraft:deepslate_tiles
fill 471 78 276 471 78 279 minecraft:deepslate_tiles
setblock 471 78 280 minecraft:cobbled_deepslate
fill 471 78 281 471 78 284 minecraft:deepslate_tiles
setblock 471 78 285 minecraft:cobbled_deepslate
fill 471 78 286 471 78 289 minecraft:deepslate_tiles
setblock 471 78 290 minecraft:cobbled_deepslate
fill 471 78 291 471 78 294 minecraft:deepslate_tiles
setblock 471 78 295 minecraft:cobbled_deepslate
fill 471 78 296 471 78 299 minecraft:deepslate_tiles
setblock 471 78 300 minecraft:cobbled_deepslate
fill 471 78 301 471 78 304 minecraft:deepslate_tiles
setblock 471 78 305 minecraft:cobbled_deepslate
fill 471 78 306 471 81 306 minecraft:deepslate_tiles
setblock 471 78 310 minecraft:cobbled_deepslate
fill 471 78 311 471 81 311 minecraft:deepslate_tiles
setblock 471 78 315 minecraft:cobbled_deepslate
fill 471 78 316 474 78 316 minecraft:deepslate_tiles
fill 472 78 276 472 78 278 minecraft:deepslate_tiles
setblock 472 78 279 minecraft:cobbled_deepslate
fill 472 78 280 472 78 283 minecraft:deepslate_tiles
setblock 472 78 284 minecraft:cobbled_deepslate
fill 472 78 285 472 81 285 minecraft:deepslate_tiles
setblock 472 78 289 minecraft:cobbled_deepslate
fill 472 78 290 472 81 290 minecraft:deepslate_tiles
setblock 472 78 294 minecraft:cobbled_deepslate
fill 472 78 295 472 81 295 minecraft:deepslate_tiles
setblock 472 78 305 minecraft:deepslate_tiles
setblock 472 78 309 minecraft:cobbled_deepslate
fill 472 78 310 472 81 310 minecraft:deepslate_tiles
setblock 472 78 313 minecraft:deepslate_tiles
fill 473 78 276 473 78 277 minecraft:deepslate_tiles
fill 473 78 280 473 78 282 minecraft:deepslate_tiles
setblock 473 78 283 minecraft:cobbled_deepslate
fill 473 78 284 473 81 284 minecraft:deepslate_tiles
setblock 473 78 288 minecraft:cobbled_deepslate
fill 473 78 289 473 81 289 minecraft:deepslate_tiles
setblock 473 78 293 minecraft:cobbled_deepslate
setblock 474 78 276 minecraft:deepslate_tiles
setblock 474 78 277 minecraft:cobbled_deepslate
setblock 474 78 283 minecraft:deepslate_tiles
setblock 474 78 287 minecraft:cobbled_deepslate
fill 474 78 288 474 80 288 minecraft:deepslate_tiles
fill 474 78 315 475 78 315 minecraft:deepslate_tiles
setblock 475 78 276 minecraft:cobbled_deepslate
fill 475 78 277 478 78 277 minecraft:deepslate_tiles
setblock 475 78 316 minecraft:cobbled_deepslate
fill 476 78 276 479 78 276 minecraft:deepslate_tiles
setblock 476 78 315 minecraft:cobbled_deepslate
fill 476 78 316 476 81 316 minecraft:deepslate_tiles
fill 477 78 315 477 80 315 minecraft:deepslate_tiles
setblock 480 78 276 minecraft:cobbled_deepslate
setblock 480 78 316 minecraft:cobbled_deepslate
setblock 481 78 276 minecraft:deepslate_tiles
fill 481 78 316 481 81 316 minecraft:deepslate_tiles
setblock 484 78 316 minecraft:deepslate_tiles
setblock 485 78 316 minecraft:cobbled_deepslate
fill 486 78 316 489 78 316 minecraft:deepslate_tiles
fill 488 78 315 490 78 315 minecraft:deepslate_tiles
setblock 489 78 276 minecraft:deepslate_tiles
setblock 490 78 276 minecraft:cobbled_deepslate
fill 490 78 314 491 78 314 minecraft:deepslate_tiles
setblock 490 78 316 minecraft:cobbled_deepslate
fill 491 78 276 494 78 276 minecraft:deepslate_tiles
setblock 491 78 315 minecraft:cobbled_deepslate
fill 491 78 316 494 78 316 minecraft:deepslate_tiles
setblock 492 78 313 minecraft:deepslate_tiles
setblock 492 78 314 minecraft:cobbled_deepslate
fill 492 78 315 495 78 315 minecraft:deepslate_tiles
fill 493 78 275 493 94 275 minecraft:cobbled_deepslate
setblock 493 78 313 minecraft:cobbled_deepslate
fill 493 78 314 493 81 314 minecraft:deepslate_tiles
setblock 494 78 275 minecraft:white_wool
fill 494 78 313 494 81 313 minecraft:deepslate_tiles
fill 495 78 275 495 78 276 minecraft:cobbled_deepslate
setblock 495 78 316 minecraft:cobbled_deepslate
setblock 496 78 276 minecraft:deepslate_tiles
setblock 496 78 315 minecraft:cobbled_deepslate
fill 496 78 316 496 81 316 minecraft:deepslate_tiles
setblock 497 78 314 minecraft:cobbled_deepslate
fill 497 78 315 497 81 315 minecraft:deepslate_tiles
setblock 498 78 314 minecraft:deepslate_tiles
setblock 500 78 316 minecraft:cobbled_deepslate
setblock 509 78 287 minecraft:cobbled_deepslate
fill 509 78 288 509 81 288 minecraft:deepslate_tiles
fill 509 78 290 510 78 290 minecraft:deepslate_tiles
fill 510 78 283 510 78 285 minecraft:deepslate_tiles
setblock 510 78 286 minecraft:cobbled_deepslate
fill 510 78 287 510 81 287 minecraft:deepslate_tiles
setblock 510 78 291 minecraft:cobbled_deepslate
fill 510 78 292 510 81 292 minecraft:deepslate_tiles
setblock 510 78 295 minecraft:deepslate_tiles
setblock 510 78 296 minecraft:cobbled_deepslate
setblock 510 78 302 minecraft:deepslate_tiles
setblock 510 78 306 minecraft:cobbled_deepslate
fill 510 78 307 510 80 307 minecraft:deepslate_tiles
setblock 510 78 311 minecraft:cobbled_deepslate
fill 510 78 312 510 81 312 minecraft:deepslate_tiles
setblock 511 78 280 minecraft:cobbled_deepslate
fill 511 78 281 511 78 284 minecraft:deepslate_tiles
setblock 511 78 285 minecraft:cobbled_deepslate
fill 511 78 286 511 81 286 minecraft:deepslate_tiles
setblock 511 78 290 minecraft:cobbled_deepslate
fill 511 78 291 511 81 291 minecraft:deepslate_tiles
setblock 511 78 295 minecraft:cobbled_deepslate
fill 511 78 296 511 78 299 minecraft:deepslate_tiles
setblock 511 78 300 minecraft:cobbled_deepslate
fill 511 78 301 511 81 301 minecraft:deepslate_tiles
setblock 511 78 305 minecraft:cobbled_deepslate
fill 511 78 306 511 81 306 minecraft:deepslate_tiles
setblock 511 78 310 minecraft:cobbled_deepslate
fill 511 78 311 511 81 311 minecraft:deepslate_tiles
setblock 511 78 315 minecraft:cobbled_deepslate
fill 471 79 276 471 79 278 minecraft:deepslate_tiles
setblock 471 79 279 minecraft:cobbled_deepslate
fill 471 79 280 471 79 283 minecraft:deepslate_tiles
setblock 471 79 284 minecraft:cobbled_deepslate
fill 471 79 285 471 79 288 minecraft:deepslate_tiles
setblock 471 79 289 minecraft:cobbled_deepslate
fill 471 79 290 471 79 293 minecraft:deepslate_tiles
setblock 471 79 294 minecraft:cobbled_deepslate
fill 471 79 295 471 79 298 minecraft:deepslate_tiles
setblock 471 79 303 minecraft:deepslate_tiles
setblock 471 79 304 minecraft:cobbled_deepslate
fill 471 79 305 471 80 305 minecraft:deepslate_tiles
setblock 471 79 309 minecraft:cobbled_deepslate
fill 471 79 310 471 82 310 minecraft:deepslate_tiles
setblock 471 79 313 minecraft:deepslate_tiles
setblock 471 79 314 minecraft:cobbled_deepslate
fill 471 79 315 471 81 316 minecraft:deepslate_tiles
fill 472 79 276 472 79 277 minecraft:deepslate_tiles
setblock 472 79 278 minecraft:cobbled_deepslate
fill 472 79 279 472 79 282 minecraft:deepslate_tiles
setblock 472 79 283 minecraft:cobbled_deepslate
fill 472 79 284 472 82 284 minecraft:deepslate_tiles
setblock 472 79 288 minecraft:cobbled_deepslate
fill 472 79 289 472 82 289 minecraft:deepslate_tiles
setblock 472 79 293 minecraft:cobbled_deepslate
fill 472 79 294 472 82 294 minecraft:deepslate_tiles
setblock 472 79 308 minecraft:cobbled_deepslate
fill 472 79 309 472 81 309 minecraft:deepslate_tiles
setblock 472 79 313 minecraft:cobbled_deepslate
fill 472 79 314 472 82 314 minecraft:deepslate_tiles
fill 472 79 316 473 79 316 minecraft:deepslate_tiles
setblock 473 79 276 minecraft:deepslate_tiles
setblock 473 79 277 minecraft:cobbled_deepslate
setblock 473 79 278 minecraft:light[level=12]
setblock 473 79 281 minecraft:deepslate_tiles
setblock 473 79 282 minecraft:cobbled_deepslate
fill 473 79 283 473 80 283 minecraft:deepslate_tiles
setblock 473 79 287 minecraft:cobbled_deepslate
fill 473 79 288 473 82 288 minecraft:deepslate_tiles
setblock 473 79 292 minecraft:cobbled_deepslate
fill 473 79 293 473 80 293 minecraft:deepslate_tiles
setblock 473 79 299 minecraft:light[level=12]
setblock 473 79 306 minecraft:light[level=12]
setblock 473 79 313 minecraft:light[level=12]
fill 473 79 315 474 79 315 minecraft:deepslate_tiles
setblock 474 79 276 minecraft:cobbled_deepslate
fill 474 79 277 477 79 277 minecraft:deepslate_tiles
setblock 474 79 286 minecraft:cobbled_deepslate
fill 474 79 287 474 80 287 minecraft:deepslate_tiles
setblock 474 79 316 minecraft:cobbled_deepslate
fill 475 79 276 478 79 276 minecraft:deepslate_tiles
setblock 475 79 315 minecraft:cobbled_deepslate
fill 475 79 316 475 82 316 minecraft:deepslate_tiles
fill 476 79 315 476 82 315 minecraft:deepslate_tiles
setblock 479 79 276 minecraft:cobbled_deepslate
setblock 479 79 316 minecraft:cobbled_deepslate
setblock 480 79 276 minecraft:deepslate_tiles
setblock 480 79 278 minecraft:light[level=12]
setblock 480 79 285 minecraft:light[level=12]
setblock 480 79 292 minecraft:light[level=12]
setblock 480 79 299 minecraft:light[level=12]
setblock 480 79 306 minecraft:light[level=12]
setblock 480 79 313 minecraft:light[level=12]
fill 480 79 316 480 82 316 minecraft:deepslate_tiles
setblock 484 79 316 minecraft:cobbled_deepslate
fill 485 79 316 488 79 316 minecraft:deepslate_tiles
setblock 487 79 278 minecraft:light[level=12]
setblock 487 79 285 minecraft:light[level=12]
setblock 487 79 292 minecraft:light[level=12]
setblock 487 79 299 minecraft:light[level=12]
setblock 487 79 306 minecraft:light[level=12]
setblock 487 79 313 minecraft:light[level=12]
fill 487 79 315 489 79 315 minecraft:deepslate_tiles
setblock 489 79 276 minecraft:cobbled_deepslate
fill 489 79 314 490 79 314 minecraft:deepslate_tiles
setblock 489 79 316 minecraft:cobbled_deepslate
fill 490 79 276 493 79 276 minecraft:deepslate_tiles
setblock 490 79 315 minecraft:cobbled_deepslate
fill 490 79 316 493 79 316 minecraft:deepslate_tiles
setblock 491 79 314 minecraft:cobbled_deepslate
fill 491 79 315 494 79 315 minecraft:deepslate_tiles
setblock 492 79 313 minecraft:cobbled_deepslate
fill 492 79 314 492 82 314 minecraft:deepslate_tiles
fill 493 79 313 493 82 313 minecraft:deepslate_tiles
fill 494 79 275 494 79 276 minecraft:cobbled_deepslate
setblock 494 79 278 minecraft:light[level=12]
setblock 494 79 285 minecraft:light[level=12]
setblock 494 79 292 minecraft:light[level=12]
setblock 494 79 299 minecraft:light[level=12]
setblock 494 79 306 minecraft:light[level=12]
setblock 494 79 316 minecraft:cobbled_deepslate
fill 495 79 275 495 90 275 minecraft:cobbled_deepslate
setblock 495 79 276 minecraft:deepslate_tiles
setblock 495 79 315 minecraft:cobbled_deepslate
fill 495 79 316 495 82 316 minecraft:deepslate_tiles
setblock 496 79 314 minecraft:cobbled_deepslate
fill 496 79 315 496 82 315 minecraft:deepslate_tiles
fill 497 79 275 497 94 275 minecraft:cobbled_deepslate
fill 497 79 314 497 80 314 minecraft:deepslate_tiles
setblock 498 79 275 minecraft:white_wool
fill 499 79 275 500 94 275 minecraft:cobbled_deepslate
setblock 499 79 316 minecraft:cobbled_deepslate
setblock 500 79 316 minecraft:deepslate_tiles
setblock 501 79 278 minecraft:light[level=12]
setblock 501 79 285 minecraft:light[level=12]
setblock 501 79 292 minecraft:light[level=12]
setblock 501 79 299 minecraft:light[level=12]
setblock 501 79 306 minecraft:light[level=12]
setblock 501 79 313 minecraft:light[level=12]
setblock 508 79 278 minecraft:light[level=12]
setblock 508 79 285 minecraft:light[level=12]
setblock 508 79 292 minecraft:light[level=12]
setblock 508 79 299 minecraft:light[level=12]
setblock 508 79 306 minecraft:light[level=12]
setblock 508 79 313 minecraft:light[level=12]
setblock 509 79 287 minecraft:deepslate_tiles
setblock 509 79 290 minecraft:deepslate_tiles
setblock 509 79 291 minecraft:cobbled_deepslate
setblock 510 79 284 minecraft:deepslate_tiles
setblock 510 79 285 minecraft:cobbled_deepslate
fill 510 79 286 510 82 286 minecraft:deepslate_tiles
setblock 510 79 290 minecraft:cobbled_deepslate
fill 510 79 291 510 82 291 minecraft:deepslate_tiles
setblock 510 79 294 minecraft:deepslate_tiles
setblock 510 79 295 minecraft:cobbled_deepslate
fill 510 79 296 511 81 296 minecraft:deepslate_tiles
setblock 510 79 305 minecraft:cobbled_deepslate
fill 510 79 306 510 80 306 minecraft:deepslate_tiles
setblock 510 79 310 minecraft:cobbled_deepslate
fill 510 79 311 510 82 311 minecraft:deepslate_tiles
fill 511 79 280 511 79 283 minecraft:deepslate_tiles
setblock 511 79 284 minecraft:cobbled_deepslate
fill 511 79 285 511 82 285 minecraft:deepslate_tiles
setblock 511 79 289 minecraft:cobbled_deepslate
fill 511 79 290 511 82 290 minecraft:deepslate_tiles
setblock 511 79 294 minecraft:cobbled_deepslate
fill 511 79 295 511 82 295 minecraft:deepslate_tiles
fill 511 79 297 511 79 298 minecraft:deepslate_tiles
setblock 511 79 299 minecraft:cobbled_deepslate
fill 511 79 300 511 82 300 minecraft:deepslate_tiles
setblock 511 79 304 minecraft:cobbled_deepslate
fill 511 79 305 511 82 305 minecraft:deepslate_tiles
setblock 511 79 309 minecraft:cobbled_deepslate
fill 511 79 310 511 82 310 minecraft:deepslate_tiles
setblock 511 79 313 minecraft:deepslate_tiles
setblock 511 79 314 minecraft:cobbled_deepslate
fill 511 79 315 511 82 315 minecraft:deepslate_tiles
fill 512 79 313 512 92 313 minecraft:cobbled_deepslate
setblock 512 79 314 minecraft:white_wool
fill 471 80 276 471 80 277 minecraft:deepslate_tiles
setblock 471 80 278 minecraft:cobbled_deepslate
fill 471 80 279 471 80 282 minecraft:deepslate_tiles
setblock 471 80 283 minecraft:cobbled_deepslate
fill 471 80 284 471 80 287 minecraft:deepslate_tiles
setblock 471 80 288 minecraft:cobbled_deepslate
fill 471 80 289 471 80 292 minecraft:deepslate_tiles
setblock 471 80 293 minecraft:cobbled_deepslate
fill 471 80 294 471 80 297 minecraft:deepslate_tiles
setblock 471 80 298 minecraft:cobbled_deepslate
setblock 471 80 308 minecraft:cobbled_deepslate
fill 471 80 309 471 83 309 minecraft:deepslate_tiles
setblock 471 80 312 minecraft:deepslate_tiles
setblock 471 80 313 minecraft:cobbled_deepslate
fill 471 80 314 471 83 314 minecraft:deepslate_tiles
setblock 472 80 276 minecraft:deepslate_tiles
setblock 472 80 277 minecraft:cobbled_deepslate
fill 472 80 278 472 80 281 minecraft:deepslate_tiles
setblock 472 80 282 minecraft:cobbled_deepslate
fill 472 80 283 472 83 283 minecraft:deepslate_tiles
setblock 472 80 287 minecraft:cobbled_deepslate
fill 472 80 288 472 83 288 minecraft:deepslate_tiles
setblock 472 80 292 minecraft:cobbled_deepslate
fill 472 80 293 472 83 293 minecraft:deepslate_tiles
setblock 472 80 308 minecraft:deepslate_tiles
setblock 472 80 312 minecraft:cobbled_deepslate
fill 472 80 313 472 83 313 minecraft:deepslate_tiles
fill 472 80 315 472 80 316 minecraft:deepslate_tiles
setblock 473 80 276 minecraft:cobbled_deepslate
fill 473 80 277 475 81 277 minecraft:deepslate_tiles
setblock 473 80 282 minecraft:deepslate_tiles
setblock 473 80 286 minecraft:cobbled_deepslate
fill 473 80 287 473 83 287 minecraft:deepslate_tiles
setblock 473 80 291 minecraft:cobbled_deepslate
fill 473 80 292 473 83 292 minecraft:deepslate_tiles
setblock 473 80 315 minecraft:deepslate_tiles
setblock 473 80 316 minecraft:cobbled_deepslate
fill 474 80 276 477 80 276 minecraft:deepslate_tiles
setblock 474 80 286 minecraft:deepslate_tiles
setblock 474 80 315 minecraft:cobbled_deepslate
fill 474 80 316 474 83 316 minecraft:deepslate_tiles
fill 475 80 315 475 83 315 minecraft:deepslate_tiles
setblock 478 80 276 minecraft:cobbled_deepslate
setblock 478 80 316 minecraft:cobbled_deepslate
fill 479 80 276 479 81 276 minecraft:deepslate_tiles
fill 479 80 316 479 83 316 minecraft:deepslate_tiles
setblock 483 80 316 minecraft:cobbled_deepslate
fill 484 80 316 487 80 316 minecraft:deepslate_tiles
fill 487 80 315 488 80 315 minecraft:deepslate_tiles
setblock 488 80 316 minecraft:cobbled_deepslate
fill 489 80 276 492 80 276 minecraft:deepslate_tiles
setblock 489 80 314 minecraft:deepslate_tiles
setblock 489 80 315 minecraft:cobbled_deepslate
fill 489 80 316 492 80 316 minecraft:deepslate_tiles
setblock 490 80 314 minecraft:cobbled_deepslate
fill 490 80 315 493 80 315 minecraft:deepslate_tiles
setblock 491 80 313 minecraft:cobbled_deepslate
fill 491 80 314 491 83 314 minecraft:deepslate_tiles
fill 492 80 313 492 83 313 minecraft:deepslate_tiles
setblock 493 80 276 minecraft:cobbled_deepslate
setblock 493 80 316 minecraft:cobbled_deepslate
fill 494 80 275 494 87 275 minecraft:cobbled_deepslate
setblock 494 80 276 minecraft:deepslate_tiles
setblock 494 80 315 minecraft:cobbled_deepslate
fill 494 80 316 494 83 316 minecraft:deepslate_tiles
setblock 495 80 314 minecraft:cobbled_deepslate
fill 495 80 315 495 83 315 minecraft:deepslate_tiles
fill 496 80 314 496 82 314 minecraft:deepslate_tiles
fill 498 80 275 498 94 275 minecraft:cobbled_deepslate
setblock 498 80 316 minecraft:cobbled_deepslate
fill 499 80 316 499 81 316 minecraft:deepslate_tiles
setblock 501 80 275 minecraft:redstone_block
fill 508 80 282 510 81 282 minecraft:cobbled_deepslate
setblock 509 80 289 minecraft:deepslate_tiles
setblock 509 80 290 minecraft:cobbled_deepslate
fill 509 80 291 509 82 292 minecraft:deepslate_tiles
setblock 510 80 284 minecraft:cobbled_deepslate
fill 510 80 285 510 83 285 minecraft:deepslate_tiles
setblock 510 80 289 minecraft:cobbled_deepslate
fill 510 80 290 510 83 290 minecraft:deepslate_tiles
setblock 510 80 294 minecraft:cobbled_deepslate
fill 510 80 295 510 83 295 minecraft:deepslate_tiles
fill 510 80 297 511 80 297 minecraft:deepslate_tiles
setblock 510 80 309 minecraft:cobbled_deepslate
fill 510 80 310 510 82 310 minecraft:deepslate_tiles
fill 511 80 280 511 80 282 minecraft:deepslate_tiles
setblock 511 80 283 minecraft:cobbled_deepslate
fill 511 80 284 511 83 284 minecraft:deepslate_tiles
setblock 511 80 288 minecraft:cobbled_deepslate
fill 511 80 289 511 83 289 minecraft:deepslate_tiles
setblock 511 80 293 minecraft:cobbled_deepslate
fill 511 80 294 511 83 294 minecraft:deepslate_tiles
setblock 511 80 298 minecraft:cobbled_deepslate
fill 511 80 299 511 83 299 minecraft:deepslate_tiles
setblock 511 80 303 minecraft:cobbled_deepslate
fill 511 80 304 511 83 304 minecraft:deepslate_tiles
setblock 511 80 308 minecraft:cobbled_deepslate
fill 511 80 309 511 83 309 minecraft:deepslate_tiles
setblock 511 80 313 minecraft:cobbled_deepslate
fill 511 80 314 511 83 314 minecraft:deepslate_tiles
fill 512 80 314 512 94 314 minecraft:cobbled_deepslate
setblock 471 81 276 minecraft:deepslate_tiles
setblock 471 81 277 minecraft:cobbled_deepslate
fill 471 81 278 471 81 281 minecraft:deepslate_tiles
setblock 471 81 282 minecraft:cobbled_deepslate
fill 471 81 283 471 81 286 minecraft:deepslate_tiles
setblock 471 81 287 minecraft:cobbled_deepslate
fill 471 81 288 471 81 291 minecraft:deepslate_tiles
setblock 471 81 292 minecraft:cobbled_deepslate
fill 471 81 293 471 81 296 minecraft:deepslate_tiles
setblock 471 81 297 minecraft:cobbled_deepslate
fill 471 81 298 471 84 298 minecraft:deepslate_tiles
fill 471 81 302 472 82 302 minecraft:cobbled_deepslate
setblock 471 81 307 minecraft:cobbled_deepslate
fill 471 81 308 471 84 308 minecraft:deepslate_tiles
setblock 471 81 312 minecraft:cobbled_deepslate
fill 471 81 313 471 84 313 minecraft:deepslate_tiles
setblock 472 81 276 minecraft:cobbled_deepslate
fill 472 81 277 472 81 280 minecraft:deepslate_tiles
setblock 472 81 281 minecraft:cobbled_deepslate
fill 472 81 282 472 84 282 minecraft:deepslate_tiles
setblock 472 81 286 minecraft:cobbled_deepslate
fill 472 81 287 472 84 287 minecraft:deepslate_tiles
setblock 472 81 291 minecraft:cobbled_deepslate
fill 472 81 292 472 84 292 minecraft:deepslate_tiles
fill 472 81 298 472 82 298 minecraft:cobbled_deepslate
fill 472 81 306 475 82 306 minecraft:cobbled_deepslate
setblock 472 81 311 minecraft:cobbled_deepslate
fill 472 81 312 472 84 312 minecraft:deepslate_tiles
setblock 472 81 315 minecraft:deepslate_tiles
setblock 472 81 316 minecraft:cobbled_deepslate
fill 473 81 276 476 81 276 minecraft:deepslate_tiles
fill 473 81 278 510 81 278 minecraft:cobbled_deepslate
fill 473 81 282 507 81 282 minecraft:cobbled_deepslate
setblock 473 81 285 minecraft:cobbled_deepslate
fill 473 81 286 473 82 286 minecraft:deepslate_tiles
fill 473 81 290 474 81 290 minecraft:cobbled_deepslate
fill 473 81 291 473 84 291 minecraft:deepslate_tiles
fill 473 81 294 479 81 294 minecraft:cobbled_deepslate
fill 473 81 310 509 81 310 minecraft:cobbled_deepslate
fill 473 81 314 473 81 315 minecraft:cobbled_deepslate
fill 473 81 316 473 84 316 minecraft:deepslate_tiles
fill 474 81 314 487 81 314 minecraft:cobbled_deepslate
fill 474 81 315 474 84 315 minecraft:deepslate_tiles
setblock 477 81 276 minecraft:cobbled_deepslate
setblock 477 81 316 minecraft:cobbled_deepslate
fill 478 81 276 478 84 276 minecraft:deepslate_tiles
fill 478 81 316 478 84 316 minecraft:deepslate_tiles
setblock 482 81 316 minecraft:cobbled_deepslate
fill 483 81 316 486 81 316 minecraft:deepslate_tiles
fill 486 81 294 509 81 294 minecraft:cobbled_deepslate
fill 486 81 315 487 81 315 minecraft:deepslate_tiles
setblock 487 81 316 minecraft:cobbled_deepslate
setblock 488 81 314 minecraft:deepslate_tiles
setblock 488 81 315 minecraft:cobbled_deepslate
fill 488 81 316 491 81 316 minecraft:deepslate_tiles
fill 489 81 276 491 81 276 minecraft:deepslate_tiles
setblock 489 81 314 minecraft:cobbled_deepslate
fill 489 81 315 492 81 315 minecraft:deepslate_tiles
fill 490 81 314 490 84 314 minecraft:deepslate_tiles
fill 491 81 313 491 84 313 minecraft:deepslate_tiles
setblock 492 81 276 minecraft:cobbled_deepslate
setblock 492 81 316 minecraft:cobbled_deepslate
fill 493 81 276 493 84 276 minecraft:deepslate_tiles
setblock 493 81 315 minecraft:cobbled_deepslate
fill 493 81 316 493 84 316 minecraft:deepslate_tiles
setblock 494 81 314 minecraft:cobbled_deepslate
fill 494 81 315 494 84 315 minecraft:deepslate_tiles
fill 495 81 314 495 84 314 minecraft:deepslate_tiles
fill 497 81 314 510 81 314 minecraft:cobbled_deepslate
setblock 497 81 316 minecraft:cobbled_deepslate
fill 498 81 316 498 84 316 minecraft:deepslate_tiles
fill 501 81 275 501 94 275 minecraft:cobbled_deepslate
setblock 509 81 289 minecraft:cobbled_deepslate
fill 509 81 290 509 84 290 minecraft:deepslate_tiles
setblock 509 81 293 minecraft:deepslate_tiles
fill 509 81 308 509 83 308 minecraft:black_concrete
fill 510 81 284 510 84 284 minecraft:deepslate_tiles
setblock 510 81 288 minecraft:cobbled_deepslate
fill 510 81 289 510 84 289 minecraft:deepslate_tiles
setblock 510 81 293 minecraft:cobbled_deepslate
fill 510 81 294 510 84 294 minecraft:deepslate_tiles
setblock 510 81 297 minecraft:deepslate_tiles
setblock 510 81 308 minecraft:cobbled_deepslate
setblock 510 81 309 minecraft:deepslate_tiles
setblock 511 81 281 minecraft:deepslate_tiles
setblock 511 81 282 minecraft:cobbled_deepslate
fill 511 81 283 511 84 283 minecraft:deepslate_tiles
setblock 511 81 287 minecraft:cobbled_deepslate
fill 511 81 288 511 84 288 minecraft:deepslate_tiles
setblock 511 81 292 minecraft:cobbled_deepslate
fill 511 81 293 511 84 293 minecraft:deepslate_tiles
setblock 511 81 297 minecraft:cobbled_deepslate
fill 511 81 298 511 84 298 minecraft:deepslate_tiles
setblock 511 81 302 minecraft:cobbled_deepslate
fill 511 81 303 511 84 303 minecraft:deepslate_tiles
setblock 511 81 307 minecraft:cobbled_deepslate
fill 511 81 308 511 84 308 minecraft:deepslate_tiles
setblock 511 81 312 minecraft:cobbled_deepslate
fill 511 81 313 511 84 313 minecraft:deepslate_tiles
setblock 511 81 316 minecraft:deepslate_tiles
fill 470 82 296 471 82 296 minecraft:cobbled_deepslate
setblock 470 82 297 minecraft:white_wool
setblock 471 82 276 minecraft:cobbled_deepslate
fill 471 82 277 471 82 280 minecraft:deepslate_tiles
setblock 471 82 281 minecraft:cobbled_deepslate
fill 471 82 282 471 82 285 minecraft:deepslate_tiles
setblock 471 82 286 minecraft:cobbled_deepslate
fill 471 82 287 471 82 290 minecraft:deepslate_tiles
setblock 471 82 291 minecraft:cobbled_deepslate
fill 471 82 292 471 82 295 minecraft:deepslate_tiles
fill 471 82 297 471 85 297 minecraft:deepslate_tiles
setblock 471 82 306 minecraft:cobbled_deepslate
setblock 471 82 307 minecraft:deepslate_tiles
setblock 471 82 311 minecraft:cobbled_deepslate
fill 471 82 312 471 85 312 minecraft:deepslate_tiles
setblock 471 82 315 minecraft:deepslate_tiles
setblock 471 82 316 minecraft:cobbled_deepslate
fill 472 82 276 472 82 279 minecraft:deepslate_tiles
setblock 472 82 280 minecraft:cobbled_deepslate
fill 472 82 281 472 85 281 minecraft:deepslate_tiles
setblock 472 82 285 minecraft:cobbled_deepslate
fill 472 82 286 472 85 286 minecraft:deepslate_tiles
setblock 472 82 290 minecraft:cobbled_deepslate
fill 472 82 291 472 85 291 minecraft:deepslate_tiles
setblock 472 82 295 minecraft:cobbled_deepslate
fill 472 82 310 474 82 310 minecraft:cobbled_deepslate
fill 472 82 311 472 85 311 minecraft:deepslate_tiles
setblock 472 82 315 minecraft:cobbled_deepslate
fill 472 82 316 472 85 316 minecraft:deepslate_tiles
setblock 473 82 275 minecraft:white_wool
fill 473 82 276 474 82 277 minecraft:deepslate_tiles
setblock 473 82 285 minecraft:deepslate_tiles
setblock 473 82 289 minecraft:cobbled_deepslate
fill 473 82 290 473 85 290 minecraft:deepslate_tiles
fill 473 82 298 479 82 298 minecraft:cobbled_deepslate
fill 473 82 302 510 82 302 minecraft:cobbled_deepslate
setblock 473 82 314 minecraft:cobbled_deepslate
fill 473 82 315 473 85 315 minecraft:deepslate_tiles
fill 474 82 286 509 82 286 minecraft:cobbled_deepslate
fill 474 82 290 508 82 290 minecraft:cobbled_deepslate
setblock 475 82 276 minecraft:deepslate_tiles
setblock 476 82 276 minecraft:cobbled_deepslate
fill 476 82 306 511 82 306 minecraft:cobbled_deepslate
setblock 476 82 316 minecraft:cobbled_deepslate
fill 477 82 276 477 85 276 minecraft:deepslate_tiles
setblock 477 82 315 minecraft:cobbled_deepslate
fill 477 82 316 477 85 316 minecraft:deepslate_tiles
setblock 481 82 316 minecraft:cobbled_deepslate
fill 482 82 316 485 82 316 minecraft:deepslate_tiles
fill 485 82 315 486 82 315 minecraft:deepslate_tiles
fill 486 82 298 509 82 298 minecraft:cobbled_deepslate
setblock 486 82 316 minecraft:cobbled_deepslate
setblock 487 82 314 minecraft:deepslate_tiles
setblock 487 82 315 minecraft:cobbled_deepslate
fill 487 82 316 490 82 316 minecraft:deepslate_tiles
setblock 488 82 275 minecraft:redstone_block
fill 488 82 276 490 82 276 minecraft:deepslate_tiles
setblock 488 82 314 minecraft:cobbled_deepslate
fill 488 82 315 491 82 315 minecraft:deepslate_tiles
fill 489 82 275 489 84 275 minecraft:cobbled_deepslate
fill 489 82 314 489 85 314 minecraft:deepslate_tiles
fill 490 82 313 490 85 313 minecraft:deepslate_tiles
setblock 491 82 276 minecraft:cobbled_deepslate
setblock 491 82 316 minecraft:cobbled_deepslate
fill 492 82 276 492 85 276 minecraft:deepslate_tiles
setblock 492 82 315 minecraft:cobbled_deepslate
fill 492 82 316 492 85 316 minecraft:deepslate_tiles
setblock 493 82 314 minecraft:cobbled_deepslate
fill 493 82 315 493 85 315 minecraft:deepslate_tiles
fill 494 82 314 494 85 314 minecraft:deepslate_tiles
setblock 496 82 316 minecraft:cobbled_deepslate
setblock 497 82 315 minecraft:cobbled_deepslate
fill 497 82 316 497 85 316 minecraft:deepslate_tiles
fill 501 82 307 501 82 315 minecraft:white_wool
fill 505 82 312 505 82 315 minecraft:white_wool
setblock 509 82 288 minecraft:cobbled_deepslate
fill 509 82 289 509 85 289 minecraft:deepslate_tiles
setblock 509 82 293 minecraft:cobbled_deepslate
fill 509 82 294 509 85 294 minecraft:deepslate_tiles
fill 509 82 310 509 101 310 minecraft:white_wool
setblock 510 82 287 minecraft:cobbled_deepslate
fill 510 82 288 510 85 288 minecraft:deepslate_tiles
setblock 510 82 292 minecraft:cobbled_deepslate
fill 510 82 293 510 85 293 minecraft:deepslate_tiles
setblock 510 82 296 minecraft:deepslate_tiles
setblock 510 82 297 minecraft:cobbled_deepslate
fill 510 82 298 510 85 298 minecraft:deepslate_tiles
setblock 510 82 312 minecraft:cobbled_deepslate
setblock 510 82 316 minecraft:deepslate_tiles
setblock 511 82 280 minecraft:deepslate_tiles
setblock 511 82 281 minecraft:cobbled_deepslate
fill 511 82 282 511 85 282 minecraft:deepslate_tiles
setblock 511 82 286 minecraft:cobbled_deepslate
fill 511 82 287 511 85 287 minecraft:deepslate_tiles
setblock 511 82 291 minecraft:cobbled_deepslate
fill 511 82 292 511 85 292 minecraft:deepslate_tiles
setblock 511 82 296 minecraft:cobbled_deepslate
fill 511 82 297 511 85 297 minecraft:deepslate_tiles
setblock 511 82 301 minecraft:cobbled_deepslate
fill 511 82 302 511 85 302 minecraft:deepslate_tiles
fill 511 82 307 511 85 307 minecraft:deepslate_tiles
setblock 511 82 311 minecraft:cobbled_deepslate
fill 511 82 312 511 85 312 minecraft:deepslate_tiles
setblock 511 82 316 minecraft:cobbled_deepslate
fill 470 83 296 470 94 297 minecraft:cobbled_deepslate
fill 471 83 276 471 83 279 minecraft:deepslate_tiles
setblock 471 83 280 minecraft:cobbled_deepslate
fill 471 83 281 471 83 284 minecraft:deepslate_tiles
setblock 471 83 285 minecraft:cobbled_deepslate
fill 471 83 286 471 83 289 minecraft:deepslate_tiles
setblock 471 83 290 minecraft:cobbled_deepslate
fill 471 83 291 471 83 294 minecraft:deepslate_tiles
setblock 471 83 295 minecraft:cobbled_deepslate
fill 471 83 296 471 86 296 minecraft:deepslate_tiles
setblock 471 83 310 minecraft:cobbled_deepslate
fill 471 83 311 471 86 311 minecraft:deepslate_tiles
setblock 471 83 315 minecraft:cobbled_deepslate
fill 471 83 316 471 86 316 minecraft:deepslate_tiles
fill 472 83 276 472 83 278 minecraft:deepslate_tiles
setblock 472 83 279 minecraft:cobbled_deepslate
fill 472 83 280 472 86 280 minecraft:deepslate_tiles
setblock 472 83 284 minecraft:cobbled_deepslate
fill 472 83 285 472 86 285 minecraft:deepslate_tiles
setblock 472 83 289 minecraft:cobbled_deepslate
fill 472 83 290 472 86 290 minecraft:deepslate_tiles
setblock 472 83 294 minecraft:cobbled_deepslate
fill 472 83 295 472 86 295 minecraft:deepslate_tiles
setblock 472 83 314 minecraft:cobbled_deepslate
fill 472 83 315 472 86 315 minecraft:deepslate_tiles
fill 473 83 275 473 94 275 minecraft:cobbled_deepslate
fill 473 83 276 473 83 277 minecraft:deepslate_tiles
fill 473 83 278 473 84 286 minecraft:white_wool
setblock 473 83 288 minecraft:cobbled_deepslate
fill 473 83 289 473 84 289 minecraft:deepslate_tiles
fill 473 83 293 473 83 314 minecraft:white_wool
setblock 474 83 276 minecraft:deepslate_tiles
setblock 474 83 277 minecraft:cobbled_deepslate
setblock 475 83 276 minecraft:cobbled_deepslate
setblock 475 83 316 minecraft:cobbled_deepslate
fill 476 83 276 476 86 276 minecraft:deepslate_tiles
setblock 476 83 315 minecraft:cobbled_deepslate
fill 476 83 316 476 86 316 minecraft:deepslate_tiles
fill 477 83 315 477 86 315 minecraft:deepslate_tiles
setblock 479 83 276 minecraft:deepslate_tiles
setblock 480 83 316 minecraft:cobbled_deepslate
fill 481 83 276 481 83 292 minecraft:white_wool
fill 481 83 300 481 83 315 minecraft:white_wool
fill 481 83 316 484 83 316 minecraft:deepslate_tiles
fill 484 83 315 485 83 315 minecraft:deepslate_tiles
fill 485 83 276 485 83 293 minecraft:white_wool
fill 485 83 299 485 83 314 minecraft:white_wool
setblock 485 83 316 minecraft:cobbled_deepslate
setblock 486 83 315 minecraft:cobbled_deepslate
fill 486 83 316 489 83 316 minecraft:deepslate_tiles
fill 487 83 276 489 83 276 minecraft:deepslate_tiles
setblock 487 83 314 minecraft:cobbled_deepslate
fill 487 83 315 490 83 315 minecraft:deepslate_tiles
fill 488 83 275 488 94 275 minecraft:cobbled_deepslate
fill 488 83 314 488 86 314 minecraft:deepslate_tiles
fill 489 83 277 489 84 277 minecraft:white_wool
fill 489 83 313 489 86 313 minecraft:deepslate_tiles
setblock 490 83 276 minecraft:cobbled_deepslate
setblock 490 83 316 minecraft:cobbled_deepslate
fill 491 83 276 491 86 276 minecraft:deepslate_tiles
setblock 491 83 315 minecraft:cobbled_deepslate
fill 491 83 316 491 86 316 minecraft:deepslate_tiles
setblock 492 83 314 minecraft:cobbled_deepslate
fill 492 83 315 492 86 315 minecraft:deepslate_tiles
fill 493 83 277 493 83 312 minecraft:white_wool
setblock 493 83 313 minecraft:cobbled_deepslate
fill 493 83 314 493 86 314 minecraft:deepslate_tiles
setblock 495 83 316 minecraft:cobbled_deepslate
setblock 496 83 315 minecraft:cobbled_deepslate
fill 496 83 316 496 86 316 minecraft:deepslate_tiles
fill 497 83 276 497 84 314 minecraft:white_wool
fill 497 83 315 497 86 315 minecraft:deepslate_tiles
fill 501 83 276 501 83 309 minecraft:white_wool
fill 505 83 276 505 83 314 minecraft:white_wool
fill 508 83 277 508 85 277 minecraft:black_concrete
fill 508 83 316 509 83 316 minecraft:deepslate_tiles
fill 509 83 276 509 83 277 minecraft:white_wool
fill 509 83 288 509 86 288 minecraft:deepslate_tiles
setblock 509 83 291 minecraft:deepslate_tiles
setblock 509 83 292 minecraft:cobbled_deepslate
fill 509 83 293 509 86 293 minecraft:deepslate_tiles
fill 509 83 295 509 84 295 minecraft:deepslate_tiles
setblock 510 83 276 minecraft:cobbled_deepslate
setblock 510 83 286 minecraft:cobbled_deepslate
fill 510 83 287 510 86 287 minecraft:deepslate_tiles
setblock 510 83 291 minecraft:cobbled_deepslate
fill 510 83 292 510 86 292 minecraft:deepslate_tiles
setblock 510 83 296 minecraft:cobbled_deepslate
fill 510 83 297 510 86 297 minecraft:deepslate_tiles
setblock 510 83 311 minecraft:cobbled_deepslate
fill 510 83 312 510 85 313 minecraft:deepslate_tiles
setblock 510 83 316 minecraft:cobbled_deepslate
fill 511 83 276 511 83 279 minecraft:deepslate_tiles
setblock 511 83 280 minecraft:cobbled_deepslate
fill 511 83 281 511 86 281 minecraft:deepslate_tiles
setblock 511 83 285 minecraft:cobbled_deepslate
fill 511 83 286 511 86 286 minecraft:deepslate_tiles
setblock 511 83 290 minecraft:cobbled_deepslate
fill 511 83 291 511 86 291 minecraft:deepslate_tiles
setblock 511 83 295 minecraft:cobbled_deepslate
fill 511 83 296 511 86 296 minecraft:deepslate_tiles
setblock 511 83 300 minecraft:cobbled_deepslate
fill 511 83 301 511 86 301 minecraft:deepslate_tiles
setblock 511 83 305 minecraft:cobbled_deepslate
fill 511 83 306 511 86 306 minecraft:deepslate_tiles
setblock 511 83 310 minecraft:cobbled_deepslate
fill 511 83 311 511 86 311 minecraft:deepslate_tiles
setblock 511 83 315 minecraft:cobbled_deepslate
fill 511 83 316 511 86 316 minecraft:deepslate_tiles
fill 471 84 276 471 84 278 minecraft:deepslate_tiles
setblock 471 84 279 minecraft:cobbled_deepslate
fill 471 84 280 471 84 283 minecraft:deepslate_tiles
setblock 471 84 284 minecraft:cobbled_deepslate
fill 471 84 285 471 84 288 minecraft:deepslate_tiles
setblock 471 84 289 minecraft:cobbled_deepslate
fill 471 84 290 471 84 293 minecraft:deepslate_tiles
setblock 471 84 294 minecraft:cobbled_deepslate
fill 471 84 295 471 87 295 minecraft:deepslate_tiles
setblock 471 84 299 minecraft:cobbled_deepslate
setblock 471 84 309 minecraft:cobbled_deepslate
fill 471 84 310 471 87 310 minecraft:deepslate_tiles
setblock 471 84 314 minecraft:cobbled_deepslate
fill 471 84 315 471 87 315 minecraft:deepslate_tiles
fill 472 84 276 472 84 277 minecraft:deepslate_tiles
setblock 472 84 278 minecraft:cobbled_deepslate
fill 472 84 279 472 87 279 minecraft:deepslate_tiles
setblock 472 84 283 minecraft:cobbled_deepslate
fill 472 84 284 472 87 284 minecraft:deepslate_tiles
setblock 472 84 288 minecraft:cobbled_deepslate
fill 472 84 289 472 87 289 minecraft:deepslate_tiles
setblock 472 84 293 minecraft:cobbled_deepslate
fill 472 84 294 472 87 294 minecraft:deepslate_tiles
fill 472 84 296 472 85 296 minecraft:deepslate_tiles
setblock 472 84 313 minecraft:cobbled_deepslate
fill 472 84 314 472 87 314 minecraft:deepslate_tiles
setblock 473 84 276 minecraft:deepslate_tiles
setblock 473 84 277 minecraft:cobbled_deepslate
setblock 473 84 287 minecraft:white_wool
setblock 473 84 288 minecraft:deepslate_tiles
setblock 473 84 292 minecraft:cobbled_deepslate
fill 473 84 293 473 84 302 minecraft:white_wool
setblock 474 84 276 minecraft:cobbled_deepslate
fill 474 84 277 475 86 277 minecraft:deepslate_tiles
setblock 474 84 316 minecraft:cobbled_deepslate
fill 475 84 276 475 87 276 minecraft:deepslate_tiles
setblock 475 84 315 minecraft:cobbled_deepslate
fill 475 84 316 475 87 316 minecraft:deepslate_tiles
fill 476 84 315 476 87 315 minecraft:deepslate_tiles
fill 477 84 277 477 84 304 minecraft:white_wool
fill 478 84 315 478 85 315 minecraft:deepslate_tiles
setblock 479 84 276 minecraft:cobbled_deepslate
setblock 479 84 316 minecraft:cobbled_deepslate
fill 480 84 316 483 84 316 minecraft:deepslate_tiles
fill 481 84 276 481 84 290 minecraft:white_wool
fill 482 84 315 484 84 315 minecraft:deepslate_tiles
setblock 484 84 276 minecraft:cobbled_deepslate
setblock 484 84 316 minecraft:cobbled_deepslate
fill 485 84 276 488 84 276 minecraft:deepslate_tiles
fill 485 84 277 485 84 278 minecraft:white_wool
setblock 485 84 310 minecraft:white_wool
setblock 485 84 315 minecraft:cobbled_deepslate
fill 485 84 316 488 84 316 minecraft:deepslate_tiles
setblock 486 84 314 minecraft:cobbled_deepslate
fill 486 84 315 489 84 315 minecraft:deepslate_tiles
fill 487 84 314 487 87 314 minecraft:deepslate_tiles
setblock 489 84 276 minecraft:cobbled_deepslate
fill 489 84 278 489 84 312 minecraft:white_wool
setblock 489 84 316 minecraft:cobbled_deepslate
fill 490 84 276 490 87 276 minecraft:deepslate_tiles
setblock 490 84 315 minecraft:cobbled_deepslate
fill 490 84 316 490 87 316 minecraft:deepslate_tiles
setblock 491 84 314 minecraft:cobbled_deepslate
fill 491 84 315 491 87 315 minecraft:deepslate_tiles
setblock 492 84 313 minecraft:cobbled_deepslate
fill 492 84 314 492 87 314 minecraft:deepslate_tiles
fill 493 84 277 493 84 289 minecraft:white_wool
fill 493 84 313 493 85 313 minecraft:deepslate_tiles
setblock 494 84 276 minecraft:cobbled_deepslate
setblock 494 84 316 minecraft:cobbled_deepslate
setblock 495 84 315 minecraft:cobbled_deepslate
fill 495 84 316 495 87 316 minecraft:deepslate_tiles
setblock 496 84 275 minecraft:redstone_block
fill 496 84 315 496 87 315 minecraft:deepslate_tiles
fill 501 84 276 501 84 277 minecraft:white_wool
fill 505 84 276 505 84 277 minecraft:white_wool
fill 507 84 316 508 84 316 minecraft:deepslate_tiles
setblock 509 84 276 minecraft:cobbled_deepslate
fill 509 84 277 509 84 286 minecraft:white_wool
fill 509 84 287 509 87 287 minecraft:deepslate_tiles
setblock 509 84 291 minecraft:cobbled_deepslate
fill 509 84 292 509 87 292 minecraft:deepslate_tiles
setblock 509 84 296 minecraft:cobbled_deepslate
fill 509 84 297 509 84 309 minecraft:white_wool
fill 509 84 311 509 85 312 minecraft:white_wool
setblock 509 84 316 minecraft:cobbled_deepslate
fill 510 84 276 511 86 276 minecraft:deepslate_tiles
setblock 510 84 285 minecraft:cobbled_deepslate
fill 510 84 286 510 87 286 minecraft:deepslate_tiles
setblock 510 84 290 minecraft:cobbled_deepslate
fill 510 84 291 510 87 291 minecraft:deepslate_tiles
setblock 510 84 295 minecraft:cobbled_deepslate
fill 510 84 296 510 87 296 minecraft:deepslate_tiles
setblock 510 84 299 minecraft:deepslate_tiles
fill 510 84 311 510 87 311 minecraft:deepslate_tiles
setblock 510 84 314 minecraft:deepslate_tiles
setblock 510 84 315 minecraft:cobbled_deepslate
fill 510 84 316 510 87 316 minecraft:deepslate_tiles
fill 511 84 277 511 84 278 minecraft:deepslate_tiles
setblock 511 84 279 minecraft:cobbled_deepslate
fill 511 84 280 511 87 280 minecraft:deepslate_tiles
setblock 511 84 284 minecraft:cobbled_deepslate
fill 511 84 285 511 87 285 minecraft:deepslate_tiles
setblock 511 84 289 minecraft:cobbled_deepslate
fill 511 84 290 511 87 290 minecraft:deepslate_tiles
setblock 511 84 294 minecraft:cobbled_deepslate
fill 511 84 295 511 87 295 minecraft:deepslate_tiles
setblock 511 84 299 minecraft:cobbled_deepslate
fill 511 84 300 511 87 300 minecraft:deepslate_tiles
setblock 511 84 304 minecraft:cobbled_deepslate
fill 511 84 305 511 87 305 minecraft:deepslate_tiles
setblock 511 84 309 minecraft:cobbled_deepslate
fill 511 84 310 511 87 310 minecraft:deepslate_tiles
setblock 511 84 314 minecraft:cobbled_deepslate
fill 511 84 315 511 87 315 minecraft:deepslate_tiles
fill 471 85 276 471 85 277 minecraft:deepslate_tiles
setblock 471 85 278 minecraft:cobbled_deepslate
fill 471 85 279 471 85 282 minecraft:deepslate_tiles
setblock 471 85 283 minecraft:cobbled_deepslate
fill 471 85 284 471 85 287 minecraft:deepslate_tiles
setblock 471 85 288 minecraft:cobbled_deepslate
fill 471 85 289 471 85 292 minecraft:deepslate_tiles
setblock 471 85 293 minecraft:cobbled_deepslate
fill 471 85 294 471 88 294 minecraft:deepslate_tiles
setblock 471 85 298 minecraft:cobbled_deepslate
fill 471 85 299 471 88 299 minecraft:deepslate_tiles
setblock 471 85 308 minecraft:cobbled_deepslate
fill 471 85 309 471 88 309 minecraft:deepslate_tiles
setblock 471 85 313 minecraft:cobbled_deepslate
fill 471 85 314 471 88 314 minecraft:deepslate_tiles
setblock 472 85 276 minecraft:deepslate_tiles
setblock 472 85 277 minecraft:cobbled_deepslate
fill 472 85 278 472 88 278 minecraft:deepslate_tiles
setblock 472 85 282 minecraft:cobbled_deepslate
fill 472 85 283 472 88 283 minecraft:deepslate_tiles
setblock 472 85 287 minecraft:cobbled_deepslate
fill 472 85 288 472 88 288 minecraft:deepslate_tiles
setblock 472 85 292 minecraft:cobbled_deepslate
fill 472 85 293 472 88 293 minecraft:deepslate_tiles
setblock 472 85 312 minecraft:cobbled_deepslate
fill 472 85 313 472 88 313 minecraft:deepslate_tiles
setblock 473 85 276 minecraft:cobbled_deepslate
fill 473 85 277 473 88 277 minecraft:deepslate_tiles
setblock 473 85 278 minecraft:light[level=13]
setblock 473 85 285 minecraft:light[level=12]
schedule function dropper:buildpart/70_4 1t
