fill 283 95 277 283 191 277 minecraft:iron_block
fill 283 95 287 283 191 287 minecraft:iron_block
fill 283 95 297 283 191 297 minecraft:iron_block
fill 283 95 307 283 191 307 minecraft:iron_block
fill 283 95 317 322 95 317 minecraft:iron_block
fill 284 95 316 284 191 316 minecraft:iron_block
fill 285 95 282 287 191 284 minecraft:iron_block
fill 285 95 309 287 191 311 minecraft:iron_block
setblock 286 95 278 minecraft:gray_concrete
fill 286 95 279 289 191 279 minecraft:iron_block
fill 286 95 280 286 95 281 minecraft:gray_concrete
fill 287 95 277 288 95 277 minecraft:gray_concrete
fill 287 95 278 288 191 278 minecraft:iron_block
fill 287 95 280 289 191 280 minecraft:iron_block
setblock 287 95 281 minecraft:gray_concrete
fill 288 95 281 288 191 281 minecraft:iron_block
fill 288 95 312 290 191 312 minecraft:iron_block
setblock 289 95 278 minecraft:gray_concrete
setblock 289 95 281 minecraft:gray_concrete
fill 289 95 311 289 191 311 minecraft:iron_block
fill 289 95 313 304 96 313 minecraft:iron_block
fill 290 95 276 290 191 276 minecraft:iron_block
fill 290 95 279 290 95 280 minecraft:gray_concrete
fill 290 95 314 290 191 314 minecraft:iron_block
fill 292 95 311 304 96 312 minecraft:iron_block
fill 292 95 314 304 96 316 minecraft:iron_block
fill 300 95 276 300 191 276 minecraft:iron_block
setblock 303 95 275 minecraft:sea_lantern
fill 304 95 275 324 98 275 minecraft:iron_block
fill 310 95 276 310 191 276 minecraft:iron_block
fill 314 95 316 314 191 316 minecraft:iron_block
fill 319 95 284 323 96 292 minecraft:iron_block
fill 320 95 276 320 191 276 minecraft:iron_block
fill 320 95 278 322 96 278 minecraft:iron_block
fill 323 95 283 323 191 283 minecraft:iron_block
fill 323 95 293 323 191 293 minecraft:iron_block
fill 323 95 303 323 191 303 minecraft:iron_block
fill 323 95 313 323 191 313 minecraft:iron_block
setblock 323 95 317 minecraft:redstone_block
fill 324 95 276 324 102 276 minecraft:iron_block
fill 324 95 317 324 102 317 minecraft:iron_block
setblock 283 96 278 minecraft:iron_block
setblock 283 96 288 minecraft:iron_block
setblock 283 96 298 minecraft:iron_block
setblock 283 96 308 minecraft:iron_block
fill 283 96 317 316 98 317 minecraft:iron_block
setblock 285 96 316 minecraft:iron_block
setblock 289 96 276 minecraft:iron_block
setblock 299 96 276 minecraft:iron_block
fill 303 96 275 303 100 275 minecraft:iron_block
setblock 305 96 316 minecraft:iron_block
setblock 309 96 276 minecraft:iron_block
setblock 315 96 316 minecraft:iron_block
setblock 317 96 317 minecraft:redstone_block
fill 318 96 317 323 98 317 minecraft:iron_block
setblock 319 96 276 minecraft:iron_block
setblock 323 96 282 minecraft:iron_block
setblock 323 96 302 minecraft:iron_block
setblock 323 96 312 minecraft:iron_block
fill 284 97 282 284 97 284 minecraft:iron_block
fill 284 97 309 284 97 311 minecraft:iron_block
setblock 285 97 278 minecraft:light[level=15]
fill 285 97 281 287 97 281 minecraft:iron_block
fill 285 97 285 287 97 285 minecraft:iron_block
setblock 285 97 286 minecraft:light[level=15]
setblock 285 97 292 minecraft:light[level=12]
setblock 285 97 294 minecraft:light[level=15]
setblock 285 97 299 minecraft:light[level=12]
setblock 285 97 302 minecraft:light[level=15]
setblock 285 97 306 minecraft:light[level=12]
fill 285 97 308 287 97 308 minecraft:iron_block
fill 285 97 312 287 97 312 minecraft:iron_block
setblock 285 97 313 minecraft:light[level=12]
fill 288 97 282 288 97 284 minecraft:iron_block
fill 288 97 309 288 97 311 minecraft:iron_block
fill 288 97 313 291 97 313 minecraft:iron_block
setblock 289 97 314 minecraft:iron_block
setblock 290 97 311 minecraft:iron_block
fill 291 97 312 292 97 312 minecraft:iron_block
fill 291 97 314 292 97 314 minecraft:iron_block
setblock 292 97 278 minecraft:light[level=12]
setblock 292 97 285 minecraft:light[level=12]
setblock 292 97 292 minecraft:light[level=12]
setblock 292 97 299 minecraft:light[level=12]
setblock 292 97 306 minecraft:light[level=12]
setblock 292 97 311 minecraft:pearlescent_froglight
setblock 292 97 313 minecraft:pearlescent_froglight
setblock 292 97 315 minecraft:pearlescent_froglight
fill 292 97 316 292 115 316 minecraft:iron_block
setblock 293 97 278 minecraft:light[level=15]
setblock 293 97 286 minecraft:light[level=15]
setblock 293 97 294 minecraft:light[level=15]
setblock 293 97 302 minecraft:light[level=15]
setblock 293 97 310 minecraft:light[level=15]
fill 293 97 311 293 115 311 minecraft:iron_block
setblock 293 97 312 minecraft:pearlescent_froglight
fill 293 97 313 293 115 313 minecraft:iron_block
setblock 293 97 314 minecraft:pearlescent_froglight
fill 293 97 315 293 115 315 minecraft:iron_block
setblock 293 97 316 minecraft:pearlescent_froglight
setblock 294 97 311 minecraft:pearlescent_froglight
fill 294 97 312 294 115 312 minecraft:iron_block
setblock 294 97 313 minecraft:pearlescent_froglight
fill 294 97 314 294 115 314 minecraft:iron_block
setblock 294 97 315 minecraft:pearlescent_froglight
fill 294 97 316 294 191 316 minecraft:iron_block
fill 295 97 311 295 115 311 minecraft:iron_block
setblock 295 97 312 minecraft:pearlescent_froglight
fill 295 97 313 295 115 313 minecraft:iron_block
setblock 295 97 314 minecraft:pearlescent_froglight
fill 295 97 315 295 115 315 minecraft:iron_block
setblock 295 97 316 minecraft:pearlescent_froglight
setblock 296 97 311 minecraft:pearlescent_froglight
fill 296 97 312 296 115 312 minecraft:iron_block
setblock 296 97 313 minecraft:pearlescent_froglight
fill 296 97 314 296 115 314 minecraft:iron_block
setblock 296 97 315 minecraft:pearlescent_froglight
fill 296 97 316 296 115 316 minecraft:iron_block
fill 297 97 311 297 115 311 minecraft:iron_block
setblock 297 97 312 minecraft:pearlescent_froglight
fill 297 97 313 297 115 313 minecraft:iron_block
setblock 297 97 314 minecraft:pearlescent_froglight
fill 297 97 315 297 115 315 minecraft:iron_block
setblock 297 97 316 minecraft:pearlescent_froglight
setblock 298 97 311 minecraft:pearlescent_froglight
fill 298 97 312 298 115 312 minecraft:iron_block
setblock 298 97 313 minecraft:pearlescent_froglight
fill 298 97 314 298 115 314 minecraft:iron_block
setblock 298 97 315 minecraft:pearlescent_froglight
fill 298 97 316 298 115 316 minecraft:iron_block
setblock 299 97 278 minecraft:light[level=12]
setblock 299 97 285 minecraft:light[level=12]
setblock 299 97 292 minecraft:light[level=12]
setblock 299 97 299 minecraft:light[level=12]
setblock 299 97 306 minecraft:light[level=12]
fill 299 97 311 299 115 311 minecraft:iron_block
setblock 299 97 312 minecraft:pearlescent_froglight
fill 299 97 313 299 115 313 minecraft:iron_block
setblock 299 97 314 minecraft:pearlescent_froglight
fill 299 97 315 299 115 315 minecraft:iron_block
setblock 299 97 316 minecraft:pearlescent_froglight
setblock 300 97 311 minecraft:pearlescent_froglight
fill 300 97 312 300 115 312 minecraft:iron_block
setblock 300 97 313 minecraft:pearlescent_froglight
fill 300 97 314 300 115 314 minecraft:iron_block
setblock 300 97 315 minecraft:pearlescent_froglight
fill 300 97 316 300 115 316 minecraft:iron_block
setblock 301 97 278 minecraft:light[level=15]
setblock 301 97 286 minecraft:light[level=15]
setblock 301 97 294 minecraft:light[level=15]
setblock 301 97 302 minecraft:light[level=15]
setblock 301 97 310 minecraft:light[level=15]
fill 301 97 311 301 115 311 minecraft:iron_block
setblock 301 97 312 minecraft:pearlescent_froglight
fill 301 97 313 301 115 313 minecraft:iron_block
setblock 301 97 314 minecraft:pearlescent_froglight
fill 301 97 315 301 115 315 minecraft:iron_block
setblock 301 97 316 minecraft:pearlescent_froglight
setblock 302 97 311 minecraft:pearlescent_froglight
fill 302 97 312 302 115 312 minecraft:iron_block
setblock 302 97 313 minecraft:pearlescent_froglight
fill 302 97 314 302 115 314 minecraft:iron_block
setblock 302 97 315 minecraft:pearlescent_froglight
fill 302 97 316 302 115 316 minecraft:iron_block
fill 303 97 311 303 115 311 minecraft:iron_block
setblock 303 97 312 minecraft:pearlescent_froglight
fill 303 97 313 303 115 313 minecraft:iron_block
setblock 303 97 314 minecraft:pearlescent_froglight
fill 303 97 315 303 115 315 minecraft:iron_block
setblock 303 97 316 minecraft:pearlescent_froglight
setblock 304 97 311 minecraft:pearlescent_froglight
fill 304 97 312 304 115 312 minecraft:iron_block
setblock 304 97 313 minecraft:pearlescent_froglight
fill 304 97 314 304 115 314 minecraft:iron_block
setblock 304 97 315 minecraft:pearlescent_froglight
fill 304 97 316 304 191 316 minecraft:iron_block
setblock 306 97 278 minecraft:light[level=12]
setblock 306 97 285 minecraft:light[level=12]
setblock 306 97 292 minecraft:light[level=12]
setblock 306 97 299 minecraft:light[level=12]
setblock 306 97 306 minecraft:light[level=12]
setblock 306 97 313 minecraft:light[level=12]
setblock 309 97 278 minecraft:light[level=15]
setblock 309 97 286 minecraft:light[level=15]
setblock 309 97 294 minecraft:light[level=15]
setblock 309 97 302 minecraft:light[level=15]
setblock 309 97 310 minecraft:light[level=15]
setblock 313 97 278 minecraft:light[level=12]
setblock 313 97 285 minecraft:light[level=12]
setblock 313 97 292 minecraft:light[level=12]
setblock 313 97 299 minecraft:light[level=12]
setblock 313 97 306 minecraft:light[level=12]
setblock 313 97 313 minecraft:light[level=12]
setblock 317 97 278 minecraft:light[level=15]
setblock 317 97 286 minecraft:light[level=15]
setblock 317 97 294 minecraft:light[level=15]
setblock 317 97 302 minecraft:light[level=15]
setblock 317 97 310 minecraft:light[level=15]
fill 317 97 317 317 102 317 minecraft:iron_block
setblock 319 97 284 minecraft:pearlescent_froglight
fill 319 97 285 319 121 285 minecraft:iron_block
setblock 319 97 286 minecraft:pearlescent_froglight
fill 319 97 287 319 121 287 minecraft:iron_block
setblock 319 97 288 minecraft:pearlescent_froglight
fill 319 97 289 319 121 289 minecraft:iron_block
setblock 319 97 290 minecraft:pearlescent_froglight
fill 319 97 291 319 121 291 minecraft:iron_block
setblock 319 97 292 minecraft:pearlescent_froglight
setblock 320 97 278 minecraft:light[level=12]
fill 320 97 284 320 121 284 minecraft:iron_block
setblock 320 97 285 minecraft:pearlescent_froglight
fill 320 97 286 320 121 286 minecraft:iron_block
setblock 320 97 287 minecraft:pearlescent_froglight
fill 320 97 288 320 121 288 minecraft:iron_block
setblock 320 97 289 minecraft:pearlescent_froglight
fill 320 97 290 320 121 290 minecraft:iron_block
setblock 320 97 291 minecraft:pearlescent_froglight
fill 320 97 292 320 121 292 minecraft:iron_block
setblock 320 97 299 minecraft:light[level=12]
setblock 320 97 306 minecraft:light[level=12]
setblock 320 97 313 minecraft:light[level=12]
setblock 321 97 284 minecraft:pearlescent_froglight
fill 321 97 285 321 121 285 minecraft:iron_block
setblock 321 97 286 minecraft:pearlescent_froglight
fill 321 97 287 321 121 287 minecraft:iron_block
setblock 321 97 288 minecraft:pearlescent_froglight
fill 321 97 289 321 121 289 minecraft:iron_block
setblock 321 97 290 minecraft:pearlescent_froglight
fill 321 97 291 321 121 291 minecraft:iron_block
setblock 321 97 292 minecraft:pearlescent_froglight
fill 322 97 284 322 121 284 minecraft:iron_block
setblock 322 97 285 minecraft:pearlescent_froglight
fill 322 97 286 322 121 286 minecraft:iron_block
setblock 322 97 287 minecraft:pearlescent_froglight
fill 322 97 288 322 121 288 minecraft:iron_block
setblock 322 97 289 minecraft:pearlescent_froglight
fill 322 97 290 322 121 290 minecraft:iron_block
setblock 322 97 291 minecraft:pearlescent_froglight
fill 322 97 292 322 121 292 minecraft:iron_block
setblock 323 97 284 minecraft:pearlescent_froglight
fill 323 97 285 323 121 285 minecraft:iron_block
setblock 323 97 286 minecraft:pearlescent_froglight
fill 323 97 287 323 121 287 minecraft:iron_block
setblock 323 97 288 minecraft:pearlescent_froglight
fill 323 97 289 323 121 289 minecraft:iron_block
setblock 323 97 290 minecraft:pearlescent_froglight
fill 323 97 291 323 121 291 minecraft:iron_block
setblock 323 97 292 minecraft:pearlescent_froglight
fill 289 98 313 292 99 313 minecraft:iron_block
fill 292 98 311 292 99 312 minecraft:iron_block
fill 292 98 314 292 99 315 minecraft:iron_block
fill 293 98 312 293 99 312 minecraft:iron_block
fill 293 98 314 293 99 314 minecraft:iron_block
fill 293 98 316 293 99 316 minecraft:iron_block
fill 294 98 311 294 99 311 minecraft:iron_block
fill 294 98 313 294 99 313 minecraft:iron_block
fill 294 98 315 294 99 315 minecraft:iron_block
fill 295 98 312 295 99 312 minecraft:iron_block
fill 295 98 314 295 99 314 minecraft:iron_block
fill 295 98 316 295 99 316 minecraft:iron_block
fill 296 98 311 296 99 311 minecraft:iron_block
fill 296 98 313 296 99 313 minecraft:iron_block
fill 296 98 315 296 99 315 minecraft:iron_block
fill 297 98 312 297 99 312 minecraft:iron_block
fill 297 98 314 297 99 314 minecraft:iron_block
fill 297 98 316 297 99 316 minecraft:iron_block
fill 298 98 311 298 99 311 minecraft:iron_block
fill 298 98 313 298 99 313 minecraft:iron_block
fill 298 98 315 298 99 315 minecraft:iron_block
fill 299 98 312 299 99 312 minecraft:iron_block
fill 299 98 314 299 99 314 minecraft:iron_block
fill 299 98 316 299 99 316 minecraft:iron_block
fill 300 98 311 300 99 311 minecraft:iron_block
fill 300 98 313 300 99 313 minecraft:iron_block
fill 300 98 315 300 99 315 minecraft:iron_block
fill 301 98 312 301 99 312 minecraft:iron_block
fill 301 98 314 301 99 314 minecraft:iron_block
fill 301 98 316 301 99 316 minecraft:iron_block
fill 302 98 311 302 99 311 minecraft:iron_block
fill 302 98 313 302 99 313 minecraft:iron_block
fill 302 98 315 302 99 315 minecraft:iron_block
fill 303 98 312 303 99 312 minecraft:iron_block
fill 303 98 314 303 99 314 minecraft:iron_block
fill 303 98 316 303 99 316 minecraft:iron_block
fill 304 98 311 304 99 311 minecraft:iron_block
fill 304 98 313 304 99 313 minecraft:iron_block
fill 304 98 315 304 99 315 minecraft:iron_block
fill 319 98 284 319 99 284 minecraft:iron_block
fill 319 98 286 319 99 286 minecraft:iron_block
fill 319 98 288 319 99 288 minecraft:iron_block
fill 319 98 290 319 99 290 minecraft:iron_block
fill 319 98 292 319 99 292 minecraft:iron_block
fill 320 98 285 320 99 285 minecraft:iron_block
fill 320 98 287 320 99 287 minecraft:iron_block
fill 320 98 289 320 99 289 minecraft:iron_block
fill 320 98 291 320 99 291 minecraft:iron_block
fill 321 98 284 321 99 284 minecraft:iron_block
fill 321 98 286 321 99 286 minecraft:iron_block
fill 321 98 288 321 99 288 minecraft:iron_block
fill 321 98 290 321 99 290 minecraft:iron_block
fill 321 98 292 321 99 292 minecraft:iron_block
fill 322 98 285 322 99 285 minecraft:iron_block
fill 322 98 287 322 99 287 minecraft:iron_block
fill 322 98 289 322 99 289 minecraft:iron_block
fill 322 98 291 322 99 291 minecraft:iron_block
fill 323 98 284 323 99 284 minecraft:iron_block
fill 323 98 286 323 99 286 minecraft:iron_block
fill 323 98 288 323 99 288 minecraft:iron_block
fill 323 98 290 323 99 290 minecraft:iron_block
fill 323 98 292 323 99 292 minecraft:iron_block
setblock 282 99 283 minecraft:gray_concrete
fill 282 99 284 282 102 284 minecraft:iron_block
setblock 282 99 285 minecraft:gray_concrete
fill 282 99 286 282 99 309 minecraft:iron_block
setblock 282 99 310 minecraft:gray_concrete
fill 282 99 311 282 99 314 minecraft:iron_block
setblock 282 99 315 minecraft:gray_concrete
fill 282 99 316 282 100 316 minecraft:iron_block
setblock 282 99 317 minecraft:gray_concrete
fill 283 99 275 287 100 275 minecraft:iron_block
fill 283 99 280 283 99 283 minecraft:iron_block
fill 283 99 290 283 99 293 minecraft:iron_block
fill 283 99 300 283 99 303 minecraft:iron_block
fill 283 99 310 283 99 313 minecraft:iron_block
fill 283 99 317 283 102 317 minecraft:iron_block
fill 284 99 276 287 99 276 minecraft:iron_block
setblock 284 99 317 minecraft:gray_concrete
fill 285 99 317 297 99 317 minecraft:iron_block
fill 287 99 316 290 99 316 minecraft:iron_block
setblock 288 99 275 minecraft:gray_concrete
fill 289 99 275 289 100 275 minecraft:iron_block
setblock 290 99 275 minecraft:gray_concrete
fill 291 99 275 302 99 275 minecraft:iron_block
fill 294 99 276 297 99 276 minecraft:iron_block
setblock 298 99 317 minecraft:gray_concrete
fill 299 99 317 306 100 317 minecraft:iron_block
fill 304 99 275 307 99 276 minecraft:iron_block
fill 307 99 316 310 99 316 minecraft:iron_block
setblock 307 99 317 minecraft:gray_concrete
fill 308 99 275 317 100 275 minecraft:iron_block
fill 308 99 317 316 99 317 minecraft:iron_block
fill 314 99 276 317 99 276 minecraft:iron_block
fill 317 99 316 320 99 316 minecraft:iron_block
setblock 318 99 275 minecraft:gray_concrete
fill 318 99 317 320 102 317 minecraft:iron_block
fill 319 99 275 320 102 275 minecraft:iron_block
setblock 321 99 275 minecraft:gray_concrete
setblock 321 99 317 minecraft:redstone_block
fill 322 99 275 324 99 275 minecraft:iron_block
setblock 322 99 317 minecraft:gray_concrete
fill 323 99 277 324 99 280 minecraft:iron_block
fill 323 99 297 324 99 300 minecraft:iron_block
fill 323 99 307 324 99 310 minecraft:iron_block
fill 323 99 317 323 100 317 minecraft:iron_block
fill 324 99 281 324 99 287 minecraft:iron_block
setblock 324 99 288 minecraft:gray_concrete
fill 324 99 289 324 102 291 minecraft:iron_block
setblock 324 99 292 minecraft:gray_concrete
fill 324 99 293 324 99 296 minecraft:iron_block
fill 324 99 301 324 99 305 minecraft:iron_block
setblock 324 99 306 minecraft:gray_concrete
fill 324 99 311 324 100 316 minecraft:iron_block
fill 282 100 275 282 102 277 minecraft:iron_block
setblock 282 100 278 minecraft:gray_concrete
fill 282 100 279 282 102 283 minecraft:iron_block
fill 282 100 285 282 100 302 minecraft:iron_block
setblock 282 100 303 minecraft:gray_concrete
fill 282 100 304 282 102 313 minecraft:iron_block
setblock 282 100 314 minecraft:gray_concrete
fill 282 100 315 282 102 315 minecraft:iron_block
fill 282 100 317 282 102 317 minecraft:iron_block
fill 284 100 317 295 100 317 minecraft:iron_block
fill 288 100 275 288 102 275 minecraft:iron_block
fill 289 100 313 291 191 313 minecraft:iron_block
fill 290 100 275 290 103 275 minecraft:iron_block
setblock 291 100 275 minecraft:gray_concrete
fill 292 100 275 297 102 275 minecraft:iron_block
setblock 292 100 311 minecraft:pearlescent_froglight
fill 292 100 312 292 115 312 minecraft:iron_block
setblock 292 100 313 minecraft:pearlescent_froglight
fill 292 100 314 292 115 314 minecraft:iron_block
setblock 292 100 315 minecraft:pearlescent_froglight
setblock 293 100 312 minecraft:pearlescent_froglight
setblock 293 100 314 minecraft:pearlescent_froglight
setblock 293 100 316 minecraft:pearlescent_froglight
setblock 294 100 311 minecraft:pearlescent_froglight
setblock 294 100 313 minecraft:pearlescent_froglight
setblock 294 100 315 minecraft:pearlescent_froglight
setblock 295 100 312 minecraft:pearlescent_froglight
setblock 295 100 314 minecraft:pearlescent_froglight
setblock 295 100 316 minecraft:pearlescent_froglight
setblock 296 100 311 minecraft:pearlescent_froglight
setblock 296 100 313 minecraft:pearlescent_froglight
setblock 296 100 315 minecraft:pearlescent_froglight
setblock 296 100 317 minecraft:gray_concrete
setblock 297 100 312 minecraft:pearlescent_froglight
setblock 297 100 314 minecraft:pearlescent_froglight
setblock 297 100 316 minecraft:pearlescent_froglight
fill 297 100 317 298 100 317 minecraft:iron_block
setblock 298 100 275 minecraft:gray_concrete
setblock 298 100 311 minecraft:pearlescent_froglight
setblock 298 100 313 minecraft:pearlescent_froglight
setblock 298 100 315 minecraft:pearlescent_froglight
fill 299 100 275 301 100 275 minecraft:iron_block
setblock 299 100 312 minecraft:pearlescent_froglight
setblock 299 100 314 minecraft:pearlescent_froglight
setblock 299 100 316 minecraft:pearlescent_froglight
setblock 300 100 311 minecraft:pearlescent_froglight
setblock 300 100 313 minecraft:pearlescent_froglight
setblock 300 100 315 minecraft:pearlescent_froglight
setblock 301 100 312 minecraft:pearlescent_froglight
setblock 301 100 314 minecraft:pearlescent_froglight
setblock 301 100 316 minecraft:pearlescent_froglight
setblock 302 100 275 minecraft:gray_concrete
setblock 302 100 311 minecraft:pearlescent_froglight
setblock 302 100 313 minecraft:pearlescent_froglight
setblock 302 100 315 minecraft:pearlescent_froglight
setblock 303 100 312 minecraft:pearlescent_froglight
setblock 303 100 314 minecraft:pearlescent_froglight
setblock 303 100 316 minecraft:pearlescent_froglight
fill 304 100 275 307 102 275 minecraft:iron_block
setblock 304 100 311 minecraft:pearlescent_froglight
setblock 304 100 313 minecraft:pearlescent_froglight
setblock 304 100 315 minecraft:pearlescent_froglight
fill 307 100 317 314 102 317 minecraft:iron_block
fill 315 100 317 315 101 317 minecraft:gray_concrete
fill 316 100 317 316 102 317 minecraft:iron_block
setblock 318 100 275 minecraft:iron_block
setblock 319 100 284 minecraft:pearlescent_froglight
setblock 319 100 286 minecraft:pearlescent_froglight
setblock 319 100 288 minecraft:pearlescent_froglight
setblock 319 100 290 minecraft:pearlescent_froglight
setblock 319 100 292 minecraft:pearlescent_froglight
setblock 320 100 285 minecraft:pearlescent_froglight
setblock 320 100 287 minecraft:pearlescent_froglight
setblock 320 100 289 minecraft:pearlescent_froglight
setblock 320 100 291 minecraft:pearlescent_froglight
fill 321 100 275 322 102 275 minecraft:iron_block
setblock 321 100 284 minecraft:pearlescent_froglight
setblock 321 100 286 minecraft:pearlescent_froglight
setblock 321 100 288 minecraft:pearlescent_froglight
setblock 321 100 290 minecraft:pearlescent_froglight
setblock 321 100 292 minecraft:pearlescent_froglight
fill 321 100 317 321 102 317 minecraft:iron_block
setblock 322 100 285 minecraft:pearlescent_froglight
setblock 322 100 287 minecraft:pearlescent_froglight
setblock 322 100 289 minecraft:pearlescent_froglight
setblock 322 100 291 minecraft:pearlescent_froglight
setblock 322 100 317 minecraft:redstone_block
setblock 323 100 275 minecraft:gray_concrete
setblock 323 100 284 minecraft:pearlescent_froglight
setblock 323 100 286 minecraft:pearlescent_froglight
setblock 323 100 288 minecraft:pearlescent_froglight
setblock 323 100 290 minecraft:pearlescent_froglight
setblock 323 100 292 minecraft:pearlescent_froglight
fill 324 100 275 324 103 275 minecraft:iron_block
fill 324 100 277 324 102 277 minecraft:iron_block
setblock 324 100 278 minecraft:gray_concrete
fill 324 100 279 324 102 281 minecraft:iron_block
fill 324 100 282 324 101 282 minecraft:gray_concrete
fill 324 100 283 324 102 284 minecraft:iron_block
fill 324 100 285 324 101 285 minecraft:gray_concrete
fill 324 100 286 324 102 288 minecraft:iron_block
fill 324 100 292 324 102 295 minecraft:iron_block
setblock 324 100 296 minecraft:sea_lantern
fill 324 100 297 324 102 301 minecraft:iron_block
fill 324 100 302 324 101 302 minecraft:gray_concrete
fill 324 100 303 324 102 306 minecraft:iron_block
setblock 324 100 307 minecraft:gray_concrete
fill 324 100 308 324 102 310 minecraft:iron_block
fill 282 101 278 282 102 278 minecraft:iron_block
fill 282 101 285 282 102 287 minecraft:iron_block
setblock 282 101 288 minecraft:gray_concrete
fill 282 101 289 282 102 290 minecraft:iron_block
setblock 282 101 291 minecraft:gray_concrete
fill 282 101 292 282 102 298 minecraft:iron_block
setblock 282 101 299 minecraft:gray_concrete
fill 282 101 300 282 102 303 minecraft:iron_block
fill 282 101 314 282 102 314 minecraft:iron_block
setblock 282 101 316 minecraft:gray_concrete
setblock 283 101 275 minecraft:gray_concrete
fill 284 101 275 287 102 275 minecraft:iron_block
fill 284 101 317 290 102 317 minecraft:iron_block
setblock 289 101 275 minecraft:gray_concrete
fill 291 101 275 291 102 275 minecraft:iron_block
setblock 291 101 317 minecraft:gray_concrete
fill 292 101 311 292 102 311 minecraft:iron_block
fill 292 101 313 292 102 313 minecraft:iron_block
fill 292 101 315 292 102 315 minecraft:iron_block
fill 292 101 317 296 102 317 minecraft:iron_block
fill 293 101 312 293 102 312 minecraft:iron_block
fill 293 101 314 293 102 314 minecraft:iron_block
fill 293 101 316 293 102 316 minecraft:iron_block
fill 294 101 311 294 102 311 minecraft:iron_block
fill 294 101 313 294 102 313 minecraft:iron_block
fill 294 101 315 294 102 315 minecraft:iron_block
fill 295 101 312 295 102 312 minecraft:iron_block
fill 295 101 314 295 102 314 minecraft:iron_block
fill 295 101 316 295 102 316 minecraft:iron_block
fill 296 101 311 296 102 311 minecraft:iron_block
fill 296 101 313 296 102 313 minecraft:iron_block
fill 296 101 315 296 102 315 minecraft:iron_block
fill 297 101 312 297 102 312 minecraft:iron_block
fill 297 101 314 297 102 314 minecraft:iron_block
fill 297 101 316 297 102 316 minecraft:iron_block
setblock 297 101 317 minecraft:gray_concrete
fill 298 101 275 298 102 275 minecraft:iron_block
fill 298 101 311 298 102 311 minecraft:iron_block
fill 298 101 313 298 102 313 minecraft:iron_block
fill 298 101 315 298 102 315 minecraft:iron_block
fill 298 101 317 298 102 317 minecraft:iron_block
setblock 299 101 275 minecraft:gray_concrete
fill 299 101 312 299 102 312 minecraft:iron_block
fill 299 101 314 299 102 314 minecraft:iron_block
fill 299 101 316 299 102 316 minecraft:iron_block
setblock 299 101 317 minecraft:gray_concrete
fill 300 101 275 302 102 275 minecraft:iron_block
fill 300 101 311 300 102 311 minecraft:iron_block
fill 300 101 313 300 102 313 minecraft:iron_block
fill 300 101 315 300 102 315 minecraft:iron_block
fill 300 101 317 306 102 317 minecraft:iron_block
fill 301 101 312 301 102 312 minecraft:iron_block
fill 301 101 314 301 102 314 minecraft:iron_block
fill 301 101 316 301 102 316 minecraft:iron_block
fill 302 101 311 302 102 311 minecraft:iron_block
fill 302 101 313 302 102 313 minecraft:iron_block
fill 302 101 315 302 102 315 minecraft:iron_block
setblock 303 101 275 minecraft:gray_concrete
fill 303 101 312 303 102 312 minecraft:iron_block
fill 303 101 314 303 102 314 minecraft:iron_block
fill 303 101 316 303 102 316 minecraft:iron_block
fill 304 101 311 304 102 311 minecraft:iron_block
fill 304 101 313 304 102 313 minecraft:iron_block
fill 304 101 315 304 102 315 minecraft:iron_block
fill 308 101 275 311 102 275 minecraft:iron_block
setblock 312 101 275 minecraft:gray_concrete
fill 313 101 275 317 102 275 minecraft:iron_block
setblock 318 101 275 minecraft:gray_concrete
fill 319 101 284 319 102 284 minecraft:iron_block
fill 319 101 286 319 102 286 minecraft:iron_block
fill 319 101 288 319 102 288 minecraft:iron_block
fill 319 101 290 319 102 290 minecraft:iron_block
fill 319 101 292 319 102 292 minecraft:iron_block
fill 320 101 285 320 102 285 minecraft:iron_block
fill 320 101 287 320 102 287 minecraft:iron_block
fill 320 101 289 320 102 289 minecraft:iron_block
fill 320 101 291 320 102 291 minecraft:iron_block
fill 321 101 284 321 102 284 minecraft:iron_block
fill 321 101 286 321 102 286 minecraft:iron_block
fill 321 101 288 321 102 288 minecraft:iron_block
fill 321 101 290 321 102 290 minecraft:iron_block
fill 321 101 292 321 102 292 minecraft:iron_block
fill 322 101 285 322 102 285 minecraft:iron_block
fill 322 101 287 322 102 287 minecraft:iron_block
fill 322 101 289 322 102 289 minecraft:iron_block
fill 322 101 291 322 102 291 minecraft:iron_block
fill 322 101 317 322 102 317 minecraft:iron_block
fill 323 101 275 323 102 275 minecraft:iron_block
fill 323 101 284 323 102 284 minecraft:iron_block
fill 323 101 286 323 102 286 minecraft:iron_block
fill 323 101 288 323 102 288 minecraft:iron_block
fill 323 101 290 323 102 290 minecraft:iron_block
fill 323 101 292 323 102 292 minecraft:iron_block
setblock 323 101 317 minecraft:gray_concrete
fill 324 101 278 324 102 278 minecraft:iron_block
setblock 324 101 296 minecraft:gray_concrete
fill 324 101 307 324 102 307 minecraft:iron_block
fill 324 101 311 324 102 312 minecraft:iron_block
setblock 324 101 313 minecraft:gray_concrete
fill 324 101 314 324 102 316 minecraft:iron_block
fill 282 102 288 283 102 288 minecraft:iron_block
setblock 282 102 291 minecraft:iron_block
setblock 282 102 299 minecraft:iron_block
fill 282 102 316 282 103 316 minecraft:iron_block
setblock 283 102 275 minecraft:iron_block
setblock 283 102 278 minecraft:iron_block
setblock 283 102 298 minecraft:iron_block
setblock 283 102 308 minecraft:iron_block
fill 284 102 282 284 102 284 minecraft:iron_block
fill 284 102 309 284 102 311 minecraft:iron_block
fill 285 102 281 287 102 281 minecraft:iron_block
fill 285 102 285 287 102 285 minecraft:iron_block
fill 285 102 308 287 102 308 minecraft:iron_block
fill 285 102 312 287 102 312 minecraft:iron_block
setblock 285 102 316 minecraft:iron_block
fill 288 102 282 288 102 284 minecraft:iron_block
fill 288 102 309 288 102 311 minecraft:iron_block
setblock 288 102 313 minecraft:iron_block
fill 289 102 275 289 102 276 minecraft:iron_block
setblock 290 102 311 minecraft:iron_block
setblock 291 102 317 minecraft:iron_block
setblock 297 102 317 minecraft:iron_block
fill 299 102 275 299 102 276 minecraft:iron_block
setblock 299 102 317 minecraft:iron_block
setblock 303 102 275 minecraft:iron_block
setblock 305 102 316 minecraft:iron_block
setblock 309 102 276 minecraft:iron_block
fill 312 102 275 312 103 275 minecraft:iron_block
fill 315 102 316 315 102 317 minecraft:iron_block
setblock 318 102 275 minecraft:iron_block
setblock 319 102 276 minecraft:iron_block
fill 323 102 282 324 102 282 minecraft:iron_block
fill 323 102 302 324 102 302 minecraft:iron_block
setblock 323 102 312 minecraft:iron_block
setblock 323 102 317 minecraft:iron_block
setblock 324 102 285 minecraft:iron_block
setblock 324 102 296 minecraft:iron_block
setblock 324 102 313 minecraft:iron_block
setblock 282 103 275 minecraft:iron_block
fill 282 103 276 282 104 280 minecraft:gray_concrete
fill 282 103 281 282 103 284 minecraft:pearlescent_froglight
setblock 282 103 285 minecraft:iron_block
fill 282 103 286 282 117 288 minecraft:gray_concrete
setblock 282 103 289 minecraft:iron_block
fill 282 103 290 282 117 290 minecraft:gray_concrete
fill 282 103 291 282 103 294 minecraft:pearlescent_froglight
fill 282 103 295 282 104 299 minecraft:gray_concrete
setblock 282 103 300 minecraft:iron_block
fill 282 103 301 282 103 304 minecraft:pearlescent_froglight
fill 282 103 305 282 103 310 minecraft:gray_concrete
fill 282 103 311 282 103 314 minecraft:pearlescent_froglight
fill 282 103 315 282 117 315 minecraft:gray_concrete
fill 282 103 317 285 117 317 minecraft:gray_concrete
fill 283 103 275 284 117 275 minecraft:gray_concrete
fill 285 103 275 288 103 275 minecraft:pearlescent_froglight
setblock 285 103 278 minecraft:light[level=12]
setblock 285 103 285 minecraft:light[level=12]
setblock 285 103 292 minecraft:light[level=12]
setblock 285 103 299 minecraft:light[level=12]
setblock 285 103 306 minecraft:light[level=12]
setblock 285 103 313 minecraft:light[level=12]
setblock 286 103 278 minecraft:gray_concrete
fill 286 103 280 286 103 281 minecraft:gray_concrete
fill 286 103 317 289 103 317 minecraft:pearlescent_froglight
fill 287 103 277 288 103 277 minecraft:gray_concrete
setblock 287 103 281 minecraft:gray_concrete
fill 289 103 275 289 106 275 minecraft:gray_concrete
setblock 289 103 278 minecraft:gray_concrete
setblock 289 103 281 minecraft:gray_concrete
fill 290 103 279 290 103 280 minecraft:gray_concrete
fill 290 103 317 291 103 317 minecraft:gray_concrete
fill 291 103 275 292 117 275 minecraft:gray_concrete
setblock 292 103 278 minecraft:light[level=12]
setblock 292 103 285 minecraft:light[level=12]
setblock 292 103 292 minecraft:light[level=12]
setblock 292 103 299 minecraft:light[level=12]
setblock 292 103 306 minecraft:light[level=12]
setblock 292 103 311 minecraft:pearlescent_froglight
setblock 292 103 313 minecraft:pearlescent_froglight
setblock 292 103 315 minecraft:pearlescent_froglight
setblock 292 103 317 minecraft:iron_block
setblock 293 103 275 minecraft:iron_block
setblock 293 103 312 minecraft:pearlescent_froglight
setblock 293 103 314 minecraft:pearlescent_froglight
setblock 293 103 316 minecraft:pearlescent_froglight
fill 293 103 317 295 104 317 minecraft:gray_concrete
fill 294 103 275 294 117 275 minecraft:gray_concrete
setblock 294 103 311 minecraft:pearlescent_froglight
setblock 294 103 313 minecraft:pearlescent_froglight
setblock 294 103 315 minecraft:pearlescent_froglight
fill 295 103 275 298 103 275 minecraft:pearlescent_froglight
setblock 295 103 312 minecraft:pearlescent_froglight
setblock 295 103 314 minecraft:pearlescent_froglight
setblock 295 103 316 minecraft:pearlescent_froglight
setblock 296 103 311 minecraft:pearlescent_froglight
setblock 296 103 313 minecraft:pearlescent_froglight
setblock 296 103 315 minecraft:pearlescent_froglight
fill 296 103 317 299 103 317 minecraft:pearlescent_froglight
setblock 297 103 312 minecraft:pearlescent_froglight
setblock 297 103 314 minecraft:pearlescent_froglight
setblock 297 103 316 minecraft:pearlescent_froglight
setblock 298 103 311 minecraft:pearlescent_froglight
setblock 298 103 313 minecraft:pearlescent_froglight
setblock 298 103 315 minecraft:pearlescent_froglight
fill 299 103 275 300 103 275 minecraft:gray_concrete
setblock 299 103 278 minecraft:light[level=12]
setblock 299 103 285 minecraft:light[level=12]
setblock 299 103 292 minecraft:light[level=12]
setblock 299 103 299 minecraft:light[level=12]
setblock 299 103 306 minecraft:light[level=12]
setblock 299 103 312 minecraft:pearlescent_froglight
setblock 299 103 314 minecraft:pearlescent_froglight
setblock 299 103 316 minecraft:pearlescent_froglight
setblock 300 103 311 minecraft:pearlescent_froglight
setblock 300 103 313 minecraft:pearlescent_froglight
setblock 300 103 315 minecraft:pearlescent_froglight
fill 300 103 317 305 104 317 minecraft:gray_concrete
setblock 301 103 275 minecraft:iron_block
setblock 301 103 312 minecraft:pearlescent_froglight
setblock 301 103 314 minecraft:pearlescent_froglight
setblock 301 103 316 minecraft:pearlescent_froglight
fill 302 103 275 304 117 275 minecraft:gray_concrete
setblock 302 103 311 minecraft:pearlescent_froglight
setblock 302 103 313 minecraft:pearlescent_froglight
setblock 302 103 315 minecraft:pearlescent_froglight
setblock 303 103 312 minecraft:pearlescent_froglight
setblock 303 103 314 minecraft:pearlescent_froglight
setblock 303 103 316 minecraft:pearlescent_froglight
setblock 304 103 311 minecraft:pearlescent_froglight
setblock 304 103 313 minecraft:pearlescent_froglight
setblock 304 103 315 minecraft:pearlescent_froglight
fill 305 103 275 308 103 275 minecraft:pearlescent_froglight
setblock 306 103 278 minecraft:light[level=12]
setblock 306 103 285 minecraft:light[level=12]
setblock 306 103 292 minecraft:light[level=12]
setblock 306 103 299 minecraft:light[level=12]
setblock 306 103 306 minecraft:light[level=12]
setblock 306 103 313 minecraft:light[level=12]
fill 306 103 317 309 103 317 minecraft:pearlescent_froglight
fill 309 103 275 311 103 275 minecraft:gray_concrete
fill 310 103 317 310 117 317 minecraft:gray_concrete
setblock 311 103 317 minecraft:iron_block
fill 312 103 317 314 117 317 minecraft:gray_concrete
fill 313 103 275 314 111 275 minecraft:gray_concrete
setblock 313 103 278 minecraft:light[level=12]
setblock 313 103 285 minecraft:light[level=12]
setblock 313 103 292 minecraft:light[level=12]
setblock 313 103 299 minecraft:light[level=12]
setblock 313 103 306 minecraft:light[level=12]
setblock 313 103 313 minecraft:light[level=12]
fill 315 103 275 318 103 275 minecraft:pearlescent_froglight
setblock 315 103 317 minecraft:iron_block
fill 316 103 317 319 103 317 minecraft:pearlescent_froglight
fill 319 103 275 323 103 275 minecraft:gray_concrete
setblock 319 103 284 minecraft:pearlescent_froglight
setblock 319 103 286 minecraft:pearlescent_froglight
setblock 319 103 288 minecraft:pearlescent_froglight
setblock 319 103 290 minecraft:pearlescent_froglight
setblock 319 103 292 minecraft:pearlescent_froglight
setblock 320 103 278 minecraft:light[level=12]
setblock 320 103 285 minecraft:pearlescent_froglight
setblock 320 103 287 minecraft:pearlescent_froglight
setblock 320 103 289 minecraft:pearlescent_froglight
setblock 320 103 291 minecraft:pearlescent_froglight
setblock 320 103 299 minecraft:light[level=12]
setblock 320 103 306 minecraft:light[level=12]
setblock 320 103 313 minecraft:light[level=12]
fill 320 103 317 324 103 317 minecraft:gray_concrete
setblock 321 103 284 minecraft:pearlescent_froglight
setblock 321 103 286 minecraft:pearlescent_froglight
setblock 321 103 288 minecraft:pearlescent_froglight
setblock 321 103 290 minecraft:pearlescent_froglight
setblock 321 103 292 minecraft:pearlescent_froglight
setblock 322 103 285 minecraft:pearlescent_froglight
setblock 322 103 287 minecraft:pearlescent_froglight
setblock 322 103 289 minecraft:pearlescent_froglight
setblock 322 103 291 minecraft:pearlescent_froglight
setblock 323 103 284 minecraft:pearlescent_froglight
fill 323 103 286 324 103 286 minecraft:pearlescent_froglight
fill 323 103 288 324 103 288 minecraft:pearlescent_froglight
setblock 323 103 290 minecraft:pearlescent_froglight
setblock 323 103 292 minecraft:pearlescent_froglight
fill 324 103 276 324 103 279 minecraft:pearlescent_froglight
fill 324 103 280 324 110 280 minecraft:gray_concrete
fill 324 103 281 324 103 282 minecraft:iron_block
fill 324 103 283 324 104 283 minecraft:gray_concrete
setblock 324 103 284 minecraft:iron_block
fill 324 103 285 324 117 285 minecraft:gray_concrete
setblock 324 103 287 minecraft:pearlescent_froglight
setblock 324 103 289 minecraft:pearlescent_froglight
fill 324 103 290 324 103 295 minecraft:gray_concrete
fill 324 103 296 324 103 299 minecraft:pearlescent_froglight
fill 324 103 300 324 104 305 minecraft:gray_concrete
fill 324 103 306 324 103 309 minecraft:pearlescent_froglight
fill 324 103 310 324 104 315 minecraft:gray_concrete
setblock 324 103 316 minecraft:pearlescent_froglight
fill 282 104 275 282 117 275 minecraft:gray_concrete
fill 282 104 281 282 111 283 minecraft:gray_concrete
setblock 282 104 284 minecraft:iron_block
fill 282 104 285 282 117 285 minecraft:gray_concrete
fill 282 104 289 282 117 289 minecraft:gray_concrete
fill 282 104 291 282 111 293 minecraft:gray_concrete
setblock 282 104 294 minecraft:iron_block
fill 282 104 300 282 111 301 minecraft:gray_concrete
setblock 282 104 302 minecraft:iron_block
fill 282 104 303 282 104 305 minecraft:gray_concrete
setblock 282 104 306 minecraft:iron_block
fill 282 104 307 282 104 314 minecraft:gray_concrete
fill 282 104 316 282 117 316 minecraft:gray_concrete
fill 285 104 275 285 105 275 minecraft:iron_block
fill 286 104 275 288 111 275 minecraft:gray_concrete
fill 286 104 317 289 110 317 minecraft:gray_concrete
fill 290 104 275 290 117 275 minecraft:gray_concrete
setblock 290 104 317 minecraft:iron_block
fill 291 104 317 292 117 317 minecraft:gray_concrete
fill 292 104 311 292 105 311 minecraft:iron_block
fill 292 104 313 292 105 313 minecraft:iron_block
fill 292 104 315 292 105 315 minecraft:iron_block
fill 293 104 275 293 117 275 minecraft:gray_concrete
fill 293 104 312 293 105 312 minecraft:iron_block
fill 293 104 314 293 105 314 minecraft:iron_block
fill 293 104 316 293 105 316 minecraft:iron_block
fill 294 104 311 294 105 311 minecraft:iron_block
fill 294 104 313 294 105 313 minecraft:iron_block
fill 294 104 315 294 105 315 minecraft:iron_block
fill 295 104 275 298 111 275 minecraft:gray_concrete
fill 295 104 312 295 105 312 minecraft:iron_block
fill 295 104 314 295 105 314 minecraft:iron_block
fill 295 104 316 295 105 316 minecraft:iron_block
fill 296 104 311 296 105 311 minecraft:iron_block
fill 296 104 313 296 105 313 minecraft:iron_block
fill 296 104 315 296 105 315 minecraft:iron_block
fill 296 104 317 297 111 317 minecraft:gray_concrete
fill 297 104 312 297 105 312 minecraft:iron_block
fill 297 104 314 297 105 314 minecraft:iron_block
fill 297 104 316 297 105 316 minecraft:iron_block
fill 298 104 311 298 105 311 minecraft:iron_block
fill 298 104 313 298 105 313 minecraft:iron_block
fill 298 104 315 298 105 315 minecraft:iron_block
setblock 298 104 317 minecraft:iron_block
setblock 299 104 275 minecraft:iron_block
fill 299 104 312 299 105 312 minecraft:iron_block
fill 299 104 314 299 105 314 minecraft:iron_block
fill 299 104 316 299 105 316 minecraft:iron_block
fill 299 104 317 299 111 317 minecraft:gray_concrete
fill 300 104 275 301 117 275 minecraft:gray_concrete
fill 300 104 311 300 105 311 minecraft:iron_block
fill 300 104 313 300 105 313 minecraft:iron_block
fill 300 104 315 300 105 315 minecraft:iron_block
fill 301 104 312 301 105 312 minecraft:iron_block
fill 301 104 314 301 105 314 minecraft:iron_block
fill 301 104 316 301 105 316 minecraft:iron_block
fill 302 104 311 302 105 311 minecraft:iron_block
fill 302 104 313 302 105 313 minecraft:iron_block
fill 302 104 315 302 105 315 minecraft:iron_block
fill 303 104 312 303 105 312 minecraft:iron_block
fill 303 104 314 303 105 314 minecraft:iron_block
fill 303 104 316 303 105 316 minecraft:iron_block
fill 304 104 311 304 105 311 minecraft:iron_block
fill 304 104 313 304 105 313 minecraft:iron_block
fill 304 104 315 304 105 315 minecraft:iron_block
fill 305 104 275 308 111 275 minecraft:gray_concrete
fill 306 104 317 307 104 317 minecraft:gray_concrete
setblock 308 104 317 minecraft:iron_block
setblock 309 104 275 minecraft:iron_block
setblock 309 104 317 minecraft:gray_concrete
fill 310 104 275 310 112 275 minecraft:gray_concrete
fill 311 104 275 311 105 275 minecraft:iron_block
fill 311 104 317 311 117 317 minecraft:gray_concrete
fill 312 104 275 312 117 275 minecraft:gray_concrete
setblock 315 104 275 minecraft:iron_block
fill 315 104 317 319 111 317 minecraft:gray_concrete
fill 316 104 275 320 104 275 minecraft:gray_concrete
fill 319 104 284 319 105 284 minecraft:iron_block
fill 319 104 286 319 105 286 minecraft:iron_block
fill 319 104 288 319 105 288 minecraft:iron_block
fill 319 104 290 319 105 290 minecraft:iron_block
fill 319 104 292 319 105 292 minecraft:iron_block
fill 320 104 285 320 105 285 minecraft:iron_block
fill 320 104 287 320 105 287 minecraft:iron_block
fill 320 104 289 320 105 289 minecraft:iron_block
fill 320 104 291 320 105 291 minecraft:iron_block
fill 320 104 317 320 105 317 minecraft:iron_block
setblock 321 104 275 minecraft:iron_block
fill 321 104 284 321 105 284 minecraft:iron_block
fill 321 104 286 321 105 286 minecraft:iron_block
fill 321 104 288 321 105 288 minecraft:iron_block
fill 321 104 290 321 105 290 minecraft:iron_block
fill 321 104 292 321 105 292 minecraft:iron_block
fill 321 104 317 323 117 317 minecraft:gray_concrete
fill 322 104 275 324 104 275 minecraft:gray_concrete
fill 322 104 285 322 105 285 minecraft:iron_block
fill 322 104 287 322 105 287 minecraft:iron_block
fill 322 104 289 322 105 289 minecraft:iron_block
fill 322 104 291 322 105 291 minecraft:iron_block
fill 323 104 284 323 105 284 minecraft:iron_block
fill 323 104 286 323 105 286 minecraft:iron_block
fill 323 104 288 324 104 288 minecraft:iron_block
fill 323 104 290 323 105 290 minecraft:iron_block
fill 323 104 292 323 105 292 minecraft:iron_block
fill 324 104 276 324 104 279 minecraft:gray_concrete
fill 324 104 281 324 104 282 minecraft:gray_concrete
fill 324 104 284 324 117 284 minecraft:gray_concrete
fill 324 104 286 324 111 287 minecraft:gray_concrete
fill 324 104 289 324 111 290 minecraft:gray_concrete
setblock 324 104 291 minecraft:iron_block
fill 324 104 292 324 117 293 minecraft:gray_concrete
setblock 324 104 294 minecraft:iron_block
fill 324 104 295 324 111 299 minecraft:gray_concrete
setblock 324 104 306 minecraft:iron_block
fill 324 104 307 324 104 309 minecraft:gray_concrete
fill 324 104 316 324 111 316 minecraft:gray_concrete
setblock 324 104 317 minecraft:iron_block
fill 282 105 276 282 117 278 minecraft:gray_concrete
setblock 282 105 279 minecraft:iron_block
fill 282 105 280 282 117 280 minecraft:gray_concrete
fill 282 105 284 282 111 284 minecraft:gray_concrete
fill 282 105 294 282 111 295 minecraft:gray_concrete
setblock 282 105 296 minecraft:iron_block
fill 282 105 297 282 117 299 minecraft:gray_concrete
fill 282 105 302 282 111 303 minecraft:gray_concrete
setblock 282 105 304 minecraft:iron_block
fill 282 105 305 282 111 312 minecraft:gray_concrete
fill 282 105 313 282 105 314 minecraft:iron_block
setblock 285 105 278 minecraft:light[level=15]
setblock 285 105 286 minecraft:light[level=15]
setblock 285 105 294 minecraft:light[level=15]
setblock 285 105 302 minecraft:light[level=15]
setblock 289 105 314 minecraft:iron_block
fill 290 105 310 290 112 310 minecraft:iron_block
fill 290 105 317 290 117 317 minecraft:gray_concrete
setblock 291 105 312 minecraft:iron_block
setblock 291 105 314 minecraft:iron_block
setblock 293 105 278 minecraft:light[level=15]
setblock 293 105 286 minecraft:light[level=15]
setblock 293 105 294 minecraft:light[level=15]
setblock 293 105 302 minecraft:light[level=15]
setblock 293 105 310 minecraft:light[level=15]
fill 293 105 317 294 117 317 minecraft:gray_concrete
setblock 295 105 317 minecraft:iron_block
fill 298 105 317 298 111 317 minecraft:gray_concrete
fill 299 105 275 299 117 275 minecraft:gray_concrete
setblock 300 105 317 minecraft:iron_block
setblock 301 105 278 minecraft:light[level=15]
setblock 301 105 286 minecraft:light[level=15]
setblock 301 105 302 minecraft:light[level=15]
setblock 301 105 310 minecraft:light[level=15]
fill 301 105 317 305 117 317 minecraft:gray_concrete
setblock 306 105 317 minecraft:iron_block
fill 307 105 317 308 111 317 minecraft:gray_concrete
fill 309 105 275 309 117 275 minecraft:gray_concrete
setblock 309 105 278 minecraft:light[level=15]
setblock 309 105 286 minecraft:light[level=15]
setblock 309 105 294 minecraft:light[level=15]
setblock 309 105 302 minecraft:light[level=15]
setblock 309 105 310 minecraft:light[level=15]
setblock 309 105 317 minecraft:iron_block
fill 315 105 275 318 111 275 minecraft:gray_concrete
setblock 317 105 278 minecraft:light[level=15]
setblock 317 105 286 minecraft:light[level=15]
setblock 317 105 294 minecraft:light[level=15]
setblock 317 105 302 minecraft:light[level=15]
setblock 317 105 310 minecraft:light[level=15]
setblock 319 105 275 minecraft:iron_block
fill 320 105 275 322 117 275 minecraft:gray_concrete
setblock 323 105 275 minecraft:iron_block
setblock 323 105 288 minecraft:iron_block
fill 324 105 275 324 111 276 minecraft:gray_concrete
setblock 324 105 277 minecraft:iron_block
fill 324 105 278 324 111 278 minecraft:gray_concrete
setblock 324 105 279 minecraft:iron_block
setblock 324 105 281 minecraft:iron_block
fill 324 105 282 324 108 282 minecraft:gray_concrete
setblock 324 105 283 minecraft:iron_block
fill 324 105 288 324 111 288 minecraft:gray_concrete
fill 324 105 291 324 117 291 minecraft:gray_concrete
fill 324 105 294 324 117 294 minecraft:gray_concrete
fill 324 105 300 324 117 304 minecraft:gray_concrete
setblock 324 105 305 minecraft:sea_lantern
fill 324 105 306 324 111 306 minecraft:gray_concrete
setblock 324 105 307 minecraft:iron_block
fill 324 105 308 324 111 312 minecraft:gray_concrete
setblock 324 105 313 minecraft:iron_block
fill 324 105 314 324 117 315 minecraft:gray_concrete
fill 324 105 317 324 117 317 minecraft:gray_concrete
fill 282 106 279 282 116 279 minecraft:gray_concrete
fill 282 106 296 282 117 296 minecraft:gray_concrete
fill 282 106 304 282 111 304 minecraft:gray_concrete
fill 282 106 313 282 111 314 minecraft:gray_concrete
fill 285 106 275 285 111 275 minecraft:gray_concrete
setblock 292 106 311 minecraft:pearlescent_froglight
setblock 292 106 313 minecraft:pearlescent_froglight
setblock 292 106 315 minecraft:pearlescent_froglight
setblock 293 106 312 minecraft:pearlescent_froglight
setblock 293 106 314 minecraft:pearlescent_froglight
setblock 293 106 316 minecraft:pearlescent_froglight
setblock 294 106 311 minecraft:pearlescent_froglight
setblock 294 106 313 minecraft:pearlescent_froglight
setblock 294 106 315 minecraft:pearlescent_froglight
setblock 295 106 312 minecraft:pearlescent_froglight
setblock 295 106 314 minecraft:pearlescent_froglight
setblock 295 106 316 minecraft:pearlescent_froglight
fill 295 106 317 295 117 317 minecraft:gray_concrete
setblock 296 106 311 minecraft:pearlescent_froglight
setblock 296 106 313 minecraft:pearlescent_froglight
setblock 296 106 315 minecraft:pearlescent_froglight
setblock 297 106 312 minecraft:pearlescent_froglight
setblock 297 106 314 minecraft:pearlescent_froglight
setblock 297 106 316 minecraft:pearlescent_froglight
setblock 298 106 311 minecraft:pearlescent_froglight
setblock 298 106 313 minecraft:pearlescent_froglight
setblock 298 106 315 minecraft:pearlescent_froglight
setblock 299 106 312 minecraft:pearlescent_froglight
setblock 299 106 314 minecraft:pearlescent_froglight
setblock 299 106 316 minecraft:pearlescent_froglight
setblock 300 106 311 minecraft:pearlescent_froglight
setblock 300 106 313 minecraft:pearlescent_froglight
setblock 300 106 315 minecraft:pearlescent_froglight
fill 300 106 317 300 117 317 minecraft:gray_concrete
setblock 301 106 312 minecraft:pearlescent_froglight
setblock 301 106 314 minecraft:pearlescent_froglight
setblock 301 106 316 minecraft:pearlescent_froglight
setblock 302 106 311 minecraft:pearlescent_froglight
setblock 302 106 313 minecraft:pearlescent_froglight
setblock 302 106 315 minecraft:pearlescent_froglight
setblock 303 106 312 minecraft:pearlescent_froglight
setblock 303 106 314 minecraft:pearlescent_froglight
setblock 303 106 316 minecraft:pearlescent_froglight
setblock 304 106 311 minecraft:pearlescent_froglight
setblock 304 106 313 minecraft:pearlescent_froglight
setblock 304 106 315 minecraft:pearlescent_froglight
fill 306 106 317 306 111 317 minecraft:gray_concrete
fill 309 106 317 309 111 317 minecraft:gray_concrete
fill 311 106 275 311 117 275 minecraft:gray_concrete
fill 319 106 275 319 117 275 minecraft:gray_concrete
setblock 319 106 284 minecraft:pearlescent_froglight
setblock 319 106 286 minecraft:pearlescent_froglight
setblock 319 106 288 minecraft:pearlescent_froglight
setblock 319 106 290 minecraft:pearlescent_froglight
setblock 319 106 292 minecraft:pearlescent_froglight
setblock 320 106 285 minecraft:pearlescent_froglight
setblock 320 106 287 minecraft:pearlescent_froglight
setblock 320 106 289 minecraft:pearlescent_froglight
setblock 320 106 291 minecraft:pearlescent_froglight
fill 320 106 317 320 117 317 minecraft:gray_concrete
setblock 321 106 284 minecraft:pearlescent_froglight
setblock 321 106 286 minecraft:pearlescent_froglight
setblock 321 106 288 minecraft:pearlescent_froglight
setblock 321 106 290 minecraft:pearlescent_froglight
setblock 321 106 292 minecraft:pearlescent_froglight
setblock 322 106 285 minecraft:pearlescent_froglight
setblock 322 106 287 minecraft:pearlescent_froglight
setblock 322 106 289 minecraft:pearlescent_froglight
setblock 322 106 291 minecraft:pearlescent_froglight
fill 323 106 275 323 117 275 minecraft:gray_concrete
setblock 323 106 284 minecraft:pearlescent_froglight
setblock 323 106 286 minecraft:pearlescent_froglight
setblock 323 106 288 minecraft:pearlescent_froglight
setblock 323 106 290 minecraft:pearlescent_froglight
setblock 323 106 292 minecraft:pearlescent_froglight
fill 324 106 277 324 111 277 minecraft:gray_concrete
fill 324 106 279 324 111 279 minecraft:gray_concrete
fill 324 106 281 324 117 281 minecraft:gray_concrete
fill 324 106 283 324 117 283 minecraft:gray_concrete
fill 324 106 305 324 117 305 minecraft:gray_concrete
fill 324 106 307 324 111 307 minecraft:gray_concrete
fill 324 106 313 324 117 313 minecraft:gray_concrete
fill 283 107 309 284 108 311 minecraft:iron_block
fill 284 107 282 284 107 284 minecraft:iron_block
fill 285 107 281 287 107 281 minecraft:iron_block
fill 285 107 285 287 107 285 minecraft:iron_block
fill 285 107 308 287 107 308 minecraft:iron_block
fill 285 107 312 287 107 312 minecraft:iron_block
fill 288 107 282 288 107 284 minecraft:iron_block
fill 288 107 309 288 107 311 minecraft:iron_block
setblock 288 107 313 minecraft:iron_block
setblock 289 107 275 minecraft:redstone_block
setblock 290 107 311 minecraft:iron_block
fill 292 107 311 292 108 311 minecraft:iron_block
fill 292 107 313 292 108 313 minecraft:iron_block
fill 292 107 315 292 108 315 minecraft:iron_block
fill 293 107 312 293 108 312 minecraft:iron_block
fill 293 107 314 293 108 314 minecraft:iron_block
fill 293 107 316 293 108 316 minecraft:iron_block
fill 294 107 311 294 108 311 minecraft:iron_block
fill 294 107 313 294 108 313 minecraft:iron_block
fill 294 107 315 294 108 315 minecraft:iron_block
fill 295 107 312 295 108 312 minecraft:iron_block
fill 295 107 314 295 108 314 minecraft:iron_block
fill 295 107 316 295 108 316 minecraft:iron_block
fill 296 107 311 296 108 311 minecraft:iron_block
fill 296 107 313 296 108 313 minecraft:iron_block
fill 296 107 315 296 108 315 minecraft:iron_block
fill 297 107 312 297 108 312 minecraft:iron_block
fill 297 107 314 297 108 314 minecraft:iron_block
fill 297 107 316 297 108 316 minecraft:iron_block
fill 298 107 311 298 108 311 minecraft:iron_block
fill 298 107 313 298 108 313 minecraft:iron_block
fill 298 107 315 298 108 315 minecraft:iron_block
fill 299 107 312 299 108 312 minecraft:iron_block
fill 299 107 314 299 108 314 minecraft:iron_block
fill 299 107 316 299 108 316 minecraft:iron_block
fill 300 107 311 300 108 311 minecraft:iron_block
fill 300 107 313 300 108 313 minecraft:iron_block
fill 300 107 315 300 108 315 minecraft:iron_block
fill 301 107 312 301 108 312 minecraft:iron_block
fill 301 107 314 301 108 314 minecraft:iron_block
fill 301 107 316 301 108 316 minecraft:iron_block
fill 302 107 311 302 108 311 minecraft:iron_block
fill 302 107 313 302 108 313 minecraft:iron_block
fill 302 107 315 302 108 315 minecraft:iron_block
fill 303 107 312 303 108 312 minecraft:iron_block
fill 303 107 314 303 108 314 minecraft:iron_block
fill 303 107 316 303 108 316 minecraft:iron_block
fill 304 107 311 304 108 311 minecraft:iron_block
fill 304 107 313 304 108 313 minecraft:iron_block
fill 304 107 315 304 108 315 minecraft:iron_block
fill 319 107 284 319 108 284 minecraft:iron_block
fill 319 107 286 319 108 286 minecraft:iron_block
fill 319 107 288 319 108 288 minecraft:iron_block
fill 319 107 290 319 108 290 minecraft:iron_block
fill 319 107 292 319 108 292 minecraft:iron_block
fill 320 107 285 320 108 285 minecraft:iron_block
fill 320 107 287 320 108 287 minecraft:iron_block
fill 320 107 289 320 108 289 minecraft:iron_block
fill 320 107 291 320 108 291 minecraft:iron_block
fill 321 107 284 321 108 284 minecraft:iron_block
fill 321 107 286 321 108 286 minecraft:iron_block
fill 321 107 288 321 108 288 minecraft:iron_block
fill 321 107 290 321 108 290 minecraft:iron_block
fill 321 107 292 321 108 292 minecraft:iron_block
fill 322 107 285 322 108 285 minecraft:iron_block
fill 322 107 287 322 108 287 minecraft:iron_block
fill 322 107 289 322 108 289 minecraft:iron_block
fill 322 107 291 322 108 291 minecraft:iron_block
fill 323 107 284 323 108 284 minecraft:iron_block
fill 323 107 286 323 108 286 minecraft:iron_block
fill 323 107 288 323 108 288 minecraft:iron_block
fill 323 107 290 323 108 290 minecraft:iron_block
fill 323 107 292 323 108 292 minecraft:iron_block
setblock 283 108 278 minecraft:iron_block
fill 283 108 280 283 108 283 minecraft:iron_block
setblock 283 108 288 minecraft:iron_block
fill 283 108 290 283 108 293 minecraft:iron_block
setblock 283 108 298 minecraft:iron_block
fill 283 108 300 283 108 303 minecraft:iron_block
setblock 283 108 308 minecraft:iron_block
fill 283 108 312 283 108 313 minecraft:iron_block
fill 284 108 276 287 108 276 minecraft:iron_block
setblock 285 108 316 minecraft:iron_block
fill 287 108 316 290 108 316 minecraft:iron_block
setblock 288 108 310 minecraft:pearlescent_froglight
fill 289 108 275 289 117 275 minecraft:gray_concrete
setblock 289 108 276 minecraft:iron_block
fill 294 108 276 297 108 276 minecraft:iron_block
setblock 299 108 276 minecraft:iron_block
fill 304 108 276 307 108 276 minecraft:iron_block
setblock 305 108 316 minecraft:iron_block
fill 307 108 316 310 108 316 minecraft:iron_block
setblock 309 108 276 minecraft:iron_block
fill 314 108 276 317 108 276 minecraft:iron_block
setblock 315 108 316 minecraft:iron_block
fill 317 108 316 320 108 316 minecraft:iron_block
setblock 319 108 276 minecraft:iron_block
fill 323 108 277 323 108 280 minecraft:iron_block
setblock 323 108 282 minecraft:iron_block
fill 323 108 297 323 108 300 minecraft:iron_block
setblock 323 108 302 minecraft:iron_block
fill 323 108 307 323 108 310 minecraft:iron_block
setblock 323 108 312 minecraft:iron_block
setblock 285 109 278 minecraft:light[level=12]
setblock 285 109 285 minecraft:light[level=12]
setblock 285 109 292 minecraft:light[level=12]
setblock 285 109 299 minecraft:light[level=12]
setblock 285 109 306 minecraft:light[level=12]
setblock 285 109 313 minecraft:light[level=12]
setblock 292 109 278 minecraft:light[level=12]
setblock 292 109 285 minecraft:light[level=12]
setblock 292 109 292 minecraft:light[level=12]
setblock 292 109 299 minecraft:light[level=12]
setblock 292 109 306 minecraft:light[level=12]
setblock 292 109 311 minecraft:pearlescent_froglight
setblock 292 109 313 minecraft:pearlescent_froglight
setblock 292 109 315 minecraft:pearlescent_froglight
setblock 293 109 312 minecraft:pearlescent_froglight
setblock 293 109 314 minecraft:pearlescent_froglight
setblock 293 109 316 minecraft:pearlescent_froglight
setblock 294 109 311 minecraft:pearlescent_froglight
setblock 294 109 313 minecraft:pearlescent_froglight
setblock 294 109 315 minecraft:pearlescent_froglight
setblock 295 109 312 minecraft:pearlescent_froglight
setblock 295 109 314 minecraft:pearlescent_froglight
setblock 295 109 316 minecraft:pearlescent_froglight
setblock 296 109 311 minecraft:pearlescent_froglight
setblock 296 109 313 minecraft:pearlescent_froglight
setblock 296 109 315 minecraft:pearlescent_froglight
setblock 297 109 312 minecraft:pearlescent_froglight
setblock 297 109 314 minecraft:pearlescent_froglight
setblock 297 109 316 minecraft:pearlescent_froglight
setblock 298 109 311 minecraft:pearlescent_froglight
setblock 298 109 313 minecraft:pearlescent_froglight
setblock 298 109 315 minecraft:pearlescent_froglight
setblock 299 109 278 minecraft:light[level=12]
setblock 299 109 285 minecraft:light[level=12]
setblock 299 109 292 minecraft:light[level=12]
setblock 299 109 299 minecraft:light[level=12]
setblock 299 109 306 minecraft:light[level=12]
setblock 299 109 312 minecraft:pearlescent_froglight
setblock 299 109 314 minecraft:pearlescent_froglight
setblock 299 109 316 minecraft:pearlescent_froglight
setblock 300 109 311 minecraft:pearlescent_froglight
setblock 300 109 313 minecraft:pearlescent_froglight
setblock 300 109 315 minecraft:pearlescent_froglight
setblock 301 109 312 minecraft:pearlescent_froglight
setblock 301 109 314 minecraft:pearlescent_froglight
setblock 301 109 316 minecraft:pearlescent_froglight
setblock 302 109 311 minecraft:pearlescent_froglight
setblock 302 109 313 minecraft:pearlescent_froglight
setblock 302 109 315 minecraft:pearlescent_froglight
setblock 303 109 312 minecraft:pearlescent_froglight
setblock 303 109 314 minecraft:pearlescent_froglight
setblock 303 109 316 minecraft:pearlescent_froglight
setblock 304 109 311 minecraft:pearlescent_froglight
setblock 304 109 313 minecraft:pearlescent_froglight
setblock 304 109 315 minecraft:pearlescent_froglight
setblock 306 109 278 minecraft:light[level=12]
setblock 306 109 285 minecraft:light[level=12]
setblock 306 109 292 minecraft:light[level=12]
setblock 306 109 299 minecraft:light[level=12]
setblock 306 109 306 minecraft:light[level=12]
setblock 306 109 313 minecraft:light[level=12]
setblock 313 109 278 minecraft:light[level=12]
setblock 313 109 285 minecraft:light[level=12]
setblock 313 109 292 minecraft:light[level=12]
setblock 313 109 299 minecraft:light[level=12]
setblock 313 109 306 minecraft:light[level=12]
setblock 313 109 313 minecraft:light[level=12]
setblock 319 109 284 minecraft:pearlescent_froglight
setblock 319 109 286 minecraft:pearlescent_froglight
setblock 319 109 288 minecraft:pearlescent_froglight
setblock 319 109 290 minecraft:pearlescent_froglight
setblock 319 109 292 minecraft:pearlescent_froglight
setblock 320 109 278 minecraft:light[level=12]
fill 320 109 280 320 127 280 minecraft:iron_block
setblock 320 109 285 minecraft:pearlescent_froglight
setblock 320 109 287 minecraft:pearlescent_froglight
setblock 320 109 289 minecraft:pearlescent_froglight
setblock 320 109 291 minecraft:pearlescent_froglight
setblock 320 109 299 minecraft:light[level=12]
setblock 320 109 306 minecraft:light[level=12]
setblock 320 109 313 minecraft:light[level=12]
setblock 321 109 284 minecraft:pearlescent_froglight
setblock 321 109 286 minecraft:pearlescent_froglight
setblock 321 109 288 minecraft:pearlescent_froglight
setblock 321 109 290 minecraft:pearlescent_froglight
setblock 321 109 292 minecraft:pearlescent_froglight
setblock 322 109 285 minecraft:pearlescent_froglight
setblock 322 109 287 minecraft:pearlescent_froglight
setblock 322 109 289 minecraft:pearlescent_froglight
setblock 322 109 291 minecraft:pearlescent_froglight
setblock 323 109 284 minecraft:pearlescent_froglight
setblock 323 109 286 minecraft:pearlescent_froglight
setblock 323 109 288 minecraft:pearlescent_froglight
setblock 323 109 290 minecraft:pearlescent_froglight
setblock 323 109 292 minecraft:pearlescent_froglight
setblock 324 109 282 minecraft:redstone_block
fill 292 110 311 292 111 311 minecraft:iron_block
fill 292 110 313 292 111 313 minecraft:iron_block
fill 292 110 315 292 111 315 minecraft:iron_block
fill 293 110 312 293 111 312 minecraft:iron_block
fill 293 110 314 293 111 314 minecraft:iron_block
fill 293 110 316 293 111 316 minecraft:iron_block
fill 294 110 311 294 111 311 minecraft:iron_block
fill 294 110 313 294 111 313 minecraft:iron_block
fill 294 110 315 294 111 315 minecraft:iron_block
fill 295 110 312 295 111 312 minecraft:iron_block
fill 295 110 314 295 111 314 minecraft:iron_block
fill 295 110 316 295 111 316 minecraft:iron_block
fill 296 110 311 296 111 311 minecraft:iron_block
fill 296 110 313 296 111 313 minecraft:iron_block
fill 296 110 315 296 111 315 minecraft:iron_block
fill 297 110 312 297 111 312 minecraft:iron_block
fill 297 110 314 297 111 314 minecraft:iron_block
fill 297 110 316 297 111 316 minecraft:iron_block
fill 298 110 311 298 111 311 minecraft:iron_block
fill 298 110 313 298 111 313 minecraft:iron_block
fill 298 110 315 298 111 315 minecraft:iron_block
fill 299 110 312 299 111 312 minecraft:iron_block
fill 299 110 314 299 111 314 minecraft:iron_block
fill 299 110 316 299 111 316 minecraft:iron_block
fill 300 110 311 300 111 311 minecraft:iron_block
fill 300 110 313 300 111 313 minecraft:iron_block
fill 300 110 315 300 111 315 minecraft:iron_block
fill 301 110 312 301 111 312 minecraft:iron_block
fill 301 110 314 301 111 314 minecraft:iron_block
fill 301 110 316 301 111 316 minecraft:iron_block
fill 302 110 311 302 111 311 minecraft:iron_block
fill 302 110 313 302 111 313 minecraft:iron_block
fill 302 110 315 302 111 315 minecraft:iron_block
fill 303 110 312 303 111 312 minecraft:iron_block
fill 303 110 314 303 111 314 minecraft:iron_block
fill 303 110 316 303 111 316 minecraft:iron_block
fill 304 110 311 304 111 311 minecraft:iron_block
fill 304 110 313 304 111 313 minecraft:iron_block
fill 304 110 315 304 111 315 minecraft:iron_block
fill 319 110 284 319 111 284 minecraft:iron_block
fill 319 110 286 319 111 286 minecraft:iron_block
fill 319 110 288 319 111 288 minecraft:iron_block
fill 319 110 290 319 111 290 minecraft:iron_block
fill 319 110 292 319 111 292 minecraft:iron_block
fill 320 110 285 320 111 285 minecraft:iron_block
fill 320 110 287 320 111 287 minecraft:iron_block
fill 320 110 289 320 111 289 minecraft:iron_block
fill 320 110 291 320 111 291 minecraft:iron_block
fill 321 110 284 321 111 284 minecraft:iron_block
fill 321 110 286 321 111 286 minecraft:iron_block
fill 321 110 288 321 111 288 minecraft:iron_block
fill 321 110 290 321 111 290 minecraft:iron_block
fill 321 110 292 321 111 292 minecraft:iron_block
fill 322 110 285 322 111 285 minecraft:iron_block
fill 322 110 287 322 111 287 minecraft:iron_block
fill 322 110 289 322 111 289 minecraft:iron_block
fill 322 110 291 322 111 291 minecraft:iron_block
fill 323 110 284 323 111 284 minecraft:iron_block
fill 323 110 286 323 111 286 minecraft:iron_block
fill 323 110 288 323 111 288 minecraft:iron_block
fill 323 110 290 323 111 290 minecraft:iron_block
fill 323 110 292 323 111 292 minecraft:iron_block
fill 324 110 282 324 117 282 minecraft:gray_concrete
setblock 286 111 278 minecraft:gray_concrete
fill 286 111 280 286 111 281 minecraft:gray_concrete
setblock 286 111 317 minecraft:redstone_block
fill 287 111 277 288 111 277 minecraft:gray_concrete
setblock 287 111 281 minecraft:gray_concrete
fill 287 111 317 289 111 317 minecraft:gray_concrete
setblock 289 111 278 minecraft:gray_concrete
setblock 289 111 281 minecraft:gray_concrete
fill 290 111 279 290 111 280 minecraft:gray_concrete
setblock 324 111 280 minecraft:redstone_block
fill 282 112 281 282 112 284 minecraft:pearlescent_froglight
fill 282 112 291 282 112 294 minecraft:pearlescent_froglight
fill 282 112 295 282 117 295 minecraft:gray_concrete
fill 282 112 300 282 117 300 minecraft:gray_concrete
fill 282 112 301 282 112 304 minecraft:pearlescent_froglight
fill 282 112 305 282 117 310 minecraft:gray_concrete
fill 282 112 311 282 112 314 minecraft:pearlescent_froglight
fill 284 112 282 284 112 284 minecraft:iron_block
fill 284 112 309 284 112 311 minecraft:iron_block
fill 285 112 275 288 112 275 minecraft:pearlescent_froglight
fill 285 112 281 287 112 281 minecraft:iron_block
fill 285 112 285 287 112 285 minecraft:iron_block
fill 285 112 308 287 112 308 minecraft:iron_block
fill 285 112 312 287 112 312 minecraft:iron_block
fill 286 112 317 289 112 317 minecraft:pearlescent_froglight
fill 288 112 282 288 112 284 minecraft:iron_block
fill 288 112 309 288 112 311 minecraft:iron_block
setblock 288 112 313 minecraft:iron_block
setblock 290 112 311 minecraft:iron_block
setblock 292 112 311 minecraft:pearlescent_froglight
setblock 292 112 313 minecraft:pearlescent_froglight
setblock 292 112 315 minecraft:pearlescent_froglight
setblock 293 112 312 minecraft:pearlescent_froglight
setblock 293 112 314 minecraft:pearlescent_froglight
setblock 293 112 316 minecraft:pearlescent_froglight
setblock 294 112 311 minecraft:pearlescent_froglight
setblock 294 112 313 minecraft:pearlescent_froglight
setblock 294 112 315 minecraft:pearlescent_froglight
fill 295 112 275 298 112 275 minecraft:pearlescent_froglight
setblock 295 112 312 minecraft:pearlescent_froglight
setblock 295 112 314 minecraft:pearlescent_froglight
setblock 295 112 316 minecraft:pearlescent_froglight
setblock 296 112 311 minecraft:pearlescent_froglight
setblock 296 112 313 minecraft:pearlescent_froglight
setblock 296 112 315 minecraft:pearlescent_froglight
fill 296 112 317 299 112 317 minecraft:pearlescent_froglight
setblock 297 112 312 minecraft:pearlescent_froglight
setblock 297 112 314 minecraft:pearlescent_froglight
setblock 297 112 316 minecraft:pearlescent_froglight
setblock 298 112 311 minecraft:pearlescent_froglight
setblock 298 112 313 minecraft:pearlescent_froglight
setblock 298 112 315 minecraft:pearlescent_froglight
setblock 299 112 312 minecraft:pearlescent_froglight
setblock 299 112 314 minecraft:pearlescent_froglight
setblock 299 112 316 minecraft:pearlescent_froglight
setblock 300 112 311 minecraft:pearlescent_froglight
setblock 300 112 313 minecraft:pearlescent_froglight
setblock 300 112 315 minecraft:pearlescent_froglight
setblock 301 112 312 minecraft:pearlescent_froglight
setblock 301 112 314 minecraft:pearlescent_froglight
setblock 301 112 316 minecraft:pearlescent_froglight
setblock 302 112 311 minecraft:pearlescent_froglight
setblock 302 112 313 minecraft:pearlescent_froglight
setblock 302 112 315 minecraft:pearlescent_froglight
setblock 303 112 312 minecraft:pearlescent_froglight
setblock 303 112 314 minecraft:pearlescent_froglight
setblock 303 112 316 minecraft:pearlescent_froglight
setblock 304 112 311 minecraft:pearlescent_froglight
setblock 304 112 313 minecraft:pearlescent_froglight
setblock 304 112 315 minecraft:pearlescent_froglight
fill 305 112 275 308 112 275 minecraft:pearlescent_froglight
fill 306 112 317 309 112 317 minecraft:pearlescent_froglight
setblock 313 112 275 minecraft:sea_lantern
fill 314 112 275 314 117 275 minecraft:gray_concrete
fill 315 112 275 318 112 275 minecraft:pearlescent_froglight
fill 315 112 317 315 117 317 minecraft:gray_concrete
fill 316 112 317 319 112 317 minecraft:pearlescent_froglight
setblock 319 112 284 minecraft:pearlescent_froglight
setblock 319 112 286 minecraft:pearlescent_froglight
setblock 319 112 288 minecraft:pearlescent_froglight
setblock 319 112 290 minecraft:pearlescent_froglight
setblock 319 112 292 minecraft:pearlescent_froglight
setblock 320 112 285 minecraft:pearlescent_froglight
setblock 320 112 287 minecraft:pearlescent_froglight
setblock 320 112 289 minecraft:pearlescent_froglight
setblock 320 112 291 minecraft:pearlescent_froglight
setblock 321 112 284 minecraft:pearlescent_froglight
setblock 321 112 286 minecraft:pearlescent_froglight
setblock 321 112 288 minecraft:pearlescent_froglight
setblock 321 112 290 minecraft:pearlescent_froglight
setblock 321 112 292 minecraft:pearlescent_froglight
setblock 322 112 285 minecraft:pearlescent_froglight
setblock 322 112 287 minecraft:pearlescent_froglight
setblock 322 112 289 minecraft:pearlescent_froglight
setblock 322 112 291 minecraft:pearlescent_froglight
setblock 323 112 284 minecraft:pearlescent_froglight
fill 323 112 286 324 112 286 minecraft:pearlescent_froglight
fill 323 112 288 324 112 288 minecraft:pearlescent_froglight
setblock 323 112 290 minecraft:pearlescent_froglight
setblock 323 112 292 minecraft:pearlescent_froglight
fill 324 112 275 324 117 275 minecraft:gray_concrete
fill 324 112 276 324 112 279 minecraft:pearlescent_froglight
fill 324 112 280 324 117 280 minecraft:gray_concrete
setblock 324 112 287 minecraft:pearlescent_froglight
setblock 324 112 289 minecraft:pearlescent_froglight
fill 324 112 290 324 117 290 minecraft:gray_concrete
fill 324 112 295 324 117 295 minecraft:gray_concrete
fill 324 112 296 324 112 299 minecraft:pearlescent_froglight
fill 324 112 306 324 112 309 minecraft:pearlescent_froglight
fill 324 112 310 324 117 312 minecraft:gray_concrete
setblock 324 112 316 minecraft:pearlescent_froglight
fill 282 113 281 282 117 284 minecraft:gray_concrete
fill 282 113 291 282 117 294 minecraft:gray_concrete
fill 282 113 301 282 117 304 minecraft:gray_concrete
fill 282 113 311 282 116 314 minecraft:gray_concrete
fill 285 113 275 288 117 275 minecraft:gray_concrete
setblock 285 113 278 minecraft:light[level=15]
setblock 285 113 286 minecraft:light[level=15]
setblock 285 113 294 minecraft:light[level=15]
setblock 285 113 302 minecraft:light[level=15]
fill 286 113 317 289 117 317 minecraft:gray_concrete
setblock 289 113 314 minecraft:iron_block
setblock 291 113 312 minecraft:iron_block
setblock 291 113 314 minecraft:iron_block
fill 292 113 311 292 115 311 minecraft:iron_block
fill 292 113 313 292 115 313 minecraft:iron_block
fill 292 113 315 292 115 315 minecraft:iron_block
setblock 293 113 278 minecraft:light[level=15]
setblock 293 113 286 minecraft:light[level=15]
setblock 293 113 294 minecraft:light[level=15]
setblock 293 113 302 minecraft:light[level=15]
setblock 293 113 310 minecraft:light[level=15]
fill 293 113 312 293 191 312 minecraft:iron_block
fill 293 113 314 293 115 314 minecraft:iron_block
fill 293 113 316 293 115 316 minecraft:iron_block
fill 294 113 311 294 115 311 minecraft:iron_block
fill 294 113 313 294 115 313 minecraft:iron_block
fill 294 113 315 294 115 315 minecraft:iron_block
fill 295 113 275 298 117 275 minecraft:gray_concrete
fill 295 113 312 295 115 312 minecraft:iron_block
fill 295 113 314 295 115 314 minecraft:iron_block
fill 295 113 316 295 115 316 minecraft:iron_block
fill 296 113 311 296 115 311 minecraft:iron_block
fill 296 113 313 296 115 313 minecraft:iron_block
fill 296 113 315 296 115 315 minecraft:iron_block
fill 296 113 317 299 117 317 minecraft:gray_concrete
fill 297 113 312 297 115 312 minecraft:iron_block
fill 297 113 314 297 115 314 minecraft:iron_block
fill 297 113 316 297 115 316 minecraft:iron_block
fill 298 113 311 298 115 311 minecraft:iron_block
fill 298 113 313 298 115 313 minecraft:iron_block
fill 298 113 315 298 115 315 minecraft:iron_block
fill 299 113 312 299 115 312 minecraft:iron_block
fill 299 113 314 299 115 314 minecraft:iron_block
fill 299 113 316 299 115 316 minecraft:iron_block
fill 300 113 311 300 115 311 minecraft:iron_block
fill 300 113 313 300 115 313 minecraft:iron_block
fill 300 113 315 300 115 315 minecraft:iron_block
setblock 301 113 278 minecraft:light[level=15]
setblock 301 113 286 minecraft:light[level=15]
setblock 301 113 302 minecraft:light[level=15]
setblock 301 113 310 minecraft:light[level=15]
fill 301 113 312 301 115 312 minecraft:iron_block
fill 301 113 314 301 115 314 minecraft:iron_block
fill 301 113 316 301 115 316 minecraft:iron_block
fill 302 113 311 302 115 311 minecraft:iron_block
fill 302 113 313 302 115 313 minecraft:iron_block
fill 302 113 315 302 115 315 minecraft:iron_block
fill 303 113 312 303 115 312 minecraft:iron_block
fill 303 113 314 303 115 314 minecraft:iron_block
fill 303 113 316 303 115 316 minecraft:iron_block
fill 304 113 311 304 115 311 minecraft:iron_block
fill 304 113 313 304 115 313 minecraft:iron_block
fill 304 113 315 304 115 315 minecraft:iron_block
fill 305 113 275 308 117 275 minecraft:gray_concrete
fill 306 113 317 309 117 317 minecraft:gray_concrete
setblock 309 113 278 minecraft:light[level=15]
setblock 309 113 286 minecraft:light[level=15]
setblock 309 113 294 minecraft:light[level=15]
setblock 309 113 302 minecraft:light[level=15]
setblock 309 113 310 minecraft:light[level=15]
setblock 310 113 275 minecraft:redstone_block
fill 313 113 275 313 117 275 minecraft:gray_concrete
fill 315 113 275 318 117 275 minecraft:gray_concrete
fill 316 113 317 319 117 317 minecraft:gray_concrete
setblock 317 113 278 minecraft:light[level=15]
setblock 317 113 286 minecraft:light[level=15]
setblock 317 113 294 minecraft:light[level=15]
setblock 317 113 302 minecraft:light[level=15]
setblock 317 113 310 minecraft:light[level=15]
fill 319 113 284 319 114 284 minecraft:iron_block
fill 319 113 286 319 114 286 minecraft:iron_block
fill 319 113 288 319 114 288 minecraft:iron_block
fill 319 113 290 319 114 290 minecraft:iron_block
fill 319 113 292 319 114 292 minecraft:iron_block
fill 320 113 285 320 114 285 minecraft:iron_block
fill 320 113 287 320 114 287 minecraft:iron_block
fill 320 113 289 320 114 289 minecraft:iron_block
fill 320 113 291 320 114 291 minecraft:iron_block
fill 321 113 284 321 114 284 minecraft:iron_block
fill 321 113 286 321 114 286 minecraft:iron_block
fill 321 113 288 321 114 288 minecraft:iron_block
fill 321 113 290 321 114 290 minecraft:iron_block
fill 321 113 292 321 114 292 minecraft:iron_block
fill 322 113 285 322 114 285 minecraft:iron_block
fill 322 113 287 322 114 287 minecraft:iron_block
fill 322 113 289 322 114 289 minecraft:iron_block
fill 322 113 291 322 114 291 minecraft:iron_block
fill 323 113 284 323 114 284 minecraft:iron_block
fill 323 113 286 323 114 286 minecraft:iron_block
fill 323 113 288 323 114 288 minecraft:iron_block
fill 323 113 290 323 114 290 minecraft:iron_block
fill 323 113 292 323 114 292 minecraft:iron_block
fill 324 113 276 324 117 279 minecraft:gray_concrete
fill 324 113 286 324 117 289 minecraft:gray_concrete
fill 324 113 296 324 117 299 minecraft:gray_concrete
fill 324 113 306 324 117 309 minecraft:gray_concrete
fill 324 113 316 324 117 316 minecraft:gray_concrete
setblock 283 114 278 minecraft:iron_block
setblock 283 114 288 minecraft:iron_block
setblock 283 114 298 minecraft:iron_block
setblock 283 114 308 minecraft:iron_block
setblock 285 114 316 minecraft:iron_block
setblock 289 114 276 minecraft:iron_block
fill 290 114 315 290 115 316 minecraft:iron_block
setblock 299 114 276 minecraft:iron_block
setblock 305 114 316 minecraft:iron_block
setblock 309 114 276 minecraft:iron_block
fill 310 114 275 310 117 275 minecraft:gray_concrete
setblock 315 114 316 minecraft:iron_block
setblock 319 114 276 minecraft:iron_block
setblock 323 114 282 minecraft:iron_block
setblock 323 114 302 minecraft:iron_block
setblock 323 114 312 minecraft:iron_block
setblock 285 115 278 minecraft:light[level=12]
setblock 285 115 285 minecraft:light[level=12]
setblock 285 115 292 minecraft:light[level=12]
setblock 285 115 299 minecraft:light[level=12]
setblock 285 115 306 minecraft:light[level=12]
setblock 285 115 313 minecraft:light[level=12]
setblock 290 115 311 minecraft:pearlescent_froglight
setblock 292 115 278 minecraft:light[level=12]
setblock 292 115 285 minecraft:light[level=12]
setblock 292 115 292 minecraft:light[level=12]
setblock 292 115 299 minecraft:light[level=12]
setblock 292 115 306 minecraft:light[level=12]
setblock 299 115 278 minecraft:light[level=12]
setblock 299 115 285 minecraft:light[level=12]
setblock 299 115 292 minecraft:light[level=12]
setblock 299 115 299 minecraft:light[level=12]
setblock 299 115 306 minecraft:light[level=12]
setblock 306 115 278 minecraft:light[level=12]
setblock 306 115 285 minecraft:light[level=12]
setblock 306 115 292 minecraft:light[level=12]
setblock 306 115 299 minecraft:light[level=12]
setblock 306 115 306 minecraft:light[level=12]
setblock 306 115 313 minecraft:light[level=12]
setblock 313 115 278 minecraft:light[level=12]
setblock 313 115 285 minecraft:light[level=12]
setblock 313 115 292 minecraft:light[level=12]
setblock 313 115 299 minecraft:light[level=12]
setblock 313 115 306 minecraft:light[level=12]
setblock 313 115 313 minecraft:light[level=12]
setblock 319 115 284 minecraft:pearlescent_froglight
setblock 319 115 286 minecraft:pearlescent_froglight
setblock 319 115 288 minecraft:pearlescent_froglight
setblock 319 115 290 minecraft:pearlescent_froglight
setblock 319 115 292 minecraft:pearlescent_froglight
setblock 320 115 278 minecraft:light[level=12]
setblock 320 115 285 minecraft:pearlescent_froglight
setblock 320 115 287 minecraft:pearlescent_froglight
setblock 320 115 289 minecraft:pearlescent_froglight
setblock 320 115 291 minecraft:pearlescent_froglight
setblock 320 115 299 minecraft:light[level=12]
setblock 320 115 306 minecraft:light[level=12]
setblock 320 115 313 minecraft:light[level=12]
setblock 321 115 284 minecraft:pearlescent_froglight
setblock 321 115 286 minecraft:pearlescent_froglight
setblock 321 115 288 minecraft:pearlescent_froglight
setblock 321 115 290 minecraft:pearlescent_froglight
setblock 321 115 292 minecraft:pearlescent_froglight
setblock 322 115 285 minecraft:pearlescent_froglight
setblock 322 115 287 minecraft:pearlescent_froglight
setblock 322 115 289 minecraft:pearlescent_froglight
setblock 322 115 291 minecraft:pearlescent_froglight
setblock 323 115 284 minecraft:pearlescent_froglight
setblock 323 115 286 minecraft:pearlescent_froglight
setblock 323 115 288 minecraft:pearlescent_froglight
setblock 323 115 290 minecraft:pearlescent_froglight
setblock 323 115 292 minecraft:pearlescent_froglight
fill 319 116 284 319 117 284 minecraft:iron_block
fill 319 116 286 319 117 286 minecraft:iron_block
fill 319 116 288 319 117 288 minecraft:iron_block
fill 319 116 290 319 117 290 minecraft:iron_block
fill 319 116 292 319 117 292 minecraft:iron_block
fill 320 116 285 320 117 285 minecraft:iron_block
fill 320 116 287 320 117 287 minecraft:iron_block
fill 320 116 289 320 117 289 minecraft:iron_block
fill 320 116 291 320 117 291 minecraft:iron_block
fill 321 116 284 321 117 284 minecraft:iron_block
fill 321 116 286 321 117 286 minecraft:iron_block
fill 321 116 288 321 117 288 minecraft:iron_block
fill 321 116 290 321 117 290 minecraft:iron_block
fill 321 116 292 321 117 292 minecraft:iron_block
fill 322 116 285 322 117 285 minecraft:iron_block
fill 322 116 287 322 117 287 minecraft:iron_block
fill 322 116 289 322 117 289 minecraft:iron_block
fill 322 116 291 322 117 291 minecraft:iron_block
fill 323 116 284 323 117 284 minecraft:iron_block
fill 323 116 286 323 117 286 minecraft:iron_block
fill 323 116 288 323 117 288 minecraft:iron_block
fill 323 116 290 323 117 290 minecraft:iron_block
fill 323 116 292 323 117 292 minecraft:iron_block
setblock 282 117 279 minecraft:redstone_block
setblock 282 117 311 minecraft:sea_lantern
fill 282 117 312 282 117 314 minecraft:gray_concrete
fill 283 117 280 283 117 283 minecraft:iron_block
fill 283 117 290 283 117 293 minecraft:iron_block
fill 283 117 300 283 117 303 minecraft:iron_block
fill 283 117 310 283 117 313 minecraft:iron_block
fill 284 117 276 287 117 276 minecraft:iron_block
fill 284 117 282 284 117 284 minecraft:iron_block
fill 284 117 309 284 117 311 minecraft:iron_block
fill 285 117 281 287 118 281 minecraft:iron_block
fill 285 117 285 287 117 285 minecraft:iron_block
fill 285 117 308 287 117 308 minecraft:iron_block
fill 285 117 312 287 117 312 minecraft:iron_block
fill 287 117 316 290 117 316 minecraft:iron_block
fill 288 117 282 288 117 284 minecraft:iron_block
fill 288 117 309 288 117 311 minecraft:iron_block
setblock 288 117 313 minecraft:iron_block
setblock 290 117 311 minecraft:iron_block
fill 294 117 276 297 117 276 minecraft:iron_block
fill 297 117 316 300 117 316 minecraft:iron_block
fill 304 117 276 307 117 276 minecraft:iron_block
fill 307 117 316 310 117 316 minecraft:iron_block
fill 314 117 276 317 117 276 minecraft:iron_block
fill 317 117 316 320 117 316 minecraft:iron_block
fill 323 117 277 323 117 280 minecraft:iron_block
fill 323 117 297 323 117 300 minecraft:iron_block
fill 323 117 307 323 117 310 minecraft:iron_block
fill 282 118 275 282 119 276 minecraft:yellow_concrete
fill 282 118 277 282 119 278 minecraft:black_concrete
fill 282 118 279 282 119 280 minecraft:yellow_concrete
fill 282 118 281 282 119 282 minecraft:black_concrete
fill 282 118 283 282 119 284 minecraft:yellow_concrete
fill 282 118 285 282 119 286 minecraft:black_concrete
fill 282 118 287 282 119 288 minecraft:yellow_concrete
fill 282 118 289 282 119 290 minecraft:black_concrete
fill 282 118 291 282 119 292 minecraft:yellow_concrete
fill 282 118 293 282 119 294 minecraft:black_concrete
fill 282 118 295 282 119 296 minecraft:yellow_concrete
fill 282 118 297 282 119 298 minecraft:black_concrete
fill 282 118 299 282 119 300 minecraft:yellow_concrete
fill 282 118 301 282 119 302 minecraft:black_concrete
fill 282 118 303 282 119 304 minecraft:yellow_concrete
fill 282 118 305 282 119 306 minecraft:black_concrete
fill 282 118 307 282 119 308 minecraft:yellow_concrete
fill 282 118 309 282 119 310 minecraft:black_concrete
fill 282 118 311 282 119 312 minecraft:yellow_concrete
fill 282 118 313 282 119 314 minecraft:black_concrete
fill 282 118 315 282 119 316 minecraft:yellow_concrete
fill 282 118 317 282 119 317 minecraft:black_concrete
fill 283 118 275 283 119 275 minecraft:yellow_concrete
fill 283 118 281 284 119 281 minecraft:iron_block
fill 283 118 317 283 119 317 minecraft:yellow_concrete
fill 284 118 275 285 119 275 minecraft:black_concrete
fill 284 118 317 285 119 317 minecraft:black_concrete
fill 286 118 275 287 119 275 minecraft:yellow_concrete
fill 286 118 317 287 119 317 minecraft:yellow_concrete
fill 288 118 275 289 119 275 minecraft:black_concrete
fill 288 118 317 289 119 317 minecraft:black_concrete
fill 289 118 281 291 118 281 minecraft:iron_block
fill 290 118 275 291 119 275 minecraft:yellow_concrete
fill 290 118 317 291 119 317 minecraft:yellow_concrete
fill 292 118 275 293 119 275 minecraft:black_concrete
fill 292 118 317 293 119 317 minecraft:black_concrete
fill 294 118 275 295 119 275 minecraft:yellow_concrete
fill 294 118 317 295 119 317 minecraft:yellow_concrete
fill 296 118 275 297 119 275 minecraft:black_concrete
fill 296 118 317 297 119 317 minecraft:black_concrete
fill 298 118 275 299 119 275 minecraft:yellow_concrete
fill 298 118 317 299 119 317 minecraft:yellow_concrete
fill 300 118 275 301 119 275 minecraft:black_concrete
fill 300 118 317 301 119 317 minecraft:black_concrete
fill 302 118 275 303 119 275 minecraft:yellow_concrete
fill 302 118 317 303 119 317 minecraft:yellow_concrete
fill 304 118 275 305 119 275 minecraft:black_concrete
fill 304 118 317 305 119 317 minecraft:black_concrete
fill 306 118 275 307 119 275 minecraft:yellow_concrete
fill 306 118 317 307 119 317 minecraft:yellow_concrete
fill 308 118 275 309 119 275 minecraft:black_concrete
fill 308 118 317 309 119 317 minecraft:black_concrete
fill 310 118 275 311 119 275 minecraft:yellow_concrete
fill 310 118 317 311 119 317 minecraft:yellow_concrete
fill 312 118 275 313 119 275 minecraft:black_concrete
fill 312 118 317 313 119 317 minecraft:black_concrete
fill 314 118 275 315 119 275 minecraft:yellow_concrete
fill 314 118 317 315 119 317 minecraft:yellow_concrete
fill 316 118 275 317 119 275 minecraft:black_concrete
fill 316 118 317 317 119 317 minecraft:black_concrete
fill 318 118 275 319 119 275 minecraft:yellow_concrete
fill 318 118 317 319 119 317 minecraft:yellow_concrete
setblock 319 118 284 minecraft:pearlescent_froglight
setblock 319 118 286 minecraft:pearlescent_froglight
setblock 319 118 288 minecraft:pearlescent_froglight
setblock 319 118 290 minecraft:pearlescent_froglight
setblock 319 118 292 minecraft:pearlescent_froglight
fill 320 118 275 321 119 275 minecraft:black_concrete
setblock 320 118 285 minecraft:pearlescent_froglight
setblock 320 118 287 minecraft:pearlescent_froglight
setblock 320 118 289 minecraft:pearlescent_froglight
setblock 320 118 291 minecraft:pearlescent_froglight
fill 320 118 317 321 119 317 minecraft:black_concrete
setblock 321 118 284 minecraft:pearlescent_froglight
setblock 321 118 286 minecraft:pearlescent_froglight
setblock 321 118 288 minecraft:pearlescent_froglight
setblock 321 118 290 minecraft:pearlescent_froglight
setblock 321 118 292 minecraft:pearlescent_froglight
fill 322 118 275 323 119 275 minecraft:yellow_concrete
setblock 322 118 285 minecraft:pearlescent_froglight
setblock 322 118 287 minecraft:pearlescent_froglight
setblock 322 118 289 minecraft:pearlescent_froglight
setblock 322 118 291 minecraft:pearlescent_froglight
fill 322 118 317 323 119 317 minecraft:yellow_concrete
setblock 323 118 284 minecraft:pearlescent_froglight
setblock 323 118 286 minecraft:pearlescent_froglight
setblock 323 118 288 minecraft:pearlescent_froglight
setblock 323 118 290 minecraft:pearlescent_froglight
setblock 323 118 292 minecraft:pearlescent_froglight
fill 324 118 275 324 119 275 minecraft:black_concrete
fill 324 118 276 324 119 276 minecraft:yellow_concrete
fill 324 118 277 324 119 278 minecraft:black_concrete
fill 324 118 279 324 119 280 minecraft:yellow_concrete
fill 324 118 281 324 119 282 minecraft:black_concrete
fill 324 118 283 324 119 284 minecraft:yellow_concrete
fill 324 118 285 324 119 286 minecraft:black_concrete
fill 324 118 287 324 119 288 minecraft:yellow_concrete
fill 324 118 289 324 119 290 minecraft:black_concrete
fill 324 118 291 324 119 292 minecraft:yellow_concrete
fill 324 118 293 324 119 294 minecraft:black_concrete
fill 324 118 295 324 119 296 minecraft:yellow_concrete
fill 324 118 297 324 119 298 minecraft:black_concrete
fill 324 118 299 324 119 300 minecraft:yellow_concrete
fill 324 118 301 324 119 302 minecraft:black_concrete
fill 324 118 303 324 119 304 minecraft:yellow_concrete
fill 324 118 305 324 119 306 minecraft:black_concrete
fill 324 118 307 324 119 308 minecraft:yellow_concrete
fill 324 118 309 324 119 310 minecraft:black_concrete
fill 324 118 311 324 119 312 minecraft:yellow_concrete
fill 324 118 313 324 119 314 minecraft:black_concrete
fill 324 118 315 324 119 316 minecraft:yellow_concrete
fill 324 118 317 324 119 317 minecraft:black_concrete
setblock 283 119 280 minecraft:iron_block
setblock 285 119 281 minecraft:iron_block
setblock 286 119 278 minecraft:gray_concrete
fill 286 119 280 286 119 281 minecraft:gray_concrete
fill 287 119 277 288 119 277 minecraft:gray_concrete
setblock 287 119 281 minecraft:gray_concrete
fill 288 119 282 312 119 282 minecraft:iron_block
setblock 289 119 278 minecraft:gray_concrete
setblock 289 119 281 minecraft:gray_concrete
fill 290 119 279 290 119 280 minecraft:gray_concrete
fill 290 119 281 304 119 281 minecraft:iron_block
fill 319 119 284 319 121 284 minecraft:iron_block
fill 319 119 286 319 121 286 minecraft:iron_block
fill 319 119 288 319 121 288 minecraft:iron_block
fill 319 119 290 319 121 290 minecraft:iron_block
fill 319 119 292 319 121 292 minecraft:iron_block
fill 320 119 285 320 121 285 minecraft:iron_block
fill 320 119 287 320 121 287 minecraft:iron_block
fill 320 119 289 320 121 289 minecraft:iron_block
fill 320 119 291 320 121 291 minecraft:iron_block
fill 321 119 284 321 121 284 minecraft:iron_block
fill 321 119 286 321 121 286 minecraft:iron_block
fill 321 119 288 321 121 288 minecraft:iron_block
fill 321 119 290 321 121 290 minecraft:iron_block
fill 321 119 292 321 121 292 minecraft:iron_block
fill 322 119 285 322 121 285 minecraft:iron_block
fill 322 119 287 322 121 287 minecraft:iron_block
fill 322 119 289 322 121 289 minecraft:iron_block
fill 322 119 291 322 121 291 minecraft:iron_block
fill 323 119 284 323 121 284 minecraft:iron_block
fill 323 119 286 323 121 286 minecraft:iron_block
fill 323 119 288 323 121 288 minecraft:iron_block
fill 323 119 290 323 121 290 minecraft:iron_block
fill 323 119 292 323 121 292 minecraft:iron_block
fill 282 120 275 282 120 317 minecraft:gray_concrete
fill 283 120 275 324 120 275 minecraft:gray_concrete
setblock 283 120 278 minecraft:iron_block
fill 283 120 281 287 120 281 minecraft:light_gray_concrete
setblock 283 120 288 minecraft:iron_block
setblock 283 120 298 minecraft:iron_block
setblock 283 120 308 minecraft:iron_block
fill 283 120 317 324 120 317 minecraft:gray_concrete
setblock 285 120 316 minecraft:iron_block
setblock 289 120 276 minecraft:iron_block
fill 289 120 281 293 120 281 minecraft:light_gray_concrete
fill 294 120 281 309 120 281 minecraft:iron_block
setblock 295 120 316 minecraft:iron_block
fill 297 120 282 323 120 282 minecraft:iron_block
setblock 299 120 276 minecraft:iron_block
setblock 305 120 316 minecraft:iron_block
setblock 309 120 276 minecraft:iron_block
fill 310 120 283 322 120 283 minecraft:iron_block
setblock 315 120 316 minecraft:iron_block
setblock 319 120 276 minecraft:iron_block
setblock 323 120 302 minecraft:iron_block
setblock 323 120 312 minecraft:iron_block
fill 324 120 276 324 120 316 minecraft:gray_concrete
fill 282 121 275 282 130 280 minecraft:gray_concrete
fill 282 121 281 282 121 284 minecraft:pearlescent_froglight
fill 282 121 285 282 145 290 minecraft:gray_concrete
fill 282 121 291 282 121 294 minecraft:pearlescent_froglight
fill 282 121 295 282 122 300 minecraft:gray_concrete
fill 282 121 301 282 121 304 minecraft:pearlescent_froglight
fill 282 121 305 282 145 310 minecraft:gray_concrete
fill 282 121 311 282 121 314 minecraft:pearlescent_froglight
fill 282 121 315 282 145 317 minecraft:gray_concrete
fill 283 121 275 284 145 275 minecraft:gray_concrete
fill 283 121 317 285 145 317 minecraft:gray_concrete
fill 285 121 275 288 121 275 minecraft:pearlescent_froglight
setblock 285 121 278 minecraft:light[level=15]
setblock 285 121 285 minecraft:light[level=12]
setblock 285 121 286 minecraft:light[level=15]
setblock 285 121 292 minecraft:light[level=12]
setblock 285 121 294 minecraft:light[level=15]
setblock 285 121 299 minecraft:light[level=12]
setblock 285 121 302 minecraft:light[level=15]
setblock 285 121 306 minecraft:light[level=12]
setblock 285 121 313 minecraft:light[level=12]
fill 286 121 317 289 121 317 minecraft:pearlescent_froglight
fill 289 121 275 294 145 275 minecraft:gray_concrete
setblock 289 121 314 minecraft:iron_block
fill 290 121 317 295 134 317 minecraft:gray_concrete
fill 291 121 312 292 121 312 minecraft:iron_block
setblock 291 121 314 minecraft:iron_block
setblock 292 121 278 minecraft:light[level=12]
setblock 292 121 285 minecraft:light[level=12]
setblock 292 121 292 minecraft:light[level=12]
setblock 292 121 299 minecraft:light[level=12]
setblock 292 121 306 minecraft:light[level=12]
fill 292 121 311 294 121 311 minecraft:iron_block
fill 292 121 313 294 121 313 minecraft:iron_block
setblock 293 121 278 minecraft:light[level=15]
setblock 293 121 286 minecraft:light[level=15]
setblock 293 121 294 minecraft:light[level=15]
setblock 293 121 302 minecraft:light[level=15]
setblock 293 121 310 minecraft:light[level=15]
setblock 294 121 312 minecraft:iron_block
fill 295 121 275 298 121 275 minecraft:pearlescent_froglight
fill 296 121 317 299 121 317 minecraft:pearlescent_froglight
fill 299 121 275 304 145 275 minecraft:gray_concrete
setblock 299 121 278 minecraft:light[level=12]
fill 299 121 282 312 121 282 minecraft:light_gray_concrete
setblock 299 121 285 minecraft:light[level=12]
setblock 299 121 292 minecraft:light[level=12]
setblock 299 121 299 minecraft:light[level=12]
setblock 299 121 306 minecraft:light[level=12]
setblock 299 121 313 minecraft:light[level=12]
fill 300 121 317 305 121 317 minecraft:gray_concrete
setblock 301 121 278 minecraft:light[level=15]
setblock 301 121 286 minecraft:light[level=15]
setblock 301 121 302 minecraft:light[level=15]
setblock 301 121 310 minecraft:light[level=15]
fill 305 121 275 308 121 275 minecraft:pearlescent_froglight
setblock 306 121 278 minecraft:light[level=12]
setblock 306 121 285 minecraft:light[level=12]
setblock 306 121 292 minecraft:light[level=12]
setblock 306 121 299 minecraft:light[level=12]
setblock 306 121 306 minecraft:light[level=12]
setblock 306 121 313 minecraft:light[level=12]
fill 306 121 317 309 121 317 minecraft:pearlescent_froglight
fill 309 121 275 314 123 275 minecraft:gray_concrete
setblock 309 121 278 minecraft:light[level=15]
setblock 309 121 286 minecraft:light[level=15]
setblock 309 121 294 minecraft:light[level=15]
setblock 309 121 302 minecraft:light[level=15]
setblock 309 121 310 minecraft:light[level=15]
fill 310 121 317 315 145 317 minecraft:gray_concrete
setblock 313 121 278 minecraft:light[level=12]
fill 313 121 282 323 121 282 minecraft:iron_block
setblock 313 121 285 minecraft:light[level=12]
setblock 313 121 292 minecraft:light[level=12]
setblock 313 121 299 minecraft:light[level=12]
setblock 313 121 306 minecraft:light[level=12]
setblock 313 121 313 minecraft:light[level=12]
fill 315 121 275 318 121 275 minecraft:pearlescent_froglight
fill 316 121 317 319 121 317 minecraft:pearlescent_froglight
setblock 317 121 278 minecraft:light[level=15]
setblock 317 121 286 minecraft:light[level=15]
setblock 317 121 294 minecraft:light[level=15]
setblock 317 121 302 minecraft:light[level=15]
setblock 317 121 310 minecraft:light[level=15]
fill 318 121 283 322 121 283 minecraft:iron_block
fill 319 121 275 324 128 275 minecraft:gray_concrete
setblock 320 121 278 minecraft:light[level=12]
setblock 320 121 299 minecraft:light[level=12]
setblock 320 121 306 minecraft:light[level=12]
setblock 320 121 313 minecraft:light[level=12]
fill 320 121 317 321 145 317 minecraft:gray_concrete
setblock 322 121 317 minecraft:redstone_block
fill 323 121 317 324 145 317 minecraft:gray_concrete
fill 324 121 276 324 121 279 minecraft:pearlescent_froglight
fill 324 121 280 324 127 285 minecraft:gray_concrete
fill 324 121 286 324 121 289 minecraft:pearlescent_froglight
fill 324 121 290 324 145 295 minecraft:gray_concrete
fill 324 121 296 324 121 299 minecraft:pearlescent_froglight
fill 324 121 300 324 128 305 minecraft:gray_concrete
fill 324 121 306 324 121 309 minecraft:pearlescent_froglight
fill 324 121 310 324 136 315 minecraft:gray_concrete
setblock 324 121 316 minecraft:pearlescent_froglight
fill 282 122 281 282 129 284 minecraft:gray_concrete
fill 282 122 291 282 129 294 minecraft:gray_concrete
fill 282 122 301 282 129 304 minecraft:gray_concrete
fill 282 122 311 282 129 314 minecraft:gray_concrete
fill 284 122 282 284 122 284 minecraft:iron_block
fill 284 122 309 284 122 311 minecraft:iron_block
fill 285 122 275 288 129 275 minecraft:gray_concrete
fill 285 122 281 287 122 281 minecraft:iron_block
fill 285 122 285 287 122 285 minecraft:iron_block
fill 285 122 308 287 122 308 minecraft:iron_block
fill 285 122 312 287 122 312 minecraft:iron_block
fill 286 122 317 289 129 317 minecraft:gray_concrete
fill 288 122 282 288 122 284 minecraft:iron_block
fill 288 122 309 288 122 311 minecraft:iron_block
setblock 288 122 313 minecraft:iron_block
setblock 290 122 311 minecraft:iron_block
fill 295 122 275 298 129 275 minecraft:gray_concrete
fill 296 122 317 303 129 317 minecraft:gray_concrete
setblock 304 122 317 minecraft:sea_lantern
fill 305 122 275 308 129 275 minecraft:gray_concrete
fill 305 122 317 306 129 317 minecraft:gray_concrete
setblock 307 122 317 minecraft:sea_lantern
fill 308 122 317 309 129 317 minecraft:gray_concrete
fill 315 122 275 318 129 275 minecraft:gray_concrete
fill 315 122 282 322 122 282 minecraft:light_gray_concrete
fill 316 122 317 319 129 317 minecraft:gray_concrete
fill 321 122 283 322 122 283 minecraft:light_gray_concrete
fill 322 122 317 322 145 317 minecraft:gray_concrete
fill 324 122 276 324 129 279 minecraft:gray_concrete
fill 324 122 286 324 129 289 minecraft:gray_concrete
fill 324 122 296 324 129 299 minecraft:gray_concrete
fill 324 122 306 324 124 309 minecraft:gray_concrete
fill 324 122 316 324 129 316 minecraft:gray_concrete
fill 282 123 295 282 145 298 minecraft:gray_concrete
setblock 282 123 299 minecraft:redstone_block
fill 282 123 300 282 145 300 minecraft:gray_concrete
fill 304 123 317 304 145 317 minecraft:gray_concrete
fill 307 123 317 307 129 317 minecraft:gray_concrete
fill 282 124 299 282 145 299 minecraft:gray_concrete
fill 309 124 275 312 144 275 minecraft:gray_concrete
setblock 313 124 275 minecraft:redstone_block
fill 314 124 275 314 145 275 minecraft:gray_concrete
fill 289 125 314 289 126 315 minecraft:iron_block
fill 313 125 275 313 145 275 minecraft:gray_concrete
fill 324 125 306 324 129 306 minecraft:gray_concrete
setblock 324 125 307 minecraft:sea_lantern
fill 324 125 308 324 129 309 minecraft:gray_concrete
setblock 283 126 278 minecraft:iron_block
fill 283 126 280 283 126 283 minecraft:iron_block
setblock 283 126 288 minecraft:iron_block
fill 283 126 290 283 126 293 minecraft:iron_block
setblock 283 126 298 minecraft:iron_block
fill 283 126 300 283 126 303 minecraft:iron_block
setblock 283 126 308 minecraft:iron_block
fill 283 126 310 283 126 313 minecraft:iron_block
fill 284 126 276 287 126 276 minecraft:iron_block
setblock 285 126 316 minecraft:iron_block
fill 287 126 316 290 126 316 minecraft:iron_block
setblock 289 126 276 minecraft:iron_block
setblock 289 126 310 minecraft:pearlescent_froglight
fill 294 126 276 297 126 276 minecraft:iron_block
setblock 295 126 316 minecraft:iron_block
fill 297 126 316 300 126 316 minecraft:iron_block
setblock 299 126 276 minecraft:iron_block
fill 304 126 276 307 126 276 minecraft:iron_block
setblock 305 126 316 minecraft:iron_block
fill 307 126 316 310 126 316 minecraft:iron_block
setblock 309 126 276 minecraft:iron_block
fill 314 126 276 317 126 276 minecraft:iron_block
setblock 315 126 316 minecraft:iron_block
fill 317 126 316 320 126 316 minecraft:iron_block
setblock 319 126 276 minecraft:iron_block
fill 323 126 277 323 126 280 minecraft:iron_block
setblock 323 126 282 minecraft:iron_block
fill 323 126 287 323 126 290 minecraft:iron_block
setblock 323 126 292 minecraft:iron_block
fill 323 126 297 323 126 300 minecraft:iron_block
setblock 323 126 302 minecraft:iron_block
fill 323 126 307 323 126 310 minecraft:iron_block
setblock 323 126 312 minecraft:iron_block
fill 324 126 307 324 129 307 minecraft:gray_concrete
fill 283 127 282 284 128 284 minecraft:iron_block
fill 284 127 309 284 127 311 minecraft:iron_block
setblock 285 127 278 minecraft:light[level=12]
setblock 285 127 281 minecraft:iron_block
fill 285 127 285 287 127 285 minecraft:iron_block
setblock 285 127 292 minecraft:light[level=12]
setblock 285 127 299 minecraft:light[level=12]
setblock 285 127 306 minecraft:light[level=12]
fill 285 127 308 287 127 308 minecraft:iron_block
fill 285 127 312 287 127 312 minecraft:iron_block
setblock 285 127 313 minecraft:light[level=12]
setblock 286 127 278 minecraft:gray_concrete
fill 286 127 280 286 127 281 minecraft:gray_concrete
fill 287 127 277 288 127 277 minecraft:gray_concrete
setblock 287 127 281 minecraft:gray_concrete
fill 288 127 282 288 127 284 minecraft:iron_block
fill 288 127 309 288 127 311 minecraft:iron_block
setblock 288 127 313 minecraft:iron_block
setblock 289 127 278 minecraft:gray_concrete
setblock 289 127 281 minecraft:gray_concrete
fill 290 127 279 290 127 280 minecraft:gray_concrete
setblock 290 127 311 minecraft:iron_block
setblock 292 127 278 minecraft:light[level=12]
setblock 292 127 285 minecraft:light[level=12]
setblock 292 127 292 minecraft:light[level=12]
setblock 292 127 299 minecraft:light[level=12]
setblock 292 127 306 minecraft:light[level=12]
setblock 292 127 313 minecraft:light[level=12]
setblock 299 127 278 minecraft:light[level=12]
setblock 299 127 285 minecraft:light[level=12]
setblock 299 127 292 minecraft:light[level=12]
setblock 299 127 299 minecraft:light[level=12]
setblock 299 127 306 minecraft:light[level=12]
setblock 299 127 313 minecraft:light[level=12]
setblock 306 127 278 minecraft:light[level=12]
setblock 306 127 285 minecraft:light[level=12]
setblock 306 127 292 minecraft:light[level=12]
setblock 306 127 299 minecraft:light[level=12]
setblock 306 127 306 minecraft:light[level=12]
setblock 306 127 313 minecraft:light[level=12]
setblock 313 127 278 minecraft:light[level=12]
setblock 313 127 285 minecraft:light[level=12]
setblock 313 127 292 minecraft:light[level=12]
setblock 313 127 299 minecraft:light[level=12]
setblock 313 127 306 minecraft:light[level=12]
setblock 313 127 313 minecraft:light[level=12]
setblock 320 127 278 minecraft:light[level=12]
setblock 320 127 285 minecraft:light[level=12]
setblock 320 127 292 minecraft:light[level=12]
setblock 320 127 299 minecraft:light[level=12]
setblock 320 127 306 minecraft:light[level=12]
setblock 320 127 313 minecraft:light[level=12]
setblock 288 128 283 minecraft:pearlescent_froglight
fill 324 128 280 324 145 282 minecraft:gray_concrete
setblock 324 128 283 minecraft:sea_lantern
fill 324 128 284 324 145 285 minecraft:gray_concrete
setblock 285 129 278 minecraft:light[level=15]
setblock 285 129 286 minecraft:light[level=15]
setblock 285 129 294 minecraft:light[level=15]
setblock 285 129 302 minecraft:light[level=15]
setblock 289 129 314 minecraft:iron_block
fill 291 129 312 292 129 312 minecraft:iron_block
setblock 291 129 314 minecraft:iron_block
fill 292 129 311 294 129 311 minecraft:iron_block
fill 292 129 313 294 129 313 minecraft:iron_block
setblock 293 129 278 minecraft:light[level=15]
setblock 293 129 286 minecraft:light[level=15]
setblock 293 129 294 minecraft:light[level=15]
setblock 293 129 302 minecraft:light[level=15]
setblock 293 129 310 minecraft:light[level=15]
setblock 294 129 312 minecraft:iron_block
setblock 301 129 278 minecraft:light[level=15]
setblock 301 129 286 minecraft:light[level=15]
setblock 301 129 302 minecraft:light[level=15]
setblock 301 129 310 minecraft:light[level=15]
setblock 309 129 278 minecraft:light[level=15]
setblock 309 129 286 minecraft:light[level=15]
setblock 309 129 294 minecraft:light[level=15]
setblock 309 129 302 minecraft:light[level=15]
setblock 309 129 310 minecraft:light[level=15]
setblock 317 129 278 minecraft:light[level=15]
setblock 317 129 286 minecraft:light[level=15]
setblock 317 129 294 minecraft:light[level=15]
setblock 317 129 302 minecraft:light[level=15]
setblock 317 129 310 minecraft:light[level=15]
fill 319 129 275 321 145 275 minecraft:gray_concrete
setblock 322 129 275 minecraft:redstone_block
fill 323 129 275 324 145 275 minecraft:gray_concrete
fill 324 129 283 324 145 283 minecraft:gray_concrete
fill 324 129 300 324 145 303 minecraft:gray_concrete
setblock 324 129 304 minecraft:sea_lantern
fill 324 129 305 324 145 305 minecraft:gray_concrete
fill 282 130 281 282 130 284 minecraft:pearlescent_froglight
fill 282 130 291 282 130 294 minecraft:pearlescent_froglight
fill 282 130 301 282 130 304 minecraft:pearlescent_froglight
fill 282 130 311 282 130 314 minecraft:pearlescent_froglight
fill 285 130 275 288 130 275 minecraft:pearlescent_froglight
fill 286 130 317 289 130 317 minecraft:pearlescent_froglight
fill 295 130 275 298 130 275 minecraft:pearlescent_froglight
fill 296 130 317 299 130 317 minecraft:pearlescent_froglight
fill 300 130 278 304 147 278 minecraft:iron_block
fill 300 130 317 303 145 317 minecraft:gray_concrete
fill 301 130 277 303 142 277 minecraft:iron_block
fill 301 130 279 303 148 279 minecraft:iron_block
fill 302 130 276 302 140 276 minecraft:iron_block
fill 302 130 280 302 148 280 minecraft:iron_block
fill 305 130 275 308 130 275 minecraft:pearlescent_froglight
fill 305 130 317 305 145 317 minecraft:gray_concrete
fill 306 130 317 309 130 317 minecraft:pearlescent_froglight
fill 315 130 275 318 130 275 minecraft:pearlescent_froglight
fill 316 130 317 319 130 317 minecraft:pearlescent_froglight
fill 322 130 275 322 145 275 minecraft:gray_concrete
fill 324 130 276 324 130 279 minecraft:pearlescent_froglight
fill 324 130 286 324 130 289 minecraft:pearlescent_froglight
fill 324 130 296 324 130 299 minecraft:pearlescent_froglight
fill 324 130 304 324 145 304 minecraft:gray_concrete
fill 324 130 306 324 130 309 minecraft:pearlescent_froglight
setblock 324 130 316 minecraft:pearlescent_froglight
fill 282 131 275 282 145 276 minecraft:gray_concrete
setblock 282 131 277 minecraft:sea_lantern
fill 282 131 278 282 135 284 minecraft:gray_concrete
fill 282 131 291 282 138 294 minecraft:gray_concrete
fill 282 131 301 282 138 304 minecraft:gray_concrete
fill 282 131 311 282 138 314 minecraft:gray_concrete
fill 285 131 275 288 138 275 minecraft:gray_concrete
fill 286 131 317 289 138 317 minecraft:gray_concrete
fill 295 131 275 298 138 275 minecraft:gray_concrete
fill 296 131 317 299 138 317 minecraft:gray_concrete
fill 299 131 277 299 139 279 minecraft:iron_block
fill 300 131 277 300 141 277 minecraft:iron_block
fill 300 131 279 300 147 280 minecraft:iron_block
fill 301 131 276 301 139 276 minecraft:iron_block
fill 301 131 280 301 148 281 minecraft:iron_block
fill 302 131 281 303 149 281 minecraft:iron_block
fill 303 131 276 304 138 276 minecraft:iron_block
fill 303 131 280 304 148 280 minecraft:iron_block
fill 304 131 277 305 139 277 minecraft:iron_block
fill 304 131 279 305 147 279 minecraft:iron_block
fill 305 131 275 308 138 275 minecraft:gray_concrete
fill 305 131 278 305 146 278 minecraft:iron_block
fill 306 131 317 309 131 317 minecraft:gray_concrete
fill 315 131 275 318 138 275 minecraft:gray_concrete
fill 316 131 317 319 138 317 minecraft:gray_concrete
setblock 324 131 276 minecraft:redstone_block
fill 324 131 277 324 138 279 minecraft:gray_concrete
fill 324 131 286 324 138 289 minecraft:gray_concrete
fill 324 131 296 324 138 299 minecraft:gray_concrete
fill 324 131 306 324 134 309 minecraft:gray_concrete
setblock 324 131 316 minecraft:gray_concrete
fill 282 132 277 282 145 277 minecraft:gray_concrete
setblock 283 132 278 minecraft:iron_block
setblock 283 132 288 minecraft:iron_block
setblock 283 132 298 minecraft:iron_block
setblock 283 132 308 minecraft:iron_block
fill 284 132 282 284 132 284 minecraft:iron_block
fill 284 132 309 284 132 311 minecraft:iron_block
fill 285 132 281 287 132 281 minecraft:iron_block
fill 285 132 285 287 132 285 minecraft:iron_block
fill 285 132 308 287 132 308 minecraft:iron_block
fill 285 132 312 287 132 312 minecraft:iron_block
setblock 285 132 316 minecraft:iron_block
fill 288 132 282 288 132 284 minecraft:iron_block
fill 288 132 309 288 132 311 minecraft:iron_block
setblock 288 132 313 minecraft:iron_block
setblock 289 132 276 minecraft:iron_block
setblock 290 132 311 minecraft:iron_block
setblock 295 132 316 minecraft:iron_block
fill 299 132 276 299 136 276 minecraft:iron_block
fill 299 132 280 299 148 280 minecraft:iron_block
fill 300 132 281 300 148 281 minecraft:iron_block
fill 304 132 281 304 148 281 minecraft:iron_block
fill 305 132 276 305 136 276 minecraft:iron_block
fill 305 132 280 305 148 280 minecraft:iron_block
setblock 305 132 316 minecraft:iron_block
fill 306 132 317 307 138 317 minecraft:gray_concrete
setblock 308 132 317 minecraft:redstone_block
setblock 309 132 276 minecraft:iron_block
fill 309 132 317 309 138 317 minecraft:gray_concrete
setblock 315 132 316 minecraft:iron_block
setblock 319 132 276 minecraft:iron_block
setblock 323 132 282 minecraft:iron_block
setblock 323 132 292 minecraft:iron_block
setblock 323 132 302 minecraft:iron_block
setblock 323 132 312 minecraft:iron_block
fill 324 132 276 324 138 276 minecraft:gray_concrete
setblock 324 132 316 minecraft:sea_lantern
setblock 285 133 278 minecraft:light[level=12]
setblock 285 133 285 minecraft:light[level=12]
setblock 285 133 292 minecraft:light[level=12]
setblock 285 133 299 minecraft:light[level=12]
setblock 285 133 306 minecraft:light[level=12]
setblock 285 133 313 minecraft:light[level=12]
setblock 292 133 278 minecraft:light[level=12]
setblock 292 133 285 minecraft:light[level=12]
setblock 292 133 292 minecraft:light[level=12]
setblock 292 133 299 minecraft:light[level=12]
setblock 292 133 306 minecraft:light[level=12]
setblock 292 133 313 minecraft:light[level=12]
fill 293 133 278 297 134 282 minecraft:gray_concrete
fill 295 133 276 295 133 277 minecraft:gray_concrete
fill 298 133 278 298 135 278 minecraft:iron_block
setblock 299 133 285 minecraft:light[level=12]
setblock 299 133 292 minecraft:light[level=12]
setblock 299 133 299 minecraft:light[level=12]
setblock 299 133 306 minecraft:light[level=12]
setblock 299 133 313 minecraft:light[level=12]
fill 302 133 282 302 149 282 minecraft:iron_block
fill 304 133 309 308 134 313 minecraft:gray_concrete
fill 306 133 278 306 135 278 minecraft:iron_block
setblock 306 133 285 minecraft:light[level=12]
setblock 306 133 292 minecraft:light[level=12]
setblock 306 133 299 minecraft:light[level=12]
setblock 306 133 306 minecraft:light[level=12]
fill 306 133 314 306 133 315 minecraft:gray_concrete
fill 308 133 317 308 138 317 minecraft:gray_concrete
setblock 313 133 278 minecraft:light[level=12]
setblock 313 133 285 minecraft:light[level=12]
setblock 313 133 292 minecraft:light[level=12]
setblock 313 133 299 minecraft:light[level=12]
setblock 313 133 306 minecraft:light[level=12]
setblock 313 133 313 minecraft:light[level=12]
setblock 320 133 278 minecraft:light[level=12]
setblock 320 133 285 minecraft:light[level=12]
setblock 320 133 292 minecraft:light[level=12]
setblock 320 133 299 minecraft:light[level=12]
setblock 320 133 306 minecraft:light[level=12]
setblock 320 133 313 minecraft:light[level=12]
fill 324 133 316 324 138 316 minecraft:gray_concrete
fill 299 134 281 299 148 281 minecraft:iron_block
fill 301 134 282 301 149 282 minecraft:iron_block
fill 303 134 282 303 149 282 minecraft:iron_block
fill 305 134 281 305 148 281 minecraft:iron_block
fill 283 135 280 283 135 283 minecraft:iron_block
fill 283 135 290 283 135 293 minecraft:iron_block
fill 283 135 300 283 135 303 minecraft:iron_block
fill 283 135 310 283 135 313 minecraft:iron_block
fill 284 135 276 287 135 276 minecraft:iron_block
setblock 286 135 278 minecraft:gray_concrete
fill 286 135 280 286 135 281 minecraft:gray_concrete
fill 287 135 277 288 135 277 minecraft:gray_concrete
setblock 287 135 281 minecraft:gray_concrete
fill 287 135 316 290 135 316 minecraft:iron_block
setblock 289 135 278 minecraft:gray_concrete
setblock 289 135 281 minecraft:gray_concrete
fill 290 135 279 290 135 280 minecraft:gray_concrete
fill 290 135 317 291 145 317 minecraft:gray_concrete
setblock 292 135 317 minecraft:sea_lantern
fill 293 135 317 295 145 317 minecraft:gray_concrete
fill 294 135 276 297 135 276 minecraft:iron_block
fill 297 135 316 300 135 316 minecraft:iron_block
fill 298 135 279 298 139 279 minecraft:iron_block
fill 300 135 282 300 149 282 minecraft:iron_block
fill 304 135 282 304 149 282 minecraft:iron_block
fill 306 135 276 307 135 276 minecraft:iron_block
fill 306 135 279 306 138 279 minecraft:iron_block
fill 307 135 316 310 135 316 minecraft:iron_block
fill 314 135 276 317 135 276 minecraft:iron_block
fill 317 135 316 320 135 316 minecraft:iron_block
fill 323 135 277 323 135 280 minecraft:iron_block
fill 323 135 287 323 135 290 minecraft:iron_block
fill 323 135 297 323 135 300 minecraft:iron_block
fill 323 135 307 323 135 310 minecraft:iron_block
fill 324 135 306 324 138 308 minecraft:gray_concrete
setblock 324 135 309 minecraft:sea_lantern
setblock 282 136 278 minecraft:sea_lantern
fill 282 136 279 282 138 284 minecraft:gray_concrete
fill 292 136 317 292 145 317 minecraft:gray_concrete
fill 302 136 283 302 149 283 minecraft:iron_block
fill 324 136 309 324 138 309 minecraft:gray_concrete
fill 282 137 278 282 145 278 minecraft:gray_concrete
fill 284 137 282 284 137 284 minecraft:iron_block
fill 284 137 309 284 137 311 minecraft:iron_block
setblock 285 137 278 minecraft:light[level=15]
fill 285 137 281 287 137 281 minecraft:iron_block
fill 285 137 285 287 137 285 minecraft:iron_block
setblock 285 137 286 minecraft:light[level=15]
setblock 285 137 294 minecraft:light[level=15]
setblock 285 137 302 minecraft:light[level=15]
fill 285 137 308 287 137 308 minecraft:iron_block
fill 285 137 312 287 137 312 minecraft:iron_block
fill 288 137 282 288 137 284 minecraft:iron_block
fill 288 137 309 288 137 311 minecraft:iron_block
setblock 288 137 313 minecraft:iron_block
setblock 289 137 314 minecraft:iron_block
setblock 290 137 311 minecraft:iron_block
fill 291 137 312 292 137 312 minecraft:iron_block
setblock 291 137 314 minecraft:iron_block
fill 292 137 311 294 137 311 minecraft:iron_block
fill 292 137 313 294 137 313 minecraft:iron_block
setblock 293 137 278 minecraft:light[level=15]
setblock 293 137 286 minecraft:light[level=15]
setblock 293 137 294 minecraft:light[level=15]
setblock 293 137 302 minecraft:light[level=15]
setblock 293 137 310 minecraft:light[level=15]
setblock 294 137 312 minecraft:iron_block
fill 299 137 282 299 148 282 minecraft:iron_block
fill 301 137 283 301 149 283 minecraft:iron_block
setblock 301 137 286 minecraft:light[level=15]
setblock 301 137 294 minecraft:light[level=15]
setblock 301 137 302 minecraft:light[level=15]
setblock 301 137 310 minecraft:light[level=15]
fill 303 137 283 303 149 283 minecraft:iron_block
fill 305 137 282 305 148 282 minecraft:iron_block
setblock 309 137 278 minecraft:light[level=15]
setblock 309 137 286 minecraft:light[level=15]
setblock 309 137 294 minecraft:light[level=15]
setblock 309 137 302 minecraft:light[level=15]
setblock 309 137 310 minecraft:light[level=15]
setblock 317 137 278 minecraft:light[level=15]
setblock 317 137 286 minecraft:light[level=15]
setblock 317 137 294 minecraft:light[level=15]
setblock 317 137 302 minecraft:light[level=15]
setblock 317 137 310 minecraft:light[level=15]
fill 324 137 310 324 145 311 minecraft:gray_concrete
setblock 324 137 312 minecraft:redstone_block
fill 324 137 313 324 145 315 minecraft:gray_concrete
setblock 283 138 278 minecraft:iron_block
setblock 283 138 288 minecraft:iron_block
setblock 283 138 298 minecraft:iron_block
setblock 283 138 308 minecraft:iron_block
setblock 285 138 316 minecraft:iron_block
setblock 289 138 276 minecraft:iron_block
fill 292 138 278 292 139 282 minecraft:iron_block
fill 293 138 277 293 139 278 minecraft:iron_block
fill 293 138 280 298 139 280 minecraft:iron_block
fill 293 138 282 293 139 283 minecraft:iron_block
fill 294 138 277 297 139 277 minecraft:iron_block
fill 294 138 283 297 139 283 minecraft:iron_block
fill 295 138 278 295 139 279 minecraft:iron_block
fill 295 138 281 295 139 282 minecraft:iron_block
setblock 295 138 316 minecraft:iron_block
fill 297 138 278 298 139 278 minecraft:iron_block
fill 297 138 282 298 139 282 minecraft:iron_block
fill 298 138 281 298 139 281 minecraft:iron_block
setblock 299 138 276 minecraft:iron_block
fill 300 138 283 300 149 283 minecraft:iron_block
fill 303 138 309 303 139 313 minecraft:iron_block
fill 304 138 283 304 149 283 minecraft:iron_block
fill 304 138 308 304 139 309 minecraft:iron_block
fill 304 138 311 309 139 311 minecraft:iron_block
fill 304 138 313 304 139 314 minecraft:iron_block
fill 305 138 308 308 139 308 minecraft:iron_block
fill 305 138 314 308 139 314 minecraft:iron_block
setblock 305 138 316 minecraft:iron_block
fill 306 138 280 306 147 280 minecraft:iron_block
fill 306 138 309 306 139 310 minecraft:iron_block
fill 306 138 312 306 139 313 minecraft:iron_block
fill 308 138 309 309 139 309 minecraft:iron_block
fill 308 138 313 309 139 313 minecraft:iron_block
setblock 309 138 276 minecraft:iron_block
fill 309 138 310 309 139 310 minecraft:iron_block
fill 309 138 312 309 139 312 minecraft:iron_block
setblock 315 138 316 minecraft:iron_block
setblock 319 138 276 minecraft:iron_block
setblock 323 138 282 minecraft:iron_block
setblock 323 138 292 minecraft:iron_block
setblock 323 138 302 minecraft:iron_block
setblock 323 138 312 minecraft:iron_block
fill 324 138 312 324 145 312 minecraft:gray_concrete
fill 282 139 279 282 145 280 minecraft:gray_concrete
fill 282 139 281 282 139 284 minecraft:pearlescent_froglight
fill 282 139 291 282 139 294 minecraft:pearlescent_froglight
fill 282 139 301 282 139 304 minecraft:pearlescent_froglight
fill 282 139 311 282 139 314 minecraft:pearlescent_froglight
fill 285 139 275 288 139 275 minecraft:pearlescent_froglight
setblock 285 139 278 minecraft:light[level=12]
setblock 285 139 285 minecraft:light[level=12]
setblock 285 139 292 minecraft:light[level=12]
setblock 285 139 299 minecraft:light[level=12]
setblock 285 139 306 minecraft:light[level=12]
setblock 285 139 313 minecraft:light[level=12]
fill 286 139 317 289 139 317 minecraft:pearlescent_froglight
setblock 292 139 285 minecraft:light[level=12]
setblock 292 139 292 minecraft:light[level=12]
setblock 292 139 299 minecraft:light[level=12]
setblock 292 139 306 minecraft:light[level=12]
setblock 292 139 313 minecraft:light[level=12]
fill 295 139 275 298 139 275 minecraft:pearlescent_froglight
fill 296 139 317 299 139 317 minecraft:pearlescent_froglight
setblock 299 139 285 minecraft:light[level=12]
setblock 299 139 292 minecraft:light[level=12]
setblock 299 139 299 minecraft:light[level=12]
setblock 299 139 306 minecraft:light[level=12]
setblock 299 139 313 minecraft:light[level=12]
fill 302 139 284 302 149 284 minecraft:iron_block
setblock 303 139 276 minecraft:iron_block
fill 305 139 275 308 139 275 minecraft:pearlescent_froglight
setblock 306 139 278 minecraft:light[level=12]
setblock 306 139 285 minecraft:light[level=12]
setblock 306 139 292 minecraft:light[level=12]
setblock 306 139 299 minecraft:light[level=12]
setblock 306 139 306 minecraft:light[level=12]
fill 306 139 317 309 139 317 minecraft:pearlescent_froglight
setblock 313 139 278 minecraft:light[level=12]
setblock 313 139 285 minecraft:light[level=12]
setblock 313 139 292 minecraft:light[level=12]
setblock 313 139 299 minecraft:light[level=12]
setblock 313 139 306 minecraft:light[level=12]
setblock 313 139 313 minecraft:light[level=12]
fill 315 139 275 318 139 275 minecraft:pearlescent_froglight
fill 316 139 317 319 139 317 minecraft:pearlescent_froglight
setblock 320 139 278 minecraft:light[level=12]
setblock 320 139 285 minecraft:light[level=12]
setblock 320 139 292 minecraft:light[level=12]
setblock 320 139 299 minecraft:light[level=12]
setblock 320 139 306 minecraft:light[level=12]
setblock 320 139 313 minecraft:light[level=12]
fill 324 139 276 324 139 279 minecraft:pearlescent_froglight
fill 324 139 286 324 139 289 minecraft:pearlescent_froglight
fill 324 139 296 324 139 299 minecraft:pearlescent_froglight
fill 324 139 306 324 139 309 minecraft:pearlescent_froglight
setblock 324 139 316 minecraft:pearlescent_froglight
fill 282 140 281 282 145 284 minecraft:gray_concrete
fill 282 140 291 282 145 294 minecraft:gray_concrete
fill 282 140 301 282 145 304 minecraft:gray_concrete
fill 282 140 311 282 145 314 minecraft:gray_concrete
fill 285 140 275 288 145 275 minecraft:gray_concrete
fill 286 140 317 289 145 317 minecraft:gray_concrete
fill 295 140 275 298 145 275 minecraft:gray_concrete
fill 296 140 317 299 145 317 minecraft:gray_concrete
fill 298 140 280 298 147 280 minecraft:iron_block
fill 299 140 278 299 146 279 minecraft:iron_block
fill 299 140 283 299 148 283 minecraft:iron_block
fill 300 140 284 301 149 284 minecraft:iron_block
fill 301 140 285 303 149 285 minecraft:iron_block
fill 303 140 284 304 149 284 minecraft:iron_block
fill 304 140 277 304 141 277 minecraft:iron_block
fill 305 140 275 308 145 275 minecraft:gray_concrete
fill 305 140 283 305 148 283 minecraft:iron_block
fill 306 140 317 309 145 317 minecraft:gray_concrete
fill 315 140 275 318 145 275 minecraft:gray_concrete
fill 316 140 317 319 145 317 minecraft:gray_concrete
fill 324 140 276 324 145 279 minecraft:gray_concrete
fill 324 140 286 324 144 289 minecraft:gray_concrete
fill 324 140 296 324 145 299 minecraft:gray_concrete
fill 324 140 306 324 145 309 minecraft:gray_concrete
fill 324 140 316 324 145 316 minecraft:gray_concrete
fill 288 141 302 288 153 302 minecraft:iron_block
fill 298 141 281 298 147 284 minecraft:iron_block
fill 299 141 284 299 148 286 minecraft:iron_block
fill 300 141 285 300 148 286 minecraft:iron_block
fill 301 141 286 303 148 287 minecraft:iron_block
fill 304 141 285 305 148 286 minecraft:iron_block
fill 305 141 284 306 148 284 minecraft:iron_block
fill 306 141 281 306 147 283 minecraft:iron_block
fill 284 142 282 284 142 284 minecraft:iron_block
fill 284 142 309 284 142 311 minecraft:iron_block
fill 285 142 281 287 142 281 minecraft:iron_block
fill 285 142 285 287 142 285 minecraft:iron_block
fill 285 142 308 287 142 308 minecraft:iron_block
fill 285 142 312 287 142 312 minecraft:iron_block
fill 288 142 282 288 142 284 minecraft:iron_block
fill 288 142 309 288 142 311 minecraft:iron_block
setblock 288 142 313 minecraft:iron_block
setblock 290 142 311 minecraft:iron_block
fill 297 142 281 297 147 285 minecraft:iron_block
fill 298 142 285 298 147 286 minecraft:iron_block
fill 299 142 287 300 147 287 minecraft:iron_block
fill 300 142 288 304 147 288 minecraft:iron_block
fill 304 142 287 305 147 287 minecraft:iron_block
fill 306 142 285 306 147 286 minecraft:iron_block
fill 307 142 281 307 147 285 minecraft:iron_block
setblock 286 143 278 minecraft:gray_concrete
fill 286 143 280 286 143 281 minecraft:gray_concrete
fill 287 143 277 288 143 277 minecraft:gray_concrete
setblock 287 143 281 minecraft:gray_concrete
setblock 289 143 278 minecraft:gray_concrete
setblock 289 143 281 minecraft:gray_concrete
fill 290 143 279 290 143 280 minecraft:gray_concrete
fill 296 143 283 296 146 283 minecraft:iron_block
fill 297 143 280 297 146 280 minecraft:iron_block
fill 297 143 286 297 146 286 minecraft:iron_block
fill 298 143 279 298 146 279 minecraft:iron_block
fill 298 143 287 298 146 287 minecraft:iron_block
fill 299 143 288 299 146 288 minecraft:iron_block
fill 302 143 277 302 146 277 minecraft:iron_block
fill 302 143 289 302 146 289 minecraft:iron_block
fill 305 143 288 305 146 288 minecraft:iron_block
fill 306 143 279 306 146 279 minecraft:iron_block
fill 306 143 287 306 146 287 minecraft:iron_block
fill 307 143 280 307 146 280 minecraft:iron_block
fill 307 143 286 307 146 286 minecraft:iron_block
fill 308 143 283 308 146 283 minecraft:iron_block
setblock 283 144 278 minecraft:iron_block
fill 283 144 280 283 144 283 minecraft:iron_block
setblock 283 144 288 minecraft:iron_block
fill 283 144 290 283 144 293 minecraft:iron_block
setblock 283 144 298 minecraft:iron_block
fill 283 144 300 283 144 303 minecraft:iron_block
setblock 283 144 308 minecraft:iron_block
fill 283 144 310 283 144 313 minecraft:iron_block
fill 284 144 276 287 144 276 minecraft:iron_block
setblock 285 144 316 minecraft:iron_block
fill 287 144 316 290 144 316 minecraft:iron_block
setblock 289 144 276 minecraft:iron_block
fill 294 144 276 297 144 276 minecraft:iron_block
setblock 295 144 316 minecraft:iron_block
fill 296 144 282 296 145 282 minecraft:iron_block
fill 296 144 284 296 145 284 minecraft:iron_block
fill 297 144 316 300 144 316 minecraft:iron_block
setblock 299 144 276 minecraft:iron_block
fill 301 144 277 301 145 277 minecraft:iron_block
fill 301 144 289 301 145 289 minecraft:iron_block
fill 303 144 277 303 145 277 minecraft:iron_block
fill 303 144 289 303 145 289 minecraft:iron_block
fill 304 144 276 307 144 276 minecraft:iron_block
setblock 305 144 316 minecraft:iron_block
fill 307 144 316 310 144 316 minecraft:iron_block
schedule function dropper:buildpart/66_3 1t
