fill 84 217 281 85 219 281 minecraft:dark_oak_planks
fill 85 217 278 85 219 278 minecraft:dark_oak_planks
fill 85 217 280 85 219 280 minecraft:dark_oak_planks
fill 89 217 292 89 221 292 minecraft:cyan_concrete
fill 47 218 278 47 241 278 minecraft:cyan_concrete
setblock 48 218 282 minecraft:spruce_planks
setblock 48 218 289 minecraft:spruce_planks
setblock 48 218 296 minecraft:spruce_planks
setblock 48 218 303 minecraft:spruce_planks
setblock 48 218 310 minecraft:spruce_planks
setblock 49 218 276 minecraft:spruce_planks
setblock 49 218 316 minecraft:spruce_planks
setblock 50 218 278 minecraft:light[level=15]
setblock 50 218 285 minecraft:light[level=12]
setblock 50 218 286 minecraft:light[level=15]
setblock 50 218 292 minecraft:light[level=12]
setblock 50 218 294 minecraft:light[level=15]
setblock 50 218 299 minecraft:light[level=12]
setblock 50 218 302 minecraft:light[level=15]
setblock 50 218 306 minecraft:light[level=12]
setblock 50 218 310 minecraft:light[level=15]
setblock 50 218 313 minecraft:light[level=12]
setblock 56 218 276 minecraft:spruce_planks
setblock 56 218 316 minecraft:spruce_planks
setblock 57 218 278 minecraft:light[level=12]
setblock 57 218 285 minecraft:light[level=12]
setblock 57 218 292 minecraft:light[level=12]
setblock 57 218 299 minecraft:light[level=12]
setblock 57 218 306 minecraft:light[level=12]
setblock 57 218 313 minecraft:light[level=12]
setblock 58 218 278 minecraft:light[level=15]
setblock 58 218 286 minecraft:light[level=15]
setblock 58 218 294 minecraft:light[level=15]
setblock 58 218 302 minecraft:light[level=15]
setblock 58 218 310 minecraft:light[level=15]
setblock 63 218 276 minecraft:spruce_planks
setblock 63 218 316 minecraft:spruce_planks
setblock 64 218 278 minecraft:light[level=12]
setblock 64 218 285 minecraft:light[level=12]
setblock 64 218 292 minecraft:light[level=12]
setblock 64 218 306 minecraft:light[level=12]
setblock 64 218 313 minecraft:light[level=12]
setblock 66 218 278 minecraft:light[level=15]
setblock 66 218 286 minecraft:light[level=15]
setblock 66 218 294 minecraft:light[level=15]
setblock 66 218 302 minecraft:light[level=15]
setblock 66 218 310 minecraft:light[level=15]
setblock 70 218 276 minecraft:spruce_planks
setblock 70 218 316 minecraft:spruce_planks
setblock 71 218 278 minecraft:light[level=12]
setblock 71 218 285 minecraft:light[level=12]
setblock 71 218 292 minecraft:light[level=12]
setblock 71 218 299 minecraft:light[level=12]
setblock 71 218 306 minecraft:light[level=12]
setblock 71 218 313 minecraft:light[level=12]
fill 73 218 317 73 242 317 minecraft:cyan_concrete
setblock 74 218 278 minecraft:light[level=15]
setblock 74 218 286 minecraft:light[level=15]
setblock 74 218 294 minecraft:light[level=15]
setblock 74 218 302 minecraft:light[level=15]
setblock 74 218 310 minecraft:light[level=15]
setblock 74 218 317 minecraft:white_wool
fill 75 218 317 80 219 317 minecraft:cyan_concrete
setblock 77 218 276 minecraft:spruce_planks
setblock 77 218 316 minecraft:spruce_planks
setblock 78 218 278 minecraft:light[level=12]
setblock 78 218 285 minecraft:light[level=12]
setblock 78 218 292 minecraft:light[level=12]
setblock 78 218 299 minecraft:light[level=12]
setblock 78 218 306 minecraft:light[level=12]
setblock 78 218 313 minecraft:light[level=12]
fill 81 218 279 81 219 279 minecraft:dark_oak_planks
setblock 82 218 286 minecraft:light[level=15]
setblock 82 218 294 minecraft:light[level=15]
setblock 82 218 302 minecraft:light[level=15]
setblock 82 218 310 minecraft:light[level=15]
fill 83 218 277 83 219 277 minecraft:dark_oak_planks
setblock 84 218 276 minecraft:spruce_planks
setblock 84 218 316 minecraft:spruce_planks
setblock 85 218 285 minecraft:light[level=12]
setblock 85 218 292 minecraft:light[level=12]
setblock 85 218 299 minecraft:light[level=12]
setblock 85 218 306 minecraft:light[level=12]
setblock 85 218 313 minecraft:light[level=12]
setblock 88 218 279 minecraft:spruce_planks
setblock 88 218 286 minecraft:spruce_planks
setblock 88 218 293 minecraft:spruce_planks
setblock 88 218 300 minecraft:spruce_planks
setblock 88 218 307 minecraft:spruce_planks
setblock 88 218 314 minecraft:spruce_planks
setblock 89 218 288 minecraft:light_blue_wool
setblock 48 219 276 minecraft:spruce_planks
setblock 48 219 283 minecraft:spruce_planks
setblock 48 219 290 minecraft:spruce_planks
setblock 48 219 297 minecraft:spruce_planks
setblock 48 219 304 minecraft:spruce_planks
setblock 48 219 311 minecraft:spruce_planks
setblock 50 219 316 minecraft:spruce_planks
setblock 55 219 276 minecraft:spruce_planks
setblock 57 219 316 minecraft:spruce_planks
setblock 62 219 276 minecraft:spruce_planks
setblock 64 219 316 minecraft:spruce_planks
setblock 69 219 276 minecraft:spruce_planks
setblock 71 219 316 minecraft:spruce_planks
fill 74 219 317 74 249 317 minecraft:cyan_concrete
setblock 76 219 276 minecraft:spruce_planks
setblock 78 219 316 minecraft:spruce_planks
setblock 80 219 275 minecraft:cyan_concrete
setblock 81 219 275 minecraft:white_wool
setblock 83 219 276 minecraft:spruce_planks
setblock 85 219 316 minecraft:spruce_planks
setblock 88 219 278 minecraft:spruce_planks
setblock 88 219 285 minecraft:spruce_planks
setblock 88 219 292 minecraft:spruce_planks
setblock 88 219 299 minecraft:spruce_planks
setblock 88 219 306 minecraft:spruce_planks
setblock 88 219 313 minecraft:spruce_planks
fill 89 219 288 89 245 288 minecraft:cyan_concrete
fill 89 219 293 89 245 293 minecraft:cyan_concrete
setblock 89 219 294 minecraft:white_wool
fill 47 220 299 47 247 300 minecraft:cyan_concrete
setblock 47 220 301 minecraft:white_wool
fill 75 220 317 75 249 317 minecraft:cyan_concrete
setblock 76 220 317 minecraft:white_wool
fill 77 220 317 80 223 317 minecraft:cyan_concrete
setblock 80 220 275 minecraft:light_blue_wool
fill 81 220 275 81 238 275 minecraft:cyan_concrete
fill 89 220 294 89 249 294 minecraft:cyan_concrete
setblock 89 220 296 minecraft:light_blue_wool
fill 89 220 297 89 235 298 minecraft:cyan_concrete
setblock 47 221 279 minecraft:light_blue_wool
fill 47 221 301 47 235 301 minecraft:cyan_concrete
fill 76 221 317 76 232 317 minecraft:cyan_concrete
fill 80 221 275 80 238 275 minecraft:cyan_concrete
fill 89 221 296 89 249 296 minecraft:cyan_concrete
setblock 89 221 312 minecraft:light_blue_wool
fill 47 222 279 47 249 279 minecraft:cyan_concrete
fill 68 222 317 71 234 317 minecraft:cyan_concrete
setblock 72 222 317 minecraft:light_blue_wool
setblock 89 222 292 minecraft:light_blue_wool
setblock 89 222 300 minecraft:white_wool
fill 89 222 301 89 246 304 minecraft:cyan_concrete
fill 89 222 312 89 238 312 minecraft:cyan_concrete
fill 47 223 288 47 246 288 minecraft:cyan_concrete
setblock 47 223 289 minecraft:light_blue_wool
fill 47 223 290 47 249 290 minecraft:cyan_concrete
setblock 56 223 317 minecraft:light_blue_wool
fill 67 223 275 71 247 275 minecraft:cyan_concrete
setblock 72 223 275 minecraft:white_wool
fill 72 223 317 72 249 317 minecraft:cyan_concrete
fill 73 223 275 73 245 275 minecraft:cyan_concrete
fill 89 223 292 89 245 292 minecraft:cyan_concrete
fill 89 223 300 89 245 300 minecraft:cyan_concrete
fill 47 224 289 47 249 289 minecraft:cyan_concrete
setblock 50 224 278 minecraft:light[level=12]
setblock 50 224 285 minecraft:light[level=12]
setblock 50 224 292 minecraft:light[level=12]
setblock 50 224 299 minecraft:light[level=12]
setblock 50 224 306 minecraft:light[level=12]
setblock 50 224 313 minecraft:light[level=12]
fill 56 224 317 56 245 317 minecraft:cyan_concrete
setblock 57 224 278 minecraft:light[level=12]
setblock 57 224 285 minecraft:light[level=12]
setblock 57 224 292 minecraft:light[level=12]
setblock 57 224 299 minecraft:light[level=12]
setblock 57 224 306 minecraft:light[level=12]
setblock 57 224 313 minecraft:light[level=12]
setblock 64 224 278 minecraft:light[level=12]
setblock 64 224 285 minecraft:light[level=12]
setblock 64 224 292 minecraft:light[level=12]
setblock 64 224 306 minecraft:light[level=12]
setblock 64 224 313 minecraft:light[level=12]
setblock 71 224 278 minecraft:light[level=12]
setblock 71 224 285 minecraft:light[level=12]
setblock 71 224 292 minecraft:light[level=12]
setblock 71 224 299 minecraft:light[level=12]
setblock 71 224 306 minecraft:light[level=12]
setblock 71 224 313 minecraft:light[level=12]
fill 72 224 275 72 246 275 minecraft:cyan_concrete
fill 77 224 317 77 228 317 minecraft:cyan_concrete
setblock 78 224 278 minecraft:light[level=12]
setblock 78 224 285 minecraft:light[level=12]
setblock 78 224 292 minecraft:light[level=12]
setblock 78 224 299 minecraft:light[level=12]
setblock 78 224 306 minecraft:light[level=12]
setblock 78 224 313 minecraft:light[level=12]
setblock 78 224 317 minecraft:white_wool
fill 79 224 317 80 224 317 minecraft:cyan_concrete
setblock 85 224 278 minecraft:light[level=12]
setblock 85 224 285 minecraft:light[level=12]
setblock 85 224 292 minecraft:light[level=12]
setblock 85 224 299 minecraft:light[level=12]
setblock 85 224 306 minecraft:light[level=12]
setblock 85 224 313 minecraft:light[level=12]
fill 57 225 296 57 225 297 minecraft:spruce_planks
fill 57 225 298 59 226 298 minecraft:dark_oak_planks
fill 57 225 299 57 225 300 minecraft:spruce_planks
fill 58 225 294 58 225 296 minecraft:spruce_planks
fill 58 225 297 60 225 297 minecraft:dark_oak_planks
fill 58 225 299 60 225 299 minecraft:dark_oak_planks
fill 58 225 300 58 225 302 minecraft:spruce_planks
fill 59 225 293 61 225 295 minecraft:spruce_planks
fill 59 225 296 60 225 296 minecraft:dark_oak_planks
fill 59 225 300 60 225 300 minecraft:dark_oak_planks
fill 59 225 301 61 225 303 minecraft:spruce_planks
fill 61 225 292 65 225 292 minecraft:spruce_planks
fill 61 225 304 65 225 304 minecraft:spruce_planks
fill 62 225 293 67 225 294 minecraft:spruce_planks
setblock 62 225 295 minecraft:dark_oak_planks
setblock 62 225 301 minecraft:dark_oak_planks
fill 62 225 302 67 225 303 minecraft:spruce_planks
setblock 64 225 295 minecraft:dark_oak_planks
setblock 64 225 301 minecraft:dark_oak_planks
fill 65 225 295 68 225 295 minecraft:spruce_planks
fill 65 225 301 68 225 301 minecraft:spruce_planks
fill 66 225 296 67 225 297 minecraft:dark_oak_planks
fill 66 225 299 67 225 300 minecraft:dark_oak_planks
fill 67 225 298 69 226 298 minecraft:dark_oak_planks
setblock 68 225 294 minecraft:spruce_planks
fill 68 225 296 69 225 296 minecraft:spruce_planks
fill 68 225 297 68 226 297 minecraft:dark_oak_planks
fill 68 225 299 68 226 299 minecraft:dark_oak_planks
fill 68 225 300 69 225 300 minecraft:spruce_planks
setblock 68 225 302 minecraft:spruce_planks
setblock 69 225 297 minecraft:spruce_planks
setblock 69 225 299 minecraft:spruce_planks
fill 78 225 317 78 250 317 minecraft:cyan_concrete
setblock 79 225 317 minecraft:light_blue_wool
fill 80 225 317 80 249 317 minecraft:cyan_concrete
fill 47 226 275 47 249 275 minecraft:cyan_concrete
setblock 47 226 276 minecraft:white_wool
fill 48 226 276 48 226 277 minecraft:white_stained_glass
setblock 48 226 278 minecraft:light_blue_stained_glass
fill 48 226 279 48 226 281 minecraft:white_stained_glass
setblock 48 226 282 minecraft:light_blue_stained_glass
fill 48 226 283 48 226 285 minecraft:white_stained_glass
setblock 48 226 286 minecraft:light_blue_stained_glass
fill 48 226 287 48 226 289 minecraft:white_stained_glass
setblock 48 226 290 minecraft:light_blue_stained_glass
fill 48 226 291 48 226 293 minecraft:white_stained_glass
setblock 48 226 294 minecraft:light_blue_stained_glass
fill 48 226 295 48 226 297 minecraft:white_stained_glass
setblock 48 226 298 minecraft:light_blue_stained_glass
fill 48 226 299 48 226 301 minecraft:white_stained_glass
setblock 48 226 302 minecraft:light_blue_stained_glass
fill 48 226 303 48 226 305 minecraft:white_stained_glass
setblock 48 226 306 minecraft:light_blue_stained_glass
fill 48 226 307 48 226 309 minecraft:white_stained_glass
setblock 48 226 310 minecraft:light_blue_stained_glass
fill 48 226 311 48 226 313 minecraft:white_stained_glass
setblock 48 226 314 minecraft:light_blue_stained_glass
fill 48 226 315 49 226 316 minecraft:white_stained_glass
setblock 49 226 276 minecraft:white_stained_glass
setblock 49 226 277 minecraft:light_blue_stained_glass
fill 49 226 278 49 226 280 minecraft:white_stained_glass
setblock 49 226 281 minecraft:light_blue_stained_glass
fill 49 226 282 49 226 284 minecraft:white_stained_glass
setblock 49 226 285 minecraft:light_blue_stained_glass
fill 49 226 286 49 226 288 minecraft:white_stained_glass
setblock 49 226 289 minecraft:light_blue_stained_glass
fill 49 226 290 49 226 292 minecraft:white_stained_glass
setblock 49 226 293 minecraft:light_blue_stained_glass
fill 49 226 294 49 226 296 minecraft:white_stained_glass
setblock 49 226 297 minecraft:light_blue_stained_glass
fill 49 226 298 49 226 300 minecraft:white_stained_glass
setblock 49 226 301 minecraft:light_blue_stained_glass
fill 49 226 302 49 226 304 minecraft:white_stained_glass
setblock 49 226 305 minecraft:light_blue_stained_glass
fill 49 226 306 49 226 308 minecraft:white_stained_glass
setblock 49 226 309 minecraft:light_blue_stained_glass
fill 49 226 310 49 226 312 minecraft:white_stained_glass
setblock 49 226 313 minecraft:light_blue_stained_glass
fill 49 226 314 51 226 314 minecraft:white_stained_glass
setblock 50 226 276 minecraft:light_blue_stained_glass
fill 50 226 277 50 226 279 minecraft:white_stained_glass
setblock 50 226 280 minecraft:light_blue_stained_glass
fill 50 226 281 50 226 283 minecraft:white_stained_glass
setblock 50 226 284 minecraft:light_blue_stained_glass
fill 50 226 285 50 226 287 minecraft:white_stained_glass
setblock 50 226 288 minecraft:light_blue_stained_glass
fill 50 226 289 50 226 291 minecraft:white_stained_glass
setblock 50 226 292 minecraft:light_blue_stained_glass
fill 50 226 293 50 226 295 minecraft:white_stained_glass
setblock 50 226 296 minecraft:light_blue_stained_glass
fill 50 226 297 50 226 299 minecraft:white_stained_glass
setblock 50 226 300 minecraft:light_blue_stained_glass
fill 50 226 301 50 226 303 minecraft:white_stained_glass
setblock 50 226 304 minecraft:light_blue_stained_glass
fill 50 226 305 50 226 307 minecraft:white_stained_glass
setblock 50 226 308 minecraft:light_blue_stained_glass
fill 50 226 309 50 226 311 minecraft:white_stained_glass
setblock 50 226 312 minecraft:light_blue_stained_glass
fill 50 226 313 52 226 313 minecraft:white_stained_glass
setblock 50 226 315 minecraft:white_stained_glass
setblock 50 226 316 minecraft:light_blue_stained_glass
fill 51 226 276 51 226 278 minecraft:white_stained_glass
setblock 51 226 279 minecraft:light_blue_stained_glass
fill 51 226 281 51 226 282 minecraft:white_stained_glass
setblock 51 226 283 minecraft:light_blue_stained_glass
fill 51 226 284 51 226 286 minecraft:white_stained_glass
setblock 51 226 287 minecraft:light_blue_stained_glass
fill 51 226 288 51 226 290 minecraft:white_stained_glass
setblock 51 226 291 minecraft:light_blue_stained_glass
fill 51 226 292 51 226 294 minecraft:white_stained_glass
setblock 51 226 295 minecraft:light_blue_stained_glass
fill 51 226 296 51 226 298 minecraft:white_stained_glass
setblock 51 226 299 minecraft:light_blue_stained_glass
fill 51 226 300 51 226 302 minecraft:white_stained_glass
setblock 51 226 303 minecraft:light_blue_stained_glass
fill 51 226 304 51 226 306 minecraft:white_stained_glass
setblock 51 226 307 minecraft:light_blue_stained_glass
fill 51 226 308 51 226 310 minecraft:white_stained_glass
setblock 51 226 311 minecraft:light_blue_stained_glass
fill 51 226 312 53 226 312 minecraft:white_stained_glass
setblock 51 226 315 minecraft:light_blue_stained_glass
fill 51 226 316 53 226 316 minecraft:white_stained_glass
fill 52 226 276 52 226 277 minecraft:white_stained_glass
setblock 52 226 278 minecraft:light_blue_stained_glass
setblock 52 226 282 minecraft:light_blue_stained_glass
fill 52 226 283 52 226 285 minecraft:white_stained_glass
setblock 52 226 286 minecraft:light_blue_stained_glass
fill 52 226 287 52 226 289 minecraft:white_stained_glass
setblock 52 226 290 minecraft:light_blue_stained_glass
fill 52 226 291 52 226 293 minecraft:white_stained_glass
setblock 52 226 294 minecraft:light_blue_stained_glass
fill 52 226 295 52 226 297 minecraft:white_stained_glass
setblock 52 226 298 minecraft:light_blue_stained_glass
fill 52 226 299 52 226 301 minecraft:white_stained_glass
setblock 52 226 302 minecraft:light_blue_stained_glass
fill 52 226 303 52 226 305 minecraft:white_stained_glass
setblock 52 226 306 minecraft:light_blue_stained_glass
fill 52 226 307 52 226 309 minecraft:white_stained_glass
setblock 52 226 310 minecraft:light_blue_stained_glass
fill 52 226 311 54 226 311 minecraft:white_stained_glass
setblock 52 226 314 minecraft:light_blue_stained_glass
fill 52 226 315 54 226 315 minecraft:white_stained_glass
setblock 53 226 276 minecraft:white_stained_glass
setblock 53 226 277 minecraft:light_blue_stained_glass
fill 53 226 278 54 226 279 minecraft:white_stained_glass
setblock 53 226 281 minecraft:light_blue_stained_glass
fill 53 226 282 53 226 284 minecraft:white_stained_glass
setblock 53 226 285 minecraft:light_blue_stained_glass
fill 53 226 286 53 226 288 minecraft:white_stained_glass
setblock 53 226 289 minecraft:light_blue_stained_glass
fill 53 226 290 53 226 292 minecraft:white_stained_glass
setblock 53 226 293 minecraft:light_blue_stained_glass
fill 53 226 294 53 226 296 minecraft:white_stained_glass
setblock 53 226 297 minecraft:light_blue_stained_glass
fill 53 226 298 53 226 300 minecraft:white_stained_glass
setblock 53 226 301 minecraft:light_blue_stained_glass
fill 53 226 302 53 226 304 minecraft:white_stained_glass
setblock 53 226 305 minecraft:light_blue_stained_glass
fill 53 226 306 53 226 308 minecraft:white_stained_glass
setblock 53 226 309 minecraft:light_blue_stained_glass
fill 53 226 310 55 226 310 minecraft:white_stained_glass
setblock 53 226 313 minecraft:light_blue_stained_glass
fill 53 226 314 55 226 314 minecraft:white_stained_glass
setblock 54 226 276 minecraft:light_blue_stained_glass
fill 54 226 277 56 226 277 minecraft:white_stained_glass
setblock 54 226 280 minecraft:light_blue_stained_glass
fill 54 226 281 54 226 283 minecraft:white_stained_glass
setblock 54 226 284 minecraft:light_blue_stained_glass
fill 54 226 285 54 226 287 minecraft:white_stained_glass
setblock 54 226 288 minecraft:light_blue_stained_glass
fill 54 226 289 54 226 291 minecraft:white_stained_glass
setblock 54 226 292 minecraft:light_blue_stained_glass
fill 54 226 293 54 226 295 minecraft:white_stained_glass
fill 54 226 296 56 226 300 minecraft:dark_oak_planks
fill 54 226 301 54 226 303 minecraft:white_stained_glass
setblock 54 226 304 minecraft:light_blue_stained_glass
fill 54 226 305 54 226 307 minecraft:white_stained_glass
setblock 54 226 308 minecraft:light_blue_stained_glass
fill 54 226 309 56 226 309 minecraft:white_stained_glass
setblock 54 226 312 minecraft:light_blue_stained_glass
fill 54 226 313 56 226 313 minecraft:white_stained_glass
setblock 54 226 316 minecraft:light_blue_stained_glass
fill 55 226 276 57 226 276 minecraft:white_stained_glass
setblock 55 226 278 minecraft:white_stained_glass
setblock 55 226 279 minecraft:light_blue_stained_glass
fill 55 226 280 55 226 282 minecraft:white_stained_glass
setblock 55 226 283 minecraft:light_blue_stained_glass
fill 55 226 284 55 226 286 minecraft:white_stained_glass
setblock 55 226 287 minecraft:light_blue_stained_glass
fill 55 226 288 55 226 290 minecraft:white_stained_glass
setblock 55 226 291 minecraft:light_blue_stained_glass
fill 55 226 292 55 226 294 minecraft:white_stained_glass
setblock 55 226 295 minecraft:light_blue_stained_glass
fill 55 226 301 55 226 302 minecraft:white_stained_glass
setblock 55 226 303 minecraft:light_blue_stained_glass
fill 55 226 304 55 226 306 minecraft:white_stained_glass
setblock 55 226 307 minecraft:light_blue_stained_glass
fill 55 226 308 57 226 308 minecraft:white_stained_glass
setblock 55 226 311 minecraft:light_blue_stained_glass
fill 55 226 312 57 226 312 minecraft:white_stained_glass
setblock 55 226 315 minecraft:light_blue_stained_glass
fill 55 226 316 57 226 316 minecraft:white_stained_glass
setblock 56 226 278 minecraft:light_blue_stained_glass
fill 56 226 279 56 226 281 minecraft:white_stained_glass
setblock 56 226 282 minecraft:light_blue_stained_glass
fill 56 226 283 56 226 285 minecraft:white_stained_glass
setblock 56 226 286 minecraft:light_blue_stained_glass
fill 56 226 287 56 226 289 minecraft:white_stained_glass
setblock 56 226 290 minecraft:light_blue_stained_glass
fill 56 226 291 56 226 293 minecraft:white_stained_glass
setblock 56 226 294 minecraft:light_blue_stained_glass
fill 56 226 295 60 226 295 minecraft:dark_oak_planks
fill 56 226 301 60 226 301 minecraft:dark_oak_planks
setblock 56 226 302 minecraft:light_blue_stained_glass
fill 56 226 303 56 226 305 minecraft:white_stained_glass
setblock 56 226 306 minecraft:light_blue_stained_glass
fill 56 226 307 58 226 307 minecraft:white_stained_glass
setblock 56 226 310 minecraft:light_blue_stained_glass
fill 56 226 311 58 226 311 minecraft:white_stained_glass
setblock 56 226 314 minecraft:light_blue_stained_glass
fill 56 226 315 58 226 315 minecraft:white_stained_glass
setblock 57 226 277 minecraft:light_blue_stained_glass
fill 57 226 278 57 226 280 minecraft:white_stained_glass
setblock 57 226 281 minecraft:light_blue_stained_glass
fill 57 226 282 57 226 284 minecraft:white_stained_glass
setblock 57 226 285 minecraft:light_blue_stained_glass
fill 57 226 286 57 226 288 minecraft:white_stained_glass
setblock 57 226 289 minecraft:light_blue_stained_glass
fill 57 226 290 57 226 292 minecraft:white_stained_glass
setblock 57 226 293 minecraft:light_blue_stained_glass
setblock 57 226 294 minecraft:white_stained_glass
fill 57 226 296 59 226 297 minecraft:dark_oak_planks
fill 57 226 299 59 226 300 minecraft:dark_oak_planks
fill 57 226 302 57 226 304 minecraft:white_stained_glass
setblock 57 226 305 minecraft:light_blue_stained_glass
fill 57 226 306 59 226 306 minecraft:white_stained_glass
setblock 57 226 309 minecraft:light_blue_stained_glass
fill 57 226 310 59 226 310 minecraft:white_stained_glass
setblock 57 226 313 minecraft:light_blue_stained_glass
fill 57 226 314 59 226 314 minecraft:white_stained_glass
setblock 58 226 276 minecraft:light_blue_stained_glass
fill 58 226 277 58 226 279 minecraft:white_stained_glass
setblock 58 226 280 minecraft:light_blue_stained_glass
fill 58 226 281 58 226 283 minecraft:white_stained_glass
setblock 58 226 284 minecraft:light_blue_stained_glass
fill 58 226 285 58 226 287 minecraft:white_stained_glass
setblock 58 226 288 minecraft:light_blue_stained_glass
fill 58 226 289 58 226 291 minecraft:white_stained_glass
setblock 58 226 292 minecraft:light_blue_stained_glass
setblock 58 226 293 minecraft:white_stained_glass
fill 58 226 294 68 226 294 minecraft:dark_oak_planks
fill 58 226 302 68 226 302 minecraft:dark_oak_planks
setblock 58 226 303 minecraft:white_stained_glass
setblock 58 226 304 minecraft:light_blue_stained_glass
fill 58 226 305 60 226 305 minecraft:white_stained_glass
setblock 58 226 308 minecraft:light_blue_stained_glass
fill 58 226 309 60 226 309 minecraft:white_stained_glass
setblock 58 226 312 minecraft:light_blue_stained_glass
fill 58 226 313 60 226 313 minecraft:white_stained_glass
setblock 58 226 316 minecraft:light_blue_stained_glass
fill 59 226 276 59 226 278 minecraft:white_stained_glass
setblock 59 226 279 minecraft:light_blue_stained_glass
fill 59 226 280 59 226 282 minecraft:white_stained_glass
setblock 59 226 283 minecraft:light_blue_stained_glass
fill 59 226 284 59 226 286 minecraft:white_stained_glass
setblock 59 226 287 minecraft:light_blue_stained_glass
fill 59 226 288 59 226 290 minecraft:white_stained_glass
setblock 59 226 291 minecraft:light_blue_stained_glass
fill 59 226 292 60 226 292 minecraft:white_stained_glass
fill 59 226 293 60 228 293 minecraft:dark_oak_planks
fill 59 226 303 60 228 303 minecraft:dark_oak_planks
fill 59 226 304 60 226 304 minecraft:white_stained_glass
setblock 59 226 307 minecraft:light_blue_stained_glass
fill 59 226 308 61 226 308 minecraft:white_stained_glass
setblock 59 226 311 minecraft:light_blue_stained_glass
fill 59 226 312 61 226 312 minecraft:white_stained_glass
setblock 59 226 315 minecraft:light_blue_stained_glass
fill 59 226 316 61 226 316 minecraft:white_stained_glass
fill 60 226 276 60 226 277 minecraft:white_stained_glass
setblock 60 226 278 minecraft:light_blue_stained_glass
fill 60 226 279 60 226 281 minecraft:white_stained_glass
setblock 60 226 282 minecraft:light_blue_stained_glass
fill 60 226 283 60 226 285 minecraft:white_stained_glass
setblock 60 226 286 minecraft:light_blue_stained_glass
fill 60 226 287 60 226 289 minecraft:white_stained_glass
setblock 60 226 290 minecraft:light_blue_stained_glass
fill 60 226 291 62 226 291 minecraft:white_stained_glass
fill 60 226 296 60 226 297 minecraft:sea_lantern
fill 60 226 299 60 226 300 minecraft:sea_lantern
setblock 60 226 306 minecraft:light_blue_stained_glass
fill 60 226 307 62 226 307 minecraft:white_stained_glass
setblock 60 226 310 minecraft:light_blue_stained_glass
fill 60 226 311 62 226 311 minecraft:white_stained_glass
setblock 60 226 314 minecraft:light_blue_stained_glass
fill 60 226 315 62 226 315 minecraft:white_stained_glass
setblock 61 226 276 minecraft:white_stained_glass
setblock 61 226 277 minecraft:light_blue_stained_glass
fill 61 226 278 61 226 280 minecraft:white_stained_glass
setblock 61 226 281 minecraft:light_blue_stained_glass
fill 61 226 282 61 226 284 minecraft:white_stained_glass
setblock 61 226 285 minecraft:light_blue_stained_glass
fill 61 226 286 61 226 288 minecraft:white_stained_glass
setblock 61 226 289 minecraft:light_blue_stained_glass
fill 61 226 290 63 226 290 minecraft:white_stained_glass
fill 61 226 292 65 229 292 minecraft:dark_oak_planks
setblock 61 226 293 minecraft:spruce_log
fill 61 226 295 62 226 295 minecraft:sea_lantern
fill 61 226 301 62 226 301 minecraft:sea_lantern
setblock 61 226 303 minecraft:spruce_log
fill 61 226 304 65 229 304 minecraft:dark_oak_planks
setblock 61 226 305 minecraft:light_blue_stained_glass
fill 61 226 306 63 226 306 minecraft:white_stained_glass
setblock 61 226 309 minecraft:light_blue_stained_glass
fill 61 226 310 63 226 310 minecraft:white_stained_glass
setblock 61 226 313 minecraft:light_blue_stained_glass
fill 61 226 314 63 226 314 minecraft:white_stained_glass
setblock 62 226 276 minecraft:light_blue_stained_glass
fill 62 226 277 62 226 279 minecraft:white_stained_glass
setblock 62 226 280 minecraft:light_blue_stained_glass
fill 62 226 281 62 226 283 minecraft:white_stained_glass
setblock 62 226 284 minecraft:light_blue_stained_glass
fill 62 226 285 62 226 287 minecraft:white_stained_glass
setblock 62 226 288 minecraft:light_blue_stained_glass
fill 62 226 289 64 226 289 minecraft:white_stained_glass
fill 62 226 293 64 226 293 minecraft:spruce_planks
fill 62 226 303 64 226 303 minecraft:spruce_planks
fill 62 226 305 64 226 305 minecraft:white_stained_glass
setblock 62 226 308 minecraft:light_blue_stained_glass
fill 62 226 309 64 226 309 minecraft:white_stained_glass
setblock 62 226 312 minecraft:light_blue_stained_glass
fill 62 226 313 64 226 313 minecraft:white_stained_glass
setblock 62 226 316 minecraft:light_blue_stained_glass
fill 63 226 276 63 226 278 minecraft:white_stained_glass
setblock 63 226 279 minecraft:light_blue_stained_glass
fill 63 226 280 63 226 282 minecraft:white_stained_glass
setblock 63 226 283 minecraft:light_blue_stained_glass
fill 63 226 284 63 226 286 minecraft:white_stained_glass
setblock 63 226 287 minecraft:light_blue_stained_glass
fill 63 226 288 65 226 288 minecraft:white_stained_glass
setblock 63 226 291 minecraft:light_blue_stained_glass
setblock 63 226 307 minecraft:light_blue_stained_glass
fill 63 226 308 65 226 308 minecraft:white_stained_glass
setblock 63 226 311 minecraft:light_blue_stained_glass
fill 63 226 312 65 226 312 minecraft:white_stained_glass
setblock 63 226 315 minecraft:light_blue_stained_glass
fill 63 226 316 65 226 316 minecraft:white_stained_glass
fill 64 226 276 64 226 277 minecraft:white_stained_glass
setblock 64 226 278 minecraft:light_blue_stained_glass
fill 64 226 279 64 226 281 minecraft:white_stained_glass
setblock 64 226 282 minecraft:light_blue_stained_glass
fill 64 226 283 64 226 285 minecraft:white_stained_glass
setblock 64 226 286 minecraft:light_blue_stained_glass
fill 64 226 287 66 226 287 minecraft:white_stained_glass
setblock 64 226 290 minecraft:light_blue_stained_glass
fill 64 226 291 66 226 291 minecraft:white_stained_glass
fill 64 226 295 65 226 295 minecraft:sea_lantern
fill 64 226 301 65 226 301 minecraft:sea_lantern
setblock 64 226 306 minecraft:light_blue_stained_glass
fill 64 226 307 66 226 307 minecraft:white_stained_glass
setblock 64 226 310 minecraft:light_blue_stained_glass
fill 64 226 311 66 226 311 minecraft:white_stained_glass
setblock 64 226 314 minecraft:light_blue_stained_glass
fill 64 226 315 66 226 315 minecraft:white_stained_glass
setblock 65 226 276 minecraft:white_stained_glass
setblock 65 226 277 minecraft:light_blue_stained_glass
fill 65 226 278 65 226 280 minecraft:white_stained_glass
setblock 65 226 281 minecraft:light_blue_stained_glass
fill 65 226 282 65 226 284 minecraft:white_stained_glass
setblock 65 226 285 minecraft:light_blue_stained_glass
fill 65 226 286 67 226 286 minecraft:white_stained_glass
setblock 65 226 289 minecraft:light_blue_stained_glass
fill 65 226 290 67 226 290 minecraft:white_stained_glass
setblock 65 226 293 minecraft:spruce_log
setblock 65 226 303 minecraft:spruce_log
setblock 65 226 305 minecraft:light_blue_stained_glass
fill 65 226 306 67 226 306 minecraft:white_stained_glass
setblock 65 226 309 minecraft:light_blue_stained_glass
fill 65 226 310 67 226 310 minecraft:white_stained_glass
setblock 65 226 313 minecraft:light_blue_stained_glass
fill 65 226 314 67 226 314 minecraft:white_stained_glass
setblock 66 226 276 minecraft:light_blue_stained_glass
fill 66 226 277 66 226 279 minecraft:white_stained_glass
setblock 66 226 280 minecraft:light_blue_stained_glass
fill 66 226 281 66 226 283 minecraft:white_stained_glass
setblock 66 226 284 minecraft:light_blue_stained_glass
fill 66 226 285 68 226 285 minecraft:white_stained_glass
setblock 66 226 288 minecraft:light_blue_stained_glass
fill 66 226 289 68 226 289 minecraft:white_stained_glass
setblock 66 226 292 minecraft:light_blue_stained_glass
fill 66 226 293 67 228 293 minecraft:dark_oak_planks
fill 66 226 295 70 226 295 minecraft:dark_oak_planks
fill 66 226 296 66 226 297 minecraft:sea_lantern
fill 66 226 299 66 226 300 minecraft:sea_lantern
fill 66 226 301 70 226 301 minecraft:dark_oak_planks
fill 66 226 303 67 228 303 minecraft:dark_oak_planks
setblock 66 226 304 minecraft:light_blue_stained_glass
fill 66 226 305 68 226 305 minecraft:white_stained_glass
setblock 66 226 308 minecraft:light_blue_stained_glass
fill 66 226 309 68 226 309 minecraft:white_stained_glass
setblock 66 226 312 minecraft:light_blue_stained_glass
fill 66 226 313 68 226 313 minecraft:white_stained_glass
setblock 66 226 316 minecraft:light_blue_stained_glass
setblock 66 226 317 minecraft:white_wool
fill 67 226 276 67 226 278 minecraft:white_stained_glass
setblock 67 226 279 minecraft:light_blue_stained_glass
fill 67 226 280 67 226 282 minecraft:white_stained_glass
setblock 67 226 283 minecraft:light_blue_stained_glass
fill 67 226 284 69 226 284 minecraft:white_stained_glass
setblock 67 226 287 minecraft:light_blue_stained_glass
fill 67 226 288 69 226 288 minecraft:white_stained_glass
setblock 67 226 291 minecraft:light_blue_stained_glass
fill 67 226 292 69 226 292 minecraft:white_stained_glass
fill 67 226 296 67 226 297 minecraft:dark_oak_planks
fill 67 226 299 67 226 300 minecraft:dark_oak_planks
fill 67 226 304 69 226 304 minecraft:white_stained_glass
setblock 67 226 307 minecraft:light_blue_stained_glass
fill 67 226 308 69 226 308 minecraft:white_stained_glass
setblock 67 226 311 minecraft:light_blue_stained_glass
fill 67 226 312 69 226 312 minecraft:white_stained_glass
setblock 67 226 315 minecraft:light_blue_stained_glass
fill 67 226 316 69 226 316 minecraft:white_stained_glass
fill 68 226 276 68 226 277 minecraft:white_stained_glass
setblock 68 226 278 minecraft:light_blue_stained_glass
fill 68 226 279 68 226 281 minecraft:white_stained_glass
setblock 68 226 282 minecraft:light_blue_stained_glass
fill 68 226 283 70 226 283 minecraft:white_stained_glass
setblock 68 226 286 minecraft:light_blue_stained_glass
fill 68 226 287 70 226 287 minecraft:white_stained_glass
setblock 68 226 290 minecraft:light_blue_stained_glass
fill 68 226 291 70 226 291 minecraft:white_stained_glass
setblock 68 226 293 minecraft:white_stained_glass
fill 68 226 296 72 226 296 minecraft:dark_oak_planks
fill 68 226 300 72 226 300 minecraft:dark_oak_planks
fill 68 226 303 70 226 303 minecraft:white_stained_glass
setblock 68 226 306 minecraft:light_blue_stained_glass
fill 68 226 307 70 226 307 minecraft:white_stained_glass
setblock 68 226 310 minecraft:light_blue_stained_glass
fill 68 226 311 70 226 311 minecraft:white_stained_glass
setblock 68 226 314 minecraft:light_blue_stained_glass
fill 68 226 315 70 226 315 minecraft:white_stained_glass
setblock 69 226 276 minecraft:white_stained_glass
setblock 69 226 277 minecraft:light_blue_stained_glass
fill 69 226 278 69 226 280 minecraft:white_stained_glass
setblock 69 226 281 minecraft:light_blue_stained_glass
fill 69 226 282 71 226 282 minecraft:white_stained_glass
setblock 69 226 285 minecraft:light_blue_stained_glass
fill 69 226 286 71 226 286 minecraft:white_stained_glass
setblock 69 226 289 minecraft:light_blue_stained_glass
fill 69 226 290 71 226 290 minecraft:white_stained_glass
setblock 69 226 293 minecraft:light_blue_stained_glass
fill 69 226 294 71 226 294 minecraft:white_stained_glass
fill 69 226 297 72 226 297 minecraft:dark_oak_planks
fill 69 226 299 72 226 299 minecraft:dark_oak_planks
fill 69 226 302 71 226 302 minecraft:white_stained_glass
setblock 69 226 305 minecraft:light_blue_stained_glass
fill 69 226 306 71 226 306 minecraft:white_stained_glass
setblock 69 226 309 minecraft:light_blue_stained_glass
fill 69 226 310 71 226 310 minecraft:white_stained_glass
setblock 69 226 313 minecraft:light_blue_stained_glass
fill 69 226 314 71 226 314 minecraft:white_stained_glass
setblock 70 226 276 minecraft:light_blue_stained_glass
fill 70 226 277 70 226 279 minecraft:white_stained_glass
setblock 70 226 280 minecraft:light_blue_stained_glass
fill 70 226 281 72 226 281 minecraft:white_stained_glass
setblock 70 226 284 minecraft:light_blue_stained_glass
fill 70 226 285 72 226 285 minecraft:white_stained_glass
setblock 70 226 288 minecraft:light_blue_stained_glass
fill 70 226 289 72 226 289 minecraft:white_stained_glass
setblock 70 226 292 minecraft:light_blue_stained_glass
fill 70 226 293 72 226 293 minecraft:white_stained_glass
fill 70 226 298 72 226 298 minecraft:dark_oak_planks
setblock 70 226 304 minecraft:light_blue_stained_glass
fill 70 226 305 72 226 305 minecraft:white_stained_glass
setblock 70 226 308 minecraft:light_blue_stained_glass
fill 70 226 309 72 226 309 minecraft:white_stained_glass
setblock 70 226 312 minecraft:light_blue_stained_glass
fill 70 226 313 72 226 313 minecraft:white_stained_glass
setblock 70 226 316 minecraft:light_blue_stained_glass
fill 71 226 276 71 226 278 minecraft:white_stained_glass
setblock 71 226 279 minecraft:light_blue_stained_glass
fill 71 226 280 73 226 280 minecraft:white_stained_glass
setblock 71 226 283 minecraft:light_blue_stained_glass
fill 71 226 284 73 226 284 minecraft:white_stained_glass
setblock 71 226 287 minecraft:light_blue_stained_glass
fill 71 226 288 73 226 288 minecraft:white_stained_glass
setblock 71 226 291 minecraft:light_blue_stained_glass
fill 71 226 292 73 226 292 minecraft:white_stained_glass
setblock 71 226 295 minecraft:light_blue_stained_glass
fill 71 226 301 72 226 301 minecraft:white_stained_glass
setblock 71 226 303 minecraft:light_blue_stained_glass
fill 71 226 304 73 226 304 minecraft:white_stained_glass
setblock 71 226 307 minecraft:light_blue_stained_glass
fill 71 226 308 73 226 308 minecraft:white_stained_glass
setblock 71 226 311 minecraft:light_blue_stained_glass
fill 71 226 312 73 226 312 minecraft:white_stained_glass
setblock 71 226 315 minecraft:light_blue_stained_glass
fill 71 226 316 73 226 316 minecraft:white_stained_glass
fill 72 226 276 72 226 277 minecraft:white_stained_glass
setblock 72 226 278 minecraft:light_blue_stained_glass
fill 72 226 279 74 226 279 minecraft:white_stained_glass
setblock 72 226 282 minecraft:light_blue_stained_glass
fill 72 226 283 74 226 283 minecraft:white_stained_glass
setblock 72 226 286 minecraft:light_blue_stained_glass
fill 72 226 287 74 226 287 minecraft:white_stained_glass
setblock 72 226 290 minecraft:light_blue_stained_glass
fill 72 226 291 74 226 291 minecraft:white_stained_glass
setblock 72 226 294 minecraft:light_blue_stained_glass
fill 72 226 295 74 226 295 minecraft:white_stained_glass
setblock 72 226 302 minecraft:light_blue_stained_glass
fill 72 226 303 74 226 303 minecraft:white_stained_glass
setblock 72 226 306 minecraft:light_blue_stained_glass
fill 72 226 307 74 226 307 minecraft:white_stained_glass
setblock 72 226 310 minecraft:light_blue_stained_glass
fill 72 226 311 74 226 311 minecraft:white_stained_glass
setblock 72 226 314 minecraft:light_blue_stained_glass
fill 72 226 315 74 226 315 minecraft:white_stained_glass
setblock 73 226 276 minecraft:white_stained_glass
setblock 73 226 277 minecraft:light_blue_stained_glass
fill 73 226 278 75 226 278 minecraft:white_stained_glass
setblock 73 226 281 minecraft:light_blue_stained_glass
fill 73 226 282 75 226 282 minecraft:white_stained_glass
setblock 73 226 285 minecraft:light_blue_stained_glass
fill 73 226 286 75 226 286 minecraft:white_stained_glass
setblock 73 226 289 minecraft:light_blue_stained_glass
fill 73 226 290 75 226 290 minecraft:white_stained_glass
setblock 73 226 293 minecraft:light_blue_stained_glass
fill 73 226 294 75 226 294 minecraft:white_stained_glass
setblock 73 226 296 minecraft:white_stained_glass
setblock 73 226 297 minecraft:light_blue_stained_glass
fill 73 226 298 73 226 300 minecraft:white_stained_glass
setblock 73 226 301 minecraft:light_blue_stained_glass
fill 73 226 302 75 226 302 minecraft:white_stained_glass
setblock 73 226 305 minecraft:light_blue_stained_glass
fill 73 226 306 75 226 306 minecraft:white_stained_glass
setblock 73 226 309 minecraft:light_blue_stained_glass
fill 73 226 310 75 226 310 minecraft:white_stained_glass
setblock 73 226 313 minecraft:light_blue_stained_glass
fill 73 226 314 75 226 314 minecraft:white_stained_glass
setblock 74 226 276 minecraft:light_blue_stained_glass
fill 74 226 277 76 226 277 minecraft:white_stained_glass
setblock 74 226 280 minecraft:light_blue_stained_glass
fill 74 226 281 76 226 281 minecraft:white_stained_glass
setblock 74 226 284 minecraft:light_blue_stained_glass
fill 74 226 285 76 226 285 minecraft:white_stained_glass
setblock 74 226 288 minecraft:light_blue_stained_glass
fill 74 226 289 76 226 289 minecraft:white_stained_glass
setblock 74 226 292 minecraft:light_blue_stained_glass
fill 74 226 293 76 226 293 minecraft:white_stained_glass
setblock 74 226 296 minecraft:light_blue_stained_glass
fill 74 226 297 74 226 299 minecraft:white_stained_glass
setblock 74 226 300 minecraft:light_blue_stained_glass
fill 74 226 301 76 226 301 minecraft:white_stained_glass
setblock 74 226 304 minecraft:light_blue_stained_glass
fill 74 226 305 76 226 305 minecraft:white_stained_glass
setblock 74 226 308 minecraft:light_blue_stained_glass
fill 74 226 309 76 226 309 minecraft:white_stained_glass
setblock 74 226 312 minecraft:light_blue_stained_glass
fill 74 226 313 76 226 313 minecraft:white_stained_glass
setblock 74 226 316 minecraft:light_blue_stained_glass
fill 75 226 276 77 226 276 minecraft:white_stained_glass
setblock 75 226 279 minecraft:light_blue_stained_glass
fill 75 226 280 77 226 280 minecraft:white_stained_glass
setblock 75 226 283 minecraft:light_blue_stained_glass
fill 75 226 284 77 226 284 minecraft:white_stained_glass
setblock 75 226 287 minecraft:light_blue_stained_glass
fill 75 226 288 77 226 288 minecraft:white_stained_glass
setblock 75 226 291 minecraft:light_blue_stained_glass
fill 75 226 292 77 226 292 minecraft:white_stained_glass
setblock 75 226 295 minecraft:light_blue_stained_glass
fill 75 226 296 75 226 298 minecraft:white_stained_glass
setblock 75 226 299 minecraft:light_blue_stained_glass
fill 75 226 300 77 226 300 minecraft:white_stained_glass
setblock 75 226 303 minecraft:light_blue_stained_glass
fill 75 226 304 77 226 304 minecraft:white_stained_glass
setblock 75 226 307 minecraft:light_blue_stained_glass
fill 75 226 308 77 226 308 minecraft:white_stained_glass
setblock 75 226 311 minecraft:light_blue_stained_glass
fill 75 226 312 77 226 312 minecraft:white_stained_glass
setblock 75 226 315 minecraft:light_blue_stained_glass
fill 75 226 316 77 226 316 minecraft:white_stained_glass
setblock 76 226 278 minecraft:light_blue_stained_glass
fill 76 226 279 78 226 279 minecraft:white_stained_glass
setblock 76 226 282 minecraft:light_blue_stained_glass
fill 76 226 283 78 226 283 minecraft:white_stained_glass
setblock 76 226 286 minecraft:light_blue_stained_glass
fill 76 226 287 78 226 287 minecraft:white_stained_glass
setblock 76 226 290 minecraft:light_blue_stained_glass
fill 76 226 291 78 226 291 minecraft:white_stained_glass
setblock 76 226 294 minecraft:light_blue_stained_glass
fill 76 226 295 76 226 297 minecraft:white_stained_glass
setblock 76 226 298 minecraft:light_blue_stained_glass
fill 76 226 299 78 226 299 minecraft:white_stained_glass
setblock 76 226 302 minecraft:light_blue_stained_glass
fill 76 226 303 78 226 303 minecraft:white_stained_glass
setblock 76 226 306 minecraft:light_blue_stained_glass
fill 76 226 307 78 226 307 minecraft:white_stained_glass
setblock 76 226 310 minecraft:light_blue_stained_glass
fill 76 226 311 78 226 311 minecraft:white_stained_glass
setblock 76 226 314 minecraft:light_blue_stained_glass
fill 76 226 315 78 226 315 minecraft:white_stained_glass
setblock 77 226 277 minecraft:light_blue_stained_glass
fill 77 226 278 79 226 278 minecraft:white_stained_glass
setblock 77 226 281 minecraft:light_blue_stained_glass
fill 77 226 282 79 226 282 minecraft:white_stained_glass
setblock 77 226 285 minecraft:light_blue_stained_glass
fill 77 226 286 79 226 286 minecraft:white_stained_glass
setblock 77 226 289 minecraft:light_blue_stained_glass
fill 77 226 290 79 226 290 minecraft:white_stained_glass
setblock 77 226 293 minecraft:light_blue_stained_glass
fill 77 226 294 77 226 296 minecraft:white_stained_glass
setblock 77 226 297 minecraft:light_blue_stained_glass
fill 77 226 298 79 226 298 minecraft:white_stained_glass
setblock 77 226 301 minecraft:light_blue_stained_glass
fill 77 226 302 79 226 302 minecraft:white_stained_glass
setblock 77 226 305 minecraft:light_blue_stained_glass
fill 77 226 306 79 226 306 minecraft:white_stained_glass
setblock 77 226 309 minecraft:light_blue_stained_glass
fill 77 226 310 79 226 310 minecraft:white_stained_glass
setblock 77 226 313 minecraft:light_blue_stained_glass
fill 77 226 314 79 226 314 minecraft:white_stained_glass
setblock 78 226 276 minecraft:light_blue_stained_glass
fill 78 226 277 80 226 277 minecraft:white_stained_glass
setblock 78 226 280 minecraft:light_blue_stained_glass
fill 78 226 281 80 226 281 minecraft:white_stained_glass
setblock 78 226 284 minecraft:light_blue_stained_glass
fill 78 226 285 80 226 285 minecraft:white_stained_glass
setblock 78 226 288 minecraft:light_blue_stained_glass
fill 78 226 289 80 226 289 minecraft:white_stained_glass
setblock 78 226 292 minecraft:light_blue_stained_glass
fill 78 226 293 78 226 295 minecraft:white_stained_glass
setblock 78 226 296 minecraft:light_blue_stained_glass
fill 78 226 297 80 226 297 minecraft:white_stained_glass
setblock 78 226 300 minecraft:light_blue_stained_glass
fill 78 226 301 80 226 301 minecraft:white_stained_glass
setblock 78 226 304 minecraft:light_blue_stained_glass
fill 78 226 305 80 226 305 minecraft:white_stained_glass
setblock 78 226 308 minecraft:light_blue_stained_glass
fill 78 226 309 80 226 309 minecraft:white_stained_glass
setblock 78 226 312 minecraft:light_blue_stained_glass
fill 78 226 313 80 226 313 minecraft:white_stained_glass
setblock 78 226 316 minecraft:light_blue_stained_glass
fill 79 226 276 81 226 276 minecraft:white_stained_glass
setblock 79 226 279 minecraft:light_blue_stained_glass
fill 79 226 280 81 226 280 minecraft:white_stained_glass
setblock 79 226 283 minecraft:light_blue_stained_glass
fill 79 226 284 81 226 284 minecraft:white_stained_glass
setblock 79 226 287 minecraft:light_blue_stained_glass
fill 79 226 288 81 226 288 minecraft:white_stained_glass
setblock 79 226 291 minecraft:light_blue_stained_glass
fill 79 226 292 79 226 294 minecraft:white_stained_glass
setblock 79 226 295 minecraft:light_blue_stained_glass
fill 79 226 296 81 226 296 minecraft:white_stained_glass
setblock 79 226 299 minecraft:light_blue_stained_glass
fill 79 226 300 81 226 300 minecraft:white_stained_glass
setblock 79 226 303 minecraft:light_blue_stained_glass
fill 79 226 304 81 226 304 minecraft:white_stained_glass
setblock 79 226 307 minecraft:light_blue_stained_glass
fill 79 226 308 81 226 308 minecraft:white_stained_glass
setblock 79 226 311 minecraft:light_blue_stained_glass
fill 79 226 312 81 226 312 minecraft:white_stained_glass
setblock 79 226 315 minecraft:light_blue_stained_glass
fill 79 226 316 81 226 316 minecraft:white_stained_glass
fill 79 226 317 79 249 317 minecraft:cyan_concrete
setblock 80 226 278 minecraft:light_blue_stained_glass
fill 80 226 279 82 226 279 minecraft:white_stained_glass
setblock 80 226 282 minecraft:light_blue_stained_glass
fill 80 226 283 82 226 283 minecraft:white_stained_glass
setblock 80 226 286 minecraft:light_blue_stained_glass
fill 80 226 287 82 226 287 minecraft:white_stained_glass
setblock 80 226 290 minecraft:light_blue_stained_glass
fill 80 226 291 80 226 293 minecraft:white_stained_glass
setblock 80 226 294 minecraft:light_blue_stained_glass
fill 80 226 295 82 226 295 minecraft:white_stained_glass
setblock 80 226 298 minecraft:light_blue_stained_glass
fill 80 226 299 82 226 299 minecraft:white_stained_glass
setblock 80 226 302 minecraft:light_blue_stained_glass
fill 80 226 303 82 226 303 minecraft:white_stained_glass
setblock 80 226 306 minecraft:light_blue_stained_glass
fill 80 226 307 82 226 307 minecraft:white_stained_glass
setblock 80 226 310 minecraft:light_blue_stained_glass
fill 80 226 311 82 226 311 minecraft:white_stained_glass
setblock 80 226 314 minecraft:light_blue_stained_glass
fill 80 226 315 82 226 315 minecraft:white_stained_glass
setblock 81 226 277 minecraft:light_blue_stained_glass
fill 81 226 278 83 226 278 minecraft:white_stained_glass
setblock 81 226 281 minecraft:light_blue_stained_glass
fill 81 226 282 83 226 282 minecraft:white_stained_glass
setblock 81 226 285 minecraft:light_blue_stained_glass
fill 81 226 286 83 226 286 minecraft:white_stained_glass
setblock 81 226 289 minecraft:light_blue_stained_glass
fill 81 226 290 81 226 292 minecraft:white_stained_glass
setblock 81 226 293 minecraft:light_blue_stained_glass
fill 81 226 294 83 226 294 minecraft:white_stained_glass
setblock 81 226 297 minecraft:light_blue_stained_glass
fill 81 226 298 83 226 298 minecraft:white_stained_glass
setblock 81 226 301 minecraft:light_blue_stained_glass
fill 81 226 302 83 226 302 minecraft:white_stained_glass
setblock 81 226 305 minecraft:light_blue_stained_glass
fill 81 226 306 83 226 306 minecraft:white_stained_glass
setblock 81 226 309 minecraft:light_blue_stained_glass
fill 81 226 310 83 226 310 minecraft:white_stained_glass
setblock 81 226 313 minecraft:light_blue_stained_glass
fill 81 226 314 83 226 314 minecraft:white_stained_glass
setblock 82 226 276 minecraft:light_blue_stained_glass
fill 82 226 277 84 226 277 minecraft:white_stained_glass
setblock 82 226 280 minecraft:light_blue_stained_glass
fill 82 226 281 84 226 281 minecraft:white_stained_glass
setblock 82 226 284 minecraft:light_blue_stained_glass
fill 82 226 285 84 226 285 minecraft:white_stained_glass
setblock 82 226 288 minecraft:light_blue_stained_glass
fill 82 226 289 82 226 291 minecraft:white_stained_glass
setblock 82 226 292 minecraft:light_blue_stained_glass
fill 82 226 293 84 226 293 minecraft:white_stained_glass
setblock 82 226 296 minecraft:light_blue_stained_glass
fill 82 226 297 84 226 297 minecraft:white_stained_glass
setblock 82 226 300 minecraft:light_blue_stained_glass
fill 82 226 301 84 226 301 minecraft:white_stained_glass
setblock 82 226 304 minecraft:light_blue_stained_glass
fill 82 226 305 84 226 305 minecraft:white_stained_glass
setblock 82 226 308 minecraft:light_blue_stained_glass
fill 82 226 309 84 226 309 minecraft:white_stained_glass
setblock 82 226 312 minecraft:light_blue_stained_glass
fill 82 226 313 83 226 313 minecraft:white_stained_glass
setblock 82 226 316 minecraft:light_blue_stained_glass
fill 83 226 276 85 226 276 minecraft:white_stained_glass
setblock 83 226 279 minecraft:light_blue_stained_glass
fill 83 226 280 85 226 280 minecraft:white_stained_glass
setblock 83 226 283 minecraft:light_blue_stained_glass
fill 83 226 284 85 226 284 minecraft:white_stained_glass
setblock 83 226 287 minecraft:light_blue_stained_glass
fill 83 226 288 83 226 290 minecraft:white_stained_glass
setblock 83 226 291 minecraft:light_blue_stained_glass
fill 83 226 292 85 226 292 minecraft:white_stained_glass
setblock 83 226 295 minecraft:light_blue_stained_glass
fill 83 226 296 85 226 296 minecraft:white_stained_glass
setblock 83 226 299 minecraft:light_blue_stained_glass
fill 83 226 300 85 226 300 minecraft:white_stained_glass
setblock 83 226 303 minecraft:light_blue_stained_glass
fill 83 226 304 85 226 304 minecraft:white_stained_glass
setblock 83 226 307 minecraft:light_blue_stained_glass
fill 83 226 308 85 226 308 minecraft:white_stained_glass
setblock 83 226 311 minecraft:light_blue_stained_glass
setblock 83 226 315 minecraft:light_blue_stained_glass
fill 83 226 316 85 226 316 minecraft:white_stained_glass
setblock 84 226 278 minecraft:light_blue_stained_glass
fill 84 226 279 86 226 279 minecraft:white_stained_glass
setblock 84 226 282 minecraft:light_blue_stained_glass
fill 84 226 283 86 226 283 minecraft:white_stained_glass
setblock 84 226 286 minecraft:light_blue_stained_glass
fill 84 226 287 84 226 289 minecraft:white_stained_glass
setblock 84 226 290 minecraft:light_blue_stained_glass
fill 84 226 291 86 226 291 minecraft:white_stained_glass
setblock 84 226 294 minecraft:light_blue_stained_glass
fill 84 226 295 86 226 295 minecraft:white_stained_glass
setblock 84 226 298 minecraft:light_blue_stained_glass
fill 84 226 299 86 226 299 minecraft:white_stained_glass
setblock 84 226 302 minecraft:light_blue_stained_glass
fill 84 226 303 86 226 303 minecraft:white_stained_glass
setblock 84 226 306 minecraft:light_blue_stained_glass
fill 84 226 307 86 226 307 minecraft:white_stained_glass
setblock 84 226 310 minecraft:light_blue_stained_glass
setblock 84 226 314 minecraft:light_blue_stained_glass
fill 84 226 315 86 226 315 minecraft:white_stained_glass
setblock 85 226 277 minecraft:light_blue_stained_glass
fill 85 226 278 87 226 278 minecraft:white_stained_glass
setblock 85 226 281 minecraft:light_blue_stained_glass
fill 85 226 282 87 226 282 minecraft:white_stained_glass
setblock 85 226 285 minecraft:light_blue_stained_glass
fill 85 226 286 85 226 288 minecraft:white_stained_glass
setblock 85 226 289 minecraft:light_blue_stained_glass
fill 85 226 290 87 226 290 minecraft:white_stained_glass
setblock 85 226 293 minecraft:light_blue_stained_glass
fill 85 226 294 87 226 294 minecraft:white_stained_glass
setblock 85 226 297 minecraft:light_blue_stained_glass
fill 85 226 298 87 226 298 minecraft:white_stained_glass
setblock 85 226 301 minecraft:light_blue_stained_glass
fill 85 226 302 87 226 302 minecraft:white_stained_glass
setblock 85 226 305 minecraft:light_blue_stained_glass
fill 85 226 306 87 226 306 minecraft:white_stained_glass
setblock 85 226 309 minecraft:light_blue_stained_glass
fill 85 226 310 86 226 311 minecraft:white_stained_glass
setblock 85 226 313 minecraft:light_blue_stained_glass
fill 85 226 314 87 226 314 minecraft:white_stained_glass
setblock 86 226 276 minecraft:light_blue_stained_glass
fill 86 226 277 88 226 277 minecraft:white_stained_glass
setblock 86 226 280 minecraft:light_blue_stained_glass
fill 86 226 281 88 226 281 minecraft:white_stained_glass
setblock 86 226 284 minecraft:light_blue_stained_glass
fill 86 226 285 86 226 287 minecraft:white_stained_glass
setblock 86 226 288 minecraft:light_blue_stained_glass
fill 86 226 289 88 226 289 minecraft:white_stained_glass
setblock 86 226 292 minecraft:light_blue_stained_glass
fill 86 226 293 88 226 293 minecraft:white_stained_glass
setblock 86 226 296 minecraft:light_blue_stained_glass
fill 86 226 297 88 226 297 minecraft:white_stained_glass
setblock 86 226 300 minecraft:light_blue_stained_glass
fill 86 226 301 88 226 301 minecraft:white_stained_glass
setblock 86 226 304 minecraft:light_blue_stained_glass
fill 86 226 305 88 226 305 minecraft:white_stained_glass
setblock 86 226 308 minecraft:light_blue_stained_glass
fill 86 226 309 88 226 309 minecraft:white_stained_glass
setblock 86 226 312 minecraft:light_blue_stained_glass
fill 86 226 313 88 226 313 minecraft:white_stained_glass
setblock 86 226 316 minecraft:light_blue_stained_glass
fill 87 226 276 88 226 276 minecraft:white_stained_glass
setblock 87 226 279 minecraft:light_blue_stained_glass
fill 87 226 280 88 226 280 minecraft:white_stained_glass
setblock 87 226 283 minecraft:light_blue_stained_glass
fill 87 226 284 87 226 286 minecraft:white_stained_glass
setblock 87 226 287 minecraft:light_blue_stained_glass
fill 87 226 288 88 226 288 minecraft:white_stained_glass
setblock 87 226 291 minecraft:light_blue_stained_glass
fill 87 226 292 88 226 292 minecraft:white_stained_glass
setblock 87 226 295 minecraft:light_blue_stained_glass
fill 87 226 296 88 226 296 minecraft:white_stained_glass
setblock 87 226 299 minecraft:light_blue_stained_glass
fill 87 226 300 88 226 300 minecraft:white_stained_glass
setblock 87 226 303 minecraft:light_blue_stained_glass
fill 87 226 304 88 226 304 minecraft:white_stained_glass
setblock 87 226 307 minecraft:light_blue_stained_glass
fill 87 226 308 88 226 308 minecraft:white_stained_glass
setblock 87 226 310 minecraft:white_stained_glass
setblock 87 226 311 minecraft:light_blue_stained_glass
fill 87 226 312 88 226 312 minecraft:white_stained_glass
setblock 87 226 315 minecraft:light_blue_stained_glass
fill 87 226 316 88 226 316 minecraft:white_stained_glass
setblock 88 226 278 minecraft:light_blue_stained_glass
setblock 88 226 279 minecraft:white_stained_glass
setblock 88 226 282 minecraft:light_blue_stained_glass
fill 88 226 283 88 226 285 minecraft:white_stained_glass
setblock 88 226 286 minecraft:light_blue_stained_glass
setblock 88 226 287 minecraft:white_stained_glass
setblock 88 226 290 minecraft:light_blue_stained_glass
setblock 88 226 291 minecraft:white_stained_glass
setblock 88 226 294 minecraft:light_blue_stained_glass
setblock 88 226 295 minecraft:white_stained_glass
setblock 88 226 298 minecraft:light_blue_stained_glass
setblock 88 226 299 minecraft:white_stained_glass
setblock 88 226 302 minecraft:light_blue_stained_glass
setblock 88 226 303 minecraft:white_stained_glass
setblock 88 226 306 minecraft:light_blue_stained_glass
setblock 88 226 307 minecraft:white_stained_glass
setblock 88 226 310 minecraft:light_blue_stained_glass
setblock 88 226 311 minecraft:white_stained_glass
setblock 88 226 314 minecraft:light_blue_stained_glass
setblock 88 226 315 minecraft:white_stained_glass
fill 89 226 284 89 230 286 minecraft:cyan_concrete
setblock 89 226 287 minecraft:light_blue_wool
fill 47 227 276 47 246 276 minecraft:cyan_concrete
fill 51 227 298 53 227 298 minecraft:dark_oak_planks
fill 52 227 296 53 227 297 minecraft:dark_oak_planks
fill 52 227 299 53 227 300 minecraft:dark_oak_planks
fill 53 227 295 55 227 295 minecraft:dark_oak_planks
fill 53 227 301 55 227 301 minecraft:dark_oak_planks
fill 54 227 294 59 227 294 minecraft:dark_oak_planks
fill 54 227 302 59 227 302 minecraft:dark_oak_planks
fill 57 227 293 58 227 293 minecraft:dark_oak_planks
fill 57 227 296 57 228 300 minecraft:dark_oak_planks
fill 57 227 303 58 227 303 minecraft:dark_oak_planks
fill 58 227 295 58 228 295 minecraft:dark_oak_planks
fill 58 227 301 58 228 301 minecraft:dark_oak_planks
fill 61 227 293 65 227 293 minecraft:dark_oak_planks
fill 61 227 303 65 227 303 minecraft:dark_oak_planks
fill 66 227 317 66 236 317 minecraft:cyan_concrete
fill 67 227 294 72 227 294 minecraft:dark_oak_planks
fill 67 227 302 72 227 302 minecraft:dark_oak_planks
fill 68 227 293 69 227 293 minecraft:dark_oak_planks
fill 68 227 295 68 228 295 minecraft:dark_oak_planks
fill 68 227 301 68 228 301 minecraft:dark_oak_planks
fill 68 227 303 69 227 303 minecraft:dark_oak_planks
fill 69 227 296 69 228 300 minecraft:dark_oak_planks
fill 71 227 295 73 227 295 minecraft:dark_oak_planks
fill 71 227 301 73 227 301 minecraft:dark_oak_planks
fill 73 227 296 74 227 300 minecraft:dark_oak_planks
setblock 75 227 298 minecraft:dark_oak_planks
fill 89 227 287 89 247 287 minecraft:cyan_concrete
fill 50 228 297 50 229 299 minecraft:dark_oak_planks
fill 51 228 296 51 228 297 minecraft:dark_oak_planks
fill 51 228 299 51 228 300 minecraft:dark_oak_planks
setblock 52 228 295 minecraft:dark_oak_planks
setblock 52 228 301 minecraft:dark_oak_planks
fill 53 228 294 54 228 294 minecraft:dark_oak_planks
fill 53 228 302 54 228 302 minecraft:dark_oak_planks
fill 55 228 293 57 228 293 minecraft:dark_oak_planks
fill 55 228 303 57 228 303 minecraft:dark_oak_planks
fill 58 228 292 60 229 292 minecraft:dark_oak_planks
fill 58 228 294 59 228 294 minecraft:dark_oak_planks
fill 58 228 302 59 228 302 minecraft:dark_oak_planks
fill 58 228 304 60 229 304 minecraft:dark_oak_planks
fill 66 228 292 68 229 292 minecraft:dark_oak_planks
fill 66 228 304 68 229 304 minecraft:dark_oak_planks
fill 67 228 294 68 228 294 minecraft:dark_oak_planks
fill 67 228 302 68 228 302 minecraft:dark_oak_planks
fill 69 228 293 71 228 293 minecraft:dark_oak_planks
fill 69 228 303 71 228 303 minecraft:dark_oak_planks
fill 72 228 294 73 228 294 minecraft:dark_oak_planks
fill 72 228 302 73 228 302 minecraft:dark_oak_planks
setblock 74 228 295 minecraft:dark_oak_planks
setblock 74 228 301 minecraft:dark_oak_planks
fill 75 228 296 75 228 297 minecraft:dark_oak_planks
fill 75 228 299 75 228 300 minecraft:dark_oak_planks
fill 76 228 297 76 229 299 minecraft:dark_oak_planks
setblock 83 228 317 minecraft:light_blue_wool
fill 85 228 317 86 229 317 minecraft:cyan_concrete
setblock 87 228 317 minecraft:white_wool
setblock 50 229 296 minecraft:dark_oak_planks
setblock 50 229 300 minecraft:dark_oak_planks
setblock 51 229 295 minecraft:dark_oak_planks
setblock 51 229 301 minecraft:dark_oak_planks
fill 52 229 294 53 229 294 minecraft:dark_oak_planks
fill 52 229 302 53 229 302 minecraft:dark_oak_planks
fill 54 229 293 55 229 293 minecraft:dark_oak_planks
fill 54 229 303 55 229 303 minecraft:dark_oak_planks
fill 56 229 292 57 229 292 minecraft:dark_oak_planks
fill 56 229 304 57 229 304 minecraft:dark_oak_planks
setblock 64 229 317 minecraft:white_wool
fill 69 229 292 70 229 292 minecraft:dark_oak_planks
fill 69 229 304 70 229 304 minecraft:dark_oak_planks
fill 71 229 293 72 229 293 minecraft:dark_oak_planks
fill 71 229 303 72 229 303 minecraft:dark_oak_planks
fill 73 229 294 74 229 294 minecraft:dark_oak_planks
fill 73 229 302 74 229 302 minecraft:dark_oak_planks
setblock 75 229 295 minecraft:dark_oak_planks
setblock 75 229 301 minecraft:dark_oak_planks
setblock 76 229 296 minecraft:dark_oak_planks
setblock 76 229 300 minecraft:dark_oak_planks
setblock 77 229 317 minecraft:light_blue_wool
fill 83 229 317 83 249 317 minecraft:cyan_concrete
fill 87 229 317 87 249 317 minecraft:cyan_concrete
setblock 47 230 281 minecraft:light_blue_wool
fill 48 230 276 48 230 316 minecraft:spruce_planks
fill 49 230 276 88 230 276 minecraft:spruce_planks
fill 49 230 292 49 234 296 minecraft:white_wool
fill 49 230 301 55 239 307 minecraft:spruce_planks
fill 49 230 316 88 230 316 minecraft:spruce_planks
setblock 50 230 278 minecraft:light[level=12]
setblock 50 230 285 minecraft:light[level=12]
setblock 50 230 292 minecraft:light[level=12]
fill 50 230 296 58 230 300 minecraft:spruce_planks
setblock 50 230 313 minecraft:light[level=12]
fill 50 230 314 50 236 314 minecraft:green_terracotta
fill 51 230 295 59 230 295 minecraft:spruce_planks
fill 52 230 294 60 230 294 minecraft:spruce_planks
fill 54 230 293 72 230 293 minecraft:spruce_planks
fill 56 230 292 70 230 292 minecraft:spruce_planks
fill 56 230 301 59 230 304 minecraft:spruce_planks
setblock 57 230 278 minecraft:light[level=12]
setblock 57 230 285 minecraft:light[level=12]
setblock 57 230 306 minecraft:light[level=12]
setblock 57 230 313 minecraft:light[level=12]
fill 59 230 313 59 230 315 minecraft:iron_bars
fill 60 230 302 60 230 304 minecraft:spruce_planks
fill 61 230 303 70 230 304 minecraft:spruce_planks
setblock 61 230 317 minecraft:white_wool
setblock 64 230 278 minecraft:light[level=12]
setblock 64 230 285 minecraft:light[level=12]
setblock 64 230 306 minecraft:light[level=12]
setblock 64 230 313 minecraft:light[level=12]
fill 64 230 317 64 232 317 minecraft:cyan_concrete
fill 66 230 294 74 230 294 minecraft:spruce_planks
fill 66 230 302 74 230 302 minecraft:spruce_planks
fill 67 230 295 75 230 295 minecraft:spruce_planks
fill 67 230 301 75 230 301 minecraft:spruce_planks
fill 68 230 296 76 230 300 minecraft:spruce_planks
setblock 71 230 278 minecraft:light[level=12]
setblock 71 230 285 minecraft:light[level=12]
setblock 71 230 292 minecraft:light[level=12]
fill 71 230 303 72 230 303 minecraft:spruce_planks
setblock 71 230 306 minecraft:light[level=12]
setblock 71 230 313 minecraft:light[level=12]
fill 75 230 307 82 231 315 minecraft:spruce_planks
fill 77 230 317 77 249 317 minecraft:cyan_concrete
setblock 78 230 278 minecraft:light[level=12]
setblock 78 230 285 minecraft:light[level=12]
setblock 78 230 292 minecraft:light[level=12]
setblock 78 230 299 minecraft:light[level=12]
setblock 78 230 306 minecraft:light[level=12]
fill 80 230 277 86 231 283 minecraft:spruce_planks
fill 83 230 307 83 231 311 minecraft:spruce_planks
fill 83 230 313 83 231 315 minecraft:spruce_planks
fill 84 230 307 85 231 310 minecraft:spruce_planks
fill 84 230 314 85 231 315 minecraft:spruce_planks
setblock 85 230 285 minecraft:light[level=12]
setblock 85 230 292 minecraft:light[level=12]
setblock 85 230 299 minecraft:light[level=12]
setblock 85 230 306 minecraft:light[level=12]
fill 85 230 311 85 231 311 minecraft:spruce_planks
fill 85 230 313 85 231 313 minecraft:spruce_planks
fill 85 230 317 85 231 317 minecraft:cyan_concrete
setblock 86 230 317 minecraft:light_blue_wool
fill 88 230 277 88 230 315 minecraft:spruce_planks
fill 47 231 281 47 234 281 minecraft:cyan_concrete
fill 47 231 294 47 249 294 minecraft:cyan_concrete
setblock 47 231 295 minecraft:white_wool
fill 47 231 296 47 237 296 minecraft:cyan_concrete
fill 48 231 281 48 272 281 minecraft:spruce_planks
fill 48 231 288 48 272 288 minecraft:spruce_planks
fill 48 231 295 48 272 295 minecraft:spruce_planks
fill 48 231 301 48 246 307 minecraft:spruce_planks
fill 48 231 309 48 272 309 minecraft:spruce_planks
fill 48 231 316 48 272 316 minecraft:spruce_planks
fill 50 231 276 50 272 276 minecraft:spruce_planks
fill 55 231 316 55 272 316 minecraft:spruce_planks
fill 56 231 298 56 234 298 minecraft:stripped_dark_oak_log
fill 57 231 276 57 272 276 minecraft:spruce_planks
fill 61 231 317 61 249 317 minecraft:cyan_concrete
fill 62 231 316 62 272 316 minecraft:spruce_planks
fill 64 231 276 64 272 276 minecraft:spruce_planks
fill 69 231 316 69 272 316 minecraft:spruce_planks
fill 71 231 276 71 272 276 minecraft:spruce_planks
fill 75 231 316 85 231 316 minecraft:spruce_planks
fill 78 231 276 78 272 276 minecraft:spruce_planks
fill 80 231 276 86 231 276 minecraft:spruce_planks
setblock 82 231 317 minecraft:light_blue_wool
fill 86 231 317 86 249 317 minecraft:cyan_concrete
fill 88 231 280 88 272 280 minecraft:spruce_planks
fill 88 231 287 88 272 287 minecraft:spruce_planks
fill 88 231 294 88 272 294 minecraft:spruce_planks
fill 88 231 301 88 272 301 minecraft:spruce_planks
fill 88 231 308 88 272 308 minecraft:spruce_planks
fill 88 231 315 88 272 315 minecraft:spruce_planks
fill 89 231 284 89 244 284 minecraft:cyan_concrete
setblock 89 231 285 minecraft:white_wool
fill 89 231 286 89 246 286 minecraft:cyan_concrete
fill 47 232 295 47 249 295 minecraft:cyan_concrete
setblock 47 232 298 minecraft:white_wool
fill 48 232 280 56 238 280 minecraft:white_wool
setblock 48 232 282 minecraft:spruce_planks
setblock 48 232 289 minecraft:spruce_planks
setblock 48 232 296 minecraft:spruce_planks
setblock 48 232 310 minecraft:spruce_planks
setblock 49 232 276 minecraft:spruce_planks
setblock 49 232 316 minecraft:spruce_planks
setblock 56 232 276 minecraft:spruce_planks
setblock 56 232 316 minecraft:spruce_planks
setblock 63 232 276 minecraft:spruce_planks
setblock 63 232 316 minecraft:spruce_planks
setblock 70 232 276 minecraft:spruce_planks
setblock 70 232 316 minecraft:spruce_planks
fill 75 232 275 76 245 275 minecraft:cyan_concrete
setblock 75 232 307 minecraft:shroomlight
fill 75 232 308 75 255 308 minecraft:spruce_planks
setblock 75 232 309 minecraft:shroomlight
fill 75 232 310 75 255 310 minecraft:spruce_planks
setblock 75 232 311 minecraft:shroomlight
fill 75 232 312 75 255 312 minecraft:spruce_planks
setblock 75 232 313 minecraft:shroomlight
fill 75 232 314 75 255 314 minecraft:spruce_planks
setblock 75 232 315 minecraft:shroomlight
fill 75 232 316 75 255 316 minecraft:spruce_planks
fill 76 232 307 76 255 307 minecraft:spruce_planks
setblock 76 232 308 minecraft:shroomlight
fill 76 232 309 76 255 309 minecraft:spruce_planks
setblock 76 232 310 minecraft:shroomlight
fill 76 232 311 76 255 311 minecraft:spruce_planks
setblock 76 232 312 minecraft:shroomlight
fill 76 232 313 76 255 313 minecraft:spruce_planks
setblock 76 232 314 minecraft:shroomlight
fill 76 232 315 76 255 315 minecraft:spruce_planks
setblock 76 232 316 minecraft:shroomlight
setblock 77 232 275 minecraft:light_blue_wool
setblock 77 232 276 minecraft:spruce_planks
setblock 77 232 307 minecraft:shroomlight
fill 77 232 308 77 255 308 minecraft:spruce_planks
setblock 77 232 309 minecraft:shroomlight
fill 77 232 310 77 255 310 minecraft:spruce_planks
setblock 77 232 311 minecraft:shroomlight
fill 77 232 312 77 255 312 minecraft:spruce_planks
setblock 77 232 313 minecraft:shroomlight
fill 77 232 314 77 255 314 minecraft:spruce_planks
setblock 77 232 315 minecraft:shroomlight
fill 77 232 316 77 255 316 minecraft:spruce_planks
fill 78 232 307 78 255 307 minecraft:spruce_planks
setblock 78 232 308 minecraft:shroomlight
fill 78 232 309 78 255 309 minecraft:spruce_planks
setblock 78 232 310 minecraft:shroomlight
fill 78 232 311 78 255 311 minecraft:spruce_planks
setblock 78 232 312 minecraft:shroomlight
fill 78 232 313 78 255 313 minecraft:spruce_planks
setblock 78 232 314 minecraft:shroomlight
fill 78 232 315 78 255 315 minecraft:spruce_planks
setblock 78 232 316 minecraft:shroomlight
setblock 79 232 307 minecraft:shroomlight
fill 79 232 308 79 255 308 minecraft:spruce_planks
setblock 79 232 309 minecraft:shroomlight
fill 79 232 310 79 255 310 minecraft:spruce_planks
setblock 79 232 311 minecraft:shroomlight
fill 79 232 312 79 255 312 minecraft:spruce_planks
setblock 79 232 313 minecraft:shroomlight
fill 79 232 314 79 255 314 minecraft:spruce_planks
setblock 79 232 315 minecraft:shroomlight
fill 79 232 316 79 255 316 minecraft:spruce_planks
setblock 80 232 276 minecraft:shroomlight
fill 80 232 277 80 238 277 minecraft:spruce_planks
setblock 80 232 278 minecraft:shroomlight
fill 80 232 279 80 238 279 minecraft:spruce_planks
setblock 80 232 280 minecraft:shroomlight
fill 80 232 281 80 238 281 minecraft:spruce_planks
setblock 80 232 282 minecraft:shroomlight
fill 80 232 283 80 238 283 minecraft:spruce_planks
fill 80 232 307 80 237 307 minecraft:spruce_planks
setblock 80 232 308 minecraft:shroomlight
fill 80 232 309 80 237 309 minecraft:spruce_planks
setblock 80 232 310 minecraft:shroomlight
fill 80 232 311 80 237 311 minecraft:spruce_planks
setblock 80 232 312 minecraft:shroomlight
fill 80 232 313 80 237 313 minecraft:spruce_planks
setblock 80 232 314 minecraft:shroomlight
fill 80 232 315 80 237 315 minecraft:spruce_planks
setblock 80 232 316 minecraft:shroomlight
fill 81 232 276 81 253 276 minecraft:spruce_planks
setblock 81 232 277 minecraft:shroomlight
fill 81 232 278 81 253 278 minecraft:spruce_planks
setblock 81 232 279 minecraft:shroomlight
fill 81 232 280 81 253 280 minecraft:spruce_planks
setblock 81 232 281 minecraft:shroomlight
fill 81 232 282 81 253 282 minecraft:spruce_planks
setblock 81 232 283 minecraft:shroomlight
setblock 81 232 307 minecraft:shroomlight
fill 81 232 308 81 255 308 minecraft:spruce_planks
setblock 81 232 309 minecraft:shroomlight
fill 81 232 310 81 255 310 minecraft:spruce_planks
setblock 81 232 311 minecraft:shroomlight
fill 81 232 312 81 238 312 minecraft:white_wool
setblock 81 232 313 minecraft:shroomlight
fill 81 232 314 81 255 314 minecraft:spruce_planks
setblock 81 232 315 minecraft:shroomlight
fill 81 232 316 81 255 316 minecraft:spruce_planks
setblock 82 232 276 minecraft:shroomlight
fill 82 232 277 82 253 277 minecraft:spruce_planks
setblock 82 232 278 minecraft:shroomlight
fill 82 232 279 82 253 279 minecraft:spruce_planks
setblock 82 232 280 minecraft:shroomlight
fill 82 232 281 82 253 281 minecraft:spruce_planks
setblock 82 232 282 minecraft:shroomlight
fill 82 232 283 82 253 283 minecraft:spruce_planks
fill 82 232 307 82 255 307 minecraft:spruce_planks
setblock 82 232 308 minecraft:shroomlight
fill 82 232 309 82 255 309 minecraft:spruce_planks
setblock 82 232 310 minecraft:shroomlight
fill 82 232 311 82 255 311 minecraft:spruce_planks
setblock 82 232 312 minecraft:shroomlight
fill 82 232 313 82 255 313 minecraft:spruce_planks
setblock 82 232 314 minecraft:shroomlight
fill 82 232 315 82 255 315 minecraft:spruce_planks
setblock 82 232 316 minecraft:shroomlight
fill 82 232 317 82 249 317 minecraft:cyan_concrete
fill 83 232 276 83 254 276 minecraft:spruce_planks
setblock 83 232 277 minecraft:shroomlight
fill 83 232 278 83 253 278 minecraft:spruce_planks
setblock 83 232 279 minecraft:shroomlight
fill 83 232 280 83 253 280 minecraft:spruce_planks
setblock 83 232 281 minecraft:shroomlight
fill 83 232 282 83 253 282 minecraft:spruce_planks
setblock 83 232 283 minecraft:shroomlight
setblock 83 232 307 minecraft:shroomlight
fill 83 232 308 83 255 308 minecraft:spruce_planks
setblock 83 232 309 minecraft:shroomlight
fill 83 232 310 83 255 310 minecraft:spruce_planks
setblock 83 232 311 minecraft:shroomlight
fill 83 232 312 83 238 312 minecraft:white_wool
setblock 83 232 313 minecraft:shroomlight
fill 83 232 314 83 255 314 minecraft:spruce_planks
setblock 83 232 315 minecraft:shroomlight
fill 83 232 316 83 272 316 minecraft:spruce_planks
setblock 84 232 276 minecraft:shroomlight
fill 84 232 277 84 253 277 minecraft:spruce_planks
setblock 84 232 278 minecraft:shroomlight
fill 84 232 279 84 253 279 minecraft:spruce_planks
setblock 84 232 280 minecraft:shroomlight
fill 84 232 281 84 253 281 minecraft:spruce_planks
setblock 84 232 282 minecraft:shroomlight
fill 84 232 283 84 253 283 minecraft:spruce_planks
fill 84 232 307 84 255 307 minecraft:spruce_planks
setblock 84 232 308 minecraft:shroomlight
fill 84 232 309 84 255 309 minecraft:spruce_planks
setblock 84 232 310 minecraft:shroomlight
setblock 84 232 312 minecraft:shroomlight
setblock 84 232 314 minecraft:shroomlight
fill 84 232 315 84 255 315 minecraft:spruce_planks
setblock 84 232 316 minecraft:shroomlight
fill 85 232 276 85 272 276 minecraft:spruce_planks
setblock 85 232 277 minecraft:shroomlight
fill 85 232 278 85 253 278 minecraft:spruce_planks
setblock 85 232 279 minecraft:shroomlight
fill 85 232 280 85 253 280 minecraft:spruce_planks
setblock 85 232 281 minecraft:shroomlight
fill 85 232 282 85 253 282 minecraft:spruce_planks
setblock 85 232 283 minecraft:shroomlight
setblock 85 232 307 minecraft:shroomlight
fill 85 232 308 85 255 308 minecraft:spruce_planks
setblock 85 232 309 minecraft:shroomlight
fill 85 232 310 85 255 310 minecraft:spruce_planks
setblock 85 232 311 minecraft:shroomlight
fill 85 232 312 88 238 312 minecraft:white_wool
setblock 85 232 313 minecraft:shroomlight
fill 85 232 314 85 255 314 minecraft:spruce_planks
setblock 85 232 315 minecraft:shroomlight
fill 85 232 316 85 255 316 minecraft:spruce_planks
setblock 85 232 317 minecraft:light_blue_wool
setblock 86 232 276 minecraft:shroomlight
fill 86 232 277 86 238 277 minecraft:spruce_planks
setblock 86 232 278 minecraft:shroomlight
fill 86 232 279 86 238 279 minecraft:spruce_planks
setblock 86 232 280 minecraft:shroomlight
fill 86 232 281 86 238 281 minecraft:spruce_planks
setblock 86 232 282 minecraft:shroomlight
fill 86 232 283 86 238 283 minecraft:spruce_planks
setblock 88 232 279 minecraft:spruce_planks
setblock 88 232 286 minecraft:spruce_planks
setblock 88 232 293 minecraft:spruce_planks
setblock 88 232 300 minecraft:spruce_planks
setblock 88 232 307 minecraft:spruce_planks
setblock 88 232 314 minecraft:spruce_planks
fill 89 232 285 89 249 285 minecraft:cyan_concrete
setblock 89 232 299 minecraft:white_wool
setblock 47 233 297 minecraft:light_blue_wool
fill 47 233 298 47 249 298 minecraft:cyan_concrete
fill 47 233 308 47 249 308 minecraft:cyan_concrete
setblock 47 233 309 minecraft:white_wool
setblock 47 233 315 minecraft:light_blue_wool
setblock 48 233 276 minecraft:spruce_planks
setblock 48 233 283 minecraft:spruce_planks
setblock 48 233 290 minecraft:spruce_planks
setblock 48 233 297 minecraft:spruce_planks
setblock 48 233 311 minecraft:spruce_planks
fill 50 233 275 50 249 275 minecraft:cyan_concrete
setblock 50 233 316 minecraft:spruce_planks
setblock 51 233 275 minecraft:light_blue_wool
setblock 55 233 276 minecraft:spruce_planks
setblock 57 233 316 minecraft:spruce_planks
setblock 62 233 276 minecraft:spruce_planks
setblock 64 233 316 minecraft:spruce_planks
setblock 64 233 317 minecraft:white_wool
setblock 69 233 276 minecraft:spruce_planks
setblock 71 233 316 minecraft:spruce_planks
fill 75 233 307 75 234 307 minecraft:spruce_planks
fill 75 233 309 75 234 309 minecraft:spruce_planks
fill 75 233 311 75 234 311 minecraft:spruce_planks
fill 75 233 313 75 234 313 minecraft:spruce_planks
fill 75 233 315 75 234 315 minecraft:spruce_planks
setblock 76 233 276 minecraft:spruce_planks
fill 76 233 308 76 234 308 minecraft:spruce_planks
fill 76 233 310 76 234 310 minecraft:spruce_planks
fill 76 233 312 76 234 312 minecraft:spruce_planks
fill 76 233 314 76 234 314 minecraft:spruce_planks
fill 76 233 316 76 234 316 minecraft:spruce_planks
setblock 76 233 317 minecraft:light_blue_wool
fill 77 233 275 77 247 275 minecraft:cyan_concrete
fill 77 233 307 77 234 307 minecraft:spruce_planks
fill 77 233 309 77 234 309 minecraft:spruce_planks
fill 77 233 311 77 234 311 minecraft:spruce_planks
fill 77 233 313 77 234 313 minecraft:spruce_planks
fill 77 233 315 77 234 315 minecraft:spruce_planks
fill 78 233 308 78 234 308 minecraft:spruce_planks
fill 78 233 310 78 234 310 minecraft:spruce_planks
fill 78 233 312 78 234 312 minecraft:spruce_planks
fill 78 233 314 78 234 314 minecraft:spruce_planks
fill 78 233 316 78 234 316 minecraft:spruce_planks
fill 79 233 307 79 234 307 minecraft:spruce_planks
fill 79 233 309 79 234 309 minecraft:spruce_planks
fill 79 233 311 79 234 311 minecraft:spruce_planks
fill 79 233 313 79 234 313 minecraft:spruce_planks
fill 79 233 315 79 234 315 minecraft:spruce_planks
fill 80 233 276 80 234 276 minecraft:spruce_planks
fill 80 233 278 80 234 278 minecraft:spruce_planks
fill 80 233 280 80 234 280 minecraft:spruce_planks
fill 80 233 282 80 234 282 minecraft:spruce_planks
fill 80 233 308 80 234 308 minecraft:spruce_planks
fill 80 233 310 80 234 310 minecraft:spruce_planks
fill 80 233 312 80 234 312 minecraft:white_wool
fill 80 233 314 80 234 314 minecraft:spruce_planks
fill 80 233 316 80 234 316 minecraft:spruce_planks
fill 81 233 277 81 234 277 minecraft:spruce_planks
fill 81 233 279 81 234 279 minecraft:spruce_planks
fill 81 233 281 81 234 281 minecraft:spruce_planks
fill 81 233 283 81 234 283 minecraft:spruce_planks
fill 81 233 307 81 234 307 minecraft:spruce_planks
fill 81 233 309 81 234 309 minecraft:spruce_planks
fill 81 233 311 81 234 311 minecraft:spruce_planks
fill 81 233 313 81 234 313 minecraft:spruce_planks
fill 81 233 315 81 234 315 minecraft:spruce_planks
fill 82 233 276 82 234 276 minecraft:spruce_planks
fill 82 233 278 82 234 278 minecraft:spruce_planks
fill 82 233 280 82 234 280 minecraft:spruce_planks
fill 82 233 282 82 234 282 minecraft:spruce_planks
fill 82 233 308 82 234 308 minecraft:spruce_planks
fill 82 233 310 82 234 310 minecraft:spruce_planks
fill 82 233 312 82 234 312 minecraft:white_wool
fill 82 233 314 82 234 314 minecraft:spruce_planks
fill 82 233 316 82 234 316 minecraft:spruce_planks
fill 83 233 277 83 234 277 minecraft:spruce_planks
fill 83 233 279 83 234 279 minecraft:spruce_planks
fill 83 233 281 83 234 281 minecraft:spruce_planks
fill 83 233 283 83 234 283 minecraft:spruce_planks
fill 83 233 307 83 234 307 minecraft:spruce_planks
fill 83 233 309 83 234 309 minecraft:spruce_planks
fill 83 233 311 83 234 311 minecraft:spruce_planks
fill 83 233 313 83 234 313 minecraft:spruce_planks
fill 83 233 315 83 234 315 minecraft:spruce_planks
fill 84 233 276 84 234 276 minecraft:spruce_planks
fill 84 233 278 84 234 278 minecraft:spruce_planks
fill 84 233 280 84 234 280 minecraft:spruce_planks
fill 84 233 282 84 234 282 minecraft:spruce_planks
fill 84 233 308 84 234 308 minecraft:spruce_planks
fill 84 233 310 84 234 310 minecraft:spruce_planks
fill 84 233 312 84 234 312 minecraft:white_wool
fill 84 233 314 84 234 314 minecraft:spruce_planks
fill 84 233 316 84 234 316 minecraft:spruce_planks
fill 85 233 277 85 234 277 minecraft:spruce_planks
fill 85 233 279 85 234 279 minecraft:spruce_planks
fill 85 233 281 85 234 281 minecraft:spruce_planks
fill 85 233 283 85 234 283 minecraft:spruce_planks
fill 85 233 307 85 234 307 minecraft:spruce_planks
fill 85 233 309 85 234 309 minecraft:spruce_planks
fill 85 233 311 85 234 311 minecraft:spruce_planks
fill 85 233 313 85 234 313 minecraft:spruce_planks
fill 85 233 315 85 234 315 minecraft:spruce_planks
fill 85 233 317 85 240 317 minecraft:cyan_concrete
fill 86 233 276 86 234 276 minecraft:spruce_planks
fill 86 233 278 86 234 278 minecraft:spruce_planks
fill 86 233 280 86 234 280 minecraft:spruce_planks
fill 86 233 282 86 234 282 minecraft:spruce_planks
setblock 88 233 278 minecraft:spruce_planks
setblock 88 233 285 minecraft:spruce_planks
setblock 88 233 292 minecraft:spruce_planks
setblock 88 233 299 minecraft:spruce_planks
setblock 88 233 306 minecraft:spruce_planks
setblock 88 233 313 minecraft:spruce_planks
fill 89 233 299 89 249 299 minecraft:cyan_concrete
fill 47 234 297 47 249 297 minecraft:cyan_concrete
fill 47 234 309 47 237 309 minecraft:cyan_concrete
fill 47 234 315 47 249 315 minecraft:cyan_concrete
setblock 48 234 277 minecraft:spruce_planks
setblock 48 234 284 minecraft:spruce_planks
setblock 48 234 291 minecraft:spruce_planks
setblock 48 234 298 minecraft:spruce_planks
setblock 48 234 312 minecraft:spruce_planks
setblock 50 234 278 minecraft:light[level=15]
setblock 50 234 286 minecraft:light[level=15]
setblock 50 234 294 minecraft:light[level=15]
setblock 50 234 310 minecraft:light[level=15]
fill 51 234 275 51 245 275 minecraft:cyan_concrete
setblock 51 234 316 minecraft:spruce_planks
setblock 54 234 276 minecraft:spruce_planks
setblock 58 234 278 minecraft:light[level=15]
setblock 58 234 286 minecraft:light[level=15]
setblock 58 234 294 minecraft:light[level=15]
setblock 58 234 302 minecraft:light[level=15]
setblock 58 234 310 minecraft:light[level=15]
setblock 58 234 316 minecraft:spruce_planks
setblock 61 234 276 minecraft:spruce_planks
fill 64 234 317 64 249 317 minecraft:cyan_concrete
setblock 65 234 316 minecraft:spruce_planks
setblock 66 234 278 minecraft:light[level=15]
setblock 66 234 286 minecraft:light[level=15]
setblock 66 234 294 minecraft:light[level=15]
setblock 66 234 302 minecraft:light[level=15]
setblock 66 234 310 minecraft:light[level=15]
setblock 68 234 276 minecraft:spruce_planks
setblock 72 234 316 minecraft:spruce_planks
setblock 74 234 278 minecraft:light[level=15]
setblock 74 234 286 minecraft:light[level=15]
setblock 74 234 294 minecraft:light[level=15]
setblock 74 234 302 minecraft:light[level=15]
setblock 74 234 310 minecraft:light[level=15]
setblock 75 234 276 minecraft:spruce_planks
fill 76 234 317 76 245 317 minecraft:cyan_concrete
setblock 82 234 286 minecraft:light[level=15]
setblock 82 234 294 minecraft:light[level=15]
setblock 82 234 302 minecraft:light[level=15]
setblock 86 234 316 minecraft:spruce_planks
setblock 88 234 277 minecraft:spruce_planks
setblock 88 234 284 minecraft:spruce_planks
setblock 88 234 291 minecraft:spruce_planks
setblock 88 234 298 minecraft:spruce_planks
setblock 88 234 305 minecraft:spruce_planks
setblock 47 235 281 minecraft:white_wool
setblock 48 235 278 minecraft:spruce_planks
setblock 48 235 285 minecraft:spruce_planks
setblock 48 235 292 minecraft:spruce_planks
setblock 48 235 299 minecraft:spruce_planks
setblock 48 235 313 minecraft:spruce_planks
fill 49 235 291 49 236 297 minecraft:iron_bars
setblock 52 235 316 minecraft:spruce_planks
setblock 53 235 276 minecraft:spruce_planks
fill 56 235 294 56 244 302 minecraft:white_wool
setblock 59 235 316 minecraft:spruce_planks
setblock 60 235 276 minecraft:spruce_planks
setblock 66 235 316 minecraft:spruce_planks
setblock 67 235 276 minecraft:spruce_planks
setblock 68 235 317 minecraft:light_blue_wool
fill 69 235 317 71 249 317 minecraft:cyan_concrete
setblock 73 235 316 minecraft:spruce_planks
setblock 74 235 276 minecraft:spruce_planks
setblock 75 235 307 minecraft:shroomlight
setblock 75 235 309 minecraft:shroomlight
setblock 75 235 311 minecraft:shroomlight
setblock 75 235 313 minecraft:shroomlight
setblock 75 235 315 minecraft:shroomlight
setblock 76 235 308 minecraft:shroomlight
setblock 76 235 310 minecraft:shroomlight
setblock 76 235 312 minecraft:shroomlight
setblock 76 235 314 minecraft:shroomlight
setblock 76 235 316 minecraft:shroomlight
setblock 77 235 307 minecraft:shroomlight
setblock 77 235 309 minecraft:shroomlight
setblock 77 235 311 minecraft:shroomlight
setblock 77 235 313 minecraft:shroomlight
setblock 77 235 315 minecraft:shroomlight
setblock 78 235 308 minecraft:shroomlight
setblock 78 235 310 minecraft:shroomlight
setblock 78 235 312 minecraft:shroomlight
setblock 78 235 314 minecraft:shroomlight
setblock 78 235 316 minecraft:shroomlight
setblock 79 235 307 minecraft:shroomlight
setblock 79 235 309 minecraft:shroomlight
setblock 79 235 311 minecraft:shroomlight
setblock 79 235 313 minecraft:shroomlight
setblock 79 235 315 minecraft:shroomlight
setblock 80 235 276 minecraft:shroomlight
setblock 80 235 278 minecraft:shroomlight
setblock 80 235 280 minecraft:shroomlight
setblock 80 235 282 minecraft:shroomlight
setblock 80 235 308 minecraft:shroomlight
setblock 80 235 310 minecraft:shroomlight
setblock 80 235 312 minecraft:shroomlight
setblock 80 235 314 minecraft:shroomlight
setblock 80 235 316 minecraft:shroomlight
setblock 81 235 277 minecraft:shroomlight
setblock 81 235 279 minecraft:shroomlight
setblock 81 235 281 minecraft:shroomlight
setblock 81 235 283 minecraft:shroomlight
setblock 81 235 307 minecraft:shroomlight
setblock 81 235 309 minecraft:shroomlight
setblock 81 235 311 minecraft:shroomlight
setblock 81 235 313 minecraft:shroomlight
setblock 81 235 315 minecraft:shroomlight
setblock 82 235 276 minecraft:shroomlight
setblock 82 235 278 minecraft:shroomlight
setblock 82 235 280 minecraft:shroomlight
setblock 82 235 282 minecraft:shroomlight
setblock 82 235 308 minecraft:shroomlight
setblock 82 235 310 minecraft:shroomlight
setblock 82 235 312 minecraft:shroomlight
setblock 82 235 314 minecraft:shroomlight
setblock 82 235 316 minecraft:shroomlight
setblock 83 235 277 minecraft:shroomlight
setblock 83 235 279 minecraft:shroomlight
setblock 83 235 281 minecraft:shroomlight
setblock 83 235 283 minecraft:shroomlight
setblock 83 235 307 minecraft:shroomlight
setblock 83 235 309 minecraft:shroomlight
setblock 83 235 311 minecraft:shroomlight
setblock 83 235 313 minecraft:shroomlight
setblock 83 235 315 minecraft:shroomlight
setblock 84 235 276 minecraft:shroomlight
setblock 84 235 278 minecraft:shroomlight
setblock 84 235 280 minecraft:shroomlight
setblock 84 235 282 minecraft:shroomlight
setblock 84 235 308 minecraft:shroomlight
setblock 84 235 310 minecraft:shroomlight
setblock 84 235 312 minecraft:shroomlight
setblock 84 235 314 minecraft:shroomlight
setblock 84 235 316 minecraft:shroomlight
setblock 85 235 277 minecraft:shroomlight
setblock 85 235 279 minecraft:shroomlight
setblock 85 235 281 minecraft:shroomlight
setblock 85 235 283 minecraft:shroomlight
setblock 85 235 307 minecraft:shroomlight
setblock 85 235 309 minecraft:shroomlight
setblock 85 235 311 minecraft:shroomlight
setblock 85 235 313 minecraft:shroomlight
setblock 85 235 315 minecraft:shroomlight
setblock 86 235 276 minecraft:shroomlight
setblock 86 235 278 minecraft:shroomlight
setblock 86 235 280 minecraft:shroomlight
setblock 86 235 282 minecraft:shroomlight
setblock 87 235 316 minecraft:spruce_planks
setblock 88 235 276 minecraft:spruce_planks
setblock 88 235 283 minecraft:spruce_planks
setblock 88 235 290 minecraft:spruce_planks
setblock 88 235 297 minecraft:spruce_planks
setblock 88 235 304 minecraft:spruce_planks
setblock 88 235 311 minecraft:spruce_planks
setblock 89 235 308 minecraft:light_blue_wool
fill 47 236 281 47 249 281 minecraft:cyan_concrete
setblock 47 236 301 minecraft:white_wool
setblock 47 236 312 minecraft:light_blue_wool
setblock 48 236 279 minecraft:spruce_planks
setblock 48 236 286 minecraft:spruce_planks
setblock 48 236 293 minecraft:spruce_planks
setblock 48 236 300 minecraft:spruce_planks
fill 48 236 314 48 238 314 minecraft:spruce_planks
setblock 50 236 278 minecraft:light[level=12]
setblock 50 236 285 minecraft:light[level=12]
setblock 50 236 292 minecraft:light[level=12]
setblock 50 236 299 minecraft:light[level=12]
setblock 50 236 313 minecraft:light[level=12]
setblock 52 236 276 minecraft:spruce_planks
setblock 53 236 316 minecraft:spruce_planks
setblock 57 236 278 minecraft:light[level=12]
setblock 57 236 285 minecraft:light[level=12]
setblock 57 236 292 minecraft:light[level=12]
setblock 57 236 299 minecraft:light[level=12]
setblock 57 236 306 minecraft:light[level=12]
setblock 57 236 313 minecraft:light[level=12]
setblock 59 236 276 minecraft:spruce_planks
setblock 60 236 316 minecraft:spruce_planks
setblock 64 236 278 minecraft:light[level=12]
setblock 64 236 285 minecraft:light[level=12]
setblock 64 236 292 minecraft:light[level=12]
setblock 64 236 306 minecraft:light[level=12]
setblock 64 236 313 minecraft:light[level=12]
setblock 66 236 276 minecraft:spruce_planks
setblock 67 236 316 minecraft:spruce_planks
setblock 68 236 317 minecraft:white_wool
setblock 71 236 278 minecraft:light[level=12]
setblock 71 236 285 minecraft:light[level=12]
setblock 71 236 292 minecraft:light[level=12]
setblock 71 236 299 minecraft:light[level=12]
setblock 71 236 306 minecraft:light[level=12]
setblock 71 236 313 minecraft:light[level=12]
setblock 73 236 276 minecraft:spruce_planks
setblock 74 236 316 minecraft:spruce_planks
fill 75 236 307 75 237 307 minecraft:spruce_planks
fill 75 236 309 75 237 309 minecraft:spruce_planks
fill 75 236 311 75 237 311 minecraft:spruce_planks
fill 75 236 313 75 237 313 minecraft:spruce_planks
fill 75 236 315 75 237 315 minecraft:spruce_planks
fill 76 236 308 76 237 308 minecraft:spruce_planks
fill 76 236 310 76 237 310 minecraft:spruce_planks
fill 76 236 312 76 237 312 minecraft:spruce_planks
fill 76 236 314 76 237 314 minecraft:spruce_planks
fill 76 236 316 76 237 316 minecraft:spruce_planks
fill 77 236 307 77 237 307 minecraft:spruce_planks
fill 77 236 309 77 237 309 minecraft:spruce_planks
fill 77 236 311 77 237 311 minecraft:spruce_planks
fill 77 236 313 77 237 313 minecraft:spruce_planks
fill 77 236 315 77 237 315 minecraft:spruce_planks
setblock 78 236 278 minecraft:light[level=12]
setblock 78 236 285 minecraft:light[level=12]
setblock 78 236 292 minecraft:light[level=12]
setblock 78 236 299 minecraft:light[level=12]
setblock 78 236 306 minecraft:light[level=12]
fill 78 236 308 78 237 308 minecraft:spruce_planks
fill 78 236 310 78 237 310 minecraft:spruce_planks
fill 78 236 312 78 237 312 minecraft:spruce_planks
fill 78 236 314 78 237 314 minecraft:spruce_planks
fill 78 236 316 78 237 316 minecraft:spruce_planks
fill 79 236 307 79 237 307 minecraft:spruce_planks
fill 79 236 309 79 237 309 minecraft:spruce_planks
fill 79 236 311 79 237 311 minecraft:spruce_planks
fill 79 236 313 79 237 313 minecraft:spruce_planks
fill 79 236 315 79 237 315 minecraft:spruce_planks
fill 80 236 276 80 237 276 minecraft:spruce_planks
fill 80 236 278 80 237 278 minecraft:spruce_planks
fill 80 236 280 80 237 280 minecraft:spruce_planks
fill 80 236 282 80 237 282 minecraft:spruce_planks
fill 80 236 308 80 237 308 minecraft:spruce_planks
fill 80 236 310 80 237 310 minecraft:spruce_planks
fill 80 236 312 80 237 312 minecraft:white_wool
fill 80 236 314 80 237 314 minecraft:spruce_planks
fill 80 236 316 80 237 316 minecraft:spruce_planks
fill 81 236 277 81 237 277 minecraft:spruce_planks
fill 81 236 279 81 237 279 minecraft:spruce_planks
fill 81 236 281 81 237 281 minecraft:spruce_planks
fill 81 236 283 81 237 283 minecraft:spruce_planks
fill 81 236 307 81 237 307 minecraft:spruce_planks
fill 81 236 309 81 237 309 minecraft:spruce_planks
fill 81 236 311 81 237 311 minecraft:spruce_planks
fill 81 236 313 81 237 313 minecraft:spruce_planks
fill 81 236 315 81 237 315 minecraft:spruce_planks
fill 82 236 276 82 237 276 minecraft:spruce_planks
fill 82 236 278 82 237 278 minecraft:spruce_planks
fill 82 236 280 82 237 280 minecraft:spruce_planks
fill 82 236 282 82 237 282 minecraft:spruce_planks
fill 82 236 308 82 237 308 minecraft:spruce_planks
fill 82 236 310 82 237 310 minecraft:spruce_planks
fill 82 236 312 82 237 312 minecraft:white_wool
fill 82 236 314 82 237 314 minecraft:spruce_planks
fill 82 236 316 82 237 316 minecraft:spruce_planks
fill 83 236 277 83 237 277 minecraft:spruce_planks
fill 83 236 279 83 237 279 minecraft:spruce_planks
fill 83 236 281 83 237 281 minecraft:spruce_planks
fill 83 236 283 83 237 283 minecraft:spruce_planks
fill 83 236 307 83 237 307 minecraft:spruce_planks
fill 83 236 309 83 237 309 minecraft:spruce_planks
fill 83 236 311 83 237 311 minecraft:spruce_planks
fill 83 236 313 83 237 313 minecraft:spruce_planks
fill 83 236 315 83 237 315 minecraft:spruce_planks
fill 84 236 276 84 237 276 minecraft:spruce_planks
fill 84 236 278 84 237 278 minecraft:spruce_planks
fill 84 236 280 84 237 280 minecraft:spruce_planks
fill 84 236 282 84 237 282 minecraft:spruce_planks
fill 84 236 308 84 237 308 minecraft:spruce_planks
fill 84 236 310 84 237 310 minecraft:spruce_planks
fill 84 236 312 84 237 312 minecraft:white_wool
fill 84 236 314 84 237 314 minecraft:spruce_planks
fill 84 236 316 84 237 316 minecraft:spruce_planks
fill 85 236 277 85 237 277 minecraft:spruce_planks
fill 85 236 279 85 237 279 minecraft:spruce_planks
fill 85 236 281 85 237 281 minecraft:spruce_planks
fill 85 236 283 85 237 283 minecraft:spruce_planks
setblock 85 236 285 minecraft:light[level=12]
setblock 85 236 292 minecraft:light[level=12]
setblock 85 236 299 minecraft:light[level=12]
setblock 85 236 306 minecraft:light[level=12]
fill 85 236 307 85 237 307 minecraft:spruce_planks
fill 85 236 309 85 237 309 minecraft:spruce_planks
fill 85 236 311 85 237 311 minecraft:spruce_planks
fill 85 236 313 85 237 313 minecraft:spruce_planks
fill 85 236 315 85 237 315 minecraft:spruce_planks
fill 86 236 276 87 236 276 minecraft:spruce_planks
fill 86 236 278 86 237 278 minecraft:spruce_planks
fill 86 236 280 86 237 280 minecraft:spruce_planks
fill 86 236 282 86 237 282 minecraft:spruce_planks
fill 86 236 314 87 237 314 minecraft:spruce_planks
setblock 88 236 282 minecraft:spruce_planks
setblock 88 236 289 minecraft:spruce_planks
setblock 88 236 296 minecraft:spruce_planks
setblock 88 236 303 minecraft:spruce_planks
setblock 88 236 310 minecraft:spruce_planks
setblock 88 236 316 minecraft:spruce_planks
setblock 89 236 297 minecraft:light_blue_wool
fill 89 236 298 89 245 298 minecraft:cyan_concrete
fill 89 236 308 89 249 308 minecraft:cyan_concrete
fill 47 237 301 47 247 301 minecraft:cyan_concrete
fill 47 237 312 47 249 312 minecraft:cyan_concrete
fill 48 237 278 50 238 278 minecraft:spruce_planks
fill 48 237 284 88 237 284 minecraft:spruce_planks
setblock 48 237 287 minecraft:spruce_planks
fill 48 237 290 88 237 290 minecraft:spruce_planks
setblock 48 237 294 minecraft:spruce_planks
fill 48 237 296 55 238 296 minecraft:spruce_planks
fill 48 237 308 74 237 308 minecraft:spruce_planks
setblock 48 237 315 minecraft:spruce_planks
fill 49 237 314 74 237 314 minecraft:spruce_planks
setblock 51 237 276 minecraft:spruce_planks
setblock 54 237 316 minecraft:spruce_planks
fill 55 237 275 55 245 275 minecraft:cyan_concrete
setblock 56 237 275 minecraft:white_wool
fill 57 237 296 62 238 296 minecraft:spruce_planks
setblock 58 237 276 minecraft:spruce_planks
setblock 61 237 316 minecraft:spruce_planks
setblock 65 237 276 minecraft:spruce_planks
fill 65 237 315 66 237 315 minecraft:white_concrete
setblock 66 237 317 minecraft:light_blue_wool
fill 68 237 296 87 238 296 minecraft:spruce_planks
setblock 68 237 316 minecraft:spruce_planks
fill 68 237 317 68 245 317 minecraft:cyan_concrete
setblock 72 237 276 minecraft:spruce_planks
setblock 79 237 276 minecraft:spruce_planks
setblock 86 237 276 minecraft:spruce_planks
fill 86 237 308 87 237 308 minecraft:spruce_planks
setblock 88 237 281 minecraft:spruce_planks
setblock 88 237 288 minecraft:spruce_planks
setblock 88 237 295 minecraft:spruce_planks
setblock 88 237 302 minecraft:spruce_planks
setblock 88 237 309 minecraft:spruce_planks
fill 89 237 297 89 249 297 minecraft:cyan_concrete
setblock 47 238 286 minecraft:white_wool
setblock 47 238 296 minecraft:white_wool
setblock 47 238 309 minecraft:white_wool
fill 48 238 284 60 238 284 minecraft:spruce_planks
fill 48 238 290 52 238 290 minecraft:spruce_planks
fill 48 238 308 70 238 308 minecraft:spruce_planks
fill 49 238 314 51 238 314 minecraft:spruce_planks
fill 51 238 278 79 238 278 minecraft:spruce_planks
fill 55 238 276 55 239 277 minecraft:spruce_planks
fill 55 238 279 55 239 279 minecraft:spruce_planks
fill 55 238 281 55 239 283 minecraft:spruce_planks
fill 55 238 285 55 239 285 minecraft:spruce_planks
fill 56 238 275 56 249 275 minecraft:cyan_concrete
fill 56 238 313 56 239 315 minecraft:iron_bars
fill 57 238 302 63 238 302 minecraft:spruce_planks
fill 66 238 317 66 249 317 minecraft:cyan_concrete
fill 67 238 302 87 238 302 minecraft:spruce_planks
setblock 75 238 307 minecraft:shroomlight
setblock 75 238 309 minecraft:shroomlight
setblock 75 238 311 minecraft:shroomlight
setblock 75 238 313 minecraft:shroomlight
setblock 75 238 315 minecraft:shroomlight
setblock 76 238 308 minecraft:shroomlight
setblock 76 238 310 minecraft:shroomlight
setblock 76 238 312 minecraft:shroomlight
setblock 76 238 314 minecraft:shroomlight
setblock 76 238 316 minecraft:shroomlight
setblock 77 238 307 minecraft:shroomlight
setblock 77 238 309 minecraft:shroomlight
setblock 77 238 311 minecraft:shroomlight
setblock 77 238 313 minecraft:shroomlight
setblock 77 238 315 minecraft:shroomlight
setblock 78 238 308 minecraft:shroomlight
setblock 78 238 310 minecraft:shroomlight
setblock 78 238 312 minecraft:shroomlight
setblock 78 238 314 minecraft:shroomlight
setblock 78 238 316 minecraft:shroomlight
setblock 79 238 307 minecraft:shroomlight
setblock 79 238 309 minecraft:shroomlight
setblock 79 238 311 minecraft:shroomlight
setblock 79 238 313 minecraft:shroomlight
setblock 79 238 315 minecraft:shroomlight
setblock 80 238 276 minecraft:shroomlight
setblock 80 238 278 minecraft:shroomlight
setblock 80 238 280 minecraft:shroomlight
setblock 80 238 282 minecraft:shroomlight
fill 80 238 301 80 239 301 minecraft:iron_bars
fill 80 238 303 80 238 307 minecraft:iron_bars
setblock 80 238 308 minecraft:shroomlight
setblock 80 238 309 minecraft:iron_bars
setblock 80 238 310 minecraft:shroomlight
setblock 80 238 311 minecraft:iron_bars
setblock 80 238 312 minecraft:shroomlight
setblock 80 238 313 minecraft:iron_bars
setblock 80 238 314 minecraft:shroomlight
setblock 80 238 315 minecraft:iron_bars
setblock 80 238 316 minecraft:shroomlight
setblock 81 238 277 minecraft:shroomlight
setblock 81 238 279 minecraft:shroomlight
setblock 81 238 281 minecraft:shroomlight
setblock 81 238 283 minecraft:shroomlight
setblock 81 238 307 minecraft:shroomlight
setblock 81 238 309 minecraft:shroomlight
setblock 81 238 311 minecraft:shroomlight
setblock 81 238 313 minecraft:shroomlight
setblock 81 238 315 minecraft:shroomlight
setblock 82 238 276 minecraft:shroomlight
setblock 82 238 278 minecraft:shroomlight
setblock 82 238 280 minecraft:shroomlight
setblock 82 238 282 minecraft:shroomlight
setblock 82 238 308 minecraft:shroomlight
setblock 82 238 310 minecraft:shroomlight
setblock 82 238 312 minecraft:shroomlight
setblock 82 238 314 minecraft:shroomlight
setblock 82 238 316 minecraft:shroomlight
setblock 83 238 277 minecraft:shroomlight
setblock 83 238 279 minecraft:shroomlight
setblock 83 238 281 minecraft:shroomlight
setblock 83 238 283 minecraft:shroomlight
setblock 83 238 307 minecraft:shroomlight
setblock 83 238 309 minecraft:shroomlight
setblock 83 238 311 minecraft:shroomlight
setblock 83 238 313 minecraft:shroomlight
setblock 83 238 315 minecraft:shroomlight
setblock 84 238 276 minecraft:shroomlight
setblock 84 238 278 minecraft:shroomlight
setblock 84 238 280 minecraft:shroomlight
setblock 84 238 282 minecraft:shroomlight
setblock 84 238 308 minecraft:shroomlight
setblock 84 238 310 minecraft:shroomlight
setblock 84 238 312 minecraft:shroomlight
setblock 84 238 314 minecraft:shroomlight
setblock 84 238 316 minecraft:shroomlight
setblock 85 238 277 minecraft:shroomlight
setblock 85 238 279 minecraft:shroomlight
setblock 85 238 281 minecraft:shroomlight
setblock 85 238 283 minecraft:shroomlight
setblock 85 238 307 minecraft:shroomlight
setblock 85 238 309 minecraft:shroomlight
setblock 85 238 311 minecraft:shroomlight
setblock 85 238 313 minecraft:shroomlight
setblock 85 238 315 minecraft:shroomlight
setblock 86 238 276 minecraft:shroomlight
setblock 86 238 278 minecraft:shroomlight
setblock 86 238 280 minecraft:shroomlight
setblock 86 238 282 minecraft:shroomlight
fill 86 238 307 86 239 311 minecraft:iron_bars
fill 86 238 313 86 238 315 minecraft:iron_bars
fill 47 239 286 47 249 286 minecraft:cyan_concrete
fill 47 239 296 47 249 296 minecraft:cyan_concrete
fill 47 239 309 47 245 309 minecraft:cyan_concrete
fill 48 239 280 56 239 280 minecraft:spruce_log
fill 48 239 282 48 240 282 minecraft:spruce_planks
fill 48 239 289 48 240 289 minecraft:spruce_planks
fill 48 239 296 48 240 296 minecraft:spruce_planks
fill 48 239 310 48 240 310 minecraft:spruce_planks
fill 49 239 276 49 240 276 minecraft:spruce_planks
fill 49 239 316 49 240 316 minecraft:spruce_planks
fill 50 239 277 50 240 278 minecraft:iron_bars
fill 50 239 314 50 240 314 minecraft:green_terracotta
setblock 53 239 275 minecraft:white_wool
setblock 54 239 279 minecraft:spruce_planks
fill 54 239 281 54 239 299 minecraft:spruce_planks
setblock 55 239 278 minecraft:spruce_planks
setblock 55 239 284 minecraft:spruce_planks
fill 55 239 286 55 240 300 minecraft:spruce_planks
fill 56 239 276 56 240 276 minecraft:spruce_planks
fill 56 239 277 56 240 279 minecraft:iron_bars
fill 56 239 281 56 239 293 minecraft:iron_bars
fill 56 239 303 56 239 312 minecraft:iron_bars
fill 56 239 316 56 240 316 minecraft:spruce_planks
setblock 57 239 317 minecraft:light_blue_wool
fill 62 239 276 62 239 280 minecraft:iron_bars
fill 63 239 276 63 240 276 minecraft:spruce_planks
fill 63 239 316 63 240 316 minecraft:spruce_planks
fill 68 239 276 68 239 297 minecraft:iron_bars
fill 68 239 301 68 240 314 minecraft:iron_bars
fill 70 239 276 70 240 276 minecraft:spruce_planks
fill 70 239 316 70 240 316 minecraft:spruce_planks
fill 74 239 276 74 239 277 minecraft:iron_bars
fill 74 239 278 80 239 278 minecraft:spruce_planks
fill 74 239 279 74 239 316 minecraft:iron_bars
fill 75 239 307 75 240 307 minecraft:spruce_planks
fill 75 239 309 75 240 309 minecraft:spruce_planks
fill 75 239 311 75 240 311 minecraft:spruce_planks
fill 75 239 313 75 240 313 minecraft:spruce_planks
fill 75 239 315 75 240 315 minecraft:spruce_planks
fill 76 239 308 76 240 308 minecraft:spruce_planks
fill 76 239 310 76 240 310 minecraft:spruce_planks
fill 76 239 312 76 240 312 minecraft:spruce_planks
fill 76 239 314 76 240 314 minecraft:spruce_planks
fill 76 239 316 76 240 316 minecraft:spruce_planks
fill 77 239 276 77 240 276 minecraft:spruce_planks
fill 77 239 307 77 240 307 minecraft:spruce_planks
fill 77 239 309 77 240 309 minecraft:spruce_planks
fill 77 239 311 77 240 311 minecraft:spruce_planks
fill 77 239 313 77 240 313 minecraft:spruce_planks
fill 77 239 315 77 240 315 minecraft:spruce_planks
fill 78 239 308 78 240 308 minecraft:spruce_planks
fill 78 239 310 78 240 310 minecraft:spruce_planks
fill 78 239 312 78 240 312 minecraft:spruce_planks
fill 78 239 314 78 240 314 minecraft:spruce_planks
fill 78 239 316 78 240 316 minecraft:spruce_planks
fill 79 239 307 81 240 307 minecraft:spruce_planks
fill 79 239 309 81 240 309 minecraft:spruce_planks
fill 79 239 311 81 240 311 minecraft:spruce_planks
fill 79 239 313 81 240 313 minecraft:spruce_planks
fill 79 239 315 81 240 315 minecraft:spruce_planks
fill 80 239 275 81 239 275 minecraft:light_blue_wool
fill 80 239 276 80 239 277 minecraft:iron_bars
fill 80 239 279 80 239 300 minecraft:iron_bars
fill 80 239 302 80 239 305 minecraft:iron_bars
fill 80 239 308 80 240 308 minecraft:spruce_planks
fill 80 239 310 80 240 310 minecraft:spruce_planks
fill 80 239 312 88 239 312 minecraft:spruce_log
fill 80 239 314 80 240 314 minecraft:spruce_planks
fill 80 239 316 80 240 316 minecraft:spruce_planks
fill 81 239 277 81 240 277 minecraft:spruce_planks
fill 81 239 279 81 240 279 minecraft:spruce_planks
fill 81 239 281 81 240 281 minecraft:spruce_planks
fill 81 239 283 81 240 283 minecraft:spruce_planks
fill 82 239 276 82 240 276 minecraft:spruce_planks
fill 82 239 278 82 240 278 minecraft:spruce_planks
fill 82 239 280 82 240 280 minecraft:spruce_planks
fill 82 239 282 82 240 282 minecraft:spruce_planks
fill 82 239 308 82 240 308 minecraft:spruce_planks
fill 82 239 310 82 240 310 minecraft:spruce_planks
fill 82 239 314 82 240 314 minecraft:spruce_planks
fill 82 239 316 82 240 316 minecraft:spruce_planks
fill 83 239 277 83 240 277 minecraft:spruce_planks
fill 83 239 279 83 240 279 minecraft:spruce_planks
fill 83 239 281 83 240 281 minecraft:spruce_planks
fill 83 239 283 83 240 283 minecraft:spruce_planks
fill 83 239 307 83 240 307 minecraft:spruce_planks
fill 83 239 309 83 240 309 minecraft:spruce_planks
fill 83 239 311 83 240 311 minecraft:spruce_planks
fill 83 239 313 83 240 313 minecraft:spruce_planks
fill 83 239 315 83 240 315 minecraft:spruce_planks
fill 84 239 276 84 240 276 minecraft:spruce_planks
fill 84 239 278 84 240 278 minecraft:spruce_planks
fill 84 239 280 84 240 280 minecraft:spruce_planks
fill 84 239 282 84 240 282 minecraft:spruce_planks
fill 84 239 308 84 240 308 minecraft:spruce_planks
fill 84 239 310 84 240 310 minecraft:spruce_planks
fill 84 239 314 84 240 314 minecraft:spruce_planks
fill 84 239 316 84 240 316 minecraft:spruce_planks
fill 85 239 277 85 240 277 minecraft:spruce_planks
fill 85 239 279 85 240 279 minecraft:spruce_planks
fill 85 239 281 85 240 281 minecraft:spruce_planks
fill 85 239 283 85 240 283 minecraft:spruce_planks
fill 85 239 307 85 240 307 minecraft:spruce_planks
fill 85 239 309 85 240 309 minecraft:spruce_planks
fill 85 239 311 85 240 311 minecraft:spruce_planks
fill 85 239 313 85 240 313 minecraft:spruce_planks
fill 85 239 315 85 240 315 minecraft:spruce_planks
fill 86 239 276 86 239 277 minecraft:iron_bars
fill 86 239 278 88 239 278 minecraft:spruce_planks
fill 86 239 279 86 239 301 minecraft:iron_bars
fill 86 239 302 87 239 302 minecraft:spruce_planks
fill 86 239 303 86 239 306 minecraft:iron_bars
setblock 86 239 313 minecraft:iron_bars
fill 88 239 279 88 240 279 minecraft:spruce_planks
fill 88 239 286 88 240 286 minecraft:spruce_planks
fill 88 239 293 88 240 293 minecraft:spruce_planks
fill 88 239 300 88 240 300 minecraft:spruce_planks
fill 88 239 307 88 240 307 minecraft:spruce_planks
fill 88 239 314 88 240 314 minecraft:spruce_planks
setblock 89 239 312 minecraft:light_blue_wool
fill 48 240 276 48 240 280 minecraft:spruce_planks
fill 48 240 283 48 240 287 minecraft:spruce_planks
fill 48 240 290 48 240 294 minecraft:spruce_planks
fill 48 240 297 48 240 300 minecraft:spruce_planks
setblock 48 240 308 minecraft:spruce_planks
fill 48 240 311 48 240 315 minecraft:spruce_planks
fill 49 240 301 49 246 307 minecraft:spruce_planks
fill 50 240 279 50 240 306 minecraft:iron_bars
fill 50 240 307 55 240 307 minecraft:spruce_planks
fill 50 240 316 54 240 316 minecraft:spruce_planks
fill 51 240 276 55 240 276 minecraft:spruce_planks
fill 51 240 280 53 255 280 minecraft:spruce_log
fill 51 240 301 55 246 306 minecraft:spruce_planks
fill 53 240 275 53 247 275 minecraft:cyan_concrete
fill 54 240 293 54 240 300 minecraft:spruce_planks
fill 54 240 308 55 240 315 minecraft:spruce_planks
fill 55 240 277 55 240 285 minecraft:dark_oak_planks
fill 57 240 316 61 240 316 minecraft:spruce_planks
fill 57 240 317 57 242 317 minecraft:cyan_concrete
fill 58 240 276 62 240 276 minecraft:spruce_planks
fill 62 240 277 62 240 296 minecraft:iron_bars
fill 62 240 301 62 240 315 minecraft:iron_bars
fill 64 240 316 68 240 316 minecraft:spruce_planks
fill 65 240 276 69 240 276 minecraft:spruce_planks
fill 68 240 277 68 240 296 minecraft:iron_bars
setblock 68 240 315 minecraft:iron_bars
fill 71 240 316 74 240 316 minecraft:spruce_planks
fill 72 240 276 76 240 276 minecraft:spruce_planks
fill 74 240 277 74 240 285 minecraft:iron_bars
fill 79 240 276 80 240 276 minecraft:spruce_planks
fill 80 240 275 81 249 275 minecraft:cyan_concrete
fill 80 240 277 80 240 278 minecraft:iron_bars
fill 80 240 279 80 240 283 minecraft:spruce_planks
fill 80 240 312 82 240 312 minecraft:spruce_planks
fill 83 240 312 85 240 312 minecraft:spruce_log
fill 86 240 276 88 240 276 minecraft:spruce_planks
fill 86 240 277 86 240 278 minecraft:iron_bars
fill 86 240 279 86 240 283 minecraft:spruce_planks
fill 86 240 316 88 240 316 minecraft:spruce_planks
fill 88 240 277 88 240 278 minecraft:spruce_planks
fill 88 240 281 88 240 285 minecraft:spruce_planks
fill 88 240 288 88 240 292 minecraft:spruce_planks
fill 88 240 295 88 240 299 minecraft:spruce_planks
fill 88 240 302 88 240 306 minecraft:spruce_planks
fill 88 240 309 88 240 313 minecraft:spruce_planks
fill 89 240 312 89 250 312 minecraft:cyan_concrete
setblock 48 241 277 minecraft:spruce_planks
fill 48 241 279 50 242 279 minecraft:iron_bars
setblock 48 241 284 minecraft:spruce_planks
setblock 48 241 291 minecraft:spruce_planks
setblock 48 241 298 minecraft:spruce_planks
setblock 48 241 312 minecraft:spruce_planks
setblock 49 241 317 minecraft:white_wool
fill 50 241 301 50 241 316 minecraft:iron_bars
fill 51 241 307 55 246 307 minecraft:spruce_planks
setblock 51 241 316 minecraft:spruce_planks
setblock 54 241 276 minecraft:spruce_planks
fill 54 241 310 54 241 316 minecraft:spruce_planks
fill 55 241 287 55 241 300 minecraft:dark_oak_planks
fill 55 241 308 55 241 315 minecraft:spruce_planks
setblock 58 241 316 minecraft:spruce_planks
setblock 61 241 276 minecraft:spruce_planks
setblock 65 241 316 minecraft:spruce_planks
setblock 68 241 276 minecraft:spruce_planks
setblock 72 241 316 minecraft:spruce_planks
setblock 75 241 276 minecraft:spruce_planks
setblock 75 241 307 minecraft:shroomlight
setblock 75 241 309 minecraft:shroomlight
setblock 75 241 311 minecraft:shroomlight
setblock 75 241 313 minecraft:shroomlight
setblock 75 241 315 minecraft:shroomlight
setblock 76 241 308 minecraft:shroomlight
setblock 76 241 310 minecraft:shroomlight
setblock 76 241 312 minecraft:shroomlight
setblock 76 241 314 minecraft:shroomlight
setblock 76 241 316 minecraft:shroomlight
setblock 77 241 307 minecraft:shroomlight
setblock 77 241 309 minecraft:shroomlight
setblock 77 241 311 minecraft:shroomlight
setblock 77 241 313 minecraft:shroomlight
setblock 77 241 315 minecraft:shroomlight
setblock 78 241 308 minecraft:shroomlight
setblock 78 241 310 minecraft:shroomlight
setblock 78 241 312 minecraft:shroomlight
setblock 78 241 314 minecraft:shroomlight
setblock 78 241 316 minecraft:shroomlight
setblock 79 241 307 minecraft:shroomlight
setblock 79 241 309 minecraft:shroomlight
setblock 79 241 311 minecraft:shroomlight
setblock 79 241 313 minecraft:shroomlight
setblock 79 241 315 minecraft:shroomlight
setblock 80 241 276 minecraft:shroomlight
fill 80 241 277 80 253 277 minecraft:spruce_planks
setblock 80 241 278 minecraft:shroomlight
fill 80 241 279 80 253 279 minecraft:spruce_planks
setblock 80 241 280 minecraft:shroomlight
fill 80 241 281 80 253 281 minecraft:spruce_planks
setblock 80 241 282 minecraft:shroomlight
fill 80 241 283 80 253 283 minecraft:spruce_planks
fill 80 241 307 80 255 307 minecraft:spruce_planks
setblock 80 241 308 minecraft:shroomlight
fill 80 241 309 80 255 309 minecraft:spruce_planks
setblock 80 241 310 minecraft:shroomlight
fill 80 241 311 80 255 311 minecraft:spruce_planks
setblock 80 241 312 minecraft:shroomlight
fill 80 241 313 80 255 313 minecraft:spruce_planks
setblock 80 241 314 minecraft:shroomlight
fill 80 241 315 80 255 315 minecraft:spruce_planks
setblock 80 241 316 minecraft:shroomlight
setblock 81 241 277 minecraft:shroomlight
setblock 81 241 279 minecraft:shroomlight
setblock 81 241 281 minecraft:shroomlight
setblock 81 241 283 minecraft:shroomlight
setblock 81 241 307 minecraft:shroomlight
setblock 81 241 309 minecraft:shroomlight
setblock 81 241 311 minecraft:shroomlight
fill 81 241 312 81 255 312 minecraft:spruce_planks
setblock 81 241 313 minecraft:shroomlight
setblock 81 241 315 minecraft:shroomlight
setblock 82 241 276 minecraft:shroomlight
setblock 82 241 278 minecraft:shroomlight
setblock 82 241 280 minecraft:shroomlight
setblock 82 241 282 minecraft:shroomlight
setblock 82 241 308 minecraft:shroomlight
setblock 82 241 310 minecraft:shroomlight
setblock 82 241 312 minecraft:shroomlight
setblock 82 241 314 minecraft:shroomlight
setblock 82 241 316 minecraft:shroomlight
setblock 83 241 277 minecraft:shroomlight
setblock 83 241 279 minecraft:shroomlight
setblock 83 241 281 minecraft:shroomlight
setblock 83 241 283 minecraft:shroomlight
setblock 83 241 307 minecraft:shroomlight
setblock 83 241 309 minecraft:shroomlight
setblock 83 241 311 minecraft:shroomlight
fill 83 241 312 83 255 312 minecraft:spruce_log
setblock 83 241 313 minecraft:shroomlight
setblock 83 241 315 minecraft:shroomlight
setblock 84 241 276 minecraft:shroomlight
setblock 84 241 278 minecraft:shroomlight
setblock 84 241 280 minecraft:shroomlight
setblock 84 241 282 minecraft:shroomlight
setblock 84 241 308 minecraft:shroomlight
setblock 84 241 310 minecraft:shroomlight
setblock 84 241 312 minecraft:shroomlight
setblock 84 241 314 minecraft:shroomlight
setblock 84 241 316 minecraft:shroomlight
setblock 85 241 277 minecraft:shroomlight
setblock 85 241 279 minecraft:shroomlight
setblock 85 241 281 minecraft:shroomlight
setblock 85 241 283 minecraft:shroomlight
setblock 85 241 307 minecraft:shroomlight
setblock 85 241 309 minecraft:shroomlight
setblock 85 241 311 minecraft:shroomlight
fill 85 241 312 85 255 312 minecraft:spruce_log
setblock 85 241 313 minecraft:shroomlight
setblock 85 241 315 minecraft:shroomlight
setblock 85 241 317 minecraft:white_wool
setblock 86 241 276 minecraft:shroomlight
fill 86 241 277 86 253 277 minecraft:spruce_planks
setblock 86 241 278 minecraft:shroomlight
fill 86 241 279 86 253 279 minecraft:spruce_planks
setblock 86 241 280 minecraft:shroomlight
fill 86 241 281 86 253 281 minecraft:spruce_planks
setblock 86 241 282 minecraft:shroomlight
fill 86 241 283 86 253 283 minecraft:spruce_planks
setblock 86 241 316 minecraft:spruce_planks
setblock 88 241 277 minecraft:spruce_planks
setblock 88 241 284 minecraft:spruce_planks
setblock 88 241 291 minecraft:spruce_planks
setblock 88 241 298 minecraft:spruce_planks
setblock 88 241 305 minecraft:spruce_planks
setblock 88 241 312 minecraft:spruce_planks
setblock 47 242 278 minecraft:light_blue_wool
setblock 48 242 278 minecraft:spruce_planks
setblock 48 242 285 minecraft:spruce_planks
setblock 48 242 292 minecraft:spruce_planks
setblock 48 242 299 minecraft:spruce_planks
setblock 48 242 313 minecraft:spruce_planks
fill 49 242 317 49 249 317 minecraft:cyan_concrete
setblock 50 242 278 minecraft:light[level=15]
setblock 50 242 285 minecraft:light[level=12]
setblock 50 242 286 minecraft:light[level=15]
setblock 50 242 292 minecraft:light[level=12]
setblock 50 242 294 minecraft:light[level=15]
setblock 50 242 299 minecraft:light[level=12]
fill 50 242 301 50 246 307 minecraft:spruce_planks
setblock 50 242 310 minecraft:light[level=15]
setblock 50 242 313 minecraft:light[level=12]
setblock 52 242 316 minecraft:spruce_planks
setblock 53 242 276 minecraft:spruce_planks
fill 55 242 310 55 242 315 minecraft:dark_oak_planks
setblock 57 242 278 minecraft:light[level=12]
setblock 57 242 285 minecraft:light[level=12]
setblock 57 242 292 minecraft:light[level=12]
setblock 57 242 299 minecraft:light[level=12]
setblock 57 242 306 minecraft:light[level=12]
setblock 57 242 313 minecraft:light[level=12]
setblock 58 242 278 minecraft:light[level=15]
setblock 58 242 286 minecraft:light[level=15]
setblock 58 242 294 minecraft:light[level=15]
setblock 58 242 302 minecraft:light[level=15]
setblock 58 242 310 minecraft:light[level=15]
setblock 59 242 316 minecraft:spruce_planks
setblock 60 242 276 minecraft:spruce_planks
setblock 64 242 278 minecraft:light[level=12]
setblock 64 242 285 minecraft:light[level=12]
setblock 64 242 292 minecraft:light[level=12]
setblock 64 242 306 minecraft:light[level=12]
setblock 64 242 313 minecraft:light[level=12]
setblock 66 242 278 minecraft:light[level=15]
setblock 66 242 286 minecraft:light[level=15]
setblock 66 242 294 minecraft:light[level=15]
setblock 66 242 302 minecraft:light[level=15]
setblock 66 242 310 minecraft:light[level=15]
setblock 66 242 316 minecraft:spruce_planks
setblock 67 242 276 minecraft:spruce_planks
setblock 71 242 278 minecraft:light[level=12]
setblock 71 242 285 minecraft:light[level=12]
setblock 71 242 292 minecraft:light[level=12]
setblock 71 242 299 minecraft:light[level=12]
setblock 71 242 306 minecraft:light[level=12]
setblock 71 242 313 minecraft:light[level=12]
setblock 73 242 316 minecraft:spruce_planks
setblock 74 242 276 minecraft:spruce_planks
setblock 74 242 278 minecraft:light[level=15]
setblock 74 242 286 minecraft:light[level=15]
setblock 74 242 294 minecraft:light[level=15]
setblock 74 242 302 minecraft:light[level=15]
setblock 74 242 310 minecraft:light[level=15]
fill 75 242 307 75 243 307 minecraft:spruce_planks
fill 75 242 309 75 243 309 minecraft:spruce_planks
fill 75 242 311 75 243 311 minecraft:spruce_planks
fill 75 242 313 75 243 313 minecraft:spruce_planks
fill 75 242 315 75 243 315 minecraft:spruce_planks
fill 76 242 308 76 243 308 minecraft:spruce_planks
fill 76 242 310 76 243 310 minecraft:spruce_planks
fill 76 242 312 76 243 312 minecraft:spruce_planks
fill 76 242 314 76 243 314 minecraft:spruce_planks
fill 76 242 316 76 243 316 minecraft:spruce_planks
fill 77 242 307 77 243 307 minecraft:spruce_planks
fill 77 242 309 77 243 309 minecraft:spruce_planks
fill 77 242 311 77 243 311 minecraft:spruce_planks
fill 77 242 313 77 243 313 minecraft:spruce_planks
fill 77 242 315 77 243 315 minecraft:spruce_planks
setblock 78 242 278 minecraft:light[level=12]
setblock 78 242 285 minecraft:light[level=12]
setblock 78 242 292 minecraft:light[level=12]
setblock 78 242 299 minecraft:light[level=12]
setblock 78 242 306 minecraft:light[level=12]
fill 78 242 308 78 243 308 minecraft:spruce_planks
fill 78 242 310 78 243 310 minecraft:spruce_planks
fill 78 242 312 78 243 312 minecraft:spruce_planks
fill 78 242 314 78 243 314 minecraft:spruce_planks
fill 78 242 316 78 243 316 minecraft:spruce_planks
fill 79 242 307 79 243 307 minecraft:spruce_planks
fill 79 242 309 79 243 309 minecraft:spruce_planks
fill 79 242 311 79 243 311 minecraft:spruce_planks
fill 79 242 313 79 243 313 minecraft:spruce_planks
fill 79 242 315 79 243 315 minecraft:spruce_planks
fill 80 242 276 80 243 276 minecraft:spruce_planks
fill 80 242 278 80 243 278 minecraft:spruce_planks
fill 80 242 280 80 243 280 minecraft:spruce_planks
fill 80 242 282 80 243 282 minecraft:spruce_planks
fill 80 242 308 80 243 308 minecraft:spruce_planks
fill 80 242 310 80 243 310 minecraft:spruce_planks
fill 80 242 312 80 243 312 minecraft:spruce_planks
fill 80 242 314 80 243 314 minecraft:spruce_planks
fill 80 242 316 80 243 316 minecraft:spruce_planks
fill 81 242 277 81 243 277 minecraft:spruce_planks
fill 81 242 279 81 243 279 minecraft:spruce_planks
fill 81 242 281 81 243 281 minecraft:spruce_planks
fill 81 242 283 81 243 283 minecraft:spruce_planks
fill 81 242 307 81 243 307 minecraft:spruce_planks
fill 81 242 309 81 243 309 minecraft:spruce_planks
fill 81 242 311 81 243 311 minecraft:spruce_planks
fill 81 242 313 81 243 313 minecraft:spruce_planks
fill 81 242 315 81 243 315 minecraft:spruce_planks
fill 82 242 276 82 243 276 minecraft:spruce_planks
fill 82 242 278 82 243 278 minecraft:spruce_planks
fill 82 242 280 82 243 280 minecraft:spruce_planks
fill 82 242 282 82 243 282 minecraft:spruce_planks
setblock 82 242 286 minecraft:light[level=15]
setblock 82 242 294 minecraft:light[level=15]
setblock 82 242 302 minecraft:light[level=15]
fill 82 242 308 82 243 308 minecraft:spruce_planks
fill 82 242 310 82 243 310 minecraft:spruce_planks
fill 82 242 312 82 243 312 minecraft:spruce_planks
fill 82 242 314 82 243 314 minecraft:spruce_planks
fill 82 242 316 82 243 316 minecraft:spruce_planks
fill 83 242 277 83 243 277 minecraft:spruce_planks
fill 83 242 279 83 243 279 minecraft:spruce_planks
fill 83 242 281 83 243 281 minecraft:spruce_planks
fill 83 242 283 83 243 283 minecraft:spruce_planks
fill 83 242 307 83 243 307 minecraft:spruce_planks
fill 83 242 309 83 243 309 minecraft:spruce_planks
fill 83 242 311 83 243 311 minecraft:spruce_planks
fill 83 242 313 83 243 313 minecraft:spruce_planks
fill 83 242 315 83 243 315 minecraft:spruce_planks
fill 84 242 276 84 243 276 minecraft:spruce_planks
fill 84 242 278 84 243 278 minecraft:spruce_planks
fill 84 242 280 84 243 280 minecraft:spruce_planks
fill 84 242 282 84 243 282 minecraft:spruce_planks
fill 84 242 308 84 243 308 minecraft:spruce_planks
fill 84 242 310 84 243 310 minecraft:spruce_planks
fill 84 242 312 84 243 312 minecraft:spruce_log
fill 84 242 314 84 243 314 minecraft:spruce_planks
fill 84 242 316 84 243 316 minecraft:spruce_planks
fill 85 242 277 85 243 277 minecraft:spruce_planks
fill 85 242 279 85 243 279 minecraft:spruce_planks
fill 85 242 281 85 243 281 minecraft:spruce_planks
fill 85 242 283 85 243 283 minecraft:spruce_planks
setblock 85 242 285 minecraft:light[level=12]
setblock 85 242 292 minecraft:light[level=12]
setblock 85 242 299 minecraft:light[level=12]
setblock 85 242 306 minecraft:light[level=12]
fill 85 242 307 85 243 307 minecraft:spruce_planks
fill 85 242 309 85 243 309 minecraft:spruce_planks
fill 85 242 311 85 243 311 minecraft:spruce_planks
fill 85 242 313 85 243 313 minecraft:spruce_planks
fill 85 242 315 85 243 315 minecraft:spruce_planks
fill 85 242 317 85 245 317 minecraft:cyan_concrete
fill 86 242 276 86 243 276 minecraft:spruce_planks
fill 86 242 278 86 243 278 minecraft:spruce_planks
fill 86 242 280 86 243 280 minecraft:spruce_planks
fill 86 242 282 86 243 282 minecraft:spruce_planks
setblock 87 242 316 minecraft:spruce_planks
setblock 88 242 276 minecraft:spruce_planks
setblock 88 242 283 minecraft:spruce_planks
setblock 88 242 290 minecraft:spruce_planks
setblock 88 242 297 minecraft:spruce_planks
setblock 88 242 304 minecraft:spruce_planks
setblock 88 242 311 minecraft:spruce_planks
fill 47 243 278 47 249 278 minecraft:cyan_concrete
setblock 48 243 279 minecraft:spruce_planks
setblock 48 243 286 minecraft:spruce_planks
setblock 48 243 293 minecraft:spruce_planks
setblock 48 243 300 minecraft:spruce_planks
setblock 48 243 314 minecraft:spruce_planks
setblock 52 243 276 minecraft:spruce_planks
setblock 53 243 316 minecraft:spruce_planks
setblock 57 243 317 minecraft:white_wool
setblock 59 243 276 minecraft:spruce_planks
setblock 60 243 316 minecraft:spruce_planks
setblock 66 243 276 minecraft:spruce_planks
setblock 67 243 316 minecraft:spruce_planks
setblock 73 243 276 minecraft:spruce_planks
setblock 73 243 317 minecraft:white_wool
setblock 74 243 316 minecraft:spruce_planks
setblock 78 243 275 minecraft:white_wool
setblock 87 243 276 minecraft:spruce_planks
setblock 88 243 282 minecraft:spruce_planks
setblock 88 243 289 minecraft:spruce_planks
setblock 88 243 296 minecraft:spruce_planks
setblock 88 243 303 minecraft:spruce_planks
setblock 88 243 310 minecraft:spruce_planks
setblock 88 243 316 minecraft:spruce_planks
setblock 89 243 276 minecraft:white_wool
fill 89 243 277 89 249 278 minecraft:cyan_concrete
setblock 89 243 311 minecraft:white_wool
setblock 48 244 280 minecraft:spruce_planks
setblock 48 244 287 minecraft:spruce_planks
setblock 48 244 294 minecraft:spruce_planks
setblock 48 244 308 minecraft:spruce_planks
setblock 48 244 315 minecraft:spruce_planks
setblock 51 244 276 minecraft:spruce_planks
setblock 54 244 316 minecraft:spruce_planks
fill 57 244 317 57 250 317 minecraft:cyan_concrete
setblock 58 244 276 minecraft:spruce_planks
setblock 61 244 316 minecraft:spruce_planks
setblock 65 244 276 minecraft:spruce_planks
setblock 68 244 316 minecraft:spruce_planks
setblock 72 244 276 minecraft:spruce_planks
fill 73 244 317 73 249 317 minecraft:cyan_concrete
setblock 75 244 307 minecraft:shroomlight
setblock 75 244 309 minecraft:shroomlight
setblock 75 244 311 minecraft:shroomlight
setblock 75 244 313 minecraft:shroomlight
setblock 75 244 315 minecraft:shroomlight
setblock 76 244 308 minecraft:shroomlight
setblock 76 244 310 minecraft:shroomlight
setblock 76 244 312 minecraft:shroomlight
setblock 76 244 314 minecraft:shroomlight
setblock 76 244 316 minecraft:shroomlight
setblock 77 244 307 minecraft:shroomlight
setblock 77 244 309 minecraft:shroomlight
setblock 77 244 311 minecraft:shroomlight
setblock 77 244 313 minecraft:shroomlight
setblock 77 244 315 minecraft:shroomlight
fill 78 244 275 78 247 275 minecraft:cyan_concrete
setblock 78 244 308 minecraft:shroomlight
setblock 78 244 310 minecraft:shroomlight
setblock 78 244 312 minecraft:shroomlight
setblock 78 244 314 minecraft:shroomlight
setblock 78 244 316 minecraft:shroomlight
setblock 79 244 276 minecraft:spruce_planks
setblock 79 244 307 minecraft:shroomlight
setblock 79 244 309 minecraft:shroomlight
setblock 79 244 311 minecraft:shroomlight
setblock 79 244 313 minecraft:shroomlight
setblock 79 244 315 minecraft:shroomlight
setblock 80 244 276 minecraft:shroomlight
setblock 80 244 278 minecraft:shroomlight
setblock 80 244 280 minecraft:shroomlight
setblock 80 244 282 minecraft:shroomlight
setblock 80 244 308 minecraft:shroomlight
setblock 80 244 310 minecraft:shroomlight
setblock 80 244 312 minecraft:shroomlight
setblock 80 244 314 minecraft:shroomlight
setblock 80 244 316 minecraft:shroomlight
setblock 81 244 277 minecraft:shroomlight
setblock 81 244 279 minecraft:shroomlight
setblock 81 244 281 minecraft:shroomlight
setblock 81 244 283 minecraft:shroomlight
setblock 81 244 307 minecraft:shroomlight
setblock 81 244 309 minecraft:shroomlight
setblock 81 244 311 minecraft:shroomlight
schedule function dropper:buildpart/61_4 1t
