fill 363 171 199 370 171 199 minecraft:smooth_basalt
fill 363 171 207 370 171 207 minecraft:smooth_basalt
fill 364 171 200 370 171 202 minecraft:smooth_basalt
fill 364 171 204 370 171 206 minecraft:smooth_basalt
fill 365 171 203 370 171 203 minecraft:smooth_basalt
fill 329 175 183 329 175 184 minecraft:bone_block
fill 329 175 191 329 175 192 minecraft:bone_block
fill 329 175 203 329 175 204 minecraft:bone_block
fill 329 175 211 329 177 211 minecraft:calcite
setblock 329 175 212 minecraft:bone_block
setblock 329 175 215 minecraft:bone_block
fill 329 175 216 329 178 216 minecraft:calcite
fill 329 175 223 330 175 223 minecraft:bone_block
fill 330 175 181 331 175 181 minecraft:bone_block
setblock 334 175 181 minecraft:bone_block
fill 335 175 181 335 177 181 minecraft:calcite
fill 341 175 223 342 175 223 minecraft:bone_block
fill 342 175 181 343 175 181 minecraft:bone_block
fill 349 175 223 350 175 223 minecraft:bone_block
fill 350 175 181 350 178 181 minecraft:calcite
setblock 351 175 181 minecraft:bone_block
setblock 353 175 223 minecraft:bone_block
fill 354 175 181 355 175 181 minecraft:bone_block
fill 354 175 223 354 178 223 minecraft:calcite
fill 361 175 223 362 175 223 minecraft:bone_block
fill 362 175 181 363 175 181 minecraft:bone_block
fill 369 175 223 369 177 223 minecraft:calcite
setblock 370 175 223 minecraft:bone_block
fill 371 175 184 371 175 185 minecraft:bone_block
fill 371 175 192 371 178 192 minecraft:calcite
setblock 371 175 193 minecraft:bone_block
setblock 371 175 196 minecraft:bone_block
fill 371 175 197 371 177 197 minecraft:calcite
fill 371 175 204 371 175 205 minecraft:bone_block
fill 371 175 216 371 175 217 minecraft:bone_block
fill 329 176 181 329 176 182 minecraft:bone_block
fill 329 176 183 329 181 184 minecraft:calcite
fill 329 176 189 329 177 190 minecraft:bone_block
fill 329 176 191 329 181 192 minecraft:calcite
setblock 329 176 193 minecraft:bone_block
fill 329 176 194 329 179 194 minecraft:calcite
fill 329 176 201 329 177 202 minecraft:bone_block
fill 329 176 203 329 181 204 minecraft:calcite
setblock 329 176 209 minecraft:calcite
fill 329 176 210 329 177 210 minecraft:bone_block
fill 329 176 212 329 181 212 minecraft:calcite
fill 329 176 213 329 176 214 minecraft:bone_block
fill 329 176 215 329 181 215 minecraft:calcite
fill 329 176 221 329 177 222 minecraft:bone_block
fill 329 176 223 330 181 223 minecraft:calcite
fill 330 176 181 331 178 181 minecraft:calcite
fill 332 176 181 333 176 181 minecraft:bone_block
fill 334 176 181 334 181 181 minecraft:calcite
fill 336 176 181 336 177 181 minecraft:bone_block
setblock 337 176 181 minecraft:calcite
fill 339 176 223 340 176 223 minecraft:bone_block
fill 341 176 223 342 181 223 minecraft:calcite
fill 342 176 181 343 181 181 minecraft:calcite
fill 344 176 181 345 177 181 minecraft:bone_block
setblock 347 176 223 minecraft:calcite
fill 348 176 223 348 177 223 minecraft:bone_block
fill 349 176 223 350 181 223 minecraft:calcite
fill 351 176 181 352 178 181 minecraft:calcite
setblock 351 176 223 minecraft:bone_block
fill 352 176 223 353 179 223 minecraft:calcite
setblock 353 176 181 minecraft:bone_block
fill 354 176 181 355 181 181 minecraft:calcite
fill 356 176 181 357 177 181 minecraft:bone_block
fill 359 176 223 360 177 223 minecraft:bone_block
fill 361 176 223 362 181 223 minecraft:calcite
fill 362 176 181 363 181 181 minecraft:calcite
fill 364 176 181 365 176 181 minecraft:bone_block
fill 370 176 223 370 181 223 minecraft:calcite
fill 371 176 184 371 181 185 minecraft:calcite
fill 371 176 186 371 177 187 minecraft:bone_block
fill 371 176 193 371 181 193 minecraft:calcite
fill 371 176 194 371 176 195 minecraft:bone_block
fill 371 176 196 371 181 196 minecraft:calcite
fill 371 176 198 371 177 198 minecraft:bone_block
setblock 371 176 199 minecraft:calcite
fill 371 176 204 371 181 205 minecraft:calcite
fill 371 176 206 371 177 207 minecraft:bone_block
fill 371 176 214 371 179 214 minecraft:calcite
setblock 371 176 215 minecraft:bone_block
fill 371 176 216 371 181 217 minecraft:calcite
fill 371 176 218 371 177 219 minecraft:bone_block
fill 371 176 223 371 177 223 minecraft:bone_block
setblock 329 177 181 minecraft:bone_block
fill 329 177 182 329 180 182 minecraft:calcite
fill 329 177 193 329 180 193 minecraft:calcite
fill 329 177 197 329 179 197 minecraft:calcite
setblock 329 177 198 minecraft:bone_block
setblock 329 177 209 minecraft:bone_block
fill 329 177 213 329 180 214 minecraft:calcite
fill 332 177 181 332 180 181 minecraft:calcite
setblock 332 177 184 minecraft:light[level=12]
setblock 332 177 192 minecraft:light[level=12]
setblock 332 177 200 minecraft:light[level=12]
setblock 332 177 208 minecraft:light[level=12]
setblock 332 177 216 minecraft:light[level=12]
setblock 333 177 181 minecraft:bone_block
fill 335 177 223 335 179 223 minecraft:calcite
setblock 336 177 223 minecraft:bone_block
setblock 337 177 181 minecraft:bone_block
setblock 339 177 223 minecraft:bone_block
setblock 340 177 184 minecraft:light[level=12]
setblock 340 177 192 minecraft:light[level=12]
setblock 340 177 200 minecraft:light[level=12]
setblock 340 177 208 minecraft:light[level=12]
setblock 340 177 216 minecraft:light[level=12]
fill 340 177 223 340 180 223 minecraft:calcite
setblock 347 177 223 minecraft:bone_block
setblock 348 177 181 minecraft:bone_block
setblock 348 177 184 minecraft:light[level=12]
setblock 348 177 192 minecraft:light[level=12]
setblock 348 177 200 minecraft:light[level=12]
setblock 348 177 208 minecraft:light[level=12]
setblock 348 177 216 minecraft:light[level=12]
fill 349 177 181 349 179 181 minecraft:calcite
fill 351 177 223 351 180 223 minecraft:calcite
fill 353 177 181 353 180 181 minecraft:calcite
setblock 356 177 184 minecraft:light[level=12]
setblock 356 177 192 minecraft:light[level=12]
setblock 356 177 200 minecraft:light[level=12]
setblock 356 177 208 minecraft:light[level=12]
setblock 356 177 216 minecraft:light[level=12]
fill 364 177 181 364 180 181 minecraft:calcite
setblock 364 177 184 minecraft:light[level=12]
setblock 364 177 192 minecraft:light[level=12]
setblock 364 177 200 minecraft:light[level=12]
setblock 364 177 208 minecraft:light[level=12]
setblock 364 177 216 minecraft:light[level=12]
setblock 365 177 181 minecraft:bone_block
fill 367 177 223 368 177 223 minecraft:bone_block
setblock 368 177 181 minecraft:bone_block
fill 369 177 181 369 179 181 minecraft:calcite
fill 371 177 194 371 180 195 minecraft:calcite
setblock 371 177 199 minecraft:bone_block
setblock 371 177 210 minecraft:bone_block
fill 371 177 211 371 179 211 minecraft:calcite
fill 371 177 215 371 180 215 minecraft:calcite
fill 329 178 181 329 183 181 minecraft:calcite
fill 329 178 187 329 179 188 minecraft:bone_block
fill 329 178 189 329 182 190 minecraft:calcite
fill 329 178 198 329 183 198 minecraft:calcite
fill 329 178 199 329 178 200 minecraft:bone_block
fill 329 178 201 329 183 202 minecraft:calcite
fill 329 178 207 329 179 208 minecraft:bone_block
fill 329 178 209 329 182 210 minecraft:calcite
setblock 329 178 211 minecraft:bone_block
fill 329 178 219 329 179 220 minecraft:bone_block
fill 329 178 221 329 183 222 minecraft:calcite
fill 333 178 181 333 180 181 minecraft:calcite
setblock 333 178 223 minecraft:calcite
fill 334 178 223 334 179 223 minecraft:bone_block
setblock 335 178 181 minecraft:bone_block
fill 336 178 181 337 183 181 minecraft:calcite
fill 336 178 223 336 183 223 minecraft:calcite
fill 337 178 223 338 178 223 minecraft:bone_block
fill 338 178 181 339 179 181 minecraft:bone_block
fill 339 178 223 339 183 223 minecraft:calcite
fill 344 178 181 345 183 181 minecraft:calcite
fill 345 178 223 346 179 223 minecraft:bone_block
fill 346 178 181 347 178 181 minecraft:bone_block
fill 347 178 223 348 183 223 minecraft:calcite
fill 348 178 181 348 179 181 minecraft:calcite
fill 356 178 181 357 183 181 minecraft:calcite
fill 357 178 223 358 178 223 minecraft:bone_block
fill 358 178 181 359 179 181 minecraft:bone_block
fill 359 178 223 360 183 223 minecraft:calcite
fill 365 178 181 365 183 181 minecraft:calcite
setblock 365 178 223 minecraft:calcite
fill 366 178 181 367 178 181 minecraft:bone_block
fill 366 178 223 366 179 223 minecraft:bone_block
fill 367 178 223 368 183 223 minecraft:calcite
fill 368 178 181 368 183 181 minecraft:calcite
setblock 369 178 223 minecraft:bone_block
fill 370 178 181 370 179 181 minecraft:bone_block
setblock 371 178 181 minecraft:calcite
fill 371 178 186 371 183 187 minecraft:calcite
fill 371 178 188 371 179 189 minecraft:bone_block
setblock 371 178 197 minecraft:bone_block
fill 371 178 198 371 183 199 minecraft:calcite
fill 371 178 200 371 179 201 minecraft:bone_block
fill 371 178 206 371 183 207 minecraft:calcite
fill 371 178 208 371 178 209 minecraft:bone_block
fill 371 178 210 371 183 210 minecraft:calcite
fill 371 178 218 371 183 219 minecraft:calcite
fill 371 178 220 371 179 221 minecraft:bone_block
fill 371 178 223 371 183 223 minecraft:calcite
fill 329 179 195 329 179 196 minecraft:bone_block
setblock 329 179 199 minecraft:bone_block
fill 329 179 200 329 182 200 minecraft:calcite
fill 329 179 211 329 182 211 minecraft:calcite
setblock 329 179 216 minecraft:bone_block
setblock 330 179 181 minecraft:bone_block
fill 331 179 181 331 181 181 minecraft:calcite
setblock 333 179 223 minecraft:bone_block
fill 335 179 181 335 182 181 minecraft:calcite
fill 337 179 223 338 182 223 minecraft:calcite
fill 346 179 181 346 182 181 minecraft:calcite
setblock 347 179 181 minecraft:bone_block
fill 350 179 181 351 179 181 minecraft:bone_block
setblock 352 179 181 minecraft:calcite
setblock 354 179 223 minecraft:bone_block
setblock 357 179 223 minecraft:bone_block
fill 358 179 223 358 182 223 minecraft:calcite
setblock 365 179 223 minecraft:bone_block
fill 366 179 181 367 181 181 minecraft:calcite
fill 369 179 223 369 182 223 minecraft:calcite
setblock 371 179 181 minecraft:bone_block
setblock 371 179 192 minecraft:bone_block
fill 371 179 197 371 182 197 minecraft:calcite
fill 371 179 208 371 182 208 minecraft:calcite
setblock 371 179 209 minecraft:bone_block
fill 371 179 212 371 179 213 minecraft:bone_block
fill 329 180 185 329 180 186 minecraft:bone_block
fill 329 180 187 329 185 188 minecraft:calcite
fill 329 180 194 329 181 194 minecraft:bone_block
fill 329 180 195 329 185 196 minecraft:calcite
setblock 329 180 197 minecraft:bone_block
fill 329 180 199 329 184 199 minecraft:calcite
fill 329 180 205 329 181 206 minecraft:bone_block
fill 329 180 207 329 185 208 minecraft:calcite
fill 329 180 216 329 182 216 minecraft:calcite
fill 329 180 217 329 180 218 minecraft:bone_block
fill 329 180 219 329 184 220 minecraft:calcite
fill 330 180 181 330 185 181 minecraft:calcite
fill 330 180 182 332 180 182 minecraft:polished_basalt
fill 330 180 184 330 180 186 minecraft:polished_basalt
fill 330 180 188 330 180 190 minecraft:polished_basalt
fill 330 180 192 330 180 194 minecraft:polished_basalt
fill 330 180 196 330 180 198 minecraft:polished_basalt
fill 330 180 200 330 180 202 minecraft:polished_basalt
fill 330 180 204 330 180 206 minecraft:polished_basalt
fill 330 180 208 330 180 210 minecraft:polished_basalt
fill 330 180 212 330 180 214 minecraft:polished_basalt
fill 330 180 216 330 180 218 minecraft:polished_basalt
fill 330 180 220 330 180 222 minecraft:polished_basalt
fill 331 180 223 332 181 223 minecraft:bone_block
fill 332 180 222 334 180 222 minecraft:polished_basalt
fill 333 180 223 334 185 223 minecraft:calcite
fill 334 180 182 336 180 182 minecraft:polished_basalt
setblock 335 180 223 minecraft:bone_block
fill 336 180 222 338 180 222 minecraft:polished_basalt
fill 338 180 181 339 182 181 minecraft:calcite
fill 338 180 182 340 180 182 minecraft:polished_basalt
fill 340 180 181 341 181 181 minecraft:bone_block
fill 340 180 222 342 180 222 minecraft:polished_basalt
fill 342 180 182 344 180 182 minecraft:polished_basalt
fill 343 180 223 344 181 223 minecraft:bone_block
fill 344 180 222 346 180 222 minecraft:polished_basalt
fill 345 180 223 346 185 223 minecraft:calcite
fill 346 180 182 348 180 182 minecraft:polished_basalt
fill 347 180 181 347 185 181 minecraft:calcite
fill 348 180 181 349 180 181 minecraft:bone_block
fill 348 180 222 350 180 222 minecraft:polished_basalt
fill 350 180 181 351 181 181 minecraft:calcite
fill 350 180 182 352 180 182 minecraft:polished_basalt
fill 352 180 181 352 181 181 minecraft:bone_block
fill 352 180 222 354 180 222 minecraft:polished_basalt
fill 352 180 223 352 181 223 minecraft:bone_block
fill 353 180 223 354 181 223 minecraft:calcite
fill 354 180 182 356 180 182 minecraft:polished_basalt
fill 355 180 223 356 180 223 minecraft:bone_block
fill 356 180 222 358 180 222 minecraft:polished_basalt
fill 357 180 223 357 185 223 minecraft:calcite
fill 358 180 181 359 183 181 minecraft:calcite
fill 358 180 182 360 180 182 minecraft:polished_basalt
fill 359 180 202 359 181 203 minecraft:bone_block
fill 360 180 181 361 181 181 minecraft:bone_block
fill 360 180 222 362 180 222 minecraft:polished_basalt
fill 362 180 182 364 180 182 minecraft:polished_basalt
fill 363 180 223 364 181 223 minecraft:bone_block
fill 364 180 222 366 180 222 minecraft:polished_basalt
fill 365 180 223 366 185 223 minecraft:calcite
fill 366 180 182 368 180 182 minecraft:polished_basalt
fill 368 180 222 370 180 222 minecraft:polished_basalt
setblock 369 180 181 minecraft:bone_block
fill 370 180 181 371 185 181 minecraft:calcite
fill 370 180 182 370 180 184 minecraft:polished_basalt
fill 370 180 186 370 180 188 minecraft:polished_basalt
fill 370 180 190 370 180 192 minecraft:polished_basalt
fill 370 180 194 370 180 196 minecraft:polished_basalt
fill 370 180 198 370 180 200 minecraft:polished_basalt
fill 370 180 202 370 180 204 minecraft:polished_basalt
fill 370 180 206 370 180 208 minecraft:polished_basalt
fill 370 180 210 370 180 212 minecraft:polished_basalt
fill 370 180 214 370 180 216 minecraft:polished_basalt
fill 370 180 218 370 180 220 minecraft:polished_basalt
fill 371 180 182 371 181 183 minecraft:bone_block
fill 371 180 188 371 183 189 minecraft:calcite
fill 371 180 190 371 180 191 minecraft:bone_block
fill 371 180 192 371 185 192 minecraft:calcite
fill 371 180 200 371 185 201 minecraft:calcite
fill 371 180 202 371 181 203 minecraft:bone_block
fill 371 180 209 371 183 209 minecraft:calcite
setblock 371 180 211 minecraft:bone_block
fill 371 180 212 371 185 213 minecraft:calcite
fill 371 180 214 371 181 214 minecraft:bone_block
fill 371 180 220 371 183 221 minecraft:calcite
setblock 371 180 222 minecraft:bone_block
setblock 329 181 182 minecraft:bone_block
setblock 329 181 185 minecraft:bone_block
fill 329 181 186 329 184 186 minecraft:calcite
setblock 329 181 193 minecraft:bone_block
fill 329 181 197 329 184 197 minecraft:calcite
fill 329 181 213 329 181 214 minecraft:bone_block
setblock 329 181 217 minecraft:bone_block
fill 329 181 218 329 184 218 minecraft:calcite
fill 332 181 181 333 181 181 minecraft:bone_block
fill 335 181 223 335 184 223 minecraft:calcite
setblock 340 181 223 minecraft:bone_block
fill 348 181 181 349 183 181 minecraft:calcite
setblock 351 181 223 minecraft:bone_block
setblock 353 181 181 minecraft:bone_block
fill 355 181 223 356 183 223 minecraft:calcite
setblock 364 181 181 minecraft:bone_block
fill 369 181 181 369 183 181 minecraft:calcite
fill 371 181 190 371 184 190 minecraft:calcite
setblock 371 181 191 minecraft:bone_block
fill 371 181 194 371 181 195 minecraft:bone_block
fill 371 181 211 371 184 211 minecraft:calcite
setblock 371 181 215 minecraft:bone_block
fill 371 181 222 371 182 222 minecraft:calcite
fill 329 182 182 329 186 182 minecraft:calcite
fill 329 182 183 329 182 184 minecraft:bone_block
fill 329 182 185 329 186 185 minecraft:calcite
fill 329 182 191 329 183 192 minecraft:bone_block
fill 329 182 193 329 182 194 minecraft:calcite
fill 329 182 203 329 182 204 minecraft:bone_block
fill 329 182 205 329 186 206 minecraft:calcite
fill 329 182 212 329 183 212 minecraft:bone_block
fill 329 182 213 329 186 214 minecraft:calcite
setblock 329 182 215 minecraft:bone_block
fill 329 182 217 329 187 217 minecraft:calcite
fill 329 182 223 330 183 223 minecraft:bone_block
setblock 331 182 181 minecraft:bone_block
fill 331 182 223 332 182 223 minecraft:calcite
fill 332 182 181 333 186 181 minecraft:calcite
fill 334 182 181 334 183 181 minecraft:bone_block
fill 340 182 181 341 186 181 minecraft:calcite
fill 340 182 223 340 186 223 minecraft:calcite
fill 341 182 223 342 182 223 minecraft:bone_block
fill 342 182 181 343 183 181 minecraft:bone_block
fill 343 182 223 344 186 223 minecraft:calcite
fill 349 182 223 350 183 223 minecraft:bone_block
fill 350 182 181 350 185 181 minecraft:calcite
setblock 351 182 181 minecraft:bone_block
fill 351 182 223 352 186 223 minecraft:calcite
fill 352 182 181 353 186 181 minecraft:calcite
setblock 353 182 223 minecraft:bone_block
fill 354 182 181 355 183 181 minecraft:bone_block
fill 354 182 223 354 185 223 minecraft:calcite
fill 360 182 181 361 182 181 minecraft:calcite
fill 361 182 223 362 183 223 minecraft:bone_block
fill 362 182 181 363 182 181 minecraft:bone_block
fill 363 182 223 364 184 223 minecraft:calcite
fill 364 182 181 364 186 181 minecraft:calcite
fill 366 182 181 366 183 181 minecraft:bone_block
setblock 367 182 181 minecraft:calcite
fill 370 182 223 370 183 223 minecraft:bone_block
fill 371 182 182 371 186 183 minecraft:calcite
fill 371 182 184 371 183 185 minecraft:bone_block
fill 371 182 191 371 183 191 minecraft:calcite
fill 371 182 193 371 183 193 minecraft:bone_block
fill 371 182 194 371 186 195 minecraft:calcite
fill 371 182 196 371 183 196 minecraft:bone_block
fill 371 182 202 371 183 203 minecraft:calcite
fill 371 182 204 371 182 205 minecraft:bone_block
fill 371 182 214 371 186 215 minecraft:calcite
fill 371 182 216 371 183 217 minecraft:bone_block
fill 329 183 183 329 186 184 minecraft:calcite
setblock 329 183 189 minecraft:calcite
fill 329 183 190 329 185 190 minecraft:bone_block
setblock 329 183 193 minecraft:bone_block
setblock 329 183 194 minecraft:calcite
setblock 329 183 200 minecraft:bone_block
setblock 329 183 203 minecraft:bone_block
fill 329 183 204 329 186 204 minecraft:calcite
setblock 329 183 209 minecraft:calcite
fill 329 183 210 329 183 211 minecraft:bone_block
fill 329 183 215 329 186 215 minecraft:calcite
setblock 329 183 216 minecraft:bone_block
fill 331 183 181 331 186 181 minecraft:calcite
fill 331 183 223 332 183 223 minecraft:bone_block
setblock 335 183 181 minecraft:bone_block
fill 337 183 223 338 183 223 minecraft:bone_block
setblock 338 183 181 minecraft:bone_block
setblock 339 183 181 minecraft:calcite
setblock 341 183 223 minecraft:bone_block
fill 342 183 223 342 186 223 minecraft:calcite
setblock 346 183 181 minecraft:bone_block
fill 351 183 181 351 185 181 minecraft:calcite
fill 353 183 223 353 186 223 minecraft:calcite
setblock 358 183 223 minecraft:bone_block
fill 360 183 181 360 185 181 minecraft:bone_block
fill 361 183 181 362 186 181 minecraft:calcite
setblock 363 183 181 minecraft:bone_block
setblock 367 183 181 minecraft:bone_block
setblock 369 183 223 minecraft:bone_block
fill 371 183 197 371 185 197 minecraft:bone_block
fill 371 183 204 371 186 204 minecraft:calcite
setblock 371 183 205 minecraft:bone_block
setblock 371 183 208 minecraft:bone_block
setblock 371 183 222 minecraft:bone_block
fill 329 184 181 329 185 181 minecraft:bone_block
fill 329 184 189 329 185 189 minecraft:bone_block
setblock 329 184 191 minecraft:bone_block
fill 329 184 192 329 186 193 minecraft:calcite
setblock 329 184 194 minecraft:bone_block
fill 329 184 198 329 185 198 minecraft:bone_block
fill 329 184 200 329 187 200 minecraft:calcite
fill 329 184 201 329 184 202 minecraft:bone_block
fill 329 184 203 329 186 203 minecraft:calcite
fill 329 184 209 329 185 210 minecraft:bone_block
fill 329 184 211 329 186 212 minecraft:calcite
fill 329 184 216 329 185 216 minecraft:calcite
fill 329 184 221 329 184 222 minecraft:bone_block
fill 329 184 223 329 186 223 minecraft:calcite
setblock 330 184 223 minecraft:bone_block
fill 331 184 223 332 184 223 minecraft:calcite
fill 334 184 181 335 186 181 minecraft:calcite
fill 336 184 181 337 185 181 minecraft:bone_block
fill 336 184 223 336 185 223 minecraft:bone_block
fill 337 184 223 337 186 223 minecraft:calcite
fill 338 184 181 338 185 181 minecraft:calcite
fill 338 184 223 339 185 223 minecraft:bone_block
setblock 339 184 181 minecraft:bone_block
fill 341 184 223 341 186 223 minecraft:calcite
fill 342 184 181 343 186 181 minecraft:calcite
fill 344 184 181 345 185 181 minecraft:bone_block
fill 346 184 181 346 186 181 minecraft:calcite
fill 347 184 223 348 185 223 minecraft:bone_block
fill 348 184 181 348 185 181 minecraft:bone_block
setblock 349 184 181 minecraft:calcite
fill 349 184 223 350 184 223 minecraft:calcite
fill 354 184 181 355 186 181 minecraft:calcite
fill 355 184 223 356 185 223 minecraft:bone_block
fill 356 184 181 358 184 181 minecraft:bone_block
fill 358 184 223 358 187 223 minecraft:calcite
fill 359 184 181 359 185 181 minecraft:calcite
fill 359 184 223 360 184 223 minecraft:bone_block
fill 361 184 223 362 184 223 minecraft:calcite
fill 363 184 181 363 186 181 minecraft:calcite
setblock 365 184 181 minecraft:bone_block
fill 366 184 181 367 186 181 minecraft:calcite
fill 367 184 223 368 185 223 minecraft:bone_block
fill 368 184 181 369 185 181 minecraft:bone_block
fill 369 184 223 370 186 223 minecraft:calcite
fill 371 184 184 371 186 185 minecraft:calcite
fill 371 184 186 371 184 187 minecraft:bone_block
fill 371 184 188 371 185 188 minecraft:calcite
setblock 371 184 189 minecraft:bone_block
setblock 371 184 191 minecraft:bone_block
fill 371 184 193 371 186 193 minecraft:calcite
fill 371 184 196 371 186 196 minecraft:calcite
fill 371 184 198 371 185 199 minecraft:bone_block
fill 371 184 202 371 184 203 minecraft:bone_block
fill 371 184 205 371 186 205 minecraft:calcite
fill 371 184 206 371 184 207 minecraft:bone_block
fill 371 184 208 371 186 208 minecraft:calcite
fill 371 184 209 371 184 210 minecraft:bone_block
fill 371 184 216 371 184 217 minecraft:calcite
fill 371 184 218 371 184 220 minecraft:bone_block
fill 371 184 221 371 184 222 minecraft:calcite
setblock 371 184 223 minecraft:bone_block
setblock 329 185 186 minecraft:bone_block
fill 329 185 191 329 186 191 minecraft:calcite
fill 329 185 194 329 187 194 minecraft:calcite
setblock 329 185 197 minecraft:bone_block
fill 329 185 199 329 307 199 minecraft:bone_block
setblock 329 185 201 minecraft:bone_block
fill 329 185 202 329 186 202 minecraft:calcite
setblock 329 185 218 minecraft:bone_block
setblock 329 185 219 minecraft:calcite
fill 329 185 220 329 185 221 minecraft:bone_block
fill 329 185 222 329 186 222 minecraft:calcite
fill 330 185 223 330 186 223 minecraft:calcite
setblock 331 185 223 minecraft:bone_block
setblock 332 185 184 minecraft:light[level=12]
setblock 332 185 192 minecraft:light[level=12]
setblock 332 185 200 minecraft:light[level=12]
setblock 332 185 208 minecraft:light[level=12]
setblock 332 185 216 minecraft:light[level=12]
fill 332 185 223 332 186 223 minecraft:calcite
setblock 335 185 223 minecraft:bone_block
setblock 339 185 181 minecraft:calcite
setblock 340 185 184 minecraft:light[level=12]
setblock 340 185 192 minecraft:light[level=12]
setblock 340 185 200 minecraft:light[level=12]
setblock 340 185 208 minecraft:light[level=12]
setblock 340 185 216 minecraft:light[level=12]
setblock 348 185 184 minecraft:light[level=12]
setblock 348 185 192 minecraft:light[level=12]
setblock 348 185 200 minecraft:light[level=12]
setblock 348 185 208 minecraft:light[level=12]
setblock 348 185 216 minecraft:light[level=12]
setblock 349 185 181 minecraft:bone_block
fill 349 185 223 349 186 223 minecraft:calcite
setblock 350 185 223 minecraft:bone_block
fill 356 185 181 357 185 181 minecraft:bone_block
setblock 356 185 184 minecraft:light[level=12]
setblock 356 185 192 minecraft:light[level=12]
setblock 356 185 200 minecraft:light[level=12]
setblock 356 185 208 minecraft:light[level=12]
setblock 356 185 216 minecraft:light[level=12]
setblock 358 185 181 minecraft:calcite
setblock 359 185 223 minecraft:bone_block
fill 360 185 223 360 186 223 minecraft:calcite
setblock 361 185 223 minecraft:bone_block
fill 362 185 223 363 186 223 minecraft:calcite
setblock 364 185 184 minecraft:light[level=12]
setblock 364 185 192 minecraft:light[level=12]
setblock 364 185 200 minecraft:light[level=12]
setblock 364 185 208 minecraft:light[level=12]
setblock 364 185 216 minecraft:light[level=12]
setblock 364 185 223 minecraft:bone_block
fill 365 185 181 365 186 181 minecraft:calcite
fill 371 185 186 371 187 186 minecraft:calcite
setblock 371 185 187 minecraft:bone_block
setblock 371 185 189 minecraft:calcite
setblock 371 185 190 minecraft:bone_block
fill 371 185 191 371 186 191 minecraft:calcite
fill 371 185 202 371 186 203 minecraft:calcite
fill 371 185 206 371 186 206 minecraft:calcite
setblock 371 185 207 minecraft:bone_block
setblock 371 185 209 minecraft:calcite
fill 371 185 210 371 185 211 minecraft:bone_block
setblock 371 185 216 minecraft:bone_block
fill 371 185 217 371 187 217 minecraft:calcite
fill 371 185 218 371 185 219 minecraft:bone_block
fill 371 185 220 371 185 221 minecraft:calcite
setblock 371 185 222 minecraft:bone_block
fill 371 185 223 371 186 223 minecraft:calcite
setblock 329 186 181 minecraft:calcite
setblock 329 186 186 minecraft:calcite
fill 329 186 187 329 186 188 minecraft:bone_block
fill 329 186 189 329 186 190 minecraft:calcite
fill 329 186 195 329 188 196 minecraft:bone_block
fill 329 186 197 329 186 198 minecraft:calcite
setblock 329 186 201 minecraft:calcite
fill 329 186 207 329 307 208 minecraft:bone_block
fill 329 186 209 329 186 210 minecraft:calcite
fill 329 186 216 329 307 216 minecraft:bone_block
fill 329 186 218 329 187 218 minecraft:calcite
fill 329 186 219 329 187 220 minecraft:bone_block
setblock 329 186 221 minecraft:calcite
fill 330 186 181 330 307 181 minecraft:bone_block
fill 330 186 182 332 186 182 minecraft:polished_basalt
fill 330 186 184 330 186 186 minecraft:polished_basalt
fill 330 186 188 330 186 190 minecraft:polished_basalt
fill 330 186 192 330 186 194 minecraft:polished_basalt
fill 330 186 196 330 186 198 minecraft:polished_basalt
fill 330 186 200 330 186 202 minecraft:polished_basalt
fill 330 186 204 330 186 206 minecraft:polished_basalt
fill 330 186 208 330 186 210 minecraft:polished_basalt
fill 330 186 212 330 186 214 minecraft:polished_basalt
fill 330 186 216 330 186 218 minecraft:polished_basalt
fill 330 186 220 330 186 222 minecraft:polished_basalt
setblock 331 186 223 minecraft:calcite
fill 332 186 222 334 186 222 minecraft:polished_basalt
fill 333 186 223 334 307 223 minecraft:bone_block
fill 334 186 182 336 186 182 minecraft:polished_basalt
fill 335 186 223 336 186 223 minecraft:calcite
fill 336 186 181 337 186 181 minecraft:calcite
fill 336 186 222 338 186 222 minecraft:polished_basalt
fill 338 186 181 339 307 181 minecraft:bone_block
fill 338 186 182 340 186 182 minecraft:polished_basalt
fill 338 186 223 339 186 223 minecraft:calcite
fill 340 186 222 342 186 222 minecraft:polished_basalt
fill 342 186 182 344 186 182 minecraft:polished_basalt
fill 344 186 181 345 186 181 minecraft:calcite
fill 344 186 222 346 186 222 minecraft:polished_basalt
fill 345 186 223 346 187 223 minecraft:bone_block
fill 346 186 182 348 186 182 minecraft:polished_basalt
setblock 347 186 181 minecraft:bone_block
fill 347 186 223 348 186 223 minecraft:calcite
fill 348 186 181 349 186 181 minecraft:calcite
fill 348 186 222 350 186 222 minecraft:polished_basalt
fill 350 186 181 351 307 181 minecraft:bone_block
fill 350 186 182 352 186 182 minecraft:polished_basalt
setblock 350 186 223 minecraft:calcite
fill 352 186 222 354 186 222 minecraft:polished_basalt
fill 354 186 182 356 186 182 minecraft:polished_basalt
fill 354 186 223 354 307 223 minecraft:bone_block
fill 355 186 223 356 186 223 minecraft:calcite
fill 356 186 181 357 186 181 minecraft:calcite
fill 356 186 222 358 186 222 minecraft:polished_basalt
fill 357 186 223 357 307 223 minecraft:bone_block
fill 358 186 181 359 307 181 minecraft:bone_block
fill 358 186 182 360 186 182 minecraft:polished_basalt
setblock 359 186 223 minecraft:calcite
setblock 360 186 181 minecraft:calcite
fill 360 186 222 362 186 222 minecraft:polished_basalt
setblock 361 186 223 minecraft:calcite
fill 362 186 182 364 186 182 minecraft:polished_basalt
fill 364 186 222 366 186 222 minecraft:polished_basalt
setblock 364 186 223 minecraft:calcite
fill 365 186 223 366 307 223 minecraft:bone_block
fill 366 186 182 368 186 182 minecraft:polished_basalt
fill 367 186 223 368 186 223 minecraft:calcite
fill 368 186 181 369 186 181 minecraft:calcite
fill 368 186 222 370 186 222 minecraft:polished_basalt
fill 370 186 181 371 187 181 minecraft:bone_block
fill 370 186 182 370 186 184 minecraft:polished_basalt
fill 370 186 186 370 186 188 minecraft:polished_basalt
fill 370 186 190 370 186 192 minecraft:polished_basalt
fill 370 186 194 370 186 196 minecraft:polished_basalt
fill 370 186 198 370 186 200 minecraft:polished_basalt
fill 370 186 202 370 186 204 minecraft:polished_basalt
fill 370 186 206 370 186 208 minecraft:polished_basalt
fill 370 186 210 370 186 212 minecraft:polished_basalt
fill 370 186 214 370 186 216 minecraft:polished_basalt
fill 370 186 218 370 186 220 minecraft:polished_basalt
setblock 371 186 187 minecraft:calcite
fill 371 186 188 371 186 189 minecraft:bone_block
setblock 371 186 190 minecraft:calcite
fill 371 186 192 371 307 192 minecraft:bone_block
fill 371 186 197 371 186 199 minecraft:calcite
fill 371 186 200 371 307 201 minecraft:bone_block
setblock 371 186 207 minecraft:calcite
fill 371 186 209 371 188 209 minecraft:bone_block
fill 371 186 210 371 186 211 minecraft:calcite
fill 371 186 212 371 187 213 minecraft:bone_block
setblock 371 186 216 minecraft:calcite
fill 371 186 218 371 186 219 minecraft:calcite
fill 371 186 220 371 307 221 minecraft:bone_block
fill 371 186 222 371 188 222 minecraft:calcite
fill 329 187 181 329 187 187 minecraft:bone_block
setblock 329 187 188 minecraft:calcite
fill 329 187 189 329 307 189 minecraft:bone_block
setblock 329 187 190 minecraft:calcite
fill 329 187 191 329 307 193 minecraft:bone_block
fill 329 187 197 329 187 198 minecraft:bone_block
fill 329 187 201 329 307 206 minecraft:bone_block
fill 329 187 209 329 187 215 minecraft:bone_block
fill 329 187 221 329 187 223 minecraft:bone_block
fill 330 187 223 332 307 223 minecraft:bone_block
fill 331 187 181 337 187 181 minecraft:bone_block
fill 335 187 223 344 307 223 minecraft:bone_block
fill 340 187 181 346 188 181 minecraft:bone_block
setblock 347 187 181 minecraft:calcite
fill 347 187 223 353 307 223 minecraft:bone_block
fill 348 187 181 349 307 181 minecraft:bone_block
fill 352 187 181 357 187 181 minecraft:bone_block
setblock 355 187 223 minecraft:calcite
fill 356 187 223 356 307 223 minecraft:bone_block
fill 359 187 223 362 187 223 minecraft:bone_block
fill 360 187 181 365 187 181 minecraft:bone_block
setblock 363 187 223 minecraft:calcite
fill 364 187 223 364 307 223 minecraft:bone_block
setblock 366 187 181 minecraft:calcite
fill 367 187 181 369 188 181 minecraft:bone_block
fill 367 187 223 371 307 223 minecraft:bone_block
fill 371 187 182 371 307 184 minecraft:bone_block
setblock 371 187 185 minecraft:calcite
fill 371 187 187 371 307 187 minecraft:bone_block
setblock 371 187 188 minecraft:calcite
fill 371 187 189 371 188 191 minecraft:bone_block
fill 371 187 193 371 307 194 minecraft:bone_block
setblock 371 187 195 minecraft:calcite
fill 371 187 196 371 188 199 minecraft:bone_block
fill 371 187 202 371 187 208 minecraft:bone_block
fill 371 187 210 371 307 211 minecraft:bone_block
fill 371 187 214 371 307 214 minecraft:bone_block
setblock 371 187 215 minecraft:calcite
fill 371 187 216 371 188 216 minecraft:bone_block
fill 371 187 218 371 307 219 minecraft:bone_block
setblock 329 188 181 minecraft:calcite
fill 329 188 182 329 307 188 minecraft:bone_block
fill 329 188 190 329 307 190 minecraft:bone_block
fill 329 188 194 329 307 194 minecraft:bone_block
setblock 329 188 197 minecraft:calcite
fill 329 188 198 329 307 198 minecraft:bone_block
fill 329 188 200 329 307 200 minecraft:bone_block
fill 329 188 209 329 307 211 minecraft:bone_block
setblock 329 188 212 minecraft:calcite
fill 329 188 213 329 307 215 minecraft:bone_block
fill 329 188 217 329 307 219 minecraft:bone_block
setblock 329 188 220 minecraft:calcite
fill 329 188 221 329 307 222 minecraft:bone_block
setblock 329 188 223 minecraft:calcite
fill 331 188 181 331 189 181 minecraft:calcite
fill 332 188 181 335 307 181 minecraft:bone_block
setblock 336 188 181 minecraft:calcite
fill 337 188 181 337 307 181 minecraft:bone_block
fill 345 188 223 345 307 223 minecraft:bone_block
setblock 346 188 223 minecraft:calcite
fill 347 188 181 347 307 181 minecraft:bone_block
fill 352 188 181 353 307 181 minecraft:bone_block
setblock 354 188 181 minecraft:calcite
fill 355 188 181 355 307 181 minecraft:bone_block
fill 355 188 223 355 307 223 minecraft:bone_block
setblock 356 188 181 minecraft:calcite
fill 357 188 181 357 307 181 minecraft:bone_block
fill 358 188 223 358 307 223 minecraft:bone_block
setblock 359 188 223 minecraft:calcite
fill 360 188 181 361 307 181 minecraft:bone_block
fill 360 188 223 363 307 223 minecraft:bone_block
setblock 362 188 181 minecraft:calcite
fill 363 188 181 366 307 181 minecraft:bone_block
setblock 370 188 181 minecraft:bone_block
fill 371 188 181 371 189 181 minecraft:calcite
fill 371 188 185 371 307 186 minecraft:bone_block
fill 371 188 188 371 307 188 minecraft:bone_block
fill 371 188 195 371 307 195 minecraft:bone_block
fill 371 188 202 371 307 207 minecraft:bone_block
fill 371 188 208 371 189 208 minecraft:calcite
fill 371 188 212 371 307 212 minecraft:bone_block
setblock 371 188 213 minecraft:calcite
fill 371 188 215 371 307 215 minecraft:bone_block
setblock 371 188 217 minecraft:bone_block
fill 329 189 181 329 307 181 minecraft:bone_block
fill 329 189 195 329 307 195 minecraft:bone_block
setblock 329 189 196 minecraft:calcite
fill 329 189 197 329 307 197 minecraft:bone_block
fill 329 189 212 329 307 212 minecraft:bone_block
fill 329 189 220 329 307 220 minecraft:bone_block
fill 329 189 223 329 307 223 minecraft:bone_block
fill 336 189 181 336 307 181 minecraft:bone_block
fill 340 189 181 341 307 181 minecraft:bone_block
setblock 342 189 181 minecraft:calcite
fill 343 189 181 346 307 181 minecraft:bone_block
fill 346 189 223 346 307 223 minecraft:bone_block
fill 354 189 181 354 307 181 minecraft:bone_block
fill 356 189 181 356 307 181 minecraft:bone_block
fill 359 189 223 359 307 223 minecraft:bone_block
fill 362 189 181 362 307 181 minecraft:bone_block
setblock 367 189 181 minecraft:calcite
fill 368 189 181 369 307 181 minecraft:bone_block
setblock 370 189 181 minecraft:calcite
fill 371 189 189 371 307 190 minecraft:bone_block
setblock 371 189 191 minecraft:calcite
fill 371 189 196 371 307 196 minecraft:bone_block
setblock 371 189 197 minecraft:calcite
fill 371 189 198 371 307 199 minecraft:bone_block
setblock 371 189 209 minecraft:calcite
fill 371 189 213 371 307 213 minecraft:bone_block
fill 371 189 216 371 189 217 minecraft:calcite
fill 371 189 222 371 307 222 minecraft:bone_block
fill 329 190 196 329 307 196 minecraft:bone_block
fill 331 190 181 331 307 181 minecraft:bone_block
fill 342 190 181 342 307 181 minecraft:bone_block
fill 367 190 181 367 307 181 minecraft:bone_block
fill 370 190 181 371 307 181 minecraft:bone_block
fill 371 190 191 371 307 191 minecraft:bone_block
fill 371 190 197 371 307 197 minecraft:bone_block
fill 371 190 208 371 307 209 minecraft:bone_block
fill 371 190 216 371 307 217 minecraft:bone_block
fill 330 192 182 332 192 182 minecraft:polished_basalt
fill 330 192 184 330 192 186 minecraft:polished_basalt
fill 330 192 188 330 192 190 minecraft:polished_basalt
fill 330 192 192 330 192 194 minecraft:polished_basalt
fill 330 192 196 330 192 198 minecraft:polished_basalt
fill 330 192 200 330 192 202 minecraft:polished_basalt
fill 330 192 204 330 192 206 minecraft:polished_basalt
fill 330 192 208 330 192 210 minecraft:polished_basalt
fill 330 192 212 330 192 214 minecraft:polished_basalt
fill 330 192 216 330 192 218 minecraft:polished_basalt
fill 330 192 220 330 192 222 minecraft:polished_basalt
fill 332 192 222 334 192 222 minecraft:polished_basalt
fill 334 192 182 336 192 182 minecraft:polished_basalt
fill 336 192 222 338 192 222 minecraft:polished_basalt
fill 338 192 182 340 192 182 minecraft:polished_basalt
fill 340 192 222 342 192 222 minecraft:polished_basalt
fill 342 192 182 344 192 182 minecraft:polished_basalt
fill 344 192 222 346 192 222 minecraft:polished_basalt
fill 346 192 182 348 192 182 minecraft:polished_basalt
fill 348 192 222 350 192 222 minecraft:polished_basalt
fill 350 192 182 352 192 182 minecraft:polished_basalt
fill 352 192 222 354 192 222 minecraft:polished_basalt
fill 354 192 182 356 192 182 minecraft:polished_basalt
fill 356 192 222 358 192 222 minecraft:polished_basalt
fill 358 192 182 360 192 182 minecraft:polished_basalt
fill 360 192 222 362 192 222 minecraft:polished_basalt
fill 362 192 182 364 192 182 minecraft:polished_basalt
fill 364 192 222 366 192 222 minecraft:polished_basalt
fill 366 192 182 368 192 182 minecraft:polished_basalt
fill 368 192 222 370 192 222 minecraft:polished_basalt
fill 370 192 182 370 192 184 minecraft:polished_basalt
fill 370 192 186 370 192 188 minecraft:polished_basalt
fill 370 192 190 370 192 192 minecraft:polished_basalt
fill 370 192 194 370 192 196 minecraft:polished_basalt
fill 370 192 198 370 192 200 minecraft:polished_basalt
fill 370 192 202 370 192 204 minecraft:polished_basalt
fill 370 192 206 370 192 208 minecraft:polished_basalt
fill 370 192 210 370 192 212 minecraft:polished_basalt
fill 370 192 214 370 192 216 minecraft:polished_basalt
fill 370 192 218 370 192 220 minecraft:polished_basalt
setblock 332 193 184 minecraft:light[level=12]
setblock 332 193 192 minecraft:light[level=12]
setblock 332 193 200 minecraft:light[level=12]
setblock 332 193 208 minecraft:light[level=12]
setblock 332 193 216 minecraft:light[level=12]
setblock 340 193 184 minecraft:light[level=12]
setblock 340 193 192 minecraft:light[level=12]
setblock 340 193 200 minecraft:light[level=12]
setblock 340 193 208 minecraft:light[level=12]
setblock 340 193 216 minecraft:light[level=12]
setblock 348 193 184 minecraft:light[level=12]
setblock 348 193 192 minecraft:light[level=12]
setblock 348 193 200 minecraft:light[level=12]
setblock 348 193 208 minecraft:light[level=12]
setblock 348 193 216 minecraft:light[level=12]
setblock 356 193 184 minecraft:light[level=12]
setblock 356 193 192 minecraft:light[level=12]
setblock 356 193 200 minecraft:light[level=12]
setblock 356 193 208 minecraft:light[level=12]
setblock 356 193 216 minecraft:light[level=12]
setblock 364 193 184 minecraft:light[level=12]
setblock 364 193 192 minecraft:light[level=12]
setblock 364 193 200 minecraft:light[level=12]
setblock 364 193 208 minecraft:light[level=12]
setblock 364 193 216 minecraft:light[level=12]
fill 330 198 182 332 198 182 minecraft:polished_basalt
fill 330 198 184 330 198 186 minecraft:polished_basalt
fill 330 198 188 330 198 190 minecraft:polished_basalt
fill 330 198 192 330 198 194 minecraft:polished_basalt
fill 330 198 196 330 198 198 minecraft:polished_basalt
fill 330 198 200 330 198 202 minecraft:polished_basalt
fill 330 198 204 330 198 206 minecraft:polished_basalt
fill 330 198 208 330 198 210 minecraft:polished_basalt
fill 330 198 212 330 198 214 minecraft:polished_basalt
fill 330 198 216 330 198 218 minecraft:polished_basalt
fill 330 198 220 330 198 222 minecraft:polished_basalt
fill 332 198 222 334 198 222 minecraft:polished_basalt
fill 334 198 182 336 198 182 minecraft:polished_basalt
fill 336 198 222 338 198 222 minecraft:polished_basalt
fill 338 198 182 340 198 182 minecraft:polished_basalt
fill 340 198 222 342 198 222 minecraft:polished_basalt
fill 342 198 182 344 198 182 minecraft:polished_basalt
fill 344 198 222 346 198 222 minecraft:polished_basalt
fill 346 198 182 348 198 182 minecraft:polished_basalt
fill 348 198 222 350 198 222 minecraft:polished_basalt
fill 350 198 182 352 198 182 minecraft:polished_basalt
fill 352 198 222 354 198 222 minecraft:polished_basalt
fill 354 198 182 356 198 182 minecraft:polished_basalt
fill 356 198 222 358 198 222 minecraft:polished_basalt
fill 358 198 182 360 198 182 minecraft:polished_basalt
fill 360 198 222 362 198 222 minecraft:polished_basalt
fill 362 198 182 364 198 182 minecraft:polished_basalt
fill 364 198 222 366 198 222 minecraft:polished_basalt
fill 366 198 182 368 198 182 minecraft:polished_basalt
fill 368 198 222 370 198 222 minecraft:polished_basalt
fill 370 198 182 370 198 184 minecraft:polished_basalt
fill 370 198 186 370 198 188 minecraft:polished_basalt
fill 370 198 190 370 198 192 minecraft:polished_basalt
fill 370 198 194 370 198 196 minecraft:polished_basalt
fill 370 198 198 370 198 200 minecraft:polished_basalt
fill 370 198 202 370 198 204 minecraft:polished_basalt
fill 370 198 206 370 198 208 minecraft:polished_basalt
fill 370 198 210 370 198 212 minecraft:polished_basalt
fill 370 198 214 370 198 216 minecraft:polished_basalt
fill 370 198 218 370 198 220 minecraft:polished_basalt
setblock 332 201 184 minecraft:light[level=12]
setblock 332 201 192 minecraft:light[level=12]
setblock 332 201 200 minecraft:light[level=12]
setblock 332 201 208 minecraft:light[level=12]
setblock 332 201 216 minecraft:light[level=12]
setblock 340 201 184 minecraft:light[level=12]
setblock 340 201 192 minecraft:light[level=12]
setblock 340 201 200 minecraft:light[level=12]
setblock 340 201 208 minecraft:light[level=12]
setblock 340 201 216 minecraft:light[level=12]
setblock 348 201 184 minecraft:light[level=12]
setblock 348 201 192 minecraft:light[level=12]
setblock 348 201 208 minecraft:light[level=12]
setblock 348 201 216 minecraft:light[level=12]
setblock 356 201 184 minecraft:light[level=12]
setblock 356 201 192 minecraft:light[level=12]
setblock 356 201 200 minecraft:light[level=12]
setblock 356 201 208 minecraft:light[level=12]
setblock 356 201 216 minecraft:light[level=12]
setblock 364 201 184 minecraft:light[level=12]
setblock 364 201 192 minecraft:light[level=12]
setblock 364 201 200 minecraft:light[level=12]
setblock 364 201 208 minecraft:light[level=12]
setblock 364 201 216 minecraft:light[level=12]
fill 330 204 182 332 204 182 minecraft:polished_basalt
fill 330 204 184 330 204 186 minecraft:polished_basalt
fill 330 204 188 330 204 190 minecraft:polished_basalt
fill 330 204 192 330 204 194 minecraft:polished_basalt
fill 330 204 196 330 204 198 minecraft:polished_basalt
fill 330 204 200 330 204 202 minecraft:polished_basalt
fill 330 204 204 330 204 206 minecraft:polished_basalt
fill 330 204 208 330 204 210 minecraft:polished_basalt
fill 330 204 212 330 204 214 minecraft:polished_basalt
fill 330 204 216 330 204 218 minecraft:polished_basalt
fill 330 204 220 330 204 222 minecraft:polished_basalt
fill 332 204 222 334 204 222 minecraft:polished_basalt
fill 334 204 182 336 204 182 minecraft:polished_basalt
fill 336 204 222 338 204 222 minecraft:polished_basalt
fill 338 204 182 340 204 182 minecraft:polished_basalt
fill 340 204 222 342 204 222 minecraft:polished_basalt
fill 342 204 182 344 204 182 minecraft:polished_basalt
fill 344 204 222 346 204 222 minecraft:polished_basalt
fill 346 204 182 348 204 182 minecraft:polished_basalt
fill 348 204 222 350 204 222 minecraft:polished_basalt
fill 350 204 182 352 204 182 minecraft:polished_basalt
fill 352 204 222 354 204 222 minecraft:polished_basalt
fill 354 204 182 356 204 182 minecraft:polished_basalt
fill 356 204 222 358 204 222 minecraft:polished_basalt
fill 358 204 182 360 204 182 minecraft:polished_basalt
fill 360 204 222 362 204 222 minecraft:polished_basalt
fill 362 204 182 364 204 182 minecraft:polished_basalt
fill 364 204 222 366 204 222 minecraft:polished_basalt
fill 366 204 182 368 204 182 minecraft:polished_basalt
fill 368 204 222 370 204 222 minecraft:polished_basalt
fill 370 204 182 370 204 184 minecraft:polished_basalt
fill 370 204 186 370 204 188 minecraft:polished_basalt
fill 370 204 190 370 204 192 minecraft:polished_basalt
fill 370 204 194 370 204 196 minecraft:polished_basalt
fill 370 204 198 370 204 200 minecraft:polished_basalt
fill 370 204 202 370 204 204 minecraft:polished_basalt
fill 370 204 206 370 204 208 minecraft:polished_basalt
fill 370 204 210 370 204 212 minecraft:polished_basalt
fill 370 204 214 370 204 216 minecraft:polished_basalt
fill 370 204 218 370 204 220 minecraft:polished_basalt
setblock 332 209 184 minecraft:light[level=12]
setblock 332 209 192 minecraft:light[level=12]
setblock 332 209 200 minecraft:light[level=12]
setblock 332 209 208 minecraft:light[level=12]
setblock 332 209 216 minecraft:light[level=12]
setblock 340 209 184 minecraft:light[level=12]
setblock 340 209 192 minecraft:light[level=12]
setblock 340 209 200 minecraft:light[level=12]
setblock 340 209 208 minecraft:light[level=12]
setblock 340 209 216 minecraft:light[level=12]
setblock 348 209 184 minecraft:light[level=12]
setblock 348 209 192 minecraft:light[level=12]
setblock 348 209 208 minecraft:light[level=12]
setblock 348 209 216 minecraft:light[level=12]
setblock 356 209 184 minecraft:light[level=12]
setblock 356 209 192 minecraft:light[level=12]
setblock 356 209 200 minecraft:light[level=12]
setblock 356 209 208 minecraft:light[level=12]
setblock 356 209 216 minecraft:light[level=12]
setblock 364 209 184 minecraft:light[level=12]
setblock 364 209 192 minecraft:light[level=12]
setblock 364 209 200 minecraft:light[level=12]
setblock 364 209 208 minecraft:light[level=12]
setblock 364 209 216 minecraft:light[level=12]
fill 330 210 182 332 210 182 minecraft:polished_basalt
fill 330 210 184 330 210 186 minecraft:polished_basalt
fill 330 210 188 330 210 190 minecraft:polished_basalt
fill 330 210 192 330 210 194 minecraft:polished_basalt
fill 330 210 196 330 210 198 minecraft:polished_basalt
fill 330 210 200 330 210 202 minecraft:polished_basalt
fill 330 210 204 330 210 206 minecraft:polished_basalt
fill 330 210 208 330 210 210 minecraft:polished_basalt
fill 330 210 212 330 210 214 minecraft:polished_basalt
fill 330 210 216 330 210 218 minecraft:polished_basalt
fill 330 210 220 330 210 222 minecraft:polished_basalt
fill 332 210 222 334 210 222 minecraft:polished_basalt
fill 334 210 182 336 210 182 minecraft:polished_basalt
fill 336 210 222 338 210 222 minecraft:polished_basalt
fill 338 210 182 340 210 182 minecraft:polished_basalt
fill 340 210 222 342 210 222 minecraft:polished_basalt
fill 342 210 182 344 210 182 minecraft:polished_basalt
fill 344 210 222 346 210 222 minecraft:polished_basalt
fill 346 210 182 348 210 182 minecraft:polished_basalt
fill 348 210 222 350 210 222 minecraft:polished_basalt
fill 350 210 182 352 210 182 minecraft:polished_basalt
fill 352 210 222 354 210 222 minecraft:polished_basalt
fill 354 210 182 356 210 182 minecraft:polished_basalt
fill 356 210 222 358 210 222 minecraft:polished_basalt
fill 358 210 182 360 210 182 minecraft:polished_basalt
fill 360 210 222 362 210 222 minecraft:polished_basalt
fill 362 210 182 364 210 182 minecraft:polished_basalt
fill 364 210 222 366 210 222 minecraft:polished_basalt
fill 366 210 182 368 210 182 minecraft:polished_basalt
fill 368 210 222 370 210 222 minecraft:polished_basalt
fill 370 210 182 370 210 184 minecraft:polished_basalt
fill 370 210 186 370 210 188 minecraft:polished_basalt
fill 370 210 190 370 210 192 minecraft:polished_basalt
fill 370 210 194 370 210 196 minecraft:polished_basalt
fill 370 210 198 370 210 200 minecraft:polished_basalt
fill 370 210 202 370 210 204 minecraft:polished_basalt
fill 370 210 206 370 210 208 minecraft:polished_basalt
fill 370 210 210 370 210 212 minecraft:polished_basalt
fill 370 210 214 370 210 216 minecraft:polished_basalt
fill 370 210 218 370 210 220 minecraft:polished_basalt
fill 330 216 182 332 216 182 minecraft:polished_basalt
fill 330 216 184 330 216 186 minecraft:polished_basalt
fill 330 216 188 330 216 190 minecraft:polished_basalt
fill 330 216 192 330 216 194 minecraft:polished_basalt
fill 330 216 196 330 216 198 minecraft:polished_basalt
fill 330 216 200 330 216 202 minecraft:polished_basalt
fill 330 216 204 330 216 206 minecraft:polished_basalt
fill 330 216 208 330 216 210 minecraft:polished_basalt
fill 330 216 212 330 216 214 minecraft:polished_basalt
fill 330 216 216 330 216 218 minecraft:polished_basalt
fill 330 216 220 330 216 222 minecraft:polished_basalt
fill 332 216 222 334 216 222 minecraft:polished_basalt
fill 334 216 182 336 216 182 minecraft:polished_basalt
fill 336 216 222 338 216 222 minecraft:polished_basalt
fill 338 216 182 340 216 182 minecraft:polished_basalt
fill 340 216 222 342 216 222 minecraft:polished_basalt
fill 342 216 182 344 216 182 minecraft:polished_basalt
fill 344 216 222 346 216 222 minecraft:polished_basalt
fill 346 216 182 348 216 182 minecraft:polished_basalt
fill 348 216 222 350 216 222 minecraft:polished_basalt
fill 350 216 182 352 216 182 minecraft:polished_basalt
fill 352 216 222 354 216 222 minecraft:polished_basalt
fill 354 216 182 356 216 182 minecraft:polished_basalt
fill 356 216 222 358 216 222 minecraft:polished_basalt
fill 358 216 182 360 216 182 minecraft:polished_basalt
fill 360 216 222 362 216 222 minecraft:polished_basalt
fill 362 216 182 364 216 182 minecraft:polished_basalt
fill 364 216 222 366 216 222 minecraft:polished_basalt
fill 366 216 182 368 216 182 minecraft:polished_basalt
fill 368 216 222 370 216 222 minecraft:polished_basalt
fill 370 216 182 370 216 184 minecraft:polished_basalt
fill 370 216 186 370 216 188 minecraft:polished_basalt
fill 370 216 190 370 216 192 minecraft:polished_basalt
fill 370 216 194 370 216 196 minecraft:polished_basalt
fill 370 216 198 370 216 200 minecraft:polished_basalt
fill 370 216 202 370 216 204 minecraft:polished_basalt
fill 370 216 206 370 216 208 minecraft:polished_basalt
fill 370 216 210 370 216 212 minecraft:polished_basalt
fill 370 216 214 370 216 216 minecraft:polished_basalt
fill 370 216 218 370 216 220 minecraft:polished_basalt
setblock 332 217 184 minecraft:light[level=12]
setblock 332 217 192 minecraft:light[level=12]
setblock 332 217 200 minecraft:light[level=12]
setblock 332 217 208 minecraft:light[level=12]
setblock 332 217 216 minecraft:light[level=12]
setblock 340 217 184 minecraft:light[level=12]
setblock 340 217 192 minecraft:light[level=12]
setblock 340 217 200 minecraft:light[level=12]
setblock 340 217 208 minecraft:light[level=12]
setblock 340 217 216 minecraft:light[level=12]
setblock 348 217 184 minecraft:light[level=12]
setblock 348 217 192 minecraft:light[level=12]
setblock 348 217 208 minecraft:light[level=12]
setblock 348 217 216 minecraft:light[level=12]
setblock 356 217 184 minecraft:light[level=12]
setblock 356 217 192 minecraft:light[level=12]
setblock 356 217 200 minecraft:light[level=12]
setblock 356 217 208 minecraft:light[level=12]
setblock 356 217 216 minecraft:light[level=12]
setblock 364 217 184 minecraft:light[level=12]
setblock 364 217 192 minecraft:light[level=12]
setblock 364 217 200 minecraft:light[level=12]
setblock 364 217 208 minecraft:light[level=12]
setblock 364 217 216 minecraft:light[level=12]
fill 330 222 182 332 222 182 minecraft:polished_basalt
fill 330 222 184 330 222 186 minecraft:polished_basalt
fill 330 222 188 330 222 190 minecraft:polished_basalt
fill 330 222 192 330 222 194 minecraft:polished_basalt
fill 330 222 196 330 222 198 minecraft:polished_basalt
fill 330 222 200 330 222 202 minecraft:polished_basalt
fill 330 222 204 330 222 206 minecraft:polished_basalt
fill 330 222 208 330 222 210 minecraft:polished_basalt
fill 330 222 212 330 222 214 minecraft:polished_basalt
fill 330 222 216 330 222 218 minecraft:polished_basalt
fill 330 222 220 330 222 222 minecraft:polished_basalt
fill 332 222 222 334 222 222 minecraft:polished_basalt
fill 334 222 182 336 222 182 minecraft:polished_basalt
fill 336 222 222 338 222 222 minecraft:polished_basalt
fill 338 222 182 340 222 182 minecraft:polished_basalt
fill 340 222 222 342 222 222 minecraft:polished_basalt
fill 342 222 182 344 222 182 minecraft:polished_basalt
fill 344 222 222 346 222 222 minecraft:polished_basalt
fill 346 222 182 348 222 182 minecraft:polished_basalt
fill 348 222 222 350 222 222 minecraft:polished_basalt
fill 350 222 182 352 222 182 minecraft:polished_basalt
fill 352 222 222 354 222 222 minecraft:polished_basalt
fill 354 222 182 356 222 182 minecraft:polished_basalt
fill 356 222 222 358 222 222 minecraft:polished_basalt
fill 358 222 182 360 222 182 minecraft:polished_basalt
fill 360 222 222 362 222 222 minecraft:polished_basalt
fill 362 222 182 364 222 182 minecraft:polished_basalt
fill 364 222 222 366 222 222 minecraft:polished_basalt
fill 366 222 182 368 222 182 minecraft:polished_basalt
fill 368 222 222 370 222 222 minecraft:polished_basalt
fill 370 222 182 370 222 184 minecraft:polished_basalt
fill 370 222 186 370 222 188 minecraft:polished_basalt
fill 370 222 190 370 222 192 minecraft:polished_basalt
fill 370 222 194 370 222 196 minecraft:polished_basalt
fill 370 222 198 370 222 200 minecraft:polished_basalt
fill 370 222 202 370 222 204 minecraft:polished_basalt
fill 370 222 206 370 222 208 minecraft:polished_basalt
fill 370 222 210 370 222 212 minecraft:polished_basalt
fill 370 222 214 370 222 216 minecraft:polished_basalt
fill 370 222 218 370 222 220 minecraft:polished_basalt
setblock 332 225 184 minecraft:light[level=12]
setblock 332 225 192 minecraft:light[level=12]
setblock 332 225 200 minecraft:light[level=12]
setblock 332 225 208 minecraft:light[level=12]
setblock 332 225 216 minecraft:light[level=12]
setblock 340 225 184 minecraft:light[level=12]
setblock 340 225 192 minecraft:light[level=12]
setblock 340 225 200 minecraft:light[level=12]
setblock 340 225 208 minecraft:light[level=12]
setblock 340 225 216 minecraft:light[level=12]
setblock 348 225 184 minecraft:light[level=12]
setblock 348 225 192 minecraft:light[level=12]
setblock 348 225 208 minecraft:light[level=12]
setblock 348 225 216 minecraft:light[level=12]
setblock 356 225 184 minecraft:light[level=12]
setblock 356 225 192 minecraft:light[level=12]
setblock 356 225 200 minecraft:light[level=12]
setblock 356 225 208 minecraft:light[level=12]
setblock 356 225 216 minecraft:light[level=12]
setblock 364 225 184 minecraft:light[level=12]
setblock 364 225 192 minecraft:light[level=12]
setblock 364 225 200 minecraft:light[level=12]
setblock 364 225 208 minecraft:light[level=12]
setblock 364 225 216 minecraft:light[level=12]
fill 330 228 189 344 228 215 minecraft:bone_block
fill 331 228 188 369 229 188 minecraft:bone_block
fill 331 228 216 369 229 216 minecraft:bone_block
fill 332 228 187 368 229 187 minecraft:bone_block
fill 332 228 217 368 229 217 minecraft:bone_block
fill 333 228 185 367 228 186 minecraft:bone_block
fill 333 228 218 367 228 219 minecraft:bone_block
fill 335 228 184 365 229 184 minecraft:bone_block
fill 335 228 220 365 229 220 minecraft:bone_block
fill 336 228 183 364 229 183 minecraft:bone_block
fill 336 228 221 364 229 221 minecraft:bone_block
fill 337 228 182 363 228 182 minecraft:bone_block
fill 337 228 222 363 228 222 minecraft:bone_block
fill 345 228 189 345 232 199 minecraft:bone_block
fill 345 228 201 345 232 215 minecraft:bone_block
fill 346 228 189 347 232 197 minecraft:bone_block
fill 346 228 203 347 232 215 minecraft:bone_block
fill 348 228 189 370 228 196 minecraft:bone_block
fill 348 228 204 370 228 215 minecraft:bone_block
fill 349 228 197 370 232 197 minecraft:bone_block
fill 349 228 203 370 232 203 minecraft:bone_block
fill 351 228 198 370 232 199 minecraft:bone_block
fill 351 228 201 370 232 202 minecraft:bone_block
fill 352 228 200 370 233 200 minecraft:bone_block
fill 330 229 190 344 229 214 minecraft:bone_block
fill 331 229 189 344 230 189 minecraft:bone_block
fill 331 229 215 344 230 215 minecraft:bone_block
fill 333 229 186 367 229 186 minecraft:bone_block
fill 333 229 218 367 229 218 minecraft:bone_block
fill 334 229 185 366 229 185 minecraft:bone_block
fill 334 229 219 366 229 219 minecraft:bone_block
fill 338 229 182 362 229 182 minecraft:bone_block
fill 338 229 222 362 229 222 minecraft:bone_block
fill 348 229 189 369 230 196 minecraft:bone_block
fill 348 229 204 369 230 215 minecraft:bone_block
fill 370 229 190 370 229 196 minecraft:bone_block
fill 370 229 204 370 229 214 minecraft:bone_block
fill 330 230 191 344 230 213 minecraft:bone_block
fill 331 230 190 344 231 190 minecraft:bone_block
fill 331 230 214 344 231 214 minecraft:bone_block
fill 332 230 188 368 230 188 minecraft:bone_block
fill 332 230 216 368 230 216 minecraft:bone_block
fill 333 230 187 367 230 187 minecraft:bone_block
fill 333 230 217 367 230 217 minecraft:bone_block
fill 334 230 186 366 231 186 minecraft:bone_block
fill 334 230 218 366 231 218 minecraft:bone_block
fill 335 230 185 365 230 185 minecraft:bone_block
fill 335 230 219 365 230 219 minecraft:bone_block
fill 336 230 184 364 230 184 minecraft:bone_block
fill 336 230 220 364 230 220 minecraft:bone_block
fill 337 230 183 363 230 183 minecraft:bone_block
fill 337 230 221 363 230 221 minecraft:bone_block
fill 339 230 182 361 230 182 minecraft:bone_block
fill 339 230 222 361 230 222 minecraft:bone_block
fill 370 230 191 370 230 196 minecraft:bone_block
fill 370 230 204 370 230 213 minecraft:bone_block
fill 330 231 192 344 231 212 minecraft:bone_block
fill 331 231 191 344 232 191 minecraft:bone_block
fill 331 231 213 344 232 213 minecraft:bone_block
fill 332 231 189 344 231 189 minecraft:bone_block
fill 332 231 215 344 231 215 minecraft:bone_block
fill 333 231 188 367 232 188 minecraft:bone_block
fill 333 231 216 367 232 216 minecraft:bone_block
fill 334 231 187 366 232 187 minecraft:bone_block
fill 334 231 217 366 232 217 minecraft:bone_block
fill 336 231 185 364 232 185 minecraft:bone_block
fill 336 231 219 364 232 219 minecraft:bone_block
fill 337 231 184 363 231 184 minecraft:bone_block
fill 337 231 220 363 231 220 minecraft:bone_block
fill 338 231 183 362 231 183 minecraft:bone_block
fill 338 231 221 362 231 221 minecraft:bone_block
fill 340 231 182 360 231 182 minecraft:bone_block
fill 340 231 222 360 231 222 minecraft:bone_block
fill 348 231 189 368 231 196 minecraft:bone_block
fill 348 231 204 368 231 215 minecraft:bone_block
fill 369 231 190 369 231 196 minecraft:bone_block
fill 369 231 204 369 231 214 minecraft:bone_block
fill 370 231 192 370 231 196 minecraft:bone_block
fill 370 231 204 370 231 212 minecraft:bone_block
fill 330 232 193 344 232 211 minecraft:bone_block
fill 331 232 192 344 233 192 minecraft:bone_block
fill 331 232 212 344 233 212 minecraft:bone_block
fill 332 232 190 344 232 190 minecraft:bone_block
fill 332 232 214 344 232 214 minecraft:bone_block
fill 333 232 189 344 233 189 minecraft:bone_block
fill 333 232 215 344 233 215 minecraft:bone_block
fill 335 232 186 365 232 186 minecraft:bone_block
fill 335 232 218 365 232 218 minecraft:bone_block
fill 338 232 184 362 232 184 minecraft:bone_block
fill 338 232 220 362 232 220 minecraft:bone_block
fill 339 232 183 361 232 183 minecraft:bone_block
fill 339 232 221 361 232 221 minecraft:bone_block
fill 341 232 182 359 232 182 minecraft:bone_block
fill 341 232 222 359 232 222 minecraft:bone_block
fill 348 232 189 367 233 196 minecraft:bone_block
fill 348 232 204 367 233 215 minecraft:bone_block
fill 368 232 190 368 232 196 minecraft:bone_block
fill 368 232 204 368 232 214 minecraft:bone_block
fill 369 232 191 369 232 196 minecraft:bone_block
fill 369 232 204 369 232 213 minecraft:bone_block
fill 370 232 193 370 232 196 minecraft:bone_block
fill 370 232 204 370 232 211 minecraft:bone_block
fill 330 233 194 344 233 210 minecraft:bone_block
fill 331 233 193 347 233 193 minecraft:bone_block
fill 331 233 211 347 233 211 minecraft:bone_block
setblock 332 233 184 minecraft:light[level=12]
fill 332 233 191 347 233 191 minecraft:bone_block
fill 332 233 213 347 233 213 minecraft:bone_block
setblock 332 233 216 minecraft:light[level=12]
fill 333 233 190 347 234 190 minecraft:bone_block
fill 333 233 214 347 234 214 minecraft:bone_block
fill 334 233 188 366 233 188 minecraft:bone_block
fill 334 233 216 366 233 216 minecraft:bone_block
fill 335 233 187 365 233 187 minecraft:bone_block
fill 335 233 217 365 233 217 minecraft:bone_block
fill 336 233 186 364 233 186 minecraft:bone_block
fill 336 233 218 364 233 218 minecraft:bone_block
fill 337 233 185 363 233 185 minecraft:bone_block
fill 337 233 219 363 233 219 minecraft:bone_block
fill 339 233 184 361 233 184 minecraft:bone_block
fill 339 233 220 361 233 220 minecraft:bone_block
fill 340 233 183 360 233 183 minecraft:bone_block
fill 340 233 221 360 233 221 minecraft:bone_block
fill 342 233 182 358 233 182 minecraft:bone_block
fill 342 233 222 358 233 222 minecraft:bone_block
fill 345 233 189 347 240 189 minecraft:bone_block
fill 345 233 192 347 237 192 minecraft:bone_block
fill 345 233 194 345 233 197 minecraft:bone_block
fill 345 233 198 345 233 199 minecraft:smooth_basalt
fill 345 233 201 345 233 202 minecraft:smooth_basalt
fill 345 233 203 345 233 210 minecraft:bone_block
fill 345 233 212 347 238 212 minecraft:bone_block
fill 345 233 215 347 240 215 minecraft:bone_block
fill 346 233 194 347 233 196 minecraft:bone_block
fill 346 233 197 347 233 197 minecraft:smooth_basalt
fill 346 233 203 347 233 203 minecraft:smooth_basalt
fill 346 233 204 347 233 210 minecraft:bone_block
fill 349 233 197 350 233 197 minecraft:smooth_basalt
fill 349 233 203 350 233 203 minecraft:smooth_basalt
fill 351 233 197 370 233 197 minecraft:bone_block
fill 351 233 198 351 233 199 minecraft:smooth_basalt
fill 351 233 201 351 233 202 minecraft:smooth_basalt
fill 351 233 203 370 233 203 minecraft:bone_block
fill 352 233 198 370 233 199 minecraft:bone_block
fill 352 233 201 370 233 202 minecraft:bone_block
setblock 364 233 184 minecraft:light[level=12]
fill 368 233 191 368 233 196 minecraft:bone_block
fill 368 233 204 368 233 213 minecraft:bone_block
fill 369 233 192 369 233 196 minecraft:bone_block
fill 369 233 204 369 233 212 minecraft:bone_block
fill 370 233 194 370 233 196 minecraft:bone_block
fill 370 233 204 370 233 210 minecraft:bone_block
fill 330 234 182 330 234 195 minecraft:smooth_basalt
fill 330 234 196 343 234 208 minecraft:bone_block
fill 330 234 209 330 234 222 minecraft:smooth_basalt
fill 331 234 182 331 234 193 minecraft:smooth_basalt
fill 331 234 194 369 234 195 minecraft:bone_block
fill 331 234 209 369 234 210 minecraft:bone_block
fill 331 234 211 331 234 222 minecraft:smooth_basalt
fill 332 234 182 332 234 191 minecraft:smooth_basalt
fill 332 234 192 344 234 193 minecraft:bone_block
fill 332 234 211 344 234 212 minecraft:bone_block
fill 332 234 213 332 234 222 minecraft:smooth_basalt
fill 333 234 182 333 234 189 minecraft:smooth_basalt
fill 333 234 191 367 235 191 minecraft:bone_block
fill 333 234 213 367 235 213 minecraft:bone_block
fill 333 234 215 333 234 222 minecraft:smooth_basalt
fill 334 234 182 334 234 188 minecraft:smooth_basalt
fill 334 234 189 344 234 189 minecraft:bone_block
fill 334 234 215 344 234 215 minecraft:bone_block
fill 334 234 216 334 234 222 minecraft:smooth_basalt
fill 335 234 182 335 234 187 minecraft:smooth_basalt
fill 335 234 188 365 234 188 minecraft:bone_block
fill 335 234 216 365 234 216 minecraft:bone_block
fill 335 234 217 335 234 222 minecraft:smooth_basalt
fill 336 234 182 336 234 186 minecraft:smooth_basalt
fill 336 234 187 364 234 187 minecraft:bone_block
fill 336 234 217 364 234 217 minecraft:bone_block
fill 336 234 218 336 234 222 minecraft:smooth_basalt
fill 337 234 182 337 234 185 minecraft:smooth_basalt
fill 337 234 186 363 234 186 minecraft:bone_block
fill 337 234 218 363 234 218 minecraft:bone_block
fill 337 234 219 337 234 222 minecraft:smooth_basalt
fill 338 234 182 339 234 184 minecraft:smooth_basalt
fill 338 234 185 362 234 185 minecraft:bone_block
fill 338 234 219 362 234 219 minecraft:bone_block
fill 338 234 220 339 234 222 minecraft:smooth_basalt
fill 340 234 182 341 234 183 minecraft:smooth_basalt
fill 340 234 184 360 234 184 minecraft:bone_block
fill 340 234 220 360 234 220 minecraft:bone_block
fill 340 234 221 341 234 222 minecraft:smooth_basalt
fill 342 234 182 343 234 182 minecraft:smooth_basalt
fill 342 234 183 358 234 183 minecraft:bone_block
fill 342 234 221 358 234 221 minecraft:bone_block
fill 342 234 222 343 234 222 minecraft:smooth_basalt
fill 344 234 182 356 234 182 minecraft:bone_block
fill 344 234 196 344 234 197 minecraft:bone_block
setblock 344 234 198 minecraft:smooth_basalt
fill 344 234 199 344 234 201 minecraft:ochre_froglight
setblock 344 234 202 minecraft:smooth_basalt
fill 344 234 203 344 234 208 minecraft:bone_block
fill 344 234 222 356 234 222 minecraft:bone_block
fill 345 234 193 368 235 193 minecraft:bone_block
setblock 345 234 196 minecraft:bone_block
fill 345 234 197 345 234 199 minecraft:ochre_froglight
fill 345 234 201 345 234 203 minecraft:ochre_froglight
fill 345 234 204 346 234 204 minecraft:smooth_basalt
fill 345 234 205 346 234 208 minecraft:bone_block
fill 345 234 211 368 235 211 minecraft:bone_block
setblock 346 234 196 minecraft:smooth_basalt
fill 346 234 197 347 234 197 minecraft:ochre_froglight
fill 346 234 203 347 234 203 minecraft:ochre_froglight
fill 347 234 196 349 234 196 minecraft:ochre_froglight
fill 347 234 204 349 234 204 minecraft:ochre_froglight
fill 347 234 205 350 234 205 minecraft:smooth_basalt
fill 347 234 206 370 234 208 minecraft:bone_block
fill 348 234 189 366 234 190 minecraft:bone_block
fill 348 234 192 368 234 192 minecraft:bone_block
fill 348 234 212 368 234 212 minecraft:bone_block
fill 348 234 214 366 234 215 minecraft:bone_block
fill 349 234 197 351 234 197 minecraft:ochre_froglight
fill 349 234 203 351 234 203 minecraft:ochre_froglight
setblock 350 234 196 minecraft:smooth_basalt
fill 350 234 204 352 234 204 minecraft:smooth_basalt
fill 351 234 196 370 234 196 minecraft:bone_block
fill 351 234 198 351 234 199 minecraft:ochre_froglight
fill 351 234 201 351 234 202 minecraft:ochre_froglight
fill 351 234 205 370 234 205 minecraft:bone_block
fill 352 234 197 352 234 198 minecraft:smooth_basalt
fill 352 234 199 352 234 201 minecraft:ochre_froglight
fill 352 234 202 352 234 203 minecraft:smooth_basalt
fill 353 234 197 370 234 198 minecraft:bone_block
fill 353 234 199 353 234 202 minecraft:smooth_basalt
fill 353 234 203 370 234 204 minecraft:bone_block
fill 354 234 199 370 234 202 minecraft:bone_block
fill 357 234 182 370 234 182 minecraft:smooth_basalt
fill 357 234 222 370 234 222 minecraft:smooth_basalt
fill 359 234 183 370 234 183 minecraft:smooth_basalt
fill 359 234 221 370 234 221 minecraft:smooth_basalt
fill 361 234 184 370 234 184 minecraft:smooth_basalt
fill 361 234 220 370 234 220 minecraft:smooth_basalt
fill 363 234 185 370 234 185 minecraft:smooth_basalt
fill 363 234 219 370 234 219 minecraft:smooth_basalt
fill 364 234 186 370 234 186 minecraft:smooth_basalt
fill 364 234 218 370 234 218 minecraft:smooth_basalt
fill 365 234 187 370 234 187 minecraft:smooth_basalt
fill 365 234 217 370 234 217 minecraft:smooth_basalt
fill 366 234 188 370 234 188 minecraft:smooth_basalt
fill 366 234 216 370 234 216 minecraft:smooth_basalt
fill 367 234 189 370 234 189 minecraft:smooth_basalt
setblock 367 234 190 minecraft:bone_block
setblock 367 234 214 minecraft:bone_block
fill 367 234 215 370 234 215 minecraft:smooth_basalt
fill 368 234 190 370 234 191 minecraft:smooth_basalt
fill 368 234 213 370 234 214 minecraft:smooth_basalt
fill 369 234 192 370 234 193 minecraft:smooth_basalt
fill 369 234 211 370 234 212 minecraft:smooth_basalt
fill 370 234 194 370 234 195 minecraft:smooth_basalt
fill 370 234 209 370 234 210 minecraft:smooth_basalt
fill 330 235 199 342 235 205 minecraft:bone_block
fill 331 235 195 342 235 198 minecraft:bone_block
fill 331 235 206 345 235 209 minecraft:bone_block
fill 332 235 193 344 235 194 minecraft:bone_block
fill 332 235 210 344 235 211 minecraft:bone_block
fill 333 235 192 344 235 192 minecraft:bone_block
fill 333 235 212 344 235 212 minecraft:bone_block
fill 334 235 190 366 235 190 minecraft:bone_block
fill 334 235 214 366 235 214 minecraft:bone_block
fill 335 235 189 344 235 189 minecraft:bone_block
fill 335 235 215 344 235 215 minecraft:bone_block
fill 336 235 188 364 235 188 minecraft:bone_block
fill 336 235 216 364 235 216 minecraft:bone_block
fill 337 235 187 363 235 187 minecraft:bone_block
fill 337 235 217 363 235 217 minecraft:bone_block
fill 338 235 186 362 235 186 minecraft:bone_block
fill 338 235 218 362 235 218 minecraft:bone_block
fill 339 235 185 361 235 185 minecraft:bone_block
fill 339 235 219 361 235 219 minecraft:bone_block
fill 341 235 184 359 235 184 minecraft:bone_block
fill 341 235 220 359 235 220 minecraft:bone_block
fill 343 235 183 357 235 183 minecraft:bone_block
fill 343 235 195 343 235 197 minecraft:bone_block
fill 343 235 198 343 235 203 minecraft:smooth_basalt
fill 343 235 204 343 235 205 minecraft:bone_block
fill 343 235 221 357 235 221 minecraft:bone_block
fill 344 235 195 344 235 196 minecraft:bone_block
setblock 344 235 197 minecraft:smooth_basalt
fill 344 235 203 344 235 204 minecraft:smooth_basalt
setblock 344 235 205 minecraft:bone_block
fill 345 235 194 345 235 195 minecraft:bone_block
setblock 345 235 196 minecraft:smooth_basalt
fill 345 235 205 346 235 205 minecraft:smooth_basalt
fill 345 235 210 368 235 210 minecraft:bone_block
fill 346 235 194 368 235 194 minecraft:bone_block
fill 346 235 195 351 235 195 minecraft:smooth_basalt
fill 346 235 206 352 235 206 minecraft:smooth_basalt
fill 346 235 207 347 235 209 minecraft:bone_block
fill 347 235 182 353 235 182 minecraft:bone_block
fill 347 235 222 353 235 222 minecraft:bone_block
fill 348 235 189 365 235 189 minecraft:bone_block
fill 348 235 192 367 235 192 minecraft:bone_block
fill 348 235 207 349 235 207 minecraft:smooth_basalt
fill 348 235 208 369 235 209 minecraft:bone_block
fill 348 235 212 367 235 212 minecraft:bone_block
fill 348 235 215 365 235 215 minecraft:bone_block
fill 350 235 207 369 235 207 minecraft:bone_block
fill 351 235 196 352 235 196 minecraft:smooth_basalt
fill 351 235 205 353 235 205 minecraft:smooth_basalt
fill 352 235 195 369 235 195 minecraft:bone_block
fill 353 235 196 369 235 196 minecraft:bone_block
fill 353 235 197 353 235 198 minecraft:smooth_basalt
fill 353 235 203 354 235 204 minecraft:smooth_basalt
fill 353 235 206 369 235 206 minecraft:bone_block
fill 354 235 197 369 235 197 minecraft:bone_block
fill 354 235 198 354 235 202 minecraft:smooth_basalt
fill 354 235 205 370 235 205 minecraft:bone_block
fill 355 235 198 369 235 199 minecraft:bone_block
fill 355 235 200 355 235 201 minecraft:smooth_basalt
fill 355 235 202 370 235 204 minecraft:bone_block
fill 356 235 200 370 235 201 minecraft:bone_block
setblock 370 235 199 minecraft:bone_block
fill 331 236 198 341 236 206 minecraft:bone_block
fill 332 236 195 342 236 197 minecraft:bone_block
fill 332 236 207 344 236 209 minecraft:bone_block
fill 333 236 193 345 236 194 minecraft:bone_block
fill 333 236 210 367 236 211 minecraft:bone_block
fill 334 236 191 344 236 192 minecraft:bone_block
fill 334 236 212 344 236 213 minecraft:bone_block
fill 335 236 190 365 236 190 minecraft:bone_block
fill 335 236 214 365 236 214 minecraft:bone_block
fill 336 236 189 344 236 189 minecraft:bone_block
fill 336 236 215 344 236 215 minecraft:bone_block
fill 337 236 188 363 236 188 minecraft:bone_block
fill 337 236 216 363 236 216 minecraft:bone_block
fill 338 236 187 362 236 187 minecraft:bone_block
fill 338 236 217 362 236 217 minecraft:bone_block
fill 339 236 186 361 236 186 minecraft:bone_block
fill 339 236 218 361 236 218 minecraft:bone_block
fill 341 236 185 359 236 185 minecraft:bone_block
fill 341 236 219 359 236 219 minecraft:bone_block
fill 342 236 198 342 236 203 minecraft:smooth_basalt
fill 342 236 204 342 236 206 minecraft:bone_block
fill 343 236 184 357 236 184 minecraft:bone_block
fill 343 236 195 343 236 196 minecraft:bone_block
setblock 343 236 197 minecraft:smooth_basalt
fill 343 236 204 343 236 205 minecraft:smooth_basalt
setblock 343 236 206 minecraft:bone_block
fill 343 236 220 357 236 220 minecraft:bone_block
setblock 344 236 195 minecraft:bone_block
setblock 344 236 196 minecraft:smooth_basalt
fill 344 236 205 344 236 206 minecraft:smooth_basalt
fill 345 236 191 366 236 191 minecraft:bone_block
setblock 345 236 195 minecraft:smooth_basalt
fill 345 236 206 345 236 207 minecraft:smooth_basalt
fill 345 236 208 346 236 209 minecraft:bone_block
fill 345 236 213 366 236 213 minecraft:bone_block
fill 346 236 183 354 236 183 minecraft:bone_block
fill 346 236 193 367 236 193 minecraft:bone_block
fill 346 236 194 351 236 194 minecraft:smooth_basalt
fill 346 236 207 347 236 207 minecraft:smooth_basalt
fill 346 236 221 354 236 221 minecraft:bone_block
fill 347 236 208 351 236 208 minecraft:smooth_basalt
fill 347 236 209 368 236 209 minecraft:bone_block
fill 348 236 189 364 236 189 minecraft:bone_block
fill 348 236 192 366 236 192 minecraft:bone_block
fill 348 236 212 366 236 212 minecraft:bone_block
fill 348 236 215 364 236 215 minecraft:bone_block
fill 350 236 207 353 236 207 minecraft:smooth_basalt
fill 352 236 194 367 236 194 minecraft:bone_block
fill 352 236 195 353 236 195 minecraft:smooth_basalt
fill 352 236 208 368 236 208 minecraft:bone_block
fill 353 236 196 354 236 196 minecraft:smooth_basalt
fill 353 236 206 354 236 206 minecraft:smooth_basalt
fill 354 236 195 368 236 195 minecraft:bone_block
fill 354 236 197 355 236 197 minecraft:smooth_basalt
fill 354 236 205 355 236 205 minecraft:smooth_basalt
fill 354 236 207 368 236 207 minecraft:bone_block
fill 355 236 196 368 236 196 minecraft:bone_block
fill 355 236 198 355 236 199 minecraft:smooth_basalt
fill 355 236 202 355 236 204 minecraft:smooth_basalt
fill 355 236 206 369 236 206 minecraft:bone_block
fill 356 236 197 368 236 198 minecraft:bone_block
fill 356 236 199 356 236 203 minecraft:smooth_basalt
fill 356 236 204 369 236 205 minecraft:bone_block
fill 357 236 199 369 236 203 minecraft:bone_block
setblock 369 236 198 minecraft:bone_block
fill 332 237 197 340 237 207 minecraft:bone_block
fill 333 237 194 342 237 196 minecraft:bone_block
fill 333 237 208 343 237 210 minecraft:bone_block
fill 334 237 193 346 237 193 minecraft:bone_block
fill 334 237 211 366 237 211 minecraft:bone_block
fill 335 237 191 344 237 192 minecraft:bone_block
fill 335 237 212 344 237 213 minecraft:bone_block
fill 336 237 190 364 237 190 minecraft:bone_block
fill 336 237 214 364 237 214 minecraft:bone_block
fill 337 237 189 344 237 189 minecraft:bone_block
fill 337 237 215 344 237 215 minecraft:bone_block
fill 338 237 188 362 237 188 minecraft:bone_block
fill 338 237 216 362 237 216 minecraft:bone_block
fill 339 237 187 361 237 187 minecraft:bone_block
fill 339 237 217 361 237 217 minecraft:bone_block
fill 341 237 186 359 237 186 minecraft:bone_block
fill 341 237 197 341 237 198 minecraft:bone_block
fill 341 237 199 341 237 204 minecraft:smooth_basalt
fill 341 237 205 341 237 207 minecraft:bone_block
fill 341 237 218 359 237 218 minecraft:bone_block
fill 342 237 185 358 237 185 minecraft:bone_block
fill 342 237 197 342 237 198 minecraft:smooth_basalt
fill 342 237 204 342 237 206 minecraft:smooth_basalt
setblock 342 237 207 minecraft:bone_block
fill 342 237 219 358 237 219 minecraft:bone_block
fill 343 237 194 343 237 195 minecraft:bone_block
setblock 343 237 196 minecraft:smooth_basalt
fill 343 237 206 343 237 207 minecraft:smooth_basalt
setblock 344 237 194 minecraft:bone_block
setblock 344 237 195 minecraft:smooth_basalt
fill 344 237 207 344 237 208 minecraft:smooth_basalt
fill 344 237 209 344 237 210 minecraft:bone_block
fill 345 237 184 355 237 184 minecraft:bone_block
fill 345 237 191 365 237 191 minecraft:bone_block
fill 345 237 194 346 237 194 minecraft:smooth_basalt
fill 345 237 208 346 237 209 minecraft:smooth_basalt
fill 345 237 210 347 237 210 minecraft:bone_block
fill 345 237 213 365 237 213 minecraft:bone_block
fill 345 237 220 355 237 220 minecraft:bone_block
fill 347 237 193 352 237 193 minecraft:smooth_basalt
fill 347 237 209 353 237 209 minecraft:smooth_basalt
fill 348 237 189 363 237 189 minecraft:bone_block
fill 348 237 192 365 237 192 minecraft:bone_block
fill 348 237 210 350 237 210 minecraft:smooth_basalt
fill 348 237 212 365 237 212 minecraft:bone_block
fill 348 237 215 363 237 215 minecraft:bone_block
fill 351 237 210 367 237 210 minecraft:bone_block
fill 352 237 194 354 237 194 minecraft:smooth_basalt
fill 352 237 208 355 237 208 minecraft:smooth_basalt
fill 353 237 193 366 237 193 minecraft:bone_block
fill 354 237 195 355 237 195 minecraft:smooth_basalt
fill 354 237 207 356 237 207 minecraft:smooth_basalt
fill 354 237 209 367 237 209 minecraft:bone_block
fill 355 237 194 367 237 194 minecraft:bone_block
fill 355 237 196 356 237 196 minecraft:smooth_basalt
fill 355 237 206 356 237 206 minecraft:smooth_basalt
fill 356 237 195 367 237 195 minecraft:bone_block
fill 356 237 197 357 237 198 minecraft:smooth_basalt
fill 356 237 204 357 237 205 minecraft:smooth_basalt
fill 356 237 208 367 237 208 minecraft:bone_block
fill 357 237 196 367 237 196 minecraft:bone_block
fill 357 237 199 357 237 203 minecraft:smooth_basalt
fill 357 237 206 368 237 207 minecraft:bone_block
fill 358 237 197 368 237 199 minecraft:bone_block
fill 358 237 200 358 237 202 minecraft:smooth_basalt
fill 358 237 203 368 237 205 minecraft:bone_block
fill 359 237 200 368 237 202 minecraft:bone_block
fill 333 238 197 339 238 207 minecraft:bone_block
fill 334 238 194 341 238 196 minecraft:bone_block
fill 334 238 208 341 238 210 minecraft:bone_block
fill 335 238 193 344 238 193 minecraft:bone_block
fill 335 238 211 345 238 211 minecraft:bone_block
fill 336 238 191 346 238 192 minecraft:bone_block
fill 336 238 212 344 238 213 minecraft:bone_block
fill 337 238 190 363 238 190 minecraft:bone_block
fill 337 238 214 363 238 214 minecraft:bone_block
fill 338 238 189 344 238 189 minecraft:bone_block
fill 338 238 215 344 238 215 minecraft:bone_block
fill 339 238 188 361 238 188 minecraft:bone_block
fill 339 238 216 361 238 216 minecraft:bone_block
fill 340 238 197 340 238 198 minecraft:bone_block
fill 340 238 199 340 238 204 minecraft:smooth_basalt
fill 340 238 205 340 238 207 minecraft:bone_block
fill 341 238 187 359 238 187 minecraft:bone_block
fill 341 238 197 341 238 198 minecraft:smooth_basalt
fill 341 238 205 341 238 206 minecraft:smooth_basalt
setblock 341 238 207 minecraft:bone_block
fill 341 238 217 359 238 217 minecraft:bone_block
fill 342 238 186 358 238 186 minecraft:bone_block
setblock 342 238 194 minecraft:bone_block
fill 342 238 195 342 238 196 minecraft:smooth_basalt
fill 342 238 202 342 239 202 minecraft:calcite
fill 342 238 207 342 238 208 minecraft:smooth_basalt
fill 342 238 209 342 238 210 minecraft:bone_block
fill 342 238 218 358 238 218 minecraft:bone_block
fill 343 238 194 343 238 195 minecraft:smooth_basalt
fill 343 238 198 343 238 199 minecraft:calcite
fill 343 238 205 343 238 206 minecraft:calcite
fill 343 238 208 343 238 209 minecraft:smooth_basalt
setblock 343 238 210 minecraft:bone_block
setblock 344 238 194 minecraft:smooth_basalt
fill 344 238 209 344 238 210 minecraft:smooth_basalt
fill 345 238 185 355 238 185 minecraft:bone_block
fill 345 238 193 346 238 193 minecraft:smooth_basalt
fill 345 238 195 345 239 196 minecraft:calcite
fill 345 238 208 345 239 209 minecraft:calcite
fill 345 238 210 347 238 210 minecraft:smooth_basalt
fill 345 238 213 364 238 213 minecraft:bone_block
fill 345 238 219 355 238 219 minecraft:bone_block
fill 346 238 211 353 238 211 minecraft:smooth_basalt
fill 347 238 191 364 238 191 minecraft:bone_block
fill 347 238 192 352 238 192 minecraft:smooth_basalt
fill 348 238 189 362 238 189 minecraft:bone_block
fill 348 238 194 348 239 194 minecraft:calcite
fill 348 238 210 348 239 210 minecraft:calcite
fill 348 238 212 364 238 212 minecraft:bone_block
fill 348 238 215 362 238 215 minecraft:bone_block
setblock 351 238 210 minecraft:smooth_basalt
fill 352 238 194 352 239 194 minecraft:calcite
fill 352 238 210 352 239 210 minecraft:calcite
fill 353 238 192 364 238 192 minecraft:bone_block
fill 353 238 193 354 238 193 minecraft:smooth_basalt
fill 353 238 210 355 238 210 minecraft:smooth_basalt
setblock 354 238 209 minecraft:smooth_basalt
fill 354 238 211 365 238 211 minecraft:bone_block
fill 355 238 193 365 238 193 minecraft:bone_block
fill 355 238 194 356 238 194 minecraft:smooth_basalt
fill 355 238 195 355 239 196 minecraft:calcite
fill 355 238 208 355 239 209 minecraft:calcite
fill 356 238 195 357 238 195 minecraft:smooth_basalt
fill 356 238 208 356 238 209 minecraft:smooth_basalt
fill 356 238 210 366 238 210 minecraft:bone_block
fill 357 238 194 366 238 194 minecraft:bone_block
fill 357 238 196 358 238 196 minecraft:smooth_basalt
fill 357 238 198 357 238 199 minecraft:calcite
fill 357 238 205 357 238 206 minecraft:calcite
fill 357 238 207 357 238 208 minecraft:smooth_basalt
fill 357 238 209 366 238 209 minecraft:bone_block
fill 358 238 195 366 238 195 minecraft:bone_block
fill 358 238 197 358 238 199 minecraft:smooth_basalt
fill 358 238 202 358 239 202 minecraft:calcite
fill 358 238 203 358 238 207 minecraft:smooth_basalt
fill 358 238 208 366 238 208 minecraft:bone_block
fill 359 238 196 366 238 197 minecraft:bone_block
fill 359 238 198 359 238 205 minecraft:smooth_basalt
fill 359 238 206 367 238 207 minecraft:bone_block
fill 360 238 198 367 238 205 minecraft:bone_block
setblock 367 238 197 minecraft:bone_block
fill 334 239 197 338 239 207 minecraft:bone_block
fill 335 239 195 340 239 196 minecraft:bone_block
fill 335 239 208 340 239 209 minecraft:bone_block
fill 336 239 193 341 239 194 minecraft:bone_block
fill 336 239 210 341 239 211 minecraft:bone_block
fill 337 239 192 344 239 192 minecraft:bone_block
fill 337 239 212 344 239 212 minecraft:bone_block
fill 338 239 191 346 239 191 minecraft:bone_block
fill 338 239 213 347 239 213 minecraft:bone_block
fill 339 239 190 361 239 190 minecraft:bone_block
fill 339 239 197 339 239 198 minecraft:bone_block
fill 339 239 199 339 239 205 minecraft:smooth_basalt
fill 339 239 206 339 239 207 minecraft:bone_block
fill 339 239 214 361 239 214 minecraft:bone_block
fill 340 239 189 344 239 189 minecraft:bone_block
fill 340 239 197 340 239 198 minecraft:smooth_basalt
fill 340 239 202 341 240 202 minecraft:calcite
fill 340 239 205 340 239 207 minecraft:smooth_basalt
fill 340 239 215 344 239 215 minecraft:bone_block
fill 341 239 188 359 239 188 minecraft:bone_block
fill 341 239 195 341 239 196 minecraft:smooth_basalt
fill 341 239 197 341 240 198 minecraft:calcite
fill 341 239 206 341 240 207 minecraft:calcite
setblock 341 239 208 minecraft:smooth_basalt
setblock 341 239 209 minecraft:bone_block
fill 341 239 216 359 239 216 minecraft:bone_block
setblock 342 239 193 minecraft:bone_block
setblock 342 239 194 minecraft:smooth_basalt
fill 342 239 198 343 239 198 minecraft:calcite
fill 342 239 206 343 239 206 minecraft:calcite
fill 342 239 209 342 239 210 minecraft:smooth_basalt
fill 342 239 211 343 239 211 minecraft:bone_block
fill 343 239 187 357 239 187 minecraft:bone_block
fill 343 239 193 344 239 193 minecraft:smooth_basalt
setblock 343 239 210 minecraft:smooth_basalt
fill 343 239 217 357 239 217 minecraft:bone_block
fill 344 239 194 344 240 195 minecraft:calcite
fill 344 239 209 344 240 210 minecraft:calcite
fill 344 239 211 345 239 211 minecraft:smooth_basalt
fill 345 239 186 355 239 186 minecraft:bone_block
fill 345 239 192 346 239 192 minecraft:smooth_basalt
fill 345 239 212 347 239 212 minecraft:smooth_basalt
fill 345 239 218 355 239 218 minecraft:bone_block
fill 347 239 191 353 239 191 minecraft:smooth_basalt
fill 348 239 189 360 239 189 minecraft:bone_block
fill 348 239 192 348 240 193 minecraft:calcite
fill 348 239 211 348 240 212 minecraft:calcite
fill 348 239 213 352 239 213 minecraft:smooth_basalt
fill 348 239 215 360 239 215 minecraft:bone_block
fill 349 239 212 351 239 212 minecraft:smooth_basalt
fill 352 239 192 352 240 193 minecraft:calcite
fill 352 239 211 352 240 212 minecraft:calcite
fill 353 239 192 355 239 192 minecraft:smooth_basalt
fill 353 239 212 354 239 212 minecraft:smooth_basalt
fill 353 239 213 362 239 213 minecraft:bone_block
fill 354 239 191 362 239 191 minecraft:bone_block
fill 354 239 211 356 239 211 minecraft:smooth_basalt
fill 355 239 193 356 239 193 minecraft:smooth_basalt
fill 355 239 212 363 239 212 minecraft:bone_block
fill 356 239 192 363 239 192 minecraft:bone_block
fill 356 239 194 356 240 195 minecraft:calcite
fill 356 239 209 356 240 210 minecraft:calcite
fill 357 239 193 364 239 193 minecraft:bone_block
fill 357 239 194 358 239 194 minecraft:smooth_basalt
fill 357 239 198 359 239 198 minecraft:calcite
fill 357 239 206 359 239 206 minecraft:calcite
fill 357 239 209 357 239 210 minecraft:smooth_basalt
fill 357 239 211 364 239 211 minecraft:bone_block
setblock 358 239 195 minecraft:smooth_basalt
fill 358 239 208 358 239 209 minecraft:smooth_basalt
fill 358 239 210 364 239 210 minecraft:bone_block
fill 359 239 194 364 239 195 minecraft:bone_block
setblock 359 239 196 minecraft:smooth_basalt
fill 359 239 197 359 241 197 minecraft:calcite
fill 359 239 202 360 240 202 minecraft:calcite
fill 359 239 207 359 241 207 minecraft:calcite
setblock 359 239 208 minecraft:smooth_basalt
fill 359 239 209 365 239 209 minecraft:bone_block
fill 360 239 196 365 239 196 minecraft:bone_block
fill 360 239 197 360 239 201 minecraft:smooth_basalt
fill 360 239 203 360 239 206 minecraft:smooth_basalt
fill 360 239 207 365 239 208 minecraft:bone_block
fill 361 239 197 366 239 199 minecraft:bone_block
fill 361 239 200 361 239 204 minecraft:smooth_basalt
fill 361 239 205 366 239 206 minecraft:bone_block
fill 362 239 200 366 239 204 minecraft:bone_block
setblock 365 239 195 minecraft:bone_block
setblock 366 239 207 minecraft:bone_block
fill 330 240 182 332 240 182 minecraft:polished_basalt
fill 330 240 184 330 240 186 minecraft:polished_basalt
fill 330 240 188 330 240 190 minecraft:polished_basalt
fill 330 240 192 330 240 194 minecraft:polished_basalt
fill 330 240 196 330 240 198 minecraft:polished_basalt
fill 330 240 200 330 240 202 minecraft:polished_basalt
fill 330 240 204 330 240 206 minecraft:polished_basalt
fill 330 240 208 330 240 210 minecraft:polished_basalt
fill 330 240 212 330 240 214 minecraft:polished_basalt
fill 330 240 216 330 240 218 minecraft:polished_basalt
fill 330 240 220 330 240 222 minecraft:polished_basalt
fill 332 240 222 334 240 222 minecraft:polished_basalt
fill 334 240 182 336 240 182 minecraft:polished_basalt
fill 335 240 200 337 240 204 minecraft:bone_block
fill 336 240 197 337 240 199 minecraft:bone_block
fill 336 240 205 337 240 207 minecraft:bone_block
fill 336 240 222 338 240 222 minecraft:polished_basalt
fill 337 240 195 339 240 196 minecraft:bone_block
fill 337 240 208 339 240 209 minecraft:bone_block
fill 338 240 182 340 240 182 minecraft:polished_basalt
fill 338 240 193 340 240 194 minecraft:bone_block
fill 338 240 197 338 240 198 minecraft:bone_block
fill 338 240 199 338 240 200 minecraft:smooth_basalt
fill 338 240 201 339 241 203 minecraft:calcite
fill 338 240 204 338 240 205 minecraft:smooth_basalt
fill 338 240 206 338 240 207 minecraft:bone_block
fill 338 240 210 340 240 211 minecraft:bone_block
fill 339 240 192 342 240 192 minecraft:bone_block
fill 339 240 197 340 241 198 minecraft:calcite
fill 339 240 206 340 241 207 minecraft:calcite
fill 339 240 212 342 240 212 minecraft:bone_block
fill 340 240 191 344 240 191 minecraft:bone_block
setblock 340 240 195 minecraft:smooth_basalt
fill 340 240 196 340 241 196 minecraft:calcite
setblock 340 240 201 minecraft:calcite
setblock 340 240 203 minecraft:calcite
fill 340 240 208 340 241 208 minecraft:calcite
setblock 340 240 209 minecraft:bone_block
fill 340 240 213 344 240 213 minecraft:bone_block
fill 340 240 222 342 240 222 minecraft:polished_basalt
fill 341 240 190 346 240 190 minecraft:bone_block
setblock 341 240 193 minecraft:bone_block
setblock 341 240 194 minecraft:smooth_basalt
fill 341 240 209 341 240 210 minecraft:smooth_basalt
setblock 341 240 211 minecraft:bone_block
fill 341 240 214 346 240 214 minecraft:bone_block
fill 342 240 182 344 240 182 minecraft:polished_basalt
fill 342 240 193 343 241 194 minecraft:calcite
setblock 342 240 198 minecraft:calcite
setblock 342 240 206 minecraft:calcite
fill 342 240 210 343 241 211 minecraft:calcite
fill 343 240 189 344 240 189 minecraft:bone_block
fill 343 240 192 343 241 192 minecraft:calcite
fill 343 240 212 343 241 212 minecraft:calcite
fill 343 240 215 344 240 215 minecraft:bone_block
setblock 344 240 192 minecraft:smooth_basalt
fill 344 240 193 344 241 193 minecraft:calcite
fill 344 240 211 344 241 211 minecraft:calcite
setblock 344 240 212 minecraft:smooth_basalt
fill 344 240 222 346 240 222 minecraft:polished_basalt
fill 345 240 188 355 240 188 minecraft:bone_block
fill 345 240 191 346 240 191 minecraft:smooth_basalt
fill 345 240 213 346 240 213 minecraft:smooth_basalt
fill 345 240 216 355 240 216 minecraft:bone_block
fill 346 240 182 348 240 182 minecraft:polished_basalt
fill 347 240 190 347 241 192 minecraft:calcite
fill 347 240 212 347 241 214 minecraft:calcite
fill 348 240 187 352 240 187 minecraft:bone_block
fill 348 240 189 357 240 189 minecraft:bone_block
fill 348 240 190 348 241 191 minecraft:calcite
fill 348 240 213 348 241 214 minecraft:calcite
fill 348 240 215 357 240 215 minecraft:bone_block
fill 348 240 217 352 240 217 minecraft:bone_block
fill 348 240 222 350 240 222 minecraft:polished_basalt
fill 349 240 190 351 240 190 minecraft:smooth_basalt
fill 349 240 214 351 240 214 minecraft:smooth_basalt
fill 350 240 182 352 240 182 minecraft:polished_basalt
fill 352 240 190 353 241 191 minecraft:calcite
fill 352 240 213 353 241 214 minecraft:calcite
fill 352 240 222 354 240 222 minecraft:polished_basalt
fill 353 240 192 353 241 192 minecraft:calcite
fill 353 240 212 353 241 212 minecraft:calcite
fill 354 240 182 356 240 182 minecraft:polished_basalt
fill 354 240 190 359 240 190 minecraft:bone_block
fill 354 240 191 355 240 191 minecraft:smooth_basalt
setblock 354 240 213 minecraft:smooth_basalt
fill 354 240 214 359 240 214 minecraft:bone_block
fill 355 240 212 356 240 212 minecraft:smooth_basalt
fill 355 240 213 360 240 213 minecraft:bone_block
fill 356 240 191 360 240 191 minecraft:bone_block
setblock 356 240 192 minecraft:smooth_basalt
fill 356 240 193 358 241 193 minecraft:calcite
fill 356 240 211 358 241 211 minecraft:calcite
fill 356 240 222 358 240 222 minecraft:polished_basalt
fill 357 240 192 357 241 192 minecraft:calcite
fill 357 240 194 358 241 194 minecraft:calcite
fill 357 240 210 358 241 210 minecraft:calcite
fill 357 240 212 357 241 212 minecraft:calcite
fill 358 240 182 360 240 182 minecraft:polished_basalt
fill 358 240 192 361 240 192 minecraft:bone_block
fill 358 240 198 361 240 198 minecraft:calcite
fill 358 240 206 361 240 206 minecraft:calcite
fill 358 240 212 361 240 212 minecraft:bone_block
fill 359 240 193 362 240 193 minecraft:bone_block
fill 359 240 194 359 240 195 minecraft:smooth_basalt
setblock 359 240 209 minecraft:smooth_basalt
fill 359 240 210 362 240 211 minecraft:bone_block
fill 360 240 194 362 240 195 minecraft:bone_block
fill 360 240 196 360 241 197 minecraft:calcite
fill 360 240 201 362 240 201 minecraft:calcite
fill 360 240 203 362 240 203 minecraft:calcite
fill 360 240 207 360 241 208 minecraft:calcite
fill 360 240 209 363 240 209 minecraft:bone_block
fill 360 240 222 362 240 222 minecraft:polished_basalt
fill 361 240 196 363 240 196 minecraft:bone_block
fill 361 240 197 361 241 197 minecraft:calcite
setblock 361 240 199 minecraft:smooth_basalt
fill 361 240 202 362 241 202 minecraft:calcite
setblock 361 240 205 minecraft:smooth_basalt
fill 361 240 207 361 241 207 minecraft:calcite
fill 361 240 208 363 240 208 minecraft:bone_block
fill 362 240 182 364 240 182 minecraft:polished_basalt
fill 362 240 197 364 240 199 minecraft:bone_block
setblock 362 240 200 minecraft:smooth_basalt
setblock 362 240 204 minecraft:smooth_basalt
fill 362 240 205 364 240 207 minecraft:bone_block
setblock 363 240 195 minecraft:bone_block
fill 363 240 200 365 240 204 minecraft:bone_block
fill 364 240 222 366 240 222 minecraft:polished_basalt
fill 366 240 182 368 240 182 minecraft:polished_basalt
fill 368 240 222 370 240 222 minecraft:polished_basalt
fill 370 240 182 370 240 184 minecraft:polished_basalt
fill 370 240 186 370 240 188 minecraft:polished_basalt
fill 370 240 190 370 240 192 minecraft:polished_basalt
fill 370 240 194 370 240 196 minecraft:polished_basalt
fill 370 240 198 370 240 200 minecraft:polished_basalt
fill 370 240 202 370 240 204 minecraft:polished_basalt
fill 370 240 206 370 240 208 minecraft:polished_basalt
fill 370 240 210 370 240 212 minecraft:polished_basalt
fill 370 240 214 370 240 216 minecraft:polished_basalt
fill 370 240 218 370 240 220 minecraft:polished_basalt
setblock 332 241 184 minecraft:light[level=12]
setblock 332 241 192 minecraft:light[level=12]
setblock 332 241 200 minecraft:light[level=12]
setblock 332 241 208 minecraft:light[level=12]
setblock 332 241 216 minecraft:light[level=12]
setblock 337 241 202 minecraft:calcite
setblock 339 241 196 minecraft:calcite
setblock 339 241 208 minecraft:calcite
setblock 340 241 184 minecraft:light[level=12]
setblock 340 241 192 minecraft:light[level=12]
setblock 340 241 200 minecraft:light[level=12]
setblock 340 241 202 minecraft:calcite
setblock 340 241 216 minecraft:light[level=12]
setblock 341 241 197 minecraft:calcite
setblock 341 241 207 minecraft:calcite
setblock 342 241 192 minecraft:calcite
setblock 342 241 212 minecraft:calcite
setblock 344 241 194 minecraft:calcite
setblock 344 241 210 minecraft:calcite
setblock 348 241 184 minecraft:light[level=12]
setblock 348 241 192 minecraft:calcite
setblock 348 241 200 minecraft:light[level=12]
setblock 348 241 208 minecraft:light[level=12]
setblock 348 241 212 minecraft:calcite
setblock 348 241 216 minecraft:light[level=12]
setblock 352 241 192 minecraft:calcite
setblock 352 241 212 minecraft:calcite
setblock 356 241 184 minecraft:light[level=12]
setblock 356 241 192 minecraft:light[level=12]
setblock 356 241 194 minecraft:calcite
setblock 356 241 200 minecraft:light[level=12]
setblock 356 241 208 minecraft:light[level=12]
setblock 356 241 210 minecraft:calcite
setblock 356 241 216 minecraft:light[level=12]
setblock 358 241 192 minecraft:calcite
setblock 358 241 212 minecraft:calcite
fill 360 241 198 361 241 198 minecraft:calcite
setblock 360 241 202 minecraft:calcite
fill 360 241 206 361 241 206 minecraft:calcite
setblock 361 241 196 minecraft:calcite
fill 361 241 201 362 241 201 minecraft:calcite
fill 361 241 203 362 241 203 minecraft:calcite
setblock 361 241 208 minecraft:calcite
setblock 363 241 202 minecraft:calcite
setblock 364 241 184 minecraft:light[level=12]
setblock 364 241 192 minecraft:light[level=12]
setblock 364 241 200 minecraft:light[level=12]
setblock 364 241 208 minecraft:light[level=12]
setblock 364 241 216 minecraft:light[level=12]
fill 330 246 182 332 246 182 minecraft:polished_basalt
fill 330 246 184 330 246 186 minecraft:polished_basalt
fill 330 246 188 330 246 190 minecraft:polished_basalt
fill 330 246 192 330 246 194 minecraft:polished_basalt
fill 330 246 196 330 246 198 minecraft:polished_basalt
fill 330 246 200 330 246 202 minecraft:polished_basalt
fill 330 246 204 330 246 206 minecraft:polished_basalt
fill 330 246 208 330 246 210 minecraft:polished_basalt
fill 330 246 212 330 246 214 minecraft:polished_basalt
fill 330 246 216 330 246 218 minecraft:polished_basalt
fill 330 246 220 330 246 222 minecraft:polished_basalt
fill 332 246 222 334 246 222 minecraft:polished_basalt
fill 334 246 182 336 246 182 minecraft:polished_basalt
fill 336 246 222 338 246 222 minecraft:polished_basalt
fill 338 246 182 340 246 182 minecraft:polished_basalt
fill 340 246 222 342 246 222 minecraft:polished_basalt
fill 342 246 182 344 246 182 minecraft:polished_basalt
fill 344 246 222 346 246 222 minecraft:polished_basalt
fill 346 246 182 348 246 182 minecraft:polished_basalt
fill 348 246 222 350 246 222 minecraft:polished_basalt
fill 350 246 182 352 246 182 minecraft:polished_basalt
fill 352 246 222 354 246 222 minecraft:polished_basalt
fill 354 246 182 356 246 182 minecraft:polished_basalt
fill 356 246 222 358 246 222 minecraft:polished_basalt
fill 358 246 182 360 246 182 minecraft:polished_basalt
fill 360 246 222 362 246 222 minecraft:polished_basalt
fill 362 246 182 364 246 182 minecraft:polished_basalt
fill 364 246 222 366 246 222 minecraft:polished_basalt
fill 366 246 182 368 246 182 minecraft:polished_basalt
fill 368 246 222 370 246 222 minecraft:polished_basalt
fill 370 246 182 370 246 184 minecraft:polished_basalt
fill 370 246 186 370 246 188 minecraft:polished_basalt
fill 370 246 190 370 246 192 minecraft:polished_basalt
fill 370 246 194 370 246 196 minecraft:polished_basalt
fill 370 246 198 370 246 200 minecraft:polished_basalt
fill 370 246 202 370 246 204 minecraft:polished_basalt
fill 370 246 206 370 246 208 minecraft:polished_basalt
fill 370 246 210 370 246 212 minecraft:polished_basalt
fill 370 246 214 370 246 216 minecraft:polished_basalt
fill 370 246 218 370 246 220 minecraft:polished_basalt
setblock 332 249 184 minecraft:light[level=12]
setblock 332 249 192 minecraft:light[level=12]
setblock 332 249 200 minecraft:light[level=12]
setblock 332 249 208 minecraft:light[level=12]
setblock 332 249 216 minecraft:light[level=12]
setblock 340 249 184 minecraft:light[level=12]
setblock 340 249 192 minecraft:light[level=12]
setblock 340 249 200 minecraft:light[level=12]
setblock 340 249 208 minecraft:light[level=12]
setblock 340 249 216 minecraft:light[level=12]
setblock 348 249 184 minecraft:light[level=12]
setblock 348 249 192 minecraft:light[level=12]
setblock 348 249 200 minecraft:light[level=12]
setblock 348 249 208 minecraft:light[level=12]
setblock 348 249 216 minecraft:light[level=12]
setblock 356 249 184 minecraft:light[level=12]
setblock 356 249 192 minecraft:light[level=12]
setblock 356 249 200 minecraft:light[level=12]
setblock 356 249 208 minecraft:light[level=12]
setblock 356 249 216 minecraft:light[level=12]
setblock 364 249 184 minecraft:light[level=12]
setblock 364 249 192 minecraft:light[level=12]
setblock 364 249 200 minecraft:light[level=12]
setblock 364 249 208 minecraft:light[level=12]
setblock 364 249 216 minecraft:light[level=12]
fill 330 252 182 332 252 182 minecraft:polished_basalt
fill 330 252 184 330 252 186 minecraft:polished_basalt
fill 330 252 188 330 252 190 minecraft:polished_basalt
fill 330 252 192 330 252 194 minecraft:polished_basalt
fill 330 252 196 330 252 198 minecraft:polished_basalt
fill 330 252 200 330 252 202 minecraft:polished_basalt
fill 330 252 204 330 252 206 minecraft:polished_basalt
fill 330 252 208 330 252 210 minecraft:polished_basalt
fill 330 252 212 330 252 214 minecraft:polished_basalt
fill 330 252 216 330 252 218 minecraft:polished_basalt
fill 330 252 220 330 252 222 minecraft:polished_basalt
fill 332 252 222 334 252 222 minecraft:polished_basalt
fill 334 252 182 336 252 182 minecraft:polished_basalt
fill 336 252 222 338 252 222 minecraft:polished_basalt
fill 338 252 182 340 252 182 minecraft:polished_basalt
fill 338 252 203 339 253 204 minecraft:bone_block
fill 340 252 222 342 252 222 minecraft:polished_basalt
fill 342 252 182 344 252 182 minecraft:polished_basalt
fill 344 252 222 346 252 222 minecraft:polished_basalt
fill 346 252 182 348 252 182 minecraft:polished_basalt
fill 348 252 222 350 252 222 minecraft:polished_basalt
fill 350 252 182 352 252 182 minecraft:polished_basalt
fill 352 252 222 354 252 222 minecraft:polished_basalt
fill 354 252 182 356 252 182 minecraft:polished_basalt
fill 356 252 222 358 252 222 minecraft:polished_basalt
fill 358 252 182 360 252 182 minecraft:polished_basalt
fill 360 252 222 362 252 222 minecraft:polished_basalt
fill 362 252 182 364 252 182 minecraft:polished_basalt
fill 364 252 222 366 252 222 minecraft:polished_basalt
fill 366 252 182 368 252 182 minecraft:polished_basalt
fill 368 252 222 370 252 222 minecraft:polished_basalt
fill 370 252 182 370 252 184 minecraft:polished_basalt
fill 370 252 186 370 252 188 minecraft:polished_basalt
fill 370 252 190 370 252 192 minecraft:polished_basalt
fill 370 252 194 370 252 196 minecraft:polished_basalt
fill 370 252 198 370 252 200 minecraft:polished_basalt
fill 370 252 202 370 252 204 minecraft:polished_basalt
fill 370 252 206 370 252 208 minecraft:polished_basalt
fill 370 252 210 370 252 212 minecraft:polished_basalt
fill 370 252 214 370 252 216 minecraft:polished_basalt
fill 370 252 218 370 252 220 minecraft:polished_basalt
setblock 332 257 184 minecraft:light[level=12]
setblock 332 257 192 minecraft:light[level=12]
setblock 332 257 200 minecraft:light[level=12]
setblock 332 257 208 minecraft:light[level=12]
setblock 332 257 216 minecraft:light[level=12]
setblock 340 257 184 minecraft:light[level=12]
setblock 340 257 192 minecraft:light[level=12]
setblock 340 257 200 minecraft:light[level=12]
setblock 340 257 208 minecraft:light[level=12]
setblock 340 257 216 minecraft:light[level=12]
setblock 348 257 184 minecraft:light[level=12]
setblock 348 257 192 minecraft:light[level=12]
setblock 348 257 200 minecraft:light[level=12]
setblock 348 257 208 minecraft:light[level=12]
setblock 348 257 216 minecraft:light[level=12]
setblock 356 257 184 minecraft:light[level=12]
setblock 356 257 192 minecraft:light[level=12]
setblock 356 257 200 minecraft:light[level=12]
setblock 356 257 208 minecraft:light[level=12]
setblock 356 257 216 minecraft:light[level=12]
setblock 364 257 184 minecraft:light[level=12]
setblock 364 257 192 minecraft:light[level=12]
setblock 364 257 200 minecraft:light[level=12]
setblock 364 257 208 minecraft:light[level=12]
setblock 364 257 216 minecraft:light[level=12]
fill 330 258 182 332 258 182 minecraft:polished_basalt
fill 330 258 184 330 258 186 minecraft:polished_basalt
fill 330 258 188 330 258 190 minecraft:polished_basalt
fill 330 258 192 330 258 194 minecraft:polished_basalt
fill 330 258 196 330 258 198 minecraft:polished_basalt
fill 330 258 200 330 258 202 minecraft:polished_basalt
fill 330 258 204 330 258 206 minecraft:polished_basalt
fill 330 258 208 330 258 210 minecraft:polished_basalt
fill 330 258 212 330 258 214 minecraft:polished_basalt
fill 330 258 216 330 258 218 minecraft:polished_basalt
fill 330 258 220 330 258 222 minecraft:polished_basalt
fill 332 258 222 334 258 222 minecraft:polished_basalt
fill 334 258 182 336 258 182 minecraft:polished_basalt
fill 336 258 222 338 258 222 minecraft:polished_basalt
fill 338 258 182 340 258 182 minecraft:polished_basalt
fill 340 258 222 342 258 222 minecraft:polished_basalt
fill 342 258 182 344 258 182 minecraft:polished_basalt
fill 344 258 222 346 258 222 minecraft:polished_basalt
fill 346 258 182 348 258 182 minecraft:polished_basalt
fill 348 258 222 350 258 222 minecraft:polished_basalt
fill 350 258 182 352 258 182 minecraft:polished_basalt
fill 352 258 222 354 258 222 minecraft:polished_basalt
fill 354 258 182 356 258 182 minecraft:polished_basalt
fill 356 258 222 358 258 222 minecraft:polished_basalt
fill 358 258 182 360 258 182 minecraft:polished_basalt
fill 360 258 222 362 258 222 minecraft:polished_basalt
fill 362 258 182 364 258 182 minecraft:polished_basalt
fill 364 258 222 366 258 222 minecraft:polished_basalt
fill 366 258 182 368 258 182 minecraft:polished_basalt
fill 368 258 222 370 258 222 minecraft:polished_basalt
fill 370 258 182 370 258 184 minecraft:polished_basalt
fill 370 258 186 370 258 188 minecraft:polished_basalt
fill 370 258 190 370 258 192 minecraft:polished_basalt
fill 370 258 194 370 258 196 minecraft:polished_basalt
fill 370 258 198 370 258 200 minecraft:polished_basalt
fill 370 258 202 370 258 204 minecraft:polished_basalt
fill 370 258 206 370 258 208 minecraft:polished_basalt
fill 370 258 210 370 258 212 minecraft:polished_basalt
fill 370 258 214 370 258 216 minecraft:polished_basalt
fill 370 258 218 370 258 220 minecraft:polished_basalt
fill 339 259 199 340 260 201 minecraft:bone_block
fill 330 264 182 332 264 182 minecraft:polished_basalt
fill 330 264 184 330 264 186 minecraft:polished_basalt
fill 330 264 188 330 264 190 minecraft:polished_basalt
fill 330 264 192 330 264 194 minecraft:polished_basalt
fill 330 264 196 330 264 198 minecraft:polished_basalt
fill 330 264 200 330 264 202 minecraft:polished_basalt
fill 330 264 204 330 264 206 minecraft:polished_basalt
fill 330 264 208 330 264 210 minecraft:polished_basalt
fill 330 264 212 330 264 214 minecraft:polished_basalt
fill 330 264 216 330 264 218 minecraft:polished_basalt
fill 330 264 220 330 264 222 minecraft:polished_basalt
fill 332 264 222 334 264 222 minecraft:polished_basalt
fill 334 264 182 336 264 182 minecraft:polished_basalt
fill 336 264 222 338 264 222 minecraft:polished_basalt
fill 338 264 182 340 264 182 minecraft:polished_basalt
fill 340 264 222 342 264 222 minecraft:polished_basalt
fill 342 264 182 344 264 182 minecraft:polished_basalt
fill 344 264 222 346 264 222 minecraft:polished_basalt
fill 346 264 182 348 264 182 minecraft:polished_basalt
fill 348 264 222 350 264 222 minecraft:polished_basalt
fill 350 264 182 352 264 182 minecraft:polished_basalt
fill 352 264 222 354 264 222 minecraft:polished_basalt
fill 354 264 182 356 264 182 minecraft:polished_basalt
fill 356 264 222 358 264 222 minecraft:polished_basalt
fill 358 264 182 360 264 182 minecraft:polished_basalt
fill 360 264 222 362 264 222 minecraft:polished_basalt
fill 362 264 182 364 264 182 minecraft:polished_basalt
fill 364 264 222 366 264 222 minecraft:polished_basalt
fill 366 264 182 368 264 182 minecraft:polished_basalt
fill 368 264 222 370 264 222 minecraft:polished_basalt
fill 370 264 182 370 264 184 minecraft:polished_basalt
fill 370 264 186 370 264 188 minecraft:polished_basalt
fill 370 264 190 370 264 192 minecraft:polished_basalt
fill 370 264 194 370 264 196 minecraft:polished_basalt
fill 370 264 198 370 264 200 minecraft:polished_basalt
fill 370 264 202 370 264 204 minecraft:polished_basalt
fill 370 264 206 370 264 208 minecraft:polished_basalt
fill 370 264 210 370 264 212 minecraft:polished_basalt
fill 370 264 214 370 264 216 minecraft:polished_basalt
fill 370 264 218 370 264 220 minecraft:polished_basalt
setblock 332 265 184 minecraft:light[level=12]
setblock 332 265 192 minecraft:light[level=12]
setblock 332 265 200 minecraft:light[level=12]
setblock 332 265 208 minecraft:light[level=12]
setblock 332 265 216 minecraft:light[level=12]
setblock 340 265 184 minecraft:light[level=12]
setblock 340 265 192 minecraft:light[level=12]
setblock 340 265 200 minecraft:light[level=12]
setblock 340 265 208 minecraft:light[level=12]
setblock 340 265 216 minecraft:light[level=12]
setblock 348 265 184 minecraft:light[level=12]
setblock 348 265 192 minecraft:light[level=12]
setblock 348 265 200 minecraft:light[level=12]
setblock 348 265 208 minecraft:light[level=12]
setblock 348 265 216 minecraft:light[level=12]
setblock 356 265 184 minecraft:light[level=12]
setblock 356 265 192 minecraft:light[level=12]
setblock 356 265 200 minecraft:light[level=12]
setblock 356 265 208 minecraft:light[level=12]
setblock 356 265 216 minecraft:light[level=12]
setblock 364 265 184 minecraft:light[level=12]
setblock 364 265 192 minecraft:light[level=12]
setblock 364 265 200 minecraft:light[level=12]
setblock 364 265 208 minecraft:light[level=12]
setblock 364 265 216 minecraft:light[level=12]
fill 365 267 212 366 268 212 minecraft:calcite
fill 366 267 211 366 268 211 minecraft:calcite
fill 366 267 213 366 268 213 minecraft:calcite
fill 330 270 182 332 270 182 minecraft:polished_basalt
fill 330 270 184 330 270 186 minecraft:polished_basalt
fill 330 270 188 330 270 190 minecraft:polished_basalt
fill 330 270 192 330 270 194 minecraft:polished_basalt
fill 330 270 196 330 270 198 minecraft:polished_basalt
fill 330 270 200 330 270 202 minecraft:polished_basalt
fill 330 270 204 330 270 206 minecraft:polished_basalt
fill 330 270 208 330 270 210 minecraft:polished_basalt
fill 330 270 212 330 270 214 minecraft:polished_basalt
fill 330 270 216 330 270 218 minecraft:polished_basalt
fill 330 270 220 330 270 222 minecraft:polished_basalt
fill 332 270 222 334 270 222 minecraft:polished_basalt
fill 334 270 182 336 270 182 minecraft:polished_basalt
fill 336 270 222 338 270 222 minecraft:polished_basalt
fill 338 270 182 340 270 182 minecraft:polished_basalt
fill 340 270 222 342 270 222 minecraft:polished_basalt
fill 342 270 182 344 270 182 minecraft:polished_basalt
fill 344 270 222 346 270 222 minecraft:polished_basalt
fill 346 270 182 348 270 182 minecraft:polished_basalt
fill 348 270 222 350 270 222 minecraft:polished_basalt
fill 350 270 182 352 270 182 minecraft:polished_basalt
fill 352 270 222 354 270 222 minecraft:polished_basalt
fill 354 270 182 356 270 182 minecraft:polished_basalt
fill 356 270 222 358 270 222 minecraft:polished_basalt
fill 358 270 182 360 270 182 minecraft:polished_basalt
fill 360 270 222 362 270 222 minecraft:polished_basalt
fill 362 270 182 364 270 182 minecraft:polished_basalt
fill 364 270 222 366 270 222 minecraft:polished_basalt
fill 366 270 182 368 270 182 minecraft:polished_basalt
fill 368 270 222 370 270 222 minecraft:polished_basalt
fill 370 270 182 370 270 184 minecraft:polished_basalt
fill 370 270 186 370 270 188 minecraft:polished_basalt
fill 370 270 190 370 270 192 minecraft:polished_basalt
fill 370 270 194 370 270 196 minecraft:polished_basalt
fill 370 270 198 370 270 200 minecraft:polished_basalt
fill 370 270 202 370 270 204 minecraft:polished_basalt
fill 370 270 206 370 270 208 minecraft:polished_basalt
fill 370 270 210 370 270 212 minecraft:polished_basalt
fill 370 270 214 370 270 216 minecraft:polished_basalt
fill 370 270 218 370 270 220 minecraft:polished_basalt
setblock 332 273 184 minecraft:light[level=12]
setblock 332 273 192 minecraft:light[level=12]
setblock 332 273 200 minecraft:light[level=12]
setblock 332 273 208 minecraft:light[level=12]
setblock 332 273 216 minecraft:light[level=12]
setblock 340 273 184 minecraft:light[level=12]
setblock 340 273 192 minecraft:light[level=12]
setblock 340 273 200 minecraft:light[level=12]
setblock 340 273 208 minecraft:light[level=12]
setblock 340 273 216 minecraft:light[level=12]
setblock 348 273 184 minecraft:light[level=12]
setblock 348 273 192 minecraft:light[level=12]
setblock 348 273 200 minecraft:light[level=12]
setblock 348 273 208 minecraft:light[level=12]
setblock 348 273 216 minecraft:light[level=12]
setblock 356 273 184 minecraft:light[level=12]
setblock 356 273 192 minecraft:light[level=12]
setblock 356 273 200 minecraft:light[level=12]
setblock 356 273 208 minecraft:light[level=12]
setblock 356 273 216 minecraft:light[level=12]
setblock 364 273 184 minecraft:light[level=12]
setblock 364 273 192 minecraft:light[level=12]
setblock 364 273 200 minecraft:light[level=12]
setblock 364 273 208 minecraft:light[level=12]
setblock 364 273 216 minecraft:light[level=12]
fill 340 278 198 348 278 206 minecraft:bone_block
fill 341 278 196 351 278 197 minecraft:bone_block
fill 341 278 207 363 279 208 minecraft:bone_block
fill 342 278 195 362 279 195 minecraft:bone_block
fill 342 278 209 362 279 209 minecraft:bone_block
fill 343 278 194 361 279 194 minecraft:bone_block
fill 343 278 210 361 279 210 minecraft:bone_block
fill 344 278 193 360 279 193 minecraft:bone_block
fill 344 278 211 360 279 211 minecraft:bone_block
fill 345 278 186 359 278 192 minecraft:bone_block
fill 345 278 212 359 279 212 minecraft:bone_block
fill 347 278 213 357 279 213 minecraft:bone_block
fill 349 278 198 349 278 199 minecraft:bone_block
fill 349 278 201 349 278 206 minecraft:bone_block
fill 350 278 203 351 278 206 minecraft:bone_block
fill 350 278 214 354 279 214 minecraft:bone_block
fill 352 278 196 363 278 196 minecraft:bone_block
fill 352 278 204 364 278 206 minecraft:bone_block
fill 353 278 197 363 278 197 minecraft:bone_block
fill 353 278 203 364 278 203 minecraft:bone_block
fill 355 278 198 364 278 199 minecraft:bone_block
fill 355 278 201 364 278 202 minecraft:bone_block
fill 356 278 200 364 278 200 minecraft:bone_block
fill 330 279 182 339 279 222 minecraft:smooth_basalt
fill 340 279 182 340 279 197 minecraft:smooth_basalt
fill 340 279 198 343 279 206 minecraft:bone_block
fill 340 279 207 340 279 222 minecraft:smooth_basalt
fill 341 279 182 341 279 195 minecraft:smooth_basalt
fill 341 279 196 348 279 197 minecraft:bone_block
fill 341 279 209 341 279 222 minecraft:smooth_basalt
fill 342 279 182 342 279 194 minecraft:smooth_basalt
fill 342 279 210 342 279 222 minecraft:smooth_basalt
fill 343 279 182 343 279 193 minecraft:smooth_basalt
fill 343 279 211 343 279 222 minecraft:smooth_basalt
fill 344 279 182 344 279 192 minecraft:smooth_basalt
fill 344 279 198 344 279 202 minecraft:bone_block
fill 344 279 203 351 279 203 minecraft:ochre_froglight
fill 344 279 204 344 279 206 minecraft:bone_block
fill 344 279 212 344 279 222 minecraft:smooth_basalt
fill 345 279 182 370 279 185 minecraft:smooth_basalt
fill 345 279 186 359 279 190 minecraft:bone_block
fill 345 279 191 345 279 192 minecraft:black_concrete
fill 345 279 198 345 279 200 minecraft:bone_block
fill 345 279 201 349 279 202 minecraft:ochre_froglight
fill 345 279 204 349 279 204 minecraft:ochre_froglight
fill 345 279 205 345 279 206 minecraft:bone_block
fill 345 279 213 346 279 222 minecraft:smooth_basalt
fill 346 279 191 346 279 192 minecraft:bone_block
fill 346 279 198 347 279 199 minecraft:bone_block
fill 346 279 200 348 279 200 minecraft:ochre_froglight
fill 346 279 205 348 279 205 minecraft:ochre_froglight
fill 346 279 206 364 279 206 minecraft:bone_block
fill 347 279 191 347 279 192 minecraft:black_concrete
fill 347 279 214 349 279 222 minecraft:smooth_basalt
fill 348 279 191 348 279 192 minecraft:bone_block
setblock 348 279 198 minecraft:bone_block
fill 348 279 199 349 279 199 minecraft:ochre_froglight
fill 349 279 191 349 279 192 minecraft:black_concrete
fill 349 279 196 350 279 196 minecraft:bone_block
fill 349 279 197 349 279 198 minecraft:ochre_froglight
fill 349 279 205 355 279 205 minecraft:bone_block
fill 350 279 191 350 279 192 minecraft:bone_block
fill 350 279 197 351 279 197 minecraft:ochre_froglight
setblock 350 279 204 minecraft:bone_block
fill 350 279 215 370 279 222 minecraft:smooth_basalt
fill 351 279 191 351 279 192 minecraft:black_concrete
fill 351 279 196 353 279 196 minecraft:ochre_froglight
fill 351 279 204 353 279 204 minecraft:ochre_froglight
fill 352 279 191 352 279 192 minecraft:bone_block
fill 353 279 191 353 279 192 minecraft:black_concrete
fill 353 279 197 355 279 197 minecraft:ochre_froglight
fill 353 279 203 360 279 203 minecraft:ochre_froglight
fill 354 279 191 354 279 192 minecraft:bone_block
fill 354 279 196 363 279 196 minecraft:bone_block
setblock 354 279 204 minecraft:bone_block
fill 355 279 191 355 279 192 minecraft:black_concrete
fill 355 279 198 355 279 199 minecraft:ochre_froglight
fill 355 279 201 359 279 202 minecraft:ochre_froglight
fill 355 279 204 359 279 204 minecraft:ochre_froglight
fill 355 279 214 370 279 214 minecraft:smooth_basalt
fill 356 279 191 356 279 192 minecraft:bone_block
fill 356 279 197 363 279 198 minecraft:bone_block
fill 356 279 199 356 279 200 minecraft:ochre_froglight
fill 356 279 205 358 279 205 minecraft:ochre_froglight
fill 357 279 191 357 279 192 minecraft:black_concrete
fill 357 279 199 364 279 199 minecraft:bone_block
fill 357 279 200 358 279 200 minecraft:ochre_froglight
fill 358 279 191 358 279 192 minecraft:bone_block
fill 358 279 213 370 279 213 minecraft:smooth_basalt
fill 359 279 191 359 279 192 minecraft:black_concrete
fill 359 279 200 364 279 200 minecraft:bone_block
fill 359 279 205 364 279 205 minecraft:bone_block
fill 360 279 186 370 279 192 minecraft:smooth_basalt
fill 360 279 201 364 279 202 minecraft:bone_block
fill 360 279 204 364 279 204 minecraft:bone_block
fill 360 279 212 370 279 212 minecraft:smooth_basalt
fill 361 279 193 370 279 193 minecraft:smooth_basalt
fill 361 279 203 364 279 203 minecraft:bone_block
fill 361 279 211 370 279 211 minecraft:smooth_basalt
fill 362 279 194 370 279 194 minecraft:smooth_basalt
fill 362 279 210 370 279 210 minecraft:smooth_basalt
fill 363 279 195 370 279 195 minecraft:smooth_basalt
fill 363 279 209 370 279 209 minecraft:smooth_basalt
fill 364 279 196 370 279 197 minecraft:smooth_basalt
setblock 364 279 198 minecraft:bone_block
fill 364 279 207 370 279 208 minecraft:smooth_basalt
fill 365 279 198 370 279 206 minecraft:smooth_basalt
setblock 332 281 184 minecraft:light[level=12]
setblock 332 281 192 minecraft:light[level=12]
setblock 332 281 200 minecraft:light[level=12]
setblock 332 281 208 minecraft:light[level=12]
setblock 332 281 216 minecraft:light[level=12]
setblock 340 281 184 minecraft:light[level=12]
setblock 340 281 192 minecraft:light[level=12]
setblock 340 281 200 minecraft:light[level=12]
setblock 340 281 208 minecraft:light[level=12]
setblock 340 281 216 minecraft:light[level=12]
setblock 348 281 184 minecraft:light[level=12]
setblock 348 281 192 minecraft:light[level=12]
setblock 348 281 200 minecraft:light[level=12]
setblock 348 281 208 minecraft:light[level=12]
setblock 348 281 216 minecraft:light[level=12]
setblock 356 281 184 minecraft:light[level=12]
setblock 356 281 192 minecraft:light[level=12]
setblock 356 281 200 minecraft:light[level=12]
setblock 356 281 208 minecraft:light[level=12]
setblock 356 281 216 minecraft:light[level=12]
setblock 364 281 184 minecraft:light[level=12]
setblock 364 281 192 minecraft:light[level=12]
setblock 364 281 200 minecraft:light[level=12]
setblock 364 281 208 minecraft:light[level=12]
setblock 364 281 216 minecraft:light[level=12]
fill 330 288 182 332 288 182 minecraft:polished_basalt
fill 330 288 184 330 288 186 minecraft:polished_basalt
fill 330 288 188 330 288 190 minecraft:polished_basalt
fill 330 288 192 330 288 194 minecraft:polished_basalt
fill 330 288 196 330 288 198 minecraft:polished_basalt
fill 330 288 200 330 288 202 minecraft:polished_basalt
fill 330 288 204 330 288 206 minecraft:polished_basalt
fill 330 288 208 330 288 210 minecraft:polished_basalt
fill 330 288 212 330 288 214 minecraft:polished_basalt
fill 330 288 216 330 288 218 minecraft:polished_basalt
fill 330 288 220 330 288 222 minecraft:polished_basalt
fill 332 288 222 334 288 222 minecraft:polished_basalt
fill 334 288 182 336 288 182 minecraft:polished_basalt
fill 336 288 222 338 288 222 minecraft:polished_basalt
fill 338 288 182 340 288 182 minecraft:polished_basalt
fill 340 288 222 342 288 222 minecraft:polished_basalt
fill 342 288 182 344 288 182 minecraft:polished_basalt
fill 344 288 222 346 288 222 minecraft:polished_basalt
fill 346 288 182 348 288 182 minecraft:polished_basalt
fill 348 288 222 350 288 222 minecraft:polished_basalt
fill 350 288 182 352 288 182 minecraft:polished_basalt
fill 352 288 222 354 288 222 minecraft:polished_basalt
fill 354 288 182 356 288 182 minecraft:polished_basalt
fill 356 288 222 358 288 222 minecraft:polished_basalt
fill 358 288 182 360 288 182 minecraft:polished_basalt
fill 360 288 222 362 288 222 minecraft:polished_basalt
fill 362 288 182 364 288 182 minecraft:polished_basalt
fill 364 288 222 366 288 222 minecraft:polished_basalt
fill 366 288 182 368 288 182 minecraft:polished_basalt
fill 368 288 222 370 288 222 minecraft:polished_basalt
fill 370 288 182 370 288 184 minecraft:polished_basalt
fill 370 288 186 370 288 188 minecraft:polished_basalt
fill 370 288 190 370 288 192 minecraft:polished_basalt
fill 370 288 194 370 288 196 minecraft:polished_basalt
fill 370 288 198 370 288 200 minecraft:polished_basalt
fill 370 288 202 370 288 204 minecraft:polished_basalt
fill 370 288 206 370 288 208 minecraft:polished_basalt
fill 370 288 210 370 288 212 minecraft:polished_basalt
fill 370 288 214 370 288 216 minecraft:polished_basalt
fill 370 288 218 370 288 220 minecraft:polished_basalt
setblock 332 289 184 minecraft:light[level=12]
setblock 332 289 192 minecraft:light[level=12]
setblock 332 289 200 minecraft:light[level=12]
setblock 332 289 208 minecraft:light[level=12]
setblock 332 289 216 minecraft:light[level=12]
setblock 340 289 184 minecraft:light[level=12]
setblock 340 289 192 minecraft:light[level=12]
setblock 340 289 200 minecraft:light[level=12]
setblock 340 289 208 minecraft:light[level=12]
setblock 340 289 216 minecraft:light[level=12]
setblock 348 289 184 minecraft:light[level=12]
setblock 348 289 192 minecraft:light[level=12]
setblock 348 289 200 minecraft:light[level=12]
setblock 348 289 208 minecraft:light[level=12]
setblock 348 289 216 minecraft:light[level=12]
setblock 356 289 184 minecraft:light[level=12]
setblock 356 289 192 minecraft:light[level=12]
setblock 356 289 200 minecraft:light[level=12]
setblock 356 289 208 minecraft:light[level=12]
setblock 356 289 216 minecraft:light[level=12]
setblock 364 289 184 minecraft:light[level=12]
setblock 364 289 192 minecraft:light[level=12]
setblock 364 289 200 minecraft:light[level=12]
setblock 364 289 208 minecraft:light[level=12]
setblock 364 289 216 minecraft:light[level=12]
fill 330 294 182 332 294 182 minecraft:polished_basalt
fill 330 294 184 330 294 186 minecraft:polished_basalt
fill 330 294 188 330 294 190 minecraft:polished_basalt
fill 330 294 192 330 294 194 minecraft:polished_basalt
fill 330 294 196 330 294 198 minecraft:polished_basalt
fill 330 294 200 330 294 202 minecraft:polished_basalt
fill 330 294 204 330 294 206 minecraft:polished_basalt
fill 330 294 208 330 294 210 minecraft:polished_basalt
fill 330 294 212 330 294 214 minecraft:polished_basalt
fill 330 294 216 330 294 218 minecraft:polished_basalt
fill 330 294 220 330 294 222 minecraft:polished_basalt
fill 332 294 222 334 294 222 minecraft:polished_basalt
fill 334 294 182 336 294 182 minecraft:polished_basalt
fill 336 294 222 338 294 222 minecraft:polished_basalt
fill 338 294 182 340 294 182 minecraft:polished_basalt
fill 340 294 222 342 294 222 minecraft:polished_basalt
fill 342 294 182 344 294 182 minecraft:polished_basalt
fill 344 294 222 346 294 222 minecraft:polished_basalt
fill 346 294 182 348 294 182 minecraft:polished_basalt
fill 348 294 222 350 294 222 minecraft:polished_basalt
fill 350 294 182 352 294 182 minecraft:polished_basalt
fill 352 294 222 354 294 222 minecraft:polished_basalt
fill 354 294 182 356 294 182 minecraft:polished_basalt
fill 356 294 222 358 294 222 minecraft:polished_basalt
fill 358 294 182 360 294 182 minecraft:polished_basalt
fill 360 294 222 362 294 222 minecraft:polished_basalt
fill 362 294 182 364 294 182 minecraft:polished_basalt
fill 364 294 222 366 294 222 minecraft:polished_basalt
fill 366 294 182 368 294 182 minecraft:polished_basalt
fill 368 294 222 370 294 222 minecraft:polished_basalt
fill 370 294 182 370 294 184 minecraft:polished_basalt
fill 370 294 186 370 294 188 minecraft:polished_basalt
fill 370 294 190 370 294 192 minecraft:polished_basalt
fill 370 294 194 370 294 196 minecraft:polished_basalt
fill 370 294 198 370 294 200 minecraft:polished_basalt
fill 370 294 202 370 294 204 minecraft:polished_basalt
fill 370 294 206 370 294 208 minecraft:polished_basalt
fill 370 294 210 370 294 212 minecraft:polished_basalt
fill 370 294 214 370 294 216 minecraft:polished_basalt
fill 370 294 218 370 294 220 minecraft:polished_basalt
setblock 332 297 184 minecraft:light[level=12]
setblock 332 297 192 minecraft:light[level=12]
setblock 332 297 200 minecraft:light[level=12]
setblock 332 297 208 minecraft:light[level=12]
setblock 332 297 216 minecraft:light[level=12]
setblock 340 297 184 minecraft:light[level=12]
setblock 340 297 192 minecraft:light[level=12]
setblock 340 297 200 minecraft:light[level=12]
setblock 340 297 208 minecraft:light[level=12]
setblock 340 297 216 minecraft:light[level=12]
setblock 348 297 184 minecraft:light[level=12]
setblock 348 297 192 minecraft:light[level=12]
setblock 348 297 200 minecraft:light[level=12]
setblock 348 297 208 minecraft:light[level=12]
setblock 348 297 216 minecraft:light[level=12]
setblock 356 297 184 minecraft:light[level=12]
setblock 356 297 192 minecraft:light[level=12]
setblock 356 297 200 minecraft:light[level=12]
setblock 356 297 208 minecraft:light[level=12]
setblock 356 297 216 minecraft:light[level=12]
setblock 364 297 184 minecraft:light[level=12]
setblock 364 297 192 minecraft:light[level=12]
setblock 364 297 200 minecraft:light[level=12]
setblock 364 297 208 minecraft:light[level=12]
setblock 364 297 216 minecraft:light[level=12]
fill 330 300 182 332 300 182 minecraft:polished_basalt
fill 330 300 184 330 300 186 minecraft:polished_basalt
fill 330 300 188 330 300 190 minecraft:polished_basalt
fill 330 300 192 330 300 194 minecraft:polished_basalt
fill 330 300 196 330 300 198 minecraft:polished_basalt
fill 330 300 200 330 300 202 minecraft:polished_basalt
fill 330 300 204 330 300 206 minecraft:polished_basalt
fill 330 300 208 330 300 210 minecraft:polished_basalt
fill 330 300 212 330 300 214 minecraft:polished_basalt
fill 330 300 216 330 300 218 minecraft:polished_basalt
schedule function dropper:buildpart/43_5 1t
