setblock 320 -22 208 minecraft:red_nether_bricks
setblock 320 -22 209 minecraft:polished_blackstone
fill 320 -22 210 320 -19 210 minecraft:red_nether_bricks
setblock 321 -22 183 minecraft:polished_blackstone
setblock 321 -22 203 minecraft:polished_blackstone
fill 321 -22 204 321 -19 204 minecraft:red_nether_bricks
setblock 321 -22 208 minecraft:polished_blackstone
fill 321 -22 209 321 -19 209 minecraft:red_nether_bricks
setblock 321 -22 212 minecraft:red_nether_bricks
setblock 322 -22 182 minecraft:polished_blackstone
fill 322 -22 183 322 -19 183 minecraft:red_nether_bricks
fill 322 -22 185 322 -22 186 minecraft:red_nether_bricks
setblock 322 -22 187 minecraft:polished_blackstone
fill 322 -22 188 322 -19 188 minecraft:red_nether_bricks
fill 322 -22 190 322 -22 191 minecraft:red_nether_bricks
fill 322 -22 198 322 -19 198 minecraft:red_nether_bricks
setblock 322 -22 202 minecraft:polished_blackstone
fill 322 -22 203 322 -19 203 minecraft:red_nether_bricks
setblock 322 -22 207 minecraft:polished_blackstone
fill 322 -22 208 322 -19 208 minecraft:red_nether_bricks
setblock 322 -22 212 minecraft:polished_blackstone
fill 322 -22 213 322 -20 214 minecraft:red_nether_bricks
setblock 322 -22 222 minecraft:polished_blackstone
fill 323 -22 182 323 -19 182 minecraft:red_nether_bricks
setblock 323 -22 186 minecraft:polished_blackstone
fill 323 -22 187 323 -19 187 minecraft:red_nether_bricks
setblock 323 -22 191 minecraft:polished_blackstone
fill 323 -22 192 323 -19 192 minecraft:red_nether_bricks
setblock 323 -22 196 minecraft:polished_blackstone
fill 323 -22 197 323 -19 197 minecraft:red_nether_bricks
setblock 323 -22 201 minecraft:polished_blackstone
fill 323 -22 202 323 -19 202 minecraft:red_nether_bricks
setblock 323 -22 206 minecraft:polished_blackstone
fill 323 -22 207 323 -19 207 minecraft:red_nether_bricks
setblock 323 -22 211 minecraft:polished_blackstone
fill 323 -22 212 323 -19 212 minecraft:red_nether_bricks
fill 283 -21 182 285 -21 182 minecraft:red_nether_bricks
setblock 283 -21 185 minecraft:polished_blackstone
fill 283 -21 186 283 -18 186 minecraft:red_nether_bricks
setblock 283 -21 190 minecraft:polished_blackstone
fill 283 -21 191 283 -21 194 minecraft:red_nether_bricks
setblock 283 -21 195 minecraft:polished_blackstone
fill 283 -21 196 283 -21 199 minecraft:red_nether_bricks
setblock 283 -21 200 minecraft:polished_blackstone
fill 283 -21 201 283 -18 201 minecraft:red_nether_bricks
setblock 283 -21 205 minecraft:polished_blackstone
fill 283 -21 206 283 -18 206 minecraft:red_nether_bricks
setblock 283 -21 210 minecraft:polished_blackstone
fill 283 -21 211 283 -18 211 minecraft:red_nether_bricks
fill 283 -21 213 283 -20 213 minecraft:red_nether_bricks
setblock 284 -21 184 minecraft:polished_blackstone
fill 284 -21 185 284 -18 185 minecraft:red_nether_bricks
setblock 284 -21 189 minecraft:polished_blackstone
fill 284 -21 190 284 -18 190 minecraft:red_nether_bricks
setblock 284 -21 194 minecraft:polished_blackstone
setblock 284 -21 204 minecraft:polished_blackstone
fill 284 -21 205 284 -20 205 minecraft:red_nether_bricks
setblock 284 -21 209 minecraft:polished_blackstone
setblock 285 -21 183 minecraft:polished_blackstone
setblock 285 -21 187 minecraft:red_nether_bricks
setblock 285 -21 188 minecraft:polished_blackstone
fill 285 -21 189 285 -18 189 minecraft:red_nether_bricks
setblock 286 -21 182 minecraft:polished_blackstone
fill 286 -21 183 286 -18 183 minecraft:red_nether_bricks
fill 287 -21 182 290 -21 182 minecraft:red_nether_bricks
setblock 289 -21 183 minecraft:red_nether_bricks
setblock 290 -21 183 minecraft:polished_blackstone
setblock 291 -21 182 minecraft:polished_blackstone
fill 291 -21 183 291 -18 183 minecraft:red_nether_bricks
fill 292 -21 182 295 -21 182 minecraft:red_nether_bricks
setblock 293 -21 184 minecraft:red_nether_bricks
setblock 294 -21 184 minecraft:polished_blackstone
fill 294 -21 222 295 -21 222 minecraft:red_nether_bricks
setblock 295 -21 183 minecraft:polished_blackstone
fill 295 -21 184 295 -18 184 minecraft:red_nether_bricks
setblock 296 -21 182 minecraft:polished_blackstone
fill 296 -21 183 296 -18 183 minecraft:red_nether_bricks
fill 296 -21 185 297 -21 185 minecraft:red_nether_bricks
setblock 296 -21 222 minecraft:polished_blackstone
fill 297 -21 182 297 -18 182 minecraft:red_nether_bricks
setblock 297 -21 221 minecraft:polished_blackstone
fill 297 -21 222 297 -18 222 minecraft:red_nether_bricks
setblock 298 -21 185 minecraft:polished_blackstone
fill 298 -21 221 298 -18 221 minecraft:red_nether_bricks
setblock 299 -21 184 minecraft:polished_blackstone
fill 299 -21 185 299 -18 185 minecraft:red_nether_bricks
setblock 300 -21 183 minecraft:polished_blackstone
fill 300 -21 184 300 -18 184 minecraft:red_nether_bricks
setblock 301 -21 182 minecraft:polished_blackstone
fill 301 -21 183 301 -18 183 minecraft:red_nether_bricks
setblock 301 -21 222 minecraft:polished_blackstone
fill 302 -21 182 302 -18 182 minecraft:red_nether_bricks
setblock 302 -21 221 minecraft:polished_blackstone
fill 302 -21 222 305 -21 222 minecraft:red_nether_bricks
fill 303 -21 221 303 -18 221 minecraft:red_nether_bricks
setblock 305 -21 183 minecraft:polished_blackstone
setblock 306 -21 182 minecraft:polished_blackstone
setblock 306 -21 222 minecraft:polished_blackstone
setblock 307 -21 182 minecraft:red_nether_bricks
fill 307 -21 222 307 -20 222 minecraft:red_nether_bricks
setblock 315 -21 182 minecraft:red_nether_bricks
setblock 315 -21 222 minecraft:red_nether_bricks
setblock 316 -21 182 minecraft:polished_blackstone
setblock 316 -21 222 minecraft:polished_blackstone
fill 317 -21 182 317 -18 182 minecraft:red_nether_bricks
fill 317 -21 222 317 -18 222 minecraft:red_nether_bricks
fill 318 -21 183 318 -20 183 minecraft:red_nether_bricks
setblock 320 -21 182 minecraft:red_nether_bricks
setblock 320 -21 183 minecraft:polished_blackstone
fill 320 -21 204 320 -19 204 minecraft:red_nether_bricks
setblock 320 -21 208 minecraft:polished_blackstone
fill 320 -21 209 320 -18 209 minecraft:red_nether_bricks
fill 320 -21 211 320 -20 211 minecraft:red_nether_bricks
setblock 321 -21 182 minecraft:polished_blackstone
fill 321 -21 183 321 -18 183 minecraft:red_nether_bricks
setblock 321 -21 202 minecraft:polished_blackstone
fill 321 -21 203 321 -18 203 minecraft:red_nether_bricks
setblock 321 -21 207 minecraft:polished_blackstone
fill 321 -21 208 321 -18 208 minecraft:red_nether_bricks
setblock 321 -21 212 minecraft:polished_blackstone
fill 321 -21 213 321 -18 213 minecraft:red_nether_bricks
setblock 321 -21 222 minecraft:polished_blackstone
fill 322 -21 182 322 -18 182 minecraft:red_nether_bricks
setblock 322 -21 185 minecraft:red_nether_bricks
setblock 322 -21 186 minecraft:polished_blackstone
fill 322 -21 187 322 -18 187 minecraft:red_nether_bricks
setblock 322 -21 190 minecraft:red_nether_bricks
setblock 322 -21 191 minecraft:polished_blackstone
fill 322 -21 192 322 -21 195 minecraft:red_nether_bricks
setblock 322 -21 196 minecraft:polished_blackstone
fill 322 -21 197 322 -18 197 minecraft:red_nether_bricks
setblock 322 -21 201 minecraft:polished_blackstone
fill 322 -21 202 322 -18 202 minecraft:red_nether_bricks
setblock 322 -21 206 minecraft:polished_blackstone
fill 322 -21 207 322 -18 207 minecraft:red_nether_bricks
setblock 322 -21 211 minecraft:polished_blackstone
fill 322 -21 212 322 -18 212 minecraft:red_nether_bricks
setblock 323 -21 185 minecraft:polished_blackstone
fill 323 -21 186 323 -18 186 minecraft:red_nether_bricks
setblock 323 -21 190 minecraft:polished_blackstone
fill 323 -21 191 323 -18 191 minecraft:red_nether_bricks
setblock 323 -21 195 minecraft:polished_blackstone
fill 323 -21 196 323 -18 196 minecraft:red_nether_bricks
setblock 323 -21 200 minecraft:polished_blackstone
fill 323 -21 201 323 -18 201 minecraft:red_nether_bricks
setblock 323 -21 205 minecraft:polished_blackstone
fill 323 -21 206 323 -18 206 minecraft:red_nether_bricks
setblock 323 -21 210 minecraft:polished_blackstone
fill 323 -21 211 323 -18 211 minecraft:red_nether_bricks
setblock 323 -21 215 minecraft:polished_blackstone
fill 323 -21 216 323 -18 216 minecraft:red_nether_bricks
fill 283 -20 182 284 -20 182 minecraft:red_nether_bricks
setblock 283 -20 184 minecraft:polished_blackstone
fill 283 -20 185 283 -17 185 minecraft:red_nether_bricks
setblock 283 -20 189 minecraft:polished_blackstone
fill 283 -20 190 283 -20 193 minecraft:red_nether_bricks
setblock 283 -20 194 minecraft:polished_blackstone
fill 283 -20 195 283 -20 198 minecraft:red_nether_bricks
setblock 283 -20 199 minecraft:polished_blackstone
fill 283 -20 200 283 -17 200 minecraft:red_nether_bricks
setblock 283 -20 204 minecraft:polished_blackstone
fill 283 -20 205 283 -17 205 minecraft:red_nether_bricks
setblock 283 -20 209 minecraft:polished_blackstone
fill 283 -20 210 283 -17 210 minecraft:red_nether_bricks
setblock 283 -20 214 minecraft:polished_blackstone
setblock 284 -20 183 minecraft:polished_blackstone
fill 284 -20 184 284 -17 184 minecraft:red_nether_bricks
setblock 284 -20 188 minecraft:polished_blackstone
fill 284 -20 189 284 -17 189 minecraft:red_nether_bricks
setblock 284 -20 193 minecraft:polished_blackstone
fill 284 -20 194 284 -17 194 minecraft:red_nether_bricks
setblock 284 -20 204 minecraft:red_nether_bricks
setblock 284 -20 208 minecraft:polished_blackstone
fill 284 -20 209 284 -19 209 minecraft:red_nether_bricks
setblock 285 -20 182 minecraft:polished_blackstone
fill 285 -20 183 285 -18 183 minecraft:red_nether_bricks
setblock 285 -20 184 minecraft:light[level=14]
setblock 285 -20 187 minecraft:polished_blackstone
fill 285 -20 188 285 -17 188 minecraft:red_nether_bricks
fill 285 -20 190 285 -19 190 minecraft:red_nether_bricks
setblock 285 -20 192 minecraft:light[level=14]
setblock 285 -20 200 minecraft:light[level=14]
setblock 285 -20 208 minecraft:light[level=14]
setblock 285 -20 216 minecraft:light[level=14]
fill 286 -20 182 289 -20 182 minecraft:red_nether_bricks
setblock 289 -20 183 minecraft:polished_blackstone
setblock 290 -20 182 minecraft:polished_blackstone
fill 290 -20 183 290 -17 183 minecraft:red_nether_bricks
fill 291 -20 182 294 -20 182 minecraft:red_nether_bricks
setblock 292 -20 184 minecraft:red_nether_bricks
setblock 293 -20 184 minecraft:polished_blackstone
setblock 293 -20 192 minecraft:light[level=14]
setblock 293 -20 200 minecraft:light[level=14]
setblock 293 -20 208 minecraft:light[level=14]
setblock 293 -20 216 minecraft:light[level=14]
fill 293 -20 222 294 -20 222 minecraft:red_nether_bricks
setblock 294 -20 183 minecraft:polished_blackstone
fill 294 -20 184 294 -17 184 minecraft:red_nether_bricks
setblock 295 -20 182 minecraft:polished_blackstone
fill 295 -20 183 295 -17 183 minecraft:red_nether_bricks
fill 295 -20 185 296 -20 185 minecraft:red_nether_bricks
setblock 295 -20 222 minecraft:polished_blackstone
fill 296 -20 182 296 -17 182 minecraft:red_nether_bricks
setblock 296 -20 221 minecraft:polished_blackstone
fill 296 -20 222 296 -17 222 minecraft:red_nether_bricks
setblock 297 -20 185 minecraft:polished_blackstone
fill 297 -20 221 297 -17 221 minecraft:red_nether_bricks
setblock 298 -20 184 minecraft:polished_blackstone
fill 298 -20 185 298 -17 185 minecraft:red_nether_bricks
setblock 299 -20 183 minecraft:polished_blackstone
fill 299 -20 184 299 -17 184 minecraft:red_nether_bricks
setblock 300 -20 182 minecraft:polished_blackstone
fill 300 -20 183 300 -17 183 minecraft:red_nether_bricks
setblock 300 -20 222 minecraft:polished_blackstone
fill 301 -20 182 301 -17 182 minecraft:red_nether_bricks
setblock 301 -20 192 minecraft:light[level=14]
setblock 301 -20 200 minecraft:light[level=14]
setblock 301 -20 208 minecraft:light[level=14]
setblock 301 -20 216 minecraft:light[level=14]
setblock 301 -20 221 minecraft:polished_blackstone
fill 301 -20 222 304 -20 222 minecraft:red_nether_bricks
fill 302 -20 221 302 -17 221 minecraft:red_nether_bricks
setblock 303 -20 184 minecraft:polished_blackstone
setblock 304 -20 183 minecraft:polished_blackstone
setblock 305 -20 182 minecraft:polished_blackstone
setblock 305 -20 183 minecraft:red_nether_bricks
setblock 305 -20 222 minecraft:polished_blackstone
fill 306 -20 182 306 -19 182 minecraft:red_nether_bricks
fill 306 -20 222 306 -18 222 minecraft:red_nether_bricks
setblock 309 -20 184 minecraft:light[level=14]
setblock 309 -20 192 minecraft:light[level=14]
setblock 309 -20 200 minecraft:light[level=14]
setblock 309 -20 208 minecraft:light[level=14]
setblock 309 -20 216 minecraft:light[level=14]
setblock 315 -20 182 minecraft:polished_blackstone
setblock 315 -20 222 minecraft:polished_blackstone
fill 316 -20 182 316 -17 182 minecraft:red_nether_bricks
fill 316 -20 222 316 -17 222 minecraft:red_nether_bricks
fill 317 -20 183 317 -19 183 minecraft:red_nether_bricks
setblock 317 -20 184 minecraft:light[level=14]
setblock 317 -20 192 minecraft:light[level=14]
setblock 317 -20 200 minecraft:light[level=14]
setblock 317 -20 208 minecraft:light[level=14]
setblock 317 -20 216 minecraft:light[level=14]
setblock 319 -20 183 minecraft:polished_blackstone
setblock 319 -20 208 minecraft:polished_blackstone
setblock 320 -20 182 minecraft:polished_blackstone
fill 320 -20 183 320 -18 183 minecraft:red_nether_bricks
setblock 320 -20 207 minecraft:polished_blackstone
fill 320 -20 208 320 -17 208 minecraft:red_nether_bricks
setblock 320 -20 212 minecraft:polished_blackstone
setblock 320 -20 222 minecraft:polished_blackstone
fill 321 -20 182 321 -17 182 minecraft:red_nether_bricks
setblock 321 -20 186 minecraft:polished_blackstone
fill 321 -20 187 321 -20 190 minecraft:red_nether_bricks
setblock 321 -20 191 minecraft:polished_blackstone
setblock 321 -20 201 minecraft:polished_blackstone
fill 321 -20 202 321 -18 202 minecraft:red_nether_bricks
setblock 321 -20 206 minecraft:polished_blackstone
fill 321 -20 207 321 -17 207 minecraft:red_nether_bricks
setblock 321 -20 211 minecraft:polished_blackstone
fill 321 -20 212 321 -17 212 minecraft:red_nether_bricks
fill 321 -20 222 321 -19 222 minecraft:red_nether_bricks
setblock 322 -20 185 minecraft:polished_blackstone
fill 322 -20 186 322 -17 186 minecraft:red_nether_bricks
setblock 322 -20 190 minecraft:polished_blackstone
fill 322 -20 191 322 -20 194 minecraft:red_nether_bricks
setblock 322 -20 195 minecraft:polished_blackstone
fill 322 -20 196 322 -17 196 minecraft:red_nether_bricks
setblock 322 -20 200 minecraft:polished_blackstone
fill 322 -20 201 322 -17 201 minecraft:red_nether_bricks
setblock 322 -20 205 minecraft:polished_blackstone
fill 322 -20 206 322 -17 206 minecraft:red_nether_bricks
setblock 322 -20 210 minecraft:polished_blackstone
fill 322 -20 211 322 -17 211 minecraft:red_nether_bricks
setblock 322 -20 215 minecraft:polished_blackstone
setblock 323 -20 184 minecraft:polished_blackstone
fill 323 -20 185 323 -17 185 minecraft:red_nether_bricks
setblock 323 -20 189 minecraft:polished_blackstone
fill 323 -20 190 323 -17 190 minecraft:red_nether_bricks
setblock 323 -20 194 minecraft:polished_blackstone
fill 323 -20 195 323 -17 195 minecraft:red_nether_bricks
setblock 323 -20 199 minecraft:polished_blackstone
fill 323 -20 200 323 -17 200 minecraft:red_nether_bricks
setblock 323 -20 204 minecraft:polished_blackstone
fill 323 -20 205 323 -17 205 minecraft:red_nether_bricks
setblock 323 -20 209 minecraft:polished_blackstone
fill 323 -20 210 323 -17 210 minecraft:red_nether_bricks
setblock 323 -20 214 minecraft:polished_blackstone
fill 323 -20 215 323 -17 215 minecraft:red_nether_bricks
setblock 283 -19 182 minecraft:red_nether_bricks
setblock 283 -19 183 minecraft:polished_blackstone
fill 283 -19 184 283 -16 184 minecraft:red_nether_bricks
setblock 283 -19 188 minecraft:polished_blackstone
fill 283 -19 189 283 -19 192 minecraft:red_nether_bricks
setblock 283 -19 193 minecraft:polished_blackstone
fill 283 -19 194 283 -19 197 minecraft:red_nether_bricks
setblock 283 -19 198 minecraft:polished_blackstone
fill 283 -19 199 283 -16 199 minecraft:red_nether_bricks
setblock 283 -19 203 minecraft:polished_blackstone
fill 283 -19 204 283 -17 204 minecraft:red_nether_bricks
setblock 283 -19 208 minecraft:polished_blackstone
fill 283 -19 209 283 -16 209 minecraft:red_nether_bricks
setblock 283 -19 213 minecraft:polished_blackstone
fill 283 -19 214 283 -16 214 minecraft:red_nether_bricks
setblock 284 -19 182 minecraft:polished_blackstone
fill 284 -19 183 284 -17 183 minecraft:red_nether_bricks
setblock 284 -19 187 minecraft:polished_blackstone
fill 284 -19 188 284 -16 188 minecraft:red_nether_bricks
setblock 284 -19 192 minecraft:polished_blackstone
fill 284 -19 193 284 -16 193 minecraft:red_nether_bricks
fill 284 -19 195 284 -18 195 minecraft:red_nether_bricks
setblock 284 -19 207 minecraft:polished_blackstone
setblock 284 -19 208 minecraft:red_nether_bricks
fill 285 -19 182 288 -19 182 minecraft:red_nether_bricks
setblock 285 -19 186 minecraft:polished_blackstone
fill 285 -19 187 285 -16 187 minecraft:red_nether_bricks
setblock 285 -19 191 minecraft:polished_blackstone
setblock 288 -19 183 minecraft:polished_blackstone
setblock 289 -19 182 minecraft:polished_blackstone
fill 289 -19 183 289 -17 183 minecraft:red_nether_bricks
fill 290 -19 182 293 -19 182 minecraft:red_nether_bricks
setblock 292 -19 184 minecraft:polished_blackstone
setblock 293 -19 183 minecraft:polished_blackstone
fill 293 -19 184 293 -16 184 minecraft:red_nether_bricks
setblock 293 -19 222 minecraft:red_nether_bricks
setblock 294 -19 182 minecraft:polished_blackstone
fill 294 -19 183 294 -16 183 minecraft:red_nether_bricks
setblock 294 -19 222 minecraft:polished_blackstone
fill 295 -19 182 295 -16 182 minecraft:red_nether_bricks
setblock 295 -19 185 minecraft:red_nether_bricks
setblock 295 -19 221 minecraft:polished_blackstone
fill 295 -19 222 295 -16 222 minecraft:red_nether_bricks
setblock 296 -19 185 minecraft:polished_blackstone
fill 296 -19 221 296 -16 221 minecraft:red_nether_bricks
setblock 297 -19 184 minecraft:polished_blackstone
fill 297 -19 185 297 -17 185 minecraft:red_nether_bricks
setblock 298 -19 183 minecraft:polished_blackstone
fill 298 -19 184 298 -16 184 minecraft:red_nether_bricks
setblock 299 -19 182 minecraft:polished_blackstone
fill 299 -19 183 299 -16 183 minecraft:red_nether_bricks
setblock 299 -19 222 minecraft:polished_blackstone
fill 300 -19 182 300 -16 182 minecraft:red_nether_bricks
setblock 300 -19 221 minecraft:polished_blackstone
fill 300 -19 222 303 -19 222 minecraft:red_nether_bricks
fill 301 -19 221 301 -16 221 minecraft:red_nether_bricks
setblock 302 -19 184 minecraft:polished_blackstone
setblock 303 -19 183 minecraft:polished_blackstone
setblock 304 -19 182 minecraft:polished_blackstone
setblock 304 -19 183 minecraft:red_nether_bricks
setblock 304 -19 222 minecraft:polished_blackstone
fill 305 -19 182 305 -18 182 minecraft:red_nether_bricks
fill 305 -19 222 305 -17 222 minecraft:red_nether_bricks
setblock 314 -19 182 minecraft:polished_blackstone
setblock 314 -19 222 minecraft:polished_blackstone
fill 315 -19 182 315 -16 182 minecraft:red_nether_bricks
fill 315 -19 222 315 -16 222 minecraft:red_nether_bricks
setblock 318 -19 183 minecraft:polished_blackstone
setblock 319 -19 182 minecraft:polished_blackstone
fill 319 -19 183 319 -17 183 minecraft:red_nether_bricks
setblock 319 -19 207 minecraft:polished_blackstone
fill 319 -19 208 319 -18 209 minecraft:red_nether_bricks
setblock 319 -19 222 minecraft:polished_blackstone
fill 320 -19 182 320 -16 182 minecraft:red_nether_bricks
setblock 320 -19 206 minecraft:polished_blackstone
fill 320 -19 207 320 -17 207 minecraft:red_nether_bricks
setblock 320 -19 211 minecraft:polished_blackstone
fill 320 -19 212 320 -16 212 minecraft:red_nether_bricks
fill 320 -19 222 320 -18 222 minecraft:red_nether_bricks
fill 321 -19 186 321 -19 189 minecraft:red_nether_bricks
setblock 321 -19 190 minecraft:polished_blackstone
fill 321 -19 191 322 -19 193 minecraft:red_nether_bricks
setblock 321 -19 201 minecraft:red_nether_bricks
setblock 321 -19 205 minecraft:polished_blackstone
fill 321 -19 206 321 -16 206 minecraft:red_nether_bricks
setblock 321 -19 210 minecraft:polished_blackstone
fill 321 -19 211 321 -16 211 minecraft:red_nether_bricks
setblock 321 -19 214 minecraft:red_nether_bricks
setblock 322 -19 184 minecraft:polished_blackstone
fill 322 -19 185 322 -16 185 minecraft:red_nether_bricks
setblock 322 -19 189 minecraft:polished_blackstone
fill 322 -19 190 322 -16 190 minecraft:red_nether_bricks
setblock 322 -19 194 minecraft:polished_blackstone
fill 322 -19 195 322 -16 195 minecraft:red_nether_bricks
setblock 322 -19 199 minecraft:polished_blackstone
fill 322 -19 200 322 -16 200 minecraft:red_nether_bricks
setblock 322 -19 204 minecraft:polished_blackstone
fill 322 -19 205 322 -16 205 minecraft:red_nether_bricks
setblock 322 -19 209 minecraft:polished_blackstone
fill 322 -19 210 322 -16 210 minecraft:red_nether_bricks
setblock 322 -19 213 minecraft:red_nether_bricks
setblock 322 -19 214 minecraft:polished_blackstone
fill 322 -19 215 322 -16 215 minecraft:red_nether_bricks
setblock 323 -19 183 minecraft:polished_blackstone
fill 323 -19 184 323 -16 184 minecraft:red_nether_bricks
setblock 323 -19 188 minecraft:polished_blackstone
fill 323 -19 189 323 -16 189 minecraft:red_nether_bricks
setblock 323 -19 193 minecraft:polished_blackstone
fill 323 -19 194 323 -16 194 minecraft:red_nether_bricks
setblock 323 -19 198 minecraft:polished_blackstone
fill 323 -19 199 323 -16 199 minecraft:red_nether_bricks
setblock 323 -19 203 minecraft:polished_blackstone
fill 323 -19 204 323 -16 204 minecraft:red_nether_bricks
setblock 323 -19 208 minecraft:polished_blackstone
fill 323 -19 209 323 -16 209 minecraft:red_nether_bricks
setblock 323 -19 213 minecraft:polished_blackstone
fill 323 -19 214 323 -16 214 minecraft:red_nether_bricks
setblock 283 -18 182 minecraft:polished_blackstone
fill 283 -18 183 283 -15 183 minecraft:red_nether_bricks
setblock 283 -18 187 minecraft:polished_blackstone
fill 283 -18 188 283 -18 191 minecraft:red_nether_bricks
setblock 283 -18 192 minecraft:polished_blackstone
fill 283 -18 193 283 -18 196 minecraft:red_nether_bricks
setblock 283 -18 197 minecraft:polished_blackstone
fill 283 -18 198 283 -15 198 minecraft:red_nether_bricks
setblock 283 -18 202 minecraft:polished_blackstone
fill 283 -18 203 283 -17 203 minecraft:red_nether_bricks
setblock 283 -18 207 minecraft:polished_blackstone
fill 283 -18 208 283 -16 208 minecraft:red_nether_bricks
setblock 283 -18 212 minecraft:polished_blackstone
fill 283 -18 213 283 -15 213 minecraft:red_nether_bricks
fill 283 -18 215 283 -17 215 minecraft:red_nether_bricks
fill 284 -18 182 287 -18 182 minecraft:red_nether_bricks
setblock 284 -18 186 minecraft:polished_blackstone
fill 284 -18 187 284 -15 187 minecraft:red_nether_bricks
setblock 284 -18 191 minecraft:polished_blackstone
fill 284 -18 192 284 -15 192 minecraft:red_nether_bricks
fill 285 -18 186 285 -17 186 minecraft:red_nether_bricks
setblock 285 -18 190 minecraft:polished_blackstone
fill 285 -18 191 285 -16 191 minecraft:red_nether_bricks
setblock 287 -18 183 minecraft:polished_blackstone
setblock 288 -18 182 minecraft:polished_blackstone
setblock 288 -18 183 minecraft:red_nether_bricks
fill 289 -18 182 292 -18 182 minecraft:red_nether_bricks
setblock 292 -18 183 minecraft:polished_blackstone
fill 292 -18 184 292 -16 184 minecraft:red_nether_bricks
setblock 292 -18 222 minecraft:red_nether_bricks
setblock 293 -18 182 minecraft:polished_blackstone
fill 293 -18 183 293 -15 183 minecraft:red_nether_bricks
setblock 293 -18 222 minecraft:polished_blackstone
fill 294 -18 182 294 -15 182 minecraft:red_nether_bricks
setblock 294 -18 185 minecraft:red_nether_bricks
fill 294 -18 222 294 -15 222 minecraft:red_nether_bricks
setblock 295 -18 185 minecraft:polished_blackstone
fill 295 -18 221 295 -15 221 minecraft:red_nether_bricks
setblock 296 -18 184 minecraft:polished_blackstone
fill 296 -18 185 296 -17 185 minecraft:red_nether_bricks
setblock 297 -18 183 minecraft:polished_blackstone
fill 297 -18 184 297 -15 184 minecraft:red_nether_bricks
setblock 298 -18 182 minecraft:polished_blackstone
fill 298 -18 183 298 -15 183 minecraft:red_nether_bricks
fill 298 -18 220 299 -18 220 minecraft:red_nether_bricks
setblock 298 -18 222 minecraft:polished_blackstone
fill 299 -18 182 299 -15 182 minecraft:red_nether_bricks
setblock 299 -18 221 minecraft:polished_blackstone
fill 299 -18 222 302 -18 222 minecraft:red_nether_bricks
fill 300 -18 221 300 -15 221 minecraft:red_nether_bricks
setblock 301 -18 184 minecraft:polished_blackstone
setblock 302 -18 183 minecraft:polished_blackstone
setblock 303 -18 182 minecraft:polished_blackstone
setblock 303 -18 183 minecraft:red_nether_bricks
setblock 303 -18 222 minecraft:polished_blackstone
fill 304 -18 182 304 -17 182 minecraft:red_nether_bricks
fill 304 -18 222 304 -16 222 minecraft:red_nether_bricks
setblock 313 -18 222 minecraft:polished_blackstone
fill 314 -18 182 314 -17 182 minecraft:red_nether_bricks
fill 314 -18 222 314 -15 222 minecraft:red_nether_bricks
setblock 317 -18 183 minecraft:polished_blackstone
setblock 318 -18 182 minecraft:polished_blackstone
fill 318 -18 183 318 -17 183 minecraft:red_nether_bricks
setblock 318 -18 222 minecraft:polished_blackstone
fill 319 -18 182 319 -16 182 minecraft:red_nether_bricks
setblock 319 -18 210 minecraft:red_nether_bricks
fill 319 -18 222 319 -16 222 minecraft:red_nether_bricks
setblock 320 -18 205 minecraft:polished_blackstone
fill 320 -18 206 320 -17 206 minecraft:red_nether_bricks
setblock 320 -18 210 minecraft:polished_blackstone
fill 320 -18 211 320 -16 211 minecraft:red_nether_bricks
fill 320 -18 213 320 -17 213 minecraft:red_nether_bricks
fill 321 -18 186 321 -18 188 minecraft:red_nether_bricks
setblock 321 -18 189 minecraft:polished_blackstone
fill 321 -18 190 321 -18 193 minecraft:red_nether_bricks
setblock 321 -18 194 minecraft:polished_blackstone
fill 321 -18 195 321 -15 195 minecraft:red_nether_bricks
setblock 321 -18 204 minecraft:polished_blackstone
fill 321 -18 205 321 -16 205 minecraft:red_nether_bricks
setblock 321 -18 209 minecraft:polished_blackstone
fill 321 -18 210 321 -15 210 minecraft:red_nether_bricks
setblock 321 -18 214 minecraft:polished_blackstone
setblock 322 -18 184 minecraft:red_nether_bricks
setblock 322 -18 188 minecraft:polished_blackstone
fill 322 -18 189 322 -15 189 minecraft:red_nether_bricks
fill 322 -18 191 322 -18 192 minecraft:red_nether_bricks
setblock 322 -18 193 minecraft:polished_blackstone
fill 322 -18 194 322 -15 194 minecraft:red_nether_bricks
setblock 322 -18 198 minecraft:polished_blackstone
fill 322 -18 199 322 -15 199 minecraft:red_nether_bricks
setblock 322 -18 203 minecraft:polished_blackstone
fill 322 -18 204 322 -16 204 minecraft:red_nether_bricks
setblock 322 -18 208 minecraft:polished_blackstone
fill 322 -18 209 322 -15 209 minecraft:red_nether_bricks
setblock 322 -18 213 minecraft:polished_blackstone
fill 322 -18 214 322 -15 214 minecraft:red_nether_bricks
setblock 323 -18 182 minecraft:polished_blackstone
fill 323 -18 183 323 -17 183 minecraft:red_nether_bricks
setblock 323 -18 187 minecraft:polished_blackstone
fill 323 -18 188 323 -15 188 minecraft:red_nether_bricks
setblock 323 -18 192 minecraft:polished_blackstone
fill 323 -18 193 323 -15 193 minecraft:red_nether_bricks
setblock 323 -18 197 minecraft:polished_blackstone
fill 323 -18 198 323 -15 198 minecraft:red_nether_bricks
setblock 323 -18 202 minecraft:polished_blackstone
fill 323 -18 203 323 -15 203 minecraft:red_nether_bricks
setblock 323 -18 207 minecraft:polished_blackstone
fill 323 -18 208 323 -15 208 minecraft:red_nether_bricks
setblock 323 -18 212 minecraft:polished_blackstone
fill 323 -18 213 323 -15 213 minecraft:red_nether_bricks
setblock 323 -18 217 minecraft:polished_blackstone
fill 283 -17 182 286 -17 182 minecraft:red_nether_bricks
setblock 283 -17 186 minecraft:polished_blackstone
fill 283 -17 187 283 -17 190 minecraft:red_nether_bricks
setblock 283 -17 191 minecraft:polished_blackstone
fill 283 -17 192 283 -17 195 minecraft:red_nether_bricks
setblock 283 -17 196 minecraft:polished_blackstone
fill 283 -17 197 283 -14 197 minecraft:red_nether_bricks
setblock 283 -17 201 minecraft:polished_blackstone
setblock 283 -17 202 minecraft:red_nether_bricks
fill 283 -17 206 284 -17 206 minecraft:polished_blackstone
fill 283 -17 207 283 -16 207 minecraft:red_nether_bricks
setblock 283 -17 211 minecraft:polished_blackstone
fill 283 -17 212 283 -15 212 minecraft:red_nether_bricks
setblock 284 -17 185 minecraft:polished_blackstone
fill 284 -17 186 284 -15 186 minecraft:red_nether_bricks
setblock 284 -17 190 minecraft:polished_blackstone
fill 284 -17 191 284 -14 191 minecraft:red_nether_bricks
setblock 284 -17 195 minecraft:polished_blackstone
fill 284 -17 205 286 -17 205 minecraft:polished_blackstone
fill 284 -17 207 286 -17 207 minecraft:polished_blackstone
setblock 285 -17 189 minecraft:polished_blackstone
fill 285 -17 190 285 -15 190 minecraft:red_nether_bricks
setblock 285 -17 192 minecraft:red_nether_bricks
setblock 286 -17 206 minecraft:polished_blackstone
setblock 287 -17 182 minecraft:polished_blackstone
fill 288 -17 182 291 -17 182 minecraft:red_nether_bricks
setblock 291 -17 183 minecraft:polished_blackstone
setblock 291 -17 222 minecraft:red_nether_bricks
setblock 292 -17 182 minecraft:polished_blackstone
fill 292 -17 183 292 -14 183 minecraft:red_nether_bricks
setblock 292 -17 222 minecraft:polished_blackstone
fill 293 -17 182 293 -14 182 minecraft:red_nether_bricks
fill 293 -17 222 293 -14 222 minecraft:red_nether_bricks
setblock 294 -17 185 minecraft:polished_blackstone
fill 294 -17 221 294 -14 221 minecraft:red_nether_bricks
setblock 295 -17 184 minecraft:polished_blackstone
setblock 295 -17 185 minecraft:red_nether_bricks
setblock 296 -17 183 minecraft:polished_blackstone
fill 296 -17 184 296 -15 184 minecraft:red_nether_bricks
setblock 297 -17 182 minecraft:polished_blackstone
fill 297 -17 183 297 -14 183 minecraft:red_nether_bricks
fill 297 -17 220 298 -17 220 minecraft:red_nether_bricks
setblock 297 -17 222 minecraft:polished_blackstone
fill 298 -17 182 298 -14 182 minecraft:red_nether_bricks
setblock 298 -17 221 minecraft:polished_blackstone
fill 298 -17 222 301 -17 222 minecraft:red_nether_bricks
setblock 299 -17 220 minecraft:polished_blackstone
fill 299 -17 221 299 -14 221 minecraft:red_nether_bricks
setblock 300 -17 184 minecraft:polished_blackstone
setblock 301 -17 183 minecraft:polished_blackstone
setblock 302 -17 182 minecraft:polished_blackstone
setblock 302 -17 183 minecraft:red_nether_bricks
setblock 302 -17 222 minecraft:polished_blackstone
fill 303 -17 182 303 -16 182 minecraft:red_nether_bricks
fill 303 -17 222 303 -15 222 minecraft:red_nether_bricks
fill 313 -17 222 313 -15 222 minecraft:red_nether_bricks
setblock 317 -17 182 minecraft:polished_blackstone
setblock 317 -17 222 minecraft:polished_blackstone
fill 318 -17 182 318 -15 182 minecraft:red_nether_bricks
fill 318 -17 222 318 -16 222 minecraft:red_nether_bricks
fill 320 -17 190 321 -17 191 minecraft:red_nether_bricks
setblock 320 -17 209 minecraft:polished_blackstone
fill 320 -17 210 320 -16 210 minecraft:red_nether_bricks
fill 321 -17 186 321 -17 187 minecraft:red_nether_bricks
setblock 321 -17 188 minecraft:polished_blackstone
fill 321 -17 189 321 -15 189 minecraft:red_nether_bricks
setblock 321 -17 192 minecraft:red_nether_bricks
setblock 321 -17 193 minecraft:polished_blackstone
fill 321 -17 194 321 -14 194 minecraft:red_nether_bricks
fill 321 -17 196 321 -16 196 minecraft:red_nether_bricks
setblock 321 -17 203 minecraft:polished_blackstone
setblock 321 -17 204 minecraft:red_nether_bricks
setblock 321 -17 208 minecraft:polished_blackstone
fill 321 -17 209 321 -15 209 minecraft:red_nether_bricks
setblock 321 -17 213 minecraft:polished_blackstone
fill 321 -17 214 321 -16 214 minecraft:red_nether_bricks
setblock 322 -17 182 minecraft:polished_blackstone
setblock 322 -17 187 minecraft:polished_blackstone
fill 322 -17 188 322 -14 188 minecraft:red_nether_bricks
setblock 322 -17 191 minecraft:red_nether_bricks
setblock 322 -17 192 minecraft:polished_blackstone
fill 322 -17 193 322 -14 193 minecraft:red_nether_bricks
setblock 322 -17 197 minecraft:polished_blackstone
fill 322 -17 198 322 -14 198 minecraft:red_nether_bricks
setblock 322 -17 202 minecraft:polished_blackstone
fill 322 -17 203 322 -16 203 minecraft:red_nether_bricks
setblock 322 -17 207 minecraft:polished_blackstone
fill 322 -17 208 322 -15 208 minecraft:red_nether_bricks
setblock 322 -17 212 minecraft:polished_blackstone
fill 322 -17 213 322 -14 213 minecraft:red_nether_bricks
setblock 323 -17 186 minecraft:polished_blackstone
fill 323 -17 187 323 -14 187 minecraft:red_nether_bricks
setblock 323 -17 191 minecraft:polished_blackstone
fill 323 -17 192 323 -14 192 minecraft:red_nether_bricks
setblock 323 -17 196 minecraft:polished_blackstone
fill 323 -17 197 323 -14 197 minecraft:red_nether_bricks
setblock 323 -17 201 minecraft:polished_blackstone
fill 323 -17 202 323 -15 202 minecraft:red_nether_bricks
setblock 323 -17 206 minecraft:polished_blackstone
fill 323 -17 207 323 -14 207 minecraft:red_nether_bricks
setblock 323 -17 211 minecraft:polished_blackstone
fill 323 -17 212 323 -14 212 minecraft:red_nether_bricks
setblock 323 -17 216 minecraft:polished_blackstone
setblock 323 -17 217 minecraft:red_nether_bricks
fill 283 -16 182 285 -16 182 minecraft:red_nether_bricks
setblock 283 -16 185 minecraft:polished_blackstone
fill 283 -16 186 283 -16 189 minecraft:red_nether_bricks
setblock 283 -16 190 minecraft:polished_blackstone
fill 283 -16 191 283 -16 194 minecraft:red_nether_bricks
setblock 283 -16 195 minecraft:polished_blackstone
fill 283 -16 196 283 -13 196 minecraft:red_nether_bricks
setblock 283 -16 206 minecraft:red_nether_bricks
setblock 283 -16 210 minecraft:polished_blackstone
fill 283 -16 211 283 -15 211 minecraft:red_nether_bricks
setblock 283 -16 215 minecraft:polished_blackstone
setblock 284 -16 184 minecraft:polished_blackstone
fill 284 -16 185 284 -15 185 minecraft:red_nether_bricks
setblock 284 -16 189 minecraft:polished_blackstone
fill 284 -16 190 284 -13 190 minecraft:red_nether_bricks
setblock 284 -16 194 minecraft:polished_blackstone
fill 284 -16 195 284 -15 195 minecraft:red_nether_bricks
setblock 285 -16 188 minecraft:polished_blackstone
setblock 285 -16 189 minecraft:red_nether_bricks
setblock 286 -16 182 minecraft:polished_blackstone
fill 287 -16 182 290 -16 182 minecraft:red_nether_bricks
setblock 290 -16 183 minecraft:polished_blackstone
setblock 291 -16 182 minecraft:polished_blackstone
fill 291 -16 183 291 -14 183 minecraft:red_nether_bricks
setblock 291 -16 222 minecraft:polished_blackstone
fill 292 -16 182 292 -13 182 minecraft:red_nether_bricks
fill 292 -16 222 292 -13 222 minecraft:red_nether_bricks
fill 293 -16 221 293 -13 221 minecraft:red_nether_bricks
setblock 294 -16 184 minecraft:polished_blackstone
setblock 295 -16 183 minecraft:polished_blackstone
fill 295 -16 184 295 -15 184 minecraft:red_nether_bricks
setblock 296 -16 182 minecraft:polished_blackstone
fill 296 -16 183 296 -13 183 minecraft:red_nether_bricks
fill 296 -16 220 297 -16 220 minecraft:red_nether_bricks
setblock 296 -16 222 minecraft:polished_blackstone
fill 297 -16 182 297 -13 182 minecraft:red_nether_bricks
setblock 297 -16 221 minecraft:polished_blackstone
fill 297 -16 222 300 -16 222 minecraft:red_nether_bricks
setblock 298 -16 220 minecraft:polished_blackstone
fill 298 -16 221 298 -13 221 minecraft:red_nether_bricks
setblock 299 -16 184 minecraft:polished_blackstone
fill 299 -16 220 299 -15 220 minecraft:red_nether_bricks
setblock 300 -16 183 minecraft:polished_blackstone
setblock 301 -16 182 minecraft:polished_blackstone
setblock 301 -16 183 minecraft:red_nether_bricks
setblock 301 -16 222 minecraft:polished_blackstone
setblock 302 -16 182 minecraft:red_nether_bricks
setblock 302 -16 221 minecraft:polished_blackstone
fill 302 -16 222 302 -14 222 minecraft:red_nether_bricks
setblock 316 -16 182 minecraft:polished_blackstone
setblock 316 -16 222 minecraft:polished_blackstone
fill 317 -16 182 317 -15 182 minecraft:red_nether_bricks
fill 317 -16 222 317 -15 222 minecraft:red_nether_bricks
fill 320 -16 191 320 -16 192 minecraft:red_nether_bricks
setblock 320 -16 208 minecraft:polished_blackstone
setblock 320 -16 209 minecraft:red_nether_bricks
setblock 321 -16 182 minecraft:polished_blackstone
setblock 321 -16 187 minecraft:polished_blackstone
fill 321 -16 188 321 -15 188 minecraft:red_nether_bricks
fill 321 -16 190 321 -16 191 minecraft:red_nether_bricks
setblock 321 -16 192 minecraft:polished_blackstone
fill 321 -16 193 321 -13 193 minecraft:red_nether_bricks
setblock 321 -16 207 minecraft:polished_blackstone
fill 321 -16 208 321 -15 208 minecraft:red_nether_bricks
setblock 321 -16 212 minecraft:polished_blackstone
fill 321 -16 213 321 -15 213 minecraft:red_nether_bricks
setblock 322 -16 186 minecraft:polished_blackstone
fill 322 -16 187 322 -15 187 minecraft:red_nether_bricks
setblock 322 -16 191 minecraft:polished_blackstone
fill 322 -16 192 322 -13 192 minecraft:red_nether_bricks
setblock 322 -16 196 minecraft:polished_blackstone
fill 322 -16 197 322 -13 197 minecraft:red_nether_bricks
setblock 322 -16 201 minecraft:polished_blackstone
setblock 322 -16 202 minecraft:red_nether_bricks
setblock 322 -16 206 minecraft:polished_blackstone
fill 322 -16 207 322 -15 207 minecraft:red_nether_bricks
setblock 322 -16 211 minecraft:polished_blackstone
fill 322 -16 212 322 -14 212 minecraft:red_nether_bricks
setblock 323 -16 185 minecraft:polished_blackstone
fill 323 -16 186 323 -14 186 minecraft:red_nether_bricks
setblock 323 -16 190 minecraft:polished_blackstone
fill 323 -16 191 323 -13 191 minecraft:red_nether_bricks
setblock 323 -16 195 minecraft:polished_blackstone
fill 323 -16 196 323 -13 196 minecraft:red_nether_bricks
setblock 323 -16 200 minecraft:polished_blackstone
fill 323 -16 201 323 -14 201 minecraft:red_nether_bricks
setblock 323 -16 205 minecraft:polished_blackstone
fill 323 -16 206 323 -14 206 minecraft:red_nether_bricks
setblock 323 -16 210 minecraft:polished_blackstone
fill 323 -16 211 323 -13 211 minecraft:red_nether_bricks
setblock 323 -16 215 minecraft:polished_blackstone
fill 323 -16 216 323 -15 216 minecraft:red_nether_bricks
setblock 283 -15 182 minecraft:red_nether_bricks
setblock 283 -15 184 minecraft:polished_blackstone
fill 283 -15 185 283 -15 188 minecraft:red_nether_bricks
setblock 283 -15 189 minecraft:polished_blackstone
fill 283 -15 190 283 -15 193 minecraft:red_nether_bricks
setblock 283 -15 194 minecraft:polished_blackstone
fill 283 -15 195 283 -12 195 minecraft:red_nether_bricks
setblock 283 -15 209 minecraft:polished_blackstone
setblock 283 -15 210 minecraft:red_nether_bricks
setblock 283 -15 214 minecraft:polished_blackstone
setblock 284 -15 188 minecraft:polished_blackstone
fill 284 -15 189 284 -13 189 minecraft:red_nether_bricks
setblock 284 -15 193 minecraft:polished_blackstone
fill 284 -15 194 284 -13 194 minecraft:red_nether_bricks
fill 287 -15 182 289 -15 182 minecraft:red_nether_bricks
setblock 290 -15 182 minecraft:polished_blackstone
setblock 290 -15 183 minecraft:red_nether_bricks
fill 291 -15 182 291 -12 182 minecraft:red_nether_bricks
fill 291 -15 222 291 -12 222 minecraft:red_nether_bricks
setblock 293 -15 184 minecraft:polished_blackstone
setblock 294 -15 183 minecraft:polished_blackstone
setblock 294 -15 184 minecraft:red_nether_bricks
setblock 295 -15 182 minecraft:polished_blackstone
fill 295 -15 183 295 -13 183 minecraft:red_nether_bricks
fill 295 -15 220 296 -15 220 minecraft:red_nether_bricks
setblock 295 -15 222 minecraft:polished_blackstone
fill 296 -15 182 296 -12 182 minecraft:red_nether_bricks
setblock 296 -15 221 minecraft:polished_blackstone
fill 296 -15 222 299 -15 222 minecraft:red_nether_bricks
setblock 297 -15 220 minecraft:polished_blackstone
fill 297 -15 221 297 -12 221 minecraft:red_nether_bricks
fill 298 -15 220 298 -14 220 minecraft:red_nether_bricks
setblock 299 -15 183 minecraft:polished_blackstone
setblock 300 -15 182 minecraft:polished_blackstone
setblock 300 -15 183 minecraft:red_nether_bricks
setblock 300 -15 222 minecraft:polished_blackstone
setblock 301 -15 182 minecraft:red_nether_bricks
setblock 301 -15 221 minecraft:polished_blackstone
fill 301 -15 222 301 -12 222 minecraft:red_nether_bricks
setblock 315 -15 222 minecraft:polished_blackstone
setblock 316 -15 182 minecraft:red_nether_bricks
fill 316 -15 222 316 -14 222 minecraft:red_nether_bricks
setblock 321 -15 190 minecraft:red_nether_bricks
setblock 321 -15 191 minecraft:polished_blackstone
fill 321 -15 192 321 -13 192 minecraft:red_nether_bricks
setblock 321 -15 196 minecraft:polished_blackstone
setblock 321 -15 211 minecraft:polished_blackstone
setblock 321 -15 212 minecraft:red_nether_bricks
setblock 322 -15 186 minecraft:red_nether_bricks
setblock 322 -15 190 minecraft:polished_blackstone
fill 322 -15 191 322 -12 191 minecraft:red_nether_bricks
setblock 322 -15 195 minecraft:polished_blackstone
fill 322 -15 196 322 -12 196 minecraft:red_nether_bricks
setblock 322 -15 205 minecraft:polished_blackstone
setblock 322 -15 206 minecraft:red_nether_bricks
setblock 322 -15 210 minecraft:polished_blackstone
fill 322 -15 211 322 -14 211 minecraft:red_nether_bricks
setblock 323 -15 185 minecraft:red_nether_bricks
setblock 323 -15 189 minecraft:polished_blackstone
fill 323 -15 190 323 -12 190 minecraft:red_nether_bricks
setblock 323 -15 194 minecraft:polished_blackstone
fill 323 -15 195 323 -12 195 minecraft:red_nether_bricks
setblock 323 -15 199 minecraft:polished_blackstone
fill 323 -15 200 323 -14 200 minecraft:red_nether_bricks
setblock 323 -15 204 minecraft:polished_blackstone
setblock 323 -15 205 minecraft:red_nether_bricks
setblock 323 -15 209 minecraft:polished_blackstone
fill 323 -15 210 323 -13 210 minecraft:red_nether_bricks
setblock 323 -15 214 minecraft:polished_blackstone
fill 323 -15 215 323 -14 215 minecraft:red_nether_bricks
fill 283 -14 184 283 -14 187 minecraft:red_nether_bricks
setblock 283 -14 188 minecraft:polished_blackstone
fill 283 -14 189 283 -14 192 minecraft:red_nether_bricks
setblock 283 -14 193 minecraft:polished_blackstone
fill 283 -14 194 283 -11 194 minecraft:red_nether_bricks
setblock 284 -14 187 minecraft:polished_blackstone
fill 284 -14 188 284 -13 188 minecraft:red_nether_bricks
setblock 284 -14 192 minecraft:polished_blackstone
fill 284 -14 193 284 -12 193 minecraft:red_nether_bricks
setblock 288 -14 182 minecraft:red_nether_bricks
setblock 289 -14 182 minecraft:polished_blackstone
fill 290 -14 182 290 -11 182 minecraft:red_nether_bricks
fill 290 -14 222 290 -11 222 minecraft:red_nether_bricks
fill 292 -14 221 292 -12 221 minecraft:red_nether_bricks
setblock 293 -14 183 minecraft:polished_blackstone
setblock 294 -14 182 minecraft:polished_blackstone
fill 294 -14 183 294 -12 183 minecraft:red_nether_bricks
setblock 294 -14 222 minecraft:polished_blackstone
fill 295 -14 182 295 -11 182 minecraft:red_nether_bricks
setblock 295 -14 220 minecraft:red_nether_bricks
setblock 295 -14 221 minecraft:polished_blackstone
fill 295 -14 222 298 -14 222 minecraft:red_nether_bricks
setblock 296 -14 220 minecraft:polished_blackstone
fill 296 -14 221 296 -11 221 minecraft:red_nether_bricks
fill 297 -14 220 297 -11 220 minecraft:red_nether_bricks
setblock 298 -14 183 minecraft:polished_blackstone
setblock 299 -14 182 minecraft:polished_blackstone
setblock 299 -14 222 minecraft:polished_blackstone
setblock 300 -14 182 minecraft:red_nether_bricks
setblock 300 -14 221 minecraft:polished_blackstone
fill 300 -14 222 300 -11 222 minecraft:red_nether_bricks
setblock 314 -14 222 minecraft:polished_blackstone
setblock 315 -14 222 minecraft:red_nether_bricks
setblock 321 -14 190 minecraft:polished_blackstone
fill 321 -14 191 321 -13 191 minecraft:red_nether_bricks
setblock 321 -14 195 minecraft:polished_blackstone
setblock 322 -14 189 minecraft:polished_blackstone
fill 322 -14 190 322 -12 190 minecraft:red_nether_bricks
setblock 322 -14 194 minecraft:polished_blackstone
fill 322 -14 195 322 -11 195 minecraft:red_nether_bricks
setblock 322 -14 209 minecraft:polished_blackstone
setblock 322 -14 210 minecraft:red_nether_bricks
setblock 323 -14 188 minecraft:polished_blackstone
fill 323 -14 189 323 -11 189 minecraft:red_nether_bricks
setblock 323 -14 193 minecraft:polished_blackstone
fill 323 -14 194 323 -11 194 minecraft:red_nether_bricks
setblock 323 -14 198 minecraft:polished_blackstone
fill 323 -14 199 323 -11 199 minecraft:red_nether_bricks
setblock 323 -14 208 minecraft:polished_blackstone
setblock 323 -14 209 minecraft:red_nether_bricks
setblock 323 -14 213 minecraft:polished_blackstone
fill 323 -14 214 323 -13 214 minecraft:red_nether_bricks
fill 283 -13 185 283 -13 186 minecraft:red_nether_bricks
setblock 283 -13 187 minecraft:polished_blackstone
fill 283 -13 188 283 -13 191 minecraft:red_nether_bricks
setblock 283 -13 192 minecraft:polished_blackstone
fill 283 -13 193 283 -10 193 minecraft:red_nether_bricks
setblock 283 -13 197 minecraft:polished_blackstone
setblock 284 -13 191 minecraft:polished_blackstone
fill 284 -13 192 284 -12 192 minecraft:red_nether_bricks
fill 289 -13 182 289 -10 182 minecraft:red_nether_bricks
fill 289 -13 202 289 -12 204 minecraft:magma_block
fill 290 -13 203 290 -12 204 minecraft:magma_block
setblock 292 -13 183 minecraft:polished_blackstone
setblock 293 -13 182 minecraft:polished_blackstone
fill 293 -13 183 293 -12 183 minecraft:red_nether_bricks
setblock 293 -13 222 minecraft:polished_blackstone
fill 294 -13 182 294 -10 182 minecraft:red_nether_bricks
setblock 294 -13 220 minecraft:red_nether_bricks
setblock 294 -13 221 minecraft:polished_blackstone
fill 294 -13 222 297 -13 222 minecraft:red_nether_bricks
setblock 295 -13 220 minecraft:polished_blackstone
fill 295 -13 221 295 -10 221 minecraft:red_nether_bricks
fill 296 -13 220 296 -10 220 minecraft:red_nether_bricks
setblock 298 -13 182 minecraft:polished_blackstone
setblock 298 -13 222 minecraft:polished_blackstone
setblock 299 -13 182 minecraft:red_nether_bricks
setblock 299 -13 221 minecraft:polished_blackstone
fill 299 -13 222 299 -10 222 minecraft:red_nether_bricks
setblock 300 -13 221 minecraft:red_nether_bricks
setblock 314 -13 222 minecraft:red_nether_bricks
setblock 321 -13 194 minecraft:polished_blackstone
setblock 321 -13 195 minecraft:red_nether_bricks
setblock 322 -13 189 minecraft:red_nether_bricks
setblock 322 -13 193 minecraft:polished_blackstone
fill 322 -13 194 322 -10 194 minecraft:red_nether_bricks
setblock 323 -13 187 minecraft:polished_blackstone
fill 323 -13 188 323 -12 188 minecraft:red_nether_bricks
setblock 323 -13 192 minecraft:polished_blackstone
fill 323 -13 193 323 -10 193 minecraft:red_nether_bricks
setblock 323 -13 197 minecraft:polished_blackstone
fill 323 -13 198 323 -10 198 minecraft:red_nether_bricks
setblock 323 -13 212 minecraft:polished_blackstone
setblock 323 -13 213 minecraft:red_nether_bricks
setblock 283 -12 186 minecraft:polished_blackstone
fill 283 -12 187 283 -12 190 minecraft:red_nether_bricks
setblock 283 -12 191 minecraft:polished_blackstone
fill 283 -12 192 283 -9 192 minecraft:red_nether_bricks
setblock 283 -12 196 minecraft:polished_blackstone
setblock 284 -12 191 minecraft:red_nether_bricks
setblock 285 -12 184 minecraft:light[level=14]
setblock 285 -12 192 minecraft:light[level=14]
setblock 285 -12 200 minecraft:light[level=14]
setblock 285 -12 208 minecraft:light[level=14]
setblock 285 -12 216 minecraft:light[level=14]
fill 291 -12 221 291 -11 221 minecraft:red_nether_bricks
setblock 292 -12 182 minecraft:polished_blackstone
setblock 292 -12 222 minecraft:polished_blackstone
fill 293 -12 182 293 -9 182 minecraft:red_nether_bricks
setblock 293 -12 184 minecraft:light[level=14]
setblock 293 -12 192 minecraft:light[level=14]
setblock 293 -12 200 minecraft:light[level=14]
setblock 293 -12 208 minecraft:light[level=14]
setblock 293 -12 216 minecraft:light[level=14]
setblock 293 -12 221 minecraft:polished_blackstone
fill 293 -12 222 296 -12 222 minecraft:red_nether_bricks
setblock 294 -12 220 minecraft:polished_blackstone
fill 294 -12 221 294 -9 221 minecraft:red_nether_bricks
fill 295 -12 220 295 -9 220 minecraft:red_nether_bricks
setblock 297 -12 182 minecraft:polished_blackstone
setblock 297 -12 222 minecraft:polished_blackstone
setblock 298 -12 182 minecraft:red_nether_bricks
setblock 298 -12 221 minecraft:polished_blackstone
fill 298 -12 222 298 -9 222 minecraft:red_nether_bricks
fill 299 -12 221 299 -9 221 minecraft:red_nether_bricks
setblock 301 -12 184 minecraft:light[level=14]
setblock 301 -12 192 minecraft:light[level=14]
setblock 301 -12 200 minecraft:light[level=14]
setblock 301 -12 208 minecraft:light[level=14]
setblock 301 -12 216 minecraft:light[level=14]
setblock 309 -12 184 minecraft:light[level=14]
setblock 309 -12 192 minecraft:light[level=14]
setblock 309 -12 200 minecraft:light[level=14]
setblock 309 -12 208 minecraft:light[level=14]
setblock 309 -12 216 minecraft:light[level=14]
setblock 317 -12 184 minecraft:light[level=14]
setblock 317 -12 192 minecraft:light[level=14]
setblock 317 -12 200 minecraft:light[level=14]
setblock 317 -12 208 minecraft:light[level=14]
setblock 317 -12 216 minecraft:light[level=14]
setblock 322 -12 192 minecraft:polished_blackstone
fill 322 -12 193 322 -9 193 minecraft:red_nether_bricks
setblock 322 -12 197 minecraft:polished_blackstone
setblock 323 -12 191 minecraft:polished_blackstone
fill 323 -12 192 323 -9 192 minecraft:red_nether_bricks
setblock 323 -12 196 minecraft:polished_blackstone
fill 323 -12 197 323 -9 197 minecraft:red_nether_bricks
fill 283 -11 188 283 -11 189 minecraft:red_nether_bricks
setblock 283 -11 190 minecraft:polished_blackstone
fill 283 -11 191 283 -8 191 minecraft:red_nether_bricks
setblock 283 -11 195 minecraft:polished_blackstone
fill 283 -11 196 283 -8 196 minecraft:red_nether_bricks
fill 289 -11 222 289 -10 222 minecraft:red_nether_bricks
setblock 291 -11 182 minecraft:polished_blackstone
setblock 291 -11 222 minecraft:polished_blackstone
fill 292 -11 182 292 -8 182 minecraft:red_nether_bricks
setblock 292 -11 221 minecraft:polished_blackstone
fill 292 -11 222 295 -11 222 minecraft:red_nether_bricks
setblock 293 -11 220 minecraft:polished_blackstone
fill 293 -11 221 293 -8 221 minecraft:red_nether_bricks
fill 294 -11 220 294 -8 220 minecraft:red_nether_bricks
setblock 296 -11 182 minecraft:polished_blackstone
setblock 296 -11 222 minecraft:polished_blackstone
setblock 297 -11 182 minecraft:red_nether_bricks
setblock 297 -11 221 minecraft:polished_blackstone
fill 297 -11 222 297 -8 222 minecraft:red_nether_bricks
fill 298 -11 221 298 -8 221 minecraft:red_nether_bricks
setblock 322 -11 191 minecraft:polished_blackstone
fill 322 -11 192 322 -10 192 minecraft:red_nether_bricks
setblock 322 -11 196 minecraft:polished_blackstone
setblock 323 -11 190 minecraft:polished_blackstone
fill 323 -11 191 323 -8 191 minecraft:red_nether_bricks
setblock 323 -11 195 minecraft:polished_blackstone
fill 323 -11 196 323 -8 196 minecraft:red_nether_bricks
setblock 283 -10 189 minecraft:polished_blackstone
fill 283 -10 190 283 -9 190 minecraft:red_nether_bricks
setblock 283 -10 194 minecraft:polished_blackstone
fill 283 -10 195 283 -7 195 minecraft:red_nether_bricks
fill 284 -10 205 284 -10 207 minecraft:polished_blackstone
fill 285 -10 205 286 -10 205 minecraft:polished_blackstone
fill 285 -10 207 286 -10 207 minecraft:polished_blackstone
setblock 286 -10 206 minecraft:polished_blackstone
fill 288 -10 222 288 -9 222 minecraft:red_nether_bricks
setblock 290 -10 182 minecraft:polished_blackstone
setblock 290 -10 221 minecraft:red_nether_bricks
setblock 290 -10 222 minecraft:polished_blackstone
fill 291 -10 182 291 -7 182 minecraft:red_nether_bricks
setblock 291 -10 221 minecraft:polished_blackstone
fill 291 -10 222 294 -10 222 minecraft:red_nether_bricks
setblock 292 -10 220 minecraft:polished_blackstone
fill 292 -10 221 292 -7 221 minecraft:red_nether_bricks
fill 293 -10 220 293 -7 220 minecraft:red_nether_bricks
setblock 295 -10 182 minecraft:polished_blackstone
setblock 295 -10 222 minecraft:polished_blackstone
fill 296 -10 182 296 -7 182 minecraft:red_nether_bricks
setblock 296 -10 221 minecraft:polished_blackstone
fill 296 -10 222 296 -7 222 minecraft:red_nether_bricks
setblock 297 -10 220 minecraft:polished_blackstone
fill 297 -10 221 297 -7 221 minecraft:red_nether_bricks
setblock 300 -10 222 minecraft:polished_blackstone
fill 312 -10 222 314 -10 222 minecraft:red_nether_bricks
setblock 322 -10 195 minecraft:polished_blackstone
fill 322 -10 196 322 -7 196 minecraft:red_nether_bricks
fill 323 -10 190 323 -7 190 minecraft:red_nether_bricks
setblock 323 -10 194 minecraft:polished_blackstone
fill 323 -10 195 323 -7 195 minecraft:red_nether_bricks
setblock 323 -10 199 minecraft:polished_blackstone
setblock 283 -9 193 minecraft:polished_blackstone
fill 283 -9 194 283 -6 194 minecraft:red_nether_bricks
fill 283 -9 216 285 -8 218 minecraft:magma_block
fill 286 -9 217 286 -6 217 minecraft:magma_block
fill 287 -9 222 287 -8 222 minecraft:red_nether_bricks
setblock 288 -9 182 minecraft:red_nether_bricks
setblock 289 -9 182 minecraft:polished_blackstone
setblock 289 -9 221 minecraft:red_nether_bricks
setblock 289 -9 222 minecraft:polished_blackstone
fill 290 -9 182 290 -6 182 minecraft:red_nether_bricks
fill 290 -9 193 292 -8 193 minecraft:magma_block
setblock 290 -9 221 minecraft:polished_blackstone
fill 290 -9 222 293 -9 222 minecraft:red_nether_bricks
fill 291 -9 192 291 -8 192 minecraft:magma_block
fill 291 -9 194 291 -8 194 minecraft:magma_block
setblock 291 -9 220 minecraft:polished_blackstone
fill 291 -9 221 291 -6 221 minecraft:red_nether_bricks
fill 292 -9 220 292 -6 220 minecraft:red_nether_bricks
setblock 294 -9 182 minecraft:polished_blackstone
setblock 294 -9 222 minecraft:polished_blackstone
fill 295 -9 182 295 -6 182 minecraft:red_nether_bricks
setblock 295 -9 221 minecraft:polished_blackstone
fill 295 -9 222 295 -6 222 minecraft:red_nether_bricks
setblock 296 -9 220 minecraft:polished_blackstone
fill 296 -9 221 296 -6 221 minecraft:red_nether_bricks
fill 297 -9 220 297 -6 220 minecraft:red_nether_bricks
setblock 299 -9 222 minecraft:polished_blackstone
fill 300 -9 222 300 -6 222 minecraft:red_nether_bricks
fill 310 -9 222 313 -9 222 minecraft:red_nether_bricks
setblock 314 -9 222 minecraft:polished_blackstone
fill 315 -9 222 315 -6 222 minecraft:red_nether_bricks
setblock 322 -9 194 minecraft:polished_blackstone
fill 322 -9 195 322 -6 195 minecraft:red_nether_bricks
fill 322 -9 197 322 -8 197 minecraft:red_nether_bricks
setblock 323 -9 193 minecraft:polished_blackstone
fill 323 -9 194 323 -6 194 minecraft:red_nether_bricks
setblock 323 -9 198 minecraft:polished_blackstone
fill 323 -9 199 323 -6 199 minecraft:red_nether_bricks
setblock 283 -8 192 minecraft:polished_blackstone
fill 283 -8 193 283 -5 193 minecraft:red_nether_bricks
setblock 283 -8 197 minecraft:polished_blackstone
fill 283 -8 215 284 -7 215 minecraft:magma_block
fill 283 -8 219 284 -8 219 minecraft:magma_block
fill 285 -8 222 286 -7 222 minecraft:red_nether_bricks
fill 286 -8 182 287 -8 182 minecraft:red_nether_bricks
fill 286 -8 216 287 -7 216 minecraft:magma_block
fill 286 -8 218 287 -7 218 minecraft:magma_block
fill 287 -8 217 288 -7 217 minecraft:magma_block
fill 287 -8 221 288 -8 221 minecraft:red_nether_bricks
setblock 288 -8 182 minecraft:polished_blackstone
setblock 288 -8 222 minecraft:polished_blackstone
fill 289 -8 182 289 -5 182 minecraft:red_nether_bricks
setblock 289 -8 220 minecraft:red_nether_bricks
setblock 289 -8 221 minecraft:polished_blackstone
fill 289 -8 222 292 -8 222 minecraft:red_nether_bricks
setblock 290 -8 220 minecraft:polished_blackstone
fill 290 -8 221 290 -5 221 minecraft:red_nether_bricks
fill 291 -8 220 291 -5 220 minecraft:red_nether_bricks
fill 292 -8 219 295 -8 219 minecraft:red_nether_bricks
setblock 293 -8 182 minecraft:polished_blackstone
setblock 293 -8 222 minecraft:polished_blackstone
fill 294 -8 182 294 -5 182 minecraft:red_nether_bricks
setblock 294 -8 221 minecraft:polished_blackstone
fill 294 -8 222 294 -5 222 minecraft:red_nether_bricks
setblock 295 -8 220 minecraft:polished_blackstone
fill 295 -8 221 295 -5 221 minecraft:red_nether_bricks
fill 296 -8 220 296 -5 220 minecraft:red_nether_bricks
setblock 298 -8 222 minecraft:polished_blackstone
setblock 299 -8 221 minecraft:polished_blackstone
fill 299 -8 222 299 -5 222 minecraft:red_nether_bricks
fill 301 -8 222 301 -7 222 minecraft:red_nether_bricks
setblock 307 -8 222 minecraft:red_nether_bricks
setblock 308 -8 222 minecraft:polished_blackstone
fill 309 -8 222 312 -8 222 minecraft:red_nether_bricks
fill 310 -8 221 313 -8 221 minecraft:red_nether_bricks
setblock 313 -8 222 minecraft:polished_blackstone
fill 314 -8 222 314 -5 222 minecraft:red_nether_bricks
setblock 322 -8 193 minecraft:polished_blackstone
fill 322 -8 194 322 -5 194 minecraft:red_nether_bricks
setblock 323 -8 192 minecraft:polished_blackstone
fill 323 -8 193 323 -5 193 minecraft:red_nether_bricks
setblock 323 -8 197 minecraft:polished_blackstone
fill 323 -8 198 323 -5 198 minecraft:red_nether_bricks
fill 323 -8 200 323 -7 200 minecraft:red_nether_bricks
setblock 283 -7 191 minecraft:polished_blackstone
fill 283 -7 192 283 -4 192 minecraft:red_nether_bricks
setblock 283 -7 196 minecraft:polished_blackstone
fill 283 -7 197 283 -5 198 minecraft:red_nether_bricks
fill 283 -7 216 285 -7 216 minecraft:magma_block
fill 283 -7 217 283 -7 220 minecraft:red_nether_bricks
setblock 283 -7 221 minecraft:polished_blackstone
fill 283 -7 222 284 -5 222 minecraft:red_nether_bricks
fill 284 -7 182 286 -7 182 minecraft:red_nether_bricks
fill 284 -7 217 284 -7 219 minecraft:magma_block
fill 285 -7 217 285 -6 218 minecraft:magma_block
fill 286 -7 221 287 -7 221 minecraft:red_nether_bricks
setblock 287 -7 182 minecraft:polished_blackstone
setblock 287 -7 222 minecraft:polished_blackstone
fill 288 -7 182 288 -4 182 minecraft:red_nether_bricks
setblock 288 -7 216 minecraft:magma_block
setblock 288 -7 218 minecraft:magma_block
setblock 288 -7 220 minecraft:red_nether_bricks
setblock 288 -7 221 minecraft:polished_blackstone
fill 288 -7 222 291 -7 222 minecraft:red_nether_bricks
fill 289 -7 183 290 -7 183 minecraft:red_nether_bricks
fill 289 -7 217 290 -7 217 minecraft:magma_block
setblock 289 -7 220 minecraft:polished_blackstone
fill 289 -7 221 289 -4 221 minecraft:red_nether_bricks
setblock 290 -7 219 minecraft:polished_blackstone
fill 290 -7 220 290 -4 220 minecraft:red_nether_bricks
setblock 291 -7 183 minecraft:polished_blackstone
fill 291 -7 219 294 -7 219 minecraft:red_nether_bricks
setblock 292 -7 182 minecraft:polished_blackstone
fill 292 -7 183 293 -5 183 minecraft:red_nether_bricks
setblock 292 -7 222 minecraft:polished_blackstone
fill 293 -7 182 293 -4 182 minecraft:red_nether_bricks
setblock 293 -7 221 minecraft:polished_blackstone
fill 293 -7 222 293 -4 222 minecraft:red_nether_bricks
setblock 294 -7 220 minecraft:polished_blackstone
fill 294 -7 221 294 -4 221 minecraft:red_nether_bricks
setblock 295 -7 219 minecraft:polished_blackstone
fill 295 -7 220 295 -4 220 minecraft:red_nether_bricks
setblock 297 -7 222 minecraft:polished_blackstone
setblock 298 -7 220 minecraft:red_nether_bricks
setblock 298 -7 221 minecraft:polished_blackstone
fill 298 -7 222 298 -4 222 minecraft:red_nether_bricks
fill 299 -7 221 300 -5 221 minecraft:red_nether_bricks
setblock 302 -7 222 minecraft:polished_blackstone
fill 303 -7 222 306 -7 222 minecraft:red_nether_bricks
setblock 307 -7 222 minecraft:polished_blackstone
setblock 308 -7 221 minecraft:polished_blackstone
fill 308 -7 222 311 -7 222 minecraft:red_nether_bricks
fill 309 -7 221 312 -7 221 minecraft:red_nether_bricks
setblock 312 -7 222 minecraft:polished_blackstone
setblock 313 -7 221 minecraft:polished_blackstone
fill 313 -7 222 313 -4 222 minecraft:red_nether_bricks
fill 314 -7 221 314 -4 221 minecraft:red_nether_bricks
setblock 316 -7 222 minecraft:red_nether_bricks
fill 322 -7 193 322 -4 193 minecraft:red_nether_bricks
setblock 322 -7 197 minecraft:polished_blackstone
fill 322 -7 198 322 -4 198 minecraft:red_nether_bricks
setblock 323 -7 191 minecraft:polished_blackstone
fill 323 -7 192 323 -4 192 minecraft:red_nether_bricks
setblock 323 -7 196 minecraft:polished_blackstone
fill 323 -7 197 323 -4 197 minecraft:red_nether_bricks
fill 283 -6 182 283 -5 183 minecraft:red_nether_bricks
fill 283 -6 191 283 -3 191 minecraft:red_nether_bricks
setblock 283 -6 195 minecraft:polished_blackstone
fill 283 -6 196 283 -3 196 minecraft:red_nether_bricks
setblock 283 -6 199 minecraft:red_nether_bricks
fill 283 -6 216 283 -6 219 minecraft:red_nether_bricks
setblock 283 -6 220 minecraft:polished_blackstone
fill 283 -6 221 286 -6 221 minecraft:red_nether_bricks
fill 284 -6 182 285 -6 182 minecraft:red_nether_bricks
fill 284 -6 216 284 -6 218 minecraft:magma_block
setblock 284 -6 219 minecraft:polished_blackstone
fill 284 -6 220 284 -3 220 minecraft:red_nether_bricks
fill 285 -6 216 286 -6 216 minecraft:magma_block
setblock 285 -6 222 minecraft:red_nether_bricks
setblock 286 -6 182 minecraft:polished_blackstone
setblock 286 -6 218 minecraft:magma_block
fill 286 -6 220 287 -6 220 minecraft:red_nether_bricks
setblock 286 -6 222 minecraft:polished_blackstone
fill 287 -6 182 287 -4 183 minecraft:red_nether_bricks
setblock 287 -6 217 minecraft:magma_block
setblock 287 -6 221 minecraft:polished_blackstone
fill 287 -6 222 290 -6 222 minecraft:red_nether_bricks
fill 288 -6 183 289 -6 183 minecraft:red_nether_bricks
setblock 288 -6 220 minecraft:polished_blackstone
fill 288 -6 221 288 -3 221 minecraft:red_nether_bricks
setblock 289 -6 219 minecraft:polished_blackstone
fill 289 -6 220 289 -3 220 minecraft:red_nether_bricks
setblock 290 -6 183 minecraft:polished_blackstone
fill 290 -6 219 293 -6 219 minecraft:red_nether_bricks
setblock 291 -6 182 minecraft:polished_blackstone
fill 291 -6 183 291 -3 183 minecraft:red_nether_bricks
setblock 291 -6 222 minecraft:polished_blackstone
fill 292 -6 182 292 -3 182 minecraft:red_nether_bricks
setblock 292 -6 221 minecraft:polished_blackstone
fill 292 -6 222 292 -3 222 minecraft:red_nether_bricks
setblock 293 -6 220 minecraft:polished_blackstone
fill 293 -6 221 293 -3 221 minecraft:red_nether_bricks
setblock 294 -6 219 minecraft:polished_blackstone
fill 294 -6 220 294 -3 220 minecraft:red_nether_bricks
fill 295 -6 219 295 -3 219 minecraft:red_nether_bricks
setblock 296 -6 182 minecraft:polished_blackstone
setblock 296 -6 222 minecraft:polished_blackstone
setblock 297 -6 221 minecraft:polished_blackstone
fill 297 -6 222 297 -3 222 minecraft:red_nether_bricks
setblock 298 -6 220 minecraft:polished_blackstone
fill 298 -6 221 298 -3 221 minecraft:red_nether_bricks
setblock 301 -6 221 minecraft:red_nether_bricks
setblock 301 -6 222 minecraft:polished_blackstone
fill 302 -6 222 305 -6 222 minecraft:red_nether_bricks
fill 305 -6 221 306 -6 221 minecraft:red_nether_bricks
setblock 306 -6 222 minecraft:polished_blackstone
setblock 307 -6 221 minecraft:polished_blackstone
fill 307 -6 222 310 -6 222 minecraft:red_nether_bricks
fill 308 -6 221 311 -6 221 minecraft:red_nether_bricks
fill 309 -6 220 312 -6 220 minecraft:red_nether_bricks
setblock 310 -6 182 minecraft:red_nether_bricks
setblock 311 -6 182 minecraft:polished_blackstone
setblock 311 -6 222 minecraft:polished_blackstone
fill 312 -6 182 315 -6 182 minecraft:red_nether_bricks
setblock 312 -6 221 minecraft:polished_blackstone
fill 312 -6 222 312 -3 222 minecraft:red_nether_bricks
fill 313 -6 221 313 -3 221 minecraft:red_nether_bricks
fill 315 -6 221 315 -5 221 minecraft:red_nether_bricks
setblock 316 -6 222 minecraft:polished_blackstone
fill 317 -6 222 317 -3 222 minecraft:red_nether_bricks
setblock 322 -6 196 minecraft:polished_blackstone
fill 322 -6 197 322 -3 197 minecraft:red_nether_bricks
fill 322 -6 199 322 -5 199 minecraft:red_nether_bricks
setblock 323 -6 190 minecraft:polished_blackstone
fill 323 -6 191 323 -3 191 minecraft:red_nether_bricks
setblock 323 -6 195 minecraft:polished_blackstone
fill 323 -6 196 323 -3 196 minecraft:red_nether_bricks
setblock 323 -6 200 minecraft:polished_blackstone
fill 323 -6 201 323 -3 201 minecraft:red_nether_bricks
setblock 283 -5 184 minecraft:polished_blackstone
fill 283 -5 185 283 -2 185 minecraft:red_nether_bricks
setblock 283 -5 194 minecraft:polished_blackstone
fill 283 -5 195 283 -2 195 minecraft:red_nether_bricks
setblock 283 -5 199 minecraft:polished_blackstone
fill 283 -5 200 283 -2 200 minecraft:red_nether_bricks
fill 283 -5 216 283 -5 218 minecraft:red_nether_bricks
setblock 283 -5 219 minecraft:polished_blackstone
fill 283 -5 220 283 -3 221 minecraft:red_nether_bricks
setblock 284 -5 182 minecraft:red_nether_bricks
setblock 284 -5 217 minecraft:red_nether_bricks
setblock 284 -5 218 minecraft:polished_blackstone
fill 284 -5 219 285 -3 219 minecraft:red_nether_bricks
fill 284 -5 221 285 -5 221 minecraft:red_nether_bricks
setblock 285 -5 182 minecraft:polished_blackstone
fill 285 -5 183 286 -3 183 minecraft:red_nether_bricks
fill 285 -5 220 286 -5 220 minecraft:red_nether_bricks
setblock 285 -5 222 minecraft:polished_blackstone
fill 286 -5 182 286 -2 182 minecraft:red_nether_bricks
setblock 286 -5 221 minecraft:polished_blackstone
fill 286 -5 222 289 -5 222 minecraft:red_nether_bricks
setblock 287 -5 220 minecraft:polished_blackstone
fill 287 -5 221 287 -2 221 minecraft:red_nether_bricks
setblock 288 -5 183 minecraft:red_nether_bricks
setblock 288 -5 219 minecraft:polished_blackstone
fill 288 -5 220 288 -2 220 minecraft:red_nether_bricks
setblock 289 -5 183 minecraft:polished_blackstone
fill 289 -5 219 292 -5 219 minecraft:red_nether_bricks
setblock 290 -5 182 minecraft:polished_blackstone
fill 290 -5 183 290 -2 183 minecraft:red_nether_bricks
setblock 290 -5 222 minecraft:polished_blackstone
fill 291 -5 182 291 -2 182 minecraft:red_nether_bricks
setblock 291 -5 221 minecraft:polished_blackstone
fill 291 -5 222 291 -2 222 minecraft:red_nether_bricks
setblock 292 -5 220 minecraft:polished_blackstone
fill 292 -5 221 292 -2 221 minecraft:red_nether_bricks
setblock 293 -5 219 minecraft:polished_blackstone
fill 293 -5 220 293 -2 220 minecraft:red_nether_bricks
setblock 294 -5 183 minecraft:polished_blackstone
fill 294 -5 219 294 -2 219 minecraft:red_nether_bricks
setblock 295 -5 182 minecraft:polished_blackstone
setblock 295 -5 222 minecraft:polished_blackstone
fill 296 -5 182 297 -3 182 minecraft:red_nether_bricks
setblock 296 -5 219 minecraft:red_nether_bricks
setblock 296 -5 221 minecraft:polished_blackstone
fill 296 -5 222 296 -2 222 minecraft:red_nether_bricks
setblock 297 -5 220 minecraft:polished_blackstone
fill 297 -5 221 297 -2 221 minecraft:red_nether_bricks
fill 298 -5 220 298 -3 220 minecraft:red_nether_bricks
setblock 300 -5 222 minecraft:polished_blackstone
setblock 301 -5 221 minecraft:polished_blackstone
fill 301 -5 222 304 -5 222 minecraft:red_nether_bricks
fill 302 -5 221 305 -5 221 minecraft:red_nether_bricks
setblock 305 -5 222 minecraft:polished_blackstone
setblock 306 -5 221 minecraft:polished_blackstone
fill 306 -5 222 309 -5 222 minecraft:red_nether_bricks
setblock 307 -5 220 minecraft:polished_blackstone
fill 307 -5 221 310 -5 221 minecraft:red_nether_bricks
fill 308 -5 182 309 -5 182 minecraft:red_nether_bricks
fill 308 -5 220 311 -5 220 minecraft:red_nether_bricks
setblock 310 -5 182 minecraft:polished_blackstone
setblock 310 -5 222 minecraft:polished_blackstone
fill 311 -5 182 314 -5 182 minecraft:red_nether_bricks
setblock 311 -5 221 minecraft:polished_blackstone
fill 311 -5 222 311 -2 222 minecraft:red_nether_bricks
setblock 312 -5 220 minecraft:polished_blackstone
fill 312 -5 221 312 -2 221 minecraft:red_nether_bricks
setblock 315 -5 182 minecraft:polished_blackstone
setblock 315 -5 222 minecraft:polished_blackstone
fill 316 -5 182 317 -3 182 minecraft:red_nether_bricks
fill 316 -5 222 316 -2 222 minecraft:red_nether_bricks
setblock 322 -5 195 minecraft:polished_blackstone
fill 322 -5 196 322 -2 196 minecraft:red_nether_bricks
setblock 322 -5 200 minecraft:polished_blackstone
fill 323 -5 182 323 -4 182 minecraft:red_nether_bricks
setblock 323 -5 189 minecraft:polished_blackstone
fill 323 -5 190 323 -2 190 minecraft:red_nether_bricks
setblock 323 -5 194 minecraft:polished_blackstone
fill 323 -5 195 323 -2 195 minecraft:red_nether_bricks
setblock 323 -5 199 minecraft:polished_blackstone
fill 323 -5 200 323 -2 200 minecraft:red_nether_bricks
fill 323 -5 202 323 -4 202 minecraft:red_nether_bricks
setblock 323 -5 219 minecraft:polished_blackstone
fill 323 -5 220 323 -4 222 minecraft:red_nether_bricks
setblock 283 -4 182 minecraft:red_nether_bricks
setblock 283 -4 183 minecraft:polished_blackstone
fill 283 -4 184 284 -2 184 minecraft:red_nether_bricks
fill 283 -4 186 283 -4 187 minecraft:red_nether_bricks
setblock 283 -4 188 minecraft:polished_blackstone
fill 283 -4 189 283 -2 190 minecraft:red_nether_bricks
setblock 283 -4 193 minecraft:polished_blackstone
fill 283 -4 194 283 -1 194 minecraft:red_nether_bricks
setblock 283 -4 197 minecraft:red_nether_bricks
setblock 283 -4 198 minecraft:polished_blackstone
fill 283 -4 199 283 -1 199 minecraft:red_nether_bricks
fill 283 -4 201 283 -3 201 minecraft:red_nether_bricks
fill 283 -4 215 283 -4 217 minecraft:red_nether_bricks
setblock 283 -4 218 minecraft:polished_blackstone
fill 283 -4 219 283 -1 219 minecraft:red_nether_bricks
setblock 283 -4 222 minecraft:red_nether_bricks
setblock 284 -4 182 minecraft:polished_blackstone
fill 284 -4 183 284 -1 183 minecraft:red_nether_bricks
setblock 284 -4 196 minecraft:red_nether_bricks
setblock 284 -4 197 minecraft:polished_blackstone
fill 284 -4 198 284 -1 198 minecraft:red_nether_bricks
setblock 284 -4 217 minecraft:polished_blackstone
fill 284 -4 218 285 -2 218 minecraft:red_nether_bricks
setblock 284 -4 221 minecraft:red_nether_bricks
setblock 284 -4 222 minecraft:polished_blackstone
fill 285 -4 182 285 -1 182 minecraft:red_nether_bricks
setblock 285 -4 184 minecraft:light[level=14]
setblock 285 -4 192 minecraft:light[level=14]
setblock 285 -4 200 minecraft:light[level=14]
setblock 285 -4 208 minecraft:light[level=14]
setblock 285 -4 216 minecraft:light[level=14]
setblock 285 -4 220 minecraft:red_nether_bricks
setblock 285 -4 221 minecraft:polished_blackstone
fill 285 -4 222 288 -4 222 minecraft:red_nether_bricks
setblock 286 -4 220 minecraft:polished_blackstone
fill 286 -4 221 286 -1 221 minecraft:red_nether_bricks
setblock 287 -4 219 minecraft:polished_blackstone
fill 287 -4 220 287 -1 220 minecraft:red_nether_bricks
setblock 288 -4 183 minecraft:polished_blackstone
fill 288 -4 219 291 -4 219 minecraft:red_nether_bricks
setblock 289 -4 182 minecraft:polished_blackstone
fill 289 -4 183 289 -2 184 minecraft:red_nether_bricks
setblock 289 -4 222 minecraft:polished_blackstone
fill 290 -4 182 290 -1 182 minecraft:red_nether_bricks
setblock 290 -4 221 minecraft:polished_blackstone
fill 290 -4 222 290 -1 222 minecraft:red_nether_bricks
setblock 291 -4 220 minecraft:polished_blackstone
fill 291 -4 221 291 -1 221 minecraft:red_nether_bricks
setblock 292 -4 183 minecraft:red_nether_bricks
setblock 292 -4 219 minecraft:polished_blackstone
fill 292 -4 220 292 -1 220 minecraft:red_nether_bricks
setblock 293 -4 183 minecraft:polished_blackstone
setblock 293 -4 184 minecraft:light[level=14]
setblock 293 -4 192 minecraft:light[level=14]
setblock 293 -4 200 minecraft:light[level=14]
setblock 293 -4 208 minecraft:light[level=14]
setblock 293 -4 216 minecraft:light[level=14]
fill 293 -4 219 293 -1 219 minecraft:red_nether_bricks
setblock 294 -4 182 minecraft:polished_blackstone
fill 294 -4 183 294 -1 183 minecraft:red_nether_bricks
setblock 294 -4 222 minecraft:polished_blackstone
fill 295 -4 182 295 -1 182 minecraft:red_nether_bricks
setblock 295 -4 221 minecraft:polished_blackstone
fill 295 -4 222 295 -1 222 minecraft:red_nether_bricks
setblock 296 -4 220 minecraft:polished_blackstone
fill 296 -4 221 296 -1 221 minecraft:red_nether_bricks
fill 297 -4 220 297 -2 220 minecraft:red_nether_bricks
setblock 299 -4 221 minecraft:red_nether_bricks
setblock 299 -4 222 minecraft:polished_blackstone
setblock 300 -4 221 minecraft:polished_blackstone
fill 300 -4 222 303 -4 222 minecraft:red_nether_bricks
setblock 301 -4 184 minecraft:light[level=14]
setblock 301 -4 192 minecraft:light[level=14]
setblock 301 -4 200 minecraft:light[level=14]
setblock 301 -4 208 minecraft:light[level=14]
setblock 301 -4 216 minecraft:light[level=14]
fill 301 -4 221 304 -4 221 minecraft:red_nether_bricks
setblock 304 -4 222 minecraft:polished_blackstone
setblock 305 -4 220 minecraft:red_nether_bricks
setblock 305 -4 221 minecraft:polished_blackstone
fill 305 -4 222 308 -4 222 minecraft:red_nether_bricks
fill 306 -4 182 308 -4 182 minecraft:red_nether_bricks
setblock 306 -4 220 minecraft:polished_blackstone
fill 306 -4 221 309 -4 221 minecraft:red_nether_bricks
fill 307 -4 220 310 -4 220 minecraft:red_nether_bricks
setblock 309 -4 182 minecraft:polished_blackstone
setblock 309 -4 184 minecraft:light[level=14]
setblock 309 -4 192 minecraft:light[level=14]
setblock 309 -4 200 minecraft:light[level=14]
setblock 309 -4 208 minecraft:light[level=14]
setblock 309 -4 216 minecraft:light[level=14]
setblock 309 -4 222 minecraft:polished_blackstone
fill 310 -4 182 313 -4 182 minecraft:red_nether_bricks
setblock 310 -4 221 minecraft:polished_blackstone
fill 310 -4 222 310 -1 222 minecraft:red_nether_bricks
setblock 311 -4 220 minecraft:polished_blackstone
fill 311 -4 221 311 -1 221 minecraft:red_nether_bricks
fill 312 -4 220 313 -4 220 minecraft:red_nether_bricks
setblock 314 -4 182 minecraft:polished_blackstone
setblock 314 -4 222 minecraft:polished_blackstone
fill 315 -4 182 315 -1 182 minecraft:red_nether_bricks
setblock 315 -4 221 minecraft:polished_blackstone
fill 315 -4 222 315 -1 222 minecraft:red_nether_bricks
setblock 317 -4 184 minecraft:light[level=14]
setblock 317 -4 192 minecraft:light[level=14]
setblock 317 -4 200 minecraft:light[level=14]
setblock 317 -4 208 minecraft:light[level=14]
setblock 317 -4 216 minecraft:light[level=14]
setblock 318 -4 182 minecraft:red_nether_bricks
setblock 318 -4 222 minecraft:red_nether_bricks
setblock 319 -4 182 minecraft:polished_blackstone
setblock 319 -4 222 minecraft:polished_blackstone
fill 320 -4 182 322 -3 182 minecraft:red_nether_bricks
fill 321 -4 222 322 -3 222 minecraft:red_nether_bricks
setblock 322 -4 194 minecraft:polished_blackstone
fill 322 -4 195 322 -1 195 minecraft:red_nether_bricks
setblock 322 -4 199 minecraft:polished_blackstone
fill 322 -4 200 322 -2 201 minecraft:red_nether_bricks
setblock 323 -4 183 minecraft:polished_blackstone
fill 323 -4 184 323 -4 187 minecraft:red_nether_bricks
setblock 323 -4 188 minecraft:polished_blackstone
fill 323 -4 189 323 -1 189 minecraft:red_nether_bricks
setblock 323 -4 193 minecraft:polished_blackstone
fill 323 -4 194 323 -1 194 minecraft:red_nether_bricks
setblock 323 -4 198 minecraft:polished_blackstone
fill 323 -4 199 323 -1 199 minecraft:red_nether_bricks
setblock 323 -4 203 minecraft:polished_blackstone
setblock 323 -4 218 minecraft:polished_blackstone
fill 323 -4 219 323 -1 219 minecraft:red_nether_bricks
setblock 283 -3 182 minecraft:polished_blackstone
fill 283 -3 183 283 0 183 minecraft:red_nether_bricks
setblock 283 -3 186 minecraft:red_nether_bricks
setblock 283 -3 187 minecraft:polished_blackstone
fill 283 -3 188 283 0 188 minecraft:red_nether_bricks
setblock 283 -3 192 minecraft:polished_blackstone
fill 283 -3 193 283 -1 193 minecraft:red_nether_bricks
setblock 283 -3 197 minecraft:polished_blackstone
fill 283 -3 198 283 0 198 minecraft:red_nether_bricks
setblock 283 -3 202 minecraft:polished_blackstone
fill 283 -3 203 283 0 203 minecraft:red_nether_bricks
fill 283 -3 215 283 -3 216 minecraft:red_nether_bricks
setblock 283 -3 217 minecraft:polished_blackstone
fill 283 -3 218 283 0 218 minecraft:red_nether_bricks
setblock 283 -3 222 minecraft:polished_blackstone
fill 284 -3 182 284 0 182 minecraft:red_nether_bricks
setblock 284 -3 185 minecraft:red_nether_bricks
setblock 284 -3 196 minecraft:polished_blackstone
fill 284 -3 197 284 -2 197 minecraft:red_nether_bricks
fill 284 -3 199 284 -3 200 minecraft:red_nether_bricks
fill 284 -3 205 284 -3 207 minecraft:polished_blackstone
setblock 284 -3 216 minecraft:polished_blackstone
fill 284 -3 217 284 0 217 minecraft:red_nether_bricks
setblock 284 -3 221 minecraft:polished_blackstone
fill 284 -3 222 287 -3 222 minecraft:red_nether_bricks
fill 285 -3 205 286 -3 205 minecraft:polished_blackstone
fill 285 -3 207 286 -3 207 minecraft:polished_blackstone
setblock 285 -3 220 minecraft:polished_blackstone
fill 285 -3 221 285 0 221 minecraft:red_nether_bricks
setblock 286 -3 184 minecraft:polished_blackstone
setblock 286 -3 206 minecraft:polished_blackstone
setblock 286 -3 219 minecraft:polished_blackstone
fill 286 -3 220 286 0 220 minecraft:red_nether_bricks
setblock 287 -3 182 minecraft:red_nether_bricks
setblock 287 -3 183 minecraft:polished_blackstone
fill 287 -3 184 288 -1 184 minecraft:red_nether_bricks
fill 287 -3 219 290 -3 219 minecraft:red_nether_bricks
setblock 288 -3 182 minecraft:polished_blackstone
fill 288 -3 183 288 0 183 minecraft:red_nether_bricks
setblock 288 -3 222 minecraft:polished_blackstone
fill 289 -3 182 289 0 182 minecraft:red_nether_bricks
setblock 289 -3 221 minecraft:polished_blackstone
fill 289 -3 222 289 0 222 minecraft:red_nether_bricks
setblock 290 -3 184 minecraft:red_nether_bricks
setblock 290 -3 220 minecraft:polished_blackstone
fill 290 -3 221 290 0 221 minecraft:red_nether_bricks
setblock 291 -3 219 minecraft:polished_blackstone
fill 291 -3 220 291 0 220 minecraft:red_nether_bricks
setblock 292 -3 183 minecraft:polished_blackstone
fill 292 -3 219 292 -1 219 minecraft:red_nether_bricks
setblock 293 -3 182 minecraft:polished_blackstone
fill 293 -3 183 293 0 183 minecraft:red_nether_bricks
setblock 293 -3 222 minecraft:polished_blackstone
fill 294 -3 182 294 0 182 minecraft:red_nether_bricks
setblock 294 -3 221 minecraft:polished_blackstone
fill 294 -3 222 294 0 222 minecraft:red_nether_bricks
setblock 295 -3 220 minecraft:polished_blackstone
fill 295 -3 221 295 0 221 minecraft:red_nether_bricks
fill 296 -3 220 296 -1 220 minecraft:red_nether_bricks
setblock 298 -3 222 minecraft:polished_blackstone
setblock 299 -3 221 minecraft:polished_blackstone
fill 299 -3 222 302 -3 222 minecraft:red_nether_bricks
fill 300 -3 221 303 -3 221 minecraft:red_nether_bricks
setblock 303 -3 222 minecraft:polished_blackstone
fill 304 -3 182 307 -3 182 minecraft:red_nether_bricks
setblock 304 -3 221 minecraft:polished_blackstone
fill 304 -3 222 307 -3 222 minecraft:red_nether_bricks
setblock 305 -3 220 minecraft:polished_blackstone
fill 305 -3 221 308 -3 221 minecraft:red_nether_bricks
fill 306 -3 220 309 -3 220 minecraft:red_nether_bricks
setblock 308 -3 182 minecraft:polished_blackstone
setblock 308 -3 222 minecraft:polished_blackstone
fill 309 -3 182 311 -3 183 minecraft:red_nether_bricks
setblock 309 -3 221 minecraft:polished_blackstone
fill 309 -3 222 309 0 222 minecraft:red_nether_bricks
setblock 310 -3 220 minecraft:polished_blackstone
fill 310 -3 221 310 0 221 minecraft:red_nether_bricks
fill 311 -3 220 312 -3 220 minecraft:red_nether_bricks
setblock 312 -3 182 minecraft:red_nether_bricks
setblock 312 -3 183 minecraft:polished_blackstone
setblock 313 -3 182 minecraft:polished_blackstone
fill 313 -3 183 313 0 183 minecraft:red_nether_bricks
setblock 313 -3 222 minecraft:polished_blackstone
fill 314 -3 182 314 0 182 minecraft:red_nether_bricks
setblock 314 -3 221 minecraft:polished_blackstone
fill 314 -3 222 314 0 222 minecraft:red_nether_bricks
setblock 315 -3 221 minecraft:red_nether_bricks
setblock 318 -3 182 minecraft:polished_blackstone
setblock 318 -3 222 minecraft:polished_blackstone
fill 319 -3 182 319 0 182 minecraft:red_nether_bricks
fill 319 -3 222 320 -1 222 minecraft:red_nether_bricks
setblock 322 -3 193 minecraft:polished_blackstone
fill 322 -3 194 322 -2 194 minecraft:red_nether_bricks
setblock 322 -3 198 minecraft:polished_blackstone
fill 322 -3 199 322 0 199 minecraft:red_nether_bricks
setblock 322 -3 202 minecraft:red_nether_bricks
setblock 323 -3 182 minecraft:polished_blackstone
fill 323 -3 183 323 -3 186 minecraft:red_nether_bricks
setblock 323 -3 187 minecraft:polished_blackstone
fill 323 -3 188 323 0 188 minecraft:red_nether_bricks
setblock 323 -3 192 minecraft:polished_blackstone
fill 323 -3 193 323 0 193 minecraft:red_nether_bricks
setblock 323 -3 197 minecraft:polished_blackstone
fill 323 -3 198 323 0 198 minecraft:red_nether_bricks
setblock 323 -3 202 minecraft:polished_blackstone
fill 323 -3 203 323 -1 204 minecraft:red_nether_bricks
fill 323 -3 218 323 0 218 minecraft:red_nether_bricks
fill 323 -3 220 323 -3 221 minecraft:red_nether_bricks
setblock 323 -3 222 minecraft:polished_blackstone
fill 283 -2 182 283 1 182 minecraft:red_nether_bricks
setblock 283 -2 186 minecraft:polished_blackstone
fill 283 -2 187 283 1 187 minecraft:red_nether_bricks
setblock 283 -2 191 minecraft:polished_blackstone
setblock 283 -2 192 minecraft:red_nether_bricks
setblock 283 -2 196 minecraft:polished_blackstone
fill 283 -2 197 283 1 197 minecraft:red_nether_bricks
setblock 283 -2 201 minecraft:polished_blackstone
fill 283 -2 202 283 1 202 minecraft:red_nether_bricks
fill 283 -2 204 283 -1 204 minecraft:red_nether_bricks
setblock 283 -2 215 minecraft:red_nether_bricks
setblock 283 -2 216 minecraft:polished_blackstone
fill 283 -2 217 283 1 217 minecraft:red_nether_bricks
setblock 283 -2 220 minecraft:red_nether_bricks
setblock 283 -2 221 minecraft:polished_blackstone
fill 283 -2 222 286 -2 222 minecraft:red_nether_bricks
setblock 284 -2 185 minecraft:polished_blackstone
fill 284 -2 186 284 1 186 minecraft:red_nether_bricks
setblock 284 -2 199 minecraft:red_nether_bricks
setblock 284 -2 200 minecraft:polished_blackstone
fill 284 -2 201 284 1 201 minecraft:red_nether_bricks
fill 284 -2 216 284 -1 216 minecraft:red_nether_bricks
setblock 284 -2 219 minecraft:red_nether_bricks
setblock 284 -2 220 minecraft:polished_blackstone
fill 284 -2 221 284 1 221 minecraft:red_nether_bricks
setblock 285 -2 183 minecraft:red_nether_bricks
setblock 285 -2 184 minecraft:polished_blackstone
setblock 285 -2 217 minecraft:red_nether_bricks
setblock 285 -2 219 minecraft:polished_blackstone
fill 285 -2 220 285 1 220 minecraft:red_nether_bricks
setblock 286 -2 183 minecraft:polished_blackstone
fill 286 -2 184 286 1 184 minecraft:red_nether_bricks
fill 286 -2 219 289 -2 219 minecraft:red_nether_bricks
setblock 287 -2 182 minecraft:polished_blackstone
fill 287 -2 183 287 1 183 minecraft:red_nether_bricks
setblock 287 -2 222 minecraft:polished_blackstone
fill 288 -2 182 288 1 182 minecraft:red_nether_bricks
setblock 288 -2 221 minecraft:polished_blackstone
fill 288 -2 222 288 1 222 minecraft:red_nether_bricks
setblock 289 -2 220 minecraft:polished_blackstone
fill 289 -2 221 289 1 221 minecraft:red_nether_bricks
setblock 290 -2 184 minecraft:polished_blackstone
setblock 290 -2 219 minecraft:polished_blackstone
fill 290 -2 220 290 1 220 minecraft:red_nether_bricks
setblock 291 -2 183 minecraft:polished_blackstone
setblock 291 -2 184 minecraft:red_nether_bricks
fill 291 -2 219 291 0 219 minecraft:red_nether_bricks
setblock 292 -2 182 minecraft:polished_blackstone
fill 292 -2 183 292 1 183 minecraft:red_nether_bricks
setblock 292 -2 222 minecraft:polished_blackstone
fill 293 -2 182 293 1 182 minecraft:red_nether_bricks
setblock 293 -2 221 minecraft:polished_blackstone
fill 293 -2 222 293 1 222 minecraft:red_nether_bricks
setblock 294 -2 220 minecraft:polished_blackstone
fill 294 -2 221 294 1 221 minecraft:red_nether_bricks
fill 295 -2 220 295 -1 220 minecraft:red_nether_bricks
setblock 296 -2 182 minecraft:red_nether_bricks
setblock 297 -2 182 minecraft:polished_blackstone
setblock 297 -2 222 minecraft:polished_blackstone
setblock 298 -2 182 minecraft:red_nether_bricks
setblock 298 -2 221 minecraft:polished_blackstone
fill 298 -2 222 301 -2 222 minecraft:red_nether_bricks
fill 299 -2 221 302 -2 221 minecraft:red_nether_bricks
setblock 302 -2 222 minecraft:polished_blackstone
fill 303 -2 182 306 -2 182 minecraft:red_nether_bricks
setblock 303 -2 221 minecraft:polished_blackstone
fill 303 -2 222 306 -2 222 minecraft:red_nether_bricks
fill 304 -2 221 307 -2 221 minecraft:red_nether_bricks
fill 305 -2 220 308 -2 220 minecraft:red_nether_bricks
setblock 307 -2 182 minecraft:polished_blackstone
fill 307 -2 183 310 -2 183 minecraft:red_nether_bricks
setblock 307 -2 222 minecraft:polished_blackstone
fill 308 -2 182 311 -2 182 minecraft:red_nether_bricks
setblock 308 -2 221 minecraft:polished_blackstone
fill 308 -2 222 308 1 222 minecraft:red_nether_bricks
setblock 309 -2 220 minecraft:polished_blackstone
fill 309 -2 221 309 1 221 minecraft:red_nether_bricks
fill 310 -2 220 311 -2 220 minecraft:red_nether_bricks
setblock 311 -2 183 minecraft:polished_blackstone
setblock 312 -2 182 minecraft:polished_blackstone
fill 312 -2 183 312 1 183 minecraft:red_nether_bricks
setblock 312 -2 222 minecraft:polished_blackstone
fill 313 -2 182 313 1 182 minecraft:red_nether_bricks
setblock 313 -2 221 minecraft:polished_blackstone
fill 313 -2 222 313 1 222 minecraft:red_nether_bricks
fill 314 -2 183 314 -1 183 minecraft:red_nether_bricks
setblock 314 -2 221 minecraft:red_nether_bricks
setblock 316 -2 182 minecraft:red_nether_bricks
setblock 317 -2 182 minecraft:polished_blackstone
setblock 317 -2 222 minecraft:polished_blackstone
fill 318 -2 182 318 1 182 minecraft:red_nether_bricks
fill 318 -2 222 318 -1 222 minecraft:red_nether_bricks
fill 320 -2 182 321 -2 182 minecraft:red_nether_bricks
setblock 321 -2 222 minecraft:red_nether_bricks
setblock 322 -2 182 minecraft:polished_blackstone
fill 322 -2 183 323 0 183 minecraft:red_nether_bricks
setblock 322 -2 197 minecraft:polished_blackstone
fill 322 -2 198 322 0 198 minecraft:red_nether_bricks
setblock 322 -2 202 minecraft:polished_blackstone
setblock 322 -2 222 minecraft:polished_blackstone
fill 323 -2 182 323 1 182 minecraft:red_nether_bricks
fill 323 -2 184 323 -2 185 minecraft:red_nether_bricks
setblock 323 -2 186 minecraft:polished_blackstone
fill 323 -2 187 323 1 187 minecraft:red_nether_bricks
setblock 323 -2 191 minecraft:polished_blackstone
fill 323 -2 192 323 1 192 minecraft:red_nether_bricks
setblock 323 -2 196 minecraft:polished_blackstone
fill 323 -2 197 323 1 197 minecraft:red_nether_bricks
setblock 323 -2 201 minecraft:polished_blackstone
fill 323 -2 202 323 1 202 minecraft:red_nether_bricks
setblock 323 -2 205 minecraft:red_nether_bricks
setblock 323 -2 220 minecraft:red_nether_bricks
setblock 323 -2 221 minecraft:polished_blackstone
fill 323 -2 222 323 1 222 minecraft:red_nether_bricks
setblock 283 -1 184 minecraft:red_nether_bricks
setblock 283 -1 185 minecraft:polished_blackstone
fill 283 -1 186 283 2 186 minecraft:red_nether_bricks
setblock 283 -1 189 minecraft:red_nether_bricks
setblock 283 -1 190 minecraft:polished_blackstone
setblock 283 -1 195 minecraft:polished_blackstone
fill 283 -1 196 283 0 196 minecraft:red_nether_bricks
setblock 283 -1 200 minecraft:polished_blackstone
fill 283 -1 201 283 2 201 minecraft:red_nether_bricks
setblock 283 -1 205 minecraft:polished_blackstone
setblock 283 -1 215 minecraft:polished_blackstone
fill 283 -1 216 283 2 216 minecraft:red_nether_bricks
setblock 283 -1 220 minecraft:polished_blackstone
fill 283 -1 221 283 1 222 minecraft:red_nether_bricks
setblock 284 -1 184 minecraft:polished_blackstone
fill 284 -1 185 284 2 185 minecraft:red_nether_bricks
setblock 284 -1 199 minecraft:polished_blackstone
fill 284 -1 200 284 0 200 minecraft:red_nether_bricks
fill 284 -1 202 284 0 202 minecraft:red_nether_bricks
setblock 284 -1 218 minecraft:red_nether_bricks
setblock 284 -1 219 minecraft:polished_blackstone
fill 284 -1 220 284 2 220 minecraft:red_nether_bricks
fill 284 -1 222 285 -1 222 minecraft:red_nether_bricks
setblock 285 -1 183 minecraft:polished_blackstone
fill 285 -1 184 285 2 184 minecraft:red_nether_bricks
setblock 285 -1 218 minecraft:polished_blackstone
fill 285 -1 219 288 -1 219 minecraft:red_nether_bricks
setblock 286 -1 182 minecraft:polished_blackstone
fill 286 -1 183 286 2 183 minecraft:red_nether_bricks
setblock 286 -1 222 minecraft:polished_blackstone
fill 287 -1 182 287 2 182 minecraft:red_nether_bricks
setblock 287 -1 221 minecraft:polished_blackstone
fill 287 -1 222 287 2 222 minecraft:red_nether_bricks
setblock 288 -1 220 minecraft:polished_blackstone
fill 288 -1 221 288 2 221 minecraft:red_nether_bricks
setblock 289 -1 183 minecraft:red_nether_bricks
setblock 289 -1 184 minecraft:polished_blackstone
setblock 289 -1 219 minecraft:polished_blackstone
fill 289 -1 220 289 2 220 minecraft:red_nether_bricks
setblock 290 -1 183 minecraft:polished_blackstone
fill 290 -1 184 290 0 184 minecraft:red_nether_bricks
fill 290 -1 219 290 0 219 minecraft:red_nether_bricks
setblock 291 -1 182 minecraft:polished_blackstone
fill 291 -1 183 291 2 183 minecraft:red_nether_bricks
setblock 291 -1 222 minecraft:polished_blackstone
fill 292 -1 182 292 2 182 minecraft:red_nether_bricks
setblock 292 -1 221 minecraft:polished_blackstone
fill 292 -1 222 292 2 222 minecraft:red_nether_bricks
setblock 293 -1 220 minecraft:polished_blackstone
fill 293 -1 221 293 2 221 minecraft:red_nether_bricks
fill 294 -1 220 294 0 220 minecraft:red_nether_bricks
setblock 296 -1 182 minecraft:polished_blackstone
setblock 296 -1 222 minecraft:polished_blackstone
fill 297 -1 182 297 0 182 minecraft:red_nether_bricks
setblock 297 -1 221 minecraft:polished_blackstone
fill 297 -1 222 300 -1 222 minecraft:red_nether_bricks
fill 298 -1 221 301 -1 221 minecraft:red_nether_bricks
setblock 301 -1 222 minecraft:polished_blackstone
fill 302 -1 182 305 -1 182 minecraft:red_nether_bricks
setblock 302 -1 221 minecraft:polished_blackstone
fill 302 -1 222 305 -1 222 minecraft:red_nether_bricks
fill 303 -1 221 306 -1 221 minecraft:red_nether_bricks
fill 305 -1 220 307 -1 220 minecraft:red_nether_bricks
setblock 306 -1 182 minecraft:polished_blackstone
fill 306 -1 183 309 -1 183 minecraft:red_nether_bricks
setblock 306 -1 222 minecraft:polished_blackstone
fill 307 -1 182 310 -1 182 minecraft:red_nether_bricks
setblock 307 -1 221 minecraft:polished_blackstone
fill 307 -1 222 307 2 222 minecraft:red_nether_bricks
setblock 308 -1 220 minecraft:polished_blackstone
fill 308 -1 221 308 2 221 minecraft:red_nether_bricks
fill 309 -1 220 310 -1 220 minecraft:red_nether_bricks
setblock 310 -1 183 minecraft:polished_blackstone
setblock 311 -1 182 minecraft:polished_blackstone
fill 311 -1 183 311 2 183 minecraft:red_nether_bricks
setblock 311 -1 222 minecraft:polished_blackstone
fill 312 -1 182 312 2 182 minecraft:red_nether_bricks
setblock 312 -1 221 minecraft:polished_blackstone
fill 312 -1 222 312 2 222 minecraft:red_nether_bricks
setblock 313 -1 221 minecraft:red_nether_bricks
setblock 316 -1 182 minecraft:polished_blackstone
setblock 316 -1 222 minecraft:polished_blackstone
fill 317 -1 182 317 2 182 minecraft:red_nether_bricks
fill 317 -1 222 317 0 222 minecraft:red_nether_bricks
setblock 320 -1 182 minecraft:red_nether_bricks
setblock 321 -1 182 minecraft:polished_blackstone
fill 321 -1 183 321 2 183 minecraft:red_nether_bricks
setblock 321 -1 222 minecraft:polished_blackstone
fill 322 -1 182 322 2 182 minecraft:red_nether_bricks
fill 322 -1 184 322 -1 185 minecraft:red_nether_bricks
setblock 322 -1 196 minecraft:polished_blackstone
fill 322 -1 197 322 0 197 minecraft:red_nether_bricks
setblock 322 -1 200 minecraft:red_nether_bricks
setblock 322 -1 201 minecraft:polished_blackstone
fill 322 -1 202 322 1 202 minecraft:red_nether_bricks
fill 322 -1 222 322 2 222 minecraft:red_nether_bricks
setblock 323 -1 184 minecraft:red_nether_bricks
setblock 323 -1 185 minecraft:polished_blackstone
fill 323 -1 186 323 2 186 minecraft:red_nether_bricks
setblock 323 -1 190 minecraft:polished_blackstone
fill 323 -1 191 323 2 191 minecraft:red_nether_bricks
setblock 323 -1 195 minecraft:polished_blackstone
fill 323 -1 196 323 2 196 minecraft:red_nether_bricks
setblock 323 -1 200 minecraft:polished_blackstone
fill 323 -1 201 323 2 201 minecraft:red_nether_bricks
setblock 323 -1 205 minecraft:polished_blackstone
setblock 323 -1 220 minecraft:polished_blackstone
fill 323 -1 221 323 2 221 minecraft:red_nether_bricks
setblock 283 0 184 minecraft:polished_blackstone
fill 283 0 185 283 3 185 minecraft:red_nether_bricks
setblock 283 0 189 minecraft:polished_blackstone
setblock 283 0 195 minecraft:red_nether_bricks
setblock 283 0 199 minecraft:polished_blackstone
fill 283 0 200 283 3 200 minecraft:red_nether_bricks
setblock 283 0 204 minecraft:polished_blackstone
fill 283 0 205 283 2 206 minecraft:red_nether_bricks
setblock 283 0 215 minecraft:red_nether_bricks
setblock 283 0 219 minecraft:polished_blackstone
fill 283 0 220 283 3 220 minecraft:red_nether_bricks
setblock 284 0 183 minecraft:polished_blackstone
fill 284 0 184 284 3 184 minecraft:red_nether_bricks
setblock 284 0 187 minecraft:red_nether_bricks
setblock 284 0 199 minecraft:red_nether_bricks
setblock 284 0 203 minecraft:polished_blackstone
setblock 284 0 218 minecraft:polished_blackstone
fill 284 0 219 287 0 219 minecraft:red_nether_bricks
setblock 284 0 222 minecraft:red_nether_bricks
setblock 285 0 182 minecraft:polished_blackstone
fill 285 0 183 285 3 183 minecraft:red_nether_bricks
fill 285 0 185 285 1 185 minecraft:red_nether_bricks
fill 285 0 218 285 1 218 minecraft:red_nether_bricks
setblock 285 0 222 minecraft:polished_blackstone
fill 286 0 182 286 3 182 minecraft:red_nether_bricks
setblock 286 0 221 minecraft:polished_blackstone
fill 286 0 222 286 3 222 minecraft:red_nether_bricks
setblock 287 0 184 minecraft:red_nether_bricks
setblock 287 0 220 minecraft:polished_blackstone
fill 287 0 221 287 3 221 minecraft:red_nether_bricks
setblock 288 0 184 minecraft:polished_blackstone
setblock 288 0 219 minecraft:polished_blackstone
fill 288 0 220 288 3 220 minecraft:red_nether_bricks
setblock 289 0 183 minecraft:polished_blackstone
fill 289 0 184 289 1 184 minecraft:red_nether_bricks
setblock 289 0 219 minecraft:red_nether_bricks
setblock 290 0 182 minecraft:polished_blackstone
fill 290 0 183 290 3 183 minecraft:red_nether_bricks
setblock 290 0 222 minecraft:polished_blackstone
fill 291 0 182 291 3 182 minecraft:red_nether_bricks
setblock 291 0 221 minecraft:polished_blackstone
fill 291 0 222 291 3 222 minecraft:red_nether_bricks
setblock 292 0 220 minecraft:polished_blackstone
fill 292 0 221 292 3 221 minecraft:red_nether_bricks
fill 293 0 220 293 1 220 minecraft:red_nether_bricks
setblock 295 0 182 minecraft:polished_blackstone
setblock 295 0 222 minecraft:polished_blackstone
fill 296 0 182 296 1 182 minecraft:red_nether_bricks
setblock 296 0 221 minecraft:polished_blackstone
fill 296 0 222 299 0 222 minecraft:red_nether_bricks
fill 297 0 221 300 0 221 minecraft:red_nether_bricks
setblock 300 0 222 minecraft:polished_blackstone
setblock 301 0 221 minecraft:polished_blackstone
fill 301 0 222 304 0 222 minecraft:red_nether_bricks
fill 302 0 182 304 0 182 minecraft:red_nether_bricks
fill 302 0 221 305 0 221 minecraft:red_nether_bricks
setblock 305 0 182 minecraft:polished_blackstone
setblock 305 0 222 minecraft:polished_blackstone
fill 306 0 182 308 0 183 minecraft:red_nether_bricks
setblock 306 0 221 minecraft:polished_blackstone
fill 306 0 222 306 3 222 minecraft:red_nether_bricks
fill 307 0 221 307 2 221 minecraft:red_nether_bricks
setblock 309 0 182 minecraft:red_nether_bricks
setblock 309 0 183 minecraft:polished_blackstone
setblock 310 0 182 minecraft:polished_blackstone
fill 310 0 183 310 3 183 minecraft:red_nether_bricks
setblock 310 0 222 minecraft:polished_blackstone
fill 311 0 182 311 3 182 minecraft:red_nether_bricks
setblock 311 0 221 minecraft:polished_blackstone
fill 311 0 222 311 3 222 minecraft:red_nether_bricks
setblock 312 0 221 minecraft:red_nether_bricks
setblock 314 0 183 minecraft:polished_blackstone
setblock 315 0 182 minecraft:polished_blackstone
setblock 315 0 222 minecraft:polished_blackstone
fill 316 0 182 316 3 182 minecraft:red_nether_bricks
setblock 316 0 222 minecraft:red_nether_bricks
setblock 319 0 222 minecraft:red_nether_bricks
setblock 320 0 182 minecraft:polished_blackstone
fill 320 0 183 320 3 183 minecraft:red_nether_bricks
setblock 320 0 222 minecraft:polished_blackstone
fill 321 0 182 321 3 182 minecraft:red_nether_bricks
fill 321 0 222 321 3 222 minecraft:red_nether_bricks
setblock 322 0 184 minecraft:red_nether_bricks
setblock 322 0 185 minecraft:polished_blackstone
fill 322 0 186 322 3 186 minecraft:red_nether_bricks
setblock 322 0 200 minecraft:polished_blackstone
fill 322 0 201 322 1 201 minecraft:red_nether_bricks
setblock 323 0 184 minecraft:polished_blackstone
fill 323 0 185 323 3 185 minecraft:red_nether_bricks
setblock 323 0 189 minecraft:polished_blackstone
fill 323 0 190 323 3 190 minecraft:red_nether_bricks
setblock 323 0 194 minecraft:polished_blackstone
fill 323 0 195 323 3 195 minecraft:red_nether_bricks
setblock 323 0 199 minecraft:polished_blackstone
fill 323 0 200 323 3 200 minecraft:red_nether_bricks
setblock 323 0 203 minecraft:red_nether_bricks
setblock 323 0 204 minecraft:polished_blackstone
fill 323 0 205 323 2 206 minecraft:red_nether_bricks
setblock 323 0 219 minecraft:polished_blackstone
fill 323 0 220 323 3 220 minecraft:red_nether_bricks
setblock 283 1 183 minecraft:polished_blackstone
fill 283 1 184 283 4 184 minecraft:red_nether_bricks
setblock 283 1 188 minecraft:polished_blackstone
fill 283 1 189 283 4 189 minecraft:red_nether_bricks
setblock 283 1 198 minecraft:polished_blackstone
fill 283 1 199 283 2 199 minecraft:red_nether_bricks
setblock 283 1 203 minecraft:polished_blackstone
fill 283 1 204 283 4 204 minecraft:red_nether_bricks
setblock 283 1 207 minecraft:red_nether_bricks
setblock 283 1 218 minecraft:polished_blackstone
fill 283 1 219 285 2 219 minecraft:red_nether_bricks
setblock 284 1 182 minecraft:polished_blackstone
fill 284 1 183 284 4 183 minecraft:red_nether_bricks
setblock 284 1 187 minecraft:polished_blackstone
setblock 284 1 202 minecraft:polished_blackstone
fill 284 1 203 284 4 203 minecraft:red_nether_bricks
setblock 284 1 217 minecraft:polished_blackstone
fill 284 1 218 284 4 218 minecraft:red_nether_bricks
setblock 284 1 222 minecraft:polished_blackstone
fill 285 1 182 285 4 182 minecraft:red_nether_bricks
setblock 285 1 221 minecraft:polished_blackstone
fill 285 1 222 285 4 222 minecraft:red_nether_bricks
setblock 286 1 220 minecraft:polished_blackstone
fill 286 1 221 286 4 221 minecraft:red_nether_bricks
setblock 287 1 184 minecraft:polished_blackstone
fill 287 1 220 287 4 220 minecraft:red_nether_bricks
setblock 288 1 183 minecraft:polished_blackstone
fill 288 1 184 288 3 184 minecraft:red_nether_bricks
setblock 289 1 182 minecraft:polished_blackstone
fill 289 1 183 289 4 183 minecraft:red_nether_bricks
setblock 289 1 222 minecraft:polished_blackstone
fill 290 1 182 290 4 182 minecraft:red_nether_bricks
setblock 290 1 221 minecraft:polished_blackstone
fill 290 1 222 290 4 222 minecraft:red_nether_bricks
setblock 291 1 220 minecraft:polished_blackstone
fill 291 1 221 291 4 221 minecraft:red_nether_bricks
setblock 292 1 220 minecraft:red_nether_bricks
setblock 294 1 182 minecraft:polished_blackstone
setblock 294 1 222 minecraft:polished_blackstone
fill 295 1 182 295 2 182 minecraft:red_nether_bricks
setblock 295 1 221 minecraft:polished_blackstone
fill 295 1 222 298 1 222 minecraft:red_nether_bricks
setblock 296 1 221 minecraft:red_nether_bricks
setblock 299 1 222 minecraft:polished_blackstone
fill 300 1 222 303 1 222 minecraft:red_nether_bricks
fill 302 1 182 303 1 182 minecraft:red_nether_bricks
fill 303 1 221 304 1 221 minecraft:red_nether_bricks
setblock 304 1 182 minecraft:polished_blackstone
setblock 304 1 222 minecraft:polished_blackstone
fill 305 1 182 307 1 183 minecraft:red_nether_bricks
setblock 305 1 221 minecraft:polished_blackstone
fill 305 1 222 305 4 222 minecraft:red_nether_bricks
fill 306 1 221 306 2 221 minecraft:red_nether_bricks
setblock 308 1 182 minecraft:red_nether_bricks
setblock 308 1 183 minecraft:polished_blackstone
setblock 309 1 182 minecraft:polished_blackstone
fill 309 1 183 309 4 183 minecraft:red_nether_bricks
setblock 309 1 222 minecraft:polished_blackstone
fill 310 1 182 310 4 182 minecraft:red_nether_bricks
setblock 310 1 221 minecraft:polished_blackstone
fill 310 1 222 310 3 222 minecraft:red_nether_bricks
setblock 313 1 183 minecraft:polished_blackstone
setblock 314 1 182 minecraft:polished_blackstone
setblock 314 1 222 minecraft:polished_blackstone
fill 315 1 182 315 4 182 minecraft:red_nether_bricks
setblock 319 1 182 minecraft:polished_blackstone
fill 320 1 182 320 4 182 minecraft:red_nether_bricks
fill 320 1 222 320 2 222 minecraft:red_nether_bricks
setblock 322 1 183 minecraft:red_nether_bricks
setblock 322 1 184 minecraft:polished_blackstone
fill 322 1 185 322 4 185 minecraft:red_nether_bricks
setblock 322 1 199 minecraft:polished_blackstone
setblock 322 1 200 minecraft:red_nether_bricks
setblock 323 1 183 minecraft:polished_blackstone
fill 323 1 184 323 4 184 minecraft:red_nether_bricks
setblock 323 1 188 minecraft:polished_blackstone
fill 323 1 189 323 4 189 minecraft:red_nether_bricks
setblock 323 1 193 minecraft:polished_blackstone
fill 323 1 194 323 3 194 minecraft:red_nether_bricks
setblock 323 1 198 minecraft:polished_blackstone
fill 323 1 199 323 4 199 minecraft:red_nether_bricks
setblock 323 1 203 minecraft:polished_blackstone
fill 323 1 204 323 4 204 minecraft:red_nether_bricks
fill 323 1 219 323 2 219 minecraft:red_nether_bricks
setblock 283 2 182 minecraft:polished_blackstone
fill 283 2 183 283 5 183 minecraft:red_nether_bricks
setblock 283 2 187 minecraft:polished_blackstone
fill 283 2 188 283 5 188 minecraft:red_nether_bricks
setblock 283 2 198 minecraft:red_nether_bricks
setblock 283 2 202 minecraft:polished_blackstone
fill 283 2 203 283 5 203 minecraft:red_nether_bricks
setblock 283 2 207 minecraft:polished_blackstone
fill 283 2 208 283 5 208 minecraft:red_nether_bricks
setblock 283 2 217 minecraft:polished_blackstone
fill 283 2 218 283 5 218 minecraft:red_nether_bricks
setblock 283 2 221 minecraft:red_nether_bricks
setblock 283 2 222 minecraft:polished_blackstone
fill 284 2 182 284 5 182 minecraft:red_nether_bricks
setblock 284 2 186 minecraft:polished_blackstone
fill 284 2 187 284 5 187 minecraft:red_nether_bricks
setblock 284 2 202 minecraft:red_nether_bricks
fill 284 2 204 284 3 204 minecraft:red_nether_bricks
setblock 284 2 217 minecraft:red_nether_bricks
setblock 284 2 221 minecraft:polished_blackstone
fill 284 2 222 284 5 222 minecraft:red_nether_bricks
setblock 285 2 185 minecraft:polished_blackstone
setblock 285 2 220 minecraft:polished_blackstone
fill 285 2 221 285 5 221 minecraft:red_nether_bricks
setblock 286 2 184 minecraft:polished_blackstone
fill 286 2 220 286 4 220 minecraft:red_nether_bricks
setblock 287 2 183 minecraft:polished_blackstone
fill 287 2 184 287 5 184 minecraft:red_nether_bricks
setblock 288 2 182 minecraft:polished_blackstone
fill 288 2 183 288 5 183 minecraft:red_nether_bricks
setblock 288 2 222 minecraft:polished_blackstone
fill 289 2 182 289 5 182 minecraft:red_nether_bricks
setblock 289 2 221 minecraft:polished_blackstone
fill 289 2 222 289 5 222 minecraft:red_nether_bricks
setblock 290 2 220 minecraft:polished_blackstone
fill 290 2 221 290 5 221 minecraft:red_nether_bricks
setblock 291 2 220 minecraft:red_nether_bricks
setblock 292 2 183 minecraft:polished_blackstone
setblock 293 2 182 minecraft:polished_blackstone
setblock 293 2 222 minecraft:polished_blackstone
fill 294 2 182 294 3 182 minecraft:red_nether_bricks
setblock 294 2 221 minecraft:polished_blackstone
fill 294 2 222 297 2 222 minecraft:red_nether_bricks
setblock 298 2 222 minecraft:polished_blackstone
fill 299 2 222 302 2 222 minecraft:red_nether_bricks
setblock 302 2 182 minecraft:red_nether_bricks
setblock 303 2 182 minecraft:polished_blackstone
setblock 303 2 222 minecraft:polished_blackstone
fill 304 2 182 307 2 182 minecraft:red_nether_bricks
setblock 304 2 221 minecraft:polished_blackstone
fill 304 2 222 304 5 222 minecraft:red_nether_bricks
fill 305 2 183 306 2 183 minecraft:red_nether_bricks
setblock 305 2 221 minecraft:red_nether_bricks
setblock 307 2 183 minecraft:polished_blackstone
setblock 308 2 182 minecraft:polished_blackstone
fill 308 2 183 308 5 183 minecraft:red_nether_bricks
setblock 308 2 222 minecraft:polished_blackstone
fill 309 2 182 309 5 182 minecraft:red_nether_bricks
fill 309 2 222 309 4 222 minecraft:red_nether_bricks
setblock 312 2 183 minecraft:polished_blackstone
setblock 313 2 182 minecraft:polished_blackstone
fill 314 2 182 314 5 182 minecraft:red_nether_bricks
setblock 318 2 182 minecraft:polished_blackstone
fill 319 2 182 319 4 183 minecraft:red_nether_bricks
setblock 322 2 183 minecraft:polished_blackstone
fill 322 2 184 322 5 184 minecraft:red_nether_bricks
setblock 322 2 187 minecraft:red_nether_bricks
setblock 323 2 182 minecraft:polished_blackstone
fill 323 2 183 323 5 183 minecraft:red_nether_bricks
setblock 323 2 187 minecraft:polished_blackstone
fill 323 2 188 323 5 188 minecraft:red_nether_bricks
setblock 323 2 192 minecraft:polished_blackstone
fill 323 2 193 323 5 193 minecraft:red_nether_bricks
setblock 323 2 197 minecraft:polished_blackstone
fill 323 2 198 323 5 198 minecraft:red_nether_bricks
setblock 323 2 202 minecraft:polished_blackstone
fill 323 2 203 323 5 203 minecraft:red_nether_bricks
setblock 323 2 222 minecraft:polished_blackstone
fill 283 3 182 283 6 182 minecraft:red_nether_bricks
setblock 283 3 186 minecraft:polished_blackstone
fill 283 3 187 283 6 187 minecraft:red_nether_bricks
setblock 283 3 201 minecraft:polished_blackstone
fill 283 3 202 283 6 202 minecraft:red_nether_bricks
setblock 283 3 205 minecraft:red_nether_bricks
setblock 283 3 206 minecraft:polished_blackstone
fill 283 3 207 283 6 207 minecraft:red_nether_bricks
fill 283 3 209 283 4 209 minecraft:red_nether_bricks
setblock 283 3 216 minecraft:polished_blackstone
fill 283 3 217 283 6 217 minecraft:red_nether_bricks
fill 283 3 219 284 3 219 minecraft:red_nether_bricks
setblock 283 3 221 minecraft:polished_blackstone
fill 283 3 222 283 6 222 minecraft:red_nether_bricks
setblock 284 3 185 minecraft:polished_blackstone
fill 284 3 186 284 6 186 minecraft:red_nether_bricks
setblock 284 3 205 minecraft:polished_blackstone
fill 284 3 206 284 6 206 minecraft:red_nether_bricks
setblock 284 3 220 minecraft:polished_blackstone
fill 284 3 221 284 6 221 minecraft:red_nether_bricks
setblock 285 3 184 minecraft:polished_blackstone
fill 285 3 185 285 6 185 minecraft:red_nether_bricks
fill 285 3 220 285 4 220 minecraft:red_nether_bricks
setblock 286 3 183 minecraft:polished_blackstone
fill 286 3 184 286 6 184 minecraft:red_nether_bricks
setblock 287 3 182 minecraft:polished_blackstone
fill 287 3 183 287 6 183 minecraft:red_nether_bricks
setblock 287 3 222 minecraft:polished_blackstone
fill 288 3 182 288 6 182 minecraft:red_nether_bricks
setblock 288 3 221 minecraft:polished_blackstone
fill 288 3 222 288 6 222 minecraft:red_nether_bricks
setblock 289 3 220 minecraft:polished_blackstone
fill 289 3 221 289 6 221 minecraft:red_nether_bricks
setblock 291 3 183 minecraft:polished_blackstone
setblock 292 3 182 minecraft:polished_blackstone
setblock 292 3 222 minecraft:polished_blackstone
fill 293 3 182 293 4 182 minecraft:red_nether_bricks
fill 293 3 222 296 3 222 minecraft:red_nether_bricks
setblock 297 3 222 minecraft:polished_blackstone
fill 299 3 222 301 3 222 minecraft:red_nether_bricks
setblock 302 3 182 minecraft:polished_blackstone
setblock 302 3 222 minecraft:polished_blackstone
fill 303 3 182 306 3 182 minecraft:red_nether_bricks
fill 303 3 222 303 6 222 minecraft:red_nether_bricks
setblock 305 3 183 minecraft:red_nether_bricks
setblock 306 3 183 minecraft:polished_blackstone
setblock 307 3 182 minecraft:polished_blackstone
fill 307 3 183 307 6 183 minecraft:red_nether_bricks
setblock 307 3 222 minecraft:polished_blackstone
fill 308 3 182 308 6 182 minecraft:red_nether_bricks
fill 308 3 222 308 5 222 minecraft:red_nether_bricks
setblock 311 3 183 minecraft:polished_blackstone
setblock 312 3 182 minecraft:polished_blackstone
fill 313 3 182 313 6 182 minecraft:red_nether_bricks
setblock 317 3 182 minecraft:polished_blackstone
fill 318 3 182 318 6 182 minecraft:red_nether_bricks
setblock 321 3 183 minecraft:polished_blackstone
setblock 322 3 182 minecraft:polished_blackstone
fill 322 3 183 322 6 183 minecraft:red_nether_bricks
setblock 322 3 187 minecraft:polished_blackstone
fill 322 3 188 322 6 188 minecraft:red_nether_bricks
setblock 322 3 222 minecraft:polished_blackstone
fill 323 3 182 323 6 182 minecraft:red_nether_bricks
setblock 323 3 186 minecraft:polished_blackstone
fill 323 3 187 323 6 187 minecraft:red_nether_bricks
setblock 323 3 191 minecraft:polished_blackstone
fill 323 3 192 323 6 192 minecraft:red_nether_bricks
setblock 323 3 196 minecraft:polished_blackstone
fill 323 3 197 323 4 197 minecraft:red_nether_bricks
setblock 323 3 201 minecraft:polished_blackstone
fill 323 3 202 323 6 202 minecraft:red_nether_bricks
setblock 323 3 205 minecraft:red_nether_bricks
setblock 323 3 206 minecraft:polished_blackstone
fill 323 3 207 323 6 207 minecraft:red_nether_bricks
setblock 323 3 221 minecraft:polished_blackstone
fill 323 3 222 323 6 222 minecraft:red_nether_bricks
setblock 283 4 185 minecraft:polished_blackstone
fill 283 4 186 283 7 186 minecraft:red_nether_bricks
setblock 283 4 200 minecraft:polished_blackstone
fill 283 4 201 283 7 201 minecraft:red_nether_bricks
setblock 283 4 205 minecraft:polished_blackstone
fill 283 4 206 283 7 206 minecraft:red_nether_bricks
setblock 283 4 210 minecraft:polished_blackstone
fill 283 4 211 283 7 211 minecraft:red_nether_bricks
fill 283 4 216 283 7 216 minecraft:red_nether_bricks
setblock 283 4 219 minecraft:red_nether_bricks
setblock 283 4 220 minecraft:polished_blackstone
fill 283 4 221 283 7 221 minecraft:red_nether_bricks
setblock 284 4 184 minecraft:polished_blackstone
fill 284 4 185 284 7 185 minecraft:red_nether_bricks
setblock 284 4 204 minecraft:polished_blackstone
fill 284 4 205 284 7 205 minecraft:red_nether_bricks
fill 284 4 207 284 5 207 minecraft:red_nether_bricks
setblock 284 4 219 minecraft:polished_blackstone
fill 284 4 220 284 7 220 minecraft:red_nether_bricks
setblock 285 4 183 minecraft:polished_blackstone
fill 285 4 184 285 7 184 minecraft:red_nether_bricks
setblock 285 4 192 minecraft:light[level=14]
setblock 285 4 200 minecraft:light[level=14]
fill 285 4 205 286 4 205 minecraft:polished_blackstone
fill 285 4 207 286 4 207 minecraft:polished_blackstone
setblock 285 4 208 minecraft:light[level=14]
setblock 285 4 216 minecraft:light[level=14]
setblock 286 4 182 minecraft:polished_blackstone
fill 286 4 183 286 7 183 minecraft:red_nether_bricks
setblock 286 4 206 minecraft:polished_blackstone
setblock 286 4 222 minecraft:polished_blackstone
fill 287 4 182 287 7 182 minecraft:red_nether_bricks
setblock 287 4 221 minecraft:polished_blackstone
fill 287 4 222 287 7 222 minecraft:red_nether_bricks
fill 288 4 221 288 7 221 minecraft:red_nether_bricks
setblock 290 4 183 minecraft:polished_blackstone
setblock 291 4 182 minecraft:polished_blackstone
setblock 291 4 222 minecraft:polished_blackstone
fill 292 4 182 292 5 182 minecraft:red_nether_bricks
fill 292 4 222 294 4 222 minecraft:red_nether_bricks
setblock 293 4 184 minecraft:light[level=14]
setblock 293 4 192 minecraft:light[level=14]
setblock 293 4 200 minecraft:light[level=14]
setblock 293 4 208 minecraft:light[level=14]
setblock 293 4 216 minecraft:light[level=14]
setblock 301 4 182 minecraft:polished_blackstone
setblock 301 4 184 minecraft:light[level=14]
setblock 301 4 192 minecraft:light[level=14]
setblock 301 4 200 minecraft:light[level=14]
setblock 301 4 208 minecraft:light[level=14]
setblock 301 4 216 minecraft:light[level=14]
setblock 301 4 222 minecraft:polished_blackstone
fill 302 4 182 305 4 182 minecraft:red_nether_bricks
fill 302 4 222 302 7 222 minecraft:red_nether_bricks
setblock 304 4 183 minecraft:red_nether_bricks
setblock 305 4 183 minecraft:polished_blackstone
setblock 306 4 182 minecraft:polished_blackstone
fill 306 4 183 306 7 183 minecraft:red_nether_bricks
setblock 306 4 222 minecraft:polished_blackstone
fill 307 4 182 307 7 182 minecraft:red_nether_bricks
fill 307 4 222 307 6 222 minecraft:red_nether_bricks
setblock 309 4 184 minecraft:light[level=14]
setblock 309 4 192 minecraft:light[level=14]
setblock 309 4 200 minecraft:light[level=14]
setblock 309 4 208 minecraft:light[level=14]
setblock 309 4 216 minecraft:light[level=14]
setblock 310 4 183 minecraft:polished_blackstone
setblock 311 4 182 minecraft:polished_blackstone
setblock 311 4 183 minecraft:red_nether_bricks
fill 312 4 182 312 7 182 minecraft:red_nether_bricks
setblock 316 4 182 minecraft:polished_blackstone
fill 317 4 182 317 7 182 minecraft:red_nether_bricks
setblock 317 4 184 minecraft:light[level=14]
setblock 317 4 192 minecraft:light[level=14]
setblock 317 4 200 minecraft:light[level=14]
setblock 317 4 208 minecraft:light[level=14]
setblock 317 4 216 minecraft:light[level=14]
setblock 320 4 183 minecraft:polished_blackstone
setblock 321 4 182 minecraft:polished_blackstone
fill 321 4 183 321 7 183 minecraft:red_nether_bricks
setblock 321 4 222 minecraft:polished_blackstone
fill 322 4 182 322 7 182 minecraft:red_nether_bricks
setblock 322 4 186 minecraft:polished_blackstone
fill 322 4 187 322 7 187 minecraft:red_nether_bricks
fill 322 4 222 322 7 222 minecraft:red_nether_bricks
setblock 323 4 185 minecraft:polished_blackstone
fill 323 4 186 323 7 186 minecraft:red_nether_bricks
setblock 323 4 190 minecraft:polished_blackstone
fill 323 4 191 323 7 191 minecraft:red_nether_bricks
setblock 323 4 200 minecraft:polished_blackstone
fill 323 4 201 323 7 201 minecraft:red_nether_bricks
setblock 323 4 205 minecraft:polished_blackstone
fill 323 4 206 323 7 206 minecraft:red_nether_bricks
fill 323 4 208 323 5 208 minecraft:red_nether_bricks
setblock 323 4 220 minecraft:polished_blackstone
fill 323 4 221 323 7 221 minecraft:red_nether_bricks
setblock 283 5 184 minecraft:polished_blackstone
fill 283 5 185 283 8 185 minecraft:red_nether_bricks
setblock 283 5 189 minecraft:polished_blackstone
fill 283 5 190 283 8 190 minecraft:red_nether_bricks
setblock 283 5 204 minecraft:polished_blackstone
fill 283 5 205 283 8 205 minecraft:red_nether_bricks
setblock 283 5 209 minecraft:polished_blackstone
fill 283 5 210 284 7 210 minecraft:red_nether_bricks
fill 283 5 212 283 5 213 minecraft:red_nether_bricks
setblock 283 5 214 minecraft:polished_blackstone
fill 283 5 215 283 8 215 minecraft:red_nether_bricks
setblock 283 5 219 minecraft:polished_blackstone
fill 283 5 220 283 8 220 minecraft:red_nether_bricks
setblock 284 5 183 minecraft:polished_blackstone
fill 284 5 184 284 8 184 minecraft:red_nether_bricks
setblock 284 5 188 minecraft:polished_blackstone
setblock 284 5 203 minecraft:polished_blackstone
fill 284 5 204 284 8 204 minecraft:red_nether_bricks
setblock 284 5 208 minecraft:polished_blackstone
fill 284 5 209 284 8 209 minecraft:red_nether_bricks
setblock 284 5 218 minecraft:polished_blackstone
fill 284 5 219 284 8 219 minecraft:red_nether_bricks
setblock 285 5 182 minecraft:polished_blackstone
fill 285 5 183 285 8 183 minecraft:red_nether_bricks
setblock 285 5 222 minecraft:polished_blackstone
fill 286 5 182 286 8 182 minecraft:red_nether_bricks
setblock 286 5 221 minecraft:polished_blackstone
fill 286 5 222 286 8 222 minecraft:red_nether_bricks
fill 287 5 221 287 8 221 minecraft:red_nether_bricks
setblock 289 5 183 minecraft:polished_blackstone
setblock 290 5 182 minecraft:polished_blackstone
setblock 290 5 222 minecraft:polished_blackstone
fill 291 5 182 291 7 182 minecraft:red_nether_bricks
fill 291 5 222 293 5 222 minecraft:red_nether_bricks
fill 301 5 182 304 5 182 minecraft:red_nether_bricks
setblock 304 5 183 minecraft:polished_blackstone
setblock 305 5 182 minecraft:polished_blackstone
fill 305 5 183 305 8 183 minecraft:red_nether_bricks
setblock 305 5 222 minecraft:polished_blackstone
fill 306 5 182 306 8 182 minecraft:red_nether_bricks
fill 306 5 222 306 7 222 minecraft:red_nether_bricks
setblock 309 5 183 minecraft:polished_blackstone
setblock 310 5 182 minecraft:polished_blackstone
fill 310 5 183 310 8 183 minecraft:red_nether_bricks
fill 310 5 217 311 6 218 minecraft:blackstone
fill 311 5 182 311 8 182 minecraft:red_nether_bricks
setblock 315 5 182 minecraft:polished_blackstone
fill 316 5 182 316 8 182 minecraft:red_nether_bricks
setblock 318 5 183 minecraft:red_nether_bricks
setblock 319 5 182 minecraft:red_nether_bricks
setblock 319 5 183 minecraft:polished_blackstone
setblock 320 5 182 minecraft:polished_blackstone
fill 320 5 183 320 8 183 minecraft:red_nether_bricks
fill 321 5 182 321 8 182 minecraft:red_nether_bricks
fill 321 5 184 321 5 185 minecraft:red_nether_bricks
fill 321 5 222 321 8 222 minecraft:red_nether_bricks
setblock 322 5 185 minecraft:polished_blackstone
fill 322 5 186 322 8 186 minecraft:red_nether_bricks
setblock 322 5 189 minecraft:red_nether_bricks
setblock 323 5 184 minecraft:polished_blackstone
fill 323 5 185 323 8 185 minecraft:red_nether_bricks
setblock 323 5 189 minecraft:polished_blackstone
fill 323 5 190 323 8 190 minecraft:red_nether_bricks
setblock 323 5 199 minecraft:polished_blackstone
fill 323 5 200 323 8 200 minecraft:red_nether_bricks
setblock 323 5 204 minecraft:polished_blackstone
fill 323 5 205 323 8 205 minecraft:red_nether_bricks
setblock 323 5 209 minecraft:polished_blackstone
fill 323 5 220 323 8 220 minecraft:red_nether_bricks
setblock 283 6 183 minecraft:polished_blackstone
fill 283 6 184 283 9 184 minecraft:red_nether_bricks
setblock 283 6 188 minecraft:polished_blackstone
fill 283 6 189 283 9 189 minecraft:red_nether_bricks
fill 283 6 191 283 7 191 minecraft:red_nether_bricks
setblock 283 6 203 minecraft:polished_blackstone
fill 283 6 204 283 9 204 minecraft:red_nether_bricks
setblock 283 6 208 minecraft:polished_blackstone
fill 283 6 209 283 9 209 minecraft:red_nether_bricks
setblock 283 6 212 minecraft:red_nether_bricks
setblock 283 6 213 minecraft:polished_blackstone
fill 283 6 214 283 9 214 minecraft:red_nether_bricks
setblock 283 6 218 minecraft:polished_blackstone
fill 283 6 219 283 9 219 minecraft:red_nether_bricks
setblock 284 6 182 minecraft:polished_blackstone
fill 284 6 183 284 9 183 minecraft:red_nether_bricks
setblock 284 6 187 minecraft:polished_blackstone
fill 284 6 188 284 9 188 minecraft:red_nether_bricks
fill 284 6 203 284 9 203 minecraft:red_nether_bricks
setblock 284 6 207 minecraft:polished_blackstone
fill 284 6 208 284 9 208 minecraft:red_nether_bricks
setblock 284 6 211 minecraft:red_nether_bricks
setblock 284 6 212 minecraft:polished_blackstone
fill 284 6 218 284 9 218 minecraft:red_nether_bricks
setblock 284 6 222 minecraft:polished_blackstone
fill 285 6 182 285 9 182 minecraft:red_nether_bricks
setblock 285 6 221 minecraft:polished_blackstone
fill 285 6 222 285 9 222 minecraft:red_nether_bricks
fill 286 6 221 286 9 221 minecraft:red_nether_bricks
setblock 288 6 183 minecraft:polished_blackstone
setblock 289 6 182 minecraft:polished_blackstone
fill 289 6 183 289 7 183 minecraft:red_nether_bricks
setblock 289 6 222 minecraft:polished_blackstone
fill 290 6 182 290 9 182 minecraft:red_nether_bricks
fill 290 6 222 292 6 222 minecraft:red_nether_bricks
fill 298 6 195 299 7 195 minecraft:blackstone
fill 301 6 182 303 6 182 minecraft:red_nether_bricks
setblock 303 6 183 minecraft:polished_blackstone
setblock 304 6 182 minecraft:polished_blackstone
fill 304 6 183 304 9 183 minecraft:red_nether_bricks
setblock 304 6 222 minecraft:polished_blackstone
fill 305 6 182 305 9 182 minecraft:red_nether_bricks
fill 305 6 222 305 9 222 minecraft:red_nether_bricks
setblock 308 6 183 minecraft:polished_blackstone
setblock 309 6 182 minecraft:polished_blackstone
fill 309 6 183 309 9 183 minecraft:red_nether_bricks
fill 310 6 182 310 9 182 minecraft:red_nether_bricks
setblock 314 6 182 minecraft:polished_blackstone
fill 315 6 182 315 9 182 minecraft:red_nether_bricks
setblock 318 6 183 minecraft:polished_blackstone
setblock 319 6 182 minecraft:polished_blackstone
fill 319 6 183 319 9 183 minecraft:red_nether_bricks
fill 320 6 182 320 9 182 minecraft:red_nether_bricks
fill 320 6 184 321 6 184 minecraft:red_nether_bricks
setblock 321 6 185 minecraft:polished_blackstone
fill 321 6 186 321 8 187 minecraft:red_nether_bricks
setblock 322 6 184 minecraft:polished_blackstone
fill 322 6 185 322 9 185 minecraft:red_nether_bricks
setblock 322 6 189 minecraft:polished_blackstone
fill 322 6 190 322 9 190 minecraft:red_nether_bricks
setblock 323 6 183 minecraft:polished_blackstone
fill 323 6 184 323 9 184 minecraft:red_nether_bricks
setblock 323 6 188 minecraft:polished_blackstone
fill 323 6 189 323 9 189 minecraft:red_nether_bricks
setblock 323 6 193 minecraft:polished_blackstone
fill 323 6 194 323 9 194 minecraft:red_nether_bricks
fill 323 6 199 323 9 199 minecraft:red_nether_bricks
setblock 323 6 203 minecraft:polished_blackstone
fill 323 6 204 323 9 204 minecraft:red_nether_bricks
setblock 323 6 208 minecraft:polished_blackstone
fill 323 6 209 323 8 210 minecraft:red_nether_bricks
fill 323 6 219 323 9 219 minecraft:red_nether_bricks
setblock 283 7 182 minecraft:polished_blackstone
fill 283 7 183 283 10 183 minecraft:red_nether_bricks
setblock 283 7 187 minecraft:polished_blackstone
fill 283 7 188 283 10 188 minecraft:red_nether_bricks
setblock 283 7 202 minecraft:polished_blackstone
fill 283 7 203 283 10 203 minecraft:red_nether_bricks
setblock 283 7 207 minecraft:polished_blackstone
fill 283 7 208 283 10 208 minecraft:red_nether_bricks
setblock 283 7 212 minecraft:polished_blackstone
fill 283 7 213 284 9 213 minecraft:red_nether_bricks
setblock 283 7 217 minecraft:polished_blackstone
fill 283 7 218 283 10 218 minecraft:red_nether_bricks
setblock 283 7 222 minecraft:polished_blackstone
fill 284 7 182 284 10 182 minecraft:red_nether_bricks
setblock 284 7 186 minecraft:polished_blackstone
fill 284 7 187 284 10 187 minecraft:red_nether_bricks
fill 284 7 189 284 8 189 minecraft:red_nether_bricks
setblock 284 7 206 minecraft:polished_blackstone
fill 284 7 207 285 9 207 minecraft:red_nether_bricks
setblock 284 7 211 minecraft:polished_blackstone
fill 284 7 212 284 10 212 minecraft:red_nether_bricks
fill 284 7 214 284 7 215 minecraft:red_nether_bricks
setblock 284 7 216 minecraft:polished_blackstone
fill 284 7 217 284 10 217 minecraft:red_nether_bricks
setblock 284 7 221 minecraft:polished_blackstone
fill 284 7 222 284 10 222 minecraft:red_nether_bricks
setblock 285 7 185 minecraft:polished_blackstone
fill 285 7 186 285 10 186 minecraft:red_nether_bricks
fill 285 7 206 285 10 206 minecraft:red_nether_bricks
fill 285 7 208 285 7 209 minecraft:red_nether_bricks
setblock 285 7 210 minecraft:polished_blackstone
fill 285 7 221 285 10 221 minecraft:red_nether_bricks
setblock 286 7 184 minecraft:polished_blackstone
setblock 287 7 183 minecraft:polished_blackstone
setblock 288 7 182 minecraft:polished_blackstone
fill 288 7 183 288 9 183 minecraft:red_nether_bricks
setblock 288 7 222 minecraft:polished_blackstone
fill 289 7 182 289 10 182 minecraft:red_nether_bricks
fill 289 7 222 291 7 222 minecraft:red_nether_bricks
fill 300 7 182 302 7 182 minecraft:red_nether_bricks
setblock 302 7 183 minecraft:polished_blackstone
setblock 303 7 182 minecraft:polished_blackstone
fill 303 7 183 303 10 183 minecraft:red_nether_bricks
setblock 303 7 222 minecraft:polished_blackstone
fill 304 7 182 304 10 182 minecraft:red_nether_bricks
fill 304 7 222 304 10 222 minecraft:red_nether_bricks
setblock 307 7 183 minecraft:polished_blackstone
setblock 308 7 182 minecraft:polished_blackstone
fill 308 7 183 308 10 183 minecraft:red_nether_bricks
fill 309 7 182 309 10 182 minecraft:red_nether_bricks
setblock 313 7 182 minecraft:polished_blackstone
fill 314 7 182 314 10 182 minecraft:red_nether_bricks
setblock 317 7 183 minecraft:polished_blackstone
setblock 318 7 182 minecraft:polished_blackstone
fill 318 7 183 318 10 183 minecraft:red_nether_bricks
fill 319 7 182 319 10 182 minecraft:red_nether_bricks
fill 319 7 184 320 7 184 minecraft:red_nether_bricks
fill 320 7 222 320 9 222 minecraft:red_nether_bricks
setblock 321 7 184 minecraft:polished_blackstone
fill 321 7 185 321 10 185 minecraft:red_nether_bricks
setblock 321 7 188 minecraft:red_nether_bricks
setblock 322 7 183 minecraft:polished_blackstone
fill 322 7 184 322 10 184 minecraft:red_nether_bricks
setblock 322 7 188 minecraft:polished_blackstone
fill 322 7 189 322 10 189 minecraft:red_nether_bricks
fill 322 7 191 322 8 191 minecraft:red_nether_bricks
fill 322 7 206 322 8 206 minecraft:red_nether_bricks
setblock 323 7 182 minecraft:polished_blackstone
fill 323 7 183 323 10 183 minecraft:red_nether_bricks
setblock 323 7 187 minecraft:polished_blackstone
fill 323 7 188 323 10 188 minecraft:red_nether_bricks
setblock 323 7 192 minecraft:polished_blackstone
fill 323 7 193 323 10 193 minecraft:red_nether_bricks
fill 323 7 195 323 8 195 minecraft:red_nether_bricks
setblock 323 7 202 minecraft:polished_blackstone
fill 323 7 203 323 10 203 minecraft:red_nether_bricks
setblock 323 7 207 minecraft:polished_blackstone
fill 323 7 208 323 10 208 minecraft:red_nether_bricks
setblock 323 7 211 minecraft:red_nether_bricks
setblock 323 7 212 minecraft:polished_blackstone
fill 323 7 213 323 10 213 minecraft:red_nether_bricks
fill 323 7 218 323 10 218 minecraft:red_nether_bricks
setblock 323 7 222 minecraft:polished_blackstone
fill 283 8 182 283 11 182 minecraft:red_nether_bricks
setblock 283 8 186 minecraft:polished_blackstone
fill 283 8 187 283 11 187 minecraft:red_nether_bricks
setblock 283 8 191 minecraft:polished_blackstone
fill 283 8 192 283 10 193 minecraft:red_nether_bricks
setblock 283 8 200 minecraft:red_nether_bricks
setblock 283 8 201 minecraft:polished_blackstone
fill 283 8 202 283 11 202 minecraft:red_nether_bricks
setblock 283 8 206 minecraft:polished_blackstone
fill 283 8 207 283 11 207 minecraft:red_nether_bricks
setblock 283 8 210 minecraft:red_nether_bricks
setblock 283 8 211 minecraft:polished_blackstone
fill 283 8 212 283 11 212 minecraft:red_nether_bricks
setblock 283 8 216 minecraft:polished_blackstone
fill 283 8 217 283 11 217 minecraft:red_nether_bricks
setblock 283 8 221 minecraft:polished_blackstone
fill 283 8 222 283 11 222 minecraft:red_nether_bricks
setblock 284 8 185 minecraft:polished_blackstone
fill 284 8 186 284 11 186 minecraft:red_nether_bricks
setblock 284 8 190 minecraft:polished_blackstone
setblock 284 8 205 minecraft:polished_blackstone
fill 284 8 206 284 11 206 minecraft:red_nether_bricks
setblock 284 8 210 minecraft:polished_blackstone
fill 284 8 211 285 10 211 minecraft:red_nether_bricks
setblock 284 8 214 minecraft:red_nether_bricks
setblock 284 8 215 minecraft:polished_blackstone
fill 284 8 216 284 11 216 minecraft:red_nether_bricks
setblock 284 8 220 minecraft:polished_blackstone
fill 284 8 221 284 11 221 minecraft:red_nether_bricks
setblock 285 8 184 minecraft:polished_blackstone
fill 285 8 185 285 11 185 minecraft:red_nether_bricks
fill 285 8 187 285 9 187 minecraft:red_nether_bricks
fill 285 8 205 285 11 205 minecraft:red_nether_bricks
setblock 285 8 208 minecraft:red_nether_bricks
setblock 285 8 209 minecraft:polished_blackstone
fill 285 8 210 285 11 210 minecraft:red_nether_bricks
fill 285 8 212 285 8 213 minecraft:red_nether_bricks
setblock 286 8 183 minecraft:polished_blackstone
fill 286 8 184 286 9 184 minecraft:red_nether_bricks
setblock 287 8 182 minecraft:polished_blackstone
fill 287 8 183 287 10 183 minecraft:red_nether_bricks
setblock 287 8 222 minecraft:polished_blackstone
fill 288 8 182 288 11 182 minecraft:red_nether_bricks
setblock 288 8 221 minecraft:polished_blackstone
fill 288 8 222 290 9 222 minecraft:red_nether_bricks
fill 299 8 182 301 8 182 minecraft:red_nether_bricks
setblock 301 8 183 minecraft:polished_blackstone
setblock 302 8 182 minecraft:polished_blackstone
fill 302 8 183 302 11 183 minecraft:red_nether_bricks
setblock 302 8 222 minecraft:polished_blackstone
fill 303 8 182 303 11 182 minecraft:red_nether_bricks
fill 303 8 222 303 11 222 minecraft:red_nether_bricks
setblock 305 8 184 minecraft:polished_blackstone
setblock 306 8 183 minecraft:polished_blackstone
fill 306 8 184 306 11 184 minecraft:red_nether_bricks
setblock 307 8 182 minecraft:polished_blackstone
fill 307 8 183 307 11 183 minecraft:red_nether_bricks
fill 308 8 182 308 11 182 minecraft:red_nether_bricks
setblock 312 8 182 minecraft:polished_blackstone
fill 313 8 182 313 11 182 minecraft:red_nether_bricks
setblock 316 8 183 minecraft:polished_blackstone
setblock 317 8 182 minecraft:polished_blackstone
fill 317 8 183 317 11 183 minecraft:red_nether_bricks
fill 318 8 182 318 11 182 minecraft:red_nether_bricks
fill 318 8 184 319 8 184 minecraft:red_nether_bricks
fill 319 8 222 319 10 222 minecraft:red_nether_bricks
setblock 320 8 184 minecraft:polished_blackstone
setblock 321 8 183 minecraft:polished_blackstone
fill 321 8 184 321 11 184 minecraft:red_nether_bricks
setblock 321 8 188 minecraft:polished_blackstone
fill 321 8 189 321 10 190 minecraft:red_nether_bricks
setblock 322 8 182 minecraft:polished_blackstone
fill 322 8 183 322 11 183 minecraft:red_nether_bricks
setblock 322 8 187 minecraft:polished_blackstone
fill 322 8 188 322 11 188 minecraft:red_nether_bricks
setblock 322 8 192 minecraft:polished_blackstone
fill 322 8 204 322 9 205 minecraft:red_nether_bricks
setblock 322 8 207 minecraft:polished_blackstone
fill 322 8 208 322 9 210 minecraft:red_nether_bricks
setblock 322 8 222 minecraft:polished_blackstone
fill 323 8 182 323 11 182 minecraft:red_nether_bricks
setblock 323 8 186 minecraft:polished_blackstone
fill 323 8 187 323 11 187 minecraft:red_nether_bricks
setblock 323 8 191 minecraft:polished_blackstone
fill 323 8 192 323 11 192 minecraft:red_nether_bricks
setblock 323 8 196 minecraft:polished_blackstone
fill 323 8 197 323 10 198 minecraft:red_nether_bricks
setblock 323 8 201 minecraft:polished_blackstone
schedule function dropper:buildpart/42_2 1t
