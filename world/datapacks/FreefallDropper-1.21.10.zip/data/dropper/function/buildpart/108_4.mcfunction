fill 1 287 492 1 288 492 minecraft:bookshelf
fill 1 287 494 1 288 494 minecraft:bookshelf
fill 1 287 496 1 288 496 minecraft:bookshelf
fill 2 287 465 2 288 465 minecraft:bookshelf
fill 2 287 467 2 288 467 minecraft:bookshelf
fill 2 287 471 2 288 471 minecraft:bookshelf
fill 2 287 487 2 288 487 minecraft:bookshelf
fill 2 287 489 2 288 489 minecraft:bookshelf
fill 2 287 491 2 288 491 minecraft:bookshelf
fill 2 287 493 2 288 493 minecraft:bookshelf
fill 2 287 495 2 288 495 minecraft:bookshelf
fill 3 287 464 3 288 464 minecraft:bookshelf
fill 3 287 466 3 288 466 minecraft:bookshelf
fill 3 287 468 3 288 468 minecraft:bookshelf
fill 3 287 470 3 288 470 minecraft:bookshelf
fill 3 287 472 3 288 472 minecraft:bookshelf
fill 3 287 486 3 288 486 minecraft:bookshelf
fill 3 287 488 3 288 488 minecraft:bookshelf
fill 3 287 490 3 288 490 minecraft:bookshelf
fill 3 287 492 3 288 492 minecraft:bookshelf
fill 3 287 494 3 288 494 minecraft:bookshelf
fill 3 287 496 3 288 496 minecraft:bookshelf
fill 4 287 465 4 288 465 minecraft:bookshelf
fill 4 287 467 4 288 467 minecraft:bookshelf
fill 4 287 469 4 288 469 minecraft:bookshelf
fill 4 287 471 4 288 471 minecraft:bookshelf
fill 4 287 480 5 288 480 minecraft:green_wool
fill 4 287 487 4 288 487 minecraft:bookshelf
fill 4 287 489 4 288 489 minecraft:bookshelf
fill 4 287 491 4 288 491 minecraft:bookshelf
fill 4 287 493 4 288 493 minecraft:bookshelf
fill 4 287 495 4 288 495 minecraft:bookshelf
fill 5 287 464 5 288 464 minecraft:bookshelf
fill 5 287 466 5 288 466 minecraft:bookshelf
fill 5 287 468 5 288 468 minecraft:bookshelf
fill 5 287 470 5 288 470 minecraft:bookshelf
fill 5 287 472 5 288 472 minecraft:bookshelf
fill 5 287 479 5 288 479 minecraft:green_wool
fill 5 287 486 5 288 486 minecraft:bookshelf
fill 5 287 488 5 288 488 minecraft:bookshelf
fill 5 287 490 5 288 490 minecraft:bookshelf
fill 5 287 492 5 288 492 minecraft:bookshelf
fill 5 287 494 5 288 494 minecraft:bookshelf
fill 5 287 496 5 288 496 minecraft:bookshelf
fill 6 287 465 6 288 465 minecraft:bookshelf
fill 6 287 467 6 288 467 minecraft:bookshelf
fill 6 287 469 6 288 469 minecraft:bookshelf
fill 6 287 471 6 288 471 minecraft:bookshelf
fill 6 287 487 6 288 487 minecraft:bookshelf
fill 6 287 489 6 288 489 minecraft:bookshelf
fill 6 287 491 6 288 491 minecraft:bookshelf
fill 6 287 493 6 288 493 minecraft:bookshelf
fill 6 287 495 6 288 495 minecraft:bookshelf
fill 7 287 464 7 288 464 minecraft:bookshelf
fill 7 287 466 7 288 466 minecraft:bookshelf
fill 7 287 468 7 288 468 minecraft:bookshelf
fill 7 287 470 7 288 470 minecraft:bookshelf
fill 7 287 472 7 288 472 minecraft:bookshelf
fill 7 287 486 7 288 486 minecraft:bookshelf
fill 7 287 488 7 288 488 minecraft:bookshelf
fill 7 287 490 7 288 490 minecraft:bookshelf
fill 7 287 492 7 288 492 minecraft:bookshelf
fill 7 287 494 7 288 494 minecraft:bookshelf
fill 7 287 496 7 288 496 minecraft:bookshelf
fill 8 287 465 8 288 465 minecraft:bookshelf
fill 8 287 467 8 288 467 minecraft:bookshelf
fill 8 287 469 8 288 469 minecraft:bookshelf
fill 8 287 471 8 288 471 minecraft:bookshelf
fill 8 287 487 8 288 487 minecraft:bookshelf
fill 8 287 489 8 288 489 minecraft:bookshelf
fill 8 287 491 8 288 491 minecraft:bookshelf
fill 8 287 493 8 288 493 minecraft:bookshelf
fill 9 287 464 9 288 464 minecraft:bookshelf
fill 9 287 466 9 288 466 minecraft:bookshelf
fill 9 287 468 9 288 468 minecraft:bookshelf
fill 9 287 470 9 288 470 minecraft:bookshelf
fill 9 287 472 9 288 472 minecraft:bookshelf
fill 10 287 465 10 288 465 minecraft:bookshelf
fill 10 287 467 10 288 467 minecraft:bookshelf
fill 10 287 469 10 288 469 minecraft:bookshelf
fill 10 287 471 10 288 471 minecraft:bookshelf
fill 11 287 464 11 288 464 minecraft:bookshelf
fill 11 287 466 11 288 466 minecraft:bookshelf
fill 11 287 468 11 288 468 minecraft:bookshelf
fill 11 287 470 11 288 470 minecraft:bookshelf
fill 11 287 472 11 288 472 minecraft:bookshelf
fill 12 287 465 12 288 465 minecraft:bookshelf
fill 12 287 467 12 288 467 minecraft:bookshelf
fill 12 287 469 12 288 469 minecraft:bookshelf
fill 12 287 471 12 288 471 minecraft:bookshelf
fill 13 287 464 13 288 464 minecraft:bookshelf
fill 13 287 466 13 288 466 minecraft:bookshelf
fill 14 287 465 14 288 465 minecraft:bookshelf
fill 14 287 467 14 288 467 minecraft:bookshelf
fill 14 287 497 14 288 497 minecraft:bookshelf
fill 14 287 499 14 288 499 minecraft:bookshelf
fill 14 287 501 14 288 501 minecraft:bookshelf
fill 14 287 503 14 288 503 minecraft:bookshelf
fill 15 287 464 15 288 464 minecraft:bookshelf
fill 15 287 466 15 288 466 minecraft:bookshelf
fill 15 287 496 15 288 496 minecraft:bookshelf
fill 15 287 498 15 288 498 minecraft:bookshelf
fill 15 287 500 15 288 500 minecraft:bookshelf
fill 15 287 502 15 288 502 minecraft:bookshelf
fill 15 287 504 15 288 504 minecraft:bookshelf
fill 16 287 465 16 288 465 minecraft:bookshelf
fill 16 287 467 16 288 467 minecraft:bookshelf
fill 16 287 497 16 288 497 minecraft:bookshelf
fill 16 287 499 16 288 499 minecraft:bookshelf
fill 16 287 501 16 288 501 minecraft:bookshelf
fill 16 287 503 16 288 503 minecraft:bookshelf
fill 17 287 464 17 288 464 minecraft:bookshelf
fill 17 287 466 17 288 466 minecraft:bookshelf
fill 17 287 496 17 288 496 minecraft:bookshelf
fill 17 287 498 17 288 498 minecraft:bookshelf
fill 17 287 500 17 288 500 minecraft:bookshelf
fill 17 287 502 17 288 502 minecraft:bookshelf
fill 17 287 504 17 288 504 minecraft:bookshelf
fill 18 287 465 18 288 465 minecraft:bookshelf
fill 18 287 467 18 288 467 minecraft:bookshelf
fill 18 287 497 18 288 497 minecraft:bookshelf
fill 18 287 499 18 288 499 minecraft:bookshelf
fill 18 287 501 18 288 501 minecraft:bookshelf
fill 18 287 503 18 288 503 minecraft:bookshelf
fill 19 287 464 19 288 464 minecraft:bookshelf
fill 19 287 466 19 288 466 minecraft:bookshelf
fill 19 287 496 19 288 496 minecraft:bookshelf
fill 19 287 498 19 288 498 minecraft:bookshelf
fill 19 287 500 19 288 500 minecraft:bookshelf
fill 19 287 502 19 288 502 minecraft:bookshelf
fill 19 287 504 19 288 504 minecraft:bookshelf
fill 20 287 465 20 288 465 minecraft:bookshelf
fill 20 287 467 20 288 467 minecraft:bookshelf
fill 20 287 495 20 288 495 minecraft:bookshelf
fill 20 287 497 20 288 497 minecraft:bookshelf
fill 20 287 499 20 288 499 minecraft:bookshelf
fill 20 287 501 20 288 501 minecraft:bookshelf
fill 20 287 503 20 288 503 minecraft:bookshelf
fill 21 287 496 21 288 496 minecraft:bookshelf
fill 21 287 498 21 288 498 minecraft:bookshelf
fill 21 287 500 21 288 500 minecraft:bookshelf
fill 21 287 502 21 288 502 minecraft:bookshelf
fill 21 287 504 21 288 504 minecraft:bookshelf
fill 22 287 495 22 288 495 minecraft:bookshelf
fill 22 287 497 22 288 497 minecraft:bookshelf
fill 22 287 499 22 288 499 minecraft:bookshelf
fill 22 287 501 22 288 501 minecraft:bookshelf
fill 22 287 503 22 288 503 minecraft:bookshelf
fill 23 287 496 23 288 496 minecraft:bookshelf
fill 23 287 498 23 288 498 minecraft:bookshelf
fill 23 287 500 23 288 500 minecraft:bookshelf
fill 23 287 502 23 288 502 minecraft:bookshelf
fill 23 287 504 23 288 504 minecraft:bookshelf
fill 24 287 495 24 288 495 minecraft:bookshelf
fill 24 287 497 24 288 497 minecraft:bookshelf
fill 24 287 499 24 288 499 minecraft:bookshelf
fill 24 287 501 24 288 501 minecraft:bookshelf
fill 24 287 503 24 288 503 minecraft:bookshelf
fill 25 287 496 25 288 496 minecraft:bookshelf
fill 25 287 498 25 288 498 minecraft:bookshelf
fill 25 287 500 25 288 500 minecraft:bookshelf
fill 25 287 502 25 288 502 minecraft:bookshelf
fill 25 287 504 25 288 504 minecraft:bookshelf
fill 26 287 495 26 288 495 minecraft:bookshelf
fill 26 287 497 26 288 497 minecraft:bookshelf
fill 26 287 499 26 288 499 minecraft:bookshelf
fill 26 287 501 26 288 501 minecraft:bookshelf
fill 26 287 503 26 288 503 minecraft:bookshelf
fill 33 287 474 33 288 474 minecraft:bookshelf
fill 33 287 476 33 288 476 minecraft:bookshelf
fill 33 287 478 33 288 478 minecraft:bookshelf
fill 33 287 480 33 288 480 minecraft:bookshelf
fill 33 287 482 33 288 482 minecraft:bookshelf
fill 34 287 475 34 288 475 minecraft:bookshelf
fill 34 287 477 34 288 477 minecraft:bookshelf
fill 34 287 479 34 288 479 minecraft:bookshelf
fill 34 287 481 34 288 481 minecraft:bookshelf
fill 35 287 474 35 288 474 minecraft:bookshelf
fill 35 287 476 35 288 476 minecraft:bookshelf
fill 35 287 478 35 288 478 minecraft:bookshelf
fill 35 287 480 35 288 480 minecraft:bookshelf
fill 35 287 482 35 288 482 minecraft:bookshelf
fill 36 287 475 36 288 475 minecraft:bookshelf
fill 36 287 477 36 288 477 minecraft:bookshelf
fill 36 287 479 36 288 479 minecraft:bookshelf
fill 36 287 481 36 288 481 minecraft:bookshelf
fill 37 287 474 37 288 474 minecraft:bookshelf
fill 37 287 476 37 288 476 minecraft:bookshelf
fill 37 287 478 37 288 478 minecraft:bookshelf
fill 37 287 480 37 288 480 minecraft:bookshelf
fill 37 287 482 37 288 482 minecraft:bookshelf
fill 38 287 475 38 288 475 minecraft:bookshelf
fill 38 287 477 38 288 477 minecraft:bookshelf
fill 38 287 479 38 288 479 minecraft:bookshelf
fill 38 287 481 38 288 481 minecraft:bookshelf
fill 39 287 474 39 288 474 minecraft:bookshelf
fill 39 287 476 39 288 476 minecraft:bookshelf
fill 39 287 478 39 288 478 minecraft:bookshelf
fill 39 287 480 39 288 480 minecraft:bookshelf
fill 39 287 482 39 288 482 minecraft:bookshelf
fill 39 287 490 40 287 495 minecraft:bookshelf
fill 40 287 475 40 288 475 minecraft:bookshelf
fill 40 287 477 40 288 477 minecraft:bookshelf
fill 40 287 479 40 288 479 minecraft:bookshelf
fill 40 287 481 40 288 481 minecraft:bookshelf
fill 41 287 474 41 288 474 minecraft:bookshelf
fill 41 287 476 41 288 476 minecraft:bookshelf
fill 41 287 478 41 288 478 minecraft:bookshelf
fill 41 287 480 41 288 480 minecraft:bookshelf
fill 41 287 482 41 288 482 minecraft:bookshelf
fill 41 287 493 41 287 495 minecraft:bookshelf
setblock 1 288 470 minecraft:bookshelf
setblock 1 288 477 minecraft:bookshelf
setblock 1 288 484 minecraft:bookshelf
setblock 1 288 498 minecraft:bookshelf
setblock 2 288 504 minecraft:bookshelf
setblock 9 288 504 minecraft:bookshelf
fill 13 288 476 14 289 477 minecraft:green_wool
fill 14 288 478 14 289 478 minecraft:green_wool
setblock 23 288 464 minecraft:bookshelf
setblock 30 288 464 minecraft:bookshelf
setblock 30 288 504 minecraft:bookshelf
setblock 37 288 464 minecraft:bookshelf
setblock 37 288 504 minecraft:bookshelf
fill 39 288 493 39 288 499 minecraft:bookshelf
fill 40 288 494 40 288 500 minecraft:bookshelf
setblock 41 288 467 minecraft:bookshelf
setblock 41 288 488 minecraft:bookshelf
fill 41 288 494 41 288 495 minecraft:bookshelf
fill 41 288 497 41 288 502 minecraft:bookshelf
fill 1 289 464 1 290 464 minecraft:bookshelf
fill 1 289 469 1 300 469 minecraft:bookshelf
fill 1 289 471 1 290 471 minecraft:bookshelf
fill 1 289 478 1 290 478 minecraft:bookshelf
fill 1 289 485 1 290 485 minecraft:bookshelf
setblock 1 289 486 minecraft:ochre_froglight
setblock 1 289 488 minecraft:ochre_froglight
setblock 1 289 490 minecraft:ochre_froglight
setblock 1 289 492 minecraft:ochre_froglight
setblock 1 289 494 minecraft:ochre_froglight
setblock 1 289 496 minecraft:ochre_froglight
fill 1 289 499 1 290 499 minecraft:bookshelf
setblock 2 289 465 minecraft:ochre_froglight
setblock 2 289 467 minecraft:ochre_froglight
setblock 2 289 469 minecraft:ochre_froglight
setblock 2 289 471 minecraft:ochre_froglight
setblock 2 289 487 minecraft:ochre_froglight
setblock 2 289 489 minecraft:ochre_froglight
setblock 2 289 491 minecraft:ochre_froglight
setblock 2 289 493 minecraft:ochre_froglight
setblock 2 289 495 minecraft:ochre_froglight
setblock 3 289 464 minecraft:ochre_froglight
setblock 3 289 466 minecraft:ochre_froglight
setblock 3 289 468 minecraft:ochre_froglight
setblock 3 289 470 minecraft:ochre_froglight
setblock 3 289 472 minecraft:ochre_froglight
setblock 3 289 474 minecraft:light[level=12]
setblock 3 289 482 minecraft:light[level=12]
setblock 3 289 486 minecraft:ochre_froglight
setblock 3 289 488 minecraft:ochre_froglight
setblock 3 289 490 minecraft:ochre_froglight
setblock 3 289 492 minecraft:ochre_froglight
setblock 3 289 494 minecraft:ochre_froglight
setblock 3 289 496 minecraft:ochre_froglight
setblock 3 289 498 minecraft:light[level=12]
fill 3 289 504 3 290 504 minecraft:bookshelf
setblock 4 289 465 minecraft:ochre_froglight
setblock 4 289 467 minecraft:ochre_froglight
setblock 4 289 469 minecraft:ochre_froglight
setblock 4 289 471 minecraft:ochre_froglight
setblock 4 289 487 minecraft:ochre_froglight
setblock 4 289 489 minecraft:ochre_froglight
setblock 4 289 491 minecraft:ochre_froglight
setblock 4 289 493 minecraft:ochre_froglight
setblock 4 289 495 minecraft:ochre_froglight
setblock 5 289 464 minecraft:ochre_froglight
setblock 5 289 466 minecraft:ochre_froglight
setblock 5 289 468 minecraft:ochre_froglight
setblock 5 289 470 minecraft:ochre_froglight
setblock 5 289 472 minecraft:ochre_froglight
setblock 5 289 486 minecraft:ochre_froglight
setblock 5 289 488 minecraft:ochre_froglight
setblock 5 289 490 minecraft:ochre_froglight
setblock 5 289 492 minecraft:ochre_froglight
setblock 5 289 494 minecraft:ochre_froglight
setblock 5 289 496 minecraft:ochre_froglight
setblock 6 289 465 minecraft:ochre_froglight
setblock 6 289 467 minecraft:ochre_froglight
setblock 6 289 469 minecraft:ochre_froglight
setblock 6 289 471 minecraft:ochre_froglight
setblock 6 289 487 minecraft:ochre_froglight
setblock 6 289 489 minecraft:ochre_froglight
setblock 6 289 491 minecraft:ochre_froglight
setblock 6 289 493 minecraft:ochre_froglight
setblock 6 289 495 minecraft:ochre_froglight
setblock 7 289 464 minecraft:ochre_froglight
setblock 7 289 466 minecraft:ochre_froglight
setblock 7 289 468 minecraft:ochre_froglight
setblock 7 289 470 minecraft:ochre_froglight
setblock 7 289 472 minecraft:ochre_froglight
setblock 7 289 486 minecraft:ochre_froglight
setblock 7 289 488 minecraft:ochre_froglight
setblock 7 289 490 minecraft:ochre_froglight
setblock 7 289 492 minecraft:ochre_froglight
setblock 7 289 494 minecraft:ochre_froglight
setblock 7 289 496 minecraft:ochre_froglight
setblock 8 289 465 minecraft:ochre_froglight
setblock 8 289 467 minecraft:ochre_froglight
setblock 8 289 469 minecraft:ochre_froglight
setblock 8 289 471 minecraft:ochre_froglight
setblock 8 289 487 minecraft:ochre_froglight
setblock 8 289 489 minecraft:ochre_froglight
setblock 8 289 491 minecraft:ochre_froglight
setblock 8 289 493 minecraft:ochre_froglight
setblock 9 289 464 minecraft:ochre_froglight
setblock 9 289 466 minecraft:ochre_froglight
setblock 9 289 468 minecraft:ochre_froglight
setblock 9 289 470 minecraft:ochre_froglight
setblock 9 289 472 minecraft:ochre_froglight
setblock 10 289 465 minecraft:ochre_froglight
setblock 10 289 467 minecraft:ochre_froglight
setblock 10 289 469 minecraft:ochre_froglight
setblock 10 289 471 minecraft:ochre_froglight
fill 10 289 504 10 290 504 minecraft:bookshelf
setblock 11 289 464 minecraft:ochre_froglight
setblock 11 289 466 minecraft:ochre_froglight
setblock 11 289 468 minecraft:ochre_froglight
setblock 11 289 470 minecraft:ochre_froglight
setblock 11 289 472 minecraft:ochre_froglight
setblock 11 289 474 minecraft:light[level=12]
setblock 11 289 482 minecraft:light[level=12]
setblock 11 289 490 minecraft:light[level=12]
setblock 11 289 498 minecraft:light[level=12]
setblock 12 289 465 minecraft:ochre_froglight
setblock 12 289 467 minecraft:ochre_froglight
setblock 12 289 469 minecraft:ochre_froglight
setblock 12 289 471 minecraft:ochre_froglight
setblock 13 289 464 minecraft:ochre_froglight
setblock 13 289 466 minecraft:ochre_froglight
setblock 14 289 465 minecraft:ochre_froglight
setblock 14 289 467 minecraft:ochre_froglight
setblock 14 289 497 minecraft:ochre_froglight
setblock 14 289 499 minecraft:ochre_froglight
setblock 14 289 501 minecraft:ochre_froglight
setblock 14 289 503 minecraft:ochre_froglight
setblock 15 289 464 minecraft:ochre_froglight
setblock 15 289 466 minecraft:ochre_froglight
setblock 15 289 496 minecraft:ochre_froglight
setblock 15 289 498 minecraft:ochre_froglight
setblock 15 289 500 minecraft:ochre_froglight
setblock 15 289 502 minecraft:ochre_froglight
setblock 15 289 504 minecraft:ochre_froglight
setblock 16 289 465 minecraft:ochre_froglight
setblock 16 289 467 minecraft:ochre_froglight
setblock 16 289 497 minecraft:ochre_froglight
setblock 16 289 499 minecraft:ochre_froglight
setblock 16 289 501 minecraft:ochre_froglight
setblock 16 289 503 minecraft:ochre_froglight
setblock 17 289 464 minecraft:ochre_froglight
setblock 17 289 466 minecraft:ochre_froglight
setblock 17 289 496 minecraft:ochre_froglight
setblock 17 289 498 minecraft:ochre_froglight
setblock 17 289 500 minecraft:ochre_froglight
setblock 17 289 502 minecraft:ochre_froglight
setblock 17 289 504 minecraft:ochre_froglight
setblock 18 289 465 minecraft:ochre_froglight
setblock 18 289 467 minecraft:ochre_froglight
setblock 18 289 497 minecraft:ochre_froglight
setblock 18 289 499 minecraft:ochre_froglight
setblock 18 289 501 minecraft:ochre_froglight
setblock 18 289 503 minecraft:ochre_froglight
setblock 19 289 464 minecraft:ochre_froglight
setblock 19 289 466 minecraft:ochre_froglight
setblock 19 289 474 minecraft:light[level=12]
setblock 19 289 482 minecraft:light[level=12]
setblock 19 289 490 minecraft:light[level=12]
setblock 19 289 496 minecraft:ochre_froglight
setblock 19 289 498 minecraft:ochre_froglight
setblock 19 289 500 minecraft:ochre_froglight
setblock 19 289 502 minecraft:ochre_froglight
setblock 19 289 504 minecraft:ochre_froglight
setblock 20 289 465 minecraft:ochre_froglight
setblock 20 289 467 minecraft:ochre_froglight
setblock 20 289 495 minecraft:ochre_froglight
setblock 20 289 497 minecraft:ochre_froglight
setblock 20 289 499 minecraft:ochre_froglight
setblock 20 289 501 minecraft:ochre_froglight
setblock 20 289 503 minecraft:ochre_froglight
setblock 21 289 496 minecraft:ochre_froglight
setblock 21 289 498 minecraft:ochre_froglight
setblock 21 289 500 minecraft:ochre_froglight
setblock 21 289 502 minecraft:ochre_froglight
setblock 21 289 504 minecraft:ochre_froglight
fill 22 289 464 22 290 464 minecraft:bookshelf
setblock 22 289 495 minecraft:ochre_froglight
setblock 22 289 497 minecraft:ochre_froglight
setblock 22 289 499 minecraft:ochre_froglight
setblock 22 289 501 minecraft:ochre_froglight
setblock 22 289 503 minecraft:ochre_froglight
setblock 23 289 496 minecraft:ochre_froglight
setblock 23 289 498 minecraft:ochre_froglight
setblock 23 289 500 minecraft:ochre_froglight
setblock 23 289 502 minecraft:ochre_froglight
setblock 23 289 504 minecraft:ochre_froglight
setblock 24 289 495 minecraft:ochre_froglight
setblock 24 289 497 minecraft:ochre_froglight
setblock 24 289 499 minecraft:ochre_froglight
setblock 24 289 501 minecraft:ochre_froglight
setblock 24 289 503 minecraft:ochre_froglight
setblock 25 289 496 minecraft:ochre_froglight
setblock 25 289 498 minecraft:ochre_froglight
setblock 25 289 500 minecraft:ochre_froglight
setblock 25 289 502 minecraft:ochre_froglight
setblock 25 289 504 minecraft:ochre_froglight
setblock 26 289 495 minecraft:ochre_froglight
setblock 26 289 497 minecraft:ochre_froglight
setblock 26 289 499 minecraft:ochre_froglight
setblock 26 289 501 minecraft:ochre_froglight
setblock 26 289 503 minecraft:ochre_froglight
setblock 27 289 466 minecraft:light[level=12]
setblock 27 289 474 minecraft:light[level=12]
setblock 27 289 482 minecraft:light[level=12]
setblock 27 289 490 minecraft:light[level=12]
setblock 27 289 498 minecraft:light[level=12]
fill 29 289 464 29 290 464 minecraft:bookshelf
fill 31 289 504 31 292 504 minecraft:bookshelf
setblock 33 289 474 minecraft:ochre_froglight
setblock 33 289 476 minecraft:ochre_froglight
setblock 33 289 478 minecraft:ochre_froglight
setblock 33 289 480 minecraft:ochre_froglight
setblock 33 289 482 minecraft:ochre_froglight
setblock 34 289 475 minecraft:ochre_froglight
setblock 34 289 477 minecraft:ochre_froglight
setblock 34 289 479 minecraft:ochre_froglight
setblock 34 289 481 minecraft:ochre_froglight
setblock 35 289 466 minecraft:light[level=12]
setblock 35 289 474 minecraft:ochre_froglight
setblock 35 289 476 minecraft:ochre_froglight
setblock 35 289 478 minecraft:ochre_froglight
setblock 35 289 480 minecraft:ochre_froglight
setblock 35 289 482 minecraft:ochre_froglight
setblock 35 289 490 minecraft:light[level=12]
setblock 35 289 498 minecraft:light[level=12]
fill 36 289 464 36 290 464 minecraft:bookshelf
setblock 36 289 475 minecraft:ochre_froglight
setblock 36 289 477 minecraft:ochre_froglight
setblock 36 289 479 minecraft:ochre_froglight
setblock 36 289 481 minecraft:ochre_froglight
setblock 37 289 474 minecraft:ochre_froglight
setblock 37 289 476 minecraft:ochre_froglight
setblock 37 289 478 minecraft:ochre_froglight
setblock 37 289 480 minecraft:ochre_froglight
setblock 37 289 482 minecraft:ochre_froglight
fill 37 289 502 41 289 502 minecraft:bookshelf
setblock 38 289 475 minecraft:ochre_froglight
setblock 38 289 477 minecraft:ochre_froglight
setblock 38 289 479 minecraft:ochre_froglight
setblock 38 289 481 minecraft:ochre_froglight
fill 38 289 503 40 290 504 minecraft:bookshelf
setblock 39 289 474 minecraft:ochre_froglight
setblock 39 289 476 minecraft:ochre_froglight
setblock 39 289 478 minecraft:ochre_froglight
setblock 39 289 480 minecraft:ochre_froglight
setblock 39 289 482 minecraft:ochre_froglight
fill 39 289 497 39 289 501 minecraft:bookshelf
setblock 40 289 475 minecraft:ochre_froglight
setblock 40 289 477 minecraft:ochre_froglight
setblock 40 289 479 minecraft:ochre_froglight
setblock 40 289 481 minecraft:ochre_froglight
fill 40 289 498 40 289 501 minecraft:bookshelf
fill 41 289 466 41 290 466 minecraft:bookshelf
fill 41 289 473 41 290 473 minecraft:bookshelf
setblock 41 289 474 minecraft:ochre_froglight
setblock 41 289 476 minecraft:ochre_froglight
setblock 41 289 478 minecraft:ochre_froglight
setblock 41 289 480 minecraft:ochre_froglight
setblock 41 289 482 minecraft:ochre_froglight
fill 41 289 487 41 290 487 minecraft:bookshelf
fill 41 289 494 41 290 494 minecraft:bookshelf
fill 41 289 499 41 290 501 minecraft:bookshelf
fill 41 289 504 41 290 504 minecraft:bookshelf
fill 1 290 465 1 290 468 minecraft:bookshelf
setblock 1 290 470 minecraft:bookshelf
fill 1 290 472 1 290 475 minecraft:bookshelf
setblock 1 290 477 minecraft:bookshelf
fill 1 290 479 1 290 482 minecraft:bookshelf
setblock 1 290 484 minecraft:bookshelf
fill 1 290 486 1 291 486 minecraft:bookshelf
fill 1 290 488 1 291 488 minecraft:bookshelf
fill 1 290 490 1 291 490 minecraft:bookshelf
fill 1 290 492 1 291 492 minecraft:bookshelf
fill 1 290 494 1 291 494 minecraft:bookshelf
fill 1 290 496 1 291 496 minecraft:bookshelf
setblock 1 290 498 minecraft:bookshelf
fill 1 290 500 1 290 503 minecraft:bookshelf
fill 2 290 465 2 291 465 minecraft:bookshelf
fill 2 290 467 2 291 467 minecraft:bookshelf
fill 2 290 469 2 291 469 minecraft:bookshelf
fill 2 290 471 2 291 471 minecraft:bookshelf
fill 2 290 487 2 291 487 minecraft:bookshelf
fill 2 290 489 2 291 489 minecraft:bookshelf
fill 2 290 491 2 291 491 minecraft:bookshelf
fill 2 290 493 2 291 493 minecraft:bookshelf
fill 2 290 495 2 291 495 minecraft:bookshelf
setblock 2 290 504 minecraft:bookshelf
fill 3 290 464 3 291 464 minecraft:bookshelf
fill 3 290 466 3 291 466 minecraft:bookshelf
fill 3 290 468 3 291 468 minecraft:bookshelf
fill 3 290 470 3 291 470 minecraft:bookshelf
fill 3 290 472 3 291 472 minecraft:bookshelf
fill 3 290 486 3 291 486 minecraft:bookshelf
fill 3 290 488 3 291 488 minecraft:bookshelf
fill 3 290 490 3 291 490 minecraft:bookshelf
fill 3 290 492 3 291 492 minecraft:bookshelf
fill 3 290 494 3 291 494 minecraft:bookshelf
fill 3 290 496 3 291 496 minecraft:bookshelf
fill 4 290 465 4 291 465 minecraft:bookshelf
fill 4 290 467 4 291 467 minecraft:bookshelf
fill 4 290 469 4 291 469 minecraft:bookshelf
fill 4 290 471 4 291 471 minecraft:bookshelf
fill 4 290 487 4 291 487 minecraft:bookshelf
fill 4 290 489 4 291 489 minecraft:bookshelf
fill 4 290 491 4 291 491 minecraft:bookshelf
fill 4 290 493 4 291 493 minecraft:bookshelf
fill 4 290 495 4 291 495 minecraft:bookshelf
fill 4 290 504 7 290 504 minecraft:bookshelf
fill 5 290 464 5 291 464 minecraft:bookshelf
fill 5 290 466 5 291 466 minecraft:bookshelf
fill 5 290 468 5 291 468 minecraft:bookshelf
fill 5 290 470 5 291 470 minecraft:bookshelf
fill 5 290 472 5 291 472 minecraft:bookshelf
fill 5 290 486 5 291 486 minecraft:bookshelf
fill 5 290 488 5 291 488 minecraft:bookshelf
fill 5 290 490 5 291 490 minecraft:bookshelf
fill 5 290 492 5 291 492 minecraft:bookshelf
fill 5 290 494 5 291 494 minecraft:bookshelf
fill 5 290 496 5 291 496 minecraft:bookshelf
fill 6 290 465 6 291 465 minecraft:bookshelf
fill 6 290 467 6 291 467 minecraft:bookshelf
fill 6 290 469 6 291 469 minecraft:bookshelf
fill 6 290 471 6 291 471 minecraft:bookshelf
fill 6 290 487 6 291 487 minecraft:bookshelf
fill 6 290 489 6 291 489 minecraft:bookshelf
fill 6 290 491 6 291 491 minecraft:bookshelf
fill 6 290 493 6 291 493 minecraft:bookshelf
fill 6 290 495 6 291 495 minecraft:bookshelf
fill 7 290 464 7 291 464 minecraft:bookshelf
fill 7 290 466 7 291 466 minecraft:bookshelf
fill 7 290 468 7 291 468 minecraft:bookshelf
fill 7 290 470 7 291 470 minecraft:bookshelf
fill 7 290 472 7 291 472 minecraft:bookshelf
fill 7 290 486 7 291 486 minecraft:bookshelf
fill 7 290 488 7 291 488 minecraft:bookshelf
fill 7 290 490 7 291 490 minecraft:bookshelf
fill 7 290 492 7 291 492 minecraft:bookshelf
fill 7 290 494 7 291 494 minecraft:bookshelf
fill 7 290 496 7 291 496 minecraft:bookshelf
fill 8 290 465 8 291 465 minecraft:bookshelf
fill 8 290 467 8 291 467 minecraft:bookshelf
fill 8 290 469 8 291 469 minecraft:bookshelf
fill 8 290 471 8 291 471 minecraft:bookshelf
fill 8 290 487 8 291 487 minecraft:bookshelf
fill 8 290 489 8 291 489 minecraft:bookshelf
fill 8 290 491 8 291 491 minecraft:bookshelf
fill 8 290 493 8 291 493 minecraft:bookshelf
fill 9 290 464 9 291 464 minecraft:bookshelf
fill 9 290 466 9 291 466 minecraft:bookshelf
fill 9 290 468 9 291 468 minecraft:bookshelf
fill 9 290 470 9 291 470 minecraft:bookshelf
fill 9 290 472 9 291 472 minecraft:bookshelf
setblock 9 290 504 minecraft:bookshelf
fill 10 290 465 10 291 465 minecraft:bookshelf
fill 10 290 467 10 291 467 minecraft:bookshelf
fill 10 290 469 10 291 469 minecraft:bookshelf
fill 10 290 471 10 291 471 minecraft:bookshelf
fill 11 290 464 11 291 464 minecraft:bookshelf
fill 11 290 466 11 291 466 minecraft:bookshelf
fill 11 290 468 11 291 468 minecraft:bookshelf
fill 11 290 470 11 291 470 minecraft:bookshelf
fill 11 290 472 11 291 472 minecraft:bookshelf
fill 11 290 504 13 290 504 minecraft:bookshelf
fill 12 290 465 12 291 465 minecraft:bookshelf
fill 12 290 467 12 291 467 minecraft:bookshelf
fill 12 290 469 12 291 469 minecraft:bookshelf
fill 12 290 471 12 291 471 minecraft:bookshelf
fill 13 290 464 13 291 464 minecraft:bookshelf
fill 13 290 466 13 291 466 minecraft:bookshelf
fill 14 290 465 14 291 465 minecraft:bookshelf
fill 14 290 467 14 291 467 minecraft:bookshelf
fill 14 290 497 14 291 497 minecraft:bookshelf
fill 14 290 499 14 291 499 minecraft:bookshelf
fill 14 290 501 14 291 501 minecraft:bookshelf
fill 14 290 503 14 291 503 minecraft:bookshelf
fill 15 290 464 15 291 464 minecraft:bookshelf
fill 15 290 466 15 291 466 minecraft:bookshelf
fill 15 290 496 15 291 496 minecraft:bookshelf
fill 15 290 498 15 291 498 minecraft:bookshelf
fill 15 290 500 15 291 500 minecraft:bookshelf
fill 15 290 502 15 291 502 minecraft:bookshelf
fill 15 290 504 15 291 504 minecraft:bookshelf
fill 16 290 465 16 291 465 minecraft:bookshelf
fill 16 290 467 16 291 467 minecraft:bookshelf
fill 16 290 497 16 291 497 minecraft:bookshelf
fill 16 290 499 16 291 499 minecraft:bookshelf
fill 16 290 501 16 291 501 minecraft:bookshelf
fill 16 290 503 16 291 503 minecraft:bookshelf
fill 17 290 464 17 291 464 minecraft:bookshelf
fill 17 290 466 17 291 466 minecraft:bookshelf
fill 17 290 496 17 291 496 minecraft:bookshelf
fill 17 290 498 17 291 498 minecraft:bookshelf
fill 17 290 500 17 291 500 minecraft:bookshelf
fill 17 290 502 17 291 502 minecraft:bookshelf
fill 17 290 504 17 291 504 minecraft:bookshelf
fill 18 290 465 18 291 465 minecraft:bookshelf
fill 18 290 467 18 291 467 minecraft:bookshelf
fill 18 290 497 18 291 497 minecraft:bookshelf
fill 18 290 499 18 291 499 minecraft:bookshelf
fill 18 290 501 18 291 501 minecraft:bookshelf
fill 18 290 503 18 291 503 minecraft:bookshelf
fill 19 290 464 19 291 464 minecraft:bookshelf
fill 19 290 466 19 291 466 minecraft:bookshelf
fill 19 290 496 19 291 496 minecraft:bookshelf
fill 19 290 498 19 291 498 minecraft:bookshelf
fill 19 290 500 19 291 500 minecraft:bookshelf
fill 19 290 502 19 291 502 minecraft:bookshelf
fill 19 290 504 19 291 504 minecraft:bookshelf
fill 20 290 465 20 291 465 minecraft:bookshelf
fill 20 290 467 20 291 467 minecraft:bookshelf
fill 20 290 495 20 291 495 minecraft:bookshelf
fill 20 290 497 20 291 497 minecraft:bookshelf
fill 20 290 499 20 291 499 minecraft:bookshelf
fill 20 290 501 20 291 501 minecraft:bookshelf
fill 20 290 503 20 291 503 minecraft:bookshelf
setblock 21 290 464 minecraft:bookshelf
fill 21 290 496 21 291 496 minecraft:bookshelf
fill 21 290 498 21 291 498 minecraft:bookshelf
fill 21 290 500 21 291 500 minecraft:bookshelf
fill 21 290 502 21 291 502 minecraft:bookshelf
fill 21 290 504 21 291 504 minecraft:bookshelf
fill 22 290 495 22 291 495 minecraft:bookshelf
fill 22 290 497 22 291 497 minecraft:bookshelf
fill 22 290 499 22 291 499 minecraft:bookshelf
fill 22 290 501 22 291 501 minecraft:bookshelf
fill 22 290 503 22 291 503 minecraft:bookshelf
setblock 23 290 464 minecraft:bookshelf
fill 23 290 496 23 291 496 minecraft:bookshelf
fill 23 290 498 23 291 498 minecraft:bookshelf
fill 23 290 500 23 291 500 minecraft:bookshelf
fill 23 290 502 23 291 502 minecraft:bookshelf
fill 23 290 504 23 291 504 minecraft:bookshelf
fill 24 290 495 24 291 495 minecraft:bookshelf
fill 24 290 497 24 291 497 minecraft:bookshelf
fill 24 290 499 24 291 499 minecraft:bookshelf
fill 24 290 501 24 291 501 minecraft:bookshelf
fill 24 290 503 24 291 503 minecraft:bookshelf
fill 25 290 464 28 290 464 minecraft:bookshelf
fill 25 290 496 25 291 496 minecraft:bookshelf
fill 25 290 498 25 291 498 minecraft:bookshelf
fill 25 290 500 25 291 500 minecraft:bookshelf
fill 25 290 502 25 291 502 minecraft:bookshelf
fill 25 290 504 25 291 504 minecraft:bookshelf
fill 26 290 495 26 291 495 minecraft:bookshelf
fill 26 290 497 26 291 497 minecraft:bookshelf
fill 26 290 499 26 291 499 minecraft:bookshelf
fill 26 290 501 26 291 501 minecraft:bookshelf
fill 26 290 503 26 291 503 minecraft:bookshelf
fill 27 290 504 28 290 504 minecraft:bookshelf
setblock 30 290 464 minecraft:bookshelf
fill 30 290 504 30 292 504 minecraft:bookshelf
fill 32 290 464 35 290 464 minecraft:bookshelf
fill 32 290 504 35 291 504 minecraft:bookshelf
fill 33 290 474 33 291 474 minecraft:bookshelf
fill 33 290 476 33 291 476 minecraft:bookshelf
fill 33 290 478 33 291 478 minecraft:bookshelf
fill 33 290 480 33 291 480 minecraft:bookshelf
fill 33 290 482 33 291 482 minecraft:bookshelf
fill 33 290 502 37 290 503 minecraft:bookshelf
fill 34 290 475 34 291 475 minecraft:bookshelf
fill 34 290 477 34 291 477 minecraft:bookshelf
fill 34 290 479 34 291 479 minecraft:bookshelf
fill 34 290 481 34 291 481 minecraft:bookshelf
fill 35 290 474 35 291 474 minecraft:bookshelf
fill 35 290 476 35 291 476 minecraft:bookshelf
fill 35 290 478 35 291 478 minecraft:bookshelf
fill 35 290 480 35 291 480 minecraft:bookshelf
fill 35 290 482 35 291 482 minecraft:bookshelf
fill 36 290 475 36 291 475 minecraft:bookshelf
fill 36 290 477 36 291 477 minecraft:bookshelf
fill 36 290 479 36 291 479 minecraft:bookshelf
fill 36 290 481 36 291 481 minecraft:bookshelf
setblock 37 290 464 minecraft:bookshelf
fill 37 290 474 37 291 474 minecraft:bookshelf
fill 37 290 476 37 291 476 minecraft:bookshelf
fill 37 290 478 37 291 478 minecraft:bookshelf
fill 37 290 480 37 291 480 minecraft:bookshelf
fill 37 290 482 37 291 482 minecraft:bookshelf
setblock 37 290 504 minecraft:bookshelf
fill 38 290 475 38 291 475 minecraft:bookshelf
fill 38 290 477 38 291 477 minecraft:bookshelf
fill 38 290 479 38 291 479 minecraft:bookshelf
fill 38 290 481 38 291 481 minecraft:bookshelf
fill 38 290 502 39 290 502 minecraft:bookshelf
fill 39 290 464 41 290 464 minecraft:bookshelf
fill 39 290 474 39 291 474 minecraft:bookshelf
fill 39 290 476 39 291 476 minecraft:bookshelf
fill 39 290 478 39 291 478 minecraft:bookshelf
fill 39 290 480 39 291 480 minecraft:bookshelf
fill 39 290 482 39 291 482 minecraft:bookshelf
fill 40 290 475 40 291 475 minecraft:bookshelf
fill 40 290 477 40 291 477 minecraft:bookshelf
fill 40 290 479 40 291 479 minecraft:bookshelf
fill 40 290 481 40 291 481 minecraft:bookshelf
setblock 41 290 465 minecraft:bookshelf
setblock 41 290 467 minecraft:bookshelf
fill 41 290 469 41 290 472 minecraft:bookshelf
fill 41 290 474 41 291 474 minecraft:bookshelf
fill 41 290 476 41 291 476 minecraft:bookshelf
fill 41 290 478 41 291 478 minecraft:bookshelf
fill 41 290 480 41 291 480 minecraft:bookshelf
fill 41 290 482 41 290 486 minecraft:bookshelf
setblock 41 290 488 minecraft:bookshelf
fill 41 290 490 41 290 493 minecraft:bookshelf
setblock 41 290 495 minecraft:bookshelf
fill 41 290 497 41 290 498 minecraft:bookshelf
setblock 41 290 502 minecraft:bookshelf
setblock 1 291 466 minecraft:bookshelf
setblock 1 291 473 minecraft:bookshelf
setblock 1 291 480 minecraft:bookshelf
setblock 1 291 501 minecraft:bookshelf
setblock 5 291 504 minecraft:bookshelf
setblock 12 291 504 minecraft:bookshelf
setblock 27 291 464 minecraft:bookshelf
fill 29 291 502 34 291 503 minecraft:bookshelf
setblock 34 291 464 minecraft:bookshelf
setblock 35 291 503 minecraft:bookshelf
setblock 40 291 504 minecraft:bookshelf
setblock 41 291 464 minecraft:bookshelf
setblock 41 291 471 minecraft:bookshelf
setblock 41 291 482 minecraft:bookshelf
setblock 41 291 485 minecraft:bookshelf
setblock 41 291 492 minecraft:bookshelf
setblock 41 291 499 minecraft:bookshelf
setblock 1 292 467 minecraft:bookshelf
setblock 1 292 474 minecraft:bookshelf
setblock 1 292 481 minecraft:bookshelf
setblock 1 292 486 minecraft:ochre_froglight
setblock 1 292 488 minecraft:ochre_froglight
setblock 1 292 490 minecraft:ochre_froglight
setblock 1 292 492 minecraft:ochre_froglight
setblock 1 292 494 minecraft:ochre_froglight
setblock 1 292 496 minecraft:ochre_froglight
setblock 1 292 502 minecraft:bookshelf
setblock 2 292 465 minecraft:ochre_froglight
setblock 2 292 467 minecraft:ochre_froglight
setblock 2 292 469 minecraft:ochre_froglight
setblock 2 292 471 minecraft:ochre_froglight
setblock 2 292 487 minecraft:ochre_froglight
setblock 2 292 489 minecraft:ochre_froglight
setblock 2 292 491 minecraft:ochre_froglight
setblock 2 292 493 minecraft:ochre_froglight
setblock 2 292 495 minecraft:ochre_froglight
setblock 3 292 464 minecraft:ochre_froglight
setblock 3 292 466 minecraft:ochre_froglight
setblock 3 292 468 minecraft:ochre_froglight
setblock 3 292 470 minecraft:ochre_froglight
setblock 3 292 472 minecraft:ochre_froglight
setblock 3 292 486 minecraft:ochre_froglight
setblock 3 292 488 minecraft:ochre_froglight
setblock 3 292 490 minecraft:ochre_froglight
setblock 3 292 492 minecraft:ochre_froglight
setblock 3 292 494 minecraft:ochre_froglight
setblock 3 292 496 minecraft:ochre_froglight
setblock 4 292 465 minecraft:ochre_froglight
setblock 4 292 467 minecraft:ochre_froglight
setblock 4 292 469 minecraft:ochre_froglight
setblock 4 292 471 minecraft:ochre_froglight
setblock 4 292 487 minecraft:ochre_froglight
setblock 4 292 489 minecraft:ochre_froglight
setblock 4 292 491 minecraft:ochre_froglight
setblock 4 292 493 minecraft:ochre_froglight
setblock 4 292 495 minecraft:ochre_froglight
setblock 5 292 464 minecraft:ochre_froglight
setblock 5 292 466 minecraft:ochre_froglight
setblock 5 292 468 minecraft:ochre_froglight
setblock 5 292 470 minecraft:ochre_froglight
setblock 5 292 472 minecraft:ochre_froglight
setblock 5 292 486 minecraft:ochre_froglight
setblock 5 292 488 minecraft:ochre_froglight
setblock 5 292 490 minecraft:ochre_froglight
setblock 5 292 492 minecraft:ochre_froglight
setblock 5 292 494 minecraft:ochre_froglight
setblock 5 292 496 minecraft:ochre_froglight
setblock 6 292 465 minecraft:ochre_froglight
setblock 6 292 467 minecraft:ochre_froglight
setblock 6 292 469 minecraft:ochre_froglight
setblock 6 292 471 minecraft:ochre_froglight
setblock 6 292 487 minecraft:ochre_froglight
setblock 6 292 489 minecraft:ochre_froglight
setblock 6 292 491 minecraft:ochre_froglight
setblock 6 292 493 minecraft:ochre_froglight
setblock 6 292 495 minecraft:ochre_froglight
setblock 6 292 504 minecraft:bookshelf
setblock 7 292 464 minecraft:ochre_froglight
setblock 7 292 466 minecraft:ochre_froglight
setblock 7 292 468 minecraft:ochre_froglight
setblock 7 292 470 minecraft:ochre_froglight
setblock 7 292 472 minecraft:ochre_froglight
setblock 7 292 486 minecraft:ochre_froglight
setblock 7 292 488 minecraft:ochre_froglight
setblock 7 292 490 minecraft:ochre_froglight
setblock 7 292 492 minecraft:ochre_froglight
setblock 7 292 494 minecraft:ochre_froglight
setblock 7 292 496 minecraft:ochre_froglight
setblock 8 292 465 minecraft:ochre_froglight
setblock 8 292 467 minecraft:ochre_froglight
setblock 8 292 469 minecraft:ochre_froglight
setblock 8 292 471 minecraft:ochre_froglight
setblock 8 292 487 minecraft:ochre_froglight
setblock 8 292 489 minecraft:ochre_froglight
setblock 8 292 491 minecraft:ochre_froglight
setblock 8 292 493 minecraft:ochre_froglight
setblock 9 292 464 minecraft:ochre_froglight
setblock 9 292 466 minecraft:ochre_froglight
setblock 9 292 468 minecraft:ochre_froglight
setblock 9 292 470 minecraft:ochre_froglight
setblock 9 292 472 minecraft:ochre_froglight
setblock 10 292 465 minecraft:ochre_froglight
setblock 10 292 467 minecraft:ochre_froglight
setblock 10 292 469 minecraft:ochre_froglight
setblock 10 292 471 minecraft:ochre_froglight
setblock 11 292 464 minecraft:ochre_froglight
setblock 11 292 466 minecraft:ochre_froglight
setblock 11 292 468 minecraft:ochre_froglight
setblock 11 292 470 minecraft:ochre_froglight
setblock 11 292 472 minecraft:ochre_froglight
setblock 12 292 465 minecraft:ochre_froglight
setblock 12 292 467 minecraft:ochre_froglight
setblock 12 292 469 minecraft:ochre_froglight
setblock 12 292 471 minecraft:ochre_froglight
setblock 13 292 464 minecraft:ochre_froglight
setblock 13 292 466 minecraft:ochre_froglight
setblock 13 292 504 minecraft:bookshelf
setblock 14 292 465 minecraft:ochre_froglight
setblock 14 292 467 minecraft:ochre_froglight
setblock 14 292 497 minecraft:ochre_froglight
setblock 14 292 499 minecraft:ochre_froglight
setblock 14 292 501 minecraft:ochre_froglight
setblock 14 292 503 minecraft:ochre_froglight
setblock 15 292 464 minecraft:ochre_froglight
setblock 15 292 466 minecraft:ochre_froglight
setblock 15 292 496 minecraft:ochre_froglight
setblock 15 292 498 minecraft:ochre_froglight
setblock 15 292 500 minecraft:ochre_froglight
setblock 15 292 502 minecraft:ochre_froglight
setblock 15 292 504 minecraft:ochre_froglight
setblock 16 292 465 minecraft:ochre_froglight
setblock 16 292 467 minecraft:ochre_froglight
setblock 16 292 497 minecraft:ochre_froglight
setblock 16 292 499 minecraft:ochre_froglight
setblock 16 292 501 minecraft:ochre_froglight
setblock 16 292 503 minecraft:ochre_froglight
setblock 17 292 464 minecraft:ochre_froglight
setblock 17 292 466 minecraft:ochre_froglight
setblock 17 292 496 minecraft:ochre_froglight
setblock 17 292 498 minecraft:ochre_froglight
setblock 17 292 500 minecraft:ochre_froglight
setblock 17 292 502 minecraft:ochre_froglight
setblock 17 292 504 minecraft:ochre_froglight
setblock 18 292 465 minecraft:ochre_froglight
setblock 18 292 467 minecraft:ochre_froglight
setblock 18 292 497 minecraft:ochre_froglight
setblock 18 292 499 minecraft:ochre_froglight
setblock 18 292 501 minecraft:ochre_froglight
setblock 18 292 503 minecraft:ochre_froglight
setblock 19 292 464 minecraft:ochre_froglight
setblock 19 292 466 minecraft:ochre_froglight
setblock 19 292 496 minecraft:ochre_froglight
setblock 19 292 498 minecraft:ochre_froglight
setblock 19 292 500 minecraft:ochre_froglight
setblock 19 292 502 minecraft:ochre_froglight
setblock 19 292 504 minecraft:ochre_froglight
setblock 20 292 465 minecraft:ochre_froglight
setblock 20 292 467 minecraft:ochre_froglight
setblock 20 292 495 minecraft:ochre_froglight
setblock 20 292 497 minecraft:ochre_froglight
setblock 20 292 499 minecraft:ochre_froglight
setblock 20 292 501 minecraft:ochre_froglight
setblock 20 292 503 minecraft:ochre_froglight
setblock 21 292 496 minecraft:ochre_froglight
setblock 21 292 498 minecraft:ochre_froglight
setblock 21 292 500 minecraft:ochre_froglight
setblock 21 292 502 minecraft:ochre_froglight
setblock 21 292 504 minecraft:ochre_froglight
setblock 22 292 495 minecraft:ochre_froglight
setblock 22 292 497 minecraft:ochre_froglight
setblock 22 292 499 minecraft:ochre_froglight
setblock 22 292 501 minecraft:ochre_froglight
setblock 22 292 503 minecraft:ochre_froglight
setblock 23 292 496 minecraft:ochre_froglight
setblock 23 292 498 minecraft:ochre_froglight
setblock 23 292 500 minecraft:ochre_froglight
setblock 23 292 502 minecraft:ochre_froglight
setblock 23 292 504 minecraft:ochre_froglight
setblock 24 292 495 minecraft:ochre_froglight
setblock 24 292 497 minecraft:ochre_froglight
setblock 24 292 499 minecraft:ochre_froglight
setblock 24 292 501 minecraft:ochre_froglight
setblock 24 292 503 minecraft:ochre_froglight
setblock 25 292 496 minecraft:ochre_froglight
setblock 25 292 498 minecraft:ochre_froglight
setblock 25 292 500 minecraft:ochre_froglight
setblock 25 292 502 minecraft:ochre_froglight
setblock 25 292 504 minecraft:ochre_froglight
setblock 26 292 464 minecraft:bookshelf
setblock 26 292 495 minecraft:ochre_froglight
setblock 26 292 497 minecraft:ochre_froglight
setblock 26 292 499 minecraft:ochre_froglight
setblock 26 292 501 minecraft:ochre_froglight
setblock 26 292 503 minecraft:ochre_froglight
fill 27 292 497 28 293 501 minecraft:dark_oak_planks
fill 27 292 502 28 292 504 minecraft:bookshelf
fill 29 292 502 30 292 503 minecraft:bookshelf
setblock 31 292 503 minecraft:bookshelf
setblock 33 292 464 minecraft:bookshelf
setblock 33 292 474 minecraft:ochre_froglight
setblock 33 292 476 minecraft:ochre_froglight
setblock 33 292 478 minecraft:ochre_froglight
setblock 33 292 480 minecraft:ochre_froglight
setblock 33 292 482 minecraft:ochre_froglight
setblock 34 292 475 minecraft:ochre_froglight
setblock 34 292 477 minecraft:ochre_froglight
setblock 34 292 479 minecraft:ochre_froglight
setblock 34 292 481 minecraft:ochre_froglight
setblock 34 292 504 minecraft:bookshelf
setblock 35 292 474 minecraft:ochre_froglight
setblock 35 292 476 minecraft:ochre_froglight
setblock 35 292 478 minecraft:ochre_froglight
setblock 35 292 480 minecraft:ochre_froglight
setblock 35 292 482 minecraft:ochre_froglight
setblock 36 292 475 minecraft:ochre_froglight
setblock 36 292 477 minecraft:ochre_froglight
setblock 36 292 479 minecraft:ochre_froglight
setblock 36 292 481 minecraft:ochre_froglight
setblock 37 292 474 minecraft:ochre_froglight
setblock 37 292 476 minecraft:ochre_froglight
setblock 37 292 478 minecraft:ochre_froglight
setblock 37 292 480 minecraft:ochre_froglight
setblock 37 292 482 minecraft:ochre_froglight
setblock 38 292 475 minecraft:ochre_froglight
setblock 38 292 477 minecraft:ochre_froglight
setblock 38 292 479 minecraft:ochre_froglight
setblock 38 292 481 minecraft:ochre_froglight
setblock 39 292 474 minecraft:ochre_froglight
setblock 39 292 476 minecraft:ochre_froglight
setblock 39 292 478 minecraft:ochre_froglight
setblock 39 292 480 minecraft:ochre_froglight
setblock 39 292 482 minecraft:ochre_froglight
setblock 40 292 464 minecraft:bookshelf
setblock 40 292 475 minecraft:ochre_froglight
setblock 40 292 477 minecraft:ochre_froglight
setblock 40 292 479 minecraft:ochre_froglight
setblock 40 292 481 minecraft:ochre_froglight
setblock 41 292 470 minecraft:bookshelf
setblock 41 292 474 minecraft:ochre_froglight
setblock 41 292 476 minecraft:ochre_froglight
setblock 41 292 478 minecraft:ochre_froglight
setblock 41 292 480 minecraft:ochre_froglight
setblock 41 292 482 minecraft:ochre_froglight
setblock 41 292 484 minecraft:bookshelf
setblock 41 292 491 minecraft:bookshelf
setblock 41 292 498 minecraft:bookshelf
setblock 41 292 504 minecraft:bookshelf
setblock 1 293 468 minecraft:bookshelf
setblock 1 293 475 minecraft:bookshelf
setblock 1 293 482 minecraft:bookshelf
fill 1 293 486 1 294 486 minecraft:bookshelf
fill 1 293 488 1 294 488 minecraft:bookshelf
fill 1 293 490 1 294 490 minecraft:bookshelf
fill 1 293 492 1 294 492 minecraft:bookshelf
fill 1 293 494 1 294 494 minecraft:bookshelf
fill 1 293 496 1 294 496 minecraft:bookshelf
setblock 1 293 503 minecraft:bookshelf
fill 2 293 465 2 294 465 minecraft:bookshelf
fill 2 293 467 2 294 467 minecraft:bookshelf
fill 2 293 469 2 294 469 minecraft:bookshelf
fill 2 293 471 2 294 471 minecraft:bookshelf
fill 2 293 487 2 294 487 minecraft:bookshelf
fill 2 293 489 2 294 489 minecraft:bookshelf
fill 2 293 491 2 294 491 minecraft:bookshelf
fill 2 293 493 2 294 493 minecraft:bookshelf
fill 2 293 495 2 294 495 minecraft:bookshelf
fill 3 293 464 3 294 464 minecraft:bookshelf
fill 3 293 466 3 294 466 minecraft:bookshelf
fill 3 293 468 3 294 468 minecraft:bookshelf
fill 3 293 470 3 294 470 minecraft:bookshelf
fill 3 293 472 3 294 472 minecraft:bookshelf
fill 3 293 486 3 294 486 minecraft:bookshelf
fill 3 293 488 3 294 488 minecraft:bookshelf
fill 3 293 490 3 294 490 minecraft:bookshelf
fill 3 293 492 3 294 492 minecraft:bookshelf
fill 3 293 494 3 294 494 minecraft:bookshelf
fill 3 293 496 3 294 496 minecraft:bookshelf
fill 4 293 465 4 294 465 minecraft:bookshelf
fill 4 293 467 4 294 467 minecraft:bookshelf
fill 4 293 469 4 294 469 minecraft:bookshelf
fill 4 293 471 4 294 471 minecraft:bookshelf
fill 4 293 487 4 294 487 minecraft:bookshelf
fill 4 293 489 4 294 489 minecraft:bookshelf
fill 4 293 491 4 294 491 minecraft:bookshelf
fill 4 293 493 4 294 493 minecraft:bookshelf
fill 4 293 495 4 294 495 minecraft:bookshelf
fill 5 293 464 5 294 464 minecraft:bookshelf
fill 5 293 466 5 294 466 minecraft:bookshelf
fill 5 293 468 5 294 468 minecraft:bookshelf
fill 5 293 470 5 294 470 minecraft:bookshelf
fill 5 293 472 5 294 472 minecraft:bookshelf
fill 5 293 486 5 294 486 minecraft:bookshelf
fill 5 293 488 5 294 488 minecraft:bookshelf
fill 5 293 490 5 294 490 minecraft:bookshelf
fill 5 293 492 5 294 492 minecraft:bookshelf
fill 5 293 494 5 294 494 minecraft:bookshelf
fill 5 293 496 5 294 496 minecraft:bookshelf
fill 6 293 465 6 294 465 minecraft:bookshelf
fill 6 293 467 6 294 467 minecraft:bookshelf
fill 6 293 469 6 294 469 minecraft:bookshelf
fill 6 293 471 6 294 471 minecraft:bookshelf
fill 6 293 487 6 294 487 minecraft:bookshelf
fill 6 293 489 6 294 489 minecraft:bookshelf
fill 6 293 491 6 294 491 minecraft:bookshelf
fill 6 293 493 6 294 493 minecraft:bookshelf
fill 6 293 495 6 294 495 minecraft:bookshelf
fill 7 293 464 7 294 464 minecraft:bookshelf
fill 7 293 466 7 294 466 minecraft:bookshelf
fill 7 293 468 7 294 468 minecraft:bookshelf
fill 7 293 470 7 294 470 minecraft:bookshelf
fill 7 293 472 7 294 472 minecraft:bookshelf
fill 7 293 486 7 294 486 minecraft:bookshelf
fill 7 293 488 7 294 488 minecraft:bookshelf
fill 7 293 490 7 294 490 minecraft:bookshelf
fill 7 293 492 7 294 492 minecraft:bookshelf
fill 7 293 494 7 294 494 minecraft:bookshelf
fill 7 293 496 7 294 496 minecraft:bookshelf
setblock 7 293 504 minecraft:bookshelf
fill 8 293 465 8 294 465 minecraft:bookshelf
fill 8 293 467 8 294 467 minecraft:bookshelf
fill 8 293 469 8 294 469 minecraft:bookshelf
fill 8 293 471 8 294 471 minecraft:bookshelf
fill 8 293 487 8 294 487 minecraft:bookshelf
fill 8 293 489 8 294 489 minecraft:bookshelf
fill 8 293 491 8 294 491 minecraft:bookshelf
fill 8 293 493 8 294 493 minecraft:bookshelf
fill 9 293 464 9 294 464 minecraft:bookshelf
fill 9 293 466 9 294 466 minecraft:bookshelf
fill 9 293 468 9 294 468 minecraft:bookshelf
fill 9 293 470 9 294 470 minecraft:bookshelf
fill 9 293 472 9 294 472 minecraft:bookshelf
fill 10 293 465 10 294 465 minecraft:bookshelf
fill 10 293 467 10 294 467 minecraft:bookshelf
fill 10 293 469 10 294 469 minecraft:bookshelf
fill 10 293 471 10 294 471 minecraft:bookshelf
fill 11 293 464 11 294 464 minecraft:bookshelf
fill 11 293 466 11 294 466 minecraft:bookshelf
fill 11 293 468 11 294 468 minecraft:bookshelf
fill 11 293 470 11 294 470 minecraft:bookshelf
fill 11 293 472 11 294 472 minecraft:bookshelf
fill 12 293 465 12 294 465 minecraft:bookshelf
fill 12 293 467 12 294 467 minecraft:bookshelf
fill 12 293 469 12 294 469 minecraft:bookshelf
fill 12 293 471 12 294 471 minecraft:bookshelf
fill 13 293 464 13 294 464 minecraft:bookshelf
fill 13 293 466 13 294 466 minecraft:bookshelf
fill 14 293 465 14 294 465 minecraft:bookshelf
fill 14 293 467 14 294 467 minecraft:bookshelf
fill 14 293 497 14 294 497 minecraft:bookshelf
fill 14 293 499 14 294 499 minecraft:bookshelf
fill 14 293 501 14 294 501 minecraft:bookshelf
fill 14 293 503 14 294 503 minecraft:bookshelf
fill 15 293 464 15 294 464 minecraft:bookshelf
fill 15 293 466 15 294 466 minecraft:bookshelf
fill 15 293 496 15 294 496 minecraft:bookshelf
fill 15 293 498 15 294 498 minecraft:bookshelf
fill 15 293 500 15 294 500 minecraft:bookshelf
fill 15 293 502 15 294 502 minecraft:bookshelf
fill 15 293 504 15 294 504 minecraft:bookshelf
fill 16 293 465 16 294 465 minecraft:bookshelf
fill 16 293 467 16 294 467 minecraft:bookshelf
fill 16 293 497 16 294 497 minecraft:bookshelf
fill 16 293 499 16 294 499 minecraft:bookshelf
fill 16 293 501 16 294 501 minecraft:bookshelf
fill 16 293 503 16 294 503 minecraft:bookshelf
fill 17 293 464 17 294 464 minecraft:bookshelf
fill 17 293 466 17 294 466 minecraft:bookshelf
fill 17 293 496 17 294 496 minecraft:bookshelf
fill 17 293 498 17 294 498 minecraft:bookshelf
fill 17 293 500 17 294 500 minecraft:bookshelf
fill 17 293 502 17 294 502 minecraft:bookshelf
fill 17 293 504 17 294 504 minecraft:bookshelf
fill 18 293 465 18 294 465 minecraft:bookshelf
fill 18 293 467 18 294 467 minecraft:bookshelf
fill 18 293 497 18 294 497 minecraft:bookshelf
fill 18 293 499 18 294 499 minecraft:bookshelf
fill 18 293 501 18 294 501 minecraft:bookshelf
fill 18 293 503 18 294 503 minecraft:bookshelf
fill 19 293 464 19 294 464 minecraft:bookshelf
fill 19 293 466 19 294 466 minecraft:bookshelf
fill 19 293 496 19 294 496 minecraft:bookshelf
fill 19 293 498 19 294 498 minecraft:bookshelf
fill 19 293 500 19 294 500 minecraft:bookshelf
fill 19 293 502 19 294 502 minecraft:bookshelf
fill 19 293 504 19 294 504 minecraft:bookshelf
fill 20 293 465 20 294 465 minecraft:bookshelf
fill 20 293 467 20 294 467 minecraft:bookshelf
fill 20 293 495 20 294 495 minecraft:bookshelf
fill 20 293 497 20 294 497 minecraft:bookshelf
fill 20 293 499 20 294 499 minecraft:bookshelf
fill 20 293 501 20 294 501 minecraft:bookshelf
fill 20 293 503 20 294 503 minecraft:bookshelf
fill 21 293 496 21 294 496 minecraft:bookshelf
fill 21 293 498 21 294 498 minecraft:bookshelf
fill 21 293 500 21 294 500 minecraft:bookshelf
fill 21 293 502 21 294 502 minecraft:bookshelf
fill 21 293 504 21 294 504 minecraft:bookshelf
fill 22 293 495 22 294 495 minecraft:bookshelf
fill 22 293 497 22 294 497 minecraft:bookshelf
fill 22 293 499 22 294 499 minecraft:bookshelf
fill 22 293 501 22 294 501 minecraft:bookshelf
fill 22 293 503 22 294 503 minecraft:bookshelf
fill 23 293 496 23 294 496 minecraft:bookshelf
fill 23 293 498 23 294 498 minecraft:bookshelf
fill 23 293 500 23 294 500 minecraft:bookshelf
fill 23 293 502 23 294 502 minecraft:bookshelf
fill 23 293 504 23 294 504 minecraft:bookshelf
fill 24 293 495 24 294 495 minecraft:bookshelf
fill 24 293 497 24 294 497 minecraft:bookshelf
fill 24 293 499 24 294 499 minecraft:bookshelf
fill 24 293 501 24 294 501 minecraft:bookshelf
fill 24 293 503 24 294 503 minecraft:bookshelf
setblock 25 293 464 minecraft:bookshelf
fill 25 293 496 25 294 496 minecraft:bookshelf
fill 25 293 498 25 294 498 minecraft:bookshelf
fill 25 293 500 25 294 500 minecraft:bookshelf
fill 25 293 502 25 294 502 minecraft:bookshelf
fill 25 293 504 25 294 504 minecraft:bookshelf
fill 26 293 495 26 294 495 minecraft:bookshelf
fill 26 293 497 26 294 497 minecraft:bookshelf
fill 26 293 499 26 294 499 minecraft:bookshelf
fill 26 293 501 26 294 501 minecraft:bookshelf
fill 26 293 503 27 293 503 minecraft:bookshelf
setblock 27 293 502 minecraft:bookshelf
fill 27 293 504 28 293 504 minecraft:bookshelf
setblock 32 293 464 minecraft:bookshelf
fill 33 293 474 33 294 474 minecraft:bookshelf
fill 33 293 476 33 294 476 minecraft:bookshelf
fill 33 293 478 33 294 478 minecraft:bookshelf
fill 33 293 480 33 294 480 minecraft:bookshelf
fill 33 293 482 33 294 482 minecraft:bookshelf
fill 34 293 475 34 294 475 minecraft:bookshelf
fill 34 293 477 34 294 477 minecraft:bookshelf
fill 34 293 479 34 294 479 minecraft:bookshelf
fill 34 293 481 34 294 481 minecraft:bookshelf
fill 35 293 474 35 294 474 minecraft:bookshelf
fill 35 293 476 35 294 476 minecraft:bookshelf
fill 35 293 478 35 294 478 minecraft:bookshelf
fill 35 293 480 35 294 480 minecraft:bookshelf
fill 35 293 482 35 294 482 minecraft:bookshelf
setblock 35 293 504 minecraft:bookshelf
fill 36 293 475 36 294 475 minecraft:bookshelf
fill 36 293 477 36 294 477 minecraft:bookshelf
fill 36 293 479 36 294 479 minecraft:bookshelf
fill 36 293 481 36 294 481 minecraft:bookshelf
fill 37 293 474 37 294 474 minecraft:bookshelf
fill 37 293 476 37 294 476 minecraft:bookshelf
fill 37 293 478 37 294 478 minecraft:bookshelf
fill 37 293 480 37 294 480 minecraft:bookshelf
fill 37 293 482 37 294 482 minecraft:bookshelf
fill 38 293 475 38 294 475 minecraft:bookshelf
fill 38 293 477 38 294 477 minecraft:bookshelf
fill 38 293 479 38 294 479 minecraft:bookshelf
fill 38 293 481 38 294 481 minecraft:bookshelf
setblock 39 293 464 minecraft:bookshelf
fill 39 293 474 39 294 474 minecraft:bookshelf
fill 39 293 476 39 294 476 minecraft:bookshelf
fill 39 293 478 39 294 478 minecraft:bookshelf
fill 39 293 480 39 294 480 minecraft:bookshelf
fill 39 293 482 39 294 482 minecraft:bookshelf
fill 40 293 475 40 294 475 minecraft:bookshelf
fill 40 293 477 40 294 477 minecraft:bookshelf
fill 40 293 479 40 294 479 minecraft:bookshelf
fill 40 293 481 40 294 481 minecraft:bookshelf
setblock 41 293 469 minecraft:bookshelf
fill 41 293 474 41 294 474 minecraft:bookshelf
fill 41 293 476 41 294 476 minecraft:bookshelf
fill 41 293 478 41 294 478 minecraft:bookshelf
fill 41 293 480 41 294 480 minecraft:bookshelf
fill 41 293 482 41 293 483 minecraft:bookshelf
setblock 41 293 490 minecraft:bookshelf
setblock 41 293 497 minecraft:bookshelf
setblock 26 294 503 minecraft:bookshelf
fill 27 294 499 27 300 499 minecraft:purple_concrete
setblock 41 294 482 minecraft:bookshelf
setblock 1 295 470 minecraft:bookshelf
setblock 1 295 477 minecraft:bookshelf
setblock 1 295 484 minecraft:bookshelf
setblock 1 295 486 minecraft:ochre_froglight
setblock 1 295 488 minecraft:ochre_froglight
setblock 1 295 490 minecraft:ochre_froglight
setblock 1 295 492 minecraft:ochre_froglight
setblock 1 295 494 minecraft:ochre_froglight
setblock 1 295 496 minecraft:ochre_froglight
setblock 1 295 498 minecraft:bookshelf
setblock 2 295 465 minecraft:ochre_froglight
setblock 2 295 467 minecraft:ochre_froglight
setblock 2 295 469 minecraft:ochre_froglight
setblock 2 295 471 minecraft:ochre_froglight
setblock 2 295 487 minecraft:ochre_froglight
setblock 2 295 489 minecraft:ochre_froglight
setblock 2 295 491 minecraft:ochre_froglight
setblock 2 295 493 minecraft:ochre_froglight
setblock 2 295 495 minecraft:ochre_froglight
setblock 2 295 504 minecraft:bookshelf
setblock 3 295 464 minecraft:ochre_froglight
setblock 3 295 466 minecraft:ochre_froglight
setblock 3 295 468 minecraft:ochre_froglight
setblock 3 295 470 minecraft:ochre_froglight
setblock 3 295 472 minecraft:ochre_froglight
setblock 3 295 486 minecraft:ochre_froglight
setblock 3 295 488 minecraft:ochre_froglight
setblock 3 295 490 minecraft:ochre_froglight
setblock 3 295 492 minecraft:ochre_froglight
setblock 3 295 494 minecraft:ochre_froglight
setblock 3 295 496 minecraft:ochre_froglight
setblock 4 295 465 minecraft:ochre_froglight
setblock 4 295 467 minecraft:ochre_froglight
setblock 4 295 469 minecraft:ochre_froglight
setblock 4 295 471 minecraft:ochre_froglight
setblock 4 295 487 minecraft:ochre_froglight
setblock 4 295 489 minecraft:ochre_froglight
setblock 4 295 491 minecraft:ochre_froglight
setblock 4 295 493 minecraft:ochre_froglight
setblock 4 295 495 minecraft:ochre_froglight
setblock 5 295 464 minecraft:ochre_froglight
setblock 5 295 466 minecraft:ochre_froglight
setblock 5 295 468 minecraft:ochre_froglight
setblock 5 295 470 minecraft:ochre_froglight
setblock 5 295 472 minecraft:ochre_froglight
setblock 5 295 486 minecraft:ochre_froglight
setblock 5 295 488 minecraft:ochre_froglight
setblock 5 295 490 minecraft:ochre_froglight
setblock 5 295 492 minecraft:ochre_froglight
setblock 5 295 494 minecraft:ochre_froglight
setblock 5 295 496 minecraft:ochre_froglight
setblock 6 295 465 minecraft:ochre_froglight
setblock 6 295 467 minecraft:ochre_froglight
setblock 6 295 469 minecraft:ochre_froglight
setblock 6 295 471 minecraft:ochre_froglight
setblock 6 295 487 minecraft:ochre_froglight
setblock 6 295 489 minecraft:ochre_froglight
setblock 6 295 491 minecraft:ochre_froglight
setblock 6 295 493 minecraft:ochre_froglight
setblock 6 295 495 minecraft:ochre_froglight
setblock 7 295 464 minecraft:ochre_froglight
setblock 7 295 466 minecraft:ochre_froglight
setblock 7 295 468 minecraft:ochre_froglight
setblock 7 295 470 minecraft:ochre_froglight
setblock 7 295 472 minecraft:ochre_froglight
setblock 7 295 486 minecraft:ochre_froglight
setblock 7 295 488 minecraft:ochre_froglight
setblock 7 295 490 minecraft:ochre_froglight
setblock 7 295 492 minecraft:ochre_froglight
setblock 7 295 494 minecraft:ochre_froglight
setblock 7 295 496 minecraft:ochre_froglight
setblock 8 295 465 minecraft:ochre_froglight
setblock 8 295 467 minecraft:ochre_froglight
setblock 8 295 469 minecraft:ochre_froglight
setblock 8 295 471 minecraft:ochre_froglight
setblock 8 295 487 minecraft:ochre_froglight
setblock 8 295 489 minecraft:ochre_froglight
setblock 8 295 491 minecraft:ochre_froglight
setblock 8 295 493 minecraft:ochre_froglight
setblock 9 295 464 minecraft:ochre_froglight
setblock 9 295 466 minecraft:ochre_froglight
setblock 9 295 468 minecraft:ochre_froglight
setblock 9 295 470 minecraft:ochre_froglight
setblock 9 295 472 minecraft:ochre_froglight
setblock 9 295 504 minecraft:bookshelf
setblock 10 295 465 minecraft:ochre_froglight
setblock 10 295 467 minecraft:ochre_froglight
setblock 10 295 469 minecraft:ochre_froglight
setblock 10 295 471 minecraft:ochre_froglight
setblock 11 295 464 minecraft:ochre_froglight
setblock 11 295 466 minecraft:ochre_froglight
setblock 11 295 468 minecraft:ochre_froglight
setblock 11 295 470 minecraft:ochre_froglight
setblock 11 295 472 minecraft:ochre_froglight
setblock 12 295 465 minecraft:ochre_froglight
setblock 12 295 467 minecraft:ochre_froglight
setblock 12 295 469 minecraft:ochre_froglight
setblock 12 295 471 minecraft:ochre_froglight
setblock 13 295 464 minecraft:ochre_froglight
setblock 13 295 466 minecraft:ochre_froglight
setblock 14 295 465 minecraft:ochre_froglight
setblock 14 295 467 minecraft:ochre_froglight
setblock 14 295 497 minecraft:ochre_froglight
setblock 14 295 499 minecraft:ochre_froglight
setblock 14 295 501 minecraft:ochre_froglight
setblock 14 295 503 minecraft:ochre_froglight
setblock 15 295 464 minecraft:ochre_froglight
setblock 15 295 466 minecraft:ochre_froglight
setblock 15 295 496 minecraft:ochre_froglight
setblock 15 295 498 minecraft:ochre_froglight
setblock 15 295 500 minecraft:ochre_froglight
setblock 15 295 502 minecraft:ochre_froglight
setblock 15 295 504 minecraft:ochre_froglight
setblock 16 295 465 minecraft:ochre_froglight
setblock 16 295 467 minecraft:ochre_froglight
setblock 16 295 497 minecraft:ochre_froglight
setblock 16 295 499 minecraft:ochre_froglight
setblock 16 295 501 minecraft:ochre_froglight
setblock 16 295 503 minecraft:ochre_froglight
setblock 17 295 464 minecraft:ochre_froglight
setblock 17 295 466 minecraft:ochre_froglight
setblock 17 295 496 minecraft:ochre_froglight
setblock 17 295 498 minecraft:ochre_froglight
setblock 17 295 500 minecraft:ochre_froglight
setblock 17 295 502 minecraft:ochre_froglight
setblock 17 295 504 minecraft:ochre_froglight
setblock 18 295 465 minecraft:ochre_froglight
setblock 18 295 467 minecraft:ochre_froglight
setblock 18 295 497 minecraft:ochre_froglight
setblock 18 295 499 minecraft:ochre_froglight
setblock 18 295 501 minecraft:ochre_froglight
setblock 18 295 503 minecraft:ochre_froglight
setblock 19 295 464 minecraft:ochre_froglight
setblock 19 295 466 minecraft:ochre_froglight
setblock 19 295 496 minecraft:ochre_froglight
setblock 19 295 498 minecraft:ochre_froglight
setblock 19 295 500 minecraft:ochre_froglight
setblock 19 295 502 minecraft:ochre_froglight
setblock 19 295 504 minecraft:ochre_froglight
setblock 20 295 465 minecraft:ochre_froglight
setblock 20 295 467 minecraft:ochre_froglight
setblock 20 295 495 minecraft:ochre_froglight
setblock 20 295 497 minecraft:ochre_froglight
setblock 20 295 499 minecraft:ochre_froglight
setblock 20 295 501 minecraft:ochre_froglight
setblock 20 295 503 minecraft:ochre_froglight
setblock 21 295 496 minecraft:ochre_froglight
setblock 21 295 498 minecraft:ochre_froglight
setblock 21 295 500 minecraft:ochre_froglight
setblock 21 295 502 minecraft:ochre_froglight
setblock 21 295 504 minecraft:ochre_froglight
setblock 22 295 495 minecraft:ochre_froglight
setblock 22 295 497 minecraft:ochre_froglight
setblock 22 295 499 minecraft:ochre_froglight
setblock 22 295 501 minecraft:ochre_froglight
setblock 22 295 503 minecraft:ochre_froglight
setblock 23 295 464 minecraft:bookshelf
setblock 23 295 496 minecraft:ochre_froglight
setblock 23 295 498 minecraft:ochre_froglight
setblock 23 295 500 minecraft:ochre_froglight
setblock 23 295 502 minecraft:ochre_froglight
setblock 23 295 504 minecraft:ochre_froglight
setblock 24 295 495 minecraft:ochre_froglight
setblock 24 295 497 minecraft:ochre_froglight
setblock 24 295 499 minecraft:ochre_froglight
setblock 24 295 501 minecraft:ochre_froglight
setblock 24 295 503 minecraft:ochre_froglight
setblock 25 295 496 minecraft:ochre_froglight
setblock 25 295 498 minecraft:ochre_froglight
setblock 25 295 500 minecraft:ochre_froglight
setblock 25 295 502 minecraft:ochre_froglight
setblock 25 295 504 minecraft:ochre_froglight
setblock 26 295 495 minecraft:ochre_froglight
setblock 26 295 497 minecraft:ochre_froglight
setblock 26 295 499 minecraft:ochre_froglight
setblock 26 295 501 minecraft:ochre_froglight
setblock 26 295 503 minecraft:ochre_froglight
setblock 30 295 464 minecraft:bookshelf
setblock 30 295 504 minecraft:bookshelf
setblock 33 295 474 minecraft:ochre_froglight
setblock 33 295 476 minecraft:ochre_froglight
setblock 33 295 478 minecraft:ochre_froglight
setblock 33 295 480 minecraft:ochre_froglight
setblock 33 295 482 minecraft:ochre_froglight
setblock 34 295 475 minecraft:ochre_froglight
setblock 34 295 477 minecraft:ochre_froglight
setblock 34 295 479 minecraft:ochre_froglight
setblock 34 295 481 minecraft:ochre_froglight
setblock 35 295 474 minecraft:ochre_froglight
setblock 35 295 476 minecraft:ochre_froglight
setblock 35 295 478 minecraft:ochre_froglight
setblock 35 295 480 minecraft:ochre_froglight
setblock 35 295 482 minecraft:ochre_froglight
setblock 36 295 475 minecraft:ochre_froglight
setblock 36 295 477 minecraft:ochre_froglight
setblock 36 295 479 minecraft:ochre_froglight
setblock 36 295 481 minecraft:ochre_froglight
setblock 37 295 464 minecraft:bookshelf
setblock 37 295 474 minecraft:ochre_froglight
setblock 37 295 476 minecraft:ochre_froglight
setblock 37 295 478 minecraft:ochre_froglight
setblock 37 295 480 minecraft:ochre_froglight
setblock 37 295 482 minecraft:ochre_froglight
setblock 37 295 504 minecraft:bookshelf
setblock 38 295 475 minecraft:ochre_froglight
setblock 38 295 477 minecraft:ochre_froglight
setblock 38 295 479 minecraft:ochre_froglight
setblock 38 295 481 minecraft:ochre_froglight
setblock 39 295 474 minecraft:ochre_froglight
setblock 39 295 476 minecraft:ochre_froglight
setblock 39 295 478 minecraft:ochre_froglight
setblock 39 295 480 minecraft:ochre_froglight
setblock 39 295 482 minecraft:ochre_froglight
setblock 40 295 475 minecraft:ochre_froglight
setblock 40 295 477 minecraft:ochre_froglight
setblock 40 295 479 minecraft:ochre_froglight
setblock 40 295 481 minecraft:ochre_froglight
setblock 41 295 467 minecraft:bookshelf
setblock 41 295 474 minecraft:ochre_froglight
setblock 41 295 476 minecraft:ochre_froglight
setblock 41 295 478 minecraft:ochre_froglight
setblock 41 295 480 minecraft:ochre_froglight
setblock 41 295 482 minecraft:ochre_froglight
setblock 41 295 488 minecraft:bookshelf
setblock 41 295 495 minecraft:bookshelf
setblock 41 295 502 minecraft:bookshelf
setblock 1 296 464 minecraft:bookshelf
fill 1 296 471 2 296 471 minecraft:bookshelf
setblock 1 296 478 minecraft:bookshelf
fill 1 296 485 1 296 486 minecraft:bookshelf
fill 1 296 488 1 297 488 minecraft:bookshelf
fill 1 296 490 1 297 490 minecraft:bookshelf
fill 1 296 492 1 297 492 minecraft:bookshelf
fill 1 296 494 1 297 494 minecraft:bookshelf
fill 1 296 496 1 297 496 minecraft:bookshelf
setblock 1 296 499 minecraft:bookshelf
fill 2 296 465 2 297 465 minecraft:bookshelf
fill 2 296 467 2 297 467 minecraft:bookshelf
fill 2 296 469 2 297 469 minecraft:bookshelf
fill 2 296 487 2 297 487 minecraft:bookshelf
fill 2 296 489 2 297 489 minecraft:bookshelf
fill 2 296 491 2 297 491 minecraft:bookshelf
fill 2 296 493 2 297 493 minecraft:bookshelf
fill 2 296 495 2 297 495 minecraft:bookshelf
fill 3 296 464 3 297 464 minecraft:bookshelf
fill 3 296 466 3 297 466 minecraft:bookshelf
fill 3 296 468 3 297 468 minecraft:bookshelf
fill 3 296 470 3 297 470 minecraft:bookshelf
fill 3 296 472 3 297 472 minecraft:bookshelf
fill 3 296 486 3 297 486 minecraft:bookshelf
fill 3 296 488 3 297 488 minecraft:bookshelf
fill 3 296 490 3 297 490 minecraft:bookshelf
fill 3 296 492 3 297 492 minecraft:bookshelf
fill 3 296 494 3 297 494 minecraft:bookshelf
fill 3 296 496 3 297 496 minecraft:bookshelf
setblock 3 296 504 minecraft:bookshelf
fill 4 296 465 4 297 465 minecraft:bookshelf
fill 4 296 467 4 297 467 minecraft:bookshelf
fill 4 296 469 4 297 469 minecraft:bookshelf
fill 4 296 471 4 297 471 minecraft:bookshelf
fill 4 296 487 4 297 487 minecraft:bookshelf
fill 4 296 489 4 297 489 minecraft:bookshelf
fill 4 296 491 4 297 491 minecraft:bookshelf
fill 4 296 493 4 297 493 minecraft:bookshelf
fill 4 296 495 4 297 495 minecraft:bookshelf
fill 5 296 464 5 297 464 minecraft:bookshelf
fill 5 296 466 5 297 466 minecraft:bookshelf
fill 5 296 468 5 297 468 minecraft:bookshelf
fill 5 296 470 5 297 470 minecraft:bookshelf
fill 5 296 472 5 297 472 minecraft:bookshelf
fill 5 296 486 5 297 486 minecraft:bookshelf
fill 5 296 488 5 297 488 minecraft:bookshelf
fill 5 296 490 5 297 490 minecraft:bookshelf
fill 5 296 492 5 297 492 minecraft:bookshelf
fill 5 296 494 5 297 494 minecraft:bookshelf
fill 5 296 496 5 297 496 minecraft:bookshelf
fill 6 296 465 6 297 465 minecraft:bookshelf
fill 6 296 467 6 297 467 minecraft:bookshelf
fill 6 296 469 6 297 469 minecraft:bookshelf
fill 6 296 471 6 297 471 minecraft:bookshelf
fill 6 296 487 6 297 487 minecraft:bookshelf
fill 6 296 489 6 297 489 minecraft:bookshelf
fill 6 296 491 6 297 491 minecraft:bookshelf
fill 6 296 493 6 297 493 minecraft:bookshelf
fill 6 296 495 6 297 495 minecraft:bookshelf
fill 7 296 464 7 297 464 minecraft:bookshelf
fill 7 296 466 7 297 466 minecraft:bookshelf
fill 7 296 468 7 297 468 minecraft:bookshelf
fill 7 296 470 7 297 470 minecraft:bookshelf
fill 7 296 472 7 297 472 minecraft:bookshelf
fill 7 296 486 7 297 486 minecraft:bookshelf
fill 7 296 488 7 297 488 minecraft:bookshelf
fill 7 296 490 7 297 490 minecraft:bookshelf
fill 7 296 492 7 297 492 minecraft:bookshelf
fill 7 296 494 7 297 494 minecraft:bookshelf
fill 7 296 496 7 297 496 minecraft:bookshelf
fill 8 296 465 8 297 465 minecraft:bookshelf
fill 8 296 467 8 297 467 minecraft:bookshelf
fill 8 296 469 8 297 469 minecraft:bookshelf
fill 8 296 471 8 297 471 minecraft:bookshelf
fill 8 296 487 8 297 487 minecraft:bookshelf
fill 8 296 489 8 297 489 minecraft:bookshelf
fill 8 296 491 8 297 491 minecraft:bookshelf
fill 8 296 493 8 297 493 minecraft:bookshelf
fill 9 296 464 9 297 464 minecraft:bookshelf
fill 9 296 466 9 297 466 minecraft:bookshelf
fill 9 296 468 9 297 468 minecraft:bookshelf
fill 9 296 470 9 297 470 minecraft:bookshelf
fill 9 296 472 9 297 472 minecraft:bookshelf
fill 10 296 465 10 297 465 minecraft:bookshelf
fill 10 296 467 10 297 467 minecraft:bookshelf
fill 10 296 469 10 297 469 minecraft:bookshelf
fill 10 296 471 10 297 471 minecraft:bookshelf
fill 10 296 504 10 298 504 minecraft:bookshelf
fill 11 296 464 11 297 464 minecraft:bookshelf
fill 11 296 466 11 297 466 minecraft:bookshelf
fill 11 296 468 11 297 468 minecraft:bookshelf
fill 11 296 470 11 297 470 minecraft:bookshelf
fill 11 296 472 11 297 472 minecraft:bookshelf
fill 12 296 465 12 297 465 minecraft:bookshelf
fill 12 296 467 12 297 467 minecraft:bookshelf
fill 12 296 469 12 297 469 minecraft:bookshelf
fill 12 296 471 12 297 471 minecraft:bookshelf
fill 13 296 464 13 297 464 minecraft:bookshelf
fill 13 296 466 13 297 466 minecraft:bookshelf
fill 13 296 504 13 297 504 minecraft:bookshelf
fill 14 296 465 14 297 465 minecraft:bookshelf
fill 14 296 467 14 297 467 minecraft:bookshelf
fill 14 296 497 14 297 497 minecraft:bookshelf
fill 14 296 499 14 297 499 minecraft:bookshelf
fill 14 296 501 14 297 501 minecraft:bookshelf
fill 14 296 503 14 297 503 minecraft:bookshelf
fill 15 296 464 15 297 464 minecraft:bookshelf
fill 15 296 466 15 297 466 minecraft:bookshelf
fill 15 296 496 15 297 496 minecraft:bookshelf
fill 15 296 498 15 297 498 minecraft:bookshelf
fill 15 296 500 15 297 500 minecraft:bookshelf
fill 15 296 502 15 297 502 minecraft:bookshelf
fill 15 296 504 15 297 504 minecraft:bookshelf
fill 16 296 465 16 297 465 minecraft:bookshelf
fill 16 296 467 16 297 467 minecraft:bookshelf
fill 16 296 497 16 297 497 minecraft:bookshelf
fill 16 296 499 16 297 499 minecraft:bookshelf
fill 16 296 501 16 297 501 minecraft:bookshelf
fill 16 296 503 16 297 503 minecraft:bookshelf
fill 17 296 464 17 297 464 minecraft:bookshelf
fill 17 296 466 17 297 466 minecraft:bookshelf
fill 17 296 496 17 297 496 minecraft:bookshelf
fill 17 296 498 17 297 498 minecraft:bookshelf
fill 17 296 500 17 297 500 minecraft:bookshelf
fill 17 296 502 17 297 502 minecraft:bookshelf
fill 17 296 504 17 297 504 minecraft:bookshelf
fill 18 296 465 18 297 465 minecraft:bookshelf
fill 18 296 467 18 297 467 minecraft:bookshelf
fill 18 296 497 18 297 497 minecraft:bookshelf
fill 18 296 499 18 297 499 minecraft:bookshelf
fill 18 296 501 18 297 501 minecraft:bookshelf
fill 18 296 503 18 297 503 minecraft:bookshelf
fill 19 296 464 19 297 464 minecraft:bookshelf
fill 19 296 466 19 297 466 minecraft:bookshelf
fill 19 296 496 19 297 496 minecraft:bookshelf
fill 19 296 498 19 297 498 minecraft:bookshelf
fill 19 296 500 19 297 500 minecraft:bookshelf
fill 19 296 502 19 297 502 minecraft:bookshelf
fill 19 296 504 19 297 504 minecraft:bookshelf
fill 20 296 465 20 297 465 minecraft:bookshelf
fill 20 296 467 20 297 467 minecraft:bookshelf
fill 20 296 495 20 297 495 minecraft:bookshelf
fill 20 296 497 20 297 497 minecraft:bookshelf
fill 20 296 499 20 297 499 minecraft:bookshelf
fill 20 296 501 20 297 501 minecraft:bookshelf
fill 20 296 503 20 297 503 minecraft:bookshelf
fill 21 296 496 21 297 496 minecraft:bookshelf
fill 21 296 498 21 297 498 minecraft:bookshelf
fill 21 296 500 21 297 500 minecraft:bookshelf
fill 21 296 502 21 297 502 minecraft:bookshelf
fill 21 296 504 21 297 504 minecraft:bookshelf
setblock 22 296 464 minecraft:bookshelf
fill 22 296 495 22 297 495 minecraft:bookshelf
fill 22 296 497 22 297 497 minecraft:bookshelf
fill 22 296 499 22 297 499 minecraft:bookshelf
fill 22 296 501 22 297 501 minecraft:bookshelf
fill 22 296 503 22 297 503 minecraft:bookshelf
fill 23 296 496 23 297 496 minecraft:bookshelf
fill 23 296 498 23 297 498 minecraft:bookshelf
fill 23 296 500 23 297 500 minecraft:bookshelf
fill 23 296 502 23 297 502 minecraft:bookshelf
fill 23 296 504 23 297 504 minecraft:bookshelf
fill 24 296 495 24 297 495 minecraft:bookshelf
fill 24 296 497 24 297 497 minecraft:bookshelf
fill 24 296 499 24 297 499 minecraft:bookshelf
fill 24 296 501 24 297 501 minecraft:bookshelf
fill 24 296 503 24 297 503 minecraft:bookshelf
fill 25 296 496 25 297 496 minecraft:bookshelf
fill 25 296 498 25 297 498 minecraft:bookshelf
fill 25 296 500 25 297 500 minecraft:bookshelf
fill 25 296 502 25 297 502 minecraft:bookshelf
fill 25 296 504 25 297 504 minecraft:bookshelf
fill 26 296 495 26 297 495 minecraft:bookshelf
fill 26 296 497 26 297 497 minecraft:bookshelf
fill 26 296 499 26 297 499 minecraft:bookshelf
fill 26 296 501 26 297 501 minecraft:bookshelf
fill 26 296 503 26 297 503 minecraft:bookshelf
setblock 29 296 464 minecraft:bookshelf
setblock 31 296 504 minecraft:bookshelf
fill 33 296 474 33 297 474 minecraft:bookshelf
fill 33 296 476 33 297 476 minecraft:bookshelf
fill 33 296 478 33 297 478 minecraft:bookshelf
fill 33 296 480 33 297 480 minecraft:bookshelf
fill 33 296 482 33 297 482 minecraft:bookshelf
fill 34 296 475 34 297 475 minecraft:bookshelf
fill 34 296 477 34 297 477 minecraft:bookshelf
fill 34 296 479 34 297 479 minecraft:bookshelf
fill 34 296 481 34 297 481 minecraft:bookshelf
fill 35 296 474 35 297 474 minecraft:bookshelf
fill 35 296 476 35 297 476 minecraft:bookshelf
fill 35 296 478 35 297 478 minecraft:bookshelf
fill 35 296 480 35 297 480 minecraft:bookshelf
fill 35 296 482 35 297 482 minecraft:bookshelf
setblock 36 296 464 minecraft:bookshelf
fill 36 296 475 36 297 475 minecraft:bookshelf
fill 36 296 477 36 297 477 minecraft:bookshelf
fill 36 296 479 36 297 479 minecraft:bookshelf
fill 36 296 481 36 297 481 minecraft:bookshelf
fill 37 296 474 37 297 474 minecraft:bookshelf
fill 37 296 476 37 297 476 minecraft:bookshelf
fill 37 296 478 37 297 478 minecraft:bookshelf
fill 37 296 480 37 297 480 minecraft:bookshelf
fill 37 296 482 37 297 482 minecraft:bookshelf
fill 38 296 475 38 297 475 minecraft:bookshelf
fill 38 296 477 38 297 477 minecraft:bookshelf
fill 38 296 479 38 297 479 minecraft:bookshelf
fill 38 296 481 38 297 481 minecraft:bookshelf
setblock 38 296 504 minecraft:bookshelf
fill 39 296 474 39 297 474 minecraft:bookshelf
fill 39 296 476 39 297 476 minecraft:bookshelf
fill 39 296 478 39 297 478 minecraft:bookshelf
fill 39 296 480 39 297 480 minecraft:bookshelf
fill 39 296 482 39 297 482 minecraft:bookshelf
fill 40 296 475 40 297 475 minecraft:bookshelf
fill 40 296 477 40 297 477 minecraft:bookshelf
fill 40 296 479 40 297 479 minecraft:bookshelf
fill 40 296 481 40 297 481 minecraft:bookshelf
setblock 41 296 466 minecraft:bookshelf
fill 41 296 473 41 296 474 minecraft:bookshelf
fill 41 296 476 41 297 476 minecraft:bookshelf
fill 41 296 478 41 297 478 minecraft:bookshelf
fill 41 296 480 41 297 480 minecraft:bookshelf
fill 41 296 482 41 297 482 minecraft:bookshelf
setblock 41 296 487 minecraft:bookshelf
setblock 41 296 494 minecraft:bookshelf
setblock 41 296 501 minecraft:bookshelf
setblock 1 297 465 minecraft:bookshelf
setblock 1 297 472 minecraft:bookshelf
setblock 1 297 479 minecraft:bookshelf
setblock 1 297 486 minecraft:bookshelf
setblock 1 297 500 minecraft:bookshelf
setblock 2 297 471 minecraft:bookshelf
setblock 3 297 474 minecraft:light[level=12]
setblock 3 297 482 minecraft:light[level=12]
setblock 3 297 498 minecraft:light[level=12]
fill 4 297 504 4 300 504 minecraft:bookshelf
fill 9 297 504 9 298 504 minecraft:bookshelf
fill 10 297 502 13 297 503 minecraft:bookshelf
setblock 11 297 474 minecraft:light[level=12]
setblock 11 297 482 minecraft:light[level=12]
setblock 11 297 490 minecraft:light[level=12]
setblock 11 297 498 minecraft:light[level=12]
fill 11 297 504 12 298 504 minecraft:bookshelf
setblock 19 297 474 minecraft:light[level=12]
setblock 19 297 482 minecraft:light[level=12]
setblock 19 297 490 minecraft:light[level=12]
setblock 21 297 464 minecraft:bookshelf
setblock 27 297 466 minecraft:light[level=12]
setblock 27 297 474 minecraft:light[level=12]
setblock 27 297 482 minecraft:light[level=12]
setblock 27 297 490 minecraft:light[level=12]
setblock 27 297 498 minecraft:light[level=12]
setblock 28 297 464 minecraft:bookshelf
setblock 32 297 504 minecraft:bookshelf
setblock 35 297 464 minecraft:bookshelf
setblock 35 297 466 minecraft:light[level=12]
setblock 35 297 490 minecraft:light[level=12]
setblock 35 297 498 minecraft:light[level=12]
setblock 39 297 504 minecraft:bookshelf
setblock 41 297 465 minecraft:bookshelf
setblock 41 297 472 minecraft:bookshelf
setblock 41 297 474 minecraft:bookshelf
setblock 41 297 486 minecraft:bookshelf
setblock 41 297 493 minecraft:bookshelf
setblock 41 297 500 minecraft:bookshelf
setblock 1 298 466 minecraft:bookshelf
setblock 1 298 473 minecraft:bookshelf
setblock 1 298 480 minecraft:bookshelf
setblock 1 298 486 minecraft:ochre_froglight
setblock 1 298 488 minecraft:ochre_froglight
setblock 1 298 490 minecraft:ochre_froglight
setblock 1 298 492 minecraft:ochre_froglight
setblock 1 298 494 minecraft:ochre_froglight
setblock 1 298 496 minecraft:ochre_froglight
setblock 1 298 501 minecraft:bookshelf
setblock 2 298 465 minecraft:ochre_froglight
setblock 2 298 467 minecraft:ochre_froglight
setblock 2 298 469 minecraft:ochre_froglight
setblock 2 298 471 minecraft:ochre_froglight
setblock 2 298 487 minecraft:ochre_froglight
setblock 2 298 489 minecraft:ochre_froglight
setblock 2 298 491 minecraft:ochre_froglight
setblock 2 298 493 minecraft:ochre_froglight
setblock 2 298 495 minecraft:ochre_froglight
setblock 3 298 464 minecraft:ochre_froglight
setblock 3 298 466 minecraft:ochre_froglight
setblock 3 298 468 minecraft:ochre_froglight
setblock 3 298 470 minecraft:ochre_froglight
setblock 3 298 472 minecraft:ochre_froglight
setblock 3 298 486 minecraft:ochre_froglight
setblock 3 298 488 minecraft:ochre_froglight
setblock 3 298 490 minecraft:ochre_froglight
setblock 3 298 492 minecraft:ochre_froglight
setblock 3 298 494 minecraft:ochre_froglight
setblock 3 298 496 minecraft:ochre_froglight
setblock 4 298 465 minecraft:ochre_froglight
setblock 4 298 467 minecraft:ochre_froglight
setblock 4 298 469 minecraft:ochre_froglight
setblock 4 298 471 minecraft:ochre_froglight
setblock 4 298 487 minecraft:ochre_froglight
setblock 4 298 489 minecraft:ochre_froglight
setblock 4 298 491 minecraft:ochre_froglight
setblock 4 298 493 minecraft:ochre_froglight
setblock 4 298 495 minecraft:ochre_froglight
setblock 5 298 464 minecraft:ochre_froglight
setblock 5 298 466 minecraft:ochre_froglight
setblock 5 298 468 minecraft:ochre_froglight
setblock 5 298 470 minecraft:ochre_froglight
setblock 5 298 472 minecraft:ochre_froglight
setblock 5 298 486 minecraft:ochre_froglight
setblock 5 298 488 minecraft:ochre_froglight
setblock 5 298 490 minecraft:ochre_froglight
setblock 5 298 492 minecraft:ochre_froglight
setblock 5 298 494 minecraft:ochre_froglight
setblock 5 298 496 minecraft:ochre_froglight
fill 5 298 503 7 298 504 minecraft:bookshelf
setblock 6 298 465 minecraft:ochre_froglight
setblock 6 298 467 minecraft:ochre_froglight
setblock 6 298 469 minecraft:ochre_froglight
setblock 6 298 471 minecraft:ochre_froglight
setblock 6 298 487 minecraft:ochre_froglight
setblock 6 298 489 minecraft:ochre_froglight
setblock 6 298 491 minecraft:ochre_froglight
setblock 6 298 493 minecraft:ochre_froglight
setblock 6 298 495 minecraft:ochre_froglight
fill 6 298 502 12 298 502 minecraft:bookshelf
setblock 7 298 464 minecraft:ochre_froglight
setblock 7 298 466 minecraft:ochre_froglight
setblock 7 298 468 minecraft:ochre_froglight
setblock 7 298 470 minecraft:ochre_froglight
setblock 7 298 472 minecraft:ochre_froglight
setblock 7 298 486 minecraft:ochre_froglight
setblock 7 298 488 minecraft:ochre_froglight
setblock 7 298 490 minecraft:ochre_froglight
setblock 7 298 492 minecraft:ochre_froglight
setblock 7 298 494 minecraft:ochre_froglight
setblock 7 298 496 minecraft:ochre_froglight
setblock 8 298 465 minecraft:ochre_froglight
setblock 8 298 467 minecraft:ochre_froglight
setblock 8 298 469 minecraft:ochre_froglight
setblock 8 298 471 minecraft:ochre_froglight
setblock 8 298 487 minecraft:ochre_froglight
setblock 8 298 489 minecraft:ochre_froglight
setblock 8 298 491 minecraft:ochre_froglight
setblock 8 298 493 minecraft:ochre_froglight
fill 8 298 503 11 298 503 minecraft:bookshelf
setblock 9 298 464 minecraft:ochre_froglight
setblock 9 298 466 minecraft:ochre_froglight
setblock 9 298 468 minecraft:ochre_froglight
setblock 9 298 470 minecraft:ochre_froglight
setblock 9 298 472 minecraft:ochre_froglight
setblock 10 298 465 minecraft:ochre_froglight
setblock 10 298 467 minecraft:ochre_froglight
setblock 10 298 469 minecraft:ochre_froglight
setblock 10 298 471 minecraft:ochre_froglight
setblock 11 298 464 minecraft:ochre_froglight
setblock 11 298 466 minecraft:ochre_froglight
setblock 11 298 468 minecraft:ochre_froglight
setblock 11 298 470 minecraft:ochre_froglight
setblock 11 298 472 minecraft:ochre_froglight
setblock 12 298 465 minecraft:ochre_froglight
setblock 12 298 467 minecraft:ochre_froglight
setblock 12 298 469 minecraft:ochre_froglight
setblock 12 298 471 minecraft:ochre_froglight
setblock 13 298 464 minecraft:ochre_froglight
setblock 13 298 466 minecraft:ochre_froglight
setblock 14 298 465 minecraft:ochre_froglight
setblock 14 298 467 minecraft:ochre_froglight
setblock 14 298 497 minecraft:ochre_froglight
setblock 14 298 499 minecraft:ochre_froglight
setblock 14 298 501 minecraft:ochre_froglight
setblock 14 298 503 minecraft:ochre_froglight
setblock 15 298 464 minecraft:ochre_froglight
setblock 15 298 466 minecraft:ochre_froglight
setblock 15 298 496 minecraft:ochre_froglight
setblock 15 298 498 minecraft:ochre_froglight
setblock 15 298 500 minecraft:ochre_froglight
setblock 15 298 502 minecraft:ochre_froglight
setblock 15 298 504 minecraft:ochre_froglight
setblock 16 298 465 minecraft:ochre_froglight
setblock 16 298 467 minecraft:ochre_froglight
setblock 16 298 497 minecraft:ochre_froglight
setblock 16 298 499 minecraft:ochre_froglight
setblock 16 298 501 minecraft:ochre_froglight
setblock 16 298 503 minecraft:ochre_froglight
setblock 17 298 464 minecraft:ochre_froglight
setblock 17 298 466 minecraft:ochre_froglight
setblock 17 298 496 minecraft:ochre_froglight
setblock 17 298 498 minecraft:ochre_froglight
setblock 17 298 500 minecraft:ochre_froglight
setblock 17 298 502 minecraft:ochre_froglight
setblock 17 298 504 minecraft:ochre_froglight
setblock 18 298 465 minecraft:ochre_froglight
setblock 18 298 467 minecraft:ochre_froglight
setblock 18 298 497 minecraft:ochre_froglight
setblock 18 298 499 minecraft:ochre_froglight
setblock 18 298 501 minecraft:ochre_froglight
setblock 18 298 503 minecraft:ochre_froglight
setblock 19 298 464 minecraft:ochre_froglight
setblock 19 298 466 minecraft:ochre_froglight
setblock 19 298 496 minecraft:ochre_froglight
setblock 19 298 498 minecraft:ochre_froglight
setblock 19 298 500 minecraft:ochre_froglight
setblock 19 298 502 minecraft:ochre_froglight
setblock 19 298 504 minecraft:ochre_froglight
setblock 20 298 465 minecraft:ochre_froglight
setblock 20 298 467 minecraft:ochre_froglight
setblock 20 298 495 minecraft:ochre_froglight
setblock 20 298 497 minecraft:ochre_froglight
setblock 20 298 499 minecraft:ochre_froglight
setblock 20 298 501 minecraft:ochre_froglight
setblock 20 298 503 minecraft:ochre_froglight
setblock 21 298 496 minecraft:ochre_froglight
setblock 21 298 498 minecraft:ochre_froglight
setblock 21 298 500 minecraft:ochre_froglight
setblock 21 298 502 minecraft:ochre_froglight
setblock 21 298 504 minecraft:ochre_froglight
setblock 22 298 495 minecraft:ochre_froglight
setblock 22 298 497 minecraft:ochre_froglight
setblock 22 298 499 minecraft:ochre_froglight
setblock 22 298 501 minecraft:ochre_froglight
setblock 22 298 503 minecraft:ochre_froglight
setblock 23 298 496 minecraft:ochre_froglight
setblock 23 298 498 minecraft:ochre_froglight
setblock 23 298 500 minecraft:ochre_froglight
setblock 23 298 502 minecraft:ochre_froglight
setblock 23 298 504 minecraft:ochre_froglight
setblock 24 298 495 minecraft:ochre_froglight
setblock 24 298 497 minecraft:ochre_froglight
setblock 24 298 499 minecraft:ochre_froglight
setblock 24 298 501 minecraft:ochre_froglight
setblock 24 298 503 minecraft:ochre_froglight
setblock 25 298 496 minecraft:ochre_froglight
setblock 25 298 498 minecraft:ochre_froglight
setblock 25 298 500 minecraft:ochre_froglight
setblock 25 298 502 minecraft:ochre_froglight
setblock 25 298 504 minecraft:ochre_froglight
setblock 26 298 495 minecraft:ochre_froglight
setblock 26 298 497 minecraft:ochre_froglight
setblock 26 298 499 minecraft:ochre_froglight
setblock 26 298 501 minecraft:ochre_froglight
setblock 26 298 503 minecraft:ochre_froglight
setblock 27 298 464 minecraft:bookshelf
setblock 33 298 474 minecraft:ochre_froglight
setblock 33 298 476 minecraft:ochre_froglight
setblock 33 298 478 minecraft:ochre_froglight
setblock 33 298 480 minecraft:ochre_froglight
setblock 33 298 482 minecraft:ochre_froglight
setblock 33 298 504 minecraft:bookshelf
setblock 34 298 464 minecraft:bookshelf
setblock 34 298 475 minecraft:ochre_froglight
setblock 34 298 477 minecraft:ochre_froglight
setblock 34 298 479 minecraft:ochre_froglight
setblock 34 298 481 minecraft:ochre_froglight
setblock 35 298 474 minecraft:ochre_froglight
setblock 35 298 476 minecraft:ochre_froglight
setblock 35 298 478 minecraft:ochre_froglight
setblock 35 298 480 minecraft:ochre_froglight
setblock 35 298 482 minecraft:ochre_froglight
setblock 36 298 475 minecraft:ochre_froglight
setblock 36 298 477 minecraft:ochre_froglight
setblock 36 298 479 minecraft:ochre_froglight
setblock 36 298 481 minecraft:ochre_froglight
setblock 37 298 474 minecraft:ochre_froglight
setblock 37 298 476 minecraft:ochre_froglight
setblock 37 298 478 minecraft:ochre_froglight
setblock 37 298 480 minecraft:ochre_froglight
setblock 37 298 482 minecraft:ochre_froglight
setblock 38 298 475 minecraft:ochre_froglight
setblock 38 298 477 minecraft:ochre_froglight
setblock 38 298 479 minecraft:ochre_froglight
setblock 38 298 481 minecraft:ochre_froglight
setblock 39 298 474 minecraft:ochre_froglight
setblock 39 298 476 minecraft:ochre_froglight
setblock 39 298 478 minecraft:ochre_froglight
setblock 39 298 480 minecraft:ochre_froglight
setblock 39 298 482 minecraft:ochre_froglight
setblock 40 298 475 minecraft:ochre_froglight
setblock 40 298 477 minecraft:ochre_froglight
setblock 40 298 479 minecraft:ochre_froglight
setblock 40 298 481 minecraft:ochre_froglight
setblock 40 298 504 minecraft:bookshelf
setblock 41 298 464 minecraft:bookshelf
setblock 41 298 471 minecraft:bookshelf
setblock 41 298 474 minecraft:ochre_froglight
setblock 41 298 476 minecraft:ochre_froglight
setblock 41 298 478 minecraft:ochre_froglight
setblock 41 298 480 minecraft:ochre_froglight
setblock 41 298 482 minecraft:ochre_froglight
setblock 41 298 485 minecraft:bookshelf
setblock 41 298 492 minecraft:bookshelf
setblock 41 298 499 minecraft:bookshelf
fill 1 299 467 2 300 467 minecraft:bookshelf
fill 1 299 474 1 300 474 minecraft:bookshelf
fill 1 299 481 1 300 481 minecraft:bookshelf
fill 1 299 486 1 300 486 minecraft:bookshelf
fill 1 299 488 1 300 488 minecraft:bookshelf
fill 1 299 490 1 300 490 minecraft:bookshelf
fill 1 299 492 1 300 492 minecraft:bookshelf
fill 1 299 494 1 300 494 minecraft:bookshelf
fill 1 299 496 1 300 496 minecraft:bookshelf
fill 1 299 502 7 299 503 minecraft:bookshelf
fill 2 299 465 2 300 465 minecraft:bookshelf
fill 2 299 469 2 300 469 minecraft:bookshelf
fill 2 299 471 2 300 471 minecraft:bookshelf
fill 2 299 487 2 300 487 minecraft:bookshelf
fill 2 299 489 2 300 489 minecraft:bookshelf
fill 2 299 491 2 300 491 minecraft:bookshelf
fill 2 299 493 2 300 493 minecraft:bookshelf
fill 2 299 495 2 300 495 minecraft:bookshelf
fill 2 299 501 3 300 501 minecraft:bookshelf
fill 2 299 504 3 300 504 minecraft:bookshelf
fill 3 299 464 3 300 464 minecraft:bookshelf
fill 3 299 466 3 300 466 minecraft:bookshelf
fill 3 299 468 3 300 468 minecraft:bookshelf
fill 3 299 470 3 300 470 minecraft:bookshelf
fill 3 299 472 3 300 472 minecraft:bookshelf
fill 3 299 486 3 300 486 minecraft:bookshelf
fill 3 299 488 3 300 488 minecraft:bookshelf
fill 3 299 490 3 300 490 minecraft:bookshelf
fill 3 299 492 3 300 492 minecraft:bookshelf
fill 3 299 494 3 300 494 minecraft:bookshelf
fill 3 299 496 3 300 496 minecraft:bookshelf
fill 3 299 500 3 300 500 minecraft:bookshelf
fill 4 299 465 4 300 465 minecraft:bookshelf
fill 4 299 467 4 300 467 minecraft:bookshelf
fill 4 299 469 4 300 469 minecraft:bookshelf
fill 4 299 471 4 300 471 minecraft:bookshelf
fill 4 299 487 4 300 487 minecraft:bookshelf
fill 4 299 489 4 300 489 minecraft:bookshelf
fill 4 299 491 4 300 491 minecraft:bookshelf
fill 4 299 493 4 300 493 minecraft:bookshelf
fill 4 299 495 4 300 495 minecraft:bookshelf
fill 5 299 464 5 300 464 minecraft:bookshelf
fill 5 299 466 5 300 466 minecraft:bookshelf
fill 5 299 468 5 300 468 minecraft:bookshelf
fill 5 299 470 5 300 470 minecraft:bookshelf
fill 5 299 472 5 300 472 minecraft:bookshelf
fill 5 299 486 5 300 486 minecraft:bookshelf
fill 5 299 488 5 300 488 minecraft:bookshelf
fill 5 299 490 5 300 490 minecraft:bookshelf
fill 5 299 492 5 300 492 minecraft:bookshelf
fill 5 299 494 5 300 494 minecraft:bookshelf
fill 5 299 496 5 300 496 minecraft:bookshelf
fill 5 299 504 6 300 504 minecraft:bookshelf
fill 6 299 465 6 300 465 minecraft:bookshelf
fill 6 299 467 6 300 467 minecraft:bookshelf
fill 6 299 469 6 300 469 minecraft:bookshelf
fill 6 299 471 6 300 471 minecraft:bookshelf
fill 6 299 487 6 300 487 minecraft:bookshelf
fill 6 299 489 6 300 489 minecraft:bookshelf
fill 6 299 491 6 300 491 minecraft:bookshelf
fill 6 299 493 6 300 493 minecraft:bookshelf
fill 6 299 495 6 300 495 minecraft:bookshelf
fill 7 299 464 7 300 464 minecraft:bookshelf
fill 7 299 466 7 300 466 minecraft:bookshelf
fill 7 299 468 7 300 468 minecraft:bookshelf
fill 7 299 470 7 300 470 minecraft:bookshelf
fill 7 299 472 7 300 472 minecraft:bookshelf
fill 7 299 486 7 300 486 minecraft:bookshelf
fill 7 299 488 7 300 488 minecraft:bookshelf
fill 7 299 490 7 300 490 minecraft:bookshelf
fill 7 299 492 7 300 492 minecraft:bookshelf
fill 7 299 494 7 300 494 minecraft:bookshelf
fill 7 299 496 7 300 496 minecraft:bookshelf
fill 8 299 465 8 300 465 minecraft:bookshelf
fill 8 299 467 8 300 467 minecraft:bookshelf
fill 8 299 469 8 300 469 minecraft:bookshelf
fill 8 299 471 8 300 471 minecraft:bookshelf
fill 8 299 487 8 300 487 minecraft:bookshelf
fill 8 299 489 8 300 489 minecraft:bookshelf
fill 8 299 491 8 300 491 minecraft:bookshelf
fill 8 299 493 8 300 493 minecraft:bookshelf
setblock 8 299 502 minecraft:bookshelf
fill 9 299 464 9 300 464 minecraft:bookshelf
fill 9 299 466 9 300 466 minecraft:bookshelf
fill 9 299 468 9 300 468 minecraft:bookshelf
fill 9 299 470 9 300 470 minecraft:bookshelf
fill 9 299 472 9 300 472 minecraft:bookshelf
fill 10 299 465 10 300 465 minecraft:bookshelf
fill 10 299 467 10 300 467 minecraft:bookshelf
fill 10 299 469 10 300 469 minecraft:bookshelf
fill 10 299 471 10 300 471 minecraft:bookshelf
fill 11 299 464 11 300 464 minecraft:bookshelf
fill 11 299 466 11 300 466 minecraft:bookshelf
fill 11 299 468 11 300 468 minecraft:bookshelf
fill 11 299 470 11 300 470 minecraft:bookshelf
fill 11 299 472 11 300 472 minecraft:bookshelf
fill 12 299 465 12 300 465 minecraft:bookshelf
fill 12 299 467 12 300 467 minecraft:bookshelf
fill 12 299 469 12 300 469 minecraft:bookshelf
fill 12 299 471 12 300 471 minecraft:bookshelf
fill 13 299 464 13 300 464 minecraft:bookshelf
fill 13 299 466 13 300 466 minecraft:bookshelf
fill 13 299 504 13 300 504 minecraft:bookshelf
fill 14 299 465 14 300 465 minecraft:bookshelf
fill 14 299 467 14 300 467 minecraft:bookshelf
fill 14 299 497 14 300 497 minecraft:bookshelf
fill 14 299 499 14 300 499 minecraft:bookshelf
fill 14 299 501 14 300 501 minecraft:bookshelf
fill 14 299 503 14 300 503 minecraft:bookshelf
fill 15 299 464 15 300 464 minecraft:bookshelf
fill 15 299 466 15 300 466 minecraft:bookshelf
fill 15 299 496 15 300 496 minecraft:bookshelf
fill 15 299 498 15 300 498 minecraft:bookshelf
fill 15 299 500 15 300 500 minecraft:bookshelf
fill 15 299 502 15 300 502 minecraft:bookshelf
fill 15 299 504 15 300 504 minecraft:bookshelf
fill 16 299 465 16 300 465 minecraft:bookshelf
fill 16 299 467 16 300 467 minecraft:bookshelf
fill 16 299 497 16 300 497 minecraft:bookshelf
fill 16 299 499 16 300 499 minecraft:bookshelf
fill 16 299 501 16 300 501 minecraft:bookshelf
fill 16 299 503 16 300 503 minecraft:bookshelf
fill 17 299 464 17 300 464 minecraft:bookshelf
fill 17 299 466 17 300 466 minecraft:bookshelf
fill 17 299 496 17 300 496 minecraft:bookshelf
fill 17 299 498 17 300 498 minecraft:bookshelf
fill 17 299 500 17 300 500 minecraft:bookshelf
fill 17 299 502 17 300 502 minecraft:bookshelf
fill 17 299 504 17 300 504 minecraft:bookshelf
fill 18 299 465 18 300 465 minecraft:bookshelf
fill 18 299 467 18 300 467 minecraft:bookshelf
fill 18 299 497 18 300 497 minecraft:bookshelf
fill 18 299 499 18 300 499 minecraft:bookshelf
fill 18 299 501 18 300 501 minecraft:bookshelf
fill 18 299 503 18 300 503 minecraft:bookshelf
fill 19 299 464 19 300 464 minecraft:bookshelf
fill 19 299 466 19 300 466 minecraft:bookshelf
fill 19 299 496 19 300 496 minecraft:bookshelf
fill 19 299 498 19 300 498 minecraft:bookshelf
fill 19 299 500 19 300 500 minecraft:bookshelf
fill 19 299 502 19 300 502 minecraft:bookshelf
fill 19 299 504 19 300 504 minecraft:bookshelf
fill 20 299 465 20 300 465 minecraft:bookshelf
fill 20 299 467 20 300 467 minecraft:bookshelf
fill 20 299 495 20 300 495 minecraft:bookshelf
fill 20 299 497 20 300 497 minecraft:bookshelf
fill 20 299 499 20 300 499 minecraft:bookshelf
fill 20 299 501 20 300 501 minecraft:bookshelf
fill 20 299 503 20 300 503 minecraft:bookshelf
fill 21 299 496 21 300 496 minecraft:bookshelf
fill 21 299 498 21 300 498 minecraft:bookshelf
fill 21 299 500 21 300 500 minecraft:bookshelf
fill 21 299 502 21 300 502 minecraft:bookshelf
fill 21 299 504 21 300 504 minecraft:bookshelf
fill 22 299 495 22 300 495 minecraft:bookshelf
fill 22 299 497 22 300 497 minecraft:bookshelf
fill 22 299 499 22 300 499 minecraft:bookshelf
fill 22 299 501 22 300 501 minecraft:bookshelf
fill 22 299 503 22 300 503 minecraft:bookshelf
fill 23 299 496 23 300 496 minecraft:bookshelf
fill 23 299 498 23 300 498 minecraft:bookshelf
fill 23 299 500 23 300 500 minecraft:bookshelf
fill 23 299 502 23 300 502 minecraft:bookshelf
fill 23 299 504 23 300 504 minecraft:bookshelf
fill 24 299 495 24 300 495 minecraft:bookshelf
fill 24 299 497 24 300 497 minecraft:bookshelf
fill 24 299 499 24 300 499 minecraft:bookshelf
fill 24 299 501 24 300 501 minecraft:bookshelf
fill 24 299 503 24 300 503 minecraft:bookshelf
fill 25 299 496 25 300 496 minecraft:bookshelf
fill 25 299 498 25 300 498 minecraft:bookshelf
fill 25 299 500 25 300 500 minecraft:bookshelf
fill 25 299 502 25 300 502 minecraft:bookshelf
fill 25 299 504 25 300 504 minecraft:bookshelf
fill 26 299 464 26 300 464 minecraft:bookshelf
fill 26 299 495 26 300 495 minecraft:bookshelf
fill 26 299 497 26 300 497 minecraft:bookshelf
fill 26 299 499 26 300 499 minecraft:bookshelf
fill 26 299 501 26 300 501 minecraft:bookshelf
fill 26 299 503 26 300 503 minecraft:bookshelf
fill 27 299 504 27 300 504 minecraft:bookshelf
fill 33 299 464 33 300 464 minecraft:bookshelf
fill 33 299 474 33 300 474 minecraft:bookshelf
fill 33 299 476 33 300 476 minecraft:bookshelf
fill 33 299 478 33 300 478 minecraft:bookshelf
fill 33 299 480 33 300 480 minecraft:bookshelf
fill 33 299 482 33 300 482 minecraft:bookshelf
fill 34 299 475 34 300 475 minecraft:bookshelf
fill 34 299 477 34 300 477 minecraft:bookshelf
fill 34 299 479 34 300 479 minecraft:bookshelf
fill 34 299 481 34 300 481 minecraft:bookshelf
fill 34 299 504 34 300 504 minecraft:bookshelf
fill 35 299 474 35 300 474 minecraft:bookshelf
fill 35 299 476 35 300 476 minecraft:bookshelf
fill 35 299 478 35 300 478 minecraft:bookshelf
fill 35 299 480 35 300 480 minecraft:bookshelf
fill 35 299 482 35 300 482 minecraft:bookshelf
fill 36 299 475 36 300 475 minecraft:bookshelf
fill 36 299 477 36 300 477 minecraft:bookshelf
fill 36 299 479 36 300 479 minecraft:bookshelf
fill 36 299 481 36 300 481 minecraft:bookshelf
fill 37 299 474 37 300 474 minecraft:bookshelf
fill 37 299 476 37 300 476 minecraft:bookshelf
fill 37 299 478 37 300 478 minecraft:bookshelf
fill 37 299 480 37 300 480 minecraft:bookshelf
fill 37 299 482 37 300 482 minecraft:bookshelf
fill 38 299 475 38 300 475 minecraft:bookshelf
fill 38 299 477 38 300 477 minecraft:bookshelf
fill 38 299 479 38 300 479 minecraft:bookshelf
fill 38 299 481 38 300 481 minecraft:bookshelf
fill 39 299 474 39 300 474 minecraft:bookshelf
fill 39 299 476 39 300 476 minecraft:bookshelf
fill 39 299 478 39 300 478 minecraft:bookshelf
fill 39 299 480 39 300 480 minecraft:bookshelf
fill 39 299 482 39 300 482 minecraft:bookshelf
fill 40 299 464 40 300 464 minecraft:bookshelf
fill 40 299 475 40 300 475 minecraft:bookshelf
fill 40 299 477 40 300 477 minecraft:bookshelf
fill 40 299 479 40 300 479 minecraft:bookshelf
fill 40 299 481 40 300 481 minecraft:bookshelf
fill 41 299 470 41 300 470 minecraft:bookshelf
fill 41 299 474 41 300 474 minecraft:bookshelf
fill 41 299 476 41 300 476 minecraft:bookshelf
fill 41 299 478 41 300 478 minecraft:bookshelf
fill 41 299 480 41 300 480 minecraft:bookshelf
fill 41 299 482 41 300 482 minecraft:bookshelf
fill 41 299 484 41 300 484 minecraft:bookshelf
fill 41 299 491 41 300 491 minecraft:bookshelf
fill 41 299 498 41 300 498 minecraft:bookshelf
fill 41 299 504 41 300 504 minecraft:bookshelf
fill 1 300 464 1 300 466 minecraft:bookshelf
setblock 1 300 468 minecraft:bookshelf
fill 1 300 470 1 300 473 minecraft:bookshelf
setblock 1 300 475 minecraft:bookshelf
fill 1 300 477 1 300 480 minecraft:bookshelf
setblock 1 300 482 minecraft:bookshelf
fill 1 300 484 1 300 485 minecraft:bookshelf
fill 1 300 498 1 300 503 minecraft:bookshelf
fill 2 300 497 2 300 500 minecraft:bookshelf
fill 2 300 502 2 300 503 minecraft:bookshelf
fill 3 300 497 3 300 499 minecraft:bookshelf
setblock 3 300 502 minecraft:bookshelf
setblock 7 300 504 minecraft:bookshelf
fill 9 300 504 12 300 504 minecraft:bookshelf
fill 21 300 464 23 300 464 minecraft:bookshelf
setblock 25 300 464 minecraft:bookshelf
fill 27 300 464 30 300 464 minecraft:bookshelf
setblock 28 300 504 minecraft:bookshelf
fill 30 300 504 33 300 504 minecraft:bookshelf
setblock 32 300 464 minecraft:bookshelf
fill 34 300 464 37 300 464 minecraft:bookshelf
setblock 35 300 504 minecraft:bookshelf
fill 37 300 504 40 300 504 minecraft:bookshelf
setblock 39 300 464 minecraft:bookshelf
fill 41 300 464 41 300 467 minecraft:bookshelf
setblock 41 300 469 minecraft:bookshelf
fill 41 300 471 41 300 473 minecraft:bookshelf
setblock 41 300 483 minecraft:bookshelf
fill 41 300 485 41 300 488 minecraft:bookshelf
setblock 41 300 490 minecraft:bookshelf
fill 41 300 492 41 300 495 minecraft:bookshelf
setblock 41 300 497 minecraft:bookshelf
fill 41 300 499 41 300 502 minecraft:bookshelf
