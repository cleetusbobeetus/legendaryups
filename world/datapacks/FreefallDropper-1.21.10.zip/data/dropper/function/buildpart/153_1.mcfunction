fill 450 137 610 451 137 610 minecraft:purple_concrete
fill 450 137 640 451 137 640 minecraft:purple_concrete
fill 452 137 611 455 137 611 minecraft:purple_concrete
fill 452 137 639 455 137 639 minecraft:purple_concrete
setblock 453 137 610 minecraft:purple_concrete
setblock 453 137 640 minecraft:purple_concrete
fill 454 137 612 456 137 612 minecraft:purple_concrete
fill 454 137 638 456 137 638 minecraft:purple_concrete
fill 455 137 613 457 137 613 minecraft:purple_concrete
fill 455 137 637 457 137 637 minecraft:purple_concrete
fill 456 137 614 458 137 614 minecraft:purple_concrete
fill 456 137 636 458 137 636 minecraft:purple_concrete
fill 457 137 615 458 137 615 minecraft:purple_concrete
fill 457 137 635 458 137 635 minecraft:purple_concrete
fill 458 137 616 458 137 617 minecraft:purple_concrete
fill 458 137 633 458 137 634 minecraft:purple_concrete
setblock 459 137 616 minecraft:purple_concrete
fill 459 137 618 460 137 619 minecraft:purple_concrete
fill 459 137 631 460 137 632 minecraft:purple_concrete
setblock 459 137 634 minecraft:purple_concrete
setblock 460 137 617 minecraft:purple_concrete
fill 460 137 620 460 137 630 minecraft:purple_concrete
setblock 460 137 633 minecraft:purple_concrete
fill 461 137 620 461 137 624 minecraft:purple_concrete
fill 461 137 626 461 137 630 minecraft:purple_concrete
setblock 462 137 625 minecraft:purple_concrete
setblock 426 138 607 minecraft:light[level=13]
setblock 426 138 615 minecraft:light[level=13]
setblock 426 138 623 minecraft:light[level=13]
setblock 426 138 631 minecraft:light[level=13]
setblock 426 138 639 minecraft:light[level=13]
setblock 434 138 607 minecraft:light[level=13]
setblock 434 138 615 minecraft:light[level=13]
setblock 434 138 623 minecraft:light[level=13]
setblock 434 138 631 minecraft:light[level=13]
setblock 434 138 639 minecraft:light[level=13]
setblock 442 138 607 minecraft:light[level=13]
setblock 442 138 615 minecraft:light[level=13]
setblock 442 138 623 minecraft:light[level=13]
setblock 442 138 631 minecraft:light[level=13]
setblock 442 138 639 minecraft:light[level=13]
setblock 450 138 607 minecraft:light[level=13]
setblock 450 138 615 minecraft:light[level=13]
setblock 450 138 623 minecraft:light[level=13]
setblock 450 138 631 minecraft:light[level=13]
setblock 450 138 639 minecraft:light[level=13]
setblock 458 138 607 minecraft:light[level=13]
setblock 458 138 615 minecraft:light[level=13]
setblock 458 138 623 minecraft:light[level=13]
setblock 458 138 631 minecraft:light[level=13]
setblock 458 138 639 minecraft:light[level=13]
fill 460 138 623 461 139 624 minecraft:white_concrete
fill 424 140 605 424 141 610 minecraft:quartz_block
fill 424 140 613 425 140 618 minecraft:quartz_block
fill 424 140 621 425 140 626 minecraft:quartz_block
fill 424 140 629 425 140 634 minecraft:quartz_block
fill 424 140 637 425 140 642 minecraft:quartz_block
fill 424 140 645 429 141 645 minecraft:quartz_block
fill 425 140 606 425 140 612 minecraft:quartz_block
fill 425 140 619 425 140 620 minecraft:quartz_block
fill 425 140 627 425 140 628 minecraft:quartz_block
fill 425 140 635 425 140 636 minecraft:quartz_block
fill 425 140 643 425 140 644 minecraft:quartz_block
fill 426 140 606 463 140 606 minecraft:quartz_block
fill 426 140 644 464 140 644 minecraft:quartz_block
fill 427 140 605 432 141 605 minecraft:quartz_block
fill 432 140 645 437 141 645 minecraft:quartz_block
fill 435 140 605 440 141 605 minecraft:quartz_block
fill 440 140 645 445 141 645 minecraft:quartz_block
fill 443 140 605 448 141 605 minecraft:quartz_block
fill 448 140 645 453 141 645 minecraft:quartz_block
fill 451 140 605 456 141 605 minecraft:quartz_block
fill 456 140 645 461 141 645 minecraft:quartz_block
fill 459 140 605 464 141 605 minecraft:quartz_block
fill 463 140 607 463 140 643 minecraft:quartz_block
fill 464 140 608 464 141 613 minecraft:quartz_block
fill 464 140 616 464 141 621 minecraft:quartz_block
fill 464 140 624 464 141 629 minecraft:quartz_block
fill 464 140 632 464 141 637 minecraft:quartz_block
fill 464 140 640 464 141 643 minecraft:quartz_block
fill 464 140 645 464 141 645 minecraft:quartz_block
fill 424 141 613 424 141 618 minecraft:quartz_block
fill 424 141 621 424 141 626 minecraft:quartz_block
fill 424 141 629 424 141 634 minecraft:quartz_block
fill 424 141 637 424 141 642 minecraft:quartz_block
setblock 464 141 644 minecraft:quartz_block
fill 443 143 616 445 144 616 minecraft:black_concrete
fill 444 143 617 445 144 617 minecraft:black_concrete
fill 457 143 615 457 144 615 minecraft:white_concrete
fill 423 144 609 423 149 609 minecraft:pearlescent_froglight
fill 423 144 617 423 149 617 minecraft:pearlescent_froglight
fill 423 144 625 423 149 625 minecraft:pearlescent_froglight
fill 423 144 633 423 149 633 minecraft:pearlescent_froglight
fill 423 144 641 423 149 641 minecraft:pearlescent_froglight
fill 426 144 646 426 149 646 minecraft:pearlescent_froglight
fill 430 144 604 430 149 604 minecraft:pearlescent_froglight
fill 434 144 646 434 149 646 minecraft:pearlescent_froglight
fill 438 144 604 438 149 604 minecraft:pearlescent_froglight
fill 442 144 646 442 149 646 minecraft:pearlescent_froglight
fill 446 144 604 446 149 604 minecraft:pearlescent_froglight
fill 450 144 646 450 149 646 minecraft:pearlescent_froglight
fill 454 144 604 454 149 604 minecraft:pearlescent_froglight
fill 458 144 646 458 149 646 minecraft:pearlescent_froglight
fill 462 144 604 462 149 604 minecraft:pearlescent_froglight
fill 465 144 609 465 149 609 minecraft:pearlescent_froglight
fill 465 144 617 465 149 617 minecraft:pearlescent_froglight
fill 465 144 625 465 149 625 minecraft:pearlescent_froglight
fill 465 144 633 465 149 633 minecraft:pearlescent_froglight
fill 465 144 641 465 149 641 minecraft:pearlescent_froglight
fill 456 145 612 456 146 613 minecraft:black_concrete
setblock 426 146 607 minecraft:light[level=13]
setblock 426 146 615 minecraft:light[level=13]
setblock 426 146 623 minecraft:light[level=13]
setblock 426 146 631 minecraft:light[level=13]
setblock 426 146 639 minecraft:light[level=13]
setblock 434 146 607 minecraft:light[level=13]
setblock 434 146 615 minecraft:light[level=13]
setblock 434 146 623 minecraft:light[level=13]
setblock 434 146 631 minecraft:light[level=13]
setblock 434 146 639 minecraft:light[level=13]
setblock 442 146 607 minecraft:light[level=13]
setblock 442 146 615 minecraft:light[level=13]
setblock 442 146 623 minecraft:light[level=13]
setblock 442 146 631 minecraft:light[level=13]
setblock 442 146 639 minecraft:light[level=13]
setblock 450 146 607 minecraft:light[level=13]
setblock 450 146 615 minecraft:light[level=13]
setblock 450 146 623 minecraft:light[level=13]
setblock 450 146 631 minecraft:light[level=13]
setblock 450 146 639 minecraft:light[level=13]
setblock 458 146 607 minecraft:light[level=13]
setblock 458 146 615 minecraft:light[level=13]
setblock 458 146 623 minecraft:light[level=13]
setblock 458 146 631 minecraft:light[level=13]
setblock 458 146 639 minecraft:light[level=13]
fill 427 149 631 427 150 632 minecraft:white_concrete
fill 437 149 609 437 150 610 minecraft:white_concrete
fill 423 150 609 423 161 609 minecraft:gray_concrete
fill 423 150 617 423 161 617 minecraft:gray_concrete
fill 423 150 625 423 161 625 minecraft:gray_concrete
fill 423 150 633 423 161 633 minecraft:gray_concrete
fill 423 150 641 423 161 641 minecraft:gray_concrete
fill 426 150 646 426 161 646 minecraft:gray_concrete
fill 430 150 604 430 161 604 minecraft:gray_concrete
fill 434 150 646 434 161 646 minecraft:gray_concrete
fill 438 150 604 438 161 604 minecraft:gray_concrete
fill 442 150 646 442 161 646 minecraft:gray_concrete
fill 446 150 604 446 161 604 minecraft:gray_concrete
fill 450 150 646 450 161 646 minecraft:gray_concrete
fill 454 150 604 454 161 604 minecraft:gray_concrete
fill 458 150 646 458 161 646 minecraft:gray_concrete
fill 462 150 604 462 161 604 minecraft:gray_concrete
fill 465 150 609 465 161 609 minecraft:gray_concrete
fill 465 150 617 465 161 617 minecraft:gray_concrete
fill 465 150 625 465 161 625 minecraft:gray_concrete
fill 465 150 633 465 161 633 minecraft:gray_concrete
fill 465 150 641 465 161 641 minecraft:gray_concrete
setblock 426 154 607 minecraft:light[level=13]
setblock 426 154 615 minecraft:light[level=13]
setblock 426 154 623 minecraft:light[level=13]
setblock 426 154 631 minecraft:light[level=13]
setblock 426 154 639 minecraft:light[level=13]
setblock 434 154 607 minecraft:light[level=13]
setblock 434 154 615 minecraft:light[level=13]
setblock 434 154 623 minecraft:light[level=13]
setblock 434 154 631 minecraft:light[level=13]
setblock 434 154 639 minecraft:light[level=13]
setblock 442 154 607 minecraft:light[level=13]
setblock 442 154 615 minecraft:light[level=13]
setblock 442 154 623 minecraft:light[level=13]
setblock 442 154 631 minecraft:light[level=13]
setblock 442 154 639 minecraft:light[level=13]
setblock 450 154 607 minecraft:light[level=13]
setblock 450 154 615 minecraft:light[level=13]
setblock 450 154 623 minecraft:light[level=13]
setblock 450 154 631 minecraft:light[level=13]
setblock 450 154 639 minecraft:light[level=13]
setblock 458 154 607 minecraft:light[level=13]
setblock 458 154 615 minecraft:light[level=13]
setblock 458 154 623 minecraft:light[level=13]
setblock 458 154 631 minecraft:light[level=13]
setblock 458 154 639 minecraft:light[level=13]
fill 434 156 624 436 156 626 minecraft:redstone_block
fill 435 156 631 437 156 633 minecraft:redstone_block
fill 441 156 623 443 156 625 minecraft:redstone_block
fill 441 156 631 443 156 633 minecraft:redstone_block
fill 425 157 628 426 158 628 minecraft:gold_block
fill 426 157 623 426 158 627 minecraft:gold_block
fill 426 157 629 426 158 633 minecraft:gold_block
fill 427 157 621 427 158 623 minecraft:gold_block
fill 427 157 624 433 157 632 minecraft:black_concrete
fill 427 157 633 427 158 635 minecraft:gold_block
fill 428 157 620 428 158 621 minecraft:gold_block
fill 428 157 622 440 157 623 minecraft:black_concrete
fill 428 157 633 434 157 634 minecraft:black_concrete
fill 428 157 635 428 158 636 minecraft:gold_block
fill 429 157 619 429 158 620 minecraft:gold_block
fill 429 157 621 449 158 621 minecraft:black_concrete
fill 429 157 635 449 157 635 minecraft:black_concrete
fill 429 157 636 429 158 637 minecraft:gold_block
fill 430 157 618 430 158 619 minecraft:gold_block
fill 430 157 620 448 158 620 minecraft:black_concrete
fill 430 157 636 448 157 636 minecraft:black_concrete
fill 430 157 637 430 158 638 minecraft:gold_block
fill 431 157 617 431 158 618 minecraft:gold_block
fill 431 157 619 447 158 619 minecraft:black_concrete
fill 431 157 637 447 158 637 minecraft:black_concrete
fill 431 157 638 431 158 639 minecraft:gold_block
fill 432 157 616 432 158 617 minecraft:gold_block
fill 432 157 618 446 157 618 minecraft:black_concrete
fill 432 157 638 446 157 638 minecraft:black_concrete
fill 432 157 639 432 158 640 minecraft:gold_block
fill 433 157 616 434 158 616 minecraft:gold_block
fill 433 157 617 445 157 617 minecraft:black_concrete
fill 433 157 639 445 157 639 minecraft:black_concrete
fill 433 157 640 434 158 640 minecraft:gold_block
fill 434 157 615 444 158 615 minecraft:gold_block
fill 434 157 627 434 157 632 minecraft:black_concrete
fill 434 157 641 444 158 641 minecraft:gold_block
fill 435 157 616 443 157 616 minecraft:black_concrete
fill 435 157 627 437 157 630 minecraft:black_concrete
fill 435 157 634 450 157 634 minecraft:black_concrete
fill 435 157 640 443 157 640 minecraft:black_concrete
fill 437 157 624 440 157 626 minecraft:black_concrete
fill 438 157 630 440 157 633 minecraft:black_concrete
fill 439 157 614 439 158 614 minecraft:gold_block
fill 439 157 642 439 158 642 minecraft:gold_block
fill 441 157 622 450 157 622 minecraft:black_concrete
fill 441 157 626 451 157 630 minecraft:black_concrete
fill 444 157 616 446 158 616 minecraft:gold_block
fill 444 157 623 450 157 625 minecraft:black_concrete
fill 444 157 631 450 157 633 minecraft:black_concrete
fill 444 157 640 446 158 640 minecraft:gold_block
fill 446 157 617 447 158 617 minecraft:gold_block
fill 446 157 639 447 158 639 minecraft:gold_block
fill 447 157 618 448 158 618 minecraft:gold_block
fill 447 157 638 448 158 638 minecraft:gold_block
fill 448 157 619 449 158 619 minecraft:gold_block
fill 448 157 637 449 158 637 minecraft:gold_block
fill 449 157 620 450 158 620 minecraft:gold_block
fill 449 157 636 450 158 636 minecraft:gold_block
fill 450 157 621 451 158 621 minecraft:gold_block
fill 450 157 635 451 158 635 minecraft:gold_block
fill 451 157 622 451 158 623 minecraft:gold_block
fill 451 157 624 451 158 625 minecraft:black_concrete
fill 451 157 631 451 158 632 minecraft:black_concrete
fill 451 157 633 451 158 634 minecraft:gold_block
fill 452 157 623 452 158 633 minecraft:gold_block
fill 453 157 628 453 158 628 minecraft:gold_block
fill 424 158 605 424 158 645 minecraft:black_concrete
fill 425 158 605 425 158 627 minecraft:black_concrete
fill 425 158 629 425 158 645 minecraft:black_concrete
fill 426 158 605 426 158 622 minecraft:black_concrete
fill 426 158 634 426 158 645 minecraft:black_concrete
fill 427 158 605 427 158 620 minecraft:black_concrete
fill 427 158 624 432 158 627 minecraft:black_concrete
fill 427 158 628 428 158 628 minecraft:white_concrete
fill 427 158 629 433 158 632 minecraft:black_concrete
fill 427 158 636 427 158 645 minecraft:black_concrete
fill 428 158 605 428 158 619 minecraft:black_concrete
fill 428 158 622 429 158 622 minecraft:white_concrete
fill 428 158 623 432 158 623 minecraft:black_concrete
fill 428 158 633 433 158 633 minecraft:black_concrete
fill 428 158 634 429 158 634 minecraft:white_concrete
fill 428 158 637 428 158 645 minecraft:black_concrete
fill 429 158 605 429 158 618 minecraft:black_concrete
fill 429 158 628 435 158 628 minecraft:black_concrete
fill 429 158 635 431 158 635 minecraft:black_concrete
fill 429 158 638 429 158 645 minecraft:black_concrete
fill 430 158 605 430 158 617 minecraft:black_concrete
fill 430 158 622 439 158 622 minecraft:black_concrete
fill 430 158 634 432 158 634 minecraft:black_concrete
fill 430 158 636 431 158 636 minecraft:black_concrete
fill 430 158 639 430 158 645 minecraft:black_concrete
fill 431 158 605 431 158 616 minecraft:black_concrete
fill 431 158 640 431 158 645 minecraft:black_concrete
fill 432 158 605 433 158 615 minecraft:black_concrete
setblock 432 158 618 minecraft:black_concrete
fill 432 158 635 432 158 636 minecraft:gold_block
setblock 432 158 638 minecraft:black_concrete
fill 432 158 641 433 158 645 minecraft:black_concrete
fill 433 158 617 433 158 618 minecraft:white_concrete
fill 433 158 623 433 158 627 minecraft:pearlescent_froglight
fill 433 158 634 433 158 635 minecraft:gold_block
fill 433 158 636 448 158 636 minecraft:black_concrete
fill 433 158 638 433 158 639 minecraft:white_concrete
fill 434 158 605 438 158 614 minecraft:black_concrete
fill 434 158 617 438 158 618 minecraft:black_concrete
fill 434 158 623 437 158 623 minecraft:pearlescent_froglight
fill 434 158 624 436 158 626 minecraft:black_concrete
fill 434 158 627 435 158 627 minecraft:pearlescent_froglight
fill 434 158 629 435 158 629 minecraft:black_concrete
fill 434 158 630 434 158 634 minecraft:pearlescent_froglight
fill 434 158 635 449 158 635 minecraft:black_concrete
fill 434 158 638 438 158 639 minecraft:black_concrete
fill 434 158 642 438 158 645 minecraft:black_concrete
fill 435 158 616 438 158 616 minecraft:black_concrete
fill 435 158 630 436 158 630 minecraft:pearlescent_froglight
fill 435 158 631 437 158 633 minecraft:black_concrete
fill 435 158 634 438 158 634 minecraft:pearlescent_froglight
fill 435 158 640 438 158 640 minecraft:black_concrete
fill 436 158 627 436 158 629 minecraft:red_nether_bricks
fill 437 158 624 437 158 625 minecraft:pearlescent_froglight
setblock 437 158 626 minecraft:red_nether_bricks
fill 437 158 627 437 158 629 minecraft:shroomlight
setblock 437 158 630 minecraft:red_nether_bricks
fill 438 158 623 439 158 625 minecraft:black_concrete
fill 438 158 626 440 158 626 minecraft:shroomlight
fill 438 158 630 440 158 630 minecraft:shroomlight
fill 438 158 631 438 158 633 minecraft:pearlescent_froglight
fill 439 158 605 464 158 613 minecraft:black_concrete
fill 439 158 616 439 158 617 minecraft:white_concrete
fill 439 158 618 444 158 618 minecraft:black_concrete
fill 439 158 631 439 158 634 minecraft:black_concrete
fill 439 158 638 444 158 638 minecraft:black_concrete
fill 439 158 639 439 158 640 minecraft:white_concrete
fill 439 158 643 464 158 645 minecraft:black_concrete
fill 440 158 614 464 158 614 minecraft:black_concrete
fill 440 158 616 443 158 617 minecraft:black_concrete
fill 440 158 622 440 158 625 minecraft:pearlescent_froglight
fill 440 158 631 440 158 634 minecraft:pearlescent_froglight
fill 440 158 639 443 158 640 minecraft:black_concrete
fill 440 158 642 464 158 642 minecraft:black_concrete
fill 441 158 622 444 158 622 minecraft:pearlescent_froglight
fill 441 158 623 443 158 625 minecraft:black_concrete
setblock 441 158 626 minecraft:red_nether_bricks
fill 441 158 627 441 158 629 minecraft:shroomlight
setblock 441 158 630 minecraft:red_nether_bricks
fill 441 158 631 443 158 633 minecraft:black_concrete
fill 441 158 634 444 158 634 minecraft:pearlescent_froglight
fill 442 158 626 444 158 626 minecraft:pearlescent_froglight
fill 442 158 627 442 158 629 minecraft:red_nether_bricks
fill 442 158 630 444 158 630 minecraft:pearlescent_froglight
fill 443 158 627 449 158 629 minecraft:black_concrete
setblock 444 158 617 minecraft:black_concrete
fill 444 158 623 444 158 625 minecraft:pearlescent_froglight
fill 444 158 631 444 158 633 minecraft:pearlescent_froglight
setblock 444 158 639 minecraft:black_concrete
fill 445 158 615 464 158 615 minecraft:black_concrete
fill 445 158 617 445 158 618 minecraft:white_concrete
fill 445 158 622 448 158 626 minecraft:black_concrete
fill 445 158 630 450 158 632 minecraft:black_concrete
setblock 445 158 633 minecraft:gold_block
fill 445 158 634 448 158 634 minecraft:black_concrete
fill 445 158 638 445 158 639 minecraft:white_concrete
fill 445 158 641 464 158 641 minecraft:black_concrete
setblock 446 158 618 minecraft:black_concrete
fill 446 158 633 450 158 633 minecraft:black_concrete
setblock 446 158 638 minecraft:black_concrete
fill 447 158 616 464 158 616 minecraft:black_concrete
fill 447 158 640 464 158 640 minecraft:black_concrete
fill 448 158 617 464 158 617 minecraft:black_concrete
fill 448 158 639 464 158 639 minecraft:black_concrete
fill 449 158 618 464 158 618 minecraft:black_concrete
fill 449 158 622 450 158 622 minecraft:white_concrete
fill 449 158 623 450 158 626 minecraft:black_concrete
fill 449 158 634 450 158 634 minecraft:white_concrete
fill 449 158 638 464 158 638 minecraft:black_concrete
fill 450 158 619 464 158 619 minecraft:black_concrete
fill 450 158 627 451 158 627 minecraft:black_concrete
fill 450 158 628 451 158 628 minecraft:white_concrete
fill 450 158 629 451 158 629 minecraft:black_concrete
fill 450 158 637 464 158 637 minecraft:black_concrete
fill 451 158 620 464 158 620 minecraft:black_concrete
setblock 451 158 626 minecraft:black_concrete
setblock 451 158 630 minecraft:black_concrete
fill 451 158 636 464 158 636 minecraft:black_concrete
fill 452 158 621 464 158 622 minecraft:black_concrete
fill 452 158 634 464 158 635 minecraft:black_concrete
fill 453 158 623 464 158 627 minecraft:black_concrete
fill 453 158 629 464 158 633 minecraft:black_concrete
fill 454 158 628 464 158 628 minecraft:black_concrete
fill 433 159 628 435 159 628 minecraft:red_nether_bricks
fill 434 159 626 436 159 627 minecraft:red_nether_bricks
fill 434 159 629 436 159 630 minecraft:red_nether_bricks
fill 435 159 625 438 159 625 minecraft:red_nether_bricks
fill 435 159 631 438 159 631 minecraft:red_nether_bricks
fill 436 159 624 442 159 624 minecraft:red_nether_bricks
fill 436 159 628 437 159 628 minecraft:quartz_block
fill 436 159 632 442 159 632 minecraft:red_nether_bricks
fill 437 159 626 437 160 627 minecraft:quartz_block
fill 437 159 629 437 160 630 minecraft:quartz_block
fill 438 159 626 441 159 626 minecraft:quartz_block
fill 438 159 630 441 159 630 minecraft:quartz_block
fill 439 159 625 439 160 625 minecraft:quartz_block
fill 439 159 631 439 160 631 minecraft:quartz_block
fill 440 159 625 443 159 625 minecraft:red_nether_bricks
fill 440 159 631 443 159 631 minecraft:red_nether_bricks
fill 441 159 627 441 159 629 minecraft:quartz_block
fill 442 159 626 444 159 627 minecraft:red_nether_bricks
fill 442 159 628 442 160 628 minecraft:quartz_block
fill 442 159 629 444 159 630 minecraft:red_nether_bricks
fill 443 159 628 445 159 628 minecraft:red_nether_bricks
fill 432 160 626 434 168 630 minecraft:red_nether_bricks
fill 433 160 625 436 166 625 minecraft:red_nether_bricks
fill 433 160 631 436 166 631 minecraft:red_nether_bricks
fill 434 160 624 438 165 624 minecraft:red_nether_bricks
fill 434 160 632 438 165 632 minecraft:red_nether_bricks
fill 435 160 623 443 167 623 minecraft:red_nether_bricks
fill 435 160 626 435 165 627 minecraft:red_nether_bricks
fill 435 160 628 436 160 628 minecraft:quartz_block
fill 435 160 629 435 165 630 minecraft:red_nether_bricks
fill 435 160 633 443 167 633 minecraft:red_nether_bricks
fill 436 160 626 436 160 627 minecraft:quartz_block
fill 436 160 629 436 160 630 minecraft:quartz_block
fill 437 160 625 438 160 625 minecraft:quartz_block
fill 437 160 631 438 160 631 minecraft:quartz_block
fill 438 160 622 440 169 622 minecraft:red_nether_bricks
setblock 438 160 626 minecraft:quartz_block
setblock 438 160 630 minecraft:quartz_block
fill 438 160 634 440 169 634 minecraft:red_nether_bricks
setblock 439 160 624 minecraft:quartz_block
setblock 439 160 632 minecraft:quartz_block
fill 440 160 624 444 165 624 minecraft:red_nether_bricks
fill 440 160 625 441 160 626 minecraft:quartz_block
fill 440 160 630 441 160 631 minecraft:quartz_block
fill 440 160 632 444 165 632 minecraft:red_nether_bricks
fill 441 160 627 442 160 627 minecraft:quartz_block
fill 441 160 629 442 160 629 minecraft:quartz_block
fill 442 160 625 445 160 625 minecraft:red_nether_bricks
setblock 442 160 626 minecraft:quartz_block
setblock 442 160 630 minecraft:quartz_block
fill 442 160 631 445 160 631 minecraft:red_nether_bricks
fill 443 160 626 443 160 627 minecraft:red_nether_bricks
setblock 443 160 628 minecraft:quartz_block
fill 443 160 629 443 160 630 minecraft:red_nether_bricks
setblock 444 160 626 minecraft:red_nether_bricks
fill 444 160 627 450 166 629 minecraft:nether_bricks
setblock 444 160 630 minecraft:red_nether_bricks
fill 445 160 626 449 166 626 minecraft:nether_bricks
fill 445 160 630 449 166 630 minecraft:nether_bricks
fill 431 161 626 431 168 630 minecraft:red_nether_bricks
fill 432 161 625 432 169 625 minecraft:red_nether_bricks
fill 432 161 631 432 169 631 minecraft:red_nether_bricks
fill 433 161 624 433 169 624 minecraft:red_nether_bricks
fill 433 161 632 433 169 632 minecraft:red_nether_bricks
fill 434 161 623 434 169 623 minecraft:red_nether_bricks
fill 434 161 633 434 169 633 minecraft:red_nether_bricks
fill 435 161 622 437 168 622 minecraft:red_nether_bricks
fill 435 161 628 436 162 628 minecraft:red_nether_bricks
fill 435 161 634 437 168 634 minecraft:red_nether_bricks
fill 436 161 626 436 162 627 minecraft:red_nether_bricks
fill 436 161 629 436 162 630 minecraft:red_nether_bricks
fill 437 161 625 437 161 626 minecraft:red_nether_bricks
fill 437 161 630 437 161 631 minecraft:red_nether_bricks
fill 438 161 625 443 161 625 minecraft:red_nether_bricks
fill 438 161 631 443 161 631 minecraft:red_nether_bricks
fill 439 161 624 439 165 624 minecraft:red_nether_bricks
fill 439 161 632 439 165 632 minecraft:red_nether_bricks
fill 441 161 622 443 168 622 minecraft:red_nether_bricks
fill 441 161 626 442 161 626 minecraft:red_nether_bricks
fill 441 161 630 442 161 630 minecraft:red_nether_bricks
fill 441 161 634 443 168 634 minecraft:red_nether_bricks
setblock 442 161 627 minecraft:red_nether_bricks
fill 442 161 628 443 162 628 minecraft:nether_bricks
setblock 442 161 629 minecraft:red_nether_bricks
fill 443 161 626 443 165 627 minecraft:nether_bricks
fill 443 161 629 443 165 630 minecraft:nether_bricks
fill 444 161 623 444 169 623 minecraft:red_nether_bricks
fill 444 161 625 444 165 626 minecraft:nether_bricks
fill 444 161 630 444 165 631 minecraft:nether_bricks
fill 444 161 633 444 169 633 minecraft:red_nether_bricks
setblock 445 161 624 minecraft:red_nether_bricks
fill 445 161 625 450 165 625 minecraft:nether_bricks
fill 445 161 631 450 165 631 minecraft:nether_bricks
setblock 445 161 632 minecraft:red_nether_bricks
fill 450 161 626 451 163 626 minecraft:nether_bricks
fill 450 161 630 451 163 630 minecraft:nether_bricks
fill 451 161 627 451 165 629 minecraft:nether_bricks
fill 452 161 628 452 165 628 minecraft:nether_bricks
fill 423 162 609 423 163 609 minecraft:pearlescent_froglight
fill 423 162 617 423 163 617 minecraft:pearlescent_froglight
fill 423 162 625 423 163 625 minecraft:pearlescent_froglight
fill 423 162 633 423 163 633 minecraft:pearlescent_froglight
fill 423 162 641 423 163 641 minecraft:pearlescent_froglight
fill 424 162 611 424 199 612 minecraft:quartz_block
fill 424 162 619 424 199 620 minecraft:quartz_block
fill 424 162 627 424 199 628 minecraft:quartz_block
fill 424 162 635 424 199 636 minecraft:quartz_block
fill 424 162 643 424 199 644 minecraft:quartz_block
fill 425 162 605 426 199 605 minecraft:quartz_block
setblock 426 162 607 minecraft:light[level=13]
setblock 426 162 615 minecraft:light[level=13]
setblock 426 162 623 minecraft:light[level=13]
setblock 426 162 631 minecraft:light[level=13]
setblock 426 162 639 minecraft:light[level=13]
fill 426 162 646 426 163 646 minecraft:pearlescent_froglight
fill 430 162 604 430 163 604 minecraft:pearlescent_froglight
fill 430 162 627 430 167 629 minecraft:red_nether_bricks
fill 430 162 645 431 199 645 minecraft:quartz_block
fill 431 162 625 431 168 625 minecraft:red_nether_bricks
fill 431 162 631 431 168 631 minecraft:red_nether_bricks
fill 432 162 624 432 168 624 minecraft:red_nether_bricks
fill 432 162 632 432 168 632 minecraft:red_nether_bricks
fill 433 162 605 434 199 605 minecraft:quartz_block
fill 433 162 623 433 168 623 minecraft:red_nether_bricks
fill 433 162 633 433 168 633 minecraft:red_nether_bricks
setblock 434 162 607 minecraft:light[level=13]
setblock 434 162 615 minecraft:light[level=13]
fill 434 162 622 434 167 622 minecraft:red_nether_bricks
fill 434 162 634 434 167 634 minecraft:red_nether_bricks
setblock 434 162 639 minecraft:light[level=13]
fill 434 162 646 434 163 646 minecraft:pearlescent_froglight
fill 436 162 621 442 166 621 minecraft:red_nether_bricks
fill 436 162 635 442 166 635 minecraft:red_nether_bricks
fill 437 162 625 442 162 625 minecraft:red_nether_bricks
fill 437 162 631 442 162 631 minecraft:red_nether_bricks
fill 438 162 604 438 163 604 minecraft:pearlescent_froglight
fill 438 162 645 439 199 645 minecraft:quartz_block
fill 441 162 605 442 199 605 minecraft:quartz_block
setblock 442 162 607 minecraft:light[level=13]
setblock 442 162 615 minecraft:light[level=13]
fill 442 162 626 442 162 627 minecraft:nether_bricks
fill 442 162 629 442 162 630 minecraft:nether_bricks
setblock 442 162 639 minecraft:light[level=13]
fill 442 162 646 442 163 646 minecraft:pearlescent_froglight
fill 443 162 625 443 164 625 minecraft:nether_bricks
fill 443 162 631 443 164 631 minecraft:nether_bricks
fill 444 162 622 444 167 622 minecraft:red_nether_bricks
fill 444 162 634 444 167 634 minecraft:red_nether_bricks
fill 445 162 623 445 168 623 minecraft:red_nether_bricks
fill 445 162 624 449 164 624 minecraft:nether_bricks
fill 445 162 632 449 164 632 minecraft:nether_bricks
fill 445 162 633 445 168 633 minecraft:red_nether_bricks
fill 446 162 604 446 163 604 minecraft:pearlescent_froglight
fill 446 162 645 447 199 645 minecraft:quartz_block
fill 449 162 605 450 199 605 minecraft:quartz_block
setblock 450 162 607 minecraft:light[level=13]
setblock 450 162 615 minecraft:light[level=13]
setblock 450 162 623 minecraft:light[level=13]
setblock 450 162 639 minecraft:light[level=13]
fill 450 162 646 450 163 646 minecraft:pearlescent_froglight
fill 451 162 625 451 164 625 minecraft:nether_bricks
fill 451 162 631 451 164 631 minecraft:nether_bricks
fill 452 162 626 452 164 627 minecraft:nether_bricks
fill 452 162 629 452 164 630 minecraft:nether_bricks
fill 454 162 604 454 163 604 minecraft:pearlescent_froglight
fill 454 162 645 455 199 645 minecraft:quartz_block
fill 457 162 605 458 199 605 minecraft:quartz_block
setblock 458 162 607 minecraft:light[level=13]
setblock 458 162 615 minecraft:light[level=13]
setblock 458 162 623 minecraft:light[level=13]
setblock 458 162 631 minecraft:light[level=13]
setblock 458 162 639 minecraft:light[level=13]
fill 458 162 646 458 163 646 minecraft:pearlescent_froglight
fill 462 162 604 462 163 604 minecraft:pearlescent_froglight
fill 462 162 645 463 199 645 minecraft:quartz_block
fill 464 162 606 464 199 607 minecraft:quartz_block
fill 464 162 614 464 199 615 minecraft:quartz_block
fill 464 162 622 464 199 623 minecraft:quartz_block
fill 464 162 630 464 199 631 minecraft:quartz_block
fill 464 162 638 464 199 639 minecraft:quartz_block
fill 465 162 609 465 163 609 minecraft:pearlescent_froglight
fill 465 162 617 465 163 617 minecraft:pearlescent_froglight
fill 465 162 625 465 163 625 minecraft:pearlescent_froglight
fill 465 162 633 465 163 633 minecraft:pearlescent_froglight
fill 465 162 641 465 163 641 minecraft:pearlescent_froglight
fill 430 163 626 430 167 626 minecraft:red_nether_bricks
fill 430 163 630 430 167 630 minecraft:red_nether_bricks
fill 431 163 624 431 167 624 minecraft:red_nether_bricks
fill 431 163 632 431 167 632 minecraft:red_nether_bricks
fill 432 163 623 432 167 623 minecraft:red_nether_bricks
fill 432 163 633 432 167 633 minecraft:red_nether_bricks
fill 433 163 622 433 166 622 minecraft:red_nether_bricks
fill 433 163 634 433 166 634 minecraft:red_nether_bricks
fill 435 163 621 435 166 621 minecraft:red_nether_bricks
fill 435 163 628 435 165 628 minecraft:red_nether_bricks
fill 435 163 635 435 166 635 minecraft:red_nether_bricks
fill 436 163 626 436 164 626 minecraft:red_nether_bricks
fill 436 163 630 436 164 630 minecraft:red_nether_bricks
fill 437 163 625 437 164 625 minecraft:red_nether_bricks
fill 437 163 631 437 164 631 minecraft:red_nether_bricks
fill 441 163 625 442 164 625 minecraft:red_nether_bricks
fill 441 163 631 442 164 631 minecraft:red_nether_bricks
fill 442 163 626 442 164 626 minecraft:nether_bricks
fill 442 163 630 442 164 630 minecraft:nether_bricks
fill 443 163 621 443 166 621 minecraft:red_nether_bricks
fill 443 163 628 443 165 628 minecraft:nether_bricks
fill 443 163 635 443 166 635 minecraft:red_nether_bricks
fill 445 163 622 445 166 622 minecraft:red_nether_bricks
fill 445 163 634 445 166 634 minecraft:red_nether_bricks
fill 446 163 623 446 167 623 minecraft:red_nether_bricks
fill 446 163 633 446 167 633 minecraft:red_nether_bricks
fill 423 164 609 423 171 609 minecraft:gray_concrete
fill 423 164 617 423 171 617 minecraft:gray_concrete
fill 423 164 625 423 171 625 minecraft:gray_concrete
fill 423 164 633 423 171 633 minecraft:gray_concrete
fill 423 164 641 423 171 641 minecraft:gray_concrete
fill 426 164 646 426 171 646 minecraft:gray_concrete
fill 430 164 604 430 171 604 minecraft:gray_concrete
fill 430 164 625 430 166 625 minecraft:red_nether_bricks
fill 430 164 631 430 166 631 minecraft:red_nether_bricks
fill 434 164 646 434 171 646 minecraft:gray_concrete
fill 438 164 604 438 171 604 minecraft:gray_concrete
fill 442 164 646 442 171 646 minecraft:gray_concrete
fill 446 164 604 446 171 604 minecraft:gray_concrete
fill 450 164 626 450 166 626 minecraft:nether_bricks
fill 450 164 630 450 166 630 minecraft:nether_bricks
fill 450 164 646 450 171 646 minecraft:gray_concrete
fill 451 164 626 451 165 626 minecraft:black_concrete
fill 451 164 630 451 165 630 minecraft:black_concrete
fill 454 164 604 454 171 604 minecraft:gray_concrete
fill 458 164 646 458 171 646 minecraft:gray_concrete
fill 462 164 604 462 171 604 minecraft:gray_concrete
fill 465 164 609 465 171 609 minecraft:gray_concrete
fill 465 164 617 465 171 617 minecraft:gray_concrete
fill 465 164 625 465 171 625 minecraft:gray_concrete
fill 465 164 633 465 171 633 minecraft:gray_concrete
fill 465 164 641 465 171 641 minecraft:gray_concrete
fill 442 165 625 443 166 625 minecraft:red_nether_bricks
fill 442 165 631 443 166 631 minecraft:red_nether_bricks
fill 445 165 624 447 167 624 minecraft:red_nether_bricks
fill 445 165 632 447 167 632 minecraft:red_nether_bricks
setblock 452 165 627 minecraft:nether_bricks
setblock 452 165 629 minecraft:nether_bricks
fill 434 166 624 437 167 624 minecraft:red_nether_bricks
fill 434 166 632 437 167 632 minecraft:red_nether_bricks
fill 435 166 626 435 167 626 minecraft:red_nether_bricks
fill 435 166 630 435 167 630 minecraft:red_nether_bricks
fill 441 166 624 444 167 624 minecraft:red_nether_bricks
fill 441 166 632 444 167 632 minecraft:red_nether_bricks
fill 443 166 626 443 167 626 minecraft:red_nether_bricks
fill 443 166 630 443 167 630 minecraft:red_nether_bricks
fill 444 166 625 445 169 625 minecraft:red_nether_bricks
setblock 444 166 626 minecraft:nether_bricks
setblock 444 166 630 minecraft:nether_bricks
fill 444 166 631 445 169 631 minecraft:red_nether_bricks
fill 446 166 625 448 166 625 minecraft:nether_bricks
fill 446 166 631 448 166 631 minecraft:nether_bricks
setblock 451 166 628 minecraft:nether_bricks
fill 433 167 625 435 168 625 minecraft:red_nether_bricks
fill 433 167 631 435 168 631 minecraft:red_nether_bricks
setblock 436 167 621 minecraft:red_nether_bricks
setblock 436 167 635 minecraft:red_nether_bricks
setblock 437 167 621 minecraft:black_concrete
setblock 437 167 635 minecraft:black_concrete
fill 438 167 621 442 167 621 minecraft:red_nether_bricks
fill 438 167 635 442 167 635 minecraft:red_nether_bricks
fill 443 167 625 443 168 625 minecraft:red_nether_bricks
fill 443 167 631 443 168 631 minecraft:red_nether_bricks
fill 444 167 626 445 168 630 minecraft:red_nether_bricks
fill 446 167 625 447 168 627 minecraft:red_nether_bricks
fill 446 167 628 448 167 628 minecraft:nether_bricks
fill 446 167 629 447 168 631 minecraft:red_nether_bricks
fill 448 167 626 448 167 627 minecraft:red_nether_bricks
fill 448 167 629 448 167 630 minecraft:red_nether_bricks
fill 424 168 605 424 169 610 minecraft:quartz_block
fill 424 168 613 425 168 618 minecraft:quartz_block
fill 424 168 621 425 168 626 minecraft:quartz_block
fill 424 168 629 425 168 634 minecraft:quartz_block
fill 424 168 637 425 168 642 minecraft:quartz_block
fill 424 168 645 429 169 645 minecraft:quartz_block
fill 425 168 606 425 168 612 minecraft:quartz_block
fill 425 168 619 425 168 620 minecraft:quartz_block
fill 425 168 627 425 168 628 minecraft:quartz_block
fill 425 168 635 425 168 636 minecraft:quartz_block
fill 425 168 643 425 168 644 minecraft:quartz_block
fill 426 168 606 463 168 606 minecraft:quartz_block
fill 426 168 644 464 168 644 minecraft:quartz_block
fill 427 168 605 432 169 605 minecraft:quartz_block
fill 432 168 645 437 169 645 minecraft:quartz_block
fill 434 168 620 437 168 620 minecraft:black_concrete
fill 434 168 624 436 168 624 minecraft:red_nether_bricks
fill 434 168 632 436 168 632 minecraft:red_nether_bricks
fill 434 168 636 437 168 636 minecraft:black_concrete
fill 435 168 605 440 169 605 minecraft:quartz_block
fill 435 168 623 441 168 623 minecraft:red_nether_bricks
fill 435 168 633 441 168 633 minecraft:red_nether_bricks
fill 438 168 621 440 168 621 minecraft:red_nether_bricks
fill 438 168 635 440 168 635 minecraft:red_nether_bricks
fill 440 168 645 445 169 645 minecraft:quartz_block
fill 442 168 623 442 168 624 minecraft:shroomlight
fill 442 168 632 442 168 633 minecraft:shroomlight
fill 443 168 605 448 169 605 minecraft:quartz_block
fill 443 168 623 443 168 624 minecraft:red_nether_bricks
fill 443 168 632 443 168 633 minecraft:red_nether_bricks
fill 444 168 624 446 168 624 minecraft:red_nether_bricks
fill 444 168 632 446 168 632 minecraft:red_nether_bricks
fill 446 168 628 447 169 628 minecraft:red_nether_bricks
fill 448 168 645 453 169 645 minecraft:quartz_block
fill 451 168 605 456 169 605 minecraft:quartz_block
fill 456 168 645 461 169 645 minecraft:quartz_block
fill 459 168 605 464 169 605 minecraft:quartz_block
fill 461 168 624 462 169 624 minecraft:white_concrete
fill 462 168 623 462 169 623 minecraft:white_concrete
fill 462 168 625 462 169 625 minecraft:white_concrete
fill 463 168 607 463 168 643 minecraft:quartz_block
fill 464 168 608 464 169 613 minecraft:quartz_block
fill 464 168 616 464 169 621 minecraft:quartz_block
fill 464 168 624 464 169 629 minecraft:quartz_block
fill 464 168 632 464 169 637 minecraft:quartz_block
fill 464 168 640 464 169 643 minecraft:quartz_block
fill 464 168 645 464 169 645 minecraft:quartz_block
fill 424 169 613 424 169 618 minecraft:quartz_block
fill 424 169 621 424 169 626 minecraft:quartz_block
fill 424 169 629 424 169 634 minecraft:quartz_block
fill 424 169 637 424 169 642 minecraft:quartz_block
fill 431 169 618 433 169 618 minecraft:black_concrete
fill 431 169 628 433 169 628 minecraft:red_nether_bricks
fill 431 169 638 433 169 638 minecraft:black_concrete
fill 432 169 619 436 169 619 minecraft:black_concrete
fill 432 169 626 434 169 627 minecraft:red_nether_bricks
fill 432 169 629 434 169 630 minecraft:red_nether_bricks
fill 432 169 637 436 169 637 minecraft:black_concrete
fill 433 169 625 434 169 625 minecraft:red_nether_bricks
fill 433 169 631 434 169 631 minecraft:red_nether_bricks
fill 434 169 624 435 169 624 minecraft:red_nether_bricks
fill 434 169 632 435 169 632 minecraft:red_nether_bricks
fill 435 169 623 438 169 623 minecraft:red_nether_bricks
fill 435 169 633 438 169 633 minecraft:red_nether_bricks
setblock 437 169 620 minecraft:black_concrete
setblock 437 169 622 minecraft:red_nether_bricks
setblock 437 169 634 minecraft:red_nether_bricks
setblock 437 169 636 minecraft:black_concrete
setblock 440 169 623 minecraft:red_nether_bricks
setblock 440 169 633 minecraft:red_nether_bricks
setblock 441 169 622 minecraft:red_nether_bricks
fill 441 169 623 443 169 623 minecraft:shroomlight
fill 441 169 633 443 169 633 minecraft:shroomlight
setblock 441 169 634 minecraft:red_nether_bricks
setblock 443 169 624 minecraft:shroomlight
setblock 443 169 632 minecraft:shroomlight
fill 444 169 624 445 169 624 minecraft:red_nether_bricks
fill 444 169 626 446 169 627 minecraft:red_nether_bricks
fill 444 169 629 446 169 630 minecraft:red_nether_bricks
fill 444 169 632 445 169 632 minecraft:red_nether_bricks
fill 445 169 628 445 170 628 minecraft:red_nether_bricks
setblock 446 169 625 minecraft:red_nether_bricks
setblock 446 169 631 minecraft:red_nether_bricks
fill 457 169 623 459 170 623 minecraft:black_concrete
fill 458 169 624 459 170 624 minecraft:black_concrete
setblock 463 169 624 minecraft:white_concrete
setblock 464 169 644 minecraft:quartz_block
setblock 426 170 607 minecraft:light[level=13]
setblock 426 170 615 minecraft:light[level=13]
setblock 426 170 623 minecraft:light[level=13]
setblock 426 170 631 minecraft:light[level=13]
setblock 426 170 639 minecraft:light[level=13]
setblock 429 170 617 minecraft:black_concrete
setblock 429 170 639 minecraft:black_concrete
setblock 432 170 617 minecraft:black_concrete
setblock 432 170 639 minecraft:black_concrete
fill 433 170 618 434 170 618 minecraft:black_concrete
fill 433 170 626 433 170 630 minecraft:red_nether_bricks
fill 433 170 638 434 170 638 minecraft:black_concrete
setblock 434 170 607 minecraft:light[level=13]
setblock 434 170 615 minecraft:light[level=13]
setblock 434 170 623 minecraft:light[level=13]
fill 434 170 625 434 170 626 minecraft:red_nether_bricks
fill 434 170 630 434 170 631 minecraft:red_nether_bricks
setblock 434 170 639 minecraft:light[level=13]
fill 435 170 624 435 171 624 minecraft:blackstone
fill 435 170 632 435 171 632 minecraft:blackstone
setblock 436 170 618 minecraft:black_concrete
fill 436 170 623 436 171 623 minecraft:blackstone
fill 436 170 633 436 171 633 minecraft:blackstone
setblock 436 170 638 minecraft:black_concrete
setblock 437 170 619 minecraft:black_concrete
setblock 437 170 623 minecraft:red_nether_bricks
setblock 437 170 633 minecraft:red_nether_bricks
setblock 437 170 637 minecraft:black_concrete
setblock 441 170 623 minecraft:red_nether_bricks
setblock 441 170 633 minecraft:red_nether_bricks
setblock 442 170 607 minecraft:light[level=13]
setblock 442 170 615 minecraft:light[level=13]
setblock 442 170 623 minecraft:light[level=13]
setblock 442 170 639 minecraft:light[level=13]
setblock 443 170 624 minecraft:red_nether_bricks
setblock 443 170 632 minecraft:red_nether_bricks
fill 444 170 625 444 170 626 minecraft:red_nether_bricks
fill 444 170 630 444 170 631 minecraft:red_nether_bricks
fill 445 170 626 445 170 627 minecraft:red_nether_bricks
fill 445 170 629 445 170 630 minecraft:red_nether_bricks
setblock 450 170 607 minecraft:light[level=13]
setblock 450 170 615 minecraft:light[level=13]
setblock 450 170 623 minecraft:light[level=13]
setblock 450 170 631 minecraft:light[level=13]
setblock 450 170 639 minecraft:light[level=13]
setblock 458 170 607 minecraft:light[level=13]
setblock 458 170 615 minecraft:light[level=13]
setblock 458 170 631 minecraft:light[level=13]
setblock 458 170 639 minecraft:light[level=13]
fill 425 171 615 426 171 615 minecraft:black_concrete
fill 425 171 641 426 171 641 minecraft:black_concrete
fill 426 171 616 427 171 616 minecraft:black_concrete
fill 426 171 640 427 171 640 minecraft:black_concrete
fill 430 171 616 431 171 616 minecraft:black_concrete
fill 430 171 640 431 171 640 minecraft:black_concrete
setblock 433 171 617 minecraft:black_concrete
setblock 433 171 639 minecraft:black_concrete
fill 435 171 617 435 172 617 minecraft:black_concrete
fill 435 171 623 435 173 623 minecraft:blackstone
fill 435 171 633 435 173 633 minecraft:blackstone
fill 435 171 639 435 172 639 minecraft:black_concrete
fill 437 171 618 437 172 618 minecraft:black_concrete
fill 437 171 638 437 172 638 minecraft:black_concrete
fill 423 172 609 423 177 609 minecraft:pearlescent_froglight
fill 423 172 617 423 177 617 minecraft:pearlescent_froglight
fill 423 172 625 423 177 625 minecraft:pearlescent_froglight
fill 423 172 633 423 177 633 minecraft:pearlescent_froglight
fill 423 172 641 423 177 641 minecraft:pearlescent_froglight
setblock 425 172 615 minecraft:black_concrete
setblock 425 172 641 minecraft:black_concrete
fill 426 172 646 426 177 646 minecraft:pearlescent_froglight
fill 428 172 614 428 173 614 minecraft:black_concrete
fill 428 172 642 428 173 642 minecraft:black_concrete
setblock 429 172 615 minecraft:black_concrete
setblock 429 172 641 minecraft:black_concrete
fill 430 172 604 430 177 604 minecraft:pearlescent_froglight
fill 432 172 616 432 173 616 minecraft:black_concrete
fill 432 172 640 432 173 640 minecraft:black_concrete
fill 434 172 622 434 174 623 minecraft:blackstone
fill 434 172 633 434 174 634 minecraft:blackstone
fill 434 172 646 434 177 646 minecraft:pearlescent_froglight
fill 435 172 616 435 173 616 minecraft:black_concrete
fill 435 172 622 435 173 622 minecraft:blackstone
fill 435 172 634 435 173 634 minecraft:blackstone
fill 435 172 640 435 173 640 minecraft:black_concrete
fill 437 172 617 437 173 617 minecraft:black_concrete
fill 437 172 639 437 173 639 minecraft:black_concrete
fill 438 172 604 438 177 604 minecraft:pearlescent_froglight
fill 442 172 646 442 177 646 minecraft:pearlescent_froglight
fill 446 172 604 446 177 604 minecraft:pearlescent_froglight
fill 450 172 646 450 177 646 minecraft:pearlescent_froglight
fill 454 172 604 454 177 604 minecraft:pearlescent_froglight
fill 458 172 646 458 177 646 minecraft:pearlescent_froglight
fill 462 172 604 462 177 604 minecraft:pearlescent_froglight
fill 465 172 609 465 177 609 minecraft:pearlescent_froglight
fill 465 172 617 465 177 617 minecraft:pearlescent_froglight
fill 465 172 625 465 177 625 minecraft:pearlescent_froglight
fill 465 172 633 465 177 633 minecraft:pearlescent_froglight
fill 465 172 641 465 177 641 minecraft:pearlescent_froglight
fill 431 173 615 431 174 615 minecraft:black_concrete
fill 431 173 641 431 174 641 minecraft:black_concrete
fill 433 173 622 433 175 622 minecraft:blackstone
fill 433 173 634 433 175 634 minecraft:blackstone
fill 449 173 631 450 174 631 minecraft:white_concrete
fill 433 174 621 434 174 621 minecraft:blackstone
fill 433 174 635 434 174 635 minecraft:blackstone
fill 434 174 614 434 174 615 minecraft:black_concrete
fill 434 174 641 434 174 642 minecraft:black_concrete
setblock 437 174 616 minecraft:black_concrete
setblock 437 174 640 minecraft:black_concrete
fill 426 175 621 426 176 629 minecraft:quartz_block
fill 427 175 618 427 176 621 minecraft:quartz_block
fill 427 175 629 427 176 632 minecraft:quartz_block
fill 428 175 616 428 176 618 minecraft:quartz_block
fill 428 175 632 428 176 634 minecraft:quartz_block
fill 429 175 614 429 176 616 minecraft:quartz_block
fill 429 175 634 429 176 636 minecraft:quartz_block
fill 430 175 613 430 176 614 minecraft:quartz_block
fill 430 175 636 430 176 637 minecraft:quartz_block
fill 431 175 612 431 176 613 minecraft:quartz_block
fill 431 175 637 431 176 638 minecraft:quartz_block
fill 432 175 611 432 176 612 minecraft:quartz_block
fill 432 175 621 432 176 622 minecraft:blackstone
fill 432 175 634 432 176 635 minecraft:blackstone
fill 432 175 638 432 176 639 minecraft:quartz_block
fill 433 175 610 433 176 611 minecraft:quartz_block
fill 433 175 621 433 176 621 minecraft:blackstone
fill 433 175 635 433 176 635 minecraft:blackstone
fill 433 175 639 433 176 640 minecraft:quartz_block
fill 434 175 610 435 176 610 minecraft:quartz_block
setblock 434 175 614 minecraft:black_concrete
setblock 434 175 622 minecraft:blackstone
setblock 434 175 634 minecraft:blackstone
fill 434 175 640 435 176 640 minecraft:quartz_block
setblock 434 175 642 minecraft:black_concrete
fill 435 175 609 437 176 609 minecraft:quartz_block
fill 435 175 641 436 176 641 minecraft:quartz_block
fill 437 175 608 440 176 608 minecraft:quartz_block
fill 437 175 615 437 176 615 minecraft:black_concrete
fill 437 175 641 437 176 641 minecraft:black_concrete
fill 437 175 642 440 176 642 minecraft:quartz_block
fill 440 175 607 448 176 607 minecraft:quartz_block
fill 440 175 643 448 176 643 minecraft:quartz_block
fill 448 175 608 451 176 608 minecraft:quartz_block
fill 448 175 642 451 176 642 minecraft:quartz_block
fill 451 175 609 453 176 609 minecraft:quartz_block
fill 451 175 641 453 176 641 minecraft:quartz_block
fill 453 175 610 455 176 610 minecraft:quartz_block
fill 453 175 640 455 176 640 minecraft:quartz_block
fill 455 175 611 456 176 611 minecraft:quartz_block
fill 455 175 639 456 176 639 minecraft:quartz_block
fill 456 175 612 457 176 612 minecraft:quartz_block
fill 456 175 638 457 176 638 minecraft:quartz_block
fill 457 175 613 458 176 613 minecraft:quartz_block
fill 457 175 637 458 176 637 minecraft:quartz_block
fill 458 175 614 459 176 614 minecraft:quartz_block
fill 458 175 636 459 176 636 minecraft:quartz_block
fill 459 175 615 459 176 616 minecraft:quartz_block
fill 459 175 634 459 176 635 minecraft:quartz_block
fill 460 175 616 460 176 618 minecraft:quartz_block
fill 460 175 632 460 176 634 minecraft:quartz_block
fill 461 175 618 461 176 621 minecraft:quartz_block
fill 461 175 629 461 176 632 minecraft:quartz_block
fill 462 175 621 462 176 629 minecraft:quartz_block
fill 431 176 620 431 177 621 minecraft:blackstone
fill 431 176 635 431 177 636 minecraft:blackstone
fill 432 176 615 433 177 616 minecraft:black_concrete
fill 432 176 620 432 177 620 minecraft:blackstone
fill 432 176 636 432 177 636 minecraft:blackstone
fill 425 177 624 425 177 626 minecraft:pearlescent_froglight
fill 426 177 619 426 177 623 minecraft:pearlescent_froglight
fill 426 177 627 426 177 631 minecraft:pearlescent_froglight
fill 427 177 617 427 177 618 minecraft:pearlescent_froglight
fill 427 177 632 427 177 633 minecraft:pearlescent_froglight
fill 428 177 615 428 177 616 minecraft:pearlescent_froglight
fill 428 177 634 428 177 635 minecraft:pearlescent_froglight
setblock 429 177 636 minecraft:pearlescent_froglight
setblock 430 177 637 minecraft:pearlescent_froglight
setblock 431 177 638 minecraft:pearlescent_froglight
setblock 432 177 621 minecraft:blackstone
setblock 432 177 635 minecraft:blackstone
setblock 432 177 639 minecraft:pearlescent_froglight
setblock 433 177 640 minecraft:pearlescent_froglight
fill 434 177 641 435 177 641 minecraft:pearlescent_froglight
fill 436 177 642 437 177 642 minecraft:pearlescent_froglight
fill 438 177 643 442 177 643 minecraft:pearlescent_froglight
fill 443 177 644 445 177 644 minecraft:pearlescent_froglight
fill 446 177 643 450 177 643 minecraft:pearlescent_froglight
fill 451 177 642 452 177 642 minecraft:pearlescent_froglight
fill 453 177 641 454 177 641 minecraft:pearlescent_froglight
setblock 455 177 640 minecraft:pearlescent_froglight
setblock 456 177 639 minecraft:pearlescent_froglight
setblock 457 177 638 minecraft:pearlescent_froglight
setblock 458 177 637 minecraft:pearlescent_froglight
setblock 459 177 636 minecraft:pearlescent_froglight
fill 460 177 634 460 177 635 minecraft:pearlescent_froglight
fill 461 177 617 461 177 618 minecraft:pearlescent_froglight
fill 461 177 632 461 177 633 minecraft:pearlescent_froglight
fill 462 177 619 462 177 623 minecraft:pearlescent_froglight
fill 462 177 627 462 177 631 minecraft:pearlescent_froglight
fill 463 177 624 463 177 626 minecraft:pearlescent_froglight
fill 423 178 609 423 185 609 minecraft:gray_concrete
fill 423 178 617 423 185 617 minecraft:gray_concrete
fill 423 178 625 423 185 625 minecraft:gray_concrete
fill 423 178 633 423 185 633 minecraft:gray_concrete
fill 423 178 641 423 185 641 minecraft:gray_concrete
setblock 426 178 607 minecraft:light[level=13]
setblock 426 178 615 minecraft:light[level=13]
setblock 426 178 623 minecraft:light[level=13]
setblock 426 178 631 minecraft:light[level=13]
setblock 426 178 639 minecraft:light[level=13]
fill 426 178 646 426 185 646 minecraft:gray_concrete
fill 430 178 604 430 185 604 minecraft:gray_concrete
setblock 431 178 620 minecraft:blackstone
setblock 431 178 636 minecraft:blackstone
fill 433 178 623 433 179 623 minecraft:black_concrete
setblock 434 178 607 minecraft:light[level=13]
setblock 434 178 615 minecraft:light[level=13]
setblock 434 178 623 minecraft:light[level=13]
setblock 434 178 631 minecraft:light[level=13]
setblock 434 178 639 minecraft:light[level=13]
fill 434 178 646 434 185 646 minecraft:gray_concrete
fill 438 178 604 438 185 604 minecraft:gray_concrete
setblock 442 178 607 minecraft:light[level=13]
setblock 442 178 615 minecraft:light[level=13]
setblock 442 178 623 minecraft:light[level=13]
setblock 442 178 631 minecraft:light[level=13]
setblock 442 178 639 minecraft:light[level=13]
fill 442 178 646 442 185 646 minecraft:gray_concrete
fill 446 178 604 446 185 604 minecraft:gray_concrete
setblock 450 178 607 minecraft:light[level=13]
setblock 450 178 615 minecraft:light[level=13]
setblock 450 178 623 minecraft:light[level=13]
setblock 450 178 631 minecraft:light[level=13]
setblock 450 178 639 minecraft:light[level=13]
fill 450 178 646 450 185 646 minecraft:gray_concrete
fill 454 178 604 454 185 604 minecraft:gray_concrete
setblock 458 178 607 minecraft:light[level=13]
setblock 458 178 615 minecraft:light[level=13]
setblock 458 178 623 minecraft:light[level=13]
setblock 458 178 631 minecraft:light[level=13]
setblock 458 178 639 minecraft:light[level=13]
fill 458 178 646 458 185 646 minecraft:gray_concrete
fill 462 178 604 462 185 604 minecraft:gray_concrete
fill 465 178 609 465 185 609 minecraft:gray_concrete
fill 465 178 617 465 185 617 minecraft:gray_concrete
fill 465 178 625 465 185 625 minecraft:gray_concrete
fill 465 178 633 465 185 633 minecraft:gray_concrete
fill 465 178 641 465 184 641 minecraft:gray_concrete
fill 424 182 605 424 183 610 minecraft:quartz_block
fill 424 182 613 425 182 618 minecraft:quartz_block
fill 424 182 621 425 182 626 minecraft:quartz_block
fill 424 182 629 425 182 634 minecraft:quartz_block
fill 424 182 637 425 182 642 minecraft:quartz_block
fill 424 182 645 429 183 645 minecraft:quartz_block
fill 425 182 606 425 182 612 minecraft:quartz_block
fill 425 182 619 425 182 620 minecraft:quartz_block
fill 425 182 627 425 182 628 minecraft:quartz_block
fill 425 182 635 425 182 636 minecraft:quartz_block
fill 425 182 643 425 182 644 minecraft:quartz_block
fill 426 182 606 463 182 606 minecraft:quartz_block
fill 426 182 644 464 182 644 minecraft:quartz_block
fill 427 182 605 432 183 605 minecraft:quartz_block
fill 432 182 645 437 183 645 minecraft:quartz_block
fill 435 182 605 440 183 605 minecraft:quartz_block
fill 440 182 645 445 183 645 minecraft:quartz_block
fill 443 182 605 448 183 605 minecraft:quartz_block
fill 448 182 645 453 183 645 minecraft:quartz_block
fill 451 182 605 456 183 605 minecraft:quartz_block
fill 456 182 645 461 183 645 minecraft:quartz_block
fill 459 182 605 464 183 605 minecraft:quartz_block
fill 463 182 607 463 182 643 minecraft:quartz_block
fill 464 182 608 464 183 613 minecraft:quartz_block
fill 464 182 616 464 183 621 minecraft:quartz_block
fill 464 182 624 464 183 629 minecraft:quartz_block
fill 464 182 632 464 183 637 minecraft:quartz_block
fill 464 182 640 464 183 643 minecraft:quartz_block
fill 464 182 645 464 183 645 minecraft:quartz_block
fill 424 183 613 424 183 618 minecraft:quartz_block
fill 424 183 621 424 183 626 minecraft:quartz_block
fill 424 183 629 424 183 634 minecraft:quartz_block
fill 424 183 637 424 183 642 minecraft:quartz_block
setblock 464 183 644 minecraft:quartz_block
fill 423 184 610 423 187 611 minecraft:gray_concrete
setblock 423 184 612 minecraft:light_gray_concrete
fill 428 184 626 428 185 627 minecraft:black_concrete
fill 433 184 604 435 187 604 minecraft:gray_concrete
setblock 436 184 604 minecraft:light_gray_concrete
fill 437 184 604 437 187 604 minecraft:gray_concrete
fill 443 184 646 443 187 646 minecraft:gray_concrete
setblock 444 184 646 minecraft:light_gray_concrete
fill 445 184 646 446 187 646 minecraft:gray_concrete
fill 447 184 604 449 184 604 minecraft:gray_concrete
setblock 447 184 646 minecraft:light_gray_concrete
fill 448 184 646 448 187 646 minecraft:gray_concrete
setblock 450 184 604 minecraft:light_gray_concrete
fill 451 184 604 453 185 604 minecraft:gray_concrete
fill 459 184 646 459 187 646 minecraft:gray_concrete
setblock 460 184 646 minecraft:light_gray_concrete
fill 461 184 646 463 187 646 minecraft:gray_concrete
setblock 463 184 604 minecraft:light_gray_concrete
fill 464 184 604 465 185 604 minecraft:gray_concrete
setblock 464 184 646 minecraft:light_gray_concrete
setblock 465 184 605 minecraft:light_gray_concrete
fill 465 184 606 465 185 608 minecraft:gray_concrete
fill 465 184 620 465 187 620 minecraft:gray_concrete
setblock 465 184 621 minecraft:light_gray_concrete
setblock 465 184 622 minecraft:gray_concrete
fill 465 184 626 465 187 626 minecraft:gray_concrete
fill 465 184 627 465 185 627 minecraft:light_gray_concrete
fill 465 184 628 465 187 632 minecraft:gray_concrete
setblock 465 184 634 minecraft:light_gray_concrete
fill 465 184 635 465 185 638 minecraft:gray_concrete
setblock 465 184 642 minecraft:light_gray_concrete
fill 465 184 643 465 185 643 minecraft:gray_concrete
fill 465 184 646 465 187 646 minecraft:gray_concrete
setblock 423 185 606 minecraft:light_gray_concrete
fill 423 185 607 423 187 608 minecraft:gray_concrete
fill 423 185 612 423 187 612 minecraft:gray_concrete
fill 423 185 614 423 185 615 minecraft:gray_concrete
setblock 423 185 616 minecraft:light_gray_concrete
fill 430 185 646 431 187 646 minecraft:gray_concrete
setblock 432 185 604 minecraft:light_gray_concrete
setblock 432 185 646 minecraft:light_gray_concrete
fill 433 185 646 433 187 646 minecraft:gray_concrete
fill 435 185 646 437 187 646 minecraft:gray_concrete
fill 436 185 604 436 187 604 minecraft:gray_concrete
setblock 438 185 646 minecraft:light_gray_concrete
fill 439 185 646 441 187 646 minecraft:gray_concrete
fill 444 185 646 444 187 646 minecraft:gray_concrete
fill 447 185 604 448 187 604 minecraft:gray_concrete
fill 447 185 646 447 187 646 minecraft:gray_concrete
fill 449 185 604 449 186 604 minecraft:light_gray_concrete
fill 450 185 604 450 187 604 minecraft:gray_concrete
fill 451 185 646 451 187 646 minecraft:gray_concrete
fill 452 185 646 453 185 646 minecraft:light_gray_concrete
fill 456 185 634 456 190 634 minecraft:yellow_concrete
setblock 458 185 604 minecraft:light_gray_concrete
fill 460 185 646 460 187 646 minecraft:gray_concrete
setblock 463 185 604 minecraft:gray_concrete
fill 464 185 646 464 187 646 minecraft:gray_concrete
fill 465 185 605 465 188 605 minecraft:gray_concrete
fill 465 185 610 465 187 610 minecraft:gray_concrete
setblock 465 185 611 minecraft:light_gray_concrete
fill 465 185 612 465 187 612 minecraft:gray_concrete
fill 465 185 621 465 187 621 minecraft:gray_concrete
setblock 465 185 622 minecraft:light_gray_concrete
fill 465 185 634 465 187 634 minecraft:gray_concrete
setblock 465 185 641 minecraft:light_gray_concrete
setblock 465 185 642 minecraft:gray_concrete
fill 423 186 606 423 187 606 minecraft:gray_concrete
fill 423 186 609 423 191 609 minecraft:pearlescent_froglight
fill 423 186 614 423 188 614 minecraft:gray_concrete
setblock 423 186 615 minecraft:light_gray_concrete
fill 423 186 616 423 187 616 minecraft:gray_concrete
fill 423 186 617 423 191 617 minecraft:pearlescent_froglight
fill 423 186 618 423 187 620 minecraft:gray_concrete
setblock 423 186 621 minecraft:light_gray_concrete
fill 423 186 622 423 187 623 minecraft:gray_concrete
setblock 423 186 624 minecraft:light_gray_concrete
fill 423 186 625 423 191 625 minecraft:pearlescent_froglight
setblock 423 186 626 minecraft:light_gray_concrete
fill 423 186 627 423 187 628 minecraft:gray_concrete
fill 423 186 633 423 191 633 minecraft:pearlescent_froglight
fill 423 186 634 423 187 634 minecraft:gray_concrete
setblock 423 186 635 minecraft:light_gray_concrete
fill 423 186 641 423 191 641 minecraft:pearlescent_froglight
fill 423 186 646 423 187 646 minecraft:gray_concrete
fill 424 186 604 425 187 604 minecraft:gray_concrete
setblock 424 186 646 minecraft:light_gray_concrete
fill 425 186 646 425 187 646 minecraft:gray_concrete
setblock 426 186 604 minecraft:light_gray_concrete
setblock 426 186 607 minecraft:light[level=13]
setblock 426 186 615 minecraft:light[level=13]
setblock 426 186 623 minecraft:light[level=13]
setblock 426 186 631 minecraft:light[level=13]
setblock 426 186 639 minecraft:light[level=13]
fill 426 186 646 426 191 646 minecraft:pearlescent_froglight
fill 427 186 604 427 187 604 minecraft:gray_concrete
fill 430 186 604 430 191 604 minecraft:pearlescent_froglight
fill 432 186 604 432 187 604 minecraft:gray_concrete
fill 432 186 646 432 188 646 minecraft:gray_concrete
setblock 434 186 607 minecraft:light[level=13]
setblock 434 186 615 minecraft:light[level=13]
setblock 434 186 623 minecraft:light[level=13]
setblock 434 186 631 minecraft:light[level=13]
setblock 434 186 639 minecraft:light[level=13]
fill 434 186 646 434 191 646 minecraft:pearlescent_froglight
fill 438 186 604 438 191 604 minecraft:pearlescent_froglight
fill 438 186 646 438 187 646 minecraft:gray_concrete
setblock 439 186 604 minecraft:light_gray_concrete
fill 440 186 604 440 187 604 minecraft:gray_concrete
setblock 442 186 607 minecraft:light[level=13]
setblock 442 186 615 minecraft:light[level=13]
setblock 442 186 623 minecraft:light[level=13]
setblock 442 186 631 minecraft:light[level=13]
setblock 442 186 639 minecraft:light[level=13]
fill 442 186 646 442 191 646 minecraft:pearlescent_froglight
fill 446 186 604 446 191 604 minecraft:pearlescent_froglight
setblock 450 186 607 minecraft:light[level=13]
setblock 450 186 615 minecraft:light[level=13]
setblock 450 186 623 minecraft:light[level=13]
setblock 450 186 631 minecraft:light[level=13]
setblock 450 186 639 minecraft:light[level=13]
fill 450 186 646 450 191 646 minecraft:pearlescent_froglight
setblock 451 186 604 minecraft:light_gray_concrete
fill 452 186 604 453 187 604 minecraft:gray_concrete
setblock 452 186 646 minecraft:light_gray_concrete
fill 453 186 646 453 187 646 minecraft:gray_concrete
fill 454 186 604 454 191 604 minecraft:pearlescent_froglight
fill 454 186 634 455 189 634 minecraft:yellow_concrete
fill 455 186 633 457 189 633 minecraft:yellow_concrete
fill 455 186 635 457 189 635 minecraft:yellow_concrete
fill 456 186 632 456 189 632 minecraft:yellow_concrete
fill 456 186 636 456 189 636 minecraft:yellow_concrete
fill 457 186 634 458 189 634 minecraft:yellow_concrete
fill 458 186 604 458 187 604 minecraft:gray_concrete
setblock 458 186 607 minecraft:light[level=13]
setblock 458 186 615 minecraft:light[level=13]
setblock 458 186 623 minecraft:light[level=13]
setblock 458 186 631 minecraft:light[level=13]
setblock 458 186 639 minecraft:light[level=13]
fill 458 186 646 458 191 646 minecraft:pearlescent_froglight
fill 462 186 604 462 191 604 minecraft:pearlescent_froglight
setblock 463 186 604 minecraft:light_gray_concrete
fill 464 186 604 464 188 604 minecraft:gray_concrete
setblock 465 186 604 minecraft:light_gray_concrete
fill 465 186 606 465 187 606 minecraft:gray_concrete
fill 465 186 607 465 186 608 minecraft:light_gray_concrete
fill 465 186 609 465 191 609 minecraft:pearlescent_froglight
fill 465 186 611 465 187 611 minecraft:gray_concrete
fill 465 186 617 465 191 617 minecraft:pearlescent_froglight
fill 465 186 622 465 187 622 minecraft:gray_concrete
fill 465 186 625 465 191 625 minecraft:pearlescent_froglight
fill 465 186 627 465 187 627 minecraft:gray_concrete
fill 465 186 633 465 191 633 minecraft:pearlescent_froglight
fill 465 186 635 465 187 635 minecraft:gray_concrete
setblock 465 186 636 minecraft:light_gray_concrete
fill 465 186 637 465 187 638 minecraft:gray_concrete
fill 465 186 641 465 191 641 minecraft:pearlescent_froglight
fill 465 186 642 465 186 643 minecraft:light_gray_concrete
setblock 423 187 615 minecraft:gray_concrete
setblock 423 187 621 minecraft:gray_concrete
setblock 423 187 624 minecraft:gray_concrete
setblock 423 187 626 minecraft:gray_concrete
fill 423 187 635 423 188 635 minecraft:gray_concrete
setblock 424 187 646 minecraft:gray_concrete
setblock 426 187 604 minecraft:gray_concrete
fill 431 187 631 432 188 632 minecraft:gold_block
setblock 439 187 604 minecraft:gray_concrete
fill 449 187 604 449 188 604 minecraft:gray_concrete
setblock 451 187 604 minecraft:gray_concrete
setblock 452 187 646 minecraft:gray_concrete
fill 454 187 633 454 188 633 minecraft:yellow_concrete
fill 454 187 635 454 188 635 minecraft:yellow_concrete
fill 455 187 632 455 188 632 minecraft:yellow_concrete
fill 455 187 636 455 188 636 minecraft:yellow_concrete
fill 457 187 632 457 188 632 minecraft:yellow_concrete
fill 457 187 636 457 188 636 minecraft:yellow_concrete
fill 458 187 633 458 188 633 minecraft:yellow_concrete
fill 458 187 635 458 188 635 minecraft:yellow_concrete
setblock 463 187 604 minecraft:gray_concrete
setblock 465 187 604 minecraft:gray_concrete
fill 465 187 607 465 187 608 minecraft:gray_concrete
setblock 465 187 636 minecraft:gray_concrete
fill 465 187 642 465 187 643 minecraft:gray_concrete
fill 423 188 604 423 189 608 minecraft:light_gray_concrete
fill 423 188 610 423 189 613 minecraft:light_gray_concrete
fill 423 188 615 423 188 616 minecraft:light_gray_concrete
fill 423 188 618 423 243 624 minecraft:light_gray_concrete
fill 423 188 626 423 188 632 minecraft:light_gray_concrete
fill 423 188 634 423 247 634 minecraft:light_gray_concrete
fill 423 188 636 423 189 640 minecraft:light_gray_concrete
fill 423 188 642 423 188 646 minecraft:light_gray_concrete
fill 424 188 604 429 188 604 minecraft:light_gray_concrete
fill 424 188 646 425 247 646 minecraft:light_gray_concrete
fill 427 188 646 431 243 646 minecraft:light_gray_concrete
fill 431 188 604 437 188 604 minecraft:light_gray_concrete
setblock 433 188 646 minecraft:light_gray_concrete
fill 435 188 646 441 189 646 minecraft:light_gray_concrete
fill 439 188 604 443 188 604 minecraft:light_gray_concrete
fill 443 188 646 448 188 646 minecraft:light_gray_concrete
setblock 444 188 604 minecraft:gray_concrete
fill 445 188 604 445 248 604 minecraft:light_gray_concrete
fill 447 188 604 448 189 604 minecraft:light_gray_concrete
fill 450 188 604 452 247 604 minecraft:light_gray_concrete
fill 451 188 646 457 188 646 minecraft:light_gray_concrete
setblock 453 188 604 minecraft:gray_concrete
setblock 455 188 604 minecraft:gray_concrete
fill 456 188 604 461 188 604 minecraft:light_gray_concrete
fill 459 188 646 465 188 646 minecraft:light_gray_concrete
fill 463 188 604 463 247 604 minecraft:light_gray_concrete
setblock 465 188 604 minecraft:light_gray_concrete
fill 465 188 606 465 244 608 minecraft:light_gray_concrete
fill 465 188 610 465 189 614 minecraft:light_gray_concrete
setblock 465 188 615 minecraft:gray_concrete
fill 465 188 616 465 247 616 minecraft:light_gray_concrete
fill 465 188 618 465 188 622 minecraft:light_gray_concrete
fill 465 188 624 465 247 624 minecraft:light_gray_concrete
fill 465 188 626 465 188 632 minecraft:light_gray_concrete
fill 465 188 634 465 243 637 minecraft:light_gray_concrete
setblock 465 188 638 minecraft:gray_concrete
fill 465 188 639 465 247 640 minecraft:light_gray_concrete
fill 465 188 642 465 188 645 minecraft:light_gray_concrete
fill 423 189 614 423 247 615 minecraft:light_gray_concrete
setblock 423 189 616 minecraft:gray_concrete
fill 423 189 626 423 189 627 minecraft:light_gray_concrete
fill 423 189 628 423 190 628 minecraft:gray_concrete
fill 423 189 629 423 243 632 minecraft:light_gray_concrete
setblock 423 189 635 minecraft:light_gray_concrete
setblock 423 189 642 minecraft:gray_concrete
setblock 423 189 643 minecraft:light_gray_concrete
setblock 423 189 644 minecraft:gray_concrete
fill 423 189 645 423 245 645 minecraft:light_gray_concrete
setblock 423 189 646 minecraft:gray_concrete
fill 424 189 604 428 243 604 minecraft:light_gray_concrete
setblock 429 189 604 minecraft:gray_concrete
fill 431 189 604 432 247 604 minecraft:light_gray_concrete
fill 432 189 646 432 247 646 minecraft:light_gray_concrete
setblock 433 189 604 minecraft:gray_concrete
setblock 433 189 646 minecraft:gray_concrete
fill 434 189 604 435 247 604 minecraft:light_gray_concrete
setblock 436 189 604 minecraft:gray_concrete
fill 437 189 604 437 245 604 minecraft:light_gray_concrete
fill 439 189 604 441 247 604 minecraft:light_gray_concrete
setblock 442 189 604 minecraft:gray_concrete
fill 443 189 604 444 247 604 minecraft:light_gray_concrete
fill 443 189 646 445 244 646 minecraft:light_gray_concrete
setblock 446 189 646 minecraft:gray_concrete
fill 447 189 646 449 189 646 minecraft:light_gray_concrete
fill 449 189 604 449 247 604 minecraft:light_gray_concrete
fill 451 189 646 454 247 646 minecraft:light_gray_concrete
fill 453 189 604 453 247 604 minecraft:light_gray_concrete
fill 455 189 604 458 189 604 minecraft:light_gray_concrete
fill 455 189 617 455 190 617 minecraft:black_concrete
setblock 455 189 646 minecraft:gray_concrete
fill 456 189 646 457 243 646 minecraft:light_gray_concrete
fill 459 189 604 459 190 604 minecraft:gray_concrete
fill 459 189 646 462 189 646 minecraft:light_gray_concrete
fill 460 189 604 461 245 604 minecraft:light_gray_concrete
setblock 463 189 646 minecraft:gray_concrete
fill 464 189 604 464 247 604 minecraft:light_gray_concrete
fill 464 189 646 464 247 646 minecraft:light_gray_concrete
setblock 465 189 604 minecraft:gray_concrete
fill 465 189 605 465 247 605 minecraft:light_gray_concrete
fill 465 189 615 465 247 615 minecraft:light_gray_concrete
setblock 465 189 618 minecraft:gray_concrete
fill 465 189 619 465 245 623 minecraft:light_gray_concrete
setblock 465 189 626 minecraft:gray_concrete
fill 465 189 627 465 244 632 minecraft:light_gray_concrete
fill 465 189 638 465 244 638 minecraft:light_gray_concrete
fill 465 189 642 465 189 644 minecraft:light_gray_concrete
fill 465 189 645 465 189 646 minecraft:gray_concrete
fill 423 190 604 423 243 604 minecraft:light_gray_concrete
setblock 423 190 605 minecraft:gray_concrete
fill 423 190 606 423 243 608 minecraft:light_gray_concrete
fill 423 190 610 423 247 612 minecraft:light_gray_concrete
setblock 423 190 613 minecraft:gray_concrete
fill 423 190 616 423 247 616 minecraft:light_gray_concrete
fill 423 190 626 423 204 626 minecraft:light_gray_concrete
setblock 423 190 627 minecraft:gray_concrete
setblock 423 190 635 minecraft:gray_concrete
fill 423 190 636 423 244 637 minecraft:light_gray_concrete
setblock 423 190 638 minecraft:gray_concrete
fill 423 190 639 423 245 640 minecraft:light_gray_concrete
fill 423 190 642 423 243 642 minecraft:light_gray_concrete
setblock 423 190 643 minecraft:gray_concrete
fill 423 190 644 423 247 644 minecraft:light_gray_concrete
fill 423 190 646 423 244 646 minecraft:light_gray_concrete
fill 429 190 604 429 245 604 minecraft:light_gray_concrete
fill 433 190 604 433 247 604 minecraft:light_gray_concrete
fill 433 190 646 433 247 646 minecraft:light_gray_concrete
fill 435 190 646 439 245 646 minecraft:light_gray_concrete
fill 436 190 604 436 245 604 minecraft:light_gray_concrete
setblock 440 190 646 minecraft:gray_concrete
fill 441 190 646 441 245 646 minecraft:light_gray_concrete
fill 442 190 604 442 247 604 minecraft:light_gray_concrete
fill 446 190 646 446 247 646 minecraft:light_gray_concrete
setblock 447 190 604 minecraft:gray_concrete
setblock 447 190 646 minecraft:gray_concrete
fill 448 190 604 448 243 604 minecraft:light_gray_concrete
fill 448 190 646 449 245 646 minecraft:light_gray_concrete
fill 455 190 604 456 247 604 minecraft:light_gray_concrete
fill 455 190 646 455 244 646 minecraft:light_gray_concrete
setblock 457 190 604 minecraft:gray_concrete
fill 458 190 604 458 247 604 minecraft:light_gray_concrete
fill 459 190 646 459 247 646 minecraft:light_gray_concrete
setblock 460 190 646 minecraft:gray_concrete
fill 461 190 646 463 247 646 minecraft:light_gray_concrete
fill 465 190 604 465 243 604 minecraft:light_gray_concrete
fill 465 190 610 465 247 610 minecraft:light_gray_concrete
setblock 465 190 611 minecraft:gray_concrete
fill 465 190 612 465 243 614 minecraft:light_gray_concrete
fill 465 190 618 465 248 618 minecraft:light_gray_concrete
fill 465 190 626 465 247 626 minecraft:light_gray_concrete
fill 465 190 642 465 244 642 minecraft:light_gray_concrete
setblock 465 190 643 minecraft:gray_concrete
fill 465 190 644 465 245 646 minecraft:light_gray_concrete
fill 423 191 605 423 247 605 minecraft:light_gray_concrete
fill 423 191 613 423 243 613 minecraft:light_gray_concrete
fill 423 191 627 423 243 628 minecraft:light_gray_concrete
fill 423 191 635 423 247 635 minecraft:light_gray_concrete
fill 423 191 638 423 247 638 minecraft:light_gray_concrete
fill 423 191 643 423 244 643 minecraft:light_gray_concrete
fill 440 191 646 440 248 646 minecraft:light_gray_concrete
fill 447 191 604 447 247 604 minecraft:light_gray_concrete
fill 447 191 646 447 244 646 minecraft:light_gray_concrete
fill 453 191 612 456 196 614 minecraft:light_blue_concrete
fill 454 191 615 455 196 615 minecraft:light_blue_concrete
fill 455 191 611 455 196 611 minecraft:light_blue_concrete
fill 457 191 604 457 247 604 minecraft:light_gray_concrete
fill 459 191 604 459 247 604 minecraft:light_gray_concrete
fill 460 191 646 460 247 646 minecraft:light_gray_concrete
fill 465 191 611 465 247 611 minecraft:light_gray_concrete
fill 465 191 643 465 248 643 minecraft:light_gray_concrete
fill 423 192 609 423 213 609 minecraft:light_gray_concrete
fill 423 192 617 423 213 617 minecraft:light_gray_concrete
fill 423 192 625 423 213 625 minecraft:light_gray_concrete
fill 423 192 633 423 213 633 minecraft:light_gray_concrete
fill 423 192 641 423 213 641 minecraft:light_gray_concrete
fill 426 192 646 426 213 646 minecraft:light_gray_concrete
fill 430 192 604 430 213 604 minecraft:light_gray_concrete
fill 434 192 646 434 213 646 minecraft:light_gray_concrete
fill 438 192 604 438 213 604 minecraft:light_gray_concrete
fill 442 192 646 442 213 646 minecraft:light_gray_concrete
fill 446 192 604 446 213 604 minecraft:light_gray_concrete
fill 450 192 646 450 213 646 minecraft:light_gray_concrete
fill 452 192 612 452 195 614 minecraft:light_blue_concrete
fill 453 192 611 454 195 611 minecraft:light_blue_concrete
fill 453 192 615 453 195 615 minecraft:light_blue_concrete
fill 454 192 604 454 213 604 minecraft:light_gray_concrete
fill 455 192 616 455 195 616 minecraft:light_blue_concrete
fill 456 192 611 456 195 611 minecraft:light_blue_concrete
fill 456 192 615 456 195 615 minecraft:light_blue_concrete
fill 457 192 612 457 195 614 minecraft:light_blue_concrete
fill 458 192 646 458 213 646 minecraft:light_gray_concrete
fill 462 192 604 462 213 604 minecraft:light_gray_concrete
fill 465 192 609 465 213 609 minecraft:light_gray_concrete
fill 465 192 617 465 213 617 minecraft:light_gray_concrete
fill 465 192 625 465 213 625 minecraft:light_gray_concrete
fill 465 192 633 465 213 633 minecraft:light_gray_concrete
fill 465 192 641 465 213 641 minecraft:light_gray_concrete
fill 454 193 610 455 194 610 minecraft:light_blue_concrete
fill 454 193 616 454 194 616 minecraft:light_blue_concrete
fill 456 193 616 456 194 616 minecraft:light_blue_concrete
fill 457 193 611 457 194 611 minecraft:light_blue_concrete
fill 457 193 615 457 194 615 minecraft:light_blue_concrete
setblock 426 194 607 minecraft:light[level=13]
setblock 426 194 615 minecraft:light[level=13]
setblock 426 194 623 minecraft:light[level=13]
setblock 426 194 631 minecraft:light[level=13]
setblock 426 194 639 minecraft:light[level=13]
setblock 434 194 607 minecraft:light[level=13]
setblock 434 194 615 minecraft:light[level=13]
setblock 434 194 623 minecraft:light[level=13]
setblock 434 194 631 minecraft:light[level=13]
setblock 434 194 639 minecraft:light[level=13]
setblock 442 194 607 minecraft:light[level=13]
setblock 442 194 615 minecraft:light[level=13]
setblock 442 194 623 minecraft:light[level=13]
setblock 442 194 631 minecraft:light[level=13]
setblock 442 194 639 minecraft:light[level=13]
setblock 450 194 607 minecraft:light[level=13]
setblock 450 194 615 minecraft:light[level=13]
setblock 450 194 623 minecraft:light[level=13]
setblock 450 194 631 minecraft:light[level=13]
setblock 450 194 639 minecraft:light[level=13]
setblock 458 194 607 minecraft:light[level=13]
setblock 458 194 615 minecraft:light[level=13]
setblock 458 194 623 minecraft:light[level=13]
setblock 458 194 631 minecraft:light[level=13]
setblock 458 194 639 minecraft:light[level=13]
fill 454 195 621 454 196 623 minecraft:gold_block
fill 455 195 621 455 196 622 minecraft:gold_block
fill 424 196 605 424 197 610 minecraft:quartz_block
fill 424 196 613 425 196 618 minecraft:quartz_block
fill 424 196 621 425 196 626 minecraft:quartz_block
fill 424 196 629 425 196 634 minecraft:quartz_block
fill 424 196 637 425 196 642 minecraft:quartz_block
fill 424 196 645 429 197 645 minecraft:quartz_block
fill 425 196 606 425 196 612 minecraft:quartz_block
fill 425 196 619 425 196 620 minecraft:quartz_block
fill 425 196 627 425 196 628 minecraft:quartz_block
fill 425 196 635 425 196 636 minecraft:quartz_block
fill 425 196 643 425 196 644 minecraft:quartz_block
fill 426 196 606 463 196 606 minecraft:quartz_block
fill 426 196 644 464 196 644 minecraft:quartz_block
fill 427 196 605 432 197 605 minecraft:quartz_block
fill 432 196 645 437 197 645 minecraft:quartz_block
fill 435 196 605 440 197 605 minecraft:quartz_block
fill 440 196 645 445 197 645 minecraft:quartz_block
fill 443 196 605 448 197 605 minecraft:quartz_block
fill 448 196 645 453 197 645 minecraft:quartz_block
fill 451 196 605 456 197 605 minecraft:quartz_block
fill 456 196 645 461 197 645 minecraft:quartz_block
fill 459 196 605 464 197 605 minecraft:quartz_block
fill 463 196 607 463 196 643 minecraft:quartz_block
fill 464 196 608 464 197 613 minecraft:quartz_block
fill 464 196 616 464 197 621 minecraft:quartz_block
fill 464 196 624 464 197 629 minecraft:quartz_block
fill 464 196 632 464 197 637 minecraft:quartz_block
fill 464 196 640 464 197 643 minecraft:quartz_block
fill 464 196 645 464 197 645 minecraft:quartz_block
fill 424 197 613 424 197 618 minecraft:quartz_block
fill 424 197 621 424 197 626 minecraft:quartz_block
fill 424 197 629 424 197 634 minecraft:quartz_block
fill 424 197 637 424 197 642 minecraft:quartz_block
setblock 464 197 644 minecraft:quartz_block
fill 426 198 621 426 199 629 minecraft:quartz_block
fill 427 198 618 427 199 621 minecraft:quartz_block
fill 427 198 629 427 199 632 minecraft:quartz_block
fill 428 198 616 428 199 618 minecraft:quartz_block
fill 428 198 632 428 199 634 minecraft:quartz_block
fill 429 198 614 429 199 616 minecraft:quartz_block
fill 429 198 634 429 199 636 minecraft:quartz_block
fill 430 198 613 430 199 614 minecraft:quartz_block
fill 430 198 636 430 199 637 minecraft:quartz_block
fill 431 198 612 431 199 613 minecraft:quartz_block
fill 431 198 637 431 199 638 minecraft:quartz_block
fill 432 198 611 432 199 612 minecraft:quartz_block
fill 432 198 638 432 199 639 minecraft:quartz_block
fill 433 198 610 433 199 611 minecraft:quartz_block
fill 433 198 639 433 199 640 minecraft:quartz_block
fill 434 198 610 435 199 610 minecraft:quartz_block
fill 434 198 640 435 199 640 minecraft:quartz_block
fill 435 198 609 437 199 609 minecraft:quartz_block
fill 435 198 641 437 199 641 minecraft:quartz_block
fill 437 198 608 440 199 608 minecraft:quartz_block
fill 437 198 642 440 199 642 minecraft:quartz_block
fill 440 198 607 448 199 607 minecraft:quartz_block
fill 440 198 643 448 199 643 minecraft:quartz_block
fill 448 198 608 451 199 608 minecraft:quartz_block
fill 448 198 642 451 199 642 minecraft:quartz_block
fill 451 198 609 453 199 609 minecraft:quartz_block
fill 451 198 641 453 199 641 minecraft:quartz_block
fill 453 198 610 455 199 610 minecraft:quartz_block
fill 453 198 640 455 199 640 minecraft:quartz_block
fill 455 198 611 456 199 611 minecraft:quartz_block
fill 455 198 639 456 199 639 minecraft:quartz_block
fill 456 198 612 457 199 612 minecraft:quartz_block
fill 456 198 638 457 199 638 minecraft:quartz_block
fill 457 198 613 458 199 613 minecraft:quartz_block
fill 457 198 637 458 199 637 minecraft:quartz_block
fill 458 198 614 459 199 614 minecraft:quartz_block
fill 458 198 636 459 199 636 minecraft:quartz_block
fill 459 198 615 459 199 616 minecraft:quartz_block
fill 459 198 634 459 199 635 minecraft:quartz_block
fill 460 198 616 460 199 618 minecraft:quartz_block
fill 460 198 632 460 199 634 minecraft:quartz_block
fill 461 198 618 461 199 621 minecraft:quartz_block
fill 461 198 629 461 199 632 minecraft:quartz_block
fill 462 198 621 462 199 629 minecraft:quartz_block
setblock 426 202 607 minecraft:light[level=13]
setblock 426 202 615 minecraft:light[level=13]
setblock 426 202 623 minecraft:light[level=13]
setblock 426 202 631 minecraft:light[level=13]
setblock 426 202 639 minecraft:light[level=13]
setblock 434 202 607 minecraft:light[level=13]
setblock 434 202 615 minecraft:light[level=13]
setblock 434 202 623 minecraft:light[level=13]
setblock 434 202 631 minecraft:light[level=13]
setblock 434 202 639 minecraft:light[level=13]
setblock 442 202 607 minecraft:light[level=13]
setblock 442 202 615 minecraft:light[level=13]
setblock 442 202 623 minecraft:light[level=13]
setblock 442 202 631 minecraft:light[level=13]
setblock 442 202 639 minecraft:light[level=13]
setblock 450 202 607 minecraft:light[level=13]
setblock 450 202 615 minecraft:light[level=13]
setblock 450 202 623 minecraft:light[level=13]
setblock 450 202 631 minecraft:light[level=13]
setblock 450 202 639 minecraft:light[level=13]
setblock 458 202 607 minecraft:light[level=13]
setblock 458 202 615 minecraft:light[level=13]
setblock 458 202 623 minecraft:light[level=13]
setblock 458 202 631 minecraft:light[level=13]
setblock 458 202 639 minecraft:light[level=13]
fill 434 204 622 436 204 624 minecraft:redstone_block
fill 438 204 630 440 204 632 minecraft:redstone_block
fill 442 204 622 444 204 624 minecraft:redstone_block
fill 423 205 626 424 206 626 minecraft:gold_block
fill 424 205 623 425 206 625 minecraft:gold_block
fill 424 205 627 425 206 629 minecraft:gold_block
fill 425 205 621 426 206 622 minecraft:gold_block
fill 425 205 626 433 206 626 minecraft:white_concrete
fill 425 205 630 426 206 631 minecraft:gold_block
fill 426 205 620 428 206 620 minecraft:gold_block
fill 426 205 623 433 205 625 minecraft:white_concrete
fill 426 205 627 433 206 629 minecraft:white_concrete
fill 426 205 632 428 206 632 minecraft:gold_block
fill 427 205 619 430 206 619 minecraft:gold_block
fill 427 205 621 427 206 621 minecraft:gold_block
fill 427 205 622 433 205 622 minecraft:white_concrete
fill 427 205 630 434 206 630 minecraft:white_concrete
fill 427 205 631 427 206 631 minecraft:gold_block
fill 427 205 633 430 206 633 minecraft:gold_block
fill 428 205 621 435 205 621 minecraft:white_concrete
fill 428 205 631 435 206 631 minecraft:white_concrete
fill 429 205 618 433 206 618 minecraft:gold_block
fill 429 205 620 449 206 620 minecraft:white_concrete
fill 429 205 632 437 205 632 minecraft:white_concrete
fill 429 205 634 433 206 634 minecraft:gold_block
fill 431 205 617 447 206 617 minecraft:gold_block
fill 431 205 619 447 206 619 minecraft:white_concrete
fill 431 205 633 447 205 633 minecraft:white_concrete
fill 431 205 635 447 206 635 minecraft:gold_block
fill 434 205 616 444 206 616 minecraft:gold_block
fill 434 205 618 444 206 618 minecraft:white_concrete
setblock 434 205 625 minecraft:gray_concrete
fill 434 205 626 437 205 626 minecraft:black_concrete
fill 434 205 627 434 206 627 minecraft:gray_concrete
fill 434 205 628 434 206 628 minecraft:black_concrete
fill 434 205 629 434 206 629 minecraft:gray_concrete
fill 434 205 634 444 206 634 minecraft:white_concrete
fill 434 205 636 444 206 636 minecraft:gold_block
fill 435 205 625 437 205 625 minecraft:black_concrete
fill 435 205 627 437 205 627 minecraft:black_concrete
fill 435 205 628 435 206 628 minecraft:gray_concrete
fill 435 205 629 435 206 630 minecraft:black_concrete
setblock 436 205 621 minecraft:black_concrete
fill 436 205 628 437 205 629 minecraft:black_concrete
fill 436 205 630 436 206 630 minecraft:gray_concrete
fill 436 205 631 436 206 631 minecraft:black_concrete
setblock 437 205 621 minecraft:gray_concrete
fill 437 205 622 437 205 624 minecraft:black_concrete
setblock 437 205 630 minecraft:black_concrete
setblock 437 205 631 minecraft:gray_concrete
fill 438 205 621 438 206 622 minecraft:black_concrete
fill 438 205 623 440 206 623 minecraft:gray_concrete
fill 438 205 624 441 205 624 minecraft:black_concrete
fill 438 205 628 442 205 628 minecraft:black_concrete
fill 438 205 629 440 205 629 minecraft:gray_concrete
fill 439 205 621 439 206 622 minecraft:gray_concrete
fill 440 205 621 440 206 622 minecraft:black_concrete
setblock 441 205 621 minecraft:gray_concrete
fill 441 205 622 441 205 623 minecraft:black_concrete
fill 441 205 625 443 205 627 minecraft:black_concrete
fill 441 205 629 441 205 630 minecraft:black_concrete
setblock 441 205 631 minecraft:gray_concrete
fill 441 205 632 449 205 632 minecraft:white_concrete
setblock 442 205 621 minecraft:black_concrete
fill 442 205 629 443 206 629 minecraft:black_concrete
fill 442 205 630 442 206 630 minecraft:gray_concrete
fill 442 205 631 442 206 631 minecraft:black_concrete
fill 443 205 621 450 205 621 minecraft:white_concrete
fill 443 205 628 443 206 628 minecraft:gray_concrete
fill 443 205 630 443 206 630 minecraft:black_concrete
fill 443 205 631 450 206 631 minecraft:white_concrete
setblock 444 205 625 minecraft:gray_concrete
fill 444 205 626 444 206 626 minecraft:black_concrete
fill 444 205 627 444 206 627 minecraft:gray_concrete
fill 444 205 628 444 206 628 minecraft:black_concrete
fill 444 205 629 444 206 629 minecraft:gray_concrete
fill 444 205 630 451 206 630 minecraft:white_concrete
fill 445 205 618 449 206 618 minecraft:gold_block
fill 445 205 622 451 205 629 minecraft:white_concrete
fill 445 205 634 449 206 634 minecraft:gold_block
fill 448 205 619 451 206 619 minecraft:gold_block
fill 448 205 633 451 206 633 minecraft:gold_block
fill 450 205 620 452 206 620 minecraft:gold_block
fill 450 205 632 452 206 632 minecraft:gold_block
fill 451 205 621 453 206 621 minecraft:gold_block
fill 451 205 631 453 206 631 minecraft:gold_block
fill 452 205 622 453 206 622 minecraft:gold_block
fill 452 205 623 452 206 629 minecraft:white_concrete
fill 452 205 630 453 206 630 minecraft:gold_block
fill 453 205 623 454 206 625 minecraft:gold_block
fill 453 205 626 453 206 626 minecraft:white_concrete
fill 453 205 627 454 206 629 minecraft:gold_block
fill 454 205 626 455 206 626 minecraft:gold_block
fill 424 206 605 424 206 622 minecraft:gray_concrete
fill 424 206 630 424 206 645 minecraft:gray_concrete
fill 425 206 605 425 206 620 minecraft:gray_concrete
fill 425 206 632 425 206 645 minecraft:gray_concrete
fill 426 206 605 426 206 619 minecraft:gray_concrete
fill 426 206 623 432 206 625 minecraft:white_concrete
fill 426 206 633 426 206 645 minecraft:gray_concrete
fill 427 206 605 428 206 618 minecraft:gray_concrete
fill 427 206 622 432 206 622 minecraft:white_concrete
fill 427 206 634 428 206 645 minecraft:gray_concrete
fill 428 206 621 432 206 621 minecraft:white_concrete
fill 429 206 605 430 206 617 minecraft:gray_concrete
fill 429 206 632 436 206 632 minecraft:white_concrete
fill 429 206 635 430 206 645 minecraft:gray_concrete
fill 431 206 605 433 206 616 minecraft:gray_concrete
fill 431 206 633 436 206 633 minecraft:white_concrete
fill 431 206 636 433 206 645 minecraft:gray_concrete
fill 433 206 621 433 206 625 minecraft:pearlescent_froglight
fill 434 206 605 464 206 615 minecraft:gray_concrete
fill 434 206 621 437 206 621 minecraft:pearlescent_froglight
fill 434 206 622 436 206 624 minecraft:gray_concrete
fill 434 206 625 437 206 625 minecraft:pearlescent_froglight
fill 434 206 626 436 206 626 minecraft:black_concrete
fill 434 206 637 464 206 645 minecraft:gray_concrete
fill 435 206 627 436 206 627 minecraft:black_concrete
fill 436 206 628 436 206 629 minecraft:black_concrete
fill 437 206 622 437 206 624 minecraft:pearlescent_froglight
fill 437 206 626 437 206 633 minecraft:pearlescent_froglight
fill 438 206 624 441 206 624 minecraft:pearlescent_froglight
fill 438 206 628 441 206 629 minecraft:pearlescent_froglight
fill 438 206 630 440 206 632 minecraft:gray_concrete
fill 438 206 633 441 206 633 minecraft:pearlescent_froglight
fill 441 206 621 441 206 623 minecraft:pearlescent_froglight
fill 441 206 625 441 206 627 minecraft:pearlescent_froglight
fill 441 206 630 441 206 632 minecraft:pearlescent_froglight
fill 442 206 621 445 206 621 minecraft:pearlescent_froglight
fill 442 206 622 444 206 624 minecraft:gray_concrete
fill 442 206 625 445 206 625 minecraft:pearlescent_froglight
fill 442 206 626 442 206 628 minecraft:black_concrete
fill 442 206 632 447 206 633 minecraft:white_concrete
fill 443 206 626 443 206 627 minecraft:black_concrete
fill 445 206 616 464 206 616 minecraft:gray_concrete
fill 445 206 622 445 206 624 minecraft:pearlescent_froglight
fill 445 206 626 451 206 629 minecraft:white_concrete
fill 445 206 636 464 206 636 minecraft:gray_concrete
fill 446 206 621 450 206 625 minecraft:white_concrete
fill 448 206 617 464 206 617 minecraft:gray_concrete
fill 448 206 632 449 206 632 minecraft:white_concrete
fill 448 206 635 464 206 635 minecraft:gray_concrete
fill 450 206 618 464 206 618 minecraft:gray_concrete
fill 450 206 634 464 206 634 minecraft:gray_concrete
fill 451 206 622 451 206 625 minecraft:white_concrete
fill 452 206 619 464 206 619 minecraft:gray_concrete
fill 452 206 633 464 206 633 minecraft:gray_concrete
fill 453 206 620 464 206 620 minecraft:gray_concrete
fill 453 206 632 464 206 632 minecraft:gray_concrete
fill 454 206 621 464 206 622 minecraft:gray_concrete
fill 454 206 630 464 206 631 minecraft:gray_concrete
fill 455 206 623 464 206 625 minecraft:gray_concrete
fill 455 206 627 464 206 629 minecraft:gray_concrete
fill 456 206 626 464 206 626 minecraft:gray_concrete
fill 423 207 626 423 245 626 minecraft:light_gray_concrete
fill 424 210 605 425 210 645 minecraft:quartz_block
fill 426 210 605 464 210 606 minecraft:quartz_block
setblock 426 210 607 minecraft:light[level=13]
setblock 426 210 615 minecraft:light[level=13]
setblock 426 210 623 minecraft:light[level=13]
setblock 426 210 631 minecraft:light[level=13]
setblock 426 210 639 minecraft:light[level=13]
fill 426 210 644 464 210 645 minecraft:quartz_block
setblock 434 210 607 minecraft:light[level=13]
setblock 434 210 615 minecraft:light[level=13]
setblock 434 210 623 minecraft:light[level=13]
setblock 434 210 631 minecraft:light[level=13]
setblock 434 210 639 minecraft:light[level=13]
fill 441 210 638 447 211 641 minecraft:yellow_concrete
setblock 442 210 607 minecraft:light[level=13]
setblock 442 210 615 minecraft:light[level=13]
setblock 442 210 623 minecraft:light[level=13]
setblock 442 210 631 minecraft:light[level=13]
fill 442 210 637 447 211 637 minecraft:yellow_concrete
fill 442 210 642 446 211 642 minecraft:yellow_concrete
fill 443 210 636 446 211 636 minecraft:yellow_concrete
setblock 450 210 607 minecraft:light[level=13]
setblock 450 210 615 minecraft:light[level=13]
setblock 450 210 623 minecraft:light[level=13]
setblock 450 210 631 minecraft:light[level=13]
setblock 450 210 639 minecraft:light[level=13]
setblock 458 210 607 minecraft:light[level=13]
setblock 458 210 615 minecraft:light[level=13]
setblock 458 210 623 minecraft:light[level=13]
setblock 458 210 631 minecraft:light[level=13]
setblock 458 210 639 minecraft:light[level=13]
fill 463 210 607 464 210 643 minecraft:quartz_block
fill 424 211 605 424 211 645 minecraft:quartz_block
fill 425 211 605 464 211 605 minecraft:quartz_block
fill 425 211 645 464 211 645 minecraft:quartz_block
fill 464 211 606 464 211 644 minecraft:quartz_block
fill 424 212 611 424 240 612 minecraft:quartz_block
fill 424 212 619 424 240 620 minecraft:quartz_block
fill 424 212 627 424 240 628 minecraft:quartz_block
fill 424 212 635 424 240 636 minecraft:quartz_block
fill 424 212 643 424 240 644 minecraft:quartz_block
fill 425 212 605 426 240 605 minecraft:quartz_block
fill 430 212 645 431 240 645 minecraft:quartz_block
fill 433 212 605 434 240 605 minecraft:quartz_block
fill 438 212 645 439 240 645 minecraft:quartz_block
fill 441 212 605 442 240 605 minecraft:quartz_block
fill 441 212 638 447 212 640 minecraft:yellow_concrete
fill 442 212 637 446 212 637 minecraft:yellow_concrete
fill 442 212 641 446 212 641 minecraft:yellow_concrete
fill 443 212 636 445 212 636 minecraft:yellow_concrete
fill 443 212 642 445 212 642 minecraft:yellow_concrete
fill 446 212 645 447 240 645 minecraft:quartz_block
fill 449 212 605 450 240 605 minecraft:quartz_block
fill 454 212 645 455 240 645 minecraft:quartz_block
fill 457 212 605 458 240 605 minecraft:quartz_block
fill 462 212 645 463 240 645 minecraft:quartz_block
fill 464 212 606 464 240 607 minecraft:quartz_block
fill 464 212 614 464 240 615 minecraft:quartz_block
fill 464 212 622 464 240 623 minecraft:quartz_block
fill 464 212 630 464 240 631 minecraft:quartz_block
fill 464 212 638 464 240 639 minecraft:quartz_block
fill 442 213 638 446 213 640 minecraft:yellow_concrete
fill 443 213 637 445 213 637 minecraft:yellow_concrete
fill 443 213 641 446 213 641 minecraft:yellow_concrete
fill 423 214 609 423 219 609 minecraft:pearlescent_froglight
fill 423 214 617 423 219 617 minecraft:pearlescent_froglight
fill 423 214 625 423 219 625 minecraft:pearlescent_froglight
fill 423 214 633 423 219 633 minecraft:pearlescent_froglight
fill 423 214 641 423 219 641 minecraft:pearlescent_froglight
fill 426 214 646 426 219 646 minecraft:pearlescent_froglight
fill 430 214 604 430 219 604 minecraft:pearlescent_froglight
fill 433 214 614 435 215 614 minecraft:gold_block
fill 434 214 613 434 215 613 minecraft:gold_block
fill 434 214 615 434 215 615 minecraft:gold_block
fill 434 214 646 434 219 646 minecraft:pearlescent_froglight
fill 438 214 604 438 219 604 minecraft:pearlescent_froglight
fill 442 214 646 442 219 646 minecraft:pearlescent_froglight
fill 443 214 639 445 214 639 minecraft:yellow_concrete
setblock 444 214 638 minecraft:yellow_concrete
setblock 444 214 640 minecraft:yellow_concrete
fill 446 214 604 446 219 604 minecraft:pearlescent_froglight
fill 450 214 646 450 219 646 minecraft:pearlescent_froglight
fill 454 214 604 454 219 604 minecraft:pearlescent_froglight
fill 458 214 646 458 219 646 minecraft:pearlescent_froglight
fill 462 214 604 462 219 604 minecraft:pearlescent_froglight
fill 465 214 609 465 219 609 minecraft:pearlescent_froglight
fill 465 214 617 465 219 617 minecraft:pearlescent_froglight
fill 465 214 625 465 219 625 minecraft:pearlescent_froglight
fill 465 214 633 465 219 633 minecraft:pearlescent_froglight
fill 465 214 641 465 219 641 minecraft:pearlescent_froglight
setblock 426 218 607 minecraft:light[level=13]
setblock 426 218 615 minecraft:light[level=13]
setblock 426 218 623 minecraft:light[level=13]
setblock 426 218 631 minecraft:light[level=13]
setblock 426 218 639 minecraft:light[level=13]
setblock 434 218 607 minecraft:light[level=13]
setblock 434 218 615 minecraft:light[level=13]
setblock 434 218 623 minecraft:light[level=13]
setblock 434 218 631 minecraft:light[level=13]
setblock 434 218 639 minecraft:light[level=13]
setblock 442 218 607 minecraft:light[level=13]
setblock 442 218 615 minecraft:light[level=13]
setblock 442 218 623 minecraft:light[level=13]
setblock 442 218 631 minecraft:light[level=13]
setblock 442 218 639 minecraft:light[level=13]
fill 446 218 636 446 219 637 minecraft:white_concrete
setblock 450 218 607 minecraft:light[level=13]
setblock 450 218 615 minecraft:light[level=13]
setblock 450 218 623 minecraft:light[level=13]
setblock 450 218 631 minecraft:light[level=13]
setblock 450 218 639 minecraft:light[level=13]
setblock 458 218 607 minecraft:light[level=13]
setblock 458 218 615 minecraft:light[level=13]
setblock 458 218 623 minecraft:light[level=13]
setblock 458 218 631 minecraft:light[level=13]
setblock 458 218 639 minecraft:light[level=13]
fill 455 219 623 461 221 629 minecraft:stone
fill 423 220 609 423 227 609 minecraft:light_gray_concrete
fill 423 220 617 423 227 617 minecraft:light_gray_concrete
fill 423 220 625 423 227 625 minecraft:light_gray_concrete
fill 423 220 633 423 227 633 minecraft:light_gray_concrete
fill 423 220 641 423 227 641 minecraft:light_gray_concrete
fill 426 220 646 426 227 646 minecraft:light_gray_concrete
fill 430 220 604 430 227 604 minecraft:light_gray_concrete
fill 434 220 646 434 227 646 minecraft:light_gray_concrete
fill 438 220 604 438 227 604 minecraft:light_gray_concrete
fill 442 220 646 442 227 646 minecraft:light_gray_concrete
fill 446 220 604 446 227 604 minecraft:light_gray_concrete
fill 450 220 646 450 227 646 minecraft:light_gray_concrete
fill 454 220 604 454 227 604 minecraft:light_gray_concrete
fill 458 220 646 458 227 646 minecraft:light_gray_concrete
fill 462 220 604 462 227 604 minecraft:light_gray_concrete
fill 465 220 609 465 227 609 minecraft:light_gray_concrete
fill 465 220 617 465 227 617 minecraft:light_gray_concrete
fill 465 220 625 465 227 625 minecraft:light_gray_concrete
fill 465 220 633 465 227 633 minecraft:light_gray_concrete
fill 465 220 641 465 227 641 minecraft:light_gray_concrete
fill 452 222 618 453 223 618 minecraft:white_concrete
fill 455 222 623 461 224 629 minecraft:dirt
fill 435 223 621 435 224 621 minecraft:white_concrete
fill 452 223 632 452 224 633 minecraft:black_concrete
fill 424 224 605 424 225 610 minecraft:quartz_block
fill 424 224 613 425 224 618 minecraft:quartz_block
fill 424 224 621 426 224 626 minecraft:quartz_block
fill 424 224 629 425 224 634 minecraft:quartz_block
fill 424 224 637 425 224 642 minecraft:quartz_block
fill 424 224 645 429 225 645 minecraft:quartz_block
fill 425 224 606 425 224 612 minecraft:quartz_block
fill 425 224 619 425 224 620 minecraft:quartz_block
fill 425 224 627 426 224 628 minecraft:quartz_block
fill 425 224 635 425 224 636 minecraft:quartz_block
fill 425 224 643 425 224 644 minecraft:quartz_block
fill 426 224 606 463 224 606 minecraft:quartz_block
fill 426 224 629 427 224 629 minecraft:quartz_block
fill 426 224 644 464 224 644 minecraft:quartz_block
fill 427 224 605 432 225 605 minecraft:quartz_block
fill 427 224 618 427 225 621 minecraft:quartz_block
fill 427 224 630 427 224 632 minecraft:quartz_block
fill 428 224 616 428 225 618 minecraft:quartz_block
fill 428 224 632 428 225 634 minecraft:quartz_block
fill 429 224 614 429 225 616 minecraft:quartz_block
fill 429 224 634 429 225 636 minecraft:quartz_block
fill 430 224 613 430 225 614 minecraft:quartz_block
fill 430 224 636 430 225 637 minecraft:quartz_block
fill 431 224 612 431 225 613 minecraft:quartz_block
fill 431 224 637 431 225 638 minecraft:quartz_block
fill 432 224 611 432 225 612 minecraft:quartz_block
fill 432 224 638 432 225 639 minecraft:quartz_block
fill 432 224 645 437 225 645 minecraft:quartz_block
fill 433 224 610 433 225 611 minecraft:quartz_block
fill 433 224 639 433 225 640 minecraft:quartz_block
fill 434 224 610 435 225 610 minecraft:quartz_block
fill 434 224 640 435 225 640 minecraft:quartz_block
fill 435 224 605 440 225 605 minecraft:quartz_block
fill 435 224 609 437 225 609 minecraft:quartz_block
fill 435 224 641 437 225 641 minecraft:quartz_block
fill 437 224 608 440 225 608 minecraft:quartz_block
fill 437 224 642 440 225 642 minecraft:quartz_block
fill 440 224 607 448 225 607 minecraft:quartz_block
fill 440 224 643 448 225 643 minecraft:quartz_block
fill 440 224 645 445 225 645 minecraft:quartz_block
fill 443 224 605 448 225 605 minecraft:quartz_block
fill 448 224 608 451 225 608 minecraft:quartz_block
fill 448 224 642 451 225 642 minecraft:quartz_block
fill 448 224 645 453 225 645 minecraft:quartz_block
fill 451 224 605 456 225 605 minecraft:quartz_block
fill 451 224 609 453 225 609 minecraft:quartz_block
fill 451 224 641 453 225 641 minecraft:quartz_block
fill 453 224 610 455 225 610 minecraft:quartz_block
fill 453 224 640 455 225 640 minecraft:quartz_block
fill 455 224 611 456 225 611 minecraft:quartz_block
fill 455 224 639 456 225 639 minecraft:quartz_block
fill 456 224 612 457 225 612 minecraft:quartz_block
fill 456 224 638 457 225 638 minecraft:quartz_block
fill 456 224 645 461 225 645 minecraft:quartz_block
fill 457 224 613 458 225 613 minecraft:quartz_block
fill 457 224 637 458 225 637 minecraft:quartz_block
fill 458 224 614 459 225 614 minecraft:quartz_block
fill 458 224 636 459 225 636 minecraft:quartz_block
fill 459 224 605 464 225 605 minecraft:quartz_block
fill 459 224 615 459 225 616 minecraft:quartz_block
fill 459 224 634 459 225 635 minecraft:quartz_block
fill 460 224 616 460 225 618 minecraft:quartz_block
fill 460 224 632 460 225 634 minecraft:quartz_block
fill 461 224 618 461 225 621 minecraft:quartz_block
fill 461 224 630 461 225 632 minecraft:quartz_block
fill 462 224 621 463 224 629 minecraft:quartz_block
fill 463 224 607 463 224 620 minecraft:quartz_block
fill 463 224 630 463 224 643 minecraft:quartz_block
fill 464 224 608 464 225 613 minecraft:quartz_block
fill 464 224 616 464 225 621 minecraft:quartz_block
fill 464 224 624 464 225 629 minecraft:quartz_block
fill 464 224 632 464 225 637 minecraft:quartz_block
fill 464 224 640 464 225 643 minecraft:quartz_block
fill 464 224 645 464 225 645 minecraft:quartz_block
fill 424 225 613 424 225 618 minecraft:quartz_block
fill 424 225 621 424 225 626 minecraft:quartz_block
fill 424 225 629 424 225 634 minecraft:quartz_block
fill 424 225 637 424 225 642 minecraft:quartz_block
fill 426 225 621 426 225 629 minecraft:quartz_block
fill 427 225 625 433 227 631 minecraft:stone
setblock 427 225 632 minecraft:quartz_block
fill 455 225 623 461 225 629 minecraft:moss_block
fill 462 225 621 462 225 629 minecraft:quartz_block
setblock 464 225 644 minecraft:quartz_block
setblock 426 226 607 minecraft:light[level=13]
setblock 426 226 615 minecraft:light[level=13]
setblock 426 226 623 minecraft:light[level=13]
setblock 426 226 631 minecraft:light[level=13]
setblock 426 226 639 minecraft:light[level=13]
setblock 431 226 612 minecraft:pearlescent_froglight
setblock 432 226 611 minecraft:pearlescent_froglight
setblock 433 226 610 minecraft:pearlescent_froglight
setblock 434 226 607 minecraft:light[level=13]
fill 434 226 609 435 226 609 minecraft:pearlescent_froglight
setblock 434 226 615 minecraft:light[level=13]
setblock 434 226 623 minecraft:light[level=13]
setblock 434 226 631 minecraft:light[level=13]
setblock 434 226 639 minecraft:light[level=13]
setblock 442 226 607 minecraft:light[level=13]
setblock 442 226 615 minecraft:light[level=13]
setblock 442 226 623 minecraft:light[level=13]
setblock 442 226 631 minecraft:light[level=13]
setblock 442 226 639 minecraft:light[level=13]
setblock 450 226 607 minecraft:light[level=13]
setblock 450 226 615 minecraft:light[level=13]
setblock 450 226 623 minecraft:light[level=13]
setblock 450 226 631 minecraft:light[level=13]
setblock 450 226 639 minecraft:light[level=13]
setblock 458 226 607 minecraft:light[level=13]
setblock 458 226 615 minecraft:light[level=13]
setblock 458 226 623 minecraft:light[level=13]
setblock 458 226 631 minecraft:light[level=13]
setblock 458 226 639 minecraft:light[level=13]
fill 423 228 609 423 233 609 minecraft:pearlescent_froglight
fill 423 228 617 423 233 617 minecraft:pearlescent_froglight
fill 423 228 625 423 233 625 minecraft:pearlescent_froglight
fill 423 228 633 423 233 633 minecraft:pearlescent_froglight
fill 423 228 641 423 233 641 minecraft:pearlescent_froglight
fill 426 228 646 426 233 646 minecraft:pearlescent_froglight
fill 427 228 625 433 230 631 minecraft:dirt
fill 430 228 604 430 233 604 minecraft:pearlescent_froglight
fill 434 228 646 434 233 646 minecraft:pearlescent_froglight
fill 438 228 604 438 233 604 minecraft:pearlescent_froglight
fill 442 228 646 442 233 646 minecraft:pearlescent_froglight
fill 446 228 604 446 233 604 minecraft:pearlescent_froglight
fill 450 228 646 450 233 646 minecraft:pearlescent_froglight
fill 454 228 604 454 233 604 minecraft:pearlescent_froglight
fill 458 228 646 458 233 646 minecraft:pearlescent_froglight
fill 462 228 604 462 233 604 minecraft:pearlescent_froglight
fill 465 228 609 465 233 609 minecraft:pearlescent_froglight
fill 465 228 617 465 233 617 minecraft:pearlescent_froglight
fill 465 228 625 465 233 625 minecraft:pearlescent_froglight
fill 465 228 633 465 233 633 minecraft:pearlescent_froglight
fill 465 228 641 465 233 641 minecraft:pearlescent_froglight
fill 426 230 621 426 231 629 minecraft:quartz_block
fill 427 230 618 427 231 621 minecraft:quartz_block
fill 427 230 632 428 231 632 minecraft:quartz_block
fill 428 230 616 428 231 618 minecraft:quartz_block
fill 428 230 633 428 231 634 minecraft:quartz_block
fill 429 230 614 429 231 616 minecraft:quartz_block
fill 429 230 634 429 231 636 minecraft:quartz_block
fill 430 230 613 430 231 614 minecraft:quartz_block
fill 430 230 636 430 231 637 minecraft:quartz_block
fill 431 230 612 431 231 613 minecraft:quartz_block
fill 431 230 637 431 231 638 minecraft:quartz_block
fill 432 230 611 432 231 612 minecraft:quartz_block
fill 432 230 633 432 231 634 minecraft:black_concrete
fill 432 230 638 432 231 639 minecraft:quartz_block
fill 433 230 610 433 231 611 minecraft:quartz_block
fill 433 230 639 433 231 640 minecraft:quartz_block
fill 434 230 610 435 231 610 minecraft:quartz_block
fill 434 230 640 435 231 640 minecraft:quartz_block
fill 435 230 609 437 231 609 minecraft:quartz_block
fill 435 230 641 437 231 641 minecraft:quartz_block
fill 437 230 608 440 231 608 minecraft:quartz_block
fill 437 230 642 440 231 642 minecraft:quartz_block
fill 440 230 607 448 231 607 minecraft:quartz_block
fill 440 230 643 448 231 643 minecraft:quartz_block
fill 448 230 608 451 230 608 minecraft:quartz_block
fill 448 230 642 451 231 642 minecraft:quartz_block
fill 451 230 609 453 231 609 minecraft:quartz_block
fill 451 230 641 453 231 641 minecraft:quartz_block
fill 453 230 610 455 231 610 minecraft:quartz_block
fill 453 230 640 455 231 640 minecraft:quartz_block
fill 455 230 611 456 231 611 minecraft:quartz_block
fill 455 230 639 456 231 639 minecraft:quartz_block
fill 456 230 612 457 231 612 minecraft:quartz_block
fill 456 230 638 457 231 638 minecraft:quartz_block
fill 457 230 613 458 231 613 minecraft:quartz_block
fill 457 230 625 459 233 626 minecraft:oak_leaves[persistent=true]
fill 457 230 637 458 231 637 minecraft:quartz_block
fill 458 230 614 459 231 614 minecraft:quartz_block
fill 458 230 627 459 233 627 minecraft:oak_leaves[persistent=true]
fill 458 230 636 459 231 636 minecraft:quartz_block
fill 459 230 615 459 231 616 minecraft:quartz_block
fill 459 230 634 459 231 635 minecraft:quartz_block
fill 460 230 616 460 231 618 minecraft:quartz_block
fill 460 230 626 460 233 626 minecraft:oak_leaves[persistent=true]
fill 460 230 632 460 231 634 minecraft:quartz_block
fill 461 230 618 461 231 621 minecraft:quartz_block
fill 461 230 629 461 231 632 minecraft:quartz_block
fill 462 230 621 462 231 629 minecraft:quartz_block
fill 427 231 625 433 231 631 minecraft:moss_block
fill 428 231 624 430 232 624 minecraft:gold_block
fill 434 231 612 435 232 613 minecraft:white_concrete
fill 442 231 608 448 233 614 minecraft:stone
fill 449 231 608 451 231 608 minecraft:quartz_block
fill 457 231 627 457 232 627 minecraft:oak_leaves[persistent=true]
fill 458 231 624 459 232 624 minecraft:oak_leaves[persistent=true]
fill 460 231 625 460 232 625 minecraft:oak_leaves[persistent=true]
fill 460 231 627 460 232 627 minecraft:oak_leaves[persistent=true]
fill 428 232 625 430 232 625 minecraft:gold_block
fill 430 232 628 430 236 628 minecraft:oak_log
fill 423 234 609 423 247 609 minecraft:light_gray_concrete
fill 423 234 617 423 247 617 minecraft:light_gray_concrete
fill 423 234 625 423 244 625 minecraft:light_gray_concrete
fill 423 234 633 423 245 633 minecraft:light_gray_concrete
fill 423 234 641 423 247 641 minecraft:light_gray_concrete
setblock 426 234 607 minecraft:light[level=13]
setblock 426 234 615 minecraft:light[level=13]
setblock 426 234 623 minecraft:light[level=13]
setblock 426 234 631 minecraft:light[level=13]
setblock 426 234 639 minecraft:light[level=13]
fill 426 234 646 426 244 646 minecraft:light_gray_concrete
fill 430 234 604 430 245 604 minecraft:light_gray_concrete
setblock 434 234 607 minecraft:light[level=13]
setblock 434 234 615 minecraft:light[level=13]
setblock 434 234 623 minecraft:light[level=13]
setblock 434 234 631 minecraft:light[level=13]
setblock 434 234 639 minecraft:light[level=13]
fill 434 234 646 434 247 646 minecraft:light_gray_concrete
fill 438 234 604 438 247 604 minecraft:light_gray_concrete
setblock 442 234 607 minecraft:light[level=13]
fill 442 234 608 448 236 614 minecraft:dirt
setblock 442 234 615 minecraft:light[level=13]
setblock 442 234 623 minecraft:light[level=13]
setblock 442 234 631 minecraft:light[level=13]
setblock 442 234 639 minecraft:light[level=13]
fill 442 234 646 442 247 646 minecraft:light_gray_concrete
fill 446 234 604 446 247 604 minecraft:light_gray_concrete
setblock 450 234 607 minecraft:light[level=13]
setblock 450 234 615 minecraft:light[level=13]
setblock 450 234 623 minecraft:light[level=13]
setblock 450 234 631 minecraft:light[level=13]
setblock 450 234 639 minecraft:light[level=13]
fill 450 234 646 450 247 646 minecraft:light_gray_concrete
fill 454 234 604 454 247 604 minecraft:light_gray_concrete
setblock 458 234 607 minecraft:light[level=13]
setblock 458 234 615 minecraft:light[level=13]
setblock 458 234 623 minecraft:light[level=13]
setblock 458 234 631 minecraft:light[level=13]
setblock 458 234 639 minecraft:light[level=13]
fill 458 234 646 458 247 646 minecraft:light_gray_concrete
fill 462 234 604 462 247 604 minecraft:light_gray_concrete
fill 465 234 609 465 243 609 minecraft:light_gray_concrete
fill 465 234 617 465 247 617 minecraft:light_gray_concrete
fill 465 234 625 465 247 625 minecraft:light_gray_concrete
fill 465 234 633 465 247 633 minecraft:light_gray_concrete
fill 465 234 641 465 247 641 minecraft:light_gray_concrete
fill 429 236 627 429 239 629 minecraft:oak_leaves[persistent=true]
fill 430 236 627 430 239 627 minecraft:oak_leaves[persistent=true]
fill 430 236 629 431 239 629 minecraft:oak_leaves[persistent=true]
fill 431 236 628 431 239 628 minecraft:oak_leaves[persistent=true]
fill 428 237 628 428 238 629 minecraft:oak_leaves[persistent=true]
fill 429 237 630 431 238 630 minecraft:oak_leaves[persistent=true]
fill 430 237 628 430 239 628 minecraft:oak_leaves[persistent=true]
fill 431 237 627 431 238 627 minecraft:oak_leaves[persistent=true]
fill 442 237 608 448 237 614 minecraft:moss_block
fill 424 238 605 424 239 610 minecraft:quartz_block
fill 424 238 613 425 238 618 minecraft:quartz_block
fill 424 238 621 425 238 626 minecraft:quartz_block
fill 424 238 629 425 238 634 minecraft:quartz_block
fill 424 238 637 425 238 642 minecraft:quartz_block
fill 424 238 645 429 239 645 minecraft:quartz_block
fill 425 238 606 425 238 612 minecraft:quartz_block
fill 425 238 619 425 238 620 minecraft:quartz_block
fill 425 238 627 425 238 628 minecraft:quartz_block
fill 425 238 635 425 238 636 minecraft:quartz_block
fill 425 238 643 425 238 644 minecraft:quartz_block
fill 426 238 606 463 238 606 minecraft:quartz_block
fill 426 238 644 464 238 644 minecraft:quartz_block
fill 427 238 605 432 239 605 minecraft:quartz_block
fill 432 238 645 437 239 645 minecraft:quartz_block
fill 434 238 634 434 239 635 minecraft:gold_block
fill 435 238 605 440 239 605 minecraft:quartz_block
fill 440 238 645 445 239 645 minecraft:quartz_block
fill 443 238 605 448 239 605 minecraft:quartz_block
fill 445 238 610 445 240 611 minecraft:oak_log
fill 448 238 645 453 239 645 minecraft:quartz_block
fill 451 238 605 456 239 605 minecraft:quartz_block
fill 456 238 645 461 239 645 minecraft:quartz_block
fill 459 238 605 464 239 605 minecraft:quartz_block
fill 463 238 607 463 238 643 minecraft:quartz_block
fill 464 238 608 464 239 613 minecraft:quartz_block
fill 464 238 616 464 239 621 minecraft:quartz_block
fill 464 238 624 464 239 629 minecraft:quartz_block
fill 464 238 632 464 239 637 minecraft:quartz_block
fill 464 238 640 464 239 643 minecraft:quartz_block
fill 464 238 645 464 239 645 minecraft:quartz_block
fill 424 239 613 424 239 618 minecraft:quartz_block
fill 424 239 621 424 239 626 minecraft:quartz_block
fill 424 239 629 424 239 634 minecraft:quartz_block
fill 424 239 637 424 239 642 minecraft:quartz_block
fill 450 239 633 451 240 634 minecraft:black_concrete
setblock 464 239 644 minecraft:quartz_block
setblock 426 242 607 minecraft:light[level=13]
setblock 426 242 615 minecraft:light[level=13]
setblock 426 242 623 minecraft:light[level=13]
setblock 426 242 631 minecraft:light[level=13]
setblock 426 242 639 minecraft:light[level=13]
setblock 434 242 607 minecraft:light[level=13]
setblock 434 242 615 minecraft:light[level=13]
setblock 434 242 623 minecraft:light[level=13]
setblock 434 242 631 minecraft:light[level=13]
setblock 434 242 639 minecraft:light[level=13]
setblock 442 242 607 minecraft:light[level=13]
setblock 442 242 615 minecraft:light[level=13]
setblock 442 242 623 minecraft:light[level=13]
setblock 442 242 631 minecraft:light[level=13]
setblock 442 242 639 minecraft:light[level=13]
setblock 450 242 607 minecraft:light[level=13]
setblock 450 242 615 minecraft:light[level=13]
setblock 450 242 623 minecraft:light[level=13]
setblock 450 242 631 minecraft:light[level=13]
setblock 450 242 639 minecraft:light[level=13]
setblock 458 242 607 minecraft:light[level=13]
setblock 458 242 615 minecraft:light[level=13]
setblock 458 242 623 minecraft:light[level=13]
setblock 458 242 631 minecraft:light[level=13]
setblock 458 242 639 minecraft:light[level=13]
fill 423 244 604 424 244 604 minecraft:white_concrete
setblock 423 244 606 minecraft:white_concrete
fill 423 244 607 423 244 608 minecraft:light_gray_concrete
setblock 423 244 613 minecraft:white_concrete
fill 423 244 618 423 244 620 minecraft:light_gray_concrete
setblock 423 244 621 minecraft:white_concrete
fill 423 244 622 423 245 624 minecraft:light_gray_concrete
fill 423 244 627 423 245 627 minecraft:light_gray_concrete
setblock 423 244 628 minecraft:white_concrete
fill 423 244 629 423 244 631 minecraft:light_gray_concrete
setblock 423 244 632 minecraft:white_concrete
setblock 423 244 642 minecraft:white_concrete
fill 425 244 604 428 245 604 minecraft:light_gray_concrete
fill 427 244 646 428 245 646 minecraft:light_gray_concrete
setblock 429 244 646 minecraft:white_concrete
fill 430 244 646 430 247 646 minecraft:light_gray_concrete
setblock 431 244 646 minecraft:white_concrete
setblock 448 244 604 minecraft:white_concrete
setblock 456 244 646 minecraft:light_gray_concrete
fill 457 244 646 457 245 646 minecraft:white_concrete
fill 465 244 604 465 245 604 minecraft:white_concrete
setblock 465 244 609 minecraft:white_concrete
fill 465 244 612 465 247 612 minecraft:light_gray_concrete
setblock 465 244 613 minecraft:white_concrete
fill 465 244 614 465 247 614 minecraft:light_gray_concrete
setblock 465 244 634 minecraft:light_gray_concrete
setblock 465 244 635 minecraft:white_concrete
fill 465 244 636 465 247 637 minecraft:light_gray_concrete
fill 423 245 604 424 247 604 minecraft:light_gray_concrete
fill 423 245 606 423 245 607 minecraft:light_gray_concrete
setblock 423 245 608 minecraft:white_concrete
fill 423 245 613 423 247 613 minecraft:light_gray_concrete
fill 423 245 618 423 248 618 minecraft:light_gray_concrete
setblock 423 245 619 minecraft:white_concrete
fill 423 245 620 423 245 621 minecraft:light_gray_concrete
setblock 423 245 625 minecraft:white_concrete
fill 423 245 628 423 247 630 minecraft:light_gray_concrete
setblock 423 245 631 minecraft:white_concrete
fill 423 245 632 423 247 632 minecraft:light_gray_concrete
setblock 423 245 636 minecraft:white_concrete
fill 423 245 637 423 247 637 minecraft:light_gray_concrete
fill 423 245 642 423 247 642 minecraft:light_gray_concrete
setblock 423 245 643 minecraft:white_concrete
setblock 423 245 646 minecraft:white_concrete
setblock 426 245 646 minecraft:white_concrete
fill 429 245 646 429 247 646 minecraft:light_gray_concrete
fill 431 245 646 431 247 646 minecraft:light_gray_concrete
fill 436 245 622 438 245 624 minecraft:redstone_block
fill 437 245 629 439 245 631 minecraft:redstone_block
fill 443 245 621 445 245 623 minecraft:redstone_block
fill 443 245 629 445 245 631 minecraft:redstone_block
setblock 443 245 646 minecraft:white_concrete
fill 444 245 646 445 247 646 minecraft:light_gray_concrete
fill 447 245 646 447 246 646 minecraft:white_concrete
fill 448 245 604 448 247 604 minecraft:light_gray_concrete
fill 455 245 646 456 245 646 minecraft:white_concrete
fill 465 245 606 465 245 607 minecraft:white_concrete
fill 465 245 608 465 247 609 minecraft:light_gray_concrete
fill 465 245 613 465 247 613 minecraft:light_gray_concrete
fill 465 245 627 465 247 627 minecraft:light_gray_concrete
fill 465 245 628 465 245 629 minecraft:white_concrete
fill 465 245 630 465 247 632 minecraft:light_gray_concrete
setblock 465 245 634 minecraft:white_concrete
setblock 465 245 635 minecraft:light_gray_concrete
setblock 465 245 638 minecraft:white_concrete
setblock 465 245 642 minecraft:white_concrete
fill 423 246 606 423 246 607 minecraft:white_concrete
fill 423 246 608 423 247 608 minecraft:light_gray_concrete
fill 423 246 619 423 247 620 minecraft:light_gray_concrete
setblock 423 246 621 minecraft:white_concrete
fill 423 246 622 423 247 622 minecraft:light_gray_concrete
setblock 423 246 623 minecraft:white_concrete
fill 423 246 624 423 247 624 minecraft:light_gray_concrete
fill 423 246 625 439 246 627 minecraft:black_concrete
fill 423 246 631 423 247 631 minecraft:light_gray_concrete
setblock 423 246 633 minecraft:white_concrete
fill 423 246 636 423 247 636 minecraft:light_gray_concrete
fill 423 246 639 423 248 639 minecraft:light_gray_concrete
setblock 423 246 640 minecraft:white_concrete
fill 423 246 643 423 247 643 minecraft:light_gray_concrete
setblock 423 246 645 minecraft:white_concrete
fill 423 246 646 423 247 646 minecraft:light_gray_concrete
fill 425 246 604 425 247 604 minecraft:light_gray_concrete
setblock 426 246 604 minecraft:white_concrete
fill 426 246 646 426 247 646 minecraft:light_gray_concrete
fill 427 246 604 428 247 604 minecraft:light_gray_concrete
fill 427 246 646 428 246 646 minecraft:white_concrete
fill 429 246 604 430 246 604 minecraft:white_concrete
fill 435 246 646 438 247 646 minecraft:light_gray_concrete
fill 436 246 604 437 246 604 minecraft:white_concrete
setblock 439 246 646 minecraft:white_concrete
fill 440 246 607 442 246 624 minecraft:black_concrete
fill 440 246 628 442 246 645 minecraft:black_concrete
setblock 441 246 646 minecraft:white_concrete
fill 443 246 625 460 246 627 minecraft:black_concrete
fill 443 246 646 443 247 646 minecraft:light_gray_concrete
setblock 448 246 646 minecraft:white_concrete
fill 449 246 646 449 248 646 minecraft:light_gray_concrete
setblock 455 246 646 minecraft:white_concrete
fill 456 246 646 457 247 646 minecraft:light_gray_concrete
setblock 460 246 604 minecraft:white_concrete
fill 461 246 604 461 247 604 minecraft:light_gray_concrete
fill 465 246 604 465 247 604 minecraft:light_gray_concrete
fill 465 246 606 465 247 607 minecraft:light_gray_concrete
fill 465 246 619 465 247 622 minecraft:light_gray_concrete
setblock 465 246 623 minecraft:white_concrete
fill 465 246 628 465 247 629 minecraft:light_gray_concrete
fill 465 246 634 465 247 634 minecraft:light_gray_concrete
setblock 465 246 635 minecraft:white_concrete
fill 465 246 638 465 247 638 minecraft:light_gray_concrete
fill 465 246 642 465 249 642 minecraft:light_gray_concrete
fill 465 246 644 465 247 645 minecraft:light_gray_concrete
setblock 465 246 646 minecraft:white_concrete
fill 423 247 606 439 247 607 minecraft:light_gray_concrete
fill 423 247 621 434 247 621 minecraft:light_gray_concrete
fill 423 247 623 434 247 623 minecraft:light_gray_concrete
fill 423 247 625 434 247 625 minecraft:gold_block
fill 423 247 626 438 247 626 minecraft:black_concrete
fill 423 247 627 438 247 627 minecraft:gold_block
fill 423 247 633 436 247 633 minecraft:light_gray_concrete
fill 423 247 640 439 247 640 minecraft:light_gray_concrete
fill 423 247 645 439 247 645 minecraft:light_gray_concrete
fill 424 247 605 464 247 605 minecraft:light_gray_concrete
fill 424 247 608 436 247 620 minecraft:light_gray_concrete
fill 424 247 622 434 247 622 minecraft:light_gray_concrete
fill 424 247 624 434 247 624 minecraft:light_gray_concrete
fill 424 247 628 435 247 632 minecraft:light_gray_concrete
fill 424 247 634 438 247 639 minecraft:light_gray_concrete
fill 424 247 641 439 247 644 minecraft:light_gray_concrete
fill 426 247 604 426 249 604 minecraft:light_gray_concrete
fill 427 247 646 428 247 646 minecraft:light_gray_concrete
fill 429 247 604 430 247 604 minecraft:light_gray_concrete
fill 435 247 621 435 247 625 minecraft:pearlescent_froglight
fill 436 247 604 437 247 604 minecraft:light_gray_concrete
fill 436 247 621 438 247 621 minecraft:pearlescent_froglight
fill 436 247 622 438 247 624 minecraft:light_gray_concrete
fill 436 247 625 438 247 625 minecraft:pearlescent_froglight
fill 436 247 628 436 247 632 minecraft:pearlescent_froglight
fill 437 247 608 438 247 618 minecraft:light_gray_concrete
fill 437 247 619 445 258 620 minecraft:green_terracotta
fill 437 247 628 439 247 628 minecraft:pearlescent_froglight
fill 437 247 629 438 247 631 minecraft:light_gray_concrete
fill 437 247 632 445 258 633 minecraft:lime_terracotta
fill 439 247 608 439 247 617 minecraft:light_gray_concrete
fill 439 247 618 443 258 618 minecraft:green_terracotta
fill 439 247 621 443 258 621 minecraft:green_terracotta
fill 439 247 622 439 247 624 minecraft:pearlescent_froglight
fill 439 247 625 439 247 627 minecraft:verdant_froglight
fill 439 247 629 439 247 630 minecraft:light_gray_concrete
fill 439 247 631 443 258 631 minecraft:lime_terracotta
fill 439 247 634 443 258 634 minecraft:lime_terracotta
fill 439 247 635 439 247 639 minecraft:light_gray_concrete
setblock 439 247 646 minecraft:light_gray_concrete
fill 440 247 606 464 247 606 minecraft:light_gray_concrete
fill 440 247 607 440 247 617 minecraft:gold_block
fill 440 247 622 440 247 623 minecraft:gold_block
fill 440 247 624 442 247 624 minecraft:verdant_froglight
fill 440 247 628 442 247 628 minecraft:verdant_froglight
fill 440 247 629 440 247 630 minecraft:pearlescent_froglight
fill 440 247 635 440 247 645 minecraft:gold_block
fill 441 247 607 441 247 617 minecraft:black_concrete
fill 441 247 622 441 247 623 minecraft:black_concrete
fill 441 247 629 441 247 630 minecraft:black_concrete
fill 441 247 635 441 247 645 minecraft:black_concrete
fill 441 247 646 441 248 646 minecraft:light_gray_concrete
fill 442 247 607 442 247 617 minecraft:gold_block
fill 442 247 622 442 247 623 minecraft:pearlescent_froglight
fill 442 247 629 442 247 630 minecraft:pearlescent_froglight
fill 442 247 635 442 247 645 minecraft:gold_block
fill 443 247 607 464 247 617 minecraft:light_gray_concrete
fill 443 247 622 445 247 623 minecraft:light_gray_concrete
fill 443 247 624 446 247 624 minecraft:pearlescent_froglight
fill 443 247 625 443 247 627 minecraft:verdant_froglight
fill 443 247 628 446 247 628 minecraft:pearlescent_froglight
fill 443 247 629 445 247 630 minecraft:light_gray_concrete
fill 443 247 635 464 247 645 minecraft:light_gray_concrete
fill 444 247 618 464 247 618 minecraft:light_gray_concrete
fill 444 247 621 445 247 621 minecraft:light_gray_concrete
fill 444 247 625 460 247 625 minecraft:gold_block
fill 444 247 626 460 247 626 minecraft:black_concrete
fill 444 247 627 460 247 627 minecraft:gold_block
fill 444 247 631 445 247 631 minecraft:light_gray_concrete
fill 444 247 634 464 247 634 minecraft:light_gray_concrete
fill 446 247 619 464 247 619 minecraft:light_gray_concrete
fill 446 247 620 446 247 623 minecraft:pearlescent_froglight
fill 446 247 629 446 247 632 minecraft:pearlescent_froglight
fill 446 247 633 464 247 633 minecraft:light_gray_concrete
fill 447 247 620 464 247 624 minecraft:light_gray_concrete
fill 447 247 628 464 247 632 minecraft:light_gray_concrete
fill 447 247 646 448 247 646 minecraft:light_gray_concrete
setblock 455 247 646 minecraft:light_gray_concrete
setblock 460 247 604 minecraft:light_gray_concrete
fill 461 247 625 464 247 627 minecraft:light_gray_concrete
setblock 465 247 623 minecraft:light_gray_concrete
setblock 465 247 635 minecraft:light_gray_concrete
setblock 465 247 646 minecraft:light_gray_concrete
setblock 423 248 604 minecraft:light_gray_concrete
fill 423 248 605 423 307 606 minecraft:white_concrete
setblock 423 248 607 minecraft:light_gray_concrete
fill 423 248 608 423 248 617 minecraft:white_concrete
fill 423 248 619 423 248 620 minecraft:white_concrete
setblock 423 248 621 minecraft:light_gray_concrete
fill 423 248 622 423 248 638 minecraft:white_concrete
fill 423 248 640 423 249 646 minecraft:white_concrete
fill 424 248 604 425 307 604 minecraft:white_concrete
fill 424 248 646 439 255 646 minecraft:white_concrete
fill 427 248 604 428 307 604 minecraft:white_concrete
setblock 429 248 604 minecraft:light_gray_concrete
fill 430 248 604 436 248 604 minecraft:white_concrete
fill 435 248 618 436 257 621 minecraft:green_terracotta
fill 435 248 631 436 257 634 minecraft:lime_terracotta
setblock 437 248 604 minecraft:light_gray_concrete
fill 437 248 618 438 258 618 minecraft:green_terracotta
fill 437 248 621 438 258 621 minecraft:green_terracotta
fill 437 248 631 438 258 631 minecraft:lime_terracotta
fill 437 248 634 438 258 634 minecraft:lime_terracotta
fill 438 248 604 444 248 604 minecraft:white_concrete
fill 438 248 617 444 257 617 minecraft:green_terracotta
fill 438 248 622 444 255 622 minecraft:green_terracotta
fill 438 248 630 444 255 630 minecraft:lime_terracotta
fill 438 248 635 444 257 635 minecraft:lime_terracotta
fill 442 248 646 448 248 646 minecraft:white_concrete
fill 444 248 618 447 257 618 minecraft:green_terracotta
fill 444 248 621 447 257 621 minecraft:green_terracotta
fill 444 248 631 447 257 631 minecraft:lime_terracotta
fill 444 248 634 447 257 634 minecraft:lime_terracotta
fill 446 248 604 455 248 604 minecraft:white_concrete
fill 446 248 619 447 257 620 minecraft:green_terracotta
fill 446 248 632 447 257 633 minecraft:lime_terracotta
fill 450 248 646 465 248 646 minecraft:white_concrete
setblock 456 248 604 minecraft:light_gray_concrete
fill 457 248 604 465 248 604 minecraft:white_concrete
fill 465 248 605 465 248 617 minecraft:white_concrete
fill 465 248 619 465 307 621 minecraft:white_concrete
setblock 465 248 622 minecraft:light_gray_concrete
fill 465 248 623 465 249 641 minecraft:white_concrete
fill 465 248 644 465 307 645 minecraft:white_concrete
fill 423 249 604 423 307 604 minecraft:white_concrete
fill 423 249 607 423 255 612 minecraft:white_concrete
setblock 423 249 613 minecraft:light_gray_concrete
fill 423 249 614 423 249 618 minecraft:white_concrete
setblock 423 249 619 minecraft:light_gray_concrete
fill 423 249 620 423 249 628 minecraft:white_concrete
setblock 423 249 629 minecraft:light_gray_concrete
fill 423 249 630 423 255 634 minecraft:white_concrete
setblock 423 249 635 minecraft:light_gray_concrete
fill 423 249 636 423 307 639 minecraft:white_concrete
fill 429 249 604 430 255 604 minecraft:white_concrete
fill 431 249 604 431 250 604 minecraft:light_gray_concrete
fill 432 249 604 442 249 604 minecraft:white_concrete
fill 433 249 619 434 257 620 minecraft:green_terracotta
fill 433 249 632 434 257 633 minecraft:lime_terracotta
fill 434 249 618 434 257 618 minecraft:green_terracotta
fill 434 249 621 434 257 621 minecraft:green_terracotta
fill 434 249 631 434 257 631 minecraft:lime_terracotta
fill 434 249 634 434 257 634 minecraft:lime_terracotta
fill 435 249 617 437 256 617 minecraft:green_terracotta
fill 435 249 622 437 256 622 minecraft:green_terracotta
fill 435 249 630 437 256 630 minecraft:lime_terracotta
fill 435 249 635 437 256 635 minecraft:lime_terracotta
fill 440 249 616 442 256 616 minecraft:green_terracotta
fill 440 249 623 442 251 623 minecraft:green_terracotta
fill 440 249 629 442 251 629 minecraft:lime_terracotta
fill 440 249 636 442 256 636 minecraft:lime_terracotta
fill 440 249 646 441 249 646 minecraft:white_concrete
setblock 442 249 646 minecraft:light_gray_concrete
setblock 443 249 604 minecraft:light_gray_concrete
fill 443 249 646 445 307 646 minecraft:white_concrete
fill 444 249 604 445 307 604 minecraft:white_concrete
fill 445 249 617 447 256 617 minecraft:green_terracotta
fill 445 249 622 447 256 622 minecraft:green_terracotta
fill 445 249 630 447 256 630 minecraft:lime_terracotta
fill 445 249 635 447 256 635 minecraft:lime_terracotta
setblock 446 249 604 minecraft:light_gray_concrete
setblock 446 249 646 minecraft:light_gray_concrete
fill 447 249 604 459 249 604 minecraft:white_concrete
fill 447 249 646 447 307 646 minecraft:white_concrete
fill 448 249 618 448 257 621 minecraft:green_terracotta
fill 448 249 631 448 257 634 minecraft:lime_terracotta
setblock 448 249 646 minecraft:light_gray_concrete
fill 449 249 619 449 257 620 minecraft:green_terracotta
fill 449 249 632 449 257 633 minecraft:lime_terracotta
fill 449 249 646 454 249 646 minecraft:white_concrete
setblock 455 249 646 minecraft:light_gray_concrete
fill 456 249 646 456 307 646 minecraft:white_concrete
fill 457 249 646 457 250 646 minecraft:light_gray_concrete
fill 458 249 646 465 249 646 minecraft:white_concrete
setblock 460 249 604 minecraft:light_gray_concrete
fill 461 249 604 465 255 604 minecraft:white_concrete
fill 465 249 605 465 249 607 minecraft:white_concrete
fill 465 249 608 465 249 609 minecraft:light_gray_concrete
fill 465 249 610 465 307 612 minecraft:white_concrete
setblock 465 249 613 minecraft:light_gray_concrete
fill 465 249 614 465 249 618 minecraft:white_concrete
fill 465 249 622 465 307 622 minecraft:white_concrete
fill 465 249 643 465 307 643 minecraft:white_concrete
fill 423 250 613 423 307 613 minecraft:white_concrete
setblock 423 250 614 minecraft:light_gray_concrete
fill 423 250 615 423 255 622 minecraft:white_concrete
setblock 423 250 623 minecraft:light_gray_concrete
fill 423 250 624 423 255 629 minecraft:white_concrete
fill 423 250 635 423 307 635 minecraft:white_concrete
fill 423 250 640 423 255 643 minecraft:white_concrete
setblock 423 250 644 minecraft:light_gray_concrete
fill 423 250 645 423 307 646 minecraft:white_concrete
fill 426 250 604 426 307 604 minecraft:white_concrete
setblock 426 250 607 minecraft:light[level=13]
setblock 426 250 615 minecraft:light[level=13]
setblock 426 250 623 minecraft:light[level=13]
setblock 426 250 631 minecraft:light[level=13]
setblock 426 250 639 minecraft:light[level=13]
fill 432 250 604 437 307 604 minecraft:white_concrete
fill 432 250 618 432 255 621 minecraft:green_terracotta
fill 432 250 631 432 255 634 minecraft:lime_terracotta
fill 433 250 618 433 256 618 minecraft:green_terracotta
fill 433 250 621 433 256 621 minecraft:green_terracotta
fill 433 250 631 433 256 631 minecraft:lime_terracotta
fill 433 250 634 433 256 634 minecraft:lime_terracotta
setblock 434 250 607 minecraft:light[level=13]
setblock 434 250 615 minecraft:light[level=13]
fill 434 250 617 434 256 617 minecraft:green_terracotta
fill 434 250 622 434 256 622 minecraft:green_terracotta
setblock 434 250 623 minecraft:light[level=13]
fill 434 250 630 434 256 630 minecraft:lime_terracotta
fill 434 250 635 434 256 635 minecraft:lime_terracotta
setblock 434 250 639 minecraft:light[level=13]
fill 437 250 616 439 256 616 minecraft:green_terracotta
fill 437 250 623 439 252 623 minecraft:green_terracotta
fill 437 250 629 439 252 629 minecraft:lime_terracotta
fill 437 250 636 439 256 636 minecraft:lime_terracotta
setblock 438 250 604 minecraft:light_gray_concrete
fill 439 250 604 440 307 604 minecraft:white_concrete
fill 440 250 646 440 307 646 minecraft:white_concrete
setblock 441 250 604 minecraft:light_gray_concrete
setblock 441 250 646 minecraft:light_gray_concrete
fill 442 250 604 443 307 604 minecraft:white_concrete
setblock 442 250 607 minecraft:light[level=13]
setblock 442 250 615 minecraft:light[level=13]
setblock 442 250 639 minecraft:light[level=13]
fill 442 250 646 442 255 646 minecraft:white_concrete
fill 443 250 616 445 256 616 minecraft:green_terracotta
fill 443 250 623 445 252 623 minecraft:green_terracotta
fill 443 250 629 445 252 629 minecraft:lime_terracotta
fill 443 250 636 445 256 636 minecraft:lime_terracotta
fill 446 250 604 448 255 604 minecraft:white_concrete
fill 446 250 646 446 307 646 minecraft:white_concrete
fill 448 250 617 448 256 617 minecraft:green_terracotta
fill 448 250 622 448 256 622 minecraft:green_terracotta
fill 448 250 630 448 256 630 minecraft:lime_terracotta
fill 448 250 635 448 256 635 minecraft:lime_terracotta
fill 448 250 646 449 307 646 minecraft:white_concrete
setblock 449 250 604 minecraft:light_gray_concrete
fill 449 250 618 450 255 618 minecraft:green_terracotta
fill 449 250 621 450 255 621 minecraft:green_terracotta
fill 449 250 631 450 255 631 minecraft:lime_terracotta
fill 449 250 634 450 255 634 minecraft:lime_terracotta
fill 450 250 604 460 255 604 minecraft:white_concrete
setblock 450 250 607 minecraft:light[level=13]
setblock 450 250 615 minecraft:light[level=13]
fill 450 250 619 450 256 620 minecraft:green_terracotta
setblock 450 250 623 minecraft:light[level=13]
fill 450 250 632 450 256 633 minecraft:lime_terracotta
setblock 450 250 639 minecraft:light[level=13]
setblock 450 250 646 minecraft:light_gray_concrete
fill 451 250 646 451 307 646 minecraft:white_concrete
setblock 452 250 646 minecraft:light_gray_concrete
fill 453 250 646 455 307 646 minecraft:white_concrete
setblock 458 250 607 minecraft:light[level=13]
setblock 458 250 615 minecraft:light[level=13]
setblock 458 250 623 minecraft:light[level=13]
setblock 458 250 631 minecraft:light[level=13]
setblock 458 250 639 minecraft:light[level=13]
fill 458 250 646 458 255 646 minecraft:white_concrete
setblock 459 250 646 minecraft:light_gray_concrete
fill 460 250 646 463 307 646 minecraft:white_concrete
setblock 464 250 646 minecraft:light_gray_concrete
fill 465 250 605 465 307 606 minecraft:white_concrete
setblock 465 250 607 minecraft:light_gray_concrete
fill 465 250 608 465 255 609 minecraft:white_concrete
fill 465 250 613 465 255 617 minecraft:white_concrete
setblock 465 250 618 minecraft:light_gray_concrete
setblock 465 250 623 minecraft:light_gray_concrete
fill 465 250 624 465 255 627 minecraft:white_concrete
setblock 465 250 628 minecraft:light_gray_concrete
schedule function dropper:buildpart/153_2 1t
