fill 42 124 332 42 132 332 minecraft:honeycomb_block
fill 42 124 336 42 147 336 minecraft:honeycomb_block
setblock 42 124 337 minecraft:yellow_concrete
fill 9 125 345 9 126 345 minecraft:black_concrete
fill 14 125 339 14 126 345 minecraft:orange_stained_glass
fill 15 125 338 15 126 341 minecraft:orange_stained_glass
fill 15 125 343 15 126 346 minecraft:orange_stained_glass
fill 16 125 337 19 126 337 minecraft:orange_stained_glass
setblock 16 125 338 minecraft:honeycomb_block
setblock 16 125 346 minecraft:honeycomb_block
fill 16 125 347 19 126 347 minecraft:orange_stained_glass
fill 17 125 336 23 126 336 minecraft:orange_stained_glass
fill 17 125 348 23 126 348 minecraft:orange_stained_glass
fill 21 125 337 24 126 337 minecraft:orange_stained_glass
fill 21 125 347 24 126 347 minecraft:orange_stained_glass
setblock 24 125 338 minecraft:honeycomb_block
setblock 24 125 346 minecraft:honeycomb_block
fill 25 125 338 25 126 341 minecraft:orange_stained_glass
fill 25 125 343 25 126 346 minecraft:orange_stained_glass
fill 26 125 339 26 126 345 minecraft:orange_stained_glass
setblock 37 125 322 minecraft:yellow_concrete
setblock 41 125 364 minecraft:orange_terracotta
fill 42 125 337 42 179 337 minecraft:honeycomb_block
fill 1 126 323 1 126 324 minecraft:orange_terracotta
setblock 1 126 325 minecraft:honeycomb_block
fill 1 126 326 1 126 328 minecraft:orange_terracotta
setblock 1 126 329 minecraft:honeycomb_block
fill 1 126 330 1 126 332 minecraft:orange_terracotta
setblock 1 126 333 minecraft:honeycomb_block
fill 1 126 334 1 126 336 minecraft:orange_terracotta
setblock 1 126 337 minecraft:honeycomb_block
fill 1 126 338 1 126 340 minecraft:orange_terracotta
setblock 1 126 341 minecraft:honeycomb_block
fill 1 126 342 1 126 344 minecraft:orange_terracotta
setblock 1 126 345 minecraft:honeycomb_block
fill 1 126 346 1 126 348 minecraft:orange_terracotta
setblock 1 126 349 minecraft:honeycomb_block
fill 1 126 350 1 126 352 minecraft:orange_terracotta
setblock 1 126 353 minecraft:honeycomb_block
fill 1 126 354 1 126 356 minecraft:orange_terracotta
setblock 1 126 357 minecraft:honeycomb_block
fill 1 126 358 1 126 360 minecraft:orange_terracotta
setblock 1 126 361 minecraft:honeycomb_block
fill 1 126 362 2 126 363 minecraft:orange_terracotta
setblock 2 126 323 minecraft:orange_terracotta
setblock 2 126 324 minecraft:honeycomb_block
fill 2 126 325 2 126 327 minecraft:orange_terracotta
setblock 2 126 328 minecraft:honeycomb_block
fill 2 126 329 2 126 331 minecraft:orange_terracotta
setblock 2 126 332 minecraft:honeycomb_block
fill 2 126 333 2 126 335 minecraft:orange_terracotta
setblock 2 126 336 minecraft:honeycomb_block
fill 2 126 337 2 126 339 minecraft:orange_terracotta
setblock 2 126 340 minecraft:honeycomb_block
fill 2 126 341 2 126 343 minecraft:orange_terracotta
setblock 2 126 344 minecraft:honeycomb_block
fill 2 126 345 2 126 347 minecraft:orange_terracotta
setblock 2 126 348 minecraft:honeycomb_block
fill 2 126 349 2 126 351 minecraft:orange_terracotta
setblock 2 126 352 minecraft:honeycomb_block
fill 2 126 353 2 126 355 minecraft:orange_terracotta
setblock 2 126 356 minecraft:honeycomb_block
fill 2 126 357 2 126 359 minecraft:orange_terracotta
setblock 2 126 360 minecraft:honeycomb_block
fill 2 126 361 4 126 361 minecraft:orange_terracotta
setblock 3 126 323 minecraft:honeycomb_block
fill 3 126 324 3 126 326 minecraft:orange_terracotta
setblock 3 126 327 minecraft:honeycomb_block
fill 3 126 328 3 126 330 minecraft:orange_terracotta
setblock 3 126 331 minecraft:honeycomb_block
fill 3 126 332 3 126 334 minecraft:orange_terracotta
setblock 3 126 335 minecraft:honeycomb_block
fill 3 126 336 3 126 338 minecraft:orange_terracotta
setblock 3 126 339 minecraft:honeycomb_block
fill 3 126 340 3 126 342 minecraft:orange_terracotta
setblock 3 126 343 minecraft:honeycomb_block
fill 3 126 344 3 126 346 minecraft:orange_terracotta
setblock 3 126 347 minecraft:honeycomb_block
fill 3 126 348 3 126 350 minecraft:orange_terracotta
setblock 3 126 351 minecraft:honeycomb_block
fill 3 126 352 3 126 354 minecraft:orange_terracotta
setblock 3 126 355 minecraft:honeycomb_block
fill 3 126 356 3 126 358 minecraft:orange_terracotta
setblock 3 126 359 minecraft:honeycomb_block
fill 3 126 360 5 126 360 minecraft:orange_terracotta
setblock 3 126 362 minecraft:orange_terracotta
setblock 3 126 363 minecraft:honeycomb_block
fill 4 126 323 4 126 325 minecraft:orange_terracotta
setblock 4 126 326 minecraft:honeycomb_block
fill 4 126 327 4 126 329 minecraft:orange_terracotta
setblock 4 126 330 minecraft:honeycomb_block
fill 4 126 331 4 126 333 minecraft:orange_terracotta
setblock 4 126 334 minecraft:honeycomb_block
fill 4 126 335 4 126 337 minecraft:orange_terracotta
setblock 4 126 338 minecraft:honeycomb_block
fill 4 126 339 4 126 341 minecraft:orange_terracotta
setblock 4 126 342 minecraft:honeycomb_block
fill 4 126 343 4 126 345 minecraft:orange_terracotta
setblock 4 126 346 minecraft:honeycomb_block
fill 4 126 347 4 126 349 minecraft:orange_terracotta
setblock 4 126 350 minecraft:honeycomb_block
fill 4 126 351 4 126 353 minecraft:orange_terracotta
setblock 4 126 354 minecraft:honeycomb_block
fill 4 126 355 4 126 357 minecraft:orange_terracotta
setblock 4 126 358 minecraft:honeycomb_block
fill 4 126 359 6 126 359 minecraft:orange_terracotta
setblock 4 126 362 minecraft:honeycomb_block
fill 4 126 363 6 126 363 minecraft:orange_terracotta
fill 5 126 323 5 126 324 minecraft:orange_terracotta
setblock 5 126 325 minecraft:honeycomb_block
fill 5 126 326 5 126 328 minecraft:orange_terracotta
setblock 5 126 329 minecraft:honeycomb_block
fill 5 126 330 5 126 332 minecraft:orange_terracotta
setblock 5 126 333 minecraft:honeycomb_block
fill 5 126 334 5 126 336 minecraft:orange_terracotta
setblock 5 126 337 minecraft:honeycomb_block
fill 5 126 338 5 126 340 minecraft:orange_terracotta
setblock 5 126 341 minecraft:honeycomb_block
fill 5 126 342 5 126 344 minecraft:orange_terracotta
setblock 5 126 345 minecraft:honeycomb_block
fill 5 126 346 5 126 348 minecraft:orange_terracotta
setblock 5 126 349 minecraft:honeycomb_block
fill 5 126 350 5 126 352 minecraft:orange_terracotta
setblock 5 126 353 minecraft:honeycomb_block
fill 5 126 354 5 126 356 minecraft:orange_terracotta
setblock 5 126 357 minecraft:honeycomb_block
fill 5 126 358 7 126 358 minecraft:orange_terracotta
setblock 5 126 361 minecraft:honeycomb_block
fill 5 126 362 7 126 362 minecraft:orange_terracotta
setblock 6 126 323 minecraft:orange_terracotta
setblock 6 126 324 minecraft:honeycomb_block
fill 6 126 325 6 126 327 minecraft:orange_terracotta
setblock 6 126 328 minecraft:honeycomb_block
fill 6 126 329 6 126 331 minecraft:orange_terracotta
setblock 6 126 332 minecraft:honeycomb_block
fill 6 126 333 6 126 335 minecraft:orange_terracotta
setblock 6 126 336 minecraft:honeycomb_block
fill 6 126 337 6 126 339 minecraft:orange_terracotta
setblock 6 126 340 minecraft:honeycomb_block
fill 6 126 341 6 126 343 minecraft:orange_terracotta
setblock 6 126 344 minecraft:honeycomb_block
fill 6 126 345 6 126 347 minecraft:orange_terracotta
setblock 6 126 348 minecraft:honeycomb_block
fill 6 126 349 6 126 351 minecraft:orange_terracotta
setblock 6 126 352 minecraft:honeycomb_block
fill 6 126 353 6 126 355 minecraft:orange_terracotta
setblock 6 126 356 minecraft:honeycomb_block
fill 6 126 357 8 126 357 minecraft:orange_terracotta
setblock 6 126 360 minecraft:honeycomb_block
fill 6 126 361 8 126 361 minecraft:orange_terracotta
setblock 7 126 323 minecraft:honeycomb_block
fill 7 126 324 7 126 326 minecraft:orange_terracotta
setblock 7 126 327 minecraft:honeycomb_block
fill 7 126 328 7 126 330 minecraft:orange_terracotta
setblock 7 126 331 minecraft:honeycomb_block
fill 7 126 332 7 126 334 minecraft:orange_terracotta
setblock 7 126 335 minecraft:honeycomb_block
fill 7 126 336 7 126 338 minecraft:orange_terracotta
setblock 7 126 339 minecraft:honeycomb_block
fill 7 126 340 7 126 342 minecraft:orange_terracotta
setblock 7 126 343 minecraft:honeycomb_block
fill 7 126 344 7 126 346 minecraft:orange_terracotta
setblock 7 126 347 minecraft:honeycomb_block
fill 7 126 348 7 126 350 minecraft:orange_terracotta
setblock 7 126 351 minecraft:honeycomb_block
fill 7 126 352 7 126 354 minecraft:orange_terracotta
setblock 7 126 355 minecraft:honeycomb_block
fill 7 126 356 9 126 356 minecraft:orange_terracotta
setblock 7 126 359 minecraft:honeycomb_block
fill 7 126 360 9 126 360 minecraft:orange_terracotta
setblock 7 126 363 minecraft:honeycomb_block
fill 8 126 323 8 126 325 minecraft:orange_terracotta
setblock 8 126 326 minecraft:honeycomb_block
fill 8 126 327 8 126 329 minecraft:orange_terracotta
setblock 8 126 330 minecraft:honeycomb_block
fill 8 126 331 8 126 333 minecraft:orange_terracotta
setblock 8 126 334 minecraft:honeycomb_block
fill 8 126 335 8 126 337 minecraft:orange_terracotta
setblock 8 126 338 minecraft:honeycomb_block
fill 8 126 339 8 126 341 minecraft:orange_terracotta
setblock 8 126 342 minecraft:honeycomb_block
fill 8 126 343 8 126 345 minecraft:orange_terracotta
setblock 8 126 346 minecraft:honeycomb_block
fill 8 126 347 8 126 349 minecraft:orange_terracotta
setblock 8 126 350 minecraft:honeycomb_block
fill 8 126 351 8 126 353 minecraft:orange_terracotta
setblock 8 126 354 minecraft:honeycomb_block
fill 8 126 355 10 126 355 minecraft:orange_terracotta
setblock 8 126 358 minecraft:honeycomb_block
fill 8 126 359 10 126 359 minecraft:orange_terracotta
setblock 8 126 362 minecraft:honeycomb_block
fill 8 126 363 10 126 363 minecraft:orange_terracotta
fill 9 126 323 9 126 324 minecraft:orange_terracotta
setblock 9 126 325 minecraft:honeycomb_block
fill 9 126 326 9 126 328 minecraft:orange_terracotta
setblock 9 126 329 minecraft:honeycomb_block
fill 9 126 330 9 126 332 minecraft:orange_terracotta
setblock 9 126 333 minecraft:honeycomb_block
fill 9 126 334 9 126 336 minecraft:orange_terracotta
setblock 9 126 337 minecraft:honeycomb_block
fill 9 126 338 9 126 340 minecraft:orange_terracotta
setblock 9 126 341 minecraft:honeycomb_block
fill 9 126 342 9 126 344 minecraft:orange_terracotta
fill 9 126 346 9 126 348 minecraft:orange_terracotta
setblock 9 126 349 minecraft:honeycomb_block
fill 9 126 350 9 126 352 minecraft:orange_terracotta
setblock 9 126 353 minecraft:honeycomb_block
fill 9 126 354 11 126 354 minecraft:orange_terracotta
setblock 9 126 357 minecraft:honeycomb_block
fill 9 126 358 11 126 358 minecraft:orange_terracotta
setblock 9 126 361 minecraft:honeycomb_block
fill 9 126 362 11 126 362 minecraft:orange_terracotta
setblock 10 126 323 minecraft:orange_terracotta
setblock 10 126 324 minecraft:honeycomb_block
fill 10 126 325 10 126 327 minecraft:orange_terracotta
setblock 10 126 328 minecraft:honeycomb_block
fill 10 126 329 10 126 331 minecraft:orange_terracotta
setblock 10 126 332 minecraft:honeycomb_block
fill 10 126 333 10 126 335 minecraft:orange_terracotta
setblock 10 126 336 minecraft:honeycomb_block
fill 10 126 337 10 126 339 minecraft:orange_terracotta
setblock 10 126 340 minecraft:honeycomb_block
fill 10 126 341 10 126 343 minecraft:orange_terracotta
setblock 10 126 344 minecraft:honeycomb_block
fill 10 126 345 10 126 347 minecraft:orange_terracotta
setblock 10 126 348 minecraft:honeycomb_block
fill 10 126 349 10 126 351 minecraft:orange_terracotta
setblock 10 126 352 minecraft:honeycomb_block
fill 10 126 353 12 126 353 minecraft:orange_terracotta
setblock 10 126 356 minecraft:honeycomb_block
fill 10 126 357 12 126 357 minecraft:orange_terracotta
setblock 10 126 360 minecraft:honeycomb_block
fill 10 126 361 12 126 361 minecraft:orange_terracotta
setblock 11 126 323 minecraft:honeycomb_block
fill 11 126 324 11 126 326 minecraft:orange_terracotta
setblock 11 126 327 minecraft:honeycomb_block
fill 11 126 328 11 126 330 minecraft:orange_terracotta
setblock 11 126 331 minecraft:honeycomb_block
fill 11 126 332 11 126 334 minecraft:orange_terracotta
setblock 11 126 335 minecraft:honeycomb_block
fill 11 126 336 11 126 338 minecraft:orange_terracotta
setblock 11 126 339 minecraft:honeycomb_block
fill 11 126 340 11 126 342 minecraft:orange_terracotta
setblock 11 126 343 minecraft:honeycomb_block
fill 11 126 344 11 126 346 minecraft:orange_terracotta
setblock 11 126 347 minecraft:honeycomb_block
fill 11 126 348 11 126 350 minecraft:orange_terracotta
setblock 11 126 351 minecraft:honeycomb_block
fill 11 126 352 13 126 352 minecraft:orange_terracotta
setblock 11 126 355 minecraft:honeycomb_block
fill 11 126 356 13 126 356 minecraft:orange_terracotta
setblock 11 126 359 minecraft:honeycomb_block
fill 11 126 360 13 126 360 minecraft:orange_terracotta
setblock 11 126 363 minecraft:honeycomb_block
fill 12 126 323 12 126 325 minecraft:orange_terracotta
setblock 12 126 326 minecraft:honeycomb_block
fill 12 126 327 12 126 329 minecraft:orange_terracotta
setblock 12 126 330 minecraft:honeycomb_block
fill 12 126 331 12 126 333 minecraft:orange_terracotta
setblock 12 126 334 minecraft:honeycomb_block
fill 12 126 335 12 126 337 minecraft:orange_terracotta
setblock 12 126 338 minecraft:honeycomb_block
fill 12 126 339 13 126 345 minecraft:orange_stained_glass
setblock 12 126 346 minecraft:honeycomb_block
fill 12 126 347 12 126 349 minecraft:orange_terracotta
setblock 12 126 350 minecraft:honeycomb_block
fill 12 126 351 14 126 351 minecraft:orange_terracotta
setblock 12 126 354 minecraft:honeycomb_block
fill 12 126 355 14 126 355 minecraft:orange_terracotta
setblock 12 126 358 minecraft:honeycomb_block
fill 12 126 359 14 126 359 minecraft:orange_terracotta
setblock 12 126 362 minecraft:honeycomb_block
fill 12 126 363 14 126 363 minecraft:orange_terracotta
fill 13 126 323 13 126 324 minecraft:orange_terracotta
setblock 13 126 325 minecraft:honeycomb_block
fill 13 126 326 13 126 328 minecraft:orange_terracotta
setblock 13 126 329 minecraft:honeycomb_block
fill 13 126 330 13 126 332 minecraft:orange_terracotta
setblock 13 126 333 minecraft:honeycomb_block
fill 13 126 334 13 126 336 minecraft:orange_terracotta
fill 13 126 337 14 126 338 minecraft:orange_stained_glass
fill 13 126 346 14 126 347 minecraft:orange_stained_glass
setblock 13 126 348 minecraft:orange_terracotta
setblock 13 126 349 minecraft:honeycomb_block
fill 13 126 350 15 126 350 minecraft:orange_terracotta
setblock 13 126 353 minecraft:honeycomb_block
fill 13 126 354 15 126 354 minecraft:orange_terracotta
setblock 13 126 357 minecraft:honeycomb_block
fill 13 126 358 15 126 358 minecraft:orange_terracotta
setblock 13 126 361 minecraft:honeycomb_block
fill 13 126 362 15 126 362 minecraft:orange_terracotta
setblock 14 126 323 minecraft:orange_terracotta
setblock 14 126 324 minecraft:honeycomb_block
fill 14 126 325 14 126 327 minecraft:orange_terracotta
setblock 14 126 328 minecraft:honeycomb_block
fill 14 126 329 14 126 331 minecraft:orange_terracotta
setblock 14 126 332 minecraft:honeycomb_block
fill 14 126 333 14 126 335 minecraft:orange_terracotta
fill 14 126 336 16 126 336 minecraft:orange_stained_glass
fill 14 126 348 16 126 348 minecraft:orange_stained_glass
setblock 14 126 349 minecraft:orange_terracotta
setblock 14 126 352 minecraft:honeycomb_block
fill 14 126 353 16 126 353 minecraft:orange_terracotta
setblock 14 126 356 minecraft:honeycomb_block
fill 14 126 357 16 126 357 minecraft:orange_terracotta
setblock 14 126 360 minecraft:honeycomb_block
fill 14 126 361 16 126 361 minecraft:orange_terracotta
setblock 15 126 323 minecraft:honeycomb_block
fill 15 126 324 15 126 326 minecraft:orange_terracotta
setblock 15 126 327 minecraft:honeycomb_block
fill 15 126 328 15 126 330 minecraft:orange_terracotta
setblock 15 126 331 minecraft:honeycomb_block
fill 15 126 332 15 126 334 minecraft:orange_terracotta
fill 15 126 335 25 126 335 minecraft:orange_stained_glass
setblock 15 126 337 minecraft:orange_stained_glass
fill 15 126 342 16 126 342 minecraft:orange_stained_glass
setblock 15 126 347 minecraft:orange_stained_glass
fill 15 126 349 25 126 349 minecraft:orange_stained_glass
setblock 15 126 351 minecraft:honeycomb_block
fill 15 126 352 17 126 352 minecraft:orange_terracotta
setblock 15 126 355 minecraft:honeycomb_block
fill 15 126 356 17 126 356 minecraft:orange_terracotta
setblock 15 126 359 minecraft:honeycomb_block
fill 15 126 360 17 126 360 minecraft:orange_terracotta
setblock 15 126 363 minecraft:honeycomb_block
fill 16 126 323 16 126 325 minecraft:orange_terracotta
setblock 16 126 326 minecraft:honeycomb_block
fill 16 126 327 16 126 329 minecraft:orange_terracotta
setblock 16 126 330 minecraft:honeycomb_block
fill 16 126 331 16 126 333 minecraft:orange_terracotta
setblock 16 126 334 minecraft:honeycomb_block
fill 16 126 338 16 126 341 minecraft:orange_stained_glass
fill 16 126 343 16 126 346 minecraft:orange_stained_glass
setblock 16 126 350 minecraft:honeycomb_block
fill 16 126 351 18 126 351 minecraft:orange_terracotta
setblock 16 126 354 minecraft:honeycomb_block
fill 16 126 355 18 126 355 minecraft:orange_terracotta
setblock 16 126 358 minecraft:honeycomb_block
fill 16 126 359 18 126 359 minecraft:orange_terracotta
setblock 16 126 362 minecraft:honeycomb_block
fill 16 126 363 18 126 363 minecraft:orange_terracotta
fill 17 126 323 17 126 324 minecraft:orange_terracotta
setblock 17 126 325 minecraft:honeycomb_block
fill 17 126 326 17 126 328 minecraft:orange_terracotta
setblock 17 126 329 minecraft:honeycomb_block
fill 17 126 330 17 126 332 minecraft:orange_terracotta
setblock 17 126 333 minecraft:honeycomb_block
fill 17 126 334 23 126 334 minecraft:orange_stained_glass
fill 17 126 338 17 126 339 minecraft:orange_stained_glass
fill 17 126 340 17 126 344 minecraft:ochre_froglight
fill 17 126 345 17 126 346 minecraft:orange_stained_glass
fill 17 126 350 23 126 350 minecraft:orange_stained_glass
setblock 17 126 353 minecraft:honeycomb_block
fill 17 126 354 19 126 354 minecraft:orange_terracotta
setblock 17 126 357 minecraft:honeycomb_block
fill 17 126 358 19 126 358 minecraft:orange_terracotta
setblock 17 126 361 minecraft:honeycomb_block
fill 17 126 362 19 126 362 minecraft:orange_terracotta
setblock 18 126 323 minecraft:orange_terracotta
setblock 18 126 324 minecraft:honeycomb_block
fill 18 126 325 18 126 327 minecraft:orange_terracotta
setblock 18 126 328 minecraft:honeycomb_block
fill 18 126 329 18 126 331 minecraft:orange_terracotta
setblock 18 126 332 minecraft:honeycomb_block
fill 18 126 333 20 126 333 minecraft:orange_terracotta
fill 18 126 338 24 126 338 minecraft:orange_stained_glass
fill 18 126 339 18 126 340 minecraft:ochre_froglight
fill 18 126 344 18 126 345 minecraft:ochre_froglight
fill 18 126 346 24 126 346 minecraft:orange_stained_glass
setblock 18 126 352 minecraft:honeycomb_block
fill 18 126 353 20 126 353 minecraft:orange_terracotta
setblock 18 126 356 minecraft:honeycomb_block
fill 18 126 357 20 126 357 minecraft:orange_terracotta
setblock 18 126 360 minecraft:honeycomb_block
fill 18 126 361 20 126 361 minecraft:orange_terracotta
setblock 19 126 323 minecraft:honeycomb_block
fill 19 126 324 19 126 326 minecraft:orange_terracotta
setblock 19 126 327 minecraft:honeycomb_block
fill 19 126 328 19 126 330 minecraft:orange_terracotta
setblock 19 126 331 minecraft:honeycomb_block
fill 19 126 332 21 126 332 minecraft:orange_terracotta
fill 19 126 339 22 126 339 minecraft:ochre_froglight
fill 19 126 345 22 126 345 minecraft:ochre_froglight
setblock 19 126 351 minecraft:honeycomb_block
fill 19 126 352 21 126 352 minecraft:orange_terracotta
setblock 19 126 355 minecraft:honeycomb_block
fill 19 126 356 21 126 356 minecraft:orange_terracotta
setblock 19 126 359 minecraft:honeycomb_block
fill 19 126 360 21 126 360 minecraft:orange_terracotta
setblock 19 126 363 minecraft:honeycomb_block
fill 20 126 323 20 126 325 minecraft:orange_terracotta
setblock 20 126 326 minecraft:honeycomb_block
fill 20 126 327 20 126 329 minecraft:orange_terracotta
setblock 20 126 330 minecraft:honeycomb_block
fill 20 126 331 22 126 331 minecraft:orange_terracotta
setblock 20 126 337 minecraft:orange_stained_glass
setblock 20 126 347 minecraft:orange_stained_glass
fill 20 126 351 22 126 351 minecraft:orange_terracotta
setblock 20 126 354 minecraft:honeycomb_block
fill 20 126 355 22 126 355 minecraft:orange_terracotta
setblock 20 126 358 minecraft:honeycomb_block
fill 20 126 359 22 126 359 minecraft:orange_terracotta
setblock 20 126 362 minecraft:honeycomb_block
fill 20 126 363 22 126 363 minecraft:orange_terracotta
fill 21 126 323 21 126 324 minecraft:orange_terracotta
setblock 21 126 325 minecraft:honeycomb_block
fill 21 126 326 21 126 328 minecraft:orange_terracotta
setblock 21 126 329 minecraft:honeycomb_block
fill 21 126 330 23 126 330 minecraft:orange_terracotta
setblock 21 126 333 minecraft:honeycomb_block
setblock 21 126 353 minecraft:honeycomb_block
fill 21 126 354 23 126 354 minecraft:orange_terracotta
setblock 21 126 357 minecraft:honeycomb_block
fill 21 126 358 23 126 358 minecraft:orange_terracotta
setblock 21 126 361 minecraft:honeycomb_block
fill 21 126 362 23 126 362 minecraft:orange_terracotta
setblock 22 126 323 minecraft:orange_terracotta
setblock 22 126 324 minecraft:honeycomb_block
fill 22 126 325 22 126 327 minecraft:orange_terracotta
setblock 22 126 328 minecraft:honeycomb_block
fill 22 126 329 24 126 329 minecraft:orange_terracotta
setblock 22 126 332 minecraft:honeycomb_block
fill 22 126 333 24 126 333 minecraft:orange_terracotta
fill 22 126 340 23 126 340 minecraft:ochre_froglight
fill 22 126 344 23 126 344 minecraft:ochre_froglight
setblock 22 126 352 minecraft:honeycomb_block
fill 22 126 353 24 126 353 minecraft:orange_terracotta
setblock 22 126 356 minecraft:honeycomb_block
fill 22 126 357 24 126 357 minecraft:orange_terracotta
setblock 22 126 360 minecraft:honeycomb_block
fill 22 126 361 24 126 361 minecraft:orange_terracotta
setblock 23 126 323 minecraft:honeycomb_block
fill 23 126 324 23 126 326 minecraft:orange_terracotta
setblock 23 126 327 minecraft:honeycomb_block
fill 23 126 328 25 126 328 minecraft:orange_terracotta
setblock 23 126 331 minecraft:honeycomb_block
fill 23 126 332 25 126 332 minecraft:orange_terracotta
fill 23 126 339 24 126 339 minecraft:orange_stained_glass
fill 23 126 341 23 126 343 minecraft:ochre_froglight
fill 23 126 345 24 126 345 minecraft:orange_stained_glass
setblock 23 126 351 minecraft:honeycomb_block
fill 23 126 352 25 126 352 minecraft:orange_terracotta
setblock 23 126 355 minecraft:honeycomb_block
fill 23 126 356 25 126 356 minecraft:orange_terracotta
setblock 23 126 359 minecraft:honeycomb_block
fill 23 126 360 25 126 360 minecraft:orange_terracotta
setblock 23 126 363 minecraft:honeycomb_block
fill 24 126 323 24 126 325 minecraft:orange_terracotta
setblock 24 126 326 minecraft:honeycomb_block
fill 24 126 327 26 126 327 minecraft:orange_terracotta
setblock 24 126 330 minecraft:honeycomb_block
fill 24 126 331 26 126 331 minecraft:orange_terracotta
setblock 24 126 334 minecraft:honeycomb_block
fill 24 126 336 26 126 336 minecraft:orange_stained_glass
fill 24 126 340 24 126 344 minecraft:orange_stained_glass
fill 24 126 348 26 126 348 minecraft:orange_stained_glass
setblock 24 126 350 minecraft:honeycomb_block
fill 24 126 351 26 126 351 minecraft:orange_terracotta
setblock 24 126 354 minecraft:honeycomb_block
fill 24 126 355 26 126 355 minecraft:orange_terracotta
setblock 24 126 358 minecraft:honeycomb_block
fill 24 126 359 26 126 359 minecraft:orange_terracotta
setblock 24 126 362 minecraft:honeycomb_block
fill 24 126 363 26 126 363 minecraft:orange_terracotta
fill 25 126 323 25 126 324 minecraft:orange_terracotta
setblock 25 126 325 minecraft:honeycomb_block
fill 25 126 326 27 126 326 minecraft:orange_terracotta
setblock 25 126 329 minecraft:honeycomb_block
fill 25 126 330 27 126 330 minecraft:orange_terracotta
setblock 25 126 333 minecraft:honeycomb_block
fill 25 126 334 27 126 334 minecraft:orange_terracotta
fill 25 126 337 27 126 337 minecraft:orange_stained_glass
setblock 25 126 342 minecraft:orange_stained_glass
fill 25 126 347 27 126 347 minecraft:orange_stained_glass
fill 25 126 350 27 126 350 minecraft:orange_terracotta
setblock 25 126 353 minecraft:honeycomb_block
fill 25 126 354 27 126 354 minecraft:orange_terracotta
setblock 25 126 357 minecraft:honeycomb_block
fill 25 126 358 27 126 358 minecraft:orange_terracotta
setblock 25 126 361 minecraft:honeycomb_block
fill 25 126 362 27 126 362 minecraft:orange_terracotta
setblock 26 126 323 minecraft:orange_terracotta
setblock 26 126 324 minecraft:honeycomb_block
fill 26 126 325 28 126 325 minecraft:orange_terracotta
setblock 26 126 328 minecraft:honeycomb_block
fill 26 126 329 28 126 329 minecraft:orange_terracotta
setblock 26 126 332 minecraft:honeycomb_block
fill 26 126 333 28 126 333 minecraft:orange_terracotta
setblock 26 126 335 minecraft:orange_terracotta
fill 26 126 338 27 126 338 minecraft:orange_stained_glass
fill 26 126 346 27 126 346 minecraft:orange_stained_glass
fill 26 126 349 28 126 349 minecraft:orange_terracotta
setblock 26 126 352 minecraft:honeycomb_block
fill 26 126 353 28 126 353 minecraft:orange_terracotta
setblock 26 126 356 minecraft:honeycomb_block
fill 26 126 357 28 126 357 minecraft:orange_terracotta
setblock 26 126 360 minecraft:honeycomb_block
fill 26 126 361 28 126 361 minecraft:orange_terracotta
setblock 27 126 323 minecraft:honeycomb_block
fill 27 126 324 29 126 324 minecraft:orange_terracotta
setblock 27 126 327 minecraft:honeycomb_block
fill 27 126 328 29 126 328 minecraft:orange_terracotta
setblock 27 126 331 minecraft:honeycomb_block
fill 27 126 332 29 126 332 minecraft:orange_terracotta
setblock 27 126 335 minecraft:honeycomb_block
fill 27 126 336 29 126 336 minecraft:orange_terracotta
fill 27 126 339 28 126 345 minecraft:orange_stained_glass
fill 27 126 348 29 126 348 minecraft:orange_terracotta
setblock 27 126 351 minecraft:honeycomb_block
fill 27 126 352 29 126 352 minecraft:orange_terracotta
setblock 27 126 355 minecraft:honeycomb_block
fill 27 126 356 29 126 356 minecraft:orange_terracotta
setblock 27 126 359 minecraft:honeycomb_block
fill 27 126 360 29 126 360 minecraft:orange_terracotta
setblock 27 126 363 minecraft:honeycomb_block
fill 28 126 323 30 126 323 minecraft:orange_terracotta
setblock 28 126 326 minecraft:honeycomb_block
fill 28 126 327 30 126 327 minecraft:orange_terracotta
setblock 28 126 330 minecraft:honeycomb_block
fill 28 126 331 30 126 331 minecraft:orange_terracotta
setblock 28 126 334 minecraft:honeycomb_block
fill 28 126 335 30 126 335 minecraft:orange_terracotta
setblock 28 126 337 minecraft:orange_terracotta
setblock 28 126 338 minecraft:honeycomb_block
setblock 28 126 346 minecraft:honeycomb_block
fill 28 126 347 30 126 347 minecraft:orange_terracotta
setblock 28 126 350 minecraft:honeycomb_block
fill 28 126 351 30 126 351 minecraft:orange_terracotta
setblock 28 126 354 minecraft:honeycomb_block
fill 28 126 355 30 126 355 minecraft:orange_terracotta
setblock 28 126 358 minecraft:honeycomb_block
fill 28 126 359 30 126 359 minecraft:orange_terracotta
setblock 28 126 362 minecraft:honeycomb_block
fill 28 126 363 30 126 363 minecraft:orange_terracotta
setblock 29 126 325 minecraft:honeycomb_block
fill 29 126 326 31 126 326 minecraft:orange_terracotta
setblock 29 126 329 minecraft:honeycomb_block
fill 29 126 330 31 126 330 minecraft:orange_terracotta
setblock 29 126 333 minecraft:honeycomb_block
fill 29 126 334 31 126 334 minecraft:orange_terracotta
setblock 29 126 337 minecraft:honeycomb_block
fill 29 126 338 29 126 340 minecraft:orange_terracotta
setblock 29 126 341 minecraft:honeycomb_block
fill 29 126 342 29 126 344 minecraft:orange_terracotta
setblock 29 126 345 minecraft:honeycomb_block
fill 29 126 346 31 126 346 minecraft:orange_terracotta
setblock 29 126 349 minecraft:honeycomb_block
fill 29 126 350 31 126 350 minecraft:orange_terracotta
setblock 29 126 353 minecraft:honeycomb_block
fill 29 126 354 31 126 354 minecraft:orange_terracotta
setblock 29 126 357 minecraft:honeycomb_block
fill 29 126 358 31 126 358 minecraft:orange_terracotta
setblock 29 126 361 minecraft:honeycomb_block
fill 29 126 362 31 126 362 minecraft:orange_terracotta
setblock 30 126 324 minecraft:honeycomb_block
fill 30 126 325 32 126 325 minecraft:orange_terracotta
setblock 30 126 328 minecraft:honeycomb_block
fill 30 126 329 32 126 329 minecraft:orange_terracotta
setblock 30 126 332 minecraft:honeycomb_block
fill 30 126 333 32 126 333 minecraft:orange_terracotta
setblock 30 126 336 minecraft:honeycomb_block
fill 30 126 337 30 126 339 minecraft:orange_terracotta
setblock 30 126 340 minecraft:honeycomb_block
fill 30 126 341 30 126 343 minecraft:orange_terracotta
setblock 30 126 344 minecraft:honeycomb_block
fill 30 126 345 32 126 345 minecraft:orange_terracotta
setblock 30 126 348 minecraft:honeycomb_block
fill 30 126 349 32 126 349 minecraft:orange_terracotta
setblock 30 126 352 minecraft:honeycomb_block
fill 30 126 353 32 126 353 minecraft:orange_terracotta
setblock 30 126 356 minecraft:honeycomb_block
fill 30 126 357 32 126 357 minecraft:orange_terracotta
setblock 30 126 360 minecraft:honeycomb_block
fill 30 126 361 32 126 361 minecraft:orange_terracotta
setblock 31 126 323 minecraft:honeycomb_block
fill 31 126 324 33 126 324 minecraft:orange_terracotta
setblock 31 126 327 minecraft:honeycomb_block
fill 31 126 328 33 126 328 minecraft:orange_terracotta
setblock 31 126 331 minecraft:honeycomb_block
fill 31 126 332 33 126 332 minecraft:orange_terracotta
setblock 31 126 335 minecraft:honeycomb_block
fill 31 126 336 31 126 338 minecraft:orange_terracotta
setblock 31 126 339 minecraft:honeycomb_block
fill 31 126 340 31 126 342 minecraft:orange_terracotta
setblock 31 126 343 minecraft:honeycomb_block
fill 31 126 344 33 126 344 minecraft:orange_terracotta
setblock 31 126 347 minecraft:honeycomb_block
fill 31 126 348 33 126 348 minecraft:orange_terracotta
setblock 31 126 351 minecraft:honeycomb_block
fill 31 126 352 33 126 352 minecraft:orange_terracotta
setblock 31 126 355 minecraft:honeycomb_block
fill 31 126 356 33 126 356 minecraft:orange_terracotta
setblock 31 126 359 minecraft:honeycomb_block
fill 31 126 360 33 126 360 minecraft:orange_terracotta
setblock 31 126 363 minecraft:honeycomb_block
fill 32 126 323 34 126 323 minecraft:orange_terracotta
setblock 32 126 326 minecraft:honeycomb_block
fill 32 126 327 34 126 327 minecraft:orange_terracotta
setblock 32 126 330 minecraft:honeycomb_block
fill 32 126 331 34 126 331 minecraft:orange_terracotta
setblock 32 126 334 minecraft:honeycomb_block
fill 32 126 335 32 126 337 minecraft:orange_terracotta
setblock 32 126 338 minecraft:honeycomb_block
fill 32 126 339 32 126 341 minecraft:orange_terracotta
setblock 32 126 342 minecraft:honeycomb_block
fill 32 126 343 34 126 343 minecraft:orange_terracotta
setblock 32 126 346 minecraft:honeycomb_block
fill 32 126 347 34 126 347 minecraft:orange_terracotta
setblock 32 126 350 minecraft:honeycomb_block
fill 32 126 351 34 126 351 minecraft:orange_terracotta
setblock 32 126 354 minecraft:honeycomb_block
fill 32 126 355 34 126 355 minecraft:orange_terracotta
setblock 32 126 358 minecraft:honeycomb_block
fill 32 126 359 34 126 359 minecraft:orange_terracotta
setblock 32 126 362 minecraft:honeycomb_block
fill 32 126 363 34 126 363 minecraft:orange_terracotta
setblock 33 126 325 minecraft:honeycomb_block
fill 33 126 326 35 126 326 minecraft:orange_terracotta
setblock 33 126 329 minecraft:honeycomb_block
fill 33 126 330 35 126 330 minecraft:orange_terracotta
setblock 33 126 333 minecraft:honeycomb_block
fill 33 126 334 33 126 336 minecraft:orange_terracotta
setblock 33 126 337 minecraft:honeycomb_block
fill 33 126 338 33 126 340 minecraft:orange_terracotta
setblock 33 126 341 minecraft:honeycomb_block
fill 33 126 342 35 126 342 minecraft:orange_terracotta
setblock 33 126 345 minecraft:honeycomb_block
fill 33 126 346 35 126 346 minecraft:orange_terracotta
setblock 33 126 349 minecraft:honeycomb_block
fill 33 126 350 35 126 350 minecraft:orange_terracotta
setblock 33 126 353 minecraft:honeycomb_block
fill 33 126 354 35 126 354 minecraft:orange_terracotta
setblock 33 126 357 minecraft:honeycomb_block
fill 33 126 358 35 126 358 minecraft:orange_terracotta
setblock 33 126 361 minecraft:honeycomb_block
fill 33 126 362 35 126 362 minecraft:orange_terracotta
setblock 34 126 324 minecraft:honeycomb_block
fill 34 126 325 36 126 325 minecraft:orange_terracotta
setblock 34 126 328 minecraft:honeycomb_block
fill 34 126 329 36 126 329 minecraft:orange_terracotta
setblock 34 126 332 minecraft:honeycomb_block
fill 34 126 333 34 126 335 minecraft:orange_terracotta
setblock 34 126 336 minecraft:honeycomb_block
fill 34 126 337 34 126 339 minecraft:orange_terracotta
setblock 34 126 340 minecraft:honeycomb_block
fill 34 126 341 36 126 341 minecraft:orange_terracotta
setblock 34 126 344 minecraft:honeycomb_block
fill 34 126 345 36 126 345 minecraft:orange_terracotta
setblock 34 126 348 minecraft:honeycomb_block
fill 34 126 349 36 126 349 minecraft:orange_terracotta
setblock 34 126 352 minecraft:honeycomb_block
fill 34 126 353 36 126 353 minecraft:orange_terracotta
setblock 34 126 356 minecraft:honeycomb_block
fill 34 126 357 36 126 357 minecraft:orange_terracotta
setblock 34 126 360 minecraft:honeycomb_block
fill 34 126 361 36 126 361 minecraft:orange_terracotta
setblock 35 126 323 minecraft:honeycomb_block
fill 35 126 324 37 126 324 minecraft:orange_terracotta
setblock 35 126 327 minecraft:honeycomb_block
fill 35 126 328 37 126 328 minecraft:orange_terracotta
setblock 35 126 331 minecraft:honeycomb_block
fill 35 126 332 35 126 334 minecraft:orange_terracotta
setblock 35 126 335 minecraft:honeycomb_block
fill 35 126 336 35 126 338 minecraft:orange_terracotta
setblock 35 126 339 minecraft:honeycomb_block
fill 35 126 340 37 126 340 minecraft:orange_terracotta
setblock 35 126 343 minecraft:honeycomb_block
fill 35 126 344 37 126 344 minecraft:orange_terracotta
setblock 35 126 347 minecraft:honeycomb_block
fill 35 126 348 37 126 348 minecraft:orange_terracotta
setblock 35 126 351 minecraft:honeycomb_block
fill 35 126 352 37 126 352 minecraft:orange_terracotta
setblock 35 126 355 minecraft:honeycomb_block
fill 35 126 356 37 126 356 minecraft:orange_terracotta
setblock 35 126 359 minecraft:honeycomb_block
fill 35 126 360 37 126 360 minecraft:orange_terracotta
setblock 35 126 363 minecraft:honeycomb_block
fill 36 126 323 38 126 323 minecraft:orange_terracotta
setblock 36 126 326 minecraft:honeycomb_block
fill 36 126 327 38 126 327 minecraft:orange_terracotta
setblock 36 126 330 minecraft:honeycomb_block
fill 36 126 331 36 126 333 minecraft:orange_terracotta
setblock 36 126 334 minecraft:honeycomb_block
fill 36 126 335 36 126 337 minecraft:orange_terracotta
setblock 36 126 338 minecraft:honeycomb_block
fill 36 126 339 38 126 339 minecraft:orange_terracotta
setblock 36 126 342 minecraft:honeycomb_block
fill 36 126 343 38 126 343 minecraft:orange_terracotta
setblock 36 126 346 minecraft:honeycomb_block
fill 36 126 347 38 126 347 minecraft:orange_terracotta
setblock 36 126 350 minecraft:honeycomb_block
fill 36 126 351 38 126 351 minecraft:orange_terracotta
setblock 36 126 354 minecraft:honeycomb_block
fill 36 126 355 38 126 355 minecraft:orange_terracotta
setblock 36 126 358 minecraft:honeycomb_block
fill 36 126 359 38 126 359 minecraft:orange_terracotta
setblock 36 126 362 minecraft:honeycomb_block
fill 36 126 363 38 126 363 minecraft:orange_terracotta
fill 37 126 322 37 147 322 minecraft:honeycomb_block
setblock 37 126 325 minecraft:honeycomb_block
fill 37 126 326 39 126 326 minecraft:orange_terracotta
setblock 37 126 329 minecraft:honeycomb_block
fill 37 126 330 37 126 332 minecraft:orange_terracotta
setblock 37 126 333 minecraft:honeycomb_block
fill 37 126 334 37 126 336 minecraft:orange_terracotta
setblock 37 126 337 minecraft:honeycomb_block
fill 37 126 338 39 126 338 minecraft:orange_terracotta
setblock 37 126 341 minecraft:honeycomb_block
fill 37 126 342 39 126 342 minecraft:orange_terracotta
setblock 37 126 345 minecraft:honeycomb_block
fill 37 126 346 39 126 346 minecraft:orange_terracotta
setblock 37 126 349 minecraft:honeycomb_block
fill 37 126 350 39 126 350 minecraft:orange_terracotta
setblock 37 126 353 minecraft:honeycomb_block
fill 37 126 354 39 126 354 minecraft:orange_terracotta
setblock 37 126 357 minecraft:honeycomb_block
fill 37 126 358 39 126 358 minecraft:orange_terracotta
setblock 37 126 361 minecraft:honeycomb_block
fill 37 126 362 39 126 362 minecraft:orange_terracotta
setblock 38 126 324 minecraft:honeycomb_block
fill 38 126 325 40 126 325 minecraft:orange_terracotta
setblock 38 126 328 minecraft:honeycomb_block
fill 38 126 329 38 126 331 minecraft:orange_terracotta
setblock 38 126 332 minecraft:honeycomb_block
fill 38 126 333 38 126 335 minecraft:orange_terracotta
setblock 38 126 336 minecraft:honeycomb_block
fill 38 126 337 40 126 337 minecraft:orange_terracotta
setblock 38 126 340 minecraft:honeycomb_block
fill 38 126 341 40 126 341 minecraft:orange_terracotta
setblock 38 126 344 minecraft:honeycomb_block
fill 38 126 345 40 126 345 minecraft:orange_terracotta
setblock 38 126 348 minecraft:honeycomb_block
fill 38 126 349 40 126 349 minecraft:orange_terracotta
setblock 38 126 352 minecraft:honeycomb_block
fill 38 126 353 40 126 353 minecraft:orange_terracotta
setblock 38 126 356 minecraft:honeycomb_block
fill 38 126 357 40 126 357 minecraft:orange_terracotta
setblock 38 126 360 minecraft:honeycomb_block
fill 38 126 361 40 126 361 minecraft:orange_terracotta
setblock 39 126 323 minecraft:honeycomb_block
fill 39 126 324 41 126 324 minecraft:orange_terracotta
setblock 39 126 327 minecraft:honeycomb_block
fill 39 126 328 39 126 330 minecraft:orange_terracotta
setblock 39 126 331 minecraft:honeycomb_block
fill 39 126 332 39 126 334 minecraft:orange_terracotta
setblock 39 126 335 minecraft:honeycomb_block
fill 39 126 336 41 126 336 minecraft:orange_terracotta
setblock 39 126 339 minecraft:honeycomb_block
fill 39 126 340 41 126 340 minecraft:orange_terracotta
setblock 39 126 343 minecraft:honeycomb_block
fill 39 126 344 41 126 344 minecraft:orange_terracotta
setblock 39 126 347 minecraft:honeycomb_block
fill 39 126 348 41 126 348 minecraft:orange_terracotta
setblock 39 126 351 minecraft:honeycomb_block
fill 39 126 352 41 126 352 minecraft:orange_terracotta
setblock 39 126 355 minecraft:honeycomb_block
fill 39 126 356 41 126 356 minecraft:orange_terracotta
setblock 39 126 359 minecraft:honeycomb_block
fill 39 126 360 41 126 360 minecraft:orange_terracotta
setblock 39 126 363 minecraft:honeycomb_block
fill 40 126 323 41 126 323 minecraft:orange_terracotta
setblock 40 126 326 minecraft:honeycomb_block
fill 40 126 327 40 126 329 minecraft:orange_terracotta
setblock 40 126 330 minecraft:honeycomb_block
fill 40 126 331 40 126 333 minecraft:orange_terracotta
setblock 40 126 334 minecraft:honeycomb_block
fill 40 126 335 41 126 335 minecraft:orange_terracotta
setblock 40 126 338 minecraft:honeycomb_block
fill 40 126 339 41 126 339 minecraft:orange_terracotta
setblock 40 126 342 minecraft:honeycomb_block
fill 40 126 343 41 126 343 minecraft:orange_terracotta
setblock 40 126 346 minecraft:honeycomb_block
fill 40 126 347 41 126 347 minecraft:orange_terracotta
setblock 40 126 350 minecraft:honeycomb_block
fill 40 126 351 41 126 351 minecraft:orange_terracotta
setblock 40 126 354 minecraft:honeycomb_block
fill 40 126 355 41 126 355 minecraft:orange_terracotta
setblock 40 126 358 minecraft:honeycomb_block
fill 40 126 359 41 126 359 minecraft:orange_terracotta
setblock 40 126 362 minecraft:honeycomb_block
fill 40 126 363 41 126 363 minecraft:orange_terracotta
setblock 41 126 325 minecraft:honeycomb_block
fill 41 126 326 41 126 328 minecraft:orange_terracotta
setblock 41 126 329 minecraft:honeycomb_block
fill 41 126 330 41 126 332 minecraft:orange_terracotta
setblock 41 126 333 minecraft:honeycomb_block
setblock 41 126 334 minecraft:orange_terracotta
setblock 41 126 337 minecraft:honeycomb_block
setblock 41 126 338 minecraft:orange_terracotta
setblock 41 126 341 minecraft:honeycomb_block
setblock 41 126 342 minecraft:orange_terracotta
setblock 41 126 345 minecraft:honeycomb_block
setblock 41 126 346 minecraft:orange_terracotta
setblock 41 126 349 minecraft:honeycomb_block
setblock 41 126 350 minecraft:orange_terracotta
setblock 41 126 353 minecraft:honeycomb_block
setblock 41 126 354 minecraft:orange_terracotta
setblock 41 126 357 minecraft:honeycomb_block
setblock 41 126 358 minecraft:orange_terracotta
setblock 41 126 361 minecraft:honeycomb_block
setblock 41 126 362 minecraft:orange_terracotta
fill 41 126 364 41 210 364 minecraft:honeycomb_block
setblock 42 126 356 minecraft:yellow_concrete
setblock 0 127 339 minecraft:yellow_concrete
setblock 3 127 325 minecraft:light[level=15]
setblock 3 127 333 minecraft:light[level=15]
setblock 3 127 341 minecraft:light[level=15]
setblock 3 127 349 minecraft:light[level=15]
setblock 3 127 357 minecraft:light[level=15]
setblock 11 127 325 minecraft:light[level=15]
setblock 11 127 333 minecraft:light[level=15]
setblock 11 127 341 minecraft:light[level=15]
setblock 11 127 349 minecraft:light[level=15]
setblock 11 127 357 minecraft:light[level=15]
fill 17 127 341 17 127 343 minecraft:orange_stained_glass
setblock 18 127 340 minecraft:honeycomb_block
setblock 18 127 344 minecraft:honeycomb_block
setblock 19 127 325 minecraft:light[level=15]
setblock 19 127 333 minecraft:light[level=15]
fill 19 127 339 21 127 339 minecraft:orange_stained_glass
fill 19 127 345 21 127 345 minecraft:orange_stained_glass
setblock 19 127 349 minecraft:light[level=15]
setblock 19 127 357 minecraft:light[level=15]
setblock 22 127 322 minecraft:yellow_terracotta
setblock 22 127 340 minecraft:honeycomb_block
setblock 22 127 344 minecraft:honeycomb_block
fill 23 127 341 23 127 343 minecraft:orange_stained_glass
setblock 27 127 325 minecraft:light[level=15]
setblock 27 127 333 minecraft:light[level=15]
setblock 27 127 341 minecraft:light[level=15]
setblock 27 127 349 minecraft:light[level=15]
setblock 27 127 357 minecraft:light[level=15]
setblock 28 127 322 minecraft:yellow_terracotta
setblock 35 127 325 minecraft:light[level=15]
setblock 35 127 333 minecraft:light[level=15]
setblock 35 127 341 minecraft:light[level=15]
setblock 35 127 349 minecraft:light[level=15]
setblock 35 127 357 minecraft:light[level=15]
setblock 42 127 329 minecraft:yellow_concrete
fill 42 127 356 42 229 356 minecraft:honeycomb_block
fill 0 128 339 0 132 339 minecraft:honeycomb_block
fill 0 128 357 0 172 357 minecraft:honeycomb_block
setblock 0 128 358 minecraft:yellow_concrete
setblock 20 128 322 minecraft:yellow_concrete
fill 22 128 322 22 308 322 minecraft:honeycomb_block
fill 28 128 322 28 181 322 minecraft:honeycomb_block
fill 42 128 329 42 308 329 minecraft:honeycomb_block
setblock 0 129 333 minecraft:orange_terracotta
fill 0 129 358 0 308 358 minecraft:honeycomb_block
setblock 3 129 325 minecraft:light[level=12]
setblock 3 129 332 minecraft:light[level=12]
setblock 3 129 339 minecraft:light[level=12]
setblock 3 129 346 minecraft:light[level=12]
setblock 3 129 353 minecraft:light[level=12]
setblock 3 129 360 minecraft:light[level=12]
setblock 10 129 325 minecraft:light[level=12]
setblock 10 129 332 minecraft:light[level=12]
setblock 10 129 339 minecraft:light[level=12]
setblock 10 129 346 minecraft:light[level=12]
setblock 10 129 353 minecraft:light[level=12]
setblock 10 129 360 minecraft:light[level=12]
setblock 17 129 325 minecraft:light[level=12]
setblock 17 129 332 minecraft:light[level=12]
setblock 17 129 339 minecraft:light[level=12]
setblock 17 129 346 minecraft:light[level=12]
setblock 17 129 353 minecraft:light[level=12]
setblock 17 129 360 minecraft:light[level=12]
fill 20 129 322 20 247 322 minecraft:honeycomb_block
setblock 24 129 325 minecraft:light[level=12]
setblock 24 129 332 minecraft:light[level=12]
setblock 24 129 339 minecraft:light[level=12]
setblock 24 129 346 minecraft:light[level=12]
setblock 24 129 353 minecraft:light[level=12]
setblock 24 129 360 minecraft:light[level=12]
setblock 31 129 325 minecraft:light[level=12]
setblock 31 129 332 minecraft:light[level=12]
setblock 31 129 339 minecraft:light[level=12]
setblock 31 129 346 minecraft:light[level=12]
setblock 31 129 353 minecraft:light[level=12]
setblock 31 129 360 minecraft:light[level=12]
setblock 38 129 325 minecraft:light[level=12]
setblock 38 129 332 minecraft:light[level=12]
setblock 38 129 339 minecraft:light[level=12]
setblock 38 129 346 minecraft:light[level=12]
setblock 38 129 353 minecraft:light[level=12]
setblock 38 129 360 minecraft:light[level=12]
fill 0 130 333 1 131 333 minecraft:honeycomb_block
setblock 0 130 356 minecraft:yellow_terracotta
fill 1 130 323 1 130 324 minecraft:honeycomb_block
setblock 1 130 325 minecraft:yellow_terracotta
fill 1 130 326 1 130 329 minecraft:honeycomb_block
setblock 1 130 330 minecraft:yellow_terracotta
fill 1 130 331 1 131 332 minecraft:honeycomb_block
setblock 1 130 334 minecraft:honeycomb_block
setblock 1 130 335 minecraft:yellow_terracotta
fill 1 130 336 1 130 339 minecraft:honeycomb_block
setblock 1 130 340 minecraft:yellow_terracotta
fill 1 130 341 1 130 344 minecraft:honeycomb_block
setblock 1 130 345 minecraft:yellow_terracotta
setblock 1 130 351 minecraft:honey_block
fill 1 130 357 1 130 359 minecraft:honeycomb_block
setblock 1 130 360 minecraft:yellow_terracotta
fill 1 130 361 2 130 363 minecraft:honeycomb_block
setblock 2 130 323 minecraft:honeycomb_block
setblock 2 130 324 minecraft:yellow_terracotta
fill 2 130 325 2 132 326 minecraft:honeycomb_block
setblock 2 130 359 minecraft:yellow_terracotta
fill 2 130 360 2 133 360 minecraft:honeycomb_block
setblock 3 130 323 minecraft:yellow_terracotta
fill 3 130 324 4 132 324 minecraft:honeycomb_block
setblock 3 130 362 minecraft:honeycomb_block
setblock 3 130 363 minecraft:yellow_terracotta
fill 4 130 323 7 130 323 minecraft:honeycomb_block
setblock 4 130 362 minecraft:yellow_terracotta
fill 4 130 363 7 130 363 minecraft:honeycomb_block
fill 5 130 362 8 130 362 minecraft:honeycomb_block
setblock 8 130 323 minecraft:yellow_terracotta
setblock 8 130 363 minecraft:yellow_terracotta
fill 9 130 323 12 130 323 minecraft:honeycomb_block
setblock 9 130 362 minecraft:yellow_terracotta
fill 9 130 363 12 130 363 minecraft:honeycomb_block
fill 10 130 362 13 130 362 minecraft:honeycomb_block
fill 12 130 361 14 130 361 minecraft:honeycomb_block
setblock 13 130 323 minecraft:yellow_terracotta
fill 13 130 354 15 205 356 minecraft:yellow_terracotta
setblock 13 130 363 minecraft:yellow_terracotta
fill 14 130 323 17 130 323 minecraft:honeycomb_block
setblock 14 130 362 minecraft:yellow_terracotta
fill 14 130 363 17 130 363 minecraft:honeycomb_block
setblock 15 130 361 minecraft:yellow_terracotta
fill 15 130 362 18 130 362 minecraft:honeycomb_block
setblock 16 130 324 minecraft:honeycomb_block
fill 16 130 361 19 130 361 minecraft:honeycomb_block
setblock 17 130 324 minecraft:yellow_terracotta
fill 17 130 360 17 131 360 minecraft:honeycomb_block
setblock 18 130 323 minecraft:yellow_terracotta
setblock 18 130 363 minecraft:yellow_terracotta
fill 19 130 323 22 130 323 minecraft:honeycomb_block
setblock 19 130 362 minecraft:yellow_terracotta
fill 19 130 363 22 130 363 minecraft:honeycomb_block
setblock 20 130 361 minecraft:yellow_terracotta
fill 20 130 362 23 130 362 minecraft:honeycomb_block
fill 21 130 327 21 135 327 minecraft:brown_terracotta
setblock 21 130 361 minecraft:honeycomb_block
setblock 23 130 363 minecraft:yellow_terracotta
fill 24 130 363 25 132 363 minecraft:honeycomb_block
setblock 28 130 323 minecraft:honey_block
setblock 32 130 323 minecraft:honeycomb_block
setblock 32 130 363 minecraft:honeycomb_block
setblock 33 130 323 minecraft:yellow_terracotta
setblock 33 130 363 minecraft:yellow_terracotta
fill 34 130 323 37 130 323 minecraft:honeycomb_block
fill 34 130 363 37 130 363 minecraft:honeycomb_block
fill 35 130 324 36 130 324 minecraft:honeycomb_block
fill 36 130 362 38 130 362 minecraft:honeycomb_block
setblock 37 130 324 minecraft:yellow_terracotta
setblock 38 130 323 minecraft:yellow_terracotta
fill 38 130 324 41 130 324 minecraft:honeycomb_block
setblock 38 130 338 minecraft:yellow_terracotta
fill 38 130 339 38 130 342 minecraft:honeycomb_block
setblock 38 130 363 minecraft:yellow_terracotta
fill 39 130 323 41 131 323 minecraft:honeycomb_block
fill 39 130 335 39 130 336 minecraft:honeycomb_block
setblock 39 130 337 minecraft:yellow_terracotta
fill 39 130 338 39 130 341 minecraft:honeycomb_block
setblock 39 130 342 minecraft:yellow_terracotta
fill 39 130 343 41 130 344 minecraft:honeycomb_block
setblock 39 130 362 minecraft:yellow_terracotta
fill 39 130 363 41 131 363 minecraft:honeycomb_block
setblock 40 130 325 minecraft:honeycomb_block
setblock 40 130 326 minecraft:yellow_terracotta
fill 40 130 327 40 130 330 minecraft:honeycomb_block
setblock 40 130 331 minecraft:yellow_terracotta
fill 40 130 332 40 130 335 minecraft:honeycomb_block
setblock 40 130 336 minecraft:yellow_terracotta
fill 40 130 337 40 130 340 minecraft:honeycomb_block
setblock 40 130 341 minecraft:yellow_terracotta
fill 40 130 342 41 132 342 minecraft:honeycomb_block
setblock 40 130 345 minecraft:honeycomb_block
setblock 40 130 346 minecraft:yellow_terracotta
setblock 40 130 361 minecraft:yellow_terracotta
fill 40 130 362 41 132 362 minecraft:honeycomb_block
setblock 41 130 325 minecraft:yellow_terracotta
fill 41 130 326 41 130 329 minecraft:honeycomb_block
setblock 41 130 330 minecraft:yellow_terracotta
fill 41 130 331 41 130 334 minecraft:honeycomb_block
setblock 41 130 335 minecraft:yellow_terracotta
fill 41 130 336 41 130 339 minecraft:honeycomb_block
setblock 41 130 340 minecraft:yellow_terracotta
fill 41 130 341 41 133 341 minecraft:honeycomb_block
setblock 41 130 345 minecraft:yellow_terracotta
fill 41 130 346 41 132 347 minecraft:honeycomb_block
setblock 41 130 354 minecraft:honey_block
fill 41 130 358 41 130 359 minecraft:honeycomb_block
setblock 41 130 360 minecraft:yellow_terracotta
fill 41 130 361 41 133 361 minecraft:honeycomb_block
setblock 42 130 326 minecraft:yellow_terracotta
setblock 42 130 363 minecraft:orange_terracotta
fill 0 131 356 0 264 356 minecraft:honeycomb_block
setblock 1 131 323 minecraft:honeycomb_block
setblock 1 131 324 minecraft:yellow_terracotta
fill 1 131 325 1 131 328 minecraft:honeycomb_block
setblock 1 131 329 minecraft:yellow_terracotta
fill 1 131 330 1 134 330 minecraft:honeycomb_block
setblock 1 131 334 minecraft:yellow_terracotta
fill 1 131 335 1 131 338 minecraft:honeycomb_block
setblock 1 131 339 minecraft:yellow_terracotta
fill 1 131 340 1 131 343 minecraft:honeycomb_block
setblock 1 131 344 minecraft:yellow_terracotta
fill 1 131 345 1 133 346 minecraft:honeycomb_block
fill 1 131 357 1 131 358 minecraft:honeycomb_block
setblock 1 131 359 minecraft:yellow_terracotta
fill 1 131 360 1 131 363 minecraft:honeycomb_block
setblock 2 131 323 minecraft:yellow_terracotta
fill 2 131 324 2 134 324 minecraft:honeycomb_block
setblock 2 131 359 minecraft:honeycomb_block
fill 2 131 361 2 131 362 minecraft:honeycomb_block
setblock 2 131 363 minecraft:yellow_terracotta
fill 3 131 323 6 131 323 minecraft:honeycomb_block
setblock 3 131 362 minecraft:yellow_terracotta
fill 3 131 363 6 131 363 minecraft:honeycomb_block
fill 4 131 362 7 131 362 minecraft:honeycomb_block
setblock 7 131 323 minecraft:yellow_terracotta
setblock 7 131 363 minecraft:yellow_terracotta
fill 8 131 323 11 131 323 minecraft:honeycomb_block
setblock 8 131 362 minecraft:yellow_terracotta
fill 8 131 363 11 131 363 minecraft:honeycomb_block
fill 9 131 362 12 131 362 minecraft:honeycomb_block
fill 11 131 361 13 131 361 minecraft:honeycomb_block
setblock 12 131 323 minecraft:yellow_terracotta
fill 12 131 354 12 132 356 minecraft:brown_terracotta
setblock 12 131 363 minecraft:yellow_terracotta
setblock 13 131 322 minecraft:yellow_concrete
fill 13 131 323 15 131 324 minecraft:honeycomb_block
fill 13 131 353 15 132 353 minecraft:brown_terracotta
fill 13 131 357 15 132 357 minecraft:brown_terracotta
setblock 13 131 362 minecraft:yellow_terracotta
fill 13 131 363 16 131 363 minecraft:honeycomb_block
setblock 14 131 361 minecraft:yellow_terracotta
fill 14 131 362 17 131 362 minecraft:honeycomb_block
fill 15 131 361 18 131 361 minecraft:honeycomb_block
setblock 16 131 323 minecraft:honeycomb_block
setblock 16 131 324 minecraft:yellow_terracotta
fill 16 131 354 16 132 356 minecraft:brown_terracotta
fill 16 131 360 16 132 360 minecraft:honeycomb_block
setblock 17 131 323 minecraft:yellow_terracotta
fill 17 131 324 19 132 324 minecraft:honeycomb_block
setblock 17 131 363 minecraft:yellow_terracotta
fill 18 131 323 21 131 323 minecraft:honeycomb_block
setblock 18 131 362 minecraft:yellow_terracotta
fill 18 131 363 21 131 363 minecraft:honeycomb_block
setblock 18 131 364 minecraft:yellow_concrete
setblock 19 131 361 minecraft:yellow_terracotta
fill 19 131 362 22 131 362 minecraft:honeycomb_block
fill 20 131 361 20 132 361 minecraft:honeycomb_block
setblock 22 131 323 minecraft:yellow_terracotta
setblock 22 131 363 minecraft:yellow_terracotta
setblock 23 131 362 minecraft:yellow_terracotta
fill 23 131 363 23 134 363 minecraft:honeycomb_block
setblock 31 131 323 minecraft:honeycomb_block
setblock 31 131 363 minecraft:honeycomb_block
setblock 32 131 323 minecraft:yellow_terracotta
setblock 32 131 363 minecraft:yellow_terracotta
fill 33 131 323 35 131 324 minecraft:honeycomb_block
fill 33 131 363 36 131 363 minecraft:honeycomb_block
fill 35 131 362 37 131 362 minecraft:honeycomb_block
setblock 36 131 323 minecraft:honeycomb_block
setblock 36 131 324 minecraft:yellow_terracotta
fill 36 131 325 39 131 325 minecraft:honeycomb_block
setblock 37 131 323 minecraft:yellow_terracotta
fill 37 131 324 40 131 324 minecraft:honeycomb_block
setblock 37 131 363 minecraft:yellow_terracotta
fill 38 131 323 38 134 323 minecraft:honeycomb_block
fill 38 131 339 38 131 341 minecraft:honeycomb_block
setblock 38 131 342 minecraft:yellow_terracotta
fill 38 131 343 41 131 343 minecraft:honeycomb_block
setblock 38 131 362 minecraft:yellow_terracotta
fill 38 131 363 38 134 363 minecraft:honeycomb_block
setblock 39 131 326 minecraft:yellow_terracotta
setblock 39 131 335 minecraft:honeycomb_block
setblock 39 131 336 minecraft:yellow_terracotta
fill 39 131 337 39 131 340 minecraft:honeycomb_block
setblock 39 131 341 minecraft:yellow_terracotta
fill 39 131 342 39 134 342 minecraft:honeycomb_block
fill 39 131 344 39 131 345 minecraft:honeycomb_block
fill 39 131 362 39 134 362 minecraft:honeycomb_block
setblock 40 131 325 minecraft:yellow_terracotta
fill 40 131 326 40 131 329 minecraft:honeycomb_block
setblock 40 131 330 minecraft:yellow_terracotta
fill 40 131 331 40 131 334 minecraft:honeycomb_block
setblock 40 131 335 minecraft:yellow_terracotta
fill 40 131 336 40 131 339 minecraft:honeycomb_block
setblock 40 131 340 minecraft:yellow_terracotta
fill 40 131 341 40 134 341 minecraft:honeycomb_block
setblock 40 131 344 minecraft:honeycomb_block
setblock 40 131 345 minecraft:yellow_terracotta
fill 40 131 346 40 134 346 minecraft:honeycomb_block
fill 40 131 361 40 133 361 minecraft:honeycomb_block
setblock 40 131 364 minecraft:orange_terracotta
setblock 41 131 322 minecraft:yellow_terracotta
setblock 41 131 324 minecraft:yellow_terracotta
fill 41 131 325 41 131 328 minecraft:honeycomb_block
setblock 41 131 329 minecraft:yellow_terracotta
fill 41 131 330 41 131 333 minecraft:honeycomb_block
setblock 41 131 334 minecraft:yellow_terracotta
fill 41 131 335 41 131 338 minecraft:honeycomb_block
setblock 41 131 339 minecraft:yellow_terracotta
fill 41 131 340 41 134 340 minecraft:honeycomb_block
setblock 41 131 344 minecraft:yellow_terracotta
fill 41 131 345 41 134 345 minecraft:honeycomb_block
setblock 41 131 348 minecraft:honeycomb_block
setblock 41 131 359 minecraft:yellow_terracotta
fill 41 131 360 41 134 360 minecraft:honeycomb_block
fill 42 131 326 42 134 326 minecraft:honeycomb_block
fill 42 131 363 42 194 363 minecraft:honeycomb_block
fill 0 132 333 0 150 333 minecraft:honeycomb_block
setblock 1 132 323 minecraft:yellow_terracotta
fill 1 132 324 1 132 327 minecraft:honeycomb_block
setblock 1 132 328 minecraft:yellow_terracotta
fill 1 132 329 1 135 329 minecraft:honeycomb_block
fill 1 132 331 1 133 331 minecraft:honeycomb_block
fill 1 132 336 1 132 337 minecraft:honeycomb_block
setblock 1 132 338 minecraft:yellow_terracotta
fill 1 132 339 1 132 342 minecraft:honeycomb_block
setblock 1 132 343 minecraft:yellow_terracotta
fill 1 132 344 1 135 344 minecraft:honeycomb_block
setblock 1 132 347 minecraft:honeycomb_block
setblock 1 132 357 minecraft:honeycomb_block
setblock 1 132 358 minecraft:yellow_terracotta
fill 1 132 359 1 132 362 minecraft:honeycomb_block
setblock 1 132 363 minecraft:yellow_terracotta
fill 2 132 323 5 132 323 minecraft:honeycomb_block
setblock 2 132 327 minecraft:yellow_terracotta
setblock 2 132 361 minecraft:honeycomb_block
setblock 2 132 362 minecraft:yellow_terracotta
fill 2 132 363 5 132 363 minecraft:honeycomb_block
fill 3 132 362 6 132 362 minecraft:honeycomb_block
setblock 5 132 324 minecraft:yellow_terracotta
setblock 6 132 323 minecraft:yellow_terracotta
setblock 6 132 363 minecraft:yellow_terracotta
fill 7 132 323 10 132 323 minecraft:honeycomb_block
setblock 7 132 362 minecraft:yellow_terracotta
fill 7 132 363 10 132 363 minecraft:honeycomb_block
fill 8 132 362 11 132 362 minecraft:honeycomb_block
setblock 10 132 324 minecraft:yellow_terracotta
fill 10 132 361 12 132 361 minecraft:honeycomb_block
setblock 11 132 323 minecraft:yellow_terracotta
fill 11 132 324 14 132 324 minecraft:honeycomb_block
setblock 11 132 355 minecraft:brown_terracotta
setblock 11 132 363 minecraft:yellow_terracotta
fill 12 132 323 15 132 323 minecraft:honeycomb_block
setblock 12 132 353 minecraft:brown_terracotta
setblock 12 132 357 minecraft:brown_terracotta
setblock 12 132 362 minecraft:yellow_terracotta
fill 12 132 363 15 132 363 minecraft:honeycomb_block
fill 13 132 322 13 138 322 minecraft:honeycomb_block
setblock 13 132 361 minecraft:yellow_terracotta
fill 13 132 362 16 132 362 minecraft:honeycomb_block
fill 14 132 352 15 132 352 minecraft:brown_terracotta
setblock 14 132 358 minecraft:brown_terracotta
fill 14 132 361 17 132 361 minecraft:honeycomb_block
setblock 15 132 324 minecraft:yellow_terracotta
fill 15 132 360 15 133 360 minecraft:honeycomb_block
setblock 15 132 364 minecraft:orange_terracotta
setblock 16 132 323 minecraft:yellow_terracotta
fill 16 132 324 16 135 324 minecraft:honeycomb_block
setblock 16 132 353 minecraft:brown_terracotta
setblock 16 132 357 minecraft:brown_terracotta
setblock 16 132 363 minecraft:yellow_terracotta
fill 17 132 323 20 132 323 minecraft:honeycomb_block
fill 17 132 354 17 132 355 minecraft:brown_terracotta
setblock 17 132 362 minecraft:yellow_terracotta
fill 17 132 363 20 132 363 minecraft:honeycomb_block
setblock 18 132 361 minecraft:yellow_terracotta
fill 18 132 362 21 132 362 minecraft:honeycomb_block
fill 18 132 364 18 236 364 minecraft:honeycomb_block
fill 19 132 361 19 133 361 minecraft:honeycomb_block
fill 20 132 327 20 135 327 minecraft:brown_terracotta
setblock 21 132 323 minecraft:yellow_terracotta
fill 21 132 326 21 135 326 minecraft:brown_terracotta
fill 21 132 328 21 135 328 minecraft:brown_terracotta
setblock 21 132 363 minecraft:yellow_terracotta
fill 22 132 323 23 134 323 minecraft:honeycomb_block
fill 22 132 327 22 135 327 minecraft:brown_terracotta
setblock 22 132 362 minecraft:yellow_terracotta
fill 22 132 363 22 135 363 minecraft:honeycomb_block
setblock 26 132 363 minecraft:honey_block
fill 29 132 323 30 132 323 minecraft:honeycomb_block
setblock 30 132 363 minecraft:honeycomb_block
setblock 31 132 323 minecraft:yellow_terracotta
setblock 31 132 363 minecraft:yellow_terracotta
fill 32 132 323 34 132 324 minecraft:honeycomb_block
fill 32 132 363 35 132 363 minecraft:honeycomb_block
setblock 34 132 325 minecraft:yellow_terracotta
fill 34 132 362 36 132 362 minecraft:honeycomb_block
setblock 35 132 323 minecraft:honeycomb_block
setblock 35 132 324 minecraft:yellow_terracotta
fill 35 132 325 38 132 325 minecraft:honeycomb_block
setblock 36 132 323 minecraft:yellow_terracotta
fill 36 132 324 39 132 324 minecraft:honeycomb_block
setblock 36 132 363 minecraft:yellow_terracotta
fill 37 132 323 37 135 323 minecraft:honeycomb_block
setblock 37 132 362 minecraft:yellow_terracotta
fill 37 132 363 37 135 363 minecraft:honeycomb_block
fill 38 132 339 38 132 340 minecraft:honeycomb_block
setblock 38 132 341 minecraft:yellow_terracotta
fill 38 132 342 38 134 343 minecraft:honeycomb_block
fill 38 132 362 38 135 362 minecraft:honeycomb_block
fill 39 132 323 40 132 323 minecraft:honeycomb_block
setblock 39 132 325 minecraft:yellow_terracotta
fill 39 132 326 40 132 328 minecraft:honeycomb_block
fill 39 132 336 39 132 339 minecraft:honeycomb_block
setblock 39 132 340 minecraft:yellow_terracotta
fill 39 132 341 39 135 341 minecraft:honeycomb_block
fill 39 132 343 39 132 344 minecraft:honeycomb_block
setblock 39 132 345 minecraft:yellow_terracotta
fill 39 132 363 40 132 363 minecraft:honeycomb_block
setblock 40 132 324 minecraft:yellow_terracotta
fill 40 132 325 41 134 325 minecraft:honeycomb_block
setblock 40 132 329 minecraft:yellow_terracotta
fill 40 132 330 40 132 333 minecraft:honeycomb_block
setblock 40 132 334 minecraft:yellow_terracotta
fill 40 132 335 40 132 338 minecraft:honeycomb_block
setblock 40 132 339 minecraft:yellow_terracotta
fill 40 132 340 40 135 340 minecraft:honeycomb_block
setblock 40 132 343 minecraft:honeycomb_block
setblock 40 132 344 minecraft:yellow_terracotta
fill 40 132 345 40 135 345 minecraft:honeycomb_block
fill 40 132 347 40 133 347 minecraft:honeycomb_block
fill 40 132 364 40 175 364 minecraft:honeycomb_block
fill 41 132 322 41 203 322 minecraft:honeycomb_block
setblock 41 132 323 minecraft:yellow_terracotta
fill 41 132 324 41 135 324 minecraft:honeycomb_block
fill 41 132 326 41 132 327 minecraft:honeycomb_block
setblock 41 132 328 minecraft:yellow_terracotta
fill 41 132 329 41 132 332 minecraft:honeycomb_block
setblock 41 132 333 minecraft:yellow_terracotta
fill 41 132 334 41 132 337 minecraft:honeycomb_block
setblock 41 132 338 minecraft:yellow_terracotta
fill 41 132 339 41 135 339 minecraft:honeycomb_block
setblock 41 132 343 minecraft:yellow_terracotta
fill 41 132 344 41 135 344 minecraft:honeycomb_block
setblock 41 132 348 minecraft:yellow_terracotta
fill 41 132 359 41 133 359 minecraft:honeycomb_block
setblock 41 132 363 minecraft:yellow_terracotta
setblock 0 133 327 minecraft:yellow_concrete
setblock 0 133 339 minecraft:orange_terracotta
fill 0 133 348 1 136 348 minecraft:honeycomb_block
setblock 0 133 349 minecraft:yellow_terracotta
fill 1 133 323 1 133 326 minecraft:honeycomb_block
setblock 1 133 327 minecraft:yellow_terracotta
fill 1 133 328 1 136 328 minecraft:honeycomb_block
fill 1 133 338 1 133 341 minecraft:honeycomb_block
setblock 1 133 342 minecraft:yellow_terracotta
fill 1 133 343 1 136 343 minecraft:honeycomb_block
setblock 1 133 347 minecraft:yellow_terracotta
setblock 1 133 350 minecraft:honey_block
setblock 1 133 357 minecraft:yellow_terracotta
fill 1 133 358 1 133 361 minecraft:honeycomb_block
setblock 1 133 362 minecraft:yellow_terracotta
fill 1 133 363 4 133 363 minecraft:honeycomb_block
fill 2 133 323 4 133 323 minecraft:honeycomb_block
setblock 2 133 325 minecraft:honeycomb_block
setblock 2 133 326 minecraft:yellow_terracotta
fill 2 133 327 2 136 327 minecraft:honeycomb_block
setblock 2 133 361 minecraft:yellow_terracotta
fill 2 133 362 5 133 362 minecraft:honeycomb_block
setblock 3 133 324 minecraft:honeycomb_block
setblock 4 133 324 minecraft:yellow_terracotta
setblock 5 133 323 minecraft:yellow_terracotta
fill 5 133 324 8 133 324 minecraft:honeycomb_block
setblock 5 133 363 minecraft:yellow_terracotta
fill 6 133 323 9 133 323 minecraft:honeycomb_block
setblock 6 133 362 minecraft:yellow_terracotta
fill 6 133 363 9 133 363 minecraft:honeycomb_block
fill 7 133 362 10 133 362 minecraft:honeycomb_block
setblock 9 133 324 minecraft:yellow_terracotta
setblock 10 133 323 minecraft:yellow_terracotta
fill 10 133 324 13 133 324 minecraft:honeycomb_block
fill 10 133 361 11 133 361 minecraft:honeycomb_block
setblock 10 133 363 minecraft:yellow_terracotta
fill 11 133 323 14 133 323 minecraft:honeycomb_block
setblock 11 133 362 minecraft:yellow_terracotta
fill 11 133 363 14 133 363 minecraft:honeycomb_block
setblock 12 133 361 minecraft:yellow_terracotta
fill 12 133 362 15 133 362 minecraft:honeycomb_block
fill 13 133 361 16 133 361 minecraft:honeycomb_block
setblock 14 133 324 minecraft:yellow_terracotta
setblock 15 133 323 minecraft:yellow_terracotta
fill 15 133 324 15 136 324 minecraft:honeycomb_block
setblock 15 133 363 minecraft:yellow_terracotta
fill 15 133 364 15 173 364 minecraft:honeycomb_block
fill 16 133 323 19 133 323 minecraft:honeycomb_block
setblock 16 133 362 minecraft:yellow_terracotta
fill 16 133 363 19 133 363 minecraft:honeycomb_block
fill 17 133 324 18 133 324 minecraft:honeycomb_block
setblock 17 133 361 minecraft:yellow_terracotta
fill 17 133 362 20 133 362 minecraft:honeycomb_block
fill 18 133 361 18 134 361 minecraft:honeycomb_block
setblock 19 133 324 minecraft:yellow_terracotta
setblock 20 133 323 minecraft:yellow_terracotta
fill 20 133 324 20 135 324 minecraft:honeycomb_block
setblock 20 133 363 minecraft:yellow_terracotta
fill 21 133 323 21 136 323 minecraft:honeycomb_block
setblock 21 133 362 minecraft:yellow_terracotta
fill 21 133 363 21 136 363 minecraft:honeycomb_block
setblock 22 133 362 minecraft:honeycomb_block
setblock 24 133 323 minecraft:honeycomb_block
setblock 24 133 363 minecraft:honeycomb_block
setblock 25 133 363 minecraft:yellow_terracotta
fill 27 133 323 29 133 323 minecraft:honeycomb_block
setblock 29 133 322 minecraft:yellow_concrete
setblock 29 133 363 minecraft:honeycomb_block
setblock 30 133 323 minecraft:yellow_terracotta
setblock 30 133 363 minecraft:yellow_terracotta
fill 31 133 323 33 133 324 minecraft:honeycomb_block
fill 31 133 363 34 133 363 minecraft:honeycomb_block
setblock 33 133 325 minecraft:yellow_terracotta
fill 33 133 362 35 133 362 minecraft:honeycomb_block
setblock 34 133 323 minecraft:honeycomb_block
setblock 34 133 324 minecraft:yellow_terracotta
fill 34 133 325 37 133 325 minecraft:honeycomb_block
setblock 35 133 323 minecraft:yellow_terracotta
fill 35 133 324 38 133 324 minecraft:honeycomb_block
setblock 35 133 363 minecraft:yellow_terracotta
fill 36 133 323 36 136 323 minecraft:honeycomb_block
setblock 36 133 326 minecraft:honeycomb_block
setblock 36 133 362 minecraft:yellow_terracotta
fill 36 133 363 36 136 363 minecraft:honeycomb_block
setblock 37 133 326 minecraft:yellow_terracotta
fill 37 133 362 37 136 362 minecraft:honeycomb_block
setblock 38 133 325 minecraft:yellow_terracotta
fill 38 133 326 41 133 326 minecraft:honeycomb_block
setblock 38 133 340 minecraft:yellow_terracotta
setblock 38 133 341 minecraft:honeycomb_block
setblock 38 133 344 minecraft:honeycomb_block
setblock 39 133 323 minecraft:honeycomb_block
setblock 39 133 324 minecraft:yellow_terracotta
fill 39 133 325 39 136 325 minecraft:honeycomb_block
fill 39 133 327 39 133 328 minecraft:honeycomb_block
setblock 39 133 329 minecraft:yellow_terracotta
fill 39 133 337 39 133 338 minecraft:honeycomb_block
setblock 39 133 339 minecraft:yellow_terracotta
fill 39 133 340 39 134 340 minecraft:honeycomb_block
setblock 39 133 343 minecraft:honeycomb_block
setblock 39 133 344 minecraft:yellow_terracotta
fill 39 133 345 39 134 346 minecraft:honeycomb_block
setblock 39 133 363 minecraft:honeycomb_block
setblock 40 133 323 minecraft:yellow_terracotta
fill 40 133 324 40 136 324 minecraft:honeycomb_block
setblock 40 133 327 minecraft:honeycomb_block
setblock 40 133 328 minecraft:yellow_terracotta
fill 40 133 329 40 133 332 minecraft:honeycomb_block
setblock 40 133 333 minecraft:yellow_terracotta
fill 40 133 334 40 133 337 minecraft:honeycomb_block
setblock 40 133 338 minecraft:yellow_terracotta
fill 40 133 339 40 135 339 minecraft:honeycomb_block
setblock 40 133 342 minecraft:honeycomb_block
setblock 40 133 343 minecraft:yellow_terracotta
fill 40 133 344 40 136 344 minecraft:honeycomb_block
setblock 40 133 362 minecraft:honeycomb_block
setblock 40 133 363 minecraft:yellow_terracotta
fill 41 133 323 41 136 323 minecraft:honeycomb_block
setblock 41 133 327 minecraft:yellow_terracotta
fill 41 133 328 41 133 331 minecraft:honeycomb_block
setblock 41 133 332 minecraft:yellow_terracotta
fill 41 133 333 41 133 336 minecraft:honeycomb_block
setblock 41 133 337 minecraft:yellow_terracotta
fill 41 133 338 41 136 338 minecraft:honeycomb_block
setblock 41 133 342 minecraft:yellow_terracotta
fill 41 133 343 41 136 343 minecraft:honeycomb_block
setblock 41 133 346 minecraft:honeycomb_block
setblock 41 133 347 minecraft:yellow_terracotta
fill 41 133 348 41 135 349 minecraft:honeycomb_block
setblock 41 133 362 minecraft:yellow_terracotta
fill 41 133 363 41 136 363 minecraft:honeycomb_block
setblock 42 133 332 minecraft:yellow_concrete
fill 0 134 327 1 137 327 minecraft:honeycomb_block
fill 0 134 339 1 134 339 minecraft:honeycomb_block
fill 0 134 349 1 135 349 minecraft:honeycomb_block
fill 1 134 323 1 134 325 minecraft:honeycomb_block
setblock 1 134 326 minecraft:yellow_terracotta
setblock 1 134 331 minecraft:yellow_terracotta
setblock 1 134 340 minecraft:honeycomb_block
setblock 1 134 341 minecraft:yellow_terracotta
fill 1 134 342 1 135 342 minecraft:honeycomb_block
setblock 1 134 345 minecraft:honeycomb_block
setblock 1 134 346 minecraft:yellow_terracotta
fill 1 134 347 1 137 347 minecraft:honeycomb_block
setblock 1 134 356 minecraft:honey_block
fill 1 134 357 1 134 360 minecraft:honeycomb_block
setblock 1 134 361 minecraft:yellow_terracotta
fill 1 134 362 3 134 363 minecraft:honeycomb_block
fill 2 134 323 3 134 323 minecraft:honeycomb_block
setblock 2 134 325 minecraft:yellow_terracotta
fill 2 134 326 2 137 326 minecraft:honeycomb_block
setblock 2 134 360 minecraft:yellow_terracotta
fill 2 134 361 2 135 361 minecraft:honeycomb_block
setblock 3 134 324 minecraft:yellow_terracotta
setblock 4 134 323 minecraft:yellow_terracotta
fill 4 134 324 7 134 324 minecraft:honeycomb_block
setblock 4 134 362 minecraft:honeycomb_block
setblock 4 134 363 minecraft:yellow_terracotta
fill 5 134 323 8 134 323 minecraft:honeycomb_block
setblock 5 134 362 minecraft:yellow_terracotta
fill 5 134 363 8 134 363 minecraft:honeycomb_block
fill 6 134 362 9 134 362 minecraft:honeycomb_block
setblock 8 134 324 minecraft:yellow_terracotta
setblock 9 134 323 minecraft:yellow_terracotta
fill 9 134 324 12 134 324 minecraft:honeycomb_block
setblock 9 134 363 minecraft:yellow_terracotta
fill 10 134 323 13 134 323 minecraft:honeycomb_block
setblock 10 134 361 minecraft:honeycomb_block
setblock 10 134 362 minecraft:yellow_terracotta
fill 10 134 363 13 134 363 minecraft:honeycomb_block
setblock 11 134 361 minecraft:yellow_terracotta
fill 11 134 362 14 134 362 minecraft:honeycomb_block
fill 12 134 361 15 134 361 minecraft:honeycomb_block
setblock 13 134 324 minecraft:yellow_terracotta
fill 13 134 325 16 134 325 minecraft:honeycomb_block
setblock 14 134 323 minecraft:yellow_terracotta
fill 14 134 324 14 137 324 minecraft:honeycomb_block
setblock 14 134 363 minecraft:yellow_terracotta
fill 15 134 323 18 134 323 minecraft:honeycomb_block
setblock 15 134 362 minecraft:yellow_terracotta
fill 15 134 363 18 134 363 minecraft:honeycomb_block
setblock 16 134 361 minecraft:yellow_terracotta
fill 16 134 362 19 134 362 minecraft:honeycomb_block
setblock 17 134 324 minecraft:honeycomb_block
fill 17 134 361 17 135 361 minecraft:honeycomb_block
setblock 18 134 324 minecraft:yellow_terracotta
setblock 19 134 323 minecraft:yellow_terracotta
fill 19 134 324 19 136 324 minecraft:honeycomb_block
setblock 19 134 363 minecraft:yellow_terracotta
fill 20 134 323 20 137 323 minecraft:honeycomb_block
fill 20 134 326 20 135 326 minecraft:brown_terracotta
fill 20 134 328 20 135 328 minecraft:brown_terracotta
setblock 20 134 362 minecraft:yellow_terracotta
fill 20 134 363 20 137 363 minecraft:honeycomb_block
setblock 21 134 362 minecraft:honeycomb_block
fill 22 134 326 22 135 326 minecraft:brown_terracotta
fill 22 134 328 22 135 328 minecraft:brown_terracotta
setblock 24 134 323 minecraft:yellow_terracotta
setblock 24 134 363 minecraft:yellow_terracotta
fill 25 134 323 28 134 323 minecraft:honeycomb_block
setblock 28 134 363 minecraft:honeycomb_block
fill 29 134 322 29 174 322 minecraft:honeycomb_block
setblock 29 134 323 minecraft:yellow_terracotta
fill 29 134 324 32 134 324 minecraft:honeycomb_block
setblock 29 134 363 minecraft:yellow_terracotta
fill 30 134 323 33 134 323 minecraft:honeycomb_block
fill 30 134 363 33 134 363 minecraft:honeycomb_block
fill 31 134 331 33 135 331 minecraft:yellow_concrete
setblock 32 134 325 minecraft:yellow_terracotta
fill 32 134 330 32 135 330 minecraft:yellow_concrete
setblock 33 134 324 minecraft:yellow_terracotta
fill 33 134 325 36 134 325 minecraft:honeycomb_block
fill 33 134 362 34 134 362 minecraft:honeycomb_block
setblock 34 134 323 minecraft:yellow_terracotta
fill 34 134 324 37 134 324 minecraft:honeycomb_block
fill 34 134 326 35 134 326 minecraft:honeycomb_block
setblock 34 134 363 minecraft:yellow_terracotta
fill 35 134 323 35 137 323 minecraft:honeycomb_block
setblock 35 134 362 minecraft:yellow_terracotta
fill 35 134 363 35 137 363 minecraft:honeycomb_block
setblock 36 134 326 minecraft:yellow_terracotta
fill 36 134 362 36 136 362 minecraft:honeycomb_block
setblock 37 134 325 minecraft:yellow_terracotta
fill 37 134 326 40 134 326 minecraft:honeycomb_block
setblock 38 134 324 minecraft:yellow_terracotta
fill 38 134 325 38 137 325 minecraft:honeycomb_block
fill 38 134 327 39 134 327 minecraft:honeycomb_block
setblock 39 134 323 minecraft:yellow_terracotta
fill 39 134 324 39 137 324 minecraft:honeycomb_block
setblock 39 134 328 minecraft:yellow_terracotta
fill 39 134 329 41 134 330 minecraft:honeycomb_block
setblock 39 134 338 minecraft:yellow_terracotta
setblock 39 134 339 minecraft:honeycomb_block
setblock 39 134 343 minecraft:yellow_terracotta
fill 39 134 344 39 135 344 minecraft:honeycomb_block
setblock 39 134 363 minecraft:yellow_terracotta
fill 40 134 323 40 137 323 minecraft:honeycomb_block
setblock 40 134 327 minecraft:yellow_terracotta
fill 40 134 328 41 136 328 minecraft:honeycomb_block
setblock 40 134 331 minecraft:honeycomb_block
setblock 40 134 332 minecraft:yellow_terracotta
fill 40 134 333 40 134 336 minecraft:honeycomb_block
setblock 40 134 337 minecraft:yellow_terracotta
fill 40 134 338 40 135 338 minecraft:honeycomb_block
setblock 40 134 342 minecraft:yellow_terracotta
fill 40 134 343 40 136 343 minecraft:honeycomb_block
setblock 40 134 347 minecraft:yellow_terracotta
setblock 40 134 348 minecraft:honeycomb_block
setblock 40 134 362 minecraft:yellow_terracotta
fill 40 134 363 40 137 363 minecraft:honeycomb_block
setblock 41 134 326 minecraft:yellow_terracotta
fill 41 134 327 41 137 327 minecraft:honeycomb_block
setblock 41 134 331 minecraft:yellow_terracotta
fill 41 134 332 41 134 335 minecraft:honeycomb_block
setblock 41 134 336 minecraft:yellow_terracotta
fill 41 134 337 41 136 337 minecraft:honeycomb_block
setblock 41 134 341 minecraft:yellow_terracotta
fill 41 134 342 41 137 342 minecraft:honeycomb_block
setblock 41 134 346 minecraft:yellow_terracotta
fill 41 134 347 41 137 347 minecraft:honeycomb_block
setblock 41 134 355 minecraft:honey_block
setblock 41 134 361 minecraft:yellow_terracotta
fill 41 134 362 41 137 362 minecraft:honeycomb_block
fill 42 134 332 42 211 332 minecraft:honeycomb_block
setblock 0 135 332 minecraft:yellow_concrete
fill 0 135 339 0 250 339 minecraft:honeycomb_block
fill 1 135 323 1 135 324 minecraft:honeycomb_block
setblock 1 135 325 minecraft:yellow_terracotta
fill 1 135 326 1 138 326 minecraft:honeycomb_block
setblock 1 135 330 minecraft:yellow_terracotta
setblock 1 135 331 minecraft:honeycomb_block
setblock 1 135 337 minecraft:honey_block
setblock 1 135 341 minecraft:honeycomb_block
setblock 1 135 345 minecraft:yellow_terracotta
fill 1 135 346 1 137 346 minecraft:honeycomb_block
setblock 1 135 350 minecraft:yellow_terracotta
fill 1 135 358 1 135 359 minecraft:honeycomb_block
setblock 1 135 360 minecraft:yellow_terracotta
fill 1 135 361 1 136 363 minecraft:honeycomb_block
setblock 2 135 323 minecraft:honeycomb_block
setblock 2 135 324 minecraft:yellow_terracotta
fill 2 135 325 2 138 325 minecraft:honeycomb_block
fill 2 135 362 2 135 363 minecraft:honeycomb_block
setblock 3 135 323 minecraft:yellow_terracotta
fill 3 135 324 6 135 324 minecraft:honeycomb_block
setblock 3 135 325 minecraft:light[level=15]
setblock 3 135 332 minecraft:light[level=12]
setblock 3 135 333 minecraft:light[level=15]
setblock 3 135 339 minecraft:light[level=12]
setblock 3 135 341 minecraft:light[level=15]
setblock 3 135 346 minecraft:light[level=12]
setblock 3 135 349 minecraft:light[level=15]
setblock 3 135 353 minecraft:light[level=12]
setblock 3 135 357 minecraft:light[level=15]
setblock 3 135 360 minecraft:light[level=12]
setblock 3 135 362 minecraft:honeycomb_block
setblock 3 135 363 minecraft:yellow_terracotta
fill 4 135 323 7 135 323 minecraft:honeycomb_block
setblock 4 135 362 minecraft:yellow_terracotta
fill 4 135 363 7 135 363 minecraft:honeycomb_block
fill 5 135 362 8 135 362 minecraft:honeycomb_block
setblock 7 135 324 minecraft:yellow_terracotta
setblock 8 135 323 minecraft:yellow_terracotta
fill 8 135 324 11 135 324 minecraft:honeycomb_block
setblock 8 135 363 minecraft:yellow_terracotta
setblock 8 135 364 minecraft:yellow_concrete
fill 9 135 323 12 135 323 minecraft:honeycomb_block
setblock 9 135 362 minecraft:yellow_terracotta
fill 9 135 363 9 138 364 minecraft:honeycomb_block
setblock 10 135 325 minecraft:light[level=12]
setblock 10 135 332 minecraft:light[level=12]
setblock 10 135 339 minecraft:light[level=12]
setblock 10 135 346 minecraft:light[level=12]
setblock 10 135 353 minecraft:light[level=12]
setblock 10 135 360 minecraft:light[level=12]
setblock 10 135 361 minecraft:yellow_terracotta
fill 10 135 362 12 135 363 minecraft:honeycomb_block
setblock 11 135 325 minecraft:light[level=15]
setblock 11 135 333 minecraft:light[level=15]
setblock 11 135 341 minecraft:light[level=15]
setblock 11 135 349 minecraft:light[level=15]
setblock 11 135 357 minecraft:light[level=15]
fill 11 135 361 14 135 361 minecraft:honeycomb_block
setblock 12 135 324 minecraft:yellow_terracotta
fill 12 135 325 15 135 325 minecraft:honeycomb_block
setblock 13 135 323 minecraft:yellow_terracotta
fill 13 135 324 13 138 324 minecraft:honeycomb_block
setblock 13 135 362 minecraft:honeycomb_block
setblock 13 135 363 minecraft:yellow_terracotta
fill 14 135 323 17 135 323 minecraft:honeycomb_block
setblock 14 135 362 minecraft:yellow_terracotta
fill 14 135 363 17 135 363 minecraft:honeycomb_block
setblock 14 135 364 minecraft:yellow_concrete
setblock 15 135 361 minecraft:yellow_terracotta
fill 15 135 362 18 135 362 minecraft:honeycomb_block
setblock 16 135 325 minecraft:yellow_terracotta
fill 16 135 361 16 136 361 minecraft:honeycomb_block
setblock 16 135 364 minecraft:yellow_terracotta
setblock 17 135 322 minecraft:orange_terracotta
setblock 17 135 324 minecraft:yellow_terracotta
setblock 17 135 325 minecraft:light[level=12]
setblock 17 135 332 minecraft:light[level=12]
setblock 17 135 339 minecraft:light[level=12]
setblock 17 135 346 minecraft:light[level=12]
setblock 17 135 353 minecraft:light[level=12]
setblock 17 135 360 minecraft:light[level=12]
setblock 18 135 323 minecraft:yellow_terracotta
fill 18 135 324 18 137 324 minecraft:honeycomb_block
setblock 18 135 363 minecraft:yellow_terracotta
fill 19 135 323 19 138 323 minecraft:honeycomb_block
setblock 19 135 325 minecraft:light[level=15]
setblock 19 135 333 minecraft:light[level=15]
setblock 19 135 341 minecraft:light[level=15]
setblock 19 135 349 minecraft:light[level=15]
setblock 19 135 357 minecraft:light[level=15]
setblock 19 135 362 minecraft:yellow_terracotta
fill 19 135 363 19 137 363 minecraft:honeycomb_block
setblock 20 135 362 minecraft:honeycomb_block
setblock 22 135 323 minecraft:honeycomb_block
setblock 23 135 323 minecraft:yellow_terracotta
setblock 23 135 363 minecraft:yellow_terracotta
fill 24 135 323 27 135 323 minecraft:honeycomb_block
setblock 24 135 325 minecraft:light[level=12]
setblock 24 135 332 minecraft:light[level=12]
setblock 24 135 339 minecraft:light[level=12]
setblock 24 135 346 minecraft:light[level=12]
setblock 24 135 353 minecraft:light[level=12]
setblock 24 135 360 minecraft:light[level=12]
setblock 24 135 364 minecraft:yellow_concrete
setblock 27 135 325 minecraft:light[level=15]
setblock 27 135 333 minecraft:light[level=15]
setblock 27 135 341 minecraft:light[level=15]
setblock 27 135 349 minecraft:light[level=15]
setblock 27 135 357 minecraft:light[level=15]
setblock 28 135 323 minecraft:yellow_terracotta
fill 29 135 323 31 135 324 minecraft:honeycomb_block
fill 29 135 363 32 135 363 minecraft:honeycomb_block
setblock 31 135 325 minecraft:yellow_terracotta
setblock 31 135 332 minecraft:light[level=12]
setblock 31 135 339 minecraft:light[level=12]
setblock 31 135 346 minecraft:light[level=12]
setblock 31 135 353 minecraft:light[level=12]
setblock 31 135 360 minecraft:light[level=12]
setblock 32 135 323 minecraft:honeycomb_block
setblock 32 135 324 minecraft:yellow_terracotta
fill 32 135 325 35 135 325 minecraft:honeycomb_block
setblock 33 135 323 minecraft:yellow_terracotta
fill 33 135 324 36 135 324 minecraft:honeycomb_block
fill 33 135 326 34 135 326 minecraft:honeycomb_block
setblock 33 135 362 minecraft:honeycomb_block
setblock 33 135 363 minecraft:yellow_terracotta
fill 34 135 323 34 138 323 minecraft:honeycomb_block
setblock 34 135 362 minecraft:yellow_terracotta
fill 34 135 363 34 138 363 minecraft:honeycomb_block
setblock 35 135 326 minecraft:yellow_terracotta
setblock 35 135 333 minecraft:light[level=15]
setblock 35 135 341 minecraft:light[level=15]
setblock 35 135 349 minecraft:light[level=15]
setblock 35 135 357 minecraft:light[level=15]
fill 35 135 362 35 136 362 minecraft:honeycomb_block
setblock 36 135 325 minecraft:yellow_terracotta
fill 36 135 326 39 135 326 minecraft:honeycomb_block
setblock 37 135 324 minecraft:yellow_terracotta
fill 37 135 325 37 138 325 minecraft:honeycomb_block
setblock 38 135 323 minecraft:yellow_terracotta
fill 38 135 324 38 138 324 minecraft:honeycomb_block
setblock 38 135 327 minecraft:honeycomb_block
setblock 38 135 328 minecraft:yellow_terracotta
setblock 38 135 332 minecraft:light[level=12]
setblock 38 135 339 minecraft:light[level=12]
setblock 38 135 346 minecraft:light[level=12]
setblock 38 135 353 minecraft:light[level=12]
setblock 38 135 360 minecraft:light[level=12]
setblock 38 135 363 minecraft:yellow_terracotta
fill 39 135 323 39 138 323 minecraft:honeycomb_block
setblock 39 135 327 minecraft:yellow_terracotta
fill 39 135 328 39 136 330 minecraft:honeycomb_block
setblock 39 135 342 minecraft:yellow_terracotta
setblock 39 135 343 minecraft:honeycomb_block
setblock 39 135 345 minecraft:honeycomb_block
setblock 39 135 362 minecraft:yellow_terracotta
fill 39 135 363 39 138 363 minecraft:honeycomb_block
setblock 40 135 325 minecraft:honeycomb_block
setblock 40 135 326 minecraft:yellow_terracotta
fill 40 135 327 40 138 327 minecraft:honeycomb_block
fill 40 135 329 40 135 330 minecraft:honeycomb_block
setblock 40 135 331 minecraft:yellow_terracotta
fill 40 135 332 41 135 333 minecraft:honeycomb_block
setblock 40 135 341 minecraft:yellow_terracotta
fill 40 135 342 40 136 342 minecraft:honeycomb_block
setblock 40 135 346 minecraft:yellow_terracotta
fill 40 135 347 40 136 347 minecraft:honeycomb_block
setblock 40 135 362 minecraft:honeycomb_block
setblock 41 135 325 minecraft:yellow_terracotta
fill 41 135 326 41 138 326 minecraft:honeycomb_block
setblock 41 135 329 minecraft:honeycomb_block
setblock 41 135 330 minecraft:yellow_terracotta
fill 41 135 331 41 138 331 minecraft:honeycomb_block
setblock 41 135 334 minecraft:honeycomb_block
setblock 41 135 335 minecraft:yellow_terracotta
fill 41 135 336 41 136 336 minecraft:honeycomb_block
setblock 41 135 340 minecraft:yellow_terracotta
fill 41 135 341 41 136 341 minecraft:honeycomb_block
setblock 41 135 345 minecraft:yellow_terracotta
fill 41 135 346 41 138 346 minecraft:honeycomb_block
setblock 41 135 360 minecraft:yellow_terracotta
fill 41 135 361 41 136 361 minecraft:honeycomb_block
setblock 42 135 326 minecraft:orange_terracotta
setblock 42 135 343 minecraft:orange_terracotta
fill 0 136 332 0 181 332 minecraft:honeycomb_block
fill 0 136 349 0 308 349 minecraft:honeycomb_block
setblock 1 136 323 minecraft:honeycomb_block
setblock 1 136 324 minecraft:yellow_terracotta
fill 1 136 325 1 139 325 minecraft:honeycomb_block
setblock 1 136 329 minecraft:yellow_terracotta
fill 1 136 330 1 137 330 minecraft:honeycomb_block
setblock 1 136 344 minecraft:yellow_terracotta
fill 1 136 345 1 137 345 minecraft:honeycomb_block
setblock 1 136 349 minecraft:yellow_terracotta
fill 1 136 350 1 139 350 minecraft:honeycomb_block
setblock 1 136 359 minecraft:yellow_terracotta
fill 1 136 360 1 137 360 minecraft:honeycomb_block
setblock 2 136 323 minecraft:yellow_terracotta
fill 2 136 324 5 136 324 minecraft:honeycomb_block
setblock 2 136 362 minecraft:honeycomb_block
setblock 2 136 363 minecraft:yellow_terracotta
fill 3 136 323 6 136 323 minecraft:honeycomb_block
setblock 3 136 362 minecraft:yellow_terracotta
fill 3 136 363 6 136 363 minecraft:honeycomb_block
fill 4 136 362 7 136 362 minecraft:honeycomb_block
setblock 6 136 324 minecraft:yellow_terracotta
setblock 7 136 323 minecraft:yellow_terracotta
fill 7 136 324 10 136 324 minecraft:honeycomb_block
setblock 7 136 363 minecraft:yellow_terracotta
fill 8 136 323 11 136 323 minecraft:honeycomb_block
setblock 8 136 362 minecraft:yellow_terracotta
fill 8 136 363 8 139 364 minecraft:honeycomb_block
fill 9 136 362 12 136 362 minecraft:honeycomb_block
fill 10 136 361 13 136 361 minecraft:honeycomb_block
fill 10 136 363 11 136 363 minecraft:honeycomb_block
setblock 11 136 324 minecraft:yellow_terracotta
fill 11 136 325 14 136 325 minecraft:honeycomb_block
fill 12 136 322 12 136 323 minecraft:yellow_terracotta
fill 12 136 324 12 139 324 minecraft:honeycomb_block
setblock 12 136 363 minecraft:yellow_terracotta
fill 13 136 323 16 136 323 minecraft:honeycomb_block
setblock 13 136 362 minecraft:yellow_terracotta
fill 13 136 363 16 136 363 minecraft:honeycomb_block
setblock 14 136 361 minecraft:yellow_terracotta
fill 14 136 362 17 136 362 minecraft:honeycomb_block
fill 14 136 364 14 308 364 minecraft:honeycomb_block
setblock 15 136 325 minecraft:yellow_terracotta
setblock 15 136 361 minecraft:honeycomb_block
setblock 16 136 324 minecraft:yellow_terracotta
setblock 16 136 325 minecraft:honeycomb_block
fill 16 136 364 16 145 364 minecraft:honeycomb_block
fill 17 136 322 17 236 322 minecraft:honeycomb_block
setblock 17 136 323 minecraft:yellow_terracotta
fill 17 136 324 17 138 324 minecraft:honeycomb_block
setblock 17 136 363 minecraft:yellow_terracotta
fill 18 136 323 18 138 323 minecraft:honeycomb_block
setblock 18 136 362 minecraft:yellow_terracotta
fill 18 136 363 18 138 363 minecraft:honeycomb_block
setblock 19 136 362 minecraft:honeycomb_block
setblock 22 136 323 minecraft:yellow_terracotta
fill 23 136 323 26 136 323 minecraft:honeycomb_block
fill 24 136 364 24 197 364 minecraft:honeycomb_block
setblock 25 136 363 minecraft:honey_block
setblock 27 136 323 minecraft:yellow_terracotta
fill 28 136 323 30 136 324 minecraft:honeycomb_block
fill 29 136 363 31 136 363 minecraft:honeycomb_block
setblock 30 136 325 minecraft:yellow_terracotta
setblock 31 136 323 minecraft:honeycomb_block
setblock 31 136 324 minecraft:yellow_terracotta
fill 31 136 325 34 136 325 minecraft:honeycomb_block
setblock 32 136 323 minecraft:yellow_terracotta
fill 32 136 324 35 136 324 minecraft:honeycomb_block
fill 32 136 326 33 136 326 minecraft:honeycomb_block
setblock 32 136 363 minecraft:yellow_terracotta
fill 33 136 323 33 139 323 minecraft:honeycomb_block
setblock 33 136 362 minecraft:yellow_terracotta
fill 33 136 363 33 139 363 minecraft:honeycomb_block
setblock 34 136 326 minecraft:yellow_terracotta
setblock 34 136 362 minecraft:honeycomb_block
setblock 34 136 364 minecraft:orange_terracotta
setblock 35 136 325 minecraft:yellow_terracotta
fill 35 136 326 38 136 326 minecraft:honeycomb_block
setblock 36 136 322 minecraft:yellow_concrete
setblock 36 136 324 minecraft:yellow_terracotta
fill 36 136 325 36 139 325 minecraft:honeycomb_block
setblock 37 136 323 minecraft:yellow_terracotta
fill 37 136 324 37 139 324 minecraft:honeycomb_block
setblock 37 136 363 minecraft:yellow_terracotta
fill 38 136 323 38 139 323 minecraft:honeycomb_block
setblock 38 136 327 minecraft:yellow_terracotta
fill 38 136 328 38 137 328 minecraft:honeycomb_block
setblock 38 136 362 minecraft:yellow_terracotta
fill 38 136 363 38 139 363 minecraft:honeycomb_block
setblock 39 136 326 minecraft:yellow_terracotta
fill 39 136 327 39 139 327 minecraft:honeycomb_block
setblock 40 136 325 minecraft:yellow_terracotta
fill 40 136 326 40 139 326 minecraft:honeycomb_block
setblock 40 136 329 minecraft:honeycomb_block
setblock 40 136 330 minecraft:yellow_terracotta
fill 40 136 331 40 136 332 minecraft:honeycomb_block
setblock 40 136 341 minecraft:honeycomb_block
setblock 40 136 345 minecraft:yellow_terracotta
setblock 40 136 346 minecraft:honeycomb_block
setblock 41 136 324 minecraft:yellow_terracotta
fill 41 136 325 41 139 325 minecraft:honeycomb_block
setblock 41 136 329 minecraft:yellow_terracotta
fill 41 136 330 41 139 330 minecraft:honeycomb_block
fill 41 136 332 41 136 333 minecraft:honeycomb_block
setblock 41 136 334 minecraft:yellow_terracotta
setblock 41 136 335 minecraft:honeycomb_block
setblock 41 136 339 minecraft:yellow_terracotta
setblock 41 136 340 minecraft:honeycomb_block
setblock 41 136 344 minecraft:yellow_terracotta
fill 41 136 345 41 137 345 minecraft:honeycomb_block
setblock 41 136 348 minecraft:honeycomb_block
setblock 41 136 349 minecraft:yellow_terracotta
fill 42 136 326 42 168 326 minecraft:honeycomb_block
fill 42 136 343 42 177 343 minecraft:honeycomb_block
fill 0 137 348 0 154 348 minecraft:honeycomb_block
setblock 1 137 323 minecraft:yellow_terracotta
fill 1 137 324 4 137 324 minecraft:honeycomb_block
setblock 1 137 328 minecraft:yellow_terracotta
fill 1 137 329 1 139 329 minecraft:honeycomb_block
setblock 1 137 348 minecraft:yellow_terracotta
fill 1 137 349 1 139 349 minecraft:honeycomb_block
fill 1 137 355 1 138 355 minecraft:honey_block
fill 1 137 361 1 137 362 minecraft:honeycomb_block
setblock 1 137 363 minecraft:yellow_terracotta
fill 2 137 323 5 137 323 minecraft:honeycomb_block
setblock 2 137 327 minecraft:yellow_terracotta
fill 2 137 363 5 137 363 minecraft:honeycomb_block
setblock 5 137 324 minecraft:yellow_terracotta
setblock 6 137 323 minecraft:yellow_terracotta
fill 6 137 324 9 137 324 minecraft:honeycomb_block
setblock 6 137 362 minecraft:honeycomb_block
setblock 6 137 363 minecraft:yellow_terracotta
fill 7 137 323 10 137 323 minecraft:honeycomb_block
setblock 7 137 362 minecraft:yellow_terracotta
fill 7 137 363 7 140 363 minecraft:honeycomb_block
fill 8 137 362 11 137 362 minecraft:honeycomb_block
setblock 10 137 324 minecraft:yellow_terracotta
setblock 10 137 363 minecraft:honeycomb_block
setblock 11 137 323 minecraft:yellow_terracotta
fill 11 137 324 11 137 325 minecraft:honeycomb_block
fill 11 137 361 12 137 361 minecraft:honeycomb_block
setblock 11 137 363 minecraft:yellow_terracotta
fill 12 137 322 12 140 323 minecraft:honeycomb_block
fill 12 137 325 13 137 325 minecraft:honeycomb_block
setblock 12 137 362 minecraft:yellow_terracotta
fill 12 137 363 15 137 363 minecraft:honeycomb_block
fill 13 137 323 15 137 323 minecraft:honeycomb_block
setblock 13 137 361 minecraft:yellow_terracotta
fill 13 137 362 16 137 362 minecraft:honeycomb_block
setblock 14 137 325 minecraft:yellow_terracotta
setblock 14 137 361 minecraft:honeycomb_block
setblock 15 137 324 minecraft:yellow_terracotta
setblock 15 137 325 minecraft:honeycomb_block
setblock 16 137 323 minecraft:yellow_terracotta
fill 16 137 324 16 138 324 minecraft:honeycomb_block
setblock 16 137 363 minecraft:yellow_terracotta
fill 17 137 323 17 139 323 minecraft:honeycomb_block
setblock 17 137 362 minecraft:yellow_terracotta
fill 17 137 363 17 139 363 minecraft:honeycomb_block
setblock 21 137 323 minecraft:yellow_terracotta
setblock 25 137 323 minecraft:honeycomb_block
setblock 26 137 323 minecraft:yellow_terracotta
fill 27 137 323 30 137 323 minecraft:honeycomb_block
fill 28 137 324 29 137 324 minecraft:honeycomb_block
setblock 30 137 324 minecraft:yellow_terracotta
fill 30 137 325 33 137 325 minecraft:honeycomb_block
setblock 30 137 363 minecraft:honeycomb_block
setblock 31 137 323 minecraft:yellow_terracotta
fill 31 137 324 34 137 324 minecraft:honeycomb_block
setblock 31 137 363 minecraft:yellow_terracotta
fill 32 137 323 32 140 323 minecraft:honeycomb_block
setblock 32 137 326 minecraft:honeycomb_block
fill 32 137 363 32 140 364 minecraft:honeycomb_block
setblock 33 137 326 minecraft:yellow_terracotta
setblock 33 137 364 minecraft:orange_terracotta
setblock 34 137 325 minecraft:yellow_terracotta
fill 34 137 326 37 137 326 minecraft:honeycomb_block
fill 34 137 364 34 147 364 minecraft:honeycomb_block
setblock 35 137 324 minecraft:yellow_terracotta
fill 35 137 325 35 140 325 minecraft:honeycomb_block
fill 36 137 322 36 178 322 minecraft:honeycomb_block
setblock 36 137 323 minecraft:yellow_terracotta
fill 36 137 324 36 140 324 minecraft:honeycomb_block
setblock 36 137 363 minecraft:yellow_terracotta
fill 37 137 323 37 140 323 minecraft:honeycomb_block
fill 37 137 363 37 139 363 minecraft:honeycomb_block
setblock 38 137 326 minecraft:yellow_terracotta
setblock 38 137 327 minecraft:honeycomb_block
setblock 39 137 325 minecraft:yellow_terracotta
fill 39 137 326 39 139 326 minecraft:honeycomb_block
fill 39 137 328 39 137 329 minecraft:honeycomb_block
setblock 39 137 330 minecraft:yellow_terracotta
setblock 40 137 324 minecraft:yellow_terracotta
fill 40 137 325 40 140 325 minecraft:honeycomb_block
setblock 40 137 328 minecraft:honeycomb_block
setblock 40 137 329 minecraft:yellow_terracotta
fill 40 137 330 40 138 331 minecraft:honeycomb_block
setblock 41 137 323 minecraft:yellow_terracotta
fill 41 137 324 41 140 324 minecraft:honeycomb_block
setblock 41 137 328 minecraft:yellow_terracotta
fill 41 137 329 41 140 329 minecraft:honeycomb_block
setblock 41 137 332 minecraft:honeycomb_block
setblock 41 137 333 minecraft:yellow_terracotta
setblock 41 137 343 minecraft:yellow_terracotta
setblock 41 137 344 minecraft:honeycomb_block
setblock 41 137 348 minecraft:yellow_terracotta
setblock 41 137 349 minecraft:honeycomb_block
setblock 41 137 356 minecraft:honey_block
setblock 41 137 363 minecraft:yellow_terracotta
fill 0 138 327 0 243 327 minecraft:honeycomb_block
fill 1 138 323 3 138 324 minecraft:honeycomb_block
setblock 1 138 327 minecraft:yellow_terracotta
fill 1 138 328 1 140 328 minecraft:honeycomb_block
setblock 1 138 336 minecraft:honey_block
setblock 1 138 347 minecraft:yellow_terracotta
setblock 1 138 348 minecraft:honeycomb_block
setblock 1 138 361 minecraft:honeycomb_block
setblock 1 138 362 minecraft:yellow_terracotta
fill 1 138 363 4 138 363 minecraft:honeycomb_block
setblock 2 138 326 minecraft:yellow_terracotta
setblock 4 138 323 minecraft:honeycomb_block
setblock 5 138 323 minecraft:yellow_terracotta
setblock 5 138 363 minecraft:yellow_terracotta
fill 6 138 323 8 138 324 minecraft:honeycomb_block
fill 6 138 363 6 141 363 minecraft:honeycomb_block
fill 8 138 362 10 138 362 minecraft:honeycomb_block
setblock 9 138 323 minecraft:honeycomb_block
setblock 9 138 324 minecraft:yellow_terracotta
setblock 10 138 323 minecraft:yellow_terracotta
fill 10 138 324 11 140 324 minecraft:honeycomb_block
setblock 10 138 363 minecraft:yellow_terracotta
fill 11 138 323 11 141 323 minecraft:honeycomb_block
setblock 11 138 362 minecraft:yellow_terracotta
fill 11 138 363 14 138 363 minecraft:honeycomb_block
fill 12 138 362 15 138 362 minecraft:honeycomb_block
fill 13 138 323 14 138 323 minecraft:honeycomb_block
setblock 14 138 324 minecraft:yellow_terracotta
setblock 15 138 323 minecraft:yellow_terracotta
fill 15 138 324 15 139 324 minecraft:honeycomb_block
setblock 15 138 363 minecraft:yellow_terracotta
fill 16 138 323 16 140 323 minecraft:honeycomb_block
setblock 16 138 362 minecraft:yellow_terracotta
fill 16 138 363 16 139 363 minecraft:honeycomb_block
setblock 24 138 323 minecraft:honey_block
fill 26 138 323 29 138 323 minecraft:honeycomb_block
setblock 28 138 324 minecraft:honeycomb_block
setblock 29 138 324 minecraft:yellow_terracotta
setblock 30 138 323 minecraft:yellow_terracotta
fill 30 138 324 32 138 325 minecraft:honeycomb_block
setblock 30 138 363 minecraft:yellow_terracotta
fill 31 138 323 31 141 323 minecraft:honeycomb_block
fill 31 138 363 31 139 363 minecraft:honeycomb_block
setblock 32 138 326 minecraft:yellow_terracotta
setblock 33 138 324 minecraft:honeycomb_block
setblock 33 138 325 minecraft:yellow_terracotta
fill 33 138 326 36 138 326 minecraft:honeycomb_block
fill 33 138 364 33 156 364 minecraft:honeycomb_block
setblock 34 138 324 minecraft:yellow_terracotta
fill 34 138 325 34 141 325 minecraft:honeycomb_block
setblock 35 138 323 minecraft:yellow_terracotta
fill 35 138 324 35 141 324 minecraft:honeycomb_block
setblock 35 138 363 minecraft:yellow_terracotta
fill 36 138 323 36 141 323 minecraft:honeycomb_block
fill 36 138 363 36 139 363 minecraft:honeycomb_block
setblock 37 138 326 minecraft:yellow_terracotta
setblock 38 138 325 minecraft:yellow_terracotta
setblock 38 138 326 minecraft:honeycomb_block
setblock 39 138 324 minecraft:yellow_terracotta
fill 39 138 325 39 139 325 minecraft:honeycomb_block
setblock 39 138 328 minecraft:honeycomb_block
setblock 39 138 329 minecraft:yellow_terracotta
setblock 40 138 323 minecraft:yellow_terracotta
fill 40 138 324 40 140 324 minecraft:honeycomb_block
setblock 40 138 328 minecraft:yellow_terracotta
fill 40 138 329 40 141 329 minecraft:honeycomb_block
setblock 40 138 363 minecraft:yellow_terracotta
fill 41 138 323 41 141 323 minecraft:honeycomb_block
setblock 41 138 327 minecraft:yellow_terracotta
fill 41 138 328 41 141 328 minecraft:honeycomb_block
setblock 41 138 332 minecraft:yellow_terracotta
setblock 41 138 347 minecraft:yellow_terracotta
setblock 41 138 350 minecraft:honey_block
setblock 41 138 363 minecraft:honeycomb_block
setblock 0 139 334 minecraft:yellow_concrete
fill 1 139 323 1 140 324 minecraft:honeycomb_block
setblock 1 139 326 minecraft:yellow_terracotta
fill 1 139 327 1 141 327 minecraft:honeycomb_block
setblock 1 139 342 minecraft:honey_block
fill 1 139 363 3 139 363 minecraft:honeycomb_block
fill 2 139 323 3 139 323 minecraft:honeycomb_block
setblock 4 139 323 minecraft:yellow_terracotta
setblock 4 139 363 minecraft:yellow_terracotta
fill 5 139 323 8 139 323 minecraft:honeycomb_block
fill 5 139 363 5 140 363 minecraft:honeycomb_block
setblock 8 139 324 minecraft:yellow_terracotta
setblock 9 139 323 minecraft:yellow_terracotta
fill 9 139 324 9 140 324 minecraft:honeycomb_block
setblock 9 139 362 minecraft:honeycomb_block
setblock 9 139 363 minecraft:yellow_terracotta
fill 9 139 364 9 195 364 minecraft:honeycomb_block
fill 10 139 323 10 142 323 minecraft:honeycomb_block
setblock 10 139 362 minecraft:yellow_terracotta
fill 10 139 363 13 139 363 minecraft:honeycomb_block
fill 11 139 362 14 139 362 minecraft:honeycomb_block
setblock 13 139 322 minecraft:yellow_concrete
setblock 13 139 323 minecraft:honeycomb_block
setblock 13 139 324 minecraft:yellow_terracotta
fill 13 139 351 13 140 351 minecraft:yellow_concrete
setblock 13 139 364 minecraft:yellow_terracotta
setblock 14 139 323 minecraft:yellow_terracotta
setblock 14 139 324 minecraft:honeycomb_block
setblock 14 139 363 minecraft:yellow_terracotta
fill 15 139 323 15 140 323 minecraft:honeycomb_block
fill 15 139 363 15 140 363 minecraft:honeycomb_block
setblock 18 139 323 minecraft:honey_block
setblock 24 139 363 minecraft:honey_block
setblock 25 139 364 minecraft:yellow_terracotta
fill 27 139 323 28 139 323 minecraft:honeycomb_block
setblock 28 139 324 minecraft:yellow_terracotta
setblock 29 139 323 minecraft:yellow_terracotta
fill 29 139 324 32 139 324 minecraft:honeycomb_block
fill 30 139 323 30 142 323 minecraft:honeycomb_block
fill 30 139 325 31 139 325 minecraft:honeycomb_block
setblock 32 139 325 minecraft:yellow_terracotta
fill 32 139 326 35 139 326 minecraft:honeycomb_block
setblock 33 139 324 minecraft:yellow_terracotta
fill 33 139 325 33 142 325 minecraft:honeycomb_block
setblock 34 139 323 minecraft:yellow_terracotta
fill 34 139 324 34 142 324 minecraft:honeycomb_block
setblock 34 139 363 minecraft:yellow_terracotta
fill 35 139 323 35 142 323 minecraft:honeycomb_block
fill 35 139 363 35 140 363 minecraft:honeycomb_block
setblock 35 139 364 minecraft:yellow_concrete
setblock 36 139 326 minecraft:yellow_terracotta
setblock 37 139 325 minecraft:yellow_terracotta
setblock 38 139 324 minecraft:yellow_terracotta
fill 38 139 325 38 140 325 minecraft:honeycomb_block
setblock 39 139 323 minecraft:yellow_terracotta
fill 39 139 324 39 141 324 minecraft:honeycomb_block
setblock 39 139 328 minecraft:yellow_terracotta
fill 40 139 323 40 142 323 minecraft:honeycomb_block
setblock 40 139 327 minecraft:yellow_terracotta
fill 40 139 328 40 142 328 minecraft:honeycomb_block
fill 40 139 330 40 140 330 minecraft:honeycomb_block
setblock 41 139 326 minecraft:yellow_terracotta
fill 41 139 327 41 142 327 minecraft:honeycomb_block
setblock 41 139 331 minecraft:yellow_terracotta
setblock 41 139 332 minecraft:honeycomb_block
setblock 41 139 344 minecraft:honey_block
setblock 42 139 360 minecraft:yellow_terracotta
fill 0 140 334 0 166 334 minecraft:honeycomb_block
setblock 1 140 325 minecraft:yellow_terracotta
fill 1 140 326 1 141 326 minecraft:honeycomb_block
setblock 1 140 329 minecraft:honey_block
setblock 1 140 348 minecraft:honey_block
setblock 2 140 323 minecraft:honeycomb_block
setblock 3 140 323 minecraft:yellow_terracotta
fill 4 140 323 7 140 323 minecraft:honeycomb_block
setblock 8 140 323 minecraft:yellow_terracotta
setblock 8 140 363 minecraft:yellow_terracotta
fill 8 140 364 8 308 364 minecraft:honeycomb_block
fill 9 140 323 9 143 323 minecraft:honeycomb_block
fill 9 140 363 12 140 363 minecraft:honeycomb_block
fill 10 140 362 12 140 362 minecraft:honeycomb_block
fill 11 140 331 11 141 332 minecraft:honey_block
setblock 12 140 324 minecraft:yellow_terracotta
fill 13 140 322 13 192 322 minecraft:honeycomb_block
setblock 13 140 323 minecraft:yellow_terracotta
setblock 13 140 324 minecraft:honeycomb_block
setblock 13 140 363 minecraft:yellow_terracotta
fill 13 140 364 13 157 364 minecraft:honeycomb_block
fill 14 140 323 14 141 323 minecraft:honeycomb_block
fill 14 140 363 14 141 363 minecraft:honeycomb_block
fill 25 140 364 25 154 364 minecraft:honeycomb_block
setblock 27 140 323 minecraft:honeycomb_block
setblock 28 140 323 minecraft:yellow_terracotta
fill 28 140 324 31 140 324 minecraft:honeycomb_block
fill 29 140 323 29 143 323 minecraft:honeycomb_block
setblock 30 140 325 minecraft:honeycomb_block
setblock 30 140 363 minecraft:honey_block
setblock 31 140 325 minecraft:yellow_terracotta
setblock 32 140 324 minecraft:yellow_terracotta
fill 32 140 325 32 140 326 minecraft:honeycomb_block
setblock 33 140 323 minecraft:yellow_terracotta
fill 33 140 324 33 143 324 minecraft:honeycomb_block
fill 33 140 326 34 140 326 minecraft:honeycomb_block
setblock 33 140 363 minecraft:yellow_terracotta
fill 34 140 323 34 143 323 minecraft:honeycomb_block
setblock 34 140 363 minecraft:honeycomb_block
setblock 35 140 326 minecraft:yellow_terracotta
fill 35 140 364 35 227 364 minecraft:honeycomb_block
setblock 36 140 325 minecraft:yellow_terracotta
setblock 37 140 324 minecraft:yellow_terracotta
setblock 37 140 325 minecraft:honeycomb_block
setblock 38 140 323 minecraft:yellow_terracotta
fill 38 140 324 38 141 324 minecraft:honeycomb_block
fill 39 140 323 39 143 323 minecraft:honeycomb_block
setblock 40 140 326 minecraft:yellow_terracotta
fill 40 140 327 40 142 327 minecraft:honeycomb_block
setblock 41 140 325 minecraft:yellow_terracotta
fill 41 140 326 41 143 326 minecraft:honeycomb_block
setblock 41 140 330 minecraft:yellow_terracotta
fill 41 140 331 41 143 331 minecraft:honeycomb_block
setblock 41 140 338 minecraft:honey_block
setblock 41 140 357 minecraft:honey_block
fill 42 140 360 42 248 360 minecraft:honeycomb_block
setblock 1 141 324 minecraft:yellow_terracotta
setblock 1 141 325 minecraft:honeycomb_block
setblock 1 141 335 minecraft:honey_block
setblock 1 141 354 minecraft:honey_block
setblock 3 141 325 minecraft:light[level=12]
setblock 3 141 332 minecraft:light[level=12]
setblock 3 141 339 minecraft:light[level=12]
setblock 3 141 346 minecraft:light[level=12]
setblock 3 141 353 minecraft:light[level=12]
setblock 3 141 360 minecraft:light[level=12]
setblock 6 141 323 minecraft:honeycomb_block
setblock 7 141 323 minecraft:yellow_terracotta
setblock 7 141 363 minecraft:yellow_terracotta
fill 8 141 323 8 144 323 minecraft:honeycomb_block
fill 8 141 363 11 141 363 minecraft:honeycomb_block
setblock 10 141 325 minecraft:light[level=12]
setblock 10 141 332 minecraft:light[level=12]
setblock 10 141 339 minecraft:light[level=12]
setblock 10 141 346 minecraft:light[level=12]
setblock 10 141 353 minecraft:light[level=12]
setblock 10 141 360 minecraft:light[level=12]
fill 12 141 322 12 175 322 minecraft:honeycomb_block
setblock 12 141 323 minecraft:yellow_terracotta
setblock 12 141 363 minecraft:yellow_terracotta
fill 13 141 323 13 142 323 minecraft:honeycomb_block
fill 13 141 363 13 142 363 minecraft:honeycomb_block
setblock 17 141 325 minecraft:light[level=12]
setblock 17 141 332 minecraft:light[level=12]
setblock 17 141 339 minecraft:light[level=12]
setblock 17 141 346 minecraft:light[level=12]
setblock 17 141 353 minecraft:light[level=12]
setblock 17 141 360 minecraft:light[level=12]
setblock 17 141 363 minecraft:honey_block
setblock 24 141 325 minecraft:light[level=12]
setblock 24 141 332 minecraft:light[level=12]
setblock 24 141 339 minecraft:light[level=12]
setblock 24 141 346 minecraft:light[level=12]
setblock 24 141 353 minecraft:light[level=12]
setblock 24 141 360 minecraft:light[level=12]
setblock 25 141 323 minecraft:honey_block
setblock 27 141 323 minecraft:yellow_terracotta
fill 28 141 323 28 143 324 minecraft:honeycomb_block
fill 28 141 327 30 205 329 minecraft:yellow_terracotta
fill 29 141 324 30 141 324 minecraft:honeycomb_block
fill 29 141 326 29 205 326 minecraft:yellow_terracotta
setblock 30 141 325 minecraft:yellow_terracotta
setblock 31 141 324 minecraft:yellow_terracotta
fill 31 141 325 32 143 325 minecraft:honeycomb_block
fill 31 141 327 31 205 328 minecraft:yellow_terracotta
setblock 31 141 332 minecraft:light[level=12]
setblock 31 141 339 minecraft:light[level=12]
setblock 31 141 346 minecraft:light[level=12]
setblock 31 141 353 minecraft:light[level=12]
setblock 31 141 360 minecraft:light[level=12]
setblock 32 141 323 minecraft:yellow_terracotta
fill 32 141 324 32 144 324 minecraft:honeycomb_block
fill 32 141 364 32 239 364 minecraft:honeycomb_block
fill 33 141 323 33 144 323 minecraft:honeycomb_block
setblock 35 141 325 minecraft:yellow_terracotta
setblock 36 141 324 minecraft:yellow_terracotta
setblock 36 141 325 minecraft:honeycomb_block
setblock 36 141 363 minecraft:honey_block
setblock 37 141 323 minecraft:yellow_terracotta
fill 37 141 324 37 142 324 minecraft:honeycomb_block
fill 38 141 323 38 144 323 minecraft:honeycomb_block
setblock 38 141 325 minecraft:light[level=12]
setblock 38 141 332 minecraft:light[level=12]
setblock 38 141 339 minecraft:light[level=12]
setblock 38 141 346 minecraft:light[level=12]
setblock 38 141 353 minecraft:light[level=12]
setblock 38 141 360 minecraft:light[level=12]
setblock 40 141 325 minecraft:yellow_terracotta
setblock 40 141 326 minecraft:honeycomb_block
setblock 41 141 324 minecraft:yellow_terracotta
fill 41 141 325 41 144 325 minecraft:honeycomb_block
setblock 41 141 329 minecraft:yellow_terracotta
fill 41 141 330 41 144 330 minecraft:honeycomb_block
setblock 41 141 332 minecraft:honey_block
setblock 41 141 351 minecraft:honey_block
setblock 42 141 323 minecraft:yellow_concrete
setblock 42 141 331 minecraft:orange_terracotta
setblock 1 142 341 minecraft:honey_block
fill 1 142 351 1 142 352 minecraft:honeycomb_block
setblock 1 142 360 minecraft:honey_block
setblock 6 142 363 minecraft:yellow_terracotta
setblock 7 142 323 minecraft:honeycomb_block
fill 7 142 363 10 142 363 minecraft:honeycomb_block
setblock 11 142 323 minecraft:yellow_terracotta
setblock 11 142 363 minecraft:yellow_terracotta
setblock 12 142 323 minecraft:honeycomb_block
fill 12 142 363 12 143 363 minecraft:honeycomb_block
setblock 19 142 323 minecraft:honey_block
setblock 23 142 363 minecraft:honey_block
fill 27 142 323 27 145 323 minecraft:honeycomb_block
fill 27 142 327 27 143 329 minecraft:brown_terracotta
fill 28 142 326 28 143 326 minecraft:brown_terracotta
fill 28 142 330 31 143 330 minecraft:brown_terracotta
setblock 29 142 324 minecraft:honeycomb_block
setblock 30 142 324 minecraft:yellow_terracotta
fill 30 142 325 30 145 325 minecraft:honeycomb_block
fill 30 142 326 31 143 326 minecraft:brown_terracotta
setblock 31 142 323 minecraft:yellow_terracotta
fill 31 142 324 31 145 324 minecraft:honeycomb_block
fill 31 142 329 31 143 329 minecraft:brown_terracotta
fill 32 142 323 32 145 323 minecraft:honeycomb_block
fill 32 142 328 32 143 328 minecraft:brown_terracotta
setblock 34 142 325 minecraft:yellow_terracotta
setblock 35 142 324 minecraft:yellow_terracotta
setblock 35 142 325 minecraft:honeycomb_block
setblock 36 142 323 minecraft:yellow_terracotta
fill 36 142 324 36 143 324 minecraft:honeycomb_block
fill 37 142 323 37 145 323 minecraft:honeycomb_block
setblock 41 142 323 minecraft:yellow_terracotta
fill 41 142 324 41 145 324 minecraft:honeycomb_block
setblock 41 142 328 minecraft:yellow_terracotta
fill 41 142 329 41 145 329 minecraft:honeycomb_block
setblock 41 142 345 minecraft:honey_block
fill 42 142 323 42 282 323 minecraft:honeycomb_block
fill 42 142 331 42 180 331 minecraft:honeycomb_block
setblock 0 143 331 minecraft:orange_terracotta
fill 0 143 335 0 165 335 minecraft:honeycomb_block
setblock 0 143 336 minecraft:yellow_concrete
setblock 1 143 347 minecraft:honey_block
fill 1 143 350 1 143 351 minecraft:honeycomb_block
setblock 1 143 352 minecraft:yellow_terracotta
fill 1 143 353 1 144 355 minecraft:honeycomb_block
setblock 3 143 325 minecraft:light[level=15]
setblock 3 143 333 minecraft:light[level=15]
setblock 3 143 341 minecraft:light[level=15]
setblock 3 143 349 minecraft:light[level=15]
setblock 3 143 357 minecraft:light[level=15]
setblock 4 143 363 minecraft:honey_block
fill 6 143 363 9 143 363 minecraft:honeycomb_block
setblock 10 143 323 minecraft:yellow_terracotta
setblock 10 143 363 minecraft:yellow_terracotta
setblock 11 143 323 minecraft:honeycomb_block
setblock 11 143 325 minecraft:light[level=15]
setblock 11 143 333 minecraft:light[level=15]
setblock 11 143 341 minecraft:light[level=15]
setblock 11 143 349 minecraft:light[level=15]
setblock 11 143 357 minecraft:light[level=15]
fill 11 143 363 11 146 363 minecraft:honeycomb_block
setblock 13 143 323 minecraft:honey_block
setblock 19 143 325 minecraft:light[level=15]
setblock 19 143 333 minecraft:light[level=15]
setblock 19 143 341 minecraft:light[level=15]
setblock 19 143 349 minecraft:light[level=15]
setblock 19 143 357 minecraft:light[level=15]
fill 26 143 327 26 143 329 minecraft:brown_terracotta
setblock 27 143 325 minecraft:light[level=15]
setblock 27 143 326 minecraft:brown_terracotta
setblock 27 143 330 minecraft:brown_terracotta
setblock 27 143 333 minecraft:light[level=15]
setblock 27 143 341 minecraft:light[level=15]
setblock 27 143 349 minecraft:light[level=15]
setblock 27 143 357 minecraft:light[level=15]
fill 28 143 325 29 143 325 minecraft:brown_terracotta
fill 28 143 331 31 143 331 minecraft:brown_terracotta
setblock 29 143 324 minecraft:yellow_terracotta
setblock 29 143 363 minecraft:honey_block
setblock 30 143 323 minecraft:yellow_terracotta
fill 30 143 324 30 146 324 minecraft:honeycomb_block
fill 31 143 323 31 146 323 minecraft:honeycomb_block
fill 32 143 326 32 143 327 minecraft:brown_terracotta
fill 32 143 329 32 143 330 minecraft:brown_terracotta
setblock 33 143 325 minecraft:yellow_terracotta
setblock 34 143 324 minecraft:yellow_terracotta
setblock 34 143 325 minecraft:honeycomb_block
setblock 35 143 323 minecraft:yellow_terracotta
fill 35 143 324 35 145 324 minecraft:honeycomb_block
setblock 35 143 325 minecraft:light[level=15]
setblock 35 143 333 minecraft:light[level=15]
setblock 35 143 341 minecraft:light[level=15]
setblock 35 143 349 minecraft:light[level=15]
setblock 35 143 357 minecraft:light[level=15]
fill 36 143 323 36 146 323 minecraft:honeycomb_block
setblock 41 143 327 minecraft:yellow_terracotta
fill 41 143 328 41 146 328 minecraft:honeycomb_block
setblock 41 143 339 minecraft:honey_block
fill 0 144 331 0 178 331 minecraft:honeycomb_block
fill 0 144 336 0 221 336 minecraft:honeycomb_block
setblock 1 144 328 minecraft:honey_block
fill 1 144 349 1 144 350 minecraft:honeycomb_block
setblock 1 144 351 minecraft:yellow_terracotta
fill 1 144 352 1 147 352 minecraft:honeycomb_block
setblock 1 144 356 minecraft:yellow_terracotta
fill 1 144 357 1 147 357 minecraft:honeycomb_block
fill 6 144 363 8 144 363 minecraft:honeycomb_block
setblock 7 144 323 minecraft:honey_block
setblock 9 144 323 minecraft:yellow_terracotta
setblock 9 144 363 minecraft:yellow_terracotta
setblock 10 144 323 minecraft:honeycomb_block
fill 10 144 363 10 147 363 minecraft:honeycomb_block
setblock 26 144 322 minecraft:yellow_concrete
setblock 26 144 323 minecraft:honey_block
setblock 28 144 323 minecraft:honeycomb_block
setblock 28 144 324 minecraft:yellow_terracotta
setblock 29 144 323 minecraft:yellow_terracotta
fill 29 144 324 29 147 324 minecraft:honeycomb_block
fill 30 144 323 30 147 323 minecraft:honeycomb_block
setblock 31 144 325 minecraft:honeycomb_block
fill 31 144 358 31 145 358 minecraft:honey_block
setblock 32 144 325 minecraft:yellow_terracotta
setblock 33 144 324 minecraft:yellow_terracotta
setblock 33 144 325 minecraft:honeycomb_block
setblock 34 144 323 minecraft:yellow_terracotta
fill 34 144 324 34 147 324 minecraft:honeycomb_block
fill 35 144 323 35 147 323 minecraft:honeycomb_block
setblock 35 144 363 minecraft:honey_block
setblock 41 144 326 minecraft:yellow_terracotta
fill 41 144 327 41 147 327 minecraft:honeycomb_block
setblock 41 144 331 minecraft:yellow_terracotta
fill 41 144 332 41 147 332 minecraft:honeycomb_block
setblock 41 144 333 minecraft:honey_block
setblock 41 144 358 minecraft:honey_block
setblock 42 144 354 minecraft:yellow_concrete
setblock 1 145 334 minecraft:honey_block
setblock 1 145 349 minecraft:honeycomb_block
setblock 1 145 350 minecraft:yellow_terracotta
fill 1 145 351 2 147 351 minecraft:honeycomb_block
fill 1 145 353 1 145 354 minecraft:honeycomb_block
setblock 1 145 355 minecraft:yellow_terracotta
fill 1 145 356 2 147 356 minecraft:honeycomb_block
fill 1 145 358 1 145 359 minecraft:honeycomb_block
fill 2 145 352 2 145 353 minecraft:honeycomb_block
setblock 2 145 354 minecraft:yellow_terracotta
fill 2 145 355 2 148 355 minecraft:honeycomb_block
fill 4 145 363 7 145 363 minecraft:honeycomb_block
setblock 8 145 323 minecraft:yellow_terracotta
setblock 8 145 363 minecraft:yellow_terracotta
fill 9 145 323 9 148 323 minecraft:honeycomb_block
fill 9 145 363 9 148 363 minecraft:honeycomb_block
setblock 16 145 363 minecraft:honey_block
setblock 20 145 323 minecraft:honey_block
fill 26 145 322 26 146 323 minecraft:honeycomb_block
setblock 27 145 324 minecraft:yellow_terracotta
setblock 28 145 323 minecraft:yellow_terracotta
fill 28 145 324 28 148 324 minecraft:honeycomb_block
fill 29 145 323 29 148 323 minecraft:honeycomb_block
fill 29 145 325 29 146 325 minecraft:honeycomb_block
setblock 31 145 325 minecraft:yellow_terracotta
setblock 32 145 324 minecraft:yellow_terracotta
fill 32 145 325 32 146 325 minecraft:honeycomb_block
setblock 33 145 323 minecraft:yellow_terracotta
fill 33 145 324 33 148 324 minecraft:honeycomb_block
fill 34 145 323 34 148 323 minecraft:honeycomb_block
fill 38 145 349 38 148 349 minecraft:iron_block
setblock 41 145 325 minecraft:yellow_terracotta
fill 41 145 326 41 148 326 minecraft:honeycomb_block
setblock 41 145 330 minecraft:yellow_terracotta
fill 41 145 331 41 148 331 minecraft:honeycomb_block
fill 41 145 333 41 146 333 minecraft:honeycomb_block
fill 41 145 346 41 146 346 minecraft:honey_block
setblock 41 145 352 minecraft:honey_block
setblock 41 145 363 minecraft:honey_block
setblock 42 145 348 minecraft:yellow_terracotta
fill 42 145 354 42 149 354 minecraft:honeycomb_block
setblock 0 146 342 minecraft:yellow_terracotta
setblock 0 146 343 minecraft:orange_terracotta
fill 1 146 330 1 148 331 minecraft:honeycomb_block
setblock 1 146 340 minecraft:honey_block
setblock 1 146 348 minecraft:honeycomb_block
setblock 1 146 349 minecraft:yellow_terracotta
fill 1 146 350 2 148 350 minecraft:honeycomb_block
setblock 1 146 353 minecraft:honeycomb_block
setblock 1 146 354 minecraft:yellow_terracotta
fill 1 146 355 1 149 355 minecraft:honeycomb_block
setblock 1 146 358 minecraft:honeycomb_block
setblock 1 146 359 minecraft:yellow_terracotta
fill 1 146 360 1 148 361 minecraft:honeycomb_block
setblock 2 146 352 minecraft:honeycomb_block
setblock 2 146 353 minecraft:yellow_terracotta
fill 2 146 354 3 148 354 minecraft:honeycomb_block
setblock 2 146 357 minecraft:honeycomb_block
setblock 2 146 358 minecraft:yellow_terracotta
setblock 3 146 351 minecraft:honeycomb_block
setblock 3 146 352 minecraft:yellow_terracotta
fill 3 146 353 3 149 353 minecraft:honeycomb_block
fill 3 146 355 3 146 356 minecraft:honeycomb_block
fill 3 146 363 6 146 363 minecraft:honeycomb_block
fill 6 146 362 7 146 362 minecraft:honeycomb_block
setblock 7 146 323 minecraft:yellow_terracotta
setblock 7 146 363 minecraft:yellow_terracotta
fill 8 146 323 8 149 323 minecraft:honeycomb_block
setblock 8 146 362 minecraft:yellow_terracotta
fill 8 146 363 8 149 363 minecraft:honeycomb_block
fill 9 146 362 9 149 362 minecraft:honeycomb_block
setblock 14 146 323 minecraft:honey_block
setblock 16 146 364 minecraft:yellow_concrete
setblock 22 146 363 minecraft:honey_block
fill 25 146 323 25 147 323 minecraft:honeycomb_block
setblock 27 146 323 minecraft:yellow_terracotta
fill 27 146 324 27 149 324 minecraft:honeycomb_block
fill 28 146 323 28 149 323 minecraft:honeycomb_block
fill 28 146 325 28 147 325 minecraft:honeycomb_block
setblock 28 146 363 minecraft:honey_block
setblock 30 146 325 minecraft:yellow_terracotta
fill 30 146 363 31 146 363 minecraft:honeycomb_block
setblock 31 146 324 minecraft:yellow_terracotta
fill 31 146 325 31 148 325 minecraft:honeycomb_block
setblock 32 146 323 minecraft:yellow_terracotta
fill 32 146 324 32 149 324 minecraft:honeycomb_block
fill 33 146 323 33 149 323 minecraft:honeycomb_block
setblock 37 146 323 minecraft:yellow_terracotta
setblock 39 146 323 minecraft:honey_block
setblock 40 146 329 minecraft:honeycomb_block
setblock 40 146 330 minecraft:yellow_terracotta
setblock 41 146 324 minecraft:yellow_terracotta
fill 41 146 325 41 149 325 minecraft:honeycomb_block
setblock 41 146 329 minecraft:yellow_terracotta
fill 41 146 330 41 149 330 minecraft:honeycomb_block
setblock 41 146 334 minecraft:yellow_terracotta
setblock 41 146 340 minecraft:honey_block
fill 41 146 352 41 146 353 minecraft:honeycomb_block
setblock 41 146 354 minecraft:yellow_terracotta
fill 41 146 355 41 146 358 minecraft:honeycomb_block
fill 42 146 348 42 157 348 minecraft:honeycomb_block
fill 0 147 342 0 167 343 minecraft:honeycomb_block
setblock 1 147 327 minecraft:honey_block
fill 1 147 329 1 150 329 minecraft:honeycomb_block
setblock 1 147 332 minecraft:honeycomb_block
setblock 1 147 333 minecraft:yellow_terracotta
setblock 1 147 346 minecraft:honey_block
setblock 1 147 348 minecraft:yellow_terracotta
fill 1 147 349 2 149 349 minecraft:honeycomb_block
setblock 1 147 353 minecraft:yellow_terracotta
fill 1 147 354 1 150 354 minecraft:honeycomb_block
setblock 1 147 358 minecraft:yellow_terracotta
fill 1 147 359 2 149 359 minecraft:honeycomb_block
setblock 1 147 362 minecraft:honeycomb_block
setblock 1 147 363 minecraft:yellow_terracotta
setblock 2 147 352 minecraft:yellow_terracotta
fill 2 147 353 2 150 353 minecraft:honeycomb_block
setblock 2 147 357 minecraft:yellow_terracotta
fill 2 147 358 3 149 358 minecraft:honeycomb_block
fill 2 147 360 2 148 360 minecraft:honeycomb_block
fill 2 147 363 5 147 363 minecraft:honeycomb_block
setblock 3 147 325 minecraft:light[level=12]
setblock 3 147 332 minecraft:light[level=12]
setblock 3 147 339 minecraft:light[level=12]
setblock 3 147 346 minecraft:light[level=12]
setblock 3 147 350 minecraft:honeycomb_block
setblock 3 147 351 minecraft:yellow_terracotta
fill 3 147 352 4 149 352 minecraft:honeycomb_block
setblock 3 147 355 minecraft:honeycomb_block
setblock 3 147 356 minecraft:yellow_terracotta
fill 3 147 357 3 150 357 minecraft:honeycomb_block
setblock 3 147 360 minecraft:light[level=12]
fill 4 147 353 4 147 354 minecraft:honeycomb_block
setblock 4 147 355 minecraft:yellow_terracotta
fill 4 147 356 4 150 356 minecraft:honeycomb_block
fill 4 147 362 6 147 362 minecraft:honeycomb_block
setblock 6 147 323 minecraft:yellow_terracotta
setblock 6 147 363 minecraft:yellow_terracotta
fill 7 147 323 7 150 323 minecraft:honeycomb_block
setblock 7 147 362 minecraft:yellow_terracotta
fill 7 147 363 7 150 363 minecraft:honeycomb_block
fill 8 147 362 8 150 362 minecraft:honeycomb_block
setblock 10 147 325 minecraft:light[level=12]
setblock 10 147 332 minecraft:light[level=12]
setblock 10 147 339 minecraft:light[level=12]
setblock 10 147 346 minecraft:light[level=12]
setblock 10 147 353 minecraft:light[level=12]
setblock 10 147 360 minecraft:light[level=12]
fill 10 147 362 10 148 362 minecraft:honeycomb_block
setblock 11 147 363 minecraft:yellow_terracotta
fill 16 147 364 16 149 364 minecraft:honeycomb_block
setblock 17 147 325 minecraft:light[level=12]
setblock 17 147 332 minecraft:light[level=12]
setblock 17 147 339 minecraft:light[level=12]
setblock 17 147 346 minecraft:light[level=12]
setblock 17 147 353 minecraft:light[level=12]
setblock 17 147 360 minecraft:light[level=12]
setblock 24 147 325 minecraft:light[level=12]
setblock 24 147 332 minecraft:light[level=12]
setblock 24 147 339 minecraft:light[level=12]
setblock 24 147 346 minecraft:light[level=12]
setblock 24 147 353 minecraft:light[level=12]
setblock 24 147 360 minecraft:light[level=12]
fill 26 147 322 26 162 322 minecraft:honeycomb_block
setblock 26 147 323 minecraft:yellow_terracotta
fill 26 147 324 26 150 324 minecraft:honeycomb_block
fill 27 147 323 27 150 323 minecraft:honeycomb_block
fill 27 147 363 30 147 363 minecraft:honeycomb_block
setblock 29 147 325 minecraft:yellow_terracotta
setblock 30 147 324 minecraft:yellow_terracotta
fill 30 147 325 30 149 325 minecraft:honeycomb_block
setblock 31 147 323 minecraft:yellow_terracotta
fill 31 147 324 31 150 324 minecraft:honeycomb_block
setblock 31 147 332 minecraft:light[level=12]
setblock 31 147 339 minecraft:light[level=12]
setblock 31 147 346 minecraft:light[level=12]
setblock 31 147 353 minecraft:light[level=12]
setblock 31 147 360 minecraft:light[level=12]
setblock 31 147 363 minecraft:yellow_terracotta
fill 32 147 323 32 150 323 minecraft:honeycomb_block
fill 32 147 363 33 149 363 minecraft:honeycomb_block
setblock 34 147 363 minecraft:honey_block
setblock 36 147 323 minecraft:yellow_terracotta
fill 37 147 323 37 150 323 minecraft:honeycomb_block
schedule function dropper:buildpart/72_5 1t
