setblock 4 264 332 minecraft:honeycomb_block
setblock 4 264 333 minecraft:yellow_terracotta
setblock 4 264 357 minecraft:yellow_terracotta
setblock 4 264 359 minecraft:yellow_terracotta
setblock 4 264 362 minecraft:honeycomb_block
setblock 4 264 363 minecraft:yellow_terracotta
fill 5 264 323 5 267 323 minecraft:honeycomb_block
setblock 5 264 362 minecraft:yellow_terracotta
fill 5 264 363 5 267 363 minecraft:honeycomb_block
setblock 6 264 326 minecraft:yellow_terracotta
setblock 6 264 357 minecraft:yellow_terracotta
setblock 6 264 359 minecraft:yellow_terracotta
fill 6 264 362 6 267 362 minecraft:honeycomb_block
setblock 7 264 325 minecraft:yellow_terracotta
setblock 7 264 326 minecraft:honeycomb_block
setblock 8 264 324 minecraft:yellow_terracotta
fill 8 264 325 8 265 325 minecraft:honeycomb_block
setblock 9 264 323 minecraft:yellow_terracotta
fill 9 264 324 9 266 324 minecraft:honeycomb_block
setblock 9 264 362 minecraft:honeycomb_block
setblock 9 264 363 minecraft:yellow_terracotta
fill 10 264 323 10 267 323 minecraft:honeycomb_block
fill 10 264 363 10 267 363 minecraft:honeycomb_block
setblock 13 264 363 minecraft:honeycomb_block
setblock 18 264 323 minecraft:honey_block
setblock 18 264 363 minecraft:honey_block
setblock 19 264 363 minecraft:yellow_terracotta
fill 20 264 363 20 267 363 minecraft:honeycomb_block
fill 21 264 364 21 308 364 minecraft:honeycomb_block
fill 23 264 362 24 264 362 minecraft:honeycomb_block
setblock 24 264 323 minecraft:yellow_terracotta
setblock 24 264 363 minecraft:yellow_terracotta
fill 24 264 364 24 308 364 minecraft:honeycomb_block
fill 25 264 323 25 267 323 minecraft:honeycomb_block
setblock 25 264 362 minecraft:yellow_terracotta
fill 25 264 363 25 267 363 minecraft:honeycomb_block
setblock 26 264 364 minecraft:yellow_terracotta
fill 32 264 338 32 266 338 minecraft:yellow_terracotta
setblock 34 264 364 minecraft:yellow_terracotta
fill 39 264 329 39 264 332 minecraft:honeycomb_block
setblock 39 264 333 minecraft:yellow_terracotta
fill 40 264 323 40 267 323 minecraft:honeycomb_block
fill 40 264 325 40 264 326 minecraft:honeycomb_block
setblock 40 264 327 minecraft:yellow_terracotta
fill 40 264 328 40 264 331 minecraft:honeycomb_block
setblock 40 264 332 minecraft:yellow_terracotta
fill 40 264 333 40 267 333 minecraft:honeycomb_block
setblock 40 264 337 minecraft:yellow_terracotta
fill 40 264 338 40 267 338 minecraft:honeycomb_block
setblock 40 264 347 minecraft:yellow_terracotta
fill 40 264 348 40 267 348 minecraft:honeycomb_block
setblock 40 264 352 minecraft:yellow_terracotta
fill 40 264 353 40 267 353 minecraft:honeycomb_block
setblock 41 264 326 minecraft:yellow_terracotta
fill 41 264 327 41 267 327 minecraft:honeycomb_block
setblock 41 264 331 minecraft:yellow_terracotta
fill 41 264 332 41 267 332 minecraft:honeycomb_block
setblock 41 264 335 minecraft:honeycomb_block
setblock 41 264 336 minecraft:yellow_terracotta
fill 41 264 337 41 267 337 minecraft:honeycomb_block
fill 41 264 339 41 264 340 minecraft:honeycomb_block
setblock 41 264 341 minecraft:yellow_terracotta
fill 41 264 342 41 267 342 minecraft:honeycomb_block
setblock 41 264 346 minecraft:yellow_terracotta
fill 41 264 347 41 267 347 minecraft:honeycomb_block
setblock 41 264 351 minecraft:yellow_terracotta
fill 41 264 352 41 267 352 minecraft:honeycomb_block
setblock 41 264 356 minecraft:yellow_terracotta
fill 41 264 357 41 267 357 minecraft:honeycomb_block
fill 42 264 350 42 308 350 minecraft:honeycomb_block
setblock 0 265 356 minecraft:yellow_concrete
setblock 1 265 325 minecraft:yellow_terracotta
fill 1 265 326 1 268 326 minecraft:honeycomb_block
setblock 1 265 330 minecraft:yellow_terracotta
fill 1 265 331 1 268 331 minecraft:honeycomb_block
setblock 1 265 334 minecraft:honeycomb_block
setblock 1 265 335 minecraft:yellow_terracotta
fill 1 265 336 1 268 336 minecraft:honeycomb_block
setblock 1 265 340 minecraft:yellow_terracotta
fill 1 265 341 1 268 341 minecraft:honeycomb_block
setblock 1 265 342 minecraft:honey_block
setblock 1 265 344 minecraft:honeycomb_block
setblock 1 265 345 minecraft:yellow_terracotta
fill 1 265 346 1 268 346 minecraft:honeycomb_block
setblock 1 265 350 minecraft:yellow_terracotta
fill 1 265 351 1 265 354 minecraft:honeycomb_block
setblock 1 265 355 minecraft:yellow_terracotta
fill 1 265 356 1 265 359 minecraft:honeycomb_block
setblock 1 265 360 minecraft:yellow_terracotta
fill 1 265 361 1 268 361 minecraft:honeycomb_block
setblock 2 265 324 minecraft:yellow_terracotta
fill 2 265 325 2 268 325 minecraft:honeycomb_block
setblock 2 265 329 minecraft:yellow_terracotta
fill 2 265 330 2 268 330 minecraft:honeycomb_block
setblock 2 265 333 minecraft:honeycomb_block
setblock 2 265 334 minecraft:yellow_terracotta
fill 2 265 335 2 268 335 minecraft:honeycomb_block
setblock 2 265 338 minecraft:honeycomb_block
setblock 2 265 348 minecraft:honeycomb_block
setblock 2 265 349 minecraft:yellow_terracotta
fill 2 265 350 2 268 350 minecraft:honeycomb_block
setblock 2 265 354 minecraft:yellow_terracotta
fill 2 265 355 3 267 355 minecraft:honeycomb_block
fill 2 265 357 2 265 358 minecraft:honeycomb_block
setblock 2 265 359 minecraft:yellow_terracotta
fill 2 265 360 2 268 360 minecraft:honeycomb_block
setblock 3 265 323 minecraft:yellow_terracotta
fill 3 265 324 3 268 324 minecraft:honeycomb_block
setblock 3 265 328 minecraft:yellow_terracotta
fill 3 265 329 3 268 329 minecraft:honeycomb_block
setblock 3 265 333 minecraft:yellow_terracotta
fill 3 265 334 3 268 334 minecraft:honeycomb_block
fill 3 265 336 3 266 336 minecraft:honeycomb_block
fill 3 265 351 3 265 352 minecraft:honeycomb_block
setblock 3 265 353 minecraft:yellow_terracotta
fill 3 265 354 3 268 354 minecraft:honeycomb_block
fill 3 265 356 3 266 356 minecraft:honeycomb_block
setblock 3 265 362 minecraft:honeycomb_block
setblock 3 265 363 minecraft:yellow_terracotta
fill 4 265 323 4 268 323 minecraft:honeycomb_block
setblock 4 265 327 minecraft:yellow_terracotta
fill 4 265 328 4 267 328 minecraft:honeycomb_block
setblock 4 265 332 minecraft:yellow_terracotta
fill 4 265 333 4 268 333 minecraft:honeycomb_block
setblock 4 265 362 minecraft:yellow_terracotta
fill 4 265 363 4 268 363 minecraft:honeycomb_block
setblock 4 265 364 minecraft:yellow_concrete
setblock 5 265 326 minecraft:yellow_terracotta
fill 5 265 362 5 268 362 minecraft:honeycomb_block
setblock 6 265 325 minecraft:yellow_terracotta
setblock 6 265 326 minecraft:honeycomb_block
setblock 7 265 324 minecraft:yellow_terracotta
fill 7 265 325 7 266 325 minecraft:honeycomb_block
setblock 8 265 323 minecraft:yellow_terracotta
fill 8 265 324 8 267 324 minecraft:honeycomb_block
setblock 8 265 363 minecraft:yellow_terracotta
fill 9 265 323 9 268 323 minecraft:honeycomb_block
setblock 9 265 362 minecraft:yellow_terracotta
fill 9 265 363 9 268 363 minecraft:honeycomb_block
setblock 13 265 363 minecraft:yellow_terracotta
setblock 17 265 363 minecraft:honeycomb_block
fill 18 265 363 18 265 364 minecraft:yellow_terracotta
fill 19 265 363 19 268 363 minecraft:honeycomb_block
fill 21 265 362 23 265 362 minecraft:honeycomb_block
setblock 23 265 323 minecraft:yellow_terracotta
setblock 23 265 363 minecraft:yellow_terracotta
fill 24 265 323 24 267 323 minecraft:honeycomb_block
setblock 24 265 362 minecraft:yellow_terracotta
fill 24 265 363 24 268 363 minecraft:honeycomb_block
fill 25 265 362 25 268 362 minecraft:honeycomb_block
fill 26 265 364 26 308 364 minecraft:honeycomb_block
fill 28 265 363 28 265 364 minecraft:yellow_terracotta
fill 30 265 363 30 266 363 minecraft:honey_block
fill 31 265 335 33 266 335 minecraft:honey_block
fill 32 265 334 32 266 334 minecraft:honey_block
fill 32 265 336 32 266 336 minecraft:honey_block
fill 34 265 364 34 290 364 minecraft:honeycomb_block
setblock 37 265 323 minecraft:honey_block
fill 39 265 328 39 265 331 minecraft:honeycomb_block
setblock 39 265 332 minecraft:yellow_terracotta
fill 39 265 333 39 266 335 minecraft:honeycomb_block
setblock 40 265 325 minecraft:honeycomb_block
setblock 40 265 326 minecraft:yellow_terracotta
fill 40 265 327 40 265 330 minecraft:honeycomb_block
setblock 40 265 331 minecraft:yellow_terracotta
fill 40 265 332 40 268 332 minecraft:honeycomb_block
fill 40 265 334 40 265 335 minecraft:honeycomb_block
setblock 40 265 336 minecraft:yellow_terracotta
fill 40 265 337 40 268 337 minecraft:honeycomb_block
fill 40 265 339 40 265 340 minecraft:honeycomb_block
fill 40 265 347 40 266 347 minecraft:honeycomb_block
fill 40 265 349 40 265 350 minecraft:honeycomb_block
setblock 40 265 351 minecraft:yellow_terracotta
fill 40 265 352 40 268 352 minecraft:honeycomb_block
fill 40 265 354 40 266 354 minecraft:honeycomb_block
setblock 41 265 325 minecraft:yellow_terracotta
fill 41 265 326 41 268 326 minecraft:honeycomb_block
setblock 41 265 330 minecraft:yellow_terracotta
fill 41 265 331 41 268 331 minecraft:honeycomb_block
setblock 41 265 335 minecraft:yellow_terracotta
fill 41 265 336 41 268 336 minecraft:honeycomb_block
setblock 41 265 339 minecraft:honeycomb_block
setblock 41 265 340 minecraft:yellow_terracotta
fill 41 265 341 41 268 341 minecraft:honeycomb_block
setblock 41 265 345 minecraft:yellow_terracotta
fill 41 265 346 41 268 346 minecraft:honeycomb_block
setblock 41 265 350 minecraft:yellow_terracotta
fill 41 265 351 41 268 351 minecraft:honeycomb_block
setblock 41 265 355 minecraft:yellow_terracotta
fill 41 265 356 41 268 356 minecraft:honeycomb_block
fill 41 265 358 41 266 358 minecraft:honeycomb_block
setblock 42 265 341 minecraft:yellow_terracotta
setblock 42 265 345 minecraft:orange_terracotta
fill 0 266 356 1 268 356 minecraft:honeycomb_block
setblock 1 266 324 minecraft:yellow_terracotta
fill 1 266 325 1 269 325 minecraft:honeycomb_block
setblock 1 266 329 minecraft:yellow_terracotta
fill 1 266 330 1 269 330 minecraft:honeycomb_block
setblock 1 266 334 minecraft:yellow_terracotta
fill 1 266 335 1 269 335 minecraft:honeycomb_block
setblock 1 266 339 minecraft:yellow_terracotta
fill 1 266 340 1 269 340 minecraft:honeycomb_block
fill 1 266 342 1 266 343 minecraft:honeycomb_block
setblock 1 266 344 minecraft:yellow_terracotta
fill 1 266 345 1 267 345 minecraft:honeycomb_block
setblock 1 266 349 minecraft:yellow_terracotta
fill 1 266 350 1 266 353 minecraft:honeycomb_block
setblock 1 266 354 minecraft:yellow_terracotta
fill 1 266 355 1 269 355 minecraft:honeycomb_block
fill 1 266 357 1 266 358 minecraft:honeycomb_block
setblock 1 266 359 minecraft:yellow_terracotta
fill 1 266 360 1 269 360 minecraft:honeycomb_block
setblock 2 266 323 minecraft:yellow_terracotta
fill 2 266 324 2 269 324 minecraft:honeycomb_block
setblock 2 266 328 minecraft:yellow_terracotta
fill 2 266 329 2 269 329 minecraft:honeycomb_block
setblock 2 266 333 minecraft:yellow_terracotta
fill 2 266 334 2 269 334 minecraft:honeycomb_block
setblock 2 266 338 minecraft:yellow_terracotta
fill 2 266 339 2 269 339 minecraft:honeycomb_block
setblock 2 266 348 minecraft:yellow_terracotta
fill 2 266 349 2 268 349 minecraft:honeycomb_block
setblock 2 266 352 minecraft:honeycomb_block
setblock 2 266 353 minecraft:yellow_terracotta
fill 2 266 354 2 269 354 minecraft:honeycomb_block
setblock 2 266 357 minecraft:honeycomb_block
setblock 2 266 358 minecraft:yellow_terracotta
fill 2 266 359 2 269 359 minecraft:honeycomb_block
fill 2 266 361 2 266 362 minecraft:honeycomb_block
setblock 2 266 363 minecraft:yellow_terracotta
fill 3 266 323 3 269 323 minecraft:honeycomb_block
setblock 3 266 327 minecraft:yellow_terracotta
fill 3 266 328 3 269 328 minecraft:honeycomb_block
setblock 3 266 331 minecraft:honeycomb_block
setblock 3 266 332 minecraft:yellow_terracotta
fill 3 266 333 3 269 333 minecraft:honeycomb_block
setblock 3 266 351 minecraft:honeycomb_block
setblock 3 266 352 minecraft:yellow_terracotta
fill 3 266 353 3 269 353 minecraft:honeycomb_block
setblock 3 266 357 minecraft:yellow_terracotta
fill 3 266 358 3 269 358 minecraft:honeycomb_block
setblock 3 266 362 minecraft:yellow_terracotta
fill 3 266 363 3 269 363 minecraft:honeycomb_block
fill 4 266 326 4 271 326 minecraft:yellow_terracotta
fill 4 266 327 4 267 327 minecraft:honeycomb_block
setblock 4 266 331 minecraft:yellow_terracotta
fill 4 266 332 4 268 332 minecraft:honeycomb_block
fill 4 266 334 4 267 334 minecraft:honeycomb_block
fill 4 266 362 4 269 362 minecraft:honeycomb_block
fill 4 266 364 4 279 364 minecraft:honeycomb_block
setblock 5 266 325 minecraft:yellow_terracotta
setblock 5 266 326 minecraft:honeycomb_block
setblock 6 266 324 minecraft:yellow_terracotta
fill 6 266 325 6 267 325 minecraft:honeycomb_block
setblock 7 266 323 minecraft:yellow_terracotta
fill 7 266 324 7 268 324 minecraft:honeycomb_block
setblock 7 266 362 minecraft:honeycomb_block
setblock 7 266 363 minecraft:yellow_terracotta
fill 8 266 323 8 269 323 minecraft:honeycomb_block
setblock 8 266 362 minecraft:yellow_terracotta
fill 8 266 363 8 269 363 minecraft:honeycomb_block
fill 9 266 362 9 268 362 minecraft:honeycomb_block
setblock 12 266 363 minecraft:yellow_terracotta
fill 13 266 363 16 266 363 minecraft:honeycomb_block
setblock 17 266 363 minecraft:yellow_terracotta
fill 18 266 363 18 269 364 minecraft:honeycomb_block
fill 20 266 362 22 266 362 minecraft:honeycomb_block
setblock 22 266 323 minecraft:yellow_terracotta
setblock 22 266 363 minecraft:yellow_terracotta
fill 22 266 364 22 279 364 minecraft:honeycomb_block
fill 23 266 323 23 268 323 minecraft:honeycomb_block
setblock 23 266 362 minecraft:yellow_terracotta
fill 23 266 363 23 269 363 minecraft:honeycomb_block
fill 24 266 362 24 269 362 minecraft:honeycomb_block
setblock 27 266 363 minecraft:yellow_terracotta
fill 28 266 364 28 274 364 minecraft:honeycomb_block
setblock 31 266 323 minecraft:honey_block
fill 34 266 349 34 267 349 minecraft:flowering_azalea_leaves[persistent=true]
setblock 36 266 363 minecraft:honey_block
fill 37 266 349 37 267 349 minecraft:flowering_azalea_leaves[persistent=true]
fill 39 266 323 39 268 323 minecraft:honeycomb_block
fill 39 266 328 39 266 330 minecraft:honeycomb_block
setblock 39 266 331 minecraft:yellow_terracotta
fill 39 266 332 39 269 332 minecraft:honeycomb_block
setblock 39 266 336 minecraft:yellow_terracotta
fill 39 266 337 39 269 337 minecraft:honeycomb_block
setblock 40 266 324 minecraft:honeycomb_block
setblock 40 266 325 minecraft:yellow_terracotta
fill 40 266 326 40 266 329 minecraft:honeycomb_block
setblock 40 266 330 minecraft:yellow_terracotta
fill 40 266 331 40 269 331 minecraft:honeycomb_block
setblock 40 266 334 minecraft:honeycomb_block
setblock 40 266 335 minecraft:yellow_terracotta
fill 40 266 336 40 269 336 minecraft:honeycomb_block
setblock 40 266 339 minecraft:honeycomb_block
setblock 40 266 340 minecraft:yellow_terracotta
fill 40 266 341 40 269 341 minecraft:honeycomb_block
setblock 40 266 349 minecraft:honeycomb_block
setblock 40 266 350 minecraft:yellow_terracotta
fill 40 266 351 40 269 351 minecraft:honeycomb_block
setblock 40 266 355 minecraft:yellow_terracotta
fill 40 266 356 40 269 356 minecraft:honeycomb_block
setblock 41 266 324 minecraft:yellow_terracotta
fill 41 266 325 41 269 325 minecraft:honeycomb_block
setblock 41 266 329 minecraft:yellow_terracotta
fill 41 266 330 41 269 330 minecraft:honeycomb_block
setblock 41 266 334 minecraft:yellow_terracotta
fill 41 266 335 41 269 335 minecraft:honeycomb_block
setblock 41 266 339 minecraft:yellow_terracotta
fill 41 266 340 41 269 340 minecraft:honeycomb_block
setblock 41 266 344 minecraft:yellow_terracotta
fill 41 266 345 42 269 345 minecraft:honeycomb_block
setblock 41 266 349 minecraft:yellow_terracotta
fill 41 266 350 41 269 350 minecraft:honeycomb_block
setblock 41 266 354 minecraft:yellow_terracotta
fill 41 266 355 41 269 355 minecraft:honeycomb_block
setblock 41 266 359 minecraft:yellow_terracotta
fill 41 266 360 41 269 360 minecraft:honeycomb_block
fill 42 266 341 42 308 341 minecraft:honeycomb_block
setblock 42 266 346 minecraft:yellow_terracotta
setblock 1 267 323 minecraft:yellow_terracotta
fill 1 267 324 1 270 324 minecraft:honeycomb_block
setblock 1 267 328 minecraft:yellow_terracotta
fill 1 267 329 1 270 329 minecraft:honeycomb_block
setblock 1 267 333 minecraft:yellow_terracotta
fill 1 267 334 1 270 334 minecraft:honeycomb_block
setblock 1 267 337 minecraft:honeycomb_block
setblock 1 267 338 minecraft:yellow_terracotta
fill 1 267 339 1 270 339 minecraft:honeycomb_block
setblock 1 267 342 minecraft:honeycomb_block
setblock 1 267 343 minecraft:yellow_terracotta
setblock 1 267 344 minecraft:honeycomb_block
setblock 1 267 348 minecraft:yellow_terracotta
fill 1 267 349 1 267 352 minecraft:honeycomb_block
setblock 1 267 353 minecraft:yellow_terracotta
fill 1 267 354 1 270 354 minecraft:honeycomb_block
setblock 1 267 357 minecraft:honeycomb_block
setblock 1 267 358 minecraft:yellow_terracotta
fill 1 267 359 1 270 359 minecraft:honeycomb_block
setblock 1 267 362 minecraft:honeycomb_block
setblock 1 267 363 minecraft:yellow_terracotta
fill 2 267 323 2 270 323 minecraft:honeycomb_block
setblock 2 267 327 minecraft:yellow_terracotta
fill 2 267 328 2 270 328 minecraft:honeycomb_block
setblock 2 267 332 minecraft:yellow_terracotta
fill 2 267 333 2 270 333 minecraft:honeycomb_block
setblock 2 267 337 minecraft:yellow_terracotta
fill 2 267 338 2 270 338 minecraft:honeycomb_block
setblock 2 267 352 minecraft:yellow_terracotta
fill 2 267 353 2 270 353 minecraft:honeycomb_block
setblock 2 267 357 minecraft:yellow_terracotta
fill 2 267 358 2 270 358 minecraft:honeycomb_block
setblock 2 267 361 minecraft:honeycomb_block
setblock 2 267 362 minecraft:yellow_terracotta
fill 2 267 363 2 270 363 minecraft:honeycomb_block
setblock 3 267 326 minecraft:yellow_terracotta
fill 3 267 327 3 269 327 minecraft:honeycomb_block
setblock 3 267 331 minecraft:yellow_terracotta
fill 3 267 332 3 270 332 minecraft:honeycomb_block
setblock 3 267 336 minecraft:yellow_terracotta
fill 3 267 337 3 268 337 minecraft:honeycomb_block
setblock 3 267 339 minecraft:light[level=12]
setblock 3 267 346 minecraft:light[level=12]
setblock 3 267 351 minecraft:yellow_terracotta
fill 3 267 352 3 268 352 minecraft:honeycomb_block
setblock 3 267 356 minecraft:yellow_terracotta
fill 3 267 357 3 270 357 minecraft:honeycomb_block
fill 3 267 359 3 267 360 minecraft:honeycomb_block
setblock 3 267 361 minecraft:yellow_terracotta
fill 3 267 362 3 270 362 minecraft:honeycomb_block
setblock 4 267 325 minecraft:yellow_terracotta
setblock 4 267 330 minecraft:yellow_terracotta
fill 4 267 331 4 268 331 minecraft:honeycomb_block
fill 4 267 361 6 268 361 minecraft:honeycomb_block
setblock 5 267 324 minecraft:yellow_terracotta
fill 5 267 325 5 268 325 minecraft:honeycomb_block
fill 5 267 326 5 271 326 minecraft:yellow_terracotta
setblock 6 267 323 minecraft:yellow_terracotta
fill 6 267 324 6 269 324 minecraft:honeycomb_block
setblock 6 267 363 minecraft:yellow_terracotta
fill 7 267 323 7 270 323 minecraft:honeycomb_block
setblock 7 267 362 minecraft:yellow_terracotta
fill 7 267 363 7 270 363 minecraft:honeycomb_block
fill 8 267 362 8 270 362 minecraft:honeycomb_block
setblock 10 267 325 minecraft:light[level=12]
setblock 10 267 332 minecraft:light[level=12]
setblock 10 267 339 minecraft:light[level=12]
setblock 10 267 346 minecraft:light[level=12]
setblock 10 267 353 minecraft:light[level=12]
setblock 10 267 360 minecraft:light[level=12]
setblock 11 267 363 minecraft:yellow_terracotta
fill 12 267 363 15 267 363 minecraft:honeycomb_block
setblock 16 267 363 minecraft:yellow_terracotta
setblock 17 267 325 minecraft:light[level=12]
setblock 17 267 332 minecraft:light[level=12]
setblock 17 267 339 minecraft:light[level=12]
setblock 17 267 346 minecraft:light[level=12]
setblock 17 267 353 minecraft:light[level=12]
setblock 17 267 360 minecraft:light[level=12]
fill 17 267 363 17 270 363 minecraft:honeycomb_block
fill 19 267 362 21 267 362 minecraft:honeycomb_block
setblock 21 267 322 minecraft:orange_terracotta
setblock 21 267 323 minecraft:yellow_terracotta
setblock 21 267 363 minecraft:yellow_terracotta
fill 22 267 323 22 268 323 minecraft:honeycomb_block
setblock 22 267 362 minecraft:yellow_terracotta
fill 22 267 363 22 270 363 minecraft:honeycomb_block
fill 23 267 362 23 270 362 minecraft:honeycomb_block
setblock 24 267 325 minecraft:light[level=12]
setblock 24 267 332 minecraft:light[level=12]
setblock 24 267 339 minecraft:light[level=12]
setblock 24 267 346 minecraft:light[level=12]
setblock 24 267 353 minecraft:light[level=12]
setblock 24 267 360 minecraft:light[level=12]
setblock 25 267 322 minecraft:orange_terracotta
setblock 26 267 363 minecraft:yellow_terracotta
setblock 27 267 363 minecraft:honeycomb_block
setblock 31 267 325 minecraft:light[level=12]
setblock 31 267 332 minecraft:light[level=12]
fill 31 267 337 33 269 340 minecraft:flowering_azalea_leaves[persistent=true]
setblock 31 267 346 minecraft:light[level=12]
setblock 31 267 353 minecraft:light[level=12]
setblock 31 267 360 minecraft:light[level=12]
fill 34 267 338 34 269 338 minecraft:flowering_azalea_leaves[persistent=true]
fill 35 267 350 36 267 350 minecraft:flowering_azalea_leaves[persistent=true]
fill 37 267 352 37 271 352 minecraft:yellow_terracotta
setblock 38 267 325 minecraft:light[level=12]
setblock 38 267 332 minecraft:light[level=12]
setblock 38 267 339 minecraft:light[level=12]
setblock 38 267 346 minecraft:light[level=12]
setblock 38 267 353 minecraft:light[level=12]
setblock 38 267 360 minecraft:light[level=12]
fill 39 267 328 39 267 329 minecraft:honeycomb_block
setblock 39 267 330 minecraft:yellow_terracotta
fill 39 267 331 39 270 331 minecraft:honeycomb_block
fill 39 267 333 39 267 334 minecraft:honeycomb_block
setblock 39 267 335 minecraft:yellow_terracotta
fill 39 267 336 39 270 336 minecraft:honeycomb_block
fill 39 267 338 39 268 338 minecraft:honeycomb_block
setblock 40 267 324 minecraft:yellow_terracotta
fill 40 267 325 40 267 328 minecraft:honeycomb_block
setblock 40 267 329 minecraft:yellow_terracotta
fill 40 267 330 40 270 330 minecraft:honeycomb_block
setblock 40 267 334 minecraft:yellow_terracotta
fill 40 267 335 40 270 335 minecraft:honeycomb_block
setblock 40 267 339 minecraft:yellow_terracotta
fill 40 267 340 40 270 340 minecraft:honeycomb_block
fill 40 267 342 40 268 342 minecraft:honeycomb_block
setblock 40 267 349 minecraft:yellow_terracotta
fill 40 267 350 40 268 350 minecraft:honeycomb_block
setblock 40 267 354 minecraft:yellow_terracotta
fill 40 267 355 40 270 355 minecraft:honeycomb_block
fill 40 267 357 40 268 357 minecraft:honeycomb_block
setblock 41 267 323 minecraft:yellow_terracotta
fill 41 267 324 41 270 324 minecraft:honeycomb_block
setblock 41 267 328 minecraft:yellow_terracotta
fill 41 267 329 41 270 329 minecraft:honeycomb_block
setblock 41 267 333 minecraft:yellow_terracotta
fill 41 267 334 41 270 334 minecraft:honeycomb_block
setblock 41 267 338 minecraft:yellow_terracotta
fill 41 267 339 41 270 339 minecraft:honeycomb_block
setblock 41 267 343 minecraft:yellow_terracotta
fill 41 267 344 41 270 344 minecraft:honeycomb_block
setblock 41 267 348 minecraft:yellow_terracotta
fill 41 267 349 41 270 349 minecraft:honeycomb_block
setblock 41 267 353 minecraft:yellow_terracotta
fill 41 267 354 41 270 354 minecraft:honeycomb_block
setblock 41 267 358 minecraft:yellow_terracotta
fill 41 267 359 41 270 359 minecraft:honeycomb_block
fill 41 267 361 41 267 362 minecraft:honeycomb_block
setblock 41 267 363 minecraft:yellow_terracotta
fill 42 267 346 42 308 346 minecraft:honeycomb_block
fill 1 268 323 1 271 323 minecraft:honeycomb_block
setblock 1 268 327 minecraft:yellow_terracotta
fill 1 268 328 1 271 328 minecraft:honeycomb_block
setblock 1 268 332 minecraft:yellow_terracotta
fill 1 268 333 1 271 333 minecraft:honeycomb_block
setblock 1 268 337 minecraft:yellow_terracotta
fill 1 268 338 1 271 338 minecraft:honeycomb_block
setblock 1 268 342 minecraft:yellow_terracotta
setblock 1 268 343 minecraft:honeycomb_block
setblock 1 268 347 minecraft:yellow_terracotta
fill 1 268 348 1 268 351 minecraft:honeycomb_block
setblock 1 268 352 minecraft:yellow_terracotta
fill 1 268 353 1 271 353 minecraft:honeycomb_block
setblock 1 268 357 minecraft:yellow_terracotta
fill 1 268 358 1 271 358 minecraft:honeycomb_block
setblock 1 268 362 minecraft:yellow_terracotta
fill 1 268 363 1 271 363 minecraft:honeycomb_block
setblock 2 268 326 minecraft:yellow_terracotta
fill 2 268 327 2 271 327 minecraft:honeycomb_block
setblock 2 268 331 minecraft:yellow_terracotta
fill 2 268 332 2 271 332 minecraft:honeycomb_block
setblock 2 268 336 minecraft:yellow_terracotta
fill 2 268 337 2 271 337 minecraft:honeycomb_block
setblock 2 268 351 minecraft:yellow_terracotta
fill 2 268 352 2 271 352 minecraft:honeycomb_block
setblock 2 268 355 minecraft:honeycomb_block
setblock 2 268 356 minecraft:yellow_terracotta
fill 2 268 357 2 271 357 minecraft:honeycomb_block
setblock 2 268 361 minecraft:yellow_terracotta
fill 2 268 362 2 271 362 minecraft:honeycomb_block
setblock 3 268 325 minecraft:yellow_terracotta
fill 3 268 326 3 269 326 minecraft:honeycomb_block
setblock 3 268 330 minecraft:yellow_terracotta
fill 3 268 331 3 270 331 minecraft:honeycomb_block
setblock 3 268 335 minecraft:yellow_terracotta
fill 3 268 336 3 270 336 minecraft:honeycomb_block
setblock 3 268 355 minecraft:yellow_terracotta
fill 3 268 356 3 271 356 minecraft:honeycomb_block
setblock 3 268 359 minecraft:honeycomb_block
setblock 3 268 360 minecraft:yellow_terracotta
fill 3 268 361 3 271 361 minecraft:honeycomb_block
setblock 4 268 324 minecraft:yellow_terracotta
setblock 4 268 325 minecraft:honeycomb_block
fill 4 268 327 5 268 328 minecraft:honey_block
setblock 4 268 329 minecraft:yellow_terracotta
setblock 4 268 330 minecraft:honeycomb_block
setblock 5 268 323 minecraft:yellow_terracotta
fill 5 268 324 5 269 324 minecraft:honeycomb_block
setblock 5 268 363 minecraft:yellow_terracotta
fill 6 268 323 6 271 323 minecraft:honeycomb_block
fill 6 268 325 6 269 327 minecraft:honey_block
setblock 6 268 362 minecraft:yellow_terracotta
fill 6 268 363 6 271 363 minecraft:honeycomb_block
fill 7 268 325 7 268 326 minecraft:honey_block
fill 7 268 362 7 271 362 minecraft:honeycomb_block
setblock 10 268 363 minecraft:yellow_terracotta
fill 11 268 363 14 268 363 minecraft:honeycomb_block
fill 12 268 331 12 269 332 minecraft:black_concrete
setblock 15 268 363 minecraft:yellow_terracotta
fill 16 268 363 16 271 363 minecraft:honeycomb_block
fill 17 268 326 17 268 330 minecraft:honey_block
fill 18 268 325 18 268 327 minecraft:honey_block
fill 18 268 329 18 269 330 minecraft:honey_block
fill 18 268 362 20 268 362 minecraft:honeycomb_block
setblock 19 268 323 minecraft:honey_block
fill 19 268 325 19 269 326 minecraft:honey_block
fill 19 268 330 21 268 331 minecraft:honey_block
fill 20 268 325 22 268 325 minecraft:honey_block
setblock 20 268 363 minecraft:yellow_terracotta
fill 21 268 322 21 308 322 minecraft:honeycomb_block
fill 21 268 326 22 269 326 minecraft:honey_block
setblock 21 268 361 minecraft:honeycomb_block
setblock 21 268 362 minecraft:yellow_terracotta
fill 21 268 363 21 271 363 minecraft:honeycomb_block
fill 22 268 327 22 268 330 minecraft:honey_block
setblock 22 268 361 minecraft:yellow_terracotta
fill 22 268 362 22 271 362 minecraft:honeycomb_block
setblock 23 268 322 minecraft:yellow_terracotta
fill 23 268 327 23 268 329 minecraft:honey_block
fill 25 268 322 25 291 322 minecraft:honeycomb_block
setblock 25 268 363 minecraft:yellow_terracotta
setblock 26 268 322 minecraft:yellow_terracotta
fill 26 268 343 27 268 344 minecraft:honey_block
fill 26 268 363 26 269 363 minecraft:honeycomb_block
fill 27 268 342 28 269 342 minecraft:honey_block
fill 27 268 345 27 268 346 minecraft:honey_block
fill 28 268 341 31 268 341 minecraft:honey_block
fill 28 268 346 33 268 346 minecraft:honey_block
fill 29 268 347 33 268 347 minecraft:honey_block
fill 30 268 338 30 268 339 minecraft:flowering_azalea_leaves[persistent=true]
fill 30 268 342 32 268 342 minecraft:honey_block
fill 31 268 343 32 268 345 minecraft:honey_block
setblock 32 268 336 minecraft:flowering_azalea_leaves[persistent=true]
fill 32 268 348 33 268 349 minecraft:honey_block
fill 33 268 344 34 268 345 minecraft:honey_block
fill 33 268 350 39 268 350 minecraft:honey_block
setblock 34 268 337 minecraft:flowering_azalea_leaves[persistent=true]
setblock 34 268 339 minecraft:flowering_azalea_leaves[persistent=true]
fill 34 268 343 37 268 343 minecraft:honey_block
fill 34 268 349 34 270 349 minecraft:honey_block
fill 34 268 351 37 268 351 minecraft:honey_block
fill 35 268 344 38 268 344 minecraft:honey_block
fill 37 268 345 39 268 345 minecraft:honey_block
fill 37 268 349 39 268 349 minecraft:honey_block
setblock 38 268 323 minecraft:honey_block
fill 38 268 332 38 268 334 minecraft:honeycomb_block
fill 38 268 346 39 269 348 minecraft:honey_block
setblock 39 268 328 minecraft:honeycomb_block
setblock 39 268 329 minecraft:yellow_terracotta
fill 39 268 330 39 271 330 minecraft:honeycomb_block
setblock 39 268 333 minecraft:honeycomb_block
setblock 39 268 334 minecraft:yellow_terracotta
fill 39 268 335 39 271 335 minecraft:honeycomb_block
setblock 40 268 323 minecraft:yellow_terracotta
fill 40 268 324 40 268 327 minecraft:honeycomb_block
setblock 40 268 328 minecraft:yellow_terracotta
fill 40 268 329 40 271 329 minecraft:honeycomb_block
setblock 40 268 333 minecraft:yellow_terracotta
fill 40 268 334 40 271 334 minecraft:honeycomb_block
setblock 40 268 338 minecraft:yellow_terracotta
fill 40 268 339 40 271 339 minecraft:honeycomb_block
setblock 40 268 347 minecraft:honey_block
setblock 40 268 349 minecraft:honeycomb_block
setblock 40 268 353 minecraft:yellow_terracotta
fill 40 268 354 40 271 354 minecraft:honeycomb_block
setblock 40 268 358 minecraft:yellow_terracotta
fill 41 268 323 41 271 323 minecraft:honeycomb_block
setblock 41 268 327 minecraft:yellow_terracotta
fill 41 268 328 41 271 328 minecraft:honeycomb_block
setblock 41 268 332 minecraft:yellow_terracotta
fill 41 268 333 41 271 333 minecraft:honeycomb_block
setblock 41 268 337 minecraft:yellow_terracotta
fill 41 268 338 41 271 338 minecraft:honeycomb_block
setblock 41 268 342 minecraft:yellow_terracotta
fill 41 268 343 41 271 343 minecraft:honeycomb_block
setblock 41 268 347 minecraft:yellow_terracotta
fill 41 268 348 41 270 348 minecraft:honeycomb_block
setblock 41 268 352 minecraft:yellow_terracotta
fill 41 268 353 41 271 353 minecraft:honeycomb_block
setblock 41 268 357 minecraft:yellow_terracotta
fill 41 268 358 41 271 358 minecraft:honeycomb_block
setblock 41 268 361 minecraft:honeycomb_block
setblock 41 268 362 minecraft:yellow_terracotta
fill 41 268 363 41 271 363 minecraft:honeycomb_block
fill 0 269 356 0 307 356 minecraft:honeycomb_block
setblock 1 269 326 minecraft:yellow_terracotta
fill 1 269 327 1 271 327 minecraft:honeycomb_block
setblock 1 269 331 minecraft:yellow_terracotta
fill 1 269 332 1 271 332 minecraft:honeycomb_block
setblock 1 269 336 minecraft:yellow_terracotta
fill 1 269 337 1 271 337 minecraft:honeycomb_block
setblock 1 269 341 minecraft:yellow_terracotta
fill 1 269 342 1 271 342 minecraft:honeycomb_block
setblock 1 269 347 minecraft:honey_block
fill 1 269 348 1 269 350 minecraft:honeycomb_block
setblock 1 269 351 minecraft:yellow_terracotta
fill 1 269 352 1 271 352 minecraft:honeycomb_block
setblock 1 269 356 minecraft:yellow_terracotta
fill 1 269 357 1 271 357 minecraft:honeycomb_block
setblock 1 269 361 minecraft:yellow_terracotta
fill 1 269 362 1 271 362 minecraft:honeycomb_block
setblock 2 269 325 minecraft:yellow_terracotta
fill 2 269 326 2 271 326 minecraft:honeycomb_block
setblock 2 269 330 minecraft:yellow_terracotta
fill 2 269 331 2 271 331 minecraft:honeycomb_block
setblock 2 269 335 minecraft:yellow_terracotta
fill 2 269 336 2 271 336 minecraft:honeycomb_block
setblock 2 269 350 minecraft:yellow_terracotta
fill 2 269 351 2 270 351 minecraft:honeycomb_block
setblock 2 269 355 minecraft:yellow_terracotta
fill 2 269 356 2 271 356 minecraft:honeycomb_block
setblock 2 269 360 minecraft:yellow_terracotta
fill 2 269 361 2 271 361 minecraft:honeycomb_block
setblock 3 269 324 minecraft:yellow_terracotta
fill 3 269 325 3 270 325 minecraft:honey_block
setblock 3 269 329 minecraft:yellow_terracotta
fill 3 269 330 3 270 330 minecraft:honeycomb_block
setblock 3 269 334 minecraft:yellow_terracotta
fill 3 269 335 3 270 335 minecraft:honeycomb_block
setblock 3 269 354 minecraft:yellow_terracotta
fill 3 269 355 3 271 355 minecraft:honeycomb_block
setblock 3 269 359 minecraft:yellow_terracotta
fill 3 269 360 3 271 360 minecraft:honeycomb_block
setblock 4 269 323 minecraft:yellow_terracotta
fill 4 269 324 4 270 324 minecraft:honeycomb_block
fill 4 269 325 5 271 325 minecraft:yellow_terracotta
fill 4 269 327 5 270 327 minecraft:honey_block
fill 4 269 361 5 269 361 minecraft:honeycomb_block
setblock 4 269 363 minecraft:yellow_terracotta
fill 5 269 323 5 271 323 minecraft:honeycomb_block
setblock 5 269 362 minecraft:yellow_terracotta
fill 5 269 363 5 271 363 minecraft:honeycomb_block
fill 6 269 362 6 271 362 minecraft:honeycomb_block
setblock 9 269 363 minecraft:yellow_terracotta
fill 10 269 363 13 269 363 minecraft:honeycomb_block
setblock 13 269 323 minecraft:honey_block
fill 13 269 352 13 270 352 minecraft:black_concrete
fill 14 269 352 14 270 352 minecraft:yellow_concrete
setblock 14 269 363 minecraft:yellow_terracotta
fill 15 269 363 15 271 363 minecraft:honeycomb_block
fill 17 269 327 17 269 329 minecraft:honey_block
fill 18 269 326 18 269 327 minecraft:honey_block
fill 18 269 362 19 269 362 minecraft:honeycomb_block
fill 19 269 330 21 270 330 minecraft:honey_block
setblock 19 269 363 minecraft:yellow_terracotta
fill 20 269 325 21 269 325 minecraft:honey_block
fill 20 269 353 20 270 353 minecraft:honey_block
setblock 20 269 362 minecraft:yellow_terracotta
fill 20 269 363 20 271 363 minecraft:honeycomb_block
setblock 21 269 361 minecraft:yellow_terracotta
fill 21 269 362 21 271 362 minecraft:honeycomb_block
fill 22 269 327 22 270 329 minecraft:honey_block
setblock 22 269 361 minecraft:honeycomb_block
fill 23 269 322 23 278 322 minecraft:honeycomb_block
setblock 24 269 363 minecraft:yellow_terracotta
fill 25 269 363 25 270 363 minecraft:honeycomb_block
fill 26 269 322 26 308 322 minecraft:honeycomb_block
fill 27 269 343 27 269 345 minecraft:honey_block
fill 28 269 346 30 269 346 minecraft:honey_block
fill 29 269 341 30 269 341 minecraft:honey_block
setblock 29 269 363 minecraft:honey_block
fill 30 269 342 31 269 342 minecraft:honey_block
fill 31 269 343 31 270 345 minecraft:honey_block
setblock 32 269 323 minecraft:honey_block
setblock 32 269 344 minecraft:honey_block
fill 32 269 346 33 269 348 minecraft:honey_block
fill 33 269 345 34 269 345 minecraft:honey_block
setblock 33 269 349 minecraft:honey_block
fill 34 269 344 37 269 344 minecraft:honey_block
fill 34 269 350 38 269 350 minecraft:honey_block
fill 37 269 345 38 269 345 minecraft:honey_block
fill 37 269 349 38 269 349 minecraft:honey_block
setblock 38 269 333 minecraft:honeycomb_block
setblock 38 269 334 minecraft:yellow_terracotta
fill 38 269 335 38 271 335 minecraft:honeycomb_block
setblock 39 269 323 minecraft:yellow_terracotta
setblock 39 269 328 minecraft:yellow_terracotta
fill 39 269 329 39 270 329 minecraft:honeycomb_block
setblock 39 269 333 minecraft:yellow_terracotta
fill 39 269 334 39 271 334 minecraft:honeycomb_block
setblock 39 269 338 minecraft:yellow_terracotta
fill 39 269 339 39 271 339 minecraft:honeycomb_block
fill 40 269 323 40 269 326 minecraft:honeycomb_block
setblock 40 269 327 minecraft:yellow_terracotta
fill 40 269 328 40 271 328 minecraft:honeycomb_block
setblock 40 269 332 minecraft:yellow_terracotta
fill 40 269 333 40 271 333 minecraft:honeycomb_block
setblock 40 269 337 minecraft:yellow_terracotta
fill 40 269 338 40 271 338 minecraft:honeycomb_block
setblock 40 269 342 minecraft:yellow_terracotta
setblock 40 269 352 minecraft:yellow_terracotta
fill 40 269 353 40 270 353 minecraft:honeycomb_block
setblock 40 269 357 minecraft:yellow_terracotta
fill 40 269 358 40 271 359 minecraft:honeycomb_block
fill 40 269 363 40 271 363 minecraft:honeycomb_block
setblock 41 269 326 minecraft:yellow_terracotta
fill 41 269 327 41 271 327 minecraft:honeycomb_block
setblock 41 269 331 minecraft:yellow_terracotta
fill 41 269 332 41 271 332 minecraft:honeycomb_block
setblock 41 269 336 minecraft:yellow_terracotta
fill 41 269 337 41 271 337 minecraft:honeycomb_block
setblock 41 269 341 minecraft:yellow_terracotta
fill 41 269 342 41 271 342 minecraft:honeycomb_block
setblock 41 269 346 minecraft:yellow_terracotta
fill 41 269 347 41 270 347 minecraft:honeycomb_block
setblock 41 269 351 minecraft:yellow_terracotta
fill 41 269 352 41 271 352 minecraft:honeycomb_block
setblock 41 269 356 minecraft:yellow_terracotta
fill 41 269 357 41 271 357 minecraft:honeycomb_block
setblock 41 269 361 minecraft:yellow_terracotta
fill 41 269 362 41 271 362 minecraft:honeycomb_block
setblock 1 270 325 minecraft:yellow_terracotta
fill 1 270 326 1 271 326 minecraft:honeycomb_block
setblock 1 270 330 minecraft:yellow_terracotta
fill 1 270 331 1 271 331 minecraft:honeycomb_block
setblock 1 270 335 minecraft:yellow_terracotta
fill 1 270 336 1 271 336 minecraft:honeycomb_block
setblock 1 270 340 minecraft:yellow_terracotta
fill 1 270 341 1 271 341 minecraft:honeycomb_block
setblock 1 270 349 minecraft:honeycomb_block
setblock 1 270 350 minecraft:yellow_terracotta
fill 1 270 351 1 271 351 minecraft:honeycomb_block
setblock 1 270 355 minecraft:yellow_terracotta
fill 1 270 356 1 271 356 minecraft:honeycomb_block
setblock 1 270 360 minecraft:yellow_terracotta
fill 1 270 361 1 271 361 minecraft:honeycomb_block
setblock 2 270 324 minecraft:yellow_terracotta
fill 2 270 325 2 271 325 minecraft:honeycomb_block
setblock 2 270 329 minecraft:yellow_terracotta
fill 2 270 330 2 271 330 minecraft:honeycomb_block
setblock 2 270 334 minecraft:yellow_terracotta
fill 2 270 335 2 271 335 minecraft:honeycomb_block
setblock 2 270 339 minecraft:yellow_terracotta
setblock 2 270 354 minecraft:yellow_terracotta
fill 2 270 355 2 271 355 minecraft:honeycomb_block
setblock 2 270 359 minecraft:yellow_terracotta
fill 2 270 360 2 271 360 minecraft:honeycomb_block
setblock 3 270 323 minecraft:yellow_terracotta
fill 3 270 324 3 271 324 minecraft:honeycomb_block
setblock 3 270 326 minecraft:honey_block
setblock 3 270 329 minecraft:honeycomb_block
setblock 3 270 333 minecraft:yellow_terracotta
fill 3 270 334 3 271 334 minecraft:honeycomb_block
setblock 3 270 354 minecraft:honeycomb_block
setblock 3 270 358 minecraft:yellow_terracotta
fill 3 270 359 3 271 359 minecraft:honeycomb_block
setblock 3 270 363 minecraft:yellow_terracotta
fill 4 270 323 4 271 323 minecraft:honeycomb_block
setblock 4 270 361 minecraft:honeycomb_block
setblock 4 270 362 minecraft:yellow_terracotta
fill 4 270 363 4 271 363 minecraft:honeycomb_block
setblock 5 270 324 minecraft:honey_block
setblock 5 270 361 minecraft:yellow_terracotta
fill 5 270 362 5 271 362 minecraft:honeycomb_block
fill 6 270 325 6 270 326 minecraft:honey_block
setblock 8 270 363 minecraft:yellow_terracotta
fill 9 270 363 12 270 363 minecraft:honeycomb_block
setblock 11 270 322 minecraft:yellow_terracotta
setblock 13 270 363 minecraft:yellow_terracotta
fill 14 270 363 14 271 363 minecraft:honeycomb_block
fill 17 270 362 18 270 362 minecraft:honeycomb_block
setblock 18 270 327 minecraft:honey_block
setblock 18 270 329 minecraft:honey_block
setblock 18 270 363 minecraft:yellow_terracotta
fill 18 270 364 18 300 364 minecraft:honeycomb_block
setblock 19 270 326 minecraft:honey_block
setblock 19 270 362 minecraft:yellow_terracotta
fill 19 270 363 19 271 363 minecraft:honeycomb_block
setblock 20 270 361 minecraft:yellow_terracotta
fill 20 270 362 20 271 362 minecraft:honeycomb_block
setblock 21 270 326 minecraft:honey_block
setblock 21 270 361 minecraft:honeycomb_block
setblock 23 270 363 minecraft:yellow_terracotta
fill 24 270 363 24 271 363 minecraft:honeycomb_block
setblock 26 270 323 minecraft:honey_block
fill 27 270 343 27 270 344 minecraft:honey_block
setblock 28 270 342 minecraft:honey_block
setblock 29 270 346 minecraft:honey_block
setblock 30 270 342 minecraft:honey_block
fill 33 270 346 33 270 348 minecraft:honey_block
setblock 34 270 345 minecraft:honey_block
fill 35 270 344 36 270 344 minecraft:honey_block
fill 35 270 350 36 270 350 minecraft:honey_block
setblock 35 270 363 minecraft:honey_block
fill 36 270 352 36 271 352 minecraft:yellow_terracotta
setblock 37 270 345 minecraft:honey_block
setblock 37 270 349 minecraft:honey_block
fill 37 270 351 37 271 351 minecraft:yellow_terracotta
fill 37 270 353 37 271 353 minecraft:yellow_terracotta
setblock 38 270 323 minecraft:yellow_terracotta
setblock 38 270 333 minecraft:yellow_terracotta
setblock 38 270 334 minecraft:honeycomb_block
fill 38 270 346 38 270 348 minecraft:honey_block
fill 38 270 352 38 271 352 minecraft:yellow_terracotta
fill 39 270 323 40 271 323 minecraft:honeycomb_block
setblock 39 270 332 minecraft:yellow_terracotta
fill 39 270 333 39 271 333 minecraft:honeycomb_block
setblock 39 270 337 minecraft:yellow_terracotta
fill 39 270 338 39 271 338 minecraft:honeycomb_block
setblock 40 270 325 minecraft:honeycomb_block
setblock 40 270 326 minecraft:yellow_terracotta
fill 40 270 327 40 271 327 minecraft:honeycomb_block
setblock 40 270 331 minecraft:yellow_terracotta
fill 40 270 332 40 271 332 minecraft:honeycomb_block
setblock 40 270 336 minecraft:yellow_terracotta
fill 40 270 337 40 271 337 minecraft:honeycomb_block
setblock 40 270 341 minecraft:yellow_terracotta
fill 40 270 342 40 271 342 minecraft:honeycomb_block
setblock 40 270 356 minecraft:yellow_terracotta
fill 40 270 357 40 271 357 minecraft:honeycomb_block
setblock 41 270 325 minecraft:yellow_terracotta
fill 41 270 326 41 271 326 minecraft:honeycomb_block
setblock 41 270 330 minecraft:yellow_terracotta
fill 41 270 331 41 271 331 minecraft:honeycomb_block
setblock 41 270 335 minecraft:yellow_terracotta
fill 41 270 336 41 271 336 minecraft:honeycomb_block
setblock 41 270 340 minecraft:yellow_terracotta
fill 41 270 341 41 271 341 minecraft:honeycomb_block
setblock 41 270 345 minecraft:yellow_terracotta
setblock 41 270 346 minecraft:honeycomb_block
setblock 41 270 350 minecraft:yellow_terracotta
fill 41 270 351 41 271 351 minecraft:honeycomb_block
setblock 41 270 355 minecraft:yellow_terracotta
fill 41 270 356 41 271 356 minecraft:honeycomb_block
setblock 41 270 360 minecraft:yellow_terracotta
fill 41 270 361 41 271 361 minecraft:honeycomb_block
setblock 42 270 324 minecraft:yellow_concrete
fill 42 270 345 42 294 345 minecraft:honeycomb_block
setblock 42 270 348 minecraft:orange_terracotta
setblock 1 271 324 minecraft:yellow_terracotta
setblock 1 271 325 minecraft:honeycomb_block
setblock 1 271 329 minecraft:yellow_terracotta
setblock 1 271 330 minecraft:honeycomb_block
setblock 1 271 334 minecraft:yellow_terracotta
setblock 1 271 335 minecraft:honeycomb_block
setblock 1 271 339 minecraft:yellow_terracotta
setblock 1 271 340 minecraft:honeycomb_block
setblock 1 271 350 minecraft:honeycomb_block
setblock 1 271 354 minecraft:yellow_terracotta
setblock 1 271 355 minecraft:honeycomb_block
setblock 1 271 359 minecraft:yellow_terracotta
setblock 1 271 360 minecraft:honeycomb_block
setblock 2 271 323 minecraft:yellow_terracotta
setblock 2 271 324 minecraft:honeycomb_block
setblock 2 271 328 minecraft:yellow_terracotta
setblock 2 271 329 minecraft:honeycomb_block
setblock 2 271 333 minecraft:yellow_terracotta
setblock 2 271 334 minecraft:honeycomb_block
setblock 2 271 338 minecraft:yellow_terracotta
setblock 2 271 339 minecraft:honeycomb_block
setblock 2 271 353 minecraft:yellow_terracotta
setblock 2 271 354 minecraft:honeycomb_block
setblock 2 271 358 minecraft:yellow_terracotta
setblock 2 271 359 minecraft:honeycomb_block
setblock 2 271 363 minecraft:yellow_terracotta
setblock 3 271 323 minecraft:honeycomb_block
setblock 3 271 325 minecraft:light[level=15]
setblock 3 271 333 minecraft:honeycomb_block
setblock 3 271 341 minecraft:light[level=15]
setblock 3 271 349 minecraft:light[level=15]
setblock 3 271 357 minecraft:yellow_terracotta
setblock 3 271 358 minecraft:honeycomb_block
setblock 3 271 362 minecraft:yellow_terracotta
setblock 3 271 363 minecraft:honeycomb_block
setblock 4 271 361 minecraft:yellow_terracotta
setblock 4 271 362 minecraft:honeycomb_block
setblock 7 271 363 minecraft:yellow_terracotta
fill 8 271 363 11 271 363 minecraft:honeycomb_block
fill 11 271 322 11 308 322 minecraft:honeycomb_block
setblock 11 271 325 minecraft:light[level=15]
setblock 11 271 333 minecraft:light[level=15]
setblock 11 271 341 minecraft:light[level=15]
setblock 11 271 349 minecraft:light[level=15]
setblock 11 271 357 minecraft:light[level=15]
setblock 13 271 363 minecraft:honeycomb_block
setblock 17 271 362 minecraft:honeycomb_block
setblock 17 271 363 minecraft:yellow_terracotta
setblock 18 271 362 minecraft:yellow_terracotta
setblock 18 271 363 minecraft:honeycomb_block
setblock 19 271 322 minecraft:orange_terracotta
setblock 19 271 325 minecraft:light[level=15]
setblock 19 271 333 minecraft:light[level=15]
setblock 19 271 341 minecraft:light[level=15]
setblock 19 271 349 minecraft:light[level=15]
setblock 19 271 357 minecraft:light[level=15]
setblock 19 271 362 minecraft:honeycomb_block
setblock 20 271 323 minecraft:honey_block
setblock 20 271 361 minecraft:honeycomb_block
setblock 22 271 363 minecraft:yellow_terracotta
setblock 23 271 362 minecraft:yellow_terracotta
setblock 23 271 363 minecraft:honeycomb_block
setblock 27 271 325 minecraft:light[level=15]
setblock 27 271 333 minecraft:light[level=15]
setblock 27 271 341 minecraft:light[level=15]
setblock 27 271 349 minecraft:light[level=15]
setblock 27 271 357 minecraft:light[level=15]
setblock 34 271 356 minecraft:flowering_azalea_leaves[persistent=true]
setblock 35 271 325 minecraft:light[level=15]
setblock 35 271 333 minecraft:light[level=15]
setblock 35 271 341 minecraft:light[level=15]
setblock 35 271 357 minecraft:light[level=15]
setblock 36 271 351 minecraft:yellow_terracotta
setblock 36 271 353 minecraft:yellow_terracotta
setblock 38 271 323 minecraft:honeycomb_block
setblock 38 271 351 minecraft:yellow_terracotta
setblock 38 271 353 minecraft:yellow_terracotta
setblock 39 271 331 minecraft:yellow_terracotta
setblock 39 271 332 minecraft:honeycomb_block
setblock 39 271 336 minecraft:yellow_terracotta
setblock 39 271 337 minecraft:honeycomb_block
setblock 39 271 363 minecraft:honeycomb_block
setblock 40 271 325 minecraft:yellow_terracotta
setblock 40 271 326 minecraft:honeycomb_block
setblock 40 271 330 minecraft:yellow_terracotta
setblock 40 271 331 minecraft:honeycomb_block
setblock 40 271 335 minecraft:yellow_terracotta
setblock 40 271 336 minecraft:honeycomb_block
setblock 40 271 340 minecraft:yellow_terracotta
setblock 40 271 341 minecraft:honeycomb_block
setblock 40 271 355 minecraft:yellow_terracotta
setblock 40 271 356 minecraft:honeycomb_block
setblock 40 271 360 minecraft:yellow_terracotta
setblock 41 271 324 minecraft:yellow_terracotta
setblock 41 271 325 minecraft:honeycomb_block
setblock 41 271 329 minecraft:yellow_terracotta
setblock 41 271 330 minecraft:honeycomb_block
setblock 41 271 334 minecraft:yellow_terracotta
setblock 41 271 335 minecraft:honeycomb_block
setblock 41 271 339 minecraft:yellow_terracotta
setblock 41 271 340 minecraft:honeycomb_block
setblock 41 271 344 minecraft:yellow_terracotta
setblock 41 271 346 minecraft:honey_block
setblock 41 271 350 minecraft:honeycomb_block
setblock 41 271 354 minecraft:yellow_terracotta
setblock 41 271 355 minecraft:honeycomb_block
setblock 41 271 359 minecraft:yellow_terracotta
setblock 41 271 360 minecraft:honeycomb_block
setblock 42 271 324 minecraft:honeycomb_block
setblock 42 271 332 minecraft:yellow_terracotta
setblock 42 271 344 minecraft:orange_terracotta
fill 42 271 348 42 308 348 minecraft:honeycomb_block
setblock 42 271 349 minecraft:orange_terracotta
setblock 12 272 322 minecraft:yellow_terracotta
fill 19 272 322 19 283 322 minecraft:honeycomb_block
setblock 42 272 324 minecraft:orange_terracotta
setblock 42 272 330 minecraft:orange_terracotta
fill 42 272 332 42 308 332 minecraft:honeycomb_block
fill 42 272 344 42 289 344 minecraft:honeycomb_block
fill 42 272 349 42 308 349 minecraft:honeycomb_block
setblock 0 273 343 minecraft:orange_terracotta
setblock 3 273 325 minecraft:light[level=12]
setblock 3 273 332 minecraft:light[level=12]
setblock 3 273 339 minecraft:light[level=12]
setblock 3 273 346 minecraft:light[level=12]
setblock 3 273 353 minecraft:light[level=12]
setblock 3 273 360 minecraft:light[level=12]
setblock 4 273 322 minecraft:yellow_concrete
setblock 10 273 325 minecraft:light[level=12]
setblock 10 273 332 minecraft:light[level=12]
setblock 10 273 339 minecraft:light[level=12]
setblock 10 273 346 minecraft:light[level=12]
setblock 10 273 353 minecraft:light[level=12]
setblock 10 273 360 minecraft:light[level=12]
fill 12 273 322 12 308 322 minecraft:honeycomb_block
setblock 17 273 325 minecraft:light[level=12]
setblock 17 273 332 minecraft:light[level=12]
setblock 17 273 339 minecraft:light[level=12]
setblock 17 273 346 minecraft:light[level=12]
setblock 17 273 353 minecraft:light[level=12]
setblock 17 273 360 minecraft:light[level=12]
setblock 19 273 364 minecraft:orange_terracotta
setblock 24 273 325 minecraft:light[level=12]
setblock 24 273 332 minecraft:light[level=12]
setblock 24 273 339 minecraft:light[level=12]
setblock 24 273 346 minecraft:light[level=12]
setblock 24 273 353 minecraft:light[level=12]
setblock 24 273 360 minecraft:light[level=12]
setblock 31 273 325 minecraft:light[level=12]
setblock 31 273 332 minecraft:light[level=12]
setblock 31 273 339 minecraft:light[level=12]
setblock 31 273 346 minecraft:light[level=12]
setblock 31 273 353 minecraft:light[level=12]
setblock 31 273 360 minecraft:light[level=12]
setblock 38 273 325 minecraft:light[level=12]
setblock 38 273 332 minecraft:light[level=12]
setblock 38 273 339 minecraft:light[level=12]
setblock 38 273 346 minecraft:light[level=12]
setblock 38 273 353 minecraft:light[level=12]
setblock 38 273 360 minecraft:light[level=12]
fill 42 273 324 42 308 324 minecraft:honeycomb_block
fill 42 273 330 42 308 330 minecraft:honeycomb_block
setblock 42 273 360 minecraft:yellow_terracotta
fill 0 274 343 0 308 343 minecraft:honeycomb_block
setblock 0 274 353 minecraft:yellow_concrete
setblock 0 274 362 minecraft:yellow_concrete
fill 4 274 322 4 308 322 minecraft:honeycomb_block
fill 19 274 364 19 308 364 minecraft:honeycomb_block
setblock 36 274 322 minecraft:yellow_terracotta
fill 37 274 322 37 308 322 minecraft:honeycomb_block
fill 42 274 360 42 308 360 minecraft:honeycomb_block
setblock 0 275 338 minecraft:yellow_terracotta
fill 0 275 353 0 308 353 minecraft:honeycomb_block
fill 0 275 362 0 289 362 minecraft:honeycomb_block
setblock 28 275 364 minecraft:yellow_concrete
fill 36 275 322 36 308 322 minecraft:honeycomb_block
fill 0 276 338 0 308 338 minecraft:honeycomb_block
setblock 6 276 322 minecraft:orange_terracotta
setblock 25 276 364 minecraft:yellow_terracotta
fill 28 276 364 28 308 364 minecraft:honeycomb_block
setblock 42 276 337 minecraft:yellow_terracotta
setblock 0 277 359 minecraft:yellow_concrete
fill 1 277 323 17 278 363 minecraft:honeycomb_block
fill 6 277 322 6 296 322 minecraft:honeycomb_block
fill 18 277 323 18 278 344 minecraft:honeycomb_block
fill 18 277 346 18 278 363 minecraft:honeycomb_block
fill 19 277 323 20 278 342 minecraft:honeycomb_block
fill 19 277 348 20 278 363 minecraft:honeycomb_block
fill 21 277 323 41 278 341 minecraft:honeycomb_block
fill 21 277 349 41 278 363 minecraft:honeycomb_block
fill 22 277 342 41 278 342 minecraft:honeycomb_block
fill 22 277 348 41 278 348 minecraft:honeycomb_block
fill 24 277 343 41 278 344 minecraft:honeycomb_block
fill 24 277 346 41 278 347 minecraft:honeycomb_block
fill 25 277 345 41 278 345 minecraft:honeycomb_block
fill 25 277 364 25 308 364 minecraft:honeycomb_block
setblock 40 277 364 minecraft:yellow_terracotta
fill 42 277 337 42 308 337 minecraft:honeycomb_block
fill 0 278 359 0 282 359 minecraft:honeycomb_block
fill 40 278 364 40 295 364 minecraft:honeycomb_block
setblock 42 278 352 minecraft:orange_terracotta
setblock 42 278 359 minecraft:orange_terracotta
fill 1 279 322 1 279 324 minecraft:orange_terracotta
fill 1 279 325 41 279 326 minecraft:honeycomb_block
fill 1 279 327 1 279 329 minecraft:orange_terracotta
fill 1 279 330 41 279 331 minecraft:honeycomb_block
fill 1 279 332 1 279 334 minecraft:orange_terracotta
fill 1 279 335 41 279 336 minecraft:honeycomb_block
fill 1 279 337 1 279 339 minecraft:orange_terracotta
fill 1 279 340 17 279 342 minecraft:honeycomb_block
fill 1 279 343 1 279 345 minecraft:orange_terracotta
fill 1 279 346 16 279 347 minecraft:honeycomb_block
fill 1 279 348 1 279 350 minecraft:orange_terracotta
fill 1 279 351 41 279 352 minecraft:honeycomb_block
fill 1 279 353 1 279 355 minecraft:orange_terracotta
fill 1 279 356 41 279 357 minecraft:honeycomb_block
fill 1 279 358 1 279 360 minecraft:orange_terracotta
fill 1 279 361 41 279 362 minecraft:honeycomb_block
fill 1 279 363 41 279 363 minecraft:orange_terracotta
fill 2 279 323 3 279 323 minecraft:honeycomb_block
fill 2 279 324 41 279 324 minecraft:orange_terracotta
fill 2 279 327 3 279 329 minecraft:honeycomb_block
fill 2 279 332 41 279 332 minecraft:orange_terracotta
fill 2 279 333 3 279 334 minecraft:honeycomb_block
fill 2 279 337 41 279 337 minecraft:orange_terracotta
fill 2 279 338 3 279 339 minecraft:honeycomb_block
fill 2 279 343 3 279 344 minecraft:honeycomb_block
fill 2 279 345 16 279 345 minecraft:orange_terracotta
fill 2 279 348 3 279 349 minecraft:honeycomb_block
fill 2 279 350 41 279 350 minecraft:orange_terracotta
fill 2 279 353 3 279 355 minecraft:honeycomb_block
fill 2 279 358 41 279 358 minecraft:orange_terracotta
fill 2 279 359 3 279 360 minecraft:honeycomb_block
setblock 4 279 323 minecraft:orange_terracotta
fill 4 279 327 4 279 329 minecraft:orange_terracotta
fill 4 279 333 4 279 334 minecraft:orange_terracotta
fill 4 279 338 4 279 339 minecraft:orange_terracotta
fill 4 279 343 4 279 344 minecraft:orange_terracotta
fill 4 279 348 4 279 349 minecraft:orange_terracotta
fill 4 279 353 4 279 355 minecraft:orange_terracotta
fill 4 279 359 4 279 360 minecraft:orange_terracotta
fill 5 279 323 6 279 323 minecraft:honeycomb_block
fill 5 279 327 6 279 329 minecraft:honeycomb_block
fill 5 279 333 6 279 334 minecraft:honeycomb_block
fill 5 279 338 6 279 339 minecraft:honeycomb_block
fill 5 279 343 6 279 344 minecraft:honeycomb_block
fill 5 279 348 6 279 349 minecraft:honeycomb_block
fill 5 279 353 6 279 355 minecraft:honeycomb_block
fill 5 279 359 6 279 360 minecraft:honeycomb_block
setblock 7 279 323 minecraft:orange_terracotta
fill 7 279 327 7 279 329 minecraft:orange_terracotta
fill 7 279 333 7 279 334 minecraft:orange_terracotta
fill 7 279 338 7 279 339 minecraft:orange_terracotta
fill 7 279 343 7 279 344 minecraft:orange_terracotta
fill 7 279 348 7 279 349 minecraft:orange_terracotta
fill 7 279 353 7 279 355 minecraft:orange_terracotta
fill 7 279 359 7 279 360 minecraft:orange_terracotta
fill 8 279 323 9 279 323 minecraft:honeycomb_block
fill 8 279 327 9 279 329 minecraft:honeycomb_block
fill 8 279 333 9 279 334 minecraft:honeycomb_block
fill 8 279 338 9 279 339 minecraft:honeycomb_block
fill 8 279 343 9 279 344 minecraft:honeycomb_block
fill 8 279 348 9 279 349 minecraft:honeycomb_block
fill 8 279 353 9 279 355 minecraft:honeycomb_block
fill 8 279 359 9 279 360 minecraft:honeycomb_block
setblock 10 279 323 minecraft:orange_terracotta
fill 10 279 327 10 279 329 minecraft:orange_terracotta
fill 10 279 333 10 279 334 minecraft:orange_terracotta
fill 10 279 338 10 279 339 minecraft:orange_terracotta
fill 10 279 343 10 279 344 minecraft:orange_terracotta
fill 10 279 348 10 279 349 minecraft:orange_terracotta
fill 10 279 353 10 279 355 minecraft:orange_terracotta
fill 10 279 359 10 279 360 minecraft:orange_terracotta
fill 11 279 323 12 279 323 minecraft:honeycomb_block
fill 11 279 327 12 279 329 minecraft:honeycomb_block
fill 11 279 333 12 279 334 minecraft:honeycomb_block
fill 11 279 338 12 279 339 minecraft:honeycomb_block
fill 11 279 343 12 279 344 minecraft:honeycomb_block
fill 11 279 348 12 279 349 minecraft:honeycomb_block
fill 11 279 353 12 279 355 minecraft:honeycomb_block
fill 11 279 359 12 279 360 minecraft:honeycomb_block
setblock 13 279 323 minecraft:orange_terracotta
fill 13 279 327 13 279 329 minecraft:orange_terracotta
fill 13 279 333 13 279 334 minecraft:orange_terracotta
fill 13 279 338 13 279 339 minecraft:orange_terracotta
fill 13 279 343 13 279 344 minecraft:orange_terracotta
fill 13 279 348 13 279 349 minecraft:orange_terracotta
fill 13 279 353 13 279 355 minecraft:orange_terracotta
fill 13 279 359 13 279 360 minecraft:orange_terracotta
fill 14 279 323 15 279 323 minecraft:honeycomb_block
fill 14 279 327 15 279 329 minecraft:honeycomb_block
fill 14 279 333 15 279 334 minecraft:honeycomb_block
fill 14 279 338 15 279 339 minecraft:honeycomb_block
fill 14 279 343 15 279 344 minecraft:honeycomb_block
fill 14 279 348 15 279 349 minecraft:honeycomb_block
fill 14 279 353 15 279 355 minecraft:honeycomb_block
fill 14 279 359 15 279 360 minecraft:honeycomb_block
setblock 16 279 323 minecraft:orange_terracotta
fill 16 279 327 16 279 329 minecraft:orange_terracotta
fill 16 279 333 16 279 334 minecraft:orange_terracotta
fill 16 279 338 16 279 339 minecraft:orange_terracotta
fill 16 279 343 16 279 344 minecraft:orange_terracotta
fill 16 279 348 16 279 349 minecraft:orange_terracotta
fill 16 279 353 16 279 355 minecraft:orange_terracotta
fill 16 279 359 16 279 360 minecraft:orange_terracotta
fill 17 279 323 18 279 323 minecraft:honeycomb_block
fill 17 279 327 18 279 329 minecraft:honeycomb_block
fill 17 279 333 18 279 334 minecraft:honeycomb_block
fill 17 279 338 18 279 339 minecraft:honeycomb_block
setblock 17 279 343 minecraft:honeycomb_block
fill 17 279 344 17 279 346 minecraft:ochre_froglight
fill 17 279 347 17 279 349 minecraft:honeycomb_block
fill 17 279 353 18 279 355 minecraft:honeycomb_block
fill 17 279 359 18 279 360 minecraft:honeycomb_block
fill 18 279 340 19 279 341 minecraft:honeycomb_block
fill 18 279 342 18 279 344 minecraft:ochre_froglight
fill 18 279 346 18 279 348 minecraft:ochre_froglight
setblock 18 279 349 minecraft:honeycomb_block
setblock 19 279 323 minecraft:orange_terracotta
fill 19 279 327 19 279 329 minecraft:orange_terracotta
fill 19 279 333 19 279 334 minecraft:orange_terracotta
fill 19 279 338 19 279 339 minecraft:orange_terracotta
fill 19 279 342 20 279 342 minecraft:ochre_froglight
fill 19 279 348 20 279 348 minecraft:ochre_froglight
setblock 19 279 349 minecraft:orange_terracotta
fill 19 279 353 19 279 355 minecraft:orange_terracotta
fill 19 279 359 19 279 360 minecraft:orange_terracotta
fill 20 279 323 21 279 323 minecraft:honeycomb_block
fill 20 279 327 21 279 329 minecraft:honeycomb_block
fill 20 279 333 21 279 334 minecraft:honeycomb_block
fill 20 279 338 21 279 340 minecraft:honeycomb_block
fill 20 279 341 22 279 341 minecraft:ochre_froglight
fill 20 279 349 22 279 349 minecraft:ochre_froglight
fill 20 279 353 21 279 355 minecraft:honeycomb_block
fill 20 279 359 21 279 360 minecraft:honeycomb_block
setblock 22 279 323 minecraft:orange_terracotta
fill 22 279 327 22 279 329 minecraft:orange_terracotta
fill 22 279 333 22 279 334 minecraft:orange_terracotta
fill 22 279 338 22 279 339 minecraft:orange_terracotta
fill 22 279 340 41 279 340 minecraft:honeycomb_block
fill 22 279 342 24 279 342 minecraft:ochre_froglight
fill 22 279 348 24 279 348 minecraft:ochre_froglight
fill 22 279 353 22 279 355 minecraft:orange_terracotta
fill 22 279 359 22 279 360 minecraft:orange_terracotta
setblock 23 279 322 minecraft:orange_terracotta
fill 23 279 323 24 279 323 minecraft:honeycomb_block
fill 23 279 327 24 279 329 minecraft:honeycomb_block
fill 23 279 333 24 279 334 minecraft:honeycomb_block
fill 23 279 338 24 279 339 minecraft:honeycomb_block
fill 23 279 341 41 279 341 minecraft:honeycomb_block
fill 23 279 349 24 279 349 minecraft:honeycomb_block
fill 23 279 353 24 279 355 minecraft:honeycomb_block
fill 23 279 359 24 279 360 minecraft:honeycomb_block
fill 24 279 343 24 279 344 minecraft:ochre_froglight
fill 24 279 346 24 279 347 minecraft:ochre_froglight
setblock 25 279 323 minecraft:orange_terracotta
fill 25 279 327 25 279 329 minecraft:orange_terracotta
fill 25 279 333 25 279 334 minecraft:orange_terracotta
fill 25 279 338 25 279 339 minecraft:orange_terracotta
fill 25 279 342 41 279 342 minecraft:honeycomb_block
setblock 25 279 343 minecraft:orange_terracotta
fill 25 279 344 25 279 346 minecraft:ochre_froglight
fill 25 279 347 41 279 347 minecraft:honeycomb_block
fill 25 279 348 25 279 349 minecraft:orange_terracotta
fill 25 279 353 25 279 355 minecraft:orange_terracotta
fill 25 279 359 25 279 360 minecraft:orange_terracotta
fill 26 279 323 27 279 323 minecraft:honeycomb_block
fill 26 279 327 27 279 329 minecraft:honeycomb_block
fill 26 279 333 27 279 334 minecraft:honeycomb_block
fill 26 279 338 27 279 339 minecraft:honeycomb_block
fill 26 279 343 27 279 344 minecraft:honeycomb_block
fill 26 279 345 41 279 345 minecraft:orange_terracotta
fill 26 279 346 41 279 346 minecraft:honeycomb_block
fill 26 279 348 27 279 349 minecraft:honeycomb_block
fill 26 279 353 27 279 355 minecraft:honeycomb_block
fill 26 279 359 27 279 360 minecraft:honeycomb_block
setblock 28 279 323 minecraft:orange_terracotta
fill 28 279 327 28 279 329 minecraft:orange_terracotta
fill 28 279 333 28 279 334 minecraft:orange_terracotta
fill 28 279 338 28 279 339 minecraft:orange_terracotta
fill 28 279 343 28 279 344 minecraft:orange_terracotta
fill 28 279 348 28 279 349 minecraft:orange_terracotta
fill 28 279 353 28 279 355 minecraft:orange_terracotta
fill 28 279 359 28 279 360 minecraft:orange_terracotta
fill 29 279 323 30 279 323 minecraft:honeycomb_block
fill 29 279 327 30 279 329 minecraft:honeycomb_block
fill 29 279 333 30 279 334 minecraft:honeycomb_block
fill 29 279 338 30 279 339 minecraft:honeycomb_block
fill 29 279 343 30 279 344 minecraft:honeycomb_block
fill 29 279 348 30 279 349 minecraft:honeycomb_block
fill 29 279 353 30 279 355 minecraft:honeycomb_block
fill 29 279 359 30 279 360 minecraft:honeycomb_block
setblock 31 279 323 minecraft:orange_terracotta
fill 31 279 327 31 279 329 minecraft:orange_terracotta
fill 31 279 333 31 279 334 minecraft:orange_terracotta
fill 31 279 338 31 279 339 minecraft:orange_terracotta
fill 31 279 343 31 279 344 minecraft:orange_terracotta
fill 31 279 348 31 279 349 minecraft:orange_terracotta
fill 31 279 353 31 279 355 minecraft:orange_terracotta
fill 31 279 359 31 279 360 minecraft:orange_terracotta
fill 32 279 323 33 279 323 minecraft:honeycomb_block
fill 32 279 327 33 279 329 minecraft:honeycomb_block
fill 32 279 333 33 279 334 minecraft:honeycomb_block
fill 32 279 338 33 279 339 minecraft:honeycomb_block
fill 32 279 343 33 279 344 minecraft:honeycomb_block
fill 32 279 348 33 279 349 minecraft:honeycomb_block
fill 32 279 353 33 279 355 minecraft:honeycomb_block
fill 32 279 359 33 279 360 minecraft:honeycomb_block
setblock 34 279 323 minecraft:orange_terracotta
fill 34 279 327 34 279 329 minecraft:orange_terracotta
fill 34 279 333 34 279 334 minecraft:orange_terracotta
fill 34 279 338 34 279 339 minecraft:orange_terracotta
fill 34 279 343 34 279 344 minecraft:orange_terracotta
fill 34 279 348 34 279 349 minecraft:orange_terracotta
fill 34 279 353 34 279 355 minecraft:orange_terracotta
fill 34 279 359 34 279 360 minecraft:orange_terracotta
fill 35 279 323 36 279 323 minecraft:honeycomb_block
fill 35 279 327 36 279 329 minecraft:honeycomb_block
fill 35 279 333 36 279 334 minecraft:honeycomb_block
fill 35 279 338 36 279 339 minecraft:honeycomb_block
fill 35 279 343 36 279 344 minecraft:honeycomb_block
fill 35 279 348 36 279 349 minecraft:honeycomb_block
fill 35 279 353 36 279 355 minecraft:honeycomb_block
fill 35 279 359 36 279 360 minecraft:honeycomb_block
setblock 37 279 323 minecraft:orange_terracotta
fill 37 279 327 37 279 329 minecraft:orange_terracotta
fill 37 279 333 37 279 334 minecraft:orange_terracotta
fill 37 279 338 37 279 339 minecraft:orange_terracotta
fill 37 279 343 37 279 344 minecraft:orange_terracotta
fill 37 279 348 37 279 349 minecraft:orange_terracotta
fill 37 279 353 37 279 355 minecraft:orange_terracotta
fill 37 279 359 37 279 360 minecraft:orange_terracotta
fill 38 279 323 39 279 323 minecraft:honeycomb_block
fill 38 279 327 39 279 329 minecraft:honeycomb_block
fill 38 279 333 39 279 334 minecraft:honeycomb_block
fill 38 279 338 39 279 339 minecraft:honeycomb_block
fill 38 279 343 39 279 344 minecraft:honeycomb_block
fill 38 279 348 39 279 349 minecraft:honeycomb_block
fill 38 279 353 39 279 355 minecraft:honeycomb_block
fill 38 279 359 39 279 360 minecraft:honeycomb_block
setblock 40 279 323 minecraft:orange_terracotta
fill 40 279 327 40 279 329 minecraft:orange_terracotta
fill 40 279 333 40 279 334 minecraft:orange_terracotta
fill 40 279 338 40 279 339 minecraft:orange_terracotta
fill 40 279 343 40 279 344 minecraft:orange_terracotta
fill 40 279 348 40 279 349 minecraft:orange_terracotta
fill 40 279 353 40 279 355 minecraft:orange_terracotta
fill 40 279 359 40 279 360 minecraft:orange_terracotta
setblock 41 279 323 minecraft:honeycomb_block
fill 41 279 327 41 279 329 minecraft:honeycomb_block
fill 41 279 333 41 279 334 minecraft:honeycomb_block
fill 41 279 338 41 279 339 minecraft:honeycomb_block
fill 41 279 343 41 279 344 minecraft:honeycomb_block
fill 41 279 348 41 279 349 minecraft:honeycomb_block
fill 41 279 353 41 279 355 minecraft:honeycomb_block
fill 41 279 359 41 279 360 minecraft:honeycomb_block
fill 42 279 352 42 308 352 minecraft:honeycomb_block
fill 42 279 359 42 308 359 minecraft:honeycomb_block
setblock 0 280 348 minecraft:orange_terracotta
fill 1 280 322 1 308 322 minecraft:honeycomb_block
setblock 4 280 364 minecraft:yellow_terracotta
setblock 22 280 364 minecraft:yellow_concrete
fill 23 280 322 23 308 322 minecraft:honeycomb_block
setblock 0 281 328 minecraft:orange_terracotta
fill 0 281 348 0 308 348 minecraft:honeycomb_block
fill 4 281 364 4 308 364 minecraft:honeycomb_block
fill 22 281 364 22 294 364 minecraft:honeycomb_block
fill 0 282 328 0 308 328 minecraft:honeycomb_block
setblock 0 282 361 minecraft:orange_terracotta
setblock 0 283 359 minecraft:yellow_concrete
fill 0 283 361 1 283 361 minecraft:honeycomb_block
fill 1 283 323 1 283 326 minecraft:honeycomb_block
setblock 1 283 327 minecraft:yellow_terracotta
setblock 1 283 341 minecraft:honeycomb_block
setblock 1 283 342 minecraft:yellow_terracotta
fill 1 283 343 1 283 346 minecraft:honeycomb_block
setblock 1 283 347 minecraft:yellow_terracotta
fill 1 283 348 1 283 351 minecraft:honeycomb_block
setblock 1 283 352 minecraft:yellow_terracotta
fill 1 283 355 1 283 356 minecraft:honeycomb_block
setblock 1 283 357 minecraft:yellow_terracotta
fill 1 283 358 1 284 360 minecraft:honeycomb_block
setblock 1 283 362 minecraft:yellow_terracotta
fill 1 283 363 4 283 363 minecraft:honeycomb_block
fill 2 283 323 2 283 324 minecraft:honeycomb_block
fill 2 283 340 4 283 342 minecraft:brown_terracotta
setblock 2 283 360 minecraft:honeycomb_block
setblock 2 283 361 minecraft:yellow_terracotta
fill 2 283 362 5 283 362 minecraft:honeycomb_block
fill 3 283 323 4 283 323 minecraft:honeycomb_block
setblock 5 283 323 minecraft:yellow_terracotta
fill 5 283 343 9 287 343 minecraft:brown_terracotta
setblock 5 283 363 minecraft:yellow_terracotta
fill 6 283 323 9 283 323 minecraft:honeycomb_block
fill 6 283 342 8 287 342 minecraft:brown_terracotta
fill 6 283 344 8 287 344 minecraft:brown_terracotta
setblock 6 283 362 minecraft:yellow_terracotta
fill 6 283 363 9 283 363 minecraft:honeycomb_block
fill 7 283 341 7 287 341 minecraft:brown_terracotta
fill 7 283 345 7 287 345 minecraft:brown_terracotta
fill 7 283 362 10 283 362 minecraft:honeycomb_block
setblock 8 283 322 minecraft:yellow_terracotta
setblock 10 283 323 minecraft:yellow_terracotta
fill 10 283 324 13 283 324 minecraft:honeycomb_block
setblock 10 283 363 minecraft:yellow_terracotta
fill 11 283 323 14 283 323 minecraft:honeycomb_block
setblock 11 283 361 minecraft:honeycomb_block
setblock 11 283 362 minecraft:yellow_terracotta
fill 11 283 363 14 283 363 minecraft:honeycomb_block
setblock 12 283 361 minecraft:yellow_terracotta
fill 12 283 362 15 283 362 minecraft:honeycomb_block
fill 13 283 361 15 283 361 minecraft:honeycomb_block
setblock 14 283 324 minecraft:yellow_terracotta
setblock 15 283 323 minecraft:yellow_terracotta
fill 15 283 324 18 283 324 minecraft:honeycomb_block
setblock 15 283 363 minecraft:yellow_terracotta
fill 16 283 323 19 283 323 minecraft:honeycomb_block
setblock 16 283 362 minecraft:yellow_terracotta
fill 16 283 363 19 283 363 minecraft:honeycomb_block
fill 17 283 362 19 283 362 minecraft:honeycomb_block
setblock 19 283 324 minecraft:yellow_terracotta
setblock 20 283 323 minecraft:yellow_terracotta
setblock 20 283 363 minecraft:yellow_terracotta
fill 21 283 323 24 283 323 minecraft:honeycomb_block
fill 21 283 363 22 283 363 minecraft:honeycomb_block
setblock 25 283 323 minecraft:yellow_terracotta
fill 26 283 323 29 283 323 minecraft:honeycomb_block
fill 27 283 324 28 283 324 minecraft:honeycomb_block
fill 28 283 363 29 283 363 minecraft:honeycomb_block
setblock 29 283 324 minecraft:yellow_terracotta
setblock 30 283 323 minecraft:yellow_terracotta
fill 30 283 324 32 283 325 minecraft:honeycomb_block
setblock 30 283 363 minecraft:yellow_terracotta
fill 31 283 323 34 283 323 minecraft:honeycomb_block
setblock 31 283 362 minecraft:yellow_terracotta
fill 31 283 363 34 283 363 minecraft:honeycomb_block
fill 32 283 362 35 283 362 minecraft:honeycomb_block
setblock 33 283 324 minecraft:honeycomb_block
setblock 33 283 325 minecraft:yellow_terracotta
fill 33 283 326 36 283 326 minecraft:honeycomb_block
setblock 34 283 324 minecraft:yellow_terracotta
fill 34 283 325 37 283 325 minecraft:honeycomb_block
fill 34 283 356 34 284 356 minecraft:flowering_azalea_leaves[persistent=true]
setblock 35 283 323 minecraft:yellow_terracotta
fill 35 283 324 38 283 324 minecraft:honeycomb_block
fill 35 283 342 35 288 342 minecraft:flowering_azalea_leaves[persistent=true]
setblock 35 283 363 minecraft:yellow_terracotta
fill 36 283 323 39 283 323 minecraft:honeycomb_block
fill 36 283 360 36 289 360 minecraft:flowering_azalea_leaves[persistent=true]
setblock 36 283 361 minecraft:honeycomb_block
setblock 36 283 362 minecraft:yellow_terracotta
fill 36 283 363 39 283 363 minecraft:honeycomb_block
setblock 37 283 326 minecraft:yellow_terracotta
setblock 37 283 361 minecraft:yellow_terracotta
fill 37 283 362 40 283 362 minecraft:honeycomb_block
setblock 38 283 325 minecraft:yellow_terracotta
fill 38 283 326 41 283 326 minecraft:honeycomb_block
setblock 39 283 324 minecraft:yellow_terracotta
fill 39 283 325 41 284 325 minecraft:honeycomb_block
fill 39 283 327 39 283 328 minecraft:honeycomb_block
setblock 40 283 323 minecraft:yellow_terracotta
fill 40 283 324 41 285 324 minecraft:honeycomb_block
setblock 40 283 327 minecraft:honeycomb_block
setblock 40 283 328 minecraft:yellow_terracotta
fill 40 283 329 41 284 329 minecraft:honeycomb_block
setblock 40 283 342 minecraft:honeycomb_block
setblock 40 283 343 minecraft:yellow_terracotta
fill 40 283 344 41 283 344 minecraft:honeycomb_block
fill 40 283 360 41 283 361 minecraft:honeycomb_block
setblock 40 283 363 minecraft:yellow_terracotta
fill 41 283 323 41 286 323 minecraft:honeycomb_block
setblock 41 283 327 minecraft:yellow_terracotta
fill 41 283 328 41 286 328 minecraft:honeycomb_block
fill 41 283 330 41 283 331 minecraft:honeycomb_block
setblock 41 283 337 minecraft:honey_block
fill 41 283 339 41 283 341 minecraft:honeycomb_block
setblock 41 283 342 minecraft:yellow_terracotta
fill 41 283 343 41 284 343 minecraft:honeycomb_block
fill 41 283 345 41 283 346 minecraft:honeycomb_block
setblock 41 283 347 minecraft:yellow_terracotta
fill 41 283 358 41 283 359 minecraft:honeycomb_block
setblock 41 283 362 minecraft:yellow_terracotta
fill 41 283 363 41 286 363 minecraft:honeycomb_block
setblock 42 283 323 minecraft:orange_terracotta
setblock 0 284 346 minecraft:orange_terracotta
fill 0 284 359 0 308 359 minecraft:honeycomb_block
fill 0 284 361 0 304 361 minecraft:honeycomb_block
fill 1 284 323 1 284 325 minecraft:honeycomb_block
setblock 1 284 326 minecraft:yellow_terracotta
setblock 1 284 327 minecraft:honeycomb_block
setblock 1 284 330 minecraft:honey_block
fill 1 284 342 1 284 345 minecraft:honeycomb_block
setblock 1 284 346 minecraft:yellow_terracotta
fill 1 284 347 1 284 350 minecraft:honeycomb_block
setblock 1 284 351 minecraft:yellow_terracotta
setblock 1 284 355 minecraft:honey_block
setblock 1 284 357 minecraft:honeycomb_block
setblock 1 284 361 minecraft:yellow_terracotta
fill 1 284 362 3 284 363 minecraft:honeycomb_block
fill 2 284 323 3 284 323 minecraft:honeycomb_block
setblock 2 284 361 minecraft:honeycomb_block
setblock 4 284 323 minecraft:yellow_terracotta
setblock 4 284 362 minecraft:honeycomb_block
setblock 4 284 363 minecraft:yellow_terracotta
fill 5 284 323 8 284 323 minecraft:honeycomb_block
fill 5 284 342 5 287 342 minecraft:brown_terracotta
fill 5 284 344 5 287 344 minecraft:brown_terracotta
fill 5 284 363 8 284 363 minecraft:honeycomb_block
fill 6 284 341 6 287 341 minecraft:brown_terracotta
fill 6 284 345 6 287 345 minecraft:brown_terracotta
fill 6 284 362 9 284 362 minecraft:honeycomb_block
fill 8 284 322 8 308 322 minecraft:honeycomb_block
fill 8 284 341 8 287 341 minecraft:brown_terracotta
fill 8 284 345 8 287 345 minecraft:brown_terracotta
setblock 9 284 323 minecraft:yellow_terracotta
fill 9 284 342 9 287 342 minecraft:brown_terracotta
fill 9 284 344 9 287 344 minecraft:brown_terracotta
setblock 9 284 363 minecraft:yellow_terracotta
fill 10 284 323 12 284 324 minecraft:honeycomb_block
setblock 10 284 362 minecraft:yellow_terracotta
fill 10 284 363 13 284 363 minecraft:honeycomb_block
fill 11 284 362 14 284 362 minecraft:honeycomb_block
setblock 13 284 323 minecraft:honeycomb_block
setblock 13 284 324 minecraft:yellow_terracotta
setblock 14 284 323 minecraft:yellow_terracotta
fill 14 284 324 17 284 324 minecraft:honeycomb_block
setblock 14 284 363 minecraft:yellow_terracotta
fill 15 284 323 18 284 323 minecraft:honeycomb_block
setblock 15 284 362 minecraft:yellow_terracotta
fill 15 284 363 18 284 363 minecraft:honeycomb_block
fill 16 284 362 17 284 362 minecraft:honeycomb_block
setblock 18 284 324 minecraft:yellow_terracotta
setblock 19 284 322 minecraft:yellow_concrete
setblock 19 284 323 minecraft:yellow_terracotta
setblock 19 284 324 minecraft:honeycomb_block
setblock 19 284 363 minecraft:yellow_terracotta
fill 20 284 323 23 284 323 minecraft:honeycomb_block
setblock 20 284 363 minecraft:honeycomb_block
setblock 24 284 323 minecraft:yellow_terracotta
fill 25 284 323 28 284 323 minecraft:honeycomb_block
setblock 27 284 324 minecraft:honeycomb_block
setblock 28 284 324 minecraft:yellow_terracotta
fill 28 284 359 31 300 359 minecraft:yellow_terracotta
setblock 28 284 363 minecraft:honeycomb_block
setblock 29 284 323 minecraft:yellow_terracotta
fill 29 284 324 31 284 325 minecraft:honeycomb_block
fill 29 284 358 31 300 358 minecraft:yellow_terracotta
fill 29 284 360 31 300 360 minecraft:yellow_terracotta
setblock 29 284 363 minecraft:yellow_terracotta
fill 30 284 323 33 284 323 minecraft:honeycomb_block
fill 30 284 363 33 284 363 minecraft:honeycomb_block
setblock 32 284 324 minecraft:honeycomb_block
setblock 32 284 325 minecraft:yellow_terracotta
fill 32 284 326 35 284 326 minecraft:honeycomb_block
fill 32 284 362 34 284 362 minecraft:honeycomb_block
setblock 33 284 324 minecraft:yellow_terracotta
fill 33 284 325 36 284 325 minecraft:honeycomb_block
setblock 34 284 323 minecraft:yellow_terracotta
fill 34 284 324 37 284 324 minecraft:honeycomb_block
setblock 34 284 363 minecraft:yellow_terracotta
fill 35 284 323 38 284 323 minecraft:honeycomb_block
setblock 35 284 362 minecraft:yellow_terracotta
fill 35 284 363 38 284 363 minecraft:honeycomb_block
setblock 36 284 326 minecraft:yellow_terracotta
fill 36 284 362 39 284 362 minecraft:honeycomb_block
setblock 37 284 325 minecraft:yellow_terracotta
fill 37 284 326 37 285 326 minecraft:honeycomb_block
setblock 38 284 324 minecraft:yellow_terracotta
fill 38 284 325 38 287 325 minecraft:honeycomb_block
setblock 39 284 323 minecraft:yellow_terracotta
fill 39 284 324 39 287 324 minecraft:honeycomb_block
fill 39 284 326 39 284 327 minecraft:honeycomb_block
setblock 39 284 363 minecraft:yellow_terracotta
fill 40 284 323 40 287 323 minecraft:honeycomb_block
setblock 40 284 326 minecraft:honeycomb_block
setblock 40 284 327 minecraft:yellow_terracotta
fill 40 284 328 40 285 328 minecraft:honeycomb_block
setblock 40 284 361 minecraft:honeycomb_block
setblock 40 284 362 minecraft:yellow_terracotta
fill 40 284 363 40 287 363 minecraft:honeycomb_block
setblock 41 284 326 minecraft:yellow_terracotta
fill 41 284 327 41 287 327 minecraft:honeycomb_block
setblock 41 284 330 minecraft:honeycomb_block
setblock 41 284 331 minecraft:honey_block
setblock 41 284 342 minecraft:honeycomb_block
fill 41 284 344 41 284 345 minecraft:honeycomb_block
setblock 41 284 346 minecraft:yellow_terracotta
setblock 41 284 347 minecraft:honeycomb_block
fill 41 284 350 41 285 350 minecraft:honey_block
setblock 41 284 356 minecraft:honey_block
fill 41 284 359 41 284 360 minecraft:honeycomb_block
setblock 41 284 361 minecraft:yellow_terracotta
fill 41 284 362 41 286 362 minecraft:honeycomb_block
fill 42 284 323 42 308 323 minecraft:honeycomb_block
fill 0 285 346 1 287 346 minecraft:honeycomb_block
fill 1 285 323 1 285 324 minecraft:honeycomb_block
setblock 1 285 325 minecraft:yellow_terracotta
setblock 1 285 326 minecraft:honeycomb_block
setblock 1 285 336 minecraft:honey_block
setblock 1 285 344 minecraft:honeycomb_block
setblock 1 285 345 minecraft:yellow_terracotta
fill 1 285 347 1 285 349 minecraft:honeycomb_block
setblock 1 285 350 minecraft:yellow_terracotta
setblock 1 285 359 minecraft:honeycomb_block
setblock 1 285 360 minecraft:yellow_terracotta
fill 1 285 361 1 286 363 minecraft:honeycomb_block
setblock 2 285 323 minecraft:honeycomb_block
setblock 2 285 363 minecraft:honeycomb_block
setblock 3 285 323 minecraft:yellow_terracotta
setblock 3 285 325 minecraft:light[level=12]
setblock 3 285 332 minecraft:light[level=12]
setblock 3 285 339 minecraft:light[level=12]
setblock 3 285 346 minecraft:light[level=12]
setblock 3 285 353 minecraft:light[level=12]
setblock 3 285 360 minecraft:light[level=12]
setblock 3 285 363 minecraft:yellow_terracotta
fill 4 285 323 7 285 323 minecraft:honeycomb_block
fill 4 285 363 7 285 363 minecraft:honeycomb_block
fill 5 285 341 5 287 341 minecraft:brown_terracotta
fill 5 285 345 5 287 345 minecraft:brown_terracotta
fill 7 285 340 7 287 340 minecraft:brown_terracotta
fill 7 285 346 7 287 346 minecraft:brown_terracotta
setblock 8 285 323 minecraft:yellow_terracotta
setblock 8 285 363 minecraft:yellow_terracotta
fill 9 285 323 12 285 323 minecraft:honeycomb_block
fill 9 285 341 9 287 341 minecraft:brown_terracotta
fill 9 285 345 9 287 345 minecraft:brown_terracotta
setblock 9 285 362 minecraft:yellow_terracotta
fill 9 285 363 12 285 363 minecraft:honeycomb_block
fill 10 285 324 11 285 324 minecraft:honeycomb_block
setblock 10 285 325 minecraft:light[level=12]
setblock 10 285 332 minecraft:light[level=12]
setblock 10 285 339 minecraft:light[level=12]
fill 10 285 343 10 287 343 minecraft:brown_terracotta
setblock 10 285 346 minecraft:light[level=12]
setblock 10 285 353 minecraft:light[level=12]
setblock 10 285 360 minecraft:light[level=12]
fill 10 285 362 13 285 362 minecraft:honeycomb_block
setblock 12 285 324 minecraft:yellow_terracotta
setblock 13 285 323 minecraft:yellow_terracotta
fill 13 285 324 16 285 324 minecraft:honeycomb_block
setblock 13 285 363 minecraft:yellow_terracotta
fill 14 285 323 17 285 323 minecraft:honeycomb_block
setblock 14 285 362 minecraft:yellow_terracotta
fill 14 285 363 17 285 363 minecraft:honeycomb_block
setblock 15 285 362 minecraft:honeycomb_block
setblock 17 285 324 minecraft:yellow_terracotta
setblock 17 285 325 minecraft:light[level=12]
setblock 17 285 332 minecraft:light[level=12]
setblock 17 285 339 minecraft:light[level=12]
setblock 17 285 346 minecraft:light[level=12]
setblock 17 285 353 minecraft:light[level=12]
setblock 17 285 360 minecraft:light[level=12]
setblock 18 285 323 minecraft:yellow_terracotta
setblock 18 285 363 minecraft:yellow_terracotta
fill 19 285 322 19 286 323 minecraft:honeycomb_block
fill 20 285 323 22 285 323 minecraft:honeycomb_block
setblock 23 285 323 minecraft:yellow_terracotta
fill 24 285 323 27 285 323 minecraft:honeycomb_block
setblock 24 285 325 minecraft:light[level=12]
setblock 24 285 332 minecraft:light[level=12]
setblock 24 285 339 minecraft:light[level=12]
setblock 24 285 346 minecraft:light[level=12]
setblock 24 285 353 minecraft:light[level=12]
setblock 24 285 360 minecraft:light[level=12]
fill 24 285 363 24 286 363 minecraft:honey_block
setblock 27 285 324 minecraft:yellow_terracotta
setblock 28 285 322 minecraft:orange_terracotta
setblock 28 285 323 minecraft:yellow_terracotta
fill 28 285 324 31 285 324 minecraft:honeycomb_block
fill 28 285 358 28 286 358 minecraft:brown_terracotta
fill 28 285 360 28 286 360 minecraft:brown_terracotta
fill 29 285 323 32 285 323 minecraft:honeycomb_block
fill 29 285 325 30 285 325 minecraft:honeycomb_block
fill 29 285 357 31 286 357 minecraft:brown_terracotta
fill 29 285 361 31 286 361 minecraft:brown_terracotta
fill 29 285 363 32 285 363 minecraft:honeycomb_block
setblock 31 285 325 minecraft:yellow_terracotta
setblock 31 285 332 minecraft:light[level=12]
setblock 31 285 339 minecraft:light[level=12]
setblock 31 285 346 minecraft:light[level=12]
setblock 31 285 353 minecraft:light[level=12]
setblock 32 285 324 minecraft:yellow_terracotta
fill 32 285 325 34 285 326 minecraft:honeycomb_block
fill 32 285 359 32 286 359 minecraft:brown_terracotta
fill 32 285 362 33 285 362 minecraft:honeycomb_block
setblock 33 285 323 minecraft:yellow_terracotta
fill 33 285 324 36 285 324 minecraft:honeycomb_block
setblock 33 285 363 minecraft:yellow_terracotta
fill 34 285 323 37 285 323 minecraft:honeycomb_block
setblock 34 285 362 minecraft:yellow_terracotta
fill 34 285 363 37 285 363 minecraft:honeycomb_block
setblock 35 285 325 minecraft:honeycomb_block
setblock 35 285 326 minecraft:yellow_terracotta
fill 35 285 362 38 285 362 minecraft:honeycomb_block
setblock 36 285 325 minecraft:yellow_terracotta
fill 36 285 326 36 286 326 minecraft:honeycomb_block
setblock 37 285 324 minecraft:yellow_terracotta
fill 37 285 325 37 288 325 minecraft:honeycomb_block
setblock 38 285 323 minecraft:yellow_terracotta
fill 38 285 324 38 288 324 minecraft:honeycomb_block
setblock 38 285 332 minecraft:light[level=12]
setblock 38 285 339 minecraft:light[level=12]
setblock 38 285 346 minecraft:light[level=12]
setblock 38 285 353 minecraft:light[level=12]
setblock 38 285 360 minecraft:light[level=12]
setblock 38 285 363 minecraft:yellow_terracotta
fill 39 285 323 39 288 323 minecraft:honeycomb_block
fill 39 285 325 39 285 326 minecraft:honeycomb_block
setblock 39 285 362 minecraft:yellow_terracotta
fill 39 285 363 39 288 363 minecraft:honeycomb_block
setblock 40 285 325 minecraft:honeycomb_block
setblock 40 285 326 minecraft:yellow_terracotta
fill 40 285 327 40 287 327 minecraft:honeycomb_block
setblock 41 285 325 minecraft:yellow_terracotta
fill 41 285 326 41 288 326 minecraft:honeycomb_block
setblock 41 285 329 minecraft:honeycomb_block
setblock 41 285 344 minecraft:honey_block
setblock 41 285 361 minecraft:honeycomb_block
setblock 1 286 323 minecraft:honeycomb_block
setblock 1 286 324 minecraft:yellow_terracotta
setblock 1 286 325 minecraft:honeycomb_block
setblock 1 286 342 minecraft:honey_block
setblock 1 286 345 minecraft:honeycomb_block
fill 1 286 347 1 286 348 minecraft:honeycomb_block
setblock 1 286 349 minecraft:yellow_terracotta
fill 1 286 350 1 289 350 minecraft:honeycomb_block
setblock 2 286 323 minecraft:yellow_terracotta
setblock 2 286 363 minecraft:yellow_terracotta
fill 3 286 363 6 286 363 minecraft:honeycomb_block
fill 4 286 342 4 287 344 minecraft:brown_terracotta
setblock 6 286 323 minecraft:honeycomb_block
fill 6 286 340 6 287 340 minecraft:brown_terracotta
fill 6 286 346 6 287 346 minecraft:brown_terracotta
setblock 7 286 323 minecraft:yellow_terracotta
setblock 7 286 363 minecraft:yellow_terracotta
fill 8 286 323 11 286 323 minecraft:honeycomb_block
fill 8 286 340 8 287 340 minecraft:brown_terracotta
fill 8 286 346 8 287 346 minecraft:brown_terracotta
fill 8 286 363 11 286 363 minecraft:honeycomb_block
fill 10 286 342 10 287 342 minecraft:brown_terracotta
fill 10 286 344 10 287 345 minecraft:brown_terracotta
setblock 11 286 324 minecraft:yellow_terracotta
fill 11 286 362 12 286 362 minecraft:honeycomb_block
setblock 12 286 323 minecraft:yellow_terracotta
fill 12 286 324 15 286 324 minecraft:honeycomb_block
fill 12 286 363 12 286 364 minecraft:yellow_terracotta
fill 13 286 323 16 286 323 minecraft:honeycomb_block
setblock 13 286 362 minecraft:yellow_terracotta
fill 13 286 363 16 286 363 minecraft:honeycomb_block
setblock 16 286 324 minecraft:yellow_terracotta
setblock 17 286 323 minecraft:yellow_terracotta
setblock 17 286 363 minecraft:yellow_terracotta
fill 18 286 323 18 287 323 minecraft:honeycomb_block
fill 18 286 325 18 290 325 minecraft:brown_terracotta
setblock 20 286 323 minecraft:honeycomb_block
setblock 20 286 364 minecraft:orange_terracotta
fill 24 286 323 26 286 323 minecraft:honeycomb_block
setblock 27 286 323 minecraft:yellow_terracotta
fill 27 286 324 30 286 324 minecraft:honeycomb_block
fill 27 286 358 27 286 360 minecraft:brown_terracotta
fill 28 286 322 28 289 323 minecraft:honeycomb_block
setblock 28 286 357 minecraft:brown_terracotta
setblock 28 286 361 minecraft:brown_terracotta
fill 29 286 323 31 286 323 minecraft:honeycomb_block
setblock 29 286 325 minecraft:honeycomb_block
fill 29 286 356 30 286 356 minecraft:brown_terracotta
fill 29 286 362 30 286 362 minecraft:brown_terracotta
fill 29 286 363 31 286 363 minecraft:honeycomb_block
setblock 30 286 325 minecraft:yellow_terracotta
setblock 31 286 324 minecraft:yellow_terracotta
fill 31 286 325 33 286 326 minecraft:honeycomb_block
setblock 32 286 323 minecraft:yellow_terracotta
fill 32 286 324 35 286 324 minecraft:honeycomb_block
fill 32 286 357 32 286 358 minecraft:brown_terracotta
fill 32 286 360 32 286 361 minecraft:brown_terracotta
setblock 32 286 363 minecraft:yellow_terracotta
fill 33 286 323 36 286 323 minecraft:honeycomb_block
setblock 33 286 362 minecraft:yellow_terracotta
fill 33 286 363 36 286 363 minecraft:honeycomb_block
setblock 34 286 325 minecraft:honeycomb_block
setblock 34 286 326 minecraft:yellow_terracotta
fill 34 286 362 37 286 362 minecraft:honeycomb_block
setblock 35 286 325 minecraft:yellow_terracotta
fill 35 286 326 35 287 326 minecraft:honeycomb_block
setblock 36 286 324 minecraft:yellow_terracotta
fill 36 286 325 36 289 325 minecraft:honeycomb_block
setblock 37 286 323 minecraft:yellow_terracotta
fill 37 286 324 37 289 324 minecraft:honeycomb_block
setblock 37 286 363 minecraft:yellow_terracotta
fill 38 286 323 38 289 323 minecraft:honeycomb_block
fill 38 286 363 38 289 363 minecraft:honeycomb_block
setblock 39 286 325 minecraft:honeycomb_block
setblock 40 286 324 minecraft:honeycomb_block
setblock 40 286 325 minecraft:yellow_terracotta
fill 40 286 326 40 288 326 minecraft:honeycomb_block
setblock 41 286 324 minecraft:yellow_terracotta
fill 41 286 325 41 289 325 minecraft:honeycomb_block
setblock 41 286 329 minecraft:yellow_terracotta
setblock 41 286 338 minecraft:honey_block
setblock 1 287 323 minecraft:yellow_terracotta
setblock 1 287 324 minecraft:honeycomb_block
setblock 1 287 329 minecraft:honey_block
setblock 1 287 347 minecraft:honeycomb_block
setblock 1 287 348 minecraft:yellow_terracotta
fill 1 287 349 1 290 349 minecraft:honeycomb_block
fill 1 287 351 1 288 351 minecraft:honeycomb_block
setblock 1 287 354 minecraft:honey_block
setblock 1 287 363 minecraft:yellow_terracotta
setblock 3 287 325 minecraft:light[level=15]
setblock 3 287 333 minecraft:light[level=15]
setblock 3 287 341 minecraft:light[level=15]
setblock 3 287 349 minecraft:light[level=15]
setblock 3 287 357 minecraft:light[level=15]
setblock 4 287 341 minecraft:brown_terracotta
setblock 4 287 345 minecraft:brown_terracotta
setblock 5 287 340 minecraft:brown_terracotta
setblock 5 287 346 minecraft:brown_terracotta
setblock 6 287 323 minecraft:honey_block
setblock 6 287 363 minecraft:yellow_terracotta
fill 7 287 323 10 287 323 minecraft:honeycomb_block
setblock 7 287 347 minecraft:brown_terracotta
fill 7 287 363 10 287 363 minecraft:honeycomb_block
setblock 9 287 340 minecraft:brown_terracotta
setblock 9 287 346 minecraft:brown_terracotta
setblock 10 287 341 minecraft:brown_terracotta
setblock 11 287 323 minecraft:yellow_terracotta
fill 11 287 324 14 287 324 minecraft:honeycomb_block
setblock 11 287 325 minecraft:light[level=15]
setblock 11 287 333 minecraft:light[level=15]
setblock 11 287 341 minecraft:light[level=15]
setblock 11 287 343 minecraft:brown_terracotta
setblock 11 287 349 minecraft:light[level=15]
setblock 11 287 357 minecraft:light[level=15]
setblock 11 287 363 minecraft:yellow_terracotta
fill 12 287 323 15 287 323 minecraft:honeycomb_block
fill 12 287 363 12 288 364 minecraft:honeycomb_block
fill 13 287 363 15 287 363 minecraft:honeycomb_block
setblock 16 287 323 minecraft:yellow_terracotta
setblock 17 287 323 minecraft:honeycomb_block
fill 19 287 322 19 308 322 minecraft:honeycomb_block
setblock 19 287 325 minecraft:light[level=15]
setblock 19 287 333 minecraft:light[level=15]
setblock 19 287 341 minecraft:light[level=15]
setblock 19 287 349 minecraft:light[level=15]
setblock 19 287 357 minecraft:light[level=15]
fill 20 287 364 20 308 364 minecraft:honeycomb_block
setblock 25 287 323 minecraft:honeycomb_block
setblock 26 287 323 minecraft:yellow_terracotta
fill 26 287 358 26 295 358 minecraft:yellow_terracotta
fill 27 287 323 27 289 324 minecraft:honeycomb_block
setblock 27 287 325 minecraft:light[level=15]
setblock 27 287 333 minecraft:light[level=15]
setblock 27 287 341 minecraft:light[level=15]
setblock 27 287 349 minecraft:light[level=15]
setblock 27 287 357 minecraft:light[level=15]
fill 28 287 324 29 287 324 minecraft:honeycomb_block
fill 29 287 323 30 287 323 minecraft:honeycomb_block
setblock 29 287 325 minecraft:yellow_terracotta
fill 29 287 363 30 287 363 minecraft:honeycomb_block
setblock 30 287 324 minecraft:yellow_terracotta
fill 30 287 325 33 287 325 minecraft:honeycomb_block
setblock 31 287 323 minecraft:yellow_terracotta
fill 31 287 324 34 287 324 minecraft:honeycomb_block
fill 31 287 326 32 287 326 minecraft:honeycomb_block
setblock 31 287 363 minecraft:yellow_terracotta
fill 32 287 323 35 287 323 minecraft:honeycomb_block
fill 32 287 363 35 287 363 minecraft:honeycomb_block
setblock 33 287 326 minecraft:yellow_terracotta
setblock 34 287 325 minecraft:yellow_terracotta
fill 34 287 326 34 290 326 minecraft:honeycomb_block
setblock 35 287 324 minecraft:yellow_terracotta
fill 35 287 325 35 290 325 minecraft:honeycomb_block
setblock 35 287 333 minecraft:light[level=15]
setblock 35 287 341 minecraft:light[level=15]
setblock 35 287 349 minecraft:light[level=15]
setblock 35 287 357 minecraft:light[level=15]
setblock 36 287 323 minecraft:yellow_terracotta
fill 36 287 324 36 290 324 minecraft:honeycomb_block
fill 36 287 343 39 300 345 minecraft:yellow_terracotta
setblock 36 287 363 minecraft:yellow_terracotta
fill 37 287 323 37 290 323 minecraft:honeycomb_block
fill 37 287 342 38 300 342 minecraft:yellow_terracotta
fill 37 287 346 38 300 346 minecraft:yellow_terracotta
fill 37 287 363 37 290 363 minecraft:honeycomb_block
setblock 40 287 324 minecraft:yellow_terracotta
fill 40 287 325 40 288 325 minecraft:honeycomb_block
setblock 41 287 323 minecraft:yellow_terracotta
fill 41 287 324 41 290 324 minecraft:honeycomb_block
setblock 41 287 328 minecraft:yellow_terracotta
setblock 41 287 332 minecraft:honey_block
setblock 41 287 357 minecraft:honey_block
setblock 41 287 363 minecraft:yellow_terracotta
setblock 0 288 324 minecraft:orange_terracotta
fill 0 288 346 0 308 346 minecraft:honeycomb_block
setblock 1 288 335 minecraft:honey_block
setblock 1 288 347 minecraft:yellow_terracotta
fill 1 288 348 1 291 348 minecraft:honeycomb_block
setblock 1 288 360 minecraft:honey_block
fill 7 288 343 7 291 343 minecraft:yellow_terracotta
fill 7 288 363 9 288 363 minecraft:honeycomb_block
fill 8 288 323 9 288 323 minecraft:honeycomb_block
setblock 10 288 323 minecraft:yellow_terracotta
setblock 10 288 363 minecraft:yellow_terracotta
fill 11 288 323 14 288 323 minecraft:honeycomb_block
fill 11 288 363 11 291 363 minecraft:honeycomb_block
fill 12 288 324 13 288 324 minecraft:honeycomb_block
fill 13 288 363 14 288 363 minecraft:honeycomb_block
setblock 15 288 323 minecraft:yellow_terracotta
setblock 16 288 323 minecraft:honeycomb_block
fill 17 288 325 17 290 325 minecraft:brown_terracotta
setblock 17 288 363 minecraft:honey_block
fill 18 288 324 18 290 324 minecraft:brown_terracotta
fill 18 288 326 18 290 326 minecraft:brown_terracotta
fill 19 288 325 19 290 325 minecraft:brown_terracotta
setblock 25 288 323 minecraft:yellow_terracotta
fill 26 288 323 26 290 324 minecraft:honeycomb_block
setblock 28 288 324 minecraft:honeycomb_block
setblock 28 288 325 minecraft:yellow_terracotta
setblock 29 288 323 minecraft:honeycomb_block
setblock 29 288 324 minecraft:yellow_terracotta
fill 29 288 325 32 288 325 minecraft:honeycomb_block
setblock 30 288 323 minecraft:yellow_terracotta
fill 30 288 324 33 288 324 minecraft:honeycomb_block
setblock 30 288 363 minecraft:yellow_terracotta
fill 31 288 323 34 288 323 minecraft:honeycomb_block
setblock 31 288 326 minecraft:honeycomb_block
fill 31 288 363 34 288 363 minecraft:honeycomb_block
setblock 32 288 326 minecraft:yellow_terracotta
setblock 33 288 325 minecraft:yellow_terracotta
fill 33 288 326 33 291 326 minecraft:honeycomb_block
setblock 34 288 324 minecraft:yellow_terracotta
fill 34 288 325 34 291 325 minecraft:honeycomb_block
setblock 35 288 323 minecraft:yellow_terracotta
fill 35 288 324 35 291 324 minecraft:honeycomb_block
fill 35 288 343 35 289 345 minecraft:brown_terracotta
setblock 35 288 363 minecraft:yellow_terracotta
fill 36 288 323 36 291 323 minecraft:honeycomb_block
fill 36 288 342 36 289 342 minecraft:brown_terracotta
fill 36 288 346 36 289 346 minecraft:brown_terracotta
fill 36 288 363 36 291 363 minecraft:honeycomb_block
fill 37 288 341 38 289 341 minecraft:brown_terracotta
fill 37 288 347 38 289 347 minecraft:brown_terracotta
setblock 39 288 324 minecraft:yellow_terracotta
fill 39 288 342 40 289 342 minecraft:brown_terracotta
fill 39 288 346 40 289 346 minecraft:brown_terracotta
setblock 40 288 323 minecraft:yellow_terracotta
setblock 40 288 324 minecraft:honeycomb_block
fill 40 288 343 40 289 345 minecraft:brown_terracotta
fill 41 288 323 41 291 323 minecraft:honeycomb_block
setblock 41 288 327 minecraft:yellow_terracotta
fill 41 288 328 41 291 328 minecraft:honeycomb_block
setblock 41 288 351 minecraft:honey_block
fill 0 289 324 0 294 324 minecraft:honeycomb_block
setblock 1 289 341 minecraft:honey_block
fill 1 289 347 1 292 347 minecraft:honeycomb_block
setblock 1 289 351 minecraft:yellow_terracotta
fill 1 289 352 1 291 353 minecraft:honeycomb_block
setblock 4 289 363 minecraft:honey_block
setblock 8 289 323 minecraft:honeycomb_block
setblock 8 289 363 minecraft:honeycomb_block
setblock 9 289 323 minecraft:yellow_terracotta
setblock 9 289 363 minecraft:yellow_terracotta
fill 10 289 323 13 289 323 minecraft:honeycomb_block
fill 10 289 363 10 292 363 minecraft:honeycomb_block
setblock 12 289 363 minecraft:honeycomb_block
setblock 12 289 364 minecraft:yellow_concrete
setblock 14 289 323 minecraft:yellow_terracotta
fill 15 289 323 15 290 323 minecraft:honeycomb_block
fill 17 289 324 17 290 324 minecraft:brown_terracotta
fill 17 289 326 17 290 326 minecraft:brown_terracotta
setblock 19 289 323 minecraft:honey_block
fill 19 289 324 19 290 324 minecraft:brown_terracotta
fill 19 289 326 19 290 326 minecraft:brown_terracotta
setblock 23 289 363 minecraft:honey_block
fill 25 289 323 25 292 323 minecraft:honeycomb_block
setblock 28 289 324 minecraft:yellow_terracotta
fill 28 289 325 31 289 325 minecraft:honeycomb_block
setblock 29 289 323 minecraft:yellow_terracotta
fill 29 289 324 32 289 324 minecraft:honeycomb_block
setblock 29 289 363 minecraft:yellow_terracotta
fill 30 289 323 33 289 323 minecraft:honeycomb_block
setblock 30 289 326 minecraft:honeycomb_block
fill 30 289 363 33 289 363 minecraft:honeycomb_block
setblock 31 289 326 minecraft:yellow_terracotta
setblock 32 289 325 minecraft:yellow_terracotta
fill 32 289 326 32 292 326 minecraft:honeycomb_block
setblock 33 289 324 minecraft:yellow_terracotta
fill 33 289 325 33 292 325 minecraft:honeycomb_block
setblock 34 289 323 minecraft:yellow_terracotta
fill 34 289 324 34 292 324 minecraft:honeycomb_block
fill 34 289 342 34 289 346 minecraft:brown_terracotta
setblock 34 289 363 minecraft:yellow_terracotta
fill 35 289 323 35 292 323 minecraft:honeycomb_block
fill 35 289 341 35 289 342 minecraft:brown_terracotta
fill 35 289 346 35 289 347 minecraft:brown_terracotta
fill 35 289 363 35 292 363 minecraft:honeycomb_block
setblock 36 289 341 minecraft:brown_terracotta
setblock 36 289 347 minecraft:brown_terracotta
setblock 37 289 325 minecraft:yellow_terracotta
fill 37 289 340 38 289 340 minecraft:brown_terracotta
fill 37 289 348 38 289 348 minecraft:brown_terracotta
setblock 38 289 324 minecraft:yellow_terracotta
setblock 39 289 323 minecraft:yellow_terracotta
setblock 39 289 324 minecraft:honeycomb_block
fill 39 289 341 40 289 341 minecraft:brown_terracotta
fill 39 289 347 40 289 347 minecraft:brown_terracotta
fill 40 289 323 40 292 323 minecraft:honeycomb_block
setblock 41 289 326 minecraft:yellow_terracotta
fill 41 289 327 41 292 327 minecraft:honeycomb_block
fill 41 289 342 41 289 344 minecraft:brown_terracotta
setblock 41 289 345 minecraft:honey_block
setblock 41 289 346 minecraft:brown_terracotta
setblock 0 290 362 minecraft:yellow_concrete
setblock 1 290 328 minecraft:honey_block
fill 1 290 346 1 293 346 minecraft:honeycomb_block
setblock 1 290 350 minecraft:yellow_terracotta
fill 1 290 351 1 293 351 minecraft:honeycomb_block
setblock 1 290 354 minecraft:honeycomb_block
setblock 7 290 323 minecraft:honeycomb_block
setblock 8 290 323 minecraft:yellow_terracotta
setblock 8 290 363 minecraft:yellow_terracotta
fill 9 290 323 12 290 323 minecraft:honeycomb_block
fill 9 290 363 9 293 363 minecraft:honeycomb_block
fill 12 290 364 12 308 364 minecraft:honeycomb_block
setblock 13 290 323 minecraft:yellow_terracotta
fill 14 290 323 14 291 323 minecraft:honeycomb_block
fill 24 290 323 24 293 323 minecraft:honeycomb_block
setblock 27 290 323 minecraft:honeycomb_block
setblock 27 290 324 minecraft:yellow_terracotta
fill 27 290 325 30 290 325 minecraft:honeycomb_block
fill 28 290 322 28 308 322 minecraft:honeycomb_block
setblock 28 290 323 minecraft:yellow_terracotta
fill 28 290 324 31 290 324 minecraft:honeycomb_block
fill 29 290 323 32 290 323 minecraft:honeycomb_block
setblock 29 290 326 minecraft:honeycomb_block
fill 29 290 363 32 290 363 minecraft:honeycomb_block
setblock 30 290 326 minecraft:yellow_terracotta
setblock 31 290 325 minecraft:yellow_terracotta
fill 31 290 326 31 293 326 minecraft:honeycomb_block
setblock 32 290 324 minecraft:yellow_terracotta
fill 32 290 325 32 293 325 minecraft:honeycomb_block
setblock 33 290 323 minecraft:yellow_terracotta
fill 33 290 324 33 293 324 minecraft:honeycomb_block
setblock 33 290 363 minecraft:yellow_terracotta
fill 34 290 323 34 293 323 minecraft:honeycomb_block
fill 34 290 363 34 293 363 minecraft:honeycomb_block
fill 35 290 342 35 292 342 minecraft:flowering_azalea_leaves[persistent=true]
setblock 36 290 325 minecraft:yellow_terracotta
setblock 37 290 324 minecraft:yellow_terracotta
setblock 38 290 323 minecraft:yellow_terracotta
fill 38 290 324 38 291 324 minecraft:honeycomb_block
fill 39 290 323 39 293 323 minecraft:honeycomb_block
setblock 41 290 325 minecraft:yellow_terracotta
fill 41 290 326 41 293 326 minecraft:honeycomb_block
setblock 41 290 329 minecraft:honeycomb_block
setblock 41 290 339 minecraft:honey_block
setblock 41 290 358 minecraft:honey_block
setblock 42 290 333 minecraft:orange_terracotta
setblock 42 290 344 minecraft:yellow_concrete
setblock 0 291 347 minecraft:orange_terracotta
fill 0 291 362 0 308 362 minecraft:honeycomb_block
setblock 1 291 334 minecraft:honey_block
setblock 1 291 349 minecraft:yellow_terracotta
fill 1 291 350 2 293 350 minecraft:honeycomb_block
setblock 1 291 354 minecraft:yellow_terracotta
fill 1 291 355 1 293 356 minecraft:honeycomb_block
setblock 2 291 348 minecraft:yellow_terracotta
fill 2 291 349 2 294 349 minecraft:honeycomb_block
fill 2 291 351 2 291 352 minecraft:honeycomb_block
setblock 2 291 353 minecraft:yellow_terracotta
setblock 3 291 325 minecraft:light[level=12]
setblock 3 291 332 minecraft:light[level=12]
setblock 3 291 339 minecraft:light[level=12]
setblock 3 291 346 minecraft:light[level=12]
setblock 3 291 353 minecraft:light[level=12]
setblock 3 291 360 minecraft:light[level=12]
fill 6 291 342 6 293 344 minecraft:flowering_azalea_leaves[persistent=true]
setblock 7 291 323 minecraft:yellow_terracotta
fill 7 291 342 8 293 342 minecraft:flowering_azalea_leaves[persistent=true]
fill 7 291 344 7 293 345 minecraft:flowering_azalea_leaves[persistent=true]
setblock 7 291 363 minecraft:yellow_terracotta
fill 8 291 323 11 291 323 minecraft:honeycomb_block
fill 8 291 343 8 293 344 minecraft:flowering_azalea_leaves[persistent=true]
fill 8 291 363 8 294 363 minecraft:honeycomb_block
fill 9 291 343 9 293 343 minecraft:flowering_azalea_leaves[persistent=true]
fill 9 291 360 9 296 360 minecraft:brown_terracotta
setblock 10 291 325 minecraft:light[level=12]
setblock 10 291 332 minecraft:light[level=12]
setblock 10 291 339 minecraft:light[level=12]
setblock 10 291 346 minecraft:light[level=12]
setblock 10 291 353 minecraft:light[level=12]
setblock 10 291 360 minecraft:light[level=12]
setblock 12 291 323 minecraft:yellow_terracotta
fill 13 291 323 13 293 323 minecraft:honeycomb_block
setblock 16 291 363 minecraft:honey_block
setblock 17 291 325 minecraft:light[level=12]
setblock 17 291 332 minecraft:light[level=12]
setblock 17 291 339 minecraft:light[level=12]
setblock 17 291 346 minecraft:light[level=12]
setblock 17 291 353 minecraft:light[level=12]
setblock 17 291 360 minecraft:light[level=12]
setblock 24 291 325 minecraft:light[level=12]
setblock 24 291 332 minecraft:light[level=12]
setblock 24 291 339 minecraft:light[level=12]
setblock 24 291 346 minecraft:light[level=12]
setblock 24 291 353 minecraft:light[level=12]
setblock 24 291 360 minecraft:light[level=12]
setblock 25 291 324 minecraft:honeycomb_block
setblock 26 291 323 minecraft:honeycomb_block
setblock 26 291 324 minecraft:yellow_terracotta
fill 26 291 325 29 291 325 minecraft:honeycomb_block
setblock 27 291 323 minecraft:yellow_terracotta
fill 27 291 324 30 291 324 minecraft:honeycomb_block
fill 28 291 323 31 291 323 minecraft:honeycomb_block
setblock 28 291 326 minecraft:honeycomb_block
fill 28 291 363 31 291 363 minecraft:honeycomb_block
setblock 29 291 326 minecraft:yellow_terracotta
setblock 30 291 325 minecraft:yellow_terracotta
fill 30 291 326 30 294 326 minecraft:honeycomb_block
setblock 31 291 324 minecraft:yellow_terracotta
fill 31 291 325 31 294 325 minecraft:honeycomb_block
setblock 31 291 332 minecraft:light[level=12]
setblock 31 291 339 minecraft:light[level=12]
setblock 31 291 346 minecraft:light[level=12]
setblock 31 291 353 minecraft:light[level=12]
setblock 32 291 323 minecraft:yellow_terracotta
fill 32 291 324 32 294 324 minecraft:honeycomb_block
setblock 32 291 363 minecraft:yellow_terracotta
fill 33 291 323 33 294 323 minecraft:honeycomb_block
fill 33 291 363 33 294 363 minecraft:honeycomb_block
setblock 34 291 364 minecraft:yellow_concrete
setblock 35 291 325 minecraft:yellow_terracotta
setblock 36 291 324 minecraft:yellow_terracotta
setblock 36 291 325 minecraft:honeycomb_block
setblock 37 291 323 minecraft:yellow_terracotta
fill 37 291 324 37 293 324 minecraft:honeycomb_block
setblock 37 291 363 minecraft:yellow_terracotta
fill 38 291 323 38 294 323 minecraft:honeycomb_block
setblock 38 291 325 minecraft:light[level=12]
setblock 38 291 332 minecraft:light[level=12]
setblock 38 291 339 minecraft:light[level=12]
setblock 38 291 353 minecraft:light[level=12]
setblock 38 291 360 minecraft:light[level=12]
setblock 41 291 324 minecraft:yellow_terracotta
fill 41 291 325 41 294 325 minecraft:honeycomb_block
setblock 41 291 329 minecraft:yellow_terracotta
setblock 41 291 333 minecraft:honey_block
fill 41 291 350 41 292 352 minecraft:honeycomb_block
fill 42 291 333 42 308 333 minecraft:honeycomb_block
fill 42 291 344 42 308 344 minecraft:honeycomb_block
fill 0 292 347 0 308 347 minecraft:honeycomb_block
setblock 1 292 340 minecraft:honey_block
setblock 1 292 348 minecraft:yellow_terracotta
fill 1 292 349 1 295 349 minecraft:honeycomb_block
setblock 1 292 352 minecraft:honeycomb_block
setblock 1 292 353 minecraft:yellow_terracotta
fill 1 292 354 2 294 354 minecraft:honeycomb_block
setblock 1 292 357 minecraft:honeycomb_block
setblock 1 292 359 minecraft:honey_block
setblock 2 292 347 minecraft:yellow_terracotta
fill 2 292 348 2 295 348 minecraft:honeycomb_block
setblock 2 292 351 minecraft:honeycomb_block
setblock 2 292 352 minecraft:yellow_terracotta
fill 2 292 353 2 295 353 minecraft:honeycomb_block
fill 2 292 355 2 293 355 minecraft:honeycomb_block
setblock 3 292 350 minecraft:honeycomb_block
setblock 3 292 351 minecraft:yellow_terracotta
fill 3 292 352 3 295 352 minecraft:honeycomb_block
fill 5 292 342 5 292 344 minecraft:flowering_azalea_leaves[persistent=true]
fill 6 292 341 8 292 341 minecraft:flowering_azalea_leaves[persistent=true]
setblock 6 292 345 minecraft:flowering_azalea_leaves[persistent=true]
setblock 6 292 363 minecraft:yellow_terracotta
fill 7 292 323 10 292 323 minecraft:honeycomb_block
fill 7 292 343 7 293 343 minecraft:flowering_azalea_leaves[persistent=true]
fill 7 292 363 7 295 363 minecraft:honeycomb_block
setblock 8 292 345 minecraft:flowering_azalea_leaves[persistent=true]
setblock 9 292 342 minecraft:flowering_azalea_leaves[persistent=true]
setblock 9 292 344 minecraft:flowering_azalea_leaves[persistent=true]
setblock 11 292 323 minecraft:yellow_terracotta
setblock 11 292 363 minecraft:yellow_terracotta
fill 12 292 323 12 294 323 minecraft:honeycomb_block
fill 12 292 326 12 298 326 minecraft:brown_terracotta
fill 15 292 332 15 293 332 minecraft:yellow_concrete
setblock 16 292 322 minecraft:orange_terracotta
fill 16 292 332 16 293 332 minecraft:black_concrete
setblock 20 292 323 minecraft:honey_block
setblock 22 292 363 minecraft:honey_block
fill 23 292 323 23 294 323 minecraft:honeycomb_block
setblock 24 292 324 minecraft:honeycomb_block
setblock 25 292 322 minecraft:yellow_concrete
setblock 25 292 324 minecraft:yellow_terracotta
setblock 26 292 323 minecraft:yellow_terracotta
fill 26 292 324 28 292 325 minecraft:honeycomb_block
fill 27 292 323 30 292 323 minecraft:honeycomb_block
setblock 27 292 326 minecraft:honeycomb_block
setblock 28 292 326 minecraft:yellow_terracotta
fill 28 292 363 30 292 363 minecraft:honeycomb_block
setblock 29 292 324 minecraft:honeycomb_block
setblock 29 292 325 minecraft:yellow_terracotta
fill 29 292 326 29 295 326 minecraft:honeycomb_block
setblock 30 292 324 minecraft:yellow_terracotta
fill 30 292 325 30 295 325 minecraft:honeycomb_block
setblock 31 292 323 minecraft:yellow_terracotta
fill 31 292 324 31 295 324 minecraft:honeycomb_block
setblock 31 292 363 minecraft:yellow_terracotta
fill 32 292 323 32 295 323 minecraft:honeycomb_block
fill 32 292 363 32 295 363 minecraft:honeycomb_block
setblock 33 292 326 minecraft:yellow_terracotta
setblock 34 292 325 minecraft:yellow_terracotta
setblock 34 292 364 minecraft:orange_terracotta
setblock 35 292 324 minecraft:yellow_terracotta
fill 35 292 325 35 293 325 minecraft:honeycomb_block
setblock 36 292 323 minecraft:yellow_terracotta
fill 36 292 324 36 294 324 minecraft:honeycomb_block
setblock 36 292 363 minecraft:yellow_terracotta
fill 37 292 323 37 295 323 minecraft:honeycomb_block
setblock 41 292 323 minecraft:yellow_terracotta
fill 41 292 324 41 295 324 minecraft:honeycomb_block
setblock 41 292 328 minecraft:yellow_terracotta
fill 41 292 329 41 294 330 minecraft:honeycomb_block
setblock 41 292 346 minecraft:honey_block
fill 41 292 349 41 295 349 minecraft:honeycomb_block
setblock 41 292 353 minecraft:yellow_terracotta
fill 41 292 354 41 293 356 minecraft:honeycomb_block
setblock 41 292 363 minecraft:honey_block
setblock 0 293 345 minecraft:yellow_concrete
fill 1 293 345 1 294 345 minecraft:honeycomb_block
setblock 1 293 347 minecraft:yellow_terracotta
fill 1 293 348 1 296 348 minecraft:honeycomb_block
setblock 1 293 352 minecraft:yellow_terracotta
fill 1 293 353 1 296 353 minecraft:honeycomb_block
setblock 1 293 357 minecraft:yellow_terracotta
fill 1 293 358 1 295 359 minecraft:honeycomb_block
fill 2 293 347 2 296 347 minecraft:honeycomb_block
setblock 2 293 351 minecraft:yellow_terracotta
fill 2 293 352 2 296 352 minecraft:honeycomb_block
setblock 2 293 356 minecraft:yellow_terracotta
fill 3 293 348 3 293 349 minecraft:honeycomb_block
setblock 3 293 350 minecraft:yellow_terracotta
fill 3 293 351 3 296 351 minecraft:honeycomb_block
fill 3 293 353 3 293 354 minecraft:honeycomb_block
setblock 3 293 363 minecraft:honey_block
setblock 5 293 363 minecraft:yellow_terracotta
fill 6 293 323 9 293 323 minecraft:honeycomb_block
fill 6 293 363 6 296 363 minecraft:honeycomb_block
setblock 10 293 323 minecraft:yellow_terracotta
setblock 10 293 363 minecraft:yellow_terracotta
fill 11 293 323 11 295 323 minecraft:honeycomb_block
setblock 14 293 323 minecraft:honey_block
fill 16 293 322 16 308 322 minecraft:honeycomb_block
setblock 24 293 324 minecraft:yellow_terracotta
fill 25 293 322 25 308 322 minecraft:honeycomb_block
setblock 25 293 323 minecraft:yellow_terracotta
fill 25 293 324 27 293 325 minecraft:honeycomb_block
fill 26 293 323 29 293 323 minecraft:honeycomb_block
setblock 27 293 326 minecraft:yellow_terracotta
fill 27 293 363 29 293 363 minecraft:honeycomb_block
setblock 28 293 324 minecraft:honeycomb_block
setblock 28 293 325 minecraft:yellow_terracotta
fill 28 293 326 28 296 326 minecraft:honeycomb_block
setblock 29 293 324 minecraft:yellow_terracotta
fill 29 293 325 29 296 325 minecraft:honeycomb_block
setblock 30 293 323 minecraft:yellow_terracotta
fill 30 293 324 30 296 324 minecraft:honeycomb_block
setblock 30 293 363 minecraft:yellow_terracotta
fill 31 293 323 31 296 323 minecraft:honeycomb_block
fill 31 293 363 31 296 363 minecraft:honeycomb_block
setblock 32 293 326 minecraft:yellow_terracotta
setblock 33 293 325 minecraft:yellow_terracotta
setblock 33 293 326 minecraft:honeycomb_block
setblock 34 293 324 minecraft:yellow_terracotta
fill 34 293 325 34 294 325 minecraft:honeycomb_block
fill 34 293 364 34 308 364 minecraft:honeycomb_block
setblock 35 293 323 minecraft:yellow_terracotta
fill 35 293 324 35 295 324 minecraft:honeycomb_block
setblock 35 293 363 minecraft:yellow_terracotta
fill 36 293 323 36 296 323 minecraft:honeycomb_block
fill 36 293 363 37 295 363 minecraft:honeycomb_block
setblock 40 293 323 minecraft:yellow_terracotta
fill 41 293 323 41 294 323 minecraft:honeycomb_block
setblock 41 293 327 minecraft:yellow_terracotta
fill 41 293 328 41 296 328 minecraft:honeycomb_block
setblock 41 293 331 minecraft:honeycomb_block
setblock 41 293 340 minecraft:honey_block
fill 41 293 348 41 296 348 minecraft:honeycomb_block
fill 41 293 350 41 293 351 minecraft:honeycomb_block
setblock 41 293 352 minecraft:yellow_terracotta
fill 41 293 353 41 296 353 minecraft:honeycomb_block
setblock 41 293 357 minecraft:yellow_terracotta
fill 41 293 358 41 295 359 minecraft:honeycomb_block
fill 0 294 345 0 308 345 minecraft:honeycomb_block
setblock 1 294 327 minecraft:honey_block
fill 1 294 328 1 294 330 minecraft:honeycomb_block
setblock 1 294 331 minecraft:yellow_terracotta
fill 1 294 332 1 297 332 minecraft:honeycomb_block
setblock 1 294 346 minecraft:yellow_terracotta
fill 1 294 347 1 297 347 minecraft:honeycomb_block
setblock 1 294 350 minecraft:honeycomb_block
setblock 1 294 351 minecraft:yellow_terracotta
fill 1 294 352 1 297 352 minecraft:honeycomb_block
setblock 1 294 355 minecraft:honeycomb_block
setblock 1 294 356 minecraft:yellow_terracotta
fill 1 294 357 2 296 357 minecraft:honeycomb_block
setblock 1 294 360 minecraft:honeycomb_block
fill 2 294 346 2 297 346 minecraft:honeycomb_block
setblock 2 294 350 minecraft:yellow_terracotta
fill 2 294 351 2 297 351 minecraft:honeycomb_block
setblock 2 294 355 minecraft:yellow_terracotta
fill 2 294 356 3 296 356 minecraft:honeycomb_block
fill 2 294 358 2 295 358 minecraft:honeycomb_block
setblock 3 294 348 minecraft:honeycomb_block
setblock 3 294 349 minecraft:yellow_terracotta
fill 3 294 350 4 296 350 minecraft:honeycomb_block
setblock 3 294 353 minecraft:honeycomb_block
setblock 3 294 354 minecraft:yellow_terracotta
fill 3 294 355 3 297 355 minecraft:honeycomb_block
fill 4 294 351 4 294 352 minecraft:honeycomb_block
setblock 4 294 353 minecraft:yellow_terracotta
fill 4 294 354 4 297 354 minecraft:honeycomb_block
setblock 4 294 363 minecraft:yellow_terracotta
fill 5 294 363 5 297 363 minecraft:honeycomb_block
fill 6 294 323 8 294 323 minecraft:honeycomb_block
fill 8 294 360 8 296 360 minecraft:brown_terracotta
setblock 9 294 323 minecraft:yellow_terracotta
fill 9 294 359 9 296 359 minecraft:brown_terracotta
fill 9 294 361 9 296 361 minecraft:brown_terracotta
setblock 9 294 363 minecraft:yellow_terracotta
fill 10 294 323 10 296 323 minecraft:honeycomb_block
fill 10 294 360 10 296 360 minecraft:brown_terracotta
fill 10 294 363 10 296 363 minecraft:honeycomb_block
fill 16 294 329 16 295 329 minecraft:black_concrete
fill 22 294 323 22 295 323 minecraft:honeycomb_block
setblock 23 294 324 minecraft:yellow_terracotta
setblock 24 294 323 minecraft:yellow_terracotta
fill 24 294 324 27 294 324 minecraft:honeycomb_block
fill 25 294 323 28 294 323 minecraft:honeycomb_block
fill 25 294 325 26 294 325 minecraft:honeycomb_block
fill 25 294 358 25 295 358 minecraft:yellow_terracotta
setblock 26 294 326 minecraft:yellow_terracotta
fill 26 294 357 26 295 357 minecraft:yellow_terracotta
fill 26 294 359 26 295 359 minecraft:yellow_terracotta
fill 26 294 363 28 294 363 minecraft:honeycomb_block
setblock 27 294 325 minecraft:yellow_terracotta
fill 27 294 326 27 297 326 minecraft:honeycomb_block
fill 27 294 358 27 295 358 minecraft:yellow_terracotta
setblock 28 294 324 minecraft:yellow_terracotta
fill 28 294 325 28 297 325 minecraft:honeycomb_block
setblock 29 294 323 minecraft:yellow_terracotta
fill 29 294 324 29 297 324 minecraft:honeycomb_block
setblock 29 294 363 minecraft:yellow_terracotta
fill 30 294 323 30 297 323 minecraft:honeycomb_block
setblock 30 294 362 minecraft:yellow_terracotta
fill 30 294 363 30 297 363 minecraft:honeycomb_block
setblock 31 294 326 minecraft:yellow_terracotta
fill 31 294 362 31 297 362 minecraft:honeycomb_block
setblock 32 294 325 minecraft:yellow_terracotta
setblock 32 294 326 minecraft:honeycomb_block
setblock 33 294 324 minecraft:yellow_terracotta
fill 33 294 325 33 295 325 minecraft:honeycomb_block
setblock 34 294 323 minecraft:yellow_terracotta
fill 34 294 324 34 296 324 minecraft:honeycomb_block
setblock 34 294 363 minecraft:yellow_terracotta
fill 35 294 323 35 297 323 minecraft:honeycomb_block
fill 35 294 363 35 297 363 minecraft:honeycomb_block
setblock 39 294 323 minecraft:yellow_terracotta
setblock 40 294 323 minecraft:honeycomb_block
setblock 40 294 352 minecraft:yellow_terracotta
fill 40 294 353 40 295 355 minecraft:honeycomb_block
setblock 41 294 326 minecraft:yellow_terracotta
fill 41 294 327 41 297 327 minecraft:honeycomb_block
setblock 41 294 331 minecraft:yellow_terracotta
fill 41 294 332 41 297 332 minecraft:honeycomb_block
setblock 41 294 334 minecraft:honey_block
setblock 41 294 350 minecraft:honeycomb_block
setblock 41 294 351 minecraft:yellow_terracotta
fill 41 294 352 41 297 352 minecraft:honeycomb_block
fill 41 294 354 41 294 355 minecraft:honeycomb_block
setblock 41 294 356 minecraft:yellow_terracotta
fill 41 294 357 41 297 357 minecraft:honeycomb_block
setblock 41 294 360 minecraft:honeycomb_block
setblock 41 294 361 minecraft:yellow_terracotta
fill 41 294 362 41 296 363 minecraft:honeycomb_block
setblock 0 295 324 minecraft:yellow_concrete
setblock 0 295 360 minecraft:orange_terracotta
fill 1 295 328 1 295 329 minecraft:honeycomb_block
setblock 1 295 330 minecraft:yellow_terracotta
fill 1 295 331 1 298 331 minecraft:honeycomb_block
fill 1 295 333 1 295 334 minecraft:honeycomb_block
setblock 1 295 335 minecraft:yellow_terracotta
setblock 1 295 345 minecraft:yellow_terracotta
fill 1 295 346 1 298 346 minecraft:honeycomb_block
setblock 1 295 350 minecraft:yellow_terracotta
fill 1 295 351 1 298 351 minecraft:honeycomb_block
setblock 1 295 354 minecraft:honeycomb_block
setblock 1 295 355 minecraft:yellow_terracotta
fill 1 295 356 1 298 356 minecraft:honeycomb_block
setblock 1 295 360 minecraft:yellow_terracotta
fill 1 295 361 1 298 361 minecraft:honeycomb_block
setblock 2 295 323 minecraft:honey_block
setblock 2 295 349 minecraft:yellow_terracotta
fill 2 295 350 2 298 350 minecraft:honeycomb_block
setblock 2 295 354 minecraft:yellow_terracotta
fill 2 295 355 2 298 355 minecraft:honeycomb_block
setblock 2 295 359 minecraft:yellow_terracotta
setblock 3 295 325 minecraft:light[level=15]
setblock 3 295 333 minecraft:light[level=15]
setblock 3 295 341 minecraft:light[level=15]
setblock 3 295 347 minecraft:honeycomb_block
setblock 3 295 348 minecraft:yellow_terracotta
fill 3 295 349 4 296 349 minecraft:honeycomb_block
setblock 3 295 353 minecraft:yellow_terracotta
fill 3 295 354 3 298 354 minecraft:honeycomb_block
setblock 3 295 357 minecraft:honeycomb_block
setblock 3 295 363 minecraft:yellow_terracotta
setblock 4 295 351 minecraft:honeycomb_block
setblock 4 295 352 minecraft:yellow_terracotta
fill 4 295 353 4 298 353 minecraft:honeycomb_block
fill 4 295 355 4 296 355 minecraft:honeycomb_block
fill 4 295 363 4 298 363 minecraft:honeycomb_block
fill 6 295 323 7 295 323 minecraft:honeycomb_block
setblock 8 295 323 minecraft:yellow_terracotta
setblock 8 295 363 minecraft:yellow_terracotta
fill 9 295 323 9 296 323 minecraft:honeycomb_block
fill 9 295 363 9 297 363 minecraft:honeycomb_block
setblock 11 295 325 minecraft:light[level=15]
setblock 11 295 333 minecraft:light[level=15]
setblock 11 295 341 minecraft:light[level=15]
setblock 11 295 349 minecraft:light[level=15]
setblock 11 295 357 minecraft:light[level=15]
setblock 15 295 363 minecraft:honey_block
setblock 19 295 325 minecraft:light[level=15]
setblock 19 295 333 minecraft:light[level=15]
setblock 19 295 341 minecraft:light[level=15]
setblock 19 295 349 minecraft:light[level=15]
setblock 19 295 357 minecraft:light[level=15]
setblock 21 295 323 minecraft:honey_block
fill 21 295 363 21 296 363 minecraft:honey_block
setblock 22 295 364 minecraft:yellow_terracotta
setblock 23 295 323 minecraft:yellow_terracotta
fill 23 295 324 26 295 324 minecraft:honeycomb_block
fill 24 295 323 27 295 323 minecraft:honeycomb_block
fill 24 295 325 25 295 325 minecraft:honeycomb_block
fill 25 295 363 27 295 363 minecraft:honeycomb_block
setblock 26 295 325 minecraft:yellow_terracotta
fill 26 295 326 26 296 326 minecraft:honeycomb_block
setblock 27 295 324 minecraft:yellow_terracotta
fill 27 295 325 27 298 325 minecraft:honeycomb_block
setblock 27 295 333 minecraft:light[level=15]
setblock 27 295 341 minecraft:light[level=15]
setblock 27 295 349 minecraft:light[level=15]
setblock 27 295 357 minecraft:light[level=15]
setblock 28 295 323 minecraft:yellow_terracotta
fill 28 295 324 28 298 324 minecraft:honeycomb_block
setblock 28 295 362 minecraft:honeycomb_block
setblock 28 295 363 minecraft:yellow_terracotta
fill 29 295 323 29 298 323 minecraft:honeycomb_block
setblock 29 295 362 minecraft:yellow_terracotta
fill 29 295 363 29 298 363 minecraft:honeycomb_block
setblock 30 295 326 minecraft:yellow_terracotta
fill 30 295 362 30 298 362 minecraft:honeycomb_block
setblock 31 295 325 minecraft:yellow_terracotta
setblock 31 295 326 minecraft:honeycomb_block
setblock 32 295 324 minecraft:yellow_terracotta
fill 32 295 325 32 296 325 minecraft:honeycomb_block
fill 32 295 362 32 296 362 minecraft:honeycomb_block
setblock 33 295 323 minecraft:yellow_terracotta
fill 33 295 324 33 297 324 minecraft:honeycomb_block
setblock 33 295 363 minecraft:yellow_terracotta
fill 34 295 323 34 298 323 minecraft:honeycomb_block
fill 34 295 363 34 298 363 minecraft:honeycomb_block
setblock 35 295 325 minecraft:light[level=15]
setblock 35 295 333 minecraft:light[level=15]
setblock 35 295 341 minecraft:light[level=15]
setblock 35 295 349 minecraft:light[level=15]
setblock 35 295 357 minecraft:light[level=15]
setblock 38 295 323 minecraft:yellow_terracotta
setblock 38 295 363 minecraft:yellow_terracotta
fill 39 295 363 40 297 363 minecraft:honeycomb_block
setblock 40 295 351 minecraft:yellow_terracotta
fill 40 295 352 40 298 352 minecraft:honeycomb_block
setblock 40 295 356 minecraft:yellow_terracotta
fill 40 295 357 40 298 357 minecraft:honeycomb_block
setblock 41 295 325 minecraft:yellow_terracotta
fill 41 295 326 41 297 326 minecraft:honeycomb_block
setblock 41 295 329 minecraft:honeycomb_block
setblock 41 295 330 minecraft:yellow_terracotta
fill 41 295 331 41 298 331 minecraft:honeycomb_block
fill 41 295 333 41 296 333 minecraft:honeycomb_block
setblock 41 295 347 minecraft:honey_block
setblock 41 295 350 minecraft:yellow_terracotta
fill 41 295 351 41 298 351 minecraft:honeycomb_block
setblock 41 295 354 minecraft:honeycomb_block
setblock 41 295 355 minecraft:yellow_terracotta
fill 41 295 356 41 298 356 minecraft:honeycomb_block
setblock 41 295 360 minecraft:yellow_terracotta
fill 41 295 361 41 298 361 minecraft:honeycomb_block
setblock 42 295 345 minecraft:yellow_terracotta
fill 0 296 324 0 308 324 minecraft:honeycomb_block
fill 0 296 360 2 298 360 minecraft:honeycomb_block
setblock 1 296 328 minecraft:honeycomb_block
setblock 1 296 329 minecraft:yellow_terracotta
fill 1 296 330 1 299 330 minecraft:honeycomb_block
setblock 1 296 333 minecraft:honeycomb_block
setblock 1 296 334 minecraft:yellow_terracotta
fill 1 296 335 1 297 337 minecraft:honeycomb_block
setblock 1 296 339 minecraft:honey_block
setblock 1 296 344 minecraft:yellow_terracotta
fill 1 296 345 1 299 345 minecraft:honeycomb_block
setblock 1 296 349 minecraft:yellow_terracotta
fill 1 296 350 1 299 350 minecraft:honeycomb_block
setblock 1 296 354 minecraft:yellow_terracotta
fill 1 296 355 1 299 355 minecraft:honeycomb_block
setblock 1 296 358 minecraft:honeycomb_block
setblock 1 296 359 minecraft:yellow_terracotta
fill 1 296 362 1 297 362 minecraft:honeycomb_block
fill 2 296 331 2 296 332 minecraft:honeycomb_block
setblock 2 296 333 minecraft:yellow_terracotta
fill 2 296 334 2 299 334 minecraft:honeycomb_block
setblock 2 296 348 minecraft:yellow_terracotta
fill 2 296 349 2 299 349 minecraft:honeycomb_block
setblock 2 296 353 minecraft:yellow_terracotta
fill 2 296 354 2 299 354 minecraft:honeycomb_block
setblock 2 296 358 minecraft:yellow_terracotta
fill 2 296 359 2 299 359 minecraft:honeycomb_block
setblock 2 296 363 minecraft:honey_block
setblock 3 296 347 minecraft:yellow_terracotta
fill 3 296 348 3 298 348 minecraft:honeycomb_block
setblock 3 296 352 minecraft:yellow_terracotta
fill 3 296 353 3 299 353 minecraft:honeycomb_block
setblock 3 296 357 minecraft:yellow_terracotta
fill 3 296 358 3 299 358 minecraft:honeycomb_block
fill 3 296 363 3 299 363 minecraft:honeycomb_block
setblock 4 296 351 minecraft:yellow_terracotta
fill 4 296 352 4 299 352 minecraft:honeycomb_block
setblock 4 296 356 minecraft:yellow_terracotta
setblock 6 296 323 minecraft:honeycomb_block
setblock 7 296 323 minecraft:yellow_terracotta
setblock 7 296 363 minecraft:yellow_terracotta
schedule function dropper:buildpart/72_11 1t
