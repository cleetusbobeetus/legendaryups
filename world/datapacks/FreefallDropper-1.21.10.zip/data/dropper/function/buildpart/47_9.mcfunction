fill 557 237 189 557 240 189 minecraft:packed_mud
setblock 557 237 193 minecraft:bone_block
fill 557 237 194 557 240 194 minecraft:packed_mud
setblock 557 237 198 minecraft:bone_block
setblock 557 237 213 minecraft:bone_block
fill 557 237 214 557 239 215 minecraft:packed_mud
setblock 558 237 182 minecraft:bone_block
fill 558 237 183 558 240 183 minecraft:packed_mud
setblock 558 237 187 minecraft:bone_block
fill 558 237 188 558 240 188 minecraft:packed_mud
setblock 558 237 192 minecraft:bone_block
fill 558 237 193 558 240 193 minecraft:packed_mud
setblock 558 237 197 minecraft:bone_block
fill 558 237 198 558 240 198 minecraft:packed_mud
setblock 558 237 212 minecraft:bone_block
fill 558 237 213 558 240 213 minecraft:packed_mud
setblock 558 237 216 minecraft:packed_mud
setblock 558 237 217 minecraft:bone_block
fill 558 237 218 558 239 219 minecraft:packed_mud
fill 518 238 182 518 238 185 minecraft:packed_mud
setblock 518 238 186 minecraft:bone_block
fill 518 238 187 518 238 190 minecraft:packed_mud
setblock 518 238 191 minecraft:bone_block
fill 518 238 192 518 241 192 minecraft:packed_mud
setblock 518 238 196 minecraft:bone_block
fill 518 238 197 518 241 197 minecraft:packed_mud
fill 518 238 209 518 238 210 minecraft:packed_mud
setblock 518 238 211 minecraft:bone_block
fill 518 238 212 518 241 212 minecraft:packed_mud
setblock 518 238 216 minecraft:bone_block
fill 518 238 217 518 241 217 minecraft:packed_mud
setblock 518 238 221 minecraft:bone_block
fill 518 238 222 518 241 222 minecraft:packed_mud
setblock 519 238 190 minecraft:bone_block
setblock 519 238 191 minecraft:packed_mud
setblock 519 238 215 minecraft:bone_block
fill 519 238 216 519 241 216 minecraft:packed_mud
setblock 519 238 219 minecraft:packed_mud
setblock 519 238 220 minecraft:bone_block
setblock 521 238 222 minecraft:packed_mud
fill 528 238 222 531 238 222 minecraft:packed_mud
fill 530 238 221 532 238 221 minecraft:packed_mud
setblock 532 238 222 minecraft:bone_block
setblock 533 238 221 minecraft:bone_block
fill 533 238 222 533 241 222 minecraft:packed_mud
fill 534 238 221 535 240 221 minecraft:packed_mud
setblock 552 238 182 minecraft:bone_block
fill 553 238 182 553 241 182 minecraft:packed_mud
fill 554 238 183 554 239 183 minecraft:packed_mud
fill 554 238 222 556 238 222 minecraft:packed_mud
setblock 555 238 189 minecraft:bone_block
fill 555 238 190 555 241 190 minecraft:packed_mud
setblock 555 238 194 minecraft:bone_block
fill 555 238 195 555 241 195 minecraft:packed_mud
setblock 556 238 183 minecraft:bone_block
setblock 556 238 188 minecraft:bone_block
fill 556 238 189 556 241 189 minecraft:packed_mud
setblock 556 238 193 minecraft:bone_block
fill 556 238 194 556 241 194 minecraft:packed_mud
setblock 556 238 197 minecraft:packed_mud
setblock 557 238 182 minecraft:bone_block
fill 557 238 183 557 241 183 minecraft:packed_mud
setblock 557 238 187 minecraft:bone_block
fill 557 238 188 557 241 188 minecraft:packed_mud
setblock 557 238 192 minecraft:bone_block
fill 557 238 193 557 241 193 minecraft:packed_mud
setblock 557 238 197 minecraft:bone_block
fill 557 238 198 557 241 198 minecraft:packed_mud
fill 557 238 213 557 240 213 minecraft:packed_mud
setblock 557 238 216 minecraft:packed_mud
setblock 557 238 217 minecraft:bone_block
setblock 557 238 222 minecraft:bone_block
fill 558 238 182 558 241 182 minecraft:packed_mud
setblock 558 238 186 minecraft:bone_block
fill 558 238 187 558 241 187 minecraft:packed_mud
setblock 558 238 191 minecraft:bone_block
fill 558 238 192 558 241 192 minecraft:packed_mud
setblock 558 238 196 minecraft:bone_block
fill 558 238 197 558 241 197 minecraft:packed_mud
setblock 558 238 211 minecraft:bone_block
fill 558 238 212 558 241 212 minecraft:packed_mud
setblock 558 238 216 minecraft:bone_block
fill 558 238 217 558 241 217 minecraft:packed_mud
setblock 558 238 220 minecraft:packed_mud
setblock 558 238 221 minecraft:bone_block
fill 558 238 222 558 241 222 minecraft:packed_mud
fill 518 239 182 518 239 184 minecraft:packed_mud
setblock 518 239 185 minecraft:bone_block
fill 518 239 186 518 239 189 minecraft:packed_mud
setblock 518 239 190 minecraft:bone_block
fill 518 239 191 518 242 191 minecraft:packed_mud
setblock 518 239 195 minecraft:bone_block
fill 518 239 196 518 242 196 minecraft:packed_mud
setblock 518 239 210 minecraft:bone_block
fill 518 239 211 518 242 211 minecraft:packed_mud
setblock 518 239 215 minecraft:bone_block
fill 518 239 216 518 242 216 minecraft:packed_mud
setblock 518 239 220 minecraft:bone_block
fill 518 239 221 519 241 221 minecraft:packed_mud
setblock 519 239 214 minecraft:bone_block
fill 519 239 215 519 242 215 minecraft:packed_mud
setblock 519 239 219 minecraft:bone_block
fill 519 239 220 519 242 220 minecraft:packed_mud
setblock 520 239 184 minecraft:light[level=11]
setblock 520 239 192 minecraft:light[level=11]
setblock 520 239 200 minecraft:light[level=11]
setblock 520 239 208 minecraft:light[level=11]
setblock 520 239 216 minecraft:light[level=11]
setblock 521 239 222 minecraft:bone_block
fill 522 239 222 525 239 222 minecraft:packed_mud
setblock 526 239 222 minecraft:bone_block
fill 527 239 222 530 239 222 minecraft:packed_mud
setblock 528 239 184 minecraft:light[level=11]
setblock 528 239 192 minecraft:light[level=11]
setblock 528 239 200 minecraft:light[level=11]
setblock 528 239 208 minecraft:light[level=11]
setblock 528 239 216 minecraft:light[level=11]
fill 528 239 221 531 239 221 minecraft:packed_mud
fill 530 239 220 532 239 220 minecraft:packed_mud
setblock 531 239 222 minecraft:bone_block
setblock 532 239 221 minecraft:bone_block
fill 532 239 222 532 242 222 minecraft:packed_mud
setblock 533 239 220 minecraft:bone_block
fill 533 239 221 533 242 221 minecraft:packed_mud
fill 534 239 220 534 242 220 minecraft:packed_mud
setblock 536 239 184 minecraft:light[level=11]
setblock 536 239 192 minecraft:light[level=11]
setblock 536 239 208 minecraft:light[level=11]
setblock 536 239 216 minecraft:light[level=11]
setblock 536 239 221 minecraft:packed_mud
setblock 536 239 222 minecraft:bone_block
fill 537 239 222 537 242 222 minecraft:packed_mud
setblock 544 239 184 minecraft:light[level=11]
setblock 544 239 192 minecraft:light[level=11]
setblock 544 239 200 minecraft:light[level=11]
setblock 544 239 208 minecraft:light[level=11]
setblock 544 239 216 minecraft:light[level=11]
setblock 550 239 182 minecraft:packed_mud
setblock 551 239 182 minecraft:bone_block
fill 552 239 182 552 242 182 minecraft:packed_mud
setblock 552 239 184 minecraft:light[level=11]
setblock 552 239 192 minecraft:light[level=11]
setblock 552 239 200 minecraft:light[level=11]
setblock 552 239 208 minecraft:light[level=11]
setblock 552 239 216 minecraft:light[level=11]
fill 552 239 222 555 239 222 minecraft:packed_mud
fill 553 239 183 553 240 183 minecraft:packed_mud
setblock 555 239 183 minecraft:bone_block
fill 555 239 189 555 240 189 minecraft:packed_mud
setblock 555 239 192 minecraft:packed_mud
setblock 555 239 193 minecraft:bone_block
fill 555 239 194 555 242 194 minecraft:packed_mud
fill 555 239 196 555 240 196 minecraft:packed_mud
setblock 556 239 182 minecraft:bone_block
fill 556 239 183 556 242 183 minecraft:packed_mud
setblock 556 239 187 minecraft:bone_block
fill 556 239 188 556 241 188 minecraft:packed_mud
setblock 556 239 192 minecraft:bone_block
fill 556 239 193 556 242 193 minecraft:packed_mud
setblock 556 239 197 minecraft:bone_block
setblock 556 239 222 minecraft:bone_block
fill 557 239 182 557 242 182 minecraft:packed_mud
setblock 557 239 186 minecraft:bone_block
fill 557 239 187 557 242 187 minecraft:packed_mud
setblock 557 239 191 minecraft:bone_block
fill 557 239 192 557 242 192 minecraft:packed_mud
setblock 557 239 196 minecraft:bone_block
fill 557 239 197 557 242 197 minecraft:packed_mud
fill 557 239 199 557 240 199 minecraft:packed_mud
setblock 557 239 216 minecraft:bone_block
fill 557 239 217 557 240 219 minecraft:packed_mud
fill 557 239 222 557 242 222 minecraft:packed_mud
setblock 558 239 185 minecraft:bone_block
fill 558 239 186 558 242 186 minecraft:packed_mud
setblock 558 239 190 minecraft:bone_block
fill 558 239 191 558 242 191 minecraft:packed_mud
setblock 558 239 195 minecraft:bone_block
fill 558 239 196 558 242 196 minecraft:packed_mud
setblock 558 239 200 minecraft:bone_block
fill 558 239 211 558 240 211 minecraft:packed_mud
setblock 558 239 215 minecraft:bone_block
fill 558 239 216 558 242 216 minecraft:packed_mud
setblock 558 239 220 minecraft:bone_block
fill 558 239 221 558 242 221 minecraft:packed_mud
fill 518 240 182 518 240 183 minecraft:packed_mud
setblock 518 240 184 minecraft:bone_block
fill 518 240 185 518 240 188 minecraft:packed_mud
setblock 518 240 189 minecraft:bone_block
fill 518 240 190 518 242 190 minecraft:packed_mud
setblock 518 240 194 minecraft:bone_block
fill 518 240 195 518 243 195 minecraft:packed_mud
setblock 518 240 198 minecraft:packed_mud
fill 518 240 210 518 241 210 minecraft:packed_mud
setblock 518 240 214 minecraft:bone_block
fill 518 240 215 518 243 215 minecraft:packed_mud
setblock 518 240 218 minecraft:packed_mud
setblock 518 240 219 minecraft:bone_block
fill 518 240 220 518 243 220 minecraft:packed_mud
setblock 519 240 213 minecraft:bone_block
fill 519 240 214 519 243 214 minecraft:packed_mud
setblock 519 240 218 minecraft:bone_block
fill 519 240 219 519 243 219 minecraft:packed_mud
setblock 520 240 221 minecraft:packed_mud
setblock 520 240 222 minecraft:bone_block
setblock 521 240 221 minecraft:bone_block
fill 521 240 222 524 240 222 minecraft:packed_mud
setblock 525 240 221 minecraft:packed_mud
setblock 525 240 222 minecraft:bone_block
setblock 526 240 221 minecraft:bone_block
fill 526 240 222 529 240 222 minecraft:packed_mud
fill 527 240 221 530 240 221 minecraft:packed_mud
fill 528 240 220 531 240 220 minecraft:packed_mud
setblock 530 240 222 minecraft:bone_block
fill 531 240 219 532 240 219 minecraft:packed_mud
setblock 531 240 221 minecraft:bone_block
fill 531 240 222 531 243 222 minecraft:packed_mud
setblock 532 240 220 minecraft:bone_block
fill 532 240 221 532 243 221 minecraft:packed_mud
fill 533 240 220 533 243 220 minecraft:packed_mud
fill 535 240 220 535 241 220 minecraft:packed_mud
setblock 535 240 222 minecraft:bone_block
setblock 536 240 221 minecraft:bone_block
fill 536 240 222 536 243 222 minecraft:packed_mud
setblock 549 240 182 minecraft:packed_mud
setblock 550 240 182 minecraft:bone_block
setblock 550 240 222 minecraft:bone_block
fill 551 240 182 551 242 183 minecraft:packed_mud
fill 551 240 222 554 240 222 minecraft:packed_mud
fill 552 240 183 552 241 183 minecraft:packed_mud
fill 552 240 221 555 240 221 minecraft:packed_mud
setblock 554 240 183 minecraft:bone_block
setblock 555 240 182 minecraft:bone_block
fill 555 240 183 555 243 183 minecraft:packed_mud
setblock 555 240 192 minecraft:bone_block
fill 555 240 193 555 243 193 minecraft:packed_mud
setblock 555 240 222 minecraft:bone_block
fill 556 240 182 556 243 182 minecraft:packed_mud
fill 556 240 187 556 241 187 minecraft:packed_mud
setblock 556 240 191 minecraft:bone_block
fill 556 240 192 556 243 192 minecraft:packed_mud
setblock 556 240 196 minecraft:bone_block
fill 556 240 197 556 242 198 minecraft:packed_mud
setblock 556 240 221 minecraft:bone_block
fill 556 240 222 556 243 222 minecraft:packed_mud
setblock 557 240 185 minecraft:bone_block
fill 557 240 186 557 242 186 minecraft:packed_mud
setblock 557 240 190 minecraft:bone_block
fill 557 240 191 557 243 191 minecraft:packed_mud
setblock 557 240 195 minecraft:bone_block
fill 557 240 196 557 243 196 minecraft:packed_mud
setblock 557 240 214 minecraft:packed_mud
setblock 557 240 215 minecraft:bone_block
fill 557 240 216 557 243 216 minecraft:packed_mud
setblock 557 240 220 minecraft:bone_block
fill 557 240 221 557 243 221 minecraft:packed_mud
setblock 558 240 184 minecraft:bone_block
fill 558 240 185 558 243 185 minecraft:packed_mud
setblock 558 240 189 minecraft:bone_block
fill 558 240 190 558 243 190 minecraft:packed_mud
setblock 558 240 194 minecraft:bone_block
fill 558 240 195 558 243 195 minecraft:packed_mud
setblock 558 240 199 minecraft:bone_block
fill 558 240 200 558 243 200 minecraft:packed_mud
setblock 558 240 214 minecraft:bone_block
fill 558 240 215 558 243 215 minecraft:packed_mud
setblock 558 240 218 minecraft:packed_mud
setblock 558 240 219 minecraft:bone_block
fill 558 240 220 558 243 220 minecraft:packed_mud
setblock 518 241 182 minecraft:packed_mud
setblock 518 241 183 minecraft:bone_block
fill 518 241 184 518 241 187 minecraft:packed_mud
setblock 518 241 188 minecraft:bone_block
fill 518 241 189 518 242 189 minecraft:packed_mud
setblock 518 241 193 minecraft:bone_block
fill 518 241 194 518 244 194 minecraft:packed_mud
setblock 518 241 198 minecraft:bone_block
setblock 518 241 213 minecraft:bone_block
fill 518 241 214 518 244 214 minecraft:packed_mud
setblock 518 241 218 minecraft:bone_block
fill 518 241 219 518 244 219 minecraft:packed_mud
setblock 519 241 182 minecraft:bone_block
fill 519 241 213 519 242 213 minecraft:packed_mud
setblock 519 241 217 minecraft:bone_block
fill 519 241 218 520 243 218 minecraft:packed_mud
setblock 519 241 222 minecraft:bone_block
setblock 520 241 216 minecraft:bone_block
fill 520 241 217 520 243 217 minecraft:packed_mud
setblock 520 241 221 minecraft:bone_block
fill 520 241 222 523 241 222 minecraft:packed_mud
fill 521 241 221 524 241 221 minecraft:packed_mud
setblock 524 241 222 minecraft:bone_block
setblock 525 241 221 minecraft:bone_block
fill 525 241 222 528 241 222 minecraft:packed_mud
setblock 526 241 220 minecraft:bone_block
fill 526 241 221 529 241 221 minecraft:packed_mud
fill 527 241 220 530 241 220 minecraft:packed_mud
fill 529 241 219 531 241 219 minecraft:packed_mud
setblock 529 241 222 minecraft:bone_block
fill 530 241 182 533 241 182 minecraft:packed_mud
setblock 530 241 221 minecraft:bone_block
fill 530 241 222 530 244 222 minecraft:packed_mud
setblock 531 241 220 minecraft:bone_block
fill 531 241 221 531 244 221 minecraft:packed_mud
setblock 532 241 219 minecraft:bone_block
fill 532 241 220 532 244 220 minecraft:packed_mud
fill 533 241 219 533 244 219 minecraft:packed_mud
setblock 534 241 221 minecraft:packed_mud
setblock 534 241 222 minecraft:bone_block
setblock 535 241 221 minecraft:bone_block
fill 535 241 222 535 244 222 minecraft:packed_mud
fill 536 241 221 536 244 221 minecraft:packed_mud
setblock 538 241 222 minecraft:packed_mud
setblock 548 241 182 minecraft:packed_mud
setblock 548 241 222 minecraft:packed_mud
setblock 549 241 182 minecraft:bone_block
setblock 549 241 222 minecraft:bone_block
fill 550 241 182 550 243 183 minecraft:packed_mud
setblock 550 241 221 minecraft:bone_block
fill 550 241 222 553 241 222 minecraft:packed_mud
fill 551 241 221 554 241 221 minecraft:packed_mud
setblock 553 241 183 minecraft:bone_block
setblock 554 241 182 minecraft:bone_block
fill 554 241 183 554 244 183 minecraft:packed_mud
setblock 554 241 222 minecraft:bone_block
fill 555 241 182 555 244 182 minecraft:packed_mud
setblock 555 241 191 minecraft:bone_block
fill 555 241 192 555 242 192 minecraft:packed_mud
setblock 555 241 196 minecraft:bone_block
fill 555 241 197 555 242 197 minecraft:packed_mud
setblock 555 241 221 minecraft:bone_block
fill 555 241 222 555 244 222 minecraft:packed_mud
setblock 556 241 190 minecraft:bone_block
fill 556 241 191 556 243 191 minecraft:packed_mud
setblock 556 241 195 minecraft:bone_block
fill 556 241 196 556 244 196 minecraft:packed_mud
fill 556 241 221 556 244 221 minecraft:packed_mud
setblock 557 241 184 minecraft:bone_block
fill 557 241 185 557 242 185 minecraft:packed_mud
setblock 557 241 189 minecraft:bone_block
fill 557 241 190 557 243 190 minecraft:packed_mud
setblock 557 241 194 minecraft:bone_block
fill 557 241 195 557 244 195 minecraft:packed_mud
setblock 557 241 199 minecraft:bone_block
setblock 557 241 214 minecraft:bone_block
fill 557 241 215 557 243 215 minecraft:packed_mud
fill 557 241 217 557 241 218 minecraft:packed_mud
setblock 557 241 219 minecraft:bone_block
fill 557 241 220 557 244 220 minecraft:packed_mud
setblock 558 241 183 minecraft:bone_block
fill 558 241 184 558 244 184 minecraft:packed_mud
setblock 558 241 188 minecraft:bone_block
fill 558 241 189 558 244 189 minecraft:packed_mud
setblock 558 241 193 minecraft:bone_block
fill 558 241 194 558 244 194 minecraft:packed_mud
setblock 558 241 198 minecraft:bone_block
fill 558 241 199 558 244 199 minecraft:packed_mud
fill 558 241 201 558 242 201 minecraft:packed_mud
setblock 558 241 213 minecraft:bone_block
fill 558 241 214 558 244 214 minecraft:packed_mud
setblock 558 241 218 minecraft:bone_block
fill 558 241 219 558 244 219 minecraft:packed_mud
setblock 518 242 182 minecraft:bone_block
fill 518 242 183 518 242 184 minecraft:packed_mud
setblock 518 242 192 minecraft:bone_block
fill 518 242 193 518 243 193 minecraft:packed_mud
setblock 518 242 197 minecraft:bone_block
fill 518 242 198 518 244 199 minecraft:packed_mud
setblock 518 242 212 minecraft:bone_block
fill 518 242 213 518 245 213 minecraft:packed_mud
setblock 518 242 217 minecraft:bone_block
fill 518 242 218 518 245 218 minecraft:packed_mud
setblock 518 242 221 minecraft:packed_mud
setblock 518 242 222 minecraft:bone_block
fill 519 242 182 519 244 182 minecraft:packed_mud
setblock 519 242 216 minecraft:bone_block
fill 519 242 217 519 245 217 minecraft:packed_mud
setblock 519 242 221 minecraft:bone_block
fill 519 242 222 522 242 222 minecraft:packed_mud
setblock 520 242 216 minecraft:packed_mud
setblock 520 242 219 minecraft:packed_mud
fill 520 242 221 523 242 221 minecraft:packed_mud
setblock 523 242 222 minecraft:bone_block
setblock 524 242 220 minecraft:packed_mud
setblock 524 242 221 minecraft:bone_block
fill 524 242 222 527 242 222 minecraft:packed_mud
setblock 525 242 220 minecraft:bone_block
fill 525 242 221 528 242 221 minecraft:packed_mud
fill 526 242 220 529 242 220 minecraft:packed_mud
fill 527 242 219 530 242 219 minecraft:packed_mud
setblock 528 242 182 minecraft:bone_block
setblock 528 242 222 minecraft:bone_block
fill 529 242 182 532 242 182 minecraft:packed_mud
setblock 529 242 221 minecraft:bone_block
fill 529 242 222 529 245 222 minecraft:packed_mud
setblock 530 242 220 minecraft:bone_block
fill 530 242 221 530 245 221 minecraft:packed_mud
setblock 531 242 219 minecraft:bone_block
fill 531 242 220 531 245 220 minecraft:packed_mud
fill 532 242 219 532 244 219 minecraft:packed_mud
setblock 533 242 182 minecraft:bone_block
setblock 533 242 222 minecraft:bone_block
fill 534 242 182 534 244 182 minecraft:packed_mud
setblock 534 242 219 minecraft:packed_mud
setblock 534 242 221 minecraft:bone_block
fill 534 242 222 534 245 222 minecraft:packed_mud
setblock 535 242 220 minecraft:bone_block
fill 535 242 221 535 245 221 minecraft:packed_mud
setblock 538 242 222 minecraft:bone_block
setblock 547 242 182 minecraft:packed_mud
setblock 547 242 222 minecraft:packed_mud
setblock 548 242 182 minecraft:bone_block
setblock 548 242 222 minecraft:bone_block
fill 549 242 182 549 244 183 minecraft:packed_mud
setblock 549 242 221 minecraft:bone_block
fill 549 242 222 552 242 222 minecraft:packed_mud
fill 550 242 221 553 242 221 minecraft:packed_mud
fill 551 242 220 554 242 220 minecraft:packed_mud
setblock 552 242 183 minecraft:bone_block
setblock 553 242 182 minecraft:bone_block
fill 553 242 183 553 244 184 minecraft:packed_mud
setblock 553 242 222 minecraft:bone_block
fill 554 242 182 554 245 182 minecraft:packed_mud
setblock 554 242 221 minecraft:bone_block
fill 554 242 222 554 245 222 minecraft:packed_mud
setblock 555 242 191 minecraft:packed_mud
setblock 555 242 195 minecraft:bone_block
fill 555 242 196 555 243 196 minecraft:packed_mud
setblock 555 242 220 minecraft:bone_block
fill 555 242 221 555 245 221 minecraft:packed_mud
setblock 556 242 189 minecraft:bone_block
setblock 556 242 190 minecraft:packed_mud
setblock 556 242 194 minecraft:bone_block
fill 556 242 195 556 244 195 minecraft:packed_mud
setblock 556 242 218 minecraft:packed_mud
setblock 556 242 219 minecraft:bone_block
setblock 557 242 183 minecraft:bone_block
fill 557 242 184 557 243 184 minecraft:packed_mud
setblock 557 242 188 minecraft:bone_block
fill 557 242 189 557 243 189 minecraft:packed_mud
setblock 557 242 193 minecraft:bone_block
fill 557 242 194 557 245 194 minecraft:packed_mud
setblock 557 242 198 minecraft:bone_block
fill 557 242 199 557 244 199 minecraft:packed_mud
setblock 557 242 214 minecraft:packed_mud
setblock 557 242 217 minecraft:packed_mud
setblock 557 242 218 minecraft:bone_block
fill 557 242 219 557 245 219 minecraft:packed_mud
setblock 558 242 182 minecraft:bone_block
fill 558 242 183 558 245 183 minecraft:packed_mud
setblock 558 242 187 minecraft:bone_block
fill 558 242 188 558 244 188 minecraft:packed_mud
setblock 558 242 192 minecraft:bone_block
fill 558 242 193 558 245 193 minecraft:packed_mud
setblock 558 242 197 minecraft:bone_block
fill 558 242 198 558 245 198 minecraft:packed_mud
setblock 558 242 212 minecraft:bone_block
fill 558 242 213 558 243 213 minecraft:packed_mud
setblock 558 242 217 minecraft:bone_block
fill 558 242 218 558 245 218 minecraft:packed_mud
setblock 558 242 222 minecraft:bone_block
fill 518 243 182 518 243 183 minecraft:packed_mud
setblock 518 243 191 minecraft:bone_block
setblock 518 243 192 minecraft:packed_mud
setblock 518 243 196 minecraft:bone_block
fill 518 243 197 518 244 197 minecraft:packed_mud
setblock 518 243 211 minecraft:bone_block
fill 518 243 212 518 244 212 minecraft:packed_mud
setblock 518 243 216 minecraft:bone_block
fill 518 243 217 518 246 217 minecraft:packed_mud
setblock 518 243 221 minecraft:bone_block
fill 518 243 222 521 243 222 minecraft:packed_mud
setblock 519 243 215 minecraft:bone_block
fill 519 243 216 519 245 216 minecraft:packed_mud
setblock 519 243 220 minecraft:bone_block
fill 519 243 221 522 243 221 minecraft:packed_mud
setblock 520 243 219 minecraft:bone_block
fill 520 243 220 523 243 220 minecraft:packed_mud
setblock 522 243 222 minecraft:bone_block
setblock 523 243 221 minecraft:bone_block
fill 523 243 222 526 243 222 minecraft:packed_mud
setblock 524 243 220 minecraft:bone_block
fill 524 243 221 527 243 221 minecraft:packed_mud
fill 525 243 220 528 243 220 minecraft:packed_mud
fill 526 243 219 529 243 219 minecraft:packed_mud
setblock 527 243 182 minecraft:bone_block
setblock 527 243 222 minecraft:bone_block
fill 528 243 182 531 243 182 minecraft:packed_mud
setblock 528 243 221 minecraft:bone_block
fill 528 243 222 528 246 222 minecraft:packed_mud
setblock 529 243 220 minecraft:bone_block
fill 529 243 221 529 246 221 minecraft:packed_mud
setblock 530 243 219 minecraft:bone_block
fill 530 243 220 530 246 220 minecraft:packed_mud
fill 531 243 219 531 245 219 minecraft:packed_mud
setblock 532 243 182 minecraft:bone_block
setblock 532 243 222 minecraft:bone_block
fill 533 243 182 533 246 182 minecraft:packed_mud
setblock 533 243 221 minecraft:bone_block
fill 533 243 222 533 246 222 minecraft:packed_mud
setblock 534 243 220 minecraft:bone_block
fill 534 243 221 534 246 221 minecraft:packed_mud
setblock 535 243 220 minecraft:packed_mud
setblock 537 243 222 minecraft:bone_block
fill 538 243 222 538 244 222 minecraft:packed_mud
setblock 546 243 182 minecraft:packed_mud
setblock 546 243 222 minecraft:packed_mud
setblock 547 243 182 minecraft:bone_block
setblock 547 243 222 minecraft:bone_block
fill 548 243 182 548 245 183 minecraft:packed_mud
setblock 548 243 221 minecraft:bone_block
fill 548 243 222 551 243 222 minecraft:packed_mud
fill 549 243 221 552 243 221 minecraft:packed_mud
fill 550 243 220 553 243 220 minecraft:packed_mud
setblock 551 243 182 minecraft:packed_mud
setblock 551 243 183 minecraft:bone_block
setblock 552 243 182 minecraft:bone_block
fill 552 243 183 552 245 184 minecraft:packed_mud
setblock 552 243 222 minecraft:bone_block
fill 553 243 182 553 246 182 minecraft:packed_mud
setblock 553 243 221 minecraft:bone_block
fill 553 243 222 553 246 222 minecraft:packed_mud
setblock 554 243 220 minecraft:bone_block
fill 554 243 221 554 246 221 minecraft:packed_mud
setblock 555 243 194 minecraft:bone_block
setblock 555 243 195 minecraft:packed_mud
fill 555 243 220 556 243 220 minecraft:packed_mud
setblock 556 243 183 minecraft:bone_block
setblock 556 243 193 minecraft:bone_block
fill 556 243 194 556 244 194 minecraft:packed_mud
setblock 556 243 197 minecraft:packed_mud
setblock 556 243 198 minecraft:bone_block
setblock 556 243 219 minecraft:packed_mud
setblock 557 243 182 minecraft:bone_block
fill 557 243 183 557 244 183 minecraft:packed_mud
setblock 557 243 187 minecraft:bone_block
setblock 557 243 188 minecraft:packed_mud
setblock 557 243 192 minecraft:bone_block
fill 557 243 193 557 244 193 minecraft:packed_mud
setblock 557 243 197 minecraft:bone_block
fill 557 243 198 557 245 198 minecraft:packed_mud
setblock 557 243 217 minecraft:bone_block
fill 557 243 218 557 245 218 minecraft:packed_mud
setblock 557 243 222 minecraft:bone_block
fill 558 243 182 558 246 182 minecraft:packed_mud
setblock 558 243 186 minecraft:bone_block
fill 558 243 187 558 244 187 minecraft:packed_mud
setblock 558 243 191 minecraft:bone_block
fill 558 243 192 558 245 192 minecraft:packed_mud
setblock 558 243 196 minecraft:bone_block
fill 558 243 197 558 246 197 minecraft:packed_mud
setblock 558 243 201 minecraft:bone_block
setblock 558 243 216 minecraft:bone_block
fill 558 243 217 558 246 217 minecraft:packed_mud
setblock 558 243 221 minecraft:bone_block
fill 558 243 222 558 246 222 minecraft:packed_mud
fill 518 244 182 518 246 182 minecraft:packed_mud
setblock 518 244 195 minecraft:bone_block
setblock 518 244 196 minecraft:packed_mud
setblock 518 244 215 minecraft:bone_block
fill 518 244 216 518 247 216 minecraft:packed_mud
setblock 518 244 220 minecraft:bone_block
fill 518 244 221 520 244 222 minecraft:packed_mud
setblock 519 244 214 minecraft:bone_block
fill 519 244 215 519 245 215 minecraft:packed_mud
setblock 519 244 218 minecraft:packed_mud
setblock 519 244 219 minecraft:bone_block
fill 519 244 220 522 244 220 minecraft:packed_mud
setblock 520 244 218 minecraft:bone_block
setblock 520 244 219 minecraft:packed_mud
setblock 521 244 221 minecraft:packed_mud
setblock 521 244 222 minecraft:bone_block
setblock 522 244 221 minecraft:bone_block
fill 522 244 222 525 244 222 minecraft:packed_mud
setblock 523 244 220 minecraft:bone_block
fill 523 244 221 526 244 221 minecraft:packed_mud
fill 524 244 220 527 244 220 minecraft:packed_mud
setblock 526 244 182 minecraft:bone_block
fill 526 244 219 528 244 219 minecraft:packed_mud
setblock 526 244 222 minecraft:bone_block
fill 527 244 182 530 244 182 minecraft:packed_mud
setblock 527 244 221 minecraft:bone_block
fill 527 244 222 527 247 222 minecraft:packed_mud
setblock 528 244 220 minecraft:bone_block
fill 528 244 221 528 247 221 minecraft:packed_mud
setblock 529 244 219 minecraft:bone_block
fill 529 244 220 529 247 220 minecraft:packed_mud
fill 530 244 219 530 246 219 minecraft:packed_mud
setblock 531 244 182 minecraft:bone_block
setblock 531 244 222 minecraft:bone_block
fill 532 244 182 532 247 182 minecraft:packed_mud
setblock 532 244 221 minecraft:bone_block
fill 532 244 222 532 247 222 minecraft:packed_mud
setblock 533 244 220 minecraft:bone_block
fill 533 244 221 533 247 221 minecraft:packed_mud
fill 534 244 220 534 245 220 minecraft:packed_mud
setblock 536 244 222 minecraft:bone_block
fill 537 244 222 537 245 222 minecraft:packed_mud
setblock 545 244 182 minecraft:packed_mud
setblock 545 244 222 minecraft:packed_mud
setblock 546 244 182 minecraft:bone_block
setblock 546 244 222 minecraft:bone_block
fill 547 244 182 547 247 182 minecraft:packed_mud
setblock 547 244 221 minecraft:bone_block
fill 547 244 222 550 244 222 minecraft:packed_mud
fill 548 244 221 551 244 221 minecraft:packed_mud
fill 549 244 220 552 244 220 minecraft:packed_mud
setblock 550 244 182 minecraft:packed_mud
setblock 550 244 183 minecraft:bone_block
setblock 551 244 182 minecraft:bone_block
fill 551 244 183 551 246 184 minecraft:packed_mud
setblock 551 244 222 minecraft:bone_block
fill 552 244 182 552 247 182 minecraft:packed_mud
setblock 552 244 221 minecraft:bone_block
fill 552 244 222 552 247 222 minecraft:packed_mud
setblock 553 244 220 minecraft:bone_block
fill 553 244 221 553 247 221 minecraft:packed_mud
fill 554 244 220 555 244 220 minecraft:packed_mud
setblock 555 244 183 minecraft:bone_block
setblock 556 244 182 minecraft:bone_block
fill 556 244 183 556 246 183 minecraft:packed_mud
setblock 556 244 193 minecraft:packed_mud
setblock 556 244 197 minecraft:bone_block
setblock 556 244 222 minecraft:bone_block
fill 557 244 182 557 247 182 minecraft:packed_mud
setblock 557 244 191 minecraft:bone_block
setblock 557 244 192 minecraft:packed_mud
setblock 557 244 196 minecraft:bone_block
fill 557 244 197 557 245 197 minecraft:packed_mud
setblock 557 244 216 minecraft:bone_block
setblock 557 244 217 minecraft:packed_mud
setblock 557 244 221 minecraft:bone_block
fill 557 244 222 557 247 222 minecraft:packed_mud
setblock 558 244 185 minecraft:bone_block
setblock 558 244 186 minecraft:packed_mud
setblock 558 244 190 minecraft:bone_block
fill 558 244 191 558 245 191 minecraft:packed_mud
setblock 558 244 195 minecraft:bone_block
fill 558 244 196 558 246 196 minecraft:packed_mud
setblock 558 244 200 minecraft:bone_block
setblock 558 244 215 minecraft:bone_block
fill 558 244 216 558 246 216 minecraft:packed_mud
setblock 558 244 220 minecraft:bone_block
fill 558 244 221 558 247 221 minecraft:packed_mud
setblock 518 245 214 minecraft:bone_block
fill 518 245 215 518 247 215 minecraft:packed_mud
setblock 518 245 219 minecraft:bone_block
fill 518 245 220 519 245 222 minecraft:packed_mud
setblock 519 245 218 minecraft:bone_block
fill 519 245 219 519 248 219 minecraft:packed_mud
setblock 520 245 221 minecraft:packed_mud
setblock 520 245 222 minecraft:bone_block
setblock 521 245 221 minecraft:bone_block
fill 521 245 222 524 245 222 minecraft:packed_mud
setblock 522 245 220 minecraft:bone_block
fill 522 245 221 525 245 221 minecraft:packed_mud
fill 523 245 220 526 245 220 minecraft:packed_mud
setblock 525 245 182 minecraft:bone_block
setblock 525 245 222 minecraft:bone_block
fill 526 245 182 529 245 182 minecraft:packed_mud
fill 526 245 219 527 245 219 minecraft:packed_mud
setblock 526 245 221 minecraft:bone_block
fill 526 245 222 526 248 222 minecraft:packed_mud
setblock 527 245 220 minecraft:bone_block
fill 527 245 221 527 248 221 minecraft:packed_mud
setblock 528 245 219 minecraft:bone_block
fill 528 245 220 528 248 220 minecraft:packed_mud
fill 529 245 219 529 246 219 minecraft:packed_mud
setblock 530 245 182 minecraft:bone_block
setblock 530 245 222 minecraft:bone_block
fill 531 245 182 531 248 182 minecraft:packed_mud
setblock 531 245 221 minecraft:bone_block
fill 531 245 222 531 248 222 minecraft:packed_mud
setblock 532 245 220 minecraft:bone_block
fill 532 245 221 532 248 221 minecraft:packed_mud
fill 533 245 220 533 246 220 minecraft:packed_mud
setblock 535 245 222 minecraft:bone_block
fill 536 245 222 536 246 222 minecraft:packed_mud
setblock 544 245 222 minecraft:packed_mud
setblock 545 245 182 minecraft:bone_block
setblock 545 245 222 minecraft:bone_block
fill 546 245 182 546 248 182 minecraft:packed_mud
setblock 546 245 221 minecraft:bone_block
fill 546 245 222 549 245 222 minecraft:packed_mud
fill 547 245 183 547 246 183 minecraft:packed_mud
fill 547 245 221 550 245 221 minecraft:packed_mud
setblock 549 245 182 minecraft:packed_mud
setblock 549 245 183 minecraft:bone_block
fill 549 245 220 551 245 220 minecraft:packed_mud
setblock 550 245 182 minecraft:bone_block
fill 550 245 183 550 247 184 minecraft:packed_mud
setblock 550 245 222 minecraft:bone_block
fill 551 245 182 551 248 182 minecraft:packed_mud
setblock 551 245 221 minecraft:bone_block
fill 551 245 222 551 248 222 minecraft:packed_mud
setblock 552 245 220 minecraft:bone_block
fill 552 245 221 552 248 221 minecraft:packed_mud
setblock 553 245 183 minecraft:packed_mud
fill 553 245 220 554 245 220 minecraft:packed_mud
setblock 554 245 183 minecraft:bone_block
setblock 555 245 182 minecraft:bone_block
fill 555 245 183 555 248 183 minecraft:packed_mud
setblock 555 245 222 minecraft:bone_block
fill 556 245 182 556 248 182 minecraft:packed_mud
setblock 556 245 221 minecraft:bone_block
fill 556 245 222 556 248 222 minecraft:packed_mud
setblock 557 245 195 minecraft:bone_block
setblock 557 245 196 minecraft:packed_mud
setblock 557 245 220 minecraft:bone_block
fill 557 245 221 557 247 221 minecraft:packed_mud
setblock 558 245 184 minecraft:bone_block
setblock 558 245 185 minecraft:packed_mud
setblock 558 245 194 minecraft:bone_block
fill 558 245 195 558 246 195 minecraft:packed_mud
setblock 558 245 199 minecraft:bone_block
setblock 558 245 200 minecraft:packed_mud
setblock 558 245 215 minecraft:packed_mud
setblock 558 245 219 minecraft:bone_block
fill 558 245 220 558 248 220 minecraft:packed_mud
setblock 518 246 214 minecraft:packed_mud
setblock 518 246 218 minecraft:bone_block
fill 518 246 219 518 246 222 minecraft:packed_mud
setblock 519 246 217 minecraft:bone_block
fill 519 246 218 519 247 218 minecraft:packed_mud
fill 519 246 220 519 246 221 minecraft:packed_mud
setblock 519 246 222 minecraft:bone_block
setblock 520 246 221 minecraft:bone_block
fill 520 246 222 523 246 222 minecraft:packed_mud
fill 521 246 221 524 246 221 minecraft:packed_mud
fill 523 246 220 525 246 220 minecraft:packed_mud
setblock 524 246 182 minecraft:bone_block
setblock 524 246 222 minecraft:bone_block
fill 525 246 182 528 246 182 minecraft:packed_mud
setblock 525 246 221 minecraft:bone_block
fill 525 246 222 525 249 222 minecraft:packed_mud
setblock 526 246 220 minecraft:bone_block
fill 526 246 221 526 249 221 minecraft:packed_mud
setblock 527 246 219 minecraft:bone_block
fill 527 246 220 527 249 220 minecraft:packed_mud
setblock 528 246 219 minecraft:packed_mud
setblock 529 246 182 minecraft:bone_block
setblock 529 246 222 minecraft:bone_block
fill 530 246 182 530 249 182 minecraft:packed_mud
setblock 530 246 221 minecraft:bone_block
fill 530 246 222 530 249 222 minecraft:packed_mud
setblock 531 246 220 minecraft:bone_block
fill 531 246 221 531 249 221 minecraft:packed_mud
setblock 532 246 220 minecraft:packed_mud
setblock 534 246 222 minecraft:bone_block
fill 535 246 222 535 247 222 minecraft:packed_mud
setblock 544 246 182 minecraft:bone_block
setblock 544 246 222 minecraft:bone_block
fill 545 246 182 545 249 182 minecraft:packed_mud
fill 545 246 222 548 246 222 minecraft:packed_mud
fill 546 246 183 546 247 183 minecraft:packed_mud
fill 546 246 221 549 246 221 minecraft:packed_mud
setblock 548 246 182 minecraft:packed_mud
setblock 548 246 183 minecraft:bone_block
setblock 549 246 182 minecraft:bone_block
fill 549 246 183 549 249 183 minecraft:packed_mud
fill 549 246 220 550 246 220 minecraft:packed_mud
setblock 549 246 222 minecraft:bone_block
fill 550 246 182 550 249 182 minecraft:packed_mud
setblock 550 246 221 minecraft:bone_block
fill 550 246 222 550 249 222 minecraft:packed_mud
setblock 551 246 220 minecraft:bone_block
fill 551 246 221 551 249 221 minecraft:packed_mud
setblock 552 246 183 minecraft:packed_mud
fill 552 246 220 553 246 220 minecraft:packed_mud
setblock 553 246 183 minecraft:bone_block
setblock 554 246 182 minecraft:bone_block
fill 554 246 183 554 249 183 minecraft:packed_mud
setblock 554 246 222 minecraft:bone_block
fill 555 246 182 555 249 182 minecraft:packed_mud
setblock 555 246 221 minecraft:bone_block
fill 555 246 222 555 249 222 minecraft:packed_mud
fill 556 246 221 556 248 221 minecraft:packed_mud
setblock 557 246 219 minecraft:bone_block
fill 557 246 220 557 247 220 minecraft:packed_mud
setblock 558 246 183 minecraft:bone_block
fill 558 246 184 558 247 184 minecraft:packed_mud
setblock 558 246 198 minecraft:bone_block
setblock 558 246 199 minecraft:packed_mud
setblock 558 246 218 minecraft:bone_block
fill 558 246 219 558 249 219 minecraft:packed_mud
setblock 518 247 217 minecraft:bone_block
fill 518 247 218 518 247 221 minecraft:packed_mud
setblock 518 247 222 minecraft:bone_block
setblock 519 247 220 minecraft:packed_mud
setblock 519 247 221 minecraft:bone_block
fill 519 247 222 522 247 222 minecraft:packed_mud
setblock 520 247 184 minecraft:light[level=11]
setblock 520 247 192 minecraft:light[level=11]
setblock 520 247 200 minecraft:light[level=11]
setblock 520 247 208 minecraft:light[level=11]
setblock 520 247 216 minecraft:light[level=11]
fill 520 247 221 523 247 221 minecraft:packed_mud
fill 523 247 220 524 247 220 minecraft:packed_mud
setblock 523 247 222 minecraft:bone_block
fill 524 247 182 527 247 182 minecraft:packed_mud
setblock 524 247 221 minecraft:bone_block
fill 524 247 222 524 250 222 minecraft:packed_mud
setblock 525 247 220 minecraft:bone_block
fill 525 247 221 525 250 221 minecraft:packed_mud
fill 526 247 220 526 250 220 minecraft:packed_mud
setblock 528 247 182 minecraft:bone_block
setblock 528 247 184 minecraft:light[level=11]
setblock 528 247 192 minecraft:light[level=11]
setblock 528 247 200 minecraft:light[level=11]
setblock 528 247 208 minecraft:light[level=11]
setblock 528 247 216 minecraft:light[level=11]
setblock 528 247 222 minecraft:bone_block
fill 529 247 182 529 250 182 minecraft:packed_mud
setblock 529 247 221 minecraft:bone_block
fill 529 247 222 529 250 222 minecraft:packed_mud
setblock 530 247 220 minecraft:bone_block
fill 530 247 221 530 250 221 minecraft:packed_mud
setblock 531 247 220 minecraft:packed_mud
setblock 533 247 222 minecraft:bone_block
fill 534 247 222 534 248 222 minecraft:packed_mud
setblock 536 247 184 minecraft:light[level=11]
setblock 536 247 192 minecraft:light[level=11]
setblock 536 247 208 minecraft:light[level=11]
setblock 536 247 216 minecraft:light[level=11]
setblock 543 247 182 minecraft:bone_block
fill 544 247 182 544 250 182 minecraft:packed_mud
setblock 544 247 184 minecraft:light[level=11]
setblock 544 247 192 minecraft:light[level=11]
setblock 544 247 200 minecraft:light[level=11]
setblock 544 247 208 minecraft:light[level=11]
setblock 544 247 216 minecraft:light[level=11]
fill 544 247 222 547 247 222 minecraft:packed_mud
fill 546 247 221 548 247 221 minecraft:packed_mud
setblock 547 247 183 minecraft:bone_block
setblock 548 247 182 minecraft:bone_block
fill 548 247 183 548 250 183 minecraft:packed_mud
setblock 548 247 222 minecraft:bone_block
fill 549 247 182 549 250 182 minecraft:packed_mud
setblock 549 247 221 minecraft:bone_block
fill 549 247 222 549 250 222 minecraft:packed_mud
fill 550 247 221 550 250 221 minecraft:packed_mud
setblock 551 247 183 minecraft:packed_mud
setblock 552 247 183 minecraft:bone_block
setblock 552 247 184 minecraft:light[level=11]
setblock 552 247 192 minecraft:light[level=11]
setblock 552 247 200 minecraft:light[level=11]
setblock 552 247 208 minecraft:light[level=11]
setblock 552 247 216 minecraft:light[level=11]
setblock 553 247 182 minecraft:bone_block
fill 553 247 183 553 250 183 minecraft:packed_mud
setblock 553 247 222 minecraft:bone_block
fill 554 247 182 554 250 182 minecraft:packed_mud
setblock 554 247 221 minecraft:bone_block
fill 554 247 222 554 250 222 minecraft:packed_mud
fill 555 247 221 555 248 221 minecraft:packed_mud
setblock 558 247 182 minecraft:bone_block
fill 558 247 183 558 250 183 minecraft:packed_mud
setblock 558 247 217 minecraft:bone_block
fill 558 247 218 558 248 218 minecraft:packed_mud
setblock 558 247 222 minecraft:bone_block
setblock 518 248 216 minecraft:bone_block
fill 518 248 217 518 248 220 minecraft:packed_mud
setblock 518 248 221 minecraft:bone_block
fill 518 248 222 521 248 222 minecraft:packed_mud
setblock 519 248 220 minecraft:bone_block
fill 519 248 221 522 248 221 minecraft:packed_mud
setblock 522 248 222 minecraft:bone_block
fill 523 248 182 526 248 182 minecraft:packed_mud
setblock 523 248 221 minecraft:bone_block
fill 523 248 222 523 251 222 minecraft:packed_mud
setblock 524 248 220 minecraft:bone_block
fill 524 248 221 524 251 221 minecraft:packed_mud
fill 525 248 220 525 250 220 minecraft:packed_mud
setblock 527 248 182 minecraft:bone_block
setblock 527 248 222 minecraft:bone_block
fill 528 248 182 528 251 182 minecraft:packed_mud
setblock 528 248 221 minecraft:bone_block
fill 528 248 222 528 251 222 minecraft:packed_mud
setblock 529 248 220 minecraft:bone_block
fill 529 248 221 529 251 221 minecraft:packed_mud
setblock 530 248 220 minecraft:packed_mud
setblock 532 248 182 minecraft:bone_block
setblock 532 248 222 minecraft:bone_block
fill 533 248 222 533 250 222 minecraft:packed_mud
fill 539 248 189 540 249 190 minecraft:bone_block
fill 543 248 182 543 251 182 minecraft:packed_mud
fill 543 248 222 546 248 222 minecraft:packed_mud
setblock 545 248 183 minecraft:packed_mud
setblock 546 248 183 minecraft:bone_block
fill 546 248 221 547 248 221 minecraft:packed_mud
setblock 547 248 182 minecraft:bone_block
fill 547 248 183 547 251 183 minecraft:packed_mud
setblock 547 248 222 minecraft:bone_block
fill 548 248 182 548 251 182 minecraft:packed_mud
setblock 548 248 221 minecraft:bone_block
fill 548 248 222 548 251 222 minecraft:packed_mud
setblock 549 248 184 minecraft:packed_mud
fill 549 248 221 549 251 221 minecraft:packed_mud
setblock 550 248 183 minecraft:packed_mud
setblock 550 248 184 minecraft:bone_block
setblock 551 248 183 minecraft:bone_block
setblock 552 248 182 minecraft:bone_block
fill 552 248 183 552 251 183 minecraft:packed_mud
setblock 552 248 222 minecraft:bone_block
fill 553 248 182 553 251 182 minecraft:packed_mud
setblock 553 248 221 minecraft:bone_block
fill 553 248 222 553 251 222 minecraft:packed_mud
fill 554 248 221 554 249 221 minecraft:packed_mud
setblock 557 248 182 minecraft:bone_block
setblock 557 248 222 minecraft:bone_block
fill 558 248 182 558 251 182 minecraft:packed_mud
setblock 558 248 221 minecraft:bone_block
fill 558 248 222 558 251 222 minecraft:packed_mud
fill 518 249 217 518 249 219 minecraft:packed_mud
setblock 518 249 220 minecraft:bone_block
fill 518 249 221 520 249 222 minecraft:packed_mud
setblock 519 249 220 minecraft:packed_mud
setblock 521 249 221 minecraft:packed_mud
setblock 521 249 222 minecraft:bone_block
setblock 522 249 221 minecraft:bone_block
fill 522 249 222 522 252 222 minecraft:packed_mud
fill 523 249 182 525 249 182 minecraft:packed_mud
fill 523 249 221 523 252 221 minecraft:packed_mud
setblock 524 249 220 minecraft:packed_mud
setblock 526 249 182 minecraft:bone_block
setblock 526 249 222 minecraft:bone_block
fill 527 249 182 527 252 182 minecraft:packed_mud
setblock 527 249 221 minecraft:bone_block
fill 527 249 222 527 252 222 minecraft:packed_mud
setblock 528 249 220 minecraft:bone_block
fill 528 249 221 528 252 221 minecraft:packed_mud
setblock 529 249 220 minecraft:packed_mud
setblock 531 249 182 minecraft:bone_block
setblock 531 249 222 minecraft:bone_block
setblock 532 249 182 minecraft:packed_mud
fill 532 249 222 532 252 222 minecraft:packed_mud
fill 542 249 182 542 252 182 minecraft:packed_mud
fill 543 249 222 545 249 222 minecraft:packed_mud
setblock 544 249 183 minecraft:packed_mud
setblock 545 249 183 minecraft:bone_block
setblock 546 249 182 minecraft:bone_block
fill 546 249 183 546 252 183 minecraft:packed_mud
setblock 546 249 221 minecraft:packed_mud
setblock 546 249 222 minecraft:bone_block
fill 547 249 182 547 252 182 minecraft:packed_mud
setblock 547 249 221 minecraft:bone_block
fill 547 249 222 547 252 222 minecraft:packed_mud
setblock 548 249 184 minecraft:packed_mud
fill 548 249 221 548 252 221 minecraft:packed_mud
setblock 549 249 184 minecraft:bone_block
setblock 550 249 183 minecraft:bone_block
fill 550 249 184 550 252 184 minecraft:packed_mud
setblock 551 249 182 minecraft:bone_block
fill 551 249 183 551 252 183 minecraft:packed_mud
setblock 551 249 222 minecraft:bone_block
fill 552 249 182 552 252 182 minecraft:packed_mud
setblock 552 249 221 minecraft:bone_block
fill 552 249 222 552 252 222 minecraft:packed_mud
fill 553 249 221 553 250 221 minecraft:packed_mud
setblock 556 249 182 minecraft:bone_block
setblock 556 249 222 minecraft:bone_block
fill 557 249 182 557 252 182 minecraft:packed_mud
fill 557 249 222 557 252 222 minecraft:packed_mud
setblock 558 249 220 minecraft:bone_block
fill 558 249 221 558 252 221 minecraft:packed_mud
setblock 518 250 218 minecraft:packed_mud
setblock 518 250 219 minecraft:bone_block
fill 518 250 220 518 251 222 minecraft:packed_mud
fill 519 250 221 519 250 222 minecraft:packed_mud
setblock 520 250 221 minecraft:packed_mud
setblock 520 250 222 minecraft:bone_block
fill 521 250 182 524 250 182 minecraft:packed_mud
setblock 521 250 221 minecraft:bone_block
fill 521 250 222 521 253 222 minecraft:packed_mud
fill 522 250 221 522 253 221 minecraft:packed_mud
setblock 525 250 182 minecraft:bone_block
setblock 525 250 222 minecraft:bone_block
fill 526 250 182 526 253 182 minecraft:packed_mud
setblock 526 250 221 minecraft:bone_block
fill 526 250 222 526 253 222 minecraft:packed_mud
setblock 527 250 220 minecraft:bone_block
fill 527 250 221 527 253 221 minecraft:packed_mud
setblock 530 250 182 minecraft:bone_block
setblock 530 250 222 minecraft:bone_block
fill 531 250 182 531 253 182 minecraft:packed_mud
fill 531 250 222 531 253 222 minecraft:packed_mud
fill 541 250 182 541 253 182 minecraft:packed_mud
setblock 543 250 183 minecraft:packed_mud
fill 543 250 222 544 250 222 minecraft:packed_mud
setblock 544 250 183 minecraft:bone_block
setblock 545 250 182 minecraft:bone_block
fill 545 250 183 545 253 183 minecraft:packed_mud
setblock 545 250 222 minecraft:bone_block
fill 546 250 182 546 253 182 minecraft:packed_mud
fill 546 250 184 547 250 184 minecraft:packed_mud
setblock 546 250 221 minecraft:bone_block
fill 546 250 222 546 253 222 minecraft:packed_mud
fill 547 250 221 547 253 221 minecraft:packed_mud
setblock 548 250 184 minecraft:bone_block
setblock 549 250 183 minecraft:bone_block
fill 549 250 184 549 253 184 minecraft:packed_mud
setblock 550 250 182 minecraft:bone_block
fill 550 250 183 550 253 183 minecraft:packed_mud
setblock 550 250 222 minecraft:bone_block
fill 551 250 182 551 253 182 minecraft:packed_mud
setblock 551 250 221 minecraft:bone_block
fill 551 250 222 551 253 222 minecraft:packed_mud
fill 552 250 221 552 252 221 minecraft:packed_mud
setblock 554 250 183 minecraft:bone_block
setblock 555 250 182 minecraft:bone_block
setblock 555 250 222 minecraft:bone_block
fill 556 250 182 556 253 182 minecraft:packed_mud
fill 556 250 222 556 253 222 minecraft:packed_mud
setblock 558 250 184 minecraft:bone_block
setblock 558 250 219 minecraft:bone_block
fill 558 250 220 558 253 220 minecraft:packed_mud
setblock 518 251 218 minecraft:bone_block
fill 518 251 219 518 254 219 minecraft:packed_mud
setblock 519 251 221 minecraft:packed_mud
setblock 519 251 222 minecraft:bone_block
fill 520 251 182 523 251 182 minecraft:packed_mud
setblock 520 251 221 minecraft:bone_block
fill 520 251 222 520 254 222 minecraft:packed_mud
fill 521 251 221 521 254 221 minecraft:packed_mud
setblock 524 251 182 minecraft:bone_block
setblock 524 251 222 minecraft:bone_block
fill 525 251 182 525 254 182 minecraft:packed_mud
setblock 525 251 221 minecraft:bone_block
fill 525 251 222 525 254 222 minecraft:packed_mud
fill 526 251 221 526 254 221 minecraft:packed_mud
setblock 529 251 182 minecraft:bone_block
setblock 529 251 222 minecraft:bone_block
fill 530 251 182 530 254 182 minecraft:packed_mud
setblock 530 251 221 minecraft:bone_block
fill 530 251 222 530 254 222 minecraft:packed_mud
fill 532 251 182 532 252 182 minecraft:packed_mud
fill 540 251 182 540 254 182 minecraft:packed_mud
setblock 542 251 183 minecraft:packed_mud
fill 542 251 222 543 251 222 minecraft:packed_mud
setblock 543 251 183 minecraft:bone_block
setblock 544 251 182 minecraft:bone_block
fill 544 251 183 544 254 183 minecraft:packed_mud
setblock 544 251 222 minecraft:bone_block
fill 545 251 182 545 254 182 minecraft:packed_mud
fill 545 251 184 546 251 184 minecraft:packed_mud
setblock 545 251 221 minecraft:bone_block
fill 545 251 222 545 254 222 minecraft:packed_mud
fill 546 251 221 546 254 221 minecraft:packed_mud
setblock 547 251 184 minecraft:bone_block
setblock 548 251 183 minecraft:bone_block
fill 548 251 184 548 254 184 minecraft:packed_mud
setblock 549 251 182 minecraft:bone_block
fill 549 251 183 549 254 183 minecraft:packed_mud
setblock 549 251 222 minecraft:bone_block
fill 550 251 182 550 254 182 minecraft:packed_mud
setblock 550 251 221 minecraft:bone_block
fill 550 251 222 550 254 222 minecraft:packed_mud
setblock 551 251 184 minecraft:packed_mud
fill 551 251 221 551 254 221 minecraft:packed_mud
setblock 553 251 183 minecraft:bone_block
setblock 554 251 182 minecraft:bone_block
fill 554 251 183 555 253 183 minecraft:packed_mud
setblock 554 251 222 minecraft:bone_block
fill 555 251 182 555 254 182 minecraft:packed_mud
fill 555 251 222 555 254 222 minecraft:packed_mud
setblock 558 251 183 minecraft:bone_block
fill 558 251 184 558 254 184 minecraft:packed_mud
fill 558 251 219 558 254 219 minecraft:packed_mud
setblock 518 252 182 minecraft:bone_block
setblock 518 252 202 minecraft:bone_block
fill 518 252 203 518 252 206 minecraft:packed_mud
fill 518 252 218 518 255 218 minecraft:packed_mud
fill 518 252 220 518 252 221 minecraft:packed_mud
setblock 518 252 222 minecraft:bone_block
fill 519 252 182 522 252 182 minecraft:packed_mud
setblock 519 252 221 minecraft:bone_block
fill 519 252 222 519 255 222 minecraft:packed_mud
fill 520 252 221 520 255 221 minecraft:packed_mud
setblock 523 252 182 minecraft:bone_block
setblock 523 252 222 minecraft:bone_block
fill 524 252 182 524 254 183 minecraft:packed_mud
setblock 524 252 221 minecraft:bone_block
fill 524 252 222 524 255 222 minecraft:packed_mud
fill 525 252 183 526 252 183 minecraft:packed_mud
fill 525 252 221 525 255 221 minecraft:packed_mud
setblock 527 252 183 minecraft:bone_block
setblock 528 252 182 minecraft:bone_block
fill 528 252 183 528 255 183 minecraft:packed_mud
setblock 528 252 222 minecraft:bone_block
fill 529 252 182 529 255 182 minecraft:packed_mud
setblock 529 252 221 minecraft:bone_block
fill 529 252 222 529 255 222 minecraft:packed_mud
fill 539 252 182 539 255 182 minecraft:packed_mud
setblock 541 252 183 minecraft:packed_mud
fill 541 252 222 542 252 222 minecraft:packed_mud
setblock 542 252 183 minecraft:bone_block
setblock 543 252 182 minecraft:bone_block
fill 543 252 183 543 254 184 minecraft:packed_mud
setblock 543 252 222 minecraft:bone_block
fill 544 252 182 544 255 182 minecraft:packed_mud
fill 544 252 184 545 252 184 minecraft:packed_mud
fill 544 252 222 544 255 222 minecraft:packed_mud
fill 545 252 221 545 255 221 minecraft:packed_mud
setblock 546 252 184 minecraft:bone_block
setblock 547 252 183 minecraft:bone_block
fill 547 252 184 547 255 184 minecraft:packed_mud
setblock 548 252 182 minecraft:bone_block
fill 548 252 183 548 255 183 minecraft:packed_mud
setblock 548 252 222 minecraft:bone_block
fill 549 252 182 549 255 182 minecraft:packed_mud
setblock 549 252 221 minecraft:bone_block
fill 549 252 222 549 255 222 minecraft:packed_mud
fill 550 252 221 550 255 221 minecraft:packed_mud
setblock 551 252 184 minecraft:bone_block
setblock 552 252 183 minecraft:bone_block
setblock 553 252 182 minecraft:bone_block
fill 553 252 183 553 255 183 minecraft:packed_mud
setblock 553 252 222 minecraft:bone_block
fill 554 252 182 554 255 182 minecraft:packed_mud
fill 554 252 222 554 255 222 minecraft:packed_mud
setblock 556 252 183 minecraft:packed_mud
setblock 558 252 182 minecraft:bone_block
fill 558 252 183 558 255 183 minecraft:packed_mud
fill 558 252 185 558 253 185 minecraft:packed_mud
setblock 558 252 222 minecraft:bone_block
fill 518 253 182 518 255 183 minecraft:packed_mud
setblock 518 253 201 minecraft:bone_block
fill 518 253 202 518 253 205 minecraft:packed_mud
setblock 518 253 206 minecraft:bone_block
fill 518 253 207 518 253 210 minecraft:packed_mud
fill 518 253 217 518 256 217 minecraft:packed_mud
setblock 518 253 220 minecraft:packed_mud
setblock 518 253 221 minecraft:bone_block
fill 518 253 222 518 256 222 minecraft:packed_mud
fill 519 253 182 521 253 182 minecraft:packed_mud
fill 519 253 203 519 253 204 minecraft:packed_mud
setblock 519 253 205 minecraft:bone_block
fill 519 253 206 519 255 207 minecraft:packed_mud
fill 519 253 221 519 256 221 minecraft:packed_mud
setblock 522 253 182 minecraft:bone_block
fill 522 253 183 523 255 183 minecraft:packed_mud
setblock 522 253 222 minecraft:bone_block
fill 523 253 182 523 256 182 minecraft:packed_mud
setblock 523 253 221 minecraft:bone_block
fill 523 253 222 523 256 222 minecraft:packed_mud
fill 524 253 221 524 256 221 minecraft:packed_mud
setblock 525 253 183 minecraft:packed_mud
setblock 526 253 183 minecraft:bone_block
setblock 527 253 182 minecraft:bone_block
fill 527 253 183 527 256 183 minecraft:packed_mud
setblock 527 253 222 minecraft:bone_block
fill 528 253 182 528 256 182 minecraft:packed_mud
setblock 528 253 221 minecraft:bone_block
fill 528 253 222 528 256 222 minecraft:packed_mud
fill 529 253 183 529 254 183 minecraft:packed_mud
setblock 532 253 182 minecraft:bone_block
fill 533 253 182 533 256 182 minecraft:packed_mud
setblock 537 253 182 minecraft:bone_block
fill 538 253 182 538 256 182 minecraft:packed_mud
setblock 540 253 183 minecraft:packed_mud
setblock 541 253 183 minecraft:bone_block
setblock 541 253 222 minecraft:packed_mud
setblock 542 253 182 minecraft:bone_block
fill 542 253 183 542 255 184 minecraft:packed_mud
setblock 542 253 222 minecraft:bone_block
fill 543 253 182 543 256 182 minecraft:packed_mud
fill 543 253 222 543 256 222 minecraft:packed_mud
setblock 544 253 184 minecraft:packed_mud
fill 544 253 221 544 256 221 minecraft:packed_mud
setblock 545 253 184 minecraft:bone_block
fill 545 253 185 548 253 185 minecraft:packed_mud
setblock 546 253 183 minecraft:bone_block
fill 546 253 184 546 256 184 minecraft:packed_mud
setblock 547 253 182 minecraft:bone_block
fill 547 253 183 547 256 183 minecraft:packed_mud
setblock 547 253 222 minecraft:bone_block
fill 548 253 182 548 256 182 minecraft:packed_mud
setblock 548 253 221 minecraft:bone_block
fill 548 253 222 548 256 222 minecraft:packed_mud
fill 549 253 221 549 256 221 minecraft:packed_mud
setblock 550 253 184 minecraft:bone_block
setblock 551 253 183 minecraft:bone_block
fill 551 253 184 552 255 184 minecraft:packed_mud
setblock 552 253 182 minecraft:bone_block
fill 552 253 183 552 256 183 minecraft:packed_mud
setblock 552 253 222 minecraft:bone_block
fill 553 253 182 553 256 182 minecraft:packed_mud
fill 553 253 222 553 256 222 minecraft:packed_mud
setblock 556 253 183 minecraft:bone_block
setblock 557 253 182 minecraft:bone_block
fill 557 253 183 557 256 183 minecraft:packed_mud
setblock 557 253 222 minecraft:bone_block
fill 558 253 182 558 256 182 minecraft:packed_mud
setblock 558 253 186 minecraft:bone_block
setblock 558 253 221 minecraft:bone_block
fill 558 253 222 558 256 222 minecraft:packed_mud
setblock 518 254 184 minecraft:packed_mud
setblock 518 254 185 minecraft:bone_block
fill 518 254 201 518 254 204 minecraft:packed_mud
setblock 518 254 205 minecraft:bone_block
fill 518 254 206 518 254 209 minecraft:packed_mud
setblock 518 254 210 minecraft:bone_block
fill 518 254 211 518 254 214 minecraft:packed_mud
setblock 518 254 215 minecraft:bone_block
fill 518 254 216 518 257 216 minecraft:packed_mud
setblock 518 254 220 minecraft:bone_block
fill 518 254 221 518 257 221 minecraft:packed_mud
fill 519 254 182 520 254 182 minecraft:packed_mud
fill 519 254 202 519 254 203 minecraft:packed_mud
setblock 519 254 204 minecraft:bone_block
fill 519 254 205 520 256 205 minecraft:packed_mud
setblock 519 254 208 minecraft:packed_mud
setblock 519 254 209 minecraft:bone_block
fill 519 254 210 519 257 210 minecraft:packed_mud
fill 519 254 220 519 257 220 minecraft:packed_mud
fill 520 254 204 520 257 204 minecraft:packed_mud
fill 520 254 206 520 254 207 minecraft:packed_mud
setblock 521 254 182 minecraft:bone_block
fill 521 254 183 521 257 183 minecraft:packed_mud
setblock 521 254 222 minecraft:bone_block
fill 522 254 182 522 257 182 minecraft:packed_mud
setblock 522 254 221 minecraft:bone_block
fill 522 254 222 522 257 222 minecraft:packed_mud
fill 523 254 221 523 257 221 minecraft:packed_mud
setblock 525 254 183 minecraft:bone_block
setblock 526 254 182 minecraft:bone_block
fill 526 254 183 526 257 183 minecraft:packed_mud
setblock 526 254 222 minecraft:bone_block
fill 527 254 182 527 257 182 minecraft:packed_mud
setblock 527 254 221 minecraft:bone_block
fill 527 254 222 527 257 222 minecraft:packed_mud
setblock 528 254 221 minecraft:packed_mud
setblock 531 254 182 minecraft:bone_block
setblock 531 254 222 minecraft:bone_block
fill 532 254 182 532 257 182 minecraft:packed_mud
fill 534 254 182 535 254 182 minecraft:packed_mud
setblock 536 254 182 minecraft:bone_block
fill 537 254 182 537 257 182 minecraft:packed_mud
fill 538 254 183 539 254 183 minecraft:packed_mud
setblock 540 254 183 minecraft:bone_block
setblock 540 254 222 minecraft:packed_mud
setblock 541 254 182 minecraft:bone_block
fill 541 254 183 541 256 184 minecraft:packed_mud
setblock 541 254 222 minecraft:bone_block
fill 542 254 182 542 257 182 minecraft:packed_mud
fill 542 254 222 542 257 222 minecraft:packed_mud
setblock 543 254 185 minecraft:bone_block
setblock 544 254 184 minecraft:bone_block
fill 544 254 185 547 254 185 minecraft:packed_mud
setblock 545 254 183 minecraft:bone_block
fill 545 254 184 545 257 184 minecraft:packed_mud
setblock 546 254 182 minecraft:bone_block
fill 546 254 183 546 257 183 minecraft:packed_mud
setblock 546 254 222 minecraft:bone_block
fill 547 254 182 547 257 182 minecraft:packed_mud
setblock 547 254 221 minecraft:bone_block
fill 547 254 222 547 257 222 minecraft:packed_mud
setblock 548 254 185 minecraft:bone_block
fill 548 254 221 548 257 221 minecraft:packed_mud
setblock 549 254 184 minecraft:bone_block
fill 549 254 185 549 257 185 minecraft:packed_mud
setblock 550 254 183 minecraft:bone_block
fill 550 254 184 550 257 184 minecraft:packed_mud
setblock 551 254 182 minecraft:bone_block
fill 551 254 183 551 257 183 minecraft:packed_mud
setblock 551 254 222 minecraft:bone_block
fill 552 254 182 552 257 182 minecraft:packed_mud
fill 552 254 222 552 257 222 minecraft:packed_mud
setblock 554 254 183 minecraft:packed_mud
setblock 555 254 183 minecraft:bone_block
setblock 556 254 182 minecraft:bone_block
fill 556 254 183 556 257 183 minecraft:packed_mud
setblock 556 254 222 minecraft:bone_block
fill 557 254 182 557 257 182 minecraft:packed_mud
fill 557 254 184 557 255 184 minecraft:packed_mud
fill 557 254 222 557 257 222 minecraft:packed_mud
setblock 558 254 185 minecraft:bone_block
fill 558 254 186 558 256 187 minecraft:packed_mud
setblock 558 254 204 minecraft:packed_mud
setblock 558 254 205 minecraft:bone_block
fill 558 254 206 558 256 207 minecraft:packed_mud
fill 558 254 218 558 255 218 minecraft:packed_mud
setblock 558 254 220 minecraft:bone_block
fill 558 254 221 558 257 221 minecraft:packed_mud
setblock 518 255 184 minecraft:bone_block
fill 518 255 185 518 257 186 minecraft:packed_mud
fill 518 255 200 518 255 203 minecraft:packed_mud
setblock 518 255 204 minecraft:bone_block
fill 518 255 205 518 255 208 minecraft:packed_mud
setblock 518 255 209 minecraft:bone_block
fill 518 255 210 518 255 213 minecraft:packed_mud
setblock 518 255 214 minecraft:bone_block
fill 518 255 215 518 258 215 minecraft:packed_mud
setblock 518 255 219 minecraft:bone_block
fill 518 255 220 518 258 220 minecraft:packed_mud
setblock 519 255 182 minecraft:packed_mud
setblock 519 255 183 minecraft:bone_block
fill 519 255 201 519 255 202 minecraft:packed_mud
setblock 519 255 203 minecraft:bone_block
fill 519 255 204 519 258 204 minecraft:packed_mud
setblock 519 255 208 minecraft:bone_block
fill 519 255 209 520 257 209 minecraft:packed_mud
fill 519 255 211 519 255 212 minecraft:packed_mud
setblock 519 255 213 minecraft:bone_block
setblock 520 255 182 minecraft:bone_block
fill 520 255 183 520 258 183 minecraft:packed_mud
setblock 520 255 184 minecraft:light[level=11]
setblock 520 255 192 minecraft:light[level=11]
setblock 520 255 200 minecraft:light[level=11]
setblock 520 255 202 minecraft:bone_block
fill 520 255 203 520 258 203 minecraft:packed_mud
setblock 520 255 206 minecraft:packed_mud
setblock 520 255 207 minecraft:bone_block
fill 520 255 208 521 257 208 minecraft:packed_mud
fill 520 255 210 520 256 210 minecraft:packed_mud
setblock 520 255 216 minecraft:light[level=11]
setblock 520 255 222 minecraft:bone_block
fill 521 255 182 521 258 182 minecraft:packed_mud
fill 521 255 204 521 255 205 minecraft:packed_mud
setblock 521 255 206 minecraft:bone_block
fill 521 255 207 521 258 207 minecraft:packed_mud
setblock 521 255 221 minecraft:bone_block
fill 521 255 222 521 258 222 minecraft:packed_mud
fill 522 255 221 522 258 221 minecraft:packed_mud
setblock 524 255 182 minecraft:packed_mud
setblock 524 255 183 minecraft:bone_block
setblock 525 255 182 minecraft:bone_block
fill 525 255 183 525 258 183 minecraft:packed_mud
setblock 525 255 222 minecraft:bone_block
fill 526 255 182 526 258 182 minecraft:packed_mud
setblock 526 255 221 minecraft:bone_block
fill 526 255 222 526 258 222 minecraft:packed_mud
setblock 527 255 221 minecraft:packed_mud
setblock 528 255 184 minecraft:light[level=11]
setblock 528 255 192 minecraft:light[level=11]
setblock 528 255 200 minecraft:light[level=11]
setblock 528 255 208 minecraft:light[level=11]
setblock 528 255 216 minecraft:light[level=11]
setblock 529 255 183 minecraft:bone_block
setblock 530 255 182 minecraft:bone_block
fill 530 255 183 530 256 183 minecraft:packed_mud
setblock 530 255 222 minecraft:bone_block
fill 531 255 182 531 258 182 minecraft:packed_mud
setblock 534 255 182 minecraft:packed_mud
setblock 535 255 182 minecraft:bone_block
fill 536 255 182 536 258 182 minecraft:packed_mud
setblock 536 255 184 minecraft:light[level=11]
setblock 536 255 192 minecraft:light[level=11]
setblock 536 255 208 minecraft:light[level=11]
setblock 536 255 216 minecraft:light[level=11]
fill 537 255 183 538 255 183 minecraft:packed_mud
setblock 539 255 183 minecraft:bone_block
fill 539 255 184 540 257 184 minecraft:packed_mud
setblock 540 255 182 minecraft:bone_block
fill 540 255 183 540 258 183 minecraft:packed_mud
setblock 540 255 222 minecraft:bone_block
fill 541 255 182 541 258 182 minecraft:packed_mud
fill 541 255 222 541 258 222 minecraft:packed_mud
setblock 542 255 185 minecraft:bone_block
setblock 543 255 183 minecraft:packed_mud
setblock 543 255 184 minecraft:bone_block
fill 543 255 185 546 255 185 minecraft:packed_mud
fill 543 255 221 543 257 221 minecraft:packed_mud
setblock 544 255 183 minecraft:bone_block
fill 544 255 184 544 258 184 minecraft:packed_mud
setblock 544 255 192 minecraft:light[level=11]
setblock 544 255 200 minecraft:light[level=11]
setblock 544 255 208 minecraft:light[level=11]
setblock 544 255 216 minecraft:light[level=11]
setblock 545 255 182 minecraft:bone_block
fill 545 255 183 545 258 183 minecraft:packed_mud
setblock 545 255 222 minecraft:bone_block
fill 546 255 182 546 258 182 minecraft:packed_mud
setblock 546 255 221 minecraft:bone_block
fill 546 255 222 546 258 222 minecraft:packed_mud
setblock 547 255 185 minecraft:bone_block
fill 547 255 221 547 258 221 minecraft:packed_mud
setblock 548 255 184 minecraft:bone_block
fill 548 255 185 548 258 185 minecraft:packed_mud
setblock 549 255 183 minecraft:bone_block
fill 549 255 184 549 258 184 minecraft:packed_mud
setblock 550 255 182 minecraft:bone_block
fill 550 255 183 550 258 183 minecraft:packed_mud
setblock 550 255 222 minecraft:bone_block
fill 551 255 182 551 258 182 minecraft:packed_mud
setblock 551 255 221 minecraft:bone_block
fill 551 255 222 551 258 222 minecraft:packed_mud
setblock 552 255 192 minecraft:light[level=11]
setblock 552 255 200 minecraft:light[level=11]
setblock 552 255 208 minecraft:light[level=11]
setblock 552 255 216 minecraft:light[level=11]
setblock 553 255 184 minecraft:bone_block
setblock 554 255 183 minecraft:bone_block
setblock 555 255 182 minecraft:bone_block
fill 555 255 183 555 258 183 minecraft:packed_mud
setblock 555 255 222 minecraft:bone_block
fill 556 255 182 556 258 182 minecraft:packed_mud
fill 556 255 222 556 258 222 minecraft:packed_mud
setblock 557 255 185 minecraft:bone_block
fill 557 255 186 557 258 186 minecraft:packed_mud
fill 557 255 221 557 258 221 minecraft:packed_mud
setblock 558 255 184 minecraft:bone_block
fill 558 255 185 558 258 185 minecraft:packed_mud
setblock 558 255 188 minecraft:packed_mud
setblock 558 255 203 minecraft:packed_mud
setblock 558 255 204 minecraft:bone_block
fill 558 255 205 558 258 205 minecraft:packed_mud
setblock 558 255 208 minecraft:packed_mud
setblock 558 255 209 minecraft:bone_block
fill 558 255 210 558 257 211 minecraft:packed_mud
fill 558 255 217 558 256 217 minecraft:packed_mud
setblock 558 255 219 minecraft:bone_block
fill 558 255 220 558 258 220 minecraft:packed_mud
setblock 518 256 182 minecraft:packed_mud
setblock 518 256 183 minecraft:bone_block
fill 518 256 184 519 258 184 minecraft:packed_mud
setblock 518 256 187 minecraft:packed_mud
setblock 518 256 188 minecraft:bone_block
fill 518 256 200 518 256 202 minecraft:packed_mud
setblock 518 256 203 minecraft:bone_block
fill 518 256 204 518 256 207 minecraft:packed_mud
setblock 518 256 208 minecraft:bone_block
fill 518 256 209 518 256 212 minecraft:packed_mud
setblock 518 256 213 minecraft:bone_block
fill 518 256 214 519 258 214 minecraft:packed_mud
setblock 518 256 218 minecraft:bone_block
fill 518 256 219 519 258 219 minecraft:packed_mud
setblock 519 256 182 minecraft:bone_block
fill 519 256 183 519 259 183 minecraft:packed_mud
fill 519 256 185 519 257 185 minecraft:packed_mud
setblock 519 256 201 minecraft:packed_mud
setblock 519 256 202 minecraft:bone_block
fill 519 256 203 519 259 203 minecraft:packed_mud
setblock 519 256 206 minecraft:packed_mud
setblock 519 256 207 minecraft:bone_block
fill 519 256 208 519 259 208 minecraft:packed_mud
setblock 519 256 211 minecraft:packed_mud
setblock 519 256 212 minecraft:bone_block
fill 519 256 213 519 259 213 minecraft:packed_mud
fill 519 256 215 519 257 215 minecraft:packed_mud
setblock 519 256 222 minecraft:bone_block
fill 520 256 182 520 259 182 minecraft:packed_mud
fill 520 256 202 520 259 202 minecraft:packed_mud
setblock 520 256 206 minecraft:bone_block
fill 520 256 207 520 259 207 minecraft:packed_mud
setblock 520 256 211 minecraft:bone_block
fill 520 256 212 520 259 212 minecraft:packed_mud
setblock 520 256 221 minecraft:bone_block
fill 520 256 222 520 259 222 minecraft:packed_mud
fill 521 256 203 521 256 204 minecraft:packed_mud
setblock 521 256 205 minecraft:bone_block
fill 521 256 206 521 259 206 minecraft:packed_mud
setblock 521 256 209 minecraft:packed_mud
setblock 521 256 210 minecraft:bone_block
fill 521 256 221 521 259 221 minecraft:packed_mud
setblock 522 256 183 minecraft:packed_mud
setblock 523 256 183 minecraft:bone_block
fill 523 256 184 526 256 184 minecraft:packed_mud
setblock 524 256 182 minecraft:bone_block
fill 524 256 183 524 259 183 minecraft:packed_mud
setblock 524 256 222 minecraft:bone_block
fill 525 256 182 525 259 182 minecraft:packed_mud
setblock 525 256 221 minecraft:bone_block
fill 525 256 222 525 259 222 minecraft:packed_mud
setblock 526 256 221 minecraft:packed_mud
setblock 528 256 183 minecraft:bone_block
setblock 529 256 182 minecraft:bone_block
fill 529 256 183 529 257 183 minecraft:packed_mud
setblock 529 256 222 minecraft:bone_block
fill 530 256 182 530 258 182 minecraft:packed_mud
setblock 534 256 182 minecraft:bone_block
fill 535 256 182 535 259 182 minecraft:packed_mud
fill 536 256 183 537 256 183 minecraft:packed_mud
setblock 538 256 183 minecraft:bone_block
fill 538 256 184 538 259 184 minecraft:packed_mud
setblock 539 256 182 minecraft:bone_block
fill 539 256 183 539 259 183 minecraft:packed_mud
setblock 539 256 222 minecraft:bone_block
fill 540 256 182 540 259 182 minecraft:packed_mud
setblock 540 256 185 minecraft:packed_mud
fill 540 256 222 540 259 222 minecraft:packed_mud
setblock 541 256 185 minecraft:bone_block
setblock 542 256 183 minecraft:packed_mud
setblock 542 256 184 minecraft:bone_block
fill 542 256 185 545 256 185 minecraft:packed_mud
setblock 543 256 183 minecraft:bone_block
fill 543 256 184 543 259 184 minecraft:packed_mud
setblock 544 256 182 minecraft:bone_block
fill 544 256 183 544 259 183 minecraft:packed_mud
setblock 544 256 186 minecraft:packed_mud
setblock 544 256 222 minecraft:bone_block
fill 545 256 182 545 259 182 minecraft:packed_mud
setblock 545 256 186 minecraft:bone_block
setblock 545 256 221 minecraft:bone_block
fill 545 256 222 545 259 222 minecraft:packed_mud
setblock 546 256 185 minecraft:bone_block
fill 546 256 186 546 258 186 minecraft:packed_mud
fill 546 256 221 546 258 221 minecraft:packed_mud
setblock 547 256 184 minecraft:bone_block
fill 547 256 185 547 259 185 minecraft:packed_mud
setblock 548 256 183 minecraft:bone_block
fill 548 256 184 548 259 184 minecraft:packed_mud
setblock 549 256 182 minecraft:bone_block
fill 549 256 183 549 259 183 minecraft:packed_mud
setblock 549 256 222 minecraft:bone_block
fill 550 256 182 550 259 182 minecraft:packed_mud
setblock 550 256 221 minecraft:bone_block
fill 550 256 222 550 259 222 minecraft:packed_mud
setblock 551 256 184 minecraft:packed_mud
setblock 552 256 184 minecraft:bone_block
fill 552 256 214 553 257 214 minecraft:bone_block
setblock 553 256 183 minecraft:bone_block
setblock 553 256 184 minecraft:packed_mud
setblock 554 256 182 minecraft:bone_block
fill 554 256 183 554 259 183 minecraft:packed_mud
setblock 554 256 222 minecraft:bone_block
fill 555 256 182 555 259 182 minecraft:packed_mud
fill 555 256 222 555 259 222 minecraft:packed_mud
setblock 557 256 184 minecraft:bone_block
fill 557 256 185 557 259 185 minecraft:packed_mud
setblock 558 256 183 minecraft:bone_block
fill 558 256 184 558 259 184 minecraft:packed_mud
setblock 558 256 188 minecraft:bone_block
fill 558 256 189 558 259 189 minecraft:packed_mud
setblock 558 256 202 minecraft:packed_mud
setblock 558 256 203 minecraft:bone_block
fill 558 256 204 558 259 204 minecraft:packed_mud
setblock 558 256 208 minecraft:bone_block
fill 558 256 209 558 259 209 minecraft:packed_mud
setblock 558 256 212 minecraft:packed_mud
setblock 558 256 213 minecraft:bone_block
fill 558 256 214 558 257 216 minecraft:packed_mud
setblock 558 256 218 minecraft:bone_block
fill 558 256 219 558 259 219 minecraft:packed_mud
setblock 518 257 182 minecraft:bone_block
fill 518 257 183 518 260 183 minecraft:packed_mud
setblock 518 257 187 minecraft:bone_block
fill 518 257 188 518 259 189 minecraft:packed_mud
fill 518 257 199 518 257 201 minecraft:packed_mud
setblock 518 257 202 minecraft:bone_block
fill 518 257 203 518 257 206 minecraft:packed_mud
setblock 518 257 207 minecraft:bone_block
fill 518 257 208 518 257 211 minecraft:packed_mud
setblock 518 257 212 minecraft:bone_block
fill 518 257 213 518 260 213 minecraft:packed_mud
setblock 518 257 217 minecraft:bone_block
fill 518 257 218 519 259 218 minecraft:packed_mud
setblock 518 257 222 minecraft:bone_block
fill 519 257 182 519 260 182 minecraft:packed_mud
setblock 519 257 186 minecraft:bone_block
fill 519 257 187 519 260 187 minecraft:packed_mud
setblock 519 257 200 minecraft:packed_mud
setblock 519 257 201 minecraft:bone_block
fill 519 257 202 519 260 202 minecraft:packed_mud
setblock 519 257 205 minecraft:packed_mud
setblock 519 257 206 minecraft:bone_block
fill 519 257 207 519 260 207 minecraft:packed_mud
setblock 519 257 211 minecraft:bone_block
fill 519 257 212 519 260 212 minecraft:packed_mud
setblock 519 257 216 minecraft:bone_block
fill 519 257 217 519 260 217 minecraft:packed_mud
setblock 519 257 221 minecraft:bone_block
fill 519 257 222 519 260 222 minecraft:packed_mud
setblock 520 257 205 minecraft:bone_block
fill 520 257 206 520 260 206 minecraft:packed_mud
setblock 520 257 210 minecraft:bone_block
fill 520 257 211 521 259 211 minecraft:packed_mud
fill 520 257 213 520 258 213 minecraft:packed_mud
fill 520 257 221 520 259 221 minecraft:packed_mud
setblock 521 257 203 minecraft:packed_mud
setblock 521 257 204 minecraft:bone_block
fill 521 257 205 522 258 205 minecraft:packed_mud
setblock 521 257 209 minecraft:bone_block
fill 521 257 210 521 260 210 minecraft:packed_mud
setblock 522 257 183 minecraft:bone_block
fill 522 257 184 525 257 184 minecraft:packed_mud
fill 522 257 206 522 257 207 minecraft:packed_mud
setblock 522 257 208 minecraft:bone_block
setblock 523 257 182 minecraft:bone_block
fill 523 257 183 523 260 183 minecraft:packed_mud
setblock 523 257 222 minecraft:bone_block
fill 524 257 182 524 260 182 minecraft:packed_mud
setblock 524 257 221 minecraft:bone_block
fill 524 257 222 524 260 222 minecraft:packed_mud
setblock 525 257 221 minecraft:packed_mud
setblock 526 257 184 minecraft:bone_block
setblock 527 257 183 minecraft:bone_block
setblock 528 257 182 minecraft:bone_block
fill 528 257 183 528 258 183 minecraft:packed_mud
setblock 528 257 222 minecraft:bone_block
fill 529 257 182 529 259 182 minecraft:packed_mud
fill 529 257 202 529 258 202 minecraft:mud_bricks
setblock 533 257 182 minecraft:bone_block
fill 534 257 182 534 259 182 minecraft:packed_mud
setblock 536 257 183 minecraft:packed_mud
setblock 537 257 183 minecraft:bone_block
setblock 538 257 182 minecraft:bone_block
fill 538 257 183 538 260 183 minecraft:packed_mud
fill 539 257 182 539 260 182 minecraft:packed_mud
fill 539 257 222 539 260 222 minecraft:packed_mud
setblock 540 257 185 minecraft:bone_block
setblock 541 257 183 minecraft:packed_mud
setblock 541 257 184 minecraft:bone_block
fill 541 257 185 544 257 185 minecraft:packed_mud
setblock 542 257 183 minecraft:bone_block
fill 542 257 184 542 260 184 minecraft:packed_mud
fill 542 257 186 543 257 186 minecraft:packed_mud
setblock 543 257 182 minecraft:bone_block
fill 543 257 183 543 260 183 minecraft:packed_mud
setblock 543 257 222 minecraft:bone_block
fill 544 257 182 544 260 182 minecraft:packed_mud
setblock 544 257 186 minecraft:bone_block
setblock 544 257 221 minecraft:bone_block
fill 544 257 222 544 260 222 minecraft:packed_mud
setblock 545 257 185 minecraft:bone_block
fill 545 257 186 545 259 186 minecraft:packed_mud
fill 545 257 221 545 258 221 minecraft:packed_mud
setblock 546 257 184 minecraft:bone_block
fill 546 257 185 546 260 185 minecraft:packed_mud
setblock 547 257 183 minecraft:bone_block
fill 547 257 184 547 260 184 minecraft:packed_mud
setblock 548 257 182 minecraft:bone_block
fill 548 257 183 548 260 183 minecraft:packed_mud
setblock 548 257 222 minecraft:bone_block
fill 549 257 182 549 260 182 minecraft:packed_mud
fill 549 257 222 549 260 222 minecraft:packed_mud
setblock 551 257 184 minecraft:bone_block
setblock 552 257 183 minecraft:bone_block
setblock 552 257 184 minecraft:packed_mud
setblock 553 257 182 minecraft:bone_block
fill 553 257 183 553 259 183 minecraft:packed_mud
setblock 553 257 222 minecraft:bone_block
fill 554 257 182 554 260 182 minecraft:packed_mud
fill 554 257 222 554 260 222 minecraft:packed_mud
setblock 557 257 183 minecraft:bone_block
fill 557 257 184 557 260 184 minecraft:packed_mud
setblock 557 257 187 minecraft:packed_mud
setblock 557 257 207 minecraft:packed_mud
setblock 557 257 208 minecraft:bone_block
fill 557 257 209 557 260 209 minecraft:packed_mud
setblock 558 257 182 minecraft:bone_block
fill 558 257 183 558 260 183 minecraft:packed_mud
setblock 558 257 186 minecraft:packed_mud
setblock 558 257 187 minecraft:bone_block
fill 558 257 188 558 260 188 minecraft:packed_mud
fill 558 257 190 558 258 190 minecraft:packed_mud
setblock 558 257 202 minecraft:bone_block
fill 558 257 203 558 260 203 minecraft:packed_mud
setblock 558 257 206 minecraft:packed_mud
setblock 558 257 207 minecraft:bone_block
fill 558 257 208 558 260 208 minecraft:packed_mud
setblock 558 257 212 minecraft:bone_block
fill 558 257 213 558 260 213 minecraft:packed_mud
setblock 558 257 217 minecraft:bone_block
fill 558 257 218 558 260 218 minecraft:packed_mud
setblock 558 257 222 minecraft:bone_block
fill 518 258 182 518 261 182 minecraft:packed_mud
setblock 518 258 185 minecraft:packed_mud
setblock 518 258 186 minecraft:bone_block
fill 518 258 187 518 261 187 minecraft:packed_mud
setblock 518 258 190 minecraft:packed_mud
setblock 518 258 191 minecraft:bone_block
fill 518 258 199 518 258 200 minecraft:packed_mud
setblock 518 258 201 minecraft:bone_block
fill 518 258 202 518 258 205 minecraft:packed_mud
setblock 518 258 206 minecraft:bone_block
fill 518 258 207 518 258 210 minecraft:packed_mud
setblock 518 258 211 minecraft:bone_block
fill 518 258 212 518 261 212 minecraft:packed_mud
setblock 518 258 216 minecraft:bone_block
fill 518 258 217 518 261 217 minecraft:packed_mud
setblock 518 258 221 minecraft:bone_block
fill 518 258 222 518 261 222 minecraft:packed_mud
setblock 519 258 185 minecraft:bone_block
fill 519 258 186 519 261 186 minecraft:packed_mud
fill 519 258 188 519 259 188 minecraft:packed_mud
setblock 519 258 200 minecraft:bone_block
fill 519 258 201 519 261 201 minecraft:packed_mud
setblock 519 258 205 minecraft:bone_block
fill 519 258 206 519 261 206 minecraft:packed_mud
setblock 519 258 209 minecraft:packed_mud
setblock 519 258 210 minecraft:bone_block
fill 519 258 211 519 261 211 minecraft:packed_mud
setblock 519 258 215 minecraft:bone_block
fill 519 258 216 519 261 216 minecraft:packed_mud
setblock 519 258 220 minecraft:bone_block
setblock 519 258 221 minecraft:packed_mud
setblock 520 258 204 minecraft:bone_block
fill 520 258 205 520 261 205 minecraft:packed_mud
setblock 520 258 208 minecraft:packed_mud
setblock 520 258 209 minecraft:bone_block
fill 520 258 210 520 261 210 minecraft:packed_mud
setblock 520 258 214 minecraft:bone_block
setblock 521 258 183 minecraft:bone_block
setblock 521 258 203 minecraft:bone_block
fill 521 258 204 521 260 204 minecraft:packed_mud
setblock 521 258 208 minecraft:bone_block
fill 521 258 209 522 260 209 minecraft:packed_mud
setblock 521 258 212 minecraft:packed_mud
setblock 522 258 182 minecraft:bone_block
fill 522 258 183 522 258 184 minecraft:packed_mud
setblock 522 258 206 minecraft:packed_mud
setblock 522 258 207 minecraft:bone_block
fill 522 258 208 522 260 208 minecraft:packed_mud
setblock 522 258 222 minecraft:bone_block
fill 523 258 182 523 261 182 minecraft:packed_mud
fill 523 258 184 524 258 184 minecraft:packed_mud
setblock 523 258 221 minecraft:bone_block
fill 523 258 222 523 261 222 minecraft:packed_mud
setblock 524 258 221 minecraft:packed_mud
setblock 526 258 183 minecraft:bone_block
setblock 527 258 182 minecraft:bone_block
setblock 527 258 183 minecraft:packed_mud
setblock 527 258 222 minecraft:bone_block
fill 528 258 182 528 259 182 minecraft:packed_mud
setblock 532 258 182 minecraft:bone_block
setblock 533 258 182 minecraft:packed_mud
setblock 536 258 183 minecraft:bone_block
setblock 537 258 182 minecraft:bone_block
fill 537 258 183 537 260 184 minecraft:packed_mud
fill 538 258 182 538 261 182 minecraft:packed_mud
setblock 539 258 184 minecraft:packed_mud
setblock 539 258 185 minecraft:bone_block
setblock 540 258 184 minecraft:bone_block
fill 540 258 185 543 258 185 minecraft:packed_mud
setblock 541 258 183 minecraft:bone_block
fill 541 258 184 541 261 184 minecraft:packed_mud
fill 541 258 186 542 258 186 minecraft:packed_mud
setblock 542 258 182 minecraft:bone_block
fill 542 258 183 542 261 183 minecraft:packed_mud
setblock 542 258 222 minecraft:bone_block
fill 543 258 182 543 261 182 minecraft:packed_mud
setblock 543 258 186 minecraft:bone_block
setblock 543 258 221 minecraft:bone_block
fill 543 258 222 543 261 222 minecraft:packed_mud
setblock 544 258 185 minecraft:bone_block
fill 544 258 186 544 259 186 minecraft:packed_mud
fill 544 258 221 544 259 221 minecraft:packed_mud
setblock 545 258 184 minecraft:bone_block
fill 545 258 185 545 261 185 minecraft:packed_mud
setblock 546 258 183 minecraft:bone_block
fill 546 258 184 546 261 184 minecraft:packed_mud
setblock 547 258 182 minecraft:bone_block
fill 547 258 183 547 261 183 minecraft:packed_mud
setblock 547 258 222 minecraft:bone_block
fill 548 258 182 548 261 182 minecraft:packed_mud
fill 548 258 222 548 260 222 minecraft:packed_mud
setblock 550 258 184 minecraft:bone_block
setblock 551 258 183 minecraft:bone_block
setblock 551 258 184 minecraft:packed_mud
setblock 552 258 182 minecraft:bone_block
fill 552 258 183 552 260 183 minecraft:packed_mud
setblock 552 258 222 minecraft:bone_block
fill 553 258 182 553 261 182 minecraft:packed_mud
fill 553 258 222 553 259 222 minecraft:packed_mud
setblock 556 258 183 minecraft:bone_block
setblock 557 258 182 minecraft:bone_block
fill 557 258 183 557 260 183 minecraft:packed_mud
setblock 557 258 187 minecraft:bone_block
fill 557 258 188 557 261 188 minecraft:packed_mud
setblock 557 258 206 minecraft:packed_mud
setblock 557 258 207 minecraft:bone_block
fill 557 258 208 557 261 208 minecraft:packed_mud
fill 557 258 210 557 258 211 minecraft:packed_mud
setblock 557 258 212 minecraft:bone_block
setblock 557 258 222 minecraft:bone_block
fill 558 258 182 558 261 182 minecraft:packed_mud
setblock 558 258 186 minecraft:bone_block
fill 558 258 187 558 261 187 minecraft:packed_mud
setblock 558 258 191 minecraft:bone_block
fill 558 258 202 558 259 202 minecraft:packed_mud
setblock 558 258 206 minecraft:bone_block
fill 558 258 207 558 261 207 minecraft:packed_mud
setblock 558 258 210 minecraft:packed_mud
setblock 558 258 211 minecraft:bone_block
fill 558 258 212 558 261 212 minecraft:packed_mud
fill 558 258 214 558 258 215 minecraft:packed_mud
setblock 558 258 216 minecraft:bone_block
fill 558 258 217 558 261 217 minecraft:packed_mud
setblock 558 258 221 minecraft:bone_block
fill 558 258 222 558 261 222 minecraft:packed_mud
setblock 518 259 184 minecraft:packed_mud
setblock 518 259 185 minecraft:bone_block
fill 518 259 186 518 262 186 minecraft:packed_mud
setblock 518 259 190 minecraft:bone_block
fill 518 259 191 518 261 192 minecraft:packed_mud
setblock 518 259 199 minecraft:packed_mud
setblock 518 259 200 minecraft:bone_block
fill 518 259 201 518 259 204 minecraft:packed_mud
setblock 518 259 205 minecraft:bone_block
fill 518 259 206 518 259 209 minecraft:packed_mud
setblock 518 259 210 minecraft:bone_block
fill 518 259 211 518 262 211 minecraft:packed_mud
setblock 518 259 214 minecraft:packed_mud
setblock 518 259 215 minecraft:bone_block
fill 518 259 216 518 262 216 minecraft:packed_mud
setblock 518 259 219 minecraft:packed_mud
setblock 518 259 220 minecraft:bone_block
fill 518 259 221 518 262 221 minecraft:packed_mud
setblock 519 259 184 minecraft:bone_block
fill 519 259 185 519 261 185 minecraft:packed_mud
setblock 519 259 189 minecraft:bone_block
setblock 519 259 200 minecraft:packed_mud
setblock 519 259 204 minecraft:bone_block
fill 519 259 205 519 262 205 minecraft:packed_mud
setblock 519 259 209 minecraft:bone_block
fill 519 259 210 519 262 210 minecraft:packed_mud
setblock 519 259 214 minecraft:bone_block
fill 519 259 215 520 261 215 minecraft:packed_mud
setblock 520 259 183 minecraft:bone_block
setblock 520 259 203 minecraft:bone_block
fill 520 259 204 520 262 204 minecraft:packed_mud
setblock 520 259 208 minecraft:bone_block
fill 520 259 209 520 262 209 minecraft:packed_mud
setblock 520 259 213 minecraft:bone_block
fill 520 259 214 520 262 214 minecraft:packed_mud
setblock 521 259 182 minecraft:bone_block
fill 521 259 183 522 260 183 minecraft:packed_mud
fill 521 259 205 521 260 205 minecraft:packed_mud
setblock 521 259 207 minecraft:bone_block
fill 521 259 208 521 262 208 minecraft:packed_mud
setblock 521 259 212 minecraft:bone_block
setblock 521 259 222 minecraft:bone_block
fill 522 259 182 522 262 182 minecraft:packed_mud
setblock 522 259 206 minecraft:bone_block
setblock 522 259 207 minecraft:packed_mud
setblock 522 259 210 minecraft:packed_mud
setblock 522 259 221 minecraft:bone_block
fill 522 259 222 522 261 222 minecraft:packed_mud
setblock 525 259 183 minecraft:bone_block
setblock 526 259 182 minecraft:bone_block
setblock 526 259 183 minecraft:packed_mud
setblock 526 259 222 minecraft:bone_block
fill 527 259 182 527 260 182 minecraft:packed_mud
fill 529 259 218 530 260 219 minecraft:bone_block
setblock 536 259 182 minecraft:bone_block
fill 536 259 183 536 261 183 minecraft:packed_mud
fill 537 259 182 537 262 182 minecraft:packed_mud
setblock 539 259 184 minecraft:bone_block
fill 539 259 185 542 259 185 minecraft:packed_mud
setblock 540 259 183 minecraft:bone_block
fill 540 259 184 540 262 184 minecraft:packed_mud
setblock 541 259 182 minecraft:bone_block
fill 541 259 183 541 262 183 minecraft:packed_mud
setblock 541 259 186 minecraft:packed_mud
setblock 541 259 222 minecraft:bone_block
fill 542 259 182 542 262 182 minecraft:packed_mud
setblock 542 259 186 minecraft:bone_block
fill 542 259 222 542 262 222 minecraft:packed_mud
setblock 543 259 185 minecraft:bone_block
fill 543 259 186 543 260 186 minecraft:packed_mud
setblock 544 259 184 minecraft:bone_block
fill 544 259 185 544 261 185 minecraft:packed_mud
setblock 545 259 183 minecraft:bone_block
fill 545 259 184 545 262 184 minecraft:packed_mud
setblock 546 259 182 minecraft:bone_block
fill 546 259 183 546 262 183 minecraft:packed_mud
setblock 546 259 222 minecraft:bone_block
fill 547 259 182 547 262 182 minecraft:packed_mud
fill 547 259 222 547 261 222 minecraft:packed_mud
setblock 549 259 184 minecraft:bone_block
setblock 550 259 183 minecraft:bone_block
setblock 550 259 184 minecraft:packed_mud
setblock 551 259 182 minecraft:bone_block
fill 551 259 183 551 260 183 minecraft:packed_mud
setblock 551 259 222 minecraft:bone_block
fill 552 259 182 552 261 182 minecraft:packed_mud
setblock 552 259 222 minecraft:packed_mud
setblock 555 259 183 minecraft:bone_block
fill 555 259 218 557 260 218 minecraft:bone_block
setblock 556 259 182 minecraft:bone_block
fill 556 259 183 556 260 183 minecraft:packed_mud
setblock 556 259 222 minecraft:bone_block
fill 557 259 182 557 262 182 minecraft:packed_mud
setblock 557 259 186 minecraft:bone_block
fill 557 259 187 557 262 187 minecraft:packed_mud
setblock 557 259 206 minecraft:bone_block
fill 557 259 207 557 262 207 minecraft:packed_mud
setblock 557 259 210 minecraft:packed_mud
setblock 557 259 211 minecraft:bone_block
fill 557 259 212 557 260 214 minecraft:packed_mud
fill 557 259 222 557 262 222 minecraft:packed_mud
setblock 558 259 185 minecraft:bone_block
fill 558 259 186 558 262 186 minecraft:packed_mud
setblock 558 259 190 minecraft:bone_block
fill 558 259 191 558 262 191 minecraft:packed_mud
setblock 558 259 205 minecraft:bone_block
fill 558 259 206 558 262 206 minecraft:packed_mud
setblock 558 259 210 minecraft:bone_block
fill 558 259 211 558 262 211 minecraft:packed_mud
setblock 558 259 214 minecraft:packed_mud
setblock 558 259 215 minecraft:bone_block
fill 558 259 216 558 262 216 minecraft:packed_mud
setblock 558 259 220 minecraft:bone_block
fill 558 259 221 558 262 221 minecraft:packed_mud
setblock 518 260 184 minecraft:bone_block
fill 518 260 185 518 263 185 minecraft:packed_mud
setblock 518 260 188 minecraft:packed_mud
setblock 518 260 189 minecraft:bone_block
fill 518 260 190 519 262 190 minecraft:packed_mud
setblock 518 260 193 minecraft:packed_mud
setblock 518 260 199 minecraft:bone_block
fill 518 260 200 518 260 203 minecraft:packed_mud
setblock 518 260 204 minecraft:bone_block
fill 518 260 205 518 260 208 minecraft:packed_mud
setblock 518 260 209 minecraft:bone_block
fill 518 260 210 518 263 210 minecraft:packed_mud
setblock 518 260 214 minecraft:bone_block
fill 518 260 215 518 263 215 minecraft:packed_mud
setblock 518 260 218 minecraft:packed_mud
setblock 518 260 219 minecraft:bone_block
fill 518 260 220 518 263 220 minecraft:packed_mud
setblock 519 260 184 minecraft:packed_mud
setblock 519 260 188 minecraft:bone_block
fill 519 260 189 519 263 189 minecraft:packed_mud
setblock 519 260 203 minecraft:bone_block
fill 519 260 204 519 263 204 minecraft:packed_mud
setblock 519 260 208 minecraft:bone_block
fill 519 260 209 519 263 209 minecraft:packed_mud
setblock 519 260 213 minecraft:bone_block
fill 519 260 214 519 263 214 minecraft:packed_mud
setblock 519 260 218 minecraft:bone_block
setblock 520 260 182 minecraft:bone_block
setblock 520 260 183 minecraft:packed_mud
setblock 520 260 202 minecraft:bone_block
fill 520 260 203 520 261 203 minecraft:packed_mud
setblock 520 260 207 minecraft:bone_block
fill 520 260 208 520 263 208 minecraft:packed_mud
setblock 520 260 211 minecraft:packed_mud
setblock 520 260 212 minecraft:bone_block
fill 520 260 213 521 260 213 minecraft:packed_mud
setblock 520 260 222 minecraft:bone_block
fill 521 260 182 521 262 182 minecraft:packed_mud
setblock 521 260 206 minecraft:bone_block
fill 521 260 207 521 262 207 minecraft:packed_mud
setblock 521 260 211 minecraft:bone_block
fill 521 260 212 521 263 212 minecraft:packed_mud
fill 521 260 222 521 261 222 minecraft:packed_mud
setblock 524 260 183 minecraft:bone_block
setblock 525 260 182 minecraft:bone_block
setblock 526 260 182 minecraft:packed_mud
setblock 535 260 182 minecraft:bone_block
fill 536 260 182 536 263 182 minecraft:packed_mud
setblock 538 260 184 minecraft:bone_block
setblock 539 260 183 minecraft:bone_block
fill 539 260 184 539 261 185 minecraft:packed_mud
setblock 540 260 182 minecraft:bone_block
fill 540 260 183 540 263 183 minecraft:packed_mud
fill 540 260 185 541 260 185 minecraft:packed_mud
setblock 540 260 222 minecraft:bone_block
fill 541 260 182 541 263 182 minecraft:packed_mud
fill 541 260 222 541 263 222 minecraft:packed_mud
setblock 542 260 185 minecraft:bone_block
setblock 542 260 186 minecraft:packed_mud
setblock 543 260 184 minecraft:bone_block
fill 543 260 185 543 262 185 minecraft:packed_mud
setblock 544 260 183 minecraft:bone_block
fill 544 260 184 544 262 184 minecraft:packed_mud
setblock 545 260 182 minecraft:bone_block
fill 545 260 183 545 263 183 minecraft:packed_mud
setblock 545 260 222 minecraft:bone_block
fill 546 260 182 546 263 182 minecraft:packed_mud
fill 546 260 222 546 261 222 minecraft:packed_mud
setblock 548 260 184 minecraft:bone_block
setblock 549 260 183 minecraft:bone_block
setblock 550 260 182 minecraft:bone_block
setblock 550 260 183 minecraft:packed_mud
setblock 550 260 222 minecraft:bone_block
fill 551 260 182 551 261 182 minecraft:packed_mud
setblock 555 260 182 minecraft:bone_block
setblock 555 260 183 minecraft:packed_mud
setblock 555 260 222 minecraft:bone_block
fill 556 260 182 556 262 182 minecraft:packed_mud
fill 556 260 222 556 263 222 minecraft:packed_mud
setblock 557 260 185 minecraft:bone_block
fill 557 260 186 557 262 186 minecraft:packed_mud
fill 557 260 206 557 261 206 minecraft:packed_mud
setblock 557 260 210 minecraft:bone_block
fill 557 260 211 557 263 211 minecraft:packed_mud
setblock 557 260 215 minecraft:bone_block
setblock 558 260 184 minecraft:bone_block
fill 558 260 185 558 263 185 minecraft:packed_mud
setblock 558 260 189 minecraft:bone_block
fill 558 260 190 558 263 190 minecraft:packed_mud
fill 558 260 192 558 261 192 minecraft:packed_mud
setblock 558 260 204 minecraft:bone_block
fill 558 260 205 558 263 205 minecraft:packed_mud
setblock 558 260 209 minecraft:bone_block
fill 558 260 210 558 263 210 minecraft:packed_mud
setblock 558 260 214 minecraft:bone_block
fill 558 260 215 558 263 215 minecraft:packed_mud
setblock 558 260 219 minecraft:bone_block
fill 558 260 220 558 263 220 minecraft:packed_mud
setblock 518 261 183 minecraft:bone_block
fill 518 261 184 518 263 184 minecraft:packed_mud
setblock 518 261 188 minecraft:bone_block
fill 518 261 189 518 264 189 minecraft:packed_mud
setblock 518 261 193 minecraft:bone_block
fill 518 261 194 518 263 195 minecraft:packed_mud
fill 518 261 199 518 261 202 minecraft:packed_mud
setblock 518 261 203 minecraft:bone_block
fill 518 261 204 518 261 207 minecraft:packed_mud
setblock 518 261 208 minecraft:bone_block
fill 518 261 209 518 264 209 minecraft:packed_mud
setblock 518 261 213 minecraft:bone_block
fill 518 261 214 518 264 214 minecraft:packed_mud
setblock 518 261 218 minecraft:bone_block
fill 518 261 219 518 264 219 minecraft:packed_mud
setblock 519 261 182 minecraft:bone_block
setblock 519 261 187 minecraft:bone_block
fill 519 261 188 519 264 188 minecraft:packed_mud
setblock 519 261 191 minecraft:packed_mud
setblock 519 261 202 minecraft:bone_block
fill 519 261 203 519 264 203 minecraft:packed_mud
setblock 519 261 207 minecraft:bone_block
fill 519 261 208 519 264 208 minecraft:packed_mud
setblock 519 261 212 minecraft:bone_block
fill 519 261 213 520 263 213 minecraft:packed_mud
setblock 519 261 217 minecraft:bone_block
setblock 519 261 222 minecraft:bone_block
fill 520 261 182 520 262 182 minecraft:packed_mud
setblock 520 261 206 minecraft:bone_block
fill 520 261 207 520 264 207 minecraft:packed_mud
setblock 520 261 211 minecraft:bone_block
fill 520 261 212 520 264 212 minecraft:packed_mud
fill 520 261 222 520 262 222 minecraft:packed_mud
setblock 521 261 205 minecraft:bone_block
fill 521 261 206 521 262 206 minecraft:packed_mud
setblock 521 261 209 minecraft:packed_mud
setblock 521 261 210 minecraft:bone_block
fill 521 261 211 521 263 211 minecraft:packed_mud
setblock 524 261 182 minecraft:bone_block
setblock 535 261 182 minecraft:packed_mud
setblock 537 261 183 minecraft:packed_mud
setblock 538 261 183 minecraft:bone_block
fill 538 261 184 538 262 184 minecraft:packed_mud
setblock 539 261 182 minecraft:bone_block
fill 539 261 183 539 264 183 minecraft:packed_mud
fill 540 261 182 540 264 182 minecraft:packed_mud
setblock 540 261 185 minecraft:packed_mud
fill 540 261 222 540 262 222 minecraft:packed_mud
setblock 541 261 185 minecraft:bone_block
setblock 542 261 184 minecraft:bone_block
fill 542 261 185 542 262 185 minecraft:packed_mud
setblock 543 261 183 minecraft:bone_block
fill 543 261 184 543 263 184 minecraft:packed_mud
setblock 544 261 182 minecraft:bone_block
fill 544 261 183 544 264 183 minecraft:packed_mud
setblock 544 261 222 minecraft:bone_block
fill 545 261 182 545 264 182 minecraft:packed_mud
fill 545 261 222 545 262 222 minecraft:packed_mud
setblock 547 261 184 minecraft:bone_block
setblock 548 261 183 minecraft:bone_block
setblock 549 261 182 minecraft:bone_block
setblock 549 261 183 minecraft:packed_mud
fill 550 261 182 550 262 182 minecraft:packed_mud
setblock 554 261 182 minecraft:bone_block
fill 555 261 182 555 262 182 minecraft:packed_mud
setblock 555 261 222 minecraft:packed_mud
setblock 557 261 184 minecraft:bone_block
setblock 557 261 185 minecraft:packed_mud
setblock 557 261 209 minecraft:bone_block
fill 557 261 210 557 264 210 minecraft:packed_mud
fill 557 261 212 557 261 213 minecraft:packed_mud
setblock 557 261 214 minecraft:bone_block
fill 557 261 215 557 263 216 minecraft:packed_mud
setblock 558 261 183 minecraft:bone_block
fill 558 261 184 558 264 184 minecraft:packed_mud
setblock 558 261 188 minecraft:bone_block
fill 558 261 189 558 264 189 minecraft:packed_mud
setblock 558 261 203 minecraft:bone_block
fill 558 261 204 558 264 204 minecraft:packed_mud
setblock 558 261 208 minecraft:bone_block
fill 558 261 209 558 264 209 minecraft:packed_mud
setblock 558 261 213 minecraft:bone_block
fill 558 261 214 558 264 214 minecraft:packed_mud
setblock 558 261 218 minecraft:bone_block
fill 558 261 219 558 264 219 minecraft:packed_mud
setblock 518 262 183 minecraft:packed_mud
setblock 518 262 187 minecraft:bone_block
fill 518 262 188 518 265 188 minecraft:packed_mud
setblock 518 262 191 minecraft:packed_mud
setblock 518 262 192 minecraft:bone_block
fill 518 262 193 518 265 193 minecraft:packed_mud
setblock 518 262 196 minecraft:packed_mud
setblock 518 262 197 minecraft:bone_block
fill 518 262 198 518 262 201 minecraft:packed_mud
setblock 518 262 202 minecraft:bone_block
fill 518 262 203 518 262 206 minecraft:packed_mud
setblock 518 262 207 minecraft:bone_block
fill 518 262 208 518 265 208 minecraft:packed_mud
setblock 518 262 212 minecraft:bone_block
fill 518 262 213 518 265 213 minecraft:packed_mud
setblock 518 262 217 minecraft:bone_block
fill 518 262 218 518 265 218 minecraft:packed_mud
setblock 518 262 222 minecraft:bone_block
setblock 519 262 186 minecraft:bone_block
fill 519 262 187 519 263 187 minecraft:packed_mud
setblock 519 262 191 minecraft:bone_block
fill 519 262 192 519 265 192 minecraft:packed_mud
fill 519 262 202 519 263 202 minecraft:packed_mud
setblock 519 262 206 minecraft:bone_block
fill 519 262 207 519 265 207 minecraft:packed_mud
setblock 519 262 211 minecraft:bone_block
fill 519 262 212 519 265 212 minecraft:packed_mud
setblock 519 262 215 minecraft:packed_mud
setblock 519 262 216 minecraft:bone_block
fill 519 262 217 519 265 217 minecraft:packed_mud
setblock 519 262 222 minecraft:packed_mud
setblock 520 262 205 minecraft:bone_block
fill 520 262 206 520 265 206 minecraft:packed_mud
setblock 520 262 210 minecraft:bone_block
fill 520 262 211 520 265 211 minecraft:packed_mud
setblock 520 262 215 minecraft:bone_block
setblock 521 262 209 minecraft:bone_block
fill 521 262 210 521 264 210 minecraft:packed_mud
setblock 537 262 183 minecraft:bone_block
setblock 538 262 182 minecraft:bone_block
fill 538 262 183 538 265 183 minecraft:packed_mud
fill 539 262 182 539 265 182 minecraft:packed_mud
fill 539 262 184 539 263 184 minecraft:packed_mud
setblock 540 262 185 minecraft:bone_block
setblock 541 262 184 minecraft:bone_block
setblock 541 262 185 minecraft:packed_mud
setblock 542 262 183 minecraft:bone_block
fill 542 262 184 542 263 184 minecraft:packed_mud
setblock 543 262 182 minecraft:bone_block
fill 543 262 183 543 265 183 minecraft:packed_mud
setblock 543 262 222 minecraft:bone_block
fill 544 262 182 544 265 182 minecraft:packed_mud
setblock 544 262 222 minecraft:packed_mud
setblock 547 262 183 minecraft:bone_block
setblock 548 262 182 minecraft:bone_block
setblock 549 262 182 minecraft:packed_mud
setblock 557 262 208 minecraft:bone_block
fill 557 262 209 557 265 209 minecraft:packed_mud
setblock 557 262 212 minecraft:packed_mud
setblock 557 262 213 minecraft:bone_block
fill 557 262 214 557 265 214 minecraft:packed_mud
setblock 557 262 217 minecraft:packed_mud
setblock 558 262 182 minecraft:bone_block
fill 558 262 183 558 264 183 minecraft:packed_mud
setblock 558 262 187 minecraft:bone_block
fill 558 262 188 558 265 188 minecraft:packed_mud
setblock 558 262 192 minecraft:bone_block
setblock 558 262 203 minecraft:packed_mud
setblock 558 262 207 minecraft:bone_block
fill 558 262 208 558 265 208 minecraft:packed_mud
setblock 558 262 212 minecraft:bone_block
fill 558 262 213 558 265 213 minecraft:packed_mud
setblock 558 262 217 minecraft:bone_block
fill 558 262 218 558 265 218 minecraft:packed_mud
setblock 558 262 222 minecraft:bone_block
setblock 518 263 186 minecraft:bone_block
fill 518 263 187 518 266 187 minecraft:packed_mud
setblock 518 263 190 minecraft:packed_mud
setblock 518 263 191 minecraft:bone_block
fill 518 263 192 518 266 192 minecraft:packed_mud
setblock 518 263 196 minecraft:bone_block
fill 518 263 197 518 263 200 minecraft:packed_mud
setblock 518 263 201 minecraft:bone_block
fill 518 263 202 518 263 205 minecraft:packed_mud
setblock 518 263 206 minecraft:bone_block
fill 518 263 207 518 266 207 minecraft:packed_mud
setblock 518 263 211 minecraft:bone_block
fill 518 263 212 518 266 212 minecraft:packed_mud
setblock 518 263 216 minecraft:bone_block
fill 518 263 217 518 266 217 minecraft:packed_mud
setblock 519 263 190 minecraft:bone_block
fill 519 263 191 519 266 191 minecraft:packed_mud
fill 519 263 193 519 264 193 minecraft:packed_mud
setblock 519 263 205 minecraft:bone_block
fill 519 263 206 519 266 206 minecraft:packed_mud
setblock 519 263 210 minecraft:bone_block
fill 519 263 211 519 266 211 minecraft:packed_mud
setblock 519 263 215 minecraft:bone_block
fill 519 263 216 519 266 216 minecraft:packed_mud
setblock 520 263 184 minecraft:light[level=11]
setblock 520 263 192 minecraft:light[level=11]
setblock 520 263 200 minecraft:light[level=11]
setblock 520 263 205 minecraft:packed_mud
setblock 520 263 209 minecraft:bone_block
fill 520 263 210 520 266 210 minecraft:packed_mud
setblock 520 263 214 minecraft:bone_block
fill 520 263 215 520 266 215 minecraft:packed_mud
setblock 520 263 216 minecraft:light[level=11]
setblock 521 263 208 minecraft:bone_block
setblock 521 263 209 minecraft:packed_mud
setblock 528 263 184 minecraft:light[level=11]
setblock 528 263 192 minecraft:light[level=11]
setblock 528 263 200 minecraft:light[level=11]
setblock 528 263 208 minecraft:light[level=11]
setblock 528 263 216 minecraft:light[level=11]
setblock 536 263 184 minecraft:light[level=11]
setblock 536 263 192 minecraft:light[level=11]
setblock 536 263 208 minecraft:light[level=11]
setblock 536 263 216 minecraft:light[level=11]
setblock 537 263 182 minecraft:bone_block
fill 537 263 183 537 266 183 minecraft:packed_mud
fill 538 263 182 538 266 182 minecraft:packed_mud
setblock 540 263 184 minecraft:bone_block
setblock 541 263 183 minecraft:bone_block
fill 541 263 184 541 264 184 minecraft:packed_mud
setblock 542 263 182 minecraft:bone_block
fill 542 263 183 542 266 183 minecraft:packed_mud
setblock 542 263 222 minecraft:bone_block
fill 543 263 182 543 266 182 minecraft:packed_mud
setblock 543 263 222 minecraft:packed_mud
setblock 544 263 184 minecraft:light[level=11]
setblock 544 263 192 minecraft:light[level=11]
setblock 544 263 200 minecraft:light[level=11]
setblock 544 263 208 minecraft:light[level=11]
setblock 544 263 216 minecraft:light[level=11]
setblock 547 263 182 minecraft:bone_block
setblock 552 263 184 minecraft:light[level=11]
setblock 552 263 192 minecraft:light[level=11]
setblock 552 263 200 minecraft:light[level=11]
setblock 552 263 208 minecraft:light[level=11]
setblock 552 263 216 minecraft:light[level=11]
setblock 557 263 182 minecraft:bone_block
setblock 557 263 207 minecraft:bone_block
fill 557 263 208 557 266 208 minecraft:packed_mud
setblock 557 263 212 minecraft:bone_block
fill 557 263 213 557 266 213 minecraft:packed_mud
setblock 557 263 217 minecraft:bone_block
fill 557 263 218 557 266 218 minecraft:packed_mud
setblock 557 263 222 minecraft:bone_block
fill 558 263 182 558 264 182 minecraft:packed_mud
setblock 558 263 186 minecraft:bone_block
fill 558 263 187 558 266 187 minecraft:packed_mud
setblock 558 263 191 minecraft:bone_block
fill 558 263 192 558 265 193 minecraft:packed_mud
setblock 558 263 206 minecraft:bone_block
fill 558 263 207 558 266 207 minecraft:packed_mud
setblock 558 263 211 minecraft:bone_block
fill 558 263 212 558 266 212 minecraft:packed_mud
setblock 558 263 216 minecraft:bone_block
fill 558 263 217 558 266 217 minecraft:packed_mud
setblock 558 263 221 minecraft:bone_block
fill 558 263 222 558 266 222 minecraft:packed_mud
setblock 518 264 185 minecraft:bone_block
fill 518 264 186 518 267 186 minecraft:packed_mud
setblock 518 264 190 minecraft:bone_block
fill 518 264 191 518 267 191 minecraft:packed_mud
setblock 518 264 194 minecraft:packed_mud
setblock 518 264 195 minecraft:bone_block
fill 518 264 196 518 264 199 minecraft:packed_mud
setblock 518 264 200 minecraft:bone_block
fill 518 264 201 518 264 204 minecraft:packed_mud
setblock 518 264 205 minecraft:bone_block
fill 518 264 206 518 267 206 minecraft:packed_mud
setblock 518 264 210 minecraft:bone_block
fill 518 264 211 518 267 211 minecraft:packed_mud
setblock 518 264 215 minecraft:bone_block
fill 518 264 216 518 267 216 minecraft:packed_mud
setblock 518 264 220 minecraft:bone_block
setblock 519 264 189 minecraft:bone_block
fill 519 264 190 519 267 190 minecraft:packed_mud
setblock 519 264 194 minecraft:bone_block
fill 519 264 195 519 267 195 minecraft:packed_mud
setblock 519 264 204 minecraft:bone_block
fill 519 264 205 519 267 205 minecraft:packed_mud
setblock 519 264 209 minecraft:bone_block
fill 519 264 210 519 267 210 minecraft:packed_mud
setblock 519 264 213 minecraft:packed_mud
setblock 519 264 214 minecraft:bone_block
fill 519 264 215 519 267 215 minecraft:packed_mud
setblock 520 264 208 minecraft:bone_block
fill 520 264 209 520 267 209 minecraft:packed_mud
setblock 520 264 213 minecraft:bone_block
fill 520 264 214 520 267 214 minecraft:packed_mud
setblock 536 264 182 minecraft:bone_block
fill 537 264 182 537 267 182 minecraft:packed_mud
setblock 539 264 184 minecraft:bone_block
setblock 540 264 183 minecraft:bone_block
setblock 540 264 184 minecraft:packed_mud
setblock 541 264 182 minecraft:bone_block
fill 541 264 183 541 267 183 minecraft:packed_mud
setblock 541 264 222 minecraft:bone_block
fill 542 264 182 542 267 182 minecraft:packed_mud
fill 542 264 222 542 267 222 minecraft:packed_mud
setblock 546 264 182 minecraft:bone_block
setblock 556 264 211 minecraft:packed_mud
setblock 556 264 212 minecraft:bone_block
fill 556 264 213 556 266 214 minecraft:packed_mud
setblock 556 264 222 minecraft:bone_block
fill 557 264 207 557 267 207 minecraft:packed_mud
setblock 557 264 211 minecraft:bone_block
fill 557 264 212 557 267 212 minecraft:packed_mud
setblock 557 264 215 minecraft:packed_mud
setblock 557 264 216 minecraft:bone_block
fill 557 264 217 557 267 217 minecraft:packed_mud
fill 557 264 219 557 265 219 minecraft:packed_mud
fill 557 264 222 557 267 222 minecraft:packed_mud
setblock 558 264 185 minecraft:bone_block
fill 558 264 186 558 267 186 minecraft:packed_mud
setblock 558 264 190 minecraft:bone_block
fill 558 264 191 558 267 191 minecraft:packed_mud
setblock 558 264 194 minecraft:packed_mud
setblock 558 264 205 minecraft:bone_block
fill 558 264 206 558 267 206 minecraft:packed_mud
setblock 558 264 210 minecraft:bone_block
fill 558 264 211 558 267 211 minecraft:packed_mud
setblock 558 264 215 minecraft:bone_block
fill 558 264 216 558 267 216 minecraft:packed_mud
setblock 558 264 220 minecraft:bone_block
fill 558 264 221 558 267 221 minecraft:packed_mud
setblock 518 265 185 minecraft:packed_mud
setblock 518 265 189 minecraft:bone_block
fill 518 265 190 518 268 190 minecraft:packed_mud
setblock 518 265 194 minecraft:bone_block
fill 518 265 195 518 265 198 minecraft:packed_mud
setblock 518 265 199 minecraft:bone_block
fill 518 265 200 518 265 203 minecraft:packed_mud
setblock 518 265 204 minecraft:bone_block
fill 518 265 205 518 268 205 minecraft:packed_mud
setblock 518 265 209 minecraft:bone_block
fill 518 265 210 518 268 210 minecraft:packed_mud
setblock 518 265 214 minecraft:bone_block
fill 518 265 215 518 268 215 minecraft:packed_mud
setblock 518 265 219 minecraft:bone_block
fill 518 265 220 518 268 220 minecraft:packed_mud
setblock 519 265 188 minecraft:bone_block
fill 519 265 189 519 268 189 minecraft:packed_mud
setblock 519 265 193 minecraft:bone_block
fill 519 265 194 519 268 194 minecraft:packed_mud
fill 519 265 196 519 265 197 minecraft:packed_mud
setblock 519 265 203 minecraft:bone_block
fill 519 265 204 519 268 204 minecraft:packed_mud
setblock 519 265 208 minecraft:bone_block
fill 519 265 209 519 268 209 minecraft:packed_mud
setblock 519 265 213 minecraft:bone_block
fill 519 265 214 519 268 214 minecraft:packed_mud
setblock 519 265 218 minecraft:bone_block
setblock 520 265 207 minecraft:bone_block
fill 520 265 208 520 268 208 minecraft:packed_mud
setblock 520 265 212 minecraft:bone_block
fill 520 265 213 520 268 213 minecraft:packed_mud
fill 536 265 182 536 268 182 minecraft:packed_mud
setblock 539 265 183 minecraft:bone_block
setblock 540 265 182 minecraft:bone_block
fill 540 265 183 540 268 183 minecraft:packed_mud
setblock 540 265 222 minecraft:bone_block
fill 541 265 182 541 268 182 minecraft:packed_mud
fill 541 265 222 541 268 222 minecraft:packed_mud
setblock 545 265 182 minecraft:bone_block
setblock 555 265 222 minecraft:bone_block
setblock 556 265 211 minecraft:bone_block
fill 556 265 212 556 268 212 minecraft:packed_mud
setblock 556 265 215 minecraft:packed_mud
setblock 556 265 216 minecraft:bone_block
fill 556 265 222 556 268 222 minecraft:packed_mud
setblock 557 265 210 minecraft:bone_block
fill 557 265 211 557 268 211 minecraft:packed_mud
setblock 557 265 215 minecraft:bone_block
fill 557 265 216 557 268 216 minecraft:packed_mud
setblock 557 265 220 minecraft:bone_block
setblock 558 265 184 minecraft:bone_block
fill 558 265 185 558 268 185 minecraft:packed_mud
setblock 558 265 189 minecraft:bone_block
fill 558 265 190 558 268 190 minecraft:packed_mud
setblock 558 265 194 minecraft:bone_block
fill 558 265 195 558 268 195 minecraft:packed_mud
setblock 558 265 204 minecraft:bone_block
fill 558 265 205 558 268 205 minecraft:packed_mud
setblock 558 265 209 minecraft:bone_block
fill 558 265 210 558 268 210 minecraft:packed_mud
setblock 558 265 214 minecraft:bone_block
fill 558 265 215 558 268 215 minecraft:packed_mud
setblock 558 265 219 minecraft:bone_block
fill 558 265 220 558 268 220 minecraft:packed_mud
setblock 518 266 188 minecraft:bone_block
fill 518 266 189 518 269 189 minecraft:packed_mud
setblock 518 266 193 minecraft:bone_block
fill 518 266 194 518 266 197 minecraft:packed_mud
setblock 518 266 198 minecraft:bone_block
fill 518 266 199 518 266 202 minecraft:packed_mud
setblock 518 266 203 minecraft:bone_block
fill 518 266 204 518 269 204 minecraft:packed_mud
setblock 518 266 208 minecraft:bone_block
fill 518 266 209 518 269 209 minecraft:packed_mud
setblock 518 266 213 minecraft:bone_block
fill 518 266 214 518 269 214 minecraft:packed_mud
setblock 518 266 218 minecraft:bone_block
fill 518 266 219 518 269 219 minecraft:packed_mud
fill 518 266 221 518 267 221 minecraft:packed_mud
fill 519 266 188 519 269 188 minecraft:packed_mud
setblock 519 266 192 minecraft:bone_block
fill 519 266 193 520 268 193 minecraft:packed_mud
setblock 519 266 196 minecraft:packed_mud
setblock 519 266 197 minecraft:bone_block
fill 519 266 198 519 266 201 minecraft:packed_mud
setblock 519 266 202 minecraft:bone_block
fill 519 266 203 519 269 203 minecraft:packed_mud
setblock 519 266 207 minecraft:bone_block
fill 519 266 208 519 269 208 minecraft:packed_mud
setblock 519 266 212 minecraft:bone_block
fill 519 266 213 519 269 213 minecraft:packed_mud
setblock 519 266 217 minecraft:bone_block
fill 519 266 218 519 269 218 minecraft:packed_mud
fill 520 266 192 520 269 192 minecraft:packed_mud
fill 520 266 194 520 267 194 minecraft:packed_mud
setblock 520 266 207 minecraft:packed_mud
setblock 520 266 211 minecraft:bone_block
fill 520 266 212 520 269 212 minecraft:packed_mud
fill 535 266 182 535 269 182 minecraft:packed_mud
setblock 538 266 183 minecraft:bone_block
setblock 538 266 222 minecraft:packed_mud
setblock 539 266 182 minecraft:bone_block
fill 539 266 183 539 269 183 minecraft:packed_mud
setblock 539 266 222 minecraft:bone_block
fill 540 266 182 540 269 182 minecraft:packed_mud
fill 540 266 222 540 269 222 minecraft:packed_mud
setblock 543 266 222 minecraft:packed_mud
setblock 544 266 182 minecraft:bone_block
setblock 554 266 222 minecraft:bone_block
fill 555 266 222 555 269 222 minecraft:packed_mud
setblock 556 266 210 minecraft:bone_block
fill 556 266 211 556 269 211 minecraft:packed_mud
setblock 556 266 215 minecraft:bone_block
fill 556 266 216 556 268 217 minecraft:packed_mud
fill 557 266 190 557 268 191 minecraft:packed_mud
setblock 557 266 209 minecraft:bone_block
fill 557 266 210 557 269 210 minecraft:packed_mud
setblock 557 266 214 minecraft:bone_block
fill 557 266 215 557 269 215 minecraft:packed_mud
setblock 557 266 219 minecraft:bone_block
fill 557 266 220 557 268 221 minecraft:packed_mud
setblock 558 266 184 minecraft:packed_mud
setblock 558 266 188 minecraft:bone_block
fill 558 266 189 558 269 189 minecraft:packed_mud
setblock 558 266 192 minecraft:packed_mud
setblock 558 266 193 minecraft:bone_block
fill 558 266 194 558 269 194 minecraft:packed_mud
fill 558 266 196 558 266 197 minecraft:packed_mud
setblock 558 266 198 minecraft:bone_block
setblock 558 266 203 minecraft:bone_block
fill 558 266 204 558 269 204 minecraft:packed_mud
setblock 558 266 208 minecraft:bone_block
fill 558 266 209 558 269 209 minecraft:packed_mud
setblock 558 266 213 minecraft:bone_block
fill 558 266 214 558 269 214 minecraft:packed_mud
setblock 558 266 218 minecraft:bone_block
fill 558 266 219 558 269 219 minecraft:packed_mud
setblock 518 267 187 minecraft:bone_block
fill 518 267 188 518 270 188 minecraft:packed_mud
setblock 518 267 192 minecraft:bone_block
fill 518 267 193 518 267 196 minecraft:packed_mud
setblock 518 267 197 minecraft:bone_block
fill 518 267 198 518 267 201 minecraft:packed_mud
setblock 518 267 202 minecraft:bone_block
fill 518 267 203 518 270 203 minecraft:packed_mud
setblock 518 267 207 minecraft:bone_block
fill 518 267 208 518 270 208 minecraft:packed_mud
setblock 518 267 212 minecraft:bone_block
fill 518 267 213 518 270 213 minecraft:packed_mud
setblock 518 267 217 minecraft:bone_block
fill 518 267 218 518 270 218 minecraft:packed_mud
setblock 518 267 222 minecraft:bone_block
setblock 519 267 191 minecraft:bone_block
fill 519 267 192 519 270 192 minecraft:packed_mud
setblock 519 267 196 minecraft:bone_block
fill 519 267 197 519 267 200 minecraft:packed_mud
setblock 519 267 201 minecraft:bone_block
fill 519 267 202 519 270 202 minecraft:packed_mud
setblock 519 267 206 minecraft:bone_block
fill 519 267 207 519 270 207 minecraft:packed_mud
setblock 519 267 211 minecraft:bone_block
fill 519 267 212 519 270 212 minecraft:packed_mud
setblock 519 267 216 minecraft:bone_block
fill 519 267 217 519 270 217 minecraft:packed_mud
fill 519 267 219 519 268 219 minecraft:packed_mud
fill 520 267 191 520 270 191 minecraft:packed_mud
setblock 520 267 195 minecraft:bone_block
fill 520 267 196 520 270 196 minecraft:packed_mud
setblock 520 267 210 minecraft:bone_block
fill 520 267 211 520 270 211 minecraft:packed_mud
setblock 520 267 215 minecraft:bone_block
fill 520 267 216 520 270 216 minecraft:packed_mud
fill 534 267 182 534 270 182 minecraft:packed_mud
setblock 536 267 183 minecraft:packed_mud
setblock 537 267 183 minecraft:bone_block
setblock 537 267 222 minecraft:packed_mud
setblock 538 267 182 minecraft:bone_block
fill 538 267 183 538 270 183 minecraft:packed_mud
setblock 538 267 222 minecraft:bone_block
fill 539 267 182 539 270 182 minecraft:packed_mud
fill 539 267 222 539 270 222 minecraft:packed_mud
setblock 543 267 182 minecraft:bone_block
setblock 543 267 222 minecraft:bone_block
fill 544 267 182 544 270 182 minecraft:packed_mud
setblock 552 267 222 minecraft:packed_mud
setblock 553 267 222 minecraft:bone_block
fill 554 267 222 554 270 222 minecraft:packed_mud
fill 555 267 221 556 269 221 minecraft:packed_mud
fill 556 267 210 556 270 210 minecraft:packed_mud
setblock 556 267 213 minecraft:packed_mud
setblock 556 267 214 minecraft:bone_block
fill 556 267 215 556 270 215 minecraft:packed_mud
setblock 556 267 218 minecraft:packed_mud
setblock 556 267 219 minecraft:bone_block
schedule function dropper:buildpart/47_10 1t
