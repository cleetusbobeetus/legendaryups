fill 145 84 557 145 90 557 minecraft:black_concrete
fill 145 84 584 148 85 584 minecraft:waxed_copper_block
fill 145 84 590 148 85 590 minecraft:waxed_copper_block
fill 146 84 585 146 85 586 minecraft:waxed_cut_copper
fill 146 84 588 146 85 589 minecraft:waxed_cut_copper
fill 148 84 585 149 85 585 minecraft:waxed_copper_block
fill 148 84 589 149 85 589 minecraft:waxed_copper_block
fill 149 84 586 149 85 588 minecraft:waxed_copper_block
fill 155 84 599 155 90 599 minecraft:black_concrete
fill 161 84 557 161 90 557 minecraft:black_concrete
fill 171 84 599 171 90 599 minecraft:black_concrete
fill 177 84 557 177 90 557 minecraft:black_concrete
fill 181 84 557 181 128 557 minecraft:black_concrete
fill 183 84 567 183 90 567 minecraft:black_concrete
fill 183 84 583 183 90 583 minecraft:black_concrete
setblock 170 85 557 minecraft:shroomlight
setblock 183 85 568 minecraft:shroomlight
setblock 141 86 593 minecraft:white_concrete
fill 170 86 557 170 128 557 minecraft:black_concrete
fill 183 86 568 183 128 568 minecraft:black_concrete
setblock 183 86 581 minecraft:shroomlight
fill 141 87 593 141 111 593 minecraft:black_concrete
setblock 141 87 595 minecraft:shroomlight
fill 183 87 581 183 128 581 minecraft:black_concrete
fill 141 88 595 141 91 595 minecraft:black_concrete
setblock 144 88 560 minecraft:light[level=14]
setblock 144 88 568 minecraft:light[level=14]
setblock 144 88 576 minecraft:light[level=14]
setblock 144 88 584 minecraft:light[level=14]
setblock 144 88 592 minecraft:light[level=14]
setblock 152 88 560 minecraft:light[level=14]
setblock 152 88 568 minecraft:light[level=14]
setblock 152 88 576 minecraft:light[level=14]
setblock 152 88 584 minecraft:light[level=14]
setblock 152 88 592 minecraft:light[level=14]
setblock 160 88 560 minecraft:light[level=14]
setblock 160 88 568 minecraft:light[level=14]
setblock 160 88 576 minecraft:light[level=14]
setblock 160 88 584 minecraft:light[level=14]
setblock 160 88 592 minecraft:light[level=14]
setblock 168 88 560 minecraft:light[level=14]
setblock 168 88 568 minecraft:light[level=14]
setblock 168 88 576 minecraft:light[level=14]
setblock 168 88 584 minecraft:light[level=14]
setblock 168 88 592 minecraft:light[level=14]
setblock 168 88 599 minecraft:shroomlight
fill 169 88 599 169 129 599 minecraft:black_concrete
setblock 176 88 560 minecraft:light[level=14]
setblock 176 88 568 minecraft:light[level=14]
setblock 176 88 576 minecraft:light[level=14]
setblock 176 88 584 minecraft:light[level=14]
setblock 176 88 592 minecraft:light[level=14]
setblock 183 88 576 minecraft:shroomlight
setblock 141 89 559 minecraft:shroomlight
setblock 141 89 588 minecraft:shroomlight
fill 141 89 589 141 128 589 minecraft:black_concrete
fill 168 89 599 168 96 599 minecraft:black_concrete
setblock 183 89 563 minecraft:shroomlight
fill 183 89 576 183 124 576 minecraft:black_concrete
fill 141 90 559 141 111 559 minecraft:black_concrete
setblock 141 90 579 minecraft:shroomlight
fill 141 90 588 141 128 588 minecraft:black_concrete
setblock 147 90 599 minecraft:white_concrete
fill 148 90 599 149 110 599 minecraft:black_concrete
setblock 153 90 599 minecraft:shroomlight
fill 183 90 563 183 124 563 minecraft:black_concrete
fill 141 91 565 141 92 565 minecraft:gold_block
fill 141 91 579 141 129 579 minecraft:black_concrete
fill 141 91 581 141 92 581 minecraft:gold_block
fill 141 91 597 141 92 597 minecraft:gold_block
fill 145 91 557 145 92 557 minecraft:gold_block
fill 147 91 599 147 124 599 minecraft:black_concrete
fill 153 91 599 153 126 599 minecraft:black_concrete
fill 155 91 599 155 92 599 minecraft:gold_block
fill 161 91 557 161 92 557 minecraft:gold_block
fill 171 91 599 171 92 599 minecraft:gold_block
fill 177 91 557 177 92 557 minecraft:gold_block
setblock 183 91 562 minecraft:white_concrete
fill 183 91 567 183 92 567 minecraft:gold_block
fill 183 91 571 183 109 571 minecraft:black_concrete
setblock 183 91 572 minecraft:shroomlight
fill 183 91 583 183 92 583 minecraft:gold_block
setblock 183 91 596 minecraft:shroomlight
setblock 141 92 595 minecraft:white_concrete
setblock 160 92 557 minecraft:white_concrete
fill 183 92 562 183 126 562 minecraft:black_concrete
fill 183 92 572 183 112 572 minecraft:black_concrete
fill 183 92 596 183 128 596 minecraft:black_concrete
setblock 141 93 564 minecraft:shroomlight
fill 141 93 565 141 99 565 minecraft:black_concrete
fill 141 93 581 141 94 581 minecraft:black_concrete
fill 141 93 595 141 128 595 minecraft:black_concrete
fill 141 93 597 141 99 597 minecraft:black_concrete
fill 145 93 557 145 99 557 minecraft:black_concrete
fill 155 93 599 155 99 599 minecraft:black_concrete
fill 160 93 557 161 99 557 minecraft:black_concrete
fill 171 93 599 171 99 599 minecraft:black_concrete
fill 177 93 557 177 99 557 minecraft:black_concrete
fill 183 93 567 183 99 567 minecraft:black_concrete
fill 183 93 583 183 99 583 minecraft:black_concrete
setblock 183 93 588 minecraft:white_concrete
fill 141 94 564 141 115 564 minecraft:black_concrete
setblock 144 94 599 minecraft:white_concrete
fill 183 94 588 183 128 588 minecraft:black_concrete
setblock 141 95 569 minecraft:shroomlight
fill 141 95 570 141 96 570 minecraft:black_concrete
setblock 141 95 581 minecraft:shroomlight
fill 144 95 599 144 126 599 minecraft:black_concrete
setblock 178 95 599 minecraft:shroomlight
setblock 179 95 557 minecraft:white_concrete
fill 179 95 599 179 128 599 minecraft:black_concrete
fill 180 95 599 181 95 599 minecraft:shroomlight
fill 141 96 569 141 125 569 minecraft:black_concrete
fill 141 96 581 141 99 581 minecraft:black_concrete
setblock 144 96 560 minecraft:light[level=14]
setblock 144 96 568 minecraft:light[level=14]
setblock 144 96 576 minecraft:light[level=14]
setblock 144 96 584 minecraft:light[level=14]
setblock 144 96 592 minecraft:light[level=14]
setblock 152 96 560 minecraft:light[level=14]
setblock 152 96 568 minecraft:light[level=14]
setblock 152 96 576 minecraft:light[level=14]
setblock 152 96 584 minecraft:light[level=14]
setblock 152 96 592 minecraft:light[level=14]
setblock 160 96 560 minecraft:light[level=14]
setblock 160 96 568 minecraft:light[level=14]
setblock 160 96 576 minecraft:light[level=14]
setblock 160 96 584 minecraft:light[level=14]
setblock 160 96 592 minecraft:light[level=14]
setblock 163 96 599 minecraft:shroomlight
setblock 168 96 560 minecraft:light[level=14]
setblock 168 96 568 minecraft:light[level=14]
setblock 168 96 576 minecraft:light[level=14]
setblock 168 96 584 minecraft:light[level=14]
setblock 168 96 592 minecraft:light[level=14]
setblock 173 96 557 minecraft:shroomlight
setblock 176 96 560 minecraft:light[level=14]
setblock 176 96 568 minecraft:light[level=14]
setblock 176 96 576 minecraft:light[level=14]
setblock 176 96 584 minecraft:light[level=14]
setblock 176 96 592 minecraft:light[level=14]
fill 178 96 599 178 128 599 minecraft:black_concrete
fill 179 96 557 179 128 557 minecraft:black_concrete
fill 180 96 599 181 105 599 minecraft:black_concrete
setblock 182 96 599 minecraft:white_concrete
fill 183 96 599 183 124 599 minecraft:black_concrete
setblock 141 97 570 minecraft:shroomlight
fill 142 97 565 148 97 565 minecraft:polished_blackstone
fill 144 97 563 148 98 564 minecraft:polished_blackstone
fill 144 97 566 148 98 567 minecraft:polished_blackstone
fill 155 97 557 155 128 557 minecraft:black_concrete
setblock 156 97 557 minecraft:shroomlight
fill 157 97 557 157 128 557 minecraft:black_concrete
fill 163 97 599 163 109 599 minecraft:black_concrete
setblock 168 97 599 minecraft:white_concrete
fill 173 97 557 173 128 557 minecraft:black_concrete
fill 182 97 599 182 128 599 minecraft:black_concrete
fill 141 98 570 141 128 570 minecraft:black_concrete
fill 144 98 565 148 98 565 minecraft:polished_blackstone
fill 156 98 557 156 114 557 minecraft:black_concrete
setblock 156 98 599 minecraft:shroomlight
setblock 157 98 599 minecraft:white_concrete
fill 168 98 599 168 128 599 minecraft:black_concrete
setblock 154 99 557 minecraft:white_concrete
fill 156 99 599 157 120 599 minecraft:black_concrete
setblock 183 99 574 minecraft:shroomlight
fill 141 100 565 141 101 565 minecraft:gold_block
fill 141 100 581 141 101 581 minecraft:gold_block
fill 141 100 597 141 101 597 minecraft:gold_block
fill 145 100 557 145 101 557 minecraft:gold_block
fill 154 100 557 154 128 557 minecraft:black_concrete
fill 155 100 599 155 101 599 minecraft:gold_block
fill 160 100 557 160 124 557 minecraft:black_concrete
fill 161 100 557 161 101 557 minecraft:gold_block
fill 171 100 599 171 101 599 minecraft:gold_block
fill 177 100 557 177 101 557 minecraft:gold_block
fill 183 100 567 183 101 567 minecraft:gold_block
fill 183 100 574 183 110 574 minecraft:black_concrete
fill 183 100 583 183 101 583 minecraft:gold_block
setblock 141 101 560 minecraft:shroomlight
fill 141 101 561 141 109 561 minecraft:black_concrete
setblock 183 101 559 minecraft:shroomlight
fill 141 102 560 141 128 560 minecraft:black_concrete
fill 141 102 565 141 108 565 minecraft:black_concrete
fill 141 102 581 141 108 581 minecraft:black_concrete
fill 141 102 597 141 108 597 minecraft:black_concrete
fill 143 102 563 143 103 567 minecraft:waxed_copper_block
fill 144 102 562 144 103 563 minecraft:waxed_copper_block
fill 144 102 565 148 103 565 minecraft:waxed_cut_copper
fill 144 102 567 144 103 568 minecraft:waxed_copper_block
fill 145 102 557 145 108 557 minecraft:black_concrete
fill 145 102 562 148 103 562 minecraft:waxed_copper_block
fill 145 102 568 147 103 568 minecraft:waxed_copper_block
fill 145 102 573 145 103 583 minecraft:waxed_cut_copper
fill 146 102 563 146 103 564 minecraft:waxed_cut_copper
fill 146 102 566 146 103 567 minecraft:waxed_cut_copper
fill 146 102 570 146 103 577 minecraft:waxed_cut_copper
fill 146 102 579 146 103 586 minecraft:waxed_cut_copper
fill 147 102 569 147 103 572 minecraft:waxed_cut_copper
fill 147 102 584 147 103 587 minecraft:waxed_cut_copper
fill 148 102 563 149 103 563 minecraft:waxed_copper_block
fill 148 102 567 148 103 570 minecraft:waxed_cut_copper
fill 148 102 586 148 103 589 minecraft:waxed_cut_copper
fill 149 102 564 149 103 565 minecraft:waxed_copper_block
fill 149 102 566 149 103 568 minecraft:waxed_cut_copper
fill 149 102 588 149 103 590 minecraft:waxed_cut_copper
fill 150 102 565 150 103 567 minecraft:waxed_cut_copper
fill 150 102 589 150 103 591 minecraft:waxed_cut_copper
fill 151 102 564 151 103 566 minecraft:waxed_cut_copper
fill 151 102 590 151 103 592 minecraft:waxed_cut_copper
fill 152 102 564 152 103 565 minecraft:waxed_cut_copper
fill 152 102 591 152 103 592 minecraft:waxed_cut_copper
fill 153 102 563 154 103 564 minecraft:waxed_cut_copper
fill 153 102 592 154 103 593 minecraft:waxed_cut_copper
fill 154 102 562 161 103 562 minecraft:waxed_cut_copper
fill 154 102 594 161 103 594 minecraft:waxed_cut_copper
fill 155 102 563 156 103 563 minecraft:waxed_cut_copper
fill 155 102 593 156 103 593 minecraft:waxed_cut_copper
fill 155 102 599 155 108 599 minecraft:black_concrete
fill 157 102 561 167 103 561 minecraft:waxed_cut_copper
fill 157 102 595 167 103 595 minecraft:waxed_cut_copper
fill 161 102 557 161 108 557 minecraft:black_concrete
fill 163 102 562 170 103 562 minecraft:waxed_cut_copper
fill 163 102 594 170 103 594 minecraft:waxed_cut_copper
fill 168 102 563 171 103 563 minecraft:waxed_cut_copper
fill 168 102 593 171 103 593 minecraft:waxed_cut_copper
fill 170 102 564 173 103 564 minecraft:waxed_cut_copper
fill 170 102 592 173 103 592 minecraft:waxed_cut_copper
fill 171 102 599 171 108 599 minecraft:black_concrete
fill 172 102 565 174 103 565 minecraft:waxed_cut_copper
fill 172 102 591 174 103 591 minecraft:waxed_cut_copper
fill 173 102 566 175 103 566 minecraft:waxed_cut_copper
fill 173 102 590 175 103 590 minecraft:waxed_cut_copper
fill 174 102 567 176 103 567 minecraft:waxed_cut_copper
fill 174 102 589 176 103 589 minecraft:waxed_cut_copper
fill 175 102 568 176 103 568 minecraft:waxed_cut_copper
fill 175 102 588 176 103 588 minecraft:waxed_cut_copper
fill 176 102 569 177 103 570 minecraft:waxed_cut_copper
fill 176 102 586 177 103 587 minecraft:waxed_cut_copper
fill 177 102 557 177 108 557 minecraft:black_concrete
fill 177 102 571 178 103 572 minecraft:waxed_cut_copper
fill 177 102 584 178 103 585 minecraft:waxed_cut_copper
fill 178 102 570 178 103 570 minecraft:waxed_cut_copper
fill 178 102 573 179 103 577 minecraft:waxed_cut_copper
fill 178 102 579 179 103 583 minecraft:waxed_cut_copper
fill 178 102 586 178 103 586 minecraft:waxed_cut_copper
fill 179 102 578 179 103 578 minecraft:waxed_cut_copper
fill 183 102 559 183 115 559 minecraft:black_concrete
fill 183 102 567 183 108 567 minecraft:black_concrete
fill 183 102 583 183 108 583 minecraft:black_concrete
setblock 144 104 560 minecraft:light[level=14]
setblock 144 104 568 minecraft:light[level=14]
setblock 144 104 576 minecraft:light[level=14]
setblock 144 104 584 minecraft:light[level=14]
setblock 144 104 592 minecraft:light[level=14]
setblock 152 104 560 minecraft:light[level=14]
setblock 152 104 568 minecraft:light[level=14]
setblock 152 104 576 minecraft:light[level=14]
setblock 152 104 584 minecraft:light[level=14]
setblock 152 104 592 minecraft:light[level=14]
setblock 160 104 560 minecraft:light[level=14]
setblock 160 104 568 minecraft:light[level=14]
setblock 160 104 576 minecraft:light[level=14]
setblock 160 104 584 minecraft:light[level=14]
setblock 160 104 592 minecraft:light[level=14]
setblock 168 104 560 minecraft:light[level=14]
setblock 168 104 568 minecraft:light[level=14]
setblock 168 104 576 minecraft:light[level=14]
setblock 168 104 584 minecraft:light[level=14]
setblock 168 104 592 minecraft:light[level=14]
setblock 176 104 560 minecraft:light[level=14]
setblock 176 104 568 minecraft:light[level=14]
setblock 176 104 576 minecraft:light[level=14]
setblock 176 104 584 minecraft:light[level=14]
setblock 176 104 592 minecraft:light[level=14]
fill 179 104 581 179 104 583 minecraft:shroomlight
setblock 183 105 570 minecraft:white_concrete
setblock 180 106 599 minecraft:white_concrete
setblock 181 106 599 minecraft:black_concrete
fill 183 106 570 183 107 570 minecraft:black_concrete
fill 180 107 599 180 125 599 minecraft:black_concrete
setblock 181 107 599 minecraft:shroomlight
setblock 183 107 575 minecraft:shroomlight
setblock 183 107 598 minecraft:white_concrete
setblock 141 108 568 minecraft:shroomlight
fill 181 108 599 181 129 599 minecraft:black_concrete
setblock 183 108 570 minecraft:shroomlight
fill 183 108 575 183 124 575 minecraft:black_concrete
setblock 183 108 598 minecraft:black_concrete
fill 141 109 565 141 110 565 minecraft:gold_block
fill 141 109 568 141 125 568 minecraft:black_concrete
fill 141 109 581 141 110 581 minecraft:gold_block
fill 141 109 597 141 110 597 minecraft:gold_block
fill 145 109 557 145 110 557 minecraft:gold_block
fill 155 109 599 155 110 599 minecraft:gold_block
fill 161 109 557 161 110 557 minecraft:gold_block
fill 171 109 599 171 110 599 minecraft:gold_block
fill 177 109 557 177 110 557 minecraft:gold_block
fill 183 109 567 183 110 567 minecraft:gold_block
fill 183 109 570 183 111 570 minecraft:black_concrete
fill 183 109 583 183 110 583 minecraft:gold_block
setblock 183 109 592 minecraft:white_concrete
setblock 183 109 598 minecraft:shroomlight
setblock 141 110 561 minecraft:white_concrete
setblock 154 110 599 minecraft:shroomlight
setblock 163 110 599 minecraft:shroomlight
setblock 183 110 571 minecraft:shroomlight
fill 183 110 592 183 128 592 minecraft:black_concrete
fill 183 110 598 183 128 598 minecraft:black_concrete
fill 141 111 561 141 124 561 minecraft:black_concrete
fill 141 111 565 141 117 565 minecraft:black_concrete
setblock 141 111 572 minecraft:shroomlight
fill 141 111 581 141 117 581 minecraft:black_concrete
setblock 141 111 594 minecraft:white_concrete
fill 141 111 597 141 117 597 minecraft:black_concrete
setblock 145 111 557 minecraft:shroomlight
setblock 148 111 599 minecraft:shroomlight
fill 149 111 599 149 128 599 minecraft:black_concrete
fill 154 111 599 155 117 599 minecraft:black_concrete
fill 161 111 557 161 117 557 minecraft:black_concrete
setblock 163 111 557 minecraft:shroomlight
fill 163 111 599 163 128 599 minecraft:black_concrete
setblock 165 111 599 minecraft:shroomlight
fill 166 111 599 166 128 599 minecraft:black_concrete
fill 171 111 599 171 112 599 minecraft:black_concrete
fill 177 111 557 177 114 557 minecraft:black_concrete
fill 183 111 567 183 117 567 minecraft:black_concrete
fill 183 111 571 183 128 571 minecraft:black_concrete
setblock 183 111 574 minecraft:white_concrete
fill 183 111 583 183 117 583 minecraft:black_concrete
fill 141 112 559 141 113 559 minecraft:shroomlight
fill 141 112 572 141 128 572 minecraft:black_concrete
setblock 141 112 593 minecraft:white_concrete
fill 141 112 594 141 124 594 minecraft:black_concrete
setblock 144 112 560 minecraft:light[level=14]
setblock 144 112 568 minecraft:light[level=14]
setblock 144 112 576 minecraft:light[level=14]
setblock 144 112 584 minecraft:light[level=14]
setblock 144 112 592 minecraft:light[level=14]
fill 145 112 557 145 117 557 minecraft:black_concrete
fill 148 112 599 148 121 599 minecraft:black_concrete
fill 151 112 599 151 124 599 minecraft:black_concrete
setblock 152 112 560 minecraft:light[level=14]
setblock 152 112 568 minecraft:light[level=14]
setblock 152 112 576 minecraft:light[level=14]
setblock 152 112 584 minecraft:light[level=14]
setblock 152 112 592 minecraft:light[level=14]
setblock 152 112 599 minecraft:white_concrete
setblock 160 112 560 minecraft:light[level=14]
setblock 160 112 568 minecraft:light[level=14]
setblock 160 112 576 minecraft:light[level=14]
setblock 160 112 584 minecraft:light[level=14]
setblock 160 112 592 minecraft:light[level=14]
fill 163 112 557 163 128 557 minecraft:black_concrete
fill 165 112 599 165 124 599 minecraft:black_concrete
setblock 168 112 560 minecraft:light[level=14]
setblock 168 112 568 minecraft:light[level=14]
setblock 168 112 576 minecraft:light[level=14]
setblock 168 112 584 minecraft:light[level=14]
setblock 168 112 592 minecraft:light[level=14]
setblock 169 112 557 minecraft:shroomlight
setblock 176 112 560 minecraft:light[level=14]
setblock 176 112 568 minecraft:light[level=14]
setblock 176 112 576 minecraft:light[level=14]
setblock 176 112 584 minecraft:light[level=14]
setblock 176 112 592 minecraft:light[level=14]
setblock 183 112 570 minecraft:white_concrete
fill 183 112 574 183 114 574 minecraft:black_concrete
setblock 141 113 585 minecraft:shroomlight
fill 141 113 593 141 128 593 minecraft:black_concrete
fill 152 113 599 152 128 599 minecraft:black_concrete
fill 169 113 557 169 128 557 minecraft:black_concrete
setblock 171 113 599 minecraft:shroomlight
fill 183 113 570 183 123 570 minecraft:black_concrete
setblock 183 113 572 minecraft:shroomlight
fill 141 114 559 141 123 559 minecraft:black_concrete
fill 141 114 585 141 126 585 minecraft:black_concrete
setblock 141 114 586 minecraft:shroomlight
fill 171 114 599 171 117 599 minecraft:black_concrete
fill 183 114 572 183 128 572 minecraft:black_concrete
fill 141 115 586 141 126 586 minecraft:black_concrete
setblock 156 115 557 minecraft:shroomlight
setblock 177 115 557 minecraft:white_concrete
setblock 183 115 574 minecraft:white_concrete
setblock 141 116 564 minecraft:white_concrete
setblock 143 116 599 minecraft:shroomlight
fill 156 116 557 156 128 557 minecraft:black_concrete
fill 177 116 557 177 117 557 minecraft:black_concrete
setblock 180 116 557 minecraft:shroomlight
setblock 183 116 559 minecraft:shroomlight
setblock 183 116 564 minecraft:white_concrete
fill 183 116 574 183 128 574 minecraft:black_concrete
fill 141 117 564 141 126 564 minecraft:black_concrete
fill 143 117 599 143 121 599 minecraft:black_concrete
fill 180 117 557 180 128 557 minecraft:black_concrete
fill 183 117 559 183 129 559 minecraft:black_concrete
fill 183 117 564 183 128 564 minecraft:black_concrete
fill 141 118 565 141 119 565 minecraft:gold_block
fill 141 118 581 141 119 581 minecraft:gold_block
fill 141 118 597 141 119 597 minecraft:gold_block
fill 145 118 557 145 119 557 minecraft:gold_block
fill 154 118 599 154 126 599 minecraft:black_concrete
fill 155 118 599 155 119 599 minecraft:gold_block
fill 161 118 557 161 119 557 minecraft:gold_block
setblock 161 118 599 minecraft:white_concrete
fill 162 118 599 162 128 599 minecraft:black_concrete
fill 171 118 599 171 119 599 minecraft:gold_block
fill 177 118 557 177 119 557 minecraft:gold_block
setblock 183 118 566 minecraft:white_concrete
fill 183 118 567 183 119 567 minecraft:gold_block
fill 183 118 583 183 119 583 minecraft:gold_block
setblock 141 119 596 minecraft:white_concrete
setblock 153 119 557 minecraft:shroomlight
fill 161 119 599 161 128 599 minecraft:black_concrete
fill 183 119 566 183 128 566 minecraft:black_concrete
fill 141 120 565 141 126 565 minecraft:black_concrete
fill 141 120 581 141 126 581 minecraft:black_concrete
fill 141 120 596 141 126 597 minecraft:black_concrete
setblock 144 120 560 minecraft:light[level=14]
setblock 144 120 568 minecraft:light[level=14]
setblock 144 120 576 minecraft:light[level=14]
setblock 144 120 584 minecraft:light[level=14]
setblock 144 120 592 minecraft:light[level=14]
fill 145 120 557 145 124 557 minecraft:black_concrete
setblock 152 120 560 minecraft:light[level=14]
setblock 152 120 568 minecraft:light[level=14]
setblock 152 120 576 minecraft:light[level=14]
setblock 152 120 584 minecraft:light[level=14]
setblock 152 120 592 minecraft:light[level=14]
fill 153 120 557 153 128 557 minecraft:black_concrete
fill 155 120 599 155 126 599 minecraft:black_concrete
setblock 160 120 560 minecraft:light[level=14]
setblock 160 120 568 minecraft:light[level=14]
setblock 160 120 576 minecraft:light[level=14]
setblock 160 120 584 minecraft:light[level=14]
setblock 160 120 592 minecraft:light[level=14]
fill 161 120 557 161 126 557 minecraft:black_concrete
setblock 168 120 560 minecraft:light[level=14]
setblock 168 120 568 minecraft:light[level=14]
setblock 168 120 576 minecraft:light[level=14]
setblock 168 120 584 minecraft:light[level=14]
setblock 168 120 592 minecraft:light[level=14]
fill 171 120 599 171 122 599 minecraft:black_concrete
setblock 176 120 560 minecraft:light[level=14]
setblock 176 120 568 minecraft:light[level=14]
setblock 176 120 576 minecraft:light[level=14]
setblock 176 120 584 minecraft:light[level=14]
setblock 176 120 592 minecraft:light[level=14]
fill 177 120 557 177 122 557 minecraft:black_concrete
fill 183 120 567 183 124 567 minecraft:black_concrete
fill 183 120 583 183 125 583 minecraft:black_concrete
setblock 156 121 599 minecraft:white_concrete
fill 157 121 599 157 128 599 minecraft:black_concrete
setblock 143 122 599 minecraft:shroomlight
setblock 148 122 599 minecraft:shroomlight
fill 156 122 599 156 128 599 minecraft:black_concrete
setblock 183 122 593 minecraft:white_concrete
fill 143 123 599 143 128 599 minecraft:black_concrete
fill 148 123 599 148 128 599 minecraft:black_concrete
setblock 160 123 599 minecraft:shroomlight
setblock 171 123 599 minecraft:shroomlight
setblock 177 123 557 minecraft:shroomlight
setblock 183 123 561 minecraft:shroomlight
fill 183 123 593 183 128 593 minecraft:black_concrete
setblock 141 124 559 minecraft:shroomlight
setblock 141 124 592 minecraft:white_concrete
fill 160 124 599 160 128 599 minecraft:black_concrete
fill 171 124 599 171 126 599 minecraft:black_concrete
fill 177 124 557 177 126 557 minecraft:black_concrete
fill 183 124 561 183 128 561 minecraft:black_concrete
setblock 183 124 570 minecraft:shroomlight
setblock 183 124 594 minecraft:shroomlight
setblock 141 125 557 minecraft:blue_concrete
fill 141 125 559 141 128 559 minecraft:black_concrete
fill 141 125 561 141 126 561 minecraft:blue_concrete
fill 141 125 577 141 125 578 minecraft:blue_concrete
setblock 141 125 591 minecraft:blue_concrete
fill 141 125 592 141 128 592 minecraft:black_concrete
setblock 141 125 594 minecraft:blue_concrete
setblock 145 125 557 minecraft:blue_concrete
fill 146 125 599 147 125 599 minecraft:blue_concrete
setblock 147 125 557 minecraft:shroomlight
setblock 151 125 599 minecraft:blue_concrete
setblock 160 125 557 minecraft:blue_concrete
setblock 165 125 599 minecraft:blue_concrete
setblock 171 125 557 minecraft:blue_concrete
fill 173 125 599 174 125 599 minecraft:blue_concrete
fill 175 125 557 175 128 557 minecraft:black_concrete
setblock 176 125 557 minecraft:shroomlight
setblock 183 125 563 minecraft:blue_concrete
setblock 183 125 567 minecraft:blue_concrete
fill 183 125 570 183 126 570 minecraft:black_concrete
fill 183 125 575 183 125 576 minecraft:blue_concrete
fill 183 125 594 183 128 594 minecraft:black_concrete
setblock 183 125 599 minecraft:blue_concrete
fill 141 126 557 141 128 557 minecraft:black_concrete
fill 141 126 568 141 126 569 minecraft:blue_concrete
fill 141 126 577 141 128 578 minecraft:black_concrete
fill 141 126 591 141 128 591 minecraft:black_concrete
fill 141 126 594 141 128 594 minecraft:black_concrete
fill 142 126 557 142 127 557 minecraft:blue_concrete
setblock 145 126 557 minecraft:black_concrete
fill 146 126 557 146 127 557 minecraft:blue_concrete
fill 146 126 599 147 128 599 minecraft:black_concrete
fill 147 126 557 147 128 557 minecraft:black_concrete
setblock 150 126 599 minecraft:blue_concrete
fill 151 126 599 151 128 599 minecraft:black_concrete
setblock 152 126 557 minecraft:blue_concrete
fill 160 126 557 160 128 557 minecraft:black_concrete
fill 165 126 599 165 128 599 minecraft:black_concrete
fill 166 126 557 167 126 557 minecraft:blue_concrete
fill 171 126 557 171 128 557 minecraft:black_concrete
fill 173 126 599 174 126 599 minecraft:black_concrete
setblock 175 126 599 minecraft:blue_concrete
fill 176 126 557 176 128 557 minecraft:black_concrete
setblock 180 126 599 minecraft:blue_concrete
fill 183 126 563 183 128 563 minecraft:black_concrete
setblock 183 126 567 minecraft:black_concrete
fill 183 126 575 183 129 575 minecraft:black_concrete
setblock 183 126 576 minecraft:blue_concrete
fill 183 126 582 183 126 583 minecraft:blue_concrete
setblock 183 126 595 minecraft:blue_concrete
fill 183 126 599 183 129 599 minecraft:black_concrete
fill 141 127 561 141 128 561 minecraft:black_concrete
fill 141 127 563 141 127 564 minecraft:blue_concrete
fill 141 127 565 141 128 565 minecraft:gold_block
fill 141 127 568 141 128 568 minecraft:black_concrete
setblock 141 127 569 minecraft:blue_concrete
setblock 141 127 580 minecraft:blue_concrete
fill 141 127 581 141 128 581 minecraft:gold_block
fill 141 127 585 141 127 586 minecraft:blue_concrete
fill 141 127 596 141 128 596 minecraft:black_concrete
fill 141 127 597 141 128 597 minecraft:gold_block
setblock 144 127 557 minecraft:blue_concrete
setblock 144 127 599 minecraft:blue_concrete
fill 145 127 557 145 128 557 minecraft:gold_block
fill 150 127 599 150 128 599 minecraft:black_concrete
fill 152 127 557 152 128 557 minecraft:black_concrete
fill 153 127 599 154 127 599 minecraft:blue_concrete
fill 155 127 599 155 128 599 minecraft:gold_block
setblock 158 127 599 minecraft:blue_concrete
fill 161 127 557 161 128 557 minecraft:gold_block
setblock 164 127 557 minecraft:white_concrete
fill 166 127 557 167 128 557 minecraft:black_concrete
fill 171 127 599 171 128 599 minecraft:gold_block
setblock 173 127 599 minecraft:blue_concrete
fill 174 127 599 175 128 599 minecraft:black_concrete
fill 177 127 557 177 128 557 minecraft:gold_block
fill 180 127 599 180 128 599 minecraft:black_concrete
setblock 183 127 562 minecraft:blue_concrete
fill 183 127 567 183 128 567 minecraft:gold_block
setblock 183 127 570 minecraft:blue_concrete
fill 183 127 576 183 128 576 minecraft:black_concrete
fill 183 127 582 183 128 582 minecraft:black_concrete
fill 183 127 583 183 128 583 minecraft:gold_block
setblock 183 127 584 minecraft:white_concrete
fill 183 127 595 183 128 595 minecraft:black_concrete
fill 141 128 563 141 128 564 minecraft:black_concrete
setblock 141 128 569 minecraft:black_concrete
setblock 141 128 580 minecraft:black_concrete
setblock 141 128 583 minecraft:shroomlight
fill 141 128 585 141 128 586 minecraft:black_concrete
setblock 142 128 557 minecraft:black_concrete
fill 144 128 557 144 129 557 minecraft:black_concrete
setblock 144 128 560 minecraft:light[level=14]
setblock 144 128 568 minecraft:light[level=14]
setblock 144 128 576 minecraft:light[level=14]
setblock 144 128 584 minecraft:light[level=14]
setblock 144 128 592 minecraft:light[level=14]
setblock 144 128 599 minecraft:black_concrete
setblock 146 128 557 minecraft:black_concrete
setblock 152 128 560 minecraft:light[level=14]
setblock 152 128 568 minecraft:light[level=14]
setblock 152 128 576 minecraft:light[level=14]
setblock 152 128 584 minecraft:light[level=14]
setblock 152 128 592 minecraft:light[level=14]
fill 153 128 599 154 128 599 minecraft:black_concrete
setblock 158 128 599 minecraft:black_concrete
setblock 160 128 560 minecraft:light[level=14]
setblock 160 128 568 minecraft:light[level=14]
setblock 160 128 576 minecraft:light[level=14]
setblock 160 128 584 minecraft:light[level=14]
setblock 160 128 592 minecraft:light[level=14]
fill 164 128 557 164 129 557 minecraft:black_concrete
setblock 168 128 560 minecraft:light[level=14]
setblock 168 128 568 minecraft:light[level=14]
setblock 168 128 576 minecraft:light[level=14]
setblock 168 128 584 minecraft:light[level=14]
setblock 168 128 592 minecraft:light[level=14]
setblock 173 128 599 minecraft:black_concrete
setblock 176 128 560 minecraft:light[level=14]
setblock 176 128 568 minecraft:light[level=14]
setblock 176 128 576 minecraft:light[level=14]
setblock 176 128 584 minecraft:light[level=14]
setblock 176 128 592 minecraft:light[level=14]
setblock 183 128 562 minecraft:black_concrete
setblock 183 128 570 minecraft:black_concrete
fill 183 128 584 183 129 584 minecraft:black_concrete
setblock 183 128 585 minecraft:white_concrete
fill 141 129 557 141 129 578 minecraft:blue_concrete
fill 141 129 580 141 129 588 minecraft:blue_concrete
setblock 141 129 589 minecraft:shroomlight
fill 141 129 590 141 130 598 minecraft:blue_concrete
fill 142 129 557 143 130 557 minecraft:blue_concrete
fill 142 129 599 143 175 599 minecraft:blue_concrete
setblock 144 129 599 minecraft:shroomlight
fill 145 129 557 157 129 557 minecraft:blue_concrete
fill 145 129 599 154 130 599 minecraft:blue_concrete
setblock 155 129 599 minecraft:black_concrete
fill 156 129 599 162 129 599 minecraft:blue_concrete
fill 159 129 557 163 130 557 minecraft:blue_concrete
setblock 163 129 599 minecraft:white_concrete
fill 164 129 599 166 129 599 minecraft:blue_concrete
fill 165 129 557 183 129 557 minecraft:blue_concrete
fill 168 129 599 168 175 599 minecraft:blue_concrete
fill 170 129 599 170 130 599 minecraft:blue_concrete
setblock 171 129 599 minecraft:black_concrete
fill 172 129 599 180 129 599 minecraft:blue_concrete
fill 182 129 599 182 154 599 minecraft:blue_concrete
fill 183 129 558 183 151 558 minecraft:blue_concrete
fill 183 129 560 183 129 574 minecraft:blue_concrete
fill 183 129 576 183 129 583 minecraft:blue_concrete
fill 183 129 585 183 129 598 minecraft:blue_concrete
fill 141 130 557 141 130 567 minecraft:blue_concrete
setblock 141 130 568 minecraft:black_concrete
fill 141 130 569 141 137 575 minecraft:blue_concrete
setblock 141 130 576 minecraft:shroomlight
fill 141 130 577 141 150 577 minecraft:blue_concrete
setblock 141 130 578 minecraft:black_concrete
fill 141 130 579 141 134 585 minecraft:blue_concrete
fill 141 130 586 141 131 586 minecraft:black_concrete
fill 141 130 587 141 149 589 minecraft:blue_concrete
fill 144 130 557 153 130 557 minecraft:blue_concrete
fill 144 130 599 144 137 599 minecraft:blue_concrete
setblock 154 130 557 minecraft:black_concrete
fill 155 130 557 158 140 557 minecraft:blue_concrete
fill 155 130 599 155 138 599 minecraft:blue_concrete
setblock 156 130 599 minecraft:black_concrete
fill 157 130 599 158 200 599 minecraft:blue_concrete
setblock 159 130 599 minecraft:shroomlight
fill 160 130 599 165 130 599 minecraft:blue_concrete
fill 164 130 557 171 132 557 minecraft:blue_concrete
setblock 166 130 599 minecraft:black_concrete
fill 167 130 599 167 184 599 minecraft:blue_concrete
setblock 169 130 599 minecraft:blue_concrete
fill 171 130 599 171 144 599 minecraft:blue_concrete
setblock 172 130 557 minecraft:black_concrete
setblock 172 130 599 minecraft:black_concrete
fill 173 130 557 179 130 557 minecraft:blue_concrete
fill 173 130 599 180 130 599 minecraft:blue_concrete
setblock 180 130 557 minecraft:black_concrete
fill 181 130 557 183 134 557 minecraft:blue_concrete
setblock 181 130 599 minecraft:white_concrete
fill 183 130 559 183 147 560 minecraft:blue_concrete
setblock 183 130 561 minecraft:black_concrete
fill 183 130 562 183 130 563 minecraft:blue_concrete
setblock 183 130 564 minecraft:black_concrete
fill 183 130 565 183 131 567 minecraft:blue_concrete
setblock 183 130 568 minecraft:shroomlight
fill 183 130 569 183 130 577 minecraft:blue_concrete
setblock 183 130 578 minecraft:black_concrete
fill 183 130 579 183 147 581 minecraft:blue_concrete
setblock 183 130 582 minecraft:black_concrete
fill 183 130 583 183 140 584 minecraft:blue_concrete
setblock 183 130 585 minecraft:black_concrete
fill 183 130 586 183 130 589 minecraft:blue_concrete
setblock 183 130 590 minecraft:black_concrete
fill 183 130 591 183 131 591 minecraft:blue_concrete
setblock 183 130 592 minecraft:black_concrete
fill 183 130 593 183 198 593 minecraft:blue_concrete
setblock 183 130 594 minecraft:black_concrete
fill 183 130 595 183 130 599 minecraft:blue_concrete
fill 141 131 557 141 131 558 minecraft:black_concrete
fill 141 131 559 141 149 564 minecraft:blue_concrete
setblock 141 131 565 minecraft:black_concrete
fill 141 131 566 141 146 568 minecraft:blue_concrete
setblock 141 131 576 minecraft:black_concrete
fill 141 131 578 141 160 578 minecraft:blue_concrete
fill 141 131 590 141 137 592 minecraft:blue_concrete
setblock 141 131 593 minecraft:black_concrete
fill 141 131 594 141 138 599 minecraft:blue_concrete
setblock 142 131 557 minecraft:black_concrete
fill 143 131 557 143 176 557 minecraft:blue_concrete
setblock 144 131 557 minecraft:black_concrete
fill 145 131 557 148 140 557 minecraft:blue_concrete
fill 145 131 599 148 132 599 minecraft:blue_concrete
setblock 149 131 557 minecraft:black_concrete
setblock 149 131 599 minecraft:black_concrete
fill 150 131 557 154 150 557 minecraft:blue_concrete
fill 150 131 599 151 174 599 minecraft:blue_concrete
setblock 152 131 599 minecraft:black_concrete
fill 153 131 599 154 146 599 minecraft:blue_concrete
fill 156 131 599 156 174 599 minecraft:blue_concrete
fill 159 131 557 161 132 557 minecraft:blue_concrete
fill 159 131 599 162 133 599 minecraft:blue_concrete
setblock 162 131 557 minecraft:black_concrete
fill 163 131 557 163 139 557 minecraft:blue_concrete
setblock 163 131 599 minecraft:black_concrete
fill 164 131 599 166 134 599 minecraft:blue_concrete
fill 169 131 599 170 131 599 minecraft:black_concrete
fill 172 131 557 173 140 557 minecraft:blue_concrete
fill 172 131 599 174 148 599 minecraft:blue_concrete
setblock 174 131 557 minecraft:black_concrete
fill 175 131 557 180 144 557 minecraft:blue_concrete
setblock 175 131 599 minecraft:black_concrete
fill 176 131 599 181 132 599 minecraft:blue_concrete
fill 183 131 561 183 153 561 minecraft:blue_concrete
setblock 183 131 562 minecraft:black_concrete
fill 183 131 563 183 185 564 minecraft:blue_concrete
fill 183 131 568 183 142 574 minecraft:blue_concrete
setblock 183 131 575 minecraft:black_concrete
fill 183 131 576 183 149 578 minecraft:blue_concrete
fill 183 131 582 183 214 582 minecraft:blue_concrete
fill 183 131 585 183 137 587 minecraft:blue_concrete
setblock 183 131 588 minecraft:black_concrete
fill 183 131 589 183 131 590 minecraft:blue_concrete
fill 183 131 592 183 202 592 minecraft:blue_concrete
fill 183 131 594 183 203 595 minecraft:blue_concrete
fill 183 131 596 183 131 597 minecraft:black_concrete
fill 183 131 598 183 210 598 minecraft:blue_concrete
setblock 183 131 599 minecraft:black_concrete
fill 141 132 557 141 214 558 minecraft:blue_concrete
fill 141 132 565 141 144 565 minecraft:blue_concrete
fill 141 132 576 141 147 576 minecraft:blue_concrete
fill 141 132 586 141 191 586 minecraft:blue_concrete
fill 141 132 593 141 207 593 minecraft:blue_concrete
fill 142 132 557 142 147 557 minecraft:blue_concrete
fill 144 132 557 144 160 557 minecraft:blue_concrete
fill 149 132 557 149 170 557 minecraft:blue_concrete
fill 149 132 599 149 167 599 minecraft:blue_concrete
fill 152 132 599 152 215 599 minecraft:blue_concrete
setblock 162 132 557 minecraft:blue_concrete
fill 163 132 599 163 137 599 minecraft:blue_concrete
fill 169 132 599 170 157 599 minecraft:blue_concrete
fill 174 132 557 174 156 557 minecraft:blue_concrete
fill 175 132 599 175 133 599 minecraft:blue_concrete
fill 183 132 562 183 164 562 minecraft:blue_concrete
setblock 183 132 565 minecraft:shroomlight
fill 183 132 566 183 144 567 minecraft:blue_concrete
fill 183 132 575 183 140 575 minecraft:blue_concrete
fill 183 132 588 183 216 589 minecraft:blue_concrete
setblock 183 132 590 minecraft:shroomlight
setblock 183 132 591 minecraft:white_concrete
fill 183 132 596 183 146 597 minecraft:blue_concrete
fill 183 132 599 183 218 599 minecraft:blue_concrete
fill 145 133 599 146 168 599 minecraft:blue_concrete
setblock 147 133 599 minecraft:shroomlight
fill 148 133 599 148 218 599 minecraft:blue_concrete
fill 159 133 557 160 139 557 minecraft:blue_concrete
setblock 161 133 557 minecraft:white_concrete
setblock 162 133 557 minecraft:shroomlight
fill 164 133 557 167 139 557 minecraft:blue_concrete
setblock 168 133 557 minecraft:shroomlight
fill 169 133 557 171 139 557 minecraft:blue_concrete
setblock 176 133 599 minecraft:shroomlight
fill 177 133 599 181 139 599 minecraft:blue_concrete
fill 183 133 565 183 162 565 minecraft:blue_concrete
fill 183 133 590 183 145 591 minecraft:blue_concrete
fill 147 134 599 147 148 599 minecraft:blue_concrete
setblock 159 134 599 minecraft:white_concrete
fill 160 134 599 162 136 599 minecraft:blue_concrete
fill 161 134 557 162 139 557 minecraft:blue_concrete
fill 168 134 557 168 139 557 minecraft:blue_concrete
setblock 175 134 599 minecraft:white_concrete
fill 176 134 599 176 181 599 minecraft:blue_concrete
fill 141 135 579 141 144 581 minecraft:blue_concrete
setblock 141 135 582 minecraft:shroomlight
fill 141 135 583 141 148 585 minecraft:blue_concrete
fill 159 135 599 159 173 599 minecraft:blue_concrete
fill 164 135 599 164 193 599 minecraft:blue_concrete
setblock 165 135 599 minecraft:shroomlight
fill 166 135 599 166 188 599 minecraft:blue_concrete
fill 175 135 599 175 151 599 minecraft:blue_concrete
fill 181 135 557 181 215 557 minecraft:blue_concrete
setblock 182 135 557 minecraft:shroomlight
fill 183 135 557 183 216 557 minecraft:blue_concrete
fill 141 136 582 141 156 582 minecraft:blue_concrete
setblock 144 136 560 minecraft:light[level=14]
setblock 144 136 568 minecraft:light[level=14]
setblock 144 136 576 minecraft:light[level=14]
setblock 144 136 584 minecraft:light[level=14]
setblock 144 136 592 minecraft:light[level=14]
setblock 152 136 560 minecraft:light[level=14]
setblock 152 136 568 minecraft:light[level=14]
setblock 152 136 576 minecraft:light[level=14]
setblock 152 136 584 minecraft:light[level=14]
setblock 152 136 592 minecraft:light[level=14]
setblock 160 136 560 minecraft:light[level=14]
setblock 160 136 568 minecraft:light[level=14]
setblock 160 136 576 minecraft:light[level=14]
setblock 160 136 584 minecraft:light[level=14]
setblock 160 136 592 minecraft:light[level=14]
fill 165 136 599 165 216 599 minecraft:blue_concrete
setblock 168 136 560 minecraft:light[level=14]
setblock 168 136 568 minecraft:light[level=14]
setblock 168 136 576 minecraft:light[level=14]
setblock 168 136 584 minecraft:light[level=14]
setblock 168 136 592 minecraft:light[level=14]
setblock 176 136 560 minecraft:light[level=14]
setblock 176 136 568 minecraft:light[level=14]
setblock 176 136 576 minecraft:light[level=14]
setblock 176 136 584 minecraft:light[level=14]
setblock 176 136 592 minecraft:light[level=14]
fill 182 136 557 182 218 557 minecraft:blue_concrete
fill 160 137 599 161 155 599 minecraft:blue_concrete
setblock 162 137 599 minecraft:shroomlight
fill 141 138 569 141 146 570 minecraft:blue_concrete
setblock 141 138 571 minecraft:white_concrete
fill 141 138 572 141 217 575 minecraft:blue_concrete
fill 141 138 590 141 218 590 minecraft:blue_concrete
setblock 141 138 591 minecraft:shroomlight
fill 141 138 592 141 146 592 minecraft:blue_concrete
setblock 144 138 599 minecraft:shroomlight
fill 162 138 599 162 208 599 minecraft:blue_concrete
setblock 163 138 599 minecraft:shroomlight
fill 183 138 585 183 173 586 minecraft:blue_concrete
setblock 183 138 587 minecraft:white_concrete
fill 141 139 571 141 163 571 minecraft:blue_concrete
fill 141 139 591 141 182 591 minecraft:blue_concrete
fill 141 139 594 141 147 596 minecraft:blue_concrete
setblock 141 139 597 minecraft:shroomlight
fill 141 139 598 141 218 599 minecraft:blue_concrete
fill 144 139 599 144 218 599 minecraft:blue_concrete
setblock 155 139 599 minecraft:white_concrete
fill 161 139 565 163 139 567 minecraft:redstone_block
fill 161 139 573 163 139 575 minecraft:redstone_block
fill 163 139 599 163 216 599 minecraft:blue_concrete
fill 168 139 566 170 139 568 minecraft:redstone_block
fill 183 139 587 183 218 587 minecraft:blue_concrete
fill 141 140 597 141 144 597 minecraft:blue_concrete
fill 151 140 570 163 140 570 minecraft:black_concrete
fill 152 140 565 160 140 569 minecraft:black_concrete
fill 152 140 571 160 140 575 minecraft:black_concrete
fill 153 140 563 177 140 564 minecraft:black_concrete
fill 153 140 576 177 140 577 minecraft:black_concrete
fill 154 140 562 176 140 562 minecraft:black_concrete
fill 154 140 578 176 140 578 minecraft:black_concrete
fill 155 140 561 175 140 561 minecraft:black_concrete
fill 155 140 579 175 140 579 minecraft:black_concrete
fill 155 140 599 155 144 599 minecraft:blue_concrete
fill 156 140 560 174 140 560 minecraft:black_concrete
fill 156 140 580 174 140 580 minecraft:black_concrete
fill 157 140 559 173 140 559 minecraft:black_concrete
fill 157 140 581 173 140 581 minecraft:black_concrete
fill 158 140 558 172 140 558 minecraft:black_concrete
fill 158 140 582 172 140 582 minecraft:black_concrete
setblock 159 140 557 minecraft:blue_concrete
fill 160 140 557 170 141 557 minecraft:black_concrete
fill 160 140 583 170 140 583 minecraft:black_concrete
fill 161 140 568 163 140 569 minecraft:black_concrete
fill 161 140 571 163 140 572 minecraft:black_concrete
fill 164 140 565 167 140 568 minecraft:black_concrete
fill 164 140 572 178 140 575 minecraft:black_concrete
setblock 165 140 584 minecraft:black_concrete
fill 167 140 569 178 140 571 minecraft:black_concrete
fill 168 140 565 178 140 565 minecraft:black_concrete
setblock 171 140 557 minecraft:blue_concrete
fill 171 140 566 178 140 568 minecraft:black_concrete
fill 177 140 599 178 166 599 minecraft:blue_concrete
setblock 179 140 570 minecraft:black_concrete
setblock 179 140 599 minecraft:shroomlight
fill 180 140 599 181 144 599 minecraft:blue_concrete
fill 142 141 558 142 141 562 minecraft:orange_terracotta
setblock 142 141 563 minecraft:white_concrete
fill 142 141 564 142 141 570 minecraft:orange_terracotta
setblock 142 141 571 minecraft:white_concrete
fill 142 141 572 142 141 578 minecraft:orange_terracotta
setblock 142 141 579 minecraft:white_concrete
fill 142 141 580 142 141 586 minecraft:orange_terracotta
setblock 142 141 587 minecraft:white_concrete
fill 142 141 588 142 141 594 minecraft:orange_terracotta
setblock 142 141 595 minecraft:white_concrete
fill 142 141 596 146 141 598 minecraft:orange_terracotta
fill 143 141 558 143 141 561 minecraft:orange_terracotta
setblock 143 141 562 minecraft:white_concrete
fill 143 141 563 143 141 569 minecraft:orange_terracotta
setblock 143 141 570 minecraft:white_concrete
fill 143 141 571 143 141 577 minecraft:orange_terracotta
setblock 143 141 578 minecraft:white_concrete
fill 143 141 579 143 141 585 minecraft:orange_terracotta
setblock 143 141 586 minecraft:white_concrete
fill 143 141 587 143 141 593 minecraft:orange_terracotta
setblock 143 141 594 minecraft:white_concrete
fill 143 141 595 149 141 595 minecraft:orange_terracotta
fill 144 141 558 144 141 560 minecraft:orange_terracotta
setblock 144 141 561 minecraft:white_concrete
fill 144 141 562 144 141 568 minecraft:orange_terracotta
setblock 144 141 569 minecraft:white_concrete
fill 144 141 570 144 141 576 minecraft:orange_terracotta
setblock 144 141 577 minecraft:white_concrete
fill 144 141 578 144 141 584 minecraft:orange_terracotta
setblock 144 141 585 minecraft:white_concrete
fill 144 141 586 144 141 592 minecraft:orange_terracotta
setblock 144 141 593 minecraft:white_concrete
fill 144 141 594 150 141 594 minecraft:orange_terracotta
fill 145 141 557 147 144 557 minecraft:blue_concrete
fill 145 141 558 145 141 559 minecraft:orange_terracotta
setblock 145 141 560 minecraft:white_concrete
fill 145 141 561 145 141 567 minecraft:orange_terracotta
setblock 145 141 568 minecraft:white_concrete
fill 145 141 569 145 141 575 minecraft:orange_terracotta
setblock 145 141 576 minecraft:white_concrete
fill 145 141 577 145 141 583 minecraft:orange_terracotta
setblock 145 141 584 minecraft:white_concrete
fill 145 141 585 145 141 591 minecraft:orange_terracotta
setblock 145 141 592 minecraft:white_concrete
fill 145 141 593 151 141 593 minecraft:orange_terracotta
setblock 146 141 558 minecraft:orange_terracotta
setblock 146 141 559 minecraft:white_concrete
fill 146 141 560 146 141 566 minecraft:orange_terracotta
setblock 146 141 567 minecraft:white_concrete
fill 146 141 568 146 141 574 minecraft:orange_terracotta
setblock 146 141 575 minecraft:white_concrete
fill 146 141 576 146 141 582 minecraft:orange_terracotta
setblock 146 141 583 minecraft:white_concrete
fill 146 141 584 146 141 590 minecraft:orange_terracotta
setblock 146 141 591 minecraft:white_concrete
fill 146 141 592 152 141 592 minecraft:orange_terracotta
setblock 147 141 558 minecraft:white_concrete
fill 147 141 559 147 141 565 minecraft:orange_terracotta
setblock 147 141 566 minecraft:white_concrete
fill 147 141 567 147 141 573 minecraft:orange_terracotta
setblock 147 141 574 minecraft:white_concrete
fill 147 141 575 147 141 581 minecraft:orange_terracotta
setblock 147 141 582 minecraft:white_concrete
fill 147 141 583 147 141 589 minecraft:orange_terracotta
setblock 147 141 590 minecraft:white_concrete
fill 147 141 591 153 141 591 minecraft:orange_terracotta
fill 147 141 596 147 141 597 minecraft:orange_terracotta
setblock 147 141 598 minecraft:white_concrete
setblock 148 141 557 minecraft:shroomlight
fill 148 141 558 148 141 564 minecraft:orange_terracotta
setblock 148 141 565 minecraft:white_concrete
fill 148 141 566 148 141 572 minecraft:orange_terracotta
setblock 148 141 573 minecraft:white_concrete
fill 148 141 574 148 141 580 minecraft:orange_terracotta
setblock 148 141 581 minecraft:white_concrete
fill 148 141 582 148 141 588 minecraft:orange_terracotta
setblock 148 141 589 minecraft:white_concrete
fill 148 141 590 154 141 590 minecraft:orange_terracotta
setblock 148 141 596 minecraft:orange_terracotta
setblock 148 141 597 minecraft:white_concrete
fill 148 141 598 154 141 598 minecraft:orange_terracotta
fill 149 141 558 149 141 563 minecraft:orange_terracotta
setblock 149 141 564 minecraft:white_concrete
fill 149 141 565 149 141 571 minecraft:orange_terracotta
setblock 149 141 572 minecraft:white_concrete
fill 149 141 573 149 141 579 minecraft:orange_terracotta
setblock 149 141 580 minecraft:white_concrete
fill 149 141 581 149 141 587 minecraft:orange_terracotta
setblock 149 141 588 minecraft:white_concrete
fill 149 141 589 155 141 589 minecraft:orange_terracotta
setblock 149 141 596 minecraft:white_concrete
fill 149 141 597 155 141 597 minecraft:orange_terracotta
fill 150 141 558 150 141 562 minecraft:orange_terracotta
setblock 150 141 563 minecraft:white_concrete
fill 150 141 564 150 141 570 minecraft:orange_terracotta
setblock 150 141 571 minecraft:white_concrete
fill 150 141 572 150 141 578 minecraft:orange_terracotta
setblock 150 141 579 minecraft:white_concrete
fill 150 141 580 150 141 586 minecraft:orange_terracotta
setblock 150 141 587 minecraft:white_concrete
fill 150 141 588 156 141 588 minecraft:orange_terracotta
setblock 150 141 595 minecraft:white_concrete
fill 150 141 596 156 141 596 minecraft:orange_terracotta
fill 151 141 558 151 141 561 minecraft:orange_terracotta
setblock 151 141 562 minecraft:white_concrete
fill 151 141 563 151 141 569 minecraft:orange_terracotta
setblock 151 141 570 minecraft:white_concrete
fill 151 141 571 151 141 577 minecraft:orange_terracotta
setblock 151 141 578 minecraft:white_concrete
fill 151 141 579 151 141 585 minecraft:orange_terracotta
setblock 151 141 586 minecraft:white_concrete
fill 151 141 587 157 141 587 minecraft:orange_terracotta
setblock 151 141 594 minecraft:white_concrete
fill 151 141 595 157 141 595 minecraft:orange_terracotta
fill 152 141 558 152 141 560 minecraft:orange_terracotta
setblock 152 141 561 minecraft:white_concrete
fill 152 141 562 152 141 568 minecraft:orange_terracotta
setblock 152 141 569 minecraft:white_concrete
fill 152 141 570 152 141 576 minecraft:orange_terracotta
setblock 152 141 577 minecraft:white_concrete
fill 152 141 578 152 141 584 minecraft:orange_terracotta
setblock 152 141 585 minecraft:white_concrete
fill 152 141 586 158 141 586 minecraft:orange_terracotta
setblock 152 141 593 minecraft:white_concrete
fill 152 141 594 158 141 594 minecraft:orange_terracotta
fill 153 141 558 153 141 559 minecraft:orange_terracotta
setblock 153 141 560 minecraft:white_concrete
fill 153 141 561 153 141 567 minecraft:orange_terracotta
setblock 153 141 568 minecraft:white_concrete
fill 153 141 569 153 141 575 minecraft:orange_terracotta
setblock 153 141 576 minecraft:white_concrete
fill 153 141 577 153 141 583 minecraft:orange_terracotta
setblock 153 141 584 minecraft:white_concrete
fill 153 141 585 159 141 585 minecraft:orange_terracotta
setblock 153 141 592 minecraft:white_concrete
fill 153 141 593 159 141 593 minecraft:orange_terracotta
setblock 154 141 558 minecraft:orange_terracotta
setblock 154 141 559 minecraft:white_concrete
fill 154 141 560 154 141 566 minecraft:orange_terracotta
setblock 154 141 567 minecraft:white_concrete
fill 154 141 568 154 141 574 minecraft:orange_terracotta
setblock 154 141 575 minecraft:white_concrete
fill 154 141 576 154 141 582 minecraft:orange_terracotta
setblock 154 141 583 minecraft:white_concrete
fill 154 141 584 160 141 584 minecraft:orange_terracotta
setblock 154 141 591 minecraft:white_concrete
fill 154 141 592 160 141 592 minecraft:orange_terracotta
fill 155 141 557 157 145 557 minecraft:blue_concrete
setblock 155 141 558 minecraft:white_concrete
fill 155 141 559 155 141 565 minecraft:orange_terracotta
setblock 155 141 566 minecraft:white_concrete
fill 155 141 567 155 141 573 minecraft:orange_terracotta
setblock 155 141 574 minecraft:white_concrete
fill 155 141 575 155 141 581 minecraft:orange_terracotta
setblock 155 141 582 minecraft:white_concrete
fill 155 141 583 161 141 583 minecraft:orange_terracotta
setblock 155 141 590 minecraft:white_concrete
fill 155 141 591 161 141 591 minecraft:orange_terracotta
setblock 155 141 598 minecraft:white_concrete
fill 156 141 558 156 141 564 minecraft:orange_terracotta
setblock 156 141 565 minecraft:white_concrete
fill 156 141 566 156 141 572 minecraft:orange_terracotta
setblock 156 141 573 minecraft:white_concrete
fill 156 141 574 156 141 580 minecraft:orange_terracotta
setblock 156 141 581 minecraft:white_concrete
fill 156 141 582 162 141 582 minecraft:orange_terracotta
setblock 156 141 589 minecraft:white_concrete
fill 156 141 590 162 141 590 minecraft:orange_terracotta
setblock 156 141 597 minecraft:white_concrete
fill 156 141 598 162 141 598 minecraft:orange_terracotta
fill 157 141 558 157 141 563 minecraft:orange_terracotta
setblock 157 141 564 minecraft:white_concrete
fill 157 141 565 157 141 571 minecraft:orange_terracotta
setblock 157 141 572 minecraft:white_concrete
fill 157 141 573 157 141 579 minecraft:orange_terracotta
setblock 157 141 580 minecraft:white_concrete
fill 157 141 581 163 141 581 minecraft:orange_terracotta
setblock 157 141 588 minecraft:white_concrete
fill 157 141 589 163 141 589 minecraft:orange_terracotta
setblock 157 141 596 minecraft:white_concrete
fill 157 141 597 163 141 597 minecraft:orange_terracotta
fill 158 141 557 159 141 557 minecraft:gold_block
fill 158 141 558 158 141 562 minecraft:orange_terracotta
setblock 158 141 563 minecraft:white_concrete
fill 158 141 564 158 141 570 minecraft:orange_terracotta
setblock 158 141 571 minecraft:white_concrete
fill 158 141 572 158 141 578 minecraft:orange_terracotta
setblock 158 141 579 minecraft:white_concrete
fill 158 141 580 164 141 580 minecraft:orange_terracotta
setblock 158 141 587 minecraft:white_concrete
fill 158 141 588 164 141 588 minecraft:orange_terracotta
setblock 158 141 595 minecraft:white_concrete
fill 158 141 596 164 141 596 minecraft:orange_terracotta
fill 159 141 558 159 141 561 minecraft:orange_terracotta
setblock 159 141 562 minecraft:white_concrete
fill 159 141 563 159 141 569 minecraft:orange_terracotta
setblock 159 141 570 minecraft:white_concrete
fill 159 141 571 159 141 577 minecraft:orange_terracotta
setblock 159 141 578 minecraft:white_concrete
fill 159 141 579 165 141 579 minecraft:orange_terracotta
setblock 159 141 586 minecraft:white_concrete
fill 159 141 587 165 141 587 minecraft:orange_terracotta
setblock 159 141 594 minecraft:white_concrete
fill 159 141 595 165 141 595 minecraft:orange_terracotta
fill 160 141 558 160 141 560 minecraft:orange_terracotta
setblock 160 141 561 minecraft:white_concrete
fill 160 141 562 160 141 568 minecraft:orange_terracotta
setblock 160 141 569 minecraft:white_concrete
fill 160 141 570 160 141 576 minecraft:orange_terracotta
setblock 160 141 577 minecraft:white_concrete
fill 160 141 578 166 141 578 minecraft:orange_terracotta
setblock 160 141 585 minecraft:white_concrete
fill 160 141 586 166 141 586 minecraft:orange_terracotta
setblock 160 141 593 minecraft:white_concrete
fill 160 141 594 166 141 594 minecraft:orange_terracotta
fill 161 141 558 161 141 559 minecraft:orange_terracotta
setblock 161 141 560 minecraft:white_concrete
fill 161 141 561 161 141 567 minecraft:orange_terracotta
fill 161 141 568 161 142 568 minecraft:white_concrete
fill 161 141 569 161 141 575 minecraft:orange_terracotta
setblock 161 141 576 minecraft:white_concrete
fill 161 141 577 167 141 577 minecraft:orange_terracotta
setblock 161 141 584 minecraft:white_concrete
fill 161 141 585 167 141 585 minecraft:orange_terracotta
setblock 161 141 592 minecraft:white_concrete
fill 161 141 593 167 141 593 minecraft:orange_terracotta
setblock 162 141 558 minecraft:orange_terracotta
setblock 162 141 559 minecraft:white_concrete
fill 162 141 560 162 141 566 minecraft:orange_terracotta
setblock 162 141 567 minecraft:white_concrete
fill 162 141 568 162 141 574 minecraft:orange_terracotta
setblock 162 141 575 minecraft:white_concrete
fill 162 141 576 168 141 576 minecraft:orange_terracotta
setblock 162 141 583 minecraft:white_concrete
fill 162 141 584 168 141 584 minecraft:orange_terracotta
setblock 162 141 591 minecraft:white_concrete
fill 162 141 592 168 141 592 minecraft:orange_terracotta
setblock 163 141 558 minecraft:white_concrete
fill 163 141 559 163 141 565 minecraft:orange_terracotta
setblock 163 141 566 minecraft:white_concrete
fill 163 141 567 163 141 568 minecraft:orange_terracotta
fill 163 141 569 163 142 571 minecraft:orange_concrete
fill 163 141 572 163 141 573 minecraft:orange_terracotta
setblock 163 141 574 minecraft:white_concrete
fill 163 141 575 169 141 575 minecraft:orange_terracotta
setblock 163 141 582 minecraft:white_concrete
fill 163 141 583 169 141 583 minecraft:orange_terracotta
setblock 163 141 590 minecraft:white_concrete
fill 163 141 591 169 141 591 minecraft:orange_terracotta
setblock 163 141 598 minecraft:white_concrete
fill 164 141 558 164 141 564 minecraft:orange_terracotta
setblock 164 141 565 minecraft:white_concrete
fill 164 141 566 169 141 567 minecraft:orange_terracotta
fill 164 141 568 166 142 568 minecraft:orange_concrete
fill 164 141 572 166 142 572 minecraft:orange_concrete
setblock 164 141 573 minecraft:white_concrete
fill 164 141 574 170 141 574 minecraft:orange_terracotta
setblock 164 141 581 minecraft:white_concrete
fill 164 141 582 170 141 582 minecraft:orange_terracotta
setblock 164 141 589 minecraft:white_concrete
fill 164 141 590 170 141 590 minecraft:orange_terracotta
setblock 164 141 597 minecraft:white_concrete
fill 164 141 598 170 141 598 minecraft:orange_terracotta
fill 165 141 558 165 141 563 minecraft:orange_terracotta
setblock 165 141 564 minecraft:white_concrete
fill 165 141 565 171 141 565 minecraft:orange_terracotta
fill 165 141 573 171 141 573 minecraft:orange_terracotta
setblock 165 141 580 minecraft:white_concrete
fill 165 141 581 171 141 581 minecraft:orange_terracotta
setblock 165 141 588 minecraft:white_concrete
fill 165 141 589 171 141 589 minecraft:orange_terracotta
setblock 165 141 596 minecraft:white_concrete
fill 165 141 597 171 141 597 minecraft:orange_terracotta
fill 166 141 558 166 141 562 minecraft:orange_terracotta
setblock 166 141 563 minecraft:white_concrete
fill 166 141 564 172 141 564 minecraft:orange_terracotta
setblock 166 141 579 minecraft:white_concrete
fill 166 141 580 172 141 580 minecraft:orange_terracotta
setblock 166 141 587 minecraft:white_concrete
fill 166 141 588 172 141 588 minecraft:orange_terracotta
setblock 166 141 595 minecraft:white_concrete
fill 166 141 596 172 141 596 minecraft:orange_terracotta
fill 167 141 558 167 141 561 minecraft:orange_terracotta
setblock 167 141 562 minecraft:white_concrete
fill 167 141 563 173 141 563 minecraft:orange_terracotta
fill 167 141 568 168 141 568 minecraft:orange_terracotta
fill 167 141 569 167 142 571 minecraft:orange_concrete
fill 167 141 572 172 141 572 minecraft:orange_terracotta
setblock 167 141 578 minecraft:white_concrete
fill 167 141 579 173 141 579 minecraft:orange_terracotta
setblock 167 141 586 minecraft:white_concrete
fill 167 141 587 173 141 587 minecraft:orange_terracotta
setblock 167 141 594 minecraft:white_concrete
fill 167 141 595 173 141 595 minecraft:orange_terracotta
fill 168 141 558 168 141 560 minecraft:orange_terracotta
setblock 168 141 561 minecraft:white_concrete
fill 168 141 562 174 141 562 minecraft:orange_terracotta
setblock 168 141 569 minecraft:white_concrete
fill 168 141 570 173 141 571 minecraft:orange_terracotta
setblock 168 141 577 minecraft:white_concrete
fill 168 141 578 174 141 578 minecraft:orange_terracotta
setblock 168 141 585 minecraft:white_concrete
fill 168 141 586 174 141 586 minecraft:orange_terracotta
setblock 168 141 593 minecraft:white_concrete
fill 168 141 594 174 141 594 minecraft:orange_terracotta
fill 169 141 558 169 141 559 minecraft:orange_terracotta
setblock 169 141 560 minecraft:white_concrete
fill 169 141 561 175 141 561 minecraft:orange_terracotta
setblock 169 141 568 minecraft:white_concrete
fill 169 141 569 175 141 569 minecraft:orange_terracotta
setblock 169 141 576 minecraft:white_concrete
fill 169 141 577 175 141 577 minecraft:orange_terracotta
setblock 169 141 584 minecraft:white_concrete
fill 169 141 585 175 141 585 minecraft:orange_terracotta
setblock 169 141 592 minecraft:white_concrete
fill 169 141 593 175 141 593 minecraft:orange_terracotta
setblock 170 141 558 minecraft:orange_terracotta
setblock 170 141 559 minecraft:white_concrete
fill 170 141 560 176 141 560 minecraft:orange_terracotta
setblock 170 141 566 minecraft:orange_terracotta
setblock 170 141 567 minecraft:white_concrete
fill 170 141 568 176 141 568 minecraft:orange_terracotta
setblock 170 141 575 minecraft:white_concrete
fill 170 141 576 176 141 576 minecraft:orange_terracotta
setblock 170 141 583 minecraft:white_concrete
fill 170 141 584 176 141 584 minecraft:orange_terracotta
setblock 170 141 591 minecraft:white_concrete
fill 170 141 592 176 141 592 minecraft:orange_terracotta
fill 171 141 557 172 141 557 minecraft:gold_block
setblock 171 141 558 minecraft:white_concrete
fill 171 141 559 177 141 559 minecraft:orange_terracotta
setblock 171 141 566 minecraft:white_concrete
fill 171 141 567 177 141 567 minecraft:orange_terracotta
setblock 171 141 574 minecraft:white_concrete
fill 171 141 575 177 141 575 minecraft:orange_terracotta
setblock 171 141 582 minecraft:white_concrete
fill 171 141 583 177 141 583 minecraft:orange_terracotta
setblock 171 141 590 minecraft:white_concrete
fill 171 141 591 177 141 591 minecraft:orange_terracotta
setblock 171 141 598 minecraft:white_concrete
fill 172 141 558 178 141 558 minecraft:orange_terracotta
setblock 172 141 565 minecraft:white_concrete
fill 172 141 566 178 141 566 minecraft:orange_terracotta
setblock 172 141 573 minecraft:white_concrete
fill 172 141 574 178 141 574 minecraft:orange_terracotta
setblock 172 141 581 minecraft:white_concrete
fill 172 141 582 178 141 582 minecraft:orange_terracotta
setblock 172 141 589 minecraft:white_concrete
fill 172 141 590 178 141 590 minecraft:orange_terracotta
setblock 172 141 597 minecraft:white_concrete
fill 172 141 598 178 141 598 minecraft:orange_terracotta
fill 173 141 557 173 218 557 minecraft:blue_concrete
setblock 173 141 564 minecraft:white_concrete
fill 173 141 565 179 141 565 minecraft:orange_terracotta
setblock 173 141 572 minecraft:white_concrete
fill 173 141 573 179 141 573 minecraft:orange_terracotta
setblock 173 141 580 minecraft:white_concrete
fill 173 141 581 179 141 581 minecraft:orange_terracotta
setblock 173 141 588 minecraft:white_concrete
fill 173 141 589 179 141 589 minecraft:orange_terracotta
setblock 173 141 596 minecraft:white_concrete
fill 173 141 597 179 141 597 minecraft:orange_terracotta
setblock 174 141 563 minecraft:white_concrete
fill 174 141 564 180 141 564 minecraft:orange_terracotta
setblock 174 141 570 minecraft:orange_terracotta
setblock 174 141 571 minecraft:white_concrete
fill 174 141 572 180 141 572 minecraft:orange_terracotta
setblock 174 141 579 minecraft:white_concrete
fill 174 141 580 180 141 580 minecraft:orange_terracotta
setblock 174 141 587 minecraft:white_concrete
fill 174 141 588 180 141 588 minecraft:orange_terracotta
setblock 174 141 595 minecraft:white_concrete
fill 174 141 596 180 141 596 minecraft:orange_terracotta
setblock 175 141 562 minecraft:white_concrete
fill 175 141 563 181 141 563 minecraft:orange_terracotta
setblock 175 141 570 minecraft:white_concrete
fill 175 141 571 181 141 571 minecraft:orange_terracotta
setblock 175 141 578 minecraft:white_concrete
fill 175 141 579 181 141 579 minecraft:orange_terracotta
setblock 175 141 586 minecraft:white_concrete
fill 175 141 587 181 141 587 minecraft:orange_terracotta
setblock 175 141 594 minecraft:white_concrete
fill 175 141 595 181 141 595 minecraft:orange_terracotta
setblock 176 141 561 minecraft:white_concrete
fill 176 141 562 182 141 562 minecraft:orange_terracotta
setblock 176 141 569 minecraft:white_concrete
fill 176 141 570 182 141 570 minecraft:orange_terracotta
setblock 176 141 577 minecraft:white_concrete
fill 176 141 578 182 141 578 minecraft:orange_terracotta
setblock 176 141 585 minecraft:white_concrete
fill 176 141 586 182 141 586 minecraft:orange_terracotta
setblock 176 141 593 minecraft:white_concrete
fill 176 141 594 182 141 594 minecraft:orange_terracotta
setblock 177 141 560 minecraft:white_concrete
fill 177 141 561 182 141 561 minecraft:orange_terracotta
setblock 177 141 568 minecraft:white_concrete
fill 177 141 569 182 141 569 minecraft:orange_terracotta
setblock 177 141 576 minecraft:white_concrete
fill 177 141 577 182 141 577 minecraft:orange_terracotta
setblock 177 141 584 minecraft:white_concrete
fill 177 141 585 182 141 585 minecraft:orange_terracotta
setblock 177 141 592 minecraft:white_concrete
fill 177 141 593 182 141 593 minecraft:orange_terracotta
setblock 178 141 559 minecraft:white_concrete
fill 178 141 560 182 141 560 minecraft:orange_terracotta
setblock 178 141 567 minecraft:white_concrete
fill 178 141 568 182 141 568 minecraft:orange_terracotta
setblock 178 141 575 minecraft:white_concrete
fill 178 141 576 182 141 576 minecraft:orange_terracotta
setblock 178 141 583 minecraft:white_concrete
fill 178 141 584 182 141 584 minecraft:orange_terracotta
setblock 178 141 591 minecraft:white_concrete
fill 178 141 592 182 141 592 minecraft:orange_terracotta
setblock 179 141 558 minecraft:white_concrete
fill 179 141 559 182 141 559 minecraft:orange_terracotta
setblock 179 141 566 minecraft:white_concrete
fill 179 141 567 182 141 567 minecraft:orange_terracotta
setblock 179 141 574 minecraft:white_concrete
fill 179 141 575 182 141 575 minecraft:orange_terracotta
setblock 179 141 582 minecraft:white_concrete
fill 179 141 583 182 141 583 minecraft:orange_terracotta
setblock 179 141 590 minecraft:white_concrete
fill 179 141 591 182 141 591 minecraft:orange_terracotta
setblock 179 141 598 minecraft:white_concrete
fill 179 141 599 179 153 599 minecraft:blue_concrete
fill 180 141 558 182 141 558 minecraft:orange_terracotta
setblock 180 141 565 minecraft:white_concrete
fill 180 141 566 182 141 566 minecraft:orange_terracotta
setblock 180 141 573 minecraft:white_concrete
fill 180 141 574 182 141 574 minecraft:orange_terracotta
setblock 180 141 581 minecraft:white_concrete
fill 180 141 582 182 141 582 minecraft:orange_terracotta
setblock 180 141 589 minecraft:white_concrete
fill 180 141 590 182 141 590 minecraft:orange_terracotta
setblock 180 141 597 minecraft:white_concrete
fill 180 141 598 182 141 598 minecraft:orange_terracotta
setblock 181 141 564 minecraft:white_concrete
fill 181 141 565 182 141 565 minecraft:orange_terracotta
setblock 181 141 572 minecraft:white_concrete
fill 181 141 573 182 141 573 minecraft:orange_terracotta
setblock 181 141 580 minecraft:white_concrete
fill 181 141 581 182 141 581 minecraft:orange_terracotta
setblock 181 141 588 minecraft:white_concrete
fill 181 141 589 182 141 589 minecraft:orange_terracotta
setblock 181 141 596 minecraft:white_concrete
fill 181 141 597 182 141 597 minecraft:orange_terracotta
setblock 182 141 563 minecraft:white_concrete
setblock 182 141 564 minecraft:orange_terracotta
setblock 182 141 571 minecraft:white_concrete
setblock 182 141 572 minecraft:orange_terracotta
setblock 182 141 579 minecraft:white_concrete
setblock 182 141 580 minecraft:orange_terracotta
setblock 182 141 587 minecraft:white_concrete
setblock 182 141 588 minecraft:orange_terracotta
setblock 182 141 595 minecraft:white_concrete
setblock 182 141 596 minecraft:orange_terracotta
setblock 183 141 575 minecraft:shroomlight
setblock 183 141 583 minecraft:shroomlight
fill 183 141 584 183 189 584 minecraft:blue_concrete
fill 148 142 557 148 144 557 minecraft:blue_concrete
setblock 151 142 570 minecraft:gold_block
fill 158 142 557 172 143 557 minecraft:blue_concrete
fill 161 142 565 161 148 567 minecraft:white_concrete
fill 161 142 569 161 142 575 minecraft:white_concrete
setblock 165 142 584 minecraft:gold_block
setblock 179 142 570 minecraft:gold_block
fill 183 142 575 183 147 575 minecraft:blue_concrete
fill 183 142 583 183 144 583 minecraft:blue_concrete
fill 161 143 568 161 146 572 minecraft:red_concrete
fill 161 143 573 161 148 575 minecraft:white_concrete
fill 183 143 568 183 152 570 minecraft:blue_concrete
setblock 183 143 571 minecraft:shroomlight
fill 183 143 572 183 160 574 minecraft:blue_concrete
setblock 144 144 560 minecraft:light[level=14]
setblock 144 144 568 minecraft:light[level=14]
setblock 144 144 576 minecraft:light[level=14]
setblock 144 144 584 minecraft:light[level=14]
setblock 144 144 592 minecraft:light[level=14]
setblock 152 144 560 minecraft:light[level=14]
setblock 152 144 568 minecraft:light[level=14]
setblock 152 144 576 minecraft:light[level=14]
setblock 152 144 584 minecraft:light[level=14]
setblock 152 144 592 minecraft:light[level=14]
fill 158 144 557 160 152 557 minecraft:blue_concrete
setblock 160 144 560 minecraft:light[level=14]
setblock 160 144 568 minecraft:light[level=14]
setblock 160 144 576 minecraft:light[level=14]
setblock 160 144 584 minecraft:light[level=14]
setblock 160 144 592 minecraft:light[level=14]
setblock 161 144 557 minecraft:white_concrete
fill 162 144 557 172 148 557 minecraft:blue_concrete
setblock 168 144 560 minecraft:light[level=14]
setblock 168 144 568 minecraft:light[level=14]
setblock 168 144 576 minecraft:light[level=14]
setblock 168 144 584 minecraft:light[level=14]
setblock 168 144 592 minecraft:light[level=14]
setblock 176 144 560 minecraft:light[level=14]
setblock 176 144 568 minecraft:light[level=14]
setblock 176 144 576 minecraft:light[level=14]
setblock 176 144 584 minecraft:light[level=14]
setblock 176 144 592 minecraft:light[level=14]
fill 183 144 571 183 168 571 minecraft:blue_concrete
fill 141 145 565 141 146 565 minecraft:gold_block
fill 141 145 579 141 201 579 minecraft:blue_concrete
setblock 141 145 580 minecraft:white_concrete
fill 141 145 581 141 146 581 minecraft:gold_block
fill 141 145 597 141 146 597 minecraft:gold_block
fill 145 145 557 145 146 557 minecraft:gold_block
fill 145 145 573 145 145 583 minecraft:waxed_cut_copper
fill 146 145 557 147 150 557 minecraft:blue_concrete
fill 146 145 570 146 145 577 minecraft:waxed_cut_copper
fill 146 145 579 146 145 586 minecraft:waxed_cut_copper
fill 147 145 569 147 145 572 minecraft:waxed_cut_copper
fill 147 145 584 147 145 587 minecraft:waxed_cut_copper
setblock 148 145 557 minecraft:shroomlight
fill 148 145 567 148 145 570 minecraft:waxed_cut_copper
fill 148 145 586 148 145 589 minecraft:waxed_cut_copper
fill 149 145 566 149 145 568 minecraft:waxed_cut_copper
fill 149 145 588 149 145 590 minecraft:waxed_cut_copper
fill 150 145 565 150 145 567 minecraft:waxed_cut_copper
fill 150 145 589 150 145 591 minecraft:waxed_cut_copper
fill 151 145 564 151 145 566 minecraft:waxed_cut_copper
fill 151 145 590 151 145 592 minecraft:waxed_cut_copper
fill 152 145 564 152 145 565 minecraft:waxed_cut_copper
fill 152 145 591 152 145 592 minecraft:waxed_cut_copper
fill 153 145 563 154 145 564 minecraft:waxed_cut_copper
fill 153 145 592 154 145 593 minecraft:waxed_cut_copper
fill 154 145 562 161 145 562 minecraft:waxed_cut_copper
fill 154 145 594 161 145 594 minecraft:waxed_cut_copper
fill 155 145 563 156 145 563 minecraft:waxed_cut_copper
fill 155 145 593 156 145 593 minecraft:waxed_cut_copper
fill 155 145 599 155 146 599 minecraft:gold_block
fill 157 145 561 167 145 561 minecraft:waxed_cut_copper
fill 157 145 595 167 145 595 minecraft:waxed_cut_copper
fill 161 145 557 161 146 557 minecraft:gold_block
fill 163 145 562 170 145 562 minecraft:waxed_cut_copper
fill 163 145 594 170 145 594 minecraft:waxed_cut_copper
fill 168 145 563 171 145 563 minecraft:waxed_cut_copper
fill 168 145 593 171 145 593 minecraft:waxed_cut_copper
fill 170 145 564 173 145 564 minecraft:waxed_cut_copper
fill 170 145 592 173 145 592 minecraft:waxed_cut_copper
fill 171 145 599 171 146 599 minecraft:gold_block
fill 172 145 565 174 145 565 minecraft:waxed_cut_copper
fill 172 145 591 174 145 591 minecraft:waxed_cut_copper
fill 173 145 566 175 145 566 minecraft:waxed_cut_copper
fill 173 145 590 175 145 590 minecraft:waxed_cut_copper
fill 174 145 567 176 145 567 minecraft:waxed_cut_copper
fill 174 145 589 176 145 589 minecraft:waxed_cut_copper
fill 175 145 557 176 160 557 minecraft:blue_concrete
fill 175 145 568 176 145 568 minecraft:waxed_cut_copper
fill 175 145 588 176 145 588 minecraft:waxed_cut_copper
fill 176 145 569 177 145 570 minecraft:waxed_cut_copper
fill 176 145 586 177 145 587 minecraft:waxed_cut_copper
fill 177 145 557 177 146 557 minecraft:gold_block
fill 177 145 571 178 145 572 minecraft:waxed_cut_copper
fill 177 145 584 178 145 585 minecraft:waxed_cut_copper
fill 178 145 557 180 150 557 minecraft:blue_concrete
setblock 178 145 570 minecraft:waxed_cut_copper
fill 178 145 573 179 145 577 minecraft:waxed_cut_copper
fill 178 145 579 179 145 583 minecraft:waxed_cut_copper
setblock 178 145 586 minecraft:waxed_cut_copper
setblock 179 145 578 minecraft:waxed_cut_copper
fill 180 145 599 180 218 599 minecraft:blue_concrete
setblock 181 145 599 minecraft:white_concrete
fill 183 145 566 183 216 566 minecraft:blue_concrete
fill 183 145 567 183 146 567 minecraft:gold_block
fill 183 145 583 183 146 583 minecraft:gold_block
fill 141 146 580 141 178 580 minecraft:blue_concrete
fill 147 146 587 147 146 588 minecraft:shroomlight
fill 148 146 557 148 190 557 minecraft:blue_concrete
fill 148 146 588 148 146 589 minecraft:shroomlight
setblock 149 146 590 minecraft:shroomlight
setblock 150 146 591 minecraft:shroomlight
fill 151 146 592 152 146 592 minecraft:shroomlight
fill 152 146 593 153 146 593 minecraft:shroomlight
fill 154 146 594 155 146 594 minecraft:shroomlight
setblock 155 146 557 minecraft:white_concrete
fill 156 146 557 157 181 557 minecraft:blue_concrete
fill 156 146 595 160 146 595 minecraft:shroomlight
fill 161 146 596 163 146 596 minecraft:shroomlight
fill 181 146 599 181 196 599 minecraft:blue_concrete
setblock 183 146 590 minecraft:shroomlight
fill 183 146 591 183 171 591 minecraft:blue_concrete
fill 141 147 565 141 151 567 minecraft:blue_concrete
setblock 141 147 568 minecraft:white_concrete
fill 141 147 569 141 190 569 minecraft:blue_concrete
setblock 141 147 570 minecraft:white_concrete
setblock 141 147 581 minecraft:blue_concrete
setblock 141 147 592 minecraft:shroomlight
fill 141 147 597 141 153 597 minecraft:blue_concrete
fill 145 147 557 145 153 557 minecraft:blue_concrete
fill 153 147 599 153 216 599 minecraft:blue_concrete
setblock 154 147 599 minecraft:shroomlight
fill 155 147 557 155 218 557 minecraft:blue_concrete
fill 155 147 599 155 153 599 minecraft:blue_concrete
fill 161 147 557 161 153 557 minecraft:blue_concrete
fill 161 147 568 161 148 572 minecraft:white_concrete
fill 171 147 599 171 153 599 minecraft:blue_concrete
fill 177 147 557 177 153 557 minecraft:blue_concrete
setblock 183 147 567 minecraft:blue_concrete
fill 183 147 583 183 153 583 minecraft:blue_concrete
fill 183 147 590 183 216 590 minecraft:blue_concrete
fill 183 147 596 183 155 596 minecraft:blue_concrete
setblock 183 147 597 minecraft:shroomlight
fill 141 148 568 141 177 568 minecraft:blue_concrete
fill 141 148 570 141 218 570 minecraft:blue_concrete
setblock 141 148 576 minecraft:shroomlight
setblock 141 148 581 minecraft:shroomlight
fill 141 148 592 141 218 592 minecraft:blue_concrete
fill 141 148 594 141 169 595 minecraft:blue_concrete
setblock 141 148 596 minecraft:white_concrete
setblock 142 148 557 minecraft:white_concrete
fill 154 148 599 154 153 599 minecraft:blue_concrete
setblock 183 148 559 minecraft:shroomlight
fill 183 148 560 183 170 560 minecraft:blue_concrete
setblock 183 148 567 minecraft:shroomlight
setblock 183 148 575 minecraft:shroomlight
fill 183 148 579 183 202 579 minecraft:blue_concrete
setblock 183 148 580 minecraft:white_concrete
fill 183 148 581 183 218 581 minecraft:blue_concrete
fill 183 148 597 183 171 597 minecraft:blue_concrete
fill 141 149 576 141 215 576 minecraft:blue_concrete
fill 141 149 581 141 153 581 minecraft:blue_concrete
setblock 141 149 583 minecraft:white_concrete
fill 141 149 584 141 149 585 minecraft:blue_concrete
fill 141 149 596 141 218 596 minecraft:blue_concrete
fill 142 149 557 142 189 557 minecraft:blue_concrete
setblock 147 149 599 minecraft:white_concrete
setblock 162 149 557 minecraft:shroomlight
fill 163 149 557 165 168 557 minecraft:blue_concrete
setblock 166 149 557 minecraft:shroomlight
fill 167 149 557 172 162 557 minecraft:blue_concrete
fill 172 149 599 172 156 599 minecraft:blue_concrete
setblock 173 149 599 minecraft:white_concrete
fill 174 149 599 174 166 599 minecraft:blue_concrete
fill 183 149 559 183 218 559 minecraft:blue_concrete
fill 183 149 567 183 153 567 minecraft:blue_concrete
fill 183 149 575 183 195 575 minecraft:blue_concrete
fill 183 149 580 183 155 580 minecraft:blue_concrete
setblock 141 150 559 minecraft:shroomlight
fill 141 150 560 141 164 564 minecraft:blue_concrete
fill 141 150 583 141 218 584 minecraft:blue_concrete
setblock 141 150 585 minecraft:white_concrete
fill 141 150 587 141 188 588 minecraft:blue_concrete
setblock 141 150 589 minecraft:shroomlight
fill 147 150 599 147 165 599 minecraft:blue_concrete
fill 162 150 557 162 158 557 minecraft:blue_concrete
fill 166 150 557 166 174 557 minecraft:blue_concrete
fill 173 150 599 173 201 599 minecraft:blue_concrete
fill 183 150 576 183 215 576 minecraft:blue_concrete
setblock 183 150 577 minecraft:shroomlight
fill 183 150 578 183 183 578 minecraft:blue_concrete
fill 141 151 559 141 154 559 minecraft:blue_concrete
setblock 141 151 577 minecraft:shroomlight
fill 141 151 585 141 218 585 minecraft:blue_concrete
fill 141 151 589 141 181 589 minecraft:blue_concrete
fill 146 151 557 146 165 557 minecraft:blue_concrete
setblock 147 151 557 minecraft:shroomlight
fill 150 151 557 152 164 557 minecraft:blue_concrete
setblock 153 151 557 minecraft:shroomlight
fill 154 151 557 154 194 557 minecraft:blue_concrete
setblock 178 151 557 minecraft:shroomlight
fill 179 151 557 180 190 557 minecraft:blue_concrete
fill 183 151 577 183 218 577 minecraft:blue_concrete
fill 141 152 565 141 153 566 minecraft:blue_concrete
setblock 141 152 567 minecraft:shroomlight
fill 141 152 577 141 157 577 minecraft:blue_concrete
setblock 144 152 560 minecraft:light[level=14]
setblock 144 152 568 minecraft:light[level=14]
setblock 144 152 576 minecraft:light[level=14]
setblock 144 152 584 minecraft:light[level=14]
setblock 144 152 592 minecraft:light[level=14]
fill 147 152 557 147 216 557 minecraft:blue_concrete
setblock 152 152 560 minecraft:light[level=14]
setblock 152 152 568 minecraft:light[level=14]
setblock 152 152 576 minecraft:light[level=14]
setblock 152 152 584 minecraft:light[level=14]
setblock 152 152 592 minecraft:light[level=14]
fill 153 152 557 153 185 557 minecraft:blue_concrete
setblock 160 152 560 minecraft:light[level=14]
setblock 160 152 568 minecraft:light[level=14]
setblock 160 152 576 minecraft:light[level=14]
setblock 160 152 584 minecraft:light[level=14]
setblock 160 152 592 minecraft:light[level=14]
setblock 168 152 560 minecraft:light[level=14]
setblock 168 152 568 minecraft:light[level=14]
setblock 168 152 576 minecraft:light[level=14]
setblock 168 152 584 minecraft:light[level=14]
setblock 168 152 592 minecraft:light[level=14]
setblock 175 152 599 minecraft:shroomlight
setblock 176 152 560 minecraft:light[level=14]
setblock 176 152 568 minecraft:light[level=14]
setblock 176 152 576 minecraft:light[level=14]
setblock 176 152 584 minecraft:light[level=14]
setblock 176 152 592 minecraft:light[level=14]
fill 178 152 557 178 162 557 minecraft:blue_concrete
setblock 183 152 558 minecraft:white_concrete
fill 141 153 567 141 166 567 minecraft:blue_concrete
fill 158 153 557 159 179 557 minecraft:blue_concrete
setblock 160 153 557 minecraft:white_concrete
fill 175 153 599 175 219 599 minecraft:blue_concrete
fill 183 153 558 183 188 558 minecraft:blue_concrete
fill 183 153 568 183 218 569 minecraft:blue_concrete
setblock 183 153 570 minecraft:shroomlight
fill 141 154 565 141 155 565 minecraft:gold_block
fill 141 154 566 141 216 566 minecraft:blue_concrete
fill 141 154 581 141 155 581 minecraft:gold_block
fill 141 154 597 141 155 597 minecraft:gold_block
fill 145 154 557 145 155 557 minecraft:gold_block
setblock 154 154 599 minecraft:shroomlight
fill 155 154 599 155 155 599 minecraft:gold_block
fill 160 154 557 160 203 557 minecraft:blue_concrete
fill 161 154 557 161 155 557 minecraft:gold_block
fill 171 154 599 171 155 599 minecraft:gold_block
fill 177 154 557 177 155 557 minecraft:gold_block
setblock 179 154 599 minecraft:white_concrete
setblock 183 154 561 minecraft:shroomlight
fill 183 154 567 183 155 567 minecraft:gold_block
fill 183 154 570 183 160 570 minecraft:blue_concrete
fill 183 154 583 183 155 583 minecraft:gold_block
setblock 141 155 559 minecraft:shroomlight
fill 154 155 599 154 189 599 minecraft:blue_concrete
fill 179 155 599 179 157 599 minecraft:blue_concrete
setblock 182 155 599 minecraft:white_concrete
fill 183 155 561 183 215 561 minecraft:blue_concrete
fill 141 156 559 141 215 559 minecraft:blue_concrete
fill 141 156 565 141 161 565 minecraft:blue_concrete
fill 141 156 581 141 161 581 minecraft:blue_concrete
fill 141 156 597 141 161 597 minecraft:blue_concrete
fill 145 156 557 145 161 557 minecraft:blue_concrete
fill 155 156 599 155 161 599 minecraft:blue_concrete
setblock 160 156 599 minecraft:shroomlight
fill 161 156 557 161 161 557 minecraft:blue_concrete
fill 161 156 599 161 170 599 minecraft:blue_concrete
fill 171 156 599 171 161 599 minecraft:blue_concrete
fill 177 156 557 177 161 557 minecraft:blue_concrete
fill 182 156 599 182 215 599 minecraft:blue_concrete
fill 183 156 567 183 161 567 minecraft:blue_concrete
setblock 183 156 580 minecraft:white_concrete
fill 183 156 583 183 161 583 minecraft:blue_concrete
setblock 183 156 596 minecraft:white_concrete
setblock 141 157 582 minecraft:white_concrete
fill 160 157 599 160 219 599 minecraft:blue_concrete
setblock 172 157 599 minecraft:shroomlight
setblock 174 157 557 minecraft:shroomlight
fill 183 157 580 183 176 580 minecraft:blue_concrete
fill 183 157 596 183 162 596 minecraft:blue_concrete
setblock 141 158 577 minecraft:shroomlight
fill 141 158 582 141 171 582 minecraft:blue_concrete
setblock 169 158 599 minecraft:shroomlight
fill 170 158 599 170 163 599 minecraft:blue_concrete
fill 172 158 599 172 218 599 minecraft:blue_concrete
fill 174 158 557 174 218 557 minecraft:blue_concrete
setblock 179 158 599 minecraft:shroomlight
fill 141 159 577 141 220 577 minecraft:blue_concrete
setblock 162 159 557 minecraft:shroomlight
fill 169 159 599 169 164 599 minecraft:blue_concrete
fill 179 159 599 179 184 599 minecraft:blue_concrete
setblock 144 160 560 minecraft:light[level=14]
setblock 144 160 568 minecraft:light[level=14]
setblock 144 160 576 minecraft:light[level=14]
setblock 144 160 584 minecraft:light[level=14]
setblock 144 160 592 minecraft:light[level=14]
setblock 152 160 560 minecraft:light[level=14]
setblock 152 160 568 minecraft:light[level=14]
setblock 152 160 576 minecraft:light[level=14]
setblock 152 160 584 minecraft:light[level=14]
setblock 152 160 592 minecraft:light[level=14]
setblock 160 160 560 minecraft:light[level=14]
setblock 160 160 568 minecraft:light[level=14]
setblock 160 160 576 minecraft:light[level=14]
setblock 160 160 584 minecraft:light[level=14]
setblock 160 160 592 minecraft:light[level=14]
fill 162 160 557 162 213 557 minecraft:blue_concrete
setblock 168 160 560 minecraft:light[level=14]
setblock 168 160 568 minecraft:light[level=14]
setblock 168 160 576 minecraft:light[level=14]
setblock 168 160 584 minecraft:light[level=14]
setblock 168 160 592 minecraft:light[level=14]
setblock 176 160 560 minecraft:light[level=14]
setblock 176 160 568 minecraft:light[level=14]
setblock 176 160 576 minecraft:light[level=14]
setblock 176 160 584 minecraft:light[level=14]
setblock 176 160 592 minecraft:light[level=14]
setblock 141 161 578 minecraft:white_concrete
setblock 144 161 557 minecraft:shroomlight
setblock 175 161 557 minecraft:shroomlight
fill 176 161 557 176 218 557 minecraft:blue_concrete
setblock 183 161 570 minecraft:shroomlight
setblock 183 161 572 minecraft:shroomlight
fill 183 161 573 183 192 574 minecraft:blue_concrete
fill 141 162 565 141 164 565 minecraft:gold_block
fill 141 162 578 141 200 578 minecraft:blue_concrete
fill 141 162 581 141 164 581 minecraft:gold_block
fill 141 162 597 141 164 597 minecraft:gold_block
fill 144 162 557 144 218 557 minecraft:blue_concrete
fill 145 162 557 145 164 557 minecraft:gold_block
fill 155 162 599 155 164 599 minecraft:gold_block
fill 161 162 557 161 164 557 minecraft:gold_block
fill 171 162 599 171 164 599 minecraft:gold_block
fill 175 162 557 175 178 557 minecraft:blue_concrete
fill 177 162 557 177 164 557 minecraft:gold_block
fill 183 162 567 183 164 567 minecraft:gold_block
fill 183 162 570 183 163 570 minecraft:blue_concrete
fill 183 162 572 183 193 572 minecraft:blue_concrete
fill 183 162 583 183 164 583 minecraft:gold_block
setblock 167 163 557 minecraft:shroomlight
fill 168 163 557 172 165 557 minecraft:blue_concrete
setblock 178 163 557 minecraft:shroomlight
setblock 183 163 565 minecraft:white_concrete
setblock 183 163 596 minecraft:shroomlight
setblock 141 164 571 minecraft:shroomlight
fill 167 164 557 167 179 557 minecraft:blue_concrete
setblock 170 164 599 minecraft:shroomlight
setblock 178 164 557 minecraft:white_concrete
setblock 183 164 565 minecraft:shroomlight
setblock 183 164 570 minecraft:shroomlight
fill 183 164 596 183 186 596 minecraft:blue_concrete
fill 141 165 560 141 181 563 minecraft:blue_concrete
setblock 141 165 564 minecraft:shroomlight
fill 141 165 565 141 168 565 minecraft:blue_concrete
fill 141 165 571 141 218 571 minecraft:blue_concrete
fill 141 165 581 141 170 581 minecraft:blue_concrete
fill 141 165 597 141 170 597 minecraft:blue_concrete
fill 145 165 557 145 170 557 minecraft:blue_concrete
fill 150 165 557 150 215 557 minecraft:blue_concrete
setblock 151 165 557 minecraft:shroomlight
fill 152 165 557 152 185 557 minecraft:blue_concrete
fill 155 165 599 155 170 599 minecraft:blue_concrete
fill 161 165 557 161 170 557 minecraft:blue_concrete
setblock 169 165 599 minecraft:shroomlight
fill 170 165 599 171 170 599 minecraft:blue_concrete
fill 177 165 557 178 166 557 minecraft:blue_concrete
setblock 183 165 562 minecraft:white_concrete
fill 183 165 565 183 198 565 minecraft:blue_concrete
fill 183 165 567 183 170 567 minecraft:blue_concrete
fill 183 165 570 183 219 570 minecraft:blue_concrete
fill 183 165 583 183 170 583 minecraft:blue_concrete
fill 141 166 564 141 218 564 minecraft:blue_concrete
setblock 146 166 557 minecraft:shroomlight
setblock 147 166 599 minecraft:shroomlight
fill 151 166 557 151 218 557 minecraft:blue_concrete
fill 168 166 557 169 193 557 minecraft:blue_concrete
fill 169 166 599 169 195 599 minecraft:blue_concrete
setblock 170 166 557 minecraft:shroomlight
fill 171 166 557 172 218 557 minecraft:blue_concrete
fill 183 166 562 183 206 562 minecraft:blue_concrete
setblock 141 167 567 minecraft:shroomlight
fill 146 167 557 146 218 557 minecraft:blue_concrete
fill 147 167 599 147 218 599 minecraft:blue_concrete
fill 170 167 557 170 218 557 minecraft:blue_concrete
setblock 174 167 599 minecraft:white_concrete
setblock 177 167 557 minecraft:white_concrete
setblock 177 167 599 minecraft:white_concrete
fill 178 167 557 178 218 557 minecraft:blue_concrete
fill 178 167 599 178 218 599 minecraft:blue_concrete
fill 141 168 567 141 218 567 minecraft:blue_concrete
setblock 144 168 560 minecraft:light[level=14]
setblock 144 168 568 minecraft:light[level=14]
setblock 144 168 576 minecraft:light[level=14]
setblock 144 168 584 minecraft:light[level=14]
setblock 144 168 592 minecraft:light[level=14]
setblock 149 168 599 minecraft:shroomlight
setblock 152 168 560 minecraft:light[level=14]
setblock 152 168 568 minecraft:light[level=14]
setblock 152 168 576 minecraft:light[level=14]
setblock 152 168 584 minecraft:light[level=14]
setblock 152 168 592 minecraft:light[level=14]
setblock 160 168 560 minecraft:light[level=14]
setblock 160 168 568 minecraft:light[level=14]
setblock 160 168 576 minecraft:light[level=14]
setblock 160 168 584 minecraft:light[level=14]
setblock 160 168 592 minecraft:light[level=14]
setblock 168 168 560 minecraft:light[level=14]
setblock 168 168 568 minecraft:light[level=14]
setblock 168 168 576 minecraft:light[level=14]
setblock 168 168 584 minecraft:light[level=14]
setblock 168 168 592 minecraft:light[level=14]
fill 174 168 599 174 216 599 minecraft:blue_concrete
setblock 176 168 560 minecraft:light[level=14]
setblock 176 168 568 minecraft:light[level=14]
setblock 176 168 576 minecraft:light[level=14]
setblock 176 168 584 minecraft:light[level=14]
setblock 176 168 592 minecraft:light[level=14]
fill 177 168 557 177 170 557 minecraft:blue_concrete
fill 177 168 599 177 218 599 minecraft:blue_concrete
setblock 141 169 565 minecraft:white_concrete
fill 145 169 599 145 202 599 minecraft:blue_concrete
setblock 146 169 599 minecraft:shroomlight
fill 149 169 599 149 197 599 minecraft:blue_concrete
setblock 163 169 557 minecraft:shroomlight
fill 164 169 557 165 181 557 minecraft:blue_concrete
setblock 183 169 571 minecraft:shroomlight
setblock 141 170 565 minecraft:blue_concrete
setblock 141 170 594 minecraft:shroomlight
fill 141 170 595 141 218 595 minecraft:blue_concrete
fill 146 170 599 146 218 599 minecraft:blue_concrete
fill 163 170 557 163 192 557 minecraft:blue_concrete
fill 183 170 571 183 194 571 minecraft:blue_concrete
fill 141 171 565 141 173 565 minecraft:gold_block
fill 141 171 581 141 173 581 minecraft:gold_block
fill 141 171 594 141 218 594 minecraft:blue_concrete
fill 141 171 597 141 173 597 minecraft:gold_block
fill 145 171 557 145 173 557 minecraft:gold_block
setblock 149 171 557 minecraft:shroomlight
fill 155 171 599 155 173 599 minecraft:gold_block
fill 161 171 557 161 173 557 minecraft:gold_block
setblock 161 171 599 minecraft:white_concrete
fill 170 171 599 170 204 599 minecraft:blue_concrete
fill 171 171 599 171 173 599 minecraft:gold_block
fill 177 171 557 177 173 557 minecraft:gold_block
setblock 183 171 560 minecraft:shroomlight
fill 183 171 567 183 173 567 minecraft:gold_block
fill 183 171 583 183 173 583 minecraft:gold_block
setblock 141 172 582 minecraft:white_concrete
fill 149 172 557 149 218 557 minecraft:blue_concrete
fill 161 172 599 161 218 599 minecraft:blue_concrete
fill 183 172 560 183 218 560 minecraft:blue_concrete
setblock 183 172 591 minecraft:shroomlight
setblock 183 172 597 minecraft:white_concrete
fill 141 173 582 141 188 582 minecraft:blue_concrete
fill 183 173 591 183 214 591 minecraft:blue_concrete
fill 183 173 597 183 214 597 minecraft:blue_concrete
fill 141 174 565 141 179 565 minecraft:blue_concrete
fill 141 174 581 141 179 581 minecraft:blue_concrete
fill 141 174 597 141 179 597 minecraft:blue_concrete
fill 145 174 557 145 179 557 minecraft:blue_concrete
fill 155 174 599 155 179 599 minecraft:blue_concrete
setblock 159 174 599 minecraft:white_concrete
fill 161 174 557 161 179 557 minecraft:blue_concrete
fill 171 174 599 171 179 599 minecraft:blue_concrete
fill 175 174 574 179 175 578 minecraft:polished_blackstone
fill 177 174 557 177 179 557 minecraft:blue_concrete
fill 180 174 576 181 174 576 minecraft:polished_blackstone
fill 183 174 567 183 179 567 minecraft:blue_concrete
fill 183 174 583 183 179 583 minecraft:blue_concrete
setblock 183 174 585 minecraft:blue_concrete
setblock 183 174 586 minecraft:white_concrete
setblock 150 175 599 minecraft:white_concrete
fill 151 175 599 151 218 599 minecraft:blue_concrete
setblock 156 175 599 minecraft:shroomlight
fill 159 175 599 159 218 599 minecraft:blue_concrete
setblock 166 175 557 minecraft:shroomlight
setblock 183 175 585 minecraft:shroomlight
fill 183 175 586 183 218 586 minecraft:blue_concrete
fill 142 176 567 148 176 567 minecraft:polished_blackstone
fill 142 176 599 142 218 599 minecraft:blue_concrete
setblock 143 176 599 minecraft:white_concrete
setblock 144 176 560 minecraft:light[level=14]
fill 144 176 565 148 177 566 minecraft:polished_blackstone
fill 144 176 568 148 177 569 minecraft:polished_blackstone
setblock 144 176 576 minecraft:light[level=14]
setblock 144 176 584 minecraft:light[level=14]
setblock 144 176 592 minecraft:light[level=14]
fill 150 176 599 150 191 599 minecraft:blue_concrete
setblock 152 176 560 minecraft:light[level=14]
setblock 152 176 568 minecraft:light[level=14]
setblock 152 176 576 minecraft:light[level=14]
setblock 152 176 584 minecraft:light[level=14]
setblock 152 176 592 minecraft:light[level=14]
fill 156 176 599 156 214 599 minecraft:blue_concrete
setblock 160 176 560 minecraft:light[level=14]
setblock 160 176 568 minecraft:light[level=14]
setblock 160 176 576 minecraft:light[level=14]
setblock 160 176 584 minecraft:light[level=14]
setblock 160 176 592 minecraft:light[level=14]
fill 166 176 557 166 218 557 minecraft:blue_concrete
setblock 168 176 560 minecraft:light[level=14]
setblock 168 176 568 minecraft:light[level=14]
setblock 168 176 576 minecraft:light[level=14]
setblock 168 176 584 minecraft:light[level=14]
setblock 168 176 592 minecraft:light[level=14]
setblock 168 176 599 minecraft:white_concrete
setblock 176 176 560 minecraft:light[level=14]
setblock 176 176 568 minecraft:light[level=14]
setblock 176 176 576 minecraft:light[level=14]
setblock 176 176 584 minecraft:light[level=14]
setblock 176 176 592 minecraft:light[level=14]
fill 183 176 585 183 218 585 minecraft:blue_concrete
setblock 143 177 557 minecraft:white_concrete
fill 143 177 599 143 181 599 minecraft:blue_concrete
fill 144 177 567 148 177 567 minecraft:polished_blackstone
fill 168 177 599 168 219 599 minecraft:blue_concrete
setblock 183 177 580 minecraft:shroomlight
setblock 141 178 568 minecraft:shroomlight
fill 143 178 557 143 198 557 minecraft:blue_concrete
setblock 183 178 580 minecraft:blue_concrete
fill 141 179 568 141 215 568 minecraft:blue_concrete
setblock 141 179 580 minecraft:white_concrete
fill 174 179 574 174 180 578 minecraft:waxed_copper_block
setblock 175 179 557 minecraft:shroomlight
fill 175 179 573 175 180 574 minecraft:waxed_copper_block
fill 175 179 576 179 180 576 minecraft:waxed_cut_copper
fill 175 179 578 175 180 579 minecraft:waxed_copper_block
fill 176 179 573 179 180 573 minecraft:waxed_copper_block
fill 176 179 579 179 180 579 minecraft:waxed_copper_block
fill 177 179 574 177 180 575 minecraft:waxed_cut_copper
fill 177 179 577 177 180 578 minecraft:waxed_cut_copper
fill 179 179 574 180 180 574 minecraft:waxed_copper_block
fill 179 179 578 180 180 578 minecraft:waxed_copper_block
fill 180 179 575 180 180 577 minecraft:waxed_copper_block
setblock 183 179 580 minecraft:shroomlight
fill 141 180 565 141 182 565 minecraft:gold_block
fill 141 180 580 141 218 580 minecraft:blue_concrete
fill 141 180 581 141 182 581 minecraft:gold_block
fill 141 180 597 141 182 597 minecraft:gold_block
fill 145 180 557 145 182 557 minecraft:gold_block
fill 155 180 599 155 182 599 minecraft:gold_block
fill 158 180 557 158 215 557 minecraft:blue_concrete
setblock 159 180 557 minecraft:white_concrete
fill 161 180 557 161 182 557 minecraft:gold_block
setblock 167 180 557 minecraft:shroomlight
fill 171 180 599 171 182 599 minecraft:gold_block
fill 175 180 557 175 195 557 minecraft:blue_concrete
fill 177 180 557 177 182 557 minecraft:gold_block
fill 183 180 567 183 182 567 minecraft:gold_block
fill 183 180 580 183 218 580 minecraft:blue_concrete
fill 183 180 583 183 182 583 minecraft:gold_block
fill 143 181 565 143 182 569 minecraft:waxed_copper_block
fill 144 181 564 144 182 565 minecraft:waxed_copper_block
fill 144 181 567 148 182 567 minecraft:waxed_cut_copper
fill 144 181 569 144 182 570 minecraft:waxed_copper_block
fill 145 181 564 148 182 564 minecraft:waxed_copper_block
fill 145 181 570 148 182 570 minecraft:waxed_copper_block
fill 146 181 565 146 182 566 minecraft:waxed_cut_copper
fill 146 181 568 146 182 569 minecraft:waxed_cut_copper
fill 148 181 565 149 182 565 minecraft:waxed_copper_block
fill 148 181 569 149 182 569 minecraft:waxed_copper_block
fill 149 181 566 149 182 568 minecraft:waxed_copper_block
fill 159 181 557 159 218 557 minecraft:blue_concrete
fill 167 181 557 167 182 557 minecraft:blue_concrete
fill 141 182 560 141 187 561 minecraft:blue_concrete
setblock 141 182 562 minecraft:shroomlight
fill 141 182 563 141 218 563 minecraft:blue_concrete
setblock 141 182 589 minecraft:shroomlight
setblock 143 182 599 minecraft:shroomlight
setblock 156 182 557 minecraft:shroomlight
fill 157 182 557 157 214 557 minecraft:blue_concrete
fill 164 182 557 164 214 557 minecraft:blue_concrete
setblock 165 182 557 minecraft:white_concrete
setblock 176 182 599 minecraft:shroomlight
fill 141 183 562 141 218 562 minecraft:blue_concrete
fill 141 183 565 141 188 565 minecraft:blue_concrete
fill 141 183 581 141 188 581 minecraft:blue_concrete
fill 141 183 589 141 214 589 minecraft:blue_concrete
setblock 141 183 591 minecraft:shroomlight
fill 141 183 597 141 188 597 minecraft:blue_concrete
fill 143 183 599 143 188 599 minecraft:blue_concrete
fill 145 183 557 145 188 557 minecraft:blue_concrete
fill 155 183 599 155 188 599 minecraft:blue_concrete
fill 156 183 557 156 188 557 minecraft:blue_concrete
fill 161 183 557 161 188 557 minecraft:blue_concrete
fill 165 183 557 165 218 557 minecraft:blue_concrete
setblock 167 183 557 minecraft:white_concrete
fill 171 183 599 171 188 599 minecraft:blue_concrete
fill 176 183 599 176 214 599 minecraft:blue_concrete
fill 177 183 557 177 188 557 minecraft:blue_concrete
fill 183 183 567 183 188 567 minecraft:blue_concrete
fill 183 183 583 183 188 583 minecraft:blue_concrete
fill 141 184 591 141 192 591 minecraft:blue_concrete
setblock 144 184 560 minecraft:light[level=14]
setblock 144 184 568 minecraft:light[level=14]
setblock 144 184 576 minecraft:light[level=14]
setblock 144 184 584 minecraft:light[level=14]
setblock 144 184 592 minecraft:light[level=14]
setblock 152 184 560 minecraft:light[level=14]
setblock 152 184 568 minecraft:light[level=14]
setblock 152 184 576 minecraft:light[level=14]
setblock 152 184 584 minecraft:light[level=14]
setblock 152 184 592 minecraft:light[level=14]
setblock 160 184 560 minecraft:light[level=14]
setblock 160 184 568 minecraft:light[level=14]
setblock 160 184 576 minecraft:light[level=14]
setblock 160 184 584 minecraft:light[level=14]
setblock 160 184 592 minecraft:light[level=14]
fill 167 184 557 167 218 557 minecraft:blue_concrete
setblock 168 184 560 minecraft:light[level=14]
setblock 168 184 568 minecraft:light[level=14]
setblock 168 184 576 minecraft:light[level=14]
setblock 168 184 584 minecraft:light[level=14]
setblock 168 184 592 minecraft:light[level=14]
setblock 176 184 560 minecraft:light[level=14]
setblock 176 184 568 minecraft:light[level=14]
setblock 176 184 576 minecraft:light[level=14]
setblock 176 184 584 minecraft:light[level=14]
setblock 176 184 592 minecraft:light[level=14]
setblock 183 184 578 minecraft:shroomlight
setblock 167 185 599 minecraft:shroomlight
setblock 179 185 599 minecraft:shroomlight
fill 183 185 578 183 218 578 minecraft:blue_concrete
fill 145 186 573 145 187 583 minecraft:waxed_cut_copper
fill 146 186 570 146 187 577 minecraft:waxed_cut_copper
fill 146 186 579 146 187 586 minecraft:waxed_cut_copper
fill 147 186 569 147 187 572 minecraft:waxed_cut_copper
fill 147 186 584 147 187 587 minecraft:waxed_cut_copper
fill 148 186 567 148 187 570 minecraft:waxed_cut_copper
fill 148 186 586 148 187 589 minecraft:waxed_cut_copper
fill 149 186 566 149 187 568 minecraft:waxed_cut_copper
fill 149 186 588 149 187 590 minecraft:waxed_cut_copper
fill 150 186 565 150 187 567 minecraft:waxed_cut_copper
fill 150 186 589 150 187 591 minecraft:waxed_cut_copper
fill 151 186 564 151 187 566 minecraft:waxed_cut_copper
fill 151 186 590 151 187 592 minecraft:waxed_cut_copper
fill 152 186 557 153 186 557 minecraft:shroomlight
fill 152 186 564 152 187 565 minecraft:waxed_cut_copper
fill 152 186 591 152 187 592 minecraft:waxed_cut_copper
fill 153 186 563 154 187 564 minecraft:waxed_cut_copper
fill 153 186 592 154 187 593 minecraft:waxed_cut_copper
fill 154 186 562 161 187 562 minecraft:waxed_cut_copper
fill 154 186 594 161 187 594 minecraft:waxed_cut_copper
fill 155 186 563 156 187 563 minecraft:waxed_cut_copper
fill 155 186 593 156 187 593 minecraft:waxed_cut_copper
fill 157 186 561 167 187 561 minecraft:waxed_cut_copper
fill 157 186 595 167 187 595 minecraft:waxed_cut_copper
fill 163 186 562 170 187 562 minecraft:waxed_cut_copper
fill 163 186 594 170 187 594 minecraft:waxed_cut_copper
fill 167 186 599 167 218 599 minecraft:blue_concrete
fill 168 186 563 171 187 563 minecraft:waxed_cut_copper
fill 168 186 593 171 187 593 minecraft:waxed_cut_copper
fill 170 186 564 173 187 564 minecraft:waxed_cut_copper
fill 170 186 592 173 187 592 minecraft:waxed_cut_copper
fill 172 186 565 174 187 565 minecraft:waxed_cut_copper
fill 172 186 591 174 187 591 minecraft:waxed_cut_copper
fill 173 186 566 175 187 566 minecraft:waxed_cut_copper
fill 173 186 590 175 187 590 minecraft:waxed_cut_copper
fill 174 186 567 176 187 567 minecraft:waxed_cut_copper
fill 174 186 589 176 187 589 minecraft:waxed_cut_copper
fill 175 186 568 176 187 568 minecraft:waxed_cut_copper
fill 175 186 588 176 187 588 minecraft:waxed_cut_copper
fill 176 186 569 177 187 570 minecraft:waxed_cut_copper
fill 176 186 586 177 187 587 minecraft:waxed_cut_copper
fill 177 186 571 178 187 572 minecraft:waxed_cut_copper
fill 177 186 584 178 187 585 minecraft:waxed_cut_copper
fill 178 186 570 178 187 570 minecraft:waxed_cut_copper
fill 178 186 573 179 187 577 minecraft:waxed_cut_copper
fill 178 186 579 179 187 583 minecraft:waxed_cut_copper
fill 178 186 586 178 187 586 minecraft:waxed_cut_copper
fill 179 186 578 179 187 578 minecraft:waxed_cut_copper
fill 179 186 599 179 218 599 minecraft:blue_concrete
setblock 183 186 563 minecraft:shroomlight
fill 183 186 564 183 218 564 minecraft:blue_concrete
fill 152 187 557 153 207 557 minecraft:blue_concrete
fill 183 187 563 183 198 563 minecraft:blue_concrete
setblock 183 187 596 minecraft:shroomlight
setblock 141 188 560 minecraft:shroomlight
fill 141 188 561 141 198 561 minecraft:blue_concrete
fill 152 188 563 152 188 564 minecraft:shroomlight
setblock 153 188 563 minecraft:shroomlight
fill 154 188 562 155 188 562 minecraft:shroomlight
fill 156 188 561 160 188 561 minecraft:shroomlight
fill 161 188 560 163 188 560 minecraft:shroomlight
fill 164 188 561 168 188 561 minecraft:shroomlight
fill 169 188 562 170 188 562 minecraft:shroomlight
fill 171 188 563 172 188 563 minecraft:shroomlight
fill 172 188 564 173 188 564 minecraft:shroomlight
setblock 174 188 565 minecraft:shroomlight
setblock 175 188 566 minecraft:shroomlight
fill 176 188 567 176 188 568 minecraft:shroomlight
fill 177 188 568 177 188 569 minecraft:shroomlight
setblock 177 188 587 minecraft:shroomlight
fill 178 188 570 178 188 571 minecraft:shroomlight
fill 178 188 585 178 188 586 minecraft:shroomlight
fill 179 188 572 179 188 576 minecraft:shroomlight
fill 179 188 580 179 188 584 minecraft:shroomlight
fill 180 188 577 180 188 579 minecraft:shroomlight
fill 183 188 596 183 218 596 minecraft:blue_concrete
fill 141 189 560 141 197 560 minecraft:blue_concrete
fill 141 189 565 141 191 565 minecraft:gold_block
fill 141 189 581 141 191 581 minecraft:gold_block
setblock 141 189 582 minecraft:white_concrete
setblock 141 189 587 minecraft:shroomlight
fill 141 189 588 141 218 588 minecraft:blue_concrete
fill 141 189 597 141 191 597 minecraft:gold_block
setblock 143 189 599 minecraft:shroomlight
fill 145 189 557 145 191 557 minecraft:gold_block
fill 155 189 599 155 191 599 minecraft:gold_block
setblock 156 189 557 minecraft:shroomlight
fill 161 189 557 161 191 557 minecraft:gold_block
setblock 166 189 599 minecraft:white_concrete
fill 171 189 599 171 191 599 minecraft:gold_block
fill 177 189 557 177 191 557 minecraft:gold_block
setblock 183 189 558 minecraft:shroomlight
fill 183 189 567 183 191 567 minecraft:gold_block
fill 183 189 583 183 191 583 minecraft:gold_block
fill 141 190 582 141 201 582 minecraft:blue_concrete
fill 141 190 587 141 215 587 minecraft:blue_concrete
setblock 142 190 557 minecraft:white_concrete
fill 143 190 599 143 219 599 minecraft:blue_concrete
setblock 154 190 599 minecraft:white_concrete
fill 156 190 557 156 204 557 minecraft:blue_concrete
fill 166 190 599 166 218 599 minecraft:blue_concrete
fill 183 190 558 183 204 558 minecraft:blue_concrete
setblock 183 190 584 minecraft:shroomlight
setblock 141 191 569 minecraft:shroomlight
fill 142 191 557 142 218 557 minecraft:blue_concrete
setblock 148 191 557 minecraft:shroomlight
fill 154 191 599 154 199 599 minecraft:blue_concrete
fill 179 191 557 179 218 557 minecraft:blue_concrete
setblock 180 191 557 minecraft:shroomlight
fill 183 191 584 183 214 584 minecraft:blue_concrete
fill 141 192 565 141 197 565 minecraft:blue_concrete
fill 141 192 569 141 218 569 minecraft:blue_concrete
fill 141 192 581 141 197 581 minecraft:blue_concrete
setblock 141 192 586 minecraft:shroomlight
fill 141 192 597 141 197 597 minecraft:blue_concrete
setblock 144 192 560 minecraft:light[level=14]
setblock 144 192 568 minecraft:light[level=14]
setblock 144 192 576 minecraft:light[level=14]
setblock 144 192 584 minecraft:light[level=14]
setblock 144 192 592 minecraft:light[level=14]
fill 145 192 557 145 197 557 minecraft:blue_concrete
fill 148 192 557 148 214 557 minecraft:blue_concrete
setblock 150 192 599 minecraft:shroomlight
setblock 152 192 560 minecraft:light[level=14]
setblock 152 192 568 minecraft:light[level=14]
setblock 152 192 576 minecraft:light[level=14]
setblock 152 192 584 minecraft:light[level=14]
setblock 152 192 592 minecraft:light[level=14]
fill 155 192 599 155 197 599 minecraft:blue_concrete
setblock 160 192 560 minecraft:light[level=14]
setblock 160 192 568 minecraft:light[level=14]
setblock 160 192 576 minecraft:light[level=14]
setblock 160 192 584 minecraft:light[level=14]
setblock 160 192 592 minecraft:light[level=14]
fill 161 192 557 161 197 557 minecraft:blue_concrete
setblock 168 192 560 minecraft:light[level=14]
setblock 168 192 568 minecraft:light[level=14]
setblock 168 192 576 minecraft:light[level=14]
setblock 168 192 584 minecraft:light[level=14]
setblock 168 192 592 minecraft:light[level=14]
fill 171 192 599 171 197 599 minecraft:blue_concrete
setblock 176 192 560 minecraft:light[level=14]
setblock 176 192 568 minecraft:light[level=14]
setblock 176 192 576 minecraft:light[level=14]
setblock 176 192 584 minecraft:light[level=14]
setblock 176 192 592 minecraft:light[level=14]
fill 177 192 557 177 197 557 minecraft:blue_concrete
fill 180 192 557 180 207 557 minecraft:blue_concrete
fill 183 192 567 183 197 567 minecraft:blue_concrete
fill 183 192 583 183 197 583 minecraft:blue_concrete
fill 141 193 586 141 215 586 minecraft:blue_concrete
setblock 141 193 591 minecraft:shroomlight
fill 150 193 599 150 215 599 minecraft:blue_concrete
setblock 163 193 557 minecraft:shroomlight
fill 183 193 573 183 211 573 minecraft:blue_concrete
setblock 183 193 574 minecraft:shroomlight
fill 141 194 591 141 199 591 minecraft:blue_concrete
fill 163 194 557 163 218 557 minecraft:blue_concrete
setblock 164 194 599 minecraft:shroomlight
fill 168 194 557 168 195 557 minecraft:blue_concrete
setblock 169 194 557 minecraft:shroomlight
setblock 183 194 572 minecraft:shroomlight
fill 183 194 574 183 218 574 minecraft:blue_concrete
setblock 154 195 557 minecraft:shroomlight
fill 164 195 599 164 214 599 minecraft:blue_concrete
fill 169 195 557 169 218 557 minecraft:blue_concrete
setblock 183 195 571 minecraft:shroomlight
fill 183 195 572 183 214 572 minecraft:blue_concrete
fill 154 196 557 154 218 557 minecraft:blue_concrete
setblock 168 196 557 minecraft:shroomlight
setblock 169 196 599 minecraft:shroomlight
setblock 175 196 557 minecraft:shroomlight
fill 183 196 571 183 218 571 minecraft:blue_concrete
setblock 183 196 575 minecraft:white_concrete
fill 168 197 557 168 219 557 minecraft:blue_concrete
fill 169 197 599 169 218 599 minecraft:blue_concrete
fill 175 197 557 175 219 557 minecraft:blue_concrete
setblock 181 197 599 minecraft:shroomlight
fill 183 197 575 183 215 575 minecraft:blue_concrete
setblock 141 198 560 minecraft:shroomlight
fill 141 198 565 141 200 565 minecraft:gold_block
fill 141 198 581 141 200 581 minecraft:gold_block
fill 141 198 597 141 200 597 minecraft:gold_block
fill 145 198 557 145 200 557 minecraft:gold_block
setblock 149 198 599 minecraft:shroomlight
fill 155 198 599 155 200 599 minecraft:gold_block
fill 161 198 557 161 200 557 minecraft:gold_block
fill 171 198 599 171 200 599 minecraft:gold_block
fill 177 198 557 177 200 557 minecraft:gold_block
fill 181 198 599 181 218 599 minecraft:blue_concrete
fill 183 198 567 183 200 567 minecraft:gold_block
fill 183 198 583 183 200 583 minecraft:gold_block
fill 141 199 560 141 215 560 minecraft:blue_concrete
setblock 141 199 561 minecraft:shroomlight
setblock 143 199 557 minecraft:shroomlight
fill 149 199 599 149 201 599 minecraft:blue_concrete
fill 152 199 563 155 204 565 minecraft:light_blue_concrete
fill 153 199 562 155 204 562 minecraft:light_blue_concrete
fill 154 199 566 154 204 566 minecraft:light_blue_concrete
fill 156 199 563 156 204 564 minecraft:light_blue_concrete
setblock 183 199 563 minecraft:shroomlight
setblock 183 199 565 minecraft:shroomlight
setblock 183 199 593 minecraft:shroomlight
fill 141 200 561 141 214 561 minecraft:blue_concrete
setblock 141 200 591 minecraft:shroomlight
fill 143 200 557 143 218 557 minecraft:blue_concrete
setblock 144 200 560 minecraft:light[level=14]
setblock 144 200 568 minecraft:light[level=14]
setblock 144 200 576 minecraft:light[level=14]
setblock 144 200 584 minecraft:light[level=14]
setblock 144 200 592 minecraft:light[level=14]
fill 151 200 563 151 203 564 minecraft:light_blue_concrete
setblock 152 200 560 minecraft:light[level=14]
fill 152 200 562 152 203 562 minecraft:light_blue_concrete
fill 152 200 566 153 203 566 minecraft:light_blue_concrete
setblock 152 200 568 minecraft:light[level=14]
setblock 152 200 576 minecraft:light[level=14]
setblock 152 200 584 minecraft:light[level=14]
setblock 152 200 592 minecraft:light[level=14]
fill 153 200 561 155 203 561 minecraft:light_blue_concrete
setblock 154 200 599 minecraft:white_concrete
fill 155 200 566 156 203 566 minecraft:light_blue_concrete
fill 156 200 562 156 203 562 minecraft:light_blue_concrete
fill 156 200 565 156 203 565 minecraft:light_blue_concrete
fill 157 200 563 157 203 564 minecraft:light_blue_concrete
setblock 160 200 560 minecraft:light[level=14]
setblock 160 200 568 minecraft:light[level=14]
setblock 160 200 576 minecraft:light[level=14]
setblock 160 200 584 minecraft:light[level=14]
setblock 160 200 592 minecraft:light[level=14]
setblock 168 200 560 minecraft:light[level=14]
setblock 168 200 568 minecraft:light[level=14]
setblock 168 200 576 minecraft:light[level=14]
setblock 168 200 584 minecraft:light[level=14]
setblock 168 200 592 minecraft:light[level=14]
setblock 176 200 560 minecraft:light[level=14]
setblock 176 200 568 minecraft:light[level=14]
setblock 176 200 576 minecraft:light[level=14]
setblock 176 200 584 minecraft:light[level=14]
setblock 176 200 592 minecraft:light[level=14]
fill 183 200 563 183 218 563 minecraft:blue_concrete
fill 183 200 565 183 218 565 minecraft:blue_concrete
fill 183 200 593 183 218 593 minecraft:blue_concrete
fill 141 201 565 141 206 565 minecraft:blue_concrete
setblock 141 201 578 minecraft:white_concrete
fill 141 201 581 141 206 581 minecraft:blue_concrete
fill 141 201 591 141 218 591 minecraft:blue_concrete
fill 141 201 597 141 206 597 minecraft:blue_concrete
fill 145 201 557 145 206 557 minecraft:blue_concrete
fill 151 201 562 151 202 562 minecraft:light_blue_concrete
fill 151 201 565 151 202 565 minecraft:light_blue_concrete
fill 152 201 561 152 202 561 minecraft:light_blue_concrete
fill 154 201 567 154 202 567 minecraft:light_blue_concrete
fill 154 201 599 155 206 599 minecraft:blue_concrete
fill 156 201 561 156 202 561 minecraft:light_blue_concrete
fill 157 201 565 157 202 565 minecraft:light_blue_concrete
fill 157 201 599 157 219 599 minecraft:blue_concrete
setblock 158 201 599 minecraft:white_concrete
fill 161 201 557 161 206 557 minecraft:blue_concrete
fill 171 201 599 171 203 599 minecraft:blue_concrete
fill 177 201 557 177 206 557 minecraft:blue_concrete
fill 183 201 567 183 204 567 minecraft:blue_concrete
fill 183 201 583 183 206 583 minecraft:blue_concrete
fill 141 202 578 141 218 578 minecraft:blue_concrete
setblock 141 202 579 minecraft:shroomlight
setblock 141 202 582 minecraft:shroomlight
setblock 149 202 599 minecraft:shroomlight
fill 158 202 599 158 216 599 minecraft:blue_concrete
setblock 173 202 599 minecraft:shroomlight
fill 141 203 579 141 218 579 minecraft:blue_concrete
fill 141 203 582 141 215 582 minecraft:blue_concrete
setblock 145 203 599 minecraft:shroomlight
setblock 149 203 599 minecraft:blue_concrete
fill 173 203 599 173 218 599 minecraft:blue_concrete
setblock 183 203 579 minecraft:shroomlight
setblock 183 203 592 minecraft:white_concrete
fill 145 204 599 145 218 599 minecraft:blue_concrete
setblock 149 204 599 minecraft:shroomlight
setblock 160 204 557 minecraft:white_concrete
setblock 171 204 599 minecraft:white_concrete
fill 183 204 579 183 218 579 minecraft:blue_concrete
fill 183 204 592 183 218 592 minecraft:blue_concrete
setblock 183 204 594 minecraft:white_concrete
fill 183 204 595 183 218 595 minecraft:blue_concrete
fill 149 205 599 149 214 599 minecraft:blue_concrete
setblock 156 205 557 minecraft:shroomlight
fill 160 205 557 160 218 557 minecraft:blue_concrete
setblock 170 205 599 minecraft:shroomlight
fill 171 205 599 171 206 599 minecraft:blue_concrete
setblock 183 205 558 minecraft:shroomlight
setblock 183 205 567 minecraft:shroomlight
fill 183 205 594 183 218 594 minecraft:blue_concrete
fill 156 206 557 156 208 557 minecraft:blue_concrete
fill 170 206 599 170 218 599 minecraft:blue_concrete
fill 183 206 558 183 214 558 minecraft:blue_concrete
setblock 183 206 567 minecraft:blue_concrete
fill 141 207 565 141 209 565 minecraft:gold_block
fill 141 207 581 141 209 581 minecraft:gold_block
fill 141 207 597 141 209 597 minecraft:gold_block
fill 145 207 557 145 209 557 minecraft:gold_block
fill 154 207 599 154 218 599 minecraft:blue_concrete
fill 155 207 599 155 209 599 minecraft:gold_block
fill 161 207 557 161 209 557 minecraft:gold_block
fill 171 207 599 171 209 599 minecraft:gold_block
fill 177 207 557 177 209 557 minecraft:gold_block
setblock 183 207 562 minecraft:shroomlight
fill 183 207 567 183 209 567 minecraft:gold_block
fill 183 207 583 183 209 583 minecraft:gold_block
setblock 141 208 593 minecraft:white_concrete
setblock 144 208 560 minecraft:light[level=14]
setblock 144 208 568 minecraft:light[level=14]
setblock 144 208 576 minecraft:light[level=14]
setblock 144 208 584 minecraft:light[level=14]
setblock 144 208 592 minecraft:light[level=14]
setblock 152 208 557 minecraft:shroomlight
setblock 152 208 560 minecraft:light[level=14]
setblock 152 208 568 minecraft:light[level=14]
setblock 152 208 576 minecraft:light[level=14]
setblock 152 208 584 minecraft:light[level=14]
setblock 152 208 592 minecraft:light[level=14]
fill 153 208 557 153 218 557 minecraft:blue_concrete
fill 160 208 560 164 209 564 minecraft:polished_blackstone
setblock 160 208 568 minecraft:light[level=14]
setblock 160 208 576 minecraft:light[level=14]
setblock 160 208 584 minecraft:light[level=14]
setblock 160 208 592 minecraft:light[level=14]
fill 162 208 558 162 208 559 minecraft:polished_blackstone
setblock 168 208 560 minecraft:light[level=14]
setblock 168 208 568 minecraft:light[level=14]
setblock 168 208 576 minecraft:light[level=14]
setblock 168 208 584 minecraft:light[level=14]
setblock 168 208 592 minecraft:light[level=14]
setblock 176 208 560 minecraft:light[level=14]
setblock 176 208 568 minecraft:light[level=14]
setblock 176 208 576 minecraft:light[level=14]
setblock 176 208 584 minecraft:light[level=14]
setblock 176 208 592 minecraft:light[level=14]
setblock 180 208 557 minecraft:white_concrete
fill 183 208 562 183 215 562 minecraft:blue_concrete
fill 141 209 593 141 214 593 minecraft:blue_concrete
fill 152 209 557 152 218 557 minecraft:blue_concrete
setblock 156 209 557 minecraft:shroomlight
setblock 162 209 599 minecraft:white_concrete
fill 180 209 557 180 214 557 minecraft:blue_concrete
fill 141 210 565 141 218 565 minecraft:blue_concrete
fill 141 210 581 141 216 581 minecraft:blue_concrete
fill 141 210 597 141 213 597 minecraft:blue_concrete
fill 145 210 557 145 218 557 minecraft:blue_concrete
fill 155 210 599 155 219 599 minecraft:blue_concrete
fill 156 210 557 156 218 557 minecraft:blue_concrete
fill 161 210 557 161 218 557 minecraft:blue_concrete
fill 162 210 599 162 218 599 minecraft:blue_concrete
fill 171 210 599 171 214 599 minecraft:blue_concrete
fill 177 210 557 177 216 557 minecraft:blue_concrete
fill 183 210 567 183 218 567 minecraft:blue_concrete
fill 183 210 583 183 218 583 minecraft:blue_concrete
setblock 183 211 598 minecraft:white_concrete
setblock 183 212 573 minecraft:shroomlight
fill 183 212 598 183 218 598 minecraft:blue_concrete
fill 183 213 573 183 218 573 minecraft:blue_concrete
setblock 141 214 597 minecraft:shroomlight
setblock 162 214 557 minecraft:shroomlight
setblock 141 215 557 minecraft:black_concrete
fill 141 215 558 141 219 558 minecraft:blue_concrete
setblock 141 215 561 minecraft:black_concrete
setblock 141 215 589 minecraft:black_concrete
setblock 141 215 593 minecraft:black_concrete
fill 141 215 597 141 218 597 minecraft:blue_concrete
setblock 148 215 557 minecraft:black_concrete
fill 149 215 599 149 216 599 minecraft:black_concrete
setblock 156 215 599 minecraft:shroomlight
fill 157 215 557 157 217 557 minecraft:black_concrete
fill 162 215 557 162 219 557 minecraft:blue_concrete
setblock 164 215 557 minecraft:black_concrete
setblock 164 215 599 minecraft:black_concrete
setblock 171 215 599 minecraft:black_concrete
setblock 176 215 599 minecraft:shroomlight
setblock 180 215 557 minecraft:black_concrete
setblock 183 215 558 minecraft:black_concrete
setblock 183 215 572 minecraft:black_concrete
fill 183 215 582 183 216 582 minecraft:black_concrete
setblock 183 215 584 minecraft:black_concrete
setblock 183 215 591 minecraft:black_concrete
setblock 183 215 597 minecraft:black_concrete
fill 141 216 557 141 218 557 minecraft:blue_concrete
fill 141 216 559 141 216 560 minecraft:black_concrete
fill 141 216 561 141 218 561 minecraft:blue_concrete
setblock 141 216 568 minecraft:black_concrete
setblock 141 216 576 minecraft:shroomlight
setblock 141 216 582 minecraft:black_concrete
fill 141 216 586 141 216 587 minecraft:black_concrete
fill 141 216 589 141 218 589 minecraft:blue_concrete
fill 141 216 593 141 218 593 minecraft:blue_concrete
setblock 144 216 560 minecraft:light[level=14]
setblock 144 216 568 minecraft:light[level=14]
setblock 144 216 576 minecraft:light[level=14]
setblock 144 216 584 minecraft:light[level=14]
setblock 144 216 592 minecraft:light[level=14]
fill 148 216 557 148 219 557 minecraft:blue_concrete
setblock 150 216 557 minecraft:shroomlight
setblock 150 216 599 minecraft:shroomlight
setblock 152 216 560 minecraft:light[level=14]
setblock 152 216 568 minecraft:light[level=14]
setblock 152 216 576 minecraft:light[level=14]
setblock 152 216 584 minecraft:light[level=14]
setblock 152 216 592 minecraft:light[level=14]
setblock 152 216 599 minecraft:black_concrete
fill 156 216 599 156 218 599 minecraft:blue_concrete
fill 158 216 557 158 217 557 minecraft:black_concrete
setblock 160 216 560 minecraft:light[level=14]
setblock 160 216 568 minecraft:light[level=14]
setblock 160 216 576 minecraft:light[level=14]
setblock 160 216 584 minecraft:light[level=14]
setblock 160 216 592 minecraft:light[level=14]
fill 164 216 557 164 218 557 minecraft:blue_concrete
fill 164 216 599 164 218 599 minecraft:blue_concrete
setblock 168 216 560 minecraft:light[level=14]
setblock 168 216 568 minecraft:light[level=14]
setblock 168 216 576 minecraft:light[level=14]
setblock 168 216 584 minecraft:light[level=14]
setblock 168 216 592 minecraft:light[level=14]
fill 171 216 599 171 218 599 minecraft:blue_concrete
setblock 176 216 560 minecraft:light[level=14]
setblock 176 216 568 minecraft:light[level=14]
setblock 176 216 576 minecraft:light[level=14]
setblock 176 216 584 minecraft:light[level=14]
setblock 176 216 592 minecraft:light[level=14]
fill 176 216 599 176 218 599 minecraft:blue_concrete
fill 180 216 557 180 219 557 minecraft:blue_concrete
setblock 181 216 557 minecraft:black_concrete
setblock 182 216 599 minecraft:black_concrete
fill 183 216 558 183 218 558 minecraft:blue_concrete
fill 183 216 561 183 216 562 minecraft:black_concrete
fill 183 216 572 183 218 572 minecraft:blue_concrete
setblock 183 216 575 minecraft:shroomlight
setblock 183 216 576 minecraft:black_concrete
fill 183 216 584 183 218 584 minecraft:blue_concrete
fill 183 216 591 183 218 591 minecraft:blue_concrete
fill 183 216 597 183 218 597 minecraft:blue_concrete
fill 141 217 559 141 218 560 minecraft:blue_concrete
setblock 141 217 566 minecraft:shroomlight
fill 141 217 568 141 218 568 minecraft:blue_concrete
fill 141 217 576 141 218 576 minecraft:blue_concrete
setblock 141 217 581 minecraft:black_concrete
fill 141 217 582 141 218 582 minecraft:blue_concrete
setblock 141 217 586 minecraft:black_concrete
fill 141 217 587 141 218 587 minecraft:blue_concrete
setblock 147 217 557 minecraft:black_concrete
fill 149 217 599 150 217 599 minecraft:blue_concrete
fill 150 217 557 150 218 557 minecraft:blue_concrete
fill 152 217 599 152 218 599 minecraft:blue_concrete
setblock 153 217 599 minecraft:black_concrete
setblock 158 217 599 minecraft:white_concrete
fill 159 217 569 161 217 571 minecraft:redstone_block
fill 159 217 575 161 217 577 minecraft:redstone_block
setblock 163 217 599 minecraft:black_concrete
setblock 165 217 599 minecraft:black_concrete
fill 166 217 568 168 217 570 minecraft:redstone_block
fill 167 217 575 169 217 577 minecraft:redstone_block
setblock 174 217 599 minecraft:black_concrete
setblock 177 217 557 minecraft:black_concrete
fill 181 217 557 181 218 557 minecraft:blue_concrete
fill 182 217 599 182 218 599 minecraft:blue_concrete
setblock 183 217 557 minecraft:black_concrete
setblock 183 217 561 minecraft:shroomlight
fill 183 217 562 183 218 562 minecraft:blue_concrete
setblock 183 217 566 minecraft:black_concrete
fill 183 217 575 183 218 576 minecraft:blue_concrete
fill 183 217 582 183 218 582 minecraft:blue_concrete
fill 183 217 588 183 218 588 minecraft:blue_concrete
fill 183 217 589 183 217 590 minecraft:black_concrete
setblock 141 218 566 minecraft:blue_concrete
setblock 141 218 572 minecraft:blue_concrete
setblock 141 218 573 minecraft:shroomlight
fill 141 218 574 141 218 575 minecraft:blue_concrete
setblock 141 218 581 minecraft:blue_concrete
setblock 141 218 586 minecraft:blue_concrete
setblock 147 218 557 minecraft:blue_concrete
setblock 149 218 599 minecraft:shroomlight
setblock 150 218 599 minecraft:blue_concrete
fill 153 218 573 154 219 573 minecraft:black_concrete
fill 153 218 599 153 219 599 minecraft:blue_concrete
fill 154 218 569 154 219 570 minecraft:black_concrete
fill 154 218 571 154 219 571 minecraft:blue_concrete
fill 154 218 572 155 219 572 minecraft:black_concrete
fill 154 218 574 154 219 574 minecraft:blue_concrete
fill 154 218 575 154 219 576 minecraft:black_concrete
fill 154 218 577 154 219 577 minecraft:blue_concrete
fill 155 218 567 155 219 567 minecraft:blue_concrete
fill 155 218 568 155 219 569 minecraft:black_concrete
fill 155 218 570 155 219 570 minecraft:blue_concrete
fill 155 218 571 156 219 571 minecraft:black_concrete
fill 155 218 573 155 219 573 minecraft:blue_concrete
fill 155 218 574 155 219 575 minecraft:black_concrete
fill 155 218 576 155 219 576 minecraft:blue_concrete
fill 155 218 577 155 219 578 minecraft:black_concrete
fill 155 218 579 155 219 579 minecraft:blue_concrete
fill 156 218 566 156 219 566 minecraft:blue_concrete
fill 156 218 567 156 219 568 minecraft:black_concrete
fill 156 218 569 156 219 569 minecraft:blue_concrete
fill 156 218 570 157 219 570 minecraft:black_concrete
fill 156 218 572 156 219 572 minecraft:blue_concrete
fill 156 218 573 156 219 574 minecraft:black_concrete
fill 156 218 575 156 219 575 minecraft:blue_concrete
fill 156 218 576 156 219 577 minecraft:black_concrete
fill 156 218 578 156 219 578 minecraft:blue_concrete
fill 156 218 579 156 219 580 minecraft:black_concrete
fill 157 218 557 158 218 557 minecraft:blue_concrete
fill 157 218 565 157 219 565 minecraft:blue_concrete
fill 157 218 566 157 219 567 minecraft:black_concrete
fill 157 218 568 157 219 568 minecraft:blue_concrete
fill 157 218 569 158 218 569 minecraft:black_concrete
fill 157 218 571 157 219 571 minecraft:blue_concrete
fill 157 218 572 157 219 573 minecraft:black_concrete
fill 157 218 574 157 219 574 minecraft:blue_concrete
fill 157 218 575 157 219 576 minecraft:black_concrete
fill 157 218 577 157 219 577 minecraft:blue_concrete
fill 157 218 578 157 219 579 minecraft:black_concrete
fill 157 218 580 157 219 580 minecraft:blue_concrete
fill 157 218 581 158 219 581 minecraft:black_concrete
fill 158 218 564 158 219 564 minecraft:blue_concrete
fill 158 218 565 158 219 566 minecraft:black_concrete
fill 158 218 567 158 219 567 minecraft:blue_concrete
fill 158 218 568 159 218 568 minecraft:black_concrete
setblock 158 218 570 minecraft:blue_concrete
fill 158 218 571 158 218 572 minecraft:black_concrete
fill 158 218 573 158 219 573 minecraft:blue_concrete
fill 158 218 574 158 218 575 minecraft:black_concrete
setblock 158 218 576 minecraft:blue_concrete
fill 158 218 577 158 218 578 minecraft:black_concrete
fill 158 218 579 158 219 579 minecraft:blue_concrete
fill 158 218 580 159 219 580 minecraft:black_concrete
fill 158 218 582 158 219 582 minecraft:blue_concrete
fill 158 218 599 158 219 599 minecraft:blue_concrete
fill 159 218 564 159 219 565 minecraft:black_concrete
fill 159 218 566 159 219 566 minecraft:blue_concrete
fill 159 218 567 160 219 567 minecraft:black_concrete
setblock 159 218 572 minecraft:blue_concrete
fill 159 218 573 159 218 574 minecraft:black_concrete
setblock 159 218 578 minecraft:blue_concrete
fill 159 218 579 160 219 579 minecraft:black_concrete
fill 159 218 581 159 219 581 minecraft:blue_concrete
fill 159 218 582 160 219 582 minecraft:black_concrete
fill 160 218 563 160 219 564 minecraft:black_concrete
fill 160 218 565 160 219 565 minecraft:blue_concrete
fill 160 218 566 161 219 566 minecraft:black_concrete
setblock 160 218 568 minecraft:blue_concrete
fill 160 218 572 160 218 573 minecraft:black_concrete
schedule function dropper:buildpart/135_2 1t
