fill 41 154 240 41 155 245 minecraft:chiseled_deepslate
fill 41 154 248 41 155 253 minecraft:chiseled_deepslate
fill 41 154 256 41 155 261 minecraft:chiseled_deepslate
fill 41 154 264 41 155 267 minecraft:chiseled_deepslate
fill 41 154 269 41 155 269 minecraft:chiseled_deepslate
fill 1 155 237 1 155 242 minecraft:chiseled_deepslate
fill 1 155 245 1 155 250 minecraft:chiseled_deepslate
fill 1 155 253 1 155 258 minecraft:chiseled_deepslate
fill 1 155 261 1 155 266 minecraft:chiseled_deepslate
setblock 41 155 268 minecraft:chiseled_deepslate
fill 0 158 233 0 163 233 minecraft:soul_lantern
fill 0 158 241 0 163 241 minecraft:soul_lantern
fill 0 158 249 0 163 249 minecraft:soul_lantern
fill 0 158 257 0 163 257 minecraft:soul_lantern
fill 0 158 265 0 163 265 minecraft:soul_lantern
fill 3 158 270 3 163 270 minecraft:soul_lantern
fill 7 158 228 7 163 228 minecraft:soul_lantern
fill 11 158 270 11 163 270 minecraft:soul_lantern
fill 15 158 228 15 163 228 minecraft:soul_lantern
fill 19 158 270 19 163 270 minecraft:soul_lantern
fill 23 158 228 23 163 228 minecraft:soul_lantern
fill 27 158 270 27 163 270 minecraft:soul_lantern
fill 31 158 228 31 163 228 minecraft:soul_lantern
fill 35 158 270 35 163 270 minecraft:soul_lantern
fill 39 158 228 39 163 228 minecraft:soul_lantern
fill 42 158 233 42 163 233 minecraft:soul_lantern
fill 42 158 241 42 163 241 minecraft:soul_lantern
fill 42 158 249 42 163 249 minecraft:soul_lantern
fill 42 158 257 42 163 257 minecraft:soul_lantern
fill 42 158 265 42 163 265 minecraft:soul_lantern
setblock 3 160 231 minecraft:light[level=13]
setblock 3 160 239 minecraft:light[level=13]
setblock 3 160 247 minecraft:light[level=13]
setblock 3 160 255 minecraft:light[level=13]
setblock 3 160 263 minecraft:light[level=13]
setblock 11 160 231 minecraft:light[level=13]
setblock 11 160 239 minecraft:light[level=13]
setblock 11 160 247 minecraft:light[level=13]
setblock 11 160 255 minecraft:light[level=13]
setblock 11 160 263 minecraft:light[level=13]
setblock 19 160 231 minecraft:light[level=13]
setblock 19 160 239 minecraft:light[level=13]
setblock 19 160 247 minecraft:light[level=13]
setblock 19 160 255 minecraft:light[level=13]
setblock 19 160 263 minecraft:light[level=13]
setblock 27 160 231 minecraft:light[level=13]
setblock 27 160 239 minecraft:light[level=13]
setblock 27 160 247 minecraft:light[level=13]
setblock 27 160 255 minecraft:light[level=13]
setblock 27 160 263 minecraft:light[level=13]
setblock 35 160 231 minecraft:light[level=13]
setblock 35 160 239 minecraft:light[level=13]
setblock 35 160 247 minecraft:light[level=13]
setblock 35 160 255 minecraft:light[level=13]
setblock 35 160 263 minecraft:light[level=13]
fill 0 164 233 0 171 233 minecraft:polished_deepslate
fill 0 164 241 0 171 241 minecraft:polished_deepslate
fill 0 164 249 0 171 249 minecraft:polished_deepslate
fill 0 164 257 0 171 257 minecraft:polished_deepslate
fill 0 164 265 0 171 265 minecraft:polished_deepslate
fill 3 164 270 3 171 270 minecraft:polished_deepslate
fill 7 164 228 7 171 228 minecraft:polished_deepslate
fill 11 164 270 11 171 270 minecraft:polished_deepslate
fill 15 164 228 15 171 228 minecraft:polished_deepslate
fill 19 164 270 19 171 270 minecraft:polished_deepslate
fill 23 164 228 23 171 228 minecraft:polished_deepslate
fill 27 164 270 27 171 270 minecraft:polished_deepslate
fill 31 164 228 31 171 228 minecraft:polished_deepslate
fill 35 164 270 35 171 270 minecraft:polished_deepslate
fill 39 164 228 39 171 228 minecraft:polished_deepslate
fill 42 164 233 42 171 233 minecraft:polished_deepslate
fill 42 164 241 42 171 241 minecraft:polished_deepslate
fill 42 164 249 42 171 249 minecraft:polished_deepslate
fill 42 164 257 42 171 257 minecraft:polished_deepslate
fill 42 164 265 42 171 265 minecraft:polished_deepslate
fill 27 166 262 31 167 266 minecraft:cobbled_deepslate
fill 29 166 267 29 166 268 minecraft:cobbled_deepslate
fill 1 168 229 1 169 234 minecraft:chiseled_deepslate
fill 1 168 237 2 168 242 minecraft:chiseled_deepslate
fill 1 168 245 2 168 250 minecraft:chiseled_deepslate
fill 1 168 253 2 168 258 minecraft:chiseled_deepslate
fill 1 168 261 2 168 266 minecraft:chiseled_deepslate
fill 1 168 269 6 169 269 minecraft:chiseled_deepslate
fill 2 168 230 2 168 236 minecraft:chiseled_deepslate
fill 2 168 243 2 168 244 minecraft:chiseled_deepslate
fill 2 168 251 2 168 252 minecraft:chiseled_deepslate
fill 2 168 259 2 168 260 minecraft:chiseled_deepslate
fill 2 168 267 2 168 268 minecraft:chiseled_deepslate
fill 3 168 230 40 168 230 minecraft:chiseled_deepslate
setblock 3 168 231 minecraft:light[level=13]
setblock 3 168 239 minecraft:light[level=13]
setblock 3 168 247 minecraft:light[level=13]
setblock 3 168 255 minecraft:light[level=13]
setblock 3 168 263 minecraft:light[level=13]
fill 3 168 268 41 168 268 minecraft:chiseled_deepslate
fill 4 168 229 9 169 229 minecraft:chiseled_deepslate
fill 9 168 269 14 169 269 minecraft:chiseled_deepslate
setblock 11 168 231 minecraft:light[level=13]
setblock 11 168 239 minecraft:light[level=13]
setblock 11 168 247 minecraft:light[level=13]
setblock 11 168 255 minecraft:light[level=13]
setblock 11 168 263 minecraft:light[level=13]
fill 12 168 229 17 169 229 minecraft:chiseled_deepslate
fill 17 168 269 22 169 269 minecraft:chiseled_deepslate
setblock 19 168 231 minecraft:light[level=13]
setblock 19 168 239 minecraft:light[level=13]
setblock 19 168 247 minecraft:light[level=13]
setblock 19 168 255 minecraft:light[level=13]
setblock 19 168 263 minecraft:light[level=13]
fill 20 168 229 25 169 229 minecraft:chiseled_deepslate
fill 25 168 269 30 169 269 minecraft:chiseled_deepslate
setblock 27 168 231 minecraft:light[level=13]
setblock 27 168 239 minecraft:light[level=13]
setblock 27 168 247 minecraft:light[level=13]
setblock 27 168 255 minecraft:light[level=13]
setblock 27 168 263 minecraft:light[level=13]
fill 28 168 229 33 169 229 minecraft:chiseled_deepslate
fill 28 168 263 30 169 265 minecraft:chiseled_deepslate
fill 33 168 269 38 169 269 minecraft:chiseled_deepslate
setblock 35 168 231 minecraft:light[level=13]
setblock 35 168 239 minecraft:light[level=13]
setblock 35 168 247 minecraft:light[level=13]
setblock 35 168 255 minecraft:light[level=13]
setblock 35 168 263 minecraft:light[level=13]
fill 36 168 229 41 169 229 minecraft:chiseled_deepslate
fill 40 168 231 40 168 267 minecraft:chiseled_deepslate
fill 41 168 232 41 169 237 minecraft:chiseled_deepslate
fill 41 168 240 41 169 245 minecraft:chiseled_deepslate
fill 41 168 248 41 169 253 minecraft:chiseled_deepslate
fill 41 168 256 41 169 261 minecraft:chiseled_deepslate
fill 41 168 264 41 169 267 minecraft:chiseled_deepslate
fill 41 168 269 41 169 269 minecraft:chiseled_deepslate
fill 1 169 237 1 169 242 minecraft:chiseled_deepslate
fill 1 169 245 1 169 250 minecraft:chiseled_deepslate
fill 1 169 253 1 169 258 minecraft:chiseled_deepslate
fill 1 169 261 1 169 266 minecraft:chiseled_deepslate
setblock 41 169 268 minecraft:chiseled_deepslate
fill 28 170 264 30 172 264 minecraft:chiseled_deepslate
fill 29 170 263 29 172 263 minecraft:chiseled_deepslate
fill 29 170 265 29 172 265 minecraft:chiseled_deepslate
fill 0 172 233 0 177 233 minecraft:soul_lantern
fill 0 172 241 0 177 241 minecraft:soul_lantern
fill 0 172 249 0 177 249 minecraft:soul_lantern
fill 0 172 257 0 177 257 minecraft:soul_lantern
fill 0 172 265 0 177 265 minecraft:soul_lantern
fill 3 172 270 3 177 270 minecraft:soul_lantern
fill 7 172 228 7 177 228 minecraft:soul_lantern
fill 11 172 270 11 177 270 minecraft:soul_lantern
fill 15 172 228 15 177 228 minecraft:soul_lantern
fill 19 172 270 19 177 270 minecraft:soul_lantern
fill 23 172 228 23 177 228 minecraft:soul_lantern
fill 27 172 270 27 177 270 minecraft:soul_lantern
fill 31 172 228 31 177 228 minecraft:soul_lantern
fill 35 172 270 35 177 270 minecraft:soul_lantern
fill 39 172 228 39 177 228 minecraft:soul_lantern
fill 42 172 233 42 177 233 minecraft:soul_lantern
fill 42 172 241 42 177 241 minecraft:soul_lantern
fill 42 172 249 42 177 249 minecraft:soul_lantern
fill 42 172 257 42 177 257 minecraft:soul_lantern
fill 42 172 265 42 177 265 minecraft:soul_lantern
fill 29 173 264 29 177 264 minecraft:chiseled_deepslate
setblock 3 176 231 minecraft:light[level=13]
setblock 3 176 239 minecraft:light[level=13]
setblock 3 176 247 minecraft:light[level=13]
setblock 3 176 255 minecraft:light[level=13]
setblock 3 176 263 minecraft:light[level=13]
setblock 11 176 231 minecraft:light[level=13]
setblock 11 176 239 minecraft:light[level=13]
setblock 11 176 247 minecraft:light[level=13]
setblock 11 176 255 minecraft:light[level=13]
setblock 11 176 263 minecraft:light[level=13]
setblock 19 176 231 minecraft:light[level=13]
setblock 19 176 239 minecraft:light[level=13]
setblock 19 176 247 minecraft:light[level=13]
setblock 19 176 255 minecraft:light[level=13]
setblock 19 176 263 minecraft:light[level=13]
setblock 27 176 231 minecraft:light[level=13]
setblock 27 176 239 minecraft:light[level=13]
setblock 27 176 247 minecraft:light[level=13]
setblock 27 176 255 minecraft:light[level=13]
setblock 27 176 263 minecraft:light[level=13]
setblock 35 176 231 minecraft:light[level=13]
setblock 35 176 239 minecraft:light[level=13]
setblock 35 176 247 minecraft:light[level=13]
setblock 35 176 255 minecraft:light[level=13]
setblock 35 176 263 minecraft:light[level=13]
fill 0 178 233 0 185 233 minecraft:polished_deepslate
fill 0 178 241 0 185 241 minecraft:polished_deepslate
fill 0 178 249 0 185 249 minecraft:polished_deepslate
fill 0 178 257 0 185 257 minecraft:polished_deepslate
fill 0 178 265 0 185 265 minecraft:polished_deepslate
fill 3 178 270 3 185 270 minecraft:polished_deepslate
fill 7 178 228 7 185 228 minecraft:polished_deepslate
fill 11 178 270 11 185 270 minecraft:polished_deepslate
fill 15 178 228 15 185 228 minecraft:polished_deepslate
fill 19 178 270 19 185 270 minecraft:polished_deepslate
fill 23 178 228 23 185 228 minecraft:polished_deepslate
fill 27 178 270 27 185 270 minecraft:polished_deepslate
setblock 29 178 264 minecraft:soul_lantern
fill 31 178 228 31 185 228 minecraft:polished_deepslate
fill 35 178 270 35 185 270 minecraft:polished_deepslate
fill 39 178 228 39 185 228 minecraft:polished_deepslate
fill 42 178 233 42 185 233 minecraft:polished_deepslate
fill 42 178 241 42 185 241 minecraft:polished_deepslate
fill 42 178 249 42 185 249 minecraft:polished_deepslate
fill 42 178 257 42 185 257 minecraft:polished_deepslate
fill 42 178 265 42 185 265 minecraft:polished_deepslate
fill 1 182 229 1 183 234 minecraft:chiseled_deepslate
fill 1 182 237 2 182 242 minecraft:chiseled_deepslate
fill 1 182 245 2 182 250 minecraft:chiseled_deepslate
fill 1 182 253 2 182 258 minecraft:chiseled_deepslate
fill 1 182 261 2 182 266 minecraft:chiseled_deepslate
fill 1 182 269 6 183 269 minecraft:chiseled_deepslate
fill 2 182 230 2 182 236 minecraft:chiseled_deepslate
fill 2 182 243 2 182 244 minecraft:chiseled_deepslate
fill 2 182 251 2 182 252 minecraft:chiseled_deepslate
fill 2 182 259 2 182 260 minecraft:chiseled_deepslate
fill 2 182 267 2 182 268 minecraft:chiseled_deepslate
fill 3 182 230 40 182 230 minecraft:chiseled_deepslate
fill 3 182 268 41 182 268 minecraft:chiseled_deepslate
fill 4 182 229 9 183 229 minecraft:chiseled_deepslate
fill 9 182 269 14 183 269 minecraft:chiseled_deepslate
fill 12 182 229 17 183 229 minecraft:chiseled_deepslate
fill 17 182 269 22 183 269 minecraft:chiseled_deepslate
fill 20 182 229 25 183 229 minecraft:chiseled_deepslate
fill 25 182 269 30 183 269 minecraft:chiseled_deepslate
fill 28 182 229 33 183 229 minecraft:chiseled_deepslate
fill 33 182 269 38 183 269 minecraft:chiseled_deepslate
fill 36 182 229 41 183 229 minecraft:chiseled_deepslate
fill 40 182 231 40 182 267 minecraft:chiseled_deepslate
fill 41 182 232 41 183 237 minecraft:chiseled_deepslate
fill 41 182 240 41 183 245 minecraft:chiseled_deepslate
fill 41 182 248 41 183 253 minecraft:chiseled_deepslate
fill 41 182 256 41 183 261 minecraft:chiseled_deepslate
fill 41 182 264 41 183 267 minecraft:chiseled_deepslate
fill 41 182 269 41 183 269 minecraft:chiseled_deepslate
fill 1 183 237 1 183 242 minecraft:chiseled_deepslate
fill 1 183 245 1 183 250 minecraft:chiseled_deepslate
fill 1 183 253 1 183 258 minecraft:chiseled_deepslate
fill 1 183 261 1 183 266 minecraft:chiseled_deepslate
setblock 41 183 268 minecraft:chiseled_deepslate
setblock 3 184 231 minecraft:light[level=13]
setblock 3 184 239 minecraft:light[level=13]
setblock 3 184 247 minecraft:light[level=13]
setblock 3 184 255 minecraft:light[level=13]
setblock 3 184 263 minecraft:light[level=13]
setblock 11 184 231 minecraft:light[level=13]
setblock 11 184 239 minecraft:light[level=13]
setblock 11 184 247 minecraft:light[level=13]
setblock 11 184 255 minecraft:light[level=13]
setblock 11 184 263 minecraft:light[level=13]
setblock 19 184 231 minecraft:light[level=13]
setblock 19 184 239 minecraft:light[level=13]
setblock 19 184 247 minecraft:light[level=13]
setblock 19 184 255 minecraft:light[level=13]
setblock 19 184 263 minecraft:light[level=13]
setblock 27 184 231 minecraft:light[level=13]
setblock 27 184 239 minecraft:light[level=13]
setblock 27 184 247 minecraft:light[level=13]
setblock 27 184 255 minecraft:light[level=13]
setblock 27 184 263 minecraft:light[level=13]
setblock 35 184 231 minecraft:light[level=13]
setblock 35 184 239 minecraft:light[level=13]
setblock 35 184 247 minecraft:light[level=13]
setblock 35 184 255 minecraft:light[level=13]
setblock 35 184 263 minecraft:light[level=13]
fill 0 186 233 0 191 233 minecraft:soul_lantern
fill 0 186 241 0 191 241 minecraft:soul_lantern
fill 0 186 249 0 191 249 minecraft:soul_lantern
fill 0 186 257 0 191 257 minecraft:soul_lantern
fill 0 186 265 0 191 265 minecraft:soul_lantern
fill 3 186 270 3 191 270 minecraft:soul_lantern
fill 7 186 228 7 191 228 minecraft:soul_lantern
fill 11 186 270 11 191 270 minecraft:soul_lantern
fill 15 186 228 15 191 228 minecraft:soul_lantern
fill 19 186 270 19 191 270 minecraft:soul_lantern
fill 23 186 228 23 191 228 minecraft:soul_lantern
fill 27 186 270 27 191 270 minecraft:soul_lantern
fill 31 186 228 31 191 228 minecraft:soul_lantern
fill 35 186 270 35 191 270 minecraft:soul_lantern
fill 39 186 228 39 191 228 minecraft:soul_lantern
fill 42 186 233 42 191 233 minecraft:soul_lantern
fill 42 186 241 42 191 241 minecraft:soul_lantern
fill 42 186 249 42 191 249 minecraft:soul_lantern
fill 42 186 257 42 191 257 minecraft:soul_lantern
fill 42 186 265 42 191 265 minecraft:soul_lantern
fill 0 192 233 0 199 233 minecraft:polished_deepslate
fill 0 192 241 0 199 241 minecraft:polished_deepslate
fill 0 192 249 0 199 249 minecraft:polished_deepslate
fill 0 192 257 0 199 257 minecraft:polished_deepslate
fill 0 192 265 0 199 265 minecraft:polished_deepslate
setblock 3 192 231 minecraft:light[level=13]
setblock 3 192 239 minecraft:light[level=13]
setblock 3 192 247 minecraft:light[level=13]
setblock 3 192 255 minecraft:light[level=13]
setblock 3 192 263 minecraft:light[level=13]
fill 3 192 270 3 199 270 minecraft:polished_deepslate
fill 7 192 228 7 199 228 minecraft:polished_deepslate
setblock 11 192 231 minecraft:light[level=13]
setblock 11 192 239 minecraft:light[level=13]
setblock 11 192 247 minecraft:light[level=13]
setblock 11 192 255 minecraft:light[level=13]
setblock 11 192 263 minecraft:light[level=13]
fill 11 192 270 11 199 270 minecraft:polished_deepslate
fill 15 192 228 15 199 228 minecraft:polished_deepslate
setblock 19 192 231 minecraft:light[level=13]
setblock 19 192 239 minecraft:light[level=13]
setblock 19 192 247 minecraft:light[level=13]
setblock 19 192 255 minecraft:light[level=13]
setblock 19 192 263 minecraft:light[level=13]
fill 19 192 270 19 199 270 minecraft:polished_deepslate
fill 23 192 228 23 199 228 minecraft:polished_deepslate
setblock 27 192 231 minecraft:light[level=13]
setblock 27 192 239 minecraft:light[level=13]
setblock 27 192 247 minecraft:light[level=13]
setblock 27 192 255 minecraft:light[level=13]
setblock 27 192 263 minecraft:light[level=13]
fill 27 192 270 27 199 270 minecraft:polished_deepslate
fill 31 192 228 31 199 228 minecraft:polished_deepslate
setblock 35 192 231 minecraft:light[level=13]
setblock 35 192 239 minecraft:light[level=13]
setblock 35 192 247 minecraft:light[level=13]
setblock 35 192 255 minecraft:light[level=13]
setblock 35 192 263 minecraft:light[level=13]
fill 35 192 270 35 199 270 minecraft:polished_deepslate
fill 39 192 228 39 199 228 minecraft:polished_deepslate
fill 42 192 233 42 199 233 minecraft:polished_deepslate
fill 42 192 241 42 199 241 minecraft:polished_deepslate
fill 42 192 249 42 199 249 minecraft:polished_deepslate
fill 42 192 257 42 199 257 minecraft:polished_deepslate
fill 42 192 265 42 199 265 minecraft:polished_deepslate
fill 1 196 229 1 197 234 minecraft:chiseled_deepslate
fill 1 196 237 2 196 242 minecraft:chiseled_deepslate
fill 1 196 245 2 196 250 minecraft:chiseled_deepslate
fill 1 196 253 2 196 258 minecraft:chiseled_deepslate
fill 1 196 261 2 196 266 minecraft:chiseled_deepslate
fill 1 196 269 6 197 269 minecraft:chiseled_deepslate
fill 2 196 230 2 196 236 minecraft:chiseled_deepslate
fill 2 196 243 2 196 244 minecraft:chiseled_deepslate
fill 2 196 251 2 196 252 minecraft:chiseled_deepslate
fill 2 196 259 2 196 260 minecraft:chiseled_deepslate
fill 2 196 267 2 196 268 minecraft:chiseled_deepslate
fill 3 196 230 40 196 230 minecraft:chiseled_deepslate
fill 3 196 268 41 196 268 minecraft:chiseled_deepslate
fill 4 196 229 9 197 229 minecraft:chiseled_deepslate
fill 9 196 269 14 197 269 minecraft:chiseled_deepslate
fill 12 196 229 17 197 229 minecraft:chiseled_deepslate
fill 17 196 269 22 197 269 minecraft:chiseled_deepslate
fill 20 196 229 25 197 229 minecraft:chiseled_deepslate
fill 25 196 269 30 197 269 minecraft:chiseled_deepslate
fill 28 196 229 33 197 229 minecraft:chiseled_deepslate
fill 33 196 269 38 197 269 minecraft:chiseled_deepslate
fill 36 196 229 41 197 229 minecraft:chiseled_deepslate
fill 40 196 231 40 196 267 minecraft:chiseled_deepslate
fill 41 196 232 41 197 237 minecraft:chiseled_deepslate
fill 41 196 240 41 197 245 minecraft:chiseled_deepslate
fill 41 196 248 41 197 253 minecraft:chiseled_deepslate
fill 41 196 256 41 197 261 minecraft:chiseled_deepslate
fill 41 196 264 41 197 267 minecraft:chiseled_deepslate
fill 41 196 269 41 197 269 minecraft:chiseled_deepslate
fill 1 197 237 1 197 242 minecraft:chiseled_deepslate
fill 1 197 245 1 197 250 minecraft:chiseled_deepslate
fill 1 197 253 1 197 258 minecraft:chiseled_deepslate
fill 1 197 261 1 197 266 minecraft:chiseled_deepslate
setblock 41 197 268 minecraft:chiseled_deepslate
fill 0 200 233 0 205 233 minecraft:soul_lantern
fill 0 200 241 0 205 241 minecraft:soul_lantern
fill 0 200 249 0 205 249 minecraft:soul_lantern
fill 0 200 257 0 205 257 minecraft:soul_lantern
fill 0 200 265 0 205 265 minecraft:soul_lantern
setblock 3 200 231 minecraft:light[level=13]
setblock 3 200 239 minecraft:light[level=13]
setblock 3 200 247 minecraft:light[level=13]
setblock 3 200 255 minecraft:light[level=13]
setblock 3 200 263 minecraft:light[level=13]
fill 3 200 270 3 205 270 minecraft:soul_lantern
fill 7 200 228 7 205 228 minecraft:soul_lantern
setblock 11 200 231 minecraft:light[level=13]
setblock 11 200 239 minecraft:light[level=13]
setblock 11 200 247 minecraft:light[level=13]
setblock 11 200 255 minecraft:light[level=13]
setblock 11 200 263 minecraft:light[level=13]
fill 11 200 270 11 205 270 minecraft:soul_lantern
fill 15 200 228 15 205 228 minecraft:soul_lantern
setblock 19 200 231 minecraft:light[level=13]
setblock 19 200 239 minecraft:light[level=13]
setblock 19 200 247 minecraft:light[level=13]
setblock 19 200 255 minecraft:light[level=13]
setblock 19 200 263 minecraft:light[level=13]
fill 19 200 270 19 205 270 minecraft:soul_lantern
fill 23 200 228 23 205 228 minecraft:soul_lantern
setblock 27 200 231 minecraft:light[level=13]
setblock 27 200 239 minecraft:light[level=13]
setblock 27 200 247 minecraft:light[level=13]
setblock 27 200 255 minecraft:light[level=13]
setblock 27 200 263 minecraft:light[level=13]
fill 27 200 270 27 205 270 minecraft:soul_lantern
fill 31 200 228 31 205 228 minecraft:soul_lantern
setblock 35 200 231 minecraft:light[level=13]
setblock 35 200 239 minecraft:light[level=13]
setblock 35 200 247 minecraft:light[level=13]
setblock 35 200 255 minecraft:light[level=13]
setblock 35 200 263 minecraft:light[level=13]
fill 35 200 270 35 205 270 minecraft:soul_lantern
fill 39 200 228 39 205 228 minecraft:soul_lantern
fill 42 200 233 42 205 233 minecraft:soul_lantern
fill 42 200 241 42 205 241 minecraft:soul_lantern
fill 42 200 249 42 205 249 minecraft:soul_lantern
fill 42 200 257 42 205 257 minecraft:soul_lantern
fill 42 200 265 42 205 265 minecraft:soul_lantern
fill 0 206 233 0 227 233 minecraft:polished_deepslate
fill 0 206 241 0 227 241 minecraft:polished_deepslate
fill 0 206 249 0 227 249 minecraft:polished_deepslate
fill 0 206 257 0 227 257 minecraft:polished_deepslate
fill 0 206 265 0 227 265 minecraft:polished_deepslate
fill 3 206 270 3 227 270 minecraft:polished_deepslate
fill 7 206 228 7 227 228 minecraft:polished_deepslate
fill 11 206 270 11 227 270 minecraft:polished_deepslate
fill 15 206 228 15 227 228 minecraft:polished_deepslate
fill 19 206 270 19 227 270 minecraft:polished_deepslate
fill 23 206 228 23 227 228 minecraft:polished_deepslate
fill 27 206 270 27 227 270 minecraft:polished_deepslate
fill 31 206 228 31 227 228 minecraft:polished_deepslate
fill 35 206 270 35 227 270 minecraft:polished_deepslate
fill 39 206 228 39 227 228 minecraft:polished_deepslate
fill 42 206 233 42 227 233 minecraft:polished_deepslate
fill 42 206 241 42 227 241 minecraft:polished_deepslate
fill 42 206 249 42 227 249 minecraft:polished_deepslate
fill 42 206 257 42 227 257 minecraft:polished_deepslate
fill 42 206 265 42 227 265 minecraft:polished_deepslate
setblock 3 208 231 minecraft:light[level=13]
setblock 3 208 239 minecraft:light[level=13]
setblock 3 208 247 minecraft:light[level=13]
setblock 3 208 255 minecraft:light[level=13]
setblock 3 208 263 minecraft:light[level=13]
setblock 11 208 231 minecraft:light[level=13]
setblock 11 208 239 minecraft:light[level=13]
setblock 11 208 247 minecraft:light[level=13]
setblock 11 208 255 minecraft:light[level=13]
setblock 11 208 263 minecraft:light[level=13]
setblock 19 208 231 minecraft:light[level=13]
setblock 19 208 239 minecraft:light[level=13]
setblock 19 208 247 minecraft:light[level=13]
setblock 19 208 255 minecraft:light[level=13]
setblock 19 208 263 minecraft:light[level=13]
setblock 27 208 231 minecraft:light[level=13]
setblock 27 208 239 minecraft:light[level=13]
setblock 27 208 255 minecraft:light[level=13]
setblock 27 208 263 minecraft:light[level=13]
setblock 35 208 231 minecraft:light[level=13]
setblock 35 208 239 minecraft:light[level=13]
setblock 35 208 247 minecraft:light[level=13]
setblock 35 208 255 minecraft:light[level=13]
setblock 35 208 263 minecraft:light[level=13]
fill 1 210 229 1 211 234 minecraft:chiseled_deepslate
fill 1 210 237 2 210 242 minecraft:chiseled_deepslate
fill 1 210 245 2 210 250 minecraft:chiseled_deepslate
fill 1 210 253 2 210 258 minecraft:chiseled_deepslate
fill 1 210 261 2 210 266 minecraft:chiseled_deepslate
fill 1 210 269 6 211 269 minecraft:chiseled_deepslate
fill 2 210 230 2 210 236 minecraft:chiseled_deepslate
fill 2 210 243 2 210 244 minecraft:chiseled_deepslate
fill 2 210 251 2 210 252 minecraft:chiseled_deepslate
fill 2 210 259 2 210 260 minecraft:chiseled_deepslate
fill 2 210 267 2 210 268 minecraft:chiseled_deepslate
fill 3 210 230 40 210 230 minecraft:chiseled_deepslate
fill 3 210 268 41 210 268 minecraft:chiseled_deepslate
fill 4 210 229 9 211 229 minecraft:chiseled_deepslate
fill 9 210 269 14 211 269 minecraft:chiseled_deepslate
fill 12 210 229 17 211 229 minecraft:chiseled_deepslate
fill 17 210 269 22 211 269 minecraft:chiseled_deepslate
fill 20 210 229 25 211 229 minecraft:chiseled_deepslate
fill 25 210 269 30 211 269 minecraft:chiseled_deepslate
fill 28 210 229 33 211 229 minecraft:chiseled_deepslate
fill 33 210 269 38 211 269 minecraft:chiseled_deepslate
fill 36 210 229 41 211 229 minecraft:chiseled_deepslate
fill 40 210 231 40 210 267 minecraft:chiseled_deepslate
fill 41 210 232 41 211 237 minecraft:chiseled_deepslate
fill 41 210 240 41 211 245 minecraft:chiseled_deepslate
fill 41 210 248 41 211 253 minecraft:chiseled_deepslate
fill 41 210 256 41 211 261 minecraft:chiseled_deepslate
fill 41 210 264 41 211 267 minecraft:chiseled_deepslate
fill 41 210 269 41 211 269 minecraft:chiseled_deepslate
fill 1 211 237 1 211 242 minecraft:chiseled_deepslate
fill 1 211 245 1 211 250 minecraft:chiseled_deepslate
fill 1 211 253 1 211 258 minecraft:chiseled_deepslate
fill 1 211 261 1 211 266 minecraft:chiseled_deepslate
setblock 41 211 268 minecraft:chiseled_deepslate
setblock 3 216 231 minecraft:light[level=13]
setblock 3 216 239 minecraft:light[level=13]
setblock 3 216 247 minecraft:light[level=13]
setblock 3 216 255 minecraft:light[level=13]
setblock 3 216 263 minecraft:light[level=13]
setblock 11 216 231 minecraft:light[level=13]
setblock 11 216 239 minecraft:light[level=13]
setblock 11 216 247 minecraft:light[level=13]
setblock 11 216 255 minecraft:light[level=13]
setblock 11 216 263 minecraft:light[level=13]
setblock 19 216 231 minecraft:light[level=13]
setblock 19 216 239 minecraft:light[level=13]
setblock 19 216 247 minecraft:light[level=13]
setblock 19 216 255 minecraft:light[level=13]
setblock 19 216 263 minecraft:light[level=13]
setblock 27 216 231 minecraft:light[level=13]
setblock 27 216 239 minecraft:light[level=13]
setblock 27 216 255 minecraft:light[level=13]
setblock 27 216 263 minecraft:light[level=13]
setblock 35 216 231 minecraft:light[level=13]
setblock 35 216 239 minecraft:light[level=13]
setblock 35 216 247 minecraft:light[level=13]
setblock 35 216 255 minecraft:light[level=13]
setblock 35 216 263 minecraft:light[level=13]
fill 14 218 246 15 218 246 minecraft:chiseled_deepslate
fill 15 218 241 16 218 245 minecraft:chiseled_deepslate
fill 15 218 247 16 218 251 minecraft:chiseled_deepslate
fill 16 218 240 17 218 240 minecraft:chiseled_deepslate
fill 16 218 246 23 218 246 minecraft:black_concrete
fill 16 218 252 17 218 252 minecraft:chiseled_deepslate
fill 17 218 238 18 218 239 minecraft:chiseled_deepslate
fill 17 218 241 17 219 241 minecraft:chiseled_deepslate
fill 17 218 242 24 218 245 minecraft:black_concrete
fill 17 218 247 24 218 250 minecraft:black_concrete
setblock 17 218 251 minecraft:chiseled_deepslate
fill 17 218 253 18 218 254 minecraft:chiseled_deepslate
fill 18 218 237 20 218 237 minecraft:chiseled_deepslate
fill 18 218 240 36 219 241 minecraft:black_concrete
fill 18 218 251 36 219 252 minecraft:black_concrete
fill 18 218 255 20 219 255 minecraft:chiseled_deepslate
fill 19 218 236 22 218 236 minecraft:chiseled_deepslate
fill 19 218 238 19 219 238 minecraft:chiseled_deepslate
fill 19 218 239 35 219 239 minecraft:black_concrete
fill 19 218 253 35 219 253 minecraft:black_concrete
fill 19 218 254 19 219 254 minecraft:chiseled_deepslate
fill 19 218 256 22 218 256 minecraft:chiseled_deepslate
fill 20 218 238 34 219 238 minecraft:black_concrete
fill 20 218 254 34 219 254 minecraft:black_concrete
fill 21 218 235 26 218 235 minecraft:chiseled_deepslate
fill 21 218 237 33 219 237 minecraft:black_concrete
fill 21 218 255 33 219 255 minecraft:black_concrete
fill 21 218 257 26 218 257 minecraft:chiseled_deepslate
fill 22 218 234 32 218 234 minecraft:chiseled_deepslate
fill 22 218 258 32 218 258 minecraft:chiseled_deepslate
fill 23 218 236 31 219 236 minecraft:black_concrete
fill 23 218 256 31 219 256 minecraft:black_concrete
fill 25 218 242 26 218 243 minecraft:black_concrete
fill 25 218 249 26 218 250 minecraft:black_concrete
setblock 27 218 233 minecraft:chiseled_deepslate
fill 27 218 235 27 219 235 minecraft:black_concrete
fill 27 218 242 37 218 242 minecraft:black_concrete
fill 27 218 250 37 218 250 minecraft:black_concrete
fill 27 218 257 27 219 257 minecraft:black_concrete
fill 27 218 259 27 219 259 minecraft:chiseled_deepslate
fill 28 218 235 33 218 235 minecraft:chiseled_deepslate
fill 28 218 243 37 218 243 minecraft:black_concrete
fill 28 218 249 37 218 249 minecraft:black_concrete
fill 28 218 257 33 218 257 minecraft:chiseled_deepslate
fill 30 218 244 37 218 245 minecraft:black_concrete
fill 30 218 247 37 218 248 minecraft:black_concrete
fill 31 218 246 38 218 246 minecraft:black_concrete
fill 32 218 236 35 218 236 minecraft:chiseled_deepslate
fill 32 218 256 35 218 256 minecraft:chiseled_deepslate
fill 34 218 237 36 218 237 minecraft:chiseled_deepslate
fill 34 218 255 36 219 255 minecraft:chiseled_deepslate
fill 35 218 238 37 219 238 minecraft:chiseled_deepslate
fill 35 218 254 37 219 254 minecraft:chiseled_deepslate
fill 36 218 239 37 218 239 minecraft:chiseled_deepslate
fill 36 218 253 37 219 253 minecraft:chiseled_deepslate
fill 37 218 240 38 219 241 minecraft:chiseled_deepslate
fill 37 218 251 38 218 252 minecraft:chiseled_deepslate
fill 38 218 242 39 218 245 minecraft:chiseled_deepslate
fill 38 218 247 39 218 250 minecraft:chiseled_deepslate
setblock 39 218 241 minecraft:chiseled_deepslate
fill 39 218 246 40 219 246 minecraft:chiseled_deepslate
fill 39 218 251 39 219 251 minecraft:chiseled_deepslate
fill 1 219 229 13 219 269 minecraft:polished_deepslate
fill 14 219 229 14 219 245 minecraft:polished_deepslate
setblock 14 219 246 minecraft:gold_block
fill 14 219 247 14 219 269 minecraft:polished_deepslate
fill 15 219 229 15 219 240 minecraft:polished_deepslate
setblock 15 219 241 minecraft:gold_block
fill 15 219 242 15 219 244 minecraft:chiseled_deepslate
setblock 15 219 245 minecraft:gold_block
fill 15 219 246 15 219 248 minecraft:chiseled_deepslate
setblock 15 219 249 minecraft:gold_block
fill 15 219 250 16 219 251 minecraft:chiseled_deepslate
fill 15 219 252 15 219 269 minecraft:polished_deepslate
fill 16 219 229 16 219 239 minecraft:polished_deepslate
setblock 16 219 240 minecraft:gold_block
fill 16 219 241 16 219 243 minecraft:chiseled_deepslate
setblock 16 219 244 minecraft:gold_block
setblock 16 219 245 minecraft:chiseled_deepslate
fill 16 219 246 22 219 246 minecraft:black_concrete
setblock 16 219 247 minecraft:chiseled_deepslate
setblock 16 219 248 minecraft:gold_block
setblock 16 219 249 minecraft:chiseled_deepslate
setblock 16 219 252 minecraft:gold_block
fill 16 219 253 16 219 269 minecraft:polished_deepslate
fill 17 219 229 17 219 237 minecraft:polished_deepslate
setblock 17 219 238 minecraft:chiseled_deepslate
setblock 17 219 239 minecraft:gold_block
setblock 17 219 240 minecraft:chiseled_deepslate
fill 17 219 242 22 219 245 minecraft:black_concrete
fill 17 219 247 22 219 250 minecraft:black_concrete
setblock 17 219 251 minecraft:gold_block
fill 17 219 252 17 219 254 minecraft:chiseled_deepslate
fill 17 219 255 17 219 269 minecraft:polished_deepslate
fill 18 219 229 18 219 236 minecraft:polished_deepslate
setblock 18 219 237 minecraft:chiseled_deepslate
setblock 18 219 238 minecraft:gold_block
setblock 18 219 239 minecraft:chiseled_deepslate
setblock 18 219 253 minecraft:chiseled_deepslate
setblock 18 219 254 minecraft:gold_block
fill 18 219 256 18 219 269 minecraft:polished_deepslate
fill 19 219 229 20 219 235 minecraft:polished_deepslate
setblock 19 219 236 minecraft:chiseled_deepslate
setblock 19 219 237 minecraft:gold_block
setblock 19 219 256 minecraft:chiseled_deepslate
fill 19 219 257 20 219 269 minecraft:polished_deepslate
setblock 20 219 236 minecraft:gold_block
setblock 20 219 237 minecraft:chiseled_deepslate
setblock 20 219 256 minecraft:gold_block
fill 21 219 229 21 219 234 minecraft:polished_deepslate
setblock 21 219 235 minecraft:gold_block
fill 21 219 236 22 219 236 minecraft:chiseled_deepslate
fill 21 219 256 22 219 257 minecraft:chiseled_deepslate
fill 21 219 258 21 219 269 minecraft:polished_deepslate
fill 22 219 229 26 219 233 minecraft:polished_deepslate
setblock 22 219 234 minecraft:gold_block
fill 22 219 235 24 219 235 minecraft:chiseled_deepslate
setblock 22 219 258 minecraft:gold_block
fill 22 219 259 26 219 269 minecraft:polished_deepslate
fill 23 219 234 25 219 234 minecraft:chiseled_deepslate
fill 23 219 242 23 219 244 minecraft:black_concrete
fill 23 219 245 23 219 247 minecraft:soul_lantern
fill 23 219 248 23 219 250 minecraft:black_concrete
setblock 23 219 257 minecraft:gold_block
fill 23 219 258 25 219 258 minecraft:chiseled_deepslate
fill 24 219 242 25 219 242 minecraft:black_concrete
fill 24 219 243 24 219 245 minecraft:soul_lantern
fill 24 219 247 24 219 249 minecraft:soul_lantern
fill 24 219 250 25 219 250 minecraft:black_concrete
fill 24 219 257 26 219 257 minecraft:chiseled_deepslate
setblock 25 219 235 minecraft:gold_block
fill 25 219 243 26 219 243 minecraft:soul_lantern
fill 25 219 249 26 219 249 minecraft:soul_lantern
setblock 26 219 234 minecraft:gold_block
setblock 26 219 235 minecraft:chiseled_deepslate
fill 26 219 242 28 219 242 minecraft:soul_lantern
fill 26 219 250 28 219 250 minecraft:soul_lantern
setblock 26 219 258 minecraft:gold_block
fill 27 219 229 41 219 232 minecraft:polished_deepslate
setblock 27 219 233 minecraft:gold_block
fill 27 219 234 29 219 234 minecraft:chiseled_deepslate
fill 27 219 258 29 219 258 minecraft:chiseled_deepslate
fill 27 219 260 41 219 269 minecraft:polished_deepslate
fill 28 219 233 41 219 233 minecraft:polished_deepslate
setblock 28 219 235 minecraft:chiseled_deepslate
fill 28 219 243 30 219 243 minecraft:soul_lantern
fill 28 219 249 30 219 249 minecraft:soul_lantern
fill 28 219 257 30 219 257 minecraft:chiseled_deepslate
fill 28 219 259 41 219 259 minecraft:polished_deepslate
setblock 29 219 235 minecraft:gold_block
fill 29 219 242 37 219 242 minecraft:black_concrete
fill 29 219 250 37 219 250 minecraft:black_concrete
setblock 30 219 234 minecraft:gold_block
fill 30 219 235 32 219 235 minecraft:chiseled_deepslate
fill 30 219 244 30 219 245 minecraft:soul_lantern
fill 30 219 247 30 219 248 minecraft:soul_lantern
setblock 30 219 258 minecraft:gold_block
fill 31 219 234 32 219 234 minecraft:chiseled_deepslate
fill 31 219 243 37 219 244 minecraft:black_concrete
fill 31 219 245 31 219 247 minecraft:soul_lantern
fill 31 219 248 37 219 249 minecraft:black_concrete
setblock 31 219 257 minecraft:gold_block
fill 31 219 258 32 219 258 minecraft:chiseled_deepslate
setblock 32 219 236 minecraft:gold_block
fill 32 219 245 37 219 247 minecraft:black_concrete
setblock 32 219 256 minecraft:gold_block
fill 32 219 257 33 219 257 minecraft:chiseled_deepslate
fill 33 219 234 41 219 234 minecraft:polished_deepslate
setblock 33 219 235 minecraft:gold_block
fill 33 219 236 35 219 236 minecraft:chiseled_deepslate
fill 33 219 256 35 219 256 minecraft:chiseled_deepslate
fill 33 219 258 41 219 258 minecraft:polished_deepslate
fill 34 219 235 41 219 235 minecraft:polished_deepslate
setblock 34 219 237 minecraft:chiseled_deepslate
fill 34 219 257 41 219 257 minecraft:polished_deepslate
setblock 35 219 237 minecraft:gold_block
fill 36 219 236 41 219 236 minecraft:polished_deepslate
setblock 36 219 237 minecraft:chiseled_deepslate
setblock 36 219 239 minecraft:chiseled_deepslate
fill 36 219 256 41 219 256 minecraft:polished_deepslate
fill 37 219 237 41 219 237 minecraft:polished_deepslate
setblock 37 219 239 minecraft:gold_block
setblock 37 219 251 minecraft:gold_block
fill 37 219 252 38 219 252 minecraft:chiseled_deepslate
fill 37 219 255 41 219 255 minecraft:polished_deepslate
fill 38 219 238 41 219 239 minecraft:polished_deepslate
setblock 38 219 242 minecraft:gold_block
fill 38 219 243 38 219 245 minecraft:chiseled_deepslate
setblock 38 219 246 minecraft:black_concrete
fill 38 219 247 38 219 249 minecraft:chiseled_deepslate
setblock 38 219 250 minecraft:gold_block
setblock 38 219 251 minecraft:chiseled_deepslate
fill 38 219 253 41 219 254 minecraft:polished_deepslate
fill 39 219 240 41 219 240 minecraft:polished_deepslate
setblock 39 219 241 minecraft:gold_block
fill 39 219 242 39 219 244 minecraft:chiseled_deepslate
setblock 39 219 245 minecraft:gold_block
fill 39 219 247 39 219 248 minecraft:chiseled_deepslate
setblock 39 219 249 minecraft:gold_block
setblock 39 219 250 minecraft:chiseled_deepslate
fill 39 219 252 41 219 252 minecraft:polished_deepslate
fill 40 219 241 41 219 245 minecraft:polished_deepslate
fill 40 219 247 41 219 251 minecraft:polished_deepslate
setblock 41 219 246 minecraft:polished_deepslate
fill 14 220 234 16 223 234 minecraft:chiseled_deepslate
fill 14 220 258 16 223 258 minecraft:chiseled_deepslate
fill 15 220 233 15 223 233 minecraft:chiseled_deepslate
fill 15 220 235 15 223 235 minecraft:chiseled_deepslate
fill 15 220 257 15 223 257 minecraft:chiseled_deepslate
fill 15 220 259 15 223 259 minecraft:chiseled_deepslate
fill 38 220 234 40 223 234 minecraft:chiseled_deepslate
fill 38 220 258 40 223 258 minecraft:chiseled_deepslate
fill 39 220 233 39 223 233 minecraft:chiseled_deepslate
fill 39 220 235 39 223 235 minecraft:chiseled_deepslate
fill 39 220 257 39 223 257 minecraft:chiseled_deepslate
fill 39 220 259 39 223 259 minecraft:chiseled_deepslate
fill 1 223 235 1 271 236 minecraft:chiseled_deepslate
fill 1 223 243 1 271 244 minecraft:chiseled_deepslate
fill 1 223 251 1 271 252 minecraft:chiseled_deepslate
fill 1 223 259 1 271 260 minecraft:chiseled_deepslate
fill 1 223 267 1 271 268 minecraft:chiseled_deepslate
fill 2 223 229 3 271 229 minecraft:chiseled_deepslate
fill 7 223 269 8 271 269 minecraft:chiseled_deepslate
fill 10 223 229 11 271 229 minecraft:chiseled_deepslate
fill 15 223 269 16 271 269 minecraft:chiseled_deepslate
fill 18 223 229 19 271 229 minecraft:chiseled_deepslate
fill 23 223 269 24 271 269 minecraft:chiseled_deepslate
fill 26 223 229 27 271 229 minecraft:chiseled_deepslate
fill 31 223 269 32 271 269 minecraft:chiseled_deepslate
fill 34 223 229 35 271 229 minecraft:chiseled_deepslate
fill 39 223 269 40 271 269 minecraft:chiseled_deepslate
fill 41 223 230 41 271 231 minecraft:chiseled_deepslate
fill 41 223 238 41 271 239 minecraft:chiseled_deepslate
fill 41 223 246 41 271 247 minecraft:chiseled_deepslate
fill 41 223 254 41 271 255 minecraft:chiseled_deepslate
fill 41 223 262 41 271 263 minecraft:chiseled_deepslate
fill 1 224 229 1 225 234 minecraft:chiseled_deepslate
fill 1 224 237 2 224 242 minecraft:chiseled_deepslate
fill 1 224 245 2 224 250 minecraft:chiseled_deepslate
fill 1 224 253 2 224 258 minecraft:chiseled_deepslate
fill 1 224 261 2 224 266 minecraft:chiseled_deepslate
fill 1 224 269 6 225 269 minecraft:chiseled_deepslate
fill 2 224 230 2 224 236 minecraft:chiseled_deepslate
fill 2 224 243 2 224 244 minecraft:chiseled_deepslate
fill 2 224 251 2 224 252 minecraft:chiseled_deepslate
fill 2 224 259 2 224 260 minecraft:chiseled_deepslate
fill 2 224 267 2 224 268 minecraft:chiseled_deepslate
fill 3 224 230 40 224 230 minecraft:chiseled_deepslate
setblock 3 224 231 minecraft:light[level=13]
setblock 3 224 239 minecraft:light[level=13]
setblock 3 224 247 minecraft:light[level=13]
setblock 3 224 255 minecraft:light[level=13]
setblock 3 224 263 minecraft:light[level=13]
fill 3 224 268 41 224 268 minecraft:chiseled_deepslate
fill 4 224 229 9 225 229 minecraft:chiseled_deepslate
fill 9 224 269 14 225 269 minecraft:chiseled_deepslate
setblock 11 224 231 minecraft:light[level=13]
setblock 11 224 239 minecraft:light[level=13]
setblock 11 224 247 minecraft:light[level=13]
setblock 11 224 255 minecraft:light[level=13]
setblock 11 224 263 minecraft:light[level=13]
fill 12 224 229 17 225 229 minecraft:chiseled_deepslate
fill 17 224 269 22 225 269 minecraft:chiseled_deepslate
setblock 19 224 231 minecraft:light[level=13]
setblock 19 224 239 minecraft:light[level=13]
setblock 19 224 247 minecraft:light[level=13]
setblock 19 224 255 minecraft:light[level=13]
setblock 19 224 263 minecraft:light[level=13]
fill 20 224 229 25 225 229 minecraft:chiseled_deepslate
fill 25 224 269 30 225 269 minecraft:chiseled_deepslate
setblock 27 224 231 minecraft:light[level=13]
setblock 27 224 239 minecraft:light[level=13]
setblock 27 224 247 minecraft:light[level=13]
setblock 27 224 255 minecraft:light[level=13]
setblock 27 224 263 minecraft:light[level=13]
fill 28 224 229 33 225 229 minecraft:chiseled_deepslate
fill 33 224 269 38 225 269 minecraft:chiseled_deepslate
setblock 35 224 231 minecraft:light[level=13]
setblock 35 224 239 minecraft:light[level=13]
setblock 35 224 247 minecraft:light[level=13]
setblock 35 224 255 minecraft:light[level=13]
setblock 35 224 263 minecraft:light[level=13]
fill 36 224 229 41 225 229 minecraft:chiseled_deepslate
fill 40 224 231 40 224 267 minecraft:chiseled_deepslate
fill 41 224 232 41 225 237 minecraft:chiseled_deepslate
fill 41 224 240 41 225 245 minecraft:chiseled_deepslate
fill 41 224 248 41 225 253 minecraft:chiseled_deepslate
fill 41 224 256 41 225 261 minecraft:chiseled_deepslate
fill 41 224 264 41 225 267 minecraft:chiseled_deepslate
fill 41 224 269 41 225 269 minecraft:chiseled_deepslate
fill 1 225 237 1 225 242 minecraft:chiseled_deepslate
fill 1 225 245 1 225 250 minecraft:chiseled_deepslate
fill 1 225 253 1 225 258 minecraft:chiseled_deepslate
fill 1 225 261 1 225 266 minecraft:chiseled_deepslate
setblock 41 225 268 minecraft:chiseled_deepslate
fill 0 228 233 0 233 233 minecraft:soul_lantern
fill 0 228 241 0 233 241 minecraft:soul_lantern
fill 0 228 249 0 233 249 minecraft:soul_lantern
fill 0 228 257 0 233 257 minecraft:soul_lantern
fill 0 228 265 0 233 265 minecraft:soul_lantern
fill 3 228 270 3 233 270 minecraft:soul_lantern
fill 7 228 228 7 233 228 minecraft:soul_lantern
fill 11 228 270 11 233 270 minecraft:soul_lantern
fill 15 228 228 15 233 228 minecraft:soul_lantern
fill 19 228 270 19 233 270 minecraft:soul_lantern
fill 23 228 228 23 233 228 minecraft:soul_lantern
fill 27 228 270 27 233 270 minecraft:soul_lantern
fill 31 228 228 31 233 228 minecraft:soul_lantern
fill 35 228 270 35 233 270 minecraft:soul_lantern
fill 39 228 228 39 233 228 minecraft:soul_lantern
fill 42 228 233 42 233 233 minecraft:soul_lantern
fill 42 228 241 42 233 241 minecraft:soul_lantern
fill 42 228 249 42 233 249 minecraft:soul_lantern
fill 42 228 257 42 233 257 minecraft:soul_lantern
fill 42 228 265 42 233 265 minecraft:soul_lantern
setblock 3 232 231 minecraft:light[level=13]
setblock 3 232 239 minecraft:light[level=13]
setblock 3 232 247 minecraft:light[level=13]
setblock 3 232 255 minecraft:light[level=13]
setblock 3 232 263 minecraft:light[level=13]
setblock 11 232 231 minecraft:light[level=13]
setblock 11 232 239 minecraft:light[level=13]
setblock 11 232 247 minecraft:light[level=13]
setblock 11 232 255 minecraft:light[level=13]
setblock 11 232 263 minecraft:light[level=13]
setblock 19 232 231 minecraft:light[level=13]
setblock 19 232 239 minecraft:light[level=13]
setblock 19 232 247 minecraft:light[level=13]
setblock 19 232 255 minecraft:light[level=13]
setblock 19 232 263 minecraft:light[level=13]
setblock 27 232 231 minecraft:light[level=13]
setblock 27 232 239 minecraft:light[level=13]
setblock 27 232 247 minecraft:light[level=13]
setblock 27 232 255 minecraft:light[level=13]
setblock 27 232 263 minecraft:light[level=13]
setblock 35 232 231 minecraft:light[level=13]
setblock 35 232 239 minecraft:light[level=13]
setblock 35 232 247 minecraft:light[level=13]
setblock 35 232 255 minecraft:light[level=13]
setblock 35 232 263 minecraft:light[level=13]
fill 0 234 233 0 241 233 minecraft:polished_deepslate
fill 0 234 241 0 241 241 minecraft:polished_deepslate
fill 0 234 249 0 241 249 minecraft:polished_deepslate
fill 0 234 257 0 241 257 minecraft:polished_deepslate
fill 0 234 265 0 241 265 minecraft:polished_deepslate
fill 3 234 270 3 241 270 minecraft:polished_deepslate
fill 7 234 228 7 241 228 minecraft:polished_deepslate
fill 11 234 270 11 241 270 minecraft:polished_deepslate
fill 15 234 228 15 241 228 minecraft:polished_deepslate
fill 19 234 270 19 241 270 minecraft:polished_deepslate
fill 23 234 228 23 241 228 minecraft:polished_deepslate
fill 27 234 270 27 241 270 minecraft:polished_deepslate
fill 31 234 228 31 241 228 minecraft:polished_deepslate
fill 35 234 270 35 241 270 minecraft:polished_deepslate
fill 39 234 228 39 241 228 minecraft:polished_deepslate
fill 42 234 233 42 241 233 minecraft:polished_deepslate
fill 42 234 241 42 241 241 minecraft:polished_deepslate
fill 42 234 249 42 241 249 minecraft:polished_deepslate
fill 42 234 257 42 241 257 minecraft:polished_deepslate
fill 42 234 265 42 241 265 minecraft:polished_deepslate
fill 1 238 229 1 239 234 minecraft:chiseled_deepslate
fill 1 238 237 2 238 242 minecraft:chiseled_deepslate
fill 1 238 245 2 238 250 minecraft:chiseled_deepslate
fill 1 238 253 2 238 258 minecraft:chiseled_deepslate
fill 1 238 261 2 238 266 minecraft:chiseled_deepslate
fill 1 238 269 6 239 269 minecraft:chiseled_deepslate
fill 2 238 230 2 238 236 minecraft:chiseled_deepslate
fill 2 238 243 2 238 244 minecraft:chiseled_deepslate
fill 2 238 251 2 238 252 minecraft:chiseled_deepslate
fill 2 238 259 2 238 260 minecraft:chiseled_deepslate
fill 2 238 267 2 238 268 minecraft:chiseled_deepslate
fill 3 238 230 40 238 230 minecraft:chiseled_deepslate
fill 3 238 268 41 238 268 minecraft:chiseled_deepslate
fill 4 238 229 9 239 229 minecraft:chiseled_deepslate
fill 9 238 269 14 239 269 minecraft:chiseled_deepslate
fill 12 238 229 17 239 229 minecraft:chiseled_deepslate
fill 17 238 269 22 239 269 minecraft:chiseled_deepslate
fill 20 238 229 25 239 229 minecraft:chiseled_deepslate
fill 25 238 269 30 239 269 minecraft:chiseled_deepslate
fill 28 238 229 33 239 229 minecraft:chiseled_deepslate
fill 33 238 269 38 239 269 minecraft:chiseled_deepslate
fill 36 238 229 41 239 229 minecraft:chiseled_deepslate
fill 40 238 231 40 238 267 minecraft:chiseled_deepslate
fill 41 238 232 41 239 237 minecraft:chiseled_deepslate
fill 41 238 240 41 239 245 minecraft:chiseled_deepslate
fill 41 238 248 41 239 253 minecraft:chiseled_deepslate
fill 41 238 256 41 239 261 minecraft:chiseled_deepslate
fill 41 238 264 41 239 267 minecraft:chiseled_deepslate
fill 41 238 269 41 239 269 minecraft:chiseled_deepslate
fill 1 239 237 1 239 242 minecraft:chiseled_deepslate
fill 1 239 245 1 239 250 minecraft:chiseled_deepslate
fill 1 239 253 1 239 258 minecraft:chiseled_deepslate
fill 1 239 261 1 239 266 minecraft:chiseled_deepslate
setblock 41 239 268 minecraft:chiseled_deepslate
setblock 3 240 231 minecraft:light[level=13]
setblock 3 240 239 minecraft:light[level=13]
setblock 3 240 247 minecraft:light[level=13]
setblock 3 240 255 minecraft:light[level=13]
setblock 3 240 263 minecraft:light[level=13]
setblock 11 240 231 minecraft:light[level=13]
setblock 11 240 239 minecraft:light[level=13]
setblock 11 240 247 minecraft:light[level=13]
setblock 11 240 255 minecraft:light[level=13]
setblock 11 240 263 minecraft:light[level=13]
setblock 19 240 231 minecraft:light[level=13]
setblock 19 240 239 minecraft:light[level=13]
setblock 19 240 247 minecraft:light[level=13]
setblock 19 240 255 minecraft:light[level=13]
setblock 19 240 263 minecraft:light[level=13]
setblock 27 240 231 minecraft:light[level=13]
setblock 27 240 239 minecraft:light[level=13]
setblock 27 240 247 minecraft:light[level=13]
setblock 27 240 255 minecraft:light[level=13]
setblock 27 240 263 minecraft:light[level=13]
setblock 35 240 231 minecraft:light[level=13]
setblock 35 240 239 minecraft:light[level=13]
setblock 35 240 247 minecraft:light[level=13]
setblock 35 240 255 minecraft:light[level=13]
setblock 35 240 263 minecraft:light[level=13]
fill 0 242 233 0 247 233 minecraft:soul_lantern
fill 0 242 241 0 247 241 minecraft:soul_lantern
fill 0 242 249 0 247 249 minecraft:soul_lantern
fill 0 242 257 0 247 257 minecraft:soul_lantern
fill 0 242 265 0 247 265 minecraft:soul_lantern
fill 3 242 270 3 247 270 minecraft:soul_lantern
fill 7 242 228 7 247 228 minecraft:soul_lantern
fill 11 242 270 11 247 270 minecraft:soul_lantern
fill 15 242 228 15 247 228 minecraft:soul_lantern
fill 19 242 270 19 247 270 minecraft:soul_lantern
fill 23 242 228 23 247 228 minecraft:soul_lantern
fill 27 242 270 27 247 270 minecraft:soul_lantern
fill 31 242 228 31 247 228 minecraft:soul_lantern
fill 35 242 270 35 247 270 minecraft:soul_lantern
fill 39 242 228 39 247 228 minecraft:soul_lantern
fill 42 242 233 42 247 233 minecraft:soul_lantern
fill 42 242 241 42 247 241 minecraft:soul_lantern
fill 42 242 249 42 247 249 minecraft:soul_lantern
fill 42 242 257 42 247 257 minecraft:soul_lantern
fill 42 242 265 42 247 265 minecraft:soul_lantern
fill 0 248 233 0 255 233 minecraft:polished_deepslate
fill 0 248 241 0 255 241 minecraft:polished_deepslate
fill 0 248 249 0 255 249 minecraft:polished_deepslate
fill 0 248 257 0 255 257 minecraft:polished_deepslate
fill 0 248 265 0 255 265 minecraft:polished_deepslate
setblock 3 248 231 minecraft:light[level=13]
setblock 3 248 239 minecraft:light[level=13]
setblock 3 248 247 minecraft:light[level=13]
setblock 3 248 255 minecraft:light[level=13]
setblock 3 248 263 minecraft:light[level=13]
fill 3 248 270 3 255 270 minecraft:polished_deepslate
fill 7 248 228 7 255 228 minecraft:polished_deepslate
setblock 11 248 231 minecraft:light[level=13]
setblock 11 248 239 minecraft:light[level=13]
setblock 11 248 247 minecraft:light[level=13]
setblock 11 248 255 minecraft:light[level=13]
setblock 11 248 263 minecraft:light[level=13]
fill 11 248 270 11 255 270 minecraft:polished_deepslate
fill 15 248 228 15 255 228 minecraft:polished_deepslate
fill 16 248 230 16 251 230 minecraft:gold_block
setblock 19 248 231 minecraft:light[level=13]
setblock 19 248 239 minecraft:light[level=13]
setblock 19 248 247 minecraft:light[level=13]
setblock 19 248 255 minecraft:light[level=13]
setblock 19 248 263 minecraft:light[level=13]
fill 19 248 270 19 255 270 minecraft:polished_deepslate
fill 23 248 228 23 255 228 minecraft:polished_deepslate
setblock 27 248 231 minecraft:light[level=13]
setblock 27 248 239 minecraft:light[level=13]
setblock 27 248 247 minecraft:light[level=13]
setblock 27 248 255 minecraft:light[level=13]
setblock 27 248 263 minecraft:light[level=13]
fill 27 248 270 27 255 270 minecraft:polished_deepslate
fill 31 248 228 31 255 228 minecraft:polished_deepslate
setblock 35 248 231 minecraft:light[level=13]
setblock 35 248 239 minecraft:light[level=13]
setblock 35 248 247 minecraft:light[level=13]
setblock 35 248 255 minecraft:light[level=13]
setblock 35 248 263 minecraft:light[level=13]
fill 35 248 270 35 255 270 minecraft:polished_deepslate
fill 39 248 228 39 255 228 minecraft:polished_deepslate
fill 42 248 233 42 255 233 minecraft:polished_deepslate
fill 42 248 241 42 255 241 minecraft:polished_deepslate
fill 42 248 249 42 255 249 minecraft:polished_deepslate
fill 42 248 257 42 255 257 minecraft:polished_deepslate
fill 42 248 265 42 255 265 minecraft:polished_deepslate
fill 14 249 230 15 251 230 minecraft:gold_block
fill 17 249 230 18 251 230 minecraft:gold_block
fill 1 252 229 1 253 234 minecraft:chiseled_deepslate
fill 1 252 237 2 252 242 minecraft:chiseled_deepslate
fill 1 252 245 2 252 250 minecraft:chiseled_deepslate
fill 1 252 253 2 252 258 minecraft:chiseled_deepslate
fill 1 252 261 2 252 266 minecraft:chiseled_deepslate
fill 1 252 269 6 253 269 minecraft:chiseled_deepslate
fill 2 252 230 2 252 236 minecraft:chiseled_deepslate
fill 2 252 243 2 252 244 minecraft:chiseled_deepslate
fill 2 252 251 2 252 252 minecraft:chiseled_deepslate
fill 2 252 259 2 252 260 minecraft:chiseled_deepslate
fill 2 252 267 2 252 268 minecraft:chiseled_deepslate
fill 3 252 230 40 252 230 minecraft:chiseled_deepslate
fill 3 252 268 41 252 268 minecraft:chiseled_deepslate
fill 4 252 229 9 253 229 minecraft:chiseled_deepslate
fill 9 252 269 14 253 269 minecraft:chiseled_deepslate
fill 12 252 229 17 253 229 minecraft:chiseled_deepslate
fill 17 252 269 22 253 269 minecraft:chiseled_deepslate
fill 20 252 229 25 253 229 minecraft:chiseled_deepslate
fill 25 252 269 30 253 269 minecraft:chiseled_deepslate
fill 28 252 229 33 253 229 minecraft:chiseled_deepslate
fill 33 252 269 38 253 269 minecraft:chiseled_deepslate
fill 36 252 229 41 253 229 minecraft:chiseled_deepslate
fill 40 252 231 40 252 267 minecraft:chiseled_deepslate
fill 41 252 232 41 253 237 minecraft:chiseled_deepslate
fill 41 252 240 41 253 245 minecraft:chiseled_deepslate
fill 41 252 248 41 253 253 minecraft:chiseled_deepslate
fill 41 252 256 41 253 261 minecraft:chiseled_deepslate
fill 41 252 264 41 253 267 minecraft:chiseled_deepslate
fill 41 252 269 41 253 269 minecraft:chiseled_deepslate
fill 1 253 237 1 253 242 minecraft:chiseled_deepslate
fill 1 253 245 1 253 250 minecraft:chiseled_deepslate
fill 1 253 253 1 253 258 minecraft:chiseled_deepslate
fill 1 253 261 1 253 266 minecraft:chiseled_deepslate
fill 14 253 230 18 263 230 minecraft:gold_block
setblock 41 253 268 minecraft:chiseled_deepslate
fill 0 256 233 0 261 233 minecraft:soul_lantern
fill 0 256 241 0 261 241 minecraft:soul_lantern
fill 0 256 249 0 261 249 minecraft:soul_lantern
fill 0 256 257 0 261 257 minecraft:soul_lantern
fill 0 256 265 0 261 265 minecraft:soul_lantern
setblock 3 256 231 minecraft:light[level=13]
setblock 3 256 239 minecraft:light[level=13]
setblock 3 256 247 minecraft:light[level=13]
setblock 3 256 255 minecraft:light[level=13]
setblock 3 256 263 minecraft:light[level=13]
fill 3 256 270 3 261 270 minecraft:soul_lantern
fill 7 256 228 7 261 228 minecraft:soul_lantern
setblock 11 256 231 minecraft:light[level=13]
setblock 11 256 239 minecraft:light[level=13]
setblock 11 256 247 minecraft:light[level=13]
setblock 11 256 255 minecraft:light[level=13]
setblock 11 256 263 minecraft:light[level=13]
fill 11 256 270 11 261 270 minecraft:soul_lantern
fill 15 256 228 15 261 228 minecraft:soul_lantern
setblock 19 256 231 minecraft:light[level=13]
setblock 19 256 239 minecraft:light[level=13]
setblock 19 256 247 minecraft:light[level=13]
setblock 19 256 255 minecraft:light[level=13]
setblock 19 256 263 minecraft:light[level=13]
fill 19 256 270 19 261 270 minecraft:soul_lantern
fill 23 256 228 23 261 228 minecraft:soul_lantern
setblock 27 256 231 minecraft:light[level=13]
setblock 27 256 239 minecraft:light[level=13]
setblock 27 256 247 minecraft:light[level=13]
setblock 27 256 255 minecraft:light[level=13]
setblock 27 256 263 minecraft:light[level=13]
fill 27 256 270 27 261 270 minecraft:soul_lantern
fill 31 256 228 31 261 228 minecraft:soul_lantern
setblock 35 256 231 minecraft:light[level=13]
setblock 35 256 239 minecraft:light[level=13]
setblock 35 256 247 minecraft:light[level=13]
setblock 35 256 255 minecraft:light[level=13]
setblock 35 256 263 minecraft:light[level=13]
fill 35 256 270 35 261 270 minecraft:soul_lantern
fill 39 256 228 39 261 228 minecraft:soul_lantern
fill 42 256 233 42 261 233 minecraft:soul_lantern
fill 42 256 241 42 261 241 minecraft:soul_lantern
fill 42 256 249 42 261 249 minecraft:soul_lantern
fill 42 256 257 42 261 257 minecraft:soul_lantern
fill 42 256 265 42 261 265 minecraft:soul_lantern
fill 0 262 233 0 269 233 minecraft:polished_deepslate
fill 0 262 241 0 269 241 minecraft:polished_deepslate
fill 0 262 249 0 269 249 minecraft:polished_deepslate
fill 0 262 257 0 269 257 minecraft:polished_deepslate
fill 0 262 265 0 269 265 minecraft:polished_deepslate
fill 3 262 270 3 269 270 minecraft:polished_deepslate
fill 7 262 228 7 269 228 minecraft:polished_deepslate
fill 11 262 270 11 269 270 minecraft:polished_deepslate
fill 13 262 230 13 263 230 minecraft:gold_block
fill 15 262 228 15 269 228 minecraft:polished_deepslate
fill 19 262 230 19 263 230 minecraft:gold_block
fill 19 262 270 19 269 270 minecraft:polished_deepslate
fill 23 262 228 23 269 228 minecraft:polished_deepslate
fill 27 262 270 27 269 270 minecraft:polished_deepslate
fill 31 262 228 31 269 228 minecraft:polished_deepslate
fill 35 262 270 35 269 270 minecraft:polished_deepslate
fill 39 262 228 39 269 228 minecraft:polished_deepslate
fill 42 262 233 42 269 233 minecraft:polished_deepslate
fill 42 262 241 42 269 241 minecraft:polished_deepslate
fill 42 262 249 42 269 249 minecraft:polished_deepslate
fill 42 262 257 42 269 257 minecraft:polished_deepslate
fill 42 262 265 42 269 265 minecraft:polished_deepslate
setblock 3 264 231 minecraft:light[level=13]
setblock 3 264 239 minecraft:light[level=13]
setblock 3 264 247 minecraft:light[level=13]
setblock 3 264 255 minecraft:light[level=13]
setblock 3 264 263 minecraft:light[level=13]
setblock 11 264 231 minecraft:light[level=13]
setblock 11 264 239 minecraft:light[level=13]
setblock 11 264 247 minecraft:light[level=13]
setblock 11 264 255 minecraft:light[level=13]
setblock 11 264 263 minecraft:light[level=13]
setblock 19 264 231 minecraft:light[level=13]
setblock 19 264 239 minecraft:light[level=13]
setblock 19 264 247 minecraft:light[level=13]
setblock 19 264 255 minecraft:light[level=13]
setblock 19 264 263 minecraft:light[level=13]
setblock 27 264 231 minecraft:light[level=13]
setblock 27 264 239 minecraft:light[level=13]
setblock 27 264 247 minecraft:light[level=13]
setblock 27 264 255 minecraft:light[level=13]
setblock 27 264 263 minecraft:light[level=13]
setblock 35 264 231 minecraft:light[level=13]
setblock 35 264 239 minecraft:light[level=13]
setblock 35 264 247 minecraft:light[level=13]
setblock 35 264 255 minecraft:light[level=13]
setblock 35 264 263 minecraft:light[level=13]
fill 1 266 229 1 267 234 minecraft:chiseled_deepslate
fill 1 266 237 2 266 242 minecraft:chiseled_deepslate
fill 1 266 245 2 266 250 minecraft:chiseled_deepslate
fill 1 266 253 2 266 258 minecraft:chiseled_deepslate
fill 1 266 261 2 266 266 minecraft:chiseled_deepslate
fill 1 266 269 6 267 269 minecraft:chiseled_deepslate
fill 2 266 230 2 266 236 minecraft:chiseled_deepslate
fill 2 266 243 2 266 244 minecraft:chiseled_deepslate
fill 2 266 251 2 266 252 minecraft:chiseled_deepslate
fill 2 266 259 2 266 260 minecraft:chiseled_deepslate
fill 2 266 267 2 266 268 minecraft:chiseled_deepslate
fill 3 266 230 40 266 230 minecraft:chiseled_deepslate
fill 3 266 268 41 266 268 minecraft:chiseled_deepslate
fill 4 266 229 9 267 229 minecraft:chiseled_deepslate
fill 9 266 269 14 267 269 minecraft:chiseled_deepslate
fill 12 266 229 17 267 229 minecraft:chiseled_deepslate
fill 17 266 269 22 267 269 minecraft:chiseled_deepslate
fill 20 266 229 25 267 229 minecraft:chiseled_deepslate
fill 25 266 269 30 267 269 minecraft:chiseled_deepslate
fill 28 266 229 33 267 229 minecraft:chiseled_deepslate
fill 33 266 269 38 267 269 minecraft:chiseled_deepslate
fill 36 266 229 41 267 229 minecraft:chiseled_deepslate
fill 40 266 231 40 266 267 minecraft:chiseled_deepslate
fill 41 266 232 41 267 237 minecraft:chiseled_deepslate
fill 41 266 240 41 267 245 minecraft:chiseled_deepslate
fill 41 266 248 41 267 253 minecraft:chiseled_deepslate
fill 41 266 256 41 267 261 minecraft:chiseled_deepslate
fill 41 266 264 41 267 267 minecraft:chiseled_deepslate
fill 41 266 269 41 267 269 minecraft:chiseled_deepslate
fill 1 267 237 1 267 242 minecraft:chiseled_deepslate
fill 1 267 245 1 267 250 minecraft:chiseled_deepslate
fill 1 267 253 1 267 258 minecraft:chiseled_deepslate
fill 1 267 261 1 267 266 minecraft:chiseled_deepslate
setblock 41 267 268 minecraft:chiseled_deepslate
fill 0 270 233 0 271 233 minecraft:soul_lantern
fill 0 270 241 0 271 241 minecraft:soul_lantern
fill 0 270 249 0 271 249 minecraft:soul_lantern
fill 0 270 257 0 271 257 minecraft:soul_lantern
fill 0 270 265 0 271 265 minecraft:soul_lantern
fill 3 270 270 3 271 270 minecraft:soul_lantern
fill 7 270 228 7 271 228 minecraft:soul_lantern
fill 11 270 270 11 271 270 minecraft:soul_lantern
fill 15 270 228 15 271 228 minecraft:soul_lantern
fill 19 270 270 19 271 270 minecraft:soul_lantern
fill 23 270 228 23 271 228 minecraft:soul_lantern
fill 27 270 270 27 271 270 minecraft:soul_lantern
fill 31 270 228 31 271 228 minecraft:soul_lantern
fill 35 270 270 35 271 270 minecraft:soul_lantern
fill 39 270 228 39 271 228 minecraft:soul_lantern
fill 42 270 233 42 271 233 minecraft:soul_lantern
fill 42 270 241 42 271 241 minecraft:soul_lantern
fill 42 270 249 42 271 249 minecraft:soul_lantern
fill 42 270 257 42 271 257 minecraft:soul_lantern
fill 42 270 265 42 271 265 minecraft:soul_lantern
fill 0 272 233 0 283 233 minecraft:polished_deepslate
fill 0 272 241 0 283 241 minecraft:polished_deepslate
fill 0 272 249 0 283 249 minecraft:polished_deepslate
fill 0 272 257 0 283 257 minecraft:polished_deepslate
fill 0 272 265 0 283 265 minecraft:polished_deepslate
setblock 3 272 231 minecraft:light[level=13]
setblock 3 272 239 minecraft:light[level=13]
setblock 3 272 247 minecraft:light[level=13]
setblock 3 272 255 minecraft:light[level=13]
setblock 3 272 263 minecraft:light[level=13]
fill 3 272 270 3 283 270 minecraft:polished_deepslate
fill 7 272 228 7 283 228 minecraft:polished_deepslate
setblock 11 272 231 minecraft:light[level=13]
setblock 11 272 239 minecraft:light[level=13]
setblock 11 272 247 minecraft:light[level=13]
setblock 11 272 255 minecraft:light[level=13]
setblock 11 272 263 minecraft:light[level=13]
fill 11 272 270 11 283 270 minecraft:polished_deepslate
fill 15 272 228 15 283 228 minecraft:polished_deepslate
setblock 19 272 231 minecraft:light[level=13]
setblock 19 272 239 minecraft:light[level=13]
setblock 19 272 247 minecraft:light[level=13]
setblock 19 272 255 minecraft:light[level=13]
setblock 19 272 263 minecraft:light[level=13]
fill 19 272 270 19 283 270 minecraft:polished_deepslate
fill 23 272 228 23 283 228 minecraft:polished_deepslate
setblock 27 272 231 minecraft:light[level=13]
setblock 27 272 239 minecraft:light[level=13]
setblock 27 272 247 minecraft:light[level=13]
setblock 27 272 255 minecraft:light[level=13]
setblock 27 272 263 minecraft:light[level=13]
fill 27 272 270 27 283 270 minecraft:polished_deepslate
fill 31 272 228 31 283 228 minecraft:polished_deepslate
setblock 35 272 231 minecraft:light[level=13]
setblock 35 272 239 minecraft:light[level=13]
setblock 35 272 247 minecraft:light[level=13]
setblock 35 272 255 minecraft:light[level=13]
setblock 35 272 263 minecraft:light[level=13]
fill 35 272 270 35 283 270 minecraft:polished_deepslate
fill 39 272 228 39 283 228 minecraft:polished_deepslate
fill 42 272 233 42 283 233 minecraft:polished_deepslate
fill 42 272 241 42 283 241 minecraft:polished_deepslate
fill 42 272 249 42 283 249 minecraft:polished_deepslate
fill 42 272 257 42 283 257 minecraft:polished_deepslate
fill 42 272 265 42 283 265 minecraft:polished_deepslate
fill 11 277 249 19 278 249 minecraft:deepslate_tiles
fill 12 277 245 20 278 248 minecraft:deepslate_tiles
fill 12 277 250 20 278 253 minecraft:deepslate_tiles
fill 13 277 243 33 278 244 minecraft:deepslate_tiles
fill 13 277 254 33 278 255 minecraft:deepslate_tiles
fill 14 277 242 32 278 242 minecraft:deepslate_tiles
fill 14 277 256 32 278 256 minecraft:deepslate_tiles
fill 15 277 241 31 278 241 minecraft:deepslate_tiles
fill 15 277 257 31 278 257 minecraft:deepslate_tiles
fill 16 277 240 30 278 240 minecraft:deepslate_tiles
fill 16 277 258 30 278 258 minecraft:deepslate_tiles
fill 17 277 239 29 278 239 minecraft:deepslate_tiles
fill 17 277 259 29 278 259 minecraft:deepslate_tiles
fill 19 277 238 27 278 238 minecraft:deepslate_tiles
fill 19 277 260 27 278 260 minecraft:deepslate_tiles
fill 21 277 245 22 278 246 minecraft:deepslate_tiles
fill 21 277 252 22 278 253 minecraft:deepslate_tiles
fill 23 277 237 23 278 237 minecraft:deepslate_tiles
fill 23 277 245 34 278 245 minecraft:deepslate_tiles
fill 23 277 253 34 278 253 minecraft:deepslate_tiles
fill 23 277 261 23 278 261 minecraft:deepslate_tiles
fill 24 277 246 34 278 246 minecraft:deepslate_tiles
fill 24 277 252 34 278 252 minecraft:deepslate_tiles
fill 26 277 247 34 278 248 minecraft:deepslate_tiles
fill 26 277 250 34 278 251 minecraft:deepslate_tiles
fill 27 277 249 35 278 249 minecraft:deepslate_tiles
fill 1 279 229 10 279 269 minecraft:cobbled_deepslate
fill 11 279 229 11 279 248 minecraft:cobbled_deepslate
fill 11 279 249 13 279 249 minecraft:polished_deepslate
fill 11 279 250 11 279 269 minecraft:cobbled_deepslate
fill 12 279 229 12 279 244 minecraft:cobbled_deepslate
fill 12 279 245 13 279 248 minecraft:polished_deepslate
fill 12 279 250 13 279 253 minecraft:polished_deepslate
fill 12 279 254 12 279 269 minecraft:cobbled_deepslate
fill 13 279 229 13 279 242 minecraft:cobbled_deepslate
fill 13 279 243 14 279 244 minecraft:gold_block
fill 13 279 254 14 279 255 minecraft:gold_block
fill 13 279 256 13 279 269 minecraft:cobbled_deepslate
fill 14 279 229 14 279 241 minecraft:cobbled_deepslate
fill 14 279 242 16 279 242 minecraft:polished_deepslate
setblock 14 279 245 minecraft:polished_deepslate
fill 14 279 246 14 279 252 minecraft:gold_block
setblock 14 279 253 minecraft:polished_deepslate
fill 14 279 256 16 279 256 minecraft:polished_deepslate
fill 14 279 257 14 279 269 minecraft:cobbled_deepslate
fill 15 279 229 15 279 240 minecraft:cobbled_deepslate
fill 15 279 241 17 279 241 minecraft:polished_deepslate
setblock 15 279 243 minecraft:polished_deepslate
fill 15 279 244 15 279 246 minecraft:gold_block
fill 15 279 247 18 279 251 minecraft:polished_deepslate
fill 15 279 252 15 279 254 minecraft:gold_block
setblock 15 279 255 minecraft:polished_deepslate
fill 15 279 257 17 279 257 minecraft:polished_deepslate
fill 15 279 258 15 279 269 minecraft:cobbled_deepslate
fill 16 279 229 16 279 239 minecraft:cobbled_deepslate
fill 16 279 240 19 279 240 minecraft:polished_deepslate
fill 16 279 243 16 279 245 minecraft:gold_block
setblock 16 279 246 minecraft:polished_deepslate
setblock 16 279 252 minecraft:polished_deepslate
fill 16 279 253 16 279 255 minecraft:gold_block
fill 16 279 258 19 279 258 minecraft:polished_deepslate
fill 16 279 259 16 279 269 minecraft:cobbled_deepslate
fill 17 279 229 18 279 238 minecraft:cobbled_deepslate
fill 17 279 239 22 279 239 minecraft:polished_deepslate
fill 17 279 242 18 279 242 minecraft:gold_block
fill 17 279 243 22 279 244 minecraft:polished_deepslate
fill 17 279 245 17 279 246 minecraft:gold_block
fill 17 279 252 17 279 253 minecraft:gold_block
fill 17 279 254 22 279 255 minecraft:polished_deepslate
fill 17 279 256 18 279 256 minecraft:gold_block
fill 17 279 259 22 279 259 minecraft:polished_deepslate
fill 17 279 260 18 279 269 minecraft:cobbled_deepslate
fill 18 279 241 20 279 241 minecraft:gold_block
fill 18 279 245 21 279 245 minecraft:polished_deepslate
setblock 18 279 246 minecraft:gold_block
setblock 18 279 252 minecraft:gold_block
fill 18 279 253 21 279 253 minecraft:polished_deepslate
fill 18 279 257 20 279 257 minecraft:gold_block
fill 19 279 229 22 279 237 minecraft:cobbled_deepslate
fill 19 279 238 21 279 238 minecraft:polished_deepslate
fill 19 279 242 22 279 242 minecraft:polished_deepslate
setblock 19 279 246 minecraft:polished_deepslate
setblock 19 279 247 minecraft:gold_block
fill 19 279 248 19 279 250 minecraft:soul_lantern
setblock 19 279 251 minecraft:gold_block
setblock 19 279 252 minecraft:polished_deepslate
fill 19 279 256 22 279 256 minecraft:polished_deepslate
fill 19 279 260 21 279 260 minecraft:polished_deepslate
fill 19 279 261 22 279 269 minecraft:cobbled_deepslate
fill 20 279 240 26 279 240 minecraft:gold_block
fill 20 279 246 20 279 248 minecraft:soul_lantern
fill 20 279 250 20 279 252 minecraft:soul_lantern
fill 20 279 258 26 279 258 minecraft:gold_block
fill 21 279 241 22 279 241 minecraft:polished_deepslate
fill 21 279 246 22 279 246 minecraft:soul_lantern
fill 21 279 252 22 279 252 minecraft:soul_lantern
fill 21 279 257 22 279 257 minecraft:polished_deepslate
fill 22 279 238 24 279 238 minecraft:gold_block
fill 22 279 245 24 279 245 minecraft:soul_lantern
fill 22 279 253 24 279 253 minecraft:soul_lantern
fill 22 279 260 24 279 260 minecraft:gold_block
fill 23 279 229 41 279 236 minecraft:cobbled_deepslate
setblock 23 279 237 minecraft:gold_block
setblock 23 279 239 minecraft:gold_block
fill 23 279 241 23 279 244 minecraft:gold_block
fill 23 279 254 23 279 257 minecraft:gold_block
setblock 23 279 259 minecraft:gold_block
setblock 23 279 261 minecraft:gold_block
fill 23 279 262 41 279 269 minecraft:cobbled_deepslate
fill 24 279 237 41 279 237 minecraft:cobbled_deepslate
fill 24 279 239 29 279 239 minecraft:polished_deepslate
fill 24 279 241 25 279 244 minecraft:polished_deepslate
fill 24 279 246 26 279 246 minecraft:soul_lantern
fill 24 279 252 26 279 252 minecraft:soul_lantern
fill 24 279 254 25 279 257 minecraft:polished_deepslate
fill 24 279 259 29 279 259 minecraft:polished_deepslate
fill 24 279 261 41 279 261 minecraft:cobbled_deepslate
fill 25 279 238 27 279 238 minecraft:polished_deepslate
fill 25 279 245 28 279 245 minecraft:polished_deepslate
fill 25 279 253 28 279 253 minecraft:polished_deepslate
fill 25 279 260 27 279 260 minecraft:polished_deepslate
fill 26 279 241 28 279 241 minecraft:gold_block
fill 26 279 242 27 279 244 minecraft:polished_deepslate
fill 26 279 247 26 279 248 minecraft:soul_lantern
fill 26 279 250 26 279 251 minecraft:soul_lantern
fill 26 279 254 27 279 256 minecraft:polished_deepslate
fill 26 279 257 28 279 257 minecraft:gold_block
fill 27 279 240 30 279 240 minecraft:polished_deepslate
setblock 27 279 246 minecraft:polished_deepslate
setblock 27 279 247 minecraft:gold_block
fill 27 279 248 27 279 250 minecraft:soul_lantern
setblock 27 279 251 minecraft:gold_block
setblock 27 279 252 minecraft:polished_deepslate
fill 27 279 258 30 279 258 minecraft:polished_deepslate
fill 28 279 238 41 279 238 minecraft:cobbled_deepslate
fill 28 279 242 29 279 242 minecraft:gold_block
fill 28 279 243 29 279 244 minecraft:polished_deepslate
fill 28 279 246 29 279 246 minecraft:gold_block
fill 28 279 247 31 279 251 minecraft:polished_deepslate
fill 28 279 252 29 279 252 minecraft:gold_block
fill 28 279 254 29 279 255 minecraft:polished_deepslate
fill 28 279 256 29 279 256 minecraft:gold_block
fill 28 279 260 41 279 260 minecraft:cobbled_deepslate
fill 29 279 241 31 279 241 minecraft:polished_deepslate
fill 29 279 245 31 279 245 minecraft:gold_block
fill 29 279 253 31 279 253 minecraft:gold_block
fill 29 279 257 31 279 257 minecraft:polished_deepslate
fill 30 279 239 41 279 239 minecraft:cobbled_deepslate
fill 30 279 242 32 279 242 minecraft:polished_deepslate
fill 30 279 243 30 279 244 minecraft:gold_block
setblock 30 279 246 minecraft:polished_deepslate
setblock 30 279 252 minecraft:polished_deepslate
fill 30 279 254 30 279 255 minecraft:gold_block
fill 30 279 256 32 279 256 minecraft:polished_deepslate
fill 30 279 259 41 279 259 minecraft:cobbled_deepslate
fill 31 279 240 41 279 240 minecraft:cobbled_deepslate
setblock 31 279 243 minecraft:polished_deepslate
fill 31 279 244 33 279 244 minecraft:gold_block
fill 31 279 246 32 279 246 minecraft:gold_block
fill 31 279 252 32 279 252 minecraft:gold_block
fill 31 279 254 33 279 254 minecraft:gold_block
setblock 31 279 255 minecraft:polished_deepslate
fill 31 279 258 41 279 258 minecraft:cobbled_deepslate
fill 32 279 241 41 279 241 minecraft:cobbled_deepslate
fill 32 279 243 33 279 243 minecraft:gold_block
fill 32 279 245 34 279 245 minecraft:polished_deepslate
fill 32 279 247 32 279 251 minecraft:gold_block
fill 32 279 253 34 279 253 minecraft:polished_deepslate
fill 32 279 255 33 279 255 minecraft:gold_block
fill 32 279 257 41 279 257 minecraft:cobbled_deepslate
fill 33 279 242 41 279 242 minecraft:cobbled_deepslate
fill 33 279 246 34 279 252 minecraft:polished_deepslate
fill 33 279 256 41 279 256 minecraft:cobbled_deepslate
fill 34 279 243 41 279 244 minecraft:cobbled_deepslate
fill 34 279 254 41 279 255 minecraft:cobbled_deepslate
fill 35 279 245 41 279 248 minecraft:cobbled_deepslate
setblock 35 279 249 minecraft:polished_deepslate
fill 35 279 250 41 279 253 minecraft:cobbled_deepslate
fill 36 279 249 41 279 249 minecraft:cobbled_deepslate
setblock 3 280 231 minecraft:light[level=13]
setblock 3 280 239 minecraft:light[level=13]
setblock 3 280 247 minecraft:light[level=13]
setblock 3 280 255 minecraft:light[level=13]
setblock 3 280 263 minecraft:light[level=13]
setblock 11 280 231 minecraft:light[level=13]
setblock 11 280 239 minecraft:light[level=13]
setblock 11 280 247 minecraft:light[level=13]
setblock 11 280 255 minecraft:light[level=13]
setblock 11 280 263 minecraft:light[level=13]
setblock 19 280 231 minecraft:light[level=13]
setblock 19 280 239 minecraft:light[level=13]
setblock 19 280 247 minecraft:light[level=13]
setblock 19 280 255 minecraft:light[level=13]
setblock 19 280 263 minecraft:light[level=13]
setblock 27 280 231 minecraft:light[level=13]
setblock 27 280 239 minecraft:light[level=13]
setblock 27 280 247 minecraft:light[level=13]
setblock 27 280 255 minecraft:light[level=13]
setblock 27 280 263 minecraft:light[level=13]
setblock 35 280 231 minecraft:light[level=13]
setblock 35 280 239 minecraft:light[level=13]
setblock 35 280 247 minecraft:light[level=13]
setblock 35 280 255 minecraft:light[level=13]
setblock 35 280 263 minecraft:light[level=13]
fill 1 283 235 1 300 236 minecraft:chiseled_deepslate
fill 1 283 243 1 300 244 minecraft:chiseled_deepslate
fill 1 283 251 1 300 252 minecraft:chiseled_deepslate
fill 1 283 259 1 300 260 minecraft:chiseled_deepslate
fill 1 283 267 1 300 268 minecraft:chiseled_deepslate
fill 2 283 229 3 300 229 minecraft:chiseled_deepslate
setblock 3 283 232 minecraft:cobbled_deepslate
fill 3 283 233 6 300 233 minecraft:chiseled_deepslate
fill 3 283 234 3 283 235 minecraft:cobbled_deepslate
fill 4 283 231 5 283 231 minecraft:cobbled_deepslate
fill 4 283 232 5 300 232 minecraft:chiseled_deepslate
fill 4 283 234 6 300 234 minecraft:chiseled_deepslate
setblock 4 283 235 minecraft:cobbled_deepslate
fill 5 283 235 5 300 235 minecraft:chiseled_deepslate
setblock 6 283 232 minecraft:cobbled_deepslate
setblock 6 283 235 minecraft:cobbled_deepslate
fill 7 283 233 7 283 234 minecraft:cobbled_deepslate
fill 7 283 269 8 300 269 minecraft:chiseled_deepslate
fill 10 283 229 11 300 229 minecraft:chiseled_deepslate
fill 15 283 269 16 300 269 minecraft:chiseled_deepslate
fill 18 283 229 19 300 229 minecraft:chiseled_deepslate
fill 23 283 269 24 300 269 minecraft:chiseled_deepslate
fill 26 283 229 27 300 229 minecraft:chiseled_deepslate
fill 31 283 269 32 300 269 minecraft:chiseled_deepslate
fill 34 283 229 35 300 229 minecraft:chiseled_deepslate
fill 34 283 264 34 283 266 minecraft:cobbled_deepslate
setblock 35 283 263 minecraft:cobbled_deepslate
fill 35 283 264 37 300 266 minecraft:chiseled_deepslate
fill 36 283 263 36 300 263 minecraft:chiseled_deepslate
fill 36 283 267 37 283 267 minecraft:cobbled_deepslate
fill 37 283 263 38 283 263 minecraft:cobbled_deepslate
fill 38 283 264 38 283 266 minecraft:cobbled_deepslate
fill 39 283 269 40 300 269 minecraft:chiseled_deepslate
fill 41 283 230 41 300 231 minecraft:chiseled_deepslate
fill 41 283 238 41 300 239 minecraft:chiseled_deepslate
fill 41 283 246 41 300 247 minecraft:chiseled_deepslate
fill 41 283 254 41 300 255 minecraft:chiseled_deepslate
fill 41 283 262 41 300 263 minecraft:chiseled_deepslate
fill 0 284 233 0 289 233 minecraft:soul_lantern
fill 0 284 241 0 289 241 minecraft:soul_lantern
fill 0 284 249 0 289 249 minecraft:soul_lantern
fill 0 284 257 0 289 257 minecraft:soul_lantern
fill 0 284 265 0 289 265 minecraft:soul_lantern
fill 3 284 270 3 289 270 minecraft:soul_lantern
fill 7 284 228 7 289 228 minecraft:soul_lantern
fill 11 284 270 11 289 270 minecraft:soul_lantern
fill 15 284 228 15 289 228 minecraft:soul_lantern
fill 19 284 270 19 289 270 minecraft:soul_lantern
fill 23 284 228 23 289 228 minecraft:soul_lantern
fill 27 284 270 27 289 270 minecraft:soul_lantern
fill 31 284 228 31 289 228 minecraft:soul_lantern
fill 35 284 270 35 289 270 minecraft:soul_lantern
fill 39 284 228 39 289 228 minecraft:soul_lantern
fill 42 284 233 42 289 233 minecraft:soul_lantern
fill 42 284 241 42 289 241 minecraft:soul_lantern
fill 42 284 249 42 289 249 minecraft:soul_lantern
fill 42 284 257 42 289 257 minecraft:soul_lantern
fill 42 284 265 42 289 265 minecraft:soul_lantern
fill 21 286 262 25 287 266 minecraft:cobbled_deepslate
fill 23 286 267 23 286 268 minecraft:cobbled_deepslate
setblock 3 288 231 minecraft:light[level=13]
setblock 3 288 239 minecraft:light[level=13]
setblock 3 288 247 minecraft:light[level=13]
setblock 3 288 255 minecraft:light[level=13]
setblock 3 288 263 minecraft:light[level=13]
setblock 11 288 231 minecraft:light[level=13]
setblock 11 288 239 minecraft:light[level=13]
setblock 11 288 247 minecraft:light[level=13]
setblock 11 288 255 minecraft:light[level=13]
setblock 11 288 263 minecraft:light[level=13]
setblock 19 288 231 minecraft:light[level=13]
setblock 19 288 239 minecraft:light[level=13]
setblock 19 288 247 minecraft:light[level=13]
setblock 19 288 255 minecraft:light[level=13]
setblock 19 288 263 minecraft:light[level=13]
fill 22 288 263 24 289 265 minecraft:chiseled_deepslate
setblock 27 288 231 minecraft:light[level=13]
setblock 27 288 239 minecraft:light[level=13]
setblock 27 288 247 minecraft:light[level=13]
setblock 27 288 255 minecraft:light[level=13]
setblock 27 288 263 minecraft:light[level=13]
fill 34 288 235 38 289 239 minecraft:cobbled_deepslate
setblock 35 288 231 minecraft:light[level=13]
setblock 35 288 247 minecraft:light[level=13]
setblock 35 288 255 minecraft:light[level=13]
setblock 35 288 263 minecraft:light[level=13]
fill 39 288 237 40 288 237 minecraft:cobbled_deepslate
fill 0 290 233 0 297 233 minecraft:polished_deepslate
fill 0 290 241 0 297 241 minecraft:polished_deepslate
fill 0 290 249 0 297 249 minecraft:polished_deepslate
fill 0 290 257 0 297 257 minecraft:polished_deepslate
fill 0 290 265 0 297 265 minecraft:polished_deepslate
fill 3 290 270 3 297 270 minecraft:polished_deepslate
fill 7 290 228 7 297 228 minecraft:polished_deepslate
fill 11 290 270 11 297 270 minecraft:polished_deepslate
fill 15 290 228 15 297 228 minecraft:polished_deepslate
fill 19 290 270 19 297 270 minecraft:polished_deepslate
fill 22 290 264 24 292 264 minecraft:chiseled_deepslate
fill 23 290 228 23 297 228 minecraft:polished_deepslate
fill 23 290 263 23 292 263 minecraft:chiseled_deepslate
fill 23 290 265 23 292 265 minecraft:chiseled_deepslate
fill 27 290 270 27 297 270 minecraft:polished_deepslate
fill 31 290 228 31 297 228 minecraft:polished_deepslate
fill 35 290 236 37 291 238 minecraft:chiseled_deepslate
fill 35 290 270 35 297 270 minecraft:polished_deepslate
fill 39 290 228 39 297 228 minecraft:polished_deepslate
fill 42 290 233 42 297 233 minecraft:polished_deepslate
fill 42 290 241 42 297 241 minecraft:polished_deepslate
fill 42 290 249 42 297 249 minecraft:polished_deepslate
fill 42 290 257 42 297 257 minecraft:polished_deepslate
fill 42 290 265 42 297 265 minecraft:polished_deepslate
setblock 3 291 232 minecraft:cobbled_deepslate
fill 3 291 234 3 291 235 minecraft:cobbled_deepslate
fill 4 291 231 5 291 231 minecraft:cobbled_deepslate
setblock 4 291 235 minecraft:cobbled_deepslate
setblock 6 291 232 minecraft:cobbled_deepslate
setblock 6 291 235 minecraft:cobbled_deepslate
fill 7 291 233 7 291 234 minecraft:cobbled_deepslate
fill 34 291 264 34 291 266 minecraft:cobbled_deepslate
setblock 35 291 263 minecraft:cobbled_deepslate
fill 36 291 267 37 291 267 minecraft:cobbled_deepslate
fill 37 291 263 38 291 263 minecraft:cobbled_deepslate
fill 38 291 264 38 291 266 minecraft:cobbled_deepslate
fill 35 292 237 37 294 237 minecraft:chiseled_deepslate
fill 36 292 236 36 294 236 minecraft:chiseled_deepslate
fill 36 292 238 36 294 238 minecraft:chiseled_deepslate
fill 23 293 264 23 297 264 minecraft:chiseled_deepslate
fill 1 294 229 1 295 234 minecraft:chiseled_deepslate
fill 1 294 237 2 294 242 minecraft:chiseled_deepslate
fill 1 294 245 2 294 250 minecraft:chiseled_deepslate
fill 1 294 253 2 294 258 minecraft:chiseled_deepslate
fill 1 294 261 2 294 266 minecraft:chiseled_deepslate
fill 1 294 269 6 295 269 minecraft:chiseled_deepslate
fill 2 294 230 2 294 236 minecraft:chiseled_deepslate
fill 2 294 243 2 294 244 minecraft:chiseled_deepslate
fill 2 294 251 2 294 252 minecraft:chiseled_deepslate
fill 2 294 259 2 294 260 minecraft:chiseled_deepslate
fill 2 294 267 2 294 268 minecraft:chiseled_deepslate
fill 3 294 230 40 294 230 minecraft:chiseled_deepslate
fill 3 294 268 41 294 268 minecraft:chiseled_deepslate
fill 4 294 229 9 295 229 minecraft:chiseled_deepslate
fill 9 294 269 14 295 269 minecraft:chiseled_deepslate
fill 12 294 229 17 295 229 minecraft:chiseled_deepslate
fill 17 294 269 22 295 269 minecraft:chiseled_deepslate
fill 20 294 229 25 295 229 minecraft:chiseled_deepslate
fill 25 294 269 30 295 269 minecraft:chiseled_deepslate
fill 28 294 229 33 295 229 minecraft:chiseled_deepslate
fill 33 294 269 38 295 269 minecraft:chiseled_deepslate
fill 36 294 229 41 295 229 minecraft:chiseled_deepslate
fill 40 294 231 40 294 267 minecraft:chiseled_deepslate
fill 41 294 232 41 295 237 minecraft:chiseled_deepslate
fill 41 294 240 41 295 245 minecraft:chiseled_deepslate
fill 41 294 248 41 295 253 minecraft:chiseled_deepslate
fill 41 294 256 41 295 261 minecraft:chiseled_deepslate
fill 41 294 264 41 295 267 minecraft:chiseled_deepslate
fill 41 294 269 41 295 269 minecraft:chiseled_deepslate
fill 1 295 237 1 295 242 minecraft:chiseled_deepslate
fill 1 295 245 1 295 250 minecraft:chiseled_deepslate
fill 1 295 253 1 295 258 minecraft:chiseled_deepslate
fill 1 295 261 1 295 266 minecraft:chiseled_deepslate
fill 36 295 237 36 299 237 minecraft:chiseled_deepslate
setblock 41 295 268 minecraft:chiseled_deepslate
setblock 3 296 231 minecraft:light[level=13]
setblock 3 296 239 minecraft:light[level=13]
setblock 3 296 247 minecraft:light[level=13]
setblock 3 296 255 minecraft:light[level=13]
setblock 3 296 263 minecraft:light[level=13]
setblock 11 296 231 minecraft:light[level=13]
setblock 11 296 239 minecraft:light[level=13]
setblock 11 296 247 minecraft:light[level=13]
setblock 11 296 255 minecraft:light[level=13]
setblock 11 296 263 minecraft:light[level=13]
setblock 19 296 231 minecraft:light[level=13]
setblock 19 296 239 minecraft:light[level=13]
setblock 19 296 247 minecraft:light[level=13]
setblock 19 296 255 minecraft:light[level=13]
setblock 19 296 263 minecraft:light[level=13]
setblock 27 296 231 minecraft:light[level=13]
setblock 27 296 239 minecraft:light[level=13]
setblock 27 296 247 minecraft:light[level=13]
setblock 27 296 255 minecraft:light[level=13]
setblock 27 296 263 minecraft:light[level=13]
setblock 35 296 231 minecraft:light[level=13]
setblock 35 296 239 minecraft:light[level=13]
setblock 35 296 247 minecraft:light[level=13]
setblock 35 296 255 minecraft:light[level=13]
setblock 35 296 263 minecraft:light[level=13]
fill 0 298 233 0 300 233 minecraft:soul_lantern
fill 0 298 241 0 300 241 minecraft:soul_lantern
fill 0 298 249 0 300 249 minecraft:soul_lantern
fill 0 298 257 0 300 257 minecraft:soul_lantern
fill 0 298 265 0 300 265 minecraft:soul_lantern
fill 3 298 270 3 300 270 minecraft:soul_lantern
fill 7 298 228 7 300 228 minecraft:soul_lantern
fill 11 298 270 11 300 270 minecraft:soul_lantern
fill 15 298 228 15 300 228 minecraft:soul_lantern
fill 19 298 270 19 300 270 minecraft:soul_lantern
fill 23 298 228 23 300 228 minecraft:soul_lantern
setblock 23 298 264 minecraft:soul_lantern
fill 27 298 270 27 300 270 minecraft:soul_lantern
fill 31 298 228 31 300 228 minecraft:soul_lantern
fill 35 298 270 35 300 270 minecraft:soul_lantern
fill 39 298 228 39 300 228 minecraft:soul_lantern
fill 42 298 233 42 300 233 minecraft:soul_lantern
fill 42 298 241 42 300 241 minecraft:soul_lantern
fill 42 298 249 42 300 249 minecraft:soul_lantern
fill 42 298 257 42 300 257 minecraft:soul_lantern
fill 42 298 265 42 300 265 minecraft:soul_lantern
setblock 3 299 232 minecraft:cobbled_deepslate
fill 3 299 234 3 299 235 minecraft:cobbled_deepslate
fill 4 299 231 5 299 231 minecraft:cobbled_deepslate
setblock 4 299 235 minecraft:cobbled_deepslate
setblock 6 299 232 minecraft:cobbled_deepslate
setblock 6 299 235 minecraft:cobbled_deepslate
fill 7 299 233 7 299 234 minecraft:cobbled_deepslate
fill 34 299 264 34 299 266 minecraft:cobbled_deepslate
setblock 35 299 263 minecraft:cobbled_deepslate
fill 36 299 267 37 299 267 minecraft:cobbled_deepslate
fill 37 299 263 38 299 263 minecraft:cobbled_deepslate
fill 38 299 264 38 299 266 minecraft:cobbled_deepslate
setblock 3 300 232 minecraft:gold_block
setblock 3 300 234 minecraft:gold_block
fill 4 300 231 5 300 231 minecraft:gold_block
setblock 4 300 235 minecraft:gold_block
setblock 6 300 232 minecraft:gold_block
setblock 6 300 235 minecraft:gold_block
setblock 7 300 233 minecraft:gold_block
fill 34 300 264 34 300 265 minecraft:gold_block
setblock 35 300 263 minecraft:gold_block
setblock 36 300 237 minecraft:soul_lantern
setblock 36 300 267 minecraft:gold_block
setblock 37 300 263 minecraft:gold_block
fill 38 300 264 38 300 266 minecraft:gold_block
fill 0 301 233 0 307 233 minecraft:polished_deepslate
fill 0 301 241 0 307 241 minecraft:polished_deepslate
fill 0 301 249 0 307 249 minecraft:polished_deepslate
fill 0 301 257 0 307 257 minecraft:polished_deepslate
fill 0 301 265 0 307 265 minecraft:polished_deepslate
fill 3 301 270 3 307 270 minecraft:polished_deepslate
fill 7 301 228 7 307 228 minecraft:polished_deepslate
fill 11 301 270 11 307 270 minecraft:polished_deepslate
fill 15 301 228 15 307 228 minecraft:polished_deepslate
fill 19 301 270 19 307 270 minecraft:polished_deepslate
fill 23 301 228 23 307 228 minecraft:polished_deepslate
fill 27 301 270 27 307 270 minecraft:polished_deepslate
fill 31 301 228 31 307 228 minecraft:polished_deepslate
fill 35 301 270 35 307 270 minecraft:polished_deepslate
fill 39 301 228 39 307 228 minecraft:polished_deepslate
fill 42 301 233 42 307 233 minecraft:polished_deepslate
fill 42 301 241 42 307 241 minecraft:polished_deepslate
fill 42 301 249 42 307 249 minecraft:polished_deepslate
fill 42 301 257 42 307 257 minecraft:polished_deepslate
fill 42 301 265 42 307 265 minecraft:polished_deepslate
