setblock 142 292 323 minecraft:dark_prismarine
fill 142 292 324 142 292 327 minecraft:blue_terracotta
setblock 142 292 328 minecraft:dark_prismarine
fill 142 292 329 142 295 329 minecraft:blue_terracotta
setblock 142 292 331 minecraft:sea_lantern
setblock 142 292 333 minecraft:sea_lantern
fill 142 292 334 142 295 334 minecraft:blue_terracotta
setblock 142 292 335 minecraft:sea_lantern
fill 142 292 336 142 292 337 minecraft:blue_terracotta
setblock 142 292 338 minecraft:dark_prismarine
fill 142 292 339 142 292 342 minecraft:blue_terracotta
setblock 142 292 343 minecraft:dark_prismarine
fill 142 292 344 142 292 347 minecraft:blue_terracotta
setblock 142 292 348 minecraft:dark_prismarine
fill 142 292 349 142 292 352 minecraft:blue_terracotta
setblock 142 292 353 minecraft:dark_prismarine
fill 142 292 354 142 295 354 minecraft:blue_terracotta
setblock 142 292 359 minecraft:purple_concrete
fill 143 292 323 143 292 326 minecraft:blue_terracotta
setblock 143 292 327 minecraft:dark_prismarine
fill 143 292 328 143 295 328 minecraft:blue_terracotta
setblock 143 292 330 minecraft:sea_lantern
setblock 143 292 332 minecraft:sea_lantern
fill 143 292 333 143 295 333 minecraft:blue_terracotta
setblock 143 292 334 minecraft:sea_lantern
fill 143 292 335 143 293 335 minecraft:blue_terracotta
setblock 143 292 336 minecraft:sea_lantern
setblock 143 292 347 minecraft:dark_prismarine
setblock 143 292 348 minecraft:blue_terracotta
fill 144 292 323 144 292 324 minecraft:blue_terracotta
setblock 144 292 326 minecraft:dark_prismarine
setblock 144 292 327 minecraft:blue_terracotta
setblock 144 292 331 minecraft:sea_lantern
setblock 144 292 333 minecraft:sea_lantern
setblock 144 292 335 minecraft:sea_lantern
fill 145 292 323 146 292 323 minecraft:blue_terracotta
fill 145 292 327 154 292 327 minecraft:dark_prismarine
setblock 145 292 330 minecraft:sea_lantern
setblock 145 292 332 minecraft:sea_lantern
setblock 145 292 334 minecraft:sea_lantern
setblock 145 292 336 minecraft:sea_lantern
setblock 146 292 331 minecraft:sea_lantern
setblock 146 292 333 minecraft:sea_lantern
setblock 146 292 335 minecraft:sea_lantern
setblock 147 292 323 minecraft:dark_prismarine
setblock 147 292 330 minecraft:sea_lantern
setblock 147 292 332 minecraft:sea_lantern
setblock 147 292 334 minecraft:sea_lantern
setblock 147 292 336 minecraft:sea_lantern
fill 148 292 323 151 292 323 minecraft:blue_terracotta
fill 148 292 341 148 298 341 minecraft:magenta_terracotta
fill 150 292 342 152 293 342 minecraft:dark_prismarine
fill 151 292 341 152 293 341 minecraft:dark_prismarine
setblock 152 292 323 minecraft:dark_prismarine
fill 153 292 322 153 308 322 minecraft:blue_concrete
fill 153 292 323 155 292 324 minecraft:blue_terracotta
setblock 155 292 325 minecraft:dark_prismarine
fill 155 292 363 156 292 363 minecraft:blue_terracotta
setblock 156 292 323 minecraft:blue_terracotta
setblock 156 292 324 minecraft:dark_prismarine
fill 156 292 325 159 292 325 minecraft:blue_terracotta
setblock 157 292 323 minecraft:dark_prismarine
fill 157 292 324 160 292 324 minecraft:blue_terracotta
setblock 157 292 363 minecraft:dark_prismarine
fill 158 292 323 161 292 323 minecraft:blue_terracotta
fill 158 292 363 161 292 363 minecraft:blue_terracotta
fill 159 292 362 162 292 362 minecraft:blue_terracotta
setblock 160 292 325 minecraft:dark_prismarine
setblock 161 292 324 minecraft:dark_prismarine
setblock 161 292 325 minecraft:blue_terracotta
setblock 162 292 323 minecraft:dark_prismarine
fill 162 292 324 162 293 324 minecraft:blue_terracotta
setblock 162 292 363 minecraft:dark_prismarine
fill 163 292 323 165 292 323 minecraft:blue_terracotta
fill 163 292 363 165 292 363 minecraft:blue_terracotta
setblock 173 292 352 minecraft:sea_lantern
setblock 173 292 354 minecraft:sea_lantern
setblock 173 292 356 minecraft:sea_lantern
setblock 173 292 358 minecraft:sea_lantern
setblock 173 292 360 minecraft:sea_lantern
setblock 173 292 362 minecraft:sea_lantern
setblock 174 292 353 minecraft:sea_lantern
setblock 174 292 355 minecraft:sea_lantern
setblock 174 292 357 minecraft:sea_lantern
setblock 174 292 359 minecraft:sea_lantern
setblock 174 292 361 minecraft:sea_lantern
setblock 175 292 352 minecraft:sea_lantern
setblock 175 292 354 minecraft:sea_lantern
setblock 175 292 356 minecraft:sea_lantern
setblock 175 292 358 minecraft:sea_lantern
setblock 175 292 360 minecraft:sea_lantern
setblock 175 292 362 minecraft:sea_lantern
setblock 176 292 353 minecraft:sea_lantern
setblock 176 292 355 minecraft:sea_lantern
setblock 176 292 357 minecraft:sea_lantern
setblock 176 292 359 minecraft:sea_lantern
setblock 176 292 361 minecraft:sea_lantern
setblock 177 292 352 minecraft:sea_lantern
setblock 177 292 354 minecraft:sea_lantern
setblock 177 292 356 minecraft:sea_lantern
setblock 177 292 358 minecraft:sea_lantern
setblock 177 292 360 minecraft:sea_lantern
setblock 177 292 362 minecraft:sea_lantern
setblock 178 292 323 minecraft:blue_terracotta
setblock 178 292 353 minecraft:sea_lantern
setblock 178 292 355 minecraft:sea_lantern
setblock 178 292 357 minecraft:sea_lantern
setblock 178 292 359 minecraft:sea_lantern
setblock 178 292 361 minecraft:sea_lantern
setblock 179 292 347 minecraft:blue_terracotta
setblock 179 292 351 minecraft:dark_prismarine
setblock 179 292 352 minecraft:sea_lantern
setblock 179 292 354 minecraft:sea_lantern
setblock 179 292 356 minecraft:sea_lantern
setblock 179 292 358 minecraft:sea_lantern
setblock 179 292 360 minecraft:sea_lantern
setblock 179 292 362 minecraft:sea_lantern
setblock 180 292 345 minecraft:dark_prismarine
fill 180 292 346 180 294 346 minecraft:blue_terracotta
setblock 180 292 350 minecraft:dark_prismarine
fill 180 292 351 180 295 351 minecraft:blue_terracotta
setblock 180 292 353 minecraft:sea_lantern
setblock 180 292 355 minecraft:sea_lantern
setblock 180 292 357 minecraft:sea_lantern
setblock 180 292 359 minecraft:sea_lantern
setblock 180 292 361 minecraft:sea_lantern
fill 180 292 362 180 300 362 minecraft:dark_prismarine
fill 181 292 322 181 308 322 minecraft:blue_concrete
setblock 181 292 325 minecraft:blue_terracotta
setblock 181 292 329 minecraft:dark_prismarine
fill 181 292 330 181 292 333 minecraft:blue_terracotta
setblock 181 292 334 minecraft:dark_prismarine
fill 181 292 335 181 295 335 minecraft:blue_terracotta
setblock 181 292 340 minecraft:blue_terracotta
setblock 181 292 344 minecraft:dark_prismarine
fill 181 292 345 181 295 345 minecraft:blue_terracotta
setblock 181 292 349 minecraft:dark_prismarine
fill 181 292 350 181 295 350 minecraft:blue_terracotta
setblock 181 292 352 minecraft:sea_lantern
setblock 181 292 354 minecraft:sea_lantern
fill 181 292 355 181 295 355 minecraft:blue_terracotta
setblock 181 292 356 minecraft:sea_lantern
setblock 181 292 358 minecraft:sea_lantern
setblock 181 292 360 minecraft:sea_lantern
setblock 181 292 362 minecraft:sea_lantern
setblock 182 292 323 minecraft:dark_prismarine
fill 182 292 324 182 293 324 minecraft:blue_terracotta
setblock 182 292 328 minecraft:dark_prismarine
fill 182 292 329 182 292 332 minecraft:blue_terracotta
setblock 182 292 333 minecraft:dark_prismarine
fill 182 292 334 182 295 334 minecraft:blue_terracotta
setblock 182 292 338 minecraft:dark_prismarine
fill 182 292 339 182 295 339 minecraft:blue_terracotta
setblock 182 292 343 minecraft:dark_prismarine
fill 182 292 344 182 295 344 minecraft:blue_terracotta
setblock 182 292 348 minecraft:dark_prismarine
fill 182 292 349 182 295 349 minecraft:blue_terracotta
setblock 182 292 353 minecraft:sea_lantern
fill 182 292 354 182 295 354 minecraft:blue_terracotta
setblock 182 292 355 minecraft:sea_lantern
fill 182 292 356 182 293 356 minecraft:blue_terracotta
setblock 182 292 357 minecraft:sea_lantern
fill 182 292 358 182 297 358 minecraft:dark_prismarine
setblock 182 292 359 minecraft:sea_lantern
fill 182 292 360 182 296 360 minecraft:dark_prismarine
setblock 182 292 361 minecraft:sea_lantern
fill 182 292 362 182 300 362 minecraft:dark_prismarine
setblock 182 292 363 minecraft:purple_concrete
fill 142 293 323 142 293 326 minecraft:blue_terracotta
setblock 142 293 327 minecraft:dark_prismarine
fill 142 293 328 142 296 328 minecraft:blue_terracotta
setblock 142 293 331 minecraft:blue_terracotta
setblock 142 293 332 minecraft:dark_prismarine
fill 142 293 333 142 294 333 minecraft:blue_terracotta
fill 142 293 335 142 293 336 minecraft:blue_terracotta
setblock 142 293 337 minecraft:dark_prismarine
fill 142 293 338 142 293 341 minecraft:blue_terracotta
setblock 142 293 342 minecraft:dark_prismarine
fill 142 293 343 142 293 346 minecraft:blue_terracotta
setblock 142 293 347 minecraft:dark_prismarine
fill 142 293 348 142 293 351 minecraft:blue_terracotta
setblock 142 293 352 minecraft:dark_prismarine
fill 142 293 353 142 296 353 minecraft:blue_terracotta
fill 143 293 323 145 293 323 minecraft:blue_terracotta
setblock 143 293 325 minecraft:blue_terracotta
setblock 143 293 326 minecraft:dark_prismarine
fill 143 293 327 143 296 327 minecraft:blue_terracotta
setblock 143 293 330 minecraft:blue_terracotta
setblock 143 293 331 minecraft:dark_prismarine
fill 143 293 332 143 294 332 minecraft:blue_terracotta
fill 143 293 334 143 294 334 minecraft:blue_terracotta
fill 143 293 336 143 294 336 minecraft:dark_prismarine
setblock 144 293 325 minecraft:light[level=13]
fill 144 293 327 154 293 327 minecraft:purple_concrete
fill 144 293 330 145 293 330 minecraft:dark_prismarine
setblock 144 293 331 minecraft:blue_terracotta
fill 144 293 333 144 294 333 minecraft:dark_prismarine
fill 144 293 335 144 294 335 minecraft:dark_prismarine
setblock 144 293 339 minecraft:light[level=12]
setblock 144 293 341 minecraft:light[level=13]
setblock 144 293 346 minecraft:light[level=12]
setblock 144 293 349 minecraft:light[level=13]
setblock 144 293 353 minecraft:light[level=12]
setblock 144 293 357 minecraft:light[level=13]
setblock 144 293 360 minecraft:light[level=12]
setblock 144 293 363 minecraft:purple_concrete
fill 145 293 332 145 294 332 minecraft:dark_prismarine
fill 145 293 334 145 294 334 minecraft:dark_prismarine
fill 145 293 336 145 294 336 minecraft:dark_prismarine
fill 146 293 331 146 294 331 minecraft:dark_prismarine
fill 146 293 333 146 294 333 minecraft:dark_prismarine
fill 146 293 335 146 294 335 minecraft:dark_prismarine
fill 147 293 330 147 294 330 minecraft:dark_prismarine
fill 147 293 332 147 294 332 minecraft:dark_prismarine
fill 147 293 334 147 294 334 minecraft:dark_prismarine
fill 147 293 336 147 294 336 minecraft:dark_prismarine
setblock 150 293 322 minecraft:light_blue_wool
fill 151 293 322 151 308 322 minecraft:blue_concrete
setblock 151 293 323 minecraft:dark_prismarine
setblock 151 293 325 minecraft:light[level=12]
setblock 151 293 332 minecraft:light[level=12]
setblock 151 293 339 minecraft:light[level=12]
setblock 151 293 346 minecraft:light[level=12]
setblock 151 293 353 minecraft:light[level=12]
setblock 151 293 360 minecraft:light[level=12]
fill 152 293 323 155 293 323 minecraft:blue_terracotta
setblock 152 293 325 minecraft:light[level=13]
setblock 152 293 333 minecraft:light[level=13]
setblock 152 293 349 minecraft:light[level=13]
setblock 154 293 324 minecraft:blue_terracotta
setblock 155 293 324 minecraft:dark_prismarine
setblock 155 293 363 minecraft:blue_terracotta
setblock 156 293 323 minecraft:dark_prismarine
fill 156 293 324 158 293 325 minecraft:blue_terracotta
fill 156 293 327 180 293 327 minecraft:purple_concrete
setblock 156 293 363 minecraft:dark_prismarine
fill 157 293 323 160 293 323 minecraft:blue_terracotta
fill 157 293 363 160 293 363 minecraft:blue_terracotta
setblock 158 293 332 minecraft:light[level=12]
setblock 158 293 339 minecraft:light[level=12]
setblock 158 293 346 minecraft:light[level=12]
setblock 158 293 353 minecraft:light[level=12]
setblock 158 293 360 minecraft:light[level=12]
setblock 159 293 324 minecraft:blue_terracotta
setblock 159 293 325 minecraft:dark_prismarine
fill 159 293 362 161 293 362 minecraft:blue_terracotta
setblock 160 293 324 minecraft:dark_prismarine
setblock 160 293 325 minecraft:blue_terracotta
setblock 160 293 333 minecraft:light[level=13]
setblock 160 293 341 minecraft:light[level=13]
setblock 160 293 349 minecraft:light[level=13]
setblock 161 293 323 minecraft:dark_prismarine
fill 161 293 324 161 294 324 minecraft:blue_terracotta
setblock 161 293 363 minecraft:dark_prismarine
fill 162 293 323 164 293 323 minecraft:blue_terracotta
fill 162 293 363 164 293 363 minecraft:blue_terracotta
setblock 165 293 325 minecraft:light[level=12]
setblock 165 293 332 minecraft:light[level=12]
setblock 165 293 339 minecraft:light[level=12]
setblock 165 293 346 minecraft:light[level=12]
setblock 165 293 353 minecraft:light[level=12]
setblock 165 293 360 minecraft:light[level=12]
setblock 168 293 325 minecraft:light[level=13]
setblock 168 293 333 minecraft:light[level=13]
setblock 168 293 341 minecraft:light[level=13]
setblock 168 293 349 minecraft:light[level=13]
setblock 168 293 357 minecraft:light[level=13]
fill 169 293 322 171 308 322 minecraft:blue_concrete
setblock 169 293 363 minecraft:purple_concrete
setblock 172 293 322 minecraft:cyan_concrete
setblock 172 293 325 minecraft:light[level=12]
setblock 172 293 332 minecraft:light[level=12]
setblock 172 293 339 minecraft:light[level=12]
setblock 172 293 346 minecraft:light[level=12]
setblock 172 293 353 minecraft:light[level=12]
setblock 172 293 360 minecraft:light[level=12]
fill 173 293 352 173 294 352 minecraft:dark_prismarine
fill 173 293 354 173 294 354 minecraft:dark_prismarine
fill 173 293 356 173 294 356 minecraft:dark_prismarine
fill 173 293 358 173 294 358 minecraft:dark_prismarine
fill 173 293 360 173 294 360 minecraft:dark_prismarine
fill 173 293 362 173 294 362 minecraft:dark_prismarine
fill 174 293 323 174 294 323 minecraft:purple_concrete
fill 174 293 353 174 294 353 minecraft:dark_prismarine
fill 174 293 355 174 294 355 minecraft:dark_prismarine
fill 174 293 357 174 294 357 minecraft:dark_prismarine
fill 174 293 359 174 294 359 minecraft:dark_prismarine
fill 174 293 361 174 294 361 minecraft:dark_prismarine
fill 175 293 352 175 294 352 minecraft:dark_prismarine
fill 175 293 354 175 294 354 minecraft:dark_prismarine
fill 175 293 356 175 294 356 minecraft:dark_prismarine
fill 175 293 358 175 294 358 minecraft:dark_prismarine
fill 175 293 360 175 294 360 minecraft:dark_prismarine
fill 175 293 362 175 294 362 minecraft:dark_prismarine
setblock 176 293 325 minecraft:light[level=13]
setblock 176 293 333 minecraft:light[level=13]
setblock 176 293 341 minecraft:light[level=13]
setblock 176 293 349 minecraft:light[level=13]
fill 176 293 353 176 294 353 minecraft:dark_prismarine
fill 176 293 355 176 294 355 minecraft:dark_prismarine
fill 176 293 357 176 294 357 minecraft:dark_prismarine
fill 176 293 359 176 294 359 minecraft:dark_prismarine
fill 176 293 361 176 294 361 minecraft:dark_prismarine
fill 177 293 344 177 297 344 minecraft:magenta_terracotta
fill 177 293 352 177 294 352 minecraft:dark_prismarine
fill 177 293 354 177 294 354 minecraft:dark_prismarine
fill 177 293 356 177 294 356 minecraft:dark_prismarine
fill 177 293 358 177 294 358 minecraft:dark_prismarine
fill 177 293 360 177 294 360 minecraft:dark_prismarine
fill 177 293 362 177 294 362 minecraft:dark_prismarine
fill 178 293 353 178 294 353 minecraft:dark_prismarine
fill 178 293 355 178 294 355 minecraft:dark_prismarine
fill 178 293 357 178 294 357 minecraft:dark_prismarine
fill 178 293 359 178 294 359 minecraft:dark_prismarine
fill 178 293 361 178 294 361 minecraft:dark_prismarine
setblock 179 293 325 minecraft:light[level=12]
setblock 179 293 332 minecraft:light[level=12]
setblock 179 293 339 minecraft:light[level=12]
setblock 179 293 346 minecraft:light[level=12]
setblock 179 293 350 minecraft:dark_prismarine
fill 179 293 351 179 294 351 minecraft:blue_terracotta
fill 179 293 352 179 294 352 minecraft:dark_prismarine
fill 179 293 354 180 293 354 minecraft:dark_prismarine
fill 179 293 356 179 294 356 minecraft:dark_prismarine
fill 179 293 358 179 294 358 minecraft:dark_prismarine
fill 179 293 360 179 294 360 minecraft:dark_prismarine
fill 179 293 362 179 294 362 minecraft:dark_prismarine
setblock 180 293 323 minecraft:purple_concrete
setblock 180 293 345 minecraft:blue_terracotta
setblock 180 293 349 minecraft:dark_prismarine
fill 180 293 350 180 296 350 minecraft:blue_terracotta
setblock 180 293 353 minecraft:blue_terracotta
fill 180 293 355 180 294 355 minecraft:dark_prismarine
fill 180 293 357 180 294 357 minecraft:dark_prismarine
fill 180 293 359 180 294 359 minecraft:dark_prismarine
fill 180 293 361 180 294 361 minecraft:dark_prismarine
setblock 181 293 328 minecraft:dark_prismarine
fill 181 293 329 181 293 332 minecraft:blue_terracotta
setblock 181 293 333 minecraft:dark_prismarine
fill 181 293 334 181 296 334 minecraft:blue_terracotta
setblock 181 293 343 minecraft:dark_prismarine
fill 181 293 344 181 296 344 minecraft:blue_terracotta
setblock 181 293 348 minecraft:dark_prismarine
fill 181 293 349 181 296 349 minecraft:blue_terracotta
setblock 181 293 352 minecraft:blue_terracotta
setblock 181 293 353 minecraft:dark_prismarine
fill 181 293 354 181 294 354 minecraft:blue_terracotta
setblock 181 293 356 minecraft:dark_prismarine
fill 181 293 358 181 294 358 minecraft:dark_prismarine
fill 181 293 360 181 294 360 minecraft:dark_prismarine
fill 181 293 362 181 294 362 minecraft:dark_prismarine
setblock 182 293 327 minecraft:dark_prismarine
fill 182 293 328 182 293 331 minecraft:blue_terracotta
setblock 182 293 332 minecraft:dark_prismarine
fill 182 293 333 182 296 333 minecraft:blue_terracotta
setblock 182 293 337 minecraft:dark_prismarine
fill 182 293 338 182 296 338 minecraft:blue_terracotta
setblock 182 293 342 minecraft:dark_prismarine
fill 182 293 343 182 296 343 minecraft:blue_terracotta
setblock 182 293 347 minecraft:dark_prismarine
fill 182 293 348 182 296 348 minecraft:blue_terracotta
setblock 182 293 352 minecraft:dark_prismarine
fill 182 293 353 182 294 353 minecraft:blue_terracotta
fill 182 293 355 182 294 355 minecraft:blue_terracotta
setblock 182 293 357 minecraft:dark_prismarine
setblock 182 293 359 minecraft:dark_prismarine
fill 182 293 361 182 294 361 minecraft:dark_prismarine
fill 142 294 323 142 294 325 minecraft:blue_terracotta
setblock 142 294 326 minecraft:dark_prismarine
fill 142 294 327 142 297 327 minecraft:blue_terracotta
setblock 142 294 331 minecraft:dark_prismarine
fill 142 294 332 142 297 332 minecraft:blue_terracotta
setblock 142 294 335 minecraft:blue_terracotta
setblock 142 294 336 minecraft:dark_prismarine
fill 142 294 337 142 294 340 minecraft:blue_terracotta
setblock 142 294 341 minecraft:dark_prismarine
fill 142 294 342 142 294 345 minecraft:blue_terracotta
setblock 142 294 346 minecraft:dark_prismarine
fill 142 294 347 142 294 350 minecraft:blue_terracotta
setblock 142 294 351 minecraft:dark_prismarine
fill 142 294 352 142 297 352 minecraft:blue_terracotta
setblock 143 294 323 minecraft:blue_terracotta
setblock 143 294 325 minecraft:dark_prismarine
fill 143 294 326 143 296 326 minecraft:blue_terracotta
setblock 143 294 330 minecraft:dark_prismarine
fill 143 294 331 143 297 331 minecraft:blue_terracotta
setblock 143 294 335 minecraft:dark_prismarine
setblock 144 294 330 minecraft:blue_terracotta
setblock 144 294 331 minecraft:dark_prismarine
setblock 145 294 330 minecraft:dark_prismarine
setblock 149 294 323 minecraft:purple_concrete
fill 150 294 322 150 308 322 minecraft:blue_concrete
setblock 150 294 363 minecraft:purple_concrete
setblock 150 294 364 minecraft:light_blue_wool
fill 152 294 323 154 294 323 minecraft:blue_terracotta
setblock 154 294 324 minecraft:dark_prismarine
setblock 155 294 323 minecraft:dark_prismarine
fill 155 294 324 158 294 324 minecraft:blue_terracotta
setblock 155 294 363 minecraft:dark_prismarine
fill 156 294 323 159 294 323 minecraft:blue_terracotta
fill 156 294 363 159 294 363 minecraft:blue_terracotta
setblock 157 294 325 minecraft:blue_terracotta
setblock 158 294 325 minecraft:dark_prismarine
setblock 159 294 324 minecraft:dark_prismarine
fill 159 294 362 160 294 362 minecraft:blue_terracotta
setblock 160 294 323 minecraft:dark_prismarine
fill 160 294 324 160 295 324 minecraft:blue_terracotta
setblock 160 294 363 minecraft:dark_prismarine
fill 161 294 323 163 294 323 minecraft:blue_terracotta
fill 161 294 363 163 295 363 minecraft:blue_terracotta
setblock 168 294 323 minecraft:purple_concrete
fill 172 294 322 172 308 322 minecraft:blue_concrete
setblock 175 294 363 minecraft:purple_concrete
setblock 179 294 350 minecraft:blue_terracotta
setblock 179 294 354 minecraft:dark_prismarine
setblock 180 294 348 minecraft:dark_prismarine
fill 180 294 349 180 297 349 minecraft:blue_terracotta
setblock 180 294 353 minecraft:dark_prismarine
fill 180 294 354 180 297 354 minecraft:blue_terracotta
setblock 181 294 327 minecraft:dark_prismarine
fill 181 294 328 181 294 331 minecraft:blue_terracotta
setblock 181 294 332 minecraft:dark_prismarine
fill 181 294 333 181 297 333 minecraft:blue_terracotta
setblock 181 294 337 minecraft:dark_prismarine
setblock 181 294 342 minecraft:dark_prismarine
fill 181 294 343 181 295 343 minecraft:blue_terracotta
setblock 181 294 347 minecraft:dark_prismarine
fill 181 294 348 181 297 348 minecraft:blue_terracotta
setblock 181 294 352 minecraft:dark_prismarine
fill 181 294 353 181 297 353 minecraft:blue_terracotta
setblock 181 294 356 minecraft:blue_terracotta
setblock 182 294 326 minecraft:dark_prismarine
fill 182 294 327 182 294 330 minecraft:blue_terracotta
setblock 182 294 331 minecraft:dark_prismarine
fill 182 294 332 182 297 332 minecraft:blue_terracotta
setblock 182 294 336 minecraft:dark_prismarine
fill 182 294 337 182 297 337 minecraft:blue_terracotta
setblock 182 294 341 minecraft:dark_prismarine
fill 182 294 342 182 297 342 minecraft:blue_terracotta
setblock 182 294 346 minecraft:dark_prismarine
fill 182 294 347 182 297 347 minecraft:blue_terracotta
setblock 182 294 351 minecraft:dark_prismarine
fill 182 294 352 182 297 352 minecraft:blue_terracotta
setblock 182 294 356 minecraft:dark_prismarine
setblock 182 294 357 minecraft:blue_terracotta
setblock 182 294 359 minecraft:purple_concrete
fill 142 295 323 142 295 324 minecraft:blue_terracotta
setblock 142 295 325 minecraft:dark_prismarine
fill 142 295 326 142 298 326 minecraft:blue_terracotta
setblock 142 295 330 minecraft:dark_prismarine
setblock 142 295 331 minecraft:sea_lantern
setblock 142 295 333 minecraft:sea_lantern
setblock 142 295 335 minecraft:sea_lantern
fill 142 295 336 142 295 339 minecraft:blue_terracotta
setblock 142 295 340 minecraft:dark_prismarine
fill 142 295 346 142 295 349 minecraft:blue_terracotta
setblock 142 295 350 minecraft:dark_prismarine
fill 142 295 351 142 298 351 minecraft:blue_terracotta
setblock 142 295 355 minecraft:dark_prismarine
setblock 142 295 358 minecraft:purple_concrete
setblock 143 295 323 minecraft:purple_concrete
setblock 143 295 329 minecraft:dark_prismarine
setblock 143 295 330 minecraft:sea_lantern
setblock 143 295 332 minecraft:sea_lantern
setblock 143 295 334 minecraft:sea_lantern
fill 143 295 335 143 298 335 minecraft:blue_terracotta
setblock 143 295 336 minecraft:sea_lantern
fill 144 295 330 144 300 330 minecraft:dark_prismarine
setblock 144 295 331 minecraft:sea_lantern
setblock 144 295 333 minecraft:sea_lantern
setblock 144 295 335 minecraft:sea_lantern
setblock 145 295 330 minecraft:sea_lantern
setblock 145 295 332 minecraft:sea_lantern
setblock 145 295 334 minecraft:sea_lantern
setblock 145 295 336 minecraft:sea_lantern
setblock 146 295 331 minecraft:sea_lantern
setblock 146 295 333 minecraft:sea_lantern
setblock 146 295 335 minecraft:sea_lantern
setblock 147 295 330 minecraft:sea_lantern
setblock 147 295 332 minecraft:sea_lantern
setblock 147 295 334 minecraft:sea_lantern
setblock 147 295 336 minecraft:sea_lantern
fill 150 295 364 150 308 364 minecraft:blue_concrete
fill 152 295 323 153 295 323 minecraft:blue_terracotta
setblock 154 295 323 minecraft:dark_prismarine
fill 154 295 324 157 295 324 minecraft:blue_terracotta
setblock 154 295 363 minecraft:dark_prismarine
fill 155 295 323 158 295 323 minecraft:blue_terracotta
fill 155 295 363 158 295 363 minecraft:blue_terracotta
fill 157 295 362 159 295 362 minecraft:blue_terracotta
setblock 158 295 324 minecraft:dark_prismarine
setblock 159 295 323 minecraft:dark_prismarine
fill 159 295 324 159 297 324 minecraft:blue_terracotta
setblock 159 295 363 minecraft:dark_prismarine
fill 160 295 323 162 295 323 minecraft:blue_terracotta
setblock 160 295 362 minecraft:dark_prismarine
fill 160 295 363 160 298 363 minecraft:blue_terracotta
setblock 173 295 352 minecraft:sea_lantern
setblock 173 295 354 minecraft:sea_lantern
setblock 173 295 356 minecraft:sea_lantern
setblock 173 295 358 minecraft:sea_lantern
setblock 173 295 360 minecraft:sea_lantern
setblock 173 295 362 minecraft:sea_lantern
setblock 174 295 353 minecraft:sea_lantern
setblock 174 295 355 minecraft:sea_lantern
setblock 174 295 357 minecraft:sea_lantern
setblock 174 295 359 minecraft:sea_lantern
setblock 174 295 361 minecraft:sea_lantern
setblock 175 295 352 minecraft:sea_lantern
setblock 175 295 354 minecraft:sea_lantern
setblock 175 295 356 minecraft:sea_lantern
setblock 175 295 358 minecraft:sea_lantern
setblock 175 295 360 minecraft:sea_lantern
setblock 175 295 362 minecraft:sea_lantern
fill 176 295 345 176 297 345 minecraft:magenta_terracotta
setblock 176 295 353 minecraft:sea_lantern
setblock 176 295 355 minecraft:sea_lantern
setblock 176 295 357 minecraft:sea_lantern
setblock 176 295 359 minecraft:sea_lantern
setblock 176 295 361 minecraft:sea_lantern
setblock 177 295 352 minecraft:sea_lantern
setblock 177 295 354 minecraft:sea_lantern
setblock 177 295 356 minecraft:sea_lantern
setblock 177 295 358 minecraft:sea_lantern
setblock 177 295 360 minecraft:sea_lantern
setblock 177 295 362 minecraft:sea_lantern
setblock 178 295 353 minecraft:sea_lantern
setblock 178 295 355 minecraft:sea_lantern
setblock 178 295 357 minecraft:sea_lantern
setblock 178 295 359 minecraft:sea_lantern
setblock 178 295 361 minecraft:sea_lantern
setblock 179 295 352 minecraft:sea_lantern
setblock 179 295 354 minecraft:sea_lantern
setblock 179 295 356 minecraft:sea_lantern
setblock 179 295 358 minecraft:sea_lantern
setblock 179 295 360 minecraft:sea_lantern
setblock 179 295 362 minecraft:sea_lantern
fill 180 295 330 180 295 331 minecraft:blue_terracotta
setblock 180 295 332 minecraft:dark_prismarine
fill 180 295 333 180 297 334 minecraft:blue_terracotta
setblock 180 295 347 minecraft:dark_prismarine
fill 180 295 348 180 296 348 minecraft:blue_terracotta
setblock 180 295 352 minecraft:dark_prismarine
setblock 180 295 353 minecraft:sea_lantern
setblock 180 295 355 minecraft:sea_lantern
setblock 180 295 357 minecraft:sea_lantern
setblock 180 295 359 minecraft:sea_lantern
setblock 180 295 361 minecraft:sea_lantern
fill 181 295 327 181 295 330 minecraft:blue_terracotta
setblock 181 295 331 minecraft:dark_prismarine
fill 181 295 332 181 298 332 minecraft:blue_terracotta
setblock 181 295 336 minecraft:dark_prismarine
fill 181 295 337 181 297 338 minecraft:blue_terracotta
setblock 181 295 346 minecraft:dark_prismarine
fill 181 295 347 181 298 347 minecraft:blue_terracotta
setblock 181 295 351 minecraft:dark_prismarine
setblock 181 295 352 minecraft:sea_lantern
setblock 181 295 354 minecraft:sea_lantern
setblock 181 295 356 minecraft:sea_lantern
setblock 181 295 358 minecraft:sea_lantern
setblock 181 295 360 minecraft:sea_lantern
setblock 181 295 362 minecraft:sea_lantern
setblock 181 295 363 minecraft:purple_concrete
setblock 182 295 325 minecraft:dark_prismarine
fill 182 295 326 182 295 329 minecraft:blue_terracotta
setblock 182 295 330 minecraft:dark_prismarine
fill 182 295 331 182 298 331 minecraft:blue_terracotta
setblock 182 295 335 minecraft:dark_prismarine
fill 182 295 336 182 298 336 minecraft:blue_terracotta
setblock 182 295 340 minecraft:dark_prismarine
fill 182 295 341 182 298 341 minecraft:blue_terracotta
setblock 182 295 345 minecraft:dark_prismarine
fill 182 295 346 182 298 346 minecraft:blue_terracotta
setblock 182 295 350 minecraft:dark_prismarine
fill 182 295 351 182 298 351 minecraft:blue_terracotta
setblock 182 295 353 minecraft:sea_lantern
setblock 182 295 355 minecraft:sea_lantern
fill 182 295 356 182 298 356 minecraft:blue_terracotta
setblock 182 295 357 minecraft:sea_lantern
setblock 182 295 359 minecraft:sea_lantern
setblock 182 295 361 minecraft:sea_lantern
setblock 142 296 323 minecraft:blue_terracotta
setblock 142 296 324 minecraft:dark_prismarine
fill 142 296 325 142 299 325 minecraft:blue_terracotta
setblock 142 296 329 minecraft:dark_prismarine
fill 142 296 330 142 297 331 minecraft:blue_terracotta
setblock 142 296 333 minecraft:blue_terracotta
setblock 142 296 334 minecraft:dark_prismarine
fill 142 296 335 142 296 338 minecraft:blue_terracotta
setblock 142 296 339 minecraft:dark_prismarine
fill 142 296 340 142 299 340 minecraft:blue_terracotta
fill 142 296 345 142 297 345 minecraft:purple_concrete
setblock 142 296 348 minecraft:blue_terracotta
setblock 142 296 349 minecraft:dark_prismarine
fill 142 296 350 142 298 350 minecraft:blue_terracotta
setblock 142 296 354 minecraft:dark_prismarine
fill 142 296 355 142 299 355 minecraft:blue_terracotta
setblock 143 296 328 minecraft:dark_prismarine
fill 143 296 329 143 297 330 minecraft:blue_terracotta
setblock 143 296 332 minecraft:blue_terracotta
fill 143 296 333 144 296 333 minecraft:dark_prismarine
fill 143 296 334 143 297 334 minecraft:blue_terracotta
fill 143 296 336 143 297 336 minecraft:blue_terracotta
setblock 143 296 363 minecraft:purple_concrete
fill 144 296 331 144 297 331 minecraft:dark_prismarine
fill 144 296 335 144 297 335 minecraft:dark_prismarine
fill 145 296 330 145 297 330 minecraft:dark_prismarine
fill 145 296 332 145 297 332 minecraft:dark_prismarine
fill 145 296 334 145 297 334 minecraft:dark_prismarine
fill 145 296 336 145 297 336 minecraft:dark_prismarine
fill 146 296 331 146 297 331 minecraft:dark_prismarine
fill 146 296 333 146 297 333 minecraft:dark_prismarine
fill 146 296 335 146 297 335 minecraft:dark_prismarine
fill 147 296 330 147 297 330 minecraft:dark_prismarine
fill 147 296 332 147 297 332 minecraft:dark_prismarine
fill 147 296 334 147 297 334 minecraft:dark_prismarine
fill 147 296 336 147 297 336 minecraft:dark_prismarine
fill 151 296 323 152 296 323 minecraft:blue_terracotta
setblock 153 296 323 minecraft:dark_prismarine
setblock 153 296 363 minecraft:dark_prismarine
fill 154 296 323 156 296 324 minecraft:blue_terracotta
fill 154 296 363 157 296 363 minecraft:blue_terracotta
fill 156 296 362 158 296 362 minecraft:blue_terracotta
setblock 157 296 323 minecraft:blue_terracotta
setblock 157 296 324 minecraft:dark_prismarine
setblock 158 296 323 minecraft:dark_prismarine
fill 158 296 324 158 299 324 minecraft:blue_terracotta
setblock 158 296 363 minecraft:dark_prismarine
fill 159 296 323 161 297 323 minecraft:blue_terracotta
setblock 159 296 362 minecraft:dark_prismarine
fill 159 296 363 159 299 363 minecraft:blue_terracotta
fill 160 296 362 160 299 362 minecraft:blue_terracotta
fill 161 296 363 162 296 363 minecraft:blue_terracotta
fill 163 296 359 163 297 360 minecraft:black_concrete
setblock 163 296 363 minecraft:dark_prismarine
setblock 168 296 363 minecraft:purple_concrete
fill 173 296 352 173 297 352 minecraft:dark_prismarine
fill 173 296 354 173 297 354 minecraft:dark_prismarine
fill 173 296 356 173 297 356 minecraft:dark_prismarine
fill 173 296 358 173 297 358 minecraft:dark_prismarine
fill 173 296 360 173 297 360 minecraft:dark_prismarine
fill 173 296 362 173 297 362 minecraft:dark_prismarine
fill 174 296 353 174 297 353 minecraft:dark_prismarine
fill 174 296 355 174 297 355 minecraft:dark_prismarine
fill 174 296 357 174 297 357 minecraft:dark_prismarine
fill 174 296 359 174 297 359 minecraft:dark_prismarine
fill 174 296 361 174 297 361 minecraft:dark_prismarine
fill 175 296 352 175 297 352 minecraft:dark_prismarine
fill 175 296 354 175 297 354 minecraft:dark_prismarine
fill 175 296 356 175 297 356 minecraft:dark_prismarine
fill 175 296 358 175 297 358 minecraft:dark_prismarine
fill 175 296 360 175 297 360 minecraft:dark_prismarine
fill 175 296 362 175 297 362 minecraft:dark_prismarine
fill 176 296 353 176 297 353 minecraft:dark_prismarine
fill 176 296 355 176 297 355 minecraft:dark_prismarine
fill 176 296 357 176 297 357 minecraft:dark_prismarine
fill 176 296 359 176 297 359 minecraft:dark_prismarine
fill 176 296 361 176 297 361 minecraft:dark_prismarine
fill 177 296 352 177 297 352 minecraft:dark_prismarine
fill 177 296 354 177 297 354 minecraft:dark_prismarine
fill 177 296 356 177 297 356 minecraft:dark_prismarine
fill 177 296 358 177 297 358 minecraft:dark_prismarine
fill 177 296 360 177 297 360 minecraft:dark_prismarine
fill 177 296 362 177 297 362 minecraft:dark_prismarine
fill 178 296 353 178 297 353 minecraft:dark_prismarine
fill 178 296 355 178 297 355 minecraft:dark_prismarine
fill 178 296 357 178 297 357 minecraft:dark_prismarine
fill 178 296 359 178 297 359 minecraft:dark_prismarine
fill 178 296 361 178 297 361 minecraft:dark_prismarine
fill 179 296 352 179 297 352 minecraft:dark_prismarine
fill 179 296 354 179 297 354 minecraft:dark_prismarine
fill 179 296 356 179 297 356 minecraft:dark_prismarine
fill 179 296 358 179 297 358 minecraft:dark_prismarine
fill 179 296 360 179 297 360 minecraft:dark_prismarine
fill 179 296 362 179 297 362 minecraft:dark_prismarine
setblock 180 296 330 minecraft:blue_terracotta
setblock 180 296 331 minecraft:dark_prismarine
fill 180 296 332 180 299 332 minecraft:blue_terracotta
setblock 180 296 335 minecraft:blue_terracotta
setblock 180 296 336 minecraft:dark_prismarine
setblock 180 296 351 minecraft:dark_prismarine
fill 180 296 352 180 297 353 minecraft:blue_terracotta
fill 180 296 355 181 296 355 minecraft:dark_prismarine
fill 180 296 357 180 297 357 minecraft:dark_prismarine
fill 180 296 359 180 297 359 minecraft:dark_prismarine
fill 180 296 361 180 297 361 minecraft:dark_prismarine
setblock 181 296 323 minecraft:purple_concrete
fill 181 296 328 181 296 329 minecraft:blue_terracotta
setblock 181 296 330 minecraft:dark_prismarine
fill 181 296 331 181 299 331 minecraft:blue_terracotta
setblock 181 296 335 minecraft:dark_prismarine
fill 181 296 336 181 299 336 minecraft:blue_terracotta
setblock 181 296 339 minecraft:blue_terracotta
setblock 181 296 340 minecraft:dark_prismarine
setblock 181 296 345 minecraft:dark_prismarine
fill 181 296 346 181 298 346 minecraft:blue_terracotta
setblock 181 296 350 minecraft:dark_prismarine
fill 181 296 351 181 297 352 minecraft:blue_terracotta
setblock 181 296 354 minecraft:blue_terracotta
fill 181 296 356 181 297 356 minecraft:blue_terracotta
fill 181 296 358 181 297 358 minecraft:dark_prismarine
fill 181 296 360 181 297 360 minecraft:dark_prismarine
fill 181 296 362 181 297 362 minecraft:dark_prismarine
fill 182 296 326 182 296 328 minecraft:blue_terracotta
setblock 182 296 329 minecraft:dark_prismarine
fill 182 296 330 182 299 330 minecraft:blue_terracotta
setblock 182 296 334 minecraft:dark_prismarine
fill 182 296 335 182 299 335 minecraft:blue_terracotta
setblock 182 296 339 minecraft:dark_prismarine
fill 182 296 340 182 299 340 minecraft:blue_terracotta
setblock 182 296 344 minecraft:dark_prismarine
fill 182 296 345 182 299 345 minecraft:blue_terracotta
setblock 182 296 349 minecraft:dark_prismarine
fill 182 296 350 182 299 350 minecraft:blue_terracotta
setblock 182 296 353 minecraft:blue_terracotta
setblock 182 296 354 minecraft:dark_prismarine
fill 182 296 355 182 297 355 minecraft:blue_terracotta
fill 182 296 357 182 297 357 minecraft:blue_terracotta
fill 182 296 359 182 297 359 minecraft:dark_prismarine
fill 182 296 361 182 297 361 minecraft:dark_prismarine
setblock 142 297 323 minecraft:dark_prismarine
fill 142 297 324 142 300 324 minecraft:blue_terracotta
setblock 142 297 328 minecraft:dark_prismarine
fill 142 297 329 142 300 329 minecraft:blue_terracotta
setblock 142 297 333 minecraft:dark_prismarine
fill 142 297 334 142 297 337 minecraft:blue_terracotta
setblock 142 297 338 minecraft:dark_prismarine
fill 142 297 339 142 300 339 minecraft:blue_terracotta
setblock 142 297 349 minecraft:blue_terracotta
setblock 142 297 353 minecraft:dark_prismarine
fill 142 297 354 142 300 354 minecraft:blue_terracotta
fill 142 297 356 142 298 356 minecraft:blue_terracotta
setblock 143 297 327 minecraft:dark_prismarine
fill 143 297 328 143 300 328 minecraft:blue_terracotta
setblock 143 297 332 minecraft:dark_prismarine
fill 143 297 333 143 300 333 minecraft:blue_terracotta
setblock 144 297 333 minecraft:dark_prismarine
setblock 147 297 341 minecraft:magenta_terracotta
setblock 149 297 363 minecraft:purple_concrete
fill 150 297 323 151 297 323 minecraft:blue_terracotta
fill 151 297 354 151 297 358 minecraft:purple_concrete
setblock 152 297 323 minecraft:dark_prismarine
fill 152 297 354 161 297 354 minecraft:purple_concrete
fill 152 297 358 154 297 359 minecraft:purple_concrete
setblock 152 297 363 minecraft:dark_prismarine
fill 153 297 323 155 297 324 minecraft:blue_terracotta
setblock 153 297 353 minecraft:purple_concrete
fill 153 297 363 156 297 363 minecraft:blue_terracotta
fill 154 297 362 157 297 362 minecraft:blue_terracotta
fill 155 297 355 156 299 356 minecraft:purple_concrete
setblock 156 297 323 minecraft:blue_terracotta
setblock 156 297 324 minecraft:dark_prismarine
fill 156 297 357 156 297 359 minecraft:purple_concrete
setblock 157 297 323 minecraft:dark_prismarine
fill 157 297 324 157 300 324 minecraft:blue_terracotta
fill 157 297 353 160 297 353 minecraft:purple_concrete
fill 157 297 358 157 298 359 minecraft:purple_concrete
setblock 157 297 363 minecraft:dark_prismarine
fill 158 297 323 158 300 323 minecraft:blue_terracotta
fill 158 297 359 159 297 360 minecraft:purple_concrete
setblock 158 297 362 minecraft:dark_prismarine
fill 158 297 363 158 300 363 minecraft:blue_terracotta
fill 159 297 362 159 300 362 minecraft:blue_terracotta
fill 160 297 355 161 298 355 minecraft:purple_concrete
fill 160 297 358 160 297 359 minecraft:purple_concrete
fill 161 297 356 161 297 358 minecraft:purple_concrete
fill 161 297 362 161 297 363 minecraft:blue_terracotta
setblock 162 297 363 minecraft:dark_prismarine
fill 163 297 363 163 300 363 minecraft:blue_terracotta
setblock 174 297 363 minecraft:purple_concrete
setblock 175 297 323 minecraft:purple_concrete
setblock 180 297 330 minecraft:dark_prismarine
fill 180 297 331 180 300 331 minecraft:blue_terracotta
setblock 180 297 335 minecraft:dark_prismarine
fill 180 297 336 180 299 337 minecraft:blue_terracotta
setblock 180 297 350 minecraft:dark_prismarine
fill 180 297 351 180 299 351 minecraft:blue_terracotta
setblock 180 297 355 minecraft:dark_prismarine
setblock 181 297 328 minecraft:blue_terracotta
setblock 181 297 329 minecraft:dark_prismarine
fill 181 297 330 181 300 330 minecraft:blue_terracotta
setblock 181 297 334 minecraft:dark_prismarine
fill 181 297 335 181 300 335 minecraft:blue_terracotta
setblock 181 297 339 minecraft:dark_prismarine
fill 181 297 340 181 299 341 minecraft:blue_terracotta
setblock 181 297 345 minecraft:blue_terracotta
setblock 181 297 349 minecraft:dark_prismarine
fill 181 297 350 181 300 350 minecraft:blue_terracotta
setblock 181 297 354 minecraft:dark_prismarine
fill 181 297 355 181 300 355 minecraft:blue_terracotta
fill 182 297 326 182 297 327 minecraft:blue_terracotta
setblock 182 297 328 minecraft:dark_prismarine
fill 182 297 329 182 300 329 minecraft:blue_terracotta
setblock 182 297 333 minecraft:dark_prismarine
fill 182 297 334 182 300 334 minecraft:blue_terracotta
setblock 182 297 338 minecraft:dark_prismarine
fill 182 297 339 182 300 339 minecraft:blue_terracotta
setblock 182 297 343 minecraft:dark_prismarine
fill 182 297 344 182 300 344 minecraft:blue_terracotta
setblock 182 297 348 minecraft:dark_prismarine
fill 182 297 349 182 300 349 minecraft:blue_terracotta
setblock 182 297 353 minecraft:dark_prismarine
fill 182 297 354 182 300 354 minecraft:blue_terracotta
setblock 182 297 360 minecraft:purple_concrete
fill 183 297 328 183 308 328 minecraft:blue_concrete
setblock 183 297 329 minecraft:cyan_concrete
fill 141 298 351 141 308 351 minecraft:blue_concrete
setblock 141 298 352 minecraft:light_blue_wool
fill 142 298 323 142 300 323 minecraft:blue_terracotta
setblock 142 298 327 minecraft:dark_prismarine
fill 142 298 328 142 300 328 minecraft:blue_terracotta
fill 142 298 330 142 299 330 minecraft:blue_terracotta
setblock 142 298 331 minecraft:sea_lantern
setblock 142 298 332 minecraft:dark_prismarine
setblock 142 298 333 minecraft:sea_lantern
fill 142 298 334 142 300 334 minecraft:blue_terracotta
setblock 142 298 335 minecraft:sea_lantern
setblock 142 298 336 minecraft:blue_terracotta
setblock 142 298 337 minecraft:dark_prismarine
fill 142 298 338 142 300 338 minecraft:blue_terracotta
setblock 142 298 352 minecraft:dark_prismarine
fill 142 298 353 142 300 353 minecraft:blue_terracotta
setblock 142 298 357 minecraft:dark_prismarine
fill 143 298 327 143 299 327 minecraft:blue_terracotta
fill 143 298 329 143 299 329 minecraft:blue_terracotta
setblock 143 298 330 minecraft:sea_lantern
setblock 143 298 331 minecraft:dark_prismarine
setblock 143 298 332 minecraft:sea_lantern
setblock 143 298 334 minecraft:sea_lantern
setblock 143 298 336 minecraft:sea_lantern
fill 143 298 337 143 300 337 minecraft:blue_terracotta
setblock 144 298 323 minecraft:purple_concrete
setblock 144 298 331 minecraft:sea_lantern
fill 144 298 332 144 299 332 minecraft:blue_terracotta
setblock 144 298 333 minecraft:sea_lantern
setblock 144 298 335 minecraft:sea_lantern
setblock 145 298 330 minecraft:sea_lantern
setblock 145 298 332 minecraft:sea_lantern
setblock 145 298 334 minecraft:sea_lantern
setblock 145 298 336 minecraft:sea_lantern
setblock 146 298 331 minecraft:sea_lantern
setblock 146 298 333 minecraft:sea_lantern
setblock 146 298 335 minecraft:sea_lantern
setblock 147 298 330 minecraft:sea_lantern
setblock 147 298 332 minecraft:sea_lantern
setblock 147 298 334 minecraft:sea_lantern
setblock 147 298 336 minecraft:sea_lantern
fill 149 298 323 150 298 323 minecraft:blue_terracotta
setblock 151 298 323 minecraft:dark_prismarine
fill 151 298 355 151 298 357 minecraft:purple_concrete
setblock 151 298 363 minecraft:dark_prismarine
fill 152 298 323 154 298 324 minecraft:blue_terracotta
fill 152 298 354 154 298 354 minecraft:purple_concrete
fill 152 298 358 154 298 358 minecraft:purple_concrete
fill 152 298 363 155 298 363 minecraft:blue_terracotta
fill 153 298 362 156 298 362 minecraft:blue_terracotta
setblock 155 298 323 minecraft:blue_terracotta
setblock 155 298 324 minecraft:dark_prismarine
fill 155 298 361 157 298 361 minecraft:blue_terracotta
setblock 156 298 323 minecraft:dark_prismarine
fill 156 298 324 156 300 324 minecraft:blue_terracotta
fill 156 298 354 160 298 354 minecraft:purple_concrete
fill 156 298 357 156 298 358 minecraft:purple_concrete
setblock 156 298 363 minecraft:dark_prismarine
fill 157 298 323 157 300 323 minecraft:blue_terracotta
setblock 157 298 362 minecraft:dark_prismarine
fill 157 298 363 157 300 363 minecraft:blue_terracotta
fill 158 298 359 159 298 359 minecraft:purple_concrete
setblock 158 298 361 minecraft:dark_prismarine
fill 158 298 362 158 300 362 minecraft:blue_terracotta
fill 159 298 323 160 298 323 minecraft:blue_terracotta
fill 159 298 361 159 300 361 minecraft:blue_terracotta
fill 160 298 358 160 299 358 minecraft:purple_concrete
setblock 161 298 323 minecraft:dark_prismarine
fill 161 298 356 161 298 357 minecraft:purple_concrete
setblock 161 298 362 minecraft:blue_terracotta
setblock 161 298 363 minecraft:dark_prismarine
fill 162 298 363 162 300 363 minecraft:blue_terracotta
fill 163 298 322 165 308 322 minecraft:blue_concrete
setblock 166 298 322 minecraft:cyan_concrete
fill 167 298 322 167 308 322 minecraft:blue_concrete
setblock 169 298 323 minecraft:purple_concrete
setblock 173 298 352 minecraft:sea_lantern
setblock 173 298 354 minecraft:sea_lantern
setblock 173 298 356 minecraft:sea_lantern
setblock 173 298 358 minecraft:sea_lantern
setblock 173 298 360 minecraft:sea_lantern
setblock 173 298 362 minecraft:sea_lantern
setblock 174 298 353 minecraft:sea_lantern
setblock 174 298 355 minecraft:sea_lantern
setblock 174 298 357 minecraft:sea_lantern
setblock 174 298 359 minecraft:sea_lantern
setblock 174 298 361 minecraft:sea_lantern
fill 174 298 363 175 298 363 minecraft:blue_terracotta
setblock 175 298 352 minecraft:sea_lantern
setblock 175 298 354 minecraft:sea_lantern
setblock 175 298 356 minecraft:sea_lantern
setblock 175 298 358 minecraft:sea_lantern
setblock 175 298 360 minecraft:sea_lantern
setblock 175 298 362 minecraft:sea_lantern
setblock 176 298 353 minecraft:sea_lantern
setblock 176 298 355 minecraft:sea_lantern
setblock 176 298 357 minecraft:sea_lantern
setblock 176 298 359 minecraft:sea_lantern
setblock 176 298 361 minecraft:sea_lantern
setblock 176 298 363 minecraft:dark_prismarine
setblock 177 298 352 minecraft:sea_lantern
setblock 177 298 354 minecraft:sea_lantern
setblock 177 298 356 minecraft:sea_lantern
setblock 177 298 358 minecraft:sea_lantern
setblock 177 298 360 minecraft:sea_lantern
setblock 177 298 362 minecraft:sea_lantern
fill 177 298 363 177 300 363 minecraft:blue_terracotta
setblock 178 298 353 minecraft:sea_lantern
setblock 178 298 355 minecraft:sea_lantern
setblock 178 298 357 minecraft:sea_lantern
setblock 178 298 359 minecraft:sea_lantern
setblock 178 298 361 minecraft:sea_lantern
fill 179 298 333 179 298 334 minecraft:blue_terracotta
setblock 179 298 335 minecraft:dark_prismarine
setblock 179 298 352 minecraft:sea_lantern
setblock 179 298 354 minecraft:sea_lantern
setblock 179 298 356 minecraft:sea_lantern
setblock 179 298 358 minecraft:sea_lantern
setblock 179 298 360 minecraft:sea_lantern
setblock 179 298 362 minecraft:sea_lantern
fill 180 298 330 180 300 330 minecraft:blue_terracotta
setblock 180 298 333 minecraft:blue_terracotta
setblock 180 298 334 minecraft:dark_prismarine
fill 180 298 335 180 300 335 minecraft:blue_terracotta
setblock 180 298 338 minecraft:blue_terracotta
setblock 180 298 339 minecraft:dark_prismarine
setblock 180 298 350 minecraft:blue_terracotta
fill 180 298 352 180 299 352 minecraft:blue_terracotta
setblock 180 298 353 minecraft:sea_lantern
setblock 180 298 354 minecraft:dark_prismarine
setblock 180 298 355 minecraft:sea_lantern
setblock 180 298 357 minecraft:sea_lantern
setblock 180 298 359 minecraft:sea_lantern
setblock 180 298 361 minecraft:sea_lantern
setblock 180 298 363 minecraft:purple_concrete
setblock 181 298 328 minecraft:dark_prismarine
fill 181 298 329 181 300 329 minecraft:blue_terracotta
setblock 181 298 333 minecraft:dark_prismarine
fill 181 298 334 181 300 334 minecraft:blue_terracotta
setblock 181 298 337 minecraft:blue_terracotta
setblock 181 298 338 minecraft:dark_prismarine
fill 181 298 339 181 300 339 minecraft:blue_terracotta
setblock 181 298 342 minecraft:blue_terracotta
setblock 181 298 348 minecraft:dark_prismarine
fill 181 298 349 181 299 349 minecraft:blue_terracotta
fill 181 298 351 181 299 351 minecraft:blue_terracotta
setblock 181 298 352 minecraft:sea_lantern
setblock 181 298 353 minecraft:dark_prismarine
setblock 181 298 354 minecraft:sea_lantern
setblock 181 298 356 minecraft:sea_lantern
setblock 181 298 357 minecraft:blue_terracotta
setblock 181 298 358 minecraft:sea_lantern
setblock 181 298 360 minecraft:sea_lantern
setblock 181 298 362 minecraft:sea_lantern
setblock 182 298 326 minecraft:blue_terracotta
setblock 182 298 327 minecraft:dark_prismarine
fill 182 298 328 182 300 328 minecraft:blue_terracotta
setblock 182 298 332 minecraft:dark_prismarine
fill 182 298 333 182 300 333 minecraft:blue_terracotta
setblock 182 298 337 minecraft:dark_prismarine
fill 182 298 338 182 300 338 minecraft:blue_terracotta
setblock 182 298 342 minecraft:dark_prismarine
fill 182 298 343 182 300 343 minecraft:blue_terracotta
setblock 182 298 347 minecraft:dark_prismarine
fill 182 298 348 182 300 348 minecraft:blue_terracotta
setblock 182 298 352 minecraft:dark_prismarine
setblock 182 298 353 minecraft:sea_lantern
setblock 182 298 355 minecraft:sea_lantern
setblock 182 298 357 minecraft:sea_lantern
fill 182 298 358 182 300 358 minecraft:blue_terracotta
setblock 182 298 359 minecraft:sea_lantern
fill 182 298 360 182 300 360 minecraft:dark_prismarine
setblock 182 298 361 minecraft:sea_lantern
fill 183 298 329 183 308 329 minecraft:blue_concrete
fill 141 299 322 141 308 322 minecraft:blue_concrete
setblock 141 299 323 minecraft:cyan_concrete
fill 141 299 352 141 308 352 minecraft:blue_concrete
setblock 141 299 354 minecraft:light_blue_wool
setblock 142 299 326 minecraft:dark_prismarine
fill 142 299 327 142 300 327 minecraft:blue_terracotta
setblock 142 299 331 minecraft:dark_prismarine
fill 142 299 332 142 300 333 minecraft:blue_terracotta
setblock 142 299 335 minecraft:blue_terracotta
setblock 142 299 336 minecraft:dark_prismarine
fill 142 299 337 142 300 337 minecraft:blue_terracotta
setblock 142 299 352 minecraft:blue_terracotta
setblock 142 299 356 minecraft:dark_prismarine
fill 142 299 357 142 300 359 minecraft:blue_terracotta
setblock 142 299 363 minecraft:purple_concrete
setblock 143 299 330 minecraft:dark_prismarine
fill 143 299 331 143 300 332 minecraft:blue_terracotta
setblock 143 299 334 minecraft:blue_terracotta
fill 143 299 335 144 299 335 minecraft:dark_prismarine
fill 143 299 336 143 300 336 minecraft:blue_terracotta
setblock 144 299 325 minecraft:light[level=12]
fill 144 299 331 144 300 331 minecraft:dark_prismarine
fill 144 299 333 144 300 333 minecraft:dark_prismarine
setblock 144 299 339 minecraft:light[level=12]
setblock 144 299 346 minecraft:light[level=12]
setblock 144 299 353 minecraft:light[level=12]
setblock 144 299 360 minecraft:light[level=12]
fill 145 299 330 145 300 330 minecraft:dark_prismarine
fill 145 299 332 145 300 332 minecraft:dark_prismarine
fill 145 299 334 145 300 334 minecraft:dark_prismarine
fill 145 299 336 145 300 336 minecraft:dark_prismarine
fill 146 299 331 146 300 331 minecraft:dark_prismarine
fill 146 299 333 146 300 333 minecraft:dark_prismarine
fill 146 299 335 146 300 335 minecraft:dark_prismarine
fill 147 299 330 147 300 330 minecraft:dark_prismarine
fill 147 299 332 147 300 332 minecraft:dark_prismarine
fill 147 299 334 147 300 334 minecraft:dark_prismarine
fill 147 299 336 147 300 336 minecraft:dark_prismarine
fill 148 299 323 149 299 323 minecraft:blue_terracotta
setblock 149 299 363 minecraft:blue_terracotta
setblock 150 299 323 minecraft:dark_prismarine
setblock 150 299 363 minecraft:dark_prismarine
fill 151 299 323 153 299 324 minecraft:blue_terracotta
setblock 151 299 325 minecraft:light[level=12]
setblock 151 299 332 minecraft:light[level=12]
setblock 151 299 339 minecraft:light[level=12]
setblock 151 299 346 minecraft:light[level=12]
setblock 151 299 353 minecraft:light[level=12]
setblock 151 299 360 minecraft:light[level=12]
setblock 151 299 362 minecraft:dark_prismarine
fill 151 299 363 154 299 363 minecraft:blue_terracotta
fill 152 299 362 155 299 362 minecraft:blue_terracotta
setblock 153 299 354 minecraft:purple_concrete
fill 153 299 358 154 299 358 minecraft:purple_concrete
fill 153 299 361 156 299 361 minecraft:blue_terracotta
setblock 154 299 323 minecraft:blue_terracotta
setblock 154 299 324 minecraft:dark_prismarine
setblock 155 299 323 minecraft:dark_prismarine
fill 155 299 324 155 300 324 minecraft:blue_terracotta
fill 155 299 357 156 299 357 minecraft:purple_concrete
setblock 155 299 363 minecraft:dark_prismarine
fill 156 299 323 156 300 323 minecraft:blue_terracotta
fill 156 299 360 157 299 360 minecraft:blue_terracotta
setblock 156 299 362 minecraft:dark_prismarine
fill 156 299 363 156 300 363 minecraft:blue_terracotta
fill 157 299 354 159 299 354 minecraft:purple_concrete
setblock 157 299 358 minecraft:purple_concrete
setblock 157 299 361 minecraft:dark_prismarine
fill 157 299 362 157 300 362 minecraft:blue_terracotta
setblock 158 299 325 minecraft:light[level=12]
setblock 158 299 332 minecraft:light[level=12]
setblock 158 299 339 minecraft:light[level=12]
setblock 158 299 346 minecraft:light[level=12]
setblock 158 299 353 minecraft:light[level=12]
setblock 158 299 360 minecraft:light[level=12]
fill 158 299 361 158 300 361 minecraft:blue_terracotta
setblock 159 299 323 minecraft:blue_terracotta
setblock 160 299 323 minecraft:dark_prismarine
setblock 160 299 355 minecraft:purple_concrete
fill 160 299 361 160 300 361 minecraft:blue_terracotta
setblock 160 299 363 minecraft:dark_prismarine
setblock 161 299 362 minecraft:dark_prismarine
fill 161 299 363 161 300 363 minecraft:blue_terracotta
fill 162 299 362 162 300 362 minecraft:blue_terracotta
setblock 163 299 323 minecraft:purple_concrete
setblock 164 299 363 minecraft:blue_terracotta
setblock 165 299 325 minecraft:light[level=12]
setblock 165 299 332 minecraft:light[level=12]
setblock 165 299 339 minecraft:light[level=12]
setblock 165 299 346 minecraft:light[level=12]
setblock 165 299 353 minecraft:light[level=12]
setblock 165 299 360 minecraft:light[level=12]
fill 166 299 322 166 300 322 minecraft:blue_concrete
setblock 172 299 325 minecraft:light[level=12]
setblock 172 299 332 minecraft:light[level=12]
setblock 172 299 339 minecraft:light[level=12]
setblock 172 299 346 minecraft:light[level=12]
setblock 172 299 353 minecraft:light[level=12]
setblock 172 299 360 minecraft:light[level=12]
fill 172 299 363 174 299 363 minecraft:blue_terracotta
fill 173 299 352 173 300 352 minecraft:dark_prismarine
fill 173 299 354 173 300 354 minecraft:dark_prismarine
fill 173 299 356 173 300 356 minecraft:dark_prismarine
fill 173 299 358 173 300 358 minecraft:dark_prismarine
fill 173 299 360 173 300 360 minecraft:dark_prismarine
setblock 173 299 362 minecraft:dark_prismarine
fill 174 299 353 174 300 353 minecraft:dark_prismarine
fill 174 299 355 174 300 355 minecraft:dark_prismarine
fill 174 299 357 174 300 357 minecraft:dark_prismarine
fill 174 299 359 174 300 359 minecraft:dark_prismarine
fill 174 299 361 174 300 361 minecraft:dark_prismarine
fill 175 299 352 175 300 352 minecraft:dark_prismarine
fill 175 299 354 175 300 354 minecraft:dark_prismarine
fill 175 299 356 175 300 356 minecraft:dark_prismarine
fill 175 299 358 175 300 358 minecraft:dark_prismarine
fill 175 299 360 175 300 360 minecraft:dark_prismarine
fill 175 299 362 175 299 363 minecraft:dark_prismarine
fill 176 299 353 176 300 353 minecraft:dark_prismarine
fill 176 299 355 176 300 355 minecraft:dark_prismarine
fill 176 299 357 176 300 357 minecraft:dark_prismarine
fill 176 299 359 176 300 359 minecraft:dark_prismarine
fill 176 299 361 176 300 361 minecraft:dark_prismarine
fill 176 299 363 176 300 363 minecraft:blue_terracotta
fill 177 299 352 177 300 352 minecraft:dark_prismarine
fill 177 299 354 177 300 354 minecraft:dark_prismarine
fill 177 299 356 177 300 356 minecraft:dark_prismarine
fill 177 299 358 177 300 358 minecraft:dark_prismarine
fill 177 299 360 177 300 360 minecraft:dark_prismarine
fill 177 299 362 177 300 362 minecraft:dark_prismarine
fill 178 299 353 178 300 353 minecraft:dark_prismarine
fill 178 299 355 178 300 355 minecraft:dark_prismarine
fill 178 299 357 178 300 357 minecraft:dark_prismarine
fill 178 299 359 178 300 359 minecraft:dark_prismarine
fill 178 299 361 178 300 361 minecraft:dark_prismarine
fill 178 299 363 178 300 363 minecraft:blue_terracotta
setblock 179 299 325 minecraft:light[level=12]
fill 179 299 332 179 299 333 minecraft:blue_terracotta
setblock 179 299 334 minecraft:dark_prismarine
fill 179 299 335 179 300 337 minecraft:blue_terracotta
setblock 179 299 339 minecraft:light[level=12]
setblock 179 299 346 minecraft:light[level=12]
fill 179 299 352 179 300 352 minecraft:dark_prismarine
fill 179 299 354 179 300 354 minecraft:dark_prismarine
fill 179 299 356 179 300 356 minecraft:dark_prismarine
fill 179 299 358 179 300 358 minecraft:dark_prismarine
fill 179 299 360 179 300 360 minecraft:dark_prismarine
fill 179 299 362 179 300 362 minecraft:dark_prismarine
setblock 180 299 333 minecraft:dark_prismarine
fill 180 299 334 180 300 334 minecraft:blue_terracotta
setblock 180 299 338 minecraft:dark_prismarine
fill 180 299 339 180 300 340 minecraft:blue_terracotta
fill 180 299 353 180 300 353 minecraft:dark_prismarine
fill 180 299 354 180 299 355 minecraft:blue_terracotta
fill 180 299 357 181 299 357 minecraft:dark_prismarine
fill 180 299 359 180 300 359 minecraft:dark_prismarine
fill 180 299 361 180 300 361 minecraft:dark_prismarine
fill 181 299 328 181 300 328 minecraft:blue_terracotta
setblock 181 299 332 minecraft:dark_prismarine
fill 181 299 333 181 300 333 minecraft:blue_terracotta
setblock 181 299 337 minecraft:dark_prismarine
fill 181 299 338 181 300 338 minecraft:blue_terracotta
setblock 181 299 342 minecraft:dark_prismarine
setblock 181 299 348 minecraft:blue_terracotta
setblock 181 299 352 minecraft:dark_prismarine
fill 181 299 353 181 300 354 minecraft:blue_terracotta
setblock 181 299 356 minecraft:blue_terracotta
fill 181 299 358 181 300 358 minecraft:dark_prismarine
fill 181 299 360 181 300 360 minecraft:dark_prismarine
fill 181 299 362 181 300 362 minecraft:dark_prismarine
setblock 182 299 323 minecraft:purple_concrete
setblock 182 299 326 minecraft:dark_prismarine
fill 182 299 327 182 300 327 minecraft:blue_terracotta
setblock 182 299 331 minecraft:dark_prismarine
fill 182 299 332 182 300 332 minecraft:blue_terracotta
setblock 182 299 336 minecraft:dark_prismarine
fill 182 299 337 182 300 337 minecraft:blue_terracotta
setblock 182 299 341 minecraft:dark_prismarine
fill 182 299 342 182 300 342 minecraft:blue_terracotta
setblock 182 299 346 minecraft:dark_prismarine
fill 182 299 347 182 300 347 minecraft:blue_terracotta
setblock 182 299 351 minecraft:dark_prismarine
fill 182 299 352 182 300 353 minecraft:blue_terracotta
setblock 182 299 355 minecraft:blue_terracotta
setblock 182 299 356 minecraft:dark_prismarine
fill 182 299 357 182 300 357 minecraft:blue_terracotta
fill 182 299 359 182 300 359 minecraft:blue_terracotta
setblock 182 299 361 minecraft:dark_prismarine
setblock 183 299 358 minecraft:cyan_concrete
fill 183 299 359 183 308 359 minecraft:blue_concrete
fill 141 300 323 141 308 323 minecraft:blue_concrete
fill 141 300 354 141 308 354 minecraft:blue_concrete
setblock 142 300 325 minecraft:dark_prismarine
setblock 142 300 326 minecraft:blue_terracotta
setblock 142 300 330 minecraft:dark_prismarine
setblock 142 300 331 minecraft:blue_terracotta
setblock 142 300 335 minecraft:dark_prismarine
setblock 142 300 336 minecraft:blue_terracotta
setblock 142 300 340 minecraft:dark_prismarine
setblock 142 300 341 minecraft:blue_terracotta
setblock 142 300 344 minecraft:purple_concrete
setblock 142 300 355 minecraft:dark_prismarine
setblock 142 300 356 minecraft:blue_terracotta
setblock 142 300 360 minecraft:dark_prismarine
setblock 143 300 329 minecraft:dark_prismarine
setblock 143 300 330 minecraft:blue_terracotta
setblock 143 300 334 minecraft:dark_prismarine
setblock 143 300 335 minecraft:blue_terracotta
setblock 143 300 338 minecraft:blue_terracotta
setblock 144 300 332 minecraft:dark_prismarine
setblock 144 300 335 minecraft:dark_prismarine
fill 147 300 323 148 300 323 minecraft:blue_terracotta
fill 148 300 334 154 300 335 minecraft:dark_prismarine
setblock 148 300 363 minecraft:blue_terracotta
setblock 149 300 323 minecraft:dark_prismarine
setblock 149 300 363 minecraft:dark_prismarine
fill 150 300 323 153 300 323 minecraft:blue_terracotta
setblock 150 300 362 minecraft:dark_prismarine
fill 150 300 363 153 300 363 minecraft:blue_terracotta
fill 151 300 324 152 300 324 minecraft:blue_terracotta
fill 151 300 362 154 300 362 minecraft:blue_terracotta
setblock 151 300 364 minecraft:cyan_concrete
fill 152 300 361 155 300 361 minecraft:blue_terracotta
setblock 153 300 324 minecraft:dark_prismarine
setblock 154 300 323 minecraft:dark_prismarine
setblock 154 300 324 minecraft:blue_terracotta
fill 154 300 360 156 300 360 minecraft:blue_terracotta
setblock 154 300 363 minecraft:dark_prismarine
setblock 155 300 323 minecraft:blue_terracotta
fill 155 300 334 161 300 334 minecraft:dark_prismarine
setblock 155 300 362 minecraft:dark_prismarine
setblock 155 300 363 minecraft:blue_terracotta
setblock 156 300 361 minecraft:dark_prismarine
setblock 156 300 362 minecraft:blue_terracotta
setblock 157 300 360 minecraft:dark_prismarine
setblock 157 300 361 minecraft:blue_terracotta
setblock 158 300 360 minecraft:blue_terracotta
setblock 159 300 323 minecraft:dark_prismarine
setblock 159 300 363 minecraft:dark_prismarine
setblock 160 300 323 minecraft:blue_terracotta
setblock 160 300 362 minecraft:dark_prismarine
setblock 160 300 363 minecraft:blue_terracotta
setblock 161 300 362 minecraft:blue_terracotta
setblock 164 300 363 minecraft:dark_prismarine
setblock 167 300 363 minecraft:purple_concrete
fill 170 300 363 173 300 363 minecraft:blue_terracotta
fill 173 300 362 174 300 362 minecraft:blue_terracotta
setblock 174 300 363 minecraft:dark_prismarine
fill 175 300 323 177 300 323 minecraft:blue_terracotta
setblock 175 300 362 minecraft:dark_prismarine
setblock 175 300 363 minecraft:blue_terracotta
setblock 176 300 362 minecraft:blue_terracotta
setblock 179 300 332 minecraft:blue_terracotta
setblock 179 300 333 minecraft:dark_prismarine
setblock 179 300 334 minecraft:blue_terracotta
setblock 179 300 338 minecraft:dark_prismarine
setblock 180 300 332 minecraft:dark_prismarine
setblock 180 300 333 minecraft:blue_terracotta
setblock 180 300 336 minecraft:blue_terracotta
setblock 180 300 337 minecraft:dark_prismarine
setblock 180 300 338 minecraft:blue_terracotta
setblock 180 300 352 minecraft:dark_prismarine
setblock 180 300 354 minecraft:blue_terracotta
setblock 180 300 355 minecraft:dark_prismarine
setblock 180 300 357 minecraft:dark_prismarine
setblock 181 300 331 minecraft:dark_prismarine
setblock 181 300 332 minecraft:blue_terracotta
setblock 181 300 336 minecraft:dark_prismarine
setblock 181 300 337 minecraft:blue_terracotta
setblock 181 300 340 minecraft:blue_terracotta
setblock 181 300 341 minecraft:dark_prismarine
setblock 181 300 342 minecraft:blue_terracotta
setblock 181 300 351 minecraft:dark_prismarine
setblock 181 300 352 minecraft:blue_terracotta
setblock 181 300 356 minecraft:dark_prismarine
setblock 181 300 357 minecraft:blue_terracotta
setblock 182 300 330 minecraft:dark_prismarine
setblock 182 300 331 minecraft:blue_terracotta
setblock 182 300 335 minecraft:dark_prismarine
setblock 182 300 336 minecraft:blue_terracotta
setblock 182 300 340 minecraft:dark_prismarine
setblock 182 300 341 minecraft:blue_terracotta
setblock 182 300 345 minecraft:dark_prismarine
setblock 182 300 346 minecraft:blue_terracotta
setblock 182 300 350 minecraft:dark_prismarine
setblock 182 300 351 minecraft:blue_terracotta
setblock 182 300 355 minecraft:dark_prismarine
setblock 182 300 356 minecraft:blue_terracotta
setblock 182 300 361 minecraft:purple_concrete
setblock 183 300 352 minecraft:light_blue_wool
fill 183 300 358 183 308 358 minecraft:blue_concrete
setblock 144 301 325 minecraft:light[level=13]
setblock 144 301 333 minecraft:light[level=13]
setblock 144 301 341 minecraft:light[level=13]
setblock 144 301 349 minecraft:light[level=13]
setblock 144 301 357 minecraft:light[level=13]
fill 151 301 364 151 308 364 minecraft:blue_concrete
setblock 152 301 325 minecraft:light[level=13]
setblock 152 301 333 minecraft:light[level=13]
setblock 152 301 341 minecraft:light[level=13]
setblock 152 301 349 minecraft:light[level=13]
setblock 152 301 357 minecraft:light[level=13]
setblock 160 301 325 minecraft:light[level=13]
setblock 160 301 333 minecraft:light[level=13]
setblock 160 301 341 minecraft:light[level=13]
setblock 160 301 349 minecraft:light[level=13]
setblock 160 301 357 minecraft:light[level=13]
setblock 166 301 322 minecraft:cyan_concrete
setblock 168 301 325 minecraft:light[level=13]
setblock 168 301 333 minecraft:light[level=13]
setblock 168 301 341 minecraft:light[level=13]
setblock 168 301 349 minecraft:light[level=13]
setblock 168 301 357 minecraft:light[level=13]
setblock 176 301 325 minecraft:light[level=13]
setblock 176 301 333 minecraft:light[level=13]
setblock 176 301 341 minecraft:light[level=13]
setblock 176 301 349 minecraft:light[level=13]
setblock 176 301 357 minecraft:light[level=13]
fill 183 301 352 183 308 352 minecraft:blue_concrete
fill 166 302 322 166 308 322 minecraft:blue_concrete
setblock 141 303 344 minecraft:light_blue_wool
fill 141 304 344 141 308 344 minecraft:blue_concrete
setblock 141 306 345 minecraft:cyan_concrete
setblock 149 306 364 minecraft:light_blue_wool
fill 141 307 345 141 308 345 minecraft:blue_concrete
fill 149 307 364 149 308 364 minecraft:blue_concrete
setblock 148 308 322 minecraft:cyan_concrete
