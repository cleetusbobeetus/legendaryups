fill 275 93 495 275 96 495 minecraft:brown_terracotta
setblock 275 93 499 minecraft:bone_block
fill 275 93 500 275 96 500 minecraft:brown_terracotta
setblock 275 93 504 minecraft:bone_block
fill 275 93 505 275 196 505 minecraft:brown_terracotta
fill 276 93 464 276 96 464 minecraft:brown_terracotta
fill 276 93 466 276 94 466 minecraft:brown_terracotta
fill 276 93 476 276 93 477 minecraft:brown_terracotta
setblock 276 93 478 minecraft:bone_block
fill 276 93 479 276 93 482 minecraft:brown_terracotta
setblock 276 93 483 minecraft:bone_block
fill 276 93 484 276 96 484 minecraft:brown_terracotta
setblock 276 93 488 minecraft:bone_block
fill 276 93 489 276 96 489 minecraft:brown_terracotta
setblock 276 93 493 minecraft:bone_block
fill 276 93 494 276 96 494 minecraft:brown_terracotta
setblock 276 93 498 minecraft:bone_block
fill 276 93 499 276 96 499 minecraft:brown_terracotta
setblock 276 93 503 minecraft:bone_block
fill 276 93 504 276 96 504 minecraft:brown_terracotta
setblock 236 94 466 minecraft:brown_terracotta
setblock 236 94 467 minecraft:bone_block
fill 236 94 468 236 96 469 minecraft:brown_terracotta
setblock 236 94 471 minecraft:brown_terracotta
setblock 236 94 472 minecraft:bone_block
fill 236 94 473 236 97 473 minecraft:brown_terracotta
setblock 236 94 477 minecraft:bone_block
fill 236 94 478 236 97 478 minecraft:brown_terracotta
setblock 236 94 482 minecraft:bone_block
fill 236 94 483 236 94 486 minecraft:brown_terracotta
setblock 236 94 487 minecraft:bone_block
fill 236 94 488 236 97 488 minecraft:brown_terracotta
setblock 236 94 491 minecraft:brown_terracotta
setblock 236 94 492 minecraft:bone_block
fill 236 94 493 236 97 493 minecraft:brown_terracotta
setblock 236 94 497 minecraft:bone_block
fill 236 94 498 236 97 498 minecraft:brown_terracotta
setblock 236 94 502 minecraft:bone_block
fill 236 94 503 236 97 503 minecraft:brown_terracotta
setblock 237 94 465 minecraft:brown_terracotta
setblock 237 94 476 minecraft:bone_block
fill 237 94 477 237 97 477 minecraft:brown_terracotta
setblock 237 94 481 minecraft:bone_block
fill 237 94 482 237 97 482 minecraft:brown_terracotta
setblock 237 94 486 minecraft:bone_block
fill 237 94 487 237 97 487 minecraft:brown_terracotta
setblock 237 94 491 minecraft:bone_block
fill 237 94 492 237 97 492 minecraft:brown_terracotta
setblock 237 94 496 minecraft:bone_block
fill 237 94 497 237 95 497 minecraft:brown_terracotta
setblock 237 94 501 minecraft:bone_block
fill 237 94 502 237 97 502 minecraft:brown_terracotta
setblock 238 94 465 minecraft:bone_block
fill 238 94 476 238 95 476 minecraft:brown_terracotta
setblock 238 94 480 minecraft:bone_block
fill 238 94 481 238 97 481 minecraft:brown_terracotta
setblock 238 94 484 minecraft:brown_terracotta
setblock 238 94 485 minecraft:bone_block
fill 238 94 486 238 97 486 minecraft:brown_terracotta
setblock 238 94 490 minecraft:bone_block
setblock 238 94 501 minecraft:brown_terracotta
setblock 239 94 464 minecraft:bone_block
fill 239 94 465 239 97 465 minecraft:brown_terracotta
setblock 239 94 479 minecraft:bone_block
fill 239 94 480 239 96 480 minecraft:brown_terracotta
setblock 239 94 484 minecraft:bone_block
fill 239 94 485 240 94 485 minecraft:brown_terracotta
setblock 239 94 488 minecraft:brown_terracotta
setblock 239 94 504 minecraft:bone_block
fill 240 94 464 240 97 464 minecraft:brown_terracotta
setblock 240 94 483 minecraft:bone_block
fill 240 94 484 240 95 484 minecraft:brown_terracotta
setblock 240 94 503 minecraft:bone_block
fill 240 94 504 240 97 504 minecraft:brown_terracotta
fill 241 94 503 241 96 503 minecraft:brown_terracotta
setblock 242 94 465 minecraft:brown_terracotta
setblock 243 94 465 minecraft:bone_block
setblock 244 94 464 minecraft:bone_block
fill 244 94 465 244 97 465 minecraft:brown_terracotta
setblock 244 94 504 minecraft:bone_block
fill 245 94 464 248 94 464 minecraft:brown_terracotta
fill 245 94 504 248 94 504 minecraft:brown_terracotta
setblock 249 94 464 minecraft:bone_block
setblock 249 94 504 minecraft:bone_block
fill 250 94 464 250 97 464 minecraft:brown_terracotta
fill 250 94 504 253 94 504 minecraft:brown_terracotta
fill 251 94 465 252 94 465 minecraft:brown_terracotta
setblock 253 94 465 minecraft:bone_block
fill 253 94 503 254 94 503 minecraft:brown_terracotta
setblock 254 94 464 minecraft:bone_block
fill 254 94 465 254 97 465 minecraft:brown_terracotta
setblock 254 94 504 minecraft:bone_block
fill 255 94 464 255 97 464 minecraft:brown_terracotta
fill 255 94 466 256 94 466 minecraft:brown_terracotta
setblock 255 94 503 minecraft:bone_block
fill 255 94 504 255 97 504 minecraft:brown_terracotta
setblock 256 94 502 minecraft:bone_block
fill 256 94 503 256 97 503 minecraft:brown_terracotta
setblock 257 94 466 minecraft:bone_block
fill 257 94 502 257 97 502 minecraft:brown_terracotta
setblock 258 94 465 minecraft:bone_block
fill 258 94 466 258 97 466 minecraft:brown_terracotta
setblock 259 94 464 minecraft:bone_block
fill 259 94 465 259 97 465 minecraft:brown_terracotta
setblock 259 94 504 minecraft:bone_block
fill 260 94 464 260 97 464 minecraft:brown_terracotta
setblock 260 94 503 minecraft:bone_block
fill 260 94 504 260 97 504 minecraft:brown_terracotta
setblock 261 94 502 minecraft:bone_block
fill 261 94 503 261 97 503 minecraft:brown_terracotta
setblock 262 94 466 minecraft:bone_block
setblock 262 94 501 minecraft:bone_block
fill 262 94 502 262 97 502 minecraft:brown_terracotta
setblock 263 94 465 minecraft:bone_block
fill 263 94 466 263 96 466 minecraft:brown_terracotta
setblock 263 94 501 minecraft:brown_terracotta
setblock 264 94 464 minecraft:bone_block
fill 264 94 465 264 97 465 minecraft:brown_terracotta
setblock 264 94 504 minecraft:bone_block
fill 265 94 464 265 97 464 minecraft:brown_terracotta
setblock 265 94 503 minecraft:bone_block
fill 265 94 504 265 97 504 minecraft:brown_terracotta
setblock 266 94 502 minecraft:bone_block
fill 266 94 503 266 97 503 minecraft:brown_terracotta
fill 267 94 502 269 94 502 minecraft:brown_terracotta
setblock 269 94 464 minecraft:bone_block
setblock 269 94 504 minecraft:bone_block
fill 270 94 464 273 94 464 minecraft:brown_terracotta
setblock 270 94 503 minecraft:bone_block
fill 270 94 504 270 97 504 minecraft:brown_terracotta
fill 271 94 503 271 97 503 minecraft:brown_terracotta
setblock 272 94 502 minecraft:brown_terracotta
setblock 274 94 464 minecraft:bone_block
setblock 274 94 500 minecraft:brown_terracotta
setblock 274 94 504 minecraft:bone_block
fill 275 94 464 275 97 464 minecraft:brown_terracotta
fill 275 94 479 275 94 482 minecraft:brown_terracotta
setblock 275 94 483 minecraft:bone_block
fill 275 94 484 275 97 484 minecraft:brown_terracotta
setblock 275 94 487 minecraft:brown_terracotta
setblock 275 94 488 minecraft:bone_block
fill 275 94 489 275 95 491 minecraft:brown_terracotta
fill 275 94 494 275 97 494 minecraft:brown_terracotta
setblock 275 94 498 minecraft:bone_block
fill 275 94 499 275 97 499 minecraft:brown_terracotta
setblock 275 94 503 minecraft:bone_block
fill 275 94 504 275 97 504 minecraft:brown_terracotta
setblock 276 94 467 minecraft:bone_block
setblock 276 94 476 minecraft:brown_terracotta
setblock 276 94 477 minecraft:bone_block
fill 276 94 478 276 94 481 minecraft:brown_terracotta
setblock 276 94 482 minecraft:bone_block
fill 276 94 483 276 97 483 minecraft:brown_terracotta
setblock 276 94 487 minecraft:bone_block
fill 276 94 488 276 97 488 minecraft:brown_terracotta
setblock 276 94 492 minecraft:bone_block
fill 276 94 493 276 97 493 minecraft:brown_terracotta
setblock 276 94 497 minecraft:bone_block
fill 276 94 498 276 97 498 minecraft:brown_terracotta
setblock 276 94 502 minecraft:bone_block
fill 276 94 503 276 97 503 minecraft:brown_terracotta
setblock 236 95 466 minecraft:bone_block
fill 236 95 467 237 97 467 minecraft:brown_terracotta
setblock 236 95 470 minecraft:brown_terracotta
setblock 236 95 471 minecraft:bone_block
fill 236 95 472 236 98 472 minecraft:brown_terracotta
setblock 236 95 476 minecraft:bone_block
fill 236 95 477 236 98 477 minecraft:brown_terracotta
setblock 236 95 481 minecraft:bone_block
fill 236 95 482 236 95 485 minecraft:brown_terracotta
setblock 236 95 486 minecraft:bone_block
fill 236 95 487 236 98 487 minecraft:brown_terracotta
setblock 236 95 491 minecraft:bone_block
fill 236 95 492 236 98 492 minecraft:brown_terracotta
setblock 236 95 496 minecraft:bone_block
fill 236 95 497 236 97 497 minecraft:brown_terracotta
setblock 236 95 501 minecraft:bone_block
fill 236 95 502 236 98 502 minecraft:brown_terracotta
setblock 237 95 465 minecraft:bone_block
fill 237 95 466 237 98 466 minecraft:brown_terracotta
setblock 237 95 475 minecraft:bone_block
fill 237 95 476 237 98 476 minecraft:brown_terracotta
setblock 237 95 480 minecraft:bone_block
fill 237 95 481 237 98 481 minecraft:brown_terracotta
setblock 237 95 485 minecraft:bone_block
fill 237 95 486 237 98 486 minecraft:brown_terracotta
setblock 237 95 489 minecraft:brown_terracotta
setblock 237 95 490 minecraft:bone_block
fill 237 95 491 237 98 491 minecraft:brown_terracotta
setblock 237 95 500 minecraft:bone_block
fill 237 95 501 237 96 501 minecraft:brown_terracotta
setblock 238 95 464 minecraft:bone_block
fill 238 95 465 238 98 465 minecraft:brown_terracotta
setblock 238 95 479 minecraft:bone_block
fill 238 95 480 238 98 480 minecraft:brown_terracotta
setblock 238 95 484 minecraft:bone_block
fill 238 95 485 239 97 485 minecraft:brown_terracotta
setblock 238 95 489 minecraft:bone_block
fill 238 95 490 238 98 490 minecraft:brown_terracotta
setblock 238 95 504 minecraft:bone_block
fill 239 95 464 239 98 464 minecraft:brown_terracotta
setblock 239 95 479 minecraft:brown_terracotta
setblock 239 95 483 minecraft:bone_block
fill 239 95 484 239 98 484 minecraft:brown_terracotta
setblock 239 95 488 minecraft:bone_block
setblock 239 95 503 minecraft:bone_block
fill 239 95 504 239 98 504 minecraft:brown_terracotta
setblock 240 95 482 minecraft:bone_block
setblock 240 95 483 minecraft:brown_terracotta
fill 240 95 503 240 96 503 minecraft:brown_terracotta
setblock 242 95 465 minecraft:bone_block
setblock 243 95 464 minecraft:bone_block
fill 243 95 465 243 98 465 minecraft:brown_terracotta
setblock 243 95 504 minecraft:bone_block
fill 244 95 464 247 95 464 minecraft:brown_terracotta
fill 244 95 504 247 95 504 minecraft:brown_terracotta
setblock 248 95 464 minecraft:bone_block
setblock 248 95 504 minecraft:bone_block
fill 249 95 464 249 98 464 minecraft:brown_terracotta
fill 249 95 504 252 95 504 minecraft:brown_terracotta
fill 250 95 465 251 95 465 minecraft:brown_terracotta
setblock 252 95 465 minecraft:bone_block
setblock 253 95 464 minecraft:bone_block
fill 253 95 465 253 98 465 minecraft:brown_terracotta
setblock 253 95 503 minecraft:brown_terracotta
setblock 253 95 504 minecraft:bone_block
fill 254 95 464 254 98 464 minecraft:brown_terracotta
fill 254 95 466 255 95 466 minecraft:brown_terracotta
setblock 254 95 503 minecraft:bone_block
fill 254 95 504 254 98 504 minecraft:brown_terracotta
fill 255 95 503 255 98 503 minecraft:brown_terracotta
setblock 256 95 466 minecraft:bone_block
fill 256 95 502 256 96 502 minecraft:brown_terracotta
setblock 257 95 465 minecraft:bone_block
fill 257 95 466 257 98 466 minecraft:brown_terracotta
setblock 258 95 464 minecraft:bone_block
fill 258 95 465 258 98 465 minecraft:brown_terracotta
setblock 258 95 504 minecraft:bone_block
fill 259 95 464 259 98 464 minecraft:brown_terracotta
setblock 259 95 503 minecraft:bone_block
fill 259 95 504 259 98 504 minecraft:brown_terracotta
setblock 260 95 502 minecraft:bone_block
fill 260 95 503 260 98 503 minecraft:brown_terracotta
setblock 261 95 466 minecraft:bone_block
fill 261 95 502 261 97 502 minecraft:brown_terracotta
setblock 262 95 465 minecraft:bone_block
fill 262 95 466 262 97 466 minecraft:brown_terracotta
setblock 263 95 464 minecraft:bone_block
fill 263 95 465 263 98 465 minecraft:brown_terracotta
setblock 263 95 504 minecraft:bone_block
fill 264 95 464 264 98 464 minecraft:brown_terracotta
setblock 264 95 503 minecraft:bone_block
fill 264 95 504 264 98 504 minecraft:brown_terracotta
setblock 265 95 502 minecraft:bone_block
fill 265 95 503 265 98 503 minecraft:brown_terracotta
setblock 266 95 502 minecraft:brown_terracotta
setblock 268 95 464 minecraft:bone_block
setblock 268 95 504 minecraft:bone_block
fill 269 95 464 272 95 464 minecraft:brown_terracotta
setblock 269 95 503 minecraft:bone_block
fill 269 95 504 269 98 504 minecraft:brown_terracotta
fill 270 95 503 270 97 503 minecraft:brown_terracotta
setblock 273 95 464 minecraft:bone_block
setblock 273 95 504 minecraft:bone_block
fill 274 95 464 274 98 464 minecraft:brown_terracotta
setblock 274 95 503 minecraft:bone_block
fill 274 95 504 274 98 504 minecraft:brown_terracotta
fill 275 95 480 275 95 481 minecraft:brown_terracotta
setblock 275 95 482 minecraft:bone_block
fill 275 95 483 275 98 483 minecraft:brown_terracotta
setblock 275 95 487 minecraft:bone_block
fill 275 95 488 275 98 488 minecraft:brown_terracotta
setblock 275 95 492 minecraft:bone_block
fill 275 95 493 275 98 493 minecraft:brown_terracotta
setblock 275 95 497 minecraft:bone_block
fill 275 95 498 275 97 498 minecraft:brown_terracotta
setblock 275 95 502 minecraft:bone_block
fill 275 95 503 275 98 503 minecraft:brown_terracotta
setblock 276 95 466 minecraft:bone_block
fill 276 95 467 276 98 467 minecraft:brown_terracotta
setblock 276 95 476 minecraft:bone_block
fill 276 95 477 276 95 480 minecraft:brown_terracotta
setblock 276 95 481 minecraft:bone_block
fill 276 95 482 276 98 482 minecraft:brown_terracotta
setblock 276 95 486 minecraft:bone_block
fill 276 95 487 276 98 487 minecraft:brown_terracotta
setblock 276 95 491 minecraft:bone_block
fill 276 95 492 276 98 492 minecraft:brown_terracotta
setblock 276 95 496 minecraft:bone_block
fill 276 95 497 276 98 497 minecraft:brown_terracotta
setblock 276 95 501 minecraft:bone_block
fill 276 95 502 276 98 502 minecraft:brown_terracotta
setblock 236 96 465 minecraft:bone_block
fill 236 96 466 236 99 466 minecraft:brown_terracotta
setblock 236 96 470 minecraft:bone_block
fill 236 96 471 236 99 471 minecraft:brown_terracotta
setblock 236 96 474 minecraft:brown_terracotta
setblock 236 96 475 minecraft:bone_block
fill 236 96 476 236 99 476 minecraft:brown_terracotta
setblock 236 96 480 minecraft:bone_block
fill 236 96 481 236 96 484 minecraft:brown_terracotta
setblock 236 96 485 minecraft:bone_block
fill 236 96 486 236 99 486 minecraft:brown_terracotta
setblock 236 96 490 minecraft:bone_block
fill 236 96 491 236 99 491 minecraft:brown_terracotta
setblock 236 96 495 minecraft:bone_block
fill 236 96 496 236 98 496 minecraft:brown_terracotta
setblock 236 96 500 minecraft:bone_block
fill 236 96 501 236 98 501 minecraft:brown_terracotta
setblock 237 96 464 minecraft:bone_block
fill 237 96 465 237 99 465 minecraft:brown_terracotta
setblock 237 96 468 minecraft:brown_terracotta
setblock 237 96 475 minecraft:brown_terracotta
setblock 237 96 479 minecraft:bone_block
fill 237 96 480 237 99 480 minecraft:brown_terracotta
setblock 237 96 484 minecraft:bone_block
fill 237 96 485 237 99 485 minecraft:brown_terracotta
setblock 237 96 489 minecraft:bone_block
fill 237 96 490 237 99 490 minecraft:brown_terracotta
setblock 237 96 500 minecraft:brown_terracotta
setblock 237 96 504 minecraft:bone_block
fill 238 96 464 238 99 464 minecraft:brown_terracotta
setblock 238 96 466 minecraft:light[level=12]
setblock 238 96 474 minecraft:light[level=12]
setblock 238 96 478 minecraft:bone_block
fill 238 96 479 238 98 479 minecraft:brown_terracotta
setblock 238 96 483 minecraft:bone_block
fill 238 96 484 238 99 484 minecraft:brown_terracotta
setblock 238 96 487 minecraft:brown_terracotta
setblock 238 96 488 minecraft:bone_block
fill 238 96 489 238 99 489 minecraft:brown_terracotta
setblock 238 96 498 minecraft:light[level=12]
setblock 238 96 503 minecraft:bone_block
fill 238 96 504 238 99 504 minecraft:brown_terracotta
setblock 239 96 482 minecraft:bone_block
fill 239 96 483 239 98 483 minecraft:brown_terracotta
setblock 239 96 487 minecraft:bone_block
fill 239 96 503 239 97 503 minecraft:brown_terracotta
setblock 241 96 465 minecraft:bone_block
setblock 242 96 464 minecraft:bone_block
fill 242 96 465 242 99 465 minecraft:brown_terracotta
setblock 242 96 504 minecraft:bone_block
fill 243 96 464 246 96 464 minecraft:brown_terracotta
fill 243 96 504 246 96 504 minecraft:brown_terracotta
setblock 245 96 465 minecraft:brown_terracotta
setblock 246 96 466 minecraft:light[level=12]
setblock 246 96 474 minecraft:light[level=12]
setblock 246 96 482 minecraft:light[level=12]
setblock 246 96 490 minecraft:light[level=12]
setblock 246 96 498 minecraft:light[level=12]
setblock 247 96 464 minecraft:bone_block
fill 248 96 464 248 99 464 minecraft:brown_terracotta
fill 249 96 465 250 96 465 minecraft:brown_terracotta
fill 249 96 504 251 96 504 minecraft:brown_terracotta
setblock 251 96 465 minecraft:bone_block
setblock 252 96 464 minecraft:bone_block
fill 252 96 465 252 99 465 minecraft:brown_terracotta
setblock 252 96 504 minecraft:bone_block
fill 253 96 464 253 99 464 minecraft:brown_terracotta
fill 253 96 466 254 96 466 minecraft:brown_terracotta
setblock 253 96 503 minecraft:bone_block
fill 253 96 504 253 99 504 minecraft:brown_terracotta
setblock 254 96 474 minecraft:light[level=12]
setblock 254 96 482 minecraft:light[level=12]
setblock 254 96 490 minecraft:light[level=12]
setblock 254 96 498 minecraft:light[level=12]
fill 254 96 503 254 99 503 minecraft:brown_terracotta
setblock 255 96 466 minecraft:bone_block
setblock 256 96 465 minecraft:bone_block
fill 256 96 466 256 99 466 minecraft:brown_terracotta
setblock 257 96 464 minecraft:bone_block
fill 257 96 465 257 99 465 minecraft:brown_terracotta
setblock 257 96 504 minecraft:bone_block
fill 258 96 464 258 99 464 minecraft:brown_terracotta
setblock 258 96 503 minecraft:bone_block
fill 258 96 504 258 99 504 minecraft:brown_terracotta
setblock 259 96 502 minecraft:bone_block
fill 259 96 503 259 99 503 minecraft:brown_terracotta
setblock 260 96 466 minecraft:bone_block
fill 260 96 502 260 97 502 minecraft:brown_terracotta
setblock 261 96 465 minecraft:bone_block
fill 261 96 466 261 99 466 minecraft:brown_terracotta
setblock 262 96 464 minecraft:bone_block
fill 262 96 465 262 99 465 minecraft:brown_terracotta
setblock 262 96 474 minecraft:light[level=12]
setblock 262 96 482 minecraft:light[level=12]
setblock 262 96 490 minecraft:light[level=12]
setblock 262 96 498 minecraft:light[level=12]
setblock 262 96 504 minecraft:bone_block
fill 263 96 464 263 99 464 minecraft:brown_terracotta
setblock 263 96 503 minecraft:bone_block
fill 263 96 504 263 99 504 minecraft:brown_terracotta
setblock 264 96 502 minecraft:bone_block
fill 264 96 503 264 98 503 minecraft:brown_terracotta
setblock 266 96 465 minecraft:bone_block
setblock 267 96 464 minecraft:bone_block
setblock 267 96 504 minecraft:bone_block
fill 268 96 464 271 96 464 minecraft:brown_terracotta
setblock 268 96 503 minecraft:bone_block
fill 268 96 504 268 99 504 minecraft:brown_terracotta
fill 269 96 503 269 97 503 minecraft:brown_terracotta
setblock 270 96 466 minecraft:light[level=12]
setblock 270 96 474 minecraft:light[level=12]
setblock 270 96 482 minecraft:light[level=12]
setblock 270 96 490 minecraft:light[level=12]
setblock 270 96 498 minecraft:light[level=12]
setblock 272 96 464 minecraft:bone_block
setblock 272 96 504 minecraft:bone_block
fill 273 96 464 273 99 464 minecraft:brown_terracotta
setblock 273 96 503 minecraft:bone_block
fill 273 96 504 273 99 504 minecraft:brown_terracotta
fill 274 96 503 274 99 503 minecraft:brown_terracotta
setblock 275 96 480 minecraft:brown_terracotta
setblock 275 96 481 minecraft:bone_block
fill 275 96 482 275 99 482 minecraft:brown_terracotta
setblock 275 96 486 minecraft:bone_block
fill 275 96 487 275 99 487 minecraft:brown_terracotta
fill 275 96 489 275 96 490 minecraft:brown_terracotta
setblock 275 96 491 minecraft:bone_block
fill 275 96 492 275 99 492 minecraft:brown_terracotta
setblock 275 96 496 minecraft:bone_block
setblock 275 96 497 minecraft:brown_terracotta
setblock 275 96 501 minecraft:bone_block
fill 275 96 502 275 99 502 minecraft:brown_terracotta
setblock 276 96 465 minecraft:bone_block
fill 276 96 466 276 99 466 minecraft:brown_terracotta
fill 276 96 468 276 97 468 minecraft:brown_terracotta
fill 276 96 477 276 96 479 minecraft:brown_terracotta
setblock 276 96 480 minecraft:bone_block
fill 276 96 481 276 99 481 minecraft:brown_terracotta
setblock 276 96 485 minecraft:bone_block
fill 276 96 486 276 99 486 minecraft:brown_terracotta
setblock 276 96 490 minecraft:bone_block
fill 276 96 491 276 99 491 minecraft:brown_terracotta
setblock 276 96 495 minecraft:bone_block
fill 276 96 496 276 99 496 minecraft:brown_terracotta
setblock 276 96 500 minecraft:bone_block
fill 276 96 501 276 99 501 minecraft:brown_terracotta
setblock 236 97 464 minecraft:bone_block
fill 236 97 465 236 100 465 minecraft:brown_terracotta
setblock 236 97 468 minecraft:brown_terracotta
setblock 236 97 469 minecraft:bone_block
fill 236 97 470 236 100 470 minecraft:brown_terracotta
setblock 236 97 474 minecraft:bone_block
fill 236 97 475 236 100 475 minecraft:brown_terracotta
setblock 236 97 479 minecraft:bone_block
fill 236 97 480 236 97 483 minecraft:brown_terracotta
setblock 236 97 484 minecraft:bone_block
fill 236 97 485 236 100 485 minecraft:brown_terracotta
setblock 236 97 489 minecraft:bone_block
fill 236 97 490 236 100 490 minecraft:brown_terracotta
setblock 236 97 494 minecraft:bone_block
fill 236 97 495 236 100 495 minecraft:brown_terracotta
setblock 236 97 499 minecraft:bone_block
fill 236 97 500 236 98 500 minecraft:brown_terracotta
setblock 236 97 504 minecraft:bone_block
fill 237 97 464 237 100 464 minecraft:brown_terracotta
setblock 237 97 468 minecraft:bone_block
setblock 237 97 478 minecraft:bone_block
fill 237 97 479 237 100 479 minecraft:brown_terracotta
setblock 237 97 483 minecraft:bone_block
fill 237 97 484 237 100 484 minecraft:brown_terracotta
setblock 237 97 488 minecraft:bone_block
fill 237 97 489 237 100 489 minecraft:brown_terracotta
setblock 237 97 493 minecraft:bone_block
setblock 237 97 503 minecraft:bone_block
fill 237 97 504 237 100 504 minecraft:brown_terracotta
setblock 238 97 478 minecraft:brown_terracotta
setblock 238 97 482 minecraft:bone_block
fill 238 97 483 238 100 483 minecraft:brown_terracotta
setblock 238 97 487 minecraft:bone_block
fill 238 97 488 238 100 488 minecraft:brown_terracotta
setblock 238 97 503 minecraft:brown_terracotta
setblock 239 97 481 minecraft:bone_block
setblock 239 97 482 minecraft:brown_terracotta
setblock 239 97 486 minecraft:bone_block
setblock 239 97 487 minecraft:brown_terracotta
setblock 240 97 465 minecraft:bone_block
setblock 241 97 464 minecraft:bone_block
fill 241 97 465 241 100 465 minecraft:brown_terracotta
setblock 241 97 504 minecraft:bone_block
fill 242 97 464 245 97 464 minecraft:brown_terracotta
fill 242 97 504 244 97 504 minecraft:brown_terracotta
setblock 246 97 464 minecraft:bone_block
fill 247 97 464 247 100 464 minecraft:brown_terracotta
setblock 249 97 465 minecraft:brown_terracotta
setblock 250 97 465 minecraft:bone_block
setblock 250 97 504 minecraft:brown_terracotta
setblock 251 97 464 minecraft:bone_block
fill 251 97 465 251 100 465 minecraft:brown_terracotta
setblock 251 97 504 minecraft:bone_block
fill 252 97 464 252 100 464 minecraft:brown_terracotta
fill 252 97 504 252 100 504 minecraft:brown_terracotta
setblock 253 97 466 minecraft:brown_terracotta
setblock 254 97 466 minecraft:bone_block
setblock 255 97 465 minecraft:bone_block
fill 255 97 466 255 100 466 minecraft:brown_terracotta
setblock 256 97 464 minecraft:bone_block
fill 256 97 465 256 100 465 minecraft:brown_terracotta
setblock 256 97 504 minecraft:bone_block
fill 257 97 464 257 100 464 minecraft:brown_terracotta
setblock 257 97 503 minecraft:bone_block
fill 257 97 504 257 100 504 minecraft:brown_terracotta
setblock 258 97 502 minecraft:bone_block
fill 258 97 503 258 100 503 minecraft:brown_terracotta
setblock 259 97 466 minecraft:bone_block
fill 259 97 502 259 98 502 minecraft:brown_terracotta
setblock 260 97 465 minecraft:bone_block
fill 260 97 466 260 100 466 minecraft:brown_terracotta
setblock 261 97 464 minecraft:bone_block
fill 261 97 465 261 100 465 minecraft:brown_terracotta
setblock 261 97 504 minecraft:bone_block
fill 262 97 464 262 100 464 minecraft:brown_terracotta
setblock 262 97 503 minecraft:bone_block
fill 262 97 504 262 100 504 minecraft:brown_terracotta
fill 263 97 503 263 99 503 minecraft:brown_terracotta
setblock 265 97 465 minecraft:bone_block
setblock 266 97 464 minecraft:bone_block
setblock 266 97 504 minecraft:bone_block
fill 267 97 464 270 97 464 minecraft:brown_terracotta
setblock 267 97 503 minecraft:bone_block
fill 267 97 504 267 100 504 minecraft:brown_terracotta
setblock 268 97 503 minecraft:brown_terracotta
setblock 271 97 464 minecraft:bone_block
setblock 271 97 504 minecraft:bone_block
fill 272 97 464 272 100 464 minecraft:brown_terracotta
setblock 272 97 503 minecraft:bone_block
fill 272 97 504 272 100 504 minecraft:brown_terracotta
fill 273 97 503 273 99 503 minecraft:brown_terracotta
setblock 274 97 485 minecraft:brown_terracotta
setblock 274 97 486 minecraft:bone_block
fill 274 97 487 274 100 487 minecraft:brown_terracotta
fill 275 97 481 275 100 481 minecraft:brown_terracotta
setblock 275 97 485 minecraft:bone_block
fill 275 97 486 275 100 486 minecraft:brown_terracotta
setblock 275 97 489 minecraft:brown_terracotta
setblock 275 97 490 minecraft:bone_block
fill 275 97 491 275 100 491 minecraft:brown_terracotta
setblock 275 97 500 minecraft:bone_block
fill 275 97 501 275 98 501 minecraft:brown_terracotta
setblock 276 97 464 minecraft:bone_block
fill 276 97 465 276 100 465 minecraft:brown_terracotta
fill 276 97 477 276 97 478 minecraft:brown_terracotta
setblock 276 97 479 minecraft:bone_block
fill 276 97 480 276 100 480 minecraft:brown_terracotta
setblock 276 97 484 minecraft:bone_block
fill 276 97 485 276 100 485 minecraft:brown_terracotta
setblock 276 97 489 minecraft:bone_block
fill 276 97 490 276 100 490 minecraft:brown_terracotta
setblock 276 97 494 minecraft:bone_block
fill 276 97 495 276 100 495 minecraft:brown_terracotta
setblock 276 97 499 minecraft:bone_block
fill 276 97 500 276 100 500 minecraft:brown_terracotta
setblock 276 97 504 minecraft:bone_block
fill 236 98 464 236 101 464 minecraft:brown_terracotta
setblock 236 98 467 minecraft:brown_terracotta
setblock 236 98 468 minecraft:bone_block
fill 236 98 469 237 100 469 minecraft:brown_terracotta
setblock 236 98 473 minecraft:bone_block
fill 236 98 474 236 101 474 minecraft:brown_terracotta
setblock 236 98 478 minecraft:bone_block
fill 236 98 479 236 98 482 minecraft:brown_terracotta
setblock 236 98 483 minecraft:bone_block
fill 236 98 484 236 101 484 minecraft:brown_terracotta
setblock 236 98 488 minecraft:bone_block
fill 236 98 489 236 101 489 minecraft:brown_terracotta
setblock 236 98 493 minecraft:bone_block
fill 236 98 494 236 101 494 minecraft:brown_terracotta
setblock 236 98 499 minecraft:brown_terracotta
setblock 236 98 503 minecraft:bone_block
fill 236 98 504 236 101 504 minecraft:brown_terracotta
setblock 237 98 467 minecraft:bone_block
fill 237 98 468 237 101 468 minecraft:brown_terracotta
setblock 237 98 477 minecraft:bone_block
fill 237 98 478 237 101 478 minecraft:brown_terracotta
setblock 237 98 482 minecraft:bone_block
fill 237 98 483 237 101 483 minecraft:brown_terracotta
setblock 237 98 487 minecraft:bone_block
fill 237 98 488 237 101 488 minecraft:brown_terracotta
setblock 237 98 492 minecraft:bone_block
setblock 238 98 481 minecraft:bone_block
fill 238 98 482 238 100 482 minecraft:brown_terracotta
setblock 238 98 485 minecraft:brown_terracotta
setblock 238 98 486 minecraft:bone_block
fill 238 98 487 238 101 487 minecraft:brown_terracotta
setblock 239 98 465 minecraft:bone_block
setblock 239 98 485 minecraft:bone_block
setblock 239 98 486 minecraft:brown_terracotta
setblock 240 98 464 minecraft:bone_block
fill 240 98 465 240 101 465 minecraft:brown_terracotta
setblock 240 98 504 minecraft:bone_block
fill 241 98 464 244 98 464 minecraft:brown_terracotta
fill 241 98 504 242 98 504 minecraft:brown_terracotta
setblock 245 98 464 minecraft:bone_block
fill 246 98 464 246 101 464 minecraft:brown_terracotta
setblock 249 98 465 minecraft:bone_block
setblock 250 98 464 minecraft:bone_block
fill 250 98 465 250 101 465 minecraft:brown_terracotta
fill 251 98 464 251 101 464 minecraft:brown_terracotta
fill 251 98 504 251 101 504 minecraft:brown_terracotta
setblock 253 98 466 minecraft:bone_block
setblock 254 98 465 minecraft:bone_block
fill 254 98 466 254 101 466 minecraft:brown_terracotta
setblock 255 98 464 minecraft:bone_block
fill 255 98 465 255 101 465 minecraft:brown_terracotta
setblock 255 98 504 minecraft:bone_block
fill 256 98 464 256 101 464 minecraft:brown_terracotta
setblock 256 98 503 minecraft:bone_block
fill 256 98 504 256 101 504 minecraft:brown_terracotta
fill 257 98 503 257 101 503 minecraft:brown_terracotta
setblock 258 98 466 minecraft:bone_block
setblock 258 98 502 minecraft:brown_terracotta
setblock 259 98 465 minecraft:bone_block
fill 259 98 466 259 101 466 minecraft:brown_terracotta
setblock 260 98 464 minecraft:bone_block
fill 260 98 465 260 101 465 minecraft:brown_terracotta
setblock 260 98 504 minecraft:bone_block
fill 261 98 464 261 101 464 minecraft:brown_terracotta
setblock 261 98 503 minecraft:bone_block
fill 261 98 504 261 101 504 minecraft:brown_terracotta
fill 262 98 503 262 99 503 minecraft:brown_terracotta
setblock 264 98 465 minecraft:bone_block
setblock 265 98 464 minecraft:bone_block
setblock 265 98 504 minecraft:bone_block
fill 266 98 464 269 98 464 minecraft:brown_terracotta
fill 266 98 504 266 101 504 minecraft:brown_terracotta
setblock 270 98 464 minecraft:bone_block
setblock 270 98 504 minecraft:bone_block
fill 271 98 464 271 101 464 minecraft:brown_terracotta
fill 271 98 504 271 101 504 minecraft:brown_terracotta
setblock 272 98 503 minecraft:brown_terracotta
setblock 274 98 485 minecraft:bone_block
fill 274 98 486 274 101 486 minecraft:brown_terracotta
fill 274 98 488 274 98 489 minecraft:brown_terracotta
setblock 275 98 464 minecraft:bone_block
setblock 275 98 484 minecraft:bone_block
fill 275 98 485 275 101 485 minecraft:brown_terracotta
setblock 275 98 489 minecraft:bone_block
fill 275 98 490 275 101 490 minecraft:brown_terracotta
setblock 275 98 494 minecraft:bone_block
setblock 275 98 500 minecraft:brown_terracotta
setblock 275 98 504 minecraft:bone_block
fill 276 98 464 276 101 464 minecraft:brown_terracotta
setblock 276 98 468 minecraft:bone_block
fill 276 98 469 276 101 469 minecraft:brown_terracotta
setblock 276 98 478 minecraft:bone_block
fill 276 98 479 276 101 479 minecraft:brown_terracotta
setblock 276 98 483 minecraft:bone_block
fill 276 98 484 276 101 484 minecraft:brown_terracotta
setblock 276 98 488 minecraft:bone_block
fill 276 98 489 276 101 489 minecraft:brown_terracotta
setblock 276 98 493 minecraft:bone_block
fill 276 98 494 276 101 494 minecraft:brown_terracotta
setblock 276 98 498 minecraft:bone_block
fill 276 98 499 276 101 499 minecraft:brown_terracotta
setblock 276 98 503 minecraft:bone_block
fill 276 98 504 276 101 504 minecraft:brown_terracotta
setblock 236 99 467 minecraft:bone_block
fill 236 99 468 236 102 468 minecraft:brown_terracotta
setblock 236 99 472 minecraft:bone_block
fill 236 99 473 236 102 473 minecraft:brown_terracotta
setblock 236 99 477 minecraft:bone_block
fill 236 99 478 236 99 481 minecraft:brown_terracotta
setblock 236 99 482 minecraft:bone_block
fill 236 99 483 236 102 483 minecraft:brown_terracotta
setblock 236 99 487 minecraft:bone_block
fill 236 99 488 236 102 488 minecraft:brown_terracotta
setblock 236 99 492 minecraft:bone_block
fill 236 99 493 236 102 493 minecraft:brown_terracotta
setblock 236 99 502 minecraft:bone_block
fill 236 99 503 236 100 503 minecraft:brown_terracotta
setblock 237 99 466 minecraft:bone_block
fill 237 99 467 237 102 467 minecraft:brown_terracotta
setblock 237 99 470 minecraft:brown_terracotta
fill 237 99 477 237 102 477 minecraft:brown_terracotta
setblock 237 99 481 minecraft:bone_block
fill 237 99 482 237 102 482 minecraft:brown_terracotta
setblock 237 99 486 minecraft:bone_block
fill 237 99 487 237 102 487 minecraft:brown_terracotta
setblock 237 99 491 minecraft:bone_block
fill 237 99 492 237 102 492 minecraft:brown_terracotta
setblock 238 99 465 minecraft:bone_block
setblock 238 99 480 minecraft:bone_block
setblock 238 99 481 minecraft:brown_terracotta
setblock 238 99 485 minecraft:bone_block
fill 238 99 486 238 102 486 minecraft:brown_terracotta
setblock 238 99 490 minecraft:bone_block
setblock 239 99 464 minecraft:bone_block
fill 239 99 465 239 102 465 minecraft:brown_terracotta
setblock 239 99 504 minecraft:bone_block
fill 240 99 464 243 99 464 minecraft:brown_terracotta
setblock 240 99 504 minecraft:brown_terracotta
setblock 244 99 464 minecraft:bone_block
fill 245 99 464 245 102 464 minecraft:brown_terracotta
setblock 249 99 464 minecraft:bone_block
fill 249 99 465 249 102 465 minecraft:brown_terracotta
fill 250 99 464 250 102 464 minecraft:brown_terracotta
setblock 252 99 466 minecraft:bone_block
setblock 253 99 465 minecraft:bone_block
fill 253 99 466 253 102 466 minecraft:brown_terracotta
setblock 254 99 464 minecraft:bone_block
fill 254 99 465 254 102 465 minecraft:brown_terracotta
setblock 254 99 504 minecraft:bone_block
fill 255 99 464 255 102 464 minecraft:brown_terracotta
setblock 255 99 503 minecraft:bone_block
fill 255 99 504 255 102 504 minecraft:brown_terracotta
fill 256 99 503 256 102 503 minecraft:brown_terracotta
setblock 257 99 466 minecraft:bone_block
setblock 258 99 465 minecraft:bone_block
fill 258 99 466 258 102 466 minecraft:brown_terracotta
setblock 259 99 464 minecraft:bone_block
fill 259 99 465 259 102 465 minecraft:brown_terracotta
setblock 259 99 504 minecraft:bone_block
fill 260 99 464 260 102 464 minecraft:brown_terracotta
setblock 260 99 503 minecraft:bone_block
fill 260 99 504 260 102 504 minecraft:brown_terracotta
fill 261 99 503 261 100 503 minecraft:brown_terracotta
setblock 263 99 465 minecraft:bone_block
setblock 264 99 464 minecraft:bone_block
setblock 264 99 504 minecraft:bone_block
fill 265 99 464 267 99 464 minecraft:brown_terracotta
fill 265 99 504 265 101 504 minecraft:brown_terracotta
setblock 269 99 504 minecraft:bone_block
fill 270 99 464 270 102 464 minecraft:brown_terracotta
fill 270 99 504 270 102 504 minecraft:brown_terracotta
setblock 274 99 464 minecraft:bone_block
fill 274 99 485 274 102 485 minecraft:brown_terracotta
setblock 274 99 488 minecraft:brown_terracotta
setblock 274 99 489 minecraft:bone_block
fill 274 99 490 274 102 490 minecraft:brown_terracotta
setblock 274 99 504 minecraft:bone_block
fill 275 99 464 275 102 464 minecraft:brown_terracotta
setblock 275 99 483 minecraft:bone_block
fill 275 99 484 275 102 484 minecraft:brown_terracotta
setblock 275 99 488 minecraft:bone_block
fill 275 99 489 275 102 489 minecraft:brown_terracotta
setblock 275 99 493 minecraft:bone_block
fill 275 99 494 275 101 495 minecraft:brown_terracotta
setblock 275 99 503 minecraft:bone_block
fill 275 99 504 275 102 504 minecraft:brown_terracotta
setblock 276 99 467 minecraft:bone_block
fill 276 99 468 276 102 468 minecraft:brown_terracotta
fill 276 99 470 276 100 470 minecraft:brown_terracotta
fill 276 99 478 276 102 478 minecraft:brown_terracotta
setblock 276 99 482 minecraft:bone_block
fill 276 99 483 276 102 483 minecraft:brown_terracotta
setblock 276 99 487 minecraft:bone_block
fill 276 99 488 276 102 488 minecraft:brown_terracotta
setblock 276 99 492 minecraft:bone_block
fill 276 99 493 276 102 493 minecraft:brown_terracotta
setblock 276 99 497 minecraft:bone_block
fill 276 99 498 276 102 498 minecraft:brown_terracotta
setblock 276 99 502 minecraft:bone_block
fill 276 99 503 276 102 503 minecraft:brown_terracotta
setblock 236 100 466 minecraft:bone_block
fill 236 100 467 236 103 467 minecraft:brown_terracotta
setblock 236 100 471 minecraft:bone_block
fill 236 100 472 237 102 472 minecraft:brown_terracotta
setblock 236 100 476 minecraft:bone_block
fill 236 100 477 236 100 480 minecraft:brown_terracotta
setblock 236 100 481 minecraft:bone_block
fill 236 100 482 236 103 482 minecraft:brown_terracotta
setblock 236 100 486 minecraft:bone_block
fill 236 100 487 236 103 487 minecraft:brown_terracotta
setblock 236 100 491 minecraft:bone_block
fill 236 100 492 236 103 492 minecraft:brown_terracotta
setblock 237 100 465 minecraft:bone_block
fill 237 100 466 237 103 466 minecraft:brown_terracotta
setblock 237 100 470 minecraft:bone_block
fill 237 100 471 237 103 471 minecraft:brown_terracotta
setblock 237 100 480 minecraft:bone_block
fill 237 100 481 237 103 481 minecraft:brown_terracotta
setblock 237 100 485 minecraft:bone_block
fill 237 100 486 237 103 486 minecraft:brown_terracotta
setblock 237 100 490 minecraft:bone_block
fill 237 100 491 237 103 491 minecraft:brown_terracotta
setblock 238 100 464 minecraft:bone_block
fill 238 100 465 238 103 465 minecraft:brown_terracotta
setblock 238 100 484 minecraft:bone_block
fill 238 100 485 238 103 485 minecraft:brown_terracotta
setblock 238 100 489 minecraft:bone_block
setblock 238 100 504 minecraft:bone_block
fill 239 100 464 242 100 464 minecraft:brown_terracotta
setblock 242 100 465 minecraft:bone_block
setblock 243 100 464 minecraft:bone_block
fill 244 100 464 244 103 464 minecraft:brown_terracotta
setblock 248 100 464 minecraft:bone_block
fill 248 100 465 248 103 465 minecraft:brown_terracotta
fill 249 100 464 249 103 464 minecraft:brown_terracotta
setblock 251 100 466 minecraft:bone_block
setblock 252 100 465 minecraft:bone_block
fill 252 100 466 252 103 466 minecraft:brown_terracotta
setblock 253 100 464 minecraft:bone_block
fill 253 100 465 253 103 465 minecraft:brown_terracotta
setblock 253 100 504 minecraft:bone_block
fill 254 100 464 254 103 464 minecraft:brown_terracotta
setblock 254 100 503 minecraft:bone_block
fill 254 100 504 254 103 504 minecraft:brown_terracotta
fill 255 100 503 255 103 503 minecraft:brown_terracotta
setblock 256 100 466 minecraft:bone_block
setblock 257 100 465 minecraft:bone_block
fill 257 100 466 257 103 466 minecraft:brown_terracotta
setblock 258 100 464 minecraft:bone_block
fill 258 100 465 258 103 465 minecraft:brown_terracotta
setblock 258 100 504 minecraft:bone_block
fill 259 100 464 259 103 464 minecraft:brown_terracotta
setblock 259 100 503 minecraft:bone_block
fill 259 100 504 259 103 504 minecraft:brown_terracotta
fill 260 100 503 260 102 503 minecraft:brown_terracotta
setblock 262 100 465 minecraft:bone_block
setblock 263 100 464 minecraft:bone_block
setblock 263 100 465 minecraft:brown_terracotta
setblock 263 100 504 minecraft:bone_block
fill 264 100 464 266 100 464 minecraft:brown_terracotta
fill 264 100 504 264 103 504 minecraft:brown_terracotta
setblock 268 100 504 minecraft:bone_block
fill 269 100 504 269 103 504 minecraft:brown_terracotta
setblock 273 100 464 minecraft:bone_block
setblock 273 100 504 minecraft:bone_block
fill 274 100 464 274 103 464 minecraft:brown_terracotta
setblock 274 100 488 minecraft:bone_block
fill 274 100 489 274 103 489 minecraft:brown_terracotta
fill 274 100 491 274 101 491 minecraft:brown_terracotta
fill 274 100 504 274 103 504 minecraft:brown_terracotta
fill 275 100 465 275 101 465 minecraft:brown_terracotta
setblock 275 100 482 minecraft:bone_block
fill 275 100 483 275 103 483 minecraft:brown_terracotta
setblock 275 100 487 minecraft:bone_block
fill 275 100 488 275 103 488 minecraft:brown_terracotta
setblock 275 100 492 minecraft:bone_block
fill 275 100 493 275 103 493 minecraft:brown_terracotta
setblock 275 100 503 minecraft:brown_terracotta
setblock 276 100 466 minecraft:bone_block
fill 276 100 467 276 103 467 minecraft:brown_terracotta
setblock 276 100 471 minecraft:bone_block
setblock 276 100 481 minecraft:bone_block
fill 276 100 482 276 103 482 minecraft:brown_terracotta
setblock 276 100 486 minecraft:bone_block
fill 276 100 487 276 103 487 minecraft:brown_terracotta
setblock 276 100 491 minecraft:bone_block
fill 276 100 492 276 103 492 minecraft:brown_terracotta
setblock 276 100 496 minecraft:bone_block
fill 276 100 497 276 103 497 minecraft:brown_terracotta
setblock 276 100 501 minecraft:bone_block
fill 276 100 502 276 103 502 minecraft:brown_terracotta
setblock 236 101 465 minecraft:bone_block
fill 236 101 466 236 104 466 minecraft:brown_terracotta
setblock 236 101 469 minecraft:brown_terracotta
setblock 236 101 470 minecraft:bone_block
fill 236 101 471 236 104 471 minecraft:brown_terracotta
setblock 236 101 475 minecraft:bone_block
fill 236 101 476 236 101 479 minecraft:brown_terracotta
setblock 236 101 480 minecraft:bone_block
fill 236 101 481 236 104 481 minecraft:brown_terracotta
setblock 236 101 485 minecraft:bone_block
fill 236 101 486 236 104 486 minecraft:brown_terracotta
setblock 236 101 490 minecraft:bone_block
fill 236 101 491 236 104 491 minecraft:brown_terracotta
setblock 236 101 495 minecraft:bone_block
fill 236 101 496 236 104 496 minecraft:brown_terracotta
setblock 237 101 464 minecraft:bone_block
fill 237 101 465 237 104 465 minecraft:brown_terracotta
setblock 237 101 469 minecraft:bone_block
fill 237 101 470 237 104 470 minecraft:brown_terracotta
setblock 237 101 473 minecraft:brown_terracotta
setblock 237 101 474 minecraft:bone_block
setblock 237 101 479 minecraft:bone_block
fill 237 101 480 237 104 480 minecraft:brown_terracotta
setblock 237 101 484 minecraft:bone_block
fill 237 101 485 237 104 485 minecraft:brown_terracotta
setblock 237 101 489 minecraft:bone_block
fill 237 101 490 238 103 490 minecraft:brown_terracotta
setblock 237 101 493 minecraft:brown_terracotta
setblock 237 101 504 minecraft:bone_block
fill 238 101 464 241 101 464 minecraft:brown_terracotta
setblock 238 101 483 minecraft:bone_block
fill 238 101 484 238 102 484 minecraft:brown_terracotta
setblock 238 101 488 minecraft:bone_block
fill 238 101 489 238 104 489 minecraft:brown_terracotta
setblock 241 101 465 minecraft:bone_block
setblock 242 101 464 minecraft:bone_block
fill 243 101 464 243 104 464 minecraft:brown_terracotta
setblock 247 101 464 minecraft:bone_block
fill 248 101 464 248 104 464 minecraft:brown_terracotta
setblock 251 101 465 minecraft:bone_block
fill 251 101 466 251 104 466 minecraft:brown_terracotta
setblock 252 101 464 minecraft:bone_block
fill 252 101 465 252 104 465 minecraft:brown_terracotta
setblock 252 101 504 minecraft:bone_block
fill 253 101 464 253 104 464 minecraft:brown_terracotta
fill 253 101 504 253 104 504 minecraft:brown_terracotta
setblock 254 101 467 minecraft:bone_block
fill 254 101 503 254 104 503 minecraft:brown_terracotta
setblock 255 101 466 minecraft:bone_block
fill 255 101 467 256 103 467 minecraft:brown_terracotta
setblock 256 101 465 minecraft:bone_block
fill 256 101 466 256 104 466 minecraft:brown_terracotta
setblock 257 101 464 minecraft:bone_block
fill 257 101 465 257 104 465 minecraft:brown_terracotta
setblock 257 101 504 minecraft:bone_block
fill 258 101 464 258 104 464 minecraft:brown_terracotta
setblock 258 101 503 minecraft:bone_block
fill 258 101 504 258 104 504 minecraft:brown_terracotta
fill 259 101 503 259 104 503 minecraft:brown_terracotta
setblock 260 101 466 minecraft:bone_block
setblock 261 101 465 minecraft:bone_block
setblock 262 101 464 minecraft:bone_block
fill 262 101 465 262 102 465 minecraft:brown_terracotta
setblock 262 101 504 minecraft:bone_block
fill 263 101 464 265 101 464 minecraft:brown_terracotta
fill 263 101 504 263 104 504 minecraft:brown_terracotta
setblock 268 101 504 minecraft:brown_terracotta
setblock 272 101 464 minecraft:bone_block
setblock 272 101 504 minecraft:bone_block
fill 273 101 464 273 104 464 minecraft:brown_terracotta
fill 273 101 504 273 104 504 minecraft:brown_terracotta
fill 274 101 484 274 103 484 minecraft:brown_terracotta
setblock 274 101 487 minecraft:bone_block
fill 274 101 488 274 104 488 minecraft:brown_terracotta
setblock 274 101 492 minecraft:bone_block
setblock 275 101 466 minecraft:bone_block
fill 275 101 467 275 104 467 minecraft:brown_terracotta
setblock 275 101 481 minecraft:bone_block
fill 275 101 482 275 104 482 minecraft:brown_terracotta
setblock 275 101 486 minecraft:bone_block
fill 275 101 487 275 104 487 minecraft:brown_terracotta
setblock 275 101 491 minecraft:bone_block
fill 275 101 492 275 104 492 minecraft:brown_terracotta
setblock 275 101 496 minecraft:bone_block
setblock 276 101 465 minecraft:bone_block
fill 276 101 466 276 104 466 minecraft:brown_terracotta
setblock 276 101 470 minecraft:bone_block
fill 276 101 471 276 102 473 minecraft:brown_terracotta
setblock 276 101 480 minecraft:bone_block
fill 276 101 481 276 104 481 minecraft:brown_terracotta
setblock 276 101 485 minecraft:bone_block
fill 276 101 486 276 104 486 minecraft:brown_terracotta
setblock 276 101 490 minecraft:bone_block
fill 276 101 491 276 104 491 minecraft:brown_terracotta
setblock 276 101 495 minecraft:bone_block
fill 276 101 496 276 104 496 minecraft:brown_terracotta
setblock 276 101 500 minecraft:bone_block
fill 276 101 501 276 104 501 minecraft:brown_terracotta
setblock 236 102 464 minecraft:bone_block
fill 236 102 465 236 105 465 minecraft:brown_terracotta
setblock 236 102 469 minecraft:bone_block
fill 236 102 470 236 105 470 minecraft:brown_terracotta
setblock 236 102 474 minecraft:bone_block
fill 236 102 475 236 102 478 minecraft:brown_terracotta
setblock 236 102 479 minecraft:bone_block
fill 236 102 480 236 105 480 minecraft:brown_terracotta
setblock 236 102 484 minecraft:bone_block
fill 236 102 485 236 105 485 minecraft:brown_terracotta
setblock 236 102 489 minecraft:bone_block
fill 236 102 490 236 105 490 minecraft:brown_terracotta
setblock 236 102 494 minecraft:bone_block
fill 236 102 495 236 105 495 minecraft:brown_terracotta
setblock 236 102 504 minecraft:bone_block
fill 237 102 464 240 102 464 minecraft:brown_terracotta
setblock 237 102 468 minecraft:bone_block
fill 237 102 469 238 104 469 minecraft:brown_terracotta
setblock 237 102 473 minecraft:bone_block
fill 237 102 474 237 103 476 minecraft:brown_terracotta
setblock 237 102 478 minecraft:bone_block
fill 237 102 479 237 105 479 minecraft:brown_terracotta
setblock 237 102 483 minecraft:bone_block
fill 237 102 484 237 105 484 minecraft:brown_terracotta
setblock 237 102 488 minecraft:bone_block
fill 237 102 489 237 105 489 minecraft:brown_terracotta
setblock 237 102 493 minecraft:bone_block
setblock 238 102 467 minecraft:bone_block
fill 238 102 468 238 105 468 minecraft:brown_terracotta
fill 238 102 470 238 103 470 minecraft:brown_terracotta
setblock 238 102 487 minecraft:bone_block
fill 238 102 488 238 105 488 minecraft:brown_terracotta
setblock 240 102 465 minecraft:bone_block
setblock 241 102 464 minecraft:bone_block
fill 241 102 465 241 105 465 minecraft:brown_terracotta
fill 242 102 464 242 105 464 minecraft:brown_terracotta
setblock 246 102 464 minecraft:bone_block
fill 247 102 464 247 104 465 minecraft:brown_terracotta
setblock 250 102 465 minecraft:bone_block
fill 250 102 466 250 105 466 minecraft:brown_terracotta
setblock 250 102 504 minecraft:brown_terracotta
setblock 251 102 464 minecraft:bone_block
fill 251 102 465 251 105 465 minecraft:brown_terracotta
setblock 251 102 504 minecraft:bone_block
fill 252 102 464 252 105 464 minecraft:brown_terracotta
fill 252 102 504 252 105 504 minecraft:brown_terracotta
setblock 253 102 467 minecraft:bone_block
setblock 254 102 466 minecraft:bone_block
fill 254 102 467 254 105 467 minecraft:brown_terracotta
setblock 255 102 465 minecraft:bone_block
fill 255 102 466 255 105 466 minecraft:brown_terracotta
setblock 256 102 464 minecraft:bone_block
fill 256 102 465 256 105 465 minecraft:brown_terracotta
setblock 256 102 504 minecraft:bone_block
fill 257 102 464 257 105 464 minecraft:brown_terracotta
setblock 257 102 503 minecraft:bone_block
fill 257 102 504 257 105 504 minecraft:brown_terracotta
fill 258 102 503 258 105 503 minecraft:brown_terracotta
setblock 259 102 466 minecraft:bone_block
setblock 260 102 465 minecraft:bone_block
setblock 261 102 464 minecraft:bone_block
fill 261 102 465 261 104 465 minecraft:brown_terracotta
setblock 261 102 504 minecraft:bone_block
fill 262 102 464 264 103 464 minecraft:brown_terracotta
fill 262 102 504 262 105 504 minecraft:brown_terracotta
setblock 271 102 464 minecraft:bone_block
setblock 271 102 504 minecraft:bone_block
fill 272 102 464 272 105 464 minecraft:brown_terracotta
fill 272 102 504 272 105 504 minecraft:brown_terracotta
fill 273 102 488 273 104 489 minecraft:brown_terracotta
setblock 274 102 465 minecraft:brown_terracotta
setblock 274 102 486 minecraft:bone_block
fill 274 102 487 274 105 487 minecraft:brown_terracotta
setblock 274 102 491 minecraft:bone_block
fill 274 102 492 274 103 494 minecraft:brown_terracotta
setblock 275 102 465 minecraft:bone_block
fill 275 102 466 275 105 466 minecraft:brown_terracotta
fill 275 102 468 275 102 469 minecraft:brown_terracotta
fill 275 102 481 275 105 481 minecraft:brown_terracotta
setblock 275 102 485 minecraft:bone_block
fill 275 102 486 275 105 486 minecraft:brown_terracotta
setblock 275 102 490 minecraft:bone_block
fill 275 102 491 275 105 491 minecraft:brown_terracotta
setblock 275 102 494 minecraft:brown_terracotta
setblock 275 102 495 minecraft:bone_block
fill 275 102 496 275 104 497 minecraft:brown_terracotta
setblock 276 102 464 minecraft:bone_block
fill 276 102 465 276 105 465 minecraft:brown_terracotta
setblock 276 102 469 minecraft:bone_block
fill 276 102 470 276 105 470 minecraft:brown_terracotta
setblock 276 102 474 minecraft:bone_block
fill 276 102 475 276 103 477 minecraft:brown_terracotta
setblock 276 102 479 minecraft:bone_block
fill 276 102 480 276 105 480 minecraft:brown_terracotta
setblock 276 102 484 minecraft:bone_block
fill 276 102 485 276 105 485 minecraft:brown_terracotta
setblock 276 102 489 minecraft:bone_block
fill 276 102 490 276 105 490 minecraft:brown_terracotta
setblock 276 102 494 minecraft:bone_block
fill 276 102 495 276 105 495 minecraft:brown_terracotta
setblock 276 102 499 minecraft:bone_block
fill 276 102 500 276 105 500 minecraft:brown_terracotta
setblock 276 102 504 minecraft:bone_block
fill 236 103 464 239 103 464 minecraft:brown_terracotta
setblock 236 103 468 minecraft:bone_block
fill 236 103 469 236 106 469 minecraft:brown_terracotta
setblock 236 103 472 minecraft:brown_terracotta
setblock 236 103 473 minecraft:bone_block
fill 236 103 474 236 103 477 minecraft:brown_terracotta
setblock 236 103 478 minecraft:bone_block
fill 236 103 479 236 106 479 minecraft:brown_terracotta
setblock 236 103 483 minecraft:bone_block
fill 236 103 484 236 106 484 minecraft:brown_terracotta
setblock 236 103 488 minecraft:bone_block
fill 236 103 489 236 106 489 minecraft:brown_terracotta
setblock 236 103 493 minecraft:bone_block
fill 236 103 494 237 105 494 minecraft:brown_terracotta
setblock 236 103 497 minecraft:brown_terracotta
setblock 237 103 467 minecraft:bone_block
fill 237 103 468 237 106 468 minecraft:brown_terracotta
setblock 237 103 472 minecraft:bone_block
fill 237 103 473 237 106 473 minecraft:brown_terracotta
setblock 237 103 477 minecraft:bone_block
fill 237 103 478 237 106 478 minecraft:brown_terracotta
setblock 237 103 482 minecraft:bone_block
fill 237 103 483 237 106 483 minecraft:brown_terracotta
setblock 237 103 487 minecraft:bone_block
fill 237 103 488 237 106 488 minecraft:brown_terracotta
setblock 237 103 492 minecraft:bone_block
fill 237 103 493 237 106 493 minecraft:brown_terracotta
setblock 238 103 466 minecraft:bone_block
fill 238 103 467 238 106 467 minecraft:brown_terracotta
setblock 238 103 471 minecraft:bone_block
setblock 238 103 486 minecraft:bone_block
fill 238 103 487 238 104 487 minecraft:brown_terracotta
setblock 239 103 465 minecraft:bone_block
setblock 240 103 464 minecraft:bone_block
fill 240 103 465 240 106 465 minecraft:brown_terracotta
fill 241 103 464 241 106 464 minecraft:brown_terracotta
fill 242 103 465 242 104 465 minecraft:brown_terracotta
setblock 245 103 464 minecraft:bone_block
fill 246 103 464 246 105 465 minecraft:brown_terracotta
setblock 249 103 465 minecraft:bone_block
fill 249 103 466 249 106 466 minecraft:brown_terracotta
setblock 250 103 464 minecraft:bone_block
fill 250 103 465 250 106 465 minecraft:brown_terracotta
setblock 250 103 504 minecraft:bone_block
fill 251 103 464 251 106 464 minecraft:brown_terracotta
fill 251 103 504 251 106 504 minecraft:brown_terracotta
setblock 252 103 467 minecraft:bone_block
setblock 253 103 466 minecraft:bone_block
fill 253 103 467 253 106 467 minecraft:brown_terracotta
fill 253 103 503 253 105 503 minecraft:brown_terracotta
setblock 254 103 465 minecraft:bone_block
fill 254 103 466 254 106 466 minecraft:brown_terracotta
setblock 255 103 464 minecraft:bone_block
fill 255 103 465 255 106 465 minecraft:brown_terracotta
setblock 255 103 504 minecraft:bone_block
fill 256 103 464 256 106 464 minecraft:brown_terracotta
setblock 256 103 503 minecraft:bone_block
fill 256 103 504 256 106 504 minecraft:brown_terracotta
fill 257 103 503 257 106 503 minecraft:brown_terracotta
setblock 258 103 466 minecraft:bone_block
setblock 259 103 465 minecraft:bone_block
fill 259 103 466 259 104 466 minecraft:brown_terracotta
setblock 260 103 464 minecraft:bone_block
fill 260 103 465 260 105 465 minecraft:brown_terracotta
setblock 260 103 504 minecraft:bone_block
fill 261 103 464 261 106 464 minecraft:brown_terracotta
fill 261 103 504 261 106 504 minecraft:brown_terracotta
fill 268 103 504 268 104 504 minecraft:brown_terracotta
setblock 269 103 464 minecraft:brown_terracotta
setblock 270 103 464 minecraft:bone_block
setblock 270 103 504 minecraft:bone_block
fill 271 103 464 271 106 464 minecraft:brown_terracotta
fill 271 103 504 271 106 504 minecraft:brown_terracotta
setblock 273 103 465 minecraft:brown_terracotta
fill 273 103 487 273 106 487 minecraft:brown_terracotta
setblock 273 103 490 minecraft:brown_terracotta
setblock 273 103 491 minecraft:bone_block
fill 273 103 492 273 106 492 minecraft:brown_terracotta
setblock 274 103 465 minecraft:bone_block
setblock 274 103 485 minecraft:bone_block
fill 274 103 486 274 106 486 minecraft:brown_terracotta
setblock 274 103 490 minecraft:bone_block
fill 274 103 491 274 106 491 minecraft:brown_terracotta
setblock 274 103 495 minecraft:bone_block
setblock 275 103 464 minecraft:bone_block
fill 275 103 465 275 106 465 minecraft:brown_terracotta
setblock 275 103 468 minecraft:brown_terracotta
setblock 275 103 469 minecraft:bone_block
fill 275 103 470 275 104 472 minecraft:brown_terracotta
setblock 275 103 484 minecraft:bone_block
fill 275 103 485 275 106 485 minecraft:brown_terracotta
setblock 275 103 489 minecraft:bone_block
fill 275 103 490 275 106 490 minecraft:brown_terracotta
setblock 275 103 494 minecraft:bone_block
fill 275 103 495 275 106 495 minecraft:brown_terracotta
setblock 275 103 498 minecraft:brown_terracotta
setblock 275 103 504 minecraft:bone_block
fill 276 103 464 276 106 464 minecraft:brown_terracotta
setblock 276 103 468 minecraft:bone_block
fill 276 103 469 276 106 469 minecraft:brown_terracotta
fill 276 103 471 276 103 472 minecraft:brown_terracotta
setblock 276 103 473 minecraft:bone_block
fill 276 103 474 276 106 474 minecraft:brown_terracotta
setblock 276 103 478 minecraft:bone_block
fill 276 103 479 276 106 479 minecraft:brown_terracotta
setblock 276 103 483 minecraft:bone_block
fill 276 103 484 276 106 484 minecraft:brown_terracotta
setblock 276 103 488 minecraft:bone_block
fill 276 103 489 276 106 489 minecraft:brown_terracotta
setblock 276 103 493 minecraft:bone_block
fill 276 103 494 276 106 494 minecraft:brown_terracotta
setblock 276 103 498 minecraft:bone_block
fill 276 103 499 276 106 499 minecraft:brown_terracotta
setblock 276 103 503 minecraft:bone_block
fill 276 103 504 276 106 504 minecraft:brown_terracotta
fill 236 104 464 238 104 464 minecraft:brown_terracotta
setblock 236 104 467 minecraft:bone_block
fill 236 104 468 236 107 468 minecraft:brown_terracotta
setblock 236 104 472 minecraft:bone_block
fill 236 104 473 236 104 476 minecraft:brown_terracotta
setblock 236 104 477 minecraft:bone_block
fill 236 104 478 236 107 478 minecraft:brown_terracotta
setblock 236 104 482 minecraft:bone_block
fill 236 104 483 236 107 483 minecraft:brown_terracotta
setblock 236 104 487 minecraft:bone_block
fill 236 104 488 236 107 488 minecraft:brown_terracotta
setblock 236 104 492 minecraft:bone_block
fill 236 104 493 236 107 493 minecraft:brown_terracotta
setblock 236 104 497 minecraft:bone_block
setblock 237 104 466 minecraft:bone_block
fill 237 104 467 237 107 467 minecraft:brown_terracotta
setblock 237 104 471 minecraft:bone_block
fill 237 104 472 238 106 472 minecraft:brown_terracotta
fill 237 104 474 237 104 475 minecraft:brown_terracotta
setblock 237 104 476 minecraft:bone_block
fill 237 104 477 237 107 477 minecraft:brown_terracotta
setblock 237 104 481 minecraft:bone_block
fill 237 104 482 237 107 482 minecraft:brown_terracotta
setblock 237 104 486 minecraft:bone_block
fill 237 104 487 237 107 487 minecraft:brown_terracotta
setblock 237 104 490 minecraft:brown_terracotta
setblock 237 104 491 minecraft:bone_block
fill 237 104 492 237 107 492 minecraft:brown_terracotta
setblock 238 104 465 minecraft:bone_block
fill 238 104 466 238 105 466 minecraft:brown_terracotta
setblock 238 104 470 minecraft:bone_block
fill 238 104 471 238 107 471 minecraft:brown_terracotta
fill 238 104 473 238 105 473 minecraft:brown_terracotta
setblock 238 104 474 minecraft:light[level=12]
setblock 238 104 482 minecraft:light[level=12]
setblock 238 104 486 minecraft:brown_terracotta
setblock 238 104 490 minecraft:bone_block
setblock 238 104 498 minecraft:light[level=12]
setblock 239 104 464 minecraft:bone_block
fill 239 104 465 239 107 465 minecraft:brown_terracotta
fill 240 104 464 240 107 464 minecraft:brown_terracotta
setblock 244 104 464 minecraft:bone_block
fill 244 104 465 245 106 465 minecraft:brown_terracotta
fill 245 104 464 245 107 464 minecraft:brown_terracotta
setblock 246 104 466 minecraft:light[level=12]
setblock 246 104 474 minecraft:light[level=12]
setblock 246 104 482 minecraft:light[level=12]
setblock 246 104 490 minecraft:light[level=12]
setblock 246 104 498 minecraft:light[level=12]
setblock 248 104 465 minecraft:bone_block
fill 248 104 466 248 107 466 minecraft:brown_terracotta
setblock 249 104 464 minecraft:bone_block
fill 249 104 465 249 107 465 minecraft:brown_terracotta
setblock 249 104 504 minecraft:bone_block
fill 250 104 464 250 107 464 minecraft:brown_terracotta
setblock 250 104 467 minecraft:brown_terracotta
fill 250 104 504 250 107 504 minecraft:brown_terracotta
setblock 251 104 467 minecraft:bone_block
setblock 252 104 466 minecraft:bone_block
fill 252 104 467 252 107 467 minecraft:brown_terracotta
fill 252 104 503 252 106 503 minecraft:brown_terracotta
setblock 253 104 465 minecraft:bone_block
fill 253 104 466 253 107 466 minecraft:brown_terracotta
setblock 254 104 464 minecraft:bone_block
fill 254 104 465 254 107 465 minecraft:brown_terracotta
setblock 254 104 474 minecraft:light[level=12]
setblock 254 104 482 minecraft:light[level=12]
setblock 254 104 490 minecraft:light[level=12]
setblock 254 104 498 minecraft:light[level=12]
setblock 254 104 504 minecraft:bone_block
fill 255 104 464 255 107 464 minecraft:brown_terracotta
setblock 255 104 467 minecraft:brown_terracotta
setblock 255 104 503 minecraft:bone_block
fill 255 104 504 255 107 504 minecraft:brown_terracotta
setblock 256 104 467 minecraft:bone_block
fill 256 104 503 256 107 503 minecraft:brown_terracotta
setblock 257 104 466 minecraft:bone_block
setblock 258 104 465 minecraft:bone_block
fill 258 104 466 258 106 466 minecraft:brown_terracotta
setblock 259 104 464 minecraft:bone_block
fill 259 104 465 259 107 465 minecraft:brown_terracotta
setblock 259 104 504 minecraft:bone_block
fill 260 104 464 260 107 464 minecraft:brown_terracotta
fill 260 104 504 260 107 504 minecraft:brown_terracotta
fill 262 104 464 263 104 464 minecraft:brown_terracotta
setblock 262 104 466 minecraft:light[level=12]
setblock 262 104 474 minecraft:light[level=12]
setblock 262 104 482 minecraft:light[level=12]
setblock 262 104 490 minecraft:light[level=12]
setblock 262 104 498 minecraft:light[level=12]
setblock 269 104 464 minecraft:bone_block
setblock 269 104 504 minecraft:bone_block
fill 270 104 464 270 107 464 minecraft:brown_terracotta
setblock 270 104 466 minecraft:light[level=12]
setblock 270 104 474 minecraft:light[level=12]
setblock 270 104 482 minecraft:light[level=12]
setblock 270 104 490 minecraft:light[level=12]
setblock 270 104 498 minecraft:light[level=12]
fill 270 104 504 270 107 504 minecraft:brown_terracotta
setblock 272 104 465 minecraft:brown_terracotta
setblock 273 104 465 minecraft:bone_block
fill 273 104 486 273 107 486 minecraft:brown_terracotta
setblock 273 104 490 minecraft:bone_block
fill 273 104 491 273 107 491 minecraft:brown_terracotta
fill 273 104 493 274 104 493 minecraft:brown_terracotta
setblock 274 104 464 minecraft:bone_block
fill 274 104 465 274 107 465 minecraft:brown_terracotta
setblock 274 104 483 minecraft:brown_terracotta
setblock 274 104 484 minecraft:bone_block
fill 274 104 485 274 107 485 minecraft:brown_terracotta
setblock 274 104 489 minecraft:bone_block
fill 274 104 490 274 107 490 minecraft:brown_terracotta
fill 274 104 492 274 105 492 minecraft:brown_terracotta
setblock 274 104 494 minecraft:bone_block
fill 274 104 495 274 106 496 minecraft:brown_terracotta
setblock 274 104 504 minecraft:bone_block
fill 275 104 464 275 107 464 minecraft:brown_terracotta
setblock 275 104 468 minecraft:bone_block
fill 275 104 469 275 107 469 minecraft:brown_terracotta
setblock 275 104 473 minecraft:bone_block
fill 275 104 474 275 106 475 minecraft:brown_terracotta
fill 275 104 480 275 106 480 minecraft:brown_terracotta
setblock 275 104 483 minecraft:bone_block
fill 275 104 484 275 107 484 minecraft:brown_terracotta
setblock 275 104 488 minecraft:bone_block
fill 275 104 489 275 107 489 minecraft:brown_terracotta
setblock 275 104 493 minecraft:bone_block
fill 275 104 494 275 107 494 minecraft:brown_terracotta
setblock 275 104 498 minecraft:bone_block
fill 275 104 499 275 107 499 minecraft:brown_terracotta
fill 275 104 504 275 107 504 minecraft:brown_terracotta
setblock 276 104 467 minecraft:bone_block
fill 276 104 468 276 107 468 minecraft:brown_terracotta
setblock 276 104 471 minecraft:brown_terracotta
setblock 276 104 472 minecraft:bone_block
fill 276 104 473 276 107 473 minecraft:brown_terracotta
fill 276 104 475 276 104 476 minecraft:brown_terracotta
setblock 276 104 477 minecraft:bone_block
fill 276 104 478 276 107 478 minecraft:brown_terracotta
setblock 276 104 482 minecraft:bone_block
fill 276 104 483 276 107 483 minecraft:brown_terracotta
setblock 276 104 487 minecraft:bone_block
fill 276 104 488 276 107 488 minecraft:brown_terracotta
setblock 276 104 492 minecraft:bone_block
fill 276 104 493 276 107 493 minecraft:brown_terracotta
setblock 276 104 497 minecraft:bone_block
fill 276 104 498 276 107 498 minecraft:brown_terracotta
setblock 276 104 502 minecraft:bone_block
fill 276 104 503 276 107 503 minecraft:brown_terracotta
fill 236 105 464 237 105 464 minecraft:brown_terracotta
setblock 236 105 466 minecraft:bone_block
fill 236 105 467 236 108 467 minecraft:brown_terracotta
setblock 236 105 471 minecraft:bone_block
fill 236 105 472 236 105 475 minecraft:brown_terracotta
setblock 236 105 476 minecraft:bone_block
fill 236 105 477 236 108 477 minecraft:brown_terracotta
setblock 236 105 481 minecraft:bone_block
fill 236 105 482 236 108 482 minecraft:brown_terracotta
setblock 236 105 486 minecraft:bone_block
fill 236 105 487 236 108 487 minecraft:brown_terracotta
setblock 236 105 491 minecraft:bone_block
fill 236 105 492 236 108 492 minecraft:brown_terracotta
setblock 236 105 496 minecraft:bone_block
fill 236 105 497 236 107 498 minecraft:brown_terracotta
setblock 237 105 465 minecraft:bone_block
fill 237 105 466 237 108 466 minecraft:brown_terracotta
setblock 237 105 469 minecraft:brown_terracotta
setblock 237 105 470 minecraft:bone_block
fill 237 105 471 237 108 471 minecraft:brown_terracotta
setblock 237 105 474 minecraft:brown_terracotta
setblock 237 105 475 minecraft:bone_block
fill 237 105 476 237 108 476 minecraft:brown_terracotta
setblock 237 105 480 minecraft:bone_block
fill 237 105 481 237 107 481 minecraft:brown_terracotta
setblock 237 105 485 minecraft:bone_block
fill 237 105 486 237 108 486 minecraft:brown_terracotta
setblock 237 105 490 minecraft:bone_block
fill 237 105 491 237 108 491 minecraft:brown_terracotta
setblock 237 105 495 minecraft:bone_block
setblock 238 105 464 minecraft:bone_block
fill 238 105 465 238 107 465 minecraft:brown_terracotta
setblock 238 105 469 minecraft:bone_block
fill 238 105 470 238 108 470 minecraft:brown_terracotta
setblock 238 105 474 minecraft:bone_block
setblock 238 105 489 minecraft:bone_block
setblock 238 105 490 minecraft:brown_terracotta
fill 239 105 464 239 108 464 minecraft:brown_terracotta
setblock 242 105 465 minecraft:bone_block
setblock 243 105 464 minecraft:bone_block
fill 243 105 465 243 106 465 minecraft:brown_terracotta
fill 244 105 464 244 108 464 minecraft:brown_terracotta
setblock 247 105 464 minecraft:brown_terracotta
setblock 247 105 465 minecraft:bone_block
fill 247 105 466 247 108 466 minecraft:brown_terracotta
setblock 248 105 464 minecraft:bone_block
fill 248 105 465 248 108 465 minecraft:brown_terracotta
setblock 248 105 504 minecraft:bone_block
fill 249 105 464 249 108 464 minecraft:brown_terracotta
setblock 249 105 467 minecraft:brown_terracotta
fill 249 105 504 249 108 504 minecraft:brown_terracotta
setblock 250 105 467 minecraft:bone_block
setblock 251 105 466 minecraft:bone_block
fill 251 105 467 251 108 467 minecraft:brown_terracotta
fill 251 105 503 251 107 503 minecraft:brown_terracotta
setblock 252 105 465 minecraft:bone_block
fill 252 105 466 252 108 466 minecraft:brown_terracotta
setblock 253 105 464 minecraft:bone_block
fill 253 105 465 253 108 465 minecraft:brown_terracotta
setblock 253 105 504 minecraft:bone_block
fill 254 105 464 254 108 464 minecraft:brown_terracotta
setblock 254 105 503 minecraft:bone_block
fill 254 105 504 254 108 504 minecraft:brown_terracotta
setblock 255 105 467 minecraft:bone_block
fill 255 105 503 255 108 503 minecraft:brown_terracotta
setblock 256 105 466 minecraft:bone_block
fill 256 105 467 256 106 467 minecraft:brown_terracotta
setblock 257 105 465 minecraft:bone_block
fill 257 105 466 257 107 466 minecraft:brown_terracotta
setblock 258 105 464 minecraft:bone_block
fill 258 105 465 258 107 465 minecraft:brown_terracotta
setblock 258 105 504 minecraft:bone_block
fill 259 105 464 259 108 464 minecraft:brown_terracotta
fill 259 105 504 259 108 504 minecraft:brown_terracotta
setblock 262 105 464 minecraft:brown_terracotta
setblock 263 105 464 minecraft:bone_block
setblock 263 105 504 minecraft:bone_block
setblock 267 105 504 minecraft:brown_terracotta
setblock 268 105 464 minecraft:bone_block
setblock 268 105 504 minecraft:bone_block
fill 269 105 464 269 108 464 minecraft:brown_terracotta
fill 269 105 504 269 108 504 minecraft:brown_terracotta
setblock 271 105 465 minecraft:brown_terracotta
setblock 272 105 465 minecraft:bone_block
setblock 273 105 464 minecraft:bone_block
fill 273 105 465 273 107 465 minecraft:brown_terracotta
setblock 273 105 488 minecraft:brown_terracotta
setblock 273 105 489 minecraft:bone_block
fill 273 105 490 273 108 490 minecraft:brown_terracotta
setblock 273 105 493 minecraft:brown_terracotta
setblock 273 105 494 minecraft:bone_block
fill 273 105 495 273 108 495 minecraft:brown_terracotta
setblock 273 105 504 minecraft:bone_block
fill 274 105 464 274 108 464 minecraft:brown_terracotta
setblock 274 105 468 minecraft:bone_block
fill 274 105 469 274 106 471 minecraft:brown_terracotta
setblock 274 105 483 minecraft:bone_block
fill 274 105 484 274 108 484 minecraft:brown_terracotta
setblock 274 105 488 minecraft:bone_block
fill 274 105 489 274 108 489 minecraft:brown_terracotta
setblock 274 105 493 minecraft:bone_block
fill 274 105 494 274 108 494 minecraft:brown_terracotta
setblock 274 105 497 minecraft:brown_terracotta
fill 274 105 504 274 108 504 minecraft:brown_terracotta
setblock 275 105 467 minecraft:bone_block
fill 275 105 468 275 108 468 minecraft:brown_terracotta
fill 275 105 470 275 105 471 minecraft:brown_terracotta
setblock 275 105 472 minecraft:bone_block
fill 275 105 473 275 108 473 minecraft:brown_terracotta
setblock 275 105 476 minecraft:brown_terracotta
setblock 275 105 477 minecraft:bone_block
fill 275 105 478 275 107 479 minecraft:brown_terracotta
setblock 275 105 482 minecraft:bone_block
fill 275 105 483 275 108 483 minecraft:brown_terracotta
setblock 275 105 487 minecraft:bone_block
fill 275 105 488 275 108 488 minecraft:brown_terracotta
setblock 275 105 492 minecraft:bone_block
fill 275 105 493 275 108 493 minecraft:brown_terracotta
setblock 275 105 496 minecraft:brown_terracotta
setblock 275 105 497 minecraft:bone_block
fill 275 105 498 275 108 498 minecraft:brown_terracotta
setblock 276 105 466 minecraft:bone_block
fill 276 105 467 276 108 467 minecraft:brown_terracotta
setblock 276 105 471 minecraft:bone_block
fill 276 105 472 276 108 472 minecraft:brown_terracotta
setblock 276 105 475 minecraft:brown_terracotta
setblock 276 105 476 minecraft:bone_block
fill 276 105 477 276 108 477 minecraft:brown_terracotta
setblock 276 105 481 minecraft:bone_block
fill 276 105 482 276 108 482 minecraft:brown_terracotta
setblock 276 105 486 minecraft:bone_block
fill 276 105 487 276 108 487 minecraft:brown_terracotta
setblock 276 105 491 minecraft:bone_block
fill 276 105 492 276 108 492 minecraft:brown_terracotta
setblock 276 105 496 minecraft:bone_block
fill 276 105 497 276 108 497 minecraft:brown_terracotta
setblock 276 105 501 minecraft:bone_block
fill 276 105 502 276 107 502 minecraft:brown_terracotta
setblock 236 106 464 minecraft:brown_terracotta
setblock 236 106 465 minecraft:bone_block
fill 236 106 466 236 109 466 minecraft:brown_terracotta
setblock 236 106 470 minecraft:bone_block
fill 236 106 471 236 106 474 minecraft:brown_terracotta
setblock 236 106 475 minecraft:bone_block
fill 236 106 476 236 109 476 minecraft:brown_terracotta
setblock 236 106 480 minecraft:bone_block
fill 236 106 481 236 109 481 minecraft:brown_terracotta
setblock 236 106 485 minecraft:bone_block
fill 236 106 486 236 109 486 minecraft:brown_terracotta
setblock 236 106 490 minecraft:bone_block
fill 236 106 491 236 109 491 minecraft:brown_terracotta
setblock 236 106 494 minecraft:brown_terracotta
setblock 236 106 495 minecraft:bone_block
fill 236 106 496 236 109 496 minecraft:brown_terracotta
setblock 236 106 499 minecraft:brown_terracotta
setblock 237 106 464 minecraft:bone_block
fill 237 106 465 237 108 465 minecraft:brown_terracotta
setblock 237 106 469 minecraft:bone_block
fill 237 106 470 237 109 470 minecraft:brown_terracotta
setblock 237 106 474 minecraft:bone_block
fill 237 106 475 238 108 475 minecraft:brown_terracotta
setblock 237 106 479 minecraft:bone_block
fill 237 106 480 237 108 480 minecraft:brown_terracotta
setblock 237 106 484 minecraft:bone_block
fill 237 106 485 237 107 485 minecraft:brown_terracotta
setblock 237 106 489 minecraft:bone_block
fill 237 106 490 237 109 490 minecraft:brown_terracotta
setblock 237 106 494 minecraft:bone_block
fill 237 106 495 237 108 495 minecraft:brown_terracotta
fill 238 106 464 238 109 464 minecraft:brown_terracotta
setblock 238 106 468 minecraft:bone_block
fill 238 106 469 238 109 469 minecraft:brown_terracotta
setblock 238 106 473 minecraft:bone_block
fill 238 106 474 238 109 474 minecraft:brown_terracotta
setblock 241 106 465 minecraft:bone_block
setblock 242 106 464 minecraft:bone_block
fill 243 106 464 243 109 464 minecraft:brown_terracotta
setblock 246 106 464 minecraft:brown_terracotta
setblock 246 106 465 minecraft:bone_block
fill 246 106 466 246 108 466 minecraft:brown_terracotta
setblock 247 106 464 minecraft:bone_block
fill 247 106 465 247 109 465 minecraft:brown_terracotta
fill 248 106 464 248 109 464 minecraft:brown_terracotta
fill 248 106 504 248 109 504 minecraft:brown_terracotta
setblock 249 106 467 minecraft:bone_block
setblock 250 106 466 minecraft:bone_block
fill 250 106 467 250 109 467 minecraft:brown_terracotta
setblock 251 106 465 minecraft:bone_block
fill 251 106 466 251 109 466 minecraft:brown_terracotta
setblock 252 106 464 minecraft:bone_block
fill 252 106 465 252 109 465 minecraft:brown_terracotta
setblock 252 106 504 minecraft:bone_block
fill 253 106 464 253 109 464 minecraft:brown_terracotta
setblock 253 106 503 minecraft:bone_block
fill 253 106 504 253 109 504 minecraft:brown_terracotta
setblock 254 106 467 minecraft:bone_block
fill 254 106 503 254 109 503 minecraft:brown_terracotta
setblock 255 106 466 minecraft:bone_block
fill 255 106 467 255 107 467 minecraft:brown_terracotta
setblock 256 106 465 minecraft:bone_block
fill 256 106 466 256 108 466 minecraft:brown_terracotta
setblock 257 106 464 minecraft:bone_block
fill 257 106 465 257 108 465 minecraft:brown_terracotta
setblock 257 106 504 minecraft:bone_block
fill 258 106 464 258 109 464 minecraft:brown_terracotta
setblock 258 106 503 minecraft:bone_block
fill 258 106 504 258 109 504 minecraft:brown_terracotta
setblock 262 106 464 minecraft:bone_block
setblock 262 106 504 minecraft:bone_block
setblock 267 106 504 minecraft:bone_block
fill 268 106 464 268 107 464 minecraft:brown_terracotta
fill 268 106 504 268 109 504 minecraft:brown_terracotta
setblock 271 106 465 minecraft:bone_block
setblock 272 106 464 minecraft:bone_block
fill 272 106 465 272 107 465 minecraft:brown_terracotta
setblock 272 106 489 minecraft:bone_block
fill 272 106 490 272 106 493 minecraft:brown_terracotta
setblock 272 106 504 minecraft:bone_block
fill 273 106 464 273 109 464 minecraft:brown_terracotta
setblock 273 106 488 minecraft:bone_block
fill 273 106 489 273 109 489 minecraft:brown_terracotta
setblock 273 106 493 minecraft:bone_block
fill 273 106 494 273 109 494 minecraft:brown_terracotta
fill 273 106 496 273 107 496 minecraft:brown_terracotta
fill 273 106 504 273 109 504 minecraft:brown_terracotta
fill 274 106 468 274 107 468 minecraft:brown_terracotta
setblock 274 106 472 minecraft:bone_block
fill 274 106 473 274 108 474 minecraft:brown_terracotta
fill 274 106 483 274 108 483 minecraft:brown_terracotta
setblock 274 106 487 minecraft:bone_block
fill 274 106 488 274 109 488 minecraft:brown_terracotta
setblock 274 106 492 minecraft:bone_block
fill 274 106 493 274 109 493 minecraft:brown_terracotta
setblock 274 106 497 minecraft:bone_block
fill 274 106 498 274 109 498 minecraft:brown_terracotta
setblock 275 106 466 minecraft:bone_block
fill 275 106 467 275 109 467 minecraft:brown_terracotta
setblock 275 106 470 minecraft:brown_terracotta
setblock 275 106 471 minecraft:bone_block
fill 275 106 472 275 109 472 minecraft:brown_terracotta
setblock 275 106 476 minecraft:bone_block
fill 275 106 477 275 109 477 minecraft:brown_terracotta
setblock 275 106 481 minecraft:bone_block
fill 275 106 482 275 109 482 minecraft:brown_terracotta
setblock 275 106 486 minecraft:bone_block
fill 275 106 487 275 109 487 minecraft:brown_terracotta
setblock 275 106 491 minecraft:bone_block
fill 275 106 492 275 109 492 minecraft:brown_terracotta
setblock 275 106 496 minecraft:bone_block
fill 275 106 497 275 109 497 minecraft:brown_terracotta
setblock 275 106 500 minecraft:brown_terracotta
setblock 276 106 465 minecraft:bone_block
fill 276 106 466 276 109 466 minecraft:brown_terracotta
setblock 276 106 470 minecraft:bone_block
fill 276 106 471 276 109 471 minecraft:brown_terracotta
setblock 276 106 475 minecraft:bone_block
fill 276 106 476 276 109 476 minecraft:brown_terracotta
setblock 276 106 480 minecraft:bone_block
fill 276 106 481 276 109 481 minecraft:brown_terracotta
setblock 276 106 485 minecraft:bone_block
fill 276 106 486 276 109 486 minecraft:brown_terracotta
setblock 276 106 490 minecraft:bone_block
fill 276 106 491 276 109 491 minecraft:brown_terracotta
setblock 276 106 495 minecraft:bone_block
fill 276 106 496 276 109 496 minecraft:brown_terracotta
setblock 276 106 500 minecraft:bone_block
fill 276 106 501 276 109 501 minecraft:brown_terracotta
setblock 236 107 464 minecraft:bone_block
fill 236 107 465 236 110 465 minecraft:brown_terracotta
setblock 236 107 469 minecraft:bone_block
fill 236 107 470 236 107 473 minecraft:brown_terracotta
setblock 236 107 474 minecraft:bone_block
fill 236 107 475 236 110 475 minecraft:brown_terracotta
setblock 236 107 479 minecraft:bone_block
fill 236 107 480 236 110 480 minecraft:brown_terracotta
setblock 236 107 484 minecraft:bone_block
fill 236 107 485 236 110 485 minecraft:brown_terracotta
setblock 236 107 489 minecraft:bone_block
fill 236 107 490 236 110 490 minecraft:brown_terracotta
setblock 236 107 494 minecraft:bone_block
fill 236 107 495 236 110 495 minecraft:brown_terracotta
setblock 236 107 499 minecraft:bone_block
fill 237 107 464 237 109 464 minecraft:brown_terracotta
setblock 237 107 468 minecraft:bone_block
fill 237 107 469 237 110 469 minecraft:brown_terracotta
setblock 237 107 472 minecraft:brown_terracotta
setblock 237 107 473 minecraft:bone_block
fill 237 107 474 237 110 474 minecraft:brown_terracotta
setblock 237 107 478 minecraft:bone_block
fill 237 107 479 237 109 479 minecraft:brown_terracotta
setblock 237 107 483 minecraft:bone_block
setblock 237 107 484 minecraft:brown_terracotta
setblock 237 107 488 minecraft:bone_block
fill 237 107 489 237 108 489 minecraft:brown_terracotta
setblock 237 107 493 minecraft:bone_block
fill 237 107 494 237 109 494 minecraft:brown_terracotta
setblock 238 107 467 minecraft:bone_block
fill 238 107 468 238 108 468 minecraft:brown_terracotta
setblock 238 107 472 minecraft:bone_block
fill 238 107 473 238 110 473 minecraft:brown_terracotta
setblock 241 107 464 minecraft:bone_block
fill 242 107 464 242 109 464 minecraft:brown_terracotta
setblock 244 107 465 minecraft:brown_terracotta
setblock 245 107 465 minecraft:bone_block
setblock 246 107 464 minecraft:bone_block
fill 246 107 465 246 110 465 minecraft:brown_terracotta
fill 247 107 464 247 110 464 minecraft:brown_terracotta
fill 247 107 504 247 110 504 minecraft:brown_terracotta
setblock 249 107 466 minecraft:bone_block
fill 249 107 467 249 108 467 minecraft:brown_terracotta
setblock 250 107 465 minecraft:bone_block
fill 250 107 466 250 110 466 minecraft:brown_terracotta
fill 250 107 503 250 108 503 minecraft:brown_terracotta
setblock 251 107 464 minecraft:bone_block
fill 251 107 465 251 110 465 minecraft:brown_terracotta
setblock 251 107 504 minecraft:bone_block
fill 252 107 464 252 110 464 minecraft:brown_terracotta
setblock 252 107 503 minecraft:bone_block
fill 252 107 504 252 110 504 minecraft:brown_terracotta
setblock 253 107 467 minecraft:bone_block
fill 253 107 503 253 110 503 minecraft:brown_terracotta
setblock 254 107 466 minecraft:bone_block
fill 254 107 467 254 108 467 minecraft:brown_terracotta
setblock 255 107 465 minecraft:bone_block
fill 255 107 466 255 108 466 minecraft:brown_terracotta
setblock 256 107 464 minecraft:bone_block
fill 256 107 465 256 109 465 minecraft:brown_terracotta
setblock 256 107 504 minecraft:bone_block
fill 257 107 464 257 110 464 minecraft:brown_terracotta
setblock 257 107 503 minecraft:bone_block
fill 257 107 504 257 110 504 minecraft:brown_terracotta
setblock 258 107 503 minecraft:brown_terracotta
setblock 261 107 464 minecraft:bone_block
setblock 261 107 504 minecraft:bone_block
setblock 266 107 504 minecraft:bone_block
fill 267 107 504 267 110 504 minecraft:brown_terracotta
setblock 271 107 464 minecraft:bone_block
setblock 271 107 465 minecraft:brown_terracotta
setblock 271 107 504 minecraft:bone_block
fill 272 107 464 272 109 464 minecraft:brown_terracotta
fill 272 107 489 272 107 492 minecraft:brown_terracotta
setblock 272 107 493 minecraft:bone_block
fill 272 107 494 272 109 494 minecraft:brown_terracotta
fill 272 107 504 272 110 504 minecraft:brown_terracotta
setblock 273 107 487 minecraft:bone_block
fill 273 107 488 273 109 488 minecraft:brown_terracotta
setblock 273 107 492 minecraft:bone_block
fill 273 107 493 273 110 493 minecraft:brown_terracotta
fill 274 107 469 274 107 470 minecraft:brown_terracotta
setblock 274 107 471 minecraft:bone_block
fill 274 107 472 274 110 472 minecraft:brown_terracotta
setblock 274 107 475 minecraft:brown_terracotta
setblock 274 107 476 minecraft:bone_block
setblock 274 107 486 minecraft:bone_block
fill 274 107 487 274 110 487 minecraft:brown_terracotta
setblock 274 107 491 minecraft:bone_block
fill 274 107 492 274 110 492 minecraft:brown_terracotta
setblock 274 107 495 minecraft:brown_terracotta
setblock 274 107 496 minecraft:bone_block
fill 274 107 497 274 110 497 minecraft:brown_terracotta
setblock 275 107 465 minecraft:bone_block
fill 275 107 466 275 108 466 minecraft:brown_terracotta
setblock 275 107 470 minecraft:bone_block
fill 275 107 471 275 110 471 minecraft:brown_terracotta
setblock 275 107 474 minecraft:brown_terracotta
setblock 275 107 475 minecraft:bone_block
fill 275 107 476 275 110 476 minecraft:brown_terracotta
setblock 275 107 480 minecraft:bone_block
fill 275 107 481 275 110 481 minecraft:brown_terracotta
setblock 275 107 485 minecraft:bone_block
fill 275 107 486 275 110 486 minecraft:brown_terracotta
setblock 275 107 490 minecraft:bone_block
fill 275 107 491 275 110 491 minecraft:brown_terracotta
setblock 275 107 495 minecraft:bone_block
fill 275 107 496 275 110 496 minecraft:brown_terracotta
setblock 275 107 500 minecraft:bone_block
setblock 276 107 464 minecraft:bone_block
fill 276 107 465 276 109 465 minecraft:brown_terracotta
setblock 276 107 469 minecraft:bone_block
fill 276 107 470 276 110 470 minecraft:brown_terracotta
setblock 276 107 474 minecraft:bone_block
fill 276 107 475 276 110 475 minecraft:brown_terracotta
setblock 276 107 479 minecraft:bone_block
fill 276 107 480 276 110 480 minecraft:brown_terracotta
setblock 276 107 484 minecraft:bone_block
fill 276 107 485 276 110 485 minecraft:brown_terracotta
setblock 276 107 489 minecraft:bone_block
fill 276 107 490 276 110 490 minecraft:brown_terracotta
setblock 276 107 494 minecraft:bone_block
fill 276 107 495 276 110 495 minecraft:brown_terracotta
setblock 276 107 499 minecraft:bone_block
fill 276 107 500 276 110 500 minecraft:brown_terracotta
fill 236 108 464 236 110 464 minecraft:brown_terracotta
setblock 236 108 468 minecraft:bone_block
fill 236 108 469 236 108 472 minecraft:brown_terracotta
setblock 236 108 473 minecraft:bone_block
fill 236 108 474 236 111 474 minecraft:brown_terracotta
setblock 236 108 478 minecraft:bone_block
fill 236 108 479 236 111 479 minecraft:brown_terracotta
setblock 236 108 483 minecraft:bone_block
fill 236 108 484 236 110 484 minecraft:brown_terracotta
setblock 236 108 488 minecraft:bone_block
fill 236 108 489 236 110 489 minecraft:brown_terracotta
setblock 236 108 493 minecraft:bone_block
fill 236 108 494 236 111 494 minecraft:brown_terracotta
setblock 236 108 497 minecraft:brown_terracotta
setblock 236 108 498 minecraft:bone_block
setblock 236 108 499 minecraft:brown_terracotta
setblock 237 108 467 minecraft:bone_block
fill 237 108 468 237 110 468 minecraft:brown_terracotta
setblock 237 108 472 minecraft:bone_block
fill 237 108 473 237 111 473 minecraft:brown_terracotta
setblock 237 108 477 minecraft:bone_block
fill 237 108 478 237 111 478 minecraft:brown_terracotta
setblock 237 108 487 minecraft:bone_block
setblock 237 108 488 minecraft:brown_terracotta
setblock 237 108 492 minecraft:bone_block
fill 237 108 493 237 109 493 minecraft:brown_terracotta
setblock 238 108 471 minecraft:bone_block
fill 238 108 472 238 110 472 minecraft:brown_terracotta
setblock 240 108 464 minecraft:bone_block
setblock 241 108 464 minecraft:brown_terracotta
setblock 244 108 465 minecraft:bone_block
setblock 245 108 464 minecraft:bone_block
fill 245 108 465 245 109 465 minecraft:brown_terracotta
fill 246 108 464 246 111 464 minecraft:brown_terracotta
setblock 248 108 466 minecraft:bone_block
setblock 249 108 465 minecraft:bone_block
fill 249 108 466 249 110 466 minecraft:brown_terracotta
fill 249 108 503 249 109 503 minecraft:brown_terracotta
setblock 250 108 464 minecraft:bone_block
fill 250 108 465 250 111 465 minecraft:brown_terracotta
setblock 250 108 504 minecraft:bone_block
fill 251 108 464 251 111 464 minecraft:brown_terracotta
setblock 251 108 503 minecraft:bone_block
fill 251 108 504 251 111 504 minecraft:brown_terracotta
setblock 252 108 467 minecraft:bone_block
fill 252 108 503 252 111 503 minecraft:brown_terracotta
setblock 253 108 466 minecraft:bone_block
setblock 253 108 467 minecraft:brown_terracotta
setblock 254 108 465 minecraft:bone_block
fill 254 108 466 254 109 466 minecraft:brown_terracotta
setblock 255 108 464 minecraft:bone_block
fill 255 108 465 255 110 465 minecraft:brown_terracotta
setblock 255 108 504 minecraft:bone_block
fill 256 108 464 256 110 464 minecraft:brown_terracotta
setblock 256 108 503 minecraft:bone_block
fill 256 108 504 256 111 504 minecraft:brown_terracotta
setblock 257 108 503 minecraft:brown_terracotta
setblock 260 108 504 minecraft:bone_block
setblock 266 108 504 minecraft:brown_terracotta
setblock 270 108 464 minecraft:bone_block
setblock 270 108 504 minecraft:bone_block
fill 271 108 464 271 109 464 minecraft:brown_terracotta
fill 271 108 504 271 111 504 minecraft:brown_terracotta
fill 272 108 490 272 108 491 minecraft:brown_terracotta
setblock 272 108 492 minecraft:bone_block
fill 272 108 493 272 109 493 minecraft:brown_terracotta
setblock 273 108 487 minecraft:brown_terracotta
setblock 273 108 491 minecraft:bone_block
fill 273 108 492 273 110 492 minecraft:brown_terracotta
setblock 273 108 496 minecraft:bone_block
setblock 274 108 469 minecraft:brown_terracotta
setblock 274 108 470 minecraft:bone_block
fill 274 108 471 274 110 471 minecraft:brown_terracotta
setblock 274 108 475 minecraft:bone_block
fill 274 108 476 274 109 478 minecraft:brown_terracotta
setblock 274 108 485 minecraft:bone_block
fill 274 108 486 274 109 486 minecraft:brown_terracotta
setblock 274 108 490 minecraft:bone_block
fill 274 108 491 274 111 491 minecraft:brown_terracotta
setblock 274 108 495 minecraft:bone_block
fill 274 108 496 274 111 496 minecraft:brown_terracotta
setblock 275 108 464 minecraft:bone_block
setblock 275 108 469 minecraft:bone_block
fill 275 108 470 275 111 470 minecraft:brown_terracotta
setblock 275 108 474 minecraft:bone_block
fill 275 108 475 275 111 475 minecraft:brown_terracotta
setblock 275 108 478 minecraft:brown_terracotta
setblock 275 108 479 minecraft:bone_block
fill 275 108 480 275 111 480 minecraft:brown_terracotta
setblock 275 108 484 minecraft:bone_block
fill 275 108 485 275 110 485 minecraft:brown_terracotta
setblock 275 108 489 minecraft:bone_block
fill 275 108 490 275 111 490 minecraft:brown_terracotta
setblock 275 108 494 minecraft:bone_block
fill 275 108 495 275 111 495 minecraft:brown_terracotta
setblock 275 108 499 minecraft:bone_block
setblock 275 108 500 minecraft:brown_terracotta
setblock 275 108 504 minecraft:bone_block
setblock 276 108 464 minecraft:brown_terracotta
setblock 276 108 468 minecraft:bone_block
fill 276 108 469 276 111 469 minecraft:brown_terracotta
setblock 276 108 473 minecraft:bone_block
fill 276 108 474 276 111 474 minecraft:brown_terracotta
setblock 276 108 478 minecraft:bone_block
fill 276 108 479 276 111 479 minecraft:brown_terracotta
setblock 276 108 483 minecraft:bone_block
fill 276 108 484 276 111 484 minecraft:brown_terracotta
setblock 276 108 488 minecraft:bone_block
fill 276 108 489 276 111 489 minecraft:brown_terracotta
setblock 276 108 493 minecraft:bone_block
fill 276 108 494 276 111 494 minecraft:brown_terracotta
setblock 276 108 498 minecraft:bone_block
fill 276 108 499 276 111 499 minecraft:brown_terracotta
setblock 236 109 467 minecraft:bone_block
fill 236 109 468 236 109 471 minecraft:brown_terracotta
setblock 236 109 472 minecraft:bone_block
fill 236 109 473 236 112 473 minecraft:brown_terracotta
setblock 236 109 477 minecraft:bone_block
fill 236 109 478 236 112 478 minecraft:brown_terracotta
setblock 236 109 482 minecraft:bone_block
fill 236 109 483 236 110 483 minecraft:brown_terracotta
setblock 236 109 487 minecraft:bone_block
fill 236 109 488 236 110 488 minecraft:brown_terracotta
setblock 236 109 492 minecraft:bone_block
fill 236 109 493 236 111 493 minecraft:brown_terracotta
setblock 236 109 497 minecraft:bone_block
fill 236 109 498 236 110 498 minecraft:brown_terracotta
setblock 237 109 466 minecraft:bone_block
fill 237 109 467 237 110 467 minecraft:brown_terracotta
setblock 237 109 471 minecraft:bone_block
fill 237 109 472 237 112 472 minecraft:brown_terracotta
setblock 237 109 475 minecraft:brown_terracotta
setblock 237 109 476 minecraft:bone_block
fill 237 109 477 237 112 477 minecraft:brown_terracotta
setblock 237 109 491 minecraft:bone_block
setblock 237 109 492 minecraft:brown_terracotta
setblock 238 109 470 minecraft:bone_block
fill 238 109 471 238 110 471 minecraft:brown_terracotta
setblock 238 109 475 minecraft:bone_block
setblock 244 109 464 minecraft:bone_block
fill 245 109 464 245 112 464 minecraft:brown_terracotta
setblock 247 109 466 minecraft:bone_block
setblock 248 109 465 minecraft:bone_block
fill 248 109 466 248 110 466 minecraft:brown_terracotta
setblock 249 109 464 minecraft:bone_block
fill 249 109 465 249 112 465 minecraft:brown_terracotta
setblock 249 109 504 minecraft:bone_block
fill 250 109 464 250 112 464 minecraft:brown_terracotta
setblock 250 109 503 minecraft:bone_block
fill 250 109 504 250 112 504 minecraft:brown_terracotta
setblock 251 109 467 minecraft:bone_block
fill 251 109 503 251 112 503 minecraft:brown_terracotta
setblock 252 109 466 minecraft:bone_block
setblock 252 109 467 minecraft:brown_terracotta
setblock 253 109 465 minecraft:bone_block
fill 253 109 466 253 110 466 minecraft:brown_terracotta
setblock 254 109 464 minecraft:bone_block
fill 254 109 465 254 110 465 minecraft:brown_terracotta
setblock 254 109 504 minecraft:bone_block
fill 255 109 464 255 111 464 minecraft:brown_terracotta
setblock 255 109 503 minecraft:bone_block
fill 255 109 504 255 112 504 minecraft:brown_terracotta
fill 256 109 503 256 110 503 minecraft:brown_terracotta
setblock 259 109 504 minecraft:bone_block
setblock 269 109 464 minecraft:bone_block
setblock 269 109 504 minecraft:bone_block
setblock 270 109 464 minecraft:brown_terracotta
fill 270 109 504 270 112 504 minecraft:brown_terracotta
setblock 272 109 491 minecraft:bone_block
setblock 272 109 492 minecraft:brown_terracotta
setblock 273 109 490 minecraft:bone_block
fill 273 109 491 273 110 491 minecraft:brown_terracotta
setblock 273 109 495 minecraft:bone_block
fill 273 109 496 273 110 496 minecraft:brown_terracotta
setblock 274 109 464 minecraft:bone_block
setblock 274 109 470 minecraft:brown_terracotta
setblock 274 109 473 minecraft:brown_terracotta
setblock 274 109 474 minecraft:bone_block
fill 274 109 475 274 112 475 minecraft:brown_terracotta
setblock 274 109 485 minecraft:brown_terracotta
setblock 274 109 489 minecraft:bone_block
fill 274 109 490 274 111 490 minecraft:brown_terracotta
setblock 274 109 494 minecraft:bone_block
fill 274 109 495 274 112 495 minecraft:brown_terracotta
setblock 274 109 504 minecraft:bone_block
setblock 275 109 468 minecraft:bone_block
fill 275 109 469 275 110 469 minecraft:brown_terracotta
setblock 275 109 473 minecraft:bone_block
fill 275 109 474 275 112 474 minecraft:brown_terracotta
setblock 275 109 478 minecraft:bone_block
fill 275 109 479 275 112 479 minecraft:brown_terracotta
setblock 275 109 483 minecraft:bone_block
fill 275 109 484 275 110 484 minecraft:brown_terracotta
setblock 275 109 488 minecraft:bone_block
fill 275 109 489 275 111 489 minecraft:brown_terracotta
setblock 275 109 493 minecraft:bone_block
fill 275 109 494 275 112 494 minecraft:brown_terracotta
setblock 275 109 498 minecraft:bone_block
fill 275 109 499 275 110 499 minecraft:brown_terracotta
setblock 276 109 467 minecraft:bone_block
fill 276 109 468 276 111 468 minecraft:brown_terracotta
setblock 276 109 472 minecraft:bone_block
fill 276 109 473 276 112 473 minecraft:brown_terracotta
setblock 276 109 477 minecraft:bone_block
fill 276 109 478 276 112 478 minecraft:brown_terracotta
setblock 276 109 482 minecraft:bone_block
fill 276 109 483 276 112 483 minecraft:brown_terracotta
setblock 276 109 487 minecraft:bone_block
fill 276 109 488 276 112 488 minecraft:brown_terracotta
setblock 276 109 492 minecraft:bone_block
fill 276 109 493 276 112 493 minecraft:brown_terracotta
setblock 276 109 497 minecraft:bone_block
fill 276 109 498 276 112 498 minecraft:brown_terracotta
setblock 236 110 466 minecraft:bone_block
fill 236 110 467 236 110 470 minecraft:brown_terracotta
setblock 236 110 471 minecraft:bone_block
fill 236 110 472 236 113 472 minecraft:brown_terracotta
setblock 236 110 476 minecraft:bone_block
fill 236 110 477 236 113 477 minecraft:brown_terracotta
setblock 236 110 481 minecraft:bone_block
fill 236 110 482 236 111 482 minecraft:brown_terracotta
setblock 236 110 486 minecraft:bone_block
setblock 236 110 487 minecraft:brown_terracotta
setblock 236 110 491 minecraft:bone_block
fill 236 110 492 236 111 492 minecraft:brown_terracotta
setblock 236 110 496 minecraft:bone_block
fill 236 110 497 236 111 497 minecraft:brown_terracotta
setblock 237 110 470 minecraft:bone_block
fill 237 110 471 237 113 471 minecraft:brown_terracotta
setblock 237 110 475 minecraft:bone_block
fill 237 110 476 237 113 476 minecraft:brown_terracotta
setblock 238 110 470 minecraft:brown_terracotta
setblock 238 110 474 minecraft:bone_block
setblock 238 110 475 minecraft:brown_terracotta
setblock 243 110 464 minecraft:bone_block
fill 244 110 464 244 113 464 minecraft:brown_terracotta
fill 246 110 504 246 111 504 minecraft:brown_terracotta
setblock 247 110 465 minecraft:bone_block
setblock 248 110 464 minecraft:bone_block
fill 248 110 465 248 113 465 minecraft:brown_terracotta
setblock 248 110 504 minecraft:bone_block
fill 249 110 464 249 113 464 minecraft:brown_terracotta
setblock 249 110 503 minecraft:bone_block
fill 249 110 504 249 113 504 minecraft:brown_terracotta
fill 250 110 503 250 113 503 minecraft:brown_terracotta
setblock 251 110 466 minecraft:bone_block
setblock 252 110 465 minecraft:bone_block
setblock 252 110 466 minecraft:brown_terracotta
setblock 253 110 464 minecraft:bone_block
fill 253 110 465 253 111 465 minecraft:brown_terracotta
setblock 253 110 504 minecraft:bone_block
fill 254 110 464 254 112 464 minecraft:brown_terracotta
setblock 254 110 503 minecraft:bone_block
fill 254 110 504 254 113 504 minecraft:brown_terracotta
fill 255 110 503 255 111 503 minecraft:brown_terracotta
setblock 258 110 504 minecraft:bone_block
fill 263 110 480 264 111 482 minecraft:bone_block
setblock 268 110 504 minecraft:bone_block
fill 269 110 504 269 113 504 minecraft:brown_terracotta
setblock 273 110 490 minecraft:brown_terracotta
setblock 273 110 494 minecraft:bone_block
setblock 273 110 495 minecraft:brown_terracotta
setblock 273 110 504 minecraft:bone_block
setblock 274 110 473 minecraft:bone_block
fill 274 110 474 274 112 474 minecraft:brown_terracotta
fill 274 110 476 274 110 477 minecraft:brown_terracotta
setblock 274 110 478 minecraft:bone_block
setblock 274 110 488 minecraft:bone_block
fill 274 110 489 274 111 489 minecraft:brown_terracotta
setblock 274 110 493 minecraft:bone_block
fill 274 110 494 274 112 494 minecraft:brown_terracotta
setblock 275 110 468 minecraft:brown_terracotta
setblock 275 110 472 minecraft:bone_block
fill 275 110 473 275 113 473 minecraft:brown_terracotta
setblock 275 110 477 minecraft:bone_block
fill 275 110 478 275 113 478 minecraft:brown_terracotta
setblock 275 110 482 minecraft:bone_block
setblock 275 110 483 minecraft:brown_terracotta
setblock 275 110 487 minecraft:bone_block
fill 275 110 488 275 111 488 minecraft:brown_terracotta
setblock 275 110 492 minecraft:bone_block
fill 275 110 493 275 112 493 minecraft:brown_terracotta
setblock 275 110 497 minecraft:bone_block
fill 275 110 498 275 111 498 minecraft:brown_terracotta
setblock 276 110 467 minecraft:brown_terracotta
setblock 276 110 471 minecraft:bone_block
fill 276 110 472 276 113 472 minecraft:brown_terracotta
setblock 276 110 476 minecraft:bone_block
fill 276 110 477 276 113 477 minecraft:brown_terracotta
setblock 276 110 481 minecraft:bone_block
fill 276 110 482 276 113 482 minecraft:brown_terracotta
setblock 276 110 486 minecraft:bone_block
fill 276 110 487 276 112 487 minecraft:brown_terracotta
setblock 276 110 491 minecraft:bone_block
fill 276 110 492 276 113 492 minecraft:brown_terracotta
setblock 276 110 496 minecraft:bone_block
fill 276 110 497 276 113 497 minecraft:brown_terracotta
fill 236 111 466 236 111 469 minecraft:brown_terracotta
setblock 236 111 470 minecraft:bone_block
fill 236 111 471 236 114 471 minecraft:brown_terracotta
setblock 236 111 475 minecraft:bone_block
fill 236 111 476 236 114 476 minecraft:brown_terracotta
setblock 236 111 480 minecraft:bone_block
fill 236 111 481 236 112 481 minecraft:brown_terracotta
setblock 236 111 490 minecraft:bone_block
setblock 236 111 491 minecraft:brown_terracotta
setblock 236 111 495 minecraft:bone_block
setblock 236 111 496 minecraft:brown_terracotta
setblock 237 111 469 minecraft:bone_block
fill 237 111 470 237 112 470 minecraft:brown_terracotta
setblock 237 111 474 minecraft:bone_block
fill 237 111 475 237 114 475 minecraft:brown_terracotta
setblock 246 111 465 minecraft:bone_block
setblock 247 111 464 minecraft:bone_block
fill 247 111 465 247 112 465 minecraft:brown_terracotta
setblock 247 111 504 minecraft:bone_block
fill 248 111 464 248 114 464 minecraft:brown_terracotta
setblock 248 111 503 minecraft:bone_block
fill 248 111 504 248 114 504 minecraft:brown_terracotta
fill 249 111 503 249 114 503 minecraft:brown_terracotta
setblock 250 111 466 minecraft:bone_block
setblock 251 111 465 minecraft:bone_block
setblock 252 111 464 minecraft:bone_block
fill 252 111 465 252 112 465 minecraft:brown_terracotta
setblock 252 111 504 minecraft:bone_block
fill 253 111 464 253 113 464 minecraft:brown_terracotta
setblock 253 111 503 minecraft:bone_block
fill 253 111 504 253 114 504 minecraft:brown_terracotta
fill 254 111 503 254 113 503 minecraft:brown_terracotta
setblock 257 111 504 minecraft:bone_block
setblock 267 111 504 minecraft:bone_block
fill 268 111 504 268 114 504 minecraft:brown_terracotta
setblock 273 111 493 minecraft:bone_block
setblock 273 111 494 minecraft:brown_terracotta
setblock 274 111 472 minecraft:bone_block
setblock 274 111 473 minecraft:brown_terracotta
setblock 274 111 476 minecraft:brown_terracotta
setblock 274 111 477 minecraft:bone_block
setblock 274 111 478 minecraft:brown_terracotta
setblock 274 111 492 minecraft:bone_block
fill 274 111 493 274 112 493 minecraft:brown_terracotta
setblock 274 111 497 minecraft:bone_block
setblock 275 111 471 minecraft:bone_block
fill 275 111 472 275 113 472 minecraft:brown_terracotta
setblock 275 111 476 minecraft:bone_block
fill 275 111 477 275 114 477 minecraft:brown_terracotta
setblock 275 111 481 minecraft:bone_block
setblock 275 111 482 minecraft:brown_terracotta
setblock 275 111 486 minecraft:bone_block
setblock 275 111 487 minecraft:brown_terracotta
setblock 275 111 491 minecraft:bone_block
fill 275 111 492 275 112 492 minecraft:brown_terracotta
setblock 275 111 496 minecraft:bone_block
fill 275 111 497 275 112 497 minecraft:brown_terracotta
setblock 276 111 470 minecraft:bone_block
fill 276 111 471 276 114 471 minecraft:brown_terracotta
setblock 276 111 475 minecraft:bone_block
fill 276 111 476 276 114 476 minecraft:brown_terracotta
setblock 276 111 480 minecraft:bone_block
fill 276 111 481 276 114 481 minecraft:brown_terracotta
setblock 276 111 485 minecraft:bone_block
fill 276 111 486 276 112 486 minecraft:brown_terracotta
setblock 276 111 490 minecraft:bone_block
fill 276 111 491 276 113 491 minecraft:brown_terracotta
setblock 276 111 495 minecraft:bone_block
fill 276 111 496 276 114 496 minecraft:brown_terracotta
fill 236 112 467 236 112 468 minecraft:brown_terracotta
setblock 236 112 469 minecraft:bone_block
fill 236 112 470 236 115 470 minecraft:brown_terracotta
setblock 236 112 474 minecraft:bone_block
fill 236 112 475 236 115 475 minecraft:brown_terracotta
setblock 236 112 479 minecraft:bone_block
fill 236 112 480 236 115 480 minecraft:brown_terracotta
setblock 236 112 494 minecraft:bone_block
setblock 236 112 495 minecraft:brown_terracotta
setblock 237 112 473 minecraft:bone_block
fill 237 112 474 237 114 474 minecraft:brown_terracotta
setblock 238 112 466 minecraft:light[level=12]
setblock 238 112 474 minecraft:light[level=12]
setblock 238 112 482 minecraft:light[level=12]
setblock 238 112 490 minecraft:light[level=12]
setblock 238 112 498 minecraft:light[level=12]
setblock 246 112 464 minecraft:bone_block
setblock 246 112 466 minecraft:light[level=12]
setblock 246 112 474 minecraft:light[level=12]
setblock 246 112 482 minecraft:light[level=12]
setblock 246 112 490 minecraft:light[level=12]
setblock 246 112 498 minecraft:light[level=12]
setblock 246 112 504 minecraft:bone_block
fill 247 112 464 247 115 464 minecraft:brown_terracotta
fill 247 112 504 247 115 504 minecraft:brown_terracotta
fill 248 112 503 248 115 503 minecraft:brown_terracotta
setblock 250 112 465 minecraft:bone_block
setblock 251 112 464 minecraft:bone_block
setblock 251 112 465 minecraft:brown_terracotta
setblock 251 112 504 minecraft:bone_block
fill 252 112 464 252 115 464 minecraft:brown_terracotta
setblock 252 112 503 minecraft:bone_block
fill 252 112 504 252 115 504 minecraft:brown_terracotta
fill 253 112 503 253 115 503 minecraft:brown_terracotta
setblock 254 112 466 minecraft:light[level=12]
setblock 254 112 474 minecraft:light[level=12]
setblock 254 112 482 minecraft:light[level=12]
setblock 254 112 490 minecraft:light[level=12]
setblock 254 112 498 minecraft:light[level=12]
setblock 256 112 504 minecraft:bone_block
fill 258 112 466 262 113 470 minecraft:soul_soil
fill 260 112 464 260 112 465 minecraft:soul_soil
setblock 262 112 474 minecraft:light[level=12]
setblock 262 112 482 minecraft:light[level=12]
setblock 262 112 490 minecraft:light[level=12]
setblock 262 112 498 minecraft:light[level=12]
setblock 270 112 466 minecraft:light[level=12]
setblock 270 112 474 minecraft:light[level=12]
setblock 270 112 482 minecraft:light[level=12]
setblock 270 112 490 minecraft:light[level=12]
setblock 270 112 498 minecraft:light[level=12]
setblock 274 112 476 minecraft:bone_block
setblock 274 112 477 minecraft:brown_terracotta
setblock 275 112 471 minecraft:brown_terracotta
setblock 275 112 475 minecraft:bone_block
fill 275 112 476 275 115 476 minecraft:brown_terracotta
setblock 275 112 480 minecraft:bone_block
setblock 275 112 490 minecraft:bone_block
setblock 275 112 491 minecraft:brown_terracotta
setblock 275 112 495 minecraft:bone_block
fill 275 112 496 275 113 496 minecraft:brown_terracotta
setblock 276 112 469 minecraft:bone_block
fill 276 112 470 276 113 470 minecraft:brown_terracotta
setblock 276 112 474 minecraft:bone_block
fill 276 112 475 276 115 475 minecraft:brown_terracotta
setblock 276 112 479 minecraft:bone_block
fill 276 112 480 276 115 480 minecraft:brown_terracotta
setblock 276 112 484 minecraft:bone_block
setblock 276 112 485 minecraft:brown_terracotta
setblock 276 112 489 minecraft:bone_block
fill 276 112 490 276 113 490 minecraft:brown_terracotta
setblock 276 112 494 minecraft:bone_block
fill 276 112 495 276 114 495 minecraft:brown_terracotta
setblock 276 112 499 minecraft:bone_block
setblock 236 113 468 minecraft:bone_block
fill 236 113 469 236 114 469 minecraft:brown_terracotta
setblock 236 113 473 minecraft:bone_block
fill 236 113 474 236 116 474 minecraft:brown_terracotta
setblock 236 113 478 minecraft:bone_block
fill 236 113 479 236 116 479 minecraft:brown_terracotta
setblock 237 113 472 minecraft:bone_block
fill 237 113 473 237 114 473 minecraft:brown_terracotta
setblock 237 113 477 minecraft:bone_block
setblock 245 113 464 minecraft:bone_block
setblock 245 113 504 minecraft:bone_block
fill 246 113 464 246 116 464 minecraft:brown_terracotta
fill 246 113 504 246 116 504 minecraft:brown_terracotta
fill 247 113 503 247 116 503 minecraft:brown_terracotta
setblock 249 113 465 minecraft:bone_block
setblock 250 113 464 minecraft:bone_block
setblock 250 113 465 minecraft:brown_terracotta
setblock 250 113 504 minecraft:bone_block
fill 251 113 464 251 116 464 minecraft:brown_terracotta
setblock 251 113 503 minecraft:bone_block
fill 251 113 504 251 116 504 minecraft:brown_terracotta
fill 252 113 503 252 116 503 minecraft:brown_terracotta
setblock 255 113 504 minecraft:bone_block
setblock 256 113 504 minecraft:brown_terracotta
fill 267 113 504 267 115 504 minecraft:brown_terracotta
setblock 274 113 475 minecraft:bone_block
setblock 274 113 476 minecraft:brown_terracotta
setblock 275 113 474 minecraft:bone_block
fill 275 113 475 275 116 475 minecraft:brown_terracotta
setblock 275 113 479 minecraft:bone_block
fill 275 113 480 275 116 480 minecraft:brown_terracotta
setblock 275 113 494 minecraft:bone_block
setblock 275 113 495 minecraft:brown_terracotta
setblock 276 113 473 minecraft:bone_block
fill 276 113 474 276 116 474 minecraft:brown_terracotta
setblock 276 113 478 minecraft:bone_block
fill 276 113 479 276 116 479 minecraft:brown_terracotta
setblock 276 113 483 minecraft:bone_block
setblock 276 113 493 minecraft:bone_block
fill 276 113 494 276 114 494 minecraft:brown_terracotta
setblock 276 113 498 minecraft:bone_block
setblock 236 114 472 minecraft:bone_block
fill 236 114 473 236 117 473 minecraft:brown_terracotta
setblock 236 114 477 minecraft:bone_block
fill 236 114 478 236 117 478 minecraft:brown_terracotta
setblock 237 114 476 minecraft:bone_block
setblock 244 114 464 minecraft:bone_block
setblock 244 114 504 minecraft:bone_block
fill 245 114 464 245 117 464 minecraft:brown_terracotta
fill 245 114 504 245 117 504 minecraft:brown_terracotta
fill 246 114 503 246 117 503 minecraft:brown_terracotta
setblock 249 114 464 minecraft:bone_block
fill 249 114 502 250 114 502 minecraft:brown_terracotta
setblock 249 114 504 minecraft:bone_block
fill 250 114 464 250 117 464 minecraft:brown_terracotta
setblock 250 114 503 minecraft:bone_block
fill 250 114 504 250 117 504 minecraft:brown_terracotta
setblock 251 114 502 minecraft:bone_block
fill 251 114 503 251 117 503 minecraft:brown_terracotta
setblock 254 114 504 minecraft:bone_block
fill 255 114 504 255 117 504 minecraft:brown_terracotta
fill 256 114 467 258 115 467 minecraft:bone_block
fill 256 114 469 258 115 469 minecraft:bone_block
fill 257 114 468 257 115 468 minecraft:bone_block
fill 266 114 504 266 116 504 minecraft:brown_terracotta
setblock 269 114 504 minecraft:bone_block
setblock 275 114 473 minecraft:bone_block
fill 275 114 474 275 116 474 minecraft:brown_terracotta
setblock 275 114 478 minecraft:bone_block
fill 275 114 479 275 117 479 minecraft:brown_terracotta
setblock 276 114 472 minecraft:bone_block
fill 276 114 473 276 117 473 minecraft:brown_terracotta
setblock 276 114 477 minecraft:bone_block
fill 276 114 478 276 117 478 minecraft:brown_terracotta
setblock 276 114 482 minecraft:bone_block
setblock 276 114 497 minecraft:bone_block
setblock 236 115 471 minecraft:bone_block
fill 236 115 472 236 118 472 minecraft:brown_terracotta
setblock 236 115 476 minecraft:bone_block
fill 236 115 477 236 118 477 minecraft:brown_terracotta
setblock 237 115 475 minecraft:bone_block
setblock 243 115 464 minecraft:bone_block
setblock 243 115 504 minecraft:bone_block
fill 244 115 464 244 118 464 minecraft:brown_terracotta
fill 244 115 504 244 118 504 minecraft:brown_terracotta
fill 245 115 503 245 118 503 minecraft:brown_terracotta
fill 247 115 502 249 115 502 minecraft:brown_terracotta
setblock 248 115 464 minecraft:bone_block
setblock 248 115 504 minecraft:bone_block
fill 249 115 464 249 118 464 minecraft:brown_terracotta
setblock 249 115 503 minecraft:bone_block
fill 249 115 504 249 118 504 minecraft:brown_terracotta
setblock 250 115 502 minecraft:bone_block
fill 250 115 503 250 118 503 minecraft:brown_terracotta
fill 251 115 502 251 118 502 minecraft:brown_terracotta
setblock 253 115 504 minecraft:bone_block
fill 254 115 504 254 118 504 minecraft:brown_terracotta
fill 258 115 468 259 116 468 minecraft:bone_block
fill 265 115 504 265 117 504 minecraft:brown_terracotta
setblock 268 115 504 minecraft:bone_block
fill 269 115 504 270 117 504 minecraft:brown_terracotta
setblock 275 115 477 minecraft:bone_block
fill 275 115 478 275 118 478 minecraft:brown_terracotta
fill 276 115 472 276 118 472 minecraft:brown_terracotta
setblock 276 115 476 minecraft:bone_block
fill 276 115 477 276 118 477 minecraft:brown_terracotta
setblock 276 115 481 minecraft:bone_block
fill 276 115 482 276 118 482 minecraft:brown_terracotta
fill 236 116 471 236 119 471 minecraft:brown_terracotta
setblock 236 116 475 minecraft:bone_block
fill 236 116 476 236 119 476 minecraft:brown_terracotta
setblock 236 116 480 minecraft:bone_block
setblock 242 116 464 minecraft:bone_block
setblock 242 116 504 minecraft:bone_block
fill 243 116 464 243 119 464 minecraft:brown_terracotta
fill 243 116 504 243 119 504 minecraft:brown_terracotta
fill 244 116 503 244 119 503 minecraft:brown_terracotta
fill 246 116 502 248 116 502 minecraft:brown_terracotta
setblock 247 116 464 minecraft:bone_block
fill 247 116 465 247 119 465 minecraft:brown_terracotta
setblock 247 116 504 minecraft:bone_block
fill 248 116 464 248 119 464 minecraft:brown_terracotta
setblock 248 116 503 minecraft:bone_block
fill 248 116 504 248 119 504 minecraft:brown_terracotta
setblock 249 116 502 minecraft:bone_block
fill 249 116 503 249 119 503 minecraft:brown_terracotta
fill 250 116 502 250 119 502 minecraft:brown_terracotta
fill 252 116 502 252 117 502 minecraft:brown_terracotta
setblock 252 116 504 minecraft:bone_block
setblock 253 116 503 minecraft:bone_block
fill 253 116 504 253 119 504 minecraft:brown_terracotta
fill 254 116 503 254 119 503 minecraft:brown_terracotta
fill 256 116 497 260 117 501 minecraft:soul_soil
setblock 256 116 504 minecraft:brown_terracotta
fill 258 116 502 258 116 503 minecraft:soul_soil
fill 260 116 468 260 117 468 minecraft:bone_block
fill 263 116 504 264 118 504 minecraft:brown_terracotta
fill 266 116 503 267 116 503 minecraft:brown_terracotta
setblock 267 116 504 minecraft:bone_block
setblock 268 116 503 minecraft:bone_block
fill 268 116 504 268 119 504 minecraft:brown_terracotta
setblock 275 116 476 minecraft:bone_block
fill 275 116 477 275 119 477 minecraft:brown_terracotta
setblock 276 116 475 minecraft:bone_block
fill 276 116 476 276 119 476 minecraft:brown_terracotta
setblock 276 116 480 minecraft:bone_block
fill 276 116 481 276 119 481 minecraft:brown_terracotta
fill 276 116 483 276 117 483 minecraft:brown_terracotta
setblock 236 117 474 minecraft:bone_block
fill 236 117 475 236 120 475 minecraft:brown_terracotta
setblock 236 117 479 minecraft:bone_block
fill 236 117 480 236 119 481 minecraft:brown_terracotta
setblock 241 117 464 minecraft:bone_block
setblock 241 117 504 minecraft:bone_block
fill 242 117 464 242 120 464 minecraft:brown_terracotta
setblock 242 117 503 minecraft:bone_block
fill 242 117 504 242 120 504 minecraft:brown_terracotta
fill 243 117 503 243 120 503 minecraft:brown_terracotta
fill 244 117 502 247 117 502 minecraft:brown_terracotta
setblock 245 117 465 minecraft:bone_block
setblock 246 117 464 minecraft:bone_block
fill 246 117 465 246 120 465 minecraft:brown_terracotta
setblock 246 117 504 minecraft:bone_block
fill 247 117 464 247 120 464 minecraft:brown_terracotta
fill 247 117 501 248 117 501 minecraft:brown_terracotta
setblock 247 117 503 minecraft:bone_block
fill 247 117 504 247 120 504 minecraft:brown_terracotta
fill 248 117 465 248 118 465 minecraft:brown_terracotta
setblock 248 117 502 minecraft:bone_block
fill 248 117 503 248 120 503 minecraft:brown_terracotta
setblock 249 117 501 minecraft:bone_block
fill 249 117 502 249 120 502 minecraft:brown_terracotta
setblock 251 117 464 minecraft:bone_block
setblock 251 117 504 minecraft:bone_block
setblock 252 117 503 minecraft:bone_block
fill 252 117 504 252 120 504 minecraft:brown_terracotta
fill 253 117 503 253 120 503 minecraft:brown_terracotta
setblock 256 117 504 minecraft:bone_block
fill 257 117 504 260 117 504 minecraft:brown_terracotta
fill 261 117 468 262 118 468 minecraft:bone_block
setblock 261 117 504 minecraft:bone_block
fill 262 117 504 262 120 504 minecraft:brown_terracotta
fill 263 117 503 266 117 503 minecraft:brown_terracotta
setblock 266 117 504 minecraft:bone_block
fill 267 117 476 268 118 476 minecraft:soul_soil
setblock 267 117 503 minecraft:bone_block
fill 267 117 504 267 120 504 minecraft:brown_terracotta
fill 268 117 503 269 119 503 minecraft:brown_terracotta
setblock 271 117 504 minecraft:bone_block
setblock 275 117 475 minecraft:bone_block
fill 275 117 476 275 120 476 minecraft:brown_terracotta
setblock 275 117 480 minecraft:bone_block
fill 275 117 481 275 120 481 minecraft:brown_terracotta
setblock 276 117 474 minecraft:bone_block
fill 276 117 475 276 120 475 minecraft:brown_terracotta
setblock 276 117 479 minecraft:bone_block
fill 276 117 480 276 120 480 minecraft:brown_terracotta
setblock 236 118 473 minecraft:bone_block
fill 236 118 474 236 121 474 minecraft:brown_terracotta
setblock 236 118 478 minecraft:bone_block
fill 236 118 479 236 121 479 minecraft:brown_terracotta
setblock 237 118 477 minecraft:bone_block
setblock 239 118 464 minecraft:brown_terracotta
setblock 239 118 504 minecraft:brown_terracotta
setblock 240 118 464 minecraft:bone_block
setblock 240 118 504 minecraft:bone_block
fill 241 118 464 241 121 464 minecraft:brown_terracotta
setblock 241 118 503 minecraft:bone_block
fill 241 118 504 241 121 504 minecraft:brown_terracotta
fill 242 118 503 242 121 503 minecraft:brown_terracotta
setblock 243 118 465 minecraft:brown_terracotta
fill 243 118 502 246 118 502 minecraft:brown_terracotta
setblock 244 118 465 minecraft:bone_block
setblock 245 118 464 minecraft:bone_block
fill 245 118 465 245 121 465 minecraft:brown_terracotta
fill 245 118 501 247 118 501 minecraft:brown_terracotta
setblock 245 118 504 minecraft:bone_block
fill 246 118 464 246 121 464 minecraft:brown_terracotta
setblock 246 118 503 minecraft:bone_block
fill 246 118 504 246 121 504 minecraft:brown_terracotta
setblock 247 118 502 minecraft:bone_block
fill 247 118 503 247 121 503 minecraft:brown_terracotta
setblock 248 118 501 minecraft:bone_block
fill 248 118 502 248 121 502 minecraft:brown_terracotta
setblock 249 118 465 minecraft:bone_block
fill 249 118 501 250 120 501 minecraft:brown_terracotta
setblock 250 118 464 minecraft:bone_block
setblock 250 118 504 minecraft:bone_block
fill 251 118 464 252 120 464 minecraft:brown_terracotta
setblock 251 118 503 minecraft:bone_block
fill 251 118 504 251 121 504 minecraft:brown_terracotta
setblock 252 118 502 minecraft:bone_block
fill 252 118 503 252 121 503 minecraft:brown_terracotta
fill 253 118 502 253 121 502 minecraft:brown_terracotta
fill 254 118 498 256 119 498 minecraft:bone_block
fill 254 118 500 256 119 500 minecraft:bone_block
fill 255 118 499 255 119 499 minecraft:bone_block
setblock 255 118 503 minecraft:brown_terracotta
setblock 255 118 504 minecraft:bone_block
setblock 256 118 503 minecraft:bone_block
fill 256 118 504 259 118 504 minecraft:brown_terracotta
setblock 260 118 503 minecraft:brown_terracotta
setblock 260 118 504 minecraft:bone_block
setblock 261 118 503 minecraft:bone_block
fill 261 118 504 261 121 504 minecraft:brown_terracotta
fill 262 118 467 264 119 467 minecraft:bone_block
fill 262 118 469 264 119 469 minecraft:bone_block
fill 262 118 503 265 118 503 minecraft:brown_terracotta
fill 263 118 468 263 119 468 minecraft:bone_block
fill 264 118 502 266 118 502 minecraft:brown_terracotta
setblock 265 118 504 minecraft:bone_block
setblock 266 118 503 minecraft:bone_block
fill 266 118 504 266 121 504 minecraft:brown_terracotta
setblock 267 118 502 minecraft:bone_block
fill 267 118 503 267 121 503 minecraft:brown_terracotta
setblock 269 118 504 minecraft:brown_terracotta
setblock 270 118 504 minecraft:bone_block
fill 271 118 504 271 121 504 minecraft:brown_terracotta
fill 274 118 478 274 118 479 minecraft:brown_terracotta
fill 275 118 475 275 121 475 minecraft:brown_terracotta
setblock 275 118 479 minecraft:bone_block
fill 275 118 480 275 121 480 minecraft:brown_terracotta
fill 275 118 482 275 119 482 minecraft:brown_terracotta
setblock 276 118 473 minecraft:bone_block
fill 276 118 474 276 121 474 minecraft:brown_terracotta
setblock 276 118 478 minecraft:bone_block
fill 276 118 479 276 121 479 minecraft:brown_terracotta
setblock 276 118 483 minecraft:bone_block
fill 276 118 484 276 121 484 minecraft:brown_terracotta
fill 236 119 464 238 119 464 minecraft:brown_terracotta
setblock 236 119 472 minecraft:bone_block
fill 236 119 473 236 122 473 minecraft:brown_terracotta
setblock 236 119 477 minecraft:bone_block
fill 236 119 478 237 121 478 minecraft:brown_terracotta
setblock 236 119 482 minecraft:bone_block
fill 236 119 500 236 119 501 minecraft:brown_terracotta
setblock 236 119 502 minecraft:bone_block
fill 236 119 503 236 121 504 minecraft:brown_terracotta
setblock 237 119 476 minecraft:bone_block
fill 237 119 477 237 121 477 minecraft:brown_terracotta
fill 237 119 504 238 119 504 minecraft:brown_terracotta
setblock 239 119 464 minecraft:bone_block
setblock 239 119 503 minecraft:brown_terracotta
setblock 239 119 504 minecraft:bone_block
fill 240 119 464 240 122 464 minecraft:brown_terracotta
setblock 240 119 503 minecraft:bone_block
fill 240 119 504 240 122 504 minecraft:brown_terracotta
fill 241 119 465 242 119 465 minecraft:brown_terracotta
fill 241 119 503 241 122 503 minecraft:brown_terracotta
fill 242 119 502 245 119 502 minecraft:brown_terracotta
setblock 243 119 465 minecraft:bone_block
setblock 244 119 464 minecraft:bone_block
fill 244 119 465 244 122 465 minecraft:brown_terracotta
fill 244 119 501 246 119 501 minecraft:brown_terracotta
setblock 244 119 504 minecraft:bone_block
fill 245 119 464 245 122 464 minecraft:brown_terracotta
setblock 245 119 503 minecraft:bone_block
fill 245 119 504 245 122 504 minecraft:brown_terracotta
setblock 246 119 502 minecraft:bone_block
fill 246 119 503 246 122 503 minecraft:brown_terracotta
setblock 247 119 501 minecraft:bone_block
fill 247 119 502 247 122 502 minecraft:brown_terracotta
setblock 248 119 465 minecraft:bone_block
fill 248 119 501 248 122 501 minecraft:brown_terracotta
setblock 249 119 464 minecraft:bone_block
fill 249 119 465 249 122 465 minecraft:brown_terracotta
setblock 249 119 504 minecraft:bone_block
fill 250 119 464 250 122 464 minecraft:brown_terracotta
setblock 250 119 503 minecraft:bone_block
fill 250 119 504 250 122 504 minecraft:brown_terracotta
setblock 251 119 501 minecraft:brown_terracotta
setblock 251 119 502 minecraft:bone_block
fill 251 119 503 251 122 503 minecraft:brown_terracotta
fill 252 119 502 252 122 502 minecraft:brown_terracotta
setblock 254 119 504 minecraft:bone_block
setblock 255 119 503 minecraft:bone_block
fill 255 119 504 258 119 504 minecraft:brown_terracotta
fill 256 119 499 257 120 499 minecraft:bone_block
fill 256 119 503 259 119 503 minecraft:brown_terracotta
setblock 259 119 504 minecraft:bone_block
setblock 260 119 503 minecraft:bone_block
fill 260 119 504 260 122 504 minecraft:brown_terracotta
setblock 261 119 502 minecraft:bone_block
fill 261 119 503 264 119 503 minecraft:brown_terracotta
fill 262 119 502 265 119 502 minecraft:brown_terracotta
setblock 263 119 504 minecraft:brown_terracotta
setblock 264 119 464 minecraft:bone_block
setblock 264 119 504 minecraft:bone_block
fill 265 119 464 268 119 464 minecraft:brown_terracotta
setblock 265 119 503 minecraft:bone_block
fill 265 119 504 265 122 504 minecraft:brown_terracotta
setblock 266 119 502 minecraft:bone_block
fill 266 119 503 266 122 503 minecraft:brown_terracotta
fill 267 119 502 268 121 502 minecraft:brown_terracotta
setblock 269 119 464 minecraft:bone_block
setblock 269 119 504 minecraft:bone_block
setblock 270 119 503 minecraft:bone_block
fill 270 119 504 270 122 504 minecraft:brown_terracotta
fill 272 119 504 272 120 504 minecraft:brown_terracotta
setblock 274 119 478 minecraft:brown_terracotta
setblock 274 119 479 minecraft:bone_block
fill 274 119 480 274 122 480 minecraft:brown_terracotta
setblock 275 119 478 minecraft:bone_block
fill 275 119 479 275 122 479 minecraft:brown_terracotta
setblock 275 119 483 minecraft:bone_block
setblock 276 119 472 minecraft:bone_block
fill 276 119 473 276 122 473 minecraft:brown_terracotta
setblock 276 119 477 minecraft:bone_block
fill 276 119 478 276 122 478 minecraft:brown_terracotta
setblock 276 119 482 minecraft:bone_block
fill 276 119 483 276 122 483 minecraft:brown_terracotta
fill 276 119 485 276 120 485 minecraft:brown_terracotta
fill 236 120 464 236 120 465 minecraft:brown_terracotta
setblock 236 120 466 minecraft:bone_block
fill 236 120 467 236 123 467 minecraft:brown_terracotta
setblock 236 120 471 minecraft:bone_block
fill 236 120 472 236 122 472 minecraft:brown_terracotta
setblock 236 120 476 minecraft:bone_block
schedule function dropper:buildpart/113_5 1t
