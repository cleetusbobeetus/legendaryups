fill 164 103 223 164 188 223 minecraft:sculk
setblock 166 103 223 minecraft:sea_lantern
fill 179 103 223 180 106 223 minecraft:sculk
fill 181 103 223 182 103 223 minecraft:sea_lantern
fill 141 104 185 141 169 185 minecraft:sculk
fill 142 104 185 158 105 219 minecraft:black_concrete
fill 143 104 184 181 105 184 minecraft:black_concrete
fill 143 104 220 181 105 220 minecraft:black_concrete
fill 144 104 183 180 105 183 minecraft:black_concrete
fill 144 104 221 180 105 221 minecraft:black_concrete
fill 145 104 182 179 105 182 minecraft:black_concrete
fill 145 104 222 179 105 222 minecraft:black_concrete
setblock 150 104 181 minecraft:sea_lantern
fill 156 104 223 156 128 223 minecraft:sculk
fill 159 104 185 159 110 198 minecraft:black_concrete
fill 159 104 200 159 110 219 minecraft:black_concrete
fill 160 104 185 161 110 196 minecraft:black_concrete
fill 160 104 202 161 110 219 minecraft:black_concrete
setblock 161 104 223 minecraft:sea_lantern
fill 162 104 185 182 105 195 minecraft:black_concrete
fill 162 104 203 182 105 219 minecraft:black_concrete
fill 162 104 223 163 124 223 minecraft:sculk
fill 163 104 196 182 110 196 minecraft:black_concrete
fill 163 104 202 182 110 202 minecraft:black_concrete
fill 165 104 197 182 110 198 minecraft:black_concrete
fill 165 104 200 182 110 201 minecraft:black_concrete
fill 166 104 199 182 111 199 minecraft:black_concrete
fill 166 104 223 166 105 223 minecraft:sculk
setblock 176 104 181 minecraft:white_concrete
fill 181 104 223 182 106 223 minecraft:sculk
fill 150 105 181 150 111 181 minecraft:sculk
fill 161 105 223 161 184 223 minecraft:sculk
setblock 163 105 181 minecraft:white_concrete
fill 176 105 181 176 188 181 minecraft:sculk
fill 142 106 186 158 106 218 minecraft:black_concrete
fill 143 106 185 158 107 185 minecraft:black_concrete
fill 143 106 219 158 107 219 minecraft:black_concrete
fill 144 106 184 180 107 184 minecraft:black_concrete
fill 144 106 220 180 107 220 minecraft:black_concrete
fill 145 106 183 179 107 183 minecraft:black_concrete
fill 145 106 221 179 107 221 minecraft:black_concrete
fill 146 106 182 178 106 182 minecraft:black_concrete
fill 146 106 222 178 106 222 minecraft:black_concrete
fill 162 106 185 181 107 195 minecraft:black_concrete
fill 162 106 203 181 107 219 minecraft:black_concrete
fill 163 106 181 163 189 181 minecraft:sculk
setblock 166 106 223 minecraft:sea_lantern
fill 182 106 186 182 106 195 minecraft:black_concrete
fill 182 106 203 182 106 218 minecraft:black_concrete
setblock 141 107 221 minecraft:sea_lantern
fill 142 107 187 158 108 217 minecraft:black_concrete
fill 143 107 186 158 108 186 minecraft:black_concrete
fill 143 107 218 158 108 218 minecraft:black_concrete
fill 147 107 182 177 108 182 minecraft:black_concrete
fill 147 107 222 177 108 222 minecraft:black_concrete
fill 166 107 223 166 127 223 minecraft:sculk
setblock 173 107 223 minecraft:white_concrete
setblock 179 107 223 minecraft:sea_lantern
fill 180 107 223 181 120 223 minecraft:sculk
fill 182 107 187 182 108 195 minecraft:black_concrete
fill 182 107 203 182 108 217 minecraft:black_concrete
setblock 182 107 223 minecraft:sea_lantern
setblock 183 107 198 minecraft:sea_lantern
fill 141 108 221 141 109 221 minecraft:sculk
fill 144 108 185 158 108 185 minecraft:black_concrete
fill 144 108 219 158 108 219 minecraft:black_concrete
fill 145 108 184 179 108 184 minecraft:black_concrete
fill 145 108 220 179 108 220 minecraft:black_concrete
fill 146 108 183 178 108 183 minecraft:black_concrete
fill 146 108 221 178 108 221 minecraft:black_concrete
fill 162 108 185 180 108 195 minecraft:black_concrete
fill 162 108 203 180 108 219 minecraft:black_concrete
fill 173 108 223 173 134 223 minecraft:sculk
setblock 179 108 223 minecraft:sculk
fill 181 108 186 181 108 195 minecraft:black_concrete
fill 181 108 203 181 108 218 minecraft:black_concrete
fill 182 108 223 182 134 223 minecraft:sculk
fill 183 108 198 183 186 198 minecraft:sculk
fill 142 109 188 158 109 216 minecraft:black_concrete
fill 143 109 187 158 109 187 minecraft:black_concrete
fill 143 109 217 158 109 217 minecraft:black_concrete
fill 144 109 186 158 110 186 minecraft:black_concrete
fill 144 109 218 158 110 218 minecraft:black_concrete
fill 145 109 185 158 110 185 minecraft:black_concrete
fill 145 109 219 158 110 219 minecraft:black_concrete
fill 146 109 184 178 110 184 minecraft:black_concrete
fill 146 109 220 178 110 220 minecraft:black_concrete
fill 147 109 183 177 109 183 minecraft:black_concrete
fill 147 109 221 177 109 221 minecraft:black_concrete
fill 148 109 182 176 109 182 minecraft:black_concrete
fill 148 109 222 176 109 222 minecraft:black_concrete
fill 162 109 185 179 110 195 minecraft:black_concrete
fill 162 109 203 179 110 219 minecraft:black_concrete
setblock 171 109 223 minecraft:white_concrete
setblock 179 109 223 minecraft:white_concrete
fill 180 109 186 180 110 195 minecraft:black_concrete
fill 180 109 203 180 110 218 minecraft:black_concrete
fill 181 109 187 181 109 195 minecraft:black_concrete
fill 181 109 203 181 109 217 minecraft:black_concrete
fill 182 109 188 182 109 195 minecraft:black_concrete
fill 182 109 203 182 109 216 minecraft:black_concrete
setblock 141 110 221 minecraft:sea_lantern
fill 142 110 189 158 110 215 minecraft:black_concrete
fill 143 110 188 158 112 188 minecraft:black_concrete
fill 143 110 216 158 112 216 minecraft:black_concrete
fill 144 110 187 158 112 187 minecraft:black_concrete
fill 144 110 217 158 112 217 minecraft:black_concrete
fill 148 110 183 176 112 183 minecraft:black_concrete
fill 148 110 221 176 112 221 minecraft:black_concrete
fill 149 110 182 175 110 182 minecraft:black_concrete
fill 149 110 222 175 110 222 minecraft:black_concrete
fill 171 110 223 171 115 223 minecraft:sculk
fill 179 110 223 179 115 223 minecraft:sculk
fill 181 110 188 181 112 195 minecraft:black_concrete
fill 181 110 203 181 112 216 minecraft:black_concrete
fill 182 110 189 182 110 195 minecraft:black_concrete
fill 182 110 203 182 110 215 minecraft:black_concrete
fill 141 111 221 141 117 221 minecraft:sculk
fill 142 111 190 158 111 214 minecraft:black_concrete
fill 143 111 189 180 112 189 minecraft:black_concrete
fill 143 111 215 180 112 215 minecraft:black_concrete
fill 145 111 186 179 112 186 minecraft:black_concrete
fill 145 111 218 179 112 218 minecraft:black_concrete
fill 146 111 185 178 112 185 minecraft:black_concrete
fill 146 111 219 178 112 219 minecraft:black_concrete
fill 147 111 184 177 112 184 minecraft:black_concrete
fill 147 111 220 177 112 220 minecraft:black_concrete
fill 150 111 182 174 112 182 minecraft:black_concrete
fill 150 111 222 174 112 222 minecraft:black_concrete
fill 159 111 187 180 112 188 minecraft:black_concrete
fill 159 111 190 160 111 196 minecraft:black_concrete
fill 159 111 197 159 111 198 minecraft:sculk
fill 159 111 200 159 111 201 minecraft:sculk
fill 159 111 202 159 111 214 minecraft:black_concrete
fill 159 111 216 180 112 217 minecraft:black_concrete
fill 160 111 202 161 111 202 minecraft:sculk
fill 160 111 203 180 111 214 minecraft:black_concrete
fill 161 111 190 180 111 195 minecraft:black_concrete
setblock 161 111 196 minecraft:sculk
setblock 163 111 196 minecraft:sculk
fill 163 111 202 164 111 202 minecraft:sculk
fill 164 111 196 182 111 196 minecraft:black_concrete
fill 165 111 197 165 111 198 minecraft:sculk
fill 165 111 200 165 111 201 minecraft:sculk
fill 165 111 202 182 111 202 minecraft:black_concrete
fill 166 111 197 182 111 198 minecraft:black_concrete
fill 166 111 200 182 111 201 minecraft:black_concrete
fill 182 111 190 182 112 195 minecraft:black_concrete
fill 182 111 203 182 112 214 minecraft:black_concrete
fill 142 112 182 142 112 222 minecraft:black_concrete
fill 143 112 182 143 112 187 minecraft:black_concrete
fill 143 112 190 157 112 214 minecraft:black_concrete
fill 143 112 217 143 112 222 minecraft:black_concrete
fill 144 112 182 144 112 186 minecraft:black_concrete
fill 144 112 218 144 112 222 minecraft:black_concrete
fill 145 112 182 145 112 185 minecraft:black_concrete
fill 145 112 219 145 112 222 minecraft:black_concrete
fill 146 112 182 146 112 184 minecraft:black_concrete
fill 146 112 220 146 112 222 minecraft:black_concrete
fill 147 112 182 147 112 183 minecraft:black_concrete
fill 147 112 221 147 112 222 minecraft:black_concrete
fill 148 112 182 149 112 182 minecraft:black_concrete
fill 148 112 222 149 112 222 minecraft:black_concrete
setblock 150 112 181 minecraft:sea_lantern
setblock 152 112 223 minecraft:sea_lantern
fill 153 112 223 154 145 223 minecraft:sculk
fill 158 112 190 158 112 196 minecraft:black_concrete
setblock 158 112 197 minecraft:sculk
fill 158 112 198 158 112 200 minecraft:sea_lantern
fill 158 112 201 158 112 202 minecraft:sculk
fill 158 112 203 158 112 214 minecraft:black_concrete
fill 159 112 190 160 112 195 minecraft:black_concrete
fill 159 112 196 159 112 198 minecraft:sea_lantern
fill 159 112 200 159 112 202 minecraft:sea_lantern
fill 159 112 203 160 112 203 minecraft:sculk
fill 159 112 204 160 112 214 minecraft:black_concrete
fill 160 112 196 161 112 196 minecraft:sea_lantern
fill 160 112 202 161 112 202 minecraft:sea_lantern
fill 161 112 190 180 112 194 minecraft:black_concrete
fill 161 112 195 163 112 195 minecraft:sea_lantern
fill 161 112 203 163 112 203 minecraft:sea_lantern
fill 161 112 204 163 112 204 minecraft:sculk
fill 161 112 205 180 112 214 minecraft:black_concrete
fill 163 112 196 165 112 196 minecraft:sea_lantern
fill 163 112 202 165 112 202 minecraft:sea_lantern
fill 164 112 195 180 112 195 minecraft:black_concrete
fill 164 112 203 165 112 203 minecraft:sculk
fill 164 112 204 180 112 204 minecraft:black_concrete
fill 165 112 197 165 112 198 minecraft:sea_lantern
fill 165 112 200 165 112 201 minecraft:sea_lantern
fill 166 112 196 182 112 196 minecraft:black_concrete
setblock 166 112 197 minecraft:sculk
fill 166 112 198 166 112 200 minecraft:sea_lantern
fill 166 112 201 166 112 202 minecraft:sculk
fill 166 112 203 180 112 203 minecraft:black_concrete
fill 167 112 197 182 112 202 minecraft:black_concrete
fill 175 112 182 182 112 182 minecraft:black_concrete
fill 175 112 222 182 112 222 minecraft:black_concrete
fill 177 112 183 182 112 183 minecraft:black_concrete
fill 177 112 221 182 112 221 minecraft:black_concrete
fill 178 112 184 182 112 184 minecraft:black_concrete
fill 178 112 220 182 112 220 minecraft:black_concrete
fill 179 112 185 182 112 185 minecraft:black_concrete
fill 179 112 219 182 112 219 minecraft:black_concrete
fill 180 112 186 182 112 186 minecraft:black_concrete
fill 180 112 218 182 112 218 minecraft:black_concrete
fill 181 112 187 182 112 187 minecraft:black_concrete
fill 181 112 217 182 112 217 minecraft:black_concrete
fill 182 112 188 182 112 189 minecraft:black_concrete
fill 182 112 215 182 112 216 minecraft:black_concrete
fill 142 113 192 156 113 212 minecraft:black_concrete
fill 143 113 190 181 113 191 minecraft:black_concrete
fill 143 113 213 181 113 214 minecraft:black_concrete
setblock 144 113 184 minecraft:light[level=10]
fill 144 113 189 180 113 189 minecraft:black_concrete
fill 144 113 215 180 113 215 minecraft:black_concrete
setblock 144 113 216 minecraft:light[level=10]
fill 145 113 188 179 113 188 minecraft:black_concrete
fill 145 113 216 179 113 216 minecraft:black_concrete
fill 146 113 187 178 114 187 minecraft:black_concrete
fill 146 113 217 178 114 217 minecraft:black_concrete
fill 147 113 186 177 114 186 minecraft:black_concrete
fill 147 113 218 177 114 218 minecraft:black_concrete
fill 148 113 185 176 113 185 minecraft:black_concrete
fill 148 113 219 176 113 219 minecraft:black_concrete
fill 149 113 184 175 113 184 minecraft:black_concrete
fill 149 113 220 175 113 220 minecraft:black_concrete
fill 150 113 181 150 126 181 minecraft:sculk
fill 150 113 183 174 113 183 minecraft:black_concrete
fill 150 113 221 174 113 221 minecraft:black_concrete
fill 152 113 182 172 113 182 minecraft:black_concrete
fill 152 113 222 172 113 222 minecraft:black_concrete
fill 152 113 223 152 186 223 minecraft:sculk
fill 157 113 192 157 113 196 minecraft:black_concrete
fill 157 113 197 157 113 203 minecraft:sculk
fill 157 113 204 157 113 212 minecraft:black_concrete
setblock 158 113 181 minecraft:sea_lantern
fill 158 113 192 158 113 195 minecraft:black_concrete
setblock 158 113 196 minecraft:sculk
fill 158 113 203 158 113 204 minecraft:sculk
fill 158 113 205 159 113 212 minecraft:black_concrete
fill 159 113 192 160 113 194 minecraft:black_concrete
fill 159 113 195 160 113 195 minecraft:sculk
fill 159 113 204 160 113 204 minecraft:sculk
fill 160 113 205 164 113 205 minecraft:sculk
fill 160 113 206 182 113 212 minecraft:black_concrete
fill 161 113 192 182 113 193 minecraft:black_concrete
fill 161 113 194 163 113 194 minecraft:sculk
fill 164 113 194 182 113 194 minecraft:black_concrete
fill 164 113 195 165 113 195 minecraft:sculk
fill 164 113 204 166 113 204 minecraft:sculk
fill 165 113 205 182 113 205 minecraft:black_concrete
fill 166 113 195 182 113 195 minecraft:black_concrete
setblock 166 113 196 minecraft:sculk
fill 166 113 203 167 113 203 minecraft:sculk
fill 167 113 196 182 113 196 minecraft:black_concrete
fill 167 113 197 167 113 202 minecraft:sculk
fill 167 113 204 182 113 204 minecraft:black_concrete
fill 168 113 197 182 113 203 minecraft:black_concrete
setblock 176 113 184 minecraft:light[level=10]
setblock 183 113 204 minecraft:white_concrete
setblock 141 114 210 minecraft:sea_lantern
fill 142 114 193 154 114 211 minecraft:black_concrete
fill 143 114 191 181 114 192 minecraft:black_concrete
fill 143 114 212 181 114 213 minecraft:black_concrete
fill 144 114 190 180 114 190 minecraft:black_concrete
fill 144 114 214 180 114 214 minecraft:black_concrete
fill 145 114 189 179 114 189 minecraft:black_concrete
fill 145 114 215 179 114 215 minecraft:black_concrete
fill 146 114 188 178 115 188 minecraft:black_concrete
fill 146 114 216 178 115 216 minecraft:black_concrete
fill 149 114 185 175 114 185 minecraft:black_concrete
fill 149 114 219 175 114 219 minecraft:black_concrete
fill 150 114 184 174 114 184 minecraft:black_concrete
fill 150 114 220 174 114 220 minecraft:black_concrete
fill 151 114 183 173 114 183 minecraft:black_concrete
fill 151 114 221 173 114 221 minecraft:black_concrete
fill 153 114 182 171 114 182 minecraft:black_concrete
fill 153 114 222 171 114 222 minecraft:black_concrete
fill 155 114 193 155 114 199 minecraft:black_concrete
fill 155 114 200 156 114 200 minecraft:sculk
fill 155 114 201 155 114 211 minecraft:black_concrete
fill 156 114 193 156 114 196 minecraft:black_concrete
fill 156 114 197 156 114 199 minecraft:sculk
fill 156 114 201 156 114 203 minecraft:sculk
fill 156 114 204 156 114 211 minecraft:black_concrete
fill 157 114 193 157 114 195 minecraft:black_concrete
setblock 157 114 196 minecraft:sculk
fill 157 114 204 157 114 205 minecraft:sculk
fill 157 114 206 158 114 211 minecraft:black_concrete
fill 158 114 181 158 149 181 minecraft:sculk
fill 158 114 193 158 114 194 minecraft:black_concrete
setblock 158 114 195 minecraft:sculk
fill 158 114 205 159 114 205 minecraft:sculk
fill 159 114 193 160 114 193 minecraft:black_concrete
fill 159 114 194 160 114 194 minecraft:sculk
fill 159 114 206 165 114 206 minecraft:sculk
fill 159 114 207 160 114 211 minecraft:black_concrete
fill 161 114 193 163 115 193 minecraft:sculk
fill 161 114 207 163 114 207 minecraft:sculk
fill 161 114 208 182 114 211 minecraft:black_concrete
fill 164 114 193 182 114 193 minecraft:black_concrete
fill 164 114 194 165 114 194 minecraft:sculk
fill 164 114 207 182 114 207 minecraft:black_concrete
fill 165 114 205 167 114 205 minecraft:sculk
fill 166 114 194 182 114 194 minecraft:black_concrete
setblock 166 114 195 minecraft:sculk
fill 166 114 206 182 114 206 minecraft:black_concrete
fill 167 114 195 182 114 195 minecraft:black_concrete
setblock 167 114 196 minecraft:sculk
setblock 167 114 204 minecraft:sculk
fill 168 114 196 182 114 196 minecraft:black_concrete
fill 168 114 197 168 114 203 minecraft:sculk
fill 168 114 204 182 114 205 minecraft:black_concrete
fill 169 114 197 182 114 199 minecraft:black_concrete
setblock 169 114 200 minecraft:sculk
fill 169 114 201 182 114 203 minecraft:black_concrete
fill 170 114 200 182 114 200 minecraft:black_concrete
fill 183 114 204 183 188 204 minecraft:sculk
setblock 141 115 192 minecraft:sea_lantern
fill 141 115 210 141 185 210 minecraft:sculk
fill 142 115 195 153 115 209 minecraft:black_concrete
fill 143 115 193 157 115 194 minecraft:black_concrete
fill 143 115 210 181 115 211 minecraft:black_concrete
fill 144 115 191 180 115 192 minecraft:black_concrete
fill 144 115 212 180 115 213 minecraft:black_concrete
fill 145 115 190 179 115 190 minecraft:black_concrete
fill 145 115 214 179 115 214 minecraft:black_concrete
fill 146 115 189 178 116 189 minecraft:black_concrete
fill 146 115 215 178 116 215 minecraft:black_concrete
fill 147 115 187 177 115 187 minecraft:black_concrete
fill 147 115 217 177 115 217 minecraft:black_concrete
setblock 147 115 223 minecraft:sea_lantern
fill 148 115 186 176 115 186 minecraft:black_concrete
fill 148 115 218 176 115 218 minecraft:black_concrete
fill 150 115 185 174 115 185 minecraft:black_concrete
fill 150 115 219 174 115 219 minecraft:black_concrete
fill 151 115 184 173 115 184 minecraft:black_concrete
fill 151 115 220 173 115 220 minecraft:black_concrete
fill 153 115 183 171 115 183 minecraft:black_concrete
fill 153 115 221 171 115 221 minecraft:black_concrete
fill 154 115 195 154 115 199 minecraft:black_concrete
fill 154 115 200 154 115 201 minecraft:sculk
fill 154 115 202 154 115 209 minecraft:black_concrete
fill 155 115 182 169 115 182 minecraft:black_concrete
fill 155 115 195 155 115 196 minecraft:black_concrete
fill 155 115 197 155 115 199 minecraft:sculk
fill 155 115 201 155 115 204 minecraft:sculk
fill 155 115 205 155 115 209 minecraft:black_concrete
fill 155 115 222 169 115 222 minecraft:black_concrete
setblock 156 115 195 minecraft:black_concrete
setblock 156 115 196 minecraft:sculk
fill 156 115 204 156 115 205 minecraft:sculk
fill 156 115 206 156 115 209 minecraft:black_concrete
setblock 157 115 195 minecraft:sculk
fill 157 115 206 158 115 206 minecraft:sculk
fill 157 115 207 157 115 209 minecraft:black_concrete
setblock 158 115 193 minecraft:black_concrete
setblock 158 115 194 minecraft:sculk
fill 158 115 207 160 115 207 minecraft:sculk
fill 158 115 208 158 115 209 minecraft:black_concrete
fill 159 115 193 160 115 193 minecraft:sculk
fill 159 115 208 165 115 208 minecraft:sculk
fill 159 115 209 182 115 209 minecraft:black_concrete
fill 164 115 193 165 115 193 minecraft:sculk
fill 164 115 207 166 115 207 minecraft:sculk
fill 166 115 193 181 115 193 minecraft:black_concrete
setblock 166 115 194 minecraft:sculk
fill 166 115 206 167 115 206 minecraft:sculk
fill 166 115 208 182 115 208 minecraft:black_concrete
fill 167 115 194 181 115 194 minecraft:black_concrete
setblock 167 115 195 minecraft:sculk
fill 167 115 207 182 115 207 minecraft:black_concrete
fill 168 115 195 182 115 195 minecraft:black_concrete
setblock 168 115 196 minecraft:sculk
fill 168 115 204 168 115 205 minecraft:sculk
fill 168 115 206 182 115 206 minecraft:black_concrete
fill 169 115 196 182 115 196 minecraft:black_concrete
fill 169 115 197 169 115 199 minecraft:sculk
fill 169 115 201 169 115 204 minecraft:sculk
fill 169 115 205 182 115 205 minecraft:black_concrete
fill 170 115 197 182 115 199 minecraft:black_concrete
fill 170 115 200 170 115 201 minecraft:sculk
fill 170 115 202 182 115 204 minecraft:black_concrete
fill 171 115 200 182 115 201 minecraft:black_concrete
setblock 183 115 197 minecraft:sea_lantern
fill 141 116 192 141 188 192 minecraft:sculk
setblock 141 116 199 minecraft:white_concrete
fill 142 116 197 152 116 207 minecraft:black_concrete
fill 143 116 194 154 116 196 minecraft:black_concrete
fill 143 116 208 156 116 210 minecraft:black_concrete
setblock 144 116 181 minecraft:sea_lantern
fill 144 116 192 157 116 193 minecraft:black_concrete
fill 144 116 211 180 116 212 minecraft:black_concrete
fill 145 116 191 179 116 191 minecraft:black_concrete
fill 145 116 213 179 116 213 minecraft:black_concrete
fill 146 116 190 178 116 190 minecraft:black_concrete
fill 146 116 214 178 116 214 minecraft:black_concrete
fill 147 116 188 177 116 188 minecraft:black_concrete
fill 147 116 216 177 116 216 minecraft:black_concrete
fill 147 116 223 147 127 223 minecraft:sculk
fill 148 116 187 176 116 187 minecraft:black_concrete
fill 148 116 217 176 116 217 minecraft:black_concrete
fill 149 116 186 175 116 186 minecraft:black_concrete
fill 149 116 218 175 116 218 minecraft:black_concrete
fill 151 116 185 173 116 185 minecraft:black_concrete
fill 151 116 219 173 116 219 minecraft:black_concrete
fill 152 116 184 172 116 184 minecraft:black_concrete
fill 152 116 220 172 116 220 minecraft:black_concrete
fill 153 116 197 153 116 198 minecraft:black_concrete
fill 153 116 199 153 116 202 minecraft:sculk
fill 153 116 203 153 116 207 minecraft:black_concrete
fill 154 116 183 170 116 183 minecraft:black_concrete
fill 154 116 197 154 116 199 minecraft:sculk
fill 154 116 202 154 116 205 minecraft:sculk
fill 154 116 206 154 116 207 minecraft:black_concrete
fill 154 116 221 170 116 221 minecraft:black_concrete
setblock 155 116 194 minecraft:black_concrete
fill 155 116 195 155 116 196 minecraft:sculk
fill 155 116 205 155 116 206 minecraft:sculk
setblock 155 116 207 minecraft:black_concrete
fill 156 116 194 156 116 195 minecraft:sculk
fill 156 116 206 156 116 207 minecraft:sculk
fill 157 116 182 167 116 182 minecraft:black_concrete
setblock 157 116 194 minecraft:sculk
fill 157 116 207 157 116 208 minecraft:sculk
fill 157 116 209 157 116 210 minecraft:black_concrete
fill 157 116 222 167 116 222 minecraft:black_concrete
setblock 158 116 192 minecraft:black_concrete
setblock 158 116 193 minecraft:sculk
fill 158 116 208 158 116 209 minecraft:sculk
fill 158 116 210 161 116 210 minecraft:black_concrete
fill 159 116 192 165 116 192 minecraft:sculk
fill 159 116 209 166 116 209 minecraft:sculk
setblock 162 116 210 minecraft:sculk
fill 163 116 210 181 116 210 minecraft:black_concrete
setblock 166 116 181 minecraft:sea_lantern
fill 166 116 192 180 116 192 minecraft:black_concrete
setblock 166 116 193 minecraft:sculk
fill 166 116 208 167 116 208 minecraft:sculk
fill 167 116 181 168 131 181 minecraft:sculk
fill 167 116 193 180 116 193 minecraft:black_concrete
fill 167 116 194 168 116 194 minecraft:sculk
fill 167 116 207 168 116 207 minecraft:sculk
fill 167 116 209 181 116 209 minecraft:black_concrete
fill 168 116 195 169 116 195 minecraft:sculk
fill 168 116 206 169 116 206 minecraft:sculk
fill 168 116 208 181 116 208 minecraft:black_concrete
fill 169 116 194 181 116 194 minecraft:black_concrete
setblock 169 116 196 minecraft:sculk
fill 169 116 205 170 116 205 minecraft:sculk
fill 169 116 207 182 116 207 minecraft:black_concrete
fill 170 116 195 181 116 196 minecraft:black_concrete
fill 170 116 197 170 116 199 minecraft:sculk
fill 170 116 202 170 116 204 minecraft:sculk
fill 170 116 206 182 116 206 minecraft:black_concrete
fill 171 116 197 182 116 198 minecraft:black_concrete
fill 171 116 199 171 116 202 minecraft:sculk
fill 171 116 203 182 116 205 minecraft:black_concrete
setblock 171 116 223 minecraft:white_concrete
fill 172 116 199 182 116 202 minecraft:black_concrete
setblock 179 116 223 minecraft:sea_lantern
fill 183 116 197 183 134 197 minecraft:sculk
fill 141 117 199 141 188 199 minecraft:sculk
fill 143 117 197 151 117 207 minecraft:black_concrete
fill 144 117 181 144 188 181 minecraft:sculk
fill 144 117 194 153 117 196 minecraft:black_concrete
fill 144 117 208 154 117 210 minecraft:black_concrete
fill 145 117 192 155 117 193 minecraft:black_concrete
fill 145 117 211 159 117 212 minecraft:black_concrete
fill 146 117 191 159 117 191 minecraft:black_concrete
fill 146 117 213 178 117 213 minecraft:black_concrete
fill 147 117 189 177 117 190 minecraft:black_concrete
fill 147 117 214 177 117 215 minecraft:black_concrete
fill 148 117 188 176 117 188 minecraft:black_concrete
fill 148 117 216 176 117 216 minecraft:black_concrete
fill 149 117 187 175 117 187 minecraft:black_concrete
fill 149 117 217 175 117 217 minecraft:black_concrete
fill 151 117 186 173 117 186 minecraft:black_concrete
fill 151 117 218 173 117 218 minecraft:black_concrete
fill 152 117 185 172 117 185 minecraft:black_concrete
fill 152 117 197 152 117 198 minecraft:black_concrete
fill 152 117 199 152 117 203 minecraft:sculk
fill 152 117 204 152 117 207 minecraft:black_concrete
fill 152 117 219 172 117 219 minecraft:black_concrete
fill 153 117 197 153 117 198 minecraft:sculk
fill 153 117 203 153 117 206 minecraft:sculk
setblock 153 117 207 minecraft:black_concrete
fill 154 117 184 170 117 184 minecraft:black_concrete
setblock 154 117 194 minecraft:black_concrete
fill 154 117 195 154 117 196 minecraft:sculk
fill 154 117 206 154 117 207 minecraft:sculk
fill 154 117 220 170 117 220 minecraft:black_concrete
setblock 155 117 194 minecraft:sculk
fill 155 117 207 155 117 208 minecraft:sculk
fill 155 117 209 155 117 210 minecraft:black_concrete
fill 156 117 192 157 117 192 minecraft:black_concrete
fill 156 117 193 157 117 193 minecraft:sculk
fill 156 117 208 156 117 209 minecraft:sculk
setblock 156 117 210 minecraft:black_concrete
fill 157 117 183 167 117 183 minecraft:black_concrete
fill 157 117 209 157 117 210 minecraft:sculk
fill 157 117 221 167 117 221 minecraft:black_concrete
fill 158 117 192 159 117 192 minecraft:sculk
fill 158 117 210 161 117 210 minecraft:sculk
fill 160 117 191 164 117 191 minecraft:sculk
fill 160 117 211 164 117 211 minecraft:sculk
fill 160 117 212 179 117 212 minecraft:black_concrete
fill 163 117 210 167 117 210 minecraft:sculk
fill 165 117 191 178 117 191 minecraft:black_concrete
fill 165 117 192 166 117 192 minecraft:sculk
fill 165 117 211 179 117 211 minecraft:black_concrete
fill 166 117 181 166 133 181 minecraft:sculk
fill 167 117 192 179 117 192 minecraft:black_concrete
fill 167 117 193 168 117 193 minecraft:sculk
fill 167 117 209 168 117 209 minecraft:sculk
fill 168 117 208 169 117 208 minecraft:sculk
fill 168 117 210 180 117 210 minecraft:black_concrete
fill 169 117 193 179 117 193 minecraft:black_concrete
setblock 169 117 194 minecraft:sculk
fill 169 117 207 170 117 207 minecraft:sculk
fill 169 117 209 180 117 209 minecraft:black_concrete
fill 170 117 194 180 117 194 minecraft:black_concrete
fill 170 117 195 170 117 196 minecraft:sculk
fill 170 117 206 171 117 206 minecraft:sculk
fill 170 117 208 180 117 208 minecraft:black_concrete
setblock 171 117 181 minecraft:sea_lantern
fill 171 117 195 180 117 196 minecraft:black_concrete
fill 171 117 197 171 117 198 minecraft:sculk
fill 171 117 203 171 117 205 minecraft:sculk
fill 171 117 207 181 117 207 minecraft:black_concrete
setblock 171 117 223 minecraft:sculk
fill 172 117 197 181 117 198 minecraft:black_concrete
fill 172 117 199 172 117 203 minecraft:sculk
fill 172 117 204 181 117 206 minecraft:black_concrete
fill 173 117 199 181 117 203 minecraft:black_concrete
fill 179 117 223 179 162 223 minecraft:sculk
fill 141 118 189 141 119 189 minecraft:cyan_concrete
fill 141 118 205 141 119 205 minecraft:cyan_concrete
fill 141 118 221 141 119 221 minecraft:cyan_concrete
fill 144 118 197 150 118 207 minecraft:black_concrete
fill 145 118 181 145 119 181 minecraft:cyan_concrete
fill 145 118 194 152 118 196 minecraft:black_concrete
fill 145 118 208 152 118 210 minecraft:black_concrete
fill 146 118 192 154 118 193 minecraft:black_concrete
fill 146 118 211 155 118 212 minecraft:black_concrete
fill 147 118 191 157 118 191 minecraft:black_concrete
fill 147 118 213 177 118 213 minecraft:black_concrete
fill 148 118 190 160 118 190 minecraft:black_concrete
fill 148 118 214 176 118 214 minecraft:black_concrete
fill 149 118 189 175 118 189 minecraft:black_concrete
fill 149 118 215 175 118 215 minecraft:black_concrete
fill 150 118 188 174 118 188 minecraft:black_concrete
fill 150 118 216 174 118 216 minecraft:black_concrete
fill 151 118 187 173 118 187 minecraft:black_concrete
fill 151 118 197 151 118 198 minecraft:black_concrete
fill 151 118 199 151 118 204 minecraft:sculk
fill 151 118 205 151 118 207 minecraft:black_concrete
fill 151 118 217 173 118 217 minecraft:black_concrete
fill 152 118 186 172 118 186 minecraft:black_concrete
fill 152 118 197 152 118 198 minecraft:sculk
fill 152 118 204 152 118 206 minecraft:sculk
setblock 152 118 207 minecraft:black_concrete
fill 152 118 218 172 118 218 minecraft:black_concrete
setblock 153 118 181 minecraft:sea_lantern
setblock 153 118 194 minecraft:black_concrete
fill 153 118 195 153 118 196 minecraft:sculk
fill 153 118 202 153 119 202 minecraft:bone_block
fill 153 118 207 153 118 208 minecraft:sculk
fill 153 118 209 153 118 210 minecraft:black_concrete
fill 154 118 185 170 118 185 minecraft:black_concrete
setblock 154 118 194 minecraft:sculk
setblock 154 118 199 minecraft:bone_block
setblock 154 118 205 minecraft:bone_block
fill 154 118 208 154 118 209 minecraft:sculk
setblock 154 118 210 minecraft:black_concrete
fill 154 118 219 170 118 219 minecraft:black_concrete
setblock 155 118 192 minecraft:black_concrete
setblock 155 118 193 minecraft:sculk
fill 155 118 209 155 118 210 minecraft:sculk
fill 155 118 223 155 119 223 minecraft:cyan_concrete
fill 156 118 192 157 118 192 minecraft:sculk
setblock 156 118 196 minecraft:bone_block
setblock 156 118 208 minecraft:bone_block
fill 156 118 210 156 118 211 minecraft:sculk
fill 156 118 212 157 118 212 minecraft:black_concrete
fill 157 118 184 167 118 184 minecraft:black_concrete
fill 157 118 211 159 118 211 minecraft:sculk
fill 157 118 220 167 118 220 minecraft:black_concrete
fill 158 118 191 160 118 191 minecraft:sculk
fill 158 118 212 166 118 212 minecraft:sculk
setblock 159 118 194 minecraft:bone_block
setblock 159 118 210 minecraft:bone_block
fill 161 118 181 161 119 181 minecraft:cyan_concrete
fill 161 118 190 163 119 190 minecraft:sculk
fill 162 118 193 162 119 193 minecraft:bone_block
fill 162 118 211 162 119 211 minecraft:bone_block
fill 164 118 190 176 118 190 minecraft:black_concrete
fill 164 118 191 166 118 191 minecraft:sculk
setblock 165 118 194 minecraft:bone_block
setblock 165 118 210 minecraft:bone_block
fill 165 118 211 168 118 211 minecraft:sculk
fill 167 118 191 177 118 191 minecraft:black_concrete
fill 167 118 192 168 118 192 minecraft:sculk
fill 167 118 212 178 118 212 minecraft:black_concrete
setblock 168 118 196 minecraft:bone_block
setblock 168 118 208 minecraft:bone_block
fill 168 118 210 169 118 210 minecraft:sculk
fill 169 118 192 178 118 192 minecraft:black_concrete
setblock 169 118 193 minecraft:sculk
fill 169 118 209 170 118 209 minecraft:sculk
fill 169 118 211 178 118 211 minecraft:black_concrete
fill 170 118 193 178 118 193 minecraft:black_concrete
setblock 170 118 194 minecraft:sculk
setblock 170 118 199 minecraft:bone_block
setblock 170 118 205 minecraft:bone_block
fill 170 118 208 171 118 208 minecraft:sculk
fill 170 118 210 179 118 210 minecraft:black_concrete
fill 171 118 181 171 140 181 minecraft:sculk
fill 171 118 194 179 118 194 minecraft:black_concrete
fill 171 118 195 171 118 196 minecraft:sculk
fill 171 118 202 171 119 202 minecraft:bone_block
setblock 171 118 207 minecraft:sculk
fill 171 118 209 179 118 209 minecraft:black_concrete
fill 171 118 223 171 119 223 minecraft:cyan_concrete
fill 172 118 195 179 118 196 minecraft:black_concrete
fill 172 118 197 172 118 198 minecraft:sculk
fill 172 118 204 172 118 206 minecraft:sculk
fill 172 118 207 179 118 208 minecraft:black_concrete
fill 173 118 197 180 118 198 minecraft:black_concrete
fill 173 118 199 173 118 204 minecraft:sculk
fill 173 118 205 180 118 206 minecraft:black_concrete
fill 174 118 199 180 118 204 minecraft:black_concrete
fill 177 118 181 177 119 181 minecraft:cyan_concrete
setblock 180 118 207 minecraft:black_concrete
fill 183 118 191 183 119 191 minecraft:cyan_concrete
fill 183 118 207 183 119 207 minecraft:cyan_concrete
fill 145 119 197 149 119 207 minecraft:black_concrete
fill 146 119 195 150 119 196 minecraft:black_concrete
fill 146 119 208 151 119 209 minecraft:black_concrete
fill 147 119 193 152 119 194 minecraft:black_concrete
fill 147 119 210 152 119 211 minecraft:black_concrete
fill 148 119 191 154 119 192 minecraft:black_concrete
fill 148 119 212 154 119 213 minecraft:black_concrete
fill 149 119 190 157 119 190 minecraft:black_concrete
fill 149 119 214 159 119 214 minecraft:black_concrete
fill 150 119 189 174 119 189 minecraft:black_concrete
fill 150 119 197 150 119 198 minecraft:black_concrete
fill 150 119 199 150 119 205 minecraft:sculk
fill 150 119 206 150 119 207 minecraft:black_concrete
fill 150 119 215 174 119 215 minecraft:black_concrete
fill 151 119 188 173 119 188 minecraft:black_concrete
setblock 151 119 195 minecraft:black_concrete
fill 151 119 196 151 119 198 minecraft:sculk
fill 151 119 202 152 120 202 minecraft:bone_block
fill 151 119 205 151 119 207 minecraft:sculk
fill 151 119 216 173 119 216 minecraft:black_concrete
fill 152 119 195 152 119 196 minecraft:sculk
fill 152 119 197 152 120 198 minecraft:bone_block
fill 152 119 206 152 120 207 minecraft:bone_block
fill 152 119 208 152 119 209 minecraft:sculk
fill 153 119 181 153 126 181 minecraft:sculk
fill 153 119 187 171 119 187 minecraft:black_concrete
setblock 153 119 193 minecraft:black_concrete
setblock 153 119 194 minecraft:sculk
fill 153 119 198 153 119 199 minecraft:bone_block
fill 153 119 205 153 119 206 minecraft:bone_block
fill 153 119 209 153 119 210 minecraft:sculk
setblock 153 119 211 minecraft:black_concrete
fill 153 119 217 171 119 217 minecraft:black_concrete
setblock 154 119 193 minecraft:sculk
fill 154 119 194 155 120 195 minecraft:bone_block
fill 154 119 209 155 120 210 minecraft:bone_block
fill 154 119 211 155 119 211 minecraft:sculk
fill 155 119 186 169 119 186 minecraft:black_concrete
setblock 155 119 191 minecraft:black_concrete
setblock 155 119 192 minecraft:sculk
fill 155 119 212 156 119 212 minecraft:sculk
fill 155 119 213 156 119 213 minecraft:black_concrete
fill 155 119 218 169 119 218 minecraft:black_concrete
fill 156 119 191 157 119 191 minecraft:sculk
fill 157 119 185 167 119 185 minecraft:black_concrete
fill 157 119 192 158 120 192 minecraft:bone_block
fill 157 119 212 158 120 212 minecraft:bone_block
fill 157 119 213 161 119 213 minecraft:sculk
fill 157 119 219 167 119 219 minecraft:black_concrete
fill 158 119 190 160 119 190 minecraft:sculk
fill 158 119 193 159 119 193 minecraft:bone_block
fill 158 119 211 159 119 211 minecraft:bone_block
fill 160 119 214 164 119 214 minecraft:sculk
fill 162 119 191 162 120 192 minecraft:bone_block
fill 162 119 212 162 120 213 minecraft:bone_block
fill 163 119 213 167 119 213 minecraft:sculk
fill 164 119 190 166 119 190 minecraft:sculk
fill 165 119 193 166 119 193 minecraft:bone_block
fill 165 119 211 166 119 211 minecraft:bone_block
fill 165 119 214 175 119 214 minecraft:black_concrete
fill 166 119 192 167 120 192 minecraft:bone_block
fill 166 119 212 167 120 212 minecraft:bone_block
fill 167 119 190 175 119 190 minecraft:black_concrete
fill 167 119 191 168 119 191 minecraft:sculk
fill 168 119 212 169 119 212 minecraft:sculk
fill 168 119 213 176 119 213 minecraft:black_concrete
fill 169 119 191 176 119 191 minecraft:black_concrete
setblock 169 119 192 minecraft:sculk
fill 169 119 194 170 120 195 minecraft:bone_block
fill 169 119 209 170 120 210 minecraft:bone_block
fill 169 119 211 170 119 211 minecraft:sculk
fill 170 119 192 176 119 192 minecraft:black_concrete
setblock 170 119 193 minecraft:sculk
fill 170 119 212 176 119 212 minecraft:black_concrete
fill 171 119 193 177 119 193 minecraft:black_concrete
setblock 171 119 194 minecraft:sculk
fill 171 119 198 171 119 199 minecraft:bone_block
fill 171 119 205 171 119 206 minecraft:bone_block
fill 171 119 209 171 119 210 minecraft:sculk
fill 171 119 211 177 119 211 minecraft:black_concrete
fill 172 119 194 177 119 194 minecraft:black_concrete
fill 172 119 195 172 119 196 minecraft:sculk
fill 172 119 197 172 120 198 minecraft:bone_block
fill 172 119 202 173 120 202 minecraft:bone_block
fill 172 119 206 172 120 207 minecraft:bone_block
fill 172 119 208 172 119 209 minecraft:sculk
fill 172 119 210 177 119 210 minecraft:black_concrete
fill 173 119 195 178 119 195 minecraft:black_concrete
fill 173 119 196 173 119 198 minecraft:sculk
fill 173 119 205 173 119 207 minecraft:sculk
fill 173 119 208 178 119 209 minecraft:black_concrete
fill 174 119 196 178 119 198 minecraft:black_concrete
fill 174 119 199 174 119 205 minecraft:sculk
fill 174 119 206 179 119 207 minecraft:black_concrete
fill 175 119 199 179 119 205 minecraft:black_concrete
fill 179 119 197 179 119 198 minecraft:black_concrete
fill 141 120 189 141 126 189 minecraft:sculk
setblock 141 120 196 minecraft:white_concrete
fill 141 120 205 141 126 205 minecraft:sculk
fill 141 120 221 141 126 221 minecraft:sculk
fill 145 120 181 145 126 181 minecraft:sculk
fill 145 120 205 146 120 207 minecraft:polished_blackstone
fill 146 120 200 148 120 204 minecraft:black_concrete
fill 147 120 196 148 120 199 minecraft:black_concrete
fill 147 120 205 148 120 208 minecraft:black_concrete
fill 148 120 194 150 120 195 minecraft:black_concrete
fill 148 120 209 150 120 210 minecraft:black_concrete
fill 149 120 193 152 120 193 minecraft:black_concrete
fill 149 120 196 149 120 198 minecraft:black_concrete
fill 149 120 199 149 120 200 minecraft:sculk
fill 149 120 201 150 121 203 minecraft:bone_block
fill 149 120 204 149 120 205 minecraft:sculk
fill 149 120 206 149 120 208 minecraft:black_concrete
fill 149 120 211 152 120 211 minecraft:black_concrete
fill 150 120 192 153 120 192 minecraft:black_concrete
setblock 150 120 196 minecraft:sculk
fill 150 120 197 151 121 198 minecraft:bone_block
fill 150 120 206 151 121 207 minecraft:bone_block
setblock 150 120 208 minecraft:black_concrete
fill 150 120 212 153 120 212 minecraft:black_concrete
fill 151 120 191 154 120 191 minecraft:black_concrete
setblock 151 120 194 minecraft:black_concrete
setblock 151 120 195 minecraft:sculk
setblock 151 120 201 minecraft:bone_block
setblock 151 120 203 minecraft:bone_block
fill 151 120 208 151 120 209 minecraft:sculk
setblock 151 120 210 minecraft:black_concrete
fill 151 120 213 154 120 213 minecraft:black_concrete
fill 152 120 190 155 120 190 minecraft:black_concrete
setblock 152 120 194 minecraft:sculk
setblock 152 120 210 minecraft:sculk
fill 152 120 214 156 120 214 minecraft:black_concrete
fill 153 120 189 158 120 189 minecraft:black_concrete
fill 153 120 193 153 121 194 minecraft:bone_block
setblock 153 120 198 minecraft:bone_block
setblock 153 120 206 minecraft:bone_block
fill 153 120 210 153 121 211 minecraft:bone_block
fill 153 120 215 159 120 215 minecraft:black_concrete
fill 154 120 188 170 120 188 minecraft:black_concrete
setblock 154 120 192 minecraft:sculk
fill 154 120 193 154 121 193 minecraft:bone_block
fill 154 120 211 154 121 211 minecraft:bone_block
setblock 154 120 212 minecraft:sculk
fill 154 120 216 170 120 216 minecraft:black_concrete
setblock 155 120 191 minecraft:sculk
fill 155 120 213 156 120 213 minecraft:sculk
fill 155 120 223 155 126 223 minecraft:sculk
fill 156 120 187 168 120 187 minecraft:black_concrete
setblock 156 120 190 minecraft:sculk
fill 156 120 217 168 120 217 minecraft:black_concrete
fill 157 120 190 158 121 191 minecraft:bone_block
fill 157 120 213 158 121 214 minecraft:bone_block
setblock 157 120 223 minecraft:white_concrete
setblock 158 120 193 minecraft:bone_block
setblock 158 120 211 minecraft:bone_block
fill 158 120 223 158 127 223 minecraft:sculk
fill 159 120 189 160 120 189 minecraft:sculk
setblock 159 120 214 minecraft:sculk
fill 160 120 186 164 120 186 minecraft:black_concrete
setblock 160 120 215 minecraft:sculk
fill 160 120 218 164 120 218 minecraft:black_concrete
fill 161 120 181 161 126 181 minecraft:sculk
fill 161 120 189 161 120 191 minecraft:bone_block
fill 161 120 213 161 120 215 minecraft:bone_block
fill 162 120 189 163 121 190 minecraft:bone_block
fill 162 120 214 163 121 215 minecraft:bone_block
setblock 163 120 191 minecraft:bone_block
setblock 163 120 213 minecraft:bone_block
fill 164 120 189 165 120 189 minecraft:sculk
setblock 164 120 215 minecraft:sculk
setblock 165 120 214 minecraft:sculk
fill 165 120 215 171 120 215 minecraft:black_concrete
fill 166 120 189 171 120 189 minecraft:black_concrete
fill 166 120 190 167 121 191 minecraft:bone_block
setblock 166 120 193 minecraft:bone_block
setblock 166 120 211 minecraft:bone_block
fill 166 120 213 167 121 214 minecraft:bone_block
setblock 168 120 190 minecraft:sculk
fill 168 120 213 169 120 213 minecraft:sculk
fill 168 120 214 172 120 214 minecraft:black_concrete
fill 169 120 190 172 120 190 minecraft:black_concrete
setblock 169 120 191 minecraft:sculk
fill 170 120 191 173 120 191 minecraft:black_concrete
setblock 170 120 192 minecraft:sculk
fill 170 120 193 171 121 193 minecraft:bone_block
fill 170 120 211 171 121 211 minecraft:bone_block
setblock 170 120 212 minecraft:sculk
fill 170 120 213 173 120 213 minecraft:black_concrete
fill 171 120 192 174 120 192 minecraft:black_concrete
fill 171 120 194 171 121 194 minecraft:bone_block
setblock 171 120 198 minecraft:bone_block
setblock 171 120 206 minecraft:bone_block
fill 171 120 210 171 121 210 minecraft:bone_block
fill 171 120 212 174 120 212 minecraft:black_concrete
fill 171 120 223 171 126 223 minecraft:sculk
fill 172 120 193 175 120 193 minecraft:black_concrete
setblock 172 120 194 minecraft:sculk
setblock 172 120 210 minecraft:sculk
fill 172 120 211 175 120 211 minecraft:black_concrete
fill 173 120 194 176 120 194 minecraft:black_concrete
setblock 173 120 195 minecraft:sculk
fill 173 120 197 174 121 198 minecraft:bone_block
fill 173 120 201 175 120 201 minecraft:bone_block
fill 173 120 203 175 120 203 minecraft:bone_block
fill 173 120 206 174 121 207 minecraft:bone_block
fill 173 120 208 173 120 209 minecraft:sculk
fill 173 120 210 176 120 210 minecraft:black_concrete
fill 174 120 195 176 120 195 minecraft:black_concrete
setblock 174 120 196 minecraft:sculk
fill 174 120 202 175 121 202 minecraft:bone_block
fill 174 120 208 176 120 209 minecraft:black_concrete
fill 175 120 196 177 120 198 minecraft:black_concrete
fill 175 120 199 175 120 200 minecraft:sculk
fill 175 120 204 175 120 205 minecraft:sculk
fill 175 120 206 177 120 207 minecraft:black_concrete
fill 176 120 199 177 120 205 minecraft:black_concrete
fill 177 120 181 177 126 181 minecraft:sculk
setblock 177 120 208 minecraft:black_concrete
fill 178 120 200 178 120 204 minecraft:black_concrete
fill 183 120 191 183 126 191 minecraft:sculk
setblock 183 120 195 minecraft:sea_lantern
fill 183 120 207 183 126 207 minecraft:sculk
fill 141 121 182 141 130 183 minecraft:sculk
setblock 141 121 184 minecraft:white_concrete
fill 141 121 196 141 186 196 minecraft:sculk
setblock 144 121 184 minecraft:light[level=10]
setblock 144 121 192 minecraft:light[level=10]
setblock 144 121 200 minecraft:light[level=10]
setblock 144 121 208 minecraft:light[level=10]
setblock 144 121 216 minecraft:light[level=10]
setblock 148 121 202 minecraft:bone_block
setblock 149 121 197 minecraft:bone_block
setblock 149 121 207 minecraft:bone_block
fill 150 121 196 151 121 196 minecraft:bone_block
fill 150 121 208 151 121 208 minecraft:bone_block
setblock 151 121 202 minecraft:bone_block
setblock 152 121 184 minecraft:light[level=10]
setblock 152 121 192 minecraft:light[level=10]
fill 152 121 193 152 121 194 minecraft:bone_block
setblock 152 121 200 minecraft:light[level=10]
setblock 152 121 208 minecraft:light[level=10]
fill 152 121 210 152 121 211 minecraft:bone_block
setblock 152 121 216 minecraft:light[level=10]
fill 153 121 192 154 121 192 minecraft:bone_block
fill 153 121 212 154 121 212 minecraft:bone_block
setblock 154 121 194 minecraft:bone_block
setblock 154 121 210 minecraft:bone_block
fill 156 121 190 156 121 191 minecraft:bone_block
fill 156 121 213 156 121 214 minecraft:bone_block
setblock 157 121 189 minecraft:bone_block
setblock 157 121 215 minecraft:bone_block
fill 157 121 223 157 183 223 minecraft:sculk
setblock 160 121 181 minecraft:sea_lantern
setblock 160 121 184 minecraft:light[level=10]
setblock 160 121 192 minecraft:light[level=10]
setblock 160 121 200 minecraft:light[level=10]
setblock 160 121 208 minecraft:light[level=10]
setblock 160 121 216 minecraft:light[level=10]
fill 161 121 189 161 121 190 minecraft:bone_block
fill 161 121 214 161 121 215 minecraft:bone_block
setblock 162 121 181 minecraft:sea_lantern
setblock 162 121 188 minecraft:bone_block
setblock 162 121 191 minecraft:bone_block
setblock 162 121 213 minecraft:bone_block
setblock 162 121 216 minecraft:bone_block
setblock 167 121 189 minecraft:bone_block
setblock 167 121 215 minecraft:bone_block
setblock 168 121 184 minecraft:light[level=10]
fill 168 121 190 168 121 191 minecraft:bone_block
setblock 168 121 192 minecraft:light[level=10]
setblock 168 121 200 minecraft:light[level=10]
setblock 168 121 208 minecraft:light[level=10]
fill 168 121 213 168 121 214 minecraft:bone_block
setblock 168 121 216 minecraft:light[level=10]
fill 170 121 192 171 121 192 minecraft:bone_block
setblock 170 121 194 minecraft:bone_block
setblock 170 121 210 minecraft:bone_block
fill 170 121 212 171 121 212 minecraft:bone_block
fill 172 121 193 172 121 194 minecraft:bone_block
fill 172 121 210 172 121 211 minecraft:bone_block
fill 173 121 196 174 121 196 minecraft:bone_block
setblock 173 121 202 minecraft:bone_block
fill 173 121 208 174 121 208 minecraft:bone_block
fill 174 121 201 175 121 201 minecraft:bone_block
fill 174 121 203 175 121 203 minecraft:bone_block
setblock 175 121 197 minecraft:bone_block
setblock 175 121 207 minecraft:bone_block
setblock 176 121 184 minecraft:light[level=10]
setblock 176 121 192 minecraft:light[level=10]
setblock 176 121 200 minecraft:light[level=10]
setblock 176 121 202 minecraft:bone_block
setblock 176 121 208 minecraft:light[level=10]
setblock 176 121 216 minecraft:light[level=10]
setblock 180 121 223 minecraft:white_concrete
fill 181 121 223 181 159 223 minecraft:sculk
fill 183 121 195 183 188 195 minecraft:sculk
fill 141 122 184 141 188 184 minecraft:sculk
fill 160 122 181 160 185 181 minecraft:sculk
fill 162 122 181 162 188 181 minecraft:sculk
setblock 178 122 181 minecraft:white_concrete
fill 180 122 223 180 186 223 minecraft:sculk
fill 183 122 183 183 123 183 minecraft:sea_lantern
setblock 141 123 215 minecraft:white_concrete
fill 178 123 181 178 175 181 minecraft:sculk
fill 141 124 215 141 138 215 minecraft:sculk
setblock 175 124 223 minecraft:white_concrete
fill 183 124 183 183 184 183 minecraft:sculk
setblock 183 124 205 minecraft:sea_lantern
setblock 141 125 193 minecraft:sea_lantern
setblock 143 125 181 minecraft:white_concrete
fill 162 125 223 162 138 223 minecraft:sculk
setblock 163 125 223 minecraft:white_concrete
fill 175 125 223 175 184 223 minecraft:sculk
setblock 183 125 201 minecraft:sea_lantern
fill 183 125 205 183 188 205 minecraft:sculk
fill 183 125 215 183 127 215 minecraft:sculk
setblock 183 125 216 minecraft:white_concrete
fill 141 126 193 141 127 193 minecraft:sculk
setblock 141 126 203 minecraft:sea_lantern
fill 143 126 181 143 188 181 minecraft:sculk
fill 163 126 223 163 127 223 minecraft:sculk
fill 183 126 201 183 188 201 minecraft:sculk
fill 183 126 216 183 188 216 minecraft:sculk
fill 141 127 189 141 128 189 minecraft:cyan_concrete
setblock 141 127 198 minecraft:sea_lantern
setblock 141 127 202 minecraft:sea_lantern
fill 141 127 203 141 190 203 minecraft:sculk
fill 141 127 205 141 128 205 minecraft:cyan_concrete
fill 141 127 221 141 128 221 minecraft:cyan_concrete
fill 145 127 181 145 128 181 minecraft:cyan_concrete
setblock 149 127 223 minecraft:sea_lantern
setblock 150 127 181 minecraft:sea_lantern
setblock 153 127 181 minecraft:white_concrete
fill 155 127 223 155 128 223 minecraft:cyan_concrete
fill 161 127 181 161 128 181 minecraft:cyan_concrete
fill 171 127 223 171 128 223 minecraft:cyan_concrete
fill 177 127 181 177 128 181 minecraft:cyan_concrete
fill 183 127 191 183 128 191 minecraft:cyan_concrete
fill 183 127 207 183 128 207 minecraft:cyan_concrete
setblock 141 128 193 minecraft:sea_lantern
fill 141 128 198 141 136 198 minecraft:sculk
fill 141 128 202 141 148 202 minecraft:sculk
setblock 147 128 223 minecraft:sea_lantern
fill 149 128 223 149 147 223 minecraft:sculk
fill 150 128 181 150 186 181 minecraft:sculk
fill 153 128 181 153 184 181 minecraft:sculk
setblock 158 128 223 minecraft:white_concrete
setblock 163 128 223 minecraft:sea_lantern
setblock 166 128 223 minecraft:sea_lantern
setblock 183 128 215 minecraft:white_concrete
fill 141 129 189 141 135 189 minecraft:sculk
fill 141 129 193 141 134 193 minecraft:sculk
fill 141 129 205 141 135 205 minecraft:sculk
fill 141 129 221 141 134 221 minecraft:sculk
setblock 144 129 184 minecraft:light[level=10]
setblock 144 129 192 minecraft:light[level=10]
setblock 144 129 200 minecraft:light[level=10]
setblock 144 129 208 minecraft:light[level=10]
setblock 144 129 216 minecraft:light[level=10]
fill 145 129 181 145 135 181 minecraft:sculk
fill 147 129 223 147 186 223 minecraft:sculk
setblock 152 129 184 minecraft:light[level=10]
setblock 152 129 192 minecraft:light[level=10]
setblock 152 129 200 minecraft:light[level=10]
setblock 152 129 208 minecraft:light[level=10]
setblock 152 129 216 minecraft:light[level=10]
fill 155 129 223 155 135 223 minecraft:sculk
setblock 156 129 223 minecraft:sea_lantern
fill 158 129 223 158 188 223 minecraft:sculk
setblock 159 129 181 minecraft:sea_lantern
setblock 160 129 184 minecraft:light[level=10]
setblock 160 129 192 minecraft:light[level=10]
setblock 160 129 200 minecraft:light[level=10]
setblock 160 129 208 minecraft:light[level=10]
setblock 160 129 216 minecraft:light[level=10]
fill 161 129 181 161 135 181 minecraft:sculk
fill 163 129 223 163 188 223 minecraft:sculk
fill 166 129 223 166 176 223 minecraft:sculk
setblock 168 129 184 minecraft:light[level=10]
setblock 168 129 192 minecraft:light[level=10]
setblock 168 129 200 minecraft:light[level=10]
setblock 168 129 208 minecraft:light[level=10]
setblock 168 129 216 minecraft:light[level=10]
fill 171 129 223 171 135 223 minecraft:sculk
setblock 175 129 181 minecraft:sea_lantern
setblock 176 129 184 minecraft:light[level=10]
setblock 176 129 192 minecraft:light[level=10]
setblock 176 129 200 minecraft:light[level=10]
setblock 176 129 208 minecraft:light[level=10]
setblock 176 129 216 minecraft:light[level=10]
fill 177 129 181 177 135 181 minecraft:sculk
fill 180 129 194 180 141 194 minecraft:sculk
fill 183 129 191 183 135 191 minecraft:sculk
fill 183 129 207 183 135 207 minecraft:sculk
fill 183 129 215 183 138 215 minecraft:sculk
fill 141 130 186 141 185 186 minecraft:sculk
setblock 141 130 187 minecraft:sea_lantern
fill 156 130 223 156 163 223 minecraft:sculk
fill 159 130 181 159 149 181 minecraft:sculk
setblock 170 130 223 minecraft:sea_lantern
setblock 174 130 181 minecraft:sea_lantern
fill 175 130 181 175 188 181 minecraft:sculk
fill 141 131 182 141 161 182 minecraft:sculk
setblock 141 131 183 minecraft:sea_lantern
fill 141 131 187 141 184 187 minecraft:sculk
fill 170 131 223 170 188 223 minecraft:sculk
fill 174 131 181 174 171 181 minecraft:sculk
fill 141 132 183 141 139 183 minecraft:sculk
fill 167 132 181 167 188 181 minecraft:sculk
setblock 168 132 181 minecraft:sea_lantern
fill 183 132 218 183 188 218 minecraft:sculk
setblock 183 132 219 minecraft:sea_lantern
fill 183 132 220 183 135 222 minecraft:sculk
setblock 141 133 211 minecraft:sea_lantern
setblock 154 133 181 minecraft:sea_lantern
fill 168 133 181 168 148 181 minecraft:sculk
fill 183 133 219 183 188 219 minecraft:sculk
fill 141 134 211 141 154 211 minecraft:sculk
fill 154 134 181 154 152 181 minecraft:sculk
setblock 166 134 181 minecraft:white_concrete
fill 176 134 216 176 143 216 minecraft:sculk
setblock 183 134 184 minecraft:sea_lantern
setblock 141 135 193 minecraft:white_concrete
setblock 141 135 221 minecraft:white_concrete
setblock 149 135 181 minecraft:white_concrete
fill 166 135 181 166 188 181 minecraft:sculk
setblock 173 135 223 minecraft:sea_lantern
setblock 182 135 223 minecraft:white_concrete
fill 183 135 184 183 188 184 minecraft:sculk
setblock 183 135 192 minecraft:sea_lantern
setblock 183 135 197 minecraft:white_concrete
fill 141 136 189 141 137 189 minecraft:cyan_concrete
fill 141 136 193 141 188 193 minecraft:sculk
fill 141 136 205 141 137 205 minecraft:cyan_concrete
fill 141 136 221 141 137 221 minecraft:cyan_concrete
fill 145 136 181 145 137 181 minecraft:cyan_concrete
fill 149 136 181 149 164 181 minecraft:sculk
fill 155 136 223 155 137 223 minecraft:cyan_concrete
fill 161 136 181 161 137 181 minecraft:cyan_concrete
fill 171 136 223 171 137 223 minecraft:cyan_concrete
fill 173 136 223 173 185 223 minecraft:sculk
fill 177 136 181 177 137 181 minecraft:cyan_concrete
fill 182 136 223 182 188 223 minecraft:sculk
fill 183 136 191 183 137 191 minecraft:cyan_concrete
fill 183 136 192 183 139 192 minecraft:sculk
fill 183 136 197 183 141 197 minecraft:sculk
fill 183 136 207 183 137 207 minecraft:cyan_concrete
setblock 183 136 220 minecraft:white_concrete
fill 183 136 221 183 172 222 minecraft:sculk
setblock 141 137 198 minecraft:white_concrete
setblock 144 137 184 minecraft:light[level=10]
setblock 144 137 192 minecraft:light[level=10]
setblock 144 137 200 minecraft:light[level=10]
setblock 144 137 208 minecraft:light[level=10]
setblock 144 137 216 minecraft:light[level=10]
setblock 152 137 184 minecraft:light[level=10]
setblock 152 137 192 minecraft:light[level=10]
setblock 152 137 200 minecraft:light[level=10]
setblock 152 137 208 minecraft:light[level=10]
setblock 152 137 216 minecraft:light[level=10]
setblock 156 137 181 minecraft:sea_lantern
fill 157 137 181 157 188 181 minecraft:sculk
setblock 160 137 184 minecraft:light[level=10]
setblock 160 137 192 minecraft:light[level=10]
setblock 160 137 200 minecraft:light[level=10]
setblock 160 137 208 minecraft:light[level=10]
setblock 160 137 216 minecraft:light[level=10]
setblock 168 137 184 minecraft:light[level=10]
setblock 168 137 192 minecraft:light[level=10]
setblock 168 137 200 minecraft:light[level=10]
setblock 168 137 208 minecraft:light[level=10]
setblock 168 137 216 minecraft:light[level=10]
setblock 176 137 184 minecraft:light[level=10]
setblock 176 137 192 minecraft:light[level=10]
setblock 176 137 200 minecraft:light[level=10]
setblock 176 137 208 minecraft:light[level=10]
setblock 178 137 223 minecraft:white_concrete
fill 183 137 220 183 188 220 minecraft:sculk
fill 141 138 189 141 144 189 minecraft:sculk
fill 141 138 198 141 170 198 minecraft:sculk
fill 141 138 205 141 144 205 minecraft:sculk
fill 141 138 217 141 188 217 minecraft:sculk
setblock 141 138 218 minecraft:white_concrete
fill 141 138 221 141 144 221 minecraft:sculk
fill 145 138 181 145 144 181 minecraft:sculk
fill 155 138 223 155 144 223 minecraft:sculk
fill 156 138 181 156 188 181 minecraft:sculk
fill 161 138 181 161 144 181 minecraft:sculk
fill 171 138 223 171 144 223 minecraft:sculk
fill 177 138 181 177 144 181 minecraft:sculk
fill 178 138 223 178 189 223 minecraft:sculk
fill 183 138 191 183 144 191 minecraft:sculk
fill 183 138 207 183 141 207 minecraft:sculk
setblock 141 139 215 minecraft:sea_lantern
fill 141 139 218 141 169 218 minecraft:sculk
setblock 162 139 223 minecraft:sea_lantern
setblock 169 139 223 minecraft:sea_lantern
setblock 183 139 215 minecraft:white_concrete
setblock 141 140 183 minecraft:sea_lantern
setblock 141 140 212 minecraft:sea_lantern
fill 141 140 213 141 188 213 minecraft:sculk
fill 141 140 215 141 153 215 minecraft:sculk
setblock 141 140 222 minecraft:sea_lantern
fill 162 140 223 162 145 223 minecraft:sculk
fill 164 140 185 164 149 185 minecraft:polished_blackstone
fill 169 140 223 169 183 223 minecraft:sculk
setblock 173 140 181 minecraft:white_concrete
setblock 177 140 223 minecraft:white_concrete
setblock 183 140 192 minecraft:white_concrete
fill 183 140 215 183 188 215 minecraft:sculk
fill 141 141 183 141 150 183 minecraft:sculk
fill 141 141 212 141 146 212 minecraft:sculk
fill 141 141 222 141 144 222 minecraft:sculk
fill 171 141 181 172 141 181 minecraft:sea_lantern
fill 173 141 181 173 147 181 minecraft:sculk
fill 177 141 223 177 188 223 minecraft:sculk
fill 183 141 192 183 188 192 minecraft:sculk
fill 171 142 181 172 184 181 minecraft:sculk
setblock 183 142 197 minecraft:sea_lantern
setblock 183 142 207 minecraft:sea_lantern
setblock 141 143 197 minecraft:sea_lantern
fill 183 143 197 183 152 197 minecraft:sculk
fill 183 143 207 183 144 207 minecraft:sculk
fill 141 144 197 141 188 197 minecraft:sculk
fill 141 145 189 141 146 189 minecraft:cyan_concrete
fill 141 145 205 141 146 205 minecraft:cyan_concrete
fill 141 145 221 141 146 221 minecraft:cyan_concrete
setblock 141 145 222 minecraft:sea_lantern
setblock 144 145 184 minecraft:light[level=10]
setblock 144 145 192 minecraft:light[level=10]
setblock 144 145 200 minecraft:light[level=10]
setblock 144 145 208 minecraft:light[level=10]
setblock 144 145 216 minecraft:light[level=10]
fill 145 145 181 145 146 181 minecraft:cyan_concrete
setblock 152 145 184 minecraft:light[level=10]
setblock 152 145 192 minecraft:light[level=10]
setblock 152 145 200 minecraft:light[level=10]
setblock 152 145 208 minecraft:light[level=10]
setblock 152 145 216 minecraft:light[level=10]
fill 155 145 223 155 146 223 minecraft:cyan_concrete
setblock 160 145 184 minecraft:light[level=10]
setblock 160 145 192 minecraft:light[level=10]
setblock 160 145 200 minecraft:light[level=10]
setblock 160 145 208 minecraft:light[level=10]
setblock 160 145 216 minecraft:light[level=10]
fill 161 145 181 161 146 181 minecraft:cyan_concrete
setblock 168 145 184 minecraft:light[level=10]
setblock 168 145 192 minecraft:light[level=10]
setblock 168 145 200 minecraft:light[level=10]
setblock 168 145 208 minecraft:light[level=10]
setblock 168 145 216 minecraft:light[level=10]
fill 171 145 223 171 146 223 minecraft:cyan_concrete
setblock 176 145 184 minecraft:light[level=10]
setblock 176 145 192 minecraft:light[level=10]
setblock 176 145 200 minecraft:light[level=10]
setblock 176 145 208 minecraft:light[level=10]
setblock 176 145 216 minecraft:light[level=10]
fill 177 145 181 177 146 181 minecraft:cyan_concrete
fill 183 145 191 183 146 191 minecraft:cyan_concrete
fill 183 145 207 183 146 207 minecraft:cyan_concrete
fill 141 146 222 141 188 222 minecraft:sculk
fill 153 146 223 153 185 223 minecraft:sculk
setblock 154 146 223 minecraft:sea_lantern
setblock 162 146 223 minecraft:sea_lantern
setblock 183 146 193 minecraft:sea_lantern
fill 183 146 209 183 169 210 minecraft:sculk
setblock 183 146 211 minecraft:white_concrete
fill 183 146 212 183 154 212 minecraft:sculk
fill 141 147 189 141 153 189 minecraft:sculk
fill 141 147 205 141 153 205 minecraft:sculk
setblock 141 147 212 minecraft:white_concrete
fill 141 147 221 141 153 221 minecraft:sculk
fill 145 147 181 145 153 181 minecraft:sculk
fill 154 147 223 155 148 223 minecraft:sculk
fill 161 147 181 161 153 181 minecraft:sculk
fill 162 147 223 162 185 223 minecraft:sculk
fill 163 147 185 163 149 185 minecraft:polished_blackstone
fill 164 147 184 164 149 184 minecraft:polished_blackstone
fill 164 147 186 164 149 186 minecraft:polished_blackstone
fill 165 147 185 165 149 185 minecraft:polished_blackstone
fill 171 147 223 171 150 223 minecraft:sculk
fill 177 147 181 177 153 181 minecraft:sculk
setblock 183 147 191 minecraft:sea_lantern
fill 183 147 193 183 184 193 minecraft:sculk
fill 183 147 207 183 153 207 minecraft:sculk
fill 183 147 211 183 188 211 minecraft:sculk
fill 141 148 212 141 178 212 minecraft:sculk
setblock 149 148 223 minecraft:sea_lantern
setblock 173 148 181 minecraft:white_concrete
fill 183 148 191 183 153 191 minecraft:sculk
setblock 141 149 190 minecraft:sea_lantern
fill 141 149 191 141 188 191 minecraft:sculk
setblock 141 149 202 minecraft:white_concrete
fill 149 149 223 149 186 223 minecraft:sculk
setblock 154 149 223 minecraft:white_concrete
fill 155 149 223 155 153 223 minecraft:sculk
setblock 168 149 181 minecraft:sea_lantern
fill 173 149 181 173 185 181 minecraft:sculk
setblock 183 149 187 minecraft:sea_lantern
fill 141 150 190 141 181 190 minecraft:sculk
fill 141 150 202 141 188 202 minecraft:sculk
fill 154 150 223 154 178 223 minecraft:sculk
setblock 158 150 181 minecraft:sea_lantern
setblock 159 150 181 minecraft:white_concrete
fill 168 150 181 168 161 181 minecraft:sculk
fill 183 150 187 183 158 187 minecraft:sculk
setblock 183 150 188 minecraft:sea_lantern
setblock 141 151 183 minecraft:white_concrete
fill 158 151 181 159 186 181 minecraft:sculk
setblock 171 151 223 minecraft:white_concrete
fill 183 151 188 183 181 188 minecraft:sculk
fill 141 152 183 141 186 183 minecraft:sculk
fill 171 152 223 171 153 223 minecraft:sculk
setblock 144 153 184 minecraft:light[level=10]
setblock 144 153 192 minecraft:light[level=10]
setblock 144 153 200 minecraft:light[level=10]
setblock 144 153 208 minecraft:light[level=10]
setblock 144 153 216 minecraft:light[level=10]
setblock 152 153 184 minecraft:light[level=10]
setblock 152 153 192 minecraft:light[level=10]
setblock 152 153 200 minecraft:light[level=10]
setblock 152 153 208 minecraft:light[level=10]
setblock 152 153 216 minecraft:light[level=10]
fill 154 153 181 155 153 181 minecraft:sea_lantern
setblock 160 153 184 minecraft:light[level=10]
setblock 160 153 192 minecraft:light[level=10]
setblock 160 153 200 minecraft:light[level=10]
setblock 160 153 208 minecraft:light[level=10]
setblock 160 153 216 minecraft:light[level=10]
setblock 168 153 184 minecraft:light[level=10]
setblock 168 153 192 minecraft:light[level=10]
setblock 168 153 200 minecraft:light[level=10]
setblock 168 153 208 minecraft:light[level=10]
setblock 168 153 216 minecraft:light[level=10]
setblock 176 153 184 minecraft:light[level=10]
setblock 176 153 192 minecraft:light[level=10]
setblock 176 153 200 minecraft:light[level=10]
setblock 176 153 208 minecraft:light[level=10]
setblock 176 153 216 minecraft:light[level=10]
setblock 183 153 197 minecraft:sea_lantern
fill 141 154 189 141 155 189 minecraft:cyan_concrete
fill 141 154 205 141 155 205 minecraft:cyan_concrete
setblock 141 154 215 minecraft:sea_lantern
fill 141 154 221 141 155 221 minecraft:cyan_concrete
fill 145 154 181 145 155 181 minecraft:cyan_concrete
setblock 150 154 223 minecraft:sea_lantern
fill 154 154 181 155 185 181 minecraft:sculk
fill 155 154 223 155 155 223 minecraft:cyan_concrete
fill 161 154 181 161 155 181 minecraft:cyan_concrete
fill 171 154 223 171 155 223 minecraft:cyan_concrete
fill 177 154 181 177 155 181 minecraft:cyan_concrete
fill 183 154 191 183 155 191 minecraft:cyan_concrete
fill 183 154 197 183 168 197 minecraft:sculk
fill 183 154 207 183 155 207 minecraft:cyan_concrete
setblock 141 155 211 minecraft:sea_lantern
fill 141 155 215 141 188 215 minecraft:sculk
fill 150 155 223 150 157 223 minecraft:sculk
setblock 183 155 196 minecraft:white_concrete
setblock 183 155 212 minecraft:sea_lantern
fill 141 156 189 141 161 189 minecraft:sculk
fill 141 156 205 141 161 205 minecraft:sculk
fill 141 156 211 141 189 211 minecraft:sculk
fill 141 156 221 141 161 221 minecraft:sculk
fill 145 156 181 145 160 181 minecraft:sculk
fill 155 156 223 155 161 223 minecraft:sculk
fill 161 156 181 161 161 181 minecraft:sculk
fill 171 156 223 171 161 223 minecraft:sculk
fill 177 156 181 177 161 181 minecraft:sculk
fill 183 156 191 183 161 191 minecraft:sculk
fill 183 156 196 183 184 196 minecraft:sculk
fill 183 156 207 183 161 207 minecraft:sculk
fill 183 156 212 183 188 212 minecraft:sculk
setblock 165 157 223 minecraft:sea_lantern
setblock 150 158 223 minecraft:white_concrete
fill 165 158 223 165 184 223 minecraft:sculk
fill 150 159 223 150 181 223 minecraft:sculk
setblock 151 159 223 minecraft:sea_lantern
setblock 183 159 187 minecraft:sea_lantern
fill 151 160 223 151 188 223 minecraft:sculk
setblock 172 160 223 minecraft:white_concrete
setblock 181 160 223 minecraft:sea_lantern
fill 183 160 187 183 188 187 minecraft:sculk
setblock 144 161 184 minecraft:light[level=10]
setblock 144 161 192 minecraft:light[level=10]
setblock 144 161 200 minecraft:light[level=10]
setblock 144 161 208 minecraft:light[level=10]
setblock 144 161 216 minecraft:light[level=10]
setblock 145 161 181 minecraft:sea_lantern
setblock 152 161 184 minecraft:light[level=10]
setblock 152 161 192 minecraft:light[level=10]
setblock 152 161 200 minecraft:light[level=10]
setblock 152 161 208 minecraft:light[level=10]
setblock 152 161 216 minecraft:light[level=10]
setblock 160 161 184 minecraft:light[level=10]
setblock 160 161 192 minecraft:light[level=10]
setblock 160 161 200 minecraft:light[level=10]
setblock 160 161 208 minecraft:light[level=10]
setblock 160 161 216 minecraft:light[level=10]
setblock 168 161 184 minecraft:light[level=10]
setblock 168 161 192 minecraft:light[level=10]
setblock 168 161 200 minecraft:light[level=10]
setblock 168 161 208 minecraft:light[level=10]
setblock 168 161 216 minecraft:light[level=10]
fill 172 161 223 172 188 223 minecraft:sculk
setblock 176 161 184 minecraft:light[level=10]
setblock 176 161 192 minecraft:light[level=10]
setblock 176 161 200 minecraft:light[level=10]
setblock 176 161 208 minecraft:light[level=10]
setblock 176 161 216 minecraft:light[level=10]
fill 181 161 223 181 170 223 minecraft:sculk
setblock 141 162 182 minecraft:sea_lantern
fill 141 162 189 141 164 189 minecraft:cyan_concrete
fill 141 162 205 141 164 205 minecraft:cyan_concrete
fill 141 162 221 141 164 221 minecraft:cyan_concrete
fill 145 162 181 145 164 181 minecraft:cyan_concrete
fill 155 162 223 155 164 223 minecraft:cyan_concrete
fill 161 162 181 161 164 181 minecraft:cyan_concrete
setblock 168 162 181 minecraft:white_concrete
fill 171 162 223 171 164 223 minecraft:cyan_concrete
fill 177 162 181 177 164 181 minecraft:cyan_concrete
fill 183 162 191 183 164 191 minecraft:cyan_concrete
fill 183 162 207 183 164 207 minecraft:cyan_concrete
fill 141 163 182 141 167 182 minecraft:sculk
setblock 141 163 216 minecraft:white_concrete
fill 168 163 181 168 188 181 minecraft:sculk
setblock 179 163 223 minecraft:sea_lantern
fill 141 164 216 141 166 216 minecraft:sculk
setblock 156 164 223 minecraft:white_concrete
fill 179 164 223 179 166 223 minecraft:sculk
setblock 183 164 186 minecraft:white_concrete
fill 141 165 189 141 184 189 minecraft:sculk
fill 141 165 205 141 185 205 minecraft:sculk
fill 141 165 221 141 186 221 minecraft:sculk
fill 145 165 181 145 188 181 minecraft:sculk
setblock 149 165 181 minecraft:sea_lantern
fill 155 165 223 156 176 223 minecraft:sculk
fill 161 165 181 161 188 181 minecraft:sculk
fill 171 165 223 171 175 223 minecraft:sculk
fill 177 165 181 177 188 181 minecraft:sculk
fill 183 165 186 183 188 186 minecraft:sculk
fill 183 165 191 183 181 191 minecraft:sculk
fill 183 165 207 183 188 207 minecraft:sculk
fill 149 166 181 149 188 181 minecraft:sculk
setblock 141 167 207 minecraft:white_concrete
setblock 141 167 216 minecraft:white_concrete
setblock 167 167 223 minecraft:sea_lantern
setblock 179 167 223 minecraft:white_concrete
setblock 183 167 208 minecraft:white_concrete
setblock 141 168 182 minecraft:sea_lantern
fill 141 168 207 141 188 207 minecraft:sculk
fill 141 168 216 141 184 216 minecraft:sculk
fill 167 168 223 167 188 223 minecraft:sculk
setblock 174 168 223 minecraft:sea_lantern
fill 179 168 223 179 188 223 minecraft:sculk
fill 183 168 208 183 184 208 minecraft:sculk
fill 141 169 182 141 173 182 minecraft:sculk
setblock 141 169 214 minecraft:white_concrete
setblock 141 169 220 minecraft:sea_lantern
setblock 144 169 184 minecraft:light[level=10]
setblock 144 169 192 minecraft:light[level=10]
setblock 144 169 200 minecraft:light[level=10]
setblock 144 169 208 minecraft:light[level=10]
setblock 144 169 216 minecraft:light[level=10]
setblock 152 169 184 minecraft:light[level=10]
setblock 152 169 192 minecraft:light[level=10]
setblock 152 169 200 minecraft:light[level=10]
setblock 152 169 208 minecraft:light[level=10]
setblock 152 169 216 minecraft:light[level=10]
setblock 160 169 184 minecraft:light[level=10]
setblock 160 169 192 minecraft:light[level=10]
setblock 160 169 200 minecraft:light[level=10]
setblock 160 169 208 minecraft:light[level=10]
setblock 160 169 216 minecraft:light[level=10]
setblock 168 169 184 minecraft:light[level=10]
setblock 168 169 192 minecraft:light[level=10]
setblock 168 169 200 minecraft:light[level=10]
setblock 168 169 208 minecraft:light[level=10]
setblock 168 169 216 minecraft:light[level=10]
fill 174 169 223 174 184 223 minecraft:sculk
setblock 176 169 184 minecraft:light[level=10]
setblock 176 169 192 minecraft:light[level=10]
setblock 176 169 200 minecraft:light[level=10]
setblock 176 169 208 minecraft:light[level=10]
setblock 176 169 216 minecraft:light[level=10]
setblock 183 169 197 minecraft:sea_lantern
setblock 141 170 185 minecraft:sea_lantern
fill 141 170 214 141 188 214 minecraft:sculk
setblock 141 170 218 minecraft:sea_lantern
fill 141 170 220 141 184 220 minecraft:sculk
setblock 146 170 223 minecraft:sea_lantern
fill 183 170 197 183 185 197 minecraft:sculk
setblock 183 170 209 minecraft:sea_lantern
fill 183 170 210 183 188 210 minecraft:sculk
fill 141 171 185 141 188 185 minecraft:sculk
setblock 141 171 198 minecraft:sea_lantern
fill 141 171 218 141 188 218 minecraft:sculk
fill 146 171 223 146 188 223 minecraft:sculk
setblock 181 171 223 minecraft:sea_lantern
fill 183 171 209 183 185 209 minecraft:sculk
fill 141 172 198 141 174 198 minecraft:sculk
setblock 147 172 181 minecraft:white_concrete
setblock 174 172 181 minecraft:white_concrete
fill 181 172 223 181 183 223 minecraft:sculk
fill 147 173 181 147 188 181 minecraft:sculk
setblock 148 173 181 minecraft:white_concrete
fill 174 173 181 174 189 181 minecraft:sculk
setblock 183 173 199 minecraft:sea_lantern
fill 183 173 221 183 189 221 minecraft:sculk
setblock 183 173 222 minecraft:sea_lantern
setblock 141 174 182 minecraft:white_concrete
setblock 148 174 181 minecraft:sculk
fill 183 174 199 183 188 199 minecraft:sculk
fill 183 174 222 183 186 222 minecraft:sculk
fill 141 175 182 141 177 182 minecraft:sculk
setblock 141 175 198 minecraft:sea_lantern
fill 147 175 194 156 178 198 minecraft:polished_blackstone
setblock 148 175 181 minecraft:sea_lantern
fill 148 175 191 159 178 193 minecraft:polished_blackstone
fill 148 175 199 159 178 201 minecraft:polished_blackstone
fill 149 175 189 171 178 190 minecraft:polished_blackstone
fill 149 175 202 171 178 203 minecraft:polished_blackstone
fill 150 175 188 170 178 188 minecraft:polished_blackstone
fill 150 175 204 170 178 204 minecraft:polished_blackstone
fill 151 175 187 169 178 187 minecraft:polished_blackstone
fill 151 175 205 169 178 205 minecraft:polished_blackstone
fill 152 175 186 168 178 186 minecraft:polished_blackstone
fill 152 175 206 168 178 206 minecraft:polished_blackstone
fill 153 175 185 167 179 185 minecraft:polished_blackstone
fill 153 175 207 167 179 207 minecraft:polished_blackstone
fill 155 175 184 165 179 184 minecraft:polished_blackstone
fill 155 175 208 165 179 208 minecraft:polished_blackstone
fill 157 175 194 157 178 195 minecraft:polished_blackstone
fill 157 175 197 157 178 198 minecraft:polished_blackstone
fill 158 175 183 162 179 183 minecraft:polished_blackstone
fill 158 175 209 162 179 209 minecraft:polished_blackstone
fill 160 175 191 172 178 192 minecraft:polished_blackstone
fill 160 175 200 172 178 201 minecraft:polished_blackstone
fill 161 175 193 172 178 193 minecraft:polished_blackstone
fill 161 175 199 172 178 199 minecraft:polished_blackstone
fill 163 175 194 173 178 195 minecraft:polished_blackstone
fill 163 175 197 173 178 198 minecraft:polished_blackstone
fill 164 175 196 173 178 196 minecraft:polished_blackstone
setblock 183 175 217 minecraft:white_concrete
fill 141 176 198 141 188 198 minecraft:sculk
fill 148 176 181 148 188 181 minecraft:sculk
setblock 171 176 223 minecraft:sea_lantern
setblock 178 176 181 minecraft:sea_lantern
fill 183 176 217 183 186 217 minecraft:sculk
setblock 144 177 184 minecraft:light[level=10]
setblock 144 177 192 minecraft:light[level=10]
setblock 144 177 200 minecraft:light[level=10]
setblock 144 177 208 minecraft:light[level=10]
setblock 144 177 216 minecraft:light[level=10]
setblock 152 177 184 minecraft:light[level=10]
setblock 152 177 208 minecraft:light[level=10]
setblock 152 177 216 minecraft:light[level=10]
setblock 155 177 223 minecraft:sea_lantern
fill 156 177 223 156 188 223 minecraft:sculk
setblock 160 177 216 minecraft:light[level=10]
setblock 166 177 223 minecraft:sea_lantern
setblock 168 177 184 minecraft:light[level=10]
setblock 168 177 208 minecraft:light[level=10]
setblock 168 177 216 minecraft:light[level=10]
fill 171 177 223 171 188 223 minecraft:sculk
setblock 176 177 184 minecraft:light[level=10]
setblock 176 177 192 minecraft:light[level=10]
setblock 176 177 200 minecraft:light[level=10]
setblock 176 177 208 minecraft:light[level=10]
setblock 176 177 216 minecraft:light[level=10]
fill 178 177 181 178 188 181 minecraft:sculk
setblock 141 178 182 minecraft:sea_lantern
fill 155 178 223 155 188 223 minecraft:sculk
fill 166 178 223 166 188 223 minecraft:sculk
fill 180 178 181 180 188 181 minecraft:sculk
setblock 181 178 181 minecraft:sea_lantern
fill 182 178 181 183 188 181 minecraft:sculk
fill 141 179 182 141 186 182 minecraft:sculk
setblock 141 179 212 minecraft:sea_lantern
fill 142 179 182 146 179 222 minecraft:black_concrete
setblock 142 179 223 minecraft:sea_lantern
fill 147 179 182 147 179 193 minecraft:black_concrete
fill 147 179 194 149 179 198 minecraft:polished_blackstone
fill 147 179 199 147 179 222 minecraft:black_concrete
fill 148 179 182 148 179 190 minecraft:black_concrete
fill 148 179 191 150 179 193 minecraft:polished_blackstone
fill 148 179 199 150 179 201 minecraft:polished_blackstone
fill 148 179 202 148 179 222 minecraft:black_concrete
fill 149 179 182 149 179 188 minecraft:black_concrete
fill 149 179 189 151 179 190 minecraft:polished_blackstone
fill 149 179 202 151 179 203 minecraft:polished_blackstone
fill 149 179 204 149 179 222 minecraft:black_concrete
fill 150 179 182 150 179 187 minecraft:black_concrete
fill 150 179 188 153 179 188 minecraft:polished_blackstone
fill 150 179 194 150 179 195 minecraft:polished_blackstone
fill 150 179 196 155 179 196 minecraft:sculk
fill 150 179 197 150 179 198 minecraft:polished_blackstone
fill 150 179 204 153 179 204 minecraft:polished_blackstone
fill 150 179 205 150 179 222 minecraft:black_concrete
fill 151 179 182 151 179 186 minecraft:black_concrete
fill 151 179 187 155 179 187 minecraft:polished_blackstone
setblock 151 179 191 minecraft:polished_blackstone
fill 151 179 192 155 179 195 minecraft:sculk
fill 151 179 197 155 179 200 minecraft:sculk
setblock 151 179 201 minecraft:polished_blackstone
fill 151 179 205 155 179 205 minecraft:polished_blackstone
fill 151 179 206 151 179 222 minecraft:black_concrete
fill 152 179 182 152 179 185 minecraft:black_concrete
fill 152 179 186 159 179 186 minecraft:polished_blackstone
setblock 152 179 189 minecraft:polished_blackstone
fill 152 179 190 168 179 191 minecraft:sculk
fill 152 179 201 168 179 202 minecraft:sculk
setblock 152 179 203 minecraft:polished_blackstone
fill 152 179 206 159 179 206 minecraft:polished_blackstone
fill 152 179 207 152 179 222 minecraft:black_concrete
fill 153 179 182 154 179 184 minecraft:black_concrete
fill 153 179 189 167 179 189 minecraft:sculk
fill 153 179 203 167 179 203 minecraft:sculk
fill 153 179 208 154 179 222 minecraft:black_concrete
fill 154 179 188 166 179 188 minecraft:sculk
fill 154 179 204 166 179 204 minecraft:sculk
setblock 154 179 223 minecraft:sea_lantern
fill 155 179 182 157 179 183 minecraft:black_concrete
fill 155 179 209 157 179 222 minecraft:black_concrete
fill 156 179 187 164 179 187 minecraft:sculk
fill 156 179 192 156 179 194 minecraft:sculk
fill 156 179 195 156 179 197 minecraft:sea_lantern
fill 156 179 198 156 179 200 minecraft:sculk
fill 156 179 205 164 179 205 minecraft:sculk
fill 157 179 192 158 179 192 minecraft:sculk
fill 157 179 193 157 179 195 minecraft:sea_lantern
fill 157 179 197 157 179 199 minecraft:sea_lantern
fill 157 179 200 158 179 200 minecraft:sculk
fill 158 179 182 182 179 182 minecraft:black_concrete
fill 158 179 193 159 179 193 minecraft:sea_lantern
fill 158 179 199 159 179 199 minecraft:sea_lantern
fill 158 179 210 182 179 222 minecraft:black_concrete
fill 159 179 192 161 179 192 minecraft:sea_lantern
fill 159 179 200 161 179 200 minecraft:sea_lantern
setblock 160 179 186 minecraft:sculk
setblock 160 179 206 minecraft:sculk
fill 161 179 186 168 179 186 minecraft:polished_blackstone
fill 161 179 193 163 179 193 minecraft:sea_lantern
fill 161 179 199 163 179 199 minecraft:sea_lantern
fill 161 179 206 168 179 206 minecraft:polished_blackstone
fill 162 179 192 169 179 192 minecraft:sculk
fill 162 179 200 169 179 200 minecraft:sculk
fill 163 179 183 182 179 183 minecraft:black_concrete
fill 163 179 194 163 179 195 minecraft:sea_lantern
fill 163 179 197 163 179 198 minecraft:sea_lantern
fill 163 179 209 182 179 209 minecraft:black_concrete
fill 164 179 193 169 179 194 minecraft:sculk
fill 164 179 195 164 179 197 minecraft:sea_lantern
fill 164 179 198 169 179 199 minecraft:sculk
fill 165 179 187 169 179 187 minecraft:polished_blackstone
fill 165 179 195 169 179 197 minecraft:sculk
fill 165 179 205 169 179 205 minecraft:polished_blackstone
fill 166 179 184 182 179 184 minecraft:black_concrete
fill 166 179 208 182 179 208 minecraft:black_concrete
fill 167 179 188 170 179 188 minecraft:polished_blackstone
fill 167 179 204 170 179 204 minecraft:polished_blackstone
fill 168 179 185 182 179 185 minecraft:black_concrete
fill 168 179 189 171 179 189 minecraft:polished_blackstone
fill 168 179 203 171 179 203 minecraft:polished_blackstone
fill 168 179 207 182 179 207 minecraft:black_concrete
fill 169 179 186 182 179 186 minecraft:black_concrete
fill 169 179 190 171 179 191 minecraft:polished_blackstone
fill 169 179 201 171 179 202 minecraft:polished_blackstone
fill 169 179 206 182 179 206 minecraft:black_concrete
fill 170 179 187 182 179 187 minecraft:black_concrete
fill 170 179 192 172 179 195 minecraft:polished_blackstone
setblock 170 179 196 minecraft:sculk
fill 170 179 197 172 179 200 minecraft:polished_blackstone
fill 170 179 205 182 179 205 minecraft:black_concrete
fill 171 179 188 182 179 188 minecraft:black_concrete
fill 171 179 196 173 179 196 minecraft:polished_blackstone
fill 171 179 204 182 179 204 minecraft:black_concrete
fill 172 179 189 182 179 190 minecraft:black_concrete
setblock 172 179 191 minecraft:polished_blackstone
setblock 172 179 201 minecraft:polished_blackstone
fill 172 179 202 182 179 203 minecraft:black_concrete
fill 173 179 191 182 179 193 minecraft:black_concrete
fill 173 179 194 173 179 195 minecraft:polished_blackstone
fill 173 179 197 173 179 198 minecraft:polished_blackstone
fill 173 179 199 182 179 201 minecraft:black_concrete
fill 174 179 194 182 179 198 minecraft:black_concrete
fill 181 179 181 181 181 181 minecraft:sculk
fill 141 180 212 141 184 212 minecraft:sculk
fill 142 180 223 142 188 223 minecraft:sculk
fill 154 180 223 154 185 223 minecraft:sculk
fill 156 180 194 156 180 198 minecraft:tinted_glass
setblock 157 180 193 minecraft:tinted_glass
setblock 157 180 199 minecraft:tinted_glass
fill 158 180 192 162 180 192 minecraft:tinted_glass
fill 158 180 200 162 180 200 minecraft:tinted_glass
setblock 163 180 193 minecraft:tinted_glass
setblock 163 180 199 minecraft:tinted_glass
fill 164 180 194 164 180 198 minecraft:tinted_glass
fill 154 181 195 155 181 197 minecraft:tinted_glass
fill 155 181 193 155 181 194 minecraft:tinted_glass
fill 155 181 198 155 181 199 minecraft:tinted_glass
fill 156 181 192 156 181 193 minecraft:tinted_glass
fill 156 181 199 156 181 200 minecraft:tinted_glass
fill 157 181 191 157 181 192 minecraft:tinted_glass
fill 157 181 200 157 181 201 minecraft:tinted_glass
fill 158 181 191 163 181 191 minecraft:tinted_glass
fill 158 181 201 163 181 201 minecraft:tinted_glass
fill 159 181 190 161 181 190 minecraft:tinted_glass
fill 159 181 202 161 181 202 minecraft:tinted_glass
fill 163 181 192 164 181 192 minecraft:tinted_glass
fill 163 181 200 164 181 200 minecraft:tinted_glass
fill 164 181 193 165 181 193 minecraft:tinted_glass
fill 164 181 199 165 181 199 minecraft:tinted_glass
fill 165 181 194 165 181 198 minecraft:tinted_glass
fill 166 181 195 166 181 197 minecraft:tinted_glass
setblock 141 182 188 minecraft:white_concrete
setblock 141 182 190 minecraft:sea_lantern
setblock 150 182 223 minecraft:sea_lantern
fill 153 182 194 153 182 198 minecraft:tinted_glass
fill 154 182 192 154 182 194 minecraft:tinted_glass
fill 154 182 198 154 182 200 minecraft:tinted_glass
fill 155 182 191 155 182 192 minecraft:tinted_glass
fill 155 182 200 155 182 201 minecraft:tinted_glass
fill 156 182 190 156 182 191 minecraft:tinted_glass
fill 156 182 201 156 182 202 minecraft:tinted_glass
fill 157 182 190 158 182 190 minecraft:tinted_glass
fill 157 182 202 158 182 202 minecraft:tinted_glass
fill 158 182 189 162 182 189 minecraft:tinted_glass
fill 158 182 203 162 182 203 minecraft:tinted_glass
fill 162 182 190 164 182 190 minecraft:tinted_glass
fill 162 182 202 164 182 202 minecraft:tinted_glass
fill 164 182 191 165 182 191 minecraft:tinted_glass
fill 164 182 201 165 182 201 minecraft:tinted_glass
fill 165 182 192 166 182 192 minecraft:tinted_glass
fill 165 182 200 166 182 200 minecraft:tinted_glass
fill 166 182 193 166 182 194 minecraft:tinted_glass
fill 166 182 198 166 182 199 minecraft:tinted_glass
fill 167 182 194 167 182 198 minecraft:tinted_glass
setblock 181 182 181 minecraft:sea_lantern
setblock 183 182 188 minecraft:sea_lantern
setblock 183 182 191 minecraft:white_concrete
fill 141 183 188 141 185 188 minecraft:sculk
fill 141 183 190 141 185 190 minecraft:sculk
fill 150 183 223 150 188 223 minecraft:sculk
setblock 152 183 181 minecraft:white_concrete
fill 152 183 193 152 183 199 minecraft:tinted_glass
fill 153 183 191 153 183 192 minecraft:tinted_glass
fill 153 183 200 153 183 201 minecraft:tinted_glass
fill 154 183 190 154 183 191 minecraft:tinted_glass
fill 154 183 201 154 183 202 minecraft:tinted_glass
fill 155 183 189 155 183 190 minecraft:tinted_glass
fill 155 183 202 155 183 203 minecraft:tinted_glass
setblock 156 183 189 minecraft:tinted_glass
setblock 156 183 203 minecraft:tinted_glass
fill 157 183 188 163 183 188 minecraft:tinted_glass
fill 157 183 204 163 183 204 minecraft:tinted_glass
setblock 164 183 181 minecraft:sea_lantern
fill 164 183 189 165 183 189 minecraft:tinted_glass
fill 164 183 203 165 183 203 minecraft:tinted_glass
fill 165 183 190 166 183 190 minecraft:tinted_glass
fill 165 183 202 166 183 202 minecraft:tinted_glass
fill 166 183 191 167 183 191 minecraft:tinted_glass
fill 166 183 201 167 183 201 minecraft:tinted_glass
setblock 167 183 192 minecraft:tinted_glass
setblock 167 183 200 minecraft:tinted_glass
fill 168 183 193 168 183 199 minecraft:tinted_glass
fill 181 183 181 181 184 181 minecraft:sculk
fill 183 183 188 183 188 188 minecraft:sculk
fill 183 183 191 183 185 191 minecraft:sculk
fill 150 184 194 151 184 198 minecraft:tinted_glass
fill 151 184 192 151 184 193 minecraft:tinted_glass
fill 151 184 199 151 184 200 minecraft:tinted_glass
fill 152 184 181 152 188 181 minecraft:sculk
fill 152 184 190 152 184 191 minecraft:tinted_glass
fill 152 184 201 152 184 202 minecraft:tinted_glass
fill 153 184 189 153 184 190 minecraft:tinted_glass
fill 153 184 202 153 184 203 minecraft:tinted_glass
fill 154 184 188 154 184 189 minecraft:tinted_glass
fill 154 184 203 154 184 204 minecraft:tinted_glass
setblock 155 184 188 minecraft:tinted_glass
setblock 155 184 204 minecraft:tinted_glass
fill 156 184 187 164 184 187 minecraft:tinted_glass
fill 156 184 205 164 184 205 minecraft:tinted_glass
setblock 157 184 223 minecraft:white_concrete
fill 158 184 186 162 184 186 minecraft:tinted_glass
fill 158 184 206 162 184 206 minecraft:tinted_glass
fill 164 184 181 164 188 181 minecraft:sculk
fill 165 184 188 166 184 188 minecraft:tinted_glass
fill 165 184 204 166 184 204 minecraft:tinted_glass
fill 166 184 189 167 184 189 minecraft:tinted_glass
fill 166 184 203 167 184 203 minecraft:tinted_glass
fill 167 184 190 168 184 190 minecraft:tinted_glass
fill 167 184 202 168 184 202 minecraft:tinted_glass
setblock 168 184 191 minecraft:tinted_glass
setblock 168 184 201 minecraft:tinted_glass
fill 169 184 192 169 184 200 minecraft:tinted_glass
setblock 169 184 223 minecraft:white_concrete
fill 170 184 194 170 184 198 minecraft:tinted_glass
setblock 181 184 223 minecraft:sea_lantern
setblock 141 185 181 minecraft:black_concrete
setblock 141 185 187 minecraft:black_concrete
setblock 141 185 189 minecraft:black_concrete
setblock 141 185 212 minecraft:black_concrete
setblock 141 185 216 minecraft:black_concrete
setblock 141 185 220 minecraft:black_concrete
fill 142 185 181 142 188 181 minecraft:sculk
setblock 144 185 184 minecraft:light[level=10]
setblock 144 185 192 minecraft:light[level=10]
setblock 144 185 200 minecraft:light[level=10]
setblock 144 185 208 minecraft:light[level=10]
setblock 144 185 216 minecraft:light[level=10]
fill 149 185 193 149 185 199 minecraft:tinted_glass
fill 150 185 191 150 185 193 minecraft:tinted_glass
fill 150 185 199 150 185 201 minecraft:tinted_glass
setblock 151 185 181 minecraft:black_concrete
fill 151 185 189 151 185 190 minecraft:tinted_glass
fill 151 185 202 151 185 203 minecraft:tinted_glass
setblock 152 185 184 minecraft:light[level=10]
fill 152 185 188 152 185 189 minecraft:tinted_glass
setblock 152 185 192 minecraft:light[level=10]
setblock 152 185 200 minecraft:light[level=10]
fill 152 185 203 152 185 204 minecraft:tinted_glass
setblock 152 185 208 minecraft:light[level=10]
setblock 152 185 216 minecraft:light[level=10]
setblock 153 185 181 minecraft:black_concrete
fill 153 185 187 153 185 188 minecraft:tinted_glass
fill 153 185 204 153 185 205 minecraft:tinted_glass
setblock 154 185 187 minecraft:tinted_glass
setblock 154 185 205 minecraft:tinted_glass
fill 155 185 186 157 185 186 minecraft:tinted_glass
fill 155 185 206 157 185 206 minecraft:tinted_glass
fill 157 185 185 163 185 185 minecraft:tinted_glass
fill 157 185 207 163 185 207 minecraft:tinted_glass
fill 157 185 223 157 188 223 minecraft:sculk
setblock 160 185 184 minecraft:light[level=10]
setblock 160 185 192 minecraft:light[level=10]
setblock 160 185 200 minecraft:light[level=10]
setblock 160 185 208 minecraft:light[level=10]
setblock 160 185 216 minecraft:light[level=10]
setblock 161 185 223 minecraft:black_concrete
fill 163 185 186 165 185 186 minecraft:tinted_glass
fill 163 185 206 165 185 206 minecraft:tinted_glass
setblock 165 185 223 minecraft:black_concrete
fill 166 185 187 167 185 187 minecraft:tinted_glass
fill 166 185 205 167 185 205 minecraft:tinted_glass
fill 167 185 188 168 185 188 minecraft:tinted_glass
fill 167 185 204 168 185 204 minecraft:tinted_glass
setblock 168 185 184 minecraft:light[level=10]
fill 168 185 189 169 185 189 minecraft:tinted_glass
setblock 168 185 192 minecraft:light[level=10]
setblock 168 185 200 minecraft:light[level=10]
fill 168 185 203 169 185 203 minecraft:tinted_glass
setblock 168 185 208 minecraft:light[level=10]
setblock 168 185 216 minecraft:light[level=10]
setblock 169 185 190 minecraft:tinted_glass
setblock 169 185 202 minecraft:tinted_glass
fill 169 185 223 169 189 223 minecraft:sculk
fill 170 185 191 170 185 193 minecraft:tinted_glass
fill 170 185 199 170 185 201 minecraft:tinted_glass
fill 171 185 181 171 189 181 minecraft:sculk
fill 171 185 193 171 185 199 minecraft:tinted_glass
setblock 172 185 181 minecraft:black_concrete
fill 174 185 223 175 185 223 minecraft:black_concrete
setblock 176 185 184 minecraft:light[level=10]
setblock 176 185 192 minecraft:light[level=10]
setblock 176 185 200 minecraft:light[level=10]
setblock 176 185 208 minecraft:light[level=10]
setblock 176 185 216 minecraft:light[level=10]
setblock 181 185 181 minecraft:black_concrete
fill 181 185 223 181 188 223 minecraft:sculk
setblock 183 185 183 minecraft:white_concrete
fill 183 185 193 183 187 193 minecraft:black_concrete
setblock 183 185 196 minecraft:black_concrete
setblock 183 185 208 minecraft:black_concrete
setblock 141 186 181 minecraft:sculk
setblock 141 186 186 minecraft:black_concrete
fill 141 186 187 141 188 187 minecraft:sculk
setblock 141 186 188 minecraft:black_concrete
fill 141 186 189 141 188 189 minecraft:sculk
setblock 141 186 190 minecraft:black_concrete
fill 141 186 194 141 186 195 minecraft:black_concrete
fill 141 186 205 141 186 206 minecraft:black_concrete
setblock 141 186 210 minecraft:black_concrete
fill 141 186 212 141 188 212 minecraft:sculk
fill 141 186 216 141 188 216 minecraft:sculk
setblock 141 186 219 minecraft:black_concrete
fill 141 186 220 141 188 220 minecraft:sculk
fill 141 186 223 141 187 223 minecraft:black_concrete
fill 148 186 192 148 186 200 minecraft:tinted_glass
fill 149 186 190 149 186 192 minecraft:tinted_glass
fill 149 186 200 149 186 202 minecraft:tinted_glass
fill 150 186 188 150 186 190 minecraft:tinted_glass
fill 150 186 202 150 186 204 minecraft:tinted_glass
fill 151 186 181 151 188 181 minecraft:sculk
fill 151 186 187 151 186 188 minecraft:tinted_glass
fill 151 186 204 151 186 205 minecraft:tinted_glass
fill 152 186 186 152 186 187 minecraft:tinted_glass
fill 152 186 205 152 186 206 minecraft:tinted_glass
fill 153 186 181 153 188 181 minecraft:sculk
fill 153 186 186 154 186 186 minecraft:tinted_glass
fill 153 186 206 154 186 206 minecraft:tinted_glass
fill 153 186 223 154 186 223 minecraft:black_concrete
setblock 154 186 181 minecraft:sea_lantern
fill 154 186 185 156 186 185 minecraft:tinted_glass
fill 154 186 207 156 186 207 minecraft:tinted_glass
fill 155 186 181 155 188 181 minecraft:sculk
fill 156 186 184 164 186 184 minecraft:tinted_glass
fill 156 186 208 164 186 208 minecraft:tinted_glass
fill 160 186 181 160 187 181 minecraft:black_concrete
fill 161 186 223 161 188 223 minecraft:sculk
setblock 162 186 223 minecraft:black_concrete
fill 164 186 185 166 186 185 minecraft:tinted_glass
fill 164 186 207 166 186 207 minecraft:tinted_glass
fill 165 186 223 165 188 223 minecraft:sculk
fill 166 186 186 168 186 186 minecraft:tinted_glass
fill 166 186 206 168 186 206 minecraft:tinted_glass
fill 168 186 187 169 186 187 minecraft:tinted_glass
fill 168 186 205 169 186 205 minecraft:tinted_glass
fill 169 186 188 170 186 188 minecraft:tinted_glass
fill 169 186 204 170 186 204 minecraft:tinted_glass
fill 170 186 189 170 186 190 minecraft:tinted_glass
fill 170 186 202 170 186 203 minecraft:tinted_glass
fill 171 186 190 171 186 192 minecraft:tinted_glass
fill 171 186 200 171 186 202 minecraft:tinted_glass
fill 172 186 181 172 188 181 minecraft:sculk
fill 172 186 192 172 186 200 minecraft:tinted_glass
setblock 173 186 181 minecraft:black_concrete
setblock 173 186 223 minecraft:black_concrete
fill 174 186 223 175 188 223 minecraft:sculk
setblock 179 186 181 minecraft:black_concrete
fill 181 186 181 181 188 181 minecraft:sculk
fill 183 186 183 183 188 183 minecraft:sculk
setblock 183 186 191 minecraft:black_concrete
setblock 183 186 194 minecraft:black_concrete
fill 183 186 196 183 188 196 minecraft:sculk
setblock 183 186 197 minecraft:white_concrete
fill 183 186 208 183 188 208 minecraft:sculk
setblock 183 186 209 minecraft:black_concrete
setblock 183 186 214 minecraft:black_concrete
fill 141 187 181 141 187 183 minecraft:black_concrete
fill 141 187 186 141 188 186 minecraft:sculk
fill 141 187 188 141 188 188 minecraft:sculk
fill 141 187 190 141 188 190 minecraft:sculk
fill 141 187 194 141 188 195 minecraft:sculk
setblock 141 187 196 minecraft:black_concrete
fill 141 187 205 141 188 206 minecraft:sculk
fill 141 187 210 141 188 210 minecraft:sculk
fill 141 187 219 141 188 219 minecraft:sculk
setblock 141 187 221 minecraft:black_concrete
fill 146 187 194 147 187 198 minecraft:tinted_glass
fill 147 187 191 147 187 193 minecraft:tinted_glass
fill 147 187 199 147 187 201 minecraft:tinted_glass
setblock 147 187 223 minecraft:black_concrete
fill 148 187 189 148 187 191 minecraft:tinted_glass
fill 148 187 201 148 187 203 minecraft:tinted_glass
fill 149 187 187 149 187 189 minecraft:tinted_glass
fill 149 187 203 149 187 205 minecraft:tinted_glass
setblock 149 187 223 minecraft:black_concrete
setblock 150 187 181 minecraft:black_concrete
fill 150 187 186 150 187 187 minecraft:tinted_glass
fill 150 187 205 150 187 206 minecraft:tinted_glass
fill 151 187 185 151 187 186 minecraft:tinted_glass
fill 151 187 206 151 187 207 minecraft:tinted_glass
fill 152 187 185 153 187 185 minecraft:tinted_glass
fill 152 187 207 153 187 207 minecraft:tinted_glass
setblock 152 187 223 minecraft:black_concrete
fill 153 187 184 155 187 184 minecraft:tinted_glass
fill 153 187 208 155 187 208 minecraft:tinted_glass
fill 153 187 223 153 188 223 minecraft:sculk
fill 154 187 181 154 188 181 minecraft:sculk
setblock 154 187 223 minecraft:black_concrete
fill 155 187 183 165 187 183 minecraft:tinted_glass
fill 155 187 209 165 187 209 minecraft:tinted_glass
setblock 158 187 181 minecraft:black_concrete
fill 158 187 182 162 187 182 minecraft:tinted_glass
fill 158 187 210 162 187 210 minecraft:tinted_glass
fill 159 187 181 159 190 181 minecraft:sculk
fill 162 187 223 162 188 223 minecraft:sculk
fill 165 187 184 167 187 184 minecraft:tinted_glass
fill 165 187 208 167 187 208 minecraft:tinted_glass
fill 167 187 185 169 187 185 minecraft:tinted_glass
fill 167 187 207 169 187 207 minecraft:tinted_glass
fill 169 187 186 170 187 186 minecraft:tinted_glass
fill 169 187 206 170 187 206 minecraft:tinted_glass
fill 170 187 187 171 187 187 minecraft:tinted_glass
fill 170 187 205 171 187 205 minecraft:tinted_glass
fill 171 187 188 171 187 189 minecraft:tinted_glass
fill 171 187 203 171 187 204 minecraft:tinted_glass
fill 172 187 189 172 187 191 minecraft:tinted_glass
fill 172 187 201 172 187 203 minecraft:tinted_glass
fill 173 187 181 173 188 181 minecraft:sculk
fill 173 187 191 173 187 201 minecraft:tinted_glass
fill 173 187 223 173 188 223 minecraft:sculk
fill 174 187 194 174 187 198 minecraft:tinted_glass
fill 179 187 181 179 188 181 minecraft:sculk
setblock 180 187 223 minecraft:black_concrete
fill 183 187 191 183 188 191 minecraft:sculk
fill 183 187 194 183 188 194 minecraft:sculk
fill 183 187 197 183 188 197 minecraft:sculk
setblock 183 187 198 minecraft:black_concrete
setblock 183 187 209 minecraft:sculk
fill 183 187 214 183 188 214 minecraft:sculk
setblock 183 187 217 minecraft:black_concrete
fill 183 187 222 183 187 223 minecraft:black_concrete
fill 141 188 181 141 188 183 minecraft:sculk
fill 141 188 196 141 189 196 minecraft:sculk
setblock 141 188 208 minecraft:sea_lantern
setblock 141 188 221 minecraft:sculk
setblock 141 188 223 minecraft:sculk
fill 147 188 194 148 189 198 minecraft:polished_blackstone
fill 147 188 223 147 189 223 minecraft:sculk
fill 148 188 191 148 189 193 minecraft:polished_blackstone
fill 148 188 199 148 189 201 minecraft:polished_blackstone
fill 149 188 189 149 189 192 minecraft:polished_blackstone
fill 149 188 200 149 189 203 minecraft:polished_blackstone
setblock 149 188 223 minecraft:sculk
setblock 150 188 181 minecraft:sculk
fill 150 188 188 150 189 190 minecraft:polished_blackstone
fill 150 188 202 150 189 204 minecraft:polished_blackstone
fill 151 188 187 151 189 188 minecraft:polished_blackstone
fill 151 188 204 151 189 205 minecraft:polished_blackstone
fill 152 188 186 152 189 187 minecraft:polished_blackstone
fill 152 188 205 152 189 206 minecraft:polished_blackstone
setblock 152 188 223 minecraft:sculk
fill 153 188 185 154 189 186 minecraft:polished_blackstone
fill 153 188 206 154 189 207 minecraft:polished_blackstone
fill 154 188 223 154 189 223 minecraft:sculk
fill 155 188 184 156 189 185 minecraft:polished_blackstone
fill 155 188 207 156 189 208 minecraft:polished_blackstone
fill 157 188 184 165 189 184 minecraft:polished_blackstone
fill 157 188 208 165 189 208 minecraft:polished_blackstone
setblock 158 188 181 minecraft:sculk
fill 158 188 183 162 189 183 minecraft:polished_blackstone
fill 158 188 209 162 189 209 minecraft:polished_blackstone
setblock 160 188 181 minecraft:sculk
fill 164 188 185 167 189 185 minecraft:polished_blackstone
fill 164 188 207 167 189 207 minecraft:polished_blackstone
fill 166 188 186 168 189 186 minecraft:polished_blackstone
fill 166 188 206 168 189 206 minecraft:polished_blackstone
fill 168 188 187 169 189 187 minecraft:polished_blackstone
fill 168 188 205 169 189 205 minecraft:polished_blackstone
fill 169 188 188 170 189 188 minecraft:polished_blackstone
fill 169 188 204 170 189 204 minecraft:polished_blackstone
fill 170 188 189 171 189 190 minecraft:polished_blackstone
fill 170 188 202 171 189 203 minecraft:polished_blackstone
fill 171 188 191 172 189 192 minecraft:polished_blackstone
fill 171 188 200 172 189 201 minecraft:polished_blackstone
fill 172 188 193 172 189 199 minecraft:polished_blackstone
fill 173 188 194 173 189 198 minecraft:polished_blackstone
setblock 180 188 223 minecraft:sculk
setblock 183 188 193 minecraft:sculk
setblock 183 188 198 minecraft:sculk
setblock 183 188 209 minecraft:sea_lantern
setblock 183 188 217 minecraft:sculk
fill 183 188 222 183 188 223 minecraft:sculk
setblock 141 189 181 minecraft:sculk
fill 141 189 182 141 205 188 minecraft:black_concrete
fill 141 189 189 141 191 189 minecraft:cyan_concrete
fill 141 189 190 141 195 191 minecraft:black_concrete
setblock 141 189 192 minecraft:sea_lantern
fill 141 189 193 141 190 195 minecraft:black_concrete
fill 141 189 197 141 189 202 minecraft:black_concrete
fill 141 189 204 141 285 204 minecraft:black_concrete
fill 141 189 205 141 191 205 minecraft:cyan_concrete
fill 141 189 206 141 194 208 minecraft:black_concrete
fill 141 189 210 141 307 210 minecraft:black_concrete
fill 141 189 212 141 189 220 minecraft:black_concrete
fill 141 189 221 141 191 221 minecraft:cyan_concrete
fill 141 189 222 141 236 223 minecraft:black_concrete
fill 142 189 181 144 200 181 minecraft:black_concrete
fill 142 189 223 146 204 223 minecraft:black_concrete
fill 145 189 181 145 191 181 minecraft:cyan_concrete
fill 146 189 181 158 189 181 minecraft:black_concrete
fill 148 189 223 153 190 223 minecraft:black_concrete
fill 155 189 223 155 191 223 minecraft:cyan_concrete
fill 156 189 223 168 189 223 minecraft:black_concrete
fill 160 189 181 160 219 181 minecraft:black_concrete
fill 161 189 181 161 191 181 minecraft:cyan_concrete
fill 162 189 181 162 286 181 minecraft:black_concrete
fill 164 189 181 170 190 181 minecraft:black_concrete
fill 170 189 223 170 238 223 minecraft:black_concrete
fill 171 189 223 171 191 223 minecraft:cyan_concrete
fill 172 189 181 173 189 181 minecraft:black_concrete
fill 172 189 223 176 192 223 minecraft:black_concrete
fill 175 189 181 176 249 181 minecraft:black_concrete
fill 177 189 181 177 191 181 minecraft:cyan_concrete
setblock 177 189 223 minecraft:sea_lantern
fill 178 189 181 183 194 181 minecraft:black_concrete
fill 179 189 223 183 189 223 minecraft:black_concrete
fill 183 189 182 183 189 190 minecraft:black_concrete
fill 183 189 191 183 191 191 minecraft:cyan_concrete
fill 183 189 192 183 189 206 minecraft:black_concrete
fill 183 189 207 183 191 207 minecraft:cyan_concrete
fill 183 189 208 183 189 218 minecraft:black_concrete
setblock 183 189 219 minecraft:white_concrete
fill 183 189 220 183 195 220 minecraft:black_concrete
fill 183 189 222 183 307 222 minecraft:black_concrete
fill 141 190 181 141 307 181 minecraft:black_concrete
fill 141 190 192 141 212 192 minecraft:black_concrete
fill 141 190 196 141 190 200 minecraft:black_concrete
setblock 141 190 201 minecraft:sculk
fill 141 190 202 141 201 202 minecraft:black_concrete
fill 141 190 211 141 190 217 minecraft:black_concrete
setblock 141 190 218 minecraft:sculk
fill 141 190 219 141 230 220 minecraft:black_concrete
fill 146 190 181 146 223 181 minecraft:black_concrete
setblock 147 190 181 minecraft:sculk
setblock 147 190 223 minecraft:black_concrete
fill 148 190 181 150 238 181 minecraft:black_concrete
setblock 151 190 181 minecraft:sculk
fill 152 190 181 158 195 181 minecraft:black_concrete
fill 154 190 223 154 297 223 minecraft:black_concrete
fill 156 190 223 159 201 223 minecraft:black_concrete
setblock 160 190 223 minecraft:sculk
fill 161 190 223 169 190 223 minecraft:black_concrete
fill 163 190 181 163 213 181 minecraft:black_concrete
fill 171 190 181 172 204 181 minecraft:black_concrete
setblock 173 190 181 minecraft:sculk
setblock 174 190 181 minecraft:black_concrete
fill 177 190 223 180 190 223 minecraft:black_concrete
setblock 181 190 223 minecraft:sculk
fill 182 190 223 183 250 223 minecraft:black_concrete
setblock 183 190 182 minecraft:sculk
fill 183 190 183 183 190 190 minecraft:black_concrete
fill 183 190 192 183 264 192 minecraft:black_concrete
setblock 183 190 193 minecraft:sculk
fill 183 190 194 183 197 194 minecraft:black_concrete
fill 183 190 195 183 190 196 minecraft:sculk
fill 183 190 197 183 208 202 minecraft:black_concrete
setblock 183 190 203 minecraft:sculk
fill 183 190 204 183 190 206 minecraft:black_concrete
fill 183 190 208 183 190 214 minecraft:black_concrete
setblock 183 190 215 minecraft:sculk
fill 183 190 216 183 205 219 minecraft:black_concrete
setblock 183 190 221 minecraft:black_concrete
setblock 141 191 193 minecraft:sculk
fill 141 191 194 141 208 198 minecraft:black_concrete
setblock 141 191 199 minecraft:sculk
fill 141 191 200 141 307 201 minecraft:black_concrete
fill 141 191 203 141 262 203 minecraft:black_concrete
fill 141 191 211 141 192 216 minecraft:black_concrete
setblock 141 191 217 minecraft:sculk
fill 141 191 218 141 307 218 minecraft:black_concrete
fill 147 191 181 147 269 181 minecraft:black_concrete
setblock 147 191 223 minecraft:sea_lantern
setblock 148 191 223 minecraft:sculk
fill 149 191 223 149 271 223 minecraft:black_concrete
setblock 150 191 223 minecraft:sculk
fill 151 191 181 151 202 181 minecraft:black_concrete
fill 151 191 223 153 201 223 minecraft:black_concrete
fill 159 191 181 159 213 181 minecraft:black_concrete
fill 160 191 223 162 192 223 minecraft:black_concrete
setblock 163 191 223 minecraft:sculk
fill 164 191 181 164 230 181 minecraft:black_concrete
fill 164 191 223 169 201 223 minecraft:black_concrete
setblock 165 191 181 minecraft:sculk
fill 166 191 181 170 197 181 minecraft:black_concrete
fill 173 191 181 173 307 181 minecraft:black_concrete
setblock 174 191 181 minecraft:sea_lantern
fill 177 191 223 178 241 223 minecraft:black_concrete
setblock 179 191 223 minecraft:sculk
fill 180 191 223 181 216 223 minecraft:black_concrete
fill 183 191 182 183 206 183 minecraft:black_concrete
setblock 183 191 184 minecraft:sculk
fill 183 191 185 183 191 189 minecraft:black_concrete
setblock 183 191 190 minecraft:sculk
fill 183 191 193 183 199 193 minecraft:black_concrete
setblock 183 191 195 minecraft:sculk
fill 183 191 196 183 289 196 minecraft:black_concrete
fill 183 191 203 183 244 203 minecraft:black_concrete
setblock 183 191 204 minecraft:sculk
fill 183 191 205 183 209 206 minecraft:black_concrete
fill 183 191 208 183 253 209 minecraft:black_concrete
setblock 183 191 210 minecraft:sculk
fill 183 191 211 183 224 211 minecraft:black_concrete
setblock 183 191 212 minecraft:sculk
fill 183 191 213 183 197 215 minecraft:black_concrete
setblock 183 191 221 minecraft:sculk
fill 141 192 189 141 197 189 minecraft:black_concrete
fill 141 192 193 141 307 193 minecraft:black_concrete
fill 141 192 199 141 232 199 minecraft:black_concrete
fill 141 192 205 141 197 205 minecraft:black_concrete
fill 141 192 209 141 205 209 minecraft:black_concrete
fill 141 192 217 141 196 217 minecraft:black_concrete
fill 141 192 221 141 197 221 minecraft:black_concrete
fill 145 192 181 145 197 181 minecraft:black_concrete
fill 147 192 223 148 193 223 minecraft:black_concrete
fill 150 192 223 150 286 223 minecraft:black_concrete
fill 155 192 223 155 197 223 minecraft:black_concrete
fill 161 192 181 161 197 181 minecraft:black_concrete
fill 163 192 223 163 237 223 minecraft:black_concrete
fill 165 192 181 165 307 181 minecraft:black_concrete
fill 171 192 223 171 197 223 minecraft:black_concrete
fill 174 192 181 174 307 181 minecraft:black_concrete
fill 177 192 181 177 197 181 minecraft:black_concrete
fill 179 192 223 179 195 223 minecraft:black_concrete
fill 183 192 184 183 192 185 minecraft:sea_lantern
fill 183 192 186 183 197 191 minecraft:black_concrete
fill 183 192 195 183 202 195 minecraft:black_concrete
fill 183 192 204 183 195 204 minecraft:black_concrete
fill 183 192 207 183 197 207 minecraft:black_concrete
fill 183 192 210 183 208 210 minecraft:black_concrete
fill 183 192 212 183 206 212 minecraft:black_concrete
fill 183 192 221 183 242 221 minecraft:black_concrete
fill 141 193 211 141 229 215 minecraft:black_concrete
setblock 141 193 216 minecraft:sea_lantern
setblock 144 193 184 minecraft:light[level=10]
setblock 144 193 192 minecraft:light[level=10]
setblock 144 193 200 minecraft:light[level=10]
setblock 144 193 208 minecraft:light[level=10]
setblock 144 193 216 minecraft:light[level=10]
setblock 152 193 184 minecraft:light[level=10]
setblock 152 193 192 minecraft:light[level=10]
setblock 152 193 200 minecraft:light[level=10]
setblock 152 193 208 minecraft:light[level=10]
setblock 152 193 216 minecraft:light[level=10]
setblock 160 193 184 minecraft:light[level=10]
setblock 160 193 192 minecraft:light[level=10]
setblock 160 193 200 minecraft:light[level=10]
setblock 160 193 208 minecraft:light[level=10]
setblock 160 193 216 minecraft:light[level=10]
fill 160 193 223 161 253 223 minecraft:black_concrete
setblock 162 193 223 minecraft:sea_lantern
setblock 168 193 184 minecraft:light[level=10]
setblock 168 193 192 minecraft:light[level=10]
setblock 168 193 200 minecraft:light[level=10]
setblock 168 193 208 minecraft:light[level=10]
setblock 168 193 216 minecraft:light[level=10]
setblock 172 193 223 minecraft:sea_lantern
fill 173 193 223 176 214 223 minecraft:black_concrete
setblock 176 193 184 minecraft:light[level=10]
setblock 176 193 192 minecraft:light[level=10]
setblock 176 193 200 minecraft:light[level=10]
setblock 176 193 208 minecraft:light[level=10]
setblock 176 193 216 minecraft:light[level=10]
fill 183 193 184 183 207 185 minecraft:black_concrete
fill 141 194 216 141 259 216 minecraft:black_concrete
setblock 147 194 223 minecraft:white_concrete
fill 148 194 223 148 244 223 minecraft:black_concrete
fill 162 194 223 162 282 223 minecraft:black_concrete
fill 172 194 223 172 247 223 minecraft:black_concrete
fill 141 195 206 141 307 206 minecraft:black_concrete
setblock 141 195 207 minecraft:sea_lantern
fill 141 195 208 141 200 208 minecraft:black_concrete
fill 147 195 223 147 201 223 minecraft:black_concrete
fill 178 195 181 181 206 181 minecraft:black_concrete
setblock 182 195 181 minecraft:white_concrete
fill 183 195 181 183 307 181 minecraft:black_concrete
fill 141 196 190 141 211 190 minecraft:black_concrete
setblock 141 196 191 minecraft:white_concrete
fill 141 196 207 141 254 207 minecraft:black_concrete
fill 152 196 181 154 200 181 minecraft:black_concrete
setblock 155 196 181 minecraft:sea_lantern
fill 156 196 181 158 234 181 minecraft:black_concrete
setblock 179 196 223 minecraft:sea_lantern
fill 182 196 181 182 260 181 minecraft:black_concrete
setblock 183 196 204 minecraft:sea_lantern
setblock 183 196 220 minecraft:white_concrete
fill 141 197 191 141 204 191 minecraft:black_concrete
setblock 141 197 217 minecraft:sea_lantern
fill 155 197 181 155 252 181 minecraft:black_concrete
fill 179 197 223 179 206 223 minecraft:black_concrete
fill 183 197 204 183 243 204 minecraft:black_concrete
fill 183 197 220 183 257 220 minecraft:black_concrete
fill 141 198 189 141 200 189 minecraft:cyan_concrete
fill 141 198 205 141 200 205 minecraft:cyan_concrete
fill 141 198 217 141 201 217 minecraft:black_concrete
fill 141 198 221 141 200 221 minecraft:cyan_concrete
fill 145 198 181 145 200 181 minecraft:cyan_concrete
fill 155 198 223 155 200 223 minecraft:cyan_concrete
fill 161 198 181 161 200 181 minecraft:cyan_concrete
fill 166 198 181 167 251 181 minecraft:black_concrete
setblock 168 198 181 minecraft:sea_lantern
fill 169 198 181 170 204 181 minecraft:black_concrete
fill 171 198 223 171 200 223 minecraft:cyan_concrete
fill 177 198 181 177 200 181 minecraft:cyan_concrete
setblock 183 198 186 minecraft:white_concrete
fill 183 198 187 183 202 190 minecraft:black_concrete
fill 183 198 191 183 200 191 minecraft:cyan_concrete
setblock 183 198 194 minecraft:sea_lantern
fill 183 198 207 183 200 207 minecraft:cyan_concrete
setblock 183 198 213 minecraft:sea_lantern
fill 183 198 214 183 257 215 minecraft:black_concrete
fill 168 199 181 168 307 181 minecraft:black_concrete
fill 183 199 186 183 269 186 minecraft:black_concrete
fill 183 199 194 183 307 194 minecraft:black_concrete
fill 183 199 213 183 306 213 minecraft:black_concrete
setblock 183 200 193 minecraft:sea_lantern
fill 141 201 189 141 206 189 minecraft:black_concrete
fill 141 201 205 141 206 205 minecraft:black_concrete
setblock 141 201 208 minecraft:white_concrete
fill 141 201 221 141 206 221 minecraft:black_concrete
fill 142 201 181 143 205 181 minecraft:black_concrete
setblock 144 201 181 minecraft:white_concrete
setblock 144 201 184 minecraft:light[level=10]
setblock 144 201 192 minecraft:light[level=10]
setblock 144 201 200 minecraft:light[level=10]
setblock 144 201 208 minecraft:light[level=10]
setblock 144 201 216 minecraft:light[level=10]
fill 145 201 181 145 206 181 minecraft:black_concrete
setblock 152 201 181 minecraft:white_concrete
setblock 152 201 184 minecraft:light[level=10]
setblock 152 201 192 minecraft:light[level=10]
setblock 152 201 200 minecraft:light[level=10]
setblock 152 201 208 minecraft:light[level=10]
setblock 152 201 216 minecraft:light[level=10]
fill 153 201 181 154 202 181 minecraft:black_concrete
fill 155 201 223 155 206 223 minecraft:black_concrete
setblock 160 201 184 minecraft:light[level=10]
setblock 160 201 192 minecraft:light[level=10]
setblock 160 201 200 minecraft:light[level=10]
setblock 160 201 208 minecraft:light[level=10]
setblock 160 201 216 minecraft:light[level=10]
fill 161 201 181 161 206 181 minecraft:black_concrete
setblock 168 201 184 minecraft:light[level=10]
setblock 168 201 192 minecraft:light[level=10]
setblock 168 201 200 minecraft:light[level=10]
setblock 168 201 208 minecraft:light[level=10]
setblock 168 201 216 minecraft:light[level=10]
setblock 171 201 223 minecraft:black_concrete
setblock 176 201 184 minecraft:light[level=10]
setblock 176 201 192 minecraft:light[level=10]
setblock 176 201 200 minecraft:light[level=10]
setblock 176 201 208 minecraft:light[level=10]
setblock 176 201 216 minecraft:light[level=10]
fill 177 201 181 177 206 181 minecraft:black_concrete
fill 183 201 191 183 202 191 minecraft:black_concrete
fill 183 201 193 183 283 193 minecraft:black_concrete
fill 183 201 207 183 206 207 minecraft:black_concrete
setblock 141 202 202 minecraft:white_concrete
fill 141 202 208 141 213 208 minecraft:black_concrete
setblock 141 202 217 minecraft:sea_lantern
fill 144 202 181 144 218 181 minecraft:black_concrete
setblock 147 202 223 minecraft:white_concrete
fill 149 202 220 149 206 220 minecraft:polished_blackstone
fill 151 202 223 152 307 223 minecraft:black_concrete
fill 152 202 181 152 250 181 minecraft:black_concrete
setblock 153 202 223 minecraft:sea_lantern
fill 156 202 223 156 307 223 minecraft:black_concrete
setblock 157 202 223 minecraft:sea_lantern
fill 158 202 223 159 307 223 minecraft:black_concrete
fill 164 202 223 165 266 223 minecraft:black_concrete
setblock 166 202 223 minecraft:white_concrete
fill 167 202 223 169 213 223 minecraft:black_concrete
setblock 171 202 223 minecraft:white_concrete
fill 141 203 202 141 244 202 minecraft:black_concrete
fill 141 203 217 141 307 217 minecraft:black_concrete
fill 147 203 223 147 302 223 minecraft:black_concrete
setblock 151 203 181 minecraft:sea_lantern
fill 153 203 181 153 307 181 minecraft:black_concrete
fill 153 203 223 153 213 223 minecraft:black_concrete
setblock 154 203 181 minecraft:sea_lantern
fill 157 203 223 157 221 223 minecraft:black_concrete
fill 166 203 223 166 307 223 minecraft:black_concrete
fill 171 203 223 171 206 223 minecraft:black_concrete
fill 183 203 187 183 246 188 minecraft:black_concrete
setblock 183 203 189 minecraft:white_concrete
fill 183 203 190 183 253 190 minecraft:black_concrete
setblock 183 203 191 minecraft:white_concrete
setblock 183 203 195 minecraft:sea_lantern
fill 151 204 181 151 255 181 minecraft:black_concrete
fill 154 204 181 154 219 181 minecraft:black_concrete
fill 183 204 189 183 266 189 minecraft:black_concrete
fill 183 204 191 183 206 191 minecraft:black_concrete
fill 183 204 195 183 224 195 minecraft:black_concrete
setblock 141 205 191 minecraft:sea_lantern
fill 142 205 223 143 228 223 minecraft:black_concrete
setblock 144 205 223 minecraft:sea_lantern
fill 145 205 223 146 255 223 minecraft:black_concrete
fill 148 205 220 148 206 220 minecraft:polished_blackstone
fill 149 205 219 149 206 219 minecraft:polished_blackstone
fill 149 205 221 149 206 221 minecraft:polished_blackstone
fill 150 205 220 150 206 220 minecraft:polished_blackstone
fill 169 205 181 169 260 181 minecraft:black_concrete
setblock 170 205 181 minecraft:sea_lantern
setblock 171 205 181 minecraft:white_concrete
fill 172 205 181 172 307 181 minecraft:black_concrete
setblock 141 206 182 minecraft:white_concrete
fill 141 206 183 141 212 188 minecraft:black_concrete
fill 141 206 191 141 307 191 minecraft:black_concrete
setblock 141 206 209 minecraft:sea_lantern
setblock 142 206 181 minecraft:sea_lantern
fill 143 206 181 143 307 181 minecraft:black_concrete
fill 144 206 223 144 218 223 minecraft:black_concrete
setblock 148 206 219 minecraft:polished_blackstone
setblock 148 206 221 minecraft:polished_blackstone
setblock 150 206 219 minecraft:polished_blackstone
setblock 150 206 221 minecraft:polished_blackstone
fill 170 206 181 171 255 181 minecraft:black_concrete
fill 183 206 216 183 221 218 minecraft:black_concrete
setblock 183 206 219 minecraft:sea_lantern
fill 141 207 182 141 262 182 minecraft:black_concrete
fill 141 207 189 141 209 189 minecraft:cyan_concrete
fill 141 207 205 141 209 205 minecraft:cyan_concrete
fill 141 207 209 141 307 209 minecraft:black_concrete
fill 141 207 221 141 209 221 minecraft:cyan_concrete
fill 142 207 181 142 219 181 minecraft:black_concrete
fill 145 207 181 145 209 181 minecraft:cyan_concrete
fill 155 207 223 155 209 223 minecraft:cyan_concrete
fill 161 207 181 161 209 181 minecraft:cyan_concrete
fill 171 207 223 171 209 223 minecraft:cyan_concrete
fill 177 207 181 177 209 181 minecraft:cyan_concrete
fill 178 207 181 180 208 181 minecraft:black_concrete
setblock 179 207 223 minecraft:white_concrete
setblock 181 207 181 minecraft:white_concrete
setblock 183 207 182 minecraft:white_concrete
fill 183 207 183 183 243 183 minecraft:black_concrete
fill 183 207 191 183 209 191 minecraft:cyan_concrete
fill 183 207 207 183 209 207 minecraft:cyan_concrete
setblock 183 207 212 minecraft:white_concrete
fill 183 207 219 183 213 219 minecraft:black_concrete
fill 179 208 223 179 307 223 minecraft:black_concrete
fill 181 208 181 181 257 181 minecraft:black_concrete
fill 183 208 182 183 245 182 minecraft:black_concrete
setblock 183 208 184 minecraft:white_concrete
fill 183 208 185 183 244 185 minecraft:black_concrete
fill 183 208 212 183 221 212 minecraft:black_concrete
fill 141 209 194 141 307 195 minecraft:black_concrete
setblock 141 209 196 minecraft:white_concrete
fill 141 209 197 141 247 198 minecraft:black_concrete
setblock 144 209 184 minecraft:light[level=10]
setblock 144 209 192 minecraft:light[level=10]
setblock 144 209 200 minecraft:light[level=10]
setblock 144 209 208 minecraft:light[level=10]
setblock 144 209 216 minecraft:light[level=10]
setblock 152 209 184 minecraft:light[level=10]
setblock 152 209 192 minecraft:light[level=10]
setblock 152 209 200 minecraft:light[level=10]
setblock 152 209 208 minecraft:light[level=10]
setblock 152 209 216 minecraft:light[level=10]
setblock 160 209 184 minecraft:light[level=10]
setblock 160 209 192 minecraft:light[level=10]
setblock 160 209 200 minecraft:light[level=10]
setblock 160 209 208 minecraft:light[level=10]
setblock 160 209 216 minecraft:light[level=10]
setblock 168 209 184 minecraft:light[level=10]
setblock 168 209 192 minecraft:light[level=10]
setblock 168 209 200 minecraft:light[level=10]
setblock 168 209 208 minecraft:light[level=10]
setblock 168 209 216 minecraft:light[level=10]
setblock 176 209 184 minecraft:light[level=10]
setblock 176 209 192 minecraft:light[level=10]
setblock 176 209 200 minecraft:light[level=10]
setblock 176 209 208 minecraft:light[level=10]
setblock 176 209 216 minecraft:light[level=10]
setblock 178 209 181 minecraft:sea_lantern
fill 179 209 181 180 237 181 minecraft:black_concrete
fill 183 209 184 183 307 184 minecraft:black_concrete
fill 183 209 197 183 223 200 minecraft:black_concrete
setblock 183 209 201 minecraft:sea_lantern
fill 183 209 202 183 262 202 minecraft:black_concrete
setblock 183 209 210 minecraft:white_concrete
fill 141 210 189 141 215 189 minecraft:black_concrete
fill 141 210 196 141 307 196 minecraft:black_concrete
setblock 141 210 205 minecraft:white_concrete
fill 141 210 221 141 215 221 minecraft:black_concrete
fill 145 210 181 145 215 181 minecraft:black_concrete
fill 155 210 223 155 215 223 minecraft:black_concrete
fill 161 210 181 161 215 181 minecraft:black_concrete
setblock 171 210 223 minecraft:white_concrete
fill 177 210 181 178 213 181 minecraft:black_concrete
fill 179 210 198 179 218 198 minecraft:black_concrete
fill 183 210 191 183 215 191 minecraft:black_concrete
fill 183 210 201 183 285 201 minecraft:black_concrete
fill 183 210 205 183 307 205 minecraft:black_concrete
setblock 183 210 206 minecraft:sea_lantern
fill 183 210 207 183 215 207 minecraft:black_concrete
fill 183 210 210 183 227 210 minecraft:black_concrete
fill 141 211 205 141 215 205 minecraft:black_concrete
fill 171 211 223 171 215 223 minecraft:black_concrete
setblock 183 211 206 minecraft:white_concrete
setblock 141 212 190 minecraft:sea_lantern
fill 183 212 206 183 242 206 minecraft:black_concrete
fill 141 213 183 141 233 187 minecraft:black_concrete
setblock 141 213 188 minecraft:white_concrete
fill 141 213 190 141 247 190 minecraft:black_concrete
setblock 141 213 192 minecraft:sea_lantern
fill 141 214 188 141 251 188 minecraft:black_concrete
fill 141 214 192 141 277 192 minecraft:black_concrete
setblock 141 214 208 minecraft:sea_lantern
setblock 153 214 223 minecraft:white_concrete
setblock 159 214 181 minecraft:sea_lantern
setblock 163 214 181 minecraft:sea_lantern
fill 167 214 223 168 252 223 minecraft:black_concrete
setblock 169 214 223 minecraft:white_concrete
fill 177 214 181 177 215 181 minecraft:black_concrete
setblock 178 214 181 minecraft:white_concrete
setblock 183 214 219 minecraft:sea_lantern
fill 141 215 208 141 235 208 minecraft:black_concrete
fill 153 215 223 153 270 223 minecraft:black_concrete
fill 159 215 181 159 220 181 minecraft:black_concrete
fill 163 215 181 163 217 181 minecraft:black_concrete
fill 169 215 223 169 268 223 minecraft:black_concrete
setblock 173 215 223 minecraft:white_concrete
fill 174 215 223 176 251 223 minecraft:black_concrete
fill 178 215 181 178 255 181 minecraft:black_concrete
fill 178 215 198 178 218 198 minecraft:black_concrete
fill 179 215 197 179 218 197 minecraft:black_concrete
fill 179 215 199 179 218 199 minecraft:black_concrete
fill 180 215 198 180 218 198 minecraft:black_concrete
fill 183 215 219 183 240 219 minecraft:black_concrete
fill 141 216 189 141 218 189 minecraft:cyan_concrete
fill 141 216 205 141 218 205 minecraft:cyan_concrete
fill 141 216 221 141 218 221 minecraft:cyan_concrete
fill 145 216 181 145 218 181 minecraft:cyan_concrete
fill 155 216 223 155 218 223 minecraft:cyan_concrete
fill 161 216 181 161 218 181 minecraft:cyan_concrete
fill 171 216 223 171 218 223 minecraft:cyan_concrete
fill 173 216 223 173 296 223 minecraft:black_concrete
fill 177 216 181 177 218 181 minecraft:cyan_concrete
fill 183 216 191 183 218 191 minecraft:cyan_concrete
fill 183 216 207 183 218 207 minecraft:cyan_concrete
setblock 144 217 184 minecraft:light[level=10]
setblock 144 217 192 minecraft:light[level=10]
setblock 144 217 200 minecraft:light[level=10]
setblock 144 217 208 minecraft:light[level=10]
setblock 144 217 216 minecraft:light[level=10]
setblock 152 217 184 minecraft:light[level=10]
setblock 152 217 192 minecraft:light[level=10]
setblock 152 217 200 minecraft:light[level=10]
setblock 152 217 208 minecraft:light[level=10]
setblock 152 217 216 minecraft:light[level=10]
setblock 160 217 184 minecraft:light[level=10]
setblock 160 217 192 minecraft:light[level=10]
setblock 160 217 200 minecraft:light[level=10]
setblock 160 217 208 minecraft:light[level=10]
setblock 160 217 216 minecraft:light[level=10]
setblock 168 217 184 minecraft:light[level=10]
setblock 168 217 192 minecraft:light[level=10]
setblock 168 217 200 minecraft:light[level=10]
setblock 168 217 208 minecraft:light[level=10]
setblock 168 217 216 minecraft:light[level=10]
setblock 176 217 184 minecraft:light[level=10]
setblock 176 217 192 minecraft:light[level=10]
setblock 176 217 200 minecraft:light[level=10]
setblock 176 217 208 minecraft:light[level=10]
setblock 176 217 216 minecraft:light[level=10]
fill 178 217 197 178 218 197 minecraft:black_concrete
fill 178 217 199 178 218 199 minecraft:black_concrete
fill 180 217 197 180 218 197 minecraft:black_concrete
fill 180 217 199 180 218 199 minecraft:black_concrete
fill 180 217 223 180 251 223 minecraft:black_concrete
setblock 181 217 223 minecraft:white_concrete
setblock 163 218 181 minecraft:sea_lantern
fill 181 218 223 181 242 223 minecraft:black_concrete
fill 141 219 189 141 224 189 minecraft:black_concrete
fill 141 219 205 141 220 205 minecraft:black_concrete
fill 141 219 221 141 224 221 minecraft:black_concrete
setblock 144 219 181 minecraft:sea_lantern
setblock 144 219 223 minecraft:sea_lantern
setblock 145 219 181 minecraft:black_concrete
fill 155 219 223 155 224 223 minecraft:black_concrete
fill 161 219 181 161 224 181 minecraft:black_concrete
fill 163 219 181 163 242 181 minecraft:black_concrete
fill 171 219 223 171 224 223 minecraft:black_concrete
fill 177 219 181 177 224 181 minecraft:black_concrete
fill 183 219 191 183 224 191 minecraft:black_concrete
fill 183 219 207 183 221 207 minecraft:black_concrete
setblock 142 220 181 minecraft:white_concrete
fill 144 220 181 144 224 181 minecraft:black_concrete
fill 144 220 223 144 260 223 minecraft:black_concrete
setblock 145 220 181 minecraft:sea_lantern
setblock 154 220 181 minecraft:sea_lantern
setblock 160 220 181 minecraft:sea_lantern
schedule function dropper:buildpart/39_2 1t
