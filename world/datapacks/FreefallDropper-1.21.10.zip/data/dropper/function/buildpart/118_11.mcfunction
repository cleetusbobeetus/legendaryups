setblock 494 293 465 minecraft:terracotta
setblock 495 293 464 minecraft:terracotta
fill 495 293 465 496 295 465 minecraft:red_terracotta
setblock 495 293 503 minecraft:red_terracotta
setblock 495 293 504 minecraft:terracotta
fill 496 293 464 499 293 464 minecraft:red_terracotta
fill 496 293 504 499 293 504 minecraft:red_terracotta
fill 499 293 503 500 293 503 minecraft:red_terracotta
setblock 500 293 464 minecraft:terracotta
setblock 500 293 504 minecraft:terracotta
fill 501 293 464 501 296 464 minecraft:red_terracotta
setblock 501 293 503 minecraft:terracotta
fill 501 293 504 501 296 504 minecraft:red_terracotta
fill 502 293 465 503 293 465 minecraft:red_terracotta
fill 502 293 503 502 296 503 minecraft:red_terracotta
fill 503 293 502 503 296 502 minecraft:red_terracotta
setblock 504 293 465 minecraft:terracotta
setblock 505 293 464 minecraft:terracotta
fill 505 293 465 508 293 465 minecraft:red_terracotta
setblock 505 293 504 minecraft:terracotta
fill 506 293 464 506 296 464 minecraft:red_terracotta
fill 506 293 501 506 294 501 minecraft:red_terracotta
setblock 506 293 503 minecraft:terracotta
fill 506 293 504 506 296 504 minecraft:red_terracotta
setblock 507 293 502 minecraft:terracotta
fill 507 293 503 507 296 503 minecraft:red_terracotta
fill 508 293 499 508 293 500 minecraft:red_terracotta
setblock 508 293 501 minecraft:terracotta
fill 508 293 502 508 296 502 minecraft:red_terracotta
setblock 509 293 465 minecraft:terracotta
fill 509 293 496 509 296 496 minecraft:red_terracotta
setblock 509 293 500 minecraft:terracotta
fill 509 293 501 509 296 501 minecraft:red_terracotta
setblock 510 293 464 minecraft:terracotta
fill 510 293 465 510 296 465 minecraft:red_terracotta
setblock 510 293 479 minecraft:terracotta
fill 510 293 480 510 296 480 minecraft:red_terracotta
setblock 510 293 484 minecraft:terracotta
fill 510 293 485 510 293 488 minecraft:red_terracotta
setblock 510 293 493 minecraft:red_terracotta
setblock 510 293 494 minecraft:terracotta
fill 510 293 495 510 296 495 minecraft:red_terracotta
setblock 510 293 499 minecraft:terracotta
fill 510 293 500 510 296 500 minecraft:red_terracotta
setblock 510 293 504 minecraft:terracotta
fill 511 293 464 511 296 464 minecraft:red_terracotta
setblock 511 293 468 minecraft:terracotta
setblock 511 293 478 minecraft:terracotta
fill 511 293 479 511 296 479 minecraft:red_terracotta
setblock 511 293 483 minecraft:terracotta
fill 511 293 484 511 293 487 minecraft:red_terracotta
setblock 511 293 488 minecraft:terracotta
fill 511 293 489 511 296 489 minecraft:red_terracotta
setblock 511 293 493 minecraft:terracotta
fill 511 293 494 511 296 494 minecraft:red_terracotta
setblock 511 293 498 minecraft:terracotta
fill 511 293 499 511 296 499 minecraft:red_terracotta
setblock 511 293 503 minecraft:terracotta
fill 511 293 504 511 296 504 minecraft:red_terracotta
setblock 471 294 467 minecraft:terracotta
fill 471 294 474 471 294 476 minecraft:red_terracotta
setblock 471 294 477 minecraft:terracotta
fill 471 294 478 471 294 481 minecraft:red_terracotta
setblock 471 294 482 minecraft:terracotta
fill 471 294 483 471 294 486 minecraft:red_terracotta
setblock 471 294 487 minecraft:terracotta
fill 471 294 488 471 294 491 minecraft:red_terracotta
setblock 471 294 492 minecraft:terracotta
fill 471 294 493 471 294 496 minecraft:red_terracotta
setblock 471 294 497 minecraft:terracotta
fill 471 294 498 471 297 498 minecraft:red_terracotta
setblock 471 294 502 minecraft:terracotta
fill 471 294 503 471 297 503 minecraft:red_terracotta
setblock 472 294 477 minecraft:red_terracotta
setblock 472 294 481 minecraft:terracotta
fill 472 294 482 472 297 482 minecraft:red_terracotta
setblock 472 294 486 minecraft:terracotta
fill 472 294 487 472 294 490 minecraft:red_terracotta
setblock 472 294 491 minecraft:terracotta
fill 472 294 492 472 297 492 minecraft:red_terracotta
setblock 472 294 496 minecraft:terracotta
fill 472 294 497 472 295 497 minecraft:red_terracotta
setblock 472 294 501 minecraft:terracotta
fill 472 294 502 472 297 502 minecraft:red_terracotta
setblock 473 294 466 minecraft:light[level=14]
setblock 473 294 474 minecraft:light[level=14]
setblock 473 294 480 minecraft:terracotta
fill 473 294 481 473 296 481 minecraft:red_terracotta
setblock 473 294 485 minecraft:terracotta
fill 473 294 486 473 296 487 minecraft:red_terracotta
setblock 473 294 490 minecraft:light[level=14]
setblock 473 294 498 minecraft:light[level=14]
setblock 474 294 504 minecraft:terracotta
fill 475 294 504 475 297 504 minecraft:red_terracotta
setblock 478 294 504 minecraft:red_terracotta
setblock 479 294 504 minecraft:terracotta
fill 480 294 504 483 294 504 minecraft:red_terracotta
fill 481 294 464 483 294 464 minecraft:red_terracotta
setblock 481 294 466 minecraft:light[level=14]
setblock 481 294 474 minecraft:light[level=14]
setblock 481 294 482 minecraft:light[level=14]
setblock 481 294 490 minecraft:light[level=14]
setblock 481 294 498 minecraft:light[level=14]
setblock 484 294 464 minecraft:terracotta
fill 484 294 465 487 294 465 minecraft:red_terracotta
setblock 484 294 503 minecraft:red_terracotta
setblock 484 294 504 minecraft:terracotta
fill 485 294 464 488 294 464 minecraft:red_terracotta
setblock 485 294 503 minecraft:terracotta
fill 485 294 504 485 297 504 minecraft:red_terracotta
fill 486 294 503 486 297 503 minecraft:red_terracotta
setblock 487 294 466 minecraft:terracotta
setblock 488 294 465 minecraft:terracotta
fill 488 294 466 491 294 466 minecraft:red_terracotta
setblock 489 294 464 minecraft:terracotta
fill 489 294 465 489 297 465 minecraft:red_terracotta
setblock 489 294 474 minecraft:light[level=14]
setblock 489 294 482 minecraft:light[level=14]
setblock 489 294 490 minecraft:light[level=14]
setblock 489 294 498 minecraft:light[level=14]
setblock 489 294 504 minecraft:terracotta
fill 490 294 464 490 297 464 minecraft:red_terracotta
setblock 490 294 503 minecraft:terracotta
fill 490 294 504 490 297 504 minecraft:red_terracotta
fill 491 294 503 491 297 503 minecraft:red_terracotta
setblock 492 294 465 minecraft:red_terracotta
setblock 492 294 466 minecraft:terracotta
setblock 493 294 465 minecraft:terracotta
setblock 494 294 464 minecraft:terracotta
fill 494 294 465 494 297 465 minecraft:red_terracotta
setblock 494 294 504 minecraft:terracotta
fill 495 294 464 498 294 464 minecraft:red_terracotta
setblock 495 294 503 minecraft:terracotta
fill 495 294 504 498 294 504 minecraft:red_terracotta
fill 496 294 503 499 294 503 minecraft:red_terracotta
setblock 497 294 465 minecraft:red_terracotta
setblock 497 294 466 minecraft:light[level=14]
setblock 497 294 474 minecraft:light[level=14]
setblock 497 294 482 minecraft:light[level=14]
setblock 497 294 490 minecraft:light[level=14]
setblock 497 294 498 minecraft:light[level=14]
setblock 498 294 465 minecraft:terracotta
setblock 499 294 464 minecraft:terracotta
fill 499 294 465 502 294 465 minecraft:red_terracotta
setblock 499 294 504 minecraft:terracotta
fill 500 294 464 500 297 464 minecraft:red_terracotta
setblock 500 294 503 minecraft:terracotta
fill 500 294 504 500 297 504 minecraft:red_terracotta
fill 501 294 503 501 297 503 minecraft:red_terracotta
fill 502 294 502 502 297 502 minecraft:red_terracotta
setblock 503 294 465 minecraft:terracotta
setblock 504 294 464 minecraft:terracotta
fill 504 294 465 507 294 465 minecraft:red_terracotta
setblock 504 294 504 minecraft:terracotta
fill 505 294 464 505 297 464 minecraft:red_terracotta
setblock 505 294 466 minecraft:light[level=14]
setblock 505 294 474 minecraft:light[level=14]
setblock 505 294 482 minecraft:light[level=14]
setblock 505 294 490 minecraft:light[level=14]
setblock 505 294 498 minecraft:light[level=14]
fill 505 294 501 505 295 501 minecraft:red_terracotta
setblock 505 294 503 minecraft:terracotta
fill 505 294 504 505 297 504 minecraft:red_terracotta
setblock 506 294 466 minecraft:red_terracotta
setblock 506 294 502 minecraft:terracotta
fill 506 294 503 506 297 503 minecraft:red_terracotta
setblock 507 294 466 minecraft:terracotta
setblock 507 294 501 minecraft:terracotta
fill 507 294 502 507 297 502 minecraft:red_terracotta
setblock 508 294 465 minecraft:terracotta
fill 508 294 466 508 297 466 minecraft:red_terracotta
setblock 508 294 499 minecraft:red_terracotta
setblock 508 294 500 minecraft:terracotta
fill 508 294 501 508 297 501 minecraft:red_terracotta
setblock 509 294 464 minecraft:terracotta
fill 509 294 465 509 297 465 minecraft:red_terracotta
fill 509 294 481 509 294 483 minecraft:red_terracotta
setblock 509 294 484 minecraft:terracotta
fill 509 294 485 511 295 485 minecraft:red_terracotta
setblock 509 294 499 minecraft:terracotta
fill 509 294 500 509 297 500 minecraft:red_terracotta
setblock 509 294 504 minecraft:terracotta
fill 510 294 464 510 297 464 minecraft:red_terracotta
setblock 510 294 467 minecraft:red_terracotta
setblock 510 294 478 minecraft:terracotta
fill 510 294 479 510 296 479 minecraft:red_terracotta
setblock 510 294 482 minecraft:red_terracotta
setblock 510 294 483 minecraft:terracotta
fill 510 294 484 511 296 484 minecraft:red_terracotta
fill 510 294 486 510 294 487 minecraft:red_terracotta
setblock 510 294 488 minecraft:terracotta
fill 510 294 489 510 294 492 minecraft:red_terracotta
setblock 510 294 493 minecraft:terracotta
fill 510 294 494 510 297 494 minecraft:red_terracotta
setblock 510 294 498 minecraft:terracotta
fill 510 294 499 510 297 499 minecraft:red_terracotta
setblock 510 294 503 minecraft:terracotta
fill 510 294 504 510 297 504 minecraft:red_terracotta
setblock 511 294 467 minecraft:terracotta
fill 511 294 468 511 296 469 minecraft:red_terracotta
setblock 511 294 477 minecraft:terracotta
fill 511 294 478 511 297 478 minecraft:red_terracotta
setblock 511 294 482 minecraft:terracotta
fill 511 294 483 511 297 483 minecraft:red_terracotta
setblock 511 294 486 minecraft:red_terracotta
setblock 511 294 487 minecraft:terracotta
fill 511 294 488 511 297 488 minecraft:red_terracotta
setblock 511 294 492 minecraft:terracotta
fill 511 294 493 511 297 493 minecraft:red_terracotta
setblock 511 294 497 minecraft:terracotta
fill 511 294 498 511 297 498 minecraft:red_terracotta
setblock 511 294 502 minecraft:terracotta
fill 511 294 503 511 297 503 minecraft:red_terracotta
setblock 471 295 466 minecraft:terracotta
fill 471 295 467 471 298 467 minecraft:red_terracotta
setblock 471 295 475 minecraft:red_terracotta
setblock 471 295 476 minecraft:terracotta
fill 471 295 477 471 295 480 minecraft:red_terracotta
setblock 471 295 481 minecraft:terracotta
fill 471 295 482 471 295 485 minecraft:red_terracotta
setblock 471 295 486 minecraft:terracotta
fill 471 295 487 471 295 490 minecraft:red_terracotta
setblock 471 295 491 minecraft:terracotta
fill 471 295 492 471 295 495 minecraft:red_terracotta
setblock 471 295 496 minecraft:terracotta
fill 471 295 497 471 298 497 minecraft:red_terracotta
setblock 471 295 501 minecraft:terracotta
fill 471 295 502 471 298 502 minecraft:red_terracotta
setblock 472 295 480 minecraft:terracotta
fill 472 295 481 472 298 481 minecraft:red_terracotta
setblock 472 295 484 minecraft:red_terracotta
setblock 472 295 485 minecraft:terracotta
fill 472 295 486 472 295 489 minecraft:red_terracotta
setblock 472 295 490 minecraft:terracotta
fill 472 295 491 472 298 491 minecraft:red_terracotta
setblock 472 295 495 minecraft:terracotta
setblock 472 295 496 minecraft:red_terracotta
setblock 472 295 500 minecraft:terracotta
fill 472 295 501 472 297 501 minecraft:red_terracotta
setblock 473 295 464 minecraft:terracotta
setblock 473 295 480 minecraft:red_terracotta
setblock 473 295 484 minecraft:terracotta
fill 473 295 485 473 298 485 minecraft:red_terracotta
setblock 473 295 504 minecraft:terracotta
fill 474 295 464 474 298 464 minecraft:red_terracotta
setblock 474 295 503 minecraft:terracotta
fill 474 295 504 474 298 504 minecraft:red_terracotta
setblock 478 295 504 minecraft:terracotta
fill 479 295 504 482 295 504 minecraft:red_terracotta
fill 480 295 464 482 295 464 minecraft:red_terracotta
setblock 483 295 464 minecraft:terracotta
fill 483 295 465 486 295 465 minecraft:red_terracotta
setblock 483 295 503 minecraft:red_terracotta
setblock 483 295 504 minecraft:terracotta
fill 484 295 464 487 295 464 minecraft:red_terracotta
setblock 484 295 503 minecraft:terracotta
fill 484 295 504 484 298 504 minecraft:red_terracotta
setblock 485 295 466 minecraft:red_terracotta
fill 485 295 503 485 298 503 minecraft:red_terracotta
setblock 486 295 466 minecraft:terracotta
setblock 487 295 465 minecraft:terracotta
fill 487 295 466 490 295 466 minecraft:red_terracotta
setblock 488 295 464 minecraft:terracotta
fill 488 295 465 488 298 465 minecraft:red_terracotta
fill 488 295 502 489 295 502 minecraft:red_terracotta
setblock 488 295 504 minecraft:terracotta
fill 489 295 464 489 298 464 minecraft:red_terracotta
setblock 489 295 503 minecraft:terracotta
fill 489 295 504 489 298 504 minecraft:red_terracotta
fill 490 295 503 490 298 503 minecraft:red_terracotta
setblock 491 295 466 minecraft:terracotta
setblock 492 295 465 minecraft:terracotta
fill 492 295 466 493 297 466 minecraft:red_terracotta
setblock 493 295 464 minecraft:terracotta
fill 493 295 465 493 298 465 minecraft:red_terracotta
setblock 493 295 503 minecraft:red_terracotta
setblock 493 295 504 minecraft:terracotta
fill 494 295 464 497 295 464 minecraft:red_terracotta
setblock 494 295 503 minecraft:terracotta
fill 494 295 504 497 295 504 minecraft:red_terracotta
fill 495 295 503 498 295 503 minecraft:red_terracotta
setblock 497 295 465 minecraft:terracotta
setblock 498 295 464 minecraft:terracotta
fill 498 295 465 501 295 465 minecraft:red_terracotta
setblock 498 295 504 minecraft:terracotta
fill 499 295 464 499 298 464 minecraft:red_terracotta
setblock 499 295 503 minecraft:terracotta
fill 499 295 504 499 298 504 minecraft:red_terracotta
fill 500 295 503 500 298 503 minecraft:red_terracotta
fill 501 295 502 501 298 502 minecraft:red_terracotta
setblock 502 295 465 minecraft:terracotta
setblock 503 295 464 minecraft:terracotta
fill 503 295 465 505 295 466 minecraft:red_terracotta
setblock 503 295 504 minecraft:terracotta
fill 504 295 464 504 298 464 minecraft:red_terracotta
setblock 504 295 503 minecraft:terracotta
fill 504 295 504 504 298 504 minecraft:red_terracotta
setblock 505 295 502 minecraft:terracotta
fill 505 295 503 505 298 503 minecraft:red_terracotta
setblock 506 295 465 minecraft:red_terracotta
setblock 506 295 466 minecraft:terracotta
setblock 506 295 501 minecraft:terracotta
fill 506 295 502 506 298 502 minecraft:red_terracotta
setblock 507 295 465 minecraft:terracotta
fill 507 295 466 507 298 466 minecraft:red_terracotta
fill 507 295 501 507 298 501 minecraft:red_terracotta
setblock 508 295 464 minecraft:terracotta
fill 508 295 465 508 298 465 minecraft:red_terracotta
setblock 508 295 499 minecraft:terracotta
fill 508 295 500 508 297 500 minecraft:red_terracotta
setblock 508 295 504 minecraft:terracotta
fill 509 295 464 509 298 464 minecraft:red_terracotta
fill 509 295 466 509 296 466 minecraft:red_terracotta
fill 509 295 481 509 295 482 minecraft:red_terracotta
setblock 509 295 483 minecraft:terracotta
fill 509 295 484 509 298 484 minecraft:red_terracotta
fill 509 295 486 509 295 487 minecraft:red_terracotta
setblock 509 295 498 minecraft:terracotta
fill 509 295 499 509 298 499 minecraft:red_terracotta
setblock 509 295 503 minecraft:terracotta
fill 509 295 504 509 298 504 minecraft:red_terracotta
setblock 510 295 467 minecraft:terracotta
setblock 510 295 478 minecraft:red_terracotta
setblock 510 295 482 minecraft:terracotta
fill 510 295 483 510 298 483 minecraft:red_terracotta
setblock 510 295 486 minecraft:red_terracotta
setblock 510 295 487 minecraft:terracotta
fill 510 295 488 510 295 491 minecraft:red_terracotta
setblock 510 295 492 minecraft:terracotta
fill 510 295 493 510 298 493 minecraft:red_terracotta
setblock 510 295 497 minecraft:terracotta
fill 510 295 498 510 298 498 minecraft:red_terracotta
setblock 510 295 502 minecraft:terracotta
fill 510 295 503 510 298 503 minecraft:red_terracotta
setblock 511 295 466 minecraft:terracotta
fill 511 295 467 511 298 467 minecraft:red_terracotta
setblock 511 295 476 minecraft:terracotta
fill 511 295 477 511 296 477 minecraft:red_terracotta
setblock 511 295 481 minecraft:terracotta
fill 511 295 482 511 298 482 minecraft:red_terracotta
setblock 511 295 486 minecraft:terracotta
fill 511 295 487 511 298 487 minecraft:red_terracotta
setblock 511 295 491 minecraft:terracotta
fill 511 295 492 511 298 492 minecraft:red_terracotta
setblock 511 295 496 minecraft:terracotta
fill 511 295 497 511 298 497 minecraft:red_terracotta
setblock 511 295 501 minecraft:terracotta
fill 511 295 502 511 298 502 minecraft:red_terracotta
setblock 471 296 465 minecraft:terracotta
fill 471 296 466 471 299 466 minecraft:red_terracotta
fill 471 296 468 471 297 468 minecraft:red_terracotta
setblock 471 296 475 minecraft:terracotta
fill 471 296 476 471 296 479 minecraft:red_terracotta
setblock 471 296 480 minecraft:terracotta
fill 471 296 481 471 296 484 minecraft:red_terracotta
setblock 471 296 485 minecraft:terracotta
fill 471 296 486 471 296 489 minecraft:red_terracotta
setblock 471 296 490 minecraft:terracotta
fill 471 296 491 471 296 494 minecraft:red_terracotta
setblock 471 296 495 minecraft:terracotta
fill 471 296 496 471 298 496 minecraft:red_terracotta
setblock 471 296 500 minecraft:terracotta
fill 471 296 501 471 299 501 minecraft:red_terracotta
setblock 472 296 464 minecraft:terracotta
setblock 472 296 479 minecraft:terracotta
fill 472 296 480 472 298 480 minecraft:red_terracotta
setblock 472 296 484 minecraft:terracotta
fill 472 296 485 472 296 488 minecraft:red_terracotta
setblock 472 296 489 minecraft:terracotta
fill 472 296 490 472 299 490 minecraft:red_terracotta
setblock 472 296 499 minecraft:terracotta
setblock 472 296 500 minecraft:red_terracotta
setblock 472 296 504 minecraft:terracotta
fill 473 296 464 473 298 464 minecraft:red_terracotta
setblock 473 296 483 minecraft:terracotta
fill 473 296 484 473 298 484 minecraft:red_terracotta
setblock 473 296 488 minecraft:terracotta
setblock 473 296 503 minecraft:terracotta
fill 473 296 504 473 298 504 minecraft:red_terracotta
fill 475 296 464 475 297 464 minecraft:red_terracotta
setblock 476 296 504 minecraft:red_terracotta
setblock 477 296 504 minecraft:terracotta
fill 478 296 464 481 296 464 minecraft:red_terracotta
fill 478 296 504 481 296 504 minecraft:red_terracotta
setblock 481 296 465 minecraft:terracotta
setblock 482 296 464 minecraft:terracotta
fill 482 296 465 485 296 465 minecraft:red_terracotta
setblock 482 296 503 minecraft:red_terracotta
setblock 482 296 504 minecraft:terracotta
fill 483 296 464 486 296 464 minecraft:red_terracotta
setblock 483 296 503 minecraft:terracotta
fill 483 296 504 483 299 504 minecraft:red_terracotta
setblock 484 296 466 minecraft:red_terracotta
fill 484 296 503 484 299 503 minecraft:red_terracotta
setblock 485 296 466 minecraft:terracotta
setblock 486 296 465 minecraft:terracotta
fill 486 296 466 489 296 466 minecraft:red_terracotta
setblock 487 296 464 minecraft:terracotta
fill 487 296 465 487 299 465 minecraft:red_terracotta
setblock 487 296 504 minecraft:terracotta
fill 488 296 464 488 299 464 minecraft:red_terracotta
setblock 488 296 503 minecraft:terracotta
fill 488 296 504 488 299 504 minecraft:red_terracotta
fill 489 296 503 489 299 503 minecraft:red_terracotta
setblock 490 296 466 minecraft:terracotta
setblock 491 296 465 minecraft:terracotta
fill 491 296 466 491 299 466 minecraft:red_terracotta
setblock 492 296 464 minecraft:terracotta
fill 492 296 465 492 299 465 minecraft:red_terracotta
setblock 492 296 504 minecraft:terracotta
fill 493 296 464 496 296 464 minecraft:red_terracotta
setblock 493 296 503 minecraft:terracotta
fill 493 296 504 496 296 504 minecraft:red_terracotta
fill 494 296 503 497 296 503 minecraft:red_terracotta
setblock 495 296 465 minecraft:red_terracotta
setblock 496 296 465 minecraft:terracotta
setblock 497 296 464 minecraft:terracotta
fill 497 296 465 500 296 465 minecraft:red_terracotta
setblock 497 296 504 minecraft:terracotta
fill 498 296 464 498 299 464 minecraft:red_terracotta
setblock 498 296 503 minecraft:terracotta
fill 498 296 504 498 299 504 minecraft:red_terracotta
fill 499 296 503 499 299 503 minecraft:red_terracotta
setblock 501 296 465 minecraft:terracotta
setblock 502 296 464 minecraft:terracotta
fill 502 296 465 504 296 466 minecraft:red_terracotta
setblock 502 296 504 minecraft:terracotta
fill 503 296 464 503 299 464 minecraft:red_terracotta
setblock 503 296 503 minecraft:terracotta
fill 503 296 504 503 299 504 minecraft:red_terracotta
setblock 504 296 501 minecraft:red_terracotta
setblock 504 296 502 minecraft:terracotta
fill 504 296 503 504 299 503 minecraft:red_terracotta
setblock 505 296 465 minecraft:red_terracotta
setblock 505 296 466 minecraft:terracotta
setblock 505 296 501 minecraft:terracotta
fill 505 296 502 505 299 502 minecraft:red_terracotta
setblock 506 296 465 minecraft:terracotta
fill 506 296 466 506 299 466 minecraft:red_terracotta
fill 506 296 501 506 298 501 minecraft:red_terracotta
setblock 507 296 464 minecraft:terracotta
fill 507 296 465 507 299 465 minecraft:red_terracotta
setblock 507 296 504 minecraft:terracotta
fill 508 296 464 508 299 464 minecraft:red_terracotta
setblock 508 296 499 minecraft:red_terracotta
setblock 508 296 503 minecraft:terracotta
fill 508 296 504 508 299 504 minecraft:red_terracotta
setblock 509 296 482 minecraft:terracotta
fill 509 296 483 509 298 483 minecraft:red_terracotta
fill 509 296 485 509 296 486 minecraft:red_terracotta
setblock 509 296 487 minecraft:terracotta
fill 509 296 488 510 297 489 minecraft:red_terracotta
setblock 509 296 497 minecraft:terracotta
fill 509 296 498 509 297 498 minecraft:red_terracotta
setblock 509 296 502 minecraft:terracotta
fill 509 296 503 509 299 503 minecraft:red_terracotta
setblock 510 296 466 minecraft:terracotta
fill 510 296 467 510 298 467 minecraft:red_terracotta
setblock 510 296 481 minecraft:terracotta
fill 510 296 482 510 299 482 minecraft:red_terracotta
setblock 510 296 485 minecraft:red_terracotta
setblock 510 296 486 minecraft:terracotta
fill 510 296 487 510 299 487 minecraft:red_terracotta
setblock 510 296 490 minecraft:red_terracotta
setblock 510 296 491 minecraft:terracotta
fill 510 296 492 510 299 492 minecraft:red_terracotta
setblock 510 296 496 minecraft:terracotta
fill 510 296 497 510 299 497 minecraft:red_terracotta
setblock 510 296 501 minecraft:terracotta
fill 510 296 502 510 299 502 minecraft:red_terracotta
setblock 511 296 465 minecraft:terracotta
fill 511 296 466 511 299 466 minecraft:red_terracotta
setblock 511 296 480 minecraft:terracotta
fill 511 296 481 511 299 481 minecraft:red_terracotta
setblock 511 296 485 minecraft:terracotta
fill 511 296 486 511 299 486 minecraft:red_terracotta
setblock 511 296 490 minecraft:terracotta
fill 511 296 491 511 299 491 minecraft:red_terracotta
setblock 511 296 495 minecraft:terracotta
fill 511 296 496 511 299 496 minecraft:red_terracotta
setblock 511 296 500 minecraft:terracotta
fill 511 296 501 511 299 501 minecraft:red_terracotta
setblock 471 297 464 minecraft:terracotta
fill 471 297 465 471 300 465 minecraft:red_terracotta
fill 471 297 476 471 297 478 minecraft:red_terracotta
setblock 471 297 479 minecraft:terracotta
fill 471 297 480 471 297 483 minecraft:red_terracotta
setblock 471 297 484 minecraft:terracotta
fill 471 297 485 471 297 488 minecraft:red_terracotta
setblock 471 297 489 minecraft:terracotta
fill 471 297 490 471 297 493 minecraft:red_terracotta
setblock 471 297 494 minecraft:terracotta
fill 471 297 495 471 299 495 minecraft:red_terracotta
setblock 471 297 499 minecraft:terracotta
fill 471 297 500 471 298 500 minecraft:red_terracotta
setblock 471 297 504 minecraft:terracotta
fill 472 297 464 472 299 464 minecraft:red_terracotta
setblock 472 297 479 minecraft:red_terracotta
setblock 472 297 483 minecraft:terracotta
fill 472 297 484 472 297 487 minecraft:red_terracotta
setblock 472 297 488 minecraft:terracotta
fill 472 297 489 472 300 489 minecraft:red_terracotta
setblock 472 297 503 minecraft:terracotta
fill 472 297 504 472 299 504 minecraft:red_terracotta
setblock 473 297 482 minecraft:terracotta
fill 473 297 483 473 298 483 minecraft:red_terracotta
setblock 473 297 486 minecraft:red_terracotta
setblock 473 297 487 minecraft:terracotta
fill 473 297 488 473 298 488 minecraft:red_terracotta
setblock 476 297 464 minecraft:terracotta
setblock 476 297 504 minecraft:terracotta
fill 477 297 464 480 297 464 minecraft:red_terracotta
fill 477 297 504 480 297 504 minecraft:red_terracotta
setblock 481 297 464 minecraft:terracotta
fill 481 297 465 484 297 465 minecraft:red_terracotta
setblock 481 297 504 minecraft:terracotta
fill 482 297 464 485 297 464 minecraft:red_terracotta
setblock 482 297 503 minecraft:terracotta
fill 482 297 504 482 300 504 minecraft:red_terracotta
setblock 483 297 466 minecraft:red_terracotta
fill 483 297 503 483 298 503 minecraft:red_terracotta
setblock 484 297 466 minecraft:terracotta
fill 484 297 469 485 297 471 minecraft:orange_concrete
setblock 485 297 465 minecraft:terracotta
fill 485 297 466 488 297 466 minecraft:red_terracotta
fill 485 297 467 485 297 468 minecraft:orange_concrete
fill 485 297 472 486 297 473 minecraft:orange_concrete
setblock 486 297 464 minecraft:terracotta
fill 486 297 465 486 300 465 minecraft:red_terracotta
fill 486 297 467 487 297 467 minecraft:red_terracotta
fill 486 297 468 486 299 469 minecraft:orange_concrete
fill 486 297 471 486 299 471 minecraft:orange_concrete
fill 486 297 474 491 297 474 minecraft:orange_concrete
setblock 486 297 504 minecraft:terracotta
fill 487 297 464 487 300 464 minecraft:red_terracotta
fill 487 297 468 487 299 468 minecraft:orange_concrete
fill 487 297 473 492 297 473 minecraft:orange_concrete
setblock 487 297 503 minecraft:terracotta
fill 487 297 504 487 300 504 minecraft:red_terracotta
setblock 488 297 467 minecraft:terracotta
fill 488 297 503 488 299 503 minecraft:red_terracotta
setblock 489 297 466 minecraft:terracotta
fill 489 297 467 489 298 467 minecraft:red_terracotta
setblock 490 297 465 minecraft:terracotta
fill 490 297 466 490 300 466 minecraft:red_terracotta
fill 490 297 467 492 297 468 minecraft:orange_concrete
setblock 491 297 464 minecraft:terracotta
fill 491 297 465 491 300 465 minecraft:red_terracotta
fill 491 297 469 493 297 469 minecraft:orange_concrete
fill 491 297 471 493 297 472 minecraft:orange_concrete
setblock 491 297 504 minecraft:terracotta
fill 492 297 464 495 297 464 minecraft:red_terracotta
fill 492 297 470 493 297 470 minecraft:orange_concrete
setblock 492 297 503 minecraft:terracotta
fill 492 297 504 495 297 504 minecraft:red_terracotta
fill 493 297 503 496 297 503 minecraft:red_terracotta
setblock 495 297 465 minecraft:terracotta
setblock 496 297 464 minecraft:terracotta
fill 496 297 465 499 297 465 minecraft:red_terracotta
setblock 496 297 504 minecraft:terracotta
fill 497 297 464 497 300 464 minecraft:red_terracotta
setblock 497 297 503 minecraft:terracotta
fill 497 297 504 497 300 504 minecraft:red_terracotta
fill 498 297 503 498 299 503 minecraft:red_terracotta
setblock 500 297 465 minecraft:terracotta
fill 500 297 466 503 297 466 minecraft:red_terracotta
setblock 501 297 464 minecraft:terracotta
fill 501 297 465 504 297 465 minecraft:red_terracotta
setblock 501 297 504 minecraft:terracotta
fill 502 297 464 502 300 464 minecraft:red_terracotta
setblock 502 297 503 minecraft:terracotta
fill 502 297 504 502 300 504 minecraft:red_terracotta
setblock 503 297 502 minecraft:terracotta
fill 503 297 503 503 300 503 minecraft:red_terracotta
setblock 504 297 466 minecraft:terracotta
fill 504 297 478 505 297 480 minecraft:orange_concrete
setblock 504 297 501 minecraft:terracotta
fill 504 297 502 504 300 502 minecraft:red_terracotta
setblock 505 297 465 minecraft:terracotta
fill 505 297 466 505 300 466 minecraft:red_terracotta
fill 505 297 476 506 297 477 minecraft:orange_concrete
fill 505 297 481 509 297 481 minecraft:orange_concrete
fill 505 297 501 505 298 501 minecraft:red_terracotta
setblock 506 297 464 minecraft:terracotta
fill 506 297 465 506 300 465 minecraft:red_terracotta
fill 506 297 482 508 297 482 minecraft:orange_concrete
setblock 506 297 504 minecraft:terracotta
fill 507 297 464 507 300 464 minecraft:red_terracotta
fill 507 297 475 508 297 476 minecraft:orange_concrete
setblock 507 297 503 minecraft:terracotta
fill 507 297 504 507 300 504 minecraft:red_terracotta
setblock 508 297 502 minecraft:terracotta
fill 508 297 503 508 300 503 minecraft:red_terracotta
setblock 509 297 466 minecraft:terracotta
fill 509 297 476 510 297 477 minecraft:orange_concrete
setblock 509 297 482 minecraft:red_terracotta
setblock 509 297 485 minecraft:red_terracotta
setblock 509 297 486 minecraft:terracotta
fill 509 297 487 509 300 487 minecraft:red_terracotta
setblock 509 297 490 minecraft:red_terracotta
setblock 509 297 497 minecraft:red_terracotta
setblock 509 297 501 minecraft:terracotta
fill 509 297 502 509 299 502 minecraft:red_terracotta
setblock 510 297 465 minecraft:terracotta
fill 510 297 466 510 299 466 minecraft:red_terracotta
fill 510 297 478 510 299 479 minecraft:orange_concrete
setblock 510 297 480 minecraft:terracotta
fill 510 297 481 510 298 481 minecraft:red_terracotta
setblock 510 297 484 minecraft:red_terracotta
setblock 510 297 485 minecraft:terracotta
fill 510 297 486 510 300 486 minecraft:red_terracotta
setblock 510 297 490 minecraft:terracotta
fill 510 297 491 510 300 491 minecraft:red_terracotta
setblock 510 297 495 minecraft:terracotta
fill 510 297 496 510 298 496 minecraft:red_terracotta
setblock 510 297 500 minecraft:terracotta
fill 510 297 501 510 300 501 minecraft:red_terracotta
setblock 511 297 464 minecraft:terracotta
fill 511 297 465 511 300 465 minecraft:red_terracotta
setblock 511 297 468 minecraft:red_terracotta
setblock 511 297 469 minecraft:terracotta
setblock 511 297 479 minecraft:terracotta
fill 511 297 480 511 298 480 minecraft:red_terracotta
setblock 511 297 484 minecraft:terracotta
fill 511 297 485 511 300 485 minecraft:red_terracotta
setblock 511 297 489 minecraft:terracotta
fill 511 297 490 511 300 490 minecraft:red_terracotta
setblock 511 297 494 minecraft:terracotta
fill 511 297 495 511 300 495 minecraft:red_terracotta
setblock 511 297 499 minecraft:terracotta
fill 511 297 500 511 300 500 minecraft:red_terracotta
setblock 511 297 504 minecraft:terracotta
fill 471 298 464 471 300 464 minecraft:red_terracotta
setblock 471 298 468 minecraft:terracotta
setblock 471 298 477 minecraft:red_terracotta
setblock 471 298 478 minecraft:terracotta
fill 471 298 479 471 298 482 minecraft:red_terracotta
setblock 471 298 483 minecraft:terracotta
fill 471 298 484 471 298 487 minecraft:red_terracotta
setblock 471 298 488 minecraft:terracotta
fill 471 298 489 471 298 492 minecraft:red_terracotta
setblock 471 298 493 minecraft:terracotta
fill 471 298 494 471 300 494 minecraft:red_terracotta
setblock 471 298 498 minecraft:terracotta
setblock 471 298 499 minecraft:red_terracotta
setblock 471 298 503 minecraft:terracotta
fill 471 298 504 471 299 504 minecraft:red_terracotta
setblock 472 298 482 minecraft:terracotta
fill 472 298 483 472 298 486 minecraft:red_terracotta
setblock 472 298 487 minecraft:terracotta
fill 472 298 488 472 300 488 minecraft:red_terracotta
setblock 473 298 486 minecraft:terracotta
fill 473 298 487 473 299 487 minecraft:red_terracotta
fill 476 298 464 479 298 464 minecraft:red_terracotta
setblock 479 298 504 minecraft:red_terracotta
setblock 480 298 464 minecraft:terracotta
fill 480 298 465 483 298 465 minecraft:red_terracotta
setblock 480 298 504 minecraft:terracotta
fill 481 298 464 484 298 464 minecraft:red_terracotta
fill 481 298 504 481 300 504 minecraft:red_terracotta
setblock 482 298 466 minecraft:red_terracotta
setblock 483 298 466 minecraft:terracotta
setblock 484 298 465 minecraft:terracotta
fill 484 298 466 487 298 466 minecraft:red_terracotta
setblock 485 298 464 minecraft:terracotta
fill 485 298 465 485 300 465 minecraft:red_terracotta
fill 485 298 467 486 298 467 minecraft:red_terracotta
fill 485 298 468 485 298 472 minecraft:orange_concrete
setblock 485 298 504 minecraft:terracotta
fill 486 298 464 486 300 464 minecraft:red_terracotta
fill 486 298 472 486 298 473 minecraft:orange_concrete
setblock 486 298 503 minecraft:terracotta
fill 486 298 504 486 300 504 minecraft:red_terracotta
setblock 487 298 467 minecraft:terracotta
fill 487 298 473 491 298 473 minecraft:orange_concrete
fill 487 298 503 487 299 503 minecraft:red_terracotta
setblock 488 298 466 minecraft:terracotta
fill 488 298 467 488 299 467 minecraft:red_terracotta
fill 488 298 474 489 298 474 minecraft:orange_concrete
setblock 489 298 465 minecraft:terracotta
fill 489 298 466 489 300 466 minecraft:red_terracotta
setblock 490 298 464 minecraft:terracotta
fill 490 298 465 490 300 465 minecraft:red_terracotta
fill 490 298 467 491 298 468 minecraft:orange_concrete
setblock 490 298 504 minecraft:terracotta
fill 491 298 464 494 298 464 minecraft:red_terracotta
fill 491 298 469 492 298 469 minecraft:orange_concrete
fill 491 298 471 492 298 472 minecraft:orange_concrete
setblock 491 298 503 minecraft:terracotta
fill 491 298 504 494 298 504 minecraft:red_terracotta
setblock 492 298 466 minecraft:red_terracotta
setblock 492 298 468 minecraft:orange_concrete
setblock 492 298 470 minecraft:orange_concrete
setblock 492 298 503 minecraft:red_terracotta
setblock 493 298 466 minecraft:terracotta
setblock 494 298 465 minecraft:terracotta
setblock 495 298 464 minecraft:terracotta
fill 495 298 465 498 298 465 minecraft:red_terracotta
setblock 495 298 504 minecraft:terracotta
fill 496 298 464 496 300 464 minecraft:red_terracotta
fill 496 298 504 496 300 504 minecraft:red_terracotta
setblock 497 298 503 minecraft:red_terracotta
setblock 499 298 465 minecraft:terracotta
setblock 500 298 464 minecraft:terracotta
fill 500 298 465 502 298 466 minecraft:red_terracotta
setblock 500 298 504 minecraft:terracotta
fill 501 298 464 501 300 464 minecraft:red_terracotta
setblock 501 298 503 minecraft:terracotta
fill 501 298 504 501 300 504 minecraft:red_terracotta
setblock 502 298 502 minecraft:terracotta
fill 502 298 503 502 300 503 minecraft:red_terracotta
setblock 503 298 465 minecraft:red_terracotta
setblock 503 298 466 minecraft:terracotta
fill 503 298 502 503 300 502 minecraft:red_terracotta
setblock 504 298 465 minecraft:terracotta
fill 504 298 466 504 300 466 minecraft:red_terracotta
setblock 505 298 464 minecraft:terracotta
fill 505 298 465 505 300 465 minecraft:red_terracotta
fill 505 298 477 505 298 480 minecraft:orange_concrete
setblock 505 298 504 minecraft:terracotta
fill 506 298 464 506 300 464 minecraft:red_terracotta
fill 506 298 476 506 298 477 minecraft:orange_concrete
fill 506 298 481 509 298 481 minecraft:orange_concrete
setblock 506 298 503 minecraft:terracotta
fill 506 298 504 506 300 504 minecraft:red_terracotta
fill 507 298 476 509 298 476 minecraft:orange_concrete
setblock 507 298 502 minecraft:terracotta
fill 507 298 503 507 300 503 minecraft:red_terracotta
setblock 508 298 466 minecraft:terracotta
fill 508 298 502 508 300 502 minecraft:red_terracotta
setblock 509 298 465 minecraft:terracotta
setblock 509 298 466 minecraft:red_terracotta
fill 509 298 477 510 298 477 minecraft:orange_concrete
setblock 509 298 485 minecraft:terracotta
fill 509 298 486 509 300 486 minecraft:red_terracotta
fill 509 298 488 509 298 489 minecraft:red_terracotta
setblock 509 298 490 minecraft:terracotta
setblock 509 298 500 minecraft:terracotta
fill 509 298 501 509 299 501 minecraft:red_terracotta
setblock 510 298 464 minecraft:terracotta
fill 510 298 465 510 300 465 minecraft:red_terracotta
setblock 510 298 480 minecraft:orange_concrete
setblock 510 298 484 minecraft:terracotta
fill 510 298 485 510 300 485 minecraft:red_terracotta
setblock 510 298 488 minecraft:red_terracotta
setblock 510 298 489 minecraft:terracotta
fill 510 298 490 510 300 490 minecraft:red_terracotta
setblock 510 298 494 minecraft:terracotta
fill 510 298 495 510 299 495 minecraft:red_terracotta
setblock 510 298 499 minecraft:terracotta
fill 510 298 500 510 299 500 minecraft:red_terracotta
setblock 510 298 504 minecraft:terracotta
fill 511 298 464 511 300 464 minecraft:red_terracotta
setblock 511 298 468 minecraft:terracotta
setblock 511 298 479 minecraft:red_terracotta
setblock 511 298 483 minecraft:terracotta
fill 511 298 484 511 300 484 minecraft:red_terracotta
setblock 511 298 488 minecraft:terracotta
fill 511 298 489 511 300 489 minecraft:red_terracotta
setblock 511 298 493 minecraft:terracotta
fill 511 298 494 511 300 494 minecraft:red_terracotta
setblock 511 298 498 minecraft:terracotta
fill 511 298 499 511 300 499 minecraft:red_terracotta
setblock 511 298 503 minecraft:terracotta
fill 511 298 504 511 300 504 minecraft:red_terracotta
setblock 471 299 467 minecraft:terracotta
fill 471 299 478 471 299 481 minecraft:red_terracotta
setblock 471 299 482 minecraft:terracotta
fill 471 299 483 471 299 486 minecraft:red_terracotta
setblock 471 299 487 minecraft:terracotta
fill 471 299 488 471 299 491 minecraft:red_terracotta
setblock 471 299 492 minecraft:terracotta
fill 471 299 493 471 300 493 minecraft:red_terracotta
setblock 471 299 502 minecraft:terracotta
setblock 471 299 503 minecraft:red_terracotta
setblock 472 299 481 minecraft:terracotta
fill 472 299 482 472 299 485 minecraft:red_terracotta
setblock 472 299 486 minecraft:terracotta
fill 472 299 487 472 300 487 minecraft:red_terracotta
setblock 472 299 491 minecraft:terracotta
setblock 473 299 485 minecraft:terracotta
setblock 473 299 486 minecraft:red_terracotta
fill 477 299 464 478 299 464 minecraft:red_terracotta
setblock 479 299 464 minecraft:terracotta
fill 480 299 464 482 299 465 minecraft:red_terracotta
fill 480 299 504 480 300 504 minecraft:red_terracotta
setblock 482 299 466 minecraft:terracotta
setblock 483 299 464 minecraft:red_terracotta
setblock 483 299 465 minecraft:terracotta
fill 483 299 466 486 299 466 minecraft:red_terracotta
setblock 484 299 464 minecraft:terracotta
fill 484 299 465 484 300 465 minecraft:red_terracotta
fill 484 299 467 485 299 467 minecraft:red_terracotta
setblock 484 299 504 minecraft:terracotta
fill 485 299 464 485 300 464 minecraft:red_terracotta
setblock 485 299 503 minecraft:terracotta
fill 485 299 504 485 300 504 minecraft:red_terracotta
setblock 486 299 467 minecraft:terracotta
setblock 486 299 472 minecraft:orange_concrete
setblock 486 299 503 minecraft:red_terracotta
setblock 487 299 466 minecraft:terracotta
fill 487 299 467 487 300 467 minecraft:red_terracotta
fill 487 299 473 490 299 473 minecraft:orange_concrete
setblock 488 299 465 minecraft:terracotta
fill 488 299 466 488 300 466 minecraft:red_terracotta
setblock 489 299 464 minecraft:terracotta
fill 489 299 465 489 300 465 minecraft:red_terracotta
setblock 489 299 467 minecraft:orange_concrete
setblock 489 299 504 minecraft:terracotta
fill 490 299 464 493 299 464 minecraft:red_terracotta
fill 490 299 468 491 299 468 minecraft:orange_concrete
fill 490 299 504 493 299 504 minecraft:red_terracotta
setblock 491 299 469 minecraft:orange_concrete
fill 491 299 471 491 299 472 minecraft:orange_concrete
setblock 492 299 466 minecraft:terracotta
setblock 493 299 465 minecraft:terracotta
setblock 494 299 464 minecraft:terracotta
fill 494 299 465 497 299 465 minecraft:red_terracotta
setblock 494 299 504 minecraft:terracotta
fill 495 299 464 495 300 464 minecraft:red_terracotta
fill 495 299 504 495 300 504 minecraft:red_terracotta
setblock 498 299 465 minecraft:terracotta
setblock 499 299 464 minecraft:terracotta
fill 499 299 465 501 299 466 minecraft:red_terracotta
setblock 499 299 504 minecraft:terracotta
fill 500 299 464 500 300 464 minecraft:red_terracotta
setblock 500 299 503 minecraft:terracotta
fill 500 299 504 500 300 504 minecraft:red_terracotta
fill 501 299 503 501 300 503 minecraft:red_terracotta
setblock 502 299 465 minecraft:red_terracotta
setblock 502 299 466 minecraft:terracotta
fill 502 299 502 502 300 502 minecraft:red_terracotta
setblock 503 299 465 minecraft:terracotta
fill 503 299 466 503 300 466 minecraft:red_terracotta
setblock 504 299 464 minecraft:terracotta
fill 504 299 465 504 300 465 minecraft:red_terracotta
setblock 504 299 504 minecraft:terracotta
fill 505 299 464 505 300 464 minecraft:red_terracotta
setblock 505 299 479 minecraft:orange_concrete
setblock 505 299 503 minecraft:terracotta
fill 505 299 504 505 300 504 minecraft:red_terracotta
setblock 506 299 477 minecraft:orange_concrete
setblock 506 299 502 minecraft:terracotta
fill 506 299 503 506 300 503 minecraft:red_terracotta
setblock 507 299 466 minecraft:terracotta
fill 507 299 481 508 299 481 minecraft:orange_concrete
fill 507 299 502 507 300 502 minecraft:red_terracotta
setblock 508 299 465 minecraft:terracotta
setblock 508 299 466 minecraft:red_terracotta
setblock 509 299 464 minecraft:terracotta
fill 509 299 465 509 300 465 minecraft:red_terracotta
setblock 509 299 477 minecraft:orange_concrete
setblock 509 299 485 minecraft:red_terracotta
setblock 509 299 488 minecraft:red_terracotta
setblock 509 299 489 minecraft:terracotta
fill 509 299 490 509 300 490 minecraft:red_terracotta
setblock 509 299 504 minecraft:terracotta
fill 510 299 464 510 300 464 minecraft:red_terracotta
setblock 510 299 483 minecraft:terracotta
fill 510 299 484 510 300 484 minecraft:red_terracotta
setblock 510 299 488 minecraft:terracotta
fill 510 299 489 510 300 489 minecraft:red_terracotta
setblock 510 299 493 minecraft:terracotta
setblock 510 299 494 minecraft:red_terracotta
setblock 510 299 498 minecraft:terracotta
setblock 510 299 499 minecraft:red_terracotta
setblock 510 299 503 minecraft:terracotta
fill 510 299 504 510 300 504 minecraft:red_terracotta
setblock 511 299 467 minecraft:terracotta
setblock 511 299 468 minecraft:red_terracotta
setblock 511 299 482 minecraft:terracotta
fill 511 299 483 511 300 483 minecraft:red_terracotta
setblock 511 299 487 minecraft:terracotta
fill 511 299 488 511 300 488 minecraft:red_terracotta
setblock 511 299 492 minecraft:terracotta
fill 511 299 493 511 300 493 minecraft:red_terracotta
setblock 511 299 497 minecraft:terracotta
fill 511 299 498 511 300 498 minecraft:red_terracotta
setblock 511 299 502 minecraft:terracotta
fill 511 299 503 511 300 503 minecraft:red_terracotta
setblock 471 300 466 minecraft:terracotta
setblock 471 300 480 minecraft:red_terracotta
setblock 471 300 481 minecraft:terracotta
fill 471 300 482 471 300 485 minecraft:red_terracotta
setblock 471 300 486 minecraft:terracotta
fill 471 300 487 471 300 490 minecraft:red_terracotta
setblock 471 300 491 minecraft:terracotta
setblock 471 300 492 minecraft:red_terracotta
fill 472 300 482 472 300 484 minecraft:red_terracotta
setblock 472 300 485 minecraft:terracotta
setblock 472 300 486 minecraft:red_terracotta
setblock 472 300 490 minecraft:terracotta
setblock 477 300 464 minecraft:red_terracotta
setblock 478 300 464 minecraft:terracotta
fill 479 300 464 481 300 465 minecraft:red_terracotta
setblock 481 300 466 minecraft:terracotta
setblock 482 300 464 minecraft:red_terracotta
setblock 482 300 465 minecraft:terracotta
fill 482 300 466 485 300 466 minecraft:red_terracotta
setblock 483 300 464 minecraft:terracotta
setblock 483 300 465 minecraft:red_terracotta
setblock 483 300 504 minecraft:terracotta
setblock 484 300 464 minecraft:red_terracotta
setblock 484 300 467 minecraft:red_terracotta
setblock 484 300 504 minecraft:red_terracotta
setblock 485 300 467 minecraft:terracotta
setblock 486 300 466 minecraft:terracotta
setblock 486 300 467 minecraft:red_terracotta
setblock 486 300 503 minecraft:magma_block
setblock 487 300 465 minecraft:terracotta
setblock 487 300 466 minecraft:red_terracotta
setblock 487 300 503 minecraft:shroomlight
setblock 488 300 464 minecraft:terracotta
setblock 488 300 465 minecraft:red_terracotta
setblock 488 300 503 minecraft:magma_block
setblock 488 300 504 minecraft:terracotta
fill 489 300 464 492 300 464 minecraft:red_terracotta
fill 489 300 504 492 300 504 minecraft:red_terracotta
setblock 491 300 466 minecraft:terracotta
setblock 492 300 465 minecraft:terracotta
setblock 493 300 464 minecraft:terracotta
fill 493 300 465 496 300 465 minecraft:red_terracotta
setblock 493 300 504 minecraft:terracotta
setblock 494 300 464 minecraft:red_terracotta
setblock 494 300 504 minecraft:red_terracotta
setblock 497 300 465 minecraft:terracotta
setblock 498 300 464 minecraft:terracotta
fill 498 300 465 501 300 465 minecraft:red_terracotta
setblock 498 300 504 minecraft:terracotta
setblock 499 300 464 minecraft:red_terracotta
fill 499 300 466 500 300 466 minecraft:red_terracotta
setblock 499 300 503 minecraft:terracotta
setblock 499 300 504 minecraft:red_terracotta
setblock 500 300 503 minecraft:red_terracotta
setblock 501 300 466 minecraft:terracotta
setblock 502 300 465 minecraft:terracotta
setblock 502 300 466 minecraft:red_terracotta
setblock 503 300 464 minecraft:terracotta
setblock 503 300 465 minecraft:red_terracotta
setblock 503 300 504 minecraft:terracotta
setblock 504 300 464 minecraft:red_terracotta
setblock 504 300 503 minecraft:terracotta
setblock 504 300 504 minecraft:red_terracotta
setblock 505 300 502 minecraft:terracotta
setblock 505 300 503 minecraft:red_terracotta
setblock 506 300 466 minecraft:terracotta
setblock 506 300 502 minecraft:red_terracotta
setblock 507 300 465 minecraft:terracotta
setblock 507 300 466 minecraft:red_terracotta
setblock 508 300 464 minecraft:terracotta
setblock 508 300 465 minecraft:red_terracotta
setblock 508 300 504 minecraft:terracotta
setblock 509 300 464 minecraft:red_terracotta
setblock 509 300 488 minecraft:terracotta
setblock 509 300 489 minecraft:red_terracotta
setblock 509 300 503 minecraft:terracotta
setblock 509 300 504 minecraft:red_terracotta
setblock 510 300 487 minecraft:terracotta
setblock 510 300 488 minecraft:red_terracotta
setblock 510 300 492 minecraft:terracotta
setblock 510 300 493 minecraft:red_terracotta
setblock 510 300 502 minecraft:terracotta
setblock 510 300 503 minecraft:red_terracotta
setblock 511 300 466 minecraft:terracotta
setblock 511 300 467 minecraft:red_terracotta
setblock 511 300 482 minecraft:red_terracotta
setblock 511 300 486 minecraft:terracotta
setblock 511 300 487 minecraft:red_terracotta
setblock 511 300 491 minecraft:terracotta
setblock 511 300 492 minecraft:red_terracotta
setblock 511 300 496 minecraft:terracotta
setblock 511 300 497 minecraft:red_terracotta
setblock 511 300 501 minecraft:terracotta
setblock 511 300 502 minecraft:red_terracotta
setblock 473 302 466 minecraft:light[level=14]
setblock 473 302 474 minecraft:light[level=14]
setblock 473 302 482 minecraft:light[level=14]
setblock 473 302 490 minecraft:light[level=14]
setblock 473 302 498 minecraft:light[level=14]
setblock 481 302 466 minecraft:light[level=14]
setblock 481 302 474 minecraft:light[level=14]
setblock 481 302 482 minecraft:light[level=14]
setblock 481 302 490 minecraft:light[level=14]
setblock 481 302 498 minecraft:light[level=14]
setblock 489 302 466 minecraft:light[level=14]
setblock 489 302 474 minecraft:light[level=14]
setblock 489 302 482 minecraft:light[level=14]
setblock 489 302 490 minecraft:light[level=14]
setblock 489 302 498 minecraft:light[level=14]
setblock 497 302 466 minecraft:light[level=14]
setblock 497 302 474 minecraft:light[level=14]
setblock 497 302 482 minecraft:light[level=14]
setblock 497 302 490 minecraft:light[level=14]
setblock 497 302 498 minecraft:light[level=14]
setblock 505 302 466 minecraft:light[level=14]
setblock 505 302 474 minecraft:light[level=14]
setblock 505 302 482 minecraft:light[level=14]
setblock 505 302 490 minecraft:light[level=14]
setblock 505 302 498 minecraft:light[level=14]
