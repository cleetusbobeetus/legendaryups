fill 237 120 285 237 125 287 minecraft:cut_sandstone
fill 237 120 297 237 125 299 minecraft:cut_sandstone
fill 237 120 309 237 125 311 minecraft:cut_sandstone
fill 239 120 304 241 122 304 minecraft:cut_sandstone
fill 240 120 275 240 142 275 minecraft:sandstone
setblock 240 120 299 minecraft:glowstone
fill 240 120 303 240 122 303 minecraft:cut_sandstone
fill 240 120 305 240 122 305 minecraft:cut_sandstone
fill 243 120 315 245 125 315 minecraft:cut_sandstone
fill 247 120 277 249 125 277 minecraft:cut_sandstone
fill 251 120 275 251 138 275 minecraft:sandstone
fill 255 120 276 255 121 276 minecraft:chiseled_sandstone
fill 255 120 315 257 125 315 minecraft:cut_sandstone
fill 259 120 277 261 125 277 minecraft:cut_sandstone
fill 267 120 315 269 125 315 minecraft:cut_sandstone
fill 271 120 277 273 125 277 minecraft:cut_sandstone
fill 275 120 285 275 125 287 minecraft:cut_sandstone
fill 275 120 289 275 121 289 minecraft:chiseled_sandstone
fill 275 120 291 275 121 291 minecraft:chiseled_sandstone
fill 275 120 293 275 121 293 minecraft:chiseled_sandstone
fill 275 120 297 275 125 299 minecraft:cut_sandstone
fill 275 120 309 275 125 311 minecraft:cut_sandstone
fill 277 120 302 277 125 302 minecraft:sandstone
fill 235 121 276 235 139 276 minecraft:sandstone
setblock 235 121 277 minecraft:black_terracotta
fill 235 121 278 235 161 279 minecraft:sandstone
setblock 235 121 284 minecraft:lapis_block
fill 235 121 291 235 181 291 minecraft:sandstone
setblock 240 121 286 minecraft:glowstone
setblock 242 121 286 minecraft:glowstone
setblock 242 121 292 minecraft:glowstone
setblock 242 121 298 minecraft:glowstone
setblock 242 121 304 minecraft:glowstone
setblock 242 121 310 minecraft:glowstone
fill 244 121 312 250 121 314 minecraft:chiseled_sandstone
setblock 246 121 282 minecraft:glowstone
fill 246 121 315 250 121 315 minecraft:chiseled_sandstone
setblock 248 121 310 minecraft:glowstone
setblock 249 121 275 minecraft:lapis_block
fill 250 121 275 250 203 275 minecraft:sandstone
setblock 252 121 282 minecraft:glowstone
setblock 254 121 310 minecraft:glowstone
setblock 258 121 282 minecraft:glowstone
setblock 260 121 310 minecraft:glowstone
setblock 264 121 282 minecraft:glowstone
setblock 266 121 310 minecraft:glowstone
setblock 270 121 282 minecraft:glowstone
setblock 270 121 288 minecraft:glowstone
setblock 270 121 294 minecraft:glowstone
setblock 270 121 300 minecraft:glowstone
setblock 270 121 306 minecraft:glowstone
fill 235 122 277 235 202 277 minecraft:sandstone
fill 235 122 284 235 125 284 minecraft:sandstone
fill 236 122 277 236 122 285 minecraft:cut_sandstone
fill 236 122 289 236 122 297 minecraft:cut_sandstone
fill 236 122 301 236 122 309 minecraft:cut_sandstone
fill 236 122 313 241 122 316 minecraft:cut_sandstone
fill 237 122 277 242 122 284 minecraft:cut_sandstone
fill 237 122 288 242 122 296 minecraft:cut_sandstone
fill 237 122 300 238 122 308 minecraft:cut_sandstone
fill 237 122 312 276 122 312 minecraft:cut_sandstone
fill 238 122 285 242 122 287 minecraft:cut_sandstone
fill 238 122 297 242 122 299 minecraft:cut_sandstone
fill 238 122 309 242 122 311 minecraft:cut_sandstone
fill 239 122 276 247 122 276 minecraft:cut_sandstone
fill 239 122 300 239 122 303 minecraft:cut_sandstone
fill 239 122 305 239 122 308 minecraft:cut_sandstone
fill 240 122 300 242 122 302 minecraft:cut_sandstone
fill 240 122 306 242 122 308 minecraft:cut_sandstone
fill 241 122 303 242 122 303 minecraft:cut_sandstone
fill 241 122 305 242 122 305 minecraft:cut_sandstone
setblock 242 122 304 minecraft:cut_sandstone
fill 242 122 313 242 122 315 minecraft:cut_sandstone
fill 243 122 277 246 122 282 minecraft:cut_sandstone
fill 243 122 310 274 122 311 minecraft:cut_sandstone
fill 243 122 313 276 122 314 minecraft:cut_sandstone
fill 245 122 316 253 122 316 minecraft:cut_sandstone
fill 246 122 315 254 122 315 minecraft:cut_sandstone
fill 247 122 278 276 122 282 minecraft:cut_sandstone
fill 249 122 275 249 186 275 minecraft:sandstone
fill 250 122 277 258 122 277 minecraft:cut_sandstone
fill 251 122 276 259 122 276 minecraft:cut_sandstone
setblock 253 122 317 minecraft:blue_terracotta
fill 254 122 317 254 200 317 minecraft:sandstone
fill 257 122 316 265 122 316 minecraft:cut_sandstone
fill 258 122 315 266 122 315 minecraft:cut_sandstone
fill 262 122 277 270 122 277 minecraft:cut_sandstone
fill 263 122 276 271 122 276 minecraft:cut_sandstone
fill 269 122 316 276 122 316 minecraft:cut_sandstone
fill 270 122 283 274 122 309 minecraft:cut_sandstone
fill 270 122 315 276 122 315 minecraft:cut_sandstone
fill 274 122 277 276 122 277 minecraft:cut_sandstone
fill 275 122 276 276 122 276 minecraft:cut_sandstone
fill 275 122 283 275 122 284 minecraft:cut_sandstone
fill 275 122 288 275 122 296 minecraft:cut_sandstone
fill 275 122 300 275 122 308 minecraft:cut_sandstone
setblock 276 122 283 minecraft:cut_sandstone
fill 276 122 287 276 122 295 minecraft:cut_sandstone
fill 276 122 299 276 122 307 minecraft:cut_sandstone
setblock 276 122 311 minecraft:cut_sandstone
fill 235 123 302 235 136 303 minecraft:sandstone
setblock 235 123 304 minecraft:blue_terracotta
setblock 238 123 278 minecraft:light[level=12]
setblock 238 123 285 minecraft:light[level=12]
setblock 238 123 292 minecraft:light[level=12]
setblock 238 123 299 minecraft:light[level=12]
setblock 238 123 306 minecraft:light[level=12]
setblock 238 123 313 minecraft:light[level=12]
fill 240 123 304 240 127 304 minecraft:cut_sandstone
fill 242 123 282 242 123 310 minecraft:lapis_block
fill 243 123 282 270 123 282 minecraft:lapis_block
fill 243 123 310 270 123 310 minecraft:lapis_block
fill 244 123 312 250 123 312 minecraft:lapis_block
setblock 245 123 278 minecraft:light[level=12]
setblock 245 123 285 minecraft:light[level=12]
setblock 245 123 292 minecraft:light[level=12]
setblock 245 123 299 minecraft:light[level=12]
setblock 245 123 306 minecraft:light[level=12]
setblock 245 123 313 minecraft:light[level=12]
fill 246 123 316 248 126 316 minecraft:glowstone
setblock 252 123 278 minecraft:light[level=12]
setblock 252 123 285 minecraft:light[level=12]
setblock 252 123 292 minecraft:light[level=12]
setblock 252 123 299 minecraft:light[level=12]
setblock 252 123 306 minecraft:light[level=12]
setblock 252 123 313 minecraft:light[level=12]
setblock 252 123 317 minecraft:blue_terracotta
fill 253 123 317 253 127 317 minecraft:sandstone
fill 256 123 314 260 125 314 minecraft:blue_wool
setblock 259 123 278 minecraft:light[level=12]
setblock 259 123 285 minecraft:light[level=12]
setblock 259 123 292 minecraft:light[level=12]
setblock 259 123 299 minecraft:light[level=12]
setblock 259 123 306 minecraft:light[level=12]
setblock 259 123 313 minecraft:light[level=12]
setblock 263 123 317 minecraft:black_terracotta
fill 264 123 317 268 126 317 minecraft:sandstone
setblock 266 123 278 minecraft:light[level=12]
setblock 266 123 285 minecraft:light[level=12]
setblock 266 123 292 minecraft:light[level=12]
setblock 266 123 299 minecraft:light[level=12]
setblock 266 123 306 minecraft:light[level=12]
setblock 266 123 313 minecraft:light[level=12]
fill 270 123 283 270 123 309 minecraft:lapis_block
setblock 273 123 278 minecraft:light[level=12]
setblock 273 123 285 minecraft:light[level=12]
setblock 273 123 292 minecraft:light[level=12]
setblock 273 123 299 minecraft:light[level=12]
setblock 273 123 306 minecraft:light[level=12]
setblock 273 123 313 minecraft:light[level=12]
setblock 277 123 279 minecraft:lapis_block
fill 235 124 304 235 143 304 minecraft:sandstone
setblock 244 124 312 minecraft:cut_sandstone
setblock 247 124 312 minecraft:cut_sandstone
setblock 250 124 312 minecraft:cut_sandstone
fill 252 124 317 252 155 317 minecraft:sandstone
fill 256 124 309 256 146 309 minecraft:cut_sandstone
fill 263 124 317 263 148 317 minecraft:sandstone
fill 277 124 279 277 125 279 minecraft:sandstone
setblock 235 125 285 minecraft:blue_terracotta
fill 235 125 286 235 156 286 minecraft:sandstone
setblock 235 125 287 minecraft:orange_terracotta
fill 235 125 288 235 130 288 minecraft:sandstone
fill 236 125 279 236 125 284 minecraft:chiseled_sandstone
fill 236 125 291 236 125 296 minecraft:chiseled_sandstone
fill 236 125 303 236 125 308 minecraft:chiseled_sandstone
fill 236 125 315 236 125 316 minecraft:chiseled_sandstone
fill 237 125 316 240 125 316 minecraft:chiseled_sandstone
fill 240 125 276 245 125 276 minecraft:chiseled_sandstone
fill 249 125 316 252 125 316 minecraft:chiseled_sandstone
fill 252 125 276 257 125 276 minecraft:chiseled_sandstone
fill 252 125 308 255 145 310 minecraft:cut_sandstone
fill 253 125 307 259 145 307 minecraft:cut_sandstone
fill 253 125 311 259 145 311 minecraft:cut_sandstone
fill 254 125 306 258 145 306 minecraft:cut_sandstone
fill 254 125 312 258 145 312 minecraft:cut_sandstone
fill 255 125 305 257 145 305 minecraft:cut_sandstone
fill 255 125 313 257 145 313 minecraft:cut_sandstone
fill 256 125 308 260 145 308 minecraft:cut_sandstone
fill 256 125 310 260 145 310 minecraft:cut_sandstone
fill 257 125 309 260 145 309 minecraft:cut_sandstone
fill 259 125 316 264 125 316 minecraft:chiseled_sandstone
fill 264 125 276 269 125 276 minecraft:chiseled_sandstone
fill 271 125 316 276 125 316 minecraft:chiseled_sandstone
fill 276 125 276 276 125 281 minecraft:chiseled_sandstone
fill 276 125 288 276 125 293 minecraft:chiseled_sandstone
fill 276 125 300 276 125 305 minecraft:chiseled_sandstone
fill 276 125 312 276 125 315 minecraft:chiseled_sandstone
fill 235 126 281 235 131 284 minecraft:glowstone
fill 235 126 285 235 154 285 minecraft:sandstone
fill 235 126 287 235 202 287 minecraft:sandstone
fill 235 126 293 235 131 296 minecraft:glowstone
fill 235 126 305 235 131 308 minecraft:glowstone
fill 235 126 317 238 131 317 minecraft:glowstone
fill 242 126 275 245 131 275 minecraft:glowstone
fill 247 126 317 250 131 317 minecraft:glowstone
fill 251 126 307 251 144 311 minecraft:cut_sandstone
fill 252 126 305 252 144 307 minecraft:cut_sandstone
fill 252 126 311 252 144 313 minecraft:cut_sandstone
fill 253 126 305 253 144 306 minecraft:cut_sandstone
fill 253 126 312 253 144 313 minecraft:cut_sandstone
fill 254 126 275 257 131 275 minecraft:glowstone
fill 254 126 304 254 144 305 minecraft:cut_sandstone
fill 254 126 313 254 144 314 minecraft:cut_sandstone
fill 255 126 304 258 144 304 minecraft:cut_sandstone
fill 255 126 314 258 144 314 minecraft:cut_sandstone
fill 258 126 305 260 144 305 minecraft:cut_sandstone
fill 258 126 313 260 144 313 minecraft:cut_sandstone
fill 259 126 306 260 144 306 minecraft:cut_sandstone
fill 259 126 312 260 144 312 minecraft:cut_sandstone
fill 259 126 314 260 126 314 minecraft:blue_wool
fill 259 126 317 262 131 317 minecraft:glowstone
fill 260 126 307 261 144 307 minecraft:cut_sandstone
fill 260 126 311 261 144 311 minecraft:cut_sandstone
fill 261 126 308 261 144 310 minecraft:cut_sandstone
fill 266 126 275 269 131 275 minecraft:glowstone
setblock 269 126 317 minecraft:lapis_block
fill 271 126 317 274 131 317 minecraft:glowstone
fill 277 126 276 277 131 279 minecraft:glowstone
fill 277 126 288 277 131 291 minecraft:glowstone
fill 277 126 300 277 131 303 minecraft:glowstone
fill 277 126 312 277 131 315 minecraft:glowstone
setblock 238 127 278 minecraft:light[level=15]
setblock 238 127 286 minecraft:light[level=15]
setblock 238 127 294 minecraft:light[level=15]
setblock 238 127 302 minecraft:light[level=15]
setblock 238 127 310 minecraft:light[level=15]
setblock 246 127 278 minecraft:light[level=15]
setblock 246 127 286 minecraft:light[level=15]
setblock 246 127 294 minecraft:light[level=15]
setblock 246 127 302 minecraft:light[level=15]
setblock 246 127 310 minecraft:light[level=15]
fill 250 127 306 250 143 312 minecraft:cut_sandstone
fill 251 127 305 251 143 306 minecraft:cut_sandstone
fill 251 127 312 251 143 313 minecraft:cut_sandstone
fill 252 127 304 253 143 304 minecraft:cut_sandstone
fill 252 127 314 253 143 314 minecraft:cut_sandstone
fill 253 127 303 259 143 303 minecraft:cut_sandstone
fill 253 127 315 259 143 315 minecraft:cut_sandstone
setblock 254 127 278 minecraft:light[level=15]
setblock 254 127 286 minecraft:light[level=15]
setblock 254 127 294 minecraft:light[level=15]
setblock 254 127 302 minecraft:light[level=15]
fill 259 127 304 260 143 304 minecraft:cut_sandstone
fill 259 127 314 260 143 314 minecraft:cut_sandstone
fill 261 127 305 261 143 306 minecraft:cut_sandstone
fill 261 127 312 261 143 313 minecraft:cut_sandstone
setblock 262 127 278 minecraft:light[level=15]
setblock 262 127 286 minecraft:light[level=15]
setblock 262 127 294 minecraft:light[level=15]
setblock 262 127 302 minecraft:light[level=15]
fill 262 127 306 262 143 312 minecraft:cut_sandstone
setblock 264 127 317 minecraft:lapis_block
fill 265 127 317 269 189 317 minecraft:sandstone
setblock 270 127 278 minecraft:light[level=15]
setblock 270 127 286 minecraft:light[level=15]
setblock 270 127 294 minecraft:light[level=15]
setblock 270 127 302 minecraft:light[level=15]
setblock 270 127 310 minecraft:light[level=15]
setblock 240 128 304 minecraft:glowstone
fill 249 128 306 249 142 312 minecraft:cut_sandstone
fill 250 128 305 250 142 305 minecraft:cut_sandstone
fill 250 128 313 250 142 313 minecraft:cut_sandstone
fill 251 128 304 251 142 304 minecraft:cut_sandstone
fill 251 128 314 251 142 314 minecraft:cut_sandstone
fill 252 128 303 252 142 303 minecraft:cut_sandstone
fill 252 128 315 252 142 315 minecraft:cut_sandstone
fill 253 128 302 259 142 302 minecraft:cut_sandstone
fill 253 128 316 253 142 316 minecraft:cut_sandstone
setblock 253 128 317 minecraft:black_terracotta
fill 257 128 316 259 142 316 minecraft:cut_sandstone
fill 260 128 303 260 142 303 minecraft:cut_sandstone
fill 260 128 315 260 142 315 minecraft:cut_sandstone
fill 261 128 304 261 142 304 minecraft:cut_sandstone
fill 261 128 314 261 142 314 minecraft:cut_sandstone
fill 262 128 305 262 142 305 minecraft:cut_sandstone
fill 262 128 313 262 142 313 minecraft:cut_sandstone
fill 263 128 306 263 142 312 minecraft:cut_sandstone
setblock 264 128 317 minecraft:sandstone
setblock 238 129 278 minecraft:light[level=12]
setblock 238 129 285 minecraft:light[level=12]
setblock 238 129 292 minecraft:light[level=12]
setblock 238 129 299 minecraft:light[level=12]
setblock 238 129 306 minecraft:light[level=12]
setblock 238 129 313 minecraft:light[level=12]
setblock 245 129 278 minecraft:light[level=12]
setblock 245 129 285 minecraft:light[level=12]
setblock 245 129 292 minecraft:light[level=12]
setblock 245 129 299 minecraft:light[level=12]
setblock 245 129 306 minecraft:light[level=12]
setblock 245 129 313 minecraft:light[level=12]
fill 248 129 307 248 141 311 minecraft:cut_sandstone
fill 249 129 305 249 141 305 minecraft:cut_sandstone
fill 249 129 313 249 141 313 minecraft:cut_sandstone
fill 250 129 304 250 141 304 minecraft:cut_sandstone
fill 250 129 314 250 141 314 minecraft:cut_sandstone
fill 251 129 303 251 141 303 minecraft:cut_sandstone
fill 251 129 315 251 141 315 minecraft:cut_sandstone
setblock 252 129 278 minecraft:light[level=12]
setblock 252 129 285 minecraft:light[level=12]
setblock 252 129 292 minecraft:light[level=12]
setblock 252 129 299 minecraft:light[level=12]
fill 252 129 302 252 141 302 minecraft:cut_sandstone
fill 252 129 316 252 141 316 minecraft:cut_sandstone
fill 253 129 317 253 171 317 minecraft:sandstone
fill 254 129 301 258 141 301 minecraft:cut_sandstone
setblock 259 129 278 minecraft:light[level=12]
setblock 259 129 285 minecraft:light[level=12]
setblock 259 129 292 minecraft:light[level=12]
setblock 259 129 299 minecraft:light[level=12]
fill 260 129 302 260 141 302 minecraft:cut_sandstone
fill 260 129 316 260 141 316 minecraft:cut_sandstone
fill 261 129 303 261 141 303 minecraft:cut_sandstone
fill 261 129 315 261 141 315 minecraft:cut_sandstone
fill 262 129 304 262 141 304 minecraft:cut_sandstone
fill 262 129 314 262 141 314 minecraft:cut_sandstone
fill 263 129 305 263 141 305 minecraft:cut_sandstone
fill 263 129 313 263 141 313 minecraft:cut_sandstone
fill 264 129 307 264 141 311 minecraft:cut_sandstone
setblock 264 129 317 minecraft:black_terracotta
setblock 266 129 278 minecraft:light[level=12]
setblock 266 129 285 minecraft:light[level=12]
setblock 266 129 292 minecraft:light[level=12]
setblock 266 129 299 minecraft:light[level=12]
setblock 266 129 306 minecraft:light[level=12]
setblock 266 129 313 minecraft:light[level=12]
setblock 273 129 278 minecraft:light[level=12]
setblock 273 129 285 minecraft:light[level=12]
setblock 273 129 292 minecraft:light[level=12]
setblock 273 129 299 minecraft:light[level=12]
setblock 273 129 306 minecraft:light[level=12]
setblock 273 129 313 minecraft:light[level=12]
setblock 274 129 275 minecraft:orange_terracotta
setblock 277 129 306 minecraft:lapis_block
fill 277 129 307 277 185 307 minecraft:sandstone
fill 248 130 306 248 140 306 minecraft:cut_sandstone
fill 248 130 312 248 140 312 minecraft:cut_sandstone
fill 249 130 304 249 140 304 minecraft:cut_sandstone
fill 249 130 314 249 140 314 minecraft:cut_sandstone
fill 250 130 303 250 140 303 minecraft:cut_sandstone
fill 250 130 315 250 140 315 minecraft:cut_sandstone
fill 251 130 302 251 140 302 minecraft:cut_sandstone
fill 251 130 316 251 140 316 minecraft:cut_sandstone
fill 253 130 300 256 130 300 minecraft:chiseled_sandstone
fill 253 130 301 253 140 301 minecraft:cut_sandstone
fill 259 130 300 259 131 300 minecraft:chiseled_sandstone
fill 259 130 301 259 140 301 minecraft:cut_sandstone
fill 261 130 302 261 140 302 minecraft:cut_sandstone
fill 261 130 316 261 140 316 minecraft:cut_sandstone
fill 262 130 303 262 140 303 minecraft:cut_sandstone
fill 262 130 315 262 140 315 minecraft:cut_sandstone
fill 263 130 304 263 140 304 minecraft:cut_sandstone
fill 263 130 314 263 140 314 minecraft:cut_sandstone
fill 264 130 306 264 140 306 minecraft:cut_sandstone
fill 264 130 312 264 140 312 minecraft:cut_sandstone
fill 264 130 317 264 202 317 minecraft:sandstone
fill 274 130 275 274 202 275 minecraft:sandstone
fill 277 130 306 277 190 306 minecraft:sandstone
setblock 235 131 288 minecraft:lapis_block
fill 247 131 307 247 139 311 minecraft:cut_sandstone
fill 248 131 305 248 139 305 minecraft:cut_sandstone
fill 248 131 313 248 139 313 minecraft:cut_sandstone
fill 249 131 303 249 139 303 minecraft:cut_sandstone
fill 249 131 315 249 139 315 minecraft:cut_sandstone
fill 250 131 302 250 139 302 minecraft:cut_sandstone
fill 250 131 316 250 139 316 minecraft:cut_sandstone
fill 252 131 301 252 139 301 minecraft:cut_sandstone
setblock 253 131 300 minecraft:chiseled_sandstone
fill 254 131 300 256 139 300 minecraft:cut_sandstone
fill 260 131 301 260 139 301 minecraft:cut_sandstone
fill 262 131 302 262 139 302 minecraft:cut_sandstone
fill 262 131 316 262 139 316 minecraft:cut_sandstone
fill 263 131 303 263 139 303 minecraft:cut_sandstone
fill 263 131 315 263 139 315 minecraft:cut_sandstone
fill 264 131 305 264 139 305 minecraft:cut_sandstone
fill 264 131 313 264 139 313 minecraft:cut_sandstone
fill 265 131 307 265 139 311 minecraft:cut_sandstone
fill 235 132 281 235 145 281 minecraft:sandstone
fill 235 132 282 235 132 283 minecraft:glowstone
fill 235 132 284 235 145 284 minecraft:sandstone
fill 235 132 288 235 141 288 minecraft:sandstone
fill 235 132 293 235 142 293 minecraft:sandstone
fill 235 132 294 235 132 295 minecraft:glowstone
fill 235 132 296 235 145 296 minecraft:sandstone
fill 235 132 305 235 145 305 minecraft:sandstone
fill 235 132 306 235 132 307 minecraft:glowstone
fill 235 132 308 235 145 308 minecraft:sandstone
fill 235 132 317 235 145 317 minecraft:sandstone
fill 236 132 275 236 198 275 minecraft:sandstone
fill 236 132 317 237 132 317 minecraft:glowstone
setblock 237 132 275 minecraft:orange_terracotta
fill 238 132 317 238 141 317 minecraft:sandstone
fill 242 132 275 242 144 275 minecraft:sandstone
fill 243 132 275 244 132 275 minecraft:glowstone
fill 245 132 275 245 145 275 minecraft:sandstone
fill 247 132 306 247 138 306 minecraft:cut_sandstone
fill 247 132 312 247 138 312 minecraft:cut_sandstone
fill 247 132 317 247 145 317 minecraft:sandstone
fill 248 132 304 248 138 304 minecraft:cut_sandstone
fill 248 132 314 248 138 314 minecraft:cut_sandstone
fill 248 132 317 249 132 317 minecraft:glowstone
fill 250 132 317 250 145 317 minecraft:sandstone
fill 251 132 301 251 138 301 minecraft:cut_sandstone
fill 253 132 300 253 138 300 minecraft:cut_sandstone
fill 254 132 275 254 145 275 minecraft:sandstone
fill 255 132 275 256 132 275 minecraft:glowstone
fill 257 132 275 257 145 275 minecraft:sandstone
fill 259 132 300 259 138 300 minecraft:cut_sandstone
fill 259 132 317 259 145 317 minecraft:sandstone
fill 260 132 317 261 132 317 minecraft:glowstone
fill 261 132 301 261 138 301 minecraft:cut_sandstone
fill 262 132 317 262 145 317 minecraft:sandstone
fill 264 132 304 264 138 304 minecraft:cut_sandstone
fill 264 132 314 264 138 314 minecraft:cut_sandstone
fill 265 132 306 265 138 306 minecraft:cut_sandstone
fill 265 132 312 265 138 312 minecraft:cut_sandstone
fill 266 132 275 266 145 275 minecraft:sandstone
fill 267 132 275 268 132 275 minecraft:glowstone
fill 269 132 275 269 138 275 minecraft:sandstone
fill 271 132 317 271 145 317 minecraft:sandstone
fill 272 132 317 273 132 317 minecraft:glowstone
fill 274 132 317 274 145 317 minecraft:sandstone
fill 277 132 276 277 145 276 minecraft:sandstone
fill 277 132 277 277 132 278 minecraft:glowstone
fill 277 132 279 277 145 279 minecraft:sandstone
fill 277 132 288 277 145 288 minecraft:sandstone
fill 277 132 289 277 132 290 minecraft:glowstone
fill 277 132 291 277 145 291 minecraft:sandstone
fill 277 132 300 277 145 300 minecraft:sandstone
fill 277 132 301 277 132 302 minecraft:glowstone
fill 277 132 303 277 145 303 minecraft:sandstone
fill 277 132 312 277 145 312 minecraft:sandstone
fill 277 132 313 277 132 314 minecraft:glowstone
fill 277 132 315 277 145 315 minecraft:sandstone
fill 235 133 282 235 145 283 minecraft:sandstone
fill 235 133 294 235 140 295 minecraft:sandstone
fill 235 133 306 235 145 307 minecraft:sandstone
fill 236 133 317 237 145 317 minecraft:sandstone
fill 237 133 275 237 154 275 minecraft:sandstone
fill 243 133 275 244 145 275 minecraft:sandstone
fill 247 133 294 248 134 295 minecraft:smooth_sandstone
fill 248 133 317 249 136 317 minecraft:sandstone
fill 255 133 275 256 145 275 minecraft:sandstone
fill 260 133 317 261 145 317 minecraft:sandstone
setblock 267 133 275 minecraft:orange_terracotta
fill 268 133 275 268 145 275 minecraft:sandstone
fill 272 133 317 273 145 317 minecraft:sandstone
fill 277 133 277 277 145 278 minecraft:sandstone
fill 277 133 289 277 145 290 minecraft:sandstone
fill 277 133 301 277 145 302 minecraft:sandstone
fill 277 133 313 277 145 314 minecraft:sandstone
fill 247 134 305 247 136 305 minecraft:cut_sandstone
fill 247 134 313 247 136 313 minecraft:cut_sandstone
fill 249 134 302 249 136 302 minecraft:cut_sandstone
fill 249 134 316 249 136 316 minecraft:cut_sandstone
fill 252 134 300 252 136 300 minecraft:cut_sandstone
fill 260 134 300 260 136 300 minecraft:cut_sandstone
fill 263 134 302 263 136 302 minecraft:cut_sandstone
fill 263 134 316 263 136 316 minecraft:cut_sandstone
fill 265 134 305 265 136 305 minecraft:cut_sandstone
fill 265 134 313 265 136 313 minecraft:cut_sandstone
fill 267 134 275 267 145 275 minecraft:sandstone
setblock 238 135 278 minecraft:light[level=15]
setblock 238 135 285 minecraft:light[level=12]
setblock 238 135 286 minecraft:light[level=15]
setblock 238 135 292 minecraft:light[level=12]
setblock 238 135 294 minecraft:light[level=15]
setblock 238 135 299 minecraft:light[level=12]
setblock 238 135 302 minecraft:light[level=15]
setblock 238 135 306 minecraft:light[level=12]
setblock 238 135 310 minecraft:light[level=15]
setblock 238 135 313 minecraft:light[level=12]
setblock 239 135 275 minecraft:blue_terracotta
setblock 245 135 278 minecraft:light[level=12]
setblock 245 135 285 minecraft:light[level=12]
setblock 245 135 292 minecraft:light[level=12]
setblock 245 135 299 minecraft:light[level=12]
setblock 245 135 306 minecraft:light[level=12]
setblock 245 135 313 minecraft:light[level=12]
setblock 246 135 278 minecraft:light[level=15]
setblock 246 135 286 minecraft:light[level=15]
setblock 246 135 294 minecraft:light[level=15]
setblock 246 135 302 minecraft:light[level=15]
setblock 246 135 309 minecraft:cut_sandstone
setblock 246 135 310 minecraft:light[level=15]
setblock 248 135 303 minecraft:cut_sandstone
setblock 248 135 315 minecraft:cut_sandstone
setblock 250 135 301 minecraft:cut_sandstone
setblock 252 135 278 minecraft:light[level=12]
setblock 252 135 285 minecraft:light[level=12]
setblock 252 135 292 minecraft:light[level=12]
setblock 252 135 299 minecraft:light[level=12]
setblock 254 135 278 minecraft:light[level=15]
setblock 254 135 286 minecraft:light[level=15]
setblock 254 135 294 minecraft:light[level=15]
setblock 259 135 278 minecraft:light[level=12]
setblock 259 135 285 minecraft:light[level=12]
setblock 259 135 292 minecraft:light[level=12]
setblock 259 135 299 minecraft:light[level=12]
setblock 262 135 278 minecraft:light[level=15]
setblock 262 135 286 minecraft:light[level=15]
setblock 262 135 294 minecraft:light[level=15]
setblock 262 135 301 minecraft:cut_sandstone
setblock 264 135 303 minecraft:cut_sandstone
setblock 264 135 315 minecraft:cut_sandstone
setblock 266 135 278 minecraft:light[level=12]
setblock 266 135 285 minecraft:light[level=12]
setblock 266 135 292 minecraft:light[level=12]
setblock 266 135 299 minecraft:light[level=12]
setblock 266 135 306 minecraft:light[level=12]
setblock 266 135 309 minecraft:cut_sandstone
setblock 266 135 313 minecraft:light[level=12]
setblock 270 135 278 minecraft:light[level=15]
setblock 270 135 286 minecraft:light[level=15]
setblock 270 135 294 minecraft:light[level=15]
setblock 270 135 302 minecraft:light[level=15]
setblock 270 135 310 minecraft:light[level=15]
setblock 273 135 278 minecraft:light[level=12]
setblock 273 135 285 minecraft:light[level=12]
setblock 273 135 292 minecraft:light[level=12]
setblock 273 135 299 minecraft:light[level=12]
setblock 273 135 306 minecraft:light[level=12]
setblock 273 135 313 minecraft:light[level=12]
fill 235 136 299 235 199 299 minecraft:sandstone
setblock 235 136 300 minecraft:orange_terracotta
setblock 235 136 312 minecraft:blue_terracotta
fill 239 136 275 239 202 275 minecraft:sandstone
fill 251 136 300 251 138 300 minecraft:glowstone
fill 261 136 300 261 138 300 minecraft:glowstone
fill 277 136 297 277 193 297 minecraft:sandstone
setblock 277 136 298 minecraft:blue_terracotta
fill 235 137 300 235 202 300 minecraft:sandstone
setblock 235 137 302 minecraft:blue_terracotta
fill 235 137 303 235 161 303 minecraft:sandstone
fill 235 137 312 235 200 312 minecraft:sandstone
fill 248 137 317 248 145 317 minecraft:sandstone
setblock 249 137 317 minecraft:black_terracotta
setblock 250 137 301 minecraft:glowstone
fill 252 137 299 252 137 300 minecraft:glowstone
setblock 253 137 299 minecraft:glowstone
fill 257 137 300 257 139 300 minecraft:cut_sandstone
setblock 258 137 275 minecraft:blue_terracotta
fill 260 137 300 260 138 300 minecraft:glowstone
setblock 262 137 301 minecraft:glowstone
fill 267 137 313 267 139 313 minecraft:shroomlight
setblock 277 137 284 minecraft:blue_terracotta
fill 277 137 285 277 139 286 minecraft:sandstone
fill 277 137 298 277 145 298 minecraft:sandstone
fill 235 138 302 235 202 302 minecraft:sandstone
fill 235 138 313 235 200 313 minecraft:sandstone
setblock 235 138 314 minecraft:orange_terracotta
fill 249 138 317 249 140 317 minecraft:sandstone
setblock 252 138 300 minecraft:glowstone
fill 258 138 275 258 164 275 minecraft:sandstone
fill 258 138 300 258 139 300 minecraft:cut_sandstone
fill 263 138 275 264 154 275 minecraft:sandstone
setblock 265 138 275 minecraft:blue_terracotta
fill 277 138 284 277 202 284 minecraft:sandstone
fill 235 139 314 235 202 314 minecraft:sandstone
setblock 251 139 275 minecraft:lapis_block
fill 265 139 275 265 199 275 minecraft:sandstone
setblock 269 139 275 minecraft:lapis_block
setblock 277 139 304 minecraft:black_terracotta
setblock 235 140 276 minecraft:orange_terracotta
fill 237 140 285 237 145 287 minecraft:cut_sandstone
fill 237 140 297 237 145 299 minecraft:cut_sandstone
fill 237 140 309 237 145 311 minecraft:cut_sandstone
fill 243 140 315 245 145 315 minecraft:cut_sandstone
fill 247 140 277 249 145 277 minecraft:cut_sandstone
fill 251 140 275 251 202 275 minecraft:sandstone
fill 259 140 277 261 145 277 minecraft:cut_sandstone
fill 267 140 315 269 145 315 minecraft:cut_sandstone
fill 269 140 275 269 145 275 minecraft:sandstone
setblock 270 140 275 minecraft:blue_terracotta
fill 271 140 277 273 145 277 minecraft:cut_sandstone
fill 275 140 285 275 145 287 minecraft:cut_sandstone
fill 275 140 297 275 145 299 minecraft:cut_sandstone
fill 275 140 309 275 145 311 minecraft:cut_sandstone
fill 277 140 285 277 203 285 minecraft:sandstone
setblock 277 140 286 minecraft:lapis_block
fill 277 140 304 277 182 304 minecraft:sandstone
setblock 277 140 316 minecraft:orange_terracotta
fill 235 141 276 235 204 276 minecraft:sandstone
fill 235 141 294 235 145 294 minecraft:sandstone
setblock 235 141 295 minecraft:lapis_block
setblock 238 141 278 minecraft:light[level=12]
setblock 238 141 285 minecraft:light[level=12]
setblock 238 141 292 minecraft:light[level=12]
setblock 238 141 299 minecraft:light[level=12]
setblock 238 141 306 minecraft:light[level=12]
setblock 238 141 313 minecraft:light[level=12]
setblock 245 141 278 minecraft:light[level=12]
setblock 245 141 285 minecraft:light[level=12]
setblock 245 141 292 minecraft:light[level=12]
setblock 245 141 299 minecraft:light[level=12]
setblock 245 141 306 minecraft:light[level=12]
setblock 245 141 313 minecraft:light[level=12]
setblock 249 141 317 minecraft:blue_terracotta
setblock 252 141 278 minecraft:light[level=12]
setblock 252 141 285 minecraft:light[level=12]
setblock 252 141 292 minecraft:light[level=12]
setblock 252 141 299 minecraft:light[level=12]
setblock 259 141 278 minecraft:light[level=12]
setblock 259 141 285 minecraft:light[level=12]
setblock 259 141 292 minecraft:light[level=12]
setblock 259 141 299 minecraft:light[level=12]
setblock 266 141 278 minecraft:light[level=12]
setblock 266 141 285 minecraft:light[level=12]
setblock 266 141 292 minecraft:light[level=12]
setblock 266 141 299 minecraft:light[level=12]
setblock 266 141 306 minecraft:light[level=12]
setblock 266 141 313 minecraft:light[level=12]
fill 270 141 275 270 202 275 minecraft:sandstone
setblock 273 141 278 minecraft:light[level=12]
setblock 273 141 285 minecraft:light[level=12]
setblock 273 141 292 minecraft:light[level=12]
setblock 273 141 299 minecraft:light[level=12]
setblock 273 141 306 minecraft:light[level=12]
setblock 273 141 313 minecraft:light[level=12]
fill 277 141 286 277 202 286 minecraft:sandstone
setblock 277 141 295 minecraft:lapis_block
fill 277 141 296 277 198 296 minecraft:sandstone
fill 277 141 316 277 182 316 minecraft:sandstone
setblock 235 142 288 minecraft:orange_terracotta
fill 235 142 295 235 145 295 minecraft:sandstone
setblock 238 142 317 minecraft:black_terracotta
fill 249 142 317 249 145 317 minecraft:sandstone
setblock 277 142 280 minecraft:orange_terracotta
fill 277 142 295 277 167 295 minecraft:sandstone
fill 235 143 288 235 202 288 minecraft:sandstone
setblock 235 143 293 minecraft:lapis_block
setblock 238 143 278 minecraft:light[level=15]
setblock 238 143 286 minecraft:light[level=15]
setblock 238 143 294 minecraft:light[level=15]
setblock 238 143 302 minecraft:light[level=15]
setblock 238 143 310 minecraft:light[level=15]
fill 238 143 317 238 145 317 minecraft:sandstone
setblock 240 143 275 minecraft:blue_terracotta
setblock 246 143 278 minecraft:light[level=15]
setblock 246 143 286 minecraft:light[level=15]
setblock 246 143 294 minecraft:light[level=15]
setblock 246 143 302 minecraft:light[level=15]
setblock 246 143 310 minecraft:light[level=15]
setblock 254 143 278 minecraft:light[level=15]
setblock 254 143 286 minecraft:light[level=15]
setblock 254 143 294 minecraft:light[level=15]
setblock 254 143 302 minecraft:light[level=15]
setblock 262 143 278 minecraft:light[level=15]
setblock 262 143 286 minecraft:light[level=15]
setblock 262 143 294 minecraft:light[level=15]
setblock 262 143 302 minecraft:light[level=15]
setblock 270 143 278 minecraft:light[level=15]
setblock 270 143 286 minecraft:light[level=15]
setblock 270 143 294 minecraft:light[level=15]
setblock 270 143 302 minecraft:light[level=15]
setblock 270 143 310 minecraft:light[level=15]
fill 277 143 280 277 202 280 minecraft:sandstone
setblock 277 143 311 minecraft:black_terracotta
fill 235 144 293 235 145 293 minecraft:sandstone
setblock 235 144 304 minecraft:lapis_block
fill 240 144 275 240 145 275 minecraft:sandstone
fill 255 144 315 257 145 315 minecraft:cut_sandstone
fill 264 144 287 266 145 287 minecraft:sandstone
fill 265 144 286 265 145 286 minecraft:sandstone
fill 265 144 288 265 145 288 minecraft:sandstone
fill 277 144 281 277 198 281 minecraft:sandstone
setblock 277 144 282 minecraft:black_terracotta
fill 277 144 311 277 151 311 minecraft:sandstone
setblock 235 145 298 minecraft:lapis_block
fill 235 145 304 235 190 304 minecraft:sandstone
fill 236 145 279 236 145 284 minecraft:chiseled_sandstone
fill 236 145 291 236 145 296 minecraft:chiseled_sandstone
fill 236 145 303 236 145 308 minecraft:chiseled_sandstone
fill 236 145 315 236 145 316 minecraft:chiseled_sandstone
fill 237 145 316 240 145 316 minecraft:chiseled_sandstone
fill 240 145 276 245 145 276 minecraft:chiseled_sandstone
setblock 242 145 275 minecraft:black_terracotta
fill 247 145 316 252 145 316 minecraft:chiseled_sandstone
fill 252 145 276 257 145 276 minecraft:chiseled_sandstone
fill 259 145 316 264 145 316 minecraft:chiseled_sandstone
fill 264 145 276 269 145 276 minecraft:chiseled_sandstone
fill 271 145 316 276 145 316 minecraft:chiseled_sandstone
fill 276 145 276 276 145 281 minecraft:chiseled_sandstone
fill 276 145 288 276 145 293 minecraft:chiseled_sandstone
fill 276 145 300 276 145 305 minecraft:chiseled_sandstone
fill 276 145 312 276 145 315 minecraft:chiseled_sandstone
fill 277 145 282 277 150 282 minecraft:sandstone
fill 235 146 281 235 151 284 minecraft:glowstone
fill 235 146 293 235 151 296 minecraft:glowstone
fill 235 146 298 235 157 298 minecraft:sandstone
fill 235 146 305 235 151 308 minecraft:glowstone
fill 235 146 317 238 151 317 minecraft:glowstone
setblock 240 146 275 minecraft:orange_terracotta
fill 242 146 275 245 151 275 minecraft:glowstone
fill 247 146 317 250 151 317 minecraft:glowstone
fill 254 146 275 257 151 275 minecraft:glowstone
fill 259 146 317 262 151 317 minecraft:glowstone
setblock 262 146 275 minecraft:black_terracotta
fill 266 146 275 269 151 275 minecraft:glowstone
fill 271 146 317 274 151 317 minecraft:glowstone
fill 273 146 310 273 148 310 minecraft:shroomlight
fill 277 146 276 277 151 279 minecraft:glowstone
fill 277 146 288 277 151 291 minecraft:glowstone
setblock 277 146 298 minecraft:blue_terracotta
fill 277 146 300 277 151 303 minecraft:glowstone
fill 277 146 312 277 151 315 minecraft:glowstone
setblock 238 147 278 minecraft:light[level=12]
setblock 238 147 285 minecraft:light[level=12]
setblock 238 147 292 minecraft:light[level=12]
setblock 238 147 299 minecraft:light[level=12]
setblock 238 147 306 minecraft:light[level=12]
setblock 238 147 313 minecraft:light[level=12]
fill 240 147 275 240 165 275 minecraft:sandstone
setblock 245 147 278 minecraft:light[level=12]
setblock 245 147 285 minecraft:light[level=12]
setblock 245 147 292 minecraft:light[level=12]
setblock 245 147 299 minecraft:light[level=12]
setblock 245 147 306 minecraft:light[level=12]
setblock 245 147 313 minecraft:light[level=12]
setblock 252 147 278 minecraft:light[level=12]
setblock 252 147 285 minecraft:light[level=12]
setblock 252 147 292 minecraft:light[level=12]
setblock 252 147 299 minecraft:light[level=12]
setblock 252 147 306 minecraft:light[level=12]
setblock 252 147 313 minecraft:light[level=12]
setblock 259 147 278 minecraft:light[level=12]
setblock 259 147 285 minecraft:light[level=12]
setblock 259 147 292 minecraft:light[level=12]
setblock 259 147 299 minecraft:light[level=12]
setblock 259 147 306 minecraft:light[level=12]
setblock 259 147 313 minecraft:light[level=12]
fill 262 147 275 262 203 275 minecraft:sandstone
setblock 266 147 278 minecraft:light[level=12]
setblock 266 147 285 minecraft:light[level=12]
setblock 266 147 292 minecraft:light[level=12]
setblock 266 147 299 minecraft:light[level=12]
setblock 266 147 306 minecraft:light[level=12]
setblock 266 147 313 minecraft:light[level=12]
setblock 273 147 278 minecraft:light[level=12]
setblock 273 147 285 minecraft:light[level=12]
setblock 273 147 292 minecraft:light[level=12]
setblock 273 147 299 minecraft:light[level=12]
setblock 273 147 306 minecraft:light[level=12]
setblock 273 147 313 minecraft:light[level=12]
fill 277 147 298 277 189 298 minecraft:sandstone
setblock 235 148 310 minecraft:black_terracotta
fill 235 149 310 235 180 310 minecraft:sandstone
setblock 263 149 317 minecraft:lapis_block
setblock 239 150 317 minecraft:black_terracotta
fill 263 150 317 263 194 317 minecraft:sandstone
setblock 277 150 299 minecraft:orange_terracotta
setblock 238 151 278 minecraft:light[level=15]
setblock 238 151 286 minecraft:light[level=15]
setblock 238 151 294 minecraft:light[level=15]
setblock 238 151 302 minecraft:light[level=15]
setblock 238 151 310 minecraft:light[level=15]
fill 239 151 317 239 188 317 minecraft:sandstone
setblock 246 151 278 minecraft:light[level=15]
setblock 246 151 286 minecraft:light[level=15]
setblock 246 151 294 minecraft:light[level=15]
setblock 246 151 302 minecraft:light[level=15]
setblock 246 151 310 minecraft:light[level=15]
setblock 254 151 278 minecraft:light[level=15]
setblock 254 151 286 minecraft:light[level=15]
setblock 254 151 294 minecraft:light[level=15]
setblock 254 151 302 minecraft:light[level=15]
setblock 254 151 310 minecraft:light[level=15]
setblock 262 151 278 minecraft:light[level=15]
setblock 262 151 286 minecraft:light[level=15]
setblock 262 151 294 minecraft:light[level=15]
setblock 262 151 302 minecraft:light[level=15]
setblock 262 151 310 minecraft:light[level=15]
setblock 270 151 278 minecraft:light[level=15]
setblock 270 151 286 minecraft:light[level=15]
setblock 270 151 294 minecraft:light[level=15]
setblock 270 151 302 minecraft:light[level=15]
setblock 270 151 310 minecraft:light[level=15]
setblock 277 151 282 minecraft:orange_terracotta
fill 277 151 299 277 182 299 minecraft:sandstone
fill 235 152 281 235 154 281 minecraft:sandstone
fill 235 152 282 235 152 283 minecraft:glowstone
fill 235 152 284 235 165 284 minecraft:sandstone
fill 235 152 293 235 165 293 minecraft:sandstone
fill 235 152 294 235 152 295 minecraft:glowstone
fill 235 152 296 235 165 296 minecraft:sandstone
fill 235 152 305 235 165 305 minecraft:sandstone
fill 235 152 306 235 152 307 minecraft:glowstone
fill 235 152 308 235 153 308 minecraft:sandstone
fill 235 152 317 235 165 317 minecraft:sandstone
fill 236 152 317 237 152 317 minecraft:glowstone
fill 238 152 317 238 160 317 minecraft:sandstone
fill 242 152 275 242 165 275 minecraft:sandstone
fill 243 152 275 244 152 275 minecraft:glowstone
fill 245 152 275 245 165 275 minecraft:sandstone
fill 247 152 317 247 165 317 minecraft:sandstone
setblock 248 152 275 minecraft:lapis_block
fill 248 152 317 249 152 317 minecraft:glowstone
fill 250 152 317 250 165 317 minecraft:sandstone
fill 254 152 275 254 165 275 minecraft:sandstone
fill 255 152 275 256 152 275 minecraft:glowstone
fill 257 152 275 257 164 275 minecraft:sandstone
fill 259 152 317 259 165 317 minecraft:sandstone
fill 260 152 317 261 152 317 minecraft:glowstone
fill 262 152 317 262 165 317 minecraft:sandstone
fill 266 152 275 266 165 275 minecraft:sandstone
fill 267 152 275 268 152 275 minecraft:glowstone
fill 269 152 275 269 165 275 minecraft:sandstone
fill 271 152 317 271 165 317 minecraft:sandstone
fill 272 152 317 273 152 317 minecraft:glowstone
fill 274 152 317 274 165 317 minecraft:sandstone
fill 277 152 276 277 165 276 minecraft:sandstone
fill 277 152 277 277 152 278 minecraft:glowstone
fill 277 152 279 277 165 279 minecraft:sandstone
fill 277 152 282 277 187 282 minecraft:sandstone
fill 277 152 288 277 165 288 minecraft:sandstone
fill 277 152 289 277 152 290 minecraft:glowstone
fill 277 152 291 277 165 291 minecraft:sandstone
fill 277 152 300 277 165 300 minecraft:sandstone
fill 277 152 301 277 152 302 minecraft:glowstone
fill 277 152 303 277 165 303 minecraft:sandstone
setblock 277 152 311 minecraft:orange_terracotta
fill 277 152 312 277 165 312 minecraft:sandstone
fill 277 152 313 277 152 314 minecraft:glowstone
fill 277 152 315 277 165 315 minecraft:sandstone
fill 235 153 282 235 165 283 minecraft:sandstone
fill 235 153 294 235 165 295 minecraft:sandstone
setblock 235 153 301 minecraft:orange_terracotta
fill 235 153 306 235 165 307 minecraft:sandstone
fill 236 153 317 237 165 317 minecraft:sandstone
setblock 238 153 278 minecraft:light[level=12]
setblock 238 153 285 minecraft:light[level=12]
setblock 238 153 292 minecraft:light[level=12]
setblock 238 153 299 minecraft:light[level=12]
setblock 238 153 306 minecraft:light[level=12]
setblock 238 153 313 minecraft:light[level=12]
fill 243 153 275 244 165 275 minecraft:sandstone
setblock 245 153 278 minecraft:light[level=12]
setblock 245 153 285 minecraft:light[level=12]
setblock 245 153 292 minecraft:light[level=12]
setblock 245 153 299 minecraft:light[level=12]
setblock 245 153 306 minecraft:light[level=12]
setblock 245 153 313 minecraft:light[level=12]
fill 248 153 275 248 154 275 minecraft:sandstone
fill 248 153 317 249 163 317 minecraft:sandstone
setblock 252 153 278 minecraft:light[level=12]
setblock 252 153 285 minecraft:light[level=12]
setblock 252 153 292 minecraft:light[level=12]
setblock 252 153 299 minecraft:light[level=12]
setblock 252 153 306 minecraft:light[level=12]
setblock 252 153 313 minecraft:light[level=12]
fill 255 153 275 256 165 275 minecraft:sandstone
setblock 259 153 278 minecraft:light[level=12]
setblock 259 153 285 minecraft:light[level=12]
setblock 259 153 292 minecraft:light[level=12]
setblock 259 153 299 minecraft:light[level=12]
setblock 259 153 306 minecraft:light[level=12]
setblock 259 153 313 minecraft:light[level=12]
fill 260 153 317 261 156 317 minecraft:sandstone
setblock 266 153 278 minecraft:light[level=12]
setblock 266 153 285 minecraft:light[level=12]
setblock 266 153 292 minecraft:light[level=12]
setblock 266 153 299 minecraft:light[level=12]
setblock 266 153 306 minecraft:light[level=12]
setblock 266 153 313 minecraft:light[level=12]
fill 267 153 275 268 165 275 minecraft:sandstone
fill 272 153 317 273 165 317 minecraft:sandstone
setblock 273 153 278 minecraft:light[level=12]
setblock 273 153 285 minecraft:light[level=12]
setblock 273 153 292 minecraft:light[level=12]
setblock 273 153 299 minecraft:light[level=12]
setblock 273 153 306 minecraft:light[level=12]
setblock 273 153 313 minecraft:light[level=12]
fill 277 153 277 277 163 278 minecraft:sandstone
setblock 277 153 289 minecraft:black_terracotta
fill 277 153 290 277 159 290 minecraft:sandstone
fill 277 153 301 277 165 302 minecraft:sandstone
fill 277 153 311 277 202 311 minecraft:sandstone
fill 277 153 313 277 153 314 minecraft:sandstone
fill 235 154 301 235 166 301 minecraft:sandstone
setblock 235 154 308 minecraft:lapis_block
fill 277 154 289 277 165 289 minecraft:sandstone
fill 277 154 313 277 165 313 minecraft:sandstone
setblock 277 154 314 minecraft:lapis_block
setblock 235 155 281 minecraft:black_terracotta
setblock 235 155 285 minecraft:lapis_block
fill 235 155 308 235 165 308 minecraft:sandstone
setblock 237 155 275 minecraft:orange_terracotta
setblock 241 155 317 minecraft:lapis_block
fill 242 155 317 242 185 317 minecraft:sandstone
setblock 248 155 275 minecraft:black_terracotta
fill 263 155 275 263 203 275 minecraft:sandstone
setblock 264 155 275 minecraft:lapis_block
setblock 277 155 294 minecraft:lapis_block
fill 277 155 314 277 165 314 minecraft:sandstone
fill 235 156 281 235 165 281 minecraft:sandstone
fill 235 156 285 235 166 285 minecraft:sandstone
setblock 235 156 309 minecraft:black_terracotta
fill 237 156 275 237 200 275 minecraft:sandstone
fill 241 156 317 241 169 317 minecraft:sandstone
fill 248 156 275 248 198 275 minecraft:sandstone
fill 251 156 317 252 156 317 minecraft:lapis_block
fill 264 156 275 264 183 275 minecraft:sandstone
fill 277 156 294 277 190 294 minecraft:sandstone
setblock 235 157 286 minecraft:blue_terracotta
fill 235 157 309 235 166 309 minecraft:sandstone
fill 251 157 317 252 163 317 minecraft:sandstone
fill 260 157 317 260 165 317 minecraft:sandstone
setblock 261 157 317 minecraft:black_terracotta
fill 235 158 286 235 200 286 minecraft:sandstone
setblock 235 158 298 minecraft:lapis_block
setblock 238 158 275 minecraft:orange_terracotta
fill 261 158 317 261 165 317 minecraft:sandstone
fill 235 159 298 235 199 298 minecraft:sandstone
fill 238 159 275 238 202 275 minecraft:sandstone
setblock 238 159 278 minecraft:light[level=15]
setblock 238 159 285 minecraft:light[level=12]
setblock 238 159 286 minecraft:light[level=15]
setblock 238 159 292 minecraft:light[level=12]
setblock 238 159 294 minecraft:light[level=15]
setblock 238 159 299 minecraft:light[level=12]
setblock 238 159 302 minecraft:light[level=15]
setblock 238 159 306 minecraft:light[level=12]
setblock 238 159 310 minecraft:light[level=15]
setblock 238 159 313 minecraft:light[level=12]
setblock 245 159 278 minecraft:light[level=12]
setblock 245 159 285 minecraft:light[level=12]
setblock 245 159 292 minecraft:light[level=12]
setblock 245 159 299 minecraft:light[level=12]
setblock 245 159 306 minecraft:light[level=12]
setblock 245 159 313 minecraft:light[level=12]
setblock 246 159 278 minecraft:light[level=15]
setblock 246 159 286 minecraft:light[level=15]
setblock 246 159 294 minecraft:light[level=15]
setblock 246 159 302 minecraft:light[level=15]
setblock 246 159 310 minecraft:light[level=15]
setblock 252 159 278 minecraft:light[level=12]
setblock 252 159 285 minecraft:light[level=12]
setblock 252 159 292 minecraft:light[level=12]
setblock 252 159 299 minecraft:light[level=12]
setblock 252 159 306 minecraft:light[level=12]
setblock 252 159 313 minecraft:light[level=12]
setblock 254 159 278 minecraft:light[level=15]
setblock 254 159 286 minecraft:light[level=15]
setblock 254 159 294 minecraft:light[level=15]
setblock 254 159 302 minecraft:light[level=15]
setblock 254 159 310 minecraft:light[level=15]
setblock 259 159 278 minecraft:light[level=12]
setblock 259 159 285 minecraft:light[level=12]
setblock 259 159 292 minecraft:light[level=12]
setblock 259 159 299 minecraft:light[level=12]
setblock 259 159 306 minecraft:light[level=12]
setblock 259 159 313 minecraft:light[level=12]
setblock 262 159 278 minecraft:light[level=15]
setblock 262 159 286 minecraft:light[level=15]
setblock 262 159 294 minecraft:light[level=15]
setblock 262 159 302 minecraft:light[level=15]
setblock 262 159 310 minecraft:light[level=15]
setblock 266 159 278 minecraft:light[level=12]
setblock 266 159 285 minecraft:light[level=12]
setblock 266 159 292 minecraft:light[level=12]
setblock 266 159 299 minecraft:light[level=12]
setblock 266 159 306 minecraft:light[level=12]
setblock 266 159 313 minecraft:light[level=12]
setblock 270 159 278 minecraft:light[level=15]
setblock 270 159 286 minecraft:light[level=15]
setblock 270 159 294 minecraft:light[level=15]
setblock 270 159 302 minecraft:light[level=15]
setblock 270 159 310 minecraft:light[level=15]
setblock 273 159 278 minecraft:light[level=12]
setblock 273 159 285 minecraft:light[level=12]
setblock 273 159 292 minecraft:light[level=12]
setblock 273 159 299 minecraft:light[level=12]
setblock 273 159 306 minecraft:light[level=12]
setblock 273 159 313 minecraft:light[level=12]
fill 237 160 285 237 165 287 minecraft:cut_sandstone
fill 237 160 297 237 165 299 minecraft:cut_sandstone
fill 237 160 309 237 165 311 minecraft:cut_sandstone
fill 238 160 295 238 162 295 minecraft:shroomlight
fill 243 160 315 245 165 315 minecraft:cut_sandstone
fill 247 160 277 249 165 277 minecraft:cut_sandstone
fill 255 160 315 257 165 315 minecraft:cut_sandstone
setblock 258 160 317 minecraft:blue_terracotta
fill 259 160 277 261 165 277 minecraft:cut_sandstone
fill 267 160 315 269 165 315 minecraft:cut_sandstone
fill 271 160 277 273 165 277 minecraft:cut_sandstone
fill 275 160 285 275 165 287 minecraft:cut_sandstone
fill 275 160 297 275 165 299 minecraft:cut_sandstone
fill 275 160 309 275 165 311 minecraft:cut_sandstone
setblock 277 160 290 minecraft:orange_terracotta
setblock 238 161 317 minecraft:blue_terracotta
fill 258 161 317 258 202 317 minecraft:sandstone
fill 277 161 290 277 165 290 minecraft:sandstone
setblock 235 162 278 minecraft:lapis_block
fill 235 162 279 235 173 279 minecraft:sandstone
setblock 235 162 303 minecraft:lapis_block
fill 238 162 317 238 165 317 minecraft:sandstone
fill 274 162 287 274 174 287 minecraft:blue_wool
fill 235 163 278 235 202 278 minecraft:sandstone
fill 235 163 303 235 172 303 minecraft:sandstone
fill 274 163 285 274 174 286 minecraft:blue_wool
fill 274 163 288 274 174 289 minecraft:blue_wool
setblock 248 164 317 minecraft:blue_terracotta
setblock 249 164 317 minecraft:orange_terracotta
fill 251 164 317 251 202 317 minecraft:sandstone
setblock 252 164 317 minecraft:blue_terracotta
setblock 277 164 277 minecraft:black_terracotta
fill 277 164 278 277 165 278 minecraft:sandstone
fill 236 165 279 236 165 284 minecraft:chiseled_sandstone
fill 236 165 291 236 165 296 minecraft:chiseled_sandstone
fill 236 165 303 236 165 308 minecraft:chiseled_sandstone
fill 236 165 315 236 165 316 minecraft:chiseled_sandstone
fill 237 165 316 240 165 316 minecraft:chiseled_sandstone
setblock 238 165 278 minecraft:light[level=12]
setblock 238 165 285 minecraft:light[level=12]
setblock 238 165 292 minecraft:light[level=12]
setblock 238 165 299 minecraft:light[level=12]
setblock 238 165 306 minecraft:light[level=12]
setblock 238 165 313 minecraft:light[level=12]
fill 240 165 276 245 165 276 minecraft:chiseled_sandstone
setblock 245 165 278 minecraft:light[level=12]
setblock 245 165 285 minecraft:light[level=12]
setblock 245 165 292 minecraft:light[level=12]
setblock 245 165 299 minecraft:light[level=12]
setblock 245 165 306 minecraft:light[level=12]
setblock 245 165 313 minecraft:light[level=12]
fill 247 165 316 252 165 316 minecraft:chiseled_sandstone
fill 248 165 317 249 165 317 minecraft:sandstone
fill 252 165 276 257 165 276 minecraft:chiseled_sandstone
setblock 252 165 278 minecraft:light[level=12]
setblock 252 165 285 minecraft:light[level=12]
setblock 252 165 292 minecraft:light[level=12]
setblock 252 165 299 minecraft:light[level=12]
setblock 252 165 306 minecraft:light[level=12]
setblock 252 165 313 minecraft:light[level=12]
fill 252 165 317 252 203 317 minecraft:sandstone
setblock 257 165 275 minecraft:orange_terracotta
setblock 258 165 275 minecraft:lapis_block
setblock 259 165 278 minecraft:light[level=12]
setblock 259 165 285 minecraft:light[level=12]
setblock 259 165 292 minecraft:light[level=12]
setblock 259 165 299 minecraft:light[level=12]
setblock 259 165 306 minecraft:light[level=12]
setblock 259 165 313 minecraft:light[level=12]
fill 259 165 316 264 165 316 minecraft:chiseled_sandstone
fill 264 165 276 269 165 276 minecraft:chiseled_sandstone
setblock 266 165 278 minecraft:light[level=12]
setblock 266 165 285 minecraft:light[level=12]
setblock 266 165 292 minecraft:light[level=12]
setblock 266 165 299 minecraft:light[level=12]
setblock 266 165 306 minecraft:light[level=12]
setblock 266 165 313 minecraft:light[level=12]
fill 271 165 316 276 165 316 minecraft:chiseled_sandstone
setblock 273 165 278 minecraft:light[level=12]
setblock 273 165 285 minecraft:light[level=12]
setblock 273 165 292 minecraft:light[level=12]
setblock 273 165 299 minecraft:light[level=12]
setblock 273 165 306 minecraft:light[level=12]
setblock 273 165 313 minecraft:light[level=12]
fill 276 165 276 276 165 281 minecraft:chiseled_sandstone
fill 276 165 288 276 165 293 minecraft:chiseled_sandstone
fill 276 165 300 276 165 305 minecraft:chiseled_sandstone
fill 276 165 312 276 165 315 minecraft:chiseled_sandstone
setblock 277 165 277 minecraft:sandstone
fill 235 166 281 235 171 284 minecraft:glowstone
fill 235 166 293 235 171 296 minecraft:glowstone
setblock 235 166 297 minecraft:blue_terracotta
fill 235 166 305 235 171 308 minecraft:glowstone
fill 235 166 317 238 171 317 minecraft:glowstone
setblock 240 166 275 minecraft:blue_terracotta
fill 242 166 275 245 171 275 minecraft:glowstone
fill 247 166 317 250 171 317 minecraft:glowstone
fill 254 166 275 257 171 275 minecraft:glowstone
fill 258 166 275 258 188 275 minecraft:sandstone
fill 259 166 317 262 171 317 minecraft:glowstone
fill 266 166 275 269 171 275 minecraft:glowstone
fill 271 166 317 274 171 317 minecraft:glowstone
fill 277 166 276 277 171 279 minecraft:glowstone
fill 277 166 288 277 171 291 minecraft:glowstone
fill 277 166 300 277 171 303 minecraft:glowstone
fill 277 166 312 277 171 315 minecraft:glowstone
setblock 235 167 285 minecraft:lapis_block
fill 235 167 297 235 202 297 minecraft:sandstone
setblock 235 167 301 minecraft:black_terracotta
setblock 235 167 309 minecraft:orange_terracotta
setblock 238 167 278 minecraft:light[level=15]
setblock 238 167 286 minecraft:light[level=15]
setblock 238 167 294 minecraft:light[level=15]
setblock 238 167 302 minecraft:light[level=15]
setblock 238 167 310 minecraft:light[level=15]
fill 240 167 275 240 184 275 minecraft:sandstone
setblock 246 167 278 minecraft:light[level=15]
setblock 246 167 286 minecraft:light[level=15]
setblock 246 167 294 minecraft:light[level=15]
setblock 246 167 302 minecraft:light[level=15]
setblock 246 167 310 minecraft:light[level=15]
setblock 254 167 278 minecraft:light[level=15]
setblock 254 167 286 minecraft:light[level=15]
setblock 254 167 294 minecraft:light[level=15]
setblock 254 167 302 minecraft:light[level=15]
setblock 254 167 310 minecraft:light[level=15]
setblock 262 167 278 minecraft:light[level=15]
setblock 262 167 286 minecraft:light[level=15]
setblock 262 167 294 minecraft:light[level=15]
setblock 262 167 302 minecraft:light[level=15]
fill 262 167 310 263 168 310 minecraft:smooth_sandstone
setblock 270 167 278 minecraft:light[level=15]
setblock 270 167 286 minecraft:light[level=15]
setblock 270 167 294 minecraft:light[level=15]
setblock 270 167 302 minecraft:light[level=15]
setblock 270 167 310 minecraft:light[level=15]
fill 235 168 285 235 170 285 minecraft:sandstone
fill 235 168 301 235 202 301 minecraft:sandstone
fill 235 168 309 235 174 309 minecraft:sandstone
setblock 277 168 295 minecraft:blue_terracotta
fill 240 169 287 240 170 287 minecraft:smooth_sandstone
fill 277 169 295 277 189 295 minecraft:sandstone
setblock 241 170 317 minecraft:black_terracotta
setblock 257 170 317 minecraft:blue_terracotta
setblock 235 171 285 minecraft:black_terracotta
setblock 238 171 278 minecraft:light[level=12]
setblock 238 171 285 minecraft:light[level=12]
setblock 238 171 292 minecraft:light[level=12]
setblock 238 171 299 minecraft:light[level=12]
setblock 238 171 306 minecraft:light[level=12]
setblock 238 171 313 minecraft:light[level=12]
fill 241 171 317 241 202 317 minecraft:sandstone
setblock 244 171 317 minecraft:blue_terracotta
setblock 245 171 278 minecraft:light[level=12]
setblock 245 171 285 minecraft:light[level=12]
setblock 245 171 292 minecraft:light[level=12]
setblock 245 171 299 minecraft:light[level=12]
setblock 245 171 306 minecraft:light[level=12]
setblock 245 171 313 minecraft:light[level=12]
setblock 252 171 278 minecraft:light[level=12]
setblock 252 171 285 minecraft:light[level=12]
setblock 252 171 292 minecraft:light[level=12]
setblock 252 171 299 minecraft:light[level=12]
setblock 252 171 306 minecraft:light[level=12]
setblock 252 171 313 minecraft:light[level=12]
fill 257 171 317 257 199 317 minecraft:sandstone
setblock 259 171 278 minecraft:light[level=12]
setblock 259 171 285 minecraft:light[level=12]
setblock 259 171 292 minecraft:light[level=12]
setblock 259 171 299 minecraft:light[level=12]
setblock 259 171 306 minecraft:light[level=12]
setblock 259 171 313 minecraft:light[level=12]
setblock 266 171 278 minecraft:light[level=12]
setblock 266 171 285 minecraft:light[level=12]
setblock 266 171 292 minecraft:light[level=12]
setblock 266 171 299 minecraft:light[level=12]
setblock 266 171 306 minecraft:light[level=12]
setblock 266 171 313 minecraft:light[level=12]
setblock 273 171 278 minecraft:light[level=12]
setblock 273 171 285 minecraft:light[level=12]
setblock 273 171 292 minecraft:light[level=12]
setblock 273 171 299 minecraft:light[level=12]
setblock 273 171 306 minecraft:light[level=12]
setblock 273 171 313 minecraft:light[level=12]
setblock 235 172 281 minecraft:sandstone
fill 235 172 282 235 172 283 minecraft:glowstone
fill 235 172 284 235 185 285 minecraft:sandstone
fill 235 172 293 235 185 293 minecraft:sandstone
fill 235 172 294 235 172 295 minecraft:glowstone
fill 235 172 296 235 185 296 minecraft:sandstone
fill 235 172 305 235 185 305 minecraft:sandstone
fill 235 172 306 235 172 307 minecraft:glowstone
fill 235 172 308 235 185 308 minecraft:sandstone
fill 235 172 317 235 185 317 minecraft:sandstone
fill 236 172 317 237 172 317 minecraft:glowstone
fill 238 172 317 238 185 317 minecraft:sandstone
fill 242 172 275 242 176 275 minecraft:sandstone
fill 243 172 275 244 172 275 minecraft:glowstone
fill 244 172 317 244 198 317 minecraft:sandstone
fill 245 172 275 245 185 275 minecraft:sandstone
setblock 247 172 275 minecraft:black_terracotta
fill 247 172 317 247 185 317 minecraft:sandstone
fill 248 172 317 249 172 317 minecraft:glowstone
fill 250 172 317 250 185 317 minecraft:sandstone
setblock 253 172 317 minecraft:black_terracotta
setblock 254 172 275 minecraft:sandstone
fill 255 172 275 256 172 275 minecraft:glowstone
fill 257 172 275 257 185 275 minecraft:sandstone
fill 259 172 317 259 185 317 minecraft:sandstone
fill 260 172 317 261 172 317 minecraft:glowstone
fill 262 172 317 262 185 317 minecraft:sandstone
fill 266 172 275 266 185 275 minecraft:sandstone
fill 267 172 275 268 172 275 minecraft:glowstone
fill 269 172 275 269 185 275 minecraft:sandstone
fill 271 172 317 271 182 317 minecraft:sandstone
fill 272 172 317 273 172 317 minecraft:glowstone
fill 274 172 317 274 185 317 minecraft:sandstone
setblock 276 172 317 minecraft:blue_terracotta
fill 277 172 276 277 185 276 minecraft:sandstone
fill 277 172 277 277 172 278 minecraft:glowstone
fill 277 172 279 277 177 279 minecraft:sandstone
fill 277 172 288 277 185 288 minecraft:sandstone
fill 277 172 289 277 172 290 minecraft:glowstone
fill 277 172 291 277 173 291 minecraft:sandstone
fill 277 172 300 277 185 300 minecraft:sandstone
fill 277 172 301 277 172 302 minecraft:glowstone
fill 277 172 303 277 175 303 minecraft:sandstone
fill 277 172 312 277 185 312 minecraft:sandstone
fill 277 172 313 277 172 314 minecraft:glowstone
fill 277 172 315 277 185 315 minecraft:sandstone
setblock 235 173 281 minecraft:blue_terracotta
fill 235 173 282 235 185 283 minecraft:sandstone
fill 235 173 294 235 174 295 minecraft:sandstone
setblock 235 173 303 minecraft:blue_terracotta
fill 235 173 306 235 176 307 minecraft:sandstone
fill 236 173 317 237 185 317 minecraft:sandstone
fill 243 173 275 244 185 275 minecraft:sandstone
fill 247 173 275 247 198 275 minecraft:sandstone
fill 248 173 317 249 185 317 minecraft:sandstone
fill 253 173 317 253 198 317 minecraft:sandstone
setblock 254 173 275 minecraft:orange_terracotta
fill 255 173 275 256 185 275 minecraft:sandstone
fill 260 173 317 261 185 317 minecraft:sandstone
fill 267 173 275 268 185 275 minecraft:sandstone
fill 272 173 317 273 185 317 minecraft:sandstone
fill 276 173 317 276 194 317 minecraft:sandstone
fill 277 173 277 277 176 278 minecraft:sandstone
fill 277 173 289 277 185 290 minecraft:sandstone
fill 277 173 301 277 184 302 minecraft:sandstone
fill 277 173 313 277 173 314 minecraft:sandstone
setblock 235 174 279 minecraft:lapis_block
fill 235 174 281 235 185 281 minecraft:sandstone
fill 235 174 303 235 202 303 minecraft:sandstone
setblock 254 174 275 minecraft:sandstone
setblock 255 174 317 minecraft:lapis_block
fill 256 174 317 256 199 317 minecraft:sandstone
fill 266 174 280 266 175 282 minecraft:smooth_sandstone
fill 267 174 281 267 175 282 minecraft:smooth_sandstone
setblock 277 174 291 minecraft:black_terracotta
setblock 277 174 313 minecraft:black_terracotta
fill 277 174 314 277 185 314 minecraft:sandstone
fill 235 175 279 235 202 279 minecraft:sandstone
fill 235 175 294 235 185 294 minecraft:sandstone
setblock 235 175 295 minecraft:lapis_block
setblock 235 175 309 minecraft:orange_terracotta
setblock 238 175 278 minecraft:light[level=15]
setblock 238 175 286 minecraft:light[level=15]
setblock 238 175 294 minecraft:light[level=15]
setblock 238 175 302 minecraft:light[level=15]
setblock 238 175 310 minecraft:light[level=15]
setblock 246 175 275 minecraft:orange_terracotta
setblock 246 175 278 minecraft:light[level=15]
setblock 246 175 286 minecraft:light[level=15]
setblock 246 175 294 minecraft:light[level=15]
setblock 246 175 302 minecraft:light[level=15]
setblock 246 175 310 minecraft:light[level=15]
setblock 254 175 275 minecraft:blue_terracotta
setblock 254 175 278 minecraft:light[level=15]
setblock 254 175 286 minecraft:light[level=15]
setblock 254 175 294 minecraft:light[level=15]
setblock 254 175 302 minecraft:light[level=15]
setblock 254 175 310 minecraft:light[level=15]
fill 255 175 317 255 202 317 minecraft:sandstone
setblock 262 175 278 minecraft:light[level=15]
setblock 262 175 286 minecraft:light[level=15]
setblock 262 175 294 minecraft:light[level=15]
setblock 262 175 302 minecraft:light[level=15]
setblock 262 175 310 minecraft:light[level=15]
setblock 270 175 278 minecraft:light[level=15]
setblock 270 175 286 minecraft:light[level=15]
setblock 270 175 294 minecraft:light[level=15]
setblock 270 175 302 minecraft:light[level=15]
setblock 270 175 310 minecraft:light[level=15]
fill 274 175 284 274 176 290 minecraft:iron_block
fill 277 175 291 277 185 291 minecraft:sandstone
fill 277 175 313 277 185 313 minecraft:sandstone
fill 235 176 295 235 185 295 minecraft:sandstone
fill 235 176 309 235 179 309 minecraft:sandstone
setblock 243 176 317 minecraft:lapis_block
fill 246 176 275 246 178 275 minecraft:sandstone
fill 254 176 275 254 185 275 minecraft:sandstone
setblock 277 176 303 minecraft:orange_terracotta
fill 235 177 306 235 185 306 minecraft:sandstone
fill 235 177 307 235 178 307 minecraft:black_terracotta
setblock 238 177 278 minecraft:light[level=12]
setblock 238 177 285 minecraft:light[level=12]
setblock 238 177 292 minecraft:light[level=12]
setblock 238 177 299 minecraft:light[level=12]
setblock 238 177 306 minecraft:light[level=12]
setblock 238 177 313 minecraft:light[level=12]
setblock 242 177 275 minecraft:black_terracotta
fill 243 177 317 243 202 317 minecraft:sandstone
setblock 245 177 278 minecraft:light[level=12]
setblock 245 177 285 minecraft:light[level=12]
setblock 245 177 292 minecraft:light[level=12]
setblock 245 177 299 minecraft:light[level=12]
setblock 245 177 306 minecraft:light[level=12]
setblock 245 177 313 minecraft:light[level=12]
setblock 252 177 278 minecraft:light[level=12]
setblock 252 177 285 minecraft:light[level=12]
setblock 252 177 292 minecraft:light[level=12]
setblock 252 177 299 minecraft:light[level=12]
setblock 252 177 306 minecraft:light[level=12]
setblock 252 177 313 minecraft:light[level=12]
setblock 259 177 278 minecraft:light[level=12]
setblock 259 177 285 minecraft:light[level=12]
setblock 259 177 292 minecraft:light[level=12]
setblock 259 177 299 minecraft:light[level=12]
setblock 259 177 306 minecraft:light[level=12]
setblock 259 177 313 minecraft:light[level=12]
setblock 266 177 278 minecraft:light[level=12]
setblock 266 177 285 minecraft:light[level=12]
setblock 266 177 292 minecraft:light[level=12]
setblock 266 177 299 minecraft:light[level=12]
setblock 266 177 306 minecraft:light[level=12]
setblock 266 177 313 minecraft:light[level=12]
setblock 273 177 278 minecraft:light[level=12]
setblock 273 177 285 minecraft:light[level=12]
setblock 273 177 292 minecraft:light[level=12]
setblock 273 177 299 minecraft:light[level=12]
setblock 273 177 306 minecraft:light[level=12]
setblock 273 177 313 minecraft:light[level=12]
setblock 277 177 277 minecraft:lapis_block
fill 277 177 278 277 185 278 minecraft:sandstone
fill 277 177 303 277 185 303 minecraft:sandstone
fill 242 178 275 242 185 275 minecraft:sandstone
fill 277 178 277 277 185 277 minecraft:sandstone
setblock 277 178 279 minecraft:black_terracotta
setblock 235 179 280 minecraft:orange_terracotta
fill 235 179 307 235 185 307 minecraft:sandstone
setblock 246 179 275 minecraft:blue_terracotta
fill 277 179 279 277 185 279 minecraft:sandstone
fill 235 180 280 235 200 280 minecraft:sandstone
setblock 235 180 309 minecraft:lapis_block
fill 237 180 285 237 185 287 minecraft:cut_sandstone
fill 237 180 297 237 185 299 minecraft:cut_sandstone
fill 237 180 309 237 185 311 minecraft:cut_sandstone
fill 243 180 315 245 185 315 minecraft:cut_sandstone
fill 246 180 275 246 202 275 minecraft:sandstone
fill 247 180 277 249 185 277 minecraft:cut_sandstone
fill 255 180 315 257 185 315 minecraft:cut_sandstone
fill 259 180 277 261 185 277 minecraft:cut_sandstone
fill 267 180 315 269 185 315 minecraft:cut_sandstone
fill 271 180 277 273 185 277 minecraft:cut_sandstone
fill 275 180 285 275 185 287 minecraft:cut_sandstone
fill 275 180 297 275 185 299 minecraft:cut_sandstone
fill 275 180 309 275 185 311 minecraft:cut_sandstone
fill 235 181 309 235 199 309 minecraft:sandstone
setblock 235 181 310 minecraft:lapis_block
setblock 235 182 291 minecraft:black_terracotta
fill 235 182 310 235 203 310 minecraft:sandstone
setblock 235 183 291 minecraft:sandstone
setblock 238 183 278 minecraft:light[level=15]
setblock 238 183 285 minecraft:light[level=12]
setblock 238 183 286 minecraft:light[level=15]
setblock 238 183 292 minecraft:light[level=12]
setblock 238 183 294 minecraft:light[level=15]
setblock 238 183 299 minecraft:light[level=12]
setblock 238 183 302 minecraft:light[level=15]
setblock 238 183 306 minecraft:light[level=12]
setblock 238 183 310 minecraft:light[level=15]
setblock 238 183 313 minecraft:light[level=12]
setblock 245 183 278 minecraft:light[level=12]
setblock 245 183 285 minecraft:light[level=12]
setblock 245 183 292 minecraft:light[level=12]
setblock 245 183 299 minecraft:light[level=12]
setblock 245 183 306 minecraft:light[level=12]
setblock 245 183 313 minecraft:light[level=12]
setblock 246 183 278 minecraft:light[level=15]
setblock 246 183 286 minecraft:light[level=15]
setblock 246 183 294 minecraft:light[level=15]
setblock 246 183 302 minecraft:light[level=15]
setblock 246 183 310 minecraft:light[level=15]
setblock 252 183 278 minecraft:light[level=12]
setblock 252 183 285 minecraft:light[level=12]
setblock 252 183 292 minecraft:light[level=12]
setblock 252 183 299 minecraft:light[level=12]
setblock 252 183 306 minecraft:light[level=12]
setblock 252 183 313 minecraft:light[level=12]
setblock 254 183 278 minecraft:light[level=15]
setblock 254 183 286 minecraft:light[level=15]
setblock 254 183 294 minecraft:light[level=15]
setblock 254 183 302 minecraft:light[level=15]
setblock 254 183 310 minecraft:light[level=15]
setblock 259 183 278 minecraft:light[level=12]
setblock 259 183 285 minecraft:light[level=12]
setblock 259 183 292 minecraft:light[level=12]
setblock 259 183 299 minecraft:light[level=12]
setblock 259 183 306 minecraft:light[level=12]
setblock 259 183 313 minecraft:light[level=12]
setblock 262 183 278 minecraft:light[level=15]
setblock 262 183 286 minecraft:light[level=15]
setblock 262 183 294 minecraft:light[level=15]
setblock 262 183 302 minecraft:light[level=15]
setblock 262 183 310 minecraft:light[level=15]
setblock 266 183 278 minecraft:light[level=12]
setblock 266 183 285 minecraft:light[level=12]
setblock 266 183 292 minecraft:light[level=12]
setblock 266 183 299 minecraft:light[level=12]
setblock 266 183 306 minecraft:light[level=12]
setblock 266 183 313 minecraft:light[level=12]
setblock 270 183 278 minecraft:light[level=15]
setblock 270 183 286 minecraft:light[level=15]
setblock 270 183 294 minecraft:light[level=15]
setblock 270 183 302 minecraft:light[level=15]
setblock 270 183 310 minecraft:light[level=15]
setblock 271 183 317 minecraft:lapis_block
setblock 273 183 278 minecraft:light[level=12]
setblock 273 183 285 minecraft:light[level=12]
setblock 273 183 292 minecraft:light[level=12]
setblock 273 183 299 minecraft:light[level=12]
setblock 273 183 306 minecraft:light[level=12]
setblock 273 183 313 minecraft:light[level=12]
setblock 277 183 299 minecraft:black_terracotta
setblock 277 183 304 minecraft:orange_terracotta
setblock 277 183 316 minecraft:lapis_block
fill 235 184 291 235 184 292 minecraft:blue_terracotta
setblock 264 184 275 minecraft:black_terracotta
fill 271 184 317 271 185 317 minecraft:sandstone
fill 277 184 299 277 202 299 minecraft:sandstone
fill 277 184 304 277 198 304 minecraft:sandstone
fill 277 184 316 277 202 316 minecraft:sandstone
fill 235 185 291 235 200 292 minecraft:sandstone
fill 236 185 279 236 185 284 minecraft:chiseled_sandstone
fill 236 185 291 236 185 296 minecraft:chiseled_sandstone
fill 236 185 303 236 185 308 minecraft:chiseled_sandstone
fill 236 185 315 236 185 316 minecraft:chiseled_sandstone
fill 237 185 316 240 185 316 minecraft:chiseled_sandstone
setblock 240 185 275 minecraft:black_terracotta
fill 240 185 276 245 185 276 minecraft:chiseled_sandstone
fill 247 185 316 252 185 316 minecraft:chiseled_sandstone
fill 252 185 276 257 185 276 minecraft:chiseled_sandstone
fill 259 185 316 264 185 316 minecraft:chiseled_sandstone
fill 264 185 275 264 202 275 minecraft:sandstone
fill 264 185 276 269 185 276 minecraft:chiseled_sandstone
fill 271 185 316 276 185 316 minecraft:chiseled_sandstone
fill 276 185 276 276 185 281 minecraft:chiseled_sandstone
fill 276 185 288 276 185 293 minecraft:chiseled_sandstone
fill 276 185 300 276 185 305 minecraft:chiseled_sandstone
fill 276 185 312 276 185 315 minecraft:chiseled_sandstone
setblock 277 185 301 minecraft:blue_terracotta
setblock 277 185 302 minecraft:sandstone
fill 235 186 281 235 186 284 minecraft:glowstone
fill 235 186 285 235 202 285 minecraft:sandstone
fill 235 186 293 235 186 296 minecraft:glowstone
fill 235 186 305 235 186 308 minecraft:glowstone
fill 235 186 317 238 186 317 minecraft:glowstone
fill 240 186 275 240 202 275 minecraft:sandstone
fill 242 186 275 245 186 275 minecraft:glowstone
setblock 242 186 317 minecraft:black_terracotta
fill 247 186 317 250 186 317 minecraft:glowstone
fill 254 186 275 257 186 275 minecraft:glowstone
fill 259 186 317 262 186 317 minecraft:glowstone
fill 266 186 275 269 186 275 minecraft:glowstone
fill 271 186 317 274 186 317 minecraft:glowstone
fill 277 186 276 277 186 279 minecraft:glowstone
fill 277 186 288 277 186 291 minecraft:glowstone
fill 277 186 300 277 186 303 minecraft:glowstone
setblock 277 186 307 minecraft:blue_terracotta
fill 277 186 312 277 186 315 minecraft:glowstone
fill 235 187 281 235 194 284 minecraft:sandstone
fill 235 187 293 235 187 296 minecraft:sandstone
fill 235 187 305 235 193 308 minecraft:sandstone
fill 235 187 317 238 199 317 minecraft:sandstone
fill 242 187 275 245 197 275 minecraft:sandstone
fill 242 187 317 242 198 317 minecraft:sandstone
fill 247 187 317 250 200 317 minecraft:sandstone
setblock 249 187 275 minecraft:lapis_block
fill 254 187 275 257 193 275 minecraft:sandstone
fill 259 187 317 262 200 317 minecraft:sandstone
fill 266 187 275 267 202 275 minecraft:sandstone
setblock 268 187 275 minecraft:orange_terracotta
fill 269 187 275 269 202 275 minecraft:sandstone
fill 271 187 317 274 187 317 minecraft:sandstone
fill 277 187 276 277 190 279 minecraft:sandstone
fill 277 187 288 277 190 291 minecraft:sandstone
fill 277 187 300 277 198 303 minecraft:sandstone
fill 277 187 307 277 202 307 minecraft:sandstone
fill 277 187 312 277 198 315 minecraft:sandstone
fill 235 188 293 235 202 293 minecraft:sandstone
setblock 235 188 294 minecraft:lapis_block
fill 235 188 295 235 193 296 minecraft:sandstone
fill 249 188 275 249 202 275 minecraft:sandstone
fill 268 188 275 268 198 275 minecraft:sandstone
fill 271 188 317 272 197 317 minecraft:sandstone
setblock 273 188 317 minecraft:lapis_block
fill 274 188 317 274 202 317 minecraft:sandstone
setblock 277 188 282 minecraft:black_terracotta
fill 235 189 294 235 200 294 minecraft:sandstone
setblock 238 189 278 minecraft:light[level=12]
setblock 238 189 285 minecraft:light[level=12]
setblock 238 189 292 minecraft:light[level=12]
setblock 238 189 299 minecraft:light[level=12]
setblock 238 189 306 minecraft:light[level=12]
setblock 238 189 313 minecraft:light[level=12]
setblock 239 189 317 minecraft:blue_terracotta
setblock 245 189 278 minecraft:light[level=12]
setblock 245 189 285 minecraft:light[level=12]
setblock 245 189 292 minecraft:light[level=12]
setblock 245 189 299 minecraft:light[level=12]
setblock 245 189 306 minecraft:light[level=12]
setblock 245 189 313 minecraft:light[level=12]
setblock 252 189 278 minecraft:light[level=12]
setblock 252 189 285 minecraft:light[level=12]
setblock 252 189 292 minecraft:light[level=12]
setblock 252 189 299 minecraft:light[level=12]
setblock 252 189 306 minecraft:light[level=12]
setblock 252 189 313 minecraft:light[level=12]
setblock 258 189 275 minecraft:black_terracotta
setblock 259 189 278 minecraft:light[level=12]
setblock 259 189 285 minecraft:light[level=12]
setblock 259 189 292 minecraft:light[level=12]
setblock 259 189 299 minecraft:light[level=12]
setblock 259 189 306 minecraft:light[level=12]
setblock 259 189 313 minecraft:light[level=12]
setblock 266 189 278 minecraft:light[level=12]
setblock 266 189 285 minecraft:light[level=12]
setblock 266 189 292 minecraft:light[level=12]
setblock 266 189 299 minecraft:light[level=12]
setblock 266 189 306 minecraft:light[level=12]
setblock 266 189 313 minecraft:light[level=12]
setblock 273 189 278 minecraft:light[level=12]
setblock 273 189 285 minecraft:light[level=12]
setblock 273 189 292 minecraft:light[level=12]
setblock 273 189 299 minecraft:light[level=12]
setblock 273 189 306 minecraft:light[level=12]
setblock 273 189 313 minecraft:light[level=12]
fill 273 189 317 273 202 317 minecraft:sandstone
fill 277 189 282 277 200 282 minecraft:sandstone
fill 239 190 317 239 198 317 minecraft:sandstone
fill 258 190 275 258 202 275 minecraft:sandstone
fill 265 190 317 267 202 317 minecraft:sandstone
setblock 268 190 317 minecraft:orange_terracotta
fill 269 190 317 269 202 317 minecraft:sandstone
setblock 277 190 295 minecraft:orange_terracotta
setblock 277 190 298 minecraft:orange_terracotta
setblock 235 191 304 minecraft:orange_terracotta
setblock 238 191 278 minecraft:light[level=15]
setblock 238 191 286 minecraft:light[level=15]
setblock 238 191 294 minecraft:light[level=15]
setblock 238 191 302 minecraft:light[level=15]
setblock 238 191 310 minecraft:light[level=15]
setblock 246 191 278 minecraft:light[level=15]
setblock 246 191 286 minecraft:light[level=15]
setblock 246 191 294 minecraft:light[level=15]
setblock 246 191 302 minecraft:light[level=15]
setblock 246 191 310 minecraft:light[level=15]
setblock 254 191 278 minecraft:light[level=15]
setblock 254 191 286 minecraft:light[level=15]
setblock 254 191 294 minecraft:light[level=15]
setblock 254 191 302 minecraft:light[level=15]
setblock 254 191 310 minecraft:light[level=15]
setblock 262 191 278 minecraft:light[level=15]
setblock 262 191 286 minecraft:light[level=15]
setblock 262 191 294 minecraft:light[level=15]
setblock 262 191 302 minecraft:light[level=15]
setblock 262 191 310 minecraft:light[level=15]
fill 268 191 317 268 202 317 minecraft:sandstone
setblock 270 191 278 minecraft:light[level=15]
setblock 270 191 286 minecraft:light[level=15]
setblock 270 191 294 minecraft:light[level=15]
setblock 270 191 302 minecraft:light[level=15]
setblock 270 191 310 minecraft:light[level=15]
fill 277 191 276 277 202 276 minecraft:sandstone
setblock 277 191 277 minecraft:blue_terracotta
fill 277 191 278 277 199 279 minecraft:sandstone
fill 277 191 288 277 198 289 minecraft:sandstone
setblock 277 191 290 minecraft:lapis_block
fill 277 191 291 277 197 291 minecraft:sandstone
setblock 277 191 294 minecraft:black_terracotta
fill 277 191 295 277 202 295 minecraft:sandstone
fill 277 191 298 277 200 298 minecraft:sandstone
setblock 277 191 306 minecraft:blue_terracotta
fill 235 192 304 235 202 304 minecraft:sandstone
fill 236 192 276 255 192 316 minecraft:gold_block
fill 256 192 276 256 192 295 minecraft:gold_block
fill 256 192 297 256 192 316 minecraft:gold_block
fill 257 192 276 258 192 293 minecraft:gold_block
fill 257 192 299 258 192 316 minecraft:gold_block
fill 259 192 276 276 192 292 minecraft:gold_block
fill 259 192 300 276 192 316 minecraft:gold_block
fill 260 192 293 276 192 293 minecraft:gold_block
fill 260 192 299 276 192 299 minecraft:gold_block
fill 262 192 294 276 192 295 minecraft:gold_block
fill 262 192 297 276 192 298 minecraft:gold_block
fill 263 192 296 276 192 296 minecraft:gold_block
fill 277 192 277 277 196 277 minecraft:sandstone
fill 277 192 290 277 202 290 minecraft:sandstone
fill 277 192 294 277 202 294 minecraft:sandstone
fill 277 192 306 277 202 306 minecraft:sandstone
fill 236 193 276 276 193 277 minecraft:gold_block
fill 236 193 278 276 193 278 minecraft:lapis_block
fill 236 193 279 276 193 280 minecraft:gold_block
fill 236 193 281 276 193 281 minecraft:lapis_block
fill 236 193 282 276 193 283 minecraft:gold_block
fill 236 193 284 276 193 284 minecraft:lapis_block
fill 236 193 285 276 193 286 minecraft:gold_block
fill 236 193 287 276 193 287 minecraft:lapis_block
fill 236 193 288 276 193 289 minecraft:gold_block
fill 236 193 290 276 193 290 minecraft:lapis_block
fill 236 193 291 255 193 292 minecraft:gold_block
fill 236 193 293 254 193 293 minecraft:lapis_block
fill 236 193 294 253 193 295 minecraft:gold_block
fill 236 193 296 253 193 296 minecraft:lapis_block
fill 236 193 297 253 193 298 minecraft:gold_block
fill 236 193 299 254 193 299 minecraft:lapis_block
fill 236 193 300 255 193 301 minecraft:gold_block
fill 236 193 302 276 193 302 minecraft:lapis_block
fill 236 193 303 276 193 304 minecraft:gold_block
fill 236 193 305 276 193 305 minecraft:lapis_block
fill 236 193 306 276 193 307 minecraft:gold_block
fill 236 193 308 276 193 308 minecraft:lapis_block
fill 236 193 309 276 193 310 minecraft:gold_block
fill 236 193 311 276 193 311 minecraft:lapis_block
fill 236 193 312 276 193 313 minecraft:gold_block
fill 236 193 314 276 193 314 minecraft:lapis_block
fill 236 193 315 276 193 316 minecraft:gold_block
fill 254 193 294 255 193 298 minecraft:black_concrete
fill 255 193 293 256 193 293 minecraft:black_concrete
fill 255 193 299 256 193 299 minecraft:black_concrete
setblock 256 193 291 minecraft:gold_block
fill 256 193 292 262 193 292 minecraft:black_concrete
fill 256 193 294 256 193 295 minecraft:sea_lantern
fill 256 193 297 256 193 298 minecraft:sea_lantern
fill 256 193 300 262 193 300 minecraft:black_concrete
setblock 256 193 301 minecraft:gold_block
fill 257 193 291 261 193 291 minecraft:black_concrete
fill 257 193 293 258 193 293 minecraft:sea_lantern
fill 257 193 299 258 193 299 minecraft:sea_lantern
fill 257 193 301 261 193 301 minecraft:black_concrete
fill 260 193 293 261 193 293 minecraft:sea_lantern
fill 260 193 299 261 193 299 minecraft:sea_lantern
fill 262 193 291 276 193 291 minecraft:gold_block
fill 262 193 293 263 193 293 minecraft:black_concrete
fill 262 193 294 262 193 295 minecraft:sea_lantern
fill 262 193 297 262 193 298 minecraft:sea_lantern
fill 262 193 299 263 193 299 minecraft:black_concrete
fill 262 193 301 276 193 301 minecraft:gold_block
fill 263 193 292 276 193 292 minecraft:gold_block
fill 263 193 294 264 193 298 minecraft:black_concrete
fill 263 193 300 276 193 300 minecraft:gold_block
fill 264 193 293 276 193 293 minecraft:lapis_block
fill 264 193 299 276 193 299 minecraft:lapis_block
fill 265 193 294 276 193 295 minecraft:gold_block
fill 265 193 296 276 193 296 minecraft:lapis_block
fill 265 193 297 276 193 298 minecraft:gold_block
setblock 235 194 295 minecraft:lapis_block
fill 235 194 296 235 202 296 minecraft:sandstone
fill 235 194 305 235 200 306 minecraft:sandstone
setblock 235 194 307 minecraft:lapis_block
fill 235 194 308 235 202 308 minecraft:sandstone
fill 247 194 284 255 195 308 minecraft:prismarine_bricks
fill 254 194 275 256 197 275 minecraft:sandstone
fill 256 194 284 256 194 294 minecraft:prismarine_bricks
fill 256 194 298 256 194 308 minecraft:prismarine_bricks
setblock 257 194 275 minecraft:lapis_block
fill 257 194 284 257 194 293 minecraft:prismarine_bricks
fill 257 194 299 257 194 308 minecraft:prismarine_bricks
fill 258 194 284 271 195 292 minecraft:prismarine_bricks
fill 258 194 300 271 195 308 minecraft:prismarine_bricks
fill 261 194 293 271 194 293 minecraft:prismarine_bricks
fill 261 194 299 271 194 299 minecraft:prismarine_bricks
fill 262 194 294 271 194 294 minecraft:prismarine_bricks
fill 262 194 298 271 194 298 minecraft:prismarine_bricks
fill 263 194 295 271 195 297 minecraft:prismarine_bricks
setblock 277 194 297 minecraft:black_terracotta
fill 235 195 281 235 202 281 minecraft:sandstone
setblock 235 195 282 minecraft:lapis_block
fill 235 195 283 235 202 284 minecraft:sandstone
fill 235 195 295 235 199 295 minecraft:sandstone
fill 235 195 307 235 202 307 minecraft:sandstone
setblock 238 195 278 minecraft:light[level=12]
setblock 238 195 285 minecraft:light[level=12]
setblock 238 195 292 minecraft:light[level=12]
setblock 238 195 299 minecraft:light[level=12]
setblock 238 195 306 minecraft:light[level=12]
setblock 238 195 313 minecraft:light[level=12]
setblock 245 195 278 minecraft:light[level=12]
setblock 245 195 285 minecraft:light[level=12]
setblock 245 195 292 minecraft:light[level=12]
setblock 245 195 299 minecraft:light[level=12]
setblock 245 195 306 minecraft:light[level=12]
setblock 245 195 313 minecraft:light[level=12]
setblock 252 195 278 minecraft:light[level=12]
setblock 252 195 313 minecraft:light[level=12]
fill 256 195 284 256 195 293 minecraft:prismarine_bricks
fill 256 195 299 256 195 308 minecraft:prismarine_bricks
fill 257 195 275 257 202 275 minecraft:sandstone
fill 257 195 284 257 195 292 minecraft:prismarine_bricks
fill 257 195 300 257 195 308 minecraft:prismarine_bricks
setblock 259 195 275 minecraft:orange_terracotta
setblock 259 195 278 minecraft:light[level=12]
setblock 259 195 313 minecraft:light[level=12]
fill 262 195 293 271 195 293 minecraft:prismarine_bricks
fill 262 195 299 271 195 299 minecraft:prismarine_bricks
fill 263 195 294 271 195 294 minecraft:prismarine_bricks
fill 263 195 298 271 195 298 minecraft:prismarine_bricks
setblock 263 195 317 minecraft:orange_terracotta
setblock 266 195 278 minecraft:light[level=12]
setblock 266 195 313 minecraft:light[level=12]
setblock 273 195 278 minecraft:light[level=12]
setblock 273 195 285 minecraft:light[level=12]
setblock 273 195 292 minecraft:light[level=12]
setblock 273 195 299 minecraft:light[level=12]
setblock 273 195 306 minecraft:light[level=12]
setblock 273 195 313 minecraft:light[level=12]
setblock 276 195 317 minecraft:blue_terracotta
fill 277 195 297 277 199 297 minecraft:sandstone
fill 235 196 282 235 202 282 minecraft:sandstone
fill 248 196 285 248 197 285 minecraft:sea_lantern
fill 248 196 307 248 197 307 minecraft:sea_lantern
fill 249 196 286 255 197 306 minecraft:dark_prismarine
fill 256 196 286 256 197 293 minecraft:dark_prismarine
fill 256 196 299 256 197 306 minecraft:dark_prismarine
fill 257 196 286 269 197 292 minecraft:dark_prismarine
fill 257 196 300 269 197 306 minecraft:dark_prismarine
fill 259 196 275 259 199 275 minecraft:sandstone
fill 262 196 293 269 197 293 minecraft:dark_prismarine
fill 262 196 299 269 197 299 minecraft:dark_prismarine
fill 263 196 294 269 197 298 minecraft:dark_prismarine
fill 263 196 317 263 198 317 minecraft:sandstone
fill 270 196 285 270 197 285 minecraft:sea_lantern
fill 270 196 307 270 197 307 minecraft:sea_lantern
fill 275 196 275 275 198 275 minecraft:sandstone
setblock 276 196 275 minecraft:lapis_block
fill 276 196 317 276 199 317 minecraft:sandstone
fill 277 196 275 277 202 275 minecraft:sandstone
fill 236 197 276 238 270 276 minecraft:cut_sandstone
fill 236 197 286 236 270 288 minecraft:cut_sandstone
fill 236 197 298 236 270 300 minecraft:cut_sandstone
fill 236 197 310 236 270 312 minecraft:cut_sandstone
fill 242 197 316 244 270 316 minecraft:cut_sandstone
fill 243 197 276 249 204 282 minecraft:cut_sandstone
fill 246 197 312 256 204 316 minecraft:cut_sandstone
fill 250 197 276 250 270 276 minecraft:cut_sandstone
fill 260 197 276 262 270 276 minecraft:cut_sandstone
fill 266 197 316 268 270 316 minecraft:cut_sandstone
fill 267 197 277 269 198 285 minecraft:cut_sandstone
fill 270 197 277 276 198 284 minecraft:cut_sandstone
fill 270 197 286 276 198 287 minecraft:cut_sandstone
fill 271 197 285 276 198 285 minecraft:cut_sandstone
fill 272 197 276 274 270 276 minecraft:cut_sandstone
fill 276 197 275 276 202 275 minecraft:sandstone
fill 276 197 296 276 270 298 minecraft:cut_sandstone
fill 276 197 308 276 243 310 minecraft:cut_sandstone
setblock 277 197 277 minecraft:lapis_block
fill 242 198 275 244 202 275 minecraft:sandstone
setblock 245 198 275 minecraft:lapis_block
fill 251 198 288 254 199 304 minecraft:prismarine_bricks
setblock 254 198 275 minecraft:black_terracotta
fill 255 198 275 256 199 275 minecraft:sandstone
fill 255 198 288 255 199 294 minecraft:prismarine_bricks
fill 255 198 298 255 199 304 minecraft:prismarine_bricks
fill 256 198 288 256 198 293 minecraft:prismarine_bricks
fill 256 198 299 256 198 304 minecraft:prismarine_bricks
fill 257 198 288 257 199 292 minecraft:prismarine_bricks
fill 257 198 300 257 199 304 minecraft:prismarine_bricks
fill 258 198 288 267 199 291 minecraft:prismarine_bricks
fill 258 198 301 267 199 304 minecraft:prismarine_bricks
fill 261 198 292 267 199 292 minecraft:prismarine_bricks
fill 261 198 300 267 199 300 minecraft:prismarine_bricks
fill 262 198 293 267 198 293 minecraft:prismarine_bricks
fill 262 198 299 267 198 299 minecraft:prismarine_bricks
fill 263 198 294 267 199 294 minecraft:prismarine_bricks
fill 263 198 298 267 199 298 minecraft:prismarine_bricks
fill 264 198 295 267 199 297 minecraft:prismarine_bricks
fill 267 198 286 269 198 287 minecraft:cut_sandstone
fill 270 198 285 270 214 285 minecraft:cut_sandstone
setblock 271 198 317 minecraft:black_terracotta
setblock 272 198 317 minecraft:sandstone
fill 273 198 297 273 199 298 minecraft:sandstone
fill 277 198 277 277 202 277 minecraft:sandstone
setblock 277 198 291 minecraft:lapis_block
fill 235 199 275 236 199 275 minecraft:smooth_sandstone
setblock 235 199 290 minecraft:lapis_block
setblock 238 199 278 minecraft:light[level=15]
setblock 238 199 286 minecraft:light[level=15]
setblock 238 199 294 minecraft:light[level=15]
setblock 238 199 302 minecraft:light[level=15]
setblock 238 199 310 minecraft:light[level=15]
setblock 239 199 317 minecraft:smooth_sandstone
setblock 242 199 317 minecraft:smooth_sandstone
setblock 244 199 317 minecraft:smooth_sandstone
fill 245 199 275 245 201 275 minecraft:sandstone
setblock 246 199 286 minecraft:light[level=15]
setblock 246 199 294 minecraft:light[level=15]
setblock 246 199 302 minecraft:light[level=15]
setblock 246 199 310 minecraft:light[level=15]
setblock 247 199 275 minecraft:smooth_sandstone
setblock 248 199 275 minecraft:lapis_block
setblock 253 199 317 minecraft:smooth_sandstone
setblock 254 199 275 minecraft:smooth_sandstone
setblock 254 199 278 minecraft:light[level=15]
setblock 254 199 286 minecraft:light[level=15]
setblock 254 199 310 minecraft:light[level=15]
fill 256 199 288 256 199 292 minecraft:prismarine_bricks
fill 256 199 300 256 199 304 minecraft:prismarine_bricks
setblock 262 199 278 minecraft:light[level=15]
setblock 262 199 286 minecraft:light[level=15]
setblock 262 199 310 minecraft:light[level=15]
fill 263 199 293 267 199 293 minecraft:prismarine_bricks
fill 263 199 299 267 199 299 minecraft:prismarine_bricks
setblock 263 199 317 minecraft:smooth_sandstone
setblock 267 199 277 minecraft:glowstone
fill 267 199 278 267 214 278 minecraft:cut_sandstone
setblock 267 199 279 minecraft:glowstone
fill 267 199 280 267 214 280 minecraft:cut_sandstone
setblock 267 199 281 minecraft:glowstone
fill 267 199 282 267 214 282 minecraft:cut_sandstone
setblock 267 199 283 minecraft:glowstone
fill 267 199 284 267 214 284 minecraft:cut_sandstone
setblock 267 199 285 minecraft:glowstone
fill 267 199 286 267 214 286 minecraft:cut_sandstone
setblock 267 199 287 minecraft:glowstone
setblock 268 199 275 minecraft:smooth_sandstone
fill 268 199 277 268 214 277 minecraft:cut_sandstone
setblock 268 199 278 minecraft:glowstone
fill 268 199 279 268 214 279 minecraft:cut_sandstone
setblock 268 199 280 minecraft:glowstone
fill 268 199 281 268 214 281 minecraft:cut_sandstone
setblock 268 199 282 minecraft:glowstone
fill 268 199 283 268 214 283 minecraft:cut_sandstone
setblock 268 199 284 minecraft:glowstone
fill 268 199 285 268 214 285 minecraft:cut_sandstone
setblock 268 199 286 minecraft:glowstone
fill 268 199 287 268 214 287 minecraft:cut_sandstone
setblock 269 199 277 minecraft:glowstone
fill 269 199 278 269 214 278 minecraft:cut_sandstone
setblock 269 199 279 minecraft:glowstone
fill 269 199 280 269 214 280 minecraft:cut_sandstone
setblock 269 199 281 minecraft:glowstone
fill 269 199 282 269 214 282 minecraft:cut_sandstone
setblock 269 199 283 minecraft:glowstone
fill 269 199 284 269 214 284 minecraft:cut_sandstone
setblock 269 199 285 minecraft:glowstone
fill 269 199 286 269 214 286 minecraft:cut_sandstone
setblock 269 199 287 minecraft:glowstone
fill 270 199 277 270 214 277 minecraft:cut_sandstone
setblock 270 199 278 minecraft:glowstone
fill 270 199 279 270 214 279 minecraft:cut_sandstone
setblock 270 199 280 minecraft:glowstone
fill 270 199 281 270 214 281 minecraft:cut_sandstone
setblock 270 199 282 minecraft:glowstone
fill 270 199 283 270 214 283 minecraft:cut_sandstone
setblock 270 199 284 minecraft:glowstone
setblock 270 199 286 minecraft:glowstone
fill 270 199 287 270 214 287 minecraft:cut_sandstone
setblock 270 199 294 minecraft:light[level=15]
setblock 270 199 302 minecraft:light[level=15]
setblock 270 199 310 minecraft:light[level=15]
setblock 270 199 317 minecraft:smooth_sandstone
setblock 271 199 277 minecraft:glowstone
fill 271 199 278 271 214 278 minecraft:cut_sandstone
setblock 271 199 279 minecraft:glowstone
fill 271 199 280 271 214 280 minecraft:cut_sandstone
setblock 271 199 281 minecraft:glowstone
fill 271 199 282 271 214 282 minecraft:cut_sandstone
setblock 271 199 283 minecraft:glowstone
fill 271 199 284 271 214 284 minecraft:cut_sandstone
setblock 271 199 285 minecraft:glowstone
fill 271 199 286 271 214 286 minecraft:cut_sandstone
setblock 271 199 287 minecraft:glowstone
fill 271 199 317 271 202 317 minecraft:sandstone
fill 272 199 277 272 214 277 minecraft:cut_sandstone
setblock 272 199 278 minecraft:glowstone
fill 272 199 279 272 214 279 minecraft:cut_sandstone
setblock 272 199 280 minecraft:glowstone
fill 272 199 281 272 214 281 minecraft:cut_sandstone
setblock 272 199 282 minecraft:glowstone
fill 272 199 283 272 214 283 minecraft:cut_sandstone
setblock 272 199 284 minecraft:glowstone
fill 272 199 285 272 214 285 minecraft:cut_sandstone
setblock 272 199 286 minecraft:glowstone
fill 272 199 287 272 214 287 minecraft:cut_sandstone
setblock 272 199 317 minecraft:smooth_sandstone
setblock 273 199 277 minecraft:glowstone
fill 273 199 278 273 214 278 minecraft:cut_sandstone
setblock 273 199 279 minecraft:glowstone
fill 273 199 280 273 214 280 minecraft:cut_sandstone
setblock 273 199 281 minecraft:glowstone
fill 273 199 282 273 214 282 minecraft:cut_sandstone
setblock 273 199 283 minecraft:glowstone
fill 273 199 284 273 214 284 minecraft:cut_sandstone
setblock 273 199 285 minecraft:glowstone
fill 273 199 286 273 214 286 minecraft:cut_sandstone
setblock 273 199 287 minecraft:glowstone
fill 274 199 277 274 214 277 minecraft:cut_sandstone
setblock 274 199 278 minecraft:glowstone
fill 274 199 279 274 214 279 minecraft:cut_sandstone
setblock 274 199 280 minecraft:glowstone
fill 274 199 281 274 214 281 minecraft:cut_sandstone
setblock 274 199 282 minecraft:glowstone
fill 274 199 283 274 214 283 minecraft:cut_sandstone
setblock 274 199 284 minecraft:glowstone
fill 274 199 285 274 214 285 minecraft:cut_sandstone
setblock 274 199 286 minecraft:glowstone
fill 274 199 287 274 214 287 minecraft:cut_sandstone
setblock 275 199 275 minecraft:smooth_sandstone
setblock 275 199 277 minecraft:glowstone
fill 275 199 278 275 214 278 minecraft:cut_sandstone
setblock 275 199 279 minecraft:glowstone
fill 275 199 280 275 214 280 minecraft:cut_sandstone
setblock 275 199 281 minecraft:glowstone
fill 275 199 282 275 214 282 minecraft:cut_sandstone
setblock 275 199 283 minecraft:glowstone
fill 275 199 284 275 200 284 minecraft:cut_sandstone
setblock 275 199 285 minecraft:glowstone
fill 275 199 286 275 214 286 minecraft:cut_sandstone
setblock 275 199 287 minecraft:glowstone
fill 276 199 277 276 204 277 minecraft:cut_sandstone
setblock 276 199 278 minecraft:glowstone
fill 276 199 279 276 204 279 minecraft:cut_sandstone
setblock 276 199 280 minecraft:glowstone
fill 276 199 281 276 204 281 minecraft:cut_sandstone
setblock 276 199 282 minecraft:glowstone
fill 276 199 283 276 214 283 minecraft:cut_sandstone
setblock 276 199 284 minecraft:glowstone
fill 276 199 285 276 270 285 minecraft:cut_sandstone
setblock 276 199 286 minecraft:glowstone
fill 276 199 287 276 214 287 minecraft:cut_sandstone
setblock 277 199 281 minecraft:smooth_sandstone
fill 277 199 288 277 202 288 minecraft:sandstone
setblock 277 199 289 minecraft:smooth_sandstone
fill 277 199 291 277 202 291 minecraft:sandstone
setblock 277 199 296 minecraft:smooth_sandstone
setblock 277 199 300 minecraft:smooth_sandstone
fill 277 199 301 277 200 303 minecraft:sandstone
setblock 277 199 304 minecraft:black_terracotta
setblock 277 199 312 minecraft:smooth_sandstone
fill 277 199 313 277 200 315 minecraft:sandstone
fill 235 200 275 236 200 275 minecraft:sandstone
setblock 235 200 290 minecraft:sandstone
setblock 235 200 295 minecraft:smooth_sandstone
fill 235 200 298 235 200 299 minecraft:smooth_sandstone
setblock 235 200 309 minecraft:smooth_sandstone
fill 235 200 317 235 201 317 minecraft:smooth_sandstone
fill 236 200 317 239 200 317 minecraft:sandstone
fill 237 200 285 237 205 287 minecraft:cut_sandstone
fill 237 200 297 237 205 299 minecraft:cut_sandstone
fill 237 200 309 237 205 311 minecraft:cut_sandstone
fill 242 200 317 242 202 317 minecraft:sandstone
fill 243 200 315 245 205 315 minecraft:cut_sandstone
setblock 244 200 317 minecraft:sandstone
fill 247 200 275 248 200 275 minecraft:sandstone
fill 253 200 290 254 201 302 minecraft:dark_prismarine
fill 253 200 317 253 202 317 minecraft:sandstone
fill 254 200 275 255 202 275 minecraft:sandstone
fill 255 200 290 255 200 294 minecraft:dark_prismarine
fill 255 200 298 255 200 302 minecraft:dark_prismarine
setblock 256 200 275 minecraft:smooth_sandstone
fill 256 200 290 257 200 292 minecraft:dark_prismarine
fill 256 200 300 257 200 302 minecraft:dark_prismarine
fill 256 200 317 257 200 317 minecraft:smooth_sandstone
fill 257 200 315 257 205 315 minecraft:cut_sandstone
fill 258 200 290 265 201 291 minecraft:dark_prismarine
fill 258 200 301 265 201 302 minecraft:dark_prismarine
setblock 259 200 275 minecraft:smooth_sandstone
fill 259 200 277 261 205 277 minecraft:cut_sandstone
fill 261 200 292 265 200 292 minecraft:dark_prismarine
fill 261 200 300 265 200 300 minecraft:dark_prismarine
fill 263 200 293 265 200 294 minecraft:dark_prismarine
fill 263 200 298 265 200 299 minecraft:dark_prismarine
fill 263 200 317 263 202 317 minecraft:sandstone
fill 264 200 295 265 201 297 minecraft:dark_prismarine
setblock 265 200 275 minecraft:smooth_sandstone
fill 267 200 277 267 201 277 minecraft:cut_sandstone
fill 267 200 279 267 201 279 minecraft:cut_sandstone
fill 267 200 281 267 201 281 minecraft:cut_sandstone
fill 267 200 283 267 201 283 minecraft:cut_sandstone
fill 267 200 285 267 201 285 minecraft:cut_sandstone
fill 267 200 287 267 201 287 minecraft:cut_sandstone
fill 267 200 315 269 205 315 minecraft:cut_sandstone
fill 268 200 275 268 202 275 minecraft:sandstone
fill 268 200 278 268 201 278 minecraft:cut_sandstone
fill 268 200 280 268 201 280 minecraft:cut_sandstone
fill 268 200 282 268 201 282 minecraft:cut_sandstone
fill 268 200 284 268 201 284 minecraft:cut_sandstone
fill 268 200 286 268 201 286 minecraft:cut_sandstone
fill 269 200 277 269 201 277 minecraft:cut_sandstone
fill 269 200 279 269 201 279 minecraft:cut_sandstone
fill 269 200 281 269 201 281 minecraft:cut_sandstone
fill 269 200 283 269 201 283 minecraft:cut_sandstone
fill 269 200 285 269 201 285 minecraft:cut_sandstone
fill 269 200 287 269 201 287 minecraft:cut_sandstone
fill 270 200 278 270 201 278 minecraft:cut_sandstone
fill 270 200 280 270 201 280 minecraft:cut_sandstone
fill 270 200 282 270 201 282 minecraft:cut_sandstone
fill 270 200 284 270 201 284 minecraft:cut_sandstone
fill 270 200 286 270 201 286 minecraft:cut_sandstone
fill 270 200 317 270 202 317 minecraft:sandstone
fill 271 200 277 271 201 277 minecraft:cut_sandstone
fill 271 200 279 271 201 279 minecraft:cut_sandstone
fill 271 200 281 271 201 281 minecraft:cut_sandstone
fill 271 200 283 271 201 283 minecraft:cut_sandstone
fill 271 200 285 271 201 285 minecraft:cut_sandstone
fill 271 200 287 271 201 287 minecraft:cut_sandstone
fill 272 200 278 272 201 278 minecraft:cut_sandstone
fill 272 200 280 272 201 280 minecraft:cut_sandstone
fill 272 200 282 272 201 282 minecraft:cut_sandstone
fill 272 200 284 272 201 284 minecraft:cut_sandstone
fill 272 200 286 272 201 286 minecraft:cut_sandstone
fill 272 200 317 272 202 317 minecraft:sandstone
fill 273 200 277 273 201 277 minecraft:cut_sandstone
fill 273 200 279 273 201 279 minecraft:cut_sandstone
fill 273 200 281 273 201 281 minecraft:cut_sandstone
fill 273 200 283 273 201 283 minecraft:cut_sandstone
fill 273 200 285 273 201 285 minecraft:cut_sandstone
fill 273 200 287 273 201 287 minecraft:cut_sandstone
fill 274 200 278 274 201 278 minecraft:cut_sandstone
fill 274 200 280 274 201 280 minecraft:cut_sandstone
fill 274 200 282 274 201 282 minecraft:cut_sandstone
fill 274 200 284 274 201 284 minecraft:cut_sandstone
fill 274 200 286 274 201 286 minecraft:cut_sandstone
setblock 275 200 275 minecraft:sandstone
fill 275 200 277 275 201 277 minecraft:cut_sandstone
fill 275 200 279 275 201 279 minecraft:cut_sandstone
fill 275 200 281 275 201 281 minecraft:cut_sandstone
fill 275 200 283 275 201 283 minecraft:cut_sandstone
fill 275 200 285 275 201 285 minecraft:cut_sandstone
fill 275 200 287 275 201 287 minecraft:cut_sandstone
fill 275 200 297 275 205 299 minecraft:cut_sandstone
fill 275 200 309 275 205 311 minecraft:cut_sandstone
fill 276 200 278 276 201 278 minecraft:cut_sandstone
fill 276 200 280 276 201 280 minecraft:cut_sandstone
fill 276 200 282 276 201 282 minecraft:cut_sandstone
fill 276 200 284 276 201 284 minecraft:cut_sandstone
fill 276 200 286 276 201 286 minecraft:cut_sandstone
fill 276 200 317 276 201 317 minecraft:smooth_sandstone
setblock 277 200 278 minecraft:smooth_sandstone
fill 277 200 279 277 202 279 minecraft:sandstone
fill 277 200 281 277 202 281 minecraft:sandstone
fill 277 200 289 277 202 289 minecraft:sandstone
fill 277 200 296 277 202 296 minecraft:sandstone
setblock 277 200 297 minecraft:smooth_sandstone
fill 277 200 300 277 202 300 minecraft:sandstone
fill 277 200 304 277 204 304 minecraft:sandstone
fill 277 200 312 277 203 312 minecraft:sandstone
fill 235 201 275 235 203 275 minecraft:sandstone
setblock 235 201 280 minecraft:smooth_sandstone
setblock 235 201 286 minecraft:smooth_sandstone
fill 235 201 290 235 201 291 minecraft:smooth_sandstone
fill 235 201 292 235 202 292 minecraft:sandstone
setblock 235 201 294 minecraft:black_terracotta
fill 235 201 295 235 202 295 minecraft:sandstone
fill 235 201 298 235 202 299 minecraft:sandstone
fill 235 201 305 235 202 305 minecraft:sandstone
setblock 235 201 306 minecraft:smooth_sandstone
fill 235 201 309 235 205 309 minecraft:sandstone
setblock 235 201 312 minecraft:smooth_sandstone
setblock 235 201 313 minecraft:orange_terracotta
fill 236 201 275 237 201 275 minecraft:smooth_sandstone
fill 236 201 317 237 202 317 minecraft:sandstone
setblock 238 201 278 minecraft:light[level=12]
setblock 238 201 285 minecraft:light[level=12]
setblock 238 201 292 minecraft:light[level=12]
setblock 238 201 299 minecraft:light[level=12]
setblock 238 201 306 minecraft:light[level=12]
setblock 238 201 313 minecraft:light[level=12]
setblock 238 201 317 minecraft:lapis_block
fill 239 201 317 239 202 317 minecraft:sandstone
setblock 240 201 317 minecraft:smooth_sandstone
setblock 244 201 317 minecraft:smooth_sandstone
setblock 245 201 285 minecraft:light[level=12]
setblock 245 201 292 minecraft:light[level=12]
setblock 245 201 299 minecraft:light[level=12]
setblock 245 201 306 minecraft:light[level=12]
setblock 245 201 313 minecraft:light[level=12]
setblock 247 201 275 minecraft:smooth_sandstone
fill 247 201 317 248 201 317 minecraft:smooth_sandstone
fill 248 201 275 248 202 275 minecraft:sandstone
fill 249 201 317 250 202 317 minecraft:sandstone
setblock 252 201 278 minecraft:light[level=12]
setblock 252 201 285 minecraft:light[level=12]
setblock 252 201 292 minecraft:light[level=12]
setblock 252 201 299 minecraft:light[level=12]
setblock 252 201 306 minecraft:light[level=12]
setblock 254 201 317 minecraft:smooth_sandstone
fill 255 201 290 255 201 293 minecraft:dark_prismarine
fill 255 201 299 255 201 302 minecraft:dark_prismarine
fill 256 201 275 256 202 275 minecraft:sandstone
fill 256 201 290 256 201 292 minecraft:dark_prismarine
fill 256 201 300 256 201 302 minecraft:dark_prismarine
fill 256 201 317 256 202 317 minecraft:sandstone
fill 257 201 290 257 201 291 minecraft:dark_prismarine
fill 257 201 301 257 201 302 minecraft:dark_prismarine
setblock 257 201 317 minecraft:smooth_sandstone
fill 259 201 275 259 202 275 minecraft:sandstone
setblock 259 201 278 minecraft:light[level=12]
setblock 259 201 285 minecraft:light[level=12]
setblock 259 201 306 minecraft:light[level=12]
setblock 259 201 313 minecraft:light[level=12]
setblock 259 201 317 minecraft:smooth_sandstone
fill 260 201 317 261 202 317 minecraft:sandstone
fill 262 201 292 265 201 292 minecraft:dark_prismarine
fill 262 201 300 265 201 300 minecraft:dark_prismarine
setblock 262 201 317 minecraft:smooth_sandstone
fill 263 201 293 265 201 293 minecraft:dark_prismarine
fill 263 201 299 265 201 299 minecraft:dark_prismarine
fill 264 201 294 265 201 294 minecraft:dark_prismarine
fill 264 201 298 265 201 298 minecraft:dark_prismarine
fill 265 201 275 265 202 275 minecraft:sandstone
setblock 266 201 278 minecraft:light[level=12]
setblock 266 201 285 minecraft:light[level=12]
setblock 266 201 292 minecraft:light[level=12]
setblock 266 201 299 minecraft:light[level=12]
setblock 266 201 306 minecraft:light[level=12]
setblock 266 201 313 minecraft:light[level=12]
setblock 273 201 292 minecraft:light[level=12]
setblock 273 201 299 minecraft:light[level=12]
setblock 273 201 306 minecraft:light[level=12]
setblock 273 201 313 minecraft:light[level=12]
setblock 275 201 275 minecraft:smooth_sandstone
fill 275 201 284 275 203 284 minecraft:shroomlight
fill 277 201 278 277 202 278 minecraft:sandstone
setblock 277 201 282 minecraft:smooth_sandstone
fill 277 201 297 277 203 297 minecraft:sandstone
setblock 277 201 298 minecraft:smooth_sandstone
setblock 277 201 301 minecraft:smooth_sandstone
fill 277 201 302 277 202 303 minecraft:sandstone
setblock 277 201 313 minecraft:smooth_sandstone
fill 277 201 314 277 202 314 minecraft:sandstone
setblock 277 201 315 minecraft:smooth_sandstone
setblock 235 202 280 minecraft:sandstone
setblock 235 202 286 minecraft:sandstone
fill 235 202 290 235 202 291 minecraft:sandstone
setblock 235 202 294 minecraft:sandstone
setblock 235 202 306 minecraft:sandstone
fill 235 202 312 235 202 313 minecraft:sandstone
setblock 235 202 317 minecraft:sandstone
fill 236 202 275 237 202 275 minecraft:sandstone
setblock 238 202 317 minecraft:sandstone
setblock 240 202 317 minecraft:sandstone
setblock 244 202 317 minecraft:sandstone
setblock 245 202 275 minecraft:orange_terracotta
setblock 247 202 275 minecraft:sandstone
fill 247 202 317 248 202 317 minecraft:sandstone
fill 254 202 317 254 203 317 minecraft:sandstone
fill 255 202 292 255 203 293 minecraft:prismarine_bricks
fill 255 202 299 255 203 300 minecraft:prismarine_bricks
fill 256 202 292 256 203 292 minecraft:prismarine_bricks
fill 256 202 300 256 203 300 minecraft:prismarine_bricks
setblock 257 202 317 minecraft:sandstone
setblock 259 202 317 minecraft:sandstone
fill 262 202 292 263 203 292 minecraft:prismarine_bricks
fill 262 202 300 263 203 300 minecraft:prismarine_bricks
setblock 262 202 317 minecraft:sandstone
fill 263 202 293 263 203 293 minecraft:prismarine_bricks
fill 263 202 299 263 203 299 minecraft:prismarine_bricks
setblock 267 202 277 minecraft:glowstone
setblock 267 202 279 minecraft:glowstone
setblock 267 202 281 minecraft:glowstone
setblock 267 202 283 minecraft:glowstone
setblock 267 202 285 minecraft:glowstone
setblock 267 202 287 minecraft:glowstone
setblock 268 202 278 minecraft:glowstone
setblock 268 202 280 minecraft:glowstone
setblock 268 202 282 minecraft:glowstone
setblock 268 202 284 minecraft:glowstone
setblock 268 202 286 minecraft:glowstone
setblock 269 202 277 minecraft:glowstone
setblock 269 202 279 minecraft:glowstone
setblock 269 202 281 minecraft:glowstone
setblock 269 202 283 minecraft:glowstone
setblock 269 202 285 minecraft:glowstone
setblock 269 202 287 minecraft:glowstone
setblock 270 202 278 minecraft:glowstone
setblock 270 202 280 minecraft:glowstone
setblock 270 202 282 minecraft:glowstone
setblock 270 202 284 minecraft:glowstone
setblock 270 202 286 minecraft:glowstone
setblock 271 202 277 minecraft:glowstone
setblock 271 202 279 minecraft:glowstone
setblock 271 202 281 minecraft:glowstone
setblock 271 202 283 minecraft:glowstone
setblock 271 202 285 minecraft:glowstone
setblock 271 202 287 minecraft:glowstone
setblock 272 202 278 minecraft:glowstone
setblock 272 202 280 minecraft:glowstone
setblock 272 202 282 minecraft:glowstone
setblock 272 202 284 minecraft:glowstone
setblock 272 202 286 minecraft:glowstone
setblock 273 202 277 minecraft:glowstone
setblock 273 202 279 minecraft:glowstone
setblock 273 202 281 minecraft:glowstone
setblock 273 202 283 minecraft:glowstone
setblock 273 202 285 minecraft:glowstone
setblock 273 202 287 minecraft:glowstone
setblock 274 202 278 minecraft:glowstone
setblock 274 202 280 minecraft:glowstone
setblock 274 202 282 minecraft:glowstone
setblock 274 202 284 minecraft:glowstone
setblock 274 202 286 minecraft:glowstone
setblock 275 202 275 minecraft:sandstone
setblock 275 202 277 minecraft:glowstone
setblock 275 202 279 minecraft:glowstone
setblock 275 202 281 minecraft:glowstone
setblock 275 202 283 minecraft:glowstone
setblock 275 202 285 minecraft:glowstone
setblock 275 202 287 minecraft:glowstone
setblock 276 202 278 minecraft:glowstone
setblock 276 202 280 minecraft:glowstone
setblock 276 202 282 minecraft:glowstone
setblock 276 202 284 minecraft:glowstone
setblock 276 202 286 minecraft:glowstone
setblock 276 202 317 minecraft:sandstone
setblock 277 202 282 minecraft:sandstone
setblock 277 202 298 minecraft:sandstone
setblock 277 202 301 minecraft:sandstone
setblock 277 202 313 minecraft:sandstone
setblock 277 202 315 minecraft:sandstone
fill 235 203 277 235 203 288 minecraft:smooth_sandstone
fill 235 203 290 235 203 308 minecraft:smooth_sandstone
fill 235 203 312 235 204 315 minecraft:smooth_sandstone
setblock 235 203 316 minecraft:sandstone
fill 235 203 317 251 203 317 minecraft:smooth_sandstone
fill 236 203 275 236 219 275 minecraft:smooth_sandstone
setblock 237 203 275 minecraft:sandstone
fill 238 203 275 249 203 275 minecraft:smooth_sandstone
fill 251 203 275 251 274 275 minecraft:smooth_sandstone
setblock 252 203 275 minecraft:sandstone
fill 253 203 275 261 203 275 minecraft:smooth_sandstone
fill 253 203 317 253 308 317 minecraft:smooth_sandstone
fill 255 203 317 264 205 317 minecraft:smooth_sandstone
fill 264 203 275 277 203 275 minecraft:smooth_sandstone
setblock 265 203 317 minecraft:sandstone
fill 266 203 317 277 203 317 minecraft:smooth_sandstone
fill 267 203 277 267 204 277 minecraft:cut_sandstone
fill 267 203 279 267 204 279 minecraft:cut_sandstone
fill 267 203 281 267 204 281 minecraft:cut_sandstone
fill 267 203 283 267 204 283 minecraft:cut_sandstone
fill 267 203 285 267 204 285 minecraft:cut_sandstone
fill 267 203 287 267 204 287 minecraft:cut_sandstone
fill 268 203 278 268 204 278 minecraft:cut_sandstone
fill 268 203 280 268 204 280 minecraft:cut_sandstone
fill 268 203 282 268 204 282 minecraft:cut_sandstone
fill 268 203 284 268 204 284 minecraft:cut_sandstone
fill 268 203 286 268 204 286 minecraft:cut_sandstone
fill 269 203 277 269 204 277 minecraft:cut_sandstone
fill 269 203 279 269 204 279 minecraft:cut_sandstone
fill 269 203 281 269 204 281 minecraft:cut_sandstone
fill 269 203 283 269 204 283 minecraft:cut_sandstone
fill 269 203 285 269 204 285 minecraft:cut_sandstone
fill 269 203 287 269 204 287 minecraft:cut_sandstone
fill 270 203 278 270 204 278 minecraft:cut_sandstone
fill 270 203 280 270 204 280 minecraft:cut_sandstone
fill 270 203 282 270 204 282 minecraft:cut_sandstone
fill 270 203 284 270 204 284 minecraft:cut_sandstone
fill 270 203 286 270 204 286 minecraft:cut_sandstone
fill 271 203 277 271 204 277 minecraft:cut_sandstone
fill 271 203 279 271 204 279 minecraft:cut_sandstone
fill 271 203 281 271 204 281 minecraft:cut_sandstone
fill 271 203 283 271 204 283 minecraft:cut_sandstone
fill 271 203 285 271 204 285 minecraft:cut_sandstone
fill 271 203 287 271 204 287 minecraft:cut_sandstone
fill 272 203 278 272 204 278 minecraft:cut_sandstone
fill 272 203 280 272 204 280 minecraft:cut_sandstone
fill 272 203 282 272 204 282 minecraft:cut_sandstone
fill 272 203 284 272 204 284 minecraft:cut_sandstone
fill 272 203 286 272 204 286 minecraft:cut_sandstone
fill 273 203 277 273 204 277 minecraft:cut_sandstone
fill 273 203 279 273 204 279 minecraft:cut_sandstone
fill 273 203 281 273 204 281 minecraft:cut_sandstone
fill 273 203 283 273 204 283 minecraft:cut_sandstone
fill 273 203 285 273 204 285 minecraft:cut_sandstone
fill 273 203 287 273 204 287 minecraft:cut_sandstone
fill 274 203 278 274 204 278 minecraft:cut_sandstone
fill 274 203 280 274 204 280 minecraft:cut_sandstone
fill 274 203 282 274 204 282 minecraft:cut_sandstone
fill 274 203 284 274 204 284 minecraft:cut_sandstone
fill 274 203 286 274 204 286 minecraft:cut_sandstone
fill 275 203 277 275 204 277 minecraft:cut_sandstone
fill 275 203 279 275 204 279 minecraft:cut_sandstone
fill 275 203 281 275 204 281 minecraft:cut_sandstone
fill 275 203 283 275 204 283 minecraft:cut_sandstone
fill 275 203 285 275 204 285 minecraft:cut_sandstone
fill 275 203 287 275 204 287 minecraft:cut_sandstone
fill 276 203 278 276 204 278 minecraft:cut_sandstone
fill 276 203 280 276 204 280 minecraft:cut_sandstone
fill 276 203 282 276 204 282 minecraft:cut_sandstone
fill 276 203 284 276 204 284 minecraft:cut_sandstone
fill 276 203 286 276 204 286 minecraft:cut_sandstone
fill 277 203 276 277 204 284 minecraft:smooth_sandstone
fill 277 203 286 277 205 292 minecraft:smooth_sandstone
setblock 277 203 293 minecraft:sandstone
fill 277 203 294 277 204 296 minecraft:smooth_sandstone
fill 277 203 298 277 204 302 minecraft:smooth_sandstone
setblock 277 203 303 minecraft:sandstone
fill 277 203 305 277 204 309 minecraft:smooth_sandstone
setblock 277 203 310 minecraft:lapis_block
setblock 277 203 311 minecraft:smooth_sandstone
fill 277 203 313 277 205 316 minecraft:smooth_sandstone
setblock 235 204 275 minecraft:smooth_sandstone
fill 235 204 277 235 207 279 minecraft:smooth_sandstone
fill 235 204 280 235 205 280 minecraft:sandstone
fill 235 204 281 235 204 287 minecraft:smooth_sandstone
setblock 235 204 288 minecraft:sandstone
fill 235 204 289 235 205 295 minecraft:smooth_sandstone
setblock 235 204 296 minecraft:sandstone
fill 235 204 297 235 204 308 minecraft:smooth_sandstone
fill 235 204 310 235 220 310 minecraft:smooth_sandstone
fill 235 204 316 235 205 317 minecraft:smooth_sandstone
setblock 236 204 317 minecraft:sandstone
fill 237 204 275 239 215 275 minecraft:smooth_sandstone
fill 237 204 317 249 204 317 minecraft:smooth_sandstone
setblock 240 204 275 minecraft:sandstone
fill 241 204 275 248 205 275 minecraft:smooth_sandstone
setblock 249 204 275 minecraft:lapis_block
fill 250 204 275 250 297 275 minecraft:smooth_sandstone
setblock 250 204 317 minecraft:sandstone
fill 251 204 317 252 212 317 minecraft:smooth_sandstone
fill 252 204 275 255 204 275 minecraft:smooth_sandstone
fill 254 204 317 254 260 317 minecraft:smooth_sandstone
setblock 256 204 275 minecraft:sandstone
fill 257 204 275 276 204 275 minecraft:smooth_sandstone
fill 265 204 317 266 206 317 minecraft:smooth_sandstone
setblock 267 204 317 minecraft:sandstone
fill 268 204 317 276 205 317 minecraft:smooth_sandstone
fill 275 204 284 275 214 284 minecraft:cut_sandstone
fill 277 204 275 277 205 275 minecraft:sandstone
fill 277 204 285 277 308 285 minecraft:smooth_sandstone
fill 277 204 293 277 238 293 minecraft:smooth_sandstone
fill 277 204 297 277 210 297 minecraft:smooth_sandstone
fill 277 204 303 277 205 303 minecraft:smooth_sandstone
fill 277 204 310 277 245 310 minecraft:smooth_sandstone
setblock 277 204 311 minecraft:lapis_block
setblock 277 204 312 minecraft:smooth_sandstone
fill 277 204 317 277 205 317 minecraft:sandstone
setblock 235 205 275 minecraft:sandstone
fill 235 205 276 235 274 276 minecraft:smooth_sandstone
fill 235 205 281 235 205 285 minecraft:smooth_sandstone
setblock 235 205 286 minecraft:orange_terracotta
fill 235 205 287 235 270 288 minecraft:smooth_sandstone
fill 235 205 296 235 205 300 minecraft:smooth_sandstone
setblock 235 205 301 minecraft:sandstone
fill 235 205 302 235 205 307 minecraft:smooth_sandstone
setblock 235 205 308 minecraft:sandstone
fill 235 205 311 235 279 314 minecraft:smooth_sandstone
setblock 235 205 315 minecraft:blue_terracotta
fill 236 205 279 236 205 284 minecraft:chiseled_sandstone
fill 236 205 291 236 205 296 minecraft:chiseled_sandstone
fill 236 205 303 236 205 308 minecraft:chiseled_sandstone
fill 236 205 315 236 205 316 minecraft:chiseled_sandstone
fill 236 205 317 237 205 317 minecraft:smooth_sandstone
fill 237 205 316 240 205 316 minecraft:chiseled_sandstone
setblock 238 205 317 minecraft:sandstone
fill 239 205 317 241 223 317 minecraft:smooth_sandstone
fill 240 205 275 240 308 275 minecraft:smooth_sandstone
fill 240 205 276 245 205 276 minecraft:chiseled_sandstone
setblock 242 205 317 minecraft:sandstone
fill 243 205 277 249 207 282 minecraft:cut_sandstone
fill 243 205 317 243 255 317 minecraft:smooth_sandstone
setblock 244 205 317 minecraft:sandstone
fill 245 205 317 250 205 317 minecraft:smooth_sandstone
fill 246 205 276 249 207 276 minecraft:cut_sandstone
fill 246 205 312 246 214 316 minecraft:cut_sandstone
fill 247 205 312 256 214 315 minecraft:cut_sandstone
fill 247 205 316 252 205 316 minecraft:chiseled_sandstone
fill 249 205 275 249 308 275 minecraft:smooth_sandstone
setblock 252 205 275 minecraft:sandstone
fill 252 205 276 257 205 276 minecraft:chiseled_sandstone
fill 253 205 275 254 205 275 minecraft:smooth_sandstone
fill 253 205 316 256 214 316 minecraft:cut_sandstone
setblock 255 205 275 minecraft:sandstone
fill 256 205 275 257 205 275 minecraft:smooth_sandstone
setblock 258 205 275 minecraft:sandstone
fill 259 205 275 263 220 275 minecraft:smooth_sandstone
fill 259 205 316 264 205 316 minecraft:chiseled_sandstone
setblock 264 205 275 minecraft:sandstone
fill 264 205 276 269 205 276 minecraft:chiseled_sandstone
fill 265 205 275 276 205 275 minecraft:smooth_sandstone
setblock 267 205 277 minecraft:glowstone
setblock 267 205 279 minecraft:glowstone
setblock 267 205 281 minecraft:glowstone
setblock 267 205 283 minecraft:glowstone
setblock 267 205 285 minecraft:glowstone
setblock 267 205 287 minecraft:glowstone
fill 267 205 317 267 299 317 minecraft:smooth_sandstone
setblock 268 205 278 minecraft:glowstone
setblock 268 205 280 minecraft:glowstone
setblock 268 205 282 minecraft:glowstone
setblock 268 205 284 minecraft:glowstone
setblock 268 205 286 minecraft:glowstone
setblock 269 205 277 minecraft:glowstone
setblock 269 205 279 minecraft:glowstone
setblock 269 205 281 minecraft:glowstone
setblock 269 205 283 minecraft:glowstone
setblock 269 205 285 minecraft:glowstone
setblock 269 205 287 minecraft:glowstone
setblock 270 205 278 minecraft:glowstone
setblock 270 205 280 minecraft:glowstone
setblock 270 205 282 minecraft:glowstone
setblock 270 205 284 minecraft:glowstone
setblock 270 205 286 minecraft:glowstone
setblock 271 205 277 minecraft:glowstone
setblock 271 205 279 minecraft:glowstone
setblock 271 205 281 minecraft:glowstone
setblock 271 205 283 minecraft:glowstone
setblock 271 205 285 minecraft:glowstone
setblock 271 205 287 minecraft:glowstone
fill 271 205 316 276 205 316 minecraft:chiseled_sandstone
setblock 272 205 278 minecraft:glowstone
setblock 272 205 280 minecraft:glowstone
setblock 272 205 282 minecraft:glowstone
setblock 272 205 284 minecraft:glowstone
setblock 272 205 286 minecraft:glowstone
setblock 273 205 277 minecraft:glowstone
setblock 273 205 279 minecraft:glowstone
setblock 273 205 281 minecraft:glowstone
setblock 273 205 283 minecraft:glowstone
setblock 273 205 285 minecraft:glowstone
setblock 273 205 287 minecraft:glowstone
setblock 274 205 278 minecraft:glowstone
setblock 274 205 280 minecraft:glowstone
setblock 274 205 282 minecraft:glowstone
setblock 274 205 284 minecraft:glowstone
setblock 274 205 286 minecraft:glowstone
setblock 275 205 277 minecraft:glowstone
setblock 275 205 279 minecraft:glowstone
setblock 275 205 281 minecraft:glowstone
setblock 275 205 283 minecraft:glowstone
setblock 275 205 285 minecraft:glowstone
setblock 275 205 287 minecraft:glowstone
fill 276 205 276 276 205 277 minecraft:chiseled_sandstone
setblock 276 205 278 minecraft:glowstone
setblock 276 205 279 minecraft:chiseled_sandstone
setblock 276 205 280 minecraft:glowstone
setblock 276 205 281 minecraft:chiseled_sandstone
setblock 276 205 282 minecraft:glowstone
setblock 276 205 284 minecraft:glowstone
setblock 276 205 286 minecraft:glowstone
fill 276 205 288 276 205 293 minecraft:chiseled_sandstone
fill 276 205 300 276 205 305 minecraft:chiseled_sandstone
fill 276 205 312 276 205 315 minecraft:chiseled_sandstone
setblock 277 205 276 minecraft:sandstone
fill 277 205 277 277 205 282 minecraft:smooth_sandstone
setblock 277 205 283 minecraft:blue_terracotta
fill 277 205 284 277 246 284 minecraft:smooth_sandstone
setblock 277 205 294 minecraft:sandstone
fill 277 205 295 277 296 295 minecraft:smooth_sandstone
setblock 277 205 296 minecraft:sandstone
fill 277 205 298 277 271 298 minecraft:smooth_sandstone
setblock 277 205 299 minecraft:sandstone
fill 277 205 300 277 205 302 minecraft:smooth_sandstone
fill 277 205 304 277 208 308 minecraft:smooth_sandstone
setblock 277 205 309 minecraft:sandstone
fill 277 205 311 277 237 311 minecraft:smooth_sandstone
setblock 277 205 312 minecraft:sandstone
fill 235 206 275 235 308 275 minecraft:smooth_sandstone
fill 235 206 280 235 217 280 minecraft:smooth_sandstone
fill 235 206 281 235 211 284 minecraft:glowstone
fill 235 206 285 235 222 286 minecraft:smooth_sandstone
fill 235 206 289 235 219 292 minecraft:smooth_sandstone
fill 235 206 293 235 211 296 minecraft:glowstone
fill 235 206 297 235 224 304 minecraft:smooth_sandstone
fill 235 206 305 235 211 308 minecraft:glowstone
fill 235 206 309 235 308 309 minecraft:smooth_sandstone
fill 235 206 315 235 265 316 minecraft:smooth_sandstone
fill 235 206 317 238 211 317 minecraft:glowstone
fill 241 206 275 241 285 275 minecraft:smooth_sandstone
fill 242 206 275 245 211 275 minecraft:glowstone
fill 242 206 317 242 308 317 minecraft:smooth_sandstone
fill 243 206 276 245 207 276 minecraft:cut_sandstone
fill 244 206 317 246 219 317 minecraft:smooth_sandstone
fill 246 206 275 247 228 275 minecraft:smooth_sandstone
fill 247 206 316 252 214 316 minecraft:cut_sandstone
fill 247 206 317 250 211 317 minecraft:glowstone
setblock 248 206 275 minecraft:black_terracotta
fill 252 206 275 253 209 275 minecraft:smooth_sandstone
fill 254 206 275 257 211 275 minecraft:glowstone
fill 255 206 317 258 235 317 minecraft:smooth_sandstone
fill 258 206 275 258 308 275 minecraft:smooth_sandstone
fill 259 206 317 262 211 317 minecraft:glowstone
fill 263 206 317 264 221 317 minecraft:smooth_sandstone
fill 264 206 275 265 286 275 minecraft:smooth_sandstone
fill 266 206 275 269 211 275 minecraft:glowstone
fill 267 206 277 267 207 277 minecraft:cut_sandstone
fill 267 206 279 267 207 279 minecraft:cut_sandstone
fill 267 206 281 267 207 281 minecraft:cut_sandstone
fill 267 206 283 267 207 283 minecraft:cut_sandstone
fill 267 206 285 267 207 285 minecraft:cut_sandstone
fill 267 206 287 267 207 287 minecraft:cut_sandstone
fill 268 206 278 268 207 278 minecraft:cut_sandstone
fill 268 206 280 268 207 280 minecraft:cut_sandstone
fill 268 206 282 268 207 282 minecraft:cut_sandstone
fill 268 206 284 268 207 284 minecraft:cut_sandstone
fill 268 206 286 268 207 286 minecraft:cut_sandstone
fill 268 206 317 270 235 317 minecraft:smooth_sandstone
fill 269 206 277 269 207 277 minecraft:cut_sandstone
fill 269 206 279 269 207 279 minecraft:cut_sandstone
fill 269 206 281 269 207 281 minecraft:cut_sandstone
fill 269 206 283 269 207 283 minecraft:cut_sandstone
fill 269 206 285 269 207 285 minecraft:cut_sandstone
fill 269 206 287 269 207 287 minecraft:cut_sandstone
fill 270 206 275 277 216 275 minecraft:smooth_sandstone
fill 270 206 278 270 207 278 minecraft:cut_sandstone
fill 270 206 280 270 207 280 minecraft:cut_sandstone
fill 270 206 282 270 207 282 minecraft:cut_sandstone
fill 270 206 284 270 207 284 minecraft:cut_sandstone
fill 270 206 286 270 207 286 minecraft:cut_sandstone
fill 271 206 277 271 207 277 minecraft:cut_sandstone
fill 271 206 279 271 207 279 minecraft:cut_sandstone
fill 271 206 281 271 207 281 minecraft:cut_sandstone
fill 271 206 283 271 207 283 minecraft:cut_sandstone
fill 271 206 285 271 207 285 minecraft:cut_sandstone
fill 271 206 287 271 207 287 minecraft:cut_sandstone
fill 271 206 317 274 211 317 minecraft:glowstone
schedule function dropper:buildpart/65_3 1t
