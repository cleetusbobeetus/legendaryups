setblock 416 112 188 minecraft:stone_bricks
fill 416 112 189 416 115 189 minecraft:mossy_cobblestone
setblock 416 112 193 minecraft:stone_bricks
fill 416 112 194 416 114 194 minecraft:mossy_cobblestone
setblock 416 112 198 minecraft:stone_bricks
fill 416 112 199 416 115 199 minecraft:mossy_cobblestone
setblock 416 112 203 minecraft:stone_bricks
fill 416 112 204 416 115 204 minecraft:mossy_cobblestone
setblock 417 112 182 minecraft:stone_bricks
fill 417 112 183 417 115 183 minecraft:mossy_cobblestone
setblock 417 112 187 minecraft:stone_bricks
fill 417 112 188 417 115 188 minecraft:mossy_cobblestone
setblock 417 112 192 minecraft:stone_bricks
fill 417 112 193 417 115 193 minecraft:mossy_cobblestone
setblock 417 112 197 minecraft:stone_bricks
fill 417 112 198 417 115 198 minecraft:mossy_cobblestone
setblock 417 112 202 minecraft:stone_bricks
fill 417 112 203 417 115 203 minecraft:mossy_cobblestone
setblock 417 112 207 minecraft:stone_bricks
fill 417 112 208 417 115 208 minecraft:mossy_cobblestone
fill 417 112 210 417 113 210 minecraft:mossy_cobblestone
setblock 417 112 217 minecraft:stone_bricks
fill 417 112 218 417 114 218 minecraft:mossy_cobblestone
setblock 417 112 222 minecraft:stone_bricks
fill 377 113 182 377 116 182 minecraft:mossy_cobblestone
setblock 377 113 186 minecraft:stone_bricks
fill 377 113 187 377 116 187 minecraft:mossy_cobblestone
setblock 377 113 190 minecraft:mossy_cobblestone
setblock 377 113 191 minecraft:stone_bricks
fill 377 113 192 377 116 192 minecraft:mossy_cobblestone
setblock 377 113 196 minecraft:stone_bricks
fill 377 113 197 377 115 197 minecraft:mossy_cobblestone
setblock 377 113 201 minecraft:stone_bricks
fill 377 113 202 377 116 202 minecraft:mossy_cobblestone
setblock 377 113 205 minecraft:mossy_cobblestone
setblock 377 113 206 minecraft:stone_bricks
fill 377 113 207 377 116 207 minecraft:mossy_cobblestone
setblock 377 113 210 minecraft:mossy_cobblestone
setblock 377 113 211 minecraft:stone_bricks
fill 377 113 212 377 116 212 minecraft:mossy_cobblestone
setblock 377 113 216 minecraft:stone_bricks
fill 377 113 217 377 116 217 minecraft:mossy_cobblestone
setblock 377 113 221 minecraft:stone_bricks
fill 377 113 222 377 116 222 minecraft:mossy_cobblestone
setblock 378 113 185 minecraft:stone_bricks
fill 378 113 186 378 116 186 minecraft:mossy_cobblestone
setblock 378 113 190 minecraft:stone_bricks
setblock 378 113 200 minecraft:stone_bricks
fill 378 113 201 378 115 201 minecraft:mossy_cobblestone
setblock 378 113 204 minecraft:mossy_cobblestone
setblock 378 113 205 minecraft:stone_bricks
fill 378 113 206 378 116 206 minecraft:mossy_cobblestone
setblock 378 113 209 minecraft:mossy_cobblestone
fill 378 113 216 378 114 216 minecraft:mossy_cobblestone
setblock 378 113 219 minecraft:mossy_cobblestone
setblock 378 113 220 minecraft:stone_bricks
fill 378 113 221 378 116 221 minecraft:mossy_cobblestone
setblock 379 113 184 minecraft:stone_bricks
fill 379 113 185 380 114 185 minecraft:mossy_cobblestone
setblock 379 113 192 minecraft:light[level=12]
setblock 379 113 200 minecraft:light[level=12]
setblock 379 113 204 minecraft:stone_bricks
setblock 379 113 205 minecraft:mossy_cobblestone
setblock 379 113 208 minecraft:light[level=12]
setblock 379 113 216 minecraft:light[level=12]
setblock 379 113 219 minecraft:stone_bricks
fill 379 113 220 379 115 220 minecraft:mossy_cobblestone
setblock 380 113 183 minecraft:stone_bricks
fill 380 113 184 380 116 184 minecraft:mossy_cobblestone
setblock 381 113 182 minecraft:stone_bricks
fill 381 113 183 381 116 183 minecraft:mossy_cobblestone
setblock 381 113 222 minecraft:stone_bricks
fill 382 113 182 382 116 182 minecraft:mossy_cobblestone
setblock 382 113 221 minecraft:stone_bricks
fill 382 113 222 385 113 222 minecraft:mossy_cobblestone
setblock 383 113 220 minecraft:stone_bricks
fill 383 113 221 383 116 221 minecraft:mossy_cobblestone
setblock 384 113 184 minecraft:stone_bricks
setblock 384 113 220 minecraft:mossy_cobblestone
setblock 385 113 183 minecraft:stone_bricks
setblock 386 113 182 minecraft:stone_bricks
fill 386 113 183 386 114 183 minecraft:mossy_cobblestone
setblock 386 113 222 minecraft:stone_bricks
fill 387 113 182 390 113 182 minecraft:mossy_cobblestone
setblock 387 113 184 minecraft:light[level=12]
setblock 387 113 192 minecraft:light[level=12]
setblock 387 113 200 minecraft:light[level=12]
setblock 387 113 208 minecraft:light[level=12]
setblock 387 113 216 minecraft:light[level=12]
setblock 387 113 221 minecraft:stone_bricks
fill 387 113 222 387 116 222 minecraft:mossy_cobblestone
fill 388 113 221 391 113 221 minecraft:mossy_cobblestone
setblock 391 113 182 minecraft:stone_bricks
setblock 391 113 222 minecraft:stone_bricks
fill 392 113 182 395 113 182 minecraft:mossy_cobblestone
setblock 392 113 221 minecraft:stone_bricks
fill 392 113 222 392 116 222 minecraft:mossy_cobblestone
fill 393 113 221 393 114 221 minecraft:mossy_cobblestone
setblock 395 113 183 minecraft:stone_bricks
setblock 395 113 184 minecraft:light[level=12]
setblock 395 113 192 minecraft:light[level=12]
setblock 395 113 200 minecraft:light[level=12]
setblock 395 113 208 minecraft:light[level=12]
setblock 395 113 216 minecraft:light[level=12]
setblock 396 113 182 minecraft:stone_bricks
fill 396 113 183 399 113 183 minecraft:mossy_cobblestone
setblock 396 113 222 minecraft:stone_bricks
fill 397 113 182 397 116 182 minecraft:mossy_cobblestone
setblock 397 113 221 minecraft:stone_bricks
fill 397 113 222 397 116 222 minecraft:mossy_cobblestone
setblock 398 113 220 minecraft:stone_bricks
fill 398 113 221 398 115 221 minecraft:mossy_cobblestone
setblock 399 113 220 minecraft:mossy_cobblestone
setblock 400 113 183 minecraft:stone_bricks
setblock 401 113 182 minecraft:stone_bricks
fill 401 113 183 401 116 183 minecraft:mossy_cobblestone
setblock 401 113 222 minecraft:stone_bricks
fill 402 113 182 402 116 182 minecraft:mossy_cobblestone
setblock 402 113 221 minecraft:stone_bricks
fill 402 113 222 402 115 222 minecraft:mossy_cobblestone
setblock 403 113 184 minecraft:light[level=12]
setblock 403 113 192 minecraft:light[level=12]
setblock 403 113 200 minecraft:light[level=12]
setblock 403 113 208 minecraft:light[level=12]
setblock 403 113 216 minecraft:light[level=12]
setblock 403 113 221 minecraft:mossy_cobblestone
setblock 404 113 183 minecraft:mossy_cobblestone
setblock 405 113 183 minecraft:stone_bricks
setblock 406 113 182 minecraft:stone_bricks
setblock 406 113 222 minecraft:stone_bricks
fill 407 113 182 410 113 182 minecraft:mossy_cobblestone
setblock 411 113 182 minecraft:stone_bricks
fill 411 113 183 411 116 183 minecraft:mossy_cobblestone
setblock 411 113 184 minecraft:light[level=12]
setblock 411 113 192 minecraft:light[level=12]
setblock 411 113 200 minecraft:light[level=12]
setblock 411 113 208 minecraft:light[level=12]
setblock 411 113 216 minecraft:light[level=12]
fill 412 113 182 412 116 182 minecraft:mossy_cobblestone
setblock 414 113 183 minecraft:mossy_cobblestone
setblock 414 113 184 minecraft:stone_bricks
setblock 415 113 183 minecraft:stone_bricks
fill 415 113 184 415 116 184 minecraft:mossy_cobblestone
fill 415 113 186 415 113 187 minecraft:mossy_cobblestone
setblock 415 113 203 minecraft:stone_bricks
setblock 416 113 182 minecraft:stone_bricks
fill 416 113 183 416 116 183 minecraft:mossy_cobblestone
setblock 416 113 186 minecraft:mossy_cobblestone
setblock 416 113 187 minecraft:stone_bricks
fill 416 113 188 416 116 188 minecraft:mossy_cobblestone
setblock 416 113 192 minecraft:stone_bricks
fill 416 113 193 416 115 193 minecraft:mossy_cobblestone
setblock 416 113 197 minecraft:stone_bricks
fill 416 113 198 416 115 198 minecraft:mossy_cobblestone
setblock 416 113 202 minecraft:stone_bricks
fill 416 113 203 416 116 203 minecraft:mossy_cobblestone
setblock 416 113 207 minecraft:stone_bricks
setblock 416 113 222 minecraft:stone_bricks
fill 417 113 182 417 116 182 minecraft:mossy_cobblestone
setblock 417 113 186 minecraft:stone_bricks
fill 417 113 187 417 116 187 minecraft:mossy_cobblestone
setblock 417 113 191 minecraft:stone_bricks
fill 417 113 192 417 116 192 minecraft:mossy_cobblestone
setblock 417 113 196 minecraft:stone_bricks
fill 417 113 197 417 116 197 minecraft:mossy_cobblestone
setblock 417 113 201 minecraft:stone_bricks
fill 417 113 202 417 116 202 minecraft:mossy_cobblestone
setblock 417 113 206 minecraft:stone_bricks
fill 417 113 207 417 116 207 minecraft:mossy_cobblestone
setblock 417 113 217 minecraft:mossy_cobblestone
setblock 417 113 221 minecraft:stone_bricks
fill 417 113 222 417 116 222 minecraft:mossy_cobblestone
setblock 377 114 185 minecraft:stone_bricks
fill 377 114 186 377 117 186 minecraft:mossy_cobblestone
setblock 377 114 190 minecraft:stone_bricks
fill 377 114 191 377 117 191 minecraft:mossy_cobblestone
setblock 377 114 195 minecraft:stone_bricks
setblock 377 114 196 minecraft:mossy_cobblestone
setblock 377 114 200 minecraft:stone_bricks
fill 377 114 201 377 117 201 minecraft:mossy_cobblestone
setblock 377 114 205 minecraft:stone_bricks
fill 377 114 206 377 117 206 minecraft:mossy_cobblestone
setblock 377 114 210 minecraft:stone_bricks
fill 377 114 211 377 117 211 minecraft:mossy_cobblestone
setblock 377 114 215 minecraft:stone_bricks
fill 377 114 216 377 117 216 minecraft:mossy_cobblestone
setblock 377 114 220 minecraft:stone_bricks
fill 377 114 221 377 117 221 minecraft:mossy_cobblestone
setblock 378 114 184 minecraft:stone_bricks
fill 378 114 185 378 117 185 minecraft:mossy_cobblestone
setblock 378 114 189 minecraft:stone_bricks
fill 378 114 190 378 116 190 minecraft:mossy_cobblestone
setblock 378 114 199 minecraft:stone_bricks
setblock 378 114 200 minecraft:mossy_cobblestone
setblock 378 114 203 minecraft:mossy_cobblestone
setblock 378 114 204 minecraft:stone_bricks
fill 378 114 205 378 117 205 minecraft:mossy_cobblestone
setblock 378 114 209 minecraft:stone_bricks
fill 378 114 210 378 117 210 minecraft:mossy_cobblestone
setblock 378 114 219 minecraft:stone_bricks
fill 378 114 220 378 117 220 minecraft:mossy_cobblestone
setblock 379 114 183 minecraft:stone_bricks
fill 379 114 184 379 117 184 minecraft:mossy_cobblestone
setblock 379 114 219 minecraft:mossy_cobblestone
setblock 380 114 182 minecraft:stone_bricks
fill 380 114 183 380 117 183 minecraft:mossy_cobblestone
setblock 380 114 222 minecraft:stone_bricks
fill 381 114 182 381 117 182 minecraft:mossy_cobblestone
setblock 381 114 221 minecraft:stone_bricks
fill 381 114 222 384 114 222 minecraft:mossy_cobblestone
setblock 382 114 220 minecraft:stone_bricks
fill 382 114 221 382 116 221 minecraft:mossy_cobblestone
setblock 383 114 184 minecraft:stone_bricks
setblock 383 114 220 minecraft:mossy_cobblestone
setblock 384 114 183 minecraft:stone_bricks
setblock 385 114 182 minecraft:stone_bricks
fill 385 114 183 385 115 183 minecraft:mossy_cobblestone
setblock 385 114 222 minecraft:stone_bricks
fill 386 114 182 389 114 182 minecraft:mossy_cobblestone
setblock 386 114 221 minecraft:stone_bricks
fill 386 114 222 386 116 222 minecraft:mossy_cobblestone
setblock 387 114 221 minecraft:mossy_cobblestone
setblock 390 114 182 minecraft:stone_bricks
setblock 390 114 222 minecraft:stone_bricks
fill 391 114 182 394 114 182 minecraft:mossy_cobblestone
fill 391 114 222 391 116 222 minecraft:mossy_cobblestone
setblock 395 114 182 minecraft:stone_bricks
fill 395 114 183 398 114 183 minecraft:mossy_cobblestone
setblock 395 114 222 minecraft:stone_bricks
fill 396 114 182 396 117 182 minecraft:mossy_cobblestone
setblock 396 114 221 minecraft:stone_bricks
fill 396 114 222 396 117 222 minecraft:mossy_cobblestone
fill 397 114 221 397 115 221 minecraft:mossy_cobblestone
setblock 399 114 183 minecraft:stone_bricks
setblock 400 114 182 minecraft:stone_bricks
fill 400 114 183 400 117 183 minecraft:mossy_cobblestone
setblock 400 114 222 minecraft:stone_bricks
fill 401 114 182 401 117 182 minecraft:mossy_cobblestone
setblock 401 114 221 minecraft:stone_bricks
fill 401 114 222 401 116 222 minecraft:mossy_cobblestone
setblock 404 114 183 minecraft:stone_bricks
setblock 405 114 182 minecraft:stone_bricks
fill 406 114 182 409 114 182 minecraft:mossy_cobblestone
setblock 410 114 182 minecraft:stone_bricks
fill 411 114 182 411 117 182 minecraft:mossy_cobblestone
setblock 414 114 183 minecraft:stone_bricks
fill 414 114 184 414 117 184 minecraft:mossy_cobblestone
setblock 415 114 182 minecraft:stone_bricks
fill 415 114 183 415 117 183 minecraft:mossy_cobblestone
setblock 415 114 186 minecraft:mossy_cobblestone
setblock 415 114 187 minecraft:stone_bricks
fill 415 114 188 415 117 188 minecraft:mossy_cobblestone
setblock 415 114 222 minecraft:stone_bricks
fill 416 114 182 416 117 182 minecraft:mossy_cobblestone
setblock 416 114 186 minecraft:stone_bricks
fill 416 114 187 416 117 187 minecraft:mossy_cobblestone
setblock 416 114 190 minecraft:mossy_cobblestone
setblock 416 114 191 minecraft:stone_bricks
fill 416 114 192 416 117 192 minecraft:mossy_cobblestone
setblock 416 114 196 minecraft:stone_bricks
fill 416 114 197 416 115 197 minecraft:mossy_cobblestone
setblock 416 114 201 minecraft:stone_bricks
fill 416 114 202 416 117 202 minecraft:mossy_cobblestone
setblock 416 114 205 minecraft:mossy_cobblestone
setblock 416 114 206 minecraft:stone_bricks
fill 416 114 207 416 117 207 minecraft:mossy_cobblestone
setblock 416 114 221 minecraft:stone_bricks
fill 416 114 222 416 117 222 minecraft:mossy_cobblestone
setblock 417 114 185 minecraft:stone_bricks
fill 417 114 186 417 117 186 minecraft:mossy_cobblestone
setblock 417 114 190 minecraft:stone_bricks
fill 417 114 191 417 117 191 minecraft:mossy_cobblestone
setblock 417 114 195 minecraft:stone_bricks
fill 417 114 196 417 117 196 minecraft:mossy_cobblestone
setblock 417 114 200 minecraft:stone_bricks
fill 417 114 201 417 117 201 minecraft:mossy_cobblestone
setblock 417 114 205 minecraft:stone_bricks
fill 417 114 206 417 117 206 minecraft:mossy_cobblestone
setblock 417 114 210 minecraft:stone_bricks
fill 417 114 211 417 117 211 minecraft:mossy_cobblestone
setblock 417 114 220 minecraft:stone_bricks
fill 417 114 221 417 117 221 minecraft:mossy_cobblestone
setblock 377 115 184 minecraft:stone_bricks
fill 377 115 185 377 118 185 minecraft:mossy_cobblestone
setblock 377 115 189 minecraft:stone_bricks
fill 377 115 190 377 118 190 minecraft:mossy_cobblestone
setblock 377 115 194 minecraft:stone_bricks
setblock 377 115 199 minecraft:stone_bricks
fill 377 115 200 377 116 200 minecraft:mossy_cobblestone
setblock 377 115 204 minecraft:stone_bricks
fill 377 115 205 377 118 205 minecraft:mossy_cobblestone
setblock 377 115 208 minecraft:mossy_cobblestone
setblock 377 115 209 minecraft:stone_bricks
fill 377 115 210 377 118 210 minecraft:mossy_cobblestone
setblock 377 115 214 minecraft:stone_bricks
fill 377 115 215 377 118 215 minecraft:mossy_cobblestone
setblock 377 115 218 minecraft:mossy_cobblestone
setblock 377 115 219 minecraft:stone_bricks
fill 377 115 220 377 118 220 minecraft:mossy_cobblestone
setblock 378 115 183 minecraft:stone_bricks
fill 378 115 184 378 118 184 minecraft:mossy_cobblestone
setblock 378 115 188 minecraft:stone_bricks
fill 378 115 189 378 118 189 minecraft:mossy_cobblestone
setblock 378 115 203 minecraft:stone_bricks
fill 378 115 204 378 117 204 minecraft:mossy_cobblestone
setblock 378 115 208 minecraft:stone_bricks
fill 378 115 209 378 118 209 minecraft:mossy_cobblestone
setblock 378 115 218 minecraft:stone_bricks
fill 378 115 219 378 117 219 minecraft:mossy_cobblestone
setblock 379 115 182 minecraft:stone_bricks
fill 379 115 183 379 118 183 minecraft:mossy_cobblestone
fill 379 115 185 379 116 185 minecraft:mossy_cobblestone
setblock 379 115 187 minecraft:stone_bricks
setblock 379 115 222 minecraft:stone_bricks
fill 380 115 182 380 118 182 minecraft:mossy_cobblestone
setblock 380 115 221 minecraft:stone_bricks
fill 380 115 222 383 115 222 minecraft:mossy_cobblestone
setblock 381 115 220 minecraft:stone_bricks
fill 381 115 221 381 117 221 minecraft:mossy_cobblestone
setblock 382 115 184 minecraft:stone_bricks
setblock 383 115 183 minecraft:stone_bricks
setblock 384 115 182 minecraft:stone_bricks
fill 384 115 183 384 116 183 minecraft:mossy_cobblestone
setblock 384 115 222 minecraft:stone_bricks
fill 385 115 182 388 115 182 minecraft:mossy_cobblestone
setblock 385 115 221 minecraft:stone_bricks
fill 385 115 222 385 117 222 minecraft:mossy_cobblestone
setblock 389 115 182 minecraft:stone_bricks
setblock 389 115 222 minecraft:stone_bricks
fill 390 115 182 393 115 182 minecraft:mossy_cobblestone
fill 390 115 222 390 116 222 minecraft:mossy_cobblestone
setblock 394 115 182 minecraft:stone_bricks
setblock 394 115 222 minecraft:stone_bricks
fill 395 115 182 395 115 183 minecraft:mossy_cobblestone
setblock 395 115 221 minecraft:stone_bricks
fill 395 115 222 395 118 222 minecraft:mossy_cobblestone
fill 396 115 183 397 115 183 minecraft:mossy_cobblestone
setblock 396 115 221 minecraft:mossy_cobblestone
setblock 398 115 183 minecraft:stone_bricks
setblock 399 115 182 minecraft:stone_bricks
fill 399 115 183 399 117 183 minecraft:mossy_cobblestone
setblock 399 115 222 minecraft:stone_bricks
fill 400 115 182 400 118 182 minecraft:mossy_cobblestone
fill 400 115 222 400 116 222 minecraft:mossy_cobblestone
setblock 403 115 183 minecraft:stone_bricks
setblock 404 115 182 minecraft:stone_bricks
fill 405 115 182 408 115 182 minecraft:mossy_cobblestone
setblock 409 115 182 minecraft:stone_bricks
fill 410 115 182 410 118 182 minecraft:mossy_cobblestone
setblock 413 115 183 minecraft:stone_bricks
fill 413 115 184 413 118 184 minecraft:mossy_cobblestone
setblock 414 115 182 minecraft:stone_bricks
fill 414 115 183 414 118 183 minecraft:mossy_cobblestone
setblock 414 115 222 minecraft:stone_bricks
fill 415 115 182 415 118 182 minecraft:mossy_cobblestone
setblock 415 115 186 minecraft:stone_bricks
fill 415 115 187 415 118 187 minecraft:mossy_cobblestone
fill 415 115 222 415 118 222 minecraft:mossy_cobblestone
setblock 416 115 185 minecraft:stone_bricks
fill 416 115 186 416 118 186 minecraft:mossy_cobblestone
setblock 416 115 190 minecraft:stone_bricks
fill 416 115 191 416 118 191 minecraft:mossy_cobblestone
setblock 416 115 200 minecraft:stone_bricks
fill 416 115 201 416 116 201 minecraft:mossy_cobblestone
setblock 416 115 205 minecraft:stone_bricks
fill 416 115 206 416 118 206 minecraft:mossy_cobblestone
setblock 417 115 184 minecraft:stone_bricks
fill 417 115 185 417 118 185 minecraft:mossy_cobblestone
setblock 417 115 189 minecraft:stone_bricks
fill 417 115 190 417 118 190 minecraft:mossy_cobblestone
setblock 417 115 194 minecraft:stone_bricks
fill 417 115 195 417 118 195 minecraft:mossy_cobblestone
setblock 417 115 199 minecraft:stone_bricks
fill 417 115 200 417 118 200 minecraft:mossy_cobblestone
setblock 417 115 204 minecraft:stone_bricks
fill 417 115 205 417 118 205 minecraft:mossy_cobblestone
setblock 417 115 209 minecraft:stone_bricks
fill 417 115 210 417 118 210 minecraft:mossy_cobblestone
setblock 417 115 219 minecraft:stone_bricks
fill 417 115 220 417 118 220 minecraft:mossy_cobblestone
setblock 377 116 183 minecraft:stone_bricks
fill 377 116 184 377 119 184 minecraft:mossy_cobblestone
setblock 377 116 188 minecraft:stone_bricks
fill 377 116 189 377 119 189 minecraft:mossy_cobblestone
setblock 377 116 199 minecraft:mossy_cobblestone
setblock 377 116 203 minecraft:stone_bricks
fill 377 116 204 377 119 204 minecraft:mossy_cobblestone
setblock 377 116 208 minecraft:stone_bricks
fill 377 116 209 377 119 209 minecraft:mossy_cobblestone
setblock 377 116 213 minecraft:stone_bricks
fill 377 116 214 377 119 214 minecraft:mossy_cobblestone
setblock 377 116 218 minecraft:stone_bricks
fill 377 116 219 377 119 219 minecraft:mossy_cobblestone
setblock 378 116 182 minecraft:stone_bricks
fill 378 116 183 378 119 183 minecraft:mossy_cobblestone
setblock 378 116 187 minecraft:stone_bricks
fill 378 116 188 378 119 188 minecraft:mossy_cobblestone
setblock 378 116 203 minecraft:mossy_cobblestone
setblock 378 116 207 minecraft:stone_bricks
fill 378 116 208 378 119 208 minecraft:mossy_cobblestone
setblock 378 116 211 minecraft:mossy_cobblestone
setblock 378 116 218 minecraft:mossy_cobblestone
setblock 378 116 222 minecraft:stone_bricks
fill 379 116 182 379 119 182 minecraft:mossy_cobblestone
setblock 379 116 186 minecraft:stone_bricks
setblock 379 116 187 minecraft:mossy_cobblestone
setblock 379 116 221 minecraft:stone_bricks
fill 379 116 222 382 116 222 minecraft:mossy_cobblestone
fill 380 116 221 380 118 221 minecraft:mossy_cobblestone
setblock 381 116 184 minecraft:stone_bricks
setblock 382 116 183 minecraft:stone_bricks
setblock 383 116 182 minecraft:stone_bricks
setblock 383 116 183 minecraft:mossy_cobblestone
setblock 383 116 222 minecraft:stone_bricks
fill 384 116 182 386 116 182 minecraft:mossy_cobblestone
fill 384 116 222 384 117 222 minecraft:mossy_cobblestone
setblock 388 116 222 minecraft:stone_bricks
setblock 389 116 222 minecraft:mossy_cobblestone
setblock 392 116 182 minecraft:mossy_cobblestone
setblock 393 116 182 minecraft:stone_bricks
setblock 393 116 222 minecraft:stone_bricks
fill 394 116 182 395 118 182 minecraft:mossy_cobblestone
fill 394 116 222 394 118 222 minecraft:mossy_cobblestone
setblock 396 116 183 minecraft:mossy_cobblestone
setblock 397 116 183 minecraft:stone_bricks
setblock 398 116 182 minecraft:stone_bricks
fill 398 116 183 398 117 183 minecraft:mossy_cobblestone
setblock 398 116 222 minecraft:stone_bricks
fill 399 116 182 399 119 182 minecraft:mossy_cobblestone
fill 399 116 222 399 117 222 minecraft:mossy_cobblestone
setblock 403 116 182 minecraft:stone_bricks
fill 404 116 182 405 116 182 minecraft:mossy_cobblestone
setblock 408 116 182 minecraft:stone_bricks
fill 409 116 182 409 119 182 minecraft:mossy_cobblestone
setblock 412 116 183 minecraft:stone_bricks
setblock 413 116 182 minecraft:stone_bricks
fill 413 116 183 413 119 183 minecraft:mossy_cobblestone
fill 414 116 182 414 119 182 minecraft:mossy_cobblestone
fill 414 116 222 414 119 222 minecraft:mossy_cobblestone
setblock 415 116 185 minecraft:stone_bricks
fill 415 116 186 415 119 186 minecraft:mossy_cobblestone
setblock 415 116 189 minecraft:mossy_cobblestone
setblock 416 116 184 minecraft:stone_bricks
fill 416 116 185 416 119 185 minecraft:mossy_cobblestone
setblock 416 116 189 minecraft:stone_bricks
fill 416 116 190 416 119 190 minecraft:mossy_cobblestone
setblock 416 116 200 minecraft:mossy_cobblestone
setblock 416 116 204 minecraft:stone_bricks
fill 416 116 205 416 119 205 minecraft:mossy_cobblestone
setblock 417 116 183 minecraft:stone_bricks
fill 417 116 184 417 119 184 minecraft:mossy_cobblestone
setblock 417 116 188 minecraft:stone_bricks
fill 417 116 189 417 119 189 minecraft:mossy_cobblestone
setblock 417 116 193 minecraft:stone_bricks
fill 417 116 194 417 119 194 minecraft:mossy_cobblestone
setblock 417 116 198 minecraft:stone_bricks
fill 417 116 199 417 118 199 minecraft:mossy_cobblestone
setblock 417 116 203 minecraft:stone_bricks
fill 417 116 204 417 119 204 minecraft:mossy_cobblestone
setblock 417 116 208 minecraft:stone_bricks
fill 417 116 209 417 119 209 minecraft:mossy_cobblestone
setblock 417 116 219 minecraft:mossy_cobblestone
setblock 377 117 182 minecraft:stone_bricks
fill 377 117 183 377 120 183 minecraft:mossy_cobblestone
setblock 377 117 187 minecraft:stone_bricks
fill 377 117 188 377 120 188 minecraft:mossy_cobblestone
setblock 377 117 192 minecraft:stone_bricks
setblock 377 117 202 minecraft:stone_bricks
fill 377 117 203 377 120 203 minecraft:mossy_cobblestone
setblock 377 117 207 minecraft:stone_bricks
fill 377 117 208 377 120 208 minecraft:mossy_cobblestone
setblock 377 117 212 minecraft:stone_bricks
fill 377 117 213 377 120 213 minecraft:mossy_cobblestone
setblock 377 117 217 minecraft:stone_bricks
fill 377 117 218 377 120 218 minecraft:mossy_cobblestone
setblock 377 117 222 minecraft:stone_bricks
fill 378 117 182 378 120 182 minecraft:mossy_cobblestone
setblock 378 117 186 minecraft:stone_bricks
fill 378 117 187 378 120 187 minecraft:mossy_cobblestone
setblock 378 117 206 minecraft:stone_bricks
fill 378 117 207 378 120 207 minecraft:mossy_cobblestone
setblock 378 117 211 minecraft:stone_bricks
setblock 378 117 221 minecraft:stone_bricks
fill 378 117 222 381 117 222 minecraft:mossy_cobblestone
setblock 379 117 185 minecraft:stone_bricks
fill 379 117 186 379 118 186 minecraft:mossy_cobblestone
fill 379 117 221 379 119 221 minecraft:mossy_cobblestone
setblock 380 117 184 minecraft:stone_bricks
setblock 381 117 183 minecraft:stone_bricks
setblock 382 117 182 minecraft:stone_bricks
setblock 382 117 183 minecraft:mossy_cobblestone
setblock 382 117 222 minecraft:stone_bricks
fill 383 117 182 385 117 182 minecraft:mossy_cobblestone
fill 383 117 222 383 118 222 minecraft:mossy_cobblestone
setblock 392 117 222 minecraft:stone_bricks
fill 393 117 182 393 120 182 minecraft:mossy_cobblestone
setblock 393 117 222 minecraft:mossy_cobblestone
setblock 396 117 183 minecraft:stone_bricks
setblock 397 117 182 minecraft:stone_bricks
fill 397 117 183 397 118 183 minecraft:mossy_cobblestone
setblock 397 117 222 minecraft:stone_bricks
fill 398 117 182 398 120 182 minecraft:mossy_cobblestone
setblock 398 117 222 minecraft:mossy_cobblestone
setblock 402 117 182 minecraft:stone_bricks
setblock 403 117 182 minecraft:mossy_cobblestone
setblock 411 117 183 minecraft:stone_bricks
setblock 412 117 182 minecraft:stone_bricks
fill 412 117 183 412 120 183 minecraft:mossy_cobblestone
fill 413 117 182 413 120 182 minecraft:mossy_cobblestone
setblock 415 117 184 minecraft:stone_bricks
fill 415 117 185 415 120 185 minecraft:mossy_cobblestone
setblock 415 117 189 minecraft:stone_bricks
setblock 416 117 183 minecraft:stone_bricks
fill 416 117 184 416 120 184 minecraft:mossy_cobblestone
setblock 416 117 188 minecraft:stone_bricks
fill 416 117 189 416 120 189 minecraft:mossy_cobblestone
setblock 416 117 203 minecraft:stone_bricks
fill 416 117 204 416 118 204 minecraft:mossy_cobblestone
setblock 416 117 208 minecraft:stone_bricks
setblock 417 117 182 minecraft:stone_bricks
fill 417 117 183 417 120 183 minecraft:mossy_cobblestone
setblock 417 117 187 minecraft:stone_bricks
fill 417 117 188 417 120 188 minecraft:mossy_cobblestone
setblock 417 117 192 minecraft:stone_bricks
fill 417 117 193 417 120 193 minecraft:mossy_cobblestone
setblock 417 117 197 minecraft:stone_bricks
fill 417 117 198 417 118 198 minecraft:mossy_cobblestone
setblock 417 117 202 minecraft:stone_bricks
fill 417 117 203 417 120 203 minecraft:mossy_cobblestone
setblock 417 117 207 minecraft:stone_bricks
fill 417 117 208 417 120 208 minecraft:mossy_cobblestone
setblock 417 117 212 minecraft:stone_bricks
setblock 417 117 222 minecraft:stone_bricks
fill 377 118 182 377 121 182 minecraft:mossy_cobblestone
setblock 377 118 186 minecraft:stone_bricks
fill 377 118 187 377 121 187 minecraft:mossy_cobblestone
setblock 377 118 191 minecraft:stone_bricks
fill 377 118 192 377 121 192 minecraft:mossy_cobblestone
fill 377 118 202 377 119 202 minecraft:mossy_cobblestone
setblock 377 118 206 minecraft:stone_bricks
fill 377 118 207 377 121 207 minecraft:mossy_cobblestone
setblock 377 118 211 minecraft:stone_bricks
fill 377 118 212 378 120 212 minecraft:mossy_cobblestone
setblock 377 118 216 minecraft:stone_bricks
fill 377 118 217 377 121 217 minecraft:mossy_cobblestone
setblock 377 118 221 minecraft:stone_bricks
fill 377 118 222 380 118 222 minecraft:mossy_cobblestone
setblock 378 118 185 minecraft:stone_bricks
fill 378 118 186 378 121 186 minecraft:mossy_cobblestone
setblock 378 118 205 minecraft:stone_bricks
fill 378 118 206 378 121 206 minecraft:mossy_cobblestone
setblock 378 118 210 minecraft:stone_bricks
fill 378 118 211 378 121 211 minecraft:mossy_cobblestone
setblock 378 118 220 minecraft:stone_bricks
fill 378 118 221 378 121 221 minecraft:mossy_cobblestone
setblock 379 118 184 minecraft:stone_bricks
setblock 379 118 185 minecraft:mossy_cobblestone
setblock 380 118 183 minecraft:stone_bricks
setblock 381 118 182 minecraft:stone_bricks
setblock 381 118 183 minecraft:mossy_cobblestone
setblock 381 118 222 minecraft:stone_bricks
fill 382 118 182 383 118 182 minecraft:mossy_cobblestone
fill 382 118 222 382 119 222 minecraft:mossy_cobblestone
setblock 396 118 182 minecraft:stone_bricks
setblock 396 118 222 minecraft:stone_bricks
fill 397 118 182 397 121 182 minecraft:mossy_cobblestone
setblock 397 118 222 minecraft:mossy_cobblestone
setblock 401 118 182 minecraft:stone_bricks
setblock 411 118 182 minecraft:stone_bricks
fill 411 118 183 411 121 183 minecraft:mossy_cobblestone
fill 412 118 182 412 121 182 minecraft:mossy_cobblestone
setblock 414 118 184 minecraft:stone_bricks
setblock 415 118 183 minecraft:stone_bricks
fill 415 118 184 415 121 184 minecraft:mossy_cobblestone
setblock 415 118 188 minecraft:stone_bricks
fill 415 118 189 415 120 190 minecraft:mossy_cobblestone
setblock 416 118 182 minecraft:stone_bricks
fill 416 118 183 416 121 183 minecraft:mossy_cobblestone
setblock 416 118 187 minecraft:stone_bricks
fill 416 118 188 416 121 188 minecraft:mossy_cobblestone
setblock 416 118 192 minecraft:stone_bricks
fill 416 118 193 416 121 193 minecraft:mossy_cobblestone
setblock 416 118 207 minecraft:stone_bricks
fill 416 118 208 416 121 208 minecraft:mossy_cobblestone
setblock 416 118 222 minecraft:stone_bricks
fill 417 118 182 417 121 182 minecraft:mossy_cobblestone
setblock 417 118 186 minecraft:stone_bricks
fill 417 118 187 417 121 187 minecraft:mossy_cobblestone
setblock 417 118 191 minecraft:stone_bricks
fill 417 118 192 417 121 192 minecraft:mossy_cobblestone
setblock 417 118 196 minecraft:stone_bricks
setblock 417 118 197 minecraft:mossy_cobblestone
setblock 417 118 201 minecraft:stone_bricks
fill 417 118 202 417 120 202 minecraft:mossy_cobblestone
setblock 417 118 206 minecraft:stone_bricks
fill 417 118 207 417 121 207 minecraft:mossy_cobblestone
setblock 417 118 211 minecraft:stone_bricks
fill 417 118 212 417 121 212 minecraft:mossy_cobblestone
setblock 417 118 221 minecraft:stone_bricks
fill 417 118 222 417 121 222 minecraft:mossy_cobblestone
setblock 377 119 185 minecraft:stone_bricks
fill 377 119 186 377 122 186 minecraft:mossy_cobblestone
setblock 377 119 190 minecraft:stone_bricks
fill 377 119 191 377 122 191 minecraft:mossy_cobblestone
setblock 377 119 205 minecraft:stone_bricks
fill 377 119 206 377 122 206 minecraft:mossy_cobblestone
setblock 377 119 210 minecraft:stone_bricks
fill 377 119 211 377 122 211 minecraft:mossy_cobblestone
setblock 377 119 215 minecraft:stone_bricks
fill 377 119 216 377 122 216 minecraft:mossy_cobblestone
setblock 377 119 220 minecraft:stone_bricks
fill 377 119 221 377 121 222 minecraft:mossy_cobblestone
setblock 378 119 184 minecraft:stone_bricks
fill 378 119 185 378 122 185 minecraft:mossy_cobblestone
setblock 378 119 189 minecraft:stone_bricks
setblock 378 119 205 minecraft:mossy_cobblestone
setblock 378 119 209 minecraft:stone_bricks
fill 378 119 210 378 122 210 minecraft:mossy_cobblestone
setblock 378 119 213 minecraft:mossy_cobblestone
setblock 378 119 214 minecraft:stone_bricks
fill 378 119 222 379 119 222 minecraft:mossy_cobblestone
setblock 379 119 183 minecraft:stone_bricks
setblock 380 119 182 minecraft:stone_bricks
fill 380 119 183 380 120 183 minecraft:mossy_cobblestone
setblock 380 119 222 minecraft:stone_bricks
fill 381 119 182 382 119 182 minecraft:mossy_cobblestone
fill 381 119 222 381 122 222 minecraft:mossy_cobblestone
setblock 394 119 182 minecraft:mossy_cobblestone
setblock 395 119 182 minecraft:stone_bricks
setblock 395 119 222 minecraft:stone_bricks
fill 396 119 182 396 122 182 minecraft:mossy_cobblestone
setblock 400 119 182 minecraft:stone_bricks
setblock 410 119 182 minecraft:stone_bricks
fill 411 119 182 411 122 182 minecraft:mossy_cobblestone
setblock 412 119 184 minecraft:mossy_cobblestone
setblock 413 119 184 minecraft:stone_bricks
setblock 414 119 183 minecraft:stone_bricks
fill 414 119 184 414 122 184 minecraft:mossy_cobblestone
fill 414 119 186 414 120 186 minecraft:mossy_cobblestone
setblock 415 119 182 minecraft:stone_bricks
fill 415 119 183 415 122 183 minecraft:mossy_cobblestone
setblock 415 119 187 minecraft:stone_bricks
fill 415 119 188 415 122 188 minecraft:mossy_cobblestone
setblock 415 119 191 minecraft:mossy_cobblestone
setblock 415 119 222 minecraft:stone_bricks
fill 416 119 182 416 122 182 minecraft:mossy_cobblestone
setblock 416 119 186 minecraft:stone_bricks
fill 416 119 187 416 122 187 minecraft:mossy_cobblestone
setblock 416 119 191 minecraft:stone_bricks
fill 416 119 192 416 122 192 minecraft:mossy_cobblestone
setblock 416 119 206 minecraft:stone_bricks
fill 416 119 207 416 122 207 minecraft:mossy_cobblestone
fill 416 119 209 416 120 209 minecraft:mossy_cobblestone
fill 416 119 222 416 122 222 minecraft:mossy_cobblestone
setblock 417 119 185 minecraft:stone_bricks
fill 417 119 186 417 122 186 minecraft:mossy_cobblestone
setblock 417 119 190 minecraft:stone_bricks
fill 417 119 191 417 122 191 minecraft:mossy_cobblestone
setblock 417 119 195 minecraft:stone_bricks
fill 417 119 196 417 122 196 minecraft:mossy_cobblestone
setblock 417 119 200 minecraft:stone_bricks
setblock 417 119 201 minecraft:mossy_cobblestone
setblock 417 119 205 minecraft:stone_bricks
fill 417 119 206 417 122 206 minecraft:mossy_cobblestone
setblock 417 119 210 minecraft:stone_bricks
fill 417 119 211 417 122 211 minecraft:mossy_cobblestone
fill 417 119 213 417 119 214 minecraft:mossy_cobblestone
setblock 417 119 220 minecraft:stone_bricks
fill 417 119 221 417 122 221 minecraft:mossy_cobblestone
setblock 377 120 184 minecraft:stone_bricks
fill 377 120 185 377 123 185 minecraft:mossy_cobblestone
setblock 377 120 189 minecraft:stone_bricks
fill 377 120 190 378 122 190 minecraft:mossy_cobblestone
setblock 377 120 193 minecraft:mossy_cobblestone
setblock 377 120 204 minecraft:stone_bricks
fill 377 120 205 377 123 205 minecraft:mossy_cobblestone
setblock 377 120 209 minecraft:stone_bricks
fill 377 120 210 377 123 210 minecraft:mossy_cobblestone
setblock 377 120 214 minecraft:stone_bricks
fill 377 120 215 378 122 215 minecraft:mossy_cobblestone
setblock 377 120 219 minecraft:stone_bricks
fill 377 120 220 377 123 220 minecraft:mossy_cobblestone
setblock 378 120 183 minecraft:stone_bricks
fill 378 120 184 378 123 184 minecraft:mossy_cobblestone
setblock 378 120 188 minecraft:stone_bricks
fill 378 120 189 378 123 189 minecraft:mossy_cobblestone
setblock 378 120 208 minecraft:stone_bricks
fill 378 120 209 378 123 209 minecraft:mossy_cobblestone
setblock 378 120 213 minecraft:stone_bricks
fill 378 120 214 378 123 214 minecraft:mossy_cobblestone
setblock 378 120 222 minecraft:mossy_cobblestone
setblock 379 120 182 minecraft:stone_bricks
fill 379 120 183 379 121 183 minecraft:mossy_cobblestone
setblock 379 120 222 minecraft:stone_bricks
fill 380 120 182 381 121 182 minecraft:mossy_cobblestone
fill 380 120 222 380 123 222 minecraft:mossy_cobblestone
setblock 394 120 182 minecraft:stone_bricks
fill 395 120 182 395 123 182 minecraft:mossy_cobblestone
setblock 399 120 182 minecraft:stone_bricks
setblock 409 120 182 minecraft:stone_bricks
fill 410 120 182 410 122 183 minecraft:mossy_cobblestone
setblock 412 120 184 minecraft:stone_bricks
setblock 413 120 183 minecraft:stone_bricks
fill 413 120 184 413 123 184 minecraft:mossy_cobblestone
setblock 414 120 182 minecraft:stone_bricks
fill 414 120 183 414 123 183 minecraft:mossy_cobblestone
fill 414 120 185 414 121 185 minecraft:mossy_cobblestone
setblock 414 120 187 minecraft:stone_bricks
fill 414 120 188 414 123 188 minecraft:mossy_cobblestone
setblock 414 120 222 minecraft:stone_bricks
fill 415 120 182 415 123 182 minecraft:mossy_cobblestone
setblock 415 120 186 minecraft:stone_bricks
fill 415 120 187 415 123 187 minecraft:mossy_cobblestone
setblock 415 120 191 minecraft:stone_bricks
fill 415 120 222 415 123 222 minecraft:mossy_cobblestone
setblock 416 120 185 minecraft:stone_bricks
fill 416 120 186 416 123 186 minecraft:mossy_cobblestone
setblock 416 120 190 minecraft:stone_bricks
fill 416 120 191 416 123 191 minecraft:mossy_cobblestone
setblock 416 120 194 minecraft:mossy_cobblestone
fill 416 120 206 416 122 206 minecraft:mossy_cobblestone
setblock 416 120 210 minecraft:stone_bricks
setblock 417 120 184 minecraft:stone_bricks
fill 417 120 185 417 123 185 minecraft:mossy_cobblestone
setblock 417 120 189 minecraft:stone_bricks
fill 417 120 190 417 123 190 minecraft:mossy_cobblestone
setblock 417 120 194 minecraft:stone_bricks
fill 417 120 195 417 123 195 minecraft:mossy_cobblestone
setblock 417 120 204 minecraft:stone_bricks
fill 417 120 205 417 123 205 minecraft:mossy_cobblestone
setblock 417 120 209 minecraft:stone_bricks
fill 417 120 210 417 123 210 minecraft:mossy_cobblestone
setblock 417 120 213 minecraft:mossy_cobblestone
setblock 417 120 214 minecraft:stone_bricks
fill 417 120 215 417 122 216 minecraft:mossy_cobblestone
setblock 417 120 219 minecraft:stone_bricks
fill 417 120 220 417 123 220 minecraft:mossy_cobblestone
setblock 377 121 183 minecraft:stone_bricks
fill 377 121 184 377 124 184 minecraft:mossy_cobblestone
setblock 377 121 188 minecraft:stone_bricks
fill 377 121 189 377 124 189 minecraft:mossy_cobblestone
setblock 377 121 193 minecraft:stone_bricks
setblock 377 121 203 minecraft:stone_bricks
fill 377 121 204 377 124 204 minecraft:mossy_cobblestone
setblock 377 121 208 minecraft:stone_bricks
fill 377 121 209 377 124 209 minecraft:mossy_cobblestone
setblock 377 121 212 minecraft:mossy_cobblestone
setblock 377 121 213 minecraft:stone_bricks
fill 377 121 214 377 124 214 minecraft:mossy_cobblestone
setblock 377 121 218 minecraft:stone_bricks
fill 377 121 219 377 124 219 minecraft:mossy_cobblestone
setblock 378 121 182 minecraft:stone_bricks
fill 378 121 183 378 123 183 minecraft:mossy_cobblestone
setblock 378 121 187 minecraft:stone_bricks
fill 378 121 188 378 124 188 minecraft:mossy_cobblestone
setblock 378 121 207 minecraft:stone_bricks
fill 378 121 208 378 124 208 minecraft:mossy_cobblestone
setblock 378 121 212 minecraft:stone_bricks
fill 378 121 213 378 124 213 minecraft:mossy_cobblestone
setblock 378 121 216 minecraft:mossy_cobblestone
setblock 378 121 217 minecraft:stone_bricks
fill 378 121 218 378 124 218 minecraft:mossy_cobblestone
setblock 378 121 222 minecraft:stone_bricks
fill 379 121 182 379 124 182 minecraft:mossy_cobblestone
setblock 379 121 184 minecraft:light[level=12]
setblock 379 121 192 minecraft:light[level=12]
setblock 379 121 200 minecraft:light[level=12]
setblock 379 121 208 minecraft:light[level=12]
setblock 379 121 216 minecraft:light[level=12]
fill 379 121 222 379 124 222 minecraft:mossy_cobblestone
setblock 387 121 184 minecraft:light[level=12]
setblock 387 121 192 minecraft:light[level=12]
setblock 387 121 200 minecraft:light[level=12]
setblock 387 121 208 minecraft:light[level=12]
setblock 387 121 216 minecraft:light[level=12]
setblock 393 121 182 minecraft:stone_bricks
fill 394 121 182 394 124 182 minecraft:mossy_cobblestone
setblock 395 121 184 minecraft:light[level=12]
setblock 395 121 192 minecraft:light[level=12]
setblock 395 121 200 minecraft:light[level=12]
setblock 395 121 208 minecraft:light[level=12]
setblock 395 121 216 minecraft:light[level=12]
setblock 398 121 182 minecraft:stone_bricks
setblock 403 121 184 minecraft:light[level=12]
setblock 403 121 192 minecraft:light[level=12]
setblock 403 121 200 minecraft:light[level=12]
setblock 403 121 208 minecraft:light[level=12]
setblock 403 121 216 minecraft:light[level=12]
fill 409 121 182 409 124 182 minecraft:mossy_cobblestone
setblock 411 121 184 minecraft:stone_bricks
setblock 411 121 192 minecraft:light[level=12]
setblock 411 121 200 minecraft:light[level=12]
setblock 411 121 208 minecraft:light[level=12]
setblock 411 121 216 minecraft:light[level=12]
setblock 412 121 183 minecraft:stone_bricks
fill 412 121 184 412 124 184 minecraft:mossy_cobblestone
setblock 413 121 182 minecraft:stone_bricks
fill 413 121 183 413 124 183 minecraft:mossy_cobblestone
fill 413 121 185 413 122 185 minecraft:mossy_cobblestone
setblock 413 121 222 minecraft:stone_bricks
fill 414 121 182 414 124 182 minecraft:mossy_cobblestone
setblock 414 121 186 minecraft:stone_bricks
fill 414 121 187 414 124 187 minecraft:mossy_cobblestone
fill 414 121 189 414 121 190 minecraft:mossy_cobblestone
fill 414 121 222 414 124 222 minecraft:mossy_cobblestone
setblock 415 121 185 minecraft:stone_bricks
fill 415 121 186 415 124 186 minecraft:mossy_cobblestone
setblock 415 121 189 minecraft:mossy_cobblestone
setblock 415 121 190 minecraft:stone_bricks
fill 415 121 191 415 123 192 minecraft:mossy_cobblestone
setblock 416 121 184 minecraft:stone_bricks
fill 416 121 185 416 124 185 minecraft:mossy_cobblestone
setblock 416 121 189 minecraft:stone_bricks
fill 416 121 190 416 124 190 minecraft:mossy_cobblestone
setblock 416 121 194 minecraft:stone_bricks
setblock 416 121 209 minecraft:stone_bricks
fill 416 121 210 416 122 212 minecraft:mossy_cobblestone
setblock 417 121 183 minecraft:stone_bricks
fill 417 121 184 417 124 184 minecraft:mossy_cobblestone
setblock 417 121 188 minecraft:stone_bricks
fill 417 121 189 417 124 189 minecraft:mossy_cobblestone
setblock 417 121 193 minecraft:stone_bricks
fill 417 121 194 417 124 194 minecraft:mossy_cobblestone
setblock 417 121 203 minecraft:stone_bricks
fill 417 121 204 417 123 204 minecraft:mossy_cobblestone
setblock 417 121 208 minecraft:stone_bricks
fill 417 121 209 417 124 209 minecraft:mossy_cobblestone
setblock 417 121 213 minecraft:stone_bricks
fill 417 121 214 417 124 214 minecraft:mossy_cobblestone
setblock 417 121 217 minecraft:mossy_cobblestone
setblock 417 121 218 minecraft:stone_bricks
fill 417 121 219 417 124 219 minecraft:mossy_cobblestone
setblock 377 122 182 minecraft:stone_bricks
fill 377 122 183 377 125 183 minecraft:mossy_cobblestone
setblock 377 122 187 minecraft:stone_bricks
fill 377 122 188 377 125 188 minecraft:mossy_cobblestone
setblock 377 122 192 minecraft:stone_bricks
fill 377 122 193 377 124 194 minecraft:mossy_cobblestone
fill 377 122 203 377 123 203 minecraft:mossy_cobblestone
setblock 377 122 207 minecraft:stone_bricks
fill 377 122 208 377 125 208 minecraft:mossy_cobblestone
setblock 377 122 212 minecraft:stone_bricks
fill 377 122 213 377 125 213 minecraft:mossy_cobblestone
setblock 377 122 217 minecraft:stone_bricks
fill 377 122 218 377 125 218 minecraft:mossy_cobblestone
setblock 377 122 221 minecraft:mossy_cobblestone
setblock 377 122 222 minecraft:stone_bricks
fill 378 122 182 378 125 182 minecraft:mossy_cobblestone
setblock 378 122 186 minecraft:stone_bricks
fill 378 122 187 378 125 187 minecraft:mossy_cobblestone
setblock 378 122 206 minecraft:stone_bricks
fill 378 122 207 378 125 207 minecraft:mossy_cobblestone
setblock 378 122 211 minecraft:stone_bricks
fill 378 122 212 379 124 212 minecraft:mossy_cobblestone
setblock 378 122 216 minecraft:stone_bricks
fill 378 122 217 378 125 217 minecraft:mossy_cobblestone
fill 378 122 219 378 122 220 minecraft:mossy_cobblestone
setblock 378 122 221 minecraft:stone_bricks
fill 378 122 222 378 125 222 minecraft:mossy_cobblestone
setblock 379 122 210 minecraft:stone_bricks
fill 379 122 211 379 125 211 minecraft:mossy_cobblestone
fill 379 122 213 379 123 213 minecraft:mossy_cobblestone
fill 380 122 182 380 123 182 minecraft:mossy_cobblestone
setblock 392 122 182 minecraft:stone_bricks
fill 393 122 182 393 125 182 minecraft:mossy_cobblestone
fill 393 122 222 394 124 222 minecraft:mossy_cobblestone
setblock 397 122 182 minecraft:stone_bricks
setblock 398 122 182 minecraft:mossy_cobblestone
fill 408 122 182 408 125 182 minecraft:mossy_cobblestone
fill 409 122 183 409 123 183 minecraft:mossy_cobblestone
setblock 411 122 183 minecraft:stone_bricks
fill 411 122 184 411 125 184 minecraft:mossy_cobblestone
setblock 412 122 182 minecraft:stone_bricks
fill 412 122 183 412 125 183 minecraft:mossy_cobblestone
fill 412 122 185 412 123 185 minecraft:mossy_cobblestone
setblock 412 122 222 minecraft:stone_bricks
fill 413 122 182 413 125 182 minecraft:mossy_cobblestone
fill 413 122 222 413 125 222 minecraft:mossy_cobblestone
setblock 414 122 185 minecraft:stone_bricks
fill 414 122 186 414 125 186 minecraft:mossy_cobblestone
setblock 414 122 189 minecraft:mossy_cobblestone
setblock 414 122 190 minecraft:stone_bricks
fill 414 122 191 414 125 191 minecraft:mossy_cobblestone
setblock 415 122 184 minecraft:stone_bricks
fill 415 122 185 415 125 185 minecraft:mossy_cobblestone
setblock 415 122 189 minecraft:stone_bricks
fill 415 122 190 415 125 190 minecraft:mossy_cobblestone
setblock 415 122 193 minecraft:mossy_cobblestone
setblock 416 122 183 minecraft:stone_bricks
fill 416 122 184 416 125 184 minecraft:mossy_cobblestone
setblock 416 122 188 minecraft:stone_bricks
fill 416 122 189 416 125 189 minecraft:mossy_cobblestone
setblock 416 122 193 minecraft:stone_bricks
fill 416 122 194 416 124 195 minecraft:mossy_cobblestone
setblock 416 122 208 minecraft:stone_bricks
fill 416 122 209 416 125 209 minecraft:mossy_cobblestone
setblock 416 122 213 minecraft:stone_bricks
fill 416 122 214 416 124 215 minecraft:mossy_cobblestone
setblock 417 122 182 minecraft:stone_bricks
fill 417 122 183 417 125 183 minecraft:mossy_cobblestone
setblock 417 122 187 minecraft:stone_bricks
fill 417 122 188 417 125 188 minecraft:mossy_cobblestone
setblock 417 122 192 minecraft:stone_bricks
fill 417 122 193 417 125 193 minecraft:mossy_cobblestone
setblock 417 122 197 minecraft:stone_bricks
setblock 417 122 203 minecraft:mossy_cobblestone
setblock 417 122 207 minecraft:stone_bricks
fill 417 122 208 417 125 208 minecraft:mossy_cobblestone
setblock 417 122 212 minecraft:stone_bricks
fill 417 122 213 417 125 213 minecraft:mossy_cobblestone
setblock 417 122 217 minecraft:stone_bricks
fill 417 122 218 417 125 218 minecraft:mossy_cobblestone
setblock 417 122 222 minecraft:stone_bricks
fill 377 123 182 377 126 182 minecraft:mossy_cobblestone
setblock 377 123 186 minecraft:stone_bricks
fill 377 123 187 377 126 187 minecraft:mossy_cobblestone
setblock 377 123 190 minecraft:mossy_cobblestone
setblock 377 123 191 minecraft:stone_bricks
fill 377 123 192 377 126 192 minecraft:mossy_cobblestone
setblock 377 123 195 minecraft:mossy_cobblestone
setblock 377 123 206 minecraft:stone_bricks
fill 377 123 207 377 126 207 minecraft:mossy_cobblestone
setblock 377 123 211 minecraft:stone_bricks
fill 377 123 212 377 126 212 minecraft:mossy_cobblestone
setblock 377 123 215 minecraft:mossy_cobblestone
setblock 377 123 216 minecraft:stone_bricks
fill 377 123 217 377 126 217 minecraft:mossy_cobblestone
setblock 377 123 221 minecraft:stone_bricks
fill 377 123 222 377 126 222 minecraft:mossy_cobblestone
setblock 378 123 185 minecraft:stone_bricks
fill 378 123 186 378 124 186 minecraft:mossy_cobblestone
setblock 378 123 190 minecraft:stone_bricks
fill 378 123 191 378 125 191 minecraft:mossy_cobblestone
setblock 378 123 206 minecraft:mossy_cobblestone
setblock 378 123 210 minecraft:stone_bricks
fill 378 123 211 378 126 211 minecraft:mossy_cobblestone
setblock 378 123 215 minecraft:stone_bricks
fill 378 123 216 378 126 216 minecraft:mossy_cobblestone
setblock 378 123 219 minecraft:mossy_cobblestone
setblock 378 123 220 minecraft:stone_bricks
fill 378 123 221 378 126 221 minecraft:mossy_cobblestone
setblock 379 123 209 minecraft:stone_bricks
fill 379 123 210 379 126 210 minecraft:mossy_cobblestone
setblock 379 123 214 minecraft:stone_bricks
fill 392 123 182 392 126 182 minecraft:mossy_cobblestone
fill 392 123 222 392 126 222 minecraft:mossy_cobblestone
setblock 396 123 182 minecraft:stone_bricks
fill 397 123 182 397 124 182 minecraft:mossy_cobblestone
fill 407 123 182 407 126 182 minecraft:mossy_cobblestone
setblock 410 123 182 minecraft:mossy_cobblestone
setblock 410 123 183 minecraft:stone_bricks
fill 410 123 184 410 126 184 minecraft:mossy_cobblestone
setblock 411 123 182 minecraft:stone_bricks
fill 411 123 183 411 126 183 minecraft:mossy_cobblestone
setblock 411 123 222 minecraft:stone_bricks
fill 412 123 182 412 126 182 minecraft:mossy_cobblestone
fill 412 123 222 412 126 222 minecraft:mossy_cobblestone
setblock 413 123 185 minecraft:stone_bricks
setblock 414 123 184 minecraft:stone_bricks
fill 414 123 185 414 126 185 minecraft:mossy_cobblestone
setblock 414 123 189 minecraft:stone_bricks
fill 414 123 190 414 126 190 minecraft:mossy_cobblestone
fill 414 123 192 414 124 192 minecraft:mossy_cobblestone
setblock 415 123 183 minecraft:stone_bricks
fill 415 123 184 415 126 184 minecraft:mossy_cobblestone
setblock 415 123 188 minecraft:stone_bricks
fill 415 123 189 415 126 189 minecraft:mossy_cobblestone
setblock 415 123 193 minecraft:stone_bricks
fill 415 123 194 415 126 194 minecraft:mossy_cobblestone
setblock 416 123 182 minecraft:stone_bricks
fill 416 123 183 416 126 183 minecraft:mossy_cobblestone
setblock 416 123 187 minecraft:stone_bricks
fill 416 123 188 416 126 188 minecraft:mossy_cobblestone
setblock 416 123 192 minecraft:stone_bricks
fill 416 123 193 416 126 193 minecraft:mossy_cobblestone
setblock 416 123 196 minecraft:mossy_cobblestone
setblock 416 123 207 minecraft:stone_bricks
fill 416 123 208 416 126 208 minecraft:mossy_cobblestone
fill 416 123 210 416 123 211 minecraft:mossy_cobblestone
setblock 416 123 212 minecraft:stone_bricks
fill 416 123 213 416 126 213 minecraft:mossy_cobblestone
setblock 416 123 216 minecraft:mossy_cobblestone
setblock 416 123 217 minecraft:stone_bricks
fill 416 123 218 416 126 218 minecraft:mossy_cobblestone
setblock 416 123 221 minecraft:mossy_cobblestone
setblock 416 123 222 minecraft:stone_bricks
fill 417 123 182 417 126 182 minecraft:mossy_cobblestone
setblock 417 123 186 minecraft:stone_bricks
fill 417 123 187 417 126 187 minecraft:mossy_cobblestone
setblock 417 123 191 minecraft:stone_bricks
fill 417 123 192 417 126 192 minecraft:mossy_cobblestone
setblock 417 123 196 minecraft:stone_bricks
fill 417 123 197 417 126 197 minecraft:mossy_cobblestone
setblock 417 123 206 minecraft:stone_bricks
fill 417 123 207 417 126 207 minecraft:mossy_cobblestone
setblock 417 123 211 minecraft:stone_bricks
fill 417 123 212 417 126 212 minecraft:mossy_cobblestone
setblock 417 123 215 minecraft:mossy_cobblestone
setblock 417 123 216 minecraft:stone_bricks
fill 417 123 217 417 126 217 minecraft:mossy_cobblestone
setblock 417 123 221 minecraft:stone_bricks
fill 417 123 222 417 126 222 minecraft:mossy_cobblestone
setblock 377 124 185 minecraft:stone_bricks
fill 377 124 186 377 127 186 minecraft:mossy_cobblestone
setblock 377 124 190 minecraft:stone_bricks
fill 377 124 191 377 127 191 minecraft:mossy_cobblestone
setblock 377 124 195 minecraft:stone_bricks
fill 377 124 196 377 127 196 minecraft:mossy_cobblestone
setblock 377 124 205 minecraft:stone_bricks
fill 377 124 206 377 127 206 minecraft:mossy_cobblestone
setblock 377 124 210 minecraft:stone_bricks
fill 377 124 211 377 127 211 minecraft:mossy_cobblestone
setblock 377 124 215 minecraft:stone_bricks
fill 377 124 216 377 127 216 minecraft:mossy_cobblestone
setblock 377 124 220 minecraft:stone_bricks
fill 377 124 221 377 127 221 minecraft:mossy_cobblestone
setblock 378 124 184 minecraft:stone_bricks
setblock 378 124 185 minecraft:mossy_cobblestone
setblock 378 124 189 minecraft:stone_bricks
fill 378 124 190 378 126 190 minecraft:mossy_cobblestone
setblock 378 124 209 minecraft:stone_bricks
fill 378 124 210 378 127 210 minecraft:mossy_cobblestone
setblock 378 124 214 minecraft:stone_bricks
fill 378 124 215 379 126 215 minecraft:mossy_cobblestone
setblock 378 124 219 minecraft:stone_bricks
fill 378 124 220 378 127 220 minecraft:mossy_cobblestone
setblock 379 124 209 minecraft:mossy_cobblestone
setblock 379 124 213 minecraft:stone_bricks
fill 379 124 214 379 127 214 minecraft:mossy_cobblestone
setblock 380 124 222 minecraft:stone_bricks
setblock 390 124 222 minecraft:stone_bricks
fill 391 124 182 391 127 182 minecraft:mossy_cobblestone
fill 391 124 222 391 127 222 minecraft:mossy_cobblestone
setblock 395 124 182 minecraft:stone_bricks
setblock 395 124 222 minecraft:stone_bricks
fill 396 124 182 396 125 182 minecraft:mossy_cobblestone
setblock 408 124 183 minecraft:mossy_cobblestone
setblock 409 124 183 minecraft:stone_bricks
setblock 410 124 182 minecraft:stone_bricks
fill 410 124 183 410 127 183 minecraft:mossy_cobblestone
setblock 410 124 222 minecraft:stone_bricks
fill 411 124 182 411 127 182 minecraft:mossy_cobblestone
setblock 411 124 185 minecraft:mossy_cobblestone
fill 411 124 222 411 127 222 minecraft:mossy_cobblestone
setblock 412 124 185 minecraft:stone_bricks
setblock 413 124 184 minecraft:stone_bricks
fill 413 124 185 413 126 185 minecraft:mossy_cobblestone
setblock 413 124 188 minecraft:mossy_cobblestone
setblock 413 124 189 minecraft:stone_bricks
fill 413 124 221 415 124 221 minecraft:mossy_cobblestone
setblock 414 124 183 minecraft:stone_bricks
fill 414 124 184 414 127 184 minecraft:mossy_cobblestone
setblock 414 124 188 minecraft:stone_bricks
fill 414 124 189 414 127 189 minecraft:mossy_cobblestone
setblock 414 124 193 minecraft:stone_bricks
setblock 415 124 182 minecraft:stone_bricks
fill 415 124 183 415 127 183 minecraft:mossy_cobblestone
setblock 415 124 187 minecraft:stone_bricks
fill 415 124 188 415 127 188 minecraft:mossy_cobblestone
setblock 415 124 191 minecraft:mossy_cobblestone
setblock 415 124 192 minecraft:stone_bricks
fill 415 124 193 415 127 193 minecraft:mossy_cobblestone
fill 415 124 210 415 124 211 minecraft:mossy_cobblestone
setblock 415 124 212 minecraft:stone_bricks
fill 415 124 213 415 126 214 minecraft:mossy_cobblestone
setblock 415 124 222 minecraft:stone_bricks
fill 416 124 182 416 127 182 minecraft:mossy_cobblestone
setblock 416 124 186 minecraft:stone_bricks
fill 416 124 187 416 127 187 minecraft:mossy_cobblestone
setblock 416 124 191 minecraft:stone_bricks
fill 416 124 192 416 127 192 minecraft:mossy_cobblestone
setblock 416 124 196 minecraft:stone_bricks
setblock 416 124 207 minecraft:mossy_cobblestone
setblock 416 124 210 minecraft:mossy_cobblestone
setblock 416 124 211 minecraft:stone_bricks
fill 416 124 212 416 127 212 minecraft:mossy_cobblestone
setblock 416 124 216 minecraft:stone_bricks
fill 416 124 217 416 127 217 minecraft:mossy_cobblestone
fill 416 124 219 416 124 220 minecraft:mossy_cobblestone
setblock 416 124 221 minecraft:stone_bricks
fill 416 124 222 416 127 222 minecraft:mossy_cobblestone
setblock 417 124 185 minecraft:stone_bricks
fill 417 124 186 417 127 186 minecraft:mossy_cobblestone
setblock 417 124 190 minecraft:stone_bricks
fill 417 124 191 417 127 191 minecraft:mossy_cobblestone
setblock 417 124 195 minecraft:stone_bricks
fill 417 124 196 417 127 196 minecraft:mossy_cobblestone
fill 417 124 198 417 125 198 minecraft:mossy_cobblestone
setblock 417 124 205 minecraft:stone_bricks
fill 417 124 206 417 126 206 minecraft:mossy_cobblestone
setblock 417 124 210 minecraft:stone_bricks
fill 417 124 211 417 127 211 minecraft:mossy_cobblestone
setblock 417 124 215 minecraft:stone_bricks
fill 417 124 216 417 127 216 minecraft:mossy_cobblestone
setblock 417 124 220 minecraft:stone_bricks
fill 417 124 221 417 127 221 minecraft:mossy_cobblestone
setblock 377 125 184 minecraft:stone_bricks
fill 377 125 185 377 127 185 minecraft:mossy_cobblestone
setblock 377 125 189 minecraft:stone_bricks
fill 377 125 190 377 128 190 minecraft:mossy_cobblestone
setblock 377 125 193 minecraft:mossy_cobblestone
setblock 377 125 194 minecraft:stone_bricks
fill 377 125 195 377 128 195 minecraft:mossy_cobblestone
setblock 377 125 204 minecraft:stone_bricks
fill 377 125 205 377 126 205 minecraft:mossy_cobblestone
setblock 377 125 209 minecraft:stone_bricks
fill 377 125 210 377 128 210 minecraft:mossy_cobblestone
setblock 377 125 214 minecraft:stone_bricks
fill 377 125 215 377 128 215 minecraft:mossy_cobblestone
setblock 377 125 219 minecraft:stone_bricks
fill 377 125 220 377 128 220 minecraft:mossy_cobblestone
setblock 378 125 188 minecraft:stone_bricks
setblock 378 125 189 minecraft:mossy_cobblestone
setblock 378 125 208 minecraft:stone_bricks
fill 378 125 209 378 128 209 minecraft:mossy_cobblestone
setblock 378 125 212 minecraft:mossy_cobblestone
setblock 378 125 213 minecraft:stone_bricks
fill 378 125 214 378 128 214 minecraft:mossy_cobblestone
setblock 378 125 218 minecraft:stone_bricks
fill 378 125 219 378 128 219 minecraft:mossy_cobblestone
setblock 379 125 212 minecraft:stone_bricks
fill 379 125 213 379 128 213 minecraft:mossy_cobblestone
setblock 379 125 216 minecraft:mossy_cobblestone
setblock 379 125 222 minecraft:stone_bricks
fill 380 125 222 380 126 222 minecraft:mossy_cobblestone
setblock 389 125 222 minecraft:stone_bricks
fill 390 125 222 390 128 222 minecraft:mossy_cobblestone
setblock 393 125 222 minecraft:mossy_cobblestone
setblock 394 125 182 minecraft:stone_bricks
setblock 394 125 222 minecraft:stone_bricks
fill 395 125 182 395 126 182 minecraft:mossy_cobblestone
setblock 395 125 222 minecraft:mossy_cobblestone
fill 406 125 182 406 127 182 minecraft:mossy_cobblestone
setblock 408 125 183 minecraft:stone_bricks
setblock 409 125 182 minecraft:stone_bricks
fill 409 125 183 409 127 184 minecraft:mossy_cobblestone
fill 410 125 182 410 128 182 minecraft:mossy_cobblestone
fill 410 125 222 410 128 222 minecraft:mossy_cobblestone
setblock 411 125 185 minecraft:stone_bricks
setblock 412 125 184 minecraft:stone_bricks
fill 412 125 185 412 126 185 minecraft:mossy_cobblestone
fill 412 125 221 414 125 221 minecraft:mossy_cobblestone
setblock 413 125 183 minecraft:stone_bricks
fill 413 125 184 413 128 184 minecraft:mossy_cobblestone
setblock 413 125 188 minecraft:stone_bricks
fill 413 125 189 413 125 190 minecraft:mossy_cobblestone
setblock 414 125 182 minecraft:stone_bricks
fill 414 125 183 414 128 183 minecraft:mossy_cobblestone
setblock 414 125 187 minecraft:stone_bricks
fill 414 125 188 414 127 188 minecraft:mossy_cobblestone
setblock 414 125 192 minecraft:stone_bricks
fill 414 125 193 414 127 193 minecraft:mossy_cobblestone
setblock 414 125 222 minecraft:stone_bricks
fill 415 125 182 415 128 182 minecraft:mossy_cobblestone
setblock 415 125 186 minecraft:stone_bricks
fill 415 125 187 415 128 187 minecraft:mossy_cobblestone
setblock 415 125 191 minecraft:stone_bricks
fill 415 125 192 415 128 192 minecraft:mossy_cobblestone
setblock 415 125 195 minecraft:mossy_cobblestone
setblock 415 125 210 minecraft:mossy_cobblestone
setblock 415 125 211 minecraft:stone_bricks
fill 415 125 212 415 127 212 minecraft:mossy_cobblestone
setblock 415 125 215 minecraft:mossy_cobblestone
setblock 415 125 216 minecraft:stone_bricks
setblock 415 125 221 minecraft:stone_bricks
fill 415 125 222 415 128 222 minecraft:mossy_cobblestone
setblock 416 125 185 minecraft:stone_bricks
fill 416 125 186 416 128 186 minecraft:mossy_cobblestone
setblock 416 125 190 minecraft:stone_bricks
fill 416 125 191 416 128 191 minecraft:mossy_cobblestone
setblock 416 125 194 minecraft:mossy_cobblestone
setblock 416 125 195 minecraft:stone_bricks
fill 416 125 196 416 128 196 minecraft:mossy_cobblestone
setblock 416 125 210 minecraft:stone_bricks
fill 416 125 211 416 128 211 minecraft:mossy_cobblestone
setblock 416 125 214 minecraft:mossy_cobblestone
setblock 416 125 215 minecraft:stone_bricks
fill 416 125 216 416 128 216 minecraft:mossy_cobblestone
setblock 416 125 219 minecraft:mossy_cobblestone
setblock 416 125 220 minecraft:stone_bricks
fill 416 125 221 416 128 221 minecraft:mossy_cobblestone
setblock 417 125 184 minecraft:stone_bricks
fill 417 125 185 417 128 185 minecraft:mossy_cobblestone
setblock 417 125 189 minecraft:stone_bricks
fill 417 125 190 417 128 190 minecraft:mossy_cobblestone
setblock 417 125 194 minecraft:stone_bricks
fill 417 125 195 417 128 195 minecraft:mossy_cobblestone
setblock 417 125 205 minecraft:mossy_cobblestone
setblock 417 125 209 minecraft:stone_bricks
fill 417 125 210 417 128 210 minecraft:mossy_cobblestone
setblock 417 125 214 minecraft:stone_bricks
fill 417 125 215 417 128 215 minecraft:mossy_cobblestone
setblock 417 125 219 minecraft:stone_bricks
fill 417 125 220 417 128 220 minecraft:mossy_cobblestone
setblock 377 126 183 minecraft:stone_bricks
fill 377 126 184 377 127 184 minecraft:mossy_cobblestone
setblock 377 126 188 minecraft:stone_bricks
fill 377 126 189 377 128 189 minecraft:mossy_cobblestone
setblock 377 126 193 minecraft:stone_bricks
fill 377 126 194 377 129 194 minecraft:mossy_cobblestone
setblock 377 126 208 minecraft:stone_bricks
fill 377 126 209 377 129 209 minecraft:mossy_cobblestone
setblock 377 126 213 minecraft:stone_bricks
fill 377 126 214 377 129 214 minecraft:mossy_cobblestone
setblock 377 126 218 minecraft:stone_bricks
fill 377 126 219 377 129 219 minecraft:mossy_cobblestone
fill 378 126 208 378 127 208 minecraft:mossy_cobblestone
setblock 378 126 212 minecraft:stone_bricks
fill 378 126 213 378 129 213 minecraft:mossy_cobblestone
setblock 378 126 217 minecraft:stone_bricks
fill 378 126 218 378 129 218 minecraft:mossy_cobblestone
setblock 378 126 222 minecraft:stone_bricks
setblock 379 126 211 minecraft:stone_bricks
fill 379 126 212 379 127 212 minecraft:mossy_cobblestone
setblock 379 126 216 minecraft:stone_bricks
setblock 379 126 217 minecraft:mossy_cobblestone
fill 379 126 222 379 128 222 minecraft:mossy_cobblestone
setblock 388 126 222 minecraft:stone_bricks
fill 389 126 222 389 129 222 minecraft:mossy_cobblestone
setblock 393 126 182 minecraft:stone_bricks
setblock 393 126 222 minecraft:stone_bricks
fill 394 126 182 394 127 182 minecraft:mossy_cobblestone
fill 394 126 222 394 127 222 minecraft:mossy_cobblestone
setblock 408 126 182 minecraft:stone_bricks
fill 408 126 183 408 129 183 minecraft:mossy_cobblestone
fill 409 126 182 409 129 182 minecraft:mossy_cobblestone
fill 409 126 222 409 129 222 minecraft:mossy_cobblestone
setblock 411 126 184 minecraft:stone_bricks
setblock 411 126 185 minecraft:mossy_cobblestone
fill 411 126 221 413 126 221 minecraft:mossy_cobblestone
setblock 412 126 183 minecraft:stone_bricks
fill 412 126 184 412 128 184 minecraft:mossy_cobblestone
setblock 413 126 182 minecraft:stone_bricks
fill 413 126 183 413 129 183 minecraft:mossy_cobblestone
setblock 413 126 190 minecraft:mossy_cobblestone
setblock 413 126 222 minecraft:stone_bricks
fill 414 126 182 414 129 182 minecraft:mossy_cobblestone
setblock 414 126 186 minecraft:stone_bricks
fill 414 126 187 414 127 187 minecraft:mossy_cobblestone
setblock 414 126 191 minecraft:stone_bricks
fill 414 126 192 414 127 192 minecraft:mossy_cobblestone
setblock 414 126 221 minecraft:stone_bricks
fill 414 126 222 414 129 222 minecraft:mossy_cobblestone
setblock 415 126 185 minecraft:stone_bricks
fill 415 126 186 415 127 186 minecraft:mossy_cobblestone
setblock 415 126 190 minecraft:stone_bricks
fill 415 126 191 415 129 191 minecraft:mossy_cobblestone
setblock 415 126 195 minecraft:stone_bricks
setblock 415 126 211 minecraft:mossy_cobblestone
setblock 415 126 215 minecraft:stone_bricks
fill 415 126 216 415 127 218 minecraft:mossy_cobblestone
fill 415 126 221 415 129 221 minecraft:mossy_cobblestone
setblock 416 126 184 minecraft:stone_bricks
fill 416 126 185 416 128 185 minecraft:mossy_cobblestone
setblock 416 126 189 minecraft:stone_bricks
fill 416 126 190 416 129 190 minecraft:mossy_cobblestone
setblock 416 126 194 minecraft:stone_bricks
fill 416 126 195 416 129 195 minecraft:mossy_cobblestone
setblock 416 126 209 minecraft:stone_bricks
fill 416 126 210 416 127 210 minecraft:mossy_cobblestone
setblock 416 126 214 minecraft:stone_bricks
fill 416 126 215 416 129 215 minecraft:mossy_cobblestone
setblock 416 126 219 minecraft:stone_bricks
fill 416 126 220 416 129 220 minecraft:mossy_cobblestone
setblock 417 126 183 minecraft:stone_bricks
fill 417 126 184 417 129 184 minecraft:mossy_cobblestone
setblock 417 126 188 minecraft:stone_bricks
fill 417 126 189 417 129 189 minecraft:mossy_cobblestone
setblock 417 126 193 minecraft:stone_bricks
fill 417 126 194 417 129 194 minecraft:mossy_cobblestone
setblock 417 126 198 minecraft:stone_bricks
setblock 417 126 208 minecraft:stone_bricks
fill 417 126 209 417 128 209 minecraft:mossy_cobblestone
setblock 417 126 213 minecraft:stone_bricks
fill 417 126 214 417 129 214 minecraft:mossy_cobblestone
setblock 417 126 218 minecraft:stone_bricks
fill 417 126 219 417 129 219 minecraft:mossy_cobblestone
setblock 377 127 182 minecraft:stone_bricks
setblock 377 127 183 minecraft:mossy_cobblestone
setblock 377 127 187 minecraft:stone_bricks
fill 377 127 188 377 128 188 minecraft:mossy_cobblestone
setblock 377 127 192 minecraft:stone_bricks
fill 377 127 193 377 129 193 minecraft:mossy_cobblestone
setblock 377 127 207 minecraft:stone_bricks
fill 377 127 208 377 129 208 minecraft:mossy_cobblestone
setblock 377 127 212 minecraft:stone_bricks
fill 377 127 213 377 130 213 minecraft:mossy_cobblestone
setblock 377 127 217 minecraft:stone_bricks
fill 377 127 218 377 130 218 minecraft:mossy_cobblestone
setblock 377 127 222 minecraft:stone_bricks
setblock 378 127 211 minecraft:stone_bricks
fill 378 127 212 378 130 212 minecraft:mossy_cobblestone
setblock 378 127 215 minecraft:mossy_cobblestone
setblock 378 127 216 minecraft:stone_bricks
fill 378 127 217 378 130 217 minecraft:mossy_cobblestone
fill 378 127 222 378 129 222 minecraft:mossy_cobblestone
setblock 379 127 211 minecraft:mossy_cobblestone
setblock 379 127 215 minecraft:stone_bricks
fill 379 127 216 379 128 216 minecraft:mossy_cobblestone
setblock 387 127 222 minecraft:stone_bricks
fill 388 127 222 388 130 222 minecraft:mossy_cobblestone
setblock 392 127 182 minecraft:stone_bricks
setblock 392 127 222 minecraft:stone_bricks
setblock 393 127 182 minecraft:mossy_cobblestone
fill 393 127 222 393 129 222 minecraft:mossy_cobblestone
setblock 407 127 182 minecraft:stone_bricks
fill 408 127 182 408 130 182 minecraft:mossy_cobblestone
fill 408 127 222 408 130 222 minecraft:mossy_cobblestone
setblock 410 127 184 minecraft:stone_bricks
fill 410 127 221 412 127 221 minecraft:mossy_cobblestone
setblock 411 127 183 minecraft:stone_bricks
fill 411 127 184 411 128 184 minecraft:mossy_cobblestone
setblock 412 127 182 minecraft:stone_bricks
fill 412 127 183 412 130 183 minecraft:mossy_cobblestone
setblock 412 127 222 minecraft:stone_bricks
fill 413 127 182 413 130 182 minecraft:mossy_cobblestone
setblock 413 127 221 minecraft:stone_bricks
fill 413 127 222 413 130 222 minecraft:mossy_cobblestone
setblock 414 127 190 minecraft:stone_bricks
fill 414 127 191 414 128 191 minecraft:mossy_cobblestone
fill 414 127 221 414 130 221 minecraft:mossy_cobblestone
setblock 415 127 184 minecraft:stone_bricks
setblock 415 127 185 minecraft:mossy_cobblestone
setblock 415 127 189 minecraft:stone_bricks
fill 415 127 190 415 128 190 minecraft:mossy_cobblestone
setblock 415 127 194 minecraft:stone_bricks
setblock 415 127 195 minecraft:mossy_cobblestone
setblock 415 127 213 minecraft:mossy_cobblestone
setblock 415 127 214 minecraft:stone_bricks
fill 415 127 215 415 129 215 minecraft:mossy_cobblestone
setblock 416 127 183 minecraft:stone_bricks
fill 416 127 184 416 128 184 minecraft:mossy_cobblestone
setblock 416 127 188 minecraft:stone_bricks
fill 416 127 189 416 129 189 minecraft:mossy_cobblestone
setblock 416 127 193 minecraft:stone_bricks
fill 416 127 194 416 129 194 minecraft:mossy_cobblestone
setblock 416 127 213 minecraft:stone_bricks
fill 416 127 214 416 130 214 minecraft:mossy_cobblestone
setblock 416 127 218 minecraft:stone_bricks
fill 416 127 219 416 130 219 minecraft:mossy_cobblestone
setblock 417 127 182 minecraft:stone_bricks
fill 417 127 183 417 129 183 minecraft:mossy_cobblestone
setblock 417 127 187 minecraft:stone_bricks
fill 417 127 188 417 129 188 minecraft:mossy_cobblestone
setblock 417 127 192 minecraft:stone_bricks
fill 417 127 193 417 130 193 minecraft:mossy_cobblestone
setblock 417 127 197 minecraft:stone_bricks
setblock 417 127 208 minecraft:mossy_cobblestone
setblock 417 127 212 minecraft:stone_bricks
fill 417 127 213 417 130 213 minecraft:mossy_cobblestone
setblock 417 127 217 minecraft:stone_bricks
fill 417 127 218 417 130 218 minecraft:mossy_cobblestone
setblock 417 127 222 minecraft:stone_bricks
setblock 377 128 191 minecraft:stone_bricks
fill 377 128 192 377 129 192 minecraft:mossy_cobblestone
setblock 377 128 196 minecraft:stone_bricks
setblock 377 128 207 minecraft:mossy_cobblestone
setblock 377 128 211 minecraft:stone_bricks
fill 377 128 212 377 131 212 minecraft:mossy_cobblestone
setblock 377 128 216 minecraft:stone_bricks
fill 377 128 217 377 131 217 minecraft:mossy_cobblestone
setblock 377 128 221 minecraft:stone_bricks
fill 377 128 222 377 131 222 minecraft:mossy_cobblestone
setblock 378 128 210 minecraft:stone_bricks
fill 378 128 211 378 129 211 minecraft:mossy_cobblestone
setblock 378 128 215 minecraft:stone_bricks
fill 378 128 216 378 131 216 minecraft:mossy_cobblestone
setblock 378 128 220 minecraft:stone_bricks
setblock 379 128 214 minecraft:stone_bricks
setblock 379 128 215 minecraft:mossy_cobblestone
fill 387 128 222 387 131 222 minecraft:mossy_cobblestone
setblock 391 128 222 minecraft:stone_bricks
fill 392 128 222 392 130 222 minecraft:mossy_cobblestone
setblock 406 128 182 minecraft:stone_bricks
fill 407 128 182 407 131 182 minecraft:mossy_cobblestone
fill 407 128 222 407 131 222 minecraft:mossy_cobblestone
setblock 409 128 183 minecraft:mossy_cobblestone
fill 409 128 221 411 128 221 minecraft:mossy_cobblestone
setblock 410 128 183 minecraft:stone_bricks
setblock 410 128 184 minecraft:mossy_cobblestone
setblock 411 128 182 minecraft:stone_bricks
fill 411 128 183 411 131 183 minecraft:mossy_cobblestone
setblock 411 128 222 minecraft:stone_bricks
fill 412 128 182 412 131 182 minecraft:mossy_cobblestone
setblock 412 128 221 minecraft:stone_bricks
fill 412 128 222 412 131 222 minecraft:mossy_cobblestone
setblock 413 128 220 minecraft:stone_bricks
fill 413 128 221 413 131 221 minecraft:mossy_cobblestone
setblock 414 128 190 minecraft:mossy_cobblestone
setblock 415 128 183 minecraft:stone_bricks
setblock 415 128 188 minecraft:stone_bricks
setblock 415 128 189 minecraft:mossy_cobblestone
setblock 415 128 193 minecraft:stone_bricks
setblock 415 128 194 minecraft:mossy_cobblestone
setblock 415 128 213 minecraft:stone_bricks
setblock 415 128 214 minecraft:mossy_cobblestone
fill 415 128 216 415 128 217 minecraft:mossy_cobblestone
setblock 415 128 218 minecraft:stone_bricks
setblock 415 128 219 minecraft:mossy_cobblestone
setblock 416 128 182 minecraft:stone_bricks
setblock 416 128 183 minecraft:mossy_cobblestone
setblock 416 128 187 minecraft:stone_bricks
fill 416 128 188 416 129 188 minecraft:mossy_cobblestone
setblock 416 128 192 minecraft:stone_bricks
fill 416 128 193 416 129 193 minecraft:mossy_cobblestone
setblock 416 128 212 minecraft:stone_bricks
fill 416 128 213 416 130 213 minecraft:mossy_cobblestone
setblock 416 128 217 minecraft:stone_bricks
fill 416 128 218 416 131 218 minecraft:mossy_cobblestone
setblock 416 128 222 minecraft:stone_bricks
fill 417 128 182 417 129 182 minecraft:mossy_cobblestone
setblock 417 128 186 minecraft:stone_bricks
fill 417 128 187 417 129 187 minecraft:mossy_cobblestone
setblock 417 128 191 minecraft:stone_bricks
fill 417 128 192 417 130 192 minecraft:mossy_cobblestone
setblock 417 128 196 minecraft:stone_bricks
setblock 417 128 197 minecraft:mossy_cobblestone
setblock 417 128 211 minecraft:stone_bricks
fill 417 128 212 417 130 212 minecraft:mossy_cobblestone
setblock 417 128 216 minecraft:stone_bricks
fill 417 128 217 417 131 217 minecraft:mossy_cobblestone
setblock 417 128 221 minecraft:stone_bricks
fill 417 128 222 417 131 222 minecraft:mossy_cobblestone
setblock 377 129 191 minecraft:mossy_cobblestone
setblock 377 129 195 minecraft:stone_bricks
setblock 377 129 210 minecraft:stone_bricks
fill 377 129 211 377 131 211 minecraft:mossy_cobblestone
setblock 377 129 215 minecraft:stone_bricks
fill 377 129 216 377 132 216 minecraft:mossy_cobblestone
setblock 377 129 220 minecraft:stone_bricks
fill 377 129 221 377 132 221 minecraft:mossy_cobblestone
setblock 378 129 214 minecraft:stone_bricks
fill 378 129 215 378 132 215 minecraft:mossy_cobblestone
setblock 378 129 219 minecraft:stone_bricks
setblock 379 129 184 minecraft:light[level=12]
setblock 379 129 192 minecraft:light[level=12]
setblock 379 129 200 minecraft:light[level=12]
setblock 379 129 208 minecraft:light[level=12]
setblock 379 129 216 minecraft:light[level=12]
setblock 387 129 184 minecraft:light[level=12]
setblock 387 129 192 minecraft:light[level=12]
setblock 387 129 200 minecraft:light[level=12]
setblock 387 129 208 minecraft:light[level=12]
setblock 387 129 216 minecraft:light[level=12]
setblock 390 129 222 minecraft:stone_bricks
fill 391 129 222 391 132 222 minecraft:mossy_cobblestone
setblock 395 129 184 minecraft:light[level=12]
setblock 395 129 192 minecraft:light[level=12]
setblock 395 129 200 minecraft:light[level=12]
setblock 395 129 208 minecraft:light[level=12]
setblock 395 129 216 minecraft:light[level=12]
setblock 403 129 184 minecraft:light[level=12]
setblock 403 129 192 minecraft:light[level=12]
setblock 403 129 200 minecraft:light[level=12]
setblock 403 129 208 minecraft:light[level=12]
setblock 403 129 216 minecraft:light[level=12]
fill 406 129 182 406 132 182 minecraft:mossy_cobblestone
setblock 409 129 183 minecraft:stone_bricks
fill 409 129 221 410 129 221 minecraft:mossy_cobblestone
setblock 410 129 182 minecraft:stone_bricks
fill 410 129 183 410 132 183 minecraft:mossy_cobblestone
setblock 410 129 222 minecraft:stone_bricks
fill 411 129 182 411 132 182 minecraft:mossy_cobblestone
setblock 411 129 184 minecraft:light[level=12]
setblock 411 129 192 minecraft:light[level=12]
setblock 411 129 200 minecraft:light[level=12]
setblock 411 129 208 minecraft:light[level=12]
setblock 411 129 216 minecraft:light[level=12]
setblock 411 129 221 minecraft:stone_bricks
fill 411 129 222 411 132 222 minecraft:mossy_cobblestone
setblock 412 129 220 minecraft:stone_bricks
fill 412 129 221 412 132 221 minecraft:mossy_cobblestone
setblock 413 129 220 minecraft:mossy_cobblestone
setblock 414 129 183 minecraft:stone_bricks
setblock 415 129 182 minecraft:stone_bricks
setblock 415 129 192 minecraft:stone_bricks
setblock 415 129 216 minecraft:mossy_cobblestone
setblock 415 129 217 minecraft:stone_bricks
setblock 415 129 218 minecraft:mossy_cobblestone
setblock 415 129 222 minecraft:stone_bricks
fill 416 129 182 416 130 182 minecraft:mossy_cobblestone
setblock 416 129 187 minecraft:mossy_cobblestone
setblock 416 129 191 minecraft:stone_bricks
setblock 416 129 192 minecraft:mossy_cobblestone
setblock 416 129 212 minecraft:mossy_cobblestone
setblock 416 129 216 minecraft:stone_bricks
fill 416 129 217 416 132 217 minecraft:mossy_cobblestone
setblock 416 129 221 minecraft:stone_bricks
fill 416 129 222 416 132 222 minecraft:mossy_cobblestone
setblock 417 129 185 minecraft:stone_bricks
setblock 417 129 186 minecraft:mossy_cobblestone
setblock 417 129 190 minecraft:stone_bricks
fill 417 129 191 417 130 191 minecraft:mossy_cobblestone
setblock 417 129 195 minecraft:stone_bricks
fill 417 129 196 417 130 196 minecraft:mossy_cobblestone
setblock 417 129 210 minecraft:stone_bricks
fill 417 129 211 417 130 211 minecraft:mossy_cobblestone
setblock 417 129 215 minecraft:stone_bricks
fill 417 129 216 417 132 216 minecraft:mossy_cobblestone
setblock 417 129 220 minecraft:stone_bricks
fill 417 129 221 417 132 221 minecraft:mossy_cobblestone
setblock 377 130 209 minecraft:stone_bricks
fill 377 130 210 377 131 210 minecraft:mossy_cobblestone
setblock 377 130 214 minecraft:stone_bricks
fill 377 130 215 377 133 215 minecraft:mossy_cobblestone
setblock 377 130 219 minecraft:stone_bricks
fill 377 130 220 377 133 220 minecraft:mossy_cobblestone
setblock 378 130 213 minecraft:stone_bricks
fill 378 130 214 378 131 214 minecraft:mossy_cobblestone
setblock 378 130 218 minecraft:stone_bricks
setblock 378 130 219 minecraft:mossy_cobblestone
fill 386 130 222 386 132 222 minecraft:mossy_cobblestone
setblock 389 130 222 minecraft:stone_bricks
fill 390 130 222 390 133 222 minecraft:mossy_cobblestone
fill 406 130 222 406 132 222 minecraft:mossy_cobblestone
setblock 408 130 183 minecraft:stone_bricks
fill 408 130 221 409 130 221 minecraft:mossy_cobblestone
setblock 409 130 182 minecraft:stone_bricks
fill 409 130 183 409 133 183 minecraft:mossy_cobblestone
setblock 409 130 222 minecraft:stone_bricks
fill 410 130 182 410 133 182 minecraft:mossy_cobblestone
setblock 410 130 221 minecraft:stone_bricks
fill 410 130 222 410 133 222 minecraft:mossy_cobblestone
setblock 411 130 220 minecraft:stone_bricks
fill 411 130 221 411 133 221 minecraft:mossy_cobblestone
fill 412 130 220 412 133 220 minecraft:mossy_cobblestone
setblock 413 130 183 minecraft:stone_bricks
setblock 414 130 182 minecraft:stone_bricks
setblock 414 130 222 minecraft:stone_bricks
fill 415 130 182 415 132 182 minecraft:mossy_cobblestone
setblock 415 130 221 minecraft:stone_bricks
fill 415 130 222 415 133 222 minecraft:mossy_cobblestone
setblock 416 130 215 minecraft:stone_bricks
fill 416 130 216 416 132 216 minecraft:mossy_cobblestone
setblock 416 130 220 minecraft:stone_bricks
fill 416 130 221 416 133 221 minecraft:mossy_cobblestone
setblock 417 130 189 minecraft:stone_bricks
setblock 417 130 190 minecraft:mossy_cobblestone
setblock 417 130 194 minecraft:stone_bricks
setblock 417 130 195 minecraft:mossy_cobblestone
setblock 417 130 214 minecraft:stone_bricks
fill 417 130 215 417 133 215 minecraft:mossy_cobblestone
setblock 417 130 219 minecraft:stone_bricks
fill 417 130 220 417 133 220 minecraft:mossy_cobblestone
setblock 377 131 213 minecraft:stone_bricks
fill 377 131 214 377 133 214 minecraft:mossy_cobblestone
setblock 377 131 218 minecraft:stone_bricks
fill 377 131 219 377 133 219 minecraft:mossy_cobblestone
setblock 378 131 213 minecraft:mossy_cobblestone
setblock 378 131 217 minecraft:stone_bricks
fill 378 131 218 378 132 218 minecraft:mossy_cobblestone
setblock 388 131 222 minecraft:stone_bricks
fill 389 131 222 389 133 222 minecraft:mossy_cobblestone
fill 405 131 182 405 133 182 minecraft:mossy_cobblestone
setblock 408 131 182 minecraft:stone_bricks
fill 408 131 183 408 133 183 minecraft:mossy_cobblestone
setblock 408 131 221 minecraft:mossy_cobblestone
setblock 408 131 222 minecraft:stone_bricks
fill 409 131 182 409 133 182 minecraft:mossy_cobblestone
setblock 409 131 221 minecraft:stone_bricks
fill 409 131 222 409 133 222 minecraft:mossy_cobblestone
fill 410 131 221 410 133 221 minecraft:mossy_cobblestone
fill 411 131 220 411 133 220 minecraft:mossy_cobblestone
setblock 412 131 183 minecraft:stone_bricks
setblock 413 131 182 minecraft:stone_bricks
setblock 413 131 222 minecraft:stone_bricks
fill 414 131 182 414 133 182 minecraft:mossy_cobblestone
setblock 414 131 221 minecraft:stone_bricks
fill 414 131 222 414 133 222 minecraft:mossy_cobblestone
fill 415 131 221 415 133 221 minecraft:mossy_cobblestone
setblock 416 131 215 minecraft:mossy_cobblestone
setblock 416 131 219 minecraft:stone_bricks
fill 416 131 220 416 133 220 minecraft:mossy_cobblestone
setblock 417 131 213 minecraft:stone_bricks
fill 417 131 214 417 133 214 minecraft:mossy_cobblestone
setblock 417 131 218 minecraft:stone_bricks
fill 417 131 219 417 133 219 minecraft:mossy_cobblestone
setblock 377 132 212 minecraft:stone_bricks
fill 377 132 213 377 133 213 minecraft:mossy_cobblestone
setblock 377 132 217 minecraft:stone_bricks
fill 377 132 218 377 133 218 minecraft:mossy_cobblestone
setblock 377 132 222 minecraft:stone_bricks
setblock 378 132 216 minecraft:stone_bricks
fill 378 132 217 378 133 217 minecraft:mossy_cobblestone
fill 385 132 222 385 133 222 minecraft:mossy_cobblestone
setblock 387 132 222 minecraft:stone_bricks
fill 388 132 222 388 133 222 minecraft:mossy_cobblestone
fill 405 132 222 405 133 222 minecraft:mossy_cobblestone
setblock 407 132 182 minecraft:stone_bricks
setblock 407 132 221 minecraft:mossy_cobblestone
setblock 407 132 222 minecraft:stone_bricks
fill 408 132 182 408 133 182 minecraft:mossy_cobblestone
setblock 408 132 221 minecraft:stone_bricks
fill 408 132 222 408 133 222 minecraft:mossy_cobblestone
fill 409 132 221 409 133 221 minecraft:mossy_cobblestone
fill 410 132 220 410 133 220 minecraft:mossy_cobblestone
setblock 411 132 183 minecraft:stone_bricks
setblock 412 132 182 minecraft:stone_bricks
setblock 412 132 222 minecraft:stone_bricks
fill 413 132 182 413 133 182 minecraft:mossy_cobblestone
setblock 413 132 221 minecraft:stone_bricks
fill 413 132 222 413 133 222 minecraft:mossy_cobblestone
fill 414 132 221 414 133 221 minecraft:mossy_cobblestone
setblock 416 132 218 minecraft:stone_bricks
fill 416 132 219 416 133 219 minecraft:mossy_cobblestone
setblock 417 132 213 minecraft:mossy_cobblestone
setblock 417 132 217 minecraft:stone_bricks
fill 417 132 218 417 133 218 minecraft:mossy_cobblestone
setblock 417 132 222 minecraft:stone_bricks
setblock 377 133 212 minecraft:mossy_cobblestone
setblock 377 133 216 minecraft:stone_bricks
setblock 377 133 217 minecraft:mossy_cobblestone
setblock 377 133 221 minecraft:stone_bricks
setblock 377 133 222 minecraft:mossy_cobblestone
setblock 384 133 222 minecraft:mossy_cobblestone
setblock 386 133 222 minecraft:stone_bricks
setblock 387 133 221 minecraft:stone_bricks
setblock 387 133 222 minecraft:mossy_cobblestone
setblock 388 133 221 minecraft:mossy_cobblestone
setblock 391 133 222 minecraft:stone_bricks
setblock 404 133 182 minecraft:mossy_cobblestone
setblock 404 133 222 minecraft:mossy_cobblestone
setblock 406 133 182 minecraft:stone_bricks
setblock 406 133 221 minecraft:mossy_cobblestone
setblock 406 133 222 minecraft:stone_bricks
fill 407 133 182 407 133 183 minecraft:mossy_cobblestone
setblock 407 133 221 minecraft:stone_bricks
setblock 407 133 222 minecraft:mossy_cobblestone
setblock 408 133 221 minecraft:mossy_cobblestone
setblock 409 133 220 minecraft:mossy_cobblestone
setblock 410 133 183 minecraft:stone_bricks
setblock 411 133 182 minecraft:stone_bricks
setblock 411 133 183 minecraft:mossy_cobblestone
setblock 411 133 222 minecraft:stone_bricks
setblock 412 133 182 minecraft:mossy_cobblestone
setblock 412 133 221 minecraft:stone_bricks
setblock 412 133 222 minecraft:mossy_cobblestone
setblock 413 133 221 minecraft:mossy_cobblestone
setblock 416 133 217 minecraft:stone_bricks
setblock 416 133 218 minecraft:mossy_cobblestone
setblock 416 133 222 minecraft:stone_bricks
setblock 417 133 216 minecraft:stone_bricks
setblock 417 133 217 minecraft:mossy_cobblestone
setblock 417 133 221 minecraft:stone_bricks
setblock 417 133 222 minecraft:mossy_cobblestone
setblock 379 137 184 minecraft:light[level=12]
setblock 379 137 192 minecraft:light[level=12]
setblock 379 137 200 minecraft:light[level=12]
setblock 379 137 208 minecraft:light[level=12]
setblock 379 137 216 minecraft:light[level=12]
setblock 387 137 184 minecraft:light[level=12]
setblock 387 137 192 minecraft:light[level=12]
setblock 387 137 200 minecraft:light[level=12]
setblock 387 137 208 minecraft:light[level=12]
setblock 387 137 216 minecraft:light[level=12]
setblock 395 137 184 minecraft:light[level=12]
setblock 395 137 192 minecraft:light[level=12]
setblock 395 137 200 minecraft:light[level=12]
setblock 395 137 208 minecraft:light[level=12]
setblock 395 137 216 minecraft:light[level=12]
setblock 403 137 184 minecraft:light[level=12]
setblock 403 137 192 minecraft:light[level=12]
setblock 403 137 200 minecraft:light[level=12]
setblock 403 137 208 minecraft:light[level=12]
setblock 403 137 216 minecraft:light[level=12]
setblock 411 137 184 minecraft:light[level=12]
setblock 411 137 192 minecraft:light[level=12]
setblock 411 137 200 minecraft:light[level=12]
setblock 411 137 208 minecraft:light[level=12]
setblock 411 137 216 minecraft:light[level=12]
fill 385 139 201 398 141 201 minecraft:cobblestone
fill 386 139 196 399 141 200 minecraft:cobblestone
fill 386 139 202 399 141 206 minecraft:cobblestone
fill 387 139 193 417 141 195 minecraft:cobblestone
fill 387 139 207 417 141 209 minecraft:cobblestone
fill 388 139 192 416 141 192 minecraft:cobblestone
fill 388 139 210 416 141 210 minecraft:cobblestone
fill 389 139 191 415 141 191 minecraft:cobblestone
fill 389 139 211 415 141 211 minecraft:cobblestone
fill 390 139 189 414 141 190 minecraft:cobblestone
fill 390 139 212 414 141 213 minecraft:cobblestone
fill 392 139 188 412 141 188 minecraft:cobblestone
fill 392 139 214 412 141 214 minecraft:cobblestone
fill 393 139 187 411 141 187 minecraft:cobblestone
fill 393 139 215 411 141 215 minecraft:cobblestone
fill 394 139 186 410 141 186 minecraft:cobblestone
fill 394 139 216 410 141 216 minecraft:cobblestone
fill 397 139 185 407 141 185 minecraft:cobblestone
fill 397 139 217 407 141 217 minecraft:cobblestone
fill 400 139 196 401 141 198 minecraft:cobblestone
fill 400 139 204 401 141 206 minecraft:cobblestone
fill 402 139 184 402 148 184 minecraft:cobblestone
fill 402 139 196 418 141 197 minecraft:cobblestone
fill 402 139 205 418 141 206 minecraft:cobblestone
fill 402 139 218 402 148 218 minecraft:cobblestone
fill 403 139 198 418 141 198 minecraft:cobblestone
fill 403 139 204 418 141 204 minecraft:cobblestone
fill 405 139 199 418 141 200 minecraft:cobblestone
fill 405 139 202 418 141 203 minecraft:cobblestone
fill 406 139 201 418 141 201 minecraft:cobblestone
fill 418 139 195 418 182 195 minecraft:mossy_cobblestone
fill 418 139 207 418 183 208 minecraft:mossy_cobblestone
fill 377 142 182 384 142 222 minecraft:cobbled_deepslate
fill 385 142 182 385 142 200 minecraft:cobbled_deepslate
fill 385 142 201 397 143 201 minecraft:cobblestone
fill 385 142 202 385 142 222 minecraft:cobbled_deepslate
fill 386 142 182 386 142 195 minecraft:cobbled_deepslate
fill 386 142 196 387 148 197 minecraft:cobblestone
fill 386 142 198 386 148 198 minecraft:moss_block
fill 386 142 199 394 145 200 minecraft:cobblestone
fill 386 142 202 386 148 204 minecraft:cobblestone
fill 386 142 205 386 148 205 minecraft:moss_block
fill 386 142 206 391 147 206 minecraft:cobblestone
fill 386 142 207 386 142 222 minecraft:cobbled_deepslate
fill 387 142 182 387 142 192 minecraft:cobbled_deepslate
fill 387 142 193 395 145 195 minecraft:cobblestone
fill 387 142 198 398 143 198 minecraft:cobblestone
fill 387 142 202 387 148 203 minecraft:cobblestone
fill 387 142 204 387 148 204 minecraft:moss_block
fill 387 142 205 392 146 205 minecraft:cobblestone
fill 387 142 207 390 147 209 minecraft:cobblestone
fill 387 142 210 387 142 222 minecraft:cobbled_deepslate
fill 388 142 182 388 142 191 minecraft:cobbled_deepslate
fill 388 142 192 392 147 192 minecraft:cobblestone
fill 388 142 196 401 143 196 minecraft:cobblestone
fill 388 142 197 389 147 197 minecraft:moss_block
fill 388 142 202 389 147 202 minecraft:cobblestone
fill 388 142 203 388 148 203 minecraft:moss_block
fill 388 142 204 393 145 204 minecraft:cobblestone
fill 388 142 210 389 148 210 minecraft:cobblestone
fill 388 142 211 388 142 222 minecraft:cobbled_deepslate
fill 389 142 182 389 142 190 minecraft:cobbled_deepslate
fill 389 142 191 389 148 191 minecraft:moss_block
fill 389 142 203 398 143 203 minecraft:cobblestone
fill 389 142 211 394 147 211 minecraft:cobblestone
fill 389 142 212 389 142 222 minecraft:cobbled_deepslate
fill 390 142 182 391 142 188 minecraft:cobbled_deepslate
fill 390 142 189 397 146 191 minecraft:cobblestone
fill 390 142 197 395 145 197 minecraft:cobblestone
fill 390 142 202 390 147 202 minecraft:moss_block
fill 390 142 210 390 148 210 minecraft:moss_block
fill 390 142 212 394 147 213 minecraft:cobblestone
fill 390 142 214 391 142 222 minecraft:cobbled_deepslate
fill 391 142 202 397 143 202 minecraft:cobblestone
fill 391 142 207 417 143 207 minecraft:cobblestone
fill 391 142 208 391 147 208 minecraft:moss_block
fill 391 142 209 402 144 210 minecraft:cobblestone
fill 392 142 182 392 142 187 minecraft:cobbled_deepslate
fill 392 142 188 396 148 188 minecraft:cobblestone
fill 392 142 206 392 146 206 minecraft:moss_block
fill 392 142 208 417 144 208 minecraft:cobblestone
fill 392 142 214 394 148 214 minecraft:cobblestone
fill 392 142 215 392 142 222 minecraft:cobbled_deepslate
fill 393 142 182 393 142 186 minecraft:cobbled_deepslate
fill 393 142 187 402 147 187 minecraft:cobblestone
fill 393 142 192 394 147 192 minecraft:moss_block
fill 393 142 205 393 145 205 minecraft:moss_block
fill 393 142 206 401 143 206 minecraft:cobblestone
fill 393 142 215 394 148 215 minecraft:cobblestone
fill 393 142 216 393 142 222 minecraft:cobbled_deepslate
fill 394 142 182 396 142 185 minecraft:cobbled_deepslate
fill 394 142 186 394 148 186 minecraft:moss_block
fill 394 142 204 394 145 204 minecraft:moss_block
fill 394 142 205 400 143 205 minecraft:cobblestone
fill 394 142 216 409 148 216 minecraft:cobblestone
fill 394 142 217 396 142 222 minecraft:cobbled_deepslate
fill 395 142 186 410 148 186 minecraft:cobblestone
fill 395 142 192 413 145 192 minecraft:cobblestone
fill 395 142 199 398 143 199 minecraft:cobblestone
fill 395 142 200 395 144 200 minecraft:moss_block
fill 395 142 204 398 143 204 minecraft:cobblestone
fill 395 142 211 395 147 215 minecraft:moss_block
fill 396 142 193 396 145 193 minecraft:moss_block
fill 396 142 194 412 143 195 minecraft:cobblestone
fill 396 142 197 396 144 197 minecraft:moss_block
fill 396 142 200 397 143 200 minecraft:cobblestone
fill 396 142 211 399 146 215 minecraft:cobblestone
fill 397 142 182 401 142 184 minecraft:cobbled_deepslate
fill 397 142 185 401 148 185 minecraft:cobblestone
fill 397 142 188 397 147 188 minecraft:moss_block
fill 397 142 193 400 145 193 minecraft:cobblestone
fill 397 142 197 400 143 197 minecraft:cobblestone
fill 397 142 217 401 148 217 minecraft:cobblestone
fill 397 142 218 401 142 222 minecraft:cobbled_deepslate
fill 398 142 188 408 147 188 minecraft:cobblestone
fill 398 142 189 398 147 189 minecraft:moss_block
fill 398 142 190 398 146 191 minecraft:cobblestone
fill 398 142 200 398 142 202 minecraft:lantern
fill 399 142 189 403 146 189 minecraft:cobblestone
fill 399 142 190 399 146 190 minecraft:moss_block
fill 399 142 191 399 146 191 minecraft:cobblestone
fill 399 142 198 399 142 200 minecraft:lantern
fill 399 142 202 399 142 204 minecraft:lantern
fill 400 142 190 403 146 190 minecraft:cobblestone
fill 400 142 191 400 146 191 minecraft:moss_block
fill 400 142 198 401 142 198 minecraft:lantern
fill 400 142 204 401 142 204 minecraft:lantern
fill 400 142 211 403 145 211 minecraft:cobblestone
fill 400 142 212 400 146 213 minecraft:moss_block
fill 400 142 214 400 147 215 minecraft:cobblestone
fill 401 142 191 408 145 191 minecraft:cobblestone
fill 401 142 193 401 145 193 minecraft:moss_block
fill 401 142 197 403 142 197 minecraft:lantern
fill 401 142 205 403 142 205 minecraft:lantern
fill 401 142 212 404 146 214 minecraft:cobblestone
fill 401 142 215 401 148 215 minecraft:moss_block
fill 402 142 182 417 142 183 minecraft:cobbled_deepslate
fill 402 142 185 402 148 185 minecraft:moss_block
fill 402 142 193 417 144 193 minecraft:cobblestone
fill 402 142 196 402 143 196 minecraft:moss_block
fill 402 142 206 402 143 206 minecraft:moss_block
fill 402 142 215 411 147 215 minecraft:cobblestone
fill 402 142 217 402 148 217 minecraft:moss_block
fill 402 142 219 417 142 222 minecraft:cobbled_deepslate
fill 403 142 184 417 142 184 minecraft:cobbled_deepslate
fill 403 142 185 407 148 185 minecraft:cobblestone
fill 403 142 187 403 148 187 minecraft:moss_block
fill 403 142 196 411 143 196 minecraft:cobblestone
fill 403 142 198 405 142 198 minecraft:lantern
fill 403 142 204 405 142 204 minecraft:lantern
fill 403 142 206 418 143 206 minecraft:cobblestone
fill 403 142 209 403 145 209 minecraft:moss_block
fill 403 142 210 409 145 210 minecraft:cobblestone
fill 403 142 217 407 148 217 minecraft:cobblestone
fill 403 142 218 417 142 218 minecraft:cobbled_deepslate
fill 404 142 187 408 148 187 minecraft:cobblestone
fill 404 142 189 404 146 190 minecraft:moss_block
fill 404 142 197 410 143 197 minecraft:cobblestone
fill 404 142 205 407 143 205 minecraft:cobblestone
fill 404 142 209 407 145 209 minecraft:cobblestone
fill 404 142 211 404 146 211 minecraft:moss_block
fill 405 142 189 408 146 190 minecraft:cobblestone
fill 405 142 199 405 142 200 minecraft:lantern
fill 405 142 202 405 142 203 minecraft:lantern
fill 405 142 211 414 146 211 minecraft:cobblestone
fill 405 142 212 405 146 212 minecraft:moss_block
fill 405 142 213 405 147 214 minecraft:cobblestone
fill 406 142 198 409 143 199 minecraft:cobblestone
fill 406 142 200 406 142 202 minecraft:lantern
fill 406 142 203 417 143 204 minecraft:cobblestone
fill 406 142 212 414 146 212 minecraft:cobblestone
fill 406 142 213 406 147 213 minecraft:moss_block
fill 406 142 214 406 147 214 minecraft:cobblestone
fill 407 142 200 408 143 202 minecraft:cobblestone
fill 407 142 213 414 147 213 minecraft:cobblestone
fill 407 142 214 407 147 214 minecraft:moss_block
fill 408 142 185 417 142 185 minecraft:cobbled_deepslate
fill 408 142 205 408 144 205 minecraft:moss_block
fill 408 142 209 408 145 209 minecraft:moss_block
fill 408 142 214 412 148 214 minecraft:cobblestone
fill 408 142 217 417 142 217 minecraft:cobbled_deepslate
fill 409 142 187 409 147 191 minecraft:moss_block
fill 409 142 200 413 144 201 minecraft:cobblestone
fill 409 142 202 409 144 202 minecraft:moss_block
fill 409 142 205 414 145 205 minecraft:cobblestone
fill 409 142 209 417 146 209 minecraft:cobblestone
fill 410 142 187 411 147 191 minecraft:cobblestone
fill 410 142 198 410 145 198 minecraft:moss_block
fill 410 142 199 415 145 199 minecraft:cobblestone
fill 410 142 202 418 145 202 minecraft:cobblestone
fill 410 142 210 411 147 210 minecraft:moss_block
fill 410 142 216 410 148 216 minecraft:moss_block
fill 411 142 186 417 142 186 minecraft:cobbled_deepslate
fill 411 142 197 411 145 197 minecraft:moss_block
fill 411 142 198 416 145 198 minecraft:cobblestone
fill 411 142 216 417 142 216 minecraft:cobbled_deepslate
fill 412 142 187 417 142 187 minecraft:cobbled_deepslate
fill 412 142 188 412 148 191 minecraft:cobblestone
fill 412 142 196 412 146 196 minecraft:moss_block
fill 412 142 197 417 146 197 minecraft:cobblestone
fill 412 142 210 416 147 210 minecraft:cobblestone
fill 412 142 215 417 142 215 minecraft:cobbled_deepslate
fill 413 142 188 417 142 188 minecraft:cobbled_deepslate
fill 413 142 189 414 148 191 minecraft:cobblestone
fill 413 142 194 413 147 194 minecraft:moss_block
fill 413 142 195 417 147 196 minecraft:cobblestone
fill 413 142 214 417 142 214 minecraft:cobbled_deepslate
fill 414 142 192 414 148 192 minecraft:moss_block
fill 414 142 194 417 147 194 minecraft:cobblestone
fill 414 142 200 414 147 200 minecraft:moss_block
fill 414 142 201 418 146 201 minecraft:cobblestone
fill 415 142 189 417 142 190 minecraft:cobbled_deepslate
fill 415 142 191 415 148 192 minecraft:cobblestone
fill 415 142 200 418 147 200 minecraft:cobblestone
fill 415 142 205 416 147 205 minecraft:moss_block
fill 415 142 211 415 148 211 minecraft:moss_block
fill 415 142 212 417 142 213 minecraft:cobbled_deepslate
fill 416 142 191 417 142 191 minecraft:cobbled_deepslate
fill 416 142 192 416 148 192 minecraft:cobblestone
fill 416 142 199 416 148 199 minecraft:moss_block
fill 416 142 211 417 142 211 minecraft:cobbled_deepslate
setblock 417 142 192 minecraft:cobbled_deepslate
fill 417 142 198 417 148 198 minecraft:moss_block
fill 417 142 199 418 148 199 minecraft:cobblestone
fill 417 142 205 418 148 205 minecraft:cobblestone
setblock 417 142 210 minecraft:cobbled_deepslate
fill 418 142 196 418 148 196 minecraft:cobblestone
fill 418 142 197 418 148 197 minecraft:moss_block
fill 418 142 198 418 148 198 minecraft:cobblestone
fill 418 142 203 418 148 203 minecraft:cobblestone
fill 418 142 204 418 148 204 minecraft:moss_block
setblock 398 143 200 minecraft:lantern
setblock 398 143 202 minecraft:lantern
setblock 399 143 198 minecraft:cobblestone
setblock 399 143 204 minecraft:cobblestone
setblock 401 143 197 minecraft:lantern
setblock 401 143 205 minecraft:lantern
setblock 403 143 197 minecraft:lantern
setblock 403 143 205 minecraft:lantern
setblock 405 143 198 minecraft:cobblestone
setblock 405 143 204 minecraft:cobblestone
setblock 406 143 200 minecraft:lantern
setblock 406 143 202 minecraft:lantern
fill 385 144 201 395 144 201 minecraft:cobblestone
fill 387 144 198 396 144 198 minecraft:cobblestone
fill 388 144 196 398 144 196 minecraft:cobblestone
fill 389 144 203 396 144 203 minecraft:cobblestone
fill 391 144 202 396 144 202 minecraft:cobblestone
fill 391 144 207 401 144 207 minecraft:cobblestone
fill 393 144 206 398 144 206 minecraft:cobblestone
fill 394 144 205 397 144 205 minecraft:cobblestone
fill 395 144 199 396 144 199 minecraft:cobblestone
fill 395 144 204 396 144 204 minecraft:cobblestone
fill 396 144 194 401 144 195 minecraft:cobblestone
setblock 396 144 200 minecraft:cobblestone
setblock 397 144 197 minecraft:cobblestone
fill 402 144 194 412 144 194 minecraft:cobblestone
fill 403 144 195 412 144 195 minecraft:cobblestone
fill 403 144 207 417 144 207 minecraft:cobblestone
fill 406 144 196 411 144 196 minecraft:cobblestone
fill 406 144 206 418 144 206 minecraft:cobblestone
fill 407 144 197 410 144 197 minecraft:cobblestone
setblock 407 144 205 minecraft:cobblestone
fill 408 144 198 408 144 200 minecraft:cobblestone
fill 408 144 202 408 144 204 minecraft:cobblestone
fill 409 144 198 409 144 199 minecraft:cobblestone
fill 409 144 203 417 144 204 minecraft:cobblestone
setblock 379 145 184 minecraft:light[level=12]
setblock 379 145 192 minecraft:light[level=12]
setblock 379 145 200 minecraft:light[level=12]
setblock 379 145 208 minecraft:light[level=12]
setblock 379 145 216 minecraft:light[level=12]
fill 385 145 201 393 145 201 minecraft:cobblestone
setblock 387 145 184 minecraft:light[level=12]
setblock 387 145 192 minecraft:light[level=12]
fill 387 145 198 394 145 198 minecraft:cobblestone
setblock 387 145 216 minecraft:light[level=12]
fill 388 145 196 395 145 196 minecraft:cobblestone
fill 389 145 203 394 145 203 minecraft:cobblestone
fill 391 145 202 394 145 202 minecraft:cobblestone
fill 391 145 207 396 145 207 minecraft:cobblestone
fill 391 145 209 401 145 210 minecraft:cobblestone
fill 392 145 208 398 145 208 minecraft:cobblestone
fill 393 145 206 395 145 206 minecraft:cobblestone
fill 394 145 205 395 145 205 minecraft:cobblestone
setblock 395 145 184 minecraft:light[level=12]
setblock 395 145 200 minecraft:light[level=12]
fill 396 145 194 396 145 195 minecraft:cobblestone
fill 397 145 194 398 145 194 minecraft:cobblestone
setblock 402 145 210 minecraft:cobblestone
setblock 403 145 184 minecraft:light[level=12]
fill 403 145 193 417 145 193 minecraft:cobblestone
setblock 403 145 200 minecraft:light[level=12]
setblock 403 145 208 minecraft:light[level=12]
fill 406 145 194 412 145 194 minecraft:cobblestone
fill 406 145 208 417 145 208 minecraft:cobblestone
fill 408 145 195 412 145 195 minecraft:cobblestone
fill 408 145 207 417 145 207 minecraft:cobblestone
fill 409 145 196 410 145 197 minecraft:cobblestone
fill 409 145 206 418 145 206 minecraft:cobblestone
fill 410 145 200 413 145 200 minecraft:cobblestone
fill 410 145 203 417 145 204 minecraft:cobblestone
setblock 411 145 184 minecraft:light[level=12]
fill 411 145 196 411 146 196 minecraft:cobblestone
fill 411 145 201 413 145 201 minecraft:cobblestone
setblock 411 145 216 minecraft:light[level=12]
setblock 377 146 182 minecraft:mossy_cobblestone
setblock 377 146 183 minecraft:stone_bricks
fill 377 146 184 377 146 187 minecraft:mossy_cobblestone
setblock 377 146 188 minecraft:stone_bricks
setblock 377 146 197 minecraft:mossy_cobblestone
setblock 377 146 198 minecraft:stone_bricks
fill 377 146 199 377 146 202 minecraft:mossy_cobblestone
setblock 377 146 203 minecraft:stone_bricks
fill 377 146 204 377 146 207 minecraft:mossy_cobblestone
setblock 377 146 208 minecraft:stone_bricks
fill 377 146 209 377 146 212 minecraft:mossy_cobblestone
setblock 377 146 213 minecraft:stone_bricks
setblock 378 146 182 minecraft:stone_bricks
fill 378 146 199 378 146 201 minecraft:mossy_cobblestone
setblock 378 146 202 minecraft:stone_bricks
fill 378 146 203 378 146 206 minecraft:mossy_cobblestone
setblock 378 146 207 minecraft:stone_bricks
fill 378 146 208 378 146 211 minecraft:mossy_cobblestone
setblock 378 146 222 minecraft:stone_bricks
fill 379 146 182 381 146 183 minecraft:mossy_cobblestone
setblock 379 146 201 minecraft:stone_bricks
fill 379 146 202 379 146 205 minecraft:mossy_cobblestone
setblock 379 146 206 minecraft:stone_bricks
fill 379 146 207 379 147 209 minecraft:mossy_cobblestone
fill 379 146 222 382 146 222 minecraft:mossy_cobblestone
fill 380 146 203 380 146 204 minecraft:mossy_cobblestone
setblock 380 146 205 minecraft:stone_bricks
fill 380 146 206 380 148 207 minecraft:mossy_cobblestone
setblock 382 146 182 minecraft:mossy_cobblestone
setblock 382 146 183 minecraft:stone_bricks
setblock 383 146 182 minecraft:stone_bricks
fill 383 146 183 386 146 183 minecraft:mossy_cobblestone
setblock 383 146 222 minecraft:stone_bricks
fill 384 146 182 387 146 182 minecraft:mossy_cobblestone
fill 385 146 201 391 146 201 minecraft:cobblestone
fill 386 146 199 392 146 200 minecraft:cobblestone
setblock 387 146 183 minecraft:stone_bricks
fill 387 146 193 393 146 195 minecraft:cobblestone
fill 387 146 198 392 146 198 minecraft:cobblestone
setblock 388 146 182 minecraft:stone_bricks
fill 388 146 196 393 146 196 minecraft:cobblestone
fill 388 146 204 392 146 204 minecraft:cobblestone
fill 389 146 182 392 146 182 minecraft:mossy_cobblestone
fill 389 146 203 392 146 203 minecraft:cobblestone
fill 390 146 197 392 146 197 minecraft:cobblestone
fill 391 146 202 392 146 202 minecraft:cobblestone
fill 391 146 207 393 146 207 minecraft:cobblestone
fill 391 146 209 395 146 210 minecraft:cobblestone
fill 392 146 208 394 146 208 minecraft:cobblestone
setblock 393 146 182 minecraft:stone_bricks
setblock 393 146 206 minecraft:cobblestone
fill 394 146 182 396 146 183 minecraft:mossy_cobblestone
fill 394 146 193 394 146 194 minecraft:cobblestone
fill 395 146 192 395 146 193 minecraft:cobblestone
setblock 396 146 184 minecraft:stone_bricks
fill 396 146 192 397 146 192 minecraft:cobblestone
fill 396 146 210 397 146 210 minecraft:cobblestone
setblock 397 146 182 minecraft:mossy_cobblestone
setblock 397 146 183 minecraft:stone_bricks
fill 397 146 184 400 146 184 minecraft:mossy_cobblestone
setblock 397 146 222 minecraft:mossy_cobblestone
setblock 398 146 182 minecraft:stone_bricks
fill 398 146 183 401 146 183 minecraft:mossy_cobblestone
setblock 398 146 222 minecraft:stone_bricks
fill 399 146 182 402 146 182 minecraft:mossy_cobblestone
fill 399 146 222 402 146 222 minecraft:mossy_cobblestone
fill 400 146 211 401 146 211 minecraft:cobblestone
fill 400 146 221 403 146 221 minecraft:mossy_cobblestone
setblock 401 146 184 minecraft:stone_bricks
setblock 401 146 191 minecraft:cobblestone
setblock 402 146 183 minecraft:stone_bricks
setblock 403 146 182 minecraft:stone_bricks
fill 403 146 183 405 146 184 minecraft:mossy_cobblestone
fill 403 146 191 408 146 191 minecraft:cobblestone
setblock 403 146 211 minecraft:cobblestone
setblock 403 146 222 minecraft:stone_bricks
fill 404 146 182 407 146 182 minecraft:mossy_cobblestone
setblock 404 146 221 minecraft:stone_bricks
fill 404 146 222 407 146 222 minecraft:mossy_cobblestone
fill 405 146 221 406 146 221 minecraft:mossy_cobblestone
setblock 406 146 183 minecraft:mossy_cobblestone
setblock 406 146 184 minecraft:stone_bricks
setblock 407 146 183 minecraft:stone_bricks
fill 407 146 192 413 146 192 minecraft:cobblestone
fill 407 146 210 409 146 210 minecraft:cobblestone
setblock 408 146 182 minecraft:stone_bricks
setblock 408 146 183 minecraft:mossy_cobblestone
setblock 408 146 222 minecraft:stone_bricks
fill 409 146 182 412 146 182 minecraft:mossy_cobblestone
fill 409 146 193 417 146 193 minecraft:cobblestone
fill 409 146 222 412 146 222 minecraft:mossy_cobblestone
fill 410 146 194 412 146 194 minecraft:cobblestone
fill 410 146 208 417 146 208 minecraft:cobblestone
fill 411 146 195 412 146 195 minecraft:cobblestone
fill 411 146 206 417 146 207 minecraft:cobblestone
fill 412 146 198 413 146 200 minecraft:cobblestone
fill 412 146 202 414 146 205 minecraft:cobblestone
setblock 413 146 182 minecraft:stone_bricks
setblock 413 146 201 minecraft:cobblestone
setblock 413 146 222 minecraft:stone_bricks
fill 414 146 182 417 146 182 minecraft:mossy_cobblestone
fill 414 146 198 415 147 199 minecraft:cobblestone
fill 414 146 222 417 146 222 minecraft:mossy_cobblestone
fill 415 146 202 417 147 204 minecraft:cobblestone
fill 416 146 198 416 148 198 minecraft:cobblestone
setblock 417 146 183 minecraft:stone_bricks
fill 417 146 184 417 147 186 minecraft:mossy_cobblestone
fill 417 146 210 417 146 212 minecraft:mossy_cobblestone
setblock 417 146 213 minecraft:stone_bricks
fill 417 146 214 417 146 217 minecraft:mossy_cobblestone
setblock 417 146 218 minecraft:stone_bricks
fill 417 146 219 417 147 221 minecraft:mossy_cobblestone
fill 418 146 202 418 148 202 minecraft:cobblestone
fill 418 146 206 418 148 206 minecraft:cobblestone
setblock 377 147 182 minecraft:stone_bricks
fill 377 147 183 377 147 186 minecraft:mossy_cobblestone
setblock 377 147 187 minecraft:stone_bricks
fill 377 147 188 377 148 190 minecraft:mossy_cobblestone
setblock 377 147 197 minecraft:stone_bricks
fill 377 147 198 377 147 201 minecraft:mossy_cobblestone
setblock 377 147 202 minecraft:stone_bricks
fill 377 147 203 377 147 206 minecraft:mossy_cobblestone
setblock 377 147 207 minecraft:stone_bricks
fill 377 147 208 377 147 211 minecraft:mossy_cobblestone
setblock 377 147 212 minecraft:stone_bricks
fill 377 147 213 377 149 214 minecraft:mossy_cobblestone
fill 378 147 182 381 147 182 minecraft:mossy_cobblestone
fill 378 147 199 378 147 200 minecraft:mossy_cobblestone
setblock 378 147 201 minecraft:stone_bricks
fill 378 147 202 378 147 205 minecraft:mossy_cobblestone
setblock 378 147 206 minecraft:stone_bricks
fill 378 147 207 378 147 210 minecraft:mossy_cobblestone
setblock 378 147 211 minecraft:stone_bricks
fill 378 147 212 378 150 212 minecraft:mossy_cobblestone
fill 379 147 183 380 147 183 minecraft:mossy_cobblestone
fill 379 147 201 379 147 204 minecraft:mossy_cobblestone
setblock 379 147 205 minecraft:stone_bricks
fill 379 147 206 379 150 206 minecraft:mossy_cobblestone
setblock 379 147 210 minecraft:stone_bricks
setblock 380 147 204 minecraft:stone_bricks
fill 380 147 205 380 148 205 minecraft:mossy_cobblestone
fill 380 147 222 381 147 222 minecraft:mossy_cobblestone
setblock 381 147 183 minecraft:stone_bricks
setblock 382 147 182 minecraft:stone_bricks
fill 382 147 183 385 147 183 minecraft:mossy_cobblestone
fill 383 147 182 386 147 182 minecraft:mossy_cobblestone
fill 385 147 201 389 147 201 minecraft:cobblestone
fill 386 147 199 390 147 200 minecraft:cobblestone
setblock 387 147 182 minecraft:stone_bricks
fill 387 147 193 391 147 195 minecraft:cobblestone
fill 387 147 198 390 147 198 minecraft:cobblestone
fill 387 147 205 390 147 205 minecraft:cobblestone
fill 388 147 182 391 147 182 minecraft:mossy_cobblestone
fill 388 147 196 391 147 196 minecraft:cobblestone
fill 388 147 204 390 147 204 minecraft:cobblestone
fill 389 147 203 390 147 203 minecraft:cobblestone
fill 390 147 189 395 147 191 minecraft:cobblestone
setblock 390 147 197 minecraft:cobblestone
setblock 391 147 207 minecraft:cobblestone
fill 391 147 209 393 147 210 minecraft:cobblestone
setblock 392 147 182 minecraft:stone_bricks
fill 392 147 193 392 147 194 minecraft:cobblestone
setblock 392 147 208 minecraft:cobblestone
fill 393 147 182 396 147 182 minecraft:mossy_cobblestone
setblock 393 147 193 minecraft:cobblestone
fill 394 147 183 395 147 183 minecraft:mossy_cobblestone
setblock 394 147 210 minecraft:cobblestone
setblock 396 147 183 minecraft:stone_bricks
fill 396 147 184 399 147 184 minecraft:mossy_cobblestone
fill 396 147 189 397 147 190 minecraft:cobblestone
fill 396 147 212 397 147 215 minecraft:cobblestone
setblock 397 147 182 minecraft:stone_bricks
fill 397 147 183 400 147 183 minecraft:mossy_cobblestone
setblock 397 147 222 minecraft:stone_bricks
fill 398 147 182 401 147 182 minecraft:mossy_cobblestone
fill 398 147 213 399 147 215 minecraft:cobblestone
fill 398 147 222 401 147 222 minecraft:mossy_cobblestone
fill 399 147 189 401 147 189 minecraft:cobblestone
setblock 400 147 184 minecraft:stone_bricks
setblock 400 147 213 minecraft:moss_block
fill 400 147 221 402 147 221 minecraft:mossy_cobblestone
setblock 401 147 183 minecraft:stone_bricks
fill 401 147 184 401 150 184 minecraft:mossy_cobblestone
fill 401 147 213 401 147 214 minecraft:cobblestone
setblock 402 147 182 minecraft:stone_bricks
fill 402 147 183 405 147 183 minecraft:mossy_cobblestone
fill 402 147 214 404 147 214 minecraft:cobblestone
setblock 402 147 222 minecraft:stone_bricks
fill 403 147 182 406 147 182 minecraft:mossy_cobblestone
fill 403 147 184 404 147 184 minecraft:mossy_cobblestone
setblock 403 147 189 minecraft:cobblestone
fill 403 147 213 404 147 213 minecraft:cobblestone
setblock 403 147 221 minecraft:stone_bricks
fill 403 147 222 406 147 222 minecraft:mossy_cobblestone
setblock 404 147 189 minecraft:moss_block
fill 404 147 221 405 147 221 minecraft:mossy_cobblestone
setblock 405 147 184 minecraft:stone_bricks
fill 405 147 189 408 147 189 minecraft:cobblestone
setblock 406 147 183 minecraft:stone_bricks
setblock 407 147 182 minecraft:stone_bricks
setblock 407 147 183 minecraft:mossy_cobblestone
fill 407 147 190 408 147 190 minecraft:cobblestone
fill 407 147 212 414 147 212 minecraft:cobblestone
setblock 407 147 222 minecraft:stone_bricks
fill 408 147 182 410 147 182 minecraft:mossy_cobblestone
fill 408 147 222 410 147 222 minecraft:mossy_cobblestone
fill 409 147 211 414 147 211 minecraft:cobblestone
fill 410 147 192 413 147 192 minecraft:cobblestone
fill 411 147 193 417 147 193 minecraft:cobblestone
fill 411 147 209 417 147 209 minecraft:cobblestone
setblock 412 147 194 minecraft:cobblestone
fill 412 147 208 417 147 208 minecraft:cobblestone
fill 413 147 206 417 147 207 minecraft:cobblestone
fill 414 147 197 417 147 197 minecraft:cobblestone
fill 414 147 202 414 147 205 minecraft:cobblestone
fill 415 147 201 418 147 201 minecraft:cobblestone
fill 415 147 222 416 147 222 minecraft:mossy_cobblestone
setblock 416 147 182 minecraft:mossy_cobblestone
fill 416 147 211 417 147 211 minecraft:mossy_cobblestone
setblock 417 147 182 minecraft:stone_bricks
fill 417 147 183 417 150 183 minecraft:mossy_cobblestone
setblock 417 147 187 minecraft:stone_bricks
fill 417 147 210 417 148 210 minecraft:mossy_cobblestone
setblock 417 147 212 minecraft:stone_bricks
fill 417 147 213 417 147 216 minecraft:mossy_cobblestone
setblock 417 147 217 minecraft:stone_bricks
fill 417 147 218 417 150 218 minecraft:mossy_cobblestone
setblock 417 147 222 minecraft:stone_bricks
fill 377 148 182 377 148 185 minecraft:mossy_cobblestone
setblock 377 148 186 minecraft:stone_bricks
fill 377 148 187 378 150 187 minecraft:mossy_cobblestone
setblock 377 148 191 minecraft:stone_bricks
fill 377 148 192 377 150 193 minecraft:mossy_cobblestone
setblock 377 148 196 minecraft:stone_bricks
fill 377 148 197 377 148 200 minecraft:mossy_cobblestone
setblock 377 148 201 minecraft:stone_bricks
fill 377 148 202 377 148 205 minecraft:mossy_cobblestone
setblock 377 148 206 minecraft:stone_bricks
fill 377 148 207 377 148 210 minecraft:mossy_cobblestone
setblock 377 148 211 minecraft:stone_bricks
fill 377 148 212 377 151 212 minecraft:mossy_cobblestone
fill 378 148 182 380 148 182 minecraft:mossy_cobblestone
setblock 378 148 184 minecraft:mossy_cobblestone
setblock 378 148 185 minecraft:stone_bricks
fill 378 148 186 378 151 186 minecraft:mossy_cobblestone
fill 378 148 188 378 148 189 minecraft:mossy_cobblestone
setblock 378 148 199 minecraft:mossy_cobblestone
setblock 378 148 200 minecraft:stone_bricks
fill 378 148 201 378 148 204 minecraft:mossy_cobblestone
setblock 378 148 205 minecraft:stone_bricks
fill 378 148 206 378 148 209 minecraft:mossy_cobblestone
setblock 378 148 210 minecraft:stone_bricks
fill 378 148 211 378 151 211 minecraft:mossy_cobblestone
setblock 379 148 183 minecraft:mossy_cobblestone
fill 379 148 202 379 148 203 minecraft:mossy_cobblestone
setblock 379 148 204 minecraft:stone_bricks
fill 379 148 205 379 151 205 minecraft:mossy_cobblestone
fill 379 148 207 379 148 208 minecraft:mossy_cobblestone
setblock 379 148 209 minecraft:stone_bricks
fill 379 148 210 379 151 210 minecraft:mossy_cobblestone
setblock 380 148 183 minecraft:stone_bricks
setblock 381 148 182 minecraft:stone_bricks
fill 381 148 183 384 148 183 minecraft:mossy_cobblestone
fill 382 148 182 385 148 182 minecraft:mossy_cobblestone
fill 385 148 201 387 148 201 minecraft:cobblestone
setblock 386 148 182 minecraft:stone_bricks
fill 386 148 199 388 148 200 minecraft:cobblestone
fill 386 148 206 388 148 206 minecraft:cobblestone
fill 387 148 182 390 148 182 minecraft:mossy_cobblestone
fill 387 148 193 389 148 195 minecraft:cobblestone
fill 387 148 198 388 148 198 minecraft:cobblestone
fill 387 148 205 388 148 205 minecraft:cobblestone
fill 387 148 207 389 148 209 minecraft:cobblestone
fill 388 148 192 391 148 192 minecraft:cobblestone
setblock 388 148 196 minecraft:cobblestone
setblock 388 148 197 minecraft:moss_block
setblock 388 148 202 minecraft:cobblestone
setblock 388 148 204 minecraft:cobblestone
fill 389 148 211 392 148 211 minecraft:cobblestone
fill 390 148 189 392 148 191 minecraft:cobblestone
setblock 390 148 193 minecraft:cobblestone
setblock 390 148 209 minecraft:cobblestone
fill 390 148 212 393 148 213 minecraft:cobblestone
setblock 391 148 182 minecraft:stone_bricks
setblock 391 148 210 minecraft:cobblestone
fill 392 148 182 395 148 182 minecraft:mossy_cobblestone
fill 393 148 183 394 148 183 minecraft:mossy_cobblestone
fill 393 148 187 401 148 187 minecraft:cobblestone
fill 393 148 189 393 148 190 minecraft:cobblestone
setblock 394 148 189 minecraft:cobblestone
setblock 394 148 213 minecraft:cobblestone
setblock 395 148 183 minecraft:stone_bricks
fill 395 148 214 395 148 215 minecraft:moss_block
setblock 396 148 182 minecraft:stone_bricks
fill 396 148 183 398 148 184 minecraft:mossy_cobblestone
fill 396 148 214 396 148 215 minecraft:cobblestone
fill 397 148 182 400 148 182 minecraft:mossy_cobblestone
fill 397 148 215 400 148 215 minecraft:cobblestone
fill 397 148 222 400 148 222 minecraft:mossy_cobblestone
setblock 399 148 183 minecraft:mossy_cobblestone
setblock 399 148 184 minecraft:stone_bricks
setblock 400 148 183 minecraft:stone_bricks
fill 400 148 184 400 151 184 minecraft:mossy_cobblestone
setblock 401 148 182 minecraft:stone_bricks
fill 401 148 183 404 148 183 minecraft:mossy_cobblestone
setblock 401 148 221 minecraft:mossy_cobblestone
setblock 401 148 222 minecraft:stone_bricks
fill 402 148 182 405 148 182 minecraft:mossy_cobblestone
setblock 402 148 221 minecraft:stone_bricks
fill 402 148 222 405 148 222 minecraft:mossy_cobblestone
setblock 403 148 184 minecraft:mossy_cobblestone
fill 403 148 215 411 148 215 minecraft:cobblestone
setblock 403 148 221 minecraft:mossy_cobblestone
setblock 404 148 184 minecraft:stone_bricks
setblock 405 148 183 minecraft:stone_bricks
setblock 406 148 182 minecraft:stone_bricks
fill 406 148 183 406 149 183 minecraft:mossy_cobblestone
setblock 406 148 222 minecraft:stone_bricks
fill 407 148 182 409 148 182 minecraft:mossy_cobblestone
fill 407 148 222 408 148 222 minecraft:mossy_cobblestone
setblock 408 148 188 minecraft:cobblestone
fill 409 148 187 409 148 188 minecraft:moss_block
fill 410 148 187 411 148 189 minecraft:cobblestone
fill 410 148 213 414 148 213 minecraft:cobblestone
setblock 411 148 190 minecraft:cobblestone
fill 411 148 212 414 148 212 minecraft:cobblestone
fill 412 148 211 414 148 211 minecraft:cobblestone
setblock 413 148 192 minecraft:cobblestone
fill 413 148 210 416 148 210 minecraft:cobblestone
fill 414 148 193 417 148 193 minecraft:cobblestone
fill 414 148 209 417 148 209 minecraft:cobblestone
fill 415 148 194 417 148 195 minecraft:cobblestone
fill 415 148 207 417 148 208 minecraft:cobblestone
setblock 415 148 222 minecraft:mossy_cobblestone
setblock 416 148 182 minecraft:stone_bricks
fill 416 148 196 417 148 197 minecraft:cobblestone
fill 416 148 200 418 148 200 minecraft:cobblestone
fill 416 148 202 417 148 204 minecraft:cobblestone
setblock 416 148 205 minecraft:moss_block
fill 416 148 206 417 148 206 minecraft:cobblestone
setblock 416 148 211 minecraft:mossy_cobblestone
setblock 416 148 212 minecraft:stone_bricks
setblock 416 148 222 minecraft:stone_bricks
fill 417 148 182 417 151 182 minecraft:mossy_cobblestone
fill 417 148 184 417 148 185 minecraft:mossy_cobblestone
setblock 417 148 186 minecraft:stone_bricks
fill 417 148 187 417 150 188 minecraft:mossy_cobblestone
fill 417 148 201 418 148 201 minecraft:cobblestone
setblock 417 148 211 minecraft:stone_bricks
fill 417 148 212 417 148 215 minecraft:mossy_cobblestone
setblock 417 148 216 minecraft:stone_bricks
fill 417 148 217 417 151 217 minecraft:mossy_cobblestone
fill 417 148 219 417 148 220 minecraft:mossy_cobblestone
setblock 417 148 221 minecraft:stone_bricks
fill 417 148 222 417 151 222 minecraft:mossy_cobblestone
fill 377 149 182 377 149 184 minecraft:mossy_cobblestone
setblock 377 149 185 minecraft:stone_bricks
fill 377 149 186 377 152 186 minecraft:mossy_cobblestone
fill 377 149 188 377 149 189 minecraft:mossy_cobblestone
setblock 377 149 190 minecraft:stone_bricks
fill 377 149 191 378 151 191 minecraft:mossy_cobblestone
setblock 377 149 194 minecraft:mossy_cobblestone
setblock 377 149 195 minecraft:stone_bricks
fill 377 149 196 377 149 199 minecraft:mossy_cobblestone
setblock 377 149 200 minecraft:stone_bricks
fill 377 149 201 377 149 204 minecraft:mossy_cobblestone
setblock 377 149 205 minecraft:stone_bricks
fill 377 149 206 377 149 209 minecraft:mossy_cobblestone
setblock 377 149 210 minecraft:stone_bricks
fill 377 149 211 377 152 211 minecraft:mossy_cobblestone
setblock 377 149 215 minecraft:stone_bricks
fill 378 149 182 379 149 182 minecraft:mossy_cobblestone
setblock 378 149 184 minecraft:stone_bricks
fill 378 149 185 378 152 185 minecraft:mossy_cobblestone
setblock 378 149 188 minecraft:mossy_cobblestone
setblock 378 149 189 minecraft:stone_bricks
fill 378 149 190 378 152 190 minecraft:mossy_cobblestone
fill 378 149 192 378 150 192 minecraft:mossy_cobblestone
setblock 378 149 199 minecraft:stone_bricks
fill 378 149 200 378 149 203 minecraft:mossy_cobblestone
setblock 378 149 204 minecraft:stone_bricks
fill 378 149 205 378 149 208 minecraft:mossy_cobblestone
setblock 378 149 209 minecraft:stone_bricks
fill 378 149 210 378 152 210 minecraft:mossy_cobblestone
setblock 378 149 213 minecraft:mossy_cobblestone
setblock 379 149 183 minecraft:stone_bricks
setblock 379 149 202 minecraft:mossy_cobblestone
setblock 379 149 203 minecraft:stone_bricks
fill 379 149 204 379 152 204 minecraft:mossy_cobblestone
setblock 379 149 207 minecraft:mossy_cobblestone
setblock 379 149 208 minecraft:stone_bricks
fill 379 149 209 379 152 209 minecraft:mossy_cobblestone
fill 379 149 211 379 150 211 minecraft:mossy_cobblestone
setblock 380 149 182 minecraft:stone_bricks
fill 380 149 183 383 149 183 minecraft:mossy_cobblestone
setblock 380 149 206 minecraft:mossy_cobblestone
setblock 380 149 207 minecraft:stone_bricks
fill 381 149 182 384 149 182 minecraft:mossy_cobblestone
setblock 385 149 182 minecraft:stone_bricks
fill 386 149 182 387 149 182 minecraft:mossy_cobblestone
setblock 390 149 182 minecraft:stone_bricks
fill 391 149 182 394 149 182 minecraft:mossy_cobblestone
setblock 393 149 183 minecraft:mossy_cobblestone
setblock 394 149 183 minecraft:stone_bricks
setblock 395 149 182 minecraft:stone_bricks
fill 395 149 183 397 149 184 minecraft:mossy_cobblestone
fill 396 149 182 399 149 182 minecraft:mossy_cobblestone
fill 396 149 222 399 149 222 minecraft:mossy_cobblestone
setblock 398 149 183 minecraft:mossy_cobblestone
setblock 398 149 184 minecraft:stone_bricks
fill 398 149 185 401 149 185 minecraft:mossy_cobblestone
setblock 399 149 183 minecraft:stone_bricks
fill 399 149 184 399 152 184 minecraft:mossy_cobblestone
setblock 400 149 182 minecraft:stone_bricks
fill 400 149 183 403 149 183 minecraft:mossy_cobblestone
setblock 400 149 221 minecraft:mossy_cobblestone
setblock 400 149 222 minecraft:stone_bricks
fill 401 149 182 404 149 182 minecraft:mossy_cobblestone
setblock 401 149 221 minecraft:stone_bricks
fill 401 149 222 404 149 222 minecraft:mossy_cobblestone
setblock 402 149 184 minecraft:mossy_cobblestone
fill 402 149 221 402 152 221 minecraft:mossy_cobblestone
setblock 403 149 184 minecraft:stone_bricks
setblock 404 149 183 minecraft:stone_bricks
setblock 404 149 184 minecraft:mossy_cobblestone
setblock 405 149 182 minecraft:stone_bricks
fill 405 149 183 405 150 183 minecraft:mossy_cobblestone
setblock 405 149 222 minecraft:stone_bricks
fill 406 149 182 408 149 182 minecraft:mossy_cobblestone
fill 406 149 222 407 149 222 minecraft:mossy_cobblestone
fill 416 149 182 416 152 182 minecraft:mossy_cobblestone
fill 416 149 204 416 149 205 minecraft:mossy_cobblestone
setblock 416 149 206 minecraft:stone_bricks
fill 416 149 207 416 149 210 minecraft:mossy_cobblestone
setblock 416 149 211 minecraft:stone_bricks
fill 416 149 212 417 149 214 minecraft:mossy_cobblestone
fill 416 149 222 416 152 222 minecraft:mossy_cobblestone
setblock 417 149 184 minecraft:mossy_cobblestone
setblock 417 149 185 minecraft:stone_bricks
fill 417 149 186 417 152 186 minecraft:mossy_cobblestone
setblock 417 149 189 minecraft:mossy_cobblestone
setblock 417 149 190 minecraft:stone_bricks
setblock 417 149 200 minecraft:stone_bricks
fill 417 149 201 418 149 204 minecraft:mossy_cobblestone
setblock 417 149 205 minecraft:stone_bricks
fill 417 149 206 417 149 209 minecraft:mossy_cobblestone
setblock 417 149 210 minecraft:stone_bricks
fill 417 149 211 417 152 211 minecraft:mossy_cobblestone
setblock 417 149 215 minecraft:stone_bricks
fill 417 149 216 417 152 216 minecraft:mossy_cobblestone
setblock 417 149 219 minecraft:mossy_cobblestone
setblock 417 149 220 minecraft:stone_bricks
fill 417 149 221 417 152 221 minecraft:mossy_cobblestone
fill 418 149 196 418 186 200 minecraft:mossy_cobblestone
fill 418 149 205 418 184 206 minecraft:mossy_cobblestone
fill 377 150 182 377 150 183 minecraft:mossy_cobblestone
setblock 377 150 184 minecraft:stone_bricks
fill 377 150 185 377 153 185 minecraft:mossy_cobblestone
setblock 377 150 188 minecraft:mossy_cobblestone
setblock 377 150 189 minecraft:stone_bricks
fill 377 150 190 377 153 190 minecraft:mossy_cobblestone
setblock 377 150 194 minecraft:stone_bricks
fill 377 150 195 377 150 198 minecraft:mossy_cobblestone
setblock 377 150 199 minecraft:stone_bricks
fill 377 150 200 377 150 203 minecraft:mossy_cobblestone
setblock 377 150 204 minecraft:stone_bricks
fill 377 150 205 377 150 208 minecraft:mossy_cobblestone
setblock 377 150 209 minecraft:stone_bricks
fill 377 150 210 377 153 210 minecraft:mossy_cobblestone
setblock 377 150 213 minecraft:mossy_cobblestone
setblock 377 150 214 minecraft:stone_bricks
fill 377 150 215 377 152 216 minecraft:mossy_cobblestone
setblock 378 150 182 minecraft:mossy_cobblestone
setblock 378 150 183 minecraft:stone_bricks
fill 378 150 184 378 153 184 minecraft:mossy_cobblestone
setblock 378 150 188 minecraft:stone_bricks
fill 378 150 189 379 152 189 minecraft:mossy_cobblestone
setblock 378 150 193 minecraft:stone_bricks
fill 378 150 194 378 150 197 minecraft:mossy_cobblestone
setblock 378 150 198 minecraft:stone_bricks
fill 378 150 199 378 150 202 minecraft:mossy_cobblestone
setblock 378 150 203 minecraft:stone_bricks
fill 378 150 204 378 150 207 minecraft:mossy_cobblestone
setblock 378 150 208 minecraft:stone_bricks
fill 378 150 209 378 153 209 minecraft:mossy_cobblestone
setblock 378 150 213 minecraft:stone_bricks
fill 378 150 214 378 153 214 minecraft:mossy_cobblestone
setblock 379 150 182 minecraft:stone_bricks
fill 379 150 183 382 150 183 minecraft:mossy_cobblestone
setblock 379 150 186 minecraft:mossy_cobblestone
setblock 379 150 187 minecraft:stone_bricks
fill 379 150 188 379 153 188 minecraft:mossy_cobblestone
fill 379 150 190 379 150 191 minecraft:mossy_cobblestone
setblock 379 150 202 minecraft:stone_bricks
fill 379 150 203 379 153 203 minecraft:mossy_cobblestone
setblock 379 150 207 minecraft:stone_bricks
fill 379 150 208 379 153 208 minecraft:mossy_cobblestone
setblock 379 150 212 minecraft:stone_bricks
fill 380 150 182 383 150 182 minecraft:mossy_cobblestone
fill 380 150 207 380 151 207 minecraft:mossy_cobblestone
setblock 383 150 183 minecraft:stone_bricks
setblock 384 150 182 minecraft:stone_bricks
fill 385 150 182 386 151 182 minecraft:mossy_cobblestone
fill 390 150 182 393 150 182 minecraft:mossy_cobblestone
setblock 393 150 183 minecraft:stone_bricks
setblock 394 150 182 minecraft:stone_bricks
fill 394 150 183 397 150 183 minecraft:mossy_cobblestone
fill 395 150 182 398 150 182 minecraft:mossy_cobblestone
fill 395 150 184 396 150 184 minecraft:mossy_cobblestone
fill 396 150 222 398 150 222 minecraft:mossy_cobblestone
setblock 397 150 184 minecraft:stone_bricks
fill 397 150 185 400 150 185 minecraft:mossy_cobblestone
setblock 398 150 183 minecraft:stone_bricks
fill 398 150 184 398 153 184 minecraft:mossy_cobblestone
setblock 399 150 182 minecraft:stone_bricks
fill 399 150 183 402 150 183 minecraft:mossy_cobblestone
setblock 399 150 222 minecraft:stone_bricks
fill 400 150 182 403 150 182 minecraft:mossy_cobblestone
setblock 400 150 221 minecraft:stone_bricks
fill 400 150 222 403 150 222 minecraft:mossy_cobblestone
setblock 401 150 185 minecraft:stone_bricks
fill 401 150 221 401 153 221 minecraft:mossy_cobblestone
setblock 402 150 184 minecraft:stone_bricks
setblock 403 150 183 minecraft:stone_bricks
schedule function dropper:buildpart/44_7 1t
