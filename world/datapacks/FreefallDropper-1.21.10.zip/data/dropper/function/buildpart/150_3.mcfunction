fill 309 251 618 310 252 618 minecraft:blackstone
fill 309 251 630 310 252 630 minecraft:blackstone
fill 309 251 636 309 252 636 minecraft:black_concrete
fill 310 251 619 310 253 619 minecraft:blackstone
fill 310 251 629 310 253 629 minecraft:blackstone
fill 312 251 612 312 252 612 minecraft:black_concrete
fill 312 251 636 312 252 636 minecraft:black_concrete
setblock 315 251 611 minecraft:black_concrete
setblock 315 251 637 minecraft:black_concrete
fill 316 251 610 316 252 610 minecraft:black_concrete
fill 316 251 638 316 252 638 minecraft:black_concrete
fill 317 251 613 317 252 614 minecraft:gold_block
setblock 319 251 611 minecraft:black_concrete
setblock 319 251 637 minecraft:black_concrete
fill 324 251 632 324 307 632 minecraft:white_concrete
fill 282 252 612 282 254 612 minecraft:gold_block
fill 282 252 628 282 254 628 minecraft:gold_block
fill 282 252 644 282 254 644 minecraft:gold_block
fill 286 252 604 286 254 604 minecraft:gold_block
fill 294 252 621 295 253 622 minecraft:obsidian
fill 296 252 646 296 254 646 minecraft:gold_block
fill 302 252 604 302 254 604 minecraft:gold_block
fill 311 252 618 311 254 618 minecraft:blackstone
fill 311 252 630 311 254 630 minecraft:blackstone
fill 312 252 646 312 254 646 minecraft:gold_block
fill 313 252 611 313 253 611 minecraft:black_concrete
fill 313 252 637 313 253 637 minecraft:black_concrete
fill 318 252 604 318 254 604 minecraft:gold_block
fill 324 252 614 324 254 614 minecraft:gold_block
fill 324 252 630 324 254 630 minecraft:gold_block
setblock 291 253 646 minecraft:pearlescent_froglight
fill 292 253 646 294 270 646 minecraft:white_concrete
setblock 307 253 612 minecraft:black_concrete
setblock 307 253 636 minecraft:black_concrete
fill 310 253 610 310 253 611 minecraft:black_concrete
fill 310 253 617 310 253 618 minecraft:blackstone
fill 310 253 630 310 253 631 minecraft:blackstone
fill 310 253 637 310 253 638 minecraft:black_concrete
fill 311 253 617 311 255 617 minecraft:blackstone
fill 311 253 631 311 255 631 minecraft:blackstone
setblock 324 253 627 minecraft:amethyst_block
fill 324 253 628 324 289 628 minecraft:white_concrete
setblock 285 254 607 minecraft:light[level=13]
setblock 285 254 615 minecraft:light[level=13]
setblock 285 254 623 minecraft:light[level=13]
setblock 285 254 631 minecraft:light[level=13]
setblock 285 254 639 minecraft:light[level=13]
fill 291 254 646 291 307 646 minecraft:white_concrete
setblock 293 254 607 minecraft:light[level=13]
setblock 293 254 615 minecraft:light[level=13]
setblock 293 254 623 minecraft:light[level=13]
setblock 293 254 631 minecraft:light[level=13]
setblock 293 254 639 minecraft:light[level=13]
setblock 301 254 607 minecraft:light[level=13]
setblock 301 254 615 minecraft:light[level=13]
setblock 301 254 631 minecraft:light[level=13]
setblock 301 254 639 minecraft:light[level=13]
fill 307 254 611 307 255 611 minecraft:black_concrete
fill 307 254 637 307 255 637 minecraft:black_concrete
setblock 309 254 607 minecraft:light[level=13]
setblock 309 254 615 minecraft:light[level=13]
setblock 309 254 631 minecraft:light[level=13]
setblock 309 254 639 minecraft:light[level=13]
setblock 310 254 610 minecraft:black_concrete
setblock 310 254 618 minecraft:blackstone
setblock 310 254 630 minecraft:blackstone
setblock 310 254 638 minecraft:black_concrete
fill 310 254 646 310 276 646 minecraft:white_concrete
setblock 311 254 646 minecraft:amethyst_block
fill 312 254 617 312 255 618 minecraft:blackstone
fill 312 254 630 312 255 631 minecraft:blackstone
setblock 317 254 607 minecraft:light[level=13]
setblock 317 254 615 minecraft:light[level=13]
setblock 317 254 623 minecraft:light[level=13]
setblock 317 254 631 minecraft:light[level=13]
setblock 317 254 639 minecraft:light[level=13]
fill 324 254 627 324 267 627 minecraft:white_concrete
fill 282 255 612 282 260 612 minecraft:white_concrete
setblock 282 255 619 minecraft:pearlescent_froglight
fill 282 255 628 282 260 628 minecraft:white_concrete
setblock 282 255 644 minecraft:white_concrete
fill 286 255 604 286 260 604 minecraft:white_concrete
fill 296 255 646 296 260 646 minecraft:white_concrete
setblock 302 255 604 minecraft:pearlescent_froglight
fill 311 255 646 312 260 646 minecraft:white_concrete
fill 312 255 616 313 256 616 minecraft:blackstone
fill 312 255 632 313 256 632 minecraft:blackstone
fill 313 255 617 313 256 617 minecraft:blackstone
fill 313 255 631 313 256 631 minecraft:blackstone
fill 318 255 604 318 260 604 minecraft:white_concrete
fill 320 255 605 320 258 605 minecraft:amethyst_block
fill 324 255 614 324 260 614 minecraft:white_concrete
fill 324 255 630 324 260 630 minecraft:white_concrete
fill 282 256 619 282 307 619 minecraft:white_concrete
setblock 282 256 644 minecraft:amethyst_block
fill 302 256 604 302 260 604 minecraft:white_concrete
setblock 312 256 617 minecraft:blackstone
setblock 312 256 631 minecraft:blackstone
fill 319 256 605 319 257 606 minecraft:amethyst_block
fill 320 256 606 320 258 607 minecraft:amethyst_block
fill 321 256 605 321 257 606 minecraft:amethyst_block
fill 282 257 644 282 260 644 minecraft:white_concrete
setblock 313 257 616 minecraft:blackstone
setblock 313 257 632 minecraft:blackstone
fill 315 257 646 315 307 646 minecraft:white_concrete
setblock 316 257 646 minecraft:pearlescent_froglight
setblock 319 257 607 minecraft:amethyst_block
fill 320 257 608 320 258 609 minecraft:amethyst_block
setblock 321 257 607 minecraft:amethyst_block
fill 282 258 604 282 307 604 minecraft:white_concrete
setblock 282 258 605 minecraft:pearlescent_froglight
fill 316 258 646 316 285 646 minecraft:white_concrete
setblock 320 258 610 minecraft:amethyst_block
setblock 324 258 608 minecraft:pearlescent_froglight
fill 282 259 605 282 286 605 minecraft:white_concrete
fill 291 259 604 291 307 604 minecraft:white_concrete
setblock 292 259 604 minecraft:amethyst_block
fill 293 259 615 294 260 615 minecraft:amethyst_block
fill 324 259 608 324 307 608 minecraft:white_concrete
fill 292 260 604 292 273 604 minecraft:white_concrete
fill 303 260 604 303 307 604 minecraft:white_concrete
setblock 304 260 604 minecraft:amethyst_block
fill 305 260 604 305 307 604 minecraft:white_concrete
setblock 306 260 604 minecraft:pearlescent_froglight
fill 307 260 604 314 268 604 minecraft:white_concrete
fill 282 261 612 282 263 612 minecraft:gold_block
fill 282 261 628 282 263 628 minecraft:gold_block
fill 282 261 644 282 263 644 minecraft:gold_block
fill 286 261 604 286 263 604 minecraft:gold_block
fill 296 261 646 296 263 646 minecraft:gold_block
fill 302 261 604 302 263 604 minecraft:gold_block
fill 304 261 604 304 307 604 minecraft:white_concrete
fill 306 261 604 306 307 604 minecraft:white_concrete
fill 311 261 646 311 277 646 minecraft:white_concrete
fill 312 261 646 312 263 646 minecraft:gold_block
fill 318 261 604 318 263 604 minecraft:gold_block
fill 324 261 614 324 263 614 minecraft:gold_block
fill 324 261 630 324 263 630 minecraft:gold_block
setblock 285 262 607 minecraft:light[level=13]
setblock 285 262 615 minecraft:light[level=13]
setblock 285 262 623 minecraft:light[level=13]
setblock 285 262 631 minecraft:light[level=13]
setblock 285 262 639 minecraft:light[level=13]
fill 289 262 604 289 286 604 minecraft:white_concrete
setblock 290 262 604 minecraft:pearlescent_froglight
setblock 293 262 607 minecraft:light[level=13]
setblock 293 262 615 minecraft:light[level=13]
setblock 293 262 623 minecraft:light[level=13]
setblock 293 262 631 minecraft:light[level=13]
setblock 293 262 639 minecraft:light[level=13]
fill 295 262 604 295 307 604 minecraft:white_concrete
setblock 296 262 604 minecraft:amethyst_block
setblock 301 262 607 minecraft:light[level=13]
setblock 301 262 615 minecraft:light[level=13]
setblock 301 262 623 minecraft:light[level=13]
setblock 301 262 631 minecraft:light[level=13]
setblock 301 262 639 minecraft:light[level=13]
setblock 302 262 646 minecraft:pearlescent_froglight
setblock 309 262 607 minecraft:light[level=13]
setblock 309 262 615 minecraft:light[level=13]
setblock 309 262 623 minecraft:light[level=13]
setblock 309 262 631 minecraft:light[level=13]
setblock 309 262 639 minecraft:light[level=13]
setblock 317 262 607 minecraft:light[level=13]
setblock 317 262 615 minecraft:light[level=13]
setblock 317 262 623 minecraft:light[level=13]
setblock 317 262 631 minecraft:light[level=13]
setblock 317 262 639 minecraft:light[level=13]
fill 290 263 604 290 299 604 minecraft:white_concrete
fill 296 263 604 296 307 604 minecraft:white_concrete
fill 302 263 646 302 269 646 minecraft:white_concrete
fill 324 263 609 324 307 609 minecraft:white_concrete
setblock 324 263 610 minecraft:amethyst_block
fill 324 263 611 324 307 612 minecraft:white_concrete
fill 282 264 612 282 269 612 minecraft:white_concrete
fill 282 264 628 282 269 628 minecraft:white_concrete
fill 282 264 644 282 269 644 minecraft:white_concrete
fill 286 264 604 286 269 604 minecraft:white_concrete
fill 290 264 626 291 265 627 minecraft:white_concrete
fill 296 264 646 296 269 646 minecraft:white_concrete
fill 302 264 604 302 269 604 minecraft:white_concrete
setblock 303 264 646 minecraft:amethyst_block
fill 304 264 646 304 307 646 minecraft:white_concrete
fill 312 264 646 312 269 646 minecraft:white_concrete
fill 318 264 604 318 269 604 minecraft:white_concrete
fill 324 264 610 324 307 610 minecraft:white_concrete
fill 324 264 614 324 269 614 minecraft:white_concrete
fill 324 264 630 324 269 630 minecraft:white_concrete
fill 303 265 646 303 274 646 minecraft:white_concrete
setblock 282 266 607 minecraft:pearlescent_froglight
fill 282 266 608 282 307 609 minecraft:white_concrete
fill 306 266 643 308 269 645 minecraft:amethyst_block
setblock 316 266 604 minecraft:pearlescent_froglight
fill 317 266 604 317 280 604 minecraft:white_concrete
setblock 324 266 626 minecraft:pearlescent_froglight
fill 282 267 607 282 307 607 minecraft:white_concrete
fill 305 267 643 305 268 645 minecraft:amethyst_block
fill 306 267 642 308 269 642 minecraft:amethyst_block
fill 307 267 641 307 270 641 minecraft:amethyst_block
fill 309 267 643 309 268 645 minecraft:amethyst_block
fill 316 267 604 316 271 604 minecraft:white_concrete
fill 318 267 646 319 269 646 minecraft:white_concrete
setblock 320 267 646 minecraft:amethyst_block
fill 324 267 626 324 307 626 minecraft:white_concrete
setblock 324 267 635 minecraft:pearlescent_froglight
fill 324 267 636 324 307 640 minecraft:white_concrete
fill 287 268 646 287 307 646 minecraft:white_concrete
setblock 288 268 646 minecraft:amethyst_block
fill 289 268 646 289 307 646 minecraft:white_concrete
setblock 300 268 646 minecraft:amethyst_block
fill 306 268 641 306 269 641 minecraft:amethyst_block
fill 307 268 640 307 270 640 minecraft:amethyst_block
fill 308 268 641 308 269 641 minecraft:amethyst_block
fill 320 268 646 320 307 646 minecraft:white_concrete
setblock 324 268 625 minecraft:pearlescent_froglight
setblock 324 268 627 minecraft:pearlescent_froglight
fill 324 268 635 324 307 635 minecraft:white_concrete
fill 288 269 646 288 307 646 minecraft:white_concrete
fill 300 269 646 300 307 646 minecraft:white_concrete
setblock 306 269 640 minecraft:amethyst_block
fill 307 269 604 309 307 604 minecraft:white_concrete
fill 307 269 639 307 270 639 minecraft:amethyst_block
setblock 308 269 640 minecraft:amethyst_block
setblock 310 269 604 minecraft:pearlescent_froglight
fill 311 269 604 314 274 604 minecraft:white_concrete
fill 324 269 625 324 307 625 minecraft:white_concrete
fill 324 269 627 324 307 627 minecraft:white_concrete
fill 282 270 612 282 272 612 minecraft:gold_block
fill 282 270 628 282 272 628 minecraft:gold_block
fill 282 270 644 282 272 644 minecraft:gold_block
setblock 285 270 607 minecraft:light[level=13]
setblock 285 270 615 minecraft:light[level=13]
setblock 285 270 623 minecraft:light[level=13]
setblock 285 270 631 minecraft:light[level=13]
setblock 285 270 639 minecraft:light[level=13]
fill 286 270 604 286 272 604 minecraft:gold_block
setblock 293 270 607 minecraft:light[level=13]
setblock 293 270 615 minecraft:light[level=13]
setblock 293 270 623 minecraft:light[level=13]
setblock 293 270 631 minecraft:light[level=13]
setblock 293 270 639 minecraft:light[level=13]
fill 296 270 646 296 272 646 minecraft:gold_block
setblock 301 270 607 minecraft:light[level=13]
setblock 301 270 615 minecraft:light[level=13]
setblock 301 270 623 minecraft:light[level=13]
setblock 301 270 631 minecraft:light[level=13]
setblock 301 270 639 minecraft:light[level=13]
fill 302 270 604 302 272 604 minecraft:gold_block
setblock 302 270 646 minecraft:pearlescent_froglight
setblock 307 270 638 minecraft:amethyst_block
setblock 307 270 642 minecraft:amethyst_block
setblock 309 270 607 minecraft:light[level=13]
setblock 309 270 615 minecraft:light[level=13]
setblock 309 270 623 minecraft:light[level=13]
setblock 309 270 631 minecraft:light[level=13]
setblock 309 270 639 minecraft:light[level=13]
fill 310 270 604 310 288 604 minecraft:white_concrete
fill 312 270 646 312 272 646 minecraft:gold_block
setblock 317 270 607 minecraft:light[level=13]
setblock 317 270 615 minecraft:light[level=13]
setblock 317 270 623 minecraft:light[level=13]
setblock 317 270 631 minecraft:light[level=13]
setblock 317 270 639 minecraft:light[level=13]
fill 318 270 604 318 272 604 minecraft:gold_block
setblock 318 270 646 minecraft:amethyst_block
fill 319 270 646 319 307 646 minecraft:white_concrete
fill 324 270 614 324 272 614 minecraft:gold_block
fill 324 270 630 324 272 630 minecraft:gold_block
fill 292 271 646 292 307 646 minecraft:white_concrete
setblock 293 271 646 minecraft:pearlescent_froglight
fill 294 271 646 294 290 646 minecraft:white_concrete
fill 302 271 646 302 307 646 minecraft:white_concrete
fill 318 271 646 318 307 646 minecraft:white_concrete
fill 291 272 627 293 273 627 minecraft:white_concrete
fill 292 272 626 292 273 626 minecraft:white_concrete
fill 292 272 628 292 273 628 minecraft:white_concrete
fill 293 272 646 293 307 646 minecraft:white_concrete
setblock 316 272 604 minecraft:pearlescent_froglight
setblock 324 272 618 minecraft:amethyst_block
fill 282 273 612 282 287 612 minecraft:white_concrete
fill 282 273 628 282 287 628 minecraft:white_concrete
fill 282 273 644 282 287 644 minecraft:white_concrete
fill 286 273 604 286 277 604 minecraft:white_concrete
fill 296 273 646 296 287 646 minecraft:white_concrete
fill 302 273 604 302 287 604 minecraft:white_concrete
fill 312 273 646 312 287 646 minecraft:white_concrete
fill 316 273 604 316 307 604 minecraft:white_concrete
fill 318 273 604 318 287 604 minecraft:white_concrete
fill 324 273 614 324 287 614 minecraft:white_concrete
fill 324 273 618 324 307 618 minecraft:white_concrete
fill 324 273 630 324 287 630 minecraft:white_concrete
setblock 292 274 604 minecraft:amethyst_block
fill 321 274 604 321 282 604 minecraft:white_concrete
setblock 322 274 604 minecraft:amethyst_block
fill 323 274 604 323 307 604 minecraft:white_concrete
setblock 285 275 604 minecraft:pearlescent_froglight
fill 292 275 604 292 298 604 minecraft:white_concrete
setblock 303 275 646 minecraft:pearlescent_froglight
fill 311 275 604 312 277 604 minecraft:white_concrete
setblock 313 275 604 minecraft:pearlescent_froglight
fill 314 275 604 314 280 604 minecraft:white_concrete
fill 322 275 604 322 307 604 minecraft:white_concrete
fill 285 276 604 285 296 604 minecraft:white_concrete
setblock 290 276 646 minecraft:amethyst_block
fill 303 276 646 303 307 646 minecraft:white_concrete
fill 313 276 604 313 307 604 minecraft:white_concrete
setblock 324 276 645 minecraft:pearlescent_froglight
fill 290 277 646 290 307 646 minecraft:white_concrete
setblock 310 277 646 minecraft:amethyst_block
fill 324 277 645 324 307 645 minecraft:white_concrete
setblock 285 278 607 minecraft:light[level=13]
setblock 285 278 615 minecraft:light[level=13]
setblock 285 278 623 minecraft:light[level=13]
setblock 285 278 631 minecraft:light[level=13]
setblock 285 278 639 minecraft:light[level=13]
setblock 286 278 604 minecraft:pearlescent_froglight
setblock 293 278 607 minecraft:light[level=13]
setblock 293 278 615 minecraft:light[level=13]
setblock 293 278 623 minecraft:light[level=13]
setblock 293 278 631 minecraft:light[level=13]
setblock 293 278 639 minecraft:light[level=13]
setblock 301 278 607 minecraft:light[level=13]
setblock 301 278 615 minecraft:light[level=13]
setblock 301 278 623 minecraft:light[level=13]
setblock 301 278 631 minecraft:light[level=13]
setblock 301 278 639 minecraft:light[level=13]
setblock 309 278 607 minecraft:light[level=13]
setblock 309 278 615 minecraft:light[level=13]
setblock 309 278 623 minecraft:light[level=13]
setblock 309 278 631 minecraft:light[level=13]
setblock 309 278 639 minecraft:light[level=13]
fill 310 278 646 310 307 646 minecraft:white_concrete
setblock 311 278 604 minecraft:amethyst_block
setblock 311 278 646 minecraft:pearlescent_froglight
fill 312 278 604 312 307 604 minecraft:white_concrete
setblock 314 278 646 minecraft:amethyst_block
setblock 317 278 607 minecraft:light[level=13]
setblock 317 278 615 minecraft:light[level=13]
setblock 317 278 623 minecraft:light[level=13]
setblock 317 278 631 minecraft:light[level=13]
setblock 317 278 639 minecraft:light[level=13]
fill 282 279 624 282 290 626 minecraft:white_concrete
setblock 282 279 627 minecraft:amethyst_block
fill 286 279 604 286 287 604 minecraft:white_concrete
fill 287 279 622 300 279 622 minecraft:gold_block
fill 290 279 615 293 280 615 minecraft:gold_block
fill 290 279 621 301 279 621 minecraft:gold_block
fill 290 279 623 301 279 623 minecraft:gold_block
fill 290 279 629 293 280 629 minecraft:gold_block
fill 291 279 616 296 280 616 minecraft:gold_block
fill 291 279 628 296 280 628 minecraft:gold_block
fill 292 279 617 314 279 617 minecraft:gold_block
fill 292 279 627 314 279 627 minecraft:gold_block
fill 293 279 618 313 279 618 minecraft:gold_block
fill 293 279 626 313 279 626 minecraft:gold_block
fill 295 279 619 311 279 619 minecraft:gold_block
fill 295 279 625 311 279 625 minecraft:gold_block
fill 296 279 609 296 280 612 minecraft:gold_block
fill 296 279 620 302 279 620 minecraft:gold_block
fill 296 279 624 302 279 624 minecraft:gold_block
fill 296 279 632 296 280 635 minecraft:gold_block
fill 297 279 610 297 280 615 minecraft:gold_block
fill 297 279 629 297 280 634 minecraft:gold_block
fill 298 279 611 298 279 616 minecraft:gold_block
fill 298 279 628 298 279 633 minecraft:gold_block
fill 299 279 612 299 279 616 minecraft:gold_block
fill 299 279 628 299 279 632 minecraft:gold_block
fill 300 279 614 300 279 616 minecraft:gold_block
fill 300 279 628 300 279 630 minecraft:gold_block
fill 301 279 615 308 279 616 minecraft:gold_block
fill 301 279 628 308 279 629 minecraft:gold_block
fill 302 279 609 304 279 614 minecraft:gold_block
fill 302 279 630 304 279 635 minecraft:gold_block
fill 303 279 606 303 280 608 minecraft:gold_block
fill 303 279 636 303 280 638 minecraft:gold_block
fill 304 279 620 310 279 620 minecraft:gold_block
fill 304 279 624 310 279 624 minecraft:gold_block
fill 305 279 621 316 279 621 minecraft:gold_block
fill 305 279 623 316 279 623 minecraft:gold_block
fill 306 279 614 309 279 614 minecraft:gold_block
fill 306 279 622 319 279 622 minecraft:gold_block
fill 306 279 630 309 279 630 minecraft:gold_block
fill 307 279 612 309 279 613 minecraft:gold_block
fill 307 279 631 309 279 632 minecraft:gold_block
fill 308 279 611 310 280 611 minecraft:gold_block
fill 308 279 633 310 280 633 minecraft:gold_block
fill 309 279 610 310 280 610 minecraft:gold_block
fill 309 279 615 309 280 615 minecraft:gold_block
fill 309 279 629 309 280 629 minecraft:gold_block
fill 309 279 634 310 280 634 minecraft:gold_block
fill 310 279 609 310 280 609 minecraft:gold_block
fill 310 279 612 310 280 612 minecraft:gold_block
fill 310 279 616 315 280 616 minecraft:gold_block
fill 310 279 628 315 280 628 minecraft:gold_block
fill 310 279 632 310 280 632 minecraft:gold_block
fill 310 279 635 310 280 635 minecraft:gold_block
fill 311 279 604 311 307 604 minecraft:white_concrete
fill 311 279 646 311 307 646 minecraft:white_concrete
fill 313 279 615 316 280 615 minecraft:gold_block
fill 313 279 629 316 280 629 minecraft:gold_block
fill 314 279 646 314 307 646 minecraft:white_concrete
setblock 282 280 613 minecraft:amethyst_block
fill 282 280 614 282 286 618 minecraft:white_concrete
setblock 282 280 623 minecraft:amethyst_block
fill 282 280 627 282 307 627 minecraft:white_concrete
setblock 283 280 605 minecraft:white_concrete
fill 283 280 606 283 280 609 minecraft:light_blue_concrete
setblock 283 280 610 minecraft:white_concrete
fill 283 280 611 283 280 614 minecraft:light_blue_concrete
setblock 283 280 615 minecraft:white_concrete
fill 283 280 616 283 280 619 minecraft:light_blue_concrete
setblock 283 280 620 minecraft:white_concrete
fill 283 280 621 283 280 624 minecraft:light_blue_concrete
setblock 283 280 625 minecraft:white_concrete
fill 283 280 626 283 280 629 minecraft:light_blue_concrete
setblock 283 280 630 minecraft:white_concrete
fill 283 280 631 283 280 634 minecraft:light_blue_concrete
setblock 283 280 635 minecraft:white_concrete
fill 283 280 636 283 280 639 minecraft:light_blue_concrete
setblock 283 280 640 minecraft:white_concrete
fill 283 280 641 283 280 644 minecraft:light_blue_concrete
setblock 283 280 645 minecraft:white_concrete
fill 284 280 605 287 280 605 minecraft:light_blue_concrete
setblock 284 280 606 minecraft:white_concrete
fill 284 280 607 284 280 610 minecraft:light_blue_concrete
setblock 284 280 611 minecraft:white_concrete
fill 284 280 612 284 280 615 minecraft:light_blue_concrete
setblock 284 280 616 minecraft:white_concrete
fill 284 280 617 284 280 620 minecraft:light_blue_concrete
setblock 284 280 621 minecraft:white_concrete
fill 284 280 622 284 280 625 minecraft:light_blue_concrete
setblock 284 280 626 minecraft:white_concrete
fill 284 280 627 284 280 630 minecraft:light_blue_concrete
setblock 284 280 631 minecraft:white_concrete
fill 284 280 632 284 280 635 minecraft:light_blue_concrete
setblock 284 280 636 minecraft:white_concrete
fill 284 280 637 284 280 640 minecraft:light_blue_concrete
setblock 284 280 641 minecraft:white_concrete
fill 284 280 642 284 280 645 minecraft:light_blue_concrete
fill 285 280 606 288 280 606 minecraft:light_blue_concrete
setblock 285 280 607 minecraft:white_concrete
fill 285 280 608 285 280 611 minecraft:light_blue_concrete
setblock 285 280 612 minecraft:white_concrete
fill 285 280 613 285 280 616 minecraft:light_blue_concrete
setblock 285 280 617 minecraft:white_concrete
fill 285 280 618 285 280 621 minecraft:light_blue_concrete
setblock 285 280 622 minecraft:white_concrete
fill 285 280 623 285 280 626 minecraft:light_blue_concrete
setblock 285 280 627 minecraft:white_concrete
fill 285 280 628 285 280 631 minecraft:light_blue_concrete
setblock 285 280 632 minecraft:white_concrete
fill 285 280 633 285 280 636 minecraft:light_blue_concrete
setblock 285 280 637 minecraft:white_concrete
fill 285 280 638 285 280 641 minecraft:light_blue_concrete
setblock 285 280 642 minecraft:white_concrete
fill 285 280 643 285 280 645 minecraft:light_blue_concrete
fill 286 280 607 289 280 607 minecraft:light_blue_concrete
setblock 286 280 608 minecraft:white_concrete
fill 286 280 609 286 280 612 minecraft:light_blue_concrete
setblock 286 280 613 minecraft:white_concrete
fill 286 280 614 286 280 617 minecraft:light_blue_concrete
setblock 286 280 618 minecraft:white_concrete
fill 286 280 619 286 280 622 minecraft:light_blue_concrete
setblock 286 280 623 minecraft:white_concrete
fill 286 280 624 286 280 627 minecraft:light_blue_concrete
setblock 286 280 628 minecraft:white_concrete
fill 286 280 629 286 280 632 minecraft:light_blue_concrete
setblock 286 280 633 minecraft:white_concrete
fill 286 280 634 286 280 637 minecraft:light_blue_concrete
setblock 286 280 638 minecraft:white_concrete
fill 286 280 639 286 280 642 minecraft:light_blue_concrete
setblock 286 280 643 minecraft:white_concrete
fill 286 280 644 286 280 645 minecraft:light_blue_concrete
fill 287 280 608 290 280 608 minecraft:light_blue_concrete
setblock 287 280 609 minecraft:white_concrete
fill 287 280 610 287 280 613 minecraft:light_blue_concrete
setblock 287 280 614 minecraft:white_concrete
fill 287 280 615 287 280 618 minecraft:light_blue_concrete
setblock 287 280 619 minecraft:white_concrete
fill 287 280 620 287 280 621 minecraft:light_blue_concrete
fill 287 280 622 291 280 622 minecraft:gold_block
fill 287 280 623 289 280 623 minecraft:light_blue_concrete
setblock 287 280 624 minecraft:white_concrete
fill 287 280 625 287 280 628 minecraft:light_blue_concrete
setblock 287 280 629 minecraft:white_concrete
fill 287 280 630 287 280 633 minecraft:light_blue_concrete
setblock 287 280 634 minecraft:white_concrete
fill 287 280 635 287 280 638 minecraft:light_blue_concrete
setblock 287 280 639 minecraft:white_concrete
fill 287 280 640 287 280 643 minecraft:light_blue_concrete
setblock 287 280 644 minecraft:white_concrete
setblock 287 280 645 minecraft:light_blue_concrete
setblock 288 280 605 minecraft:white_concrete
fill 288 280 609 291 280 609 minecraft:light_blue_concrete
setblock 288 280 610 minecraft:white_concrete
fill 288 280 611 288 280 614 minecraft:light_blue_concrete
setblock 288 280 615 minecraft:white_concrete
fill 288 280 616 288 280 619 minecraft:light_blue_concrete
setblock 288 280 620 minecraft:white_concrete
setblock 288 280 621 minecraft:light_blue_concrete
fill 288 280 624 291 280 624 minecraft:light_blue_concrete
setblock 288 280 625 minecraft:white_concrete
fill 288 280 626 288 280 629 minecraft:light_blue_concrete
setblock 288 280 630 minecraft:white_concrete
fill 288 280 631 288 280 634 minecraft:light_blue_concrete
setblock 288 280 635 minecraft:white_concrete
fill 288 280 636 288 280 639 minecraft:light_blue_concrete
setblock 288 280 640 minecraft:white_concrete
fill 288 280 641 288 280 644 minecraft:light_blue_concrete
setblock 288 280 645 minecraft:white_concrete
fill 289 280 605 292 280 605 minecraft:light_blue_concrete
setblock 289 280 606 minecraft:white_concrete
fill 289 280 610 292 280 610 minecraft:light_blue_concrete
setblock 289 280 611 minecraft:white_concrete
fill 289 280 612 289 280 615 minecraft:light_blue_concrete
setblock 289 280 616 minecraft:white_concrete
fill 289 280 617 289 280 620 minecraft:light_blue_concrete
setblock 289 280 621 minecraft:white_concrete
fill 289 280 625 292 280 625 minecraft:light_blue_concrete
setblock 289 280 626 minecraft:white_concrete
fill 289 280 627 289 280 630 minecraft:light_blue_concrete
setblock 289 280 631 minecraft:white_concrete
fill 289 280 632 289 280 635 minecraft:light_blue_concrete
setblock 289 280 636 minecraft:white_concrete
fill 289 280 637 289 280 640 minecraft:light_blue_concrete
setblock 289 280 641 minecraft:white_concrete
fill 289 280 642 289 280 645 minecraft:light_blue_concrete
fill 290 280 606 293 280 606 minecraft:light_blue_concrete
setblock 290 280 607 minecraft:white_concrete
fill 290 280 611 293 280 611 minecraft:light_blue_concrete
setblock 290 280 612 minecraft:white_concrete
fill 290 280 613 290 280 614 minecraft:light_blue_concrete
setblock 290 280 616 minecraft:light_blue_concrete
setblock 290 280 617 minecraft:white_concrete
fill 290 280 618 290 280 620 minecraft:light_blue_concrete
fill 290 280 621 294 280 621 minecraft:gold_block
fill 290 280 623 294 280 623 minecraft:gold_block
fill 290 280 626 292 280 626 minecraft:light_blue_concrete
setblock 290 280 627 minecraft:white_concrete
setblock 290 280 628 minecraft:light_blue_concrete
fill 290 280 630 292 280 631 minecraft:light_blue_concrete
setblock 290 280 632 minecraft:white_concrete
fill 290 280 633 290 280 636 minecraft:light_blue_concrete
setblock 290 280 637 minecraft:white_concrete
fill 290 280 638 290 280 641 minecraft:light_blue_concrete
setblock 290 280 642 minecraft:white_concrete
fill 290 280 643 290 280 645 minecraft:light_blue_concrete
fill 291 280 607 294 280 607 minecraft:light_blue_concrete
setblock 291 280 608 minecraft:white_concrete
fill 291 280 612 294 280 612 minecraft:light_blue_concrete
setblock 291 280 613 minecraft:white_concrete
setblock 291 280 614 minecraft:light_blue_concrete
setblock 291 280 617 minecraft:light_blue_concrete
setblock 291 280 618 minecraft:white_concrete
fill 291 280 619 291 280 620 minecraft:light_blue_concrete
setblock 291 280 627 minecraft:light_blue_concrete
fill 291 280 632 294 280 632 minecraft:light_blue_concrete
setblock 291 280 633 minecraft:white_concrete
fill 291 280 634 291 280 637 minecraft:light_blue_concrete
setblock 291 280 638 minecraft:white_concrete
fill 291 280 639 291 280 642 minecraft:light_blue_concrete
setblock 291 280 643 minecraft:white_concrete
fill 291 280 644 291 280 645 minecraft:light_blue_concrete
fill 292 280 608 295 280 608 minecraft:light_blue_concrete
setblock 292 280 609 minecraft:white_concrete
fill 292 280 613 295 280 613 minecraft:light_blue_concrete
setblock 292 280 614 minecraft:white_concrete
fill 292 280 617 293 280 617 minecraft:gold_block
setblock 292 280 618 minecraft:light_blue_concrete
setblock 292 280 619 minecraft:white_concrete
setblock 292 280 620 minecraft:light_blue_concrete
fill 292 280 622 298 280 622 minecraft:white_concrete
setblock 292 280 624 minecraft:white_concrete
fill 292 280 627 293 280 627 minecraft:gold_block
fill 292 280 633 295 280 633 minecraft:light_blue_concrete
setblock 292 280 634 minecraft:white_concrete
fill 292 280 635 292 280 638 minecraft:light_blue_concrete
setblock 292 280 639 minecraft:white_concrete
fill 292 280 640 292 280 643 minecraft:light_blue_concrete
setblock 292 280 644 minecraft:white_concrete
setblock 292 280 645 minecraft:light_blue_concrete
setblock 293 280 605 minecraft:white_concrete
fill 293 280 609 295 280 609 minecraft:light_blue_concrete
setblock 293 280 610 minecraft:white_concrete
fill 293 280 614 296 280 614 minecraft:light_blue_concrete
fill 293 280 618 294 280 618 minecraft:gold_block
fill 293 280 619 294 280 619 minecraft:light_blue_concrete
setblock 293 280 620 minecraft:white_concrete
fill 293 280 624 295 280 624 minecraft:light_blue_concrete
setblock 293 280 625 minecraft:white_concrete
fill 293 280 626 294 280 626 minecraft:gold_block
setblock 293 280 630 minecraft:white_concrete
setblock 293 280 631 minecraft:light_blue_concrete
fill 293 280 634 295 280 634 minecraft:light_blue_concrete
setblock 293 280 635 minecraft:white_concrete
fill 293 280 636 293 280 639 minecraft:light_blue_concrete
setblock 293 280 640 minecraft:white_concrete
fill 293 280 641 293 280 644 minecraft:light_blue_concrete
setblock 293 280 645 minecraft:white_concrete
fill 294 280 605 297 280 605 minecraft:light_blue_concrete
setblock 294 280 606 minecraft:white_concrete
fill 294 280 610 295 280 610 minecraft:light_blue_concrete
setblock 294 280 611 minecraft:white_concrete
fill 294 280 615 296 280 615 minecraft:light_blue_concrete
fill 294 280 617 296 280 617 minecraft:white_concrete
fill 294 280 620 295 280 620 minecraft:light_blue_concrete
setblock 294 280 625 minecraft:light_blue_concrete
fill 294 280 627 296 280 627 minecraft:white_concrete
fill 294 280 629 296 280 630 minecraft:light_blue_concrete
setblock 294 280 631 minecraft:white_concrete
fill 294 280 635 295 280 635 minecraft:light_blue_concrete
setblock 294 280 636 minecraft:white_concrete
fill 294 280 637 294 280 640 minecraft:light_blue_concrete
setblock 294 280 641 minecraft:white_concrete
fill 294 280 642 294 280 645 minecraft:light_blue_concrete
fill 295 280 606 298 280 606 minecraft:light_blue_concrete
setblock 295 280 607 minecraft:white_concrete
setblock 295 280 611 minecraft:light_blue_concrete
setblock 295 280 612 minecraft:white_concrete
fill 295 280 618 298 280 618 minecraft:white_concrete
setblock 295 280 619 minecraft:gold_block
fill 295 280 621 299 280 621 minecraft:white_concrete
fill 295 280 623 299 280 623 minecraft:white_concrete
setblock 295 280 625 minecraft:gold_block
fill 295 280 626 298 280 626 minecraft:white_concrete
fill 295 280 631 296 280 631 minecraft:light_blue_concrete
setblock 295 280 632 minecraft:white_concrete
fill 295 280 636 298 280 636 minecraft:light_blue_concrete
setblock 295 280 637 minecraft:white_concrete
fill 295 280 638 295 280 641 minecraft:light_blue_concrete
setblock 295 280 642 minecraft:white_concrete
fill 295 280 643 295 280 645 minecraft:light_blue_concrete
fill 296 280 607 299 280 607 minecraft:light_blue_concrete
setblock 296 280 608 minecraft:white_concrete
setblock 296 280 613 minecraft:white_concrete
fill 296 280 619 300 280 619 minecraft:white_concrete
setblock 296 280 620 minecraft:gold_block
setblock 296 280 624 minecraft:gold_block
fill 296 280 625 300 280 625 minecraft:white_concrete
fill 296 280 637 299 280 637 minecraft:light_blue_concrete
setblock 296 280 638 minecraft:white_concrete
fill 296 280 639 296 280 642 minecraft:light_blue_concrete
setblock 296 280 643 minecraft:white_concrete
fill 296 280 644 296 280 645 minecraft:light_blue_concrete
fill 297 280 608 300 280 608 minecraft:light_blue_concrete
setblock 297 280 609 minecraft:white_concrete
setblock 297 280 616 minecraft:light_blue_concrete
fill 297 280 617 298 280 617 minecraft:gold_block
fill 297 280 620 299 280 620 minecraft:white_concrete
fill 297 280 624 299 280 624 minecraft:white_concrete
fill 297 280 627 298 280 627 minecraft:gold_block
setblock 297 280 628 minecraft:light_blue_concrete
setblock 297 280 635 minecraft:light_blue_concrete
fill 297 280 638 300 280 638 minecraft:light_blue_concrete
setblock 297 280 639 minecraft:white_concrete
fill 297 280 640 297 280 643 minecraft:light_blue_concrete
setblock 297 280 644 minecraft:white_concrete
setblock 297 280 645 minecraft:light_blue_concrete
setblock 298 280 605 minecraft:white_concrete
fill 298 280 609 301 280 609 minecraft:light_blue_concrete
setblock 298 280 610 minecraft:white_concrete
fill 298 280 611 298 280 612 minecraft:gold_block
fill 298 280 613 298 280 615 minecraft:white_concrete
setblock 298 280 616 minecraft:gold_block
setblock 298 280 628 minecraft:gold_block
fill 298 280 629 298 280 631 minecraft:white_concrete
fill 298 280 632 298 280 633 minecraft:gold_block
fill 298 280 634 301 280 634 minecraft:light_blue_concrete
setblock 298 280 635 minecraft:white_concrete
fill 298 280 639 301 280 639 minecraft:light_blue_concrete
setblock 298 280 640 minecraft:white_concrete
fill 298 280 641 298 280 644 minecraft:light_blue_concrete
setblock 298 280 645 minecraft:white_concrete
fill 299 280 605 302 280 605 minecraft:light_blue_concrete
setblock 299 280 606 minecraft:white_concrete
fill 299 280 610 301 280 610 minecraft:light_blue_concrete
setblock 299 280 611 minecraft:white_concrete
fill 299 280 612 299 280 613 minecraft:gold_block
fill 299 280 614 299 280 617 minecraft:white_concrete
setblock 299 280 618 minecraft:gold_block
fill 299 280 622 300 280 622 minecraft:pearlescent_froglight
setblock 299 280 626 minecraft:gold_block
fill 299 280 627 299 280 630 minecraft:white_concrete
fill 299 280 631 299 280 632 minecraft:gold_block
fill 299 280 633 300 280 633 minecraft:light_blue_concrete
fill 299 280 635 301 280 635 minecraft:light_blue_concrete
setblock 299 280 636 minecraft:white_concrete
fill 299 280 640 302 280 640 minecraft:light_blue_concrete
setblock 299 280 641 minecraft:white_concrete
fill 299 280 642 299 280 645 minecraft:light_blue_concrete
fill 300 280 606 302 280 606 minecraft:light_blue_concrete
setblock 300 280 607 minecraft:white_concrete
fill 300 280 611 301 280 611 minecraft:light_blue_concrete
setblock 300 280 612 minecraft:white_concrete
setblock 300 280 613 minecraft:light_blue_concrete
setblock 300 280 614 minecraft:gold_block
fill 300 280 615 300 280 618 minecraft:white_concrete
fill 300 280 620 301 280 621 minecraft:pearlescent_froglight
fill 300 280 623 301 280 624 minecraft:pearlescent_froglight
fill 300 280 626 300 280 629 minecraft:white_concrete
setblock 300 280 630 minecraft:gold_block
fill 300 280 631 301 280 631 minecraft:light_blue_concrete
setblock 300 280 632 minecraft:white_concrete
fill 300 280 636 302 280 636 minecraft:light_blue_concrete
setblock 300 280 637 minecraft:white_concrete
fill 300 280 641 303 280 641 minecraft:light_blue_concrete
setblock 300 280 642 minecraft:white_concrete
fill 300 280 643 300 280 645 minecraft:light_blue_concrete
fill 301 280 607 302 280 607 minecraft:light_blue_concrete
setblock 301 280 608 minecraft:white_concrete
setblock 301 280 612 minecraft:light_blue_concrete
setblock 301 280 613 minecraft:white_concrete
setblock 301 280 614 minecraft:light_blue_concrete
setblock 301 280 615 minecraft:gold_block
fill 301 280 616 302 280 618 minecraft:white_concrete
fill 301 280 619 305 280 619 minecraft:pearlescent_froglight
fill 301 280 625 305 280 625 minecraft:pearlescent_froglight
fill 301 280 626 302 280 628 minecraft:white_concrete
setblock 301 280 629 minecraft:gold_block
setblock 301 280 630 minecraft:light_blue_concrete
setblock 301 280 632 minecraft:light_blue_concrete
setblock 301 280 633 minecraft:white_concrete
fill 301 280 637 302 280 637 minecraft:light_blue_concrete
setblock 301 280 638 minecraft:white_concrete
fill 301 280 642 304 280 642 minecraft:light_blue_concrete
setblock 301 280 643 minecraft:white_concrete
fill 301 280 644 301 280 645 minecraft:light_blue_concrete
setblock 302 280 608 minecraft:light_blue_concrete
fill 302 280 609 302 280 613 minecraft:gold_block
fill 302 280 614 304 280 615 minecraft:white_concrete
setblock 302 280 620 minecraft:pearlescent_froglight
setblock 302 280 624 minecraft:pearlescent_froglight
fill 302 280 629 304 280 630 minecraft:white_concrete
fill 302 280 631 302 280 635 minecraft:gold_block
setblock 302 280 638 minecraft:light_blue_concrete
setblock 302 280 639 minecraft:white_concrete
fill 302 280 643 305 280 643 minecraft:light_blue_concrete
setblock 302 280 644 minecraft:white_concrete
setblock 302 280 645 minecraft:light_blue_concrete
setblock 303 280 605 minecraft:white_concrete
fill 303 280 609 304 280 610 minecraft:gold_block
fill 303 280 611 303 280 613 minecraft:white_concrete
fill 303 280 616 307 280 617 minecraft:white_concrete
setblock 303 280 618 minecraft:pearlescent_froglight
setblock 303 280 626 minecraft:pearlescent_froglight
fill 303 280 627 307 280 628 minecraft:white_concrete
fill 303 280 631 303 280 633 minecraft:white_concrete
fill 303 280 634 304 280 635 minecraft:gold_block
fill 303 280 639 306 280 639 minecraft:light_blue_concrete
setblock 303 280 640 minecraft:white_concrete
fill 303 280 644 306 280 644 minecraft:light_blue_concrete
setblock 303 280 645 minecraft:white_concrete
fill 304 280 605 307 280 605 minecraft:light_blue_concrete
setblock 304 280 606 minecraft:white_concrete
fill 304 280 607 304 280 608 minecraft:light_blue_concrete
fill 304 280 611 304 280 613 minecraft:gold_block
fill 304 280 618 306 280 618 minecraft:white_concrete
fill 304 280 620 306 280 620 minecraft:pearlescent_froglight
fill 304 280 624 306 280 624 minecraft:pearlescent_froglight
fill 304 280 626 306 280 626 minecraft:white_concrete
fill 304 280 631 304 280 633 minecraft:gold_block
setblock 304 280 636 minecraft:white_concrete
fill 304 280 637 304 280 638 minecraft:light_blue_concrete
fill 304 280 640 307 280 640 minecraft:light_blue_concrete
setblock 304 280 641 minecraft:white_concrete
fill 304 280 645 307 280 645 minecraft:light_blue_concrete
fill 305 280 606 308 280 606 minecraft:light_blue_concrete
setblock 305 280 607 minecraft:white_concrete
fill 305 280 608 305 280 611 minecraft:light_blue_concrete
setblock 305 280 612 minecraft:white_concrete
fill 305 280 613 305 280 614 minecraft:light_blue_concrete
setblock 305 280 615 minecraft:gold_block
fill 305 280 621 306 280 621 minecraft:pearlescent_froglight
fill 305 280 623 306 280 623 minecraft:pearlescent_froglight
setblock 305 280 629 minecraft:gold_block
fill 305 280 630 305 280 631 minecraft:light_blue_concrete
setblock 305 280 632 minecraft:white_concrete
fill 305 280 633 305 280 636 minecraft:light_blue_concrete
setblock 305 280 637 minecraft:white_concrete
setblock 305 280 638 minecraft:light_blue_concrete
fill 305 280 641 308 280 641 minecraft:light_blue_concrete
setblock 305 280 642 minecraft:white_concrete
fill 306 280 607 309 280 607 minecraft:light_blue_concrete
setblock 306 280 608 minecraft:white_concrete
fill 306 280 609 306 280 612 minecraft:light_blue_concrete
setblock 306 280 613 minecraft:white_concrete
setblock 306 280 614 minecraft:gold_block
fill 306 280 615 308 280 615 minecraft:white_concrete
fill 306 280 619 310 280 619 minecraft:white_concrete
fill 306 280 622 307 280 622 minecraft:pearlescent_froglight
fill 306 280 625 310 280 625 minecraft:white_concrete
fill 306 280 629 308 280 629 minecraft:white_concrete
setblock 306 280 630 minecraft:gold_block
fill 306 280 631 306 280 632 minecraft:light_blue_concrete
setblock 306 280 633 minecraft:white_concrete
fill 306 280 634 306 280 637 minecraft:light_blue_concrete
setblock 306 280 638 minecraft:white_concrete
fill 306 280 642 309 280 642 minecraft:light_blue_concrete
setblock 306 280 643 minecraft:white_concrete
fill 307 280 608 310 280 608 minecraft:light_blue_concrete
setblock 307 280 609 minecraft:white_concrete
fill 307 280 610 307 280 611 minecraft:light_blue_concrete
fill 307 280 612 307 280 613 minecraft:gold_block
fill 307 280 614 308 280 614 minecraft:white_concrete
setblock 307 280 618 minecraft:gold_block
fill 307 280 620 309 280 621 minecraft:white_concrete
fill 307 280 623 309 280 624 minecraft:white_concrete
setblock 307 280 626 minecraft:gold_block
fill 307 280 630 308 280 630 minecraft:white_concrete
fill 307 280 631 307 280 632 minecraft:gold_block
setblock 307 280 633 minecraft:light_blue_concrete
setblock 307 280 634 minecraft:white_concrete
fill 307 280 635 307 280 638 minecraft:light_blue_concrete
setblock 307 280 639 minecraft:white_concrete
fill 307 280 643 310 280 643 minecraft:light_blue_concrete
setblock 307 280 644 minecraft:white_concrete
setblock 308 280 605 minecraft:white_concrete
fill 308 280 609 309 280 609 minecraft:light_blue_concrete
setblock 308 280 610 minecraft:white_concrete
fill 308 280 612 309 280 612 minecraft:gold_block
setblock 308 280 613 minecraft:white_concrete
fill 308 280 616 308 280 617 minecraft:gold_block
fill 308 280 618 311 280 618 minecraft:white_concrete
fill 308 280 622 314 280 622 minecraft:white_concrete
fill 308 280 626 311 280 626 minecraft:white_concrete
fill 308 280 627 308 280 628 minecraft:gold_block
setblock 308 280 631 minecraft:white_concrete
fill 308 280 632 309 280 632 minecraft:gold_block
setblock 308 280 634 minecraft:light_blue_concrete
setblock 308 280 635 minecraft:white_concrete
fill 308 280 636 308 280 639 minecraft:light_blue_concrete
setblock 308 280 640 minecraft:white_concrete
fill 308 280 644 311 280 644 minecraft:light_blue_concrete
setblock 308 280 645 minecraft:white_concrete
fill 309 280 605 312 280 605 minecraft:light_blue_concrete
setblock 309 280 606 minecraft:white_concrete
fill 309 280 613 309 280 614 minecraft:gold_block
setblock 309 280 616 minecraft:white_concrete
setblock 309 280 617 minecraft:gold_block
setblock 309 280 627 minecraft:gold_block
setblock 309 280 628 minecraft:light_blue_concrete
fill 309 280 630 309 280 631 minecraft:gold_block
setblock 309 280 635 minecraft:light_blue_concrete
setblock 309 280 636 minecraft:white_concrete
fill 309 280 637 309 280 640 minecraft:light_blue_concrete
setblock 309 280 641 minecraft:white_concrete
fill 309 280 645 312 280 645 minecraft:light_blue_concrete
fill 310 280 606 313 280 606 minecraft:light_blue_concrete
setblock 310 280 607 minecraft:white_concrete
fill 310 280 613 310 280 615 minecraft:light_blue_concrete
fill 310 280 617 312 280 617 minecraft:white_concrete
setblock 310 280 620 minecraft:gold_block
fill 310 280 621 311 280 621 minecraft:white_concrete
fill 310 280 623 311 280 623 minecraft:white_concrete
setblock 310 280 624 minecraft:gold_block
fill 310 280 627 312 280 627 minecraft:white_concrete
fill 310 280 629 311 280 631 minecraft:light_blue_concrete
fill 310 280 636 313 280 636 minecraft:light_blue_concrete
setblock 310 280 637 minecraft:white_concrete
fill 310 280 638 310 280 641 minecraft:light_blue_concrete
setblock 310 280 642 minecraft:white_concrete
fill 311 280 607 314 280 607 minecraft:light_blue_concrete
setblock 311 280 608 minecraft:white_concrete
fill 311 280 609 311 280 612 minecraft:light_blue_concrete
setblock 311 280 613 minecraft:white_concrete
fill 311 280 614 311 280 615 minecraft:light_blue_concrete
setblock 311 280 619 minecraft:gold_block
fill 311 280 620 312 280 620 minecraft:light_blue_concrete
setblock 311 280 624 minecraft:light_blue_concrete
setblock 311 280 625 minecraft:gold_block
fill 311 280 632 314 280 632 minecraft:light_blue_concrete
setblock 311 280 633 minecraft:white_concrete
fill 311 280 634 311 280 635 minecraft:light_blue_concrete
fill 311 280 637 314 280 637 minecraft:light_blue_concrete
setblock 311 280 638 minecraft:white_concrete
fill 311 280 639 311 280 642 minecraft:light_blue_concrete
setblock 311 280 643 minecraft:white_concrete
fill 312 280 608 315 280 608 minecraft:light_blue_concrete
setblock 312 280 609 minecraft:white_concrete
fill 312 280 610 312 280 613 minecraft:light_blue_concrete
setblock 312 280 614 minecraft:white_concrete
setblock 312 280 615 minecraft:light_blue_concrete
fill 312 280 618 313 280 618 minecraft:gold_block
setblock 312 280 619 minecraft:white_concrete
fill 312 280 621 316 280 621 minecraft:gold_block
fill 312 280 623 316 280 623 minecraft:gold_block
setblock 312 280 624 minecraft:white_concrete
setblock 312 280 625 minecraft:light_blue_concrete
fill 312 280 626 313 280 626 minecraft:gold_block
setblock 312 280 629 minecraft:white_concrete
fill 312 280 630 312 280 631 minecraft:light_blue_concrete
fill 312 280 633 315 280 633 minecraft:light_blue_concrete
setblock 312 280 634 minecraft:white_concrete
setblock 312 280 635 minecraft:light_blue_concrete
fill 312 280 638 315 280 638 minecraft:light_blue_concrete
setblock 312 280 639 minecraft:white_concrete
fill 312 280 640 312 280 643 minecraft:light_blue_concrete
setblock 312 280 644 minecraft:white_concrete
setblock 313 280 605 minecraft:white_concrete
fill 313 280 609 316 280 609 minecraft:light_blue_concrete
setblock 313 280 610 minecraft:white_concrete
fill 313 280 611 313 280 614 minecraft:light_blue_concrete
fill 313 280 617 314 280 617 minecraft:gold_block
fill 313 280 619 316 280 619 minecraft:light_blue_concrete
setblock 313 280 620 minecraft:white_concrete
fill 313 280 624 316 280 624 minecraft:light_blue_concrete
setblock 313 280 625 minecraft:white_concrete
fill 313 280 627 314 280 627 minecraft:gold_block
setblock 313 280 630 minecraft:white_concrete
setblock 313 280 631 minecraft:light_blue_concrete
fill 313 280 634 316 280 634 minecraft:light_blue_concrete
setblock 313 280 635 minecraft:white_concrete
fill 313 280 639 316 280 639 minecraft:light_blue_concrete
setblock 313 280 640 minecraft:white_concrete
fill 313 280 641 313 280 644 minecraft:light_blue_concrete
setblock 313 280 645 minecraft:white_concrete
fill 314 280 605 317 280 605 minecraft:light_blue_concrete
setblock 314 280 606 minecraft:white_concrete
fill 314 280 610 317 280 610 minecraft:light_blue_concrete
setblock 314 280 611 minecraft:white_concrete
fill 314 280 612 314 280 614 minecraft:light_blue_concrete
fill 314 280 618 315 280 618 minecraft:light_blue_concrete
fill 314 280 620 317 280 620 minecraft:light_blue_concrete
fill 314 280 625 317 280 625 minecraft:light_blue_concrete
setblock 314 280 626 minecraft:white_concrete
fill 314 280 630 317 280 630 minecraft:light_blue_concrete
setblock 314 280 631 minecraft:white_concrete
fill 314 280 635 317 280 635 minecraft:light_blue_concrete
setblock 314 280 636 minecraft:white_concrete
fill 314 280 640 317 280 640 minecraft:light_blue_concrete
setblock 314 280 641 minecraft:white_concrete
fill 314 280 642 314 280 645 minecraft:light_blue_concrete
fill 315 280 606 318 280 606 minecraft:light_blue_concrete
setblock 315 280 607 minecraft:white_concrete
fill 315 280 611 318 280 611 minecraft:light_blue_concrete
setblock 315 280 612 minecraft:white_concrete
fill 315 280 613 315 280 614 minecraft:light_blue_concrete
setblock 315 280 617 minecraft:white_concrete
fill 315 280 622 319 280 622 minecraft:gold_block
fill 315 280 626 318 280 626 minecraft:light_blue_concrete
setblock 315 280 627 minecraft:white_concrete
fill 315 280 631 318 280 631 minecraft:light_blue_concrete
setblock 315 280 632 minecraft:white_concrete
fill 315 280 636 318 280 636 minecraft:light_blue_concrete
setblock 315 280 637 minecraft:white_concrete
fill 315 280 641 318 280 641 minecraft:light_blue_concrete
setblock 315 280 642 minecraft:white_concrete
fill 315 280 643 315 280 645 minecraft:light_blue_concrete
fill 316 280 607 319 280 607 minecraft:light_blue_concrete
setblock 316 280 608 minecraft:white_concrete
fill 316 280 612 319 280 612 minecraft:light_blue_concrete
setblock 316 280 613 minecraft:white_concrete
setblock 316 280 614 minecraft:light_blue_concrete
fill 316 280 616 318 280 617 minecraft:light_blue_concrete
setblock 316 280 618 minecraft:white_concrete
fill 316 280 627 319 280 627 minecraft:light_blue_concrete
setblock 316 280 628 minecraft:white_concrete
fill 316 280 632 319 280 632 minecraft:light_blue_concrete
setblock 316 280 633 minecraft:white_concrete
fill 316 280 637 319 280 637 minecraft:light_blue_concrete
setblock 316 280 638 minecraft:white_concrete
fill 316 280 642 319 280 642 minecraft:light_blue_concrete
setblock 316 280 643 minecraft:white_concrete
fill 316 280 644 316 280 645 minecraft:light_blue_concrete
fill 317 280 608 320 280 608 minecraft:light_blue_concrete
setblock 317 280 609 minecraft:white_concrete
fill 317 280 613 320 280 613 minecraft:light_blue_concrete
setblock 317 280 614 minecraft:white_concrete
setblock 317 280 615 minecraft:light_blue_concrete
fill 317 280 618 320 280 618 minecraft:light_blue_concrete
setblock 317 280 619 minecraft:white_concrete
fill 317 280 621 318 280 621 minecraft:light_blue_concrete
fill 317 280 623 320 280 623 minecraft:light_blue_concrete
setblock 317 280 624 minecraft:white_concrete
fill 317 280 628 320 280 628 minecraft:light_blue_concrete
setblock 317 280 629 minecraft:white_concrete
fill 317 280 633 320 280 633 minecraft:light_blue_concrete
setblock 317 280 634 minecraft:white_concrete
fill 317 280 638 320 280 638 minecraft:light_blue_concrete
setblock 317 280 639 minecraft:white_concrete
fill 317 280 643 320 280 643 minecraft:light_blue_concrete
setblock 317 280 644 minecraft:white_concrete
setblock 317 280 645 minecraft:light_blue_concrete
setblock 318 280 605 minecraft:white_concrete
fill 318 280 609 321 280 609 minecraft:light_blue_concrete
setblock 318 280 610 minecraft:white_concrete
fill 318 280 614 321 280 614 minecraft:light_blue_concrete
setblock 318 280 615 minecraft:white_concrete
fill 318 280 619 321 280 619 minecraft:light_blue_concrete
setblock 318 280 620 minecraft:white_concrete
fill 318 280 624 321 280 624 minecraft:light_blue_concrete
setblock 318 280 625 minecraft:white_concrete
fill 318 280 629 321 280 629 minecraft:light_blue_concrete
setblock 318 280 630 minecraft:white_concrete
fill 318 280 634 321 280 634 minecraft:light_blue_concrete
setblock 318 280 635 minecraft:white_concrete
fill 318 280 639 321 280 639 minecraft:light_blue_concrete
setblock 318 280 640 minecraft:white_concrete
fill 318 280 644 321 280 644 minecraft:light_blue_concrete
setblock 318 280 645 minecraft:white_concrete
fill 319 280 605 322 280 605 minecraft:light_blue_concrete
setblock 319 280 606 minecraft:white_concrete
fill 319 280 610 322 280 610 minecraft:light_blue_concrete
setblock 319 280 611 minecraft:white_concrete
fill 319 280 615 322 280 615 minecraft:light_blue_concrete
setblock 319 280 616 minecraft:white_concrete
setblock 319 280 617 minecraft:light_blue_concrete
fill 319 280 620 322 280 620 minecraft:light_blue_concrete
setblock 319 280 621 minecraft:white_concrete
fill 319 280 625 322 280 625 minecraft:light_blue_concrete
setblock 319 280 626 minecraft:white_concrete
fill 319 280 630 322 280 630 minecraft:light_blue_concrete
setblock 319 280 631 minecraft:white_concrete
fill 319 280 635 322 280 635 minecraft:light_blue_concrete
setblock 319 280 636 minecraft:white_concrete
fill 319 280 640 322 280 640 minecraft:light_blue_concrete
setblock 319 280 641 minecraft:white_concrete
fill 319 280 645 322 280 645 minecraft:light_blue_concrete
fill 320 280 606 323 280 606 minecraft:light_blue_concrete
setblock 320 280 607 minecraft:white_concrete
fill 320 280 611 323 280 611 minecraft:light_blue_concrete
setblock 320 280 612 minecraft:white_concrete
fill 320 280 616 323 280 616 minecraft:light_blue_concrete
setblock 320 280 617 minecraft:white_concrete
fill 320 280 621 323 280 621 minecraft:light_blue_concrete
setblock 320 280 622 minecraft:white_concrete
fill 320 280 626 323 280 626 minecraft:light_blue_concrete
setblock 320 280 627 minecraft:white_concrete
fill 320 280 631 323 280 631 minecraft:light_blue_concrete
setblock 320 280 632 minecraft:white_concrete
fill 320 280 636 323 280 636 minecraft:light_blue_concrete
setblock 320 280 637 minecraft:white_concrete
fill 320 280 641 323 280 641 minecraft:light_blue_concrete
setblock 320 280 642 minecraft:white_concrete
fill 321 280 607 323 280 607 minecraft:light_blue_concrete
setblock 321 280 608 minecraft:white_concrete
fill 321 280 612 323 280 612 minecraft:light_blue_concrete
setblock 321 280 613 minecraft:white_concrete
fill 321 280 617 323 280 617 minecraft:light_blue_concrete
setblock 321 280 618 minecraft:white_concrete
fill 321 280 622 323 280 622 minecraft:light_blue_concrete
setblock 321 280 623 minecraft:white_concrete
fill 321 280 627 323 280 627 minecraft:light_blue_concrete
setblock 321 280 628 minecraft:white_concrete
fill 321 280 632 323 280 632 minecraft:light_blue_concrete
setblock 321 280 633 minecraft:white_concrete
fill 321 280 637 323 280 637 minecraft:light_blue_concrete
setblock 321 280 638 minecraft:white_concrete
fill 321 280 642 323 280 642 minecraft:light_blue_concrete
setblock 321 280 643 minecraft:white_concrete
fill 322 280 608 323 280 608 minecraft:light_blue_concrete
setblock 322 280 609 minecraft:white_concrete
fill 322 280 613 323 280 613 minecraft:light_blue_concrete
setblock 322 280 614 minecraft:white_concrete
fill 322 280 618 323 280 618 minecraft:light_blue_concrete
setblock 322 280 619 minecraft:white_concrete
fill 322 280 623 323 280 623 minecraft:light_blue_concrete
setblock 322 280 624 minecraft:white_concrete
fill 322 280 628 323 280 628 minecraft:light_blue_concrete
setblock 322 280 629 minecraft:white_concrete
fill 322 280 633 323 280 633 minecraft:light_blue_concrete
setblock 322 280 634 minecraft:white_concrete
fill 322 280 638 323 280 638 minecraft:light_blue_concrete
setblock 322 280 639 minecraft:white_concrete
fill 322 280 643 323 280 643 minecraft:light_blue_concrete
setblock 322 280 644 minecraft:white_concrete
setblock 323 280 605 minecraft:white_concrete
setblock 323 280 609 minecraft:light_blue_concrete
setblock 323 280 610 minecraft:white_concrete
setblock 323 280 614 minecraft:light_blue_concrete
setblock 323 280 615 minecraft:white_concrete
setblock 323 280 619 minecraft:light_blue_concrete
setblock 323 280 620 minecraft:white_concrete
setblock 323 280 624 minecraft:light_blue_concrete
setblock 323 280 625 minecraft:white_concrete
setblock 323 280 629 minecraft:light_blue_concrete
setblock 323 280 630 minecraft:white_concrete
setblock 323 280 634 minecraft:light_blue_concrete
setblock 323 280 635 minecraft:white_concrete
setblock 323 280 639 minecraft:light_blue_concrete
setblock 323 280 640 minecraft:white_concrete
setblock 323 280 644 minecraft:light_blue_concrete
setblock 323 280 645 minecraft:white_concrete
fill 282 281 613 282 307 613 minecraft:white_concrete
fill 282 281 623 282 307 623 minecraft:white_concrete
setblock 314 281 604 minecraft:amethyst_block
setblock 317 281 604 minecraft:amethyst_block
fill 314 282 604 314 307 604 minecraft:white_concrete
fill 317 282 604 317 307 604 minecraft:white_concrete
setblock 321 283 604 minecraft:amethyst_block
fill 287 284 604 287 307 604 minecraft:white_concrete
setblock 288 284 604 minecraft:pearlescent_froglight
fill 321 284 604 321 307 604 minecraft:white_concrete
fill 288 285 604 288 307 604 minecraft:white_concrete
fill 310 285 611 311 286 612 minecraft:amethyst_block
setblock 320 285 604 minecraft:pearlescent_froglight
setblock 285 286 607 minecraft:light[level=13]
setblock 285 286 615 minecraft:light[level=13]
setblock 285 286 623 minecraft:light[level=13]
setblock 285 286 631 minecraft:light[level=13]
setblock 285 286 639 minecraft:light[level=13]
setblock 293 286 607 minecraft:light[level=13]
setblock 293 286 615 minecraft:light[level=13]
setblock 293 286 623 minecraft:light[level=13]
setblock 293 286 631 minecraft:light[level=13]
setblock 293 286 639 minecraft:light[level=13]
setblock 301 286 607 minecraft:light[level=13]
setblock 301 286 615 minecraft:light[level=13]
setblock 301 286 623 minecraft:light[level=13]
setblock 301 286 631 minecraft:light[level=13]
setblock 301 286 639 minecraft:light[level=13]
setblock 309 286 607 minecraft:light[level=13]
setblock 309 286 615 minecraft:light[level=13]
setblock 309 286 623 minecraft:light[level=13]
setblock 309 286 631 minecraft:light[level=13]
setblock 309 286 639 minecraft:light[level=13]
setblock 316 286 646 minecraft:pearlescent_froglight
setblock 317 286 607 minecraft:light[level=13]
setblock 317 286 615 minecraft:light[level=13]
setblock 317 286 623 minecraft:light[level=13]
setblock 317 286 631 minecraft:light[level=13]
setblock 317 286 639 minecraft:light[level=13]
fill 320 286 604 320 307 604 minecraft:white_concrete
setblock 282 287 605 minecraft:pearlescent_froglight
fill 282 287 614 282 307 616 minecraft:white_concrete
setblock 282 287 617 minecraft:amethyst_block
fill 282 287 618 282 300 618 minecraft:white_concrete
setblock 289 287 604 minecraft:pearlescent_froglight
fill 316 287 646 316 307 646 minecraft:white_concrete
setblock 317 287 646 minecraft:amethyst_block
setblock 282 288 605 minecraft:white_concrete
fill 282 288 612 282 290 612 minecraft:gold_block
fill 282 288 617 282 298 617 minecraft:white_concrete
fill 282 288 628 282 290 628 minecraft:gold_block
fill 282 288 644 282 290 644 minecraft:gold_block
fill 286 288 604 286 290 604 minecraft:gold_block
fill 289 288 604 289 307 604 minecraft:white_concrete
fill 296 288 646 296 290 646 minecraft:gold_block
fill 302 288 604 302 290 604 minecraft:gold_block
setblock 305 288 646 minecraft:amethyst_block
fill 306 288 646 306 304 646 minecraft:white_concrete
fill 312 288 646 312 290 646 minecraft:gold_block
fill 317 288 646 317 307 646 minecraft:white_concrete
fill 318 288 604 318 290 604 minecraft:gold_block
fill 324 288 614 324 290 614 minecraft:gold_block
fill 324 288 630 324 290 630 minecraft:gold_block
setblock 282 289 605 minecraft:amethyst_block
fill 305 289 646 305 307 646 minecraft:white_concrete
setblock 310 289 604 minecraft:amethyst_block
fill 282 290 605 282 307 605 minecraft:white_concrete
fill 310 290 604 310 307 604 minecraft:white_concrete
setblock 324 290 628 minecraft:amethyst_block
fill 282 291 612 282 296 612 minecraft:white_concrete
fill 282 291 624 282 307 625 minecraft:white_concrete
setblock 282 291 626 minecraft:pearlescent_froglight
fill 282 291 628 282 296 628 minecraft:white_concrete
fill 282 291 644 282 296 644 minecraft:white_concrete
fill 286 291 604 286 296 604 minecraft:white_concrete
setblock 294 291 646 minecraft:pearlescent_froglight
fill 296 291 646 296 296 646 minecraft:white_concrete
setblock 301 291 646 minecraft:pearlescent_froglight
fill 302 291 604 302 296 604 minecraft:white_concrete
fill 312 291 646 312 296 646 minecraft:white_concrete
fill 318 291 604 318 296 604 minecraft:white_concrete
fill 324 291 614 324 296 614 minecraft:white_concrete
fill 324 291 628 324 307 628 minecraft:white_concrete
fill 324 291 630 324 296 630 minecraft:white_concrete
fill 282 292 626 282 307 626 minecraft:white_concrete
fill 294 292 646 294 307 646 minecraft:white_concrete
fill 301 292 646 301 307 646 minecraft:white_concrete
setblock 282 293 610 minecraft:pearlescent_froglight
setblock 324 293 644 minecraft:pearlescent_froglight
fill 282 294 610 282 307 610 minecraft:white_concrete
setblock 285 294 607 minecraft:light[level=13]
setblock 285 294 615 minecraft:light[level=13]
setblock 285 294 623 minecraft:light[level=13]
setblock 285 294 631 minecraft:light[level=13]
setblock 285 294 639 minecraft:light[level=13]
setblock 293 294 607 minecraft:light[level=13]
setblock 293 294 615 minecraft:light[level=13]
setblock 293 294 623 minecraft:light[level=13]
setblock 293 294 631 minecraft:light[level=13]
setblock 293 294 639 minecraft:light[level=13]
fill 295 294 634 296 295 634 minecraft:obsidian
setblock 301 294 607 minecraft:light[level=13]
setblock 301 294 615 minecraft:light[level=13]
setblock 301 294 623 minecraft:light[level=13]
setblock 301 294 631 minecraft:light[level=13]
setblock 301 294 639 minecraft:light[level=13]
fill 307 294 646 307 303 646 minecraft:white_concrete
setblock 308 294 646 minecraft:amethyst_block
setblock 309 294 607 minecraft:light[level=13]
setblock 309 294 615 minecraft:light[level=13]
setblock 309 294 623 minecraft:light[level=13]
setblock 309 294 631 minecraft:light[level=13]
setblock 309 294 639 minecraft:light[level=13]
setblock 317 294 607 minecraft:light[level=13]
setblock 317 294 615 minecraft:light[level=13]
setblock 317 294 623 minecraft:light[level=13]
setblock 317 294 631 minecraft:light[level=13]
setblock 317 294 639 minecraft:light[level=13]
setblock 324 294 613 minecraft:amethyst_block
fill 324 294 644 324 307 644 minecraft:white_concrete
fill 308 295 646 308 307 646 minecraft:white_concrete
fill 324 295 613 324 306 613 minecraft:white_concrete
fill 282 297 612 282 299 612 minecraft:gold_block
fill 282 297 628 282 299 628 minecraft:gold_block
fill 282 297 644 282 299 644 minecraft:gold_block
setblock 285 297 604 minecraft:pearlescent_froglight
fill 286 297 604 286 299 604 minecraft:gold_block
fill 296 297 646 296 299 646 minecraft:gold_block
fill 302 297 604 302 299 604 minecraft:gold_block
fill 307 297 636 308 298 636 minecraft:amethyst_block
fill 312 297 646 312 299 646 minecraft:gold_block
fill 318 297 604 318 299 604 minecraft:gold_block
fill 324 297 614 324 299 614 minecraft:gold_block
fill 324 297 630 324 299 630 minecraft:gold_block
setblock 284 298 646 minecraft:amethyst_block
fill 285 298 604 285 307 604 minecraft:white_concrete
fill 285 298 646 285 307 646 minecraft:white_concrete
fill 288 298 623 289 299 624 minecraft:amethyst_block
fill 289 298 625 289 299 625 minecraft:amethyst_block
setblock 282 299 617 minecraft:pearlescent_froglight
fill 284 299 646 284 307 646 minecraft:white_concrete
setblock 292 299 604 minecraft:amethyst_block
fill 311 299 624 311 300 625 minecraft:gold_block
fill 312 299 624 312 300 624 minecraft:gold_block
setblock 324 299 605 minecraft:amethyst_block
fill 282 300 612 282 307 612 minecraft:white_concrete
fill 282 300 617 282 307 617 minecraft:white_concrete
fill 282 300 628 282 307 628 minecraft:white_concrete
fill 282 300 644 282 307 644 minecraft:white_concrete
fill 286 300 604 286 307 604 minecraft:white_concrete
setblock 290 300 604 minecraft:pearlescent_froglight
fill 292 300 604 292 307 604 minecraft:white_concrete
fill 296 300 646 296 307 646 minecraft:white_concrete
fill 302 300 604 302 307 604 minecraft:white_concrete
setblock 309 300 646 minecraft:pearlescent_froglight
fill 312 300 646 312 307 646 minecraft:white_concrete
fill 318 300 604 318 307 604 minecraft:white_concrete
fill 324 300 605 324 307 605 minecraft:white_concrete
fill 324 300 614 324 307 614 minecraft:white_concrete
fill 324 300 630 324 307 630 minecraft:white_concrete
setblock 282 301 618 minecraft:amethyst_block
setblock 282 301 638 minecraft:pearlescent_froglight
fill 290 301 604 290 307 604 minecraft:white_concrete
fill 309 301 646 309 307 646 minecraft:white_concrete
fill 282 302 618 282 307 618 minecraft:white_concrete
fill 282 302 638 282 307 638 minecraft:white_concrete
setblock 285 302 607 minecraft:light[level=13]
setblock 285 302 615 minecraft:light[level=13]
setblock 285 302 623 minecraft:light[level=13]
setblock 285 302 631 minecraft:light[level=13]
setblock 285 302 639 minecraft:light[level=13]
setblock 293 302 607 minecraft:light[level=13]
setblock 293 302 615 minecraft:light[level=13]
setblock 293 302 623 minecraft:light[level=13]
setblock 293 302 631 minecraft:light[level=13]
setblock 293 302 639 minecraft:light[level=13]
setblock 301 302 607 minecraft:light[level=13]
setblock 301 302 615 minecraft:light[level=13]
setblock 301 302 623 minecraft:light[level=13]
setblock 301 302 631 minecraft:light[level=13]
setblock 301 302 639 minecraft:light[level=13]
setblock 309 302 607 minecraft:light[level=13]
setblock 309 302 615 minecraft:light[level=13]
setblock 309 302 623 minecraft:light[level=13]
setblock 309 302 631 minecraft:light[level=13]
setblock 309 302 639 minecraft:light[level=13]
setblock 317 302 607 minecraft:light[level=13]
setblock 317 302 615 minecraft:light[level=13]
setblock 317 302 623 minecraft:light[level=13]
setblock 317 302 631 minecraft:light[level=13]
setblock 317 302 639 minecraft:light[level=13]
setblock 282 304 611 minecraft:amethyst_block
setblock 282 304 637 minecraft:amethyst_block
setblock 307 304 646 minecraft:amethyst_block
fill 324 304 619 324 307 619 minecraft:white_concrete
setblock 324 304 620 minecraft:pearlescent_froglight
fill 324 304 621 324 307 623 minecraft:white_concrete
fill 282 305 611 282 307 611 minecraft:white_concrete
fill 282 305 637 282 307 637 minecraft:white_concrete
setblock 306 305 646 minecraft:amethyst_block
fill 307 305 646 307 307 646 minecraft:white_concrete
fill 324 305 620 324 307 620 minecraft:white_concrete
setblock 297 306 604 minecraft:pearlescent_froglight
fill 298 306 604 301 307 604 minecraft:white_concrete
fill 306 306 646 306 307 646 minecraft:white_concrete
setblock 297 307 604 minecraft:white_concrete
setblock 324 307 613 minecraft:amethyst_block
