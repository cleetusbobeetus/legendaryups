fill 55 93 510 56 105 510 minecraft:black_concrete
fill 60 93 552 61 105 552 minecraft:black_concrete
fill 67 93 510 68 105 510 minecraft:black_concrete
fill 72 93 552 73 105 552 minecraft:black_concrete
fill 79 93 510 80 105 510 minecraft:black_concrete
fill 82 93 533 84 100 533 minecraft:purple_stained_glass
fill 83 93 532 83 100 532 minecraft:purple_stained_glass
fill 83 93 534 83 100 534 minecraft:purple_stained_glass
fill 84 93 552 85 105 552 minecraft:black_concrete
fill 89 93 512 89 105 513 minecraft:black_concrete
fill 89 93 524 89 105 525 minecraft:black_concrete
fill 89 93 536 89 105 537 minecraft:black_concrete
fill 89 93 548 89 105 549 minecraft:black_concrete
fill 81 95 514 81 95 516 minecraft:blackstone
fill 81 95 546 81 95 547 minecraft:blackstone
fill 82 95 513 85 95 513 minecraft:blackstone
fill 82 95 517 84 95 517 minecraft:blackstone
setblock 82 95 545 minecraft:blackstone
setblock 82 95 548 minecraft:blackstone
fill 83 95 544 84 95 544 minecraft:blackstone
fill 84 95 548 85 95 548 minecraft:blackstone
setblock 85 95 514 minecraft:blackstone
setblock 85 95 516 minecraft:blackstone
setblock 85 95 545 minecraft:blackstone
setblock 85 95 547 minecraft:blackstone
setblock 50 99 513 minecraft:light[level=11]
setblock 50 99 521 minecraft:light[level=11]
setblock 50 99 529 minecraft:light[level=11]
setblock 50 99 537 minecraft:light[level=11]
setblock 50 99 545 minecraft:light[level=11]
setblock 58 99 513 minecraft:light[level=11]
setblock 58 99 521 minecraft:light[level=11]
setblock 58 99 529 minecraft:light[level=11]
setblock 58 99 537 minecraft:light[level=11]
setblock 58 99 545 minecraft:light[level=11]
setblock 66 99 513 minecraft:light[level=11]
setblock 66 99 521 minecraft:light[level=11]
setblock 66 99 537 minecraft:light[level=11]
setblock 66 99 545 minecraft:light[level=11]
setblock 74 99 513 minecraft:light[level=11]
setblock 74 99 521 minecraft:light[level=11]
setblock 74 99 529 minecraft:light[level=11]
setblock 74 99 537 minecraft:light[level=11]
setblock 74 99 545 minecraft:light[level=11]
fill 76 99 512 82 100 512 minecraft:iron_bars
setblock 82 99 513 minecraft:light[level=11]
setblock 82 99 521 minecraft:light[level=11]
setblock 82 99 529 minecraft:light[level=11]
setblock 82 99 537 minecraft:light[level=11]
setblock 82 99 545 minecraft:light[level=11]
fill 49 100 520 49 105 522 minecraft:polished_blackstone_bricks
fill 49 100 532 49 105 534 minecraft:polished_blackstone_bricks
fill 49 100 544 49 105 546 minecraft:polished_blackstone_bricks
fill 55 100 550 57 105 550 minecraft:polished_blackstone_bricks
fill 59 100 512 61 105 512 minecraft:polished_blackstone_bricks
fill 67 100 550 69 105 550 minecraft:polished_blackstone_bricks
fill 71 100 512 73 105 512 minecraft:polished_blackstone_bricks
fill 79 100 550 81 105 550 minecraft:polished_blackstone_bricks
fill 83 100 512 85 105 512 minecraft:polished_blackstone_bricks
fill 87 100 520 87 105 522 minecraft:polished_blackstone_bricks
fill 87 100 532 87 105 534 minecraft:polished_blackstone_bricks
fill 87 100 544 87 105 546 minecraft:polished_blackstone_bricks
fill 81 103 514 81 103 516 minecraft:blackstone
fill 81 103 546 81 103 547 minecraft:blackstone
fill 82 103 513 85 103 513 minecraft:blackstone
fill 82 103 517 84 103 517 minecraft:blackstone
setblock 82 103 545 minecraft:blackstone
setblock 82 103 548 minecraft:blackstone
setblock 83 103 533 minecraft:crying_obsidian
fill 83 103 544 84 103 544 minecraft:blackstone
fill 84 103 548 85 103 548 minecraft:blackstone
setblock 85 103 514 minecraft:blackstone
setblock 85 103 516 minecraft:blackstone
setblock 85 103 545 minecraft:blackstone
setblock 85 103 547 minecraft:blackstone
fill 48 105 514 48 105 519 minecraft:blackstone
fill 48 105 526 48 105 531 minecraft:blackstone
fill 48 105 538 48 105 543 minecraft:blackstone
fill 48 105 550 48 105 551 minecraft:blackstone
fill 49 105 551 52 105 551 minecraft:blackstone
fill 52 105 511 57 105 511 minecraft:blackstone
fill 59 105 551 64 105 551 minecraft:blackstone
fill 64 105 511 69 105 511 minecraft:blackstone
fill 71 105 551 76 105 551 minecraft:blackstone
fill 76 105 511 81 105 511 minecraft:blackstone
fill 83 105 551 88 105 551 minecraft:blackstone
fill 88 105 511 88 105 516 minecraft:blackstone
fill 88 105 523 88 105 528 minecraft:blackstone
fill 88 105 535 88 105 540 minecraft:blackstone
fill 88 105 547 88 105 550 minecraft:blackstone
fill 47 106 516 47 109 519 minecraft:crying_obsidian
fill 47 106 528 47 109 531 minecraft:crying_obsidian
fill 47 106 540 47 109 543 minecraft:crying_obsidian
fill 47 106 552 50 109 552 minecraft:crying_obsidian
fill 54 106 510 57 109 510 minecraft:crying_obsidian
fill 59 106 552 62 109 552 minecraft:crying_obsidian
fill 66 106 510 69 109 510 minecraft:crying_obsidian
fill 71 106 552 74 109 552 minecraft:crying_obsidian
fill 78 106 510 81 109 510 minecraft:crying_obsidian
fill 83 106 552 86 109 552 minecraft:crying_obsidian
fill 89 106 511 89 109 514 minecraft:crying_obsidian
fill 89 106 523 89 109 526 minecraft:crying_obsidian
fill 89 106 535 89 109 538 minecraft:crying_obsidian
fill 89 106 547 89 109 550 minecraft:crying_obsidian
setblock 50 107 513 minecraft:light[level=11]
setblock 50 107 521 minecraft:light[level=11]
setblock 50 107 529 minecraft:light[level=11]
setblock 50 107 537 minecraft:light[level=11]
setblock 50 107 545 minecraft:light[level=11]
setblock 58 107 513 minecraft:light[level=11]
setblock 58 107 521 minecraft:light[level=11]
setblock 58 107 529 minecraft:light[level=11]
setblock 58 107 537 minecraft:light[level=11]
setblock 58 107 545 minecraft:light[level=11]
setblock 66 107 513 minecraft:light[level=11]
setblock 66 107 521 minecraft:light[level=11]
setblock 66 107 537 minecraft:light[level=11]
setblock 66 107 545 minecraft:light[level=11]
setblock 74 107 513 minecraft:light[level=11]
setblock 74 107 521 minecraft:light[level=11]
setblock 74 107 529 minecraft:light[level=11]
setblock 74 107 537 minecraft:light[level=11]
setblock 74 107 545 minecraft:light[level=11]
setblock 82 107 513 minecraft:light[level=11]
setblock 82 107 521 minecraft:light[level=11]
setblock 82 107 529 minecraft:light[level=11]
setblock 82 107 537 minecraft:light[level=11]
setblock 82 107 545 minecraft:light[level=11]
fill 81 108 515 81 109 515 minecraft:purple_stained_glass
fill 81 108 546 81 109 546 minecraft:purple_stained_glass
fill 82 108 513 84 109 513 minecraft:purple_stained_glass
fill 82 108 545 82 109 545 minecraft:purple_stained_glass
fill 82 108 548 82 109 548 minecraft:purple_stained_glass
fill 83 108 517 84 109 517 minecraft:purple_stained_glass
fill 83 108 544 84 109 544 minecraft:purple_stained_glass
fill 84 108 548 85 109 548 minecraft:purple_stained_glass
fill 85 108 514 85 109 514 minecraft:purple_stained_glass
fill 85 108 516 85 109 516 minecraft:purple_stained_glass
fill 85 108 545 85 109 545 minecraft:purple_stained_glass
fill 85 108 547 85 109 547 minecraft:purple_stained_glass
fill 47 110 516 47 116 519 minecraft:black_concrete
fill 47 110 528 47 115 531 minecraft:black_concrete
fill 47 110 540 47 115 543 minecraft:black_concrete
fill 47 110 552 50 115 552 minecraft:black_concrete
fill 54 110 510 57 115 510 minecraft:black_concrete
fill 59 110 552 62 117 552 minecraft:black_concrete
fill 66 110 510 69 115 510 minecraft:black_concrete
fill 71 110 552 74 116 552 minecraft:black_concrete
fill 78 110 510 81 119 510 minecraft:black_concrete
fill 83 110 552 86 115 552 minecraft:black_concrete
fill 89 110 511 89 116 514 minecraft:black_concrete
fill 89 110 523 89 115 526 minecraft:black_concrete
fill 89 110 535 89 115 538 minecraft:black_concrete
fill 89 110 547 89 115 550 minecraft:black_concrete
fill 62 114 524 64 114 526 minecraft:redstone_block
fill 62 114 532 64 114 534 minecraft:redstone_block
fill 69 114 525 71 114 527 minecraft:redstone_block
fill 69 114 531 71 114 533 minecraft:redstone_block
fill 48 115 511 48 116 551 minecraft:black_concrete
fill 49 115 511 49 116 551 minecraft:iron_bars
fill 50 115 511 50 116 551 minecraft:black_concrete
fill 51 115 511 51 116 551 minecraft:iron_bars
fill 52 115 511 52 116 551 minecraft:black_concrete
fill 53 115 511 53 116 551 minecraft:iron_bars
fill 54 115 511 54 116 551 minecraft:black_concrete
fill 55 115 511 55 116 551 minecraft:iron_bars
fill 56 115 511 56 116 551 minecraft:black_concrete
fill 57 115 511 57 116 551 minecraft:iron_bars
fill 58 115 511 58 116 551 minecraft:black_concrete
fill 59 115 511 59 116 551 minecraft:iron_bars
fill 60 115 511 60 116 551 minecraft:black_concrete
fill 61 115 511 61 115 551 minecraft:iron_bars
fill 62 115 511 62 115 523 minecraft:black_concrete
fill 62 115 527 62 115 531 minecraft:black_concrete
fill 62 115 535 62 115 551 minecraft:black_concrete
fill 63 115 511 63 115 523 minecraft:iron_bars
fill 63 115 527 63 115 531 minecraft:iron_bars
fill 63 115 535 63 115 551 minecraft:iron_bars
fill 64 115 511 64 115 523 minecraft:black_concrete
fill 64 115 527 64 115 531 minecraft:black_concrete
fill 64 115 535 64 115 551 minecraft:black_concrete
fill 65 115 511 65 115 527 minecraft:iron_bars
fill 65 115 531 65 115 551 minecraft:iron_bars
fill 66 115 511 66 115 527 minecraft:black_concrete
fill 66 115 531 66 115 551 minecraft:black_concrete
fill 67 115 511 67 115 527 minecraft:iron_bars
fill 67 115 531 67 115 551 minecraft:iron_bars
fill 68 115 511 68 115 551 minecraft:black_concrete
fill 69 115 511 69 115 524 minecraft:iron_bars
fill 69 115 528 69 115 530 minecraft:iron_bars
fill 69 115 534 69 115 551 minecraft:iron_bars
fill 70 115 511 70 115 524 minecraft:black_concrete
fill 70 115 528 70 115 530 minecraft:black_concrete
fill 70 115 534 70 115 551 minecraft:black_concrete
fill 71 115 511 71 115 524 minecraft:iron_bars
fill 71 115 528 71 115 530 minecraft:iron_bars
fill 71 115 534 71 115 551 minecraft:iron_bars
fill 72 115 511 72 115 551 minecraft:black_concrete
fill 73 115 511 73 116 551 minecraft:iron_bars
fill 74 115 511 74 116 551 minecraft:black_concrete
fill 75 115 511 75 116 551 minecraft:iron_bars
fill 76 115 511 76 116 551 minecraft:black_concrete
fill 77 115 511 77 116 551 minecraft:iron_bars
fill 78 115 511 78 116 551 minecraft:black_concrete
fill 79 115 511 79 116 551 minecraft:iron_bars
fill 80 115 511 80 116 551 minecraft:black_concrete
fill 81 115 511 81 116 551 minecraft:iron_bars
fill 82 115 511 82 116 551 minecraft:black_concrete
fill 83 115 511 83 116 551 minecraft:iron_bars
fill 84 115 511 84 116 551 minecraft:black_concrete
fill 85 115 511 85 116 551 minecraft:iron_bars
fill 86 115 511 86 116 551 minecraft:black_concrete
fill 87 115 511 87 116 551 minecraft:iron_bars
fill 88 115 511 88 116 551 minecraft:black_concrete
fill 47 116 510 47 116 514 minecraft:black_concrete
setblock 47 116 515 minecraft:polished_blackstone_bricks
fill 47 116 528 47 119 529 minecraft:black_concrete
fill 47 116 530 47 117 530 minecraft:polished_blackstone_bricks
setblock 47 116 531 minecraft:black_concrete
fill 47 116 540 47 117 540 minecraft:black_concrete
fill 47 116 541 47 116 542 minecraft:polished_blackstone_bricks
fill 47 116 543 47 119 543 minecraft:black_concrete
setblock 47 116 544 minecraft:polished_blackstone_bricks
fill 47 116 545 47 119 546 minecraft:black_concrete
fill 47 116 547 47 117 547 minecraft:polished_blackstone_bricks
fill 47 116 548 47 119 548 minecraft:black_concrete
setblock 47 116 549 minecraft:polished_blackstone_bricks
fill 47 116 550 47 116 551 minecraft:black_concrete
setblock 47 116 552 minecraft:polished_blackstone_bricks
fill 48 116 510 52 117 510 minecraft:black_concrete
fill 48 116 552 50 119 552 minecraft:black_concrete
setblock 53 116 510 minecraft:polished_blackstone_bricks
fill 54 116 510 54 120 510 minecraft:black_concrete
setblock 55 116 510 minecraft:polished_blackstone_bricks
fill 56 116 510 57 116 510 minecraft:black_concrete
fill 61 116 511 61 116 522 minecraft:iron_bars
fill 61 116 523 61 116 527 minecraft:crying_obsidian
fill 61 116 528 61 116 530 minecraft:iron_bars
fill 61 116 531 61 116 535 minecraft:crying_obsidian
fill 61 116 536 61 116 551 minecraft:iron_bars
fill 62 116 511 62 116 522 minecraft:black_concrete
fill 62 116 523 65 116 523 minecraft:crying_obsidian
fill 62 116 524 64 116 526 minecraft:blackstone
fill 62 116 527 68 116 527 minecraft:crying_obsidian
fill 62 116 528 62 116 530 minecraft:black_concrete
fill 62 116 531 68 116 531 minecraft:crying_obsidian
fill 62 116 532 64 116 534 minecraft:blackstone
fill 62 116 535 65 116 535 minecraft:crying_obsidian
fill 62 116 536 62 116 551 minecraft:black_concrete
fill 63 116 511 63 116 522 minecraft:iron_bars
fill 63 116 528 63 116 530 minecraft:iron_bars
fill 63 116 536 63 116 551 minecraft:iron_bars
fill 63 116 552 65 119 552 minecraft:black_concrete
fill 64 116 511 64 116 522 minecraft:black_concrete
fill 64 116 528 64 116 530 minecraft:crying_obsidian
fill 64 116 536 64 116 551 minecraft:black_concrete
fill 65 116 511 65 116 522 minecraft:iron_bars
fill 65 116 524 65 116 526 minecraft:crying_obsidian
fill 65 116 532 65 116 534 minecraft:crying_obsidian
fill 65 116 536 65 116 551 minecraft:iron_bars
fill 66 116 510 66 116 526 minecraft:black_concrete
fill 66 116 532 66 116 551 minecraft:black_concrete
setblock 66 116 552 minecraft:polished_blackstone_bricks
fill 67 116 510 68 119 510 minecraft:black_concrete
fill 67 116 511 67 116 526 minecraft:iron_bars
fill 67 116 532 67 116 551 minecraft:iron_bars
fill 67 116 552 67 119 552 minecraft:black_concrete
fill 68 116 511 68 116 523 minecraft:black_concrete
fill 68 116 524 68 116 526 minecraft:crying_obsidian
fill 68 116 528 68 116 530 minecraft:crying_obsidian
fill 68 116 532 68 116 534 minecraft:crying_obsidian
fill 68 116 535 68 116 551 minecraft:black_concrete
fill 68 116 552 68 117 552 minecraft:polished_blackstone_bricks
fill 69 116 510 70 116 510 minecraft:polished_blackstone_bricks
fill 69 116 511 69 116 523 minecraft:iron_bars
fill 69 116 524 72 116 524 minecraft:crying_obsidian
fill 69 116 525 71 116 527 minecraft:blackstone
fill 69 116 528 72 116 528 minecraft:crying_obsidian
setblock 69 116 529 minecraft:iron_bars
fill 69 116 530 72 116 530 minecraft:crying_obsidian
fill 69 116 531 71 116 533 minecraft:blackstone
fill 69 116 534 72 116 534 minecraft:crying_obsidian
fill 69 116 535 69 116 551 minecraft:iron_bars
fill 69 116 552 70 119 552 minecraft:black_concrete
fill 70 116 511 70 116 523 minecraft:black_concrete
setblock 70 116 529 minecraft:black_concrete
fill 70 116 535 70 116 551 minecraft:black_concrete
fill 71 116 510 71 119 510 minecraft:black_concrete
fill 71 116 511 71 116 523 minecraft:iron_bars
setblock 71 116 529 minecraft:iron_bars
fill 71 116 535 71 116 551 minecraft:iron_bars
setblock 72 116 510 minecraft:polished_blackstone_bricks
fill 72 116 511 72 116 523 minecraft:black_concrete
fill 72 116 525 72 116 527 minecraft:crying_obsidian
setblock 72 116 529 minecraft:black_concrete
fill 72 116 531 72 116 533 minecraft:crying_obsidian
fill 72 116 535 72 116 551 minecraft:black_concrete
fill 73 116 510 77 117 510 minecraft:black_concrete
fill 82 116 510 83 119 510 minecraft:black_concrete
fill 83 116 552 83 119 552 minecraft:black_concrete
fill 84 116 510 84 117 510 minecraft:polished_blackstone_bricks
setblock 84 116 552 minecraft:polished_blackstone_bricks
fill 85 116 510 89 116 510 minecraft:black_concrete
fill 85 116 552 86 116 552 minecraft:black_concrete
fill 89 116 523 89 119 524 minecraft:black_concrete
fill 89 116 525 89 117 525 minecraft:polished_blackstone_bricks
fill 89 116 526 89 119 526 minecraft:black_concrete
setblock 89 116 535 minecraft:polished_blackstone_bricks
fill 89 116 536 89 119 536 minecraft:black_concrete
setblock 89 116 537 minecraft:polished_blackstone_bricks
fill 89 116 538 89 119 541 minecraft:black_concrete
fill 89 116 542 89 117 542 minecraft:polished_blackstone_bricks
fill 89 116 543 89 119 547 minecraft:black_concrete
setblock 89 116 548 minecraft:polished_blackstone_bricks
setblock 89 116 549 minecraft:black_concrete
setblock 89 116 550 minecraft:polished_blackstone_bricks
fill 47 117 510 47 118 510 minecraft:polished_blackstone_bricks
fill 47 117 511 47 119 515 minecraft:black_concrete
setblock 47 117 516 minecraft:polished_blackstone_bricks
fill 47 117 517 47 119 524 minecraft:black_concrete
setblock 47 117 525 minecraft:polished_blackstone_bricks
fill 47 117 526 47 119 527 minecraft:black_concrete
fill 47 117 531 47 117 532 minecraft:polished_blackstone_bricks
fill 47 117 533 47 119 535 minecraft:black_concrete
fill 47 117 536 47 117 537 minecraft:polished_blackstone_bricks
fill 47 117 538 47 119 539 minecraft:black_concrete
fill 47 117 541 47 117 542 minecraft:black_concrete
fill 47 117 544 47 119 544 minecraft:black_concrete
setblock 47 117 549 minecraft:black_concrete
setblock 47 117 550 minecraft:polished_blackstone_bricks
fill 47 117 551 47 119 552 minecraft:black_concrete
fill 51 117 552 52 119 552 minecraft:black_concrete
fill 53 117 510 53 119 510 minecraft:black_concrete
setblock 53 117 552 minecraft:polished_blackstone_bricks
fill 54 117 552 58 119 552 minecraft:black_concrete
fill 55 117 510 56 119 510 minecraft:black_concrete
setblock 57 117 510 minecraft:polished_blackstone_bricks
fill 58 117 510 59 117 510 minecraft:black_concrete
setblock 60 117 510 minecraft:polished_blackstone_bricks
fill 61 117 510 62 119 510 minecraft:black_concrete
setblock 63 117 510 minecraft:polished_blackstone_bricks
fill 64 117 510 66 119 510 minecraft:black_concrete
fill 66 117 552 66 119 552 minecraft:black_concrete
fill 69 117 510 70 119 510 minecraft:black_concrete
fill 71 117 552 71 119 552 minecraft:black_concrete
fill 72 117 510 72 119 510 minecraft:black_concrete
fill 72 117 552 72 118 552 minecraft:polished_blackstone_bricks
fill 73 117 552 74 119 552 minecraft:black_concrete
fill 84 117 552 85 117 552 minecraft:black_concrete
fill 85 117 510 88 119 510 minecraft:black_concrete
setblock 86 117 552 minecraft:polished_blackstone_bricks
fill 89 117 510 89 118 510 minecraft:polished_blackstone_bricks
fill 89 117 511 89 119 511 minecraft:black_concrete
setblock 89 117 512 minecraft:polished_blackstone_bricks
fill 89 117 513 89 119 516 minecraft:black_concrete
fill 89 117 517 89 118 517 minecraft:polished_blackstone_bricks
setblock 89 117 518 minecraft:black_concrete
setblock 89 117 519 minecraft:polished_blackstone_bricks
fill 89 117 520 89 117 522 minecraft:black_concrete
fill 89 117 527 89 117 530 minecraft:black_concrete
setblock 89 117 531 minecraft:polished_blackstone_bricks
fill 89 117 532 89 117 535 minecraft:black_concrete
fill 89 117 537 89 119 537 minecraft:black_concrete
fill 89 117 548 89 119 548 minecraft:black_concrete
setblock 89 117 549 minecraft:polished_blackstone_bricks
setblock 89 117 550 minecraft:black_concrete
fill 47 118 516 47 119 516 minecraft:black_concrete
fill 47 118 525 47 119 525 minecraft:black_concrete
fill 47 118 530 47 119 532 minecraft:black_concrete
setblock 47 118 536 minecraft:polished_blackstone_bricks
fill 47 118 537 47 119 537 minecraft:black_concrete
fill 47 118 540 47 118 541 minecraft:polished_blackstone_bricks
fill 47 118 542 47 119 542 minecraft:black_concrete
fill 47 118 547 47 119 547 minecraft:black_concrete
setblock 47 118 549 minecraft:polished_blackstone_bricks
fill 47 118 550 47 119 550 minecraft:black_concrete
fill 48 118 510 49 118 510 minecraft:polished_blackstone_bricks
fill 50 118 510 51 119 510 minecraft:black_concrete
setblock 52 118 510 minecraft:polished_blackstone_bricks
fill 53 118 552 53 119 552 minecraft:black_concrete
fill 57 118 510 57 119 510 minecraft:black_concrete
setblock 58 118 510 minecraft:polished_blackstone_bricks
fill 59 118 510 60 119 510 minecraft:black_concrete
fill 59 118 552 59 119 552 minecraft:black_concrete
setblock 60 118 552 minecraft:polished_blackstone_bricks
fill 61 118 552 62 119 552 minecraft:black_concrete
fill 63 118 510 63 119 510 minecraft:black_concrete
fill 68 118 552 68 119 552 minecraft:black_concrete
fill 73 118 510 74 118 510 minecraft:polished_blackstone_bricks
fill 75 118 510 77 119 510 minecraft:black_concrete
fill 84 118 510 84 119 510 minecraft:black_concrete
fill 84 118 552 84 119 552 minecraft:black_concrete
setblock 85 118 552 minecraft:polished_blackstone_bricks
fill 86 118 552 86 119 552 minecraft:black_concrete
fill 89 118 512 89 119 512 minecraft:black_concrete
setblock 89 118 518 minecraft:polished_blackstone_bricks
fill 89 118 519 89 119 520 minecraft:black_concrete
setblock 89 118 521 minecraft:polished_blackstone_bricks
fill 89 118 522 89 119 522 minecraft:black_concrete
fill 89 118 525 89 119 525 minecraft:black_concrete
setblock 89 118 527 minecraft:polished_blackstone_bricks
fill 89 118 528 89 119 529 minecraft:black_concrete
setblock 89 118 530 minecraft:polished_blackstone_bricks
fill 89 118 531 89 119 534 minecraft:black_concrete
setblock 89 118 535 minecraft:polished_blackstone_bricks
fill 89 118 542 89 120 542 minecraft:black_concrete
fill 89 118 549 89 119 549 minecraft:black_concrete
setblock 89 118 550 minecraft:polished_blackstone_bricks
fill 47 119 510 49 119 510 minecraft:black_concrete
setblock 47 119 536 minecraft:black_concrete
fill 47 119 540 47 119 541 minecraft:black_concrete
setblock 47 119 549 minecraft:black_concrete
setblock 52 119 510 minecraft:black_concrete
setblock 58 119 510 minecraft:black_concrete
setblock 60 119 552 minecraft:black_concrete
setblock 72 119 552 minecraft:black_concrete
fill 73 119 510 74 119 510 minecraft:black_concrete
setblock 85 119 552 minecraft:black_concrete
setblock 89 119 510 minecraft:black_concrete
fill 89 119 517 89 119 518 minecraft:black_concrete
setblock 89 119 521 minecraft:black_concrete
setblock 89 119 527 minecraft:black_concrete
setblock 89 119 530 minecraft:black_concrete
setblock 89 119 535 minecraft:black_concrete
setblock 89 119 550 minecraft:black_concrete
fill 47 120 510 47 120 526 minecraft:polished_blackstone_bricks
setblock 47 120 527 minecraft:black_concrete
fill 47 120 528 47 120 530 minecraft:polished_blackstone_bricks
setblock 47 120 531 minecraft:black_concrete
fill 47 120 532 47 120 539 minecraft:polished_blackstone_bricks
setblock 47 120 540 minecraft:black_concrete
fill 47 120 541 47 125 552 minecraft:polished_blackstone_bricks
setblock 48 120 510 minecraft:black_concrete
fill 48 120 511 50 172 511 minecraft:polished_blackstone_bricks
fill 48 120 521 48 172 523 minecraft:polished_blackstone_bricks
fill 48 120 533 48 172 535 minecraft:polished_blackstone_bricks
fill 48 120 545 48 172 547 minecraft:polished_blackstone_bricks
fill 48 120 552 89 120 552 minecraft:polished_blackstone_bricks
fill 49 120 510 49 213 510 minecraft:polished_blackstone_bricks
fill 49 120 520 49 125 522 minecraft:polished_blackstone_bricks
fill 49 120 523 49 125 526 minecraft:purple_wool
fill 49 120 532 49 125 534 minecraft:polished_blackstone_bricks
fill 49 120 541 49 122 543 minecraft:purple_wool
fill 49 120 544 49 125 546 minecraft:polished_blackstone_bricks
setblock 50 120 510 minecraft:black_concrete
fill 51 120 510 53 120 510 minecraft:polished_blackstone_bricks
fill 54 120 511 62 120 520 minecraft:polished_blackstone_bricks
fill 54 120 551 56 172 551 minecraft:polished_blackstone_bricks
fill 55 120 510 78 120 510 minecraft:polished_blackstone_bricks
fill 55 120 550 57 125 550 minecraft:polished_blackstone_bricks
fill 66 120 551 68 172 551 minecraft:polished_blackstone_bricks
fill 67 120 550 69 125 550 minecraft:polished_blackstone_bricks
fill 71 120 512 73 125 512 minecraft:polished_blackstone_bricks
fill 72 120 511 74 172 511 minecraft:polished_blackstone_bricks
fill 78 120 515 88 120 523 minecraft:polished_blackstone_bricks
fill 78 120 551 80 172 551 minecraft:polished_blackstone_bricks
fill 79 120 510 79 121 510 minecraft:black_concrete
fill 79 120 550 81 125 550 minecraft:polished_blackstone_bricks
fill 80 120 510 82 121 510 minecraft:polished_blackstone_bricks
setblock 83 120 510 minecraft:black_concrete
fill 83 120 512 85 125 512 minecraft:polished_blackstone_bricks
fill 84 120 510 86 172 511 minecraft:polished_blackstone_bricks
fill 87 120 510 87 214 510 minecraft:polished_blackstone_bricks
fill 87 120 532 87 125 534 minecraft:polished_blackstone_bricks
fill 87 120 544 87 125 546 minecraft:polished_blackstone_bricks
fill 88 120 510 88 121 510 minecraft:black_concrete
fill 88 120 531 89 172 533 minecraft:polished_blackstone_bricks
fill 88 120 543 89 172 545 minecraft:polished_blackstone_bricks
fill 89 120 510 89 120 519 minecraft:polished_blackstone_bricks
setblock 89 120 520 minecraft:black_concrete
fill 89 120 521 89 120 528 minecraft:polished_blackstone_bricks
setblock 89 120 529 minecraft:black_concrete
fill 89 120 530 89 213 530 minecraft:polished_blackstone_bricks
fill 89 120 534 89 120 541 minecraft:polished_blackstone_bricks
fill 89 120 546 89 120 551 minecraft:polished_blackstone_bricks
fill 47 121 510 47 122 510 minecraft:black_concrete
fill 47 121 511 47 209 513 minecraft:polished_blackstone_bricks
setblock 47 121 514 minecraft:black_concrete
fill 47 121 515 47 213 515 minecraft:polished_blackstone_bricks
setblock 47 121 516 minecraft:black_concrete
fill 47 121 517 47 125 518 minecraft:polished_blackstone_bricks
setblock 47 121 519 minecraft:black_concrete
fill 47 121 520 47 213 521 minecraft:polished_blackstone_bricks
setblock 47 121 522 minecraft:black_concrete
fill 47 121 523 47 213 523 minecraft:polished_blackstone_bricks
setblock 47 121 524 minecraft:black_concrete
fill 47 121 525 47 121 527 minecraft:polished_blackstone_bricks
setblock 47 121 528 minecraft:black_concrete
fill 47 121 529 47 125 529 minecraft:polished_blackstone_bricks
setblock 47 121 530 minecraft:black_concrete
fill 47 121 531 47 121 538 minecraft:polished_blackstone_bricks
setblock 47 121 539 minecraft:black_concrete
fill 47 121 540 47 125 540 minecraft:polished_blackstone_bricks
fill 48 121 510 48 213 510 minecraft:polished_blackstone_bricks
fill 48 121 552 74 125 552 minecraft:polished_blackstone_bricks
fill 50 121 510 50 213 510 minecraft:polished_blackstone_bricks
setblock 51 121 510 minecraft:black_concrete
fill 52 121 510 58 125 510 minecraft:polished_blackstone_bricks
setblock 54 121 511 minecraft:crying_obsidian
fill 54 121 512 54 146 512 minecraft:polished_blackstone_bricks
setblock 54 121 513 minecraft:crying_obsidian
fill 54 121 514 54 146 514 minecraft:polished_blackstone_bricks
setblock 54 121 515 minecraft:crying_obsidian
fill 54 121 516 54 146 516 minecraft:polished_blackstone_bricks
setblock 54 121 517 minecraft:crying_obsidian
fill 54 121 518 54 146 518 minecraft:polished_blackstone_bricks
setblock 54 121 519 minecraft:crying_obsidian
fill 54 121 520 54 146 520 minecraft:polished_blackstone_bricks
fill 55 121 511 55 124 511 minecraft:polished_blackstone_bricks
setblock 55 121 512 minecraft:crying_obsidian
fill 55 121 513 55 146 513 minecraft:polished_blackstone_bricks
setblock 55 121 514 minecraft:crying_obsidian
fill 55 121 515 55 146 515 minecraft:polished_blackstone_bricks
setblock 55 121 516 minecraft:crying_obsidian
fill 55 121 517 55 146 517 minecraft:polished_blackstone_bricks
setblock 55 121 518 minecraft:crying_obsidian
fill 55 121 519 55 146 519 minecraft:polished_blackstone_bricks
setblock 55 121 520 minecraft:crying_obsidian
setblock 56 121 511 minecraft:crying_obsidian
fill 56 121 512 56 146 512 minecraft:polished_blackstone_bricks
setblock 56 121 513 minecraft:crying_obsidian
fill 56 121 514 56 146 514 minecraft:polished_blackstone_bricks
setblock 56 121 515 minecraft:crying_obsidian
fill 56 121 516 56 146 516 minecraft:polished_blackstone_bricks
setblock 56 121 517 minecraft:crying_obsidian
fill 56 121 518 56 146 518 minecraft:polished_blackstone_bricks
setblock 56 121 519 minecraft:crying_obsidian
fill 56 121 520 56 146 520 minecraft:polished_blackstone_bricks
fill 57 121 511 57 124 511 minecraft:polished_blackstone_bricks
setblock 57 121 512 minecraft:crying_obsidian
fill 57 121 513 57 146 513 minecraft:polished_blackstone_bricks
setblock 57 121 514 minecraft:crying_obsidian
fill 57 121 515 57 146 515 minecraft:polished_blackstone_bricks
setblock 57 121 516 minecraft:crying_obsidian
fill 57 121 517 57 146 517 minecraft:polished_blackstone_bricks
setblock 57 121 518 minecraft:crying_obsidian
fill 57 121 519 57 146 519 minecraft:polished_blackstone_bricks
setblock 57 121 520 minecraft:crying_obsidian
setblock 58 121 511 minecraft:crying_obsidian
fill 58 121 512 58 146 512 minecraft:polished_blackstone_bricks
setblock 58 121 513 minecraft:crying_obsidian
fill 58 121 514 58 146 514 minecraft:polished_blackstone_bricks
setblock 58 121 515 minecraft:crying_obsidian
fill 58 121 516 58 146 516 minecraft:polished_blackstone_bricks
setblock 58 121 517 minecraft:crying_obsidian
fill 58 121 518 58 146 518 minecraft:polished_blackstone_bricks
setblock 58 121 519 minecraft:crying_obsidian
fill 58 121 520 58 146 520 minecraft:polished_blackstone_bricks
fill 59 121 510 59 122 510 minecraft:black_concrete
fill 59 121 511 59 146 511 minecraft:polished_blackstone_bricks
setblock 59 121 512 minecraft:crying_obsidian
fill 59 121 513 59 146 513 minecraft:polished_blackstone_bricks
setblock 59 121 514 minecraft:crying_obsidian
fill 59 121 515 59 146 515 minecraft:polished_blackstone_bricks
setblock 59 121 516 minecraft:crying_obsidian
fill 59 121 517 59 146 517 minecraft:polished_blackstone_bricks
setblock 59 121 518 minecraft:crying_obsidian
fill 59 121 519 59 146 519 minecraft:polished_blackstone_bricks
setblock 59 121 520 minecraft:crying_obsidian
fill 60 121 510 78 121 510 minecraft:polished_blackstone_bricks
setblock 60 121 511 minecraft:crying_obsidian
fill 60 121 512 60 146 512 minecraft:polished_blackstone_bricks
setblock 60 121 513 minecraft:crying_obsidian
fill 60 121 514 60 146 514 minecraft:polished_blackstone_bricks
setblock 60 121 515 minecraft:crying_obsidian
fill 60 121 516 60 146 516 minecraft:polished_blackstone_bricks
setblock 60 121 517 minecraft:crying_obsidian
fill 60 121 518 60 146 518 minecraft:polished_blackstone_bricks
setblock 60 121 519 minecraft:crying_obsidian
fill 60 121 520 60 146 520 minecraft:polished_blackstone_bricks
fill 61 121 511 61 172 511 minecraft:polished_blackstone_bricks
setblock 61 121 512 minecraft:crying_obsidian
fill 61 121 513 61 146 513 minecraft:polished_blackstone_bricks
setblock 61 121 514 minecraft:crying_obsidian
fill 61 121 515 61 146 515 minecraft:polished_blackstone_bricks
setblock 61 121 516 minecraft:crying_obsidian
fill 61 121 517 61 146 517 minecraft:polished_blackstone_bricks
setblock 61 121 518 minecraft:crying_obsidian
fill 61 121 519 61 146 519 minecraft:polished_blackstone_bricks
setblock 61 121 520 minecraft:crying_obsidian
setblock 62 121 511 minecraft:crying_obsidian
fill 62 121 512 62 146 512 minecraft:polished_blackstone_bricks
setblock 62 121 513 minecraft:crying_obsidian
fill 62 121 514 62 146 514 minecraft:polished_blackstone_bricks
setblock 62 121 515 minecraft:crying_obsidian
fill 62 121 516 62 146 516 minecraft:polished_blackstone_bricks
setblock 62 121 517 minecraft:crying_obsidian
fill 62 121 518 62 146 518 minecraft:polished_blackstone_bricks
setblock 62 121 519 minecraft:crying_obsidian
fill 62 121 520 62 146 520 minecraft:polished_blackstone_bricks
setblock 75 121 552 minecraft:black_concrete
fill 76 121 552 89 121 552 minecraft:polished_blackstone_bricks
setblock 78 121 515 minecraft:crying_obsidian
fill 78 121 516 78 138 516 minecraft:polished_blackstone_bricks
setblock 78 121 517 minecraft:crying_obsidian
fill 78 121 518 78 138 518 minecraft:polished_blackstone_bricks
setblock 78 121 519 minecraft:crying_obsidian
fill 78 121 520 78 138 520 minecraft:polished_blackstone_bricks
setblock 78 121 521 minecraft:crying_obsidian
fill 78 121 522 78 138 522 minecraft:polished_blackstone_bricks
setblock 78 121 523 minecraft:crying_obsidian
fill 79 121 515 79 138 515 minecraft:polished_blackstone_bricks
setblock 79 121 516 minecraft:crying_obsidian
fill 79 121 517 79 138 517 minecraft:polished_blackstone_bricks
setblock 79 121 518 minecraft:crying_obsidian
fill 79 121 519 79 138 519 minecraft:polished_blackstone_bricks
setblock 79 121 520 minecraft:crying_obsidian
fill 79 121 521 79 138 521 minecraft:polished_blackstone_bricks
setblock 79 121 522 minecraft:crying_obsidian
fill 79 121 523 79 138 523 minecraft:polished_blackstone_bricks
setblock 80 121 515 minecraft:crying_obsidian
fill 80 121 516 80 138 516 minecraft:polished_blackstone_bricks
setblock 80 121 517 minecraft:crying_obsidian
fill 80 121 518 80 138 518 minecraft:polished_blackstone_bricks
setblock 80 121 519 minecraft:crying_obsidian
fill 80 121 520 80 138 520 minecraft:polished_blackstone_bricks
setblock 80 121 521 minecraft:crying_obsidian
fill 80 121 522 80 138 522 minecraft:polished_blackstone_bricks
setblock 80 121 523 minecraft:crying_obsidian
fill 81 121 515 81 138 515 minecraft:polished_blackstone_bricks
setblock 81 121 516 minecraft:crying_obsidian
fill 81 121 517 81 138 517 minecraft:polished_blackstone_bricks
setblock 81 121 518 minecraft:crying_obsidian
fill 81 121 519 81 138 519 minecraft:polished_blackstone_bricks
setblock 81 121 520 minecraft:crying_obsidian
fill 81 121 521 81 138 521 minecraft:polished_blackstone_bricks
setblock 81 121 522 minecraft:crying_obsidian
fill 81 121 523 81 138 523 minecraft:polished_blackstone_bricks
setblock 82 121 515 minecraft:crying_obsidian
fill 82 121 516 82 138 516 minecraft:polished_blackstone_bricks
setblock 82 121 517 minecraft:crying_obsidian
fill 82 121 518 82 138 518 minecraft:polished_blackstone_bricks
setblock 82 121 519 minecraft:crying_obsidian
fill 82 121 520 82 138 520 minecraft:polished_blackstone_bricks
setblock 82 121 521 minecraft:crying_obsidian
fill 82 121 522 82 138 522 minecraft:polished_blackstone_bricks
setblock 82 121 523 minecraft:crying_obsidian
fill 83 121 510 83 209 510 minecraft:polished_blackstone_bricks
fill 83 121 515 83 138 515 minecraft:polished_blackstone_bricks
setblock 83 121 516 minecraft:crying_obsidian
fill 83 121 517 83 138 517 minecraft:polished_blackstone_bricks
setblock 83 121 518 minecraft:crying_obsidian
fill 83 121 519 83 138 519 minecraft:polished_blackstone_bricks
setblock 83 121 520 minecraft:crying_obsidian
fill 83 121 521 83 138 521 minecraft:polished_blackstone_bricks
setblock 83 121 522 minecraft:crying_obsidian
fill 83 121 523 83 138 523 minecraft:polished_blackstone_bricks
setblock 84 121 515 minecraft:crying_obsidian
fill 84 121 516 84 138 516 minecraft:polished_blackstone_bricks
setblock 84 121 517 minecraft:crying_obsidian
fill 84 121 518 84 138 518 minecraft:polished_blackstone_bricks
setblock 84 121 519 minecraft:crying_obsidian
fill 84 121 520 84 138 520 minecraft:polished_blackstone_bricks
setblock 84 121 521 minecraft:crying_obsidian
fill 84 121 522 84 138 522 minecraft:polished_blackstone_bricks
setblock 84 121 523 minecraft:crying_obsidian
fill 85 121 515 85 138 515 minecraft:polished_blackstone_bricks
setblock 85 121 516 minecraft:crying_obsidian
fill 85 121 517 85 138 517 minecraft:polished_blackstone_bricks
setblock 85 121 518 minecraft:crying_obsidian
fill 85 121 519 85 138 519 minecraft:polished_blackstone_bricks
setblock 85 121 520 minecraft:crying_obsidian
fill 85 121 521 85 138 521 minecraft:polished_blackstone_bricks
setblock 85 121 522 minecraft:crying_obsidian
fill 85 121 523 85 138 523 minecraft:polished_blackstone_bricks
setblock 86 121 515 minecraft:crying_obsidian
fill 86 121 516 86 138 516 minecraft:polished_blackstone_bricks
setblock 86 121 517 minecraft:crying_obsidian
fill 86 121 518 86 138 518 minecraft:polished_blackstone_bricks
setblock 86 121 519 minecraft:crying_obsidian
fill 86 121 520 86 138 520 minecraft:polished_blackstone_bricks
setblock 86 121 521 minecraft:crying_obsidian
fill 86 121 522 86 138 522 minecraft:polished_blackstone_bricks
setblock 86 121 523 minecraft:crying_obsidian
fill 87 121 515 87 138 515 minecraft:polished_blackstone_bricks
setblock 87 121 516 minecraft:crying_obsidian
fill 87 121 517 87 138 517 minecraft:polished_blackstone_bricks
setblock 87 121 518 minecraft:crying_obsidian
fill 87 121 519 87 138 519 minecraft:polished_blackstone_bricks
setblock 87 121 520 minecraft:crying_obsidian
fill 87 121 521 87 138 521 minecraft:polished_blackstone_bricks
setblock 87 121 522 minecraft:crying_obsidian
fill 87 121 523 87 138 523 minecraft:polished_blackstone_bricks
setblock 88 121 515 minecraft:crying_obsidian
fill 88 121 516 89 121 516 minecraft:polished_blackstone_bricks
setblock 88 121 517 minecraft:crying_obsidian
fill 88 121 518 89 138 518 minecraft:polished_blackstone_bricks
setblock 88 121 519 minecraft:crying_obsidian
fill 88 121 520 89 172 520 minecraft:polished_blackstone_bricks
setblock 88 121 521 minecraft:crying_obsidian
fill 88 121 522 89 138 522 minecraft:polished_blackstone_bricks
setblock 88 121 523 minecraft:crying_obsidian
fill 89 121 510 89 121 513 minecraft:polished_blackstone_bricks
setblock 89 121 514 minecraft:black_concrete
setblock 89 121 515 minecraft:polished_blackstone_bricks
fill 89 121 517 89 210 517 minecraft:polished_blackstone_bricks
fill 89 121 519 89 213 519 minecraft:polished_blackstone_bricks
fill 89 121 521 89 213 521 minecraft:polished_blackstone_bricks
fill 89 121 523 89 125 524 minecraft:polished_blackstone_bricks
setblock 89 121 525 minecraft:black_concrete
fill 89 121 526 89 125 529 minecraft:polished_blackstone_bricks
fill 89 121 534 89 121 536 minecraft:polished_blackstone_bricks
setblock 89 121 537 minecraft:black_concrete
fill 89 121 538 89 125 542 minecraft:polished_blackstone_bricks
fill 89 121 546 89 125 547 minecraft:polished_blackstone_bricks
setblock 89 121 548 minecraft:black_concrete
fill 89 121 549 89 125 551 minecraft:polished_blackstone_bricks
fill 47 122 514 47 210 514 minecraft:polished_blackstone_bricks
fill 47 122 516 47 125 516 minecraft:polished_blackstone_bricks
fill 47 122 519 47 125 519 minecraft:polished_blackstone_bricks
fill 47 122 522 47 213 522 minecraft:polished_blackstone_bricks
fill 47 122 524 47 213 526 minecraft:polished_blackstone_bricks
setblock 47 122 527 minecraft:black_concrete
fill 47 122 528 47 125 528 minecraft:polished_blackstone_bricks
fill 47 122 530 47 125 534 minecraft:polished_blackstone_bricks
setblock 47 122 535 minecraft:black_concrete
fill 47 122 536 47 211 539 minecraft:polished_blackstone_bricks
fill 51 122 510 51 213 510 minecraft:polished_blackstone_bricks
fill 54 122 511 54 123 511 minecraft:polished_blackstone_bricks
fill 54 122 513 54 123 513 minecraft:polished_blackstone_bricks
fill 54 122 515 54 123 515 minecraft:polished_blackstone_bricks
fill 54 122 517 54 123 517 minecraft:polished_blackstone_bricks
fill 54 122 519 54 123 519 minecraft:polished_blackstone_bricks
fill 55 122 512 55 123 512 minecraft:polished_blackstone_bricks
fill 55 122 514 55 123 514 minecraft:polished_blackstone_bricks
fill 55 122 516 55 123 516 minecraft:polished_blackstone_bricks
fill 55 122 518 55 123 518 minecraft:polished_blackstone_bricks
fill 55 122 520 55 123 520 minecraft:polished_blackstone_bricks
fill 56 122 511 56 123 511 minecraft:polished_blackstone_bricks
fill 56 122 513 56 123 513 minecraft:polished_blackstone_bricks
fill 56 122 515 56 123 515 minecraft:polished_blackstone_bricks
fill 56 122 517 56 123 517 minecraft:polished_blackstone_bricks
fill 56 122 519 56 123 519 minecraft:polished_blackstone_bricks
fill 57 122 512 57 123 512 minecraft:polished_blackstone_bricks
fill 57 122 514 57 123 514 minecraft:polished_blackstone_bricks
fill 57 122 516 57 123 516 minecraft:polished_blackstone_bricks
fill 57 122 518 57 123 518 minecraft:polished_blackstone_bricks
fill 57 122 520 57 123 520 minecraft:polished_blackstone_bricks
fill 58 122 511 58 123 511 minecraft:polished_blackstone_bricks
fill 58 122 513 58 123 513 minecraft:polished_blackstone_bricks
fill 58 122 515 58 123 515 minecraft:polished_blackstone_bricks
fill 58 122 517 58 123 517 minecraft:polished_blackstone_bricks
fill 58 122 519 58 123 519 minecraft:polished_blackstone_bricks
fill 59 122 512 59 123 512 minecraft:polished_blackstone_bricks
fill 59 122 514 59 123 514 minecraft:polished_blackstone_bricks
fill 59 122 516 59 123 516 minecraft:polished_blackstone_bricks
fill 59 122 518 59 123 518 minecraft:polished_blackstone_bricks
fill 59 122 520 59 123 520 minecraft:polished_blackstone_bricks
fill 60 122 510 60 123 511 minecraft:polished_blackstone_bricks
fill 60 122 513 60 123 513 minecraft:polished_blackstone_bricks
fill 60 122 515 60 123 515 minecraft:polished_blackstone_bricks
fill 60 122 517 60 123 517 minecraft:polished_blackstone_bricks
fill 60 122 519 60 123 519 minecraft:polished_blackstone_bricks
fill 61 122 510 67 125 510 minecraft:polished_blackstone_bricks
fill 61 122 512 61 123 512 minecraft:polished_blackstone_bricks
fill 61 122 514 61 123 514 minecraft:polished_blackstone_bricks
fill 61 122 516 61 123 516 minecraft:polished_blackstone_bricks
fill 61 122 518 61 123 518 minecraft:polished_blackstone_bricks
fill 61 122 520 61 123 520 minecraft:polished_blackstone_bricks
fill 62 122 511 62 123 511 minecraft:polished_blackstone_bricks
fill 62 122 513 62 123 513 minecraft:polished_blackstone_bricks
fill 62 122 515 62 123 515 minecraft:polished_blackstone_bricks
fill 62 122 517 62 123 517 minecraft:polished_blackstone_bricks
fill 62 122 519 62 123 519 minecraft:polished_blackstone_bricks
setblock 68 122 510 minecraft:black_concrete
fill 69 122 510 81 125 510 minecraft:polished_blackstone_bricks
fill 75 122 552 76 213 552 minecraft:polished_blackstone_bricks
setblock 77 122 552 minecraft:black_concrete
fill 78 122 515 78 123 515 minecraft:polished_blackstone_bricks
fill 78 122 517 78 123 517 minecraft:polished_blackstone_bricks
fill 78 122 519 78 123 519 minecraft:polished_blackstone_bricks
fill 78 122 521 78 123 521 minecraft:polished_blackstone_bricks
fill 78 122 523 78 123 523 minecraft:polished_blackstone_bricks
fill 78 122 552 83 125 552 minecraft:polished_blackstone_bricks
fill 79 122 516 79 123 516 minecraft:polished_blackstone_bricks
fill 79 122 518 79 123 518 minecraft:polished_blackstone_bricks
fill 79 122 520 79 123 520 minecraft:polished_blackstone_bricks
fill 79 122 522 79 123 522 minecraft:polished_blackstone_bricks
fill 80 122 515 80 123 515 minecraft:polished_blackstone_bricks
fill 80 122 517 80 123 517 minecraft:polished_blackstone_bricks
fill 80 122 519 80 123 519 minecraft:polished_blackstone_bricks
fill 80 122 521 80 123 521 minecraft:polished_blackstone_bricks
fill 80 122 523 80 123 523 minecraft:polished_blackstone_bricks
fill 81 122 516 81 123 516 minecraft:polished_blackstone_bricks
fill 81 122 518 81 123 518 minecraft:polished_blackstone_bricks
fill 81 122 520 81 123 520 minecraft:polished_blackstone_bricks
fill 81 122 522 81 123 522 minecraft:polished_blackstone_bricks
setblock 82 122 510 minecraft:black_concrete
fill 82 122 515 82 123 515 minecraft:polished_blackstone_bricks
fill 82 122 517 82 123 517 minecraft:polished_blackstone_bricks
fill 82 122 519 82 123 519 minecraft:polished_blackstone_bricks
fill 82 122 521 82 123 521 minecraft:polished_blackstone_bricks
fill 82 122 523 82 123 523 minecraft:polished_blackstone_bricks
fill 83 122 516 83 123 516 minecraft:polished_blackstone_bricks
fill 83 122 518 83 123 518 minecraft:polished_blackstone_bricks
fill 83 122 520 83 123 520 minecraft:polished_blackstone_bricks
fill 83 122 522 83 123 522 minecraft:polished_blackstone_bricks
fill 84 122 515 84 123 515 minecraft:polished_blackstone_bricks
fill 84 122 517 84 123 517 minecraft:polished_blackstone_bricks
fill 84 122 519 84 123 519 minecraft:polished_blackstone_bricks
fill 84 122 521 84 123 521 minecraft:polished_blackstone_bricks
fill 84 122 523 84 123 523 minecraft:polished_blackstone_bricks
setblock 84 122 552 minecraft:black_concrete
fill 85 122 516 85 123 516 minecraft:polished_blackstone_bricks
fill 85 122 518 85 123 518 minecraft:polished_blackstone_bricks
fill 85 122 520 85 123 520 minecraft:polished_blackstone_bricks
fill 85 122 522 85 123 522 minecraft:polished_blackstone_bricks
fill 85 122 552 88 125 552 minecraft:polished_blackstone_bricks
fill 86 122 515 86 123 515 minecraft:polished_blackstone_bricks
fill 86 122 517 86 123 517 minecraft:polished_blackstone_bricks
fill 86 122 519 86 123 519 minecraft:polished_blackstone_bricks
fill 86 122 521 86 123 521 minecraft:polished_blackstone_bricks
fill 86 122 523 86 123 523 minecraft:polished_blackstone_bricks
fill 87 122 516 88 123 516 minecraft:polished_blackstone_bricks
fill 87 122 518 87 123 518 minecraft:polished_blackstone_bricks
fill 87 122 520 87 123 520 minecraft:polished_blackstone_bricks
fill 87 122 522 87 123 522 minecraft:polished_blackstone_bricks
fill 88 122 510 89 213 510 minecraft:polished_blackstone_bricks
fill 88 122 515 88 123 515 minecraft:polished_blackstone_bricks
fill 88 122 517 88 123 517 minecraft:polished_blackstone_bricks
fill 88 122 519 88 123 519 minecraft:polished_blackstone_bricks
fill 88 122 521 88 123 521 minecraft:polished_blackstone_bricks
fill 88 122 523 88 123 523 minecraft:polished_blackstone_bricks
fill 89 122 511 89 122 512 minecraft:black_concrete
fill 89 122 513 89 125 514 minecraft:polished_blackstone_bricks
fill 89 122 515 89 122 516 minecraft:black_concrete
fill 89 122 525 89 125 525 minecraft:polished_blackstone_bricks
fill 89 122 534 89 125 535 minecraft:polished_blackstone_bricks
setblock 89 122 536 minecraft:black_concrete
fill 89 122 537 89 125 537 minecraft:polished_blackstone_bricks
fill 89 122 548 89 125 548 minecraft:polished_blackstone_bricks
setblock 89 122 552 minecraft:black_concrete
fill 47 123 510 47 213 510 minecraft:polished_blackstone_bricks
fill 47 123 527 47 213 527 minecraft:polished_blackstone_bricks
fill 47 123 535 47 213 535 minecraft:polished_blackstone_bricks
fill 49 123 540 49 124 543 minecraft:iron_bars
setblock 50 123 513 minecraft:light[level=11]
setblock 50 123 521 minecraft:light[level=11]
setblock 50 123 529 minecraft:light[level=11]
setblock 50 123 537 minecraft:light[level=11]
setblock 50 123 545 minecraft:light[level=11]
setblock 58 123 521 minecraft:light[level=11]
setblock 58 123 529 minecraft:light[level=11]
setblock 58 123 537 minecraft:light[level=11]
setblock 58 123 545 minecraft:light[level=11]
fill 59 123 510 59 213 510 minecraft:polished_blackstone_bricks
setblock 66 123 513 minecraft:light[level=11]
setblock 66 123 521 minecraft:light[level=11]
setblock 66 123 537 minecraft:light[level=11]
setblock 66 123 545 minecraft:light[level=11]
fill 68 123 510 68 125 510 minecraft:polished_blackstone_bricks
setblock 74 123 513 minecraft:light[level=11]
setblock 74 123 521 minecraft:light[level=11]
setblock 74 123 529 minecraft:light[level=11]
setblock 74 123 537 minecraft:light[level=11]
setblock 74 123 545 minecraft:light[level=11]
fill 77 123 552 77 213 552 minecraft:polished_blackstone_bricks
fill 82 123 510 82 213 510 minecraft:polished_blackstone_bricks
setblock 82 123 513 minecraft:light[level=11]
setblock 82 123 529 minecraft:light[level=11]
setblock 82 123 537 minecraft:light[level=11]
setblock 82 123 545 minecraft:light[level=11]
fill 84 123 552 84 125 552 minecraft:polished_blackstone_bricks
fill 89 123 511 89 125 512 minecraft:polished_blackstone_bricks
fill 89 123 515 89 214 516 minecraft:polished_blackstone_bricks
fill 89 123 536 89 125 536 minecraft:polished_blackstone_bricks
fill 89 123 552 89 213 552 minecraft:polished_blackstone_bricks
setblock 54 124 511 minecraft:crying_obsidian
setblock 54 124 513 minecraft:crying_obsidian
setblock 54 124 515 minecraft:crying_obsidian
setblock 54 124 517 minecraft:crying_obsidian
setblock 54 124 519 minecraft:crying_obsidian
setblock 55 124 512 minecraft:crying_obsidian
setblock 55 124 514 minecraft:crying_obsidian
setblock 55 124 516 minecraft:crying_obsidian
setblock 55 124 518 minecraft:crying_obsidian
setblock 55 124 520 minecraft:crying_obsidian
setblock 56 124 511 minecraft:crying_obsidian
setblock 56 124 513 minecraft:crying_obsidian
setblock 56 124 515 minecraft:crying_obsidian
setblock 56 124 517 minecraft:crying_obsidian
setblock 56 124 519 minecraft:crying_obsidian
setblock 57 124 512 minecraft:crying_obsidian
setblock 57 124 514 minecraft:crying_obsidian
setblock 57 124 516 minecraft:crying_obsidian
setblock 57 124 518 minecraft:crying_obsidian
setblock 57 124 520 minecraft:crying_obsidian
setblock 58 124 511 minecraft:crying_obsidian
setblock 58 124 513 minecraft:crying_obsidian
setblock 58 124 515 minecraft:crying_obsidian
setblock 58 124 517 minecraft:crying_obsidian
setblock 58 124 519 minecraft:crying_obsidian
setblock 59 124 512 minecraft:crying_obsidian
setblock 59 124 514 minecraft:crying_obsidian
setblock 59 124 516 minecraft:crying_obsidian
setblock 59 124 518 minecraft:crying_obsidian
setblock 59 124 520 minecraft:crying_obsidian
fill 60 124 510 60 209 510 minecraft:polished_blackstone_bricks
setblock 60 124 511 minecraft:crying_obsidian
setblock 60 124 513 minecraft:crying_obsidian
setblock 60 124 515 minecraft:crying_obsidian
setblock 60 124 517 minecraft:crying_obsidian
setblock 60 124 519 minecraft:crying_obsidian
setblock 61 124 512 minecraft:crying_obsidian
setblock 61 124 514 minecraft:crying_obsidian
setblock 61 124 516 minecraft:crying_obsidian
setblock 61 124 518 minecraft:crying_obsidian
setblock 61 124 520 minecraft:crying_obsidian
setblock 62 124 511 minecraft:crying_obsidian
setblock 62 124 513 minecraft:crying_obsidian
setblock 62 124 515 minecraft:crying_obsidian
setblock 62 124 517 minecraft:crying_obsidian
setblock 62 124 519 minecraft:crying_obsidian
setblock 78 124 515 minecraft:crying_obsidian
setblock 78 124 517 minecraft:crying_obsidian
setblock 78 124 519 minecraft:crying_obsidian
setblock 78 124 521 minecraft:crying_obsidian
setblock 78 124 523 minecraft:crying_obsidian
setblock 79 124 516 minecraft:crying_obsidian
setblock 79 124 518 minecraft:crying_obsidian
setblock 79 124 520 minecraft:crying_obsidian
setblock 79 124 522 minecraft:crying_obsidian
setblock 80 124 515 minecraft:crying_obsidian
setblock 80 124 517 minecraft:crying_obsidian
setblock 80 124 519 minecraft:crying_obsidian
setblock 80 124 521 minecraft:crying_obsidian
setblock 80 124 523 minecraft:crying_obsidian
setblock 81 124 516 minecraft:crying_obsidian
setblock 81 124 518 minecraft:crying_obsidian
setblock 81 124 520 minecraft:crying_obsidian
setblock 81 124 522 minecraft:crying_obsidian
setblock 82 124 515 minecraft:crying_obsidian
setblock 82 124 517 minecraft:crying_obsidian
setblock 82 124 519 minecraft:crying_obsidian
setblock 82 124 521 minecraft:crying_obsidian
setblock 82 124 523 minecraft:crying_obsidian
setblock 83 124 516 minecraft:crying_obsidian
setblock 83 124 518 minecraft:crying_obsidian
setblock 83 124 520 minecraft:crying_obsidian
setblock 83 124 522 minecraft:crying_obsidian
setblock 84 124 515 minecraft:crying_obsidian
setblock 84 124 517 minecraft:crying_obsidian
setblock 84 124 519 minecraft:crying_obsidian
setblock 84 124 521 minecraft:crying_obsidian
setblock 84 124 523 minecraft:crying_obsidian
setblock 85 124 516 minecraft:crying_obsidian
setblock 85 124 518 minecraft:crying_obsidian
setblock 85 124 520 minecraft:crying_obsidian
setblock 85 124 522 minecraft:crying_obsidian
setblock 86 124 515 minecraft:crying_obsidian
setblock 86 124 517 minecraft:crying_obsidian
setblock 86 124 519 minecraft:crying_obsidian
setblock 86 124 521 minecraft:crying_obsidian
setblock 86 124 523 minecraft:crying_obsidian
setblock 87 124 516 minecraft:crying_obsidian
setblock 87 124 518 minecraft:crying_obsidian
setblock 87 124 520 minecraft:crying_obsidian
setblock 87 124 522 minecraft:crying_obsidian
setblock 88 124 515 minecraft:crying_obsidian
setblock 88 124 516 minecraft:polished_blackstone_bricks
setblock 88 124 517 minecraft:crying_obsidian
setblock 88 124 519 minecraft:crying_obsidian
setblock 88 124 521 minecraft:crying_obsidian
setblock 88 124 523 minecraft:crying_obsidian
fill 48 125 514 48 125 519 minecraft:blackstone
fill 48 125 526 48 125 531 minecraft:blackstone
fill 48 125 538 48 125 543 minecraft:blackstone
fill 48 125 550 48 125 551 minecraft:blackstone
fill 49 125 551 52 125 551 minecraft:blackstone
fill 52 125 511 57 125 511 minecraft:blackstone
fill 54 125 513 54 126 513 minecraft:polished_blackstone_bricks
fill 54 125 515 54 126 515 minecraft:polished_blackstone_bricks
fill 54 125 517 54 126 517 minecraft:polished_blackstone_bricks
fill 54 125 519 54 126 519 minecraft:polished_blackstone_bricks
fill 55 125 512 55 126 512 minecraft:polished_blackstone_bricks
fill 55 125 514 55 126 514 minecraft:polished_blackstone_bricks
fill 55 125 516 55 126 516 minecraft:polished_blackstone_bricks
fill 55 125 518 55 126 518 minecraft:polished_blackstone_bricks
fill 55 125 520 55 126 520 minecraft:polished_blackstone_bricks
fill 56 125 513 56 126 513 minecraft:polished_blackstone_bricks
fill 56 125 515 56 126 515 minecraft:polished_blackstone_bricks
fill 56 125 517 56 126 517 minecraft:polished_blackstone_bricks
fill 56 125 519 56 126 519 minecraft:polished_blackstone_bricks
fill 57 125 512 57 126 512 minecraft:polished_blackstone_bricks
fill 57 125 514 57 126 514 minecraft:polished_blackstone_bricks
fill 57 125 516 57 126 516 minecraft:polished_blackstone_bricks
fill 57 125 518 57 126 518 minecraft:polished_blackstone_bricks
fill 57 125 520 57 126 520 minecraft:polished_blackstone_bricks
fill 58 125 511 58 126 511 minecraft:polished_blackstone_bricks
fill 58 125 513 58 126 513 minecraft:polished_blackstone_bricks
fill 58 125 515 58 126 515 minecraft:polished_blackstone_bricks
fill 58 125 517 58 126 517 minecraft:polished_blackstone_bricks
fill 58 125 519 58 126 519 minecraft:polished_blackstone_bricks
fill 59 125 512 59 126 512 minecraft:polished_blackstone_bricks
fill 59 125 514 59 126 514 minecraft:polished_blackstone_bricks
fill 59 125 516 59 126 516 minecraft:polished_blackstone_bricks
fill 59 125 518 59 126 518 minecraft:polished_blackstone_bricks
fill 59 125 520 59 126 520 minecraft:polished_blackstone_bricks
fill 59 125 551 64 125 551 minecraft:blackstone
fill 60 125 511 60 126 511 minecraft:polished_blackstone_bricks
fill 60 125 513 60 126 513 minecraft:polished_blackstone_bricks
fill 60 125 515 60 126 515 minecraft:polished_blackstone_bricks
fill 60 125 517 60 126 517 minecraft:polished_blackstone_bricks
fill 60 125 519 60 126 519 minecraft:polished_blackstone_bricks
fill 61 125 512 61 126 512 minecraft:polished_blackstone_bricks
fill 61 125 514 61 126 514 minecraft:polished_blackstone_bricks
fill 61 125 516 61 126 516 minecraft:polished_blackstone_bricks
fill 61 125 518 61 126 518 minecraft:polished_blackstone_bricks
fill 61 125 520 61 126 520 minecraft:polished_blackstone_bricks
fill 62 125 511 62 126 511 minecraft:polished_blackstone_bricks
fill 62 125 513 62 126 513 minecraft:polished_blackstone_bricks
fill 62 125 515 62 126 515 minecraft:polished_blackstone_bricks
fill 62 125 517 62 126 517 minecraft:polished_blackstone_bricks
fill 62 125 519 62 126 519 minecraft:polished_blackstone_bricks
fill 64 125 511 69 125 511 minecraft:blackstone
fill 71 125 551 76 125 551 minecraft:blackstone
fill 76 125 511 81 125 511 minecraft:blackstone
fill 78 125 515 78 126 515 minecraft:polished_blackstone_bricks
fill 78 125 517 78 126 517 minecraft:polished_blackstone_bricks
fill 78 125 519 78 126 519 minecraft:polished_blackstone_bricks
fill 78 125 521 78 126 521 minecraft:polished_blackstone_bricks
fill 78 125 523 78 126 523 minecraft:polished_blackstone_bricks
fill 79 125 516 79 126 516 minecraft:polished_blackstone_bricks
fill 79 125 518 79 126 518 minecraft:polished_blackstone_bricks
fill 79 125 520 79 126 520 minecraft:polished_blackstone_bricks
fill 79 125 522 79 126 522 minecraft:polished_blackstone_bricks
fill 80 125 515 80 126 515 minecraft:polished_blackstone_bricks
fill 80 125 517 80 126 517 minecraft:polished_blackstone_bricks
fill 80 125 519 80 126 519 minecraft:polished_blackstone_bricks
fill 80 125 521 80 126 521 minecraft:polished_blackstone_bricks
fill 80 125 523 80 126 523 minecraft:polished_blackstone_bricks
fill 81 125 516 81 126 516 minecraft:polished_blackstone_bricks
fill 81 125 518 81 126 518 minecraft:polished_blackstone_bricks
fill 81 125 520 81 126 520 minecraft:polished_blackstone_bricks
fill 81 125 522 81 126 522 minecraft:polished_blackstone_bricks
fill 82 125 515 82 126 515 minecraft:polished_blackstone_bricks
fill 82 125 517 82 126 517 minecraft:polished_blackstone_bricks
fill 82 125 519 82 126 519 minecraft:polished_blackstone_bricks
fill 82 125 521 82 126 521 minecraft:polished_blackstone_bricks
fill 82 125 523 82 126 523 minecraft:polished_blackstone_bricks
fill 83 125 516 83 126 516 minecraft:polished_blackstone_bricks
fill 83 125 518 83 126 518 minecraft:polished_blackstone_bricks
fill 83 125 520 83 126 520 minecraft:polished_blackstone_bricks
fill 83 125 522 83 126 522 minecraft:polished_blackstone_bricks
fill 83 125 551 88 125 551 minecraft:blackstone
fill 84 125 515 84 126 515 minecraft:polished_blackstone_bricks
fill 84 125 517 84 126 517 minecraft:polished_blackstone_bricks
fill 84 125 519 84 126 519 minecraft:polished_blackstone_bricks
fill 84 125 521 84 126 521 minecraft:polished_blackstone_bricks
fill 84 125 523 84 126 523 minecraft:polished_blackstone_bricks
fill 85 125 516 85 126 516 minecraft:polished_blackstone_bricks
fill 85 125 518 85 126 518 minecraft:polished_blackstone_bricks
fill 85 125 520 85 126 520 minecraft:polished_blackstone_bricks
fill 85 125 522 85 126 522 minecraft:polished_blackstone_bricks
fill 86 125 515 86 126 515 minecraft:polished_blackstone_bricks
fill 86 125 517 86 126 517 minecraft:polished_blackstone_bricks
fill 86 125 519 86 126 519 minecraft:polished_blackstone_bricks
fill 86 125 521 86 126 521 minecraft:polished_blackstone_bricks
fill 86 125 523 86 126 523 minecraft:polished_blackstone_bricks
fill 87 125 516 87 126 516 minecraft:polished_blackstone_bricks
fill 87 125 518 87 126 518 minecraft:polished_blackstone_bricks
fill 87 125 520 87 126 520 minecraft:polished_blackstone_bricks
fill 87 125 522 87 126 522 minecraft:polished_blackstone_bricks
fill 88 125 511 88 125 516 minecraft:blackstone
fill 88 125 517 88 126 517 minecraft:polished_blackstone_bricks
fill 88 125 519 88 126 519 minecraft:polished_blackstone_bricks
fill 88 125 521 88 126 521 minecraft:polished_blackstone_bricks
fill 88 125 523 88 125 528 minecraft:blackstone
fill 88 125 535 88 125 540 minecraft:blackstone
fill 88 125 547 88 125 550 minecraft:blackstone
fill 47 126 516 47 131 519 minecraft:crying_obsidian
fill 47 126 528 47 131 531 minecraft:crying_obsidian
fill 47 126 532 47 210 534 minecraft:polished_blackstone_bricks
fill 47 126 540 47 131 543 minecraft:crying_obsidian
fill 47 126 544 47 209 551 minecraft:polished_blackstone_bricks
fill 47 126 552 50 131 552 minecraft:crying_obsidian
fill 49 126 521 49 127 527 minecraft:iron_bars
fill 51 126 552 58 209 552 minecraft:polished_blackstone_bricks
fill 52 126 510 53 209 510 minecraft:polished_blackstone_bricks
fill 54 126 510 57 131 510 minecraft:crying_obsidian
fill 54 126 511 57 126 511 minecraft:polished_blackstone_bricks
fill 58 126 510 58 209 510 minecraft:polished_blackstone_bricks
fill 59 126 552 62 131 552 minecraft:crying_obsidian
fill 61 126 510 65 209 510 minecraft:polished_blackstone_bricks
fill 63 126 552 70 210 552 minecraft:polished_blackstone_bricks
fill 66 126 510 69 131 510 minecraft:crying_obsidian
fill 70 126 510 77 213 510 minecraft:polished_blackstone_bricks
fill 71 126 552 74 131 552 minecraft:crying_obsidian
fill 78 126 510 81 131 510 minecraft:crying_obsidian
fill 78 126 552 82 209 552 minecraft:polished_blackstone_bricks
fill 81 126 524 85 127 527 minecraft:blackstone
fill 83 126 552 86 131 552 minecraft:crying_obsidian
fill 86 126 525 87 126 525 minecraft:blackstone
fill 87 126 552 88 210 552 minecraft:polished_blackstone_bricks
fill 88 126 515 88 126 516 minecraft:polished_blackstone_bricks
setblock 88 126 523 minecraft:polished_blackstone_bricks
fill 89 126 511 89 131 514 minecraft:crying_obsidian
fill 89 126 523 89 131 526 minecraft:crying_obsidian
fill 89 126 527 89 210 529 minecraft:polished_blackstone_bricks
fill 89 126 534 89 213 534 minecraft:polished_blackstone_bricks
fill 89 126 535 89 131 538 minecraft:crying_obsidian
fill 89 126 539 89 209 542 minecraft:polished_blackstone_bricks
fill 89 126 546 89 213 546 minecraft:polished_blackstone_bricks
fill 89 126 547 89 131 550 minecraft:crying_obsidian
fill 89 126 551 89 213 551 minecraft:polished_blackstone_bricks
setblock 54 127 511 minecraft:crying_obsidian
setblock 54 127 513 minecraft:crying_obsidian
setblock 54 127 515 minecraft:crying_obsidian
setblock 54 127 517 minecraft:crying_obsidian
setblock 54 127 519 minecraft:crying_obsidian
fill 55 127 511 55 144 511 minecraft:polished_blackstone_bricks
setblock 55 127 512 minecraft:crying_obsidian
setblock 55 127 514 minecraft:crying_obsidian
setblock 55 127 516 minecraft:crying_obsidian
setblock 55 127 518 minecraft:crying_obsidian
setblock 55 127 520 minecraft:crying_obsidian
setblock 56 127 511 minecraft:crying_obsidian
setblock 56 127 513 minecraft:crying_obsidian
setblock 56 127 515 minecraft:crying_obsidian
setblock 56 127 517 minecraft:crying_obsidian
setblock 56 127 519 minecraft:crying_obsidian
fill 57 127 511 57 144 511 minecraft:polished_blackstone_bricks
setblock 57 127 512 minecraft:crying_obsidian
setblock 57 127 514 minecraft:crying_obsidian
setblock 57 127 516 minecraft:crying_obsidian
setblock 57 127 518 minecraft:crying_obsidian
setblock 57 127 520 minecraft:crying_obsidian
setblock 58 127 511 minecraft:crying_obsidian
setblock 58 127 513 minecraft:crying_obsidian
setblock 58 127 515 minecraft:crying_obsidian
setblock 58 127 517 minecraft:crying_obsidian
setblock 58 127 519 minecraft:crying_obsidian
setblock 59 127 512 minecraft:crying_obsidian
setblock 59 127 514 minecraft:crying_obsidian
setblock 59 127 516 minecraft:crying_obsidian
setblock 59 127 518 minecraft:crying_obsidian
setblock 59 127 520 minecraft:crying_obsidian
setblock 60 127 511 minecraft:crying_obsidian
setblock 60 127 513 minecraft:crying_obsidian
setblock 60 127 515 minecraft:crying_obsidian
setblock 60 127 517 minecraft:crying_obsidian
setblock 60 127 519 minecraft:crying_obsidian
setblock 61 127 512 minecraft:crying_obsidian
setblock 61 127 514 minecraft:crying_obsidian
setblock 61 127 516 minecraft:crying_obsidian
setblock 61 127 518 minecraft:crying_obsidian
setblock 61 127 520 minecraft:crying_obsidian
setblock 62 127 511 minecraft:crying_obsidian
setblock 62 127 513 minecraft:crying_obsidian
setblock 62 127 515 minecraft:crying_obsidian
setblock 62 127 517 minecraft:crying_obsidian
setblock 62 127 519 minecraft:crying_obsidian
setblock 78 127 515 minecraft:crying_obsidian
setblock 78 127 517 minecraft:crying_obsidian
setblock 78 127 519 minecraft:crying_obsidian
setblock 78 127 521 minecraft:crying_obsidian
setblock 78 127 523 minecraft:crying_obsidian
setblock 79 127 516 minecraft:crying_obsidian
setblock 79 127 518 minecraft:crying_obsidian
setblock 79 127 520 minecraft:crying_obsidian
setblock 79 127 522 minecraft:crying_obsidian
setblock 80 127 515 minecraft:crying_obsidian
setblock 80 127 517 minecraft:crying_obsidian
setblock 80 127 519 minecraft:crying_obsidian
setblock 80 127 521 minecraft:crying_obsidian
setblock 80 127 523 minecraft:crying_obsidian
setblock 81 127 516 minecraft:crying_obsidian
setblock 81 127 518 minecraft:crying_obsidian
setblock 81 127 520 minecraft:crying_obsidian
setblock 81 127 522 minecraft:crying_obsidian
setblock 82 127 515 minecraft:crying_obsidian
setblock 82 127 517 minecraft:crying_obsidian
setblock 82 127 519 minecraft:crying_obsidian
setblock 82 127 521 minecraft:crying_obsidian
setblock 82 127 523 minecraft:crying_obsidian
setblock 83 127 516 minecraft:crying_obsidian
setblock 83 127 518 minecraft:crying_obsidian
setblock 83 127 520 minecraft:crying_obsidian
setblock 83 127 522 minecraft:crying_obsidian
setblock 84 127 515 minecraft:crying_obsidian
setblock 84 127 517 minecraft:crying_obsidian
setblock 84 127 519 minecraft:crying_obsidian
setblock 84 127 521 minecraft:crying_obsidian
setblock 84 127 523 minecraft:crying_obsidian
setblock 85 127 516 minecraft:crying_obsidian
setblock 85 127 518 minecraft:crying_obsidian
setblock 85 127 520 minecraft:crying_obsidian
setblock 85 127 522 minecraft:crying_obsidian
setblock 86 127 515 minecraft:crying_obsidian
setblock 86 127 517 minecraft:crying_obsidian
setblock 86 127 519 minecraft:crying_obsidian
setblock 86 127 521 minecraft:crying_obsidian
setblock 86 127 523 minecraft:crying_obsidian
setblock 87 127 516 minecraft:crying_obsidian
setblock 87 127 518 minecraft:crying_obsidian
setblock 87 127 520 minecraft:crying_obsidian
setblock 87 127 522 minecraft:crying_obsidian
setblock 88 127 515 minecraft:crying_obsidian
fill 88 127 516 88 138 516 minecraft:polished_blackstone_bricks
setblock 88 127 517 minecraft:crying_obsidian
setblock 88 127 519 minecraft:crying_obsidian
setblock 88 127 521 minecraft:crying_obsidian
setblock 88 127 523 minecraft:crying_obsidian
fill 54 128 511 54 129 511 minecraft:polished_blackstone_bricks
fill 54 128 513 54 129 513 minecraft:polished_blackstone_bricks
fill 54 128 515 54 129 515 minecraft:polished_blackstone_bricks
fill 54 128 517 54 129 517 minecraft:polished_blackstone_bricks
fill 54 128 519 54 129 519 minecraft:polished_blackstone_bricks
fill 55 128 512 55 129 512 minecraft:polished_blackstone_bricks
fill 55 128 514 55 129 514 minecraft:polished_blackstone_bricks
fill 55 128 516 55 129 516 minecraft:polished_blackstone_bricks
fill 55 128 518 55 129 518 minecraft:polished_blackstone_bricks
fill 55 128 520 55 129 520 minecraft:polished_blackstone_bricks
fill 56 128 511 56 129 511 minecraft:polished_blackstone_bricks
fill 56 128 513 56 129 513 minecraft:polished_blackstone_bricks
fill 56 128 515 56 129 515 minecraft:polished_blackstone_bricks
fill 56 128 517 56 129 517 minecraft:polished_blackstone_bricks
fill 56 128 519 56 129 519 minecraft:polished_blackstone_bricks
fill 57 128 512 57 129 512 minecraft:polished_blackstone_bricks
fill 57 128 514 57 129 514 minecraft:polished_blackstone_bricks
fill 57 128 516 57 129 516 minecraft:polished_blackstone_bricks
fill 57 128 518 57 129 518 minecraft:polished_blackstone_bricks
fill 57 128 520 57 129 520 minecraft:polished_blackstone_bricks
fill 58 128 511 58 129 511 minecraft:polished_blackstone_bricks
fill 58 128 513 58 129 513 minecraft:polished_blackstone_bricks
fill 58 128 515 58 129 515 minecraft:polished_blackstone_bricks
fill 58 128 517 58 129 517 minecraft:polished_blackstone_bricks
fill 58 128 519 58 129 519 minecraft:polished_blackstone_bricks
fill 59 128 512 59 129 512 minecraft:polished_blackstone_bricks
fill 59 128 514 59 129 514 minecraft:polished_blackstone_bricks
fill 59 128 516 59 129 516 minecraft:polished_blackstone_bricks
fill 59 128 518 59 129 518 minecraft:polished_blackstone_bricks
fill 59 128 520 59 129 520 minecraft:polished_blackstone_bricks
fill 60 128 511 60 129 511 minecraft:polished_blackstone_bricks
fill 60 128 513 60 129 513 minecraft:polished_blackstone_bricks
fill 60 128 515 60 129 515 minecraft:polished_blackstone_bricks
fill 60 128 517 60 129 517 minecraft:polished_blackstone_bricks
fill 60 128 519 60 129 519 minecraft:polished_blackstone_bricks
fill 61 128 512 61 129 512 minecraft:polished_blackstone_bricks
fill 61 128 514 61 129 514 minecraft:polished_blackstone_bricks
fill 61 128 516 61 129 516 minecraft:polished_blackstone_bricks
fill 61 128 518 61 129 518 minecraft:polished_blackstone_bricks
fill 61 128 520 61 129 520 minecraft:polished_blackstone_bricks
fill 62 128 511 62 129 511 minecraft:polished_blackstone_bricks
fill 62 128 513 62 129 513 minecraft:polished_blackstone_bricks
fill 62 128 515 62 129 515 minecraft:polished_blackstone_bricks
fill 62 128 517 62 129 517 minecraft:polished_blackstone_bricks
fill 62 128 519 62 129 519 minecraft:polished_blackstone_bricks
fill 78 128 515 78 129 515 minecraft:polished_blackstone_bricks
fill 78 128 517 78 129 517 minecraft:polished_blackstone_bricks
fill 78 128 519 78 129 519 minecraft:polished_blackstone_bricks
fill 78 128 521 78 129 521 minecraft:polished_blackstone_bricks
fill 78 128 523 78 129 523 minecraft:polished_blackstone_bricks
fill 79 128 516 79 129 516 minecraft:polished_blackstone_bricks
fill 79 128 518 79 129 518 minecraft:polished_blackstone_bricks
fill 79 128 520 79 129 520 minecraft:polished_blackstone_bricks
fill 79 128 522 79 129 522 minecraft:polished_blackstone_bricks
fill 80 128 515 80 129 515 minecraft:polished_blackstone_bricks
fill 80 128 517 80 129 517 minecraft:polished_blackstone_bricks
fill 80 128 519 80 129 519 minecraft:polished_blackstone_bricks
fill 80 128 521 80 129 521 minecraft:polished_blackstone_bricks
fill 80 128 523 80 129 523 minecraft:polished_blackstone_bricks
fill 81 128 516 81 129 516 minecraft:polished_blackstone_bricks
fill 81 128 518 81 129 518 minecraft:polished_blackstone_bricks
fill 81 128 520 81 129 520 minecraft:polished_blackstone_bricks
fill 81 128 522 81 129 522 minecraft:polished_blackstone_bricks
fill 82 128 515 82 129 515 minecraft:polished_blackstone_bricks
fill 82 128 517 82 129 517 minecraft:polished_blackstone_bricks
fill 82 128 519 82 129 519 minecraft:polished_blackstone_bricks
fill 82 128 521 82 129 521 minecraft:polished_blackstone_bricks
fill 82 128 523 82 129 523 minecraft:polished_blackstone_bricks
fill 82 128 525 84 136 525 minecraft:purple_stained_glass
fill 83 128 516 83 129 516 minecraft:polished_blackstone_bricks
fill 83 128 518 83 129 518 minecraft:polished_blackstone_bricks
fill 83 128 520 83 129 520 minecraft:polished_blackstone_bricks
fill 83 128 522 83 129 522 minecraft:polished_blackstone_bricks
fill 83 128 524 83 136 524 minecraft:purple_stained_glass
fill 83 128 526 83 136 526 minecraft:purple_stained_glass
fill 84 128 515 84 129 515 minecraft:polished_blackstone_bricks
fill 84 128 517 84 129 517 minecraft:polished_blackstone_bricks
fill 84 128 519 84 129 519 minecraft:polished_blackstone_bricks
fill 84 128 521 84 129 521 minecraft:polished_blackstone_bricks
fill 84 128 523 84 129 523 minecraft:polished_blackstone_bricks
fill 85 128 516 85 129 516 minecraft:polished_blackstone_bricks
fill 85 128 518 85 129 518 minecraft:polished_blackstone_bricks
fill 85 128 520 85 129 520 minecraft:polished_blackstone_bricks
fill 85 128 522 85 129 522 minecraft:polished_blackstone_bricks
fill 86 128 515 86 129 515 minecraft:polished_blackstone_bricks
fill 86 128 517 86 129 517 minecraft:polished_blackstone_bricks
fill 86 128 519 86 129 519 minecraft:polished_blackstone_bricks
fill 86 128 521 86 129 521 minecraft:polished_blackstone_bricks
fill 86 128 523 86 129 523 minecraft:polished_blackstone_bricks
fill 87 128 516 87 129 516 minecraft:polished_blackstone_bricks
fill 87 128 518 87 129 518 minecraft:polished_blackstone_bricks
fill 87 128 520 87 129 520 minecraft:polished_blackstone_bricks
fill 87 128 522 87 129 522 minecraft:polished_blackstone_bricks
fill 88 128 515 88 129 515 minecraft:polished_blackstone_bricks
fill 88 128 517 88 129 517 minecraft:polished_blackstone_bricks
fill 88 128 519 88 129 519 minecraft:polished_blackstone_bricks
fill 88 128 521 88 129 521 minecraft:polished_blackstone_bricks
fill 88 128 523 88 129 523 minecraft:polished_blackstone_bricks
setblock 54 130 511 minecraft:crying_obsidian
setblock 54 130 513 minecraft:crying_obsidian
setblock 54 130 515 minecraft:crying_obsidian
setblock 54 130 517 minecraft:crying_obsidian
setblock 54 130 519 minecraft:crying_obsidian
setblock 55 130 512 minecraft:crying_obsidian
setblock 55 130 514 minecraft:crying_obsidian
setblock 55 130 516 minecraft:crying_obsidian
setblock 55 130 518 minecraft:crying_obsidian
setblock 55 130 520 minecraft:crying_obsidian
setblock 56 130 511 minecraft:crying_obsidian
setblock 56 130 513 minecraft:crying_obsidian
setblock 56 130 515 minecraft:crying_obsidian
setblock 56 130 517 minecraft:crying_obsidian
setblock 56 130 519 minecraft:crying_obsidian
setblock 57 130 512 minecraft:crying_obsidian
setblock 57 130 514 minecraft:crying_obsidian
setblock 57 130 516 minecraft:crying_obsidian
setblock 57 130 518 minecraft:crying_obsidian
setblock 57 130 520 minecraft:crying_obsidian
setblock 58 130 511 minecraft:crying_obsidian
setblock 58 130 513 minecraft:crying_obsidian
setblock 58 130 515 minecraft:crying_obsidian
setblock 58 130 517 minecraft:crying_obsidian
setblock 58 130 519 minecraft:crying_obsidian
setblock 59 130 512 minecraft:crying_obsidian
setblock 59 130 514 minecraft:crying_obsidian
setblock 59 130 516 minecraft:crying_obsidian
setblock 59 130 518 minecraft:crying_obsidian
setblock 59 130 520 minecraft:crying_obsidian
setblock 60 130 511 minecraft:crying_obsidian
setblock 60 130 513 minecraft:crying_obsidian
setblock 60 130 515 minecraft:crying_obsidian
setblock 60 130 517 minecraft:crying_obsidian
setblock 60 130 519 minecraft:crying_obsidian
setblock 61 130 512 minecraft:crying_obsidian
setblock 61 130 514 minecraft:crying_obsidian
setblock 61 130 516 minecraft:crying_obsidian
setblock 61 130 518 minecraft:crying_obsidian
setblock 61 130 520 minecraft:crying_obsidian
setblock 62 130 511 minecraft:crying_obsidian
setblock 62 130 513 minecraft:crying_obsidian
setblock 62 130 515 minecraft:crying_obsidian
setblock 62 130 517 minecraft:crying_obsidian
setblock 62 130 519 minecraft:crying_obsidian
setblock 78 130 515 minecraft:crying_obsidian
setblock 78 130 517 minecraft:crying_obsidian
setblock 78 130 519 minecraft:crying_obsidian
setblock 78 130 521 minecraft:crying_obsidian
setblock 78 130 523 minecraft:crying_obsidian
setblock 79 130 516 minecraft:crying_obsidian
setblock 79 130 518 minecraft:crying_obsidian
setblock 79 130 520 minecraft:crying_obsidian
setblock 79 130 522 minecraft:crying_obsidian
setblock 80 130 515 minecraft:crying_obsidian
setblock 80 130 517 minecraft:crying_obsidian
setblock 80 130 519 minecraft:crying_obsidian
setblock 80 130 521 minecraft:crying_obsidian
setblock 80 130 523 minecraft:crying_obsidian
setblock 81 130 516 minecraft:crying_obsidian
setblock 81 130 518 minecraft:crying_obsidian
setblock 81 130 520 minecraft:crying_obsidian
setblock 81 130 522 minecraft:crying_obsidian
setblock 82 130 515 minecraft:crying_obsidian
setblock 82 130 517 minecraft:crying_obsidian
setblock 82 130 519 minecraft:crying_obsidian
setblock 82 130 521 minecraft:crying_obsidian
setblock 82 130 523 minecraft:crying_obsidian
setblock 83 130 516 minecraft:crying_obsidian
setblock 83 130 518 minecraft:crying_obsidian
setblock 83 130 520 minecraft:crying_obsidian
setblock 83 130 522 minecraft:crying_obsidian
setblock 84 130 515 minecraft:crying_obsidian
setblock 84 130 517 minecraft:crying_obsidian
setblock 84 130 519 minecraft:crying_obsidian
setblock 84 130 521 minecraft:crying_obsidian
setblock 84 130 523 minecraft:crying_obsidian
setblock 85 130 516 minecraft:crying_obsidian
setblock 85 130 518 minecraft:crying_obsidian
setblock 85 130 520 minecraft:crying_obsidian
setblock 85 130 522 minecraft:crying_obsidian
setblock 86 130 515 minecraft:crying_obsidian
setblock 86 130 517 minecraft:crying_obsidian
setblock 86 130 519 minecraft:crying_obsidian
setblock 86 130 521 minecraft:crying_obsidian
setblock 86 130 523 minecraft:crying_obsidian
setblock 87 130 516 minecraft:crying_obsidian
setblock 87 130 518 minecraft:crying_obsidian
setblock 87 130 520 minecraft:crying_obsidian
setblock 87 130 522 minecraft:crying_obsidian
setblock 88 130 515 minecraft:crying_obsidian
setblock 88 130 517 minecraft:crying_obsidian
setblock 88 130 519 minecraft:crying_obsidian
setblock 88 130 521 minecraft:crying_obsidian
setblock 88 130 523 minecraft:crying_obsidian
setblock 50 131 513 minecraft:light[level=11]
setblock 50 131 521 minecraft:light[level=11]
setblock 50 131 529 minecraft:light[level=11]
setblock 50 131 537 minecraft:light[level=11]
setblock 50 131 545 minecraft:light[level=11]
fill 54 131 511 54 132 511 minecraft:polished_blackstone_bricks
fill 54 131 513 54 132 513 minecraft:polished_blackstone_bricks
fill 54 131 515 54 132 515 minecraft:polished_blackstone_bricks
fill 54 131 517 54 132 517 minecraft:polished_blackstone_bricks
fill 54 131 519 54 132 519 minecraft:polished_blackstone_bricks
fill 55 131 512 55 132 512 minecraft:polished_blackstone_bricks
fill 55 131 514 55 132 514 minecraft:polished_blackstone_bricks
fill 55 131 516 55 132 516 minecraft:polished_blackstone_bricks
fill 55 131 518 55 132 518 minecraft:polished_blackstone_bricks
fill 55 131 520 55 132 520 minecraft:polished_blackstone_bricks
fill 56 131 511 56 132 511 minecraft:polished_blackstone_bricks
fill 56 131 513 56 132 513 minecraft:polished_blackstone_bricks
fill 56 131 515 56 132 515 minecraft:polished_blackstone_bricks
fill 56 131 517 56 132 517 minecraft:polished_blackstone_bricks
fill 56 131 519 56 132 519 minecraft:polished_blackstone_bricks
fill 57 131 512 57 132 512 minecraft:polished_blackstone_bricks
fill 57 131 514 57 132 514 minecraft:polished_blackstone_bricks
fill 57 131 516 57 132 516 minecraft:polished_blackstone_bricks
fill 57 131 518 57 132 518 minecraft:polished_blackstone_bricks
fill 57 131 520 57 132 520 minecraft:polished_blackstone_bricks
fill 58 131 511 58 132 511 minecraft:polished_blackstone_bricks
fill 58 131 513 58 132 513 minecraft:polished_blackstone_bricks
fill 58 131 515 58 132 515 minecraft:polished_blackstone_bricks
fill 58 131 517 58 132 517 minecraft:polished_blackstone_bricks
fill 58 131 519 58 132 519 minecraft:polished_blackstone_bricks
setblock 58 131 521 minecraft:light[level=11]
setblock 58 131 529 minecraft:light[level=11]
setblock 58 131 537 minecraft:light[level=11]
setblock 58 131 545 minecraft:light[level=11]
fill 59 131 512 59 132 512 minecraft:polished_blackstone_bricks
fill 59 131 514 59 132 514 minecraft:polished_blackstone_bricks
fill 59 131 516 59 132 516 minecraft:polished_blackstone_bricks
fill 59 131 518 59 132 518 minecraft:polished_blackstone_bricks
fill 59 131 520 59 132 520 minecraft:polished_blackstone_bricks
fill 60 131 511 60 132 511 minecraft:polished_blackstone_bricks
fill 60 131 513 60 132 513 minecraft:polished_blackstone_bricks
fill 60 131 515 60 132 515 minecraft:polished_blackstone_bricks
fill 60 131 517 60 132 517 minecraft:polished_blackstone_bricks
fill 60 131 519 60 132 519 minecraft:polished_blackstone_bricks
fill 61 131 512 61 132 512 minecraft:polished_blackstone_bricks
fill 61 131 514 61 132 514 minecraft:polished_blackstone_bricks
fill 61 131 516 61 132 516 minecraft:polished_blackstone_bricks
fill 61 131 518 61 132 518 minecraft:polished_blackstone_bricks
fill 61 131 520 61 132 520 minecraft:polished_blackstone_bricks
fill 62 131 511 62 132 511 minecraft:polished_blackstone_bricks
fill 62 131 513 62 132 513 minecraft:polished_blackstone_bricks
fill 62 131 515 62 132 515 minecraft:polished_blackstone_bricks
fill 62 131 517 62 132 517 minecraft:polished_blackstone_bricks
fill 62 131 519 62 132 519 minecraft:polished_blackstone_bricks
setblock 66 131 513 minecraft:light[level=11]
setblock 66 131 521 minecraft:light[level=11]
setblock 66 131 537 minecraft:light[level=11]
setblock 66 131 545 minecraft:light[level=11]
setblock 74 131 513 minecraft:light[level=11]
setblock 74 131 521 minecraft:light[level=11]
setblock 74 131 529 minecraft:light[level=11]
setblock 74 131 537 minecraft:light[level=11]
setblock 74 131 545 minecraft:light[level=11]
fill 78 131 515 78 132 515 minecraft:polished_blackstone_bricks
fill 78 131 517 78 132 517 minecraft:polished_blackstone_bricks
fill 78 131 519 78 132 519 minecraft:polished_blackstone_bricks
fill 78 131 521 78 132 521 minecraft:polished_blackstone_bricks
fill 78 131 523 78 132 523 minecraft:polished_blackstone_bricks
fill 79 131 516 79 132 516 minecraft:polished_blackstone_bricks
fill 79 131 518 79 132 518 minecraft:polished_blackstone_bricks
fill 79 131 520 79 132 520 minecraft:polished_blackstone_bricks
fill 79 131 522 79 132 522 minecraft:polished_blackstone_bricks
fill 80 131 515 80 132 515 minecraft:polished_blackstone_bricks
fill 80 131 517 80 132 517 minecraft:polished_blackstone_bricks
fill 80 131 519 80 132 519 minecraft:polished_blackstone_bricks
fill 80 131 521 80 132 521 minecraft:polished_blackstone_bricks
fill 80 131 523 80 132 523 minecraft:polished_blackstone_bricks
fill 81 131 516 81 132 516 minecraft:polished_blackstone_bricks
fill 81 131 518 81 132 518 minecraft:polished_blackstone_bricks
fill 81 131 520 81 132 520 minecraft:polished_blackstone_bricks
fill 81 131 522 81 132 522 minecraft:polished_blackstone_bricks
setblock 82 131 513 minecraft:light[level=11]
fill 82 131 515 82 132 515 minecraft:polished_blackstone_bricks
fill 82 131 517 82 132 517 minecraft:polished_blackstone_bricks
fill 82 131 519 82 132 519 minecraft:polished_blackstone_bricks
fill 82 131 521 82 132 521 minecraft:polished_blackstone_bricks
fill 82 131 523 82 132 523 minecraft:polished_blackstone_bricks
setblock 82 131 529 minecraft:light[level=11]
setblock 82 131 537 minecraft:light[level=11]
setblock 82 131 545 minecraft:light[level=11]
fill 83 131 516 83 132 516 minecraft:polished_blackstone_bricks
fill 83 131 518 83 132 518 minecraft:polished_blackstone_bricks
fill 83 131 520 83 132 520 minecraft:polished_blackstone_bricks
fill 83 131 522 83 132 522 minecraft:polished_blackstone_bricks
fill 84 131 515 84 132 515 minecraft:polished_blackstone_bricks
fill 84 131 517 84 132 517 minecraft:polished_blackstone_bricks
fill 84 131 519 84 132 519 minecraft:polished_blackstone_bricks
fill 84 131 521 84 132 521 minecraft:polished_blackstone_bricks
fill 84 131 523 84 132 523 minecraft:polished_blackstone_bricks
fill 85 131 516 85 132 516 minecraft:polished_blackstone_bricks
fill 85 131 518 85 132 518 minecraft:polished_blackstone_bricks
fill 85 131 520 85 132 520 minecraft:polished_blackstone_bricks
fill 85 131 522 85 132 522 minecraft:polished_blackstone_bricks
fill 86 131 515 86 132 515 minecraft:polished_blackstone_bricks
fill 86 131 517 86 132 517 minecraft:polished_blackstone_bricks
fill 86 131 519 86 132 519 minecraft:polished_blackstone_bricks
fill 86 131 521 86 132 521 minecraft:polished_blackstone_bricks
fill 86 131 523 86 132 523 minecraft:polished_blackstone_bricks
fill 87 131 516 87 132 516 minecraft:polished_blackstone_bricks
fill 87 131 518 87 132 518 minecraft:polished_blackstone_bricks
fill 87 131 520 87 132 520 minecraft:polished_blackstone_bricks
fill 87 131 522 87 132 522 minecraft:polished_blackstone_bricks
fill 88 131 515 88 132 515 minecraft:polished_blackstone_bricks
fill 88 131 517 88 132 517 minecraft:polished_blackstone_bricks
fill 88 131 519 88 132 519 minecraft:polished_blackstone_bricks
fill 88 131 521 88 132 521 minecraft:polished_blackstone_bricks
fill 88 131 523 88 132 523 minecraft:polished_blackstone_bricks
fill 47 132 516 47 145 516 minecraft:polished_blackstone_bricks
fill 47 132 517 47 132 518 minecraft:crying_obsidian
fill 47 132 519 47 145 519 minecraft:polished_blackstone_bricks
fill 47 132 528 47 145 528 minecraft:polished_blackstone_bricks
fill 47 132 529 47 132 530 minecraft:crying_obsidian
fill 47 132 531 47 145 531 minecraft:polished_blackstone_bricks
fill 47 132 540 47 145 540 minecraft:polished_blackstone_bricks
fill 47 132 541 47 132 542 minecraft:crying_obsidian
fill 47 132 543 47 145 543 minecraft:polished_blackstone_bricks
fill 47 132 552 47 145 552 minecraft:polished_blackstone_bricks
fill 48 132 552 49 132 552 minecraft:crying_obsidian
fill 50 132 552 50 145 552 minecraft:polished_blackstone_bricks
fill 54 132 510 54 145 510 minecraft:polished_blackstone_bricks
fill 55 132 510 56 132 510 minecraft:crying_obsidian
fill 57 132 510 57 145 510 minecraft:polished_blackstone_bricks
fill 59 132 552 59 145 552 minecraft:polished_blackstone_bricks
fill 60 132 552 61 132 552 minecraft:crying_obsidian
fill 62 132 552 62 145 552 minecraft:polished_blackstone_bricks
fill 66 132 510 66 145 510 minecraft:polished_blackstone_bricks
fill 67 132 510 68 132 510 minecraft:crying_obsidian
fill 69 132 510 69 145 510 minecraft:polished_blackstone_bricks
fill 71 132 552 71 145 552 minecraft:polished_blackstone_bricks
fill 72 132 552 73 132 552 minecraft:crying_obsidian
fill 74 132 552 74 145 552 minecraft:polished_blackstone_bricks
fill 78 132 510 78 145 510 minecraft:polished_blackstone_bricks
fill 79 132 510 80 132 510 minecraft:crying_obsidian
fill 81 132 510 81 145 510 minecraft:polished_blackstone_bricks
fill 83 132 552 83 145 552 minecraft:polished_blackstone_bricks
fill 84 132 552 85 132 552 minecraft:crying_obsidian
fill 86 132 552 86 145 552 minecraft:polished_blackstone_bricks
fill 89 132 511 89 145 511 minecraft:polished_blackstone_bricks
fill 89 132 512 89 132 513 minecraft:crying_obsidian
fill 89 132 514 89 145 514 minecraft:polished_blackstone_bricks
fill 89 132 523 89 145 523 minecraft:polished_blackstone_bricks
fill 89 132 524 89 132 525 minecraft:crying_obsidian
fill 89 132 526 89 145 526 minecraft:polished_blackstone_bricks
fill 89 132 535 89 145 535 minecraft:polished_blackstone_bricks
fill 89 132 536 89 132 537 minecraft:crying_obsidian
fill 89 132 538 89 145 538 minecraft:polished_blackstone_bricks
fill 89 132 547 89 145 547 minecraft:polished_blackstone_bricks
fill 89 132 548 89 132 549 minecraft:crying_obsidian
fill 89 132 550 89 145 550 minecraft:polished_blackstone_bricks
fill 47 133 517 47 145 518 minecraft:polished_blackstone_bricks
fill 47 133 529 47 145 530 minecraft:polished_blackstone_bricks
fill 47 133 541 47 145 542 minecraft:polished_blackstone_bricks
fill 48 133 552 49 145 552 minecraft:polished_blackstone_bricks
setblock 54 133 511 minecraft:crying_obsidian
setblock 54 133 513 minecraft:crying_obsidian
setblock 54 133 515 minecraft:crying_obsidian
setblock 54 133 517 minecraft:crying_obsidian
setblock 54 133 519 minecraft:crying_obsidian
fill 55 133 510 56 145 510 minecraft:polished_blackstone_bricks
setblock 55 133 512 minecraft:crying_obsidian
setblock 55 133 514 minecraft:crying_obsidian
setblock 55 133 516 minecraft:crying_obsidian
setblock 55 133 518 minecraft:crying_obsidian
setblock 55 133 520 minecraft:crying_obsidian
setblock 56 133 511 minecraft:crying_obsidian
setblock 56 133 513 minecraft:crying_obsidian
setblock 56 133 515 minecraft:crying_obsidian
setblock 56 133 517 minecraft:crying_obsidian
setblock 56 133 519 minecraft:crying_obsidian
setblock 57 133 512 minecraft:crying_obsidian
setblock 57 133 514 minecraft:crying_obsidian
setblock 57 133 516 minecraft:crying_obsidian
setblock 57 133 518 minecraft:crying_obsidian
setblock 57 133 520 minecraft:crying_obsidian
setblock 58 133 511 minecraft:crying_obsidian
setblock 58 133 513 minecraft:crying_obsidian
setblock 58 133 515 minecraft:crying_obsidian
setblock 58 133 517 minecraft:crying_obsidian
setblock 58 133 519 minecraft:crying_obsidian
setblock 59 133 512 minecraft:crying_obsidian
setblock 59 133 514 minecraft:crying_obsidian
setblock 59 133 516 minecraft:crying_obsidian
setblock 59 133 518 minecraft:crying_obsidian
setblock 59 133 520 minecraft:crying_obsidian
setblock 60 133 511 minecraft:crying_obsidian
setblock 60 133 513 minecraft:crying_obsidian
setblock 60 133 515 minecraft:crying_obsidian
setblock 60 133 517 minecraft:crying_obsidian
setblock 60 133 519 minecraft:crying_obsidian
fill 60 133 552 61 145 552 minecraft:polished_blackstone_bricks
setblock 61 133 512 minecraft:crying_obsidian
setblock 61 133 514 minecraft:crying_obsidian
setblock 61 133 516 minecraft:crying_obsidian
setblock 61 133 518 minecraft:crying_obsidian
setblock 61 133 520 minecraft:crying_obsidian
setblock 62 133 511 minecraft:crying_obsidian
setblock 62 133 513 minecraft:crying_obsidian
setblock 62 133 515 minecraft:crying_obsidian
setblock 62 133 517 minecraft:crying_obsidian
setblock 62 133 519 minecraft:crying_obsidian
fill 67 133 510 68 145 510 minecraft:polished_blackstone_bricks
fill 72 133 552 73 145 552 minecraft:polished_blackstone_bricks
setblock 78 133 515 minecraft:crying_obsidian
setblock 78 133 517 minecraft:crying_obsidian
setblock 78 133 519 minecraft:crying_obsidian
setblock 78 133 521 minecraft:crying_obsidian
setblock 78 133 523 minecraft:crying_obsidian
fill 79 133 510 80 145 510 minecraft:polished_blackstone_bricks
setblock 79 133 516 minecraft:crying_obsidian
setblock 79 133 518 minecraft:crying_obsidian
setblock 79 133 520 minecraft:crying_obsidian
setblock 79 133 522 minecraft:crying_obsidian
setblock 80 133 515 minecraft:crying_obsidian
setblock 80 133 517 minecraft:crying_obsidian
setblock 80 133 519 minecraft:crying_obsidian
setblock 80 133 521 minecraft:crying_obsidian
setblock 80 133 523 minecraft:crying_obsidian
setblock 81 133 516 minecraft:crying_obsidian
setblock 81 133 518 minecraft:crying_obsidian
setblock 81 133 520 minecraft:crying_obsidian
setblock 81 133 522 minecraft:crying_obsidian
setblock 82 133 515 minecraft:crying_obsidian
setblock 82 133 517 minecraft:crying_obsidian
setblock 82 133 519 minecraft:crying_obsidian
setblock 82 133 521 minecraft:crying_obsidian
setblock 82 133 523 minecraft:crying_obsidian
setblock 83 133 516 minecraft:crying_obsidian
setblock 83 133 518 minecraft:crying_obsidian
setblock 83 133 520 minecraft:crying_obsidian
setblock 83 133 522 minecraft:crying_obsidian
setblock 84 133 515 minecraft:crying_obsidian
setblock 84 133 517 minecraft:crying_obsidian
setblock 84 133 519 minecraft:crying_obsidian
setblock 84 133 521 minecraft:crying_obsidian
setblock 84 133 523 minecraft:crying_obsidian
fill 84 133 552 85 145 552 minecraft:polished_blackstone_bricks
setblock 85 133 516 minecraft:crying_obsidian
setblock 85 133 518 minecraft:crying_obsidian
setblock 85 133 520 minecraft:crying_obsidian
setblock 85 133 522 minecraft:crying_obsidian
setblock 86 133 515 minecraft:crying_obsidian
setblock 86 133 517 minecraft:crying_obsidian
setblock 86 133 519 minecraft:crying_obsidian
setblock 86 133 521 minecraft:crying_obsidian
setblock 86 133 523 minecraft:crying_obsidian
setblock 87 133 516 minecraft:crying_obsidian
setblock 87 133 518 minecraft:crying_obsidian
setblock 87 133 520 minecraft:crying_obsidian
setblock 87 133 522 minecraft:crying_obsidian
setblock 88 133 515 minecraft:crying_obsidian
setblock 88 133 517 minecraft:crying_obsidian
setblock 88 133 519 minecraft:crying_obsidian
setblock 88 133 521 minecraft:crying_obsidian
setblock 88 133 523 minecraft:crying_obsidian
fill 89 133 512 89 145 513 minecraft:polished_blackstone_bricks
fill 89 133 524 89 145 525 minecraft:polished_blackstone_bricks
fill 89 133 536 89 145 537 minecraft:polished_blackstone_bricks
fill 89 133 548 89 145 549 minecraft:polished_blackstone_bricks
fill 54 134 511 54 135 511 minecraft:polished_blackstone_bricks
fill 54 134 513 54 135 513 minecraft:polished_blackstone_bricks
fill 54 134 515 54 135 515 minecraft:polished_blackstone_bricks
fill 54 134 517 54 135 517 minecraft:polished_blackstone_bricks
fill 54 134 519 54 135 519 minecraft:polished_blackstone_bricks
fill 55 134 512 55 135 512 minecraft:polished_blackstone_bricks
fill 55 134 514 55 135 514 minecraft:polished_blackstone_bricks
fill 55 134 516 55 135 516 minecraft:polished_blackstone_bricks
fill 55 134 518 55 135 518 minecraft:polished_blackstone_bricks
fill 55 134 520 55 135 520 minecraft:polished_blackstone_bricks
fill 56 134 511 56 135 511 minecraft:polished_blackstone_bricks
fill 56 134 513 56 135 513 minecraft:polished_blackstone_bricks
fill 56 134 515 56 135 515 minecraft:polished_blackstone_bricks
fill 56 134 517 56 135 517 minecraft:polished_blackstone_bricks
fill 56 134 519 56 135 519 minecraft:polished_blackstone_bricks
fill 57 134 512 57 135 512 minecraft:polished_blackstone_bricks
fill 57 134 514 57 135 514 minecraft:polished_blackstone_bricks
fill 57 134 516 57 135 516 minecraft:polished_blackstone_bricks
fill 57 134 518 57 135 518 minecraft:polished_blackstone_bricks
fill 57 134 520 57 135 520 minecraft:polished_blackstone_bricks
fill 58 134 511 58 135 511 minecraft:polished_blackstone_bricks
fill 58 134 513 58 135 513 minecraft:polished_blackstone_bricks
fill 58 134 515 58 135 515 minecraft:polished_blackstone_bricks
fill 58 134 517 58 135 517 minecraft:polished_blackstone_bricks
fill 58 134 519 58 135 519 minecraft:polished_blackstone_bricks
fill 59 134 512 59 135 512 minecraft:polished_blackstone_bricks
fill 59 134 514 59 135 514 minecraft:polished_blackstone_bricks
fill 59 134 516 59 135 516 minecraft:polished_blackstone_bricks
fill 59 134 518 59 135 518 minecraft:polished_blackstone_bricks
fill 59 134 520 59 135 520 minecraft:polished_blackstone_bricks
fill 60 134 511 60 135 511 minecraft:polished_blackstone_bricks
fill 60 134 513 60 135 513 minecraft:polished_blackstone_bricks
fill 60 134 515 60 135 515 minecraft:polished_blackstone_bricks
fill 60 134 517 60 135 517 minecraft:polished_blackstone_bricks
fill 60 134 519 60 135 519 minecraft:polished_blackstone_bricks
fill 61 134 512 61 135 512 minecraft:polished_blackstone_bricks
fill 61 134 514 61 135 514 minecraft:polished_blackstone_bricks
fill 61 134 516 61 135 516 minecraft:polished_blackstone_bricks
fill 61 134 518 61 135 518 minecraft:polished_blackstone_bricks
fill 61 134 520 61 135 520 minecraft:polished_blackstone_bricks
fill 62 134 511 62 135 511 minecraft:polished_blackstone_bricks
fill 62 134 513 62 135 513 minecraft:polished_blackstone_bricks
fill 62 134 515 62 135 515 minecraft:polished_blackstone_bricks
fill 62 134 517 62 135 517 minecraft:polished_blackstone_bricks
fill 62 134 519 62 135 519 minecraft:polished_blackstone_bricks
fill 78 134 515 78 135 515 minecraft:polished_blackstone_bricks
fill 78 134 517 78 135 517 minecraft:polished_blackstone_bricks
fill 78 134 519 78 135 519 minecraft:polished_blackstone_bricks
fill 78 134 521 78 135 521 minecraft:polished_blackstone_bricks
fill 78 134 523 78 135 523 minecraft:polished_blackstone_bricks
fill 79 134 516 79 135 516 minecraft:polished_blackstone_bricks
fill 79 134 518 79 135 518 minecraft:polished_blackstone_bricks
fill 79 134 520 79 135 520 minecraft:polished_blackstone_bricks
fill 79 134 522 79 135 522 minecraft:polished_blackstone_bricks
fill 80 134 515 80 135 515 minecraft:polished_blackstone_bricks
fill 80 134 517 80 135 517 minecraft:polished_blackstone_bricks
fill 80 134 519 80 135 519 minecraft:polished_blackstone_bricks
fill 80 134 521 80 135 521 minecraft:polished_blackstone_bricks
fill 80 134 523 80 135 523 minecraft:polished_blackstone_bricks
fill 81 134 516 81 135 516 minecraft:polished_blackstone_bricks
fill 81 134 518 81 135 518 minecraft:polished_blackstone_bricks
fill 81 134 520 81 135 520 minecraft:polished_blackstone_bricks
fill 81 134 522 81 135 522 minecraft:polished_blackstone_bricks
fill 82 134 515 82 135 515 minecraft:polished_blackstone_bricks
fill 82 134 517 82 135 517 minecraft:polished_blackstone_bricks
fill 82 134 519 82 135 519 minecraft:polished_blackstone_bricks
fill 82 134 521 82 135 521 minecraft:polished_blackstone_bricks
fill 82 134 523 82 135 523 minecraft:polished_blackstone_bricks
fill 83 134 516 83 135 516 minecraft:polished_blackstone_bricks
fill 83 134 518 83 135 518 minecraft:polished_blackstone_bricks
fill 83 134 520 83 135 520 minecraft:polished_blackstone_bricks
fill 83 134 522 83 135 522 minecraft:polished_blackstone_bricks
fill 84 134 515 84 135 515 minecraft:polished_blackstone_bricks
fill 84 134 517 84 135 517 minecraft:polished_blackstone_bricks
fill 84 134 519 84 135 519 minecraft:polished_blackstone_bricks
fill 84 134 521 84 135 521 minecraft:polished_blackstone_bricks
fill 84 134 523 84 135 523 minecraft:polished_blackstone_bricks
fill 85 134 516 85 135 516 minecraft:polished_blackstone_bricks
fill 85 134 518 85 135 518 minecraft:polished_blackstone_bricks
fill 85 134 520 85 135 520 minecraft:polished_blackstone_bricks
fill 85 134 522 85 135 522 minecraft:polished_blackstone_bricks
fill 86 134 515 86 135 515 minecraft:polished_blackstone_bricks
fill 86 134 517 86 135 517 minecraft:polished_blackstone_bricks
fill 86 134 519 86 135 519 minecraft:polished_blackstone_bricks
fill 86 134 521 86 135 521 minecraft:polished_blackstone_bricks
fill 86 134 523 86 135 523 minecraft:polished_blackstone_bricks
fill 87 134 516 87 135 516 minecraft:polished_blackstone_bricks
fill 87 134 518 87 135 518 minecraft:polished_blackstone_bricks
fill 87 134 520 87 135 520 minecraft:polished_blackstone_bricks
fill 87 134 522 87 135 522 minecraft:polished_blackstone_bricks
fill 88 134 515 88 135 515 minecraft:polished_blackstone_bricks
fill 88 134 517 88 135 517 minecraft:polished_blackstone_bricks
fill 88 134 519 88 135 519 minecraft:polished_blackstone_bricks
fill 88 134 521 88 135 521 minecraft:polished_blackstone_bricks
fill 88 134 523 88 135 523 minecraft:polished_blackstone_bricks
setblock 54 136 511 minecraft:crying_obsidian
setblock 54 136 513 minecraft:crying_obsidian
setblock 54 136 515 minecraft:crying_obsidian
setblock 54 136 517 minecraft:crying_obsidian
setblock 54 136 519 minecraft:crying_obsidian
setblock 55 136 512 minecraft:crying_obsidian
setblock 55 136 514 minecraft:crying_obsidian
setblock 55 136 516 minecraft:crying_obsidian
setblock 55 136 518 minecraft:crying_obsidian
setblock 55 136 520 minecraft:crying_obsidian
setblock 56 136 511 minecraft:crying_obsidian
setblock 56 136 513 minecraft:crying_obsidian
setblock 56 136 515 minecraft:crying_obsidian
setblock 56 136 517 minecraft:crying_obsidian
setblock 56 136 519 minecraft:crying_obsidian
setblock 57 136 512 minecraft:crying_obsidian
setblock 57 136 514 minecraft:crying_obsidian
setblock 57 136 516 minecraft:crying_obsidian
setblock 57 136 518 minecraft:crying_obsidian
setblock 57 136 520 minecraft:crying_obsidian
setblock 58 136 511 minecraft:crying_obsidian
setblock 58 136 513 minecraft:crying_obsidian
setblock 58 136 515 minecraft:crying_obsidian
setblock 58 136 517 minecraft:crying_obsidian
setblock 58 136 519 minecraft:crying_obsidian
setblock 59 136 512 minecraft:crying_obsidian
setblock 59 136 514 minecraft:crying_obsidian
setblock 59 136 516 minecraft:crying_obsidian
setblock 59 136 518 minecraft:crying_obsidian
setblock 59 136 520 minecraft:crying_obsidian
setblock 60 136 511 minecraft:crying_obsidian
setblock 60 136 513 minecraft:crying_obsidian
setblock 60 136 515 minecraft:crying_obsidian
setblock 60 136 517 minecraft:crying_obsidian
setblock 60 136 519 minecraft:crying_obsidian
setblock 61 136 512 minecraft:crying_obsidian
setblock 61 136 514 minecraft:crying_obsidian
setblock 61 136 516 minecraft:crying_obsidian
setblock 61 136 518 minecraft:crying_obsidian
setblock 61 136 520 minecraft:crying_obsidian
setblock 62 136 511 minecraft:crying_obsidian
setblock 62 136 513 minecraft:crying_obsidian
setblock 62 136 515 minecraft:crying_obsidian
setblock 62 136 517 minecraft:crying_obsidian
setblock 62 136 519 minecraft:crying_obsidian
setblock 78 136 515 minecraft:crying_obsidian
setblock 78 136 517 minecraft:crying_obsidian
setblock 78 136 519 minecraft:crying_obsidian
setblock 78 136 521 minecraft:crying_obsidian
setblock 78 136 523 minecraft:crying_obsidian
setblock 79 136 516 minecraft:crying_obsidian
setblock 79 136 518 minecraft:crying_obsidian
setblock 79 136 520 minecraft:crying_obsidian
setblock 79 136 522 minecraft:crying_obsidian
setblock 80 136 515 minecraft:crying_obsidian
setblock 80 136 517 minecraft:crying_obsidian
setblock 80 136 519 minecraft:crying_obsidian
setblock 80 136 521 minecraft:crying_obsidian
setblock 80 136 523 minecraft:crying_obsidian
setblock 81 136 516 minecraft:crying_obsidian
setblock 81 136 518 minecraft:crying_obsidian
setblock 81 136 520 minecraft:crying_obsidian
setblock 81 136 522 minecraft:crying_obsidian
setblock 82 136 515 minecraft:crying_obsidian
setblock 82 136 517 minecraft:crying_obsidian
setblock 82 136 519 minecraft:crying_obsidian
setblock 82 136 521 minecraft:crying_obsidian
setblock 82 136 523 minecraft:crying_obsidian
setblock 83 136 516 minecraft:crying_obsidian
setblock 83 136 518 minecraft:crying_obsidian
setblock 83 136 520 minecraft:crying_obsidian
setblock 83 136 522 minecraft:crying_obsidian
setblock 84 136 515 minecraft:crying_obsidian
setblock 84 136 517 minecraft:crying_obsidian
setblock 84 136 519 minecraft:crying_obsidian
setblock 84 136 521 minecraft:crying_obsidian
setblock 84 136 523 minecraft:crying_obsidian
setblock 85 136 516 minecraft:crying_obsidian
setblock 85 136 518 minecraft:crying_obsidian
setblock 85 136 520 minecraft:crying_obsidian
setblock 85 136 522 minecraft:crying_obsidian
setblock 86 136 515 minecraft:crying_obsidian
setblock 86 136 517 minecraft:crying_obsidian
setblock 86 136 519 minecraft:crying_obsidian
setblock 86 136 521 minecraft:crying_obsidian
setblock 86 136 523 minecraft:crying_obsidian
setblock 87 136 516 minecraft:crying_obsidian
setblock 87 136 518 minecraft:crying_obsidian
setblock 87 136 520 minecraft:crying_obsidian
setblock 87 136 522 minecraft:crying_obsidian
setblock 88 136 515 minecraft:crying_obsidian
setblock 88 136 517 minecraft:crying_obsidian
setblock 88 136 519 minecraft:crying_obsidian
setblock 88 136 521 minecraft:crying_obsidian
setblock 88 136 523 minecraft:crying_obsidian
fill 54 137 511 54 138 511 minecraft:polished_blackstone_bricks
fill 54 137 513 54 138 513 minecraft:polished_blackstone_bricks
fill 54 137 515 54 138 515 minecraft:polished_blackstone_bricks
fill 54 137 517 54 138 517 minecraft:polished_blackstone_bricks
fill 54 137 519 54 138 519 minecraft:polished_blackstone_bricks
fill 55 137 512 55 138 512 minecraft:polished_blackstone_bricks
fill 55 137 514 55 138 514 minecraft:polished_blackstone_bricks
fill 55 137 516 55 138 516 minecraft:polished_blackstone_bricks
fill 55 137 518 55 138 518 minecraft:polished_blackstone_bricks
fill 55 137 520 55 138 520 minecraft:polished_blackstone_bricks
fill 56 137 511 56 138 511 minecraft:polished_blackstone_bricks
fill 56 137 513 56 138 513 minecraft:polished_blackstone_bricks
fill 56 137 515 56 138 515 minecraft:polished_blackstone_bricks
fill 56 137 517 56 138 517 minecraft:polished_blackstone_bricks
fill 56 137 519 56 138 519 minecraft:polished_blackstone_bricks
fill 57 137 512 57 138 512 minecraft:polished_blackstone_bricks
fill 57 137 514 57 138 514 minecraft:polished_blackstone_bricks
fill 57 137 516 57 138 516 minecraft:polished_blackstone_bricks
fill 57 137 518 57 138 518 minecraft:polished_blackstone_bricks
fill 57 137 520 57 138 520 minecraft:polished_blackstone_bricks
fill 58 137 511 58 138 511 minecraft:polished_blackstone_bricks
fill 58 137 513 58 138 513 minecraft:polished_blackstone_bricks
fill 58 137 515 58 138 515 minecraft:polished_blackstone_bricks
fill 58 137 517 58 138 517 minecraft:polished_blackstone_bricks
fill 58 137 519 58 138 519 minecraft:polished_blackstone_bricks
fill 59 137 512 59 138 512 minecraft:polished_blackstone_bricks
fill 59 137 514 59 138 514 minecraft:polished_blackstone_bricks
fill 59 137 516 59 138 516 minecraft:polished_blackstone_bricks
fill 59 137 518 59 138 518 minecraft:polished_blackstone_bricks
fill 59 137 520 59 138 520 minecraft:polished_blackstone_bricks
fill 60 137 511 60 138 511 minecraft:polished_blackstone_bricks
fill 60 137 513 60 138 513 minecraft:polished_blackstone_bricks
fill 60 137 515 60 138 515 minecraft:polished_blackstone_bricks
fill 60 137 517 60 138 517 minecraft:polished_blackstone_bricks
fill 60 137 519 60 138 519 minecraft:polished_blackstone_bricks
fill 61 137 512 61 138 512 minecraft:polished_blackstone_bricks
fill 61 137 514 61 138 514 minecraft:polished_blackstone_bricks
fill 61 137 516 61 138 516 minecraft:polished_blackstone_bricks
fill 61 137 518 61 138 518 minecraft:polished_blackstone_bricks
fill 61 137 520 61 138 520 minecraft:polished_blackstone_bricks
fill 62 137 511 62 138 511 minecraft:polished_blackstone_bricks
fill 62 137 513 62 138 513 minecraft:polished_blackstone_bricks
fill 62 137 515 62 138 515 minecraft:polished_blackstone_bricks
fill 62 137 517 62 138 517 minecraft:polished_blackstone_bricks
fill 62 137 519 62 138 519 minecraft:polished_blackstone_bricks
fill 78 137 515 78 138 515 minecraft:polished_blackstone_bricks
fill 78 137 517 78 138 517 minecraft:polished_blackstone_bricks
fill 78 137 519 78 138 519 minecraft:polished_blackstone_bricks
fill 78 137 521 78 138 521 minecraft:polished_blackstone_bricks
fill 78 137 523 78 138 523 minecraft:polished_blackstone_bricks
fill 79 137 516 79 138 516 minecraft:polished_blackstone_bricks
fill 79 137 518 79 138 518 minecraft:polished_blackstone_bricks
fill 79 137 520 79 138 520 minecraft:polished_blackstone_bricks
fill 79 137 522 79 138 522 minecraft:polished_blackstone_bricks
fill 80 137 515 80 138 515 minecraft:polished_blackstone_bricks
fill 80 137 517 80 138 517 minecraft:polished_blackstone_bricks
fill 80 137 519 80 138 519 minecraft:polished_blackstone_bricks
fill 80 137 521 80 138 521 minecraft:polished_blackstone_bricks
fill 80 137 523 80 138 523 minecraft:polished_blackstone_bricks
fill 81 137 516 81 138 516 minecraft:polished_blackstone_bricks
fill 81 137 518 81 138 518 minecraft:polished_blackstone_bricks
fill 81 137 520 81 138 520 minecraft:polished_blackstone_bricks
fill 81 137 522 81 138 522 minecraft:polished_blackstone_bricks
fill 82 137 515 82 138 515 minecraft:polished_blackstone_bricks
fill 82 137 517 82 138 517 minecraft:polished_blackstone_bricks
fill 82 137 519 82 138 519 minecraft:polished_blackstone_bricks
fill 82 137 521 82 138 521 minecraft:polished_blackstone_bricks
fill 82 137 523 82 138 523 minecraft:polished_blackstone_bricks
fill 83 137 516 83 138 516 minecraft:polished_blackstone_bricks
fill 83 137 518 83 138 518 minecraft:polished_blackstone_bricks
fill 83 137 520 83 138 520 minecraft:polished_blackstone_bricks
fill 83 137 522 83 138 522 minecraft:polished_blackstone_bricks
fill 84 137 515 84 138 515 minecraft:polished_blackstone_bricks
fill 84 137 517 84 138 517 minecraft:polished_blackstone_bricks
fill 84 137 519 84 138 519 minecraft:polished_blackstone_bricks
fill 84 137 521 84 138 521 minecraft:polished_blackstone_bricks
fill 84 137 523 84 138 523 minecraft:polished_blackstone_bricks
fill 85 137 516 85 138 516 minecraft:polished_blackstone_bricks
fill 85 137 518 85 138 518 minecraft:polished_blackstone_bricks
fill 85 137 520 85 138 520 minecraft:polished_blackstone_bricks
fill 85 137 522 85 138 522 minecraft:polished_blackstone_bricks
fill 86 137 515 86 138 515 minecraft:polished_blackstone_bricks
fill 86 137 517 86 138 517 minecraft:polished_blackstone_bricks
fill 86 137 519 86 138 519 minecraft:polished_blackstone_bricks
fill 86 137 521 86 138 521 minecraft:polished_blackstone_bricks
fill 86 137 523 86 138 523 minecraft:polished_blackstone_bricks
fill 87 137 516 87 138 516 minecraft:polished_blackstone_bricks
fill 87 137 518 87 138 518 minecraft:polished_blackstone_bricks
fill 87 137 520 87 138 520 minecraft:polished_blackstone_bricks
fill 87 137 522 87 138 522 minecraft:polished_blackstone_bricks
fill 88 137 515 88 138 515 minecraft:polished_blackstone_bricks
fill 88 137 517 88 138 517 minecraft:polished_blackstone_bricks
fill 88 137 519 88 172 519 minecraft:polished_blackstone_bricks
fill 88 137 521 88 172 521 minecraft:polished_blackstone_bricks
fill 88 137 523 88 138 523 minecraft:polished_blackstone_bricks
setblock 83 138 525 minecraft:crying_obsidian
setblock 50 139 513 minecraft:light[level=11]
setblock 50 139 521 minecraft:light[level=11]
setblock 50 139 529 minecraft:light[level=11]
setblock 50 139 537 minecraft:light[level=11]
setblock 50 139 545 minecraft:light[level=11]
setblock 54 139 511 minecraft:crying_obsidian
setblock 54 139 513 minecraft:crying_obsidian
setblock 54 139 515 minecraft:crying_obsidian
setblock 54 139 517 minecraft:crying_obsidian
setblock 54 139 519 minecraft:crying_obsidian
setblock 55 139 512 minecraft:crying_obsidian
setblock 55 139 514 minecraft:crying_obsidian
setblock 55 139 516 minecraft:crying_obsidian
setblock 55 139 518 minecraft:crying_obsidian
setblock 55 139 520 minecraft:crying_obsidian
setblock 56 139 511 minecraft:crying_obsidian
setblock 56 139 513 minecraft:crying_obsidian
setblock 56 139 515 minecraft:crying_obsidian
setblock 56 139 517 minecraft:crying_obsidian
setblock 56 139 519 minecraft:crying_obsidian
setblock 57 139 512 minecraft:crying_obsidian
setblock 57 139 514 minecraft:crying_obsidian
setblock 57 139 516 minecraft:crying_obsidian
setblock 57 139 518 minecraft:crying_obsidian
setblock 57 139 520 minecraft:crying_obsidian
setblock 58 139 511 minecraft:crying_obsidian
setblock 58 139 513 minecraft:crying_obsidian
setblock 58 139 515 minecraft:crying_obsidian
setblock 58 139 517 minecraft:crying_obsidian
setblock 58 139 519 minecraft:crying_obsidian
setblock 58 139 521 minecraft:light[level=11]
setblock 58 139 529 minecraft:light[level=11]
setblock 58 139 537 minecraft:light[level=11]
setblock 58 139 545 minecraft:light[level=11]
setblock 59 139 512 minecraft:crying_obsidian
setblock 59 139 514 minecraft:crying_obsidian
setblock 59 139 516 minecraft:crying_obsidian
setblock 59 139 518 minecraft:crying_obsidian
setblock 59 139 520 minecraft:crying_obsidian
setblock 60 139 511 minecraft:crying_obsidian
setblock 60 139 513 minecraft:crying_obsidian
setblock 60 139 515 minecraft:crying_obsidian
setblock 60 139 517 minecraft:crying_obsidian
setblock 60 139 519 minecraft:crying_obsidian
setblock 61 139 512 minecraft:crying_obsidian
setblock 61 139 514 minecraft:crying_obsidian
setblock 61 139 516 minecraft:crying_obsidian
setblock 61 139 518 minecraft:crying_obsidian
setblock 61 139 520 minecraft:crying_obsidian
setblock 62 139 511 minecraft:crying_obsidian
setblock 62 139 513 minecraft:crying_obsidian
setblock 62 139 515 minecraft:crying_obsidian
setblock 62 139 517 minecraft:crying_obsidian
setblock 62 139 519 minecraft:crying_obsidian
setblock 66 139 513 minecraft:light[level=11]
setblock 66 139 521 minecraft:light[level=11]
setblock 66 139 537 minecraft:light[level=11]
setblock 66 139 545 minecraft:light[level=11]
setblock 74 139 513 minecraft:light[level=11]
setblock 74 139 521 minecraft:light[level=11]
setblock 74 139 529 minecraft:light[level=11]
setblock 74 139 537 minecraft:light[level=11]
setblock 74 139 545 minecraft:light[level=11]
fill 79 139 516 87 139 522 minecraft:purple_stained_glass
setblock 82 139 513 minecraft:light[level=11]
setblock 82 139 529 minecraft:light[level=11]
setblock 82 139 537 minecraft:light[level=11]
setblock 82 139 545 minecraft:light[level=11]
fill 89 139 518 89 213 518 minecraft:polished_blackstone_bricks
fill 89 139 522 89 213 522 minecraft:polished_blackstone_bricks
fill 49 140 520 49 145 522 minecraft:polished_blackstone_bricks
fill 49 140 532 49 145 534 minecraft:polished_blackstone_bricks
fill 49 140 544 49 145 546 minecraft:polished_blackstone_bricks
fill 54 140 511 54 141 511 minecraft:polished_blackstone_bricks
fill 54 140 513 54 141 513 minecraft:polished_blackstone_bricks
fill 54 140 515 54 141 515 minecraft:polished_blackstone_bricks
fill 54 140 517 54 141 517 minecraft:polished_blackstone_bricks
fill 54 140 519 54 141 519 minecraft:polished_blackstone_bricks
fill 55 140 512 55 141 512 minecraft:polished_blackstone_bricks
fill 55 140 514 55 141 514 minecraft:polished_blackstone_bricks
fill 55 140 516 55 141 516 minecraft:polished_blackstone_bricks
fill 55 140 518 55 141 518 minecraft:polished_blackstone_bricks
fill 55 140 520 55 141 520 minecraft:polished_blackstone_bricks
fill 55 140 550 57 145 550 minecraft:polished_blackstone_bricks
fill 56 140 511 56 141 511 minecraft:polished_blackstone_bricks
fill 56 140 513 56 141 513 minecraft:polished_blackstone_bricks
fill 56 140 515 56 141 515 minecraft:polished_blackstone_bricks
fill 56 140 517 56 141 517 minecraft:polished_blackstone_bricks
fill 56 140 519 56 141 519 minecraft:polished_blackstone_bricks
fill 57 140 512 57 141 512 minecraft:polished_blackstone_bricks
fill 57 140 514 57 141 514 minecraft:polished_blackstone_bricks
fill 57 140 516 57 141 516 minecraft:polished_blackstone_bricks
fill 57 140 518 57 141 518 minecraft:polished_blackstone_bricks
fill 57 140 520 57 141 520 minecraft:polished_blackstone_bricks
fill 58 140 511 58 141 511 minecraft:polished_blackstone_bricks
fill 58 140 513 58 141 513 minecraft:polished_blackstone_bricks
fill 58 140 515 58 141 515 minecraft:polished_blackstone_bricks
fill 58 140 517 58 141 517 minecraft:polished_blackstone_bricks
fill 58 140 519 58 141 519 minecraft:polished_blackstone_bricks
fill 59 140 512 59 141 512 minecraft:polished_blackstone_bricks
fill 59 140 514 59 141 514 minecraft:polished_blackstone_bricks
fill 59 140 516 59 141 516 minecraft:polished_blackstone_bricks
fill 59 140 518 59 141 518 minecraft:polished_blackstone_bricks
fill 59 140 520 59 141 520 minecraft:polished_blackstone_bricks
fill 60 140 511 60 141 511 minecraft:polished_blackstone_bricks
fill 60 140 513 60 141 513 minecraft:polished_blackstone_bricks
fill 60 140 515 60 141 515 minecraft:polished_blackstone_bricks
fill 60 140 517 60 141 517 minecraft:polished_blackstone_bricks
fill 60 140 519 60 141 519 minecraft:polished_blackstone_bricks
fill 61 140 512 61 141 512 minecraft:polished_blackstone_bricks
fill 61 140 514 61 141 514 minecraft:polished_blackstone_bricks
fill 61 140 516 61 141 516 minecraft:polished_blackstone_bricks
fill 61 140 518 61 141 518 minecraft:polished_blackstone_bricks
fill 61 140 520 61 141 520 minecraft:polished_blackstone_bricks
fill 62 140 511 62 141 511 minecraft:polished_blackstone_bricks
fill 62 140 513 62 141 513 minecraft:polished_blackstone_bricks
fill 62 140 515 62 141 515 minecraft:polished_blackstone_bricks
fill 62 140 517 62 141 517 minecraft:polished_blackstone_bricks
fill 62 140 519 62 141 519 minecraft:polished_blackstone_bricks
fill 67 140 550 69 145 550 minecraft:polished_blackstone_bricks
fill 71 140 512 73 145 512 minecraft:polished_blackstone_bricks
fill 79 140 550 81 145 550 minecraft:polished_blackstone_bricks
fill 80 140 517 86 140 521 minecraft:purple_stained_glass
fill 83 140 512 85 145 512 minecraft:polished_blackstone_bricks
fill 87 140 520 87 145 522 minecraft:polished_blackstone_bricks
fill 87 140 532 87 145 534 minecraft:polished_blackstone_bricks
fill 87 140 544 87 145 546 minecraft:polished_blackstone_bricks
fill 81 141 518 85 141 520 minecraft:purple_stained_glass
setblock 54 142 511 minecraft:crying_obsidian
setblock 54 142 513 minecraft:crying_obsidian
setblock 54 142 515 minecraft:crying_obsidian
setblock 54 142 517 minecraft:crying_obsidian
setblock 54 142 519 minecraft:crying_obsidian
setblock 55 142 512 minecraft:crying_obsidian
setblock 55 142 514 minecraft:crying_obsidian
setblock 55 142 516 minecraft:crying_obsidian
setblock 55 142 518 minecraft:crying_obsidian
setblock 55 142 520 minecraft:crying_obsidian
setblock 56 142 511 minecraft:crying_obsidian
setblock 56 142 513 minecraft:crying_obsidian
setblock 56 142 515 minecraft:crying_obsidian
setblock 56 142 517 minecraft:crying_obsidian
setblock 56 142 519 minecraft:crying_obsidian
setblock 57 142 512 minecraft:crying_obsidian
setblock 57 142 514 minecraft:crying_obsidian
setblock 57 142 516 minecraft:crying_obsidian
setblock 57 142 518 minecraft:crying_obsidian
setblock 57 142 520 minecraft:crying_obsidian
setblock 58 142 511 minecraft:crying_obsidian
setblock 58 142 513 minecraft:crying_obsidian
setblock 58 142 515 minecraft:crying_obsidian
setblock 58 142 517 minecraft:crying_obsidian
setblock 58 142 519 minecraft:crying_obsidian
setblock 59 142 512 minecraft:crying_obsidian
setblock 59 142 514 minecraft:crying_obsidian
setblock 59 142 516 minecraft:crying_obsidian
setblock 59 142 518 minecraft:crying_obsidian
setblock 59 142 520 minecraft:crying_obsidian
setblock 60 142 511 minecraft:crying_obsidian
setblock 60 142 513 minecraft:crying_obsidian
setblock 60 142 515 minecraft:crying_obsidian
setblock 60 142 517 minecraft:crying_obsidian
setblock 60 142 519 minecraft:crying_obsidian
setblock 61 142 512 minecraft:crying_obsidian
setblock 61 142 514 minecraft:crying_obsidian
setblock 61 142 516 minecraft:crying_obsidian
setblock 61 142 518 minecraft:crying_obsidian
setblock 61 142 520 minecraft:crying_obsidian
setblock 62 142 511 minecraft:crying_obsidian
setblock 62 142 513 minecraft:crying_obsidian
setblock 62 142 515 minecraft:crying_obsidian
setblock 62 142 517 minecraft:crying_obsidian
setblock 62 142 519 minecraft:crying_obsidian
fill 82 142 519 84 142 519 minecraft:purple_stained_glass
fill 54 143 511 54 144 511 minecraft:polished_blackstone_bricks
fill 54 143 513 54 144 513 minecraft:polished_blackstone_bricks
fill 54 143 515 54 144 515 minecraft:polished_blackstone_bricks
fill 54 143 517 54 144 517 minecraft:polished_blackstone_bricks
fill 54 143 519 54 144 519 minecraft:polished_blackstone_bricks
fill 55 143 512 55 144 512 minecraft:polished_blackstone_bricks
fill 55 143 514 55 144 514 minecraft:polished_blackstone_bricks
fill 55 143 516 55 144 516 minecraft:polished_blackstone_bricks
fill 55 143 518 55 144 518 minecraft:polished_blackstone_bricks
fill 55 143 520 55 144 520 minecraft:polished_blackstone_bricks
fill 56 143 511 56 144 511 minecraft:polished_blackstone_bricks
fill 56 143 513 56 144 513 minecraft:polished_blackstone_bricks
fill 56 143 515 56 144 515 minecraft:polished_blackstone_bricks
fill 56 143 517 56 144 517 minecraft:polished_blackstone_bricks
fill 56 143 519 56 144 519 minecraft:polished_blackstone_bricks
fill 57 143 512 57 144 512 minecraft:polished_blackstone_bricks
fill 57 143 514 57 144 514 minecraft:polished_blackstone_bricks
fill 57 143 516 57 144 516 minecraft:polished_blackstone_bricks
fill 57 143 518 57 144 518 minecraft:polished_blackstone_bricks
fill 57 143 520 57 144 520 minecraft:polished_blackstone_bricks
fill 58 143 511 58 144 511 minecraft:polished_blackstone_bricks
fill 58 143 513 58 144 513 minecraft:polished_blackstone_bricks
fill 58 143 515 58 144 515 minecraft:polished_blackstone_bricks
fill 58 143 517 58 144 517 minecraft:polished_blackstone_bricks
fill 58 143 519 58 144 519 minecraft:polished_blackstone_bricks
fill 59 143 512 59 144 512 minecraft:polished_blackstone_bricks
fill 59 143 514 59 144 514 minecraft:polished_blackstone_bricks
fill 59 143 516 59 144 516 minecraft:polished_blackstone_bricks
fill 59 143 518 59 144 518 minecraft:polished_blackstone_bricks
fill 59 143 520 59 144 520 minecraft:polished_blackstone_bricks
fill 60 143 511 60 144 511 minecraft:polished_blackstone_bricks
fill 60 143 513 60 144 513 minecraft:polished_blackstone_bricks
fill 60 143 515 60 144 515 minecraft:polished_blackstone_bricks
fill 60 143 517 60 144 517 minecraft:polished_blackstone_bricks
fill 60 143 519 60 144 519 minecraft:polished_blackstone_bricks
fill 61 143 512 61 144 512 minecraft:polished_blackstone_bricks
fill 61 143 514 61 144 514 minecraft:polished_blackstone_bricks
fill 61 143 516 61 144 516 minecraft:polished_blackstone_bricks
fill 61 143 518 61 144 518 minecraft:polished_blackstone_bricks
fill 61 143 520 61 144 520 minecraft:polished_blackstone_bricks
fill 62 143 511 62 144 511 minecraft:polished_blackstone_bricks
fill 62 143 513 62 144 513 minecraft:polished_blackstone_bricks
fill 62 143 515 62 144 515 minecraft:polished_blackstone_bricks
fill 62 143 517 62 144 517 minecraft:polished_blackstone_bricks
fill 62 143 519 62 144 519 minecraft:polished_blackstone_bricks
fill 48 145 514 48 145 519 minecraft:blackstone
fill 48 145 526 48 145 531 minecraft:blackstone
fill 48 145 538 48 145 543 minecraft:blackstone
fill 48 145 550 48 145 551 minecraft:blackstone
fill 49 145 551 52 145 551 minecraft:blackstone
fill 52 145 511 53 145 511 minecraft:blackstone
setblock 54 145 511 minecraft:crying_obsidian
setblock 54 145 513 minecraft:crying_obsidian
setblock 54 145 515 minecraft:crying_obsidian
setblock 54 145 517 minecraft:crying_obsidian
setblock 54 145 519 minecraft:crying_obsidian
setblock 55 145 511 minecraft:blackstone
setblock 55 145 512 minecraft:crying_obsidian
setblock 55 145 514 minecraft:crying_obsidian
setblock 55 145 516 minecraft:crying_obsidian
setblock 55 145 518 minecraft:crying_obsidian
setblock 55 145 520 minecraft:crying_obsidian
setblock 56 145 511 minecraft:crying_obsidian
setblock 56 145 513 minecraft:crying_obsidian
setblock 56 145 515 minecraft:crying_obsidian
setblock 56 145 517 minecraft:crying_obsidian
setblock 56 145 519 minecraft:crying_obsidian
setblock 57 145 511 minecraft:blackstone
setblock 57 145 512 minecraft:crying_obsidian
setblock 57 145 514 minecraft:crying_obsidian
setblock 57 145 516 minecraft:crying_obsidian
setblock 57 145 518 minecraft:crying_obsidian
setblock 57 145 520 minecraft:crying_obsidian
setblock 58 145 511 minecraft:crying_obsidian
setblock 58 145 513 minecraft:crying_obsidian
setblock 58 145 515 minecraft:crying_obsidian
setblock 58 145 517 minecraft:crying_obsidian
setblock 58 145 519 minecraft:crying_obsidian
setblock 59 145 512 minecraft:crying_obsidian
setblock 59 145 514 minecraft:crying_obsidian
setblock 59 145 516 minecraft:crying_obsidian
setblock 59 145 518 minecraft:crying_obsidian
setblock 59 145 520 minecraft:crying_obsidian
fill 59 145 551 64 145 551 minecraft:blackstone
setblock 60 145 511 minecraft:crying_obsidian
setblock 60 145 513 minecraft:crying_obsidian
setblock 60 145 515 minecraft:crying_obsidian
setblock 60 145 517 minecraft:crying_obsidian
setblock 60 145 519 minecraft:crying_obsidian
setblock 61 145 512 minecraft:crying_obsidian
setblock 61 145 514 minecraft:crying_obsidian
setblock 61 145 516 minecraft:crying_obsidian
setblock 61 145 518 minecraft:crying_obsidian
setblock 61 145 520 minecraft:crying_obsidian
setblock 62 145 511 minecraft:crying_obsidian
setblock 62 145 513 minecraft:crying_obsidian
setblock 62 145 515 minecraft:crying_obsidian
setblock 62 145 517 minecraft:crying_obsidian
setblock 62 145 519 minecraft:crying_obsidian
fill 64 145 511 69 145 511 minecraft:blackstone
fill 71 145 551 76 145 551 minecraft:blackstone
fill 76 145 511 81 145 511 minecraft:blackstone
fill 83 145 551 88 145 551 minecraft:blackstone
fill 87 145 541 87 146 543 minecraft:polished_blackstone_bricks
fill 88 145 511 88 145 516 minecraft:blackstone
fill 88 145 523 88 145 528 minecraft:blackstone
fill 88 145 535 88 145 540 minecraft:blackstone
fill 88 145 541 88 146 542 minecraft:polished_blackstone_bricks
fill 88 145 547 88 145 550 minecraft:blackstone
fill 47 146 516 47 151 519 minecraft:crying_obsidian
fill 47 146 528 47 151 531 minecraft:crying_obsidian
fill 47 146 540 47 151 543 minecraft:crying_obsidian
fill 47 146 552 50 151 552 minecraft:crying_obsidian
fill 48 146 541 49 146 543 minecraft:polished_blackstone_bricks
fill 50 146 542 50 148 542 minecraft:polished_blackstone_bricks
fill 54 146 510 57 151 510 minecraft:crying_obsidian
fill 54 146 511 58 146 511 minecraft:polished_blackstone_bricks
setblock 54 146 513 minecraft:polished_blackstone_bricks
setblock 54 146 515 minecraft:polished_blackstone_bricks
setblock 54 146 517 minecraft:polished_blackstone_bricks
setblock 54 146 519 minecraft:polished_blackstone_bricks
setblock 55 146 512 minecraft:polished_blackstone_bricks
setblock 55 146 514 minecraft:polished_blackstone_bricks
setblock 55 146 516 minecraft:polished_blackstone_bricks
setblock 55 146 518 minecraft:polished_blackstone_bricks
setblock 55 146 520 minecraft:polished_blackstone_bricks
setblock 56 146 513 minecraft:polished_blackstone_bricks
setblock 56 146 515 minecraft:polished_blackstone_bricks
setblock 56 146 517 minecraft:polished_blackstone_bricks
setblock 56 146 519 minecraft:polished_blackstone_bricks
setblock 57 146 512 minecraft:polished_blackstone_bricks
setblock 57 146 514 minecraft:polished_blackstone_bricks
setblock 57 146 516 minecraft:polished_blackstone_bricks
setblock 57 146 518 minecraft:polished_blackstone_bricks
setblock 57 146 520 minecraft:polished_blackstone_bricks
setblock 58 146 513 minecraft:polished_blackstone_bricks
setblock 58 146 515 minecraft:polished_blackstone_bricks
setblock 58 146 517 minecraft:polished_blackstone_bricks
setblock 58 146 519 minecraft:polished_blackstone_bricks
setblock 59 146 512 minecraft:polished_blackstone_bricks
setblock 59 146 514 minecraft:polished_blackstone_bricks
setblock 59 146 516 minecraft:polished_blackstone_bricks
setblock 59 146 518 minecraft:polished_blackstone_bricks
setblock 59 146 520 minecraft:polished_blackstone_bricks
fill 59 146 552 62 151 552 minecraft:crying_obsidian
fill 60 146 511 60 172 511 minecraft:polished_blackstone_bricks
setblock 60 146 513 minecraft:polished_blackstone_bricks
setblock 60 146 515 minecraft:polished_blackstone_bricks
setblock 60 146 517 minecraft:polished_blackstone_bricks
setblock 60 146 519 minecraft:polished_blackstone_bricks
setblock 61 146 512 minecraft:polished_blackstone_bricks
setblock 61 146 514 minecraft:polished_blackstone_bricks
setblock 61 146 516 minecraft:polished_blackstone_bricks
setblock 61 146 518 minecraft:polished_blackstone_bricks
setblock 61 146 520 minecraft:polished_blackstone_bricks
fill 62 146 511 62 172 511 minecraft:polished_blackstone_bricks
setblock 62 146 513 minecraft:polished_blackstone_bricks
setblock 62 146 515 minecraft:polished_blackstone_bricks
setblock 62 146 517 minecraft:polished_blackstone_bricks
setblock 62 146 519 minecraft:polished_blackstone_bricks
fill 66 146 510 69 151 510 minecraft:crying_obsidian
fill 71 146 552 74 151 552 minecraft:crying_obsidian
fill 78 146 510 81 151 510 minecraft:crying_obsidian
fill 83 146 552 86 151 552 minecraft:crying_obsidian
fill 85 146 542 86 148 542 minecraft:polished_blackstone_bricks
fill 86 146 541 86 147 541 minecraft:polished_blackstone_bricks
fill 86 146 543 86 147 543 minecraft:polished_blackstone_bricks
fill 89 146 511 89 151 514 minecraft:crying_obsidian
fill 89 146 523 89 151 526 minecraft:crying_obsidian
fill 89 146 535 89 151 538 minecraft:crying_obsidian
fill 89 146 547 89 151 550 minecraft:crying_obsidian
fill 48 147 542 49 147 542 minecraft:polished_blackstone_bricks
fill 49 147 541 50 147 541 minecraft:polished_blackstone_bricks
fill 49 147 543 50 147 543 minecraft:polished_blackstone_bricks
setblock 50 147 513 minecraft:light[level=11]
setblock 50 147 521 minecraft:light[level=11]
setblock 50 147 529 minecraft:light[level=11]
setblock 50 147 537 minecraft:light[level=11]
setblock 50 147 545 minecraft:light[level=11]
fill 51 147 542 51 149 542 minecraft:polished_blackstone_bricks
fill 55 147 512 61 147 519 minecraft:purple_stained_glass
setblock 58 147 521 minecraft:light[level=11]
setblock 58 147 529 minecraft:light[level=11]
setblock 58 147 537 minecraft:light[level=11]
setblock 58 147 545 minecraft:light[level=11]
setblock 66 147 513 minecraft:light[level=11]
setblock 66 147 521 minecraft:light[level=11]
setblock 66 147 537 minecraft:light[level=11]
setblock 66 147 545 minecraft:light[level=11]
setblock 74 147 513 minecraft:light[level=11]
setblock 74 147 521 minecraft:light[level=11]
setblock 74 147 529 minecraft:light[level=11]
setblock 74 147 537 minecraft:light[level=11]
setblock 74 147 545 minecraft:light[level=11]
setblock 82 147 513 minecraft:light[level=11]
setblock 82 147 521 minecraft:light[level=11]
setblock 82 147 529 minecraft:light[level=11]
setblock 82 147 537 minecraft:light[level=11]
setblock 82 147 545 minecraft:light[level=11]
fill 84 147 542 84 149 542 minecraft:polished_blackstone_bricks
fill 85 147 541 85 148 541 minecraft:polished_blackstone_bricks
fill 85 147 543 85 148 543 minecraft:polished_blackstone_bricks
setblock 87 147 542 minecraft:polished_blackstone_bricks
setblock 88 147 542 minecraft:purple_stained_glass
setblock 48 148 542 minecraft:purple_stained_glass
setblock 49 148 542 minecraft:polished_blackstone_bricks
fill 50 148 541 52 148 541 minecraft:polished_blackstone_bricks
fill 50 148 543 52 148 543 minecraft:polished_blackstone_bricks
fill 52 148 542 52 150 542 minecraft:polished_blackstone_bricks
fill 56 148 513 60 148 518 minecraft:purple_stained_glass
fill 83 148 541 83 149 543 minecraft:polished_blackstone_bricks
fill 84 148 541 84 149 541 minecraft:polished_blackstone_bricks
fill 84 148 543 84 149 543 minecraft:polished_blackstone_bricks
setblock 87 148 542 minecraft:purple_stained_glass
setblock 50 149 542 minecraft:purple_stained_glass
fill 51 149 541 53 149 541 minecraft:polished_blackstone_bricks
fill 51 149 543 53 149 543 minecraft:polished_blackstone_bricks
fill 53 149 542 54 151 542 minecraft:polished_blackstone_bricks
fill 57 149 514 59 149 517 minecraft:purple_stained_glass
fill 81 149 542 82 151 542 minecraft:polished_blackstone_bricks
fill 82 149 541 82 150 541 minecraft:polished_blackstone_bricks
fill 82 149 543 82 150 543 minecraft:polished_blackstone_bricks
setblock 85 149 542 minecraft:purple_stained_glass
setblock 51 150 542 minecraft:purple_stained_glass
fill 53 150 541 54 150 541 minecraft:polished_blackstone_bricks
fill 53 150 543 54 150 543 minecraft:polished_blackstone_bricks
fill 55 150 542 55 152 542 minecraft:polished_blackstone_bricks
fill 58 150 515 58 150 516 minecraft:purple_stained_glass
fill 80 150 542 80 152 542 minecraft:polished_blackstone_bricks
fill 81 150 541 81 151 541 minecraft:polished_blackstone_bricks
fill 81 150 543 81 151 543 minecraft:polished_blackstone_bricks
setblock 83 150 542 minecraft:polished_blackstone_bricks
setblock 84 150 542 minecraft:purple_stained_glass
setblock 52 151 542 minecraft:purple_stained_glass
fill 54 151 541 56 151 541 minecraft:polished_blackstone_bricks
fill 54 151 543 56 151 543 minecraft:polished_blackstone_bricks
fill 56 151 542 57 152 542 minecraft:polished_blackstone_bricks
fill 78 151 542 79 152 542 minecraft:polished_blackstone_bricks
fill 79 151 541 80 151 541 minecraft:polished_blackstone_bricks
fill 79 151 543 80 151 543 minecraft:polished_blackstone_bricks
setblock 83 151 542 minecraft:purple_stained_glass
fill 47 152 516 47 165 516 minecraft:polished_blackstone_bricks
fill 47 152 517 47 152 518 minecraft:crying_obsidian
fill 47 152 519 47 165 519 minecraft:polished_blackstone_bricks
fill 47 152 528 47 165 528 minecraft:polished_blackstone_bricks
fill 47 152 529 47 152 530 minecraft:crying_obsidian
fill 47 152 531 47 165 531 minecraft:polished_blackstone_bricks
fill 47 152 540 47 165 540 minecraft:polished_blackstone_bricks
fill 47 152 541 47 152 542 minecraft:crying_obsidian
fill 47 152 543 47 165 543 minecraft:polished_blackstone_bricks
fill 47 152 552 47 165 552 minecraft:polished_blackstone_bricks
fill 48 152 552 49 152 552 minecraft:crying_obsidian
fill 50 152 552 50 165 552 minecraft:polished_blackstone_bricks
fill 54 152 510 54 165 510 minecraft:polished_blackstone_bricks
setblock 54 152 542 minecraft:purple_stained_glass
fill 55 152 510 56 152 510 minecraft:crying_obsidian
fill 56 152 541 58 152 541 minecraft:polished_blackstone_bricks
fill 56 152 543 58 152 543 minecraft:polished_blackstone_bricks
fill 57 152 510 57 165 510 minecraft:polished_blackstone_bricks
fill 58 152 542 59 154 542 minecraft:polished_blackstone_bricks
fill 59 152 552 59 165 552 minecraft:polished_blackstone_bricks
fill 60 152 552 61 152 552 minecraft:crying_obsidian
fill 62 152 552 62 165 552 minecraft:polished_blackstone_bricks
fill 66 152 510 66 165 510 minecraft:polished_blackstone_bricks
fill 67 152 510 68 152 510 minecraft:crying_obsidian
fill 69 152 510 69 165 510 minecraft:polished_blackstone_bricks
fill 71 152 552 71 165 552 minecraft:polished_blackstone_bricks
fill 72 152 552 73 152 552 minecraft:crying_obsidian
fill 74 152 552 74 165 552 minecraft:polished_blackstone_bricks
fill 76 152 542 77 154 542 minecraft:polished_blackstone_bricks
fill 77 152 541 79 152 541 minecraft:polished_blackstone_bricks
fill 77 152 543 79 152 543 minecraft:polished_blackstone_bricks
fill 78 152 510 78 165 510 minecraft:polished_blackstone_bricks
fill 79 152 510 80 152 510 minecraft:crying_obsidian
fill 81 152 510 81 165 510 minecraft:polished_blackstone_bricks
setblock 81 152 542 minecraft:purple_stained_glass
fill 83 152 552 83 165 552 minecraft:polished_blackstone_bricks
fill 84 152 552 85 152 552 minecraft:crying_obsidian
fill 86 152 552 86 165 552 minecraft:polished_blackstone_bricks
fill 89 152 511 89 165 511 minecraft:polished_blackstone_bricks
fill 89 152 512 89 152 513 minecraft:crying_obsidian
fill 89 152 514 89 165 514 minecraft:polished_blackstone_bricks
fill 89 152 523 89 165 523 minecraft:polished_blackstone_bricks
fill 89 152 524 89 152 525 minecraft:crying_obsidian
fill 89 152 526 89 165 526 minecraft:polished_blackstone_bricks
fill 89 152 535 89 165 535 minecraft:polished_blackstone_bricks
fill 89 152 536 89 152 537 minecraft:crying_obsidian
fill 89 152 538 89 165 538 minecraft:polished_blackstone_bricks
fill 89 152 547 89 165 547 minecraft:polished_blackstone_bricks
fill 89 152 548 89 152 549 minecraft:crying_obsidian
fill 89 152 550 89 165 550 minecraft:polished_blackstone_bricks
fill 47 153 517 47 165 518 minecraft:polished_blackstone_bricks
fill 47 153 529 47 165 530 minecraft:polished_blackstone_bricks
fill 47 153 541 47 165 542 minecraft:polished_blackstone_bricks
fill 48 153 552 49 165 552 minecraft:polished_blackstone_bricks
fill 55 153 510 56 165 510 minecraft:polished_blackstone_bricks
fill 55 153 542 56 153 542 minecraft:purple_stained_glass
setblock 57 153 542 minecraft:polished_blackstone_bricks
fill 58 153 541 60 153 541 minecraft:polished_blackstone_bricks
fill 58 153 543 60 153 543 minecraft:polished_blackstone_bricks
fill 60 153 542 61 155 542 minecraft:polished_blackstone_bricks
fill 60 153 552 61 165 552 minecraft:polished_blackstone_bricks
fill 67 153 510 68 165 510 minecraft:polished_blackstone_bricks
fill 72 153 552 73 165 552 minecraft:polished_blackstone_bricks
fill 74 153 542 75 155 542 minecraft:polished_blackstone_bricks
fill 75 153 541 77 153 541 minecraft:polished_blackstone_bricks
fill 75 153 543 77 153 543 minecraft:polished_blackstone_bricks
setblock 78 153 542 minecraft:polished_blackstone_bricks
fill 79 153 510 80 165 510 minecraft:polished_blackstone_bricks
fill 79 153 542 80 153 542 minecraft:purple_stained_glass
fill 84 153 552 85 165 552 minecraft:polished_blackstone_bricks
fill 89 153 512 89 165 513 minecraft:polished_blackstone_bricks
fill 89 153 524 89 165 525 minecraft:polished_blackstone_bricks
fill 89 153 536 89 165 537 minecraft:polished_blackstone_bricks
fill 89 153 548 89 165 549 minecraft:polished_blackstone_bricks
setblock 57 154 542 minecraft:purple_stained_glass
fill 59 154 541 63 154 541 minecraft:polished_blackstone_bricks
fill 59 154 543 63 154 543 minecraft:polished_blackstone_bricks
fill 62 154 542 66 155 542 minecraft:polished_blackstone_bricks
fill 69 154 542 73 155 542 minecraft:polished_blackstone_bricks
fill 72 154 541 76 154 541 minecraft:polished_blackstone_bricks
fill 72 154 543 76 154 543 minecraft:polished_blackstone_bricks
setblock 78 154 542 minecraft:purple_stained_glass
setblock 50 155 513 minecraft:light[level=11]
setblock 50 155 521 minecraft:light[level=11]
setblock 50 155 529 minecraft:light[level=11]
setblock 50 155 537 minecraft:light[level=11]
setblock 50 155 545 minecraft:light[level=11]
setblock 58 155 513 minecraft:light[level=11]
setblock 58 155 521 minecraft:light[level=11]
setblock 58 155 529 minecraft:light[level=11]
setblock 58 155 537 minecraft:light[level=11]
setblock 58 155 545 minecraft:light[level=11]
setblock 59 155 542 minecraft:purple_stained_glass
fill 62 155 541 73 155 541 minecraft:polished_blackstone_bricks
fill 62 155 543 73 155 543 minecraft:polished_blackstone_bricks
setblock 66 155 513 minecraft:light[level=11]
setblock 66 155 521 minecraft:light[level=11]
setblock 66 155 529 minecraft:light[level=11]
setblock 66 155 537 minecraft:light[level=11]
setblock 66 155 545 minecraft:light[level=11]
fill 67 155 542 68 156 542 minecraft:polished_blackstone_bricks
setblock 74 155 513 minecraft:light[level=11]
setblock 74 155 521 minecraft:light[level=11]
setblock 74 155 529 minecraft:light[level=11]
setblock 74 155 537 minecraft:light[level=11]
setblock 74 155 545 minecraft:light[level=11]
setblock 76 155 542 minecraft:purple_stained_glass
setblock 82 155 513 minecraft:light[level=11]
setblock 82 155 521 minecraft:light[level=11]
setblock 82 155 529 minecraft:light[level=11]
setblock 82 155 537 minecraft:light[level=11]
setblock 82 155 545 minecraft:light[level=11]
fill 61 156 542 63 156 542 minecraft:purple_stained_glass
fill 64 156 542 66 156 542 minecraft:polished_blackstone_bricks
fill 67 156 541 68 156 541 minecraft:polished_blackstone_bricks
fill 67 156 543 68 156 543 minecraft:polished_blackstone_bricks
fill 69 156 542 71 156 542 minecraft:polished_blackstone_bricks
fill 72 156 542 74 156 542 minecraft:purple_stained_glass
fill 64 157 542 71 157 542 minecraft:purple_stained_glass
fill 67 157 544 71 158 548 minecraft:blackstone
fill 69 157 549 69 157 550 minecraft:blackstone
fill 68 159 546 70 166 546 minecraft:purple_stained_glass
fill 69 159 545 69 166 545 minecraft:purple_stained_glass
fill 69 159 547 69 166 547 minecraft:purple_stained_glass
fill 49 160 520 49 165 522 minecraft:polished_blackstone_bricks
fill 49 160 532 49 165 534 minecraft:polished_blackstone_bricks
fill 49 160 544 49 165 546 minecraft:polished_blackstone_bricks
fill 55 160 550 57 165 550 minecraft:polished_blackstone_bricks
fill 59 160 512 61 165 512 minecraft:polished_blackstone_bricks
fill 67 160 550 69 165 550 minecraft:polished_blackstone_bricks
fill 71 160 512 73 165 512 minecraft:polished_blackstone_bricks
fill 79 160 550 81 165 550 minecraft:polished_blackstone_bricks
fill 83 160 512 85 165 512 minecraft:polished_blackstone_bricks
fill 87 160 520 87 165 522 minecraft:polished_blackstone_bricks
fill 87 160 532 87 165 534 minecraft:polished_blackstone_bricks
schedule function dropper:buildpart/121_2 1t
