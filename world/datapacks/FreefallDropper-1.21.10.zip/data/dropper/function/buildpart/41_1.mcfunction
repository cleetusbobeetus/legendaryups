fill 258 103 181 261 103 181 minecraft:ochre_froglight
fill 259 103 223 262 103 223 minecraft:ochre_froglight
fill 268 103 181 271 103 181 minecraft:ochre_froglight
fill 269 103 223 272 103 223 minecraft:ochre_froglight
fill 277 103 182 277 103 185 minecraft:ochre_froglight
fill 277 103 192 277 103 195 minecraft:ochre_froglight
fill 277 103 202 277 103 205 minecraft:ochre_froglight
fill 277 103 212 277 103 215 minecraft:ochre_froglight
setblock 277 103 222 minecraft:ochre_froglight
fill 235 104 187 235 111 190 minecraft:andesite
fill 235 104 197 235 111 200 minecraft:andesite
fill 235 104 207 235 111 210 minecraft:andesite
fill 235 104 217 235 111 220 minecraft:andesite
fill 238 104 181 241 111 181 minecraft:andesite
fill 239 104 223 242 111 223 minecraft:andesite
fill 248 104 181 251 111 181 minecraft:andesite
fill 249 104 223 252 111 223 minecraft:andesite
fill 258 104 181 261 111 181 minecraft:andesite
fill 259 104 223 262 111 223 minecraft:andesite
fill 268 104 181 271 111 181 minecraft:andesite
fill 269 104 223 272 111 223 minecraft:andesite
fill 277 104 182 277 111 185 minecraft:andesite
fill 277 104 192 277 111 195 minecraft:andesite
fill 277 104 202 277 111 205 minecraft:andesite
fill 277 104 212 277 111 215 minecraft:andesite
fill 277 104 222 277 111 222 minecraft:andesite
setblock 238 106 186 minecraft:smooth_stone
setblock 238 106 188 minecraft:smooth_stone
setblock 240 106 186 minecraft:smooth_stone
setblock 240 106 188 minecraft:smooth_stone
setblock 236 107 192 minecraft:smooth_stone
fill 236 107 194 236 108 194 minecraft:smooth_stone
fill 237 107 191 239 107 191 minecraft:smooth_stone
fill 237 107 195 239 107 195 minecraft:smooth_stone
setblock 238 107 184 minecraft:light[level=13]
setblock 238 107 200 minecraft:light[level=13]
setblock 238 107 208 minecraft:light[level=13]
setblock 238 107 216 minecraft:light[level=13]
fill 240 107 192 240 107 194 minecraft:smooth_stone
setblock 246 107 184 minecraft:light[level=13]
setblock 246 107 192 minecraft:light[level=13]
setblock 246 107 200 minecraft:light[level=13]
setblock 246 107 208 minecraft:light[level=13]
setblock 246 107 216 minecraft:light[level=13]
setblock 254 107 184 minecraft:light[level=13]
setblock 254 107 192 minecraft:light[level=13]
setblock 254 107 200 minecraft:light[level=13]
setblock 254 107 208 minecraft:light[level=13]
setblock 254 107 216 minecraft:light[level=13]
setblock 257 107 184 minecraft:smooth_stone
setblock 257 107 186 minecraft:smooth_stone
setblock 259 107 184 minecraft:smooth_stone
setblock 259 107 186 minecraft:smooth_stone
setblock 262 107 184 minecraft:light[level=13]
setblock 262 107 192 minecraft:light[level=13]
setblock 262 107 200 minecraft:light[level=13]
setblock 262 107 208 minecraft:light[level=13]
setblock 262 107 216 minecraft:light[level=13]
setblock 270 107 184 minecraft:light[level=13]
setblock 270 107 192 minecraft:light[level=13]
setblock 270 107 200 minecraft:light[level=13]
setblock 270 107 208 minecraft:light[level=13]
setblock 270 107 216 minecraft:light[level=13]
setblock 236 108 184 minecraft:smooth_stone
fill 236 108 186 236 108 189 minecraft:smooth_stone
fill 236 108 196 236 108 199 minecraft:smooth_stone
setblock 236 108 204 minecraft:smooth_stone
fill 236 108 206 236 108 209 minecraft:smooth_stone
setblock 236 108 214 minecraft:smooth_stone
fill 236 108 216 236 108 219 minecraft:smooth_stone
fill 237 108 182 240 108 182 minecraft:smooth_stone
setblock 238 108 222 minecraft:smooth_stone
fill 240 108 222 243 108 222 minecraft:smooth_stone
setblock 242 108 182 minecraft:smooth_stone
setblock 244 108 217 minecraft:smooth_stone
setblock 244 108 219 minecraft:smooth_stone
setblock 246 108 217 minecraft:smooth_stone
setblock 246 108 219 minecraft:smooth_stone
fill 247 108 182 250 108 182 minecraft:smooth_stone
setblock 248 108 222 minecraft:smooth_stone
fill 250 108 222 253 108 222 minecraft:smooth_stone
setblock 252 108 182 minecraft:smooth_stone
fill 257 108 182 260 108 182 minecraft:smooth_stone
setblock 258 108 222 minecraft:smooth_stone
fill 260 108 222 263 108 222 minecraft:smooth_stone
setblock 262 108 182 minecraft:smooth_stone
fill 267 108 182 270 108 182 minecraft:smooth_stone
setblock 268 108 222 minecraft:smooth_stone
fill 270 108 222 273 108 222 minecraft:smooth_stone
setblock 272 108 182 minecraft:smooth_stone
fill 276 108 183 276 108 186 minecraft:smooth_stone
setblock 276 108 188 minecraft:smooth_stone
fill 276 108 193 276 108 196 minecraft:smooth_stone
setblock 276 108 198 minecraft:smooth_stone
fill 276 108 203 276 108 206 minecraft:smooth_stone
setblock 276 108 208 minecraft:smooth_stone
fill 276 108 213 276 108 216 minecraft:smooth_stone
setblock 276 108 218 minecraft:smooth_stone
fill 245 109 220 245 110 221 minecraft:iron_block
setblock 245 110 216 minecraft:ochre_froglight
fill 235 112 187 235 112 190 minecraft:ochre_froglight
fill 235 112 197 235 112 200 minecraft:ochre_froglight
fill 235 112 207 235 112 210 minecraft:ochre_froglight
fill 235 112 217 235 112 220 minecraft:ochre_froglight
fill 236 112 212 238 113 212 minecraft:iron_block
fill 238 112 181 241 112 181 minecraft:ochre_froglight
setblock 238 112 186 minecraft:smooth_stone
setblock 238 112 188 minecraft:smooth_stone
fill 239 112 223 242 112 223 minecraft:ochre_froglight
setblock 240 112 186 minecraft:smooth_stone
setblock 240 112 188 minecraft:smooth_stone
fill 248 112 181 251 112 181 minecraft:ochre_froglight
fill 249 112 223 252 112 223 minecraft:ochre_froglight
fill 258 112 181 261 112 181 minecraft:ochre_froglight
fill 259 112 223 262 112 223 minecraft:ochre_froglight
fill 268 112 181 271 112 181 minecraft:ochre_froglight
fill 269 112 223 272 112 223 minecraft:ochre_froglight
fill 277 112 182 277 112 185 minecraft:ochre_froglight
fill 277 112 192 277 112 195 minecraft:ochre_froglight
fill 277 112 202 277 112 205 minecraft:ochre_froglight
fill 277 112 212 277 112 215 minecraft:ochre_froglight
setblock 277 112 222 minecraft:ochre_froglight
fill 235 113 187 235 120 190 minecraft:andesite
fill 235 113 197 235 120 200 minecraft:andesite
fill 235 113 207 235 120 210 minecraft:andesite
fill 235 113 217 235 120 220 minecraft:andesite
fill 238 113 181 241 120 181 minecraft:andesite
fill 239 113 223 242 120 223 minecraft:andesite
setblock 244 113 217 minecraft:smooth_stone
setblock 244 113 219 minecraft:smooth_stone
setblock 246 113 217 minecraft:smooth_stone
setblock 246 113 219 minecraft:smooth_stone
fill 248 113 181 251 120 181 minecraft:andesite
fill 249 113 223 252 120 223 minecraft:andesite
fill 258 113 181 261 120 181 minecraft:andesite
fill 259 113 223 262 120 223 minecraft:andesite
fill 268 113 181 271 120 181 minecraft:andesite
fill 269 113 223 272 120 223 minecraft:andesite
fill 277 113 182 277 120 185 minecraft:andesite
fill 277 113 192 277 120 195 minecraft:andesite
fill 277 113 202 277 120 205 minecraft:andesite
fill 277 113 212 277 120 215 minecraft:andesite
fill 277 113 222 277 120 222 minecraft:andesite
setblock 236 114 184 minecraft:smooth_stone
setblock 236 114 192 minecraft:smooth_stone
setblock 236 114 194 minecraft:smooth_stone
setblock 236 114 204 minecraft:smooth_stone
setblock 236 114 214 minecraft:smooth_stone
fill 237 114 191 239 114 191 minecraft:smooth_stone
fill 237 114 195 239 114 195 minecraft:smooth_stone
setblock 238 114 222 minecraft:smooth_stone
fill 240 114 192 240 114 194 minecraft:smooth_stone
setblock 242 114 182 minecraft:smooth_stone
setblock 248 114 222 minecraft:smooth_stone
setblock 252 114 182 minecraft:smooth_stone
setblock 257 114 184 minecraft:smooth_stone
setblock 257 114 186 minecraft:smooth_stone
setblock 258 114 222 minecraft:smooth_stone
setblock 259 114 184 minecraft:smooth_stone
setblock 259 114 186 minecraft:smooth_stone
setblock 262 114 182 minecraft:smooth_stone
setblock 268 114 222 minecraft:smooth_stone
setblock 272 114 182 minecraft:smooth_stone
setblock 276 114 188 minecraft:smooth_stone
setblock 276 114 198 minecraft:smooth_stone
setblock 276 114 208 minecraft:smooth_stone
setblock 276 114 218 minecraft:smooth_stone
setblock 238 115 184 minecraft:light[level=13]
setblock 238 115 200 minecraft:light[level=13]
setblock 238 115 208 minecraft:light[level=13]
setblock 238 115 216 minecraft:light[level=13]
setblock 246 115 184 minecraft:light[level=13]
setblock 246 115 192 minecraft:light[level=13]
setblock 246 115 200 minecraft:light[level=13]
setblock 246 115 208 minecraft:light[level=13]
setblock 246 115 216 minecraft:light[level=13]
setblock 254 115 184 minecraft:light[level=13]
setblock 254 115 192 minecraft:light[level=13]
setblock 254 115 200 minecraft:light[level=13]
setblock 254 115 208 minecraft:light[level=13]
setblock 254 115 216 minecraft:light[level=13]
setblock 262 115 184 minecraft:light[level=13]
setblock 262 115 192 minecraft:light[level=13]
setblock 262 115 200 minecraft:light[level=13]
setblock 262 115 208 minecraft:light[level=13]
setblock 262 115 216 minecraft:light[level=13]
setblock 270 115 184 minecraft:light[level=13]
setblock 270 115 192 minecraft:light[level=13]
setblock 270 115 200 minecraft:light[level=13]
setblock 270 115 208 minecraft:light[level=13]
setblock 270 115 216 minecraft:light[level=13]
fill 236 117 186 236 117 189 minecraft:smooth_stone
fill 236 117 196 236 117 199 minecraft:smooth_stone
fill 236 117 206 236 117 209 minecraft:smooth_stone
fill 236 117 216 236 117 219 minecraft:smooth_stone
fill 237 117 182 240 117 182 minecraft:smooth_stone
fill 240 117 222 243 117 222 minecraft:smooth_stone
fill 247 117 182 250 117 182 minecraft:smooth_stone
fill 250 117 222 253 117 222 minecraft:smooth_stone
fill 257 117 182 260 117 182 minecraft:smooth_stone
fill 260 117 222 263 117 222 minecraft:smooth_stone
fill 267 117 182 270 117 182 minecraft:smooth_stone
fill 270 117 222 273 117 222 minecraft:smooth_stone
fill 276 117 183 276 117 186 minecraft:smooth_stone
fill 276 117 193 276 117 196 minecraft:smooth_stone
fill 276 117 203 276 117 206 minecraft:smooth_stone
fill 276 117 213 276 117 216 minecraft:smooth_stone
setblock 238 118 186 minecraft:smooth_stone
setblock 238 118 188 minecraft:smooth_stone
setblock 240 118 186 minecraft:smooth_stone
setblock 240 118 188 minecraft:smooth_stone
setblock 244 118 217 minecraft:smooth_stone
setblock 244 118 219 minecraft:smooth_stone
setblock 246 118 217 minecraft:smooth_stone
setblock 246 118 219 minecraft:smooth_stone
setblock 236 120 184 minecraft:smooth_stone
fill 236 120 194 236 121 194 minecraft:smooth_stone
setblock 236 120 204 minecraft:smooth_stone
setblock 236 120 214 minecraft:smooth_stone
setblock 238 120 222 minecraft:smooth_stone
setblock 242 120 182 minecraft:smooth_stone
setblock 248 120 222 minecraft:smooth_stone
setblock 252 120 182 minecraft:smooth_stone
setblock 258 120 222 minecraft:smooth_stone
setblock 262 120 182 minecraft:smooth_stone
setblock 268 120 222 minecraft:smooth_stone
setblock 272 120 182 minecraft:smooth_stone
setblock 276 120 188 minecraft:smooth_stone
setblock 276 120 198 minecraft:smooth_stone
setblock 276 120 208 minecraft:smooth_stone
setblock 276 120 218 minecraft:smooth_stone
fill 235 121 187 235 121 190 minecraft:ochre_froglight
fill 235 121 197 235 121 200 minecraft:ochre_froglight
fill 235 121 207 235 121 210 minecraft:ochre_froglight
fill 235 121 217 235 121 220 minecraft:ochre_froglight
setblock 236 121 192 minecraft:smooth_stone
fill 237 121 191 239 121 191 minecraft:smooth_stone
fill 237 121 195 239 121 195 minecraft:smooth_stone
fill 238 121 181 241 121 181 minecraft:ochre_froglight
fill 239 121 223 242 121 223 minecraft:ochre_froglight
fill 240 121 192 240 121 194 minecraft:smooth_stone
fill 248 121 181 251 121 181 minecraft:ochre_froglight
fill 249 121 223 252 121 223 minecraft:ochre_froglight
setblock 257 121 184 minecraft:smooth_stone
setblock 257 121 186 minecraft:smooth_stone
fill 258 121 181 261 121 181 minecraft:ochre_froglight
setblock 259 121 184 minecraft:smooth_stone
setblock 259 121 186 minecraft:smooth_stone
fill 259 121 223 262 121 223 minecraft:ochre_froglight
fill 268 121 181 271 121 181 minecraft:ochre_froglight
fill 269 121 223 272 121 223 minecraft:ochre_froglight
fill 277 121 182 277 121 185 minecraft:ochre_froglight
fill 277 121 192 277 121 195 minecraft:ochre_froglight
fill 277 121 202 277 121 205 minecraft:ochre_froglight
fill 277 121 212 277 121 215 minecraft:ochre_froglight
setblock 277 121 222 minecraft:ochre_froglight
fill 235 122 187 235 129 190 minecraft:andesite
fill 235 122 197 235 129 200 minecraft:andesite
fill 235 122 207 235 129 210 minecraft:andesite
fill 235 122 217 235 129 220 minecraft:andesite
fill 238 122 181 241 129 181 minecraft:andesite
fill 239 122 223 242 129 223 minecraft:andesite
fill 248 122 181 251 129 181 minecraft:andesite
fill 249 122 223 252 129 223 minecraft:andesite
fill 258 122 181 261 129 181 minecraft:andesite
fill 259 122 223 262 129 223 minecraft:andesite
fill 268 122 181 271 129 181 minecraft:andesite
fill 269 122 223 272 129 223 minecraft:andesite
fill 277 122 182 277 129 185 minecraft:andesite
fill 277 122 192 277 129 195 minecraft:andesite
fill 277 122 202 277 129 205 minecraft:andesite
fill 277 122 212 277 129 215 minecraft:andesite
fill 277 122 222 277 129 222 minecraft:andesite
setblock 238 123 184 minecraft:light[level=13]
setblock 238 123 200 minecraft:light[level=13]
setblock 238 123 208 minecraft:light[level=13]
setblock 238 123 216 minecraft:light[level=13]
setblock 244 123 217 minecraft:smooth_stone
setblock 244 123 219 minecraft:smooth_stone
setblock 246 123 184 minecraft:light[level=13]
setblock 246 123 192 minecraft:light[level=13]
setblock 246 123 200 minecraft:light[level=13]
setblock 246 123 208 minecraft:light[level=13]
setblock 246 123 216 minecraft:light[level=13]
setblock 246 123 217 minecraft:smooth_stone
setblock 246 123 219 minecraft:smooth_stone
setblock 254 123 184 minecraft:light[level=13]
setblock 254 123 192 minecraft:light[level=13]
setblock 254 123 200 minecraft:light[level=13]
setblock 254 123 208 minecraft:light[level=13]
setblock 254 123 216 minecraft:light[level=13]
setblock 262 123 184 minecraft:light[level=13]
setblock 262 123 192 minecraft:light[level=13]
setblock 262 123 200 minecraft:light[level=13]
setblock 262 123 208 minecraft:light[level=13]
setblock 262 123 216 minecraft:light[level=13]
setblock 270 123 184 minecraft:light[level=13]
setblock 270 123 192 minecraft:light[level=13]
setblock 270 123 200 minecraft:light[level=13]
setblock 270 123 208 minecraft:light[level=13]
setblock 270 123 216 minecraft:light[level=13]
setblock 238 124 186 minecraft:smooth_stone
setblock 238 124 188 minecraft:smooth_stone
setblock 240 124 186 minecraft:smooth_stone
setblock 240 124 188 minecraft:smooth_stone
setblock 236 126 184 minecraft:smooth_stone
fill 236 126 186 236 126 189 minecraft:smooth_stone
setblock 236 126 194 minecraft:smooth_stone
fill 236 126 196 236 126 199 minecraft:smooth_stone
setblock 236 126 204 minecraft:smooth_stone
fill 236 126 206 236 126 209 minecraft:smooth_stone
setblock 236 126 214 minecraft:smooth_stone
fill 236 126 216 236 126 219 minecraft:smooth_stone
fill 237 126 182 240 126 182 minecraft:smooth_stone
setblock 238 126 222 minecraft:smooth_stone
fill 240 126 222 243 126 222 minecraft:smooth_stone
setblock 242 126 182 minecraft:smooth_stone
fill 247 126 182 250 126 182 minecraft:smooth_stone
setblock 248 126 222 minecraft:smooth_stone
fill 250 126 222 253 126 222 minecraft:smooth_stone
setblock 252 126 182 minecraft:smooth_stone
fill 257 126 182 260 126 182 minecraft:smooth_stone
setblock 258 126 222 minecraft:smooth_stone
fill 260 126 222 263 126 222 minecraft:smooth_stone
setblock 262 126 182 minecraft:smooth_stone
fill 267 126 182 270 126 182 minecraft:smooth_stone
setblock 268 126 222 minecraft:smooth_stone
fill 270 126 222 273 126 222 minecraft:smooth_stone
setblock 272 126 182 minecraft:smooth_stone
fill 276 126 183 276 126 186 minecraft:smooth_stone
setblock 276 126 188 minecraft:smooth_stone
fill 276 126 193 276 126 196 minecraft:smooth_stone
setblock 276 126 198 minecraft:smooth_stone
fill 276 126 203 276 126 206 minecraft:smooth_stone
setblock 276 126 208 minecraft:smooth_stone
fill 276 126 213 276 126 216 minecraft:smooth_stone
setblock 276 126 218 minecraft:smooth_stone
setblock 236 128 192 minecraft:smooth_stone
setblock 236 128 194 minecraft:smooth_stone
fill 237 128 191 239 128 191 minecraft:smooth_stone
fill 237 128 195 239 128 195 minecraft:smooth_stone
fill 240 128 192 240 128 194 minecraft:smooth_stone
setblock 244 128 217 minecraft:smooth_stone
setblock 244 128 219 minecraft:smooth_stone
setblock 246 128 217 minecraft:smooth_stone
setblock 246 128 219 minecraft:smooth_stone
setblock 257 128 184 minecraft:smooth_stone
setblock 257 128 186 minecraft:smooth_stone
setblock 259 128 184 minecraft:smooth_stone
setblock 259 128 186 minecraft:smooth_stone
fill 235 130 187 235 130 190 minecraft:ochre_froglight
fill 235 130 197 235 130 200 minecraft:ochre_froglight
fill 235 130 207 235 130 210 minecraft:ochre_froglight
fill 235 130 217 235 130 220 minecraft:ochre_froglight
fill 238 130 181 241 130 181 minecraft:ochre_froglight
setblock 238 130 186 minecraft:smooth_stone
setblock 238 130 188 minecraft:smooth_stone
fill 239 130 223 242 130 223 minecraft:ochre_froglight
setblock 240 130 186 minecraft:smooth_stone
setblock 240 130 188 minecraft:smooth_stone
fill 248 130 181 251 130 181 minecraft:ochre_froglight
fill 249 130 223 252 130 223 minecraft:ochre_froglight
fill 258 130 181 261 130 181 minecraft:ochre_froglight
fill 259 130 223 262 130 223 minecraft:ochre_froglight
fill 268 130 181 271 130 181 minecraft:ochre_froglight
fill 269 130 223 272 130 223 minecraft:ochre_froglight
fill 277 130 182 277 130 185 minecraft:ochre_froglight
fill 277 130 192 277 130 195 minecraft:ochre_froglight
fill 277 130 202 277 130 205 minecraft:ochre_froglight
fill 277 130 212 277 130 215 minecraft:ochre_froglight
setblock 277 130 222 minecraft:ochre_froglight
fill 235 131 187 235 147 190 minecraft:andesite
fill 235 131 197 235 147 200 minecraft:andesite
fill 235 131 207 235 147 210 minecraft:andesite
fill 235 131 217 235 147 220 minecraft:andesite
fill 238 131 181 241 147 181 minecraft:andesite
setblock 238 131 184 minecraft:light[level=13]
setblock 238 131 200 minecraft:light[level=13]
setblock 238 131 208 minecraft:light[level=13]
setblock 238 131 216 minecraft:light[level=13]
fill 239 131 223 242 147 223 minecraft:andesite
setblock 246 131 184 minecraft:light[level=13]
setblock 246 131 192 minecraft:light[level=13]
setblock 246 131 200 minecraft:light[level=13]
setblock 246 131 208 minecraft:light[level=13]
setblock 246 131 216 minecraft:light[level=13]
fill 248 131 181 251 147 181 minecraft:andesite
fill 249 131 223 252 147 223 minecraft:andesite
setblock 254 131 184 minecraft:light[level=13]
setblock 254 131 192 minecraft:light[level=13]
setblock 254 131 200 minecraft:light[level=13]
setblock 254 131 208 minecraft:light[level=13]
setblock 254 131 216 minecraft:light[level=13]
fill 258 131 181 261 147 181 minecraft:andesite
fill 259 131 223 262 147 223 minecraft:andesite
setblock 262 131 184 minecraft:light[level=13]
setblock 262 131 192 minecraft:light[level=13]
setblock 262 131 200 minecraft:light[level=13]
setblock 262 131 208 minecraft:light[level=13]
setblock 262 131 216 minecraft:light[level=13]
fill 268 131 181 271 147 181 minecraft:andesite
fill 269 131 223 272 147 223 minecraft:andesite
setblock 270 131 184 minecraft:light[level=13]
setblock 270 131 192 minecraft:light[level=13]
setblock 270 131 200 minecraft:light[level=13]
setblock 270 131 208 minecraft:light[level=13]
setblock 270 131 216 minecraft:light[level=13]
fill 277 131 182 277 147 185 minecraft:andesite
fill 277 131 192 277 147 195 minecraft:andesite
fill 277 131 202 277 147 205 minecraft:andesite
fill 277 131 212 277 147 215 minecraft:andesite
fill 277 131 222 277 147 222 minecraft:andesite
setblock 236 132 184 minecraft:smooth_stone
setblock 236 132 194 minecraft:smooth_stone
setblock 236 132 204 minecraft:smooth_stone
setblock 236 132 214 minecraft:smooth_stone
setblock 238 132 222 minecraft:smooth_stone
setblock 242 132 182 minecraft:smooth_stone
setblock 248 132 222 minecraft:smooth_stone
setblock 252 132 182 minecraft:smooth_stone
setblock 258 132 222 minecraft:smooth_stone
setblock 262 132 182 minecraft:smooth_stone
setblock 268 132 222 minecraft:smooth_stone
setblock 272 132 182 minecraft:smooth_stone
setblock 276 132 188 minecraft:smooth_stone
setblock 276 132 198 minecraft:smooth_stone
setblock 276 132 208 minecraft:smooth_stone
setblock 276 132 218 minecraft:smooth_stone
setblock 238 139 184 minecraft:light[level=13]
setblock 238 139 192 minecraft:light[level=13]
setblock 238 139 200 minecraft:light[level=13]
setblock 238 139 208 minecraft:light[level=13]
setblock 238 139 216 minecraft:light[level=13]
fill 244 139 201 245 140 201 minecraft:iron_block
fill 245 139 197 245 140 200 minecraft:iron_block
fill 245 139 202 245 140 205 minecraft:iron_block
setblock 246 139 184 minecraft:light[level=13]
setblock 246 139 192 minecraft:light[level=13]
fill 246 139 195 246 140 197 minecraft:iron_block
fill 246 139 198 252 139 204 minecraft:smooth_stone
fill 246 139 205 246 140 207 minecraft:iron_block
setblock 246 139 208 minecraft:light[level=13]
setblock 246 139 216 minecraft:light[level=13]
fill 247 139 194 247 140 195 minecraft:iron_block
fill 247 139 196 265 139 197 minecraft:smooth_stone
fill 247 139 205 265 139 206 minecraft:smooth_stone
fill 247 139 207 247 140 208 minecraft:iron_block
fill 248 139 193 248 140 193 minecraft:iron_block
fill 248 139 194 264 140 195 minecraft:smooth_stone
fill 248 139 207 264 139 208 minecraft:smooth_stone
fill 248 139 209 248 140 209 minecraft:iron_block
fill 249 139 192 250 140 192 minecraft:iron_block
fill 249 139 193 263 139 193 minecraft:smooth_stone
fill 249 139 209 263 139 209 minecraft:smooth_stone
fill 249 139 210 250 140 210 minecraft:iron_block
fill 250 139 191 252 140 191 minecraft:iron_block
fill 250 139 211 252 140 211 minecraft:iron_block
fill 251 139 192 261 139 192 minecraft:smooth_stone
fill 251 139 210 261 139 210 minecraft:smooth_stone
fill 252 139 190 260 140 190 minecraft:iron_block
fill 252 139 212 260 140 212 minecraft:iron_block
fill 253 139 191 259 139 191 minecraft:smooth_stone
fill 253 139 198 253 139 200 minecraft:smooth_stone
fill 253 139 202 253 139 204 minecraft:smooth_stone
fill 253 139 211 259 139 211 minecraft:smooth_stone
setblock 254 139 184 minecraft:light[level=13]
fill 254 139 198 255 139 198 minecraft:smooth_stone
fill 254 139 204 255 139 204 minecraft:smooth_stone
setblock 254 139 216 minecraft:light[level=13]
fill 256 139 189 256 140 189 minecraft:iron_block
fill 256 139 213 256 140 213 minecraft:iron_block
fill 257 139 198 266 139 198 minecraft:smooth_stone
fill 257 139 204 266 139 204 minecraft:smooth_stone
fill 259 139 199 266 139 200 minecraft:smooth_stone
fill 259 139 202 266 139 203 minecraft:smooth_stone
fill 260 139 191 262 140 191 minecraft:iron_block
fill 260 139 201 266 139 201 minecraft:smooth_stone
fill 260 139 211 262 140 211 minecraft:iron_block
setblock 262 139 184 minecraft:light[level=13]
fill 262 139 192 263 140 192 minecraft:iron_block
fill 262 139 210 263 140 210 minecraft:iron_block
setblock 262 139 216 minecraft:light[level=13]
fill 264 139 193 264 140 193 minecraft:iron_block
fill 264 139 209 264 140 209 minecraft:iron_block
fill 265 139 194 265 140 195 minecraft:iron_block
fill 265 139 207 265 140 208 minecraft:iron_block
fill 266 139 195 266 140 197 minecraft:iron_block
fill 266 139 205 266 140 207 minecraft:iron_block
fill 267 139 197 267 140 205 minecraft:iron_block
fill 268 139 201 268 140 201 minecraft:iron_block
setblock 270 139 184 minecraft:light[level=13]
setblock 270 139 192 minecraft:light[level=13]
setblock 270 139 200 minecraft:light[level=13]
setblock 270 139 208 minecraft:light[level=13]
setblock 270 139 216 minecraft:light[level=13]
fill 236 140 182 243 140 222 minecraft:gray_concrete
fill 244 140 182 244 140 200 minecraft:gray_concrete
fill 244 140 202 244 140 222 minecraft:gray_concrete
fill 245 140 182 245 140 196 minecraft:gray_concrete
fill 245 140 206 245 140 222 minecraft:gray_concrete
fill 246 140 182 246 140 194 minecraft:gray_concrete
fill 246 140 198 251 140 200 minecraft:smooth_stone
fill 246 140 201 247 140 201 minecraft:redstone_block
fill 246 140 202 251 140 204 minecraft:smooth_stone
fill 246 140 208 246 140 222 minecraft:gray_concrete
fill 247 140 182 247 140 193 minecraft:gray_concrete
fill 247 140 196 248 140 196 minecraft:redstone_block
fill 247 140 197 254 140 197 minecraft:smooth_stone
fill 247 140 205 251 140 205 minecraft:smooth_stone
fill 247 140 206 248 140 206 minecraft:redstone_block
fill 247 140 209 247 140 222 minecraft:gray_concrete
fill 248 140 182 248 140 192 minecraft:gray_concrete
fill 248 140 201 251 140 201 minecraft:smooth_stone
fill 248 140 207 249 140 208 minecraft:smooth_stone
fill 248 140 210 248 140 222 minecraft:gray_concrete
fill 249 140 182 249 140 191 minecraft:gray_concrete
fill 249 140 193 250 140 193 minecraft:smooth_stone
fill 249 140 196 263 140 196 minecraft:smooth_stone
fill 249 140 206 250 140 206 minecraft:smooth_stone
fill 249 140 209 250 140 209 minecraft:smooth_stone
fill 249 140 211 249 140 222 minecraft:gray_concrete
fill 250 140 182 251 140 190 minecraft:gray_concrete
fill 250 140 207 250 140 208 minecraft:black_concrete
fill 250 140 212 251 140 222 minecraft:gray_concrete
fill 251 140 192 251 140 193 minecraft:redstone_block
fill 251 140 206 251 140 207 minecraft:black_concrete
fill 251 140 208 264 140 208 minecraft:smooth_stone
fill 251 140 209 251 140 210 minecraft:redstone_block
fill 252 140 182 255 140 189 minecraft:gray_concrete
fill 252 140 192 255 140 193 minecraft:smooth_stone
fill 252 140 198 252 140 199 minecraft:smooth_stone
fill 252 140 200 252 140 202 minecraft:ochre_froglight
fill 252 140 203 252 140 204 minecraft:smooth_stone
fill 252 140 205 252 140 206 minecraft:black_concrete
fill 252 140 207 264 140 207 minecraft:smooth_stone
fill 252 140 209 255 140 210 minecraft:smooth_stone
fill 252 140 213 255 140 222 minecraft:gray_concrete
fill 253 140 191 255 140 191 minecraft:smooth_stone
fill 253 140 198 253 140 200 minecraft:ochre_froglight
fill 253 140 202 253 140 204 minecraft:ochre_froglight
setblock 253 140 205 minecraft:black_concrete
fill 253 140 206 263 140 206 minecraft:smooth_stone
fill 253 140 211 255 140 211 minecraft:smooth_stone
fill 254 140 198 255 140 198 minecraft:ochre_froglight
fill 254 140 204 255 140 204 minecraft:ochre_froglight
setblock 254 140 205 minecraft:smooth_stone
fill 255 140 197 257 140 197 minecraft:ochre_froglight
fill 255 140 205 257 140 205 minecraft:ochre_froglight
fill 256 140 182 276 140 188 minecraft:gray_concrete
fill 256 140 191 256 140 192 minecraft:redstone_block
fill 256 140 193 260 140 193 minecraft:smooth_stone
fill 256 140 209 260 140 209 minecraft:smooth_stone
fill 256 140 210 256 140 211 minecraft:redstone_block
fill 256 140 214 276 140 222 minecraft:gray_concrete
fill 257 140 189 276 140 189 minecraft:gray_concrete
fill 257 140 191 259 140 192 minecraft:smooth_stone
fill 257 140 198 259 140 198 minecraft:ochre_froglight
fill 257 140 204 259 140 204 minecraft:ochre_froglight
fill 257 140 210 259 140 211 minecraft:smooth_stone
fill 257 140 213 276 140 213 minecraft:gray_concrete
fill 258 140 197 265 140 197 minecraft:smooth_stone
fill 258 140 205 259 140 205 minecraft:smooth_stone
fill 259 140 199 259 140 200 minecraft:ochre_froglight
fill 259 140 202 259 140 203 minecraft:ochre_froglight
setblock 260 140 192 minecraft:smooth_stone
fill 260 140 198 266 140 199 minecraft:smooth_stone
fill 260 140 200 260 140 202 minecraft:ochre_froglight
fill 260 140 203 266 140 203 minecraft:smooth_stone
fill 260 140 204 260 140 205 minecraft:black_concrete
setblock 260 140 210 minecraft:smooth_stone
fill 261 140 190 276 140 190 minecraft:gray_concrete
fill 261 140 192 261 140 193 minecraft:redstone_block
fill 261 140 200 264 140 202 minecraft:smooth_stone
fill 261 140 204 266 140 204 minecraft:smooth_stone
setblock 261 140 205 minecraft:black_concrete
fill 261 140 209 261 140 210 minecraft:redstone_block
fill 261 140 212 276 140 212 minecraft:gray_concrete
fill 262 140 193 263 140 193 minecraft:smooth_stone
fill 262 140 205 265 140 205 minecraft:smooth_stone
fill 262 140 209 263 140 209 minecraft:smooth_stone
fill 263 140 191 276 140 191 minecraft:gray_concrete
fill 263 140 211 276 140 211 minecraft:gray_concrete
fill 264 140 192 276 140 192 minecraft:gray_concrete
fill 264 140 196 265 140 196 minecraft:redstone_block
fill 264 140 206 265 140 206 minecraft:redstone_block
fill 264 140 210 276 140 210 minecraft:gray_concrete
fill 265 140 193 276 140 193 minecraft:gray_concrete
fill 265 140 200 266 140 200 minecraft:smooth_stone
fill 265 140 201 266 140 201 minecraft:redstone_block
fill 265 140 202 266 140 202 minecraft:smooth_stone
fill 265 140 209 276 140 209 minecraft:gray_concrete
fill 266 140 194 276 140 194 minecraft:gray_concrete
fill 266 140 208 276 140 208 minecraft:gray_concrete
fill 267 140 195 276 140 196 minecraft:gray_concrete
fill 267 140 206 276 140 207 minecraft:gray_concrete
fill 268 140 197 276 140 200 minecraft:gray_concrete
fill 268 140 202 276 140 205 minecraft:gray_concrete
fill 269 140 201 276 140 201 minecraft:gray_concrete
fill 236 144 183 236 211 183 minecraft:iron_block
setblock 236 144 184 minecraft:smooth_stone
fill 236 144 186 236 144 189 minecraft:smooth_stone
fill 236 144 193 236 211 193 minecraft:iron_block
setblock 236 144 194 minecraft:smooth_stone
fill 236 144 196 236 144 199 minecraft:smooth_stone
fill 236 144 203 236 211 203 minecraft:iron_block
setblock 236 144 204 minecraft:smooth_stone
fill 236 144 206 236 144 209 minecraft:smooth_stone
fill 236 144 213 236 211 213 minecraft:iron_block
setblock 236 144 214 minecraft:smooth_stone
fill 236 144 216 236 144 219 minecraft:smooth_stone
fill 237 144 182 240 144 182 minecraft:smooth_stone
fill 237 144 222 237 211 222 minecraft:iron_block
setblock 238 144 222 minecraft:smooth_stone
fill 240 144 222 243 144 222 minecraft:smooth_stone
setblock 242 144 182 minecraft:smooth_stone
fill 243 144 182 243 211 182 minecraft:iron_block
fill 247 144 182 250 144 182 minecraft:smooth_stone
fill 247 144 222 247 211 222 minecraft:iron_block
setblock 248 144 222 minecraft:smooth_stone
fill 250 144 222 253 144 222 minecraft:smooth_stone
setblock 252 144 182 minecraft:smooth_stone
fill 253 144 182 253 211 182 minecraft:iron_block
fill 257 144 182 260 144 182 minecraft:smooth_stone
fill 257 144 222 257 211 222 minecraft:iron_block
setblock 258 144 222 minecraft:smooth_stone
fill 259 144 219 259 145 221 minecraft:iron_block
fill 260 144 222 263 144 222 minecraft:smooth_stone
setblock 262 144 182 minecraft:smooth_stone
fill 263 144 182 263 211 182 minecraft:iron_block
fill 266 144 218 268 211 218 minecraft:iron_block
fill 267 144 182 270 144 182 minecraft:smooth_stone
fill 267 144 217 267 211 217 minecraft:iron_block
fill 267 144 219 267 211 219 minecraft:iron_block
fill 267 144 222 267 211 222 minecraft:iron_block
setblock 268 144 222 minecraft:smooth_stone
fill 270 144 222 273 144 222 minecraft:smooth_stone
setblock 272 144 182 minecraft:smooth_stone
fill 273 144 182 273 211 182 minecraft:iron_block
fill 276 144 183 276 144 186 minecraft:smooth_stone
setblock 276 144 188 minecraft:smooth_stone
fill 276 144 189 276 211 189 minecraft:iron_block
fill 276 144 193 276 144 196 minecraft:smooth_stone
setblock 276 144 198 minecraft:smooth_stone
fill 276 144 199 276 211 199 minecraft:iron_block
fill 276 144 203 276 144 206 minecraft:smooth_stone
setblock 276 144 208 minecraft:smooth_stone
fill 276 144 209 276 211 209 minecraft:iron_block
fill 276 144 213 276 144 216 minecraft:smooth_stone
setblock 276 144 218 minecraft:smooth_stone
fill 276 144 219 276 211 219 minecraft:iron_block
setblock 266 146 217 minecraft:smooth_stone
setblock 266 146 219 minecraft:smooth_stone
setblock 268 146 217 minecraft:smooth_stone
setblock 268 146 219 minecraft:smooth_stone
setblock 238 147 184 minecraft:light[level=13]
setblock 238 147 192 minecraft:light[level=13]
setblock 238 147 200 minecraft:light[level=13]
setblock 238 147 208 minecraft:light[level=13]
setblock 238 147 216 minecraft:light[level=13]
setblock 246 147 184 minecraft:light[level=13]
setblock 246 147 192 minecraft:light[level=13]
setblock 246 147 200 minecraft:light[level=13]
setblock 246 147 208 minecraft:light[level=13]
setblock 246 147 216 minecraft:light[level=13]
setblock 254 147 184 minecraft:light[level=13]
setblock 254 147 192 minecraft:light[level=13]
setblock 254 147 200 minecraft:light[level=13]
setblock 254 147 208 minecraft:light[level=13]
setblock 254 147 216 minecraft:light[level=13]
setblock 262 147 184 minecraft:light[level=13]
setblock 262 147 192 minecraft:light[level=13]
setblock 262 147 200 minecraft:light[level=13]
setblock 262 147 208 minecraft:light[level=13]
setblock 262 147 216 minecraft:light[level=13]
setblock 270 147 184 minecraft:light[level=13]
setblock 270 147 192 minecraft:light[level=13]
setblock 270 147 200 minecraft:light[level=13]
setblock 270 147 208 minecraft:light[level=13]
setblock 270 147 216 minecraft:light[level=13]
fill 235 148 187 235 148 190 minecraft:ochre_froglight
fill 235 148 197 235 148 200 minecraft:ochre_froglight
fill 235 148 207 235 148 210 minecraft:ochre_froglight
fill 235 148 217 235 148 220 minecraft:ochre_froglight
fill 238 148 181 241 148 181 minecraft:ochre_froglight
fill 239 148 223 242 148 223 minecraft:ochre_froglight
fill 248 148 181 251 148 181 minecraft:ochre_froglight
fill 249 148 223 252 148 223 minecraft:ochre_froglight
fill 258 148 181 261 148 181 minecraft:ochre_froglight
fill 259 148 223 262 148 223 minecraft:ochre_froglight
fill 268 148 181 271 148 181 minecraft:ochre_froglight
fill 269 148 223 272 148 223 minecraft:ochre_froglight
fill 277 148 182 277 148 185 minecraft:ochre_froglight
fill 277 148 192 277 148 195 minecraft:ochre_froglight
fill 277 148 202 277 148 205 minecraft:ochre_froglight
fill 277 148 212 277 148 215 minecraft:ochre_froglight
setblock 277 148 222 minecraft:ochre_froglight
fill 235 149 187 235 156 190 minecraft:andesite
fill 235 149 197 235 156 200 minecraft:andesite
fill 235 149 207 235 156 210 minecraft:andesite
fill 235 149 217 235 156 220 minecraft:andesite
fill 238 149 181 241 156 181 minecraft:andesite
fill 239 149 223 242 156 223 minecraft:andesite
fill 248 149 181 251 156 181 minecraft:andesite
fill 249 149 223 252 156 223 minecraft:andesite
fill 258 149 181 261 156 181 minecraft:andesite
fill 259 149 223 262 156 223 minecraft:andesite
fill 268 149 181 271 156 181 minecraft:andesite
fill 269 149 223 272 156 223 minecraft:andesite
fill 277 149 182 277 156 185 minecraft:andesite
fill 277 149 192 277 156 195 minecraft:andesite
fill 277 149 202 277 156 205 minecraft:andesite
fill 277 149 212 277 156 215 minecraft:andesite
fill 277 149 222 277 156 222 minecraft:andesite
setblock 236 150 184 minecraft:smooth_stone
setblock 236 150 194 minecraft:smooth_stone
setblock 236 150 204 minecraft:smooth_stone
setblock 236 150 214 minecraft:smooth_stone
setblock 238 150 222 minecraft:smooth_stone
setblock 242 150 182 minecraft:smooth_stone
setblock 248 150 222 minecraft:smooth_stone
setblock 252 150 182 minecraft:smooth_stone
setblock 258 150 222 minecraft:smooth_stone
setblock 262 150 182 minecraft:smooth_stone
fill 267 150 220 267 151 221 minecraft:iron_block
setblock 268 150 222 minecraft:smooth_stone
setblock 272 150 182 minecraft:smooth_stone
setblock 276 150 188 minecraft:smooth_stone
setblock 276 150 198 minecraft:smooth_stone
setblock 276 150 208 minecraft:smooth_stone
setblock 276 150 218 minecraft:smooth_stone
setblock 267 151 216 minecraft:ochre_froglight
setblock 266 152 217 minecraft:smooth_stone
setblock 266 152 219 minecraft:smooth_stone
setblock 268 152 217 minecraft:smooth_stone
setblock 268 152 219 minecraft:smooth_stone
fill 236 153 186 236 153 189 minecraft:smooth_stone
fill 236 153 196 236 153 199 minecraft:smooth_stone
fill 236 153 206 236 153 209 minecraft:smooth_stone
fill 236 153 216 236 153 219 minecraft:smooth_stone
fill 237 153 182 240 153 182 minecraft:smooth_stone
fill 240 153 222 243 153 222 minecraft:smooth_stone
fill 247 153 182 250 153 182 minecraft:smooth_stone
fill 250 153 222 253 153 222 minecraft:smooth_stone
fill 257 153 182 260 153 182 minecraft:smooth_stone
fill 260 153 222 263 153 222 minecraft:smooth_stone
fill 267 153 182 270 153 182 minecraft:smooth_stone
fill 270 153 222 273 153 222 minecraft:smooth_stone
fill 276 153 183 276 153 186 minecraft:smooth_stone
fill 276 153 193 276 153 196 minecraft:smooth_stone
fill 276 153 203 276 153 206 minecraft:smooth_stone
fill 276 153 213 276 153 216 minecraft:smooth_stone
fill 261 154 213 276 154 213 minecraft:smooth_stone
fill 264 154 183 276 154 183 minecraft:smooth_stone
fill 236 155 188 246 156 188 minecraft:smooth_stone
fill 236 155 198 275 155 198 minecraft:smooth_stone
fill 236 155 208 245 156 208 minecraft:smooth_stone
fill 236 155 218 265 155 218 minecraft:smooth_stone
fill 237 155 183 269 155 183 minecraft:smooth_stone
fill 237 155 193 253 156 193 minecraft:smooth_stone
fill 237 155 203 238 156 203 minecraft:smooth_stone
fill 237 155 213 266 155 213 minecraft:smooth_stone
setblock 238 155 184 minecraft:light[level=13]
setblock 238 155 192 minecraft:light[level=13]
setblock 238 155 200 minecraft:light[level=13]
setblock 238 155 216 minecraft:light[level=13]
setblock 246 155 184 minecraft:light[level=13]
setblock 246 155 192 minecraft:light[level=13]
setblock 246 155 200 minecraft:light[level=13]
setblock 246 155 208 minecraft:light[level=13]
setblock 246 155 216 minecraft:light[level=13]
setblock 254 155 184 minecraft:light[level=13]
setblock 254 155 192 minecraft:light[level=13]
setblock 254 155 200 minecraft:light[level=13]
setblock 254 155 208 minecraft:light[level=13]
setblock 254 155 216 minecraft:light[level=13]
setblock 262 155 184 minecraft:light[level=13]
setblock 262 155 192 minecraft:light[level=13]
setblock 262 155 200 minecraft:light[level=13]
setblock 262 155 208 minecraft:light[level=13]
setblock 262 155 216 minecraft:light[level=13]
fill 269 155 218 275 155 218 minecraft:smooth_stone
setblock 270 155 184 minecraft:light[level=13]
setblock 270 155 192 minecraft:light[level=13]
setblock 270 155 200 minecraft:light[level=13]
setblock 270 155 208 minecraft:light[level=13]
setblock 270 155 216 minecraft:light[level=13]
setblock 236 156 184 minecraft:smooth_stone
setblock 236 156 194 minecraft:smooth_stone
fill 236 156 198 240 156 198 minecraft:smooth_stone
setblock 236 156 204 minecraft:smooth_stone
setblock 236 156 214 minecraft:smooth_stone
fill 236 156 218 246 156 218 minecraft:smooth_stone
fill 237 156 183 238 156 183 minecraft:smooth_stone
fill 237 156 213 238 156 213 minecraft:smooth_stone
setblock 238 156 222 minecraft:smooth_stone
fill 239 156 203 251 156 203 minecraft:smooth_stone
setblock 242 156 182 minecraft:smooth_stone
fill 246 156 208 276 156 208 minecraft:smooth_stone
fill 247 156 188 276 156 188 minecraft:smooth_stone
fill 247 156 212 247 156 221 minecraft:iron_block
fill 248 156 218 263 156 218 minecraft:smooth_stone
setblock 248 156 222 minecraft:smooth_stone
setblock 252 156 182 minecraft:smooth_stone
fill 254 156 193 276 156 193 minecraft:smooth_stone
setblock 258 156 222 minecraft:smooth_stone
fill 259 156 203 268 156 203 minecraft:smooth_stone
setblock 262 156 182 minecraft:smooth_stone
fill 267 156 212 267 157 216 minecraft:iron_block
fill 267 156 220 267 156 221 minecraft:iron_block
setblock 268 156 222 minecraft:smooth_stone
setblock 272 156 182 minecraft:smooth_stone
setblock 276 156 198 minecraft:smooth_stone
setblock 276 156 218 minecraft:smooth_stone
fill 235 157 187 235 157 190 minecraft:ochre_froglight
fill 235 157 197 235 157 200 minecraft:ochre_froglight
fill 235 157 207 235 157 210 minecraft:ochre_froglight
fill 235 157 217 235 157 220 minecraft:ochre_froglight
fill 237 157 182 237 157 221 minecraft:iron_block
fill 238 157 181 241 157 181 minecraft:ochre_froglight
fill 239 157 223 242 157 223 minecraft:ochre_froglight
fill 242 157 182 242 158 184 minecraft:iron_block
fill 247 157 182 247 157 217 minecraft:iron_block
fill 248 157 181 251 157 181 minecraft:ochre_froglight
fill 249 157 223 252 157 223 minecraft:ochre_froglight
fill 252 157 182 252 157 202 minecraft:iron_block
fill 252 157 206 252 157 222 minecraft:iron_block
fill 257 157 182 257 157 201 minecraft:iron_block
fill 257 157 207 257 157 221 minecraft:iron_block
fill 258 157 181 261 157 181 minecraft:ochre_froglight
fill 259 157 223 262 157 223 minecraft:ochre_froglight
fill 262 157 182 262 158 189 minecraft:iron_block
fill 263 157 203 276 157 203 minecraft:smooth_stone
fill 267 157 182 267 157 202 minecraft:iron_block
fill 267 157 204 267 157 211 minecraft:iron_block
fill 268 157 181 271 157 181 minecraft:ochre_froglight
fill 269 157 223 272 157 223 minecraft:ochre_froglight
fill 272 157 182 272 158 202 minecraft:iron_block
fill 272 157 204 272 158 221 minecraft:iron_block
fill 277 157 182 277 157 185 minecraft:ochre_froglight
fill 277 157 192 277 157 195 minecraft:ochre_froglight
fill 277 157 202 277 157 205 minecraft:ochre_froglight
fill 277 157 212 277 157 215 minecraft:ochre_froglight
setblock 277 157 222 minecraft:ochre_froglight
fill 235 158 187 235 165 190 minecraft:andesite
fill 235 158 197 235 165 200 minecraft:andesite
fill 235 158 207 235 165 210 minecraft:andesite
fill 235 158 217 235 165 220 minecraft:andesite
fill 237 158 182 237 158 186 minecraft:iron_block
fill 238 158 181 241 165 181 minecraft:andesite
fill 239 158 223 242 165 223 minecraft:andesite
fill 242 158 185 242 158 214 minecraft:iron_block
fill 247 158 182 247 158 184 minecraft:iron_block
fill 248 158 181 251 165 181 minecraft:andesite
fill 249 158 223 252 165 223 minecraft:andesite
fill 252 158 182 252 158 200 minecraft:iron_block
fill 257 158 182 257 158 191 minecraft:iron_block
fill 258 158 181 261 165 181 minecraft:andesite
fill 259 158 223 262 165 223 minecraft:andesite
fill 262 158 190 262 158 222 minecraft:iron_block
setblock 266 158 217 minecraft:smooth_stone
setblock 266 158 219 minecraft:smooth_stone
fill 267 158 182 267 158 184 minecraft:iron_block
fill 268 158 181 271 165 181 minecraft:andesite
setblock 268 158 217 minecraft:smooth_stone
setblock 268 158 219 minecraft:smooth_stone
fill 269 158 223 272 165 223 minecraft:andesite
setblock 272 158 203 minecraft:iron_block
fill 277 158 182 277 165 185 minecraft:andesite
fill 277 158 192 277 165 195 minecraft:andesite
fill 277 158 202 277 165 205 minecraft:andesite
fill 277 158 212 277 165 215 minecraft:andesite
fill 277 158 222 277 165 222 minecraft:andesite
fill 242 159 209 242 159 222 minecraft:iron_block
setblock 236 162 184 minecraft:smooth_stone
fill 236 162 186 236 162 189 minecraft:smooth_stone
setblock 236 162 194 minecraft:smooth_stone
fill 236 162 196 236 162 199 minecraft:smooth_stone
setblock 236 162 204 minecraft:smooth_stone
fill 236 162 206 236 162 209 minecraft:smooth_stone
setblock 236 162 214 minecraft:smooth_stone
fill 236 162 216 236 162 219 minecraft:smooth_stone
fill 237 162 182 240 162 182 minecraft:smooth_stone
setblock 238 162 222 minecraft:smooth_stone
fill 240 162 222 243 162 222 minecraft:smooth_stone
setblock 242 162 182 minecraft:smooth_stone
fill 247 162 182 250 162 182 minecraft:smooth_stone
setblock 248 162 222 minecraft:smooth_stone
fill 250 162 222 253 162 222 minecraft:smooth_stone
setblock 252 162 182 minecraft:smooth_stone
fill 257 162 182 260 162 182 minecraft:smooth_stone
setblock 258 162 222 minecraft:smooth_stone
fill 260 162 222 263 162 222 minecraft:smooth_stone
setblock 262 162 182 minecraft:smooth_stone
fill 267 162 182 270 162 182 minecraft:smooth_stone
setblock 268 162 222 minecraft:smooth_stone
fill 270 162 222 273 162 222 minecraft:smooth_stone
setblock 272 162 182 minecraft:smooth_stone
fill 276 162 183 276 162 186 minecraft:smooth_stone
setblock 276 162 188 minecraft:smooth_stone
fill 276 162 193 276 162 196 minecraft:smooth_stone
setblock 276 162 198 minecraft:smooth_stone
fill 276 162 203 276 162 206 minecraft:smooth_stone
setblock 276 162 208 minecraft:smooth_stone
fill 276 162 213 276 162 216 minecraft:smooth_stone
setblock 276 162 218 minecraft:smooth_stone
setblock 238 163 184 minecraft:light[level=13]
setblock 238 163 192 minecraft:light[level=13]
setblock 238 163 200 minecraft:light[level=13]
setblock 238 163 208 minecraft:light[level=13]
setblock 238 163 216 minecraft:light[level=13]
setblock 246 163 184 minecraft:light[level=13]
setblock 246 163 192 minecraft:light[level=13]
setblock 246 163 200 minecraft:light[level=13]
setblock 246 163 208 minecraft:light[level=13]
setblock 246 163 216 minecraft:light[level=13]
setblock 254 163 184 minecraft:light[level=13]
setblock 254 163 192 minecraft:light[level=13]
setblock 254 163 200 minecraft:light[level=13]
setblock 254 163 208 minecraft:light[level=13]
setblock 254 163 216 minecraft:light[level=13]
setblock 262 163 184 minecraft:light[level=13]
setblock 262 163 192 minecraft:light[level=13]
setblock 262 163 200 minecraft:light[level=13]
setblock 262 163 208 minecraft:light[level=13]
setblock 262 163 216 minecraft:light[level=13]
setblock 270 163 184 minecraft:light[level=13]
setblock 270 163 192 minecraft:light[level=13]
setblock 270 163 200 minecraft:light[level=13]
setblock 270 163 208 minecraft:light[level=13]
setblock 270 163 216 minecraft:light[level=13]
setblock 266 164 217 minecraft:smooth_stone
setblock 266 164 219 minecraft:smooth_stone
setblock 268 164 217 minecraft:smooth_stone
setblock 268 164 219 minecraft:smooth_stone
fill 235 166 187 235 166 190 minecraft:ochre_froglight
fill 235 166 197 235 166 200 minecraft:ochre_froglight
fill 235 166 207 235 166 210 minecraft:ochre_froglight
fill 235 166 217 235 166 220 minecraft:ochre_froglight
fill 238 166 181 241 166 181 minecraft:ochre_froglight
fill 239 166 223 242 166 223 minecraft:ochre_froglight
fill 248 166 181 251 166 181 minecraft:ochre_froglight
fill 249 166 223 252 166 223 minecraft:ochre_froglight
fill 258 166 181 261 166 181 minecraft:ochre_froglight
fill 259 166 223 262 166 223 minecraft:ochre_froglight
fill 268 166 181 271 166 181 minecraft:ochre_froglight
fill 269 166 223 272 166 223 minecraft:ochre_froglight
fill 277 166 182 277 166 185 minecraft:ochre_froglight
fill 277 166 192 277 166 195 minecraft:ochre_froglight
fill 277 166 202 277 166 205 minecraft:ochre_froglight
fill 277 166 212 277 166 215 minecraft:ochre_froglight
setblock 277 166 222 minecraft:ochre_froglight
fill 235 167 187 235 174 190 minecraft:andesite
fill 235 167 197 235 174 200 minecraft:andesite
fill 235 167 207 235 174 210 minecraft:andesite
fill 235 167 217 235 174 220 minecraft:andesite
fill 238 167 181 241 174 181 minecraft:andesite
fill 239 167 223 242 174 223 minecraft:andesite
fill 248 167 181 251 174 181 minecraft:andesite
fill 249 167 223 252 174 223 minecraft:andesite
fill 258 167 181 261 174 181 minecraft:andesite
fill 259 167 223 262 174 223 minecraft:andesite
fill 268 167 181 271 174 181 minecraft:andesite
fill 269 167 223 272 174 223 minecraft:andesite
fill 277 167 182 277 174 185 minecraft:andesite
fill 277 167 192 277 174 195 minecraft:andesite
fill 277 167 202 277 174 205 minecraft:andesite
fill 277 167 212 277 174 215 minecraft:andesite
fill 277 167 222 277 174 222 minecraft:andesite
setblock 236 168 184 minecraft:smooth_stone
setblock 236 168 194 minecraft:smooth_stone
setblock 236 168 204 minecraft:smooth_stone
setblock 236 168 214 minecraft:smooth_stone
setblock 238 168 222 minecraft:smooth_stone
setblock 242 168 182 minecraft:smooth_stone
setblock 248 168 222 minecraft:smooth_stone
setblock 252 168 182 minecraft:smooth_stone
setblock 258 168 222 minecraft:smooth_stone
setblock 262 168 182 minecraft:smooth_stone
setblock 268 168 222 minecraft:smooth_stone
setblock 272 168 182 minecraft:smooth_stone
setblock 276 168 188 minecraft:smooth_stone
setblock 276 168 198 minecraft:smooth_stone
setblock 276 168 208 minecraft:smooth_stone
setblock 276 168 218 minecraft:smooth_stone
setblock 266 170 217 minecraft:smooth_stone
setblock 266 170 219 minecraft:smooth_stone
setblock 268 170 217 minecraft:smooth_stone
setblock 268 170 219 minecraft:smooth_stone
fill 236 171 186 236 171 189 minecraft:smooth_stone
fill 236 171 196 236 171 199 minecraft:smooth_stone
fill 236 171 206 236 171 209 minecraft:smooth_stone
fill 236 171 216 236 171 219 minecraft:smooth_stone
fill 237 171 182 240 171 182 minecraft:smooth_stone
setblock 238 171 184 minecraft:light[level=13]
setblock 238 171 192 minecraft:light[level=13]
setblock 238 171 200 minecraft:light[level=13]
setblock 238 171 208 minecraft:light[level=13]
setblock 238 171 216 minecraft:light[level=13]
fill 240 171 222 243 171 222 minecraft:smooth_stone
setblock 246 171 184 minecraft:light[level=13]
setblock 246 171 192 minecraft:light[level=13]
setblock 246 171 200 minecraft:light[level=13]
setblock 246 171 208 minecraft:light[level=13]
setblock 246 171 216 minecraft:light[level=13]
fill 247 171 182 250 171 182 minecraft:smooth_stone
fill 250 171 222 253 171 222 minecraft:smooth_stone
setblock 254 171 184 minecraft:light[level=13]
setblock 254 171 192 minecraft:light[level=13]
setblock 254 171 200 minecraft:light[level=13]
setblock 254 171 208 minecraft:light[level=13]
setblock 254 171 216 minecraft:light[level=13]
fill 257 171 182 260 171 182 minecraft:smooth_stone
fill 260 171 222 263 171 222 minecraft:smooth_stone
setblock 262 171 184 minecraft:light[level=13]
setblock 262 171 192 minecraft:light[level=13]
setblock 262 171 200 minecraft:light[level=13]
setblock 262 171 208 minecraft:light[level=13]
setblock 262 171 216 minecraft:light[level=13]
fill 267 171 182 270 171 182 minecraft:smooth_stone
setblock 270 171 184 minecraft:light[level=13]
setblock 270 171 192 minecraft:light[level=13]
setblock 270 171 200 minecraft:light[level=13]
setblock 270 171 208 minecraft:light[level=13]
setblock 270 171 216 minecraft:light[level=13]
fill 270 171 222 273 171 222 minecraft:smooth_stone
fill 276 171 183 276 171 186 minecraft:smooth_stone
fill 276 171 193 276 171 196 minecraft:smooth_stone
fill 276 171 203 276 171 206 minecraft:smooth_stone
fill 276 171 213 276 171 216 minecraft:smooth_stone
setblock 236 174 184 minecraft:smooth_stone
setblock 236 174 194 minecraft:smooth_stone
setblock 236 174 204 minecraft:smooth_stone
setblock 236 174 214 minecraft:smooth_stone
setblock 238 174 222 minecraft:smooth_stone
setblock 242 174 182 minecraft:smooth_stone
setblock 248 174 222 minecraft:smooth_stone
setblock 252 174 182 minecraft:smooth_stone
setblock 258 174 222 minecraft:smooth_stone
setblock 262 174 182 minecraft:smooth_stone
setblock 268 174 222 minecraft:smooth_stone
setblock 272 174 182 minecraft:smooth_stone
setblock 276 174 188 minecraft:smooth_stone
setblock 276 174 198 minecraft:smooth_stone
setblock 276 174 208 minecraft:smooth_stone
setblock 276 174 218 minecraft:smooth_stone
fill 235 175 187 235 175 190 minecraft:ochre_froglight
fill 235 175 197 235 175 200 minecraft:ochre_froglight
fill 235 175 207 235 175 210 minecraft:ochre_froglight
fill 235 175 217 235 175 220 minecraft:ochre_froglight
fill 238 175 181 241 175 181 minecraft:ochre_froglight
fill 239 175 223 242 175 223 minecraft:ochre_froglight
fill 248 175 181 251 175 181 minecraft:ochre_froglight
fill 249 175 223 252 175 223 minecraft:ochre_froglight
fill 258 175 181 261 175 181 minecraft:ochre_froglight
fill 259 175 223 262 175 223 minecraft:ochre_froglight
fill 268 175 181 271 175 181 minecraft:ochre_froglight
fill 269 175 223 272 175 223 minecraft:ochre_froglight
fill 277 175 182 277 175 185 minecraft:ochre_froglight
fill 277 175 192 277 175 195 minecraft:ochre_froglight
fill 277 175 202 277 175 205 minecraft:ochre_froglight
fill 277 175 212 277 175 215 minecraft:ochre_froglight
setblock 277 175 222 minecraft:ochre_froglight
fill 235 176 187 235 183 190 minecraft:andesite
fill 235 176 197 235 183 200 minecraft:andesite
fill 235 176 207 235 183 210 minecraft:andesite
fill 235 176 217 235 183 220 minecraft:andesite
fill 238 176 181 241 183 181 minecraft:andesite
fill 239 176 223 242 183 223 minecraft:andesite
fill 248 176 181 251 183 181 minecraft:andesite
fill 249 176 223 252 183 223 minecraft:andesite
fill 258 176 181 261 183 181 minecraft:andesite
fill 259 176 223 262 183 223 minecraft:andesite
setblock 266 176 217 minecraft:smooth_stone
setblock 266 176 219 minecraft:smooth_stone
fill 268 176 181 271 183 181 minecraft:andesite
setblock 268 176 217 minecraft:smooth_stone
setblock 268 176 219 minecraft:smooth_stone
fill 269 176 223 272 183 223 minecraft:andesite
fill 277 176 182 277 183 185 minecraft:andesite
fill 277 176 192 277 183 195 minecraft:andesite
fill 277 176 202 277 183 205 minecraft:andesite
fill 277 176 212 277 183 215 minecraft:andesite
fill 277 176 222 277 183 222 minecraft:andesite
setblock 238 179 184 minecraft:light[level=13]
setblock 238 179 192 minecraft:light[level=13]
setblock 238 179 200 minecraft:light[level=13]
setblock 238 179 208 minecraft:light[level=13]
setblock 238 179 216 minecraft:light[level=13]
setblock 246 179 184 minecraft:light[level=13]
setblock 246 179 192 minecraft:light[level=13]
setblock 246 179 200 minecraft:light[level=13]
setblock 246 179 208 minecraft:light[level=13]
setblock 246 179 216 minecraft:light[level=13]
setblock 254 179 184 minecraft:light[level=13]
setblock 254 179 192 minecraft:light[level=13]
setblock 254 179 200 minecraft:light[level=13]
setblock 254 179 208 minecraft:light[level=13]
setblock 254 179 216 minecraft:light[level=13]
setblock 262 179 184 minecraft:light[level=13]
setblock 262 179 192 minecraft:light[level=13]
setblock 262 179 200 minecraft:light[level=13]
setblock 262 179 208 minecraft:light[level=13]
setblock 262 179 216 minecraft:light[level=13]
setblock 270 179 184 minecraft:light[level=13]
setblock 270 179 192 minecraft:light[level=13]
setblock 270 179 200 minecraft:light[level=13]
setblock 270 179 208 minecraft:light[level=13]
setblock 270 179 216 minecraft:light[level=13]
fill 273 179 212 275 180 212 minecraft:iron_block
setblock 236 180 184 minecraft:smooth_stone
fill 236 180 186 236 180 189 minecraft:smooth_stone
setblock 236 180 194 minecraft:smooth_stone
fill 236 180 196 236 180 199 minecraft:smooth_stone
setblock 236 180 204 minecraft:smooth_stone
fill 236 180 206 236 180 209 minecraft:smooth_stone
setblock 236 180 214 minecraft:smooth_stone
fill 236 180 216 236 180 219 minecraft:smooth_stone
fill 237 180 182 240 180 182 minecraft:smooth_stone
setblock 238 180 222 minecraft:smooth_stone
fill 240 180 222 243 180 222 minecraft:smooth_stone
setblock 242 180 182 minecraft:smooth_stone
fill 247 180 182 250 180 182 minecraft:smooth_stone
setblock 248 180 222 minecraft:smooth_stone
fill 250 180 222 253 180 222 minecraft:smooth_stone
setblock 252 180 182 minecraft:smooth_stone
fill 257 180 182 260 180 182 minecraft:smooth_stone
setblock 258 180 222 minecraft:smooth_stone
fill 260 180 222 263 180 222 minecraft:smooth_stone
setblock 262 180 182 minecraft:smooth_stone
fill 267 180 182 270 180 182 minecraft:smooth_stone
setblock 268 180 222 minecraft:smooth_stone
fill 270 180 222 273 180 222 minecraft:smooth_stone
setblock 272 180 182 minecraft:smooth_stone
fill 276 180 183 276 180 186 minecraft:smooth_stone
setblock 276 180 188 minecraft:smooth_stone
fill 276 180 193 276 180 196 minecraft:smooth_stone
setblock 276 180 198 minecraft:smooth_stone
fill 276 180 203 276 180 206 minecraft:smooth_stone
setblock 276 180 208 minecraft:smooth_stone
fill 276 180 213 276 180 216 minecraft:smooth_stone
setblock 276 180 218 minecraft:smooth_stone
setblock 266 182 217 minecraft:smooth_stone
setblock 266 182 219 minecraft:smooth_stone
setblock 268 182 217 minecraft:smooth_stone
setblock 268 182 219 minecraft:smooth_stone
fill 235 184 187 235 184 190 minecraft:ochre_froglight
fill 235 184 197 235 184 200 minecraft:ochre_froglight
fill 235 184 207 235 184 210 minecraft:ochre_froglight
fill 235 184 217 235 184 220 minecraft:ochre_froglight
fill 238 184 181 241 184 181 minecraft:ochre_froglight
fill 239 184 223 242 184 223 minecraft:ochre_froglight
fill 248 184 181 251 184 181 minecraft:ochre_froglight
fill 249 184 223 252 184 223 minecraft:ochre_froglight
fill 258 184 181 261 184 181 minecraft:ochre_froglight
fill 259 184 223 262 184 223 minecraft:ochre_froglight
fill 268 184 181 271 184 181 minecraft:ochre_froglight
fill 269 184 223 272 184 223 minecraft:ochre_froglight
fill 277 184 182 277 184 185 minecraft:ochre_froglight
fill 277 184 192 277 184 195 minecraft:ochre_froglight
fill 277 184 202 277 184 205 minecraft:ochre_froglight
fill 277 184 212 277 184 215 minecraft:ochre_froglight
setblock 277 184 222 minecraft:ochre_froglight
fill 235 185 187 235 189 190 minecraft:andesite
fill 235 185 197 235 189 200 minecraft:andesite
fill 235 185 207 235 189 210 minecraft:andesite
fill 235 185 217 235 188 220 minecraft:andesite
fill 238 185 181 241 188 181 minecraft:andesite
fill 239 185 223 242 190 223 minecraft:andesite
fill 248 185 181 251 188 181 minecraft:andesite
fill 249 185 223 252 189 223 minecraft:andesite
fill 258 185 181 261 190 181 minecraft:andesite
fill 259 185 223 262 189 223 minecraft:andesite
fill 268 185 181 271 188 181 minecraft:andesite
fill 269 185 223 272 188 223 minecraft:andesite
fill 277 185 182 277 189 185 minecraft:andesite
fill 277 185 192 277 189 195 minecraft:andesite
fill 277 185 202 277 188 205 minecraft:andesite
fill 277 185 212 277 189 215 minecraft:andesite
fill 277 185 222 277 188 222 minecraft:andesite
setblock 236 186 184 minecraft:smooth_stone
setblock 236 186 194 minecraft:smooth_stone
setblock 236 186 204 minecraft:smooth_stone
setblock 236 186 214 minecraft:smooth_stone
setblock 238 186 222 minecraft:smooth_stone
setblock 242 186 182 minecraft:smooth_stone
setblock 248 186 222 minecraft:smooth_stone
setblock 252 186 182 minecraft:smooth_stone
setblock 258 186 222 minecraft:smooth_stone
setblock 262 186 182 minecraft:smooth_stone
setblock 268 186 222 minecraft:smooth_stone
setblock 272 186 182 minecraft:smooth_stone
setblock 276 186 188 minecraft:smooth_stone
setblock 276 186 198 minecraft:smooth_stone
setblock 276 186 208 minecraft:smooth_stone
setblock 276 186 218 minecraft:smooth_stone
setblock 238 187 184 minecraft:light[level=13]
setblock 238 187 192 minecraft:light[level=13]
setblock 238 187 200 minecraft:light[level=13]
setblock 238 187 208 minecraft:light[level=13]
setblock 238 187 216 minecraft:light[level=13]
setblock 246 187 184 minecraft:light[level=13]
setblock 246 187 192 minecraft:light[level=13]
setblock 246 187 200 minecraft:light[level=13]
setblock 246 187 208 minecraft:light[level=13]
setblock 246 187 216 minecraft:light[level=13]
setblock 254 187 184 minecraft:light[level=13]
setblock 254 187 192 minecraft:light[level=13]
setblock 254 187 200 minecraft:light[level=13]
setblock 254 187 208 minecraft:light[level=13]
setblock 254 187 216 minecraft:light[level=13]
setblock 262 187 184 minecraft:light[level=13]
setblock 262 187 192 minecraft:light[level=13]
setblock 262 187 200 minecraft:light[level=13]
setblock 262 187 208 minecraft:light[level=13]
setblock 262 187 216 minecraft:light[level=13]
setblock 270 187 184 minecraft:light[level=13]
setblock 270 187 192 minecraft:light[level=13]
setblock 270 187 200 minecraft:light[level=13]
setblock 270 187 208 minecraft:light[level=13]
setblock 270 187 216 minecraft:light[level=13]
setblock 266 188 217 minecraft:smooth_stone
setblock 266 188 219 minecraft:smooth_stone
setblock 268 188 217 minecraft:smooth_stone
setblock 268 188 219 minecraft:smooth_stone
fill 235 189 181 235 190 181 minecraft:polished_andesite
fill 235 189 193 235 192 194 minecraft:andesite
setblock 235 189 195 minecraft:polished_andesite
fill 235 189 196 235 192 196 minecraft:andesite
fill 235 189 217 235 190 217 minecraft:andesite
setblock 235 189 218 minecraft:polished_andesite
fill 235 189 219 235 192 220 minecraft:andesite
fill 236 189 186 236 189 189 minecraft:smooth_stone
fill 236 189 196 236 189 199 minecraft:smooth_stone
fill 236 189 206 236 189 209 minecraft:smooth_stone
fill 236 189 216 236 189 219 minecraft:smooth_stone
fill 237 189 182 240 189 182 minecraft:smooth_stone
fill 238 189 181 238 192 181 minecraft:andesite
setblock 239 189 181 minecraft:polished_andesite
fill 240 189 181 241 192 181 minecraft:andesite
fill 240 189 222 243 189 222 minecraft:smooth_stone
setblock 243 189 223 minecraft:polished_andesite
fill 244 189 223 245 190 223 minecraft:andesite
setblock 246 189 181 minecraft:polished_andesite
fill 247 189 181 249 190 181 minecraft:andesite
fill 247 189 182 250 189 182 minecraft:smooth_stone
setblock 250 189 181 minecraft:polished_andesite
fill 250 189 222 253 189 222 minecraft:smooth_stone
fill 251 189 181 251 190 181 minecraft:andesite
fill 257 189 182 260 189 182 minecraft:smooth_stone
fill 260 189 222 263 189 222 minecraft:smooth_stone
fill 267 189 182 270 189 182 minecraft:smooth_stone
fill 268 189 181 268 190 181 minecraft:polished_andesite
fill 269 189 181 271 192 181 minecraft:andesite
fill 269 189 223 271 190 223 minecraft:andesite
fill 270 189 222 273 189 222 minecraft:smooth_stone
setblock 272 189 223 minecraft:polished_andesite
fill 276 189 183 276 189 186 minecraft:smooth_stone
fill 276 189 193 276 189 196 minecraft:smooth_stone
fill 276 189 203 276 189 206 minecraft:smooth_stone
fill 276 189 213 276 189 216 minecraft:smooth_stone
setblock 277 189 191 minecraft:polished_andesite
fill 277 189 196 277 192 196 minecraft:andesite
setblock 277 189 197 minecraft:polished_andesite
fill 277 189 198 277 192 198 minecraft:andesite
setblock 277 189 202 minecraft:polished_andesite
fill 277 189 203 277 189 206 minecraft:andesite
setblock 277 189 207 minecraft:polished_andesite
fill 277 189 208 277 190 211 minecraft:andesite
setblock 277 189 217 minecraft:polished_andesite
fill 277 189 218 277 190 219 minecraft:andesite
setblock 277 189 220 minecraft:polished_andesite
setblock 277 189 222 minecraft:polished_andesite
setblock 235 190 183 minecraft:polished_andesite
fill 235 190 184 235 193 184 minecraft:andesite
fill 235 190 187 235 190 188 minecraft:andesite
setblock 235 190 189 minecraft:polished_andesite
setblock 235 190 190 minecraft:andesite
fill 235 190 195 235 192 195 minecraft:andesite
fill 235 190 197 235 192 197 minecraft:andesite
setblock 235 190 198 minecraft:polished_andesite
fill 235 190 199 235 192 200 minecraft:andesite
fill 235 190 201 235 190 202 minecraft:polished_andesite
setblock 235 190 207 minecraft:polished_andesite
fill 235 190 208 235 192 210 minecraft:andesite
fill 235 190 218 235 192 218 minecraft:andesite
fill 239 190 181 239 192 181 minecraft:andesite
fill 243 190 223 243 192 223 minecraft:andesite
setblock 245 190 181 minecraft:polished_andesite
fill 246 190 181 246 192 181 minecraft:andesite
setblock 249 190 223 minecraft:polished_andesite
fill 250 190 181 250 192 181 minecraft:andesite
fill 250 190 223 252 190 223 minecraft:andesite
setblock 252 190 181 minecraft:polished_andesite
fill 253 190 181 255 192 181 minecraft:andesite
fill 253 190 223 253 191 223 minecraft:polished_andesite
fill 254 190 223 256 192 223 minecraft:andesite
setblock 256 190 181 minecraft:polished_andesite
fill 257 190 181 257 192 181 minecraft:andesite
setblock 257 190 223 minecraft:polished_andesite
fill 258 190 223 258 192 223 minecraft:andesite
fill 259 190 223 259 191 223 minecraft:polished_andesite
fill 260 190 223 261 192 223 minecraft:andesite
setblock 262 190 223 minecraft:polished_andesite
fill 272 190 223 276 192 223 minecraft:andesite
fill 277 190 182 277 192 184 minecraft:andesite
setblock 277 190 185 minecraft:polished_andesite
fill 277 190 191 277 192 193 minecraft:andesite
setblock 277 190 194 minecraft:polished_andesite
fill 277 190 195 277 192 195 minecraft:andesite
fill 277 190 197 277 192 197 minecraft:andesite
fill 277 190 202 277 192 203 minecraft:andesite
setblock 277 190 204 minecraft:polished_andesite
fill 277 190 205 277 192 207 minecraft:andesite
setblock 277 190 212 minecraft:polished_andesite
fill 277 190 213 277 192 215 minecraft:andesite
setblock 277 190 217 minecraft:andesite
fill 277 190 220 277 192 220 minecraft:andesite
setblock 277 190 221 minecraft:polished_andesite
fill 277 190 222 277 192 222 minecraft:andesite
setblock 277 190 223 minecraft:polished_andesite
fill 235 191 181 235 192 181 minecraft:andesite
fill 235 191 183 235 192 183 minecraft:andesite
fill 235 191 187 235 192 187 minecraft:andesite
setblock 235 191 188 minecraft:polished_andesite
fill 235 191 189 235 192 189 minecraft:andesite
setblock 235 191 190 minecraft:polished_andesite
fill 235 191 198 235 192 198 minecraft:andesite
fill 235 191 201 235 192 201 minecraft:andesite
setblock 235 191 202 minecraft:polished_andesite
fill 235 191 207 235 192 207 minecraft:andesite
setblock 235 191 217 minecraft:polished_andesite
fill 235 191 221 235 191 222 minecraft:polished_andesite
fill 239 191 223 240 192 223 minecraft:andesite
setblock 241 191 223 minecraft:polished_andesite
fill 242 191 181 243 192 181 minecraft:andesite
fill 242 191 223 242 192 223 minecraft:andesite
setblock 244 191 181 minecraft:polished_andesite
fill 244 191 223 244 192 223 minecraft:andesite
fill 245 191 181 245 192 181 minecraft:andesite
setblock 245 191 223 minecraft:polished_andesite
fill 247 191 181 248 192 181 minecraft:andesite
setblock 249 191 181 minecraft:polished_andesite
fill 249 191 223 250 192 223 minecraft:andesite
setblock 251 191 181 minecraft:polished_andesite
setblock 251 191 223 minecraft:polished_andesite
fill 252 191 181 252 192 181 minecraft:andesite
fill 252 191 223 252 192 223 minecraft:andesite
fill 256 191 181 256 192 181 minecraft:andesite
fill 257 191 223 257 192 223 minecraft:andesite
setblock 258 191 181 minecraft:polished_andesite
fill 259 191 181 259 192 181 minecraft:andesite
setblock 260 191 181 minecraft:polished_andesite
fill 261 191 181 261 192 181 minecraft:andesite
fill 262 191 223 262 192 223 minecraft:andesite
fill 268 191 181 268 192 181 minecraft:andesite
setblock 269 191 223 minecraft:polished_andesite
fill 270 191 223 270 192 223 minecraft:andesite
setblock 271 191 223 minecraft:polished_andesite
setblock 277 191 181 minecraft:polished_andesite
fill 277 191 185 277 192 185 minecraft:andesite
fill 277 191 194 277 192 194 minecraft:andesite
fill 277 191 204 277 192 204 minecraft:andesite
fill 277 191 208 277 192 209 minecraft:andesite
setblock 277 191 210 minecraft:polished_andesite
fill 277 191 211 277 192 212 minecraft:andesite
setblock 277 191 217 minecraft:polished_andesite
fill 277 191 218 277 192 218 minecraft:andesite
setblock 277 191 219 minecraft:polished_andesite
fill 277 191 221 277 192 221 minecraft:andesite
fill 277 191 223 277 192 223 minecraft:andesite
setblock 235 192 188 minecraft:andesite
setblock 235 192 190 minecraft:andesite
setblock 235 192 202 minecraft:andesite
setblock 235 192 217 minecraft:andesite
fill 235 192 221 235 192 222 minecraft:andesite
setblock 236 192 184 minecraft:smooth_stone
setblock 236 192 194 minecraft:smooth_stone
setblock 236 192 204 minecraft:smooth_stone
setblock 236 192 214 minecraft:smooth_stone
setblock 238 192 222 minecraft:smooth_stone
setblock 241 192 223 minecraft:andesite
setblock 242 192 182 minecraft:smooth_stone
setblock 244 192 181 minecraft:andesite
setblock 245 192 223 minecraft:andesite
setblock 248 192 222 minecraft:smooth_stone
setblock 249 192 181 minecraft:andesite
setblock 251 192 181 minecraft:andesite
setblock 251 192 223 minecraft:andesite
setblock 252 192 182 minecraft:smooth_stone
setblock 253 192 223 minecraft:andesite
setblock 258 192 181 minecraft:andesite
setblock 258 192 222 minecraft:smooth_stone
setblock 259 192 223 minecraft:andesite
setblock 260 192 181 minecraft:andesite
setblock 262 192 182 minecraft:smooth_stone
setblock 268 192 222 minecraft:smooth_stone
setblock 269 192 223 minecraft:andesite
setblock 271 192 223 minecraft:andesite
setblock 272 192 182 minecraft:smooth_stone
setblock 276 192 188 minecraft:smooth_stone
setblock 276 192 198 minecraft:smooth_stone
setblock 276 192 208 minecraft:smooth_stone
setblock 276 192 218 minecraft:smooth_stone
setblock 277 192 181 minecraft:andesite
setblock 277 192 210 minecraft:andesite
setblock 277 192 217 minecraft:andesite
setblock 277 192 219 minecraft:andesite
fill 235 193 181 235 194 183 minecraft:polished_andesite
fill 235 193 185 235 307 185 minecraft:polished_andesite
fill 235 193 187 235 193 190 minecraft:ochre_froglight
fill 235 193 191 235 193 196 minecraft:polished_andesite
fill 235 193 197 235 193 200 minecraft:ochre_froglight
fill 235 193 201 235 307 202 minecraft:polished_andesite
fill 235 193 204 235 193 206 minecraft:polished_andesite
fill 235 193 207 235 193 210 minecraft:ochre_froglight
fill 235 193 211 235 194 215 minecraft:polished_andesite
fill 235 193 216 235 194 216 minecraft:andesite
fill 235 193 217 235 193 220 minecraft:ochre_froglight
fill 235 193 221 235 194 223 minecraft:polished_andesite
fill 236 193 181 237 307 181 minecraft:polished_andesite
fill 236 193 223 238 193 223 minecraft:polished_andesite
fill 238 193 181 241 193 181 minecraft:ochre_froglight
fill 239 193 223 242 193 223 minecraft:ochre_froglight
fill 242 193 181 247 307 181 minecraft:polished_andesite
fill 243 193 223 247 193 223 minecraft:polished_andesite
fill 248 193 181 251 193 181 minecraft:ochre_froglight
fill 249 193 223 252 193 223 minecraft:ochre_froglight
fill 252 193 181 257 307 181 minecraft:polished_andesite
fill 253 193 223 255 307 223 minecraft:polished_andesite
setblock 256 193 223 minecraft:andesite
fill 257 193 223 258 307 223 minecraft:polished_andesite
fill 258 193 181 261 193 181 minecraft:ochre_froglight
fill 259 193 223 262 193 223 minecraft:ochre_froglight
fill 262 193 181 267 194 181 minecraft:polished_andesite
fill 263 193 223 268 193 223 minecraft:polished_andesite
fill 268 193 181 271 193 181 minecraft:ochre_froglight
fill 269 193 223 272 193 223 minecraft:ochre_froglight
fill 272 193 181 277 307 181 minecraft:polished_andesite
fill 273 193 223 274 193 223 minecraft:andesite
fill 275 193 223 277 307 223 minecraft:polished_andesite
fill 277 193 182 277 193 185 minecraft:ochre_froglight
fill 277 193 186 277 307 191 minecraft:polished_andesite
fill 277 193 192 277 193 195 minecraft:ochre_froglight
fill 277 193 196 277 307 200 minecraft:polished_andesite
setblock 277 193 201 minecraft:andesite
fill 277 193 202 277 193 205 minecraft:ochre_froglight
fill 277 193 206 277 307 211 minecraft:polished_andesite
fill 277 193 212 277 193 215 minecraft:ochre_froglight
fill 277 193 216 277 194 221 minecraft:polished_andesite
setblock 277 193 222 minecraft:ochre_froglight
fill 235 194 184 235 307 184 minecraft:polished_andesite
fill 235 194 186 235 194 190 minecraft:polished_andesite
setblock 235 194 191 minecraft:andesite
fill 235 194 192 235 307 193 minecraft:polished_andesite
setblock 235 194 194 minecraft:andesite
fill 235 194 195 235 194 200 minecraft:polished_andesite
fill 235 194 204 235 307 205 minecraft:polished_andesite
setblock 235 194 206 minecraft:andesite
fill 235 194 207 235 201 207 minecraft:polished_andesite
fill 235 194 208 235 194 209 minecraft:andesite
fill 235 194 210 235 201 210 minecraft:polished_andesite
fill 235 194 217 235 201 217 minecraft:polished_andesite
setblock 235 194 218 minecraft:andesite
fill 235 194 219 235 194 220 minecraft:polished_andesite
setblock 236 194 223 minecraft:andesite
fill 237 194 223 239 194 223 minecraft:polished_andesite
fill 238 194 181 241 201 181 minecraft:polished_andesite
fill 240 194 223 240 195 223 minecraft:andesite
fill 241 194 223 245 201 223 minecraft:polished_andesite
setblock 246 194 223 minecraft:andesite
fill 247 194 223 251 201 223 minecraft:polished_andesite
fill 248 194 181 250 201 181 minecraft:polished_andesite
setblock 251 194 181 minecraft:andesite
setblock 252 194 223 minecraft:andesite
setblock 256 194 223 minecraft:polished_andesite
fill 258 194 181 261 194 181 minecraft:polished_andesite
fill 259 194 223 267 194 223 minecraft:polished_andesite
setblock 266 194 217 minecraft:smooth_stone
setblock 266 194 219 minecraft:smooth_stone
fill 268 194 181 271 201 181 minecraft:polished_andesite
setblock 268 194 217 minecraft:smooth_stone
setblock 268 194 219 minecraft:smooth_stone
setblock 268 194 223 minecraft:andesite
fill 269 194 223 269 201 223 minecraft:polished_andesite
setblock 270 194 223 minecraft:andesite
fill 271 194 223 274 194 223 minecraft:polished_andesite
fill 277 194 182 277 194 185 minecraft:polished_andesite
fill 277 194 192 277 201 195 minecraft:polished_andesite
fill 277 194 201 277 201 205 minecraft:polished_andesite
setblock 277 194 212 minecraft:andesite
fill 277 194 213 277 194 215 minecraft:polished_andesite
fill 277 194 222 277 201 222 minecraft:polished_andesite
setblock 235 195 181 minecraft:andesite
fill 235 195 182 235 307 183 minecraft:polished_andesite
fill 235 195 186 235 201 188 minecraft:polished_andesite
setblock 235 195 189 minecraft:andesite
fill 235 195 190 235 201 191 minecraft:polished_andesite
fill 235 195 194 235 307 196 minecraft:polished_andesite
setblock 235 195 197 minecraft:andesite
fill 235 195 198 235 201 200 minecraft:polished_andesite
fill 235 195 203 235 307 203 minecraft:polished_andesite
fill 235 195 206 235 307 206 minecraft:polished_andesite
fill 235 195 208 235 201 209 minecraft:polished_andesite
fill 235 195 211 235 307 211 minecraft:polished_andesite
setblock 235 195 212 minecraft:andesite
fill 235 195 213 235 307 213 minecraft:polished_andesite
setblock 235 195 214 minecraft:andesite
fill 235 195 215 235 307 216 minecraft:polished_andesite
fill 235 195 218 235 201 218 minecraft:polished_andesite
setblock 235 195 219 minecraft:andesite
fill 235 195 220 235 201 222 minecraft:polished_andesite
setblock 235 195 223 minecraft:andesite
fill 236 195 223 238 307 223 minecraft:polished_andesite
setblock 238 195 184 minecraft:light[level=13]
setblock 238 195 192 minecraft:light[level=13]
setblock 238 195 200 minecraft:light[level=13]
setblock 238 195 208 minecraft:light[level=13]
setblock 238 195 216 minecraft:light[level=13]
setblock 239 195 223 minecraft:andesite
setblock 246 195 184 minecraft:light[level=13]
setblock 246 195 192 minecraft:light[level=13]
setblock 246 195 200 minecraft:light[level=13]
setblock 246 195 208 minecraft:light[level=13]
setblock 246 195 216 minecraft:light[level=13]
fill 246 195 223 246 307 223 minecraft:polished_andesite
fill 251 195 181 251 201 181 minecraft:polished_andesite
fill 252 195 223 252 201 223 minecraft:polished_andesite
setblock 254 195 184 minecraft:light[level=13]
setblock 254 195 192 minecraft:light[level=13]
setblock 254 195 200 minecraft:light[level=13]
setblock 254 195 208 minecraft:light[level=13]
setblock 254 195 216 minecraft:light[level=13]
setblock 256 195 223 minecraft:andesite
fill 258 195 181 258 201 181 minecraft:polished_andesite
setblock 259 195 181 minecraft:andesite
fill 259 195 223 260 201 223 minecraft:polished_andesite
fill 260 195 181 260 201 181 minecraft:polished_andesite
setblock 261 195 181 minecraft:andesite
setblock 261 195 223 minecraft:andesite
fill 262 195 181 264 307 181 minecraft:polished_andesite
setblock 262 195 184 minecraft:light[level=13]
setblock 262 195 192 minecraft:light[level=13]
setblock 262 195 200 minecraft:light[level=13]
setblock 262 195 208 minecraft:light[level=13]
setblock 262 195 216 minecraft:light[level=13]
fill 262 195 223 268 201 223 minecraft:polished_andesite
fill 265 195 181 266 195 181 minecraft:andesite
fill 267 195 181 267 307 181 minecraft:polished_andesite
setblock 270 195 184 minecraft:light[level=13]
setblock 270 195 192 minecraft:light[level=13]
setblock 270 195 200 minecraft:light[level=13]
setblock 270 195 208 minecraft:light[level=13]
setblock 270 195 216 minecraft:light[level=13]
fill 270 195 223 270 201 223 minecraft:polished_andesite
setblock 271 195 223 minecraft:andesite
fill 272 195 223 274 201 223 minecraft:polished_andesite
fill 277 195 182 277 201 182 minecraft:polished_andesite
setblock 277 195 183 minecraft:andesite
fill 277 195 184 277 201 185 minecraft:polished_andesite
fill 277 195 212 277 201 213 minecraft:polished_andesite
setblock 277 195 214 minecraft:andesite
fill 277 195 215 277 201 219 minecraft:polished_andesite
setblock 277 195 220 minecraft:andesite
fill 277 195 221 277 307 221 minecraft:polished_andesite
fill 235 196 181 235 307 181 minecraft:polished_andesite
fill 235 196 189 235 201 189 minecraft:polished_andesite
fill 235 196 197 235 201 197 minecraft:polished_andesite
fill 235 196 212 235 307 212 minecraft:polished_andesite
fill 235 196 214 235 307 214 minecraft:polished_andesite
fill 235 196 219 235 201 219 minecraft:polished_andesite
fill 235 196 223 235 307 223 minecraft:polished_andesite
fill 239 196 223 240 201 223 minecraft:polished_andesite
fill 256 196 223 256 307 223 minecraft:polished_andesite
fill 259 196 181 259 201 181 minecraft:polished_andesite
fill 261 196 181 261 201 181 minecraft:polished_andesite
fill 261 196 223 261 201 223 minecraft:polished_andesite
fill 265 196 181 266 307 181 minecraft:polished_andesite
fill 271 196 223 271 201 223 minecraft:polished_andesite
fill 277 196 183 277 201 183 minecraft:polished_andesite
fill 277 196 214 277 201 214 minecraft:polished_andesite
fill 277 196 220 277 307 220 minecraft:polished_andesite
setblock 236 198 184 minecraft:smooth_stone
fill 236 198 186 236 198 189 minecraft:smooth_stone
setblock 236 198 194 minecraft:smooth_stone
fill 236 198 196 236 198 199 minecraft:smooth_stone
setblock 236 198 204 minecraft:smooth_stone
fill 236 198 206 236 198 209 minecraft:smooth_stone
setblock 236 198 214 minecraft:smooth_stone
fill 236 198 216 236 198 219 minecraft:smooth_stone
fill 237 198 182 240 198 182 minecraft:smooth_stone
setblock 238 198 222 minecraft:smooth_stone
fill 240 198 222 243 198 222 minecraft:smooth_stone
setblock 242 198 182 minecraft:smooth_stone
fill 247 198 182 250 198 182 minecraft:smooth_stone
setblock 248 198 222 minecraft:smooth_stone
fill 250 198 222 253 198 222 minecraft:smooth_stone
setblock 252 198 182 minecraft:smooth_stone
fill 257 198 182 260 198 182 minecraft:smooth_stone
setblock 258 198 222 minecraft:smooth_stone
fill 260 198 222 263 198 222 minecraft:smooth_stone
setblock 262 198 182 minecraft:smooth_stone
fill 267 198 182 270 198 182 minecraft:smooth_stone
setblock 268 198 222 minecraft:smooth_stone
fill 270 198 222 273 198 222 minecraft:smooth_stone
setblock 272 198 182 minecraft:smooth_stone
fill 276 198 183 276 198 186 minecraft:smooth_stone
setblock 276 198 188 minecraft:smooth_stone
fill 276 198 193 276 198 196 minecraft:smooth_stone
setblock 276 198 198 minecraft:smooth_stone
fill 276 198 203 276 198 206 minecraft:smooth_stone
setblock 276 198 208 minecraft:smooth_stone
fill 276 198 213 276 198 216 minecraft:smooth_stone
setblock 276 198 218 minecraft:smooth_stone
setblock 266 200 217 minecraft:smooth_stone
setblock 266 200 219 minecraft:smooth_stone
setblock 268 200 217 minecraft:smooth_stone
setblock 268 200 219 minecraft:smooth_stone
fill 235 202 186 235 307 186 minecraft:polished_andesite
fill 235 202 187 235 202 190 minecraft:ochre_froglight
fill 235 202 191 235 307 191 minecraft:polished_andesite
fill 235 202 197 235 202 200 minecraft:ochre_froglight
fill 235 202 207 235 202 210 minecraft:ochre_froglight
fill 235 202 217 235 202 220 minecraft:ochre_froglight
fill 235 202 221 235 307 222 minecraft:polished_andesite
fill 238 202 181 241 202 181 minecraft:ochre_froglight
fill 239 202 223 242 202 223 minecraft:ochre_froglight
fill 243 202 223 245 307 223 minecraft:polished_andesite
fill 247 202 223 248 307 223 minecraft:polished_andesite
fill 248 202 181 251 202 181 minecraft:ochre_froglight
fill 249 202 223 252 202 223 minecraft:ochre_froglight
fill 258 202 181 261 202 181 minecraft:ochre_froglight
fill 259 202 223 262 202 223 minecraft:ochre_froglight
fill 263 202 223 268 307 223 minecraft:polished_andesite
fill 268 202 181 271 202 181 minecraft:ochre_froglight
fill 269 202 223 272 202 223 minecraft:ochre_froglight
fill 273 202 223 274 307 223 minecraft:polished_andesite
fill 277 202 182 277 202 185 minecraft:ochre_froglight
fill 277 202 192 277 202 195 minecraft:ochre_froglight
fill 277 202 201 277 307 201 minecraft:polished_andesite
fill 277 202 202 277 202 205 minecraft:ochre_froglight
fill 277 202 212 277 202 215 minecraft:ochre_froglight
fill 277 202 216 277 307 219 minecraft:polished_andesite
setblock 277 202 222 minecraft:ochre_froglight
fill 235 203 187 235 210 190 minecraft:polished_andesite
fill 235 203 197 235 210 200 minecraft:polished_andesite
fill 235 203 207 235 210 210 minecraft:polished_andesite
fill 235 203 217 235 210 220 minecraft:polished_andesite
fill 238 203 181 241 210 181 minecraft:polished_andesite
setblock 238 203 184 minecraft:light[level=13]
setblock 238 203 192 minecraft:light[level=13]
setblock 238 203 200 minecraft:light[level=13]
setblock 238 203 208 minecraft:light[level=13]
setblock 238 203 216 minecraft:light[level=13]
fill 239 203 223 242 210 223 minecraft:polished_andesite
setblock 246 203 184 minecraft:light[level=13]
setblock 246 203 192 minecraft:light[level=13]
setblock 246 203 200 minecraft:light[level=13]
setblock 246 203 208 minecraft:light[level=13]
setblock 246 203 216 minecraft:light[level=13]
fill 248 203 181 251 210 181 minecraft:polished_andesite
fill 249 203 223 252 210 223 minecraft:polished_andesite
setblock 254 203 184 minecraft:light[level=13]
setblock 254 203 192 minecraft:light[level=13]
setblock 254 203 200 minecraft:light[level=13]
setblock 254 203 208 minecraft:light[level=13]
setblock 254 203 216 minecraft:light[level=13]
fill 258 203 181 261 210 181 minecraft:polished_andesite
fill 259 203 223 262 210 223 minecraft:polished_andesite
setblock 262 203 184 minecraft:light[level=13]
setblock 262 203 192 minecraft:light[level=13]
setblock 262 203 200 minecraft:light[level=13]
setblock 262 203 208 minecraft:light[level=13]
setblock 262 203 216 minecraft:light[level=13]
fill 268 203 181 271 210 181 minecraft:polished_andesite
fill 269 203 223 272 210 223 minecraft:polished_andesite
setblock 270 203 184 minecraft:light[level=13]
setblock 270 203 192 minecraft:light[level=13]
setblock 270 203 200 minecraft:light[level=13]
setblock 270 203 208 minecraft:light[level=13]
setblock 270 203 216 minecraft:light[level=13]
fill 277 203 182 277 210 185 minecraft:polished_andesite
fill 277 203 192 277 210 195 minecraft:polished_andesite
fill 277 203 202 277 210 205 minecraft:polished_andesite
fill 277 203 212 277 210 215 minecraft:polished_andesite
fill 277 203 222 277 210 222 minecraft:polished_andesite
setblock 236 204 184 minecraft:smooth_stone
setblock 236 204 194 minecraft:smooth_stone
setblock 236 204 204 minecraft:smooth_stone
setblock 236 204 214 minecraft:smooth_stone
setblock 238 204 222 minecraft:smooth_stone
setblock 242 204 182 minecraft:smooth_stone
setblock 248 204 222 minecraft:smooth_stone
setblock 252 204 182 minecraft:smooth_stone
setblock 258 204 222 minecraft:smooth_stone
setblock 262 204 182 minecraft:smooth_stone
setblock 268 204 222 minecraft:smooth_stone
setblock 272 204 182 minecraft:smooth_stone
setblock 276 204 188 minecraft:smooth_stone
setblock 276 204 198 minecraft:smooth_stone
setblock 276 204 208 minecraft:smooth_stone
setblock 276 204 218 minecraft:smooth_stone
setblock 266 206 217 minecraft:smooth_stone
setblock 266 206 219 minecraft:smooth_stone
setblock 268 206 217 minecraft:smooth_stone
setblock 268 206 219 minecraft:smooth_stone
fill 236 207 186 236 207 189 minecraft:smooth_stone
fill 236 207 196 236 207 199 minecraft:smooth_stone
fill 236 207 206 236 207 209 minecraft:smooth_stone
fill 236 207 216 236 207 219 minecraft:smooth_stone
fill 237 207 182 240 207 182 minecraft:smooth_stone
fill 240 207 222 243 207 222 minecraft:smooth_stone
fill 247 207 182 250 207 182 minecraft:smooth_stone
fill 250 207 222 253 207 222 minecraft:smooth_stone
fill 257 207 182 260 207 182 minecraft:smooth_stone
fill 260 207 222 263 207 222 minecraft:smooth_stone
fill 267 207 182 270 207 182 minecraft:smooth_stone
fill 270 207 222 273 207 222 minecraft:smooth_stone
fill 276 207 183 276 207 186 minecraft:smooth_stone
fill 276 207 193 276 207 196 minecraft:smooth_stone
fill 276 207 203 276 207 206 minecraft:smooth_stone
fill 276 207 213 276 207 216 minecraft:smooth_stone
setblock 236 210 184 minecraft:smooth_stone
setblock 236 210 194 minecraft:smooth_stone
setblock 236 210 204 minecraft:smooth_stone
setblock 236 210 214 minecraft:smooth_stone
setblock 238 210 222 minecraft:smooth_stone
setblock 242 210 182 minecraft:smooth_stone
setblock 248 210 222 minecraft:smooth_stone
setblock 252 210 182 minecraft:smooth_stone
setblock 258 210 222 minecraft:smooth_stone
setblock 262 210 182 minecraft:smooth_stone
setblock 268 210 222 minecraft:smooth_stone
setblock 272 210 182 minecraft:smooth_stone
setblock 276 210 188 minecraft:smooth_stone
setblock 276 210 198 minecraft:smooth_stone
setblock 276 210 208 minecraft:smooth_stone
setblock 276 210 218 minecraft:smooth_stone
fill 235 211 187 235 211 190 minecraft:ochre_froglight
fill 235 211 197 235 211 200 minecraft:ochre_froglight
fill 235 211 207 235 211 210 minecraft:ochre_froglight
fill 235 211 217 235 211 220 minecraft:ochre_froglight
fill 238 211 181 241 211 181 minecraft:ochre_froglight
setblock 238 211 184 minecraft:light[level=13]
setblock 238 211 192 minecraft:light[level=13]
setblock 238 211 200 minecraft:light[level=13]
setblock 238 211 208 minecraft:light[level=13]
setblock 238 211 216 minecraft:light[level=13]
fill 239 211 223 242 211 223 minecraft:ochre_froglight
setblock 246 211 184 minecraft:light[level=13]
setblock 246 211 192 minecraft:light[level=13]
setblock 246 211 200 minecraft:light[level=13]
setblock 246 211 208 minecraft:light[level=13]
setblock 246 211 216 minecraft:light[level=13]
fill 248 211 181 251 211 181 minecraft:ochre_froglight
fill 249 211 223 252 211 223 minecraft:ochre_froglight
setblock 254 211 184 minecraft:light[level=13]
setblock 254 211 192 minecraft:light[level=13]
setblock 254 211 200 minecraft:light[level=13]
setblock 254 211 208 minecraft:light[level=13]
setblock 254 211 216 minecraft:light[level=13]
fill 258 211 181 261 211 181 minecraft:ochre_froglight
fill 259 211 223 262 211 223 minecraft:ochre_froglight
setblock 262 211 184 minecraft:light[level=13]
setblock 262 211 192 minecraft:light[level=13]
setblock 262 211 200 minecraft:light[level=13]
setblock 262 211 208 minecraft:light[level=13]
setblock 262 211 216 minecraft:light[level=13]
fill 268 211 181 271 211 181 minecraft:ochre_froglight
fill 269 211 223 272 211 223 minecraft:ochre_froglight
setblock 270 211 184 minecraft:light[level=13]
setblock 270 211 192 minecraft:light[level=13]
setblock 270 211 200 minecraft:light[level=13]
setblock 270 211 208 minecraft:light[level=13]
setblock 270 211 216 minecraft:light[level=13]
fill 277 211 182 277 211 185 minecraft:ochre_froglight
fill 277 211 192 277 211 195 minecraft:ochre_froglight
fill 277 211 202 277 211 205 minecraft:ochre_froglight
fill 277 211 212 277 211 215 minecraft:ochre_froglight
setblock 277 211 222 minecraft:ochre_froglight
fill 235 212 187 235 228 190 minecraft:polished_andesite
fill 235 212 197 235 228 200 minecraft:polished_andesite
fill 235 212 207 235 228 210 minecraft:polished_andesite
fill 235 212 217 235 228 220 minecraft:polished_andesite
fill 238 212 181 241 228 181 minecraft:polished_andesite
fill 239 212 223 242 228 223 minecraft:polished_andesite
fill 248 212 181 251 228 181 minecraft:polished_andesite
fill 249 212 223 252 228 223 minecraft:polished_andesite
fill 258 212 181 261 228 181 minecraft:polished_andesite
fill 259 212 223 262 228 223 minecraft:polished_andesite
fill 268 212 181 271 228 181 minecraft:polished_andesite
fill 269 212 223 272 228 223 minecraft:polished_andesite
fill 277 212 182 277 228 185 minecraft:polished_andesite
fill 277 212 192 277 228 195 minecraft:polished_andesite
fill 277 212 202 277 228 205 minecraft:polished_andesite
fill 277 212 212 277 228 215 minecraft:polished_andesite
fill 277 212 222 277 228 222 minecraft:polished_andesite
fill 236 217 182 251 217 222 minecraft:smooth_stone
fill 252 217 182 252 217 204 minecraft:smooth_stone
fill 252 217 206 252 217 222 minecraft:smooth_stone
fill 253 217 182 254 217 202 minecraft:smooth_stone
fill 253 217 208 254 217 222 minecraft:smooth_stone
fill 255 217 182 276 217 201 minecraft:smooth_stone
fill 255 217 209 276 217 222 minecraft:smooth_stone
fill 256 217 202 276 217 202 minecraft:smooth_stone
fill 256 217 208 276 217 208 minecraft:smooth_stone
fill 258 217 203 276 217 204 minecraft:smooth_stone
fill 258 217 206 276 217 207 minecraft:smooth_stone
fill 259 217 205 276 217 205 minecraft:smooth_stone
fill 236 218 182 236 218 183 minecraft:smooth_stone
fill 236 218 184 276 218 184 minecraft:redstone_block
fill 236 218 185 276 218 186 minecraft:smooth_stone
fill 236 218 187 276 218 187 minecraft:redstone_block
fill 236 218 188 236 218 189 minecraft:smooth_stone
fill 236 218 190 276 218 190 minecraft:redstone_block
fill 236 218 191 276 218 192 minecraft:smooth_stone
fill 236 218 193 276 218 193 minecraft:redstone_block
fill 236 218 194 236 218 195 minecraft:smooth_stone
fill 236 218 196 276 218 196 minecraft:redstone_block
fill 236 218 197 276 218 198 minecraft:smooth_stone
fill 236 218 199 276 218 199 minecraft:redstone_block
fill 236 218 200 236 218 201 minecraft:smooth_stone
fill 236 218 202 251 218 202 minecraft:redstone_block
fill 236 218 203 250 218 204 minecraft:smooth_stone
fill 236 218 205 250 218 205 minecraft:redstone_block
fill 236 218 206 236 218 207 minecraft:smooth_stone
fill 236 218 208 251 218 208 minecraft:redstone_block
fill 236 218 209 253 218 210 minecraft:smooth_stone
fill 236 218 211 276 218 211 minecraft:redstone_block
fill 236 218 212 236 218 213 minecraft:smooth_stone
fill 236 218 214 276 218 214 minecraft:redstone_block
fill 236 218 215 276 218 216 minecraft:smooth_stone
fill 236 218 217 276 218 217 minecraft:redstone_block
fill 236 218 218 236 218 219 minecraft:smooth_stone
fill 236 218 220 276 218 220 minecraft:redstone_block
fill 236 218 221 276 218 222 minecraft:smooth_stone
fill 237 218 182 237 218 183 minecraft:redstone_block
fill 237 218 188 237 218 189 minecraft:redstone_block
fill 237 218 194 237 218 195 minecraft:redstone_block
fill 237 218 200 237 218 201 minecraft:redstone_block
fill 237 218 206 237 218 207 minecraft:redstone_block
fill 237 218 212 237 218 213 minecraft:redstone_block
fill 237 218 218 237 218 219 minecraft:redstone_block
fill 238 218 182 239 218 183 minecraft:smooth_stone
fill 238 218 188 239 218 189 minecraft:smooth_stone
fill 238 218 194 239 218 195 minecraft:smooth_stone
fill 238 218 200 239 218 201 minecraft:smooth_stone
fill 238 218 206 239 218 207 minecraft:smooth_stone
fill 238 218 212 239 218 213 minecraft:smooth_stone
fill 238 218 218 239 218 219 minecraft:smooth_stone
fill 240 218 182 240 218 183 minecraft:redstone_block
fill 240 218 188 240 218 189 minecraft:redstone_block
fill 240 218 194 240 218 195 minecraft:redstone_block
fill 240 218 200 240 218 201 minecraft:redstone_block
fill 240 218 206 240 218 207 minecraft:redstone_block
fill 240 218 212 240 218 213 minecraft:redstone_block
fill 240 218 218 240 218 219 minecraft:redstone_block
fill 241 218 182 242 218 183 minecraft:smooth_stone
fill 241 218 188 242 218 189 minecraft:smooth_stone
fill 241 218 194 242 218 195 minecraft:smooth_stone
fill 241 218 200 242 218 201 minecraft:smooth_stone
fill 241 218 206 242 218 207 minecraft:smooth_stone
fill 241 218 212 242 218 213 minecraft:smooth_stone
fill 241 218 218 242 218 219 minecraft:smooth_stone
fill 243 218 182 243 218 183 minecraft:redstone_block
fill 243 218 188 243 218 189 minecraft:redstone_block
fill 243 218 194 243 218 195 minecraft:redstone_block
fill 243 218 200 243 218 201 minecraft:redstone_block
fill 243 218 206 243 218 207 minecraft:redstone_block
fill 243 218 212 243 218 213 minecraft:redstone_block
fill 243 218 218 243 218 219 minecraft:redstone_block
fill 244 218 182 245 218 183 minecraft:smooth_stone
fill 244 218 188 245 218 189 minecraft:smooth_stone
fill 244 218 194 245 218 195 minecraft:smooth_stone
fill 244 218 200 245 218 201 minecraft:smooth_stone
fill 244 218 206 245 218 207 minecraft:smooth_stone
fill 244 218 212 245 218 213 minecraft:smooth_stone
fill 244 218 218 245 218 219 minecraft:smooth_stone
fill 246 218 182 246 218 183 minecraft:redstone_block
fill 246 218 188 246 218 189 minecraft:redstone_block
fill 246 218 194 246 218 195 minecraft:redstone_block
fill 246 218 200 246 218 201 minecraft:redstone_block
fill 246 218 206 246 218 207 minecraft:redstone_block
fill 246 218 212 246 218 213 minecraft:redstone_block
fill 246 218 218 246 218 219 minecraft:redstone_block
fill 247 218 182 248 218 183 minecraft:smooth_stone
fill 247 218 188 248 218 189 minecraft:smooth_stone
fill 247 218 194 248 218 195 minecraft:smooth_stone
fill 247 218 200 248 218 201 minecraft:smooth_stone
fill 247 218 206 248 218 207 minecraft:smooth_stone
fill 247 218 212 248 218 213 minecraft:smooth_stone
fill 247 218 218 248 218 219 minecraft:smooth_stone
fill 249 218 182 249 218 183 minecraft:redstone_block
fill 249 218 188 249 218 189 minecraft:redstone_block
fill 249 218 194 249 218 195 minecraft:redstone_block
fill 249 218 200 249 218 201 minecraft:redstone_block
fill 249 218 206 249 218 207 minecraft:redstone_block
fill 249 218 212 249 218 213 minecraft:redstone_block
fill 249 218 218 249 218 219 minecraft:redstone_block
fill 250 218 182 251 218 183 minecraft:smooth_stone
fill 250 218 188 251 218 189 minecraft:smooth_stone
fill 250 218 194 251 218 195 minecraft:smooth_stone
fill 250 218 200 251 218 201 minecraft:smooth_stone
fill 250 218 206 250 218 207 minecraft:smooth_stone
fill 250 218 212 251 218 213 minecraft:smooth_stone
fill 250 218 218 251 218 219 minecraft:smooth_stone
setblock 251 218 203 minecraft:smooth_stone
fill 251 218 204 251 218 206 minecraft:ochre_froglight
setblock 251 218 207 minecraft:smooth_stone
fill 252 218 182 252 218 183 minecraft:redstone_block
fill 252 218 188 252 218 189 minecraft:redstone_block
fill 252 218 194 252 218 195 minecraft:redstone_block
fill 252 218 200 252 218 201 minecraft:redstone_block
fill 252 218 202 252 218 204 minecraft:ochre_froglight
fill 252 218 206 252 218 208 minecraft:ochre_froglight
fill 252 218 212 252 218 213 minecraft:redstone_block
fill 252 218 218 252 218 219 minecraft:redstone_block
fill 253 218 182 254 218 183 minecraft:smooth_stone
fill 253 218 188 254 218 189 minecraft:smooth_stone
fill 253 218 194 254 218 195 minecraft:smooth_stone
fill 253 218 200 253 218 201 minecraft:smooth_stone
fill 253 218 202 254 218 202 minecraft:ochre_froglight
fill 253 218 208 254 218 208 minecraft:ochre_froglight
fill 253 218 212 254 218 213 minecraft:smooth_stone
fill 253 218 218 254 218 219 minecraft:smooth_stone
setblock 254 218 200 minecraft:smooth_stone
fill 254 218 201 256 218 201 minecraft:ochre_froglight
fill 254 218 209 256 218 209 minecraft:ochre_froglight
fill 254 218 210 276 218 210 minecraft:smooth_stone
fill 255 218 182 255 218 183 minecraft:redstone_block
fill 255 218 188 255 218 189 minecraft:redstone_block
fill 255 218 194 255 218 195 minecraft:redstone_block
setblock 255 218 200 minecraft:redstone_block
fill 255 218 212 255 218 213 minecraft:redstone_block
fill 255 218 218 255 218 219 minecraft:redstone_block
fill 256 218 182 257 218 183 minecraft:smooth_stone
fill 256 218 188 257 218 189 minecraft:smooth_stone
fill 256 218 194 257 218 195 minecraft:smooth_stone
fill 256 218 200 257 218 200 minecraft:smooth_stone
fill 256 218 202 258 218 202 minecraft:ochre_froglight
fill 256 218 208 258 218 208 minecraft:ochre_froglight
fill 256 218 212 257 218 213 minecraft:smooth_stone
fill 256 218 218 257 218 219 minecraft:smooth_stone
setblock 257 218 201 minecraft:smooth_stone
fill 257 218 209 276 218 209 minecraft:smooth_stone
fill 258 218 182 258 218 183 minecraft:redstone_block
fill 258 218 188 258 218 189 minecraft:redstone_block
fill 258 218 194 258 218 195 minecraft:redstone_block
fill 258 218 200 258 218 201 minecraft:redstone_block
fill 258 218 203 258 218 204 minecraft:ochre_froglight
fill 258 218 206 258 218 207 minecraft:ochre_froglight
fill 258 218 212 258 218 213 minecraft:redstone_block
fill 258 218 218 258 218 219 minecraft:redstone_block
fill 259 218 182 260 218 183 minecraft:smooth_stone
fill 259 218 188 260 218 189 minecraft:smooth_stone
fill 259 218 194 260 218 195 minecraft:smooth_stone
fill 259 218 200 260 218 201 minecraft:smooth_stone
fill 259 218 202 276 218 202 minecraft:redstone_block
fill 259 218 203 276 218 203 minecraft:smooth_stone
fill 259 218 204 259 218 206 minecraft:ochre_froglight
fill 259 218 207 260 218 207 minecraft:smooth_stone
fill 259 218 208 276 218 208 minecraft:redstone_block
fill 259 218 212 260 218 213 minecraft:smooth_stone
fill 259 218 218 260 218 219 minecraft:smooth_stone
fill 260 218 204 276 218 204 minecraft:smooth_stone
fill 260 218 205 276 218 205 minecraft:redstone_block
setblock 260 218 206 minecraft:smooth_stone
fill 261 218 182 261 218 183 minecraft:redstone_block
fill 261 218 188 261 218 189 minecraft:redstone_block
fill 261 218 194 261 218 195 minecraft:redstone_block
fill 261 218 200 261 218 201 minecraft:redstone_block
fill 261 218 206 261 218 207 minecraft:redstone_block
fill 261 218 212 261 218 213 minecraft:redstone_block
fill 261 218 218 261 218 219 minecraft:redstone_block
fill 262 218 182 263 218 183 minecraft:smooth_stone
fill 262 218 188 263 218 189 minecraft:smooth_stone
fill 262 218 194 263 218 195 minecraft:smooth_stone
fill 262 218 200 263 218 201 minecraft:smooth_stone
fill 262 218 206 263 218 207 minecraft:smooth_stone
fill 262 218 212 263 218 213 minecraft:smooth_stone
fill 262 218 218 263 218 219 minecraft:smooth_stone
fill 264 218 182 264 218 183 minecraft:redstone_block
fill 264 218 188 264 218 189 minecraft:redstone_block
fill 264 218 194 264 218 195 minecraft:redstone_block
fill 264 218 200 264 218 201 minecraft:redstone_block
fill 264 218 206 264 218 207 minecraft:redstone_block
fill 264 218 212 264 218 213 minecraft:redstone_block
fill 264 218 218 264 218 219 minecraft:redstone_block
fill 265 218 182 266 218 183 minecraft:smooth_stone
fill 265 218 188 266 218 189 minecraft:smooth_stone
fill 265 218 194 266 218 195 minecraft:smooth_stone
fill 265 218 200 266 218 201 minecraft:smooth_stone
fill 265 218 206 266 218 207 minecraft:smooth_stone
fill 265 218 212 266 218 213 minecraft:smooth_stone
fill 265 218 218 266 218 219 minecraft:smooth_stone
fill 267 218 182 267 218 183 minecraft:redstone_block
fill 267 218 188 267 218 189 minecraft:redstone_block
fill 267 218 194 267 218 195 minecraft:redstone_block
fill 267 218 200 267 218 201 minecraft:redstone_block
fill 267 218 206 267 218 207 minecraft:redstone_block
fill 267 218 212 267 218 213 minecraft:redstone_block
fill 267 218 218 267 218 219 minecraft:redstone_block
fill 268 218 182 269 218 183 minecraft:smooth_stone
fill 268 218 188 269 218 189 minecraft:smooth_stone
fill 268 218 194 269 218 195 minecraft:smooth_stone
fill 268 218 200 269 218 201 minecraft:smooth_stone
fill 268 218 206 269 218 207 minecraft:smooth_stone
fill 268 218 212 269 218 213 minecraft:smooth_stone
fill 268 218 218 269 218 219 minecraft:smooth_stone
fill 270 218 182 270 218 183 minecraft:redstone_block
fill 270 218 188 270 218 189 minecraft:redstone_block
fill 270 218 194 270 218 195 minecraft:redstone_block
fill 270 218 200 270 218 201 minecraft:redstone_block
fill 270 218 206 270 218 207 minecraft:redstone_block
fill 270 218 212 270 218 213 minecraft:redstone_block
fill 270 218 218 270 218 219 minecraft:redstone_block
fill 271 218 182 272 218 183 minecraft:smooth_stone
fill 271 218 188 272 218 189 minecraft:smooth_stone
fill 271 218 194 272 218 195 minecraft:smooth_stone
fill 271 218 200 272 218 201 minecraft:smooth_stone
fill 271 218 206 272 218 207 minecraft:smooth_stone
fill 271 218 212 272 218 213 minecraft:smooth_stone
fill 271 218 218 272 218 219 minecraft:smooth_stone
fill 273 218 182 273 218 183 minecraft:redstone_block
fill 273 218 188 273 218 189 minecraft:redstone_block
fill 273 218 194 273 218 195 minecraft:redstone_block
fill 273 218 200 273 218 201 minecraft:redstone_block
fill 273 218 206 273 218 207 minecraft:redstone_block
fill 273 218 212 273 218 213 minecraft:redstone_block
fill 273 218 218 273 218 219 minecraft:redstone_block
fill 274 218 182 275 218 183 minecraft:smooth_stone
fill 274 218 188 275 218 189 minecraft:smooth_stone
fill 274 218 194 275 218 195 minecraft:smooth_stone
fill 274 218 200 275 218 201 minecraft:smooth_stone
fill 274 218 206 275 218 207 minecraft:smooth_stone
fill 274 218 212 275 218 213 minecraft:smooth_stone
fill 274 218 218 275 218 219 minecraft:smooth_stone
fill 276 218 182 276 218 183 minecraft:redstone_block
fill 276 218 188 276 218 189 minecraft:redstone_block
fill 276 218 194 276 218 195 minecraft:redstone_block
fill 276 218 200 276 218 201 minecraft:redstone_block
fill 276 218 206 276 218 207 minecraft:redstone_block
fill 276 218 212 276 218 213 minecraft:redstone_block
fill 276 218 218 276 218 219 minecraft:redstone_block
setblock 238 219 184 minecraft:light[level=13]
setblock 238 219 192 minecraft:light[level=13]
setblock 238 219 200 minecraft:light[level=13]
setblock 238 219 208 minecraft:light[level=13]
setblock 238 219 216 minecraft:light[level=13]
setblock 246 219 184 minecraft:light[level=13]
setblock 246 219 192 minecraft:light[level=13]
setblock 246 219 200 minecraft:light[level=13]
setblock 246 219 208 minecraft:light[level=13]
setblock 246 219 216 minecraft:light[level=13]
setblock 254 219 184 minecraft:light[level=13]
setblock 254 219 192 minecraft:light[level=13]
setblock 254 219 200 minecraft:light[level=13]
setblock 254 219 208 minecraft:light[level=13]
setblock 254 219 216 minecraft:light[level=13]
setblock 262 219 184 minecraft:light[level=13]
setblock 262 219 192 minecraft:light[level=13]
setblock 262 219 200 minecraft:light[level=13]
setblock 262 219 208 minecraft:light[level=13]
setblock 262 219 216 minecraft:light[level=13]
setblock 270 219 184 minecraft:light[level=13]
setblock 270 219 192 minecraft:light[level=13]
setblock 270 219 200 minecraft:light[level=13]
setblock 270 219 208 minecraft:light[level=13]
setblock 270 219 216 minecraft:light[level=13]
fill 236 222 183 236 271 183 minecraft:iron_block
setblock 236 222 184 minecraft:smooth_stone
fill 236 222 193 236 271 193 minecraft:iron_block
setblock 236 222 194 minecraft:smooth_stone
fill 236 222 203 236 271 203 minecraft:iron_block
setblock 236 222 204 minecraft:smooth_stone
fill 236 222 213 236 271 213 minecraft:iron_block
setblock 236 222 214 minecraft:smooth_stone
fill 237 222 222 237 271 222 minecraft:iron_block
setblock 238 222 222 minecraft:smooth_stone
setblock 242 222 182 minecraft:smooth_stone
fill 243 222 182 243 271 182 minecraft:iron_block
fill 247 222 222 247 271 222 minecraft:iron_block
setblock 248 222 222 minecraft:smooth_stone
setblock 252 222 182 minecraft:smooth_stone
fill 253 222 182 253 271 182 minecraft:iron_block
fill 257 222 222 257 271 222 minecraft:iron_block
setblock 258 222 222 minecraft:smooth_stone
setblock 262 222 182 minecraft:smooth_stone
fill 263 222 182 263 271 182 minecraft:iron_block
fill 267 222 222 267 271 222 minecraft:iron_block
setblock 268 222 222 minecraft:smooth_stone
setblock 272 222 182 minecraft:smooth_stone
fill 273 222 182 273 271 182 minecraft:iron_block
setblock 276 222 188 minecraft:smooth_stone
fill 276 222 189 276 271 189 minecraft:iron_block
setblock 276 222 198 minecraft:smooth_stone
fill 276 222 199 276 271 199 minecraft:iron_block
setblock 276 222 208 minecraft:smooth_stone
fill 276 222 209 276 271 209 minecraft:iron_block
setblock 276 222 218 minecraft:smooth_stone
fill 276 222 219 276 271 219 minecraft:iron_block
fill 236 225 186 236 225 189 minecraft:smooth_stone
fill 236 225 196 236 225 199 minecraft:smooth_stone
fill 236 225 206 236 225 209 minecraft:smooth_stone
fill 236 225 216 236 225 219 minecraft:smooth_stone
fill 237 225 182 240 225 182 minecraft:smooth_stone
fill 240 225 222 243 225 222 minecraft:smooth_stone
fill 247 225 182 250 225 182 minecraft:smooth_stone
fill 250 225 222 253 225 222 minecraft:smooth_stone
fill 257 225 182 260 225 182 minecraft:smooth_stone
fill 260 225 222 263 225 222 minecraft:smooth_stone
fill 267 225 182 270 225 182 minecraft:smooth_stone
fill 270 225 222 273 225 222 minecraft:smooth_stone
fill 276 225 183 276 225 186 minecraft:smooth_stone
fill 276 225 193 276 225 196 minecraft:smooth_stone
fill 276 225 203 276 225 206 minecraft:smooth_stone
fill 276 225 213 276 225 216 minecraft:smooth_stone
setblock 238 227 184 minecraft:light[level=13]
setblock 238 227 192 minecraft:light[level=13]
setblock 238 227 200 minecraft:light[level=13]
setblock 238 227 208 minecraft:light[level=13]
setblock 238 227 216 minecraft:light[level=13]
setblock 246 227 184 minecraft:light[level=13]
setblock 246 227 192 minecraft:light[level=13]
setblock 246 227 200 minecraft:light[level=13]
setblock 246 227 208 minecraft:light[level=13]
setblock 246 227 216 minecraft:light[level=13]
setblock 254 227 184 minecraft:light[level=13]
setblock 254 227 192 minecraft:light[level=13]
setblock 254 227 200 minecraft:light[level=13]
setblock 254 227 208 minecraft:light[level=13]
setblock 254 227 216 minecraft:light[level=13]
setblock 262 227 184 minecraft:light[level=13]
setblock 262 227 192 minecraft:light[level=13]
setblock 262 227 200 minecraft:light[level=13]
setblock 262 227 208 minecraft:light[level=13]
setblock 262 227 216 minecraft:light[level=13]
setblock 270 227 184 minecraft:light[level=13]
setblock 270 227 192 minecraft:light[level=13]
setblock 270 227 200 minecraft:light[level=13]
setblock 270 227 208 minecraft:light[level=13]
setblock 270 227 216 minecraft:light[level=13]
setblock 236 228 184 minecraft:smooth_stone
setblock 236 228 194 minecraft:smooth_stone
setblock 236 228 204 minecraft:smooth_stone
setblock 236 228 214 minecraft:smooth_stone
setblock 238 228 222 minecraft:smooth_stone
setblock 242 228 182 minecraft:smooth_stone
setblock 248 228 222 minecraft:smooth_stone
setblock 252 228 182 minecraft:smooth_stone
setblock 258 228 222 minecraft:smooth_stone
setblock 262 228 182 minecraft:smooth_stone
setblock 268 228 222 minecraft:smooth_stone
setblock 272 228 182 minecraft:smooth_stone
setblock 276 228 188 minecraft:smooth_stone
setblock 276 228 198 minecraft:smooth_stone
setblock 276 228 208 minecraft:smooth_stone
setblock 276 228 218 minecraft:smooth_stone
fill 235 229 187 235 229 190 minecraft:ochre_froglight
fill 235 229 197 235 229 200 minecraft:ochre_froglight
fill 235 229 207 235 229 210 minecraft:ochre_froglight
fill 235 229 217 235 229 220 minecraft:ochre_froglight
fill 238 229 181 241 229 181 minecraft:ochre_froglight
fill 239 229 223 242 229 223 minecraft:ochre_froglight
fill 248 229 181 251 229 181 minecraft:ochre_froglight
fill 249 229 223 252 229 223 minecraft:ochre_froglight
fill 258 229 181 261 229 181 minecraft:ochre_froglight
fill 259 229 223 262 229 223 minecraft:ochre_froglight
fill 268 229 181 271 229 181 minecraft:ochre_froglight
fill 269 229 223 272 229 223 minecraft:ochre_froglight
fill 277 229 182 277 229 185 minecraft:ochre_froglight
fill 277 229 192 277 229 195 minecraft:ochre_froglight
fill 277 229 202 277 229 205 minecraft:ochre_froglight
fill 277 229 212 277 229 215 minecraft:ochre_froglight
setblock 277 229 222 minecraft:ochre_froglight
fill 235 230 187 235 237 190 minecraft:polished_andesite
fill 235 230 197 235 237 200 minecraft:polished_andesite
fill 235 230 207 235 237 210 minecraft:polished_andesite
fill 235 230 217 235 237 220 minecraft:polished_andesite
fill 238 230 181 241 237 181 minecraft:polished_andesite
fill 239 230 223 242 237 223 minecraft:polished_andesite
fill 248 230 181 251 237 181 minecraft:polished_andesite
fill 249 230 223 252 237 223 minecraft:polished_andesite
fill 258 230 181 261 237 181 minecraft:polished_andesite
fill 259 230 223 262 237 223 minecraft:polished_andesite
fill 268 230 181 271 237 181 minecraft:polished_andesite
fill 269 230 223 272 237 223 minecraft:polished_andesite
fill 277 230 182 277 237 185 minecraft:polished_andesite
fill 277 230 192 277 237 195 minecraft:polished_andesite
fill 277 230 202 277 237 205 minecraft:polished_andesite
fill 277 230 212 277 237 215 minecraft:polished_andesite
fill 277 230 222 277 237 222 minecraft:polished_andesite
setblock 236 234 184 minecraft:smooth_stone
fill 236 234 186 236 234 189 minecraft:smooth_stone
setblock 236 234 194 minecraft:smooth_stone
fill 236 234 196 236 234 199 minecraft:smooth_stone
setblock 236 234 204 minecraft:smooth_stone
fill 236 234 206 236 234 209 minecraft:smooth_stone
setblock 236 234 214 minecraft:smooth_stone
fill 236 234 216 236 234 219 minecraft:smooth_stone
fill 237 234 182 240 234 182 minecraft:smooth_stone
setblock 238 234 222 minecraft:smooth_stone
fill 240 234 222 243 234 222 minecraft:smooth_stone
setblock 242 234 182 minecraft:smooth_stone
fill 247 234 182 250 234 182 minecraft:smooth_stone
setblock 248 234 222 minecraft:smooth_stone
fill 250 234 222 253 234 222 minecraft:smooth_stone
setblock 252 234 182 minecraft:smooth_stone
fill 257 234 182 260 234 182 minecraft:smooth_stone
setblock 258 234 222 minecraft:smooth_stone
fill 260 234 222 263 234 222 minecraft:smooth_stone
setblock 262 234 182 minecraft:smooth_stone
fill 267 234 182 270 234 182 minecraft:smooth_stone
setblock 268 234 222 minecraft:smooth_stone
fill 270 234 222 273 234 222 minecraft:smooth_stone
setblock 272 234 182 minecraft:smooth_stone
fill 276 234 183 276 234 186 minecraft:smooth_stone
setblock 276 234 188 minecraft:smooth_stone
fill 276 234 193 276 234 196 minecraft:smooth_stone
setblock 276 234 198 minecraft:smooth_stone
fill 276 234 203 276 234 206 minecraft:smooth_stone
setblock 276 234 208 minecraft:smooth_stone
fill 276 234 213 276 234 216 minecraft:smooth_stone
setblock 276 234 218 minecraft:smooth_stone
setblock 238 235 184 minecraft:light[level=13]
setblock 238 235 192 minecraft:light[level=13]
setblock 238 235 200 minecraft:light[level=13]
setblock 238 235 208 minecraft:light[level=13]
setblock 238 235 216 minecraft:light[level=13]
setblock 246 235 184 minecraft:light[level=13]
setblock 246 235 192 minecraft:light[level=13]
setblock 246 235 200 minecraft:light[level=13]
setblock 246 235 208 minecraft:light[level=13]
setblock 246 235 216 minecraft:light[level=13]
setblock 254 235 184 minecraft:light[level=13]
setblock 254 235 192 minecraft:light[level=13]
setblock 254 235 200 minecraft:light[level=13]
setblock 254 235 208 minecraft:light[level=13]
setblock 254 235 216 minecraft:light[level=13]
setblock 262 235 184 minecraft:light[level=13]
setblock 262 235 192 minecraft:light[level=13]
setblock 262 235 200 minecraft:light[level=13]
setblock 262 235 208 minecraft:light[level=13]
setblock 262 235 216 minecraft:light[level=13]
setblock 270 235 184 minecraft:light[level=13]
setblock 270 235 192 minecraft:light[level=13]
setblock 270 235 200 minecraft:light[level=13]
setblock 270 235 208 minecraft:light[level=13]
setblock 270 235 216 minecraft:light[level=13]
fill 235 238 187 235 238 190 minecraft:ochre_froglight
fill 235 238 197 235 238 200 minecraft:ochre_froglight
fill 235 238 207 235 238 210 minecraft:ochre_froglight
fill 235 238 217 235 238 220 minecraft:ochre_froglight
fill 238 238 181 241 238 181 minecraft:ochre_froglight
fill 239 238 223 242 238 223 minecraft:ochre_froglight
fill 248 238 181 251 238 181 minecraft:ochre_froglight
fill 249 238 223 252 238 223 minecraft:ochre_froglight
fill 258 238 181 261 238 181 minecraft:ochre_froglight
fill 259 238 223 262 238 223 minecraft:ochre_froglight
fill 268 238 181 271 238 181 minecraft:ochre_froglight
fill 269 238 223 272 238 223 minecraft:ochre_froglight
fill 277 238 182 277 238 185 minecraft:ochre_froglight
fill 277 238 192 277 238 195 minecraft:ochre_froglight
fill 277 238 202 277 238 205 minecraft:ochre_froglight
fill 277 238 212 277 238 215 minecraft:ochre_froglight
setblock 277 238 222 minecraft:ochre_froglight
fill 235 239 187 235 246 190 minecraft:polished_andesite
fill 235 239 197 235 246 200 minecraft:polished_andesite
fill 235 239 207 235 246 210 minecraft:polished_andesite
fill 235 239 217 235 246 220 minecraft:polished_andesite
fill 238 239 181 241 246 181 minecraft:polished_andesite
fill 239 239 223 242 246 223 minecraft:polished_andesite
fill 248 239 181 251 246 181 minecraft:polished_andesite
fill 249 239 223 252 246 223 minecraft:polished_andesite
fill 258 239 181 261 246 181 minecraft:polished_andesite
fill 259 239 223 262 246 223 minecraft:polished_andesite
fill 268 239 181 271 246 181 minecraft:polished_andesite
fill 269 239 223 272 246 223 minecraft:polished_andesite
fill 277 239 182 277 246 185 minecraft:polished_andesite
fill 277 239 192 277 246 195 minecraft:polished_andesite
fill 277 239 202 277 246 205 minecraft:polished_andesite
fill 277 239 212 277 246 215 minecraft:polished_andesite
fill 277 239 222 277 246 222 minecraft:polished_andesite
setblock 236 240 184 minecraft:smooth_stone
setblock 236 240 194 minecraft:smooth_stone
setblock 236 240 204 minecraft:smooth_stone
setblock 236 240 214 minecraft:smooth_stone
setblock 238 240 222 minecraft:smooth_stone
setblock 242 240 182 minecraft:smooth_stone
setblock 248 240 222 minecraft:smooth_stone
setblock 252 240 182 minecraft:smooth_stone
setblock 258 240 222 minecraft:smooth_stone
setblock 262 240 182 minecraft:smooth_stone
setblock 268 240 222 minecraft:smooth_stone
setblock 272 240 182 minecraft:smooth_stone
setblock 276 240 188 minecraft:smooth_stone
setblock 276 240 198 minecraft:smooth_stone
setblock 276 240 208 minecraft:smooth_stone
setblock 276 240 218 minecraft:smooth_stone
fill 236 243 186 236 243 189 minecraft:smooth_stone
fill 236 243 196 236 243 199 minecraft:smooth_stone
fill 236 243 206 236 243 209 minecraft:smooth_stone
fill 236 243 216 236 243 219 minecraft:smooth_stone
fill 237 243 182 240 243 182 minecraft:smooth_stone
setblock 238 243 184 minecraft:light[level=13]
setblock 238 243 192 minecraft:light[level=13]
setblock 238 243 200 minecraft:light[level=13]
setblock 238 243 208 minecraft:light[level=13]
setblock 238 243 216 minecraft:light[level=13]
fill 240 243 222 243 243 222 minecraft:smooth_stone
setblock 246 243 184 minecraft:light[level=13]
setblock 246 243 192 minecraft:light[level=13]
setblock 246 243 200 minecraft:light[level=13]
setblock 246 243 208 minecraft:light[level=13]
setblock 246 243 216 minecraft:light[level=13]
fill 247 243 182 250 243 182 minecraft:smooth_stone
fill 250 243 222 253 243 222 minecraft:smooth_stone
setblock 254 243 184 minecraft:light[level=13]
setblock 254 243 192 minecraft:light[level=13]
setblock 254 243 200 minecraft:light[level=13]
setblock 254 243 208 minecraft:light[level=13]
setblock 254 243 216 minecraft:light[level=13]
fill 257 243 182 260 243 182 minecraft:smooth_stone
fill 260 243 222 263 243 222 minecraft:smooth_stone
setblock 262 243 184 minecraft:light[level=13]
setblock 262 243 192 minecraft:light[level=13]
setblock 262 243 200 minecraft:light[level=13]
setblock 262 243 208 minecraft:light[level=13]
setblock 262 243 216 minecraft:light[level=13]
fill 267 243 182 270 243 182 minecraft:smooth_stone
setblock 270 243 184 minecraft:light[level=13]
setblock 270 243 192 minecraft:light[level=13]
setblock 270 243 200 minecraft:light[level=13]
setblock 270 243 208 minecraft:light[level=13]
setblock 270 243 216 minecraft:light[level=13]
fill 270 243 222 273 243 222 minecraft:smooth_stone
fill 276 243 183 276 243 186 minecraft:smooth_stone
fill 276 243 193 276 243 196 minecraft:smooth_stone
fill 276 243 203 276 243 206 minecraft:smooth_stone
fill 276 243 213 276 243 216 minecraft:smooth_stone
setblock 236 246 184 minecraft:smooth_stone
setblock 236 246 194 minecraft:smooth_stone
setblock 236 246 204 minecraft:smooth_stone
setblock 236 246 214 minecraft:smooth_stone
setblock 238 246 222 minecraft:smooth_stone
setblock 242 246 182 minecraft:smooth_stone
setblock 248 246 222 minecraft:smooth_stone
setblock 252 246 182 minecraft:smooth_stone
setblock 258 246 222 minecraft:smooth_stone
setblock 262 246 182 minecraft:smooth_stone
setblock 268 246 222 minecraft:smooth_stone
setblock 272 246 182 minecraft:smooth_stone
setblock 276 246 188 minecraft:smooth_stone
setblock 276 246 198 minecraft:smooth_stone
setblock 276 246 208 minecraft:smooth_stone
setblock 276 246 218 minecraft:smooth_stone
fill 235 247 187 235 247 190 minecraft:ochre_froglight
fill 235 247 197 235 247 200 minecraft:ochre_froglight
fill 235 247 207 235 247 210 minecraft:ochre_froglight
fill 235 247 217 235 247 220 minecraft:ochre_froglight
fill 238 247 181 241 247 181 minecraft:ochre_froglight
fill 239 247 223 242 247 223 minecraft:ochre_froglight
fill 248 247 181 251 247 181 minecraft:ochre_froglight
fill 249 247 223 252 247 223 minecraft:ochre_froglight
fill 258 247 181 261 247 181 minecraft:ochre_froglight
fill 259 247 223 262 247 223 minecraft:ochre_froglight
fill 268 247 181 271 247 181 minecraft:ochre_froglight
fill 269 247 223 272 247 223 minecraft:ochre_froglight
fill 277 247 182 277 247 185 minecraft:ochre_froglight
fill 277 247 192 277 247 195 minecraft:ochre_froglight
fill 277 247 202 277 247 205 minecraft:ochre_froglight
fill 277 247 212 277 247 215 minecraft:ochre_froglight
setblock 277 247 222 minecraft:ochre_froglight
fill 235 248 187 235 255 190 minecraft:polished_andesite
fill 235 248 197 235 255 200 minecraft:polished_andesite
fill 235 248 207 235 255 210 minecraft:polished_andesite
fill 235 248 217 235 255 220 minecraft:polished_andesite
fill 238 248 181 241 255 181 minecraft:polished_andesite
fill 239 248 223 242 255 223 minecraft:polished_andesite
fill 248 248 181 251 255 181 minecraft:polished_andesite
fill 249 248 223 252 255 223 minecraft:polished_andesite
fill 258 248 181 261 255 181 minecraft:polished_andesite
fill 259 248 223 262 255 223 minecraft:polished_andesite
fill 268 248 181 271 255 181 minecraft:polished_andesite
fill 269 248 223 272 255 223 minecraft:polished_andesite
fill 277 248 182 277 255 185 minecraft:polished_andesite
fill 277 248 192 277 255 195 minecraft:polished_andesite
fill 277 248 202 277 255 205 minecraft:polished_andesite
fill 277 248 212 277 255 215 minecraft:polished_andesite
fill 277 248 222 277 255 222 minecraft:polished_andesite
setblock 238 251 184 minecraft:light[level=13]
setblock 238 251 192 minecraft:light[level=13]
setblock 238 251 200 minecraft:light[level=13]
setblock 238 251 208 minecraft:light[level=13]
setblock 238 251 216 minecraft:light[level=13]
setblock 246 251 184 minecraft:light[level=13]
setblock 246 251 192 minecraft:light[level=13]
setblock 246 251 200 minecraft:light[level=13]
setblock 246 251 208 minecraft:light[level=13]
setblock 246 251 216 minecraft:light[level=13]
setblock 254 251 184 minecraft:light[level=13]
setblock 254 251 192 minecraft:light[level=13]
setblock 254 251 200 minecraft:light[level=13]
setblock 254 251 208 minecraft:light[level=13]
setblock 254 251 216 minecraft:light[level=13]
setblock 262 251 184 minecraft:light[level=13]
setblock 262 251 192 minecraft:light[level=13]
setblock 262 251 200 minecraft:light[level=13]
setblock 262 251 208 minecraft:light[level=13]
setblock 262 251 216 minecraft:light[level=13]
setblock 270 251 184 minecraft:light[level=13]
setblock 270 251 192 minecraft:light[level=13]
setblock 270 251 200 minecraft:light[level=13]
setblock 270 251 208 minecraft:light[level=13]
setblock 270 251 216 minecraft:light[level=13]
setblock 236 252 184 minecraft:smooth_stone
fill 236 252 186 236 252 189 minecraft:smooth_stone
setblock 236 252 194 minecraft:smooth_stone
fill 236 252 196 236 252 199 minecraft:smooth_stone
setblock 236 252 204 minecraft:smooth_stone
fill 236 252 206 236 252 209 minecraft:smooth_stone
setblock 236 252 214 minecraft:smooth_stone
fill 236 252 216 236 252 219 minecraft:smooth_stone
fill 237 252 182 240 252 182 minecraft:smooth_stone
setblock 238 252 222 minecraft:smooth_stone
fill 240 252 222 243 252 222 minecraft:smooth_stone
setblock 242 252 182 minecraft:smooth_stone
fill 247 252 182 250 252 182 minecraft:smooth_stone
setblock 248 252 222 minecraft:smooth_stone
fill 250 252 222 253 252 222 minecraft:smooth_stone
setblock 252 252 182 minecraft:smooth_stone
fill 257 252 182 260 252 182 minecraft:smooth_stone
setblock 258 252 222 minecraft:smooth_stone
fill 260 252 222 263 252 222 minecraft:smooth_stone
setblock 262 252 182 minecraft:smooth_stone
fill 267 252 182 270 252 182 minecraft:smooth_stone
setblock 268 252 222 minecraft:smooth_stone
fill 270 252 222 273 252 222 minecraft:smooth_stone
setblock 272 252 182 minecraft:smooth_stone
fill 276 252 183 276 252 186 minecraft:smooth_stone
setblock 276 252 188 minecraft:smooth_stone
fill 276 252 193 276 252 196 minecraft:smooth_stone
setblock 276 252 198 minecraft:smooth_stone
fill 276 252 203 276 252 206 minecraft:smooth_stone
setblock 276 252 208 minecraft:smooth_stone
fill 276 252 213 276 252 216 minecraft:smooth_stone
setblock 276 252 218 minecraft:smooth_stone
fill 235 256 187 235 256 190 minecraft:ochre_froglight
fill 235 256 197 235 256 200 minecraft:ochre_froglight
fill 235 256 207 235 256 210 minecraft:ochre_froglight
fill 235 256 217 235 256 220 minecraft:ochre_froglight
fill 238 256 181 241 256 181 minecraft:ochre_froglight
fill 239 256 223 242 256 223 minecraft:ochre_froglight
fill 248 256 181 251 256 181 minecraft:ochre_froglight
fill 249 256 223 252 256 223 minecraft:ochre_froglight
fill 258 256 181 261 256 181 minecraft:ochre_froglight
fill 259 256 223 262 256 223 minecraft:ochre_froglight
fill 268 256 181 271 256 181 minecraft:ochre_froglight
fill 269 256 223 272 256 223 minecraft:ochre_froglight
fill 277 256 182 277 256 185 minecraft:ochre_froglight
fill 277 256 192 277 256 195 minecraft:ochre_froglight
fill 277 256 202 277 256 205 minecraft:ochre_froglight
fill 277 256 212 277 256 215 minecraft:ochre_froglight
setblock 277 256 222 minecraft:ochre_froglight
fill 235 257 187 235 264 190 minecraft:polished_andesite
fill 235 257 197 235 264 200 minecraft:polished_andesite
fill 235 257 207 235 264 210 minecraft:polished_andesite
fill 235 257 217 235 264 220 minecraft:polished_andesite
fill 238 257 181 241 264 181 minecraft:polished_andesite
fill 239 257 223 242 264 223 minecraft:polished_andesite
fill 248 257 181 251 264 181 minecraft:polished_andesite
fill 249 257 223 252 264 223 minecraft:polished_andesite
fill 258 257 181 261 264 181 minecraft:polished_andesite
fill 259 257 223 262 264 223 minecraft:polished_andesite
fill 268 257 181 271 264 181 minecraft:polished_andesite
fill 269 257 223 272 264 223 minecraft:polished_andesite
fill 277 257 182 277 264 185 minecraft:polished_andesite
fill 277 257 192 277 264 195 minecraft:polished_andesite
fill 277 257 202 277 264 205 minecraft:polished_andesite
fill 277 257 212 277 264 215 minecraft:polished_andesite
fill 277 257 222 277 264 222 minecraft:polished_andesite
setblock 236 258 184 minecraft:smooth_stone
setblock 236 258 194 minecraft:smooth_stone
setblock 236 258 204 minecraft:smooth_stone
setblock 236 258 214 minecraft:smooth_stone
setblock 238 258 222 minecraft:smooth_stone
setblock 242 258 182 minecraft:smooth_stone
setblock 248 258 222 minecraft:smooth_stone
setblock 252 258 182 minecraft:smooth_stone
setblock 258 258 222 minecraft:smooth_stone
setblock 262 258 182 minecraft:smooth_stone
setblock 268 258 222 minecraft:smooth_stone
setblock 272 258 182 minecraft:smooth_stone
fill 273 258 184 275 259 184 minecraft:iron_block
setblock 276 258 188 minecraft:smooth_stone
setblock 276 258 198 minecraft:smooth_stone
setblock 276 258 208 minecraft:smooth_stone
setblock 276 258 218 minecraft:smooth_stone
setblock 238 259 184 minecraft:light[level=13]
setblock 238 259 192 minecraft:light[level=13]
setblock 238 259 200 minecraft:light[level=13]
schedule function dropper:buildpart/41_2 1t
