setblock 294 211 183 minecraft:red_nether_bricks
setblock 294 211 222 minecraft:polished_blackstone
setblock 295 211 182 minecraft:red_nether_bricks
setblock 295 211 221 minecraft:polished_blackstone
setblock 295 211 222 minecraft:red_nether_bricks
setblock 296 211 220 minecraft:polished_blackstone
setblock 296 211 221 minecraft:red_nether_bricks
setblock 299 211 182 minecraft:polished_blackstone
setblock 299 211 222 minecraft:polished_blackstone
setblock 300 211 222 minecraft:red_nether_bricks
setblock 309 211 182 minecraft:polished_blackstone
setblock 310 211 182 minecraft:red_nether_bricks
setblock 310 211 222 minecraft:red_nether_bricks
setblock 311 211 183 minecraft:red_nether_bricks
setblock 313 211 183 minecraft:polished_blackstone
setblock 314 211 182 minecraft:polished_blackstone
fill 314 211 183 314 211 184 minecraft:red_nether_bricks
setblock 314 211 222 minecraft:polished_blackstone
setblock 315 211 182 minecraft:red_nether_bricks
fill 315 211 184 316 211 184 minecraft:red_nether_bricks
setblock 315 211 222 minecraft:red_nether_bricks
setblock 317 211 184 minecraft:polished_blackstone
setblock 318 211 183 minecraft:polished_blackstone
setblock 319 211 182 minecraft:polished_blackstone
setblock 319 211 183 minecraft:red_nether_bricks
setblock 319 211 222 minecraft:polished_blackstone
setblock 320 211 182 minecraft:red_nether_bricks
setblock 320 211 222 minecraft:red_nether_bricks
setblock 322 211 183 minecraft:red_nether_bricks
setblock 322 211 184 minecraft:polished_blackstone
setblock 323 211 183 minecraft:polished_blackstone
setblock 323 211 184 minecraft:red_nether_bricks
setblock 323 211 187 minecraft:red_nether_bricks
setblock 285 212 184 minecraft:light[level=14]
setblock 285 212 192 minecraft:light[level=14]
setblock 285 212 200 minecraft:light[level=14]
setblock 285 212 208 minecraft:light[level=14]
setblock 285 212 216 minecraft:light[level=14]
setblock 293 212 184 minecraft:light[level=14]
setblock 293 212 192 minecraft:light[level=14]
setblock 293 212 200 minecraft:light[level=14]
setblock 293 212 208 minecraft:light[level=14]
setblock 293 212 216 minecraft:light[level=14]
setblock 301 212 184 minecraft:light[level=14]
setblock 301 212 192 minecraft:light[level=14]
setblock 301 212 200 minecraft:light[level=14]
setblock 301 212 208 minecraft:light[level=14]
setblock 301 212 216 minecraft:light[level=14]
setblock 309 212 184 minecraft:light[level=14]
setblock 309 212 192 minecraft:light[level=14]
setblock 309 212 200 minecraft:light[level=14]
setblock 309 212 208 minecraft:light[level=14]
setblock 309 212 216 minecraft:light[level=14]
setblock 317 212 184 minecraft:light[level=14]
setblock 317 212 192 minecraft:light[level=14]
setblock 317 212 200 minecraft:light[level=14]
setblock 317 212 208 minecraft:light[level=14]
setblock 317 212 216 minecraft:light[level=14]
fill 283 217 192 298 217 212 minecraft:nether_bricks
fill 284 217 190 322 217 191 minecraft:nether_bricks
fill 284 217 213 322 217 214 minecraft:nether_bricks
fill 285 217 189 321 217 189 minecraft:nether_bricks
fill 285 217 215 321 217 215 minecraft:nether_bricks
fill 286 217 188 320 218 188 minecraft:nether_bricks
fill 286 217 216 320 218 216 minecraft:nether_bricks
fill 287 217 186 319 217 187 minecraft:nether_bricks
fill 287 217 217 319 217 218 minecraft:nether_bricks
fill 289 217 185 317 218 185 minecraft:nether_bricks
fill 289 217 219 317 218 219 minecraft:nether_bricks
fill 290 217 184 316 217 184 minecraft:nether_bricks
fill 290 217 220 316 217 220 minecraft:nether_bricks
fill 291 217 183 315 217 183 minecraft:nether_bricks
fill 291 217 221 315 217 221 minecraft:nether_bricks
fill 293 217 182 313 217 182 minecraft:nether_bricks
fill 293 217 222 313 217 222 minecraft:nether_bricks
fill 299 217 192 299 217 203 minecraft:nether_bricks
fill 299 217 204 299 217 205 minecraft:magma_block
setblock 299 217 207 minecraft:magma_block
fill 299 217 208 299 217 212 minecraft:nether_bricks
fill 300 217 192 323 217 202 minecraft:nether_bricks
fill 300 217 203 301 217 203 minecraft:magma_block
fill 300 217 209 300 217 212 minecraft:nether_bricks
setblock 301 217 209 minecraft:magma_block
fill 301 217 210 323 217 212 minecraft:nether_bricks
fill 303 217 203 304 217 203 minecraft:magma_block
setblock 303 217 209 minecraft:magma_block
fill 304 217 209 323 217 209 minecraft:nether_bricks
fill 305 217 203 323 217 203 minecraft:nether_bricks
fill 305 217 204 305 217 205 minecraft:magma_block
setblock 305 217 207 minecraft:magma_block
fill 305 217 208 323 217 208 minecraft:nether_bricks
fill 306 217 204 323 217 207 minecraft:nether_bricks
fill 283 218 182 283 218 192 minecraft:blackstone
fill 283 218 193 297 218 211 minecraft:nether_bricks
fill 283 218 212 283 218 222 minecraft:blackstone
fill 284 218 182 284 218 190 minecraft:blackstone
fill 284 218 191 322 218 192 minecraft:nether_bricks
fill 284 218 212 322 218 213 minecraft:nether_bricks
fill 284 218 214 284 218 222 minecraft:blackstone
fill 285 218 182 285 218 189 minecraft:blackstone
fill 285 218 190 321 218 190 minecraft:nether_bricks
fill 285 218 214 321 218 214 minecraft:nether_bricks
fill 285 218 215 285 218 222 minecraft:blackstone
fill 286 218 182 286 218 187 minecraft:blackstone
fill 286 218 189 320 219 189 minecraft:nether_bricks
fill 286 218 215 320 219 215 minecraft:nether_bricks
fill 286 218 217 286 218 222 minecraft:blackstone
fill 287 218 182 287 218 186 minecraft:blackstone
fill 287 218 187 319 218 187 minecraft:nether_bricks
fill 287 218 217 319 218 217 minecraft:nether_bricks
fill 287 218 218 287 218 222 minecraft:blackstone
fill 288 218 182 288 218 185 minecraft:blackstone
fill 288 218 186 318 218 186 minecraft:nether_bricks
fill 288 218 218 318 218 218 minecraft:nether_bricks
fill 288 218 219 288 218 222 minecraft:blackstone
fill 289 218 182 290 218 184 minecraft:blackstone
fill 289 218 220 290 218 222 minecraft:blackstone
fill 291 218 182 291 218 183 minecraft:blackstone
fill 291 218 184 315 218 184 minecraft:nether_bricks
fill 291 218 220 315 218 220 minecraft:nether_bricks
fill 291 218 221 291 218 222 minecraft:blackstone
fill 292 218 182 293 218 182 minecraft:blackstone
fill 292 218 183 314 218 183 minecraft:nether_bricks
fill 292 218 221 314 218 221 minecraft:nether_bricks
fill 292 218 222 293 218 222 minecraft:blackstone
fill 294 218 182 312 218 182 minecraft:nether_bricks
fill 294 218 222 312 218 222 minecraft:nether_bricks
fill 298 218 193 298 218 203 minecraft:nether_bricks
setblock 298 218 204 minecraft:magma_block
fill 298 218 205 298 218 207 minecraft:shroomlight
fill 298 218 208 298 218 211 minecraft:nether_bricks
fill 299 218 193 300 218 201 minecraft:nether_bricks
fill 299 218 202 300 218 202 minecraft:magma_block
fill 299 218 203 299 218 205 minecraft:shroomlight
fill 299 218 207 299 218 209 minecraft:shroomlight
fill 299 218 210 300 218 211 minecraft:nether_bricks
fill 300 218 203 301 218 203 minecraft:shroomlight
fill 300 218 209 301 218 209 minecraft:shroomlight
fill 301 218 193 323 218 200 minecraft:nether_bricks
fill 301 218 201 303 218 201 minecraft:magma_block
fill 301 218 202 303 218 202 minecraft:shroomlight
fill 301 218 210 303 218 210 minecraft:shroomlight
fill 301 218 211 323 218 211 minecraft:nether_bricks
fill 303 218 203 305 218 203 minecraft:shroomlight
fill 303 218 209 305 218 209 minecraft:shroomlight
fill 304 218 201 323 218 201 minecraft:nether_bricks
fill 304 218 202 305 218 202 minecraft:magma_block
fill 304 218 210 323 218 210 minecraft:nether_bricks
fill 305 218 204 305 218 205 minecraft:shroomlight
fill 305 218 207 305 218 208 minecraft:shroomlight
fill 306 218 202 323 218 202 minecraft:nether_bricks
fill 306 218 203 306 218 204 minecraft:magma_block
fill 306 218 205 306 218 207 minecraft:shroomlight
fill 306 218 208 323 218 209 minecraft:nether_bricks
fill 307 218 203 323 218 207 minecraft:nether_bricks
fill 313 218 182 323 218 182 minecraft:blackstone
fill 313 218 222 323 218 222 minecraft:blackstone
fill 315 218 183 323 218 183 minecraft:blackstone
fill 315 218 221 323 218 221 minecraft:blackstone
fill 316 218 184 323 218 184 minecraft:blackstone
fill 316 218 220 323 218 220 minecraft:blackstone
fill 318 218 185 323 218 185 minecraft:blackstone
fill 318 218 219 323 218 219 minecraft:blackstone
fill 319 218 186 323 218 186 minecraft:blackstone
fill 319 218 218 323 218 218 minecraft:blackstone
fill 320 218 187 323 218 187 minecraft:blackstone
fill 320 218 217 323 218 217 minecraft:blackstone
fill 321 218 188 323 218 189 minecraft:blackstone
fill 321 218 215 323 218 216 minecraft:blackstone
fill 322 218 190 323 218 190 minecraft:blackstone
fill 322 218 214 323 218 214 minecraft:blackstone
fill 323 218 191 323 218 192 minecraft:blackstone
fill 323 218 212 323 218 213 minecraft:blackstone
fill 283 219 194 296 219 210 minecraft:nether_bricks
fill 284 219 192 322 219 193 minecraft:nether_bricks
fill 284 219 211 322 219 212 minecraft:nether_bricks
fill 285 219 191 321 219 191 minecraft:nether_bricks
fill 285 219 213 321 219 213 minecraft:nether_bricks
fill 286 219 190 320 220 190 minecraft:nether_bricks
fill 286 219 214 320 220 214 minecraft:nether_bricks
fill 287 219 188 319 219 188 minecraft:nether_bricks
fill 287 219 216 319 219 216 minecraft:nether_bricks
fill 288 219 187 318 219 187 minecraft:nether_bricks
fill 288 219 217 318 219 217 minecraft:nether_bricks
fill 289 219 186 317 219 186 minecraft:nether_bricks
fill 289 219 218 317 219 218 minecraft:nether_bricks
fill 290 219 185 316 219 185 minecraft:nether_bricks
fill 290 219 219 316 219 219 minecraft:nether_bricks
fill 292 219 184 314 219 184 minecraft:nether_bricks
fill 292 219 220 314 219 220 minecraft:nether_bricks
fill 293 219 183 313 219 183 minecraft:nether_bricks
fill 293 219 221 313 219 221 minecraft:nether_bricks
fill 295 219 182 311 219 182 minecraft:nether_bricks
fill 295 219 222 311 219 222 minecraft:nether_bricks
fill 297 219 194 297 219 202 minecraft:nether_bricks
fill 297 219 203 297 219 207 minecraft:magma_block
fill 297 219 208 297 219 210 minecraft:nether_bricks
fill 298 219 194 298 219 201 minecraft:nether_bricks
fill 298 219 202 298 219 203 minecraft:magma_block
setblock 298 219 208 minecraft:magma_block
fill 298 219 209 298 219 210 minecraft:nether_bricks
fill 299 219 194 299 219 200 minecraft:nether_bricks
fill 299 219 201 300 219 201 minecraft:magma_block
setblock 299 219 209 minecraft:magma_block
setblock 299 219 210 minecraft:nether_bricks
fill 300 219 194 323 219 199 minecraft:nether_bricks
fill 300 219 200 305 219 200 minecraft:magma_block
fill 300 219 210 305 219 210 minecraft:magma_block
fill 304 219 201 306 219 201 minecraft:magma_block
fill 306 219 200 323 219 200 minecraft:nether_bricks
fill 306 219 202 307 219 202 minecraft:magma_block
fill 306 219 208 306 219 209 minecraft:magma_block
fill 306 219 210 323 219 210 minecraft:nether_bricks
fill 307 219 201 323 219 201 minecraft:nether_bricks
fill 307 219 203 307 219 207 minecraft:magma_block
fill 307 219 208 323 219 209 minecraft:nether_bricks
fill 308 219 202 323 219 207 minecraft:nether_bricks
fill 283 220 196 295 220 208 minecraft:nether_bricks
fill 284 220 194 322 220 195 minecraft:nether_bricks
fill 284 220 209 297 220 210 minecraft:nether_bricks
setblock 285 220 184 minecraft:light[level=14]
fill 285 220 192 321 220 193 minecraft:nether_bricks
fill 285 220 211 299 220 212 minecraft:nether_bricks
setblock 285 220 216 minecraft:light[level=14]
fill 286 220 191 320 221 191 minecraft:nether_bricks
fill 286 220 213 320 221 213 minecraft:nether_bricks
fill 287 220 189 319 220 189 minecraft:nether_bricks
fill 287 220 215 319 220 215 minecraft:nether_bricks
fill 288 220 188 318 220 188 minecraft:nether_bricks
fill 288 220 216 318 220 216 minecraft:nether_bricks
fill 289 220 187 317 220 187 minecraft:nether_bricks
fill 289 220 217 317 220 217 minecraft:nether_bricks
fill 290 220 186 316 220 186 minecraft:nether_bricks
fill 290 220 218 316 220 218 minecraft:nether_bricks
fill 291 220 185 315 220 185 minecraft:nether_bricks
fill 291 220 219 315 220 219 minecraft:nether_bricks
fill 293 220 184 313 220 184 minecraft:nether_bricks
fill 293 220 220 313 220 220 minecraft:nether_bricks
fill 295 220 183 311 220 183 minecraft:nether_bricks
fill 295 220 221 311 220 221 minecraft:nether_bricks
fill 296 220 196 296 220 202 minecraft:nether_bricks
fill 296 220 203 296 220 206 minecraft:magma_block
fill 296 220 207 296 220 208 minecraft:nether_bricks
fill 297 220 182 309 220 182 minecraft:nether_bricks
fill 297 220 196 297 220 200 minecraft:nether_bricks
fill 297 220 201 297 220 202 minecraft:magma_block
fill 297 220 207 297 220 208 minecraft:magma_block
fill 297 220 222 309 220 222 minecraft:nether_bricks
fill 298 220 196 298 220 199 minecraft:nether_bricks
fill 298 220 200 298 220 201 minecraft:magma_block
setblock 298 220 209 minecraft:magma_block
setblock 298 220 210 minecraft:nether_bricks
fill 299 220 196 300 220 198 minecraft:nether_bricks
fill 299 220 199 299 220 200 minecraft:magma_block
setblock 299 220 210 minecraft:magma_block
fill 300 220 199 306 220 199 minecraft:magma_block
fill 300 220 211 304 220 211 minecraft:magma_block
fill 300 220 212 321 220 212 minecraft:nether_bricks
fill 301 220 196 323 220 197 minecraft:nether_bricks
fill 301 220 198 303 220 198 minecraft:magma_block
setblock 301 220 200 minecraft:light[level=14]
fill 304 220 198 323 220 198 minecraft:nether_bricks
fill 305 220 210 306 220 210 minecraft:magma_block
fill 305 220 211 321 220 211 minecraft:nether_bricks
fill 306 220 200 307 220 200 minecraft:magma_block
fill 307 220 199 323 220 199 minecraft:nether_bricks
fill 307 220 201 308 220 201 minecraft:magma_block
fill 307 220 208 307 220 209 minecraft:magma_block
fill 307 220 210 322 220 210 minecraft:nether_bricks
fill 308 220 200 323 220 200 minecraft:nether_bricks
fill 308 220 202 308 220 207 minecraft:magma_block
fill 308 220 208 322 220 209 minecraft:nether_bricks
fill 309 220 201 323 220 207 minecraft:nether_bricks
setblock 317 220 184 minecraft:light[level=14]
setblock 323 220 208 minecraft:nether_bricks
fill 283 221 199 294 221 205 minecraft:nether_bricks
fill 284 221 195 297 221 198 minecraft:nether_bricks
fill 284 221 206 294 221 209 minecraft:nether_bricks
fill 285 221 193 321 221 194 minecraft:nether_bricks
fill 285 221 210 297 221 211 minecraft:nether_bricks
fill 286 221 192 320 221 192 minecraft:nether_bricks
fill 286 221 212 301 221 212 minecraft:nether_bricks
fill 287 221 190 319 221 190 minecraft:nether_bricks
fill 287 221 214 319 221 214 minecraft:nether_bricks
fill 288 221 189 318 221 189 minecraft:nether_bricks
fill 288 221 215 318 221 215 minecraft:nether_bricks
fill 289 221 188 317 221 188 minecraft:nether_bricks
fill 289 221 216 317 221 216 minecraft:nether_bricks
fill 290 221 187 316 221 187 minecraft:nether_bricks
fill 290 221 217 316 221 217 minecraft:nether_bricks
fill 291 221 186 315 221 186 minecraft:nether_bricks
fill 291 221 218 315 221 218 minecraft:nether_bricks
fill 292 221 185 314 221 185 minecraft:nether_bricks
fill 292 221 219 314 221 219 minecraft:nether_bricks
fill 294 221 184 312 221 184 minecraft:nether_bricks
fill 294 221 220 312 221 220 minecraft:nether_bricks
fill 295 221 199 295 221 202 minecraft:nether_bricks
fill 295 221 203 295 221 206 minecraft:magma_block
fill 295 221 207 295 221 209 minecraft:nether_bricks
fill 296 221 183 310 221 183 minecraft:nether_bricks
fill 296 221 199 296 221 200 minecraft:nether_bricks
fill 296 221 201 296 221 202 minecraft:magma_block
fill 296 221 207 296 221 208 minecraft:magma_block
setblock 296 221 209 minecraft:nether_bricks
fill 296 221 221 310 221 221 minecraft:nether_bricks
fill 297 221 199 297 221 200 minecraft:magma_block
setblock 297 221 209 minecraft:magma_block
fill 298 221 195 299 221 197 minecraft:nether_bricks
fill 298 221 198 298 221 199 minecraft:magma_block
setblock 298 221 210 minecraft:magma_block
setblock 298 221 211 minecraft:nether_bricks
fill 299 221 198 300 221 198 minecraft:magma_block
fill 299 221 211 301 221 211 minecraft:magma_block
fill 300 221 182 306 221 182 minecraft:nether_bricks
fill 300 221 195 322 221 196 minecraft:nether_bricks
fill 300 221 197 305 221 197 minecraft:magma_block
fill 300 221 222 306 221 222 minecraft:nether_bricks
fill 302 221 212 303 222 212 minecraft:magma_block
fill 304 221 198 307 221 198 minecraft:magma_block
fill 304 221 211 305 221 211 minecraft:magma_block
fill 304 221 212 320 221 212 minecraft:nether_bricks
fill 306 221 197 322 221 197 minecraft:nether_bricks
fill 306 221 210 307 221 210 minecraft:magma_block
fill 306 221 211 321 221 211 minecraft:nether_bricks
fill 307 221 199 308 221 199 minecraft:magma_block
fill 308 221 198 322 221 198 minecraft:nether_bricks
setblock 308 221 200 minecraft:magma_block
fill 308 221 208 308 221 209 minecraft:magma_block
fill 308 221 210 321 221 210 minecraft:nether_bricks
fill 309 221 199 323 221 200 minecraft:nether_bricks
fill 309 221 201 309 221 207 minecraft:magma_block
fill 309 221 208 322 221 209 minecraft:nether_bricks
fill 310 221 201 323 221 202 minecraft:nether_bricks
fill 310 221 203 310 221 205 minecraft:magma_block
fill 310 221 206 322 221 207 minecraft:nether_bricks
fill 311 221 203 323 221 205 minecraft:nether_bricks
fill 283 222 183 283 222 186 minecraft:red_nether_bricks
setblock 283 222 187 minecraft:polished_blackstone
fill 283 222 188 283 222 191 minecraft:red_nether_bricks
fill 283 222 205 283 222 206 minecraft:red_nether_bricks
setblock 283 222 207 minecraft:polished_blackstone
fill 283 222 208 283 222 211 minecraft:red_nether_bricks
setblock 283 222 212 minecraft:polished_blackstone
fill 283 222 213 283 222 216 minecraft:red_nether_bricks
setblock 283 222 217 minecraft:polished_blackstone
fill 283 222 218 283 222 221 minecraft:red_nether_bricks
setblock 283 222 222 minecraft:polished_blackstone
fill 284 222 182 287 222 182 minecraft:red_nether_bricks
fill 284 222 198 293 222 206 minecraft:nether_bricks
fill 284 222 207 284 222 210 minecraft:red_nether_bricks
setblock 284 222 211 minecraft:polished_blackstone
fill 284 222 212 284 222 215 minecraft:red_nether_bricks
setblock 284 222 216 minecraft:polished_blackstone
fill 284 222 217 284 224 218 minecraft:red_nether_bricks
fill 284 222 222 287 222 222 minecraft:red_nether_bricks
fill 285 222 195 297 222 197 minecraft:nether_bricks
fill 285 222 207 294 222 209 minecraft:nether_bricks
setblock 285 222 210 minecraft:polished_blackstone
fill 285 222 211 285 222 214 minecraft:red_nether_bricks
setblock 285 222 215 minecraft:polished_blackstone
fill 286 222 193 320 222 194 minecraft:nether_bricks
fill 286 222 210 296 222 211 minecraft:nether_bricks
fill 286 222 212 286 223 212 minecraft:red_nether_bricks
fill 287 222 191 319 222 192 minecraft:nether_bricks
fill 287 222 212 299 222 213 minecraft:nether_bricks
setblock 288 222 182 minecraft:polished_blackstone
fill 288 222 190 318 222 190 minecraft:nether_bricks
fill 288 222 214 318 222 214 minecraft:nether_bricks
setblock 288 222 222 minecraft:polished_blackstone
setblock 289 222 182 minecraft:red_nether_bricks
fill 289 222 189 317 222 189 minecraft:nether_bricks
fill 289 222 215 317 222 215 minecraft:nether_bricks
fill 289 222 222 290 222 222 minecraft:red_nether_bricks
fill 290 222 188 316 222 188 minecraft:nether_bricks
fill 290 222 216 316 222 216 minecraft:nether_bricks
fill 291 222 187 315 222 187 minecraft:nether_bricks
fill 291 222 217 315 222 217 minecraft:nether_bricks
fill 292 222 186 314 222 186 minecraft:nether_bricks
fill 292 222 218 314 222 218 minecraft:nether_bricks
fill 294 222 185 312 222 185 minecraft:nether_bricks
fill 294 222 198 294 222 202 minecraft:nether_bricks
fill 294 222 203 294 223 205 minecraft:magma_block
setblock 294 222 206 minecraft:nether_bricks
fill 294 222 219 312 222 219 minecraft:nether_bricks
fill 295 222 198 295 222 199 minecraft:nether_bricks
fill 295 222 200 295 222 202 minecraft:magma_block
fill 295 222 206 295 222 207 minecraft:magma_block
fill 295 222 208 295 222 209 minecraft:nether_bricks
fill 296 222 184 310 222 184 minecraft:nether_bricks
setblock 296 222 198 minecraft:nether_bricks
fill 296 222 199 296 222 200 minecraft:magma_block
fill 296 222 208 296 222 209 minecraft:magma_block
fill 296 222 220 310 222 220 minecraft:nether_bricks
setblock 297 222 198 minecraft:magma_block
setblock 297 222 210 minecraft:magma_block
setblock 297 222 211 minecraft:nether_bricks
fill 298 222 195 298 222 196 minecraft:nether_bricks
fill 298 222 197 299 222 197 minecraft:magma_block
fill 298 222 211 299 222 211 minecraft:magma_block
fill 299 222 183 307 222 183 minecraft:nether_bricks
fill 299 222 195 301 222 195 minecraft:nether_bricks
fill 299 222 196 306 222 196 minecraft:magma_block
fill 299 222 221 307 222 221 minecraft:nether_bricks
fill 300 222 212 301 223 212 minecraft:magma_block
fill 300 222 213 319 222 213 minecraft:nether_bricks
fill 302 222 195 303 222 195 minecraft:magma_block
fill 304 222 195 321 222 195 minecraft:nether_bricks
fill 304 222 212 305 222 212 minecraft:magma_block
fill 305 222 182 307 222 182 minecraft:red_nether_bricks
fill 306 222 197 308 222 197 minecraft:magma_block
fill 306 222 211 307 222 211 minecraft:magma_block
fill 306 222 212 319 222 212 minecraft:nether_bricks
fill 307 222 196 321 222 196 minecraft:nether_bricks
setblock 308 222 182 minecraft:polished_blackstone
fill 308 222 183 311 222 183 minecraft:red_nether_bricks
fill 308 222 198 309 222 198 minecraft:magma_block
setblock 308 222 210 minecraft:magma_block
fill 308 222 211 320 222 211 minecraft:nether_bricks
fill 309 222 182 312 222 182 minecraft:red_nether_bricks
fill 309 222 197 321 222 197 minecraft:nether_bricks
fill 309 222 199 309 222 200 minecraft:magma_block
fill 309 222 208 309 222 209 minecraft:magma_block
fill 309 222 210 320 222 210 minecraft:nether_bricks
fill 310 222 198 322 222 199 minecraft:nether_bricks
fill 310 222 200 310 222 202 minecraft:magma_block
fill 310 222 206 310 222 207 minecraft:magma_block
fill 310 222 208 321 222 209 minecraft:nether_bricks
fill 311 222 200 322 222 201 minecraft:nether_bricks
fill 311 222 202 311 222 205 minecraft:magma_block
fill 311 222 206 321 222 207 minecraft:nether_bricks
setblock 312 222 183 minecraft:polished_blackstone
fill 312 222 202 322 222 205 minecraft:nether_bricks
setblock 313 222 182 minecraft:polished_blackstone
setblock 313 222 183 minecraft:red_nether_bricks
fill 314 222 182 315 222 182 minecraft:red_nether_bricks
fill 321 222 182 322 222 182 minecraft:red_nether_bricks
fill 322 222 185 322 222 187 minecraft:red_nether_bricks
setblock 322 222 188 minecraft:polished_blackstone
fill 322 222 189 323 223 190 minecraft:red_nether_bricks
setblock 322 222 206 minecraft:nether_bricks
setblock 323 222 182 minecraft:polished_blackstone
fill 323 222 183 323 222 186 minecraft:red_nether_bricks
setblock 323 222 187 minecraft:polished_blackstone
fill 323 222 188 323 225 188 minecraft:red_nether_bricks
setblock 323 222 191 minecraft:red_nether_bricks
setblock 323 222 192 minecraft:polished_blackstone
fill 323 222 193 323 225 193 minecraft:red_nether_bricks
fill 323 222 208 323 222 211 minecraft:red_nether_bricks
setblock 323 222 212 minecraft:polished_blackstone
fill 323 222 213 323 222 216 minecraft:red_nether_bricks
fill 283 223 184 283 223 185 minecraft:red_nether_bricks
setblock 283 223 186 minecraft:polished_blackstone
fill 283 223 187 283 223 190 minecraft:red_nether_bricks
setblock 283 223 191 minecraft:polished_blackstone
fill 283 223 192 283 226 192 minecraft:red_nether_bricks
setblock 283 223 206 minecraft:polished_blackstone
fill 283 223 207 283 223 210 minecraft:red_nether_bricks
setblock 283 223 211 minecraft:polished_blackstone
fill 283 223 212 283 223 215 minecraft:red_nether_bricks
setblock 283 223 216 minecraft:polished_blackstone
fill 283 223 217 283 223 220 minecraft:red_nether_bricks
setblock 283 223 221 minecraft:polished_blackstone
fill 283 223 222 286 223 222 minecraft:red_nether_bricks
fill 284 223 207 284 223 209 minecraft:red_nether_bricks
setblock 284 223 210 minecraft:polished_blackstone
fill 284 223 211 284 223 214 minecraft:red_nether_bricks
setblock 284 223 215 minecraft:polished_blackstone
fill 284 223 216 285 225 216 minecraft:red_nether_bricks
fill 285 223 197 293 223 207 minecraft:nether_bricks
setblock 285 223 208 minecraft:red_nether_bricks
setblock 285 223 209 minecraft:polished_blackstone
fill 285 223 210 285 223 213 minecraft:red_nether_bricks
setblock 285 223 214 minecraft:polished_blackstone
fill 285 223 215 285 226 215 minecraft:red_nether_bricks
setblock 286 223 182 minecraft:red_nether_bricks
fill 286 223 194 296 223 196 minecraft:nether_bricks
fill 286 223 208 294 223 210 minecraft:nether_bricks
fill 286 223 211 286 224 211 minecraft:red_nether_bricks
setblock 286 223 213 minecraft:polished_blackstone
setblock 287 223 182 minecraft:polished_blackstone
fill 287 223 193 319 223 193 minecraft:nether_bricks
fill 287 223 211 296 223 211 minecraft:nether_bricks
setblock 287 223 222 minecraft:polished_blackstone
fill 288 223 191 318 223 192 minecraft:nether_bricks
fill 288 223 212 298 223 213 minecraft:nether_bricks
fill 288 223 222 289 224 222 minecraft:red_nether_bricks
fill 289 223 190 317 223 190 minecraft:nether_bricks
fill 289 223 214 317 223 214 minecraft:nether_bricks
fill 290 223 189 316 223 189 minecraft:nether_bricks
fill 290 223 215 316 223 215 minecraft:nether_bricks
fill 291 223 188 315 223 188 minecraft:nether_bricks
fill 291 223 216 315 223 216 minecraft:nether_bricks
fill 292 223 187 314 223 187 minecraft:nether_bricks
fill 292 223 217 314 223 217 minecraft:nether_bricks
fill 294 223 186 312 223 186 minecraft:nether_bricks
fill 294 223 197 294 223 199 minecraft:nether_bricks
fill 294 223 200 294 223 202 minecraft:magma_block
fill 294 223 206 294 223 207 minecraft:magma_block
fill 294 223 218 312 223 218 minecraft:nether_bricks
fill 295 223 185 311 223 185 minecraft:nether_bricks
setblock 295 223 197 minecraft:nether_bricks
fill 295 223 198 295 223 199 minecraft:magma_block
fill 295 223 208 295 223 209 minecraft:magma_block
fill 295 223 210 295 224 210 minecraft:nether_bricks
fill 295 223 219 311 223 219 minecraft:nether_bricks
fill 296 223 197 296 223 198 minecraft:magma_block
fill 296 223 210 296 224 210 minecraft:magma_block
fill 297 223 194 297 223 195 minecraft:nether_bricks
fill 297 223 196 297 223 197 minecraft:magma_block
fill 297 223 211 298 223 211 minecraft:magma_block
fill 298 223 184 308 223 184 minecraft:nether_bricks
fill 298 223 194 299 223 194 minecraft:nether_bricks
fill 298 223 195 298 223 196 minecraft:magma_block
fill 298 223 220 308 223 220 minecraft:nether_bricks
fill 299 223 195 301 223 195 minecraft:magma_block
fill 299 223 212 299 224 212 minecraft:magma_block
fill 299 223 213 301 223 213 minecraft:nether_bricks
fill 300 223 194 305 223 194 minecraft:magma_block
fill 302 223 213 304 224 213 minecraft:magma_block
fill 304 223 195 307 223 195 minecraft:magma_block
fill 305 223 212 306 223 212 minecraft:magma_block
fill 305 223 213 318 223 213 minecraft:nether_bricks
setblock 306 223 182 minecraft:red_nether_bricks
fill 306 223 194 320 223 194 minecraft:nether_bricks
setblock 307 223 182 minecraft:polished_blackstone
fill 307 223 183 310 223 183 minecraft:red_nether_bricks
fill 307 223 196 309 223 196 minecraft:magma_block
fill 307 223 211 308 223 211 minecraft:magma_block
fill 307 223 212 318 223 212 minecraft:nether_bricks
fill 308 223 182 311 223 182 minecraft:red_nether_bricks
fill 308 223 195 320 223 195 minecraft:nether_bricks
fill 309 223 197 310 223 197 minecraft:magma_block
setblock 309 223 210 minecraft:magma_block
fill 309 223 211 319 223 211 minecraft:nether_bricks
fill 310 223 196 320 223 196 minecraft:nether_bricks
fill 310 223 198 310 223 199 minecraft:magma_block
fill 310 223 208 310 223 209 minecraft:magma_block
fill 310 223 210 320 223 210 minecraft:nether_bricks
setblock 311 223 183 minecraft:polished_blackstone
fill 311 223 197 321 223 198 minecraft:nether_bricks
fill 311 223 199 311 223 201 minecraft:magma_block
fill 311 223 206 311 223 207 minecraft:magma_block
fill 311 223 208 320 223 209 minecraft:nether_bricks
setblock 312 223 182 minecraft:polished_blackstone
fill 312 223 199 321 223 200 minecraft:nether_bricks
fill 312 223 201 312 223 205 minecraft:magma_block
fill 312 223 206 321 223 207 minecraft:nether_bricks
setblock 313 223 182 minecraft:red_nether_bricks
fill 313 223 201 321 223 205 minecraft:nether_bricks
setblock 322 223 182 minecraft:polished_blackstone
setblock 322 223 186 minecraft:red_nether_bricks
setblock 322 223 187 minecraft:polished_blackstone
fill 322 223 188 322 226 188 minecraft:red_nether_bricks
fill 323 223 182 323 223 185 minecraft:red_nether_bricks
setblock 323 223 186 minecraft:polished_blackstone
fill 323 223 187 323 226 187 minecraft:red_nether_bricks
setblock 323 223 191 minecraft:polished_blackstone
fill 323 223 192 323 226 192 minecraft:red_nether_bricks
fill 323 223 208 323 223 210 minecraft:red_nether_bricks
setblock 323 223 211 minecraft:polished_blackstone
fill 323 223 212 323 223 215 minecraft:red_nether_bricks
setblock 323 223 216 minecraft:polished_blackstone
fill 323 223 217 323 224 219 minecraft:red_nether_bricks
setblock 283 224 185 minecraft:polished_blackstone
fill 283 224 186 283 224 189 minecraft:red_nether_bricks
setblock 283 224 190 minecraft:polished_blackstone
fill 283 224 191 283 227 191 minecraft:red_nether_bricks
fill 283 224 193 283 225 193 minecraft:red_nether_bricks
fill 283 224 206 283 224 209 minecraft:red_nether_bricks
setblock 283 224 210 minecraft:polished_blackstone
fill 283 224 211 283 224 214 minecraft:red_nether_bricks
setblock 283 224 215 minecraft:polished_blackstone
fill 283 224 216 283 224 219 minecraft:red_nether_bricks
setblock 283 224 220 minecraft:polished_blackstone
fill 283 224 221 283 226 222 minecraft:red_nether_bricks
fill 284 224 207 284 224 208 minecraft:red_nether_bricks
setblock 284 224 209 minecraft:polished_blackstone
fill 284 224 210 284 224 213 minecraft:red_nether_bricks
setblock 284 224 214 minecraft:polished_blackstone
fill 284 224 215 284 227 215 minecraft:red_nether_bricks
setblock 284 224 219 minecraft:polished_blackstone
fill 284 224 222 285 224 222 minecraft:red_nether_bricks
setblock 285 224 208 minecraft:polished_blackstone
fill 285 224 209 285 224 212 minecraft:red_nether_bricks
setblock 285 224 213 minecraft:polished_blackstone
fill 285 224 214 286 226 214 minecraft:red_nether_bricks
setblock 285 224 217 minecraft:red_nether_bricks
fill 286 224 197 292 224 207 minecraft:nether_bricks
setblock 286 224 212 minecraft:polished_blackstone
fill 286 224 213 286 227 213 minecraft:red_nether_bricks
setblock 286 224 222 minecraft:polished_blackstone
fill 287 224 194 294 224 196 minecraft:nether_bricks
fill 287 224 208 293 224 210 minecraft:nether_bricks
fill 287 224 222 287 227 222 minecraft:red_nether_bricks
fill 288 224 193 298 224 193 minecraft:nether_bricks
fill 288 224 211 296 224 211 minecraft:nether_bricks
fill 289 224 191 317 224 192 minecraft:nether_bricks
fill 289 224 212 297 224 213 minecraft:nether_bricks
fill 290 224 190 316 224 190 minecraft:nether_bricks
fill 290 224 214 316 224 214 minecraft:nether_bricks
fill 291 224 189 315 224 189 minecraft:nether_bricks
fill 291 224 215 315 224 215 minecraft:nether_bricks
fill 292 224 188 314 224 188 minecraft:nether_bricks
fill 292 224 216 314 224 216 minecraft:nether_bricks
fill 293 224 197 293 224 198 minecraft:nether_bricks
fill 293 224 199 293 224 207 minecraft:magma_block
fill 294 224 187 312 224 187 minecraft:nether_bricks
fill 294 224 197 294 224 199 minecraft:magma_block
setblock 294 224 208 minecraft:magma_block
fill 294 224 209 294 224 210 minecraft:nether_bricks
fill 294 224 217 312 224 217 minecraft:nether_bricks
fill 295 224 186 311 224 186 minecraft:nether_bricks
fill 295 224 194 295 224 195 minecraft:nether_bricks
fill 295 224 196 295 224 197 minecraft:magma_block
setblock 295 224 209 minecraft:magma_block
fill 295 224 218 311 224 218 minecraft:nether_bricks
setblock 296 224 194 minecraft:nether_bricks
fill 296 224 195 296 224 196 minecraft:magma_block
fill 297 224 194 297 224 195 minecraft:magma_block
setblock 297 224 211 minecraft:magma_block
fill 298 224 185 308 224 185 minecraft:nether_bricks
fill 298 224 194 299 224 194 minecraft:magma_block
setblock 298 224 212 minecraft:magma_block
fill 298 224 213 299 224 213 minecraft:nether_bricks
fill 298 224 219 308 224 219 minecraft:nether_bricks
fill 299 224 193 307 224 193 minecraft:magma_block
fill 300 224 213 301 224 213 minecraft:magma_block
fill 305 224 213 306 225 213 minecraft:magma_block
setblock 306 224 182 minecraft:polished_blackstone
fill 306 224 194 308 224 194 minecraft:magma_block
fill 307 224 182 310 224 182 minecraft:red_nether_bricks
fill 307 224 212 308 224 212 minecraft:magma_block
fill 307 224 213 317 224 213 minecraft:nether_bricks
fill 308 224 193 318 224 193 minecraft:nether_bricks
fill 308 224 195 310 224 195 minecraft:magma_block
fill 309 224 194 319 224 194 minecraft:nether_bricks
setblock 309 224 211 minecraft:magma_block
fill 309 224 212 317 224 212 minecraft:nether_bricks
setblock 310 224 196 minecraft:magma_block
setblock 310 224 210 minecraft:magma_block
fill 310 224 211 318 224 211 minecraft:nether_bricks
setblock 311 224 182 minecraft:polished_blackstone
fill 311 224 195 319 224 196 minecraft:nether_bricks
fill 311 224 197 311 224 198 minecraft:magma_block
fill 311 224 208 311 224 209 minecraft:magma_block
fill 311 224 210 319 224 210 minecraft:nether_bricks
setblock 312 224 182 minecraft:red_nether_bricks
fill 312 224 197 320 224 197 minecraft:nether_bricks
fill 312 224 198 312 224 200 minecraft:magma_block
fill 312 224 206 312 224 207 minecraft:magma_block
fill 312 224 208 319 224 209 minecraft:nether_bricks
fill 313 224 198 320 224 199 minecraft:nether_bricks
fill 313 224 200 313 224 205 minecraft:magma_block
fill 313 224 206 320 224 207 minecraft:nether_bricks
fill 314 224 200 320 224 205 minecraft:nether_bricks
fill 322 224 182 323 226 182 minecraft:red_nether_bricks
fill 322 224 187 322 227 187 minecraft:red_nether_bricks
fill 322 224 189 322 224 190 minecraft:red_nether_bricks
fill 323 224 183 323 224 184 minecraft:red_nether_bricks
setblock 323 224 185 minecraft:polished_blackstone
fill 323 224 186 323 227 186 minecraft:red_nether_bricks
setblock 323 224 189 minecraft:red_nether_bricks
setblock 323 224 190 minecraft:polished_blackstone
fill 323 224 191 323 227 191 minecraft:red_nether_bricks
setblock 323 224 194 minecraft:red_nether_bricks
fill 323 224 208 323 224 209 minecraft:red_nether_bricks
setblock 323 224 210 minecraft:polished_blackstone
fill 323 224 211 323 224 214 minecraft:red_nether_bricks
setblock 323 224 215 minecraft:polished_blackstone
fill 323 224 216 323 227 216 minecraft:red_nether_bricks
setblock 323 224 220 minecraft:polished_blackstone
fill 323 224 221 323 226 222 minecraft:red_nether_bricks
fill 283 225 186 283 225 188 minecraft:red_nether_bricks
setblock 283 225 189 minecraft:polished_blackstone
fill 283 225 190 283 228 190 minecraft:red_nether_bricks
setblock 283 225 194 minecraft:polished_blackstone
fill 283 225 195 283 228 195 minecraft:red_nether_bricks
fill 283 225 205 283 225 208 minecraft:red_nether_bricks
setblock 283 225 209 minecraft:polished_blackstone
fill 283 225 210 283 225 213 minecraft:red_nether_bricks
setblock 283 225 214 minecraft:polished_blackstone
fill 283 225 215 283 225 218 minecraft:red_nether_bricks
setblock 283 225 219 minecraft:polished_blackstone
fill 283 225 220 284 227 220 minecraft:red_nether_bricks
setblock 284 225 207 minecraft:red_nether_bricks
setblock 284 225 208 minecraft:polished_blackstone
fill 284 225 209 284 225 212 minecraft:red_nether_bricks
setblock 284 225 213 minecraft:polished_blackstone
fill 284 225 214 284 228 214 minecraft:red_nether_bricks
setblock 284 225 217 minecraft:red_nether_bricks
setblock 284 225 218 minecraft:polished_blackstone
fill 284 225 219 284 228 219 minecraft:red_nether_bricks
setblock 284 225 222 minecraft:red_nether_bricks
fill 285 225 208 285 225 211 minecraft:red_nether_bricks
setblock 285 225 212 minecraft:polished_blackstone
fill 285 225 213 285 228 213 minecraft:red_nether_bricks
setblock 285 225 217 minecraft:polished_blackstone
fill 285 225 218 285 228 218 minecraft:red_nether_bricks
setblock 285 225 221 minecraft:red_nether_bricks
setblock 285 225 222 minecraft:polished_blackstone
setblock 286 225 211 minecraft:polished_blackstone
fill 286 225 212 286 228 212 minecraft:red_nether_bricks
setblock 286 225 215 minecraft:red_nether_bricks
fill 286 225 222 286 228 222 minecraft:red_nether_bricks
fill 287 225 197 291 225 207 minecraft:nether_bricks
fill 288 225 195 293 225 196 minecraft:nether_bricks
fill 288 225 208 292 225 209 minecraft:nether_bricks
fill 288 225 222 288 226 222 minecraft:red_nether_bricks
fill 289 225 193 294 225 194 minecraft:nether_bricks
fill 289 225 210 294 225 211 minecraft:nether_bricks
fill 290 225 192 297 225 192 minecraft:nether_bricks
fill 290 225 212 296 225 212 minecraft:nether_bricks
fill 291 225 191 300 225 191 minecraft:nether_bricks
fill 291 225 213 297 225 213 minecraft:nether_bricks
fill 292 225 190 314 225 190 minecraft:nether_bricks
fill 292 225 197 292 225 198 minecraft:nether_bricks
fill 292 225 199 292 225 206 minecraft:magma_block
setblock 292 225 207 minecraft:nether_bricks
fill 292 225 214 300 225 214 minecraft:nether_bricks
fill 293 225 189 313 225 189 minecraft:nether_bricks
fill 293 225 197 293 225 198 minecraft:magma_block
fill 293 225 207 293 225 208 minecraft:magma_block
setblock 293 225 209 minecraft:nether_bricks
fill 293 225 215 313 225 215 minecraft:nether_bricks
fill 294 225 188 312 225 188 minecraft:nether_bricks
fill 294 225 195 294 225 196 minecraft:magma_block
setblock 294 225 209 minecraft:magma_block
fill 294 225 216 312 225 216 minecraft:nether_bricks
fill 295 225 193 296 225 193 minecraft:nether_bricks
fill 295 225 194 295 225 195 minecraft:magma_block
setblock 295 225 210 minecraft:magma_block
setblock 295 225 211 minecraft:nether_bricks
fill 296 225 187 310 225 187 minecraft:nether_bricks
setblock 296 225 194 minecraft:magma_block
setblock 296 225 211 minecraft:magma_block
fill 296 225 217 310 225 217 minecraft:nether_bricks
fill 297 225 193 298 225 193 minecraft:magma_block
setblock 297 225 212 minecraft:magma_block
fill 298 225 186 308 225 186 minecraft:nether_bricks
fill 298 225 192 308 225 192 minecraft:magma_block
fill 298 225 213 300 225 213 minecraft:magma_block
fill 298 225 218 308 225 218 minecraft:nether_bricks
fill 301 225 191 305 225 191 minecraft:magma_block
fill 301 225 214 304 226 214 minecraft:magma_block
setblock 305 225 182 minecraft:polished_blackstone
fill 305 225 214 314 225 214 minecraft:nether_bricks
fill 306 225 182 309 225 182 minecraft:red_nether_bricks
fill 306 225 191 315 225 191 minecraft:nether_bricks
fill 307 225 213 307 226 213 minecraft:magma_block
fill 308 225 193 309 225 193 minecraft:magma_block
fill 308 225 212 309 225 212 minecraft:magma_block
fill 308 225 213 315 225 213 minecraft:nether_bricks
fill 309 225 192 316 225 192 minecraft:nether_bricks
fill 309 225 194 311 225 194 minecraft:magma_block
setblock 310 225 182 minecraft:polished_blackstone
fill 310 225 193 317 225 193 minecraft:nether_bricks
setblock 310 225 211 minecraft:magma_block
fill 310 225 212 316 225 212 minecraft:nether_bricks
fill 311 225 182 311 228 182 minecraft:red_nether_bricks
fill 311 225 195 311 225 196 minecraft:magma_block
setblock 311 225 210 minecraft:magma_block
fill 311 225 211 317 225 211 minecraft:nether_bricks
fill 312 225 194 317 225 195 minecraft:nether_bricks
fill 312 225 196 312 225 197 minecraft:magma_block
fill 312 225 208 312 225 209 minecraft:magma_block
fill 312 225 210 317 225 210 minecraft:nether_bricks
fill 313 225 196 318 225 196 minecraft:nether_bricks
fill 313 225 197 313 225 199 minecraft:magma_block
fill 313 225 206 313 225 207 minecraft:magma_block
fill 313 225 208 318 225 209 minecraft:nether_bricks
fill 314 225 197 319 225 199 minecraft:nether_bricks
fill 314 225 200 314 225 205 minecraft:magma_block
fill 314 225 206 319 225 207 minecraft:nether_bricks
fill 315 225 200 319 225 205 minecraft:nether_bricks
setblock 318 225 195 minecraft:nether_bricks
setblock 322 225 189 minecraft:red_nether_bricks
setblock 322 225 190 minecraft:polished_blackstone
fill 322 225 191 322 228 191 minecraft:red_nether_bricks
fill 322 225 213 322 225 214 minecraft:red_nether_bricks
setblock 322 225 215 minecraft:polished_blackstone
fill 322 225 216 322 228 216 minecraft:red_nether_bricks
fill 322 225 222 322 227 222 minecraft:red_nether_bricks
setblock 323 225 183 minecraft:red_nether_bricks
setblock 323 225 184 minecraft:polished_blackstone
fill 323 225 185 323 228 185 minecraft:red_nether_bricks
setblock 323 225 189 minecraft:polished_blackstone
fill 323 225 190 323 228 190 minecraft:red_nether_bricks
setblock 323 225 194 minecraft:polished_blackstone
fill 323 225 195 323 228 195 minecraft:red_nether_bricks
setblock 323 225 208 minecraft:red_nether_bricks
setblock 323 225 209 minecraft:polished_blackstone
fill 323 225 210 323 225 213 minecraft:red_nether_bricks
setblock 323 225 214 minecraft:polished_blackstone
fill 323 225 215 323 228 215 minecraft:red_nether_bricks
fill 323 225 217 323 225 218 minecraft:red_nether_bricks
setblock 323 225 219 minecraft:polished_blackstone
fill 323 225 220 323 228 220 minecraft:red_nether_bricks
fill 283 226 186 283 226 187 minecraft:red_nether_bricks
setblock 283 226 188 minecraft:polished_blackstone
fill 283 226 189 283 229 189 minecraft:red_nether_bricks
setblock 283 226 193 minecraft:polished_blackstone
fill 283 226 194 284 228 194 minecraft:red_nether_bricks
fill 283 226 196 283 226 197 minecraft:red_nether_bricks
fill 283 226 205 283 226 207 minecraft:red_nether_bricks
setblock 283 226 208 minecraft:polished_blackstone
fill 283 226 209 283 226 212 minecraft:red_nether_bricks
setblock 283 226 213 minecraft:polished_blackstone
fill 283 226 214 283 226 217 minecraft:red_nether_bricks
setblock 283 226 218 minecraft:polished_blackstone
fill 283 226 219 283 229 219 minecraft:red_nether_bricks
fill 284 226 190 284 226 191 minecraft:red_nether_bricks
setblock 284 226 192 minecraft:polished_blackstone
fill 284 226 193 284 229 193 minecraft:red_nether_bricks
setblock 284 226 206 minecraft:red_nether_bricks
setblock 284 226 207 minecraft:polished_blackstone
fill 284 226 208 284 226 211 minecraft:red_nether_bricks
setblock 284 226 212 minecraft:polished_blackstone
fill 284 226 213 284 229 213 minecraft:red_nether_bricks
setblock 284 226 216 minecraft:red_nether_bricks
setblock 284 226 217 minecraft:polished_blackstone
fill 284 226 218 284 229 218 minecraft:red_nether_bricks
setblock 284 226 221 minecraft:red_nether_bricks
setblock 284 226 222 minecraft:polished_blackstone
fill 285 226 208 285 226 210 minecraft:red_nether_bricks
setblock 285 226 211 minecraft:polished_blackstone
fill 285 226 212 285 229 212 minecraft:red_nether_bricks
setblock 285 226 216 minecraft:polished_blackstone
fill 285 226 217 285 229 217 minecraft:red_nether_bricks
fill 285 226 219 285 227 219 minecraft:red_nether_bricks
setblock 285 226 221 minecraft:polished_blackstone
fill 285 226 222 285 229 222 minecraft:red_nether_bricks
setblock 286 226 210 minecraft:polished_blackstone
fill 286 226 211 286 229 211 minecraft:red_nether_bricks
setblock 286 226 215 minecraft:polished_blackstone
fill 286 226 216 286 229 216 minecraft:red_nether_bricks
fill 286 226 221 287 228 221 minecraft:red_nether_bricks
fill 288 226 200 290 226 204 minecraft:nether_bricks
fill 289 226 197 290 226 199 minecraft:nether_bricks
fill 289 226 205 290 226 207 minecraft:nether_bricks
fill 290 226 195 292 226 196 minecraft:nether_bricks
fill 290 226 208 291 226 209 minecraft:nether_bricks
fill 291 226 193 293 226 194 minecraft:nether_bricks
fill 291 226 197 291 226 198 minecraft:nether_bricks
fill 291 226 199 291 226 205 minecraft:magma_block
fill 291 226 206 291 226 207 minecraft:nether_bricks
fill 291 226 210 293 226 211 minecraft:nether_bricks
fill 292 226 192 296 226 192 minecraft:nether_bricks
fill 292 226 197 292 226 198 minecraft:magma_block
fill 292 226 206 292 226 208 minecraft:magma_block
setblock 292 226 209 minecraft:nether_bricks
fill 292 226 212 295 226 212 minecraft:nether_bricks
fill 293 226 191 297 226 191 minecraft:nether_bricks
fill 293 226 195 293 226 196 minecraft:magma_block
setblock 293 226 209 minecraft:magma_block
fill 293 226 213 296 226 213 minecraft:nether_bricks
fill 294 226 190 300 226 190 minecraft:nether_bricks
setblock 294 226 193 minecraft:nether_bricks
setblock 294 226 194 minecraft:magma_block
setblock 294 226 210 minecraft:magma_block
setblock 294 226 211 minecraft:nether_bricks
fill 294 226 214 298 226 214 minecraft:nether_bricks
fill 295 226 193 296 226 193 minecraft:magma_block
setblock 295 226 211 minecraft:magma_block
fill 296 226 189 310 226 189 minecraft:nether_bricks
setblock 296 226 212 minecraft:magma_block
fill 296 226 215 310 226 215 minecraft:nether_bricks
setblock 297 226 192 minecraft:magma_block
fill 297 226 213 298 226 213 minecraft:magma_block
fill 298 226 188 308 226 188 minecraft:nether_bricks
fill 298 226 191 300 226 191 minecraft:magma_block
fill 298 226 216 308 226 216 minecraft:nether_bricks
fill 299 226 214 300 226 214 minecraft:magma_block
fill 301 226 187 305 226 187 minecraft:nether_bricks
fill 301 226 190 305 226 190 minecraft:magma_block
fill 301 226 217 305 226 217 minecraft:nether_bricks
fill 305 226 182 308 226 182 minecraft:red_nether_bricks
fill 305 226 214 306 226 214 minecraft:magma_block
fill 306 226 190 312 226 190 minecraft:nether_bricks
fill 306 226 191 308 226 191 minecraft:magma_block
fill 307 226 214 312 226 214 minecraft:nether_bricks
fill 308 226 213 309 226 213 minecraft:magma_block
setblock 309 226 182 minecraft:polished_blackstone
fill 309 226 191 313 226 191 minecraft:nether_bricks
setblock 309 226 192 minecraft:magma_block
fill 310 226 182 310 229 182 minecraft:red_nether_bricks
fill 310 226 192 314 226 192 minecraft:nether_bricks
fill 310 226 193 311 226 193 minecraft:magma_block
setblock 310 226 212 minecraft:magma_block
fill 310 226 213 313 226 213 minecraft:nether_bricks
setblock 311 226 211 minecraft:magma_block
fill 311 226 212 314 226 212 minecraft:nether_bricks
fill 312 226 193 315 226 193 minecraft:nether_bricks
fill 312 226 194 312 226 195 minecraft:magma_block
setblock 312 226 210 minecraft:magma_block
fill 312 226 211 315 226 211 minecraft:nether_bricks
fill 313 226 194 315 226 195 minecraft:nether_bricks
setblock 313 226 196 minecraft:magma_block
fill 313 226 208 313 226 209 minecraft:magma_block
fill 313 226 210 315 226 210 minecraft:nether_bricks
fill 314 226 196 316 226 196 minecraft:nether_bricks
fill 314 226 197 314 226 199 minecraft:magma_block
fill 314 226 206 314 226 207 minecraft:magma_block
fill 314 226 208 316 226 209 minecraft:nether_bricks
fill 315 226 197 317 226 199 minecraft:nether_bricks
fill 315 226 200 315 226 205 minecraft:magma_block
fill 315 226 206 317 226 207 minecraft:nether_bricks
setblock 316 226 195 minecraft:nether_bricks
fill 316 226 200 317 226 205 minecraft:nether_bricks
fill 318 226 200 318 226 204 minecraft:nether_bricks
fill 321 226 182 321 228 182 minecraft:red_nether_bricks
fill 321 226 222 321 228 222 minecraft:red_nether_bricks
setblock 322 226 189 minecraft:polished_blackstone
fill 322 226 190 322 229 190 minecraft:red_nether_bricks
fill 322 226 192 322 227 192 minecraft:red_nether_bricks
fill 322 226 205 322 231 205 minecraft:magma_block
fill 322 226 211 322 226 213 minecraft:red_nether_bricks
setblock 322 226 214 minecraft:polished_blackstone
fill 322 226 215 322 229 215 minecraft:red_nether_bricks
fill 322 226 217 322 226 218 minecraft:red_nether_bricks
setblock 322 226 219 minecraft:polished_blackstone
setblock 323 226 183 minecraft:polished_blackstone
fill 323 226 184 323 229 184 minecraft:red_nether_bricks
setblock 323 226 188 minecraft:polished_blackstone
fill 323 226 189 323 229 189 minecraft:red_nether_bricks
setblock 323 226 193 minecraft:polished_blackstone
fill 323 226 194 323 229 194 minecraft:red_nether_bricks
fill 323 226 196 323 227 196 minecraft:red_nether_bricks
setblock 323 226 208 minecraft:polished_blackstone
fill 323 226 209 323 226 212 minecraft:red_nether_bricks
setblock 323 226 213 minecraft:polished_blackstone
fill 323 226 214 323 229 214 minecraft:red_nether_bricks
setblock 323 226 217 minecraft:red_nether_bricks
setblock 323 226 218 minecraft:polished_blackstone
fill 323 226 219 323 229 219 minecraft:red_nether_bricks
setblock 283 227 186 minecraft:red_nether_bricks
setblock 283 227 187 minecraft:polished_blackstone
fill 283 227 188 283 230 188 minecraft:red_nether_bricks
setblock 283 227 192 minecraft:polished_blackstone
fill 283 227 193 283 230 193 minecraft:red_nether_bricks
setblock 283 227 196 minecraft:red_nether_bricks
setblock 283 227 197 minecraft:polished_blackstone
fill 283 227 198 283 227 201 minecraft:red_nether_bricks
setblock 283 227 202 minecraft:polished_blackstone
fill 283 227 203 283 227 206 minecraft:red_nether_bricks
setblock 283 227 207 minecraft:polished_blackstone
fill 283 227 208 283 227 211 minecraft:red_nether_bricks
setblock 283 227 212 minecraft:polished_blackstone
fill 283 227 213 283 227 216 minecraft:red_nether_bricks
setblock 283 227 217 minecraft:polished_blackstone
fill 283 227 218 283 230 218 minecraft:red_nether_bricks
setblock 283 227 221 minecraft:red_nether_bricks
setblock 283 227 222 minecraft:polished_blackstone
fill 284 227 189 284 227 190 minecraft:red_nether_bricks
setblock 284 227 191 minecraft:polished_blackstone
fill 284 227 192 284 230 192 minecraft:red_nether_bricks
setblock 284 227 195 minecraft:red_nether_bricks
setblock 284 227 196 minecraft:polished_blackstone
fill 284 227 197 284 230 197 minecraft:red_nether_bricks
setblock 284 227 206 minecraft:polished_blackstone
fill 284 227 207 284 227 210 minecraft:red_nether_bricks
setblock 284 227 211 minecraft:polished_blackstone
fill 284 227 212 284 230 212 minecraft:red_nether_bricks
setblock 284 227 216 minecraft:polished_blackstone
fill 284 227 217 284 230 217 minecraft:red_nether_bricks
setblock 284 227 221 minecraft:polished_blackstone
fill 284 227 222 284 230 222 minecraft:red_nether_bricks
fill 285 227 208 285 227 209 minecraft:red_nether_bricks
setblock 285 227 210 minecraft:polished_blackstone
fill 285 227 211 285 230 211 minecraft:red_nether_bricks
setblock 285 227 214 minecraft:red_nether_bricks
setblock 285 227 215 minecraft:polished_blackstone
fill 285 227 216 285 230 216 minecraft:red_nether_bricks
setblock 285 227 220 minecraft:polished_blackstone
fill 285 227 221 285 230 221 minecraft:red_nether_bricks
fill 286 227 210 286 228 210 minecraft:red_nether_bricks
setblock 286 227 214 minecraft:polished_blackstone
fill 286 227 215 286 230 215 minecraft:red_nether_bricks
fill 286 227 217 286 228 217 minecraft:red_nether_bricks
setblock 288 227 222 minecraft:polished_blackstone
fill 289 227 222 289 230 222 minecraft:red_nether_bricks
fill 304 227 182 307 227 182 minecraft:red_nether_bricks
setblock 308 227 182 minecraft:polished_blackstone
fill 309 227 182 309 230 182 minecraft:red_nether_bricks
fill 320 227 182 320 229 182 minecraft:red_nether_bricks
fill 320 227 205 321 230 205 minecraft:magma_block
fill 320 227 222 320 229 222 minecraft:red_nether_bricks
fill 321 227 204 323 229 204 minecraft:magma_block
fill 321 227 206 323 228 206 minecraft:magma_block
setblock 322 227 182 minecraft:red_nether_bricks
setblock 322 227 188 minecraft:polished_blackstone
fill 322 227 189 322 230 189 minecraft:red_nether_bricks
setblock 322 227 193 minecraft:polished_blackstone
fill 322 227 194 322 230 194 minecraft:red_nether_bricks
fill 322 227 203 322 230 203 minecraft:magma_block
fill 322 227 207 322 230 207 minecraft:magma_block
fill 322 227 211 322 227 212 minecraft:red_nether_bricks
setblock 322 227 213 minecraft:polished_blackstone
fill 322 227 214 322 230 214 minecraft:red_nether_bricks
setblock 322 227 217 minecraft:red_nether_bricks
setblock 322 227 218 minecraft:polished_blackstone
fill 322 227 219 322 228 221 minecraft:red_nether_bricks
setblock 323 227 182 minecraft:polished_blackstone
fill 323 227 183 323 230 183 minecraft:red_nether_bricks
setblock 323 227 187 minecraft:polished_blackstone
fill 323 227 188 323 230 188 minecraft:red_nether_bricks
setblock 323 227 192 minecraft:polished_blackstone
fill 323 227 193 323 230 193 minecraft:red_nether_bricks
setblock 323 227 197 minecraft:polished_blackstone
fill 323 227 198 323 230 198 minecraft:red_nether_bricks
fill 323 227 205 323 228 205 minecraft:magma_block
setblock 323 227 207 minecraft:polished_blackstone
fill 323 227 208 323 227 211 minecraft:red_nether_bricks
setblock 323 227 212 minecraft:polished_blackstone
fill 323 227 213 323 230 213 minecraft:red_nether_bricks
setblock 323 227 217 minecraft:polished_blackstone
fill 323 227 218 323 230 218 minecraft:red_nether_bricks
setblock 323 227 221 minecraft:red_nether_bricks
setblock 323 227 222 minecraft:polished_blackstone
fill 283 228 182 284 230 182 minecraft:red_nether_bricks
setblock 283 228 185 minecraft:red_nether_bricks
setblock 283 228 186 minecraft:polished_blackstone
fill 283 228 187 283 231 187 minecraft:red_nether_bricks
setblock 283 228 191 minecraft:polished_blackstone
fill 283 228 192 283 231 192 minecraft:red_nether_bricks
setblock 283 228 196 minecraft:polished_blackstone
fill 283 228 197 283 228 200 minecraft:red_nether_bricks
setblock 283 228 201 minecraft:polished_blackstone
fill 283 228 202 283 228 205 minecraft:red_nether_bricks
setblock 283 228 206 minecraft:polished_blackstone
fill 283 228 207 283 228 210 minecraft:red_nether_bricks
setblock 283 228 211 minecraft:polished_blackstone
fill 283 228 212 283 228 215 minecraft:red_nether_bricks
setblock 283 228 216 minecraft:polished_blackstone
fill 283 228 217 283 231 217 minecraft:red_nether_bricks
setblock 283 228 220 minecraft:red_nether_bricks
setblock 283 228 221 minecraft:polished_blackstone
fill 283 228 222 283 231 222 minecraft:red_nether_bricks
setblock 284 228 189 minecraft:red_nether_bricks
setblock 284 228 190 minecraft:polished_blackstone
fill 284 228 191 284 231 191 minecraft:red_nether_bricks
setblock 284 228 195 minecraft:polished_blackstone
fill 284 228 196 284 231 196 minecraft:red_nether_bricks
fill 284 228 198 284 228 199 minecraft:red_nether_bricks
setblock 284 228 200 minecraft:polished_blackstone
setblock 284 228 204 minecraft:red_nether_bricks
setblock 284 228 205 minecraft:polished_blackstone
fill 284 228 206 284 228 209 minecraft:red_nether_bricks
setblock 284 228 210 minecraft:polished_blackstone
fill 284 228 211 284 231 211 minecraft:red_nether_bricks
setblock 284 228 215 minecraft:polished_blackstone
fill 284 228 216 284 231 216 minecraft:red_nether_bricks
setblock 284 228 220 minecraft:polished_blackstone
fill 284 228 221 284 231 221 minecraft:red_nether_bricks
setblock 285 228 184 minecraft:light[level=14]
setblock 285 228 192 minecraft:light[level=14]
setblock 285 228 194 minecraft:polished_blackstone
setblock 285 228 200 minecraft:light[level=14]
setblock 285 228 208 minecraft:red_nether_bricks
setblock 285 228 209 minecraft:polished_blackstone
fill 285 228 210 285 231 210 minecraft:red_nether_bricks
setblock 285 228 214 minecraft:polished_blackstone
fill 285 228 215 285 231 215 minecraft:red_nether_bricks
setblock 285 228 219 minecraft:polished_blackstone
fill 285 228 220 286 230 220 minecraft:red_nether_bricks
setblock 286 228 213 minecraft:polished_blackstone
fill 286 228 214 286 231 214 minecraft:red_nether_bricks
setblock 286 228 218 minecraft:polished_blackstone
setblock 287 228 222 minecraft:polished_blackstone
setblock 288 228 221 minecraft:polished_blackstone
fill 288 228 222 288 231 222 minecraft:red_nether_bricks
setblock 293 228 184 minecraft:light[level=14]
setblock 293 228 192 minecraft:light[level=14]
setblock 293 228 200 minecraft:light[level=14]
setblock 293 228 208 minecraft:light[level=14]
setblock 293 228 216 minecraft:light[level=14]
setblock 301 228 184 minecraft:light[level=14]
setblock 301 228 192 minecraft:light[level=14]
setblock 301 228 200 minecraft:light[level=14]
setblock 301 228 208 minecraft:light[level=14]
setblock 301 228 216 minecraft:light[level=14]
setblock 302 228 182 minecraft:polished_blackstone
fill 303 228 182 306 228 182 minecraft:red_nether_bricks
fill 303 228 222 306 228 222 minecraft:red_nether_bricks
setblock 305 228 183 minecraft:red_nether_bricks
setblock 306 228 183 minecraft:polished_blackstone
setblock 307 228 182 minecraft:polished_blackstone
fill 307 228 183 307 231 183 minecraft:red_nether_bricks
setblock 307 228 222 minecraft:polished_blackstone
fill 308 228 182 308 231 182 minecraft:red_nether_bricks
fill 308 228 222 309 230 222 minecraft:red_nether_bricks
setblock 309 228 184 minecraft:light[level=14]
setblock 309 228 192 minecraft:light[level=14]
setblock 309 228 200 minecraft:light[level=14]
setblock 309 228 208 minecraft:light[level=14]
setblock 309 228 216 minecraft:light[level=14]
setblock 317 228 184 minecraft:light[level=14]
setblock 317 228 192 minecraft:light[level=14]
setblock 317 228 200 minecraft:light[level=14]
setblock 317 228 208 minecraft:light[level=14]
setblock 317 228 216 minecraft:light[level=14]
fill 318 228 222 319 230 222 minecraft:red_nether_bricks
fill 319 228 182 319 230 182 minecraft:red_nether_bricks
fill 319 228 204 319 229 206 minecraft:magma_block
fill 320 228 204 320 230 204 minecraft:magma_block
fill 320 228 206 320 230 206 minecraft:magma_block
fill 320 228 221 321 229 221 minecraft:red_nether_bricks
fill 321 228 203 321 229 203 minecraft:magma_block
fill 321 228 207 321 229 207 minecraft:magma_block
fill 321 228 214 321 228 217 minecraft:red_nether_bricks
setblock 321 228 218 minecraft:polished_blackstone
fill 321 228 219 321 231 219 minecraft:red_nether_bricks
setblock 322 228 182 minecraft:polished_blackstone
setblock 322 228 186 minecraft:red_nether_bricks
setblock 322 228 187 minecraft:polished_blackstone
fill 322 228 188 322 231 188 minecraft:red_nether_bricks
setblock 322 228 192 minecraft:polished_blackstone
fill 322 228 193 322 231 193 minecraft:red_nether_bricks
fill 322 228 195 322 228 196 minecraft:red_nether_bricks
fill 322 228 210 322 228 211 minecraft:red_nether_bricks
setblock 322 228 212 minecraft:polished_blackstone
fill 322 228 213 322 231 213 minecraft:red_nether_bricks
setblock 322 228 217 minecraft:polished_blackstone
fill 322 228 218 322 231 218 minecraft:red_nether_bricks
setblock 322 228 222 minecraft:polished_blackstone
fill 323 228 182 323 231 182 minecraft:red_nether_bricks
setblock 323 228 186 minecraft:polished_blackstone
fill 323 228 187 323 231 187 minecraft:red_nether_bricks
setblock 323 228 191 minecraft:polished_blackstone
fill 323 228 192 323 231 192 minecraft:red_nether_bricks
setblock 323 228 196 minecraft:polished_blackstone
fill 323 228 197 323 231 197 minecraft:red_nether_bricks
fill 323 228 199 323 229 199 minecraft:red_nether_bricks
fill 323 228 203 323 229 203 minecraft:magma_block
fill 323 228 207 323 228 210 minecraft:red_nether_bricks
setblock 323 228 211 minecraft:polished_blackstone
fill 323 228 212 323 231 212 minecraft:red_nether_bricks
setblock 323 228 216 minecraft:polished_blackstone
fill 323 228 217 323 231 217 minecraft:red_nether_bricks
setblock 323 228 221 minecraft:polished_blackstone
fill 323 228 222 323 231 222 minecraft:red_nether_bricks
fill 283 229 183 283 229 184 minecraft:red_nether_bricks
setblock 283 229 185 minecraft:polished_blackstone
fill 283 229 186 283 232 186 minecraft:red_nether_bricks
setblock 283 229 190 minecraft:polished_blackstone
fill 283 229 191 283 232 191 minecraft:red_nether_bricks
setblock 283 229 194 minecraft:red_nether_bricks
setblock 283 229 195 minecraft:polished_blackstone
fill 283 229 196 283 229 199 minecraft:red_nether_bricks
setblock 283 229 200 minecraft:polished_blackstone
fill 283 229 201 283 229 204 minecraft:red_nether_bricks
setblock 283 229 205 minecraft:polished_blackstone
fill 283 229 206 283 229 209 minecraft:red_nether_bricks
setblock 283 229 210 minecraft:polished_blackstone
fill 283 229 211 283 229 214 minecraft:red_nether_bricks
setblock 283 229 215 minecraft:polished_blackstone
fill 283 229 216 283 232 216 minecraft:red_nether_bricks
setblock 283 229 220 minecraft:polished_blackstone
fill 283 229 221 283 232 221 minecraft:red_nether_bricks
setblock 284 229 189 minecraft:polished_blackstone
fill 284 229 190 284 231 190 minecraft:red_nether_bricks
setblock 284 229 194 minecraft:polished_blackstone
fill 284 229 195 285 231 195 minecraft:red_nether_bricks
setblock 284 229 198 minecraft:red_nether_bricks
setblock 284 229 199 minecraft:polished_blackstone
fill 284 229 200 284 229 203 minecraft:red_nether_bricks
setblock 284 229 204 minecraft:polished_blackstone
fill 284 229 205 284 229 208 minecraft:red_nether_bricks
setblock 284 229 209 minecraft:polished_blackstone
fill 284 229 210 284 232 210 minecraft:red_nether_bricks
setblock 284 229 214 minecraft:polished_blackstone
fill 284 229 215 284 232 215 minecraft:red_nether_bricks
setblock 284 229 219 minecraft:polished_blackstone
fill 284 229 220 284 232 220 minecraft:red_nether_bricks
setblock 285 229 182 minecraft:red_nether_bricks
setblock 285 229 193 minecraft:polished_blackstone
fill 285 229 194 285 232 194 minecraft:red_nether_bricks
fill 285 229 196 285 229 197 minecraft:red_nether_bricks
setblock 285 229 198 minecraft:polished_blackstone
setblock 285 229 207 minecraft:red_nether_bricks
setblock 285 229 208 minecraft:polished_blackstone
fill 285 229 209 285 232 209 minecraft:red_nether_bricks
setblock 285 229 213 minecraft:polished_blackstone
fill 285 229 214 285 232 214 minecraft:red_nether_bricks
setblock 285 229 218 minecraft:polished_blackstone
fill 285 229 219 285 232 219 minecraft:red_nether_bricks
setblock 286 229 212 minecraft:polished_blackstone
fill 286 229 213 286 231 213 minecraft:red_nether_bricks
setblock 286 229 217 minecraft:polished_blackstone
fill 286 229 218 286 232 218 minecraft:red_nether_bricks
setblock 286 229 221 minecraft:red_nether_bricks
setblock 286 229 222 minecraft:polished_blackstone
setblock 287 229 220 minecraft:red_nether_bricks
setblock 287 229 221 minecraft:polished_blackstone
fill 287 229 222 287 232 222 minecraft:red_nether_bricks
fill 288 229 221 288 232 221 minecraft:red_nether_bricks
setblock 301 229 182 minecraft:polished_blackstone
setblock 301 229 222 minecraft:polished_blackstone
fill 302 229 182 305 229 182 minecraft:red_nether_bricks
fill 302 229 222 305 229 222 minecraft:red_nether_bricks
setblock 304 229 183 minecraft:red_nether_bricks
setblock 305 229 183 minecraft:polished_blackstone
fill 305 229 221 306 229 221 minecraft:red_nether_bricks
setblock 306 229 182 minecraft:polished_blackstone
fill 306 229 183 306 232 183 minecraft:red_nether_bricks
setblock 306 229 222 minecraft:polished_blackstone
fill 307 229 182 307 232 182 minecraft:red_nether_bricks
fill 307 229 222 307 232 222 minecraft:red_nether_bricks
fill 308 229 183 308 230 183 minecraft:red_nether_bricks
setblock 310 229 222 minecraft:red_nether_bricks
setblock 311 229 182 minecraft:polished_blackstone
setblock 311 229 222 minecraft:polished_blackstone
fill 312 229 182 312 232 182 minecraft:red_nether_bricks
setblock 316 229 222 minecraft:polished_blackstone
fill 317 229 182 318 231 182 minecraft:red_nether_bricks
fill 317 229 222 317 232 222 minecraft:red_nether_bricks
setblock 318 229 205 minecraft:magma_block
fill 318 229 221 319 231 221 minecraft:red_nether_bricks
fill 320 229 220 322 229 220 minecraft:red_nether_bricks
setblock 321 229 182 minecraft:polished_blackstone
fill 321 229 206 322 230 206 minecraft:magma_block
fill 321 229 213 321 229 216 minecraft:red_nether_bricks
setblock 321 229 217 minecraft:polished_blackstone
fill 321 229 218 321 232 218 minecraft:red_nether_bricks
setblock 321 229 222 minecraft:polished_blackstone
fill 322 229 182 322 229 185 minecraft:red_nether_bricks
setblock 322 229 186 minecraft:polished_blackstone
fill 322 229 187 322 231 187 minecraft:red_nether_bricks
setblock 322 229 191 minecraft:polished_blackstone
fill 322 229 192 322 232 192 minecraft:red_nether_bricks
setblock 322 229 195 minecraft:red_nether_bricks
setblock 322 229 196 minecraft:polished_blackstone
fill 322 229 197 322 232 197 minecraft:red_nether_bricks
fill 322 229 209 322 229 210 minecraft:red_nether_bricks
setblock 322 229 211 minecraft:polished_blackstone
fill 322 229 212 322 232 212 minecraft:red_nether_bricks
setblock 322 229 216 minecraft:polished_blackstone
fill 322 229 217 322 232 217 minecraft:red_nether_bricks
fill 322 229 219 322 230 219 minecraft:red_nether_bricks
setblock 322 229 221 minecraft:polished_blackstone
fill 322 229 222 322 232 222 minecraft:red_nether_bricks
setblock 323 229 185 minecraft:polished_blackstone
fill 323 229 186 323 232 186 minecraft:red_nether_bricks
setblock 323 229 190 minecraft:polished_blackstone
fill 323 229 191 323 232 191 minecraft:red_nether_bricks
setblock 323 229 195 minecraft:polished_blackstone
fill 323 229 196 323 232 196 minecraft:red_nether_bricks
setblock 323 229 200 minecraft:polished_blackstone
fill 323 229 201 323 231 202 minecraft:red_nether_bricks
setblock 323 229 205 minecraft:polished_blackstone
fill 323 229 206 323 229 209 minecraft:red_nether_bricks
setblock 323 229 210 minecraft:polished_blackstone
fill 323 229 211 323 232 211 minecraft:red_nether_bricks
setblock 323 229 215 minecraft:polished_blackstone
fill 323 229 216 323 232 216 minecraft:red_nether_bricks
setblock 323 229 220 minecraft:polished_blackstone
fill 323 229 221 323 232 221 minecraft:red_nether_bricks
setblock 283 230 183 minecraft:red_nether_bricks
setblock 283 230 184 minecraft:polished_blackstone
fill 283 230 185 283 232 185 minecraft:red_nether_bricks
setblock 283 230 189 minecraft:polished_blackstone
fill 283 230 190 283 233 190 minecraft:red_nether_bricks
setblock 283 230 194 minecraft:polished_blackstone
fill 283 230 195 283 230 198 minecraft:red_nether_bricks
setblock 283 230 199 minecraft:polished_blackstone
fill 283 230 200 283 230 203 minecraft:red_nether_bricks
setblock 283 230 204 minecraft:polished_blackstone
fill 283 230 205 283 230 208 minecraft:red_nether_bricks
setblock 283 230 209 minecraft:polished_blackstone
fill 283 230 210 283 230 213 minecraft:red_nether_bricks
setblock 283 230 214 minecraft:polished_blackstone
fill 283 230 215 283 233 215 minecraft:red_nether_bricks
setblock 283 230 219 minecraft:polished_blackstone
fill 283 230 220 283 233 220 minecraft:red_nether_bricks
setblock 284 230 189 minecraft:red_nether_bricks
setblock 284 230 193 minecraft:polished_blackstone
fill 284 230 194 284 233 194 minecraft:red_nether_bricks
setblock 284 230 198 minecraft:polished_blackstone
fill 284 230 199 284 230 202 minecraft:red_nether_bricks
setblock 284 230 203 minecraft:polished_blackstone
fill 284 230 204 284 230 207 minecraft:red_nether_bricks
setblock 284 230 208 minecraft:polished_blackstone
fill 284 230 209 284 233 209 minecraft:red_nether_bricks
setblock 284 230 213 minecraft:polished_blackstone
fill 284 230 214 284 233 214 minecraft:red_nether_bricks
setblock 284 230 218 minecraft:polished_blackstone
fill 284 230 219 284 233 219 minecraft:red_nether_bricks
setblock 285 230 182 minecraft:polished_blackstone
setblock 285 230 192 minecraft:polished_blackstone
fill 285 230 193 285 231 193 minecraft:red_nether_bricks
setblock 285 230 196 minecraft:red_nether_bricks
setblock 285 230 197 minecraft:polished_blackstone
fill 285 230 198 285 231 200 minecraft:red_nether_bricks
setblock 285 230 207 minecraft:polished_blackstone
fill 285 230 208 285 231 208 minecraft:red_nether_bricks
setblock 285 230 212 minecraft:polished_blackstone
fill 285 230 213 285 233 213 minecraft:red_nether_bricks
setblock 285 230 217 minecraft:polished_blackstone
fill 285 230 218 285 233 218 minecraft:red_nether_bricks
setblock 285 230 222 minecraft:polished_blackstone
setblock 286 230 211 minecraft:polished_blackstone
fill 286 230 212 286 231 212 minecraft:red_nether_bricks
setblock 286 230 216 minecraft:polished_blackstone
fill 286 230 217 286 232 217 minecraft:red_nether_bricks
fill 286 230 219 286 231 219 minecraft:red_nether_bricks
setblock 286 230 221 minecraft:polished_blackstone
fill 286 230 222 286 233 222 minecraft:red_nether_bricks
setblock 287 230 220 minecraft:polished_blackstone
fill 287 230 221 287 233 221 minecraft:red_nether_bricks
setblock 300 230 182 minecraft:polished_blackstone
setblock 300 230 222 minecraft:polished_blackstone
fill 301 230 182 304 230 182 minecraft:red_nether_bricks
fill 301 230 222 304 230 222 minecraft:red_nether_bricks
fill 302 230 183 303 230 183 minecraft:red_nether_bricks
fill 302 230 221 305 230 221 minecraft:red_nether_bricks
setblock 304 230 183 minecraft:polished_blackstone
setblock 305 230 182 minecraft:polished_blackstone
fill 305 230 183 305 233 183 minecraft:red_nether_bricks
setblock 305 230 222 minecraft:polished_blackstone
fill 306 230 182 306 233 182 minecraft:red_nether_bricks
setblock 306 230 221 minecraft:polished_blackstone
fill 306 230 222 306 233 222 minecraft:red_nether_bricks
fill 307 230 221 308 232 221 minecraft:red_nether_bricks
setblock 310 230 182 minecraft:polished_blackstone
setblock 310 230 222 minecraft:polished_blackstone
fill 311 230 182 311 233 182 minecraft:red_nether_bricks
fill 311 230 222 314 230 222 minecraft:red_nether_bricks
fill 313 230 182 314 230 182 minecraft:red_nether_bricks
setblock 315 230 182 minecraft:polished_blackstone
setblock 315 230 222 minecraft:polished_blackstone
fill 316 230 182 316 233 182 minecraft:red_nether_bricks
fill 316 230 222 316 233 222 minecraft:red_nether_bricks
fill 317 230 221 317 233 221 minecraft:red_nether_bricks
fill 319 230 220 321 230 220 minecraft:red_nether_bricks
setblock 320 230 182 minecraft:polished_blackstone
fill 320 230 183 322 231 183 minecraft:red_nether_bricks
setblock 320 230 217 minecraft:polished_blackstone
fill 320 230 218 320 233 218 minecraft:red_nether_bricks
setblock 320 230 221 minecraft:red_nether_bricks
setblock 320 230 222 minecraft:polished_blackstone
fill 321 230 182 322 232 182 minecraft:red_nether_bricks
fill 321 230 204 322 230 204 minecraft:magma_block
fill 321 230 212 321 230 215 minecraft:red_nether_bricks
setblock 321 230 216 minecraft:polished_blackstone
fill 321 230 217 321 233 217 minecraft:red_nether_bricks
setblock 321 230 221 minecraft:polished_blackstone
fill 321 230 222 321 233 222 minecraft:red_nether_bricks
setblock 322 230 184 minecraft:red_nether_bricks
setblock 322 230 185 minecraft:polished_blackstone
fill 322 230 186 322 231 186 minecraft:red_nether_bricks
setblock 322 230 190 minecraft:polished_blackstone
fill 322 230 191 322 233 191 minecraft:red_nether_bricks
setblock 322 230 195 minecraft:polished_blackstone
fill 322 230 196 322 233 196 minecraft:red_nether_bricks
fill 322 230 198 322 230 199 minecraft:red_nether_bricks
setblock 322 230 209 minecraft:red_nether_bricks
setblock 322 230 210 minecraft:polished_blackstone
fill 322 230 211 322 233 211 minecraft:red_nether_bricks
setblock 322 230 215 minecraft:polished_blackstone
fill 322 230 216 322 233 216 minecraft:red_nether_bricks
setblock 322 230 220 minecraft:polished_blackstone
fill 322 230 221 322 233 221 minecraft:red_nether_bricks
setblock 323 230 184 minecraft:polished_blackstone
fill 323 230 185 323 233 185 minecraft:red_nether_bricks
setblock 323 230 189 minecraft:polished_blackstone
fill 323 230 190 323 233 190 minecraft:red_nether_bricks
setblock 323 230 194 minecraft:polished_blackstone
fill 323 230 195 323 233 195 minecraft:red_nether_bricks
setblock 323 230 199 minecraft:polished_blackstone
fill 323 230 200 323 233 200 minecraft:red_nether_bricks
setblock 323 230 203 minecraft:red_nether_bricks
setblock 323 230 204 minecraft:polished_blackstone
fill 323 230 205 323 230 208 minecraft:red_nether_bricks
setblock 323 230 209 minecraft:polished_blackstone
fill 323 230 210 323 233 210 minecraft:red_nether_bricks
setblock 323 230 214 minecraft:polished_blackstone
fill 323 230 215 323 233 215 minecraft:red_nether_bricks
setblock 323 230 219 minecraft:polished_blackstone
fill 323 230 220 323 233 220 minecraft:red_nether_bricks
setblock 283 231 182 minecraft:red_nether_bricks
setblock 283 231 183 minecraft:polished_blackstone
fill 283 231 184 283 233 184 minecraft:red_nether_bricks
setblock 283 231 188 minecraft:polished_blackstone
fill 283 231 189 283 233 189 minecraft:red_nether_bricks
setblock 283 231 193 minecraft:polished_blackstone
fill 283 231 194 283 231 197 minecraft:red_nether_bricks
setblock 283 231 198 minecraft:polished_blackstone
fill 283 231 199 283 231 202 minecraft:red_nether_bricks
setblock 283 231 203 minecraft:polished_blackstone
fill 283 231 204 283 231 207 minecraft:red_nether_bricks
setblock 283 231 208 minecraft:polished_blackstone
fill 283 231 209 283 231 212 minecraft:red_nether_bricks
setblock 283 231 213 minecraft:polished_blackstone
fill 283 231 214 283 234 214 minecraft:red_nether_bricks
setblock 283 231 218 minecraft:polished_blackstone
fill 283 231 219 283 234 219 minecraft:red_nether_bricks
setblock 284 231 182 minecraft:polished_blackstone
setblock 284 231 192 minecraft:polished_blackstone
fill 284 231 193 284 234 193 minecraft:red_nether_bricks
setblock 284 231 197 minecraft:polished_blackstone
fill 284 231 198 284 231 201 minecraft:red_nether_bricks
setblock 284 231 202 minecraft:polished_blackstone
fill 284 231 203 284 231 206 minecraft:red_nether_bricks
setblock 284 231 207 minecraft:polished_blackstone
fill 284 231 208 284 234 208 minecraft:red_nether_bricks
setblock 284 231 212 minecraft:polished_blackstone
fill 284 231 213 284 234 213 minecraft:red_nether_bricks
setblock 284 231 217 minecraft:polished_blackstone
fill 284 231 218 284 234 218 minecraft:red_nether_bricks
setblock 284 231 222 minecraft:polished_blackstone
fill 285 231 182 285 233 182 minecraft:red_nether_bricks
setblock 285 231 196 minecraft:polished_blackstone
fill 285 231 197 285 234 197 minecraft:red_nether_bricks
setblock 285 231 201 minecraft:polished_blackstone
fill 285 231 202 285 234 202 minecraft:red_nether_bricks
setblock 285 231 211 minecraft:polished_blackstone
fill 285 231 212 285 233 212 minecraft:red_nether_bricks
setblock 285 231 216 minecraft:polished_blackstone
fill 285 231 217 285 234 217 minecraft:red_nether_bricks
setblock 285 231 220 minecraft:red_nether_bricks
setblock 285 231 221 minecraft:polished_blackstone
fill 285 231 222 285 234 222 minecraft:red_nether_bricks
setblock 286 231 215 minecraft:polished_blackstone
fill 286 231 216 286 232 216 minecraft:red_nether_bricks
setblock 286 231 220 minecraft:polished_blackstone
fill 286 231 221 286 234 221 minecraft:red_nether_bricks
fill 287 231 220 287 232 220 minecraft:red_nether_bricks
setblock 289 231 222 minecraft:polished_blackstone
fill 290 231 222 290 232 222 minecraft:red_nether_bricks
fill 292 231 199 293 232 200 minecraft:magma_block
setblock 298 231 222 minecraft:red_nether_bricks
setblock 299 231 182 minecraft:polished_blackstone
setblock 299 231 222 minecraft:polished_blackstone
fill 300 231 182 303 231 182 minecraft:red_nether_bricks
setblock 300 231 221 minecraft:polished_blackstone
fill 300 231 222 303 231 222 minecraft:red_nether_bricks
fill 301 231 183 302 231 183 minecraft:red_nether_bricks
fill 301 231 221 304 231 221 minecraft:red_nether_bricks
setblock 303 231 183 minecraft:polished_blackstone
setblock 304 231 182 minecraft:polished_blackstone
fill 304 231 183 304 234 183 minecraft:red_nether_bricks
setblock 304 231 222 minecraft:polished_blackstone
fill 305 231 182 305 234 182 minecraft:red_nether_bricks
setblock 305 231 221 minecraft:polished_blackstone
fill 305 231 222 305 234 222 minecraft:red_nether_bricks
fill 306 231 221 306 234 221 minecraft:red_nether_bricks
setblock 308 231 183 minecraft:polished_blackstone
setblock 308 231 222 minecraft:red_nether_bricks
setblock 309 231 182 minecraft:polished_blackstone
setblock 309 231 221 minecraft:red_nether_bricks
setblock 309 231 222 minecraft:polished_blackstone
fill 310 231 182 310 234 182 minecraft:red_nether_bricks
fill 310 231 222 313 231 222 minecraft:red_nether_bricks
setblock 313 231 182 minecraft:red_nether_bricks
setblock 314 231 182 minecraft:polished_blackstone
setblock 314 231 222 minecraft:polished_blackstone
fill 315 231 182 315 234 182 minecraft:red_nether_bricks
setblock 315 231 221 minecraft:polished_blackstone
fill 315 231 222 315 234 222 minecraft:red_nether_bricks
fill 316 231 221 316 234 221 minecraft:red_nether_bricks
fill 317 231 220 320 231 220 minecraft:red_nether_bricks
setblock 318 231 222 minecraft:red_nether_bricks
setblock 319 231 182 minecraft:polished_blackstone
fill 319 231 183 319 234 183 minecraft:red_nether_bricks
fill 319 231 219 320 232 219 minecraft:red_nether_bricks
setblock 319 231 222 minecraft:polished_blackstone
fill 320 231 182 320 234 182 minecraft:red_nether_bricks
setblock 320 231 215 minecraft:red_nether_bricks
setblock 320 231 216 minecraft:polished_blackstone
fill 320 231 217 320 234 217 minecraft:red_nether_bricks
setblock 320 231 221 minecraft:polished_blackstone
fill 320 231 222 320 234 222 minecraft:red_nether_bricks
setblock 321 231 194 minecraft:red_nether_bricks
setblock 321 231 195 minecraft:polished_blackstone
fill 321 231 212 321 231 214 minecraft:red_nether_bricks
setblock 321 231 215 minecraft:polished_blackstone
fill 321 231 216 321 234 216 minecraft:red_nether_bricks
setblock 321 231 220 minecraft:polished_blackstone
fill 321 231 221 321 234 221 minecraft:red_nether_bricks
setblock 322 231 184 minecraft:polished_blackstone
fill 322 231 185 322 232 185 minecraft:red_nether_bricks
setblock 322 231 189 minecraft:polished_blackstone
fill 322 231 190 322 232 190 minecraft:red_nether_bricks
setblock 322 231 194 minecraft:polished_blackstone
fill 322 231 195 322 234 195 minecraft:red_nether_bricks
setblock 322 231 198 minecraft:red_nether_bricks
setblock 322 231 199 minecraft:polished_blackstone
fill 322 231 200 322 234 200 minecraft:red_nether_bricks
setblock 322 231 209 minecraft:polished_blackstone
fill 322 231 210 322 234 210 minecraft:red_nether_bricks
setblock 322 231 214 minecraft:polished_blackstone
fill 322 231 215 322 234 215 minecraft:red_nether_bricks
setblock 322 231 219 minecraft:polished_blackstone
fill 322 231 220 322 234 220 minecraft:red_nether_bricks
setblock 323 231 183 minecraft:polished_blackstone
fill 323 231 184 323 234 184 minecraft:red_nether_bricks
setblock 323 231 188 minecraft:polished_blackstone
fill 323 231 189 323 234 189 minecraft:red_nether_bricks
setblock 323 231 193 minecraft:polished_blackstone
fill 323 231 194 323 234 194 minecraft:red_nether_bricks
setblock 323 231 198 minecraft:polished_blackstone
fill 323 231 199 323 234 199 minecraft:red_nether_bricks
setblock 323 231 203 minecraft:polished_blackstone
fill 323 231 204 323 231 207 minecraft:red_nether_bricks
setblock 323 231 208 minecraft:polished_blackstone
fill 323 231 209 323 234 209 minecraft:red_nether_bricks
setblock 323 231 213 minecraft:polished_blackstone
fill 323 231 214 323 234 214 minecraft:red_nether_bricks
setblock 323 231 218 minecraft:polished_blackstone
fill 323 231 219 323 234 219 minecraft:red_nether_bricks
setblock 283 232 182 minecraft:polished_blackstone
fill 283 232 183 283 235 183 minecraft:red_nether_bricks
setblock 283 232 187 minecraft:polished_blackstone
fill 283 232 188 283 233 188 minecraft:red_nether_bricks
setblock 283 232 192 minecraft:polished_blackstone
fill 283 232 193 283 232 196 minecraft:red_nether_bricks
setblock 283 232 197 minecraft:polished_blackstone
fill 283 232 198 283 232 201 minecraft:red_nether_bricks
setblock 283 232 202 minecraft:polished_blackstone
fill 283 232 203 283 232 206 minecraft:red_nether_bricks
setblock 283 232 207 minecraft:polished_blackstone
fill 283 232 208 283 232 211 minecraft:red_nether_bricks
setblock 283 232 212 minecraft:polished_blackstone
fill 283 232 213 283 235 213 minecraft:red_nether_bricks
setblock 283 232 217 minecraft:polished_blackstone
fill 283 232 218 283 235 218 minecraft:red_nether_bricks
setblock 283 232 222 minecraft:polished_blackstone
fill 284 232 182 284 235 182 minecraft:red_nether_bricks
setblock 284 232 191 minecraft:polished_blackstone
fill 284 232 192 284 233 192 minecraft:red_nether_bricks
setblock 284 232 195 minecraft:red_nether_bricks
setblock 284 232 196 minecraft:polished_blackstone
fill 284 232 197 284 232 200 minecraft:red_nether_bricks
setblock 284 232 201 minecraft:polished_blackstone
fill 284 232 202 284 232 205 minecraft:red_nether_bricks
setblock 284 232 206 minecraft:polished_blackstone
fill 284 232 207 284 235 207 minecraft:red_nether_bricks
setblock 284 232 211 minecraft:polished_blackstone
fill 284 232 212 284 235 212 minecraft:red_nether_bricks
setblock 284 232 216 minecraft:polished_blackstone
fill 284 232 217 284 235 217 minecraft:red_nether_bricks
setblock 284 232 221 minecraft:polished_blackstone
fill 284 232 222 284 235 222 minecraft:red_nether_bricks
setblock 285 232 195 minecraft:polished_blackstone
fill 285 232 196 285 234 196 minecraft:red_nether_bricks
fill 285 232 198 285 232 199 minecraft:red_nether_bricks
setblock 285 232 200 minecraft:polished_blackstone
fill 285 232 201 285 235 201 minecraft:red_nether_bricks
fill 285 232 203 285 233 203 minecraft:red_nether_bricks
setblock 285 232 210 minecraft:polished_blackstone
fill 285 232 211 285 233 211 minecraft:red_nether_bricks
setblock 285 232 215 minecraft:polished_blackstone
fill 285 232 216 285 234 216 minecraft:red_nether_bricks
setblock 285 232 220 minecraft:polished_blackstone
fill 285 232 221 285 235 221 minecraft:red_nether_bricks
setblock 286 232 214 minecraft:polished_blackstone
setblock 286 232 215 minecraft:red_nether_bricks
fill 286 232 220 286 233 220 minecraft:red_nether_bricks
setblock 288 232 222 minecraft:polished_blackstone
fill 289 232 222 289 234 222 minecraft:red_nether_bricks
setblock 297 232 222 minecraft:red_nether_bricks
setblock 298 232 182 minecraft:polished_blackstone
setblock 298 232 222 minecraft:polished_blackstone
fill 299 232 182 302 232 182 minecraft:red_nether_bricks
setblock 299 232 221 minecraft:polished_blackstone
fill 299 232 222 302 232 222 minecraft:red_nether_bricks
fill 300 232 221 303 232 221 minecraft:red_nether_bricks
setblock 301 232 183 minecraft:red_nether_bricks
setblock 302 232 183 minecraft:polished_blackstone
fill 302 232 220 304 232 220 minecraft:red_nether_bricks
setblock 303 232 182 minecraft:polished_blackstone
fill 303 232 183 303 235 183 minecraft:red_nether_bricks
setblock 303 232 222 minecraft:polished_blackstone
fill 304 232 182 304 235 182 minecraft:red_nether_bricks
setblock 304 232 221 minecraft:polished_blackstone
fill 304 232 222 304 235 222 minecraft:red_nether_bricks
setblock 305 232 220 minecraft:polished_blackstone
fill 305 232 221 305 235 221 minecraft:red_nether_bricks
setblock 307 232 183 minecraft:polished_blackstone
setblock 308 232 182 minecraft:polished_blackstone
fill 308 232 183 308 233 183 minecraft:red_nether_bricks
setblock 308 232 222 minecraft:polished_blackstone
fill 309 232 182 309 235 182 minecraft:red_nether_bricks
setblock 309 232 221 minecraft:polished_blackstone
fill 309 232 222 312 232 222 minecraft:red_nether_bricks
fill 310 232 221 310 233 221 minecraft:red_nether_bricks
setblock 313 232 182 minecraft:polished_blackstone
setblock 313 232 221 minecraft:red_nether_bricks
setblock 313 232 222 minecraft:polished_blackstone
fill 314 232 182 314 235 182 minecraft:red_nether_bricks
setblock 314 232 221 minecraft:polished_blackstone
fill 314 232 222 314 235 222 minecraft:red_nether_bricks
fill 315 232 221 315 235 221 minecraft:red_nether_bricks
setblock 317 232 182 minecraft:red_nether_bricks
fill 317 232 220 319 232 220 minecraft:red_nether_bricks
setblock 318 232 182 minecraft:polished_blackstone
setblock 318 232 221 minecraft:red_nether_bricks
setblock 318 232 222 minecraft:polished_blackstone
fill 319 232 182 319 235 182 minecraft:red_nether_bricks
setblock 319 232 221 minecraft:polished_blackstone
fill 319 232 222 319 235 222 minecraft:red_nether_bricks
fill 320 232 183 321 232 183 minecraft:red_nether_bricks
setblock 320 232 215 minecraft:polished_blackstone
fill 320 232 216 320 234 216 minecraft:red_nether_bricks
setblock 320 232 220 minecraft:polished_blackstone
fill 320 232 221 320 235 221 minecraft:red_nether_bricks
fill 321 232 195 321 232 196 minecraft:red_nether_bricks
fill 321 232 212 321 232 213 minecraft:red_nether_bricks
setblock 321 232 214 minecraft:polished_blackstone
fill 321 232 215 321 235 215 minecraft:red_nether_bricks
setblock 321 232 219 minecraft:polished_blackstone
fill 321 232 220 321 235 220 minecraft:red_nether_bricks
setblock 322 232 183 minecraft:polished_blackstone
fill 322 232 184 322 234 184 minecraft:red_nether_bricks
setblock 322 232 188 minecraft:polished_blackstone
setblock 322 232 189 minecraft:red_nether_bricks
setblock 322 232 193 minecraft:polished_blackstone
fill 322 232 194 322 234 194 minecraft:red_nether_bricks
setblock 322 232 198 minecraft:polished_blackstone
fill 322 232 199 322 235 199 minecraft:red_nether_bricks
fill 322 232 201 322 232 202 minecraft:red_nether_bricks
fill 322 232 209 322 234 209 minecraft:red_nether_bricks
setblock 322 232 213 minecraft:polished_blackstone
fill 322 232 214 322 235 214 minecraft:red_nether_bricks
setblock 322 232 218 minecraft:polished_blackstone
fill 322 232 219 322 235 219 minecraft:red_nether_bricks
setblock 323 232 182 minecraft:polished_blackstone
fill 323 232 183 323 235 183 minecraft:red_nether_bricks
setblock 323 232 187 minecraft:polished_blackstone
fill 323 232 188 323 234 188 minecraft:red_nether_bricks
setblock 323 232 192 minecraft:polished_blackstone
fill 323 232 193 323 235 193 minecraft:red_nether_bricks
setblock 323 232 197 minecraft:polished_blackstone
fill 323 232 198 323 235 198 minecraft:red_nether_bricks
setblock 323 232 201 minecraft:red_nether_bricks
setblock 323 232 202 minecraft:polished_blackstone
fill 323 232 203 323 232 206 minecraft:red_nether_bricks
setblock 323 232 207 minecraft:polished_blackstone
fill 323 232 208 323 235 208 minecraft:red_nether_bricks
setblock 323 232 212 minecraft:polished_blackstone
fill 323 232 213 323 235 213 minecraft:red_nether_bricks
setblock 323 232 217 minecraft:polished_blackstone
fill 323 232 218 323 235 218 minecraft:red_nether_bricks
setblock 323 232 222 minecraft:polished_blackstone
fill 283 233 182 283 236 182 minecraft:red_nether_bricks
setblock 283 233 191 minecraft:polished_blackstone
fill 283 233 192 283 233 195 minecraft:red_nether_bricks
setblock 283 233 196 minecraft:polished_blackstone
fill 283 233 197 283 233 200 minecraft:red_nether_bricks
setblock 283 233 201 minecraft:polished_blackstone
fill 283 233 202 283 233 205 minecraft:red_nether_bricks
setblock 283 233 206 minecraft:polished_blackstone
fill 283 233 207 283 233 210 minecraft:red_nether_bricks
setblock 283 233 211 minecraft:polished_blackstone
fill 283 233 212 283 236 212 minecraft:red_nether_bricks
setblock 283 233 216 minecraft:polished_blackstone
fill 283 233 217 283 236 217 minecraft:red_nether_bricks
setblock 283 233 221 minecraft:polished_blackstone
fill 283 233 222 283 236 222 minecraft:red_nether_bricks
setblock 284 233 195 minecraft:polished_blackstone
fill 284 233 196 284 233 199 minecraft:red_nether_bricks
setblock 284 233 200 minecraft:polished_blackstone
fill 284 233 201 284 233 204 minecraft:red_nether_bricks
setblock 284 233 205 minecraft:polished_blackstone
fill 284 233 206 284 236 206 minecraft:red_nether_bricks
setblock 284 233 210 minecraft:polished_blackstone
fill 284 233 211 284 235 211 minecraft:red_nether_bricks
setblock 284 233 215 minecraft:polished_blackstone
fill 284 233 216 284 236 216 minecraft:red_nether_bricks
setblock 284 233 220 minecraft:polished_blackstone
fill 284 233 221 284 236 221 minecraft:red_nether_bricks
setblock 285 233 194 minecraft:polished_blackstone
setblock 285 233 195 minecraft:red_nether_bricks
setblock 285 233 198 minecraft:red_nether_bricks
setblock 285 233 199 minecraft:polished_blackstone
fill 285 233 200 285 236 200 minecraft:red_nether_bricks
setblock 285 233 214 minecraft:polished_blackstone
fill 285 233 215 285 234 215 minecraft:red_nether_bricks
setblock 285 233 219 minecraft:polished_blackstone
fill 285 233 220 285 234 220 minecraft:red_nether_bricks
setblock 287 233 222 minecraft:polished_blackstone
setblock 288 233 221 minecraft:polished_blackstone
fill 288 233 222 288 235 222 minecraft:red_nether_bricks
setblock 296 233 222 minecraft:red_nether_bricks
setblock 297 233 182 minecraft:polished_blackstone
setblock 297 233 222 minecraft:polished_blackstone
fill 298 233 182 301 233 182 minecraft:red_nether_bricks
fill 298 233 222 301 233 222 minecraft:red_nether_bricks
fill 299 233 221 302 233 221 minecraft:red_nether_bricks
setblock 300 233 183 minecraft:red_nether_bricks
setblock 301 233 183 minecraft:polished_blackstone
setblock 302 233 182 minecraft:polished_blackstone
fill 302 233 183 302 236 183 minecraft:red_nether_bricks
fill 302 233 220 303 233 220 minecraft:red_nether_bricks
setblock 302 233 222 minecraft:polished_blackstone
fill 303 233 182 303 236 182 minecraft:red_nether_bricks
setblock 303 233 221 minecraft:polished_blackstone
fill 303 233 222 303 236 222 minecraft:red_nether_bricks
setblock 304 233 220 minecraft:polished_blackstone
fill 304 233 221 304 236 221 minecraft:red_nether_bricks
setblock 306 233 183 minecraft:polished_blackstone
setblock 307 233 182 minecraft:polished_blackstone
fill 307 233 183 307 234 183 minecraft:red_nether_bricks
setblock 307 233 221 minecraft:red_nether_bricks
setblock 307 233 222 minecraft:polished_blackstone
fill 308 233 182 308 236 182 minecraft:red_nether_bricks
setblock 308 233 221 minecraft:polished_blackstone
fill 308 233 222 311 233 222 minecraft:red_nether_bricks
fill 309 233 221 309 234 221 minecraft:red_nether_bricks
fill 311 233 221 312 233 221 minecraft:red_nether_bricks
setblock 312 233 182 minecraft:polished_blackstone
setblock 312 233 222 minecraft:polished_blackstone
fill 313 233 182 313 236 182 minecraft:red_nether_bricks
setblock 313 233 221 minecraft:polished_blackstone
fill 313 233 222 313 236 222 minecraft:red_nether_bricks
fill 314 233 221 314 236 221 minecraft:red_nether_bricks
fill 316 233 220 318 233 220 minecraft:red_nether_bricks
setblock 317 233 182 minecraft:polished_blackstone
setblock 317 233 222 minecraft:polished_blackstone
fill 318 233 182 318 235 183 minecraft:red_nether_bricks
fill 318 233 219 319 233 219 minecraft:red_nether_bricks
setblock 318 233 221 minecraft:polished_blackstone
fill 318 233 222 318 236 222 minecraft:red_nether_bricks
setblock 319 233 220 minecraft:polished_blackstone
fill 319 233 221 319 236 221 minecraft:red_nether_bricks
setblock 320 233 183 minecraft:red_nether_bricks
setblock 320 233 215 minecraft:red_nether_bricks
setblock 320 233 219 minecraft:polished_blackstone
fill 320 233 220 320 236 220 minecraft:red_nether_bricks
setblock 321 233 182 minecraft:red_nether_bricks
setblock 321 233 183 minecraft:polished_blackstone
setblock 321 233 212 minecraft:red_nether_bricks
setblock 321 233 213 minecraft:polished_blackstone
fill 321 233 214 321 235 214 minecraft:red_nether_bricks
setblock 321 233 218 minecraft:polished_blackstone
fill 321 233 219 321 236 219 minecraft:red_nether_bricks
setblock 322 233 182 minecraft:polished_blackstone
fill 322 233 183 322 236 183 minecraft:red_nether_bricks
setblock 322 233 192 minecraft:polished_blackstone
fill 322 233 193 322 234 193 minecraft:red_nether_bricks
setblock 322 233 197 minecraft:polished_blackstone
fill 322 233 198 322 236 198 minecraft:red_nether_bricks
setblock 322 233 201 minecraft:red_nether_bricks
setblock 322 233 202 minecraft:polished_blackstone
fill 322 233 203 323 235 203 minecraft:red_nether_bricks
setblock 322 233 212 minecraft:polished_blackstone
fill 322 233 213 322 236 213 minecraft:red_nether_bricks
setblock 322 233 217 minecraft:polished_blackstone
fill 322 233 218 322 236 218 minecraft:red_nether_bricks
setblock 322 233 222 minecraft:polished_blackstone
fill 323 233 182 323 236 182 minecraft:red_nether_bricks
setblock 323 233 186 minecraft:polished_blackstone
fill 323 233 187 323 234 187 minecraft:red_nether_bricks
setblock 323 233 191 minecraft:polished_blackstone
fill 323 233 192 323 235 192 minecraft:red_nether_bricks
setblock 323 233 196 minecraft:polished_blackstone
fill 323 233 197 323 236 197 minecraft:red_nether_bricks
setblock 323 233 201 minecraft:polished_blackstone
fill 323 233 202 323 236 202 minecraft:red_nether_bricks
fill 323 233 204 323 233 205 minecraft:red_nether_bricks
setblock 323 233 206 minecraft:polished_blackstone
fill 323 233 207 323 236 207 minecraft:red_nether_bricks
setblock 323 233 211 minecraft:polished_blackstone
fill 323 233 212 323 236 212 minecraft:red_nether_bricks
setblock 323 233 216 minecraft:polished_blackstone
fill 323 233 217 323 236 217 minecraft:red_nether_bricks
setblock 323 233 221 minecraft:polished_blackstone
fill 323 233 222 323 236 222 minecraft:red_nether_bricks
setblock 283 234 190 minecraft:polished_blackstone
fill 283 234 191 283 234 194 minecraft:red_nether_bricks
setblock 283 234 195 minecraft:polished_blackstone
fill 283 234 196 283 234 199 minecraft:red_nether_bricks
setblock 283 234 200 minecraft:polished_blackstone
fill 283 234 201 283 234 204 minecraft:red_nether_bricks
setblock 283 234 205 minecraft:polished_blackstone
fill 283 234 206 283 234 209 minecraft:red_nether_bricks
setblock 283 234 210 minecraft:polished_blackstone
fill 283 234 211 283 237 211 minecraft:red_nether_bricks
setblock 283 234 215 minecraft:polished_blackstone
fill 283 234 216 283 237 216 minecraft:red_nether_bricks
setblock 283 234 220 minecraft:polished_blackstone
fill 283 234 221 283 237 221 minecraft:red_nether_bricks
setblock 284 234 194 minecraft:polished_blackstone
fill 284 234 195 284 234 198 minecraft:red_nether_bricks
setblock 284 234 199 minecraft:polished_blackstone
fill 284 234 200 284 234 203 minecraft:red_nether_bricks
setblock 284 234 204 minecraft:polished_blackstone
fill 284 234 205 284 237 205 minecraft:red_nether_bricks
setblock 284 234 209 minecraft:polished_blackstone
fill 284 234 210 284 235 210 minecraft:red_nether_bricks
setblock 284 234 214 minecraft:polished_blackstone
fill 284 234 215 284 236 215 minecraft:red_nether_bricks
setblock 284 234 219 minecraft:polished_blackstone
fill 284 234 220 284 237 220 minecraft:red_nether_bricks
setblock 285 234 198 minecraft:polished_blackstone
fill 285 234 199 285 236 199 minecraft:red_nether_bricks
setblock 285 234 203 minecraft:polished_blackstone
setblock 285 234 213 minecraft:polished_blackstone
setblock 285 234 214 minecraft:red_nether_bricks
setblock 285 234 218 minecraft:polished_blackstone
fill 285 234 219 285 235 219 minecraft:red_nether_bricks
setblock 286 234 222 minecraft:polished_blackstone
setblock 287 234 221 minecraft:polished_blackstone
fill 287 234 222 287 236 222 minecraft:red_nether_bricks
setblock 296 234 222 minecraft:polished_blackstone
fill 297 234 182 300 234 182 minecraft:red_nether_bricks
fill 297 234 222 300 234 222 minecraft:red_nether_bricks
fill 298 234 221 301 234 221 minecraft:red_nether_bricks
setblock 299 234 183 minecraft:red_nether_bricks
setblock 300 234 183 minecraft:polished_blackstone
setblock 301 234 182 minecraft:polished_blackstone
fill 301 234 183 301 237 183 minecraft:red_nether_bricks
setblock 301 234 222 minecraft:polished_blackstone
fill 302 234 182 302 237 182 minecraft:red_nether_bricks
setblock 302 234 220 minecraft:red_nether_bricks
setblock 302 234 221 minecraft:polished_blackstone
fill 302 234 222 302 237 222 minecraft:red_nether_bricks
setblock 303 234 220 minecraft:polished_blackstone
fill 303 234 221 303 237 221 minecraft:red_nether_bricks
setblock 305 234 183 minecraft:polished_blackstone
setblock 306 234 182 minecraft:polished_blackstone
fill 306 234 183 306 237 183 minecraft:red_nether_bricks
setblock 306 234 222 minecraft:polished_blackstone
fill 307 234 182 307 237 182 minecraft:red_nether_bricks
setblock 307 234 221 minecraft:polished_blackstone
fill 307 234 222 310 234 222 minecraft:red_nether_bricks
fill 308 234 221 308 235 221 minecraft:red_nether_bricks
setblock 311 234 182 minecraft:polished_blackstone
setblock 311 234 222 minecraft:polished_blackstone
fill 312 234 182 312 237 182 minecraft:red_nether_bricks
setblock 312 234 221 minecraft:polished_blackstone
fill 312 234 222 312 237 222 minecraft:red_nether_bricks
fill 313 234 221 313 237 221 minecraft:red_nether_bricks
setblock 316 234 182 minecraft:polished_blackstone
fill 316 234 220 317 234 220 minecraft:red_nether_bricks
setblock 316 234 222 minecraft:polished_blackstone
fill 317 234 182 317 236 183 minecraft:red_nether_bricks
setblock 317 234 221 minecraft:polished_blackstone
fill 317 234 222 317 237 222 minecraft:red_nether_bricks
setblock 318 234 219 minecraft:red_nether_bricks
setblock 318 234 220 minecraft:polished_blackstone
fill 318 234 221 318 237 221 minecraft:red_nether_bricks
setblock 319 234 219 minecraft:polished_blackstone
fill 319 234 220 319 237 220 minecraft:red_nether_bricks
setblock 320 234 183 minecraft:polished_blackstone
setblock 320 234 218 minecraft:polished_blackstone
fill 320 234 219 320 237 219 minecraft:red_nether_bricks
setblock 321 234 182 minecraft:polished_blackstone
fill 321 234 183 321 237 183 minecraft:red_nether_bricks
setblock 321 234 213 minecraft:red_nether_bricks
setblock 321 234 217 minecraft:polished_blackstone
fill 321 234 218 321 237 218 minecraft:red_nether_bricks
setblock 321 234 222 minecraft:polished_blackstone
fill 322 234 182 322 237 182 minecraft:red_nether_bricks
setblock 322 234 196 minecraft:polished_blackstone
fill 322 234 197 322 236 197 minecraft:red_nether_bricks
setblock 322 234 201 minecraft:polished_blackstone
fill 322 234 202 322 237 202 minecraft:red_nether_bricks
fill 322 234 204 323 234 204 minecraft:red_nether_bricks
setblock 322 234 211 minecraft:polished_blackstone
fill 322 234 212 322 236 212 minecraft:red_nether_bricks
setblock 322 234 216 minecraft:polished_blackstone
fill 322 234 217 322 237 217 minecraft:red_nether_bricks
setblock 322 234 221 minecraft:polished_blackstone
fill 322 234 222 322 237 222 minecraft:red_nether_bricks
setblock 323 234 185 minecraft:polished_blackstone
setblock 323 234 186 minecraft:red_nether_bricks
setblock 323 234 190 minecraft:polished_blackstone
fill 323 234 191 323 235 191 minecraft:red_nether_bricks
setblock 323 234 195 minecraft:polished_blackstone
fill 323 234 196 323 237 196 minecraft:red_nether_bricks
setblock 323 234 200 minecraft:polished_blackstone
fill 323 234 201 323 237 201 minecraft:red_nether_bricks
setblock 323 234 205 minecraft:polished_blackstone
fill 323 234 206 323 237 206 minecraft:red_nether_bricks
setblock 323 234 210 minecraft:polished_blackstone
fill 323 234 211 323 237 211 minecraft:red_nether_bricks
setblock 323 234 215 minecraft:polished_blackstone
fill 323 234 216 323 237 216 minecraft:red_nether_bricks
setblock 323 234 220 minecraft:polished_blackstone
fill 323 234 221 323 237 221 minecraft:red_nether_bricks
fill 283 235 191 283 235 193 minecraft:red_nether_bricks
setblock 283 235 194 minecraft:polished_blackstone
fill 283 235 195 283 235 198 minecraft:red_nether_bricks
setblock 283 235 199 minecraft:polished_blackstone
fill 283 235 200 283 235 203 minecraft:red_nether_bricks
setblock 283 235 204 minecraft:polished_blackstone
fill 283 235 205 283 235 208 minecraft:red_nether_bricks
setblock 283 235 209 minecraft:polished_blackstone
fill 283 235 210 283 238 210 minecraft:red_nether_bricks
setblock 283 235 214 minecraft:polished_blackstone
fill 283 235 215 283 238 215 minecraft:red_nether_bricks
setblock 283 235 219 minecraft:polished_blackstone
fill 283 235 220 283 238 220 minecraft:red_nether_bricks
fill 284 235 194 284 235 197 minecraft:red_nether_bricks
setblock 284 235 198 minecraft:polished_blackstone
fill 284 235 199 284 235 202 minecraft:red_nether_bricks
setblock 284 235 203 minecraft:polished_blackstone
fill 284 235 204 284 238 204 minecraft:red_nether_bricks
setblock 284 235 208 minecraft:polished_blackstone
setblock 284 235 209 minecraft:red_nether_bricks
setblock 284 235 213 minecraft:polished_blackstone
fill 284 235 214 284 236 214 minecraft:red_nether_bricks
setblock 284 235 218 minecraft:polished_blackstone
fill 284 235 219 284 237 219 minecraft:red_nether_bricks
setblock 285 235 197 minecraft:polished_blackstone
setblock 285 235 198 minecraft:red_nether_bricks
setblock 285 235 202 minecraft:polished_blackstone
setblock 285 235 217 minecraft:polished_blackstone
setblock 285 235 218 minecraft:red_nether_bricks
setblock 285 235 222 minecraft:polished_blackstone
setblock 286 235 221 minecraft:polished_blackstone
fill 286 235 222 286 237 222 minecraft:red_nether_bricks
setblock 295 235 222 minecraft:polished_blackstone
fill 296 235 182 299 235 182 minecraft:red_nether_bricks
fill 296 235 222 299 235 222 minecraft:red_nether_bricks
fill 298 235 221 300 235 221 minecraft:red_nether_bricks
setblock 299 235 183 minecraft:polished_blackstone
setblock 300 235 182 minecraft:polished_blackstone
fill 300 235 183 300 238 183 minecraft:red_nether_bricks
setblock 300 235 222 minecraft:polished_blackstone
fill 301 235 182 301 238 182 minecraft:red_nether_bricks
setblock 301 235 221 minecraft:polished_blackstone
fill 301 235 222 301 238 222 minecraft:red_nether_bricks
fill 302 235 221 302 238 221 minecraft:red_nether_bricks
setblock 304 235 183 minecraft:polished_blackstone
setblock 305 235 182 minecraft:polished_blackstone
fill 305 235 183 305 238 183 minecraft:red_nether_bricks
setblock 305 235 222 minecraft:polished_blackstone
fill 306 235 182 306 238 182 minecraft:red_nether_bricks
setblock 306 235 221 minecraft:polished_blackstone
fill 306 235 222 309 235 222 minecraft:red_nether_bricks
setblock 307 235 221 minecraft:red_nether_bricks
setblock 310 235 182 minecraft:polished_blackstone
setblock 310 235 222 minecraft:polished_blackstone
fill 311 235 182 311 238 182 minecraft:red_nether_bricks
fill 311 235 222 311 238 222 minecraft:red_nether_bricks
fill 312 235 221 312 238 221 minecraft:red_nether_bricks
setblock 315 235 182 minecraft:polished_blackstone
fill 315 235 220 316 235 220 minecraft:red_nether_bricks
setblock 315 235 222 minecraft:polished_blackstone
fill 316 235 182 316 238 182 minecraft:red_nether_bricks
setblock 316 235 221 minecraft:polished_blackstone
fill 316 235 222 316 238 222 minecraft:red_nether_bricks
setblock 317 235 220 minecraft:polished_blackstone
fill 317 235 221 317 238 221 minecraft:red_nether_bricks
setblock 318 235 219 minecraft:polished_blackstone
fill 318 235 220 318 238 220 minecraft:red_nether_bricks
setblock 319 235 183 minecraft:polished_blackstone
fill 319 235 219 319 237 219 minecraft:red_nether_bricks
setblock 320 235 182 minecraft:polished_blackstone
fill 320 235 183 320 238 183 minecraft:red_nether_bricks
setblock 320 235 217 minecraft:polished_blackstone
fill 320 235 218 320 236 218 minecraft:red_nether_bricks
setblock 320 235 222 minecraft:polished_blackstone
fill 321 235 182 321 238 182 minecraft:red_nether_bricks
setblock 321 235 216 minecraft:polished_blackstone
fill 321 235 217 321 238 217 minecraft:red_nether_bricks
setblock 321 235 221 minecraft:polished_blackstone
fill 321 235 222 321 238 222 minecraft:red_nether_bricks
setblock 322 235 195 minecraft:polished_blackstone
fill 322 235 196 322 236 196 minecraft:red_nether_bricks
setblock 322 235 200 minecraft:polished_blackstone
fill 322 235 201 322 238 201 minecraft:red_nether_bricks
setblock 322 235 204 minecraft:red_nether_bricks
setblock 322 235 210 minecraft:polished_blackstone
setblock 322 235 211 minecraft:red_nether_bricks
setblock 322 235 215 minecraft:polished_blackstone
fill 322 235 216 322 238 216 minecraft:red_nether_bricks
setblock 322 235 220 minecraft:polished_blackstone
fill 322 235 221 322 238 221 minecraft:red_nether_bricks
setblock 323 235 184 minecraft:polished_blackstone
setblock 323 235 185 minecraft:red_nether_bricks
setblock 323 235 194 minecraft:polished_blackstone
fill 323 235 195 323 237 195 minecraft:red_nether_bricks
setblock 323 235 199 minecraft:polished_blackstone
fill 323 235 200 323 238 200 minecraft:red_nether_bricks
setblock 323 235 204 minecraft:polished_blackstone
fill 323 235 205 323 238 205 minecraft:red_nether_bricks
setblock 323 235 209 minecraft:polished_blackstone
fill 323 235 210 323 238 210 minecraft:red_nether_bricks
setblock 323 235 214 minecraft:polished_blackstone
fill 323 235 215 323 238 215 minecraft:red_nether_bricks
setblock 323 235 219 minecraft:polished_blackstone
fill 323 235 220 323 238 220 minecraft:red_nether_bricks
setblock 283 236 193 minecraft:polished_blackstone
fill 283 236 194 283 236 197 minecraft:red_nether_bricks
setblock 283 236 198 minecraft:polished_blackstone
fill 283 236 199 283 236 202 minecraft:red_nether_bricks
setblock 283 236 203 minecraft:polished_blackstone
fill 283 236 204 283 236 207 minecraft:red_nether_bricks
setblock 283 236 208 minecraft:polished_blackstone
fill 283 236 209 283 239 209 minecraft:red_nether_bricks
setblock 283 236 213 minecraft:polished_blackstone
fill 283 236 214 283 239 214 minecraft:red_nether_bricks
setblock 283 236 218 minecraft:polished_blackstone
fill 283 236 219 283 239 219 minecraft:red_nether_bricks
fill 284 236 195 284 236 196 minecraft:red_nether_bricks
setblock 284 236 197 minecraft:polished_blackstone
fill 284 236 198 284 236 201 minecraft:red_nether_bricks
setblock 284 236 202 minecraft:polished_blackstone
fill 284 236 203 284 239 203 minecraft:red_nether_bricks
setblock 284 236 207 minecraft:polished_blackstone
setblock 284 236 213 minecraft:red_nether_bricks
setblock 284 236 217 minecraft:polished_blackstone
fill 284 236 218 284 237 218 minecraft:red_nether_bricks
setblock 284 236 222 minecraft:polished_blackstone
setblock 285 236 184 minecraft:light[level=14]
setblock 285 236 192 minecraft:light[level=14]
setblock 285 236 201 minecraft:polished_blackstone
setblock 285 236 202 minecraft:red_nether_bricks
setblock 285 236 208 minecraft:light[level=14]
setblock 285 236 216 minecraft:light[level=14]
setblock 285 236 221 minecraft:polished_blackstone
fill 285 236 222 285 239 222 minecraft:red_nether_bricks
setblock 293 236 184 minecraft:light[level=14]
setblock 293 236 192 minecraft:light[level=14]
setblock 293 236 200 minecraft:light[level=14]
setblock 293 236 208 minecraft:light[level=14]
setblock 293 236 216 minecraft:light[level=14]
fill 295 236 222 298 236 222 minecraft:red_nether_bricks
fill 296 236 182 298 236 182 minecraft:red_nether_bricks
setblock 298 236 183 minecraft:polished_blackstone
fill 298 236 221 299 236 221 minecraft:red_nether_bricks
setblock 299 236 182 minecraft:polished_blackstone
fill 299 236 183 299 239 183 minecraft:red_nether_bricks
setblock 299 236 222 minecraft:polished_blackstone
fill 300 236 182 300 239 182 minecraft:red_nether_bricks
setblock 300 236 221 minecraft:polished_blackstone
fill 300 236 222 300 239 222 minecraft:red_nether_bricks
setblock 301 236 184 minecraft:light[level=14]
setblock 301 236 192 minecraft:light[level=14]
setblock 301 236 200 minecraft:light[level=14]
setblock 301 236 208 minecraft:light[level=14]
setblock 301 236 216 minecraft:light[level=14]
fill 301 236 221 301 239 221 minecraft:red_nether_bricks
setblock 303 236 183 minecraft:polished_blackstone
setblock 304 236 182 minecraft:polished_blackstone
fill 304 236 183 304 239 183 minecraft:red_nether_bricks
setblock 304 236 222 minecraft:polished_blackstone
fill 305 236 182 305 239 182 minecraft:red_nether_bricks
setblock 305 236 221 minecraft:polished_blackstone
fill 305 236 222 308 236 222 minecraft:red_nether_bricks
setblock 306 236 221 minecraft:red_nether_bricks
setblock 309 236 182 minecraft:polished_blackstone
setblock 309 236 184 minecraft:light[level=14]
setblock 309 236 192 minecraft:light[level=14]
setblock 309 236 200 minecraft:light[level=14]
setblock 309 236 208 minecraft:light[level=14]
setblock 309 236 216 minecraft:light[level=14]
setblock 309 236 222 minecraft:polished_blackstone
fill 310 236 182 310 239 182 minecraft:red_nether_bricks
fill 310 236 222 310 239 222 minecraft:red_nether_bricks
setblock 314 236 182 minecraft:polished_blackstone
setblock 314 236 222 minecraft:polished_blackstone
fill 315 236 182 315 239 182 minecraft:red_nether_bricks
setblock 315 236 220 minecraft:red_nether_bricks
setblock 315 236 221 minecraft:polished_blackstone
fill 315 236 222 315 239 222 minecraft:red_nether_bricks
setblock 316 236 220 minecraft:polished_blackstone
fill 316 236 221 316 239 221 minecraft:red_nether_bricks
setblock 317 236 184 minecraft:light[level=14]
setblock 317 236 192 minecraft:light[level=14]
setblock 317 236 200 minecraft:light[level=14]
setblock 317 236 208 minecraft:light[level=14]
setblock 317 236 216 minecraft:light[level=14]
fill 317 236 220 317 239 220 minecraft:red_nether_bricks
setblock 318 236 182 minecraft:red_nether_bricks
setblock 318 236 183 minecraft:polished_blackstone
setblock 318 236 219 minecraft:red_nether_bricks
setblock 319 236 182 minecraft:polished_blackstone
fill 319 236 183 319 239 183 minecraft:red_nether_bricks
setblock 319 236 222 minecraft:polished_blackstone
fill 320 236 182 320 239 182 minecraft:red_nether_bricks
setblock 320 236 221 minecraft:polished_blackstone
fill 320 236 222 320 239 222 minecraft:red_nether_bricks
setblock 321 236 215 minecraft:polished_blackstone
fill 321 236 216 321 237 216 minecraft:red_nether_bricks
setblock 321 236 220 minecraft:polished_blackstone
fill 321 236 221 321 239 221 minecraft:red_nether_bricks
setblock 322 236 199 minecraft:polished_blackstone
fill 322 236 200 322 239 200 minecraft:red_nether_bricks
setblock 322 236 203 minecraft:red_nether_bricks
setblock 322 236 204 minecraft:polished_blackstone
setblock 322 236 214 minecraft:polished_blackstone
fill 322 236 215 322 239 215 minecraft:red_nether_bricks
setblock 322 236 219 minecraft:polished_blackstone
fill 322 236 220 322 239 220 minecraft:red_nether_bricks
setblock 323 236 183 minecraft:polished_blackstone
fill 323 236 184 323 239 184 minecraft:red_nether_bricks
setblock 323 236 194 minecraft:red_nether_bricks
setblock 323 236 198 minecraft:polished_blackstone
fill 323 236 199 323 239 199 minecraft:red_nether_bricks
setblock 323 236 203 minecraft:polished_blackstone
fill 323 236 204 323 239 204 minecraft:red_nether_bricks
setblock 323 236 208 minecraft:polished_blackstone
fill 323 236 209 323 239 209 minecraft:red_nether_bricks
setblock 323 236 213 minecraft:polished_blackstone
fill 323 236 214 323 239 214 minecraft:red_nether_bricks
setblock 323 236 218 minecraft:polished_blackstone
fill 323 236 219 323 239 219 minecraft:red_nether_bricks
setblock 283 237 182 minecraft:polished_blackstone
fill 283 237 194 283 237 196 minecraft:red_nether_bricks
setblock 283 237 197 minecraft:polished_blackstone
fill 283 237 198 283 237 201 minecraft:red_nether_bricks
setblock 283 237 202 minecraft:polished_blackstone
fill 283 237 203 283 237 206 minecraft:red_nether_bricks
setblock 283 237 207 minecraft:polished_blackstone
fill 283 237 208 283 240 208 minecraft:red_nether_bricks
setblock 283 237 212 minecraft:polished_blackstone
fill 283 237 213 283 239 213 minecraft:red_nether_bricks
setblock 283 237 217 minecraft:polished_blackstone
fill 283 237 218 283 240 218 minecraft:red_nether_bricks
setblock 283 237 222 minecraft:polished_blackstone
setblock 284 237 196 minecraft:polished_blackstone
fill 284 237 197 284 237 200 minecraft:red_nether_bricks
setblock 284 237 201 minecraft:polished_blackstone
fill 284 237 202 284 240 202 minecraft:red_nether_bricks
setblock 284 237 206 minecraft:polished_blackstone
setblock 284 237 217 minecraft:red_nether_bricks
setblock 284 237 221 minecraft:polished_blackstone
fill 284 237 222 284 240 222 minecraft:red_nether_bricks
fill 295 237 182 297 237 182 minecraft:red_nether_bricks
fill 295 237 222 297 237 222 minecraft:red_nether_bricks
setblock 297 237 183 minecraft:polished_blackstone
setblock 298 237 182 minecraft:polished_blackstone
fill 298 237 183 298 240 183 minecraft:red_nether_bricks
setblock 298 237 221 minecraft:red_nether_bricks
setblock 298 237 222 minecraft:polished_blackstone
fill 299 237 182 299 240 182 minecraft:red_nether_bricks
setblock 299 237 221 minecraft:polished_blackstone
fill 299 237 222 299 240 222 minecraft:red_nether_bricks
fill 300 237 221 300 240 221 minecraft:red_nether_bricks
setblock 302 237 183 minecraft:polished_blackstone
setblock 303 237 182 minecraft:polished_blackstone
fill 303 237 183 303 240 183 minecraft:red_nether_bricks
setblock 303 237 222 minecraft:polished_blackstone
fill 304 237 182 304 240 182 minecraft:red_nether_bricks
fill 304 237 192 305 238 193 minecraft:magma_block
setblock 304 237 221 minecraft:polished_blackstone
fill 304 237 222 307 237 222 minecraft:red_nether_bricks
fill 305 237 194 305 238 194 minecraft:magma_block
setblock 305 237 221 minecraft:red_nether_bricks
fill 306 237 193 306 238 193 minecraft:magma_block
setblock 308 237 182 minecraft:polished_blackstone
setblock 308 237 222 minecraft:polished_blackstone
fill 309 237 182 309 240 182 minecraft:red_nether_bricks
fill 309 237 222 309 240 222 minecraft:red_nether_bricks
setblock 313 237 182 minecraft:polished_blackstone
setblock 313 237 222 minecraft:polished_blackstone
fill 314 237 182 314 240 182 minecraft:red_nether_bricks
setblock 314 237 221 minecraft:polished_blackstone
fill 314 237 222 314 240 222 minecraft:red_nether_bricks
setblock 315 237 220 minecraft:polished_blackstone
fill 315 237 221 315 240 221 minecraft:red_nether_bricks
setblock 316 237 183 minecraft:red_nether_bricks
fill 316 237 220 316 240 220 minecraft:red_nether_bricks
setblock 317 237 182 minecraft:red_nether_bricks
setblock 317 237 183 minecraft:polished_blackstone
setblock 318 237 182 minecraft:polished_blackstone
fill 318 237 183 318 240 183 minecraft:red_nether_bricks
setblock 318 237 222 minecraft:polished_blackstone
fill 319 237 182 319 240 182 minecraft:red_nether_bricks
setblock 319 237 221 minecraft:polished_blackstone
fill 319 237 222 319 240 222 minecraft:red_nether_bricks
setblock 320 237 220 minecraft:polished_blackstone
fill 320 237 221 320 240 221 minecraft:red_nether_bricks
setblock 321 237 219 minecraft:polished_blackstone
fill 321 237 220 321 240 220 minecraft:red_nether_bricks
setblock 322 237 198 minecraft:polished_blackstone
fill 322 237 199 322 238 199 minecraft:red_nether_bricks
setblock 322 237 203 minecraft:polished_blackstone
fill 322 237 204 322 239 205 minecraft:red_nether_bricks
setblock 322 237 213 minecraft:polished_blackstone
fill 322 237 214 322 238 214 minecraft:red_nether_bricks
setblock 322 237 218 minecraft:polished_blackstone
fill 322 237 219 322 240 219 minecraft:red_nether_bricks
setblock 323 237 182 minecraft:polished_blackstone
fill 323 237 183 323 240 183 minecraft:red_nether_bricks
setblock 323 237 197 minecraft:polished_blackstone
fill 323 237 198 323 240 198 minecraft:red_nether_bricks
setblock 323 237 202 minecraft:polished_blackstone
fill 323 237 203 323 240 203 minecraft:red_nether_bricks
setblock 323 237 207 minecraft:polished_blackstone
fill 323 237 208 323 240 208 minecraft:red_nether_bricks
setblock 323 237 212 minecraft:polished_blackstone
fill 323 237 213 323 240 213 minecraft:red_nether_bricks
setblock 323 237 217 minecraft:polished_blackstone
fill 323 237 218 323 240 218 minecraft:red_nether_bricks
setblock 323 237 222 minecraft:polished_blackstone
setblock 283 238 182 minecraft:red_nether_bricks
setblock 283 238 195 minecraft:red_nether_bricks
setblock 283 238 196 minecraft:polished_blackstone
fill 283 238 197 283 238 200 minecraft:red_nether_bricks
setblock 283 238 201 minecraft:polished_blackstone
fill 283 238 202 283 238 205 minecraft:red_nether_bricks
setblock 283 238 206 minecraft:polished_blackstone
fill 283 238 207 283 241 207 minecraft:red_nether_bricks
setblock 283 238 211 minecraft:polished_blackstone
fill 283 238 212 283 239 212 minecraft:red_nether_bricks
setblock 283 238 216 minecraft:polished_blackstone
fill 283 238 217 283 240 217 minecraft:red_nether_bricks
setblock 283 238 221 minecraft:polished_blackstone
fill 283 238 222 283 241 222 minecraft:red_nether_bricks
fill 284 238 197 284 238 199 minecraft:red_nether_bricks
setblock 284 238 200 minecraft:polished_blackstone
fill 284 238 201 284 241 201 minecraft:red_nether_bricks
setblock 284 238 205 minecraft:polished_blackstone
fill 284 238 206 284 241 206 minecraft:red_nether_bricks
fill 294 238 182 296 238 182 minecraft:red_nether_bricks
fill 295 238 222 296 238 222 minecraft:red_nether_bricks
setblock 297 238 182 minecraft:polished_blackstone
fill 297 238 183 297 241 183 minecraft:red_nether_bricks
setblock 297 238 222 minecraft:polished_blackstone
fill 298 238 182 298 241 182 minecraft:red_nether_bricks
setblock 298 238 221 minecraft:polished_blackstone
fill 298 238 222 298 241 222 minecraft:red_nether_bricks
fill 299 238 221 299 241 221 minecraft:red_nether_bricks
setblock 301 238 183 minecraft:polished_blackstone
setblock 302 238 182 minecraft:polished_blackstone
fill 302 238 183 302 241 183 minecraft:red_nether_bricks
setblock 302 238 222 minecraft:polished_blackstone
fill 303 238 182 303 241 182 minecraft:red_nether_bricks
setblock 303 238 221 minecraft:polished_blackstone
fill 303 238 222 306 238 222 minecraft:red_nether_bricks
setblock 304 238 221 minecraft:red_nether_bricks
setblock 307 238 182 minecraft:polished_blackstone
setblock 307 238 222 minecraft:polished_blackstone
fill 308 238 182 308 241 182 minecraft:red_nether_bricks
fill 308 238 222 308 241 222 minecraft:red_nether_bricks
setblock 312 238 182 minecraft:polished_blackstone
setblock 312 238 222 minecraft:polished_blackstone
fill 313 238 182 313 241 182 minecraft:red_nether_bricks
setblock 313 238 221 minecraft:polished_blackstone
fill 313 238 222 313 241 222 minecraft:red_nether_bricks
fill 314 238 221 314 241 221 minecraft:red_nether_bricks
setblock 315 238 183 minecraft:red_nether_bricks
fill 315 238 220 315 241 220 minecraft:red_nether_bricks
setblock 316 238 183 minecraft:polished_blackstone
setblock 317 238 182 minecraft:polished_blackstone
fill 317 238 183 317 241 183 minecraft:red_nether_bricks
setblock 317 238 222 minecraft:polished_blackstone
fill 318 238 182 318 241 182 minecraft:red_nether_bricks
setblock 318 238 221 minecraft:polished_blackstone
fill 318 238 222 318 241 222 minecraft:red_nether_bricks
setblock 319 238 220 minecraft:polished_blackstone
fill 319 238 221 319 241 221 minecraft:red_nether_bricks
fill 320 238 220 320 241 220 minecraft:red_nether_bricks
setblock 321 238 183 minecraft:polished_blackstone
setblock 321 238 218 minecraft:polished_blackstone
fill 321 238 219 321 241 219 minecraft:red_nether_bricks
setblock 322 238 182 minecraft:polished_blackstone
setblock 322 238 202 minecraft:polished_blackstone
fill 322 238 203 322 241 203 minecraft:red_nether_bricks
setblock 322 238 217 minecraft:polished_blackstone
fill 322 238 218 322 241 218 minecraft:red_nether_bricks
setblock 322 238 222 minecraft:polished_blackstone
fill 323 238 182 323 241 182 minecraft:red_nether_bricks
setblock 323 238 196 minecraft:polished_blackstone
fill 323 238 197 323 239 197 minecraft:red_nether_bricks
setblock 323 238 201 minecraft:polished_blackstone
fill 323 238 202 323 241 202 minecraft:red_nether_bricks
setblock 323 238 206 minecraft:polished_blackstone
fill 323 238 207 323 241 207 minecraft:red_nether_bricks
setblock 323 238 211 minecraft:polished_blackstone
fill 323 238 212 323 241 212 minecraft:red_nether_bricks
setblock 323 238 216 minecraft:polished_blackstone
fill 323 238 217 323 241 217 minecraft:red_nether_bricks
setblock 323 238 221 minecraft:polished_blackstone
fill 323 238 222 323 241 222 minecraft:red_nether_bricks
setblock 283 239 195 minecraft:polished_blackstone
fill 283 239 196 283 239 199 minecraft:red_nether_bricks
setblock 283 239 200 minecraft:polished_blackstone
fill 283 239 201 283 239 204 minecraft:red_nether_bricks
setblock 283 239 205 minecraft:polished_blackstone
fill 283 239 206 283 242 206 minecraft:red_nether_bricks
setblock 283 239 210 minecraft:polished_blackstone
fill 283 239 211 283 242 211 minecraft:red_nether_bricks
setblock 283 239 215 minecraft:polished_blackstone
setblock 283 239 216 minecraft:red_nether_bricks
setblock 283 239 220 minecraft:polished_blackstone
fill 283 239 221 283 242 221 minecraft:red_nether_bricks
setblock 284 239 198 minecraft:red_nether_bricks
setblock 284 239 199 minecraft:polished_blackstone
fill 284 239 200 284 242 200 minecraft:red_nether_bricks
setblock 284 239 204 minecraft:polished_blackstone
fill 284 239 205 284 242 205 minecraft:red_nether_bricks
fill 293 239 182 295 239 182 minecraft:red_nether_bricks
fill 294 239 222 295 239 222 minecraft:red_nether_bricks
setblock 296 239 182 minecraft:polished_blackstone
fill 296 239 183 296 242 183 minecraft:red_nether_bricks
setblock 296 239 222 minecraft:polished_blackstone
fill 297 239 182 297 242 182 minecraft:red_nether_bricks
fill 297 239 222 297 242 222 minecraft:red_nether_bricks
fill 298 239 221 298 242 221 minecraft:red_nether_bricks
setblock 299 239 184 minecraft:polished_blackstone
setblock 300 239 183 minecraft:polished_blackstone
fill 300 239 184 301 241 184 minecraft:red_nether_bricks
setblock 301 239 182 minecraft:polished_blackstone
fill 301 239 183 301 242 183 minecraft:red_nether_bricks
setblock 301 239 222 minecraft:polished_blackstone
fill 302 239 182 302 242 182 minecraft:red_nether_bricks
setblock 302 239 221 minecraft:polished_blackstone
fill 302 239 222 305 239 222 minecraft:red_nether_bricks
setblock 303 239 221 minecraft:red_nether_bricks
setblock 305 239 183 minecraft:polished_blackstone
setblock 306 239 182 minecraft:polished_blackstone
fill 306 239 183 306 242 183 minecraft:red_nether_bricks
setblock 306 239 222 minecraft:polished_blackstone
fill 307 239 182 307 242 182 minecraft:red_nether_bricks
fill 307 239 222 307 242 222 minecraft:red_nether_bricks
setblock 311 239 182 minecraft:polished_blackstone
setblock 311 239 222 minecraft:polished_blackstone
fill 312 239 182 312 242 182 minecraft:red_nether_bricks
setblock 312 239 221 minecraft:polished_blackstone
fill 312 239 222 312 242 222 minecraft:red_nether_bricks
fill 313 239 183 314 239 183 minecraft:red_nether_bricks
fill 313 239 221 313 242 221 minecraft:red_nether_bricks
setblock 315 239 183 minecraft:polished_blackstone
setblock 316 239 182 minecraft:polished_blackstone
fill 316 239 183 316 242 183 minecraft:red_nether_bricks
setblock 316 239 222 minecraft:polished_blackstone
fill 317 239 182 317 242 182 minecraft:red_nether_bricks
setblock 317 239 221 minecraft:polished_blackstone
fill 317 239 222 317 242 222 minecraft:red_nether_bricks
setblock 318 239 220 minecraft:polished_blackstone
fill 318 239 221 318 242 221 minecraft:red_nether_bricks
fill 319 239 220 319 242 220 minecraft:red_nether_bricks
setblock 320 239 183 minecraft:polished_blackstone
setblock 321 239 182 minecraft:polished_blackstone
fill 321 239 183 321 242 183 minecraft:red_nether_bricks
setblock 321 239 217 minecraft:polished_blackstone
fill 321 239 218 321 240 218 minecraft:red_nether_bricks
setblock 321 239 222 minecraft:polished_blackstone
fill 322 239 182 322 242 182 minecraft:red_nether_bricks
setblock 322 239 201 minecraft:polished_blackstone
fill 322 239 202 322 242 202 minecraft:red_nether_bricks
setblock 322 239 206 minecraft:polished_blackstone
setblock 322 239 216 minecraft:polished_blackstone
fill 322 239 217 322 242 217 minecraft:red_nether_bricks
setblock 322 239 221 minecraft:polished_blackstone
fill 322 239 222 322 242 222 minecraft:red_nether_bricks
setblock 323 239 200 minecraft:polished_blackstone
fill 323 239 201 323 242 201 minecraft:red_nether_bricks
setblock 323 239 205 minecraft:polished_blackstone
fill 323 239 206 323 242 206 minecraft:red_nether_bricks
setblock 323 239 210 minecraft:polished_blackstone
fill 323 239 211 323 242 211 minecraft:red_nether_bricks
setblock 323 239 215 minecraft:polished_blackstone
fill 323 239 216 323 242 216 minecraft:red_nether_bricks
setblock 323 239 220 minecraft:polished_blackstone
fill 323 239 221 323 242 221 minecraft:red_nether_bricks
fill 283 240 182 283 241 182 minecraft:red_nether_bricks
fill 283 240 196 283 240 198 minecraft:red_nether_bricks
setblock 283 240 199 minecraft:polished_blackstone
fill 283 240 200 283 240 203 minecraft:red_nether_bricks
setblock 283 240 204 minecraft:polished_blackstone
fill 283 240 205 283 243 205 minecraft:red_nether_bricks
setblock 283 240 209 minecraft:polished_blackstone
fill 283 240 210 283 243 210 minecraft:red_nether_bricks
setblock 283 240 219 minecraft:polished_blackstone
fill 283 240 220 283 242 220 minecraft:red_nether_bricks
setblock 284 240 198 minecraft:polished_blackstone
fill 284 240 199 284 243 199 minecraft:red_nether_bricks
setblock 284 240 203 minecraft:polished_blackstone
fill 284 240 204 284 243 204 minecraft:red_nether_bricks
fill 287 240 210 288 241 210 minecraft:magma_block
fill 292 240 182 294 240 182 minecraft:red_nether_bricks
setblock 294 240 183 minecraft:polished_blackstone
setblock 294 240 222 minecraft:red_nether_bricks
setblock 295 240 182 minecraft:polished_blackstone
fill 295 240 183 295 243 183 minecraft:red_nether_bricks
setblock 295 240 222 minecraft:polished_blackstone
fill 296 240 182 296 243 182 minecraft:red_nether_bricks
fill 296 240 222 296 243 222 minecraft:red_nether_bricks
setblock 297 240 184 minecraft:red_nether_bricks
fill 297 240 221 297 243 221 minecraft:red_nether_bricks
setblock 298 240 184 minecraft:polished_blackstone
setblock 299 240 183 minecraft:polished_blackstone
fill 299 240 184 299 243 184 minecraft:red_nether_bricks
setblock 300 240 182 minecraft:polished_blackstone
fill 300 240 183 300 243 183 minecraft:red_nether_bricks
setblock 300 240 222 minecraft:polished_blackstone
fill 301 240 182 301 243 182 minecraft:red_nether_bricks
setblock 301 240 221 minecraft:polished_blackstone
fill 301 240 222 304 240 222 minecraft:red_nether_bricks
setblock 302 240 184 minecraft:red_nether_bricks
fill 302 240 221 302 241 221 minecraft:red_nether_bricks
setblock 304 240 183 minecraft:polished_blackstone
setblock 305 240 182 minecraft:polished_blackstone
fill 305 240 183 305 243 183 minecraft:red_nether_bricks
setblock 305 240 222 minecraft:polished_blackstone
fill 306 240 182 306 243 182 minecraft:red_nether_bricks
fill 306 240 222 306 243 222 minecraft:red_nether_bricks
setblock 310 240 182 minecraft:polished_blackstone
setblock 310 240 222 minecraft:polished_blackstone
fill 311 240 182 311 243 182 minecraft:red_nether_bricks
setblock 311 240 221 minecraft:polished_blackstone
fill 311 240 222 311 243 222 minecraft:red_nether_bricks
fill 312 240 183 313 240 183 minecraft:red_nether_bricks
fill 312 240 221 312 243 221 minecraft:red_nether_bricks
setblock 314 240 183 minecraft:polished_blackstone
setblock 315 240 182 minecraft:polished_blackstone
fill 315 240 183 315 243 183 minecraft:red_nether_bricks
setblock 315 240 222 minecraft:polished_blackstone
fill 316 240 182 316 243 182 minecraft:red_nether_bricks
setblock 316 240 221 minecraft:polished_blackstone
fill 316 240 222 316 243 222 minecraft:red_nether_bricks
setblock 317 240 220 minecraft:polished_blackstone
fill 317 240 221 317 243 221 minecraft:red_nether_bricks
fill 318 240 220 318 243 220 minecraft:red_nether_bricks
setblock 319 240 183 minecraft:polished_blackstone
setblock 320 240 182 minecraft:polished_blackstone
fill 320 240 183 320 243 183 minecraft:red_nether_bricks
setblock 320 240 222 minecraft:polished_blackstone
fill 321 240 182 321 243 182 minecraft:red_nether_bricks
setblock 321 240 221 minecraft:polished_blackstone
fill 321 240 222 321 243 222 minecraft:red_nether_bricks
setblock 322 240 200 minecraft:polished_blackstone
fill 322 240 201 322 243 201 minecraft:red_nether_bricks
setblock 322 240 204 minecraft:red_nether_bricks
setblock 322 240 205 minecraft:polished_blackstone
fill 322 240 206 322 241 208 minecraft:red_nether_bricks
fill 322 240 216 322 241 216 minecraft:red_nether_bricks
setblock 322 240 220 minecraft:polished_blackstone
fill 322 240 221 322 243 221 minecraft:red_nether_bricks
setblock 323 240 184 minecraft:polished_blackstone
setblock 323 240 199 minecraft:polished_blackstone
fill 323 240 200 323 243 200 minecraft:red_nether_bricks
setblock 323 240 204 minecraft:polished_blackstone
fill 323 240 205 323 243 205 minecraft:red_nether_bricks
setblock 323 240 209 minecraft:polished_blackstone
fill 323 240 210 323 243 210 minecraft:red_nether_bricks
setblock 323 240 214 minecraft:polished_blackstone
fill 323 240 215 323 243 215 minecraft:red_nether_bricks
setblock 323 240 219 minecraft:polished_blackstone
fill 323 240 220 323 243 220 minecraft:red_nether_bricks
fill 283 241 196 283 241 197 minecraft:red_nether_bricks
setblock 283 241 198 minecraft:polished_blackstone
fill 283 241 199 283 241 202 minecraft:red_nether_bricks
setblock 283 241 203 minecraft:polished_blackstone
fill 283 241 204 283 244 204 minecraft:red_nether_bricks
setblock 283 241 208 minecraft:polished_blackstone
fill 283 241 209 283 244 209 minecraft:red_nether_bricks
setblock 283 241 219 minecraft:red_nether_bricks
setblock 284 241 202 minecraft:polished_blackstone
fill 284 241 203 284 244 203 minecraft:red_nether_bricks
setblock 284 241 207 minecraft:polished_blackstone
setblock 284 241 222 minecraft:polished_blackstone
fill 290 241 204 292 242 204 minecraft:magma_block
fill 291 241 182 293 241 182 minecraft:red_nether_bricks
fill 291 241 205 292 242 205 minecraft:magma_block
setblock 293 241 183 minecraft:polished_blackstone
setblock 293 241 222 minecraft:red_nether_bricks
setblock 294 241 182 minecraft:polished_blackstone
fill 294 241 183 294 244 183 minecraft:red_nether_bricks
setblock 294 241 222 minecraft:polished_blackstone
fill 295 241 182 295 244 182 minecraft:red_nether_bricks
fill 295 241 184 296 241 184 minecraft:red_nether_bricks
fill 295 241 222 295 244 222 minecraft:red_nether_bricks
setblock 297 241 184 minecraft:polished_blackstone
setblock 298 241 183 minecraft:polished_blackstone
fill 298 241 184 298 244 184 minecraft:red_nether_bricks
setblock 299 241 182 minecraft:polished_blackstone
fill 299 241 183 299 244 183 minecraft:red_nether_bricks
setblock 299 241 222 minecraft:polished_blackstone
fill 300 241 182 300 244 182 minecraft:red_nether_bricks
setblock 300 241 221 minecraft:polished_blackstone
fill 300 241 222 303 241 222 minecraft:red_nether_bricks
fill 301 241 221 301 243 221 minecraft:red_nether_bricks
setblock 302 241 184 minecraft:polished_blackstone
setblock 303 241 183 minecraft:polished_blackstone
fill 303 241 184 303 244 184 minecraft:red_nether_bricks
setblock 304 241 182 minecraft:polished_blackstone
fill 304 241 183 304 244 183 minecraft:red_nether_bricks
setblock 304 241 222 minecraft:polished_blackstone
fill 305 241 182 305 244 182 minecraft:red_nether_bricks
fill 305 241 222 305 244 222 minecraft:red_nether_bricks
setblock 307 241 183 minecraft:red_nether_bricks
setblock 308 241 183 minecraft:polished_blackstone
setblock 309 241 182 minecraft:polished_blackstone
fill 309 241 183 312 241 183 minecraft:red_nether_bricks
setblock 309 241 222 minecraft:polished_blackstone
fill 310 241 182 310 244 182 minecraft:red_nether_bricks
fill 310 241 222 310 244 222 minecraft:red_nether_bricks
fill 311 241 221 311 244 221 minecraft:red_nether_bricks
setblock 313 241 183 minecraft:polished_blackstone
setblock 314 241 182 minecraft:polished_blackstone
fill 314 241 183 314 244 183 minecraft:red_nether_bricks
fill 314 241 220 314 242 220 minecraft:red_nether_bricks
setblock 314 241 222 minecraft:polished_blackstone
fill 315 241 182 315 244 182 minecraft:red_nether_bricks
setblock 315 241 221 minecraft:polished_blackstone
fill 315 241 222 315 244 222 minecraft:red_nether_bricks
setblock 316 241 220 minecraft:polished_blackstone
fill 316 241 221 316 244 221 minecraft:red_nether_bricks
fill 317 241 220 317 244 220 minecraft:red_nether_bricks
setblock 318 241 183 minecraft:polished_blackstone
setblock 319 241 182 minecraft:polished_blackstone
fill 319 241 183 319 244 183 minecraft:red_nether_bricks
setblock 319 241 222 minecraft:polished_blackstone
schedule function dropper:buildpart/42_10 1t
