fill 370 20 445 370 20 448 minecraft:red_concrete
setblock 370 20 450 minecraft:red_concrete
fill 370 20 452 370 20 455 minecraft:red_concrete
setblock 330 22 423 minecraft:red_concrete
setblock 330 22 430 minecraft:red_concrete
setblock 330 22 437 minecraft:red_concrete
setblock 330 22 444 minecraft:red_concrete
setblock 330 22 451 minecraft:red_concrete
setblock 331 22 417 minecraft:red_concrete
setblock 331 22 457 minecraft:red_concrete
setblock 338 22 417 minecraft:red_concrete
setblock 338 22 457 minecraft:red_concrete
setblock 345 22 417 minecraft:red_concrete
setblock 345 22 457 minecraft:red_concrete
fill 347 22 448 347 23 450 minecraft:yellow_wool
fill 348 22 449 348 23 450 minecraft:yellow_wool
setblock 352 22 417 minecraft:red_concrete
setblock 352 22 457 minecraft:red_concrete
setblock 359 22 417 minecraft:red_concrete
setblock 359 22 457 minecraft:red_concrete
setblock 366 22 417 minecraft:red_concrete
setblock 366 22 457 minecraft:red_concrete
setblock 370 22 420 minecraft:red_concrete
setblock 370 22 427 minecraft:red_concrete
setblock 370 22 434 minecraft:red_concrete
setblock 370 22 441 minecraft:red_concrete
setblock 370 22 448 minecraft:red_concrete
setblock 370 22 455 minecraft:red_concrete
setblock 330 23 417 minecraft:red_concrete
setblock 330 23 424 minecraft:red_concrete
setblock 330 23 431 minecraft:red_concrete
setblock 330 23 438 minecraft:red_concrete
setblock 330 23 445 minecraft:red_concrete
setblock 330 23 452 minecraft:red_concrete
setblock 332 23 457 minecraft:red_concrete
setblock 337 23 417 minecraft:red_concrete
setblock 339 23 457 minecraft:red_concrete
setblock 344 23 417 minecraft:red_concrete
setblock 346 23 457 minecraft:red_concrete
setblock 351 23 417 minecraft:red_concrete
setblock 353 23 457 minecraft:red_concrete
setblock 358 23 417 minecraft:red_concrete
setblock 360 23 457 minecraft:red_concrete
setblock 365 23 417 minecraft:red_concrete
setblock 367 23 457 minecraft:red_concrete
setblock 370 23 419 minecraft:red_concrete
setblock 370 23 426 minecraft:red_concrete
setblock 370 23 433 minecraft:red_concrete
setblock 370 23 440 minecraft:red_concrete
setblock 370 23 447 minecraft:red_concrete
setblock 370 23 454 minecraft:red_concrete
setblock 330 24 418 minecraft:red_concrete
setblock 330 24 425 minecraft:red_concrete
setblock 330 24 432 minecraft:red_concrete
setblock 330 24 439 minecraft:red_concrete
setblock 330 24 446 minecraft:red_concrete
setblock 330 24 453 minecraft:red_concrete
fill 331 24 435 331 25 441 minecraft:gray_concrete
setblock 332 24 419 minecraft:light[level=12]
setblock 332 24 427 minecraft:light[level=12]
setblock 332 24 435 minecraft:light[level=12]
setblock 332 24 443 minecraft:light[level=12]
setblock 332 24 451 minecraft:light[level=12]
setblock 333 24 457 minecraft:red_concrete
setblock 336 24 417 minecraft:red_concrete
setblock 340 24 419 minecraft:light[level=12]
setblock 340 24 427 minecraft:light[level=12]
setblock 340 24 435 minecraft:light[level=12]
setblock 340 24 443 minecraft:light[level=12]
setblock 340 24 451 minecraft:light[level=12]
setblock 340 24 457 minecraft:red_concrete
setblock 343 24 417 minecraft:red_concrete
setblock 347 24 457 minecraft:red_concrete
setblock 348 24 419 minecraft:light[level=12]
setblock 348 24 427 minecraft:light[level=12]
setblock 348 24 435 minecraft:light[level=12]
setblock 348 24 443 minecraft:light[level=12]
setblock 348 24 451 minecraft:light[level=12]
setblock 350 24 417 minecraft:red_concrete
setblock 354 24 457 minecraft:red_concrete
setblock 356 24 419 minecraft:light[level=12]
setblock 356 24 427 minecraft:light[level=12]
setblock 356 24 435 minecraft:light[level=12]
setblock 356 24 443 minecraft:light[level=12]
setblock 356 24 451 minecraft:light[level=12]
setblock 357 24 417 minecraft:red_concrete
setblock 361 24 457 minecraft:red_concrete
setblock 364 24 417 minecraft:red_concrete
setblock 364 24 419 minecraft:light[level=12]
setblock 364 24 427 minecraft:light[level=12]
setblock 364 24 435 minecraft:light[level=12]
setblock 364 24 443 minecraft:light[level=12]
setblock 364 24 451 minecraft:light[level=12]
setblock 368 24 457 minecraft:red_concrete
setblock 370 24 418 minecraft:red_concrete
setblock 370 24 425 minecraft:red_concrete
setblock 370 24 432 minecraft:red_concrete
setblock 370 24 439 minecraft:red_concrete
setblock 370 24 446 minecraft:red_concrete
setblock 370 24 453 minecraft:red_concrete
setblock 330 25 419 minecraft:red_concrete
setblock 330 25 426 minecraft:red_concrete
setblock 330 25 433 minecraft:red_concrete
setblock 330 25 440 minecraft:red_concrete
setblock 330 25 447 minecraft:red_concrete
setblock 330 25 454 minecraft:red_concrete
setblock 334 25 457 minecraft:red_concrete
setblock 335 25 417 minecraft:red_concrete
setblock 341 25 457 minecraft:red_concrete
setblock 342 25 417 minecraft:red_concrete
setblock 348 25 457 minecraft:red_concrete
setblock 349 25 417 minecraft:red_concrete
setblock 355 25 457 minecraft:red_concrete
setblock 356 25 417 minecraft:red_concrete
setblock 362 25 457 minecraft:red_concrete
setblock 363 25 417 minecraft:red_concrete
setblock 369 25 457 minecraft:red_concrete
setblock 370 25 417 minecraft:red_concrete
setblock 370 25 424 minecraft:red_concrete
setblock 370 25 431 minecraft:red_concrete
setblock 370 25 438 minecraft:red_concrete
setblock 370 25 445 minecraft:red_concrete
setblock 370 25 452 minecraft:red_concrete
setblock 330 26 420 minecraft:red_concrete
setblock 330 26 427 minecraft:red_concrete
setblock 330 26 434 minecraft:red_concrete
setblock 330 26 441 minecraft:red_concrete
setblock 330 26 448 minecraft:red_concrete
setblock 330 26 455 minecraft:red_concrete
setblock 334 26 417 minecraft:red_concrete
setblock 335 26 457 minecraft:red_concrete
setblock 341 26 417 minecraft:red_concrete
setblock 342 26 457 minecraft:red_concrete
setblock 348 26 417 minecraft:red_concrete
setblock 349 26 457 minecraft:red_concrete
setblock 355 26 417 minecraft:red_concrete
setblock 356 26 457 minecraft:red_concrete
setblock 362 26 417 minecraft:red_concrete
setblock 363 26 457 minecraft:red_concrete
setblock 369 26 417 minecraft:red_concrete
setblock 370 26 423 minecraft:red_concrete
setblock 370 26 430 minecraft:red_concrete
setblock 370 26 437 minecraft:red_concrete
setblock 370 26 444 minecraft:red_concrete
setblock 370 26 451 minecraft:red_concrete
setblock 370 26 457 minecraft:red_concrete
setblock 330 27 421 minecraft:red_concrete
setblock 330 27 428 minecraft:red_concrete
setblock 330 27 435 minecraft:red_concrete
setblock 330 27 442 minecraft:red_concrete
setblock 330 27 449 minecraft:red_concrete
setblock 330 27 456 minecraft:red_concrete
setblock 333 27 417 minecraft:red_concrete
setblock 336 27 457 minecraft:red_concrete
setblock 340 27 417 minecraft:red_concrete
setblock 343 27 457 minecraft:red_concrete
setblock 347 27 417 minecraft:red_concrete
setblock 350 27 457 minecraft:red_concrete
setblock 354 27 417 minecraft:red_concrete
setblock 357 27 457 minecraft:red_concrete
setblock 361 27 417 minecraft:red_concrete
setblock 364 27 457 minecraft:red_concrete
setblock 368 27 417 minecraft:red_concrete
setblock 370 27 422 minecraft:red_concrete
setblock 370 27 429 minecraft:red_concrete
setblock 370 27 436 minecraft:red_concrete
setblock 370 27 443 minecraft:red_concrete
setblock 370 27 450 minecraft:red_concrete
fill 330 29 423 330 30 423 minecraft:red_concrete
fill 330 29 430 330 30 430 minecraft:red_concrete
fill 330 29 437 330 30 437 minecraft:red_concrete
fill 330 29 444 330 30 444 minecraft:red_concrete
fill 330 29 451 330 30 451 minecraft:red_concrete
fill 331 29 417 331 30 417 minecraft:red_concrete
fill 331 29 457 331 30 457 minecraft:red_concrete
fill 338 29 417 338 30 417 minecraft:red_concrete
fill 338 29 457 338 30 457 minecraft:red_concrete
fill 345 29 417 345 30 417 minecraft:red_concrete
fill 345 29 457 345 30 457 minecraft:red_concrete
fill 352 29 417 352 30 417 minecraft:red_concrete
fill 352 29 457 352 30 457 minecraft:red_concrete
fill 359 29 417 359 30 417 minecraft:red_concrete
fill 359 29 457 359 30 457 minecraft:red_concrete
fill 366 29 417 366 30 417 minecraft:red_concrete
fill 366 29 457 366 30 457 minecraft:red_concrete
fill 370 29 420 370 30 420 minecraft:red_concrete
fill 370 29 427 370 30 427 minecraft:red_concrete
fill 370 29 434 370 30 434 minecraft:red_concrete
fill 370 29 441 370 30 441 minecraft:red_concrete
fill 370 29 448 370 30 448 minecraft:red_concrete
fill 370 29 455 370 30 455 minecraft:red_concrete
fill 330 30 417 330 30 421 minecraft:red_concrete
fill 330 30 424 330 30 428 minecraft:red_concrete
fill 330 30 431 330 30 435 minecraft:red_concrete
fill 330 30 438 330 30 442 minecraft:red_concrete
fill 330 30 445 330 30 449 minecraft:red_concrete
fill 330 30 452 330 30 456 minecraft:red_concrete
fill 332 30 457 336 30 457 minecraft:red_concrete
fill 333 30 417 337 30 417 minecraft:red_concrete
fill 339 30 457 343 30 457 minecraft:red_concrete
fill 340 30 417 344 30 417 minecraft:red_concrete
fill 346 30 457 350 30 457 minecraft:red_concrete
fill 347 30 417 351 30 417 minecraft:red_concrete
fill 353 30 419 357 31 423 minecraft:black_concrete
fill 353 30 457 357 30 457 minecraft:red_concrete
fill 354 30 417 358 30 417 minecraft:red_concrete
setblock 355 30 418 minecraft:black_concrete
fill 360 30 457 364 30 457 minecraft:red_concrete
fill 361 30 417 365 30 417 minecraft:red_concrete
fill 367 30 457 370 30 457 minecraft:red_concrete
fill 368 30 417 370 30 417 minecraft:red_concrete
fill 370 30 418 370 30 419 minecraft:red_concrete
fill 370 30 422 370 30 426 minecraft:red_concrete
fill 370 30 429 370 30 433 minecraft:red_concrete
fill 370 30 436 370 30 440 minecraft:red_concrete
fill 370 30 443 370 30 447 minecraft:red_concrete
fill 370 30 450 370 30 454 minecraft:red_concrete
setblock 330 31 418 minecraft:red_concrete
setblock 330 31 425 minecraft:red_concrete
setblock 330 31 432 minecraft:red_concrete
setblock 330 31 439 minecraft:red_concrete
setblock 330 31 446 minecraft:red_concrete
setblock 330 31 453 minecraft:red_concrete
setblock 333 31 457 minecraft:red_concrete
setblock 336 31 417 minecraft:red_concrete
setblock 340 31 457 minecraft:red_concrete
setblock 343 31 417 minecraft:red_concrete
setblock 347 31 457 minecraft:red_concrete
setblock 350 31 417 minecraft:red_concrete
setblock 354 31 457 minecraft:red_concrete
setblock 357 31 417 minecraft:red_concrete
setblock 361 31 457 minecraft:red_concrete
setblock 364 31 417 minecraft:red_concrete
setblock 368 31 457 minecraft:red_concrete
setblock 370 31 418 minecraft:red_concrete
setblock 370 31 425 minecraft:red_concrete
setblock 370 31 432 minecraft:red_concrete
setblock 370 31 439 minecraft:red_concrete
setblock 370 31 446 minecraft:red_concrete
setblock 370 31 453 minecraft:red_concrete
setblock 330 32 419 minecraft:red_concrete
setblock 330 32 426 minecraft:red_concrete
setblock 330 32 433 minecraft:red_concrete
setblock 330 32 440 minecraft:red_concrete
setblock 330 32 447 minecraft:red_concrete
setblock 330 32 454 minecraft:red_concrete
setblock 332 32 419 minecraft:light[level=12]
setblock 332 32 427 minecraft:light[level=12]
setblock 332 32 435 minecraft:light[level=12]
setblock 332 32 443 minecraft:light[level=12]
setblock 332 32 451 minecraft:light[level=12]
setblock 334 32 457 minecraft:red_concrete
setblock 335 32 417 minecraft:red_concrete
setblock 340 32 419 minecraft:light[level=12]
setblock 340 32 427 minecraft:light[level=12]
setblock 340 32 435 minecraft:light[level=12]
setblock 340 32 443 minecraft:light[level=12]
setblock 340 32 451 minecraft:light[level=12]
setblock 341 32 457 minecraft:red_concrete
setblock 342 32 417 minecraft:red_concrete
setblock 348 32 419 minecraft:light[level=12]
setblock 348 32 427 minecraft:light[level=12]
setblock 348 32 435 minecraft:light[level=12]
setblock 348 32 443 minecraft:light[level=12]
setblock 348 32 451 minecraft:light[level=12]
setblock 348 32 457 minecraft:red_concrete
setblock 349 32 417 minecraft:red_concrete
fill 350 32 419 354 33 423 minecraft:black_concrete
fill 352 32 417 352 32 418 minecraft:black_concrete
fill 355 32 421 355 37 421 minecraft:bone_block
setblock 355 32 457 minecraft:red_concrete
setblock 356 32 417 minecraft:red_concrete
setblock 356 32 419 minecraft:light[level=12]
setblock 356 32 427 minecraft:light[level=12]
setblock 356 32 435 minecraft:light[level=12]
setblock 356 32 443 minecraft:light[level=12]
setblock 356 32 451 minecraft:light[level=12]
setblock 362 32 457 minecraft:red_concrete
setblock 363 32 417 minecraft:red_concrete
setblock 364 32 419 minecraft:light[level=12]
setblock 364 32 427 minecraft:light[level=12]
setblock 364 32 435 minecraft:light[level=12]
setblock 364 32 443 minecraft:light[level=12]
setblock 364 32 451 minecraft:light[level=12]
setblock 369 32 457 minecraft:red_concrete
setblock 370 32 417 minecraft:red_concrete
setblock 370 32 424 minecraft:red_concrete
setblock 370 32 431 minecraft:red_concrete
setblock 370 32 438 minecraft:red_concrete
setblock 370 32 445 minecraft:red_concrete
setblock 370 32 452 minecraft:red_concrete
setblock 330 33 420 minecraft:red_concrete
setblock 330 33 427 minecraft:red_concrete
setblock 330 33 434 minecraft:red_concrete
setblock 330 33 441 minecraft:red_concrete
setblock 330 33 448 minecraft:red_concrete
setblock 330 33 455 minecraft:red_concrete
setblock 334 33 417 minecraft:red_concrete
setblock 335 33 457 minecraft:red_concrete
setblock 341 33 417 minecraft:red_concrete
setblock 342 33 457 minecraft:red_concrete
setblock 348 33 417 minecraft:red_concrete
setblock 349 33 457 minecraft:red_concrete
setblock 355 33 417 minecraft:red_concrete
fill 355 33 419 356 36 420 minecraft:bone_block
fill 355 33 422 356 36 423 minecraft:bone_block
fill 356 33 421 357 36 421 minecraft:bone_block
setblock 356 33 457 minecraft:red_concrete
fill 357 33 420 357 36 420 minecraft:bone_block
fill 357 33 422 357 36 422 minecraft:bone_block
setblock 362 33 417 minecraft:red_concrete
setblock 363 33 457 minecraft:red_concrete
setblock 369 33 417 minecraft:red_concrete
setblock 370 33 423 minecraft:red_concrete
setblock 370 33 430 minecraft:red_concrete
setblock 370 33 437 minecraft:red_concrete
setblock 370 33 444 minecraft:red_concrete
setblock 370 33 451 minecraft:red_concrete
setblock 370 33 457 minecraft:red_concrete
setblock 330 34 421 minecraft:red_concrete
setblock 330 34 428 minecraft:red_concrete
setblock 330 34 435 minecraft:red_concrete
setblock 330 34 442 minecraft:red_concrete
setblock 330 34 449 minecraft:red_concrete
setblock 330 34 456 minecraft:red_concrete
setblock 333 34 417 minecraft:red_concrete
setblock 336 34 457 minecraft:red_concrete
setblock 340 34 417 minecraft:red_concrete
setblock 343 34 457 minecraft:red_concrete
setblock 347 34 417 minecraft:red_concrete
setblock 350 34 457 minecraft:red_concrete
fill 352 34 421 354 38 421 minecraft:bone_block
fill 353 34 420 354 38 420 minecraft:bone_block
fill 353 34 422 354 38 422 minecraft:bone_block
setblock 354 34 417 minecraft:red_concrete
fill 354 34 419 354 36 419 minecraft:bone_block
fill 354 34 423 354 36 423 minecraft:bone_block
setblock 357 34 457 minecraft:red_concrete
setblock 361 34 417 minecraft:red_concrete
setblock 364 34 457 minecraft:red_concrete
setblock 368 34 417 minecraft:red_concrete
setblock 370 34 422 minecraft:red_concrete
setblock 370 34 429 minecraft:red_concrete
setblock 370 34 436 minecraft:red_concrete
setblock 370 34 443 minecraft:red_concrete
setblock 370 34 450 minecraft:red_concrete
fill 350 35 420 351 38 422 minecraft:bone_block
fill 351 35 419 353 38 419 minecraft:bone_block
fill 351 35 423 353 38 423 minecraft:bone_block
fill 352 35 420 352 38 420 minecraft:bone_block
fill 352 35 422 352 38 422 minecraft:bone_block
setblock 330 36 423 minecraft:red_concrete
setblock 330 36 430 minecraft:red_concrete
setblock 330 36 437 minecraft:red_concrete
setblock 330 36 444 minecraft:red_concrete
setblock 330 36 451 minecraft:red_concrete
setblock 331 36 417 minecraft:red_concrete
setblock 331 36 457 minecraft:red_concrete
setblock 338 36 417 minecraft:red_concrete
setblock 338 36 457 minecraft:red_concrete
setblock 345 36 417 minecraft:red_concrete
setblock 345 36 457 minecraft:red_concrete
setblock 352 36 417 minecraft:red_concrete
setblock 352 36 457 minecraft:red_concrete
setblock 359 36 417 minecraft:red_concrete
setblock 359 36 457 minecraft:red_concrete
setblock 366 36 417 minecraft:red_concrete
setblock 366 36 457 minecraft:red_concrete
setblock 370 36 420 minecraft:red_concrete
setblock 370 36 427 minecraft:red_concrete
setblock 370 36 434 minecraft:red_concrete
setblock 370 36 441 minecraft:red_concrete
setblock 370 36 448 minecraft:red_concrete
setblock 370 36 455 minecraft:red_concrete
setblock 330 37 417 minecraft:red_concrete
setblock 330 37 424 minecraft:red_concrete
setblock 330 37 431 minecraft:red_concrete
setblock 330 37 438 minecraft:red_concrete
setblock 330 37 445 minecraft:red_concrete
setblock 330 37 452 minecraft:red_concrete
setblock 332 37 457 minecraft:red_concrete
setblock 337 37 417 minecraft:red_concrete
setblock 339 37 457 minecraft:red_concrete
setblock 344 37 417 minecraft:red_concrete
setblock 346 37 457 minecraft:red_concrete
setblock 351 37 417 minecraft:red_concrete
setblock 353 37 457 minecraft:red_concrete
setblock 358 37 417 minecraft:red_concrete
setblock 360 37 457 minecraft:red_concrete
setblock 365 37 417 minecraft:red_concrete
setblock 367 37 457 minecraft:red_concrete
setblock 370 37 419 minecraft:red_concrete
setblock 370 37 426 minecraft:red_concrete
setblock 370 37 433 minecraft:red_concrete
setblock 370 37 440 minecraft:red_concrete
setblock 370 37 447 minecraft:red_concrete
setblock 370 37 454 minecraft:red_concrete
setblock 330 38 418 minecraft:red_concrete
setblock 330 38 425 minecraft:red_concrete
setblock 330 38 432 minecraft:red_concrete
setblock 330 38 439 minecraft:red_concrete
setblock 330 38 446 minecraft:red_concrete
setblock 330 38 453 minecraft:red_concrete
setblock 333 38 457 minecraft:red_concrete
setblock 336 38 417 minecraft:red_concrete
setblock 340 38 457 minecraft:red_concrete
setblock 343 38 417 minecraft:red_concrete
setblock 347 38 457 minecraft:red_concrete
setblock 350 38 417 minecraft:red_concrete
setblock 354 38 457 minecraft:red_concrete
setblock 357 38 417 minecraft:red_concrete
setblock 361 38 457 minecraft:red_concrete
setblock 364 38 417 minecraft:red_concrete
setblock 368 38 457 minecraft:red_concrete
setblock 370 38 418 minecraft:red_concrete
setblock 370 38 425 minecraft:red_concrete
setblock 370 38 432 minecraft:red_concrete
setblock 370 38 439 minecraft:red_concrete
setblock 370 38 446 minecraft:red_concrete
setblock 370 38 453 minecraft:red_concrete
fill 330 39 419 330 40 419 minecraft:red_concrete
fill 330 39 426 330 40 426 minecraft:red_concrete
fill 330 39 433 330 40 433 minecraft:red_concrete
fill 330 39 440 330 40 440 minecraft:red_concrete
fill 330 39 447 330 40 447 minecraft:red_concrete
fill 330 39 454 330 40 454 minecraft:red_concrete
fill 334 39 457 334 40 457 minecraft:red_concrete
fill 335 39 417 335 40 417 minecraft:red_concrete
fill 341 39 457 341 40 457 minecraft:red_concrete
fill 342 39 417 342 40 417 minecraft:red_concrete
fill 348 39 457 348 40 457 minecraft:red_concrete
fill 349 39 417 349 40 417 minecraft:red_concrete
setblock 352 39 421 minecraft:bone_block
fill 355 39 457 355 40 457 minecraft:red_concrete
fill 356 39 417 356 40 417 minecraft:red_concrete
fill 362 39 457 362 40 457 minecraft:red_concrete
fill 363 39 417 363 40 417 minecraft:red_concrete
fill 369 39 457 369 40 457 minecraft:red_concrete
fill 370 39 417 370 40 417 minecraft:red_concrete
fill 370 39 424 370 40 424 minecraft:red_concrete
fill 370 39 431 370 40 431 minecraft:red_concrete
fill 370 39 438 370 40 438 minecraft:red_concrete
fill 370 39 445 370 40 445 minecraft:red_concrete
fill 370 39 452 370 40 452 minecraft:red_concrete
fill 330 40 417 330 40 418 minecraft:red_concrete
fill 330 40 420 330 40 421 minecraft:red_concrete
fill 330 40 423 330 40 425 minecraft:red_concrete
fill 330 40 427 330 40 428 minecraft:red_concrete
fill 330 40 430 330 40 432 minecraft:red_concrete
fill 330 40 434 330 40 435 minecraft:red_concrete
fill 330 40 437 330 40 439 minecraft:red_concrete
fill 330 40 441 330 40 442 minecraft:red_concrete
fill 330 40 444 330 40 446 minecraft:red_concrete
fill 330 40 448 330 40 449 minecraft:red_concrete
fill 330 40 451 330 40 453 minecraft:red_concrete
fill 330 40 455 330 40 456 minecraft:red_concrete
setblock 331 40 417 minecraft:red_concrete
fill 331 40 457 333 40 457 minecraft:red_concrete
setblock 332 40 419 minecraft:light[level=12]
setblock 332 40 427 minecraft:light[level=12]
setblock 332 40 435 minecraft:light[level=12]
setblock 332 40 443 minecraft:light[level=12]
setblock 332 40 451 minecraft:light[level=12]
fill 333 40 417 334 40 417 minecraft:red_concrete
fill 335 40 457 336 40 457 minecraft:red_concrete
fill 336 40 417 338 40 417 minecraft:red_concrete
fill 338 40 457 340 40 457 minecraft:red_concrete
fill 340 40 417 341 40 417 minecraft:red_concrete
setblock 340 40 419 minecraft:light[level=12]
setblock 340 40 427 minecraft:light[level=12]
setblock 340 40 435 minecraft:light[level=12]
setblock 340 40 443 minecraft:light[level=12]
setblock 340 40 451 minecraft:light[level=12]
fill 342 40 457 343 40 457 minecraft:red_concrete
fill 343 40 417 345 40 417 minecraft:red_concrete
fill 345 40 457 347 40 457 minecraft:red_concrete
fill 347 40 417 348 40 417 minecraft:red_concrete
setblock 348 40 419 minecraft:light[level=12]
setblock 348 40 427 minecraft:light[level=12]
setblock 348 40 435 minecraft:light[level=12]
setblock 348 40 443 minecraft:light[level=12]
setblock 348 40 451 minecraft:light[level=12]
fill 349 40 457 350 40 457 minecraft:red_concrete
fill 350 40 417 352 40 417 minecraft:red_concrete
fill 352 40 457 354 40 457 minecraft:red_concrete
fill 354 40 417 355 40 417 minecraft:red_concrete
setblock 356 40 419 minecraft:light[level=12]
setblock 356 40 427 minecraft:light[level=12]
setblock 356 40 435 minecraft:light[level=12]
setblock 356 40 443 minecraft:light[level=12]
setblock 356 40 451 minecraft:light[level=12]
fill 356 40 457 357 40 457 minecraft:red_concrete
fill 357 40 417 359 40 417 minecraft:red_concrete
fill 359 40 457 361 40 457 minecraft:red_concrete
fill 361 40 417 362 40 417 minecraft:red_concrete
fill 363 40 457 364 40 457 minecraft:red_concrete
fill 364 40 417 366 40 417 minecraft:red_concrete
setblock 364 40 419 minecraft:light[level=12]
setblock 364 40 427 minecraft:light[level=12]
setblock 364 40 435 minecraft:light[level=12]
setblock 364 40 443 minecraft:light[level=12]
setblock 364 40 451 minecraft:light[level=12]
fill 366 40 457 368 40 457 minecraft:red_concrete
fill 368 40 417 369 40 417 minecraft:red_concrete
fill 370 40 418 370 40 420 minecraft:red_concrete
fill 370 40 422 370 40 423 minecraft:red_concrete
fill 370 40 425 370 40 427 minecraft:red_concrete
fill 370 40 429 370 40 430 minecraft:red_concrete
fill 370 40 432 370 40 434 minecraft:red_concrete
fill 370 40 436 370 40 437 minecraft:red_concrete
fill 370 40 439 370 40 441 minecraft:red_concrete
fill 370 40 443 370 40 444 minecraft:red_concrete
fill 370 40 446 370 40 448 minecraft:red_concrete
fill 370 40 450 370 40 451 minecraft:red_concrete
fill 370 40 453 370 40 455 minecraft:red_concrete
setblock 370 40 457 minecraft:red_concrete
setblock 330 41 421 minecraft:red_concrete
setblock 330 41 428 minecraft:red_concrete
setblock 330 41 435 minecraft:red_concrete
setblock 330 41 442 minecraft:red_concrete
setblock 330 41 449 minecraft:red_concrete
setblock 330 41 456 minecraft:red_concrete
setblock 333 41 417 minecraft:red_concrete
setblock 336 41 457 minecraft:red_concrete
setblock 340 41 417 minecraft:red_concrete
setblock 343 41 457 minecraft:red_concrete
setblock 347 41 417 minecraft:red_concrete
setblock 350 41 457 minecraft:red_concrete
setblock 354 41 417 minecraft:red_concrete
setblock 357 41 457 minecraft:red_concrete
setblock 361 41 417 minecraft:red_concrete
setblock 364 41 457 minecraft:red_concrete
setblock 368 41 417 minecraft:red_concrete
setblock 370 41 422 minecraft:red_concrete
setblock 370 41 429 minecraft:red_concrete
setblock 370 41 436 minecraft:red_concrete
setblock 370 41 443 minecraft:red_concrete
setblock 370 41 450 minecraft:red_concrete
fill 351 42 453 352 43 454 minecraft:white_wool
setblock 330 43 423 minecraft:red_concrete
setblock 330 43 430 minecraft:red_concrete
setblock 330 43 437 minecraft:red_concrete
setblock 330 43 444 minecraft:red_concrete
setblock 330 43 451 minecraft:red_concrete
setblock 331 43 417 minecraft:red_concrete
setblock 331 43 457 minecraft:red_concrete
setblock 338 43 417 minecraft:red_concrete
setblock 338 43 457 minecraft:red_concrete
setblock 345 43 417 minecraft:red_concrete
setblock 345 43 457 minecraft:red_concrete
setblock 352 43 417 minecraft:red_concrete
setblock 352 43 457 minecraft:red_concrete
setblock 359 43 417 minecraft:red_concrete
setblock 359 43 457 minecraft:red_concrete
setblock 366 43 417 minecraft:red_concrete
setblock 366 43 457 minecraft:red_concrete
setblock 370 43 420 minecraft:red_concrete
setblock 370 43 427 minecraft:red_concrete
setblock 370 43 434 minecraft:red_concrete
setblock 370 43 441 minecraft:red_concrete
setblock 370 43 448 minecraft:red_concrete
setblock 370 43 455 minecraft:red_concrete
setblock 330 44 417 minecraft:red_concrete
setblock 330 44 424 minecraft:red_concrete
setblock 330 44 431 minecraft:red_concrete
setblock 330 44 438 minecraft:red_concrete
setblock 330 44 445 minecraft:red_concrete
setblock 330 44 452 minecraft:red_concrete
setblock 332 44 457 minecraft:red_concrete
setblock 337 44 417 minecraft:red_concrete
setblock 339 44 457 minecraft:red_concrete
setblock 344 44 417 minecraft:red_concrete
setblock 346 44 457 minecraft:red_concrete
setblock 351 44 417 minecraft:red_concrete
setblock 353 44 457 minecraft:red_concrete
setblock 358 44 417 minecraft:red_concrete
setblock 360 44 457 minecraft:red_concrete
setblock 365 44 417 minecraft:red_concrete
setblock 367 44 457 minecraft:red_concrete
setblock 370 44 419 minecraft:red_concrete
setblock 370 44 426 minecraft:red_concrete
setblock 370 44 433 minecraft:red_concrete
setblock 370 44 440 minecraft:red_concrete
setblock 370 44 447 minecraft:red_concrete
setblock 370 44 454 minecraft:red_concrete
setblock 330 45 418 minecraft:red_concrete
setblock 330 45 425 minecraft:red_concrete
setblock 330 45 432 minecraft:red_concrete
setblock 330 45 439 minecraft:red_concrete
setblock 330 45 446 minecraft:red_concrete
setblock 330 45 453 minecraft:red_concrete
setblock 333 45 457 minecraft:red_concrete
setblock 336 45 417 minecraft:red_concrete
setblock 340 45 457 minecraft:red_concrete
setblock 343 45 417 minecraft:red_concrete
setblock 347 45 457 minecraft:red_concrete
setblock 350 45 417 minecraft:red_concrete
setblock 354 45 457 minecraft:red_concrete
setblock 357 45 417 minecraft:red_concrete
setblock 361 45 457 minecraft:red_concrete
setblock 364 45 417 minecraft:red_concrete
setblock 368 45 457 minecraft:red_concrete
setblock 370 45 418 minecraft:red_concrete
setblock 370 45 425 minecraft:red_concrete
setblock 370 45 432 minecraft:red_concrete
setblock 370 45 439 minecraft:red_concrete
setblock 370 45 446 minecraft:red_concrete
setblock 370 45 453 minecraft:red_concrete
setblock 330 46 419 minecraft:red_concrete
setblock 330 46 426 minecraft:red_concrete
setblock 330 46 433 minecraft:red_concrete
setblock 330 46 440 minecraft:red_concrete
setblock 330 46 447 minecraft:red_concrete
setblock 330 46 454 minecraft:red_concrete
setblock 334 46 457 minecraft:red_concrete
setblock 335 46 417 minecraft:red_concrete
setblock 341 46 457 minecraft:red_concrete
setblock 342 46 417 minecraft:red_concrete
setblock 348 46 457 minecraft:red_concrete
setblock 349 46 417 minecraft:red_concrete
setblock 355 46 457 minecraft:red_concrete
setblock 356 46 417 minecraft:red_concrete
setblock 362 46 457 minecraft:red_concrete
setblock 363 46 417 minecraft:red_concrete
setblock 369 46 457 minecraft:red_concrete
setblock 370 46 417 minecraft:red_concrete
setblock 370 46 424 minecraft:red_concrete
setblock 370 46 431 minecraft:red_concrete
setblock 370 46 438 minecraft:red_concrete
setblock 370 46 445 minecraft:red_concrete
setblock 370 46 452 minecraft:red_concrete
setblock 330 47 420 minecraft:red_concrete
setblock 330 47 427 minecraft:red_concrete
setblock 330 47 434 minecraft:red_concrete
setblock 330 47 441 minecraft:red_concrete
setblock 330 47 448 minecraft:red_concrete
setblock 330 47 455 minecraft:red_concrete
setblock 334 47 417 minecraft:red_concrete
setblock 335 47 457 minecraft:red_concrete
setblock 341 47 417 minecraft:red_concrete
setblock 342 47 457 minecraft:red_concrete
setblock 348 47 417 minecraft:red_concrete
setblock 349 47 457 minecraft:red_concrete
setblock 355 47 417 minecraft:red_concrete
setblock 356 47 457 minecraft:red_concrete
setblock 362 47 417 minecraft:red_concrete
setblock 363 47 457 minecraft:red_concrete
setblock 369 47 417 minecraft:red_concrete
setblock 370 47 423 minecraft:red_concrete
setblock 370 47 430 minecraft:red_concrete
setblock 370 47 437 minecraft:red_concrete
setblock 370 47 444 minecraft:red_concrete
setblock 370 47 451 minecraft:red_concrete
setblock 370 47 457 minecraft:red_concrete
setblock 330 48 421 minecraft:red_concrete
setblock 330 48 428 minecraft:red_concrete
setblock 330 48 435 minecraft:red_concrete
setblock 330 48 442 minecraft:red_concrete
setblock 330 48 449 minecraft:red_concrete
setblock 330 48 456 minecraft:red_concrete
setblock 332 48 419 minecraft:light[level=12]
setblock 332 48 427 minecraft:light[level=12]
setblock 332 48 435 minecraft:light[level=12]
setblock 332 48 443 minecraft:light[level=12]
setblock 332 48 451 minecraft:light[level=12]
setblock 333 48 417 minecraft:red_concrete
setblock 336 48 457 minecraft:red_concrete
setblock 340 48 417 minecraft:red_concrete
setblock 340 48 419 minecraft:light[level=12]
setblock 340 48 427 minecraft:light[level=12]
setblock 340 48 435 minecraft:light[level=12]
setblock 340 48 443 minecraft:light[level=12]
setblock 340 48 451 minecraft:light[level=12]
setblock 343 48 457 minecraft:red_concrete
setblock 347 48 417 minecraft:red_concrete
setblock 348 48 419 minecraft:light[level=12]
setblock 348 48 427 minecraft:light[level=12]
setblock 348 48 435 minecraft:light[level=12]
setblock 348 48 443 minecraft:light[level=12]
setblock 348 48 451 minecraft:light[level=12]
setblock 350 48 457 minecraft:red_concrete
setblock 354 48 417 minecraft:red_concrete
setblock 356 48 419 minecraft:light[level=12]
setblock 356 48 427 minecraft:light[level=12]
setblock 356 48 435 minecraft:light[level=12]
setblock 356 48 443 minecraft:light[level=12]
setblock 356 48 451 minecraft:light[level=12]
setblock 357 48 457 minecraft:red_concrete
setblock 361 48 417 minecraft:red_concrete
setblock 364 48 419 minecraft:light[level=12]
setblock 364 48 427 minecraft:light[level=12]
setblock 364 48 435 minecraft:light[level=12]
setblock 364 48 443 minecraft:light[level=12]
setblock 364 48 451 minecraft:light[level=12]
setblock 364 48 457 minecraft:red_concrete
setblock 368 48 417 minecraft:red_concrete
setblock 370 48 422 minecraft:red_concrete
setblock 370 48 429 minecraft:red_concrete
setblock 370 48 436 minecraft:red_concrete
setblock 370 48 443 minecraft:red_concrete
setblock 370 48 450 minecraft:red_concrete
fill 330 50 417 330 50 421 minecraft:red_concrete
fill 330 50 423 330 50 428 minecraft:red_concrete
fill 330 50 430 330 50 435 minecraft:red_concrete
fill 330 50 437 330 50 442 minecraft:red_concrete
fill 330 50 444 330 50 449 minecraft:red_concrete
fill 330 50 451 330 50 456 minecraft:red_concrete
setblock 331 50 417 minecraft:red_concrete
fill 331 50 457 336 50 457 minecraft:red_concrete
fill 333 50 417 338 50 417 minecraft:red_concrete
fill 338 50 457 343 50 457 minecraft:red_concrete
fill 340 50 417 345 50 417 minecraft:red_concrete
fill 345 50 457 350 50 457 minecraft:red_concrete
fill 347 50 417 352 50 417 minecraft:red_concrete
fill 352 50 457 357 50 457 minecraft:red_concrete
fill 354 50 417 359 50 417 minecraft:red_concrete
fill 359 50 457 364 50 457 minecraft:red_concrete
fill 361 50 417 366 50 417 minecraft:red_concrete
fill 366 50 457 370 50 457 minecraft:red_concrete
fill 368 50 417 370 50 417 minecraft:red_concrete
fill 370 50 418 370 50 420 minecraft:red_concrete
fill 370 50 422 370 50 427 minecraft:red_concrete
fill 370 50 429 370 50 434 minecraft:red_concrete
fill 370 50 436 370 50 441 minecraft:red_concrete
fill 370 50 443 370 50 448 minecraft:red_concrete
fill 370 50 450 370 50 455 minecraft:red_concrete
setblock 330 51 417 minecraft:red_concrete
setblock 330 51 424 minecraft:red_concrete
setblock 330 51 431 minecraft:red_concrete
setblock 330 51 438 minecraft:red_concrete
setblock 330 51 445 minecraft:red_concrete
setblock 330 51 452 minecraft:red_concrete
setblock 332 51 457 minecraft:red_concrete
setblock 337 51 417 minecraft:red_concrete
setblock 339 51 457 minecraft:red_concrete
fill 341 51 450 345 52 454 minecraft:black_concrete
fill 343 51 455 343 51 456 minecraft:black_concrete
setblock 344 51 417 minecraft:red_concrete
setblock 346 51 457 minecraft:red_concrete
setblock 351 51 417 minecraft:red_concrete
setblock 353 51 457 minecraft:red_concrete
setblock 358 51 417 minecraft:red_concrete
setblock 360 51 457 minecraft:red_concrete
setblock 365 51 417 minecraft:red_concrete
setblock 367 51 457 minecraft:red_concrete
setblock 370 51 419 minecraft:red_concrete
setblock 370 51 426 minecraft:red_concrete
setblock 370 51 433 minecraft:red_concrete
setblock 370 51 440 minecraft:red_concrete
setblock 370 51 447 minecraft:red_concrete
setblock 370 51 454 minecraft:red_concrete
setblock 330 52 418 minecraft:red_concrete
setblock 330 52 425 minecraft:red_concrete
setblock 330 52 432 minecraft:red_concrete
setblock 330 52 439 minecraft:red_concrete
setblock 330 52 446 minecraft:red_concrete
setblock 330 52 453 minecraft:red_concrete
setblock 333 52 457 minecraft:red_concrete
setblock 336 52 417 minecraft:red_concrete
setblock 340 52 457 minecraft:red_concrete
setblock 343 52 417 minecraft:red_concrete
setblock 347 52 457 minecraft:red_concrete
setblock 350 52 417 minecraft:red_concrete
setblock 354 52 457 minecraft:red_concrete
setblock 357 52 417 minecraft:red_concrete
setblock 361 52 457 minecraft:red_concrete
setblock 364 52 417 minecraft:red_concrete
setblock 368 52 457 minecraft:red_concrete
setblock 370 52 418 minecraft:red_concrete
setblock 370 52 425 minecraft:red_concrete
setblock 370 52 432 minecraft:red_concrete
setblock 370 52 439 minecraft:red_concrete
setblock 370 52 446 minecraft:red_concrete
setblock 370 52 453 minecraft:red_concrete
setblock 330 53 419 minecraft:red_concrete
setblock 330 53 426 minecraft:red_concrete
setblock 330 53 433 minecraft:red_concrete
setblock 330 53 440 minecraft:red_concrete
setblock 330 53 447 minecraft:red_concrete
setblock 330 53 454 minecraft:red_concrete
setblock 334 53 457 minecraft:red_concrete
setblock 335 53 417 minecraft:red_concrete
setblock 341 53 457 minecraft:red_concrete
setblock 342 53 417 minecraft:red_concrete
fill 343 53 452 343 58 452 minecraft:bone_block
setblock 348 53 457 minecraft:red_concrete
setblock 349 53 417 minecraft:red_concrete
setblock 355 53 457 minecraft:red_concrete
setblock 356 53 417 minecraft:red_concrete
setblock 362 53 457 minecraft:red_concrete
setblock 363 53 417 minecraft:red_concrete
setblock 369 53 457 minecraft:red_concrete
setblock 370 53 417 minecraft:red_concrete
setblock 370 53 424 minecraft:red_concrete
setblock 370 53 431 minecraft:red_concrete
setblock 370 53 438 minecraft:red_concrete
setblock 370 53 445 minecraft:red_concrete
setblock 370 53 452 minecraft:red_concrete
setblock 330 54 420 minecraft:red_concrete
setblock 330 54 427 minecraft:red_concrete
setblock 330 54 434 minecraft:red_concrete
setblock 330 54 441 minecraft:red_concrete
setblock 330 54 448 minecraft:red_concrete
setblock 330 54 455 minecraft:red_concrete
setblock 334 54 417 minecraft:red_concrete
setblock 335 54 457 minecraft:red_concrete
setblock 341 54 417 minecraft:red_concrete
fill 341 54 451 342 57 453 minecraft:bone_block
fill 342 54 450 344 57 450 minecraft:bone_block
fill 342 54 454 344 57 454 minecraft:bone_block
setblock 342 54 457 minecraft:red_concrete
fill 343 54 451 345 57 451 minecraft:bone_block
fill 343 54 453 345 57 453 minecraft:bone_block
fill 344 54 452 345 57 452 minecraft:bone_block
setblock 348 54 417 minecraft:red_concrete
setblock 349 54 457 minecraft:red_concrete
setblock 355 54 417 minecraft:red_concrete
setblock 356 54 457 minecraft:red_concrete
setblock 362 54 417 minecraft:red_concrete
setblock 363 54 457 minecraft:red_concrete
setblock 369 54 417 minecraft:red_concrete
setblock 370 54 423 minecraft:red_concrete
setblock 370 54 430 minecraft:red_concrete
setblock 370 54 437 minecraft:red_concrete
setblock 370 54 444 minecraft:red_concrete
setblock 370 54 451 minecraft:red_concrete
setblock 370 54 457 minecraft:red_concrete
setblock 330 55 421 minecraft:red_concrete
setblock 330 55 428 minecraft:red_concrete
setblock 330 55 435 minecraft:red_concrete
setblock 330 55 442 minecraft:red_concrete
setblock 330 55 449 minecraft:red_concrete
setblock 330 55 456 minecraft:red_concrete
setblock 333 55 417 minecraft:red_concrete
setblock 336 55 457 minecraft:red_concrete
setblock 340 55 417 minecraft:red_concrete
setblock 343 55 457 minecraft:red_concrete
setblock 347 55 417 minecraft:red_concrete
setblock 350 55 457 minecraft:red_concrete
setblock 354 55 417 minecraft:red_concrete
setblock 357 55 457 minecraft:red_concrete
setblock 361 55 417 minecraft:red_concrete
setblock 364 55 457 minecraft:red_concrete
setblock 368 55 417 minecraft:red_concrete
setblock 370 55 422 minecraft:red_concrete
setblock 370 55 429 minecraft:red_concrete
setblock 370 55 436 minecraft:red_concrete
setblock 370 55 443 minecraft:red_concrete
setblock 370 55 450 minecraft:red_concrete
setblock 332 56 419 minecraft:light[level=12]
setblock 332 56 427 minecraft:light[level=12]
setblock 332 56 435 minecraft:light[level=12]
setblock 332 56 443 minecraft:light[level=12]
setblock 332 56 451 minecraft:light[level=12]
setblock 340 56 419 minecraft:light[level=12]
setblock 340 56 427 minecraft:light[level=12]
setblock 340 56 435 minecraft:light[level=12]
setblock 340 56 443 minecraft:light[level=12]
setblock 340 56 451 minecraft:light[level=12]
setblock 348 56 419 minecraft:light[level=12]
setblock 348 56 427 minecraft:light[level=12]
setblock 348 56 435 minecraft:light[level=12]
setblock 348 56 443 minecraft:light[level=12]
setblock 348 56 451 minecraft:light[level=12]
setblock 356 56 419 minecraft:light[level=12]
setblock 356 56 427 minecraft:light[level=12]
setblock 356 56 435 minecraft:light[level=12]
setblock 356 56 443 minecraft:light[level=12]
setblock 356 56 451 minecraft:light[level=12]
setblock 364 56 419 minecraft:light[level=12]
setblock 364 56 427 minecraft:light[level=12]
setblock 364 56 435 minecraft:light[level=12]
setblock 364 56 443 minecraft:light[level=12]
setblock 364 56 451 minecraft:light[level=12]
setblock 330 57 423 minecraft:red_concrete
setblock 330 57 430 minecraft:red_concrete
setblock 330 57 437 minecraft:red_concrete
setblock 330 57 444 minecraft:red_concrete
setblock 330 57 451 minecraft:red_concrete
setblock 331 57 417 minecraft:red_concrete
setblock 331 57 457 minecraft:red_concrete
setblock 338 57 417 minecraft:red_concrete
setblock 338 57 457 minecraft:red_concrete
setblock 345 57 417 minecraft:red_concrete
setblock 345 57 457 minecraft:red_concrete
setblock 352 57 417 minecraft:red_concrete
setblock 352 57 457 minecraft:red_concrete
setblock 359 57 417 minecraft:red_concrete
setblock 359 57 457 minecraft:red_concrete
setblock 366 57 417 minecraft:red_concrete
setblock 366 57 457 minecraft:red_concrete
setblock 370 57 420 minecraft:red_concrete
setblock 370 57 427 minecraft:red_concrete
setblock 370 57 434 minecraft:red_concrete
setblock 370 57 441 minecraft:red_concrete
setblock 370 57 448 minecraft:red_concrete
setblock 370 57 455 minecraft:red_concrete
setblock 330 58 417 minecraft:red_concrete
setblock 330 58 424 minecraft:red_concrete
setblock 330 58 431 minecraft:red_concrete
setblock 330 58 438 minecraft:red_concrete
setblock 330 58 445 minecraft:red_concrete
setblock 330 58 452 minecraft:red_concrete
setblock 332 58 457 minecraft:red_concrete
setblock 337 58 417 minecraft:red_concrete
setblock 339 58 457 minecraft:red_concrete
setblock 344 58 417 minecraft:red_concrete
setblock 346 58 457 minecraft:red_concrete
setblock 351 58 417 minecraft:red_concrete
setblock 353 58 457 minecraft:red_concrete
setblock 358 58 417 minecraft:red_concrete
setblock 360 58 457 minecraft:red_concrete
setblock 365 58 417 minecraft:red_concrete
setblock 367 58 457 minecraft:red_concrete
setblock 370 58 419 minecraft:red_concrete
setblock 370 58 426 minecraft:red_concrete
setblock 370 58 433 minecraft:red_concrete
setblock 370 58 440 minecraft:red_concrete
setblock 370 58 447 minecraft:red_concrete
setblock 370 58 454 minecraft:red_concrete
fill 330 59 418 330 60 418 minecraft:red_concrete
fill 330 59 425 330 60 425 minecraft:red_concrete
fill 330 59 432 330 60 432 minecraft:red_concrete
fill 330 59 439 330 60 439 minecraft:red_concrete
fill 330 59 446 330 60 446 minecraft:red_concrete
fill 330 59 453 330 60 453 minecraft:red_concrete
fill 333 59 457 333 60 457 minecraft:red_concrete
fill 336 59 417 336 60 417 minecraft:red_concrete
fill 340 59 457 340 60 457 minecraft:red_concrete
fill 343 59 417 343 60 417 minecraft:red_concrete
fill 347 59 457 347 60 457 minecraft:red_concrete
fill 350 59 417 350 60 417 minecraft:red_concrete
fill 354 59 457 354 60 457 minecraft:red_concrete
fill 357 59 417 357 60 417 minecraft:red_concrete
fill 361 59 457 361 60 457 minecraft:red_concrete
fill 364 59 417 364 60 417 minecraft:red_concrete
fill 368 59 457 368 60 457 minecraft:red_concrete
fill 370 59 418 370 60 418 minecraft:red_concrete
fill 370 59 425 370 60 425 minecraft:red_concrete
fill 370 59 432 370 60 432 minecraft:red_concrete
fill 370 59 439 370 60 439 minecraft:red_concrete
fill 370 59 446 370 60 446 minecraft:red_concrete
fill 370 59 453 370 60 453 minecraft:red_concrete
fill 330 60 417 331 60 417 minecraft:red_concrete
fill 330 60 419 330 60 421 minecraft:red_concrete
fill 330 60 423 330 60 424 minecraft:red_concrete
fill 330 60 426 330 60 428 minecraft:red_concrete
fill 330 60 430 330 60 431 minecraft:red_concrete
fill 330 60 433 330 60 435 minecraft:red_concrete
fill 330 60 437 330 60 438 minecraft:red_concrete
fill 330 60 440 330 60 442 minecraft:red_concrete
fill 330 60 444 330 60 445 minecraft:red_concrete
fill 330 60 447 330 60 449 minecraft:red_concrete
fill 330 60 451 330 60 452 minecraft:red_concrete
fill 330 60 454 330 60 456 minecraft:red_concrete
fill 331 60 457 332 60 457 minecraft:red_concrete
fill 333 60 417 335 60 417 minecraft:red_concrete
fill 334 60 457 336 60 457 minecraft:red_concrete
fill 337 60 417 338 60 417 minecraft:red_concrete
fill 338 60 457 339 60 457 minecraft:red_concrete
fill 340 60 417 342 60 417 minecraft:red_concrete
fill 341 60 457 343 60 457 minecraft:red_concrete
fill 344 60 417 345 60 417 minecraft:red_concrete
fill 345 60 457 346 60 457 minecraft:red_concrete
fill 347 60 417 349 60 417 minecraft:red_concrete
fill 348 60 457 350 60 457 minecraft:red_concrete
fill 351 60 417 352 60 417 minecraft:red_concrete
fill 352 60 457 353 60 457 minecraft:red_concrete
fill 354 60 417 356 60 417 minecraft:red_concrete
fill 355 60 457 357 60 457 minecraft:red_concrete
fill 358 60 417 359 60 417 minecraft:red_concrete
fill 359 60 457 360 60 457 minecraft:red_concrete
fill 361 60 417 363 60 417 minecraft:red_concrete
fill 362 60 457 364 60 457 minecraft:red_concrete
fill 365 60 417 366 60 417 minecraft:red_concrete
fill 366 60 457 367 60 457 minecraft:red_concrete
fill 368 60 417 370 60 417 minecraft:red_concrete
fill 369 60 457 370 60 457 minecraft:red_concrete
fill 370 60 419 370 60 420 minecraft:red_concrete
fill 370 60 422 370 60 424 minecraft:red_concrete
fill 370 60 426 370 60 427 minecraft:red_concrete
fill 370 60 429 370 60 431 minecraft:red_concrete
fill 370 60 433 370 60 434 minecraft:red_concrete
fill 370 60 436 370 60 438 minecraft:red_concrete
fill 370 60 440 370 60 441 minecraft:red_concrete
fill 370 60 443 370 60 445 minecraft:red_concrete
fill 370 60 447 370 60 448 minecraft:red_concrete
fill 370 60 450 370 60 452 minecraft:red_concrete
fill 370 60 454 370 60 455 minecraft:red_concrete
setblock 332 64 419 minecraft:light[level=12]
setblock 332 64 427 minecraft:light[level=12]
setblock 332 64 435 minecraft:light[level=12]
setblock 332 64 443 minecraft:light[level=12]
setblock 332 64 451 minecraft:light[level=12]
setblock 340 64 419 minecraft:light[level=12]
setblock 340 64 427 minecraft:light[level=12]
setblock 340 64 435 minecraft:light[level=12]
setblock 340 64 443 minecraft:light[level=12]
setblock 340 64 451 minecraft:light[level=12]
setblock 348 64 419 minecraft:light[level=12]
setblock 348 64 427 minecraft:light[level=12]
setblock 348 64 435 minecraft:light[level=12]
setblock 348 64 443 minecraft:light[level=12]
setblock 348 64 451 minecraft:light[level=12]
setblock 356 64 419 minecraft:light[level=12]
setblock 356 64 427 minecraft:light[level=12]
setblock 356 64 435 minecraft:light[level=12]
setblock 356 64 443 minecraft:light[level=12]
setblock 356 64 451 minecraft:light[level=12]
setblock 364 64 419 minecraft:light[level=12]
setblock 364 64 427 minecraft:light[level=12]
setblock 364 64 435 minecraft:light[level=12]
setblock 364 64 443 minecraft:light[level=12]
setblock 364 64 451 minecraft:light[level=12]
fill 347 65 432 349 65 434 minecraft:redstone_block
fill 347 65 438 349 65 440 minecraft:redstone_block
fill 352 65 440 354 65 442 minecraft:redstone_block
fill 355 65 432 357 65 434 minecraft:redstone_block
fill 336 66 436 341 67 436 minecraft:red_concrete
fill 337 66 431 341 67 435 minecraft:red_concrete
fill 337 66 437 340 67 441 minecraft:red_concrete
fill 338 66 429 338 67 429 minecraft:white_concrete
fill 338 66 430 354 67 430 minecraft:red_concrete
fill 338 66 442 340 67 443 minecraft:red_concrete
fill 339 66 427 339 67 428 minecraft:white_concrete
fill 339 66 429 354 67 429 minecraft:red_concrete
fill 339 66 444 340 67 445 minecraft:red_concrete
fill 340 66 426 341 67 427 minecraft:white_concrete
fill 340 66 428 353 67 428 minecraft:red_concrete
fill 340 66 446 341 67 446 minecraft:red_concrete
fill 341 66 425 356 67 425 minecraft:white_concrete
fill 341 66 437 344 67 445 minecraft:white_concrete
fill 341 66 447 341 67 447 minecraft:red_concrete
fill 342 66 424 354 67 424 minecraft:white_concrete
fill 342 66 426 343 67 426 minecraft:white_concrete
fill 342 66 427 352 67 427 minecraft:red_concrete
fill 342 66 431 342 67 434 minecraft:red_concrete
fill 342 66 435 345 67 436 minecraft:white_concrete
fill 342 66 446 345 67 447 minecraft:white_concrete
fill 342 66 448 342 67 448 minecraft:red_concrete
fill 343 66 423 353 67 423 minecraft:white_concrete
fill 343 66 431 343 67 433 minecraft:red_concrete
fill 343 66 434 346 66 434 minecraft:white_concrete
fill 343 66 448 347 67 449 minecraft:white_concrete
fill 344 66 426 350 67 426 minecraft:red_concrete
fill 344 66 431 345 67 432 minecraft:red_concrete
fill 344 66 433 346 66 433 minecraft:white_concrete
fill 345 66 422 350 67 422 minecraft:white_concrete
fill 345 66 437 346 66 444 minecraft:red_concrete
fill 345 66 445 345 67 445 minecraft:white_concrete
fill 345 66 450 349 67 450 minecraft:white_concrete
fill 346 66 431 355 66 431 minecraft:red_concrete
setblock 346 66 432 minecraft:white_concrete
setblock 346 66 435 minecraft:white_concrete
fill 346 66 436 348 67 436 minecraft:red_concrete
fill 346 66 445 354 67 446 minecraft:red_concrete
fill 346 66 447 346 67 447 minecraft:white_concrete
fill 347 66 421 357 67 421 minecraft:red_concrete
fill 347 66 435 348 66 435 minecraft:red_concrete
fill 347 66 437 348 66 437 minecraft:red_concrete
fill 347 66 441 349 66 444 minecraft:red_concrete
fill 347 66 447 363 67 447 minecraft:red_concrete
fill 347 66 451 352 67 451 minecraft:white_concrete
fill 348 66 448 362 67 448 minecraft:red_concrete
fill 348 66 449 348 67 449 minecraft:white_concrete
fill 349 66 435 350 66 437 minecraft:black_concrete
fill 349 66 449 361 67 449 minecraft:red_concrete
fill 350 66 432 350 66 433 minecraft:white_concrete
fill 350 66 434 354 66 434 minecraft:black_concrete
fill 350 66 438 354 66 438 minecraft:black_concrete
fill 350 66 439 350 66 441 minecraft:white_concrete
fill 350 66 442 350 67 444 minecraft:red_concrete
fill 350 66 450 359 67 450 minecraft:red_concrete
fill 351 66 422 359 67 422 minecraft:red_concrete
fill 351 66 426 356 67 426 minecraft:white_concrete
fill 351 66 432 354 66 432 minecraft:red_concrete
fill 351 66 433 353 67 433 minecraft:black_concrete
fill 351 66 439 353 66 439 minecraft:black_concrete
fill 351 66 440 351 66 443 minecraft:white_concrete
fill 351 66 444 352 67 444 minecraft:red_concrete
fill 352 66 420 352 67 420 minecraft:red_concrete
fill 352 66 443 363 66 443 minecraft:white_concrete
fill 352 66 452 352 67 452 minecraft:white_concrete
fill 353 66 427 357 67 427 minecraft:white_concrete
fill 353 66 444 361 67 444 minecraft:white_concrete
fill 353 66 451 357 67 451 minecraft:red_concrete
fill 354 66 423 361 67 423 minecraft:red_concrete
fill 354 66 428 358 67 428 minecraft:white_concrete
setblock 354 66 433 minecraft:red_concrete
fill 354 66 435 355 66 437 minecraft:black_concrete
fill 354 66 439 362 66 439 minecraft:red_concrete
fill 355 66 424 362 67 424 minecraft:red_concrete
fill 355 66 429 358 67 430 minecraft:white_concrete
fill 355 66 438 362 67 438 minecraft:red_concrete
fill 355 66 440 359 66 441 minecraft:red_concrete
fill 355 66 442 364 66 442 minecraft:white_concrete
fill 355 66 445 359 67 445 minecraft:white_concrete
fill 355 66 446 364 67 446 minecraft:red_concrete
fill 356 66 431 358 66 431 minecraft:white_concrete
fill 356 66 435 357 66 436 minecraft:white_concrete
fill 356 66 437 363 67 437 minecraft:red_concrete
fill 357 66 425 363 67 426 minecraft:red_concrete
fill 358 66 427 364 67 427 minecraft:red_concrete
fill 358 66 432 358 66 434 minecraft:white_concrete
fill 358 66 435 364 66 436 minecraft:red_concrete
fill 359 66 428 364 67 434 minecraft:red_concrete
fill 360 66 440 360 67 440 minecraft:red_concrete
fill 360 66 441 365 67 441 minecraft:white_concrete
fill 360 66 445 365 67 445 minecraft:red_concrete
fill 361 66 440 366 67 440 minecraft:white_concrete
fill 362 66 444 365 67 444 minecraft:red_concrete
fill 363 66 438 367 67 439 minecraft:white_concrete
fill 364 66 426 364 67 426 minecraft:red_concrete
fill 364 66 437 367 67 437 minecraft:white_concrete
fill 364 66 443 366 67 443 minecraft:red_concrete
fill 365 66 427 365 67 428 minecraft:white_concrete
fill 365 66 429 365 67 432 minecraft:red_concrete
fill 365 66 433 367 67 436 minecraft:white_concrete
fill 365 66 442 366 67 442 minecraft:red_concrete
fill 366 66 429 366 67 432 minecraft:white_concrete
fill 366 66 441 367 67 441 minecraft:red_concrete
fill 367 66 431 367 67 432 minecraft:white_concrete
fill 367 66 440 367 67 440 minecraft:red_concrete
fill 368 66 436 368 67 436 minecraft:white_concrete
fill 330 67 417 335 67 457 minecraft:purple_concrete
fill 336 67 417 336 67 435 minecraft:purple_concrete
fill 336 67 437 336 67 457 minecraft:purple_concrete
fill 337 67 417 337 67 430 minecraft:purple_concrete
fill 337 67 442 337 67 457 minecraft:purple_concrete
fill 338 67 417 338 67 428 minecraft:purple_concrete
fill 338 67 444 338 67 457 minecraft:purple_concrete
fill 339 67 417 339 67 426 minecraft:purple_concrete
fill 339 67 446 339 67 457 minecraft:purple_concrete
fill 340 67 417 340 67 425 minecraft:purple_concrete
fill 340 67 447 340 67 457 minecraft:purple_concrete
fill 341 67 417 341 67 424 minecraft:purple_concrete
fill 341 67 448 341 67 457 minecraft:purple_concrete
fill 342 67 417 342 67 423 minecraft:purple_concrete
fill 342 67 449 342 67 457 minecraft:purple_concrete
fill 343 67 417 344 67 422 minecraft:purple_concrete
fill 343 67 434 345 67 434 minecraft:white_concrete
fill 343 67 450 344 67 457 minecraft:purple_concrete
fill 344 67 433 345 67 433 minecraft:white_concrete
fill 345 67 417 346 67 421 minecraft:purple_concrete
fill 345 67 437 345 67 444 minecraft:red_concrete
fill 345 67 451 346 67 457 minecraft:purple_concrete
fill 346 67 431 346 67 435 minecraft:jack_o_lantern
fill 346 67 437 346 67 441 minecraft:jack_o_lantern
fill 346 67 442 349 67 444 minecraft:red_concrete
fill 347 67 417 351 67 420 minecraft:purple_concrete
fill 347 67 431 350 67 431 minecraft:jack_o_lantern
fill 347 67 432 349 67 434 minecraft:purple_concrete
fill 347 67 435 350 67 435 minecraft:jack_o_lantern
fill 347 67 437 350 67 437 minecraft:jack_o_lantern
fill 347 67 438 349 67 440 minecraft:purple_concrete
fill 347 67 441 351 67 441 minecraft:jack_o_lantern
fill 347 67 452 351 67 457 minecraft:purple_concrete
setblock 349 67 436 minecraft:black_concrete
fill 350 67 432 350 67 434 minecraft:jack_o_lantern
setblock 350 67 436 minecraft:jack_o_lantern
fill 350 67 438 351 67 440 minecraft:jack_o_lantern
fill 351 67 431 353 67 432 minecraft:red_concrete
fill 351 67 434 354 67 434 minecraft:jack_o_lantern
fill 351 67 442 351 67 443 minecraft:jack_o_lantern
fill 352 67 417 370 67 419 minecraft:purple_concrete
fill 352 67 438 354 67 439 minecraft:jack_o_lantern
fill 352 67 440 354 67 442 minecraft:purple_concrete
fill 352 67 443 355 67 443 minecraft:jack_o_lantern
fill 352 67 453 370 67 457 minecraft:purple_concrete
fill 353 67 420 370 67 420 minecraft:purple_concrete
fill 353 67 452 370 67 452 minecraft:purple_concrete
fill 354 67 431 354 67 433 minecraft:jack_o_lantern
fill 354 67 435 354 67 437 minecraft:jack_o_lantern
fill 355 67 431 358 67 431 minecraft:jack_o_lantern
fill 355 67 432 357 67 434 minecraft:purple_concrete
fill 355 67 435 358 67 435 minecraft:jack_o_lantern
fill 355 67 436 355 67 437 minecraft:black_concrete
fill 355 67 439 355 67 442 minecraft:jack_o_lantern
fill 356 67 436 357 67 436 minecraft:white_concrete
fill 356 67 439 359 67 441 minecraft:red_concrete
fill 356 67 442 363 67 443 minecraft:white_concrete
fill 358 67 421 370 67 421 minecraft:purple_concrete
fill 358 67 432 358 67 434 minecraft:jack_o_lantern
fill 358 67 436 364 67 436 minecraft:red_concrete
fill 358 67 451 370 67 451 minecraft:purple_concrete
fill 359 67 435 364 67 435 minecraft:red_concrete
fill 360 67 422 370 67 422 minecraft:purple_concrete
fill 360 67 439 362 67 439 minecraft:red_concrete
fill 360 67 450 370 67 450 minecraft:purple_concrete
fill 362 67 423 370 67 423 minecraft:purple_concrete
fill 362 67 449 370 67 449 minecraft:purple_concrete
fill 363 67 424 370 67 424 minecraft:purple_concrete
fill 363 67 448 370 67 448 minecraft:purple_concrete
fill 364 67 425 370 67 425 minecraft:purple_concrete
setblock 364 67 442 minecraft:white_concrete
fill 364 67 447 370 67 447 minecraft:purple_concrete
fill 365 67 426 370 67 426 minecraft:purple_concrete
fill 365 67 446 370 67 446 minecraft:purple_concrete
fill 366 67 427 370 67 428 minecraft:purple_concrete
fill 366 67 444 370 67 445 minecraft:purple_concrete
fill 367 67 429 370 67 430 minecraft:purple_concrete
fill 367 67 442 370 67 443 minecraft:purple_concrete
fill 368 67 431 370 67 435 minecraft:purple_concrete
fill 368 67 437 370 67 441 minecraft:purple_concrete
fill 369 67 436 370 67 436 minecraft:purple_concrete
fill 330 71 422 330 71 423 minecraft:red_concrete
fill 330 71 429 330 71 430 minecraft:red_concrete
fill 330 71 436 330 71 437 minecraft:red_concrete
fill 330 71 443 330 71 444 minecraft:red_concrete
fill 330 71 450 330 72 457 minecraft:red_concrete
fill 331 71 417 332 71 417 minecraft:red_concrete
fill 331 71 451 335 72 457 minecraft:red_concrete
fill 337 71 457 338 71 457 minecraft:red_concrete
fill 338 71 417 339 71 417 minecraft:red_concrete
fill 344 71 457 345 71 457 minecraft:red_concrete
fill 345 71 417 346 71 417 minecraft:red_concrete
fill 351 71 457 352 71 457 minecraft:red_concrete
fill 352 71 417 353 71 417 minecraft:red_concrete
fill 358 71 457 359 71 457 minecraft:red_concrete
fill 359 71 417 360 71 417 minecraft:red_concrete
fill 365 71 457 366 71 457 minecraft:red_concrete
fill 366 71 417 367 71 417 minecraft:red_concrete
fill 370 71 420 370 71 421 minecraft:red_concrete
fill 370 71 427 370 71 428 minecraft:red_concrete
fill 370 71 434 370 71 435 minecraft:red_concrete
fill 370 71 441 370 71 442 minecraft:red_concrete
fill 370 71 448 370 71 449 minecraft:red_concrete
fill 370 71 455 370 71 456 minecraft:red_concrete
setblock 330 72 417 minecraft:red_concrete
fill 330 72 422 330 165 422 minecraft:red_concrete
setblock 330 72 424 minecraft:red_concrete
fill 330 72 429 330 165 429 minecraft:red_concrete
setblock 330 72 431 minecraft:red_concrete
fill 330 72 436 330 165 436 minecraft:red_concrete
setblock 330 72 438 minecraft:red_concrete
fill 330 72 443 330 165 443 minecraft:red_concrete
setblock 330 72 445 minecraft:red_concrete
fill 332 72 417 332 165 417 minecraft:red_concrete
setblock 332 72 419 minecraft:light[level=12]
setblock 332 72 427 minecraft:light[level=12]
setblock 332 72 435 minecraft:light[level=12]
setblock 332 72 443 minecraft:light[level=12]
setblock 337 72 417 minecraft:red_concrete
fill 337 72 457 337 165 457 minecraft:red_concrete
fill 339 72 417 339 165 417 minecraft:red_concrete
setblock 339 72 457 minecraft:red_concrete
setblock 340 72 419 minecraft:light[level=12]
setblock 340 72 427 minecraft:light[level=12]
setblock 340 72 435 minecraft:light[level=12]
setblock 340 72 443 minecraft:light[level=12]
setblock 340 72 451 minecraft:light[level=12]
setblock 344 72 417 minecraft:red_concrete
fill 344 72 457 344 165 457 minecraft:red_concrete
fill 346 72 417 346 165 417 minecraft:red_concrete
setblock 346 72 457 minecraft:red_concrete
setblock 348 72 419 minecraft:light[level=12]
setblock 348 72 427 minecraft:light[level=12]
setblock 348 72 435 minecraft:light[level=12]
setblock 348 72 443 minecraft:light[level=12]
setblock 348 72 451 minecraft:light[level=12]
setblock 351 72 417 minecraft:red_concrete
fill 351 72 457 351 165 457 minecraft:red_concrete
fill 353 72 417 353 165 417 minecraft:red_concrete
setblock 353 72 457 minecraft:red_concrete
setblock 356 72 419 minecraft:light[level=12]
setblock 356 72 427 minecraft:light[level=12]
setblock 356 72 435 minecraft:light[level=12]
setblock 356 72 443 minecraft:light[level=12]
setblock 356 72 451 minecraft:light[level=12]
setblock 358 72 417 minecraft:red_concrete
fill 358 72 457 358 165 457 minecraft:red_concrete
fill 360 72 417 360 165 417 minecraft:red_concrete
setblock 360 72 457 minecraft:red_concrete
setblock 364 72 419 minecraft:light[level=12]
setblock 364 72 427 minecraft:light[level=12]
setblock 364 72 435 minecraft:light[level=12]
setblock 364 72 443 minecraft:light[level=12]
setblock 364 72 451 minecraft:light[level=12]
setblock 365 72 417 minecraft:red_concrete
fill 365 72 457 365 165 457 minecraft:red_concrete
fill 367 72 417 367 165 417 minecraft:red_concrete
setblock 367 72 457 minecraft:red_concrete
setblock 370 72 419 minecraft:red_concrete
fill 370 72 421 370 165 421 minecraft:red_concrete
setblock 370 72 426 minecraft:red_concrete
fill 370 72 428 370 165 428 minecraft:red_concrete
setblock 370 72 433 minecraft:red_concrete
fill 370 72 435 370 165 435 minecraft:red_concrete
setblock 370 72 440 minecraft:red_concrete
fill 370 72 442 370 165 442 minecraft:red_concrete
setblock 370 72 447 minecraft:red_concrete
fill 370 72 449 370 165 449 minecraft:red_concrete
setblock 370 72 454 minecraft:red_concrete
fill 370 72 456 370 165 456 minecraft:red_concrete
fill 329 73 416 329 81 451 minecraft:black_concrete
setblock 329 73 452 minecraft:jack_o_lantern
fill 329 73 453 329 82 453 minecraft:black_concrete
setblock 329 73 454 minecraft:jack_o_lantern
fill 329 73 455 329 83 455 minecraft:black_concrete
setblock 329 73 456 minecraft:jack_o_lantern
fill 329 73 457 329 81 458 minecraft:black_concrete
setblock 330 73 418 minecraft:red_concrete
setblock 330 73 425 minecraft:red_concrete
setblock 330 73 432 minecraft:red_concrete
setblock 330 73 439 minecraft:red_concrete
setblock 330 73 446 minecraft:red_concrete
fill 330 73 450 330 165 450 minecraft:red_concrete
setblock 330 73 451 minecraft:jack_o_lantern
fill 330 73 452 330 83 452 minecraft:red_concrete
setblock 330 73 453 minecraft:jack_o_lantern
fill 330 73 454 330 83 454 minecraft:red_concrete
setblock 330 73 455 minecraft:jack_o_lantern
fill 330 73 456 330 83 456 minecraft:red_concrete
setblock 330 73 457 minecraft:jack_o_lantern
fill 331 73 451 331 83 451 minecraft:red_concrete
setblock 331 73 452 minecraft:jack_o_lantern
fill 331 73 453 331 83 453 minecraft:red_concrete
setblock 331 73 454 minecraft:jack_o_lantern
fill 331 73 455 331 83 455 minecraft:red_concrete
setblock 331 73 456 minecraft:jack_o_lantern
fill 331 73 457 331 83 457 minecraft:red_concrete
setblock 332 73 451 minecraft:jack_o_lantern
fill 332 73 452 332 83 452 minecraft:red_concrete
setblock 332 73 453 minecraft:jack_o_lantern
fill 332 73 454 332 83 454 minecraft:red_concrete
setblock 332 73 455 minecraft:jack_o_lantern
fill 332 73 456 332 83 456 minecraft:red_concrete
setblock 332 73 457 minecraft:jack_o_lantern
fill 333 73 451 333 83 451 minecraft:red_concrete
setblock 333 73 452 minecraft:jack_o_lantern
fill 333 73 453 333 83 453 minecraft:red_concrete
setblock 333 73 454 minecraft:jack_o_lantern
fill 333 73 455 333 83 455 minecraft:red_concrete
setblock 333 73 456 minecraft:jack_o_lantern
fill 333 73 457 333 83 457 minecraft:red_concrete
setblock 334 73 451 minecraft:jack_o_lantern
fill 334 73 452 334 83 452 minecraft:red_concrete
setblock 334 73 453 minecraft:jack_o_lantern
fill 334 73 454 334 83 454 minecraft:red_concrete
setblock 334 73 455 minecraft:jack_o_lantern
fill 334 73 456 334 83 456 minecraft:red_concrete
setblock 334 73 457 minecraft:jack_o_lantern
fill 335 73 451 335 83 451 minecraft:red_concrete
setblock 335 73 452 minecraft:jack_o_lantern
fill 335 73 453 335 83 453 minecraft:red_concrete
setblock 335 73 454 minecraft:jack_o_lantern
fill 335 73 455 335 83 455 minecraft:red_concrete
setblock 335 73 456 minecraft:jack_o_lantern
fill 335 73 457 335 83 457 minecraft:red_concrete
setblock 336 73 417 minecraft:red_concrete
setblock 340 73 457 minecraft:red_concrete
setblock 343 73 417 minecraft:red_concrete
setblock 347 73 457 minecraft:red_concrete
setblock 350 73 417 minecraft:red_concrete
setblock 354 73 457 minecraft:red_concrete
setblock 357 73 417 minecraft:red_concrete
setblock 361 73 457 minecraft:red_concrete
setblock 364 73 417 minecraft:red_concrete
setblock 368 73 457 minecraft:red_concrete
setblock 370 73 418 minecraft:red_concrete
setblock 370 73 425 minecraft:red_concrete
setblock 370 73 432 minecraft:red_concrete
setblock 370 73 439 minecraft:red_concrete
setblock 370 73 446 minecraft:red_concrete
setblock 370 73 453 minecraft:red_concrete
fill 329 74 452 329 75 452 minecraft:black_concrete
fill 329 74 454 329 75 454 minecraft:black_concrete
fill 329 74 456 329 75 456 minecraft:black_concrete
setblock 330 74 419 minecraft:red_concrete
setblock 330 74 426 minecraft:red_concrete
setblock 330 74 433 minecraft:red_concrete
setblock 330 74 440 minecraft:red_concrete
setblock 330 74 447 minecraft:red_concrete
fill 330 74 451 330 75 451 minecraft:red_concrete
fill 330 74 453 330 75 453 minecraft:red_concrete
fill 330 74 455 330 75 455 minecraft:red_concrete
fill 330 74 457 330 75 457 minecraft:red_concrete
fill 331 74 452 331 75 452 minecraft:red_concrete
fill 331 74 454 331 75 454 minecraft:red_concrete
fill 331 74 456 331 75 456 minecraft:red_concrete
fill 332 74 451 332 75 451 minecraft:red_concrete
fill 332 74 453 332 75 453 minecraft:red_concrete
fill 332 74 455 332 75 455 minecraft:red_concrete
fill 332 74 457 332 75 457 minecraft:red_concrete
fill 333 74 452 333 75 452 minecraft:red_concrete
fill 333 74 454 333 75 454 minecraft:red_concrete
fill 333 74 456 333 75 456 minecraft:red_concrete
fill 334 74 451 334 75 451 minecraft:red_concrete
fill 334 74 453 334 75 453 minecraft:red_concrete
fill 334 74 455 334 75 455 minecraft:red_concrete
fill 334 74 457 334 75 457 minecraft:red_concrete
setblock 335 74 417 minecraft:red_concrete
fill 335 74 452 335 75 452 minecraft:red_concrete
fill 335 74 454 335 75 454 minecraft:red_concrete
fill 335 74 456 335 75 456 minecraft:red_concrete
setblock 341 74 457 minecraft:red_concrete
setblock 342 74 417 minecraft:red_concrete
setblock 348 74 457 minecraft:red_concrete
setblock 349 74 417 minecraft:red_concrete
setblock 355 74 457 minecraft:red_concrete
setblock 356 74 417 minecraft:red_concrete
setblock 362 74 457 minecraft:red_concrete
setblock 363 74 417 minecraft:red_concrete
setblock 369 74 457 minecraft:red_concrete
setblock 370 74 417 minecraft:red_concrete
setblock 370 74 424 minecraft:red_concrete
setblock 370 74 431 minecraft:red_concrete
setblock 370 74 438 minecraft:red_concrete
setblock 370 74 445 minecraft:red_concrete
setblock 370 74 452 minecraft:red_concrete
setblock 330 75 420 minecraft:red_concrete
setblock 330 75 427 minecraft:red_concrete
setblock 330 75 434 minecraft:red_concrete
setblock 330 75 441 minecraft:red_concrete
setblock 330 75 448 minecraft:red_concrete
setblock 334 75 417 minecraft:red_concrete
setblock 341 75 417 minecraft:red_concrete
setblock 342 75 457 minecraft:red_concrete
setblock 348 75 417 minecraft:red_concrete
setblock 349 75 457 minecraft:red_concrete
setblock 355 75 417 minecraft:red_concrete
setblock 356 75 457 minecraft:red_concrete
setblock 362 75 417 minecraft:red_concrete
setblock 363 75 457 minecraft:red_concrete
setblock 369 75 417 minecraft:red_concrete
setblock 370 75 423 minecraft:red_concrete
setblock 370 75 430 minecraft:red_concrete
setblock 370 75 437 minecraft:red_concrete
setblock 370 75 444 minecraft:red_concrete
setblock 370 75 451 minecraft:red_concrete
setblock 370 75 457 minecraft:red_concrete
setblock 329 76 452 minecraft:jack_o_lantern
setblock 329 76 454 minecraft:jack_o_lantern
setblock 329 76 456 minecraft:jack_o_lantern
setblock 330 76 421 minecraft:red_concrete
setblock 330 76 428 minecraft:red_concrete
setblock 330 76 435 minecraft:red_concrete
setblock 330 76 442 minecraft:red_concrete
setblock 330 76 449 minecraft:red_concrete
setblock 330 76 451 minecraft:jack_o_lantern
setblock 330 76 453 minecraft:jack_o_lantern
setblock 330 76 455 minecraft:jack_o_lantern
setblock 330 76 457 minecraft:jack_o_lantern
setblock 331 76 452 minecraft:jack_o_lantern
setblock 331 76 454 minecraft:jack_o_lantern
setblock 331 76 456 minecraft:jack_o_lantern
setblock 332 76 451 minecraft:jack_o_lantern
setblock 332 76 453 minecraft:jack_o_lantern
setblock 332 76 455 minecraft:jack_o_lantern
setblock 332 76 457 minecraft:jack_o_lantern
setblock 333 76 417 minecraft:red_concrete
setblock 333 76 452 minecraft:jack_o_lantern
setblock 333 76 454 minecraft:jack_o_lantern
setblock 333 76 456 minecraft:jack_o_lantern
setblock 334 76 451 minecraft:jack_o_lantern
setblock 334 76 453 minecraft:jack_o_lantern
setblock 334 76 455 minecraft:jack_o_lantern
setblock 334 76 457 minecraft:jack_o_lantern
setblock 335 76 452 minecraft:jack_o_lantern
setblock 335 76 454 minecraft:jack_o_lantern
setblock 335 76 456 minecraft:jack_o_lantern
setblock 336 76 457 minecraft:red_concrete
setblock 340 76 417 minecraft:red_concrete
setblock 343 76 457 minecraft:red_concrete
setblock 347 76 417 minecraft:red_concrete
setblock 350 76 457 minecraft:red_concrete
setblock 354 76 417 minecraft:red_concrete
setblock 357 76 457 minecraft:red_concrete
setblock 361 76 417 minecraft:red_concrete
setblock 364 76 457 minecraft:red_concrete
setblock 368 76 417 minecraft:red_concrete
setblock 370 76 422 minecraft:red_concrete
setblock 370 76 429 minecraft:red_concrete
setblock 370 76 436 minecraft:red_concrete
setblock 370 76 443 minecraft:red_concrete
setblock 370 76 450 minecraft:red_concrete
fill 329 77 452 329 78 452 minecraft:black_concrete
fill 329 77 454 329 78 454 minecraft:black_concrete
fill 329 77 456 329 78 456 minecraft:black_concrete
fill 330 77 451 330 78 451 minecraft:red_concrete
fill 330 77 453 330 78 453 minecraft:red_concrete
fill 330 77 455 330 78 455 minecraft:red_concrete
fill 330 77 457 330 78 457 minecraft:red_concrete
fill 331 77 452 331 78 452 minecraft:red_concrete
fill 331 77 454 331 78 454 minecraft:red_concrete
fill 331 77 456 331 78 456 minecraft:red_concrete
fill 332 77 451 332 78 451 minecraft:red_concrete
fill 332 77 453 332 78 453 minecraft:red_concrete
fill 332 77 455 332 78 455 minecraft:red_concrete
fill 332 77 457 332 78 457 minecraft:red_concrete
fill 333 77 452 333 78 452 minecraft:red_concrete
fill 333 77 454 333 78 454 minecraft:red_concrete
fill 333 77 456 333 78 456 minecraft:red_concrete
fill 334 77 451 334 78 451 minecraft:red_concrete
fill 334 77 453 334 78 453 minecraft:red_concrete
fill 334 77 455 334 78 455 minecraft:red_concrete
fill 334 77 457 334 78 457 minecraft:red_concrete
fill 335 77 452 335 78 452 minecraft:red_concrete
fill 335 77 454 335 78 454 minecraft:red_concrete
fill 335 77 456 335 78 456 minecraft:red_concrete
setblock 330 78 423 minecraft:red_concrete
setblock 330 78 430 minecraft:red_concrete
setblock 330 78 437 minecraft:red_concrete
setblock 330 78 444 minecraft:red_concrete
setblock 331 78 417 minecraft:red_concrete
setblock 338 78 417 minecraft:red_concrete
setblock 338 78 457 minecraft:red_concrete
setblock 345 78 417 minecraft:red_concrete
setblock 345 78 457 minecraft:red_concrete
setblock 352 78 417 minecraft:red_concrete
setblock 352 78 457 minecraft:red_concrete
setblock 359 78 417 minecraft:red_concrete
setblock 359 78 457 minecraft:red_concrete
setblock 366 78 417 minecraft:red_concrete
setblock 366 78 457 minecraft:red_concrete
setblock 370 78 420 minecraft:red_concrete
setblock 370 78 427 minecraft:red_concrete
setblock 370 78 434 minecraft:red_concrete
setblock 370 78 441 minecraft:red_concrete
setblock 370 78 448 minecraft:red_concrete
setblock 370 78 455 minecraft:red_concrete
setblock 329 79 452 minecraft:jack_o_lantern
setblock 329 79 454 minecraft:jack_o_lantern
setblock 329 79 456 minecraft:jack_o_lantern
fill 330 79 417 330 80 417 minecraft:red_concrete
fill 330 79 424 330 80 424 minecraft:red_concrete
fill 330 79 431 330 80 431 minecraft:red_concrete
fill 330 79 438 330 80 438 minecraft:red_concrete
fill 330 79 445 330 80 445 minecraft:red_concrete
setblock 330 79 451 minecraft:jack_o_lantern
setblock 330 79 453 minecraft:jack_o_lantern
setblock 330 79 455 minecraft:jack_o_lantern
setblock 330 79 457 minecraft:jack_o_lantern
setblock 331 79 452 minecraft:jack_o_lantern
setblock 331 79 454 minecraft:jack_o_lantern
setblock 331 79 456 minecraft:jack_o_lantern
setblock 332 79 451 minecraft:jack_o_lantern
setblock 332 79 453 minecraft:jack_o_lantern
setblock 332 79 455 minecraft:jack_o_lantern
setblock 332 79 457 minecraft:jack_o_lantern
setblock 333 79 452 minecraft:jack_o_lantern
setblock 333 79 454 minecraft:jack_o_lantern
setblock 333 79 456 minecraft:jack_o_lantern
setblock 334 79 451 minecraft:jack_o_lantern
setblock 334 79 453 minecraft:jack_o_lantern
setblock 334 79 455 minecraft:jack_o_lantern
setblock 334 79 457 minecraft:jack_o_lantern
setblock 335 79 452 minecraft:jack_o_lantern
setblock 335 79 454 minecraft:jack_o_lantern
setblock 335 79 456 minecraft:jack_o_lantern
fill 337 79 417 337 80 417 minecraft:red_concrete
fill 339 79 457 339 80 457 minecraft:red_concrete
fill 344 79 417 344 80 417 minecraft:red_concrete
fill 346 79 457 346 80 457 minecraft:red_concrete
fill 351 79 417 351 80 417 minecraft:red_concrete
fill 353 79 457 353 80 457 minecraft:red_concrete
fill 358 79 417 358 80 417 minecraft:red_concrete
fill 360 79 457 360 80 457 minecraft:red_concrete
fill 365 79 417 365 80 417 minecraft:red_concrete
fill 367 79 457 367 80 457 minecraft:red_concrete
fill 370 79 419 370 80 419 minecraft:red_concrete
fill 370 79 426 370 80 426 minecraft:red_concrete
fill 370 79 433 370 80 433 minecraft:red_concrete
fill 370 79 440 370 80 440 minecraft:red_concrete
fill 370 79 447 370 80 447 minecraft:red_concrete
fill 370 79 454 370 80 454 minecraft:red_concrete
fill 329 80 452 329 81 452 minecraft:black_concrete
fill 329 80 454 329 81 454 minecraft:black_concrete
fill 329 80 456 329 81 456 minecraft:black_concrete
fill 330 80 418 330 80 421 minecraft:red_concrete
setblock 330 80 423 minecraft:red_concrete
fill 330 80 425 330 80 428 minecraft:red_concrete
setblock 330 80 430 minecraft:red_concrete
fill 330 80 432 330 80 435 minecraft:red_concrete
setblock 330 80 437 minecraft:red_concrete
fill 330 80 439 330 80 442 minecraft:red_concrete
setblock 330 80 444 minecraft:red_concrete
fill 330 80 446 330 80 449 minecraft:red_concrete
fill 330 80 451 330 81 451 minecraft:red_concrete
fill 330 80 453 330 81 453 minecraft:red_concrete
fill 330 80 455 330 81 455 minecraft:red_concrete
fill 330 80 457 330 81 457 minecraft:red_concrete
setblock 331 80 417 minecraft:red_concrete
fill 331 80 452 331 81 452 minecraft:red_concrete
fill 331 80 454 331 81 454 minecraft:red_concrete
fill 331 80 456 331 81 456 minecraft:red_concrete
setblock 332 80 419 minecraft:light[level=12]
setblock 332 80 427 minecraft:light[level=12]
setblock 332 80 435 minecraft:light[level=12]
setblock 332 80 443 minecraft:light[level=12]
fill 332 80 451 332 81 451 minecraft:red_concrete
fill 332 80 453 332 81 453 minecraft:red_concrete
fill 332 80 455 332 81 455 minecraft:red_concrete
fill 332 80 457 332 81 457 minecraft:red_concrete
fill 333 80 417 336 80 417 minecraft:red_concrete
fill 333 80 452 333 81 452 minecraft:red_concrete
fill 333 80 454 333 81 454 minecraft:red_concrete
fill 333 80 456 333 81 456 minecraft:red_concrete
fill 334 80 451 334 81 451 minecraft:red_concrete
fill 334 80 453 334 81 453 minecraft:red_concrete
fill 334 80 455 334 81 455 minecraft:red_concrete
fill 334 80 457 334 81 457 minecraft:red_concrete
fill 335 80 452 335 81 452 minecraft:red_concrete
fill 335 80 454 335 81 454 minecraft:red_concrete
fill 335 80 456 335 81 456 minecraft:red_concrete
setblock 336 80 457 minecraft:red_concrete
setblock 338 80 417 minecraft:red_concrete
setblock 338 80 457 minecraft:red_concrete
fill 340 80 417 343 80 417 minecraft:red_concrete
setblock 340 80 419 minecraft:light[level=12]
setblock 340 80 427 minecraft:light[level=12]
setblock 340 80 435 minecraft:light[level=12]
setblock 340 80 443 minecraft:light[level=12]
setblock 340 80 451 minecraft:light[level=12]
fill 340 80 457 343 80 457 minecraft:red_concrete
setblock 345 80 417 minecraft:red_concrete
setblock 345 80 457 minecraft:red_concrete
fill 347 80 417 350 80 417 minecraft:red_concrete
fill 347 80 457 350 80 457 minecraft:red_concrete
setblock 348 80 419 minecraft:light[level=12]
setblock 348 80 427 minecraft:light[level=12]
setblock 348 80 435 minecraft:light[level=12]
setblock 348 80 443 minecraft:light[level=12]
setblock 348 80 451 minecraft:light[level=12]
setblock 352 80 417 minecraft:red_concrete
setblock 352 80 457 minecraft:red_concrete
fill 354 80 417 357 80 417 minecraft:red_concrete
fill 354 80 457 357 80 457 minecraft:red_concrete
setblock 356 80 419 minecraft:light[level=12]
setblock 356 80 427 minecraft:light[level=12]
setblock 356 80 435 minecraft:light[level=12]
setblock 356 80 443 minecraft:light[level=12]
setblock 356 80 451 minecraft:light[level=12]
setblock 359 80 417 minecraft:red_concrete
setblock 359 80 457 minecraft:red_concrete
fill 361 80 417 364 80 417 minecraft:red_concrete
fill 361 80 457 364 80 457 minecraft:red_concrete
setblock 364 80 419 minecraft:light[level=12]
setblock 364 80 427 minecraft:light[level=12]
setblock 364 80 435 minecraft:light[level=12]
setblock 364 80 443 minecraft:light[level=12]
setblock 364 80 451 minecraft:light[level=12]
setblock 366 80 417 minecraft:red_concrete
setblock 366 80 457 minecraft:red_concrete
fill 368 80 417 370 80 417 minecraft:red_concrete
fill 368 80 457 370 80 457 minecraft:red_concrete
setblock 370 80 418 minecraft:red_concrete
setblock 370 80 420 minecraft:red_concrete
fill 370 80 422 370 80 425 minecraft:red_concrete
setblock 370 80 427 minecraft:red_concrete
fill 370 80 429 370 80 432 minecraft:red_concrete
setblock 370 80 434 minecraft:red_concrete
fill 370 80 436 370 80 439 minecraft:red_concrete
setblock 370 80 441 minecraft:red_concrete
fill 370 80 443 370 80 446 minecraft:red_concrete
setblock 370 80 448 minecraft:red_concrete
fill 370 80 450 370 80 453 minecraft:red_concrete
setblock 370 80 455 minecraft:red_concrete
setblock 330 81 419 minecraft:red_concrete
setblock 330 81 426 minecraft:red_concrete
setblock 330 81 433 minecraft:red_concrete
setblock 330 81 440 minecraft:red_concrete
setblock 330 81 447 minecraft:red_concrete
setblock 335 81 417 minecraft:red_concrete
setblock 341 81 457 minecraft:red_concrete
setblock 342 81 417 minecraft:red_concrete
setblock 348 81 457 minecraft:red_concrete
setblock 349 81 417 minecraft:red_concrete
setblock 355 81 457 minecraft:red_concrete
setblock 356 81 417 minecraft:red_concrete
setblock 362 81 457 minecraft:red_concrete
setblock 363 81 417 minecraft:red_concrete
setblock 369 81 457 minecraft:red_concrete
setblock 370 81 417 minecraft:red_concrete
setblock 370 81 424 minecraft:red_concrete
setblock 370 81 431 minecraft:red_concrete
setblock 370 81 438 minecraft:red_concrete
setblock 370 81 445 minecraft:red_concrete
setblock 370 81 452 minecraft:red_concrete
fill 329 82 416 329 85 417 minecraft:black_concrete
setblock 329 82 418 minecraft:purple_terracotta
fill 329 82 419 329 82 423 minecraft:black_concrete
setblock 329 82 424 minecraft:purple_terracotta
fill 329 82 425 329 83 440 minecraft:black_concrete
setblock 329 82 441 minecraft:purple_terracotta
fill 329 82 442 329 85 442 minecraft:black_concrete
setblock 329 82 443 minecraft:purple_terracotta
fill 329 82 444 329 83 445 minecraft:black_concrete
setblock 329 82 446 minecraft:purple_terracotta
fill 329 82 447 329 83 451 minecraft:black_concrete
setblock 329 82 452 minecraft:jack_o_lantern
setblock 329 82 454 minecraft:jack_o_lantern
setblock 329 82 456 minecraft:jack_o_lantern
fill 329 82 457 329 85 457 minecraft:black_concrete
setblock 329 82 458 minecraft:purple_terracotta
fill 330 82 416 337 85 416 minecraft:black_concrete
setblock 330 82 420 minecraft:red_concrete
setblock 330 82 427 minecraft:red_concrete
setblock 330 82 434 minecraft:red_concrete
setblock 330 82 441 minecraft:red_concrete
setblock 330 82 448 minecraft:red_concrete
setblock 330 82 451 minecraft:jack_o_lantern
setblock 330 82 453 minecraft:jack_o_lantern
setblock 330 82 455 minecraft:jack_o_lantern
setblock 330 82 457 minecraft:jack_o_lantern
fill 330 82 458 330 85 458 minecraft:black_concrete
setblock 331 82 452 minecraft:jack_o_lantern
setblock 331 82 454 minecraft:jack_o_lantern
setblock 331 82 456 minecraft:jack_o_lantern
setblock 331 82 458 minecraft:purple_terracotta
setblock 332 82 451 minecraft:jack_o_lantern
setblock 332 82 453 minecraft:jack_o_lantern
setblock 332 82 455 minecraft:jack_o_lantern
setblock 332 82 457 minecraft:jack_o_lantern
fill 332 82 458 340 82 458 minecraft:black_concrete
setblock 333 82 452 minecraft:jack_o_lantern
setblock 333 82 454 minecraft:jack_o_lantern
setblock 333 82 456 minecraft:jack_o_lantern
setblock 334 82 417 minecraft:red_concrete
setblock 334 82 451 minecraft:jack_o_lantern
setblock 334 82 453 minecraft:jack_o_lantern
setblock 334 82 455 minecraft:jack_o_lantern
setblock 334 82 457 minecraft:jack_o_lantern
setblock 335 82 452 minecraft:jack_o_lantern
setblock 335 82 454 minecraft:jack_o_lantern
setblock 335 82 456 minecraft:jack_o_lantern
setblock 338 82 416 minecraft:purple_terracotta
fill 339 82 416 347 82 416 minecraft:black_concrete
setblock 341 82 417 minecraft:red_concrete
setblock 341 82 458 minecraft:purple_terracotta
setblock 342 82 457 minecraft:red_concrete
fill 342 82 458 349 85 458 minecraft:black_concrete
setblock 348 82 416 minecraft:purple_terracotta
setblock 348 82 417 minecraft:red_concrete
fill 349 82 416 370 82 416 minecraft:black_concrete
setblock 349 82 457 minecraft:red_concrete
fill 350 82 458 351 82 458 minecraft:purple_terracotta
fill 352 82 458 355 85 458 minecraft:black_concrete
setblock 355 82 417 minecraft:red_concrete
setblock 356 82 457 minecraft:red_concrete
fill 356 82 458 357 82 458 minecraft:purple_terracotta
fill 358 82 458 365 83 458 minecraft:black_concrete
setblock 362 82 417 minecraft:red_concrete
setblock 363 82 457 minecraft:red_concrete
fill 366 82 458 366 84 458 minecraft:purple_terracotta
fill 367 82 458 371 82 458 minecraft:black_concrete
setblock 369 82 417 minecraft:red_concrete
setblock 370 82 423 minecraft:red_concrete
setblock 370 82 430 minecraft:red_concrete
setblock 370 82 437 minecraft:red_concrete
setblock 370 82 444 minecraft:red_concrete
setblock 370 82 451 minecraft:red_concrete
setblock 370 82 457 minecraft:red_concrete
fill 371 82 416 371 83 416 minecraft:purple_terracotta
fill 371 82 417 371 83 417 minecraft:black_concrete
setblock 371 82 418 minecraft:purple_terracotta
fill 371 82 419 371 82 425 minecraft:black_concrete
setblock 371 82 426 minecraft:purple_terracotta
fill 371 82 427 371 83 433 minecraft:black_concrete
fill 371 82 434 371 83 434 minecraft:purple_terracotta
fill 371 82 435 371 85 442 minecraft:black_concrete
setblock 371 82 443 minecraft:purple_terracotta
fill 371 82 444 371 82 449 minecraft:black_concrete
setblock 371 82 450 minecraft:purple_terracotta
fill 371 82 451 371 82 454 minecraft:black_concrete
setblock 371 82 455 minecraft:purple_terracotta
fill 371 82 456 371 82 457 minecraft:black_concrete
fill 329 83 418 329 85 420 minecraft:black_concrete
setblock 329 83 421 minecraft:purple_terracotta
fill 329 83 422 329 85 424 minecraft:black_concrete
fill 329 83 441 329 85 441 minecraft:black_concrete
fill 329 83 443 329 85 443 minecraft:black_concrete
fill 329 83 446 329 85 446 minecraft:black_concrete
fill 329 83 452 329 85 452 minecraft:black_concrete
setblock 329 83 453 minecraft:purple_terracotta
fill 329 83 454 329 85 454 minecraft:black_concrete
setblock 329 83 456 minecraft:purple_terracotta
fill 329 83 458 329 85 458 minecraft:black_concrete
setblock 330 83 421 minecraft:red_concrete
setblock 330 83 428 minecraft:red_concrete
setblock 330 83 435 minecraft:red_concrete
setblock 330 83 442 minecraft:red_concrete
setblock 330 83 449 minecraft:red_concrete
setblock 330 83 451 minecraft:red_concrete
setblock 330 83 453 minecraft:red_concrete
setblock 330 83 455 minecraft:red_concrete
fill 330 83 457 330 165 457 minecraft:red_concrete
setblock 331 83 452 minecraft:red_concrete
setblock 331 83 454 minecraft:red_concrete
setblock 331 83 456 minecraft:red_concrete
fill 331 83 458 338 83 458 minecraft:black_concrete
setblock 332 83 451 minecraft:red_concrete
setblock 332 83 453 minecraft:red_concrete
setblock 332 83 455 minecraft:red_concrete
setblock 332 83 457 minecraft:red_concrete
setblock 333 83 417 minecraft:red_concrete
setblock 333 83 452 minecraft:red_concrete
setblock 333 83 454 minecraft:red_concrete
setblock 333 83 456 minecraft:red_concrete
setblock 334 83 451 minecraft:red_concrete
setblock 334 83 453 minecraft:red_concrete
setblock 334 83 455 minecraft:red_concrete
setblock 334 83 457 minecraft:red_concrete
setblock 335 83 452 minecraft:red_concrete
setblock 335 83 454 minecraft:red_concrete
setblock 335 83 456 minecraft:red_concrete
setblock 336 83 457 minecraft:red_concrete
fill 338 83 416 344 85 416 minecraft:black_concrete
setblock 339 83 458 minecraft:purple_terracotta
setblock 340 83 417 minecraft:red_concrete
fill 340 83 458 341 85 458 minecraft:black_concrete
setblock 343 83 457 minecraft:red_concrete
setblock 345 83 416 minecraft:purple_terracotta
fill 346 83 416 362 83 416 minecraft:black_concrete
setblock 347 83 417 minecraft:red_concrete
setblock 350 83 457 minecraft:red_concrete
fill 350 83 458 351 85 458 minecraft:black_concrete
setblock 354 83 417 minecraft:red_concrete
fill 356 83 458 356 85 458 minecraft:black_concrete
setblock 357 83 457 minecraft:red_concrete
setblock 357 83 458 minecraft:purple_terracotta
setblock 361 83 417 minecraft:red_concrete
setblock 363 83 416 minecraft:purple_terracotta
fill 364 83 416 365 85 416 minecraft:black_concrete
setblock 364 83 457 minecraft:red_concrete
setblock 366 83 416 minecraft:purple_terracotta
fill 367 83 416 370 83 416 minecraft:black_concrete
setblock 367 83 458 minecraft:purple_terracotta
setblock 368 83 417 minecraft:red_concrete
fill 368 83 458 371 85 458 minecraft:black_concrete
setblock 370 83 422 minecraft:red_concrete
setblock 370 83 429 minecraft:red_concrete
setblock 370 83 436 minecraft:red_concrete
setblock 370 83 443 minecraft:red_concrete
setblock 370 83 450 minecraft:red_concrete
fill 371 83 418 371 85 422 minecraft:black_concrete
setblock 371 83 423 minecraft:purple_terracotta
fill 371 83 424 371 85 426 minecraft:black_concrete
fill 371 83 443 371 85 445 minecraft:black_concrete
setblock 371 83 446 minecraft:purple_terracotta
fill 371 83 447 371 85 447 minecraft:black_concrete
fill 371 83 448 371 84 448 minecraft:purple_terracotta
fill 371 83 449 371 85 450 minecraft:black_concrete
setblock 371 83 451 minecraft:purple_terracotta
fill 371 83 452 371 85 455 minecraft:black_concrete
setblock 371 83 456 minecraft:purple_terracotta
fill 371 83 457 371 86 457 minecraft:black_concrete
fill 329 84 421 329 85 421 minecraft:black_concrete
fill 329 84 425 329 85 436 minecraft:black_concrete
setblock 329 84 437 minecraft:purple_terracotta
fill 329 84 438 329 85 440 minecraft:black_concrete
setblock 329 84 444 minecraft:purple_terracotta
fill 329 84 445 329 85 445 minecraft:black_concrete
fill 329 84 447 329 85 447 minecraft:black_concrete
setblock 329 84 448 minecraft:purple_terracotta
fill 329 84 449 329 85 451 minecraft:black_concrete
fill 329 84 453 329 85 453 minecraft:black_concrete
setblock 329 84 455 minecraft:purple_terracotta
fill 329 84 456 329 85 456 minecraft:black_concrete
fill 330 84 452 334 84 456 minecraft:white_concrete
fill 331 84 458 333 85 458 minecraft:black_concrete
setblock 334 84 458 minecraft:purple_terracotta
fill 335 84 458 339 85 458 minecraft:black_concrete
fill 345 84 416 357 85 416 minecraft:black_concrete
fill 357 84 458 359 85 458 minecraft:black_concrete
setblock 358 84 416 minecraft:purple_terracotta
fill 359 84 416 363 85 416 minecraft:black_concrete
setblock 360 84 458 minecraft:purple_terracotta
fill 361 84 458 361 85 458 minecraft:black_concrete
setblock 362 84 458 minecraft:purple_terracotta
fill 363 84 458 365 85 458 minecraft:black_concrete
fill 366 84 416 367 85 416 minecraft:black_concrete
fill 367 84 458 367 85 458 minecraft:black_concrete
setblock 368 84 416 minecraft:purple_terracotta
fill 369 84 416 371 85 416 minecraft:black_concrete
setblock 371 84 417 minecraft:purple_terracotta
fill 371 84 423 371 86 423 minecraft:black_concrete
fill 371 84 427 371 85 429 minecraft:black_concrete
setblock 371 84 430 minecraft:purple_terracotta
fill 371 84 431 371 85 434 minecraft:black_concrete
fill 371 84 446 371 85 446 minecraft:black_concrete
fill 371 84 451 371 85 451 minecraft:black_concrete
fill 371 84 456 371 85 456 minecraft:black_concrete
setblock 329 85 437 minecraft:black_concrete
setblock 329 85 444 minecraft:black_concrete
setblock 329 85 448 minecraft:black_concrete
setblock 329 85 455 minecraft:black_concrete
setblock 330 85 423 minecraft:red_concrete
setblock 330 85 430 minecraft:red_concrete
setblock 330 85 437 minecraft:red_concrete
setblock 330 85 444 minecraft:red_concrete
setblock 330 85 451 minecraft:red_concrete
setblock 331 85 417 minecraft:red_concrete
fill 331 85 453 333 85 455 minecraft:white_concrete
setblock 331 85 457 minecraft:red_concrete
setblock 334 85 458 minecraft:black_concrete
setblock 338 85 417 minecraft:red_concrete
setblock 338 85 457 minecraft:red_concrete
setblock 345 85 417 minecraft:red_concrete
setblock 345 85 457 minecraft:red_concrete
setblock 352 85 417 minecraft:red_concrete
setblock 352 85 457 minecraft:red_concrete
setblock 358 85 416 minecraft:black_concrete
setblock 359 85 417 minecraft:red_concrete
setblock 359 85 457 minecraft:red_concrete
setblock 360 85 458 minecraft:black_concrete
setblock 362 85 458 minecraft:black_concrete
setblock 366 85 417 minecraft:red_concrete
setblock 366 85 457 minecraft:red_concrete
setblock 366 85 458 minecraft:black_concrete
setblock 368 85 416 minecraft:black_concrete
setblock 370 85 420 minecraft:red_concrete
setblock 370 85 427 minecraft:red_concrete
setblock 370 85 434 minecraft:red_concrete
setblock 370 85 441 minecraft:red_concrete
setblock 370 85 448 minecraft:red_concrete
setblock 370 85 455 minecraft:red_concrete
setblock 371 85 417 minecraft:black_concrete
setblock 371 85 430 minecraft:black_concrete
setblock 371 85 448 minecraft:black_concrete
fill 329 86 416 329 86 437 minecraft:purple_terracotta
setblock 329 86 438 minecraft:black_concrete
fill 329 86 439 329 86 449 minecraft:purple_terracotta
setblock 329 86 450 minecraft:black_concrete
fill 329 86 451 329 86 458 minecraft:purple_terracotta
fill 330 86 416 362 86 416 minecraft:purple_terracotta
setblock 330 86 417 minecraft:red_concrete
setblock 330 86 424 minecraft:red_concrete
setblock 330 86 431 minecraft:red_concrete
setblock 330 86 438 minecraft:red_concrete
setblock 330 86 445 minecraft:red_concrete
setblock 330 86 452 minecraft:red_concrete
fill 330 86 458 353 86 458 minecraft:purple_terracotta
fill 332 86 454 332 87 454 minecraft:white_concrete
setblock 332 86 457 minecraft:red_concrete
setblock 337 86 417 minecraft:red_concrete
setblock 339 86 457 minecraft:red_concrete
setblock 344 86 417 minecraft:red_concrete
setblock 346 86 457 minecraft:red_concrete
setblock 351 86 417 minecraft:red_concrete
setblock 353 86 457 minecraft:red_concrete
setblock 354 86 458 minecraft:black_concrete
fill 355 86 458 368 86 458 minecraft:purple_terracotta
setblock 358 86 417 minecraft:red_concrete
setblock 360 86 457 minecraft:red_concrete
setblock 363 86 416 minecraft:black_concrete
fill 364 86 416 371 86 416 minecraft:purple_terracotta
setblock 365 86 417 minecraft:red_concrete
setblock 367 86 457 minecraft:red_concrete
setblock 369 86 458 minecraft:black_concrete
setblock 370 86 419 minecraft:red_concrete
setblock 370 86 426 minecraft:red_concrete
setblock 370 86 433 minecraft:red_concrete
setblock 370 86 440 minecraft:red_concrete
setblock 370 86 447 minecraft:red_concrete
setblock 370 86 454 minecraft:red_concrete
fill 370 86 458 371 193 458 minecraft:purple_terracotta
fill 371 86 417 371 87 421 minecraft:purple_terracotta
setblock 371 86 422 minecraft:black_concrete
fill 371 86 424 371 87 427 minecraft:purple_terracotta
setblock 371 86 428 minecraft:black_concrete
fill 371 86 429 371 86 438 minecraft:purple_terracotta
fill 371 86 439 371 87 439 minecraft:black_concrete
fill 371 86 440 371 87 441 minecraft:purple_terracotta
setblock 371 86 442 minecraft:black_concrete
fill 371 86 443 371 193 444 minecraft:purple_terracotta
setblock 371 86 445 minecraft:black_concrete
fill 371 86 446 371 86 451 minecraft:purple_terracotta
fill 371 86 452 371 86 453 minecraft:black_concrete
fill 371 86 454 371 87 456 minecraft:purple_terracotta
setblock 329 87 416 minecraft:black_concrete
fill 329 87 417 329 87 419 minecraft:purple_terracotta
setblock 329 87 420 minecraft:black_concrete
fill 329 87 421 329 87 424 minecraft:purple_terracotta
setblock 329 87 425 minecraft:black_concrete
fill 329 87 426 329 196 427 minecraft:purple_terracotta
setblock 329 87 428 minecraft:black_concrete
fill 329 87 429 329 87 441 minecraft:purple_terracotta
setblock 329 87 442 minecraft:black_concrete
fill 329 87 443 329 196 443 minecraft:purple_terracotta
setblock 329 87 444 minecraft:black_concrete
fill 329 87 445 329 192 450 minecraft:purple_terracotta
setblock 329 87 451 minecraft:black_concrete
fill 329 87 452 329 87 458 minecraft:purple_terracotta
fill 330 87 416 330 196 416 minecraft:purple_terracotta
setblock 330 87 418 minecraft:red_concrete
setblock 330 87 425 minecraft:red_concrete
setblock 330 87 432 minecraft:red_concrete
setblock 330 87 439 minecraft:red_concrete
setblock 330 87 446 minecraft:red_concrete
setblock 330 87 453 minecraft:red_concrete
fill 330 87 458 332 87 458 minecraft:purple_terracotta
setblock 331 87 416 minecraft:black_concrete
fill 331 87 453 331 87 455 minecraft:white_concrete
fill 332 87 416 344 192 416 minecraft:purple_terracotta
fill 332 87 453 333 87 453 minecraft:white_concrete
fill 332 87 455 333 87 455 minecraft:white_concrete
setblock 333 87 454 minecraft:white_concrete
setblock 333 87 457 minecraft:red_concrete
fill 333 87 458 335 87 458 minecraft:black_concrete
setblock 336 87 417 minecraft:red_concrete
fill 336 87 458 349 87 458 minecraft:purple_terracotta
setblock 340 87 457 minecraft:red_concrete
setblock 343 87 417 minecraft:red_concrete
fill 345 87 416 346 87 416 minecraft:black_concrete
fill 347 87 416 365 87 416 minecraft:purple_terracotta
setblock 347 87 457 minecraft:red_concrete
setblock 350 87 417 minecraft:red_concrete
setblock 350 87 458 minecraft:black_concrete
fill 351 87 458 352 192 458 minecraft:purple_terracotta
fill 353 87 458 353 88 458 minecraft:black_concrete
setblock 354 87 457 minecraft:red_concrete
setblock 354 87 458 minecraft:purple_terracotta
setblock 355 87 458 minecraft:black_concrete
fill 356 87 458 357 192 458 minecraft:purple_terracotta
setblock 357 87 417 minecraft:red_concrete
setblock 358 87 458 minecraft:black_concrete
fill 359 87 458 361 196 458 minecraft:purple_terracotta
setblock 361 87 457 minecraft:red_concrete
fill 362 87 458 363 87 458 minecraft:black_concrete
setblock 364 87 417 minecraft:red_concrete
fill 364 87 458 364 193 458 minecraft:purple_terracotta
setblock 365 87 458 minecraft:black_concrete
fill 366 87 416 367 87 416 minecraft:black_concrete
fill 366 87 458 369 87 458 minecraft:purple_terracotta
fill 368 87 416 371 87 416 minecraft:purple_terracotta
setblock 368 87 457 minecraft:red_concrete
setblock 370 87 418 minecraft:red_concrete
setblock 370 87 425 minecraft:red_concrete
setblock 370 87 432 minecraft:red_concrete
setblock 370 87 439 minecraft:red_concrete
setblock 370 87 446 minecraft:red_concrete
setblock 370 87 453 minecraft:red_concrete
fill 371 87 422 371 196 423 minecraft:purple_terracotta
fill 371 87 428 371 192 434 minecraft:purple_terracotta
setblock 371 87 435 minecraft:black_concrete
fill 371 87 436 371 196 438 minecraft:purple_terracotta
setblock 371 87 442 minecraft:purple_terracotta
fill 371 87 445 371 194 449 minecraft:purple_terracotta
setblock 371 87 450 minecraft:black_concrete
fill 371 87 451 371 196 453 minecraft:purple_terracotta
fill 371 87 457 371 192 457 minecraft:purple_terracotta
fill 329 88 416 329 194 416 minecraft:purple_terracotta
setblock 329 88 417 minecraft:black_concrete
fill 329 88 418 329 194 420 minecraft:purple_terracotta
setblock 329 88 421 minecraft:black_concrete
fill 329 88 422 329 196 422 minecraft:purple_terracotta
fill 329 88 423 329 88 424 minecraft:black_concrete
fill 329 88 425 329 196 425 minecraft:purple_terracotta
fill 329 88 428 329 192 428 minecraft:purple_terracotta
setblock 329 88 429 minecraft:black_concrete
fill 329 88 430 329 194 432 minecraft:purple_terracotta
fill 329 88 433 329 88 435 minecraft:black_concrete
fill 329 88 436 329 196 436 minecraft:purple_terracotta
setblock 329 88 437 minecraft:black_concrete
fill 329 88 438 329 193 442 minecraft:purple_terracotta
fill 329 88 444 329 196 444 minecraft:purple_terracotta
fill 329 88 451 329 194 455 minecraft:purple_terracotta
setblock 329 88 456 minecraft:black_concrete
fill 329 88 457 329 196 457 minecraft:purple_terracotta
fill 329 88 458 330 88 458 minecraft:black_concrete
setblock 330 88 419 minecraft:red_concrete
setblock 330 88 426 minecraft:red_concrete
setblock 330 88 433 minecraft:red_concrete
setblock 330 88 440 minecraft:red_concrete
setblock 330 88 447 minecraft:red_concrete
setblock 330 88 454 minecraft:red_concrete
fill 331 88 416 331 196 416 minecraft:purple_terracotta
fill 331 88 458 333 192 458 minecraft:purple_terracotta
setblock 332 88 419 minecraft:light[level=12]
setblock 332 88 427 minecraft:light[level=12]
setblock 332 88 435 minecraft:light[level=12]
setblock 332 88 443 minecraft:light[level=12]
setblock 332 88 451 minecraft:light[level=12]
setblock 334 88 457 minecraft:red_concrete
fill 334 88 458 335 88 458 minecraft:black_concrete
setblock 335 88 417 minecraft:red_concrete
fill 336 88 458 338 192 458 minecraft:purple_terracotta
setblock 339 88 458 minecraft:black_concrete
setblock 340 88 419 minecraft:light[level=12]
setblock 340 88 427 minecraft:light[level=12]
setblock 340 88 435 minecraft:light[level=12]
setblock 340 88 443 minecraft:light[level=12]
setblock 340 88 451 minecraft:light[level=12]
fill 340 88 458 350 193 458 minecraft:purple_terracotta
setblock 341 88 457 minecraft:red_concrete
setblock 342 88 417 minecraft:red_concrete
fill 345 88 416 348 192 416 minecraft:purple_terracotta
setblock 348 88 419 minecraft:light[level=12]
setblock 348 88 427 minecraft:light[level=12]
setblock 348 88 435 minecraft:light[level=12]
setblock 348 88 443 minecraft:light[level=12]
setblock 348 88 451 minecraft:light[level=12]
setblock 348 88 457 minecraft:red_concrete
setblock 349 88 416 minecraft:black_concrete
setblock 349 88 417 minecraft:red_concrete
fill 350 88 416 352 192 416 minecraft:purple_terracotta
setblock 353 88 416 minecraft:black_concrete
fill 354 88 416 366 192 416 minecraft:purple_terracotta
setblock 354 88 458 minecraft:black_concrete
setblock 355 88 457 minecraft:red_concrete
fill 355 88 458 355 196 458 minecraft:purple_terracotta
setblock 356 88 417 minecraft:red_concrete
setblock 356 88 419 minecraft:light[level=12]
setblock 356 88 427 minecraft:light[level=12]
setblock 356 88 435 minecraft:light[level=12]
setblock 356 88 443 minecraft:light[level=12]
setblock 356 88 451 minecraft:light[level=12]
fill 358 88 458 358 192 458 minecraft:purple_terracotta
setblock 362 88 457 minecraft:red_concrete
fill 362 88 458 363 194 458 minecraft:purple_terracotta
setblock 363 88 417 minecraft:red_concrete
setblock 364 88 419 minecraft:light[level=12]
setblock 364 88 427 minecraft:light[level=12]
setblock 364 88 435 minecraft:light[level=12]
setblock 364 88 443 minecraft:light[level=12]
setblock 364 88 451 minecraft:light[level=12]
fill 365 88 458 366 196 458 minecraft:purple_terracotta
setblock 367 88 416 minecraft:black_concrete
setblock 367 88 458 minecraft:black_concrete
fill 368 88 416 370 192 416 minecraft:purple_terracotta
fill 368 88 458 368 193 458 minecraft:purple_terracotta
setblock 369 88 457 minecraft:red_concrete
setblock 369 88 458 minecraft:black_concrete
setblock 370 88 417 minecraft:red_concrete
setblock 370 88 424 minecraft:red_concrete
setblock 370 88 431 minecraft:red_concrete
setblock 370 88 438 minecraft:red_concrete
setblock 370 88 445 minecraft:red_concrete
setblock 370 88 452 minecraft:red_concrete
setblock 371 88 416 minecraft:black_concrete
fill 371 88 417 371 177 418 minecraft:purple_terracotta
setblock 371 88 419 minecraft:black_concrete
fill 371 88 420 371 177 421 minecraft:purple_terracotta
setblock 371 88 424 minecraft:black_concrete
fill 371 88 425 371 196 427 minecraft:purple_terracotta
fill 371 88 435 371 194 435 minecraft:purple_terracotta
fill 371 88 439 371 196 440 minecraft:purple_terracotta
fill 371 88 441 371 88 442 minecraft:black_concrete
fill 371 88 450 371 196 450 minecraft:purple_terracotta
setblock 371 88 454 minecraft:black_concrete
fill 371 88 455 371 196 456 minecraft:purple_terracotta
fill 329 89 417 329 196 417 minecraft:purple_terracotta
fill 329 89 421 329 197 421 minecraft:purple_terracotta
fill 329 89 423 329 196 424 minecraft:purple_terracotta
fill 329 89 429 329 196 429 minecraft:purple_terracotta
fill 329 89 433 329 192 435 minecraft:purple_terracotta
fill 329 89 437 329 194 437 minecraft:purple_terracotta
fill 329 89 456 329 196 456 minecraft:purple_terracotta
fill 329 89 458 330 194 458 minecraft:purple_terracotta
fill 330 89 420 330 90 420 minecraft:red_concrete
fill 330 89 427 330 90 427 minecraft:red_concrete
fill 330 89 434 330 90 434 minecraft:red_concrete
fill 330 89 441 330 90 441 minecraft:red_concrete
fill 330 89 448 330 90 448 minecraft:red_concrete
fill 330 89 455 330 90 455 minecraft:red_concrete
fill 334 89 417 334 90 417 minecraft:red_concrete
fill 334 89 458 335 194 458 minecraft:purple_terracotta
fill 335 89 457 335 90 457 minecraft:red_concrete
fill 339 89 458 339 196 458 minecraft:purple_terracotta
fill 341 89 417 341 90 417 minecraft:red_concrete
fill 342 89 457 342 90 457 minecraft:red_concrete
fill 348 89 417 348 90 417 minecraft:red_concrete
fill 349 89 416 349 196 416 minecraft:purple_terracotta
fill 349 89 457 349 90 457 minecraft:red_concrete
fill 353 89 416 353 193 416 minecraft:purple_terracotta
fill 353 89 458 354 197 458 minecraft:purple_terracotta
fill 355 89 417 355 90 417 minecraft:red_concrete
fill 356 89 457 356 90 457 minecraft:red_concrete
fill 362 89 417 362 90 417 minecraft:red_concrete
fill 363 89 457 363 90 457 minecraft:red_concrete
fill 367 89 416 367 196 416 minecraft:purple_terracotta
fill 367 89 458 367 196 458 minecraft:purple_terracotta
fill 369 89 417 369 90 417 minecraft:red_concrete
fill 369 89 458 369 196 458 minecraft:purple_terracotta
fill 370 89 423 370 90 423 minecraft:red_concrete
fill 370 89 430 370 90 430 minecraft:red_concrete
fill 370 89 437 370 90 437 minecraft:red_concrete
fill 370 89 444 370 90 444 minecraft:red_concrete
fill 370 89 451 370 90 451 minecraft:red_concrete
fill 370 89 457 370 90 457 minecraft:red_concrete
fill 371 89 416 371 194 416 minecraft:purple_terracotta
fill 371 89 419 371 196 419 minecraft:purple_terracotta
fill 371 89 424 371 196 424 minecraft:purple_terracotta
fill 371 89 441 371 193 442 minecraft:purple_terracotta
fill 371 89 454 371 196 454 minecraft:purple_terracotta
fill 330 90 417 330 90 419 minecraft:red_concrete
setblock 330 90 421 minecraft:red_concrete
fill 330 90 423 330 90 426 minecraft:red_concrete
setblock 330 90 428 minecraft:red_concrete
fill 330 90 430 330 90 433 minecraft:red_concrete
setblock 330 90 435 minecraft:red_concrete
fill 330 90 437 330 90 440 minecraft:red_concrete
setblock 330 90 442 minecraft:red_concrete
fill 330 90 444 330 90 447 minecraft:red_concrete
setblock 330 90 449 minecraft:red_concrete
fill 330 90 451 330 90 454 minecraft:red_concrete
setblock 330 90 456 minecraft:red_concrete
setblock 331 90 417 minecraft:red_concrete
fill 331 90 457 334 90 457 minecraft:red_concrete
setblock 333 90 417 minecraft:red_concrete
fill 335 90 417 338 90 417 minecraft:red_concrete
setblock 336 90 457 minecraft:red_concrete
fill 338 90 457 341 90 457 minecraft:red_concrete
setblock 340 90 417 minecraft:red_concrete
fill 342 90 417 345 90 417 minecraft:red_concrete
setblock 343 90 457 minecraft:red_concrete
fill 345 90 457 348 90 457 minecraft:red_concrete
setblock 347 90 417 minecraft:red_concrete
fill 349 90 417 352 90 417 minecraft:red_concrete
setblock 350 90 457 minecraft:red_concrete
fill 352 90 457 355 90 457 minecraft:red_concrete
setblock 354 90 417 minecraft:red_concrete
fill 356 90 417 359 90 417 minecraft:red_concrete
setblock 357 90 457 minecraft:red_concrete
fill 359 90 457 362 90 457 minecraft:red_concrete
setblock 361 90 417 minecraft:red_concrete
fill 363 90 417 366 90 417 minecraft:red_concrete
setblock 364 90 457 minecraft:red_concrete
fill 366 90 457 369 90 457 minecraft:red_concrete
setblock 368 90 417 minecraft:red_concrete
fill 370 90 417 370 90 420 minecraft:red_concrete
setblock 370 90 422 minecraft:red_concrete
fill 370 90 424 370 90 427 minecraft:red_concrete
setblock 370 90 429 minecraft:red_concrete
fill 370 90 431 370 90 434 minecraft:red_concrete
setblock 370 90 436 minecraft:red_concrete
fill 370 90 438 370 90 441 minecraft:red_concrete
setblock 370 90 443 minecraft:red_concrete
fill 370 90 445 370 90 448 minecraft:red_concrete
setblock 370 90 450 minecraft:red_concrete
fill 370 90 452 370 90 455 minecraft:red_concrete
fill 338 91 418 338 104 418 minecraft:red_wool
setblock 330 92 423 minecraft:red_concrete
setblock 330 92 430 minecraft:red_concrete
setblock 330 92 437 minecraft:red_concrete
setblock 330 92 444 minecraft:red_concrete
setblock 330 92 451 minecraft:red_concrete
setblock 331 92 417 minecraft:red_concrete
setblock 331 92 457 minecraft:red_concrete
fill 336 92 418 337 104 418 minecraft:red_wool
setblock 338 92 417 minecraft:red_concrete
setblock 338 92 457 minecraft:red_concrete
fill 339 92 418 340 104 418 minecraft:red_wool
setblock 345 92 417 minecraft:red_concrete
setblock 345 92 457 minecraft:red_concrete
setblock 352 92 417 minecraft:red_concrete
setblock 352 92 457 minecraft:red_concrete
setblock 359 92 417 minecraft:red_concrete
setblock 359 92 457 minecraft:red_concrete
setblock 366 92 417 minecraft:red_concrete
setblock 366 92 457 minecraft:red_concrete
setblock 370 92 420 minecraft:red_concrete
setblock 370 92 427 minecraft:red_concrete
setblock 370 92 434 minecraft:red_concrete
setblock 370 92 441 minecraft:red_concrete
setblock 370 92 448 minecraft:red_concrete
setblock 370 92 455 minecraft:red_concrete
setblock 330 93 417 minecraft:red_concrete
setblock 330 93 424 minecraft:red_concrete
setblock 330 93 431 minecraft:red_concrete
setblock 330 93 438 minecraft:red_concrete
setblock 330 93 445 minecraft:red_concrete
setblock 330 93 452 minecraft:red_concrete
setblock 332 93 457 minecraft:red_concrete
setblock 337 93 417 minecraft:red_concrete
setblock 339 93 457 minecraft:red_concrete
setblock 344 93 417 minecraft:red_concrete
setblock 346 93 457 minecraft:red_concrete
setblock 351 93 417 minecraft:red_concrete
setblock 353 93 457 minecraft:red_concrete
setblock 358 93 417 minecraft:red_concrete
setblock 360 93 457 minecraft:red_concrete
setblock 365 93 417 minecraft:red_concrete
setblock 367 93 457 minecraft:red_concrete
setblock 370 93 419 minecraft:red_concrete
setblock 370 93 426 minecraft:red_concrete
setblock 370 93 433 minecraft:red_concrete
setblock 370 93 440 minecraft:red_concrete
setblock 370 93 447 minecraft:red_concrete
setblock 370 93 454 minecraft:red_concrete
setblock 330 94 418 minecraft:red_concrete
setblock 330 94 425 minecraft:red_concrete
setblock 330 94 432 minecraft:red_concrete
setblock 330 94 439 minecraft:red_concrete
setblock 330 94 446 minecraft:red_concrete
setblock 330 94 453 minecraft:red_concrete
setblock 333 94 457 minecraft:red_concrete
setblock 336 94 417 minecraft:red_concrete
setblock 340 94 457 minecraft:red_concrete
setblock 343 94 417 minecraft:red_concrete
setblock 347 94 457 minecraft:red_concrete
setblock 350 94 417 minecraft:red_concrete
setblock 354 94 457 minecraft:red_concrete
setblock 357 94 417 minecraft:red_concrete
setblock 361 94 457 minecraft:red_concrete
setblock 364 94 417 minecraft:red_concrete
setblock 368 94 457 minecraft:red_concrete
setblock 370 94 418 minecraft:red_concrete
setblock 370 94 425 minecraft:red_concrete
setblock 370 94 432 minecraft:red_concrete
setblock 370 94 439 minecraft:red_concrete
setblock 370 94 446 minecraft:red_concrete
setblock 370 94 453 minecraft:red_concrete
setblock 330 95 419 minecraft:red_concrete
setblock 330 95 426 minecraft:red_concrete
setblock 330 95 433 minecraft:red_concrete
setblock 330 95 440 minecraft:red_concrete
setblock 330 95 447 minecraft:red_concrete
setblock 330 95 454 minecraft:red_concrete
fill 331 95 435 331 108 435 minecraft:red_wool
setblock 334 95 457 minecraft:red_concrete
setblock 335 95 417 minecraft:red_concrete
setblock 341 95 457 minecraft:red_concrete
setblock 342 95 417 minecraft:red_concrete
setblock 348 95 457 minecraft:red_concrete
setblock 349 95 417 minecraft:red_concrete
setblock 355 95 457 minecraft:red_concrete
setblock 356 95 417 minecraft:red_concrete
setblock 362 95 457 minecraft:red_concrete
setblock 363 95 417 minecraft:red_concrete
setblock 369 95 457 minecraft:red_concrete
setblock 370 95 417 minecraft:red_concrete
setblock 370 95 424 minecraft:red_concrete
setblock 370 95 431 minecraft:red_concrete
setblock 370 95 438 minecraft:red_concrete
setblock 370 95 445 minecraft:red_concrete
setblock 370 95 452 minecraft:red_concrete
setblock 330 96 420 minecraft:red_concrete
setblock 330 96 427 minecraft:red_concrete
setblock 330 96 434 minecraft:red_concrete
setblock 330 96 441 minecraft:red_concrete
setblock 330 96 448 minecraft:red_concrete
setblock 330 96 455 minecraft:red_concrete
fill 331 96 433 331 108 434 minecraft:red_wool
fill 331 96 436 331 108 437 minecraft:red_wool
setblock 332 96 419 minecraft:light[level=12]
setblock 332 96 427 minecraft:light[level=12]
setblock 332 96 435 minecraft:light[level=12]
setblock 332 96 443 minecraft:light[level=12]
setblock 332 96 451 minecraft:light[level=12]
setblock 334 96 417 minecraft:red_concrete
setblock 335 96 457 minecraft:red_concrete
setblock 340 96 419 minecraft:light[level=12]
setblock 340 96 427 minecraft:light[level=12]
setblock 340 96 435 minecraft:light[level=12]
setblock 340 96 443 minecraft:light[level=12]
setblock 340 96 451 minecraft:light[level=12]
setblock 341 96 417 minecraft:red_concrete
setblock 342 96 457 minecraft:red_concrete
setblock 348 96 417 minecraft:red_concrete
setblock 348 96 419 minecraft:light[level=12]
setblock 348 96 427 minecraft:light[level=12]
setblock 348 96 435 minecraft:light[level=12]
setblock 348 96 443 minecraft:light[level=12]
setblock 348 96 451 minecraft:light[level=12]
setblock 349 96 457 minecraft:red_concrete
setblock 355 96 417 minecraft:red_concrete
setblock 356 96 419 minecraft:light[level=12]
setblock 356 96 427 minecraft:light[level=12]
setblock 356 96 435 minecraft:light[level=12]
setblock 356 96 443 minecraft:light[level=12]
setblock 356 96 451 minecraft:light[level=12]
setblock 356 96 457 minecraft:red_concrete
setblock 362 96 417 minecraft:red_concrete
setblock 363 96 457 minecraft:red_concrete
setblock 364 96 419 minecraft:light[level=12]
setblock 364 96 427 minecraft:light[level=12]
setblock 364 96 435 minecraft:light[level=12]
setblock 364 96 443 minecraft:light[level=12]
setblock 364 96 451 minecraft:light[level=12]
setblock 369 96 417 minecraft:red_concrete
setblock 370 96 423 minecraft:red_concrete
setblock 370 96 430 minecraft:red_concrete
setblock 370 96 437 minecraft:red_concrete
setblock 370 96 444 minecraft:red_concrete
setblock 370 96 451 minecraft:red_concrete
setblock 370 96 457 minecraft:red_concrete
setblock 330 97 421 minecraft:red_concrete
setblock 330 97 428 minecraft:red_concrete
setblock 330 97 435 minecraft:red_concrete
setblock 330 97 442 minecraft:red_concrete
setblock 330 97 449 minecraft:red_concrete
setblock 330 97 456 minecraft:red_concrete
setblock 333 97 417 minecraft:red_concrete
setblock 336 97 457 minecraft:red_concrete
setblock 340 97 417 minecraft:red_concrete
setblock 343 97 457 minecraft:red_concrete
setblock 347 97 417 minecraft:red_concrete
setblock 350 97 457 minecraft:red_concrete
setblock 354 97 417 minecraft:red_concrete
setblock 357 97 457 minecraft:red_concrete
setblock 361 97 417 minecraft:red_concrete
setblock 364 97 457 minecraft:red_concrete
setblock 368 97 417 minecraft:red_concrete
setblock 370 97 422 minecraft:red_concrete
setblock 370 97 429 minecraft:red_concrete
setblock 370 97 436 minecraft:red_concrete
setblock 370 97 443 minecraft:red_concrete
setblock 370 97 450 minecraft:red_concrete
fill 330 99 423 330 100 423 minecraft:red_concrete
fill 330 99 430 330 100 430 minecraft:red_concrete
fill 330 99 437 330 100 437 minecraft:red_concrete
fill 330 99 444 330 100 444 minecraft:red_concrete
fill 330 99 451 330 100 451 minecraft:red_concrete
fill 331 99 417 331 100 417 minecraft:red_concrete
fill 331 99 457 331 100 457 minecraft:red_concrete
fill 338 99 417 338 100 417 minecraft:red_concrete
fill 338 99 457 338 100 457 minecraft:red_concrete
fill 345 99 417 345 100 417 minecraft:red_concrete
fill 345 99 457 345 100 457 minecraft:red_concrete
fill 352 99 417 352 100 417 minecraft:red_concrete
fill 352 99 457 352 100 457 minecraft:red_concrete
fill 359 99 417 359 100 417 minecraft:red_concrete
fill 359 99 457 359 100 457 minecraft:red_concrete
fill 366 99 417 366 100 417 minecraft:red_concrete
fill 366 99 457 366 100 457 minecraft:red_concrete
fill 370 99 420 370 100 420 minecraft:red_concrete
fill 370 99 427 370 100 427 minecraft:red_concrete
fill 370 99 434 370 100 434 minecraft:red_concrete
fill 370 99 441 370 100 441 minecraft:red_concrete
fill 370 99 448 370 100 448 minecraft:red_concrete
fill 370 99 455 370 100 455 minecraft:red_concrete
fill 330 100 417 330 100 421 minecraft:red_concrete
fill 330 100 424 330 100 428 minecraft:red_concrete
fill 330 100 431 330 100 435 minecraft:red_concrete
fill 330 100 438 330 100 442 minecraft:red_concrete
fill 330 100 445 330 100 449 minecraft:red_concrete
fill 330 100 452 330 100 456 minecraft:red_concrete
fill 332 100 457 336 100 457 minecraft:red_concrete
fill 333 100 417 337 100 417 minecraft:red_concrete
fill 339 100 457 343 100 457 minecraft:red_concrete
fill 340 100 417 344 100 417 minecraft:red_concrete
fill 346 100 457 350 100 457 minecraft:red_concrete
fill 347 100 417 351 100 417 minecraft:red_concrete
fill 353 100 457 357 100 457 minecraft:red_concrete
fill 354 100 417 358 100 417 minecraft:red_concrete
fill 360 100 457 364 100 457 minecraft:red_concrete
fill 361 100 417 365 100 417 minecraft:red_concrete
fill 367 100 457 370 100 457 minecraft:red_concrete
fill 368 100 417 370 100 417 minecraft:red_concrete
fill 370 100 418 370 100 419 minecraft:red_concrete
fill 370 100 422 370 100 426 minecraft:red_concrete
fill 370 100 429 370 100 433 minecraft:red_concrete
fill 370 100 436 370 100 440 minecraft:red_concrete
fill 370 100 443 370 100 447 minecraft:red_concrete
fill 370 100 450 370 100 454 minecraft:red_concrete
setblock 330 101 418 minecraft:red_concrete
setblock 330 101 425 minecraft:red_concrete
setblock 330 101 432 minecraft:red_concrete
setblock 330 101 439 minecraft:red_concrete
setblock 330 101 446 minecraft:red_concrete
setblock 330 101 453 minecraft:red_concrete
setblock 333 101 457 minecraft:red_concrete
setblock 336 101 417 minecraft:red_concrete
setblock 340 101 457 minecraft:red_concrete
setblock 343 101 417 minecraft:red_concrete
setblock 347 101 457 minecraft:red_concrete
setblock 350 101 417 minecraft:red_concrete
setblock 354 101 457 minecraft:red_concrete
setblock 357 101 417 minecraft:red_concrete
setblock 361 101 457 minecraft:red_concrete
setblock 364 101 417 minecraft:red_concrete
setblock 368 101 457 minecraft:red_concrete
setblock 370 101 418 minecraft:red_concrete
setblock 370 101 425 minecraft:red_concrete
setblock 370 101 432 minecraft:red_concrete
setblock 370 101 439 minecraft:red_concrete
setblock 370 101 446 minecraft:red_concrete
setblock 370 101 453 minecraft:red_concrete
setblock 330 102 419 minecraft:red_concrete
setblock 330 102 426 minecraft:red_concrete
setblock 330 102 433 minecraft:red_concrete
setblock 330 102 440 minecraft:red_concrete
setblock 330 102 447 minecraft:red_concrete
setblock 330 102 454 minecraft:red_concrete
setblock 334 102 457 minecraft:red_concrete
setblock 335 102 417 minecraft:red_concrete
setblock 341 102 457 minecraft:red_concrete
setblock 342 102 417 minecraft:red_concrete
setblock 348 102 457 minecraft:red_concrete
setblock 349 102 417 minecraft:red_concrete
setblock 355 102 457 minecraft:red_concrete
setblock 356 102 417 minecraft:red_concrete
setblock 362 102 457 minecraft:red_concrete
setblock 363 102 417 minecraft:red_concrete
setblock 369 102 457 minecraft:red_concrete
setblock 370 102 417 minecraft:red_concrete
setblock 370 102 424 minecraft:red_concrete
setblock 370 102 431 minecraft:red_concrete
setblock 370 102 438 minecraft:red_concrete
setblock 370 102 445 minecraft:red_concrete
setblock 370 102 452 minecraft:red_concrete
setblock 330 103 420 minecraft:red_concrete
setblock 330 103 427 minecraft:red_concrete
setblock 330 103 434 minecraft:red_concrete
setblock 330 103 441 minecraft:red_concrete
setblock 330 103 448 minecraft:red_concrete
setblock 330 103 455 minecraft:red_concrete
setblock 334 103 417 minecraft:red_concrete
schedule function dropper:buildpart/103_2 1t
