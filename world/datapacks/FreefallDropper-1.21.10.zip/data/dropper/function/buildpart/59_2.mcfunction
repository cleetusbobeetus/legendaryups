fill 541 149 228 541 151 228 minecraft:purple_terracotta
fill 541 149 270 541 151 270 minecraft:purple_terracotta
fill 545 149 228 545 151 228 minecraft:purple_terracotta
fill 545 149 243 545 150 243 minecraft:white_stained_glass
fill 545 149 270 545 151 270 minecraft:purple_terracotta
fill 548 149 246 548 150 246 minecraft:white_stained_glass
fill 549 149 228 549 151 228 minecraft:purple_terracotta
fill 549 149 270 549 151 270 minecraft:purple_terracotta
fill 553 149 228 553 151 228 minecraft:purple_terracotta
fill 553 149 270 553 151 270 minecraft:purple_terracotta
fill 557 149 228 557 151 228 minecraft:purple_terracotta
fill 557 149 270 557 151 270 minecraft:purple_terracotta
setblock 559 149 228 minecraft:purple_terracotta
fill 559 149 232 559 151 232 minecraft:purple_terracotta
fill 559 149 236 559 151 236 minecraft:purple_terracotta
fill 559 149 240 559 151 240 minecraft:purple_terracotta
fill 559 149 244 559 151 244 minecraft:purple_terracotta
fill 559 149 248 559 151 248 minecraft:purple_terracotta
fill 559 149 252 559 151 252 minecraft:purple_terracotta
fill 559 149 256 559 151 256 minecraft:purple_terracotta
fill 559 149 260 559 151 260 minecraft:purple_terracotta
fill 559 149 264 559 151 264 minecraft:purple_terracotta
fill 559 149 268 559 151 268 minecraft:purple_terracotta
setblock 517 150 230 minecraft:magenta_terracotta
setblock 517 150 234 minecraft:magenta_terracotta
setblock 517 150 238 minecraft:magenta_terracotta
setblock 517 150 242 minecraft:magenta_terracotta
setblock 517 150 246 minecraft:magenta_terracotta
setblock 517 150 250 minecraft:magenta_terracotta
setblock 517 150 254 minecraft:magenta_terracotta
setblock 517 150 258 minecraft:magenta_terracotta
setblock 517 150 262 minecraft:magenta_terracotta
setblock 517 150 266 minecraft:magenta_terracotta
setblock 517 150 270 minecraft:magenta_terracotta
setblock 519 150 228 minecraft:magenta_terracotta
setblock 519 150 270 minecraft:magenta_terracotta
setblock 523 150 228 minecraft:magenta_terracotta
setblock 523 150 270 minecraft:magenta_terracotta
setblock 527 150 228 minecraft:magenta_terracotta
setblock 527 150 270 minecraft:magenta_terracotta
setblock 531 150 228 minecraft:magenta_terracotta
setblock 531 150 270 minecraft:magenta_terracotta
setblock 535 150 228 minecraft:magenta_terracotta
setblock 535 150 270 minecraft:magenta_terracotta
fill 536 150 268 537 150 269 minecraft:dark_oak_planks
fill 538 150 268 539 150 268 minecraft:spruce_planks
setblock 539 150 228 minecraft:magenta_terracotta
setblock 539 150 270 minecraft:magenta_terracotta
setblock 543 150 228 minecraft:magenta_terracotta
setblock 543 150 270 minecraft:magenta_terracotta
fill 545 150 244 547 152 245 minecraft:white_concrete
setblock 545 150 246 minecraft:white_stained_glass
setblock 546 150 243 minecraft:black_concrete
fill 546 150 246 547 152 246 minecraft:white_concrete
setblock 547 150 228 minecraft:magenta_terracotta
setblock 547 150 243 minecraft:white_stained_glass
setblock 547 150 270 minecraft:magenta_terracotta
setblock 548 150 245 minecraft:white_stained_glass
setblock 551 150 228 minecraft:magenta_terracotta
setblock 551 150 270 minecraft:magenta_terracotta
setblock 555 150 228 minecraft:magenta_terracotta
setblock 555 150 270 minecraft:magenta_terracotta
setblock 559 150 228 minecraft:magenta_terracotta
setblock 559 150 230 minecraft:magenta_terracotta
setblock 559 150 234 minecraft:magenta_terracotta
setblock 559 150 238 minecraft:magenta_terracotta
setblock 559 150 242 minecraft:magenta_terracotta
setblock 559 150 246 minecraft:magenta_terracotta
setblock 559 150 250 minecraft:magenta_terracotta
setblock 559 150 254 minecraft:magenta_terracotta
setblock 559 150 258 minecraft:magenta_terracotta
setblock 559 150 262 minecraft:magenta_terracotta
setblock 559 150 266 minecraft:magenta_terracotta
setblock 559 150 270 minecraft:magenta_terracotta
fill 517 151 230 517 153 230 minecraft:purple_terracotta
fill 517 151 234 517 153 234 minecraft:purple_terracotta
fill 517 151 238 517 153 238 minecraft:purple_terracotta
fill 517 151 242 517 153 242 minecraft:purple_terracotta
fill 517 151 246 517 153 246 minecraft:purple_terracotta
fill 517 151 250 517 153 250 minecraft:purple_terracotta
fill 517 151 254 517 153 254 minecraft:purple_terracotta
fill 517 151 258 517 153 258 minecraft:purple_terracotta
fill 517 151 262 517 153 262 minecraft:purple_terracotta
fill 517 151 266 517 153 266 minecraft:purple_terracotta
setblock 517 151 270 minecraft:purple_terracotta
fill 519 151 228 519 153 228 minecraft:purple_terracotta
fill 519 151 270 519 153 270 minecraft:purple_terracotta
setblock 520 151 231 minecraft:light[level=12]
setblock 520 151 238 minecraft:light[level=12]
setblock 520 151 245 minecraft:light[level=12]
setblock 520 151 252 minecraft:light[level=12]
setblock 520 151 259 minecraft:light[level=12]
setblock 520 151 266 minecraft:light[level=12]
fill 523 151 228 523 153 228 minecraft:purple_terracotta
fill 523 151 270 523 153 270 minecraft:purple_terracotta
fill 527 151 228 527 153 228 minecraft:purple_terracotta
setblock 527 151 231 minecraft:light[level=12]
setblock 527 151 238 minecraft:light[level=12]
setblock 527 151 245 minecraft:light[level=12]
setblock 527 151 252 minecraft:light[level=12]
setblock 527 151 259 minecraft:light[level=12]
setblock 527 151 266 minecraft:light[level=12]
fill 527 151 270 527 153 270 minecraft:purple_terracotta
fill 531 151 228 531 153 228 minecraft:purple_terracotta
fill 531 151 270 531 153 270 minecraft:purple_terracotta
setblock 534 151 231 minecraft:light[level=12]
setblock 534 151 238 minecraft:light[level=12]
setblock 534 151 245 minecraft:light[level=12]
setblock 534 151 252 minecraft:light[level=12]
setblock 534 151 259 minecraft:light[level=12]
setblock 534 151 266 minecraft:light[level=12]
fill 535 151 228 535 153 228 minecraft:purple_terracotta
fill 535 151 270 535 153 270 minecraft:purple_terracotta
fill 538 151 268 539 151 269 minecraft:dark_oak_planks
fill 539 151 228 539 153 228 minecraft:purple_terracotta
fill 539 151 270 539 153 270 minecraft:purple_terracotta
fill 540 151 268 541 151 268 minecraft:spruce_planks
setblock 541 151 231 minecraft:light[level=12]
setblock 541 151 238 minecraft:light[level=12]
setblock 541 151 245 minecraft:light[level=12]
setblock 541 151 252 minecraft:light[level=12]
setblock 541 151 259 minecraft:light[level=12]
setblock 541 151 266 minecraft:light[level=12]
fill 543 151 228 543 153 228 minecraft:purple_terracotta
setblock 543 151 270 minecraft:black_terracotta
setblock 545 151 246 minecraft:white_concrete
setblock 546 151 243 minecraft:white_concrete
fill 547 151 228 547 153 228 minecraft:purple_terracotta
setblock 547 151 243 minecraft:black_concrete
fill 547 151 270 547 153 270 minecraft:purple_terracotta
setblock 548 151 231 minecraft:light[level=12]
setblock 548 151 238 minecraft:light[level=12]
setblock 548 151 245 minecraft:white_concrete
setblock 548 151 252 minecraft:light[level=12]
setblock 548 151 259 minecraft:light[level=12]
setblock 548 151 266 minecraft:light[level=12]
fill 551 151 228 551 153 228 minecraft:purple_terracotta
fill 551 151 270 551 153 270 minecraft:purple_terracotta
fill 555 151 228 555 153 228 minecraft:purple_terracotta
setblock 555 151 231 minecraft:light[level=12]
setblock 555 151 238 minecraft:light[level=12]
setblock 555 151 245 minecraft:light[level=12]
setblock 555 151 252 minecraft:light[level=12]
setblock 555 151 259 minecraft:light[level=12]
setblock 555 151 266 minecraft:light[level=12]
fill 555 151 270 555 153 270 minecraft:purple_terracotta
setblock 559 151 228 minecraft:purple_terracotta
fill 559 151 230 559 153 230 minecraft:purple_terracotta
fill 559 151 234 559 153 234 minecraft:purple_terracotta
fill 559 151 238 559 153 238 minecraft:purple_terracotta
fill 559 151 242 559 153 242 minecraft:purple_terracotta
fill 559 151 246 559 153 246 minecraft:purple_terracotta
fill 559 151 250 559 153 250 minecraft:purple_terracotta
fill 559 151 254 559 153 254 minecraft:purple_terracotta
fill 559 151 258 559 153 258 minecraft:purple_terracotta
fill 559 151 262 559 153 262 minecraft:purple_terracotta
fill 559 151 266 559 153 266 minecraft:purple_terracotta
fill 559 151 270 559 153 270 minecraft:purple_terracotta
setblock 517 152 228 minecraft:magenta_terracotta
setblock 517 152 232 minecraft:magenta_terracotta
setblock 517 152 236 minecraft:magenta_terracotta
setblock 517 152 240 minecraft:magenta_terracotta
setblock 517 152 244 minecraft:magenta_terracotta
setblock 517 152 248 minecraft:magenta_terracotta
setblock 517 152 252 minecraft:magenta_terracotta
setblock 517 152 256 minecraft:magenta_terracotta
setblock 517 152 260 minecraft:magenta_terracotta
setblock 517 152 264 minecraft:magenta_terracotta
setblock 517 152 268 minecraft:magenta_terracotta
setblock 517 152 270 minecraft:magenta_terracotta
setblock 521 152 228 minecraft:magenta_terracotta
setblock 521 152 270 minecraft:magenta_terracotta
fill 522 152 241 522 155 241 minecraft:iron_bars
setblock 525 152 228 minecraft:magenta_terracotta
setblock 525 152 270 minecraft:magenta_terracotta
setblock 529 152 228 minecraft:magenta_terracotta
setblock 529 152 270 minecraft:magenta_terracotta
setblock 533 152 228 minecraft:magenta_terracotta
setblock 533 152 270 minecraft:magenta_terracotta
setblock 537 152 228 minecraft:magenta_terracotta
setblock 537 152 270 minecraft:magenta_terracotta
fill 538 152 228 538 165 228 minecraft:purple_terracotta
fill 540 152 268 541 152 269 minecraft:dark_oak_planks
setblock 541 152 228 minecraft:magenta_terracotta
setblock 541 152 270 minecraft:magenta_terracotta
fill 542 152 268 543 152 268 minecraft:spruce_planks
fill 543 152 270 543 153 270 minecraft:purple_terracotta
setblock 545 152 228 minecraft:magenta_terracotta
setblock 545 152 270 minecraft:magenta_terracotta
setblock 549 152 228 minecraft:magenta_terracotta
setblock 549 152 270 minecraft:magenta_terracotta
setblock 553 152 228 minecraft:magenta_terracotta
setblock 553 152 270 minecraft:magenta_terracotta
setblock 557 152 228 minecraft:magenta_terracotta
setblock 557 152 270 minecraft:magenta_terracotta
setblock 559 152 228 minecraft:magenta_terracotta
setblock 559 152 232 minecraft:magenta_terracotta
setblock 559 152 236 minecraft:magenta_terracotta
setblock 559 152 240 minecraft:magenta_terracotta
setblock 559 152 244 minecraft:magenta_terracotta
setblock 559 152 248 minecraft:magenta_terracotta
setblock 559 152 252 minecraft:magenta_terracotta
setblock 559 152 256 minecraft:magenta_terracotta
setblock 559 152 260 minecraft:magenta_terracotta
setblock 559 152 264 minecraft:magenta_terracotta
setblock 559 152 268 minecraft:magenta_terracotta
fill 517 153 228 517 155 228 minecraft:purple_terracotta
fill 517 153 232 517 155 232 minecraft:purple_terracotta
fill 517 153 236 517 155 236 minecraft:purple_terracotta
fill 517 153 240 517 155 240 minecraft:purple_terracotta
fill 517 153 244 517 155 244 minecraft:purple_terracotta
fill 517 153 248 517 155 248 minecraft:purple_terracotta
fill 517 153 252 517 155 252 minecraft:purple_terracotta
fill 517 153 256 517 155 256 minecraft:purple_terracotta
fill 517 153 260 517 155 260 minecraft:purple_terracotta
fill 517 153 264 517 155 264 minecraft:purple_terracotta
fill 517 153 268 517 155 268 minecraft:purple_terracotta
setblock 517 153 270 minecraft:purple_terracotta
setblock 520 153 231 minecraft:light[level=11]
setblock 520 153 239 minecraft:light[level=11]
setblock 520 153 247 minecraft:light[level=11]
setblock 520 153 255 minecraft:light[level=11]
setblock 520 153 263 minecraft:light[level=11]
fill 521 153 228 521 155 228 minecraft:purple_terracotta
fill 521 153 270 521 155 270 minecraft:purple_terracotta
fill 525 153 228 525 155 228 minecraft:purple_terracotta
fill 525 153 270 525 155 270 minecraft:purple_terracotta
setblock 528 153 231 minecraft:light[level=11]
setblock 528 153 239 minecraft:light[level=11]
setblock 528 153 247 minecraft:light[level=11]
setblock 528 153 255 minecraft:light[level=11]
setblock 528 153 263 minecraft:light[level=11]
fill 529 153 228 529 155 228 minecraft:purple_terracotta
fill 529 153 270 529 155 270 minecraft:purple_terracotta
fill 533 153 228 533 155 228 minecraft:purple_terracotta
fill 533 153 270 533 155 270 minecraft:purple_terracotta
setblock 536 153 231 minecraft:light[level=11]
setblock 536 153 239 minecraft:light[level=11]
setblock 536 153 247 minecraft:light[level=11]
setblock 536 153 255 minecraft:light[level=11]
setblock 536 153 263 minecraft:light[level=11]
fill 537 153 228 537 155 228 minecraft:purple_terracotta
fill 537 153 270 537 155 270 minecraft:purple_terracotta
fill 541 153 228 541 155 228 minecraft:purple_terracotta
fill 541 153 270 541 155 270 minecraft:purple_terracotta
fill 542 153 268 543 153 269 minecraft:dark_oak_planks
setblock 544 153 231 minecraft:light[level=11]
setblock 544 153 239 minecraft:light[level=11]
setblock 544 153 247 minecraft:light[level=11]
setblock 544 153 255 minecraft:light[level=11]
setblock 544 153 263 minecraft:light[level=11]
fill 544 153 268 545 153 268 minecraft:spruce_planks
fill 545 153 228 545 155 228 minecraft:purple_terracotta
fill 545 153 270 545 155 270 minecraft:purple_terracotta
fill 549 153 228 549 155 228 minecraft:purple_terracotta
fill 549 153 270 549 155 270 minecraft:purple_terracotta
setblock 552 153 231 minecraft:light[level=11]
setblock 552 153 239 minecraft:light[level=11]
setblock 552 153 247 minecraft:light[level=11]
setblock 552 153 255 minecraft:light[level=11]
setblock 552 153 263 minecraft:light[level=11]
fill 553 153 228 553 155 228 minecraft:purple_terracotta
fill 553 153 270 553 155 270 minecraft:purple_terracotta
fill 557 153 228 557 155 228 minecraft:purple_terracotta
fill 557 153 270 557 155 270 minecraft:purple_terracotta
setblock 559 153 228 minecraft:purple_terracotta
fill 559 153 232 559 155 232 minecraft:purple_terracotta
fill 559 153 236 559 155 236 minecraft:purple_terracotta
fill 559 153 240 559 155 240 minecraft:purple_terracotta
fill 559 153 244 559 155 244 minecraft:purple_terracotta
fill 559 153 248 559 155 248 minecraft:purple_terracotta
fill 559 153 252 559 155 252 minecraft:purple_terracotta
fill 559 153 256 559 155 256 minecraft:purple_terracotta
fill 559 153 260 559 155 260 minecraft:purple_terracotta
fill 559 153 264 559 155 264 minecraft:purple_terracotta
fill 559 153 268 559 155 268 minecraft:purple_terracotta
setblock 517 154 230 minecraft:magenta_terracotta
setblock 517 154 234 minecraft:magenta_terracotta
setblock 517 154 238 minecraft:magenta_terracotta
setblock 517 154 242 minecraft:magenta_terracotta
setblock 517 154 246 minecraft:magenta_terracotta
setblock 517 154 250 minecraft:magenta_terracotta
setblock 517 154 254 minecraft:magenta_terracotta
setblock 517 154 258 minecraft:magenta_terracotta
setblock 517 154 262 minecraft:magenta_terracotta
setblock 517 154 266 minecraft:magenta_terracotta
setblock 517 154 270 minecraft:magenta_terracotta
setblock 519 154 228 minecraft:magenta_terracotta
setblock 519 154 270 minecraft:magenta_terracotta
setblock 523 154 228 minecraft:magenta_terracotta
setblock 523 154 270 minecraft:magenta_terracotta
setblock 527 154 228 minecraft:magenta_terracotta
setblock 527 154 270 minecraft:magenta_terracotta
setblock 531 154 228 minecraft:magenta_terracotta
setblock 531 154 270 minecraft:magenta_terracotta
setblock 535 154 228 minecraft:magenta_terracotta
setblock 535 154 270 minecraft:magenta_terracotta
setblock 539 154 228 minecraft:magenta_terracotta
setblock 539 154 270 minecraft:magenta_terracotta
setblock 543 154 228 minecraft:magenta_terracotta
setblock 543 154 270 minecraft:magenta_terracotta
fill 544 154 268 545 154 269 minecraft:dark_oak_planks
fill 546 154 268 547 154 268 minecraft:spruce_planks
setblock 547 154 228 minecraft:magenta_terracotta
setblock 547 154 270 minecraft:magenta_terracotta
setblock 551 154 228 minecraft:magenta_terracotta
setblock 551 154 270 minecraft:magenta_terracotta
setblock 555 154 228 minecraft:magenta_terracotta
setblock 555 154 270 minecraft:magenta_terracotta
setblock 559 154 228 minecraft:magenta_terracotta
setblock 559 154 230 minecraft:magenta_terracotta
setblock 559 154 234 minecraft:magenta_terracotta
setblock 559 154 238 minecraft:magenta_terracotta
setblock 559 154 242 minecraft:magenta_terracotta
setblock 559 154 246 minecraft:magenta_terracotta
setblock 559 154 250 minecraft:magenta_terracotta
setblock 559 154 254 minecraft:magenta_terracotta
setblock 559 154 258 minecraft:magenta_terracotta
setblock 559 154 262 minecraft:magenta_terracotta
setblock 559 154 266 minecraft:magenta_terracotta
setblock 559 154 270 minecraft:magenta_terracotta
fill 517 155 230 517 157 230 minecraft:purple_terracotta
fill 517 155 234 517 157 234 minecraft:purple_terracotta
fill 517 155 238 517 157 238 minecraft:purple_terracotta
fill 517 155 242 517 157 242 minecraft:purple_terracotta
fill 517 155 246 517 157 246 minecraft:purple_terracotta
fill 517 155 250 517 157 250 minecraft:purple_terracotta
fill 517 155 254 517 157 254 minecraft:purple_terracotta
setblock 517 155 258 minecraft:black_terracotta
fill 517 155 262 517 157 262 minecraft:purple_terracotta
fill 517 155 266 517 157 266 minecraft:purple_terracotta
setblock 517 155 270 minecraft:purple_terracotta
setblock 519 155 228 minecraft:purple_terracotta
fill 519 155 270 519 157 270 minecraft:purple_terracotta
fill 523 155 228 523 157 228 minecraft:purple_terracotta
fill 523 155 270 523 157 270 minecraft:purple_terracotta
fill 527 155 228 527 157 228 minecraft:purple_terracotta
fill 527 155 270 527 157 270 minecraft:purple_terracotta
fill 531 155 228 531 157 228 minecraft:purple_terracotta
fill 531 155 270 531 157 270 minecraft:purple_terracotta
fill 535 155 228 535 157 228 minecraft:purple_terracotta
fill 535 155 270 535 157 270 minecraft:purple_terracotta
fill 539 155 228 539 157 228 minecraft:purple_terracotta
fill 539 155 270 539 157 270 minecraft:purple_terracotta
fill 543 155 228 543 157 228 minecraft:purple_terracotta
fill 543 155 270 543 157 270 minecraft:purple_terracotta
fill 546 155 268 547 155 269 minecraft:dark_oak_planks
fill 547 155 228 547 157 228 minecraft:purple_terracotta
fill 547 155 270 547 157 270 minecraft:purple_terracotta
fill 548 155 268 549 155 268 minecraft:spruce_planks
fill 551 155 228 551 157 228 minecraft:purple_terracotta
fill 551 155 270 551 157 270 minecraft:purple_terracotta
fill 555 155 228 555 157 228 minecraft:purple_terracotta
fill 555 155 270 555 157 270 minecraft:purple_terracotta
setblock 559 155 228 minecraft:purple_terracotta
fill 559 155 230 559 157 230 minecraft:purple_terracotta
fill 559 155 234 559 157 234 minecraft:purple_terracotta
fill 559 155 238 559 157 238 minecraft:purple_terracotta
fill 559 155 242 559 157 242 minecraft:purple_terracotta
fill 559 155 246 559 157 246 minecraft:purple_terracotta
fill 559 155 250 559 157 250 minecraft:purple_terracotta
fill 559 155 254 559 157 254 minecraft:purple_terracotta
fill 559 155 258 559 157 258 minecraft:purple_terracotta
fill 559 155 262 559 157 262 minecraft:purple_terracotta
fill 559 155 266 559 157 266 minecraft:purple_terracotta
fill 559 155 270 559 157 270 minecraft:purple_terracotta
setblock 517 156 228 minecraft:magenta_terracotta
setblock 517 156 232 minecraft:magenta_terracotta
setblock 517 156 236 minecraft:magenta_terracotta
setblock 517 156 240 minecraft:magenta_terracotta
setblock 517 156 244 minecraft:magenta_terracotta
setblock 517 156 248 minecraft:magenta_terracotta
setblock 517 156 252 minecraft:magenta_terracotta
setblock 517 156 256 minecraft:magenta_terracotta
fill 517 156 258 517 157 258 minecraft:purple_terracotta
setblock 517 156 260 minecraft:magenta_terracotta
setblock 517 156 264 minecraft:magenta_terracotta
setblock 517 156 268 minecraft:magenta_terracotta
setblock 517 156 270 minecraft:magenta_terracotta
fill 518 156 237 522 156 245 minecraft:dark_oak_planks
setblock 519 156 228 minecraft:light_gray_terracotta
setblock 521 156 228 minecraft:magenta_terracotta
setblock 521 156 270 minecraft:magenta_terracotta
setblock 525 156 228 minecraft:magenta_terracotta
setblock 525 156 270 minecraft:magenta_terracotta
setblock 529 156 228 minecraft:magenta_terracotta
setblock 529 156 270 minecraft:magenta_terracotta
setblock 533 156 228 minecraft:magenta_terracotta
setblock 533 156 270 minecraft:magenta_terracotta
setblock 537 156 228 minecraft:magenta_terracotta
setblock 537 156 270 minecraft:magenta_terracotta
setblock 541 156 228 minecraft:magenta_terracotta
setblock 541 156 270 minecraft:magenta_terracotta
setblock 545 156 228 minecraft:magenta_terracotta
setblock 545 156 270 minecraft:magenta_terracotta
setblock 546 156 270 minecraft:light_gray_terracotta
fill 548 156 268 549 156 269 minecraft:dark_oak_planks
setblock 549 156 228 minecraft:magenta_terracotta
setblock 549 156 270 minecraft:magenta_terracotta
fill 550 156 268 551 156 268 minecraft:spruce_planks
setblock 553 156 228 minecraft:magenta_terracotta
setblock 553 156 270 minecraft:magenta_terracotta
setblock 557 156 228 minecraft:magenta_terracotta
setblock 557 156 270 minecraft:magenta_terracotta
setblock 559 156 228 minecraft:magenta_terracotta
setblock 559 156 231 minecraft:black_terracotta
setblock 559 156 232 minecraft:magenta_terracotta
setblock 559 156 236 minecraft:magenta_terracotta
setblock 559 156 240 minecraft:magenta_terracotta
setblock 559 156 244 minecraft:magenta_terracotta
setblock 559 156 248 minecraft:magenta_terracotta
setblock 559 156 252 minecraft:magenta_terracotta
setblock 559 156 256 minecraft:magenta_terracotta
setblock 559 156 260 minecraft:magenta_terracotta
setblock 559 156 264 minecraft:magenta_terracotta
setblock 559 156 268 minecraft:magenta_terracotta
fill 517 157 228 517 159 228 minecraft:purple_terracotta
fill 517 157 232 517 159 232 minecraft:purple_terracotta
fill 517 157 236 517 159 236 minecraft:purple_terracotta
setblock 517 157 240 minecraft:purple_terracotta
fill 517 157 244 517 159 244 minecraft:purple_terracotta
fill 517 157 248 517 159 248 minecraft:purple_terracotta
fill 517 157 252 517 159 252 minecraft:purple_terracotta
fill 517 157 256 517 159 256 minecraft:purple_terracotta
fill 517 157 260 517 159 260 minecraft:purple_terracotta
fill 517 157 264 517 159 264 minecraft:purple_terracotta
fill 517 157 268 517 159 268 minecraft:purple_terracotta
setblock 517 157 270 minecraft:purple_terracotta
fill 518 157 237 522 157 245 minecraft:stripped_dark_oak_log
setblock 519 157 228 minecraft:purple_terracotta
setblock 520 157 231 minecraft:light[level=12]
setblock 520 157 252 minecraft:light[level=12]
setblock 520 157 259 minecraft:light[level=12]
setblock 520 157 266 minecraft:light[level=12]
fill 521 157 228 521 159 228 minecraft:purple_terracotta
fill 521 157 270 521 159 270 minecraft:purple_terracotta
fill 525 157 228 525 159 228 minecraft:purple_terracotta
fill 525 157 270 525 159 270 minecraft:purple_terracotta
setblock 527 157 231 minecraft:light[level=12]
setblock 527 157 238 minecraft:light[level=12]
setblock 527 157 245 minecraft:light[level=12]
setblock 527 157 252 minecraft:light[level=12]
setblock 527 157 259 minecraft:light[level=12]
setblock 527 157 266 minecraft:light[level=12]
fill 529 157 228 529 159 228 minecraft:purple_terracotta
fill 529 157 270 529 159 270 minecraft:purple_terracotta
fill 533 157 228 533 159 228 minecraft:purple_terracotta
fill 533 157 270 533 159 270 minecraft:purple_terracotta
setblock 534 157 231 minecraft:light[level=12]
setblock 534 157 238 minecraft:light[level=12]
setblock 534 157 245 minecraft:light[level=12]
setblock 534 157 252 minecraft:light[level=12]
setblock 534 157 259 minecraft:light[level=12]
setblock 534 157 266 minecraft:light[level=12]
fill 537 157 228 537 159 228 minecraft:purple_terracotta
fill 537 157 270 537 159 270 minecraft:purple_terracotta
setblock 540 157 228 minecraft:light_gray_terracotta
fill 541 157 228 541 159 228 minecraft:purple_terracotta
setblock 541 157 231 minecraft:light[level=12]
setblock 541 157 238 minecraft:light[level=12]
setblock 541 157 245 minecraft:light[level=12]
setblock 541 157 252 minecraft:light[level=12]
setblock 541 157 259 minecraft:light[level=12]
setblock 541 157 266 minecraft:light[level=12]
fill 541 157 270 541 159 270 minecraft:purple_terracotta
setblock 544 157 228 minecraft:light_gray_terracotta
fill 545 157 228 545 159 228 minecraft:purple_terracotta
fill 545 157 270 546 159 270 minecraft:purple_terracotta
setblock 548 157 231 minecraft:light[level=12]
setblock 548 157 238 minecraft:light[level=12]
setblock 548 157 245 minecraft:light[level=12]
setblock 548 157 252 minecraft:light[level=12]
setblock 548 157 259 minecraft:light[level=12]
setblock 548 157 266 minecraft:light[level=12]
fill 549 157 228 549 159 228 minecraft:purple_terracotta
fill 549 157 270 549 159 270 minecraft:purple_terracotta
fill 550 157 268 551 157 269 minecraft:dark_oak_planks
fill 552 157 268 553 157 268 minecraft:spruce_planks
fill 553 157 228 553 159 228 minecraft:purple_terracotta
fill 553 157 270 553 159 270 minecraft:purple_terracotta
setblock 555 157 231 minecraft:light[level=12]
setblock 555 157 238 minecraft:light[level=12]
setblock 555 157 245 minecraft:light[level=12]
setblock 555 157 252 minecraft:light[level=12]
setblock 555 157 259 minecraft:light[level=12]
setblock 555 157 266 minecraft:light[level=12]
fill 557 157 228 557 159 228 minecraft:purple_terracotta
fill 557 157 270 557 159 270 minecraft:purple_terracotta
setblock 559 157 228 minecraft:purple_terracotta
fill 559 157 231 559 159 232 minecraft:purple_terracotta
fill 559 157 236 559 159 236 minecraft:purple_terracotta
fill 559 157 240 559 159 240 minecraft:purple_terracotta
fill 559 157 244 559 159 244 minecraft:purple_terracotta
fill 559 157 248 559 159 248 minecraft:purple_terracotta
fill 559 157 252 559 159 252 minecraft:purple_terracotta
fill 559 157 256 559 159 256 minecraft:purple_terracotta
fill 559 157 260 559 159 260 minecraft:purple_terracotta
fill 559 157 264 559 159 264 minecraft:purple_terracotta
fill 559 157 268 559 159 268 minecraft:purple_terracotta
setblock 517 158 230 minecraft:magenta_terracotta
setblock 517 158 234 minecraft:magenta_terracotta
setblock 517 158 238 minecraft:magenta_terracotta
fill 517 158 240 517 161 242 minecraft:jack_o_lantern
setblock 517 158 246 minecraft:magenta_terracotta
setblock 517 158 250 minecraft:magenta_terracotta
setblock 517 158 254 minecraft:magenta_terracotta
setblock 517 158 258 minecraft:magenta_terracotta
setblock 517 158 262 minecraft:magenta_terracotta
setblock 517 158 266 minecraft:magenta_terracotta
setblock 517 158 270 minecraft:magenta_terracotta
setblock 519 158 228 minecraft:magenta_terracotta
setblock 519 158 270 minecraft:magenta_terracotta
fill 522 158 237 522 158 245 minecraft:purple_concrete
setblock 523 158 228 minecraft:magenta_terracotta
setblock 523 158 270 minecraft:magenta_terracotta
setblock 524 158 228 minecraft:light_gray_terracotta
setblock 527 158 228 minecraft:magenta_terracotta
setblock 527 158 270 minecraft:magenta_terracotta
setblock 531 158 228 minecraft:magenta_terracotta
setblock 531 158 270 minecraft:magenta_terracotta
setblock 535 158 228 minecraft:magenta_terracotta
setblock 535 158 270 minecraft:magenta_terracotta
setblock 539 158 228 minecraft:magenta_terracotta
setblock 539 158 270 minecraft:magenta_terracotta
fill 540 158 228 540 207 228 minecraft:purple_terracotta
setblock 543 158 228 minecraft:magenta_terracotta
setblock 543 158 270 minecraft:magenta_terracotta
fill 544 158 228 544 207 228 minecraft:purple_terracotta
setblock 547 158 228 minecraft:magenta_terracotta
setblock 547 158 270 minecraft:magenta_terracotta
setblock 551 158 228 minecraft:magenta_terracotta
setblock 551 158 270 minecraft:magenta_terracotta
fill 552 158 268 553 158 269 minecraft:dark_oak_planks
fill 554 158 268 555 158 268 minecraft:spruce_planks
setblock 555 158 228 minecraft:magenta_terracotta
setblock 555 158 270 minecraft:magenta_terracotta
setblock 559 158 228 minecraft:magenta_terracotta
setblock 559 158 230 minecraft:magenta_terracotta
setblock 559 158 234 minecraft:magenta_terracotta
setblock 559 158 238 minecraft:magenta_terracotta
setblock 559 158 242 minecraft:magenta_terracotta
setblock 559 158 246 minecraft:magenta_terracotta
setblock 559 158 250 minecraft:magenta_terracotta
setblock 559 158 254 minecraft:magenta_terracotta
setblock 559 158 258 minecraft:magenta_terracotta
setblock 559 158 262 minecraft:magenta_terracotta
setblock 559 158 266 minecraft:magenta_terracotta
setblock 559 158 270 minecraft:magenta_terracotta
fill 517 159 230 517 161 230 minecraft:purple_terracotta
fill 517 159 234 517 161 234 minecraft:purple_terracotta
fill 517 159 238 517 161 238 minecraft:purple_terracotta
fill 517 159 246 517 161 246 minecraft:purple_terracotta
fill 517 159 250 517 161 250 minecraft:purple_terracotta
fill 517 159 254 517 161 254 minecraft:purple_terracotta
fill 517 159 258 517 161 258 minecraft:purple_terracotta
fill 517 159 262 517 161 262 minecraft:purple_terracotta
fill 517 159 266 517 161 266 minecraft:purple_terracotta
setblock 517 159 270 minecraft:purple_terracotta
fill 519 159 228 519 161 228 minecraft:purple_terracotta
fill 519 159 270 519 161 270 minecraft:purple_terracotta
setblock 522 159 237 minecraft:stripped_dark_oak_log
setblock 522 159 241 minecraft:stripped_dark_oak_log
setblock 522 159 245 minecraft:stripped_dark_oak_log
fill 523 159 228 524 161 228 minecraft:purple_terracotta
fill 523 159 270 523 161 270 minecraft:purple_terracotta
fill 527 159 228 527 161 228 minecraft:purple_terracotta
fill 527 159 270 527 161 270 minecraft:purple_terracotta
fill 531 159 228 531 161 228 minecraft:purple_terracotta
fill 531 159 270 531 161 270 minecraft:purple_terracotta
fill 535 159 228 535 161 228 minecraft:purple_terracotta
fill 535 159 270 535 161 270 minecraft:purple_terracotta
fill 539 159 228 539 161 228 minecraft:purple_terracotta
fill 539 159 270 539 161 270 minecraft:purple_terracotta
fill 543 159 228 543 161 228 minecraft:purple_terracotta
fill 543 159 270 543 161 270 minecraft:purple_terracotta
fill 547 159 228 547 161 228 minecraft:purple_terracotta
fill 547 159 270 547 161 270 minecraft:purple_terracotta
fill 551 159 228 551 161 228 minecraft:purple_terracotta
fill 551 159 270 551 161 270 minecraft:purple_terracotta
fill 554 159 268 555 159 269 minecraft:dark_oak_planks
fill 555 159 228 555 161 228 minecraft:purple_terracotta
fill 555 159 270 555 161 270 minecraft:purple_terracotta
fill 556 159 268 557 159 268 minecraft:spruce_planks
setblock 559 159 228 minecraft:purple_terracotta
fill 559 159 230 559 161 230 minecraft:purple_terracotta
fill 559 159 234 559 161 234 minecraft:purple_terracotta
fill 559 159 238 559 161 238 minecraft:purple_terracotta
fill 559 159 242 559 161 242 minecraft:purple_terracotta
fill 559 159 246 559 161 246 minecraft:purple_terracotta
fill 559 159 250 559 161 250 minecraft:purple_terracotta
fill 559 159 254 559 161 254 minecraft:purple_terracotta
fill 559 159 258 559 161 258 minecraft:purple_terracotta
fill 559 159 262 559 161 262 minecraft:purple_terracotta
fill 559 159 266 559 161 266 minecraft:purple_terracotta
fill 559 159 270 559 161 270 minecraft:purple_terracotta
setblock 517 160 228 minecraft:magenta_terracotta
setblock 517 160 232 minecraft:magenta_terracotta
setblock 517 160 236 minecraft:magenta_terracotta
setblock 517 160 244 minecraft:magenta_terracotta
setblock 517 160 248 minecraft:magenta_terracotta
setblock 517 160 252 minecraft:magenta_terracotta
setblock 517 160 256 minecraft:magenta_terracotta
setblock 517 160 260 minecraft:magenta_terracotta
setblock 517 160 264 minecraft:magenta_terracotta
setblock 517 160 268 minecraft:magenta_terracotta
setblock 517 160 270 minecraft:magenta_terracotta
setblock 521 160 228 minecraft:magenta_terracotta
setblock 521 160 270 minecraft:magenta_terracotta
setblock 525 160 228 minecraft:magenta_terracotta
setblock 525 160 270 minecraft:magenta_terracotta
setblock 529 160 228 minecraft:magenta_terracotta
setblock 529 160 270 minecraft:magenta_terracotta
setblock 533 160 228 minecraft:magenta_terracotta
setblock 533 160 270 minecraft:magenta_terracotta
setblock 537 160 228 minecraft:magenta_terracotta
setblock 537 160 270 minecraft:magenta_terracotta
setblock 541 160 228 minecraft:magenta_terracotta
setblock 541 160 270 minecraft:magenta_terracotta
setblock 545 160 228 minecraft:magenta_terracotta
setblock 545 160 270 minecraft:magenta_terracotta
fill 546 160 270 546 206 270 minecraft:purple_terracotta
setblock 549 160 228 minecraft:magenta_terracotta
setblock 549 160 270 minecraft:magenta_terracotta
setblock 553 160 228 minecraft:magenta_terracotta
setblock 553 160 270 minecraft:magenta_terracotta
fill 556 160 268 558 160 269 minecraft:dark_oak_planks
setblock 557 160 228 minecraft:magenta_terracotta
setblock 557 160 267 minecraft:spruce_planks
setblock 557 160 270 minecraft:magenta_terracotta
setblock 559 160 228 minecraft:magenta_terracotta
fill 559 160 231 559 207 231 minecraft:purple_terracotta
setblock 559 160 232 minecraft:magenta_terracotta
setblock 559 160 236 minecraft:magenta_terracotta
setblock 559 160 240 minecraft:magenta_terracotta
setblock 559 160 244 minecraft:magenta_terracotta
setblock 559 160 248 minecraft:magenta_terracotta
setblock 559 160 252 minecraft:magenta_terracotta
setblock 559 160 256 minecraft:magenta_terracotta
setblock 559 160 257 minecraft:light_gray_terracotta
setblock 559 160 260 minecraft:magenta_terracotta
setblock 559 160 264 minecraft:magenta_terracotta
setblock 559 160 268 minecraft:magenta_terracotta
fill 517 161 228 517 163 228 minecraft:purple_terracotta
fill 517 161 232 517 163 232 minecraft:purple_terracotta
fill 517 161 236 517 163 236 minecraft:purple_terracotta
fill 517 161 244 517 163 244 minecraft:purple_terracotta
fill 517 161 248 517 163 248 minecraft:purple_terracotta
fill 517 161 252 517 163 252 minecraft:purple_terracotta
fill 517 161 256 517 163 256 minecraft:purple_terracotta
fill 517 161 260 517 163 260 minecraft:purple_terracotta
fill 517 161 264 517 163 264 minecraft:purple_terracotta
fill 517 161 268 517 163 268 minecraft:purple_terracotta
setblock 517 161 270 minecraft:purple_terracotta
setblock 520 161 231 minecraft:light[level=11]
setblock 520 161 239 minecraft:light[level=11]
setblock 520 161 247 minecraft:light[level=11]
setblock 520 161 255 minecraft:light[level=11]
setblock 520 161 263 minecraft:light[level=11]
fill 521 161 228 521 163 228 minecraft:purple_terracotta
fill 521 161 270 521 163 270 minecraft:purple_terracotta
fill 525 161 228 525 163 228 minecraft:purple_terracotta
fill 525 161 270 525 163 270 minecraft:purple_terracotta
setblock 528 161 231 minecraft:light[level=11]
setblock 528 161 239 minecraft:light[level=11]
setblock 528 161 247 minecraft:light[level=11]
setblock 528 161 255 minecraft:light[level=11]
setblock 528 161 263 minecraft:light[level=11]
fill 529 161 228 529 163 228 minecraft:purple_terracotta
fill 529 161 270 529 163 270 minecraft:purple_terracotta
fill 533 161 228 533 163 228 minecraft:purple_terracotta
fill 533 161 270 533 163 270 minecraft:purple_terracotta
setblock 536 161 231 minecraft:light[level=11]
setblock 536 161 239 minecraft:light[level=11]
setblock 536 161 247 minecraft:light[level=11]
setblock 536 161 255 minecraft:light[level=11]
setblock 536 161 263 minecraft:light[level=11]
fill 537 161 228 537 163 228 minecraft:purple_terracotta
fill 537 161 270 537 163 270 minecraft:purple_terracotta
fill 541 161 228 541 163 228 minecraft:purple_terracotta
fill 541 161 270 541 163 270 minecraft:purple_terracotta
setblock 544 161 231 minecraft:light[level=11]
setblock 544 161 239 minecraft:light[level=11]
setblock 544 161 247 minecraft:light[level=11]
setblock 544 161 255 minecraft:light[level=11]
setblock 544 161 263 minecraft:light[level=11]
fill 545 161 228 545 163 228 minecraft:purple_terracotta
fill 545 161 270 545 163 270 minecraft:purple_terracotta
fill 546 161 250 546 163 251 minecraft:white_stained_glass
fill 547 161 249 547 163 250 minecraft:white_stained_glass
fill 548 161 251 548 163 251 minecraft:white_stained_glass
fill 549 161 228 549 163 228 minecraft:purple_terracotta
fill 549 161 270 549 163 270 minecraft:purple_terracotta
setblock 552 161 231 minecraft:light[level=11]
setblock 552 161 239 minecraft:light[level=11]
setblock 552 161 247 minecraft:light[level=11]
setblock 552 161 255 minecraft:light[level=11]
setblock 552 161 263 minecraft:light[level=11]
fill 553 161 228 553 163 228 minecraft:purple_terracotta
fill 553 161 270 553 163 270 minecraft:purple_terracotta
fill 557 161 228 557 163 228 minecraft:purple_terracotta
fill 557 161 265 557 161 266 minecraft:spruce_planks
fill 557 161 267 558 161 269 minecraft:dark_oak_planks
fill 557 161 270 557 163 270 minecraft:purple_terracotta
setblock 559 161 228 minecraft:purple_terracotta
fill 559 161 232 559 163 232 minecraft:purple_terracotta
fill 559 161 236 559 163 236 minecraft:purple_terracotta
fill 559 161 240 559 163 240 minecraft:purple_terracotta
fill 559 161 244 559 163 244 minecraft:purple_terracotta
fill 559 161 248 559 163 248 minecraft:purple_terracotta
fill 559 161 252 559 163 252 minecraft:purple_terracotta
fill 559 161 256 559 163 257 minecraft:purple_terracotta
fill 559 161 260 559 163 260 minecraft:purple_terracotta
fill 559 161 264 559 163 264 minecraft:purple_terracotta
fill 559 161 268 559 163 268 minecraft:purple_terracotta
setblock 517 162 230 minecraft:magenta_terracotta
setblock 517 162 234 minecraft:magenta_terracotta
setblock 517 162 238 minecraft:magenta_terracotta
fill 517 162 240 517 163 241 minecraft:purple_terracotta
setblock 517 162 242 minecraft:magenta_terracotta
setblock 517 162 246 minecraft:magenta_terracotta
setblock 517 162 250 minecraft:magenta_terracotta
setblock 517 162 254 minecraft:magenta_terracotta
setblock 517 162 258 minecraft:magenta_terracotta
setblock 517 162 262 minecraft:magenta_terracotta
setblock 517 162 266 minecraft:magenta_terracotta
setblock 517 162 270 minecraft:magenta_terracotta
setblock 519 162 228 minecraft:magenta_terracotta
setblock 519 162 270 minecraft:magenta_terracotta
setblock 523 162 228 minecraft:magenta_terracotta
setblock 523 162 270 minecraft:magenta_terracotta
fill 524 162 228 524 207 228 minecraft:purple_terracotta
setblock 527 162 228 minecraft:magenta_terracotta
setblock 527 162 270 minecraft:magenta_terracotta
fill 529 162 231 533 163 235 minecraft:dark_oak_planks
setblock 531 162 228 minecraft:magenta_terracotta
fill 531 162 229 531 162 230 minecraft:dark_oak_planks
setblock 531 162 270 minecraft:magenta_terracotta
setblock 535 162 228 minecraft:magenta_terracotta
setblock 535 162 270 minecraft:magenta_terracotta
setblock 539 162 228 minecraft:magenta_terracotta
setblock 539 162 270 minecraft:magenta_terracotta
setblock 543 162 228 minecraft:magenta_terracotta
setblock 543 162 270 minecraft:magenta_terracotta
fill 546 162 249 546 164 249 minecraft:white_stained_glass
setblock 547 162 228 minecraft:magenta_terracotta
fill 547 162 251 547 163 252 minecraft:white_stained_glass
setblock 547 162 270 minecraft:magenta_terracotta
fill 548 162 249 548 163 250 minecraft:white_stained_glass
setblock 551 162 228 minecraft:magenta_terracotta
setblock 551 162 270 minecraft:magenta_terracotta
setblock 555 162 228 minecraft:magenta_terracotta
setblock 555 162 270 minecraft:magenta_terracotta
fill 557 162 263 557 162 264 minecraft:spruce_planks
fill 557 162 265 558 162 266 minecraft:dark_oak_planks
setblock 559 162 228 minecraft:magenta_terracotta
setblock 559 162 230 minecraft:magenta_terracotta
setblock 559 162 234 minecraft:magenta_terracotta
setblock 559 162 238 minecraft:magenta_terracotta
setblock 559 162 242 minecraft:magenta_terracotta
setblock 559 162 246 minecraft:magenta_terracotta
setblock 559 162 250 minecraft:magenta_terracotta
setblock 559 162 254 minecraft:magenta_terracotta
setblock 559 162 258 minecraft:magenta_terracotta
setblock 559 162 262 minecraft:magenta_terracotta
setblock 559 162 266 minecraft:magenta_terracotta
setblock 559 162 270 minecraft:magenta_terracotta
fill 517 163 230 517 165 230 minecraft:purple_terracotta
fill 517 163 234 517 165 234 minecraft:purple_terracotta
fill 517 163 238 517 165 238 minecraft:purple_terracotta
fill 517 163 242 517 165 242 minecraft:purple_terracotta
fill 517 163 246 517 165 246 minecraft:purple_terracotta
fill 517 163 250 517 165 250 minecraft:purple_terracotta
fill 517 163 254 517 165 254 minecraft:purple_terracotta
fill 517 163 258 517 165 258 minecraft:purple_terracotta
fill 517 163 262 517 165 262 minecraft:purple_terracotta
fill 517 163 266 517 165 266 minecraft:purple_terracotta
setblock 517 163 270 minecraft:purple_terracotta
fill 519 163 228 519 165 228 minecraft:purple_terracotta
fill 519 163 270 519 165 270 minecraft:purple_terracotta
setblock 520 163 231 minecraft:light[level=12]
setblock 520 163 238 minecraft:light[level=12]
setblock 520 163 245 minecraft:light[level=12]
setblock 520 163 252 minecraft:light[level=12]
setblock 520 163 259 minecraft:light[level=12]
setblock 520 163 266 minecraft:light[level=12]
fill 523 163 228 523 165 228 minecraft:purple_terracotta
fill 523 163 270 523 165 270 minecraft:purple_terracotta
fill 527 163 228 527 165 228 minecraft:purple_terracotta
setblock 527 163 231 minecraft:light[level=12]
setblock 527 163 238 minecraft:light[level=12]
setblock 527 163 245 minecraft:light[level=12]
setblock 527 163 252 minecraft:light[level=12]
setblock 527 163 259 minecraft:light[level=12]
setblock 527 163 266 minecraft:light[level=12]
fill 527 163 270 527 165 270 minecraft:purple_terracotta
fill 531 163 228 531 165 228 minecraft:purple_terracotta
fill 531 163 270 531 165 270 minecraft:purple_terracotta
setblock 534 163 231 minecraft:light[level=12]
setblock 534 163 238 minecraft:light[level=12]
setblock 534 163 245 minecraft:light[level=12]
setblock 534 163 252 minecraft:light[level=12]
setblock 534 163 259 minecraft:light[level=12]
setblock 534 163 266 minecraft:light[level=12]
fill 535 163 228 535 165 228 minecraft:purple_terracotta
fill 535 163 270 535 165 270 minecraft:purple_terracotta
fill 539 163 228 539 165 228 minecraft:purple_terracotta
fill 539 163 270 539 165 270 minecraft:purple_terracotta
setblock 541 163 231 minecraft:light[level=12]
setblock 541 163 238 minecraft:light[level=12]
setblock 541 163 245 minecraft:light[level=12]
setblock 541 163 252 minecraft:light[level=12]
setblock 541 163 259 minecraft:light[level=12]
setblock 541 163 266 minecraft:light[level=12]
fill 542 163 239 543 165 241 minecraft:white_stained_glass
fill 543 163 228 543 165 228 minecraft:purple_terracotta
fill 543 163 270 543 165 270 minecraft:purple_terracotta
fill 544 163 240 544 165 240 minecraft:white_stained_glass
fill 545 163 250 545 164 251 minecraft:white_stained_glass
fill 546 163 252 546 164 252 minecraft:white_stained_glass
fill 547 163 228 547 165 228 minecraft:purple_terracotta
fill 547 163 270 547 165 270 minecraft:purple_terracotta
setblock 548 163 231 minecraft:light[level=12]
setblock 548 163 238 minecraft:light[level=12]
setblock 548 163 245 minecraft:light[level=12]
fill 548 163 252 548 164 252 minecraft:white_stained_glass
setblock 548 163 259 minecraft:light[level=12]
setblock 548 163 266 minecraft:light[level=12]
fill 549 163 250 549 164 251 minecraft:white_stained_glass
setblock 551 163 228 minecraft:light_gray_terracotta
fill 551 163 270 551 165 270 minecraft:purple_terracotta
fill 555 163 228 555 165 228 minecraft:purple_terracotta
setblock 555 163 231 minecraft:light[level=12]
setblock 555 163 238 minecraft:light[level=12]
setblock 555 163 245 minecraft:light[level=12]
setblock 555 163 252 minecraft:light[level=12]
setblock 555 163 259 minecraft:light[level=12]
setblock 555 163 266 minecraft:light[level=12]
fill 555 163 270 555 165 270 minecraft:purple_terracotta
fill 557 163 261 557 163 262 minecraft:spruce_planks
fill 557 163 263 558 163 264 minecraft:dark_oak_planks
setblock 559 163 228 minecraft:purple_terracotta
fill 559 163 230 559 165 230 minecraft:purple_terracotta
fill 559 163 234 559 165 234 minecraft:purple_terracotta
fill 559 163 238 559 165 238 minecraft:purple_terracotta
fill 559 163 242 559 165 242 minecraft:purple_terracotta
fill 559 163 246 559 165 246 minecraft:purple_terracotta
fill 559 163 250 559 165 250 minecraft:purple_terracotta
fill 559 163 254 559 165 254 minecraft:purple_terracotta
fill 559 163 258 559 165 258 minecraft:purple_terracotta
fill 559 163 262 559 165 262 minecraft:purple_terracotta
fill 559 163 266 559 165 266 minecraft:purple_terracotta
fill 559 163 270 559 165 270 minecraft:purple_terracotta
setblock 517 164 228 minecraft:magenta_terracotta
setblock 517 164 232 minecraft:magenta_terracotta
setblock 517 164 236 minecraft:magenta_terracotta
setblock 517 164 240 minecraft:magenta_terracotta
fill 517 164 241 517 207 241 minecraft:purple_terracotta
setblock 517 164 244 minecraft:magenta_terracotta
setblock 517 164 248 minecraft:magenta_terracotta
setblock 517 164 252 minecraft:magenta_terracotta
setblock 517 164 256 minecraft:magenta_terracotta
setblock 517 164 260 minecraft:magenta_terracotta
setblock 517 164 264 minecraft:magenta_terracotta
setblock 517 164 268 minecraft:magenta_terracotta
setblock 517 164 270 minecraft:magenta_terracotta
setblock 521 164 228 minecraft:magenta_terracotta
setblock 521 164 270 minecraft:magenta_terracotta
setblock 525 164 228 minecraft:magenta_terracotta
setblock 525 164 270 minecraft:magenta_terracotta
setblock 529 164 228 minecraft:magenta_terracotta
setblock 529 164 270 minecraft:magenta_terracotta
fill 530 164 233 532 169 233 minecraft:purple_concrete
fill 531 164 232 531 169 232 minecraft:purple_concrete
fill 531 164 234 531 169 234 minecraft:purple_concrete
setblock 533 164 228 minecraft:magenta_terracotta
setblock 533 164 270 minecraft:magenta_terracotta
setblock 537 164 228 minecraft:magenta_terracotta
setblock 537 164 270 minecraft:magenta_terracotta
setblock 541 164 228 minecraft:magenta_terracotta
fill 541 164 239 541 166 241 minecraft:white_stained_glass
setblock 541 164 270 minecraft:magenta_terracotta
fill 544 164 239 544 166 239 minecraft:white_stained_glass
fill 544 164 241 544 166 241 minecraft:white_stained_glass
setblock 545 164 228 minecraft:magenta_terracotta
setblock 545 164 270 minecraft:magenta_terracotta
fill 546 164 250 548 166 251 minecraft:white_concrete
setblock 547 164 249 minecraft:black_concrete
setblock 547 164 252 minecraft:white_stained_glass
setblock 548 164 249 minecraft:white_stained_glass
setblock 549 164 228 minecraft:magenta_terracotta
setblock 549 164 270 minecraft:magenta_terracotta
fill 551 164 228 551 165 228 minecraft:purple_terracotta
setblock 553 164 228 minecraft:magenta_terracotta
setblock 553 164 270 minecraft:magenta_terracotta
setblock 557 164 228 minecraft:magenta_terracotta
fill 557 164 259 557 164 260 minecraft:spruce_planks
fill 557 164 261 558 164 262 minecraft:dark_oak_planks
setblock 557 164 270 minecraft:magenta_terracotta
setblock 559 164 228 minecraft:magenta_terracotta
setblock 559 164 232 minecraft:magenta_terracotta
setblock 559 164 236 minecraft:magenta_terracotta
setblock 559 164 240 minecraft:magenta_terracotta
setblock 559 164 244 minecraft:magenta_terracotta
setblock 559 164 248 minecraft:magenta_terracotta
setblock 559 164 252 minecraft:magenta_terracotta
setblock 559 164 256 minecraft:magenta_terracotta
fill 559 164 257 559 188 257 minecraft:purple_terracotta
setblock 559 164 260 minecraft:magenta_terracotta
setblock 559 164 264 minecraft:magenta_terracotta
setblock 559 164 268 minecraft:magenta_terracotta
fill 517 165 228 517 167 228 minecraft:purple_terracotta
fill 517 165 232 517 167 232 minecraft:purple_terracotta
fill 517 165 236 517 167 236 minecraft:purple_terracotta
fill 517 165 240 517 167 240 minecraft:purple_terracotta
fill 517 165 244 517 167 244 minecraft:purple_terracotta
fill 517 165 248 517 167 248 minecraft:purple_terracotta
fill 517 165 252 517 167 252 minecraft:purple_terracotta
fill 517 165 256 517 167 256 minecraft:purple_terracotta
fill 517 165 260 517 167 260 minecraft:purple_terracotta
fill 517 165 264 517 167 264 minecraft:purple_terracotta
fill 517 165 268 517 167 268 minecraft:purple_terracotta
setblock 517 165 270 minecraft:purple_terracotta
fill 521 165 228 521 167 228 minecraft:purple_terracotta
fill 521 165 270 521 167 270 minecraft:purple_terracotta
fill 525 165 228 525 167 228 minecraft:purple_terracotta
fill 525 165 270 525 167 270 minecraft:purple_terracotta
fill 529 165 228 529 167 228 minecraft:purple_terracotta
fill 529 165 270 529 167 270 minecraft:purple_terracotta
fill 533 165 228 533 167 228 minecraft:purple_terracotta
fill 533 165 270 533 167 270 minecraft:purple_terracotta
fill 537 165 228 537 167 228 minecraft:purple_terracotta
fill 537 165 270 537 167 270 minecraft:purple_terracotta
fill 541 165 228 541 167 228 minecraft:purple_terracotta
fill 541 165 270 541 167 270 minecraft:purple_terracotta
fill 542 165 238 543 166 238 minecraft:white_stained_glass
fill 542 165 242 543 166 242 minecraft:white_stained_glass
setblock 542 165 270 minecraft:gray_terracotta
fill 545 165 228 545 167 228 minecraft:purple_terracotta
fill 545 165 270 545 167 270 minecraft:purple_terracotta
setblock 546 165 249 minecraft:black_concrete
fill 547 165 249 547 166 249 minecraft:white_concrete
setblock 547 165 252 minecraft:white_concrete
setblock 548 165 249 minecraft:black_concrete
fill 549 165 228 549 167 228 minecraft:purple_terracotta
fill 549 165 267 549 179 267 minecraft:purple_wool
fill 549 165 270 549 167 270 minecraft:purple_terracotta
fill 553 165 228 553 167 228 minecraft:purple_terracotta
fill 553 165 270 553 167 270 minecraft:purple_terracotta
fill 557 165 228 557 167 228 minecraft:purple_terracotta
fill 557 165 257 557 165 258 minecraft:spruce_planks
fill 557 165 259 558 165 260 minecraft:dark_oak_planks
fill 557 165 270 557 167 270 minecraft:purple_terracotta
setblock 559 165 228 minecraft:purple_terracotta
fill 559 165 232 559 167 232 minecraft:purple_terracotta
fill 559 165 236 559 167 236 minecraft:purple_terracotta
fill 559 165 240 559 167 240 minecraft:purple_terracotta
fill 559 165 244 559 167 244 minecraft:purple_terracotta
fill 559 165 248 559 167 248 minecraft:purple_terracotta
fill 559 165 252 559 167 252 minecraft:purple_terracotta
fill 559 165 256 559 167 256 minecraft:purple_terracotta
fill 559 165 260 559 167 260 minecraft:purple_terracotta
fill 559 165 264 559 167 264 minecraft:purple_terracotta
fill 559 165 268 559 167 268 minecraft:purple_terracotta
setblock 517 166 230 minecraft:magenta_terracotta
setblock 517 166 234 minecraft:magenta_terracotta
setblock 517 166 238 minecraft:magenta_terracotta
setblock 517 166 242 minecraft:magenta_terracotta
setblock 517 166 246 minecraft:magenta_terracotta
setblock 517 166 250 minecraft:magenta_terracotta
setblock 517 166 254 minecraft:magenta_terracotta
setblock 517 166 258 minecraft:magenta_terracotta
setblock 517 166 262 minecraft:magenta_terracotta
setblock 517 166 266 minecraft:magenta_terracotta
setblock 517 166 270 minecraft:magenta_terracotta
setblock 519 166 228 minecraft:magenta_terracotta
setblock 519 166 270 minecraft:magenta_terracotta
setblock 523 166 228 minecraft:magenta_terracotta
setblock 523 166 270 minecraft:magenta_terracotta
setblock 527 166 228 minecraft:magenta_terracotta
setblock 527 166 270 minecraft:magenta_terracotta
setblock 531 166 228 minecraft:magenta_terracotta
setblock 531 166 270 minecraft:magenta_terracotta
setblock 535 166 228 minecraft:magenta_terracotta
setblock 535 166 270 minecraft:magenta_terracotta
setblock 538 166 228 minecraft:light_gray_terracotta
setblock 539 166 228 minecraft:magenta_terracotta
setblock 539 166 270 minecraft:magenta_terracotta
fill 542 166 239 543 166 241 minecraft:white_concrete
fill 542 166 270 542 207 270 minecraft:purple_terracotta
setblock 543 166 228 minecraft:gray_terracotta
setblock 543 166 270 minecraft:magenta_terracotta
fill 544 166 240 544 168 240 minecraft:white_concrete
setblock 547 166 228 minecraft:magenta_terracotta
fill 547 166 267 548 179 267 minecraft:purple_wool
setblock 547 166 270 minecraft:magenta_terracotta
fill 550 166 267 551 179 267 minecraft:purple_wool
setblock 551 166 228 minecraft:magenta_terracotta
setblock 551 166 270 minecraft:magenta_terracotta
setblock 555 166 228 minecraft:magenta_terracotta
setblock 555 166 270 minecraft:magenta_terracotta
fill 557 166 255 557 166 256 minecraft:spruce_planks
fill 557 166 257 558 166 258 minecraft:dark_oak_planks
fill 558 166 244 558 166 248 minecraft:gold_block
setblock 559 166 228 minecraft:magenta_terracotta
setblock 559 166 230 minecraft:magenta_terracotta
setblock 559 166 234 minecraft:magenta_terracotta
setblock 559 166 238 minecraft:magenta_terracotta
setblock 559 166 242 minecraft:magenta_terracotta
setblock 559 166 246 minecraft:magenta_terracotta
setblock 559 166 250 minecraft:magenta_terracotta
setblock 559 166 254 minecraft:magenta_terracotta
setblock 559 166 258 minecraft:magenta_terracotta
setblock 559 166 262 minecraft:magenta_terracotta
setblock 559 166 266 minecraft:magenta_terracotta
setblock 559 166 270 minecraft:magenta_terracotta
fill 517 167 230 517 169 230 minecraft:purple_terracotta
fill 517 167 234 517 169 234 minecraft:purple_terracotta
fill 517 167 238 517 168 238 minecraft:purple_terracotta
fill 517 167 242 517 169 242 minecraft:purple_terracotta
fill 517 167 246 517 169 246 minecraft:purple_terracotta
setblock 517 167 249 minecraft:gray_terracotta
fill 517 167 250 517 169 250 minecraft:purple_terracotta
fill 517 167 254 517 169 254 minecraft:purple_terracotta
fill 517 167 258 517 169 258 minecraft:purple_terracotta
fill 517 167 262 517 169 262 minecraft:purple_terracotta
fill 517 167 266 517 169 266 minecraft:purple_terracotta
setblock 517 167 270 minecraft:purple_terracotta
fill 519 167 228 519 169 228 minecraft:purple_terracotta
fill 519 167 270 519 169 270 minecraft:purple_terracotta
fill 523 167 228 523 169 228 minecraft:purple_terracotta
fill 523 167 270 523 169 270 minecraft:purple_terracotta
fill 527 167 228 527 169 228 minecraft:purple_terracotta
fill 527 167 270 527 169 270 minecraft:purple_terracotta
fill 531 167 228 531 169 228 minecraft:purple_terracotta
fill 531 167 270 531 169 270 minecraft:purple_terracotta
fill 535 167 228 535 169 228 minecraft:purple_terracotta
fill 535 167 270 535 169 270 minecraft:purple_terracotta
fill 538 167 228 539 169 228 minecraft:purple_terracotta
fill 539 167 270 539 169 270 minecraft:purple_terracotta
setblock 541 167 239 minecraft:white_stained_glass
fill 541 167 240 543 167 240 minecraft:white_concrete
setblock 541 167 241 minecraft:white_stained_glass
setblock 542 167 239 minecraft:black_concrete
fill 542 167 241 544 167 241 minecraft:white_concrete
fill 543 167 228 543 169 228 minecraft:purple_terracotta
fill 543 167 239 544 167 239 minecraft:white_concrete
fill 543 167 270 543 169 270 minecraft:purple_terracotta
fill 547 167 228 547 169 228 minecraft:purple_terracotta
fill 547 167 270 547 169 270 minecraft:purple_terracotta
fill 551 167 228 551 169 228 minecraft:purple_terracotta
fill 551 167 270 551 169 270 minecraft:purple_terracotta
fill 555 167 228 555 169 228 minecraft:purple_terracotta
fill 555 167 270 555 169 270 minecraft:purple_terracotta
fill 557 167 253 557 167 254 minecraft:spruce_planks
fill 557 167 255 558 167 256 minecraft:dark_oak_planks
fill 558 167 244 558 172 244 minecraft:gold_block
fill 558 167 245 558 168 247 minecraft:brown_concrete
fill 558 167 248 558 170 248 minecraft:gold_block
setblock 559 167 228 minecraft:purple_terracotta
fill 559 167 230 559 169 230 minecraft:purple_terracotta
fill 559 167 234 559 169 234 minecraft:purple_terracotta
fill 559 167 238 559 169 238 minecraft:purple_terracotta
fill 559 167 242 559 169 242 minecraft:purple_terracotta
fill 559 167 246 559 169 246 minecraft:purple_terracotta
fill 559 167 250 559 169 250 minecraft:purple_terracotta
fill 559 167 254 559 169 254 minecraft:purple_terracotta
fill 559 167 258 559 169 258 minecraft:purple_terracotta
fill 559 167 262 559 169 262 minecraft:purple_terracotta
fill 559 167 266 559 169 266 minecraft:purple_terracotta
fill 559 167 270 559 169 270 minecraft:purple_terracotta
setblock 517 168 228 minecraft:magenta_terracotta
setblock 517 168 232 minecraft:magenta_terracotta
setblock 517 168 236 minecraft:magenta_terracotta
setblock 517 168 240 minecraft:magenta_terracotta
setblock 517 168 244 minecraft:magenta_terracotta
setblock 517 168 248 minecraft:magenta_terracotta
fill 517 168 249 517 207 249 minecraft:purple_terracotta
setblock 517 168 252 minecraft:magenta_terracotta
setblock 517 168 256 minecraft:magenta_terracotta
setblock 517 168 260 minecraft:magenta_terracotta
setblock 517 168 264 minecraft:magenta_terracotta
setblock 517 168 268 minecraft:magenta_terracotta
setblock 517 168 270 minecraft:magenta_terracotta
fill 518 168 239 518 168 243 minecraft:gold_block
setblock 521 168 228 minecraft:magenta_terracotta
setblock 521 168 270 minecraft:magenta_terracotta
setblock 525 168 228 minecraft:magenta_terracotta
setblock 525 168 270 minecraft:magenta_terracotta
setblock 529 168 228 minecraft:magenta_terracotta
setblock 529 168 270 minecraft:magenta_terracotta
setblock 533 168 228 minecraft:magenta_terracotta
setblock 533 168 270 minecraft:magenta_terracotta
setblock 537 168 228 minecraft:magenta_terracotta
setblock 537 168 270 minecraft:magenta_terracotta
setblock 541 168 228 minecraft:magenta_terracotta
setblock 541 168 270 minecraft:magenta_terracotta
fill 542 168 239 543 168 241 minecraft:white_concrete
setblock 545 168 228 minecraft:magenta_terracotta
setblock 545 168 270 minecraft:magenta_terracotta
setblock 549 168 228 minecraft:magenta_terracotta
setblock 549 168 270 minecraft:magenta_terracotta
setblock 553 168 228 minecraft:magenta_terracotta
setblock 553 168 270 minecraft:magenta_terracotta
setblock 557 168 228 minecraft:magenta_terracotta
fill 557 168 251 557 168 252 minecraft:spruce_planks
fill 557 168 253 558 168 254 minecraft:dark_oak_planks
setblock 557 168 270 minecraft:magenta_terracotta
setblock 559 168 228 minecraft:magenta_terracotta
setblock 559 168 232 minecraft:magenta_terracotta
setblock 559 168 236 minecraft:magenta_terracotta
setblock 559 168 240 minecraft:magenta_terracotta
setblock 559 168 244 minecraft:magenta_terracotta
setblock 559 168 248 minecraft:magenta_terracotta
setblock 559 168 252 minecraft:magenta_terracotta
setblock 559 168 256 minecraft:magenta_terracotta
setblock 559 168 260 minecraft:magenta_terracotta
setblock 559 168 264 minecraft:magenta_terracotta
setblock 559 168 268 minecraft:magenta_terracotta
fill 517 169 228 517 171 228 minecraft:purple_terracotta
fill 517 169 232 517 171 232 minecraft:purple_terracotta
fill 517 169 236 517 171 236 minecraft:purple_terracotta
setblock 517 169 238 minecraft:black_terracotta
fill 517 169 240 517 171 240 minecraft:purple_terracotta
fill 517 169 244 517 171 244 minecraft:purple_terracotta
fill 517 169 248 517 171 248 minecraft:purple_terracotta
fill 517 169 252 517 171 252 minecraft:purple_terracotta
fill 517 169 256 517 171 256 minecraft:purple_terracotta
fill 517 169 260 517 171 260 minecraft:purple_terracotta
fill 517 169 264 517 171 264 minecraft:purple_terracotta
fill 517 169 268 517 171 268 minecraft:purple_terracotta
setblock 517 169 270 minecraft:purple_terracotta
fill 518 169 239 518 174 239 minecraft:gold_block
fill 518 169 240 518 170 242 minecraft:black_concrete
fill 518 169 243 518 174 243 minecraft:gold_block
setblock 520 169 231 minecraft:light[level=11]
setblock 520 169 238 minecraft:light[level=12]
setblock 520 169 239 minecraft:light[level=11]
setblock 520 169 245 minecraft:light[level=12]
setblock 520 169 247 minecraft:light[level=11]
setblock 520 169 252 minecraft:light[level=12]
setblock 520 169 255 minecraft:light[level=11]
setblock 520 169 259 minecraft:light[level=12]
setblock 520 169 263 minecraft:light[level=11]
setblock 520 169 266 minecraft:light[level=12]
fill 521 169 228 521 171 228 minecraft:purple_terracotta
fill 521 169 270 521 171 270 minecraft:purple_terracotta
fill 525 169 228 525 171 228 minecraft:purple_terracotta
fill 525 169 270 525 171 270 minecraft:purple_terracotta
setblock 527 169 231 minecraft:light[level=12]
setblock 527 169 238 minecraft:light[level=12]
setblock 527 169 245 minecraft:light[level=12]
setblock 527 169 252 minecraft:light[level=12]
setblock 527 169 259 minecraft:light[level=12]
setblock 527 169 266 minecraft:light[level=12]
setblock 528 169 231 minecraft:light[level=11]
setblock 528 169 239 minecraft:light[level=11]
setblock 528 169 247 minecraft:light[level=11]
setblock 528 169 255 minecraft:light[level=11]
setblock 528 169 263 minecraft:light[level=11]
fill 529 169 228 529 171 228 minecraft:purple_terracotta
fill 529 169 270 529 171 270 minecraft:purple_terracotta
fill 533 169 228 533 171 228 minecraft:purple_terracotta
fill 533 169 270 533 171 270 minecraft:purple_terracotta
setblock 534 169 231 minecraft:light[level=12]
setblock 534 169 238 minecraft:light[level=12]
setblock 534 169 245 minecraft:light[level=12]
setblock 534 169 252 minecraft:light[level=12]
setblock 534 169 259 minecraft:light[level=12]
setblock 534 169 266 minecraft:light[level=12]
setblock 536 169 231 minecraft:light[level=11]
setblock 536 169 239 minecraft:light[level=11]
setblock 536 169 247 minecraft:light[level=11]
setblock 536 169 255 minecraft:light[level=11]
setblock 536 169 263 minecraft:light[level=11]
fill 537 169 228 537 171 228 minecraft:purple_terracotta
fill 537 169 270 537 171 270 minecraft:purple_terracotta
fill 541 169 228 541 171 228 minecraft:purple_terracotta
setblock 541 169 231 minecraft:light[level=12]
setblock 541 169 238 minecraft:light[level=12]
setblock 541 169 245 minecraft:light[level=12]
setblock 541 169 252 minecraft:light[level=12]
setblock 541 169 259 minecraft:light[level=12]
setblock 541 169 266 minecraft:light[level=12]
fill 541 169 270 541 171 270 minecraft:purple_terracotta
setblock 544 169 231 minecraft:light[level=11]
setblock 544 169 239 minecraft:light[level=11]
setblock 544 169 247 minecraft:light[level=11]
setblock 544 169 255 minecraft:light[level=11]
setblock 544 169 263 minecraft:light[level=11]
fill 545 169 228 545 171 228 minecraft:purple_terracotta
fill 545 169 270 545 171 270 minecraft:purple_terracotta
setblock 548 169 231 minecraft:light[level=12]
setblock 548 169 238 minecraft:light[level=12]
setblock 548 169 245 minecraft:light[level=12]
setblock 548 169 252 minecraft:light[level=12]
setblock 548 169 259 minecraft:light[level=12]
setblock 548 169 266 minecraft:light[level=12]
fill 549 169 228 549 171 228 minecraft:purple_terracotta
fill 549 169 270 549 171 270 minecraft:purple_terracotta
setblock 552 169 231 minecraft:light[level=11]
setblock 552 169 239 minecraft:light[level=11]
setblock 552 169 247 minecraft:light[level=11]
setblock 552 169 255 minecraft:light[level=11]
setblock 552 169 263 minecraft:light[level=11]
fill 553 169 228 553 171 228 minecraft:purple_terracotta
fill 553 169 270 553 171 270 minecraft:purple_terracotta
setblock 555 169 231 minecraft:light[level=12]
setblock 555 169 238 minecraft:light[level=12]
setblock 555 169 245 minecraft:light[level=12]
setblock 555 169 252 minecraft:light[level=12]
setblock 555 169 259 minecraft:light[level=12]
setblock 555 169 266 minecraft:light[level=12]
fill 557 169 228 557 171 228 minecraft:purple_terracotta
fill 557 169 249 557 169 250 minecraft:spruce_planks
fill 557 169 251 558 169 252 minecraft:dark_oak_planks
fill 557 169 270 557 171 270 minecraft:purple_terracotta
fill 558 169 245 558 169 247 minecraft:pink_terracotta
setblock 559 169 228 minecraft:purple_terracotta
fill 559 169 232 559 171 232 minecraft:purple_terracotta
fill 559 169 236 559 171 236 minecraft:purple_terracotta
fill 559 169 240 559 171 240 minecraft:purple_terracotta
fill 559 169 244 559 171 244 minecraft:purple_terracotta
fill 559 169 248 559 171 248 minecraft:purple_terracotta
fill 559 169 252 559 171 252 minecraft:purple_terracotta
fill 559 169 256 559 171 256 minecraft:purple_terracotta
fill 559 169 260 559 171 260 minecraft:purple_terracotta
fill 559 169 264 559 171 264 minecraft:purple_terracotta
fill 559 169 268 559 171 268 minecraft:purple_terracotta
setblock 517 170 230 minecraft:magenta_terracotta
setblock 517 170 234 minecraft:magenta_terracotta
setblock 517 170 238 minecraft:magenta_terracotta
setblock 517 170 242 minecraft:magenta_terracotta
setblock 517 170 246 minecraft:magenta_terracotta
setblock 517 170 250 minecraft:magenta_terracotta
setblock 517 170 254 minecraft:magenta_terracotta
setblock 517 170 258 minecraft:magenta_terracotta
setblock 517 170 261 minecraft:light_gray_terracotta
setblock 517 170 262 minecraft:magenta_terracotta
setblock 517 170 266 minecraft:magenta_terracotta
setblock 517 170 270 minecraft:magenta_terracotta
setblock 519 170 228 minecraft:magenta_terracotta
setblock 519 170 270 minecraft:magenta_terracotta
setblock 523 170 228 minecraft:magenta_terracotta
setblock 523 170 270 minecraft:magenta_terracotta
setblock 527 170 228 minecraft:magenta_terracotta
setblock 527 170 270 minecraft:magenta_terracotta
setblock 531 170 228 minecraft:magenta_terracotta
setblock 531 170 270 minecraft:magenta_terracotta
setblock 535 170 228 minecraft:magenta_terracotta
setblock 535 170 270 minecraft:magenta_terracotta
fill 538 170 228 538 207 228 minecraft:purple_terracotta
setblock 539 170 228 minecraft:magenta_terracotta
setblock 539 170 270 minecraft:magenta_terracotta
setblock 543 170 228 minecraft:magenta_terracotta
setblock 543 170 270 minecraft:magenta_terracotta
setblock 547 170 228 minecraft:magenta_terracotta
setblock 547 170 270 minecraft:magenta_terracotta
setblock 551 170 228 minecraft:magenta_terracotta
setblock 551 170 270 minecraft:magenta_terracotta
setblock 555 170 228 minecraft:magenta_terracotta
setblock 555 170 270 minecraft:magenta_terracotta
fill 557 170 247 557 170 248 minecraft:spruce_planks
fill 557 170 249 558 170 250 minecraft:dark_oak_planks
setblock 558 170 245 minecraft:blue_concrete
fill 558 170 246 558 171 246 minecraft:pink_terracotta
setblock 558 170 247 minecraft:blue_concrete
setblock 559 170 228 minecraft:magenta_terracotta
setblock 559 170 230 minecraft:magenta_terracotta
setblock 559 170 234 minecraft:magenta_terracotta
setblock 559 170 238 minecraft:magenta_terracotta
setblock 559 170 242 minecraft:magenta_terracotta
setblock 559 170 246 minecraft:magenta_terracotta
setblock 559 170 250 minecraft:magenta_terracotta
setblock 559 170 254 minecraft:magenta_terracotta
setblock 559 170 258 minecraft:magenta_terracotta
setblock 559 170 262 minecraft:magenta_terracotta
setblock 559 170 266 minecraft:magenta_terracotta
setblock 559 170 270 minecraft:magenta_terracotta
fill 517 171 230 517 173 230 minecraft:purple_terracotta
fill 517 171 234 517 173 234 minecraft:purple_terracotta
fill 517 171 238 517 173 238 minecraft:purple_terracotta
fill 517 171 242 517 173 242 minecraft:purple_terracotta
setblock 517 171 243 minecraft:gray_terracotta
fill 517 171 246 517 173 246 minecraft:purple_terracotta
fill 517 171 250 517 173 250 minecraft:purple_terracotta
fill 517 171 254 517 173 254 minecraft:purple_terracotta
fill 517 171 258 517 173 258 minecraft:purple_terracotta
fill 517 171 261 517 173 262 minecraft:purple_terracotta
fill 517 171 266 517 173 266 minecraft:purple_terracotta
setblock 517 171 270 minecraft:purple_terracotta
fill 518 171 240 518 171 242 minecraft:light_gray_concrete
fill 519 171 228 519 173 228 minecraft:purple_terracotta
fill 519 171 270 519 173 270 minecraft:purple_terracotta
fill 523 171 228 523 173 228 minecraft:purple_terracotta
fill 523 171 270 523 173 270 minecraft:purple_terracotta
fill 527 171 228 527 173 228 minecraft:purple_terracotta
fill 527 171 270 527 173 270 minecraft:purple_terracotta
fill 531 171 228 531 173 228 minecraft:purple_terracotta
fill 531 171 270 531 172 270 minecraft:purple_terracotta
fill 535 171 228 535 173 228 minecraft:purple_terracotta
fill 535 171 270 535 173 270 minecraft:purple_terracotta
fill 539 171 228 539 173 228 minecraft:purple_terracotta
fill 539 171 270 539 173 270 minecraft:purple_terracotta
fill 543 171 228 543 173 228 minecraft:purple_terracotta
fill 543 171 270 543 173 270 minecraft:purple_terracotta
fill 547 171 228 547 173 228 minecraft:purple_terracotta
fill 547 171 270 547 173 270 minecraft:purple_terracotta
fill 551 171 228 551 173 228 minecraft:purple_terracotta
fill 551 171 270 551 173 270 minecraft:purple_terracotta
fill 555 171 228 555 173 228 minecraft:purple_terracotta
fill 555 171 270 555 173 270 minecraft:purple_terracotta
fill 557 171 245 557 171 246 minecraft:spruce_planks
fill 557 171 247 558 171 248 minecraft:dark_oak_planks
setblock 558 171 245 minecraft:pink_terracotta
setblock 559 171 228 minecraft:purple_terracotta
fill 559 171 230 559 173 230 minecraft:purple_terracotta
fill 559 171 234 559 173 234 minecraft:purple_terracotta
fill 559 171 238 559 173 238 minecraft:purple_terracotta
fill 559 171 242 559 173 242 minecraft:purple_terracotta
fill 559 171 246 559 173 246 minecraft:purple_terracotta
fill 559 171 250 559 173 250 minecraft:purple_terracotta
fill 559 171 254 559 173 254 minecraft:purple_terracotta
fill 559 171 258 559 173 258 minecraft:purple_terracotta
fill 559 171 262 559 173 262 minecraft:purple_terracotta
fill 559 171 266 559 173 266 minecraft:purple_terracotta
fill 559 171 270 559 173 270 minecraft:purple_terracotta
setblock 517 172 228 minecraft:magenta_terracotta
setblock 517 172 232 minecraft:magenta_terracotta
setblock 517 172 236 minecraft:magenta_terracotta
setblock 517 172 240 minecraft:magenta_terracotta
fill 517 172 243 517 207 243 minecraft:purple_terracotta
setblock 517 172 244 minecraft:magenta_terracotta
setblock 517 172 248 minecraft:magenta_terracotta
setblock 517 172 252 minecraft:magenta_terracotta
setblock 517 172 256 minecraft:magenta_terracotta
setblock 517 172 260 minecraft:magenta_terracotta
setblock 517 172 264 minecraft:magenta_terracotta
setblock 517 172 268 minecraft:magenta_terracotta
setblock 517 172 270 minecraft:magenta_terracotta
setblock 518 172 240 minecraft:green_concrete
fill 518 172 241 518 173 241 minecraft:light_gray_concrete
setblock 518 172 242 minecraft:green_concrete
setblock 521 172 228 minecraft:magenta_terracotta
setblock 521 172 270 minecraft:magenta_terracotta
setblock 525 172 228 minecraft:magenta_terracotta
setblock 525 172 270 minecraft:magenta_terracotta
setblock 529 172 228 minecraft:magenta_terracotta
setblock 529 172 270 minecraft:magenta_terracotta
setblock 533 172 228 minecraft:magenta_terracotta
setblock 533 172 270 minecraft:magenta_terracotta
setblock 537 172 228 minecraft:magenta_terracotta
setblock 537 172 270 minecraft:magenta_terracotta
setblock 541 172 228 minecraft:magenta_terracotta
setblock 541 172 270 minecraft:magenta_terracotta
setblock 545 172 228 minecraft:magenta_terracotta
setblock 545 172 270 minecraft:magenta_terracotta
setblock 549 172 228 minecraft:magenta_terracotta
setblock 549 172 270 minecraft:magenta_terracotta
setblock 553 172 228 minecraft:magenta_terracotta
setblock 553 172 270 minecraft:magenta_terracotta
setblock 557 172 228 minecraft:magenta_terracotta
fill 557 172 243 557 172 244 minecraft:spruce_planks
fill 557 172 245 558 172 246 minecraft:dark_oak_planks
setblock 557 172 270 minecraft:magenta_terracotta
fill 558 172 247 558 172 248 minecraft:gold_block
setblock 559 172 228 minecraft:magenta_terracotta
setblock 559 172 232 minecraft:magenta_terracotta
setblock 559 172 236 minecraft:magenta_terracotta
setblock 559 172 240 minecraft:magenta_terracotta
setblock 559 172 244 minecraft:magenta_terracotta
setblock 559 172 248 minecraft:magenta_terracotta
setblock 559 172 252 minecraft:magenta_terracotta
setblock 559 172 256 minecraft:magenta_terracotta
setblock 559 172 260 minecraft:magenta_terracotta
setblock 559 172 264 minecraft:magenta_terracotta
setblock 559 172 268 minecraft:magenta_terracotta
fill 517 173 228 517 175 228 minecraft:purple_terracotta
fill 517 173 232 517 175 232 minecraft:purple_terracotta
fill 517 173 236 517 175 236 minecraft:purple_terracotta
fill 517 173 240 517 175 240 minecraft:purple_terracotta
fill 517 173 244 517 175 244 minecraft:purple_terracotta
fill 517 173 248 517 175 248 minecraft:purple_terracotta
fill 517 173 252 517 175 252 minecraft:purple_terracotta
fill 517 173 256 517 175 256 minecraft:purple_terracotta
fill 517 173 260 517 175 260 minecraft:purple_terracotta
fill 517 173 264 517 175 264 minecraft:purple_terracotta
fill 517 173 268 517 175 268 minecraft:purple_terracotta
setblock 517 173 270 minecraft:purple_terracotta
setblock 518 173 240 minecraft:light_gray_concrete
setblock 518 173 242 minecraft:light_gray_concrete
fill 521 173 228 521 175 228 minecraft:purple_terracotta
fill 521 173 270 521 175 270 minecraft:purple_terracotta
fill 525 173 228 525 175 228 minecraft:purple_terracotta
fill 525 173 270 525 175 270 minecraft:purple_terracotta
fill 529 173 228 529 175 228 minecraft:purple_terracotta
fill 529 173 270 529 175 270 minecraft:purple_terracotta
setblock 531 173 270 minecraft:light_gray_terracotta
fill 533 173 228 533 174 228 minecraft:purple_terracotta
fill 533 173 270 533 175 270 minecraft:purple_terracotta
fill 537 173 228 537 175 228 minecraft:purple_terracotta
fill 537 173 270 537 175 270 minecraft:purple_terracotta
fill 541 173 228 541 175 228 minecraft:purple_terracotta
fill 541 173 270 541 175 270 minecraft:purple_terracotta
fill 545 173 228 545 175 228 minecraft:purple_terracotta
fill 545 173 270 545 175 270 minecraft:purple_terracotta
fill 549 173 228 549 175 228 minecraft:purple_terracotta
fill 549 173 270 549 175 270 minecraft:purple_terracotta
setblock 550 173 228 minecraft:black_terracotta
fill 553 173 228 553 175 228 minecraft:purple_terracotta
fill 553 173 270 553 175 270 minecraft:purple_terracotta
fill 557 173 228 557 175 228 minecraft:purple_terracotta
fill 557 173 241 557 173 242 minecraft:spruce_planks
fill 557 173 243 558 173 244 minecraft:dark_oak_planks
fill 557 173 270 557 175 270 minecraft:purple_terracotta
fill 558 173 238 558 173 242 minecraft:gold_block
setblock 559 173 228 minecraft:purple_terracotta
fill 559 173 232 559 175 232 minecraft:purple_terracotta
fill 559 173 236 559 175 236 minecraft:purple_terracotta
fill 559 173 240 559 175 240 minecraft:purple_terracotta
fill 559 173 244 559 175 244 minecraft:purple_terracotta
fill 559 173 248 559 175 248 minecraft:purple_terracotta
fill 559 173 252 559 175 252 minecraft:purple_terracotta
fill 559 173 256 559 175 256 minecraft:purple_terracotta
fill 559 173 260 559 175 260 minecraft:purple_terracotta
fill 559 173 264 559 175 264 minecraft:purple_terracotta
fill 559 173 268 559 175 268 minecraft:purple_terracotta
setblock 517 174 230 minecraft:magenta_terracotta
setblock 517 174 234 minecraft:magenta_terracotta
setblock 517 174 238 minecraft:magenta_terracotta
setblock 517 174 242 minecraft:magenta_terracotta
setblock 517 174 246 minecraft:magenta_terracotta
setblock 517 174 250 minecraft:magenta_terracotta
setblock 517 174 254 minecraft:magenta_terracotta
setblock 517 174 258 minecraft:magenta_terracotta
fill 517 174 261 517 207 261 minecraft:purple_terracotta
setblock 517 174 262 minecraft:magenta_terracotta
setblock 517 174 266 minecraft:magenta_terracotta
setblock 517 174 270 minecraft:magenta_terracotta
fill 518 174 240 518 174 242 minecraft:gold_block
setblock 519 174 228 minecraft:magenta_terracotta
setblock 519 174 270 minecraft:magenta_terracotta
setblock 523 174 228 minecraft:magenta_terracotta
setblock 523 174 270 minecraft:magenta_terracotta
setblock 527 174 228 minecraft:magenta_terracotta
setblock 527 174 270 minecraft:magenta_terracotta
setblock 531 174 228 minecraft:magenta_terracotta
setblock 531 174 233 minecraft:jack_o_lantern
setblock 531 174 270 minecraft:magenta_terracotta
setblock 535 174 228 minecraft:magenta_terracotta
setblock 535 174 270 minecraft:magenta_terracotta
setblock 539 174 228 minecraft:magenta_terracotta
setblock 539 174 270 minecraft:magenta_terracotta
setblock 543 174 228 minecraft:magenta_terracotta
setblock 543 174 270 minecraft:magenta_terracotta
setblock 547 174 228 minecraft:magenta_terracotta
setblock 547 174 270 minecraft:magenta_terracotta
fill 550 174 228 550 207 228 minecraft:purple_terracotta
setblock 551 174 228 minecraft:magenta_terracotta
setblock 551 174 270 minecraft:magenta_terracotta
setblock 555 174 228 minecraft:magenta_terracotta
setblock 555 174 270 minecraft:magenta_terracotta
fill 557 174 239 557 174 240 minecraft:spruce_planks
fill 557 174 241 558 174 242 minecraft:dark_oak_planks
fill 558 174 238 558 175 238 minecraft:gold_block
fill 558 174 239 558 174 240 minecraft:red_terracotta
setblock 559 174 228 minecraft:magenta_terracotta
setblock 559 174 230 minecraft:magenta_terracotta
setblock 559 174 234 minecraft:magenta_terracotta
setblock 559 174 238 minecraft:magenta_terracotta
setblock 559 174 242 minecraft:magenta_terracotta
setblock 559 174 246 minecraft:magenta_terracotta
setblock 559 174 250 minecraft:magenta_terracotta
setblock 559 174 254 minecraft:magenta_terracotta
setblock 559 174 258 minecraft:magenta_terracotta
setblock 559 174 262 minecraft:magenta_terracotta
setblock 559 174 266 minecraft:magenta_terracotta
setblock 559 174 270 minecraft:magenta_terracotta
fill 517 175 230 517 177 230 minecraft:purple_terracotta
fill 517 175 234 517 177 234 minecraft:purple_terracotta
fill 517 175 238 517 177 238 minecraft:purple_terracotta
fill 517 175 242 517 177 242 minecraft:purple_terracotta
fill 517 175 246 517 177 246 minecraft:purple_terracotta
fill 517 175 250 517 177 250 minecraft:purple_terracotta
fill 517 175 254 517 177 254 minecraft:purple_terracotta
fill 517 175 258 517 177 258 minecraft:purple_terracotta
fill 517 175 262 517 177 262 minecraft:purple_terracotta
fill 517 175 266 517 177 266 minecraft:purple_terracotta
setblock 517 175 270 minecraft:purple_terracotta
fill 519 175 228 519 177 228 minecraft:purple_terracotta
fill 519 175 270 519 177 270 minecraft:purple_terracotta
setblock 520 175 231 minecraft:light[level=12]
setblock 520 175 238 minecraft:light[level=12]
setblock 520 175 245 minecraft:light[level=12]
setblock 520 175 252 minecraft:light[level=12]
setblock 520 175 259 minecraft:light[level=12]
setblock 520 175 266 minecraft:light[level=12]
fill 523 175 228 523 177 228 minecraft:purple_terracotta
fill 523 175 270 523 177 270 minecraft:purple_terracotta
fill 527 175 228 527 177 228 minecraft:purple_terracotta
setblock 527 175 231 minecraft:light[level=12]
setblock 527 175 238 minecraft:light[level=12]
fill 527 175 241 528 177 241 minecraft:white_stained_glass
setblock 527 175 245 minecraft:light[level=12]
setblock 527 175 252 minecraft:light[level=12]
setblock 527 175 259 minecraft:light[level=12]
setblock 527 175 266 minecraft:light[level=12]
fill 527 175 270 527 177 270 minecraft:purple_terracotta
fill 528 175 240 528 177 240 minecraft:white_stained_glass
fill 531 175 228 531 177 228 minecraft:purple_terracotta
fill 531 175 270 531 177 270 minecraft:purple_terracotta
setblock 533 175 228 minecraft:gray_terracotta
setblock 534 175 231 minecraft:light[level=12]
setblock 534 175 238 minecraft:light[level=12]
setblock 534 175 245 minecraft:light[level=12]
setblock 534 175 252 minecraft:light[level=12]
setblock 534 175 259 minecraft:light[level=12]
setblock 534 175 266 minecraft:light[level=12]
fill 535 175 228 535 177 228 minecraft:purple_terracotta
fill 535 175 270 535 177 270 minecraft:purple_terracotta
fill 539 175 228 539 177 228 minecraft:purple_terracotta
fill 539 175 270 539 177 270 minecraft:purple_terracotta
setblock 541 175 231 minecraft:light[level=12]
setblock 541 175 238 minecraft:light[level=12]
setblock 541 175 245 minecraft:light[level=12]
setblock 541 175 252 minecraft:light[level=12]
setblock 541 175 259 minecraft:light[level=12]
setblock 541 175 266 minecraft:light[level=12]
fill 543 175 228 543 177 228 minecraft:purple_terracotta
fill 543 175 270 543 177 270 minecraft:purple_terracotta
fill 547 175 228 547 177 228 minecraft:purple_terracotta
fill 547 175 270 547 177 270 minecraft:purple_terracotta
setblock 548 175 231 minecraft:light[level=12]
setblock 548 175 238 minecraft:light[level=12]
setblock 548 175 245 minecraft:light[level=12]
setblock 548 175 252 minecraft:light[level=12]
setblock 548 175 259 minecraft:light[level=12]
setblock 548 175 266 minecraft:light[level=12]
fill 551 175 228 551 177 228 minecraft:purple_terracotta
fill 551 175 270 551 177 270 minecraft:purple_terracotta
fill 555 175 228 555 177 228 minecraft:purple_terracotta
setblock 555 175 231 minecraft:light[level=12]
setblock 555 175 238 minecraft:light[level=12]
setblock 555 175 245 minecraft:light[level=12]
setblock 555 175 252 minecraft:light[level=12]
setblock 555 175 259 minecraft:light[level=12]
setblock 555 175 266 minecraft:light[level=12]
fill 555 175 270 555 177 270 minecraft:purple_terracotta
fill 557 175 237 557 175 238 minecraft:spruce_planks
fill 557 175 239 558 175 240 minecraft:dark_oak_planks
setblock 558 175 241 minecraft:red_terracotta
fill 558 175 242 558 179 242 minecraft:gold_block
setblock 559 175 228 minecraft:purple_terracotta
fill 559 175 230 559 177 230 minecraft:purple_terracotta
fill 559 175 234 559 177 234 minecraft:purple_terracotta
fill 559 175 238 559 177 238 minecraft:purple_terracotta
fill 559 175 242 559 177 242 minecraft:purple_terracotta
fill 559 175 246 559 177 246 minecraft:purple_terracotta
fill 559 175 250 559 177 250 minecraft:purple_terracotta
fill 559 175 254 559 177 254 minecraft:purple_terracotta
fill 559 175 258 559 177 258 minecraft:purple_terracotta
fill 559 175 262 559 177 262 minecraft:purple_terracotta
fill 559 175 266 559 177 266 minecraft:purple_terracotta
fill 559 175 270 559 177 270 minecraft:purple_terracotta
setblock 517 176 228 minecraft:magenta_terracotta
setblock 517 176 232 minecraft:magenta_terracotta
setblock 517 176 236 minecraft:magenta_terracotta
setblock 517 176 240 minecraft:magenta_terracotta
setblock 517 176 244 minecraft:magenta_terracotta
setblock 517 176 248 minecraft:magenta_terracotta
setblock 517 176 252 minecraft:magenta_terracotta
setblock 517 176 253 minecraft:black_terracotta
setblock 517 176 256 minecraft:magenta_terracotta
setblock 517 176 260 minecraft:magenta_terracotta
setblock 517 176 264 minecraft:magenta_terracotta
setblock 517 176 268 minecraft:magenta_terracotta
setblock 517 176 270 minecraft:magenta_terracotta
setblock 521 176 228 minecraft:magenta_terracotta
setblock 521 176 270 minecraft:magenta_terracotta
setblock 525 176 228 minecraft:magenta_terracotta
setblock 525 176 270 minecraft:magenta_terracotta
fill 526 176 240 526 178 241 minecraft:white_stained_glass
fill 527 176 239 527 177 240 minecraft:white_stained_glass
fill 527 176 242 528 178 242 minecraft:white_stained_glass
fill 528 176 239 528 178 239 minecraft:white_stained_glass
setblock 529 176 228 minecraft:magenta_terracotta
fill 529 176 240 529 178 241 minecraft:white_stained_glass
setblock 529 176 270 minecraft:magenta_terracotta
setblock 533 176 228 minecraft:magenta_terracotta
setblock 533 176 270 minecraft:magenta_terracotta
setblock 537 176 228 minecraft:magenta_terracotta
setblock 537 176 270 minecraft:magenta_terracotta
setblock 541 176 228 minecraft:magenta_terracotta
setblock 541 176 270 minecraft:magenta_terracotta
setblock 545 176 228 minecraft:magenta_terracotta
setblock 545 176 270 minecraft:magenta_terracotta
setblock 549 176 228 minecraft:magenta_terracotta
setblock 549 176 270 minecraft:magenta_terracotta
setblock 553 176 228 minecraft:magenta_terracotta
setblock 553 176 270 minecraft:magenta_terracotta
setblock 557 176 228 minecraft:magenta_terracotta
fill 557 176 235 557 176 236 minecraft:spruce_planks
fill 557 176 237 558 176 238 minecraft:dark_oak_planks
setblock 557 176 270 minecraft:magenta_terracotta
fill 558 176 239 558 176 241 minecraft:white_terracotta
setblock 559 176 228 minecraft:magenta_terracotta
setblock 559 176 232 minecraft:magenta_terracotta
setblock 559 176 236 minecraft:magenta_terracotta
setblock 559 176 240 minecraft:magenta_terracotta
setblock 559 176 244 minecraft:magenta_terracotta
setblock 559 176 248 minecraft:magenta_terracotta
setblock 559 176 252 minecraft:magenta_terracotta
setblock 559 176 256 minecraft:magenta_terracotta
setblock 559 176 260 minecraft:magenta_terracotta
setblock 559 176 264 minecraft:magenta_terracotta
setblock 559 176 268 minecraft:magenta_terracotta
fill 517 177 228 517 179 228 minecraft:purple_terracotta
fill 517 177 232 517 179 232 minecraft:purple_terracotta
fill 517 177 236 517 179 236 minecraft:purple_terracotta
fill 517 177 240 517 179 240 minecraft:purple_terracotta
fill 517 177 244 517 179 244 minecraft:purple_terracotta
fill 517 177 248 517 179 248 minecraft:purple_terracotta
fill 517 177 252 517 179 253 minecraft:purple_terracotta
setblock 517 177 256 minecraft:gray_terracotta
fill 517 177 260 517 179 260 minecraft:purple_terracotta
fill 517 177 264 517 179 264 minecraft:purple_terracotta
fill 517 177 268 517 179 268 minecraft:purple_terracotta
setblock 517 177 270 minecraft:purple_terracotta
setblock 520 177 231 minecraft:light[level=11]
setblock 520 177 239 minecraft:light[level=11]
setblock 520 177 247 minecraft:light[level=11]
setblock 520 177 255 minecraft:light[level=11]
setblock 520 177 263 minecraft:light[level=11]
fill 521 177 228 521 179 228 minecraft:purple_terracotta
fill 521 177 270 521 179 270 minecraft:purple_terracotta
setblock 525 177 228 minecraft:light_gray_terracotta
fill 525 177 270 525 179 270 minecraft:purple_terracotta
fill 526 177 242 526 178 242 minecraft:white_stained_glass
setblock 528 177 231 minecraft:light[level=11]
setblock 528 177 247 minecraft:light[level=11]
setblock 528 177 255 minecraft:light[level=11]
setblock 528 177 263 minecraft:light[level=11]
fill 529 177 228 529 179 228 minecraft:purple_terracotta
fill 529 177 239 529 178 239 minecraft:white_stained_glass
fill 529 177 242 529 178 242 minecraft:white_stained_glass
fill 529 177 270 529 179 270 minecraft:purple_terracotta
fill 533 177 228 533 179 228 minecraft:purple_terracotta
fill 533 177 270 533 179 270 minecraft:purple_terracotta
setblock 536 177 231 minecraft:light[level=11]
setblock 536 177 239 minecraft:light[level=11]
setblock 536 177 247 minecraft:light[level=11]
setblock 536 177 255 minecraft:light[level=11]
setblock 536 177 263 minecraft:light[level=11]
fill 537 177 228 537 179 228 minecraft:purple_terracotta
fill 537 177 270 537 179 270 minecraft:purple_terracotta
fill 541 177 228 541 179 228 minecraft:purple_terracotta
fill 541 177 270 541 179 270 minecraft:purple_terracotta
setblock 544 177 231 minecraft:light[level=11]
setblock 544 177 239 minecraft:light[level=11]
setblock 544 177 247 minecraft:light[level=11]
setblock 544 177 255 minecraft:light[level=11]
setblock 544 177 263 minecraft:light[level=11]
fill 545 177 228 545 179 228 minecraft:purple_terracotta
fill 545 177 270 545 179 270 minecraft:purple_terracotta
fill 549 177 228 549 179 228 minecraft:purple_terracotta
fill 549 177 270 549 179 270 minecraft:purple_terracotta
setblock 552 177 231 minecraft:light[level=11]
setblock 552 177 239 minecraft:light[level=11]
setblock 552 177 247 minecraft:light[level=11]
setblock 552 177 255 minecraft:light[level=11]
setblock 552 177 263 minecraft:light[level=11]
fill 553 177 228 553 179 228 minecraft:purple_terracotta
setblock 553 177 270 minecraft:light_gray_terracotta
fill 557 177 228 557 179 228 minecraft:purple_terracotta
fill 557 177 233 557 177 234 minecraft:spruce_planks
fill 557 177 235 558 177 236 minecraft:dark_oak_planks
fill 557 177 270 557 179 270 minecraft:purple_terracotta
fill 558 177 238 558 179 238 minecraft:gold_block
setblock 558 177 239 minecraft:black_concrete
fill 558 177 240 558 178 240 minecraft:white_terracotta
setblock 558 177 241 minecraft:black_concrete
setblock 559 177 228 minecraft:purple_terracotta
fill 559 177 232 559 179 232 minecraft:purple_terracotta
fill 559 177 236 559 179 236 minecraft:purple_terracotta
fill 559 177 240 559 179 240 minecraft:purple_terracotta
fill 559 177 244 559 179 244 minecraft:purple_terracotta
fill 559 177 248 559 179 248 minecraft:purple_terracotta
fill 559 177 252 559 179 252 minecraft:purple_terracotta
fill 559 177 256 559 179 256 minecraft:purple_terracotta
fill 559 177 260 559 179 260 minecraft:purple_terracotta
fill 559 177 264 559 179 264 minecraft:purple_terracotta
fill 559 177 268 559 179 268 minecraft:purple_terracotta
setblock 517 178 230 minecraft:magenta_terracotta
setblock 517 178 234 minecraft:magenta_terracotta
setblock 517 178 238 minecraft:magenta_terracotta
setblock 517 178 242 minecraft:magenta_terracotta
setblock 517 178 246 minecraft:magenta_terracotta
setblock 517 178 250 minecraft:magenta_terracotta
setblock 517 178 254 minecraft:magenta_terracotta
fill 517 178 256 517 179 256 minecraft:purple_terracotta
setblock 517 178 258 minecraft:magenta_terracotta
setblock 517 178 262 minecraft:magenta_terracotta
setblock 517 178 266 minecraft:magenta_terracotta
setblock 517 178 270 minecraft:magenta_terracotta
setblock 519 178 228 minecraft:magenta_terracotta
setblock 519 178 270 minecraft:magenta_terracotta
setblock 523 178 228 minecraft:magenta_terracotta
setblock 523 178 270 minecraft:magenta_terracotta
fill 525 178 228 525 179 228 minecraft:purple_terracotta
setblock 527 178 228 minecraft:magenta_terracotta
setblock 527 178 239 minecraft:white_stained_glass
fill 527 178 240 528 180 241 minecraft:white_concrete
setblock 527 178 270 minecraft:magenta_terracotta
setblock 531 178 228 minecraft:magenta_terracotta
setblock 531 178 270 minecraft:magenta_terracotta
setblock 535 178 228 minecraft:magenta_terracotta
setblock 535 178 270 minecraft:magenta_terracotta
setblock 539 178 228 minecraft:magenta_terracotta
setblock 539 178 270 minecraft:magenta_terracotta
setblock 543 178 228 minecraft:magenta_terracotta
setblock 543 178 270 minecraft:magenta_terracotta
setblock 547 178 228 minecraft:magenta_terracotta
setblock 547 178 270 minecraft:magenta_terracotta
setblock 551 178 228 minecraft:magenta_terracotta
setblock 551 178 270 minecraft:magenta_terracotta
fill 553 178 270 553 179 270 minecraft:purple_terracotta
setblock 555 178 228 minecraft:magenta_terracotta
setblock 555 178 270 minecraft:magenta_terracotta
fill 557 178 231 557 178 232 minecraft:spruce_planks
fill 557 178 233 558 178 234 minecraft:dark_oak_planks
setblock 558 178 239 minecraft:white_terracotta
setblock 558 178 241 minecraft:white_terracotta
setblock 559 178 228 minecraft:magenta_terracotta
setblock 559 178 230 minecraft:magenta_terracotta
setblock 559 178 234 minecraft:magenta_terracotta
setblock 559 178 238 minecraft:magenta_terracotta
setblock 559 178 242 minecraft:magenta_terracotta
setblock 559 178 246 minecraft:magenta_terracotta
setblock 559 178 250 minecraft:magenta_terracotta
setblock 559 178 254 minecraft:magenta_terracotta
setblock 559 178 258 minecraft:magenta_terracotta
setblock 559 178 262 minecraft:magenta_terracotta
setblock 559 178 266 minecraft:magenta_terracotta
setblock 559 178 270 minecraft:magenta_terracotta
setblock 517 179 230 minecraft:light_gray_terracotta
fill 517 179 234 517 181 234 minecraft:purple_terracotta
fill 517 179 238 517 181 238 minecraft:purple_terracotta
fill 517 179 242 517 181 242 minecraft:purple_terracotta
fill 517 179 246 517 181 246 minecraft:purple_terracotta
fill 517 179 250 517 181 250 minecraft:purple_terracotta
fill 517 179 254 517 181 254 minecraft:purple_terracotta
fill 517 179 258 517 181 258 minecraft:purple_terracotta
fill 517 179 262 517 181 262 minecraft:purple_terracotta
fill 517 179 266 517 181 266 minecraft:purple_terracotta
setblock 517 179 270 minecraft:purple_terracotta
fill 519 179 228 519 181 228 minecraft:purple_terracotta
fill 519 179 270 519 181 270 minecraft:purple_terracotta
fill 523 179 228 523 181 228 minecraft:purple_terracotta
fill 523 179 270 523 181 270 minecraft:purple_terracotta
fill 526 179 240 526 179 241 minecraft:white_concrete
fill 527 179 228 527 181 228 minecraft:purple_terracotta
fill 527 179 239 528 179 239 minecraft:black_concrete
fill 527 179 242 528 179 242 minecraft:white_concrete
fill 527 179 270 527 181 270 minecraft:purple_terracotta
fill 529 179 240 529 179 241 minecraft:white_concrete
fill 531 179 228 531 181 228 minecraft:purple_terracotta
fill 531 179 270 531 181 270 minecraft:purple_terracotta
fill 535 179 228 535 181 228 minecraft:purple_terracotta
fill 535 179 270 535 181 270 minecraft:purple_terracotta
fill 539 179 228 539 181 228 minecraft:purple_terracotta
fill 539 179 270 539 181 270 minecraft:purple_terracotta
fill 543 179 228 543 181 228 minecraft:purple_terracotta
fill 543 179 270 543 181 270 minecraft:purple_terracotta
fill 547 179 228 547 181 228 minecraft:purple_terracotta
fill 547 179 270 547 181 270 minecraft:purple_terracotta
fill 551 179 228 551 181 228 minecraft:purple_terracotta
setblock 551 179 270 minecraft:purple_terracotta
fill 555 179 228 555 181 228 minecraft:purple_terracotta
fill 555 179 270 555 181 270 minecraft:purple_terracotta
setblock 557 179 230 minecraft:spruce_planks
fill 557 179 231 558 179 232 minecraft:dark_oak_planks
fill 558 179 239 558 179 241 minecraft:gold_block
setblock 559 179 228 minecraft:purple_terracotta
fill 559 179 230 559 181 230 minecraft:purple_terracotta
fill 559 179 234 559 181 234 minecraft:purple_terracotta
fill 559 179 238 559 181 238 minecraft:purple_terracotta
fill 559 179 242 559 181 242 minecraft:purple_terracotta
fill 559 179 246 559 181 246 minecraft:purple_terracotta
fill 559 179 250 559 181 250 minecraft:purple_terracotta
fill 559 179 254 559 181 254 minecraft:purple_terracotta
fill 559 179 258 559 181 258 minecraft:purple_terracotta
fill 559 179 262 559 181 262 minecraft:purple_terracotta
fill 559 179 266 559 181 266 minecraft:purple_terracotta
fill 559 179 270 559 181 270 minecraft:purple_terracotta
setblock 517 180 228 minecraft:magenta_terracotta
fill 517 180 230 517 181 230 minecraft:purple_terracotta
setblock 517 180 232 minecraft:magenta_terracotta
setblock 517 180 236 minecraft:magenta_terracotta
setblock 517 180 240 minecraft:magenta_terracotta
setblock 517 180 244 minecraft:magenta_terracotta
setblock 517 180 248 minecraft:magenta_terracotta
setblock 517 180 252 minecraft:magenta_terracotta
fill 517 180 253 517 207 253 minecraft:purple_terracotta
setblock 517 180 256 minecraft:magenta_terracotta
setblock 517 180 260 minecraft:magenta_terracotta
setblock 517 180 264 minecraft:magenta_terracotta
setblock 517 180 268 minecraft:magenta_terracotta
setblock 517 180 270 minecraft:magenta_terracotta
setblock 521 180 228 minecraft:magenta_terracotta
setblock 521 180 270 minecraft:magenta_terracotta
setblock 525 180 228 minecraft:magenta_terracotta
setblock 525 180 270 minecraft:magenta_terracotta
setblock 529 180 228 minecraft:magenta_terracotta
setblock 529 180 270 minecraft:magenta_terracotta
setblock 533 180 228 minecraft:magenta_terracotta
setblock 533 180 270 minecraft:magenta_terracotta
setblock 537 180 228 minecraft:magenta_terracotta
setblock 537 180 270 minecraft:magenta_terracotta
setblock 541 180 228 minecraft:magenta_terracotta
setblock 541 180 270 minecraft:magenta_terracotta
setblock 545 180 228 minecraft:magenta_terracotta
setblock 545 180 270 minecraft:magenta_terracotta
fill 546 180 267 552 181 267 minecraft:iron_bars
setblock 549 180 228 minecraft:magenta_terracotta
setblock 549 180 270 minecraft:magenta_terracotta
setblock 551 180 270 minecraft:gray_terracotta
setblock 553 180 228 minecraft:magenta_terracotta
setblock 553 180 270 minecraft:magenta_terracotta
fill 555 180 230 556 180 230 minecraft:spruce_planks
setblock 557 180 228 minecraft:magenta_terracotta
fill 557 180 229 558 180 230 minecraft:dark_oak_planks
setblock 557 180 270 minecraft:magenta_terracotta
setblock 559 180 228 minecraft:magenta_terracotta
setblock 559 180 232 minecraft:magenta_terracotta
setblock 559 180 236 minecraft:magenta_terracotta
setblock 559 180 240 minecraft:magenta_terracotta
setblock 559 180 244 minecraft:magenta_terracotta
setblock 559 180 248 minecraft:magenta_terracotta
setblock 559 180 252 minecraft:magenta_terracotta
setblock 559 180 256 minecraft:magenta_terracotta
setblock 559 180 260 minecraft:magenta_terracotta
setblock 559 180 264 minecraft:magenta_terracotta
setblock 559 180 268 minecraft:magenta_terracotta
fill 517 181 228 517 183 228 minecraft:purple_terracotta
fill 517 181 232 517 183 232 minecraft:purple_terracotta
fill 517 181 236 517 183 236 minecraft:purple_terracotta
fill 517 181 240 517 183 240 minecraft:purple_terracotta
fill 517 181 244 517 183 244 minecraft:purple_terracotta
fill 517 181 248 517 183 248 minecraft:purple_terracotta
fill 517 181 252 517 183 252 minecraft:purple_terracotta
fill 517 181 256 517 183 256 minecraft:purple_terracotta
fill 517 181 260 517 183 260 minecraft:purple_terracotta
fill 517 181 264 517 183 264 minecraft:purple_terracotta
fill 517 181 268 517 183 268 minecraft:purple_terracotta
setblock 517 181 270 minecraft:purple_terracotta
setblock 520 181 231 minecraft:light[level=12]
setblock 520 181 238 minecraft:light[level=12]
setblock 520 181 245 minecraft:light[level=12]
setblock 520 181 252 minecraft:light[level=12]
setblock 520 181 259 minecraft:light[level=12]
setblock 520 181 266 minecraft:light[level=12]
fill 521 181 228 521 183 228 minecraft:purple_terracotta
fill 521 181 270 521 183 270 minecraft:purple_terracotta
fill 525 181 228 525 183 228 minecraft:purple_terracotta
fill 525 181 270 525 183 270 minecraft:purple_terracotta
setblock 527 181 231 minecraft:light[level=12]
setblock 527 181 238 minecraft:light[level=12]
setblock 527 181 245 minecraft:light[level=12]
setblock 527 181 252 minecraft:light[level=12]
setblock 527 181 259 minecraft:light[level=12]
setblock 527 181 266 minecraft:light[level=12]
fill 529 181 228 529 183 228 minecraft:purple_terracotta
fill 529 181 270 529 183 270 minecraft:purple_terracotta
fill 533 181 228 533 183 228 minecraft:purple_terracotta
fill 533 181 270 533 183 270 minecraft:purple_terracotta
setblock 534 181 228 minecraft:gray_terracotta
setblock 534 181 231 minecraft:light[level=12]
setblock 534 181 238 minecraft:light[level=12]
setblock 534 181 245 minecraft:light[level=12]
setblock 534 181 252 minecraft:light[level=12]
setblock 534 181 259 minecraft:light[level=12]
setblock 534 181 266 minecraft:light[level=12]
fill 537 181 228 537 183 228 minecraft:purple_terracotta
fill 537 181 270 537 183 270 minecraft:purple_terracotta
fill 541 181 228 541 183 228 minecraft:purple_terracotta
setblock 541 181 231 minecraft:light[level=12]
setblock 541 181 238 minecraft:light[level=12]
setblock 541 181 245 minecraft:light[level=12]
setblock 541 181 252 minecraft:light[level=12]
setblock 541 181 259 minecraft:light[level=12]
setblock 541 181 266 minecraft:light[level=12]
fill 541 181 270 541 183 270 minecraft:purple_terracotta
fill 545 181 228 545 183 228 minecraft:purple_terracotta
fill 545 181 270 545 183 270 minecraft:purple_terracotta
setblock 548 181 231 minecraft:light[level=12]
setblock 548 181 238 minecraft:light[level=12]
setblock 548 181 245 minecraft:light[level=12]
setblock 548 181 252 minecraft:light[level=12]
setblock 548 181 259 minecraft:light[level=12]
setblock 548 181 266 minecraft:light[level=12]
fill 549 181 228 549 183 228 minecraft:purple_terracotta
fill 549 181 270 549 183 270 minecraft:purple_terracotta
setblock 551 181 270 minecraft:purple_terracotta
fill 553 181 228 553 183 228 minecraft:purple_terracotta
fill 553 181 230 554 181 230 minecraft:spruce_planks
fill 553 181 270 553 183 270 minecraft:purple_terracotta
fill 555 181 229 556 181 230 minecraft:dark_oak_planks
setblock 555 181 231 minecraft:light[level=12]
setblock 555 181 238 minecraft:light[level=12]
setblock 555 181 245 minecraft:light[level=12]
setblock 555 181 252 minecraft:light[level=12]
setblock 555 181 259 minecraft:light[level=12]
setblock 555 181 266 minecraft:light[level=12]
fill 557 181 228 557 183 228 minecraft:purple_terracotta
fill 557 181 270 557 183 270 minecraft:purple_terracotta
setblock 559 181 228 minecraft:purple_terracotta
fill 559 181 232 559 183 232 minecraft:purple_terracotta
fill 559 181 236 559 183 236 minecraft:purple_terracotta
fill 559 181 240 559 183 240 minecraft:purple_terracotta
fill 559 181 244 559 183 244 minecraft:purple_terracotta
fill 559 181 248 559 183 248 minecraft:purple_terracotta
fill 559 181 252 559 183 252 minecraft:purple_terracotta
fill 559 181 256 559 183 256 minecraft:purple_terracotta
fill 559 181 260 559 183 260 minecraft:purple_terracotta
fill 559 181 264 559 183 264 minecraft:purple_terracotta
fill 559 181 268 559 183 268 minecraft:purple_terracotta
setblock 517 182 230 minecraft:magenta_terracotta
setblock 517 182 234 minecraft:magenta_terracotta
setblock 517 182 238 minecraft:magenta_terracotta
setblock 517 182 242 minecraft:magenta_terracotta
setblock 517 182 246 minecraft:magenta_terracotta
setblock 517 182 250 minecraft:magenta_terracotta
setblock 517 182 254 minecraft:magenta_terracotta
setblock 517 182 258 minecraft:magenta_terracotta
setblock 517 182 262 minecraft:magenta_terracotta
setblock 517 182 266 minecraft:magenta_terracotta
setblock 517 182 270 minecraft:magenta_terracotta
setblock 519 182 228 minecraft:magenta_terracotta
setblock 519 182 270 minecraft:magenta_terracotta
setblock 523 182 228 minecraft:magenta_terracotta
setblock 523 182 270 minecraft:magenta_terracotta
setblock 527 182 228 minecraft:magenta_terracotta
setblock 527 182 270 minecraft:magenta_terracotta
setblock 531 182 228 minecraft:magenta_terracotta
setblock 531 182 270 minecraft:magenta_terracotta
fill 534 182 228 534 207 228 minecraft:purple_terracotta
setblock 535 182 228 minecraft:magenta_terracotta
setblock 535 182 270 minecraft:magenta_terracotta
setblock 539 182 228 minecraft:magenta_terracotta
setblock 539 182 270 minecraft:magenta_terracotta
setblock 543 182 228 minecraft:magenta_terracotta
setblock 543 182 270 minecraft:magenta_terracotta
setblock 547 182 228 minecraft:magenta_terracotta
setblock 547 182 270 minecraft:magenta_terracotta
setblock 551 182 228 minecraft:magenta_terracotta
fill 551 182 230 552 182 230 minecraft:spruce_planks
setblock 551 182 270 minecraft:magenta_terracotta
fill 553 182 229 554 182 230 minecraft:dark_oak_planks
setblock 555 182 228 minecraft:magenta_terracotta
setblock 555 182 270 minecraft:magenta_terracotta
setblock 559 182 228 minecraft:magenta_terracotta
setblock 559 182 230 minecraft:magenta_terracotta
setblock 559 182 234 minecraft:magenta_terracotta
setblock 559 182 238 minecraft:magenta_terracotta
setblock 559 182 242 minecraft:magenta_terracotta
setblock 559 182 246 minecraft:magenta_terracotta
setblock 559 182 250 minecraft:magenta_terracotta
setblock 559 182 254 minecraft:magenta_terracotta
setblock 559 182 258 minecraft:magenta_terracotta
setblock 559 182 262 minecraft:magenta_terracotta
setblock 559 182 266 minecraft:magenta_terracotta
setblock 559 182 270 minecraft:magenta_terracotta
fill 517 183 230 517 185 230 minecraft:purple_terracotta
fill 517 183 234 517 185 234 minecraft:purple_terracotta
fill 517 183 238 517 185 238 minecraft:purple_terracotta
fill 517 183 242 517 185 242 minecraft:purple_terracotta
fill 517 183 246 517 185 246 minecraft:purple_terracotta
fill 517 183 250 517 185 250 minecraft:purple_terracotta
fill 517 183 254 517 185 254 minecraft:purple_terracotta
fill 517 183 258 517 185 258 minecraft:purple_terracotta
fill 517 183 262 517 185 262 minecraft:purple_terracotta
fill 517 183 266 517 185 266 minecraft:purple_terracotta
setblock 517 183 270 minecraft:purple_terracotta
fill 519 183 228 519 185 228 minecraft:purple_terracotta
fill 519 183 270 519 185 270 minecraft:purple_terracotta
fill 523 183 228 523 185 228 minecraft:purple_terracotta
fill 523 183 270 523 184 270 minecraft:purple_terracotta
fill 527 183 228 527 185 228 minecraft:purple_terracotta
fill 527 183 270 527 185 270 minecraft:purple_terracotta
fill 531 183 228 531 185 228 minecraft:purple_terracotta
fill 531 183 270 531 185 270 minecraft:purple_terracotta
fill 535 183 228 535 185 228 minecraft:purple_terracotta
fill 535 183 270 535 185 270 minecraft:purple_terracotta
fill 539 183 228 539 185 228 minecraft:purple_terracotta
fill 539 183 270 539 185 270 minecraft:purple_terracotta
fill 543 183 228 543 185 228 minecraft:purple_terracotta
fill 543 183 270 543 185 270 minecraft:purple_terracotta
fill 547 183 228 547 185 228 minecraft:purple_terracotta
fill 547 183 270 547 185 270 minecraft:purple_terracotta
fill 549 183 230 550 183 230 minecraft:spruce_planks
fill 551 183 228 551 185 228 minecraft:purple_terracotta
fill 551 183 229 552 183 230 minecraft:dark_oak_planks
fill 551 183 270 551 185 270 minecraft:purple_terracotta
fill 555 183 228 555 185 228 minecraft:purple_terracotta
fill 555 183 270 555 185 270 minecraft:purple_terracotta
setblock 559 183 228 minecraft:purple_terracotta
fill 559 183 230 559 185 230 minecraft:purple_terracotta
fill 559 183 234 559 184 234 minecraft:purple_terracotta
fill 559 183 238 559 185 238 minecraft:purple_terracotta
fill 559 183 242 559 185 242 minecraft:purple_terracotta
fill 559 183 246 559 185 246 minecraft:purple_terracotta
fill 559 183 250 559 185 250 minecraft:purple_terracotta
fill 559 183 254 559 185 254 minecraft:purple_terracotta
fill 559 183 258 559 185 258 minecraft:purple_terracotta
fill 559 183 262 559 185 262 minecraft:purple_terracotta
fill 559 183 266 559 185 266 minecraft:purple_terracotta
fill 559 183 270 559 185 270 minecraft:purple_terracotta
setblock 517 184 228 minecraft:magenta_terracotta
setblock 517 184 232 minecraft:magenta_terracotta
setblock 517 184 236 minecraft:magenta_terracotta
setblock 517 184 240 minecraft:magenta_terracotta
setblock 517 184 244 minecraft:magenta_terracotta
setblock 517 184 248 minecraft:magenta_terracotta
setblock 517 184 252 minecraft:magenta_terracotta
setblock 517 184 256 minecraft:magenta_terracotta
setblock 517 184 260 minecraft:magenta_terracotta
setblock 517 184 264 minecraft:magenta_terracotta
setblock 517 184 268 minecraft:magenta_terracotta
setblock 517 184 270 minecraft:magenta_terracotta
setblock 521 184 228 minecraft:magenta_terracotta
setblock 521 184 270 minecraft:magenta_terracotta
setblock 525 184 228 minecraft:magenta_terracotta
setblock 525 184 270 minecraft:magenta_terracotta
setblock 529 184 228 minecraft:magenta_terracotta
setblock 529 184 270 minecraft:magenta_terracotta
setblock 533 184 228 minecraft:magenta_terracotta
setblock 533 184 270 minecraft:magenta_terracotta
setblock 537 184 228 minecraft:magenta_terracotta
setblock 537 184 270 minecraft:magenta_terracotta
setblock 541 184 228 minecraft:magenta_terracotta
setblock 541 184 270 minecraft:magenta_terracotta
setblock 545 184 228 minecraft:magenta_terracotta
setblock 545 184 270 minecraft:magenta_terracotta
fill 547 184 230 548 184 230 minecraft:spruce_planks
setblock 549 184 228 minecraft:magenta_terracotta
fill 549 184 229 550 184 230 minecraft:dark_oak_planks
setblock 549 184 270 minecraft:magenta_terracotta
setblock 553 184 228 minecraft:magenta_terracotta
setblock 553 184 270 minecraft:magenta_terracotta
setblock 557 184 228 minecraft:magenta_terracotta
setblock 557 184 270 minecraft:magenta_terracotta
setblock 559 184 228 minecraft:magenta_terracotta
setblock 559 184 232 minecraft:magenta_terracotta
setblock 559 184 236 minecraft:magenta_terracotta
setblock 559 184 240 minecraft:magenta_terracotta
setblock 559 184 244 minecraft:magenta_terracotta
setblock 559 184 248 minecraft:magenta_terracotta
setblock 559 184 252 minecraft:magenta_terracotta
setblock 559 184 256 minecraft:magenta_terracotta
setblock 559 184 260 minecraft:magenta_terracotta
setblock 559 184 264 minecraft:magenta_terracotta
setblock 559 184 268 minecraft:magenta_terracotta
fill 517 185 228 517 187 228 minecraft:purple_terracotta
fill 517 185 232 517 187 232 minecraft:purple_terracotta
fill 517 185 236 517 187 236 minecraft:purple_terracotta
fill 517 185 240 517 187 240 minecraft:purple_terracotta
fill 517 185 244 517 187 244 minecraft:purple_terracotta
fill 517 185 248 517 187 248 minecraft:purple_terracotta
fill 517 185 252 517 187 252 minecraft:purple_terracotta
fill 517 185 256 517 187 256 minecraft:purple_terracotta
fill 517 185 260 517 187 260 minecraft:purple_terracotta
fill 517 185 264 517 187 264 minecraft:purple_terracotta
fill 517 185 268 517 187 268 minecraft:purple_terracotta
setblock 517 185 270 minecraft:purple_terracotta
setblock 520 185 231 minecraft:light[level=11]
setblock 520 185 239 minecraft:light[level=11]
setblock 520 185 247 minecraft:light[level=11]
setblock 520 185 255 minecraft:light[level=11]
setblock 520 185 263 minecraft:light[level=11]
fill 521 185 228 521 187 228 minecraft:purple_terracotta
fill 521 185 270 521 187 270 minecraft:purple_terracotta
setblock 523 185 270 minecraft:gray_terracotta
fill 525 185 228 525 187 228 minecraft:purple_terracotta
fill 525 185 270 525 187 270 minecraft:purple_terracotta
setblock 528 185 231 minecraft:light[level=11]
setblock 528 185 239 minecraft:light[level=11]
setblock 528 185 247 minecraft:light[level=11]
setblock 528 185 255 minecraft:light[level=11]
setblock 528 185 263 minecraft:light[level=11]
fill 529 185 228 529 187 228 minecraft:purple_terracotta
fill 529 185 270 529 187 270 minecraft:purple_terracotta
fill 533 185 228 533 187 228 minecraft:purple_terracotta
fill 533 185 270 533 187 270 minecraft:purple_terracotta
setblock 536 185 231 minecraft:light[level=11]
setblock 536 185 239 minecraft:light[level=11]
setblock 536 185 247 minecraft:light[level=11]
setblock 536 185 255 minecraft:light[level=11]
setblock 536 185 263 minecraft:light[level=11]
fill 537 185 228 537 187 228 minecraft:purple_terracotta
fill 537 185 270 537 187 270 minecraft:purple_terracotta
fill 541 185 228 541 187 228 minecraft:purple_terracotta
fill 541 185 270 541 187 270 minecraft:purple_terracotta
setblock 544 185 231 minecraft:light[level=11]
setblock 544 185 239 minecraft:light[level=11]
setblock 544 185 247 minecraft:light[level=11]
setblock 544 185 255 minecraft:light[level=11]
setblock 544 185 263 minecraft:light[level=11]
fill 545 185 228 545 187 228 minecraft:purple_terracotta
fill 545 185 230 546 185 230 minecraft:spruce_planks
fill 545 185 270 545 187 270 minecraft:purple_terracotta
fill 547 185 229 548 185 230 minecraft:dark_oak_planks
fill 549 185 228 549 187 228 minecraft:purple_terracotta
fill 549 185 270 549 187 270 minecraft:purple_terracotta
setblock 550 185 270 minecraft:gray_terracotta
setblock 552 185 231 minecraft:light[level=11]
setblock 552 185 239 minecraft:light[level=11]
setblock 552 185 247 minecraft:light[level=11]
setblock 552 185 255 minecraft:light[level=11]
setblock 552 185 263 minecraft:light[level=11]
fill 553 185 228 553 187 228 minecraft:purple_terracotta
fill 553 185 270 553 187 270 minecraft:purple_terracotta
fill 557 185 228 557 187 228 minecraft:purple_terracotta
fill 557 185 270 557 187 270 minecraft:purple_terracotta
setblock 559 185 228 minecraft:purple_terracotta
fill 559 185 232 559 187 232 minecraft:purple_terracotta
setblock 559 185 234 minecraft:light_gray_terracotta
fill 559 185 236 559 187 236 minecraft:purple_terracotta
fill 559 185 240 559 187 240 minecraft:purple_terracotta
fill 559 185 244 559 187 244 minecraft:purple_terracotta
fill 559 185 248 559 187 248 minecraft:purple_terracotta
fill 559 185 252 559 187 252 minecraft:purple_terracotta
fill 559 185 256 559 187 256 minecraft:purple_terracotta
fill 559 185 260 559 187 260 minecraft:purple_terracotta
fill 559 185 264 559 187 264 minecraft:purple_terracotta
fill 559 185 268 559 187 268 minecraft:purple_terracotta
setblock 517 186 230 minecraft:magenta_terracotta
setblock 517 186 234 minecraft:magenta_terracotta
setblock 517 186 238 minecraft:magenta_terracotta
setblock 517 186 242 minecraft:magenta_terracotta
setblock 517 186 246 minecraft:magenta_terracotta
setblock 517 186 250 minecraft:magenta_terracotta
setblock 517 186 254 minecraft:magenta_terracotta
setblock 517 186 258 minecraft:magenta_terracotta
setblock 517 186 262 minecraft:magenta_terracotta
setblock 517 186 266 minecraft:magenta_terracotta
setblock 517 186 270 minecraft:magenta_terracotta
setblock 519 186 228 minecraft:magenta_terracotta
setblock 519 186 270 minecraft:magenta_terracotta
setblock 523 186 228 minecraft:magenta_terracotta
setblock 523 186 270 minecraft:magenta_terracotta
setblock 527 186 228 minecraft:magenta_terracotta
setblock 527 186 270 minecraft:magenta_terracotta
setblock 531 186 228 minecraft:magenta_terracotta
setblock 531 186 270 minecraft:magenta_terracotta
setblock 535 186 228 minecraft:magenta_terracotta
setblock 535 186 270 minecraft:magenta_terracotta
setblock 539 186 228 minecraft:magenta_terracotta
setblock 539 186 270 minecraft:magenta_terracotta
setblock 543 186 228 minecraft:magenta_terracotta
fill 543 186 230 544 186 230 minecraft:spruce_planks
setblock 543 186 270 minecraft:magenta_terracotta
fill 545 186 229 546 186 230 minecraft:dark_oak_planks
setblock 547 186 228 minecraft:magenta_terracotta
setblock 547 186 270 minecraft:magenta_terracotta
fill 550 186 270 550 207 270 minecraft:purple_terracotta
setblock 551 186 228 minecraft:magenta_terracotta
setblock 551 186 270 minecraft:magenta_terracotta
setblock 555 186 228 minecraft:magenta_terracotta
setblock 555 186 270 minecraft:magenta_terracotta
setblock 559 186 228 minecraft:magenta_terracotta
setblock 559 186 230 minecraft:magenta_terracotta
setblock 559 186 234 minecraft:magenta_terracotta
setblock 559 186 238 minecraft:magenta_terracotta
setblock 559 186 242 minecraft:magenta_terracotta
setblock 559 186 246 minecraft:magenta_terracotta
setblock 559 186 250 minecraft:magenta_terracotta
setblock 559 186 254 minecraft:magenta_terracotta
setblock 559 186 258 minecraft:magenta_terracotta
setblock 559 186 262 minecraft:magenta_terracotta
setblock 559 186 266 minecraft:magenta_terracotta
setblock 559 186 270 minecraft:magenta_terracotta
fill 517 187 230 517 189 230 minecraft:purple_terracotta
fill 517 187 234 517 189 234 minecraft:purple_terracotta
fill 517 187 238 517 189 238 minecraft:purple_terracotta
fill 517 187 242 517 189 242 minecraft:purple_terracotta
fill 517 187 246 517 189 246 minecraft:purple_terracotta
fill 517 187 250 517 189 250 minecraft:purple_terracotta
fill 517 187 254 517 189 254 minecraft:purple_terracotta
fill 517 187 258 517 189 258 minecraft:purple_terracotta
fill 517 187 262 517 189 262 minecraft:purple_terracotta
fill 517 187 266 517 189 266 minecraft:purple_terracotta
setblock 517 187 270 minecraft:purple_terracotta
fill 519 187 228 519 189 228 minecraft:purple_terracotta
fill 519 187 270 519 189 270 minecraft:purple_terracotta
setblock 520 187 231 minecraft:light[level=12]
setblock 520 187 238 minecraft:light[level=12]
setblock 520 187 245 minecraft:light[level=12]
setblock 520 187 252 minecraft:light[level=12]
setblock 520 187 259 minecraft:light[level=12]
setblock 520 187 266 minecraft:light[level=12]
fill 523 187 228 523 189 228 minecraft:purple_terracotta
fill 523 187 270 523 189 270 minecraft:purple_terracotta
fill 527 187 228 527 189 228 minecraft:purple_terracotta
setblock 527 187 231 minecraft:light[level=12]
setblock 527 187 238 minecraft:light[level=12]
setblock 527 187 245 minecraft:light[level=12]
setblock 527 187 252 minecraft:light[level=12]
setblock 527 187 259 minecraft:light[level=12]
setblock 527 187 266 minecraft:light[level=12]
fill 527 187 270 527 189 270 minecraft:purple_terracotta
fill 531 187 228 531 189 228 minecraft:purple_terracotta
fill 531 187 270 531 189 270 minecraft:purple_terracotta
setblock 534 187 231 minecraft:light[level=12]
setblock 534 187 238 minecraft:light[level=12]
setblock 534 187 245 minecraft:light[level=12]
setblock 534 187 252 minecraft:light[level=12]
setblock 534 187 259 minecraft:light[level=12]
setblock 534 187 266 minecraft:light[level=12]
fill 535 187 228 535 189 228 minecraft:purple_terracotta
fill 535 187 270 535 189 270 minecraft:purple_terracotta
fill 539 187 228 539 189 228 minecraft:purple_terracotta
fill 539 187 270 539 189 270 minecraft:purple_terracotta
fill 541 187 230 542 187 230 minecraft:spruce_planks
setblock 541 187 231 minecraft:light[level=12]
setblock 541 187 238 minecraft:light[level=12]
setblock 541 187 245 minecraft:light[level=12]
setblock 541 187 252 minecraft:light[level=12]
setblock 541 187 259 minecraft:light[level=12]
setblock 541 187 266 minecraft:light[level=12]
fill 543 187 228 543 189 228 minecraft:purple_terracotta
fill 543 187 229 544 187 230 minecraft:dark_oak_planks
fill 543 187 270 543 189 270 minecraft:purple_terracotta
fill 547 187 228 547 189 228 minecraft:purple_terracotta
fill 547 187 270 547 189 270 minecraft:purple_terracotta
setblock 548 187 231 minecraft:light[level=12]
setblock 548 187 238 minecraft:light[level=12]
setblock 548 187 245 minecraft:light[level=12]
setblock 548 187 252 minecraft:light[level=12]
setblock 548 187 259 minecraft:light[level=12]
setblock 548 187 266 minecraft:light[level=12]
fill 551 187 228 551 189 228 minecraft:purple_terracotta
fill 551 187 270 551 189 270 minecraft:purple_terracotta
fill 555 187 228 555 189 228 minecraft:purple_terracotta
setblock 555 187 231 minecraft:light[level=12]
setblock 555 187 238 minecraft:light[level=12]
setblock 555 187 245 minecraft:light[level=12]
setblock 555 187 252 minecraft:light[level=12]
setblock 555 187 259 minecraft:light[level=12]
setblock 555 187 266 minecraft:light[level=12]
fill 555 187 270 555 189 270 minecraft:purple_terracotta
setblock 559 187 228 minecraft:purple_terracotta
fill 559 187 230 559 189 230 minecraft:purple_terracotta
fill 559 187 234 559 189 234 minecraft:purple_terracotta
fill 559 187 238 559 189 238 minecraft:purple_terracotta
fill 559 187 242 559 189 242 minecraft:purple_terracotta
fill 559 187 246 559 189 246 minecraft:purple_terracotta
fill 559 187 250 559 189 250 minecraft:purple_terracotta
fill 559 187 254 559 189 254 minecraft:purple_terracotta
fill 559 187 258 559 189 258 minecraft:purple_terracotta
fill 559 187 262 559 189 262 minecraft:purple_terracotta
fill 559 187 266 559 189 266 minecraft:purple_terracotta
fill 559 187 270 559 189 270 minecraft:purple_terracotta
setblock 517 188 228 minecraft:magenta_terracotta
setblock 517 188 232 minecraft:magenta_terracotta
setblock 517 188 236 minecraft:magenta_terracotta
setblock 517 188 240 minecraft:magenta_terracotta
setblock 517 188 244 minecraft:magenta_terracotta
setblock 517 188 248 minecraft:magenta_terracotta
setblock 517 188 252 minecraft:magenta_terracotta
setblock 517 188 256 minecraft:magenta_terracotta
setblock 517 188 260 minecraft:magenta_terracotta
setblock 517 188 264 minecraft:magenta_terracotta
setblock 517 188 268 minecraft:magenta_terracotta
setblock 517 188 270 minecraft:magenta_terracotta
setblock 521 188 228 minecraft:magenta_terracotta
setblock 521 188 270 minecraft:magenta_terracotta
setblock 525 188 228 minecraft:magenta_terracotta
setblock 525 188 270 minecraft:magenta_terracotta
setblock 529 188 228 minecraft:magenta_terracotta
setblock 529 188 270 minecraft:magenta_terracotta
setblock 533 188 228 minecraft:magenta_terracotta
setblock 533 188 270 minecraft:magenta_terracotta
setblock 537 188 228 minecraft:magenta_terracotta
setblock 537 188 270 minecraft:magenta_terracotta
fill 539 188 230 540 188 230 minecraft:spruce_planks
setblock 541 188 228 minecraft:magenta_terracotta
fill 541 188 229 542 188 230 minecraft:dark_oak_planks
setblock 541 188 270 minecraft:magenta_terracotta
setblock 545 188 228 minecraft:magenta_terracotta
setblock 545 188 270 minecraft:magenta_terracotta
setblock 549 188 228 minecraft:magenta_terracotta
setblock 549 188 270 minecraft:magenta_terracotta
setblock 553 188 228 minecraft:magenta_terracotta
setblock 553 188 270 minecraft:magenta_terracotta
setblock 557 188 228 minecraft:magenta_terracotta
setblock 557 188 270 minecraft:magenta_terracotta
setblock 559 188 228 minecraft:magenta_terracotta
setblock 559 188 232 minecraft:magenta_terracotta
setblock 559 188 236 minecraft:magenta_terracotta
setblock 559 188 240 minecraft:magenta_terracotta
setblock 559 188 244 minecraft:magenta_terracotta
setblock 559 188 248 minecraft:magenta_terracotta
setblock 559 188 251 minecraft:black_terracotta
setblock 559 188 252 minecraft:magenta_terracotta
setblock 559 188 256 minecraft:magenta_terracotta
setblock 559 188 260 minecraft:magenta_terracotta
setblock 559 188 264 minecraft:magenta_terracotta
setblock 559 188 268 minecraft:magenta_terracotta
fill 517 189 228 517 191 228 minecraft:purple_terracotta
fill 517 189 232 517 191 232 minecraft:purple_terracotta
fill 517 189 236 517 191 236 minecraft:purple_terracotta
fill 517 189 240 517 191 240 minecraft:purple_terracotta
fill 517 189 244 517 191 244 minecraft:purple_terracotta
fill 517 189 248 517 191 248 minecraft:purple_terracotta
fill 517 189 252 517 191 252 minecraft:purple_terracotta
fill 517 189 256 517 191 256 minecraft:purple_terracotta
fill 517 189 260 517 191 260 minecraft:purple_terracotta
fill 517 189 264 517 191 264 minecraft:purple_terracotta
fill 517 189 268 517 191 268 minecraft:purple_terracotta
setblock 517 189 270 minecraft:purple_terracotta
fill 521 189 228 521 191 228 minecraft:purple_terracotta
fill 521 189 270 521 191 270 minecraft:purple_terracotta
fill 525 189 228 525 191 228 minecraft:purple_terracotta
fill 525 189 270 525 191 270 minecraft:purple_terracotta
fill 529 189 228 529 191 228 minecraft:purple_terracotta
fill 529 189 270 529 191 270 minecraft:purple_terracotta
setblock 532 189 270 minecraft:light_gray_terracotta
fill 533 189 228 533 191 228 minecraft:purple_terracotta
fill 533 189 270 533 191 270 minecraft:purple_terracotta
fill 537 189 228 537 191 228 minecraft:purple_terracotta
fill 537 189 230 538 189 230 minecraft:spruce_planks
fill 537 189 270 537 191 270 minecraft:purple_terracotta
fill 539 189 229 540 189 230 minecraft:dark_oak_planks
fill 541 189 228 541 191 228 minecraft:purple_terracotta
fill 541 189 270 541 191 270 minecraft:purple_terracotta
fill 545 189 228 545 191 228 minecraft:purple_terracotta
fill 545 189 270 545 191 270 minecraft:purple_terracotta
fill 549 189 228 549 191 228 minecraft:purple_terracotta
fill 549 189 270 549 191 270 minecraft:purple_terracotta
fill 553 189 228 553 191 228 minecraft:purple_terracotta
fill 553 189 270 553 191 270 minecraft:purple_terracotta
fill 557 189 228 557 191 228 minecraft:purple_terracotta
fill 557 189 270 557 191 270 minecraft:purple_terracotta
setblock 559 189 228 minecraft:purple_terracotta
fill 559 189 232 559 191 232 minecraft:purple_terracotta
fill 559 189 236 559 191 236 minecraft:purple_terracotta
fill 559 189 240 559 191 240 minecraft:purple_terracotta
fill 559 189 244 559 191 244 minecraft:purple_terracotta
fill 559 189 248 559 191 248 minecraft:purple_terracotta
fill 559 189 251 559 191 252 minecraft:purple_terracotta
fill 559 189 256 559 191 256 minecraft:purple_terracotta
setblock 559 189 257 minecraft:black_terracotta
fill 559 189 260 559 191 260 minecraft:purple_terracotta
fill 559 189 264 559 191 264 minecraft:purple_terracotta
fill 559 189 268 559 191 268 minecraft:purple_terracotta
setblock 517 190 230 minecraft:magenta_terracotta
setblock 517 190 234 minecraft:magenta_terracotta
setblock 517 190 238 minecraft:magenta_terracotta
setblock 517 190 242 minecraft:magenta_terracotta
setblock 517 190 246 minecraft:magenta_terracotta
setblock 517 190 250 minecraft:magenta_terracotta
setblock 517 190 254 minecraft:magenta_terracotta
setblock 517 190 258 minecraft:magenta_terracotta
setblock 517 190 262 minecraft:magenta_terracotta
setblock 517 190 266 minecraft:magenta_terracotta
setblock 517 190 270 minecraft:magenta_terracotta
setblock 519 190 228 minecraft:magenta_terracotta
setblock 519 190 270 minecraft:magenta_terracotta
setblock 523 190 228 minecraft:magenta_terracotta
setblock 523 190 270 minecraft:magenta_terracotta
setblock 526 190 270 minecraft:black_terracotta
setblock 527 190 228 minecraft:magenta_terracotta
setblock 527 190 270 minecraft:magenta_terracotta
setblock 531 190 228 minecraft:magenta_terracotta
setblock 531 190 270 minecraft:magenta_terracotta
fill 532 190 270 532 207 270 minecraft:purple_terracotta
setblock 535 190 228 minecraft:magenta_terracotta
fill 535 190 230 536 190 230 minecraft:spruce_planks
setblock 535 190 270 minecraft:magenta_terracotta
fill 537 190 229 538 190 230 minecraft:dark_oak_planks
setblock 539 190 228 minecraft:magenta_terracotta
setblock 539 190 270 minecraft:magenta_terracotta
setblock 543 190 228 minecraft:magenta_terracotta
setblock 543 190 270 minecraft:magenta_terracotta
setblock 547 190 228 minecraft:magenta_terracotta
setblock 547 190 270 minecraft:magenta_terracotta
setblock 551 190 228 minecraft:magenta_terracotta
setblock 551 190 270 minecraft:magenta_terracotta
setblock 555 190 228 minecraft:magenta_terracotta
setblock 555 190 270 minecraft:magenta_terracotta
setblock 559 190 228 minecraft:magenta_terracotta
setblock 559 190 230 minecraft:magenta_terracotta
setblock 559 190 234 minecraft:magenta_terracotta
setblock 559 190 238 minecraft:magenta_terracotta
setblock 559 190 242 minecraft:magenta_terracotta
setblock 559 190 246 minecraft:magenta_terracotta
setblock 559 190 250 minecraft:magenta_terracotta
setblock 559 190 254 minecraft:magenta_terracotta
fill 559 190 257 559 207 257 minecraft:purple_terracotta
setblock 559 190 258 minecraft:magenta_terracotta
setblock 559 190 262 minecraft:magenta_terracotta
setblock 559 190 266 minecraft:magenta_terracotta
setblock 559 190 270 minecraft:magenta_terracotta
fill 517 191 230 517 193 230 minecraft:purple_terracotta
fill 517 191 234 517 193 234 minecraft:purple_terracotta
fill 517 191 238 517 193 238 minecraft:purple_terracotta
fill 517 191 242 517 193 242 minecraft:purple_terracotta
fill 517 191 246 517 193 246 minecraft:purple_terracotta
fill 517 191 250 517 193 250 minecraft:purple_terracotta
fill 517 191 254 517 193 254 minecraft:purple_terracotta
fill 517 191 258 517 193 258 minecraft:purple_terracotta
fill 517 191 262 517 193 262 minecraft:purple_terracotta
fill 517 191 266 517 193 266 minecraft:purple_terracotta
setblock 517 191 270 minecraft:purple_terracotta
fill 519 191 228 519 193 228 minecraft:purple_terracotta
fill 519 191 270 519 193 270 minecraft:purple_terracotta
fill 523 191 228 523 193 228 minecraft:purple_terracotta
fill 523 191 270 523 193 270 minecraft:purple_terracotta
fill 526 191 270 527 193 270 minecraft:purple_terracotta
fill 527 191 228 527 193 228 minecraft:purple_terracotta
fill 531 191 228 531 193 228 minecraft:purple_terracotta
fill 531 191 270 531 193 270 minecraft:purple_terracotta
fill 533 191 230 534 191 230 minecraft:spruce_planks
fill 535 191 228 535 193 228 minecraft:purple_terracotta
fill 535 191 229 536 191 230 minecraft:dark_oak_planks
fill 535 191 270 535 193 270 minecraft:purple_terracotta
fill 539 191 228 539 193 228 minecraft:purple_terracotta
fill 539 191 270 539 193 270 minecraft:purple_terracotta
fill 543 191 228 543 193 228 minecraft:purple_terracotta
fill 543 191 270 543 193 270 minecraft:purple_terracotta
fill 547 191 228 547 193 228 minecraft:purple_terracotta
fill 547 191 270 547 193 270 minecraft:purple_terracotta
fill 551 191 228 551 193 228 minecraft:purple_terracotta
fill 551 191 270 551 193 270 minecraft:purple_terracotta
fill 555 191 228 555 193 228 minecraft:purple_terracotta
fill 555 191 270 555 193 270 minecraft:purple_terracotta
setblock 559 191 228 minecraft:purple_terracotta
fill 559 191 230 559 193 230 minecraft:purple_terracotta
setblock 559 191 234 minecraft:purple_terracotta
fill 559 191 238 559 193 238 minecraft:purple_terracotta
fill 559 191 242 559 193 242 minecraft:purple_terracotta
fill 559 191 246 559 193 246 minecraft:purple_terracotta
fill 559 191 250 559 193 250 minecraft:purple_terracotta
fill 559 191 254 559 193 254 minecraft:purple_terracotta
fill 559 191 258 559 193 258 minecraft:purple_terracotta
fill 559 191 262 559 193 262 minecraft:purple_terracotta
fill 559 191 266 559 193 266 minecraft:purple_terracotta
fill 559 191 270 559 193 270 minecraft:purple_terracotta
setblock 517 192 228 minecraft:magenta_terracotta
setblock 517 192 232 minecraft:magenta_terracotta
setblock 517 192 236 minecraft:magenta_terracotta
setblock 517 192 240 minecraft:magenta_terracotta
setblock 517 192 244 minecraft:magenta_terracotta
setblock 517 192 248 minecraft:magenta_terracotta
setblock 517 192 252 minecraft:magenta_terracotta
setblock 517 192 256 minecraft:magenta_terracotta
setblock 517 192 260 minecraft:magenta_terracotta
setblock 517 192 264 minecraft:magenta_terracotta
setblock 517 192 268 minecraft:magenta_terracotta
setblock 517 192 270 minecraft:magenta_terracotta
setblock 521 192 228 minecraft:magenta_terracotta
setblock 521 192 270 minecraft:magenta_terracotta
setblock 525 192 228 minecraft:magenta_terracotta
setblock 525 192 270 minecraft:magenta_terracotta
fill 527 192 232 527 195 232 minecraft:iron_bars
setblock 529 192 228 minecraft:magenta_terracotta
setblock 529 192 270 minecraft:magenta_terracotta
fill 531 192 230 532 192 230 minecraft:spruce_planks
setblock 533 192 228 minecraft:magenta_terracotta
fill 533 192 229 534 192 230 minecraft:dark_oak_planks
setblock 533 192 270 minecraft:magenta_terracotta
setblock 537 192 228 minecraft:magenta_terracotta
setblock 537 192 270 minecraft:magenta_terracotta
setblock 541 192 228 minecraft:magenta_terracotta
setblock 541 192 270 minecraft:magenta_terracotta
setblock 545 192 228 minecraft:magenta_terracotta
setblock 545 192 270 minecraft:magenta_terracotta
setblock 549 192 228 minecraft:magenta_terracotta
setblock 549 192 270 minecraft:magenta_terracotta
setblock 553 192 228 minecraft:magenta_terracotta
setblock 553 192 270 minecraft:magenta_terracotta
setblock 557 192 228 minecraft:magenta_terracotta
setblock 557 192 270 minecraft:magenta_terracotta
setblock 559 192 228 minecraft:magenta_terracotta
setblock 559 192 232 minecraft:magenta_terracotta
setblock 559 192 234 minecraft:black_terracotta
setblock 559 192 236 minecraft:magenta_terracotta
setblock 559 192 240 minecraft:magenta_terracotta
setblock 559 192 244 minecraft:magenta_terracotta
setblock 559 192 248 minecraft:magenta_terracotta
fill 559 192 251 559 207 251 minecraft:purple_terracotta
setblock 559 192 252 minecraft:magenta_terracotta
setblock 559 192 256 minecraft:magenta_terracotta
setblock 559 192 260 minecraft:magenta_terracotta
setblock 559 192 264 minecraft:magenta_terracotta
setblock 559 192 268 minecraft:magenta_terracotta
fill 517 193 228 517 195 228 minecraft:purple_terracotta
fill 517 193 232 517 195 232 minecraft:purple_terracotta
fill 517 193 236 517 195 236 minecraft:purple_terracotta
setblock 517 193 237 minecraft:light_gray_terracotta
fill 517 193 240 517 195 240 minecraft:purple_terracotta
schedule function dropper:buildpart/59_3 1t
