fill 266 222 254 266 222 255 minecraft:pearlescent_froglight
setblock 266 222 259 minecraft:light_gray_concrete
fill 266 222 270 266 239 270 minecraft:black_concrete
setblock 267 222 240 minecraft:light_gray_concrete
setblock 267 222 243 minecraft:gray_stained_glass
fill 267 222 247 268 222 247 minecraft:black_stained_glass
setblock 267 222 248 minecraft:sea_lantern
fill 267 222 249 268 222 249 minecraft:pearlescent_froglight
fill 267 222 253 268 222 253 minecraft:pearlescent_froglight
setblock 267 222 254 minecraft:sea_lantern
setblock 267 222 255 minecraft:black_stained_glass
setblock 267 222 258 minecraft:light_gray_concrete
fill 268 222 241 268 222 243 minecraft:light_gray_concrete
setblock 268 222 245 minecraft:gray_stained_glass
setblock 268 222 246 minecraft:black_stained_glass
setblock 268 222 248 minecraft:black_stained_glass
fill 268 222 250 268 222 252 minecraft:sea_lantern
setblock 268 222 254 minecraft:black_stained_glass
fill 268 222 255 268 222 257 minecraft:light_gray_concrete
fill 268 222 262 268 223 262 minecraft:light_gray_concrete
fill 268 222 264 268 223 264 minecraft:light_gray_concrete
fill 268 222 266 268 223 266 minecraft:light_gray_concrete
fill 268 222 268 268 223 268 minecraft:light_gray_concrete
fill 269 222 243 269 222 248 minecraft:light_gray_concrete
setblock 269 222 249 minecraft:gray_stained_glass
fill 269 222 250 269 222 253 minecraft:light_gray_concrete
setblock 269 222 255 minecraft:light_gray_concrete
fill 269 222 261 269 223 261 minecraft:light_gray_concrete
fill 269 222 269 269 223 269 minecraft:light_gray_concrete
fill 270 222 245 270 222 247 minecraft:light_gray_concrete
fill 270 222 251 270 222 253 minecraft:light_gray_concrete
fill 271 222 243 271 223 243 minecraft:light_gray_concrete
setblock 271 222 245 minecraft:light_gray_concrete
setblock 271 222 247 minecraft:light_gray_concrete
setblock 271 222 249 minecraft:light_gray_concrete
setblock 271 222 251 minecraft:light_gray_concrete
setblock 271 222 253 minecraft:light_gray_concrete
fill 271 222 261 271 223 261 minecraft:light_gray_concrete
fill 271 222 269 271 223 269 minecraft:light_gray_concrete
fill 272 222 242 272 223 242 minecraft:light_gray_concrete
setblock 272 222 255 minecraft:light_gray_concrete
fill 273 222 261 273 223 261 minecraft:light_gray_concrete
fill 273 222 269 273 223 269 minecraft:light_gray_concrete
fill 274 222 242 274 223 242 minecraft:light_gray_concrete
fill 274 222 255 274 223 255 minecraft:light_gray_concrete
fill 275 222 261 275 223 261 minecraft:light_gray_concrete
fill 275 222 269 275 223 269 minecraft:light_gray_concrete
fill 276 222 243 276 223 243 minecraft:light_gray_concrete
fill 276 222 245 276 223 245 minecraft:light_gray_concrete
fill 276 222 247 276 223 247 minecraft:light_gray_concrete
fill 276 222 249 276 223 249 minecraft:light_gray_concrete
fill 276 222 251 276 223 251 minecraft:light_gray_concrete
fill 276 222 253 276 223 253 minecraft:light_gray_concrete
fill 276 222 262 276 223 262 minecraft:light_gray_concrete
fill 276 222 264 276 223 264 minecraft:light_gray_concrete
fill 276 222 266 276 223 266 minecraft:light_gray_concrete
fill 276 222 268 276 223 268 minecraft:light_gray_concrete
setblock 235 223 239 minecraft:sea_lantern
setblock 235 223 253 minecraft:verdant_froglight
setblock 238 223 238 minecraft:light[level=12]
setblock 238 223 245 minecraft:light[level=12]
setblock 238 223 252 minecraft:light[level=12]
setblock 238 223 259 minecraft:light[level=12]
setblock 238 223 266 minecraft:light[level=12]
setblock 240 223 270 minecraft:cyan_concrete
fill 242 223 248 243 223 250 minecraft:cyan_concrete
fill 243 223 244 244 223 244 minecraft:cyan_concrete
fill 243 223 245 245 223 245 minecraft:light_gray_concrete
fill 243 223 246 243 223 247 minecraft:cyan_concrete
fill 243 223 251 243 223 254 minecraft:cyan_concrete
fill 244 223 242 244 223 243 minecraft:cyan_concrete
fill 244 223 254 244 223 256 minecraft:cyan_concrete
setblock 245 223 231 minecraft:light[level=12]
setblock 245 223 238 minecraft:light[level=12]
fill 245 223 241 245 223 242 minecraft:cyan_concrete
fill 245 223 246 248 223 246 minecraft:light_gray_concrete
setblock 245 223 252 minecraft:light[level=12]
fill 245 223 256 245 223 257 minecraft:cyan_concrete
setblock 245 223 259 minecraft:light[level=12]
setblock 245 223 266 minecraft:light[level=12]
setblock 246 223 240 minecraft:cyan_concrete
fill 246 223 258 247 223 258 minecraft:light_gray_concrete
setblock 247 223 239 minecraft:cyan_concrete
fill 247 223 257 248 223 257 minecraft:light_gray_concrete
setblock 247 223 259 minecraft:cyan_concrete
fill 248 223 238 249 223 238 minecraft:cyan_concrete
fill 248 223 247 249 223 247 minecraft:light_gray_concrete
fill 248 223 256 249 223 256 minecraft:light_gray_concrete
setblock 248 223 260 minecraft:cyan_concrete
fill 248 223 261 253 223 261 minecraft:white_concrete
fill 249 223 237 251 223 237 minecraft:cyan_concrete
fill 249 223 255 250 223 255 minecraft:light_gray_concrete
fill 249 223 260 250 223 260 minecraft:white_concrete
fill 249 223 262 262 223 262 minecraft:white_concrete
fill 250 223 254 251 223 254 minecraft:light_gray_concrete
fill 251 223 236 252 223 236 minecraft:cyan_concrete
setblock 252 223 231 minecraft:light[level=12]
setblock 252 223 238 minecraft:light[level=12]
setblock 252 223 245 minecraft:light[level=12]
setblock 252 223 252 minecraft:light[level=12]
setblock 252 223 259 minecraft:light[level=12]
fill 252 223 263 259 223 263 minecraft:white_concrete
setblock 252 223 266 minecraft:light[level=12]
fill 253 223 236 253 223 238 minecraft:light_gray_concrete
setblock 254 223 228 minecraft:magenta_concrete
fill 254 223 236 261 223 236 minecraft:cyan_concrete
fill 254 223 238 254 223 242 minecraft:light_gray_concrete
fill 255 223 235 257 223 235 minecraft:cyan_concrete
fill 255 223 261 255 224 261 minecraft:white_concrete
fill 257 223 244 258 224 259 minecraft:gray_concrete
fill 258 223 260 259 223 260 minecraft:light_gray_concrete
fill 258 223 261 258 224 261 minecraft:white_concrete
setblock 259 223 231 minecraft:light[level=12]
setblock 259 223 238 minecraft:light[level=12]
fill 259 223 244 272 224 245 minecraft:gray_concrete
fill 259 223 257 272 224 259 minecraft:gray_concrete
setblock 259 223 261 minecraft:light_gray_concrete
setblock 259 223 266 minecraft:light[level=12]
fill 260 223 261 262 223 261 minecraft:white_concrete
fill 261 223 237 263 223 237 minecraft:cyan_concrete
fill 261 223 263 261 224 263 minecraft:white_concrete
fill 262 223 243 263 223 243 minecraft:light_gray_concrete
fill 263 223 238 264 223 238 minecraft:cyan_concrete
fill 263 223 242 264 223 242 minecraft:light_gray_concrete
fill 263 223 260 263 223 261 minecraft:cyan_concrete
fill 264 223 241 265 223 241 minecraft:light_gray_concrete
setblock 264 223 260 minecraft:cyan_concrete
setblock 265 223 239 minecraft:cyan_concrete
setblock 265 223 240 minecraft:light_gray_concrete
setblock 266 223 231 minecraft:light[level=12]
setblock 266 223 238 minecraft:light[level=12]
setblock 266 223 266 minecraft:light[level=12]
fill 267 223 241 267 223 242 minecraft:cyan_concrete
fill 268 223 242 268 223 243 minecraft:cyan_concrete
fill 270 223 246 272 224 256 minecraft:gray_concrete
fill 272 223 243 274 225 243 minecraft:light_gray_concrete
setblock 273 223 231 minecraft:light[level=12]
setblock 273 223 238 minecraft:light[level=12]
fill 273 223 244 274 225 245 minecraft:light_gray_concrete
fill 273 223 250 275 229 254 minecraft:light_gray_concrete
setblock 273 223 259 minecraft:light[level=12]
fill 276 223 250 276 263 250 minecraft:light_gray_concrete
fill 276 223 252 276 263 252 minecraft:light_gray_concrete
setblock 277 223 243 minecraft:cyan_concrete
fill 235 224 232 235 302 232 minecraft:black_concrete
setblock 235 224 233 minecraft:ochre_froglight
fill 235 224 239 235 244 239 minecraft:black_concrete
setblock 235 224 246 minecraft:sea_lantern
fill 235 224 253 235 290 253 minecraft:black_concrete
setblock 236 224 230 minecraft:black_stained_glass
setblock 236 224 232 minecraft:sea_lantern
setblock 236 224 234 minecraft:black_stained_glass
setblock 236 224 236 minecraft:black_stained_glass
setblock 237 224 229 minecraft:black_stained_glass
setblock 237 224 237 minecraft:black_stained_glass
setblock 239 224 229 minecraft:sea_lantern
setblock 239 224 237 minecraft:cyan_stained_glass
setblock 240 224 270 minecraft:black_concrete
setblock 241 224 229 minecraft:black_stained_glass
setblock 241 224 237 minecraft:cyan_stained_glass
setblock 243 224 229 minecraft:black_stained_glass
setblock 243 224 237 minecraft:black_stained_glass
setblock 244 224 230 minecraft:black_stained_glass
setblock 244 224 232 minecraft:sea_lantern
setblock 244 224 234 minecraft:black_stained_glass
setblock 244 224 236 minecraft:pearlescent_froglight
fill 248 224 260 248 224 261 minecraft:white_concrete
fill 249 224 260 250 224 261 minecraft:light_blue_stained_glass
fill 249 224 262 251 224 262 minecraft:white_concrete
setblock 251 224 261 minecraft:white_concrete
fill 251 224 263 254 224 263 minecraft:white_concrete
fill 252 224 261 252 224 262 minecraft:light_blue_stained_glass
setblock 253 224 261 minecraft:white_concrete
setblock 253 224 262 minecraft:light_blue_stained_glass
fill 254 224 228 254 296 228 minecraft:black_concrete
fill 254 224 262 254 225 262 minecraft:white_concrete
fill 255 224 262 255 225 263 minecraft:light_blue_stained_glass
setblock 255 224 264 minecraft:white_concrete
setblock 256 224 228 minecraft:magenta_concrete
setblock 256 224 262 minecraft:light_blue_stained_glass
fill 256 224 263 257 224 263 minecraft:white_concrete
fill 257 224 262 257 225 262 minecraft:white_concrete
fill 258 224 262 258 225 263 minecraft:light_blue_stained_glass
setblock 258 224 264 minecraft:white_concrete
fill 259 224 261 260 224 261 minecraft:white_concrete
fill 259 224 262 261 224 262 minecraft:light_blue_stained_glass
fill 259 224 263 260 224 263 minecraft:white_concrete
setblock 261 224 260 minecraft:white_concrete
fill 261 224 261 261 225 261 minecraft:light_blue_stained_glass
fill 262 224 261 262 224 262 minecraft:white_concrete
setblock 268 224 262 minecraft:light_blue_stained_glass
setblock 268 224 264 minecraft:black_stained_glass
setblock 268 224 266 minecraft:black_stained_glass
setblock 268 224 268 minecraft:black_stained_glass
setblock 269 224 261 minecraft:cyan_stained_glass
setblock 269 224 269 minecraft:black_stained_glass
setblock 271 224 243 minecraft:black_stained_glass
setblock 271 224 261 minecraft:pearlescent_froglight
setblock 271 224 269 minecraft:magenta_stained_glass
setblock 272 224 228 minecraft:verdant_froglight
setblock 272 224 242 minecraft:sea_lantern
setblock 273 224 261 minecraft:magenta_stained_glass
setblock 273 224 269 minecraft:magenta_stained_glass
setblock 274 224 242 minecraft:magenta_stained_glass
setblock 274 224 255 minecraft:magenta_stained_glass
setblock 275 224 261 minecraft:cyan_stained_glass
setblock 275 224 269 minecraft:black_stained_glass
setblock 276 224 243 minecraft:sea_lantern
setblock 276 224 245 minecraft:magenta_stained_glass
setblock 276 224 247 minecraft:black_stained_glass
setblock 276 224 249 minecraft:sea_lantern
setblock 276 224 251 minecraft:light_blue_stained_glass
setblock 276 224 253 minecraft:ochre_froglight
setblock 276 224 262 minecraft:sea_lantern
setblock 276 224 264 minecraft:ochre_froglight
setblock 276 224 266 minecraft:ochre_froglight
setblock 276 224 268 minecraft:cyan_stained_glass
setblock 277 224 236 minecraft:ochre_froglight
fill 277 224 243 277 263 243 minecraft:black_concrete
setblock 277 224 265 minecraft:magenta_concrete
setblock 235 225 229 minecraft:purple_concrete
fill 235 225 233 235 230 233 minecraft:black_concrete
fill 235 225 246 235 308 246 minecraft:black_concrete
setblock 236 225 230 minecraft:light_gray_concrete
setblock 236 225 232 minecraft:light_gray_concrete
setblock 236 225 234 minecraft:light_gray_concrete
setblock 236 225 236 minecraft:light_gray_concrete
setblock 237 225 229 minecraft:light_gray_concrete
setblock 237 225 237 minecraft:light_gray_concrete
setblock 239 225 229 minecraft:light_gray_concrete
setblock 239 225 237 minecraft:light_gray_concrete
setblock 240 225 270 minecraft:magenta_concrete
setblock 241 225 229 minecraft:light_gray_concrete
setblock 241 225 237 minecraft:light_gray_concrete
setblock 243 225 228 minecraft:sea_lantern
setblock 243 225 229 minecraft:light_gray_concrete
setblock 243 225 237 minecraft:light_gray_concrete
fill 243 225 258 247 225 260 minecraft:cyan_stained_glass
setblock 244 225 230 minecraft:light_gray_concrete
setblock 244 225 232 minecraft:light_gray_concrete
setblock 244 225 234 minecraft:light_gray_concrete
setblock 244 225 236 minecraft:light_gray_concrete
fill 244 225 257 246 225 257 minecraft:cyan_stained_glass
fill 244 225 261 246 225 261 minecraft:cyan_stained_glass
fill 249 225 260 250 225 260 minecraft:white_concrete
fill 249 225 261 250 225 261 minecraft:light_blue_stained_glass
setblock 251 225 262 minecraft:white_concrete
setblock 252 225 261 minecraft:white_concrete
setblock 252 225 262 minecraft:light_blue_stained_glass
setblock 252 225 263 minecraft:white_concrete
setblock 253 225 262 minecraft:white_concrete
setblock 254 225 263 minecraft:white_concrete
fill 256 225 228 256 259 228 minecraft:black_concrete
fill 256 225 262 256 225 263 minecraft:white_concrete
fill 257 225 244 257 237 244 minecraft:gray_concrete
setblock 257 225 245 minecraft:sea_lantern
fill 257 225 246 258 238 246 minecraft:gray_concrete
setblock 257 225 247 minecraft:black_stained_glass
fill 257 225 248 258 238 248 minecraft:gray_concrete
setblock 257 225 249 minecraft:black_stained_glass
fill 257 225 250 258 238 250 minecraft:gray_concrete
setblock 257 225 251 minecraft:light_blue_stained_glass
fill 257 225 252 258 238 252 minecraft:gray_concrete
setblock 257 225 253 minecraft:light_blue_stained_glass
fill 257 225 254 258 238 254 minecraft:gray_concrete
setblock 257 225 255 minecraft:sea_lantern
fill 257 225 256 258 238 256 minecraft:gray_concrete
setblock 257 225 257 minecraft:black_stained_glass
fill 257 225 258 257 238 259 minecraft:gray_concrete
setblock 258 225 244 minecraft:black_stained_glass
fill 258 225 245 271 238 245 minecraft:gray_concrete
fill 258 225 247 258 238 247 minecraft:gray_concrete
fill 258 225 249 258 238 249 minecraft:gray_concrete
fill 258 225 251 258 238 251 minecraft:gray_concrete
fill 258 225 253 258 238 253 minecraft:gray_concrete
fill 258 225 255 258 238 255 minecraft:gray_concrete
fill 258 225 257 271 238 258 minecraft:gray_concrete
setblock 258 225 259 minecraft:sea_lantern
fill 259 225 244 259 237 244 minecraft:gray_concrete
fill 259 225 259 259 238 259 minecraft:gray_concrete
fill 259 225 262 259 225 263 minecraft:white_concrete
setblock 260 225 244 minecraft:sea_lantern
setblock 260 225 259 minecraft:sea_lantern
fill 260 225 261 260 225 262 minecraft:white_concrete
fill 261 225 244 261 237 244 minecraft:gray_concrete
fill 261 225 259 261 238 259 minecraft:gray_concrete
setblock 261 225 262 minecraft:light_blue_stained_glass
setblock 262 225 244 minecraft:black_stained_glass
setblock 262 225 259 minecraft:sea_lantern
setblock 262 225 262 minecraft:white_concrete
fill 263 225 244 263 237 244 minecraft:gray_concrete
fill 263 225 259 263 238 259 minecraft:gray_concrete
setblock 264 225 244 minecraft:black_stained_glass
setblock 264 225 259 minecraft:light_blue_stained_glass
fill 265 225 244 265 237 244 minecraft:gray_concrete
fill 265 225 259 265 238 259 minecraft:gray_concrete
setblock 266 225 244 minecraft:sea_lantern
setblock 266 225 259 minecraft:sea_lantern
fill 267 225 244 267 237 244 minecraft:gray_concrete
fill 267 225 259 267 238 259 minecraft:gray_concrete
setblock 268 225 244 minecraft:sea_lantern
setblock 268 225 259 minecraft:black_stained_glass
fill 268 225 262 268 226 262 minecraft:light_gray_concrete
fill 268 225 264 268 226 264 minecraft:light_gray_concrete
fill 268 225 266 268 226 266 minecraft:light_gray_concrete
fill 268 225 268 268 226 268 minecraft:light_gray_concrete
fill 269 225 244 269 237 244 minecraft:gray_concrete
fill 269 225 259 269 238 259 minecraft:gray_concrete
fill 269 225 261 269 226 261 minecraft:light_gray_concrete
fill 269 225 269 269 226 269 minecraft:light_gray_concrete
setblock 270 225 244 minecraft:sea_lantern
fill 270 225 246 271 238 256 minecraft:gray_concrete
setblock 270 225 259 minecraft:light_blue_stained_glass
setblock 271 225 243 minecraft:light_gray_concrete
fill 271 225 244 272 237 244 minecraft:gray_concrete
fill 271 225 259 272 238 259 minecraft:gray_concrete
fill 271 225 261 271 226 261 minecraft:light_gray_concrete
fill 271 225 269 271 226 269 minecraft:light_gray_concrete
fill 272 225 228 272 308 228 minecraft:black_concrete
setblock 272 225 242 minecraft:light_gray_concrete
setblock 272 225 245 minecraft:black_stained_glass
fill 272 225 246 272 248 246 minecraft:gray_concrete
setblock 272 225 247 minecraft:sea_lantern
fill 272 225 248 272 248 248 minecraft:gray_concrete
setblock 272 225 249 minecraft:sea_lantern
fill 272 225 250 272 238 250 minecraft:gray_concrete
setblock 272 225 251 minecraft:black_stained_glass
fill 272 225 252 272 238 252 minecraft:gray_concrete
setblock 272 225 253 minecraft:sea_lantern
fill 272 225 254 272 238 254 minecraft:gray_concrete
setblock 272 225 255 minecraft:black_stained_glass
fill 272 225 256 272 238 256 minecraft:gray_concrete
setblock 272 225 257 minecraft:black_stained_glass
fill 272 225 258 272 238 258 minecraft:gray_concrete
fill 273 225 261 273 226 261 minecraft:light_gray_concrete
fill 273 225 269 273 226 269 minecraft:light_gray_concrete
setblock 273 225 270 minecraft:magenta_concrete
setblock 274 225 242 minecraft:light_gray_concrete
fill 274 225 255 274 226 255 minecraft:light_gray_concrete
fill 275 225 261 275 226 261 minecraft:light_gray_concrete
fill 275 225 269 275 226 269 minecraft:light_gray_concrete
setblock 276 225 243 minecraft:light_gray_concrete
setblock 276 225 245 minecraft:light_gray_concrete
setblock 276 225 247 minecraft:light_gray_concrete
fill 276 225 249 276 226 249 minecraft:light_gray_concrete
fill 276 225 251 276 226 251 minecraft:light_gray_concrete
fill 276 225 253 276 226 253 minecraft:light_gray_concrete
fill 276 225 262 276 226 262 minecraft:light_gray_concrete
fill 276 225 264 276 226 264 minecraft:light_gray_concrete
fill 276 225 266 276 226 266 minecraft:light_gray_concrete
fill 276 225 268 276 226 268 minecraft:light_gray_concrete
fill 277 225 236 277 308 236 minecraft:black_concrete
setblock 277 225 248 minecraft:blue_concrete
fill 277 225 265 277 272 265 minecraft:black_concrete
fill 235 226 229 244 226 229 minecraft:black_concrete
setblock 235 226 259 minecraft:purple_concrete
fill 236 226 230 244 226 237 minecraft:black_concrete
fill 240 226 270 240 255 270 minecraft:black_concrete
fill 242 226 258 242 227 260 minecraft:cyan_stained_glass
setblock 243 226 228 minecraft:black_concrete
fill 243 226 257 243 226 258 minecraft:cyan_stained_glass
fill 243 226 260 243 226 261 minecraft:cyan_stained_glass
fill 244 226 256 244 226 257 minecraft:cyan_stained_glass
fill 244 226 261 244 226 262 minecraft:cyan_stained_glass
fill 245 226 256 246 227 256 minecraft:cyan_stained_glass
fill 245 226 262 246 227 262 minecraft:cyan_stained_glass
fill 246 226 257 247 226 257 minecraft:cyan_stained_glass
fill 246 226 261 247 226 261 minecraft:cyan_stained_glass
fill 247 226 258 248 226 258 minecraft:cyan_stained_glass
fill 247 226 260 248 226 260 minecraft:cyan_stained_glass
fill 248 226 259 248 227 259 minecraft:cyan_stained_glass
fill 257 226 245 257 227 245 minecraft:gray_concrete
fill 257 226 247 257 227 247 minecraft:gray_concrete
fill 257 226 249 257 227 249 minecraft:gray_concrete
fill 257 226 251 257 227 251 minecraft:gray_concrete
fill 257 226 253 257 227 253 minecraft:gray_concrete
fill 257 226 255 257 227 255 minecraft:gray_concrete
fill 257 226 257 257 227 257 minecraft:gray_concrete
fill 258 226 244 258 227 244 minecraft:gray_concrete
fill 258 226 259 258 227 259 minecraft:gray_concrete
fill 260 226 244 260 227 244 minecraft:gray_concrete
fill 260 226 259 260 227 259 minecraft:gray_concrete
fill 262 226 244 262 227 244 minecraft:gray_concrete
fill 262 226 259 262 227 259 minecraft:gray_concrete
fill 264 226 244 264 227 244 minecraft:gray_concrete
fill 264 226 259 264 227 259 minecraft:gray_concrete
fill 266 226 244 266 227 244 minecraft:gray_concrete
fill 266 226 259 266 227 259 minecraft:gray_concrete
fill 268 226 244 268 227 244 minecraft:gray_concrete
fill 268 226 259 268 227 259 minecraft:gray_concrete
fill 270 226 238 270 227 244 minecraft:gray_concrete
fill 270 226 259 270 227 259 minecraft:gray_concrete
fill 271 226 238 276 226 243 minecraft:gray_concrete
fill 272 226 245 276 226 245 minecraft:gray_concrete
fill 272 226 247 276 226 247 minecraft:gray_concrete
fill 272 226 249 272 227 249 minecraft:gray_concrete
fill 272 226 251 272 227 251 minecraft:gray_concrete
fill 272 226 253 272 227 253 minecraft:gray_concrete
fill 272 226 255 272 227 255 minecraft:gray_concrete
fill 272 226 257 272 227 257 minecraft:gray_concrete
fill 273 226 244 276 228 244 minecraft:gray_concrete
fill 273 226 246 276 228 246 minecraft:gray_concrete
fill 273 226 248 276 228 248 minecraft:gray_concrete
fill 273 226 249 275 230 249 minecraft:light_gray_concrete
fill 273 226 270 273 250 270 minecraft:black_concrete
fill 277 226 248 277 242 248 minecraft:black_concrete
fill 235 227 229 235 244 229 minecraft:black_concrete
fill 235 227 259 235 247 259 minecraft:black_concrete
fill 236 227 229 236 227 237 minecraft:pearlescent_froglight
fill 237 227 229 244 227 229 minecraft:pearlescent_froglight
fill 237 227 237 244 227 237 minecraft:pearlescent_froglight
fill 238 227 231 242 228 235 minecraft:light_gray_concrete
setblock 238 227 239 minecraft:light[level=15]
setblock 238 227 247 minecraft:light[level=15]
setblock 238 227 255 minecraft:light[level=15]
setblock 238 227 263 minecraft:light[level=15]
fill 242 227 257 242 230 257 minecraft:cyan_stained_glass
fill 242 227 261 242 230 261 minecraft:cyan_stained_glass
setblock 243 227 228 minecraft:cyan_concrete
fill 243 227 256 244 227 256 minecraft:cyan_stained_glass
fill 243 227 262 244 227 262 minecraft:cyan_stained_glass
fill 244 227 230 244 227 236 minecraft:pearlescent_froglight
setblock 246 227 231 minecraft:light[level=15]
setblock 246 227 239 minecraft:light[level=15]
setblock 246 227 247 minecraft:light[level=15]
setblock 246 227 255 minecraft:light[level=15]
setblock 246 227 263 minecraft:light[level=15]
fill 247 227 256 247 230 256 minecraft:cyan_stained_glass
fill 247 227 262 247 230 262 minecraft:cyan_stained_glass
fill 248 227 257 248 227 258 minecraft:cyan_stained_glass
fill 248 227 260 248 227 261 minecraft:cyan_stained_glass
setblock 254 227 231 minecraft:light[level=15]
setblock 254 227 239 minecraft:light[level=15]
setblock 254 227 247 minecraft:light[level=15]
setblock 254 227 255 minecraft:light[level=15]
setblock 254 227 263 minecraft:light[level=15]
setblock 262 227 231 minecraft:light[level=15]
setblock 262 227 239 minecraft:light[level=15]
setblock 262 227 263 minecraft:light[level=15]
setblock 268 227 262 minecraft:magenta_stained_glass
setblock 268 227 264 minecraft:black_stained_glass
setblock 268 227 266 minecraft:magenta_stained_glass
setblock 268 227 268 minecraft:black_stained_glass
setblock 269 227 261 minecraft:magenta_stained_glass
setblock 269 227 269 minecraft:magenta_stained_glass
setblock 270 227 231 minecraft:light[level=15]
fill 271 227 238 271 228 243 minecraft:gray_concrete
setblock 271 227 261 minecraft:black_stained_glass
setblock 271 227 269 minecraft:magenta_stained_glass
fill 272 227 238 276 228 241 minecraft:gray_concrete
setblock 272 227 242 minecraft:sea_lantern
fill 272 227 243 275 228 243 minecraft:gray_concrete
fill 272 227 245 275 227 245 minecraft:gray_concrete
fill 272 227 247 275 227 247 minecraft:gray_concrete
fill 273 227 242 273 228 242 minecraft:gray_concrete
setblock 273 227 261 minecraft:cyan_stained_glass
setblock 273 227 269 minecraft:magenta_stained_glass
setblock 274 227 242 minecraft:ochre_froglight
setblock 274 227 255 minecraft:black_stained_glass
fill 275 227 242 276 228 242 minecraft:gray_concrete
setblock 275 227 261 minecraft:black_stained_glass
setblock 275 227 269 minecraft:pearlescent_froglight
setblock 276 227 243 minecraft:cyan_stained_glass
setblock 276 227 245 minecraft:pearlescent_froglight
setblock 276 227 247 minecraft:black_stained_glass
setblock 276 227 249 minecraft:sea_lantern
setblock 276 227 251 minecraft:ochre_froglight
setblock 276 227 253 minecraft:black_stained_glass
setblock 276 227 262 minecraft:black_stained_glass
setblock 276 227 264 minecraft:black_stained_glass
setblock 276 227 266 minecraft:black_stained_glass
setblock 276 227 268 minecraft:cyan_stained_glass
fill 241 228 258 241 229 260 minecraft:cyan_stained_glass
fill 243 228 228 243 308 228 minecraft:black_concrete
fill 243 228 256 243 230 256 minecraft:cyan_stained_glass
fill 243 228 262 243 230 262 minecraft:cyan_stained_glass
fill 244 228 255 246 229 255 minecraft:cyan_stained_glass
fill 244 228 259 246 229 259 minecraft:pearlescent_froglight
fill 244 228 263 246 229 263 minecraft:cyan_stained_glass
fill 245 228 258 245 229 258 minecraft:pearlescent_froglight
fill 245 228 260 245 229 260 minecraft:pearlescent_froglight
fill 248 228 257 248 230 257 minecraft:cyan_stained_glass
fill 248 228 261 248 230 261 minecraft:cyan_stained_glass
fill 249 228 258 249 229 260 minecraft:cyan_stained_glass
setblock 257 228 245 minecraft:black_stained_glass
setblock 257 228 247 minecraft:sea_lantern
setblock 257 228 249 minecraft:sea_lantern
setblock 257 228 251 minecraft:light_blue_stained_glass
setblock 257 228 253 minecraft:light_blue_stained_glass
setblock 257 228 255 minecraft:light_blue_stained_glass
setblock 257 228 257 minecraft:black_stained_glass
setblock 258 228 244 minecraft:black_stained_glass
setblock 258 228 259 minecraft:sea_lantern
setblock 260 228 244 minecraft:sea_lantern
setblock 260 228 259 minecraft:light_blue_stained_glass
setblock 262 228 244 minecraft:black_stained_glass
setblock 262 228 259 minecraft:black_stained_glass
setblock 264 228 244 minecraft:black_stained_glass
setblock 264 228 259 minecraft:sea_lantern
setblock 266 228 244 minecraft:sea_lantern
setblock 266 228 259 minecraft:light_blue_stained_glass
setblock 268 228 244 minecraft:black_stained_glass
setblock 268 228 259 minecraft:light_blue_stained_glass
fill 268 228 262 268 229 262 minecraft:light_gray_concrete
fill 268 228 264 268 229 264 minecraft:light_gray_concrete
fill 268 228 266 268 229 266 minecraft:light_gray_concrete
fill 268 228 268 268 229 268 minecraft:light_gray_concrete
fill 269 228 261 269 229 261 minecraft:light_gray_concrete
fill 269 228 269 269 229 269 minecraft:light_gray_concrete
fill 270 228 238 270 228 243 minecraft:gray_concrete
setblock 270 228 244 minecraft:sea_lantern
setblock 270 228 259 minecraft:black_stained_glass
fill 271 228 261 271 229 261 minecraft:light_gray_concrete
fill 271 228 269 271 229 269 minecraft:light_gray_concrete
fill 272 228 242 272 229 242 minecraft:gray_concrete
setblock 272 228 245 minecraft:black_stained_glass
setblock 272 228 247 minecraft:black_stained_glass
setblock 272 228 249 minecraft:light_blue_stained_glass
setblock 272 228 251 minecraft:light_blue_stained_glass
setblock 272 228 253 minecraft:sea_lantern
setblock 272 228 255 minecraft:black_stained_glass
setblock 272 228 257 minecraft:black_stained_glass
fill 273 228 245 276 228 245 minecraft:gray_concrete
fill 273 228 247 276 228 247 minecraft:gray_concrete
fill 273 228 261 273 229 261 minecraft:light_gray_concrete
fill 273 228 269 273 229 269 minecraft:light_gray_concrete
fill 274 228 242 274 235 242 minecraft:gray_concrete
fill 274 228 255 274 229 255 minecraft:light_gray_concrete
fill 275 228 261 275 229 261 minecraft:light_gray_concrete
fill 275 228 269 275 229 269 minecraft:light_gray_concrete
setblock 276 228 243 minecraft:gray_concrete
fill 276 228 249 276 229 249 minecraft:light_gray_concrete
fill 276 228 251 276 229 251 minecraft:light_gray_concrete
fill 276 228 253 276 229 253 minecraft:light_gray_concrete
fill 276 228 262 276 229 262 minecraft:light_gray_concrete
fill 276 228 264 276 229 264 minecraft:light_gray_concrete
fill 276 228 266 276 229 266 minecraft:light_gray_concrete
fill 276 228 268 276 229 268 minecraft:light_gray_concrete
fill 238 229 231 238 236 231 minecraft:light_gray_concrete
setblock 238 229 232 minecraft:light_blue_stained_glass
fill 238 229 233 242 236 233 minecraft:light_gray_concrete
setblock 238 229 234 minecraft:pearlescent_froglight
fill 238 229 235 238 236 235 minecraft:light_gray_concrete
setblock 238 229 238 minecraft:light[level=12]
setblock 238 229 245 minecraft:light[level=12]
setblock 238 229 252 minecraft:light[level=12]
setblock 238 229 259 minecraft:light[level=12]
setblock 238 229 266 minecraft:light[level=12]
setblock 239 229 231 minecraft:light_blue_stained_glass
fill 239 229 232 241 236 232 minecraft:light_gray_concrete
fill 239 229 234 241 236 234 minecraft:light_gray_concrete
setblock 239 229 235 minecraft:black_stained_glass
fill 240 229 231 240 236 231 minecraft:light_gray_concrete
fill 240 229 235 240 236 235 minecraft:light_gray_concrete
setblock 241 229 231 minecraft:black_stained_glass
setblock 241 229 235 minecraft:cyan_stained_glass
fill 242 229 231 242 236 231 minecraft:light_gray_concrete
setblock 242 229 232 minecraft:light_blue_stained_glass
setblock 242 229 234 minecraft:black_stained_glass
fill 242 229 235 242 236 235 minecraft:light_gray_concrete
setblock 245 229 231 minecraft:light[level=12]
setblock 245 229 238 minecraft:light[level=12]
setblock 245 229 245 minecraft:light[level=12]
setblock 245 229 252 minecraft:light[level=12]
setblock 245 229 266 minecraft:light[level=12]
setblock 252 229 231 minecraft:light[level=12]
setblock 252 229 238 minecraft:light[level=12]
setblock 252 229 245 minecraft:light[level=12]
setblock 252 229 252 minecraft:light[level=12]
setblock 252 229 259 minecraft:light[level=12]
setblock 252 229 266 minecraft:light[level=12]
setblock 253 229 228 minecraft:pearlescent_froglight
fill 257 229 245 257 230 245 minecraft:gray_concrete
fill 257 229 247 257 230 247 minecraft:gray_concrete
fill 257 229 249 257 230 249 minecraft:gray_concrete
fill 257 229 251 257 230 251 minecraft:gray_concrete
fill 257 229 253 257 230 253 minecraft:gray_concrete
fill 257 229 255 257 230 255 minecraft:gray_concrete
fill 257 229 257 257 230 257 minecraft:gray_concrete
fill 258 229 244 258 230 244 minecraft:gray_concrete
fill 258 229 259 258 230 259 minecraft:gray_concrete
setblock 259 229 231 minecraft:light[level=12]
setblock 259 229 238 minecraft:light[level=12]
setblock 259 229 266 minecraft:light[level=12]
fill 260 229 244 260 230 244 minecraft:gray_concrete
fill 260 229 259 260 230 259 minecraft:gray_concrete
fill 262 229 244 262 230 244 minecraft:gray_concrete
fill 262 229 259 262 230 259 minecraft:gray_concrete
fill 264 229 244 264 230 244 minecraft:gray_concrete
fill 264 229 259 264 230 259 minecraft:gray_concrete
setblock 266 229 231 minecraft:light[level=12]
setblock 266 229 238 minecraft:light[level=12]
fill 266 229 244 266 230 244 minecraft:gray_concrete
fill 266 229 259 266 230 259 minecraft:gray_concrete
setblock 266 229 266 minecraft:light[level=12]
fill 268 229 244 268 230 244 minecraft:gray_concrete
fill 268 229 259 268 230 259 minecraft:gray_concrete
fill 270 229 238 270 245 238 minecraft:gray_concrete
setblock 270 229 239 minecraft:sea_lantern
fill 270 229 240 270 248 240 minecraft:gray_concrete
setblock 270 229 241 minecraft:sea_lantern
fill 270 229 242 270 248 242 minecraft:gray_concrete
setblock 270 229 243 minecraft:sea_lantern
fill 270 229 244 270 230 244 minecraft:gray_concrete
fill 270 229 259 270 230 259 minecraft:gray_concrete
setblock 271 229 238 minecraft:sea_lantern
fill 271 229 239 271 248 239 minecraft:gray_concrete
setblock 271 229 240 minecraft:sea_lantern
fill 271 229 241 271 248 241 minecraft:gray_concrete
setblock 271 229 242 minecraft:sea_lantern
fill 271 229 243 271 232 243 minecraft:gray_concrete
fill 272 229 238 272 248 238 minecraft:gray_concrete
setblock 272 229 239 minecraft:sea_lantern
fill 272 229 240 272 248 240 minecraft:gray_concrete
setblock 272 229 241 minecraft:sea_lantern
setblock 272 229 243 minecraft:sea_lantern
fill 272 229 245 273 230 245 minecraft:gray_concrete
fill 272 229 247 273 230 247 minecraft:gray_concrete
fill 272 229 249 272 230 249 minecraft:gray_concrete
fill 272 229 251 272 230 251 minecraft:gray_concrete
fill 272 229 253 272 230 253 minecraft:gray_concrete
fill 272 229 255 272 230 255 minecraft:gray_concrete
fill 272 229 257 272 230 257 minecraft:gray_concrete
setblock 273 229 231 minecraft:light[level=12]
setblock 273 229 238 minecraft:sea_lantern
fill 273 229 239 273 248 239 minecraft:gray_concrete
setblock 273 229 240 minecraft:sea_lantern
fill 273 229 241 273 248 241 minecraft:gray_concrete
setblock 273 229 242 minecraft:sea_lantern
fill 273 229 243 273 248 243 minecraft:gray_concrete
setblock 273 229 244 minecraft:sea_lantern
setblock 273 229 246 minecraft:sea_lantern
setblock 273 229 248 minecraft:sea_lantern
setblock 273 229 259 minecraft:light[level=12]
fill 274 229 238 274 248 238 minecraft:gray_concrete
setblock 274 229 239 minecraft:sea_lantern
fill 274 229 240 274 248 240 minecraft:gray_concrete
setblock 274 229 241 minecraft:sea_lantern
setblock 274 229 243 minecraft:sea_lantern
fill 274 229 244 274 248 244 minecraft:gray_concrete
setblock 274 229 245 minecraft:sea_lantern
fill 274 229 246 274 248 246 minecraft:gray_concrete
setblock 274 229 247 minecraft:sea_lantern
fill 274 229 248 274 248 248 minecraft:gray_concrete
setblock 275 229 238 minecraft:sea_lantern
fill 275 229 239 275 248 239 minecraft:gray_concrete
setblock 275 229 240 minecraft:sea_lantern
fill 275 229 241 275 248 241 minecraft:gray_concrete
setblock 275 229 242 minecraft:sea_lantern
fill 275 229 243 275 248 243 minecraft:gray_concrete
setblock 275 229 244 minecraft:sea_lantern
fill 275 229 245 275 248 245 minecraft:gray_concrete
setblock 275 229 246 minecraft:sea_lantern
fill 275 229 247 275 248 247 minecraft:gray_concrete
setblock 275 229 248 minecraft:sea_lantern
fill 276 229 238 276 248 238 minecraft:gray_concrete
setblock 276 229 239 minecraft:sea_lantern
fill 276 229 240 276 248 240 minecraft:gray_concrete
setblock 276 229 241 minecraft:sea_lantern
fill 276 229 242 276 248 242 minecraft:gray_concrete
fill 276 229 243 276 230 243 minecraft:sea_lantern
fill 276 229 244 276 248 244 minecraft:gray_concrete
setblock 276 229 245 minecraft:sea_lantern
fill 276 229 246 276 248 246 minecraft:gray_concrete
setblock 276 229 247 minecraft:sea_lantern
fill 276 229 248 276 248 248 minecraft:gray_concrete
setblock 235 230 269 minecraft:verdant_froglight
fill 238 230 232 238 231 232 minecraft:light_gray_concrete
fill 238 230 234 238 231 234 minecraft:light_gray_concrete
fill 239 230 231 239 231 231 minecraft:light_gray_concrete
fill 239 230 235 239 231 235 minecraft:light_gray_concrete
fill 241 230 231 241 231 231 minecraft:light_gray_concrete
fill 241 230 235 241 231 235 minecraft:light_gray_concrete
fill 242 230 232 242 231 232 minecraft:light_gray_concrete
fill 242 230 234 242 231 234 minecraft:light_gray_concrete
fill 242 230 258 242 231 260 minecraft:cyan_stained_glass
fill 244 230 256 246 231 256 minecraft:cyan_stained_glass
fill 244 230 262 246 231 262 minecraft:cyan_stained_glass
setblock 246 230 270 minecraft:verdant_froglight
fill 248 230 258 248 231 260 minecraft:cyan_stained_glass
fill 253 230 228 253 308 228 minecraft:black_concrete
setblock 268 230 262 minecraft:black_stained_glass
setblock 268 230 264 minecraft:cyan_stained_glass
setblock 268 230 266 minecraft:black_stained_glass
setblock 268 230 268 minecraft:cyan_stained_glass
setblock 269 230 261 minecraft:black_stained_glass
fill 269 230 264 271 230 265 minecraft:light_gray_concrete
setblock 269 230 269 minecraft:black_stained_glass
fill 270 230 239 270 231 239 minecraft:gray_concrete
fill 270 230 241 270 231 241 minecraft:gray_concrete
fill 270 230 243 270 231 243 minecraft:gray_concrete
fill 271 230 238 271 231 238 minecraft:gray_concrete
fill 271 230 240 271 231 240 minecraft:gray_concrete
fill 271 230 242 271 231 242 minecraft:gray_concrete
setblock 271 230 261 minecraft:cyan_stained_glass
fill 271 230 262 271 230 263 minecraft:light_gray_concrete
setblock 271 230 269 minecraft:light_blue_stained_glass
fill 272 230 239 272 231 239 minecraft:gray_concrete
fill 272 230 241 272 231 241 minecraft:gray_concrete
setblock 272 230 242 minecraft:black_stained_glass
fill 272 230 243 272 231 243 minecraft:gray_concrete
fill 272 230 262 272 231 265 minecraft:sea_lantern
fill 273 230 238 273 231 238 minecraft:gray_concrete
fill 273 230 240 273 231 240 minecraft:gray_concrete
fill 273 230 242 273 231 242 minecraft:gray_concrete
fill 273 230 244 273 231 244 minecraft:gray_concrete
fill 273 230 246 273 231 246 minecraft:gray_concrete
fill 273 230 248 273 231 248 minecraft:gray_concrete
fill 273 230 250 275 230 250 minecraft:light_gray_concrete
fill 273 230 251 273 231 257 minecraft:sea_lantern
setblock 273 230 261 minecraft:magenta_stained_glass
fill 273 230 262 273 230 265 minecraft:light_gray_concrete
setblock 273 230 269 minecraft:black_stained_glass
fill 274 230 239 274 231 239 minecraft:gray_concrete
fill 274 230 241 274 231 241 minecraft:gray_concrete
fill 274 230 243 274 231 243 minecraft:gray_concrete
fill 274 230 245 274 231 245 minecraft:gray_concrete
fill 274 230 247 274 231 247 minecraft:gray_concrete
fill 274 230 251 275 230 254 minecraft:light_gray_concrete
fill 274 230 255 274 233 255 minecraft:light_blue_stained_glass
fill 274 230 262 275 237 264 minecraft:light_gray_concrete
fill 275 230 238 275 231 238 minecraft:gray_concrete
fill 275 230 240 275 231 240 minecraft:gray_concrete
fill 275 230 242 275 231 242 minecraft:gray_concrete
fill 275 230 244 275 231 244 minecraft:gray_concrete
fill 275 230 246 275 231 246 minecraft:gray_concrete
fill 275 230 248 275 231 248 minecraft:gray_concrete
setblock 275 230 261 minecraft:magenta_stained_glass
setblock 275 230 269 minecraft:light_blue_stained_glass
fill 276 230 239 276 231 239 minecraft:gray_concrete
fill 276 230 241 276 231 241 minecraft:gray_concrete
setblock 276 230 245 minecraft:pearlescent_froglight
setblock 276 230 247 minecraft:black_stained_glass
setblock 276 230 249 minecraft:magenta_stained_glass
setblock 276 230 251 minecraft:black_stained_glass
setblock 276 230 253 minecraft:cyan_stained_glass
setblock 276 230 262 minecraft:black_stained_glass
setblock 276 230 264 minecraft:black_stained_glass
setblock 276 230 266 minecraft:pearlescent_froglight
setblock 276 230 268 minecraft:black_stained_glass
setblock 277 230 249 minecraft:verdant_froglight
setblock 235 231 233 minecraft:sea_lantern
setblock 235 231 245 minecraft:verdant_froglight
fill 235 231 269 235 237 269 minecraft:black_concrete
fill 243 231 257 243 231 258 minecraft:cyan_stained_glass
fill 243 231 260 243 231 261 minecraft:cyan_stained_glass
fill 244 231 257 244 232 257 minecraft:cyan_stained_glass
fill 244 231 261 244 232 261 minecraft:cyan_stained_glass
fill 246 231 257 247 231 257 minecraft:cyan_stained_glass
fill 246 231 261 247 231 261 minecraft:cyan_stained_glass
fill 246 231 270 246 232 270 minecraft:black_concrete
fill 247 231 258 247 232 258 minecraft:cyan_stained_glass
fill 247 231 260 247 232 260 minecraft:cyan_stained_glass
setblock 257 231 245 minecraft:black_stained_glass
setblock 257 231 247 minecraft:light_blue_stained_glass
setblock 257 231 249 minecraft:sea_lantern
setblock 257 231 251 minecraft:black_stained_glass
setblock 257 231 253 minecraft:black_stained_glass
setblock 257 231 255 minecraft:light_blue_stained_glass
setblock 257 231 257 minecraft:black_stained_glass
setblock 258 231 244 minecraft:black_stained_glass
setblock 258 231 259 minecraft:sea_lantern
setblock 260 231 244 minecraft:black_stained_glass
setblock 260 231 259 minecraft:black_stained_glass
setblock 261 231 228 minecraft:ochre_froglight
setblock 262 231 244 minecraft:black_stained_glass
setblock 262 231 259 minecraft:sea_lantern
setblock 264 231 244 minecraft:black_stained_glass
setblock 264 231 259 minecraft:black_stained_glass
setblock 266 231 244 minecraft:light_blue_stained_glass
setblock 266 231 259 minecraft:sea_lantern
setblock 268 231 244 minecraft:sea_lantern
setblock 268 231 259 minecraft:black_stained_glass
fill 268 231 262 268 232 262 minecraft:light_gray_concrete
fill 268 231 264 270 232 264 minecraft:light_gray_concrete
fill 268 231 266 271 232 266 minecraft:light_gray_concrete
fill 268 231 268 268 232 268 minecraft:light_gray_concrete
fill 269 231 261 269 232 261 minecraft:light_gray_concrete
fill 269 231 265 270 237 265 minecraft:light_gray_concrete
fill 269 231 269 269 232 269 minecraft:light_gray_concrete
setblock 270 231 244 minecraft:light_blue_stained_glass
setblock 270 231 259 minecraft:sea_lantern
fill 271 231 261 271 232 262 minecraft:light_gray_concrete
fill 271 231 263 271 232 265 minecraft:light_blue_stained_glass
fill 271 231 269 271 232 269 minecraft:light_gray_concrete
fill 272 231 242 272 232 242 minecraft:gray_concrete
setblock 272 231 245 minecraft:black_stained_glass
setblock 272 231 247 minecraft:light_blue_stained_glass
fill 272 231 249 274 231 249 minecraft:light_blue_stained_glass
setblock 272 231 251 minecraft:black_stained_glass
setblock 272 231 253 minecraft:sea_lantern
setblock 272 231 255 minecraft:sea_lantern
setblock 272 231 257 minecraft:black_stained_glass
fill 272 231 260 273 232 261 minecraft:light_blue_stained_glass
fill 272 231 266 272 232 266 minecraft:light_blue_stained_glass
fill 273 231 245 273 248 245 minecraft:gray_concrete
fill 273 231 247 273 248 247 minecraft:gray_concrete
fill 273 231 250 274 232 250 minecraft:light_blue_stained_glass
fill 273 231 258 273 232 259 minecraft:light_blue_stained_glass
fill 273 231 262 273 232 265 minecraft:light_blue_stained_glass
fill 273 231 266 273 237 266 minecraft:light_gray_concrete
fill 273 231 269 273 232 269 minecraft:light_gray_concrete
fill 274 231 251 274 232 254 minecraft:light_blue_stained_glass
fill 274 231 256 274 232 256 minecraft:light_blue_stained_glass
fill 275 231 249 275 233 254 minecraft:light_gray_concrete
fill 275 231 261 275 232 261 minecraft:light_gray_concrete
fill 275 231 269 275 232 269 minecraft:light_gray_concrete
setblock 276 231 243 minecraft:gray_concrete
setblock 276 231 245 minecraft:gray_concrete
setblock 276 231 247 minecraft:gray_concrete
fill 276 231 249 276 232 249 minecraft:light_gray_concrete
fill 276 231 251 276 232 251 minecraft:light_gray_concrete
fill 276 231 253 276 232 253 minecraft:light_gray_concrete
fill 276 231 262 276 232 262 minecraft:light_gray_concrete
fill 276 231 264 276 232 264 minecraft:light_gray_concrete
fill 276 231 266 276 232 266 minecraft:light_gray_concrete
fill 276 231 268 276 232 268 minecraft:light_gray_concrete
setblock 277 231 246 minecraft:ochre_froglight
fill 277 231 249 277 250 249 minecraft:black_concrete
setblock 277 231 261 minecraft:verdant_froglight
fill 235 232 233 235 236 233 minecraft:black_concrete
fill 235 232 245 235 308 245 minecraft:black_concrete
setblock 235 232 262 minecraft:sea_lantern
setblock 238 232 232 minecraft:sea_lantern
setblock 238 232 234 minecraft:magenta_stained_glass
setblock 239 232 231 minecraft:black_stained_glass
setblock 239 232 235 minecraft:cyan_stained_glass
setblock 241 232 231 minecraft:black_stained_glass
setblock 241 232 235 minecraft:sea_lantern
setblock 242 232 232 minecraft:cyan_stained_glass
setblock 242 232 234 minecraft:black_stained_glass
fill 243 232 258 246 232 260 minecraft:cyan_stained_glass
fill 245 232 257 246 232 257 minecraft:cyan_stained_glass
fill 245 232 261 246 232 261 minecraft:cyan_stained_glass
fill 247 232 229 247 233 231 minecraft:iron_block
setblock 247 232 259 minecraft:cyan_stained_glass
fill 257 232 245 257 233 245 minecraft:gray_concrete
fill 257 232 247 257 233 247 minecraft:gray_concrete
fill 257 232 249 257 233 249 minecraft:gray_concrete
fill 257 232 251 257 233 251 minecraft:gray_concrete
fill 257 232 253 257 233 253 minecraft:gray_concrete
fill 257 232 255 257 233 255 minecraft:gray_concrete
fill 257 232 257 257 233 257 minecraft:gray_concrete
fill 258 232 244 258 233 244 minecraft:gray_concrete
fill 258 232 259 258 233 259 minecraft:gray_concrete
fill 260 232 244 260 233 244 minecraft:gray_concrete
fill 260 232 259 260 233 259 minecraft:gray_concrete
fill 261 232 228 261 308 228 minecraft:black_concrete
fill 262 232 244 262 233 244 minecraft:gray_concrete
fill 262 232 259 262 233 259 minecraft:gray_concrete
fill 264 232 244 264 233 244 minecraft:gray_concrete
fill 264 232 259 264 233 259 minecraft:gray_concrete
fill 266 232 244 266 233 244 minecraft:gray_concrete
fill 266 232 259 266 233 259 minecraft:gray_concrete
fill 268 232 244 268 233 244 minecraft:gray_concrete
fill 268 232 259 268 233 259 minecraft:gray_concrete
setblock 270 232 239 minecraft:sea_lantern
setblock 270 232 241 minecraft:sea_lantern
setblock 270 232 243 minecraft:sea_lantern
fill 270 232 244 270 233 244 minecraft:gray_concrete
fill 270 232 259 270 233 259 minecraft:gray_concrete
setblock 271 232 238 minecraft:sea_lantern
setblock 271 232 240 minecraft:sea_lantern
setblock 271 232 242 minecraft:sea_lantern
setblock 272 232 239 minecraft:sea_lantern
setblock 272 232 241 minecraft:sea_lantern
setblock 272 232 243 minecraft:sea_lantern
fill 272 232 245 272 233 245 minecraft:gray_concrete
fill 272 232 247 272 233 247 minecraft:gray_concrete
fill 272 232 249 272 233 249 minecraft:gray_concrete
fill 272 232 251 272 233 251 minecraft:gray_concrete
fill 272 232 253 272 233 253 minecraft:gray_concrete
fill 272 232 255 272 233 255 minecraft:gray_concrete
fill 272 232 257 272 233 257 minecraft:gray_concrete
fill 272 232 262 272 232 265 minecraft:light_blue_stained_glass
setblock 273 232 238 minecraft:sea_lantern
setblock 273 232 240 minecraft:sea_lantern
setblock 273 232 242 minecraft:sea_lantern
setblock 273 232 244 minecraft:sea_lantern
setblock 273 232 246 minecraft:sea_lantern
setblock 273 232 248 minecraft:sea_lantern
fill 273 232 249 274 232 249 minecraft:light_blue_stained_glass
fill 273 232 251 273 232 257 minecraft:light_blue_stained_glass
setblock 274 232 239 minecraft:sea_lantern
setblock 274 232 241 minecraft:sea_lantern
setblock 274 232 243 minecraft:sea_lantern
setblock 274 232 245 minecraft:sea_lantern
setblock 274 232 247 minecraft:sea_lantern
setblock 275 232 238 minecraft:sea_lantern
setblock 275 232 240 minecraft:sea_lantern
setblock 275 232 242 minecraft:sea_lantern
setblock 275 232 244 minecraft:sea_lantern
setblock 275 232 246 minecraft:sea_lantern
setblock 275 232 248 minecraft:sea_lantern
setblock 276 232 239 minecraft:sea_lantern
setblock 276 232 241 minecraft:sea_lantern
fill 276 232 243 276 233 243 minecraft:sea_lantern
setblock 276 232 245 minecraft:sea_lantern
setblock 276 232 247 minecraft:sea_lantern
setblock 277 232 238 minecraft:cyan_concrete
fill 277 232 246 277 237 246 minecraft:black_concrete
fill 277 232 261 277 234 261 minecraft:black_concrete
setblock 235 233 231 minecraft:blue_concrete
fill 235 233 262 235 236 262 minecraft:black_concrete
setblock 235 233 265 minecraft:blue_concrete
fill 238 233 232 238 236 232 minecraft:light_gray_concrete
fill 238 233 234 238 236 234 minecraft:light_gray_concrete
fill 239 233 231 239 236 231 minecraft:light_gray_concrete
fill 239 233 235 239 236 235 minecraft:light_gray_concrete
fill 241 233 231 241 236 231 minecraft:light_gray_concrete
fill 241 233 235 241 236 235 minecraft:light_gray_concrete
fill 242 233 232 242 236 232 minecraft:light_gray_concrete
fill 242 233 234 242 236 234 minecraft:light_gray_concrete
setblock 246 233 270 minecraft:ochre_froglight
setblock 268 233 262 minecraft:cyan_stained_glass
setblock 268 233 264 minecraft:light_blue_stained_glass
setblock 268 233 266 minecraft:light_blue_stained_glass
setblock 268 233 268 minecraft:black_stained_glass
setblock 269 233 261 minecraft:cyan_stained_glass
fill 269 233 264 273 237 264 minecraft:light_gray_concrete
fill 269 233 266 272 237 266 minecraft:light_gray_concrete
setblock 269 233 269 minecraft:cyan_stained_glass
fill 270 233 239 270 234 239 minecraft:gray_concrete
fill 270 233 241 270 234 241 minecraft:gray_concrete
fill 270 233 243 270 234 243 minecraft:gray_concrete
fill 271 233 238 271 234 238 minecraft:gray_concrete
fill 271 233 240 271 234 240 minecraft:gray_concrete
fill 271 233 242 271 234 242 minecraft:gray_concrete
setblock 271 233 243 minecraft:magenta_stained_glass
setblock 271 233 261 minecraft:cyan_stained_glass
fill 271 233 262 273 237 263 minecraft:light_gray_concrete
fill 271 233 265 273 237 265 minecraft:light_gray_concrete
setblock 271 233 269 minecraft:pearlescent_froglight
fill 272 233 239 272 234 239 minecraft:gray_concrete
fill 272 233 241 272 234 241 minecraft:gray_concrete
setblock 272 233 242 minecraft:cyan_stained_glass
fill 272 233 243 272 234 243 minecraft:gray_concrete
fill 272 233 261 272 237 261 minecraft:light_gray_concrete
fill 273 233 238 273 234 238 minecraft:gray_concrete
fill 273 233 240 273 234 240 minecraft:gray_concrete
fill 273 233 242 273 234 242 minecraft:gray_concrete
fill 273 233 244 273 234 244 minecraft:gray_concrete
fill 273 233 246 273 234 246 minecraft:gray_concrete
fill 273 233 248 273 234 248 minecraft:gray_concrete
fill 273 233 249 273 233 255 minecraft:light_gray_concrete
setblock 273 233 261 minecraft:light_blue_stained_glass
setblock 273 233 269 minecraft:black_stained_glass
fill 274 233 239 274 234 239 minecraft:gray_concrete
fill 274 233 241 274 234 241 minecraft:gray_concrete
fill 274 233 243 274 234 243 minecraft:gray_concrete
fill 274 233 245 274 234 245 minecraft:gray_concrete
fill 274 233 247 274 234 247 minecraft:gray_concrete
fill 274 233 249 274 233 254 minecraft:light_gray_concrete
fill 275 233 238 275 234 238 minecraft:gray_concrete
fill 275 233 240 275 234 240 minecraft:gray_concrete
fill 275 233 242 275 234 242 minecraft:gray_concrete
fill 275 233 244 275 234 244 minecraft:gray_concrete
fill 275 233 246 275 234 246 minecraft:gray_concrete
fill 275 233 248 275 234 248 minecraft:gray_concrete
setblock 275 233 261 minecraft:ochre_froglight
setblock 275 233 269 minecraft:black_stained_glass
fill 276 233 239 276 234 239 minecraft:gray_concrete
fill 276 233 241 276 234 241 minecraft:gray_concrete
setblock 276 233 245 minecraft:magenta_stained_glass
setblock 276 233 247 minecraft:pearlescent_froglight
setblock 276 233 249 minecraft:cyan_stained_glass
setblock 276 233 251 minecraft:ochre_froglight
setblock 276 233 253 minecraft:ochre_froglight
setblock 276 233 262 minecraft:cyan_stained_glass
setblock 276 233 264 minecraft:black_stained_glass
setblock 276 233 266 minecraft:magenta_stained_glass
setblock 276 233 268 minecraft:sea_lantern
fill 277 233 238 277 308 238 minecraft:black_concrete
fill 235 234 231 235 299 231 minecraft:black_concrete
fill 235 234 265 235 248 265 minecraft:black_concrete
setblock 238 234 239 minecraft:light[level=15]
setblock 238 234 247 minecraft:light[level=15]
setblock 238 234 255 minecraft:light[level=15]
setblock 238 234 263 minecraft:light[level=15]
setblock 238 234 270 minecraft:magenta_concrete
setblock 246 234 231 minecraft:light[level=15]
setblock 246 234 239 minecraft:light[level=15]
setblock 246 234 247 minecraft:light[level=15]
setblock 246 234 255 minecraft:light[level=15]
setblock 246 234 263 minecraft:light[level=15]
fill 246 234 270 246 259 270 minecraft:black_concrete
setblock 254 234 231 minecraft:light[level=15]
setblock 254 234 239 minecraft:light[level=15]
setblock 254 234 247 minecraft:light[level=15]
setblock 254 234 255 minecraft:light[level=15]
setblock 254 234 263 minecraft:light[level=15]
setblock 257 234 245 minecraft:black_stained_glass
setblock 257 234 247 minecraft:black_stained_glass
setblock 257 234 249 minecraft:light_blue_stained_glass
setblock 257 234 251 minecraft:light_blue_stained_glass
setblock 257 234 253 minecraft:black_stained_glass
setblock 257 234 255 minecraft:sea_lantern
setblock 257 234 257 minecraft:black_stained_glass
setblock 258 234 244 minecraft:black_stained_glass
setblock 258 234 259 minecraft:black_stained_glass
setblock 260 234 244 minecraft:black_stained_glass
setblock 260 234 259 minecraft:black_stained_glass
setblock 262 234 231 minecraft:light[level=15]
setblock 262 234 239 minecraft:light[level=15]
setblock 262 234 244 minecraft:black_stained_glass
setblock 262 234 259 minecraft:black_stained_glass
setblock 262 234 263 minecraft:light[level=15]
setblock 264 234 228 minecraft:cyan_concrete
setblock 264 234 244 minecraft:light_blue_stained_glass
setblock 264 234 259 minecraft:black_stained_glass
setblock 266 234 244 minecraft:light_blue_stained_glass
setblock 266 234 259 minecraft:light_blue_stained_glass
setblock 268 234 244 minecraft:black_stained_glass
setblock 268 234 259 minecraft:black_stained_glass
fill 268 234 262 268 235 262 minecraft:light_gray_concrete
fill 268 234 264 268 235 264 minecraft:light_gray_concrete
fill 268 234 266 268 235 266 minecraft:light_gray_concrete
fill 268 234 268 268 235 268 minecraft:light_gray_concrete
fill 269 234 261 269 235 261 minecraft:light_gray_concrete
fill 269 234 269 269 235 269 minecraft:light_gray_concrete
setblock 270 234 231 minecraft:light[level=15]
setblock 270 234 244 minecraft:black_stained_glass
setblock 270 234 259 minecraft:sea_lantern
setblock 271 234 228 minecraft:purple_concrete
fill 271 234 243 271 235 243 minecraft:gray_concrete
fill 271 234 261 271 235 261 minecraft:light_gray_concrete
fill 271 234 269 271 235 269 minecraft:light_gray_concrete
fill 272 234 242 272 235 242 minecraft:gray_concrete
setblock 272 234 245 minecraft:black_stained_glass
setblock 272 234 247 minecraft:black_stained_glass
setblock 272 234 249 minecraft:black_stained_glass
setblock 272 234 251 minecraft:sea_lantern
setblock 272 234 253 minecraft:light_blue_stained_glass
setblock 272 234 255 minecraft:light_blue_stained_glass
setblock 272 234 257 minecraft:black_stained_glass
fill 273 234 249 275 235 249 minecraft:iron_block
fill 273 234 250 274 235 255 minecraft:light_gray_concrete
fill 273 234 261 273 235 261 minecraft:light_gray_concrete
fill 273 234 269 273 235 269 minecraft:light_gray_concrete
fill 275 234 250 275 263 254 minecraft:light_gray_concrete
fill 275 234 261 275 235 261 minecraft:light_gray_concrete
fill 275 234 269 275 235 269 minecraft:light_gray_concrete
setblock 276 234 243 minecraft:gray_concrete
setblock 276 234 245 minecraft:gray_concrete
setblock 276 234 247 minecraft:gray_concrete
fill 276 234 249 276 235 249 minecraft:light_gray_concrete
fill 276 234 251 276 235 251 minecraft:light_gray_concrete
fill 276 234 253 276 235 253 minecraft:light_gray_concrete
fill 276 234 262 276 235 262 minecraft:light_gray_concrete
fill 276 234 264 276 235 264 minecraft:light_gray_concrete
fill 276 234 266 276 235 266 minecraft:light_gray_concrete
fill 276 234 268 276 235 268 minecraft:light_gray_concrete
setblock 277 234 241 minecraft:verdant_froglight
setblock 238 235 238 minecraft:light[level=12]
setblock 238 235 245 minecraft:light[level=12]
setblock 238 235 252 minecraft:light[level=12]
setblock 238 235 259 minecraft:light[level=12]
setblock 238 235 266 minecraft:light[level=12]
fill 238 235 270 238 272 270 minecraft:black_concrete
fill 245 235 229 246 236 231 minecraft:gray_concrete
setblock 245 235 238 minecraft:light[level=12]
setblock 245 235 245 minecraft:light[level=12]
setblock 245 235 252 minecraft:light[level=12]
setblock 245 235 259 minecraft:light[level=12]
setblock 245 235 266 minecraft:light[level=12]
fill 246 235 232 246 236 246 minecraft:gray_concrete
setblock 252 235 231 minecraft:light[level=12]
setblock 252 235 238 minecraft:light[level=12]
setblock 252 235 245 minecraft:light[level=12]
setblock 252 235 252 minecraft:light[level=12]
setblock 252 235 259 minecraft:light[level=12]
setblock 252 235 266 minecraft:light[level=12]
fill 257 235 245 257 238 245 minecraft:gray_concrete
fill 257 235 247 257 238 247 minecraft:gray_concrete
fill 257 235 249 257 238 249 minecraft:gray_concrete
fill 257 235 251 257 238 251 minecraft:gray_concrete
fill 257 235 253 257 238 253 minecraft:gray_concrete
fill 257 235 255 257 238 255 minecraft:gray_concrete
fill 257 235 257 257 238 257 minecraft:gray_concrete
fill 258 235 244 258 237 244 minecraft:gray_concrete
fill 258 235 259 258 238 259 minecraft:gray_concrete
setblock 259 235 231 minecraft:light[level=12]
setblock 259 235 238 minecraft:light[level=12]
setblock 259 235 266 minecraft:light[level=12]
fill 260 235 244 260 237 244 minecraft:gray_concrete
fill 260 235 259 260 238 259 minecraft:gray_concrete
fill 262 235 244 262 237 244 minecraft:gray_concrete
fill 262 235 259 262 238 259 minecraft:gray_concrete
fill 264 235 228 264 308 228 minecraft:black_concrete
fill 264 235 244 264 237 244 minecraft:gray_concrete
fill 264 235 259 264 238 259 minecraft:gray_concrete
setblock 266 235 231 minecraft:light[level=12]
setblock 266 235 238 minecraft:light[level=12]
fill 266 235 244 266 237 244 minecraft:gray_concrete
fill 266 235 259 266 238 259 minecraft:gray_concrete
setblock 266 235 266 minecraft:light[level=12]
fill 268 235 244 268 237 244 minecraft:gray_concrete
fill 268 235 259 268 238 259 minecraft:gray_concrete
setblock 270 235 239 minecraft:sea_lantern
setblock 270 235 241 minecraft:sea_lantern
setblock 270 235 243 minecraft:sea_lantern
fill 270 235 244 270 237 244 minecraft:gray_concrete
fill 270 235 259 270 238 259 minecraft:gray_concrete
fill 271 235 228 271 267 228 minecraft:black_concrete
setblock 271 235 238 minecraft:sea_lantern
setblock 271 235 240 minecraft:sea_lantern
setblock 271 235 242 minecraft:sea_lantern
setblock 272 235 239 minecraft:sea_lantern
setblock 272 235 241 minecraft:sea_lantern
setblock 272 235 243 minecraft:sea_lantern
fill 272 235 245 272 240 245 minecraft:gray_concrete
fill 272 235 247 272 240 247 minecraft:gray_concrete
fill 272 235 249 272 238 249 minecraft:gray_concrete
fill 272 235 251 272 238 251 minecraft:gray_concrete
fill 272 235 253 272 238 253 minecraft:gray_concrete
fill 272 235 255 272 238 255 minecraft:gray_concrete
fill 272 235 257 272 238 257 minecraft:gray_concrete
setblock 273 235 231 minecraft:light[level=12]
setblock 273 235 238 minecraft:sea_lantern
setblock 273 235 240 minecraft:sea_lantern
setblock 273 235 242 minecraft:sea_lantern
setblock 273 235 244 minecraft:sea_lantern
setblock 273 235 246 minecraft:sea_lantern
setblock 273 235 248 minecraft:sea_lantern
setblock 273 235 259 minecraft:light[level=12]
setblock 274 235 239 minecraft:sea_lantern
setblock 274 235 241 minecraft:sea_lantern
setblock 274 235 243 minecraft:sea_lantern
setblock 274 235 245 minecraft:sea_lantern
setblock 274 235 247 minecraft:sea_lantern
setblock 275 235 238 minecraft:sea_lantern
setblock 275 235 240 minecraft:sea_lantern
setblock 275 235 242 minecraft:sea_lantern
setblock 275 235 244 minecraft:sea_lantern
setblock 275 235 246 minecraft:sea_lantern
setblock 275 235 248 minecraft:sea_lantern
setblock 276 235 239 minecraft:sea_lantern
setblock 276 235 241 minecraft:sea_lantern
setblock 276 235 243 minecraft:sea_lantern
fill 276 235 245 276 236 245 minecraft:sea_lantern
setblock 276 235 247 minecraft:sea_lantern
fill 277 235 241 277 245 241 minecraft:black_concrete
setblock 277 235 261 minecraft:sea_lantern
setblock 277 235 266 minecraft:sea_lantern
setblock 235 236 247 minecraft:cyan_concrete
setblock 235 236 248 minecraft:sea_lantern
fill 245 236 232 245 236 235 minecraft:gray_concrete
setblock 245 236 270 minecraft:sea_lantern
fill 246 236 247 247 236 264 minecraft:gray_concrete
fill 247 236 239 247 236 246 minecraft:gray_concrete
fill 247 236 265 247 237 269 minecraft:gray_concrete
setblock 268 236 262 minecraft:pearlescent_froglight
setblock 268 236 264 minecraft:light_blue_stained_glass
setblock 268 236 266 minecraft:sea_lantern
setblock 268 236 268 minecraft:pearlescent_froglight
setblock 269 236 261 minecraft:black_stained_glass
setblock 269 236 269 minecraft:pearlescent_froglight
fill 270 236 239 270 237 239 minecraft:gray_concrete
fill 270 236 241 270 237 241 minecraft:gray_concrete
fill 270 236 243 270 237 243 minecraft:gray_concrete
fill 271 236 238 271 237 238 minecraft:gray_concrete
fill 271 236 240 271 237 240 minecraft:gray_concrete
fill 271 236 242 271 237 242 minecraft:gray_concrete
setblock 271 236 243 minecraft:sea_lantern
setblock 271 236 261 minecraft:sea_lantern
setblock 271 236 269 minecraft:cyan_stained_glass
fill 272 236 239 272 237 239 minecraft:gray_concrete
fill 272 236 241 272 237 241 minecraft:gray_concrete
setblock 272 236 242 minecraft:magenta_stained_glass
fill 272 236 243 272 237 243 minecraft:gray_concrete
fill 273 236 238 273 237 238 minecraft:gray_concrete
fill 273 236 240 273 237 240 minecraft:gray_concrete
fill 273 236 242 273 237 242 minecraft:gray_concrete
fill 273 236 244 273 237 244 minecraft:gray_concrete
fill 273 236 246 273 237 246 minecraft:gray_concrete
fill 273 236 248 273 237 248 minecraft:gray_concrete
fill 273 236 249 273 263 255 minecraft:light_gray_concrete
setblock 273 236 261 minecraft:magenta_stained_glass
setblock 273 236 269 minecraft:magenta_stained_glass
fill 274 236 239 274 237 239 minecraft:gray_concrete
fill 274 236 241 274 237 241 minecraft:gray_concrete
setblock 274 236 242 minecraft:magenta_stained_glass
fill 274 236 243 274 237 243 minecraft:gray_concrete
fill 274 236 245 274 237 245 minecraft:gray_concrete
fill 274 236 247 274 237 247 minecraft:gray_concrete
fill 274 236 249 274 263 254 minecraft:light_gray_concrete
setblock 274 236 255 minecraft:black_stained_glass
fill 275 236 238 275 237 238 minecraft:gray_concrete
fill 275 236 240 275 237 240 minecraft:gray_concrete
fill 275 236 242 275 237 242 minecraft:gray_concrete
fill 275 236 244 275 237 244 minecraft:gray_concrete
fill 275 236 246 275 237 246 minecraft:gray_concrete
fill 275 236 248 275 237 248 minecraft:gray_concrete
fill 275 236 249 275 263 249 minecraft:light_gray_concrete
setblock 275 236 261 minecraft:light_blue_stained_glass
setblock 275 236 269 minecraft:black_stained_glass
fill 276 236 239 276 237 239 minecraft:gray_concrete
fill 276 236 241 276 237 241 minecraft:gray_concrete
setblock 276 236 243 minecraft:pearlescent_froglight
setblock 276 236 247 minecraft:black_stained_glass
setblock 276 236 249 minecraft:pearlescent_froglight
setblock 276 236 251 minecraft:black_stained_glass
setblock 276 236 253 minecraft:sea_lantern
setblock 276 236 262 minecraft:pearlescent_froglight
setblock 276 236 264 minecraft:black_stained_glass
setblock 276 236 266 minecraft:sea_lantern
setblock 276 236 268 minecraft:black_stained_glass
fill 277 236 261 277 251 261 minecraft:black_concrete
fill 277 236 266 277 237 266 minecraft:black_concrete
setblock 235 237 233 minecraft:blue_concrete
fill 235 237 247 235 308 248 minecraft:black_concrete
setblock 235 237 262 minecraft:purple_concrete
fill 245 237 270 245 297 270 minecraft:black_concrete
fill 246 237 229 246 237 248 minecraft:magenta_concrete
fill 247 237 254 247 237 264 minecraft:gray_concrete
setblock 268 237 262 minecraft:light_gray_concrete
setblock 268 237 264 minecraft:light_gray_concrete
setblock 268 237 266 minecraft:light_gray_concrete
setblock 268 237 268 minecraft:light_gray_concrete
setblock 269 237 261 minecraft:light_gray_concrete
setblock 269 237 269 minecraft:light_gray_concrete
fill 271 237 243 271 238 243 minecraft:gray_concrete
setblock 271 237 261 minecraft:light_gray_concrete
setblock 271 237 269 minecraft:light_gray_concrete
fill 272 237 242 272 238 242 minecraft:gray_concrete
setblock 273 237 261 minecraft:light_gray_concrete
setblock 273 237 269 minecraft:light_gray_concrete
fill 274 237 242 274 238 242 minecraft:gray_concrete
fill 274 237 255 274 238 255 minecraft:light_gray_concrete
setblock 275 237 261 minecraft:light_gray_concrete
setblock 275 237 269 minecraft:light_gray_concrete
setblock 276 237 243 minecraft:gray_concrete
setblock 276 237 245 minecraft:gray_concrete
setblock 276 237 247 minecraft:gray_concrete
fill 276 237 249 276 238 249 minecraft:light_gray_concrete
fill 276 237 251 276 238 251 minecraft:light_gray_concrete
fill 276 237 253 276 238 253 minecraft:light_gray_concrete
setblock 276 237 262 minecraft:light_gray_concrete
setblock 276 237 264 minecraft:light_gray_concrete
setblock 276 237 266 minecraft:light_gray_concrete
setblock 276 237 268 minecraft:light_gray_concrete
setblock 277 237 262 minecraft:purple_concrete
fill 235 238 233 235 261 233 minecraft:black_concrete
setblock 235 238 243 minecraft:purple_concrete
setblock 235 238 257 minecraft:magenta_concrete
fill 235 238 262 235 264 262 minecraft:black_concrete
setblock 235 238 269 minecraft:verdant_froglight
fill 237 238 260 237 248 260 minecraft:cyan_wool
setblock 238 238 228 minecraft:magenta_concrete
setblock 240 238 233 minecraft:redstone_block
fill 247 238 257 247 238 269 minecraft:magenta_concrete
fill 257 238 244 272 238 244 minecraft:yellow_concrete
fill 268 238 261 276 238 269 minecraft:black_concrete
setblock 270 238 239 minecraft:sea_lantern
setblock 270 238 241 minecraft:sea_lantern
setblock 270 238 243 minecraft:sea_lantern
setblock 271 238 238 minecraft:sea_lantern
setblock 271 238 240 minecraft:sea_lantern
setblock 271 238 242 minecraft:sea_lantern
setblock 272 238 239 minecraft:sea_lantern
setblock 272 238 241 minecraft:sea_lantern
setblock 272 238 243 minecraft:sea_lantern
setblock 273 238 238 minecraft:sea_lantern
setblock 273 238 240 minecraft:sea_lantern
setblock 273 238 242 minecraft:sea_lantern
setblock 273 238 244 minecraft:sea_lantern
setblock 273 238 246 minecraft:sea_lantern
setblock 273 238 248 minecraft:sea_lantern
setblock 274 238 239 minecraft:sea_lantern
setblock 274 238 241 minecraft:sea_lantern
setblock 274 238 243 minecraft:sea_lantern
setblock 274 238 245 minecraft:sea_lantern
setblock 274 238 247 minecraft:sea_lantern
setblock 275 238 238 minecraft:sea_lantern
setblock 275 238 240 minecraft:sea_lantern
setblock 275 238 242 minecraft:sea_lantern
setblock 275 238 244 minecraft:sea_lantern
setblock 275 238 246 minecraft:sea_lantern
setblock 275 238 248 minecraft:sea_lantern
setblock 276 238 239 minecraft:sea_lantern
setblock 276 238 241 minecraft:sea_lantern
setblock 276 238 243 minecraft:sea_lantern
setblock 276 238 245 minecraft:sea_lantern
setblock 276 238 247 minecraft:sea_lantern
setblock 277 238 246 minecraft:cyan_concrete
setblock 277 238 254 minecraft:pearlescent_froglight
fill 277 238 262 277 308 262 minecraft:black_concrete
setblock 277 238 266 minecraft:purple_concrete
fill 235 239 243 235 261 243 minecraft:black_concrete
fill 235 239 257 235 308 257 minecraft:black_concrete
fill 235 239 269 235 293 269 minecraft:black_concrete
fill 236 239 258 236 240 258 minecraft:iron_block
fill 237 239 258 237 248 259 minecraft:cyan_wool
fill 237 239 261 237 248 262 minecraft:cyan_wool
fill 238 239 228 238 255 228 minecraft:black_concrete
fill 238 239 258 238 240 258 minecraft:iron_block
setblock 255 239 270 minecraft:magenta_concrete
fill 268 239 261 268 239 269 minecraft:pearlescent_froglight
fill 269 239 261 276 239 261 minecraft:pearlescent_froglight
fill 269 239 269 276 239 269 minecraft:pearlescent_froglight
fill 270 239 239 270 240 239 minecraft:gray_concrete
fill 270 239 241 270 240 241 minecraft:gray_concrete
fill 270 239 243 270 240 248 minecraft:gray_concrete
fill 271 239 238 271 240 238 minecraft:gray_concrete
fill 271 239 240 271 240 240 minecraft:gray_concrete
fill 271 239 242 271 240 242 minecraft:gray_concrete
setblock 271 239 243 minecraft:pearlescent_froglight
fill 271 239 244 273 240 244 minecraft:gray_concrete
setblock 271 239 245 minecraft:cyan_stained_glass
fill 271 239 246 271 240 246 minecraft:gray_concrete
setblock 271 239 247 minecraft:black_stained_glass
fill 271 239 248 271 240 248 minecraft:gray_concrete
setblock 271 239 249 minecraft:magenta_stained_glass
fill 271 239 250 272 263 250 minecraft:light_gray_concrete
setblock 271 239 251 minecraft:black_stained_glass
fill 271 239 252 272 263 252 minecraft:light_gray_concrete
setblock 271 239 253 minecraft:cyan_stained_glass
fill 271 239 254 271 263 255 minecraft:light_gray_concrete
fill 272 239 239 272 240 239 minecraft:gray_concrete
fill 272 239 241 272 240 241 minecraft:gray_concrete
setblock 272 239 242 minecraft:cyan_stained_glass
fill 272 239 243 272 240 243 minecraft:gray_concrete
fill 272 239 249 272 263 249 minecraft:light_gray_concrete
fill 272 239 251 272 263 251 minecraft:light_gray_concrete
fill 272 239 253 272 263 254 minecraft:light_gray_concrete
setblock 272 239 255 minecraft:black_stained_glass
fill 272 239 265 272 249 265 minecraft:iron_bars
fill 273 239 238 273 240 238 minecraft:gray_concrete
fill 273 239 240 273 240 240 minecraft:gray_concrete
fill 273 239 242 273 240 242 minecraft:gray_concrete
fill 273 239 246 273 240 246 minecraft:gray_concrete
fill 273 239 248 273 240 248 minecraft:gray_concrete
fill 274 239 239 274 240 239 minecraft:gray_concrete
fill 274 239 241 274 240 241 minecraft:gray_concrete
setblock 274 239 242 minecraft:black_stained_glass
fill 274 239 243 274 240 243 minecraft:gray_concrete
fill 274 239 245 274 240 245 minecraft:gray_concrete
fill 274 239 247 274 240 247 minecraft:gray_concrete
setblock 274 239 255 minecraft:ochre_froglight
fill 275 239 238 275 240 238 minecraft:gray_concrete
fill 275 239 240 275 240 240 minecraft:gray_concrete
fill 275 239 242 275 240 242 minecraft:gray_concrete
fill 275 239 244 275 240 244 minecraft:gray_concrete
fill 275 239 246 275 240 246 minecraft:gray_concrete
fill 275 239 248 275 240 248 minecraft:gray_concrete
fill 276 239 239 276 240 239 minecraft:gray_concrete
fill 276 239 241 276 240 241 minecraft:gray_concrete
setblock 276 239 243 minecraft:black_stained_glass
setblock 276 239 245 minecraft:black_stained_glass
setblock 276 239 247 minecraft:black_stained_glass
setblock 276 239 249 minecraft:pearlescent_froglight
setblock 276 239 251 minecraft:pearlescent_froglight
setblock 276 239 253 minecraft:black_stained_glass
fill 276 239 262 276 239 268 minecraft:pearlescent_froglight
fill 277 239 246 277 276 246 minecraft:black_concrete
fill 277 239 254 277 308 254 minecraft:black_concrete
fill 277 239 266 277 247 266 minecraft:black_concrete
fill 255 240 270 255 253 270 minecraft:black_concrete
setblock 261 240 270 minecraft:purple_concrete
setblock 266 240 270 minecraft:pearlescent_froglight
fill 271 240 243 271 241 243 minecraft:gray_concrete
fill 271 240 245 271 241 245 minecraft:gray_concrete
fill 271 240 247 271 241 247 minecraft:gray_concrete
fill 271 240 249 271 241 249 minecraft:light_gray_concrete
fill 271 240 251 271 241 251 minecraft:light_gray_concrete
fill 271 240 253 271 241 253 minecraft:light_gray_concrete
fill 272 240 242 272 241 242 minecraft:gray_concrete
fill 272 240 255 272 241 255 minecraft:light_gray_concrete
fill 274 240 242 274 244 242 minecraft:gray_concrete
fill 274 240 255 274 241 255 minecraft:light_gray_concrete
setblock 276 240 243 minecraft:gray_concrete
setblock 276 240 245 minecraft:gray_concrete
setblock 276 240 247 minecraft:gray_concrete
fill 276 240 249 276 241 249 minecraft:light_gray_concrete
fill 276 240 251 276 241 251 minecraft:light_gray_concrete
fill 276 240 253 276 241 253 minecraft:light_gray_concrete
setblock 277 240 252 minecraft:verdant_froglight
setblock 238 241 231 minecraft:light[level=15]
setblock 238 241 238 minecraft:light[level=12]
setblock 238 241 239 minecraft:light[level=15]
setblock 238 241 245 minecraft:light[level=12]
setblock 238 241 247 minecraft:light[level=15]
setblock 238 241 252 minecraft:light[level=12]
setblock 238 241 255 minecraft:light[level=15]
setblock 238 241 259 minecraft:light[level=12]
setblock 238 241 263 minecraft:light[level=15]
setblock 238 241 266 minecraft:light[level=12]
setblock 245 241 231 minecraft:light[level=12]
setblock 245 241 238 minecraft:light[level=12]
setblock 245 241 245 minecraft:light[level=12]
setblock 245 241 252 minecraft:light[level=12]
setblock 245 241 259 minecraft:light[level=12]
setblock 245 241 266 minecraft:light[level=12]
setblock 246 241 231 minecraft:light[level=15]
setblock 246 241 239 minecraft:light[level=15]
setblock 246 241 247 minecraft:light[level=15]
setblock 246 241 255 minecraft:light[level=15]
setblock 246 241 263 minecraft:light[level=15]
setblock 252 241 231 minecraft:light[level=12]
setblock 252 241 238 minecraft:light[level=12]
setblock 252 241 245 minecraft:light[level=12]
setblock 252 241 252 minecraft:light[level=12]
setblock 252 241 259 minecraft:light[level=12]
setblock 252 241 266 minecraft:light[level=12]
setblock 254 241 231 minecraft:light[level=15]
setblock 254 241 239 minecraft:light[level=15]
setblock 254 241 247 minecraft:light[level=15]
setblock 254 241 255 minecraft:light[level=15]
setblock 254 241 263 minecraft:light[level=15]
setblock 259 241 231 minecraft:light[level=12]
setblock 259 241 238 minecraft:light[level=12]
setblock 259 241 245 minecraft:light[level=12]
setblock 259 241 252 minecraft:light[level=12]
setblock 259 241 259 minecraft:light[level=12]
setblock 259 241 266 minecraft:light[level=12]
fill 261 241 270 261 292 270 minecraft:black_concrete
setblock 262 241 231 minecraft:light[level=15]
setblock 262 241 239 minecraft:light[level=15]
setblock 262 241 247 minecraft:light[level=15]
setblock 262 241 255 minecraft:light[level=15]
setblock 262 241 263 minecraft:light[level=15]
setblock 266 241 231 minecraft:light[level=12]
setblock 266 241 238 minecraft:light[level=12]
setblock 266 241 245 minecraft:light[level=12]
setblock 266 241 252 minecraft:light[level=12]
setblock 266 241 259 minecraft:light[level=12]
setblock 266 241 266 minecraft:light[level=12]
fill 266 241 270 266 260 270 minecraft:black_concrete
setblock 269 241 270 minecraft:purple_concrete
setblock 270 241 231 minecraft:light[level=15]
setblock 270 241 239 minecraft:sea_lantern
setblock 270 241 241 minecraft:sea_lantern
setblock 270 241 243 minecraft:sea_lantern
fill 270 241 244 270 248 244 minecraft:gray_concrete
setblock 270 241 245 minecraft:sea_lantern
fill 270 241 246 270 248 246 minecraft:gray_concrete
setblock 270 241 247 minecraft:sea_lantern
fill 270 241 248 270 248 248 minecraft:gray_concrete
setblock 270 241 255 minecraft:light[level=15]
setblock 270 241 263 minecraft:light[level=15]
setblock 271 241 238 minecraft:sea_lantern
setblock 271 241 240 minecraft:sea_lantern
setblock 271 241 242 minecraft:sea_lantern
setblock 271 241 244 minecraft:sea_lantern
setblock 271 241 246 minecraft:sea_lantern
setblock 271 241 248 minecraft:sea_lantern
setblock 272 241 239 minecraft:sea_lantern
setblock 272 241 241 minecraft:sea_lantern
setblock 272 241 243 minecraft:sea_lantern
fill 272 241 244 272 248 244 minecraft:gray_concrete
setblock 272 241 245 minecraft:sea_lantern
setblock 272 241 247 minecraft:sea_lantern
setblock 273 241 231 minecraft:light[level=12]
setblock 273 241 238 minecraft:sea_lantern
setblock 273 241 240 minecraft:sea_lantern
setblock 273 241 242 minecraft:sea_lantern
setblock 273 241 244 minecraft:sea_lantern
setblock 273 241 246 minecraft:sea_lantern
setblock 273 241 248 minecraft:sea_lantern
setblock 273 241 259 minecraft:light[level=12]
setblock 273 241 266 minecraft:light[level=12]
setblock 274 241 239 minecraft:sea_lantern
setblock 274 241 241 minecraft:sea_lantern
setblock 274 241 243 minecraft:sea_lantern
setblock 274 241 245 minecraft:sea_lantern
setblock 274 241 247 minecraft:sea_lantern
setblock 275 241 238 minecraft:sea_lantern
setblock 275 241 240 minecraft:sea_lantern
setblock 275 241 242 minecraft:sea_lantern
setblock 275 241 244 minecraft:sea_lantern
setblock 275 241 246 minecraft:sea_lantern
setblock 275 241 248 minecraft:sea_lantern
setblock 276 241 239 minecraft:sea_lantern
setblock 276 241 241 minecraft:sea_lantern
setblock 276 241 243 minecraft:sea_lantern
setblock 276 241 245 minecraft:sea_lantern
setblock 276 241 247 minecraft:sea_lantern
fill 277 241 252 277 308 252 minecraft:black_concrete
setblock 241 242 270 minecraft:sea_lantern
setblock 245 242 228 minecraft:cyan_concrete
fill 269 242 270 269 246 270 minecraft:black_concrete
fill 270 242 239 270 243 239 minecraft:gray_concrete
fill 270 242 241 270 243 241 minecraft:gray_concrete
fill 270 242 243 270 243 243 minecraft:gray_concrete
fill 270 242 245 270 243 245 minecraft:gray_concrete
fill 270 242 247 270 243 247 minecraft:gray_concrete
fill 271 242 238 271 243 238 minecraft:gray_concrete
fill 271 242 240 271 243 240 minecraft:gray_concrete
fill 271 242 242 271 243 242 minecraft:gray_concrete
setblock 271 242 243 minecraft:black_stained_glass
fill 271 242 244 271 243 244 minecraft:gray_concrete
setblock 271 242 245 minecraft:black_stained_glass
fill 271 242 246 271 243 246 minecraft:gray_concrete
setblock 271 242 247 minecraft:black_stained_glass
fill 271 242 248 271 243 248 minecraft:gray_concrete
setblock 271 242 249 minecraft:black_stained_glass
setblock 271 242 251 minecraft:sea_lantern
setblock 271 242 253 minecraft:black_stained_glass
fill 272 242 239 272 243 239 minecraft:gray_concrete
fill 272 242 241 272 243 241 minecraft:gray_concrete
setblock 272 242 242 minecraft:black_stained_glass
fill 272 242 243 272 243 243 minecraft:gray_concrete
fill 272 242 245 272 243 245 minecraft:gray_concrete
fill 272 242 247 272 243 247 minecraft:gray_concrete
setblock 272 242 255 minecraft:black_stained_glass
fill 273 242 238 273 243 238 minecraft:gray_concrete
fill 273 242 240 273 243 240 minecraft:gray_concrete
fill 273 242 242 273 243 242 minecraft:gray_concrete
fill 273 242 244 273 243 244 minecraft:gray_concrete
fill 273 242 246 273 243 246 minecraft:gray_concrete
fill 273 242 248 273 243 248 minecraft:gray_concrete
fill 274 242 239 274 243 239 minecraft:gray_concrete
fill 274 242 241 274 243 241 minecraft:gray_concrete
fill 274 242 243 274 243 243 minecraft:gray_concrete
fill 274 242 245 274 243 245 minecraft:gray_concrete
fill 274 242 247 274 243 247 minecraft:gray_concrete
setblock 274 242 255 minecraft:cyan_stained_glass
fill 275 242 238 275 243 238 minecraft:gray_concrete
fill 275 242 240 275 243 240 minecraft:gray_concrete
fill 275 242 242 275 243 242 minecraft:gray_concrete
fill 275 242 244 275 243 244 minecraft:gray_concrete
fill 275 242 246 275 243 246 minecraft:gray_concrete
fill 275 242 248 275 243 248 minecraft:gray_concrete
fill 276 242 239 276 243 239 minecraft:gray_concrete
fill 276 242 241 276 243 241 minecraft:gray_concrete
setblock 276 242 243 minecraft:black_stained_glass
setblock 276 242 245 minecraft:black_stained_glass
setblock 276 242 247 minecraft:black_stained_glass
setblock 276 242 249 minecraft:cyan_stained_glass
setblock 276 242 251 minecraft:cyan_stained_glass
setblock 276 242 253 minecraft:light_blue_stained_glass
setblock 277 242 229 minecraft:verdant_froglight
setblock 277 242 260 minecraft:verdant_froglight
fill 241 243 270 241 262 270 minecraft:black_concrete
fill 245 243 228 245 288 228 minecraft:black_concrete
fill 264 243 237 268 243 239 minecraft:cyan_stained_glass
fill 265 243 236 267 243 236 minecraft:cyan_stained_glass
fill 265 243 240 267 243 240 minecraft:cyan_stained_glass
fill 271 243 243 271 244 243 minecraft:gray_concrete
fill 271 243 245 271 244 245 minecraft:gray_concrete
fill 271 243 247 271 244 247 minecraft:gray_concrete
fill 271 243 249 271 244 249 minecraft:light_gray_concrete
fill 271 243 251 271 244 251 minecraft:light_gray_concrete
fill 271 243 253 271 244 253 minecraft:light_gray_concrete
fill 272 243 242 272 244 242 minecraft:gray_concrete
fill 272 243 255 272 244 255 minecraft:light_gray_concrete
fill 274 243 255 274 244 255 minecraft:light_gray_concrete
setblock 276 243 243 minecraft:gray_concrete
setblock 276 243 245 minecraft:gray_concrete
setblock 276 243 247 minecraft:gray_concrete
fill 276 243 249 276 244 249 minecraft:light_gray_concrete
fill 276 243 251 276 244 251 minecraft:light_gray_concrete
fill 276 243 253 276 244 253 minecraft:light_gray_concrete
fill 277 243 229 277 270 229 minecraft:black_concrete
setblock 277 243 248 minecraft:ochre_froglight
fill 277 243 260 277 265 260 minecraft:black_concrete
setblock 260 244 270 minecraft:ochre_froglight
fill 263 244 237 263 245 239 minecraft:cyan_stained_glass
fill 264 244 236 264 244 237 minecraft:cyan_stained_glass
fill 264 244 239 264 244 240 minecraft:cyan_stained_glass
fill 265 244 235 265 244 236 minecraft:cyan_stained_glass
fill 265 244 240 265 244 241 minecraft:cyan_stained_glass
setblock 266 244 228 minecraft:verdant_froglight
fill 266 244 235 267 245 235 minecraft:cyan_stained_glass
fill 266 244 241 267 245 241 minecraft:cyan_stained_glass
fill 267 244 236 268 244 236 minecraft:cyan_stained_glass
fill 267 244 240 268 244 240 minecraft:cyan_stained_glass
fill 268 244 237 269 244 237 minecraft:cyan_stained_glass
fill 268 244 239 269 244 239 minecraft:cyan_stained_glass
fill 269 244 238 269 245 238 minecraft:cyan_stained_glass
setblock 270 244 239 minecraft:sea_lantern
setblock 270 244 241 minecraft:sea_lantern
setblock 270 244 243 minecraft:sea_lantern
setblock 270 244 245 minecraft:sea_lantern
setblock 270 244 247 minecraft:sea_lantern
setblock 271 244 238 minecraft:sea_lantern
setblock 271 244 240 minecraft:sea_lantern
setblock 271 244 242 minecraft:sea_lantern
setblock 271 244 244 minecraft:sea_lantern
setblock 271 244 246 minecraft:sea_lantern
setblock 271 244 248 minecraft:sea_lantern
setblock 272 244 239 minecraft:sea_lantern
setblock 272 244 241 minecraft:sea_lantern
setblock 272 244 243 minecraft:sea_lantern
setblock 272 244 245 minecraft:sea_lantern
setblock 272 244 247 minecraft:sea_lantern
setblock 272 244 270 minecraft:pearlescent_froglight
setblock 273 244 238 minecraft:sea_lantern
setblock 273 244 240 minecraft:sea_lantern
setblock 273 244 242 minecraft:sea_lantern
setblock 273 244 244 minecraft:sea_lantern
setblock 273 244 246 minecraft:sea_lantern
setblock 273 244 248 minecraft:sea_lantern
setblock 274 244 239 minecraft:sea_lantern
setblock 274 244 241 minecraft:sea_lantern
setblock 274 244 243 minecraft:sea_lantern
setblock 274 244 245 minecraft:sea_lantern
setblock 274 244 247 minecraft:sea_lantern
setblock 275 244 238 minecraft:sea_lantern
setblock 275 244 240 minecraft:sea_lantern
setblock 275 244 242 minecraft:sea_lantern
setblock 275 244 244 minecraft:sea_lantern
setblock 275 244 246 minecraft:sea_lantern
setblock 275 244 248 minecraft:sea_lantern
setblock 276 244 239 minecraft:sea_lantern
setblock 276 244 241 minecraft:sea_lantern
setblock 276 244 243 minecraft:sea_lantern
fill 276 244 245 276 245 245 minecraft:sea_lantern
setblock 276 244 247 minecraft:sea_lantern
fill 277 244 248 277 261 248 minecraft:black_concrete
setblock 235 245 229 minecraft:magenta_concrete
setblock 235 245 239 minecraft:pearlescent_froglight
setblock 235 245 249 minecraft:purple_concrete
fill 237 245 254 237 257 254 minecraft:cyan_wool
setblock 250 245 270 minecraft:purple_concrete
fill 260 245 270 260 275 270 minecraft:black_concrete
fill 263 245 236 263 248 236 minecraft:cyan_stained_glass
fill 263 245 240 263 248 240 minecraft:cyan_stained_glass
fill 264 245 235 265 245 235 minecraft:cyan_stained_glass
fill 264 245 241 265 245 241 minecraft:cyan_stained_glass
fill 266 245 228 266 267 228 minecraft:black_concrete
fill 268 245 235 268 248 235 minecraft:cyan_stained_glass
fill 268 245 241 268 248 241 minecraft:cyan_stained_glass
fill 269 245 236 269 245 237 minecraft:cyan_stained_glass
fill 269 245 239 269 245 240 minecraft:cyan_stained_glass
setblock 270 245 239 minecraft:gray_concrete
fill 270 245 241 270 246 241 minecraft:gray_concrete
fill 270 245 243 270 246 243 minecraft:gray_concrete
fill 270 245 245 270 246 245 minecraft:gray_concrete
fill 270 245 247 270 246 247 minecraft:gray_concrete
fill 271 245 238 271 246 238 minecraft:gray_concrete
fill 271 245 240 271 246 240 minecraft:gray_concrete
fill 271 245 242 271 246 242 minecraft:gray_concrete
setblock 271 245 243 minecraft:ochre_froglight
fill 271 245 244 271 246 244 minecraft:gray_concrete
setblock 271 245 245 minecraft:sea_lantern
fill 271 245 246 271 246 246 minecraft:gray_concrete
setblock 271 245 247 minecraft:black_stained_glass
fill 271 245 248 271 246 248 minecraft:gray_concrete
setblock 271 245 249 minecraft:black_stained_glass
setblock 271 245 251 minecraft:light_blue_stained_glass
setblock 271 245 253 minecraft:black_stained_glass
fill 272 245 239 272 246 239 minecraft:gray_concrete
fill 272 245 241 272 246 241 minecraft:gray_concrete
setblock 272 245 242 minecraft:black_stained_glass
fill 272 245 243 272 246 243 minecraft:gray_concrete
fill 272 245 245 272 246 245 minecraft:gray_concrete
fill 272 245 247 272 246 247 minecraft:gray_concrete
setblock 272 245 255 minecraft:pearlescent_froglight
fill 272 245 270 272 276 270 minecraft:black_concrete
fill 273 245 238 273 246 238 minecraft:gray_concrete
fill 273 245 240 273 246 240 minecraft:gray_concrete
fill 273 245 242 273 246 242 minecraft:gray_concrete
fill 273 245 244 273 246 244 minecraft:gray_concrete
fill 273 245 246 273 246 246 minecraft:gray_concrete
fill 273 245 248 273 246 248 minecraft:gray_concrete
fill 274 245 239 274 246 239 minecraft:gray_concrete
fill 274 245 241 274 246 241 minecraft:gray_concrete
setblock 274 245 242 minecraft:ochre_froglight
fill 274 245 243 274 246 243 minecraft:gray_concrete
fill 274 245 245 274 246 245 minecraft:gray_concrete
fill 274 245 247 274 246 247 minecraft:gray_concrete
setblock 274 245 255 minecraft:pearlescent_froglight
fill 275 245 238 275 246 238 minecraft:gray_concrete
fill 275 245 240 275 246 240 minecraft:gray_concrete
fill 275 245 242 275 246 242 minecraft:gray_concrete
fill 275 245 244 275 246 244 minecraft:gray_concrete
fill 275 245 246 275 246 246 minecraft:gray_concrete
fill 275 245 248 275 246 248 minecraft:gray_concrete
fill 276 245 239 276 246 239 minecraft:gray_concrete
fill 276 245 241 276 246 241 minecraft:gray_concrete
setblock 276 245 243 minecraft:black_stained_glass
setblock 276 245 247 minecraft:pearlescent_froglight
setblock 276 245 249 minecraft:black_stained_glass
setblock 276 245 251 minecraft:black_stained_glass
setblock 276 245 253 minecraft:ochre_froglight
fill 235 246 229 235 288 229 minecraft:black_concrete
fill 235 246 239 235 308 239 minecraft:black_concrete
fill 235 246 249 235 286 249 minecraft:black_concrete
fill 237 246 252 237 257 253 minecraft:cyan_wool
fill 237 246 255 237 257 256 minecraft:cyan_wool
fill 248 246 267 248 255 267 minecraft:cyan_wool
fill 250 246 270 250 260 270 minecraft:black_concrete
fill 262 246 237 262 247 239 minecraft:cyan_stained_glass
fill 264 246 235 264 248 235 minecraft:cyan_stained_glass
fill 264 246 241 264 248 241 minecraft:cyan_stained_glass
fill 265 246 234 267 247 234 minecraft:cyan_stained_glass
fill 265 246 238 267 247 238 minecraft:pearlescent_froglight
fill 265 246 242 267 247 242 minecraft:cyan_stained_glass
fill 266 246 237 266 247 237 minecraft:pearlescent_froglight
fill 266 246 239 266 247 239 minecraft:pearlescent_froglight
fill 269 246 236 269 248 236 minecraft:cyan_stained_glass
fill 269 246 240 269 248 240 minecraft:cyan_stained_glass
fill 270 246 237 270 246 239 minecraft:cyan_stained_glass
fill 271 246 243 271 247 243 minecraft:gray_concrete
fill 271 246 245 271 247 245 minecraft:gray_concrete
fill 271 246 247 271 247 247 minecraft:gray_concrete
fill 271 246 249 271 247 249 minecraft:light_gray_concrete
fill 271 246 251 271 247 251 minecraft:light_gray_concrete
fill 271 246 253 271 247 253 minecraft:light_gray_concrete
fill 272 246 242 272 247 242 minecraft:gray_concrete
fill 272 246 255 272 247 255 minecraft:light_gray_concrete
fill 274 246 242 274 247 242 minecraft:gray_concrete
fill 274 246 255 274 247 255 minecraft:light_gray_concrete
setblock 276 246 243 minecraft:gray_concrete
setblock 276 246 245 minecraft:gray_concrete
setblock 276 246 247 minecraft:gray_concrete
fill 276 246 249 276 247 249 minecraft:light_gray_concrete
fill 276 246 251 276 247 251 minecraft:light_gray_concrete
fill 276 246 253 276 247 253 minecraft:light_gray_concrete
setblock 277 246 241 minecraft:cyan_concrete
setblock 235 247 268 minecraft:magenta_concrete
setblock 238 247 231 minecraft:light[level=12]
setblock 238 247 238 minecraft:light[level=12]
setblock 238 247 245 minecraft:light[level=12]
setblock 238 247 252 minecraft:light[level=12]
setblock 238 247 259 minecraft:light[level=12]
setblock 238 247 266 minecraft:light[level=12]
setblock 245 247 231 minecraft:light[level=12]
setblock 245 247 238 minecraft:light[level=12]
setblock 245 247 245 minecraft:light[level=12]
setblock 245 247 252 minecraft:light[level=12]
setblock 245 247 259 minecraft:light[level=12]
setblock 245 247 266 minecraft:light[level=12]
fill 246 247 267 247 255 267 minecraft:cyan_wool
fill 249 247 267 250 255 267 minecraft:cyan_wool
setblock 252 247 231 minecraft:light[level=12]
setblock 252 247 238 minecraft:light[level=12]
setblock 252 247 245 minecraft:light[level=12]
setblock 252 247 252 minecraft:light[level=12]
setblock 252 247 259 minecraft:light[level=12]
setblock 252 247 266 minecraft:light[level=12]
setblock 253 247 270 minecraft:cyan_concrete
setblock 259 247 231 minecraft:light[level=12]
setblock 259 247 238 minecraft:light[level=12]
setblock 259 247 245 minecraft:light[level=12]
setblock 259 247 252 minecraft:light[level=12]
setblock 259 247 259 minecraft:light[level=12]
setblock 259 247 266 minecraft:light[level=12]
setblock 266 247 231 minecraft:light[level=12]
setblock 266 247 245 minecraft:light[level=12]
setblock 266 247 252 minecraft:light[level=12]
setblock 266 247 259 minecraft:light[level=12]
setblock 266 247 266 minecraft:light[level=12]
setblock 269 247 270 minecraft:cyan_concrete
fill 270 247 237 270 247 238 minecraft:cyan_stained_glass
setblock 270 247 239 minecraft:sea_lantern
setblock 270 247 241 minecraft:sea_lantern
setblock 270 247 243 minecraft:sea_lantern
setblock 270 247 245 minecraft:sea_lantern
setblock 270 247 247 minecraft:sea_lantern
setblock 271 247 238 minecraft:sea_lantern
setblock 271 247 240 minecraft:sea_lantern
setblock 271 247 242 minecraft:sea_lantern
setblock 271 247 244 minecraft:sea_lantern
setblock 271 247 246 minecraft:sea_lantern
setblock 271 247 248 minecraft:sea_lantern
setblock 272 247 239 minecraft:sea_lantern
setblock 272 247 241 minecraft:sea_lantern
setblock 272 247 243 minecraft:sea_lantern
setblock 272 247 245 minecraft:sea_lantern
setblock 272 247 247 minecraft:sea_lantern
setblock 273 247 231 minecraft:light[level=12]
setblock 273 247 238 minecraft:sea_lantern
setblock 273 247 240 minecraft:sea_lantern
setblock 273 247 242 minecraft:sea_lantern
setblock 273 247 244 minecraft:sea_lantern
setblock 273 247 246 minecraft:sea_lantern
setblock 273 247 248 minecraft:sea_lantern
setblock 273 247 259 minecraft:light[level=12]
setblock 273 247 266 minecraft:light[level=12]
setblock 274 247 239 minecraft:sea_lantern
setblock 274 247 241 minecraft:sea_lantern
setblock 274 247 243 minecraft:sea_lantern
setblock 274 247 245 minecraft:sea_lantern
setblock 274 247 247 minecraft:sea_lantern
setblock 275 247 238 minecraft:sea_lantern
setblock 275 247 240 minecraft:sea_lantern
setblock 275 247 242 minecraft:sea_lantern
setblock 275 247 244 minecraft:sea_lantern
setblock 275 247 246 minecraft:sea_lantern
setblock 275 247 248 minecraft:sea_lantern
setblock 276 247 239 minecraft:sea_lantern
setblock 276 247 241 minecraft:sea_lantern
setblock 276 247 243 minecraft:sea_lantern
setblock 276 247 245 minecraft:sea_lantern
setblock 276 247 247 minecraft:sea_lantern
fill 277 247 241 277 265 241 minecraft:black_concrete
setblock 277 247 255 minecraft:cyan_concrete
setblock 235 248 259 minecraft:purple_concrete
fill 235 248 268 235 308 268 minecraft:black_concrete
setblock 238 248 231 minecraft:light[level=15]
setblock 238 248 239 minecraft:light[level=15]
setblock 238 248 247 minecraft:light[level=15]
setblock 238 248 255 minecraft:light[level=15]
setblock 238 248 263 minecraft:light[level=15]
setblock 246 248 231 minecraft:light[level=15]
setblock 246 248 239 minecraft:light[level=15]
setblock 246 248 247 minecraft:light[level=15]
setblock 246 248 255 minecraft:light[level=15]
setblock 246 248 263 minecraft:light[level=15]
fill 253 248 270 253 289 270 minecraft:black_concrete
setblock 254 248 231 minecraft:light[level=15]
setblock 254 248 239 minecraft:light[level=15]
setblock 254 248 247 minecraft:light[level=15]
setblock 254 248 255 minecraft:light[level=15]
setblock 254 248 263 minecraft:light[level=15]
setblock 262 248 231 minecraft:light[level=15]
setblock 262 248 239 minecraft:light[level=15]
setblock 262 248 247 minecraft:light[level=15]
setblock 262 248 255 minecraft:light[level=15]
setblock 262 248 263 minecraft:light[level=15]
fill 263 248 237 263 249 239 minecraft:cyan_stained_glass
fill 265 248 235 267 249 235 minecraft:cyan_stained_glass
fill 265 248 241 267 249 241 minecraft:cyan_stained_glass
fill 269 248 237 269 249 239 minecraft:cyan_stained_glass
fill 269 248 270 269 271 270 minecraft:black_concrete
setblock 270 248 231 minecraft:light[level=15]
fill 270 248 238 270 248 239 minecraft:gray_concrete
setblock 270 248 241 minecraft:gray_concrete
setblock 270 248 243 minecraft:gray_concrete
setblock 270 248 245 minecraft:gray_concrete
setblock 270 248 247 minecraft:gray_concrete
setblock 270 248 255 minecraft:light[level=15]
setblock 270 248 263 minecraft:light[level=15]
setblock 271 248 238 minecraft:gray_concrete
setblock 271 248 240 minecraft:gray_concrete
setblock 271 248 242 minecraft:gray_concrete
setblock 271 248 243 minecraft:ochre_froglight
setblock 271 248 244 minecraft:gray_concrete
setblock 271 248 245 minecraft:cyan_stained_glass
setblock 271 248 246 minecraft:gray_concrete
setblock 271 248 247 minecraft:ochre_froglight
setblock 271 248 248 minecraft:gray_concrete
setblock 271 248 249 minecraft:pearlescent_froglight
setblock 271 248 251 minecraft:light_blue_stained_glass
setblock 271 248 253 minecraft:pearlescent_froglight
setblock 272 248 239 minecraft:gray_concrete
setblock 272 248 241 minecraft:gray_concrete
setblock 272 248 242 minecraft:cyan_stained_glass
setblock 272 248 243 minecraft:gray_concrete
setblock 272 248 245 minecraft:gray_concrete
setblock 272 248 247 minecraft:gray_concrete
setblock 272 248 255 minecraft:black_stained_glass
setblock 273 248 238 minecraft:gray_concrete
setblock 273 248 240 minecraft:gray_concrete
setblock 273 248 242 minecraft:gray_concrete
setblock 273 248 244 minecraft:gray_concrete
setblock 273 248 246 minecraft:gray_concrete
setblock 273 248 248 minecraft:gray_concrete
setblock 274 248 239 minecraft:gray_concrete
setblock 274 248 241 minecraft:gray_concrete
setblock 274 248 242 minecraft:pearlescent_froglight
setblock 274 248 243 minecraft:gray_concrete
setblock 274 248 245 minecraft:gray_concrete
setblock 274 248 247 minecraft:gray_concrete
setblock 274 248 255 minecraft:magenta_stained_glass
setblock 275 248 238 minecraft:gray_concrete
setblock 275 248 240 minecraft:gray_concrete
setblock 275 248 242 minecraft:gray_concrete
setblock 275 248 244 minecraft:gray_concrete
setblock 275 248 246 minecraft:gray_concrete
setblock 275 248 248 minecraft:gray_concrete
setblock 276 248 239 minecraft:gray_concrete
setblock 276 248 241 minecraft:gray_concrete
setblock 276 248 243 minecraft:black_stained_glass
setblock 276 248 245 minecraft:cyan_stained_glass
setblock 276 248 247 minecraft:cyan_stained_glass
setblock 276 248 249 minecraft:black_stained_glass
setblock 276 248 251 minecraft:pearlescent_froglight
setblock 276 248 253 minecraft:ochre_froglight
fill 277 248 255 277 251 255 minecraft:black_concrete
setblock 277 248 266 minecraft:pearlescent_froglight
fill 235 249 259 235 263 259 minecraft:black_concrete
setblock 235 249 265 minecraft:ochre_froglight
fill 237 249 257 237 250 263 minecraft:iron_block
fill 264 249 236 264 249 237 minecraft:cyan_stained_glass
fill 264 249 239 264 249 240 minecraft:cyan_stained_glass
fill 265 249 236 265 250 236 minecraft:cyan_stained_glass
fill 265 249 240 265 250 240 minecraft:cyan_stained_glass
fill 267 249 236 268 249 236 minecraft:cyan_stained_glass
fill 267 249 240 268 249 240 minecraft:cyan_stained_glass
fill 268 249 237 268 250 237 minecraft:cyan_stained_glass
fill 268 249 239 268 250 239 minecraft:cyan_stained_glass
fill 271 249 242 271 250 249 minecraft:light_gray_concrete
fill 271 249 251 271 250 251 minecraft:light_gray_concrete
fill 271 249 253 271 250 253 minecraft:light_gray_concrete
fill 272 249 242 276 250 248 minecraft:light_gray_concrete
fill 272 249 255 272 250 255 minecraft:light_gray_concrete
fill 274 249 255 274 250 255 minecraft:light_gray_concrete
fill 276 249 249 276 250 249 minecraft:light_gray_concrete
fill 276 249 251 276 250 251 minecraft:light_gray_concrete
fill 276 249 253 276 250 253 minecraft:light_gray_concrete
fill 277 249 266 277 308 266 minecraft:black_concrete
setblock 235 250 230 minecraft:pearlescent_froglight
fill 235 250 265 235 260 265 minecraft:black_concrete
setblock 250 250 263 minecraft:sea_lantern
setblock 252 250 228 minecraft:purple_concrete
setblock 255 250 228 minecraft:magenta_concrete
fill 264 250 237 267 250 239 minecraft:cyan_stained_glass
fill 266 250 236 267 250 236 minecraft:cyan_stained_glass
fill 266 250 240 267 250 240 minecraft:cyan_stained_glass
setblock 268 250 238 minecraft:cyan_stained_glass
setblock 272 250 265 minecraft:redstone_block
fill 235 251 230 235 308 230 minecraft:black_concrete
setblock 237 251 228 minecraft:pearlescent_froglight
fill 248 251 263 252 251 263 minecraft:lime_concrete
fill 249 251 262 251 251 262 minecraft:lime_concrete
fill 249 251 264 251 251 264 minecraft:lime_concrete
fill 252 251 228 252 308 228 minecraft:black_concrete
fill 255 251 228 255 256 228 minecraft:black_concrete
fill 271 251 242 271 263 242 minecraft:light_gray_concrete
setblock 271 251 243 minecraft:cyan_stained_glass
fill 271 251 244 276 263 244 minecraft:light_gray_concrete
setblock 271 251 245 minecraft:ochre_froglight
fill 271 251 246 276 263 246 minecraft:light_gray_concrete
setblock 271 251 247 minecraft:black_stained_glass
fill 271 251 248 276 263 248 minecraft:light_gray_concrete
setblock 271 251 249 minecraft:sea_lantern
setblock 271 251 251 minecraft:black_stained_glass
setblock 271 251 253 minecraft:light_blue_stained_glass
setblock 272 251 242 minecraft:cyan_stained_glass
fill 272 251 243 275 263 243 minecraft:light_gray_concrete
fill 272 251 245 275 263 245 minecraft:light_gray_concrete
fill 272 251 247 275 263 247 minecraft:light_gray_concrete
setblock 272 251 255 minecraft:black_stained_glass
fill 273 251 242 273 263 242 minecraft:light_gray_concrete
setblock 273 251 270 minecraft:sea_lantern
setblock 274 251 242 minecraft:black_stained_glass
setblock 274 251 255 minecraft:pearlescent_froglight
fill 275 251 242 276 263 242 minecraft:light_gray_concrete
setblock 276 251 243 minecraft:black_stained_glass
setblock 276 251 245 minecraft:light_blue_stained_glass
setblock 276 251 247 minecraft:black_stained_glass
setblock 276 251 249 minecraft:magenta_stained_glass
setblock 276 251 251 minecraft:black_stained_glass
setblock 276 251 253 minecraft:ochre_froglight
setblock 277 251 231 minecraft:blue_concrete
setblock 277 251 249 minecraft:purple_concrete
fill 237 252 228 237 291 228 minecraft:black_concrete
fill 249 252 263 251 252 263 minecraft:light_blue_stained_glass
fill 271 252 243 271 253 243 minecraft:light_gray_concrete
fill 271 252 245 271 253 245 minecraft:light_gray_concrete
fill 271 252 247 271 253 247 minecraft:light_gray_concrete
fill 271 252 249 271 253 249 minecraft:light_gray_concrete
fill 271 252 251 271 253 251 minecraft:light_gray_concrete
fill 271 252 253 271 253 253 minecraft:light_gray_concrete
fill 272 252 242 272 253 242 minecraft:light_gray_concrete
fill 272 252 255 272 253 255 minecraft:light_gray_concrete
fill 273 252 270 273 308 270 minecraft:black_concrete
fill 274 252 242 274 253 242 minecraft:light_gray_concrete
fill 274 252 255 274 253 255 minecraft:light_gray_concrete
fill 276 252 243 276 253 243 minecraft:light_gray_concrete
fill 276 252 245 276 253 245 minecraft:light_gray_concrete
fill 276 252 247 276 253 247 minecraft:light_gray_concrete
fill 276 252 249 276 253 249 minecraft:light_gray_concrete
fill 276 252 251 276 253 251 minecraft:light_gray_concrete
fill 276 252 253 276 253 253 minecraft:light_gray_concrete
fill 277 252 231 277 272 231 minecraft:black_concrete
fill 277 252 249 277 308 249 minecraft:black_concrete
setblock 277 252 255 minecraft:cyan_concrete
setblock 277 252 261 minecraft:blue_concrete
setblock 235 253 238 minecraft:magenta_concrete
setblock 235 253 258 minecraft:cyan_concrete
setblock 238 253 231 minecraft:light[level=12]
setblock 238 253 238 minecraft:light[level=12]
setblock 238 253 245 minecraft:light[level=12]
setblock 238 253 252 minecraft:light[level=12]
setblock 238 253 259 minecraft:light[level=12]
setblock 238 253 266 minecraft:light[level=12]
setblock 245 253 231 minecraft:light[level=12]
setblock 245 253 238 minecraft:light[level=12]
setblock 245 253 245 minecraft:light[level=12]
setblock 245 253 252 minecraft:light[level=12]
setblock 245 253 259 minecraft:light[level=12]
setblock 245 253 266 minecraft:light[level=12]
setblock 252 253 231 minecraft:light[level=12]
setblock 252 253 238 minecraft:light[level=12]
setblock 252 253 245 minecraft:light[level=12]
setblock 252 253 252 minecraft:light[level=12]
setblock 252 253 259 minecraft:light[level=12]
setblock 252 253 266 minecraft:light[level=12]
setblock 258 253 270 minecraft:sea_lantern
setblock 259 253 231 minecraft:light[level=12]
setblock 259 253 238 minecraft:light[level=12]
setblock 259 253 245 minecraft:light[level=12]
setblock 259 253 252 minecraft:light[level=12]
setblock 259 253 259 minecraft:light[level=12]
setblock 259 253 266 minecraft:light[level=12]
setblock 262 253 270 minecraft:cyan_concrete
setblock 266 253 231 minecraft:light[level=12]
setblock 266 253 238 minecraft:light[level=12]
setblock 266 253 245 minecraft:light[level=12]
setblock 266 253 252 minecraft:light[level=12]
setblock 266 253 259 minecraft:light[level=12]
setblock 266 253 266 minecraft:light[level=12]
setblock 273 253 231 minecraft:light[level=12]
setblock 273 253 238 minecraft:light[level=12]
setblock 273 253 259 minecraft:light[level=12]
setblock 273 253 266 minecraft:light[level=12]
fill 277 253 255 277 283 255 minecraft:black_concrete
fill 277 253 261 277 286 261 minecraft:black_concrete
fill 235 254 238 235 286 238 minecraft:black_concrete
fill 235 254 258 235 266 258 minecraft:black_concrete
setblock 255 254 270 minecraft:blue_concrete
setblock 256 254 270 minecraft:magenta_concrete
fill 258 254 270 258 281 270 minecraft:black_concrete
fill 262 254 270 262 308 270 minecraft:black_concrete
setblock 271 254 243 minecraft:black_stained_glass
setblock 271 254 245 minecraft:pearlescent_froglight
setblock 271 254 247 minecraft:black_stained_glass
setblock 271 254 249 minecraft:light_blue_stained_glass
setblock 271 254 251 minecraft:magenta_stained_glass
setblock 271 254 253 minecraft:pearlescent_froglight
setblock 272 254 242 minecraft:ochre_froglight
setblock 272 254 255 minecraft:cyan_stained_glass
setblock 274 254 242 minecraft:light_blue_stained_glass
setblock 274 254 255 minecraft:pearlescent_froglight
setblock 276 254 243 minecraft:pearlescent_froglight
setblock 276 254 245 minecraft:sea_lantern
setblock 276 254 247 minecraft:cyan_stained_glass
setblock 276 254 249 minecraft:magenta_stained_glass
setblock 276 254 251 minecraft:black_stained_glass
setblock 276 254 253 minecraft:black_stained_glass
setblock 277 254 237 minecraft:pearlescent_froglight
setblock 235 255 261 minecraft:verdant_froglight
setblock 238 255 231 minecraft:light[level=15]
setblock 238 255 239 minecraft:light[level=15]
setblock 238 255 247 minecraft:light[level=15]
setblock 238 255 255 minecraft:light[level=15]
setblock 238 255 263 minecraft:light[level=15]
setblock 246 255 231 minecraft:light[level=15]
setblock 246 255 239 minecraft:light[level=15]
setblock 246 255 247 minecraft:light[level=15]
setblock 246 255 255 minecraft:light[level=15]
setblock 246 255 263 minecraft:light[level=15]
setblock 254 255 231 minecraft:light[level=15]
setblock 254 255 239 minecraft:light[level=15]
setblock 254 255 247 minecraft:light[level=15]
setblock 254 255 255 minecraft:light[level=15]
setblock 254 255 263 minecraft:light[level=15]
fill 255 255 270 256 271 270 minecraft:black_concrete
setblock 262 255 231 minecraft:light[level=15]
setblock 262 255 239 minecraft:light[level=15]
setblock 262 255 247 minecraft:light[level=15]
setblock 262 255 255 minecraft:light[level=15]
setblock 262 255 263 minecraft:light[level=15]
setblock 270 255 231 minecraft:light[level=15]
setblock 270 255 239 minecraft:light[level=15]
setblock 270 255 247 minecraft:light[level=15]
setblock 270 255 255 minecraft:light[level=15]
setblock 270 255 263 minecraft:light[level=15]
fill 271 255 243 271 256 243 minecraft:light_gray_concrete
fill 271 255 245 271 256 245 minecraft:light_gray_concrete
fill 271 255 247 271 256 247 minecraft:light_gray_concrete
fill 271 255 249 271 256 249 minecraft:light_gray_concrete
fill 271 255 251 271 256 251 minecraft:light_gray_concrete
fill 271 255 253 271 256 253 minecraft:light_gray_concrete
fill 272 255 242 272 256 242 minecraft:light_gray_concrete
fill 272 255 255 272 256 255 minecraft:light_gray_concrete
fill 274 255 242 274 256 242 minecraft:light_gray_concrete
fill 274 255 255 274 256 255 minecraft:light_gray_concrete
fill 276 255 243 276 256 243 minecraft:light_gray_concrete
fill 276 255 245 276 256 245 minecraft:light_gray_concrete
fill 276 255 247 276 256 247 minecraft:light_gray_concrete
fill 276 255 249 276 256 249 minecraft:light_gray_concrete
fill 276 255 251 276 256 251 minecraft:light_gray_concrete
fill 276 255 253 276 256 253 minecraft:light_gray_concrete
fill 277 255 237 277 299 237 minecraft:black_concrete
setblock 277 255 240 minecraft:purple_concrete
fill 235 256 261 235 275 261 minecraft:black_concrete
setblock 238 256 228 minecraft:magenta_concrete
setblock 240 256 270 minecraft:blue_concrete
fill 245 256 267 251 257 267 minecraft:iron_block
setblock 262 256 228 minecraft:ochre_froglight
setblock 268 256 251 minecraft:sea_lantern
fill 277 256 240 277 287 240 minecraft:black_concrete
fill 238 257 228 238 263 228 minecraft:black_concrete
fill 240 257 270 240 308 270 minecraft:black_concrete
setblock 250 257 237 minecraft:sea_lantern
setblock 255 257 228 minecraft:cyan_concrete
fill 262 257 228 262 284 228 minecraft:black_concrete
fill 267 257 250 269 257 252 minecraft:magenta_concrete
setblock 268 257 249 minecraft:magenta_concrete
setblock 268 257 253 minecraft:magenta_concrete
setblock 271 257 243 minecraft:black_stained_glass
setblock 271 257 245 minecraft:black_stained_glass
setblock 271 257 247 minecraft:black_stained_glass
setblock 271 257 249 minecraft:black_stained_glass
setblock 271 257 251 minecraft:cyan_stained_glass
setblock 271 257 253 minecraft:black_stained_glass
setblock 272 257 242 minecraft:black_stained_glass
setblock 272 257 255 minecraft:black_stained_glass
setblock 274 257 242 minecraft:magenta_stained_glass
setblock 274 257 255 minecraft:black_stained_glass
setblock 276 257 243 minecraft:magenta_stained_glass
setblock 276 257 245 minecraft:sea_lantern
setblock 276 257 247 minecraft:cyan_stained_glass
setblock 276 257 249 minecraft:black_stained_glass
setblock 276 257 251 minecraft:light_blue_stained_glass
setblock 276 257 253 minecraft:black_stained_glass
setblock 277 257 253 minecraft:cyan_concrete
setblock 236 258 228 minecraft:pearlescent_froglight
fill 237 258 251 237 259 257 minecraft:iron_block
fill 248 258 237 252 258 237 minecraft:white_concrete
fill 249 258 236 251 258 236 minecraft:white_concrete
fill 249 258 238 251 258 238 minecraft:white_concrete
fill 255 258 228 255 301 228 minecraft:black_concrete
fill 268 258 250 268 258 252 minecraft:light_blue_stained_glass
fill 271 258 243 271 259 243 minecraft:light_gray_concrete
fill 271 258 245 271 259 245 minecraft:light_gray_concrete
fill 271 258 247 271 259 247 minecraft:light_gray_concrete
fill 271 258 249 271 259 249 minecraft:light_gray_concrete
fill 271 258 251 271 259 251 minecraft:light_gray_concrete
fill 271 258 253 271 259 253 minecraft:light_gray_concrete
fill 272 258 242 272 259 242 minecraft:light_gray_concrete
fill 272 258 255 272 259 255 minecraft:light_gray_concrete
fill 274 258 242 274 259 242 minecraft:light_gray_concrete
fill 274 258 255 274 259 255 minecraft:light_gray_concrete
fill 276 258 243 276 259 243 minecraft:light_gray_concrete
fill 276 258 245 276 259 245 minecraft:light_gray_concrete
fill 276 258 247 276 259 247 minecraft:light_gray_concrete
fill 276 258 249 276 259 249 minecraft:light_gray_concrete
fill 276 258 251 276 259 251 minecraft:light_gray_concrete
fill 276 258 253 276 259 253 minecraft:light_gray_concrete
fill 277 258 253 277 292 253 minecraft:black_concrete
fill 236 259 228 236 266 228 minecraft:black_concrete
setblock 236 259 270 minecraft:purple_concrete
setblock 238 259 231 minecraft:light[level=12]
setblock 238 259 238 minecraft:light[level=12]
setblock 238 259 245 minecraft:light[level=12]
setblock 238 259 252 minecraft:light[level=12]
setblock 238 259 259 minecraft:light[level=12]
setblock 238 259 266 minecraft:light[level=12]
setblock 245 259 231 minecraft:light[level=12]
setblock 245 259 238 minecraft:light[level=12]
setblock 245 259 245 minecraft:light[level=12]
setblock 245 259 252 minecraft:light[level=12]
setblock 245 259 259 minecraft:light[level=12]
setblock 245 259 266 minecraft:light[level=12]
setblock 248 259 228 minecraft:magenta_concrete
fill 249 259 237 251 259 237 minecraft:light_blue_stained_glass
fill 250 259 229 250 260 231 minecraft:iron_block
setblock 252 259 231 minecraft:light[level=12]
setblock 252 259 238 minecraft:light[level=12]
setblock 252 259 245 minecraft:light[level=12]
setblock 252 259 252 minecraft:light[level=12]
setblock 252 259 259 minecraft:light[level=12]
setblock 252 259 266 minecraft:light[level=12]
setblock 259 259 231 minecraft:light[level=12]
setblock 259 259 238 minecraft:light[level=12]
setblock 259 259 245 minecraft:light[level=12]
setblock 259 259 252 minecraft:light[level=12]
setblock 259 259 259 minecraft:light[level=12]
setblock 259 259 266 minecraft:light[level=12]
setblock 266 259 231 minecraft:light[level=12]
setblock 266 259 238 minecraft:light[level=12]
setblock 266 259 245 minecraft:light[level=12]
setblock 266 259 252 minecraft:light[level=12]
setblock 266 259 259 minecraft:light[level=12]
setblock 266 259 266 minecraft:light[level=12]
setblock 273 259 231 minecraft:light[level=12]
setblock 273 259 238 minecraft:light[level=12]
setblock 273 259 259 minecraft:light[level=12]
setblock 273 259 266 minecraft:light[level=12]
setblock 235 260 241 minecraft:purple_concrete
setblock 235 260 260 minecraft:cyan_concrete
fill 236 260 270 236 295 270 minecraft:black_concrete
setblock 246 260 270 minecraft:sea_lantern
fill 248 260 228 248 293 228 minecraft:black_concrete
fill 249 260 266 249 261 268 minecraft:iron_block
setblock 256 260 228 minecraft:purple_concrete
setblock 271 260 243 minecraft:magenta_stained_glass
setblock 271 260 245 minecraft:black_stained_glass
setblock 271 260 247 minecraft:cyan_stained_glass
setblock 271 260 249 minecraft:ochre_froglight
setblock 271 260 251 minecraft:black_stained_glass
setblock 271 260 253 minecraft:black_stained_glass
setblock 272 260 242 minecraft:black_stained_glass
setblock 272 260 255 minecraft:pearlescent_froglight
setblock 274 260 242 minecraft:light_blue_stained_glass
setblock 274 260 255 minecraft:cyan_stained_glass
setblock 276 260 243 minecraft:black_stained_glass
setblock 276 260 245 minecraft:ochre_froglight
setblock 276 260 247 minecraft:ochre_froglight
setblock 276 260 249 minecraft:black_stained_glass
setblock 276 260 251 minecraft:pearlescent_froglight
setblock 276 260 253 minecraft:black_stained_glass
fill 235 261 241 235 293 241 minecraft:black_concrete
fill 235 261 260 235 308 260 minecraft:black_concrete
setblock 235 261 265 minecraft:cyan_concrete
fill 246 261 270 246 308 270 minecraft:black_concrete
setblock 250 261 270 minecraft:purple_concrete
fill 256 261 228 256 263 228 minecraft:black_concrete
setblock 266 261 270 minecraft:verdant_froglight
fill 271 261 243 271 263 243 minecraft:light_gray_concrete
fill 271 261 245 271 263 245 minecraft:light_gray_concrete
fill 271 261 247 271 263 247 minecraft:light_gray_concrete
fill 271 261 249 271 263 249 minecraft:light_gray_concrete
fill 271 261 251 271 263 251 minecraft:light_gray_concrete
fill 271 261 253 271 263 253 minecraft:light_gray_concrete
fill 272 261 242 272 263 242 minecraft:light_gray_concrete
fill 272 261 255 272 263 255 minecraft:light_gray_concrete
fill 274 261 242 274 263 242 minecraft:light_gray_concrete
fill 274 261 255 274 263 255 minecraft:light_gray_concrete
fill 276 261 243 276 263 243 minecraft:light_gray_concrete
fill 276 261 245 276 263 245 minecraft:light_gray_concrete
fill 276 261 247 276 263 247 minecraft:light_gray_concrete
fill 276 261 249 276 263 249 minecraft:light_gray_concrete
fill 276 261 251 276 263 251 minecraft:light_gray_concrete
fill 276 261 253 276 263 253 minecraft:light_gray_concrete
setblock 235 262 233 minecraft:blue_concrete
setblock 235 262 243 minecraft:magenta_concrete
fill 235 262 265 235 286 265 minecraft:black_concrete
setblock 238 262 231 minecraft:light[level=15]
setblock 238 262 239 minecraft:light[level=15]
setblock 238 262 247 minecraft:light[level=15]
setblock 238 262 255 minecraft:light[level=15]
setblock 238 262 263 minecraft:light[level=15]
setblock 246 262 231 minecraft:light[level=15]
setblock 246 262 239 minecraft:light[level=15]
setblock 246 262 247 minecraft:light[level=15]
setblock 246 262 255 minecraft:light[level=15]
setblock 246 262 263 minecraft:light[level=15]
setblock 247 262 228 minecraft:magenta_concrete
fill 250 262 270 250 283 270 minecraft:black_concrete
setblock 254 262 231 minecraft:light[level=15]
setblock 254 262 239 minecraft:light[level=15]
setblock 254 262 247 minecraft:light[level=15]
setblock 254 262 255 minecraft:light[level=15]
setblock 254 262 263 minecraft:light[level=15]
setblock 262 262 231 minecraft:light[level=15]
setblock 262 262 239 minecraft:light[level=15]
setblock 262 262 247 minecraft:light[level=15]
setblock 262 262 255 minecraft:light[level=15]
setblock 262 262 263 minecraft:light[level=15]
fill 266 262 270 266 298 270 minecraft:black_concrete
setblock 270 262 231 minecraft:light[level=15]
setblock 270 262 239 minecraft:light[level=15]
setblock 270 262 247 minecraft:light[level=15]
setblock 270 262 255 minecraft:light[level=15]
setblock 270 262 263 minecraft:light[level=15]
setblock 277 262 248 minecraft:ochre_froglight
fill 235 263 233 235 308 233 minecraft:black_concrete
fill 235 263 243 235 279 243 minecraft:black_concrete
setblock 241 263 270 minecraft:ochre_froglight
fill 247 263 228 247 308 228 minecraft:black_concrete
setblock 252 263 270 minecraft:verdant_froglight
setblock 275 263 228 minecraft:verdant_froglight
fill 277 263 248 277 264 248 minecraft:black_concrete
setblock 235 264 255 minecraft:pearlescent_froglight
setblock 235 264 259 minecraft:sea_lantern
setblock 238 264 228 minecraft:purple_concrete
fill 241 264 270 241 265 270 minecraft:black_concrete
setblock 244 264 270 minecraft:pearlescent_froglight
fill 252 264 270 252 308 270 minecraft:black_concrete
setblock 256 264 228 minecraft:pearlescent_froglight
fill 271 264 242 276 264 255 minecraft:black_concrete
setblock 274 264 270 minecraft:sea_lantern
fill 275 264 228 275 278 228 minecraft:black_concrete
setblock 277 264 243 minecraft:cyan_concrete
setblock 235 265 240 minecraft:blue_concrete
setblock 235 265 255 minecraft:black_concrete
fill 235 265 259 235 269 259 minecraft:black_concrete
setblock 235 265 262 minecraft:verdant_froglight
fill 238 265 228 238 308 228 minecraft:black_concrete
setblock 238 265 231 minecraft:light[level=12]
setblock 238 265 238 minecraft:light[level=12]
setblock 238 265 245 minecraft:light[level=12]
setblock 238 265 252 minecraft:light[level=12]
setblock 238 265 259 minecraft:light[level=12]
setblock 238 265 266 minecraft:light[level=12]
setblock 244 265 270 minecraft:verdant_froglight
setblock 245 265 231 minecraft:light[level=12]
setblock 245 265 238 minecraft:light[level=12]
setblock 245 265 245 minecraft:light[level=12]
setblock 245 265 252 minecraft:light[level=12]
setblock 245 265 259 minecraft:light[level=12]
setblock 245 265 266 minecraft:light[level=12]
setblock 248 265 261 minecraft:sea_lantern
setblock 252 265 231 minecraft:light[level=12]
setblock 252 265 238 minecraft:light[level=12]
setblock 252 265 245 minecraft:light[level=12]
setblock 252 265 252 minecraft:light[level=12]
setblock 252 265 259 minecraft:light[level=12]
setblock 252 265 266 minecraft:light[level=12]
fill 256 265 228 256 280 228 minecraft:black_concrete
setblock 259 265 231 minecraft:light[level=12]
setblock 259 265 238 minecraft:light[level=12]
setblock 259 265 245 minecraft:light[level=12]
setblock 259 265 252 minecraft:light[level=12]
setblock 259 265 259 minecraft:light[level=12]
setblock 259 265 266 minecraft:light[level=12]
setblock 266 265 231 minecraft:light[level=12]
setblock 266 265 238 minecraft:light[level=12]
setblock 266 265 245 minecraft:light[level=12]
setblock 266 265 252 minecraft:light[level=12]
setblock 266 265 259 minecraft:light[level=12]
setblock 266 265 266 minecraft:light[level=12]
fill 271 265 242 271 265 255 minecraft:sea_lantern
fill 272 265 242 276 265 242 minecraft:sea_lantern
fill 272 265 255 276 265 255 minecraft:sea_lantern
setblock 273 265 231 minecraft:light[level=12]
setblock 273 265 238 minecraft:light[level=12]
fill 273 265 244 274 266 253 minecraft:light_gray_concrete
setblock 273 265 259 minecraft:light[level=12]
setblock 273 265 266 minecraft:light[level=12]
fill 274 265 270 274 308 270 minecraft:black_concrete
fill 276 265 243 276 265 254 minecraft:sea_lantern
fill 277 265 243 277 308 243 minecraft:black_concrete
setblock 277 265 248 minecraft:verdant_froglight
fill 235 266 240 235 278 240 minecraft:black_concrete
setblock 235 266 255 minecraft:cyan_concrete
fill 235 266 262 235 273 262 minecraft:black_concrete
setblock 241 266 270 minecraft:cyan_concrete
fill 244 266 270 244 308 270 minecraft:black_concrete
fill 246 266 261 250 266 261 minecraft:red_concrete
fill 247 266 260 249 266 260 minecraft:red_concrete
fill 247 266 262 249 266 262 minecraft:red_concrete
setblock 277 266 241 minecraft:pearlescent_froglight
fill 277 266 248 277 268 248 minecraft:black_concrete
setblock 277 266 260 minecraft:magenta_concrete
fill 235 267 255 235 287 255 minecraft:black_concrete
setblock 235 267 258 minecraft:verdant_froglight
setblock 236 267 228 minecraft:ochre_froglight
fill 241 267 270 241 308 270 minecraft:black_concrete
fill 247 267 261 249 267 261 minecraft:light_blue_stained_glass
fill 273 267 244 274 272 244 minecraft:light_gray_concrete
setblock 273 267 245 minecraft:light_blue_stained_glass
fill 273 267 246 274 272 246 minecraft:light_gray_concrete
setblock 273 267 247 minecraft:pearlescent_froglight
fill 273 267 248 274 272 248 minecraft:light_gray_concrete
setblock 273 267 249 minecraft:black_stained_glass
fill 273 267 250 274 272 250 minecraft:light_gray_concrete
setblock 273 267 251 minecraft:ochre_froglight
fill 273 267 252 274 272 253 minecraft:light_gray_concrete
setblock 274 267 245 minecraft:cyan_stained_glass
setblock 274 267 247 minecraft:light_blue_stained_glass
setblock 274 267 249 minecraft:light_blue_stained_glass
setblock 274 267 251 minecraft:magenta_stained_glass
fill 277 267 241 277 308 241 minecraft:black_concrete
fill 277 267 260 277 288 260 minecraft:black_concrete
fill 235 268 258 235 308 258 minecraft:black_concrete
fill 236 268 228 236 301 228 minecraft:black_concrete
setblock 266 268 228 minecraft:verdant_froglight
setblock 271 268 228 minecraft:blue_concrete
fill 273 268 245 274 269 245 minecraft:light_gray_concrete
fill 273 268 247 274 269 247 minecraft:light_gray_concrete
fill 273 268 249 274 269 249 minecraft:light_gray_concrete
fill 273 268 251 274 269 251 minecraft:light_gray_concrete
setblock 238 269 231 minecraft:light[level=15]
setblock 238 269 239 minecraft:light[level=15]
setblock 238 269 247 minecraft:light[level=15]
setblock 238 269 255 minecraft:light[level=15]
setblock 238 269 263 minecraft:light[level=15]
setblock 239 269 270 minecraft:magenta_concrete
setblock 246 269 231 minecraft:light[level=15]
setblock 246 269 239 minecraft:light[level=15]
setblock 246 269 247 minecraft:light[level=15]
setblock 246 269 255 minecraft:light[level=15]
setblock 246 269 263 minecraft:light[level=15]
setblock 250 269 228 minecraft:verdant_froglight
setblock 254 269 231 minecraft:light[level=15]
setblock 254 269 239 minecraft:light[level=15]
setblock 254 269 247 minecraft:light[level=15]
setblock 254 269 255 minecraft:light[level=15]
setblock 254 269 263 minecraft:light[level=15]
setblock 262 269 231 minecraft:light[level=15]
setblock 262 269 239 minecraft:light[level=15]
setblock 262 269 247 minecraft:light[level=15]
setblock 262 269 255 minecraft:light[level=15]
setblock 262 269 263 minecraft:light[level=15]
fill 266 269 228 266 308 228 minecraft:black_concrete
setblock 270 269 231 minecraft:light[level=15]
setblock 270 269 239 minecraft:light[level=15]
setblock 270 269 247 minecraft:light[level=15]
setblock 270 269 255 minecraft:light[level=15]
setblock 270 269 263 minecraft:light[level=15]
fill 271 269 228 271 308 228 minecraft:black_concrete
setblock 276 269 228 minecraft:cyan_concrete
setblock 277 269 248 minecraft:cyan_concrete
setblock 235 270 259 minecraft:verdant_froglight
fill 239 270 270 239 308 270 minecraft:black_concrete
fill 250 270 228 250 306 228 minecraft:black_concrete
fill 273 270 245 274 270 245 minecraft:black_stained_glass
setblock 273 270 247 minecraft:cyan_stained_glass
fill 273 270 249 274 270 249 minecraft:black_stained_glass
setblock 273 270 251 minecraft:black_stained_glass
setblock 274 270 247 minecraft:black_stained_glass
setblock 274 270 251 minecraft:magenta_stained_glass
fill 276 270 228 276 308 228 minecraft:black_concrete
fill 277 270 248 277 276 248 minecraft:black_concrete
setblock 277 270 257 minecraft:verdant_froglight
fill 235 271 259 235 308 259 minecraft:black_concrete
setblock 238 271 231 minecraft:light[level=12]
setblock 238 271 238 minecraft:light[level=12]
setblock 238 271 245 minecraft:light[level=12]
setblock 238 271 252 minecraft:light[level=12]
setblock 238 271 259 minecraft:light[level=12]
setblock 238 271 266 minecraft:light[level=12]
setblock 245 271 231 minecraft:light[level=12]
setblock 245 271 238 minecraft:light[level=12]
setblock 245 271 245 minecraft:light[level=12]
setblock 245 271 252 minecraft:light[level=12]
setblock 245 271 259 minecraft:light[level=12]
setblock 245 271 266 minecraft:light[level=12]
setblock 252 271 231 minecraft:light[level=12]
setblock 252 271 238 minecraft:light[level=12]
setblock 252 271 245 minecraft:light[level=12]
setblock 252 271 252 minecraft:light[level=12]
setblock 252 271 259 minecraft:light[level=12]
setblock 252 271 266 minecraft:light[level=12]
setblock 259 271 231 minecraft:light[level=12]
setblock 259 271 238 minecraft:light[level=12]
setblock 259 271 245 minecraft:light[level=12]
setblock 259 271 252 minecraft:light[level=12]
setblock 259 271 259 minecraft:light[level=12]
setblock 259 271 266 minecraft:light[level=12]
setblock 266 271 231 minecraft:light[level=12]
setblock 266 271 238 minecraft:light[level=12]
setblock 266 271 245 minecraft:light[level=12]
setblock 266 271 252 minecraft:light[level=12]
setblock 266 271 259 minecraft:light[level=12]
setblock 266 271 266 minecraft:light[level=12]
setblock 273 271 231 minecraft:light[level=12]
setblock 273 271 238 minecraft:light[level=12]
fill 273 271 245 274 272 245 minecraft:light_gray_concrete
fill 273 271 247 274 272 247 minecraft:light_gray_concrete
fill 273 271 249 274 272 249 minecraft:light_gray_concrete
fill 273 271 251 274 272 251 minecraft:light_gray_concrete
setblock 273 271 259 minecraft:light[level=12]
setblock 273 271 266 minecraft:light[level=12]
setblock 277 271 229 minecraft:cyan_concrete
fill 277 271 257 277 308 257 minecraft:black_concrete
fill 255 272 270 255 308 270 minecraft:black_concrete
setblock 256 272 270 minecraft:sea_lantern
setblock 259 272 228 minecraft:verdant_froglight
setblock 269 272 270 minecraft:verdant_froglight
fill 277 272 229 277 273 229 minecraft:black_concrete
setblock 238 273 270 minecraft:ochre_froglight
fill 256 273 270 256 284 270 minecraft:black_concrete
fill 259 273 228 259 308 228 minecraft:black_concrete
setblock 269 273 270 minecraft:ochre_froglight
setblock 273 273 248 minecraft:iron_bars
setblock 277 273 231 minecraft:verdant_froglight
setblock 277 273 265 minecraft:ochre_froglight
setblock 235 274 262 minecraft:magenta_concrete
fill 238 274 270 238 303 270 minecraft:black_concrete
fill 250 274 243 251 274 244 minecraft:sea_lantern
fill 250 274 254 251 274 255 minecraft:sea_lantern
fill 261 274 243 262 274 244 minecraft:sea_lantern
fill 261 274 254 262 274 255 minecraft:sea_lantern
fill 269 274 270 269 280 270 minecraft:black_concrete
setblock 277 274 229 minecraft:ochre_froglight
fill 277 274 231 277 308 231 minecraft:black_concrete
fill 277 274 265 277 308 265 minecraft:black_concrete
setblock 235 275 244 minecraft:blue_concrete
fill 235 275 262 235 308 262 minecraft:black_concrete
fill 249 275 243 251 277 244 minecraft:gray_concrete
fill 249 275 254 251 277 255 minecraft:gray_concrete
setblock 249 275 261 minecraft:sea_lantern
fill 250 275 242 251 277 242 minecraft:gray_concrete
fill 250 275 256 251 277 256 minecraft:gray_concrete
fill 261 275 242 262 277 244 minecraft:gray_concrete
fill 261 275 254 262 277 256 minecraft:gray_concrete
fill 263 275 243 263 277 244 minecraft:gray_concrete
fill 263 275 254 263 277 255 minecraft:gray_concrete
fill 277 275 229 277 308 229 minecraft:black_concrete
fill 235 276 244 235 289 244 minecraft:black_concrete
setblock 235 276 261 minecraft:magenta_concrete
setblock 238 276 231 minecraft:light[level=15]
setblock 238 276 239 minecraft:light[level=15]
setblock 238 276 247 minecraft:light[level=15]
setblock 238 276 255 minecraft:light[level=15]
setblock 238 276 263 minecraft:light[level=15]
setblock 246 276 231 minecraft:light[level=15]
setblock 246 276 239 minecraft:light[level=15]
setblock 246 276 247 minecraft:light[level=15]
setblock 246 276 255 minecraft:light[level=15]
setblock 246 276 263 minecraft:light[level=15]
fill 247 276 261 251 276 261 minecraft:yellow_concrete
fill 248 276 260 250 276 260 minecraft:yellow_concrete
fill 248 276 262 250 276 262 minecraft:yellow_concrete
setblock 254 276 231 minecraft:light[level=15]
setblock 254 276 239 minecraft:light[level=15]
setblock 254 276 247 minecraft:light[level=15]
setblock 254 276 255 minecraft:light[level=15]
setblock 254 276 263 minecraft:light[level=15]
setblock 260 276 270 minecraft:cyan_concrete
setblock 262 276 231 minecraft:light[level=15]
setblock 262 276 239 minecraft:light[level=15]
setblock 262 276 247 minecraft:light[level=15]
setblock 262 276 263 minecraft:light[level=15]
setblock 270 276 231 minecraft:light[level=15]
setblock 270 276 239 minecraft:light[level=15]
setblock 270 276 247 minecraft:light[level=15]
setblock 270 276 255 minecraft:light[level=15]
setblock 270 276 263 minecraft:light[level=15]
setblock 273 276 248 minecraft:redstone_block
fill 235 277 261 235 280 261 minecraft:black_concrete
schedule function dropper:buildpart/53_8 1t
