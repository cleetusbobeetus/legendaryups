setblock 387 261 584 minecraft:light[level=12]
setblock 387 261 592 minecraft:light[level=12]
fill 387 261 599 387 264 599 minecraft:black_concrete
setblock 395 261 557 minecraft:purple_concrete
setblock 395 261 560 minecraft:light[level=12]
setblock 395 261 568 minecraft:light[level=12]
setblock 395 261 576 minecraft:light[level=12]
setblock 395 261 584 minecraft:light[level=12]
setblock 395 261 592 minecraft:light[level=12]
fill 398 261 599 398 264 599 minecraft:black_concrete
fill 400 261 557 400 264 557 minecraft:black_concrete
fill 402 261 592 404 261 593 minecraft:black_concrete
setblock 403 261 560 minecraft:light[level=12]
setblock 403 261 568 minecraft:light[level=12]
setblock 403 261 576 minecraft:light[level=12]
setblock 403 261 584 minecraft:light[level=12]
fill 403 261 590 404 261 590 minecraft:black_concrete
setblock 403 261 599 minecraft:purple_concrete
fill 404 261 589 404 262 589 minecraft:black_concrete
setblock 404 261 591 minecraft:black_concrete
setblock 405 261 588 minecraft:black_concrete
fill 405 261 589 405 264 589 minecraft:purple_concrete
fill 405 261 591 405 263 592 minecraft:purple_concrete
fill 405 261 593 407 262 593 minecraft:black_concrete
fill 406 261 588 408 265 588 minecraft:purple_concrete
fill 406 261 592 408 263 592 minecraft:purple_concrete
fill 409 261 589 409 265 591 minecraft:purple_concrete
fill 411 261 557 411 264 557 minecraft:black_concrete
setblock 411 261 560 minecraft:light[level=12]
setblock 411 261 568 minecraft:light[level=12]
setblock 411 261 576 minecraft:light[level=12]
setblock 411 261 584 minecraft:light[level=12]
setblock 411 261 592 minecraft:light[level=12]
setblock 412 261 557 minecraft:purple_concrete
setblock 414 261 599 minecraft:purple_concrete
fill 415 261 557 416 261 557 minecraft:purple_concrete
fill 418 261 571 418 264 571 minecraft:black_concrete
setblock 418 261 575 minecraft:purple_concrete
fill 418 261 582 418 264 582 minecraft:black_concrete
setblock 418 261 583 minecraft:purple_concrete
setblock 418 261 586 minecraft:purple_concrete
fill 418 261 599 418 264 599 minecraft:black_concrete
fill 376 262 557 376 267 557 minecraft:black_concrete
fill 376 262 563 376 263 564 minecraft:purple_concrete
fill 376 262 565 376 267 566 minecraft:black_concrete
setblock 376 262 571 minecraft:black_concrete
fill 376 262 572 376 263 572 minecraft:purple_concrete
fill 376 262 574 376 267 574 minecraft:black_concrete
fill 376 262 575 376 262 576 minecraft:purple_concrete
fill 376 262 577 376 264 578 minecraft:black_concrete
fill 376 262 583 376 263 584 minecraft:purple_concrete
fill 376 262 585 376 267 586 minecraft:black_concrete
setblock 376 262 587 minecraft:purple_concrete
fill 376 262 588 376 265 588 minecraft:black_concrete
fill 376 262 595 376 263 596 minecraft:purple_concrete
fill 376 262 597 376 267 598 minecraft:black_concrete
fill 381 262 599 381 263 599 minecraft:purple_concrete
setblock 382 262 557 minecraft:purple_concrete
fill 382 262 599 383 267 599 minecraft:black_concrete
fill 383 262 557 384 267 557 minecraft:black_concrete
setblock 384 262 599 minecraft:purple_concrete
fill 385 262 557 386 263 557 minecraft:purple_concrete
fill 386 262 599 386 267 599 minecraft:black_concrete
fill 391 262 557 392 267 557 minecraft:black_concrete
fill 392 262 599 393 263 599 minecraft:purple_concrete
fill 393 262 557 394 262 557 minecraft:purple_concrete
fill 394 262 599 395 267 599 minecraft:black_concrete
fill 395 262 557 395 267 557 minecraft:black_concrete
fill 403 262 557 404 267 557 minecraft:black_concrete
fill 403 262 590 403 262 592 minecraft:black_concrete
fill 403 262 599 403 267 599 minecraft:black_concrete
fill 404 262 590 404 262 591 minecraft:purple_concrete
fill 404 262 592 404 262 593 minecraft:black_concrete
fill 404 262 599 405 262 599 minecraft:purple_concrete
fill 405 262 557 406 263 557 minecraft:purple_concrete
fill 405 262 588 405 263 588 minecraft:purple_concrete
fill 406 262 599 407 267 599 minecraft:black_concrete
fill 407 262 587 409 267 587 minecraft:purple_concrete
fill 409 262 588 409 268 588 minecraft:purple_concrete
fill 410 262 589 410 267 589 minecraft:purple_concrete
fill 412 262 557 412 267 557 minecraft:black_concrete
fill 412 262 599 413 263 599 minecraft:purple_concrete
setblock 414 262 557 minecraft:purple_concrete
fill 414 262 599 415 267 599 minecraft:black_concrete
fill 415 262 557 416 267 557 minecraft:black_concrete
setblock 416 262 599 minecraft:purple_concrete
fill 417 262 557 417 263 557 minecraft:purple_concrete
fill 418 262 562 418 267 563 minecraft:black_concrete
fill 418 262 564 418 262 565 minecraft:purple_concrete
fill 418 262 574 418 267 575 minecraft:black_concrete
fill 418 262 576 418 263 577 minecraft:purple_concrete
fill 418 262 583 418 267 583 minecraft:black_concrete
fill 418 262 584 418 262 585 minecraft:purple_concrete
fill 418 262 586 418 267 586 minecraft:black_concrete
fill 418 262 588 418 263 588 minecraft:purple_concrete
fill 418 262 594 418 267 595 minecraft:black_concrete
fill 418 262 596 418 263 597 minecraft:purple_concrete
setblock 376 263 571 minecraft:purple_concrete
setblock 376 263 575 minecraft:purple_concrete
fill 376 263 576 376 266 576 minecraft:black_concrete
fill 376 263 587 376 265 587 minecraft:black_concrete
setblock 376 263 592 minecraft:purple_concrete
setblock 377 263 557 minecraft:purple_concrete
setblock 380 263 599 minecraft:purple_concrete
fill 382 263 557 382 266 557 minecraft:black_concrete
fill 384 263 599 384 266 599 minecraft:black_concrete
fill 393 263 557 393 266 557 minecraft:black_concrete
setblock 394 263 557 minecraft:purple_concrete
fill 397 263 557 398 263 557 minecraft:purple_concrete
fill 400 263 599 401 263 599 minecraft:purple_concrete
setblock 404 263 590 minecraft:purple_concrete
setblock 404 263 591 minecraft:black_concrete
setblock 404 263 599 minecraft:purple_concrete
fill 405 263 599 405 266 599 minecraft:black_concrete
fill 406 263 587 406 265 587 minecraft:purple_concrete
fill 408 263 586 409 268 586 minecraft:purple_concrete
fill 410 263 587 410 268 588 minecraft:purple_concrete
fill 410 263 590 410 266 590 minecraft:purple_concrete
fill 414 263 557 414 266 557 minecraft:black_concrete
fill 416 263 599 416 266 599 minecraft:black_concrete
setblock 418 263 557 minecraft:purple_concrete
fill 418 263 564 418 266 564 minecraft:black_concrete
setblock 418 263 565 minecraft:purple_concrete
setblock 418 263 568 minecraft:purple_concrete
fill 418 263 584 418 266 585 minecraft:black_concrete
setblock 418 263 589 minecraft:purple_concrete
fill 376 264 561 376 264 562 minecraft:purple_concrete
fill 376 264 563 376 269 564 minecraft:black_concrete
fill 376 264 569 376 265 570 minecraft:purple_concrete
fill 376 264 571 376 269 572 minecraft:black_concrete
setblock 376 264 573 minecraft:purple_concrete
fill 376 264 575 376 266 575 minecraft:black_concrete
fill 376 264 581 376 265 582 minecraft:purple_concrete
fill 376 264 583 376 269 584 minecraft:black_concrete
setblock 376 264 589 minecraft:black_concrete
fill 376 264 590 376 265 590 minecraft:purple_concrete
fill 376 264 592 376 269 592 minecraft:black_concrete
fill 376 264 593 376 264 594 minecraft:purple_concrete
fill 376 264 595 376 266 596 minecraft:black_concrete
fill 377 264 557 377 269 557 minecraft:black_concrete
fill 377 264 558 379 264 558 minecraft:obsidian
fill 377 264 560 377 264 562 minecraft:obsidian
fill 377 264 564 377 264 566 minecraft:obsidian
fill 377 264 568 377 264 570 minecraft:obsidian
fill 377 264 572 377 264 574 minecraft:obsidian
fill 377 264 576 377 264 578 minecraft:obsidian
fill 377 264 580 377 264 582 minecraft:obsidian
fill 377 264 584 377 264 586 minecraft:obsidian
fill 377 264 588 377 264 590 minecraft:obsidian
fill 377 264 592 377 264 594 minecraft:obsidian
fill 377 264 596 377 264 598 minecraft:obsidian
fill 378 264 599 379 265 599 minecraft:purple_concrete
fill 379 264 598 381 264 598 minecraft:obsidian
fill 380 264 599 381 269 599 minecraft:black_concrete
fill 381 264 558 383 264 558 minecraft:obsidian
fill 383 264 598 385 264 598 minecraft:obsidian
fill 385 264 557 386 269 557 minecraft:black_concrete
fill 385 264 558 387 264 558 minecraft:obsidian
fill 387 264 557 388 265 557 minecraft:purple_concrete
fill 387 264 598 389 264 598 minecraft:obsidian
fill 389 264 558 391 264 558 minecraft:obsidian
fill 390 264 599 391 264 599 minecraft:purple_concrete
fill 391 264 598 393 264 598 minecraft:obsidian
fill 392 264 599 393 269 599 minecraft:black_concrete
fill 393 264 558 395 264 558 minecraft:obsidian
fill 394 264 557 394 269 557 minecraft:black_concrete
fill 395 264 598 397 264 598 minecraft:obsidian
setblock 396 264 557 minecraft:purple_concrete
fill 397 264 557 398 269 557 minecraft:black_concrete
fill 397 264 558 399 264 558 minecraft:obsidian
fill 399 264 557 399 265 557 minecraft:purple_concrete
fill 399 264 598 401 264 598 minecraft:obsidian
fill 399 264 599 399 265 599 minecraft:purple_concrete
fill 400 264 599 401 269 599 minecraft:black_concrete
fill 401 264 558 403 264 558 minecraft:obsidian
setblock 402 264 599 minecraft:purple_concrete
fill 403 264 598 405 264 598 minecraft:obsidian
fill 404 264 599 404 269 599 minecraft:black_concrete
fill 405 264 557 406 269 557 minecraft:black_concrete
fill 405 264 558 407 264 558 minecraft:obsidian
setblock 405 264 591 minecraft:purple_concrete
fill 406 264 592 407 264 592 minecraft:purple_concrete
fill 407 264 557 408 264 557 minecraft:purple_concrete
fill 407 264 586 407 266 586 minecraft:purple_concrete
fill 407 264 598 409 264 598 minecraft:obsidian
fill 409 264 558 411 264 558 minecraft:obsidian
fill 410 264 586 411 270 586 minecraft:purple_concrete
fill 410 264 599 411 265 599 minecraft:purple_concrete
fill 411 264 587 411 267 589 minecraft:purple_concrete
fill 411 264 598 413 264 598 minecraft:obsidian
fill 412 264 599 413 269 599 minecraft:black_concrete
fill 413 264 558 415 264 558 minecraft:obsidian
fill 415 264 598 417 264 598 minecraft:obsidian
fill 417 264 557 418 269 557 minecraft:black_concrete
fill 417 264 558 417 264 560 minecraft:obsidian
fill 417 264 562 417 264 564 minecraft:obsidian
fill 417 264 566 417 264 568 minecraft:obsidian
fill 417 264 570 417 264 572 minecraft:obsidian
fill 417 264 574 417 264 576 minecraft:obsidian
fill 417 264 578 417 264 580 minecraft:obsidian
fill 417 264 582 417 264 584 minecraft:obsidian
fill 417 264 586 417 264 588 minecraft:obsidian
fill 417 264 590 417 264 592 minecraft:obsidian
fill 417 264 594 417 264 596 minecraft:obsidian
fill 418 264 558 418 265 559 minecraft:purple_concrete
fill 418 264 565 418 269 565 minecraft:black_concrete
fill 418 264 566 418 264 567 minecraft:purple_concrete
fill 418 264 568 418 269 568 minecraft:black_concrete
fill 418 264 570 418 265 570 minecraft:purple_concrete
fill 418 264 576 418 269 577 minecraft:black_concrete
fill 418 264 578 418 265 579 minecraft:purple_concrete
setblock 418 264 587 minecraft:purple_concrete
fill 418 264 588 418 269 589 minecraft:black_concrete
fill 418 264 590 418 265 591 minecraft:purple_concrete
fill 418 264 596 418 269 597 minecraft:black_concrete
setblock 418 264 598 minecraft:purple_concrete
setblock 376 265 558 minecraft:purple_concrete
setblock 376 265 561 minecraft:purple_concrete
fill 376 265 562 376 268 562 minecraft:black_concrete
fill 376 265 573 376 268 573 minecraft:black_concrete
fill 376 265 577 376 267 577 minecraft:black_concrete
setblock 376 265 578 minecraft:purple_concrete
setblock 376 265 589 minecraft:purple_concrete
setblock 376 265 593 minecraft:purple_concrete
fill 376 265 594 376 268 594 minecraft:black_concrete
fill 379 265 557 380 265 557 minecraft:purple_concrete
setblock 387 265 599 minecraft:purple_concrete
setblock 390 265 599 minecraft:purple_concrete
fill 391 265 599 391 268 599 minecraft:black_concrete
fill 396 265 557 396 268 557 minecraft:black_concrete
setblock 398 265 599 minecraft:purple_concrete
setblock 400 265 557 minecraft:purple_concrete
fill 402 265 599 402 268 599 minecraft:black_concrete
fill 406 265 590 408 265 590 minecraft:purple_concrete
fill 407 265 557 407 268 557 minecraft:black_concrete
fill 407 265 591 408 265 591 minecraft:purple_concrete
setblock 408 265 557 minecraft:purple_concrete
fill 408 265 585 411 268 585 minecraft:purple_concrete
setblock 411 265 557 minecraft:purple_concrete
fill 412 265 586 412 269 587 minecraft:purple_concrete
fill 418 265 566 418 268 567 minecraft:black_concrete
setblock 418 265 571 minecraft:purple_concrete
setblock 418 265 582 minecraft:purple_concrete
fill 418 265 587 418 268 587 minecraft:black_concrete
fill 418 265 598 418 268 598 minecraft:black_concrete
setblock 418 265 599 minecraft:purple_concrete
fill 376 266 558 376 271 558 minecraft:black_concrete
fill 376 266 559 376 266 560 minecraft:purple_concrete
fill 376 266 561 376 271 561 minecraft:black_concrete
fill 376 266 567 376 267 568 minecraft:purple_concrete
fill 376 266 569 376 271 570 minecraft:black_concrete
fill 376 266 578 376 267 578 minecraft:black_concrete
fill 376 266 579 376 266 580 minecraft:purple_concrete
fill 376 266 581 376 271 582 minecraft:black_concrete
fill 376 266 587 376 267 588 minecraft:purple_concrete
fill 376 266 589 376 271 590 minecraft:black_concrete
setblock 376 266 591 minecraft:purple_concrete
fill 376 266 593 376 268 593 minecraft:black_concrete
fill 376 266 599 377 267 599 minecraft:purple_concrete
setblock 378 266 557 minecraft:purple_concrete
fill 378 266 599 379 271 599 minecraft:black_concrete
fill 379 266 557 380 271 557 minecraft:black_concrete
fill 381 266 557 381 267 557 minecraft:purple_concrete
fill 385 266 599 385 267 599 minecraft:purple_concrete
fill 387 266 557 388 271 557 minecraft:black_concrete
fill 387 266 599 387 271 599 minecraft:black_concrete
fill 388 266 599 389 266 599 minecraft:purple_concrete
fill 389 266 557 390 266 557 minecraft:purple_concrete
fill 390 266 599 390 271 599 minecraft:black_concrete
fill 396 266 599 397 267 599 minecraft:purple_concrete
fill 398 266 599 399 271 599 minecraft:black_concrete
fill 399 266 557 400 271 557 minecraft:black_concrete
fill 401 266 557 402 267 557 minecraft:purple_concrete
fill 406 266 590 406 268 590 minecraft:amethyst_block
fill 407 266 588 408 266 590 minecraft:purple_concrete
fill 408 266 557 408 271 557 minecraft:black_concrete
fill 408 266 599 409 266 599 minecraft:purple_concrete
fill 409 266 557 410 266 557 minecraft:purple_concrete
fill 409 266 584 412 267 584 minecraft:purple_concrete
fill 409 266 589 409 266 590 minecraft:purple_concrete
fill 410 266 599 411 271 599 minecraft:black_concrete
fill 411 266 557 411 271 557 minecraft:black_concrete
fill 412 266 585 412 268 585 minecraft:purple_concrete
fill 412 266 588 412 267 588 minecraft:purple_concrete
fill 413 266 557 413 267 557 minecraft:purple_concrete
fill 417 266 599 417 267 599 minecraft:purple_concrete
fill 418 266 558 418 271 559 minecraft:black_concrete
fill 418 266 560 418 267 561 minecraft:purple_concrete
setblock 418 266 569 minecraft:purple_concrete
fill 418 266 570 418 271 571 minecraft:black_concrete
fill 418 266 572 418 267 573 minecraft:purple_concrete
fill 418 266 578 418 271 579 minecraft:black_concrete
fill 418 266 580 418 266 581 minecraft:purple_concrete
fill 418 266 582 418 271 582 minecraft:black_concrete
fill 418 266 590 418 271 591 minecraft:black_concrete
fill 418 266 592 418 267 593 minecraft:purple_concrete
fill 418 266 599 418 271 599 minecraft:black_concrete
fill 376 267 559 376 269 560 minecraft:black_concrete
fill 376 267 575 376 267 576 minecraft:purple_concrete
setblock 376 267 579 minecraft:purple_concrete
fill 376 267 580 376 270 580 minecraft:black_concrete
fill 376 267 591 376 270 591 minecraft:black_concrete
fill 376 267 595 376 269 595 minecraft:black_concrete
setblock 376 267 596 minecraft:purple_concrete
fill 378 267 557 378 270 557 minecraft:black_concrete
setblock 382 267 557 minecraft:purple_concrete
setblock 384 267 599 minecraft:purple_concrete
fill 388 267 599 389 270 599 minecraft:black_concrete
fill 389 267 557 389 270 557 minecraft:black_concrete
setblock 390 267 557 minecraft:purple_concrete
setblock 393 267 557 minecraft:purple_concrete
setblock 405 267 599 minecraft:purple_concrete
fill 407 267 588 408 267 588 minecraft:purple_concrete
fill 407 267 590 407 268 590 minecraft:amethyst_block
fill 408 267 589 409 267 589 minecraft:purple_concrete
setblock 408 267 599 minecraft:purple_concrete
fill 409 267 557 410 270 557 minecraft:black_concrete
fill 409 267 583 412 267 583 minecraft:purple_concrete
fill 409 267 599 409 270 599 minecraft:black_concrete
fill 413 267 584 413 268 586 minecraft:purple_concrete
setblock 414 267 557 minecraft:purple_concrete
setblock 416 267 599 minecraft:purple_concrete
setblock 418 267 564 minecraft:purple_concrete
fill 418 267 569 418 270 569 minecraft:black_concrete
fill 418 267 580 418 270 580 minecraft:black_concrete
setblock 418 267 581 minecraft:purple_concrete
fill 418 267 584 418 267 585 minecraft:purple_concrete
setblock 376 268 557 minecraft:purple_concrete
fill 376 268 565 376 269 566 minecraft:purple_concrete
fill 376 268 567 376 285 568 minecraft:black_concrete
fill 376 268 574 376 269 574 minecraft:purple_concrete
fill 376 268 575 376 269 576 minecraft:black_concrete
fill 376 268 577 376 268 578 minecraft:purple_concrete
fill 376 268 579 376 285 579 minecraft:black_concrete
fill 376 268 585 376 269 586 minecraft:purple_concrete
fill 376 268 587 376 286 588 minecraft:black_concrete
fill 376 268 596 376 289 596 minecraft:black_concrete
fill 376 268 597 376 268 598 minecraft:purple_concrete
fill 376 268 599 377 285 599 minecraft:black_concrete
fill 381 268 557 382 286 557 minecraft:black_concrete
fill 382 268 599 383 269 599 minecraft:purple_concrete
fill 383 268 557 384 269 557 minecraft:purple_concrete
fill 384 268 599 385 286 599 minecraft:black_concrete
setblock 386 268 599 minecraft:purple_concrete
fill 390 268 557 390 285 557 minecraft:black_concrete
fill 391 268 557 392 268 557 minecraft:purple_concrete
fill 393 268 557 393 289 557 minecraft:black_concrete
fill 394 268 599 395 269 599 minecraft:purple_concrete
fill 395 268 557 395 269 557 minecraft:purple_concrete
fill 396 268 599 397 285 599 minecraft:black_concrete
fill 401 268 557 402 285 557 minecraft:black_concrete
fill 403 268 557 404 269 557 minecraft:purple_concrete
fill 403 268 599 403 269 599 minecraft:purple_concrete
fill 405 268 599 405 289 599 minecraft:black_concrete
fill 406 268 599 407 268 599 minecraft:purple_concrete
fill 408 268 587 408 268 588 minecraft:purple_concrete
fill 408 268 599 408 285 599 minecraft:black_concrete
fill 409 268 583 410 268 584 minecraft:purple_concrete
fill 409 268 587 409 269 587 minecraft:purple_concrete
setblock 410 268 582 minecraft:purple_concrete
fill 411 268 582 413 273 583 minecraft:black_concrete
setblock 411 268 584 minecraft:purple_concrete
fill 411 268 587 411 268 588 minecraft:purple_concrete
setblock 412 268 557 minecraft:purple_concrete
fill 412 268 584 412 272 584 minecraft:black_concrete
fill 413 268 557 414 286 557 minecraft:black_concrete
fill 414 268 599 415 269 599 minecraft:purple_concrete
fill 415 268 557 416 269 557 minecraft:purple_concrete
fill 416 268 599 417 286 599 minecraft:black_concrete
fill 418 268 560 418 285 561 minecraft:black_concrete
fill 418 268 562 418 268 563 minecraft:purple_concrete
fill 418 268 564 418 289 564 minecraft:black_concrete
fill 418 268 572 418 286 573 minecraft:black_concrete
fill 418 268 574 418 269 575 minecraft:purple_concrete
fill 418 268 581 418 285 581 minecraft:black_concrete
setblock 418 268 583 minecraft:purple_concrete
fill 418 268 584 418 289 585 minecraft:black_concrete
fill 418 268 586 418 269 586 minecraft:purple_concrete
fill 418 268 592 418 285 593 minecraft:black_concrete
fill 418 268 594 418 268 595 minecraft:purple_concrete
fill 376 269 557 376 271 557 minecraft:black_concrete
setblock 376 269 562 minecraft:purple_concrete
setblock 376 269 573 minecraft:purple_concrete
fill 376 269 577 376 271 578 minecraft:black_concrete
fill 376 269 593 376 269 594 minecraft:purple_concrete
setblock 376 269 597 minecraft:purple_concrete
fill 376 269 598 376 272 598 minecraft:black_concrete
setblock 379 269 560 minecraft:light[level=12]
setblock 379 269 568 minecraft:light[level=12]
setblock 379 269 576 minecraft:light[level=12]
setblock 379 269 584 minecraft:light[level=12]
setblock 379 269 592 minecraft:light[level=12]
fill 386 269 599 386 272 599 minecraft:black_concrete
setblock 387 269 560 minecraft:light[level=12]
setblock 387 269 568 minecraft:light[level=12]
setblock 387 269 576 minecraft:light[level=12]
setblock 387 269 584 minecraft:light[level=12]
setblock 387 269 592 minecraft:light[level=12]
fill 391 269 557 392 272 557 minecraft:black_concrete
setblock 391 269 599 minecraft:purple_concrete
setblock 395 269 560 minecraft:light[level=12]
setblock 395 269 568 minecraft:light[level=12]
setblock 395 269 576 minecraft:light[level=12]
setblock 395 269 584 minecraft:light[level=12]
setblock 395 269 592 minecraft:light[level=12]
setblock 396 269 557 minecraft:purple_concrete
setblock 402 269 599 minecraft:purple_concrete
setblock 403 269 560 minecraft:light[level=12]
setblock 403 269 568 minecraft:light[level=12]
setblock 403 269 576 minecraft:light[level=12]
setblock 403 269 584 minecraft:light[level=12]
setblock 403 269 592 minecraft:light[level=12]
fill 406 269 599 407 272 599 minecraft:black_concrete
setblock 407 269 557 minecraft:purple_concrete
fill 409 269 583 409 270 586 minecraft:purple_concrete
fill 410 269 581 410 271 584 minecraft:black_concrete
fill 410 269 585 411 269 585 minecraft:purple_concrete
fill 410 269 587 411 269 587 minecraft:purple_concrete
setblock 411 269 560 minecraft:light[level=12]
setblock 411 269 568 minecraft:light[level=12]
setblock 411 269 576 minecraft:light[level=12]
fill 411 269 581 413 273 581 minecraft:black_concrete
fill 411 269 584 411 272 584 minecraft:black_concrete
setblock 411 269 592 minecraft:light[level=12]
fill 412 269 557 412 272 557 minecraft:black_concrete
fill 412 269 580 412 273 580 minecraft:black_concrete
fill 412 269 585 412 271 585 minecraft:black_concrete
fill 413 269 584 413 272 584 minecraft:black_concrete
fill 413 269 585 413 269 586 minecraft:purple_concrete
fill 414 269 582 414 272 583 minecraft:black_concrete
setblock 414 269 584 minecraft:purple_concrete
fill 418 269 562 418 272 562 minecraft:black_concrete
setblock 418 269 563 minecraft:purple_concrete
fill 418 269 566 418 269 567 minecraft:purple_concrete
fill 418 269 583 418 272 583 minecraft:black_concrete
setblock 418 269 587 minecraft:purple_concrete
fill 418 269 594 418 272 594 minecraft:black_concrete
setblock 418 269 595 minecraft:purple_concrete
setblock 418 269 598 minecraft:purple_concrete
setblock 376 270 559 minecraft:black_concrete
fill 376 270 560 376 271 560 minecraft:purple_concrete
fill 376 270 562 376 283 562 minecraft:black_concrete
fill 376 270 563 376 270 564 minecraft:purple_concrete
fill 376 270 565 376 272 566 minecraft:black_concrete
fill 376 270 571 376 271 572 minecraft:purple_concrete
fill 376 270 573 376 283 574 minecraft:black_concrete
setblock 376 270 575 minecraft:purple_concrete
fill 376 270 576 376 289 576 minecraft:black_concrete
fill 376 270 583 376 271 584 minecraft:purple_concrete
fill 376 270 585 376 283 586 minecraft:black_concrete
fill 376 270 592 376 271 592 minecraft:purple_concrete
fill 376 270 593 376 283 594 minecraft:black_concrete
setblock 376 270 595 minecraft:purple_concrete
fill 376 270 597 376 287 597 minecraft:black_concrete
fill 377 270 557 377 271 557 minecraft:purple_concrete
fill 377 270 558 379 270 558 minecraft:obsidian
fill 377 270 560 377 270 562 minecraft:obsidian
fill 377 270 564 377 270 566 minecraft:obsidian
fill 377 270 568 377 270 570 minecraft:obsidian
fill 377 270 572 377 270 574 minecraft:obsidian
fill 377 270 576 377 270 578 minecraft:obsidian
fill 377 270 580 377 270 582 minecraft:obsidian
fill 377 270 584 377 270 586 minecraft:obsidian
fill 377 270 588 377 270 590 minecraft:obsidian
fill 377 270 592 377 270 594 minecraft:obsidian
fill 377 270 596 377 270 598 minecraft:obsidian
fill 379 270 598 381 270 598 minecraft:obsidian
fill 380 270 599 381 271 599 minecraft:purple_concrete
fill 381 270 558 383 270 558 minecraft:obsidian
fill 382 270 599 383 283 599 minecraft:black_concrete
fill 383 270 557 384 283 557 minecraft:black_concrete
fill 383 270 598 385 270 598 minecraft:obsidian
fill 385 270 557 386 271 557 minecraft:purple_concrete
fill 385 270 558 387 270 558 minecraft:obsidian
fill 387 270 598 389 270 598 minecraft:obsidian
fill 389 270 558 391 270 558 minecraft:obsidian
fill 391 270 598 393 270 598 minecraft:obsidian
fill 391 270 599 391 283 599 minecraft:black_concrete
fill 392 270 599 393 270 599 minecraft:purple_concrete
fill 393 270 558 395 270 558 minecraft:obsidian
setblock 394 270 557 minecraft:purple_concrete
fill 394 270 599 395 287 599 minecraft:black_concrete
fill 395 270 557 396 283 557 minecraft:black_concrete
fill 395 270 598 397 270 598 minecraft:obsidian
fill 397 270 557 398 271 557 minecraft:purple_concrete
fill 397 270 558 399 270 558 minecraft:obsidian
fill 399 270 598 401 270 598 minecraft:obsidian
fill 400 270 599 401 271 599 minecraft:purple_concrete
fill 401 270 558 403 270 558 minecraft:obsidian
fill 402 270 599 403 283 599 minecraft:black_concrete
fill 403 270 557 404 287 557 minecraft:black_concrete
fill 403 270 598 405 270 598 minecraft:obsidian
setblock 404 270 599 minecraft:purple_concrete
fill 405 270 557 406 270 557 minecraft:purple_concrete
fill 405 270 558 407 270 558 minecraft:obsidian
fill 407 270 557 407 283 557 minecraft:black_concrete
fill 407 270 598 409 270 598 minecraft:obsidian
fill 409 270 558 411 270 558 minecraft:obsidian
setblock 409 270 582 minecraft:purple_concrete
fill 410 270 585 410 271 585 minecraft:purple_concrete
fill 411 270 580 411 273 580 minecraft:black_concrete
fill 411 270 585 411 271 585 minecraft:black_concrete
fill 411 270 598 413 270 598 minecraft:obsidian
fill 412 270 579 412 273 579 minecraft:black_concrete
setblock 412 270 586 minecraft:purple_concrete
fill 412 270 599 413 271 599 minecraft:purple_concrete
fill 413 270 558 415 270 558 minecraft:obsidian
fill 413 270 580 413 273 580 minecraft:black_concrete
fill 413 270 585 413 271 585 minecraft:black_concrete
fill 414 270 581 414 273 581 minecraft:black_concrete
fill 414 270 584 414 271 584 minecraft:black_concrete
fill 414 270 599 415 283 599 minecraft:black_concrete
fill 415 270 557 416 283 557 minecraft:black_concrete
fill 415 270 598 417 270 598 minecraft:obsidian
fill 417 270 557 418 271 557 minecraft:purple_concrete
fill 417 270 558 417 270 560 minecraft:obsidian
fill 417 270 562 417 270 564 minecraft:obsidian
fill 417 270 566 417 270 568 minecraft:obsidian
fill 417 270 570 417 270 572 minecraft:obsidian
fill 417 270 574 417 270 576 minecraft:obsidian
fill 417 270 578 417 270 580 minecraft:obsidian
fill 417 270 582 417 270 584 minecraft:obsidian
fill 417 270 586 417 270 588 minecraft:obsidian
fill 417 270 590 417 270 592 minecraft:obsidian
fill 417 270 594 417 270 596 minecraft:obsidian
fill 418 270 563 418 287 563 minecraft:black_concrete
setblock 418 270 565 minecraft:purple_concrete
fill 418 270 566 418 283 567 minecraft:black_concrete
fill 418 270 568 418 271 568 minecraft:purple_concrete
fill 418 270 574 418 283 575 minecraft:black_concrete
fill 418 270 576 418 270 577 minecraft:purple_concrete
fill 418 270 586 418 283 587 minecraft:black_concrete
fill 418 270 588 418 271 589 minecraft:purple_concrete
fill 418 270 595 418 287 595 minecraft:black_concrete
fill 418 270 596 418 270 597 minecraft:purple_concrete
fill 418 270 598 418 283 598 minecraft:black_concrete
setblock 376 271 559 minecraft:purple_concrete
setblock 376 271 563 minecraft:purple_concrete
fill 376 271 564 376 289 564 minecraft:black_concrete
fill 376 271 575 376 289 575 minecraft:black_concrete
setblock 376 271 580 minecraft:purple_concrete
setblock 376 271 591 minecraft:purple_concrete
fill 376 271 595 376 289 595 minecraft:black_concrete
setblock 378 271 557 minecraft:purple_concrete
fill 388 271 599 389 271 599 minecraft:purple_concrete
setblock 389 271 557 minecraft:purple_concrete
setblock 392 271 599 minecraft:purple_concrete
fill 393 271 599 393 289 599 minecraft:black_concrete
fill 394 271 557 394 289 557 minecraft:black_concrete
fill 395 271 569 395 272 569 minecraft:obsidian
fill 404 271 599 404 289 599 minecraft:black_concrete
fill 405 271 557 405 289 557 minecraft:black_concrete
setblock 406 271 557 minecraft:purple_concrete
fill 409 271 557 410 271 557 minecraft:purple_concrete
setblock 409 271 599 minecraft:purple_concrete
fill 410 271 580 410 273 580 minecraft:black_concrete
fill 411 271 577 411 272 577 minecraft:obsidian
fill 411 271 579 411 273 579 minecraft:black_concrete
fill 412 271 578 413 273 578 minecraft:black_concrete
fill 413 271 579 414 273 579 minecraft:black_concrete
fill 414 271 580 414 273 580 minecraft:black_concrete
fill 418 271 565 418 289 565 minecraft:black_concrete
setblock 418 271 569 minecraft:purple_concrete
fill 418 271 576 418 289 576 minecraft:black_concrete
setblock 418 271 577 minecraft:purple_concrete
setblock 418 271 580 minecraft:purple_concrete
fill 418 271 596 418 289 597 minecraft:black_concrete
fill 376 272 557 376 273 558 minecraft:purple_concrete
fill 376 272 559 376 285 560 minecraft:black_concrete
setblock 376 272 561 minecraft:purple_concrete
fill 376 272 563 376 289 563 minecraft:black_concrete
fill 376 272 569 376 273 570 minecraft:purple_concrete
fill 376 272 571 376 285 572 minecraft:black_concrete
setblock 376 272 577 minecraft:black_concrete
fill 376 272 578 376 273 578 minecraft:purple_concrete
fill 376 272 580 376 285 580 minecraft:black_concrete
fill 376 272 581 376 272 582 minecraft:purple_concrete
fill 376 272 583 376 289 584 minecraft:black_concrete
fill 376 272 589 376 273 590 minecraft:purple_concrete
fill 376 272 591 376 285 592 minecraft:black_concrete
fill 377 272 557 378 285 557 minecraft:black_concrete
fill 378 272 599 379 272 599 minecraft:purple_concrete
fill 379 272 557 380 273 557 minecraft:purple_concrete
fill 380 272 599 381 285 599 minecraft:black_concrete
fill 385 272 557 386 289 557 minecraft:black_concrete
fill 387 272 557 388 272 557 minecraft:purple_concrete
fill 387 272 599 387 273 599 minecraft:purple_concrete
fill 388 272 599 389 285 599 minecraft:black_concrete
fill 389 272 557 389 285 557 minecraft:black_concrete
setblock 390 272 599 minecraft:purple_concrete
fill 392 272 599 392 289 599 minecraft:black_concrete
fill 397 272 557 398 285 557 minecraft:black_concrete
fill 398 272 599 399 273 599 minecraft:purple_concrete
fill 399 272 557 400 273 557 minecraft:purple_concrete
fill 400 272 599 401 285 599 minecraft:black_concrete
fill 406 272 557 406 289 557 minecraft:black_concrete
setblock 408 272 557 minecraft:purple_concrete
fill 409 272 557 410 285 557 minecraft:black_concrete
fill 409 272 599 409 285 599 minecraft:black_concrete
fill 410 272 579 410 273 579 minecraft:black_concrete
fill 410 272 581 410 272 583 minecraft:black_concrete
setblock 410 272 584 minecraft:purple_concrete
fill 410 272 599 411 272 599 minecraft:purple_concrete
fill 411 272 557 411 273 557 minecraft:purple_concrete
fill 411 272 578 411 273 578 minecraft:black_concrete
fill 412 272 577 413 273 577 minecraft:black_concrete
fill 412 272 599 413 289 599 minecraft:black_concrete
fill 414 272 578 414 273 578 minecraft:black_concrete
fill 417 272 557 418 285 557 minecraft:black_concrete
fill 418 272 558 418 272 559 minecraft:purple_concrete
fill 418 272 568 418 285 569 minecraft:black_concrete
fill 418 272 570 418 273 571 minecraft:purple_concrete
fill 418 272 577 418 289 577 minecraft:black_concrete
fill 418 272 578 418 272 579 minecraft:purple_concrete
fill 418 272 580 418 285 580 minecraft:black_concrete
fill 418 272 582 418 273 582 minecraft:purple_concrete
fill 418 272 588 418 285 589 minecraft:black_concrete
fill 418 272 590 418 273 591 minecraft:purple_concrete
fill 418 272 599 418 273 599 minecraft:purple_concrete
fill 376 273 561 376 283 561 minecraft:black_concrete
fill 376 273 565 376 287 565 minecraft:black_concrete
setblock 376 273 566 minecraft:purple_concrete
setblock 376 273 577 minecraft:purple_concrete
setblock 376 273 581 minecraft:purple_concrete
fill 376 273 582 376 283 582 minecraft:black_concrete
setblock 376 273 598 minecraft:purple_concrete
setblock 378 273 599 minecraft:purple_concrete
fill 379 273 599 379 283 599 minecraft:black_concrete
setblock 386 273 599 minecraft:purple_concrete
fill 387 273 557 387 283 557 minecraft:black_concrete
setblock 388 273 557 minecraft:purple_concrete
fill 390 273 599 390 283 599 minecraft:black_concrete
fill 391 273 557 392 273 557 minecraft:purple_concrete
fill 406 273 599 407 273 599 minecraft:purple_concrete
fill 408 273 557 408 283 557 minecraft:black_concrete
setblock 410 273 578 minecraft:black_concrete
fill 410 273 581 410 273 582 minecraft:black_concrete
setblock 410 273 599 minecraft:purple_concrete
setblock 411 273 577 minecraft:black_concrete
fill 411 273 599 411 283 599 minecraft:black_concrete
setblock 412 273 557 minecraft:purple_concrete
fill 412 273 576 413 273 576 minecraft:black_concrete
setblock 414 273 577 minecraft:black_concrete
setblock 414 273 582 minecraft:black_concrete
fill 415 273 579 415 273 580 minecraft:black_concrete
fill 418 273 558 418 283 558 minecraft:black_concrete
setblock 418 273 559 minecraft:purple_concrete
setblock 418 273 562 minecraft:purple_concrete
fill 418 273 578 418 283 579 minecraft:black_concrete
setblock 418 273 583 minecraft:purple_concrete
setblock 418 273 594 minecraft:purple_concrete
fill 376 274 557 376 287 558 minecraft:black_concrete
fill 376 274 566 376 287 566 minecraft:black_concrete
fill 376 274 569 376 284 570 minecraft:black_concrete
fill 376 274 577 376 287 578 minecraft:black_concrete
fill 376 274 581 376 283 581 minecraft:black_concrete
fill 376 274 589 376 284 590 minecraft:black_concrete
fill 376 274 598 376 287 598 minecraft:black_concrete
fill 378 274 599 378 284 599 minecraft:black_concrete
fill 379 274 557 380 284 557 minecraft:black_concrete
fill 386 274 599 387 287 599 minecraft:black_concrete
fill 388 274 557 388 284 557 minecraft:black_concrete
fill 391 274 557 392 287 557 minecraft:black_concrete
fill 398 274 599 399 284 599 minecraft:black_concrete
fill 399 274 557 400 284 557 minecraft:black_concrete
fill 406 274 599 407 287 599 minecraft:black_concrete
fill 410 274 599 410 284 599 minecraft:black_concrete
fill 411 274 557 412 287 557 minecraft:black_concrete
fill 418 274 559 418 284 559 minecraft:black_concrete
fill 418 274 562 418 287 562 minecraft:black_concrete
fill 418 274 570 418 284 571 minecraft:black_concrete
fill 418 274 582 418 287 583 minecraft:black_concrete
fill 418 274 590 418 284 591 minecraft:black_concrete
fill 418 274 594 418 287 594 minecraft:black_concrete
fill 418 274 599 418 287 599 minecraft:black_concrete
setblock 379 277 560 minecraft:light[level=12]
setblock 379 277 568 minecraft:light[level=12]
setblock 379 277 576 minecraft:light[level=12]
setblock 379 277 584 minecraft:light[level=12]
setblock 379 277 592 minecraft:light[level=12]
setblock 387 277 560 minecraft:light[level=12]
setblock 387 277 568 minecraft:light[level=12]
setblock 387 277 576 minecraft:light[level=12]
setblock 387 277 584 minecraft:light[level=12]
setblock 387 277 592 minecraft:light[level=12]
setblock 395 277 560 minecraft:light[level=12]
setblock 395 277 568 minecraft:light[level=12]
setblock 395 277 576 minecraft:light[level=12]
setblock 395 277 584 minecraft:light[level=12]
setblock 395 277 592 minecraft:light[level=12]
setblock 403 277 560 minecraft:light[level=12]
setblock 403 277 568 minecraft:light[level=12]
setblock 403 277 576 minecraft:light[level=12]
setblock 403 277 584 minecraft:light[level=12]
setblock 403 277 592 minecraft:light[level=12]
setblock 411 277 560 minecraft:light[level=12]
setblock 411 277 568 minecraft:light[level=12]
setblock 411 277 576 minecraft:light[level=12]
setblock 411 277 584 minecraft:light[level=12]
setblock 411 277 592 minecraft:light[level=12]
fill 383 279 575 394 279 575 minecraft:black_concrete
fill 385 279 574 395 279 574 minecraft:black_concrete
fill 385 279 576 395 279 576 minecraft:black_concrete
fill 386 279 573 396 279 573 minecraft:black_concrete
fill 386 279 577 396 279 577 minecraft:black_concrete
fill 389 279 572 405 279 572 minecraft:black_concrete
fill 389 279 578 405 279 578 minecraft:black_concrete
fill 390 279 563 390 280 568 minecraft:black_concrete
fill 390 279 582 390 280 587 minecraft:black_concrete
fill 391 279 564 392 279 571 minecraft:black_concrete
fill 391 279 579 392 279 586 minecraft:black_concrete
fill 393 279 565 394 279 571 minecraft:black_concrete
fill 393 279 579 394 279 585 minecraft:black_concrete
fill 395 279 566 395 279 571 minecraft:black_concrete
fill 395 279 579 395 279 584 minecraft:black_concrete
fill 396 279 567 396 279 571 minecraft:black_concrete
fill 396 279 579 396 279 583 minecraft:black_concrete
fill 397 279 569 403 279 571 minecraft:black_concrete
fill 397 279 579 403 279 581 minecraft:black_concrete
fill 398 279 567 404 279 568 minecraft:black_concrete
fill 398 279 573 408 279 573 minecraft:black_concrete
fill 398 279 577 408 279 577 minecraft:black_concrete
fill 398 279 582 404 279 583 minecraft:black_concrete
fill 399 279 566 404 280 566 minecraft:black_concrete
fill 399 279 574 409 279 574 minecraft:black_concrete
fill 399 279 576 409 279 576 minecraft:black_concrete
fill 399 279 584 404 280 584 minecraft:black_concrete
fill 400 279 565 404 280 565 minecraft:black_concrete
fill 400 279 575 411 279 575 minecraft:black_concrete
fill 400 279 585 404 280 585 minecraft:black_concrete
fill 402 279 564 404 280 564 minecraft:black_concrete
fill 402 279 586 404 280 586 minecraft:black_concrete
fill 404 279 563 404 280 563 minecraft:black_concrete
fill 404 279 587 404 280 587 minecraft:black_concrete
fill 377 280 558 382 280 598 minecraft:obsidian
fill 383 280 558 384 280 574 minecraft:obsidian
fill 383 280 575 387 280 575 minecraft:black_concrete
fill 383 280 576 384 280 598 minecraft:obsidian
fill 385 280 558 385 280 573 minecraft:obsidian
fill 385 280 574 388 280 574 minecraft:black_concrete
fill 385 280 576 388 280 576 minecraft:black_concrete
fill 385 280 577 385 280 598 minecraft:obsidian
fill 386 280 558 388 280 572 minecraft:obsidian
fill 386 280 573 390 280 573 minecraft:black_concrete
fill 386 280 577 390 280 577 minecraft:black_concrete
fill 386 280 578 388 280 598 minecraft:obsidian
fill 388 280 575 392 280 575 minecraft:purple_concrete
fill 389 280 558 389 280 571 minecraft:obsidian
fill 389 280 572 392 280 572 minecraft:black_concrete
fill 389 280 574 393 280 574 minecraft:purple_concrete
fill 389 280 576 393 280 576 minecraft:purple_concrete
fill 389 280 578 392 280 578 minecraft:black_concrete
fill 389 280 579 389 280 598 minecraft:obsidian
fill 390 280 558 417 280 562 minecraft:obsidian
fill 390 280 569 390 280 571 minecraft:obsidian
fill 390 280 579 390 280 581 minecraft:obsidian
fill 390 280 588 417 280 598 minecraft:obsidian
fill 391 280 563 403 280 563 minecraft:obsidian
fill 391 280 564 391 280 571 minecraft:black_concrete
fill 391 280 573 393 280 573 minecraft:purple_concrete
fill 391 280 577 393 280 577 minecraft:purple_concrete
fill 391 280 579 391 280 586 minecraft:black_concrete
fill 391 280 587 403 280 587 minecraft:obsidian
fill 392 280 564 392 280 566 minecraft:black_concrete
fill 392 280 567 393 280 570 minecraft:purple_concrete
setblock 392 280 571 minecraft:black_concrete
setblock 392 280 579 minecraft:black_concrete
fill 392 280 580 393 280 583 minecraft:purple_concrete
fill 392 280 584 392 280 586 minecraft:black_concrete
fill 393 280 564 401 280 564 minecraft:obsidian
fill 393 280 565 394 280 566 minecraft:black_concrete
fill 393 280 571 394 280 572 minecraft:purple_concrete
setblock 393 280 575 minecraft:amethyst_block
fill 393 280 578 394 280 579 minecraft:purple_concrete
fill 393 280 584 394 280 585 minecraft:black_concrete
fill 393 280 586 401 280 586 minecraft:obsidian
fill 394 280 567 396 280 567 minecraft:black_concrete
fill 394 280 568 394 280 570 minecraft:purple_concrete
setblock 394 280 573 minecraft:amethyst_block
fill 394 280 574 394 280 576 minecraft:crying_obsidian
setblock 394 280 577 minecraft:amethyst_block
fill 394 280 580 394 280 582 minecraft:purple_concrete
fill 394 280 583 396 280 583 minecraft:black_concrete
fill 395 280 565 399 280 565 minecraft:obsidian
setblock 395 280 566 minecraft:black_concrete
fill 395 280 568 396 280 568 minecraft:black_concrete
fill 395 280 569 396 280 571 minecraft:purple_concrete
setblock 395 280 572 minecraft:amethyst_block
fill 395 280 573 395 280 574 minecraft:crying_obsidian
fill 395 280 576 395 280 577 minecraft:crying_obsidian
setblock 395 280 578 minecraft:amethyst_block
fill 395 280 579 396 280 581 minecraft:purple_concrete
fill 395 280 582 396 280 582 minecraft:black_concrete
setblock 395 280 584 minecraft:black_concrete
fill 395 280 585 399 280 585 minecraft:obsidian
fill 396 280 566 398 280 566 minecraft:obsidian
fill 396 280 572 396 280 573 minecraft:crying_obsidian
fill 396 280 577 396 280 578 minecraft:crying_obsidian
fill 396 280 584 398 280 584 minecraft:obsidian
fill 397 280 567 397 280 568 minecraft:obsidian
fill 397 280 569 397 280 570 minecraft:black_concrete
setblock 397 280 571 minecraft:amethyst_block
fill 397 280 572 398 280 572 minecraft:crying_obsidian
fill 397 280 578 398 280 578 minecraft:crying_obsidian
setblock 397 280 579 minecraft:amethyst_block
fill 397 280 580 397 280 581 minecraft:black_concrete
fill 397 280 582 397 280 583 minecraft:obsidian
fill 398 280 567 399 280 568 minecraft:black_concrete
fill 398 280 569 401 280 571 minecraft:purple_concrete
fill 398 280 573 399 280 573 minecraft:crying_obsidian
fill 398 280 577 399 280 577 minecraft:crying_obsidian
fill 398 280 579 401 280 581 minecraft:purple_concrete
fill 398 280 582 399 280 583 minecraft:black_concrete
setblock 399 280 572 minecraft:amethyst_block
fill 399 280 574 400 280 574 minecraft:crying_obsidian
fill 399 280 576 400 280 576 minecraft:crying_obsidian
setblock 399 280 578 minecraft:amethyst_block
setblock 400 280 567 minecraft:black_concrete
fill 400 280 568 402 280 568 minecraft:purple_concrete
fill 400 280 572 401 280 572 minecraft:purple_concrete
setblock 400 280 573 minecraft:amethyst_block
setblock 400 280 575 minecraft:crying_obsidian
setblock 400 280 577 minecraft:amethyst_block
fill 400 280 578 401 280 578 minecraft:purple_concrete
fill 400 280 582 402 280 582 minecraft:purple_concrete
setblock 400 280 583 minecraft:black_concrete
fill 401 280 567 402 280 567 minecraft:purple_concrete
fill 401 280 573 403 280 574 minecraft:purple_concrete
setblock 401 280 575 minecraft:amethyst_block
fill 401 280 576 403 280 577 minecraft:purple_concrete
fill 401 280 583 402 280 583 minecraft:purple_concrete
fill 402 280 569 402 280 570 minecraft:purple_concrete
fill 402 280 571 403 280 572 minecraft:black_concrete
fill 402 280 575 406 280 575 minecraft:purple_concrete
fill 402 280 578 403 280 579 minecraft:black_concrete
fill 402 280 580 402 280 581 minecraft:purple_concrete
fill 403 280 567 403 280 570 minecraft:black_concrete
fill 403 280 580 403 280 583 minecraft:black_concrete
fill 404 280 567 404 280 568 minecraft:black_concrete
fill 404 280 569 417 280 571 minecraft:obsidian
fill 404 280 572 405 280 573 minecraft:black_concrete
fill 404 280 574 405 280 574 minecraft:purple_concrete
fill 404 280 576 405 280 576 minecraft:purple_concrete
fill 404 280 577 405 280 578 minecraft:black_concrete
fill 404 280 579 417 280 581 minecraft:obsidian
fill 404 280 582 404 280 583 minecraft:black_concrete
fill 405 280 563 417 280 568 minecraft:obsidian
fill 405 280 582 417 280 587 minecraft:obsidian
fill 406 280 572 417 280 572 minecraft:obsidian
fill 406 280 573 408 280 574 minecraft:black_concrete
fill 406 280 576 408 280 577 minecraft:black_concrete
fill 406 280 578 417 280 578 minecraft:obsidian
fill 407 280 575 411 280 575 minecraft:black_concrete
fill 409 280 573 417 280 573 minecraft:obsidian
setblock 409 280 574 minecraft:black_concrete
setblock 409 280 576 minecraft:black_concrete
fill 409 280 577 417 280 577 minecraft:obsidian
fill 410 280 574 417 280 574 minecraft:obsidian
fill 410 280 576 417 280 576 minecraft:obsidian
fill 412 280 575 417 280 575 minecraft:obsidian
fill 376 284 561 376 285 562 minecraft:purple_concrete
fill 376 284 573 376 284 574 minecraft:purple_concrete
fill 376 284 581 376 285 582 minecraft:purple_concrete
setblock 376 284 585 minecraft:purple_concrete
fill 376 284 586 376 287 586 minecraft:black_concrete
fill 376 284 593 376 285 594 minecraft:purple_concrete
fill 379 284 599 379 285 599 minecraft:purple_concrete
fill 382 284 599 383 284 599 minecraft:purple_concrete
fill 383 284 557 383 287 557 minecraft:black_concrete
setblock 384 284 557 minecraft:purple_concrete
fill 387 284 557 387 285 557 minecraft:purple_concrete
fill 390 284 599 391 285 599 minecraft:purple_concrete
fill 395 284 557 396 284 557 minecraft:purple_concrete
fill 402 284 599 403 284 599 minecraft:purple_concrete
fill 407 284 557 408 285 557 minecraft:purple_concrete
fill 411 284 599 411 285 599 minecraft:purple_concrete
setblock 414 284 599 minecraft:purple_concrete
fill 415 284 557 416 284 557 minecraft:purple_concrete
fill 415 284 599 415 287 599 minecraft:black_concrete
fill 418 284 558 418 285 558 minecraft:purple_concrete
fill 418 284 566 418 285 567 minecraft:purple_concrete
fill 418 284 574 418 287 574 minecraft:black_concrete
setblock 418 284 575 minecraft:purple_concrete
fill 418 284 578 418 285 579 minecraft:purple_concrete
fill 418 284 586 418 284 587 minecraft:purple_concrete
fill 418 284 598 418 285 598 minecraft:purple_concrete
fill 376 285 569 376 285 570 minecraft:purple_concrete
setblock 376 285 573 minecraft:purple_concrete
fill 376 285 574 376 288 574 minecraft:black_concrete
fill 376 285 585 376 288 585 minecraft:black_concrete
fill 376 285 589 376 287 589 minecraft:black_concrete
setblock 376 285 590 minecraft:purple_concrete
setblock 378 285 599 minecraft:purple_concrete
setblock 379 285 557 minecraft:purple_concrete
setblock 379 285 560 minecraft:light[level=12]
setblock 379 285 568 minecraft:light[level=12]
setblock 379 285 576 minecraft:light[level=12]
setblock 379 285 584 minecraft:light[level=12]
setblock 379 285 592 minecraft:light[level=12]
fill 380 285 557 380 287 557 minecraft:black_concrete
fill 382 285 599 383 288 599 minecraft:black_concrete
fill 384 285 557 384 288 557 minecraft:black_concrete
setblock 387 285 560 minecraft:light[level=12]
setblock 387 285 568 minecraft:light[level=12]
setblock 387 285 576 minecraft:light[level=12]
setblock 387 285 584 minecraft:light[level=12]
setblock 387 285 592 minecraft:light[level=12]
setblock 388 285 557 minecraft:purple_concrete
fill 395 285 557 395 288 557 minecraft:black_concrete
setblock 395 285 560 minecraft:light[level=12]
setblock 395 285 568 minecraft:light[level=12]
setblock 395 285 576 minecraft:light[level=12]
setblock 395 285 584 minecraft:light[level=12]
setblock 395 285 592 minecraft:light[level=12]
setblock 396 285 557 minecraft:purple_concrete
fill 398 285 599 398 287 599 minecraft:black_concrete
setblock 399 285 557 minecraft:purple_concrete
setblock 399 285 599 minecraft:purple_concrete
fill 400 285 557 400 287 557 minecraft:black_concrete
setblock 402 285 599 minecraft:purple_concrete
setblock 403 285 560 minecraft:light[level=12]
setblock 403 285 568 minecraft:light[level=12]
setblock 403 285 576 minecraft:light[level=12]
setblock 403 285 584 minecraft:light[level=12]
setblock 403 285 592 minecraft:light[level=12]
fill 403 285 599 403 288 599 minecraft:black_concrete
setblock 410 285 599 minecraft:purple_concrete
setblock 411 285 560 minecraft:light[level=12]
setblock 411 285 568 minecraft:light[level=12]
setblock 411 285 576 minecraft:light[level=12]
setblock 411 285 584 minecraft:light[level=12]
setblock 411 285 592 minecraft:light[level=12]
fill 414 285 599 414 288 599 minecraft:black_concrete
fill 415 285 557 416 288 557 minecraft:black_concrete
setblock 418 285 559 minecraft:purple_concrete
setblock 418 285 570 minecraft:purple_concrete
fill 418 285 571 418 287 571 minecraft:black_concrete
fill 418 285 575 418 288 575 minecraft:black_concrete
fill 418 285 586 418 288 586 minecraft:black_concrete
setblock 418 285 587 minecraft:purple_concrete
fill 418 285 590 418 285 591 minecraft:purple_concrete
fill 376 286 559 376 287 560 minecraft:purple_concrete
fill 376 286 561 376 291 562 minecraft:black_concrete
setblock 376 286 567 minecraft:black_concrete
fill 376 286 568 376 287 568 minecraft:purple_concrete
fill 376 286 569 376 291 570 minecraft:black_concrete
setblock 376 286 571 minecraft:purple_concrete
fill 376 286 572 376 289 573 minecraft:black_concrete
fill 376 286 579 376 287 580 minecraft:purple_concrete
fill 376 286 581 376 291 582 minecraft:black_concrete
fill 376 286 590 376 291 590 minecraft:black_concrete
fill 376 286 591 376 286 592 minecraft:purple_concrete
fill 376 286 593 376 291 594 minecraft:black_concrete
fill 376 286 599 377 287 599 minecraft:purple_concrete
fill 377 286 557 378 286 557 minecraft:purple_concrete
fill 378 286 599 379 291 599 minecraft:black_concrete
fill 379 286 557 379 287 557 minecraft:black_concrete
setblock 380 286 599 minecraft:purple_concrete
fill 381 286 599 381 289 599 minecraft:black_concrete
fill 387 286 557 388 291 557 minecraft:black_concrete
fill 388 286 599 389 287 599 minecraft:purple_concrete
fill 389 286 557 390 287 557 minecraft:purple_concrete
fill 390 286 599 391 291 599 minecraft:black_concrete
fill 396 286 557 396 291 557 minecraft:black_concrete
setblock 396 286 599 minecraft:black_concrete
fill 397 286 557 398 286 557 minecraft:purple_concrete
fill 397 286 599 397 287 599 minecraft:purple_concrete
fill 399 286 557 399 291 557 minecraft:black_concrete
fill 399 286 599 399 291 599 minecraft:black_concrete
fill 400 286 599 401 286 599 minecraft:purple_concrete
fill 401 286 557 401 287 557 minecraft:purple_concrete
setblock 402 286 557 minecraft:black_concrete
fill 402 286 599 402 291 599 minecraft:black_concrete
fill 407 286 557 408 291 557 minecraft:black_concrete
fill 408 286 599 409 287 599 minecraft:purple_concrete
fill 409 286 557 410 287 557 minecraft:purple_concrete
fill 410 286 599 411 291 599 minecraft:black_concrete
fill 417 286 557 417 289 557 minecraft:black_concrete
setblock 418 286 557 minecraft:purple_concrete
fill 418 286 558 418 291 559 minecraft:black_concrete
fill 418 286 560 418 287 561 minecraft:purple_concrete
fill 418 286 566 418 291 567 minecraft:black_concrete
fill 418 286 568 418 286 569 minecraft:purple_concrete
fill 418 286 570 418 291 570 minecraft:black_concrete
fill 418 286 578 418 291 579 minecraft:black_concrete
fill 418 286 580 418 287 581 minecraft:purple_concrete
fill 418 286 587 418 289 588 minecraft:black_concrete
setblock 418 286 589 minecraft:purple_concrete
fill 418 286 590 418 291 591 minecraft:black_concrete
fill 418 286 592 418 287 592 minecraft:purple_concrete
setblock 418 286 593 minecraft:black_concrete
fill 418 286 598 418 291 598 minecraft:black_concrete
setblock 376 287 567 minecraft:purple_concrete
fill 376 287 571 376 290 571 minecraft:black_concrete
fill 376 287 587 376 287 588 minecraft:purple_concrete
setblock 376 287 591 minecraft:purple_concrete
fill 376 287 592 376 290 592 minecraft:black_concrete
fill 377 287 557 377 290 557 minecraft:black_concrete
setblock 378 287 557 minecraft:purple_concrete
fill 380 287 599 380 290 599 minecraft:black_concrete
fill 381 287 557 382 287 557 minecraft:purple_concrete
fill 384 287 599 384 289 599 minecraft:black_concrete
setblock 385 287 599 minecraft:purple_concrete
setblock 396 287 599 minecraft:purple_concrete
fill 397 287 557 398 290 557 minecraft:black_concrete
fill 400 287 599 401 290 599 minecraft:black_concrete
setblock 402 287 557 minecraft:purple_concrete
setblock 413 287 557 minecraft:purple_concrete
fill 414 287 557 414 289 557 minecraft:black_concrete
fill 416 287 599 416 289 599 minecraft:black_concrete
setblock 417 287 599 minecraft:purple_concrete
fill 418 287 557 418 290 557 minecraft:black_concrete
fill 418 287 568 418 290 568 minecraft:black_concrete
setblock 418 287 569 minecraft:purple_concrete
fill 418 287 572 418 287 573 minecraft:purple_concrete
fill 418 287 589 418 290 589 minecraft:black_concrete
setblock 418 287 593 minecraft:purple_concrete
fill 376 288 557 376 288 558 minecraft:purple_concrete
fill 376 288 559 376 290 560 minecraft:black_concrete
fill 376 288 565 376 289 566 minecraft:purple_concrete
fill 376 288 567 376 293 568 minecraft:black_concrete
fill 376 288 577 376 288 578 minecraft:purple_concrete
fill 376 288 579 376 293 580 minecraft:black_concrete
fill 376 288 586 376 289 586 minecraft:purple_concrete
fill 376 288 587 376 293 588 minecraft:black_concrete
setblock 376 288 589 minecraft:purple_concrete
fill 376 288 591 376 293 591 minecraft:black_concrete
fill 376 288 597 376 289 598 minecraft:purple_concrete
fill 376 288 599 377 293 599 minecraft:black_concrete
fill 377 288 558 379 288 558 minecraft:obsidian
fill 377 288 560 377 288 562 minecraft:obsidian
fill 377 288 564 377 288 566 minecraft:obsidian
fill 377 288 568 377 288 570 minecraft:obsidian
fill 377 288 572 377 288 574 minecraft:obsidian
fill 377 288 576 377 288 578 minecraft:obsidian
fill 377 288 580 377 288 582 minecraft:obsidian
fill 377 288 584 377 288 586 minecraft:obsidian
fill 377 288 588 377 288 590 minecraft:obsidian
fill 377 288 592 377 288 594 minecraft:obsidian
fill 377 288 596 377 288 598 minecraft:obsidian
fill 378 288 557 378 293 557 minecraft:black_concrete
fill 379 288 557 380 288 557 minecraft:purple_concrete
fill 379 288 598 381 288 598 minecraft:obsidian
fill 381 288 557 382 289 557 minecraft:black_concrete
fill 381 288 558 383 288 558 minecraft:obsidian
fill 383 288 557 383 289 557 minecraft:purple_concrete
fill 383 288 598 385 288 598 minecraft:obsidian
fill 385 288 558 387 288 558 minecraft:obsidian
fill 385 288 599 385 293 599 minecraft:black_concrete
fill 386 288 599 387 288 599 minecraft:purple_concrete
fill 387 288 598 389 288 598 minecraft:obsidian
fill 388 288 599 389 293 599 minecraft:black_concrete
fill 389 288 557 390 293 557 minecraft:black_concrete
fill 389 288 558 391 288 558 minecraft:obsidian
fill 391 288 557 392 289 557 minecraft:purple_concrete
fill 391 288 598 393 288 598 minecraft:obsidian
fill 393 288 558 395 288 558 minecraft:obsidian
fill 394 288 599 395 289 599 minecraft:purple_concrete
fill 395 288 598 397 288 598 minecraft:obsidian
fill 396 288 599 397 293 599 minecraft:black_concrete
fill 397 288 558 399 288 558 minecraft:obsidian
setblock 398 288 599 minecraft:purple_concrete
fill 399 288 598 401 288 598 minecraft:obsidian
setblock 400 288 557 minecraft:purple_concrete
fill 401 288 557 402 293 557 minecraft:black_concrete
fill 401 288 558 403 288 558 minecraft:obsidian
fill 403 288 557 404 289 557 minecraft:purple_concrete
fill 403 288 598 405 288 598 minecraft:obsidian
fill 405 288 558 407 288 558 minecraft:obsidian
fill 406 288 599 407 289 599 minecraft:purple_concrete
fill 407 288 598 409 288 598 minecraft:obsidian
fill 408 288 599 409 293 599 minecraft:black_concrete
fill 409 288 557 410 293 557 minecraft:black_concrete
fill 409 288 558 411 288 558 minecraft:obsidian
fill 411 288 557 412 288 557 minecraft:purple_concrete
fill 411 288 598 413 288 598 minecraft:obsidian
fill 413 288 557 413 293 557 minecraft:black_concrete
fill 413 288 558 415 288 558 minecraft:obsidian
fill 415 288 598 417 288 598 minecraft:obsidian
fill 415 288 599 415 289 599 minecraft:purple_concrete
fill 417 288 558 417 288 560 minecraft:obsidian
fill 417 288 562 417 288 564 minecraft:obsidian
fill 417 288 566 417 288 568 minecraft:obsidian
fill 417 288 570 417 288 572 minecraft:obsidian
fill 417 288 574 417 288 576 minecraft:obsidian
fill 417 288 578 417 288 580 minecraft:obsidian
fill 417 288 582 417 288 584 minecraft:obsidian
fill 417 288 586 417 288 588 minecraft:obsidian
fill 417 288 590 417 288 592 minecraft:obsidian
fill 417 288 594 417 288 596 minecraft:obsidian
fill 417 288 599 417 293 599 minecraft:black_concrete
fill 418 288 560 418 293 561 minecraft:black_concrete
fill 418 288 562 418 289 563 minecraft:purple_concrete
fill 418 288 569 418 293 569 minecraft:black_concrete
setblock 418 288 571 minecraft:purple_concrete
fill 418 288 572 418 293 573 minecraft:black_concrete
fill 418 288 574 418 289 574 minecraft:purple_concrete
fill 418 288 580 418 293 581 minecraft:black_concrete
fill 418 288 582 418 288 583 minecraft:purple_concrete
fill 418 288 592 418 293 593 minecraft:black_concrete
fill 418 288 594 418 289 595 minecraft:purple_concrete
setblock 418 288 599 minecraft:purple_concrete
setblock 376 289 557 minecraft:purple_concrete
fill 376 289 558 376 292 558 minecraft:black_concrete
setblock 376 289 574 minecraft:purple_concrete
setblock 376 289 577 minecraft:purple_concrete
fill 376 289 578 376 292 578 minecraft:black_concrete
setblock 376 289 585 minecraft:purple_concrete
fill 376 289 589 376 292 589 minecraft:black_concrete
fill 379 289 557 380 291 557 minecraft:black_concrete
fill 382 289 599 383 289 599 minecraft:purple_concrete
setblock 384 289 557 minecraft:purple_concrete
setblock 386 289 599 minecraft:purple_concrete
fill 387 289 599 387 292 599 minecraft:black_concrete
setblock 395 289 557 minecraft:purple_concrete
fill 398 289 599 398 292 599 minecraft:black_concrete
fill 400 289 557 400 292 557 minecraft:black_concrete
setblock 403 289 599 minecraft:purple_concrete
fill 411 289 557 411 292 557 minecraft:black_concrete
setblock 412 289 557 minecraft:purple_concrete
setblock 414 289 599 minecraft:purple_concrete
fill 415 289 557 416 289 557 minecraft:purple_concrete
fill 418 289 571 418 292 571 minecraft:black_concrete
setblock 418 289 575 minecraft:purple_concrete
fill 418 289 582 418 292 582 minecraft:black_concrete
setblock 418 289 583 minecraft:purple_concrete
setblock 418 289 586 minecraft:purple_concrete
fill 418 289 599 418 292 599 minecraft:black_concrete
fill 376 290 557 376 292 557 minecraft:black_concrete
fill 376 290 563 376 291 564 minecraft:purple_concrete
fill 376 290 565 376 295 566 minecraft:black_concrete
fill 376 290 572 376 291 572 minecraft:purple_concrete
fill 376 290 573 376 291 574 minecraft:black_concrete
fill 376 290 575 376 290 576 minecraft:purple_concrete
fill 376 290 577 376 295 577 minecraft:black_concrete
fill 376 290 583 376 291 584 minecraft:purple_concrete
fill 376 290 585 376 295 586 minecraft:black_concrete
fill 376 290 595 376 290 596 minecraft:purple_concrete
fill 376 290 597 376 295 598 minecraft:black_concrete
fill 381 290 557 381 293 557 minecraft:black_concrete
fill 381 290 599 381 291 599 minecraft:purple_concrete
setblock 382 290 557 minecraft:purple_concrete
fill 382 290 599 383 295 599 minecraft:black_concrete
fill 383 290 557 384 295 557 minecraft:black_concrete
setblock 384 290 599 minecraft:purple_concrete
fill 385 290 557 386 291 557 minecraft:purple_concrete
fill 386 290 599 386 295 599 minecraft:black_concrete
fill 391 290 557 392 292 557 minecraft:black_concrete
fill 392 290 599 393 291 599 minecraft:purple_concrete
fill 393 290 557 394 290 557 minecraft:purple_concrete
fill 394 290 599 395 295 599 minecraft:black_concrete
fill 395 290 557 395 295 557 minecraft:black_concrete
fill 403 290 557 404 295 557 minecraft:black_concrete
fill 403 290 599 403 295 599 minecraft:black_concrete
fill 404 290 599 405 290 599 minecraft:purple_concrete
fill 405 290 557 406 291 557 minecraft:purple_concrete
fill 406 290 599 407 295 599 minecraft:black_concrete
fill 412 290 557 412 295 557 minecraft:black_concrete
fill 412 290 599 413 291 599 minecraft:purple_concrete
setblock 414 290 557 minecraft:purple_concrete
fill 414 290 599 415 295 599 minecraft:black_concrete
fill 415 290 557 416 295 557 minecraft:black_concrete
setblock 416 290 599 minecraft:purple_concrete
fill 417 290 557 417 291 557 minecraft:purple_concrete
fill 418 290 562 418 295 563 minecraft:black_concrete
fill 418 290 564 418 290 565 minecraft:purple_concrete
fill 418 290 574 418 295 575 minecraft:black_concrete
fill 418 290 576 418 291 577 minecraft:purple_concrete
fill 418 290 583 418 295 583 minecraft:black_concrete
fill 418 290 584 418 290 585 minecraft:purple_concrete
fill 418 290 586 418 291 587 minecraft:black_concrete
fill 418 290 588 418 291 588 minecraft:purple_concrete
fill 418 290 594 418 295 595 minecraft:black_concrete
fill 418 290 596 418 291 597 minecraft:purple_concrete
fill 376 291 559 376 293 559 minecraft:black_concrete
setblock 376 291 560 minecraft:purple_concrete
setblock 376 291 571 minecraft:purple_concrete
fill 376 291 575 376 294 576 minecraft:black_concrete
setblock 376 291 592 minecraft:purple_concrete
setblock 376 291 595 minecraft:purple_concrete
fill 376 291 596 376 294 596 minecraft:black_concrete
setblock 377 291 557 minecraft:purple_concrete
setblock 380 291 599 minecraft:purple_concrete
fill 382 291 557 382 293 557 minecraft:black_concrete
fill 384 291 599 384 294 599 minecraft:black_concrete
fill 393 291 557 393 294 557 minecraft:black_concrete
setblock 394 291 557 minecraft:purple_concrete
fill 397 291 557 398 291 557 minecraft:purple_concrete
fill 400 291 599 401 291 599 minecraft:purple_concrete
setblock 404 291 599 minecraft:purple_concrete
fill 405 291 599 405 294 599 minecraft:black_concrete
fill 414 291 557 414 294 557 minecraft:black_concrete
fill 416 291 599 416 294 599 minecraft:black_concrete
setblock 418 291 557 minecraft:purple_concrete
fill 418 291 564 418 294 564 minecraft:black_concrete
setblock 418 291 565 minecraft:purple_concrete
setblock 418 291 568 minecraft:purple_concrete
fill 418 291 584 418 294 585 minecraft:black_concrete
setblock 418 291 589 minecraft:purple_concrete
fill 376 292 560 376 297 560 minecraft:black_concrete
fill 376 292 561 376 292 562 minecraft:purple_concrete
fill 376 292 563 376 297 564 minecraft:black_concrete
fill 376 292 569 376 293 570 minecraft:purple_concrete
fill 376 292 571 376 297 572 minecraft:black_concrete
setblock 376 292 573 minecraft:purple_concrete
fill 376 292 574 376 295 574 minecraft:black_concrete
fill 376 292 581 376 293 582 minecraft:purple_concrete
fill 376 292 583 376 297 584 minecraft:black_concrete
fill 376 292 590 376 293 590 minecraft:purple_concrete
fill 376 292 592 376 297 592 minecraft:black_concrete
fill 376 292 593 376 292 594 minecraft:purple_concrete
fill 376 292 595 376 297 595 minecraft:black_concrete
fill 377 292 557 377 297 557 minecraft:black_concrete
fill 378 292 599 379 293 599 minecraft:purple_concrete
fill 379 292 557 379 293 557 minecraft:purple_concrete
setblock 380 292 557 minecraft:black_concrete
fill 380 292 599 381 297 599 minecraft:black_concrete
fill 385 292 557 386 297 557 minecraft:black_concrete
fill 387 292 557 388 293 557 minecraft:purple_concrete
fill 390 292 599 391 292 599 minecraft:purple_concrete
fill 392 292 599 393 297 599 minecraft:black_concrete
fill 394 292 557 394 294 557 minecraft:black_concrete
setblock 396 292 557 minecraft:purple_concrete
fill 397 292 557 398 297 557 minecraft:black_concrete
fill 399 292 557 399 293 557 minecraft:purple_concrete
fill 399 292 599 399 293 599 minecraft:purple_concrete
fill 400 292 599 401 297 599 minecraft:black_concrete
setblock 402 292 599 minecraft:purple_concrete
fill 404 292 599 404 297 599 minecraft:black_concrete
fill 405 292 557 406 297 557 minecraft:black_concrete
fill 407 292 557 408 292 557 minecraft:purple_concrete
fill 410 292 599 411 293 599 minecraft:purple_concrete
fill 412 292 599 413 297 599 minecraft:black_concrete
fill 417 292 557 418 297 557 minecraft:black_concrete
fill 418 292 558 418 293 559 minecraft:purple_concrete
fill 418 292 565 418 297 565 minecraft:black_concrete
fill 418 292 566 418 292 567 minecraft:purple_concrete
fill 418 292 568 418 297 568 minecraft:black_concrete
fill 418 292 570 418 293 570 minecraft:purple_concrete
fill 418 292 576 418 297 577 minecraft:black_concrete
fill 418 292 578 418 293 579 minecraft:purple_concrete
fill 418 292 586 418 295 586 minecraft:black_concrete
setblock 418 292 587 minecraft:purple_concrete
fill 418 292 588 418 297 589 minecraft:black_concrete
fill 418 292 590 418 293 591 minecraft:purple_concrete
fill 418 292 596 418 297 597 minecraft:black_concrete
setblock 418 292 598 minecraft:purple_concrete
fill 376 293 557 376 293 558 minecraft:purple_concrete
setblock 376 293 561 minecraft:purple_concrete
fill 376 293 562 376 296 562 minecraft:black_concrete
fill 376 293 573 376 296 573 minecraft:black_concrete
setblock 376 293 578 minecraft:purple_concrete
setblock 376 293 589 minecraft:purple_concrete
fill 376 293 593 376 296 594 minecraft:black_concrete
setblock 379 293 560 minecraft:light[level=12]
setblock 379 293 568 minecraft:light[level=12]
setblock 379 293 576 minecraft:light[level=12]
setblock 379 293 584 minecraft:light[level=12]
setblock 379 293 592 minecraft:light[level=12]
setblock 380 293 557 minecraft:purple_concrete
setblock 387 293 560 minecraft:light[level=12]
setblock 387 293 568 minecraft:light[level=12]
setblock 387 293 576 minecraft:light[level=12]
setblock 387 293 584 minecraft:light[level=12]
setblock 387 293 592 minecraft:light[level=12]
setblock 387 293 599 minecraft:purple_concrete
setblock 390 293 599 minecraft:purple_concrete
setblock 391 293 557 minecraft:purple_concrete
fill 391 293 599 391 296 599 minecraft:black_concrete
fill 392 293 557 392 295 557 minecraft:black_concrete
setblock 395 293 560 minecraft:light[level=12]
setblock 395 293 568 minecraft:light[level=12]
setblock 395 293 576 minecraft:light[level=12]
setblock 395 293 584 minecraft:light[level=12]
setblock 395 293 592 minecraft:light[level=12]
fill 396 293 557 396 296 557 minecraft:black_concrete
setblock 398 293 599 minecraft:purple_concrete
setblock 400 293 557 minecraft:purple_concrete
fill 402 293 599 402 296 599 minecraft:black_concrete
setblock 403 293 560 minecraft:light[level=12]
setblock 403 293 568 minecraft:light[level=12]
setblock 403 293 576 minecraft:light[level=12]
setblock 403 293 584 minecraft:light[level=12]
setblock 403 293 592 minecraft:light[level=12]
fill 407 293 557 407 296 557 minecraft:black_concrete
setblock 408 293 557 minecraft:purple_concrete
setblock 411 293 557 minecraft:purple_concrete
setblock 411 293 560 minecraft:light[level=12]
setblock 411 293 568 minecraft:light[level=12]
setblock 411 293 576 minecraft:light[level=12]
setblock 411 293 584 minecraft:light[level=12]
setblock 411 293 592 minecraft:light[level=12]
fill 418 293 566 418 296 567 minecraft:black_concrete
setblock 418 293 571 minecraft:purple_concrete
setblock 418 293 582 minecraft:purple_concrete
fill 418 293 587 418 296 587 minecraft:black_concrete
fill 418 293 598 418 296 598 minecraft:black_concrete
setblock 418 293 599 minecraft:purple_concrete
fill 376 294 557 376 299 558 minecraft:black_concrete
setblock 376 294 559 minecraft:purple_concrete
fill 376 294 561 376 299 561 minecraft:black_concrete
fill 376 294 567 376 295 568 minecraft:purple_concrete
fill 376 294 569 376 299 570 minecraft:black_concrete
fill 376 294 578 376 299 578 minecraft:black_concrete
fill 376 294 579 376 294 580 minecraft:purple_concrete
fill 376 294 581 376 299 582 minecraft:black_concrete
fill 376 294 587 376 295 588 minecraft:purple_concrete
fill 376 294 589 376 299 590 minecraft:black_concrete
setblock 376 294 591 minecraft:purple_concrete
fill 376 294 599 377 295 599 minecraft:purple_concrete
fill 377 294 558 379 294 558 minecraft:obsidian
fill 377 294 560 377 294 562 minecraft:obsidian
fill 377 294 564 377 294 566 minecraft:obsidian
fill 377 294 568 377 294 570 minecraft:obsidian
fill 377 294 572 377 294 574 minecraft:obsidian
fill 377 294 576 377 294 578 minecraft:obsidian
fill 377 294 580 377 294 582 minecraft:obsidian
fill 377 294 584 377 294 586 minecraft:obsidian
fill 377 294 588 377 294 590 minecraft:obsidian
fill 377 294 592 377 294 594 minecraft:obsidian
fill 377 294 596 377 294 598 minecraft:obsidian
setblock 378 294 557 minecraft:purple_concrete
fill 378 294 599 379 299 599 minecraft:black_concrete
fill 379 294 557 380 299 557 minecraft:black_concrete
fill 379 294 598 381 294 598 minecraft:obsidian
fill 381 294 557 382 295 557 minecraft:purple_concrete
fill 381 294 558 383 294 558 minecraft:obsidian
fill 383 294 598 385 294 598 minecraft:obsidian
fill 385 294 558 387 294 558 minecraft:obsidian
fill 385 294 599 385 295 599 minecraft:purple_concrete
fill 387 294 557 388 299 557 minecraft:black_concrete
fill 387 294 598 389 294 598 minecraft:obsidian
fill 387 294 599 387 299 599 minecraft:black_concrete
fill 388 294 599 389 294 599 minecraft:purple_concrete
fill 389 294 557 390 294 557 minecraft:purple_concrete
fill 389 294 558 391 294 558 minecraft:obsidian
fill 390 294 599 390 299 599 minecraft:black_concrete
fill 391 294 557 391 295 557 minecraft:black_concrete
fill 391 294 598 393 294 598 minecraft:obsidian
fill 393 294 558 395 294 558 minecraft:obsidian
fill 395 294 598 397 294 598 minecraft:obsidian
fill 396 294 599 397 295 599 minecraft:purple_concrete
fill 397 294 558 399 294 558 minecraft:obsidian
fill 398 294 599 399 299 599 minecraft:black_concrete
fill 399 294 557 400 299 557 minecraft:black_concrete
fill 399 294 598 401 294 598 minecraft:obsidian
fill 401 294 557 402 295 557 minecraft:purple_concrete
fill 401 294 558 403 294 558 minecraft:obsidian
fill 403 294 598 405 294 598 minecraft:obsidian
fill 405 294 558 407 294 558 minecraft:obsidian
fill 407 294 598 409 294 598 minecraft:obsidian
fill 408 294 557 408 299 557 minecraft:black_concrete
fill 408 294 599 409 294 599 minecraft:purple_concrete
fill 409 294 557 410 294 557 minecraft:purple_concrete
fill 409 294 558 411 294 558 minecraft:obsidian
fill 410 294 599 411 299 599 minecraft:black_concrete
fill 411 294 557 411 299 557 minecraft:black_concrete
fill 411 294 598 413 294 598 minecraft:obsidian
fill 413 294 557 413 295 557 minecraft:purple_concrete
fill 413 294 558 415 294 558 minecraft:obsidian
fill 415 294 598 417 294 598 minecraft:obsidian
fill 417 294 558 417 294 560 minecraft:obsidian
fill 417 294 562 417 294 564 minecraft:obsidian
fill 417 294 566 417 294 568 minecraft:obsidian
fill 417 294 570 417 294 572 minecraft:obsidian
fill 417 294 574 417 294 576 minecraft:obsidian
fill 417 294 578 417 294 580 minecraft:obsidian
fill 417 294 582 417 294 584 minecraft:obsidian
fill 417 294 586 417 294 588 minecraft:obsidian
fill 417 294 590 417 294 592 minecraft:obsidian
fill 417 294 594 417 294 596 minecraft:obsidian
fill 417 294 599 417 295 599 minecraft:purple_concrete
fill 418 294 558 418 299 559 minecraft:black_concrete
fill 418 294 560 418 295 561 minecraft:purple_concrete
setblock 418 294 569 minecraft:purple_concrete
fill 418 294 570 418 299 571 minecraft:black_concrete
fill 418 294 572 418 295 573 minecraft:purple_concrete
fill 418 294 578 418 299 579 minecraft:black_concrete
fill 418 294 580 418 294 581 minecraft:purple_concrete
fill 418 294 582 418 299 582 minecraft:black_concrete
fill 418 294 590 418 299 591 minecraft:black_concrete
fill 418 294 592 418 295 593 minecraft:purple_concrete
fill 418 294 599 418 299 599 minecraft:black_concrete
fill 376 295 559 376 298 559 minecraft:black_concrete
fill 376 295 575 376 295 576 minecraft:purple_concrete
setblock 376 295 579 minecraft:purple_concrete
fill 376 295 580 376 298 580 minecraft:black_concrete
fill 376 295 591 376 298 591 minecraft:black_concrete
setblock 376 295 596 minecraft:purple_concrete
fill 378 295 557 378 298 557 minecraft:black_concrete
setblock 384 295 599 minecraft:purple_concrete
fill 388 295 599 389 298 599 minecraft:black_concrete
fill 389 295 557 389 298 557 minecraft:black_concrete
setblock 390 295 557 minecraft:purple_concrete
fill 393 295 557 394 295 557 minecraft:purple_concrete
setblock 405 295 599 minecraft:purple_concrete
setblock 408 295 599 minecraft:purple_concrete
fill 409 295 557 410 298 557 minecraft:black_concrete
fill 409 295 599 409 298 599 minecraft:black_concrete
setblock 414 295 557 minecraft:purple_concrete
setblock 416 295 599 minecraft:purple_concrete
setblock 418 295 564 minecraft:purple_concrete
fill 418 295 569 418 298 569 minecraft:black_concrete
fill 418 295 580 418 298 580 minecraft:black_concrete
setblock 418 295 581 minecraft:purple_concrete
fill 418 295 584 418 295 585 minecraft:purple_concrete
fill 376 296 565 376 296 566 minecraft:purple_concrete
fill 376 296 567 376 307 568 minecraft:black_concrete
fill 376 296 574 376 297 574 minecraft:purple_concrete
fill 376 296 575 376 307 576 minecraft:black_concrete
setblock 376 296 577 minecraft:purple_concrete
fill 376 296 579 376 307 579 minecraft:black_concrete
fill 376 296 585 376 297 586 minecraft:purple_concrete
fill 376 296 587 376 307 588 minecraft:black_concrete
fill 376 296 596 376 307 596 minecraft:black_concrete
fill 376 296 597 376 296 598 minecraft:purple_concrete
fill 376 296 599 377 307 599 minecraft:black_concrete
fill 381 296 557 382 307 557 minecraft:black_concrete
fill 382 296 599 383 297 599 minecraft:purple_concrete
fill 383 296 557 384 297 557 minecraft:purple_concrete
fill 384 296 599 385 307 599 minecraft:black_concrete
setblock 386 296 599 minecraft:purple_concrete
fill 390 296 557 390 307 557 minecraft:black_concrete
fill 391 296 557 392 296 557 minecraft:purple_concrete
fill 393 296 557 394 297 557 minecraft:black_concrete
fill 394 296 599 395 297 599 minecraft:purple_concrete
fill 395 296 557 395 297 557 minecraft:purple_concrete
fill 396 296 599 397 307 599 minecraft:black_concrete
fill 401 296 557 402 307 557 minecraft:black_concrete
fill 403 296 557 404 297 557 minecraft:purple_concrete
fill 403 296 599 403 297 599 minecraft:purple_concrete
fill 405 296 599 405 307 599 minecraft:black_concrete
fill 406 296 599 407 296 599 minecraft:purple_concrete
fill 408 296 599 408 307 599 minecraft:black_concrete
setblock 412 296 557 minecraft:purple_concrete
fill 413 296 557 414 307 557 minecraft:black_concrete
fill 414 296 599 415 297 599 minecraft:purple_concrete
fill 415 296 557 416 297 557 minecraft:purple_concrete
fill 416 296 599 417 307 599 minecraft:black_concrete
fill 418 296 560 418 307 561 minecraft:black_concrete
fill 418 296 562 418 296 563 minecraft:purple_concrete
fill 418 296 564 418 307 564 minecraft:black_concrete
fill 418 296 572 418 307 573 minecraft:black_concrete
fill 418 296 574 418 297 575 minecraft:purple_concrete
fill 418 296 581 418 307 581 minecraft:black_concrete
setblock 418 296 583 minecraft:purple_concrete
fill 418 296 584 418 307 585 minecraft:black_concrete
fill 418 296 586 418 297 586 minecraft:purple_concrete
fill 418 296 592 418 307 593 minecraft:black_concrete
fill 418 296 594 418 296 595 minecraft:purple_concrete
setblock 376 297 562 minecraft:purple_concrete
setblock 376 297 565 minecraft:purple_concrete
fill 376 297 566 376 307 566 minecraft:black_concrete
setblock 376 297 573 minecraft:purple_concrete
fill 376 297 577 376 307 577 minecraft:black_concrete
fill 376 297 593 376 297 594 minecraft:purple_concrete
setblock 376 297 597 minecraft:purple_concrete
fill 376 297 598 376 307 598 minecraft:black_concrete
fill 386 297 599 386 307 599 minecraft:black_concrete
fill 391 297 557 392 299 557 minecraft:black_concrete
setblock 391 297 599 minecraft:purple_concrete
setblock 396 297 557 minecraft:purple_concrete
setblock 402 297 599 minecraft:purple_concrete
fill 406 297 599 407 307 599 minecraft:black_concrete
setblock 407 297 557 minecraft:purple_concrete
fill 412 297 557 412 307 557 minecraft:black_concrete
fill 418 297 562 418 307 562 minecraft:black_concrete
setblock 418 297 563 minecraft:purple_concrete
fill 418 297 566 418 297 567 minecraft:purple_concrete
fill 418 297 583 418 307 583 minecraft:black_concrete
setblock 418 297 587 minecraft:purple_concrete
fill 418 297 594 418 307 594 minecraft:black_concrete
setblock 418 297 595 minecraft:purple_concrete
setblock 418 297 598 minecraft:purple_concrete
fill 376 298 560 376 299 560 minecraft:purple_concrete
fill 376 298 562 376 307 562 minecraft:black_concrete
fill 376 298 563 376 298 564 minecraft:purple_concrete
fill 376 298 565 376 307 565 minecraft:black_concrete
fill 376 298 571 376 299 572 minecraft:purple_concrete
fill 376 298 573 376 307 574 minecraft:black_concrete
fill 376 298 583 376 298 584 minecraft:purple_concrete
fill 376 298 585 376 307 586 minecraft:black_concrete
fill 376 298 592 376 299 592 minecraft:purple_concrete
fill 376 298 593 376 307 594 minecraft:black_concrete
setblock 376 298 595 minecraft:purple_concrete
fill 376 298 597 376 307 597 minecraft:black_concrete
fill 377 298 557 377 299 557 minecraft:purple_concrete
fill 380 298 599 381 299 599 minecraft:purple_concrete
fill 382 298 599 383 307 599 minecraft:black_concrete
fill 383 298 557 384 307 557 minecraft:black_concrete
fill 385 298 557 386 299 557 minecraft:purple_concrete
fill 391 298 599 391 307 599 minecraft:black_concrete
fill 392 298 599 393 298 599 minecraft:purple_concrete
fill 393 298 557 393 307 557 minecraft:black_concrete
setblock 394 298 557 minecraft:purple_concrete
fill 394 298 599 395 307 599 minecraft:black_concrete
fill 395 298 557 396 307 557 minecraft:black_concrete
fill 397 298 557 398 299 557 minecraft:purple_concrete
fill 400 298 599 401 299 599 minecraft:purple_concrete
fill 402 298 599 403 307 599 minecraft:black_concrete
fill 403 298 557 404 307 557 minecraft:black_concrete
setblock 404 298 599 minecraft:purple_concrete
fill 405 298 557 406 298 557 minecraft:purple_concrete
fill 407 298 557 407 307 557 minecraft:black_concrete
fill 412 298 599 413 299 599 minecraft:purple_concrete
fill 414 298 599 415 307 599 minecraft:black_concrete
fill 415 298 557 416 307 557 minecraft:black_concrete
fill 417 298 557 418 299 557 minecraft:purple_concrete
fill 418 298 563 418 307 563 minecraft:black_concrete
setblock 418 298 565 minecraft:purple_concrete
fill 418 298 566 418 307 567 minecraft:black_concrete
fill 418 298 568 418 299 568 minecraft:purple_concrete
fill 418 298 574 418 307 575 minecraft:black_concrete
fill 418 298 576 418 298 577 minecraft:purple_concrete
fill 418 298 586 418 307 587 minecraft:black_concrete
fill 418 298 588 418 299 589 minecraft:purple_concrete
fill 418 298 595 418 307 595 minecraft:black_concrete
fill 418 298 596 418 298 597 minecraft:purple_concrete
fill 418 298 598 418 307 598 minecraft:black_concrete
setblock 376 299 559 minecraft:purple_concrete
fill 376 299 563 376 307 564 minecraft:black_concrete
setblock 376 299 580 minecraft:purple_concrete
setblock 376 299 583 minecraft:purple_concrete
fill 376 299 584 376 307 584 minecraft:black_concrete
setblock 376 299 591 minecraft:purple_concrete
fill 376 299 595 376 307 595 minecraft:black_concrete
setblock 378 299 557 minecraft:purple_concrete
fill 388 299 599 389 299 599 minecraft:purple_concrete
setblock 389 299 557 minecraft:purple_concrete
setblock 392 299 599 minecraft:purple_concrete
fill 393 299 599 393 307 599 minecraft:black_concrete
fill 394 299 557 394 307 557 minecraft:black_concrete
fill 404 299 599 404 307 599 minecraft:black_concrete
fill 405 299 557 405 307 557 minecraft:black_concrete
setblock 406 299 557 minecraft:purple_concrete
fill 409 299 557 410 299 557 minecraft:purple_concrete
setblock 409 299 599 minecraft:purple_concrete
fill 418 299 565 418 307 565 minecraft:black_concrete
setblock 418 299 569 minecraft:purple_concrete
fill 418 299 576 418 307 576 minecraft:black_concrete
setblock 418 299 577 minecraft:purple_concrete
setblock 418 299 580 minecraft:purple_concrete
fill 418 299 596 418 307 597 minecraft:black_concrete
fill 376 300 557 376 300 558 minecraft:purple_concrete
fill 376 300 559 376 307 560 minecraft:black_concrete
setblock 376 300 561 minecraft:purple_concrete
fill 376 300 569 376 300 570 minecraft:purple_concrete
fill 376 300 571 376 307 572 minecraft:black_concrete
setblock 376 300 578 minecraft:purple_concrete
fill 376 300 580 376 307 580 minecraft:black_concrete
fill 376 300 581 376 300 582 minecraft:purple_concrete
fill 376 300 583 376 307 583 minecraft:black_concrete
fill 376 300 589 376 300 590 minecraft:purple_concrete
fill 376 300 591 376 307 592 minecraft:black_concrete
fill 377 300 557 378 307 557 minecraft:black_concrete
fill 377 300 558 379 300 558 minecraft:obsidian
fill 377 300 560 377 300 562 minecraft:obsidian
fill 377 300 564 377 300 566 minecraft:obsidian
fill 377 300 568 377 300 570 minecraft:obsidian
fill 377 300 572 377 300 574 minecraft:obsidian
fill 377 300 576 377 300 578 minecraft:obsidian
fill 377 300 580 377 300 582 minecraft:obsidian
fill 377 300 584 377 300 586 minecraft:obsidian
fill 377 300 588 377 300 590 minecraft:obsidian
fill 377 300 592 377 300 594 minecraft:obsidian
fill 377 300 596 377 300 598 minecraft:obsidian
fill 378 300 599 379 300 599 minecraft:purple_concrete
fill 379 300 557 380 300 557 minecraft:purple_concrete
fill 379 300 598 381 300 598 minecraft:obsidian
fill 380 300 599 381 307 599 minecraft:black_concrete
fill 381 300 558 383 300 558 minecraft:obsidian
fill 383 300 598 385 300 598 minecraft:obsidian
fill 385 300 557 386 307 557 minecraft:black_concrete
fill 385 300 558 387 300 558 minecraft:obsidian
fill 387 300 557 388 300 557 minecraft:purple_concrete
fill 387 300 598 389 300 598 minecraft:obsidian
setblock 387 300 599 minecraft:purple_concrete
fill 388 300 599 389 307 599 minecraft:black_concrete
fill 389 300 557 389 307 557 minecraft:black_concrete
fill 389 300 558 391 300 558 minecraft:obsidian
setblock 390 300 599 minecraft:purple_concrete
setblock 391 300 557 minecraft:purple_concrete
fill 391 300 598 393 300 598 minecraft:obsidian
fill 392 300 557 392 307 557 minecraft:black_concrete
fill 392 300 599 392 307 599 minecraft:black_concrete
fill 393 300 558 395 300 558 minecraft:obsidian
fill 395 300 598 397 300 598 minecraft:obsidian
fill 397 300 557 398 307 557 minecraft:black_concrete
fill 397 300 558 399 300 558 minecraft:obsidian
fill 398 300 599 399 300 599 minecraft:purple_concrete
fill 399 300 557 400 300 557 minecraft:purple_concrete
fill 399 300 598 401 300 598 minecraft:obsidian
fill 400 300 599 401 307 599 minecraft:black_concrete
fill 401 300 558 403 300 558 minecraft:obsidian
fill 403 300 598 405 300 598 minecraft:obsidian
fill 405 300 558 407 300 558 minecraft:obsidian
fill 406 300 557 406 307 557 minecraft:black_concrete
fill 407 300 598 409 300 598 minecraft:obsidian
setblock 408 300 557 minecraft:purple_concrete
fill 409 300 557 410 307 557 minecraft:black_concrete
fill 409 300 558 411 300 558 minecraft:obsidian
fill 409 300 599 409 307 599 minecraft:black_concrete
fill 410 300 599 411 300 599 minecraft:purple_concrete
setblock 411 300 557 minecraft:purple_concrete
fill 411 300 598 413 300 598 minecraft:obsidian
fill 412 300 599 413 307 599 minecraft:black_concrete
fill 413 300 558 415 300 558 minecraft:obsidian
fill 415 300 598 417 300 598 minecraft:obsidian
fill 417 300 557 418 307 557 minecraft:black_concrete
fill 417 300 558 417 300 560 minecraft:obsidian
fill 417 300 562 417 300 564 minecraft:obsidian
fill 417 300 566 417 300 568 minecraft:obsidian
fill 417 300 570 417 300 572 minecraft:obsidian
fill 417 300 574 417 300 576 minecraft:obsidian
fill 417 300 578 417 300 580 minecraft:obsidian
fill 417 300 582 417 300 584 minecraft:obsidian
fill 417 300 586 417 300 588 minecraft:obsidian
fill 417 300 590 417 300 592 minecraft:obsidian
fill 417 300 594 417 300 596 minecraft:obsidian
fill 418 300 558 418 300 559 minecraft:purple_concrete
fill 418 300 568 418 307 569 minecraft:black_concrete
fill 418 300 570 418 300 571 minecraft:purple_concrete
fill 418 300 577 418 307 577 minecraft:black_concrete
fill 418 300 578 418 300 579 minecraft:purple_concrete
fill 418 300 580 418 307 580 minecraft:black_concrete
setblock 418 300 582 minecraft:purple_concrete
fill 418 300 588 418 307 589 minecraft:black_concrete
fill 418 300 590 418 300 591 minecraft:purple_concrete
setblock 418 300 599 minecraft:purple_concrete
fill 376 301 557 376 307 558 minecraft:black_concrete
fill 376 301 561 376 307 561 minecraft:black_concrete
fill 376 301 569 376 307 570 minecraft:black_concrete
fill 376 301 578 376 307 578 minecraft:black_concrete
fill 376 301 581 376 307 582 minecraft:black_concrete
fill 376 301 589 376 307 590 minecraft:black_concrete
fill 378 301 599 379 307 599 minecraft:black_concrete
fill 379 301 557 380 307 557 minecraft:black_concrete
setblock 379 301 560 minecraft:light[level=12]
setblock 379 301 568 minecraft:light[level=12]
setblock 379 301 576 minecraft:light[level=12]
setblock 379 301 584 minecraft:light[level=12]
setblock 379 301 592 minecraft:light[level=12]
fill 387 301 557 388 307 557 minecraft:black_concrete
setblock 387 301 560 minecraft:light[level=12]
setblock 387 301 568 minecraft:light[level=12]
setblock 387 301 576 minecraft:light[level=12]
setblock 387 301 584 minecraft:light[level=12]
setblock 387 301 592 minecraft:light[level=12]
fill 387 301 599 387 307 599 minecraft:black_concrete
fill 390 301 599 390 307 599 minecraft:black_concrete
fill 391 301 557 391 307 557 minecraft:black_concrete
setblock 395 301 560 minecraft:light[level=12]
setblock 395 301 568 minecraft:light[level=12]
setblock 395 301 576 minecraft:light[level=12]
setblock 395 301 584 minecraft:light[level=12]
setblock 395 301 592 minecraft:light[level=12]
fill 398 301 599 399 307 599 minecraft:black_concrete
fill 399 301 557 400 307 557 minecraft:black_concrete
setblock 403 301 560 minecraft:light[level=12]
setblock 403 301 568 minecraft:light[level=12]
setblock 403 301 576 minecraft:light[level=12]
setblock 403 301 584 minecraft:light[level=12]
setblock 403 301 592 minecraft:light[level=12]
fill 408 301 557 408 307 557 minecraft:black_concrete
fill 410 301 599 411 307 599 minecraft:black_concrete
fill 411 301 557 411 307 557 minecraft:black_concrete
setblock 411 301 560 minecraft:light[level=12]
setblock 411 301 568 minecraft:light[level=12]
setblock 411 301 576 minecraft:light[level=12]
setblock 411 301 584 minecraft:light[level=12]
setblock 411 301 592 minecraft:light[level=12]
fill 418 301 558 418 307 559 minecraft:black_concrete
fill 418 301 570 418 307 571 minecraft:black_concrete
fill 418 301 578 418 307 579 minecraft:black_concrete
fill 418 301 582 418 307 582 minecraft:black_concrete
fill 418 301 590 418 307 591 minecraft:black_concrete
fill 418 301 599 418 307 599 minecraft:black_concrete
