setblock 236 140 230 minecraft:cyan_stained_glass
setblock 236 140 232 minecraft:light_blue_stained_glass
setblock 236 140 234 minecraft:magenta_stained_glass
setblock 236 140 236 minecraft:black_stained_glass
setblock 236 140 243 minecraft:magenta_stained_glass
setblock 236 140 245 minecraft:pearlescent_froglight
setblock 236 140 247 minecraft:magenta_stained_glass
setblock 236 140 249 minecraft:pearlescent_froglight
setblock 236 140 251 minecraft:ochre_froglight
setblock 236 140 253 minecraft:pearlescent_froglight
setblock 236 140 262 minecraft:ochre_froglight
setblock 236 140 264 minecraft:sea_lantern
setblock 236 140 266 minecraft:black_stained_glass
setblock 236 140 268 minecraft:pearlescent_froglight
setblock 237 140 229 minecraft:light_blue_stained_glass
setblock 237 140 237 minecraft:black_stained_glass
setblock 237 140 242 minecraft:light_blue_stained_glass
setblock 237 140 255 minecraft:black_stained_glass
setblock 237 140 261 minecraft:light_blue_stained_glass
setblock 237 140 269 minecraft:black_stained_glass
setblock 239 140 229 minecraft:black_stained_glass
setblock 239 140 237 minecraft:black_stained_glass
setblock 239 140 242 minecraft:black_stained_glass
setblock 239 140 255 minecraft:magenta_stained_glass
setblock 239 140 261 minecraft:pearlescent_froglight
setblock 239 140 269 minecraft:magenta_stained_glass
setblock 241 140 229 minecraft:black_stained_glass
setblock 241 140 237 minecraft:ochre_froglight
setblock 241 140 243 minecraft:cyan_stained_glass
setblock 241 140 245 minecraft:cyan_stained_glass
setblock 241 140 247 minecraft:light_blue_stained_glass
setblock 241 140 249 minecraft:cyan_stained_glass
setblock 241 140 251 minecraft:cyan_stained_glass
setblock 241 140 253 minecraft:cyan_stained_glass
setblock 241 140 261 minecraft:sea_lantern
setblock 241 140 269 minecraft:magenta_stained_glass
setblock 243 140 229 minecraft:light_blue_stained_glass
setblock 243 140 237 minecraft:black_stained_glass
setblock 243 140 261 minecraft:black_stained_glass
setblock 243 140 269 minecraft:black_stained_glass
setblock 244 140 230 minecraft:black_stained_glass
setblock 244 140 232 minecraft:pearlescent_froglight
setblock 244 140 234 minecraft:magenta_stained_glass
setblock 244 140 236 minecraft:black_stained_glass
setblock 244 140 262 minecraft:light_blue_stained_glass
setblock 244 140 264 minecraft:cyan_stained_glass
setblock 244 140 266 minecraft:black_stained_glass
setblock 244 140 268 minecraft:pearlescent_froglight
setblock 249 140 230 minecraft:sea_lantern
setblock 249 140 232 minecraft:magenta_stained_glass
setblock 249 140 265 minecraft:sea_lantern
setblock 249 140 267 minecraft:magenta_stained_glass
fill 250 140 228 250 268 228 minecraft:black_concrete
setblock 250 140 229 minecraft:magenta_stained_glass
setblock 250 140 234 minecraft:ochre_froglight
setblock 250 140 264 minecraft:black_stained_glass
setblock 250 140 269 minecraft:ochre_froglight
setblock 252 140 229 minecraft:black_stained_glass
setblock 252 140 234 minecraft:pearlescent_froglight
setblock 252 140 264 minecraft:ochre_froglight
setblock 252 140 269 minecraft:pearlescent_froglight
setblock 254 140 228 minecraft:blue_concrete
setblock 254 140 229 minecraft:light_blue_stained_glass
setblock 254 140 234 minecraft:black_stained_glass
setblock 254 140 264 minecraft:black_stained_glass
setblock 254 140 269 minecraft:magenta_stained_glass
setblock 256 140 229 minecraft:black_stained_glass
setblock 256 140 234 minecraft:black_stained_glass
setblock 256 140 264 minecraft:black_stained_glass
setblock 256 140 269 minecraft:pearlescent_froglight
setblock 258 140 229 minecraft:pearlescent_froglight
setblock 258 140 234 minecraft:ochre_froglight
setblock 258 140 264 minecraft:light_blue_stained_glass
setblock 258 140 269 minecraft:black_stained_glass
setblock 260 140 229 minecraft:black_stained_glass
setblock 260 140 234 minecraft:black_stained_glass
setblock 260 140 264 minecraft:sea_lantern
setblock 260 140 269 minecraft:black_stained_glass
setblock 262 140 230 minecraft:black_stained_glass
setblock 262 140 232 minecraft:black_stained_glass
setblock 262 140 265 minecraft:ochre_froglight
setblock 262 140 267 minecraft:black_stained_glass
setblock 267 140 228 minecraft:purple_concrete
setblock 268 140 230 minecraft:light_blue_stained_glass
setblock 268 140 232 minecraft:pearlescent_froglight
setblock 268 140 234 minecraft:black_stained_glass
setblock 268 140 236 minecraft:sea_lantern
setblock 268 140 262 minecraft:light_blue_stained_glass
setblock 268 140 264 minecraft:cyan_stained_glass
setblock 268 140 266 minecraft:sea_lantern
setblock 268 140 268 minecraft:black_stained_glass
fill 269 140 228 269 175 228 minecraft:black_concrete
setblock 269 140 229 minecraft:light_blue_stained_glass
setblock 269 140 237 minecraft:light_blue_stained_glass
setblock 269 140 261 minecraft:pearlescent_froglight
setblock 269 140 269 minecraft:sea_lantern
setblock 271 140 229 minecraft:black_stained_glass
setblock 271 140 237 minecraft:ochre_froglight
setblock 271 140 243 minecraft:cyan_stained_glass
setblock 271 140 245 minecraft:ochre_froglight
setblock 271 140 247 minecraft:black_stained_glass
setblock 271 140 249 minecraft:black_stained_glass
setblock 271 140 251 minecraft:light_blue_stained_glass
setblock 271 140 253 minecraft:ochre_froglight
setblock 271 140 261 minecraft:cyan_stained_glass
setblock 271 140 269 minecraft:sea_lantern
setblock 272 140 242 minecraft:ochre_froglight
setblock 272 140 255 minecraft:black_stained_glass
setblock 273 140 229 minecraft:black_stained_glass
setblock 273 140 237 minecraft:black_stained_glass
setblock 273 140 261 minecraft:pearlescent_froglight
setblock 273 140 269 minecraft:light_blue_stained_glass
setblock 274 140 242 minecraft:black_stained_glass
setblock 274 140 255 minecraft:magenta_stained_glass
setblock 275 140 229 minecraft:ochre_froglight
setblock 275 140 237 minecraft:black_stained_glass
setblock 275 140 261 minecraft:black_stained_glass
setblock 275 140 269 minecraft:black_stained_glass
setblock 276 140 230 minecraft:sea_lantern
setblock 276 140 232 minecraft:black_stained_glass
setblock 276 140 234 minecraft:sea_lantern
setblock 276 140 236 minecraft:light_blue_stained_glass
setblock 276 140 243 minecraft:black_stained_glass
setblock 276 140 245 minecraft:sea_lantern
setblock 276 140 247 minecraft:sea_lantern
setblock 276 140 249 minecraft:black_stained_glass
setblock 276 140 251 minecraft:sea_lantern
setblock 276 140 253 minecraft:black_stained_glass
setblock 276 140 262 minecraft:cyan_stained_glass
setblock 276 140 264 minecraft:pearlescent_froglight
setblock 276 140 266 minecraft:black_stained_glass
setblock 276 140 268 minecraft:black_stained_glass
setblock 235 141 265 minecraft:verdant_froglight
fill 236 141 230 236 142 230 minecraft:light_gray_concrete
fill 236 141 232 236 142 232 minecraft:light_gray_concrete
fill 236 141 234 236 142 234 minecraft:light_gray_concrete
fill 236 141 236 236 142 236 minecraft:light_gray_concrete
fill 236 141 243 236 142 243 minecraft:light_gray_concrete
fill 236 141 245 236 142 245 minecraft:light_gray_concrete
fill 236 141 247 236 142 247 minecraft:light_gray_concrete
fill 236 141 249 236 142 249 minecraft:light_gray_concrete
fill 236 141 251 236 142 251 minecraft:light_gray_concrete
fill 236 141 253 236 142 253 minecraft:light_gray_concrete
fill 236 141 262 236 142 262 minecraft:cyan_terracotta
fill 236 141 264 236 142 264 minecraft:cyan_terracotta
fill 236 141 266 236 142 266 minecraft:cyan_terracotta
fill 236 141 268 236 142 268 minecraft:cyan_terracotta
fill 237 141 229 237 142 229 minecraft:light_gray_concrete
fill 237 141 237 237 142 237 minecraft:light_gray_concrete
fill 237 141 242 237 142 242 minecraft:light_gray_concrete
fill 237 141 255 237 142 255 minecraft:light_gray_concrete
fill 237 141 261 237 142 261 minecraft:cyan_terracotta
fill 237 141 269 237 142 269 minecraft:cyan_terracotta
setblock 239 141 228 minecraft:ochre_froglight
fill 239 141 229 239 142 229 minecraft:light_gray_concrete
fill 239 141 237 239 142 237 minecraft:light_gray_concrete
fill 239 141 242 239 142 242 minecraft:light_gray_concrete
fill 239 141 255 239 142 255 minecraft:light_gray_concrete
fill 239 141 261 239 142 261 minecraft:cyan_terracotta
fill 239 141 269 239 142 269 minecraft:cyan_terracotta
fill 241 141 229 241 142 229 minecraft:light_gray_concrete
fill 241 141 237 241 142 237 minecraft:light_gray_concrete
fill 241 141 243 241 142 243 minecraft:light_gray_concrete
fill 241 141 245 241 142 245 minecraft:light_gray_concrete
fill 241 141 247 241 142 247 minecraft:light_gray_concrete
fill 241 141 249 241 142 249 minecraft:light_gray_concrete
fill 241 141 251 241 142 251 minecraft:light_gray_concrete
fill 241 141 253 241 142 253 minecraft:light_gray_concrete
fill 241 141 261 241 142 261 minecraft:cyan_terracotta
fill 241 141 269 241 142 269 minecraft:cyan_terracotta
fill 243 141 229 243 142 229 minecraft:light_gray_concrete
fill 243 141 237 243 142 237 minecraft:light_gray_concrete
fill 243 141 261 243 142 261 minecraft:cyan_terracotta
fill 243 141 269 243 142 269 minecraft:cyan_terracotta
fill 244 141 230 244 142 230 minecraft:light_gray_concrete
fill 244 141 232 244 142 232 minecraft:light_gray_concrete
fill 244 141 234 244 142 234 minecraft:light_gray_concrete
fill 244 141 236 244 142 236 minecraft:light_gray_concrete
fill 244 141 262 244 142 262 minecraft:cyan_terracotta
fill 244 141 264 244 142 264 minecraft:cyan_terracotta
fill 244 141 266 244 142 266 minecraft:cyan_terracotta
fill 244 141 268 244 142 268 minecraft:cyan_terracotta
fill 245 141 228 245 204 228 minecraft:black_concrete
setblock 246 141 228 minecraft:purple_concrete
fill 247 141 228 247 172 228 minecraft:black_concrete
fill 249 141 230 249 142 230 minecraft:light_gray_concrete
fill 249 141 232 249 142 232 minecraft:light_gray_concrete
fill 249 141 265 249 142 265 minecraft:cyan_terracotta
fill 249 141 267 249 142 267 minecraft:cyan_terracotta
fill 250 141 229 250 142 229 minecraft:light_gray_concrete
fill 250 141 234 250 142 234 minecraft:light_gray_concrete
fill 250 141 264 250 142 264 minecraft:cyan_terracotta
fill 250 141 269 250 142 269 minecraft:cyan_terracotta
fill 252 141 229 252 142 229 minecraft:light_gray_concrete
fill 252 141 234 252 142 234 minecraft:light_gray_concrete
fill 252 141 264 252 142 264 minecraft:cyan_terracotta
fill 252 141 269 252 142 269 minecraft:cyan_terracotta
fill 254 141 228 254 153 228 minecraft:black_concrete
fill 254 141 229 254 142 229 minecraft:light_gray_concrete
fill 254 141 234 254 142 234 minecraft:light_gray_concrete
fill 254 141 264 254 142 264 minecraft:cyan_terracotta
fill 254 141 269 254 142 269 minecraft:cyan_terracotta
setblock 256 141 228 minecraft:blue_concrete
fill 256 141 229 256 142 229 minecraft:light_gray_concrete
fill 256 141 234 256 142 234 minecraft:light_gray_concrete
fill 256 141 264 256 142 264 minecraft:cyan_terracotta
fill 256 141 269 256 142 269 minecraft:cyan_terracotta
fill 258 141 229 258 142 229 minecraft:light_gray_concrete
fill 258 141 234 258 142 234 minecraft:light_gray_concrete
fill 258 141 264 258 142 264 minecraft:cyan_terracotta
fill 258 141 269 258 142 269 minecraft:cyan_terracotta
fill 260 141 229 260 142 229 minecraft:light_gray_concrete
fill 260 141 234 260 142 234 minecraft:light_gray_concrete
fill 260 141 264 260 142 264 minecraft:cyan_terracotta
fill 260 141 269 260 142 269 minecraft:cyan_terracotta
fill 262 141 230 262 142 230 minecraft:light_gray_concrete
fill 262 141 232 262 142 232 minecraft:light_gray_concrete
fill 262 141 265 262 142 265 minecraft:cyan_terracotta
fill 262 141 267 262 142 267 minecraft:cyan_terracotta
fill 267 141 228 267 203 228 minecraft:black_concrete
fill 268 141 230 268 142 230 minecraft:cyan_terracotta
fill 268 141 232 268 142 232 minecraft:cyan_terracotta
fill 268 141 234 268 142 234 minecraft:cyan_terracotta
fill 268 141 236 268 142 236 minecraft:cyan_terracotta
fill 268 141 262 268 142 262 minecraft:light_gray_concrete
fill 268 141 264 268 142 264 minecraft:light_gray_concrete
fill 268 141 266 268 142 266 minecraft:light_gray_concrete
fill 268 141 268 268 142 268 minecraft:light_gray_concrete
fill 269 141 229 269 142 229 minecraft:cyan_terracotta
fill 269 141 237 269 142 237 minecraft:cyan_terracotta
fill 269 141 261 269 142 261 minecraft:light_gray_concrete
fill 269 141 269 269 142 269 minecraft:light_gray_concrete
fill 271 141 229 271 142 229 minecraft:cyan_terracotta
fill 271 141 237 271 142 237 minecraft:cyan_terracotta
fill 271 141 243 271 142 243 minecraft:light_gray_concrete
fill 271 141 245 271 142 245 minecraft:light_gray_concrete
fill 271 141 247 271 142 247 minecraft:light_gray_concrete
setblock 271 141 249 minecraft:light_gray_concrete
setblock 271 141 251 minecraft:light_gray_concrete
setblock 271 141 253 minecraft:light_gray_concrete
fill 271 141 261 271 142 261 minecraft:light_gray_concrete
fill 271 141 269 271 142 269 minecraft:light_gray_concrete
setblock 272 141 228 minecraft:verdant_froglight
fill 272 141 242 272 142 242 minecraft:light_gray_concrete
fill 272 141 255 272 142 255 minecraft:light_gray_concrete
fill 273 141 228 273 308 228 minecraft:black_concrete
fill 273 141 229 273 142 229 minecraft:cyan_terracotta
fill 273 141 237 273 142 237 minecraft:cyan_terracotta
fill 273 141 261 273 142 261 minecraft:light_gray_concrete
fill 273 141 269 273 142 269 minecraft:light_gray_concrete
setblock 273 141 270 minecraft:magenta_concrete
fill 274 141 242 274 142 242 minecraft:light_gray_concrete
fill 274 141 255 274 142 255 minecraft:light_gray_concrete
fill 275 141 229 275 142 229 minecraft:cyan_terracotta
fill 275 141 237 275 142 237 minecraft:cyan_terracotta
fill 275 141 261 275 142 261 minecraft:light_gray_concrete
fill 275 141 269 275 142 269 minecraft:light_gray_concrete
fill 276 141 230 276 142 230 minecraft:cyan_terracotta
fill 276 141 232 276 142 232 minecraft:cyan_terracotta
fill 276 141 234 276 142 234 minecraft:cyan_terracotta
fill 276 141 236 276 142 236 minecraft:cyan_terracotta
fill 276 141 243 276 142 243 minecraft:light_gray_concrete
fill 276 141 245 276 142 245 minecraft:light_gray_concrete
fill 276 141 247 276 142 247 minecraft:light_gray_concrete
fill 276 141 249 276 142 249 minecraft:light_gray_concrete
fill 276 141 251 276 142 251 minecraft:light_gray_concrete
fill 276 141 253 276 142 253 minecraft:light_gray_concrete
fill 276 141 262 276 142 262 minecraft:light_gray_concrete
fill 276 141 264 276 142 264 minecraft:light_gray_concrete
fill 276 141 266 276 142 266 minecraft:light_gray_concrete
fill 276 141 268 276 142 268 minecraft:light_gray_concrete
setblock 277 141 241 minecraft:verdant_froglight
setblock 235 142 253 minecraft:blue_concrete
fill 235 142 265 235 202 265 minecraft:black_concrete
fill 239 142 228 239 183 228 minecraft:black_concrete
fill 246 142 228 246 299 228 minecraft:black_concrete
fill 249 142 249 250 143 249 minecraft:cyan_stained_glass
fill 249 142 250 249 144 250 minecraft:sea_lantern
fill 249 142 251 249 144 253 minecraft:cyan_stained_glass
fill 249 142 254 249 144 254 minecraft:sea_lantern
fill 249 142 255 250 143 255 minecraft:cyan_stained_glass
fill 250 142 247 250 144 248 minecraft:cyan_stained_glass
fill 250 142 256 250 144 257 minecraft:cyan_stained_glass
fill 251 142 245 252 143 245 minecraft:cyan_stained_glass
fill 251 142 246 251 145 246 minecraft:sea_lantern
fill 251 142 258 251 145 258 minecraft:sea_lantern
fill 251 142 259 252 143 259 minecraft:cyan_stained_glass
fill 252 142 244 253 143 244 minecraft:cyan_stained_glass
fill 252 142 260 253 143 260 minecraft:cyan_stained_glass
fill 253 142 243 253 143 243 minecraft:cyan_stained_glass
fill 253 142 261 253 143 261 minecraft:cyan_stained_glass
fill 254 142 243 254 145 243 minecraft:sea_lantern
fill 254 142 261 254 143 261 minecraft:sea_lantern
fill 255 142 242 257 144 242 minecraft:cyan_stained_glass
fill 255 142 262 257 144 262 minecraft:cyan_stained_glass
fill 256 142 228 256 177 228 minecraft:black_concrete
fill 257 142 241 257 143 241 minecraft:cyan_stained_glass
fill 257 142 263 257 143 263 minecraft:cyan_stained_glass
fill 258 142 241 258 144 241 minecraft:sea_lantern
fill 258 142 263 258 144 263 minecraft:sea_lantern
fill 259 142 241 261 144 241 minecraft:cyan_stained_glass
fill 259 142 263 261 144 263 minecraft:cyan_stained_glass
fill 262 142 241 262 144 241 minecraft:sea_lantern
fill 262 142 263 262 144 263 minecraft:sea_lantern
fill 263 142 241 263 143 242 minecraft:cyan_stained_glass
fill 263 142 262 263 143 263 minecraft:cyan_stained_glass
fill 264 142 242 265 144 242 minecraft:cyan_stained_glass
fill 264 142 262 265 144 262 minecraft:cyan_stained_glass
fill 266 142 243 266 145 243 minecraft:sea_lantern
fill 266 142 261 266 145 261 minecraft:sea_lantern
fill 267 142 243 267 143 244 minecraft:cyan_stained_glass
fill 267 142 260 267 143 261 minecraft:cyan_stained_glass
fill 268 142 244 268 143 245 minecraft:cyan_stained_glass
fill 268 142 259 268 143 260 minecraft:cyan_stained_glass
fill 269 142 245 269 143 245 minecraft:cyan_stained_glass
fill 269 142 246 269 145 246 minecraft:sea_lantern
fill 269 142 258 269 145 258 minecraft:sea_lantern
fill 269 142 259 269 143 259 minecraft:cyan_stained_glass
fill 270 142 247 270 144 249 minecraft:cyan_stained_glass
fill 270 142 255 270 144 257 minecraft:cyan_stained_glass
fill 271 142 249 271 143 249 minecraft:cyan_stained_glass
fill 271 142 250 271 144 250 minecraft:sea_lantern
fill 271 142 251 271 144 253 minecraft:cyan_stained_glass
fill 271 142 254 271 144 254 minecraft:sea_lantern
fill 271 142 255 271 143 255 minecraft:cyan_stained_glass
fill 272 142 228 272 208 228 minecraft:black_concrete
fill 272 142 250 276 222 250 minecraft:light_gray_concrete
fill 272 142 252 276 222 252 minecraft:light_gray_concrete
fill 273 142 270 273 170 270 minecraft:black_concrete
fill 277 142 241 277 143 241 minecraft:black_concrete
setblock 235 143 230 minecraft:magenta_concrete
fill 235 143 253 235 222 253 minecraft:black_concrete
setblock 236 143 230 minecraft:sea_lantern
setblock 236 143 232 minecraft:pearlescent_froglight
setblock 236 143 234 minecraft:pearlescent_froglight
setblock 236 143 236 minecraft:sea_lantern
setblock 236 143 243 minecraft:black_stained_glass
setblock 236 143 245 minecraft:sea_lantern
setblock 236 143 247 minecraft:black_stained_glass
setblock 236 143 249 minecraft:light_blue_stained_glass
setblock 236 143 251 minecraft:black_stained_glass
setblock 236 143 253 minecraft:black_stained_glass
setblock 236 143 262 minecraft:black_stained_glass
setblock 236 143 264 minecraft:black_stained_glass
setblock 236 143 266 minecraft:black_stained_glass
setblock 236 143 268 minecraft:cyan_stained_glass
setblock 237 143 229 minecraft:black_stained_glass
setblock 237 143 237 minecraft:ochre_froglight
setblock 237 143 242 minecraft:cyan_stained_glass
setblock 237 143 255 minecraft:cyan_stained_glass
setblock 237 143 261 minecraft:pearlescent_froglight
setblock 237 143 269 minecraft:cyan_stained_glass
setblock 238 143 239 minecraft:light[level=15]
setblock 239 143 229 minecraft:black_stained_glass
setblock 239 143 237 minecraft:magenta_stained_glass
setblock 239 143 242 minecraft:light_blue_stained_glass
setblock 239 143 255 minecraft:magenta_stained_glass
setblock 239 143 261 minecraft:black_stained_glass
setblock 239 143 269 minecraft:cyan_stained_glass
setblock 240 143 228 minecraft:sea_lantern
setblock 241 143 229 minecraft:black_stained_glass
setblock 241 143 237 minecraft:cyan_stained_glass
setblock 241 143 243 minecraft:black_stained_glass
setblock 241 143 245 minecraft:black_stained_glass
setblock 241 143 247 minecraft:magenta_stained_glass
setblock 241 143 249 minecraft:black_stained_glass
setblock 241 143 251 minecraft:black_stained_glass
setblock 241 143 253 minecraft:black_stained_glass
setblock 241 143 261 minecraft:black_stained_glass
setblock 241 143 269 minecraft:black_stained_glass
setblock 243 143 229 minecraft:black_stained_glass
setblock 243 143 237 minecraft:light_blue_stained_glass
setblock 243 143 261 minecraft:ochre_froglight
setblock 243 143 269 minecraft:ochre_froglight
setblock 244 143 230 minecraft:black_stained_glass
setblock 244 143 232 minecraft:ochre_froglight
setblock 244 143 234 minecraft:black_stained_glass
setblock 244 143 236 minecraft:ochre_froglight
setblock 244 143 262 minecraft:black_stained_glass
setblock 244 143 264 minecraft:black_stained_glass
setblock 244 143 266 minecraft:magenta_stained_glass
setblock 244 143 268 minecraft:magenta_stained_glass
setblock 246 143 231 minecraft:light[level=15]
setblock 246 143 239 minecraft:light[level=15]
setblock 246 143 247 minecraft:light[level=15]
setblock 246 143 255 minecraft:light[level=15]
setblock 246 143 263 minecraft:light[level=15]
setblock 249 143 230 minecraft:black_stained_glass
setblock 249 143 232 minecraft:black_stained_glass
setblock 249 143 265 minecraft:sea_lantern
setblock 249 143 267 minecraft:cyan_stained_glass
setblock 250 143 229 minecraft:black_stained_glass
setblock 250 143 234 minecraft:pearlescent_froglight
setblock 250 143 264 minecraft:cyan_stained_glass
setblock 250 143 269 minecraft:sea_lantern
fill 251 143 247 251 146 247 minecraft:cyan_stained_glass
fill 251 143 257 251 146 257 minecraft:cyan_stained_glass
setblock 252 143 229 minecraft:black_stained_glass
setblock 252 143 234 minecraft:pearlescent_froglight
setblock 252 143 264 minecraft:sea_lantern
setblock 252 143 269 minecraft:black_stained_glass
setblock 254 143 229 minecraft:light_blue_stained_glass
setblock 254 143 234 minecraft:black_stained_glass
setblock 254 143 239 minecraft:light[level=15]
setblock 254 143 247 minecraft:light[level=15]
setblock 254 143 255 minecraft:light[level=15]
setblock 254 143 263 minecraft:light[level=15]
setblock 254 143 264 minecraft:magenta_stained_glass
setblock 254 143 269 minecraft:light_blue_stained_glass
fill 255 143 243 255 146 243 minecraft:cyan_stained_glass
fill 255 143 261 255 146 261 minecraft:cyan_stained_glass
setblock 256 143 229 minecraft:black_stained_glass
setblock 256 143 234 minecraft:light_blue_stained_glass
setblock 256 143 264 minecraft:black_stained_glass
setblock 256 143 269 minecraft:cyan_stained_glass
setblock 257 143 228 minecraft:magenta_concrete
setblock 258 143 229 minecraft:ochre_froglight
setblock 258 143 234 minecraft:black_stained_glass
setblock 258 143 264 minecraft:pearlescent_froglight
setblock 258 143 269 minecraft:black_stained_glass
setblock 260 143 229 minecraft:black_stained_glass
setblock 260 143 234 minecraft:light_blue_stained_glass
setblock 260 143 264 minecraft:sea_lantern
setblock 260 143 269 minecraft:ochre_froglight
setblock 262 143 230 minecraft:magenta_stained_glass
setblock 262 143 232 minecraft:magenta_stained_glass
setblock 262 143 239 minecraft:light[level=15]
setblock 262 143 247 minecraft:light[level=15]
setblock 262 143 255 minecraft:light[level=15]
setblock 262 143 265 minecraft:black_stained_glass
setblock 262 143 267 minecraft:black_stained_glass
fill 265 143 243 265 146 243 minecraft:cyan_stained_glass
fill 265 143 261 265 146 261 minecraft:cyan_stained_glass
setblock 268 143 230 minecraft:black_stained_glass
setblock 268 143 232 minecraft:cyan_stained_glass
setblock 268 143 234 minecraft:pearlescent_froglight
setblock 268 143 236 minecraft:ochre_froglight
setblock 268 143 262 minecraft:pearlescent_froglight
setblock 268 143 264 minecraft:pearlescent_froglight
setblock 268 143 266 minecraft:cyan_stained_glass
setblock 268 143 268 minecraft:black_stained_glass
setblock 269 143 229 minecraft:black_stained_glass
setblock 269 143 237 minecraft:black_stained_glass
fill 269 143 247 269 146 247 minecraft:cyan_stained_glass
fill 269 143 257 269 146 257 minecraft:cyan_stained_glass
setblock 269 143 261 minecraft:light_blue_stained_glass
setblock 269 143 269 minecraft:black_stained_glass
setblock 270 143 239 minecraft:light[level=15]
setblock 271 143 229 minecraft:light_blue_stained_glass
setblock 271 143 237 minecraft:black_stained_glass
setblock 271 143 243 minecraft:black_stained_glass
setblock 271 143 245 minecraft:cyan_stained_glass
setblock 271 143 247 minecraft:pearlescent_froglight
setblock 271 143 261 minecraft:black_stained_glass
setblock 271 143 269 minecraft:black_stained_glass
setblock 272 143 242 minecraft:magenta_stained_glass
setblock 272 143 255 minecraft:black_stained_glass
setblock 273 143 229 minecraft:black_stained_glass
setblock 273 143 237 minecraft:black_stained_glass
setblock 273 143 261 minecraft:cyan_stained_glass
setblock 273 143 269 minecraft:black_stained_glass
setblock 274 143 242 minecraft:pearlescent_froglight
setblock 274 143 255 minecraft:pearlescent_froglight
setblock 275 143 229 minecraft:ochre_froglight
setblock 275 143 237 minecraft:black_stained_glass
setblock 275 143 261 minecraft:black_stained_glass
setblock 275 143 269 minecraft:ochre_froglight
setblock 276 143 230 minecraft:black_stained_glass
setblock 276 143 232 minecraft:black_stained_glass
setblock 276 143 234 minecraft:pearlescent_froglight
setblock 276 143 236 minecraft:pearlescent_froglight
setblock 276 143 243 minecraft:sea_lantern
setblock 276 143 245 minecraft:black_stained_glass
setblock 276 143 247 minecraft:pearlescent_froglight
setblock 276 143 249 minecraft:magenta_stained_glass
setblock 276 143 251 minecraft:ochre_froglight
setblock 276 143 253 minecraft:light_blue_stained_glass
setblock 276 143 262 minecraft:cyan_stained_glass
setblock 276 143 264 minecraft:pearlescent_froglight
setblock 276 143 266 minecraft:cyan_stained_glass
setblock 276 143 268 minecraft:black_stained_glass
fill 235 144 230 235 148 230 minecraft:black_concrete
fill 236 144 230 236 145 230 minecraft:light_gray_concrete
fill 236 144 232 236 145 232 minecraft:light_gray_concrete
fill 236 144 234 236 145 234 minecraft:light_gray_concrete
fill 236 144 236 236 145 236 minecraft:light_gray_concrete
fill 236 144 243 236 145 243 minecraft:light_gray_concrete
fill 236 144 245 236 145 245 minecraft:light_gray_concrete
fill 236 144 247 236 145 247 minecraft:light_gray_concrete
fill 236 144 249 236 145 249 minecraft:light_gray_concrete
fill 236 144 251 236 145 251 minecraft:light_gray_concrete
fill 236 144 253 236 145 253 minecraft:light_gray_concrete
fill 236 144 262 236 145 262 minecraft:cyan_terracotta
fill 236 144 264 236 145 264 minecraft:cyan_terracotta
fill 236 144 266 236 145 266 minecraft:cyan_terracotta
fill 236 144 268 236 145 268 minecraft:cyan_terracotta
fill 237 144 229 237 145 229 minecraft:light_gray_concrete
fill 237 144 237 237 145 237 minecraft:light_gray_concrete
fill 237 144 242 237 145 242 minecraft:light_gray_concrete
fill 237 144 255 237 145 255 minecraft:light_gray_concrete
fill 237 144 261 237 145 261 minecraft:cyan_terracotta
fill 237 144 269 237 145 269 minecraft:cyan_terracotta
fill 239 144 229 239 145 229 minecraft:light_gray_concrete
fill 239 144 237 239 145 237 minecraft:light_gray_concrete
fill 239 144 242 239 145 242 minecraft:light_gray_concrete
fill 239 144 255 239 145 255 minecraft:light_gray_concrete
fill 239 144 261 239 145 261 minecraft:cyan_terracotta
fill 239 144 269 239 145 269 minecraft:cyan_terracotta
fill 240 144 228 240 308 228 minecraft:black_concrete
fill 241 144 229 241 145 229 minecraft:light_gray_concrete
fill 241 144 237 241 145 237 minecraft:light_gray_concrete
fill 241 144 243 241 145 243 minecraft:light_gray_concrete
fill 241 144 245 241 145 245 minecraft:light_gray_concrete
fill 241 144 247 241 145 247 minecraft:light_gray_concrete
fill 241 144 249 241 145 249 minecraft:light_gray_concrete
fill 241 144 251 241 145 251 minecraft:light_gray_concrete
fill 241 144 253 241 145 253 minecraft:light_gray_concrete
fill 241 144 261 241 145 261 minecraft:cyan_terracotta
fill 241 144 269 241 145 269 minecraft:cyan_terracotta
fill 243 144 229 243 145 229 minecraft:light_gray_concrete
fill 243 144 237 243 145 237 minecraft:light_gray_concrete
fill 243 144 261 243 145 261 minecraft:cyan_terracotta
fill 243 144 269 243 145 269 minecraft:cyan_terracotta
fill 244 144 230 244 145 230 minecraft:light_gray_concrete
fill 244 144 232 244 145 232 minecraft:light_gray_concrete
fill 244 144 234 244 145 234 minecraft:light_gray_concrete
fill 244 144 236 244 145 236 minecraft:light_gray_concrete
fill 244 144 245 244 144 247 minecraft:verdant_froglight
fill 244 144 249 244 144 251 minecraft:verdant_froglight
fill 244 144 262 244 145 262 minecraft:cyan_terracotta
fill 244 144 264 244 145 264 minecraft:cyan_terracotta
fill 244 144 266 244 145 266 minecraft:cyan_terracotta
fill 244 144 268 244 145 268 minecraft:cyan_terracotta
fill 248 144 261 248 147 261 minecraft:pearlescent_froglight
fill 249 144 230 249 145 230 minecraft:light_gray_concrete
fill 249 144 232 249 145 232 minecraft:light_gray_concrete
fill 249 144 265 249 145 265 minecraft:cyan_terracotta
fill 249 144 267 249 145 267 minecraft:cyan_terracotta
fill 250 144 229 250 145 229 minecraft:light_gray_concrete
fill 250 144 234 250 145 234 minecraft:light_gray_concrete
fill 250 144 237 252 144 237 minecraft:pearlescent_froglight
fill 250 144 249 250 146 249 minecraft:cyan_stained_glass
fill 250 144 250 250 146 250 minecraft:sea_lantern
fill 250 144 254 250 146 254 minecraft:sea_lantern
fill 250 144 255 250 146 255 minecraft:cyan_stained_glass
fill 250 144 261 250 148 261 minecraft:pearlescent_froglight
fill 250 144 264 250 145 264 minecraft:cyan_terracotta
fill 250 144 269 250 145 269 minecraft:cyan_terracotta
fill 252 144 229 252 145 229 minecraft:light_gray_concrete
fill 252 144 234 252 145 234 minecraft:light_gray_concrete
fill 252 144 245 252 145 245 minecraft:cyan_stained_glass
fill 252 144 259 252 145 259 minecraft:cyan_stained_glass
fill 252 144 261 254 144 261 minecraft:pearlescent_froglight
fill 252 144 264 252 145 264 minecraft:cyan_terracotta
fill 252 144 269 252 145 269 minecraft:cyan_terracotta
fill 253 144 244 253 145 244 minecraft:cyan_stained_glass
fill 253 144 260 253 145 260 minecraft:cyan_stained_glass
fill 254 144 229 254 145 229 minecraft:light_gray_concrete
fill 254 144 234 254 145 234 minecraft:light_gray_concrete
fill 254 144 264 254 145 264 minecraft:cyan_terracotta
fill 254 144 269 254 145 269 minecraft:cyan_terracotta
fill 256 144 229 256 145 229 minecraft:light_gray_concrete
fill 256 144 234 256 145 234 minecraft:light_gray_concrete
fill 256 144 237 256 148 237 minecraft:pearlescent_froglight
fill 256 144 264 256 145 264 minecraft:cyan_terracotta
fill 256 144 269 256 145 269 minecraft:cyan_terracotta
fill 257 144 228 257 170 228 minecraft:black_concrete
fill 258 144 229 258 145 229 minecraft:light_gray_concrete
fill 258 144 234 258 145 234 minecraft:light_gray_concrete
fill 258 144 242 258 146 242 minecraft:sea_lantern
fill 258 144 261 258 148 261 minecraft:pearlescent_froglight
fill 258 144 262 258 146 262 minecraft:sea_lantern
fill 258 144 264 258 145 264 minecraft:cyan_terracotta
fill 258 144 269 258 145 269 minecraft:cyan_terracotta
fill 260 144 229 260 145 229 minecraft:light_gray_concrete
fill 260 144 234 260 145 234 minecraft:light_gray_concrete
fill 260 144 264 260 145 264 minecraft:cyan_terracotta
fill 260 144 269 260 145 269 minecraft:cyan_terracotta
setblock 261 144 261 minecraft:pearlescent_froglight
fill 262 144 230 262 145 230 minecraft:light_gray_concrete
fill 262 144 232 262 145 232 minecraft:light_gray_concrete
fill 262 144 242 262 146 242 minecraft:sea_lantern
fill 262 144 262 262 146 262 minecraft:sea_lantern
fill 262 144 265 262 145 265 minecraft:cyan_terracotta
fill 262 144 267 262 145 267 minecraft:cyan_terracotta
fill 263 144 237 263 146 237 minecraft:pearlescent_froglight
fill 263 144 242 263 146 242 minecraft:cyan_stained_glass
fill 263 144 262 263 146 262 minecraft:cyan_stained_glass
fill 267 144 244 267 145 244 minecraft:cyan_stained_glass
fill 267 144 260 267 145 260 minecraft:cyan_stained_glass
fill 268 144 230 268 145 230 minecraft:cyan_terracotta
fill 268 144 232 268 145 232 minecraft:cyan_terracotta
fill 268 144 234 268 145 234 minecraft:cyan_terracotta
fill 268 144 236 268 145 236 minecraft:cyan_terracotta
fill 268 144 245 268 148 245 minecraft:verdant_froglight
fill 268 144 247 268 147 247 minecraft:verdant_froglight
fill 268 144 249 268 144 251 minecraft:verdant_froglight
setblock 268 144 254 minecraft:verdant_froglight
fill 268 144 259 268 145 259 minecraft:cyan_stained_glass
fill 268 144 262 268 145 262 minecraft:light_gray_concrete
fill 268 144 264 268 145 264 minecraft:light_gray_concrete
fill 268 144 266 268 145 266 minecraft:light_gray_concrete
fill 268 144 268 268 145 268 minecraft:light_gray_concrete
fill 269 144 229 269 145 229 minecraft:cyan_terracotta
fill 269 144 237 269 145 237 minecraft:cyan_terracotta
fill 269 144 261 269 145 261 minecraft:light_gray_concrete
fill 269 144 269 269 145 269 minecraft:light_gray_concrete
fill 270 144 250 270 146 250 minecraft:sea_lantern
fill 270 144 254 270 146 254 minecraft:sea_lantern
fill 271 144 229 271 145 229 minecraft:cyan_terracotta
fill 271 144 237 271 145 237 minecraft:cyan_terracotta
fill 271 144 243 271 145 243 minecraft:light_gray_concrete
fill 271 144 245 271 145 245 minecraft:light_gray_concrete
fill 271 144 247 271 145 247 minecraft:light_gray_concrete
fill 271 144 249 271 145 249 minecraft:light_gray_concrete
fill 271 144 255 272 145 255 minecraft:light_gray_concrete
fill 271 144 261 271 145 261 minecraft:light_gray_concrete
fill 271 144 269 271 145 269 minecraft:light_gray_concrete
fill 272 144 242 272 145 242 minecraft:light_gray_concrete
fill 273 144 229 273 145 229 minecraft:cyan_terracotta
fill 273 144 237 273 145 237 minecraft:cyan_terracotta
fill 273 144 261 273 145 261 minecraft:light_gray_concrete
fill 273 144 269 273 145 269 minecraft:light_gray_concrete
fill 274 144 242 274 145 242 minecraft:light_gray_concrete
fill 274 144 255 274 145 255 minecraft:light_gray_concrete
fill 275 144 229 275 145 229 minecraft:cyan_terracotta
fill 275 144 237 275 145 237 minecraft:cyan_terracotta
fill 275 144 261 275 145 261 minecraft:light_gray_concrete
fill 275 144 269 275 145 269 minecraft:light_gray_concrete
setblock 275 144 270 minecraft:blue_concrete
setblock 276 144 228 minecraft:ochre_froglight
fill 276 144 230 276 145 230 minecraft:cyan_terracotta
fill 276 144 232 276 145 232 minecraft:cyan_terracotta
fill 276 144 234 276 145 234 minecraft:cyan_terracotta
fill 276 144 236 276 145 236 minecraft:cyan_terracotta
fill 276 144 243 276 145 243 minecraft:light_gray_concrete
fill 276 144 245 276 145 245 minecraft:light_gray_concrete
fill 276 144 247 276 145 247 minecraft:light_gray_concrete
fill 276 144 249 276 145 249 minecraft:light_gray_concrete
fill 276 144 251 276 145 251 minecraft:light_gray_concrete
fill 276 144 253 276 145 253 minecraft:light_gray_concrete
fill 276 144 262 276 145 262 minecraft:light_gray_concrete
fill 276 144 264 276 145 264 minecraft:light_gray_concrete
fill 276 144 266 276 145 266 minecraft:light_gray_concrete
fill 276 144 268 276 145 268 minecraft:light_gray_concrete
setblock 277 144 241 minecraft:sea_lantern
setblock 277 144 266 minecraft:cyan_concrete
setblock 235 145 245 minecraft:cyan_concrete
setblock 235 145 269 minecraft:blue_concrete
fill 235 145 270 235 308 270 minecraft:black_concrete
setblock 238 145 238 minecraft:light[level=12]
setblock 238 145 259 minecraft:light[level=12]
fill 244 145 245 244 148 245 minecraft:verdant_froglight
fill 244 145 247 244 148 247 minecraft:verdant_froglight
fill 244 145 251 244 148 251 minecraft:verdant_froglight
setblock 245 145 231 minecraft:light[level=12]
setblock 245 145 238 minecraft:light[level=12]
setblock 245 145 245 minecraft:light[level=12]
setblock 245 145 252 minecraft:light[level=12]
setblock 245 145 259 minecraft:light[level=12]
setblock 245 145 266 minecraft:light[level=12]
setblock 250 145 237 minecraft:pearlescent_froglight
fill 250 145 248 251 145 248 minecraft:cyan_stained_glass
fill 250 145 251 250 147 253 minecraft:cyan_stained_glass
fill 250 145 256 251 145 256 minecraft:cyan_stained_glass
setblock 252 145 238 minecraft:light[level=12]
fill 252 145 246 252 147 246 minecraft:cyan_stained_glass
setblock 252 145 252 minecraft:light[level=12]
fill 252 145 258 252 147 258 minecraft:cyan_stained_glass
fill 253 145 245 253 147 245 minecraft:cyan_stained_glass
fill 253 145 259 253 147 259 minecraft:cyan_stained_glass
fill 254 145 244 254 147 244 minecraft:cyan_stained_glass
fill 254 145 260 254 147 260 minecraft:cyan_stained_glass
fill 254 145 261 254 148 261 minecraft:pearlescent_froglight
fill 256 145 242 256 145 243 minecraft:cyan_stained_glass
fill 256 145 261 256 145 262 minecraft:cyan_stained_glass
fill 257 145 242 257 146 242 minecraft:cyan_stained_glass
fill 257 145 262 257 146 262 minecraft:cyan_stained_glass
setblock 259 145 238 minecraft:light[level=12]
fill 259 145 242 261 147 242 minecraft:cyan_stained_glass
setblock 259 145 245 minecraft:light[level=12]
setblock 259 145 252 minecraft:light[level=12]
setblock 259 145 259 minecraft:light[level=12]
fill 259 145 262 261 147 262 minecraft:cyan_stained_glass
setblock 260 145 228 minecraft:purple_concrete
fill 260 145 261 260 147 261 minecraft:pearlescent_froglight
fill 261 145 228 261 230 228 minecraft:black_concrete
fill 262 145 261 262 147 261 minecraft:pearlescent_froglight
fill 264 145 242 264 145 243 minecraft:cyan_stained_glass
fill 264 145 261 264 145 262 minecraft:cyan_stained_glass
setblock 266 145 231 minecraft:light[level=12]
setblock 266 145 238 minecraft:light[level=12]
fill 266 145 244 266 147 244 minecraft:cyan_stained_glass
setblock 266 145 245 minecraft:light[level=12]
setblock 266 145 252 minecraft:light[level=12]
setblock 266 145 259 minecraft:light[level=12]
fill 266 145 260 266 147 260 minecraft:cyan_stained_glass
setblock 266 145 266 minecraft:light[level=12]
fill 267 145 245 267 147 245 minecraft:cyan_stained_glass
fill 267 145 259 267 147 259 minecraft:cyan_stained_glass
fill 268 145 246 268 147 246 minecraft:cyan_stained_glass
fill 268 145 249 268 148 249 minecraft:verdant_froglight
fill 268 145 253 268 147 253 minecraft:verdant_froglight
fill 268 145 255 268 147 255 minecraft:verdant_froglight
fill 268 145 258 268 147 258 minecraft:cyan_stained_glass
fill 269 145 248 270 145 248 minecraft:cyan_stained_glass
fill 269 145 256 270 145 256 minecraft:cyan_stained_glass
setblock 269 145 270 minecraft:magenta_concrete
fill 270 145 249 270 146 249 minecraft:cyan_stained_glass
fill 270 145 251 270 147 253 minecraft:cyan_stained_glass
fill 270 145 255 270 146 255 minecraft:cyan_stained_glass
fill 271 145 250 271 145 254 minecraft:light_gray_concrete
setblock 273 145 238 minecraft:light[level=12]
setblock 273 145 259 minecraft:light[level=12]
fill 275 145 270 275 200 270 minecraft:black_concrete
fill 276 145 228 276 201 228 minecraft:black_concrete
fill 277 145 241 277 210 241 minecraft:black_concrete
fill 277 145 266 277 189 266 minecraft:black_concrete
setblock 235 146 239 minecraft:cyan_concrete
fill 235 146 245 235 167 245 minecraft:black_concrete
fill 235 146 269 235 177 269 minecraft:black_concrete
setblock 236 146 230 minecraft:light_blue_stained_glass
setblock 236 146 232 minecraft:ochre_froglight
setblock 236 146 234 minecraft:pearlescent_froglight
setblock 236 146 236 minecraft:sea_lantern
setblock 236 146 243 minecraft:sea_lantern
setblock 236 146 245 minecraft:black_stained_glass
setblock 236 146 247 minecraft:ochre_froglight
setblock 236 146 249 minecraft:black_stained_glass
setblock 236 146 251 minecraft:black_stained_glass
setblock 236 146 253 minecraft:black_stained_glass
setblock 236 146 262 minecraft:cyan_stained_glass
setblock 236 146 264 minecraft:black_stained_glass
fill 236 146 265 239 146 265 minecraft:cyan_terracotta
setblock 236 146 266 minecraft:light_blue_stained_glass
setblock 236 146 268 minecraft:black_stained_glass
setblock 237 146 229 minecraft:light_blue_stained_glass
setblock 237 146 237 minecraft:sea_lantern
setblock 237 146 242 minecraft:magenta_stained_glass
setblock 237 146 255 minecraft:magenta_stained_glass
setblock 237 146 261 minecraft:sea_lantern
setblock 237 146 269 minecraft:pearlescent_froglight
setblock 239 146 229 minecraft:pearlescent_froglight
setblock 239 146 237 minecraft:cyan_stained_glass
setblock 239 146 242 minecraft:pearlescent_froglight
setblock 239 146 255 minecraft:cyan_stained_glass
setblock 239 146 261 minecraft:light_blue_stained_glass
setblock 239 146 269 minecraft:black_stained_glass
fill 240 146 265 243 147 265 minecraft:sea_lantern
setblock 241 146 229 minecraft:light_blue_stained_glass
setblock 241 146 237 minecraft:black_stained_glass
setblock 241 146 243 minecraft:magenta_stained_glass
setblock 241 146 245 minecraft:cyan_stained_glass
setblock 241 146 247 minecraft:sea_lantern
setblock 241 146 249 minecraft:black_stained_glass
setblock 241 146 251 minecraft:black_stained_glass
setblock 241 146 253 minecraft:black_stained_glass
setblock 241 146 261 minecraft:black_stained_glass
setblock 241 146 269 minecraft:sea_lantern
setblock 243 146 229 minecraft:ochre_froglight
setblock 243 146 237 minecraft:magenta_stained_glass
setblock 243 146 261 minecraft:ochre_froglight
setblock 243 146 269 minecraft:black_stained_glass
setblock 244 146 230 minecraft:ochre_froglight
setblock 244 146 232 minecraft:magenta_stained_glass
setblock 244 146 234 minecraft:black_stained_glass
setblock 244 146 236 minecraft:black_stained_glass
setblock 244 146 262 minecraft:black_stained_glass
setblock 244 146 264 minecraft:magenta_stained_glass
setblock 244 146 265 minecraft:cyan_terracotta
setblock 244 146 266 minecraft:magenta_stained_glass
setblock 244 146 268 minecraft:sea_lantern
fill 247 146 266 253 147 266 minecraft:sea_lantern
setblock 249 146 230 minecraft:sea_lantern
setblock 249 146 232 minecraft:black_stained_glass
setblock 249 146 265 minecraft:magenta_stained_glass
setblock 249 146 267 minecraft:magenta_stained_glass
setblock 250 146 229 minecraft:ochre_froglight
setblock 250 146 234 minecraft:black_stained_glass
setblock 250 146 264 minecraft:black_stained_glass
setblock 250 146 269 minecraft:light_blue_stained_glass
setblock 251 146 237 minecraft:pearlescent_froglight
fill 251 146 248 251 147 249 minecraft:cyan_stained_glass
fill 251 146 255 251 147 256 minecraft:cyan_stained_glass
setblock 252 146 229 minecraft:black_stained_glass
setblock 252 146 234 minecraft:cyan_stained_glass
fill 252 146 247 252 148 247 minecraft:sea_lantern
fill 252 146 257 252 148 257 minecraft:sea_lantern
setblock 252 146 264 minecraft:black_stained_glass
setblock 252 146 269 minecraft:black_stained_glass
setblock 253 146 261 minecraft:pearlescent_froglight
setblock 254 146 229 minecraft:black_stained_glass
setblock 254 146 234 minecraft:pearlescent_froglight
fill 254 146 237 255 146 237 minecraft:pearlescent_froglight
setblock 254 146 264 minecraft:pearlescent_froglight
fill 254 146 266 257 146 266 minecraft:cyan_terracotta
setblock 254 146 269 minecraft:black_stained_glass
fill 255 146 244 255 148 244 minecraft:sea_lantern
fill 255 146 260 255 148 260 minecraft:sea_lantern
setblock 256 146 229 minecraft:cyan_stained_glass
setblock 256 146 234 minecraft:cyan_stained_glass
fill 256 146 243 257 147 243 minecraft:cyan_stained_glass
setblock 256 146 261 minecraft:cyan_stained_glass
setblock 256 146 264 minecraft:sea_lantern
setblock 256 146 269 minecraft:magenta_stained_glass
setblock 257 146 261 minecraft:pearlescent_froglight
setblock 258 146 229 minecraft:light_blue_stained_glass
setblock 258 146 234 minecraft:light_blue_stained_glass
fill 258 146 237 260 146 237 minecraft:pearlescent_froglight
setblock 258 146 264 minecraft:black_stained_glass
fill 258 146 266 264 147 266 minecraft:sea_lantern
setblock 258 146 269 minecraft:magenta_stained_glass
fill 260 146 228 260 172 228 minecraft:black_concrete
setblock 260 146 229 minecraft:black_stained_glass
setblock 260 146 234 minecraft:black_stained_glass
setblock 260 146 264 minecraft:black_stained_glass
setblock 260 146 269 minecraft:black_stained_glass
setblock 262 146 230 minecraft:ochre_froglight
setblock 262 146 232 minecraft:ochre_froglight
setblock 262 146 265 minecraft:ochre_froglight
setblock 262 146 267 minecraft:black_stained_glass
fill 263 146 243 264 147 243 minecraft:cyan_stained_glass
fill 263 146 261 264 147 261 minecraft:cyan_stained_glass
fill 265 146 244 265 148 244 minecraft:sea_lantern
fill 265 146 260 265 148 260 minecraft:sea_lantern
setblock 268 146 230 minecraft:cyan_stained_glass
setblock 268 146 232 minecraft:black_stained_glass
setblock 268 146 234 minecraft:ochre_froglight
setblock 268 146 236 minecraft:pearlescent_froglight
setblock 268 146 250 minecraft:verdant_froglight
fill 268 146 257 268 148 257 minecraft:sea_lantern
setblock 268 146 262 minecraft:black_stained_glass
setblock 268 146 264 minecraft:black_stained_glass
setblock 268 146 265 minecraft:light_gray_concrete
setblock 268 146 266 minecraft:black_stained_glass
setblock 268 146 268 minecraft:sea_lantern
setblock 269 146 229 minecraft:sea_lantern
setblock 269 146 237 minecraft:light_blue_stained_glass
fill 269 146 248 269 147 249 minecraft:cyan_stained_glass
fill 269 146 255 269 147 256 minecraft:cyan_stained_glass
setblock 269 146 261 minecraft:magenta_stained_glass
fill 269 146 265 272 147 265 minecraft:sea_lantern
setblock 269 146 269 minecraft:pearlescent_froglight
fill 269 146 270 269 191 270 minecraft:black_concrete
setblock 271 146 229 minecraft:black_stained_glass
setblock 271 146 237 minecraft:magenta_stained_glass
setblock 271 146 243 minecraft:black_stained_glass
setblock 271 146 245 minecraft:sea_lantern
setblock 271 146 247 minecraft:black_stained_glass
setblock 271 146 249 minecraft:black_stained_glass
fill 271 146 250 271 222 250 minecraft:light_gray_concrete
setblock 271 146 251 minecraft:black_stained_glass
fill 271 146 252 271 222 252 minecraft:light_gray_concrete
setblock 271 146 253 minecraft:black_stained_glass
fill 271 146 254 271 222 255 minecraft:light_gray_concrete
setblock 271 146 261 minecraft:pearlescent_froglight
setblock 271 146 269 minecraft:black_stained_glass
setblock 272 146 242 minecraft:black_stained_glass
setblock 272 146 255 minecraft:black_stained_glass
setblock 273 146 229 minecraft:light_blue_stained_glass
setblock 273 146 237 minecraft:black_stained_glass
setblock 273 146 261 minecraft:black_stained_glass
setblock 273 146 269 minecraft:cyan_stained_glass
setblock 274 146 242 minecraft:black_stained_glass
setblock 274 146 255 minecraft:black_stained_glass
setblock 275 146 229 minecraft:black_stained_glass
setblock 275 146 237 minecraft:light_blue_stained_glass
setblock 275 146 261 minecraft:light_blue_stained_glass
setblock 275 146 269 minecraft:ochre_froglight
setblock 276 146 230 minecraft:black_stained_glass
setblock 276 146 232 minecraft:sea_lantern
setblock 276 146 234 minecraft:black_stained_glass
setblock 276 146 236 minecraft:sea_lantern
setblock 276 146 243 minecraft:black_stained_glass
setblock 276 146 245 minecraft:magenta_stained_glass
setblock 276 146 247 minecraft:black_stained_glass
setblock 276 146 249 minecraft:sea_lantern
setblock 276 146 251 minecraft:magenta_stained_glass
setblock 276 146 253 minecraft:black_stained_glass
setblock 276 146 262 minecraft:sea_lantern
setblock 276 146 264 minecraft:magenta_stained_glass
setblock 276 146 266 minecraft:pearlescent_froglight
setblock 276 146 268 minecraft:black_stained_glass
fill 235 147 239 235 222 239 minecraft:black_concrete
setblock 235 147 268 minecraft:ochre_froglight
fill 236 147 230 236 148 230 minecraft:light_gray_concrete
fill 236 147 232 236 148 232 minecraft:light_gray_concrete
fill 236 147 234 236 148 234 minecraft:light_gray_concrete
fill 236 147 236 236 148 236 minecraft:light_gray_concrete
fill 236 147 243 236 148 243 minecraft:light_gray_concrete
fill 236 147 245 236 148 245 minecraft:light_gray_concrete
fill 236 147 247 236 148 247 minecraft:light_gray_concrete
fill 236 147 249 236 148 249 minecraft:light_gray_concrete
fill 236 147 251 236 148 251 minecraft:light_gray_concrete
fill 236 147 253 236 148 253 minecraft:light_gray_concrete
fill 236 147 262 236 148 262 minecraft:cyan_terracotta
fill 236 147 264 238 148 266 minecraft:cyan_terracotta
fill 236 147 268 236 148 268 minecraft:cyan_terracotta
fill 237 147 229 237 148 229 minecraft:light_gray_concrete
fill 237 147 237 237 148 237 minecraft:light_gray_concrete
fill 237 147 242 237 148 242 minecraft:light_gray_concrete
fill 237 147 255 237 148 255 minecraft:light_gray_concrete
fill 237 147 261 237 148 261 minecraft:cyan_terracotta
fill 237 147 269 237 148 269 minecraft:cyan_terracotta
fill 239 147 229 239 148 229 minecraft:light_gray_concrete
fill 239 147 237 239 148 237 minecraft:light_gray_concrete
fill 239 147 242 239 148 242 minecraft:light_gray_concrete
fill 239 147 255 239 148 255 minecraft:light_gray_concrete
fill 239 147 261 239 148 261 minecraft:cyan_terracotta
fill 239 147 264 239 169 264 minecraft:cyan_terracotta
fill 239 147 265 239 148 265 minecraft:light_blue_stained_glass
fill 239 147 266 239 198 266 minecraft:cyan_terracotta
fill 239 147 269 239 148 269 minecraft:cyan_terracotta
fill 240 147 264 242 148 264 minecraft:light_blue_stained_glass
fill 240 147 266 246 148 266 minecraft:light_blue_stained_glass
fill 241 147 229 241 148 229 minecraft:light_gray_concrete
fill 241 147 237 241 148 237 minecraft:light_gray_concrete
fill 241 147 243 241 148 243 minecraft:light_gray_concrete
fill 241 147 245 241 148 245 minecraft:light_gray_concrete
fill 241 147 247 241 148 247 minecraft:light_gray_concrete
fill 241 147 249 241 148 249 minecraft:light_gray_concrete
fill 241 147 251 241 148 251 minecraft:light_gray_concrete
fill 241 147 253 241 148 253 minecraft:light_gray_concrete
fill 241 147 261 241 148 261 minecraft:cyan_terracotta
fill 241 147 269 241 148 269 minecraft:cyan_terracotta
fill 243 147 229 243 148 229 minecraft:light_gray_concrete
fill 243 147 237 243 148 237 minecraft:light_gray_concrete
fill 243 147 261 243 148 261 minecraft:cyan_terracotta
fill 243 147 264 244 148 264 minecraft:cyan_terracotta
fill 243 147 269 243 148 269 minecraft:cyan_terracotta
fill 244 147 230 244 148 230 minecraft:light_gray_concrete
fill 244 147 232 244 148 232 minecraft:light_gray_concrete
fill 244 147 234 244 148 234 minecraft:light_gray_concrete
fill 244 147 236 244 148 236 minecraft:light_gray_concrete
fill 244 147 262 244 148 262 minecraft:cyan_terracotta
fill 244 147 265 252 148 265 minecraft:light_blue_stained_glass
fill 244 147 268 244 148 268 minecraft:cyan_terracotta
fill 249 147 230 249 148 230 minecraft:light_gray_concrete
fill 249 147 232 249 148 232 minecraft:light_gray_concrete
fill 249 147 267 263 148 267 minecraft:light_blue_stained_glass
fill 250 147 229 250 148 229 minecraft:light_gray_concrete
fill 250 147 234 250 148 234 minecraft:light_gray_concrete
fill 250 147 264 250 148 264 minecraft:cyan_terracotta
fill 250 147 268 250 148 269 minecraft:cyan_terracotta
fill 251 147 250 251 148 250 minecraft:sea_lantern
fill 251 147 251 251 148 253 minecraft:cyan_stained_glass
fill 251 147 254 251 148 254 minecraft:sea_lantern
fill 251 147 268 261 154 268 minecraft:cyan_terracotta
fill 252 147 229 252 148 229 minecraft:light_gray_concrete
fill 252 147 234 252 148 234 minecraft:light_gray_concrete
setblock 252 147 237 minecraft:pearlescent_froglight
fill 252 147 248 252 148 248 minecraft:cyan_stained_glass
fill 252 147 256 252 148 256 minecraft:cyan_stained_glass
fill 252 147 264 252 148 264 minecraft:cyan_terracotta
fill 252 147 269 252 148 269 minecraft:cyan_terracotta
fill 253 147 246 253 148 246 minecraft:cyan_stained_glass
fill 253 147 258 253 148 258 minecraft:cyan_stained_glass
fill 253 147 265 258 154 265 minecraft:cyan_terracotta
fill 254 147 229 254 148 229 minecraft:light_gray_concrete
fill 254 147 234 254 148 234 minecraft:light_gray_concrete
fill 254 147 237 254 148 237 minecraft:pearlescent_froglight
fill 254 147 245 254 148 245 minecraft:cyan_stained_glass
fill 254 147 259 254 148 259 minecraft:cyan_stained_glass
fill 254 147 264 254 148 264 minecraft:cyan_terracotta
fill 254 147 266 257 148 266 minecraft:light_blue_stained_glass
fill 254 147 269 254 148 269 minecraft:cyan_terracotta
fill 256 147 229 256 148 229 minecraft:light_gray_concrete
fill 256 147 234 256 148 234 minecraft:light_gray_concrete
fill 256 147 244 256 148 244 minecraft:cyan_stained_glass
fill 256 147 260 256 148 260 minecraft:cyan_stained_glass
setblock 256 147 261 minecraft:pearlescent_froglight
fill 256 147 264 256 148 264 minecraft:cyan_terracotta
fill 256 147 269 256 148 269 minecraft:cyan_terracotta
setblock 257 147 261 minecraft:cyan_stained_glass
fill 258 147 229 258 148 229 minecraft:light_gray_concrete
fill 258 147 234 258 148 234 minecraft:light_gray_concrete
fill 258 147 243 258 148 243 minecraft:sea_lantern
fill 258 147 264 258 148 264 minecraft:cyan_terracotta
fill 258 147 269 258 148 269 minecraft:cyan_terracotta
fill 259 147 243 261 148 243 minecraft:cyan_stained_glass
fill 259 147 261 259 148 261 minecraft:cyan_stained_glass
fill 259 147 265 268 148 265 minecraft:light_blue_stained_glass
fill 260 147 229 260 148 229 minecraft:light_gray_concrete
fill 260 147 234 260 148 234 minecraft:light_gray_concrete
fill 260 147 264 260 148 264 minecraft:cyan_terracotta
fill 260 147 269 260 148 269 minecraft:cyan_terracotta
setblock 261 147 261 minecraft:cyan_stained_glass
fill 262 147 230 262 148 230 minecraft:light_gray_concrete
fill 262 147 232 262 148 232 minecraft:light_gray_concrete
fill 262 147 243 262 148 243 minecraft:sea_lantern
fill 264 147 237 264 148 237 minecraft:pearlescent_froglight
fill 264 147 244 264 148 244 minecraft:cyan_stained_glass
fill 264 147 260 264 148 260 minecraft:cyan_stained_glass
fill 265 147 266 272 148 266 minecraft:light_blue_stained_glass
fill 266 147 245 266 148 245 minecraft:cyan_stained_glass
fill 266 147 259 266 148 259 minecraft:cyan_stained_glass
fill 267 147 246 267 148 246 minecraft:cyan_stained_glass
fill 267 147 258 267 148 258 minecraft:cyan_stained_glass
fill 268 147 230 268 148 230 minecraft:cyan_terracotta
fill 268 147 232 268 148 232 minecraft:cyan_terracotta
fill 268 147 234 268 148 234 minecraft:cyan_terracotta
fill 268 147 236 268 148 236 minecraft:cyan_terracotta
fill 268 147 248 268 148 248 minecraft:cyan_stained_glass
fill 268 147 256 268 148 256 minecraft:cyan_stained_glass
fill 268 147 262 268 148 262 minecraft:light_gray_concrete
fill 268 147 264 269 148 264 minecraft:light_gray_concrete
fill 268 147 268 268 148 268 minecraft:light_gray_concrete
fill 269 147 229 269 148 229 minecraft:cyan_terracotta
fill 269 147 237 269 148 237 minecraft:cyan_terracotta
fill 269 147 250 269 148 250 minecraft:sea_lantern
fill 269 147 251 269 148 253 minecraft:cyan_stained_glass
fill 269 147 254 269 148 254 minecraft:sea_lantern
fill 269 147 261 269 148 261 minecraft:light_gray_concrete
fill 269 147 269 269 148 269 minecraft:light_gray_concrete
fill 270 147 264 272 148 264 minecraft:light_blue_stained_glass
fill 271 147 229 271 148 229 minecraft:cyan_terracotta
fill 271 147 237 271 148 237 minecraft:cyan_terracotta
fill 271 147 243 271 148 243 minecraft:light_gray_concrete
fill 271 147 245 271 148 245 minecraft:light_gray_concrete
fill 271 147 247 271 148 247 minecraft:light_gray_concrete
fill 271 147 249 271 148 249 minecraft:light_gray_concrete
fill 271 147 251 271 148 251 minecraft:light_gray_concrete
fill 271 147 253 271 148 253 minecraft:light_gray_concrete
fill 271 147 261 271 148 261 minecraft:light_gray_concrete
fill 271 147 269 271 148 269 minecraft:light_gray_concrete
fill 272 147 242 272 148 242 minecraft:light_gray_concrete
fill 272 147 255 272 148 255 minecraft:light_gray_concrete
fill 273 147 229 273 148 229 minecraft:cyan_terracotta
fill 273 147 237 273 148 237 minecraft:cyan_terracotta
fill 273 147 261 273 148 261 minecraft:light_gray_concrete
fill 273 147 264 276 148 264 minecraft:light_gray_concrete
fill 273 147 265 273 148 265 minecraft:light_blue_stained_glass
fill 273 147 266 273 148 269 minecraft:light_gray_concrete
fill 274 147 242 274 148 242 minecraft:light_gray_concrete
fill 274 147 255 274 148 255 minecraft:light_gray_concrete
fill 274 147 265 275 237 268 minecraft:light_gray_concrete
fill 275 147 229 275 148 229 minecraft:cyan_terracotta
fill 275 147 237 275 148 237 minecraft:cyan_terracotta
fill 275 147 261 275 148 261 minecraft:light_gray_concrete
fill 275 147 269 275 148 269 minecraft:light_gray_concrete
fill 276 147 230 276 148 230 minecraft:cyan_terracotta
fill 276 147 232 276 148 232 minecraft:cyan_terracotta
fill 276 147 234 276 148 234 minecraft:cyan_terracotta
fill 276 147 236 276 148 236 minecraft:cyan_terracotta
fill 276 147 243 276 148 243 minecraft:light_gray_concrete
fill 276 147 245 276 148 245 minecraft:light_gray_concrete
fill 276 147 247 276 148 247 minecraft:light_gray_concrete
fill 276 147 249 276 148 249 minecraft:light_gray_concrete
fill 276 147 251 276 148 251 minecraft:light_gray_concrete
fill 276 147 253 276 148 253 minecraft:light_gray_concrete
fill 276 147 262 276 148 262 minecraft:light_gray_concrete
fill 276 147 266 276 148 266 minecraft:light_gray_concrete
fill 276 147 268 276 148 268 minecraft:light_gray_concrete
fill 235 148 268 235 246 268 minecraft:black_concrete
fill 240 148 265 243 148 265 minecraft:light_blue_stained_glass
fill 247 148 266 253 148 266 minecraft:light_blue_stained_glass
setblock 249 148 261 minecraft:pearlescent_froglight
fill 250 148 237 251 148 237 minecraft:pearlescent_froglight
fill 251 148 249 252 148 249 minecraft:cyan_stained_glass
fill 251 148 255 252 148 255 minecraft:cyan_stained_glass
fill 252 148 250 252 150 250 minecraft:cyan_stained_glass
fill 252 148 254 252 150 254 minecraft:cyan_stained_glass
fill 252 148 261 253 148 261 minecraft:pearlescent_froglight
fill 253 148 247 253 149 247 minecraft:sea_lantern
fill 253 148 257 253 149 257 minecraft:sea_lantern
fill 254 148 246 254 150 246 minecraft:cyan_stained_glass
fill 254 148 258 254 150 258 minecraft:cyan_stained_glass
setblock 254 148 270 minecraft:sea_lantern
fill 255 148 245 255 149 245 minecraft:sea_lantern
fill 255 148 259 255 149 259 minecraft:sea_lantern
fill 257 148 243 257 148 244 minecraft:cyan_stained_glass
fill 257 148 260 258 150 260 minecraft:cyan_stained_glass
setblock 257 148 261 minecraft:pearlescent_froglight
fill 258 148 244 258 150 244 minecraft:cyan_stained_glass
fill 258 148 266 264 148 266 minecraft:light_blue_stained_glass
setblock 260 148 261 minecraft:cyan_stained_glass
setblock 261 148 261 minecraft:pearlescent_froglight
fill 262 148 237 263 148 237 minecraft:pearlescent_froglight
fill 262 148 244 263 150 244 minecraft:cyan_stained_glass
fill 262 148 260 263 150 260 minecraft:cyan_stained_glass
setblock 262 148 261 minecraft:sea_lantern
setblock 263 148 243 minecraft:cyan_stained_glass
setblock 263 148 261 minecraft:cyan_stained_glass
fill 265 148 245 265 149 245 minecraft:sea_lantern
fill 265 148 259 265 149 259 minecraft:sea_lantern
fill 266 148 246 266 150 246 minecraft:cyan_stained_glass
fill 266 148 258 266 150 258 minecraft:cyan_stained_glass
fill 267 148 247 268 148 247 minecraft:sea_lantern
fill 267 148 257 267 149 257 minecraft:sea_lantern
setblock 268 148 246 minecraft:verdant_froglight
fill 268 148 250 268 148 251 minecraft:verdant_froglight
setblock 268 148 254 minecraft:verdant_froglight
fill 268 148 255 269 148 255 minecraft:cyan_stained_glass
setblock 269 148 249 minecraft:cyan_stained_glass
fill 269 148 265 272 148 265 minecraft:light_blue_stained_glass
setblock 277 148 237 minecraft:sea_lantern
setblock 235 149 230 minecraft:magenta_concrete
setblock 236 149 230 minecraft:pearlescent_froglight
setblock 236 149 232 minecraft:ochre_froglight
setblock 236 149 234 minecraft:black_stained_glass
setblock 236 149 236 minecraft:ochre_froglight
setblock 236 149 243 minecraft:ochre_froglight
setblock 236 149 245 minecraft:black_stained_glass
setblock 236 149 247 minecraft:cyan_stained_glass
setblock 236 149 249 minecraft:cyan_stained_glass
setblock 236 149 251 minecraft:pearlescent_froglight
setblock 236 149 253 minecraft:ochre_froglight
setblock 236 149 262 minecraft:black_stained_glass
setblock 236 149 264 minecraft:ochre_froglight
fill 236 149 265 244 168 265 minecraft:cyan_terracotta
setblock 236 149 266 minecraft:black_stained_glass
setblock 236 149 268 minecraft:black_stained_glass
setblock 237 149 229 minecraft:cyan_stained_glass
setblock 237 149 237 minecraft:light_blue_stained_glass
setblock 237 149 242 minecraft:magenta_stained_glass
setblock 237 149 255 minecraft:black_stained_glass
setblock 237 149 261 minecraft:sea_lantern
fill 237 149 264 238 198 264 minecraft:cyan_terracotta
fill 237 149 266 238 198 266 minecraft:cyan_terracotta
setblock 237 149 269 minecraft:cyan_stained_glass
setblock 238 149 270 minecraft:cyan_concrete
setblock 239 149 229 minecraft:black_stained_glass
setblock 239 149 237 minecraft:ochre_froglight
setblock 239 149 242 minecraft:magenta_stained_glass
setblock 239 149 255 minecraft:sea_lantern
setblock 239 149 261 minecraft:light_blue_stained_glass
setblock 239 149 269 minecraft:black_stained_glass
fill 240 149 264 243 168 264 minecraft:cyan_terracotta
fill 240 149 266 243 169 266 minecraft:cyan_terracotta
setblock 241 149 229 minecraft:black_stained_glass
setblock 241 149 237 minecraft:cyan_stained_glass
setblock 241 149 243 minecraft:black_stained_glass
setblock 241 149 245 minecraft:magenta_stained_glass
setblock 241 149 247 minecraft:light_blue_stained_glass
setblock 241 149 249 minecraft:black_stained_glass
setblock 241 149 251 minecraft:ochre_froglight
setblock 241 149 253 minecraft:sea_lantern
setblock 241 149 261 minecraft:ochre_froglight
setblock 241 149 269 minecraft:black_stained_glass
setblock 243 149 229 minecraft:pearlescent_froglight
setblock 243 149 237 minecraft:ochre_froglight
setblock 243 149 261 minecraft:ochre_froglight
setblock 243 149 269 minecraft:black_stained_glass
setblock 244 149 230 minecraft:black_stained_glass
setblock 244 149 232 minecraft:black_stained_glass
setblock 244 149 234 minecraft:ochre_froglight
setblock 244 149 236 minecraft:black_stained_glass
setblock 244 149 262 minecraft:sea_lantern
setblock 244 149 264 minecraft:black_stained_glass
setblock 244 149 266 minecraft:pearlescent_froglight
setblock 244 149 268 minecraft:black_stained_glass
setblock 249 149 230 minecraft:ochre_froglight
setblock 249 149 232 minecraft:light_blue_stained_glass
setblock 249 149 265 minecraft:black_stained_glass
fill 249 149 266 262 154 266 minecraft:cyan_terracotta
setblock 249 149 267 minecraft:pearlescent_froglight
setblock 250 149 229 minecraft:pearlescent_froglight
setblock 250 149 234 minecraft:magenta_stained_glass
setblock 250 149 264 minecraft:light_blue_stained_glass
fill 250 149 265 252 154 265 minecraft:cyan_terracotta
fill 250 149 267 250 154 268 minecraft:cyan_terracotta
setblock 250 149 269 minecraft:pearlescent_froglight
fill 251 149 267 261 154 267 minecraft:cyan_terracotta
setblock 252 149 229 minecraft:pearlescent_froglight
setblock 252 149 234 minecraft:black_stained_glass
fill 252 149 249 253 150 249 minecraft:cyan_stained_glass
fill 252 149 251 252 150 253 minecraft:cyan_stained_glass
fill 252 149 255 253 150 255 minecraft:cyan_stained_glass
setblock 252 149 264 minecraft:pearlescent_froglight
setblock 252 149 269 minecraft:black_stained_glass
fill 253 149 248 253 150 248 minecraft:cyan_stained_glass
fill 253 149 250 253 150 250 minecraft:cyan_stained_glass
fill 253 149 254 253 150 254 minecraft:cyan_stained_glass
fill 253 149 256 253 150 256 minecraft:cyan_stained_glass
setblock 254 149 229 minecraft:magenta_stained_glass
setblock 254 149 234 minecraft:black_stained_glass
fill 254 149 247 254 150 247 minecraft:cyan_stained_glass
setblock 254 149 248 minecraft:sea_lantern
setblock 254 149 256 minecraft:sea_lantern
fill 254 149 257 254 150 257 minecraft:cyan_stained_glass
setblock 254 149 264 minecraft:black_stained_glass
setblock 254 149 269 minecraft:black_stained_glass
fill 254 149 270 254 170 270 minecraft:black_concrete
fill 255 149 246 255 150 246 minecraft:cyan_stained_glass
fill 255 149 258 255 150 258 minecraft:cyan_stained_glass
setblock 256 149 229 minecraft:ochre_froglight
setblock 256 149 234 minecraft:magenta_stained_glass
fill 256 149 245 258 150 245 minecraft:cyan_stained_glass
setblock 256 149 246 minecraft:sea_lantern
setblock 256 149 258 minecraft:sea_lantern
fill 256 149 259 258 150 259 minecraft:cyan_stained_glass
setblock 256 149 264 minecraft:black_stained_glass
setblock 256 149 269 minecraft:magenta_stained_glass
fill 257 149 244 257 150 244 minecraft:cyan_stained_glass
setblock 258 149 229 minecraft:black_stained_glass
setblock 258 149 234 minecraft:black_stained_glass
setblock 258 149 264 minecraft:light_blue_stained_glass
setblock 258 149 269 minecraft:pearlescent_froglight
fill 259 149 244 261 150 244 minecraft:cyan_stained_glass
fill 259 149 260 261 150 260 minecraft:cyan_stained_glass
fill 259 149 265 261 154 265 minecraft:cyan_terracotta
setblock 260 149 229 minecraft:black_stained_glass
setblock 260 149 234 minecraft:black_stained_glass
setblock 260 149 264 minecraft:magenta_stained_glass
setblock 260 149 269 minecraft:black_stained_glass
setblock 262 149 230 minecraft:black_stained_glass
setblock 262 149 232 minecraft:pearlescent_froglight
fill 262 149 245 264 150 245 minecraft:cyan_stained_glass
fill 262 149 259 264 150 259 minecraft:cyan_stained_glass
setblock 262 149 265 minecraft:magenta_stained_glass
setblock 262 149 267 minecraft:pearlescent_froglight
setblock 264 149 246 minecraft:sea_lantern
setblock 264 149 258 minecraft:sea_lantern
setblock 264 149 270 minecraft:blue_concrete
fill 265 149 246 265 150 246 minecraft:cyan_stained_glass
fill 265 149 258 265 150 258 minecraft:cyan_stained_glass
fill 266 149 247 266 150 247 minecraft:cyan_stained_glass
setblock 266 149 248 minecraft:sea_lantern
setblock 266 149 256 minecraft:sea_lantern
fill 266 149 257 266 150 257 minecraft:cyan_stained_glass
setblock 267 149 247 minecraft:sea_lantern
fill 267 149 248 267 150 250 minecraft:cyan_stained_glass
fill 267 149 254 267 150 256 minecraft:cyan_stained_glass
setblock 268 149 230 minecraft:sea_lantern
setblock 268 149 232 minecraft:black_stained_glass
setblock 268 149 234 minecraft:black_stained_glass
setblock 268 149 236 minecraft:black_stained_glass
fill 268 149 249 268 150 255 minecraft:cyan_stained_glass
setblock 268 149 262 minecraft:magenta_stained_glass
setblock 268 149 264 minecraft:black_stained_glass
fill 268 149 265 273 153 265 minecraft:light_gray_concrete
setblock 268 149 266 minecraft:black_stained_glass
setblock 268 149 268 minecraft:magenta_stained_glass
setblock 269 149 229 minecraft:cyan_stained_glass
setblock 269 149 237 minecraft:black_stained_glass
setblock 269 149 261 minecraft:pearlescent_froglight
fill 269 149 264 275 229 264 minecraft:light_gray_concrete
fill 269 149 266 273 230 266 minecraft:light_gray_concrete
setblock 269 149 269 minecraft:sea_lantern
setblock 271 149 229 minecraft:black_stained_glass
setblock 271 149 237 minecraft:sea_lantern
setblock 271 149 243 minecraft:cyan_stained_glass
setblock 271 149 245 minecraft:sea_lantern
setblock 271 149 247 minecraft:cyan_stained_glass
setblock 271 149 249 minecraft:light_blue_stained_glass
setblock 271 149 251 minecraft:sea_lantern
setblock 271 149 253 minecraft:magenta_stained_glass
setblock 271 149 261 minecraft:sea_lantern
setblock 271 149 269 minecraft:sea_lantern
setblock 272 149 242 minecraft:light_blue_stained_glass
setblock 272 149 255 minecraft:black_stained_glass
setblock 273 149 229 minecraft:ochre_froglight
setblock 273 149 237 minecraft:black_stained_glass
setblock 273 149 261 minecraft:light_blue_stained_glass
fill 273 149 267 273 237 268 minecraft:light_gray_concrete
setblock 273 149 269 minecraft:cyan_stained_glass
setblock 274 149 242 minecraft:black_stained_glass
setblock 274 149 255 minecraft:black_stained_glass
setblock 275 149 229 minecraft:light_blue_stained_glass
setblock 275 149 237 minecraft:black_stained_glass
setblock 275 149 261 minecraft:sea_lantern
setblock 275 149 269 minecraft:cyan_stained_glass
setblock 276 149 230 minecraft:pearlescent_froglight
setblock 276 149 232 minecraft:ochre_froglight
setblock 276 149 234 minecraft:pearlescent_froglight
setblock 276 149 236 minecraft:black_stained_glass
setblock 276 149 243 minecraft:magenta_stained_glass
setblock 276 149 245 minecraft:pearlescent_froglight
setblock 276 149 247 minecraft:sea_lantern
setblock 276 149 249 minecraft:black_stained_glass
setblock 276 149 251 minecraft:cyan_stained_glass
setblock 276 149 253 minecraft:pearlescent_froglight
setblock 276 149 262 minecraft:black_stained_glass
setblock 276 149 264 minecraft:black_stained_glass
setblock 276 149 266 minecraft:black_stained_glass
setblock 276 149 268 minecraft:black_stained_glass
fill 277 149 237 277 253 237 minecraft:black_concrete
fill 235 150 230 235 206 230 minecraft:black_concrete
setblock 235 150 240 minecraft:blue_concrete
fill 236 150 230 236 151 230 minecraft:light_gray_concrete
fill 236 150 232 236 151 232 minecraft:light_gray_concrete
fill 236 150 234 236 151 234 minecraft:light_gray_concrete
fill 236 150 236 236 151 236 minecraft:light_gray_concrete
fill 236 150 243 236 151 243 minecraft:light_gray_concrete
fill 236 150 245 236 151 245 minecraft:light_gray_concrete
fill 236 150 247 236 151 247 minecraft:light_gray_concrete
fill 236 150 249 236 151 249 minecraft:light_gray_concrete
fill 236 150 251 236 151 251 minecraft:light_gray_concrete
fill 236 150 253 236 151 253 minecraft:light_gray_concrete
fill 236 150 262 236 151 262 minecraft:cyan_terracotta
fill 236 150 264 236 151 264 minecraft:cyan_terracotta
fill 236 150 266 236 151 266 minecraft:cyan_terracotta
fill 236 150 268 236 151 268 minecraft:cyan_terracotta
fill 237 150 229 237 151 229 minecraft:light_gray_concrete
fill 237 150 237 237 151 237 minecraft:light_gray_concrete
fill 237 150 242 237 151 242 minecraft:light_gray_concrete
fill 237 150 255 237 151 255 minecraft:light_gray_concrete
fill 237 150 261 237 151 261 minecraft:cyan_terracotta
fill 237 150 269 237 151 269 minecraft:cyan_terracotta
setblock 238 150 239 minecraft:light[level=15]
fill 238 150 270 238 233 270 minecraft:black_concrete
fill 239 150 229 239 151 229 minecraft:light_gray_concrete
fill 239 150 237 239 151 237 minecraft:light_gray_concrete
fill 239 150 242 239 151 242 minecraft:light_gray_concrete
fill 239 150 255 239 151 255 minecraft:light_gray_concrete
fill 239 150 261 239 151 261 minecraft:cyan_terracotta
fill 239 150 269 239 151 269 minecraft:cyan_terracotta
fill 241 150 229 241 151 229 minecraft:light_gray_concrete
fill 241 150 237 241 151 237 minecraft:light_gray_concrete
fill 241 150 243 241 151 243 minecraft:light_gray_concrete
fill 241 150 245 241 151 245 minecraft:light_gray_concrete
fill 241 150 247 241 151 247 minecraft:light_gray_concrete
fill 241 150 249 241 151 249 minecraft:light_gray_concrete
fill 241 150 251 241 151 251 minecraft:light_gray_concrete
fill 241 150 253 241 151 253 minecraft:light_gray_concrete
fill 241 150 261 241 151 261 minecraft:cyan_terracotta
fill 241 150 269 241 151 269 minecraft:cyan_terracotta
fill 243 150 229 243 151 229 minecraft:light_gray_concrete
fill 243 150 237 243 151 237 minecraft:light_gray_concrete
fill 243 150 261 243 151 261 minecraft:cyan_terracotta
fill 243 150 269 243 151 269 minecraft:cyan_terracotta
fill 244 150 230 244 151 230 minecraft:light_gray_concrete
fill 244 150 232 244 151 232 minecraft:light_gray_concrete
fill 244 150 234 244 151 234 minecraft:light_gray_concrete
fill 244 150 236 244 151 236 minecraft:light_gray_concrete
fill 244 150 262 244 151 262 minecraft:cyan_terracotta
fill 244 150 264 244 151 264 minecraft:cyan_terracotta
fill 244 150 266 244 151 266 minecraft:cyan_terracotta
fill 244 150 268 244 151 268 minecraft:cyan_terracotta
setblock 246 150 231 minecraft:light[level=15]
setblock 246 150 239 minecraft:light[level=15]
setblock 246 150 247 minecraft:light[level=15]
setblock 246 150 255 minecraft:light[level=15]
setblock 246 150 263 minecraft:light[level=15]
fill 249 150 230 249 151 230 minecraft:light_gray_concrete
fill 249 150 232 249 151 232 minecraft:light_gray_concrete
fill 249 150 265 249 151 265 minecraft:cyan_terracotta
fill 249 150 267 249 151 267 minecraft:cyan_terracotta
fill 250 150 229 250 151 229 minecraft:light_gray_concrete
fill 250 150 234 250 151 234 minecraft:light_gray_concrete
fill 250 150 264 250 151 264 minecraft:cyan_terracotta
fill 250 150 269 250 151 269 minecraft:cyan_terracotta
fill 251 150 249 251 150 255 minecraft:cyan_stained_glass
fill 252 150 229 252 151 229 minecraft:light_gray_concrete
fill 252 150 234 252 151 234 minecraft:light_gray_concrete
fill 252 150 247 252 150 248 minecraft:cyan_stained_glass
fill 252 150 256 252 150 257 minecraft:cyan_stained_glass
fill 252 150 264 252 151 264 minecraft:cyan_terracotta
fill 252 150 269 252 151 269 minecraft:cyan_terracotta
fill 253 150 246 253 150 247 minecraft:cyan_stained_glass
fill 253 150 251 255 150 253 minecraft:cyan_stained_glass
fill 253 150 257 253 150 258 minecraft:cyan_stained_glass
fill 254 150 229 254 151 229 minecraft:light_gray_concrete
fill 254 150 234 254 151 234 minecraft:light_gray_concrete
setblock 254 150 239 minecraft:light[level=15]
fill 254 150 245 255 150 245 minecraft:cyan_stained_glass
fill 254 150 248 255 150 250 minecraft:cyan_stained_glass
fill 254 150 254 255 150 256 minecraft:cyan_stained_glass
fill 254 150 259 255 150 259 minecraft:cyan_stained_glass
setblock 254 150 263 minecraft:light[level=15]
fill 254 150 264 254 151 264 minecraft:cyan_terracotta
fill 254 150 269 254 151 269 minecraft:cyan_terracotta
fill 255 150 244 256 150 244 minecraft:cyan_stained_glass
fill 255 150 247 265 150 247 minecraft:cyan_stained_glass
fill 255 150 257 265 150 257 minecraft:cyan_stained_glass
fill 255 150 260 256 150 260 minecraft:cyan_stained_glass
fill 256 150 229 256 151 229 minecraft:light_gray_concrete
fill 256 150 234 256 151 234 minecraft:light_gray_concrete
fill 256 150 246 264 150 246 minecraft:cyan_stained_glass
fill 256 150 248 256 151 249 minecraft:cyan_stained_glass
fill 256 150 250 256 150 254 minecraft:sea_lantern
fill 256 150 255 256 151 256 minecraft:cyan_stained_glass
fill 256 150 258 264 150 258 minecraft:cyan_stained_glass
fill 256 150 264 256 151 264 minecraft:cyan_terracotta
fill 256 150 269 256 151 269 minecraft:cyan_terracotta
fill 257 150 243 263 150 243 minecraft:cyan_stained_glass
fill 257 150 248 257 151 248 minecraft:cyan_stained_glass
fill 257 150 249 257 150 250 minecraft:sea_lantern
fill 257 150 254 257 150 255 minecraft:sea_lantern
fill 257 150 256 257 151 256 minecraft:cyan_stained_glass
fill 257 150 261 263 150 261 minecraft:cyan_stained_glass
fill 258 150 229 258 151 229 minecraft:light_gray_concrete
fill 258 150 234 258 151 234 minecraft:light_gray_concrete
fill 258 150 248 258 150 249 minecraft:sea_lantern
fill 258 150 255 258 150 256 minecraft:sea_lantern
fill 258 150 264 258 151 264 minecraft:cyan_terracotta
fill 258 150 269 258 151 269 minecraft:cyan_terracotta
fill 259 150 245 261 150 245 minecraft:cyan_stained_glass
fill 259 150 248 262 150 248 minecraft:sea_lantern
fill 259 150 256 262 150 256 minecraft:sea_lantern
fill 259 150 259 261 150 259 minecraft:cyan_stained_glass
setblock 259 150 270 minecraft:cyan_concrete
fill 260 150 229 260 151 229 minecraft:light_gray_concrete
fill 260 150 234 260 151 234 minecraft:light_gray_concrete
fill 260 150 264 260 151 264 minecraft:cyan_terracotta
fill 260 150 269 260 151 269 minecraft:cyan_terracotta
setblock 261 150 270 minecraft:pearlescent_froglight
fill 262 150 230 262 151 230 minecraft:light_gray_concrete
fill 262 150 232 262 151 232 minecraft:light_gray_concrete
setblock 262 150 239 minecraft:light[level=15]
fill 262 150 249 263 150 249 minecraft:sea_lantern
fill 262 150 255 263 150 255 minecraft:sea_lantern
setblock 262 150 263 minecraft:light[level=15]
fill 262 150 265 262 151 265 minecraft:cyan_terracotta
fill 262 150 267 262 151 267 minecraft:cyan_terracotta
fill 263 150 248 266 150 248 minecraft:cyan_stained_glass
fill 263 150 250 264 150 250 minecraft:sea_lantern
fill 263 150 254 264 150 254 minecraft:sea_lantern
fill 263 150 256 266 150 256 minecraft:cyan_stained_glass
fill 264 150 244 265 150 244 minecraft:cyan_stained_glass
fill 264 150 249 266 150 249 minecraft:cyan_stained_glass
fill 264 150 251 264 150 253 minecraft:sea_lantern
fill 264 150 255 266 150 255 minecraft:cyan_stained_glass
fill 264 150 260 265 150 260 minecraft:cyan_stained_glass
fill 264 150 270 264 161 270 minecraft:black_concrete
fill 265 150 245 266 150 245 minecraft:cyan_stained_glass
fill 265 150 250 266 150 254 minecraft:cyan_stained_glass
fill 265 150 259 266 150 259 minecraft:cyan_stained_glass
setblock 266 150 270 minecraft:purple_concrete
fill 267 150 246 267 150 247 minecraft:cyan_stained_glass
fill 267 150 251 267 150 253 minecraft:cyan_stained_glass
fill 267 150 257 267 150 258 minecraft:cyan_stained_glass
fill 267 150 270 267 193 270 minecraft:black_concrete
fill 268 150 230 268 151 230 minecraft:cyan_terracotta
fill 268 150 232 268 151 232 minecraft:cyan_terracotta
fill 268 150 234 268 151 234 minecraft:cyan_terracotta
fill 268 150 236 268 151 236 minecraft:cyan_terracotta
fill 268 150 247 268 150 248 minecraft:cyan_stained_glass
fill 268 150 256 268 150 257 minecraft:cyan_stained_glass
fill 268 150 262 268 151 262 minecraft:light_gray_concrete
fill 268 150 264 268 151 264 minecraft:light_gray_concrete
fill 268 150 266 268 151 266 minecraft:light_gray_concrete
fill 268 150 268 268 151 268 minecraft:light_gray_concrete
fill 269 150 229 269 151 229 minecraft:cyan_terracotta
fill 269 150 237 269 151 237 minecraft:cyan_terracotta
fill 269 150 249 269 150 255 minecraft:cyan_stained_glass
fill 269 150 261 269 151 261 minecraft:light_gray_concrete
fill 269 150 269 269 151 269 minecraft:light_gray_concrete
setblock 270 150 239 minecraft:light[level=15]
setblock 270 150 247 minecraft:light[level=15]
setblock 270 150 255 minecraft:light[level=15]
fill 271 150 229 271 151 229 minecraft:cyan_terracotta
fill 271 150 237 271 151 237 minecraft:cyan_terracotta
fill 271 150 243 271 151 243 minecraft:light_gray_concrete
fill 271 150 245 271 151 245 minecraft:light_gray_concrete
fill 271 150 247 271 151 247 minecraft:light_gray_concrete
fill 271 150 249 271 151 249 minecraft:light_gray_concrete
fill 271 150 251 271 151 251 minecraft:light_gray_concrete
fill 271 150 253 271 151 253 minecraft:light_gray_concrete
fill 271 150 261 271 151 261 minecraft:light_gray_concrete
fill 271 150 269 271 151 269 minecraft:light_gray_concrete
fill 272 150 242 272 151 242 minecraft:light_gray_concrete
fill 272 150 255 272 151 255 minecraft:light_gray_concrete
fill 273 150 229 273 151 229 minecraft:cyan_terracotta
fill 273 150 237 273 151 237 minecraft:cyan_terracotta
fill 273 150 261 273 151 261 minecraft:light_gray_concrete
fill 273 150 269 273 151 269 minecraft:light_gray_concrete
fill 274 150 242 274 151 242 minecraft:light_gray_concrete
fill 274 150 255 274 151 255 minecraft:light_gray_concrete
fill 275 150 229 275 151 229 minecraft:cyan_terracotta
fill 275 150 237 275 151 237 minecraft:cyan_terracotta
fill 275 150 261 275 151 261 minecraft:light_gray_concrete
fill 275 150 269 275 151 269 minecraft:light_gray_concrete
fill 276 150 230 276 151 230 minecraft:cyan_terracotta
fill 276 150 232 276 151 232 minecraft:cyan_terracotta
fill 276 150 234 276 151 234 minecraft:cyan_terracotta
fill 276 150 236 276 151 236 minecraft:cyan_terracotta
fill 276 150 243 276 151 243 minecraft:light_gray_concrete
fill 276 150 245 276 151 245 minecraft:light_gray_concrete
fill 276 150 247 276 151 247 minecraft:light_gray_concrete
fill 276 150 249 276 151 249 minecraft:light_gray_concrete
fill 276 150 251 276 151 251 minecraft:light_gray_concrete
fill 276 150 253 276 151 253 minecraft:light_gray_concrete
fill 276 150 262 276 151 262 minecraft:light_gray_concrete
fill 276 150 264 276 151 264 minecraft:light_gray_concrete
fill 276 150 266 276 151 266 minecraft:light_gray_concrete
fill 276 150 268 276 151 268 minecraft:light_gray_concrete
fill 235 151 240 235 200 240 minecraft:black_concrete
setblock 236 151 270 minecraft:ochre_froglight
setblock 238 151 238 minecraft:light[level=12]
setblock 238 151 259 minecraft:light[level=12]
setblock 245 151 231 minecraft:light[level=12]
setblock 245 151 238 minecraft:light[level=12]
setblock 245 151 245 minecraft:light[level=12]
setblock 245 151 252 minecraft:light[level=12]
setblock 245 151 259 minecraft:light[level=12]
setblock 245 151 266 minecraft:light[level=12]
setblock 252 151 238 minecraft:light[level=12]
setblock 252 151 245 minecraft:light[level=12]
setblock 252 151 252 minecraft:light[level=12]
setblock 252 151 259 minecraft:light[level=12]
fill 254 151 250 256 151 250 minecraft:cyan_stained_glass
fill 254 151 251 255 151 251 minecraft:sea_lantern
fill 254 151 252 255 151 252 minecraft:cyan_stained_glass
fill 254 151 253 255 151 253 minecraft:sea_lantern
fill 254 151 254 256 151 254 minecraft:cyan_stained_glass
fill 255 151 248 255 151 249 minecraft:cyan_stained_glass
fill 255 151 255 255 151 256 minecraft:cyan_stained_glass
fill 256 151 247 258 151 247 minecraft:cyan_stained_glass
fill 256 151 257 258 151 257 minecraft:cyan_stained_glass
fill 257 151 249 257 152 249 minecraft:cyan_stained_glass
fill 257 151 255 257 152 255 minecraft:cyan_stained_glass
setblock 257 151 270 minecraft:pearlescent_froglight
setblock 258 151 246 minecraft:cyan_stained_glass
fill 258 151 248 258 152 248 minecraft:cyan_stained_glass
fill 258 151 256 258 152 256 minecraft:cyan_stained_glass
setblock 258 151 258 minecraft:cyan_stained_glass
setblock 259 151 238 minecraft:light[level=12]
setblock 259 151 245 minecraft:light[level=12]
fill 259 151 246 259 151 247 minecraft:sea_lantern
fill 259 151 257 259 151 258 minecraft:sea_lantern
setblock 259 151 259 minecraft:light[level=12]
fill 259 151 270 259 169 270 minecraft:black_concrete
fill 260 151 246 260 151 247 minecraft:cyan_stained_glass
fill 260 151 257 260 151 258 minecraft:cyan_stained_glass
fill 261 151 246 261 151 247 minecraft:sea_lantern
fill 261 151 257 261 151 258 minecraft:sea_lantern
fill 261 151 270 261 173 270 minecraft:black_concrete
fill 262 151 246 262 151 248 minecraft:cyan_stained_glass
fill 262 151 256 262 151 258 minecraft:cyan_stained_glass
fill 263 151 247 264 151 249 minecraft:cyan_stained_glass
fill 263 151 255 264 151 257 minecraft:cyan_stained_glass
fill 264 151 250 266 151 250 minecraft:cyan_stained_glass
fill 264 151 254 266 151 254 minecraft:cyan_stained_glass
fill 265 151 248 265 151 249 minecraft:cyan_stained_glass
fill 265 151 251 266 151 251 minecraft:sea_lantern
fill 265 151 252 266 151 252 minecraft:cyan_stained_glass
fill 265 151 253 266 151 253 minecraft:sea_lantern
fill 265 151 255 265 151 256 minecraft:cyan_stained_glass
setblock 266 151 231 minecraft:light[level=12]
setblock 266 151 238 minecraft:light[level=12]
setblock 266 151 245 minecraft:light[level=12]
setblock 266 151 259 minecraft:light[level=12]
setblock 266 151 266 minecraft:light[level=12]
fill 266 151 270 266 205 270 minecraft:black_concrete
setblock 273 151 238 minecraft:light[level=12]
setblock 273 151 259 minecraft:light[level=12]
setblock 277 151 244 minecraft:magenta_concrete
setblock 236 152 230 minecraft:pearlescent_froglight
setblock 236 152 232 minecraft:black_stained_glass
setblock 236 152 234 minecraft:pearlescent_froglight
setblock 236 152 236 minecraft:sea_lantern
setblock 236 152 243 minecraft:pearlescent_froglight
setblock 236 152 245 minecraft:ochre_froglight
setblock 236 152 247 minecraft:cyan_stained_glass
setblock 236 152 249 minecraft:magenta_stained_glass
setblock 236 152 251 minecraft:cyan_stained_glass
setblock 236 152 253 minecraft:black_stained_glass
setblock 236 152 262 minecraft:sea_lantern
setblock 236 152 264 minecraft:black_stained_glass
setblock 236 152 266 minecraft:light_blue_stained_glass
setblock 236 152 268 minecraft:cyan_stained_glass
fill 236 152 270 236 258 270 minecraft:black_concrete
setblock 237 152 229 minecraft:black_stained_glass
setblock 237 152 237 minecraft:cyan_stained_glass
setblock 237 152 242 minecraft:pearlescent_froglight
setblock 237 152 255 minecraft:black_stained_glass
setblock 237 152 261 minecraft:black_stained_glass
setblock 237 152 269 minecraft:light_blue_stained_glass
setblock 239 152 229 minecraft:pearlescent_froglight
setblock 239 152 237 minecraft:pearlescent_froglight
setblock 239 152 242 minecraft:black_stained_glass
setblock 239 152 255 minecraft:black_stained_glass
setblock 239 152 261 minecraft:cyan_stained_glass
setblock 239 152 269 minecraft:sea_lantern
setblock 241 152 229 minecraft:cyan_stained_glass
setblock 241 152 237 minecraft:ochre_froglight
setblock 241 152 243 minecraft:black_stained_glass
setblock 241 152 245 minecraft:black_stained_glass
setblock 241 152 247 minecraft:black_stained_glass
setblock 241 152 249 minecraft:cyan_stained_glass
setblock 241 152 251 minecraft:cyan_stained_glass
setblock 241 152 253 minecraft:black_stained_glass
setblock 241 152 261 minecraft:black_stained_glass
setblock 241 152 269 minecraft:black_stained_glass
setblock 243 152 229 minecraft:pearlescent_froglight
setblock 243 152 237 minecraft:black_stained_glass
setblock 243 152 261 minecraft:black_stained_glass
setblock 243 152 269 minecraft:black_stained_glass
setblock 244 152 230 minecraft:magenta_stained_glass
setblock 244 152 232 minecraft:light_blue_stained_glass
setblock 244 152 234 minecraft:ochre_froglight
setblock 244 152 236 minecraft:sea_lantern
setblock 244 152 262 minecraft:black_stained_glass
setblock 244 152 264 minecraft:sea_lantern
setblock 244 152 266 minecraft:black_stained_glass
setblock 244 152 268 minecraft:magenta_stained_glass
setblock 249 152 230 minecraft:sea_lantern
setblock 249 152 232 minecraft:sea_lantern
setblock 249 152 265 minecraft:sea_lantern
setblock 249 152 267 minecraft:black_stained_glass
setblock 250 152 229 minecraft:light_blue_stained_glass
setblock 250 152 234 minecraft:sea_lantern
setblock 250 152 264 minecraft:pearlescent_froglight
setblock 250 152 269 minecraft:cyan_stained_glass
setblock 252 152 229 minecraft:black_stained_glass
setblock 252 152 234 minecraft:magenta_stained_glass
setblock 252 152 264 minecraft:ochre_froglight
setblock 252 152 269 minecraft:magenta_stained_glass
setblock 253 152 228 minecraft:ochre_froglight
setblock 254 152 229 minecraft:pearlescent_froglight
setblock 254 152 234 minecraft:pearlescent_froglight
setblock 254 152 264 minecraft:black_stained_glass
setblock 254 152 269 minecraft:cyan_stained_glass
setblock 256 152 229 minecraft:pearlescent_froglight
setblock 256 152 234 minecraft:black_stained_glass
fill 256 152 250 256 152 254 minecraft:cyan_stained_glass
setblock 256 152 264 minecraft:black_stained_glass
setblock 256 152 269 minecraft:pearlescent_froglight
setblock 257 152 250 minecraft:sea_lantern
setblock 257 152 254 minecraft:sea_lantern
fill 257 152 270 257 159 270 minecraft:black_concrete
setblock 258 152 229 minecraft:black_stained_glass
setblock 258 152 234 minecraft:black_stained_glass
setblock 258 152 249 minecraft:sea_lantern
setblock 258 152 255 minecraft:sea_lantern
setblock 258 152 264 minecraft:black_stained_glass
setblock 258 152 269 minecraft:magenta_stained_glass
fill 259 152 248 262 152 248 minecraft:cyan_stained_glass
fill 259 152 256 262 152 256 minecraft:cyan_stained_glass
setblock 260 152 229 minecraft:ochre_froglight
setblock 260 152 234 minecraft:black_stained_glass
setblock 260 152 264 minecraft:black_stained_glass
setblock 260 152 269 minecraft:light_blue_stained_glass
setblock 262 152 230 minecraft:black_stained_glass
setblock 262 152 232 minecraft:pearlescent_froglight
setblock 262 152 249 minecraft:sea_lantern
setblock 262 152 255 minecraft:sea_lantern
setblock 262 152 265 minecraft:black_stained_glass
setblock 262 152 267 minecraft:sea_lantern
setblock 263 152 249 minecraft:cyan_stained_glass
setblock 263 152 250 minecraft:sea_lantern
setblock 263 152 254 minecraft:sea_lantern
setblock 263 152 255 minecraft:cyan_stained_glass
fill 264 152 250 264 152 254 minecraft:cyan_stained_glass
setblock 268 152 230 minecraft:magenta_stained_glass
setblock 268 152 232 minecraft:black_stained_glass
setblock 268 152 234 minecraft:black_stained_glass
setblock 268 152 236 minecraft:cyan_stained_glass
setblock 268 152 262 minecraft:black_stained_glass
setblock 268 152 264 minecraft:light_blue_stained_glass
setblock 268 152 266 minecraft:black_stained_glass
setblock 268 152 268 minecraft:magenta_stained_glass
setblock 269 152 229 minecraft:black_stained_glass
setblock 269 152 237 minecraft:ochre_froglight
setblock 269 152 261 minecraft:black_stained_glass
setblock 269 152 269 minecraft:black_stained_glass
setblock 271 152 229 minecraft:cyan_stained_glass
setblock 271 152 237 minecraft:black_stained_glass
setblock 271 152 243 minecraft:light_blue_stained_glass
setblock 271 152 245 minecraft:pearlescent_froglight
setblock 271 152 247 minecraft:pearlescent_froglight
setblock 271 152 249 minecraft:sea_lantern
setblock 271 152 251 minecraft:black_stained_glass
setblock 271 152 253 minecraft:black_stained_glass
setblock 271 152 261 minecraft:magenta_stained_glass
setblock 271 152 269 minecraft:sea_lantern
setblock 272 152 242 minecraft:black_stained_glass
setblock 272 152 255 minecraft:magenta_stained_glass
setblock 273 152 229 minecraft:sea_lantern
setblock 273 152 237 minecraft:magenta_stained_glass
setblock 273 152 261 minecraft:black_stained_glass
setblock 273 152 269 minecraft:black_stained_glass
setblock 274 152 242 minecraft:cyan_stained_glass
setblock 274 152 255 minecraft:black_stained_glass
setblock 275 152 229 minecraft:light_blue_stained_glass
setblock 275 152 237 minecraft:ochre_froglight
setblock 275 152 261 minecraft:pearlescent_froglight
setblock 275 152 269 minecraft:black_stained_glass
setblock 276 152 230 minecraft:black_stained_glass
setblock 276 152 232 minecraft:black_stained_glass
setblock 276 152 234 minecraft:black_stained_glass
setblock 276 152 236 minecraft:cyan_stained_glass
setblock 276 152 243 minecraft:ochre_froglight
setblock 276 152 245 minecraft:black_stained_glass
setblock 276 152 247 minecraft:cyan_stained_glass
setblock 276 152 249 minecraft:magenta_stained_glass
setblock 276 152 251 minecraft:ochre_froglight
setblock 276 152 253 minecraft:magenta_stained_glass
setblock 276 152 262 minecraft:black_stained_glass
setblock 276 152 264 minecraft:black_stained_glass
setblock 276 152 266 minecraft:magenta_stained_glass
setblock 276 152 268 minecraft:black_stained_glass
fill 277 152 244 277 283 244 minecraft:black_concrete
fill 236 153 230 236 154 230 minecraft:light_gray_concrete
fill 236 153 232 236 154 232 minecraft:light_gray_concrete
fill 236 153 234 236 154 234 minecraft:light_gray_concrete
fill 236 153 236 236 154 236 minecraft:light_gray_concrete
fill 236 153 243 236 154 243 minecraft:light_gray_concrete
fill 236 153 245 236 154 245 minecraft:light_gray_concrete
fill 236 153 247 236 154 247 minecraft:light_gray_concrete
fill 236 153 249 236 154 249 minecraft:light_gray_concrete
fill 236 153 251 236 154 251 minecraft:light_gray_concrete
fill 236 153 253 236 154 253 minecraft:light_gray_concrete
fill 236 153 262 236 154 262 minecraft:cyan_terracotta
fill 236 153 264 236 154 264 minecraft:cyan_terracotta
fill 236 153 266 236 154 266 minecraft:cyan_terracotta
fill 236 153 268 236 154 268 minecraft:cyan_terracotta
fill 237 153 229 237 154 229 minecraft:light_gray_concrete
fill 237 153 237 237 154 237 minecraft:light_gray_concrete
fill 237 153 242 237 154 242 minecraft:light_gray_concrete
fill 237 153 255 237 154 255 minecraft:light_gray_concrete
fill 237 153 261 237 154 261 minecraft:cyan_terracotta
fill 237 153 269 237 154 269 minecraft:cyan_terracotta
fill 239 153 229 239 154 229 minecraft:light_gray_concrete
fill 239 153 237 239 154 237 minecraft:light_gray_concrete
fill 239 153 242 239 154 242 minecraft:light_gray_concrete
fill 239 153 255 239 154 255 minecraft:light_gray_concrete
fill 239 153 261 239 154 261 minecraft:cyan_terracotta
fill 239 153 269 239 154 269 minecraft:cyan_terracotta
fill 241 153 229 241 154 229 minecraft:light_gray_concrete
fill 241 153 237 241 154 237 minecraft:light_gray_concrete
fill 241 153 243 241 154 243 minecraft:light_gray_concrete
fill 241 153 245 241 154 245 minecraft:light_gray_concrete
fill 241 153 247 241 154 247 minecraft:light_gray_concrete
fill 241 153 249 241 154 249 minecraft:light_gray_concrete
fill 241 153 251 241 154 251 minecraft:light_gray_concrete
fill 241 153 253 241 154 253 minecraft:light_gray_concrete
fill 241 153 261 241 154 261 minecraft:cyan_terracotta
fill 241 153 269 241 154 269 minecraft:cyan_terracotta
fill 243 153 229 243 154 229 minecraft:light_gray_concrete
fill 243 153 237 243 154 237 minecraft:light_gray_concrete
fill 243 153 261 243 154 261 minecraft:cyan_terracotta
fill 243 153 269 243 154 269 minecraft:cyan_terracotta
fill 244 153 230 244 154 230 minecraft:light_gray_concrete
fill 244 153 232 244 154 232 minecraft:light_gray_concrete
fill 244 153 234 244 154 234 minecraft:light_gray_concrete
fill 244 153 236 244 154 236 minecraft:light_gray_concrete
fill 244 153 262 244 154 262 minecraft:cyan_terracotta
fill 244 153 264 244 154 264 minecraft:cyan_terracotta
fill 244 153 266 244 154 266 minecraft:cyan_terracotta
fill 244 153 268 244 154 268 minecraft:cyan_terracotta
fill 249 153 230 249 154 230 minecraft:light_gray_concrete
fill 249 153 232 249 154 232 minecraft:light_gray_concrete
fill 249 153 265 249 154 265 minecraft:cyan_terracotta
fill 249 153 267 249 154 267 minecraft:cyan_terracotta
fill 250 153 229 250 154 229 minecraft:light_gray_concrete
fill 250 153 234 250 154 234 minecraft:light_gray_concrete
fill 250 153 264 250 154 264 minecraft:cyan_terracotta
fill 250 153 269 250 154 269 minecraft:cyan_terracotta
fill 252 153 229 252 154 229 minecraft:light_gray_concrete
fill 252 153 234 252 154 234 minecraft:light_gray_concrete
fill 252 153 264 252 154 264 minecraft:cyan_terracotta
fill 252 153 269 252 154 269 minecraft:cyan_terracotta
fill 253 153 228 253 228 228 minecraft:black_concrete
fill 254 153 229 254 154 229 minecraft:light_gray_concrete
fill 254 153 234 254 154 234 minecraft:light_gray_concrete
fill 254 153 264 254 154 264 minecraft:cyan_terracotta
fill 254 153 269 254 154 269 minecraft:cyan_terracotta
fill 256 153 229 256 154 229 minecraft:light_gray_concrete
fill 256 153 234 256 154 234 minecraft:light_gray_concrete
fill 256 153 264 256 154 264 minecraft:cyan_terracotta
fill 256 153 269 256 154 269 minecraft:cyan_terracotta
fill 258 153 229 258 154 229 minecraft:light_gray_concrete
fill 258 153 234 258 154 234 minecraft:light_gray_concrete
fill 258 153 264 258 154 264 minecraft:cyan_terracotta
fill 258 153 269 258 154 269 minecraft:cyan_terracotta
fill 260 153 229 260 154 229 minecraft:light_gray_concrete
fill 260 153 234 260 154 234 minecraft:light_gray_concrete
setblock 260 153 252 minecraft:cyan_stained_glass
fill 260 153 264 260 154 264 minecraft:cyan_terracotta
fill 260 153 269 260 154 269 minecraft:cyan_terracotta
fill 262 153 230 262 154 230 minecraft:light_gray_concrete
fill 262 153 232 262 154 232 minecraft:light_gray_concrete
fill 262 153 265 262 154 265 minecraft:cyan_terracotta
fill 262 153 267 262 154 267 minecraft:cyan_terracotta
fill 268 153 230 268 154 230 minecraft:cyan_terracotta
fill 268 153 232 268 154 232 minecraft:cyan_terracotta
fill 268 153 234 268 154 234 minecraft:cyan_terracotta
fill 268 153 236 268 154 236 minecraft:cyan_terracotta
fill 268 153 262 268 154 262 minecraft:light_gray_concrete
setblock 268 153 264 minecraft:light_gray_concrete
setblock 268 153 266 minecraft:light_gray_concrete
setblock 268 153 268 minecraft:light_gray_concrete
fill 269 153 229 269 154 229 minecraft:cyan_terracotta
fill 269 153 237 269 154 237 minecraft:cyan_terracotta
fill 269 153 261 269 154 261 minecraft:light_gray_concrete
fill 269 153 269 269 154 269 minecraft:light_gray_concrete
fill 271 153 229 271 154 229 minecraft:cyan_terracotta
fill 271 153 237 271 154 237 minecraft:cyan_terracotta
fill 271 153 243 271 154 243 minecraft:light_gray_concrete
fill 271 153 245 271 154 245 minecraft:light_gray_concrete
fill 271 153 247 271 154 247 minecraft:light_gray_concrete
fill 271 153 249 271 154 249 minecraft:light_gray_concrete
fill 271 153 251 271 154 251 minecraft:light_gray_concrete
fill 271 153 253 271 154 253 minecraft:light_gray_concrete
fill 271 153 261 271 154 261 minecraft:light_gray_concrete
fill 271 153 269 271 154 269 minecraft:light_gray_concrete
fill 272 153 242 272 154 242 minecraft:light_gray_concrete
fill 272 153 255 272 154 255 minecraft:light_gray_concrete
fill 273 153 229 273 154 229 minecraft:cyan_terracotta
fill 273 153 237 273 154 237 minecraft:cyan_terracotta
fill 273 153 261 273 154 261 minecraft:light_gray_concrete
fill 273 153 269 273 154 269 minecraft:light_gray_concrete
fill 274 153 242 274 154 242 minecraft:light_gray_concrete
fill 274 153 255 274 154 255 minecraft:light_gray_concrete
fill 275 153 229 275 154 229 minecraft:cyan_terracotta
fill 275 153 237 275 154 237 minecraft:cyan_terracotta
fill 275 153 261 275 154 261 minecraft:light_gray_concrete
fill 275 153 269 275 154 269 minecraft:light_gray_concrete
fill 276 153 230 276 154 230 minecraft:cyan_terracotta
fill 276 153 232 276 154 232 minecraft:cyan_terracotta
fill 276 153 234 276 154 234 minecraft:cyan_terracotta
fill 276 153 236 276 154 236 minecraft:cyan_terracotta
fill 276 153 243 276 154 243 minecraft:light_gray_concrete
fill 276 153 245 276 154 245 minecraft:light_gray_concrete
fill 276 153 247 276 154 247 minecraft:light_gray_concrete
fill 276 153 249 276 154 249 minecraft:light_gray_concrete
fill 276 153 251 276 154 251 minecraft:light_gray_concrete
fill 276 153 253 276 154 253 minecraft:light_gray_concrete
fill 276 153 262 276 154 262 minecraft:light_gray_concrete
fill 276 153 264 276 154 264 minecraft:light_gray_concrete
fill 276 153 266 276 154 266 minecraft:light_gray_concrete
fill 276 153 268 276 154 268 minecraft:light_gray_concrete
fill 239 154 270 239 180 270 minecraft:black_concrete
setblock 240 154 270 minecraft:blue_concrete
fill 251 154 261 263 156 263 minecraft:gray_concrete
setblock 254 154 228 minecraft:magenta_concrete
fill 263 154 264 268 154 269 minecraft:gray_concrete
fill 264 154 263 268 156 263 minecraft:gray_concrete
fill 265 154 229 267 156 234 minecraft:gray_concrete
fill 269 154 263 276 191 263 minecraft:light_gray_concrete
fill 269 154 265 273 229 265 minecraft:light_gray_concrete
fill 269 154 267 272 237 267 minecraft:light_gray_concrete
setblock 277 154 252 minecraft:blue_concrete
setblock 235 155 233 minecraft:cyan_concrete
setblock 235 155 260 minecraft:purple_concrete
setblock 235 155 266 minecraft:cyan_concrete
setblock 236 155 230 minecraft:magenta_stained_glass
setblock 236 155 232 minecraft:light_blue_stained_glass
setblock 236 155 234 minecraft:sea_lantern
setblock 236 155 236 minecraft:black_stained_glass
setblock 236 155 243 minecraft:pearlescent_froglight
setblock 236 155 245 minecraft:black_stained_glass
setblock 236 155 247 minecraft:ochre_froglight
setblock 236 155 249 minecraft:light_blue_stained_glass
setblock 236 155 251 minecraft:black_stained_glass
setblock 236 155 253 minecraft:black_stained_glass
setblock 236 155 262 minecraft:black_stained_glass
setblock 236 155 264 minecraft:magenta_stained_glass
setblock 236 155 266 minecraft:light_blue_stained_glass
setblock 236 155 268 minecraft:black_stained_glass
setblock 237 155 229 minecraft:magenta_stained_glass
setblock 237 155 237 minecraft:sea_lantern
setblock 237 155 242 minecraft:black_stained_glass
setblock 237 155 255 minecraft:pearlescent_froglight
setblock 237 155 261 minecraft:black_stained_glass
setblock 237 155 269 minecraft:magenta_stained_glass
setblock 239 155 229 minecraft:black_stained_glass
fill 239 155 230 240 164 236 minecraft:light_gray_concrete
setblock 239 155 237 minecraft:black_stained_glass
setblock 239 155 242 minecraft:magenta_stained_glass
setblock 239 155 255 minecraft:light_blue_stained_glass
setblock 239 155 261 minecraft:black_stained_glass
setblock 239 155 269 minecraft:light_blue_stained_glass
fill 240 155 242 240 171 242 minecraft:light_gray_concrete
fill 240 155 270 240 222 270 minecraft:black_concrete
setblock 241 155 229 minecraft:black_stained_glass
fill 241 155 230 243 159 233 minecraft:light_gray_concrete
fill 241 155 234 249 155 242 minecraft:magenta_stained_glass
setblock 241 155 243 minecraft:light_blue_stained_glass
setblock 241 155 245 minecraft:black_stained_glass
setblock 241 155 247 minecraft:light_blue_stained_glass
setblock 241 155 249 minecraft:sea_lantern
setblock 241 155 251 minecraft:black_stained_glass
setblock 241 155 253 minecraft:black_stained_glass
setblock 241 155 261 minecraft:magenta_stained_glass
setblock 241 155 269 minecraft:black_stained_glass
setblock 243 155 229 minecraft:ochre_froglight
setblock 243 155 261 minecraft:black_stained_glass
setblock 243 155 269 minecraft:sea_lantern
setblock 244 155 230 minecraft:black_stained_glass
setblock 244 155 232 minecraft:pearlescent_froglight
setblock 244 155 262 minecraft:black_stained_glass
setblock 244 155 264 minecraft:light_blue_stained_glass
setblock 244 155 266 minecraft:pearlescent_froglight
setblock 244 155 268 minecraft:light_blue_stained_glass
setblock 249 155 230 minecraft:black_stained_glass
setblock 249 155 232 minecraft:ochre_froglight
fill 249 155 233 249 165 233 minecraft:light_gray_concrete
fill 249 155 264 262 155 269 minecraft:black_concrete
setblock 250 155 229 minecraft:cyan_stained_glass
setblock 250 155 234 minecraft:magenta_stained_glass
setblock 252 155 229 minecraft:cyan_stained_glass
setblock 252 155 234 minecraft:light_blue_stained_glass
fill 254 155 228 254 222 228 minecraft:black_concrete
setblock 254 155 229 minecraft:pearlescent_froglight
setblock 254 155 234 minecraft:black_stained_glass
setblock 256 155 229 minecraft:pearlescent_froglight
setblock 256 155 234 minecraft:cyan_stained_glass
setblock 258 155 229 minecraft:black_stained_glass
setblock 258 155 234 minecraft:sea_lantern
setblock 260 155 229 minecraft:light_blue_stained_glass
setblock 260 155 234 minecraft:black_stained_glass
setblock 262 155 230 minecraft:pearlescent_froglight
setblock 262 155 232 minecraft:magenta_stained_glass
fill 263 155 264 267 156 269 minecraft:gray_concrete
setblock 268 155 230 minecraft:gray_concrete
setblock 268 155 232 minecraft:cyan_stained_glass
setblock 268 155 234 minecraft:black_stained_glass
setblock 268 155 236 minecraft:black_stained_glass
setblock 268 155 262 minecraft:black_stained_glass
setblock 268 155 264 minecraft:cyan_stained_glass
fill 268 155 265 268 156 265 minecraft:gray_concrete
setblock 268 155 266 minecraft:ochre_froglight
fill 268 155 267 268 156 267 minecraft:gray_concrete
setblock 268 155 268 minecraft:magenta_stained_glass
fill 268 155 269 268 156 269 minecraft:gray_concrete
setblock 269 155 229 minecraft:gray_concrete
setblock 269 155 237 minecraft:cyan_stained_glass
setblock 269 155 261 minecraft:black_stained_glass
setblock 269 155 269 minecraft:black_stained_glass
setblock 271 155 229 minecraft:magenta_stained_glass
setblock 271 155 237 minecraft:pearlescent_froglight
setblock 271 155 243 minecraft:cyan_stained_glass
setblock 271 155 245 minecraft:sea_lantern
setblock 271 155 247 minecraft:black_stained_glass
setblock 271 155 249 minecraft:light_blue_stained_glass
setblock 271 155 251 minecraft:black_stained_glass
setblock 271 155 253 minecraft:sea_lantern
setblock 271 155 261 minecraft:black_stained_glass
setblock 271 155 269 minecraft:black_stained_glass
setblock 272 155 242 minecraft:magenta_stained_glass
setblock 272 155 255 minecraft:ochre_froglight
setblock 273 155 229 minecraft:cyan_stained_glass
setblock 273 155 237 minecraft:black_stained_glass
setblock 273 155 261 minecraft:sea_lantern
setblock 273 155 269 minecraft:sea_lantern
setblock 274 155 242 minecraft:light_blue_stained_glass
setblock 274 155 255 minecraft:pearlescent_froglight
setblock 275 155 229 minecraft:ochre_froglight
setblock 275 155 237 minecraft:pearlescent_froglight
setblock 275 155 261 minecraft:black_stained_glass
setblock 275 155 269 minecraft:ochre_froglight
setblock 276 155 230 minecraft:black_stained_glass
setblock 276 155 232 minecraft:black_stained_glass
setblock 276 155 234 minecraft:magenta_stained_glass
setblock 276 155 236 minecraft:cyan_stained_glass
setblock 276 155 243 minecraft:cyan_stained_glass
setblock 276 155 245 minecraft:cyan_stained_glass
setblock 276 155 247 minecraft:black_stained_glass
setblock 276 155 249 minecraft:ochre_froglight
setblock 276 155 251 minecraft:black_stained_glass
setblock 276 155 253 minecraft:black_stained_glass
setblock 276 155 262 minecraft:black_stained_glass
setblock 276 155 264 minecraft:black_stained_glass
setblock 276 155 266 minecraft:black_stained_glass
setblock 276 155 268 minecraft:black_stained_glass
setblock 277 155 243 minecraft:cyan_concrete
fill 277 155 252 277 239 252 minecraft:black_concrete
setblock 277 155 269 minecraft:magenta_concrete
setblock 235 156 231 minecraft:purple_concrete
fill 235 156 233 235 166 233 minecraft:black_concrete
setblock 235 156 248 minecraft:blue_concrete
fill 235 156 260 235 259 260 minecraft:black_concrete
fill 235 156 266 235 193 266 minecraft:black_concrete
fill 236 156 230 236 157 230 minecraft:light_gray_concrete
fill 236 156 232 236 157 232 minecraft:light_gray_concrete
fill 236 156 234 236 157 234 minecraft:light_gray_concrete
fill 236 156 236 236 157 236 minecraft:light_gray_concrete
fill 236 156 243 236 157 243 minecraft:light_gray_concrete
fill 236 156 245 236 157 245 minecraft:light_gray_concrete
fill 236 156 247 236 157 247 minecraft:light_gray_concrete
fill 236 156 249 236 157 249 minecraft:light_gray_concrete
fill 236 156 251 236 157 251 minecraft:light_gray_concrete
fill 236 156 253 236 157 253 minecraft:light_gray_concrete
fill 236 156 262 236 157 262 minecraft:cyan_terracotta
fill 236 156 264 236 157 264 minecraft:cyan_terracotta
fill 236 156 266 236 157 266 minecraft:cyan_terracotta
fill 236 156 268 236 157 268 minecraft:cyan_terracotta
fill 237 156 229 237 157 229 minecraft:light_gray_concrete
fill 237 156 237 237 157 237 minecraft:light_gray_concrete
fill 237 156 242 237 157 242 minecraft:light_gray_concrete
fill 237 156 255 237 157 255 minecraft:light_gray_concrete
fill 237 156 261 237 157 261 minecraft:cyan_terracotta
fill 237 156 269 237 157 269 minecraft:cyan_terracotta
fill 239 156 229 239 157 229 minecraft:light_gray_concrete
fill 239 156 237 239 157 237 minecraft:light_gray_concrete
fill 239 156 242 239 157 242 minecraft:light_gray_concrete
fill 239 156 255 239 157 255 minecraft:light_gray_concrete
fill 239 156 261 239 157 261 minecraft:cyan_terracotta
fill 239 156 269 239 157 269 minecraft:cyan_terracotta
fill 241 156 229 241 157 229 minecraft:light_gray_concrete
fill 241 156 234 241 157 237 minecraft:light_gray_concrete
fill 241 156 242 241 157 243 minecraft:light_gray_concrete
fill 241 156 245 241 157 245 minecraft:light_gray_concrete
fill 241 156 247 241 157 247 minecraft:light_gray_concrete
fill 241 156 249 241 157 249 minecraft:light_gray_concrete
fill 241 156 251 241 157 251 minecraft:light_gray_concrete
fill 241 156 253 241 157 253 minecraft:light_gray_concrete
fill 241 156 261 241 157 261 minecraft:cyan_terracotta
fill 241 156 269 241 157 269 minecraft:cyan_terracotta
fill 242 156 234 244 157 234 minecraft:light_gray_concrete
fill 242 156 235 242 157 241 minecraft:magenta_stained_glass
fill 243 156 229 243 157 229 minecraft:light_gray_concrete
fill 243 156 235 248 157 235 minecraft:magenta_stained_glass
fill 243 156 236 244 157 237 minecraft:light_gray_concrete
fill 243 156 241 248 157 241 minecraft:magenta_stained_glass
fill 243 156 261 243 157 261 minecraft:cyan_terracotta
fill 243 156 269 243 157 269 minecraft:cyan_terracotta
fill 244 156 230 244 157 230 minecraft:light_gray_concrete
fill 244 156 232 244 157 232 minecraft:light_gray_concrete
fill 244 156 262 244 157 262 minecraft:cyan_terracotta
fill 244 156 264 244 157 264 minecraft:cyan_terracotta
fill 244 156 266 244 157 266 minecraft:cyan_terracotta
fill 244 156 268 244 157 268 minecraft:cyan_terracotta
fill 248 156 236 248 157 240 minecraft:magenta_stained_glass
fill 249 156 230 249 157 230 minecraft:light_gray_concrete
fill 249 156 232 249 157 232 minecraft:light_gray_concrete
fill 249 156 234 250 157 234 minecraft:light_gray_concrete
fill 249 156 264 249 156 269 minecraft:verdant_froglight
fill 250 156 229 250 157 229 minecraft:light_gray_concrete
fill 250 156 264 262 156 264 minecraft:verdant_froglight
fill 250 156 269 262 156 269 minecraft:verdant_froglight
fill 251 156 265 261 156 265 minecraft:gray_concrete
fill 251 156 266 260 156 267 minecraft:cyan_terracotta
fill 251 156 268 261 156 268 minecraft:gray_concrete
fill 252 156 229 252 157 229 minecraft:light_gray_concrete
fill 252 156 234 252 157 234 minecraft:light_gray_concrete
fill 254 156 229 254 157 229 minecraft:light_gray_concrete
fill 254 156 234 254 157 234 minecraft:light_gray_concrete
fill 256 156 229 256 157 229 minecraft:light_gray_concrete
fill 256 156 234 256 157 234 minecraft:light_gray_concrete
fill 258 156 229 258 157 229 minecraft:light_gray_concrete
fill 258 156 234 258 157 234 minecraft:light_gray_concrete
fill 260 156 229 260 157 229 minecraft:light_gray_concrete
fill 260 156 234 260 157 234 minecraft:light_gray_concrete
fill 261 156 266 261 156 267 minecraft:gray_concrete
fill 262 156 230 262 157 230 minecraft:light_gray_concrete
fill 262 156 232 262 157 232 minecraft:light_gray_concrete
fill 262 156 265 262 156 268 minecraft:verdant_froglight
setblock 262 156 270 minecraft:verdant_froglight
fill 268 156 230 268 157 230 minecraft:cyan_terracotta
fill 268 156 232 268 157 232 minecraft:cyan_terracotta
fill 268 156 234 268 157 234 minecraft:cyan_terracotta
fill 268 156 236 268 157 236 minecraft:cyan_terracotta
fill 268 156 262 268 157 262 minecraft:light_gray_concrete
fill 268 156 264 268 157 264 minecraft:gray_concrete
fill 268 156 266 268 157 266 minecraft:gray_concrete
fill 268 156 268 268 157 268 minecraft:gray_concrete
fill 269 156 229 269 157 229 minecraft:cyan_terracotta
fill 269 156 237 269 157 237 minecraft:cyan_terracotta
fill 269 156 261 269 157 261 minecraft:light_gray_concrete
fill 269 156 269 269 157 269 minecraft:light_gray_concrete
fill 271 156 229 271 157 229 minecraft:cyan_terracotta
fill 271 156 237 271 157 237 minecraft:cyan_terracotta
fill 271 156 243 271 157 243 minecraft:light_gray_concrete
fill 271 156 245 271 157 245 minecraft:light_gray_concrete
fill 271 156 247 271 157 247 minecraft:light_gray_concrete
fill 271 156 249 271 157 249 minecraft:light_gray_concrete
fill 271 156 251 271 157 251 minecraft:light_gray_concrete
fill 271 156 253 271 157 253 minecraft:light_gray_concrete
fill 271 156 261 271 157 261 minecraft:light_gray_concrete
fill 271 156 269 271 157 269 minecraft:light_gray_concrete
fill 272 156 242 272 157 242 minecraft:light_gray_concrete
fill 272 156 255 272 157 255 minecraft:light_gray_concrete
fill 273 156 229 273 157 229 minecraft:cyan_terracotta
fill 273 156 237 273 157 237 minecraft:cyan_terracotta
fill 273 156 261 273 157 261 minecraft:light_gray_concrete
fill 273 156 269 273 157 269 minecraft:light_gray_concrete
fill 274 156 242 274 157 242 minecraft:light_gray_concrete
fill 274 156 255 274 157 255 minecraft:light_gray_concrete
fill 275 156 229 275 157 229 minecraft:cyan_terracotta
fill 275 156 237 275 157 237 minecraft:cyan_terracotta
fill 275 156 261 275 157 261 minecraft:light_gray_concrete
fill 275 156 269 275 157 269 minecraft:light_gray_concrete
fill 276 156 230 276 157 230 minecraft:cyan_terracotta
fill 276 156 232 276 157 232 minecraft:cyan_terracotta
fill 276 156 234 276 157 234 minecraft:cyan_terracotta
fill 276 156 236 276 157 236 minecraft:cyan_terracotta
fill 276 156 243 276 157 243 minecraft:light_gray_concrete
fill 276 156 245 276 157 245 minecraft:light_gray_concrete
fill 276 156 247 276 157 247 minecraft:light_gray_concrete
fill 276 156 249 276 157 249 minecraft:light_gray_concrete
fill 276 156 251 276 157 251 minecraft:light_gray_concrete
fill 276 156 253 276 157 253 minecraft:light_gray_concrete
fill 276 156 262 276 157 262 minecraft:light_gray_concrete
fill 276 156 264 276 157 264 minecraft:light_gray_concrete
fill 276 156 266 276 157 266 minecraft:light_gray_concrete
fill 276 156 268 276 157 268 minecraft:light_gray_concrete
fill 277 156 243 277 222 243 minecraft:black_concrete
setblock 277 156 254 minecraft:blue_concrete
setblock 277 156 269 minecraft:purple_concrete
setblock 235 157 231 minecraft:pearlescent_froglight
fill 235 157 248 235 235 248 minecraft:black_concrete
setblock 235 157 252 minecraft:verdant_froglight
setblock 238 157 238 minecraft:light[level=12]
setblock 238 157 239 minecraft:light[level=15]
setblock 238 157 259 minecraft:light[level=12]
setblock 245 157 231 minecraft:light[level=12]
setblock 245 157 238 minecraft:light[level=12]
setblock 245 157 245 minecraft:light[level=12]
setblock 245 157 252 minecraft:light[level=12]
setblock 245 157 259 minecraft:light[level=12]
setblock 245 157 266 minecraft:light[level=12]
setblock 246 157 231 minecraft:light[level=15]
setblock 246 157 239 minecraft:light[level=15]
setblock 246 157 247 minecraft:light[level=15]
setblock 246 157 255 minecraft:light[level=15]
setblock 246 157 263 minecraft:light[level=15]
fill 251 157 261 259 169 265 minecraft:gray_concrete
fill 251 157 266 259 157 267 minecraft:cyan_terracotta
fill 251 157 268 259 169 269 minecraft:gray_concrete
setblock 252 157 238 minecraft:light[level=12]
setblock 252 157 245 minecraft:light[level=12]
setblock 252 157 252 minecraft:light[level=12]
setblock 252 157 259 minecraft:light[level=12]
setblock 254 157 239 minecraft:light[level=15]
setblock 254 157 247 minecraft:light[level=15]
setblock 254 157 255 minecraft:light[level=15]
setblock 259 157 238 minecraft:light[level=12]
setblock 259 157 245 minecraft:light[level=12]
setblock 259 157 252 minecraft:light[level=12]
setblock 259 157 259 minecraft:light[level=12]
fill 260 157 261 263 169 262 minecraft:gray_concrete
setblock 260 157 263 minecraft:sea_lantern
fill 260 157 264 260 169 264 minecraft:gray_concrete
setblock 260 157 265 minecraft:sea_lantern
fill 260 157 266 260 169 266 minecraft:cyan_terracotta
setblock 260 157 267 minecraft:sea_lantern
fill 260 157 268 260 169 268 minecraft:gray_concrete
setblock 260 157 269 minecraft:sea_lantern
fill 261 157 263 261 169 263 minecraft:gray_concrete
setblock 261 157 264 minecraft:sea_lantern
fill 261 157 265 261 169 265 minecraft:gray_concrete
setblock 261 157 266 minecraft:sea_lantern
fill 261 157 267 261 169 267 minecraft:gray_concrete
setblock 261 157 268 minecraft:sea_lantern
fill 261 157 269 261 169 269 minecraft:gray_concrete
setblock 262 157 239 minecraft:light[level=15]
setblock 262 157 247 minecraft:light[level=15]
setblock 262 157 255 minecraft:light[level=15]
setblock 262 157 263 minecraft:sea_lantern
fill 262 157 264 262 169 264 minecraft:gray_concrete
setblock 262 157 265 minecraft:sea_lantern
fill 262 157 266 262 169 266 minecraft:gray_concrete
setblock 262 157 267 minecraft:sea_lantern
fill 262 157 268 262 169 268 minecraft:gray_concrete
setblock 262 157 269 minecraft:sea_lantern
fill 262 157 270 262 218 270 minecraft:black_concrete
fill 263 157 263 263 169 263 minecraft:gray_concrete
setblock 263 157 264 minecraft:sea_lantern
fill 263 157 265 263 169 265 minecraft:gray_concrete
setblock 263 157 266 minecraft:sea_lantern
fill 263 157 267 263 169 267 minecraft:gray_concrete
setblock 263 157 268 minecraft:sea_lantern
fill 263 157 269 263 169 269 minecraft:gray_concrete
setblock 264 157 263 minecraft:sea_lantern
fill 264 157 264 264 168 264 minecraft:gray_concrete
setblock 264 157 265 minecraft:sea_lantern
fill 264 157 266 264 168 266 minecraft:gray_concrete
setblock 264 157 267 minecraft:sea_lantern
fill 264 157 268 264 168 268 minecraft:gray_concrete
setblock 264 157 269 minecraft:sea_lantern
fill 265 157 229 265 166 229 minecraft:gray_concrete
setblock 265 157 230 minecraft:sea_lantern
fill 265 157 231 265 166 231 minecraft:gray_concrete
setblock 265 157 232 minecraft:sea_lantern
fill 265 157 233 265 166 233 minecraft:gray_concrete
setblock 265 157 234 minecraft:sea_lantern
fill 265 157 263 265 168 263 minecraft:gray_concrete
setblock 265 157 264 minecraft:sea_lantern
fill 265 157 265 265 168 265 minecraft:gray_concrete
setblock 265 157 266 minecraft:sea_lantern
fill 265 157 267 265 168 267 minecraft:gray_concrete
setblock 265 157 268 minecraft:sea_lantern
fill 265 157 269 265 168 269 minecraft:gray_concrete
setblock 266 157 229 minecraft:sea_lantern
fill 266 157 230 266 166 230 minecraft:gray_concrete
setblock 266 157 231 minecraft:sea_lantern
fill 266 157 232 266 166 232 minecraft:gray_concrete
setblock 266 157 233 minecraft:sea_lantern
fill 266 157 234 266 166 234 minecraft:gray_concrete
setblock 266 157 238 minecraft:light[level=12]
setblock 266 157 245 minecraft:light[level=12]
setblock 266 157 252 minecraft:light[level=12]
setblock 266 157 259 minecraft:light[level=12]
setblock 266 157 263 minecraft:sea_lantern
fill 266 157 264 266 168 264 minecraft:gray_concrete
setblock 266 157 265 minecraft:sea_lantern
fill 266 157 266 266 168 266 minecraft:gray_concrete
setblock 266 157 267 minecraft:sea_lantern
fill 266 157 268 266 168 268 minecraft:gray_concrete
setblock 266 157 269 minecraft:sea_lantern
fill 267 157 229 267 166 229 minecraft:gray_concrete
setblock 267 157 230 minecraft:sea_lantern
fill 267 157 231 267 166 231 minecraft:gray_concrete
setblock 267 157 232 minecraft:sea_lantern
fill 267 157 233 267 166 233 minecraft:gray_concrete
setblock 267 157 234 minecraft:sea_lantern
fill 267 157 263 267 168 263 minecraft:gray_concrete
setblock 267 157 264 minecraft:sea_lantern
fill 267 157 265 267 168 265 minecraft:gray_concrete
setblock 267 157 266 minecraft:sea_lantern
fill 267 157 267 267 168 267 minecraft:gray_concrete
setblock 267 157 268 minecraft:sea_lantern
fill 267 157 269 267 168 269 minecraft:gray_concrete
setblock 268 157 229 minecraft:sea_lantern
setblock 268 157 231 minecraft:sea_lantern
setblock 268 157 233 minecraft:sea_lantern
setblock 268 157 263 minecraft:sea_lantern
setblock 268 157 265 minecraft:sea_lantern
setblock 268 157 267 minecraft:sea_lantern
setblock 268 157 269 minecraft:sea_lantern
setblock 269 157 230 minecraft:sea_lantern
setblock 269 157 232 minecraft:sea_lantern
setblock 269 157 234 minecraft:sea_lantern
setblock 270 157 229 minecraft:sea_lantern
setblock 270 157 231 minecraft:sea_lantern
setblock 270 157 233 minecraft:sea_lantern
setblock 270 157 239 minecraft:light[level=15]
setblock 270 157 247 minecraft:light[level=15]
setblock 270 157 255 minecraft:light[level=15]
fill 270 157 256 275 158 256 minecraft:gray_concrete
setblock 271 157 230 minecraft:sea_lantern
setblock 271 157 232 minecraft:sea_lantern
setblock 271 157 234 minecraft:sea_lantern
fill 271 157 257 276 158 257 minecraft:gray_concrete
setblock 272 157 229 minecraft:sea_lantern
setblock 272 157 231 minecraft:sea_lantern
setblock 272 157 233 minecraft:sea_lantern
setblock 273 157 230 minecraft:sea_lantern
setblock 273 157 232 minecraft:sea_lantern
setblock 273 157 234 minecraft:sea_lantern
setblock 273 157 238 minecraft:light[level=12]
setblock 273 157 259 minecraft:light[level=12]
fill 277 157 254 277 237 254 minecraft:black_concrete
fill 277 157 269 277 194 269 minecraft:black_concrete
fill 235 158 231 235 232 231 minecraft:black_concrete
fill 235 158 252 235 167 252 minecraft:black_concrete
setblock 236 158 230 minecraft:magenta_stained_glass
setblock 236 158 232 minecraft:light_blue_stained_glass
setblock 236 158 234 minecraft:ochre_froglight
setblock 236 158 236 minecraft:black_stained_glass
setblock 236 158 243 minecraft:cyan_stained_glass
setblock 236 158 245 minecraft:ochre_froglight
setblock 236 158 247 minecraft:magenta_stained_glass
setblock 236 158 249 minecraft:ochre_froglight
setblock 236 158 251 minecraft:magenta_stained_glass
setblock 236 158 253 minecraft:black_stained_glass
setblock 236 158 262 minecraft:light_blue_stained_glass
setblock 236 158 264 minecraft:cyan_stained_glass
setblock 236 158 266 minecraft:black_stained_glass
setblock 236 158 268 minecraft:black_stained_glass
setblock 237 158 229 minecraft:light_blue_stained_glass
setblock 237 158 237 minecraft:pearlescent_froglight
setblock 237 158 242 minecraft:black_stained_glass
setblock 237 158 255 minecraft:black_stained_glass
setblock 237 158 261 minecraft:cyan_stained_glass
setblock 237 158 269 minecraft:black_stained_glass
setblock 239 158 229 minecraft:ochre_froglight
setblock 239 158 237 minecraft:pearlescent_froglight
setblock 239 158 242 minecraft:cyan_stained_glass
setblock 239 158 255 minecraft:magenta_stained_glass
setblock 239 158 261 minecraft:magenta_stained_glass
setblock 239 158 269 minecraft:black_stained_glass
setblock 241 158 229 minecraft:cyan_stained_glass
fill 241 158 234 242 165 236 minecraft:light_gray_concrete
setblock 241 158 237 minecraft:black_stained_glass
fill 241 158 242 241 183 242 minecraft:light_gray_concrete
setblock 241 158 243 minecraft:magenta_stained_glass
setblock 241 158 245 minecraft:ochre_froglight
setblock 241 158 247 minecraft:black_stained_glass
setblock 241 158 249 minecraft:magenta_stained_glass
setblock 241 158 251 minecraft:pearlescent_froglight
setblock 241 158 253 minecraft:pearlescent_froglight
setblock 241 158 261 minecraft:ochre_froglight
setblock 241 158 269 minecraft:magenta_stained_glass
fill 242 158 237 242 225 237 minecraft:light_gray_concrete
setblock 243 158 229 minecraft:black_stained_glass
fill 243 158 234 243 225 235 minecraft:light_gray_concrete
fill 243 158 236 243 159 240 minecraft:magenta_stained_glass
setblock 243 158 261 minecraft:sea_lantern
setblock 243 158 269 minecraft:sea_lantern
setblock 244 158 230 minecraft:cyan_stained_glass
setblock 244 158 232 minecraft:cyan_stained_glass
setblock 244 158 234 minecraft:black_stained_glass
fill 244 158 235 244 225 235 minecraft:light_gray_concrete
fill 244 158 236 247 159 236 minecraft:magenta_stained_glass
fill 244 158 237 244 159 237 minecraft:light_gray_concrete
fill 244 158 240 247 159 240 minecraft:magenta_stained_glass
setblock 244 158 262 minecraft:black_stained_glass
setblock 244 158 264 minecraft:magenta_stained_glass
setblock 244 158 266 minecraft:magenta_stained_glass
setblock 244 158 268 minecraft:light_blue_stained_glass
setblock 246 158 270 minecraft:pearlescent_froglight
fill 247 158 237 247 159 239 minecraft:magenta_stained_glass
setblock 249 158 230 minecraft:light_blue_stained_glass
setblock 249 158 232 minecraft:light_blue_stained_glass
fill 249 158 234 249 175 234 minecraft:light_gray_concrete
setblock 250 158 229 minecraft:black_stained_glass
setblock 250 158 234 minecraft:cyan_stained_glass
fill 251 158 266 251 169 267 minecraft:cyan_terracotta
setblock 252 158 229 minecraft:sea_lantern
setblock 252 158 234 minecraft:magenta_stained_glass
setblock 252 158 266 minecraft:sea_lantern
setblock 252 158 267 minecraft:black_stained_glass
fill 253 158 266 253 169 267 minecraft:cyan_terracotta
setblock 254 158 229 minecraft:cyan_stained_glass
setblock 254 158 234 minecraft:black_stained_glass
setblock 254 158 266 minecraft:gray_concrete
setblock 254 158 267 minecraft:black_stained_glass
fill 255 158 266 255 169 267 minecraft:cyan_terracotta
setblock 256 158 229 minecraft:magenta_stained_glass
setblock 256 158 234 minecraft:cyan_stained_glass
setblock 256 158 266 minecraft:black_stained_glass
setblock 256 158 267 minecraft:sea_lantern
fill 257 158 255 264 158 255 minecraft:gray_concrete
fill 257 158 266 257 169 267 minecraft:cyan_terracotta
setblock 258 158 229 minecraft:black_stained_glass
setblock 258 158 234 minecraft:light_blue_stained_glass
fill 258 158 256 269 158 256 minecraft:gray_concrete
fill 258 158 266 258 158 267 minecraft:black_stained_glass
fill 259 158 266 259 169 267 minecraft:cyan_terracotta
setblock 260 158 229 minecraft:magenta_stained_glass
setblock 260 158 234 minecraft:black_stained_glass
fill 260 158 263 260 159 263 minecraft:gray_concrete
fill 260 158 265 260 159 265 minecraft:gray_concrete
fill 260 158 267 260 159 267 minecraft:cyan_terracotta
fill 260 158 269 260 159 269 minecraft:gray_concrete
fill 261 158 264 261 159 264 minecraft:gray_concrete
fill 261 158 266 261 159 266 minecraft:gray_concrete
fill 261 158 268 261 159 268 minecraft:gray_concrete
setblock 262 158 230 minecraft:sea_lantern
setblock 262 158 232 minecraft:ochre_froglight
fill 262 158 263 262 159 263 minecraft:gray_concrete
fill 262 158 265 262 159 265 minecraft:gray_concrete
fill 262 158 267 262 159 267 minecraft:gray_concrete
fill 262 158 269 262 159 269 minecraft:gray_concrete
fill 263 158 264 263 159 264 minecraft:gray_concrete
fill 263 158 266 263 159 266 minecraft:gray_concrete
fill 263 158 268 263 159 268 minecraft:gray_concrete
fill 264 158 263 264 159 263 minecraft:gray_concrete
fill 264 158 265 264 159 265 minecraft:gray_concrete
fill 264 158 267 264 159 267 minecraft:gray_concrete
fill 264 158 269 264 159 269 minecraft:gray_concrete
fill 265 158 230 265 159 230 minecraft:gray_concrete
fill 265 158 232 265 159 232 minecraft:gray_concrete
fill 265 158 234 265 159 234 minecraft:gray_concrete
fill 265 158 264 265 159 264 minecraft:gray_concrete
fill 265 158 266 265 159 266 minecraft:gray_concrete
fill 265 158 268 265 159 268 minecraft:gray_concrete
fill 266 158 229 266 159 229 minecraft:gray_concrete
fill 266 158 231 266 159 231 minecraft:gray_concrete
fill 266 158 233 266 159 233 minecraft:gray_concrete
fill 266 158 257 270 158 257 minecraft:gray_concrete
fill 266 158 263 266 159 263 minecraft:gray_concrete
fill 266 158 265 266 159 265 minecraft:gray_concrete
fill 266 158 267 266 159 267 minecraft:gray_concrete
fill 266 158 269 266 159 269 minecraft:gray_concrete
fill 267 158 230 267 159 230 minecraft:gray_concrete
fill 267 158 232 267 159 232 minecraft:gray_concrete
fill 267 158 234 267 159 234 minecraft:gray_concrete
fill 267 158 264 267 159 264 minecraft:gray_concrete
fill 267 158 266 267 159 266 minecraft:gray_concrete
fill 267 158 268 267 159 268 minecraft:gray_concrete
fill 268 158 229 268 159 229 minecraft:cyan_terracotta
setblock 268 158 230 minecraft:ochre_froglight
fill 268 158 231 268 159 231 minecraft:cyan_terracotta
setblock 268 158 232 minecraft:black_stained_glass
fill 268 158 233 268 159 233 minecraft:cyan_terracotta
setblock 268 158 234 minecraft:black_stained_glass
setblock 268 158 236 minecraft:black_stained_glass
setblock 268 158 262 minecraft:ochre_froglight
fill 268 158 263 268 159 263 minecraft:gray_concrete
setblock 268 158 264 minecraft:sea_lantern
fill 268 158 265 268 159 265 minecraft:gray_concrete
setblock 268 158 266 minecraft:sea_lantern
fill 268 158 267 268 159 267 minecraft:gray_concrete
setblock 268 158 268 minecraft:cyan_stained_glass
fill 268 158 269 268 159 269 minecraft:gray_concrete
setblock 269 158 229 minecraft:magenta_stained_glass
fill 269 158 230 269 159 230 minecraft:cyan_terracotta
fill 269 158 232 269 159 232 minecraft:cyan_terracotta
fill 269 158 234 269 159 234 minecraft:cyan_terracotta
setblock 269 158 237 minecraft:black_stained_glass
setblock 269 158 261 minecraft:cyan_stained_glass
setblock 269 158 269 minecraft:black_stained_glass
fill 270 158 229 270 159 229 minecraft:cyan_terracotta
fill 270 158 231 270 159 231 minecraft:cyan_terracotta
fill 270 158 233 270 159 233 minecraft:cyan_terracotta
setblock 271 158 229 minecraft:magenta_stained_glass
fill 271 158 230 271 159 230 minecraft:cyan_terracotta
fill 271 158 232 271 159 232 minecraft:cyan_terracotta
fill 271 158 234 271 159 234 minecraft:cyan_terracotta
setblock 271 158 237 minecraft:pearlescent_froglight
setblock 271 158 243 minecraft:ochre_froglight
setblock 271 158 245 minecraft:cyan_stained_glass
setblock 271 158 247 minecraft:sea_lantern
setblock 271 158 249 minecraft:black_stained_glass
setblock 271 158 251 minecraft:light_blue_stained_glass
setblock 271 158 253 minecraft:black_stained_glass
setblock 271 158 261 minecraft:black_stained_glass
setblock 271 158 269 minecraft:cyan_stained_glass
fill 272 158 229 272 159 229 minecraft:cyan_terracotta
fill 272 158 231 272 159 231 minecraft:cyan_terracotta
fill 272 158 233 272 159 233 minecraft:cyan_terracotta
setblock 272 158 242 minecraft:sea_lantern
setblock 272 158 255 minecraft:magenta_stained_glass
setblock 273 158 229 minecraft:pearlescent_froglight
fill 273 158 230 273 159 230 minecraft:cyan_terracotta
fill 273 158 232 273 159 232 minecraft:cyan_terracotta
fill 273 158 234 273 159 234 minecraft:cyan_terracotta
setblock 273 158 237 minecraft:light_blue_stained_glass
setblock 273 158 261 minecraft:cyan_stained_glass
setblock 273 158 269 minecraft:magenta_stained_glass
setblock 274 158 242 minecraft:black_stained_glass
setblock 274 158 255 minecraft:pearlescent_froglight
setblock 275 158 229 minecraft:black_stained_glass
setblock 275 158 237 minecraft:black_stained_glass
setblock 275 158 261 minecraft:black_stained_glass
setblock 275 158 269 minecraft:sea_lantern
setblock 276 158 230 minecraft:black_stained_glass
setblock 276 158 232 minecraft:black_stained_glass
setblock 276 158 234 minecraft:black_stained_glass
setblock 276 158 236 minecraft:black_stained_glass
setblock 276 158 243 minecraft:black_stained_glass
setblock 276 158 245 minecraft:black_stained_glass
setblock 276 158 247 minecraft:light_blue_stained_glass
setblock 276 158 249 minecraft:black_stained_glass
setblock 276 158 251 minecraft:magenta_stained_glass
setblock 276 158 253 minecraft:black_stained_glass
setblock 276 158 262 minecraft:black_stained_glass
setblock 276 158 264 minecraft:black_stained_glass
setblock 276 158 266 minecraft:ochre_froglight
setblock 276 158 268 minecraft:cyan_stained_glass
setblock 277 158 267 minecraft:ochre_froglight
setblock 235 159 254 minecraft:magenta_concrete
fill 236 159 230 236 160 230 minecraft:light_gray_concrete
fill 236 159 232 236 160 232 minecraft:light_gray_concrete
fill 236 159 234 236 160 234 minecraft:light_gray_concrete
fill 236 159 236 236 160 236 minecraft:light_gray_concrete
fill 236 159 243 236 160 243 minecraft:light_gray_concrete
fill 236 159 245 236 160 245 minecraft:light_gray_concrete
fill 236 159 247 236 160 247 minecraft:light_gray_concrete
fill 236 159 249 236 160 249 minecraft:light_gray_concrete
fill 236 159 251 236 160 251 minecraft:light_gray_concrete
setblock 236 159 253 minecraft:light_gray_concrete
fill 236 159 262 236 160 262 minecraft:cyan_terracotta
fill 236 159 264 236 160 264 minecraft:cyan_terracotta
fill 236 159 266 236 160 266 minecraft:cyan_terracotta
fill 236 159 268 236 160 268 minecraft:cyan_terracotta
fill 237 159 229 237 160 229 minecraft:light_gray_concrete
fill 237 159 237 237 160 237 minecraft:light_gray_concrete
fill 237 159 242 237 160 242 minecraft:light_gray_concrete
fill 237 159 255 237 160 255 minecraft:light_gray_concrete
fill 237 159 261 237 160 261 minecraft:cyan_terracotta
fill 237 159 269 237 160 269 minecraft:cyan_terracotta
fill 239 159 229 239 160 229 minecraft:light_gray_concrete
fill 239 159 237 239 160 237 minecraft:light_gray_concrete
fill 239 159 242 239 160 242 minecraft:light_gray_concrete
setblock 239 159 255 minecraft:light_gray_concrete
fill 239 159 261 239 160 261 minecraft:cyan_terracotta
fill 239 159 269 239 160 269 minecraft:cyan_terracotta
fill 241 159 229 241 160 229 minecraft:light_gray_concrete
fill 241 159 237 241 160 237 minecraft:light_gray_concrete
fill 241 159 243 241 160 243 minecraft:light_gray_concrete
fill 241 159 245 241 160 245 minecraft:light_gray_concrete
fill 241 159 247 241 160 247 minecraft:light_gray_concrete
fill 241 159 249 241 160 249 minecraft:light_gray_concrete
fill 241 159 251 241 160 251 minecraft:light_gray_concrete
fill 241 159 253 241 160 253 minecraft:light_gray_concrete
fill 241 159 261 241 160 261 minecraft:cyan_terracotta
fill 241 159 269 241 160 269 minecraft:cyan_terracotta
fill 243 159 229 243 160 229 minecraft:light_gray_concrete
fill 243 159 254 251 159 254 minecraft:gray_concrete
fill 243 159 261 243 160 261 minecraft:cyan_terracotta
fill 243 159 269 243 160 269 minecraft:cyan_terracotta
setblock 244 159 230 minecraft:light_gray_concrete
fill 244 159 232 244 160 232 minecraft:light_gray_concrete
fill 244 159 234 244 160 234 minecraft:light_gray_concrete
fill 244 159 262 244 160 262 minecraft:cyan_terracotta
fill 244 159 264 244 160 264 minecraft:cyan_terracotta
fill 244 159 266 244 160 266 minecraft:cyan_terracotta
fill 244 159 268 244 160 268 minecraft:cyan_terracotta
fill 245 159 230 245 167 230 minecraft:cyan_wool
fill 245 159 255 262 159 255 minecraft:gray_concrete
fill 246 159 270 246 171 270 minecraft:black_concrete
fill 249 159 230 249 160 230 minecraft:light_gray_concrete
fill 249 159 232 249 160 232 minecraft:light_gray_concrete
fill 250 159 229 250 160 229 minecraft:light_gray_concrete
fill 250 159 234 250 160 234 minecraft:light_gray_concrete
fill 252 159 229 252 160 229 minecraft:light_gray_concrete
fill 252 159 234 252 160 234 minecraft:light_gray_concrete
fill 252 159 266 252 160 267 minecraft:cyan_terracotta
fill 253 159 256 268 159 256 minecraft:gray_concrete
fill 254 159 229 254 160 229 minecraft:light_gray_concrete
fill 254 159 234 254 160 234 minecraft:light_gray_concrete
fill 254 159 266 254 160 267 minecraft:cyan_terracotta
fill 256 159 229 256 160 229 minecraft:light_gray_concrete
fill 256 159 234 256 160 234 minecraft:light_gray_concrete
fill 256 159 266 256 160 267 minecraft:cyan_terracotta
fill 258 159 229 258 160 229 minecraft:light_gray_concrete
fill 258 159 234 258 160 234 minecraft:light_gray_concrete
fill 258 159 266 258 160 267 minecraft:cyan_terracotta
fill 260 159 229 260 160 229 minecraft:light_gray_concrete
fill 260 159 234 260 160 234 minecraft:light_gray_concrete
fill 262 159 230 262 160 230 minecraft:light_gray_concrete
fill 262 159 232 262 160 232 minecraft:light_gray_concrete
fill 268 159 230 268 160 230 minecraft:cyan_terracotta
schedule function dropper:buildpart/53_5 1t
