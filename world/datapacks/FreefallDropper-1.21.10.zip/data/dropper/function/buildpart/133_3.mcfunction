setblock 88 63 572 minecraft:calcite
fill 88 63 573 88 66 573 minecraft:cobbled_deepslate
setblock 88 63 577 minecraft:calcite
fill 88 63 578 88 66 578 minecraft:cobbled_deepslate
setblock 88 63 582 minecraft:calcite
fill 88 63 583 88 66 583 minecraft:cobbled_deepslate
setblock 88 63 587 minecraft:calcite
fill 88 63 588 88 66 588 minecraft:cobbled_deepslate
setblock 88 63 592 minecraft:calcite
fill 88 63 593 88 66 593 minecraft:cobbled_deepslate
fill 88 63 595 88 64 595 minecraft:cobbled_deepslate
setblock 48 64 560 minecraft:cobbled_deepslate
setblock 48 64 561 minecraft:calcite
fill 48 64 562 48 67 562 minecraft:cobbled_deepslate
setblock 48 64 566 minecraft:calcite
fill 48 64 567 48 67 567 minecraft:cobbled_deepslate
setblock 48 64 571 minecraft:calcite
fill 48 64 572 48 67 572 minecraft:cobbled_deepslate
setblock 48 64 576 minecraft:calcite
fill 48 64 577 48 67 577 minecraft:cobbled_deepslate
fill 48 64 579 48 65 579 minecraft:cobbled_deepslate
fill 48 64 584 48 64 585 minecraft:cobbled_deepslate
setblock 48 64 586 minecraft:calcite
fill 48 64 587 48 67 587 minecraft:cobbled_deepslate
setblock 48 64 590 minecraft:cobbled_deepslate
setblock 48 64 591 minecraft:calcite
fill 48 64 592 48 67 592 minecraft:cobbled_deepslate
setblock 48 64 596 minecraft:calcite
fill 48 64 597 50 64 598 minecraft:cobbled_deepslate
setblock 49 64 560 minecraft:calcite
fill 49 64 561 49 67 561 minecraft:cobbled_deepslate
setblock 49 64 565 minecraft:calcite
fill 49 64 566 49 67 566 minecraft:cobbled_deepslate
setblock 49 64 570 minecraft:calcite
fill 49 64 571 49 67 571 minecraft:cobbled_deepslate
setblock 49 64 575 minecraft:calcite
fill 49 64 576 49 67 576 minecraft:cobbled_deepslate
setblock 49 64 590 minecraft:calcite
fill 49 64 591 50 66 591 minecraft:cobbled_deepslate
setblock 49 64 594 minecraft:cobbled_deepslate
setblock 49 64 595 minecraft:calcite
fill 49 64 596 49 67 596 minecraft:cobbled_deepslate
setblock 50 64 558 minecraft:cobbled_deepslate
setblock 50 64 559 minecraft:calcite
fill 50 64 560 50 66 560 minecraft:cobbled_deepslate
setblock 50 64 564 minecraft:calcite
fill 50 64 565 50 67 565 minecraft:cobbled_deepslate
setblock 50 64 569 minecraft:calcite
fill 50 64 570 50 67 570 minecraft:cobbled_deepslate
setblock 50 64 574 minecraft:calcite
setblock 50 64 576 minecraft:light[level=14]
setblock 50 64 584 minecraft:light[level=14]
fill 50 64 590 50 65 590 minecraft:cobbled_deepslate
fill 50 64 592 50 64 593 minecraft:cobbled_deepslate
setblock 50 64 594 minecraft:calcite
fill 50 64 595 50 67 595 minecraft:cobbled_deepslate
setblock 51 64 558 minecraft:calcite
fill 51 64 559 51 67 559 minecraft:cobbled_deepslate
setblock 51 64 564 minecraft:cobbled_deepslate
setblock 51 64 568 minecraft:calcite
fill 51 64 569 51 67 569 minecraft:cobbled_deepslate
setblock 51 64 572 minecraft:cobbled_deepslate
fill 51 64 596 51 64 597 minecraft:cobbled_deepslate
setblock 51 64 598 minecraft:calcite
fill 52 64 558 52 67 558 minecraft:cobbled_deepslate
setblock 52 64 596 minecraft:cobbled_deepslate
setblock 52 64 597 minecraft:calcite
fill 52 64 598 52 67 598 minecraft:cobbled_deepslate
setblock 53 64 596 minecraft:calcite
fill 53 64 597 53 67 597 minecraft:cobbled_deepslate
setblock 54 64 560 minecraft:calcite
fill 54 64 596 54 67 596 minecraft:cobbled_deepslate
setblock 55 64 559 minecraft:calcite
setblock 56 64 558 minecraft:calcite
fill 56 64 559 56 65 559 minecraft:cobbled_deepslate
fill 56 64 596 56 65 596 minecraft:cobbled_deepslate
setblock 56 64 598 minecraft:calcite
fill 57 64 558 57 67 558 minecraft:cobbled_deepslate
setblock 57 64 597 minecraft:calcite
fill 57 64 598 57 67 598 minecraft:cobbled_deepslate
setblock 58 64 560 minecraft:light[level=14]
setblock 58 64 568 minecraft:light[level=14]
setblock 58 64 576 minecraft:light[level=14]
setblock 58 64 584 minecraft:light[level=14]
setblock 58 64 592 minecraft:light[level=14]
fill 58 64 597 58 67 597 minecraft:cobbled_deepslate
fill 60 64 597 60 64 598 minecraft:cobbled_deepslate
setblock 61 64 597 minecraft:cobbled_deepslate
setblock 61 64 598 minecraft:calcite
fill 62 64 598 65 64 598 minecraft:cobbled_deepslate
fill 63 64 597 66 64 597 minecraft:cobbled_deepslate
setblock 66 64 560 minecraft:light[level=14]
setblock 66 64 568 minecraft:light[level=14]
setblock 66 64 576 minecraft:light[level=14]
setblock 66 64 584 minecraft:light[level=14]
setblock 66 64 592 minecraft:light[level=14]
setblock 66 64 598 minecraft:calcite
setblock 67 64 596 minecraft:cobbled_deepslate
setblock 67 64 597 minecraft:calcite
fill 67 64 598 67 67 598 minecraft:cobbled_deepslate
fill 68 64 558 68 66 558 minecraft:cobbled_deepslate
setblock 68 64 596 minecraft:calcite
fill 68 64 597 71 64 597 minecraft:cobbled_deepslate
setblock 69 64 595 minecraft:calcite
fill 69 64 596 72 64 596 minecraft:cobbled_deepslate
fill 70 64 595 70 67 595 minecraft:cobbled_deepslate
setblock 71 64 558 minecraft:calcite
setblock 71 64 598 minecraft:calcite
fill 72 64 558 72 67 558 minecraft:cobbled_deepslate
setblock 72 64 597 minecraft:calcite
fill 72 64 598 72 67 598 minecraft:cobbled_deepslate
setblock 73 64 596 minecraft:calcite
fill 73 64 597 73 67 597 minecraft:cobbled_deepslate
setblock 74 64 560 minecraft:light[level=14]
setblock 74 64 568 minecraft:light[level=14]
setblock 74 64 576 minecraft:light[level=14]
setblock 74 64 584 minecraft:light[level=14]
setblock 74 64 592 minecraft:light[level=14]
setblock 74 64 595 minecraft:calcite
fill 74 64 596 74 67 596 minecraft:cobbled_deepslate
setblock 76 64 598 minecraft:calcite
fill 77 64 598 77 67 598 minecraft:cobbled_deepslate
setblock 82 64 560 minecraft:light[level=14]
setblock 82 64 568 minecraft:light[level=14]
setblock 82 64 576 minecraft:light[level=14]
setblock 82 64 584 minecraft:light[level=14]
setblock 82 64 592 minecraft:light[level=14]
setblock 86 64 567 minecraft:cobbled_deepslate
setblock 86 64 568 minecraft:calcite
fill 86 64 569 86 67 569 minecraft:cobbled_deepslate
setblock 86 64 573 minecraft:calcite
fill 86 64 574 88 65 574 minecraft:cobbled_deepslate
setblock 87 64 567 minecraft:calcite
fill 87 64 568 87 67 568 minecraft:cobbled_deepslate
setblock 87 64 571 minecraft:cobbled_deepslate
setblock 87 64 572 minecraft:calcite
fill 87 64 573 87 67 573 minecraft:cobbled_deepslate
fill 87 64 575 87 64 576 minecraft:cobbled_deepslate
setblock 87 64 577 minecraft:calcite
fill 87 64 578 87 67 578 minecraft:cobbled_deepslate
setblock 87 64 587 minecraft:calcite
fill 87 64 588 87 65 588 minecraft:cobbled_deepslate
setblock 87 64 592 minecraft:calcite
fill 87 64 593 87 67 593 minecraft:cobbled_deepslate
setblock 88 64 560 minecraft:cobbled_deepslate
setblock 88 64 561 minecraft:calcite
fill 88 64 562 88 67 562 minecraft:cobbled_deepslate
setblock 88 64 566 minecraft:calcite
fill 88 64 567 88 67 567 minecraft:cobbled_deepslate
setblock 88 64 571 minecraft:calcite
fill 88 64 572 88 67 572 minecraft:cobbled_deepslate
setblock 88 64 575 minecraft:cobbled_deepslate
setblock 88 64 576 minecraft:calcite
fill 88 64 577 88 67 577 minecraft:cobbled_deepslate
setblock 88 64 581 minecraft:calcite
fill 88 64 582 88 67 582 minecraft:cobbled_deepslate
setblock 88 64 586 minecraft:calcite
fill 88 64 587 88 67 587 minecraft:cobbled_deepslate
setblock 88 64 591 minecraft:calcite
fill 88 64 592 88 67 592 minecraft:cobbled_deepslate
setblock 88 64 596 minecraft:calcite
fill 88 64 597 88 67 597 minecraft:cobbled_deepslate
setblock 48 65 559 minecraft:cobbled_deepslate
setblock 48 65 560 minecraft:calcite
fill 48 65 561 48 68 561 minecraft:cobbled_deepslate
setblock 48 65 565 minecraft:calcite
fill 48 65 566 48 68 566 minecraft:cobbled_deepslate
setblock 48 65 570 minecraft:calcite
fill 48 65 571 48 68 571 minecraft:cobbled_deepslate
setblock 48 65 574 minecraft:cobbled_deepslate
setblock 48 65 575 minecraft:calcite
fill 48 65 576 48 68 576 minecraft:cobbled_deepslate
setblock 48 65 585 minecraft:calcite
fill 48 65 586 48 66 586 minecraft:cobbled_deepslate
setblock 48 65 589 minecraft:cobbled_deepslate
setblock 48 65 590 minecraft:calcite
fill 48 65 591 48 68 591 minecraft:cobbled_deepslate
setblock 48 65 594 minecraft:cobbled_deepslate
setblock 48 65 595 minecraft:calcite
fill 48 65 596 48 66 598 minecraft:cobbled_deepslate
setblock 49 65 559 minecraft:calcite
fill 49 65 560 49 68 560 minecraft:cobbled_deepslate
setblock 49 65 564 minecraft:calcite
fill 49 65 565 49 68 565 minecraft:cobbled_deepslate
setblock 49 65 569 minecraft:calcite
fill 49 65 570 49 68 570 minecraft:cobbled_deepslate
setblock 49 65 573 minecraft:cobbled_deepslate
setblock 49 65 574 minecraft:calcite
fill 49 65 575 50 67 575 minecraft:cobbled_deepslate
fill 49 65 577 49 66 577 minecraft:cobbled_deepslate
setblock 49 65 589 minecraft:calcite
fill 49 65 590 49 68 590 minecraft:cobbled_deepslate
setblock 49 65 594 minecraft:calcite
fill 49 65 595 49 68 595 minecraft:cobbled_deepslate
fill 49 65 597 49 65 598 minecraft:cobbled_deepslate
setblock 50 65 558 minecraft:calcite
fill 50 65 559 50 68 559 minecraft:cobbled_deepslate
setblock 50 65 563 minecraft:calcite
fill 50 65 564 50 67 564 minecraft:cobbled_deepslate
setblock 50 65 568 minecraft:calcite
fill 50 65 569 50 68 569 minecraft:cobbled_deepslate
setblock 50 65 573 minecraft:calcite
fill 50 65 574 50 68 574 minecraft:cobbled_deepslate
setblock 50 65 592 minecraft:cobbled_deepslate
setblock 50 65 593 minecraft:calcite
fill 50 65 594 50 68 594 minecraft:cobbled_deepslate
fill 50 65 596 50 65 597 minecraft:cobbled_deepslate
setblock 50 65 598 minecraft:calcite
fill 51 65 558 51 68 558 minecraft:cobbled_deepslate
setblock 51 65 567 minecraft:calcite
fill 51 65 568 51 66 568 minecraft:cobbled_deepslate
setblock 51 65 572 minecraft:calcite
setblock 51 65 596 minecraft:cobbled_deepslate
setblock 51 65 597 minecraft:calcite
fill 51 65 598 51 68 598 minecraft:cobbled_deepslate
setblock 52 65 596 minecraft:calcite
fill 52 65 597 52 68 597 minecraft:cobbled_deepslate
setblock 53 65 560 minecraft:calcite
fill 53 65 596 53 68 596 minecraft:cobbled_deepslate
setblock 54 65 559 minecraft:calcite
setblock 55 65 558 minecraft:calcite
fill 55 65 559 55 67 559 minecraft:cobbled_deepslate
setblock 55 65 598 minecraft:calcite
fill 56 65 558 56 68 558 minecraft:cobbled_deepslate
setblock 56 65 597 minecraft:calcite
fill 56 65 598 56 68 598 minecraft:cobbled_deepslate
setblock 57 65 596 minecraft:calcite
fill 57 65 597 57 68 597 minecraft:cobbled_deepslate
setblock 60 65 597 minecraft:cobbled_deepslate
setblock 60 65 598 minecraft:calcite
setblock 61 65 597 minecraft:calcite
fill 61 65 598 64 65 598 minecraft:cobbled_deepslate
fill 62 65 597 65 65 597 minecraft:cobbled_deepslate
fill 65 65 596 66 65 596 minecraft:cobbled_deepslate
setblock 65 65 598 minecraft:calcite
setblock 66 65 597 minecraft:calcite
fill 66 65 598 66 68 598 minecraft:cobbled_deepslate
fill 67 65 558 67 67 558 minecraft:cobbled_deepslate
setblock 67 65 596 minecraft:calcite
fill 67 65 597 70 65 597 minecraft:cobbled_deepslate
setblock 68 65 595 minecraft:calcite
fill 68 65 596 71 65 596 minecraft:cobbled_deepslate
fill 69 65 595 69 68 595 minecraft:cobbled_deepslate
setblock 70 65 558 minecraft:calcite
setblock 70 65 598 minecraft:calcite
fill 71 65 558 71 68 558 minecraft:cobbled_deepslate
fill 71 65 595 72 65 595 minecraft:cobbled_deepslate
setblock 71 65 597 minecraft:calcite
fill 71 65 598 71 68 598 minecraft:cobbled_deepslate
setblock 72 65 596 minecraft:calcite
fill 72 65 597 72 68 597 minecraft:cobbled_deepslate
setblock 73 65 595 minecraft:calcite
fill 73 65 596 73 68 596 minecraft:cobbled_deepslate
setblock 74 65 595 minecraft:cobbled_deepslate
setblock 75 65 598 minecraft:calcite
setblock 76 65 597 minecraft:calcite
fill 76 65 598 76 68 598 minecraft:cobbled_deepslate
setblock 86 65 567 minecraft:calcite
fill 86 65 568 86 68 568 minecraft:cobbled_deepslate
fill 86 65 570 86 65 571 minecraft:cobbled_deepslate
setblock 86 65 572 minecraft:calcite
fill 86 65 573 86 68 573 minecraft:cobbled_deepslate
fill 86 65 575 87 65 575 minecraft:cobbled_deepslate
setblock 87 65 566 minecraft:calcite
fill 87 65 567 87 68 567 minecraft:cobbled_deepslate
setblock 87 65 571 minecraft:calcite
fill 87 65 572 87 68 572 minecraft:cobbled_deepslate
setblock 87 65 576 minecraft:calcite
fill 87 65 577 87 68 577 minecraft:cobbled_deepslate
setblock 87 65 587 minecraft:cobbled_deepslate
setblock 87 65 591 minecraft:calcite
fill 87 65 592 87 68 592 minecraft:cobbled_deepslate
fill 87 65 594 87 66 594 minecraft:cobbled_deepslate
fill 88 65 558 88 65 559 minecraft:cobbled_deepslate
setblock 88 65 560 minecraft:calcite
fill 88 65 561 88 68 561 minecraft:cobbled_deepslate
setblock 88 65 565 minecraft:calcite
fill 88 65 566 88 68 566 minecraft:cobbled_deepslate
setblock 88 65 570 minecraft:calcite
fill 88 65 571 88 68 571 minecraft:cobbled_deepslate
setblock 88 65 575 minecraft:calcite
fill 88 65 576 88 68 576 minecraft:cobbled_deepslate
setblock 88 65 580 minecraft:calcite
fill 88 65 581 88 68 581 minecraft:cobbled_deepslate
setblock 88 65 585 minecraft:calcite
fill 88 65 586 88 68 586 minecraft:cobbled_deepslate
setblock 88 65 590 minecraft:calcite
fill 88 65 591 88 68 591 minecraft:cobbled_deepslate
setblock 88 65 595 minecraft:calcite
fill 88 65 596 88 68 596 minecraft:cobbled_deepslate
fill 88 65 598 88 66 598 minecraft:cobbled_deepslate
setblock 48 66 559 minecraft:calcite
fill 48 66 560 48 69 560 minecraft:cobbled_deepslate
setblock 48 66 564 minecraft:calcite
fill 48 66 565 48 69 565 minecraft:cobbled_deepslate
setblock 48 66 569 minecraft:calcite
fill 48 66 570 48 69 570 minecraft:cobbled_deepslate
setblock 48 66 574 minecraft:calcite
fill 48 66 575 48 69 575 minecraft:cobbled_deepslate
setblock 48 66 579 minecraft:calcite
fill 48 66 580 48 69 580 minecraft:cobbled_deepslate
setblock 48 66 589 minecraft:calcite
fill 48 66 590 48 69 590 minecraft:cobbled_deepslate
setblock 48 66 593 minecraft:cobbled_deepslate
setblock 48 66 594 minecraft:calcite
fill 48 66 595 48 69 595 minecraft:cobbled_deepslate
setblock 49 66 558 minecraft:calcite
fill 49 66 559 49 69 559 minecraft:cobbled_deepslate
setblock 49 66 563 minecraft:calcite
fill 49 66 564 49 69 564 minecraft:cobbled_deepslate
setblock 49 66 568 minecraft:calcite
fill 49 66 569 49 69 569 minecraft:cobbled_deepslate
setblock 49 66 573 minecraft:calcite
fill 49 66 574 49 69 574 minecraft:cobbled_deepslate
setblock 49 66 588 minecraft:calcite
fill 49 66 589 49 67 589 minecraft:cobbled_deepslate
setblock 49 66 593 minecraft:calcite
fill 49 66 594 49 69 594 minecraft:cobbled_deepslate
setblock 49 66 597 minecraft:cobbled_deepslate
setblock 49 66 598 minecraft:calcite
fill 50 66 558 50 69 558 minecraft:cobbled_deepslate
setblock 50 66 562 minecraft:calcite
fill 50 66 563 50 67 563 minecraft:cobbled_deepslate
setblock 50 66 567 minecraft:calcite
fill 50 66 568 50 68 568 minecraft:cobbled_deepslate
setblock 50 66 571 minecraft:cobbled_deepslate
setblock 50 66 572 minecraft:calcite
fill 50 66 573 50 69 573 minecraft:cobbled_deepslate
setblock 50 66 592 minecraft:calcite
fill 50 66 593 50 69 593 minecraft:cobbled_deepslate
setblock 50 66 596 minecraft:cobbled_deepslate
setblock 50 66 597 minecraft:calcite
fill 50 66 598 50 69 598 minecraft:cobbled_deepslate
setblock 51 66 566 minecraft:calcite
setblock 51 66 567 minecraft:cobbled_deepslate
setblock 51 66 571 minecraft:calcite
setblock 51 66 572 minecraft:cobbled_deepslate
setblock 51 66 596 minecraft:calcite
fill 51 66 597 51 69 597 minecraft:cobbled_deepslate
setblock 52 66 560 minecraft:calcite
fill 52 66 596 52 69 596 minecraft:cobbled_deepslate
setblock 53 66 559 minecraft:calcite
setblock 54 66 558 minecraft:calcite
fill 54 66 559 54 68 559 minecraft:cobbled_deepslate
setblock 54 66 598 minecraft:calcite
fill 55 66 558 55 69 558 minecraft:cobbled_deepslate
setblock 55 66 597 minecraft:calcite
fill 55 66 598 55 69 598 minecraft:cobbled_deepslate
setblock 56 66 596 minecraft:calcite
fill 56 66 597 56 69 597 minecraft:cobbled_deepslate
setblock 57 66 596 minecraft:cobbled_deepslate
setblock 59 66 558 minecraft:calcite
setblock 59 66 598 minecraft:calcite
setblock 60 66 597 minecraft:calcite
fill 60 66 598 63 66 598 minecraft:cobbled_deepslate
fill 61 66 597 64 66 597 minecraft:cobbled_deepslate
fill 64 66 596 65 66 596 minecraft:cobbled_deepslate
setblock 64 66 598 minecraft:calcite
setblock 65 66 597 minecraft:calcite
fill 65 66 598 65 69 598 minecraft:cobbled_deepslate
setblock 66 66 596 minecraft:calcite
fill 66 66 597 69 66 597 minecraft:cobbled_deepslate
setblock 67 66 595 minecraft:calcite
fill 67 66 596 70 66 596 minecraft:cobbled_deepslate
fill 68 66 595 68 69 595 minecraft:cobbled_deepslate
setblock 69 66 558 minecraft:calcite
setblock 69 66 598 minecraft:calcite
fill 70 66 558 70 69 558 minecraft:cobbled_deepslate
setblock 70 66 597 minecraft:calcite
fill 70 66 598 70 69 598 minecraft:cobbled_deepslate
setblock 71 66 595 minecraft:cobbled_deepslate
setblock 71 66 596 minecraft:calcite
fill 71 66 597 71 69 597 minecraft:cobbled_deepslate
setblock 72 66 595 minecraft:calcite
fill 72 66 596 72 69 596 minecraft:cobbled_deepslate
setblock 73 66 595 minecraft:cobbled_deepslate
setblock 74 66 598 minecraft:calcite
setblock 75 66 597 minecraft:calcite
fill 75 66 598 75 69 598 minecraft:cobbled_deepslate
setblock 76 66 597 minecraft:cobbled_deepslate
setblock 86 66 567 minecraft:cobbled_deepslate
setblock 86 66 570 minecraft:cobbled_deepslate
setblock 86 66 571 minecraft:calcite
fill 86 66 572 86 69 572 minecraft:cobbled_deepslate
fill 86 66 574 86 66 575 minecraft:cobbled_deepslate
setblock 87 66 565 minecraft:calcite
fill 87 66 566 87 69 566 minecraft:cobbled_deepslate
setblock 87 66 570 minecraft:calcite
fill 87 66 571 87 69 571 minecraft:cobbled_deepslate
setblock 87 66 574 minecraft:cobbled_deepslate
setblock 87 66 575 minecraft:calcite
fill 87 66 576 87 69 576 minecraft:cobbled_deepslate
setblock 87 66 579 minecraft:cobbled_deepslate
setblock 87 66 590 minecraft:calcite
fill 87 66 591 87 67 591 minecraft:cobbled_deepslate
fill 87 66 598 87 67 598 minecraft:cobbled_deepslate
setblock 88 66 558 minecraft:cobbled_deepslate
setblock 88 66 559 minecraft:calcite
fill 88 66 560 88 69 560 minecraft:cobbled_deepslate
setblock 88 66 564 minecraft:calcite
fill 88 66 565 88 69 565 minecraft:cobbled_deepslate
setblock 88 66 569 minecraft:calcite
fill 88 66 570 88 69 570 minecraft:cobbled_deepslate
setblock 88 66 574 minecraft:calcite
fill 88 66 575 88 69 575 minecraft:cobbled_deepslate
setblock 88 66 579 minecraft:calcite
fill 88 66 580 88 69 580 minecraft:cobbled_deepslate
setblock 88 66 584 minecraft:calcite
fill 88 66 585 88 68 585 minecraft:cobbled_deepslate
setblock 88 66 589 minecraft:calcite
fill 88 66 590 88 69 590 minecraft:cobbled_deepslate
setblock 88 66 594 minecraft:calcite
fill 88 66 595 88 69 595 minecraft:cobbled_deepslate
setblock 48 67 558 minecraft:calcite
fill 48 67 559 48 70 559 minecraft:cobbled_deepslate
setblock 48 67 563 minecraft:calcite
fill 48 67 564 48 70 564 minecraft:cobbled_deepslate
setblock 48 67 568 minecraft:calcite
fill 48 67 569 48 70 569 minecraft:cobbled_deepslate
setblock 48 67 573 minecraft:calcite
fill 48 67 574 48 70 574 minecraft:cobbled_deepslate
setblock 48 67 578 minecraft:calcite
fill 48 67 579 48 70 579 minecraft:cobbled_deepslate
setblock 48 67 588 minecraft:calcite
fill 48 67 589 48 70 589 minecraft:cobbled_deepslate
setblock 48 67 593 minecraft:calcite
fill 48 67 594 48 70 594 minecraft:cobbled_deepslate
fill 48 67 596 48 67 597 minecraft:cobbled_deepslate
setblock 48 67 598 minecraft:calcite
fill 49 67 558 49 70 558 minecraft:cobbled_deepslate
setblock 49 67 562 minecraft:calcite
fill 49 67 563 49 70 563 minecraft:cobbled_deepslate
setblock 49 67 567 minecraft:calcite
fill 49 67 568 49 70 568 minecraft:cobbled_deepslate
setblock 49 67 572 minecraft:calcite
fill 49 67 573 49 70 573 minecraft:cobbled_deepslate
setblock 49 67 577 minecraft:calcite
setblock 49 67 591 minecraft:cobbled_deepslate
setblock 49 67 592 minecraft:calcite
fill 49 67 593 49 70 593 minecraft:cobbled_deepslate
setblock 49 67 597 minecraft:calcite
fill 49 67 598 49 70 598 minecraft:cobbled_deepslate
setblock 50 67 566 minecraft:calcite
fill 50 67 567 50 68 567 minecraft:cobbled_deepslate
setblock 50 67 571 minecraft:calcite
fill 50 67 572 50 69 572 minecraft:cobbled_deepslate
setblock 50 67 591 minecraft:calcite
fill 50 67 592 50 68 592 minecraft:cobbled_deepslate
setblock 50 67 596 minecraft:calcite
fill 50 67 597 50 70 597 minecraft:cobbled_deepslate
setblock 51 67 570 minecraft:calcite
setblock 51 67 571 minecraft:cobbled_deepslate
fill 51 67 596 51 70 596 minecraft:cobbled_deepslate
setblock 52 67 559 minecraft:calcite
setblock 53 67 558 minecraft:calcite
fill 53 67 559 53 69 559 minecraft:cobbled_deepslate
setblock 53 67 598 minecraft:calcite
fill 54 67 558 54 70 558 minecraft:cobbled_deepslate
setblock 54 67 597 minecraft:calcite
fill 54 67 598 54 70 598 minecraft:cobbled_deepslate
setblock 55 67 596 minecraft:calcite
fill 55 67 597 55 70 597 minecraft:cobbled_deepslate
setblock 56 67 596 minecraft:cobbled_deepslate
setblock 58 67 558 minecraft:calcite
setblock 58 67 598 minecraft:calcite
setblock 59 67 597 minecraft:calcite
fill 59 67 598 62 67 598 minecraft:cobbled_deepslate
fill 60 67 597 63 67 597 minecraft:cobbled_deepslate
setblock 63 67 598 minecraft:calcite
setblock 64 67 596 minecraft:cobbled_deepslate
setblock 64 67 597 minecraft:calcite
fill 64 67 598 64 70 598 minecraft:cobbled_deepslate
setblock 65 67 596 minecraft:calcite
fill 65 67 597 68 67 597 minecraft:cobbled_deepslate
fill 66 67 596 69 67 596 minecraft:cobbled_deepslate
fill 67 67 595 67 69 595 minecraft:cobbled_deepslate
setblock 68 67 558 minecraft:calcite
setblock 68 67 598 minecraft:calcite
fill 69 67 558 69 70 558 minecraft:cobbled_deepslate
setblock 69 67 597 minecraft:calcite
fill 69 67 598 69 70 598 minecraft:cobbled_deepslate
setblock 70 67 596 minecraft:calcite
fill 70 67 597 70 70 597 minecraft:cobbled_deepslate
setblock 71 67 595 minecraft:calcite
fill 71 67 596 71 70 596 minecraft:cobbled_deepslate
setblock 72 67 595 minecraft:cobbled_deepslate
setblock 73 67 598 minecraft:calcite
setblock 74 67 597 minecraft:calcite
fill 74 67 598 74 70 598 minecraft:cobbled_deepslate
fill 75 67 597 75 68 597 minecraft:cobbled_deepslate
setblock 86 67 570 minecraft:calcite
fill 86 67 571 86 70 571 minecraft:cobbled_deepslate
setblock 86 67 574 minecraft:cobbled_deepslate
setblock 86 67 575 minecraft:calcite
fill 86 67 576 86 70 576 minecraft:cobbled_deepslate
setblock 87 67 558 minecraft:cobbled_deepslate
setblock 87 67 564 minecraft:calcite
fill 87 67 565 87 70 565 minecraft:cobbled_deepslate
setblock 87 67 569 minecraft:calcite
fill 87 67 570 87 70 570 minecraft:cobbled_deepslate
setblock 87 67 574 minecraft:calcite
fill 87 67 575 87 70 575 minecraft:cobbled_deepslate
setblock 87 67 579 minecraft:calcite
setblock 87 67 590 minecraft:cobbled_deepslate
setblock 87 67 594 minecraft:calcite
fill 87 67 595 87 70 595 minecraft:cobbled_deepslate
setblock 88 67 558 minecraft:calcite
fill 88 67 559 88 70 559 minecraft:cobbled_deepslate
setblock 88 67 563 minecraft:calcite
fill 88 67 564 88 70 564 minecraft:cobbled_deepslate
setblock 88 67 568 minecraft:calcite
fill 88 67 569 88 70 569 minecraft:cobbled_deepslate
setblock 88 67 573 minecraft:calcite
fill 88 67 574 88 70 574 minecraft:cobbled_deepslate
setblock 88 67 578 minecraft:calcite
fill 88 67 579 88 70 579 minecraft:cobbled_deepslate
setblock 88 67 583 minecraft:calcite
fill 88 67 584 88 68 584 minecraft:cobbled_deepslate
setblock 88 67 588 minecraft:calcite
fill 88 67 589 88 69 589 minecraft:cobbled_deepslate
setblock 88 67 593 minecraft:calcite
fill 88 67 594 88 70 594 minecraft:cobbled_deepslate
setblock 88 67 598 minecraft:calcite
fill 48 68 558 48 71 558 minecraft:cobbled_deepslate
setblock 48 68 562 minecraft:calcite
fill 48 68 563 48 71 563 minecraft:cobbled_deepslate
setblock 48 68 567 minecraft:calcite
fill 48 68 568 48 71 568 minecraft:cobbled_deepslate
setblock 48 68 572 minecraft:calcite
fill 48 68 573 48 71 573 minecraft:cobbled_deepslate
setblock 48 68 577 minecraft:calcite
fill 48 68 578 48 71 578 minecraft:cobbled_deepslate
setblock 48 68 588 minecraft:cobbled_deepslate
setblock 48 68 592 minecraft:calcite
fill 48 68 593 48 71 593 minecraft:cobbled_deepslate
setblock 48 68 596 minecraft:cobbled_deepslate
setblock 48 68 597 minecraft:calcite
fill 48 68 598 48 71 598 minecraft:cobbled_deepslate
setblock 49 68 561 minecraft:calcite
fill 49 68 562 49 71 562 minecraft:cobbled_deepslate
setblock 49 68 566 minecraft:calcite
fill 49 68 567 49 70 567 minecraft:cobbled_deepslate
setblock 49 68 571 minecraft:calcite
fill 49 68 572 49 71 572 minecraft:cobbled_deepslate
setblock 49 68 575 minecraft:cobbled_deepslate
setblock 49 68 576 minecraft:calcite
fill 49 68 577 49 71 577 minecraft:cobbled_deepslate
setblock 49 68 591 minecraft:calcite
fill 49 68 592 49 71 592 minecraft:cobbled_deepslate
setblock 49 68 596 minecraft:calcite
fill 49 68 597 49 71 597 minecraft:cobbled_deepslate
setblock 50 68 566 minecraft:cobbled_deepslate
setblock 50 68 570 minecraft:calcite
fill 50 68 571 50 69 571 minecraft:cobbled_deepslate
setblock 50 68 575 minecraft:calcite
setblock 50 68 595 minecraft:calcite
fill 50 68 596 50 71 596 minecraft:cobbled_deepslate
setblock 51 68 559 minecraft:calcite
setblock 52 68 558 minecraft:calcite
fill 52 68 559 52 71 559 minecraft:cobbled_deepslate
setblock 52 68 598 minecraft:calcite
fill 53 68 558 53 71 558 minecraft:cobbled_deepslate
setblock 53 68 597 minecraft:calcite
fill 53 68 598 53 71 598 minecraft:cobbled_deepslate
setblock 54 68 596 minecraft:calcite
fill 54 68 597 54 71 597 minecraft:cobbled_deepslate
setblock 55 68 596 minecraft:cobbled_deepslate
setblock 57 68 558 minecraft:calcite
setblock 57 68 598 minecraft:calcite
setblock 58 68 597 minecraft:calcite
fill 58 68 598 61 68 598 minecraft:cobbled_deepslate
fill 59 68 597 62 68 597 minecraft:cobbled_deepslate
fill 61 68 558 63 70 559 minecraft:light_blue_stained_glass
fill 62 68 560 62 70 561 minecraft:light_blue_stained_glass
setblock 62 68 598 minecraft:calcite
setblock 63 68 597 minecraft:calcite
fill 63 68 598 63 71 598 minecraft:cobbled_deepslate
setblock 64 68 596 minecraft:calcite
fill 64 68 597 67 68 597 minecraft:cobbled_deepslate
fill 65 68 596 68 68 596 minecraft:cobbled_deepslate
setblock 67 68 558 minecraft:calcite
setblock 67 68 598 minecraft:calcite
fill 68 68 558 68 71 558 minecraft:cobbled_deepslate
setblock 68 68 597 minecraft:calcite
fill 68 68 598 68 71 598 minecraft:cobbled_deepslate
setblock 69 68 596 minecraft:calcite
fill 69 68 597 69 71 597 minecraft:cobbled_deepslate
setblock 70 68 595 minecraft:calcite
fill 70 68 596 70 71 596 minecraft:cobbled_deepslate
setblock 71 68 595 minecraft:cobbled_deepslate
setblock 72 68 598 minecraft:calcite
setblock 73 68 597 minecraft:calcite
fill 73 68 598 73 71 598 minecraft:cobbled_deepslate
fill 74 68 597 74 69 597 minecraft:cobbled_deepslate
setblock 86 68 569 minecraft:calcite
fill 86 68 570 86 71 570 minecraft:cobbled_deepslate
setblock 86 68 574 minecraft:calcite
fill 86 68 575 86 71 575 minecraft:cobbled_deepslate
setblock 86 68 598 minecraft:cobbled_deepslate
setblock 87 68 558 minecraft:calcite
setblock 87 68 568 minecraft:calcite
fill 87 68 569 87 71 569 minecraft:cobbled_deepslate
setblock 87 68 573 minecraft:calcite
fill 87 68 574 87 71 574 minecraft:cobbled_deepslate
setblock 87 68 578 minecraft:calcite
fill 87 68 579 87 71 579 minecraft:cobbled_deepslate
setblock 87 68 593 minecraft:calcite
fill 87 68 594 87 69 594 minecraft:cobbled_deepslate
setblock 87 68 598 minecraft:calcite
fill 88 68 558 88 71 558 minecraft:cobbled_deepslate
setblock 88 68 562 minecraft:calcite
fill 88 68 563 88 71 563 minecraft:cobbled_deepslate
setblock 88 68 567 minecraft:calcite
fill 88 68 568 88 71 568 minecraft:cobbled_deepslate
setblock 88 68 572 minecraft:calcite
fill 88 68 573 88 71 573 minecraft:cobbled_deepslate
setblock 88 68 577 minecraft:calcite
fill 88 68 578 88 71 578 minecraft:cobbled_deepslate
setblock 88 68 582 minecraft:calcite
setblock 88 68 583 minecraft:cobbled_deepslate
setblock 88 68 587 minecraft:calcite
fill 88 68 588 88 69 588 minecraft:cobbled_deepslate
setblock 88 68 592 minecraft:calcite
fill 88 68 593 88 71 593 minecraft:cobbled_deepslate
setblock 88 68 597 minecraft:calcite
fill 88 68 598 88 71 598 minecraft:cobbled_deepslate
setblock 48 69 561 minecraft:calcite
fill 48 69 562 48 72 562 minecraft:cobbled_deepslate
setblock 48 69 566 minecraft:calcite
fill 48 69 567 48 72 567 minecraft:cobbled_deepslate
setblock 48 69 571 minecraft:calcite
fill 48 69 572 48 72 572 minecraft:cobbled_deepslate
setblock 48 69 576 minecraft:calcite
fill 48 69 577 48 72 577 minecraft:cobbled_deepslate
setblock 48 69 591 minecraft:calcite
fill 48 69 592 48 72 592 minecraft:cobbled_deepslate
setblock 48 69 596 minecraft:calcite
fill 48 69 597 48 72 597 minecraft:cobbled_deepslate
setblock 49 69 560 minecraft:calcite
fill 49 69 561 49 72 561 minecraft:cobbled_deepslate
setblock 49 69 565 minecraft:calcite
fill 49 69 566 49 70 566 minecraft:cobbled_deepslate
setblock 49 69 570 minecraft:calcite
fill 49 69 571 49 72 571 minecraft:cobbled_deepslate
setblock 49 69 575 minecraft:calcite
fill 49 69 576 49 72 576 minecraft:cobbled_deepslate
setblock 49 69 591 minecraft:cobbled_deepslate
setblock 49 69 595 minecraft:calcite
fill 49 69 596 49 72 596 minecraft:cobbled_deepslate
setblock 50 69 559 minecraft:calcite
setblock 50 69 569 minecraft:calcite
setblock 50 69 570 minecraft:cobbled_deepslate
setblock 50 69 574 minecraft:calcite
setblock 50 69 594 minecraft:calcite
fill 50 69 595 50 72 595 minecraft:cobbled_deepslate
setblock 51 69 558 minecraft:calcite
fill 51 69 559 51 72 559 minecraft:cobbled_deepslate
setblock 51 69 598 minecraft:calcite
fill 52 69 558 52 72 558 minecraft:cobbled_deepslate
setblock 52 69 597 minecraft:calcite
fill 52 69 598 52 72 598 minecraft:cobbled_deepslate
setblock 53 69 596 minecraft:calcite
fill 53 69 597 53 72 597 minecraft:cobbled_deepslate
setblock 54 69 596 minecraft:cobbled_deepslate
setblock 56 69 558 minecraft:calcite
setblock 56 69 598 minecraft:calcite
setblock 57 69 597 minecraft:calcite
fill 57 69 598 60 69 598 minecraft:cobbled_deepslate
fill 58 69 597 61 69 597 minecraft:cobbled_deepslate
fill 61 69 560 61 69 561 minecraft:light_blue_stained_glass
setblock 61 69 598 minecraft:calcite
fill 62 69 562 62 69 563 minecraft:light_blue_stained_glass
setblock 62 69 597 minecraft:calcite
fill 62 69 598 62 72 598 minecraft:cobbled_deepslate
fill 63 69 560 63 69 561 minecraft:light_blue_stained_glass
fill 63 69 597 66 69 597 minecraft:cobbled_deepslate
fill 64 69 596 67 69 596 minecraft:cobbled_deepslate
setblock 66 69 558 minecraft:calcite
setblock 66 69 598 minecraft:calcite
fill 67 69 558 67 72 558 minecraft:cobbled_deepslate
setblock 67 69 597 minecraft:calcite
fill 67 69 598 67 72 598 minecraft:cobbled_deepslate
setblock 68 69 596 minecraft:calcite
fill 68 69 597 68 72 597 minecraft:cobbled_deepslate
setblock 69 69 595 minecraft:calcite
fill 69 69 596 69 72 596 minecraft:cobbled_deepslate
setblock 70 69 595 minecraft:cobbled_deepslate
setblock 71 69 558 minecraft:calcite
setblock 71 69 598 minecraft:calcite
setblock 72 69 597 minecraft:calcite
fill 72 69 598 72 72 598 minecraft:cobbled_deepslate
fill 73 69 597 73 71 597 minecraft:cobbled_deepslate
setblock 86 69 558 minecraft:calcite
fill 86 69 569 86 70 569 minecraft:cobbled_deepslate
setblock 86 69 573 minecraft:calcite
fill 86 69 574 86 72 574 minecraft:cobbled_deepslate
setblock 86 69 577 minecraft:cobbled_deepslate
setblock 86 69 598 minecraft:calcite
fill 87 69 558 87 72 558 minecraft:cobbled_deepslate
setblock 87 69 567 minecraft:calcite
fill 87 69 568 87 72 568 minecraft:cobbled_deepslate
setblock 87 69 572 minecraft:calcite
fill 87 69 573 87 72 573 minecraft:cobbled_deepslate
setblock 87 69 577 minecraft:calcite
fill 87 69 578 87 72 578 minecraft:cobbled_deepslate
setblock 87 69 596 minecraft:cobbled_deepslate
fill 87 69 598 87 72 598 minecraft:cobbled_deepslate
setblock 88 69 561 minecraft:calcite
fill 88 69 562 88 72 562 minecraft:cobbled_deepslate
setblock 88 69 566 minecraft:calcite
fill 88 69 567 88 72 567 minecraft:cobbled_deepslate
setblock 88 69 571 minecraft:calcite
fill 88 69 572 88 72 572 minecraft:cobbled_deepslate
setblock 88 69 576 minecraft:calcite
fill 88 69 577 88 72 577 minecraft:cobbled_deepslate
setblock 88 69 581 minecraft:calcite
fill 88 69 582 88 72 582 minecraft:cobbled_deepslate
setblock 88 69 591 minecraft:calcite
fill 88 69 592 88 72 592 minecraft:cobbled_deepslate
setblock 88 69 596 minecraft:calcite
fill 88 69 597 88 72 597 minecraft:cobbled_deepslate
setblock 48 70 560 minecraft:calcite
fill 48 70 561 48 73 561 minecraft:cobbled_deepslate
setblock 48 70 565 minecraft:calcite
fill 48 70 566 48 73 566 minecraft:cobbled_deepslate
setblock 48 70 570 minecraft:calcite
fill 48 70 571 48 73 571 minecraft:cobbled_deepslate
setblock 48 70 575 minecraft:calcite
fill 48 70 576 48 73 576 minecraft:cobbled_deepslate
setblock 48 70 580 minecraft:calcite
setblock 48 70 590 minecraft:calcite
fill 48 70 591 48 73 591 minecraft:cobbled_deepslate
setblock 48 70 595 minecraft:calcite
fill 48 70 596 48 73 596 minecraft:cobbled_deepslate
setblock 49 70 559 minecraft:calcite
fill 49 70 560 49 73 560 minecraft:cobbled_deepslate
setblock 49 70 564 minecraft:calcite
setblock 49 70 565 minecraft:cobbled_deepslate
setblock 49 70 569 minecraft:calcite
fill 49 70 570 49 72 570 minecraft:cobbled_deepslate
setblock 49 70 574 minecraft:calcite
fill 49 70 575 49 73 575 minecraft:cobbled_deepslate
setblock 49 70 594 minecraft:calcite
fill 49 70 595 49 73 595 minecraft:cobbled_deepslate
setblock 50 70 558 minecraft:calcite
fill 50 70 559 50 73 559 minecraft:cobbled_deepslate
setblock 50 70 594 minecraft:cobbled_deepslate
setblock 50 70 598 minecraft:calcite
fill 51 70 558 51 73 558 minecraft:cobbled_deepslate
setblock 51 70 597 minecraft:calcite
fill 51 70 598 51 73 598 minecraft:cobbled_deepslate
setblock 52 70 596 minecraft:calcite
fill 52 70 597 52 73 597 minecraft:cobbled_deepslate
setblock 53 70 596 minecraft:cobbled_deepslate
setblock 55 70 558 minecraft:calcite
setblock 55 70 598 minecraft:calcite
fill 56 70 558 56 73 558 minecraft:cobbled_deepslate
setblock 56 70 597 minecraft:calcite
fill 56 70 598 59 70 598 minecraft:cobbled_deepslate
fill 57 70 597 60 70 597 minecraft:cobbled_deepslate
setblock 60 70 598 minecraft:calcite
setblock 61 70 560 minecraft:light_blue_stained_glass
setblock 61 70 597 minecraft:calcite
fill 61 70 598 61 73 598 minecraft:cobbled_deepslate
fill 62 70 597 65 70 597 minecraft:cobbled_deepslate
setblock 63 70 560 minecraft:light_blue_stained_glass
fill 64 70 596 66 70 596 minecraft:cobbled_deepslate
setblock 65 70 598 minecraft:calcite
fill 66 70 558 66 73 558 minecraft:cobbled_deepslate
setblock 66 70 597 minecraft:calcite
fill 66 70 598 66 73 598 minecraft:cobbled_deepslate
setblock 67 70 596 minecraft:calcite
fill 67 70 597 67 73 597 minecraft:cobbled_deepslate
setblock 68 70 595 minecraft:calcite
fill 68 70 596 68 73 596 minecraft:cobbled_deepslate
setblock 70 70 558 minecraft:calcite
setblock 70 70 598 minecraft:calcite
setblock 71 70 597 minecraft:calcite
fill 71 70 598 71 73 598 minecraft:cobbled_deepslate
setblock 72 70 596 minecraft:calcite
fill 72 70 597 72 73 597 minecraft:cobbled_deepslate
setblock 75 70 598 minecraft:calcite
setblock 85 70 558 minecraft:calcite
setblock 85 70 598 minecraft:calcite
fill 86 70 558 86 73 558 minecraft:cobbled_deepslate
setblock 86 70 572 minecraft:calcite
fill 86 70 573 86 73 573 minecraft:cobbled_deepslate
setblock 86 70 577 minecraft:calcite
fill 86 70 598 86 73 598 minecraft:cobbled_deepslate
setblock 87 70 566 minecraft:calcite
fill 87 70 567 87 73 567 minecraft:cobbled_deepslate
setblock 87 70 571 minecraft:calcite
fill 87 70 572 87 73 572 minecraft:cobbled_deepslate
setblock 87 70 576 minecraft:calcite
fill 87 70 577 87 73 577 minecraft:cobbled_deepslate
setblock 87 70 596 minecraft:calcite
setblock 88 70 560 minecraft:calcite
fill 88 70 561 88 73 561 minecraft:cobbled_deepslate
setblock 88 70 565 minecraft:calcite
fill 88 70 566 88 73 566 minecraft:cobbled_deepslate
setblock 88 70 570 minecraft:calcite
fill 88 70 571 88 73 571 minecraft:cobbled_deepslate
setblock 88 70 575 minecraft:calcite
fill 88 70 576 88 73 576 minecraft:cobbled_deepslate
setblock 88 70 580 minecraft:calcite
fill 88 70 581 88 73 581 minecraft:cobbled_deepslate
setblock 88 70 590 minecraft:calcite
fill 88 70 591 88 71 591 minecraft:cobbled_deepslate
setblock 88 70 595 minecraft:calcite
fill 88 70 596 88 73 596 minecraft:cobbled_deepslate
setblock 48 71 559 minecraft:calcite
fill 48 71 560 48 74 560 minecraft:cobbled_deepslate
setblock 48 71 564 minecraft:calcite
fill 48 71 565 48 74 565 minecraft:cobbled_deepslate
setblock 48 71 569 minecraft:calcite
fill 48 71 570 48 74 570 minecraft:cobbled_deepslate
setblock 48 71 574 minecraft:calcite
fill 48 71 575 48 74 575 minecraft:cobbled_deepslate
setblock 48 71 579 minecraft:calcite
fill 48 71 580 48 74 580 minecraft:cobbled_deepslate
fill 48 71 590 48 72 590 minecraft:cobbled_deepslate
setblock 48 71 594 minecraft:calcite
fill 48 71 595 48 74 595 minecraft:cobbled_deepslate
setblock 49 71 558 minecraft:calcite
fill 49 71 559 49 74 559 minecraft:cobbled_deepslate
setblock 49 71 568 minecraft:calcite
setblock 49 71 569 minecraft:cobbled_deepslate
setblock 49 71 573 minecraft:calcite
fill 49 71 574 49 74 574 minecraft:cobbled_deepslate
setblock 49 71 593 minecraft:calcite
fill 49 71 594 49 74 594 minecraft:cobbled_deepslate
setblock 49 71 598 minecraft:calcite
fill 50 71 558 50 74 558 minecraft:cobbled_deepslate
setblock 50 71 597 minecraft:calcite
fill 50 71 598 50 74 598 minecraft:cobbled_deepslate
setblock 51 71 596 minecraft:calcite
fill 51 71 597 51 74 597 minecraft:cobbled_deepslate
fill 52 71 596 52 72 596 minecraft:cobbled_deepslate
setblock 54 71 558 minecraft:calcite
setblock 54 71 598 minecraft:calcite
fill 55 71 558 55 74 558 minecraft:cobbled_deepslate
setblock 55 71 597 minecraft:calcite
fill 55 71 598 58 71 598 minecraft:cobbled_deepslate
fill 56 71 597 59 71 597 minecraft:cobbled_deepslate
setblock 59 71 598 minecraft:calcite
setblock 60 71 597 minecraft:calcite
fill 60 71 598 60 74 598 minecraft:cobbled_deepslate
fill 61 71 558 63 71 558 minecraft:light_blue_stained_glass
fill 61 71 597 64 71 597 minecraft:cobbled_deepslate
setblock 62 71 559 minecraft:light_blue_stained_glass
fill 63 71 596 65 71 596 minecraft:cobbled_deepslate
setblock 64 71 558 minecraft:calcite
setblock 64 71 598 minecraft:calcite
fill 65 71 558 65 74 558 minecraft:cobbled_deepslate
setblock 65 71 597 minecraft:calcite
fill 65 71 598 65 74 598 minecraft:cobbled_deepslate
setblock 66 71 596 minecraft:calcite
fill 66 71 597 66 74 597 minecraft:cobbled_deepslate
fill 67 71 596 67 74 596 minecraft:cobbled_deepslate
setblock 69 71 558 minecraft:calcite
setblock 69 71 598 minecraft:calcite
fill 70 71 558 70 74 558 minecraft:cobbled_deepslate
setblock 70 71 597 minecraft:calcite
fill 70 71 598 70 74 598 minecraft:cobbled_deepslate
setblock 71 71 596 minecraft:calcite
fill 71 71 597 71 74 597 minecraft:cobbled_deepslate
setblock 74 71 598 minecraft:calcite
fill 82 71 560 83 71 563 minecraft:diamond_block
fill 82 71 583 83 71 587 minecraft:diamond_block
fill 83 71 559 86 71 559 minecraft:diamond_block
fill 83 71 564 87 71 564 minecraft:diamond_block
fill 83 71 582 87 72 582 minecraft:diamond_block
setblock 84 71 558 minecraft:calcite
fill 84 71 563 84 73 563 minecraft:diamond_block
fill 84 71 581 87 71 581 minecraft:diamond_block
fill 84 71 587 87 71 588 minecraft:diamond_block
setblock 84 71 598 minecraft:calcite
fill 85 71 558 85 74 558 minecraft:cobbled_deepslate
setblock 85 71 565 minecraft:diamond_block
fill 85 71 598 85 74 598 minecraft:cobbled_deepslate
setblock 86 71 571 minecraft:calcite
fill 86 71 572 86 74 572 minecraft:cobbled_deepslate
setblock 86 71 576 minecraft:calcite
fill 86 71 577 86 74 577 minecraft:cobbled_deepslate
setblock 87 71 559 minecraft:cobbled_deepslate
fill 87 71 560 87 71 563 minecraft:diamond_block
fill 87 71 566 87 74 566 minecraft:cobbled_deepslate
setblock 87 71 570 minecraft:calcite
fill 87 71 571 87 74 571 minecraft:cobbled_deepslate
setblock 87 71 575 minecraft:calcite
fill 87 71 576 87 74 576 minecraft:cobbled_deepslate
setblock 87 71 580 minecraft:calcite
fill 87 71 583 88 72 583 minecraft:diamond_block
fill 87 71 586 88 72 586 minecraft:diamond_block
fill 87 71 596 87 73 597 minecraft:cobbled_deepslate
setblock 88 71 559 minecraft:calcite
fill 88 71 560 88 74 560 minecraft:cobbled_deepslate
setblock 88 71 564 minecraft:calcite
fill 88 71 565 88 74 565 minecraft:cobbled_deepslate
setblock 88 71 569 minecraft:calcite
fill 88 71 570 88 74 570 minecraft:cobbled_deepslate
setblock 88 71 574 minecraft:calcite
fill 88 71 575 88 74 575 minecraft:cobbled_deepslate
setblock 88 71 579 minecraft:calcite
fill 88 71 580 88 74 580 minecraft:cobbled_deepslate
fill 88 71 584 88 73 585 minecraft:diamond_block
setblock 88 71 587 minecraft:diamond_block
setblock 88 71 594 minecraft:calcite
fill 88 71 595 88 74 595 minecraft:cobbled_deepslate
setblock 48 72 558 minecraft:calcite
fill 48 72 559 48 74 559 minecraft:cobbled_deepslate
setblock 48 72 563 minecraft:calcite
fill 48 72 564 48 74 564 minecraft:cobbled_deepslate
setblock 48 72 568 minecraft:calcite
fill 48 72 569 48 74 569 minecraft:cobbled_deepslate
setblock 48 72 573 minecraft:calcite
fill 48 72 574 48 74 574 minecraft:cobbled_deepslate
setblock 48 72 578 minecraft:calcite
fill 48 72 579 48 74 579 minecraft:cobbled_deepslate
setblock 48 72 593 minecraft:calcite
fill 48 72 594 48 74 594 minecraft:cobbled_deepslate
setblock 48 72 598 minecraft:calcite
fill 49 72 558 49 74 558 minecraft:cobbled_deepslate
setblock 49 72 562 minecraft:calcite
setblock 49 72 572 minecraft:calcite
fill 49 72 573 49 74 573 minecraft:cobbled_deepslate
setblock 49 72 577 minecraft:calcite
fill 49 72 593 49 74 593 minecraft:cobbled_deepslate
setblock 49 72 597 minecraft:calcite
fill 49 72 598 49 74 598 minecraft:cobbled_deepslate
setblock 50 72 560 minecraft:light[level=14]
setblock 50 72 568 minecraft:light[level=14]
setblock 50 72 576 minecraft:light[level=14]
setblock 50 72 584 minecraft:light[level=14]
setblock 50 72 592 minecraft:light[level=14]
setblock 50 72 596 minecraft:calcite
fill 50 72 597 50 74 597 minecraft:cobbled_deepslate
fill 51 72 596 51 74 596 minecraft:cobbled_deepslate
setblock 52 72 559 minecraft:calcite
setblock 53 72 558 minecraft:calcite
setblock 53 72 598 minecraft:calcite
fill 54 72 558 54 74 558 minecraft:cobbled_deepslate
setblock 54 72 597 minecraft:calcite
fill 54 72 598 57 72 598 minecraft:cobbled_deepslate
fill 55 72 597 58 72 597 minecraft:cobbled_deepslate
setblock 58 72 560 minecraft:light[level=14]
setblock 58 72 568 minecraft:light[level=14]
setblock 58 72 576 minecraft:light[level=14]
setblock 58 72 584 minecraft:light[level=14]
setblock 58 72 592 minecraft:light[level=14]
setblock 58 72 598 minecraft:calcite
setblock 59 72 597 minecraft:calcite
fill 59 72 598 59 74 598 minecraft:cobbled_deepslate
fill 60 72 597 63 72 597 minecraft:cobbled_deepslate
setblock 63 72 558 minecraft:calcite
fill 63 72 596 64 72 596 minecraft:cobbled_deepslate
setblock 63 72 598 minecraft:calcite
fill 64 72 558 64 74 558 minecraft:cobbled_deepslate
setblock 64 72 597 minecraft:calcite
fill 64 72 598 64 74 598 minecraft:cobbled_deepslate
setblock 65 72 596 minecraft:calcite
fill 65 72 597 65 74 597 minecraft:cobbled_deepslate
setblock 66 72 560 minecraft:light[level=14]
setblock 66 72 568 minecraft:light[level=14]
setblock 66 72 576 minecraft:light[level=14]
setblock 66 72 584 minecraft:light[level=14]
setblock 66 72 592 minecraft:light[level=14]
fill 66 72 596 66 74 596 minecraft:cobbled_deepslate
setblock 68 72 558 minecraft:calcite
setblock 68 72 598 minecraft:calcite
fill 69 72 558 69 74 558 minecraft:cobbled_deepslate
setblock 69 72 597 minecraft:calcite
fill 69 72 598 69 74 598 minecraft:cobbled_deepslate
setblock 70 72 596 minecraft:calcite
fill 70 72 597 70 74 597 minecraft:cobbled_deepslate
setblock 73 72 598 minecraft:calcite
setblock 74 72 560 minecraft:light[level=14]
setblock 74 72 568 minecraft:light[level=14]
setblock 74 72 576 minecraft:light[level=14]
setblock 74 72 584 minecraft:light[level=14]
setblock 74 72 592 minecraft:light[level=14]
fill 74 72 598 74 73 598 minecraft:cobbled_deepslate
setblock 82 72 560 minecraft:light[level=14]
setblock 82 72 568 minecraft:light[level=14]
setblock 82 72 576 minecraft:light[level=14]
fill 82 72 584 83 72 585 minecraft:diamond_block
setblock 82 72 592 minecraft:light[level=14]
setblock 83 72 558 minecraft:calcite
fill 83 72 560 83 72 563 minecraft:diamond_block
fill 83 72 583 83 73 583 minecraft:diamond_block
fill 83 72 586 83 72 587 minecraft:diamond_block
fill 84 72 558 84 74 558 minecraft:cobbled_deepslate
fill 84 72 559 85 72 559 minecraft:diamond_block
fill 84 72 564 86 72 564 minecraft:diamond_block
fill 84 72 587 87 72 587 minecraft:diamond_block
fill 84 72 598 84 74 598 minecraft:cobbled_deepslate
setblock 86 72 559 minecraft:cobbled_deepslate
setblock 86 72 570 minecraft:calcite
fill 86 72 571 86 74 571 minecraft:cobbled_deepslate
setblock 86 72 575 minecraft:calcite
fill 86 72 576 86 74 576 minecraft:cobbled_deepslate
fill 86 72 578 86 73 578 minecraft:cobbled_deepslate
fill 86 72 597 86 74 597 minecraft:cobbled_deepslate
setblock 87 72 559 minecraft:calcite
fill 87 72 560 87 73 562 minecraft:cobbled_deepslate
setblock 87 72 563 minecraft:diamond_block
fill 87 72 565 87 74 565 minecraft:cobbled_deepslate
setblock 87 72 569 minecraft:calcite
fill 87 72 570 87 74 570 minecraft:cobbled_deepslate
setblock 87 72 574 minecraft:calcite
fill 87 72 575 87 74 575 minecraft:cobbled_deepslate
setblock 87 72 579 minecraft:calcite
fill 87 72 580 87 74 580 minecraft:cobbled_deepslate
setblock 88 72 558 minecraft:calcite
fill 88 72 559 88 74 559 minecraft:cobbled_deepslate
setblock 88 72 563 minecraft:calcite
fill 88 72 564 88 74 564 minecraft:cobbled_deepslate
setblock 88 72 568 minecraft:calcite
fill 88 72 569 88 74 569 minecraft:cobbled_deepslate
setblock 88 72 573 minecraft:calcite
fill 88 72 574 88 74 574 minecraft:cobbled_deepslate
setblock 88 72 578 minecraft:calcite
fill 88 72 579 88 74 579 minecraft:cobbled_deepslate
setblock 88 72 593 minecraft:calcite
fill 88 72 594 88 74 594 minecraft:cobbled_deepslate
setblock 88 72 598 minecraft:calcite
fill 48 73 558 48 74 558 minecraft:cobbled_deepslate
setblock 48 73 562 minecraft:calcite
fill 48 73 563 48 74 563 minecraft:cobbled_deepslate
setblock 48 73 567 minecraft:calcite
fill 48 73 568 48 74 568 minecraft:cobbled_deepslate
setblock 48 73 572 minecraft:calcite
fill 48 73 573 48 74 573 minecraft:cobbled_deepslate
setblock 48 73 577 minecraft:calcite
fill 48 73 578 48 74 578 minecraft:cobbled_deepslate
setblock 48 73 581 minecraft:cobbled_deepslate
setblock 48 73 592 minecraft:calcite
fill 48 73 593 48 74 593 minecraft:cobbled_deepslate
setblock 48 73 597 minecraft:calcite
fill 48 73 598 48 74 598 minecraft:cobbled_deepslate
setblock 49 73 561 minecraft:calcite
fill 49 73 562 49 74 562 minecraft:cobbled_deepslate
setblock 49 73 572 minecraft:cobbled_deepslate
setblock 49 73 576 minecraft:calcite
fill 49 73 577 49 74 577 minecraft:cobbled_deepslate
setblock 49 73 596 minecraft:calcite
fill 49 73 597 49 74 597 minecraft:cobbled_deepslate
setblock 50 73 595 minecraft:calcite
fill 50 73 596 50 74 596 minecraft:cobbled_deepslate
setblock 51 73 559 minecraft:calcite
setblock 52 73 558 minecraft:calcite
fill 52 73 559 52 74 559 minecraft:cobbled_deepslate
setblock 52 73 598 minecraft:calcite
fill 53 73 558 53 74 558 minecraft:cobbled_deepslate
setblock 53 73 597 minecraft:calcite
fill 53 73 598 56 73 598 minecraft:cobbled_deepslate
fill 54 73 597 57 73 597 minecraft:cobbled_deepslate
setblock 57 73 558 minecraft:calcite
setblock 57 73 598 minecraft:calcite
setblock 58 73 597 minecraft:calcite
fill 58 73 598 58 74 598 minecraft:cobbled_deepslate
fill 59 73 597 62 73 597 minecraft:cobbled_deepslate
setblock 61 73 558 minecraft:cobbled_deepslate
setblock 62 73 558 minecraft:calcite
setblock 62 73 598 minecraft:calcite
fill 63 73 558 63 74 558 minecraft:cobbled_deepslate
setblock 63 73 596 minecraft:cobbled_deepslate
setblock 63 73 597 minecraft:calcite
fill 63 73 598 63 74 598 minecraft:cobbled_deepslate
setblock 64 73 596 minecraft:calcite
fill 64 73 597 64 74 597 minecraft:cobbled_deepslate
fill 65 73 596 65 74 596 minecraft:cobbled_deepslate
setblock 67 73 558 minecraft:calcite
setblock 67 73 598 minecraft:calcite
fill 68 73 558 68 74 558 minecraft:cobbled_deepslate
setblock 68 73 597 minecraft:calcite
fill 68 73 598 68 74 598 minecraft:cobbled_deepslate
setblock 69 73 596 minecraft:calcite
fill 69 73 597 69 74 597 minecraft:cobbled_deepslate
setblock 71 73 558 minecraft:cobbled_deepslate
setblock 72 73 598 minecraft:calcite
fill 73 73 598 73 74 598 minecraft:cobbled_deepslate
setblock 82 73 558 minecraft:calcite
fill 83 73 558 83 74 558 minecraft:cobbled_deepslate
fill 83 73 560 83 73 562 minecraft:diamond_block
fill 83 73 584 83 73 586 minecraft:diamond_block
fill 83 73 598 83 74 598 minecraft:cobbled_deepslate
fill 84 73 587 86 73 587 minecraft:diamond_block
setblock 85 73 559 minecraft:cobbled_deepslate
fill 85 73 582 86 73 582 minecraft:diamond_block
setblock 86 73 559 minecraft:calcite
fill 86 73 570 86 74 570 minecraft:cobbled_deepslate
setblock 86 73 574 minecraft:calcite
fill 86 73 575 86 74 575 minecraft:cobbled_deepslate
setblock 86 73 579 minecraft:calcite
setblock 87 73 558 minecraft:calcite
fill 87 73 559 87 74 559 minecraft:cobbled_deepslate
setblock 87 73 563 minecraft:calcite
fill 87 73 564 87 74 564 minecraft:cobbled_deepslate
setblock 87 73 568 minecraft:calcite
fill 87 73 569 87 74 569 minecraft:cobbled_deepslate
setblock 87 73 573 minecraft:calcite
fill 87 73 574 87 74 574 minecraft:cobbled_deepslate
setblock 87 73 578 minecraft:calcite
fill 87 73 579 87 74 579 minecraft:cobbled_deepslate
fill 87 73 581 87 74 581 minecraft:cobbled_deepslate
setblock 87 73 583 minecraft:diamond_block
setblock 87 73 586 minecraft:diamond_block
fill 87 73 595 87 74 595 minecraft:cobbled_deepslate
setblock 87 73 598 minecraft:calcite
fill 88 73 558 88 74 558 minecraft:cobbled_deepslate
setblock 88 73 562 minecraft:calcite
fill 88 73 563 88 74 563 minecraft:cobbled_deepslate
setblock 88 73 567 minecraft:calcite
fill 88 73 568 88 74 568 minecraft:cobbled_deepslate
setblock 88 73 572 minecraft:calcite
fill 88 73 573 88 74 573 minecraft:cobbled_deepslate
setblock 88 73 577 minecraft:calcite
fill 88 73 578 88 74 578 minecraft:cobbled_deepslate
setblock 88 73 582 minecraft:calcite
fill 88 73 583 88 74 583 minecraft:cobbled_deepslate
setblock 88 73 592 minecraft:calcite
fill 88 73 593 88 74 593 minecraft:cobbled_deepslate
setblock 88 73 597 minecraft:calcite
fill 88 73 598 88 74 598 minecraft:cobbled_deepslate
setblock 48 74 561 minecraft:calcite
setblock 48 74 562 minecraft:cobbled_deepslate
setblock 48 74 566 minecraft:calcite
setblock 48 74 567 minecraft:cobbled_deepslate
setblock 48 74 571 minecraft:calcite
setblock 48 74 572 minecraft:cobbled_deepslate
setblock 48 74 576 minecraft:calcite
setblock 48 74 577 minecraft:cobbled_deepslate
setblock 48 74 581 minecraft:calcite
setblock 48 74 582 minecraft:cobbled_deepslate
setblock 48 74 591 minecraft:calcite
setblock 48 74 592 minecraft:cobbled_deepslate
setblock 48 74 596 minecraft:calcite
setblock 48 74 597 minecraft:cobbled_deepslate
setblock 49 74 560 minecraft:calcite
setblock 49 74 561 minecraft:cobbled_deepslate
setblock 49 74 563 minecraft:cobbled_deepslate
setblock 49 74 575 minecraft:calcite
setblock 49 74 576 minecraft:cobbled_deepslate
setblock 49 74 578 minecraft:cobbled_deepslate
setblock 49 74 595 minecraft:calcite
setblock 49 74 596 minecraft:cobbled_deepslate
setblock 50 74 559 minecraft:calcite
setblock 51 74 558 minecraft:calcite
setblock 51 74 559 minecraft:cobbled_deepslate
setblock 51 74 598 minecraft:calcite
setblock 52 74 558 minecraft:cobbled_deepslate
setblock 52 74 597 minecraft:calcite
fill 52 74 598 55 74 598 minecraft:cobbled_deepslate
setblock 53 74 559 minecraft:cobbled_deepslate
fill 53 74 597 56 74 597 minecraft:cobbled_deepslate
setblock 56 74 558 minecraft:calcite
setblock 56 74 598 minecraft:calcite
fill 57 74 558 60 74 558 minecraft:cobbled_deepslate
setblock 57 74 597 minecraft:calcite
setblock 57 74 598 minecraft:cobbled_deepslate
fill 58 74 597 61 74 597 minecraft:cobbled_deepslate
setblock 61 74 558 minecraft:calcite
setblock 61 74 598 minecraft:calcite
setblock 62 74 558 minecraft:cobbled_deepslate
setblock 62 74 596 minecraft:cobbled_deepslate
setblock 62 74 597 minecraft:calcite
setblock 62 74 598 minecraft:cobbled_deepslate
setblock 63 74 596 minecraft:calcite
setblock 63 74 597 minecraft:cobbled_deepslate
setblock 64 74 596 minecraft:cobbled_deepslate
setblock 66 74 558 minecraft:calcite
setblock 66 74 598 minecraft:calcite
setblock 67 74 558 minecraft:cobbled_deepslate
setblock 67 74 597 minecraft:calcite
setblock 67 74 598 minecraft:cobbled_deepslate
setblock 68 74 596 minecraft:calcite
setblock 68 74 597 minecraft:cobbled_deepslate
setblock 69 74 596 minecraft:cobbled_deepslate
setblock 71 74 558 minecraft:calcite
setblock 71 74 598 minecraft:calcite
setblock 72 74 598 minecraft:cobbled_deepslate
setblock 81 74 558 minecraft:calcite
setblock 82 74 558 minecraft:cobbled_deepslate
setblock 82 74 598 minecraft:cobbled_deepslate
fill 83 74 559 84 74 559 minecraft:cobbled_deepslate
fill 85 74 559 85 74 560 minecraft:calcite
setblock 85 74 597 minecraft:cobbled_deepslate
setblock 86 74 558 minecraft:calcite
fill 86 74 559 86 74 560 minecraft:cobbled_deepslate
setblock 86 74 573 minecraft:calcite
setblock 86 74 574 minecraft:cobbled_deepslate
setblock 86 74 578 minecraft:calcite
setblock 86 74 579 minecraft:cobbled_deepslate
setblock 86 74 598 minecraft:calcite
setblock 87 74 558 minecraft:cobbled_deepslate
fill 87 74 560 87 74 561 minecraft:cobbled_deepslate
setblock 87 74 562 minecraft:calcite
setblock 87 74 563 minecraft:cobbled_deepslate
setblock 87 74 567 minecraft:calcite
setblock 87 74 568 minecraft:cobbled_deepslate
setblock 87 74 572 minecraft:calcite
setblock 87 74 573 minecraft:cobbled_deepslate
setblock 87 74 577 minecraft:calcite
setblock 87 74 578 minecraft:cobbled_deepslate
setblock 87 74 582 minecraft:calcite
setblock 87 74 596 minecraft:cobbled_deepslate
setblock 87 74 597 minecraft:calcite
setblock 87 74 598 minecraft:cobbled_deepslate
setblock 88 74 561 minecraft:calcite
setblock 88 74 562 minecraft:cobbled_deepslate
setblock 88 74 566 minecraft:calcite
setblock 88 74 567 minecraft:cobbled_deepslate
setblock 88 74 571 minecraft:calcite
setblock 88 74 572 minecraft:cobbled_deepslate
setblock 88 74 576 minecraft:calcite
setblock 88 74 577 minecraft:cobbled_deepslate
setblock 88 74 581 minecraft:calcite
setblock 88 74 582 minecraft:cobbled_deepslate
setblock 88 74 584 minecraft:cobbled_deepslate
setblock 88 74 592 minecraft:cobbled_deepslate
setblock 88 74 596 minecraft:calcite
setblock 88 74 597 minecraft:cobbled_deepslate
fill 65 75 579 68 75 579 minecraft:sea_lantern
fill 66 75 576 67 75 576 minecraft:sea_lantern
fill 66 75 580 67 75 580 minecraft:sea_lantern
fill 67 75 577 68 75 577 minecraft:sea_lantern
setblock 68 75 578 minecraft:sea_lantern
fill 63 76 577 64 76 579 minecraft:sea_lantern
fill 64 76 575 65 76 576 minecraft:sea_lantern
fill 64 76 580 65 76 581 minecraft:sea_lantern
fill 65 76 579 68 78 579 minecraft:diamond_block
fill 66 76 575 69 76 575 minecraft:sea_lantern
fill 66 76 576 67 80 576 minecraft:diamond_block
fill 66 76 580 67 80 580 minecraft:diamond_block
fill 66 76 581 69 76 581 minecraft:sea_lantern
fill 67 76 577 68 76 577 minecraft:diamond_block
fill 68 76 576 69 76 576 minecraft:sea_lantern
fill 68 76 578 68 85 578 minecraft:diamond_block
fill 68 76 580 69 76 580 minecraft:sea_lantern
fill 69 76 577 70 76 579 minecraft:sea_lantern
fill 62 77 577 62 78 579 minecraft:sea_lantern
fill 63 77 575 63 77 576 minecraft:sea_lantern
fill 63 77 577 64 78 579 minecraft:diamond_block
fill 63 77 580 63 77 581 minecraft:sea_lantern
fill 64 77 574 69 77 574 minecraft:sea_lantern
fill 64 77 575 65 80 576 minecraft:diamond_block
fill 64 77 580 65 80 581 minecraft:diamond_block
fill 64 77 582 69 77 582 minecraft:sea_lantern
fill 66 77 575 69 78 575 minecraft:diamond_block
fill 66 77 581 69 80 581 minecraft:diamond_block
fill 68 77 576 69 80 577 minecraft:diamond_block
fill 68 77 580 69 84 580 minecraft:diamond_block
fill 69 77 578 70 84 579 minecraft:diamond_block
fill 70 77 575 70 77 576 minecraft:sea_lantern
fill 70 77 577 70 84 577 minecraft:diamond_block
fill 70 77 580 70 77 581 minecraft:sea_lantern
fill 71 77 577 71 78 579 minecraft:sea_lantern
fill 62 78 575 62 78 576 minecraft:sea_lantern
fill 62 78 580 62 79 581 minecraft:sea_lantern
fill 63 78 574 64 78 574 minecraft:sea_lantern
fill 63 78 575 63 80 576 minecraft:diamond_block
fill 63 78 580 63 80 581 minecraft:diamond_block
fill 63 78 582 64 78 582 minecraft:sea_lantern
fill 65 78 573 68 78 573 minecraft:sea_lantern
fill 65 78 574 68 78 574 minecraft:diamond_block
fill 65 78 582 68 78 582 minecraft:diamond_block
fill 65 78 583 68 78 583 minecraft:sea_lantern
fill 69 78 574 70 78 574 minecraft:sea_lantern
fill 69 78 582 70 78 582 minecraft:sea_lantern
fill 70 78 575 70 80 576 minecraft:diamond_block
fill 70 78 580 70 83 581 minecraft:diamond_block
fill 71 78 575 71 79 576 minecraft:sea_lantern
fill 71 78 580 71 79 581 minecraft:sea_lantern
fill 60 79 574 62 79 576 minecraft:redstone_block
fill 61 79 577 61 82 579 minecraft:sea_lantern
fill 62 79 577 63 80 579 minecraft:diamond_block
fill 63 79 574 63 83 574 minecraft:sea_lantern
fill 63 79 582 63 83 582 minecraft:sea_lantern
fill 64 79 573 66 82 573 minecraft:sea_lantern
fill 64 79 574 66 80 574 minecraft:diamond_block
fill 64 79 582 66 79 584 minecraft:redstone_block
fill 66 79 575 66 80 575 minecraft:diamond_block
fill 67 79 573 69 79 575 minecraft:redstone_block
fill 67 79 579 68 80 579 minecraft:diamond_block
fill 67 79 582 69 80 582 minecraft:diamond_block
fill 67 79 583 69 82 583 minecraft:sea_lantern
fill 70 79 574 70 83 574 minecraft:sea_lantern
fill 70 79 582 70 83 582 minecraft:sea_lantern
fill 71 79 577 71 82 579 minecraft:diamond_block
fill 72 79 577 72 82 579 minecraft:sea_lantern
setblock 50 80 560 minecraft:light[level=14]
setblock 50 80 568 minecraft:light[level=14]
setblock 50 80 576 minecraft:light[level=14]
setblock 50 80 584 minecraft:light[level=14]
setblock 50 80 592 minecraft:light[level=14]
setblock 58 80 560 minecraft:light[level=14]
setblock 58 80 568 minecraft:light[level=14]
setblock 58 80 576 minecraft:light[level=14]
setblock 58 80 584 minecraft:light[level=14]
setblock 58 80 592 minecraft:light[level=14]
fill 61 80 580 61 81 580 minecraft:sea_lantern
fill 62 80 580 62 81 580 minecraft:diamond_block
fill 62 80 581 62 83 581 minecraft:sea_lantern
setblock 66 80 560 minecraft:light[level=14]
setblock 66 80 568 minecraft:light[level=14]
setblock 66 80 584 minecraft:light[level=14]
setblock 66 80 592 minecraft:light[level=14]
fill 67 80 577 67 80 578 minecraft:diamond_block
fill 71 80 575 71 83 575 minecraft:sea_lantern
fill 71 80 576 71 81 576 minecraft:diamond_block
fill 71 80 580 71 81 580 minecraft:diamond_block
fill 71 80 581 71 83 581 minecraft:sea_lantern
fill 72 80 576 72 81 576 minecraft:sea_lantern
fill 72 80 580 72 81 580 minecraft:sea_lantern
setblock 74 80 560 minecraft:light[level=14]
setblock 74 80 568 minecraft:light[level=14]
setblock 74 80 576 minecraft:light[level=14]
setblock 74 80 584 minecraft:light[level=14]
setblock 74 80 592 minecraft:light[level=14]
setblock 82 80 560 minecraft:light[level=14]
setblock 82 80 568 minecraft:light[level=14]
setblock 82 80 576 minecraft:light[level=14]
setblock 82 80 584 minecraft:light[level=14]
setblock 82 80 592 minecraft:light[level=14]
fill 48 81 558 58 81 598 minecraft:tuff
fill 59 81 558 65 81 572 minecraft:tuff
fill 59 81 573 59 81 577 minecraft:sea_lantern
fill 59 81 578 60 81 598 minecraft:tuff
fill 60 81 573 63 81 573 minecraft:sea_lantern
fill 60 81 574 62 81 576 minecraft:tuff
setblock 60 81 577 minecraft:sea_lantern
fill 61 81 581 61 81 598 minecraft:tuff
fill 62 81 577 63 81 577 minecraft:sea_lantern
fill 62 81 578 62 82 579 minecraft:diamond_block
fill 62 81 582 62 81 598 minecraft:tuff
fill 63 81 575 63 81 576 minecraft:sea_lantern
fill 63 81 578 63 81 581 minecraft:sea_lantern
fill 63 81 583 63 81 585 minecraft:sea_lantern
fill 63 81 586 88 81 598 minecraft:tuff
fill 64 81 574 65 82 575 minecraft:diamond_block
fill 64 81 576 70 81 576 minecraft:sea_lantern
fill 64 81 580 67 81 581 minecraft:sea_lantern
fill 64 81 582 66 81 584 minecraft:tuff
fill 64 81 585 67 81 585 minecraft:sea_lantern
fill 66 81 558 88 81 571 minecraft:tuff
fill 66 81 572 70 81 572 minecraft:sea_lantern
fill 66 81 574 66 81 575 minecraft:sea_lantern
fill 67 81 573 69 81 575 minecraft:tuff
fill 67 81 577 67 81 579 minecraft:sea_lantern
setblock 67 81 582 minecraft:sea_lantern
setblock 67 81 584 minecraft:sea_lantern
fill 68 81 577 69 84 577 minecraft:diamond_block
fill 68 81 579 68 85 579 minecraft:diamond_block
fill 68 81 581 69 82 582 minecraft:diamond_block
fill 68 81 584 88 81 585 minecraft:tuff
setblock 70 81 573 minecraft:sea_lantern
setblock 70 81 575 minecraft:sea_lantern
fill 70 81 583 88 81 583 minecraft:tuff
fill 71 81 572 88 81 574 minecraft:tuff
fill 71 81 582 88 81 582 minecraft:tuff
fill 72 81 575 88 81 575 minecraft:tuff
fill 72 81 581 88 81 581 minecraft:tuff
fill 73 81 576 88 81 580 minecraft:tuff
fill 62 82 575 62 83 576 minecraft:sea_lantern
fill 62 82 577 63 82 577 minecraft:diamond_block
fill 62 82 580 62 83 580 minecraft:sea_lantern
fill 63 82 575 63 83 576 minecraft:diamond_block
fill 63 82 578 63 83 581 minecraft:diamond_block
fill 64 82 576 70 83 576 minecraft:diamond_block
fill 64 82 580 67 82 582 minecraft:diamond_block
fill 64 82 583 66 82 583 minecraft:sea_lantern
fill 66 82 574 69 82 575 minecraft:diamond_block
fill 67 82 573 69 82 573 minecraft:sea_lantern
fill 67 82 579 67 85 579 minecraft:diamond_block
fill 70 82 575 70 83 575 minecraft:diamond_block
fill 71 82 576 71 83 576 minecraft:sea_lantern
fill 71 82 580 71 83 580 minecraft:sea_lantern
fill 62 83 577 62 84 579 minecraft:sea_lantern
fill 63 83 577 63 84 577 minecraft:diamond_block
fill 64 83 574 64 84 574 minecraft:sea_lantern
fill 64 83 575 69 84 575 minecraft:diamond_block
fill 64 83 580 67 84 581 minecraft:diamond_block
fill 64 83 582 64 84 582 minecraft:sea_lantern
fill 65 83 573 68 83 573 minecraft:sea_lantern
fill 65 83 574 68 83 574 minecraft:diamond_block
fill 65 83 582 68 83 582 minecraft:diamond_block
fill 65 83 583 68 83 583 minecraft:sea_lantern
fill 68 83 581 69 84 581 minecraft:diamond_block
fill 69 83 574 69 84 574 minecraft:sea_lantern
fill 69 83 582 69 84 582 minecraft:sea_lantern
fill 71 83 577 71 84 579 minecraft:sea_lantern
fill 63 84 575 63 84 576 minecraft:sea_lantern
fill 63 84 578 64 84 579 minecraft:diamond_block
fill 63 84 580 63 84 581 minecraft:sea_lantern
fill 64 84 576 64 84 577 minecraft:diamond_block
fill 65 84 574 68 84 574 minecraft:sea_lantern
fill 65 84 576 69 84 576 minecraft:diamond_block
fill 65 84 579 66 85 579 minecraft:diamond_block
fill 65 84 582 68 84 582 minecraft:sea_lantern
fill 70 84 575 70 84 576 minecraft:sea_lantern
fill 70 84 580 70 84 581 minecraft:sea_lantern
fill 48 85 558 48 85 559 minecraft:cobbled_deepslate
setblock 48 85 560 minecraft:calcite
fill 48 85 561 48 85 564 minecraft:cobbled_deepslate
setblock 48 85 584 minecraft:cobbled_deepslate
setblock 48 85 585 minecraft:calcite
fill 48 85 586 48 85 589 minecraft:cobbled_deepslate
fill 53 85 558 55 88 559 minecraft:light_blue_stained_glass
fill 54 85 560 54 86 562 minecraft:light_blue_stained_glass
fill 57 85 598 59 85 598 minecraft:cobbled_deepslate
fill 58 85 558 59 85 558 minecraft:cobbled_deepslate
setblock 60 85 558 minecraft:calcite
setblock 60 85 598 minecraft:calcite
fill 61 85 558 63 85 558 minecraft:cobbled_deepslate
fill 61 85 598 62 85 598 minecraft:cobbled_deepslate
fill 63 85 577 64 85 579 minecraft:sea_lantern
fill 64 85 575 65 85 576 minecraft:sea_lantern
fill 64 85 580 65 85 581 minecraft:sea_lantern
fill 66 85 575 69 85 575 minecraft:sea_lantern
fill 66 85 576 67 85 576 minecraft:diamond_block
fill 66 85 580 67 85 580 minecraft:diamond_block
fill 66 85 581 69 85 581 minecraft:sea_lantern
fill 68 85 576 69 85 576 minecraft:sea_lantern
setblock 68 85 577 minecraft:diamond_block
fill 68 85 580 69 85 580 minecraft:sea_lantern
fill 69 85 577 70 85 579 minecraft:sea_lantern
fill 76 85 558 79 85 558 minecraft:cobbled_deepslate
fill 77 85 559 78 85 559 minecraft:cobbled_deepslate
setblock 78 85 560 minecraft:calcite
setblock 79 85 559 minecraft:calcite
fill 79 85 560 82 85 560 minecraft:cobbled_deepslate
setblock 80 85 558 minecraft:calcite
fill 80 85 559 83 85 559 minecraft:cobbled_deepslate
fill 81 85 558 84 85 558 minecraft:cobbled_deepslate
setblock 81 85 561 minecraft:cobbled_deepslate
setblock 82 85 561 minecraft:calcite
fill 82 85 598 83 85 598 minecraft:cobbled_deepslate
setblock 83 85 560 minecraft:calcite
setblock 83 85 561 minecraft:cobbled_deepslate
setblock 84 85 559 minecraft:calcite
fill 84 85 560 85 85 560 minecraft:cobbled_deepslate
setblock 85 85 558 minecraft:calcite
fill 85 85 559 88 85 559 minecraft:cobbled_deepslate
fill 86 85 558 88 86 558 minecraft:cobbled_deepslate
setblock 86 85 561 minecraft:cobbled_deepslate
setblock 86 85 562 minecraft:calcite
fill 86 85 563 88 85 564 minecraft:cobbled_deepslate
setblock 87 85 560 minecraft:cobbled_deepslate
setblock 87 85 561 minecraft:calcite
fill 87 85 562 88 87 562 minecraft:cobbled_deepslate
setblock 87 85 565 minecraft:cobbled_deepslate
setblock 87 85 566 minecraft:calcite
setblock 88 85 560 minecraft:calcite
fill 88 85 561 88 88 561 minecraft:cobbled_deepslate
setblock 88 85 565 minecraft:calcite
fill 88 85 566 88 87 567 minecraft:cobbled_deepslate
fill 48 86 562 48 86 563 minecraft:cobbled_deepslate
fill 48 86 572 49 91 574 minecraft:light_blue_stained_glass
setblock 48 86 584 minecraft:calcite
fill 48 86 585 48 86 588 minecraft:cobbled_deepslate
setblock 48 86 589 minecraft:calcite
fill 48 86 590 48 89 590 minecraft:cobbled_deepslate
fill 52 86 558 52 87 558 minecraft:light_blue_stained_glass
fill 53 86 560 53 86 561 minecraft:light_blue_stained_glass
fill 55 86 560 55 86 561 minecraft:light_blue_stained_glass
fill 56 86 558 56 87 558 minecraft:light_blue_stained_glass
fill 57 86 598 58 86 598 minecraft:cobbled_deepslate
setblock 59 86 558 minecraft:calcite
setblock 59 86 598 minecraft:calcite
setblock 60 86 558 minecraft:cobbled_deepslate
setblock 60 86 598 minecraft:cobbled_deepslate
fill 65 86 577 65 86 579 minecraft:sea_lantern
fill 66 86 576 67 86 576 minecraft:sea_lantern
fill 66 86 579 67 86 580 minecraft:sea_lantern
fill 68 86 577 68 86 579 minecraft:sea_lantern
fill 76 86 558 78 86 558 minecraft:cobbled_deepslate
setblock 77 86 559 minecraft:cobbled_deepslate
setblock 78 86 559 minecraft:calcite
setblock 79 86 558 minecraft:calcite
fill 79 86 559 81 86 560 minecraft:cobbled_deepslate
fill 80 86 558 83 86 558 minecraft:cobbled_deepslate
setblock 82 86 559 minecraft:cobbled_deepslate
setblock 82 86 560 minecraft:calcite
setblock 83 86 559 minecraft:calcite
fill 83 86 560 84 86 560 minecraft:cobbled_deepslate
setblock 84 86 558 minecraft:calcite
fill 84 86 559 86 86 559 minecraft:cobbled_deepslate
fill 85 86 558 85 89 558 minecraft:cobbled_deepslate
setblock 87 86 560 minecraft:calcite
fill 87 86 561 87 87 561 minecraft:cobbled_deepslate
fill 87 86 563 87 86 564 minecraft:cobbled_deepslate
setblock 87 86 565 minecraft:calcite
setblock 87 86 566 minecraft:cobbled_deepslate
setblock 88 86 559 minecraft:calcite
fill 88 86 560 88 89 560 minecraft:cobbled_deepslate
setblock 88 86 563 minecraft:cobbled_deepslate
setblock 88 86 564 minecraft:calcite
fill 88 86 565 88 89 565 minecraft:cobbled_deepslate
fill 47 87 557 47 87 566 minecraft:tuff
setblock 47 87 567 minecraft:cobbled_deepslate
fill 47 87 568 47 88 576 minecraft:tuff
fill 47 87 577 47 87 578 minecraft:cobbled_deepslate
fill 47 87 579 47 88 579 minecraft:tuff
setblock 47 87 580 minecraft:cobbled_deepslate
setblock 47 87 581 minecraft:tuff
setblock 47 87 582 minecraft:cobbled_deepslate
fill 47 87 583 47 87 593 minecraft:tuff
setblock 47 87 594 minecraft:cobbled_deepslate
fill 47 87 595 47 87 598 minecraft:tuff
setblock 47 87 599 minecraft:cobbled_deepslate
fill 48 87 557 60 87 557 minecraft:tuff
fill 48 87 571 49 90 571 minecraft:light_blue_stained_glass
fill 48 87 575 49 90 575 minecraft:light_blue_stained_glass
fill 48 87 585 48 87 587 minecraft:cobbled_deepslate
setblock 48 87 588 minecraft:calcite
fill 48 87 589 48 90 589 minecraft:cobbled_deepslate
fill 48 87 591 48 88 591 minecraft:cobbled_deepslate
fill 48 87 599 66 87 599 minecraft:tuff
fill 50 87 572 50 90 574 minecraft:light_blue_stained_glass
fill 51 87 573 51 90 573 minecraft:light_blue_stained_glass
fill 53 87 560 55 87 560 minecraft:light_blue_stained_glass
setblock 57 87 598 minecraft:cobbled_deepslate
setblock 58 87 598 minecraft:calcite
fill 59 87 598 59 90 598 minecraft:cobbled_deepslate
setblock 61 87 557 minecraft:cobbled_deepslate
fill 62 87 557 64 88 557 minecraft:tuff
setblock 65 87 557 minecraft:cobbled_deepslate
fill 66 87 557 67 88 557 minecraft:tuff
setblock 67 87 599 minecraft:cobbled_deepslate
setblock 68 87 557 minecraft:cobbled_deepslate
fill 68 87 599 74 87 599 minecraft:tuff
fill 69 87 557 80 87 557 minecraft:tuff
setblock 75 87 599 minecraft:cobbled_deepslate
fill 76 87 558 77 87 558 minecraft:cobbled_deepslate
fill 76 87 599 84 87 599 minecraft:tuff
setblock 77 87 559 minecraft:calcite
setblock 78 87 558 minecraft:calcite
fill 78 87 559 81 87 559 minecraft:cobbled_deepslate
fill 79 87 558 82 87 558 minecraft:cobbled_deepslate
fill 79 87 560 80 87 560 minecraft:cobbled_deepslate
setblock 81 87 557 minecraft:cobbled_deepslate
setblock 81 87 560 minecraft:calcite
fill 82 87 557 87 87 557 minecraft:tuff
setblock 82 87 559 minecraft:calcite
fill 82 87 560 83 87 560 minecraft:cobbled_deepslate
setblock 83 87 558 minecraft:calcite
fill 83 87 559 85 87 559 minecraft:cobbled_deepslate
fill 84 87 558 84 90 558 minecraft:cobbled_deepslate
setblock 85 87 599 minecraft:cobbled_deepslate
fill 86 87 558 87 87 558 minecraft:cobbled_deepslate
fill 86 87 599 89 88 599 minecraft:tuff
setblock 87 87 563 minecraft:cobbled_deepslate
setblock 87 87 564 minecraft:calcite
fill 87 87 565 87 90 565 minecraft:cobbled_deepslate
setblock 88 87 557 minecraft:cobbled_deepslate
fill 88 87 559 88 88 559 minecraft:cobbled_deepslate
setblock 88 87 563 minecraft:calcite
fill 88 87 564 89 88 564 minecraft:cobbled_deepslate
fill 89 87 557 89 87 563 minecraft:tuff
fill 89 87 565 89 87 567 minecraft:tuff
setblock 89 87 568 minecraft:cobbled_deepslate
fill 89 87 569 89 87 598 minecraft:tuff
fill 47 88 557 48 88 557 minecraft:cobbled_deepslate
fill 47 88 558 47 90 558 minecraft:tuff
setblock 47 88 559 minecraft:cobbled_deepslate
fill 47 88 560 47 88 567 minecraft:tuff
fill 47 88 577 47 90 578 minecraft:tuff
fill 47 88 580 47 90 580 minecraft:tuff
setblock 47 88 581 minecraft:cobbled_deepslate
fill 47 88 582 47 90 584 minecraft:tuff
fill 47 88 585 48 88 585 minecraft:cobbled_deepslate
setblock 47 88 586 minecraft:tuff
setblock 47 88 587 minecraft:cobbled_deepslate
fill 47 88 588 47 88 594 minecraft:tuff
setblock 47 88 595 minecraft:cobbled_deepslate
fill 47 88 596 47 88 599 minecraft:tuff
fill 48 88 570 48 89 570 minecraft:light_blue_stained_glass
fill 48 88 576 48 89 576 minecraft:light_blue_stained_glass
setblock 48 88 586 minecraft:cobbled_deepslate
setblock 48 88 587 minecraft:calcite
fill 48 88 588 48 91 588 minecraft:cobbled_deepslate
setblock 48 88 592 minecraft:calcite
fill 48 88 599 59 88 599 minecraft:tuff
fill 49 88 557 61 88 557 minecraft:tuff
setblock 50 88 560 minecraft:light[level=14]
setblock 50 88 568 minecraft:light[level=14]
fill 50 88 571 50 90 571 minecraft:light_blue_stained_glass
fill 50 88 575 50 90 575 minecraft:light_blue_stained_glass
setblock 50 88 576 minecraft:light[level=14]
setblock 50 88 584 minecraft:light[level=14]
setblock 50 88 592 minecraft:light[level=14]
fill 51 88 572 52 90 572 minecraft:light_blue_stained_glass
fill 51 88 574 52 90 574 minecraft:light_blue_stained_glass
fill 52 88 573 52 90 573 minecraft:light_blue_stained_glass
setblock 56 88 598 minecraft:cobbled_deepslate
setblock 57 88 598 minecraft:calcite
setblock 58 88 560 minecraft:light[level=14]
setblock 58 88 568 minecraft:light[level=14]
setblock 58 88 576 minecraft:light[level=14]
setblock 58 88 584 minecraft:light[level=14]
setblock 58 88 592 minecraft:light[level=14]
fill 58 88 598 58 91 598 minecraft:cobbled_deepslate
setblock 60 88 599 minecraft:cobbled_deepslate
fill 61 88 599 70 88 599 minecraft:tuff
fill 65 88 557 65 90 557 minecraft:tuff
setblock 66 88 560 minecraft:light[level=14]
setblock 66 88 568 minecraft:light[level=14]
setblock 66 88 576 minecraft:light[level=14]
setblock 66 88 584 minecraft:light[level=14]
setblock 66 88 592 minecraft:light[level=14]
fill 68 88 557 69 90 557 minecraft:tuff
setblock 70 88 557 minecraft:cobbled_deepslate
fill 71 88 557 71 90 557 minecraft:tuff
setblock 71 88 599 minecraft:cobbled_deepslate
setblock 72 88 557 minecraft:cobbled_deepslate
fill 72 88 599 79 90 599 minecraft:tuff
fill 73 88 557 77 90 557 minecraft:tuff
setblock 74 88 560 minecraft:light[level=14]
setblock 74 88 568 minecraft:light[level=14]
setblock 74 88 576 minecraft:light[level=14]
setblock 74 88 584 minecraft:light[level=14]
setblock 74 88 592 minecraft:light[level=14]
fill 75 88 558 76 88 558 minecraft:cobbled_deepslate
setblock 77 88 558 minecraft:calcite
fill 77 88 559 80 88 559 minecraft:cobbled_deepslate
fill 78 88 557 78 88 558 minecraft:cobbled_deepslate
fill 78 88 560 79 88 560 minecraft:cobbled_deepslate
fill 79 88 557 82 90 557 minecraft:tuff
fill 79 88 558 81 88 558 minecraft:cobbled_deepslate
setblock 80 88 560 minecraft:calcite
setblock 80 88 599 minecraft:cobbled_deepslate
setblock 81 88 559 minecraft:calcite
fill 81 88 560 82 88 560 minecraft:cobbled_deepslate
fill 81 88 599 85 88 599 minecraft:tuff
setblock 82 88 558 minecraft:calcite
fill 82 88 559 84 89 559 minecraft:cobbled_deepslate
setblock 82 88 568 minecraft:light[level=14]
setblock 82 88 576 minecraft:light[level=14]
setblock 82 88 584 minecraft:light[level=14]
setblock 82 88 592 minecraft:light[level=14]
fill 83 88 557 83 88 558 minecraft:cobbled_deepslate
fill 84 88 557 89 90 557 minecraft:tuff
setblock 86 88 558 minecraft:cobbled_deepslate
setblock 87 88 563 minecraft:calcite
fill 87 88 564 87 89 564 minecraft:cobbled_deepslate
setblock 88 88 562 minecraft:calcite
fill 88 88 563 88 91 563 minecraft:cobbled_deepslate
fill 88 88 566 89 88 566 minecraft:cobbled_deepslate
setblock 88 88 567 minecraft:calcite
fill 88 88 568 88 91 568 minecraft:cobbled_deepslate
fill 89 88 558 89 90 558 minecraft:tuff
setblock 89 88 559 minecraft:cobbled_deepslate
fill 89 88 560 89 90 561 minecraft:tuff
setblock 89 88 562 minecraft:cobbled_deepslate
fill 89 88 563 89 90 563 minecraft:tuff
fill 89 88 565 89 90 565 minecraft:tuff
fill 89 88 567 89 90 577 minecraft:tuff
setblock 89 88 578 minecraft:cobbled_deepslate
fill 89 88 579 89 90 586 minecraft:tuff
fill 89 88 587 89 88 588 minecraft:cobbled_deepslate
fill 89 88 589 89 88 598 minecraft:tuff
fill 47 89 557 55 90 557 minecraft:tuff
fill 47 89 559 47 90 560 minecraft:tuff
setblock 47 89 561 minecraft:cobbled_deepslate
fill 47 89 562 47 90 570 minecraft:tuff
setblock 47 89 571 minecraft:cobbled_deepslate
fill 47 89 572 47 90 576 minecraft:tuff
setblock 47 89 579 minecraft:cobbled_deepslate
fill 47 89 581 47 90 581 minecraft:tuff
fill 47 89 585 47 90 585 minecraft:tuff
setblock 47 89 586 minecraft:cobbled_deepslate
fill 47 89 587 47 90 589 minecraft:tuff
setblock 47 89 590 minecraft:cobbled_deepslate
fill 47 89 591 47 90 591 minecraft:tuff
fill 47 89 592 48 89 592 minecraft:cobbled_deepslate
fill 47 89 593 47 90 595 minecraft:tuff
setblock 47 89 596 minecraft:cobbled_deepslate
fill 47 89 597 47 90 599 minecraft:tuff
setblock 48 89 585 minecraft:cobbled_deepslate
setblock 48 89 586 minecraft:calcite
fill 48 89 587 49 91 587 minecraft:cobbled_deepslate
setblock 48 89 591 minecraft:calcite
fill 48 89 593 48 90 594 minecraft:cobbled_deepslate
fill 48 89 599 49 90 599 minecraft:tuff
fill 49 89 588 49 89 589 minecraft:cobbled_deepslate
setblock 49 89 590 minecraft:calcite
setblock 50 89 599 minecraft:cobbled_deepslate
fill 51 89 599 54 90 599 minecraft:tuff
fill 53 89 572 53 89 574 minecraft:light_blue_stained_glass
setblock 54 89 573 minecraft:light_blue_stained_glass
fill 55 89 598 55 89 599 minecraft:cobbled_deepslate
setblock 56 89 557 minecraft:cobbled_deepslate
setblock 56 89 598 minecraft:calcite
fill 56 89 599 68 90 599 minecraft:tuff
fill 57 89 557 57 90 557 minecraft:tuff
fill 57 89 598 57 92 598 minecraft:cobbled_deepslate
setblock 58 89 557 minecraft:cobbled_deepslate
fill 59 89 557 62 90 557 minecraft:tuff
setblock 63 89 557 minecraft:cobbled_deepslate
fill 64 89 557 64 90 557 minecraft:tuff
fill 66 89 557 66 90 557 minecraft:tuff
setblock 67 89 557 minecraft:cobbled_deepslate
setblock 69 89 599 minecraft:cobbled_deepslate
fill 70 89 557 70 90 557 minecraft:tuff
fill 70 89 599 71 90 599 minecraft:tuff
fill 72 89 557 72 90 557 minecraft:tuff
setblock 75 89 558 minecraft:cobbled_deepslate
setblock 76 89 558 minecraft:calcite
fill 76 89 559 79 89 559 minecraft:cobbled_deepslate
fill 77 89 558 80 89 558 minecraft:cobbled_deepslate
fill 78 89 557 78 90 557 minecraft:tuff
setblock 78 89 560 minecraft:cobbled_deepslate
setblock 79 89 560 minecraft:calcite
fill 79 89 598 80 89 598 minecraft:cobbled_deepslate
setblock 80 89 559 minecraft:calcite
fill 80 89 560 81 90 560 minecraft:cobbled_deepslate
fill 80 89 599 80 90 599 minecraft:tuff
setblock 81 89 558 minecraft:calcite
fill 81 89 559 81 92 559 minecraft:cobbled_deepslate
setblock 81 89 598 minecraft:calcite
setblock 81 89 599 minecraft:cobbled_deepslate
fill 82 89 558 83 91 558 minecraft:cobbled_deepslate
fill 82 89 599 82 90 599 minecraft:tuff
fill 83 89 557 83 90 557 minecraft:tuff
setblock 83 89 599 minecraft:cobbled_deepslate
fill 84 89 599 84 90 599 minecraft:tuff
setblock 85 89 599 minecraft:cobbled_deepslate
setblock 86 89 558 minecraft:calcite
fill 86 89 599 86 90 599 minecraft:tuff
setblock 87 89 599 minecraft:cobbled_deepslate
setblock 88 89 561 minecraft:calcite
fill 88 89 562 88 92 562 minecraft:cobbled_deepslate
fill 88 89 564 88 90 564 minecraft:cobbled_deepslate
setblock 88 89 566 minecraft:calcite
fill 88 89 567 88 92 567 minecraft:cobbled_deepslate
fill 88 89 599 89 90 599 minecraft:tuff
fill 89 89 559 89 90 559 minecraft:tuff
fill 89 89 562 89 90 562 minecraft:tuff
fill 89 89 564 89 90 564 minecraft:tuff
fill 89 89 566 89 91 566 minecraft:tuff
fill 89 89 578 89 90 578 minecraft:tuff
fill 89 89 587 89 91 587 minecraft:tuff
setblock 89 89 588 minecraft:cobbled_deepslate
fill 89 89 589 89 90 589 minecraft:tuff
setblock 89 89 590 minecraft:cobbled_deepslate
fill 89 89 591 89 90 591 minecraft:tuff
setblock 89 89 592 minecraft:cobbled_deepslate
fill 89 89 593 89 90 595 minecraft:tuff
setblock 89 89 596 minecraft:cobbled_deepslate
fill 89 89 597 89 90 598 minecraft:tuff
setblock 47 90 561 minecraft:tuff
setblock 47 90 571 minecraft:tuff
setblock 47 90 579 minecraft:tuff
setblock 47 90 586 minecraft:tuff
setblock 47 90 590 minecraft:tuff
setblock 47 90 592 minecraft:tuff
setblock 47 90 596 minecraft:tuff
setblock 48 90 584 minecraft:cobbled_deepslate
setblock 48 90 585 minecraft:calcite
fill 48 90 586 49 92 586 minecraft:cobbled_deepslate
setblock 48 90 590 minecraft:calcite
fill 48 90 591 49 91 592 minecraft:cobbled_deepslate
setblock 48 90 595 minecraft:calcite
setblock 49 90 588 minecraft:cobbled_deepslate
setblock 49 90 589 minecraft:calcite
fill 49 90 590 49 93 590 minecraft:cobbled_deepslate
fill 49 90 597 51 92 597 minecraft:light_blue_stained_glass
fill 50 90 596 50 93 596 minecraft:light_blue_stained_glass
fill 50 90 598 50 91 598 minecraft:light_blue_stained_glass
setblock 50 90 599 minecraft:tuff
setblock 53 90 573 minecraft:light_blue_stained_glass
fill 53 90 598 54 90 598 minecraft:cobbled_deepslate
setblock 55 90 598 minecraft:calcite
setblock 55 90 599 minecraft:tuff
setblock 56 90 557 minecraft:tuff
fill 56 90 598 56 93 598 minecraft:cobbled_deepslate
setblock 58 90 557 minecraft:tuff
setblock 60 90 598 minecraft:calcite
setblock 63 90 557 minecraft:tuff
setblock 67 90 557 minecraft:tuff
setblock 69 90 599 minecraft:tuff
setblock 74 90 558 minecraft:cobbled_deepslate
setblock 75 90 558 minecraft:calcite
fill 75 90 559 78 90 559 minecraft:cobbled_deepslate
fill 76 90 558 79 90 558 minecraft:cobbled_deepslate
setblock 77 90 560 minecraft:cobbled_deepslate
fill 77 90 598 79 90 598 minecraft:cobbled_deepslate
setblock 78 90 560 minecraft:calcite
setblock 79 90 559 minecraft:calcite
fill 79 90 560 79 93 560 minecraft:cobbled_deepslate
setblock 80 90 558 minecraft:calcite
fill 80 90 559 80 93 559 minecraft:cobbled_deepslate
setblock 80 90 598 minecraft:calcite
fill 81 90 558 81 93 558 minecraft:cobbled_deepslate
fill 81 90 598 83 91 598 minecraft:cobbled_deepslate
setblock 81 90 599 minecraft:tuff
fill 82 90 559 83 90 559 minecraft:cobbled_deepslate
setblock 83 90 599 minecraft:tuff
setblock 85 90 558 minecraft:calcite
setblock 85 90 599 minecraft:tuff
fill 86 90 558 86 91 558 minecraft:cobbled_deepslate
setblock 87 90 599 minecraft:tuff
setblock 88 90 560 minecraft:calcite
fill 88 90 561 88 92 561 minecraft:cobbled_deepslate
setblock 88 90 565 minecraft:calcite
fill 88 90 566 88 93 566 minecraft:cobbled_deepslate
setblock 88 90 569 minecraft:cobbled_deepslate
fill 88 90 587 88 90 589 minecraft:cobbled_deepslate
setblock 88 90 590 minecraft:calcite
fill 88 90 591 88 91 593 minecraft:cobbled_deepslate
setblock 89 90 588 minecraft:tuff
setblock 89 90 590 minecraft:tuff
setblock 89 90 592 minecraft:tuff
setblock 89 90 596 minecraft:tuff
fill 47 91 557 47 91 558 minecraft:cobbled_deepslate
setblock 47 91 559 minecraft:tuff
fill 47 91 560 47 91 562 minecraft:cobbled_deepslate
setblock 47 91 563 minecraft:tuff
fill 47 91 564 47 195 569 minecraft:cobbled_deepslate
setblock 47 91 570 minecraft:tuff
fill 47 91 571 47 91 598 minecraft:cobbled_deepslate
setblock 47 91 599 minecraft:tuff
setblock 48 91 557 minecraft:tuff
setblock 48 91 584 minecraft:calcite
fill 48 91 585 48 94 585 minecraft:cobbled_deepslate
setblock 48 91 589 minecraft:calcite
fill 48 91 590 48 94 590 minecraft:cobbled_deepslate
setblock 48 91 593 minecraft:cobbled_deepslate
setblock 48 91 594 minecraft:calcite
fill 48 91 595 48 92 597 minecraft:cobbled_deepslate
fill 48 91 599 56 91 599 minecraft:cobbled_deepslate
fill 49 91 557 76 91 557 minecraft:cobbled_deepslate
setblock 49 91 588 minecraft:calcite
fill 49 91 589 50 93 589 minecraft:cobbled_deepslate
setblock 49 91 593 minecraft:calcite
fill 49 91 594 49 94 594 minecraft:cobbled_deepslate
fill 49 91 595 49 91 596 minecraft:light_blue_stained_glass
setblock 49 91 598 minecraft:light_blue_stained_glass
setblock 50 91 573 minecraft:light_blue_stained_glass
fill 50 91 588 50 94 588 minecraft:cobbled_deepslate
fill 50 91 590 50 91 591 minecraft:cobbled_deepslate
fill 50 91 595 51 93 595 minecraft:light_blue_stained_glass
fill 51 91 596 51 93 596 minecraft:light_blue_stained_glass
fill 51 91 598 53 91 598 minecraft:cobbled_deepslate
setblock 54 91 597 minecraft:cobbled_deepslate
setblock 54 91 598 minecraft:calcite
setblock 55 91 597 minecraft:calcite
fill 55 91 598 55 94 598 minecraft:cobbled_deepslate
fill 56 91 597 58 92 597 minecraft:cobbled_deepslate
setblock 57 91 599 minecraft:tuff
fill 58 91 599 72 91 599 minecraft:cobbled_deepslate
setblock 59 91 598 minecraft:calcite
fill 60 91 598 60 94 598 minecraft:cobbled_deepslate
fill 61 91 589 61 92 589 minecraft:light_blue_stained_glass
setblock 73 91 558 minecraft:cobbled_deepslate
setblock 73 91 599 minecraft:tuff
setblock 74 91 558 minecraft:calcite
fill 74 91 599 88 91 599 minecraft:cobbled_deepslate
fill 75 91 558 77 91 559 minecraft:cobbled_deepslate
fill 76 91 598 78 91 598 minecraft:cobbled_deepslate
setblock 77 91 557 minecraft:tuff
setblock 77 91 560 minecraft:calcite
fill 78 91 557 78 91 558 minecraft:cobbled_deepslate
setblock 78 91 559 minecraft:calcite
fill 78 91 560 78 94 560 minecraft:cobbled_deepslate
setblock 79 91 557 minecraft:tuff
setblock 79 91 558 minecraft:calcite
fill 79 91 559 79 94 559 minecraft:cobbled_deepslate
setblock 79 91 598 minecraft:calcite
fill 80 91 557 80 94 558 minecraft:cobbled_deepslate
fill 80 91 560 80 92 560 minecraft:cobbled_deepslate
fill 80 91 598 80 94 598 minecraft:cobbled_deepslate
fill 81 91 557 86 91 557 minecraft:cobbled_deepslate
setblock 82 91 559 minecraft:cobbled_deepslate
fill 82 91 581 88 92 581 minecraft:light_blue_stained_glass
setblock 83 91 559 minecraft:calcite
setblock 84 91 558 minecraft:calcite
setblock 84 91 598 minecraft:calcite
fill 85 91 558 85 94 558 minecraft:cobbled_deepslate
fill 85 91 580 87 95 580 minecraft:light_blue_stained_glass
fill 85 91 582 87 95 582 minecraft:light_blue_stained_glass
setblock 87 91 557 minecraft:tuff
fill 88 91 557 89 199 557 minecraft:cobbled_deepslate
setblock 88 91 564 minecraft:calcite
fill 88 91 565 89 91 565 minecraft:cobbled_deepslate
setblock 88 91 569 minecraft:calcite
fill 88 91 570 88 94 570 minecraft:cobbled_deepslate
fill 88 91 587 88 91 588 minecraft:cobbled_deepslate
setblock 88 91 589 minecraft:calcite
fill 88 91 590 89 94 590 minecraft:cobbled_deepslate
setblock 88 91 594 minecraft:calcite
fill 88 91 595 89 93 596 minecraft:cobbled_deepslate
fill 89 91 558 89 196 564 minecraft:cobbled_deepslate
fill 89 91 567 89 196 569 minecraft:cobbled_deepslate
fill 89 91 570 89 92 570 minecraft:tuff
fill 89 91 571 89 92 580 minecraft:cobbled_deepslate
setblock 89 91 581 minecraft:tuff
fill 89 91 582 89 91 586 minecraft:cobbled_deepslate
fill 89 91 588 89 195 589 minecraft:cobbled_deepslate
fill 89 91 591 89 92 594 minecraft:cobbled_deepslate
fill 89 91 597 89 196 598 minecraft:cobbled_deepslate
setblock 89 91 599 minecraft:tuff
fill 47 92 557 54 92 557 minecraft:cobbled_deepslate
setblock 47 92 558 minecraft:tuff
fill 47 92 559 47 199 559 minecraft:cobbled_deepslate
setblock 47 92 560 minecraft:tuff
fill 47 92 561 47 199 563 minecraft:cobbled_deepslate
fill 47 92 570 47 199 572 minecraft:cobbled_deepslate
setblock 47 92 573 minecraft:tuff
fill 47 92 574 47 196 575 minecraft:cobbled_deepslate
setblock 47 92 576 minecraft:tuff
fill 47 92 577 47 199 583 minecraft:cobbled_deepslate
setblock 47 92 584 minecraft:tuff
fill 47 92 585 47 199 585 minecraft:cobbled_deepslate
fill 47 92 586 47 93 586 minecraft:tuff
fill 47 92 587 47 92 599 minecraft:cobbled_deepslate
setblock 48 92 568 minecraft:calcite
fill 48 92 584 48 95 584 minecraft:cobbled_deepslate
setblock 48 92 587 minecraft:cobbled_deepslate
setblock 48 92 588 minecraft:calcite
fill 48 92 589 48 95 589 minecraft:cobbled_deepslate
fill 48 92 591 48 92 592 minecraft:cobbled_deepslate
setblock 48 92 593 minecraft:calcite
fill 48 92 594 48 95 594 minecraft:cobbled_deepslate
setblock 48 92 598 minecraft:calcite
fill 48 92 599 48 200 599 minecraft:cobbled_deepslate
fill 49 92 585 49 93 585 minecraft:cobbled_deepslate
setblock 49 92 587 minecraft:calcite
fill 49 92 588 49 95 588 minecraft:cobbled_deepslate
setblock 49 92 591 minecraft:cobbled_deepslate
setblock 49 92 592 minecraft:calcite
fill 49 92 593 50 94 593 minecraft:cobbled_deepslate
fill 49 92 595 49 93 595 minecraft:cobbled_deepslate
setblock 49 92 596 minecraft:light_blue_stained_glass
fill 49 92 598 52 92 598 minecraft:cobbled_deepslate
setblock 49 92 599 minecraft:tuff
fill 50 92 587 50 95 587 minecraft:cobbled_deepslate
setblock 50 92 590 minecraft:cobbled_deepslate
setblock 50 92 591 minecraft:calcite
fill 50 92 592 50 95 592 minecraft:cobbled_deepslate
fill 50 92 594 51 92 594 minecraft:light_blue_stained_glass
fill 50 92 599 51 92 599 minecraft:cobbled_deepslate
fill 52 92 597 53 92 597 minecraft:cobbled_deepslate
setblock 52 92 599 minecraft:tuff
setblock 53 92 598 minecraft:calcite
fill 53 92 599 62 195 599 minecraft:cobbled_deepslate
setblock 54 92 597 minecraft:calcite
fill 54 92 598 54 95 598 minecraft:cobbled_deepslate
fill 55 92 557 55 93 557 minecraft:tuff
setblock 55 92 596 minecraft:calcite
fill 55 92 597 55 95 597 minecraft:cobbled_deepslate
fill 56 92 557 57 92 558 minecraft:cobbled_deepslate
fill 56 92 596 56 95 596 minecraft:cobbled_deepslate
fill 58 92 557 58 199 557 minecraft:cobbled_deepslate
setblock 58 92 598 minecraft:calcite
setblock 59 92 557 minecraft:tuff
fill 59 92 598 59 95 598 minecraft:cobbled_deepslate
fill 60 92 557 74 92 557 minecraft:cobbled_deepslate
setblock 63 92 599 minecraft:tuff
fill 64 92 599 64 199 599 minecraft:cobbled_deepslate
setblock 65 92 599 minecraft:tuff
fill 66 92 599 80 195 599 minecraft:cobbled_deepslate
setblock 72 92 558 minecraft:cobbled_deepslate
setblock 73 92 558 minecraft:calcite
fill 74 92 558 76 92 559 minecraft:cobbled_deepslate
fill 74 92 598 77 92 598 minecraft:cobbled_deepslate
fill 75 92 557 75 93 557 minecraft:tuff
fill 76 92 557 79 197 557 minecraft:cobbled_deepslate
setblock 76 92 560 minecraft:calcite
setblock 77 92 558 minecraft:cobbled_deepslate
setblock 77 92 559 minecraft:calcite
fill 77 92 560 77 95 560 minecraft:cobbled_deepslate
fill 77 92 597 78 92 597 minecraft:cobbled_deepslate
setblock 78 92 558 minecraft:calcite
fill 78 92 559 78 95 559 minecraft:cobbled_deepslate
setblock 78 92 598 minecraft:calcite
fill 79 92 558 79 95 558 minecraft:cobbled_deepslate
setblock 79 92 597 minecraft:calcite
fill 79 92 598 79 95 598 minecraft:cobbled_deepslate
fill 80 92 597 80 95 597 minecraft:cobbled_deepslate
fill 81 92 557 84 92 557 minecraft:cobbled_deepslate
fill 81 92 598 82 92 598 minecraft:cobbled_deepslate
setblock 81 92 599 minecraft:tuff
setblock 82 92 558 minecraft:cobbled_deepslate
setblock 82 92 559 minecraft:calcite
fill 82 92 599 89 92 599 minecraft:cobbled_deepslate
setblock 83 92 558 minecraft:calcite
fill 83 92 580 84 93 580 minecraft:light_blue_stained_glass
fill 83 92 582 84 93 582 minecraft:light_blue_stained_glass
setblock 83 92 598 minecraft:calcite
fill 84 92 558 84 95 558 minecraft:cobbled_deepslate
fill 84 92 598 87 92 598 minecraft:cobbled_deepslate
setblock 85 92 557 minecraft:tuff
fill 86 92 557 87 199 557 minecraft:cobbled_deepslate
fill 86 92 579 88 95 579 minecraft:light_blue_stained_glass
fill 86 92 583 88 95 583 minecraft:light_blue_stained_glass
fill 87 92 591 88 92 592 minecraft:cobbled_deepslate
setblock 88 92 563 minecraft:calcite
fill 88 92 564 88 94 565 minecraft:cobbled_deepslate
setblock 88 92 568 minecraft:calcite
fill 88 92 569 88 95 569 minecraft:cobbled_deepslate
fill 88 92 580 88 95 580 minecraft:light_blue_stained_glass
fill 88 92 582 88 95 582 minecraft:light_blue_stained_glass
fill 88 92 587 89 92 587 minecraft:cobbled_deepslate
setblock 88 92 588 minecraft:calcite
fill 88 92 589 88 95 589 minecraft:cobbled_deepslate
setblock 88 92 593 minecraft:calcite
fill 88 92 594 88 95 594 minecraft:cobbled_deepslate
setblock 88 92 597 minecraft:cobbled_deepslate
setblock 88 92 598 minecraft:calcite
setblock 89 92 565 minecraft:tuff
fill 89 92 566 89 199 566 minecraft:cobbled_deepslate
fill 89 92 581 89 199 582 minecraft:cobbled_deepslate
setblock 89 92 583 minecraft:tuff
fill 89 92 584 89 195 586 minecraft:cobbled_deepslate
fill 47 93 557 47 195 558 minecraft:cobbled_deepslate
fill 47 93 560 47 199 560 minecraft:cobbled_deepslate
fill 47 93 573 47 197 573 minecraft:cobbled_deepslate
fill 47 93 576 47 199 576 minecraft:cobbled_deepslate
fill 47 93 584 47 199 584 minecraft:cobbled_deepslate
fill 47 93 587 47 197 588 minecraft:cobbled_deepslate
setblock 47 93 589 minecraft:tuff
fill 47 93 590 47 195 592 minecraft:cobbled_deepslate
setblock 47 93 593 minecraft:tuff
fill 47 93 594 47 196 594 minecraft:cobbled_deepslate
setblock 47 93 595 minecraft:tuff
fill 47 93 596 47 196 599 minecraft:cobbled_deepslate
fill 48 93 557 51 196 557 minecraft:cobbled_deepslate
setblock 48 93 567 minecraft:calcite
fill 48 93 568 48 93 571 minecraft:cobbled_deepslate
setblock 48 93 586 minecraft:cobbled_deepslate
setblock 48 93 587 minecraft:calcite
fill 48 93 588 48 96 588 minecraft:cobbled_deepslate
setblock 48 93 591 minecraft:cobbled_deepslate
setblock 48 93 592 minecraft:calcite
fill 48 93 593 48 96 593 minecraft:cobbled_deepslate
fill 48 93 595 48 93 596 minecraft:cobbled_deepslate
setblock 48 93 597 minecraft:calcite
fill 48 93 598 51 93 598 minecraft:cobbled_deepslate
setblock 49 93 586 minecraft:calcite
fill 49 93 587 49 96 587 minecraft:cobbled_deepslate
setblock 49 93 591 minecraft:calcite
fill 49 93 592 49 96 592 minecraft:cobbled_deepslate
setblock 49 93 596 minecraft:calcite
setblock 49 93 597 minecraft:light_blue_stained_glass
fill 49 93 599 49 195 599 minecraft:cobbled_deepslate
setblock 50 93 590 minecraft:calcite
fill 50 93 591 51 95 591 minecraft:cobbled_deepslate
setblock 50 93 594 minecraft:cobbled_deepslate
fill 50 93 597 52 93 597 minecraft:cobbled_deepslate
setblock 50 93 599 minecraft:tuff
setblock 51 93 589 minecraft:calcite
fill 51 93 590 51 96 590 minecraft:cobbled_deepslate
fill 51 93 592 51 94 592 minecraft:cobbled_deepslate
fill 51 93 593 51 93 594 minecraft:light_blue_stained_glass
fill 51 93 599 52 196 599 minecraft:cobbled_deepslate
setblock 52 93 557 minecraft:tuff
setblock 52 93 598 minecraft:calcite
fill 53 93 557 54 195 557 minecraft:cobbled_deepslate
setblock 53 93 596 minecraft:cobbled_deepslate
setblock 53 93 597 minecraft:calcite
fill 53 93 598 53 96 598 minecraft:cobbled_deepslate
setblock 54 93 596 minecraft:calcite
fill 54 93 597 54 96 597 minecraft:cobbled_deepslate
fill 55 93 558 56 93 558 minecraft:cobbled_deepslate
fill 55 93 596 55 96 596 minecraft:cobbled_deepslate
setblock 56 93 557 minecraft:tuff
fill 56 93 597 57 93 597 minecraft:cobbled_deepslate
fill 57 93 557 57 200 557 minecraft:cobbled_deepslate
setblock 57 93 558 minecraft:calcite
fill 57 93 596 57 94 596 minecraft:cobbled_deepslate
setblock 57 93 598 minecraft:calcite
setblock 58 93 597 minecraft:calcite
fill 58 93 598 58 96 598 minecraft:cobbled_deepslate
fill 59 93 557 73 195 557 minecraft:cobbled_deepslate
fill 59 93 597 59 94 597 minecraft:cobbled_deepslate
fill 61 93 589 61 100 589 minecraft:deepslate
fill 63 93 599 63 199 599 minecraft:cobbled_deepslate
fill 65 93 599 65 196 599 minecraft:cobbled_deepslate
setblock 72 93 558 minecraft:calcite
fill 73 93 558 75 93 559 minecraft:cobbled_deepslate
fill 73 93 598 76 93 598 minecraft:cobbled_deepslate
setblock 74 93 557 minecraft:tuff
fill 75 93 597 77 93 597 minecraft:cobbled_deepslate
setblock 76 93 558 minecraft:cobbled_deepslate
setblock 76 93 559 minecraft:calcite
fill 76 93 560 76 95 560 minecraft:cobbled_deepslate
setblock 77 93 558 minecraft:calcite
fill 77 93 559 77 96 559 minecraft:cobbled_deepslate
setblock 77 93 598 minecraft:calcite
fill 78 93 558 78 96 558 minecraft:cobbled_deepslate
setblock 78 93 597 minecraft:calcite
fill 78 93 598 78 96 598 minecraft:cobbled_deepslate
fill 79 93 597 79 96 597 minecraft:cobbled_deepslate
fill 81 93 557 81 195 557 minecraft:cobbled_deepslate
setblock 81 93 559 minecraft:calcite
fill 81 93 597 81 93 599 minecraft:cobbled_deepslate
setblock 82 93 557 minecraft:tuff
setblock 82 93 558 minecraft:calcite
setblock 82 93 559 minecraft:cobbled_deepslate
setblock 82 93 597 minecraft:cobbled_deepslate
setblock 82 93 598 minecraft:calcite
fill 82 93 599 85 199 599 minecraft:cobbled_deepslate
fill 83 93 557 83 96 558 minecraft:cobbled_deepslate
fill 83 93 581 88 93 581 minecraft:light_blue_stained_glass
fill 83 93 598 86 93 598 minecraft:cobbled_deepslate
setblock 84 93 557 minecraft:tuff
fill 85 93 557 85 195 557 minecraft:cobbled_deepslate
fill 85 93 579 85 94 579 minecraft:light_blue_stained_glass
fill 85 93 583 85 94 583 minecraft:light_blue_stained_glass
setblock 86 93 599 minecraft:tuff
fill 87 93 590 87 93 592 minecraft:cobbled_deepslate
setblock 87 93 593 minecraft:calcite
fill 87 93 594 87 96 594 minecraft:cobbled_deepslate
setblock 87 93 598 minecraft:calcite
fill 87 93 599 89 199 599 minecraft:cobbled_deepslate
setblock 88 93 562 minecraft:calcite
setblock 88 93 563 minecraft:cobbled_deepslate
setblock 88 93 567 minecraft:calcite
fill 88 93 568 88 96 568 minecraft:cobbled_deepslate
fill 88 93 571 89 93 571 minecraft:cobbled_deepslate
setblock 88 93 586 minecraft:cobbled_deepslate
setblock 88 93 587 minecraft:calcite
fill 88 93 588 88 96 588 minecraft:cobbled_deepslate
setblock 88 93 591 minecraft:cobbled_deepslate
setblock 88 93 592 minecraft:calcite
fill 88 93 593 89 96 593 minecraft:cobbled_deepslate
setblock 88 93 597 minecraft:calcite
fill 88 93 598 88 96 598 minecraft:cobbled_deepslate
fill 89 93 565 89 199 565 minecraft:cobbled_deepslate
fill 89 93 570 89 199 570 minecraft:cobbled_deepslate
fill 89 93 572 89 199 574 minecraft:cobbled_deepslate
setblock 89 93 575 minecraft:tuff
fill 89 93 576 89 195 579 minecraft:cobbled_deepslate
setblock 89 93 580 minecraft:tuff
fill 89 93 583 89 199 583 minecraft:cobbled_deepslate
fill 89 93 587 89 197 587 minecraft:cobbled_deepslate
setblock 89 93 591 minecraft:tuff
fill 89 93 592 89 196 592 minecraft:cobbled_deepslate
fill 89 93 594 89 199 594 minecraft:cobbled_deepslate
fill 47 94 586 47 199 586 minecraft:cobbled_deepslate
fill 47 94 589 47 199 589 minecraft:cobbled_deepslate
fill 47 94 593 47 199 593 minecraft:cobbled_deepslate
fill 47 94 595 48 94 595 minecraft:cobbled_deepslate
fill 48 94 567 48 94 570 minecraft:cobbled_deepslate
setblock 48 94 571 minecraft:calcite
fill 48 94 572 48 96 573 minecraft:cobbled_deepslate
setblock 48 94 586 minecraft:calcite
fill 48 94 587 48 97 587 minecraft:cobbled_deepslate
setblock 48 94 591 minecraft:calcite
fill 48 94 592 48 97 592 minecraft:cobbled_deepslate
setblock 48 94 596 minecraft:calcite
fill 48 94 597 50 94 598 minecraft:cobbled_deepslate
setblock 49 94 585 minecraft:calcite
fill 49 94 586 49 97 586 minecraft:cobbled_deepslate
setblock 49 94 589 minecraft:cobbled_deepslate
setblock 49 94 590 minecraft:calcite
fill 49 94 591 49 97 591 minecraft:cobbled_deepslate
setblock 49 94 595 minecraft:calcite
fill 49 94 596 49 97 596 minecraft:cobbled_deepslate
setblock 50 94 589 minecraft:calcite
fill 50 94 590 50 97 590 minecraft:cobbled_deepslate
setblock 50 94 594 minecraft:calcite
fill 50 94 595 50 97 595 minecraft:cobbled_deepslate
fill 50 94 599 50 195 599 minecraft:cobbled_deepslate
fill 51 94 589 51 95 589 minecraft:cobbled_deepslate
setblock 51 94 593 minecraft:calcite
fill 51 94 596 51 94 597 minecraft:cobbled_deepslate
setblock 51 94 598 minecraft:calcite
fill 52 94 557 52 199 557 minecraft:cobbled_deepslate
setblock 52 94 596 minecraft:cobbled_deepslate
setblock 52 94 597 minecraft:calcite
fill 52 94 598 52 97 598 minecraft:cobbled_deepslate
setblock 53 94 596 minecraft:calcite
fill 53 94 597 53 97 597 minecraft:cobbled_deepslate
fill 54 94 558 55 94 558 minecraft:cobbled_deepslate
fill 54 94 596 54 97 596 minecraft:cobbled_deepslate
fill 55 94 557 56 199 557 minecraft:cobbled_deepslate
setblock 56 94 558 minecraft:calcite
setblock 56 94 597 minecraft:cobbled_deepslate
setblock 56 94 598 minecraft:calcite
setblock 57 94 597 minecraft:calcite
fill 57 94 598 57 97 598 minecraft:cobbled_deepslate
fill 58 94 597 58 96 597 minecraft:cobbled_deepslate
fill 62 94 589 62 100 589 minecraft:deepslate
setblock 71 94 558 minecraft:calcite
fill 72 94 558 75 94 558 minecraft:cobbled_deepslate
fill 72 94 598 75 94 598 minecraft:cobbled_deepslate
fill 73 94 559 74 94 559 minecraft:cobbled_deepslate
fill 74 94 557 75 196 557 minecraft:cobbled_deepslate
fill 74 94 597 76 94 597 minecraft:cobbled_deepslate
setblock 75 94 559 minecraft:calcite
setblock 75 94 560 minecraft:cobbled_deepslate
setblock 76 94 558 minecraft:calcite
fill 76 94 559 76 97 559 minecraft:cobbled_deepslate
setblock 76 94 598 minecraft:calcite
fill 77 94 558 77 97 558 minecraft:cobbled_deepslate
setblock 77 94 597 minecraft:calcite
fill 77 94 598 77 97 598 minecraft:cobbled_deepslate
fill 78 94 597 78 97 597 minecraft:cobbled_deepslate
setblock 80 94 559 minecraft:calcite
setblock 81 94 558 minecraft:calcite
setblock 81 94 559 minecraft:cobbled_deepslate
setblock 81 94 597 minecraft:cobbled_deepslate
setblock 81 94 598 minecraft:calcite
fill 81 94 599 81 199 599 minecraft:cobbled_deepslate
fill 82 94 557 82 97 558 minecraft:cobbled_deepslate
setblock 82 94 597 minecraft:calcite
fill 82 94 598 85 94 598 minecraft:cobbled_deepslate
fill 84 94 557 84 197 557 minecraft:cobbled_deepslate
fill 84 94 580 84 94 582 minecraft:light_blue_stained_glass
fill 85 94 581 88 95 581 minecraft:light_blue_stained_glass
setblock 86 94 598 minecraft:calcite
fill 86 94 599 86 199 599 minecraft:cobbled_deepslate
fill 87 94 590 87 94 591 minecraft:cobbled_deepslate
setblock 87 94 592 minecraft:calcite
fill 87 94 593 87 97 593 minecraft:cobbled_deepslate
fill 87 94 595 87 94 596 minecraft:cobbled_deepslate
fill 87 94 598 87 97 598 minecraft:cobbled_deepslate
setblock 88 94 566 minecraft:calcite
fill 88 94 567 88 96 567 minecraft:cobbled_deepslate
setblock 88 94 571 minecraft:calcite
fill 88 94 572 88 97 572 minecraft:cobbled_deepslate
fill 88 94 587 88 96 587 minecraft:cobbled_deepslate
setblock 88 94 591 minecraft:calcite
fill 88 94 592 88 97 592 minecraft:cobbled_deepslate
fill 88 94 595 89 94 595 minecraft:cobbled_deepslate
setblock 88 94 596 minecraft:calcite
fill 88 94 597 88 97 597 minecraft:cobbled_deepslate
fill 89 94 571 89 196 571 minecraft:cobbled_deepslate
fill 89 94 575 89 199 575 minecraft:cobbled_deepslate
fill 89 94 580 89 196 580 minecraft:cobbled_deepslate
fill 89 94 591 89 199 591 minecraft:cobbled_deepslate
fill 89 94 596 89 199 596 minecraft:cobbled_deepslate
fill 47 95 595 47 196 595 minecraft:cobbled_deepslate
fill 48 95 568 48 95 569 minecraft:cobbled_deepslate
setblock 48 95 570 minecraft:calcite
fill 48 95 571 48 98 571 minecraft:cobbled_deepslate
setblock 48 95 574 minecraft:cobbled_deepslate
setblock 48 95 585 minecraft:calcite
fill 48 95 586 48 98 586 minecraft:cobbled_deepslate
setblock 48 95 590 minecraft:calcite
fill 48 95 591 48 98 591 minecraft:cobbled_deepslate
setblock 48 95 595 minecraft:calcite
fill 48 95 596 48 96 598 minecraft:cobbled_deepslate
setblock 49 95 585 minecraft:cobbled_deepslate
setblock 49 95 589 minecraft:calcite
fill 49 95 590 49 98 590 minecraft:cobbled_deepslate
setblock 49 95 593 minecraft:cobbled_deepslate
setblock 49 95 594 minecraft:calcite
fill 49 95 595 49 98 595 minecraft:cobbled_deepslate
fill 49 95 597 49 95 598 minecraft:cobbled_deepslate
setblock 50 95 588 minecraft:calcite
fill 50 95 589 50 98 589 minecraft:cobbled_deepslate
setblock 50 95 593 minecraft:calcite
fill 50 95 594 50 98 594 minecraft:cobbled_deepslate
fill 50 95 596 50 95 597 minecraft:cobbled_deepslate
setblock 50 95 598 minecraft:calcite
setblock 51 95 592 minecraft:calcite
fill 51 95 593 51 97 593 minecraft:cobbled_deepslate
setblock 51 95 596 minecraft:cobbled_deepslate
setblock 51 95 597 minecraft:calcite
fill 51 95 598 51 98 598 minecraft:cobbled_deepslate
setblock 52 95 596 minecraft:calcite
fill 52 95 597 52 98 597 minecraft:cobbled_deepslate
setblock 53 95 595 minecraft:calcite
fill 53 95 596 53 98 596 minecraft:cobbled_deepslate
setblock 54 95 558 minecraft:cobbled_deepslate
fill 54 95 595 55 95 595 minecraft:cobbled_deepslate
setblock 55 95 558 minecraft:calcite
setblock 55 95 598 minecraft:calcite
setblock 56 95 558 minecraft:cobbled_deepslate
setblock 56 95 597 minecraft:calcite
fill 56 95 598 56 98 598 minecraft:cobbled_deepslate
setblock 57 95 596 minecraft:calcite
fill 57 95 597 57 98 597 minecraft:cobbled_deepslate
setblock 60 95 598 minecraft:calcite
fill 61 95 588 62 100 588 minecraft:deepslate
fill 71 95 558 74 95 558 minecraft:cobbled_deepslate
fill 71 95 598 74 95 598 minecraft:cobbled_deepslate
setblock 73 95 559 minecraft:cobbled_deepslate
fill 73 95 597 75 95 597 minecraft:cobbled_deepslate
setblock 74 95 559 minecraft:calcite
setblock 75 95 558 minecraft:calcite
fill 75 95 559 75 98 559 minecraft:cobbled_deepslate
setblock 75 95 598 minecraft:calcite
fill 76 95 558 76 98 558 minecraft:cobbled_deepslate
setblock 76 95 596 minecraft:cobbled_deepslate
setblock 76 95 597 minecraft:calcite
fill 76 95 598 76 98 598 minecraft:cobbled_deepslate
setblock 77 95 596 minecraft:calcite
fill 77 95 597 77 98 597 minecraft:cobbled_deepslate
fill 78 95 596 78 96 596 minecraft:cobbled_deepslate
setblock 79 95 559 minecraft:calcite
fill 80 95 557 80 195 557 minecraft:cobbled_deepslate
setblock 80 95 558 minecraft:calcite
setblock 80 95 559 minecraft:cobbled_deepslate
setblock 80 95 598 minecraft:calcite
fill 81 95 558 81 98 558 minecraft:cobbled_deepslate
setblock 81 95 597 minecraft:calcite
fill 81 95 598 84 95 598 minecraft:cobbled_deepslate
fill 82 95 597 83 96 597 minecraft:cobbled_deepslate
setblock 85 95 598 minecraft:calcite
fill 86 95 598 86 98 598 minecraft:cobbled_deepslate
setblock 87 95 590 minecraft:cobbled_deepslate
setblock 87 95 591 minecraft:calcite
fill 87 95 592 87 98 592 minecraft:cobbled_deepslate
setblock 87 95 595 minecraft:cobbled_deepslate
setblock 87 95 596 minecraft:calcite
fill 87 95 597 87 98 597 minecraft:cobbled_deepslate
setblock 88 95 565 minecraft:calcite
setblock 88 95 566 minecraft:cobbled_deepslate
setblock 88 95 570 minecraft:calcite
fill 88 95 571 88 97 571 minecraft:cobbled_deepslate
setblock 88 95 590 minecraft:calcite
fill 88 95 591 88 98 591 minecraft:cobbled_deepslate
setblock 88 95 595 minecraft:calcite
fill 88 95 596 88 98 596 minecraft:cobbled_deepslate
fill 89 95 590 89 199 590 minecraft:cobbled_deepslate
fill 89 95 595 89 199 595 minecraft:cobbled_deepslate
setblock 48 96 569 minecraft:calcite
fill 48 96 570 48 99 570 minecraft:cobbled_deepslate
setblock 48 96 574 minecraft:calcite
fill 48 96 575 48 98 576 minecraft:cobbled_deepslate
setblock 48 96 584 minecraft:calcite
fill 48 96 585 48 99 585 minecraft:cobbled_deepslate
setblock 48 96 589 minecraft:calcite
fill 48 96 590 48 99 590 minecraft:cobbled_deepslate
setblock 48 96 594 minecraft:calcite
fill 48 96 595 48 99 595 minecraft:cobbled_deepslate
setblock 49 96 588 minecraft:calcite
fill 49 96 589 49 99 589 minecraft:cobbled_deepslate
setblock 49 96 593 minecraft:calcite
fill 49 96 594 49 99 594 minecraft:cobbled_deepslate
setblock 49 96 597 minecraft:cobbled_deepslate
setblock 49 96 598 minecraft:calcite
setblock 50 96 560 minecraft:light[level=14]
setblock 50 96 568 minecraft:light[level=14]
setblock 50 96 576 minecraft:light[level=14]
setblock 50 96 584 minecraft:light[level=14]
fill 50 96 588 50 97 588 minecraft:cobbled_deepslate
setblock 50 96 591 minecraft:cobbled_deepslate
setblock 50 96 592 minecraft:calcite
fill 50 96 593 50 99 593 minecraft:cobbled_deepslate
setblock 50 96 596 minecraft:cobbled_deepslate
setblock 50 96 597 minecraft:calcite
fill 50 96 598 50 99 598 minecraft:cobbled_deepslate
setblock 51 96 591 minecraft:calcite
fill 51 96 592 51 97 592 minecraft:cobbled_deepslate
setblock 51 96 594 minecraft:cobbled_deepslate
setblock 51 96 596 minecraft:calcite
fill 51 96 597 51 99 597 minecraft:cobbled_deepslate
fill 52 96 596 52 99 596 minecraft:cobbled_deepslate
fill 53 96 595 54 96 595 minecraft:cobbled_deepslate
setblock 54 96 598 minecraft:calcite
setblock 55 96 597 minecraft:calcite
fill 55 96 598 55 99 598 minecraft:cobbled_deepslate
setblock 56 96 596 minecraft:calcite
fill 56 96 597 56 99 597 minecraft:cobbled_deepslate
setblock 58 96 560 minecraft:light[level=14]
setblock 58 96 568 minecraft:light[level=14]
setblock 58 96 576 minecraft:light[level=14]
setblock 58 96 584 minecraft:light[level=14]
setblock 58 96 592 minecraft:light[level=14]
setblock 59 96 598 minecraft:calcite
fill 60 96 588 60 100 589 minecraft:deepslate
fill 61 96 590 62 100 590 minecraft:deepslate
fill 63 96 589 63 100 589 minecraft:deepslate
setblock 66 96 560 minecraft:light[level=14]
setblock 66 96 568 minecraft:light[level=14]
setblock 66 96 576 minecraft:light[level=14]
setblock 66 96 584 minecraft:light[level=14]
setblock 66 96 592 minecraft:light[level=14]
fill 70 96 558 73 96 558 minecraft:cobbled_deepslate
fill 70 96 598 73 96 598 minecraft:cobbled_deepslate
setblock 72 96 559 minecraft:cobbled_deepslate
fill 72 96 597 74 96 597 minecraft:cobbled_deepslate
setblock 73 96 559 minecraft:calcite
setblock 74 96 558 minecraft:calcite
fill 74 96 559 74 99 559 minecraft:cobbled_deepslate
setblock 74 96 560 minecraft:light[level=14]
setblock 74 96 568 minecraft:light[level=14]
setblock 74 96 576 minecraft:light[level=14]
setblock 74 96 584 minecraft:light[level=14]
setblock 74 96 592 minecraft:light[level=14]
setblock 74 96 598 minecraft:calcite
fill 75 96 558 75 99 558 minecraft:cobbled_deepslate
setblock 75 96 596 minecraft:cobbled_deepslate
setblock 75 96 597 minecraft:calcite
fill 75 96 598 75 99 598 minecraft:cobbled_deepslate
setblock 76 96 596 minecraft:calcite
fill 76 96 597 76 99 597 minecraft:cobbled_deepslate
fill 77 96 596 77 97 596 minecraft:cobbled_deepslate
setblock 78 96 559 minecraft:calcite
setblock 79 96 558 minecraft:calcite
setblock 79 96 559 minecraft:cobbled_deepslate
setblock 79 96 598 minecraft:calcite
fill 80 96 558 80 99 558 minecraft:cobbled_deepslate
setblock 80 96 597 minecraft:calcite
fill 80 96 598 83 96 598 minecraft:cobbled_deepslate
fill 81 96 597 81 99 597 minecraft:cobbled_deepslate
setblock 82 96 560 minecraft:light[level=14]
setblock 82 96 568 minecraft:light[level=14]
setblock 82 96 576 minecraft:light[level=14]
setblock 82 96 584 minecraft:light[level=14]
setblock 82 96 592 minecraft:light[level=14]
setblock 84 96 598 minecraft:calcite
fill 85 96 598 85 99 598 minecraft:cobbled_deepslate
fill 86 96 581 88 96 581 minecraft:light_blue_stained_glass
fill 86 96 597 86 99 597 minecraft:cobbled_deepslate
setblock 87 96 580 minecraft:light_blue_stained_glass
setblock 87 96 582 minecraft:light_blue_stained_glass
setblock 87 96 590 minecraft:calcite
fill 87 96 591 87 98 591 minecraft:cobbled_deepslate
setblock 87 96 595 minecraft:calcite
fill 87 96 596 87 99 596 minecraft:cobbled_deepslate
setblock 88 96 569 minecraft:calcite
fill 88 96 570 88 97 570 minecraft:cobbled_deepslate
setblock 88 96 589 minecraft:calcite
fill 88 96 590 88 99 590 minecraft:cobbled_deepslate
setblock 88 96 594 minecraft:calcite
fill 88 96 595 88 99 595 minecraft:cobbled_deepslate
setblock 48 97 569 minecraft:cobbled_deepslate
setblock 48 97 572 minecraft:cobbled_deepslate
setblock 48 97 573 minecraft:calcite
fill 48 97 574 49 99 574 minecraft:cobbled_deepslate
setblock 48 97 577 minecraft:cobbled_deepslate
setblock 48 97 578 minecraft:calcite
setblock 48 97 584 minecraft:cobbled_deepslate
setblock 48 97 588 minecraft:calcite
fill 48 97 589 48 100 589 minecraft:cobbled_deepslate
setblock 48 97 593 minecraft:calcite
fill 48 97 594 48 100 594 minecraft:cobbled_deepslate
fill 48 97 596 48 97 597 minecraft:cobbled_deepslate
setblock 48 97 598 minecraft:calcite
setblock 49 97 572 minecraft:calcite
fill 49 97 573 49 100 573 minecraft:cobbled_deepslate
setblock 49 97 587 minecraft:calcite
fill 49 97 588 49 100 588 minecraft:cobbled_deepslate
setblock 49 97 592 minecraft:calcite
fill 49 97 593 49 100 593 minecraft:cobbled_deepslate
setblock 49 97 597 minecraft:calcite
fill 49 97 598 49 100 598 minecraft:cobbled_deepslate
setblock 50 97 591 minecraft:calcite
fill 50 97 592 50 100 592 minecraft:cobbled_deepslate
setblock 50 97 596 minecraft:calcite
fill 50 97 597 50 100 597 minecraft:cobbled_deepslate
setblock 51 97 591 minecraft:cobbled_deepslate
fill 51 97 596 51 100 596 minecraft:cobbled_deepslate
setblock 53 97 598 minecraft:calcite
setblock 54 97 597 minecraft:calcite
fill 54 97 598 54 100 598 minecraft:cobbled_deepslate
setblock 55 97 596 minecraft:calcite
fill 55 97 597 55 100 597 minecraft:cobbled_deepslate
setblock 56 97 596 minecraft:cobbled_deepslate
setblock 58 97 598 minecraft:calcite
setblock 59 97 598 minecraft:cobbled_deepslate
fill 60 97 590 60 100 590 minecraft:deepslate
fill 61 97 587 62 100 587 minecraft:deepslate
fill 63 97 588 63 100 588 minecraft:deepslate
fill 63 97 590 63 100 590 minecraft:deepslate
fill 70 97 558 72 97 558 minecraft:cobbled_deepslate
fill 70 97 598 72 97 598 minecraft:cobbled_deepslate
setblock 72 97 559 minecraft:calcite
fill 72 97 597 73 97 597 minecraft:cobbled_deepslate
setblock 73 97 558 minecraft:calcite
fill 73 97 559 73 100 559 minecraft:cobbled_deepslate
setblock 73 97 598 minecraft:calcite
fill 74 97 558 74 100 558 minecraft:cobbled_deepslate
setblock 74 97 597 minecraft:calcite
fill 74 97 598 74 100 598 minecraft:cobbled_deepslate
setblock 75 97 596 minecraft:calcite
fill 75 97 597 75 100 597 minecraft:cobbled_deepslate
fill 76 97 596 76 98 596 minecraft:cobbled_deepslate
setblock 77 97 559 minecraft:calcite
setblock 78 97 558 minecraft:calcite
fill 78 97 559 78 98 559 minecraft:cobbled_deepslate
setblock 78 97 598 minecraft:calcite
fill 79 97 558 79 100 558 minecraft:cobbled_deepslate
setblock 79 97 597 minecraft:calcite
fill 79 97 598 82 97 598 minecraft:cobbled_deepslate
fill 80 97 597 80 100 597 minecraft:cobbled_deepslate
setblock 82 97 597 minecraft:cobbled_deepslate
fill 83 97 557 83 199 557 minecraft:cobbled_deepslate
setblock 83 97 598 minecraft:calcite
fill 84 97 598 84 100 598 minecraft:cobbled_deepslate
fill 85 97 597 85 100 597 minecraft:cobbled_deepslate
setblock 87 97 594 minecraft:calcite
fill 87 97 595 87 100 595 minecraft:cobbled_deepslate
setblock 88 97 573 minecraft:calcite
setblock 88 97 588 minecraft:calcite
fill 88 97 589 88 100 589 minecraft:cobbled_deepslate
setblock 88 97 593 minecraft:calcite
fill 88 97 594 88 100 594 minecraft:cobbled_deepslate
setblock 88 97 598 minecraft:calcite
fill 89 97 593 89 197 593 minecraft:cobbled_deepslate
setblock 48 98 572 minecraft:calcite
fill 48 98 573 48 101 573 minecraft:cobbled_deepslate
setblock 48 98 577 minecraft:calcite
schedule function dropper:buildpart/133_4 1t
