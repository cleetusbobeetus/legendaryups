fill 357 86 558 357 89 558 minecraft:green_terracotta
setblock 357 86 596 minecraft:green_terracotta
setblock 357 86 597 minecraft:oak_log
fill 357 86 598 357 89 598 minecraft:green_terracotta
fill 358 86 597 358 88 597 minecraft:green_terracotta
setblock 361 86 558 minecraft:oak_log
setblock 361 86 598 minecraft:oak_log
setblock 362 86 598 minecraft:green_terracotta
setblock 368 86 586 minecraft:oak_log
fill 368 86 587 368 89 587 minecraft:green_terracotta
fill 368 86 589 368 87 589 minecraft:green_terracotta
setblock 369 86 558 minecraft:oak_leaves[persistent=true]
setblock 369 86 580 minecraft:oak_log
fill 369 86 581 369 89 581 minecraft:green_terracotta
setblock 369 86 585 minecraft:oak_log
fill 369 86 586 369 89 586 minecraft:green_terracotta
setblock 369 86 590 minecraft:oak_log
fill 369 86 591 369 88 592 minecraft:green_terracotta
setblock 369 86 598 minecraft:oak_leaves[persistent=true]
fill 370 86 560 370 86 563 minecraft:green_terracotta
setblock 370 86 564 minecraft:oak_log
fill 370 86 565 370 89 565 minecraft:green_terracotta
fill 370 86 567 370 86 568 minecraft:green_terracotta
setblock 370 86 569 minecraft:oak_log
fill 370 86 570 370 86 573 minecraft:green_terracotta
setblock 370 86 574 minecraft:oak_log
fill 370 86 575 370 89 575 minecraft:green_terracotta
setblock 370 86 579 minecraft:oak_log
fill 370 86 580 370 89 580 minecraft:green_terracotta
setblock 370 86 584 minecraft:oak_log
fill 370 86 585 370 89 585 minecraft:green_terracotta
setblock 370 86 589 minecraft:oak_log
fill 370 86 590 370 89 590 minecraft:green_terracotta
setblock 370 86 594 minecraft:oak_log
fill 370 86 595 370 89 595 minecraft:green_terracotta
setblock 330 87 558 minecraft:oak_log
fill 330 87 559 330 90 559 minecraft:green_terracotta
setblock 330 87 563 minecraft:oak_log
fill 330 87 564 330 90 564 minecraft:green_terracotta
setblock 330 87 568 minecraft:oak_log
fill 330 87 569 330 90 569 minecraft:green_terracotta
setblock 330 87 572 minecraft:green_terracotta
setblock 330 87 573 minecraft:oak_log
fill 330 87 574 330 90 574 minecraft:green_terracotta
setblock 330 87 578 minecraft:oak_log
fill 330 87 579 330 90 579 minecraft:green_terracotta
setblock 330 87 583 minecraft:oak_log
fill 330 87 584 330 90 584 minecraft:green_terracotta
setblock 330 87 588 minecraft:oak_log
fill 330 87 589 330 90 589 minecraft:green_terracotta
setblock 330 87 593 minecraft:oak_log
fill 331 87 558 334 87 558 minecraft:green_terracotta
setblock 331 87 561 minecraft:green_terracotta
setblock 331 87 562 minecraft:oak_log
fill 331 87 563 331 90 563 minecraft:green_terracotta
setblock 331 87 567 minecraft:oak_log
fill 331 87 568 331 90 568 minecraft:green_terracotta
setblock 331 87 572 minecraft:oak_log
fill 331 87 573 331 90 573 minecraft:green_terracotta
setblock 331 87 577 minecraft:oak_log
fill 331 87 578 331 88 578 minecraft:green_terracotta
setblock 331 87 582 minecraft:oak_log
fill 331 87 583 331 89 583 minecraft:green_terracotta
setblock 331 87 587 minecraft:oak_log
fill 331 87 588 331 90 588 minecraft:green_terracotta
setblock 331 87 598 minecraft:oak_leaves[persistent=true]
setblock 332 87 561 minecraft:oak_log
fill 332 87 562 332 89 562 minecraft:green_terracotta
setblock 332 87 565 minecraft:green_terracotta
setblock 332 87 566 minecraft:oak_log
fill 332 87 567 332 90 567 minecraft:green_terracotta
setblock 332 87 571 minecraft:oak_log
fill 332 87 572 332 90 572 minecraft:green_terracotta
setblock 332 87 582 minecraft:green_terracotta
setblock 332 87 586 minecraft:oak_log
fill 332 87 587 332 88 587 minecraft:green_terracotta
setblock 332 87 589 minecraft:green_terracotta
setblock 333 87 560 minecraft:oak_log
setblock 333 87 565 minecraft:oak_log
fill 333 87 566 333 90 566 minecraft:green_terracotta
setblock 333 87 570 minecraft:oak_log
fill 333 87 571 333 90 571 minecraft:green_terracotta
setblock 334 87 559 minecraft:oak_log
fill 334 87 560 334 88 560 minecraft:green_terracotta
setblock 334 87 565 minecraft:green_terracotta
setblock 335 87 558 minecraft:oak_log
fill 335 87 559 335 89 559 minecraft:green_terracotta
setblock 335 87 598 minecraft:oak_log
fill 336 87 558 339 87 558 minecraft:green_terracotta
setblock 336 87 598 minecraft:green_terracotta
fill 337 87 598 337 88 598 minecraft:oak_leaves[persistent=true]
setblock 338 87 560 minecraft:oak_log
setblock 339 87 559 minecraft:oak_log
setblock 340 87 558 minecraft:oak_log
setblock 340 87 559 minecraft:green_terracotta
fill 341 87 558 341 88 558 minecraft:green_terracotta
setblock 345 87 558 minecraft:oak_log
fill 346 87 558 346 88 558 minecraft:green_terracotta
setblock 349 87 559 minecraft:oak_log
setblock 350 87 558 minecraft:oak_log
fill 350 87 559 350 88 559 minecraft:green_terracotta
setblock 350 87 598 minecraft:oak_log
fill 351 87 558 351 90 558 minecraft:green_terracotta
setblock 351 87 597 minecraft:oak_log
fill 351 87 598 351 90 598 minecraft:green_terracotta
fill 352 87 597 352 90 597 minecraft:green_terracotta
setblock 353 87 560 minecraft:oak_log
fill 353 87 596 353 90 596 minecraft:green_terracotta
setblock 354 87 559 minecraft:oak_log
setblock 354 87 560 minecraft:green_terracotta
setblock 355 87 558 minecraft:oak_log
fill 355 87 559 355 88 559 minecraft:green_terracotta
setblock 355 87 598 minecraft:oak_log
fill 356 87 558 356 89 558 minecraft:green_terracotta
setblock 356 87 597 minecraft:oak_log
fill 356 87 598 356 90 598 minecraft:green_terracotta
fill 357 87 597 357 89 597 minecraft:green_terracotta
setblock 360 87 598 minecraft:oak_log
setblock 361 87 598 minecraft:green_terracotta
setblock 363 87 558 minecraft:oak_leaves[persistent=true]
setblock 368 87 585 minecraft:oak_log
fill 368 87 586 368 89 586 minecraft:green_terracotta
fill 369 87 565 369 87 568 minecraft:green_terracotta
setblock 369 87 569 minecraft:oak_log
setblock 369 87 580 minecraft:green_terracotta
setblock 369 87 584 minecraft:oak_log
fill 369 87 585 369 90 585 minecraft:green_terracotta
setblock 369 87 589 minecraft:oak_log
fill 369 87 590 369 90 590 minecraft:green_terracotta
fill 370 87 561 370 87 562 minecraft:green_terracotta
setblock 370 87 563 minecraft:oak_log
fill 370 87 564 370 90 564 minecraft:green_terracotta
setblock 370 87 567 minecraft:green_terracotta
setblock 370 87 568 minecraft:oak_log
fill 370 87 569 370 87 572 minecraft:green_terracotta
setblock 370 87 573 minecraft:oak_log
fill 370 87 574 370 90 574 minecraft:green_terracotta
setblock 370 87 578 minecraft:oak_log
fill 370 87 579 370 90 579 minecraft:green_terracotta
setblock 370 87 583 minecraft:oak_log
fill 370 87 584 370 90 584 minecraft:green_terracotta
setblock 370 87 588 minecraft:oak_log
fill 370 87 589 370 90 589 minecraft:green_terracotta
setblock 370 87 592 minecraft:green_terracotta
setblock 370 87 593 minecraft:oak_log
fill 370 87 594 370 90 594 minecraft:green_terracotta
setblock 330 88 562 minecraft:oak_log
fill 330 88 563 330 91 563 minecraft:green_terracotta
setblock 330 88 567 minecraft:oak_log
fill 330 88 568 330 91 568 minecraft:green_terracotta
setblock 330 88 572 minecraft:oak_log
fill 330 88 573 330 91 573 minecraft:green_terracotta
setblock 330 88 577 minecraft:oak_log
fill 330 88 578 330 91 578 minecraft:green_terracotta
setblock 330 88 582 minecraft:oak_log
fill 330 88 583 330 91 583 minecraft:green_terracotta
setblock 330 88 587 minecraft:oak_log
fill 330 88 588 330 91 588 minecraft:green_terracotta
setblock 330 88 591 minecraft:green_terracotta
setblock 330 88 592 minecraft:oak_log
fill 330 88 593 330 91 593 minecraft:green_terracotta
fill 331 88 558 333 88 558 minecraft:green_terracotta
setblock 331 88 561 minecraft:oak_log
fill 331 88 562 331 91 562 minecraft:green_terracotta
setblock 331 88 566 minecraft:oak_log
fill 331 88 567 331 91 567 minecraft:green_terracotta
setblock 331 88 571 minecraft:oak_log
fill 331 88 572 331 91 572 minecraft:green_terracotta
setblock 331 88 576 minecraft:oak_log
fill 331 88 577 331 90 577 minecraft:green_terracotta
setblock 331 88 581 minecraft:oak_log
fill 331 88 582 331 89 582 minecraft:green_terracotta
setblock 331 88 586 minecraft:oak_log
fill 331 88 587 331 91 587 minecraft:green_terracotta
setblock 331 88 591 minecraft:oak_log
setblock 332 88 561 minecraft:green_terracotta
setblock 332 88 565 minecraft:oak_log
fill 332 88 566 332 91 566 minecraft:green_terracotta
setblock 332 88 569 minecraft:green_terracotta
setblock 332 88 570 minecraft:oak_log
fill 332 88 571 332 91 571 minecraft:green_terracotta
setblock 332 88 574 minecraft:green_terracotta
setblock 332 88 585 minecraft:oak_log
setblock 332 88 586 minecraft:green_terracotta
setblock 333 88 559 minecraft:oak_log
setblock 333 88 564 minecraft:oak_log
fill 333 88 565 333 90 565 minecraft:green_terracotta
fill 333 88 567 333 89 567 minecraft:green_terracotta
setblock 333 88 569 minecraft:oak_log
fill 333 88 570 333 91 570 minecraft:green_terracotta
setblock 334 88 558 minecraft:oak_log
fill 334 88 559 334 89 559 minecraft:green_terracotta
fill 335 88 558 338 88 558 minecraft:green_terracotta
fill 335 88 585 335 100 585 minecraft:oak_leaves[persistent=true]
setblock 338 88 559 minecraft:oak_log
setblock 339 88 558 minecraft:oak_log
setblock 339 88 559 minecraft:green_terracotta
setblock 340 88 558 minecraft:green_terracotta
setblock 343 88 598 minecraft:oak_leaves[persistent=true]
setblock 349 88 558 minecraft:oak_log
setblock 349 88 559 minecraft:green_terracotta
setblock 349 88 598 minecraft:oak_log
fill 350 88 558 350 91 558 minecraft:green_terracotta
setblock 350 88 597 minecraft:oak_log
fill 350 88 598 350 91 598 minecraft:green_terracotta
fill 351 88 597 351 91 597 minecraft:green_terracotta
setblock 353 88 559 minecraft:oak_log
setblock 354 88 558 minecraft:oak_log
fill 354 88 559 354 89 559 minecraft:green_terracotta
setblock 354 88 598 minecraft:oak_log
fill 355 88 558 355 90 558 minecraft:green_terracotta
setblock 355 88 597 minecraft:oak_log
fill 355 88 598 355 91 598 minecraft:green_terracotta
setblock 356 88 596 minecraft:oak_log
fill 356 88 597 356 91 597 minecraft:green_terracotta
setblock 359 88 598 minecraft:oak_log
setblock 360 88 598 minecraft:green_terracotta
setblock 362 88 598 minecraft:oak_leaves[persistent=true]
setblock 368 88 585 minecraft:green_terracotta
setblock 368 88 589 minecraft:oak_log
fill 369 88 566 369 88 567 minecraft:green_terracotta
setblock 369 88 568 minecraft:oak_log
fill 369 88 569 370 89 570 minecraft:green_terracotta
setblock 369 88 583 minecraft:oak_log
fill 369 88 584 369 91 584 minecraft:green_terracotta
setblock 369 88 588 minecraft:oak_log
fill 369 88 589 369 91 589 minecraft:green_terracotta
setblock 370 88 561 minecraft:green_terracotta
setblock 370 88 562 minecraft:oak_log
fill 370 88 563 370 91 563 minecraft:green_terracotta
setblock 370 88 567 minecraft:oak_log
fill 370 88 568 370 91 568 minecraft:green_terracotta
setblock 370 88 571 minecraft:green_terracotta
setblock 370 88 572 minecraft:oak_log
fill 370 88 573 370 91 573 minecraft:green_terracotta
setblock 370 88 577 minecraft:oak_log
fill 370 88 578 370 91 578 minecraft:green_terracotta
setblock 370 88 582 minecraft:oak_log
fill 370 88 583 370 91 583 minecraft:green_terracotta
setblock 370 88 587 minecraft:oak_log
fill 370 88 588 370 91 588 minecraft:green_terracotta
setblock 370 88 592 minecraft:oak_log
fill 370 88 593 370 91 593 minecraft:green_terracotta
setblock 330 89 561 minecraft:oak_log
fill 330 89 562 330 92 562 minecraft:green_terracotta
setblock 330 89 566 minecraft:oak_log
fill 330 89 567 330 92 567 minecraft:green_terracotta
setblock 330 89 571 minecraft:oak_log
fill 330 89 572 330 92 572 minecraft:green_terracotta
setblock 330 89 576 minecraft:oak_log
fill 330 89 577 330 92 577 minecraft:green_terracotta
setblock 330 89 581 minecraft:oak_log
fill 330 89 582 330 92 582 minecraft:green_terracotta
setblock 330 89 586 minecraft:oak_log
fill 330 89 587 330 92 587 minecraft:green_terracotta
setblock 330 89 591 minecraft:oak_log
fill 330 89 592 331 91 592 minecraft:green_terracotta
fill 330 89 594 330 90 594 minecraft:green_terracotta
fill 331 89 558 332 89 558 minecraft:green_terracotta
fill 331 89 561 331 90 561 minecraft:green_terracotta
setblock 331 89 565 minecraft:oak_log
fill 331 89 566 331 92 566 minecraft:green_terracotta
setblock 331 89 570 minecraft:oak_log
fill 331 89 571 331 92 571 minecraft:green_terracotta
setblock 331 89 575 minecraft:oak_log
fill 331 89 576 331 92 576 minecraft:green_terracotta
setblock 331 89 581 minecraft:green_terracotta
setblock 331 89 585 minecraft:oak_log
fill 331 89 586 331 91 586 minecraft:green_terracotta
setblock 331 89 590 minecraft:oak_log
fill 331 89 591 331 92 591 minecraft:green_terracotta
setblock 332 89 560 minecraft:light[level=14]
setblock 332 89 564 minecraft:oak_log
fill 332 89 565 332 92 565 minecraft:green_terracotta
setblock 332 89 569 minecraft:oak_log
fill 332 89 570 332 92 570 minecraft:green_terracotta
setblock 332 89 574 minecraft:oak_log
setblock 332 89 576 minecraft:light[level=14]
setblock 332 89 584 minecraft:light[level=14]
setblock 332 89 592 minecraft:light[level=14]
setblock 333 89 558 minecraft:oak_log
setblock 333 89 559 minecraft:green_terracotta
setblock 333 89 564 minecraft:green_terracotta
setblock 333 89 568 minecraft:oak_log
fill 333 89 569 333 92 569 minecraft:green_terracotta
fill 334 89 558 337 89 558 minecraft:green_terracotta
setblock 338 89 558 minecraft:oak_log
setblock 339 89 558 minecraft:green_terracotta
setblock 340 89 560 minecraft:light[level=14]
setblock 340 89 568 minecraft:light[level=14]
setblock 340 89 576 minecraft:light[level=14]
setblock 340 89 584 minecraft:light[level=14]
setblock 340 89 592 minecraft:light[level=14]
setblock 348 89 558 minecraft:oak_log
setblock 348 89 560 minecraft:light[level=14]
setblock 348 89 568 minecraft:light[level=14]
setblock 348 89 576 minecraft:light[level=14]
setblock 348 89 584 minecraft:light[level=14]
setblock 348 89 592 minecraft:light[level=14]
setblock 348 89 598 minecraft:oak_log
fill 349 89 558 349 92 558 minecraft:green_terracotta
fill 349 89 598 349 92 598 minecraft:green_terracotta
fill 350 89 597 350 92 597 minecraft:green_terracotta
setblock 352 89 559 minecraft:oak_log
setblock 353 89 558 minecraft:oak_log
setblock 353 89 559 minecraft:green_terracotta
setblock 353 89 598 minecraft:oak_log
fill 354 89 558 354 91 558 minecraft:green_terracotta
setblock 354 89 597 minecraft:oak_log
fill 354 89 598 354 92 598 minecraft:green_terracotta
fill 355 89 559 355 96 559 minecraft:oak_leaves[persistent=true]
setblock 355 89 596 minecraft:oak_log
fill 355 89 597 355 92 597 minecraft:green_terracotta
setblock 356 89 560 minecraft:light[level=14]
setblock 356 89 568 minecraft:light[level=14]
setblock 356 89 576 minecraft:light[level=14]
setblock 356 89 584 minecraft:light[level=14]
setblock 356 89 592 minecraft:light[level=14]
setblock 358 89 598 minecraft:oak_log
setblock 359 89 598 minecraft:green_terracotta
setblock 364 89 560 minecraft:light[level=14]
setblock 364 89 568 minecraft:light[level=14]
setblock 364 89 576 minecraft:light[level=14]
setblock 364 89 584 minecraft:light[level=14]
setblock 364 89 592 minecraft:light[level=14]
setblock 368 89 588 minecraft:oak_log
setblock 368 89 589 minecraft:green_terracotta
setblock 368 89 598 minecraft:oak_leaves[persistent=true]
setblock 369 89 566 minecraft:green_terracotta
setblock 369 89 567 minecraft:oak_log
fill 369 89 568 369 92 568 minecraft:green_terracotta
setblock 369 89 571 minecraft:green_terracotta
setblock 369 89 572 minecraft:oak_log
setblock 369 89 582 minecraft:oak_log
fill 369 89 583 369 91 583 minecraft:green_terracotta
setblock 369 89 587 minecraft:oak_log
fill 369 89 588 369 92 588 minecraft:green_terracotta
setblock 369 89 591 minecraft:green_terracotta
setblock 369 89 592 minecraft:oak_log
fill 369 89 593 369 92 593 minecraft:green_terracotta
fill 370 89 562 370 90 562 minecraft:green_terracotta
setblock 370 89 566 minecraft:oak_log
fill 370 89 567 370 92 567 minecraft:green_terracotta
setblock 370 89 571 minecraft:oak_log
fill 370 89 572 370 92 572 minecraft:green_terracotta
setblock 370 89 576 minecraft:oak_log
fill 370 89 577 370 92 577 minecraft:green_terracotta
setblock 370 89 581 minecraft:oak_log
fill 370 89 582 370 92 582 minecraft:green_terracotta
setblock 370 89 586 minecraft:oak_log
fill 370 89 587 370 92 587 minecraft:green_terracotta
setblock 370 89 591 minecraft:oak_log
fill 370 89 592 370 92 592 minecraft:green_terracotta
setblock 330 90 560 minecraft:oak_log
fill 330 90 561 330 93 561 minecraft:green_terracotta
setblock 330 90 565 minecraft:oak_log
fill 330 90 566 330 93 566 minecraft:green_terracotta
setblock 330 90 570 minecraft:oak_log
fill 330 90 571 330 93 571 minecraft:green_terracotta
setblock 330 90 575 minecraft:oak_log
fill 330 90 576 330 93 576 minecraft:green_terracotta
setblock 330 90 580 minecraft:oak_log
fill 330 90 581 330 93 581 minecraft:green_terracotta
setblock 330 90 585 minecraft:oak_log
fill 330 90 586 330 93 586 minecraft:green_terracotta
setblock 330 90 590 minecraft:oak_log
fill 330 90 591 330 93 591 minecraft:green_terracotta
setblock 330 90 598 minecraft:oak_leaves[persistent=true]
setblock 331 90 558 minecraft:green_terracotta
setblock 331 90 564 minecraft:oak_log
fill 331 90 565 331 93 565 minecraft:green_terracotta
setblock 331 90 569 minecraft:oak_log
fill 331 90 570 331 93 570 minecraft:green_terracotta
setblock 331 90 574 minecraft:oak_log
fill 331 90 575 331 93 575 minecraft:green_terracotta
setblock 331 90 584 minecraft:oak_log
setblock 331 90 585 minecraft:green_terracotta
setblock 331 90 589 minecraft:oak_log
fill 331 90 590 331 93 590 minecraft:green_terracotta
setblock 332 90 558 minecraft:oak_log
setblock 332 90 563 minecraft:oak_log
fill 332 90 564 332 92 564 minecraft:green_terracotta
setblock 332 90 568 minecraft:oak_log
fill 332 90 569 332 93 569 minecraft:green_terracotta
setblock 332 90 573 minecraft:oak_log
fill 332 90 574 332 93 574 minecraft:green_terracotta
fill 333 90 558 336 90 558 minecraft:green_terracotta
setblock 333 90 567 minecraft:oak_log
fill 333 90 568 333 92 568 minecraft:green_terracotta
setblock 337 90 558 minecraft:oak_log
setblock 338 90 558 minecraft:green_terracotta
setblock 345 90 558 minecraft:oak_leaves[persistent=true]
setblock 347 90 598 minecraft:oak_log
fill 348 90 558 348 93 558 minecraft:green_terracotta
fill 348 90 598 348 93 598 minecraft:green_terracotta
setblock 352 90 558 minecraft:oak_log
fill 352 90 596 352 91 596 minecraft:green_terracotta
setblock 352 90 598 minecraft:oak_log
fill 353 90 558 353 93 558 minecraft:green_terracotta
setblock 353 90 597 minecraft:oak_log
fill 353 90 598 353 93 598 minecraft:green_terracotta
setblock 354 90 596 minecraft:oak_log
fill 354 90 597 354 93 597 minecraft:green_terracotta
setblock 357 90 598 minecraft:oak_log
setblock 358 90 598 minecraft:green_terracotta
setblock 368 90 588 minecraft:green_terracotta
setblock 369 90 566 minecraft:oak_log
fill 369 90 567 369 93 567 minecraft:green_terracotta
fill 369 90 569 369 90 570 minecraft:green_terracotta
setblock 369 90 571 minecraft:oak_log
fill 369 90 572 369 92 573 minecraft:green_terracotta
setblock 369 90 582 minecraft:green_terracotta
setblock 369 90 586 minecraft:oak_log
fill 369 90 587 369 93 587 minecraft:green_terracotta
setblock 369 90 591 minecraft:oak_log
fill 369 90 592 369 93 592 minecraft:green_terracotta
setblock 370 90 558 minecraft:oak_leaves[persistent=true]
setblock 370 90 565 minecraft:oak_log
fill 370 90 566 370 93 566 minecraft:green_terracotta
setblock 370 90 569 minecraft:green_terracotta
setblock 370 90 570 minecraft:oak_log
fill 370 90 571 370 93 571 minecraft:green_terracotta
setblock 370 90 575 minecraft:oak_log
fill 370 90 576 370 93 576 minecraft:green_terracotta
setblock 370 90 580 minecraft:oak_log
fill 370 90 581 370 93 581 minecraft:green_terracotta
setblock 370 90 585 minecraft:oak_log
fill 370 90 586 370 93 586 minecraft:green_terracotta
setblock 370 90 590 minecraft:oak_log
fill 370 90 591 370 93 591 minecraft:green_terracotta
setblock 370 90 595 minecraft:oak_log
setblock 330 91 559 minecraft:oak_log
fill 330 91 560 330 94 560 minecraft:green_terracotta
setblock 330 91 564 minecraft:oak_log
fill 330 91 565 330 94 565 minecraft:green_terracotta
setblock 330 91 569 minecraft:oak_log
fill 330 91 570 330 94 570 minecraft:green_terracotta
setblock 330 91 574 minecraft:oak_log
fill 330 91 575 330 94 575 minecraft:green_terracotta
setblock 330 91 579 minecraft:oak_log
fill 330 91 580 330 94 580 minecraft:green_terracotta
setblock 330 91 584 minecraft:oak_log
fill 330 91 585 330 94 585 minecraft:green_terracotta
setblock 330 91 589 minecraft:oak_log
fill 330 91 590 330 94 590 minecraft:green_terracotta
setblock 330 91 594 minecraft:oak_log
fill 330 91 595 330 94 595 minecraft:green_terracotta
setblock 331 91 558 minecraft:oak_log
setblock 331 91 563 minecraft:oak_log
fill 331 91 564 331 94 564 minecraft:green_terracotta
setblock 331 91 568 minecraft:oak_log
fill 331 91 569 331 94 569 minecraft:green_terracotta
setblock 331 91 573 minecraft:oak_log
fill 331 91 574 331 94 574 minecraft:green_terracotta
setblock 331 91 588 minecraft:oak_log
fill 331 91 589 331 93 589 minecraft:green_terracotta
fill 332 91 558 335 91 558 minecraft:green_terracotta
setblock 332 91 563 minecraft:green_terracotta
setblock 332 91 567 minecraft:oak_log
fill 332 91 568 332 94 568 minecraft:green_terracotta
setblock 332 91 572 minecraft:oak_log
fill 332 91 573 332 94 573 minecraft:green_terracotta
fill 333 91 565 333 119 566 minecraft:oak_log
fill 333 91 567 333 92 567 minecraft:green_terracotta
setblock 333 91 571 minecraft:oak_log
setblock 336 91 558 minecraft:oak_log
setblock 336 91 598 minecraft:oak_leaves[persistent=true]
setblock 339 91 558 minecraft:oak_leaves[persistent=true]
fill 347 91 598 347 94 598 minecraft:green_terracotta
fill 349 91 597 349 93 597 minecraft:green_terracotta
setblock 351 91 558 minecraft:oak_log
fill 351 91 596 351 92 596 minecraft:green_terracotta
setblock 351 91 598 minecraft:oak_log
fill 352 91 558 352 94 558 minecraft:green_terracotta
setblock 352 91 597 minecraft:oak_log
fill 352 91 598 352 94 598 minecraft:green_terracotta
setblock 353 91 596 minecraft:oak_log
fill 353 91 597 353 94 597 minecraft:green_terracotta
fill 354 91 596 354 94 596 minecraft:green_terracotta
setblock 356 91 598 minecraft:oak_log
fill 357 91 598 357 94 598 minecraft:green_terracotta
setblock 361 91 598 minecraft:oak_leaves[persistent=true]
setblock 364 91 558 minecraft:oak_leaves[persistent=true]
fill 369 91 566 369 94 566 minecraft:green_terracotta
setblock 369 91 569 minecraft:green_terracotta
setblock 369 91 570 minecraft:oak_log
fill 369 91 571 369 94 571 minecraft:green_terracotta
setblock 369 91 574 minecraft:green_terracotta
setblock 369 91 575 minecraft:oak_log
setblock 369 91 585 minecraft:oak_log
fill 369 91 586 369 94 586 minecraft:green_terracotta
setblock 369 91 590 minecraft:oak_log
fill 369 91 591 369 94 591 minecraft:green_terracotta
setblock 370 91 564 minecraft:oak_log
fill 370 91 565 370 94 565 minecraft:green_terracotta
setblock 370 91 569 minecraft:oak_log
fill 370 91 570 370 94 570 minecraft:green_terracotta
setblock 370 91 574 minecraft:oak_log
fill 370 91 575 370 94 575 minecraft:green_terracotta
setblock 370 91 579 minecraft:oak_log
fill 370 91 580 370 94 580 minecraft:green_terracotta
setblock 370 91 584 minecraft:oak_log
fill 370 91 585 370 94 585 minecraft:green_terracotta
setblock 370 91 589 minecraft:oak_log
fill 370 91 590 370 94 590 minecraft:green_terracotta
setblock 370 91 594 minecraft:oak_log
fill 370 91 595 370 93 596 minecraft:green_terracotta
fill 330 92 559 330 95 559 minecraft:green_terracotta
setblock 330 92 563 minecraft:oak_log
fill 330 92 564 330 95 564 minecraft:green_terracotta
setblock 330 92 568 minecraft:oak_log
fill 330 92 569 330 95 569 minecraft:green_terracotta
setblock 330 92 573 minecraft:oak_log
fill 330 92 574 330 95 574 minecraft:green_terracotta
setblock 330 92 578 minecraft:oak_log
fill 330 92 579 330 95 579 minecraft:green_terracotta
setblock 330 92 583 minecraft:oak_log
fill 330 92 584 330 95 584 minecraft:green_terracotta
setblock 330 92 588 minecraft:oak_log
fill 330 92 589 330 95 589 minecraft:green_terracotta
setblock 330 92 592 minecraft:green_terracotta
setblock 330 92 593 minecraft:oak_log
fill 330 92 594 330 95 594 minecraft:green_terracotta
fill 330 92 596 330 93 596 minecraft:green_terracotta
fill 331 92 558 334 92 558 minecraft:green_terracotta
setblock 331 92 562 minecraft:oak_log
fill 331 92 563 331 95 563 minecraft:green_terracotta
setblock 331 92 567 minecraft:oak_log
fill 331 92 568 331 95 568 minecraft:green_terracotta
setblock 331 92 572 minecraft:oak_log
fill 331 92 573 331 95 573 minecraft:green_terracotta
setblock 331 92 577 minecraft:oak_log
setblock 331 92 588 minecraft:green_terracotta
setblock 331 92 592 minecraft:oak_log
setblock 332 92 566 minecraft:oak_log
fill 332 92 567 332 95 567 minecraft:green_terracotta
setblock 332 92 571 minecraft:oak_log
fill 332 92 572 332 95 572 minecraft:green_terracotta
setblock 333 92 570 minecraft:oak_log
setblock 335 92 558 minecraft:oak_log
setblock 342 92 598 minecraft:oak_leaves[persistent=true]
fill 346 92 598 346 95 598 minecraft:green_terracotta
fill 348 92 597 348 94 597 minecraft:green_terracotta
setblock 350 92 558 minecraft:oak_log
fill 350 92 596 350 93 596 minecraft:green_terracotta
setblock 350 92 598 minecraft:oak_log
fill 351 92 558 351 95 558 minecraft:green_terracotta
setblock 351 92 597 minecraft:oak_log
fill 351 92 598 351 95 598 minecraft:green_terracotta
setblock 352 92 596 minecraft:oak_log
fill 352 92 597 352 95 597 minecraft:green_terracotta
fill 353 92 596 353 95 596 minecraft:green_terracotta
setblock 355 92 598 minecraft:oak_log
setblock 356 92 597 minecraft:oak_log
fill 356 92 598 356 95 598 minecraft:green_terracotta
setblock 358 92 558 minecraft:oak_leaves[persistent=true]
setblock 367 92 598 minecraft:oak_leaves[persistent=true]
setblock 369 92 569 minecraft:oak_log
fill 369 92 570 369 95 570 minecraft:green_terracotta
setblock 369 92 574 minecraft:oak_log
fill 369 92 575 369 93 577 minecraft:green_terracotta
setblock 369 92 584 minecraft:oak_log
fill 369 92 585 369 95 585 minecraft:green_terracotta
setblock 369 92 589 minecraft:oak_log
fill 369 92 590 369 95 590 minecraft:green_terracotta
setblock 369 92 594 minecraft:oak_log
setblock 370 92 563 minecraft:oak_log
fill 370 92 564 370 95 564 minecraft:green_terracotta
setblock 370 92 568 minecraft:oak_log
fill 370 92 569 370 95 569 minecraft:green_terracotta
setblock 370 92 573 minecraft:oak_log
fill 370 92 574 370 95 574 minecraft:green_terracotta
setblock 370 92 578 minecraft:oak_log
fill 370 92 579 370 95 579 minecraft:green_terracotta
setblock 370 92 583 minecraft:oak_log
fill 370 92 584 370 95 584 minecraft:green_terracotta
setblock 370 92 588 minecraft:oak_log
fill 370 92 589 370 95 589 minecraft:green_terracotta
setblock 370 92 593 minecraft:oak_log
fill 370 92 594 370 95 594 minecraft:green_terracotta
fill 330 93 558 333 93 558 minecraft:green_terracotta
setblock 330 93 562 minecraft:oak_log
fill 330 93 563 330 96 563 minecraft:green_terracotta
setblock 330 93 567 minecraft:oak_log
fill 330 93 568 330 96 568 minecraft:green_terracotta
setblock 330 93 572 minecraft:oak_log
fill 330 93 573 330 96 573 minecraft:green_terracotta
setblock 330 93 577 minecraft:oak_log
fill 330 93 578 330 96 578 minecraft:green_terracotta
setblock 330 93 582 minecraft:oak_log
setblock 330 93 583 minecraft:green_terracotta
setblock 330 93 587 minecraft:oak_log
fill 330 93 588 330 96 588 minecraft:green_terracotta
setblock 330 93 592 minecraft:oak_log
fill 330 93 593 331 95 593 minecraft:green_terracotta
setblock 330 93 597 minecraft:oak_log
fill 331 93 562 331 96 562 minecraft:green_terracotta
setblock 331 93 566 minecraft:oak_log
fill 331 93 567 331 96 567 minecraft:green_terracotta
setblock 331 93 571 minecraft:oak_log
fill 331 93 572 331 96 572 minecraft:green_terracotta
setblock 331 93 576 minecraft:oak_log
fill 331 93 577 331 96 577 minecraft:green_terracotta
setblock 331 93 591 minecraft:oak_log
fill 331 93 592 331 96 592 minecraft:green_terracotta
fill 331 93 598 333 93 598 minecraft:green_terracotta
setblock 332 93 565 minecraft:oak_log
fill 332 93 566 332 96 566 minecraft:green_terracotta
setblock 332 93 570 minecraft:oak_log
fill 332 93 571 332 96 571 minecraft:green_terracotta
fill 333 93 567 333 119 567 minecraft:oak_log
setblock 333 93 569 minecraft:oak_log
setblock 333 93 570 minecraft:green_terracotta
setblock 334 93 558 minecraft:oak_log
fill 335 93 558 335 96 558 minecraft:green_terracotta
fill 345 93 598 345 96 598 minecraft:green_terracotta
fill 347 93 558 347 94 558 minecraft:green_terracotta
fill 347 93 597 347 95 597 minecraft:green_terracotta
setblock 349 93 558 minecraft:oak_log
fill 349 93 596 349 94 596 minecraft:green_terracotta
setblock 349 93 598 minecraft:oak_log
fill 350 93 558 350 96 558 minecraft:green_terracotta
setblock 350 93 597 minecraft:oak_log
fill 350 93 598 350 96 598 minecraft:green_terracotta
setblock 351 93 596 minecraft:oak_log
fill 351 93 597 351 96 597 minecraft:green_terracotta
fill 352 93 596 352 96 596 minecraft:green_terracotta
setblock 354 93 598 minecraft:oak_log
setblock 355 93 597 minecraft:oak_log
fill 355 93 598 355 96 598 minecraft:green_terracotta
fill 356 93 597 356 96 597 minecraft:green_terracotta
fill 368 93 571 368 94 572 minecraft:green_terracotta
setblock 369 93 568 minecraft:oak_log
fill 369 93 569 369 96 569 minecraft:green_terracotta
setblock 369 93 572 minecraft:green_terracotta
setblock 369 93 573 minecraft:oak_log
fill 369 93 574 369 96 574 minecraft:green_terracotta
setblock 369 93 578 minecraft:oak_log
fill 369 93 584 369 96 584 minecraft:green_terracotta
setblock 369 93 588 minecraft:oak_log
fill 369 93 589 369 96 589 minecraft:green_terracotta
setblock 369 93 593 minecraft:oak_log
fill 369 93 594 369 96 594 minecraft:green_terracotta
setblock 370 93 559 minecraft:oak_leaves[persistent=true]
fill 370 93 563 370 96 563 minecraft:green_terracotta
setblock 370 93 567 minecraft:oak_log
fill 370 93 568 370 96 568 minecraft:green_terracotta
setblock 370 93 572 minecraft:oak_log
fill 370 93 573 370 96 573 minecraft:green_terracotta
setblock 370 93 577 minecraft:oak_log
fill 370 93 578 370 96 578 minecraft:green_terracotta
setblock 370 93 582 minecraft:oak_log
fill 370 93 583 370 96 583 minecraft:green_terracotta
setblock 370 93 587 minecraft:oak_log
fill 370 93 588 370 96 588 minecraft:green_terracotta
setblock 370 93 592 minecraft:oak_log
fill 370 93 593 370 96 593 minecraft:green_terracotta
setblock 370 93 597 minecraft:oak_log
fill 330 94 558 332 94 558 minecraft:green_terracotta
setblock 330 94 561 minecraft:oak_log
fill 330 94 562 330 97 562 minecraft:green_terracotta
setblock 330 94 566 minecraft:oak_log
fill 330 94 567 330 97 567 minecraft:green_terracotta
setblock 330 94 571 minecraft:oak_log
fill 330 94 572 330 97 572 minecraft:green_terracotta
setblock 330 94 576 minecraft:oak_log
fill 330 94 577 330 97 577 minecraft:green_terracotta
setblock 330 94 581 minecraft:oak_log
fill 330 94 582 330 97 582 minecraft:green_terracotta
setblock 330 94 586 minecraft:oak_log
fill 330 94 587 330 97 587 minecraft:green_terracotta
setblock 330 94 591 minecraft:oak_log
fill 330 94 592 330 97 592 minecraft:green_terracotta
setblock 330 94 596 minecraft:oak_log
fill 330 94 597 330 96 598 minecraft:green_terracotta
setblock 331 94 565 minecraft:oak_log
fill 331 94 566 331 97 566 minecraft:green_terracotta
setblock 331 94 570 minecraft:oak_log
fill 331 94 571 331 97 571 minecraft:green_terracotta
setblock 331 94 575 minecraft:oak_log
fill 331 94 576 331 97 576 minecraft:green_terracotta
setblock 331 94 590 minecraft:oak_log
fill 331 94 591 331 97 591 minecraft:green_terracotta
setblock 331 94 594 minecraft:green_terracotta
setblock 331 94 595 minecraft:oak_log
fill 331 94 598 332 94 598 minecraft:green_terracotta
fill 332 94 565 332 95 565 minecraft:green_terracotta
setblock 332 94 569 minecraft:oak_log
fill 332 94 570 332 97 570 minecraft:green_terracotta
setblock 332 94 574 minecraft:oak_log
fill 332 94 575 332 97 575 minecraft:green_terracotta
setblock 333 94 558 minecraft:oak_log
setblock 333 94 598 minecraft:oak_log
fill 334 94 558 334 97 558 minecraft:green_terracotta
fill 334 94 598 335 96 598 minecraft:green_terracotta
fill 340 94 558 340 95 558 minecraft:oak_leaves[persistent=true]
setblock 343 94 598 minecraft:oak_log
fill 344 94 598 344 97 598 minecraft:green_terracotta
fill 345 94 597 346 96 597 minecraft:green_terracotta
fill 346 94 558 346 95 558 minecraft:green_terracotta
fill 347 94 596 348 95 596 minecraft:green_terracotta
setblock 348 94 558 minecraft:oak_log
setblock 348 94 598 minecraft:oak_log
fill 349 94 558 349 97 558 minecraft:green_terracotta
setblock 349 94 597 minecraft:oak_log
fill 349 94 598 349 97 598 minecraft:green_terracotta
setblock 350 94 595 minecraft:green_terracotta
setblock 350 94 596 minecraft:oak_log
fill 350 94 597 350 97 597 minecraft:green_terracotta
setblock 351 94 595 minecraft:oak_log
fill 351 94 596 351 97 596 minecraft:green_terracotta
fill 352 94 595 352 97 595 minecraft:green_terracotta
setblock 353 94 558 minecraft:oak_log
setblock 353 94 598 minecraft:oak_log
setblock 354 94 597 minecraft:oak_log
fill 354 94 598 354 97 598 minecraft:green_terracotta
fill 355 94 597 355 97 597 minecraft:green_terracotta
setblock 365 94 558 minecraft:oak_leaves[persistent=true]
fill 368 94 569 368 96 570 minecraft:green_terracotta
setblock 368 94 573 minecraft:oak_log
fill 368 94 574 368 96 575 minecraft:green_terracotta
setblock 369 94 567 minecraft:oak_log
fill 369 94 568 369 97 568 minecraft:green_terracotta
setblock 369 94 572 minecraft:oak_log
fill 369 94 573 369 97 573 minecraft:green_terracotta
fill 369 94 575 369 94 576 minecraft:green_terracotta
setblock 369 94 577 minecraft:oak_log
fill 369 94 578 369 94 581 minecraft:green_terracotta
setblock 369 94 587 minecraft:oak_log
fill 369 94 588 369 97 588 minecraft:green_terracotta
setblock 369 94 592 minecraft:oak_log
fill 369 94 593 369 97 593 minecraft:green_terracotta
fill 369 94 595 370 94 595 minecraft:green_terracotta
fill 369 94 598 370 96 598 minecraft:green_terracotta
setblock 370 94 566 minecraft:oak_log
fill 370 94 567 370 97 567 minecraft:green_terracotta
setblock 370 94 571 minecraft:oak_log
fill 370 94 572 370 97 572 minecraft:green_terracotta
setblock 370 94 576 minecraft:oak_log
fill 370 94 577 370 97 577 minecraft:green_terracotta
setblock 370 94 581 minecraft:oak_log
fill 370 94 582 370 97 582 minecraft:green_terracotta
setblock 370 94 586 minecraft:oak_log
fill 370 94 587 370 97 587 minecraft:green_terracotta
setblock 370 94 591 minecraft:oak_log
fill 370 94 592 370 97 592 minecraft:green_terracotta
setblock 370 94 596 minecraft:oak_log
fill 370 94 597 370 97 597 minecraft:green_terracotta
fill 330 95 558 331 95 558 minecraft:green_terracotta
setblock 330 95 560 minecraft:oak_log
fill 330 95 561 331 97 561 minecraft:green_terracotta
setblock 330 95 565 minecraft:oak_log
fill 330 95 566 330 98 566 minecraft:green_terracotta
setblock 330 95 570 minecraft:oak_log
fill 330 95 571 330 98 571 minecraft:green_terracotta
setblock 330 95 575 minecraft:oak_log
fill 330 95 576 330 98 576 minecraft:green_terracotta
setblock 330 95 580 minecraft:oak_log
fill 330 95 581 330 98 581 minecraft:green_terracotta
fill 330 95 583 330 96 583 minecraft:green_terracotta
setblock 330 95 585 minecraft:oak_log
fill 330 95 586 330 98 586 minecraft:green_terracotta
setblock 330 95 590 minecraft:oak_log
fill 330 95 591 330 98 591 minecraft:green_terracotta
setblock 330 95 595 minecraft:oak_log
fill 330 95 596 331 97 596 minecraft:green_terracotta
setblock 331 95 564 minecraft:oak_log
fill 331 95 565 331 98 565 minecraft:green_terracotta
setblock 331 95 569 minecraft:oak_log
fill 331 95 570 331 98 570 minecraft:green_terracotta
setblock 331 95 574 minecraft:oak_log
fill 331 95 575 331 98 575 minecraft:green_terracotta
setblock 331 95 578 minecraft:green_terracotta
setblock 331 95 590 minecraft:green_terracotta
setblock 331 95 594 minecraft:oak_log
fill 331 95 595 331 98 595 minecraft:green_terracotta
fill 331 95 597 331 95 598 minecraft:green_terracotta
setblock 332 95 558 minecraft:oak_log
setblock 332 95 568 minecraft:oak_log
fill 332 95 569 332 98 569 minecraft:green_terracotta
setblock 332 95 573 minecraft:oak_log
fill 332 95 574 332 98 574 minecraft:green_terracotta
setblock 332 95 597 minecraft:green_terracotta
setblock 332 95 598 minecraft:oak_log
fill 333 95 558 333 98 558 minecraft:green_terracotta
fill 333 95 598 333 98 598 minecraft:green_terracotta
setblock 336 95 558 minecraft:green_terracotta
setblock 336 95 598 minecraft:green_terracotta
setblock 341 95 598 minecraft:green_terracotta
setblock 342 95 598 minecraft:oak_log
fill 343 95 598 343 98 598 minecraft:green_terracotta
fill 344 95 558 345 96 558 minecraft:green_terracotta
fill 344 95 597 344 98 597 minecraft:green_terracotta
fill 346 95 596 346 97 596 minecraft:green_terracotta
setblock 347 95 558 minecraft:oak_log
setblock 347 95 598 minecraft:oak_log
fill 348 95 558 348 98 558 minecraft:green_terracotta
fill 348 95 595 349 95 595 minecraft:green_terracotta
setblock 348 95 597 minecraft:oak_log
fill 348 95 598 348 98 598 minecraft:green_terracotta
setblock 349 95 596 minecraft:oak_log
fill 349 95 597 349 98 597 minecraft:green_terracotta
setblock 350 95 595 minecraft:oak_log
fill 350 95 596 350 98 596 minecraft:green_terracotta
fill 351 95 595 351 98 595 minecraft:green_terracotta
setblock 352 95 558 minecraft:oak_log
setblock 352 95 598 minecraft:oak_log
fill 353 95 558 353 98 558 minecraft:green_terracotta
fill 353 95 595 353 96 595 minecraft:green_terracotta
setblock 353 95 597 minecraft:oak_log
fill 353 95 598 353 98 598 minecraft:green_terracotta
setblock 354 95 596 minecraft:oak_log
fill 354 95 597 354 98 597 minecraft:green_terracotta
fill 355 95 596 355 98 596 minecraft:green_terracotta
setblock 357 95 598 minecraft:oak_log
fill 358 95 598 358 98 598 minecraft:green_terracotta
setblock 359 95 558 minecraft:oak_leaves[persistent=true]
setblock 360 95 598 minecraft:oak_leaves[persistent=true]
setblock 367 95 598 minecraft:oak_log
fill 368 95 568 368 98 568 minecraft:green_terracotta
setblock 368 95 571 minecraft:green_terracotta
setblock 368 95 572 minecraft:oak_log
fill 368 95 573 368 98 573 minecraft:green_terracotta
setblock 368 95 576 minecraft:green_terracotta
setblock 368 95 577 minecraft:oak_log
fill 368 95 581 368 97 581 minecraft:iron_block
setblock 368 95 591 minecraft:green_terracotta
setblock 368 95 592 minecraft:oak_log
fill 368 95 598 368 98 598 minecraft:green_terracotta
setblock 369 95 565 minecraft:green_terracotta
setblock 369 95 566 minecraft:oak_log
fill 369 95 567 369 98 567 minecraft:green_terracotta
setblock 369 95 571 minecraft:oak_log
fill 369 95 572 369 98 572 minecraft:green_terracotta
setblock 369 95 575 minecraft:green_terracotta
setblock 369 95 576 minecraft:oak_log
fill 369 95 577 369 95 580 minecraft:green_terracotta
setblock 369 95 581 minecraft:oak_log
fill 369 95 582 369 97 583 minecraft:green_terracotta
setblock 369 95 586 minecraft:oak_log
fill 369 95 587 369 98 587 minecraft:green_terracotta
setblock 369 95 591 minecraft:oak_log
fill 369 95 592 369 98 592 minecraft:green_terracotta
setblock 369 95 595 minecraft:green_terracotta
setblock 369 95 596 minecraft:oak_log
fill 370 95 562 370 97 562 minecraft:green_terracotta
setblock 370 95 565 minecraft:oak_log
fill 370 95 566 370 98 566 minecraft:green_terracotta
setblock 370 95 570 minecraft:oak_log
fill 370 95 571 370 98 571 minecraft:green_terracotta
setblock 370 95 575 minecraft:oak_log
fill 370 95 576 370 98 576 minecraft:green_terracotta
setblock 370 95 580 minecraft:oak_log
fill 370 95 581 370 98 581 minecraft:green_terracotta
setblock 370 95 585 minecraft:oak_log
fill 370 95 586 370 98 586 minecraft:green_terracotta
setblock 370 95 590 minecraft:oak_log
fill 370 95 591 370 98 591 minecraft:green_terracotta
setblock 370 95 595 minecraft:oak_log
fill 370 95 596 370 98 596 minecraft:green_terracotta
setblock 330 96 558 minecraft:green_terracotta
setblock 330 96 559 minecraft:oak_log
fill 330 96 560 331 98 560 minecraft:green_terracotta
setblock 330 96 564 minecraft:oak_log
fill 330 96 565 330 99 565 minecraft:green_terracotta
setblock 330 96 569 minecraft:oak_log
fill 330 96 570 330 99 570 minecraft:green_terracotta
setblock 330 96 574 minecraft:oak_log
fill 330 96 575 330 99 575 minecraft:green_terracotta
setblock 330 96 579 minecraft:oak_log
fill 330 96 580 330 99 580 minecraft:green_terracotta
setblock 330 96 584 minecraft:oak_log
fill 330 96 585 330 98 585 minecraft:green_terracotta
setblock 330 96 589 minecraft:oak_log
fill 330 96 590 330 99 590 minecraft:green_terracotta
setblock 330 96 593 minecraft:green_terracotta
setblock 330 96 594 minecraft:oak_log
fill 330 96 595 330 99 595 minecraft:green_terracotta
setblock 331 96 558 minecraft:oak_log
fill 331 96 559 333 97 559 minecraft:green_terracotta
setblock 331 96 563 minecraft:oak_log
fill 331 96 564 331 99 564 minecraft:green_terracotta
setblock 331 96 568 minecraft:oak_log
fill 331 96 569 331 99 569 minecraft:green_terracotta
setblock 331 96 573 minecraft:oak_log
fill 331 96 574 331 99 574 minecraft:green_terracotta
setblock 331 96 578 minecraft:oak_log
fill 331 96 579 331 99 579 minecraft:green_terracotta
setblock 331 96 593 minecraft:oak_log
fill 331 96 594 331 99 594 minecraft:green_terracotta
setblock 331 96 597 minecraft:green_terracotta
setblock 331 96 598 minecraft:oak_log
fill 332 96 558 332 99 558 minecraft:green_terracotta
fill 332 96 565 332 119 565 minecraft:oak_log
setblock 332 96 567 minecraft:oak_log
fill 332 96 568 332 99 568 minecraft:green_terracotta
setblock 332 96 572 minecraft:oak_log
fill 332 96 573 332 99 573 minecraft:green_terracotta
setblock 332 96 576 minecraft:green_terracotta
setblock 332 96 597 minecraft:oak_log
fill 332 96 598 332 99 598 minecraft:green_terracotta
fill 333 96 597 334 98 597 minecraft:green_terracotta
setblock 336 96 558 minecraft:oak_log
setblock 336 96 598 minecraft:oak_log
fill 337 96 558 338 98 558 minecraft:green_terracotta
fill 337 96 598 340 96 598 minecraft:green_terracotta
setblock 341 96 558 minecraft:oak_log
setblock 341 96 598 minecraft:oak_log
fill 342 96 558 343 98 558 minecraft:green_terracotta
setblock 342 96 597 minecraft:oak_log
fill 342 96 598 342 99 598 minecraft:green_terracotta
fill 343 96 597 343 99 597 minecraft:green_terracotta
fill 344 96 596 345 98 596 minecraft:green_terracotta
setblock 346 96 558 minecraft:oak_log
setblock 346 96 598 minecraft:oak_log
fill 347 96 558 347 99 558 minecraft:green_terracotta
fill 347 96 595 347 96 596 minecraft:green_terracotta
setblock 347 96 597 minecraft:oak_log
fill 347 96 598 347 99 598 minecraft:green_terracotta
fill 348 96 559 349 96 559 minecraft:green_terracotta
setblock 348 96 595 minecraft:green_terracotta
setblock 348 96 596 minecraft:oak_log
fill 348 96 597 348 99 597 minecraft:green_terracotta
setblock 349 96 595 minecraft:oak_log
fill 349 96 596 349 99 596 minecraft:green_terracotta
fill 350 96 595 350 99 595 minecraft:green_terracotta
setblock 351 96 558 minecraft:oak_log
setblock 351 96 598 minecraft:oak_log
fill 352 96 558 352 99 558 minecraft:green_terracotta
setblock 352 96 597 minecraft:oak_log
fill 352 96 598 352 99 598 minecraft:green_terracotta
setblock 353 96 596 minecraft:oak_log
fill 353 96 597 353 99 597 minecraft:green_terracotta
fill 354 96 596 354 99 596 minecraft:green_terracotta
setblock 356 96 598 minecraft:oak_log
setblock 357 96 597 minecraft:oak_log
fill 357 96 598 357 99 598 minecraft:green_terracotta
fill 359 96 598 359 97 598 minecraft:green_terracotta
fill 364 96 598 365 96 598 minecraft:green_terracotta
setblock 366 96 598 minecraft:oak_log
setblock 367 96 572 minecraft:oak_log
fill 367 96 573 367 98 574 minecraft:green_terracotta
setblock 367 96 597 minecraft:oak_log
fill 367 96 598 367 99 598 minecraft:green_terracotta
setblock 368 96 571 minecraft:oak_log
fill 368 96 572 368 99 572 minecraft:green_terracotta
setblock 368 96 576 minecraft:oak_log
fill 368 96 577 369 96 579 minecraft:green_terracotta
setblock 368 96 591 minecraft:oak_log
fill 368 96 592 368 97 594 minecraft:green_terracotta
fill 368 96 597 369 98 597 minecraft:green_terracotta
fill 369 96 558 370 96 558 minecraft:green_terracotta
setblock 369 96 565 minecraft:oak_log
fill 369 96 566 369 99 566 minecraft:green_terracotta
setblock 369 96 570 minecraft:oak_log
fill 369 96 571 369 99 571 minecraft:green_terracotta
setblock 369 96 575 minecraft:oak_log
fill 369 96 576 369 99 576 minecraft:green_terracotta
setblock 369 96 580 minecraft:oak_log
fill 369 96 581 369 99 581 minecraft:green_terracotta
setblock 369 96 585 minecraft:oak_log
fill 369 96 586 369 99 586 minecraft:green_terracotta
setblock 369 96 590 minecraft:oak_log
fill 369 96 591 369 99 591 minecraft:green_terracotta
setblock 369 96 595 minecraft:oak_log
fill 369 96 596 369 99 596 minecraft:green_terracotta
setblock 370 96 559 minecraft:oak_log
fill 370 96 560 370 98 561 minecraft:green_terracotta
setblock 370 96 564 minecraft:oak_log
fill 370 96 565 370 99 565 minecraft:green_terracotta
setblock 370 96 569 minecraft:oak_log
fill 370 96 570 370 99 570 minecraft:green_terracotta
setblock 370 96 574 minecraft:oak_log
fill 370 96 575 370 99 575 minecraft:green_terracotta
setblock 370 96 579 minecraft:oak_log
fill 370 96 580 370 99 580 minecraft:green_terracotta
setblock 370 96 584 minecraft:oak_log
fill 370 96 585 370 99 585 minecraft:green_terracotta
setblock 370 96 589 minecraft:oak_log
fill 370 96 590 370 99 590 minecraft:green_terracotta
setblock 370 96 594 minecraft:oak_log
fill 370 96 595 370 99 595 minecraft:green_terracotta
fill 329 97 557 329 97 558 minecraft:dirt
setblock 329 97 559 minecraft:brown_terracotta
fill 329 97 560 329 98 579 minecraft:dirt
setblock 329 97 580 minecraft:brown_terracotta
fill 329 97 581 329 97 592 minecraft:dirt
setblock 329 97 593 minecraft:brown_terracotta
fill 329 97 594 329 98 599 minecraft:dirt
fill 330 97 557 335 97 557 minecraft:dirt
setblock 330 97 558 minecraft:oak_log
fill 330 97 559 330 100 559 minecraft:green_terracotta
setblock 330 97 563 minecraft:oak_log
fill 330 97 564 330 100 564 minecraft:green_terracotta
setblock 330 97 568 minecraft:oak_log
fill 330 97 569 330 100 569 minecraft:green_terracotta
setblock 330 97 573 minecraft:oak_log
fill 330 97 574 330 100 574 minecraft:green_terracotta
setblock 330 97 578 minecraft:oak_log
fill 330 97 579 330 100 579 minecraft:green_terracotta
setblock 330 97 583 minecraft:oak_log
fill 330 97 584 330 100 584 minecraft:green_terracotta
setblock 330 97 588 minecraft:oak_log
fill 330 97 589 330 100 589 minecraft:green_terracotta
setblock 330 97 593 minecraft:oak_log
fill 330 97 594 330 100 594 minecraft:green_terracotta
setblock 330 97 597 minecraft:green_terracotta
setblock 330 97 598 minecraft:oak_log
fill 330 97 599 330 101 599 minecraft:dirt
fill 331 97 558 331 100 558 minecraft:green_terracotta
setblock 331 97 562 minecraft:oak_log
fill 331 97 563 331 100 563 minecraft:green_terracotta
setblock 331 97 567 minecraft:oak_log
fill 331 97 568 331 100 568 minecraft:green_terracotta
setblock 331 97 572 minecraft:oak_log
fill 331 97 573 331 100 573 minecraft:green_terracotta
setblock 331 97 577 minecraft:oak_log
fill 331 97 578 331 100 578 minecraft:green_terracotta
setblock 331 97 592 minecraft:oak_log
fill 331 97 593 331 100 593 minecraft:green_terracotta
setblock 331 97 597 minecraft:oak_log
fill 331 97 598 331 100 598 minecraft:green_terracotta
setblock 331 97 599 minecraft:brown_terracotta
setblock 332 97 560 minecraft:light[level=14]
fill 332 97 566 332 119 566 minecraft:oak_log
fill 332 97 567 332 98 567 minecraft:green_terracotta
setblock 332 97 571 minecraft:oak_log
fill 332 97 572 332 100 572 minecraft:green_terracotta
setblock 332 97 576 minecraft:oak_log
setblock 332 97 584 minecraft:light[level=14]
setblock 332 97 592 minecraft:light[level=14]
fill 332 97 597 332 100 597 minecraft:green_terracotta
fill 332 97 599 335 97 599 minecraft:dirt
setblock 334 97 559 minecraft:oak_log
setblock 334 97 598 minecraft:green_terracotta
setblock 335 97 558 minecraft:oak_log
setblock 335 97 597 minecraft:green_terracotta
setblock 335 97 598 minecraft:oak_log
setblock 336 97 557 minecraft:brown_terracotta
fill 336 97 558 336 100 558 minecraft:green_terracotta
fill 336 97 598 339 97 598 minecraft:green_terracotta
setblock 336 97 599 minecraft:brown_terracotta
fill 337 97 557 340 98 557 minecraft:dirt
fill 337 97 599 346 97 599 minecraft:dirt
setblock 339 97 558 minecraft:green_terracotta
setblock 340 97 558 minecraft:oak_log
setblock 340 97 560 minecraft:light[level=14]
setblock 340 97 568 minecraft:light[level=14]
setblock 340 97 576 minecraft:light[level=14]
setblock 340 97 584 minecraft:light[level=14]
setblock 340 97 592 minecraft:light[level=14]
setblock 340 97 597 minecraft:green_terracotta
setblock 340 97 598 minecraft:oak_log
setblock 341 97 557 minecraft:brown_terracotta
fill 341 97 558 341 100 558 minecraft:green_terracotta
setblock 341 97 597 minecraft:oak_log
fill 341 97 598 341 100 598 minecraft:green_terracotta
fill 342 97 557 345 97 557 minecraft:dirt
fill 342 97 597 342 100 597 minecraft:green_terracotta
fill 343 97 596 343 100 596 minecraft:green_terracotta
setblock 344 97 558 minecraft:green_terracotta
setblock 345 97 558 minecraft:oak_log
fill 345 97 559 348 97 559 minecraft:green_terracotta
fill 345 97 595 347 97 595 minecraft:green_terracotta
setblock 345 97 597 minecraft:green_terracotta
setblock 345 97 598 minecraft:oak_log
setblock 346 97 557 minecraft:brown_terracotta
fill 346 97 558 346 100 558 minecraft:green_terracotta
setblock 346 97 597 minecraft:oak_log
fill 346 97 598 346 100 598 minecraft:green_terracotta
fill 347 97 557 371 97 557 minecraft:dirt
setblock 347 97 596 minecraft:oak_log
fill 347 97 597 347 100 597 minecraft:green_terracotta
setblock 347 97 599 minecraft:brown_terracotta
setblock 348 97 560 minecraft:light[level=14]
setblock 348 97 568 minecraft:light[level=14]
setblock 348 97 576 minecraft:light[level=14]
setblock 348 97 584 minecraft:light[level=14]
setblock 348 97 592 minecraft:light[level=14]
setblock 348 97 595 minecraft:oak_log
fill 348 97 596 348 100 596 minecraft:green_terracotta
fill 348 97 599 353 97 599 minecraft:dirt
setblock 349 97 559 minecraft:oak_log
setblock 349 97 594 minecraft:oak_log
fill 349 97 595 349 100 595 minecraft:green_terracotta
setblock 350 97 558 minecraft:oak_log
fill 350 97 559 350 100 559 minecraft:green_terracotta
fill 350 97 594 350 99 594 minecraft:green_terracotta
setblock 350 97 598 minecraft:oak_log
fill 351 97 558 351 100 558 minecraft:green_terracotta
setblock 351 97 597 minecraft:oak_log
fill 351 97 598 351 100 598 minecraft:green_terracotta
setblock 352 97 596 minecraft:oak_log
fill 352 97 597 352 100 597 minecraft:green_terracotta
setblock 353 97 595 minecraft:oak_log
fill 353 97 596 353 100 596 minecraft:green_terracotta
setblock 354 97 558 minecraft:green_terracotta
setblock 354 97 599 minecraft:brown_terracotta
setblock 355 97 598 minecraft:oak_log
fill 355 97 599 371 97 599 minecraft:dirt
setblock 356 97 560 minecraft:light[level=14]
setblock 356 97 568 minecraft:light[level=14]
setblock 356 97 576 minecraft:light[level=14]
setblock 356 97 584 minecraft:light[level=14]
setblock 356 97 592 minecraft:light[level=14]
setblock 356 97 597 minecraft:oak_log
fill 356 97 598 356 100 598 minecraft:green_terracotta
fill 357 97 597 357 100 597 minecraft:green_terracotta
setblock 360 97 598 minecraft:oak_log
fill 361 97 598 364 97 598 minecraft:green_terracotta
setblock 364 97 560 minecraft:light[level=14]
setblock 364 97 568 minecraft:light[level=14]
setblock 364 97 576 minecraft:light[level=14]
setblock 364 97 584 minecraft:light[level=14]
setblock 364 97 592 minecraft:light[level=14]
fill 364 97 597 365 97 597 minecraft:green_terracotta
setblock 365 97 598 minecraft:oak_log
setblock 366 97 558 minecraft:oak_leaves[persistent=true]
setblock 366 97 597 minecraft:oak_log
fill 366 97 598 366 100 598 minecraft:green_terracotta
fill 367 97 558 369 97 558 minecraft:green_terracotta
setblock 367 97 571 minecraft:oak_log
fill 367 97 572 367 100 572 minecraft:green_terracotta
setblock 367 97 575 minecraft:green_terracotta
setblock 367 97 576 minecraft:oak_log
fill 367 97 577 369 98 577 minecraft:green_terracotta
fill 367 97 597 367 100 597 minecraft:green_terracotta
setblock 368 97 569 minecraft:green_terracotta
setblock 368 97 570 minecraft:oak_log
fill 368 97 571 368 100 571 minecraft:green_terracotta
setblock 368 97 574 minecraft:green_terracotta
setblock 368 97 575 minecraft:oak_log
fill 368 97 576 368 100 576 minecraft:green_terracotta
fill 368 97 578 368 97 579 minecraft:green_terracotta
setblock 368 97 580 minecraft:oak_log
setblock 368 97 590 minecraft:oak_log
fill 368 97 591 368 98 591 minecraft:green_terracotta
setblock 368 97 595 minecraft:oak_log
setblock 369 97 564 minecraft:oak_log
fill 369 97 565 369 100 565 minecraft:green_terracotta
setblock 369 97 569 minecraft:oak_log
fill 369 97 570 369 100 570 minecraft:green_terracotta
setblock 369 97 574 minecraft:oak_log
fill 369 97 575 369 100 575 minecraft:green_terracotta
setblock 369 97 578 minecraft:green_terracotta
setblock 369 97 579 minecraft:oak_log
fill 369 97 580 369 100 580 minecraft:green_terracotta
setblock 369 97 584 minecraft:oak_log
fill 369 97 585 369 100 585 minecraft:green_terracotta
setblock 369 97 589 minecraft:oak_log
fill 369 97 590 369 100 590 minecraft:green_terracotta
setblock 369 97 594 minecraft:oak_log
fill 369 97 595 369 100 595 minecraft:green_terracotta
setblock 369 97 598 minecraft:green_terracotta
setblock 370 97 558 minecraft:oak_log
fill 370 97 559 370 100 559 minecraft:green_terracotta
setblock 370 97 563 minecraft:oak_log
fill 370 97 564 370 100 564 minecraft:green_terracotta
setblock 370 97 568 minecraft:oak_log
fill 370 97 569 370 100 569 minecraft:green_terracotta
setblock 370 97 573 minecraft:oak_log
fill 370 97 574 370 100 574 minecraft:green_terracotta
setblock 370 97 578 minecraft:oak_log
fill 370 97 579 370 100 579 minecraft:green_terracotta
setblock 370 97 583 minecraft:oak_log
fill 370 97 584 370 100 584 minecraft:green_terracotta
setblock 370 97 588 minecraft:oak_log
fill 370 97 589 370 100 589 minecraft:green_terracotta
setblock 370 97 593 minecraft:oak_log
fill 370 97 594 370 100 594 minecraft:green_terracotta
setblock 370 97 598 minecraft:oak_log
fill 371 97 558 371 98 563 minecraft:dirt
setblock 371 97 564 minecraft:brown_terracotta
fill 371 97 565 371 97 580 minecraft:dirt
fill 371 97 581 371 98 581 minecraft:brown_terracotta
fill 371 97 582 371 97 591 minecraft:dirt
setblock 371 97 592 minecraft:brown_terracotta
fill 371 97 593 371 100 594 minecraft:dirt
setblock 371 97 595 minecraft:brown_terracotta
fill 371 97 596 371 100 598 minecraft:dirt
fill 329 98 557 331 98 557 minecraft:dirt
setblock 329 98 558 minecraft:brown_terracotta
fill 329 98 559 329 100 559 minecraft:dirt
fill 329 98 580 329 100 581 minecraft:dirt
setblock 329 98 582 minecraft:brown_terracotta
setblock 329 98 583 minecraft:dirt
setblock 329 98 584 minecraft:brown_terracotta
fill 329 98 585 329 98 593 minecraft:dirt
fill 330 98 558 330 101 558 minecraft:green_terracotta
setblock 330 98 561 minecraft:green_terracotta
setblock 330 98 562 minecraft:oak_log
fill 330 98 563 330 101 563 minecraft:green_terracotta
setblock 330 98 567 minecraft:oak_log
fill 330 98 568 330 101 568 minecraft:green_terracotta
setblock 330 98 572 minecraft:oak_log
fill 330 98 573 330 101 573 minecraft:green_terracotta
setblock 330 98 577 minecraft:oak_log
fill 330 98 578 330 101 578 minecraft:green_terracotta
setblock 330 98 582 minecraft:oak_log
fill 330 98 583 330 101 583 minecraft:green_terracotta
setblock 330 98 587 minecraft:oak_log
fill 330 98 588 330 99 588 minecraft:green_terracotta
setblock 330 98 592 minecraft:oak_log
fill 330 98 593 330 101 593 minecraft:green_terracotta
setblock 330 98 596 minecraft:green_terracotta
setblock 330 98 597 minecraft:oak_log
fill 330 98 598 330 101 598 minecraft:green_terracotta
fill 331 98 559 332 98 559 minecraft:green_terracotta
setblock 331 98 561 minecraft:oak_log
fill 331 98 562 331 101 562 minecraft:green_terracotta
setblock 331 98 566 minecraft:oak_log
fill 331 98 567 331 101 567 minecraft:green_terracotta
setblock 331 98 571 minecraft:oak_log
fill 331 98 572 331 101 572 minecraft:green_terracotta
setblock 331 98 576 minecraft:oak_log
fill 331 98 577 331 101 577 minecraft:green_terracotta
setblock 331 98 580 minecraft:green_terracotta
setblock 331 98 591 minecraft:oak_log
fill 331 98 592 331 99 592 minecraft:green_terracotta
setblock 331 98 596 minecraft:oak_log
fill 331 98 597 331 101 597 minecraft:green_terracotta
fill 331 98 599 333 100 599 minecraft:dirt
fill 332 98 557 332 99 557 minecraft:brown_terracotta
setblock 332 98 570 minecraft:oak_log
fill 332 98 571 332 100 571 minecraft:green_terracotta
setblock 332 98 575 minecraft:oak_log
fill 332 98 576 332 100 576 minecraft:green_terracotta
fill 333 98 557 333 100 557 minecraft:dirt
setblock 333 98 559 minecraft:oak_log
fill 334 98 557 334 99 557 minecraft:brown_terracotta
setblock 334 98 558 minecraft:oak_log
fill 334 98 559 335 100 559 minecraft:green_terracotta
setblock 334 98 598 minecraft:oak_log
setblock 334 98 599 minecraft:brown_terracotta
fill 335 98 557 336 100 557 minecraft:dirt
fill 335 98 558 335 101 558 minecraft:green_terracotta
setblock 335 98 597 minecraft:oak_log
fill 335 98 598 338 98 598 minecraft:green_terracotta
fill 335 98 599 336 100 599 minecraft:dirt
fill 336 98 597 339 98 597 minecraft:green_terracotta
setblock 337 98 599 minecraft:brown_terracotta
fill 338 98 599 348 100 599 minecraft:dirt
setblock 339 98 558 minecraft:oak_log
setblock 339 98 598 minecraft:oak_log
fill 340 98 558 340 101 558 minecraft:green_terracotta
setblock 340 98 597 minecraft:oak_log
fill 340 98 598 340 101 598 minecraft:green_terracotta
fill 341 98 557 341 100 557 minecraft:dirt
fill 341 98 597 341 101 597 minecraft:green_terracotta
setblock 342 98 557 minecraft:brown_terracotta
fill 342 98 596 342 101 596 minecraft:green_terracotta
fill 343 98 557 360 100 557 minecraft:dirt
setblock 343 98 559 minecraft:oak_log
setblock 344 98 558 minecraft:oak_log
fill 344 98 559 347 98 559 minecraft:green_terracotta
fill 344 98 595 346 98 595 minecraft:green_terracotta
setblock 344 98 598 minecraft:oak_log
fill 345 98 558 345 101 558 minecraft:green_terracotta
setblock 345 98 597 minecraft:oak_log
fill 345 98 598 345 101 598 minecraft:green_terracotta
setblock 346 98 596 minecraft:oak_log
fill 346 98 597 346 101 597 minecraft:green_terracotta
setblock 347 98 594 minecraft:green_terracotta
setblock 347 98 595 minecraft:oak_log
fill 347 98 596 347 101 596 minecraft:green_terracotta
setblock 348 98 559 minecraft:oak_log
setblock 348 98 594 minecraft:oak_log
fill 348 98 595 348 101 595 minecraft:green_terracotta
setblock 349 98 558 minecraft:oak_log
fill 349 98 559 349 101 559 minecraft:green_terracotta
fill 349 98 594 349 100 594 minecraft:green_terracotta
setblock 349 98 598 minecraft:oak_log
setblock 349 98 599 minecraft:brown_terracotta
fill 350 98 558 350 101 558 minecraft:green_terracotta
setblock 350 98 597 minecraft:oak_log
fill 350 98 598 350 101 598 minecraft:green_terracotta
fill 350 98 599 363 98 599 minecraft:dirt
fill 351 98 559 351 99 559 minecraft:green_terracotta
setblock 351 98 596 minecraft:oak_log
fill 351 98 597 351 101 597 minecraft:green_terracotta
setblock 352 98 595 minecraft:oak_log
fill 352 98 596 352 101 596 minecraft:green_terracotta
fill 353 98 595 353 99 595 minecraft:green_terracotta
setblock 354 98 558 minecraft:oak_log
setblock 354 98 598 minecraft:oak_log
setblock 355 98 597 minecraft:oak_log
fill 355 98 598 355 101 598 minecraft:green_terracotta
fill 356 98 597 356 101 597 minecraft:green_terracotta
fill 358 98 597 358 99 597 minecraft:green_terracotta
setblock 359 98 598 minecraft:oak_log
setblock 360 98 558 minecraft:oak_leaves[persistent=true]
fill 360 98 598 363 98 598 minecraft:green_terracotta
fill 361 98 557 361 99 557 minecraft:brown_terracotta
fill 362 98 557 371 98 557 minecraft:dirt
fill 362 98 597 364 98 597 minecraft:green_terracotta
setblock 364 98 598 minecraft:oak_log
fill 364 98 599 365 98 599 minecraft:brown_terracotta
fill 365 98 558 368 98 558 minecraft:green_terracotta
setblock 365 98 597 minecraft:oak_log
fill 365 98 598 365 101 598 minecraft:green_terracotta
setblock 366 98 596 minecraft:oak_log
fill 366 98 597 366 101 597 minecraft:green_terracotta
fill 366 98 599 371 98 599 minecraft:dirt
setblock 367 98 570 minecraft:oak_log
fill 367 98 571 367 101 571 minecraft:green_terracotta
setblock 367 98 575 minecraft:oak_log
fill 367 98 576 367 101 576 minecraft:green_terracotta
fill 367 98 578 367 98 579 minecraft:green_terracotta
fill 367 98 596 368 100 596 minecraft:green_terracotta
fill 368 98 567 368 99 567 minecraft:green_terracotta
setblock 368 98 569 minecraft:oak_log
fill 368 98 570 368 101 570 minecraft:green_terracotta
setblock 368 98 574 minecraft:oak_log
fill 368 98 575 368 101 575 minecraft:green_terracotta
setblock 368 98 578 minecraft:green_terracotta
setblock 368 98 579 minecraft:oak_log
fill 368 98 580 368 99 582 minecraft:green_terracotta
fill 368 98 592 368 98 593 minecraft:green_terracotta
setblock 368 98 594 minecraft:oak_log
fill 368 98 595 368 100 595 minecraft:green_terracotta
setblock 369 98 558 minecraft:oak_log
fill 369 98 559 369 101 559 minecraft:green_terracotta
fill 369 98 564 369 101 564 minecraft:green_terracotta
setblock 369 98 568 minecraft:oak_log
fill 369 98 569 369 101 569 minecraft:green_terracotta
setblock 369 98 573 minecraft:oak_log
fill 369 98 574 369 101 574 minecraft:green_terracotta
setblock 369 98 578 minecraft:oak_log
fill 369 98 579 369 101 579 minecraft:green_terracotta
setblock 369 98 582 minecraft:green_terracotta
setblock 369 98 583 minecraft:oak_log
fill 369 98 584 369 101 584 minecraft:green_terracotta
setblock 369 98 588 minecraft:oak_log
fill 369 98 589 369 100 589 minecraft:green_terracotta
setblock 369 98 593 minecraft:oak_log
fill 369 98 594 369 101 594 minecraft:green_terracotta
setblock 369 98 598 minecraft:oak_log
fill 370 98 558 370 101 558 minecraft:green_terracotta
setblock 370 98 562 minecraft:oak_log
fill 370 98 563 370 101 563 minecraft:green_terracotta
setblock 370 98 567 minecraft:oak_log
fill 370 98 568 370 101 568 minecraft:green_terracotta
setblock 370 98 572 minecraft:oak_log
fill 370 98 573 370 101 573 minecraft:green_terracotta
setblock 370 98 577 minecraft:oak_log
fill 370 98 578 370 101 578 minecraft:green_terracotta
setblock 370 98 582 minecraft:oak_log
fill 370 98 583 370 101 583 minecraft:green_terracotta
setblock 370 98 587 minecraft:oak_log
fill 370 98 588 370 101 588 minecraft:green_terracotta
setblock 370 98 592 minecraft:oak_log
fill 370 98 593 370 101 593 minecraft:green_terracotta
setblock 370 98 597 minecraft:oak_log
fill 370 98 598 370 101 598 minecraft:green_terracotta
fill 371 98 564 371 100 570 minecraft:dirt
setblock 371 98 571 minecraft:brown_terracotta
setblock 371 98 572 minecraft:dirt
fill 371 98 573 371 98 574 minecraft:brown_terracotta
fill 371 98 575 371 100 575 minecraft:dirt
setblock 371 98 576 minecraft:brown_terracotta
fill 371 98 577 371 100 577 minecraft:dirt
setblock 371 98 578 minecraft:brown_terracotta
fill 371 98 579 371 100 580 minecraft:dirt
fill 371 98 582 371 100 588 minecraft:dirt
setblock 371 98 589 minecraft:brown_terracotta
fill 371 98 590 371 100 590 minecraft:dirt
setblock 371 98 591 minecraft:brown_terracotta
fill 371 98 592 371 100 592 minecraft:dirt
fill 371 98 595 371 100 595 minecraft:dirt
setblock 329 99 557 minecraft:brown_terracotta
fill 329 99 558 329 100 558 minecraft:dirt
fill 329 99 560 329 100 561 minecraft:dirt
setblock 329 99 562 minecraft:brown_terracotta
fill 329 99 563 329 100 568 minecraft:dirt
setblock 329 99 569 minecraft:brown_terracotta
fill 329 99 570 329 100 575 minecraft:dirt
setblock 329 99 576 minecraft:brown_terracotta
fill 329 99 577 329 100 579 minecraft:dirt
fill 329 99 582 329 100 582 minecraft:dirt
setblock 329 99 583 minecraft:brown_terracotta
fill 329 99 584 329 100 589 minecraft:dirt
fill 329 99 590 329 99 591 minecraft:brown_terracotta
fill 329 99 592 329 100 598 minecraft:dirt
setblock 329 99 599 minecraft:brown_terracotta
fill 330 99 557 331 100 557 minecraft:dirt
setblock 330 99 560 minecraft:green_terracotta
setblock 330 99 561 minecraft:oak_log
fill 330 99 562 330 102 562 minecraft:green_terracotta
setblock 330 99 566 minecraft:oak_log
fill 330 99 567 330 102 567 minecraft:green_terracotta
setblock 330 99 571 minecraft:oak_log
fill 330 99 572 330 102 572 minecraft:green_terracotta
setblock 330 99 576 minecraft:oak_log
fill 330 99 577 330 102 577 minecraft:green_terracotta
setblock 330 99 581 minecraft:oak_log
fill 330 99 582 330 102 582 minecraft:green_terracotta
setblock 330 99 587 minecraft:green_terracotta
setblock 330 99 591 minecraft:oak_log
fill 330 99 592 330 102 592 minecraft:green_terracotta
setblock 330 99 596 minecraft:oak_log
fill 330 99 597 330 102 597 minecraft:green_terracotta
setblock 331 99 559 minecraft:green_terracotta
setblock 331 99 560 minecraft:oak_log
fill 331 99 561 331 102 561 minecraft:green_terracotta
setblock 331 99 565 minecraft:oak_log
fill 331 99 566 331 101 566 minecraft:green_terracotta
setblock 331 99 570 minecraft:oak_log
fill 331 99 571 331 102 571 minecraft:green_terracotta
setblock 331 99 575 minecraft:oak_log
fill 331 99 576 331 102 576 minecraft:green_terracotta
setblock 331 99 580 minecraft:oak_log
setblock 331 99 595 minecraft:oak_log
fill 331 99 596 332 99 596 minecraft:green_terracotta
setblock 332 99 559 minecraft:oak_log
fill 332 99 567 332 119 567 minecraft:oak_log
setblock 332 99 569 minecraft:oak_log
fill 332 99 570 332 100 570 minecraft:green_terracotta
setblock 332 99 574 minecraft:oak_log
fill 332 99 575 332 100 575 minecraft:green_terracotta
setblock 333 99 558 minecraft:oak_log
fill 333 99 559 333 102 559 minecraft:green_terracotta
setblock 333 99 597 minecraft:green_terracotta
setblock 333 99 598 minecraft:oak_log
fill 334 99 558 334 102 558 minecraft:green_terracotta
setblock 334 99 597 minecraft:oak_log
fill 334 99 598 337 99 598 minecraft:green_terracotta
fill 334 99 599 334 100 599 minecraft:dirt
fill 335 99 597 338 99 597 minecraft:green_terracotta
setblock 336 99 559 minecraft:green_terracotta
fill 337 99 557 337 100 557 minecraft:dirt
setblock 337 99 558 minecraft:green_terracotta
fill 337 99 599 337 100 599 minecraft:dirt
setblock 338 99 557 minecraft:brown_terracotta
setblock 338 99 558 minecraft:oak_log
setblock 338 99 598 minecraft:oak_log
fill 339 99 557 339 100 557 minecraft:dirt
fill 339 99 558 339 102 558 minecraft:green_terracotta
setblock 339 99 597 minecraft:oak_log
fill 339 99 598 339 102 598 minecraft:green_terracotta
setblock 340 99 557 minecraft:brown_terracotta
fill 340 99 597 340 102 597 minecraft:green_terracotta
setblock 341 99 559 minecraft:green_terracotta
fill 341 99 596 341 102 596 minecraft:green_terracotta
fill 342 99 557 342 100 557 minecraft:dirt
setblock 342 99 558 minecraft:green_terracotta
setblock 342 99 559 minecraft:oak_log
setblock 343 99 558 minecraft:oak_log
fill 343 99 559 346 99 559 minecraft:green_terracotta
fill 343 99 595 345 99 595 minecraft:green_terracotta
setblock 343 99 598 minecraft:oak_log
fill 344 99 558 344 102 558 minecraft:green_terracotta
setblock 344 99 596 minecraft:green_terracotta
setblock 344 99 597 minecraft:oak_log
fill 344 99 598 344 102 598 minecraft:green_terracotta
setblock 345 99 596 minecraft:oak_log
fill 345 99 597 345 102 597 minecraft:green_terracotta
setblock 346 99 595 minecraft:oak_log
fill 346 99 596 346 102 596 minecraft:green_terracotta
setblock 347 99 559 minecraft:oak_log
setblock 347 99 594 minecraft:oak_log
fill 347 99 595 347 102 595 minecraft:green_terracotta
setblock 348 99 558 minecraft:oak_log
fill 348 99 559 348 102 559 minecraft:green_terracotta
fill 348 99 594 348 100 594 minecraft:green_terracotta
setblock 348 99 598 minecraft:oak_log
fill 349 99 558 349 102 558 minecraft:green_terracotta
setblock 349 99 597 minecraft:oak_log
fill 349 99 598 349 102 598 minecraft:green_terracotta
fill 349 99 599 356 100 599 minecraft:dirt
setblock 350 99 596 minecraft:oak_log
fill 350 99 597 350 102 597 minecraft:green_terracotta
setblock 351 99 595 minecraft:oak_log
fill 351 99 596 351 102 596 minecraft:green_terracotta
fill 352 99 595 352 100 595 minecraft:green_terracotta
setblock 353 99 558 minecraft:oak_log
setblock 353 99 598 minecraft:oak_log
fill 354 99 558 354 101 558 minecraft:green_terracotta
setblock 354 99 597 minecraft:oak_log
fill 354 99 598 354 102 598 minecraft:green_terracotta
setblock 355 99 596 minecraft:oak_log
fill 355 99 597 355 102 597 minecraft:green_terracotta
setblock 357 99 599 minecraft:brown_terracotta
setblock 358 99 598 minecraft:oak_log
fill 358 99 599 362 100 599 minecraft:dirt
setblock 359 99 597 minecraft:oak_log
fill 359 99 598 362 99 598 minecraft:green_terracotta
fill 360 99 597 363 99 597 minecraft:green_terracotta
fill 362 99 557 362 100 557 minecraft:dirt
setblock 363 99 557 minecraft:brown_terracotta
setblock 363 99 598 minecraft:oak_log
setblock 363 99 599 minecraft:brown_terracotta
fill 364 99 557 367 100 557 minecraft:dirt
fill 364 99 558 367 99 558 minecraft:green_terracotta
setblock 364 99 597 minecraft:oak_log
fill 364 99 598 364 102 598 minecraft:green_terracotta
fill 364 99 599 364 100 599 minecraft:dirt
setblock 365 99 596 minecraft:oak_log
fill 365 99 597 365 102 597 minecraft:green_terracotta
setblock 365 99 599 minecraft:brown_terracotta
setblock 366 99 574 minecraft:green_terracotta
setblock 366 99 575 minecraft:oak_log
fill 366 99 596 366 101 596 minecraft:green_terracotta
fill 366 99 599 370 100 599 minecraft:dirt
setblock 367 99 559 minecraft:oak_log
fill 367 99 570 367 100 570 minecraft:green_terracotta
setblock 367 99 573 minecraft:green_terracotta
setblock 367 99 574 minecraft:oak_log
fill 367 99 575 367 102 575 minecraft:green_terracotta
fill 367 99 577 367 99 578 minecraft:green_terracotta
setblock 367 99 579 minecraft:oak_log
fill 367 99 580 367 102 580 minecraft:green_terracotta
setblock 368 99 557 minecraft:brown_terracotta
setblock 368 99 558 minecraft:oak_log
fill 368 99 559 368 102 559 minecraft:green_terracotta
setblock 368 99 568 minecraft:oak_log
fill 368 99 569 368 102 569 minecraft:green_terracotta
setblock 368 99 573 minecraft:oak_log
fill 368 99 574 368 102 574 minecraft:green_terracotta
setblock 368 99 577 minecraft:green_terracotta
setblock 368 99 578 minecraft:oak_log
fill 368 99 579 368 102 579 minecraft:green_terracotta
setblock 368 99 592 minecraft:green_terracotta
setblock 368 99 593 minecraft:oak_log
fill 368 99 594 368 100 594 minecraft:green_terracotta
setblock 368 99 597 minecraft:green_terracotta
setblock 368 99 598 minecraft:oak_log
fill 369 99 557 371 100 557 minecraft:dirt
fill 369 99 558 369 102 558 minecraft:green_terracotta
fill 369 99 560 369 99 561 minecraft:green_terracotta
setblock 369 99 562 minecraft:oak_log
fill 369 99 563 369 102 563 minecraft:green_terracotta
setblock 369 99 567 minecraft:oak_log
fill 369 99 568 369 102 568 minecraft:green_terracotta
setblock 369 99 572 minecraft:oak_log
fill 369 99 573 369 102 573 minecraft:green_terracotta
setblock 369 99 577 minecraft:oak_log
fill 369 99 578 369 102 578 minecraft:green_terracotta
setblock 369 99 582 minecraft:oak_log
fill 369 99 583 369 102 583 minecraft:green_terracotta
setblock 369 99 587 minecraft:oak_log
fill 369 99 588 369 100 588 minecraft:green_terracotta
setblock 369 99 592 minecraft:oak_log
fill 369 99 593 369 101 593 minecraft:green_terracotta
setblock 369 99 597 minecraft:oak_log
fill 369 99 598 369 102 598 minecraft:green_terracotta
setblock 370 99 560 minecraft:green_terracotta
setblock 370 99 561 minecraft:oak_log
fill 370 99 562 370 102 562 minecraft:green_terracotta
setblock 370 99 566 minecraft:oak_log
fill 370 99 567 370 102 567 minecraft:green_terracotta
setblock 370 99 571 minecraft:oak_log
fill 370 99 572 370 102 572 minecraft:green_terracotta
setblock 370 99 576 minecraft:oak_log
fill 370 99 577 370 102 577 minecraft:green_terracotta
setblock 370 99 581 minecraft:oak_log
fill 370 99 582 370 102 582 minecraft:green_terracotta
setblock 370 99 586 minecraft:oak_log
fill 370 99 587 370 101 587 minecraft:green_terracotta
setblock 370 99 591 minecraft:oak_log
fill 370 99 592 370 102 592 minecraft:green_terracotta
setblock 370 99 596 minecraft:oak_log
fill 370 99 597 370 102 597 minecraft:green_terracotta
fill 371 99 558 371 100 560 minecraft:dirt
setblock 371 99 561 minecraft:brown_terracotta
fill 371 99 562 371 100 563 minecraft:dirt
fill 371 99 571 371 100 571 minecraft:dirt
setblock 371 99 572 minecraft:brown_terracotta
fill 371 99 573 371 100 574 minecraft:dirt
fill 371 99 576 371 100 576 minecraft:dirt
fill 371 99 578 371 100 578 minecraft:dirt
fill 371 99 581 371 100 581 minecraft:dirt
fill 371 99 589 371 100 589 minecraft:dirt
fill 371 99 591 371 100 591 minecraft:dirt
setblock 371 99 599 minecraft:brown_terracotta
setblock 329 100 557 minecraft:dirt
setblock 329 100 562 minecraft:dirt
setblock 329 100 569 minecraft:dirt
setblock 329 100 576 minecraft:dirt
setblock 329 100 583 minecraft:dirt
fill 329 100 590 329 100 591 minecraft:dirt
setblock 329 100 599 minecraft:dirt
setblock 330 100 560 minecraft:oak_log
fill 330 100 561 330 103 561 minecraft:green_terracotta
setblock 330 100 565 minecraft:oak_log
fill 330 100 566 330 103 566 minecraft:green_terracotta
setblock 330 100 570 minecraft:oak_log
fill 330 100 571 330 103 571 minecraft:green_terracotta
setblock 330 100 575 minecraft:oak_log
fill 330 100 576 330 103 576 minecraft:green_terracotta
setblock 330 100 580 minecraft:oak_log
fill 330 100 581 330 103 581 minecraft:green_terracotta
setblock 330 100 590 minecraft:oak_log
fill 330 100 591 330 101 591 minecraft:green_terracotta
setblock 330 100 595 minecraft:oak_log
fill 330 100 596 331 102 596 minecraft:green_terracotta
setblock 331 100 559 minecraft:oak_log
fill 331 100 560 331 103 560 minecraft:green_terracotta
setblock 331 100 564 minecraft:oak_log
fill 331 100 565 331 101 565 minecraft:green_terracotta
setblock 331 100 569 minecraft:oak_log
fill 331 100 570 331 102 570 minecraft:green_terracotta
setblock 331 100 574 minecraft:oak_log
fill 331 100 575 331 103 575 minecraft:green_terracotta
setblock 331 100 579 minecraft:oak_log
fill 331 100 580 331 101 580 minecraft:green_terracotta
setblock 331 100 594 minecraft:oak_log
fill 331 100 595 331 102 595 minecraft:green_terracotta
setblock 332 100 557 minecraft:dirt
setblock 332 100 558 minecraft:oak_log
fill 332 100 559 332 103 559 minecraft:green_terracotta
setblock 332 100 573 minecraft:oak_log
setblock 332 100 574 minecraft:green_terracotta
setblock 332 100 598 minecraft:oak_log
fill 333 100 558 333 103 558 minecraft:green_terracotta
setblock 333 100 597 minecraft:oak_log
fill 333 100 598 336 100 598 minecraft:green_terracotta
setblock 334 100 557 minecraft:dirt
fill 334 100 597 337 100 597 minecraft:green_terracotta
setblock 336 100 559 minecraft:oak_log
setblock 337 100 558 minecraft:oak_log
fill 337 100 559 340 100 559 minecraft:green_terracotta
setblock 337 100 598 minecraft:oak_log
setblock 338 100 557 minecraft:dirt
fill 338 100 558 338 103 558 minecraft:green_terracotta
setblock 338 100 597 minecraft:oak_log
fill 338 100 598 338 103 598 minecraft:green_terracotta
fill 339 100 597 339 103 597 minecraft:green_terracotta
setblock 340 100 557 minecraft:dirt
fill 340 100 596 340 103 596 minecraft:green_terracotta
setblock 341 100 559 minecraft:oak_log
setblock 342 100 558 minecraft:oak_log
fill 342 100 559 345 100 559 minecraft:green_terracotta
setblock 342 100 598 minecraft:oak_log
fill 343 100 558 343 103 558 minecraft:green_terracotta
fill 343 100 595 344 100 595 minecraft:green_terracotta
setblock 343 100 597 minecraft:oak_log
fill 343 100 598 343 103 598 minecraft:green_terracotta
setblock 344 100 596 minecraft:oak_log
fill 344 100 597 344 103 597 minecraft:green_terracotta
setblock 345 100 595 minecraft:oak_log
fill 345 100 596 345 103 596 minecraft:green_terracotta
setblock 346 100 559 minecraft:oak_log
fill 346 100 595 346 103 595 minecraft:green_terracotta
setblock 347 100 558 minecraft:oak_log
fill 347 100 559 347 103 559 minecraft:green_terracotta
setblock 347 100 594 minecraft:green_terracotta
setblock 347 100 598 minecraft:oak_log
fill 348 100 558 348 103 558 minecraft:green_terracotta
setblock 348 100 597 minecraft:oak_log
fill 348 100 598 348 103 598 minecraft:green_terracotta
setblock 349 100 596 minecraft:oak_log
fill 349 100 597 349 103 597 minecraft:green_terracotta
setblock 350 100 595 minecraft:oak_log
fill 350 100 596 350 103 596 minecraft:green_terracotta
setblock 351 100 559 minecraft:oak_log
fill 351 100 595 351 101 595 minecraft:green_terracotta
setblock 352 100 558 minecraft:oak_log
setblock 352 100 598 minecraft:oak_log
fill 353 100 558 353 103 558 minecraft:green_terracotta
setblock 353 100 597 minecraft:oak_log
fill 353 100 598 353 103 598 minecraft:green_terracotta
setblock 354 100 596 minecraft:oak_log
fill 354 100 597 354 103 597 minecraft:green_terracotta
setblock 355 100 596 minecraft:green_terracotta
setblock 357 100 598 minecraft:oak_log
setblock 357 100 599 minecraft:dirt
setblock 358 100 597 minecraft:oak_log
fill 358 100 598 361 100 598 minecraft:green_terracotta
fill 359 100 597 362 100 597 minecraft:green_terracotta
setblock 361 100 557 minecraft:dirt
setblock 362 100 558 minecraft:oak_log
setblock 362 100 598 minecraft:oak_log
setblock 363 100 557 minecraft:dirt
fill 363 100 558 366 100 558 minecraft:green_terracotta
setblock 363 100 597 minecraft:oak_log
fill 363 100 598 363 103 598 minecraft:green_terracotta
setblock 363 100 599 minecraft:dirt
fill 364 100 597 364 103 597 minecraft:green_terracotta
fill 365 100 596 365 101 596 minecraft:green_terracotta
setblock 365 100 599 minecraft:dirt
setblock 366 100 559 minecraft:oak_log
setblock 366 100 574 minecraft:oak_log
fill 366 100 575 366 101 577 minecraft:green_terracotta
setblock 367 100 558 minecraft:oak_log
fill 367 100 559 367 103 559 minecraft:green_terracotta
setblock 367 100 573 minecraft:oak_log
fill 367 100 574 367 103 574 minecraft:green_terracotta
setblock 367 100 577 minecraft:green_terracotta
setblock 367 100 578 minecraft:oak_log
fill 367 100 579 367 103 579 minecraft:green_terracotta
setblock 367 100 598 minecraft:oak_log
setblock 368 100 557 minecraft:dirt
fill 368 100 558 368 103 558 minecraft:green_terracotta
setblock 368 100 567 minecraft:oak_log
fill 368 100 568 368 101 568 minecraft:green_terracotta
setblock 368 100 572 minecraft:oak_log
fill 368 100 573 368 103 573 minecraft:green_terracotta
setblock 368 100 577 minecraft:oak_log
fill 368 100 578 368 103 578 minecraft:green_terracotta
fill 368 100 580 368 100 581 minecraft:green_terracotta
setblock 368 100 582 minecraft:oak_log
fill 368 100 583 368 101 583 minecraft:green_terracotta
setblock 368 100 593 minecraft:green_terracotta
setblock 368 100 597 minecraft:oak_log
fill 368 100 598 368 103 598 minecraft:green_terracotta
setblock 369 100 560 minecraft:green_terracotta
setblock 369 100 561 minecraft:oak_log
fill 369 100 562 369 103 562 minecraft:green_terracotta
setblock 369 100 566 minecraft:oak_log
fill 369 100 567 369 103 567 minecraft:green_terracotta
setblock 369 100 571 minecraft:oak_log
fill 369 100 572 369 103 572 minecraft:green_terracotta
setblock 369 100 576 minecraft:oak_log
fill 369 100 577 369 103 577 minecraft:green_terracotta
setblock 369 100 581 minecraft:oak_log
fill 369 100 582 369 103 582 minecraft:green_terracotta
setblock 369 100 586 minecraft:oak_log
setblock 369 100 591 minecraft:oak_log
fill 369 100 592 369 101 592 minecraft:green_terracotta
setblock 369 100 596 minecraft:oak_log
fill 369 100 597 369 103 597 minecraft:green_terracotta
setblock 370 100 560 minecraft:oak_log
fill 370 100 561 370 103 561 minecraft:green_terracotta
setblock 370 100 565 minecraft:oak_log
fill 370 100 566 370 103 566 minecraft:green_terracotta
setblock 370 100 570 minecraft:oak_log
fill 370 100 571 370 103 571 minecraft:green_terracotta
setblock 370 100 575 minecraft:oak_log
fill 370 100 576 370 103 576 minecraft:green_terracotta
setblock 370 100 580 minecraft:oak_log
fill 370 100 581 370 103 581 minecraft:green_terracotta
setblock 370 100 585 minecraft:oak_log
fill 370 100 586 370 102 586 minecraft:green_terracotta
setblock 370 100 590 minecraft:oak_log
fill 370 100 591 370 102 591 minecraft:green_terracotta
setblock 370 100 595 minecraft:oak_log
fill 370 100 596 370 103 596 minecraft:green_terracotta
setblock 371 100 561 minecraft:dirt
setblock 371 100 572 minecraft:dirt
setblock 371 100 599 minecraft:dirt
fill 329 101 557 329 101 566 minecraft:brown_terracotta
setblock 329 101 567 minecraft:dirt
fill 329 101 568 329 101 579 minecraft:brown_terracotta
setblock 329 101 580 minecraft:dirt
fill 329 101 581 329 101 583 minecraft:brown_terracotta
setblock 329 101 584 minecraft:dirt
fill 329 101 585 329 102 586 minecraft:brown_terracotta
setblock 329 101 587 minecraft:dirt
fill 329 101 588 329 101 599 minecraft:brown_terracotta
fill 330 101 557 351 101 557 minecraft:brown_terracotta
setblock 330 101 559 minecraft:oak_log
fill 330 101 560 330 104 560 minecraft:green_terracotta
setblock 330 101 564 minecraft:oak_log
fill 330 101 565 330 104 565 minecraft:green_terracotta
setblock 330 101 569 minecraft:oak_log
fill 330 101 570 330 104 570 minecraft:green_terracotta
setblock 330 101 574 minecraft:oak_log
fill 330 101 575 330 104 575 minecraft:green_terracotta
setblock 330 101 579 minecraft:oak_log
fill 330 101 580 330 104 580 minecraft:green_terracotta
setblock 330 101 594 minecraft:oak_log
fill 330 101 595 330 104 595 minecraft:green_terracotta
setblock 331 101 558 minecraft:oak_log
fill 331 101 559 331 104 559 minecraft:green_terracotta
setblock 331 101 563 minecraft:oak_log
fill 331 101 564 331 102 564 minecraft:green_terracotta
setblock 331 101 568 minecraft:oak_log
fill 331 101 569 331 102 569 minecraft:green_terracotta
setblock 331 101 573 minecraft:oak_log
fill 331 101 574 331 103 574 minecraft:green_terracotta
setblock 331 101 578 minecraft:oak_log
fill 331 101 579 331 102 579 minecraft:green_terracotta
setblock 331 101 594 minecraft:green_terracotta
setblock 331 101 598 minecraft:oak_log
fill 331 101 599 354 101 599 minecraft:brown_terracotta
fill 332 101 558 332 104 558 minecraft:green_terracotta
setblock 332 101 597 minecraft:oak_log
fill 332 101 598 335 101 598 minecraft:green_terracotta
fill 333 101 597 336 101 597 minecraft:green_terracotta
setblock 334 101 559 minecraft:green_terracotta
setblock 335 101 559 minecraft:oak_log
setblock 336 101 558 minecraft:oak_log
fill 336 101 559 339 101 559 minecraft:green_terracotta
setblock 336 101 598 minecraft:oak_log
fill 337 101 558 337 104 558 minecraft:green_terracotta
setblock 337 101 597 minecraft:oak_log
fill 337 101 598 337 104 598 minecraft:green_terracotta
fill 338 101 597 338 104 597 minecraft:green_terracotta
setblock 340 101 559 minecraft:oak_log
setblock 341 101 558 minecraft:oak_log
fill 341 101 559 344 101 559 minecraft:green_terracotta
setblock 341 101 598 minecraft:oak_log
fill 342 101 558 342 104 558 minecraft:green_terracotta
setblock 342 101 597 minecraft:oak_log
fill 342 101 598 342 104 598 minecraft:green_terracotta
setblock 343 101 595 minecraft:green_terracotta
setblock 343 101 596 minecraft:oak_log
fill 343 101 597 343 104 597 minecraft:green_terracotta
setblock 344 101 595 minecraft:oak_log
fill 344 101 596 344 104 596 minecraft:green_terracotta
setblock 345 101 559 minecraft:oak_log
fill 345 101 595 345 103 595 minecraft:green_terracotta
setblock 346 101 558 minecraft:oak_log
fill 346 101 559 346 104 559 minecraft:green_terracotta
setblock 346 101 598 minecraft:oak_log
fill 347 101 558 347 104 558 minecraft:green_terracotta
setblock 347 101 597 minecraft:oak_log
fill 347 101 598 347 104 598 minecraft:green_terracotta
setblock 348 101 596 minecraft:oak_log
fill 348 101 597 348 104 597 minecraft:green_terracotta
setblock 349 101 595 minecraft:oak_log
fill 349 101 596 349 104 596 minecraft:green_terracotta
setblock 350 101 559 minecraft:oak_log
fill 350 101 595 350 102 595 minecraft:green_terracotta
setblock 351 101 558 minecraft:oak_log
setblock 351 101 559 minecraft:green_terracotta
setblock 351 101 598 minecraft:oak_log
fill 352 101 557 352 102 557 minecraft:dirt
fill 352 101 558 352 104 558 minecraft:green_terracotta
setblock 352 101 597 minecraft:oak_log
fill 352 101 598 352 104 598 minecraft:green_terracotta
fill 353 101 557 364 101 557 minecraft:brown_terracotta
setblock 353 101 596 minecraft:oak_log
fill 353 101 597 353 103 597 minecraft:green_terracotta
setblock 354 101 596 minecraft:green_terracotta
setblock 355 101 599 minecraft:dirt
setblock 356 101 598 minecraft:oak_log
fill 356 101 599 365 101 599 minecraft:brown_terracotta
setblock 357 101 597 minecraft:oak_log
fill 357 101 598 360 101 598 minecraft:green_terracotta
fill 358 101 597 361 101 597 minecraft:green_terracotta
setblock 361 101 558 minecraft:oak_log
setblock 361 101 598 minecraft:oak_log
fill 362 101 558 365 101 558 minecraft:green_terracotta
setblock 362 101 597 minecraft:oak_log
fill 362 101 598 362 104 598 minecraft:green_terracotta
fill 363 101 597 363 104 597 minecraft:green_terracotta
fill 365 101 557 365 103 557 minecraft:dirt
setblock 365 101 559 minecraft:oak_log
fill 366 101 557 371 102 557 minecraft:brown_terracotta
setblock 366 101 558 minecraft:oak_log
fill 366 101 559 366 104 559 minecraft:green_terracotta
setblock 366 101 574 minecraft:green_terracotta
setblock 366 101 578 minecraft:oak_log
setblock 366 101 598 minecraft:oak_log
setblock 366 101 599 minecraft:dirt
fill 367 101 558 367 104 558 minecraft:green_terracotta
setblock 367 101 572 minecraft:oak_log
fill 367 101 573 367 103 573 minecraft:green_terracotta
setblock 367 101 577 minecraft:oak_log
fill 367 101 578 367 104 578 minecraft:green_terracotta
setblock 367 101 581 minecraft:green_terracotta
setblock 367 101 596 minecraft:green_terracotta
setblock 367 101 597 minecraft:oak_log
fill 367 101 598 367 104 598 minecraft:green_terracotta
fill 367 101 599 371 165 599 minecraft:brown_terracotta
setblock 368 101 571 minecraft:oak_log
fill 368 101 572 368 104 572 minecraft:green_terracotta
setblock 368 101 576 minecraft:oak_log
fill 368 101 577 368 104 577 minecraft:green_terracotta
setblock 368 101 580 minecraft:green_terracotta
setblock 368 101 581 minecraft:oak_log
fill 368 101 582 368 103 582 minecraft:green_terracotta
setblock 368 101 596 minecraft:oak_log
fill 368 101 597 368 103 597 minecraft:green_terracotta
setblock 369 101 560 minecraft:oak_log
fill 369 101 561 369 104 561 minecraft:green_terracotta
setblock 369 101 565 minecraft:oak_log
fill 369 101 566 369 103 566 minecraft:green_terracotta
setblock 369 101 570 minecraft:oak_log
fill 369 101 571 369 104 571 minecraft:green_terracotta
setblock 369 101 575 minecraft:oak_log
fill 369 101 576 369 104 576 minecraft:green_terracotta
setblock 369 101 580 minecraft:oak_log
fill 369 101 581 369 104 581 minecraft:green_terracotta
setblock 369 101 585 minecraft:oak_log
setblock 369 101 595 minecraft:oak_log
fill 369 101 596 369 103 596 minecraft:green_terracotta
setblock 370 101 559 minecraft:oak_log
fill 370 101 560 370 104 560 minecraft:green_terracotta
setblock 370 101 564 minecraft:oak_log
fill 370 101 565 370 104 565 minecraft:green_terracotta
setblock 370 101 569 minecraft:oak_log
fill 370 101 570 370 104 570 minecraft:green_terracotta
setblock 370 101 574 minecraft:oak_log
fill 370 101 575 370 104 575 minecraft:green_terracotta
setblock 370 101 579 minecraft:oak_log
fill 370 101 580 370 104 580 minecraft:green_terracotta
setblock 370 101 584 minecraft:oak_log
fill 370 101 585 370 103 585 minecraft:green_terracotta
setblock 370 101 589 minecraft:oak_log
setblock 370 101 590 minecraft:green_terracotta
setblock 370 101 594 minecraft:oak_log
fill 370 101 595 370 103 595 minecraft:green_terracotta
fill 371 101 558 371 101 578 minecraft:brown_terracotta
setblock 371 101 579 minecraft:dirt
fill 371 101 580 371 101 593 minecraft:brown_terracotta
setblock 371 101 594 minecraft:dirt
fill 371 101 595 371 101 598 minecraft:brown_terracotta
fill 329 102 557 329 102 564 minecraft:brown_terracotta
setblock 329 102 565 minecraft:dirt
fill 329 102 566 329 169 568 minecraft:brown_terracotta
setblock 329 102 569 minecraft:dirt
fill 329 102 570 329 102 572 minecraft:brown_terracotta
setblock 329 102 573 minecraft:dirt
fill 329 102 574 329 165 581 minecraft:brown_terracotta
setblock 329 102 582 minecraft:dirt
fill 329 102 583 329 166 584 minecraft:brown_terracotta
fill 329 102 587 329 102 595 minecraft:brown_terracotta
setblock 329 102 596 minecraft:dirt
fill 329 102 597 329 165 599 minecraft:brown_terracotta
fill 330 102 557 336 165 557 minecraft:brown_terracotta
setblock 330 102 558 minecraft:oak_log
fill 330 102 559 330 105 559 minecraft:green_terracotta
setblock 330 102 563 minecraft:oak_log
fill 330 102 564 330 105 564 minecraft:green_terracotta
setblock 330 102 568 minecraft:oak_log
fill 330 102 569 330 104 569 minecraft:green_terracotta
setblock 330 102 573 minecraft:oak_log
fill 330 102 574 330 105 574 minecraft:green_terracotta
setblock 330 102 578 minecraft:oak_log
fill 330 102 579 330 105 579 minecraft:green_terracotta
setblock 330 102 583 minecraft:oak_log
setblock 330 102 588 minecraft:oak_leaves[persistent=true]
setblock 330 102 593 minecraft:oak_log
fill 330 102 594 330 103 594 minecraft:green_terracotta
setblock 330 102 598 minecraft:oak_log
fill 330 102 599 338 102 599 minecraft:brown_terracotta
fill 331 102 558 331 105 558 minecraft:green_terracotta
setblock 331 102 562 minecraft:oak_log
fill 331 102 563 331 103 563 minecraft:green_terracotta
fill 331 102 565 331 112 566 minecraft:oak_log
setblock 331 102 572 minecraft:oak_log
fill 331 102 573 331 103 573 minecraft:green_terracotta
setblock 331 102 577 minecraft:oak_log
fill 331 102 578 331 103 578 minecraft:green_terracotta
setblock 331 102 597 minecraft:oak_log
fill 331 102 598 334 102 598 minecraft:green_terracotta
fill 332 102 597 335 102 597 minecraft:green_terracotta
setblock 334 102 559 minecraft:oak_log
setblock 335 102 558 minecraft:oak_log
fill 335 102 559 338 102 559 minecraft:green_terracotta
setblock 335 102 598 minecraft:oak_log
fill 336 102 558 336 105 558 minecraft:green_terracotta
setblock 336 102 597 minecraft:oak_log
fill 336 102 598 336 105 598 minecraft:green_terracotta
setblock 337 102 557 minecraft:dirt
fill 337 102 597 337 104 597 minecraft:green_terracotta
fill 338 102 557 338 169 557 minecraft:brown_terracotta
setblock 339 102 557 minecraft:dirt
setblock 339 102 559 minecraft:oak_log
setblock 339 102 599 minecraft:dirt
fill 340 102 557 351 102 557 minecraft:brown_terracotta
setblock 340 102 558 minecraft:oak_log
fill 340 102 559 343 102 559 minecraft:green_terracotta
setblock 340 102 598 minecraft:oak_log
fill 340 102 599 350 165 599 minecraft:brown_terracotta
fill 341 102 558 341 105 558 minecraft:green_terracotta
setblock 341 102 597 minecraft:oak_log
fill 341 102 598 341 105 598 minecraft:green_terracotta
setblock 342 102 596 minecraft:oak_log
fill 342 102 597 342 105 597 minecraft:green_terracotta
setblock 343 102 595 minecraft:oak_log
fill 343 102 596 343 105 596 minecraft:green_terracotta
setblock 344 102 559 minecraft:oak_log
fill 344 102 595 344 103 595 minecraft:green_terracotta
setblock 345 102 558 minecraft:oak_log
fill 345 102 559 345 102 560 minecraft:green_terracotta
setblock 345 102 598 minecraft:oak_log
fill 346 102 558 346 105 558 minecraft:green_terracotta
setblock 346 102 597 minecraft:oak_log
fill 346 102 598 346 105 598 minecraft:green_terracotta
setblock 347 102 596 minecraft:oak_log
fill 347 102 597 347 105 597 minecraft:green_terracotta
setblock 348 102 595 minecraft:oak_log
fill 348 102 596 348 105 596 minecraft:green_terracotta
setblock 349 102 559 minecraft:oak_log
setblock 349 102 595 minecraft:green_terracotta
setblock 350 102 558 minecraft:oak_log
setblock 350 102 559 minecraft:green_terracotta
setblock 350 102 598 minecraft:oak_log
fill 351 102 558 351 105 558 minecraft:green_terracotta
setblock 351 102 597 minecraft:oak_log
fill 351 102 598 351 105 598 minecraft:green_terracotta
setblock 351 102 599 minecraft:dirt
setblock 352 102 596 minecraft:oak_log
fill 352 102 597 352 104 597 minecraft:green_terracotta
fill 352 102 599 353 102 599 minecraft:brown_terracotta
fill 353 102 557 359 102 557 minecraft:brown_terracotta
fill 354 102 599 354 103 599 minecraft:dirt
setblock 355 102 598 minecraft:oak_log
fill 355 102 599 356 167 599 minecraft:brown_terracotta
fill 356 102 598 359 102 598 minecraft:green_terracotta
setblock 357 102 599 minecraft:dirt
fill 358 102 599 366 102 599 minecraft:brown_terracotta
setblock 360 102 557 minecraft:dirt
setblock 360 102 598 minecraft:oak_log
fill 361 102 557 364 102 557 minecraft:brown_terracotta
fill 361 102 558 364 102 558 minecraft:green_terracotta
setblock 361 102 597 minecraft:oak_log
fill 361 102 598 361 105 598 minecraft:green_terracotta
fill 362 102 597 362 103 597 minecraft:green_terracotta
setblock 364 102 559 minecraft:oak_log
setblock 365 102 558 minecraft:oak_log
fill 365 102 559 365 105 559 minecraft:green_terracotta
setblock 365 102 598 minecraft:oak_log
fill 366 102 558 366 105 558 minecraft:green_terracotta
fill 366 102 575 366 102 576 minecraft:green_terracotta
setblock 366 102 577 minecraft:oak_log
setblock 366 102 578 minecraft:green_terracotta
setblock 366 102 597 minecraft:oak_log
fill 366 102 598 366 105 598 minecraft:green_terracotta
setblock 367 102 572 minecraft:green_terracotta
setblock 367 102 576 minecraft:oak_log
fill 367 102 577 367 105 577 minecraft:green_terracotta
fill 367 102 597 367 104 597 minecraft:green_terracotta
setblock 368 102 570 minecraft:oak_log
fill 368 102 571 368 103 571 minecraft:green_terracotta
setblock 368 102 575 minecraft:oak_log
fill 368 102 576 368 105 576 minecraft:green_terracotta
setblock 368 102 580 minecraft:oak_log
fill 368 102 581 368 105 581 minecraft:green_terracotta
setblock 369 102 559 minecraft:oak_log
fill 369 102 560 369 105 560 minecraft:green_terracotta
setblock 369 102 564 minecraft:oak_log
fill 369 102 565 369 103 565 minecraft:green_terracotta
setblock 369 102 569 minecraft:oak_log
fill 369 102 570 369 104 570 minecraft:green_terracotta
setblock 369 102 574 minecraft:oak_log
fill 369 102 575 369 105 575 minecraft:green_terracotta
setblock 369 102 579 minecraft:oak_log
fill 369 102 580 369 105 580 minecraft:green_terracotta
setblock 369 102 584 minecraft:oak_log
setblock 369 102 594 minecraft:oak_log
setblock 369 102 595 minecraft:green_terracotta
setblock 370 102 558 minecraft:oak_log
fill 370 102 559 370 105 559 minecraft:green_terracotta
setblock 370 102 563 minecraft:oak_log
fill 370 102 564 370 105 564 minecraft:green_terracotta
setblock 370 102 568 minecraft:oak_log
fill 370 102 569 370 105 569 minecraft:green_terracotta
setblock 370 102 573 minecraft:oak_log
fill 370 102 574 370 105 574 minecraft:green_terracotta
setblock 370 102 578 minecraft:oak_log
fill 370 102 579 370 105 579 minecraft:green_terracotta
setblock 370 102 583 minecraft:oak_log
fill 370 102 584 370 104 584 minecraft:green_terracotta
setblock 370 102 593 minecraft:oak_log
fill 370 102 594 370 103 594 minecraft:green_terracotta
setblock 370 102 598 minecraft:oak_log
fill 371 102 558 371 165 562 minecraft:brown_terracotta
setblock 371 102 563 minecraft:dirt
fill 371 102 564 371 102 575 minecraft:brown_terracotta
setblock 371 102 576 minecraft:dirt
fill 371 102 577 371 165 582 minecraft:brown_terracotta
setblock 371 102 583 minecraft:dirt
fill 371 102 584 371 102 595 minecraft:brown_terracotta
setblock 371 102 596 minecraft:dirt
fill 371 102 597 371 102 598 minecraft:brown_terracotta
fill 329 103 557 329 169 558 minecraft:brown_terracotta
fill 329 103 559 329 103 560 minecraft:dirt
fill 329 103 561 329 169 562 minecraft:brown_terracotta
setblock 329 103 563 minecraft:dirt
fill 329 103 564 329 169 565 minecraft:brown_terracotta
fill 329 103 569 329 169 569 minecraft:brown_terracotta
setblock 329 103 570 minecraft:dirt
fill 329 103 571 329 169 571 minecraft:brown_terracotta
setblock 329 103 572 minecraft:dirt
fill 329 103 573 329 169 573 minecraft:brown_terracotta
fill 329 103 582 329 166 582 minecraft:brown_terracotta
setblock 329 103 585 minecraft:dirt
fill 329 103 586 329 165 586 minecraft:brown_terracotta
setblock 329 103 587 minecraft:dirt
fill 329 103 588 329 165 593 minecraft:brown_terracotta
setblock 329 103 594 minecraft:dirt
fill 329 103 595 329 165 596 minecraft:brown_terracotta
fill 330 103 558 330 106 558 minecraft:green_terracotta
setblock 330 103 562 minecraft:oak_log
fill 330 103 563 330 106 563 minecraft:green_terracotta
setblock 330 103 567 minecraft:oak_log
fill 330 103 568 330 104 568 minecraft:green_terracotta
setblock 330 103 572 minecraft:oak_log
fill 330 103 573 330 105 573 minecraft:green_terracotta
setblock 330 103 577 minecraft:oak_log
fill 330 103 578 330 106 578 minecraft:green_terracotta
setblock 330 103 582 minecraft:oak_log
setblock 330 103 596 minecraft:green_terracotta
setblock 330 103 597 minecraft:oak_log
fill 330 103 598 333 103 598 minecraft:green_terracotta
fill 330 103 599 332 169 599 minecraft:brown_terracotta
setblock 331 103 561 minecraft:oak_log
fill 331 103 562 331 104 562 minecraft:green_terracotta
setblock 331 103 576 minecraft:oak_log
setblock 331 103 577 minecraft:green_terracotta
setblock 331 103 596 minecraft:oak_log
fill 331 103 597 333 103 597 minecraft:green_terracotta
setblock 333 103 559 minecraft:oak_log
setblock 333 103 599 minecraft:dirt
setblock 334 103 558 minecraft:oak_log
fill 334 103 559 337 103 559 minecraft:green_terracotta
setblock 334 103 598 minecraft:oak_log
fill 334 103 599 339 169 599 minecraft:brown_terracotta
fill 335 103 558 335 106 558 minecraft:green_terracotta
fill 335 103 598 335 106 598 minecraft:green_terracotta
setblock 336 103 597 minecraft:green_terracotta
fill 337 103 557 337 170 557 minecraft:brown_terracotta
setblock 338 103 559 minecraft:oak_log
fill 339 103 557 340 169 557 minecraft:brown_terracotta
setblock 339 103 558 minecraft:oak_log
fill 339 103 559 342 103 559 minecraft:green_terracotta
setblock 339 103 598 minecraft:oak_log
fill 340 103 558 340 106 558 minecraft:green_terracotta
setblock 340 103 597 minecraft:oak_log
fill 340 103 598 340 106 598 minecraft:green_terracotta
setblock 341 103 557 minecraft:dirt
setblock 341 103 596 minecraft:oak_log
fill 341 103 597 341 106 597 minecraft:green_terracotta
fill 342 103 557 357 165 557 minecraft:brown_terracotta
fill 342 103 596 342 106 596 minecraft:green_terracotta
setblock 343 103 559 minecraft:oak_log
setblock 344 103 558 minecraft:oak_log
fill 344 103 559 345 105 559 minecraft:green_terracotta
setblock 344 103 598 minecraft:oak_log
fill 345 103 558 345 106 558 minecraft:green_terracotta
setblock 345 103 597 minecraft:oak_log
fill 345 103 598 345 106 598 minecraft:green_terracotta
setblock 346 103 596 minecraft:oak_log
fill 346 103 597 346 106 597 minecraft:green_terracotta
setblock 347 103 595 minecraft:oak_log
fill 347 103 596 347 105 596 minecraft:green_terracotta
setblock 348 103 559 minecraft:oak_log
setblock 348 103 595 minecraft:green_terracotta
setblock 349 103 558 minecraft:oak_log
fill 349 103 559 349 104 559 minecraft:green_terracotta
setblock 349 103 598 minecraft:oak_log
fill 350 103 558 350 106 558 minecraft:green_terracotta
setblock 350 103 597 minecraft:oak_log
fill 350 103 598 350 106 598 minecraft:green_terracotta
fill 351 103 586 351 104 586 minecraft:glowstone
setblock 351 103 596 minecraft:oak_log
fill 351 103 597 351 104 597 minecraft:green_terracotta
fill 351 103 599 351 169 599 minecraft:brown_terracotta
setblock 352 103 599 minecraft:dirt
fill 353 103 599 353 169 599 minecraft:brown_terracotta
setblock 354 103 598 minecraft:oak_log
setblock 355 103 558 minecraft:oak_leaves[persistent=true]
fill 355 103 598 358 103 598 minecraft:green_terracotta
fill 357 103 599 357 169 599 minecraft:brown_terracotta
setblock 358 103 557 minecraft:dirt
setblock 358 103 599 minecraft:dirt
fill 359 103 557 362 165 557 minecraft:brown_terracotta
setblock 359 103 598 minecraft:oak_log
fill 359 103 599 363 165 599 minecraft:brown_terracotta
fill 360 103 558 363 103 558 minecraft:green_terracotta
fill 360 103 598 360 106 598 minecraft:green_terracotta
setblock 363 103 557 minecraft:dirt
setblock 363 103 559 minecraft:oak_log
fill 364 103 557 364 166 557 minecraft:brown_terracotta
setblock 364 103 558 minecraft:oak_log
fill 364 103 559 364 106 559 minecraft:green_terracotta
setblock 364 103 598 minecraft:oak_log
setblock 364 103 599 minecraft:dirt
fill 365 103 558 365 106 558 minecraft:green_terracotta
setblock 365 103 597 minecraft:oak_log
fill 365 103 598 365 106 598 minecraft:green_terracotta
fill 365 103 599 366 169 599 minecraft:brown_terracotta
fill 366 103 557 366 169 557 minecraft:brown_terracotta
fill 366 103 597 366 104 597 minecraft:green_terracotta
setblock 367 103 557 minecraft:dirt
setblock 367 103 575 minecraft:oak_log
fill 367 103 576 367 104 576 minecraft:green_terracotta
setblock 367 103 580 minecraft:oak_log
fill 368 103 557 371 165 557 minecraft:brown_terracotta
setblock 368 103 559 minecraft:oak_log
setblock 368 103 570 minecraft:green_terracotta
setblock 368 103 574 minecraft:oak_log
fill 368 103 575 368 105 575 minecraft:green_terracotta
setblock 368 103 579 minecraft:oak_log
fill 368 103 580 368 106 580 minecraft:green_terracotta
setblock 369 103 558 minecraft:oak_log
fill 369 103 559 369 106 559 minecraft:green_terracotta
setblock 369 103 563 minecraft:oak_log
setblock 369 103 564 minecraft:green_terracotta
setblock 369 103 568 minecraft:oak_log
fill 369 103 569 369 104 569 minecraft:green_terracotta
setblock 369 103 573 minecraft:oak_log
fill 369 103 574 369 106 574 minecraft:green_terracotta
setblock 369 103 578 minecraft:oak_log
fill 369 103 579 369 106 579 minecraft:green_terracotta
setblock 369 103 583 minecraft:oak_log
setblock 369 103 598 minecraft:oak_log
fill 370 103 558 370 106 558 minecraft:green_terracotta
setblock 370 103 562 minecraft:oak_log
fill 370 103 563 370 106 563 minecraft:green_terracotta
setblock 370 103 567 minecraft:oak_log
fill 370 103 568 370 105 568 minecraft:green_terracotta
setblock 370 103 572 minecraft:oak_log
fill 370 103 573 370 106 573 minecraft:green_terracotta
setblock 370 103 577 minecraft:oak_log
fill 370 103 578 370 106 578 minecraft:green_terracotta
setblock 370 103 582 minecraft:oak_log
fill 370 103 583 370 106 583 minecraft:green_terracotta
setblock 370 103 587 minecraft:oak_leaves[persistent=true]
setblock 370 103 597 minecraft:oak_log
fill 370 103 598 370 105 598 minecraft:green_terracotta
fill 371 103 563 371 166 566 minecraft:brown_terracotta
setblock 371 103 567 minecraft:dirt
fill 371 103 568 371 165 571 minecraft:brown_terracotta
setblock 371 103 572 minecraft:dirt
fill 371 103 573 371 166 576 minecraft:brown_terracotta
fill 371 103 583 371 165 585 minecraft:brown_terracotta
setblock 371 103 586 minecraft:dirt
fill 371 103 587 371 165 597 minecraft:brown_terracotta
setblock 371 103 598 minecraft:dirt
fill 329 104 559 329 165 560 minecraft:brown_terracotta
fill 329 104 563 329 169 563 minecraft:brown_terracotta
fill 329 104 570 329 169 570 minecraft:brown_terracotta
fill 329 104 572 329 169 572 minecraft:brown_terracotta
fill 329 104 585 329 169 585 minecraft:brown_terracotta
fill 329 104 587 329 170 587 minecraft:brown_terracotta
fill 329 104 594 329 169 594 minecraft:brown_terracotta
setblock 330 104 561 minecraft:oak_log
fill 330 104 562 330 107 562 minecraft:green_terracotta
setblock 330 104 566 minecraft:oak_log
setblock 330 104 567 minecraft:green_terracotta
setblock 330 104 571 minecraft:oak_log
setblock 330 104 572 minecraft:green_terracotta
setblock 330 104 576 minecraft:oak_log
fill 330 104 577 330 106 577 minecraft:green_terracotta
setblock 330 104 581 minecraft:oak_log
setblock 330 104 596 minecraft:oak_log
fill 330 104 597 330 106 598 minecraft:green_terracotta
setblock 331 104 560 minecraft:oak_log
fill 331 104 561 331 107 561 minecraft:green_terracotta
fill 331 104 598 332 104 598 minecraft:green_terracotta
setblock 332 104 559 minecraft:oak_log
setblock 333 104 558 minecraft:oak_log
fill 333 104 559 336 104 559 minecraft:green_terracotta
setblock 333 104 598 minecraft:oak_log
fill 333 104 599 333 166 599 minecraft:brown_terracotta
fill 334 104 558 334 107 558 minecraft:green_terracotta
fill 334 104 598 334 107 598 minecraft:green_terracotta
setblock 337 104 559 minecraft:oak_log
setblock 338 104 558 minecraft:oak_log
fill 338 104 559 341 104 559 minecraft:green_terracotta
setblock 338 104 598 minecraft:oak_log
fill 339 104 558 339 107 558 minecraft:green_terracotta
setblock 339 104 597 minecraft:oak_log
fill 339 104 598 339 107 598 minecraft:green_terracotta
fill 340 104 597 340 107 597 minecraft:green_terracotta
fill 341 104 557 341 169 557 minecraft:brown_terracotta
fill 341 104 596 341 105 596 minecraft:green_terracotta
setblock 342 104 559 minecraft:oak_log
setblock 343 104 558 minecraft:oak_log
fill 343 104 559 343 107 559 minecraft:green_terracotta
setblock 343 104 598 minecraft:oak_log
fill 344 104 558 344 107 558 minecraft:green_terracotta
setblock 344 104 597 minecraft:oak_log
fill 344 104 598 344 107 598 minecraft:green_terracotta
setblock 345 104 596 minecraft:oak_log
fill 345 104 597 345 107 597 minecraft:green_terracotta
fill 346 104 596 346 106 596 minecraft:green_terracotta
setblock 347 104 559 minecraft:oak_log
setblock 348 104 558 minecraft:oak_log
fill 348 104 559 348 105 559 minecraft:green_terracotta
setblock 348 104 598 minecraft:oak_log
fill 349 104 558 349 107 558 minecraft:green_terracotta
setblock 349 104 597 minecraft:oak_log
fill 349 104 598 349 107 598 minecraft:green_terracotta
fill 350 104 597 350 105 597 minecraft:green_terracotta
fill 352 104 599 352 167 599 minecraft:brown_terracotta
setblock 353 104 598 minecraft:oak_log
fill 354 104 598 357 104 598 minecraft:green_terracotta
fill 354 104 599 354 169 599 minecraft:brown_terracotta
fill 358 104 557 358 169 557 minecraft:brown_terracotta
setblock 358 104 598 minecraft:oak_log
fill 358 104 599 358 165 599 minecraft:brown_terracotta
fill 359 104 598 359 105 598 minecraft:green_terracotta
fill 360 104 558 362 104 558 minecraft:green_terracotta
fill 363 104 557 363 165 557 minecraft:brown_terracotta
setblock 363 104 558 minecraft:oak_log
fill 363 104 559 363 107 559 minecraft:green_terracotta
setblock 363 104 598 minecraft:oak_log
fill 364 104 558 364 107 558 minecraft:green_terracotta
setblock 364 104 597 minecraft:oak_log
fill 364 104 598 364 107 598 minecraft:green_terracotta
fill 364 104 599 364 169 599 minecraft:brown_terracotta
fill 365 104 557 365 169 557 minecraft:brown_terracotta
setblock 365 104 597 minecraft:green_terracotta
fill 367 104 557 367 169 557 minecraft:brown_terracotta
setblock 367 104 559 minecraft:oak_log
setblock 367 104 575 minecraft:green_terracotta
setblock 367 104 579 minecraft:oak_log
setblock 367 104 580 minecraft:green_terracotta
setblock 368 104 558 minecraft:oak_log
fill 368 104 559 368 107 559 minecraft:green_terracotta
setblock 368 104 573 minecraft:oak_log
fill 368 104 574 368 105 574 minecraft:green_terracotta
setblock 368 104 578 minecraft:oak_log
fill 368 104 579 368 106 579 minecraft:green_terracotta
setblock 368 104 598 minecraft:oak_log
fill 369 104 558 369 107 558 minecraft:green_terracotta
setblock 369 104 562 minecraft:oak_log
fill 369 104 563 369 105 563 minecraft:green_terracotta
setblock 369 104 572 minecraft:oak_log
fill 369 104 573 369 105 573 minecraft:green_terracotta
setblock 369 104 577 minecraft:oak_log
fill 369 104 578 369 107 578 minecraft:green_terracotta
setblock 369 104 582 minecraft:oak_log
setblock 369 104 583 minecraft:green_terracotta
fill 369 104 598 369 106 598 minecraft:green_terracotta
setblock 370 104 561 minecraft:oak_log
fill 370 104 562 370 107 562 minecraft:green_terracotta
setblock 370 104 566 minecraft:oak_log
fill 370 104 567 370 106 567 minecraft:green_terracotta
setblock 370 104 571 minecraft:oak_log
fill 370 104 572 370 106 572 minecraft:green_terracotta
setblock 370 104 576 minecraft:oak_log
fill 370 104 577 370 107 577 minecraft:green_terracotta
setblock 370 104 581 minecraft:oak_log
fill 370 104 582 370 107 582 minecraft:green_terracotta
setblock 370 104 596 minecraft:oak_log
setblock 370 104 597 minecraft:green_terracotta
fill 371 104 567 371 169 567 minecraft:brown_terracotta
fill 371 104 572 371 166 572 minecraft:brown_terracotta
fill 371 104 586 371 169 586 minecraft:brown_terracotta
fill 371 104 598 371 169 598 minecraft:brown_terracotta
setblock 330 105 560 minecraft:oak_log
fill 330 105 561 330 108 561 minecraft:green_terracotta
setblock 330 105 565 minecraft:oak_log
setblock 330 105 566 minecraft:green_terracotta
setblock 330 105 575 minecraft:oak_log
setblock 330 105 576 minecraft:green_terracotta
setblock 330 105 580 minecraft:oak_log
setblock 330 105 581 minecraft:green_terracotta
setblock 330 105 596 minecraft:green_terracotta
setblock 331 105 559 minecraft:oak_log
fill 331 105 560 331 108 560 minecraft:green_terracotta
setblock 331 105 598 minecraft:green_terracotta
setblock 332 105 558 minecraft:oak_log
fill 332 105 559 335 105 559 minecraft:green_terracotta
setblock 332 105 560 minecraft:light[level=14]
setblock 332 105 568 minecraft:light[level=14]
setblock 332 105 576 minecraft:light[level=14]
setblock 332 105 584 minecraft:light[level=14]
setblock 332 105 592 minecraft:light[level=14]
setblock 332 105 598 minecraft:oak_log
fill 333 105 558 333 108 558 minecraft:green_terracotta
fill 333 105 598 333 108 598 minecraft:green_terracotta
setblock 336 105 559 minecraft:oak_log
setblock 337 105 558 minecraft:oak_log
fill 337 105 559 340 105 559 minecraft:green_terracotta
setblock 337 105 598 minecraft:oak_log
fill 338 105 558 338 108 558 minecraft:green_terracotta
setblock 338 105 597 minecraft:oak_log
fill 338 105 598 338 108 598 minecraft:green_terracotta
fill 339 105 597 339 108 597 minecraft:green_terracotta
setblock 340 105 560 minecraft:light[level=14]
setblock 340 105 568 minecraft:light[level=14]
setblock 340 105 576 minecraft:light[level=14]
setblock 340 105 584 minecraft:light[level=14]
setblock 340 105 592 minecraft:light[level=14]
setblock 341 105 559 minecraft:oak_log
setblock 342 105 558 minecraft:oak_log
fill 342 105 559 342 108 559 minecraft:green_terracotta
setblock 342 105 598 minecraft:oak_log
fill 343 105 558 343 108 558 minecraft:green_terracotta
setblock 343 105 597 minecraft:oak_log
fill 343 105 598 343 108 598 minecraft:green_terracotta
setblock 344 105 596 minecraft:oak_log
fill 344 105 597 344 108 597 minecraft:green_terracotta
fill 345 105 596 345 106 596 minecraft:green_terracotta
setblock 346 105 559 minecraft:oak_log
setblock 347 105 558 minecraft:oak_log
fill 347 105 559 347 107 559 minecraft:green_terracotta
setblock 347 105 598 minecraft:oak_log
fill 348 105 558 348 108 558 minecraft:green_terracotta
setblock 348 105 560 minecraft:light[level=14]
setblock 348 105 568 minecraft:light[level=14]
setblock 348 105 576 minecraft:light[level=14]
setblock 348 105 584 minecraft:light[level=14]
setblock 348 105 592 minecraft:light[level=14]
setblock 348 105 597 minecraft:oak_log
fill 348 105 598 348 108 598 minecraft:green_terracotta
fill 349 105 597 349 106 597 minecraft:green_terracotta
setblock 352 105 598 minecraft:oak_log
setblock 353 105 598 minecraft:green_terracotta
setblock 356 105 560 minecraft:light[level=14]
setblock 356 105 568 minecraft:light[level=14]
setblock 356 105 576 minecraft:light[level=14]
setblock 356 105 584 minecraft:light[level=14]
setblock 356 105 592 minecraft:light[level=14]
setblock 357 105 598 minecraft:oak_leaves[persistent=true]
fill 360 105 558 361 105 558 minecraft:green_terracotta
setblock 362 105 558 minecraft:oak_log
setblock 362 105 598 minecraft:oak_log
fill 363 105 558 363 108 558 minecraft:green_terracotta
fill 363 105 598 363 108 598 minecraft:green_terracotta
setblock 364 105 560 minecraft:light[level=14]
setblock 364 105 568 minecraft:light[level=14]
setblock 364 105 576 minecraft:light[level=14]
setblock 364 105 584 minecraft:light[level=14]
setblock 364 105 592 minecraft:light[level=14]
setblock 366 105 559 minecraft:oak_log
setblock 367 105 558 minecraft:oak_log
fill 367 105 559 367 108 559 minecraft:green_terracotta
setblock 367 105 578 minecraft:oak_log
setblock 367 105 598 minecraft:oak_log
fill 368 105 558 368 108 558 minecraft:green_terracotta
setblock 368 105 577 minecraft:oak_log
fill 368 105 578 368 106 578 minecraft:green_terracotta
fill 368 105 598 368 106 598 minecraft:green_terracotta
setblock 369 105 561 minecraft:oak_log
fill 369 105 562 369 108 562 minecraft:green_terracotta
setblock 369 105 571 minecraft:oak_log
setblock 369 105 572 minecraft:green_terracotta
setblock 369 105 576 minecraft:oak_log
fill 369 105 577 369 107 577 minecraft:green_terracotta
setblock 369 105 581 minecraft:oak_log
fill 369 105 582 369 106 582 minecraft:green_terracotta
setblock 370 105 560 minecraft:oak_log
fill 370 105 561 370 108 561 minecraft:green_terracotta
setblock 370 105 565 minecraft:oak_log
fill 370 105 566 370 108 566 minecraft:green_terracotta
setblock 370 105 570 minecraft:oak_log
fill 370 105 571 370 106 571 minecraft:green_terracotta
setblock 370 105 575 minecraft:oak_log
fill 370 105 576 370 108 576 minecraft:green_terracotta
setblock 370 105 580 minecraft:oak_log
fill 370 105 581 370 108 581 minecraft:green_terracotta
setblock 370 105 594 minecraft:oak_leaves[persistent=true]
setblock 330 106 559 minecraft:oak_log
fill 330 106 560 330 109 560 minecraft:green_terracotta
setblock 330 106 564 minecraft:oak_log
fill 330 106 565 330 109 565 minecraft:green_terracotta
setblock 330 106 568 minecraft:oak_leaves[persistent=true]
setblock 330 106 579 minecraft:oak_log
setblock 330 106 587 minecraft:oak_leaves[persistent=true]
setblock 331 106 558 minecraft:oak_log
fill 331 106 559 334 106 559 minecraft:green_terracotta
setblock 331 106 598 minecraft:oak_log
fill 332 106 558 332 109 558 minecraft:green_terracotta
fill 332 106 598 332 107 598 minecraft:green_terracotta
setblock 335 106 559 minecraft:oak_log
setblock 336 106 558 minecraft:oak_log
fill 336 106 559 339 106 559 minecraft:green_terracotta
setblock 336 106 598 minecraft:oak_log
fill 337 106 558 337 109 558 minecraft:green_terracotta
fill 337 106 598 337 109 598 minecraft:green_terracotta
fill 338 106 597 338 109 597 minecraft:green_terracotta
setblock 340 106 559 minecraft:oak_log
setblock 341 106 558 minecraft:oak_log
fill 341 106 559 341 109 559 minecraft:green_terracotta
setblock 341 106 598 minecraft:oak_log
fill 342 106 558 342 109 558 minecraft:green_terracotta
setblock 342 106 597 minecraft:oak_log
fill 342 106 598 342 109 598 minecraft:green_terracotta
setblock 343 106 596 minecraft:oak_log
fill 343 106 597 343 109 597 minecraft:green_terracotta
setblock 344 106 559 minecraft:green_terracotta
fill 344 106 596 344 107 596 minecraft:green_terracotta
setblock 345 106 559 minecraft:oak_log
setblock 346 106 558 minecraft:oak_log
fill 346 106 559 346 109 559 minecraft:green_terracotta
setblock 346 106 598 minecraft:oak_log
fill 347 106 558 347 109 558 minecraft:green_terracotta
setblock 347 106 597 minecraft:oak_log
fill 347 106 598 347 109 598 minecraft:green_terracotta
fill 348 106 597 348 107 597 minecraft:green_terracotta
setblock 351 106 598 minecraft:oak_log
setblock 352 106 598 minecraft:green_terracotta
setblock 356 106 558 minecraft:oak_leaves[persistent=true]
setblock 360 106 558 minecraft:green_terracotta
setblock 361 106 558 minecraft:oak_log
setblock 361 106 598 minecraft:oak_log
fill 362 106 558 362 108 559 minecraft:green_terracotta
fill 362 106 598 362 109 598 minecraft:green_terracotta
setblock 365 106 559 minecraft:oak_log
setblock 366 106 558 minecraft:oak_log
fill 366 106 559 366 109 559 minecraft:green_terracotta
setblock 366 106 598 minecraft:oak_log
fill 367 106 558 367 109 558 minecraft:green_terracotta
fill 367 106 598 367 107 598 minecraft:green_terracotta
setblock 368 106 576 minecraft:oak_log
setblock 368 106 577 minecraft:green_terracotta
fill 368 106 581 368 114 581 minecraft:iron_block
setblock 369 106 560 minecraft:oak_log
fill 369 106 561 369 109 561 minecraft:green_terracotta
setblock 369 106 575 minecraft:oak_log
fill 369 106 576 369 107 576 minecraft:green_terracotta
setblock 369 106 580 minecraft:oak_log
fill 369 106 581 369 107 581 minecraft:green_terracotta
setblock 370 106 559 minecraft:oak_log
fill 370 106 560 370 109 560 minecraft:green_terracotta
setblock 370 106 564 minecraft:oak_log
fill 370 106 565 370 109 565 minecraft:green_terracotta
setblock 370 106 569 minecraft:oak_leaves[persistent=true]
setblock 370 106 570 minecraft:green_terracotta
setblock 370 106 574 minecraft:oak_log
fill 370 106 575 370 108 575 minecraft:green_terracotta
schedule function dropper:buildpart/139_3 1t
