setblock 40 167 324 minecraft:yellow_terracotta
fill 40 167 325 40 168 325 minecraft:honeycomb_block
setblock 40 167 344 minecraft:yellow_terracotta
fill 40 167 345 40 170 345 minecraft:honeycomb_block
setblock 40 167 349 minecraft:yellow_terracotta
fill 40 167 350 40 170 350 minecraft:honeycomb_block
setblock 40 167 354 minecraft:yellow_terracotta
fill 40 167 355 40 170 355 minecraft:honeycomb_block
setblock 40 167 359 minecraft:yellow_terracotta
fill 40 167 360 40 168 360 minecraft:honeycomb_block
setblock 41 167 323 minecraft:yellow_terracotta
fill 41 167 324 41 169 324 minecraft:honeycomb_block
setblock 41 167 328 minecraft:yellow_terracotta
fill 41 167 329 41 170 329 minecraft:honeycomb_block
setblock 41 167 338 minecraft:yellow_terracotta
setblock 41 167 339 minecraft:honeycomb_block
setblock 41 167 343 minecraft:yellow_terracotta
fill 41 167 344 41 170 344 minecraft:honeycomb_block
setblock 41 167 348 minecraft:yellow_terracotta
fill 41 167 349 41 170 349 minecraft:honeycomb_block
setblock 41 167 353 minecraft:yellow_terracotta
fill 41 167 354 41 170 354 minecraft:honeycomb_block
setblock 41 167 358 minecraft:yellow_terracotta
fill 41 167 359 41 169 359 minecraft:honeycomb_block
setblock 41 167 363 minecraft:yellow_terracotta
fill 0 168 325 0 308 325 minecraft:honeycomb_block
fill 0 168 330 0 231 330 minecraft:honeycomb_block
fill 0 168 334 0 308 334 minecraft:honeycomb_block
fill 0 168 342 0 170 342 minecraft:honeycomb_block
setblock 0 168 343 minecraft:yellow_terracotta
fill 0 168 347 0 193 347 minecraft:honeycomb_block
fill 1 168 323 3 168 323 minecraft:honeycomb_block
setblock 1 168 327 minecraft:yellow_terracotta
fill 1 168 328 1 171 328 minecraft:honeycomb_block
setblock 1 168 332 minecraft:yellow_terracotta
fill 1 168 333 1 171 333 minecraft:honeycomb_block
setblock 1 168 337 minecraft:yellow_terracotta
fill 1 168 338 1 169 338 minecraft:honeycomb_block
setblock 1 168 342 minecraft:yellow_terracotta
fill 1 168 343 1 168 346 minecraft:honeycomb_block
setblock 1 168 347 minecraft:yellow_terracotta
fill 1 168 348 1 171 348 minecraft:honeycomb_block
setblock 1 168 352 minecraft:yellow_terracotta
fill 1 168 353 1 171 353 minecraft:honeycomb_block
setblock 2 168 341 minecraft:yellow_terracotta
fill 2 168 342 2 169 342 minecraft:honeycomb_block
setblock 2 168 346 minecraft:yellow_terracotta
fill 2 168 347 2 171 347 minecraft:honeycomb_block
setblock 2 168 351 minecraft:yellow_terracotta
setblock 2 168 352 minecraft:honeycomb_block
setblock 3 168 345 minecraft:yellow_terracotta
setblock 3 168 346 minecraft:honeycomb_block
setblock 8 168 323 minecraft:honey_block
setblock 9 168 363 minecraft:honey_block
setblock 10 168 323 minecraft:yellow_terracotta
fill 11 168 323 11 171 323 minecraft:honeycomb_block
setblock 13 168 324 minecraft:honeycomb_block
setblock 13 168 325 minecraft:yellow_terracotta
setblock 14 168 324 minecraft:yellow_terracotta
fill 14 168 325 14 170 326 minecraft:honeycomb_block
setblock 15 168 323 minecraft:yellow_terracotta
fill 15 168 324 15 171 324 minecraft:honeycomb_block
fill 15 168 326 16 168 326 minecraft:honeycomb_block
setblock 15 168 363 minecraft:yellow_terracotta
fill 16 168 323 16 171 323 minecraft:honeycomb_block
fill 16 168 363 16 171 363 minecraft:honeycomb_block
setblock 17 168 326 minecraft:yellow_terracotta
setblock 18 168 325 minecraft:yellow_terracotta
fill 18 168 326 18 170 326 minecraft:honeycomb_block
setblock 19 168 324 minecraft:yellow_terracotta
fill 19 168 325 19 171 325 minecraft:honeycomb_block
setblock 20 168 323 minecraft:yellow_terracotta
fill 20 168 324 20 171 324 minecraft:honeycomb_block
setblock 20 168 363 minecraft:yellow_terracotta
fill 21 168 323 21 171 323 minecraft:honeycomb_block
fill 21 168 363 21 170 363 minecraft:honeycomb_block
setblock 23 168 325 minecraft:yellow_terracotta
setblock 24 168 324 minecraft:yellow_terracotta
setblock 24 168 325 minecraft:honeycomb_block
setblock 25 168 323 minecraft:yellow_terracotta
fill 25 168 324 28 168 324 minecraft:honeycomb_block
fill 25 168 332 25 169 332 minecraft:brown_terracotta
fill 25 168 335 25 169 335 minecraft:brown_terracotta
setblock 25 168 363 minecraft:yellow_terracotta
fill 26 168 323 26 171 323 minecraft:honeycomb_block
setblock 26 168 363 minecraft:honeycomb_block
fill 27 168 331 27 169 331 minecraft:brown_terracotta
fill 27 168 336 27 169 336 minecraft:brown_terracotta
setblock 29 168 324 minecraft:yellow_terracotta
fill 29 168 332 29 169 332 minecraft:brown_terracotta
fill 29 168 335 29 169 335 minecraft:brown_terracotta
setblock 30 168 323 minecraft:yellow_terracotta
fill 30 168 324 30 169 324 minecraft:honeycomb_block
setblock 30 168 363 minecraft:yellow_terracotta
fill 31 168 323 31 171 323 minecraft:honeycomb_block
fill 31 168 363 31 171 363 minecraft:honeycomb_block
setblock 32 168 362 minecraft:honeycomb_block
setblock 33 168 324 minecraft:honeycomb_block
setblock 34 168 324 minecraft:yellow_terracotta
setblock 34 168 325 minecraft:honeycomb_block
setblock 35 168 323 minecraft:yellow_terracotta
fill 35 168 324 35 171 324 minecraft:honeycomb_block
setblock 35 168 363 minecraft:yellow_terracotta
fill 36 168 323 36 171 323 minecraft:honeycomb_block
setblock 36 168 362 minecraft:yellow_terracotta
fill 36 168 363 36 171 363 minecraft:honeycomb_block
fill 37 168 362 37 170 362 minecraft:honeycomb_block
setblock 38 168 325 minecraft:yellow_terracotta
fill 38 168 348 38 168 349 minecraft:honeycomb_block
setblock 38 168 350 minecraft:yellow_terracotta
setblock 39 168 324 minecraft:yellow_terracotta
setblock 39 168 344 minecraft:yellow_terracotta
fill 39 168 345 39 169 345 minecraft:honeycomb_block
setblock 39 168 349 minecraft:yellow_terracotta
fill 39 168 350 39 171 350 minecraft:honeycomb_block
setblock 39 168 354 minecraft:yellow_terracotta
setblock 40 168 323 minecraft:yellow_terracotta
setblock 40 168 324 minecraft:honeycomb_block
setblock 40 168 328 minecraft:yellow_terracotta
setblock 40 168 343 minecraft:yellow_terracotta
fill 40 168 344 40 170 344 minecraft:honeycomb_block
setblock 40 168 348 minecraft:yellow_terracotta
fill 40 168 349 40 171 349 minecraft:honeycomb_block
setblock 40 168 353 minecraft:yellow_terracotta
fill 40 168 354 40 171 354 minecraft:honeycomb_block
setblock 40 168 358 minecraft:yellow_terracotta
setblock 40 168 359 minecraft:honeycomb_block
setblock 40 168 363 minecraft:yellow_terracotta
fill 41 168 323 41 169 323 minecraft:honeycomb_block
setblock 41 168 327 minecraft:yellow_terracotta
fill 41 168 328 41 170 328 minecraft:honeycomb_block
setblock 41 168 334 minecraft:honey_block
setblock 41 168 342 minecraft:yellow_terracotta
fill 41 168 343 41 171 343 minecraft:honeycomb_block
setblock 41 168 347 minecraft:yellow_terracotta
fill 41 168 348 41 171 348 minecraft:honeycomb_block
setblock 41 168 352 minecraft:yellow_terracotta
fill 41 168 353 41 171 353 minecraft:honeycomb_block
setblock 41 168 357 minecraft:yellow_terracotta
fill 41 168 358 41 169 358 minecraft:honeycomb_block
setblock 41 168 362 minecraft:yellow_terracotta
fill 41 168 363 41 169 363 minecraft:honeycomb_block
fill 0 169 343 1 171 343 minecraft:honeycomb_block
setblock 1 169 323 minecraft:honeycomb_block
setblock 1 169 326 minecraft:yellow_terracotta
fill 1 169 327 1 172 327 minecraft:honeycomb_block
setblock 1 169 331 minecraft:yellow_terracotta
fill 1 169 332 1 172 332 minecraft:honeycomb_block
setblock 1 169 341 minecraft:yellow_terracotta
fill 1 169 342 1 171 342 minecraft:honeycomb_block
fill 1 169 344 1 169 345 minecraft:honeycomb_block
setblock 1 169 346 minecraft:yellow_terracotta
fill 1 169 347 1 172 347 minecraft:honeycomb_block
setblock 1 169 351 minecraft:yellow_terracotta
fill 1 169 352 1 172 352 minecraft:honeycomb_block
setblock 1 169 358 minecraft:honey_block
setblock 2 169 323 minecraft:honey_block
setblock 2 169 345 minecraft:yellow_terracotta
fill 2 169 346 2 171 346 minecraft:honeycomb_block
setblock 2 169 350 minecraft:yellow_terracotta
fill 2 169 351 2 170 351 minecraft:honeycomb_block
setblock 9 169 323 minecraft:yellow_terracotta
fill 10 169 323 10 172 323 minecraft:honeycomb_block
setblock 12 169 325 minecraft:yellow_terracotta
setblock 13 169 324 minecraft:yellow_terracotta
fill 13 169 325 13 172 325 minecraft:honeycomb_block
setblock 14 169 323 minecraft:yellow_terracotta
fill 14 169 324 14 172 324 minecraft:honeycomb_block
setblock 14 169 363 minecraft:yellow_terracotta
fill 15 169 323 15 172 323 minecraft:honeycomb_block
setblock 15 169 326 minecraft:honeycomb_block
fill 15 169 363 15 172 363 minecraft:honeycomb_block
setblock 16 169 326 minecraft:yellow_terracotta
setblock 17 169 325 minecraft:yellow_terracotta
fill 17 169 326 17 171 326 minecraft:honeycomb_block
setblock 17 169 364 minecraft:yellow_terracotta
setblock 18 169 324 minecraft:yellow_terracotta
fill 18 169 325 18 172 325 minecraft:honeycomb_block
setblock 19 169 323 minecraft:yellow_terracotta
fill 19 169 324 19 172 324 minecraft:honeycomb_block
setblock 19 169 363 minecraft:yellow_terracotta
fill 20 169 323 20 172 323 minecraft:honeycomb_block
fill 20 169 363 20 170 363 minecraft:honeycomb_block
setblock 22 169 325 minecraft:yellow_terracotta
setblock 23 169 324 minecraft:yellow_terracotta
setblock 24 169 323 minecraft:yellow_terracotta
fill 24 169 324 25 169 324 minecraft:honeycomb_block
fill 24 169 333 24 169 334 minecraft:brown_terracotta
fill 25 169 323 25 171 323 minecraft:honeycomb_block
setblock 26 169 331 minecraft:brown_terracotta
setblock 26 169 336 minecraft:brown_terracotta
setblock 28 169 331 minecraft:brown_terracotta
setblock 28 169 336 minecraft:brown_terracotta
setblock 29 169 323 minecraft:yellow_terracotta
setblock 29 169 363 minecraft:yellow_terracotta
fill 30 169 323 30 172 323 minecraft:honeycomb_block
fill 30 169 363 30 172 363 minecraft:honeycomb_block
setblock 33 169 324 minecraft:yellow_terracotta
setblock 34 169 323 minecraft:yellow_terracotta
fill 34 169 324 34 172 324 minecraft:honeycomb_block
setblock 34 169 363 minecraft:yellow_terracotta
setblock 34 169 364 minecraft:yellow_concrete
fill 35 169 323 35 172 323 minecraft:honeycomb_block
setblock 35 169 362 minecraft:yellow_terracotta
fill 35 169 363 35 172 363 minecraft:honeycomb_block
fill 36 169 340 36 170 340 minecraft:black_concrete
fill 36 169 362 36 170 362 minecraft:honeycomb_block
fill 37 169 340 37 170 340 minecraft:yellow_concrete
setblock 38 169 324 minecraft:yellow_terracotta
setblock 38 169 348 minecraft:honeycomb_block
setblock 38 169 349 minecraft:yellow_terracotta
setblock 38 169 350 minecraft:honeycomb_block
setblock 39 169 323 minecraft:yellow_terracotta
setblock 39 169 324 minecraft:honeycomb_block
fill 39 169 337 39 176 337 minecraft:brown_terracotta
setblock 39 169 348 minecraft:yellow_terracotta
fill 39 169 349 39 172 349 minecraft:honeycomb_block
setblock 39 169 353 minecraft:yellow_terracotta
setblock 39 169 354 minecraft:honeycomb_block
setblock 39 169 363 minecraft:yellow_terracotta
fill 40 169 323 40 170 323 minecraft:honeycomb_block
setblock 40 169 343 minecraft:honeycomb_block
setblock 40 169 347 minecraft:yellow_terracotta
fill 40 169 348 40 172 348 minecraft:honeycomb_block
setblock 40 169 352 minecraft:yellow_terracotta
fill 40 169 353 40 172 353 minecraft:honeycomb_block
fill 40 169 363 40 170 363 minecraft:honeycomb_block
setblock 41 169 326 minecraft:yellow_terracotta
fill 41 169 327 41 170 327 minecraft:honeycomb_block
setblock 41 169 341 minecraft:yellow_terracotta
fill 41 169 342 41 170 342 minecraft:honeycomb_block
setblock 41 169 346 minecraft:yellow_terracotta
fill 41 169 347 41 172 347 minecraft:honeycomb_block
setblock 41 169 351 minecraft:yellow_terracotta
fill 41 169 352 41 172 352 minecraft:honeycomb_block
setblock 41 169 356 minecraft:yellow_terracotta
fill 41 169 357 41 171 357 minecraft:honeycomb_block
setblock 41 169 361 minecraft:yellow_terracotta
setblock 41 169 362 minecraft:honeycomb_block
setblock 42 169 326 minecraft:orange_terracotta
setblock 42 169 342 minecraft:yellow_concrete
setblock 0 170 354 minecraft:orange_terracotta
setblock 1 170 325 minecraft:yellow_terracotta
fill 1 170 326 1 171 326 minecraft:honeycomb_block
setblock 1 170 330 minecraft:yellow_terracotta
fill 1 170 331 1 173 331 minecraft:honeycomb_block
setblock 1 170 339 minecraft:honey_block
setblock 1 170 340 minecraft:yellow_terracotta
fill 1 170 341 1 171 341 minecraft:honeycomb_block
setblock 1 170 344 minecraft:honeycomb_block
setblock 1 170 345 minecraft:yellow_terracotta
fill 1 170 346 1 173 346 minecraft:honeycomb_block
setblock 1 170 350 minecraft:yellow_terracotta
fill 1 170 351 1 173 351 minecraft:honeycomb_block
setblock 2 170 344 minecraft:yellow_terracotta
setblock 2 170 345 minecraft:honeycomb_block
setblock 2 170 349 minecraft:yellow_terracotta
fill 2 170 350 2 171 350 minecraft:honeycomb_block
setblock 2 170 363 minecraft:honey_block
setblock 12 170 324 minecraft:yellow_terracotta
fill 12 170 325 12 173 325 minecraft:honeycomb_block
setblock 13 170 323 minecraft:yellow_terracotta
fill 13 170 324 13 173 324 minecraft:honeycomb_block
fill 14 170 323 14 173 323 minecraft:honeycomb_block
setblock 14 170 363 minecraft:honeycomb_block
setblock 15 170 326 minecraft:yellow_terracotta
setblock 16 170 325 minecraft:yellow_terracotta
fill 16 170 326 16 172 326 minecraft:honeycomb_block
setblock 17 170 324 minecraft:yellow_terracotta
fill 17 170 325 17 173 325 minecraft:honeycomb_block
fill 17 170 364 17 308 364 minecraft:honeycomb_block
setblock 18 170 323 minecraft:yellow_terracotta
fill 18 170 324 18 173 324 minecraft:honeycomb_block
setblock 18 170 363 minecraft:yellow_terracotta
fill 19 170 323 19 173 323 minecraft:honeycomb_block
fill 19 170 363 19 171 363 minecraft:honeycomb_block
setblock 21 170 325 minecraft:yellow_terracotta
setblock 22 170 324 minecraft:yellow_terracotta
setblock 23 170 323 minecraft:yellow_terracotta
setblock 23 170 324 minecraft:honeycomb_block
fill 24 170 323 24 171 323 minecraft:honeycomb_block
fill 27 170 333 27 172 334 minecraft:yellow_terracotta
setblock 28 170 323 minecraft:yellow_terracotta
fill 29 170 323 29 173 323 minecraft:honeycomb_block
setblock 29 170 363 minecraft:honeycomb_block
setblock 32 170 324 minecraft:yellow_terracotta
setblock 33 170 323 minecraft:yellow_terracotta
fill 33 170 324 33 171 324 minecraft:honeycomb_block
setblock 33 170 363 minecraft:yellow_terracotta
fill 34 170 323 34 173 323 minecraft:honeycomb_block
setblock 34 170 362 minecraft:yellow_terracotta
fill 34 170 363 34 173 364 minecraft:honeycomb_block
fill 35 170 362 35 171 362 minecraft:honeycomb_block
setblock 37 170 324 minecraft:yellow_terracotta
setblock 38 170 323 minecraft:yellow_terracotta
setblock 38 170 324 minecraft:honeycomb_block
setblock 38 170 363 minecraft:yellow_terracotta
fill 39 170 323 39 171 323 minecraft:honeycomb_block
setblock 39 170 347 minecraft:yellow_terracotta
fill 39 170 348 39 173 348 minecraft:honeycomb_block
setblock 39 170 352 minecraft:yellow_terracotta
fill 39 170 353 39 173 353 minecraft:honeycomb_block
fill 39 170 363 39 171 363 minecraft:honeycomb_block
setblock 40 170 346 minecraft:yellow_terracotta
fill 40 170 347 40 173 347 minecraft:honeycomb_block
setblock 40 170 351 minecraft:yellow_terracotta
fill 40 170 352 40 173 352 minecraft:honeycomb_block
setblock 41 170 325 minecraft:yellow_terracotta
fill 41 170 326 42 170 326 minecraft:honeycomb_block
setblock 41 170 345 minecraft:yellow_terracotta
fill 41 170 346 41 173 346 minecraft:honeycomb_block
setblock 41 170 350 minecraft:yellow_terracotta
fill 41 170 351 41 173 351 minecraft:honeycomb_block
setblock 41 170 355 minecraft:yellow_terracotta
fill 41 170 356 41 173 356 minecraft:honeycomb_block
fill 42 170 342 42 217 342 minecraft:honeycomb_block
setblock 0 171 333 minecraft:orange_terracotta
setblock 0 171 342 minecraft:yellow_concrete
fill 0 171 354 0 180 354 minecraft:honeycomb_block
setblock 1 171 329 minecraft:yellow_terracotta
fill 1 171 330 1 174 330 minecraft:honeycomb_block
setblock 1 171 344 minecraft:yellow_terracotta
fill 1 171 345 1 174 345 minecraft:honeycomb_block
setblock 1 171 349 minecraft:yellow_terracotta
fill 1 171 350 1 174 350 minecraft:honeycomb_block
setblock 1 171 354 minecraft:yellow_terracotta
setblock 2 171 348 minecraft:yellow_terracotta
setblock 2 171 349 minecraft:honeycomb_block
setblock 3 171 325 minecraft:light[level=12]
setblock 3 171 332 minecraft:light[level=12]
setblock 3 171 339 minecraft:light[level=12]
setblock 3 171 346 minecraft:light[level=12]
setblock 3 171 353 minecraft:light[level=12]
setblock 3 171 360 minecraft:light[level=12]
setblock 8 171 363 minecraft:honey_block
setblock 10 171 325 minecraft:light[level=12]
setblock 10 171 332 minecraft:light[level=12]
setblock 10 171 339 minecraft:light[level=12]
setblock 10 171 346 minecraft:light[level=12]
setblock 10 171 353 minecraft:light[level=12]
setblock 10 171 360 minecraft:light[level=12]
setblock 11 171 324 minecraft:yellow_terracotta
setblock 12 171 323 minecraft:yellow_terracotta
fill 12 171 324 12 174 324 minecraft:honeycomb_block
fill 13 171 323 13 174 323 minecraft:honeycomb_block
setblock 14 171 325 minecraft:honeycomb_block
setblock 14 171 326 minecraft:yellow_terracotta
setblock 15 171 325 minecraft:yellow_terracotta
fill 15 171 326 15 173 326 minecraft:honeycomb_block
setblock 16 171 324 minecraft:yellow_terracotta
fill 16 171 325 16 174 325 minecraft:honeycomb_block
setblock 17 171 323 minecraft:yellow_terracotta
fill 17 171 324 17 174 324 minecraft:honeycomb_block
setblock 17 171 332 minecraft:light[level=12]
setblock 17 171 339 minecraft:light[level=12]
setblock 17 171 346 minecraft:light[level=12]
setblock 17 171 353 minecraft:light[level=12]
setblock 17 171 360 minecraft:light[level=12]
setblock 17 171 363 minecraft:yellow_terracotta
fill 18 171 323 18 174 323 minecraft:honeycomb_block
fill 18 171 363 18 172 363 minecraft:honeycomb_block
setblock 20 171 325 minecraft:yellow_terracotta
setblock 21 171 324 minecraft:yellow_terracotta
setblock 22 171 323 minecraft:yellow_terracotta
setblock 22 171 324 minecraft:honeycomb_block
fill 23 171 323 23 172 323 minecraft:honeycomb_block
setblock 24 171 325 minecraft:light[level=12]
setblock 24 171 332 minecraft:light[level=12]
setblock 24 171 339 minecraft:light[level=12]
setblock 24 171 346 minecraft:light[level=12]
setblock 24 171 353 minecraft:light[level=12]
setblock 24 171 360 minecraft:light[level=12]
setblock 27 171 323 minecraft:yellow_terracotta
setblock 27 171 363 minecraft:honey_block
setblock 28 171 323 minecraft:honeycomb_block
setblock 31 171 325 minecraft:light[level=12]
setblock 31 171 332 minecraft:light[level=12]
setblock 31 171 339 minecraft:light[level=12]
setblock 31 171 346 minecraft:light[level=12]
setblock 31 171 353 minecraft:light[level=12]
setblock 31 171 360 minecraft:light[level=12]
setblock 32 171 323 minecraft:yellow_terracotta
setblock 32 171 324 minecraft:honeycomb_block
setblock 32 171 363 minecraft:yellow_terracotta
fill 33 171 323 33 174 323 minecraft:honeycomb_block
fill 33 171 363 33 174 363 minecraft:honeycomb_block
setblock 34 171 362 minecraft:honeycomb_block
setblock 36 171 324 minecraft:yellow_terracotta
setblock 37 171 323 minecraft:yellow_terracotta
setblock 37 171 363 minecraft:yellow_terracotta
fill 38 171 323 38 172 323 minecraft:honeycomb_block
setblock 38 171 325 minecraft:light[level=12]
setblock 38 171 332 minecraft:light[level=12]
setblock 38 171 339 minecraft:light[level=12]
setblock 38 171 346 minecraft:light[level=12]
setblock 38 171 353 minecraft:light[level=12]
setblock 38 171 360 minecraft:light[level=12]
fill 38 171 363 38 172 363 minecraft:honeycomb_block
fill 39 171 347 39 172 347 minecraft:honeycomb_block
setblock 39 171 351 minecraft:yellow_terracotta
fill 39 171 352 39 174 352 minecraft:honeycomb_block
setblock 40 171 345 minecraft:yellow_terracotta
fill 40 171 346 40 174 346 minecraft:honeycomb_block
setblock 40 171 350 minecraft:yellow_terracotta
fill 40 171 351 40 174 351 minecraft:honeycomb_block
setblock 40 171 355 minecraft:yellow_terracotta
setblock 41 171 341 minecraft:honey_block
setblock 41 171 344 minecraft:yellow_terracotta
fill 41 171 345 41 174 345 minecraft:honeycomb_block
setblock 41 171 349 minecraft:yellow_terracotta
fill 41 171 350 41 174 350 minecraft:honeycomb_block
setblock 41 171 354 minecraft:yellow_terracotta
fill 41 171 355 41 174 355 minecraft:honeycomb_block
setblock 41 171 360 minecraft:honey_block
fill 42 171 326 42 298 326 minecraft:honeycomb_block
setblock 42 171 338 minecraft:yellow_concrete
setblock 42 171 361 minecraft:yellow_terracotta
fill 0 172 333 0 210 333 minecraft:honeycomb_block
fill 0 172 342 0 232 343 minecraft:honeycomb_block
setblock 1 172 328 minecraft:yellow_terracotta
fill 1 172 329 1 175 329 minecraft:honeycomb_block
setblock 1 172 333 minecraft:yellow_terracotta
fill 1 172 334 1 175 334 minecraft:honeycomb_block
setblock 1 172 343 minecraft:yellow_terracotta
fill 1 172 344 1 173 344 minecraft:honeycomb_block
setblock 1 172 348 minecraft:yellow_terracotta
fill 1 172 349 1 175 349 minecraft:honeycomb_block
setblock 1 172 353 minecraft:yellow_terracotta
fill 1 172 354 1 175 354 minecraft:honeycomb_block
setblock 5 172 322 minecraft:yellow_terracotta
fill 9 172 323 9 173 323 minecraft:honeycomb_block
setblock 11 172 323 minecraft:yellow_terracotta
fill 11 172 324 11 175 324 minecraft:honeycomb_block
fill 12 172 323 12 175 323 minecraft:honeycomb_block
setblock 14 172 325 minecraft:yellow_terracotta
fill 14 172 326 14 175 326 minecraft:honeycomb_block
setblock 14 172 363 minecraft:honey_block
setblock 15 172 324 minecraft:yellow_terracotta
fill 15 172 325 15 175 325 minecraft:honeycomb_block
setblock 16 172 323 minecraft:yellow_terracotta
fill 16 172 324 16 175 324 minecraft:honeycomb_block
setblock 16 172 363 minecraft:yellow_terracotta
fill 17 172 323 17 175 323 minecraft:honeycomb_block
fill 17 172 363 17 175 363 minecraft:honeycomb_block
setblock 19 172 325 minecraft:yellow_terracotta
setblock 20 172 324 minecraft:yellow_terracotta
setblock 21 172 323 minecraft:yellow_terracotta
setblock 21 172 324 minecraft:honeycomb_block
fill 22 172 323 22 174 323 minecraft:honeycomb_block
setblock 28 172 323 minecraft:honey_block
fill 28 172 360 28 178 360 minecraft:brown_terracotta
setblock 30 172 364 minecraft:orange_terracotta
fill 31 172 322 31 172 323 minecraft:yellow_terracotta
setblock 31 172 363 minecraft:yellow_terracotta
fill 32 172 323 32 175 323 minecraft:honeycomb_block
fill 32 172 363 32 175 363 minecraft:honeycomb_block
setblock 36 172 323 minecraft:yellow_terracotta
setblock 36 172 363 minecraft:yellow_terracotta
fill 37 172 323 37 173 323 minecraft:honeycomb_block
fill 37 172 363 37 175 363 minecraft:honeycomb_block
setblock 39 172 350 minecraft:yellow_terracotta
fill 39 172 351 39 175 351 minecraft:honeycomb_block
setblock 40 172 345 minecraft:honeycomb_block
setblock 40 172 349 minecraft:yellow_terracotta
fill 40 172 350 40 175 350 minecraft:honeycomb_block
setblock 40 172 354 minecraft:yellow_terracotta
fill 40 172 355 40 175 355 minecraft:honeycomb_block
setblock 41 172 335 minecraft:honey_block
fill 41 172 344 41 174 344 minecraft:honeycomb_block
setblock 41 172 348 minecraft:yellow_terracotta
fill 41 172 349 41 175 349 minecraft:honeycomb_block
setblock 41 172 353 minecraft:yellow_terracotta
fill 41 172 354 41 175 354 minecraft:honeycomb_block
fill 42 172 338 42 200 338 minecraft:honeycomb_block
fill 42 172 361 42 250 361 minecraft:honeycomb_block
setblock 0 173 357 minecraft:yellow_concrete
setblock 1 173 327 minecraft:yellow_terracotta
fill 1 173 328 1 176 328 minecraft:honeycomb_block
setblock 1 173 332 minecraft:yellow_terracotta
fill 1 173 333 1 176 333 minecraft:honeycomb_block
fill 1 173 335 1 174 335 minecraft:honeycomb_block
setblock 1 173 338 minecraft:honey_block
setblock 1 173 347 minecraft:yellow_terracotta
fill 1 173 348 1 176 348 minecraft:honeycomb_block
setblock 1 173 352 minecraft:yellow_terracotta
fill 1 173 353 1 176 353 minecraft:honeycomb_block
setblock 1 173 357 minecraft:honey_block
setblock 3 173 322 minecraft:orange_terracotta
setblock 3 173 323 minecraft:honey_block
fill 5 173 322 5 308 322 minecraft:honeycomb_block
setblock 10 173 323 minecraft:yellow_terracotta
fill 10 173 324 10 176 324 minecraft:honeycomb_block
fill 11 173 323 11 176 323 minecraft:honeycomb_block
setblock 13 173 325 minecraft:yellow_terracotta
setblock 14 173 324 minecraft:yellow_terracotta
fill 14 173 325 14 176 325 minecraft:honeycomb_block
setblock 14 173 363 minecraft:honeycomb_block
setblock 15 173 323 minecraft:yellow_terracotta
fill 15 173 324 15 176 324 minecraft:honeycomb_block
setblock 15 173 363 minecraft:yellow_terracotta
fill 16 173 323 16 176 323 minecraft:honeycomb_block
fill 16 173 363 16 176 363 minecraft:honeycomb_block
setblock 18 173 325 minecraft:yellow_terracotta
setblock 19 173 324 minecraft:yellow_terracotta
setblock 20 173 323 minecraft:yellow_terracotta
setblock 20 173 324 minecraft:honeycomb_block
setblock 20 173 363 minecraft:honey_block
fill 21 173 323 21 176 323 minecraft:honeycomb_block
fill 25 173 333 28 175 334 minecraft:flowering_azalea_leaves[persistent=true]
fill 26 173 332 28 175 332 minecraft:flowering_azalea_leaves[persistent=true]
fill 26 173 335 28 175 335 minecraft:flowering_azalea_leaves[persistent=true]
setblock 29 173 363 minecraft:honeycomb_block
setblock 30 173 323 minecraft:yellow_terracotta
setblock 30 173 363 minecraft:yellow_terracotta
fill 30 173 364 30 207 364 minecraft:honeycomb_block
fill 31 173 322 31 175 323 minecraft:honeycomb_block
fill 31 173 363 31 176 363 minecraft:honeycomb_block
fill 34 173 362 34 174 362 minecraft:honeycomb_block
setblock 35 173 323 minecraft:yellow_terracotta
setblock 35 173 363 minecraft:yellow_terracotta
fill 36 173 323 36 174 323 minecraft:honeycomb_block
fill 36 173 363 36 176 363 minecraft:honeycomb_block
setblock 39 173 349 minecraft:yellow_terracotta
fill 39 173 350 39 176 350 minecraft:honeycomb_block
setblock 39 173 354 minecraft:yellow_terracotta
setblock 39 173 363 minecraft:honey_block
setblock 40 173 348 minecraft:yellow_terracotta
fill 40 173 349 40 176 349 minecraft:honeycomb_block
setblock 40 173 353 minecraft:yellow_terracotta
fill 40 173 354 40 176 354 minecraft:honeycomb_block
setblock 41 173 329 minecraft:honey_block
setblock 41 173 347 minecraft:yellow_terracotta
fill 41 173 348 41 176 348 minecraft:honeycomb_block
setblock 41 173 352 minecraft:yellow_terracotta
fill 41 173 353 41 176 353 minecraft:honeycomb_block
setblock 41 173 357 minecraft:yellow_terracotta
setblock 42 173 349 minecraft:orange_terracotta
fill 0 174 357 0 186 357 minecraft:honeycomb_block
fill 1 174 327 1 177 327 minecraft:honeycomb_block
setblock 1 174 331 minecraft:yellow_terracotta
fill 1 174 332 1 177 332 minecraft:honeycomb_block
setblock 1 174 336 minecraft:yellow_terracotta
fill 1 174 337 1 177 337 minecraft:honeycomb_block
setblock 1 174 344 minecraft:honey_block
setblock 1 174 346 minecraft:yellow_terracotta
fill 1 174 347 1 177 347 minecraft:honeycomb_block
setblock 1 174 351 minecraft:yellow_terracotta
fill 1 174 352 1 177 352 minecraft:honeycomb_block
setblock 1 174 363 minecraft:honey_block
fill 3 174 322 3 181 322 minecraft:honeycomb_block
setblock 7 174 364 minecraft:orange_terracotta
setblock 9 174 323 minecraft:yellow_terracotta
fill 10 174 323 10 177 323 minecraft:honeycomb_block
setblock 11 174 325 minecraft:honeycomb_block
setblock 12 174 325 minecraft:yellow_terracotta
setblock 13 174 324 minecraft:yellow_terracotta
fill 13 174 325 13 177 325 minecraft:honeycomb_block
setblock 13 174 363 minecraft:honeycomb_block
setblock 14 174 323 minecraft:yellow_terracotta
fill 14 174 324 14 177 324 minecraft:honeycomb_block
setblock 14 174 363 minecraft:yellow_terracotta
fill 15 174 323 15 177 323 minecraft:honeycomb_block
fill 15 174 363 15 177 363 minecraft:honeycomb_block
setblock 15 174 364 minecraft:yellow_terracotta
setblock 17 174 325 minecraft:yellow_terracotta
setblock 18 174 324 minecraft:yellow_terracotta
setblock 18 174 363 minecraft:honeycomb_block
setblock 19 174 323 minecraft:yellow_terracotta
fill 19 174 324 19 175 324 minecraft:honeycomb_block
fill 20 174 323 20 177 323 minecraft:honeycomb_block
setblock 26 174 363 minecraft:honey_block
setblock 28 174 363 minecraft:honeycomb_block
setblock 29 174 323 minecraft:yellow_terracotta
fill 29 174 333 29 174 334 minecraft:flowering_azalea_leaves[persistent=true]
setblock 29 174 363 minecraft:yellow_terracotta
fill 30 174 323 30 177 323 minecraft:honeycomb_block
fill 30 174 363 30 177 363 minecraft:honeycomb_block
fill 32 174 362 33 175 362 minecraft:honeycomb_block
setblock 34 174 323 minecraft:yellow_terracotta
setblock 34 174 363 minecraft:yellow_terracotta
fill 34 174 364 34 263 364 minecraft:honeycomb_block
fill 35 174 323 35 177 323 minecraft:honeycomb_block
fill 35 174 363 35 177 363 minecraft:honeycomb_block
fill 38 174 337 38 176 337 minecraft:brown_terracotta
fill 39 174 336 39 176 336 minecraft:brown_terracotta
fill 39 174 338 39 176 338 minecraft:brown_terracotta
setblock 39 174 348 minecraft:yellow_terracotta
fill 39 174 349 39 176 349 minecraft:honeycomb_block
setblock 39 174 353 minecraft:yellow_terracotta
fill 39 174 354 39 177 354 minecraft:honeycomb_block
fill 40 174 337 40 176 337 minecraft:brown_terracotta
setblock 40 174 347 minecraft:yellow_terracotta
fill 40 174 348 40 177 348 minecraft:honeycomb_block
setblock 40 174 352 minecraft:yellow_terracotta
fill 40 174 353 40 177 353 minecraft:honeycomb_block
setblock 40 174 356 minecraft:honeycomb_block
setblock 41 174 323 minecraft:honey_block
setblock 41 174 331 minecraft:yellow_terracotta
setblock 41 174 342 minecraft:honey_block
setblock 41 174 346 minecraft:yellow_terracotta
fill 41 174 347 41 177 347 minecraft:honeycomb_block
setblock 41 174 351 minecraft:yellow_terracotta
fill 41 174 352 41 177 352 minecraft:honeycomb_block
setblock 41 174 356 minecraft:yellow_terracotta
fill 41 174 357 41 177 357 minecraft:honeycomb_block
fill 42 174 349 42 176 349 minecraft:honeycomb_block
setblock 1 175 325 minecraft:honey_block
setblock 1 175 330 minecraft:yellow_terracotta
fill 1 175 331 2 177 331 minecraft:honeycomb_block
setblock 1 175 335 minecraft:yellow_terracotta
fill 1 175 336 1 178 336 minecraft:honeycomb_block
fill 1 175 338 1 176 338 minecraft:honeycomb_block
setblock 1 175 345 minecraft:yellow_terracotta
fill 1 175 346 1 176 346 minecraft:honeycomb_block
setblock 1 175 350 minecraft:yellow_terracotta
fill 1 175 351 1 178 351 minecraft:honeycomb_block
setblock 1 175 355 minecraft:yellow_terracotta
fill 2 175 330 2 178 330 minecraft:honeycomb_block
fill 2 175 332 2 175 333 minecraft:honeycomb_block
setblock 2 175 334 minecraft:yellow_terracotta
setblock 3 175 325 minecraft:light[level=15]
setblock 3 175 333 minecraft:light[level=15]
setblock 3 175 341 minecraft:light[level=15]
setblock 3 175 349 minecraft:light[level=15]
setblock 3 175 357 minecraft:light[level=15]
setblock 7 175 363 minecraft:honey_block
fill 7 175 364 7 192 364 minecraft:honeycomb_block
setblock 8 175 323 minecraft:yellow_terracotta
fill 9 175 323 9 177 324 minecraft:honeycomb_block
setblock 11 175 325 minecraft:yellow_terracotta
setblock 11 175 333 minecraft:light[level=15]
setblock 11 175 341 minecraft:light[level=15]
setblock 11 175 349 minecraft:light[level=15]
setblock 11 175 357 minecraft:light[level=15]
setblock 12 175 324 minecraft:yellow_terracotta
fill 12 175 325 12 178 325 minecraft:honeycomb_block
setblock 12 175 363 minecraft:honeycomb_block
setblock 13 175 323 minecraft:yellow_terracotta
fill 13 175 324 13 178 324 minecraft:honeycomb_block
fill 13 175 326 13 176 326 minecraft:honeycomb_block
setblock 13 175 363 minecraft:yellow_terracotta
fill 14 175 323 14 178 323 minecraft:honeycomb_block
fill 14 175 363 14 178 363 minecraft:honeycomb_block
fill 15 175 364 15 195 364 minecraft:honeycomb_block
setblock 16 175 325 minecraft:yellow_terracotta
setblock 17 175 324 minecraft:yellow_terracotta
setblock 17 175 325 minecraft:honeycomb_block
setblock 18 175 323 minecraft:yellow_terracotta
fill 18 175 324 18 177 324 minecraft:honeycomb_block
setblock 18 175 363 minecraft:yellow_terracotta
fill 19 175 323 19 178 323 minecraft:honeycomb_block
setblock 19 175 325 minecraft:light[level=15]
setblock 19 175 333 minecraft:light[level=15]
setblock 19 175 341 minecraft:light[level=15]
setblock 19 175 349 minecraft:light[level=15]
setblock 19 175 357 minecraft:light[level=15]
fill 25 175 355 26 176 357 minecraft:yellow_concrete
setblock 27 175 325 minecraft:light[level=15]
setblock 27 175 341 minecraft:light[level=15]
setblock 27 175 349 minecraft:light[level=15]
setblock 27 175 357 minecraft:light[level=15]
setblock 27 175 363 minecraft:honeycomb_block
setblock 28 175 323 minecraft:yellow_terracotta
setblock 28 175 363 minecraft:yellow_terracotta
setblock 29 175 322 minecraft:yellow_concrete
fill 29 175 323 29 178 323 minecraft:honeycomb_block
fill 29 175 363 29 178 363 minecraft:honeycomb_block
fill 30 175 362 31 177 362 minecraft:honeycomb_block
setblock 33 175 323 minecraft:yellow_terracotta
setblock 33 175 363 minecraft:yellow_terracotta
fill 34 175 323 34 178 323 minecraft:honeycomb_block
setblock 34 175 362 minecraft:yellow_terracotta
fill 34 175 363 34 178 363 minecraft:honeycomb_block
setblock 35 175 325 minecraft:light[level=15]
setblock 35 175 333 minecraft:light[level=15]
setblock 35 175 341 minecraft:light[level=15]
setblock 35 175 349 minecraft:light[level=15]
setblock 35 175 357 minecraft:light[level=15]
fill 35 175 362 35 178 362 minecraft:honeycomb_block
setblock 39 175 352 minecraft:yellow_terracotta
fill 39 175 353 39 178 353 minecraft:honeycomb_block
fill 39 175 355 39 176 355 minecraft:honeycomb_block
fill 40 175 347 40 176 347 minecraft:honeycomb_block
setblock 40 175 351 minecraft:yellow_terracotta
fill 40 175 352 40 178 352 minecraft:honeycomb_block
setblock 40 175 356 minecraft:yellow_terracotta
setblock 41 175 330 minecraft:yellow_terracotta
fill 41 175 331 41 175 334 minecraft:honeycomb_block
setblock 41 175 336 minecraft:honey_block
setblock 41 175 345 minecraft:yellow_terracotta
fill 41 175 346 41 178 346 minecraft:honeycomb_block
setblock 41 175 350 minecraft:yellow_terracotta
fill 41 175 351 41 178 351 minecraft:honeycomb_block
setblock 41 175 355 minecraft:yellow_terracotta
fill 41 175 356 41 178 356 minecraft:honeycomb_block
fill 41 175 358 41 176 358 minecraft:honeycomb_block
setblock 41 175 361 minecraft:honey_block
setblock 1 176 329 minecraft:yellow_terracotta
fill 1 176 330 1 179 330 minecraft:honeycomb_block
setblock 1 176 334 minecraft:yellow_terracotta
fill 1 176 335 2 178 335 minecraft:honeycomb_block
setblock 1 176 339 minecraft:yellow_terracotta
fill 1 176 340 1 179 340 minecraft:honeycomb_block
setblock 1 176 349 minecraft:yellow_terracotta
fill 1 176 350 1 179 350 minecraft:honeycomb_block
setblock 1 176 354 minecraft:yellow_terracotta
fill 1 176 355 1 179 355 minecraft:honeycomb_block
setblock 1 176 356 minecraft:honey_block
fill 2 176 329 2 179 329 minecraft:honeycomb_block
setblock 2 176 332 minecraft:honeycomb_block
setblock 2 176 333 minecraft:yellow_terracotta
fill 2 176 334 2 179 334 minecraft:honeycomb_block
setblock 4 176 323 minecraft:honey_block
setblock 7 176 323 minecraft:yellow_terracotta
fill 8 176 323 8 179 323 minecraft:honeycomb_block
setblock 10 176 325 minecraft:yellow_terracotta
fill 10 176 363 11 176 363 minecraft:honeycomb_block
setblock 11 176 324 minecraft:yellow_terracotta
fill 11 176 325 11 179 325 minecraft:honeycomb_block
setblock 11 176 364 minecraft:yellow_terracotta
fill 12 176 322 12 176 323 minecraft:yellow_terracotta
fill 12 176 324 12 179 324 minecraft:honeycomb_block
fill 12 176 326 12 177 326 minecraft:honeycomb_block
setblock 12 176 363 minecraft:yellow_terracotta
fill 13 176 323 13 179 323 minecraft:honeycomb_block
fill 13 176 363 13 179 363 minecraft:honeycomb_block
setblock 15 176 325 minecraft:yellow_terracotta
setblock 16 176 324 minecraft:yellow_terracotta
fill 16 176 325 16 177 325 minecraft:honeycomb_block
setblock 17 176 323 minecraft:yellow_terracotta
fill 17 176 324 17 178 324 minecraft:honeycomb_block
setblock 17 176 363 minecraft:yellow_terracotta
fill 18 176 323 18 179 323 minecraft:honeycomb_block
fill 18 176 363 19 178 363 minecraft:honeycomb_block
setblock 23 176 323 minecraft:honey_block
setblock 26 176 363 minecraft:honeycomb_block
setblock 27 176 323 minecraft:yellow_terracotta
fill 27 176 360 27 178 360 minecraft:brown_terracotta
setblock 27 176 363 minecraft:yellow_terracotta
fill 28 176 323 28 179 323 minecraft:honeycomb_block
fill 28 176 359 28 178 359 minecraft:brown_terracotta
fill 28 176 361 28 177 361 minecraft:brown_terracotta
fill 28 176 363 28 179 363 minecraft:honeycomb_block
fill 29 176 322 29 241 322 minecraft:honeycomb_block
fill 29 176 358 29 181 358 minecraft:brown_terracotta
fill 29 176 360 29 178 360 minecraft:brown_terracotta
fill 29 176 362 29 179 362 minecraft:honeycomb_block
setblock 31 176 322 minecraft:orange_terracotta
setblock 31 176 323 minecraft:honeycomb_block
setblock 32 176 323 minecraft:yellow_terracotta
fill 32 176 361 32 176 362 minecraft:honeycomb_block
setblock 32 176 363 minecraft:yellow_terracotta
fill 33 176 323 33 179 323 minecraft:honeycomb_block
setblock 33 176 362 minecraft:yellow_terracotta
fill 33 176 363 33 179 363 minecraft:honeycomb_block
fill 34 176 362 34 179 362 minecraft:honeycomb_block
setblock 37 176 363 minecraft:yellow_terracotta
setblock 38 176 336 minecraft:brown_terracotta
setblock 38 176 338 minecraft:brown_terracotta
setblock 38 176 363 minecraft:honey_block
setblock 39 176 351 minecraft:yellow_terracotta
fill 39 176 352 39 178 352 minecraft:honeycomb_block
setblock 40 176 336 minecraft:brown_terracotta
setblock 40 176 338 minecraft:brown_terracotta
setblock 40 176 350 minecraft:yellow_terracotta
fill 40 176 351 40 179 351 minecraft:honeycomb_block
setblock 40 176 355 minecraft:yellow_terracotta
fill 40 176 356 40 178 357 minecraft:honeycomb_block
fill 40 176 364 40 177 364 minecraft:orange_terracotta
setblock 41 176 329 minecraft:yellow_terracotta
fill 41 176 330 41 176 333 minecraft:honeycomb_block
setblock 41 176 334 minecraft:yellow_terracotta
fill 41 176 335 41 177 337 minecraft:honeycomb_block
fill 41 176 345 41 179 345 minecraft:honeycomb_block
setblock 41 176 349 minecraft:yellow_terracotta
fill 41 176 350 41 179 350 minecraft:honeycomb_block
setblock 41 176 354 minecraft:yellow_terracotta
fill 41 176 355 41 179 355 minecraft:honeycomb_block
setblock 1 177 328 minecraft:yellow_terracotta
fill 1 177 329 1 180 329 minecraft:honeycomb_block
setblock 1 177 333 minecraft:yellow_terracotta
fill 1 177 334 1 180 334 minecraft:honeycomb_block
setblock 1 177 338 minecraft:yellow_terracotta
fill 1 177 339 1 180 339 minecraft:honeycomb_block
fill 1 177 341 1 178 341 minecraft:honeycomb_block
fill 1 177 343 1 178 343 minecraft:honey_block
setblock 1 177 348 minecraft:yellow_terracotta
fill 1 177 349 1 178 349 minecraft:honeycomb_block
setblock 1 177 353 minecraft:yellow_terracotta
fill 1 177 354 1 180 354 minecraft:honeycomb_block
fill 1 177 356 1 178 356 minecraft:honeycomb_block
setblock 1 177 362 minecraft:honey_block
setblock 2 177 332 minecraft:yellow_terracotta
fill 2 177 333 3 179 333 minecraft:honeycomb_block
setblock 2 177 336 minecraft:honeycomb_block
setblock 2 177 337 minecraft:yellow_terracotta
setblock 3 177 325 minecraft:light[level=12]
setblock 3 177 332 minecraft:light[level=12]
fill 3 177 336 3 178 336 minecraft:yellow_terracotta
setblock 3 177 339 minecraft:light[level=12]
setblock 3 177 346 minecraft:light[level=12]
setblock 3 177 353 minecraft:light[level=12]
setblock 3 177 360 minecraft:light[level=12]
fill 6 177 333 6 178 335 minecraft:honey_block
fill 7 177 323 7 180 323 minecraft:honeycomb_block
fill 7 177 334 7 178 335 minecraft:honey_block
fill 8 177 324 8 178 324 minecraft:honeycomb_block
setblock 9 177 322 minecraft:orange_terracotta
setblock 9 177 325 minecraft:yellow_terracotta
fill 9 177 363 10 177 363 minecraft:honeycomb_block
setblock 10 177 324 minecraft:yellow_terracotta
fill 10 177 325 10 180 325 minecraft:honeycomb_block
setblock 10 177 332 minecraft:light[level=12]
setblock 10 177 339 minecraft:light[level=12]
setblock 10 177 346 minecraft:light[level=12]
setblock 10 177 353 minecraft:light[level=12]
setblock 10 177 360 minecraft:light[level=12]
setblock 11 177 323 minecraft:yellow_terracotta
fill 11 177 324 11 180 324 minecraft:honeycomb_block
setblock 11 177 363 minecraft:yellow_terracotta
fill 11 177 364 11 225 364 minecraft:honeycomb_block
fill 12 177 322 12 180 323 minecraft:honeycomb_block
setblock 12 177 362 minecraft:yellow_terracotta
fill 12 177 363 12 180 363 minecraft:honeycomb_block
setblock 13 177 326 minecraft:yellow_terracotta
fill 13 177 362 15 178 362 minecraft:honeycomb_block
setblock 14 177 325 minecraft:yellow_terracotta
setblock 15 177 324 minecraft:yellow_terracotta
fill 15 177 325 15 178 325 minecraft:honeycomb_block
setblock 16 177 323 minecraft:yellow_terracotta
fill 16 177 324 16 179 324 minecraft:honeycomb_block
setblock 16 177 363 minecraft:yellow_terracotta
fill 17 177 323 17 180 323 minecraft:honeycomb_block
setblock 17 177 325 minecraft:light[level=12]
fill 17 177 331 17 178 331 minecraft:yellow_concrete
setblock 17 177 332 minecraft:light[level=12]
setblock 17 177 339 minecraft:light[level=12]
setblock 17 177 346 minecraft:light[level=12]
setblock 17 177 353 minecraft:light[level=12]
setblock 17 177 360 minecraft:light[level=12]
fill 17 177 363 17 180 363 minecraft:honeycomb_block
fill 18 177 331 18 178 331 minecraft:black_concrete
setblock 20 177 363 minecraft:honeycomb_block
fill 23 177 363 25 177 363 minecraft:honeycomb_block
setblock 24 177 325 minecraft:light[level=12]
setblock 24 177 332 minecraft:light[level=12]
setblock 24 177 339 minecraft:light[level=12]
setblock 24 177 346 minecraft:light[level=12]
setblock 24 177 353 minecraft:light[level=12]
setblock 24 177 360 minecraft:light[level=12]
setblock 26 177 363 minecraft:yellow_terracotta
fill 27 177 323 27 180 323 minecraft:honeycomb_block
fill 27 177 359 27 178 359 minecraft:brown_terracotta
fill 27 177 361 27 178 361 minecraft:brown_terracotta
setblock 27 177 362 minecraft:yellow_terracotta
fill 27 177 363 27 180 363 minecraft:honeycomb_block
fill 28 177 362 28 180 362 minecraft:honeycomb_block
fill 29 177 359 29 181 359 minecraft:brown_terracotta
fill 29 177 361 32 177 361 minecraft:honeycomb_block
fill 31 177 322 31 179 322 minecraft:honeycomb_block
setblock 31 177 323 minecraft:yellow_terracotta
setblock 31 177 325 minecraft:light[level=12]
setblock 31 177 332 minecraft:light[level=12]
setblock 31 177 339 minecraft:light[level=12]
setblock 31 177 346 minecraft:light[level=12]
setblock 31 177 353 minecraft:light[level=12]
setblock 31 177 360 minecraft:light[level=12]
setblock 31 177 363 minecraft:yellow_terracotta
setblock 31 177 364 minecraft:yellow_concrete
fill 32 177 323 32 180 323 minecraft:honeycomb_block
setblock 32 177 362 minecraft:yellow_terracotta
fill 32 177 363 32 180 363 minecraft:honeycomb_block
setblock 33 177 361 minecraft:yellow_terracotta
fill 33 177 362 33 180 362 minecraft:honeycomb_block
fill 34 177 361 34 180 361 minecraft:honeycomb_block
setblock 36 177 363 minecraft:yellow_terracotta
fill 37 177 363 37 178 363 minecraft:honeycomb_block
setblock 38 177 325 minecraft:light[level=12]
setblock 38 177 332 minecraft:light[level=12]
setblock 38 177 339 minecraft:light[level=12]
setblock 38 177 346 minecraft:light[level=12]
setblock 38 177 353 minecraft:light[level=12]
setblock 38 177 360 minecraft:light[level=12]
setblock 39 177 350 minecraft:yellow_terracotta
fill 39 177 351 39 178 351 minecraft:honeycomb_block
setblock 39 177 355 minecraft:yellow_terracotta
setblock 40 177 349 minecraft:yellow_terracotta
fill 40 177 350 40 179 350 minecraft:honeycomb_block
setblock 40 177 354 minecraft:yellow_terracotta
fill 40 177 355 40 180 355 minecraft:honeycomb_block
setblock 41 177 324 minecraft:honey_block
fill 41 177 329 41 177 332 minecraft:honeycomb_block
setblock 41 177 333 minecraft:yellow_terracotta
fill 41 177 334 41 180 334 minecraft:honeycomb_block
setblock 41 177 338 minecraft:yellow_terracotta
fill 41 177 339 41 180 339 minecraft:honeycomb_block
setblock 41 177 343 minecraft:honey_block
fill 41 177 344 41 180 344 minecraft:honeycomb_block
setblock 41 177 348 minecraft:yellow_terracotta
fill 41 177 349 41 180 349 minecraft:honeycomb_block
setblock 41 177 353 minecraft:yellow_terracotta
fill 41 177 354 41 180 354 minecraft:honeycomb_block
setblock 41 177 358 minecraft:yellow_terracotta
fill 41 177 359 41 180 359 minecraft:honeycomb_block
setblock 42 177 349 minecraft:yellow_concrete
setblock 1 178 324 minecraft:honey_block
setblock 1 178 327 minecraft:yellow_terracotta
fill 1 178 328 1 181 328 minecraft:honeycomb_block
setblock 1 178 331 minecraft:honeycomb_block
setblock 1 178 332 minecraft:yellow_terracotta
fill 1 178 333 1 181 333 minecraft:honeycomb_block
setblock 1 178 337 minecraft:yellow_terracotta
fill 1 178 338 2 180 338 minecraft:honeycomb_block
setblock 1 178 348 minecraft:honeycomb_block
setblock 1 178 352 minecraft:yellow_terracotta
fill 1 178 353 1 180 353 minecraft:honeycomb_block
setblock 2 178 322 minecraft:orange_terracotta
setblock 2 178 331 minecraft:yellow_terracotta
fill 2 178 332 3 180 332 minecraft:honeycomb_block
setblock 2 178 336 minecraft:yellow_terracotta
fill 2 178 337 2 181 337 minecraft:honeycomb_block
fill 3 178 331 3 180 331 minecraft:honeycomb_block
setblock 3 178 334 minecraft:honeycomb_block
setblock 3 178 335 minecraft:yellow_terracotta
fill 6 178 323 6 181 323 minecraft:honeycomb_block
setblock 6 178 363 minecraft:honey_block
fill 7 178 324 7 179 324 minecraft:honeycomb_block
fill 8 178 363 9 178 363 minecraft:honeycomb_block
fill 9 178 322 9 178 323 minecraft:honeycomb_block
setblock 9 178 324 minecraft:yellow_terracotta
fill 9 178 325 9 180 325 minecraft:honeycomb_block
setblock 10 178 323 minecraft:yellow_terracotta
fill 10 178 324 10 181 324 minecraft:honeycomb_block
setblock 10 178 362 minecraft:honeycomb_block
setblock 10 178 363 minecraft:yellow_terracotta
fill 11 178 323 11 181 323 minecraft:honeycomb_block
setblock 11 178 362 minecraft:yellow_terracotta
fill 11 178 363 11 181 363 minecraft:honeycomb_block
fill 12 178 362 12 181 362 minecraft:honeycomb_block
setblock 13 178 325 minecraft:yellow_terracotta
setblock 14 178 324 minecraft:yellow_terracotta
fill 14 178 325 14 179 325 minecraft:honeycomb_block
setblock 15 178 323 minecraft:yellow_terracotta
fill 15 178 324 15 180 324 minecraft:honeycomb_block
setblock 15 178 363 minecraft:yellow_terracotta
fill 16 178 323 16 181 323 minecraft:honeycomb_block
setblock 16 178 362 minecraft:yellow_terracotta
fill 16 178 363 16 181 363 minecraft:honeycomb_block
setblock 20 178 323 minecraft:yellow_terracotta
setblock 20 178 363 minecraft:yellow_terracotta
fill 21 178 363 24 178 363 minecraft:honeycomb_block
setblock 25 178 363 minecraft:yellow_terracotta
fill 26 178 323 26 181 323 minecraft:honeycomb_block
setblock 26 178 362 minecraft:yellow_terracotta
fill 26 178 363 26 181 363 minecraft:honeycomb_block
fill 27 178 362 27 181 362 minecraft:honeycomb_block
fill 28 178 361 31 178 361 minecraft:honeycomb_block
setblock 30 178 323 minecraft:yellow_terracotta
setblock 30 178 362 minecraft:honeycomb_block
setblock 30 178 363 minecraft:yellow_terracotta
fill 31 178 323 31 181 323 minecraft:honeycomb_block
fill 31 178 360 32 178 360 minecraft:honeycomb_block
setblock 31 178 362 minecraft:yellow_terracotta
fill 31 178 363 31 181 364 minecraft:honeycomb_block
setblock 32 178 361 minecraft:yellow_terracotta
fill 32 178 362 32 181 362 minecraft:honeycomb_block
fill 33 178 361 33 181 361 minecraft:honeycomb_block
setblock 35 178 363 minecraft:yellow_terracotta
setblock 36 178 323 minecraft:honey_block
fill 36 178 363 36 181 363 minecraft:honeycomb_block
setblock 39 178 354 minecraft:yellow_terracotta
fill 39 178 355 39 179 355 minecraft:honeycomb_block
setblock 40 178 333 minecraft:yellow_terracotta
fill 40 178 334 40 180 335 minecraft:honeycomb_block
setblock 40 178 348 minecraft:yellow_terracotta
setblock 40 178 349 minecraft:honeycomb_block
setblock 40 178 353 minecraft:yellow_terracotta
fill 40 178 354 40 181 354 minecraft:honeycomb_block
fill 40 178 364 40 182 364 minecraft:honeycomb_block
fill 41 178 330 41 178 331 minecraft:honeycomb_block
setblock 41 178 332 minecraft:yellow_terracotta
fill 41 178 333 41 181 333 minecraft:honeycomb_block
fill 41 178 335 41 178 336 minecraft:honeycomb_block
setblock 41 178 337 minecraft:yellow_terracotta
fill 41 178 338 41 181 338 minecraft:honeycomb_block
fill 41 178 340 41 178 341 minecraft:honeycomb_block
setblock 41 178 342 minecraft:yellow_terracotta
fill 41 178 343 41 181 343 minecraft:honeycomb_block
setblock 41 178 347 minecraft:yellow_terracotta
fill 41 178 348 41 180 348 minecraft:honeycomb_block
setblock 41 178 352 minecraft:yellow_terracotta
fill 41 178 353 41 181 353 minecraft:honeycomb_block
setblock 41 178 357 minecraft:yellow_terracotta
fill 41 178 358 41 181 358 minecraft:honeycomb_block
setblock 41 178 362 minecraft:honey_block
setblock 42 178 343 minecraft:orange_terracotta
fill 42 178 349 42 270 349 minecraft:honeycomb_block
setblock 42 178 354 minecraft:orange_terracotta
fill 0 179 331 1 179 331 minecraft:yellow_terracotta
setblock 1 179 327 minecraft:honeycomb_block
fill 1 179 332 1 182 332 minecraft:honeycomb_block
setblock 1 179 335 minecraft:honeycomb_block
setblock 1 179 336 minecraft:yellow_terracotta
fill 1 179 337 1 182 337 minecraft:honeycomb_block
setblock 1 179 341 minecraft:yellow_terracotta
fill 1 179 342 1 182 342 minecraft:honeycomb_block
setblock 1 179 351 minecraft:yellow_terracotta
setblock 1 179 352 minecraft:honeycomb_block
setblock 1 179 356 minecraft:yellow_terracotta
fill 1 179 357 1 180 357 minecraft:honeycomb_block
fill 2 179 322 2 215 322 minecraft:honeycomb_block
setblock 2 179 330 minecraft:yellow_terracotta
fill 2 179 331 2 182 331 minecraft:honeycomb_block
setblock 2 179 335 minecraft:yellow_terracotta
fill 2 179 336 3 181 336 minecraft:honeycomb_block
setblock 2 179 339 minecraft:honeycomb_block
setblock 3 179 334 minecraft:yellow_terracotta
fill 3 179 335 3 182 335 minecraft:honeycomb_block
fill 5 179 323 5 182 323 minecraft:honeycomb_block
fill 7 179 363 8 179 363 minecraft:honeycomb_block
setblock 8 179 324 minecraft:yellow_terracotta
fill 9 179 322 9 308 322 minecraft:honeycomb_block
setblock 9 179 323 minecraft:yellow_terracotta
fill 9 179 324 9 182 324 minecraft:honeycomb_block
setblock 9 179 362 minecraft:honeycomb_block
setblock 9 179 363 minecraft:yellow_terracotta
fill 10 179 323 10 182 323 minecraft:honeycomb_block
setblock 10 179 362 minecraft:yellow_terracotta
fill 10 179 363 10 182 363 minecraft:honeycomb_block
fill 11 179 362 11 182 362 minecraft:honeycomb_block
setblock 12 179 325 minecraft:yellow_terracotta
setblock 13 179 324 minecraft:yellow_terracotta
setblock 13 179 325 minecraft:honeycomb_block
fill 13 179 362 14 179 362 minecraft:honeycomb_block
setblock 14 179 323 minecraft:yellow_terracotta
fill 14 179 324 14 181 324 minecraft:honeycomb_block
setblock 14 179 363 minecraft:yellow_terracotta
fill 15 179 323 15 182 323 minecraft:honeycomb_block
setblock 15 179 362 minecraft:yellow_terracotta
fill 15 179 363 15 182 363 minecraft:honeycomb_block
fill 16 179 362 16 182 362 minecraft:honeycomb_block
setblock 18 179 363 minecraft:honeycomb_block
setblock 19 179 323 minecraft:yellow_terracotta
setblock 19 179 363 minecraft:yellow_terracotta
fill 20 179 363 23 179 363 minecraft:honeycomb_block
setblock 24 179 362 minecraft:honeycomb_block
setblock 24 179 363 minecraft:yellow_terracotta
setblock 25 179 362 minecraft:yellow_terracotta
fill 25 179 363 25 182 363 minecraft:honeycomb_block
setblock 26 179 361 minecraft:yellow_terracotta
fill 26 179 362 26 182 362 minecraft:honeycomb_block
fill 27 179 361 30 179 361 minecraft:honeycomb_block
fill 28 179 358 28 181 358 minecraft:brown_terracotta
setblock 29 179 323 minecraft:yellow_terracotta
fill 29 179 357 29 181 357 minecraft:brown_terracotta
fill 29 179 360 31 179 360 minecraft:honeycomb_block
setblock 29 179 363 minecraft:yellow_terracotta
fill 30 179 323 30 182 323 minecraft:honeycomb_block
fill 30 179 358 30 181 358 minecraft:brown_terracotta
setblock 30 179 362 minecraft:yellow_terracotta
fill 30 179 363 30 182 363 minecraft:honeycomb_block
setblock 31 179 361 minecraft:yellow_terracotta
fill 31 179 362 31 182 362 minecraft:honeycomb_block
setblock 32 179 360 minecraft:yellow_terracotta
fill 32 179 361 32 182 361 minecraft:honeycomb_block
setblock 34 179 363 minecraft:yellow_terracotta
setblock 35 179 362 minecraft:yellow_terracotta
fill 35 179 363 35 182 363 minecraft:honeycomb_block
setblock 36 179 322 minecraft:yellow_concrete
setblock 37 179 363 minecraft:honey_block
setblock 39 179 353 minecraft:yellow_terracotta
setblock 39 179 354 minecraft:honeycomb_block
setblock 40 179 333 minecraft:honeycomb_block
setblock 40 179 336 minecraft:honeycomb_block
setblock 40 179 337 minecraft:yellow_terracotta
setblock 40 179 352 minecraft:yellow_terracotta
fill 40 179 353 40 180 353 minecraft:honeycomb_block
setblock 40 179 356 minecraft:honeycomb_block
setblock 40 179 357 minecraft:yellow_terracotta
setblock 41 179 330 minecraft:honeycomb_block
setblock 41 179 331 minecraft:yellow_terracotta
fill 41 179 332 41 182 332 minecraft:honeycomb_block
setblock 41 179 335 minecraft:honeycomb_block
setblock 41 179 336 minecraft:yellow_terracotta
fill 41 179 337 41 182 337 minecraft:honeycomb_block
setblock 41 179 340 minecraft:honeycomb_block
setblock 41 179 341 minecraft:yellow_terracotta
fill 41 179 342 41 182 342 minecraft:honeycomb_block
setblock 41 179 346 minecraft:yellow_terracotta
fill 41 179 347 41 180 347 minecraft:honeycomb_block
setblock 41 179 351 minecraft:yellow_terracotta
fill 41 179 352 41 182 352 minecraft:honeycomb_block
setblock 41 179 356 minecraft:yellow_terracotta
fill 41 179 357 41 182 357 minecraft:honeycomb_block
fill 42 179 343 42 183 343 minecraft:honeycomb_block
fill 42 179 354 42 198 354 minecraft:honeycomb_block
fill 0 180 331 1 183 331 minecraft:honeycomb_block
setblock 0 180 353 minecraft:yellow_terracotta
setblock 1 180 330 minecraft:yellow_terracotta
setblock 1 180 335 minecraft:yellow_terracotta
fill 1 180 336 1 183 336 minecraft:honeycomb_block
setblock 1 180 340 minecraft:yellow_terracotta
fill 1 180 341 1 183 341 minecraft:honeycomb_block
setblock 1 180 355 minecraft:yellow_terracotta
setblock 1 180 356 minecraft:honeycomb_block
setblock 1 180 361 minecraft:honey_block
fill 2 180 330 2 181 330 minecraft:honeycomb_block
setblock 2 180 333 minecraft:honeycomb_block
setblock 2 180 334 minecraft:yellow_terracotta
fill 2 180 335 2 183 335 minecraft:honeycomb_block
setblock 2 180 339 minecraft:yellow_terracotta
setblock 3 180 333 minecraft:yellow_terracotta
fill 3 180 334 3 183 334 minecraft:honeycomb_block
setblock 3 180 337 minecraft:honeycomb_block
fill 4 180 336 4 181 336 minecraft:yellow_terracotta
fill 6 180 363 7 180 363 minecraft:honeycomb_block
setblock 7 180 324 minecraft:yellow_terracotta
setblock 8 180 323 minecraft:yellow_terracotta
fill 8 180 324 8 183 324 minecraft:honeycomb_block
setblock 8 180 362 minecraft:honeycomb_block
setblock 8 180 363 minecraft:yellow_terracotta
fill 9 180 323 9 183 323 minecraft:honeycomb_block
setblock 9 180 362 minecraft:yellow_terracotta
fill 9 180 363 9 183 363 minecraft:honeycomb_block
fill 10 180 362 10 183 362 minecraft:honeycomb_block
setblock 11 180 325 minecraft:yellow_terracotta
setblock 12 180 324 minecraft:yellow_terracotta
setblock 12 180 325 minecraft:honeycomb_block
fill 12 180 361 12 182 361 minecraft:honeycomb_block
setblock 13 180 323 minecraft:yellow_terracotta
fill 13 180 324 13 182 324 minecraft:honeycomb_block
setblock 13 180 362 minecraft:honeycomb_block
setblock 13 180 363 minecraft:yellow_terracotta
setblock 14 180 322 minecraft:orange_terracotta
fill 14 180 323 14 183 323 minecraft:honeycomb_block
setblock 14 180 362 minecraft:yellow_terracotta
fill 14 180 363 14 183 363 minecraft:honeycomb_block
fill 15 180 362 15 183 362 minecraft:honeycomb_block
fill 17 180 362 17 181 362 minecraft:honeycomb_block
setblock 18 180 323 minecraft:yellow_terracotta
setblock 18 180 363 minecraft:yellow_terracotta
fill 19 180 363 22 180 363 minecraft:honeycomb_block
setblock 23 180 362 minecraft:honeycomb_block
setblock 23 180 363 minecraft:yellow_terracotta
setblock 24 180 323 minecraft:honey_block
setblock 24 180 362 minecraft:yellow_terracotta
fill 24 180 363 24 183 363 minecraft:honeycomb_block
setblock 25 180 361 minecraft:yellow_terracotta
fill 25 180 362 25 183 362 minecraft:honeycomb_block
fill 26 180 361 29 180 361 minecraft:honeycomb_block
setblock 28 180 323 minecraft:yellow_terracotta
fill 28 180 360 30 180 360 minecraft:honeycomb_block
setblock 28 180 363 minecraft:yellow_terracotta
fill 29 180 323 29 183 323 minecraft:honeycomb_block
setblock 29 180 362 minecraft:yellow_terracotta
fill 29 180 363 29 183 363 minecraft:honeycomb_block
setblock 30 180 361 minecraft:yellow_terracotta
fill 30 180 362 30 183 362 minecraft:honeycomb_block
setblock 31 180 322 minecraft:yellow_concrete
setblock 31 180 360 minecraft:yellow_terracotta
fill 31 180 361 31 183 361 minecraft:honeycomb_block
fill 32 180 360 32 181 360 minecraft:honeycomb_block
setblock 33 180 363 minecraft:yellow_terracotta
setblock 34 180 362 minecraft:yellow_terracotta
fill 34 180 363 34 183 363 minecraft:honeycomb_block
setblock 35 180 362 minecraft:honeycomb_block
fill 36 180 322 36 189 322 minecraft:honeycomb_block
setblock 40 180 336 minecraft:yellow_terracotta
fill 40 180 337 40 182 338 minecraft:honeycomb_block
setblock 40 180 351 minecraft:yellow_terracotta
setblock 40 180 352 minecraft:honeycomb_block
setblock 40 180 356 minecraft:yellow_terracotta
setblock 40 180 357 minecraft:honeycomb_block
setblock 41 180 325 minecraft:honey_block
setblock 41 180 330 minecraft:yellow_terracotta
fill 41 180 331 41 181 331 minecraft:honeycomb_block
setblock 41 180 335 minecraft:yellow_terracotta
fill 41 180 336 41 183 336 minecraft:honeycomb_block
setblock 41 180 340 minecraft:yellow_terracotta
fill 41 180 341 41 183 341 minecraft:honeycomb_block
setblock 41 180 346 minecraft:honeycomb_block
setblock 41 180 350 minecraft:yellow_terracotta
fill 41 180 351 41 181 351 minecraft:honeycomb_block
setblock 41 180 355 minecraft:yellow_terracotta
fill 41 180 356 41 183 356 minecraft:honeycomb_block
setblock 42 180 333 minecraft:yellow_terracotta
setblock 42 180 337 minecraft:orange_terracotta
fill 0 181 353 0 251 353 minecraft:honeycomb_block
setblock 0 181 354 minecraft:orange_terracotta
setblock 1 181 323 minecraft:honey_block
setblock 1 181 329 minecraft:yellow_terracotta
fill 1 181 330 1 184 330 minecraft:honeycomb_block
setblock 1 181 334 minecraft:yellow_terracotta
fill 1 181 335 1 184 335 minecraft:honeycomb_block
setblock 1 181 338 minecraft:honeycomb_block
setblock 1 181 339 minecraft:yellow_terracotta
fill 1 181 340 1 184 340 minecraft:honeycomb_block
setblock 2 181 332 minecraft:honeycomb_block
setblock 2 181 333 minecraft:yellow_terracotta
fill 2 181 334 2 184 334 minecraft:honeycomb_block
setblock 2 181 338 minecraft:yellow_terracotta
fill 2 181 339 2 184 339 minecraft:honeycomb_block
setblock 3 181 332 minecraft:yellow_terracotta
fill 3 181 333 3 182 333 minecraft:honeycomb_block
fill 3 181 337 4 181 337 minecraft:yellow_terracotta
setblock 4 181 335 minecraft:yellow_terracotta
setblock 5 181 363 minecraft:honey_block
setblock 6 181 363 minecraft:honeycomb_block
setblock 7 181 323 minecraft:yellow_terracotta
fill 7 181 324 7 184 324 minecraft:honeycomb_block
setblock 7 181 362 minecraft:honeycomb_block
setblock 7 181 363 minecraft:yellow_terracotta
fill 8 181 323 8 184 323 minecraft:honeycomb_block
setblock 8 181 362 minecraft:yellow_terracotta
fill 8 181 363 8 184 363 minecraft:honeycomb_block
fill 9 181 362 9 184 362 minecraft:honeycomb_block
setblock 10 181 325 minecraft:yellow_terracotta
fill 10 181 361 11 183 361 minecraft:honeycomb_block
setblock 11 181 324 minecraft:yellow_terracotta
fill 11 181 337 12 182 338 minecraft:honey_block
fill 12 181 322 12 271 322 minecraft:honeycomb_block
setblock 12 181 323 minecraft:yellow_terracotta
fill 12 181 324 12 183 324 minecraft:honeycomb_block
fill 12 181 339 12 182 339 minecraft:honey_block
setblock 12 181 363 minecraft:yellow_terracotta
fill 13 181 323 13 184 323 minecraft:honeycomb_block
setblock 13 181 362 minecraft:yellow_terracotta
fill 13 181 363 13 184 363 minecraft:honeycomb_block
fill 14 181 322 14 308 322 minecraft:honeycomb_block
fill 14 181 362 14 184 362 minecraft:honeycomb_block
setblock 17 181 323 minecraft:yellow_terracotta
setblock 17 181 363 minecraft:yellow_terracotta
setblock 18 181 323 minecraft:honey_block
fill 18 181 363 21 181 363 minecraft:honeycomb_block
setblock 22 181 362 minecraft:honeycomb_block
setblock 22 181 363 minecraft:yellow_terracotta
setblock 23 181 362 minecraft:yellow_terracotta
fill 23 181 363 23 184 363 minecraft:honeycomb_block
fill 24 181 362 24 184 362 minecraft:honeycomb_block
fill 25 181 361 28 181 361 minecraft:honeycomb_block
setblock 27 181 323 minecraft:yellow_terracotta
fill 27 181 360 29 181 360 minecraft:honeycomb_block
setblock 27 181 363 minecraft:yellow_terracotta
fill 28 181 323 28 184 323 minecraft:honeycomb_block
setblock 28 181 357 minecraft:brown_terracotta
setblock 28 181 359 minecraft:brown_terracotta
setblock 28 181 362 minecraft:yellow_terracotta
fill 28 181 363 28 184 363 minecraft:honeycomb_block
setblock 29 181 361 minecraft:yellow_terracotta
fill 29 181 362 29 184 362 minecraft:honeycomb_block
setblock 30 181 357 minecraft:brown_terracotta
setblock 30 181 359 minecraft:brown_terracotta
setblock 30 181 360 minecraft:yellow_terracotta
fill 30 181 361 30 184 361 minecraft:honeycomb_block
fill 31 181 322 31 216 322 minecraft:honeycomb_block
fill 31 181 360 31 182 360 minecraft:honeycomb_block
setblock 32 181 363 minecraft:yellow_terracotta
setblock 33 181 362 minecraft:yellow_terracotta
fill 33 181 363 33 184 363 minecraft:honeycomb_block
fill 34 181 362 34 182 362 minecraft:honeycomb_block
setblock 37 181 323 minecraft:honey_block
setblock 40 181 334 minecraft:honeycomb_block
setblock 40 181 335 minecraft:yellow_terracotta
fill 40 181 336 40 183 336 minecraft:honeycomb_block
setblock 40 181 355 minecraft:yellow_terracotta
setblock 40 181 356 minecraft:honeycomb_block
setblock 41 181 334 minecraft:yellow_terracotta
fill 41 181 335 41 184 335 minecraft:honeycomb_block
setblock 41 181 339 minecraft:yellow_terracotta
fill 41 181 340 41 184 340 minecraft:honeycomb_block
setblock 41 181 344 minecraft:honey_block
setblock 41 181 349 minecraft:yellow_terracotta
setblock 41 181 350 minecraft:honeycomb_block
setblock 41 181 354 minecraft:yellow_terracotta
fill 41 181 355 41 183 355 minecraft:honeycomb_block
setblock 41 181 359 minecraft:yellow_terracotta
setblock 42 181 331 minecraft:yellow_terracotta
fill 42 181 333 42 289 333 minecraft:honeycomb_block
fill 42 181 337 42 218 337 minecraft:honeycomb_block
setblock 0 182 332 minecraft:yellow_terracotta
fill 0 182 354 0 204 354 minecraft:honeycomb_block
setblock 1 182 329 minecraft:honeycomb_block
setblock 1 182 333 minecraft:yellow_terracotta
fill 1 182 334 1 185 334 minecraft:honeycomb_block
setblock 1 182 338 minecraft:yellow_terracotta
fill 1 182 339 1 185 339 minecraft:honeycomb_block
setblock 1 182 348 minecraft:honey_block
setblock 2 182 332 minecraft:yellow_terracotta
fill 2 182 333 2 185 333 minecraft:honeycomb_block
setblock 2 182 336 minecraft:honeycomb_block
setblock 2 182 337 minecraft:yellow_terracotta
fill 2 182 338 2 185 338 minecraft:honeycomb_block
fill 2 182 340 2 183 340 minecraft:honeycomb_block
setblock 3 182 322 minecraft:yellow_concrete
setblock 3 182 336 minecraft:yellow_terracotta
fill 3 182 337 3 185 337 minecraft:honeycomb_block
fill 4 182 323 4 183 323 minecraft:honeycomb_block
setblock 5 182 363 minecraft:honeycomb_block
setblock 6 182 323 minecraft:yellow_terracotta
setblock 6 182 363 minecraft:yellow_terracotta
fill 7 182 323 7 185 323 minecraft:honeycomb_block
setblock 7 182 362 minecraft:yellow_terracotta
fill 7 182 363 7 185 363 minecraft:honeycomb_block
fill 8 182 362 8 185 362 minecraft:honeycomb_block
setblock 10 182 324 minecraft:yellow_terracotta
setblock 11 182 323 minecraft:yellow_terracotta
fill 11 182 324 11 185 324 minecraft:honeycomb_block
setblock 11 182 363 minecraft:yellow_terracotta
fill 12 182 323 12 185 323 minecraft:honeycomb_block
setblock 12 182 362 minecraft:yellow_terracotta
fill 12 182 363 12 185 363 minecraft:honeycomb_block
fill 13 182 362 13 185 362 minecraft:honeycomb_block
setblock 16 182 323 minecraft:yellow_terracotta
setblock 16 182 363 minecraft:yellow_terracotta
fill 17 182 363 20 182 363 minecraft:honeycomb_block
setblock 21 182 363 minecraft:yellow_terracotta
setblock 22 182 362 minecraft:yellow_terracotta
fill 22 182 363 22 185 363 minecraft:honeycomb_block
fill 23 182 362 23 185 362 minecraft:honeycomb_block
fill 24 182 361 27 182 361 minecraft:honeycomb_block
setblock 26 182 323 minecraft:yellow_terracotta
setblock 26 182 363 minecraft:yellow_terracotta
fill 27 182 323 27 185 323 minecraft:honeycomb_block
fill 27 182 360 28 182 360 minecraft:honeycomb_block
setblock 27 182 362 minecraft:yellow_terracotta
fill 27 182 363 27 185 363 minecraft:honeycomb_block
setblock 28 182 322 minecraft:orange_terracotta
setblock 28 182 361 minecraft:yellow_terracotta
fill 28 182 362 28 185 362 minecraft:honeycomb_block
setblock 29 182 360 minecraft:yellow_terracotta
fill 29 182 361 29 185 361 minecraft:honeycomb_block
fill 30 182 360 30 183 360 minecraft:honeycomb_block
setblock 31 182 323 minecraft:honey_block
setblock 31 182 363 minecraft:yellow_terracotta
fill 31 182 364 31 255 364 minecraft:honeycomb_block
setblock 32 182 362 minecraft:yellow_terracotta
fill 32 182 363 32 185 363 minecraft:honeycomb_block
setblock 33 182 361 minecraft:yellow_terracotta
fill 33 182 362 33 184 362 minecraft:honeycomb_block
setblock 40 182 335 minecraft:honeycomb_block
setblock 40 182 339 minecraft:yellow_terracotta
setblock 41 182 333 minecraft:yellow_terracotta
fill 41 182 334 41 185 334 minecraft:honeycomb_block
setblock 41 182 338 minecraft:yellow_terracotta
fill 41 182 339 41 185 339 minecraft:honeycomb_block
setblock 41 182 343 minecraft:yellow_terracotta
setblock 41 182 353 minecraft:yellow_terracotta
fill 41 182 354 41 183 354 minecraft:honeycomb_block
setblock 41 182 358 minecraft:yellow_terracotta
setblock 41 182 359 minecraft:honeycomb_block
fill 42 182 331 42 308 331 minecraft:honeycomb_block
setblock 42 182 334 minecraft:yellow_concrete
fill 0 183 332 0 243 332 minecraft:honeycomb_block
setblock 1 183 332 minecraft:yellow_terracotta
fill 1 183 333 1 186 333 minecraft:honeycomb_block
setblock 1 183 337 minecraft:yellow_terracotta
fill 1 183 338 1 186 338 minecraft:honeycomb_block
setblock 1 183 342 minecraft:yellow_terracotta
setblock 1 183 354 minecraft:honey_block
fill 2 183 332 2 184 332 minecraft:honeycomb_block
setblock 2 183 336 minecraft:yellow_terracotta
fill 2 183 337 2 186 337 minecraft:honeycomb_block
setblock 3 183 322 minecraft:orange_terracotta
setblock 3 183 325 minecraft:light[level=15]
setblock 3 183 332 minecraft:light[level=12]
setblock 3 183 333 minecraft:light[level=15]
setblock 3 183 335 minecraft:yellow_terracotta
fill 3 183 336 3 185 336 minecraft:honeycomb_block
setblock 3 183 339 minecraft:light[level=12]
setblock 3 183 341 minecraft:light[level=15]
setblock 3 183 346 minecraft:light[level=12]
setblock 3 183 349 minecraft:light[level=15]
setblock 3 183 353 minecraft:light[level=12]
setblock 3 183 357 minecraft:light[level=15]
setblock 3 183 360 minecraft:light[level=12]
setblock 4 183 363 minecraft:honeycomb_block
setblock 5 183 323 minecraft:yellow_terracotta
setblock 5 183 363 minecraft:yellow_terracotta
fill 6 183 323 6 185 324 minecraft:honeycomb_block
setblock 6 183 362 minecraft:yellow_terracotta
fill 6 183 363 6 186 363 minecraft:honeycomb_block
fill 7 183 362 7 186 362 minecraft:honeycomb_block
fill 8 183 349 8 184 349 minecraft:black_concrete
setblock 9 183 324 minecraft:yellow_terracotta
fill 9 183 361 9 185 361 minecraft:honeycomb_block
setblock 10 183 323 minecraft:yellow_terracotta
fill 10 183 324 10 186 324 minecraft:honeycomb_block
setblock 10 183 325 minecraft:light[level=12]
setblock 10 183 332 minecraft:light[level=12]
setblock 10 183 339 minecraft:light[level=12]
setblock 10 183 346 minecraft:light[level=12]
setblock 10 183 353 minecraft:light[level=12]
setblock 10 183 360 minecraft:light[level=12]
setblock 10 183 363 minecraft:yellow_terracotta
fill 11 183 323 11 186 323 minecraft:honeycomb_block
setblock 11 183 325 minecraft:light[level=15]
setblock 11 183 333 minecraft:light[level=15]
setblock 11 183 341 minecraft:light[level=15]
setblock 11 183 349 minecraft:light[level=15]
setblock 11 183 357 minecraft:light[level=15]
setblock 11 183 362 minecraft:yellow_terracotta
fill 11 183 363 11 186 363 minecraft:honeycomb_block
fill 12 183 362 12 186 362 minecraft:honeycomb_block
setblock 15 183 323 minecraft:yellow_terracotta
setblock 15 183 363 minecraft:yellow_terracotta
setblock 16 183 362 minecraft:yellow_terracotta
fill 16 183 363 19 183 363 minecraft:honeycomb_block
setblock 17 183 325 minecraft:light[level=12]
setblock 17 183 332 minecraft:light[level=12]
setblock 17 183 339 minecraft:light[level=12]
setblock 17 183 346 minecraft:light[level=12]
setblock 17 183 353 minecraft:light[level=12]
setblock 17 183 360 minecraft:light[level=12]
setblock 19 183 325 minecraft:light[level=15]
setblock 19 183 333 minecraft:light[level=15]
setblock 19 183 341 minecraft:light[level=15]
setblock 19 183 349 minecraft:light[level=15]
setblock 19 183 357 minecraft:light[level=15]
setblock 20 183 363 minecraft:yellow_terracotta
setblock 21 183 362 minecraft:yellow_terracotta
fill 21 183 363 21 186 363 minecraft:honeycomb_block
fill 22 183 362 22 186 362 minecraft:honeycomb_block
setblock 24 183 325 minecraft:light[level=12]
setblock 24 183 332 minecraft:light[level=12]
setblock 24 183 339 minecraft:light[level=12]
setblock 24 183 346 minecraft:light[level=12]
setblock 24 183 353 minecraft:light[level=12]
setblock 24 183 360 minecraft:light[level=12]
fill 24 183 361 26 183 361 minecraft:honeycomb_block
setblock 25 183 323 minecraft:honey_block
setblock 25 183 363 minecraft:yellow_terracotta
fill 26 183 323 26 186 323 minecraft:honeycomb_block
fill 26 183 360 27 183 360 minecraft:honeycomb_block
setblock 26 183 362 minecraft:yellow_terracotta
fill 26 183 363 26 186 363 minecraft:honeycomb_block
setblock 27 183 325 minecraft:light[level=15]
setblock 27 183 333 minecraft:light[level=15]
setblock 27 183 341 minecraft:light[level=15]
setblock 27 183 349 minecraft:light[level=15]
setblock 27 183 357 minecraft:light[level=15]
setblock 27 183 361 minecraft:yellow_terracotta
fill 27 183 362 27 186 362 minecraft:honeycomb_block
fill 28 183 322 28 210 322 minecraft:honeycomb_block
setblock 28 183 360 minecraft:yellow_terracotta
fill 28 183 361 28 186 361 minecraft:honeycomb_block
fill 29 183 360 29 184 360 minecraft:honeycomb_block
setblock 30 183 363 minecraft:yellow_terracotta
setblock 31 183 325 minecraft:light[level=12]
setblock 31 183 332 minecraft:light[level=12]
setblock 31 183 339 minecraft:light[level=12]
setblock 31 183 346 minecraft:light[level=12]
setblock 31 183 353 minecraft:light[level=12]
setblock 31 183 360 minecraft:light[level=12]
setblock 31 183 362 minecraft:yellow_terracotta
fill 31 183 363 31 186 363 minecraft:honeycomb_block
setblock 32 183 361 minecraft:yellow_terracotta
fill 32 183 362 32 186 362 minecraft:honeycomb_block
setblock 35 183 325 minecraft:light[level=15]
setblock 35 183 333 minecraft:light[level=15]
setblock 35 183 341 minecraft:light[level=15]
setblock 35 183 349 minecraft:light[level=15]
setblock 35 183 357 minecraft:light[level=15]
setblock 36 183 363 minecraft:honey_block
setblock 38 183 325 minecraft:light[level=12]
setblock 38 183 332 minecraft:light[level=12]
setblock 38 183 339 minecraft:light[level=12]
setblock 38 183 346 minecraft:light[level=12]
setblock 38 183 353 minecraft:light[level=12]
setblock 38 183 360 minecraft:light[level=12]
setblock 40 183 337 minecraft:honeycomb_block
setblock 40 183 338 minecraft:yellow_terracotta
fill 40 183 339 40 186 339 minecraft:honeycomb_block
setblock 40 183 364 minecraft:yellow_terracotta
setblock 41 183 332 minecraft:yellow_terracotta
fill 41 183 333 41 186 333 minecraft:honeycomb_block
setblock 41 183 337 minecraft:yellow_terracotta
fill 41 183 338 41 186 338 minecraft:honeycomb_block
setblock 41 183 342 minecraft:yellow_terracotta
fill 41 183 343 41 186 343 minecraft:honeycomb_block
setblock 41 183 351 minecraft:honey_block
setblock 41 183 357 minecraft:yellow_terracotta
setblock 41 183 358 minecraft:honeycomb_block
fill 42 183 334 42 206 334 minecraft:honeycomb_block
setblock 42 183 353 minecraft:yellow_terracotta
fill 0 184 331 0 307 331 minecraft:honeycomb_block
setblock 1 184 331 minecraft:yellow_terracotta
fill 1 184 332 1 187 332 minecraft:honeycomb_block
setblock 1 184 336 minecraft:yellow_terracotta
fill 1 184 337 1 187 337 minecraft:honeycomb_block
setblock 1 184 341 minecraft:yellow_terracotta
fill 1 184 342 1 187 342 minecraft:honeycomb_block
setblock 1 184 360 minecraft:honey_block
setblock 2 184 335 minecraft:yellow_terracotta
fill 2 184 336 2 187 336 minecraft:honeycomb_block
setblock 2 184 340 minecraft:yellow_terracotta
fill 3 184 322 3 307 322 minecraft:honeycomb_block
setblock 3 184 335 minecraft:honeycomb_block
setblock 4 184 323 minecraft:yellow_terracotta
setblock 4 184 363 minecraft:yellow_terracotta
fill 5 184 323 5 187 323 minecraft:honeycomb_block
fill 5 184 363 5 187 363 minecraft:honeycomb_block
fill 6 184 362 6 187 362 minecraft:honeycomb_block
setblock 8 184 324 minecraft:yellow_terracotta
setblock 9 184 323 minecraft:yellow_terracotta
fill 9 184 324 9 187 324 minecraft:honeycomb_block
setblock 9 184 363 minecraft:yellow_terracotta
fill 10 184 323 10 187 323 minecraft:honeycomb_block
setblock 10 184 361 minecraft:honeycomb_block
setblock 10 184 362 minecraft:yellow_terracotta
fill 10 184 363 10 187 363 minecraft:honeycomb_block
fill 11 184 362 11 187 362 minecraft:honeycomb_block
setblock 14 184 323 minecraft:yellow_terracotta
setblock 14 184 363 minecraft:yellow_terracotta
setblock 15 184 323 minecraft:honeycomb_block
setblock 15 184 362 minecraft:yellow_terracotta
fill 15 184 363 18 184 363 minecraft:honeycomb_block
setblock 19 184 323 minecraft:honey_block
setblock 19 184 363 minecraft:yellow_terracotta
fill 20 184 363 20 187 363 minecraft:honeycomb_block
fill 21 184 362 21 187 362 minecraft:honeycomb_block
fill 23 184 361 25 184 361 minecraft:honeycomb_block
setblock 24 184 363 minecraft:yellow_terracotta
setblock 25 184 362 minecraft:yellow_terracotta
fill 25 184 363 25 187 363 minecraft:honeycomb_block
setblock 26 184 360 minecraft:honeycomb_block
setblock 26 184 361 minecraft:yellow_terracotta
fill 26 184 362 26 187 362 minecraft:honeycomb_block
setblock 27 184 360 minecraft:yellow_terracotta
fill 27 184 361 27 187 361 minecraft:honeycomb_block
fill 28 184 360 28 185 360 minecraft:honeycomb_block
setblock 29 184 363 minecraft:yellow_terracotta
setblock 30 184 362 minecraft:yellow_terracotta
fill 30 184 363 30 187 363 minecraft:honeycomb_block
setblock 31 184 361 minecraft:yellow_terracotta
fill 31 184 362 31 187 362 minecraft:honeycomb_block
setblock 33 184 364 minecraft:yellow_terracotta
setblock 34 184 363 minecraft:yellow_terracotta
fill 38 184 323 38 185 323 minecraft:honey_block
setblock 40 184 337 minecraft:yellow_terracotta
fill 40 184 338 40 187 338 minecraft:honeycomb_block
fill 40 184 364 40 210 364 minecraft:honeycomb_block
setblock 41 184 326 minecraft:honey_block
setblock 41 184 336 minecraft:yellow_terracotta
fill 41 184 337 41 187 337 minecraft:honeycomb_block
setblock 41 184 341 minecraft:yellow_terracotta
fill 41 184 342 41 187 342 minecraft:honeycomb_block
setblock 41 184 345 minecraft:honey_block
setblock 42 184 343 minecraft:orange_terracotta
fill 42 184 353 42 308 353 minecraft:honeycomb_block
setblock 42 184 355 minecraft:yellow_terracotta
fill 1 185 331 1 188 331 minecraft:honeycomb_block
setblock 1 185 335 minecraft:yellow_terracotta
fill 1 185 336 1 188 336 minecraft:honeycomb_block
setblock 1 185 340 minecraft:yellow_terracotta
fill 1 185 341 1 188 341 minecraft:honeycomb_block
setblock 1 185 347 minecraft:honey_block
setblock 2 185 334 minecraft:yellow_terracotta
fill 2 185 335 2 188 335 minecraft:honeycomb_block
setblock 2 185 339 minecraft:yellow_terracotta
fill 2 185 340 2 188 340 minecraft:honeycomb_block
setblock 3 185 323 minecraft:yellow_terracotta
setblock 3 185 363 minecraft:yellow_terracotta
fill 4 185 323 4 188 323 minecraft:honeycomb_block
fill 4 185 363 4 188 363 minecraft:honeycomb_block
fill 5 185 362 5 188 362 minecraft:honeycomb_block
setblock 7 185 324 minecraft:yellow_terracotta
setblock 8 185 323 minecraft:yellow_terracotta
fill 8 185 324 8 188 324 minecraft:honeycomb_block
fill 8 185 361 8 186 361 minecraft:honeycomb_block
setblock 8 185 363 minecraft:yellow_terracotta
fill 9 185 323 9 188 323 minecraft:honeycomb_block
setblock 9 185 362 minecraft:yellow_terracotta
fill 9 185 363 9 188 363 minecraft:honeycomb_block
setblock 10 185 361 minecraft:yellow_terracotta
fill 10 185 362 10 188 362 minecraft:honeycomb_block
setblock 13 185 323 minecraft:yellow_terracotta
setblock 13 185 363 minecraft:yellow_terracotta
fill 14 185 323 14 188 323 minecraft:honeycomb_block
setblock 14 185 362 minecraft:yellow_terracotta
fill 14 185 363 17 185 363 minecraft:honeycomb_block
fill 15 185 362 15 188 362 minecraft:honeycomb_block
setblock 18 185 363 minecraft:yellow_terracotta
fill 19 185 363 19 188 363 minecraft:honeycomb_block
fill 20 185 362 20 188 362 minecraft:honeycomb_block
fill 23 185 361 24 185 361 minecraft:honeycomb_block
setblock 23 185 363 minecraft:yellow_terracotta
setblock 24 185 362 minecraft:yellow_terracotta
fill 24 185 363 24 188 363 minecraft:honeycomb_block
setblock 25 185 322 minecraft:yellow_concrete
fill 25 185 323 25 187 323 minecraft:honeycomb_block
setblock 25 185 361 minecraft:yellow_terracotta
fill 25 185 362 25 188 362 minecraft:honeycomb_block
setblock 26 185 360 minecraft:yellow_terracotta
fill 26 185 361 26 188 361 minecraft:honeycomb_block
fill 27 185 360 27 187 360 minecraft:honeycomb_block
setblock 28 185 323 minecraft:yellow_terracotta
setblock 28 185 363 minecraft:yellow_terracotta
setblock 29 185 362 minecraft:yellow_terracotta
fill 29 185 363 29 188 363 minecraft:honeycomb_block
setblock 30 185 361 minecraft:yellow_terracotta
fill 30 185 362 30 188 362 minecraft:honeycomb_block
setblock 31 185 361 minecraft:honeycomb_block
setblock 32 185 323 minecraft:honey_block
setblock 33 185 363 minecraft:yellow_terracotta
fill 33 185 364 33 200 364 minecraft:honeycomb_block
fill 40 185 337 40 188 337 minecraft:honeycomb_block
setblock 40 185 340 minecraft:honeycomb_block
setblock 41 185 335 minecraft:yellow_terracotta
fill 41 185 336 41 188 336 minecraft:honeycomb_block
setblock 41 185 340 minecraft:yellow_terracotta
fill 41 185 341 41 188 341 minecraft:honeycomb_block
setblock 41 185 344 minecraft:honeycomb_block
fill 41 185 358 41 186 358 minecraft:honey_block
fill 42 185 343 42 220 343 minecraft:honeycomb_block
fill 42 185 355 42 308 355 minecraft:honeycomb_block
setblock 1 186 328 minecraft:honey_block
setblock 1 186 334 minecraft:yellow_terracotta
fill 1 186 335 1 189 335 minecraft:honeycomb_block
setblock 1 186 339 minecraft:yellow_terracotta
fill 1 186 340 1 189 340 minecraft:honeycomb_block
setblock 1 186 343 minecraft:honeycomb_block
setblock 1 186 353 minecraft:honey_block
setblock 2 186 323 minecraft:yellow_terracotta
setblock 2 186 333 minecraft:yellow_terracotta
fill 2 186 334 2 189 334 minecraft:honeycomb_block
setblock 2 186 338 minecraft:yellow_terracotta
fill 2 186 339 2 189 339 minecraft:honeycomb_block
fill 2 186 341 2 187 341 minecraft:honeycomb_block
setblock 2 186 363 minecraft:yellow_terracotta
fill 3 186 323 3 189 323 minecraft:honeycomb_block
setblock 3 186 337 minecraft:yellow_terracotta
fill 3 186 338 3 189 338 minecraft:honeycomb_block
fill 3 186 363 3 189 363 minecraft:honeycomb_block
fill 4 186 362 4 189 362 minecraft:honeycomb_block
setblock 5 186 324 minecraft:honeycomb_block
setblock 6 186 323 minecraft:honeycomb_block
setblock 6 186 324 minecraft:yellow_terracotta
setblock 7 186 323 minecraft:yellow_terracotta
fill 7 186 324 7 189 324 minecraft:honeycomb_block
fill 7 186 361 7 187 361 minecraft:honeycomb_block
setblock 7 186 363 minecraft:yellow_terracotta
fill 8 186 323 8 189 323 minecraft:honeycomb_block
setblock 8 186 362 minecraft:yellow_terracotta
fill 8 186 363 8 189 363 minecraft:honeycomb_block
setblock 9 186 361 minecraft:yellow_terracotta
fill 9 186 362 9 189 362 minecraft:honeycomb_block
fill 10 186 361 10 189 361 minecraft:honeycomb_block
setblock 12 186 323 minecraft:yellow_terracotta
setblock 12 186 363 minecraft:yellow_terracotta
fill 13 186 323 13 189 323 minecraft:honeycomb_block
setblock 13 186 362 minecraft:yellow_terracotta
fill 13 186 363 16 186 363 minecraft:honeycomb_block
fill 14 186 362 14 189 362 minecraft:honeycomb_block
setblock 17 186 363 minecraft:yellow_terracotta
fill 18 186 363 18 189 363 minecraft:honeycomb_block
fill 19 186 362 19 189 362 minecraft:honeycomb_block
fill 22 186 361 23 186 361 minecraft:honeycomb_block
setblock 22 186 363 minecraft:yellow_terracotta
setblock 23 186 362 minecraft:yellow_terracotta
fill 23 186 363 23 189 363 minecraft:honeycomb_block
fill 24 186 323 24 188 323 minecraft:honeycomb_block
setblock 24 186 361 minecraft:yellow_terracotta
fill 24 186 362 24 189 362 minecraft:honeycomb_block
fill 25 186 322 25 231 322 minecraft:honeycomb_block
fill 25 186 361 25 189 361 minecraft:honeycomb_block
fill 26 186 360 26 189 360 minecraft:honeycomb_block
setblock 27 186 323 minecraft:yellow_terracotta
setblock 27 186 363 minecraft:yellow_terracotta
fill 28 186 323 28 189 323 minecraft:honeycomb_block
setblock 28 186 362 minecraft:yellow_terracotta
fill 28 186 363 28 189 363 minecraft:honeycomb_block
setblock 29 186 361 minecraft:yellow_terracotta
fill 29 186 362 29 189 362 minecraft:honeycomb_block
fill 30 186 361 30 187 361 minecraft:honeycomb_block
setblock 32 186 363 minecraft:yellow_terracotta
fill 33 186 363 33 189 363 minecraft:honeycomb_block
setblock 35 186 363 minecraft:honey_block
setblock 40 186 340 minecraft:yellow_terracotta
fill 40 186 341 40 189 341 minecraft:honeycomb_block
setblock 41 186 334 minecraft:yellow_terracotta
fill 41 186 335 41 189 335 minecraft:honeycomb_block
setblock 41 186 339 minecraft:yellow_terracotta
fill 41 186 340 41 189 340 minecraft:honeycomb_block
setblock 41 186 344 minecraft:yellow_terracotta
fill 41 186 345 41 189 345 minecraft:honeycomb_block
setblock 41 186 352 minecraft:honey_block
setblock 42 186 327 minecraft:orange_terracotta
setblock 0 187 357 minecraft:yellow_terracotta
setblock 1 187 323 minecraft:yellow_terracotta
fill 1 187 324 1 189 325 minecraft:honeycomb_block
fill 1 187 330 1 189 330 minecraft:honeycomb_block
setblock 1 187 333 minecraft:yellow_terracotta
fill 1 187 334 1 190 334 minecraft:honeycomb_block
setblock 1 187 338 minecraft:yellow_terracotta
fill 1 187 339 1 190 339 minecraft:honeycomb_block
setblock 1 187 343 minecraft:yellow_terracotta
fill 1 187 344 1 190 344 minecraft:honeycomb_block
setblock 1 187 359 minecraft:honey_block
fill 1 187 360 1 187 362 minecraft:honeycomb_block
setblock 1 187 363 minecraft:yellow_terracotta
fill 2 187 323 2 190 323 minecraft:honeycomb_block
fill 2 187 333 2 190 333 minecraft:honeycomb_block
setblock 2 187 337 minecraft:yellow_terracotta
fill 2 187 338 2 190 338 minecraft:honeycomb_block
setblock 2 187 342 minecraft:yellow_terracotta
fill 2 187 363 2 190 363 minecraft:honeycomb_block
fill 3 187 324 4 187 324 minecraft:honeycomb_block
fill 3 187 337 3 190 337 minecraft:honeycomb_block
fill 3 187 339 3 188 339 minecraft:honeycomb_block
fill 3 187 362 3 190 362 minecraft:honeycomb_block
setblock 5 187 324 minecraft:yellow_terracotta
setblock 6 187 323 minecraft:yellow_terracotta
fill 6 187 324 6 190 324 minecraft:honeycomb_block
fill 6 187 361 6 188 361 minecraft:honeycomb_block
setblock 6 187 363 minecraft:yellow_terracotta
fill 7 187 323 7 190 323 minecraft:honeycomb_block
setblock 7 187 362 minecraft:yellow_terracotta
fill 7 187 363 7 190 363 minecraft:honeycomb_block
setblock 8 187 361 minecraft:yellow_terracotta
fill 8 187 362 8 190 362 minecraft:honeycomb_block
fill 9 187 361 9 190 361 minecraft:honeycomb_block
setblock 10 187 324 minecraft:yellow_terracotta
setblock 11 187 323 minecraft:yellow_terracotta
fill 11 187 324 11 190 324 minecraft:honeycomb_block
setblock 11 187 363 minecraft:yellow_terracotta
fill 12 187 323 12 190 323 minecraft:honeycomb_block
setblock 12 187 362 minecraft:yellow_terracotta
fill 12 187 363 15 187 363 minecraft:honeycomb_block
fill 13 187 362 13 190 362 minecraft:honeycomb_block
setblock 16 187 362 minecraft:honeycomb_block
setblock 16 187 363 minecraft:yellow_terracotta
setblock 17 187 362 minecraft:yellow_terracotta
fill 17 187 363 17 190 363 minecraft:honeycomb_block
fill 18 187 362 18 190 362 minecraft:honeycomb_block
setblock 20 187 323 minecraft:honey_block
fill 21 187 361 22 187 361 minecraft:honeycomb_block
setblock 21 187 363 minecraft:yellow_terracotta
fill 22 187 323 23 189 323 minecraft:honeycomb_block
setblock 22 187 362 minecraft:yellow_terracotta
fill 22 187 363 22 190 363 minecraft:honeycomb_block
setblock 23 187 361 minecraft:yellow_terracotta
fill 23 187 362 23 190 362 minecraft:honeycomb_block
fill 24 187 361 24 190 361 minecraft:honeycomb_block
fill 25 187 360 25 190 360 minecraft:honeycomb_block
setblock 26 187 323 minecraft:yellow_terracotta
setblock 26 187 363 minecraft:yellow_terracotta
fill 27 187 323 27 190 323 minecraft:honeycomb_block
setblock 27 187 362 minecraft:yellow_terracotta
fill 27 187 363 27 190 363 minecraft:honeycomb_block
setblock 28 187 361 minecraft:yellow_terracotta
fill 28 187 362 28 190 362 minecraft:honeycomb_block
fill 29 187 323 29 188 323 minecraft:honeycomb_block
fill 29 187 361 29 190 361 minecraft:honeycomb_block
setblock 31 187 363 minecraft:yellow_terracotta
fill 32 187 363 32 190 363 minecraft:honeycomb_block
setblock 39 187 322 minecraft:yellow_concrete
setblock 40 187 339 minecraft:yellow_terracotta
fill 40 187 340 40 190 340 minecraft:honeycomb_block
fill 40 187 342 40 188 342 minecraft:honeycomb_block
setblock 41 187 327 minecraft:honey_block
setblock 41 187 333 minecraft:yellow_terracotta
fill 41 187 334 41 190 334 minecraft:honeycomb_block
setblock 41 187 338 minecraft:yellow_terracotta
fill 41 187 339 41 190 339 minecraft:honeycomb_block
setblock 41 187 343 minecraft:yellow_terracotta
fill 41 187 344 41 190 344 minecraft:honeycomb_block
fill 41 187 346 41 188 346 minecraft:honeycomb_block
setblock 41 187 363 minecraft:honey_block
fill 42 187 327 42 224 327 minecraft:honeycomb_block
fill 0 188 357 0 234 357 minecraft:honeycomb_block
fill 1 188 323 1 191 323 minecraft:honeycomb_block
setblock 1 188 326 minecraft:honeycomb_block
setblock 1 188 327 minecraft:yellow_terracotta
fill 1 188 328 1 190 329 minecraft:honeycomb_block
setblock 1 188 332 minecraft:yellow_terracotta
fill 1 188 333 1 191 333 minecraft:honeycomb_block
setblock 1 188 337 minecraft:yellow_terracotta
fill 1 188 338 1 191 338 minecraft:honeycomb_block
setblock 1 188 342 minecraft:yellow_terracotta
fill 1 188 343 2 190 343 minecraft:honeycomb_block
fill 1 188 345 1 189 345 minecraft:honeycomb_block
setblock 1 188 346 minecraft:honey_block
fill 1 188 359 1 188 361 minecraft:honeycomb_block
setblock 1 188 362 minecraft:yellow_terracotta
fill 1 188 363 1 191 363 minecraft:honeycomb_block
fill 2 188 324 2 188 325 minecraft:honeycomb_block
setblock 2 188 336 minecraft:yellow_terracotta
fill 2 188 337 2 191 337 minecraft:honeycomb_block
setblock 2 188 341 minecraft:yellow_terracotta
fill 2 188 342 2 191 342 minecraft:honeycomb_block
fill 2 188 362 2 191 362 minecraft:honeycomb_block
setblock 3 188 324 minecraft:honeycomb_block
setblock 3 188 340 minecraft:yellow_terracotta
setblock 4 188 324 minecraft:yellow_terracotta
setblock 5 188 323 minecraft:yellow_terracotta
fill 5 188 324 5 191 324 minecraft:honeycomb_block
fill 5 188 361 5 189 361 minecraft:honeycomb_block
setblock 5 188 363 minecraft:yellow_terracotta
fill 6 188 323 6 191 323 minecraft:honeycomb_block
fill 6 188 325 6 189 325 minecraft:honeycomb_block
setblock 6 188 362 minecraft:yellow_terracotta
fill 6 188 363 6 191 363 minecraft:honeycomb_block
setblock 7 188 361 minecraft:yellow_terracotta
fill 7 188 362 7 191 362 minecraft:honeycomb_block
fill 8 188 361 8 191 361 minecraft:honeycomb_block
setblock 9 188 324 minecraft:yellow_terracotta
setblock 10 188 323 minecraft:yellow_terracotta
fill 10 188 324 10 191 324 minecraft:honeycomb_block
setblock 10 188 363 minecraft:yellow_terracotta
fill 11 188 323 11 191 323 minecraft:honeycomb_block
setblock 11 188 362 minecraft:yellow_terracotta
fill 11 188 363 14 188 363 minecraft:honeycomb_block
fill 12 188 362 12 191 362 minecraft:honeycomb_block
setblock 15 188 323 minecraft:yellow_terracotta
setblock 15 188 363 minecraft:yellow_terracotta
fill 16 188 323 16 191 323 minecraft:honeycomb_block
setblock 16 188 362 minecraft:yellow_terracotta
fill 16 188 363 16 191 363 minecraft:honeycomb_block
fill 17 188 362 17 191 362 minecraft:honeycomb_block
setblock 19 188 323 minecraft:honeycomb_block
setblock 20 188 323 minecraft:yellow_terracotta
setblock 20 188 363 minecraft:yellow_terracotta
fill 21 188 323 21 191 323 minecraft:honeycomb_block
setblock 21 188 361 minecraft:honeycomb_block
setblock 21 188 362 minecraft:yellow_terracotta
fill 21 188 363 21 191 363 minecraft:honeycomb_block
setblock 22 188 361 minecraft:yellow_terracotta
fill 22 188 362 22 191 362 minecraft:honeycomb_block
fill 23 188 361 23 191 361 minecraft:honeycomb_block
fill 24 188 360 24 191 360 minecraft:honeycomb_block
setblock 25 188 323 minecraft:yellow_terracotta
setblock 25 188 363 minecraft:yellow_terracotta
fill 26 188 323 26 191 323 minecraft:honeycomb_block
fill 26 188 327 26 193 327 minecraft:brown_terracotta
setblock 26 188 362 minecraft:yellow_terracotta
fill 26 188 363 26 191 363 minecraft:honeycomb_block
setblock 27 188 361 minecraft:yellow_terracotta
fill 27 188 362 27 191 362 minecraft:honeycomb_block
fill 28 188 361 28 191 361 minecraft:honeycomb_block
fill 30 188 342 32 189 342 minecraft:honey_block
setblock 30 188 363 minecraft:yellow_terracotta
fill 31 188 341 31 189 341 minecraft:honey_block
fill 31 188 343 31 189 343 minecraft:honey_block
setblock 31 188 362 minecraft:yellow_terracotta
fill 31 188 363 31 191 363 minecraft:honeycomb_block
fill 39 188 322 39 307 322 minecraft:honeycomb_block
setblock 39 188 323 minecraft:honey_block
fill 40 188 336 40 189 336 minecraft:honeycomb_block
setblock 40 188 338 minecraft:yellow_terracotta
fill 40 188 339 40 191 339 minecraft:honeycomb_block
setblock 40 188 343 minecraft:yellow_terracotta
fill 40 188 344 40 191 344 minecraft:honeycomb_block
fill 41 188 333 41 191 333 minecraft:honeycomb_block
setblock 41 188 337 minecraft:yellow_terracotta
fill 41 188 338 41 191 338 minecraft:honeycomb_block
setblock 41 188 342 minecraft:yellow_terracotta
fill 41 188 343 41 191 343 minecraft:honeycomb_block
setblock 41 188 347 minecraft:yellow_terracotta
fill 41 188 360 41 188 361 minecraft:honeycomb_block
setblock 41 188 362 minecraft:yellow_terracotta
setblock 42 188 336 minecraft:yellow_concrete
setblock 1 189 326 minecraft:yellow_terracotta
fill 1 189 327 2 191 327 minecraft:honeycomb_block
setblock 1 189 331 minecraft:yellow_terracotta
fill 1 189 332 2 191 332 minecraft:honeycomb_block
setblock 1 189 336 minecraft:yellow_terracotta
fill 1 189 337 1 192 337 minecraft:honeycomb_block
setblock 1 189 341 minecraft:yellow_terracotta
fill 1 189 342 1 192 342 minecraft:honeycomb_block
setblock 1 189 346 minecraft:yellow_terracotta
setblock 1 189 352 minecraft:honey_block
fill 1 189 358 1 189 360 minecraft:honeycomb_block
setblock 1 189 361 minecraft:yellow_terracotta
fill 1 189 362 1 192 362 minecraft:honeycomb_block
setblock 2 189 324 minecraft:honeycomb_block
setblock 2 189 325 minecraft:yellow_terracotta
fill 2 189 326 2 192 326 minecraft:honeycomb_block
fill 2 189 328 2 190 328 minecraft:honeycomb_block
setblock 2 189 335 minecraft:yellow_terracotta
fill 2 189 336 3 191 336 minecraft:honeycomb_block
setblock 2 189 340 minecraft:yellow_terracotta
fill 2 189 341 3 191 341 minecraft:honeycomb_block
setblock 2 189 344 minecraft:honeycomb_block
setblock 2 189 360 minecraft:yellow_terracotta
fill 2 189 361 2 192 361 minecraft:honeycomb_block
setblock 3 189 324 minecraft:yellow_terracotta
fill 3 189 325 5 190 325 minecraft:honeycomb_block
setblock 3 189 332 minecraft:light[level=12]
setblock 3 189 339 minecraft:yellow_terracotta
fill 3 189 340 3 192 340 minecraft:honeycomb_block
setblock 3 189 346 minecraft:light[level=12]
setblock 3 189 353 minecraft:light[level=12]
setblock 3 189 360 minecraft:light[level=12]
setblock 4 189 323 minecraft:yellow_terracotta
fill 4 189 324 4 192 324 minecraft:honeycomb_block
fill 4 189 361 4 190 361 minecraft:honeycomb_block
setblock 4 189 363 minecraft:yellow_terracotta
fill 5 189 323 5 192 323 minecraft:honeycomb_block
setblock 5 189 362 minecraft:yellow_terracotta
fill 5 189 363 5 192 363 minecraft:honeycomb_block
setblock 6 189 361 minecraft:yellow_terracotta
fill 6 189 362 6 192 362 minecraft:honeycomb_block
setblock 7 189 325 minecraft:yellow_terracotta
fill 7 189 361 7 192 361 minecraft:honeycomb_block
setblock 8 189 324 minecraft:yellow_terracotta
fill 8 189 325 8 192 325 minecraft:honeycomb_block
setblock 9 189 323 minecraft:yellow_terracotta
fill 9 189 324 9 192 324 minecraft:honeycomb_block
setblock 9 189 363 minecraft:yellow_terracotta
fill 10 189 323 10 192 323 minecraft:honeycomb_block
setblock 10 189 325 minecraft:light[level=12]
setblock 10 189 332 minecraft:light[level=12]
setblock 10 189 339 minecraft:light[level=12]
setblock 10 189 346 minecraft:light[level=12]
setblock 10 189 353 minecraft:light[level=12]
setblock 10 189 360 minecraft:light[level=12]
setblock 10 189 362 minecraft:yellow_terracotta
fill 10 189 363 13 189 363 minecraft:honeycomb_block
fill 11 189 362 11 192 362 minecraft:honeycomb_block
setblock 14 189 323 minecraft:yellow_terracotta
setblock 14 189 363 minecraft:yellow_terracotta
fill 15 189 323 15 192 323 minecraft:honeycomb_block
setblock 15 189 362 minecraft:yellow_terracotta
fill 15 189 363 15 192 363 minecraft:honeycomb_block
fill 16 189 362 16 192 362 minecraft:honeycomb_block
fill 17 189 323 18 189 323 minecraft:honeycomb_block
setblock 17 189 325 minecraft:light[level=12]
setblock 17 189 332 minecraft:light[level=12]
setblock 17 189 339 minecraft:light[level=12]
setblock 17 189 346 minecraft:light[level=12]
setblock 17 189 353 minecraft:light[level=12]
setblock 17 189 360 minecraft:light[level=12]
setblock 19 189 323 minecraft:yellow_terracotta
fill 19 189 361 20 189 361 minecraft:honeycomb_block
setblock 19 189 363 minecraft:yellow_terracotta
fill 20 189 323 20 192 323 minecraft:honeycomb_block
setblock 20 189 362 minecraft:yellow_terracotta
fill 20 189 363 20 192 363 minecraft:honeycomb_block
setblock 21 189 361 minecraft:yellow_terracotta
fill 21 189 362 21 192 362 minecraft:honeycomb_block
fill 22 189 361 22 192 361 minecraft:honeycomb_block
setblock 23 189 322 minecraft:orange_terracotta
fill 23 189 360 23 192 360 minecraft:honeycomb_block
setblock 24 189 323 minecraft:yellow_terracotta
setblock 24 189 325 minecraft:light[level=12]
setblock 24 189 332 minecraft:light[level=12]
setblock 24 189 339 minecraft:light[level=12]
setblock 24 189 346 minecraft:light[level=12]
setblock 24 189 353 minecraft:light[level=12]
setblock 24 189 363 minecraft:yellow_terracotta
fill 25 189 323 25 192 323 minecraft:honeycomb_block
setblock 25 189 362 minecraft:yellow_terracotta
fill 25 189 363 25 192 363 minecraft:honeycomb_block
setblock 26 189 361 minecraft:yellow_terracotta
fill 26 189 362 26 192 362 minecraft:honeycomb_block
fill 27 189 361 27 192 361 minecraft:honeycomb_block
setblock 29 189 323 minecraft:yellow_terracotta
setblock 29 189 363 minecraft:yellow_terracotta
fill 30 189 323 30 192 323 minecraft:honeycomb_block
setblock 30 189 362 minecraft:yellow_terracotta
fill 30 189 363 30 192 363 minecraft:honeycomb_block
setblock 31 189 325 minecraft:light[level=12]
setblock 31 189 332 minecraft:light[level=12]
setblock 31 189 339 minecraft:light[level=12]
setblock 31 189 346 minecraft:light[level=12]
setblock 31 189 353 minecraft:light[level=12]
setblock 31 189 360 minecraft:light[level=12]
fill 31 189 362 31 191 362 minecraft:honeycomb_block
setblock 33 189 323 minecraft:honey_block
setblock 34 189 363 minecraft:honey_block
setblock 38 189 325 minecraft:light[level=12]
setblock 38 189 332 minecraft:light[level=12]
setblock 38 189 339 minecraft:light[level=12]
setblock 38 189 346 minecraft:light[level=12]
setblock 38 189 353 minecraft:light[level=12]
setblock 38 189 360 minecraft:light[level=12]
fill 39 189 341 39 190 341 minecraft:honeycomb_block
setblock 40 189 337 minecraft:yellow_terracotta
fill 40 189 338 40 192 338 minecraft:honeycomb_block
setblock 40 189 342 minecraft:yellow_terracotta
fill 40 189 343 40 192 343 minecraft:honeycomb_block
fill 40 189 345 40 190 345 minecraft:honeycomb_block
fill 40 189 363 41 191 363 minecraft:honeycomb_block
fill 41 189 323 41 189 325 minecraft:honeycomb_block
setblock 41 189 331 minecraft:yellow_terracotta
fill 41 189 332 41 192 332 minecraft:honeycomb_block
setblock 41 189 336 minecraft:yellow_terracotta
fill 41 189 337 41 192 337 minecraft:honeycomb_block
setblock 41 189 341 minecraft:yellow_terracotta
fill 41 189 342 41 192 342 minecraft:honeycomb_block
setblock 41 189 346 minecraft:yellow_terracotta
fill 41 189 347 41 191 348 minecraft:honeycomb_block
fill 41 189 359 41 189 360 minecraft:honeycomb_block
setblock 41 189 361 minecraft:yellow_terracotta
fill 41 189 362 41 192 362 minecraft:honeycomb_block
fill 42 189 336 42 258 336 minecraft:honeycomb_block
setblock 0 190 352 minecraft:orange_terracotta
setblock 1 190 324 minecraft:honeycomb_block
setblock 1 190 325 minecraft:yellow_terracotta
fill 1 190 326 1 193 326 minecraft:honeycomb_block
setblock 1 190 330 minecraft:yellow_terracotta
fill 1 190 331 2 192 331 minecraft:honeycomb_block
setblock 1 190 335 minecraft:yellow_terracotta
fill 1 190 336 1 193 336 minecraft:honeycomb_block
setblock 1 190 340 minecraft:yellow_terracotta
fill 1 190 341 1 193 341 minecraft:honeycomb_block
setblock 1 190 345 minecraft:yellow_terracotta
fill 1 190 346 1 192 347 minecraft:honeycomb_block
fill 1 190 358 1 190 359 minecraft:honeycomb_block
setblock 1 190 360 minecraft:yellow_terracotta
fill 1 190 361 1 193 361 minecraft:honeycomb_block
setblock 1 190 364 minecraft:yellow_terracotta
setblock 2 190 324 minecraft:yellow_terracotta
fill 2 190 325 2 193 325 minecraft:honeycomb_block
setblock 2 190 329 minecraft:yellow_terracotta
fill 2 190 330 2 193 330 minecraft:honeycomb_block
setblock 2 190 334 minecraft:yellow_terracotta
fill 2 190 335 2 193 335 minecraft:honeycomb_block
setblock 2 190 339 minecraft:yellow_terracotta
fill 2 190 340 2 193 340 minecraft:honeycomb_block
setblock 2 190 344 minecraft:yellow_terracotta
fill 2 190 345 2 193 345 minecraft:honeycomb_block
setblock 2 190 359 minecraft:yellow_terracotta
fill 2 190 360 2 193 360 minecraft:honeycomb_block
fill 2 190 364 4 254 364 minecraft:honeycomb_block
setblock 3 190 323 minecraft:yellow_terracotta
fill 3 190 324 3 193 324 minecraft:honeycomb_block
fill 3 190 326 3 190 327 minecraft:honeycomb_block
setblock 3 190 338 minecraft:yellow_terracotta
fill 3 190 339 3 193 339 minecraft:honeycomb_block
setblock 3 190 342 minecraft:honeycomb_block
setblock 3 190 343 minecraft:yellow_terracotta
fill 3 190 361 3 191 361 minecraft:honeycomb_block
setblock 3 190 363 minecraft:yellow_terracotta
fill 4 190 323 4 193 323 minecraft:honeycomb_block
setblock 4 190 362 minecraft:yellow_terracotta
fill 4 190 363 4 193 363 minecraft:honeycomb_block
setblock 5 190 361 minecraft:yellow_terracotta
fill 5 190 362 5 193 362 minecraft:honeycomb_block
setblock 6 190 325 minecraft:yellow_terracotta
fill 6 190 361 6 193 361 minecraft:honeycomb_block
setblock 7 190 324 minecraft:yellow_terracotta
fill 7 190 325 7 193 325 minecraft:honeycomb_block
setblock 8 190 323 minecraft:yellow_terracotta
fill 8 190 324 8 193 324 minecraft:honeycomb_block
setblock 8 190 363 minecraft:yellow_terracotta
fill 9 190 323 9 193 323 minecraft:honeycomb_block
fill 9 190 325 9 191 325 minecraft:honeycomb_block
setblock 9 190 362 minecraft:yellow_terracotta
fill 9 190 363 12 190 363 minecraft:honeycomb_block
setblock 10 190 361 minecraft:yellow_terracotta
fill 10 190 362 10 193 362 minecraft:honeycomb_block
setblock 12 190 324 minecraft:yellow_terracotta
setblock 13 190 323 minecraft:yellow_terracotta
setblock 13 190 363 minecraft:yellow_terracotta
fill 14 190 323 14 193 323 minecraft:honeycomb_block
setblock 14 190 362 minecraft:yellow_terracotta
fill 14 190 363 14 193 363 minecraft:honeycomb_block
fill 15 190 362 15 193 362 minecraft:honeycomb_block
setblock 17 190 323 minecraft:honeycomb_block
setblock 18 190 323 minecraft:yellow_terracotta
fill 18 190 361 19 190 361 minecraft:honeycomb_block
setblock 18 190 363 minecraft:yellow_terracotta
fill 19 190 323 19 193 323 minecraft:honeycomb_block
setblock 19 190 362 minecraft:yellow_terracotta
fill 19 190 363 19 193 363 minecraft:honeycomb_block
setblock 20 190 361 minecraft:yellow_terracotta
fill 20 190 362 20 193 362 minecraft:honeycomb_block
fill 21 190 361 21 193 361 minecraft:honeycomb_block
setblock 22 190 323 minecraft:honeycomb_block
setblock 22 190 324 minecraft:yellow_terracotta
fill 23 190 322 23 267 322 minecraft:honeycomb_block
setblock 23 190 323 minecraft:yellow_terracotta
fill 23 190 324 26 190 324 minecraft:honeycomb_block
setblock 23 190 363 minecraft:yellow_terracotta
fill 24 190 323 24 193 323 minecraft:honeycomb_block
setblock 24 190 362 minecraft:yellow_terracotta
fill 24 190 363 24 193 363 minecraft:honeycomb_block
setblock 25 190 361 minecraft:yellow_terracotta
fill 25 190 362 25 193 362 minecraft:honeycomb_block
setblock 26 190 360 minecraft:yellow_terracotta
fill 26 190 361 26 193 361 minecraft:honeycomb_block
setblock 28 190 323 minecraft:yellow_terracotta
setblock 28 190 363 minecraft:yellow_terracotta
fill 29 190 323 29 193 323 minecraft:honeycomb_block
setblock 29 190 362 minecraft:yellow_terracotta
fill 29 190 363 29 193 363 minecraft:honeycomb_block
fill 30 190 362 30 192 362 minecraft:honeycomb_block
setblock 33 190 363 minecraft:yellow_terracotta
setblock 36 190 322 minecraft:yellow_terracotta
fill 39 190 323 41 191 323 minecraft:honeycomb_block
fill 39 190 339 39 191 340 minecraft:honeycomb_block
setblock 39 190 342 minecraft:yellow_terracotta
fill 39 190 343 39 193 343 minecraft:honeycomb_block
fill 39 190 363 39 193 363 minecraft:honeycomb_block
setblock 40 190 335 minecraft:honeycomb_block
setblock 40 190 336 minecraft:yellow_terracotta
fill 40 190 337 40 193 337 minecraft:honeycomb_block
setblock 40 190 341 minecraft:yellow_terracotta
fill 40 190 342 40 193 342 minecraft:honeycomb_block
setblock 40 190 346 minecraft:yellow_terracotta
setblock 41 190 324 minecraft:honeycomb_block
setblock 41 190 325 minecraft:yellow_terracotta
fill 41 190 326 41 190 329 minecraft:honeycomb_block
setblock 41 190 330 minecraft:yellow_terracotta
fill 41 190 331 41 193 331 minecraft:honeycomb_block
setblock 41 190 335 minecraft:yellow_terracotta
fill 41 190 336 41 193 336 minecraft:honeycomb_block
setblock 41 190 340 minecraft:yellow_terracotta
fill 41 190 341 41 193 341 minecraft:honeycomb_block
setblock 41 190 345 minecraft:yellow_terracotta
fill 41 190 346 41 193 346 minecraft:honeycomb_block
setblock 41 190 349 minecraft:honeycomb_block
setblock 41 190 353 minecraft:honey_block
fill 41 190 358 41 190 359 minecraft:honeycomb_block
setblock 41 190 360 minecraft:yellow_terracotta
fill 41 190 361 41 193 361 minecraft:honeycomb_block
setblock 0 191 352 minecraft:honeycomb_block
setblock 0 191 355 minecraft:yellow_terracotta
setblock 1 191 324 minecraft:yellow_terracotta
fill 1 191 325 1 194 325 minecraft:honeycomb_block
setblock 1 191 328 minecraft:honeycomb_block
setblock 1 191 329 minecraft:yellow_terracotta
fill 1 191 330 1 194 330 minecraft:honeycomb_block
setblock 1 191 334 minecraft:yellow_terracotta
fill 1 191 335 1 194 335 minecraft:honeycomb_block
setblock 1 191 339 minecraft:yellow_terracotta
fill 1 191 340 1 194 340 minecraft:honeycomb_block
setblock 1 191 343 minecraft:honeycomb_block
setblock 1 191 344 minecraft:yellow_terracotta
fill 1 191 345 1 194 345 minecraft:honeycomb_block
setblock 1 191 348 minecraft:honeycomb_block
setblock 1 191 349 minecraft:yellow_terracotta
fill 1 191 357 1 191 358 minecraft:honeycomb_block
setblock 1 191 359 minecraft:yellow_terracotta
fill 1 191 360 1 194 360 minecraft:honeycomb_block
fill 1 191 364 1 198 364 minecraft:honeycomb_block
setblock 2 191 323 minecraft:yellow_terracotta
fill 2 191 324 2 194 324 minecraft:honeycomb_block
setblock 2 191 328 minecraft:yellow_terracotta
fill 2 191 329 3 193 329 minecraft:honeycomb_block
setblock 2 191 333 minecraft:yellow_terracotta
fill 2 191 334 2 194 334 minecraft:honeycomb_block
setblock 2 191 338 minecraft:yellow_terracotta
fill 2 191 339 2 194 339 minecraft:honeycomb_block
setblock 2 191 343 minecraft:yellow_terracotta
fill 2 191 344 3 193 344 minecraft:honeycomb_block
fill 2 191 346 2 192 346 minecraft:honeycomb_block
fill 2 191 359 2 194 359 minecraft:honeycomb_block
setblock 2 191 363 minecraft:yellow_terracotta
fill 3 191 323 3 194 323 minecraft:honeycomb_block
fill 3 191 325 3 191 326 minecraft:honeycomb_block
setblock 3 191 327 minecraft:yellow_terracotta
fill 3 191 328 3 194 328 minecraft:honeycomb_block
setblock 3 191 333 minecraft:light[level=15]
setblock 3 191 337 minecraft:yellow_terracotta
fill 3 191 338 3 193 338 minecraft:honeycomb_block
setblock 3 191 342 minecraft:yellow_terracotta
fill 3 191 343 3 194 343 minecraft:honeycomb_block
setblock 3 191 349 minecraft:light[level=15]
setblock 3 191 357 minecraft:light[level=15]
setblock 3 191 362 minecraft:yellow_terracotta
fill 3 191 363 3 194 363 minecraft:honeycomb_block
setblock 4 191 325 minecraft:honeycomb_block
setblock 4 191 326 minecraft:yellow_terracotta
setblock 4 191 361 minecraft:yellow_terracotta
fill 4 191 362 4 194 362 minecraft:honeycomb_block
setblock 5 191 325 minecraft:yellow_terracotta
fill 5 191 326 5 194 326 minecraft:honeycomb_block
fill 5 191 361 5 194 361 minecraft:honeycomb_block
setblock 6 191 324 minecraft:yellow_terracotta
fill 6 191 325 6 194 325 minecraft:honeycomb_block
setblock 7 191 323 minecraft:yellow_terracotta
fill 7 191 324 7 194 324 minecraft:honeycomb_block
setblock 7 191 363 minecraft:yellow_terracotta
fill 8 191 323 8 194 323 minecraft:honeycomb_block
setblock 8 191 362 minecraft:yellow_terracotta
fill 8 191 363 11 191 363 minecraft:honeycomb_block
setblock 9 191 361 minecraft:yellow_terracotta
fill 9 191 362 9 194 362 minecraft:honeycomb_block
fill 10 191 361 10 192 361 minecraft:honeycomb_block
setblock 11 191 324 minecraft:yellow_terracotta
setblock 11 191 325 minecraft:light[level=15]
setblock 11 191 333 minecraft:light[level=15]
setblock 11 191 341 minecraft:light[level=15]
setblock 11 191 349 minecraft:light[level=15]
setblock 11 191 357 minecraft:light[level=15]
setblock 12 191 323 minecraft:yellow_terracotta
fill 12 191 324 13 193 324 minecraft:honeycomb_block
setblock 12 191 363 minecraft:yellow_terracotta
fill 13 191 323 13 194 323 minecraft:honeycomb_block
setblock 13 191 362 minecraft:yellow_terracotta
fill 13 191 363 13 194 363 minecraft:honeycomb_block
fill 14 191 362 14 194 362 minecraft:honeycomb_block
setblock 17 191 323 minecraft:yellow_terracotta
setblock 17 191 363 minecraft:yellow_terracotta
fill 18 191 323 18 194 323 minecraft:honeycomb_block
setblock 18 191 361 minecraft:honeycomb_block
setblock 18 191 362 minecraft:yellow_terracotta
fill 18 191 363 18 194 363 minecraft:honeycomb_block
fill 19 191 324 20 191 324 minecraft:honeycomb_block
setblock 19 191 325 minecraft:light[level=15]
setblock 19 191 333 minecraft:light[level=15]
setblock 19 191 341 minecraft:light[level=15]
setblock 19 191 349 minecraft:light[level=15]
setblock 19 191 357 minecraft:light[level=15]
setblock 19 191 361 minecraft:yellow_terracotta
fill 19 191 362 19 194 362 minecraft:honeycomb_block
fill 20 191 361 20 194 361 minecraft:honeycomb_block
setblock 21 191 324 minecraft:yellow_terracotta
setblock 22 191 323 minecraft:yellow_terracotta
fill 22 191 324 25 191 324 minecraft:honeycomb_block
fill 22 191 360 22 193 360 minecraft:honeycomb_block
setblock 22 191 363 minecraft:yellow_terracotta
fill 23 191 323 23 194 323 minecraft:honeycomb_block
setblock 23 191 362 minecraft:yellow_terracotta
fill 23 191 363 23 194 363 minecraft:honeycomb_block
setblock 24 191 361 minecraft:yellow_terracotta
fill 24 191 362 24 194 362 minecraft:honeycomb_block
setblock 25 191 360 minecraft:yellow_terracotta
fill 25 191 361 25 194 361 minecraft:honeycomb_block
setblock 26 191 324 minecraft:yellow_terracotta
setblock 27 191 323 minecraft:yellow_terracotta
fill 27 191 324 27 194 324 minecraft:honeycomb_block
setblock 27 191 325 minecraft:light[level=15]
setblock 27 191 333 minecraft:light[level=15]
setblock 27 191 341 minecraft:light[level=15]
setblock 27 191 349 minecraft:light[level=15]
setblock 27 191 357 minecraft:light[level=15]
setblock 27 191 363 minecraft:yellow_terracotta
fill 28 191 323 28 194 323 minecraft:honeycomb_block
setblock 28 191 362 minecraft:yellow_terracotta
fill 28 191 363 28 194 363 minecraft:honeycomb_block
fill 29 191 362 29 193 362 minecraft:honeycomb_block
setblock 31 191 323 minecraft:honeycomb_block
setblock 32 191 363 minecraft:yellow_terracotta
fill 33 191 363 34 192 363 minecraft:honeycomb_block
setblock 35 191 325 minecraft:light[level=15]
setblock 35 191 333 minecraft:light[level=15]
setblock 35 191 341 minecraft:light[level=15]
setblock 35 191 349 minecraft:light[level=15]
setblock 35 191 357 minecraft:light[level=15]
fill 36 191 322 36 231 322 minecraft:honeycomb_block
setblock 37 191 323 minecraft:yellow_terracotta
setblock 37 191 363 minecraft:yellow_terracotta
fill 38 191 323 38 194 323 minecraft:honeycomb_block
fill 38 191 363 38 194 363 minecraft:honeycomb_block
fill 39 191 338 39 193 338 minecraft:honeycomb_block
setblock 39 191 341 minecraft:yellow_terracotta
fill 39 191 342 39 194 342 minecraft:honeycomb_block
fill 39 191 344 39 191 345 minecraft:honeycomb_block
setblock 39 191 364 minecraft:orange_terracotta
setblock 40 191 324 minecraft:honeycomb_block
setblock 40 191 325 minecraft:yellow_terracotta
setblock 40 191 334 minecraft:honeycomb_block
setblock 40 191 335 minecraft:yellow_terracotta
fill 40 191 336 40 194 336 minecraft:honeycomb_block
setblock 40 191 340 minecraft:yellow_terracotta
fill 40 191 341 40 194 341 minecraft:honeycomb_block
setblock 40 191 345 minecraft:yellow_terracotta
fill 40 191 346 40 192 348 minecraft:honeycomb_block
setblock 41 191 324 minecraft:yellow_terracotta
fill 41 191 325 41 191 328 minecraft:honeycomb_block
setblock 41 191 329 minecraft:yellow_terracotta
fill 41 191 330 41 194 330 minecraft:honeycomb_block
setblock 41 191 334 minecraft:yellow_terracotta
fill 41 191 335 41 194 335 minecraft:honeycomb_block
setblock 41 191 339 minecraft:yellow_terracotta
fill 41 191 340 41 194 340 minecraft:honeycomb_block
setblock 41 191 344 minecraft:yellow_terracotta
fill 41 191 345 41 194 345 minecraft:honeycomb_block
setblock 41 191 349 minecraft:yellow_terracotta
fill 41 191 350 41 193 351 minecraft:honeycomb_block
setblock 41 191 358 minecraft:honeycomb_block
setblock 41 191 359 minecraft:yellow_terracotta
fill 41 191 360 41 194 360 minecraft:honeycomb_block
setblock 0 192 352 minecraft:yellow_terracotta
fill 0 192 355 0 308 355 minecraft:honeycomb_block
setblock 1 192 323 minecraft:yellow_terracotta
fill 1 192 324 1 195 324 minecraft:honeycomb_block
setblock 1 192 327 minecraft:honeycomb_block
setblock 1 192 328 minecraft:yellow_terracotta
fill 1 192 329 1 195 329 minecraft:honeycomb_block
setblock 1 192 332 minecraft:honeycomb_block
setblock 1 192 333 minecraft:yellow_terracotta
fill 1 192 334 1 195 334 minecraft:honeycomb_block
setblock 1 192 338 minecraft:yellow_terracotta
fill 1 192 339 1 195 339 minecraft:honeycomb_block
setblock 1 192 343 minecraft:yellow_terracotta
fill 1 192 344 1 195 344 minecraft:honeycomb_block
setblock 1 192 348 minecraft:yellow_terracotta
fill 1 192 349 1 194 350 minecraft:honeycomb_block
setblock 1 192 357 minecraft:honeycomb_block
setblock 1 192 358 minecraft:yellow_terracotta
fill 1 192 359 1 195 359 minecraft:honeycomb_block
setblock 1 192 363 minecraft:yellow_terracotta
fill 2 192 323 2 195 323 minecraft:honeycomb_block
setblock 2 192 327 minecraft:yellow_terracotta
fill 2 192 328 2 195 328 minecraft:honeycomb_block
setblock 2 192 332 minecraft:yellow_terracotta
fill 2 192 333 2 195 333 minecraft:honeycomb_block
setblock 2 192 336 minecraft:honeycomb_block
setblock 2 192 337 minecraft:yellow_terracotta
fill 2 192 338 2 195 338 minecraft:honeycomb_block
setblock 2 192 341 minecraft:honeycomb_block
setblock 2 192 342 minecraft:yellow_terracotta
fill 2 192 343 2 195 343 minecraft:honeycomb_block
setblock 2 192 347 minecraft:yellow_terracotta
fill 2 192 348 2 195 348 minecraft:honeycomb_block
setblock 2 192 362 minecraft:yellow_terracotta
fill 2 192 363 2 195 363 minecraft:honeycomb_block
setblock 3 192 325 minecraft:honeycomb_block
setblock 3 192 326 minecraft:yellow_terracotta
fill 3 192 327 4 194 327 minecraft:honeycomb_block
setblock 3 192 330 minecraft:honeycomb_block
setblock 3 192 337 minecraft:honeycomb_block
setblock 3 192 341 minecraft:yellow_terracotta
fill 3 192 342 3 195 342 minecraft:honeycomb_block
setblock 3 192 345 minecraft:honeycomb_block
setblock 3 192 360 minecraft:honeycomb_block
setblock 3 192 361 minecraft:yellow_terracotta
fill 3 192 362 3 195 362 minecraft:honeycomb_block
setblock 4 192 325 minecraft:yellow_terracotta
fill 4 192 326 4 195 326 minecraft:honeycomb_block
fill 4 192 361 4 195 361 minecraft:honeycomb_block
setblock 5 192 324 minecraft:yellow_terracotta
fill 5 192 325 5 195 325 minecraft:honeycomb_block
setblock 6 192 323 minecraft:yellow_terracotta
fill 6 192 324 6 195 324 minecraft:honeycomb_block
fill 6 192 326 6 193 326 minecraft:honeycomb_block
setblock 6 192 363 minecraft:yellow_terracotta
fill 7 192 323 7 195 323 minecraft:honeycomb_block
setblock 7 192 362 minecraft:yellow_terracotta
fill 7 192 363 10 192 363 minecraft:honeycomb_block
setblock 8 192 361 minecraft:yellow_terracotta
fill 8 192 362 8 195 362 minecraft:honeycomb_block
setblock 9 192 325 minecraft:yellow_terracotta
fill 9 192 361 9 193 361 minecraft:honeycomb_block
setblock 10 192 324 minecraft:yellow_terracotta
setblock 11 192 323 minecraft:yellow_terracotta
fill 11 192 324 11 195 324 minecraft:honeycomb_block
setblock 11 192 363 minecraft:yellow_terracotta
fill 12 192 323 12 195 323 minecraft:honeycomb_block
setblock 12 192 362 minecraft:yellow_terracotta
fill 12 192 363 12 195 363 minecraft:honeycomb_block
fill 13 192 362 13 195 362 minecraft:honeycomb_block
setblock 14 192 324 minecraft:honeycomb_block
setblock 15 192 324 minecraft:yellow_terracotta
setblock 16 192 323 minecraft:yellow_terracotta
fill 16 192 324 19 192 324 minecraft:honeycomb_block
setblock 16 192 363 minecraft:yellow_terracotta
fill 17 192 323 17 195 323 minecraft:honeycomb_block
setblock 17 192 361 minecraft:honeycomb_block
setblock 17 192 362 minecraft:yellow_terracotta
fill 17 192 363 17 195 363 minecraft:honeycomb_block
setblock 18 192 361 minecraft:yellow_terracotta
fill 18 192 362 18 195 362 minecraft:honeycomb_block
fill 19 192 361 19 195 361 minecraft:honeycomb_block
setblock 20 192 324 minecraft:yellow_terracotta
setblock 21 192 323 minecraft:yellow_terracotta
fill 21 192 324 24 192 324 minecraft:honeycomb_block
setblock 21 192 363 minecraft:yellow_terracotta
fill 22 192 323 22 195 323 minecraft:honeycomb_block
setblock 22 192 362 minecraft:yellow_terracotta
fill 22 192 363 22 195 363 minecraft:honeycomb_block
setblock 23 192 361 minecraft:yellow_terracotta
fill 23 192 362 23 195 362 minecraft:honeycomb_block
fill 24 192 360 24 194 360 minecraft:yellow_terracotta
fill 24 192 361 24 195 361 minecraft:honeycomb_block
fill 25 192 324 25 192 325 minecraft:yellow_terracotta
setblock 25 192 360 minecraft:honeycomb_block
setblock 26 192 323 minecraft:yellow_terracotta
fill 26 192 324 26 195 324 minecraft:honeycomb_block
setblock 26 192 363 minecraft:yellow_terracotta
fill 27 192 323 27 195 323 minecraft:honeycomb_block
setblock 27 192 362 minecraft:yellow_terracotta
fill 27 192 363 27 195 363 minecraft:honeycomb_block
fill 28 192 324 28 193 324 minecraft:honeycomb_block
setblock 28 192 361 minecraft:yellow_terracotta
fill 28 192 362 28 194 362 minecraft:honeycomb_block
setblock 31 192 323 minecraft:yellow_terracotta
setblock 31 192 363 minecraft:yellow_terracotta
fill 32 192 323 32 195 323 minecraft:honeycomb_block
fill 32 192 363 32 193 363 minecraft:honeycomb_block
setblock 34 192 323 minecraft:honey_block
setblock 35 192 323 minecraft:honeycomb_block
setblock 35 192 363 minecraft:honeycomb_block
setblock 36 192 323 minecraft:yellow_terracotta
setblock 36 192 363 minecraft:yellow_terracotta
fill 37 192 323 37 195 323 minecraft:honeycomb_block
fill 37 192 363 37 195 363 minecraft:honeycomb_block
fill 39 192 323 39 192 324 minecraft:honeycomb_block
setblock 39 192 339 minecraft:honeycomb_block
setblock 39 192 340 minecraft:yellow_terracotta
fill 39 192 341 39 195 341 minecraft:honeycomb_block
setblock 39 192 344 minecraft:honeycomb_block
setblock 39 192 345 minecraft:yellow_terracotta
fill 39 192 346 39 195 346 minecraft:honeycomb_block
fill 39 192 364 39 198 364 minecraft:honeycomb_block
setblock 40 192 323 minecraft:honeycomb_block
setblock 40 192 324 minecraft:yellow_terracotta
fill 40 192 325 40 192 328 minecraft:honeycomb_block
setblock 40 192 329 minecraft:yellow_terracotta
fill 40 192 332 40 192 333 minecraft:honeycomb_block
setblock 40 192 334 minecraft:yellow_terracotta
fill 40 192 335 40 195 335 minecraft:honeycomb_block
setblock 40 192 339 minecraft:yellow_terracotta
fill 40 192 340 40 195 340 minecraft:honeycomb_block
setblock 40 192 344 minecraft:yellow_terracotta
fill 40 192 345 40 195 345 minecraft:honeycomb_block
setblock 40 192 349 minecraft:yellow_terracotta
fill 40 192 362 40 192 363 minecraft:honeycomb_block
setblock 41 192 323 minecraft:yellow_terracotta
fill 41 192 324 41 192 327 minecraft:honeycomb_block
setblock 41 192 328 minecraft:yellow_terracotta
fill 41 192 329 41 195 329 minecraft:honeycomb_block
setblock 41 192 333 minecraft:yellow_terracotta
fill 41 192 334 41 195 334 minecraft:honeycomb_block
setblock 41 192 338 minecraft:yellow_terracotta
fill 41 192 339 41 195 339 minecraft:honeycomb_block
setblock 41 192 343 minecraft:yellow_terracotta
fill 41 192 344 41 195 344 minecraft:honeycomb_block
setblock 41 192 347 minecraft:honeycomb_block
setblock 41 192 348 minecraft:yellow_terracotta
fill 41 192 349 41 195 349 minecraft:honeycomb_block
setblock 41 192 352 minecraft:honeycomb_block
setblock 41 192 357 minecraft:honeycomb_block
setblock 41 192 358 minecraft:yellow_terracotta
fill 41 192 359 41 195 359 minecraft:honeycomb_block
setblock 41 192 363 minecraft:yellow_terracotta
fill 0 193 352 0 308 352 minecraft:honeycomb_block
fill 1 193 323 1 196 323 minecraft:honeycomb_block
setblock 1 193 327 minecraft:yellow_terracotta
fill 1 193 328 1 196 328 minecraft:honeycomb_block
setblock 1 193 331 minecraft:honeycomb_block
setblock 1 193 332 minecraft:yellow_terracotta
fill 1 193 333 1 196 333 minecraft:honeycomb_block
setblock 1 193 337 minecraft:yellow_terracotta
fill 1 193 338 1 196 338 minecraft:honeycomb_block
setblock 1 193 342 minecraft:yellow_terracotta
fill 1 193 343 1 196 343 minecraft:honeycomb_block
setblock 1 193 346 minecraft:honeycomb_block
setblock 1 193 347 minecraft:yellow_terracotta
fill 1 193 348 1 196 348 minecraft:honeycomb_block
setblock 1 193 351 minecraft:honeycomb_block
setblock 1 193 352 minecraft:yellow_terracotta
setblock 1 193 356 minecraft:honeycomb_block
setblock 1 193 357 minecraft:yellow_terracotta
fill 1 193 358 1 196 358 minecraft:honeycomb_block
setblock 1 193 362 minecraft:yellow_terracotta
fill 1 193 363 1 196 363 minecraft:honeycomb_block
setblock 2 193 326 minecraft:yellow_terracotta
fill 2 193 327 2 196 327 minecraft:honeycomb_block
setblock 2 193 331 minecraft:yellow_terracotta
fill 2 193 332 2 196 332 minecraft:honeycomb_block
setblock 2 193 336 minecraft:yellow_terracotta
fill 2 193 337 2 195 337 minecraft:honeycomb_block
setblock 2 193 341 minecraft:yellow_terracotta
fill 2 193 342 2 196 342 minecraft:honeycomb_block
setblock 2 193 346 minecraft:yellow_terracotta
fill 2 193 347 2 196 347 minecraft:honeycomb_block
fill 2 193 349 2 194 349 minecraft:honeycomb_block
setblock 2 193 361 minecraft:yellow_terracotta
fill 2 193 362 2 196 362 minecraft:honeycomb_block
setblock 3 193 325 minecraft:yellow_terracotta
fill 3 193 326 3 196 326 minecraft:honeycomb_block
setblock 3 193 330 minecraft:yellow_terracotta
fill 3 193 331 3 195 331 minecraft:honeycomb_block
setblock 3 193 340 minecraft:yellow_terracotta
fill 3 193 341 3 194 341 minecraft:honeycomb_block
setblock 3 193 345 minecraft:yellow_terracotta
fill 3 193 346 3 195 346 minecraft:honeycomb_block
setblock 3 193 360 minecraft:yellow_terracotta
fill 3 193 361 3 195 361 minecraft:honeycomb_block
setblock 4 193 324 minecraft:yellow_terracotta
fill 4 193 325 4 196 325 minecraft:honeycomb_block
setblock 5 193 323 minecraft:yellow_terracotta
fill 5 193 324 5 196 324 minecraft:honeycomb_block
setblock 5 193 363 minecraft:yellow_terracotta
fill 6 193 323 6 196 323 minecraft:honeycomb_block
setblock 6 193 362 minecraft:yellow_terracotta
fill 6 193 363 9 193 363 minecraft:honeycomb_block
setblock 7 193 361 minecraft:yellow_terracotta
fill 7 193 362 7 196 362 minecraft:honeycomb_block
setblock 7 193 364 minecraft:yellow_terracotta
setblock 8 193 325 minecraft:yellow_terracotta
setblock 8 193 361 minecraft:honeycomb_block
setblock 9 193 324 minecraft:yellow_terracotta
fill 9 193 325 10 193 325 minecraft:honeycomb_block
setblock 10 193 323 minecraft:yellow_terracotta
fill 10 193 324 10 196 324 minecraft:honeycomb_block
setblock 10 193 363 minecraft:yellow_terracotta
fill 11 193 323 11 196 323 minecraft:honeycomb_block
setblock 11 193 362 minecraft:yellow_terracotta
fill 11 193 363 11 196 363 minecraft:honeycomb_block
fill 12 193 362 12 195 362 minecraft:honeycomb_block
setblock 12 193 364 minecraft:orange_terracotta
setblock 13 193 322 minecraft:yellow_terracotta
setblock 14 193 324 minecraft:yellow_terracotta
setblock 15 193 323 minecraft:yellow_terracotta
schedule function dropper:buildpart/72_7 1t
