fill 423 163 576 423 164 577 minecraft:light_blue_concrete
fill 423 163 581 423 164 581 minecraft:light_blue_concrete
fill 423 163 585 423 164 585 minecraft:light_blue_concrete
fill 423 163 597 423 164 597 minecraft:light_blue_concrete
setblock 423 163 598 minecraft:lime_concrete
fill 423 163 599 423 165 599 minecraft:light_blue_concrete
setblock 424 163 557 minecraft:lime_concrete
fill 425 163 599 425 164 599 minecraft:light_blue_concrete
setblock 426 163 560 minecraft:light[level=14]
setblock 426 163 568 minecraft:light[level=14]
setblock 426 163 576 minecraft:light[level=14]
setblock 426 163 584 minecraft:light[level=14]
setblock 426 163 592 minecraft:light[level=14]
setblock 428 163 599 minecraft:lime_concrete
fill 429 163 599 429 164 599 minecraft:light_blue_concrete
setblock 430 163 599 minecraft:lime_concrete
fill 431 163 599 431 164 599 minecraft:light_blue_concrete
fill 433 163 599 433 165 599 minecraft:light_blue_concrete
setblock 434 163 560 minecraft:light[level=14]
setblock 434 163 568 minecraft:light[level=14]
setblock 434 163 576 minecraft:light[level=14]
setblock 434 163 584 minecraft:light[level=14]
setblock 434 163 592 minecraft:light[level=14]
fill 435 163 599 435 165 599 minecraft:light_blue_concrete
setblock 436 163 599 minecraft:lime_concrete
fill 437 163 599 437 164 599 minecraft:light_blue_concrete
setblock 438 163 599 minecraft:lime_concrete
fill 439 163 557 439 164 557 minecraft:light_blue_concrete
fill 439 163 599 441 164 599 minecraft:light_blue_concrete
setblock 440 163 557 minecraft:lime_concrete
fill 441 163 557 444 164 557 minecraft:light_blue_concrete
setblock 442 163 560 minecraft:light[level=14]
setblock 442 163 568 minecraft:light[level=14]
setblock 442 163 576 minecraft:light[level=14]
setblock 442 163 584 minecraft:light[level=14]
setblock 442 163 592 minecraft:light[level=14]
setblock 450 163 560 minecraft:light[level=14]
setblock 450 163 568 minecraft:light[level=14]
setblock 450 163 576 minecraft:light[level=14]
setblock 450 163 584 minecraft:light[level=14]
setblock 450 163 592 minecraft:light[level=14]
fill 452 163 599 452 165 599 minecraft:light_blue_concrete
fill 454 163 599 456 164 599 minecraft:light_blue_concrete
setblock 457 163 599 minecraft:lime_concrete
setblock 458 163 560 minecraft:light[level=14]
setblock 458 163 568 minecraft:light[level=14]
setblock 458 163 576 minecraft:light[level=14]
setblock 458 163 584 minecraft:light[level=14]
setblock 458 163 592 minecraft:light[level=14]
setblock 459 163 599 minecraft:lime_concrete
setblock 460 163 557 minecraft:lime_concrete
fill 461 163 599 461 164 599 minecraft:light_blue_concrete
fill 465 163 559 465 164 559 minecraft:light_blue_concrete
fill 465 163 566 465 164 566 minecraft:light_blue_concrete
setblock 465 163 567 minecraft:lime_concrete
fill 465 163 568 465 164 569 minecraft:light_blue_concrete
fill 465 163 571 465 164 571 minecraft:light_blue_concrete
fill 465 163 573 465 164 574 minecraft:light_blue_concrete
setblock 465 163 575 minecraft:lime_concrete
fill 465 163 576 465 164 576 minecraft:light_blue_concrete
fill 465 163 581 465 164 581 minecraft:light_blue_concrete
fill 465 163 591 465 164 591 minecraft:light_blue_concrete
fill 465 163 595 465 164 595 minecraft:light_blue_concrete
setblock 423 164 558 minecraft:light_blue_concrete
fill 423 164 562 423 164 563 minecraft:light_blue_concrete
setblock 423 164 570 minecraft:light_blue_concrete
setblock 423 164 572 minecraft:light_blue_concrete
setblock 423 164 575 minecraft:light_blue_concrete
setblock 423 164 578 minecraft:light_blue_concrete
fill 423 164 586 423 165 586 minecraft:light_blue_concrete
setblock 423 164 594 minecraft:light_blue_concrete
setblock 423 164 598 minecraft:light_blue_concrete
setblock 424 164 557 minecraft:light_blue_concrete
setblock 426 164 599 minecraft:light_blue_concrete
setblock 428 164 599 minecraft:light_blue_concrete
setblock 430 164 557 minecraft:light_blue_concrete
setblock 430 164 599 minecraft:light_blue_concrete
setblock 434 164 599 minecraft:light_blue_concrete
fill 436 164 599 436 165 599 minecraft:light_blue_concrete
setblock 438 164 557 minecraft:light_blue_concrete
setblock 438 164 599 minecraft:light_blue_concrete
fill 440 164 557 440 166 557 minecraft:light_blue_concrete
fill 442 164 599 442 166 599 minecraft:light_blue_concrete
setblock 446 164 557 minecraft:light_blue_concrete
setblock 450 164 599 minecraft:light_blue_concrete
setblock 454 164 557 minecraft:light_blue_concrete
fill 457 164 599 459 164 599 minecraft:light_blue_concrete
setblock 460 164 557 minecraft:light_blue_concrete
setblock 462 164 557 minecraft:light_blue_concrete
setblock 465 164 562 minecraft:light_blue_concrete
setblock 465 164 564 minecraft:light_blue_concrete
setblock 465 164 567 minecraft:light_blue_concrete
setblock 465 164 570 minecraft:light_blue_concrete
setblock 465 164 575 minecraft:light_blue_concrete
fill 465 164 577 465 164 578 minecraft:light_blue_concrete
setblock 465 164 586 minecraft:light_blue_concrete
fill 465 164 594 465 165 594 minecraft:light_blue_concrete
fill 423 165 557 423 165 564 minecraft:lime_concrete
setblock 423 165 565 minecraft:light_blue_concrete
fill 423 165 566 423 165 585 minecraft:lime_concrete
fill 423 165 588 423 171 598 minecraft:lime_concrete
fill 424 165 557 425 165 557 minecraft:lime_concrete
fill 424 165 599 432 165 599 minecraft:lime_concrete
setblock 426 165 557 minecraft:light_blue_concrete
fill 427 165 557 439 165 557 minecraft:lime_concrete
fill 431 165 586 431 166 586 minecraft:purple_concrete
fill 434 165 599 434 171 599 minecraft:lime_concrete
fill 437 165 599 438 200 599 minecraft:lime_concrete
setblock 439 165 599 minecraft:light_blue_concrete
fill 440 165 599 441 200 599 minecraft:lime_concrete
fill 441 165 557 465 165 557 minecraft:lime_concrete
fill 443 165 599 451 166 599 minecraft:lime_concrete
fill 453 165 599 453 201 599 minecraft:lime_concrete
setblock 454 165 599 minecraft:light_blue_concrete
fill 455 165 599 457 165 599 minecraft:lime_concrete
setblock 458 165 599 minecraft:light_blue_concrete
fill 459 165 599 464 166 599 minecraft:lime_concrete
fill 465 165 558 465 166 579 minecraft:lime_concrete
fill 465 165 581 465 165 593 minecraft:lime_concrete
fill 465 165 595 465 196 598 minecraft:lime_concrete
fill 423 166 557 423 166 563 minecraft:lime_concrete
setblock 423 166 564 minecraft:light_blue_concrete
fill 423 166 565 423 171 574 minecraft:lime_concrete
setblock 423 166 575 minecraft:light_blue_concrete
fill 423 166 576 423 171 578 minecraft:lime_concrete
fill 423 166 579 423 167 579 minecraft:light_blue_concrete
fill 423 166 580 423 171 587 minecraft:lime_concrete
setblock 423 166 599 minecraft:lime_concrete
setblock 424 166 557 minecraft:light_blue_concrete
setblock 424 166 599 minecraft:light_blue_concrete
fill 425 166 557 436 166 557 minecraft:lime_concrete
fill 425 166 599 429 171 599 minecraft:lime_concrete
setblock 430 166 599 minecraft:light_blue_concrete
fill 431 166 599 433 200 599 minecraft:lime_concrete
fill 435 166 599 436 200 599 minecraft:lime_concrete
setblock 437 166 557 minecraft:light_blue_concrete
fill 438 166 557 439 171 557 minecraft:lime_concrete
fill 439 166 599 439 200 599 minecraft:lime_concrete
fill 441 166 557 445 166 557 minecraft:lime_concrete
setblock 446 166 557 minecraft:light_blue_concrete
fill 447 166 557 448 198 557 minecraft:lime_concrete
setblock 449 166 557 minecraft:light_blue_concrete
fill 450 166 557 465 166 557 minecraft:lime_concrete
fill 452 166 599 452 200 599 minecraft:lime_concrete
fill 454 166 599 456 197 599 minecraft:lime_concrete
setblock 457 166 599 minecraft:light_blue_concrete
fill 458 166 599 458 171 599 minecraft:lime_concrete
fill 465 166 580 465 200 580 minecraft:lime_concrete
setblock 465 166 581 minecraft:light_blue_concrete
fill 465 166 582 465 200 582 minecraft:lime_concrete
fill 465 166 583 465 167 583 minecraft:light_blue_concrete
fill 465 166 584 465 166 586 minecraft:lime_concrete
setblock 465 166 587 minecraft:light_blue_concrete
fill 465 166 588 465 198 591 minecraft:lime_concrete
setblock 465 166 592 minecraft:light_blue_concrete
fill 465 166 593 465 171 594 minecraft:lime_concrete
setblock 423 167 557 minecraft:light_blue_concrete
fill 423 167 558 423 171 564 minecraft:lime_concrete
fill 423 167 575 423 196 575 minecraft:lime_concrete
setblock 423 167 599 minecraft:light_blue_concrete
fill 424 167 557 430 171 557 minecraft:lime_concrete
fill 424 167 599 424 200 599 minecraft:lime_concrete
fill 430 167 599 430 200 599 minecraft:lime_concrete
setblock 431 167 557 minecraft:light_blue_concrete
fill 432 167 557 437 196 557 minecraft:lime_concrete
fill 440 167 557 441 200 557 minecraft:lime_concrete
setblock 442 167 557 minecraft:light_blue_concrete
fill 442 167 599 449 171 599 minecraft:lime_concrete
fill 443 167 557 446 171 557 minecraft:lime_concrete
fill 449 167 557 451 198 557 minecraft:lime_concrete
setblock 450 167 599 minecraft:light_blue_concrete
fill 451 167 599 451 200 599 minecraft:lime_concrete
setblock 452 167 557 minecraft:light_blue_concrete
fill 453 167 557 453 200 557 minecraft:lime_concrete
setblock 454 167 557 minecraft:light_blue_concrete
fill 455 167 557 456 200 557 minecraft:lime_concrete
setblock 457 167 557 minecraft:light_blue_concrete
fill 457 167 599 457 200 599 minecraft:lime_concrete
fill 458 167 557 461 196 557 minecraft:lime_concrete
setblock 459 167 599 minecraft:light_blue_concrete
fill 460 167 599 465 198 599 minecraft:lime_concrete
fill 462 167 557 463 167 557 minecraft:light_blue_concrete
fill 464 167 557 464 200 557 minecraft:lime_concrete
setblock 465 167 557 minecraft:light_blue_concrete
fill 465 167 558 465 171 575 minecraft:lime_concrete
setblock 465 167 576 minecraft:light_blue_concrete
fill 465 167 577 465 171 579 minecraft:lime_concrete
fill 465 167 581 465 201 581 minecraft:lime_concrete
fill 465 167 584 465 197 584 minecraft:lime_concrete
setblock 465 167 585 minecraft:light_blue_concrete
fill 465 167 586 465 171 587 minecraft:lime_concrete
fill 465 167 592 465 200 592 minecraft:lime_concrete
fill 423 168 557 423 200 557 minecraft:lime_concrete
fill 423 168 579 423 198 579 minecraft:lime_concrete
fill 423 168 599 423 197 599 minecraft:lime_concrete
fill 424 168 558 424 169 563 minecraft:white_concrete
fill 424 168 566 425 168 571 minecraft:white_concrete
fill 424 168 574 425 168 579 minecraft:white_concrete
fill 424 168 582 425 168 587 minecraft:white_concrete
fill 424 168 590 425 168 595 minecraft:white_concrete
fill 424 168 598 429 169 598 minecraft:white_concrete
fill 425 168 559 425 168 565 minecraft:white_concrete
fill 425 168 572 425 168 573 minecraft:white_concrete
fill 425 168 580 425 168 581 minecraft:white_concrete
fill 425 168 588 425 168 589 minecraft:white_concrete
fill 425 168 596 425 168 597 minecraft:white_concrete
fill 426 168 559 463 168 559 minecraft:white_concrete
fill 426 168 597 464 168 597 minecraft:white_concrete
fill 427 168 558 432 169 558 minecraft:white_concrete
fill 431 168 557 431 197 557 minecraft:lime_concrete
fill 432 168 598 437 169 598 minecraft:white_concrete
fill 435 168 558 440 169 558 minecraft:white_concrete
fill 440 168 598 445 169 598 minecraft:white_concrete
fill 442 168 557 442 200 557 minecraft:lime_concrete
fill 443 168 558 448 169 558 minecraft:white_concrete
fill 444 168 564 445 169 565 minecraft:red_concrete
fill 448 168 598 453 169 598 minecraft:white_concrete
fill 450 168 599 450 171 599 minecraft:lime_concrete
fill 451 168 558 456 169 558 minecraft:white_concrete
fill 452 168 557 452 200 557 minecraft:lime_concrete
fill 454 168 557 454 171 557 minecraft:lime_concrete
fill 456 168 598 461 169 598 minecraft:white_concrete
fill 457 168 557 457 196 557 minecraft:lime_concrete
fill 459 168 558 464 169 558 minecraft:white_concrete
fill 459 168 599 459 196 599 minecraft:lime_concrete
fill 462 168 557 463 171 557 minecraft:lime_concrete
fill 463 168 560 463 168 596 minecraft:white_concrete
fill 464 168 561 464 169 566 minecraft:white_concrete
fill 464 168 569 464 169 574 minecraft:white_concrete
fill 464 168 577 464 169 582 minecraft:white_concrete
fill 464 168 585 464 169 590 minecraft:white_concrete
fill 464 168 593 464 169 596 minecraft:white_concrete
fill 464 168 598 464 169 598 minecraft:white_concrete
fill 465 168 557 465 197 557 minecraft:lime_concrete
fill 465 168 576 465 200 576 minecraft:lime_concrete
fill 465 168 583 465 196 583 minecraft:lime_concrete
fill 465 168 585 465 200 585 minecraft:lime_concrete
fill 424 169 566 424 169 571 minecraft:white_concrete
fill 424 169 574 424 169 579 minecraft:white_concrete
fill 424 169 582 424 169 587 minecraft:white_concrete
fill 424 169 590 424 169 595 minecraft:white_concrete
setblock 464 169 597 minecraft:white_concrete
setblock 426 171 560 minecraft:light[level=14]
setblock 426 171 568 minecraft:light[level=14]
fill 426 171 574 427 172 582 minecraft:white_concrete
setblock 426 171 584 minecraft:light[level=14]
setblock 426 171 592 minecraft:light[level=14]
fill 427 171 571 428 172 573 minecraft:white_concrete
fill 427 171 583 428 172 585 minecraft:white_concrete
fill 428 171 569 429 172 570 minecraft:white_concrete
fill 428 171 586 429 172 587 minecraft:white_concrete
fill 429 171 568 430 172 568 minecraft:white_concrete
fill 429 171 571 429 172 571 minecraft:white_concrete
fill 429 171 585 429 172 585 minecraft:white_concrete
fill 429 171 588 430 172 588 minecraft:white_concrete
fill 430 171 566 431 172 567 minecraft:white_concrete
fill 430 171 569 430 172 569 minecraft:white_concrete
fill 430 171 587 430 172 587 minecraft:white_concrete
fill 430 171 589 431 172 590 minecraft:white_concrete
fill 431 171 565 433 172 565 minecraft:white_concrete
fill 431 171 591 433 172 591 minecraft:white_concrete
fill 432 171 564 435 172 564 minecraft:white_concrete
fill 432 171 566 432 172 566 minecraft:white_concrete
fill 432 171 590 432 172 590 minecraft:white_concrete
fill 432 171 592 435 172 592 minecraft:white_concrete
setblock 434 171 560 minecraft:light[level=14]
fill 434 171 563 437 172 563 minecraft:white_concrete
setblock 434 171 568 minecraft:light[level=14]
setblock 434 171 576 minecraft:light[level=14]
setblock 434 171 584 minecraft:light[level=14]
fill 434 171 593 437 172 593 minecraft:white_concrete
fill 435 171 562 439 172 562 minecraft:white_concrete
fill 435 171 594 439 172 594 minecraft:white_concrete
fill 437 171 561 451 172 561 minecraft:white_concrete
fill 437 171 595 451 172 595 minecraft:white_concrete
fill 440 171 560 448 172 560 minecraft:white_concrete
fill 440 171 596 448 172 596 minecraft:white_concrete
setblock 442 171 568 minecraft:light[level=14]
setblock 442 171 576 minecraft:light[level=14]
setblock 442 171 584 minecraft:light[level=14]
setblock 442 171 592 minecraft:light[level=14]
fill 449 171 562 453 172 562 minecraft:white_concrete
fill 449 171 594 453 172 594 minecraft:white_concrete
setblock 450 171 560 minecraft:light[level=14]
setblock 450 171 568 minecraft:light[level=14]
setblock 450 171 576 minecraft:light[level=14]
setblock 450 171 584 minecraft:light[level=14]
setblock 450 171 592 minecraft:light[level=14]
fill 451 171 563 454 172 563 minecraft:white_concrete
fill 451 171 593 454 172 593 minecraft:white_concrete
fill 453 171 564 456 172 564 minecraft:white_concrete
fill 453 171 592 456 172 592 minecraft:white_concrete
fill 454 171 590 454 172 591 minecraft:lime_concrete
fill 455 171 565 457 172 565 minecraft:white_concrete
fill 455 171 591 457 172 591 minecraft:white_concrete
fill 456 171 566 458 172 566 minecraft:white_concrete
fill 456 171 590 458 172 590 minecraft:white_concrete
fill 457 171 567 458 172 567 minecraft:white_concrete
fill 457 171 589 458 172 589 minecraft:white_concrete
setblock 458 171 560 minecraft:light[level=14]
fill 458 171 568 459 172 569 minecraft:white_concrete
setblock 458 171 576 minecraft:light[level=14]
setblock 458 171 584 minecraft:light[level=14]
fill 458 171 587 459 172 588 minecraft:white_concrete
setblock 458 171 592 minecraft:light[level=14]
fill 459 171 570 460 172 571 minecraft:white_concrete
fill 459 171 585 460 172 586 minecraft:white_concrete
fill 460 171 569 460 172 569 minecraft:white_concrete
fill 460 171 572 461 172 573 minecraft:white_concrete
fill 460 171 583 461 172 584 minecraft:white_concrete
fill 460 171 587 460 172 587 minecraft:white_concrete
fill 461 171 571 461 172 571 minecraft:white_concrete
fill 461 171 574 462 172 582 minecraft:white_concrete
fill 461 171 585 461 172 585 minecraft:white_concrete
fill 423 172 558 423 200 561 minecraft:lime_concrete
fill 423 172 562 423 177 562 minecraft:sea_lantern
fill 423 172 563 423 196 569 minecraft:lime_concrete
fill 423 172 570 423 177 570 minecraft:sea_lantern
fill 423 172 571 423 196 574 minecraft:lime_concrete
fill 423 172 576 423 197 577 minecraft:lime_concrete
fill 423 172 578 423 177 578 minecraft:sea_lantern
fill 423 172 580 423 197 585 minecraft:lime_concrete
fill 423 172 586 423 177 586 minecraft:sea_lantern
fill 423 172 587 423 196 593 minecraft:lime_concrete
fill 423 172 594 423 177 594 minecraft:sea_lantern
fill 423 172 595 423 198 598 minecraft:lime_concrete
fill 424 172 557 429 197 557 minecraft:lime_concrete
fill 425 172 599 425 200 599 minecraft:lime_concrete
fill 426 172 599 426 177 599 minecraft:sea_lantern
fill 427 172 599 429 200 599 minecraft:lime_concrete
fill 430 172 557 430 177 557 minecraft:sea_lantern
fill 434 172 599 434 177 599 minecraft:sea_lantern
fill 438 172 557 438 177 557 minecraft:sea_lantern
fill 439 172 557 439 198 557 minecraft:lime_concrete
fill 442 172 599 442 177 599 minecraft:sea_lantern
fill 443 172 557 445 200 557 minecraft:lime_concrete
fill 443 172 599 449 196 599 minecraft:lime_concrete
fill 446 172 557 446 177 557 minecraft:sea_lantern
fill 450 172 599 450 177 599 minecraft:sea_lantern
fill 454 172 557 454 177 557 minecraft:sea_lantern
fill 458 172 599 458 177 599 minecraft:sea_lantern
fill 462 172 557 462 177 557 minecraft:sea_lantern
fill 463 172 557 463 197 557 minecraft:lime_concrete
fill 465 172 558 465 196 561 minecraft:lime_concrete
fill 465 172 562 465 177 562 minecraft:sea_lantern
fill 465 172 563 465 197 569 minecraft:lime_concrete
fill 465 172 570 465 177 570 minecraft:sea_lantern
fill 465 172 571 465 196 575 minecraft:lime_concrete
fill 465 172 577 465 196 577 minecraft:lime_concrete
fill 465 172 578 465 177 578 minecraft:sea_lantern
fill 465 172 579 465 198 579 minecraft:lime_concrete
fill 465 172 586 465 177 586 minecraft:sea_lantern
fill 465 172 587 465 200 587 minecraft:lime_concrete
fill 465 172 593 465 200 593 minecraft:lime_concrete
fill 465 172 594 465 177 594 minecraft:sea_lantern
fill 426 173 574 426 173 582 minecraft:sea_lantern
fill 427 173 571 427 173 573 minecraft:sea_lantern
fill 427 173 583 427 173 585 minecraft:sea_lantern
fill 428 173 569 428 173 570 minecraft:sea_lantern
fill 428 173 586 428 173 587 minecraft:sea_lantern
setblock 429 173 568 minecraft:sea_lantern
setblock 429 173 588 minecraft:sea_lantern
fill 430 173 566 430 173 567 minecraft:sea_lantern
fill 430 173 589 430 173 590 minecraft:sea_lantern
fill 431 173 565 431 173 566 minecraft:sea_lantern
fill 431 173 590 431 173 591 minecraft:sea_lantern
fill 432 173 564 432 173 565 minecraft:sea_lantern
fill 432 173 591 432 173 592 minecraft:sea_lantern
setblock 433 173 564 minecraft:sea_lantern
setblock 433 173 592 minecraft:sea_lantern
setblock 434 173 563 minecraft:sea_lantern
setblock 434 173 593 minecraft:sea_lantern
fill 435 173 562 436 173 562 minecraft:sea_lantern
fill 435 173 594 436 173 594 minecraft:sea_lantern
fill 437 173 561 439 173 561 minecraft:sea_lantern
fill 437 173 595 439 173 595 minecraft:sea_lantern
fill 440 173 560 448 173 560 minecraft:sea_lantern
fill 440 173 596 448 173 596 minecraft:sea_lantern
fill 448 173 569 449 174 570 minecraft:yellow_concrete
fill 449 173 595 451 173 595 minecraft:sea_lantern
fill 452 173 594 453 173 594 minecraft:sea_lantern
setblock 454 173 593 minecraft:sea_lantern
fill 452 174 562 454 175 562 minecraft:blue_concrete
fill 453 174 561 454 175 561 minecraft:blue_concrete
fill 423 178 562 423 185 562 minecraft:lime_concrete
fill 423 178 570 423 185 570 minecraft:lime_concrete
fill 423 178 578 423 185 578 minecraft:lime_concrete
fill 423 178 586 423 185 586 minecraft:lime_concrete
fill 423 178 594 423 185 594 minecraft:lime_concrete
fill 426 178 599 426 185 599 minecraft:lime_concrete
fill 430 178 557 430 185 557 minecraft:lime_concrete
fill 434 178 599 434 185 599 minecraft:lime_concrete
fill 438 178 557 438 185 557 minecraft:lime_concrete
fill 442 178 599 442 185 599 minecraft:lime_concrete
fill 446 178 557 446 185 557 minecraft:lime_concrete
fill 450 178 599 450 185 599 minecraft:lime_concrete
fill 454 178 557 454 185 557 minecraft:lime_concrete
fill 458 178 599 458 185 599 minecraft:lime_concrete
fill 462 178 557 462 185 557 minecraft:lime_concrete
fill 465 178 562 465 185 562 minecraft:lime_concrete
fill 465 178 570 465 185 570 minecraft:lime_concrete
fill 465 178 578 465 185 578 minecraft:lime_concrete
fill 465 178 586 465 185 586 minecraft:lime_concrete
fill 465 178 594 465 185 594 minecraft:lime_concrete
setblock 426 179 560 minecraft:light[level=14]
setblock 426 179 568 minecraft:light[level=14]
setblock 426 179 576 minecraft:light[level=14]
setblock 426 179 584 minecraft:light[level=14]
setblock 426 179 592 minecraft:light[level=14]
setblock 434 179 560 minecraft:light[level=14]
setblock 434 179 568 minecraft:light[level=14]
setblock 434 179 576 minecraft:light[level=14]
setblock 434 179 584 minecraft:light[level=14]
setblock 434 179 592 minecraft:light[level=14]
setblock 442 179 560 minecraft:light[level=14]
setblock 442 179 568 minecraft:light[level=14]
setblock 442 179 576 minecraft:light[level=14]
setblock 442 179 584 minecraft:light[level=14]
setblock 442 179 592 minecraft:light[level=14]
setblock 450 179 560 minecraft:light[level=14]
setblock 450 179 568 minecraft:light[level=14]
setblock 450 179 576 minecraft:light[level=14]
setblock 450 179 584 minecraft:light[level=14]
setblock 450 179 592 minecraft:light[level=14]
setblock 458 179 560 minecraft:light[level=14]
setblock 458 179 568 minecraft:light[level=14]
setblock 458 179 576 minecraft:light[level=14]
setblock 458 179 584 minecraft:light[level=14]
setblock 458 179 592 minecraft:light[level=14]
fill 424 182 558 424 183 563 minecraft:white_concrete
fill 424 182 566 425 182 571 minecraft:white_concrete
fill 424 182 574 425 182 579 minecraft:white_concrete
fill 424 182 582 425 182 587 minecraft:white_concrete
fill 424 182 590 425 182 595 minecraft:white_concrete
fill 424 182 598 429 183 598 minecraft:white_concrete
fill 425 182 559 425 182 565 minecraft:white_concrete
fill 425 182 572 425 182 573 minecraft:white_concrete
fill 425 182 580 425 182 581 minecraft:white_concrete
fill 425 182 588 425 182 589 minecraft:white_concrete
fill 425 182 596 425 182 597 minecraft:white_concrete
fill 426 182 559 463 182 559 minecraft:white_concrete
fill 426 182 597 464 182 597 minecraft:white_concrete
fill 427 182 558 432 183 558 minecraft:white_concrete
fill 432 182 598 437 183 598 minecraft:white_concrete
fill 435 182 558 440 183 558 minecraft:white_concrete
fill 440 182 598 445 183 598 minecraft:white_concrete
fill 443 182 558 448 183 558 minecraft:white_concrete
fill 448 182 598 453 183 598 minecraft:white_concrete
fill 451 182 558 456 183 558 minecraft:white_concrete
fill 456 182 598 461 183 598 minecraft:white_concrete
fill 459 182 558 464 183 558 minecraft:white_concrete
fill 463 182 560 463 182 596 minecraft:white_concrete
fill 464 182 561 464 183 566 minecraft:white_concrete
fill 464 182 569 464 183 574 minecraft:white_concrete
fill 464 182 577 464 183 582 minecraft:white_concrete
fill 464 182 585 464 183 590 minecraft:white_concrete
fill 464 182 593 464 183 596 minecraft:white_concrete
fill 464 182 598 464 183 598 minecraft:white_concrete
fill 424 183 566 424 183 571 minecraft:white_concrete
fill 424 183 574 424 183 579 minecraft:white_concrete
fill 424 183 582 424 183 587 minecraft:white_concrete
fill 424 183 590 424 183 595 minecraft:white_concrete
setblock 464 183 597 minecraft:white_concrete
fill 454 184 569 454 185 570 minecraft:blue_concrete
fill 423 186 562 423 191 562 minecraft:sea_lantern
fill 423 186 570 423 191 570 minecraft:sea_lantern
fill 423 186 578 423 191 578 minecraft:sea_lantern
fill 423 186 586 423 191 586 minecraft:sea_lantern
fill 423 186 594 423 191 594 minecraft:sea_lantern
fill 426 186 599 426 191 599 minecraft:sea_lantern
fill 430 186 557 430 191 557 minecraft:sea_lantern
fill 434 186 599 434 191 599 minecraft:sea_lantern
fill 438 186 557 438 191 557 minecraft:sea_lantern
fill 442 186 599 442 191 599 minecraft:sea_lantern
fill 446 186 557 446 191 557 minecraft:sea_lantern
fill 450 186 599 450 191 599 minecraft:sea_lantern
fill 454 186 557 454 191 557 minecraft:sea_lantern
fill 458 186 599 458 191 599 minecraft:sea_lantern
fill 462 186 557 462 191 557 minecraft:sea_lantern
fill 465 186 562 465 191 562 minecraft:sea_lantern
fill 465 186 570 465 191 570 minecraft:sea_lantern
fill 465 186 578 465 191 578 minecraft:sea_lantern
fill 465 186 586 465 191 586 minecraft:sea_lantern
fill 465 186 594 465 191 594 minecraft:sea_lantern
setblock 426 187 560 minecraft:light[level=14]
setblock 426 187 568 minecraft:light[level=14]
setblock 426 187 576 minecraft:light[level=14]
setblock 426 187 584 minecraft:light[level=14]
setblock 426 187 592 minecraft:light[level=14]
setblock 434 187 560 minecraft:light[level=14]
setblock 434 187 568 minecraft:light[level=14]
setblock 434 187 576 minecraft:light[level=14]
setblock 434 187 584 minecraft:light[level=14]
setblock 434 187 592 minecraft:light[level=14]
setblock 442 187 560 minecraft:light[level=14]
setblock 442 187 568 minecraft:light[level=14]
setblock 442 187 576 minecraft:light[level=14]
setblock 442 187 584 minecraft:light[level=14]
setblock 442 187 592 minecraft:light[level=14]
setblock 450 187 560 minecraft:light[level=14]
setblock 450 187 568 minecraft:light[level=14]
setblock 450 187 576 minecraft:light[level=14]
setblock 450 187 584 minecraft:light[level=14]
setblock 450 187 592 minecraft:light[level=14]
setblock 458 187 560 minecraft:light[level=14]
setblock 458 187 568 minecraft:light[level=14]
setblock 458 187 576 minecraft:light[level=14]
setblock 458 187 584 minecraft:light[level=14]
setblock 458 187 592 minecraft:light[level=14]
fill 433 189 569 433 190 569 minecraft:red_concrete
fill 433 190 567 434 191 568 minecraft:orange_concrete
fill 435 190 567 435 191 567 minecraft:orange_concrete
fill 435 191 594 435 192 594 minecraft:purple_concrete
fill 423 192 562 423 200 562 minecraft:lime_concrete
fill 423 192 570 423 200 570 minecraft:lime_concrete
fill 423 192 578 423 197 578 minecraft:lime_concrete
fill 423 192 586 423 200 586 minecraft:lime_concrete
fill 423 192 594 423 200 594 minecraft:lime_concrete
fill 426 192 599 426 200 599 minecraft:lime_concrete
fill 430 192 557 430 200 557 minecraft:lime_concrete
fill 434 192 599 434 200 599 minecraft:lime_concrete
fill 438 192 557 438 200 557 minecraft:lime_concrete
fill 442 192 599 442 200 599 minecraft:lime_concrete
fill 446 192 557 446 200 557 minecraft:lime_concrete
fill 450 192 599 450 200 599 minecraft:lime_concrete
fill 454 192 557 454 198 557 minecraft:lime_concrete
fill 458 192 599 458 200 599 minecraft:lime_concrete
fill 462 192 557 462 200 557 minecraft:lime_concrete
fill 465 192 562 465 200 562 minecraft:lime_concrete
fill 465 192 570 465 200 570 minecraft:lime_concrete
fill 465 192 578 465 200 578 minecraft:lime_concrete
fill 465 192 586 465 200 586 minecraft:lime_concrete
fill 465 192 594 465 200 594 minecraft:lime_concrete
setblock 426 195 560 minecraft:light[level=14]
setblock 426 195 568 minecraft:light[level=14]
setblock 426 195 576 minecraft:light[level=14]
setblock 426 195 584 minecraft:light[level=14]
setblock 426 195 592 minecraft:light[level=14]
setblock 434 195 560 minecraft:light[level=14]
setblock 434 195 568 minecraft:light[level=14]
setblock 434 195 576 minecraft:light[level=14]
setblock 434 195 584 minecraft:light[level=14]
setblock 434 195 592 minecraft:light[level=14]
setblock 442 195 560 minecraft:light[level=14]
setblock 442 195 568 minecraft:light[level=14]
setblock 442 195 576 minecraft:light[level=14]
setblock 442 195 584 minecraft:light[level=14]
setblock 442 195 592 minecraft:light[level=14]
setblock 450 195 560 minecraft:light[level=14]
setblock 450 195 568 minecraft:light[level=14]
setblock 450 195 576 minecraft:light[level=14]
setblock 450 195 584 minecraft:light[level=14]
setblock 450 195 592 minecraft:light[level=14]
setblock 458 195 560 minecraft:light[level=14]
setblock 458 195 568 minecraft:light[level=14]
setblock 458 195 576 minecraft:light[level=14]
setblock 458 195 584 minecraft:light[level=14]
setblock 458 195 592 minecraft:light[level=14]
fill 423 197 563 423 200 566 minecraft:lime_concrete
setblock 423 197 567 minecraft:yellow_concrete
fill 423 197 568 423 201 569 minecraft:lime_concrete
fill 423 197 571 423 197 572 minecraft:lime_concrete
setblock 423 197 573 minecraft:yellow_concrete
fill 423 197 574 423 201 574 minecraft:lime_concrete
setblock 423 197 575 minecraft:yellow_concrete
fill 423 197 587 423 200 587 minecraft:lime_concrete
setblock 423 197 588 minecraft:yellow_concrete
fill 423 197 589 423 197 593 minecraft:lime_concrete
setblock 432 197 557 minecraft:yellow_concrete
fill 433 197 557 437 197 557 minecraft:lime_concrete
fill 443 197 599 444 200 599 minecraft:lime_concrete
setblock 445 197 599 minecraft:yellow_concrete
fill 446 197 599 447 200 599 minecraft:lime_concrete
setblock 448 197 599 minecraft:yellow_concrete
fill 449 197 599 449 200 599 minecraft:lime_concrete
setblock 457 197 557 minecraft:yellow_concrete
fill 458 197 557 460 197 557 minecraft:lime_concrete
setblock 459 197 599 minecraft:yellow_concrete
setblock 461 197 557 minecraft:yellow_concrete
fill 465 197 558 465 198 560 minecraft:lime_concrete
setblock 465 197 561 minecraft:yellow_concrete
fill 465 197 571 465 200 572 minecraft:lime_concrete
setblock 465 197 573 minecraft:yellow_concrete
fill 465 197 574 465 200 575 minecraft:lime_concrete
setblock 465 197 577 minecraft:yellow_concrete
setblock 465 197 583 minecraft:yellow_concrete
setblock 465 197 595 minecraft:yellow_concrete
fill 465 197 596 465 197 598 minecraft:lime_concrete
fill 423 198 567 423 200 567 minecraft:lime_concrete
setblock 423 198 571 minecraft:yellow_concrete
fill 423 198 572 423 200 573 minecraft:lime_concrete
fill 423 198 575 423 200 575 minecraft:lime_concrete
setblock 423 198 576 minecraft:yellow_concrete
fill 423 198 577 423 200 577 minecraft:lime_concrete
setblock 423 198 578 minecraft:yellow_concrete
fill 423 198 580 423 198 582 minecraft:lime_concrete
setblock 423 198 583 minecraft:yellow_concrete
fill 423 198 584 423 200 585 minecraft:lime_concrete
fill 423 198 588 423 198 590 minecraft:lime_concrete
setblock 423 198 591 minecraft:yellow_concrete
fill 423 198 592 423 198 593 minecraft:lime_concrete
setblock 423 198 599 minecraft:yellow_concrete
fill 424 198 557 428 200 557 minecraft:lime_concrete
setblock 429 198 557 minecraft:yellow_concrete
setblock 431 198 557 minecraft:yellow_concrete
fill 432 198 557 434 200 557 minecraft:lime_concrete
setblock 435 198 557 minecraft:yellow_concrete
fill 436 198 557 437 200 557 minecraft:lime_concrete
fill 445 198 599 445 200 599 minecraft:lime_concrete
fill 448 198 599 448 200 599 minecraft:lime_concrete
setblock 454 198 599 minecraft:yellow_concrete
fill 455 198 599 456 200 599 minecraft:lime_concrete
fill 457 198 557 459 198 557 minecraft:lime_concrete
fill 459 198 599 459 200 599 minecraft:lime_concrete
setblock 460 198 557 minecraft:yellow_concrete
fill 461 198 557 461 200 557 minecraft:lime_concrete
setblock 463 198 557 minecraft:yellow_concrete
setblock 465 198 557 minecraft:yellow_concrete
fill 465 198 561 465 200 561 minecraft:lime_concrete
setblock 465 198 563 minecraft:yellow_concrete
fill 465 198 564 465 200 569 minecraft:lime_concrete
fill 465 198 573 465 200 573 minecraft:lime_concrete
fill 465 198 577 465 200 577 minecraft:lime_concrete
fill 465 198 583 465 200 583 minecraft:lime_concrete
setblock 465 198 584 minecraft:yellow_concrete
fill 465 198 595 465 200 597 minecraft:lime_concrete
setblock 465 198 598 minecraft:yellow_concrete
fill 423 199 571 423 200 571 minecraft:lime_concrete
fill 423 199 576 423 200 576 minecraft:lime_concrete
fill 423 199 578 423 200 578 minecraft:lime_concrete
setblock 423 199 579 minecraft:yellow_concrete
fill 423 199 580 423 200 580 minecraft:lime_concrete
setblock 423 199 581 minecraft:yellow_concrete
fill 423 199 582 423 200 583 minecraft:lime_concrete
setblock 423 199 588 minecraft:yellow_concrete
fill 423 199 589 423 200 592 minecraft:lime_concrete
setblock 423 199 593 minecraft:yellow_concrete
fill 423 199 595 423 200 597 minecraft:lime_concrete
setblock 423 199 598 minecraft:yellow_concrete
fill 423 199 599 423 200 599 minecraft:lime_concrete
fill 429 199 557 429 200 557 minecraft:lime_concrete
fill 431 199 557 431 200 557 minecraft:lime_concrete
fill 435 199 557 435 200 557 minecraft:lime_concrete
setblock 439 199 557 minecraft:yellow_concrete
fill 440 199 582 442 199 584 minecraft:redstone_block
fill 444 199 574 446 199 576 minecraft:redstone_block
fill 447 199 557 447 200 557 minecraft:lime_concrete
fill 448 199 557 449 199 557 minecraft:yellow_concrete
fill 448 199 582 450 199 584 minecraft:redstone_block
fill 450 199 557 451 200 557 minecraft:lime_concrete
setblock 454 199 557 minecraft:yellow_concrete
fill 454 199 599 454 200 599 minecraft:lime_concrete
setblock 457 199 557 minecraft:yellow_concrete
fill 458 199 557 460 200 557 minecraft:lime_concrete
fill 460 199 599 462 200 599 minecraft:lime_concrete
fill 463 199 557 463 200 557 minecraft:lime_concrete
setblock 463 199 599 minecraft:yellow_concrete
fill 464 199 599 465 200 599 minecraft:lime_concrete
fill 465 199 557 465 200 559 minecraft:lime_concrete
setblock 465 199 560 minecraft:yellow_concrete
fill 465 199 563 465 201 563 minecraft:lime_concrete
setblock 465 199 579 minecraft:yellow_concrete
fill 465 199 584 465 200 584 minecraft:lime_concrete
setblock 465 199 588 minecraft:yellow_concrete
fill 465 199 589 465 201 589 minecraft:lime_concrete
setblock 465 199 590 minecraft:yellow_concrete
fill 465 199 591 465 200 591 minecraft:lime_concrete
fill 465 199 598 465 200 598 minecraft:lime_concrete
fill 423 200 579 423 201 579 minecraft:lime_concrete
setblock 423 200 581 minecraft:lime_concrete
setblock 423 200 588 minecraft:lime_concrete
setblock 423 200 593 minecraft:lime_concrete
setblock 423 200 598 minecraft:lime_concrete
fill 432 200 574 439 201 574 minecraft:lime_concrete
fill 432 200 586 439 201 586 minecraft:lime_concrete
fill 433 200 575 443 200 576 minecraft:lime_concrete
fill 433 200 584 439 200 585 minecraft:lime_concrete
fill 434 200 577 451 200 577 minecraft:lime_concrete
fill 434 200 583 439 200 583 minecraft:lime_concrete
fill 435 200 578 456 200 578 minecraft:lime_concrete
fill 435 200 582 439 200 582 minecraft:lime_concrete
fill 437 200 579 443 200 579 minecraft:lime_concrete
fill 437 200 581 443 200 581 minecraft:lime_concrete
setblock 439 200 557 minecraft:lime_concrete
fill 439 200 580 443 200 580 minecraft:lime_concrete
fill 440 200 585 452 200 585 minecraft:lime_concrete
fill 441 200 567 443 200 574 minecraft:lime_concrete
fill 441 200 586 443 200 593 minecraft:lime_concrete
fill 442 200 566 442 201 566 minecraft:lime_concrete
fill 442 200 594 442 201 594 minecraft:lime_concrete
fill 443 200 582 447 200 584 minecraft:lime_concrete
fill 444 200 568 444 200 573 minecraft:lime_concrete
fill 444 200 586 444 200 592 minecraft:lime_concrete
fill 445 200 570 445 200 573 minecraft:lime_concrete
fill 445 200 586 445 200 590 minecraft:lime_concrete
fill 446 200 572 446 200 573 minecraft:lime_concrete
fill 446 200 586 446 201 588 minecraft:lime_concrete
fill 447 200 573 451 200 576 minecraft:lime_concrete
fill 447 200 579 458 200 581 minecraft:lime_concrete
fill 447 200 586 453 200 587 minecraft:lime_concrete
fill 448 200 557 449 200 557 minecraft:lime_concrete
fill 448 200 572 453 200 572 minecraft:lime_concrete
fill 448 200 588 453 200 588 minecraft:lime_concrete
fill 449 200 571 454 201 571 minecraft:lime_concrete
fill 449 200 589 454 201 589 minecraft:lime_concrete
fill 451 200 570 454 201 570 minecraft:lime_concrete
fill 451 200 582 451 200 584 minecraft:lime_concrete
fill 451 200 590 454 201 590 minecraft:lime_concrete
fill 452 200 569 454 201 569 minecraft:lime_concrete
fill 452 200 573 452 201 575 minecraft:lime_concrete
fill 452 200 582 456 201 582 minecraft:lime_concrete
fill 452 200 591 454 201 591 minecraft:lime_concrete
fill 453 200 573 453 201 574 minecraft:lime_concrete
setblock 454 200 557 minecraft:lime_concrete
fill 457 200 557 457 201 557 minecraft:lime_concrete
fill 459 200 580 460 201 580 minecraft:lime_concrete
setblock 463 200 599 minecraft:lime_concrete
setblock 465 200 560 minecraft:lime_concrete
setblock 465 200 579 minecraft:lime_concrete
fill 465 200 588 465 201 588 minecraft:lime_concrete
setblock 465 200 590 minecraft:lime_concrete
fill 423 201 557 423 201 558 minecraft:yellow_concrete
setblock 423 201 559 minecraft:lime_concrete
fill 423 201 560 423 201 562 minecraft:yellow_concrete
setblock 423 201 563 minecraft:lime_concrete
fill 423 201 564 423 236 564 minecraft:yellow_concrete
setblock 423 201 565 minecraft:lime_concrete
fill 423 201 566 423 201 567 minecraft:yellow_concrete
fill 423 201 570 423 202 573 minecraft:yellow_concrete
fill 423 201 575 423 202 578 minecraft:yellow_concrete
fill 423 201 580 423 236 582 minecraft:yellow_concrete
fill 423 201 583 423 202 583 minecraft:lime_concrete
fill 423 201 584 423 201 591 minecraft:yellow_concrete
setblock 423 201 592 minecraft:lime_concrete
fill 423 201 593 423 204 596 minecraft:yellow_concrete
setblock 423 201 597 minecraft:lime_concrete
fill 423 201 598 423 236 599 minecraft:yellow_concrete
fill 424 201 557 426 232 557 minecraft:yellow_concrete
fill 424 201 558 431 201 598 minecraft:black_concrete
fill 424 201 599 442 201 599 minecraft:yellow_concrete
setblock 427 201 557 minecraft:lime_concrete
fill 428 201 557 435 201 557 minecraft:yellow_concrete
fill 432 201 558 440 201 573 minecraft:black_concrete
fill 432 201 575 432 201 585 minecraft:black_concrete
fill 432 201 587 440 201 598 minecraft:black_concrete
fill 433 201 575 435 201 576 minecraft:lime_concrete
fill 433 201 577 433 201 583 minecraft:black_concrete
fill 433 201 584 435 201 585 minecraft:lime_concrete
fill 434 201 577 436 201 577 minecraft:lime_concrete
fill 434 201 578 434 201 582 minecraft:black_concrete
fill 434 201 583 436 201 583 minecraft:lime_concrete
fill 435 201 578 437 201 578 minecraft:lime_concrete
fill 435 201 579 436 201 581 minecraft:black_concrete
fill 435 201 582 437 201 582 minecraft:lime_concrete
setblock 436 201 557 minecraft:lime_concrete
fill 436 201 575 441 201 575 minecraft:lime_concrete
fill 436 201 576 442 201 576 minecraft:light_blue_concrete
fill 436 201 584 438 201 584 minecraft:light_blue_concrete
fill 436 201 585 438 201 585 minecraft:lime_concrete
fill 437 201 557 456 201 557 minecraft:yellow_concrete
fill 437 201 577 442 201 577 minecraft:light_blue_concrete
fill 437 201 579 438 201 579 minecraft:lime_concrete
fill 437 201 580 438 201 580 minecraft:black_concrete
fill 437 201 581 438 201 581 minecraft:lime_concrete
fill 437 201 583 438 201 583 minecraft:light_blue_concrete
fill 438 201 578 441 201 578 minecraft:light_blue_concrete
setblock 438 201 582 minecraft:light_blue_concrete
fill 439 201 579 441 201 579 minecraft:light_blue_concrete
fill 439 201 580 440 201 580 minecraft:lime_concrete
fill 439 201 581 439 201 585 minecraft:sea_lantern
setblock 440 201 574 minecraft:black_concrete
fill 440 201 581 442 201 581 minecraft:sea_lantern
fill 440 201 582 442 201 584 minecraft:black_concrete
fill 440 201 585 443 201 585 minecraft:sea_lantern
setblock 440 201 586 minecraft:black_concrete
fill 441 201 558 441 201 566 minecraft:black_concrete
fill 441 201 567 441 201 574 minecraft:lime_concrete
fill 441 201 580 442 201 580 minecraft:magenta_concrete
fill 441 201 586 441 201 593 minecraft:lime_concrete
fill 441 201 594 441 201 598 minecraft:black_concrete
fill 442 201 558 464 201 565 minecraft:black_concrete
fill 442 201 567 442 201 571 minecraft:lime_concrete
fill 442 201 572 442 201 575 minecraft:light_blue_concrete
fill 442 201 578 442 201 579 minecraft:magenta_concrete
fill 442 201 586 444 201 588 minecraft:light_blue_concrete
fill 442 201 589 442 201 593 minecraft:lime_concrete
fill 442 201 595 464 201 598 minecraft:black_concrete
fill 443 201 566 464 201 566 minecraft:black_concrete
fill 443 201 567 443 201 570 minecraft:lime_concrete
fill 443 201 571 443 201 572 minecraft:light_blue_concrete
fill 443 201 573 443 201 578 minecraft:sea_lantern
fill 443 201 579 443 201 581 minecraft:shroomlight
fill 443 201 582 443 201 584 minecraft:sea_lantern
setblock 443 201 589 minecraft:light_blue_concrete
fill 443 201 590 443 201 593 minecraft:lime_concrete
fill 443 201 594 464 201 594 minecraft:black_concrete
fill 443 201 599 443 202 599 minecraft:lime_concrete
fill 444 201 567 464 201 567 minecraft:black_concrete
fill 444 201 568 444 201 571 minecraft:lime_concrete
setblock 444 201 572 minecraft:light_blue_concrete
fill 444 201 573 447 201 573 minecraft:sea_lantern
fill 444 201 574 446 201 576 minecraft:black_concrete
fill 444 201 577 447 201 577 minecraft:sea_lantern
fill 444 201 578 446 201 578 minecraft:shroomlight
fill 444 201 582 446 201 582 minecraft:shroomlight
fill 444 201 583 446 201 583 minecraft:magenta_concrete
fill 444 201 584 444 201 585 minecraft:light_blue_concrete
fill 444 201 589 444 201 592 minecraft:lime_concrete
fill 444 201 593 464 201 593 minecraft:black_concrete
fill 444 201 599 452 204 599 minecraft:yellow_concrete
fill 445 201 568 451 201 569 minecraft:black_concrete
fill 445 201 570 445 201 572 minecraft:lime_concrete
setblock 445 201 584 minecraft:magenta_concrete
fill 445 201 585 445 201 587 minecraft:light_blue_concrete
fill 445 201 588 445 201 590 minecraft:lime_concrete
fill 445 201 591 451 201 592 minecraft:black_concrete
fill 446 201 570 448 201 571 minecraft:black_concrete
setblock 446 201 572 minecraft:lime_concrete
setblock 446 201 584 minecraft:light_blue_concrete
setblock 446 201 585 minecraft:lime_concrete
fill 446 201 589 448 201 590 minecraft:black_concrete
setblock 447 201 572 minecraft:black_concrete
fill 447 201 574 447 201 576 minecraft:sea_lantern
setblock 447 201 578 minecraft:sea_lantern
fill 447 201 579 447 201 581 minecraft:shroomlight
fill 447 201 582 447 201 585 minecraft:sea_lantern
fill 447 201 586 447 201 587 minecraft:lime_concrete
setblock 447 201 588 minecraft:black_concrete
fill 448 201 572 448 201 573 minecraft:lime_concrete
fill 448 201 574 450 201 577 minecraft:light_blue_concrete
fill 448 201 578 448 201 580 minecraft:magenta_concrete
fill 448 201 581 451 201 581 minecraft:sea_lantern
fill 448 201 582 450 201 584 minecraft:black_concrete
fill 448 201 585 451 201 585 minecraft:sea_lantern
fill 448 201 586 451 201 586 minecraft:light_blue_concrete
fill 448 201 587 448 201 588 minecraft:lime_concrete
fill 449 201 570 450 201 570 minecraft:black_concrete
fill 449 201 572 450 201 572 minecraft:lime_concrete
fill 449 201 573 451 201 573 minecraft:light_blue_concrete
fill 449 201 578 451 201 579 minecraft:light_blue_concrete
setblock 449 201 580 minecraft:magenta_concrete
fill 449 201 587 451 201 587 minecraft:light_blue_concrete
fill 449 201 588 450 201 588 minecraft:lime_concrete
fill 449 201 590 450 201 590 minecraft:black_concrete
fill 450 201 580 455 201 580 minecraft:light_blue_concrete
setblock 451 201 572 minecraft:light_blue_concrete
fill 451 201 574 451 201 575 minecraft:light_blue_concrete
fill 451 201 576 451 201 577 minecraft:lime_concrete
fill 451 201 582 451 201 584 minecraft:sea_lantern
setblock 451 201 588 minecraft:light_blue_concrete
fill 452 201 568 464 201 568 minecraft:black_concrete
fill 452 201 572 453 201 572 minecraft:lime_concrete
fill 452 201 576 464 201 577 minecraft:black_concrete
fill 452 201 578 456 201 578 minecraft:lime_concrete
fill 452 201 579 454 201 579 minecraft:light_blue_concrete
fill 452 201 581 454 201 581 minecraft:light_blue_concrete
fill 452 201 583 464 201 584 minecraft:black_concrete
fill 452 201 585 452 201 588 minecraft:lime_concrete
fill 452 201 592 464 201 592 minecraft:black_concrete
fill 453 201 575 464 201 575 minecraft:black_concrete
fill 453 201 585 464 201 585 minecraft:black_concrete
fill 453 201 586 453 201 588 minecraft:lime_concrete
fill 454 201 572 464 201 574 minecraft:black_concrete
fill 454 201 586 464 201 588 minecraft:black_concrete
fill 454 201 599 465 201 599 minecraft:yellow_concrete
fill 455 201 569 464 201 571 minecraft:black_concrete
fill 455 201 579 458 201 579 minecraft:lime_concrete
fill 455 201 581 458 201 581 minecraft:lime_concrete
fill 455 201 589 464 201 591 minecraft:black_concrete
fill 456 201 580 458 201 580 minecraft:lime_concrete
fill 457 201 578 464 201 578 minecraft:black_concrete
fill 457 201 582 464 201 582 minecraft:black_concrete
fill 458 201 557 465 201 557 minecraft:yellow_concrete
fill 459 201 579 464 201 579 minecraft:black_concrete
fill 459 201 581 464 201 581 minecraft:black_concrete
fill 461 201 580 464 201 580 minecraft:black_concrete
fill 465 201 558 465 204 562 minecraft:yellow_concrete
fill 465 201 564 465 201 571 minecraft:yellow_concrete
fill 465 201 572 465 203 572 minecraft:lime_concrete
fill 465 201 573 465 204 580 minecraft:yellow_concrete
fill 465 201 582 465 202 587 minecraft:yellow_concrete
fill 465 201 590 465 204 596 minecraft:yellow_concrete
setblock 465 201 597 minecraft:lime_concrete
fill 465 201 598 465 233 598 minecraft:yellow_concrete
setblock 423 202 557 minecraft:lime_concrete
fill 423 202 558 423 232 559 minecraft:yellow_concrete
setblock 423 202 560 minecraft:lime_concrete
fill 423 202 561 423 204 563 minecraft:yellow_concrete
fill 423 202 565 423 236 565 minecraft:yellow_concrete
setblock 423 202 566 minecraft:lime_concrete
fill 423 202 567 423 236 569 minecraft:yellow_concrete
setblock 423 202 574 minecraft:yellow_concrete
fill 423 202 579 423 236 579 minecraft:yellow_concrete
fill 423 202 584 423 204 586 minecraft:yellow_concrete
fill 423 202 587 423 203 587 minecraft:lime_concrete
fill 423 202 588 423 202 592 minecraft:yellow_concrete
fill 423 202 597 423 236 597 minecraft:yellow_concrete
fill 424 202 571 425 202 589 minecraft:basalt
fill 424 202 599 429 204 599 minecraft:yellow_concrete
fill 425 202 569 428 202 570 minecraft:basalt
fill 425 202 590 428 202 591 minecraft:basalt
fill 426 202 567 428 202 567 minecraft:basalt
setblock 426 202 568 minecraft:magma_block
setblock 426 202 571 minecraft:magma_block
fill 426 202 572 428 204 573 minecraft:basalt
setblock 426 202 574 minecraft:magma_block
fill 426 202 575 428 205 576 minecraft:basalt
setblock 426 202 577 minecraft:magma_block
fill 426 202 578 428 206 579 minecraft:basalt
setblock 426 202 580 minecraft:magma_block
fill 426 202 581 428 206 582 minecraft:basalt
setblock 426 202 583 minecraft:magma_block
fill 426 202 584 428 204 585 minecraft:basalt
setblock 426 202 586 minecraft:magma_block
fill 426 202 587 428 204 588 minecraft:basalt
setblock 426 202 589 minecraft:magma_block
setblock 426 202 592 minecraft:magma_block
fill 426 202 593 431 202 593 minecraft:basalt
fill 427 202 557 431 202 557 minecraft:yellow_concrete
fill 427 202 566 431 202 566 minecraft:basalt
fill 427 202 568 434 203 568 minecraft:basalt
fill 427 202 571 434 205 571 minecraft:basalt
fill 427 202 574 432 206 574 minecraft:basalt
fill 427 202 577 431 202 577 minecraft:basalt
fill 427 202 580 430 207 580 minecraft:basalt
fill 427 202 583 431 202 583 minecraft:basalt
fill 427 202 586 432 206 586 minecraft:basalt
fill 427 202 589 434 205 589 minecraft:basalt
fill 427 202 592 434 203 592 minecraft:basalt
fill 427 202 594 428 202 594 minecraft:basalt
fill 428 202 565 434 202 565 minecraft:basalt
fill 428 202 595 434 202 595 minecraft:basalt
setblock 429 202 564 minecraft:magma_block
setblock 429 202 567 minecraft:magma_block
fill 429 202 569 431 206 569 minecraft:basalt
setblock 429 202 570 minecraft:magma_block
fill 429 202 572 431 207 572 minecraft:basalt
setblock 429 202 573 minecraft:magma_block
fill 429 202 575 431 209 575 minecraft:basalt
setblock 429 202 576 minecraft:magma_block
fill 429 202 578 430 209 578 minecraft:basalt
setblock 429 202 579 minecraft:magma_block
fill 429 202 581 430 210 581 minecraft:basalt
setblock 429 202 582 minecraft:magma_block
fill 429 202 584 431 209 584 minecraft:basalt
setblock 429 202 585 minecraft:magma_block
fill 429 202 587 431 208 587 minecraft:basalt
setblock 429 202 588 minecraft:magma_block
fill 429 202 590 431 206 590 minecraft:basalt
setblock 429 202 591 minecraft:magma_block
setblock 429 202 594 minecraft:magma_block
fill 429 202 596 431 202 596 minecraft:basalt
fill 430 202 563 431 202 564 minecraft:basalt
fill 430 202 567 437 205 567 minecraft:basalt
fill 430 202 570 434 207 570 minecraft:basalt
fill 430 202 573 432 209 573 minecraft:basalt
fill 430 202 576 431 210 576 minecraft:basalt
fill 430 202 579 430 211 579 minecraft:basalt
fill 430 202 582 430 211 582 minecraft:basalt
fill 430 202 585 431 210 585 minecraft:basalt
fill 430 202 588 433 208 588 minecraft:basalt
fill 430 202 591 436 207 591 minecraft:basalt
fill 430 202 594 437 203 594 minecraft:basalt
fill 430 202 597 437 202 597 minecraft:basalt
fill 430 202 599 431 202 599 minecraft:lime_concrete
fill 431 202 562 434 202 562 minecraft:basalt
fill 431 202 598 434 202 598 minecraft:basalt
setblock 432 202 557 minecraft:lime_concrete
fill 432 202 561 437 202 561 minecraft:basalt
setblock 432 202 563 minecraft:magma_block
fill 432 202 564 437 204 564 minecraft:basalt
setblock 432 202 566 minecraft:magma_block
setblock 432 202 569 minecraft:magma_block
setblock 432 202 572 minecraft:magma_block
setblock 432 202 587 minecraft:magma_block
setblock 432 202 590 minecraft:magma_block
setblock 432 202 593 minecraft:magma_block
setblock 432 202 596 minecraft:magma_block
fill 432 202 599 442 202 599 minecraft:yellow_concrete
fill 433 202 557 437 202 557 minecraft:yellow_concrete
fill 433 202 563 440 203 563 minecraft:basalt
fill 433 202 566 440 207 566 minecraft:basalt
fill 433 202 569 436 209 569 minecraft:basalt
fill 433 202 572 433 211 572 minecraft:basalt
fill 433 202 590 434 210 590 minecraft:basalt
fill 433 202 593 439 208 593 minecraft:basalt
fill 433 202 596 440 205 596 minecraft:basalt
fill 434 202 560 440 202 560 minecraft:basalt
setblock 435 202 562 minecraft:magma_block
setblock 435 202 565 minecraft:magma_block
setblock 435 202 568 minecraft:magma_block
setblock 435 202 592 minecraft:magma_block
setblock 435 202 595 minecraft:magma_block
setblock 435 202 598 minecraft:magma_block
fill 436 202 559 443 202 559 minecraft:basalt
fill 436 202 562 443 205 562 minecraft:basalt
fill 436 202 565 443 208 565 minecraft:basalt
fill 436 202 568 437 211 568 minecraft:basalt
fill 436 202 592 437 211 592 minecraft:basalt
fill 436 202 595 443 208 595 minecraft:basalt
fill 436 202 598 443 205 598 minecraft:basalt
fill 438 202 557 438 203 557 minecraft:lime_concrete
setblock 438 202 561 minecraft:magma_block
setblock 438 202 564 minecraft:magma_block
setblock 438 202 567 minecraft:magma_block
setblock 438 202 594 minecraft:magma_block
setblock 438 202 597 minecraft:magma_block
fill 439 202 557 452 202 557 minecraft:yellow_concrete
fill 439 202 558 446 202 558 minecraft:basalt
fill 439 202 561 446 205 561 minecraft:basalt
fill 439 202 564 446 208 564 minecraft:basalt
fill 439 202 567 439 211 567 minecraft:basalt
fill 439 202 594 442 210 594 minecraft:basalt
fill 439 202 597 446 207 597 minecraft:basalt
setblock 441 202 560 minecraft:magma_block
setblock 441 202 563 minecraft:magma_block
setblock 441 202 566 minecraft:magma_block
setblock 441 202 596 minecraft:magma_block
fill 442 202 560 449 204 560 minecraft:basalt
fill 442 202 563 449 207 563 minecraft:basalt
fill 442 202 566 442 211 566 minecraft:basalt
fill 442 202 596 449 208 596 minecraft:basalt
setblock 444 202 559 minecraft:magma_block
setblock 444 202 562 minecraft:magma_block
setblock 444 202 565 minecraft:magma_block
setblock 444 202 595 minecraft:magma_block
setblock 444 202 598 minecraft:magma_block
fill 445 202 559 452 202 559 minecraft:basalt
fill 445 202 562 452 206 562 minecraft:basalt
fill 445 202 565 452 208 565 minecraft:basalt
fill 445 202 595 452 208 595 minecraft:basalt
fill 445 202 598 452 206 598 minecraft:basalt
setblock 447 202 558 minecraft:magma_block
setblock 447 202 561 minecraft:magma_block
setblock 447 202 564 minecraft:magma_block
setblock 447 202 597 minecraft:magma_block
fill 448 202 558 451 202 558 minecraft:basalt
fill 448 202 561 455 203 561 minecraft:basalt
fill 448 202 564 455 206 564 minecraft:basalt
fill 448 202 566 449 211 566 minecraft:basalt
fill 448 202 594 455 208 594 minecraft:basalt
fill 448 202 597 455 205 597 minecraft:basalt
setblock 450 202 560 minecraft:magma_block
setblock 450 202 563 minecraft:magma_block
setblock 450 202 566 minecraft:magma_block
setblock 450 202 596 minecraft:magma_block
fill 451 202 560 456 202 560 minecraft:basalt
fill 451 202 563 458 203 563 minecraft:basalt
fill 451 202 566 455 208 567 minecraft:basalt
fill 451 202 593 458 207 593 minecraft:basalt
fill 451 202 596 458 204 596 minecraft:basalt
fill 453 202 557 453 203 557 minecraft:lime_concrete
setblock 453 202 559 minecraft:magma_block
setblock 453 202 562 minecraft:magma_block
setblock 453 202 565 minecraft:magma_block
setblock 453 202 568 minecraft:magma_block
setblock 453 202 592 minecraft:magma_block
setblock 453 202 595 minecraft:magma_block
setblock 453 202 598 minecraft:magma_block
fill 453 202 599 454 236 599 minecraft:yellow_concrete
fill 454 202 557 454 204 557 minecraft:yellow_concrete
setblock 454 202 559 minecraft:basalt
fill 454 202 562 459 202 562 minecraft:basalt
fill 454 202 565 461 203 565 minecraft:basalt
fill 454 202 568 458 208 569 minecraft:basalt
fill 454 202 591 455 210 592 minecraft:basalt
fill 454 202 595 461 203 595 minecraft:basalt
fill 454 202 598 459 202 598 minecraft:basalt
setblock 455 202 557 minecraft:lime_concrete
setblock 455 202 599 minecraft:lime_concrete
fill 456 202 557 458 202 557 minecraft:yellow_concrete
setblock 456 202 561 minecraft:magma_block
setblock 456 202 564 minecraft:magma_block
fill 456 202 566 458 206 566 minecraft:basalt
setblock 456 202 567 minecraft:magma_block
setblock 456 202 570 minecraft:magma_block
fill 456 202 571 461 207 571 minecraft:basalt
fill 456 202 589 458 208 590 minecraft:basalt
setblock 456 202 591 minecraft:magma_block
fill 456 202 592 461 205 592 minecraft:basalt
setblock 456 202 594 minecraft:magma_block
setblock 456 202 597 minecraft:magma_block
fill 456 202 599 465 202 599 minecraft:yellow_concrete
fill 457 202 561 458 202 561 minecraft:basalt
fill 457 202 564 461 202 564 minecraft:basalt
fill 457 202 567 464 202 567 minecraft:basalt
fill 457 202 570 464 203 570 minecraft:basalt
fill 457 202 572 458 210 572 minecraft:basalt
fill 457 202 588 464 204 588 minecraft:basalt
fill 457 202 591 464 203 591 minecraft:basalt
fill 457 202 594 463 202 594 minecraft:basalt
fill 457 202 597 460 202 597 minecraft:basalt
fill 458 202 573 461 202 574 minecraft:basalt
fill 458 202 586 458 202 587 minecraft:basalt
fill 459 202 557 460 202 557 minecraft:lime_concrete
setblock 459 202 563 minecraft:magma_block
setblock 459 202 566 minecraft:magma_block
fill 459 202 568 461 205 568 minecraft:basalt
setblock 459 202 569 minecraft:magma_block
setblock 459 202 572 minecraft:magma_block
setblock 459 202 575 minecraft:magma_block
fill 459 202 576 461 208 577 minecraft:basalt
fill 459 202 583 461 208 583 minecraft:basalt
setblock 459 202 584 minecraft:magma_block
fill 459 202 585 461 208 586 minecraft:basalt
setblock 459 202 587 minecraft:magma_block
fill 459 202 589 461 207 589 minecraft:basalt
setblock 459 202 590 minecraft:magma_block
setblock 459 202 593 minecraft:magma_block
setblock 459 202 596 minecraft:magma_block
setblock 460 202 563 minecraft:basalt
fill 460 202 566 463 202 566 minecraft:basalt
fill 460 202 569 464 202 569 minecraft:basalt
fill 460 202 572 464 204 572 minecraft:basalt
fill 460 202 575 464 205 575 minecraft:basalt
fill 460 202 578 461 208 582 minecraft:basalt
fill 460 202 584 464 206 584 minecraft:basalt
fill 460 202 587 464 205 587 minecraft:basalt
fill 460 202 590 464 202 590 minecraft:basalt
fill 460 202 593 464 202 593 minecraft:basalt
fill 460 202 596 461 202 596 minecraft:basalt
fill 461 202 557 465 202 557 minecraft:yellow_concrete
setblock 462 202 565 minecraft:magma_block
setblock 462 202 568 minecraft:magma_block
setblock 462 202 571 minecraft:magma_block
fill 462 202 573 464 205 573 minecraft:basalt
setblock 462 202 574 minecraft:magma_block
fill 462 202 576 464 206 576 minecraft:basalt
setblock 462 202 577 minecraft:magma_block
fill 462 202 578 464 206 579 minecraft:basalt
setblock 462 202 580 minecraft:magma_block
fill 462 202 581 464 206 582 minecraft:basalt
setblock 462 202 583 minecraft:magma_block
fill 462 202 585 464 205 585 minecraft:basalt
setblock 462 202 586 minecraft:magma_block
setblock 462 202 589 minecraft:magma_block
setblock 462 202 592 minecraft:magma_block
setblock 462 202 595 minecraft:magma_block
fill 463 202 568 464 202 568 minecraft:basalt
fill 463 202 571 464 204 571 minecraft:basalt
fill 463 202 574 464 205 574 minecraft:basalt
fill 463 202 577 464 205 577 minecraft:basalt
fill 463 202 580 464 205 580 minecraft:basalt
fill 463 202 583 464 205 583 minecraft:basalt
fill 463 202 586 464 205 586 minecraft:basalt
fill 463 202 589 464 204 589 minecraft:basalt
fill 463 202 592 464 202 592 minecraft:basalt
fill 465 202 563 465 202 569 minecraft:yellow_concrete
setblock 465 202 570 minecraft:lime_concrete
fill 465 202 571 465 233 571 minecraft:yellow_concrete
fill 465 202 581 465 236 581 minecraft:yellow_concrete
fill 465 202 588 465 236 589 minecraft:yellow_concrete
fill 465 202 597 465 236 597 minecraft:yellow_concrete
fill 423 203 557 423 232 557 minecraft:yellow_concrete
fill 423 203 560 423 232 560 minecraft:yellow_concrete
fill 423 203 566 423 232 566 minecraft:yellow_concrete
fill 423 203 570 423 204 571 minecraft:yellow_concrete
fill 423 203 572 423 203 575 minecraft:lime_concrete
fill 423 203 576 423 236 577 minecraft:yellow_concrete
setblock 423 203 578 minecraft:lime_concrete
fill 423 203 583 423 232 583 minecraft:yellow_concrete
fill 423 203 588 423 232 589 minecraft:yellow_concrete
fill 423 203 590 423 203 591 minecraft:lime_concrete
fill 423 203 592 423 236 592 minecraft:yellow_concrete
fill 424 203 573 425 203 587 minecraft:basalt
fill 425 203 571 425 203 572 minecraft:basalt
setblock 425 203 588 minecraft:magma_block
fill 425 203 589 426 203 589 minecraft:basalt
setblock 426 203 560 minecraft:light[level=14]
setblock 426 203 568 minecraft:light[level=14]
fill 426 203 569 426 203 571 minecraft:basalt
fill 426 203 574 426 205 574 minecraft:basalt
fill 426 203 577 430 206 577 minecraft:basalt
fill 426 203 580 426 206 580 minecraft:basalt
fill 426 203 583 430 206 583 minecraft:basalt
fill 426 203 586 426 205 586 minecraft:basalt
fill 426 203 590 428 203 591 minecraft:basalt
setblock 426 203 592 minecraft:light[level=14]
fill 427 203 557 429 233 557 minecraft:yellow_concrete
fill 427 203 569 428 204 570 minecraft:basalt
setblock 428 203 566 minecraft:magma_block
fill 428 203 567 429 203 567 minecraft:basalt
setblock 428 203 593 minecraft:magma_block
fill 428 203 594 429 203 594 minecraft:basalt
fill 429 203 565 432 203 566 minecraft:basalt
fill 429 203 570 429 206 570 minecraft:basalt
fill 429 203 573 429 208 573 minecraft:basalt
fill 429 203 576 429 209 576 minecraft:basalt
fill 429 203 579 429 210 579 minecraft:basalt
fill 429 203 582 429 209 582 minecraft:basalt
fill 429 203 585 429 209 585 minecraft:basalt
fill 429 203 588 429 207 588 minecraft:basalt
fill 429 203 591 429 206 591 minecraft:basalt
fill 429 203 593 432 204 593 minecraft:basalt
fill 429 203 595 435 203 595 minecraft:basalt
setblock 430 203 557 minecraft:lime_concrete
fill 430 203 564 431 203 564 minecraft:basalt
fill 430 203 596 432 203 596 minecraft:basalt
fill 430 203 599 436 204 599 minecraft:yellow_concrete
fill 431 203 557 433 232 557 minecraft:yellow_concrete
fill 431 203 563 432 203 563 minecraft:basalt
setblock 431 203 577 minecraft:magma_block
fill 431 203 578 431 212 579 minecraft:basalt
setblock 431 203 580 minecraft:magma_block
fill 431 203 581 431 212 582 minecraft:basalt
setblock 431 203 583 minecraft:magma_block
fill 431 203 597 438 203 597 minecraft:basalt
fill 432 203 569 432 208 569 minecraft:basalt
fill 432 203 572 432 210 572 minecraft:basalt
fill 432 203 575 432 212 576 minecraft:basalt
fill 432 203 584 432 212 585 minecraft:basalt
fill 432 203 587 433 210 587 minecraft:basalt
fill 432 203 590 432 209 590 minecraft:basalt
fill 433 203 562 435 203 562 minecraft:basalt
fill 433 203 565 435 206 565 minecraft:basalt
fill 433 203 573 433 212 573 minecraft:basalt
fill 433 203 598 435 203 598 minecraft:basalt
setblock 434 203 557 minecraft:lime_concrete
setblock 434 203 560 minecraft:light[level=14]
setblock 434 203 561 minecraft:magma_block
fill 434 203 572 434 212 572 minecraft:basalt
setblock 434 203 576 minecraft:light[level=14]
setblock 434 203 584 minecraft:light[level=14]
setblock 434 203 588 minecraft:magma_block
fill 435 203 557 437 232 557 minecraft:yellow_concrete
fill 435 203 561 438 203 561 minecraft:basalt
fill 435 203 568 435 210 568 minecraft:basalt
fill 435 203 570 435 212 570 minecraft:basalt
fill 435 203 590 435 212 590 minecraft:basalt
fill 435 203 592 435 210 592 minecraft:basalt
setblock 436 203 560 minecraft:basalt
setblock 437 203 560 minecraft:magma_block
setblock 437 203 569 minecraft:magma_block
fill 437 203 591 437 212 591 minecraft:basalt
setblock 437 203 599 minecraft:lime_concrete
fill 438 203 559 439 203 560 minecraft:basalt
fill 438 203 564 438 208 564 minecraft:basalt
fill 438 203 567 438 210 568 minecraft:basalt
fill 438 203 592 438 212 592 minecraft:basalt
fill 438 203 594 438 210 594 minecraft:basalt
fill 438 203 599 439 234 599 minecraft:yellow_concrete
fill 439 203 557 444 233 557 minecraft:yellow_concrete
setblock 440 203 559 minecraft:magma_block
fill 440 203 560 441 204 560 minecraft:basalt
fill 440 203 567 441 212 567 minecraft:basalt
fill 440 203 593 441 212 593 minecraft:basalt
setblock 440 203 599 minecraft:lime_concrete
fill 441 203 559 448 203 559 minecraft:basalt
fill 441 203 563 441 208 563 minecraft:basalt
fill 441 203 566 441 210 566 minecraft:basalt
fill 441 203 596 441 209 596 minecraft:basalt
fill 441 203 599 443 204 599 minecraft:yellow_concrete
setblock 442 203 568 minecraft:light[level=14]
setblock 442 203 576 minecraft:light[level=14]
setblock 442 203 584 minecraft:light[level=14]
setblock 442 203 592 minecraft:light[level=14]
setblock 443 203 558 minecraft:magma_block
fill 443 203 566 445 212 566 minecraft:basalt
setblock 443 203 594 minecraft:magma_block
fill 444 203 558 447 203 558 minecraft:basalt
fill 444 203 562 444 207 562 minecraft:basalt
fill 444 203 565 444 210 565 minecraft:basalt
fill 444 203 594 444 210 595 minecraft:basalt
fill 444 203 598 444 207 598 minecraft:basalt
setblock 445 203 557 minecraft:lime_concrete
fill 445 203 594 447 212 594 minecraft:basalt
fill 446 203 557 452 204 557 minecraft:yellow_concrete
setblock 446 203 566 minecraft:magma_block
fill 447 203 561 447 206 561 minecraft:basalt
fill 447 203 564 447 209 564 minecraft:basalt
fill 447 203 566 447 212 566 minecraft:basalt
fill 447 203 597 447 208 597 minecraft:basalt
setblock 449 203 559 minecraft:magma_block
fill 449 203 567 450 212 567 minecraft:basalt
fill 449 203 593 450 212 593 minecraft:basalt
fill 450 203 559 452 203 560 minecraft:basalt
fill 450 203 563 450 208 563 minecraft:basalt
fill 450 203 566 450 210 566 minecraft:basalt
setblock 450 203 568 minecraft:light[level=14]
setblock 450 203 576 minecraft:light[level=14]
setblock 450 203 584 minecraft:light[level=14]
setblock 450 203 592 minecraft:light[level=14]
fill 450 203 596 450 209 596 minecraft:basalt
fill 452 203 568 453 210 568 minecraft:basalt
fill 452 203 592 453 210 592 minecraft:basalt
fill 453 203 560 454 203 560 minecraft:basalt
fill 453 203 562 457 203 562 minecraft:basalt
fill 453 203 565 453 208 565 minecraft:basalt
fill 453 203 569 453 212 569 minecraft:basalt
fill 453 203 591 453 212 591 minecraft:basalt
fill 453 203 595 453 208 595 minecraft:basalt
fill 453 203 598 457 203 598 minecraft:basalt
fill 455 203 557 457 232 557 minecraft:yellow_concrete
fill 455 203 570 456 210 570 minecraft:basalt
setblock 455 203 590 minecraft:magma_block
fill 455 203 599 462 204 599 minecraft:yellow_concrete
setblock 456 203 561 minecraft:basalt
fill 456 203 564 460 203 564 minecraft:basalt
fill 456 203 567 462 203 567 minecraft:basalt
fill 456 203 572 456 212 572 minecraft:basalt
fill 456 203 588 456 212 588 minecraft:basalt
fill 456 203 591 456 210 591 minecraft:basalt
fill 456 203 594 462 203 594 minecraft:basalt
fill 456 203 597 459 203 597 minecraft:basalt
fill 457 203 573 461 208 573 minecraft:basalt
fill 457 203 587 459 210 587 minecraft:basalt
setblock 458 203 557 minecraft:lime_concrete
setblock 458 203 560 minecraft:light[level=14]
setblock 458 203 574 minecraft:magma_block
fill 458 203 575 458 212 576 minecraft:basalt
fill 458 203 584 458 212 585 minecraft:basalt
setblock 458 203 586 minecraft:magma_block
fill 459 203 557 463 204 557 minecraft:yellow_concrete
setblock 459 203 563 minecraft:basalt
fill 459 203 566 462 203 566 minecraft:basalt
fill 459 203 569 463 204 569 minecraft:basalt
fill 459 203 572 459 209 572 minecraft:basalt
fill 459 203 574 459 210 575 minecraft:basalt
fill 459 203 578 459 212 582 minecraft:basalt
fill 459 203 584 459 210 584 minecraft:basalt
fill 459 203 590 463 204 590 minecraft:basalt
fill 459 203 593 462 203 593 minecraft:basalt
fill 459 203 596 460 203 596 minecraft:basalt
fill 460 203 574 462 207 574 minecraft:basalt
fill 462 203 568 463 203 568 minecraft:basalt
fill 462 203 571 462 206 571 minecraft:basalt
fill 462 203 577 462 208 577 minecraft:basalt
fill 462 203 580 462 208 580 minecraft:basalt
fill 462 203 583 462 208 583 minecraft:basalt
fill 462 203 586 462 207 586 minecraft:basalt
fill 462 203 589 462 206 589 minecraft:basalt
fill 462 203 592 463 203 592 minecraft:basalt
fill 463 203 599 464 203 599 minecraft:lime_concrete
fill 464 203 557 465 203 557 minecraft:lime_concrete
setblock 464 203 569 minecraft:magma_block
setblock 464 203 590 minecraft:magma_block
fill 465 203 563 465 236 563 minecraft:yellow_concrete
setblock 465 203 564 minecraft:lime_concrete
fill 465 203 565 465 236 565 minecraft:yellow_concrete
setblock 465 203 566 minecraft:lime_concrete
fill 465 203 567 465 204 570 minecraft:yellow_concrete
fill 465 203 582 465 236 583 minecraft:yellow_concrete
setblock 465 203 584 minecraft:lime_concrete
fill 465 203 585 465 204 587 minecraft:yellow_concrete
fill 465 203 599 465 236 599 minecraft:yellow_concrete
fill 423 204 572 423 236 575 minecraft:yellow_concrete
setblock 423 204 578 minecraft:yellow_concrete
fill 423 204 587 423 232 587 minecraft:yellow_concrete
fill 423 204 590 423 236 591 minecraft:yellow_concrete
fill 424 204 577 425 204 577 minecraft:basalt
setblock 424 204 578 minecraft:magma_block
fill 424 204 579 425 204 580 minecraft:basalt
setblock 424 204 581 minecraft:magma_block
fill 424 204 582 425 204 583 minecraft:basalt
fill 425 204 573 425 204 576 minecraft:basalt
fill 425 204 578 425 205 578 minecraft:basalt
fill 425 204 581 425 205 581 minecraft:basalt
fill 425 204 584 425 204 587 minecraft:basalt
setblock 426 204 571 minecraft:basalt
setblock 426 204 589 minecraft:basalt
fill 427 204 590 428 204 591 minecraft:basalt
fill 428 204 568 434 204 568 minecraft:basalt
fill 428 204 592 434 204 592 minecraft:basalt
fill 429 204 566 429 204 567 minecraft:basalt
setblock 429 204 594 minecraft:basalt
setblock 430 204 557 minecraft:yellow_concrete
fill 430 204 565 432 204 566 minecraft:basalt
setblock 430 204 594 minecraft:magma_block
fill 430 204 595 435 204 595 minecraft:basalt
setblock 431 204 564 minecraft:basalt
fill 431 204 577 432 211 577 minecraft:basalt
fill 431 204 580 432 204 580 minecraft:basalt
fill 431 204 583 432 211 583 minecraft:basalt
fill 431 204 594 437 205 594 minecraft:basalt
fill 431 204 596 432 204 596 minecraft:basalt
fill 432 204 578 432 213 579 minecraft:basalt
fill 432 204 581 432 213 582 minecraft:basalt
setblock 433 204 563 minecraft:magma_block
fill 433 204 574 433 213 574 minecraft:basalt
setblock 433 204 575 minecraft:magma_block
fill 433 204 585 433 213 586 minecraft:basalt
fill 433 204 597 438 204 597 minecraft:basalt
fill 434 204 557 434 236 557 minecraft:yellow_concrete
fill 434 204 562 435 204 563 minecraft:basalt
fill 434 204 573 434 213 573 minecraft:basalt
fill 434 204 587 434 211 588 minecraft:basalt
fill 434 204 598 435 204 598 minecraft:basalt
fill 435 204 571 435 212 571 minecraft:basalt
fill 435 204 589 435 212 589 minecraft:basalt
fill 436 204 561 438 204 561 minecraft:basalt
fill 436 204 563 440 206 563 minecraft:basalt
fill 436 204 570 436 212 570 minecraft:basalt
fill 436 204 590 436 212 590 minecraft:basalt
fill 437 204 569 438 204 569 minecraft:basalt
fill 437 204 599 437 236 599 minecraft:yellow_concrete
setblock 438 204 557 minecraft:yellow_concrete
fill 438 204 560 439 204 560 minecraft:basalt
fill 438 204 591 438 213 591 minecraft:basalt
fill 439 204 568 440 213 568 minecraft:basalt
fill 439 204 592 440 213 592 minecraft:basalt
fill 440 204 599 440 234 599 minecraft:yellow_concrete
fill 442 204 559 444 204 559 minecraft:basalt
fill 442 204 567 447 204 567 minecraft:basalt
setblock 442 204 593 minecraft:magma_block
fill 443 204 593 443 211 594 minecraft:basalt
fill 444 204 593 448 204 593 minecraft:basalt
fill 445 204 557 445 236 557 minecraft:yellow_concrete
setblock 445 204 559 minecraft:magma_block
fill 446 204 559 448 204 559 minecraft:basalt
fill 446 204 566 446 211 566 minecraft:basalt
fill 448 204 561 454 204 561 minecraft:basalt
setblock 448 204 567 minecraft:magma_block
setblock 450 204 560 minecraft:basalt
fill 450 204 568 451 204 568 minecraft:basalt
fill 450 204 592 451 204 592 minecraft:basalt
setblock 451 204 560 minecraft:magma_block
fill 451 204 563 457 204 563 minecraft:basalt
setblock 452 204 560 minecraft:basalt
fill 452 204 569 452 213 569 minecraft:basalt
fill 452 204 591 452 213 591 minecraft:basalt
fill 453 204 557 453 232 557 minecraft:yellow_concrete
fill 453 204 562 456 204 562 minecraft:basalt
fill 453 204 598 456 204 598 minecraft:basalt
fill 454 204 565 460 204 565 minecraft:basalt
fill 454 204 570 454 212 570 minecraft:basalt
fill 454 204 590 455 211 590 minecraft:basalt
fill 454 204 595 460 204 595 minecraft:basalt
fill 455 204 571 455 212 571 minecraft:basalt
fill 455 204 589 455 212 589 minecraft:basalt
fill 456 204 564 459 204 564 minecraft:basalt
fill 456 204 567 461 204 567 minecraft:basalt
fill 456 204 573 456 213 573 minecraft:basalt
setblock 456 204 587 minecraft:basalt
fill 456 204 594 461 204 594 minecraft:basalt
fill 456 204 597 456 205 597 minecraft:basalt
fill 457 204 570 463 204 570 minecraft:basalt
fill 457 204 574 457 213 575 minecraft:basalt
setblock 457 204 585 minecraft:magma_block
fill 457 204 586 458 211 586 minecraft:basalt
fill 457 204 591 463 204 591 minecraft:basalt
setblock 457 204 597 minecraft:magma_block
fill 458 204 557 458 236 557 minecraft:yellow_concrete
fill 458 204 574 458 211 574 minecraft:basalt
fill 458 204 577 458 211 583 minecraft:basalt
fill 459 204 566 459 205 566 minecraft:basalt
fill 459 204 593 461 204 593 minecraft:basalt
setblock 459 204 596 minecraft:basalt
setblock 460 204 566 minecraft:magma_block
setblock 461 204 566 minecraft:basalt
setblock 462 204 568 minecraft:basalt
setblock 462 204 592 minecraft:basalt
fill 463 204 599 464 236 599 minecraft:yellow_concrete
fill 464 204 557 465 232 557 minecraft:yellow_concrete
fill 465 204 564 465 236 564 minecraft:yellow_concrete
fill 465 204 566 465 238 566 minecraft:yellow_concrete
fill 465 204 572 465 236 572 minecraft:yellow_concrete
fill 465 204 584 465 236 584 minecraft:yellow_concrete
fill 423 205 561 423 232 561 minecraft:yellow_concrete
setblock 423 205 562 minecraft:sea_lantern
fill 423 205 563 423 236 563 minecraft:yellow_concrete
setblock 423 205 570 minecraft:sea_lantern
fill 423 205 571 423 233 571 minecraft:yellow_concrete
setblock 423 205 578 minecraft:sea_lantern
fill 423 205 584 423 236 585 minecraft:yellow_concrete
setblock 423 205 586 minecraft:sea_lantern
fill 423 205 593 423 236 593 minecraft:yellow_concrete
setblock 423 205 594 minecraft:sea_lantern
fill 423 205 595 423 236 596 minecraft:yellow_concrete
fill 424 205 564 424 238 565 minecraft:white_concrete
fill 424 205 572 424 238 573 minecraft:white_concrete
fill 424 205 580 424 238 581 minecraft:white_concrete
fill 424 205 588 424 238 589 minecraft:white_concrete
fill 424 205 596 424 238 597 minecraft:white_concrete
fill 424 205 599 425 237 599 minecraft:yellow_concrete
fill 425 205 558 426 238 558 minecraft:white_concrete
fill 425 205 576 425 205 577 minecraft:basalt
fill 425 205 579 425 205 580 minecraft:basalt
fill 425 205 582 425 205 584 minecraft:basalt
setblock 426 205 573 minecraft:magma_block
fill 426 205 584 428 206 584 minecraft:basalt
setblock 426 205 585 minecraft:magma_block
fill 426 205 587 428 205 587 minecraft:basalt
setblock 426 205 599 minecraft:sea_lantern
fill 427 205 572 428 205 573 minecraft:basalt
fill 427 205 585 428 206 585 minecraft:basalt
fill 427 205 588 428 205 588 minecraft:basalt
fill 427 205 599 433 232 599 minecraft:yellow_concrete
fill 428 205 569 428 205 570 minecraft:basalt
fill 428 205 590 428 205 591 minecraft:basalt
fill 429 205 568 434 205 568 minecraft:basalt
fill 429 205 592 434 205 592 minecraft:basalt
setblock 430 205 557 minecraft:sea_lantern
fill 430 205 593 432 205 593 minecraft:basalt
fill 430 205 598 431 238 598 minecraft:white_concrete
fill 431 205 566 432 205 566 minecraft:basalt
fill 431 205 580 431 211 580 minecraft:basalt
setblock 432 205 565 minecraft:magma_block
setblock 432 205 580 minecraft:magma_block
setblock 432 205 595 minecraft:magma_block
fill 433 205 558 434 238 558 minecraft:white_concrete
fill 433 205 564 437 205 564 minecraft:basalt
fill 433 205 575 433 212 577 minecraft:basalt
fill 433 205 583 433 212 584 minecraft:basalt
fill 433 205 595 435 206 595 minecraft:basalt
fill 434 205 563 435 205 563 minecraft:basalt
fill 434 205 574 434 214 574 minecraft:basalt
fill 434 205 586 434 214 586 minecraft:basalt
setblock 434 205 597 minecraft:basalt
setblock 434 205 599 minecraft:sea_lantern
fill 435 205 572 435 213 572 minecraft:basalt
setblock 435 205 588 minecraft:magma_block
setblock 435 205 597 minecraft:magma_block
fill 435 205 599 436 236 599 minecraft:yellow_concrete
fill 436 205 571 436 212 571 minecraft:basalt
fill 436 205 589 436 212 589 minecraft:basalt
fill 436 205 597 438 206 597 minecraft:basalt
fill 437 205 569 437 211 570 minecraft:basalt
fill 437 205 590 437 213 590 minecraft:basalt
setblock 438 205 557 minecraft:sea_lantern
setblock 438 205 561 minecraft:basalt
setblock 438 205 569 minecraft:magma_block
fill 439 205 569 439 214 569 minecraft:basalt
fill 439 205 591 439 214 591 minecraft:basalt
fill 441 205 558 442 238 558 minecraft:white_concrete
fill 441 205 560 446 205 560 minecraft:basalt
setblock 441 205 568 minecraft:magma_block
setblock 441 205 592 minecraft:magma_block
fill 441 205 599 441 236 599 minecraft:yellow_concrete
fill 442 205 567 442 213 568 minecraft:basalt
fill 442 205 592 442 212 593 minecraft:basalt
setblock 442 205 599 minecraft:sea_lantern
fill 443 205 567 443 213 567 minecraft:basalt
fill 443 205 599 449 236 599 minecraft:yellow_concrete
setblock 444 205 567 minecraft:magma_block
fill 444 205 593 446 213 593 minecraft:basalt
fill 445 205 567 448 212 567 minecraft:basalt
setblock 446 205 557 minecraft:sea_lantern
fill 447 205 557 452 233 557 minecraft:yellow_concrete
setblock 447 205 560 minecraft:magma_block
setblock 447 205 593 minecraft:magma_block
fill 448 205 560 449 205 561 minecraft:basalt
fill 448 205 568 449 213 568 minecraft:basalt
fill 448 205 592 448 213 593 minecraft:basalt
fill 449 205 558 450 238 558 minecraft:white_concrete
fill 449 205 592 449 213 592 minecraft:basalt
fill 450 205 561 452 205 561 minecraft:basalt
setblock 450 205 568 minecraft:magma_block
setblock 450 205 592 minecraft:magma_block
setblock 450 205 599 minecraft:sea_lantern
fill 451 205 563 455 205 563 minecraft:basalt
fill 451 205 568 451 213 569 minecraft:basalt
fill 451 205 591 451 213 592 minecraft:basalt
fill 451 205 596 457 205 596 minecraft:basalt
fill 451 205 599 452 236 599 minecraft:yellow_concrete
fill 453 205 562 454 205 562 minecraft:basalt
setblock 453 205 570 minecraft:magma_block
fill 453 205 590 453 213 590 minecraft:basalt
fill 453 205 598 454 205 598 minecraft:basalt
setblock 454 205 557 minecraft:sea_lantern
fill 454 205 565 458 205 565 minecraft:basalt
fill 454 205 571 454 212 571 minecraft:basalt
fill 454 205 589 454 212 589 minecraft:basalt
fill 454 205 595 458 205 595 minecraft:basalt
fill 455 205 572 455 213 572 minecraft:basalt
fill 455 205 588 455 213 588 minecraft:basalt
fill 455 205 598 455 238 598 minecraft:white_concrete
fill 455 205 599 457 234 599 minecraft:yellow_concrete
setblock 456 205 563 minecraft:magma_block
fill 456 205 564 457 205 564 minecraft:basalt
fill 456 205 567 460 205 567 minecraft:basalt
fill 456 205 574 456 214 574 minecraft:basalt
fill 456 205 586 456 214 586 minecraft:basalt
setblock 456 205 587 minecraft:magma_block
fill 456 205 594 459 205 594 minecraft:basalt
fill 457 205 558 458 238 558 minecraft:white_concrete
fill 457 205 570 461 206 570 minecraft:basalt
fill 457 205 576 457 212 577 minecraft:basalt
fill 457 205 583 457 212 585 minecraft:basalt
fill 457 205 588 463 205 588 minecraft:basalt
fill 457 205 591 461 206 591 minecraft:basalt
setblock 458 205 599 minecraft:sea_lantern
fill 459 205 557 461 233 557 minecraft:yellow_concrete
fill 459 205 569 462 205 569 minecraft:basalt
fill 459 205 590 462 205 590 minecraft:basalt
fill 459 205 593 460 205 593 minecraft:basalt
fill 459 205 599 462 236 599 minecraft:yellow_concrete
fill 460 205 572 463 205 572 minecraft:basalt
setblock 462 205 557 minecraft:sea_lantern
setblock 462 205 570 minecraft:magma_block
setblock 462 205 591 minecraft:magma_block
fill 462 205 598 463 238 598 minecraft:white_concrete
fill 463 205 557 463 236 557 minecraft:yellow_concrete
setblock 463 205 571 minecraft:basalt
setblock 463 205 589 minecraft:basalt
fill 464 205 559 464 238 560 minecraft:white_concrete
fill 464 205 567 464 238 568 minecraft:white_concrete
fill 464 205 591 464 238 592 minecraft:white_concrete
fill 465 205 558 465 236 561 minecraft:yellow_concrete
setblock 465 205 562 minecraft:sea_lantern
fill 465 205 567 465 234 569 minecraft:yellow_concrete
setblock 465 205 570 minecraft:sea_lantern
fill 465 205 573 465 232 577 minecraft:yellow_concrete
setblock 465 205 578 minecraft:sea_lantern
fill 465 205 579 465 232 580 minecraft:yellow_concrete
fill 465 205 585 465 232 585 minecraft:yellow_concrete
setblock 465 205 586 minecraft:sea_lantern
fill 465 205 587 465 236 587 minecraft:yellow_concrete
fill 465 205 590 465 233 593 minecraft:yellow_concrete
setblock 465 205 594 minecraft:sea_lantern
fill 465 205 595 465 236 596 minecraft:yellow_concrete
fill 423 206 562 423 213 562 minecraft:yellow_concrete
fill 423 206 570 423 213 570 minecraft:yellow_concrete
fill 423 206 578 423 213 578 minecraft:yellow_concrete
fill 423 206 586 423 213 586 minecraft:yellow_concrete
fill 423 206 594 423 213 594 minecraft:yellow_concrete
fill 426 206 576 428 206 576 minecraft:basalt
fill 426 206 599 426 213 599 minecraft:yellow_concrete
fill 427 206 573 428 206 573 minecraft:basalt
fill 427 206 575 428 207 575 minecraft:basalt
fill 427 206 587 428 206 587 minecraft:basalt
setblock 428 206 571 minecraft:magma_block
setblock 428 206 572 minecraft:basalt
setblock 428 206 588 minecraft:basalt
setblock 428 206 589 minecraft:magma_block
fill 429 206 571 434 207 571 minecraft:basalt
fill 429 206 589 434 207 589 minecraft:basalt
fill 430 206 557 430 213 557 minecraft:yellow_concrete
fill 430 206 568 434 206 568 minecraft:basalt
fill 430 206 592 434 206 592 minecraft:basalt
setblock 431 206 567 minecraft:magma_block
fill 431 206 593 432 206 593 minecraft:basalt
fill 432 206 566 432 206 567 minecraft:basalt
fill 432 206 580 433 206 580 minecraft:basalt
fill 432 206 594 437 206 594 minecraft:basalt
fill 433 206 567 437 208 567 minecraft:basalt
fill 433 206 578 433 214 579 minecraft:basalt
fill 433 206 581 433 214 582 minecraft:basalt
fill 434 206 564 437 206 564 minecraft:basalt
setblock 434 206 575 minecraft:magma_block
fill 434 206 576 434 214 576 minecraft:basalt
setblock 434 206 584 minecraft:magma_block
fill 434 206 585 434 214 585 minecraft:basalt
setblock 434 206 596 minecraft:magma_block
fill 434 206 599 434 213 599 minecraft:yellow_concrete
fill 435 206 573 435 213 573 minecraft:basalt
fill 435 206 587 435 213 588 minecraft:basalt
fill 435 206 596 440 206 596 minecraft:basalt
fill 436 206 572 436 214 572 minecraft:basalt
fill 436 206 588 436 214 588 minecraft:basalt
setblock 437 206 571 minecraft:magma_block
setblock 437 206 589 minecraft:magma_block
fill 438 206 557 438 213 557 minecraft:yellow_concrete
fill 438 206 562 443 206 562 minecraft:basalt
fill 438 206 569 438 213 570 minecraft:basalt
fill 438 206 590 438 213 590 minecraft:basalt
fill 438 206 598 443 206 598 minecraft:basalt
fill 440 206 569 441 214 569 minecraft:basalt
setblock 440 206 591 minecraft:magma_block
fill 441 206 561 446 206 561 minecraft:basalt
fill 441 206 568 441 213 568 minecraft:basalt
fill 441 206 591 441 213 592 minecraft:basalt
fill 442 206 599 442 213 599 minecraft:yellow_concrete
fill 443 206 568 445 214 568 minecraft:basalt
fill 443 206 592 445 214 592 minecraft:basalt
fill 444 206 567 444 213 567 minecraft:basalt
fill 446 206 557 446 213 557 minecraft:yellow_concrete
setblock 446 206 568 minecraft:magma_block
setblock 446 206 592 minecraft:magma_block
fill 447 206 568 447 214 568 minecraft:basalt
fill 447 206 592 447 213 593 minecraft:basalt
setblock 448 206 561 minecraft:basalt
fill 448 206 597 454 206 597 minecraft:basalt
setblock 449 206 561 minecraft:magma_block
fill 449 206 569 450 214 569 minecraft:basalt
setblock 449 206 591 minecraft:magma_block
fill 450 206 568 450 213 568 minecraft:basalt
fill 450 206 591 450 213 592 minecraft:basalt
fill 450 206 599 450 213 599 minecraft:yellow_concrete
fill 451 206 563 454 206 563 minecraft:basalt
fill 451 206 596 456 206 596 minecraft:basalt
fill 452 206 570 453 213 570 minecraft:basalt
setblock 452 206 590 minecraft:magma_block
fill 453 206 571 453 214 571 minecraft:basalt
fill 453 206 589 453 214 589 minecraft:basalt
fill 454 206 557 454 213 557 minecraft:yellow_concrete
fill 454 206 565 457 206 565 minecraft:basalt
fill 454 206 572 454 214 572 minecraft:basalt
fill 454 206 588 454 214 588 minecraft:basalt
fill 454 206 595 457 206 595 minecraft:basalt
fill 454 206 598 454 238 598 minecraft:white_concrete
fill 455 206 573 455 214 573 minecraft:basalt
fill 455 206 587 456 213 587 minecraft:basalt
setblock 456 206 564 minecraft:basalt
fill 456 206 567 459 206 567 minecraft:basalt
fill 456 206 575 456 213 576 minecraft:basalt
fill 456 206 584 456 213 585 minecraft:basalt
fill 456 206 592 460 206 592 minecraft:basalt
fill 456 206 594 457 207 594 minecraft:basalt
fill 457 206 578 457 206 582 minecraft:basalt
fill 457 206 588 462 206 588 minecraft:basalt
setblock 458 206 594 minecraft:magma_block
fill 458 206 599 458 213 599 minecraft:yellow_concrete
fill 459 206 568 460 206 569 minecraft:basalt
fill 459 206 590 460 207 590 minecraft:basalt
setblock 459 206 593 minecraft:basalt
fill 460 206 572 462 206 572 minecraft:basalt
fill 460 206 575 463 207 575 minecraft:basalt
fill 460 206 587 463 206 587 minecraft:basalt
setblock 461 206 569 minecraft:magma_block
setblock 461 206 590 minecraft:magma_block
fill 462 206 557 462 213 557 minecraft:yellow_concrete
fill 462 206 573 463 206 573 minecraft:basalt
fill 462 206 585 463 206 585 minecraft:basalt
setblock 463 206 574 minecraft:basalt
fill 463 206 577 463 207 577 minecraft:basalt
fill 463 206 580 463 207 580 minecraft:basalt
fill 463 206 583 463 207 583 minecraft:basalt
setblock 463 206 586 minecraft:basalt
fill 464 206 575 464 238 575 minecraft:white_concrete
setblock 464 206 577 minecraft:magma_block
setblock 464 206 580 minecraft:magma_block
setblock 464 206 583 minecraft:magma_block
fill 465 206 562 465 213 562 minecraft:yellow_concrete
fill 465 206 570 465 213 570 minecraft:yellow_concrete
fill 465 206 578 465 213 578 minecraft:yellow_concrete
fill 465 206 586 465 213 586 minecraft:yellow_concrete
fill 465 206 594 465 213 594 minecraft:yellow_concrete
setblock 427 207 576 minecraft:magma_block
fill 427 207 577 428 207 578 minecraft:basalt
setblock 427 207 579 minecraft:magma_block
fill 427 207 581 428 207 581 minecraft:basalt
setblock 427 207 582 minecraft:magma_block
fill 427 207 583 428 207 584 minecraft:basalt
setblock 427 207 585 minecraft:magma_block
fill 428 207 573 428 207 574 minecraft:basalt
fill 428 207 576 428 208 576 minecraft:basalt
fill 428 207 579 428 208 579 minecraft:basalt
fill 428 207 582 428 208 582 minecraft:basalt
fill 428 207 585 428 207 587 minecraft:basalt
fill 429 207 574 432 207 574 minecraft:basalt
fill 429 207 577 430 209 577 minecraft:basalt
fill 429 207 583 430 209 583 minecraft:basalt
fill 429 207 586 432 207 586 minecraft:basalt
setblock 430 207 569 minecraft:magma_block
setblock 430 207 590 minecraft:magma_block
fill 431 207 568 431 207 569 minecraft:basalt
fill 431 207 590 431 208 590 minecraft:basalt
fill 431 207 592 434 207 592 minecraft:basalt
fill 432 207 567 432 207 568 minecraft:basalt
fill 432 207 580 432 213 580 minecraft:basalt
setblock 432 207 593 minecraft:basalt
fill 433 207 568 434 208 568 minecraft:basalt
setblock 433 207 580 minecraft:magma_block
fill 433 207 594 437 207 594 minecraft:basalt
fill 434 207 565 435 207 565 minecraft:basalt
fill 434 207 575 435 207 575 minecraft:basalt
fill 434 207 577 434 214 578 minecraft:basalt
fill 434 207 582 434 214 584 minecraft:basalt
fill 434 207 595 435 207 595 minecraft:basalt
fill 435 207 574 435 215 574 minecraft:basalt
fill 435 207 585 435 215 586 minecraft:basalt
setblock 436 207 564 minecraft:magma_block
setblock 436 207 573 minecraft:magma_block
fill 436 207 587 436 215 587 minecraft:basalt
fill 436 207 596 440 207 596 minecraft:basalt
setblock 437 207 564 minecraft:basalt
fill 437 207 571 437 214 572 minecraft:basalt
fill 437 207 588 437 214 589 minecraft:basalt
setblock 438 207 563 minecraft:basalt
fill 438 207 571 438 215 571 minecraft:basalt
fill 438 207 589 438 215 589 minecraft:basalt
setblock 438 207 597 minecraft:basalt
fill 438 207 598 439 238 598 minecraft:white_concrete
setblock 439 207 563 minecraft:magma_block
fill 439 207 570 440 214 570 minecraft:basalt
setblock 439 207 590 minecraft:magma_block
fill 440 207 562 440 207 563 minecraft:basalt
fill 440 207 590 440 214 591 minecraft:basalt
fill 440 207 598 441 207 598 minecraft:basalt
setblock 441 207 562 minecraft:basalt
setblock 442 207 562 minecraft:magma_block
fill 442 207 569 443 214 569 minecraft:basalt
fill 442 207 591 443 215 591 minecraft:basalt
setblock 442 207 598 minecraft:magma_block
setblock 443 207 562 minecraft:basalt
setblock 443 207 598 minecraft:basalt
fill 445 207 562 450 207 562 minecraft:basalt
fill 445 207 598 450 207 598 minecraft:basalt
fill 446 207 568 446 214 568 minecraft:basalt
fill 446 207 592 446 214 592 minecraft:basalt
fill 447 207 569 447 215 569 minecraft:basalt
fill 447 207 591 449 214 591 minecraft:basalt
fill 448 207 564 453 207 564 minecraft:basalt
setblock 448 207 569 minecraft:magma_block
fill 448 207 597 452 207 597 minecraft:basalt
fill 450 207 570 451 207 570 minecraft:basalt
fill 450 207 590 452 214 590 minecraft:basalt
fill 451 207 563 452 207 563 minecraft:basalt
fill 451 207 596 454 207 596 minecraft:basalt
fill 452 207 571 452 215 571 minecraft:basalt
fill 452 207 589 452 215 589 minecraft:basalt
fill 453 207 572 453 215 572 minecraft:basalt
fill 453 207 588 453 215 588 minecraft:basalt
setblock 454 207 564 minecraft:magma_block
fill 454 207 565 456 207 565 minecraft:basalt
setblock 454 207 573 minecraft:magma_block
fill 454 207 587 454 215 587 minecraft:basalt
fill 454 207 595 456 207 595 minecraft:basalt
fill 455 207 574 455 214 575 minecraft:basalt
fill 455 207 585 455 214 586 minecraft:basalt
fill 456 207 566 456 208 567 minecraft:basalt
fill 456 207 577 456 215 578 minecraft:basalt
fill 456 207 582 456 215 583 minecraft:basalt
fill 456 207 592 459 207 592 minecraft:basalt
setblock 457 207 566 minecraft:magma_block
fill 457 207 567 458 207 567 minecraft:basalt
fill 457 207 570 460 207 570 minecraft:basalt
fill 457 207 578 457 214 580 minecraft:basalt
setblock 457 207 581 minecraft:magma_block
fill 457 207 582 457 214 582 minecraft:basalt
fill 457 207 588 461 207 588 minecraft:basalt
fill 457 207 591 460 207 591 minecraft:basalt
fill 459 207 568 459 207 569 minecraft:basalt
setblock 460 207 569 minecraft:basalt
fill 460 207 572 461 207 572 minecraft:basalt
fill 460 207 584 463 207 584 minecraft:basalt
fill 460 207 587 462 207 587 minecraft:basalt
setblock 462 207 573 minecraft:basalt
fill 462 207 576 462 208 576 minecraft:basalt
fill 462 207 578 462 207 579 minecraft:basalt
fill 462 207 581 462 207 582 minecraft:basalt
fill 462 207 585 462 208 585 minecraft:basalt
setblock 463 207 576 minecraft:magma_block
setblock 463 207 578 minecraft:basalt
setblock 463 207 579 minecraft:magma_block
setblock 463 207 581 minecraft:basalt
setblock 463 207 582 minecraft:magma_block
setblock 463 207 585 minecraft:magma_block
fill 464 207 576 464 238 576 minecraft:white_concrete
fill 464 207 583 464 238 584 minecraft:white_concrete
fill 426 208 574 427 209 582 minecraft:white_concrete
fill 427 208 571 428 209 573 minecraft:white_concrete
fill 427 208 583 427 209 585 minecraft:white_concrete
fill 428 208 569 429 209 570 minecraft:white_concrete
setblock 428 208 575 minecraft:basalt
fill 428 208 577 428 208 578 minecraft:basalt
fill 428 208 580 428 208 581 minecraft:basalt
fill 428 208 583 428 208 585 minecraft:basalt
fill 428 208 586 428 209 587 minecraft:white_concrete
fill 429 208 568 430 209 568 minecraft:white_concrete
fill 429 208 571 429 209 571 minecraft:white_concrete
setblock 429 208 574 minecraft:magma_block
fill 429 208 580 430 210 580 minecraft:basalt
setblock 429 208 586 minecraft:magma_block
fill 429 208 588 429 209 588 minecraft:white_concrete
fill 430 208 566 431 209 567 minecraft:white_concrete
fill 430 208 569 430 209 569 minecraft:white_concrete
fill 430 208 571 431 208 572 minecraft:basalt
fill 430 208 574 432 209 574 minecraft:basalt
fill 430 208 586 432 209 586 minecraft:basalt
fill 430 208 589 434 208 589 minecraft:basalt
fill 430 208 590 430 209 590 minecraft:white_concrete
fill 431 208 565 433 209 565 minecraft:white_concrete
fill 431 208 569 431 208 570 minecraft:basalt
setblock 431 208 591 minecraft:basalt
fill 432 208 564 435 209 564 minecraft:white_concrete
fill 432 208 566 432 209 566 minecraft:white_concrete
setblock 432 208 568 minecraft:basalt
fill 432 208 570 434 209 571 minecraft:basalt
setblock 432 208 591 minecraft:magma_block
fill 432 208 592 434 208 592 minecraft:basalt
fill 433 208 580 434 214 580 minecraft:basalt
fill 433 208 591 436 209 591 minecraft:basalt
fill 434 208 563 437 209 563 minecraft:white_concrete
setblock 434 208 566 minecraft:basalt
fill 434 208 575 434 214 575 minecraft:basalt
fill 434 208 579 434 215 579 minecraft:basalt
fill 434 208 581 434 214 581 minecraft:basalt
fill 434 208 594 437 208 594 minecraft:basalt
fill 435 208 562 439 209 562 minecraft:white_concrete
setblock 435 208 566 minecraft:magma_block
setblock 435 208 575 minecraft:magma_block
fill 435 208 576 435 216 577 minecraft:basalt
fill 435 208 583 435 216 583 minecraft:basalt
setblock 435 208 584 minecraft:magma_block
fill 436 208 566 440 209 566 minecraft:basalt
fill 436 208 573 436 215 574 minecraft:basalt
fill 436 208 586 436 215 586 minecraft:basalt
fill 437 208 561 451 209 561 minecraft:white_concrete
fill 437 208 573 437 216 573 minecraft:basalt
fill 437 208 587 437 216 587 minecraft:basalt
fill 438 208 572 438 216 572 minecraft:basalt
fill 438 208 588 438 216 588 minecraft:basalt
fill 438 208 596 440 208 596 minecraft:basalt
fill 439 208 571 439 215 571 minecraft:basalt
fill 439 208 589 439 215 590 minecraft:basalt
fill 440 208 560 448 209 560 minecraft:white_concrete
setblock 440 208 563 minecraft:basalt
setblock 440 208 597 minecraft:basalt
setblock 441 208 570 minecraft:magma_block
fill 441 208 590 442 216 590 minecraft:basalt
setblock 441 208 597 minecraft:magma_block
fill 442 208 563 443 208 563 minecraft:basalt
fill 442 208 570 442 216 570 minecraft:basalt
fill 442 208 597 446 208 597 minecraft:basalt
setblock 444 208 563 minecraft:magma_block
setblock 444 208 569 minecraft:magma_block
fill 444 208 591 446 215 591 minecraft:basalt
fill 445 208 563 449 208 563 minecraft:basalt
fill 445 208 569 446 215 569 minecraft:basalt
fill 446 208 598 447 238 598 minecraft:white_concrete
fill 448 208 564 452 208 564 minecraft:basalt
fill 448 208 569 448 215 570 minecraft:basalt
fill 448 208 590 449 215 590 minecraft:basalt
fill 448 208 597 449 208 597 minecraft:basalt
fill 449 208 562 453 209 562 minecraft:white_concrete
fill 449 208 570 449 214 570 minecraft:basalt
setblock 450 208 570 minecraft:magma_block
setblock 450 208 597 minecraft:magma_block
fill 451 208 563 454 209 563 minecraft:white_concrete
fill 451 208 570 451 215 571 minecraft:basalt
fill 451 208 589 451 215 589 minecraft:basalt
fill 451 208 593 457 208 593 minecraft:basalt
fill 451 208 596 452 208 596 minecraft:basalt
fill 452 208 572 452 216 572 minecraft:basalt
fill 452 208 588 452 216 588 minecraft:basalt
fill 453 208 564 456 209 564 minecraft:white_concrete
fill 453 208 573 454 215 573 minecraft:basalt
setblock 453 208 587 minecraft:magma_block
setblock 454 208 565 minecraft:basalt
fill 454 208 574 454 215 574 minecraft:basalt
fill 454 208 586 454 215 586 minecraft:basalt
setblock 454 208 595 minecraft:basalt
fill 455 208 565 457 209 565 minecraft:white_concrete
fill 455 208 576 455 216 577 minecraft:basalt
fill 455 208 583 455 216 584 minecraft:basalt
fill 456 208 571 460 208 571 minecraft:basalt
fill 456 208 579 456 215 579 minecraft:basalt
setblock 456 208 580 minecraft:magma_block
fill 456 208 581 457 214 581 minecraft:basalt
fill 456 208 592 458 208 592 minecraft:basalt
setblock 456 208 594 minecraft:basalt
fill 457 208 566 458 209 566 minecraft:white_concrete
setblock 457 208 567 minecraft:basalt
fill 457 208 570 458 209 570 minecraft:basalt
fill 457 208 588 460 208 588 minecraft:basalt
fill 457 208 591 458 208 591 minecraft:basalt
fill 458 208 567 458 209 567 minecraft:white_concrete
fill 459 208 568 459 209 568 minecraft:white_concrete
setblock 459 208 569 minecraft:basalt
setblock 459 208 570 minecraft:magma_block
fill 459 208 589 459 208 590 minecraft:basalt
setblock 459 208 591 minecraft:magma_block
fill 460 208 569 460 209 570 minecraft:white_concrete
setblock 460 208 572 minecraft:basalt
fill 460 208 574 461 208 575 minecraft:basalt
fill 460 208 584 461 209 584 minecraft:basalt
fill 460 208 587 461 208 587 minecraft:basalt
setblock 460 208 589 minecraft:basalt
fill 461 208 571 461 209 572 minecraft:white_concrete
fill 462 208 574 462 209 574 minecraft:white_concrete
setblock 462 208 575 minecraft:magma_block
setblock 462 208 578 minecraft:magma_block
setblock 462 208 579 minecraft:basalt
setblock 462 208 581 minecraft:magma_block
setblock 462 208 582 minecraft:basalt
setblock 462 208 584 minecraft:magma_block
fill 428 209 583 428 209 585 minecraft:white_concrete
fill 429 209 586 429 209 587 minecraft:white_concrete
fill 430 209 587 431 209 587 minecraft:basalt
fill 430 209 588 430 209 589 minecraft:white_concrete
setblock 431 209 571 minecraft:basalt
setblock 431 209 572 minecraft:magma_block
fill 431 209 588 433 209 589 minecraft:basalt
fill 431 209 590 431 209 591 minecraft:white_concrete
fill 432 209 591 432 209 592 minecraft:white_concrete
setblock 433 209 592 minecraft:white_concrete
setblock 434 209 568 minecraft:magma_block
fill 434 209 589 434 212 589 minecraft:basalt
setblock 434 209 592 minecraft:magma_block
setblock 434 209 593 minecraft:white_concrete
fill 435 209 567 437 209 567 minecraft:basalt
fill 435 209 575 436 215 575 minecraft:basalt
fill 435 209 578 435 216 582 minecraft:basalt
fill 435 209 584 436 209 584 minecraft:basalt
fill 435 209 593 439 209 593 minecraft:basalt
setblock 435 209 594 minecraft:white_concrete
fill 436 209 576 436 217 576 minecraft:basalt
fill 436 209 585 436 215 585 minecraft:basalt
setblock 436 209 594 minecraft:basalt
fill 437 209 574 437 216 574 minecraft:basalt
fill 437 209 586 437 216 586 minecraft:basalt
setblock 437 209 594 minecraft:magma_block
setblock 437 209 595 minecraft:white_concrete
fill 438 209 565 443 209 565 minecraft:basalt
fill 438 209 573 438 217 573 minecraft:basalt
fill 438 209 587 438 217 587 minecraft:basalt
fill 438 209 595 443 209 595 minecraft:basalt
fill 439 209 572 439 215 572 minecraft:basalt
fill 439 209 588 439 216 588 minecraft:basalt
fill 440 209 564 445 209 564 minecraft:basalt
fill 440 209 571 441 216 571 minecraft:basalt
fill 440 209 589 441 216 589 minecraft:basalt
setblock 440 209 596 minecraft:magma_block
fill 441 209 570 441 216 570 minecraft:basalt
fill 442 209 596 448 209 596 minecraft:basalt
fill 443 209 570 445 215 570 minecraft:basalt
fill 443 209 590 447 209 590 minecraft:basalt
fill 444 209 569 444 215 569 minecraft:basalt
fill 445 209 565 451 209 565 minecraft:basalt
fill 445 209 595 451 209 595 minecraft:basalt
setblock 446 209 564 minecraft:magma_block
setblock 446 209 570 minecraft:magma_block
fill 447 209 570 447 216 570 minecraft:basalt
fill 448 209 564 450 209 564 minecraft:basalt
fill 448 209 594 454 209 594 minecraft:basalt
fill 449 209 571 450 216 571 minecraft:basalt
fill 449 209 589 450 216 589 minecraft:basalt
setblock 449 209 596 minecraft:magma_block
fill 450 209 570 450 215 570 minecraft:basalt
fill 451 209 566 454 209 567 minecraft:basalt
fill 451 209 572 451 216 572 minecraft:basalt
fill 451 209 588 451 216 588 minecraft:basalt
fill 451 209 593 455 209 593 minecraft:basalt
setblock 452 209 565 minecraft:magma_block
fill 452 209 573 452 217 573 minecraft:basalt
fill 452 209 587 453 216 587 minecraft:basalt
setblock 452 209 595 minecraft:magma_block
fill 453 209 574 453 216 574 minecraft:basalt
fill 453 209 586 453 216 586 minecraft:basalt
fill 454 209 568 456 209 569 minecraft:basalt
fill 454 209 575 454 216 576 minecraft:basalt
fill 454 209 584 454 209 585 minecraft:basalt
setblock 455 209 567 minecraft:magma_block
fill 455 209 578 455 216 578 minecraft:basalt
setblock 455 209 579 minecraft:magma_block
fill 455 209 580 455 216 581 minecraft:basalt
setblock 455 209 582 minecraft:magma_block
setblock 456 209 566 minecraft:white_concrete
fill 456 209 571 459 209 571 minecraft:basalt
fill 456 209 580 456 215 580 minecraft:basalt
fill 456 209 589 457 210 590 minecraft:basalt
setblock 456 209 592 minecraft:basalt
setblock 457 209 567 minecraft:white_concrete
setblock 457 209 569 minecraft:basalt
fill 457 209 573 460 209 573 minecraft:basalt
fill 457 209 588 459 209 588 minecraft:basalt
setblock 457 209 591 minecraft:basalt
fill 458 209 568 458 209 569 minecraft:white_concrete
fill 458 209 589 459 209 589 minecraft:basalt
setblock 458 209 590 minecraft:magma_block
fill 459 209 569 459 209 570 minecraft:white_concrete
fill 459 209 576 460 209 577 minecraft:basalt
fill 459 209 583 460 210 583 minecraft:basalt
fill 459 209 585 460 209 586 minecraft:basalt
fill 460 209 571 460 209 572 minecraft:white_concrete
fill 460 209 574 460 209 575 minecraft:basalt
fill 460 209 578 460 209 582 minecraft:basalt
setblock 460 209 587 minecraft:basalt
fill 461 209 573 461 209 574 minecraft:white_concrete
fill 461 209 575 461 209 576 minecraft:basalt
setblock 461 209 577 minecraft:magma_block
fill 461 209 578 461 209 579 minecraft:basalt
setblock 461 209 580 minecraft:magma_block
fill 461 209 581 461 209 582 minecraft:basalt
setblock 461 209 583 minecraft:magma_block
setblock 461 209 585 minecraft:basalt
fill 462 209 575 462 209 582 minecraft:white_concrete
fill 424 210 558 424 211 563 minecraft:white_concrete
fill 424 210 566 425 210 571 minecraft:white_concrete
fill 424 210 574 425 210 579 minecraft:white_concrete
fill 424 210 582 425 210 587 minecraft:white_concrete
fill 424 210 590 425 210 595 minecraft:white_concrete
fill 424 210 598 429 211 598 minecraft:white_concrete
fill 425 210 559 425 210 565 minecraft:white_concrete
fill 425 210 572 425 210 573 minecraft:white_concrete
fill 425 210 580 425 210 581 minecraft:white_concrete
fill 425 210 588 425 210 589 minecraft:white_concrete
fill 425 210 596 425 210 597 minecraft:white_concrete
fill 426 210 559 463 210 559 minecraft:white_concrete
fill 426 210 574 426 210 582 minecraft:sea_lantern
fill 426 210 597 464 210 597 minecraft:white_concrete
fill 427 210 558 432 211 558 minecraft:white_concrete
fill 427 210 571 427 210 573 minecraft:sea_lantern
fill 427 210 583 427 210 585 minecraft:sea_lantern
fill 428 210 569 428 210 570 minecraft:sea_lantern
setblock 429 210 568 minecraft:sea_lantern
fill 430 210 566 430 210 567 minecraft:sea_lantern
fill 430 210 575 431 210 575 minecraft:basalt
setblock 430 210 577 minecraft:magma_block
fill 430 210 578 430 211 578 minecraft:basalt
setblock 430 210 583 minecraft:magma_block
fill 430 210 584 431 210 584 minecraft:basalt
fill 431 210 565 431 210 566 minecraft:sea_lantern
fill 431 210 573 432 210 574 minecraft:basalt
fill 431 210 586 431 210 587 minecraft:basalt
fill 432 210 564 432 210 565 minecraft:sea_lantern
fill 432 210 571 434 210 571 minecraft:basalt
fill 432 210 586 432 211 586 minecraft:basalt
fill 432 210 588 433 210 589 minecraft:basalt
fill 432 210 598 437 211 598 minecraft:white_concrete
setblock 433 210 564 minecraft:sea_lantern
setblock 433 210 570 minecraft:magma_block
setblock 434 210 563 minecraft:sea_lantern
fill 434 210 569 434 210 570 minecraft:basalt
fill 434 210 591 436 210 591 minecraft:basalt
fill 435 210 558 440 211 558 minecraft:white_concrete
fill 435 210 562 436 210 562 minecraft:sea_lantern
fill 435 210 569 436 211 569 minecraft:basalt
fill 435 210 584 435 216 584 minecraft:basalt
fill 435 210 593 435 211 593 minecraft:purple_concrete
fill 436 210 567 437 210 567 minecraft:basalt
fill 436 210 577 436 217 577 minecraft:basalt
setblock 436 210 578 minecraft:magma_block
fill 436 210 582 436 217 583 minecraft:basalt
setblock 436 210 584 minecraft:magma_block
setblock 436 210 593 minecraft:magma_block
fill 437 210 561 439 210 561 minecraft:sea_lantern
fill 437 210 575 437 217 575 minecraft:basalt
fill 437 210 585 437 217 585 minecraft:basalt
fill 437 210 593 439 210 593 minecraft:basalt
fill 438 210 566 440 210 566 minecraft:basalt
fill 438 210 574 438 216 574 minecraft:basalt
fill 438 210 586 438 216 586 minecraft:basalt
fill 439 210 573 439 217 573 minecraft:basalt
fill 439 210 587 439 217 587 minecraft:basalt
fill 440 210 560 448 210 560 minecraft:sea_lantern
fill 440 210 565 443 210 565 minecraft:basalt
fill 440 210 572 440 217 572 minecraft:basalt
fill 440 210 588 440 217 588 minecraft:basalt
fill 440 210 595 443 210 595 minecraft:basalt
fill 440 210 598 445 211 598 minecraft:white_concrete
fill 442 210 571 443 217 571 minecraft:basalt
fill 442 210 589 443 217 589 minecraft:basalt
fill 443 210 558 448 211 558 minecraft:white_concrete
fill 443 210 590 444 216 590 minecraft:basalt
fill 444 210 564 446 210 564 minecraft:basalt
setblock 444 210 596 minecraft:basalt
fill 445 210 565 447 211 565 minecraft:basalt
setblock 445 210 590 minecraft:magma_block
fill 445 210 595 447 211 595 minecraft:basalt
setblock 445 210 596 minecraft:magma_block
fill 446 210 570 446 216 570 minecraft:basalt
fill 446 210 590 447 216 590 minecraft:basalt
setblock 446 210 596 minecraft:basalt
fill 447 210 571 447 216 571 minecraft:basalt
fill 447 210 589 447 216 589 minecraft:basalt
setblock 448 210 565 minecraft:magma_block
setblock 448 210 571 minecraft:magma_block
setblock 448 210 589 minecraft:magma_block
fill 448 210 594 450 211 594 minecraft:basalt
setblock 448 210 595 minecraft:magma_block
setblock 448 210 596 minecraft:sea_lantern
fill 448 210 598 453 211 598 minecraft:white_concrete
fill 449 210 561 451 210 561 minecraft:sea_lantern
fill 449 210 565 450 210 565 minecraft:basalt
fill 449 210 595 450 210 595 minecraft:basalt
fill 450 210 572 450 217 572 minecraft:basalt
fill 450 210 588 450 216 588 minecraft:basalt
fill 451 210 558 456 211 558 minecraft:white_concrete
fill 451 210 566 452 210 567 minecraft:basalt
setblock 451 210 573 minecraft:magma_block
fill 451 210 587 451 217 587 minecraft:basalt
fill 451 210 593 453 210 593 minecraft:basalt
setblock 451 210 594 minecraft:magma_block
setblock 451 210 595 minecraft:sea_lantern
fill 452 210 562 453 210 562 minecraft:sea_lantern
fill 452 210 574 452 217 574 minecraft:basalt
fill 452 210 586 452 217 586 minecraft:basalt
setblock 452 210 594 minecraft:basalt
fill 453 210 567 454 210 567 minecraft:basalt
fill 453 210 575 453 216 575 minecraft:basalt
fill 453 210 585 454 215 585 minecraft:basalt
setblock 453 210 594 minecraft:sea_lantern
setblock 454 210 563 minecraft:sea_lantern
fill 454 210 568 455 210 569 minecraft:basalt
fill 454 210 577 454 217 577 minecraft:basalt
setblock 454 210 578 minecraft:magma_block
fill 454 210 582 454 217 583 minecraft:basalt
setblock 454 210 584 minecraft:magma_block
setblock 454 210 593 minecraft:magma_block
fill 455 210 564 456 210 564 minecraft:sea_lantern
fill 455 210 579 455 216 579 minecraft:basalt
fill 455 210 582 455 216 582 minecraft:basalt
fill 456 210 565 457 210 565 minecraft:sea_lantern
setblock 456 210 569 minecraft:basalt
fill 456 210 571 458 210 571 minecraft:basalt
setblock 456 210 592 minecraft:sea_lantern
fill 456 210 598 461 211 598 minecraft:white_concrete
fill 457 210 566 458 210 566 minecraft:sea_lantern
setblock 457 210 570 minecraft:basalt
fill 457 210 573 459 210 573 minecraft:basalt
fill 457 210 588 458 210 588 minecraft:basalt
setblock 457 210 591 minecraft:sea_lantern
setblock 458 210 567 minecraft:sea_lantern
setblock 458 210 589 minecraft:basalt
setblock 458 210 590 minecraft:sea_lantern
fill 459 210 558 464 211 558 minecraft:white_concrete
setblock 459 210 568 minecraft:sea_lantern
fill 459 210 576 459 211 577 minecraft:basalt
fill 459 210 585 459 210 586 minecraft:basalt
setblock 459 210 588 minecraft:sea_lantern
fill 460 210 569 460 210 570 minecraft:sea_lantern
setblock 460 210 575 minecraft:basalt
setblock 460 210 576 minecraft:magma_block
fill 460 210 577 460 210 581 minecraft:basalt
setblock 460 210 582 minecraft:magma_block
setblock 460 210 584 minecraft:basalt
setblock 460 210 585 minecraft:magma_block
fill 460 210 586 460 210 587 minecraft:sea_lantern
fill 461 210 571 461 210 573 minecraft:sea_lantern
fill 461 210 579 461 210 581 minecraft:basalt
fill 461 210 583 461 210 585 minecraft:sea_lantern
fill 462 210 574 462 210 582 minecraft:sea_lantern
fill 463 210 560 463 210 596 minecraft:white_concrete
fill 464 210 561 464 211 566 minecraft:white_concrete
fill 464 210 569 464 211 574 minecraft:white_concrete
fill 464 210 577 464 211 582 minecraft:white_concrete
fill 464 210 585 464 211 590 minecraft:white_concrete
fill 464 210 593 464 211 596 minecraft:white_concrete
fill 464 210 598 464 211 598 minecraft:white_concrete
fill 424 211 566 424 211 571 minecraft:white_concrete
fill 424 211 574 424 211 579 minecraft:white_concrete
fill 424 211 582 424 211 587 minecraft:white_concrete
fill 424 211 590 424 211 595 minecraft:white_concrete
setblock 426 211 560 minecraft:light[level=14]
setblock 426 211 568 minecraft:light[level=14]
setblock 426 211 576 minecraft:light[level=14]
setblock 426 211 584 minecraft:light[level=14]
setblock 426 211 592 minecraft:light[level=14]
fill 430 211 580 430 211 581 minecraft:basalt
fill 431 211 575 431 211 576 minecraft:basalt
fill 431 211 584 431 211 585 minecraft:basalt
fill 432 211 573 432 211 574 minecraft:basalt
setblock 432 211 587 minecraft:magma_block
fill 433 211 571 434 211 571 minecraft:basalt
fill 433 211 587 433 211 589 minecraft:basalt
setblock 434 211 560 minecraft:light[level=14]
setblock 434 211 568 minecraft:light[level=14]
setblock 434 211 570 minecraft:basalt
setblock 434 211 590 minecraft:basalt
setblock 434 211 592 minecraft:light[level=14]
fill 435 211 591 436 211 591 minecraft:basalt
setblock 435 211 592 minecraft:purple_concrete
fill 436 211 578 436 217 581 minecraft:basalt
fill 436 211 584 437 217 584 minecraft:basalt
setblock 436 211 593 minecraft:purple_concrete
fill 437 211 576 437 217 576 minecraft:basalt
setblock 438 211 567 minecraft:magma_block
fill 438 211 568 438 212 568 minecraft:basalt
fill 438 211 575 438 217 575 minecraft:basalt
setblock 438 211 585 minecraft:magma_block
fill 438 211 593 439 211 593 minecraft:basalt
setblock 440 211 566 minecraft:basalt
fill 440 211 573 440 217 573 minecraft:basalt
fill 440 211 587 440 217 587 minecraft:basalt
fill 440 211 594 442 211 594 minecraft:basalt
setblock 441 211 566 minecraft:magma_block
setblock 441 211 572 minecraft:magma_block
fill 441 211 588 441 216 588 minecraft:basalt
setblock 442 211 560 minecraft:light[level=14]
setblock 442 211 576 minecraft:light[level=14]
setblock 442 211 584 minecraft:light[level=14]
setblock 443 211 565 minecraft:basalt
setblock 443 211 595 minecraft:basalt
setblock 444 211 565 minecraft:magma_block
setblock 444 211 571 minecraft:magma_block
setblock 444 211 589 minecraft:magma_block
fill 444 211 594 444 212 594 minecraft:basalt
setblock 444 211 595 minecraft:magma_block
fill 445 211 571 446 217 571 minecraft:basalt
fill 445 211 589 445 216 590 minecraft:basalt
fill 446 211 589 446 217 589 minecraft:basalt
fill 448 211 571 448 217 571 minecraft:basalt
fill 448 211 589 448 217 589 minecraft:basalt
fill 449 211 572 449 217 572 minecraft:basalt
fill 449 211 588 449 217 588 minecraft:basalt
setblock 450 211 560 minecraft:light[level=14]
setblock 450 211 566 minecraft:magma_block
fill 450 211 573 451 216 573 minecraft:basalt
setblock 450 211 576 minecraft:light[level=14]
setblock 450 211 584 minecraft:light[level=14]
setblock 450 211 587 minecraft:magma_block
fill 451 211 567 452 211 567 minecraft:basalt
fill 451 211 593 452 211 593 minecraft:basalt
fill 452 211 568 452 212 568 minecraft:basalt
fill 452 211 575 452 217 575 minecraft:basalt
setblock 452 211 585 minecraft:basalt
fill 452 211 592 452 212 592 minecraft:basalt
setblock 453 211 568 minecraft:magma_block
fill 453 211 576 453 217 576 minecraft:basalt
fill 453 211 584 454 216 584 minecraft:basalt
setblock 453 211 592 minecraft:magma_block
fill 454 211 568 454 211 569 minecraft:basalt
fill 454 211 578 454 217 581 minecraft:basalt
fill 454 211 591 454 211 592 minecraft:basalt
fill 455 211 569 455 211 570 minecraft:basalt
setblock 455 211 591 minecraft:basalt
setblock 456 211 570 minecraft:magma_block
fill 456 211 571 457 211 571 minecraft:basalt
fill 456 211 589 456 211 590 minecraft:basalt
fill 457 211 572 457 211 573 minecraft:basalt
fill 457 211 587 457 211 589 minecraft:basalt
setblock 458 211 560 minecraft:light[level=14]
setblock 458 211 568 minecraft:light[level=14]
setblock 458 211 573 minecraft:basalt
setblock 458 211 587 minecraft:basalt
setblock 458 211 592 minecraft:light[level=14]
setblock 459 211 575 minecraft:magma_block
setblock 459 211 583 minecraft:basalt
setblock 459 211 584 minecraft:magma_block
setblock 459 211 585 minecraft:basalt
fill 460 211 578 460 211 582 minecraft:basalt
setblock 464 211 597 minecraft:white_concrete
setblock 431 212 580 minecraft:magma_block
fill 432 212 577 432 213 577 minecraft:basalt
fill 432 212 583 432 213 583 minecraft:basalt
fill 433 212 587 434 212 587 minecraft:basalt
setblock 434 212 571 minecraft:basalt
setblock 434 212 588 minecraft:magma_block
setblock 436 212 569 minecraft:basalt
setblock 436 212 591 minecraft:basalt
setblock 437 212 569 minecraft:magma_block
fill 437 212 570 437 213 570 minecraft:basalt
fill 437 212 577 437 217 577 minecraft:basalt
setblock 437 212 578 minecraft:magma_block
fill 437 212 579 437 217 580 minecraft:basalt
setblock 437 212 581 minecraft:magma_block
fill 437 212 582 437 217 583 minecraft:basalt
fill 438 212 576 438 217 576 minecraft:basalt
fill 438 212 584 438 217 585 minecraft:basalt
setblock 439 212 567 minecraft:orange_concrete
fill 439 212 574 439 217 574 minecraft:basalt
fill 439 212 586 439 217 586 minecraft:basalt
fill 441 212 572 441 216 573 minecraft:basalt
fill 441 212 587 441 217 587 minecraft:basalt
fill 442 212 572 445 216 572 minecraft:basalt
fill 442 212 588 442 217 588 minecraft:basalt
setblock 443 212 588 minecraft:magma_block
fill 443 212 593 443 213 593 minecraft:basalt
setblock 443 212 594 minecraft:magma_block
fill 444 212 571 444 217 571 minecraft:basalt
fill 444 212 588 444 217 589 minecraft:basalt
fill 445 212 588 448 217 588 minecraft:basalt
setblock 446 212 566 minecraft:magma_block
setblock 446 212 572 minecraft:magma_block
fill 447 212 572 448 217 572 minecraft:basalt
fill 449 212 573 449 217 573 minecraft:basalt
fill 449 212 587 450 217 587 minecraft:basalt
fill 451 212 574 451 217 574 minecraft:basalt
fill 451 212 586 451 217 586 minecraft:basalt
setblock 452 212 576 minecraft:magma_block
fill 452 212 584 452 217 584 minecraft:basalt
setblock 452 212 585 minecraft:magma_block
fill 453 212 577 453 216 583 minecraft:basalt
setblock 454 212 569 minecraft:basalt
fill 454 212 590 454 212 591 minecraft:basalt
setblock 455 212 570 minecraft:basalt
setblock 455 212 590 minecraft:magma_block
setblock 456 212 571 minecraft:basalt
setblock 456 212 589 minecraft:basalt
setblock 457 212 573 minecraft:basalt
fill 457 212 586 457 212 587 minecraft:basalt
setblock 458 212 577 minecraft:magma_block
fill 458 212 578 458 213 582 minecraft:basalt
setblock 458 212 583 minecraft:magma_block
setblock 433 213 575 minecraft:magma_block
fill 433 213 576 433 213 577 minecraft:basalt
fill 433 213 583 433 214 583 minecraft:basalt
setblock 433 213 584 minecraft:magma_block
setblock 434 213 587 minecraft:basalt
setblock 436 213 571 minecraft:magma_block
setblock 436 213 589 minecraft:magma_block
fill 437 213 578 437 217 578 minecraft:basalt
fill 437 213 581 437 217 581 minecraft:basalt
fill 438 213 577 438 216 577 minecraft:basalt
fill 438 213 583 438 216 583 minecraft:basalt
fill 439 213 575 439 217 575 minecraft:basalt
setblock 439 213 585 minecraft:magma_block
fill 440 213 574 440 217 574 minecraft:basalt
fill 440 213 586 440 217 586 minecraft:basalt
fill 442 213 573 442 217 573 minecraft:basalt
setblock 442 213 587 minecraft:magma_block
fill 442 213 592 442 214 592 minecraft:basalt
setblock 442 213 593 minecraft:magma_block
fill 443 213 588 443 217 588 minecraft:basalt
fill 445 213 567 447 213 567 minecraft:basalt
fill 446 213 572 446 217 572 minecraft:basalt
setblock 448 213 567 minecraft:magma_block
setblock 448 213 573 minecraft:magma_block
fill 448 213 587 448 217 587 minecraft:basalt
fill 450 213 574 450 217 574 minecraft:basalt
fill 450 213 586 450 217 586 minecraft:basalt
setblock 451 213 575 minecraft:magma_block
fill 451 213 585 452 217 585 minecraft:basalt
fill 452 213 576 452 217 577 minecraft:basalt
fill 452 213 583 452 217 583 minecraft:basalt
setblock 454 213 571 minecraft:magma_block
setblock 454 213 589 minecraft:magma_block
setblock 457 213 576 minecraft:magma_block
fill 457 213 577 458 213 577 minecraft:basalt
fill 457 213 583 457 213 584 minecraft:basalt
setblock 457 213 585 minecraft:magma_block
setblock 457 213 586 minecraft:basalt
setblock 458 213 583 minecraft:basalt
fill 423 214 562 423 219 562 minecraft:sea_lantern
fill 423 214 570 423 219 570 minecraft:sea_lantern
fill 423 214 578 423 219 578 minecraft:sea_lantern
fill 423 214 586 423 219 586 minecraft:sea_lantern
fill 423 214 594 423 219 594 minecraft:sea_lantern
fill 426 214 599 426 219 599 minecraft:sea_lantern
fill 430 214 557 430 219 557 minecraft:sea_lantern
setblock 433 214 577 minecraft:basalt
fill 434 214 599 434 219 599 minecraft:sea_lantern
setblock 435 214 573 minecraft:magma_block
setblock 435 214 587 minecraft:basalt
fill 438 214 557 438 219 557 minecraft:sea_lantern
setblock 438 214 570 minecraft:basalt
setblock 438 214 578 minecraft:magma_block
fill 438 214 579 438 216 580 minecraft:basalt
setblock 438 214 581 minecraft:magma_block
fill 438 214 582 438 217 582 minecraft:basalt
setblock 438 214 590 minecraft:magma_block
fill 439 214 576 439 217 577 minecraft:basalt
fill 439 214 583 439 217 585 minecraft:basalt
fill 440 214 575 440 217 575 minecraft:basalt
fill 440 214 585 440 217 585 minecraft:basalt
setblock 441 214 574 minecraft:magma_block
setblock 441 214 586 minecraft:magma_block
setblock 441 214 591 minecraft:basalt
setblock 442 214 568 minecraft:basalt
fill 442 214 574 442 217 574 minecraft:basalt
fill 442 214 586 442 217 587 minecraft:basalt
fill 442 214 599 442 219 599 minecraft:sea_lantern
fill 443 214 573 443 217 573 minecraft:basalt
fill 443 214 587 446 216 587 minecraft:basalt
setblock 444 214 573 minecraft:magma_block
fill 445 214 573 448 217 573 minecraft:basalt
fill 446 214 557 446 219 557 minecraft:sea_lantern
setblock 447 214 587 minecraft:magma_block
fill 447 214 592 448 214 592 minecraft:basalt
setblock 448 214 568 minecraft:basalt
fill 448 214 574 449 217 574 minecraft:basalt
fill 448 214 586 449 217 586 minecraft:basalt
fill 450 214 575 451 217 575 minecraft:basalt
fill 450 214 585 450 216 585 minecraft:basalt
fill 450 214 591 451 214 591 minecraft:basalt
fill 450 214 599 450 219 599 minecraft:sea_lantern
setblock 451 214 569 minecraft:basalt
fill 451 214 576 451 217 577 minecraft:basalt
fill 451 214 583 451 217 584 minecraft:basalt
setblock 452 214 570 minecraft:basalt
fill 452 214 578 452 217 582 minecraft:basalt
fill 454 214 557 454 219 557 minecraft:sea_lantern
setblock 455 214 587 minecraft:basalt
setblock 456 214 575 minecraft:magma_block
setblock 456 214 576 minecraft:basalt
setblock 456 214 584 minecraft:magma_block
setblock 456 214 585 minecraft:basalt
setblock 457 214 577 minecraft:basalt
setblock 457 214 583 minecraft:basalt
fill 458 214 599 458 219 599 minecraft:sea_lantern
fill 462 214 557 462 219 557 minecraft:sea_lantern
fill 465 214 562 465 219 562 minecraft:sea_lantern
fill 465 214 570 465 219 570 minecraft:sea_lantern
fill 465 214 578 465 219 578 minecraft:sea_lantern
fill 465 214 586 465 219 586 minecraft:sea_lantern
fill 465 214 594 465 219 594 minecraft:sea_lantern
setblock 434 215 577 minecraft:basalt
setblock 434 215 578 minecraft:magma_block
setblock 434 215 580 minecraft:basalt
setblock 434 215 581 minecraft:magma_block
fill 434 215 582 434 215 583 minecraft:basalt
setblock 437 215 572 minecraft:basalt
setblock 437 215 588 minecraft:basalt
fill 438 215 578 439 215 578 minecraft:basalt
fill 438 215 581 439 215 581 minecraft:basalt
setblock 439 215 570 minecraft:basalt
fill 439 215 579 439 217 579 minecraft:basalt
fill 439 215 582 439 217 582 minecraft:basalt
setblock 440 215 570 minecraft:magma_block
setblock 440 215 576 minecraft:magma_block
fill 440 215 584 440 217 584 minecraft:basalt
setblock 440 215 590 minecraft:basalt
fill 441 215 574 441 217 575 minecraft:basalt
fill 441 215 585 441 216 586 minecraft:basalt
setblock 442 215 569 minecraft:basalt
setblock 443 215 569 minecraft:magma_block
fill 443 215 574 444 217 574 minecraft:basalt
fill 443 215 586 444 217 586 minecraft:basalt
fill 444 215 573 444 217 573 minecraft:basalt
setblock 446 215 574 minecraft:magma_block
setblock 446 215 586 minecraft:magma_block
fill 447 215 574 447 216 574 minecraft:basalt
fill 447 215 586 447 216 587 minecraft:basalt
fill 447 215 591 448 215 591 minecraft:basalt
setblock 449 215 570 minecraft:magma_block
fill 449 215 575 449 217 575 minecraft:basalt
setblock 449 215 585 minecraft:magma_block
fill 450 215 576 450 216 576 minecraft:basalt
schedule function dropper:buildpart/141_2 1t
