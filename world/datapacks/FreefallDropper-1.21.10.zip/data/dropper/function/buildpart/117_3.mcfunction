fill 447 96 480 450 96 480 minecraft:sea_lantern
fill 447 96 481 449 96 483 minecraft:soul_soil
fill 447 96 485 447 96 487 minecraft:sea_lantern
fill 447 96 489 449 96 491 minecraft:soul_soil
fill 447 96 492 450 96 492 minecraft:sea_lantern
fill 448 96 485 449 96 487 minecraft:dirt
fill 450 96 481 450 96 483 minecraft:sea_lantern
fill 450 96 485 464 96 485 minecraft:soul_soil
setblock 450 96 486 minecraft:dirt
fill 450 96 487 464 96 487 minecraft:soul_soil
fill 450 96 489 450 96 491 minecraft:sea_lantern
fill 451 96 480 464 96 484 minecraft:soul_soil
fill 451 96 486 464 96 486 minecraft:soul_soil
fill 451 96 488 464 96 492 minecraft:soul_soil
setblock 424 100 480 minecraft:blackstone
setblock 424 100 481 minecraft:polished_blackstone_bricks
fill 424 100 482 424 100 485 minecraft:blackstone
setblock 424 100 486 minecraft:polished_blackstone_bricks
fill 424 100 487 424 100 490 minecraft:blackstone
fill 425 100 481 425 100 484 minecraft:blackstone
setblock 425 100 485 minecraft:polished_blackstone_bricks
fill 425 100 486 425 101 488 minecraft:blackstone
setblock 426 100 464 minecraft:polished_blackstone_bricks
setblock 426 100 484 minecraft:polished_blackstone_bricks
fill 426 100 485 426 103 485 minecraft:blackstone
fill 427 100 464 430 100 464 minecraft:blackstone
fill 428 100 504 430 100 504 minecraft:blackstone
setblock 429 100 465 minecraft:blackstone
setblock 430 100 465 minecraft:polished_blackstone_bricks
setblock 431 100 464 minecraft:polished_blackstone_bricks
fill 431 100 465 433 100 466 minecraft:blackstone
setblock 431 100 504 minecraft:polished_blackstone_bricks
fill 432 100 464 435 100 464 minecraft:blackstone
fill 432 100 504 435 100 504 minecraft:blackstone
setblock 434 100 465 minecraft:blackstone
setblock 434 100 466 minecraft:polished_blackstone_bricks
setblock 435 100 465 minecraft:polished_blackstone_bricks
fill 435 100 466 437 101 466 minecraft:blackstone
setblock 436 100 464 minecraft:polished_blackstone_bricks
fill 436 100 465 439 100 465 minecraft:blackstone
setblock 436 100 504 minecraft:polished_blackstone_bricks
fill 437 100 464 440 100 464 minecraft:blackstone
fill 437 100 504 440 100 504 minecraft:blackstone
setblock 440 100 465 minecraft:polished_blackstone_bricks
setblock 441 100 464 minecraft:polished_blackstone_bricks
fill 441 100 465 444 100 465 minecraft:blackstone
setblock 441 100 504 minecraft:polished_blackstone_bricks
fill 442 100 464 445 100 464 minecraft:blackstone
fill 442 100 504 445 100 504 minecraft:blackstone
setblock 445 100 465 minecraft:polished_blackstone_bricks
setblock 446 100 464 minecraft:polished_blackstone_bricks
fill 446 100 465 449 100 465 minecraft:blackstone
setblock 446 100 504 minecraft:polished_blackstone_bricks
fill 447 100 464 450 100 464 minecraft:blackstone
setblock 447 100 503 minecraft:polished_blackstone_bricks
fill 447 100 504 450 100 504 minecraft:blackstone
setblock 448 100 466 minecraft:blackstone
fill 448 100 503 451 100 503 minecraft:blackstone
setblock 449 100 466 minecraft:polished_blackstone_bricks
setblock 450 100 465 minecraft:polished_blackstone_bricks
fill 450 100 466 453 100 466 minecraft:blackstone
fill 450 100 502 452 100 502 minecraft:blackstone
setblock 451 100 464 minecraft:polished_blackstone_bricks
fill 451 100 465 454 100 465 minecraft:blackstone
setblock 451 100 504 minecraft:polished_blackstone_bricks
fill 452 100 464 455 100 464 minecraft:blackstone
setblock 452 100 503 minecraft:polished_blackstone_bricks
fill 452 100 504 455 100 504 minecraft:blackstone
setblock 453 100 502 minecraft:polished_blackstone_bricks
fill 453 100 503 456 100 503 minecraft:blackstone
setblock 454 100 466 minecraft:polished_blackstone_bricks
fill 454 100 502 456 101 502 minecraft:blackstone
setblock 455 100 465 minecraft:polished_blackstone_bricks
setblock 456 100 464 minecraft:polished_blackstone_bricks
fill 456 100 465 457 102 465 minecraft:blackstone
setblock 456 100 504 minecraft:polished_blackstone_bricks
fill 457 100 464 460 100 464 minecraft:blackstone
setblock 457 100 503 minecraft:polished_blackstone_bricks
fill 457 100 504 460 100 504 minecraft:blackstone
fill 458 100 503 459 101 503 minecraft:blackstone
setblock 461 100 504 minecraft:polished_blackstone_bricks
fill 462 100 504 464 101 504 minecraft:blackstone
fill 464 100 482 464 100 485 minecraft:blackstone
setblock 464 100 486 minecraft:polished_blackstone_bricks
fill 464 100 487 464 100 490 minecraft:blackstone
setblock 464 100 491 minecraft:polished_blackstone_bricks
fill 464 100 503 464 102 503 minecraft:blackstone
setblock 424 101 479 minecraft:blackstone
setblock 424 101 480 minecraft:polished_blackstone_bricks
fill 424 101 481 424 101 484 minecraft:blackstone
setblock 424 101 485 minecraft:polished_blackstone_bricks
fill 424 101 486 424 101 489 minecraft:blackstone
setblock 424 101 490 minecraft:polished_blackstone_bricks
fill 424 101 491 424 103 492 minecraft:blackstone
setblock 425 101 464 minecraft:polished_blackstone_bricks
fill 425 101 481 425 101 483 minecraft:blackstone
setblock 425 101 484 minecraft:polished_blackstone_bricks
fill 425 101 485 425 104 485 minecraft:blackstone
setblock 425 101 489 minecraft:polished_blackstone_bricks
fill 425 101 490 425 104 490 minecraft:blackstone
fill 426 101 464 429 101 464 minecraft:blackstone
setblock 426 101 483 minecraft:polished_blackstone_bricks
fill 426 101 484 426 104 484 minecraft:blackstone
fill 426 101 486 426 101 487 minecraft:blackstone
fill 427 101 465 428 101 465 minecraft:blackstone
fill 427 101 504 429 101 504 minecraft:blackstone
setblock 429 101 465 minecraft:polished_blackstone_bricks
fill 429 101 466 432 101 466 minecraft:blackstone
setblock 430 101 464 minecraft:polished_blackstone_bricks
fill 430 101 465 433 101 465 minecraft:blackstone
setblock 430 101 504 minecraft:polished_blackstone_bricks
fill 431 101 464 434 101 464 minecraft:blackstone
fill 431 101 504 434 101 504 minecraft:blackstone
setblock 433 101 466 minecraft:polished_blackstone_bricks
setblock 434 101 465 minecraft:polished_blackstone_bricks
fill 434 101 466 434 104 466 minecraft:blackstone
setblock 435 101 464 minecraft:polished_blackstone_bricks
fill 435 101 465 438 101 465 minecraft:blackstone
setblock 435 101 504 minecraft:polished_blackstone_bricks
fill 436 101 464 439 101 464 minecraft:blackstone
fill 436 101 504 439 101 504 minecraft:blackstone
setblock 438 101 466 minecraft:polished_blackstone_bricks
setblock 439 101 465 minecraft:polished_blackstone_bricks
setblock 440 101 464 minecraft:polished_blackstone_bricks
fill 440 101 465 443 101 465 minecraft:blackstone
setblock 440 101 504 minecraft:polished_blackstone_bricks
fill 441 101 464 444 101 464 minecraft:blackstone
fill 441 101 504 444 101 504 minecraft:blackstone
setblock 444 101 465 minecraft:polished_blackstone_bricks
setblock 445 101 464 minecraft:polished_blackstone_bricks
fill 445 101 465 448 101 465 minecraft:blackstone
setblock 445 101 504 minecraft:polished_blackstone_bricks
fill 446 101 464 449 101 464 minecraft:blackstone
fill 446 101 466 447 101 466 minecraft:blackstone
setblock 446 101 503 minecraft:polished_blackstone_bricks
fill 446 101 504 449 101 504 minecraft:blackstone
fill 447 101 503 450 101 503 minecraft:blackstone
setblock 448 101 466 minecraft:polished_blackstone_bricks
setblock 449 101 465 minecraft:polished_blackstone_bricks
fill 449 101 466 452 101 466 minecraft:blackstone
setblock 450 101 464 minecraft:polished_blackstone_bricks
fill 450 101 465 453 101 465 minecraft:blackstone
fill 450 101 502 451 101 502 minecraft:blackstone
setblock 450 101 504 minecraft:polished_blackstone_bricks
fill 451 101 464 454 101 464 minecraft:blackstone
setblock 451 101 503 minecraft:polished_blackstone_bricks
fill 451 101 504 454 101 504 minecraft:blackstone
setblock 452 101 502 minecraft:polished_blackstone_bricks
fill 452 101 503 455 101 503 minecraft:blackstone
setblock 453 101 466 minecraft:polished_blackstone_bricks
fill 453 101 502 453 104 502 minecraft:blackstone
setblock 454 101 465 minecraft:polished_blackstone_bricks
fill 454 101 466 455 103 466 minecraft:blackstone
setblock 455 101 464 minecraft:polished_blackstone_bricks
fill 455 101 465 455 104 465 minecraft:blackstone
setblock 455 101 504 minecraft:polished_blackstone_bricks
fill 456 101 464 459 101 464 minecraft:blackstone
setblock 456 101 503 minecraft:polished_blackstone_bricks
fill 456 101 504 459 101 504 minecraft:blackstone
fill 457 101 503 457 104 503 minecraft:blackstone
setblock 460 101 464 minecraft:polished_blackstone_bricks
setblock 460 101 504 minecraft:polished_blackstone_bricks
fill 461 101 464 461 104 464 minecraft:blackstone
fill 461 101 504 461 104 504 minecraft:blackstone
setblock 463 101 485 minecraft:blackstone
setblock 463 101 486 minecraft:polished_blackstone_bricks
fill 463 101 487 464 101 489 minecraft:blackstone
fill 464 101 482 464 101 484 minecraft:blackstone
setblock 464 101 485 minecraft:polished_blackstone_bricks
fill 464 101 486 464 104 486 minecraft:blackstone
setblock 464 101 490 minecraft:polished_blackstone_bricks
fill 464 101 491 464 102 493 minecraft:blackstone
fill 423 102 463 423 105 464 minecraft:basalt
fill 423 102 465 424 102 465 minecraft:blackstone
fill 423 102 466 423 102 505 minecraft:basalt
fill 424 102 463 424 103 463 minecraft:blackstone
setblock 424 102 464 minecraft:polished_blackstone_bricks
fill 424 102 466 424 102 468 minecraft:blackstone
setblock 424 102 469 minecraft:polished_blackstone_bricks
setblock 424 102 478 minecraft:blackstone
setblock 424 102 479 minecraft:polished_blackstone_bricks
fill 424 102 480 424 102 483 minecraft:blackstone
setblock 424 102 484 minecraft:polished_blackstone_bricks
fill 424 102 485 424 102 488 minecraft:blackstone
setblock 424 102 489 minecraft:polished_blackstone_bricks
fill 424 102 490 424 105 490 minecraft:blackstone
setblock 424 102 493 minecraft:blackstone
fill 424 102 505 424 105 505 minecraft:basalt
fill 425 102 463 429 102 463 minecraft:basalt
fill 425 102 464 428 102 464 minecraft:blackstone
fill 425 102 480 425 102 482 minecraft:blackstone
setblock 425 102 483 minecraft:polished_blackstone_bricks
fill 425 102 484 425 105 484 minecraft:blackstone
fill 425 102 486 425 102 487 minecraft:blackstone
setblock 425 102 488 minecraft:polished_blackstone_bricks
fill 425 102 489 426 104 489 minecraft:blackstone
fill 425 102 491 425 103 491 minecraft:blackstone
setblock 425 102 505 minecraft:blackstone
fill 426 102 465 427 102 465 minecraft:blackstone
setblock 426 102 466 minecraft:light[level=11]
setblock 426 102 474 minecraft:light[level=11]
setblock 426 102 482 minecraft:polished_blackstone_bricks
fill 426 102 483 426 105 483 minecraft:blackstone
setblock 426 102 486 minecraft:blackstone
setblock 426 102 487 minecraft:polished_blackstone_bricks
fill 426 102 488 426 105 488 minecraft:blackstone
setblock 426 102 490 minecraft:light[level=11]
setblock 426 102 498 minecraft:light[level=11]
fill 426 102 504 428 102 504 minecraft:blackstone
fill 426 102 505 432 105 505 minecraft:basalt
setblock 428 102 465 minecraft:polished_blackstone_bricks
fill 428 102 466 431 102 466 minecraft:blackstone
setblock 429 102 464 minecraft:polished_blackstone_bricks
fill 429 102 465 432 102 465 minecraft:blackstone
setblock 429 102 504 minecraft:polished_blackstone_bricks
fill 430 102 463 430 102 464 minecraft:blackstone
fill 430 102 504 433 102 504 minecraft:blackstone
fill 431 102 463 438 103 463 minecraft:basalt
fill 431 102 464 433 102 464 minecraft:blackstone
setblock 431 102 467 minecraft:polished_blackstone_bricks
setblock 432 102 466 minecraft:polished_blackstone_bricks
fill 432 102 467 434 103 467 minecraft:blackstone
setblock 433 102 465 minecraft:polished_blackstone_bricks
fill 433 102 466 433 105 466 minecraft:blackstone
fill 433 102 505 433 103 505 minecraft:blackstone
setblock 434 102 464 minecraft:polished_blackstone_bricks
fill 434 102 465 437 102 465 minecraft:blackstone
setblock 434 102 474 minecraft:light[level=11]
setblock 434 102 482 minecraft:light[level=11]
setblock 434 102 490 minecraft:light[level=11]
setblock 434 102 498 minecraft:light[level=11]
setblock 434 102 504 minecraft:polished_blackstone_bricks
fill 434 102 505 440 105 505 minecraft:basalt
fill 435 102 464 438 102 464 minecraft:blackstone
fill 435 102 466 436 102 466 minecraft:blackstone
fill 435 102 504 438 102 504 minecraft:blackstone
setblock 437 102 466 minecraft:polished_blackstone_bricks
setblock 438 102 465 minecraft:polished_blackstone_bricks
fill 438 102 466 439 104 466 minecraft:blackstone
setblock 439 102 463 minecraft:blackstone
setblock 439 102 464 minecraft:polished_blackstone_bricks
fill 439 102 465 442 102 465 minecraft:blackstone
fill 439 102 497 443 103 501 minecraft:blackstone
setblock 439 102 504 minecraft:polished_blackstone_bricks
fill 440 102 463 458 102 463 minecraft:basalt
fill 440 102 464 443 102 464 minecraft:blackstone
fill 440 102 504 443 102 504 minecraft:blackstone
fill 441 102 502 441 102 503 minecraft:blackstone
setblock 441 102 505 minecraft:blackstone
setblock 442 102 466 minecraft:light[level=11]
setblock 442 102 474 minecraft:light[level=11]
setblock 442 102 482 minecraft:light[level=11]
setblock 442 102 490 minecraft:light[level=11]
fill 442 102 505 459 103 505 minecraft:basalt
setblock 443 102 465 minecraft:polished_blackstone_bricks
setblock 444 102 464 minecraft:polished_blackstone_bricks
fill 444 102 465 446 102 466 minecraft:blackstone
setblock 444 102 504 minecraft:polished_blackstone_bricks
fill 445 102 464 448 102 464 minecraft:blackstone
fill 445 102 494 447 103 494 minecraft:cyan_stained_glass
fill 445 102 504 448 102 504 minecraft:blackstone
fill 446 102 493 446 103 493 minecraft:cyan_stained_glass
fill 446 102 495 446 103 495 minecraft:cyan_stained_glass
fill 446 102 503 449 102 503 minecraft:blackstone
setblock 447 102 465 minecraft:blackstone
setblock 447 102 466 minecraft:polished_blackstone_bricks
setblock 448 102 465 minecraft:polished_blackstone_bricks
fill 448 102 466 451 102 466 minecraft:blackstone
setblock 449 102 464 minecraft:polished_blackstone_bricks
fill 449 102 465 452 102 465 minecraft:blackstone
fill 449 102 502 450 102 502 minecraft:blackstone
setblock 449 102 504 minecraft:polished_blackstone_bricks
fill 450 102 464 453 102 464 minecraft:blackstone
setblock 450 102 474 minecraft:light[level=11]
setblock 450 102 482 minecraft:light[level=11]
setblock 450 102 490 minecraft:light[level=11]
setblock 450 102 498 minecraft:light[level=11]
setblock 450 102 503 minecraft:polished_blackstone_bricks
fill 450 102 504 453 102 504 minecraft:blackstone
setblock 451 102 502 minecraft:polished_blackstone_bricks
fill 451 102 503 454 102 503 minecraft:blackstone
setblock 452 102 466 minecraft:polished_blackstone_bricks
fill 452 102 502 452 105 502 minecraft:blackstone
setblock 453 102 465 minecraft:polished_blackstone_bricks
fill 453 102 466 453 105 466 minecraft:blackstone
setblock 454 102 464 minecraft:polished_blackstone_bricks
fill 454 102 465 454 105 465 minecraft:blackstone
fill 454 102 502 455 102 502 minecraft:blackstone
setblock 454 102 504 minecraft:polished_blackstone_bricks
fill 455 102 464 458 102 464 minecraft:blackstone
setblock 455 102 503 minecraft:polished_blackstone_bricks
fill 455 102 504 458 102 504 minecraft:blackstone
fill 456 102 503 456 105 503 minecraft:blackstone
setblock 458 102 466 minecraft:light[level=11]
setblock 458 102 474 minecraft:light[level=11]
setblock 458 102 482 minecraft:light[level=11]
setblock 458 102 490 minecraft:light[level=11]
setblock 458 102 498 minecraft:light[level=11]
fill 458 102 503 458 103 503 minecraft:blackstone
fill 459 102 463 459 103 463 minecraft:blackstone
setblock 459 102 464 minecraft:polished_blackstone_bricks
setblock 459 102 504 minecraft:polished_blackstone_bricks
fill 460 102 463 464 102 463 minecraft:basalt
fill 460 102 464 460 104 464 minecraft:blackstone
fill 460 102 504 460 103 505 minecraft:blackstone
fill 461 102 505 461 105 505 minecraft:basalt
fill 462 102 504 462 102 505 minecraft:blackstone
setblock 463 102 484 minecraft:blackstone
setblock 463 102 485 minecraft:polished_blackstone_bricks
fill 463 102 486 463 102 489 minecraft:blackstone
setblock 463 102 490 minecraft:polished_blackstone_bricks
fill 463 102 491 463 105 491 minecraft:blackstone
setblock 463 102 504 minecraft:blackstone
fill 463 102 505 465 102 505 minecraft:basalt
setblock 464 102 464 minecraft:polished_blackstone_bricks
fill 464 102 465 464 105 465 minecraft:blackstone
fill 464 102 481 464 102 483 minecraft:blackstone
setblock 464 102 484 minecraft:polished_blackstone_bricks
fill 464 102 485 464 105 485 minecraft:blackstone
fill 464 102 487 464 102 488 minecraft:blackstone
setblock 464 102 489 minecraft:polished_blackstone_bricks
fill 464 102 490 464 105 490 minecraft:blackstone
setblock 464 102 494 minecraft:polished_blackstone_bricks
fill 464 102 495 464 105 495 minecraft:blackstone
setblock 464 102 504 minecraft:polished_blackstone_bricks
setblock 465 102 463 minecraft:blackstone
fill 465 102 464 465 103 470 minecraft:basalt
setblock 465 102 471 minecraft:blackstone
fill 465 102 472 465 102 476 minecraft:basalt
fill 465 102 477 465 104 477 minecraft:blackstone
fill 465 102 478 465 105 480 minecraft:basalt
fill 465 102 481 465 103 481 minecraft:blackstone
fill 465 102 482 465 105 486 minecraft:basalt
setblock 465 102 487 minecraft:blackstone
fill 465 102 488 465 102 490 minecraft:basalt
fill 465 102 491 465 103 491 minecraft:blackstone
fill 465 102 492 465 105 497 minecraft:basalt
setblock 465 102 498 minecraft:blackstone
fill 465 102 499 465 103 504 minecraft:basalt
fill 423 103 465 423 103 466 minecraft:basalt
fill 423 103 467 424 103 467 minecraft:blackstone
fill 423 103 468 423 105 468 minecraft:basalt
fill 423 103 469 425 103 469 minecraft:blackstone
setblock 423 103 470 minecraft:basalt
fill 423 103 471 424 103 471 minecraft:blackstone
fill 423 103 472 423 103 489 minecraft:basalt
setblock 423 103 490 minecraft:blackstone
fill 423 103 491 423 105 501 minecraft:basalt
setblock 423 103 502 minecraft:blackstone
fill 423 103 503 423 105 505 minecraft:basalt
fill 424 103 464 425 103 466 minecraft:blackstone
setblock 424 103 468 minecraft:polished_blackstone_bricks
fill 424 103 470 425 104 470 minecraft:blackstone
setblock 424 103 472 minecraft:blackstone
setblock 424 103 473 minecraft:polished_blackstone_bricks
fill 424 103 474 424 106 474 minecraft:blackstone
fill 424 103 476 424 103 477 minecraft:blackstone
setblock 424 103 478 minecraft:polished_blackstone_bricks
fill 424 103 479 424 103 482 minecraft:blackstone
setblock 424 103 483 minecraft:polished_blackstone_bricks
fill 424 103 484 424 103 487 minecraft:blackstone
setblock 424 103 488 minecraft:polished_blackstone_bricks
fill 424 103 489 424 106 489 minecraft:blackstone
setblock 424 103 493 minecraft:polished_blackstone_bricks
fill 424 103 494 424 106 494 minecraft:blackstone
fill 425 103 463 425 104 463 minecraft:blackstone
setblock 425 103 467 minecraft:polished_blackstone_bricks
fill 425 103 468 425 106 468 minecraft:blackstone
fill 425 103 480 425 103 481 minecraft:blackstone
setblock 425 103 482 minecraft:polished_blackstone_bricks
fill 425 103 483 425 106 483 minecraft:blackstone
setblock 425 103 486 minecraft:blackstone
setblock 425 103 487 minecraft:polished_blackstone_bricks
fill 425 103 488 425 106 488 minecraft:blackstone
setblock 425 103 492 minecraft:polished_blackstone_bricks
fill 425 103 505 425 106 505 minecraft:basalt
fill 426 103 463 427 103 463 minecraft:basalt
fill 426 103 464 426 103 465 minecraft:blackstone
fill 426 103 482 426 106 482 minecraft:blackstone
setblock 426 103 486 minecraft:polished_blackstone_bricks
fill 426 103 487 427 105 487 minecraft:blackstone
setblock 426 103 490 minecraft:blackstone
fill 426 103 504 427 103 504 minecraft:blackstone
setblock 427 103 464 minecraft:blackstone
setblock 427 103 465 minecraft:polished_blackstone_bricks
fill 427 103 466 430 103 466 minecraft:blackstone
setblock 427 103 484 minecraft:blackstone
setblock 427 103 485 minecraft:polished_blackstone_bricks
fill 427 103 486 427 106 486 minecraft:blackstone
fill 427 103 488 427 104 488 minecraft:blackstone
fill 428 103 463 428 104 463 minecraft:blackstone
setblock 428 103 464 minecraft:polished_blackstone_bricks
fill 428 103 465 431 103 465 minecraft:blackstone
setblock 428 103 504 minecraft:polished_blackstone_bricks
fill 429 103 463 430 105 463 minecraft:basalt
fill 429 103 464 432 103 464 minecraft:blackstone
setblock 429 103 467 minecraft:blackstone
fill 429 103 504 432 103 504 minecraft:blackstone
setblock 430 103 467 minecraft:polished_blackstone_bricks
setblock 431 103 466 minecraft:polished_blackstone_bricks
fill 431 103 467 431 106 467 minecraft:blackstone
setblock 432 103 465 minecraft:polished_blackstone_bricks
fill 432 103 466 432 106 466 minecraft:blackstone
setblock 433 103 464 minecraft:polished_blackstone_bricks
fill 433 103 465 436 103 465 minecraft:blackstone
setblock 433 103 504 minecraft:polished_blackstone_bricks
fill 434 103 464 437 103 464 minecraft:blackstone
fill 434 103 504 437 103 504 minecraft:blackstone
setblock 435 103 466 minecraft:blackstone
setblock 435 103 467 minecraft:polished_blackstone_bricks
setblock 436 103 466 minecraft:polished_blackstone_bricks
setblock 437 103 465 minecraft:polished_blackstone_bricks
fill 437 103 466 437 106 466 minecraft:blackstone
setblock 438 103 464 minecraft:polished_blackstone_bricks
fill 438 103 465 441 103 465 minecraft:blackstone
setblock 438 103 504 minecraft:polished_blackstone_bricks
fill 439 103 463 445 103 463 minecraft:basalt
fill 439 103 464 442 103 464 minecraft:blackstone
fill 439 103 504 442 103 504 minecraft:blackstone
setblock 440 103 466 minecraft:blackstone
setblock 441 103 466 minecraft:polished_blackstone_bricks
setblock 441 103 505 minecraft:basalt
setblock 442 103 465 minecraft:polished_blackstone_bricks
fill 442 103 466 445 103 466 minecraft:blackstone
setblock 443 103 464 minecraft:polished_blackstone_bricks
fill 443 103 465 446 103 465 minecraft:blackstone
setblock 443 103 504 minecraft:polished_blackstone_bricks
fill 444 103 464 447 103 464 minecraft:blackstone
fill 444 103 504 447 103 504 minecraft:blackstone
fill 445 103 503 448 103 503 minecraft:blackstone
setblock 446 103 463 minecraft:blackstone
setblock 446 103 466 minecraft:polished_blackstone_bricks
fill 447 103 463 453 103 463 minecraft:basalt
setblock 447 103 465 minecraft:polished_blackstone_bricks
fill 447 103 466 450 103 466 minecraft:blackstone
setblock 448 103 464 minecraft:polished_blackstone_bricks
fill 448 103 465 451 103 465 minecraft:blackstone
fill 448 103 467 449 103 467 minecraft:blackstone
fill 448 103 502 449 103 502 minecraft:blackstone
setblock 448 103 504 minecraft:polished_blackstone_bricks
fill 449 103 464 452 103 464 minecraft:blackstone
setblock 449 103 503 minecraft:polished_blackstone_bricks
fill 449 103 504 452 103 504 minecraft:blackstone
setblock 450 103 467 minecraft:polished_blackstone_bricks
setblock 450 103 502 minecraft:polished_blackstone_bricks
fill 450 103 503 453 103 503 minecraft:blackstone
setblock 451 103 466 minecraft:polished_blackstone_bricks
fill 451 103 467 452 104 467 minecraft:blackstone
fill 451 103 502 451 106 502 minecraft:blackstone
setblock 452 103 465 minecraft:polished_blackstone_bricks
fill 452 103 466 452 106 466 minecraft:blackstone
setblock 453 103 464 minecraft:polished_blackstone_bricks
fill 453 103 465 453 106 465 minecraft:blackstone
setblock 453 103 504 minecraft:polished_blackstone_bricks
fill 454 103 463 454 103 464 minecraft:blackstone
setblock 454 103 502 minecraft:blackstone
setblock 454 103 503 minecraft:polished_blackstone_bricks
fill 454 103 504 457 103 504 minecraft:blackstone
fill 455 103 463 458 105 463 minecraft:basalt
fill 455 103 464 457 103 464 minecraft:blackstone
fill 455 103 503 455 106 503 minecraft:blackstone
setblock 456 103 465 minecraft:blackstone
setblock 457 103 465 minecraft:polished_blackstone_bricks
setblock 458 103 464 minecraft:polished_blackstone_bricks
setblock 458 103 504 minecraft:polished_blackstone_bricks
fill 459 103 464 459 105 464 minecraft:blackstone
fill 459 103 504 459 105 504 minecraft:blackstone
fill 460 103 463 461 103 463 minecraft:basalt
fill 462 103 463 462 103 464 minecraft:blackstone
setblock 462 103 504 minecraft:blackstone
fill 462 103 505 462 106 505 minecraft:basalt
fill 463 103 463 465 105 463 minecraft:basalt
setblock 463 103 464 minecraft:polished_blackstone_bricks
setblock 463 103 484 minecraft:polished_blackstone_bricks
fill 463 103 485 463 103 488 minecraft:blackstone
setblock 463 103 489 minecraft:polished_blackstone_bricks
fill 463 103 490 463 106 490 minecraft:blackstone
fill 463 103 492 463 103 493 minecraft:blackstone
setblock 463 103 504 minecraft:polished_blackstone_bricks
setblock 463 103 505 minecraft:blackstone
fill 464 103 464 464 106 464 minecraft:blackstone
fill 464 103 466 464 103 467 minecraft:blackstone
setblock 464 103 468 minecraft:polished_blackstone_bricks
fill 464 103 481 464 103 482 minecraft:blackstone
setblock 464 103 483 minecraft:polished_blackstone_bricks
fill 464 103 484 464 106 484 minecraft:blackstone
setblock 464 103 487 minecraft:blackstone
setblock 464 103 488 minecraft:polished_blackstone_bricks
fill 464 103 489 464 106 489 minecraft:blackstone
fill 464 103 491 464 103 492 minecraft:blackstone
setblock 464 103 493 minecraft:polished_blackstone_bricks
fill 464 103 494 464 106 494 minecraft:blackstone
fill 464 103 496 464 103 497 minecraft:blackstone
setblock 464 103 502 minecraft:blackstone
setblock 464 103 503 minecraft:polished_blackstone_bricks
fill 464 103 504 464 105 504 minecraft:blackstone
fill 464 103 505 465 105 505 minecraft:basalt
fill 465 103 471 465 103 474 minecraft:basalt
setblock 465 103 475 minecraft:blackstone
fill 465 103 476 465 105 476 minecraft:basalt
fill 465 103 487 465 105 489 minecraft:basalt
setblock 465 103 490 minecraft:blackstone
fill 465 103 498 465 105 498 minecraft:basalt
fill 423 104 465 425 104 465 minecraft:blackstone
fill 423 104 466 423 105 467 minecraft:basalt
fill 423 104 469 423 105 469 minecraft:basalt
setblock 423 104 470 minecraft:blackstone
fill 423 104 471 423 105 476 minecraft:basalt
fill 423 104 477 423 104 478 minecraft:blackstone
fill 423 104 479 423 105 490 minecraft:basalt
fill 423 104 502 423 105 502 minecraft:basalt
fill 424 104 463 424 105 463 minecraft:basalt
fill 424 104 464 426 104 464 minecraft:blackstone
setblock 424 104 466 minecraft:blackstone
setblock 424 104 467 minecraft:polished_blackstone_bricks
fill 424 104 468 424 106 469 minecraft:blackstone
setblock 424 104 471 minecraft:blackstone
setblock 424 104 472 minecraft:polished_blackstone_bricks
fill 424 104 473 425 106 473 minecraft:blackstone
fill 424 104 475 424 104 476 minecraft:blackstone
setblock 424 104 477 minecraft:polished_blackstone_bricks
fill 424 104 478 424 104 481 minecraft:blackstone
setblock 424 104 482 minecraft:polished_blackstone_bricks
fill 424 104 483 424 104 486 minecraft:blackstone
setblock 424 104 487 minecraft:polished_blackstone_bricks
fill 424 104 488 424 107 488 minecraft:blackstone
setblock 424 104 491 minecraft:blackstone
setblock 424 104 492 minecraft:polished_blackstone_bricks
fill 424 104 493 425 106 493 minecraft:blackstone
fill 424 104 495 424 105 495 minecraft:blackstone
setblock 425 104 466 minecraft:polished_blackstone_bricks
fill 425 104 467 426 106 467 minecraft:blackstone
fill 425 104 469 426 104 469 minecraft:blackstone
setblock 425 104 471 minecraft:polished_blackstone_bricks
fill 425 104 472 425 107 472 minecraft:blackstone
fill 425 104 474 425 105 474 minecraft:blackstone
fill 425 104 478 425 104 480 minecraft:blackstone
setblock 425 104 481 minecraft:polished_blackstone_bricks
fill 425 104 482 425 107 482 minecraft:blackstone
setblock 425 104 486 minecraft:polished_blackstone_bricks
fill 425 104 487 425 107 487 minecraft:blackstone
setblock 425 104 491 minecraft:polished_blackstone_bricks
fill 425 104 492 425 107 492 minecraft:blackstone
setblock 426 104 463 minecraft:blackstone
setblock 426 104 465 minecraft:polished_blackstone_bricks
fill 426 104 466 429 104 466 minecraft:blackstone
fill 426 104 468 426 105 468 minecraft:blackstone
setblock 426 104 470 minecraft:polished_blackstone_bricks
fill 426 104 471 426 107 471 minecraft:blackstone
fill 426 104 481 426 105 481 minecraft:blackstone
setblock 426 104 485 minecraft:polished_blackstone_bricks
fill 426 104 486 426 107 486 minecraft:blackstone
setblock 426 104 490 minecraft:polished_blackstone_bricks
fill 426 104 491 426 107 491 minecraft:blackstone
setblock 426 104 504 minecraft:blackstone
fill 427 104 463 427 106 463 minecraft:basalt
setblock 427 104 464 minecraft:polished_blackstone_bricks
fill 427 104 465 430 104 465 minecraft:blackstone
setblock 427 104 484 minecraft:polished_blackstone_bricks
fill 427 104 485 427 105 485 minecraft:blackstone
setblock 427 104 489 minecraft:polished_blackstone_bricks
setblock 427 104 504 minecraft:polished_blackstone_bricks
fill 428 104 464 431 104 464 minecraft:blackstone
setblock 428 104 467 minecraft:blackstone
fill 428 104 504 431 104 504 minecraft:blackstone
setblock 429 104 467 minecraft:polished_blackstone_bricks
setblock 430 104 466 minecraft:polished_blackstone_bricks
fill 430 104 467 430 107 467 minecraft:blackstone
fill 431 104 463 436 105 463 minecraft:basalt
setblock 431 104 465 minecraft:polished_blackstone_bricks
fill 431 104 466 431 107 466 minecraft:blackstone
setblock 432 104 464 minecraft:polished_blackstone_bricks
fill 432 104 465 435 104 465 minecraft:blackstone
fill 432 104 467 433 104 467 minecraft:blackstone
setblock 432 104 504 minecraft:polished_blackstone_bricks
fill 433 104 464 436 104 464 minecraft:blackstone
fill 433 104 504 436 104 504 minecraft:blackstone
fill 433 104 505 433 105 505 minecraft:basalt
setblock 434 104 467 minecraft:polished_blackstone_bricks
setblock 435 104 466 minecraft:polished_blackstone_bricks
fill 435 104 467 435 105 467 minecraft:blackstone
setblock 436 104 465 minecraft:polished_blackstone_bricks
fill 436 104 466 436 107 466 minecraft:blackstone
setblock 437 104 463 minecraft:blackstone
setblock 437 104 464 minecraft:polished_blackstone_bricks
fill 437 104 465 440 104 465 minecraft:blackstone
setblock 437 104 504 minecraft:polished_blackstone_bricks
fill 438 104 463 438 107 463 minecraft:basalt
fill 438 104 464 441 104 464 minecraft:blackstone
fill 438 104 504 441 104 504 minecraft:blackstone
setblock 439 104 463 minecraft:blackstone
fill 440 104 463 443 105 463 minecraft:basalt
setblock 440 104 466 minecraft:polished_blackstone_bricks
fill 440 104 499 442 110 499 minecraft:polished_blackstone_bricks
setblock 441 104 465 minecraft:polished_blackstone_bricks
fill 441 104 466 444 104 466 minecraft:blackstone
fill 441 104 498 441 110 498 minecraft:polished_blackstone_bricks
fill 441 104 500 441 110 500 minecraft:polished_blackstone_bricks
setblock 441 104 505 minecraft:blackstone
setblock 442 104 464 minecraft:polished_blackstone_bricks
fill 442 104 465 445 104 465 minecraft:blackstone
setblock 442 104 504 minecraft:polished_blackstone_bricks
fill 442 104 505 445 105 505 minecraft:basalt
fill 443 104 464 446 104 464 minecraft:blackstone
fill 443 104 504 446 104 504 minecraft:blackstone
setblock 444 104 463 minecraft:blackstone
fill 445 104 463 452 105 463 minecraft:basalt
setblock 445 104 466 minecraft:polished_blackstone_bricks
fill 445 104 503 447 104 503 minecraft:blackstone
setblock 446 104 465 minecraft:polished_blackstone_bricks
fill 446 104 466 448 104 467 minecraft:blackstone
setblock 446 104 505 minecraft:blackstone
setblock 447 104 464 minecraft:polished_blackstone_bricks
fill 447 104 465 450 104 465 minecraft:blackstone
setblock 447 104 504 minecraft:polished_blackstone_bricks
fill 447 104 505 460 105 505 minecraft:basalt
fill 448 104 464 451 104 464 minecraft:blackstone
setblock 448 104 502 minecraft:blackstone
setblock 448 104 503 minecraft:polished_blackstone_bricks
fill 448 104 504 451 104 504 minecraft:blackstone
setblock 449 104 466 minecraft:blackstone
setblock 449 104 467 minecraft:polished_blackstone_bricks
setblock 449 104 502 minecraft:polished_blackstone_bricks
fill 449 104 503 452 104 503 minecraft:blackstone
setblock 450 104 466 minecraft:polished_blackstone_bricks
fill 450 104 467 450 106 467 minecraft:blackstone
fill 450 104 502 450 107 502 minecraft:blackstone
setblock 451 104 465 minecraft:polished_blackstone_bricks
fill 451 104 466 451 107 466 minecraft:blackstone
setblock 452 104 464 minecraft:polished_blackstone_bricks
fill 452 104 465 452 107 465 minecraft:blackstone
setblock 452 104 504 minecraft:polished_blackstone_bricks
fill 453 104 463 453 104 464 minecraft:blackstone
setblock 453 104 503 minecraft:polished_blackstone_bricks
fill 453 104 504 456 104 504 minecraft:blackstone
fill 454 104 463 454 105 463 minecraft:basalt
fill 454 104 464 456 104 464 minecraft:blackstone
setblock 454 104 466 minecraft:blackstone
setblock 454 104 502 minecraft:polished_blackstone_bricks
fill 454 104 503 454 106 503 minecraft:blackstone
setblock 455 104 466 minecraft:polished_blackstone_bricks
setblock 456 104 465 minecraft:polished_blackstone_bricks
setblock 457 104 464 minecraft:polished_blackstone_bricks
setblock 457 104 465 minecraft:blackstone
setblock 457 104 504 minecraft:polished_blackstone_bricks
fill 458 104 464 458 105 464 minecraft:blackstone
fill 458 104 504 458 106 504 minecraft:blackstone
fill 459 104 463 460 105 463 minecraft:basalt
fill 460 104 504 460 105 504 minecraft:blackstone
setblock 461 104 463 minecraft:blackstone
fill 462 104 463 462 106 463 minecraft:basalt
setblock 462 104 464 minecraft:polished_blackstone_bricks
fill 462 104 487 462 104 488 minecraft:blackstone
setblock 462 104 489 minecraft:polished_blackstone_bricks
fill 462 104 490 462 107 490 minecraft:blackstone
setblock 462 104 504 minecraft:polished_blackstone_bricks
fill 463 104 464 463 106 464 minecraft:blackstone
fill 463 104 484 463 104 487 minecraft:blackstone
setblock 463 104 488 minecraft:polished_blackstone_bricks
fill 463 104 489 463 107 489 minecraft:blackstone
setblock 463 104 492 minecraft:blackstone
setblock 463 104 493 minecraft:polished_blackstone_bricks
fill 463 104 494 463 107 494 minecraft:blackstone
fill 463 104 504 463 105 504 minecraft:blackstone
fill 463 104 505 463 105 505 minecraft:basalt
setblock 464 104 466 minecraft:blackstone
setblock 464 104 467 minecraft:polished_blackstone_bricks
fill 464 104 468 464 105 470 minecraft:blackstone
fill 464 104 480 464 104 481 minecraft:blackstone
setblock 464 104 482 minecraft:polished_blackstone_bricks
fill 464 104 483 464 107 483 minecraft:blackstone
setblock 464 104 487 minecraft:polished_blackstone_bricks
fill 464 104 488 464 107 488 minecraft:blackstone
setblock 464 104 491 minecraft:blackstone
setblock 464 104 492 minecraft:polished_blackstone_bricks
fill 464 104 493 464 107 493 minecraft:blackstone
setblock 464 104 496 minecraft:blackstone
setblock 464 104 497 minecraft:polished_blackstone_bricks
fill 464 104 498 464 107 498 minecraft:blackstone
fill 464 104 503 464 105 503 minecraft:blackstone
fill 465 104 464 465 105 464 minecraft:basalt
setblock 465 104 465 minecraft:blackstone
fill 465 104 466 465 105 472 minecraft:basalt
setblock 465 104 473 minecraft:blackstone
fill 465 104 474 465 105 475 minecraft:basalt
fill 465 104 481 465 105 481 minecraft:basalt
fill 465 104 490 465 105 491 minecraft:basalt
fill 465 104 499 465 105 499 minecraft:basalt
setblock 465 104 500 minecraft:blackstone
fill 465 104 501 465 105 504 minecraft:basalt
setblock 423 105 465 minecraft:basalt
setblock 423 105 470 minecraft:basalt
fill 423 105 477 423 105 478 minecraft:basalt
fill 424 105 464 424 105 465 minecraft:blackstone
setblock 424 105 466 minecraft:polished_blackstone_bricks
fill 424 105 467 424 108 467 minecraft:blackstone
setblock 424 105 470 minecraft:blackstone
setblock 424 105 471 minecraft:polished_blackstone_bricks
fill 424 105 472 424 108 472 minecraft:blackstone
setblock 424 105 475 minecraft:blackstone
setblock 424 105 476 minecraft:polished_blackstone_bricks
fill 424 105 477 424 105 480 minecraft:blackstone
setblock 424 105 481 minecraft:polished_blackstone_bricks
fill 424 105 482 424 105 485 minecraft:blackstone
setblock 424 105 486 minecraft:polished_blackstone_bricks
fill 424 105 487 424 108 487 minecraft:blackstone
setblock 424 105 491 minecraft:polished_blackstone_bricks
fill 424 105 492 424 108 492 minecraft:blackstone
fill 425 105 463 426 105 463 minecraft:basalt
setblock 425 105 464 minecraft:blackstone
setblock 425 105 465 minecraft:polished_blackstone_bricks
fill 425 105 466 428 105 466 minecraft:blackstone
setblock 425 105 469 minecraft:blackstone
setblock 425 105 470 minecraft:polished_blackstone_bricks
fill 425 105 471 425 108 471 minecraft:blackstone
setblock 425 105 475 minecraft:polished_blackstone_bricks
fill 425 105 476 425 105 479 minecraft:blackstone
setblock 425 105 480 minecraft:polished_blackstone_bricks
fill 425 105 481 425 108 481 minecraft:blackstone
setblock 425 105 485 minecraft:polished_blackstone_bricks
fill 425 105 486 425 108 486 minecraft:blackstone
setblock 425 105 489 minecraft:blackstone
setblock 425 105 490 minecraft:polished_blackstone_bricks
fill 425 105 491 425 108 491 minecraft:blackstone
setblock 425 105 494 minecraft:blackstone
setblock 426 105 464 minecraft:polished_blackstone_bricks
fill 426 105 465 429 105 465 minecraft:blackstone
setblock 426 105 469 minecraft:polished_blackstone_bricks
fill 426 105 470 427 107 470 minecraft:blackstone
fill 426 105 472 426 105 473 minecraft:blackstone
setblock 426 105 484 minecraft:polished_blackstone_bricks
fill 426 105 485 426 108 485 minecraft:blackstone
setblock 426 105 489 minecraft:polished_blackstone_bricks
fill 426 105 490 426 108 490 minecraft:blackstone
fill 426 105 492 426 106 492 minecraft:blackstone
setblock 426 105 504 minecraft:polished_blackstone_bricks
fill 427 105 464 430 105 464 minecraft:blackstone
setblock 427 105 467 minecraft:blackstone
setblock 427 105 468 minecraft:polished_blackstone_bricks
fill 427 105 469 427 108 469 minecraft:blackstone
setblock 427 105 488 minecraft:polished_blackstone_bricks
fill 427 105 489 427 106 489 minecraft:blackstone
fill 427 105 504 430 105 504 minecraft:blackstone
setblock 428 105 463 minecraft:basalt
setblock 428 105 467 minecraft:polished_blackstone_bricks
setblock 429 105 466 minecraft:polished_blackstone_bricks
fill 429 105 467 429 108 467 minecraft:blackstone
setblock 430 105 465 minecraft:polished_blackstone_bricks
fill 430 105 466 430 108 466 minecraft:blackstone
setblock 431 105 464 minecraft:polished_blackstone_bricks
fill 431 105 465 434 105 465 minecraft:blackstone
fill 431 105 477 432 106 478 minecraft:cyan_stained_glass
setblock 431 105 504 minecraft:polished_blackstone_bricks
fill 432 105 464 435 105 464 minecraft:blackstone
setblock 432 105 467 minecraft:blackstone
fill 432 105 504 435 105 504 minecraft:blackstone
setblock 433 105 467 minecraft:polished_blackstone_bricks
setblock 434 105 466 minecraft:polished_blackstone_bricks
fill 434 105 467 434 106 467 minecraft:blackstone
setblock 435 105 465 minecraft:polished_blackstone_bricks
fill 435 105 466 435 107 466 minecraft:blackstone
setblock 436 105 464 minecraft:polished_blackstone_bricks
fill 436 105 465 439 105 465 minecraft:blackstone
setblock 436 105 504 minecraft:polished_blackstone_bricks
setblock 437 105 463 minecraft:basalt
fill 437 105 464 440 105 464 minecraft:blackstone
setblock 437 105 504 minecraft:blackstone
setblock 438 105 466 minecraft:blackstone
setblock 439 105 463 minecraft:basalt
setblock 439 105 466 minecraft:polished_blackstone_bricks
setblock 440 105 465 minecraft:polished_blackstone_bricks
fill 440 105 466 443 105 466 minecraft:blackstone
setblock 440 105 504 minecraft:blackstone
setblock 441 105 464 minecraft:polished_blackstone_bricks
fill 441 105 465 444 105 465 minecraft:blackstone
setblock 441 105 504 minecraft:polished_blackstone_bricks
setblock 441 105 505 minecraft:basalt
fill 442 105 464 445 105 464 minecraft:blackstone
fill 442 105 504 445 105 504 minecraft:blackstone
setblock 444 105 463 minecraft:basalt
setblock 444 105 466 minecraft:polished_blackstone_bricks
setblock 445 105 465 minecraft:polished_blackstone_bricks
fill 445 105 466 447 105 467 minecraft:blackstone
fill 445 105 503 446 105 503 minecraft:blackstone
setblock 446 105 464 minecraft:polished_blackstone_bricks
fill 446 105 465 449 105 465 minecraft:blackstone
setblock 446 105 504 minecraft:polished_blackstone_bricks
setblock 446 105 505 minecraft:basalt
fill 447 105 464 450 105 464 minecraft:blackstone
setblock 447 105 503 minecraft:polished_blackstone_bricks
fill 447 105 504 450 105 504 minecraft:blackstone
setblock 448 105 466 minecraft:blackstone
setblock 448 105 467 minecraft:polished_blackstone_bricks
setblock 448 105 502 minecraft:polished_blackstone_bricks
fill 448 105 503 451 105 503 minecraft:blackstone
setblock 449 105 466 minecraft:polished_blackstone_bricks
fill 449 105 467 449 107 467 minecraft:blackstone
fill 449 105 502 449 107 502 minecraft:blackstone
setblock 450 105 465 minecraft:polished_blackstone_bricks
fill 450 105 466 450 108 466 minecraft:blackstone
setblock 451 105 464 minecraft:polished_blackstone_bricks
fill 451 105 465 451 108 465 minecraft:blackstone
setblock 451 105 467 minecraft:blackstone
setblock 451 105 504 minecraft:polished_blackstone_bricks
fill 452 105 464 455 105 464 minecraft:blackstone
setblock 452 105 503 minecraft:polished_blackstone_bricks
fill 452 105 504 455 105 504 minecraft:blackstone
setblock 453 105 463 minecraft:basalt
setblock 453 105 502 minecraft:polished_blackstone_bricks
fill 453 105 503 453 107 503 minecraft:blackstone
setblock 454 105 466 minecraft:polished_blackstone_bricks
setblock 455 105 465 minecraft:polished_blackstone_bricks
setblock 456 105 464 minecraft:polished_blackstone_bricks
setblock 456 105 465 minecraft:blackstone
setblock 456 105 504 minecraft:polished_blackstone_bricks
fill 457 105 464 457 106 464 minecraft:blackstone
fill 457 105 504 457 106 504 minecraft:blackstone
setblock 461 105 463 minecraft:basalt
setblock 462 105 487 minecraft:blackstone
setblock 462 105 488 minecraft:polished_blackstone_bricks
fill 462 105 489 462 108 489 minecraft:blackstone
fill 462 105 491 462 106 491 minecraft:blackstone
fill 463 105 484 463 105 486 minecraft:blackstone
setblock 463 105 487 minecraft:polished_blackstone_bricks
fill 463 105 488 463 108 488 minecraft:blackstone
setblock 463 105 492 minecraft:polished_blackstone_bricks
fill 463 105 493 463 108 493 minecraft:blackstone
fill 463 105 495 463 106 495 minecraft:blackstone
setblock 464 105 466 minecraft:polished_blackstone_bricks
fill 464 105 467 464 108 467 minecraft:blackstone
setblock 464 105 471 minecraft:polished_blackstone_bricks
fill 464 105 472 464 108 472 minecraft:blackstone
setblock 464 105 480 minecraft:blackstone
setblock 464 105 481 minecraft:polished_blackstone_bricks
fill 464 105 482 464 108 482 minecraft:blackstone
setblock 464 105 486 minecraft:polished_blackstone_bricks
fill 464 105 487 464 108 487 minecraft:blackstone
setblock 464 105 491 minecraft:polished_blackstone_bricks
fill 464 105 492 464 108 492 minecraft:blackstone
setblock 464 105 496 minecraft:polished_blackstone_bricks
fill 464 105 497 464 108 497 minecraft:blackstone
fill 464 105 499 464 106 499 minecraft:blackstone
setblock 465 105 465 minecraft:basalt
setblock 465 105 473 minecraft:basalt
setblock 465 105 477 minecraft:basalt
fill 465 105 500 465 106 500 minecraft:basalt
fill 423 106 463 423 106 470 minecraft:blackstone
setblock 423 106 471 minecraft:basalt
fill 423 106 472 423 206 472 minecraft:blackstone
setblock 423 106 473 minecraft:basalt
fill 423 106 474 423 107 477 minecraft:blackstone
fill 423 106 478 423 107 478 minecraft:basalt
fill 423 106 479 423 107 483 minecraft:blackstone
setblock 423 106 484 minecraft:basalt
fill 423 106 485 423 203 490 minecraft:blackstone
setblock 423 106 491 minecraft:basalt
fill 423 106 492 423 203 493 minecraft:blackstone
setblock 423 106 494 minecraft:basalt
fill 423 106 495 423 206 496 minecraft:blackstone
setblock 423 106 497 minecraft:basalt
fill 423 106 498 423 202 505 minecraft:blackstone
fill 424 106 463 424 106 464 minecraft:blackstone
setblock 424 106 465 minecraft:polished_blackstone_bricks
fill 424 106 466 427 106 466 minecraft:blackstone
setblock 424 106 470 minecraft:polished_blackstone_bricks
fill 424 106 471 424 109 471 minecraft:blackstone
setblock 424 106 475 minecraft:polished_blackstone_bricks
fill 424 106 476 424 106 479 minecraft:blackstone
setblock 424 106 480 minecraft:polished_blackstone_bricks
fill 424 106 481 424 106 484 minecraft:blackstone
setblock 424 106 485 minecraft:polished_blackstone_bricks
fill 424 106 486 424 109 486 minecraft:blackstone
setblock 424 106 490 minecraft:polished_blackstone_bricks
fill 424 106 491 424 109 491 minecraft:blackstone
setblock 424 106 495 minecraft:polished_blackstone_bricks
fill 424 106 496 424 109 496 minecraft:blackstone
fill 424 106 505 424 206 505 minecraft:blackstone
fill 425 106 463 426 106 463 minecraft:blackstone
setblock 425 106 464 minecraft:polished_blackstone_bricks
fill 425 106 465 428 106 465 minecraft:blackstone
setblock 425 106 469 minecraft:polished_blackstone_bricks
fill 425 106 470 425 109 470 minecraft:blackstone
setblock 425 106 474 minecraft:polished_blackstone_bricks
fill 425 106 475 425 106 478 minecraft:blackstone
setblock 425 106 479 minecraft:polished_blackstone_bricks
fill 425 106 480 425 109 480 minecraft:blackstone
setblock 425 106 484 minecraft:polished_blackstone_bricks
fill 425 106 485 425 109 485 minecraft:blackstone
setblock 425 106 489 minecraft:polished_blackstone_bricks
fill 425 106 490 425 109 490 minecraft:blackstone
setblock 425 106 494 minecraft:polished_blackstone_bricks
fill 426 106 464 429 106 464 minecraft:blackstone
setblock 426 106 468 minecraft:polished_blackstone_bricks
fill 426 106 469 426 109 469 minecraft:blackstone
setblock 426 106 472 minecraft:blackstone
setblock 426 106 473 minecraft:polished_blackstone_bricks
fill 426 106 474 426 108 475 minecraft:blackstone
setblock 426 106 483 minecraft:polished_blackstone_bricks
fill 426 106 484 426 107 484 minecraft:blackstone
setblock 426 106 487 minecraft:blackstone
setblock 426 106 488 minecraft:polished_blackstone_bricks
fill 426 106 489 426 109 489 minecraft:blackstone
fill 426 106 504 429 106 505 minecraft:blackstone
setblock 427 106 467 minecraft:polished_blackstone_bricks
fill 427 106 468 427 109 468 minecraft:blackstone
setblock 427 106 471 minecraft:blackstone
setblock 427 106 472 minecraft:polished_blackstone_bricks
setblock 427 106 487 minecraft:polished_blackstone_bricks
setblock 427 106 488 minecraft:blackstone
setblock 427 106 490 minecraft:blackstone
fill 428 106 463 428 206 463 minecraft:blackstone
setblock 428 106 466 minecraft:polished_blackstone_bricks
fill 428 106 467 428 108 467 minecraft:blackstone
fill 429 106 463 429 107 463 minecraft:basalt
setblock 429 106 465 minecraft:polished_blackstone_bricks
fill 429 106 466 429 109 466 minecraft:blackstone
fill 430 106 463 431 107 463 minecraft:blackstone
setblock 430 106 464 minecraft:polished_blackstone_bricks
fill 430 106 465 433 106 465 minecraft:blackstone
setblock 430 106 504 minecraft:polished_blackstone_bricks
fill 430 106 505 435 106 505 minecraft:blackstone
fill 431 106 464 434 106 464 minecraft:blackstone
fill 431 106 504 434 106 504 minecraft:blackstone
setblock 432 106 463 minecraft:basalt
setblock 432 106 467 minecraft:polished_blackstone_bricks
fill 433 106 463 437 106 463 minecraft:blackstone
setblock 433 106 466 minecraft:polished_blackstone_bricks
fill 433 106 467 433 107 467 minecraft:blackstone
setblock 434 106 465 minecraft:polished_blackstone_bricks
fill 434 106 466 434 108 466 minecraft:blackstone
setblock 435 106 464 minecraft:polished_blackstone_bricks
fill 435 106 465 438 106 465 minecraft:blackstone
setblock 435 106 504 minecraft:polished_blackstone_bricks
fill 436 106 464 439 106 464 minecraft:blackstone
setblock 436 106 505 minecraft:basalt
fill 437 106 505 444 106 505 minecraft:blackstone
setblock 438 106 466 minecraft:polished_blackstone_bricks
fill 439 106 463 454 107 463 minecraft:blackstone
setblock 439 106 465 minecraft:polished_blackstone_bricks
fill 439 106 466 442 106 466 minecraft:blackstone
setblock 440 106 464 minecraft:polished_blackstone_bricks
fill 440 106 465 443 106 465 minecraft:blackstone
fill 441 106 464 444 106 464 minecraft:blackstone
fill 441 106 504 444 106 504 minecraft:blackstone
setblock 443 106 466 minecraft:polished_blackstone_bricks
setblock 444 106 465 minecraft:polished_blackstone_bricks
fill 444 106 466 447 106 466 minecraft:blackstone
setblock 445 106 464 minecraft:polished_blackstone_bricks
fill 445 106 465 448 106 465 minecraft:blackstone
fill 445 106 467 446 106 467 minecraft:blackstone
setblock 445 106 503 minecraft:blackstone
setblock 445 106 504 minecraft:polished_blackstone_bricks
setblock 445 106 505 minecraft:basalt
fill 446 106 464 449 106 464 minecraft:blackstone
setblock 446 106 503 minecraft:polished_blackstone_bricks
fill 446 106 504 449 106 505 minecraft:blackstone
setblock 447 106 467 minecraft:polished_blackstone_bricks
fill 447 106 503 450 106 503 minecraft:blackstone
setblock 448 106 466 minecraft:polished_blackstone_bricks
fill 448 106 467 448 107 467 minecraft:blackstone
setblock 448 106 502 minecraft:blackstone
setblock 449 106 465 minecraft:polished_blackstone_bricks
fill 449 106 466 449 108 466 minecraft:blackstone
setblock 450 106 464 minecraft:polished_blackstone_bricks
fill 450 106 465 450 109 465 minecraft:blackstone
setblock 450 106 504 minecraft:polished_blackstone_bricks
fill 450 106 505 450 206 505 minecraft:blackstone
fill 451 106 464 454 106 464 minecraft:blackstone
setblock 451 106 503 minecraft:polished_blackstone_bricks
fill 451 106 504 454 106 504 minecraft:blackstone
fill 451 106 505 451 107 505 minecraft:basalt
fill 452 106 503 452 108 503 minecraft:blackstone
fill 452 106 505 456 106 505 minecraft:blackstone
setblock 453 106 466 minecraft:polished_blackstone_bricks
setblock 454 106 465 minecraft:polished_blackstone_bricks
fill 455 106 463 456 106 463 minecraft:basalt
setblock 455 106 464 minecraft:polished_blackstone_bricks
setblock 455 106 465 minecraft:blackstone
setblock 455 106 504 minecraft:polished_blackstone_bricks
fill 456 106 464 456 107 464 minecraft:blackstone
fill 456 106 504 456 107 504 minecraft:blackstone
fill 457 106 463 457 202 463 minecraft:blackstone
setblock 457 106 505 minecraft:basalt
setblock 458 106 463 minecraft:basalt
fill 458 106 505 461 107 505 minecraft:blackstone
setblock 459 106 463 minecraft:blackstone
setblock 460 106 463 minecraft:basalt
fill 461 106 463 461 206 463 minecraft:blackstone
setblock 462 106 487 minecraft:polished_blackstone_bricks
fill 462 106 488 462 108 488 minecraft:blackstone
setblock 462 106 492 minecraft:polished_blackstone_bricks
fill 463 106 463 463 202 463 minecraft:blackstone
fill 463 106 484 463 106 485 minecraft:blackstone
setblock 463 106 486 minecraft:polished_blackstone_bricks
fill 463 106 487 463 109 487 minecraft:blackstone
setblock 463 106 491 minecraft:polished_blackstone_bricks
fill 463 106 492 463 109 492 minecraft:blackstone
fill 463 106 505 465 106 505 minecraft:blackstone
setblock 464 106 463 minecraft:basalt
setblock 464 106 465 minecraft:polished_blackstone_bricks
fill 464 106 466 465 109 466 minecraft:blackstone
fill 464 106 468 464 106 469 minecraft:blackstone
setblock 464 106 470 minecraft:polished_blackstone_bricks
fill 464 106 471 465 109 471 minecraft:blackstone
fill 464 106 473 465 106 474 minecraft:blackstone
setblock 464 106 475 minecraft:polished_blackstone_bricks
fill 464 106 479 465 106 479 minecraft:blackstone
setblock 464 106 480 minecraft:polished_blackstone_bricks
fill 464 106 481 465 109 481 minecraft:blackstone
setblock 464 106 485 minecraft:polished_blackstone_bricks
fill 464 106 486 464 109 486 minecraft:blackstone
setblock 464 106 490 minecraft:polished_blackstone_bricks
fill 464 106 491 465 107 491 minecraft:blackstone
setblock 464 106 495 minecraft:polished_blackstone_bricks
fill 464 106 496 465 109 496 minecraft:blackstone
fill 465 106 463 465 203 465 minecraft:blackstone
fill 465 106 467 465 206 467 minecraft:blackstone
setblock 465 106 468 minecraft:basalt
fill 465 106 469 465 107 470 minecraft:blackstone
fill 465 106 472 465 204 472 minecraft:blackstone
fill 465 106 475 465 106 478 minecraft:blackstone
fill 465 106 480 465 206 480 minecraft:blackstone
fill 465 106 482 465 206 485 minecraft:blackstone
fill 465 106 486 465 107 486 minecraft:basalt
fill 465 106 487 465 107 490 minecraft:blackstone
fill 465 106 492 465 106 495 minecraft:blackstone
fill 465 106 497 465 202 499 minecraft:blackstone
fill 465 106 501 465 106 504 minecraft:blackstone
fill 423 107 463 423 203 469 minecraft:blackstone
fill 423 107 470 423 108 470 minecraft:basalt
fill 423 107 471 423 202 471 minecraft:blackstone
fill 423 107 473 424 107 473 minecraft:blackstone
fill 423 107 484 423 203 484 minecraft:blackstone
fill 423 107 491 423 206 491 minecraft:blackstone
fill 423 107 494 423 206 494 minecraft:blackstone
fill 423 107 497 423 203 497 minecraft:blackstone
fill 424 107 463 425 204 463 minecraft:blackstone
setblock 424 107 464 minecraft:polished_blackstone_bricks
fill 424 107 465 426 107 466 minecraft:blackstone
setblock 424 107 468 minecraft:blackstone
setblock 424 107 469 minecraft:polished_blackstone_bricks
fill 424 107 470 424 110 470 minecraft:blackstone
setblock 424 107 474 minecraft:polished_blackstone_bricks
fill 424 107 475 424 107 478 minecraft:blackstone
setblock 424 107 479 minecraft:polished_blackstone_bricks
fill 424 107 480 424 107 483 minecraft:blackstone
setblock 424 107 484 minecraft:polished_blackstone_bricks
fill 424 107 485 424 110 485 minecraft:blackstone
setblock 424 107 489 minecraft:polished_blackstone_bricks
fill 424 107 490 424 110 490 minecraft:blackstone
setblock 424 107 493 minecraft:blackstone
setblock 424 107 494 minecraft:polished_blackstone_bricks
fill 424 107 495 425 109 495 minecraft:blackstone
fill 425 107 464 428 107 464 minecraft:blackstone
setblock 425 107 467 minecraft:blackstone
setblock 425 107 468 minecraft:polished_blackstone_bricks
fill 425 107 469 425 110 469 minecraft:blackstone
setblock 425 107 473 minecraft:polished_blackstone_bricks
fill 425 107 474 425 107 477 minecraft:blackstone
setblock 425 107 478 minecraft:polished_blackstone_bricks
fill 425 107 479 425 110 479 minecraft:blackstone
setblock 425 107 483 minecraft:polished_blackstone_bricks
fill 425 107 484 425 110 484 minecraft:blackstone
setblock 425 107 488 minecraft:polished_blackstone_bricks
fill 425 107 489 425 110 489 minecraft:blackstone
setblock 425 107 493 minecraft:polished_blackstone_bricks
fill 425 107 494 425 110 494 minecraft:blackstone
fill 425 107 505 431 202 505 minecraft:blackstone
setblock 426 107 463 minecraft:basalt
setblock 426 107 467 minecraft:polished_blackstone_bricks
fill 426 107 468 426 110 468 minecraft:blackstone
setblock 426 107 472 minecraft:polished_blackstone_bricks
fill 426 107 473 427 109 473 minecraft:blackstone
setblock 426 107 476 minecraft:blackstone
setblock 426 107 483 minecraft:blackstone
setblock 426 107 487 minecraft:polished_blackstone_bricks
fill 426 107 488 426 109 488 minecraft:blackstone
setblock 426 107 492 minecraft:polished_blackstone_bricks
setblock 426 107 493 minecraft:blackstone
fill 427 107 463 427 206 463 minecraft:blackstone
setblock 427 107 465 minecraft:blackstone
setblock 427 107 466 minecraft:polished_blackstone_bricks
fill 427 107 467 427 108 467 minecraft:blackstone
setblock 427 107 471 minecraft:polished_blackstone_bricks
fill 427 107 472 427 110 472 minecraft:blackstone
fill 427 107 504 428 107 504 minecraft:blackstone
setblock 428 107 465 minecraft:polished_blackstone_bricks
fill 428 107 466 428 110 466 minecraft:blackstone
setblock 429 107 464 minecraft:polished_blackstone_bricks
fill 429 107 465 432 107 465 minecraft:blackstone
setblock 429 107 504 minecraft:polished_blackstone_bricks
fill 430 107 464 433 107 464 minecraft:blackstone
fill 430 107 504 433 107 504 minecraft:blackstone
setblock 431 107 467 minecraft:polished_blackstone_bricks
fill 432 107 463 434 202 463 minecraft:blackstone
setblock 432 107 466 minecraft:polished_blackstone_bricks
setblock 432 107 467 minecraft:blackstone
setblock 432 107 505 minecraft:basalt
setblock 433 107 465 minecraft:polished_blackstone_bricks
fill 433 107 466 433 108 466 minecraft:blackstone
fill 433 107 505 434 206 505 minecraft:blackstone
setblock 434 107 464 minecraft:polished_blackstone_bricks
fill 434 107 465 437 107 465 minecraft:blackstone
setblock 435 107 463 minecraft:basalt
fill 435 107 464 438 107 464 minecraft:blackstone
setblock 435 107 505 minecraft:basalt
fill 436 107 463 437 204 463 minecraft:blackstone
fill 436 107 505 436 206 505 minecraft:blackstone
setblock 437 107 505 minecraft:basalt
setblock 438 107 465 minecraft:polished_blackstone_bricks
fill 438 107 505 448 107 505 minecraft:blackstone
setblock 439 107 464 minecraft:polished_blackstone_bricks
fill 439 107 465 442 107 465 minecraft:blackstone
fill 440 107 464 443 107 464 minecraft:blackstone
fill 441 107 504 443 107 504 minecraft:blackstone
setblock 442 107 466 minecraft:polished_blackstone_bricks
setblock 443 107 465 minecraft:polished_blackstone_bricks
fill 443 107 466 446 107 466 minecraft:blackstone
setblock 444 107 464 minecraft:polished_blackstone_bricks
fill 444 107 465 447 107 465 minecraft:blackstone
setblock 444 107 504 minecraft:polished_blackstone_bricks
fill 445 107 464 448 107 464 minecraft:blackstone
setblock 445 107 503 minecraft:polished_blackstone_bricks
fill 445 107 504 448 107 504 minecraft:blackstone
setblock 446 107 467 minecraft:polished_blackstone_bricks
fill 446 107 503 449 107 503 minecraft:blackstone
setblock 447 107 466 minecraft:polished_blackstone_bricks
setblock 447 107 467 minecraft:blackstone
setblock 448 107 465 minecraft:polished_blackstone_bricks
fill 448 107 466 448 109 466 minecraft:blackstone
setblock 449 107 464 minecraft:polished_blackstone_bricks
fill 449 107 465 449 110 465 minecraft:blackstone
setblock 449 107 504 minecraft:polished_blackstone_bricks
setblock 449 107 505 minecraft:basalt
fill 450 107 464 453 107 464 minecraft:blackstone
setblock 450 107 503 minecraft:polished_blackstone_bricks
fill 450 107 504 453 107 504 minecraft:blackstone
fill 451 107 503 451 109 503 minecraft:blackstone
setblock 452 107 466 minecraft:polished_blackstone_bricks
fill 452 107 505 454 206 505 minecraft:blackstone
setblock 453 107 465 minecraft:polished_blackstone_bricks
setblock 454 107 464 minecraft:polished_blackstone_bricks
setblock 454 107 465 minecraft:blackstone
setblock 454 107 504 minecraft:polished_blackstone_bricks
fill 455 107 463 455 107 464 minecraft:blackstone
setblock 455 107 504 minecraft:blackstone
setblock 455 107 505 minecraft:basalt
fill 456 107 463 456 202 463 minecraft:blackstone
fill 456 107 505 457 206 505 minecraft:blackstone
fill 458 107 463 458 206 463 minecraft:blackstone
setblock 459 107 463 minecraft:basalt
fill 460 107 463 460 206 463 minecraft:blackstone
fill 462 107 463 462 206 463 minecraft:blackstone
setblock 462 107 491 minecraft:polished_blackstone_bricks
fill 462 107 492 462 109 493 minecraft:blackstone
fill 462 107 505 463 206 505 minecraft:blackstone
setblock 463 107 484 minecraft:blackstone
setblock 463 107 485 minecraft:polished_blackstone_bricks
fill 463 107 486 463 110 486 minecraft:blackstone
setblock 463 107 490 minecraft:polished_blackstone_bricks
fill 463 107 491 463 110 491 minecraft:blackstone
setblock 463 107 495 minecraft:polished_blackstone_bricks
fill 463 107 496 463 110 496 minecraft:blackstone
fill 464 107 463 464 207 463 minecraft:blackstone
setblock 464 107 464 minecraft:polished_blackstone_bricks
fill 464 107 465 464 108 465 minecraft:blackstone
fill 464 107 468 465 107 468 minecraft:blackstone
setblock 464 107 469 minecraft:polished_blackstone_bricks
fill 464 107 470 464 110 470 minecraft:blackstone
fill 464 107 473 465 107 473 minecraft:blackstone
setblock 464 107 474 minecraft:polished_blackstone_bricks
fill 464 107 475 464 107 478 minecraft:blackstone
setblock 464 107 479 minecraft:polished_blackstone_bricks
fill 464 107 480 464 110 480 minecraft:blackstone
setblock 464 107 484 minecraft:polished_blackstone_bricks
fill 464 107 485 464 110 485 minecraft:blackstone
setblock 464 107 489 minecraft:polished_blackstone_bricks
fill 464 107 490 464 110 490 minecraft:blackstone
setblock 464 107 494 minecraft:polished_blackstone_bricks
fill 464 107 495 465 110 495 minecraft:blackstone
setblock 464 107 499 minecraft:polished_blackstone_bricks
setblock 464 107 505 minecraft:basalt
fill 465 107 474 465 204 474 minecraft:blackstone
setblock 465 107 475 minecraft:basalt
fill 465 107 476 465 202 479 minecraft:blackstone
fill 465 107 492 465 107 493 minecraft:blackstone
setblock 465 107 494 minecraft:basalt
fill 465 107 500 465 203 501 minecraft:blackstone
fill 465 107 502 465 107 503 minecraft:basalt
fill 465 107 504 465 206 505 minecraft:blackstone
fill 423 108 473 423 204 474 minecraft:blackstone
setblock 423 108 475 minecraft:basalt
fill 423 108 476 425 108 476 minecraft:blackstone
setblock 423 108 477 minecraft:basalt
fill 423 108 478 423 202 481 minecraft:blackstone
setblock 423 108 482 minecraft:basalt
fill 423 108 483 423 206 483 minecraft:blackstone
fill 424 108 464 425 108 466 minecraft:blackstone
setblock 424 108 468 minecraft:polished_blackstone_bricks
fill 424 108 469 424 111 469 minecraft:blackstone
setblock 424 108 473 minecraft:polished_blackstone_bricks
fill 424 108 474 425 109 475 minecraft:blackstone
setblock 424 108 477 minecraft:blackstone
setblock 424 108 478 minecraft:polished_blackstone_bricks
fill 424 108 479 424 108 482 minecraft:blackstone
setblock 424 108 483 minecraft:polished_blackstone_bricks
fill 424 108 484 424 111 484 minecraft:blackstone
setblock 424 108 488 minecraft:polished_blackstone_bricks
fill 424 108 489 424 111 489 minecraft:blackstone
setblock 424 108 493 minecraft:polished_blackstone_bricks
fill 424 108 494 424 111 494 minecraft:blackstone
setblock 424 108 497 minecraft:blackstone
setblock 425 108 467 minecraft:polished_blackstone_bricks
fill 425 108 468 425 111 468 minecraft:blackstone
setblock 425 108 472 minecraft:polished_blackstone_bricks
fill 425 108 473 425 111 473 minecraft:blackstone
setblock 425 108 477 minecraft:polished_blackstone_bricks
fill 425 108 478 425 111 478 minecraft:blackstone
setblock 425 108 482 minecraft:polished_blackstone_bricks
fill 425 108 483 425 109 483 minecraft:blackstone
setblock 425 108 487 minecraft:polished_blackstone_bricks
fill 425 108 488 425 111 488 minecraft:blackstone
setblock 425 108 492 minecraft:polished_blackstone_bricks
fill 425 108 493 425 111 493 minecraft:blackstone
fill 426 108 463 426 108 465 minecraft:blackstone
setblock 426 108 466 minecraft:polished_blackstone_bricks
fill 426 108 467 426 111 467 minecraft:blackstone
setblock 426 108 470 minecraft:blackstone
setblock 426 108 471 minecraft:polished_blackstone_bricks
fill 426 108 472 426 111 472 minecraft:blackstone
setblock 426 108 476 minecraft:polished_blackstone_bricks
setblock 426 108 486 minecraft:polished_blackstone_bricks
setblock 426 108 487 minecraft:blackstone
setblock 426 108 491 minecraft:polished_blackstone_bricks
fill 426 108 492 426 109 492 minecraft:blackstone
setblock 427 108 464 minecraft:blackstone
setblock 427 108 465 minecraft:polished_blackstone_bricks
fill 427 108 466 427 110 466 minecraft:blackstone
setblock 427 108 470 minecraft:polished_blackstone_bricks
fill 427 108 471 427 111 471 minecraft:blackstone
setblock 428 108 464 minecraft:polished_blackstone_bricks
fill 428 108 465 431 108 465 minecraft:blackstone
setblock 428 108 504 minecraft:polished_blackstone_bricks
fill 429 108 463 430 110 464 minecraft:blackstone
fill 429 108 504 430 108 504 minecraft:blackstone
setblock 430 108 467 minecraft:polished_blackstone_bricks
setblock 431 108 463 minecraft:basalt
fill 431 108 464 432 108 464 minecraft:blackstone
setblock 431 108 466 minecraft:polished_blackstone_bricks
setblock 431 108 467 minecraft:blackstone
setblock 432 108 465 minecraft:polished_blackstone_bricks
fill 432 108 466 432 109 466 minecraft:blackstone
fill 432 108 505 432 207 505 minecraft:blackstone
setblock 433 108 464 minecraft:polished_blackstone_bricks
fill 433 108 465 436 108 465 minecraft:blackstone
fill 434 108 464 437 108 464 minecraft:blackstone
fill 435 108 463 435 206 463 minecraft:blackstone
fill 435 108 505 435 206 505 minecraft:blackstone
setblock 437 108 465 minecraft:polished_blackstone_bricks
fill 437 108 505 442 206 505 minecraft:blackstone
fill 438 108 463 449 202 463 minecraft:blackstone
setblock 438 108 464 minecraft:polished_blackstone_bricks
fill 438 108 465 441 108 465 minecraft:blackstone
fill 439 108 464 442 108 464 minecraft:blackstone
setblock 442 108 465 minecraft:polished_blackstone_bricks
setblock 442 108 504 minecraft:blackstone
setblock 443 108 464 minecraft:polished_blackstone_bricks
fill 443 108 465 445 108 466 minecraft:blackstone
setblock 443 108 504 minecraft:polished_blackstone_bricks
setblock 443 108 505 minecraft:basalt
fill 444 108 464 447 108 464 minecraft:blackstone
fill 444 108 504 444 111 505 minecraft:blackstone
fill 445 108 503 447 108 504 minecraft:blackstone
setblock 445 108 505 minecraft:basalt
setblock 446 108 465 minecraft:blackstone
setblock 446 108 466 minecraft:polished_blackstone_bricks
fill 446 108 505 449 206 505 minecraft:blackstone
setblock 447 108 465 minecraft:polished_blackstone_bricks
fill 447 108 466 447 109 466 minecraft:blackstone
setblock 448 108 464 minecraft:polished_blackstone_bricks
fill 448 108 465 448 110 465 minecraft:blackstone
setblock 448 108 503 minecraft:blackstone
setblock 448 108 504 minecraft:polished_blackstone_bricks
fill 449 108 464 452 108 464 minecraft:blackstone
setblock 449 108 503 minecraft:polished_blackstone_bricks
fill 449 108 504 452 108 504 minecraft:blackstone
fill 450 108 463 451 108 463 minecraft:basalt
fill 450 108 503 450 109 503 minecraft:blackstone
fill 451 108 505 451 206 505 minecraft:blackstone
fill 452 108 463 455 206 463 minecraft:blackstone
setblock 452 108 465 minecraft:polished_blackstone_bricks
setblock 453 108 464 minecraft:polished_blackstone_bricks
setblock 453 108 504 minecraft:polished_blackstone_bricks
setblock 454 108 464 minecraft:blackstone
setblock 454 108 504 minecraft:blackstone
fill 455 108 505 455 204 505 minecraft:blackstone
fill 458 108 505 459 202 505 minecraft:blackstone
fill 459 108 463 459 207 463 minecraft:blackstone
setblock 460 108 505 minecraft:basalt
fill 461 108 505 461 206 505 minecraft:blackstone
setblock 462 108 490 minecraft:polished_blackstone_bricks
fill 462 108 491 462 111 491 minecraft:blackstone
setblock 463 108 484 minecraft:polished_blackstone_bricks
fill 463 108 485 463 109 485 minecraft:blackstone
setblock 463 108 489 minecraft:polished_blackstone_bricks
fill 463 108 490 463 111 490 minecraft:blackstone
setblock 463 108 494 minecraft:polished_blackstone_bricks
fill 463 108 495 463 111 495 minecraft:blackstone
setblock 464 108 468 minecraft:polished_blackstone_bricks
fill 464 108 469 464 111 469 minecraft:blackstone
setblock 464 108 473 minecraft:polished_blackstone_bricks
fill 464 108 474 464 108 477 minecraft:blackstone
setblock 464 108 478 minecraft:polished_blackstone_bricks
fill 464 108 479 464 111 479 minecraft:blackstone
setblock 464 108 483 minecraft:polished_blackstone_bricks
fill 464 108 484 464 111 484 minecraft:blackstone
setblock 464 108 488 minecraft:polished_blackstone_bricks
fill 464 108 489 465 111 489 minecraft:blackstone
fill 464 108 491 464 109 491 minecraft:blackstone
setblock 464 108 493 minecraft:polished_blackstone_bricks
fill 464 108 494 465 111 494 minecraft:blackstone
setblock 464 108 498 minecraft:polished_blackstone_bricks
fill 464 108 499 464 111 499 minecraft:blackstone
fill 464 108 505 464 206 505 minecraft:blackstone
fill 465 108 468 465 207 468 minecraft:blackstone
setblock 465 108 469 minecraft:basalt
fill 465 108 470 465 203 470 minecraft:blackstone
setblock 465 108 473 minecraft:basalt
fill 465 108 475 465 206 475 minecraft:blackstone
fill 465 108 486 465 206 486 minecraft:blackstone
setblock 465 108 487 minecraft:basalt
fill 465 108 488 465 204 488 minecraft:blackstone
fill 465 108 490 465 206 490 minecraft:blackstone
setblock 465 108 491 minecraft:basalt
fill 465 108 492 465 204 492 minecraft:blackstone
setblock 465 108 493 minecraft:basalt
fill 465 108 502 465 206 503 minecraft:blackstone
fill 423 109 470 423 206 470 minecraft:blackstone
fill 423 109 475 423 206 477 minecraft:blackstone
fill 423 109 482 423 206 482 minecraft:blackstone
fill 424 109 464 424 109 466 minecraft:blackstone
setblock 424 109 467 minecraft:polished_blackstone_bricks
fill 424 109 468 424 112 468 minecraft:blackstone
setblock 424 109 472 minecraft:polished_blackstone_bricks
fill 424 109 473 424 112 473 minecraft:blackstone
setblock 424 109 476 minecraft:blackstone
setblock 424 109 477 minecraft:polished_blackstone_bricks
fill 424 109 478 424 109 481 minecraft:blackstone
setblock 424 109 482 minecraft:polished_blackstone_bricks
fill 424 109 483 424 112 483 minecraft:blackstone
setblock 424 109 487 minecraft:polished_blackstone_bricks
fill 424 109 488 424 112 488 minecraft:blackstone
setblock 424 109 492 minecraft:polished_blackstone_bricks
fill 424 109 493 424 112 493 minecraft:blackstone
setblock 424 109 497 minecraft:polished_blackstone_bricks
fill 425 109 464 425 109 465 minecraft:blackstone
setblock 425 109 466 minecraft:polished_blackstone_bricks
fill 425 109 467 425 112 467 minecraft:blackstone
setblock 425 109 471 minecraft:polished_blackstone_bricks
fill 425 109 472 425 112 472 minecraft:blackstone
setblock 425 109 476 minecraft:polished_blackstone_bricks
fill 425 109 477 426 111 477 minecraft:blackstone
setblock 425 109 481 minecraft:polished_blackstone_bricks
setblock 425 109 482 minecraft:blackstone
setblock 425 109 486 minecraft:polished_blackstone_bricks
fill 425 109 487 425 111 487 minecraft:blackstone
setblock 425 109 491 minecraft:polished_blackstone_bricks
fill 425 109 492 425 112 492 minecraft:blackstone
fill 426 109 463 426 109 464 minecraft:blackstone
setblock 426 109 465 minecraft:polished_blackstone_bricks
setblock 426 109 466 minecraft:blackstone
setblock 426 109 470 minecraft:polished_blackstone_bricks
fill 426 109 471 426 112 471 minecraft:blackstone
setblock 426 109 474 minecraft:blackstone
setblock 426 109 475 minecraft:polished_blackstone_bricks
fill 426 109 476 426 112 476 minecraft:blackstone
setblock 426 109 490 minecraft:polished_blackstone_bricks
setblock 426 109 491 minecraft:blackstone
setblock 427 109 464 minecraft:polished_blackstone_bricks
fill 427 109 465 430 109 465 minecraft:blackstone
setblock 427 109 469 minecraft:polished_blackstone_bricks
fill 427 109 470 427 111 470 minecraft:blackstone
setblock 427 109 474 minecraft:polished_blackstone_bricks
fill 428 109 464 428 112 464 minecraft:blackstone
setblock 430 109 466 minecraft:polished_blackstone_bricks
fill 431 109 463 431 109 464 minecraft:blackstone
setblock 431 109 465 minecraft:polished_blackstone_bricks
setblock 431 109 466 minecraft:blackstone
setblock 432 109 464 minecraft:polished_blackstone_bricks
fill 432 109 465 434 109 465 minecraft:blackstone
fill 433 109 464 436 109 464 minecraft:blackstone
setblock 437 109 464 minecraft:polished_blackstone_bricks
fill 438 109 464 441 109 464 minecraft:blackstone
setblock 441 109 465 minecraft:polished_blackstone_bricks
setblock 442 109 464 minecraft:polished_blackstone_bricks
fill 442 109 465 445 109 465 minecraft:blackstone
setblock 442 109 504 minecraft:polished_blackstone_bricks
fill 443 109 464 446 109 464 minecraft:blackstone
fill 443 109 504 443 112 505 minecraft:blackstone
setblock 444 109 466 minecraft:blackstone
setblock 445 109 466 minecraft:polished_blackstone_bricks
fill 445 109 503 445 110 505 minecraft:blackstone
setblock 446 109 465 minecraft:polished_blackstone_bricks
setblock 446 109 466 minecraft:blackstone
fill 446 109 503 446 109 504 minecraft:blackstone
setblock 447 109 464 minecraft:polished_blackstone_bricks
fill 447 109 465 447 111 465 minecraft:blackstone
setblock 447 109 503 minecraft:blackstone
setblock 447 109 504 minecraft:polished_blackstone_bricks
fill 448 109 464 451 109 464 minecraft:blackstone
setblock 448 109 503 minecraft:polished_blackstone_bricks
fill 448 109 504 451 109 504 minecraft:blackstone
fill 449 109 503 449 110 503 minecraft:blackstone
fill 450 109 463 451 206 463 minecraft:blackstone
setblock 451 109 465 minecraft:polished_blackstone_bricks
setblock 452 109 464 minecraft:polished_blackstone_bricks
setblock 452 109 504 minecraft:polished_blackstone_bricks
fill 453 109 498 453 110 499 minecraft:light_blue_stained_glass
setblock 453 109 504 minecraft:blackstone
fill 460 109 505 460 206 505 minecraft:blackstone
setblock 462 109 489 minecraft:polished_blackstone_bricks
fill 462 109 490 462 110 490 minecraft:blackstone
setblock 463 109 488 minecraft:polished_blackstone_bricks
fill 463 109 489 463 112 489 minecraft:blackstone
setblock 463 109 493 minecraft:polished_blackstone_bricks
fill 463 109 494 463 112 494 minecraft:blackstone
setblock 464 109 467 minecraft:polished_blackstone_bricks
fill 464 109 468 464 112 468 minecraft:blackstone
setblock 464 109 472 minecraft:polished_blackstone_bricks
fill 464 109 473 464 109 476 minecraft:blackstone
setblock 464 109 477 minecraft:polished_blackstone_bricks
fill 464 109 478 464 112 478 minecraft:blackstone
setblock 464 109 482 minecraft:polished_blackstone_bricks
fill 464 109 483 464 112 483 minecraft:blackstone
setblock 464 109 487 minecraft:polished_blackstone_bricks
fill 464 109 488 464 112 488 minecraft:blackstone
setblock 464 109 492 minecraft:polished_blackstone_bricks
fill 464 109 493 465 112 493 minecraft:blackstone
setblock 464 109 497 minecraft:polished_blackstone_bricks
fill 464 109 498 464 112 498 minecraft:blackstone
fill 465 109 469 465 206 469 minecraft:blackstone
fill 465 109 473 465 207 473 minecraft:blackstone
fill 465 109 487 465 206 487 minecraft:blackstone
fill 465 109 491 465 206 491 minecraft:blackstone
fill 424 110 464 424 110 465 minecraft:blackstone
setblock 424 110 466 minecraft:polished_blackstone_bricks
fill 424 110 467 424 113 467 minecraft:blackstone
setblock 424 110 471 minecraft:polished_blackstone_bricks
fill 424 110 472 424 113 472 minecraft:blackstone
fill 424 110 474 424 110 475 minecraft:blackstone
setblock 424 110 476 minecraft:polished_blackstone_bricks
fill 424 110 477 424 110 480 minecraft:blackstone
setblock 424 110 481 minecraft:polished_blackstone_bricks
fill 424 110 482 424 113 482 minecraft:blackstone
setblock 424 110 486 minecraft:polished_blackstone_bricks
fill 424 110 487 424 113 487 minecraft:blackstone
setblock 424 110 491 minecraft:polished_blackstone_bricks
fill 424 110 492 424 113 492 minecraft:blackstone
setblock 424 110 495 minecraft:blackstone
setblock 424 110 496 minecraft:polished_blackstone_bricks
fill 424 110 497 424 113 497 minecraft:blackstone
setblock 425 110 464 minecraft:blackstone
setblock 425 110 465 minecraft:polished_blackstone_bricks
fill 425 110 466 425 113 466 minecraft:blackstone
setblock 425 110 470 minecraft:polished_blackstone_bricks
fill 425 110 471 425 113 471 minecraft:blackstone
setblock 425 110 474 minecraft:blackstone
setblock 425 110 475 minecraft:polished_blackstone_bricks
fill 425 110 476 425 113 476 minecraft:blackstone
setblock 425 110 480 minecraft:polished_blackstone_bricks
setblock 425 110 481 minecraft:blackstone
setblock 425 110 485 minecraft:polished_blackstone_bricks
setblock 425 110 486 minecraft:blackstone
setblock 425 110 490 minecraft:polished_blackstone_bricks
fill 425 110 491 425 113 491 minecraft:blackstone
setblock 425 110 495 minecraft:polished_blackstone_bricks
fill 426 110 463 426 207 463 minecraft:blackstone
setblock 426 110 464 minecraft:polished_blackstone_bricks
fill 426 110 465 429 110 465 minecraft:blackstone
setblock 426 110 466 minecraft:light[level=11]
setblock 426 110 469 minecraft:polished_blackstone_bricks
fill 426 110 470 426 113 470 minecraft:blackstone
setblock 426 110 473 minecraft:blackstone
setblock 426 110 474 minecraft:polished_blackstone_bricks
fill 426 110 475 426 113 475 minecraft:blackstone
setblock 426 110 482 minecraft:light[level=11]
setblock 426 110 490 minecraft:light[level=11]
setblock 426 110 498 minecraft:light[level=11]
fill 427 110 464 427 113 464 minecraft:blackstone
setblock 427 110 469 minecraft:blackstone
setblock 427 110 473 minecraft:polished_blackstone_bricks
fill 427 110 474 427 113 474 minecraft:blackstone
setblock 429 110 466 minecraft:polished_blackstone_bricks
setblock 430 110 465 minecraft:polished_blackstone_bricks
fill 431 110 463 431 206 463 minecraft:blackstone
setblock 431 110 464 minecraft:polished_blackstone_bricks
fill 431 110 465 432 110 465 minecraft:blackstone
fill 432 110 464 435 110 464 minecraft:blackstone
setblock 434 110 466 minecraft:light[level=11]
setblock 434 110 474 minecraft:light[level=11]
setblock 434 110 482 minecraft:light[level=11]
setblock 434 110 490 minecraft:light[level=11]
setblock 434 110 498 minecraft:light[level=11]
fill 439 110 464 440 110 464 minecraft:blackstone
setblock 441 110 464 minecraft:polished_blackstone_bricks
fill 442 110 464 444 110 465 minecraft:blackstone
setblock 442 110 466 minecraft:light[level=11]
setblock 442 110 474 minecraft:light[level=11]
setblock 442 110 482 minecraft:light[level=11]
setblock 442 110 490 minecraft:light[level=11]
setblock 442 110 498 minecraft:light[level=11]
fill 442 110 504 442 113 504 minecraft:blackstone
setblock 445 110 464 minecraft:blackstone
setblock 445 110 465 minecraft:polished_blackstone_bricks
setblock 446 110 464 minecraft:polished_blackstone_bricks
fill 446 110 465 446 111 465 minecraft:blackstone
setblock 446 110 503 minecraft:blackstone
setblock 446 110 504 minecraft:polished_blackstone_bricks
fill 447 110 464 450 110 464 minecraft:blackstone
setblock 447 110 503 minecraft:polished_blackstone_bricks
fill 447 110 504 450 110 504 minecraft:blackstone
fill 448 110 503 448 113 503 minecraft:blackstone
setblock 450 110 466 minecraft:light[level=11]
setblock 450 110 474 minecraft:light[level=11]
setblock 450 110 482 minecraft:light[level=11]
setblock 450 110 490 minecraft:light[level=11]
setblock 450 110 498 minecraft:light[level=11]
setblock 451 110 464 minecraft:polished_blackstone_bricks
setblock 451 110 504 minecraft:polished_blackstone_bricks
setblock 452 110 504 minecraft:blackstone
setblock 458 110 466 minecraft:light[level=11]
setblock 458 110 474 minecraft:light[level=11]
setblock 458 110 482 minecraft:light[level=11]
setblock 458 110 490 minecraft:light[level=11]
setblock 458 110 498 minecraft:light[level=11]
setblock 462 110 492 minecraft:blackstone
setblock 462 110 493 minecraft:polished_blackstone_bricks
setblock 463 110 472 minecraft:polished_blackstone_bricks
setblock 463 110 487 minecraft:polished_blackstone_bricks
fill 463 110 488 463 113 488 minecraft:blackstone
setblock 463 110 492 minecraft:polished_blackstone_bricks
fill 463 110 493 463 113 493 minecraft:blackstone
setblock 463 110 497 minecraft:polished_blackstone_bricks
setblock 464 110 466 minecraft:polished_blackstone_bricks
fill 464 110 467 464 113 467 minecraft:blackstone
setblock 464 110 471 minecraft:polished_blackstone_bricks
fill 464 110 472 464 110 475 minecraft:blackstone
setblock 464 110 476 minecraft:polished_blackstone_bricks
fill 464 110 477 464 113 477 minecraft:blackstone
setblock 464 110 481 minecraft:polished_blackstone_bricks
fill 464 110 482 464 113 482 minecraft:blackstone
setblock 464 110 486 minecraft:polished_blackstone_bricks
fill 464 110 487 464 113 487 minecraft:blackstone
setblock 464 110 491 minecraft:polished_blackstone_bricks
fill 464 110 492 464 113 492 minecraft:blackstone
setblock 464 110 496 minecraft:polished_blackstone_bricks
fill 464 110 497 464 113 497 minecraft:blackstone
fill 465 110 466 465 206 466 minecraft:blackstone
fill 465 110 471 465 206 471 minecraft:blackstone
fill 465 110 481 465 207 481 minecraft:blackstone
fill 465 110 496 465 206 496 minecraft:blackstone
setblock 424 111 464 minecraft:blackstone
setblock 424 111 465 minecraft:polished_blackstone_bricks
fill 424 111 466 424 114 466 minecraft:blackstone
setblock 424 111 470 minecraft:polished_blackstone_bricks
fill 424 111 471 424 114 471 minecraft:blackstone
setblock 424 111 474 minecraft:blackstone
setblock 424 111 475 minecraft:polished_blackstone_bricks
fill 424 111 476 424 111 479 minecraft:blackstone
setblock 424 111 480 minecraft:polished_blackstone_bricks
fill 424 111 481 424 114 481 minecraft:blackstone
setblock 424 111 485 minecraft:polished_blackstone_bricks
fill 424 111 486 424 114 486 minecraft:blackstone
setblock 424 111 490 minecraft:polished_blackstone_bricks
fill 424 111 491 424 114 491 minecraft:blackstone
setblock 424 111 495 minecraft:polished_blackstone_bricks
fill 424 111 496 424 114 496 minecraft:blackstone
fill 424 111 498 424 112 498 minecraft:blackstone
setblock 425 111 464 minecraft:polished_blackstone_bricks
setblock 425 111 469 minecraft:polished_blackstone_bricks
fill 425 111 470 425 114 470 minecraft:blackstone
setblock 425 111 474 minecraft:polished_blackstone_bricks
fill 425 111 475 425 114 475 minecraft:blackstone
setblock 425 111 479 minecraft:polished_blackstone_bricks
fill 425 111 480 425 114 480 minecraft:blackstone
setblock 425 111 489 minecraft:polished_blackstone_bricks
fill 425 111 490 425 113 490 minecraft:blackstone
setblock 425 111 494 minecraft:polished_blackstone_bricks
fill 425 111 495 425 114 495 minecraft:blackstone
fill 426 111 464 426 112 465 minecraft:blackstone
setblock 426 111 468 minecraft:polished_blackstone_bricks
fill 426 111 469 426 114 469 minecraft:blackstone
setblock 426 111 473 minecraft:polished_blackstone_bricks
fill 426 111 474 426 114 474 minecraft:blackstone
fill 427 111 465 428 111 465 minecraft:blackstone
setblock 427 111 472 minecraft:polished_blackstone_bricks
fill 427 111 473 427 114 473 minecraft:blackstone
fill 429 111 463 429 111 464 minecraft:blackstone
setblock 429 111 465 minecraft:polished_blackstone_bricks
fill 430 111 463 430 206 463 minecraft:blackstone
setblock 430 111 464 minecraft:polished_blackstone_bricks
setblock 430 111 465 minecraft:blackstone
fill 431 111 464 432 111 464 minecraft:blackstone
fill 439 111 497 440 114 501 minecraft:warped_wart_block
setblock 440 111 464 minecraft:polished_blackstone_bricks
fill 441 111 464 444 111 464 minecraft:blackstone
fill 441 111 497 443 114 498 minecraft:warped_wart_block
setblock 441 111 499 minecraft:polished_blackstone_bricks
fill 441 111 500 443 114 501 minecraft:warped_wart_block
fill 442 111 499 443 114 499 minecraft:warped_wart_block
setblock 444 111 465 minecraft:polished_blackstone_bricks
setblock 445 111 464 minecraft:polished_blackstone_bricks
setblock 445 111 465 minecraft:blackstone
setblock 445 111 503 minecraft:blackstone
setblock 445 111 504 minecraft:polished_blackstone_bricks
fill 445 111 505 445 204 505 minecraft:blackstone
fill 446 111 464 449 111 464 minecraft:blackstone
setblock 446 111 503 minecraft:polished_blackstone_bricks
fill 446 111 504 449 111 504 minecraft:blackstone
fill 447 111 503 447 114 503 minecraft:blackstone
setblock 450 111 464 minecraft:polished_blackstone_bricks
setblock 450 111 504 minecraft:polished_blackstone_bricks
setblock 451 111 504 minecraft:blackstone
setblock 462 111 492 minecraft:polished_blackstone_bricks
fill 462 111 493 462 114 493 minecraft:blackstone
setblock 463 111 471 minecraft:polished_blackstone_bricks
fill 463 111 472 463 111 475 minecraft:blackstone
setblock 463 111 486 minecraft:polished_blackstone_bricks
fill 463 111 487 463 114 487 minecraft:blackstone
setblock 463 111 491 minecraft:polished_blackstone_bricks
fill 463 111 492 463 114 492 minecraft:blackstone
setblock 463 111 496 minecraft:polished_blackstone_bricks
fill 463 111 497 463 114 497 minecraft:blackstone
setblock 464 111 470 minecraft:polished_blackstone_bricks
fill 464 111 471 464 111 474 minecraft:blackstone
setblock 464 111 475 minecraft:polished_blackstone_bricks
fill 464 111 476 464 114 476 minecraft:blackstone
setblock 464 111 480 minecraft:polished_blackstone_bricks
fill 464 111 481 464 114 481 minecraft:blackstone
setblock 464 111 485 minecraft:polished_blackstone_bricks
fill 464 111 486 464 114 486 minecraft:blackstone
setblock 464 111 490 minecraft:polished_blackstone_bricks
fill 464 111 491 464 114 491 minecraft:blackstone
setblock 464 111 495 minecraft:polished_blackstone_bricks
fill 464 111 496 464 114 496 minecraft:blackstone
fill 465 111 495 465 206 495 minecraft:blackstone
setblock 424 112 464 minecraft:polished_blackstone_bricks
fill 424 112 465 424 115 465 minecraft:blackstone
setblock 424 112 469 minecraft:polished_blackstone_bricks
fill 424 112 470 424 115 470 minecraft:blackstone
setblock 424 112 474 minecraft:polished_blackstone_bricks
fill 424 112 475 424 112 478 minecraft:blackstone
setblock 424 112 479 minecraft:polished_blackstone_bricks
fill 424 112 480 424 115 480 minecraft:blackstone
setblock 424 112 484 minecraft:polished_blackstone_bricks
fill 424 112 485 424 115 485 minecraft:blackstone
setblock 424 112 489 minecraft:polished_blackstone_bricks
fill 424 112 490 424 115 490 minecraft:blackstone
setblock 424 112 494 minecraft:polished_blackstone_bricks
fill 424 112 495 424 115 495 minecraft:blackstone
fill 425 112 464 425 115 464 minecraft:blackstone
setblock 425 112 468 minecraft:polished_blackstone_bricks
fill 425 112 469 425 115 469 minecraft:blackstone
setblock 425 112 473 minecraft:polished_blackstone_bricks
fill 425 112 474 425 115 474 minecraft:blackstone
setblock 425 112 477 minecraft:blackstone
setblock 425 112 478 minecraft:polished_blackstone_bricks
fill 425 112 479 425 115 479 minecraft:blackstone
fill 425 112 481 425 113 481 minecraft:blackstone
setblock 425 112 489 minecraft:blackstone
setblock 425 112 493 minecraft:polished_blackstone_bricks
fill 425 112 494 425 115 494 minecraft:blackstone
fill 425 112 496 425 113 496 minecraft:blackstone
fill 426 112 468 426 115 468 minecraft:blackstone
setblock 426 112 472 minecraft:polished_blackstone_bricks
fill 426 112 473 426 115 473 minecraft:blackstone
setblock 426 112 477 minecraft:polished_blackstone_bricks
setblock 427 112 465 minecraft:blackstone
setblock 427 112 471 minecraft:polished_blackstone_bricks
fill 427 112 472 427 115 472 minecraft:blackstone
setblock 428 112 465 minecraft:polished_blackstone_bricks
fill 429 112 463 429 206 463 minecraft:blackstone
setblock 429 112 464 minecraft:polished_blackstone_bricks
fill 430 112 464 431 112 464 minecraft:blackstone
fill 438 112 498 438 113 500 minecraft:warped_wart_block
fill 440 112 496 442 113 496 minecraft:warped_wart_block
fill 440 112 502 442 113 502 minecraft:warped_wart_block
fill 441 112 464 443 112 464 minecraft:blackstone
fill 441 112 499 441 115 499 minecraft:warped_wart_block
setblock 444 112 464 minecraft:polished_blackstone_bricks
fill 444 112 498 444 113 500 minecraft:warped_wart_block
setblock 444 112 504 minecraft:polished_blackstone_bricks
fill 444 112 505 444 204 505 minecraft:blackstone
fill 445 112 464 448 112 464 minecraft:blackstone
setblock 445 112 503 minecraft:polished_blackstone_bricks
fill 445 112 504 448 112 504 minecraft:blackstone
fill 446 112 503 446 115 503 minecraft:blackstone
setblock 449 112 504 minecraft:polished_blackstone_bricks
fill 450 112 504 450 115 504 minecraft:blackstone
setblock 462 112 491 minecraft:polished_blackstone_bricks
fill 462 112 492 462 115 492 minecraft:blackstone
fill 462 112 494 462 113 494 minecraft:blackstone
fill 463 112 471 463 112 474 minecraft:blackstone
setblock 463 112 475 minecraft:polished_blackstone_bricks
fill 463 112 476 463 114 477 minecraft:blackstone
fill 463 112 486 463 115 486 minecraft:blackstone
setblock 463 112 490 minecraft:polished_blackstone_bricks
fill 463 112 491 463 115 491 minecraft:blackstone
setblock 463 112 495 minecraft:polished_blackstone_bricks
fill 463 112 496 463 115 496 minecraft:blackstone
setblock 464 112 469 minecraft:polished_blackstone_bricks
fill 464 112 470 464 112 473 minecraft:blackstone
setblock 464 112 474 minecraft:polished_blackstone_bricks
fill 464 112 475 464 115 475 minecraft:blackstone
setblock 464 112 479 minecraft:polished_blackstone_bricks
fill 464 112 480 464 115 480 minecraft:blackstone
setblock 464 112 484 minecraft:polished_blackstone_bricks
fill 464 112 485 464 115 485 minecraft:blackstone
setblock 464 112 489 minecraft:polished_blackstone_bricks
fill 464 112 490 464 115 490 minecraft:blackstone
setblock 464 112 494 minecraft:polished_blackstone_bricks
fill 464 112 495 464 115 495 minecraft:blackstone
setblock 464 112 499 minecraft:polished_blackstone_bricks
fill 464 112 500 464 115 500 minecraft:blackstone
fill 465 112 489 465 203 489 minecraft:blackstone
fill 465 112 494 465 206 494 minecraft:blackstone
fill 424 113 464 424 116 464 minecraft:blackstone
setblock 424 113 468 minecraft:polished_blackstone_bricks
fill 424 113 469 424 116 469 minecraft:blackstone
setblock 424 113 473 minecraft:polished_blackstone_bricks
fill 424 113 474 424 113 477 minecraft:blackstone
setblock 424 113 478 minecraft:polished_blackstone_bricks
fill 424 113 479 424 116 479 minecraft:blackstone
setblock 424 113 483 minecraft:polished_blackstone_bricks
fill 424 113 484 424 116 484 minecraft:blackstone
setblock 424 113 488 minecraft:polished_blackstone_bricks
fill 424 113 489 424 116 489 minecraft:blackstone
setblock 424 113 493 minecraft:polished_blackstone_bricks
fill 424 113 494 424 116 494 minecraft:blackstone
setblock 424 113 498 minecraft:polished_blackstone_bricks
fill 424 113 499 424 116 499 minecraft:blackstone
setblock 425 113 467 minecraft:polished_blackstone_bricks
fill 425 113 468 425 116 468 minecraft:blackstone
setblock 425 113 472 minecraft:polished_blackstone_bricks
fill 425 113 473 425 116 473 minecraft:blackstone
setblock 425 113 477 minecraft:polished_blackstone_bricks
fill 425 113 478 426 115 478 minecraft:blackstone
setblock 425 113 492 minecraft:polished_blackstone_bricks
fill 425 113 493 425 116 493 minecraft:blackstone
fill 426 113 464 426 114 464 minecraft:blackstone
setblock 426 113 471 minecraft:polished_blackstone_bricks
fill 426 113 472 426 116 472 minecraft:blackstone
setblock 426 113 476 minecraft:polished_blackstone_bricks
fill 426 113 477 426 116 477 minecraft:blackstone
setblock 427 113 471 minecraft:blackstone
setblock 428 113 464 minecraft:polished_blackstone_bricks
fill 429 113 464 430 113 464 minecraft:blackstone
fill 441 113 464 442 113 464 minecraft:blackstone
fill 441 113 504 441 114 504 minecraft:blackstone
setblock 443 113 464 minecraft:polished_blackstone_bricks
setblock 443 113 503 minecraft:blackstone
setblock 443 113 504 minecraft:polished_blackstone_bricks
fill 443 113 505 443 206 505 minecraft:blackstone
fill 444 113 464 447 113 464 minecraft:blackstone
setblock 444 113 503 minecraft:polished_blackstone_bricks
fill 444 113 504 447 113 504 minecraft:blackstone
fill 445 113 503 445 116 503 minecraft:blackstone
setblock 448 113 504 minecraft:polished_blackstone_bricks
fill 449 113 504 449 116 504 minecraft:blackstone
setblock 462 113 495 minecraft:polished_blackstone_bricks
fill 463 113 470 463 113 473 minecraft:blackstone
setblock 463 113 474 minecraft:polished_blackstone_bricks
fill 463 113 475 463 116 475 minecraft:blackstone
setblock 463 113 478 minecraft:blackstone
setblock 463 113 479 minecraft:polished_blackstone_bricks
fill 463 113 480 463 116 480 minecraft:blackstone
setblock 463 113 489 minecraft:polished_blackstone_bricks
fill 463 113 490 463 116 490 minecraft:blackstone
setblock 463 113 494 minecraft:polished_blackstone_bricks
fill 463 113 495 463 116 495 minecraft:blackstone
setblock 463 113 498 minecraft:blackstone
setblock 464 113 468 minecraft:polished_blackstone_bricks
fill 464 113 469 464 113 472 minecraft:blackstone
setblock 464 113 473 minecraft:polished_blackstone_bricks
fill 464 113 474 464 116 474 minecraft:blackstone
setblock 464 113 478 minecraft:polished_blackstone_bricks
fill 464 113 479 464 116 479 minecraft:blackstone
setblock 464 113 483 minecraft:polished_blackstone_bricks
fill 464 113 484 464 116 484 minecraft:blackstone
setblock 464 113 488 minecraft:polished_blackstone_bricks
fill 464 113 489 464 116 489 minecraft:blackstone
setblock 464 113 493 minecraft:polished_blackstone_bricks
fill 464 113 494 464 116 494 minecraft:blackstone
setblock 464 113 498 minecraft:polished_blackstone_bricks
fill 464 113 499 464 116 499 minecraft:blackstone
fill 464 113 501 464 114 501 minecraft:blackstone
fill 465 113 493 465 207 493 minecraft:blackstone
setblock 424 114 467 minecraft:polished_blackstone_bricks
fill 424 114 468 424 117 468 minecraft:blackstone
setblock 424 114 472 minecraft:polished_blackstone_bricks
fill 424 114 473 424 114 476 minecraft:blackstone
setblock 424 114 477 minecraft:polished_blackstone_bricks
fill 424 114 478 424 117 478 minecraft:blackstone
setblock 424 114 482 minecraft:polished_blackstone_bricks
fill 424 114 483 424 117 483 minecraft:blackstone
setblock 424 114 487 minecraft:polished_blackstone_bricks
fill 424 114 488 424 117 488 minecraft:blackstone
setblock 424 114 492 minecraft:polished_blackstone_bricks
fill 424 114 493 424 117 493 minecraft:blackstone
setblock 424 114 497 minecraft:polished_blackstone_bricks
fill 424 114 498 424 117 498 minecraft:blackstone
fill 424 114 500 424 114 501 minecraft:blackstone
setblock 425 114 466 minecraft:polished_blackstone_bricks
fill 425 114 467 425 117 467 minecraft:blackstone
setblock 425 114 471 minecraft:polished_blackstone_bricks
fill 425 114 472 425 117 472 minecraft:blackstone
setblock 425 114 476 minecraft:polished_blackstone_bricks
fill 425 114 477 425 117 477 minecraft:blackstone
setblock 425 114 481 minecraft:polished_blackstone_bricks
fill 425 114 482 425 117 482 minecraft:blackstone
setblock 425 114 491 minecraft:polished_blackstone_bricks
fill 425 114 492 425 116 492 minecraft:blackstone
setblock 425 114 496 minecraft:polished_blackstone_bricks
fill 425 114 497 425 117 497 minecraft:blackstone
setblock 426 114 470 minecraft:polished_blackstone_bricks
fill 426 114 471 426 117 471 minecraft:blackstone
setblock 426 114 475 minecraft:polished_blackstone_bricks
fill 426 114 476 426 117 476 minecraft:blackstone
setblock 426 114 479 minecraft:blackstone
setblock 427 114 464 minecraft:polished_blackstone_bricks
setblock 427 114 474 minecraft:polished_blackstone_bricks
fill 427 114 475 427 117 475 minecraft:blackstone
fill 428 114 464 429 116 464 minecraft:blackstone
fill 440 114 464 441 114 464 minecraft:blackstone
fill 440 114 504 440 115 504 minecraft:blackstone
setblock 442 114 464 minecraft:polished_blackstone_bricks
setblock 442 114 503 minecraft:blackstone
setblock 442 114 504 minecraft:polished_blackstone_bricks
fill 443 114 464 446 114 464 minecraft:blackstone
setblock 443 114 503 minecraft:polished_blackstone_bricks
fill 443 114 504 446 114 504 minecraft:blackstone
fill 444 114 503 444 117 503 minecraft:blackstone
setblock 447 114 464 minecraft:polished_blackstone_bricks
setblock 447 114 504 minecraft:polished_blackstone_bricks
setblock 448 114 503 minecraft:polished_blackstone_bricks
fill 448 114 504 448 117 504 minecraft:blackstone
fill 462 114 475 462 117 475 minecraft:blackstone
fill 462 114 491 462 116 491 minecraft:blackstone
setblock 462 114 494 minecraft:polished_blackstone_bricks
fill 462 114 495 462 116 496 minecraft:blackstone
fill 463 114 470 463 114 472 minecraft:blackstone
setblock 463 114 473 minecraft:polished_blackstone_bricks
fill 463 114 474 463 117 474 minecraft:blackstone
setblock 463 114 478 minecraft:polished_blackstone_bricks
fill 463 114 479 463 117 479 minecraft:blackstone
fill 463 114 481 463 114 482 minecraft:blackstone
setblock 463 114 483 minecraft:polished_blackstone_bricks
fill 463 114 484 463 116 485 minecraft:blackstone
setblock 463 114 488 minecraft:polished_blackstone_bricks
fill 463 114 489 463 117 489 minecraft:blackstone
setblock 463 114 493 minecraft:polished_blackstone_bricks
fill 463 114 494 463 117 494 minecraft:blackstone
setblock 463 114 498 minecraft:polished_blackstone_bricks
fill 463 114 499 463 117 499 minecraft:blackstone
setblock 464 114 467 minecraft:polished_blackstone_bricks
fill 464 114 468 464 114 471 minecraft:blackstone
setblock 464 114 472 minecraft:polished_blackstone_bricks
fill 464 114 473 464 117 473 minecraft:blackstone
setblock 464 114 477 minecraft:polished_blackstone_bricks
fill 464 114 478 464 117 478 minecraft:blackstone
setblock 464 114 482 minecraft:polished_blackstone_bricks
fill 464 114 483 464 117 483 minecraft:blackstone
setblock 464 114 487 minecraft:polished_blackstone_bricks
fill 464 114 488 464 117 488 minecraft:blackstone
setblock 464 114 492 minecraft:polished_blackstone_bricks
fill 464 114 493 464 117 493 minecraft:blackstone
setblock 464 114 497 minecraft:polished_blackstone_bricks
fill 464 114 498 464 117 498 minecraft:blackstone
setblock 424 115 466 minecraft:polished_blackstone_bricks
fill 424 115 467 424 118 467 minecraft:blackstone
setblock 424 115 471 minecraft:polished_blackstone_bricks
fill 424 115 472 424 115 475 minecraft:blackstone
setblock 424 115 476 minecraft:polished_blackstone_bricks
fill 424 115 477 424 118 477 minecraft:blackstone
setblock 424 115 481 minecraft:polished_blackstone_bricks
fill 424 115 482 424 118 482 minecraft:blackstone
setblock 424 115 486 minecraft:polished_blackstone_bricks
fill 424 115 487 424 118 487 minecraft:blackstone
setblock 424 115 491 minecraft:polished_blackstone_bricks
fill 424 115 492 424 118 492 minecraft:blackstone
setblock 424 115 496 minecraft:polished_blackstone_bricks
fill 424 115 497 424 118 497 minecraft:blackstone
setblock 424 115 500 minecraft:blackstone
setblock 424 115 501 minecraft:polished_blackstone_bricks
fill 424 115 502 424 117 503 minecraft:blackstone
fill 425 115 466 425 118 466 minecraft:blackstone
setblock 425 115 470 minecraft:polished_blackstone_bricks
fill 425 115 471 425 118 471 minecraft:blackstone
setblock 425 115 475 minecraft:polished_blackstone_bricks
fill 425 115 476 425 118 476 minecraft:blackstone
setblock 425 115 480 minecraft:polished_blackstone_bricks
fill 425 115 481 425 118 481 minecraft:blackstone
setblock 425 115 495 minecraft:polished_blackstone_bricks
fill 425 115 496 425 118 496 minecraft:blackstone
fill 425 115 498 425 115 499 minecraft:blackstone
setblock 426 115 464 minecraft:polished_blackstone_bricks
setblock 426 115 469 minecraft:polished_blackstone_bricks
fill 426 115 470 426 118 470 minecraft:blackstone
setblock 426 115 474 minecraft:polished_blackstone_bricks
fill 426 115 475 426 118 475 minecraft:blackstone
setblock 426 115 479 minecraft:polished_blackstone_bricks
fill 427 115 464 427 118 464 minecraft:blackstone
setblock 427 115 473 minecraft:polished_blackstone_bricks
fill 427 115 474 427 118 474 minecraft:blackstone
fill 427 115 476 427 116 476 minecraft:blackstone
setblock 430 115 464 minecraft:blackstone
fill 438 115 504 439 116 504 minecraft:blackstone
fill 439 115 464 440 115 464 minecraft:blackstone
fill 440 115 503 441 115 503 minecraft:blackstone
setblock 441 115 464 minecraft:polished_blackstone_bricks
setblock 441 115 504 minecraft:polished_blackstone_bricks
fill 442 115 464 445 115 464 minecraft:blackstone
setblock 442 115 502 minecraft:blackstone
setblock 442 115 503 minecraft:polished_blackstone_bricks
fill 442 115 504 445 115 504 minecraft:blackstone
setblock 443 115 502 minecraft:polished_blackstone_bricks
fill 443 115 503 443 118 503 minecraft:blackstone
fill 444 115 502 447 115 502 minecraft:blackstone
setblock 446 115 464 minecraft:polished_blackstone_bricks
setblock 446 115 504 minecraft:polished_blackstone_bricks
fill 447 115 464 447 118 464 minecraft:blackstone
setblock 447 115 503 minecraft:polished_blackstone_bricks
fill 447 115 504 447 118 504 minecraft:blackstone
fill 448 115 503 448 118 503 minecraft:blackstone
fill 457 115 475 461 116 479 minecraft:blackstone
setblock 462 115 473 minecraft:polished_blackstone_bricks
fill 462 115 474 462 118 474 minecraft:blackstone
fill 462 115 476 462 115 477 minecraft:blackstone
setblock 462 115 478 minecraft:polished_blackstone_bricks
fill 462 115 479 462 118 479 minecraft:blackstone
setblock 462 115 493 minecraft:polished_blackstone_bricks
fill 462 115 494 462 118 494 minecraft:blackstone
setblock 462 115 497 minecraft:blackstone
fill 463 115 469 463 115 471 minecraft:blackstone
setblock 463 115 472 minecraft:polished_blackstone_bricks
fill 463 115 473 463 118 473 minecraft:blackstone
setblock 463 115 476 minecraft:blackstone
setblock 463 115 477 minecraft:polished_blackstone_bricks
fill 463 115 478 463 118 478 minecraft:blackstone
setblock 463 115 481 minecraft:blackstone
setblock 463 115 482 minecraft:polished_blackstone_bricks
fill 463 115 483 463 118 483 minecraft:blackstone
setblock 463 115 487 minecraft:polished_blackstone_bricks
fill 463 115 488 463 118 488 minecraft:blackstone
setblock 463 115 492 minecraft:polished_blackstone_bricks
fill 463 115 493 463 118 493 minecraft:blackstone
setblock 463 115 497 minecraft:polished_blackstone_bricks
fill 463 115 498 463 118 498 minecraft:blackstone
fill 463 115 500 463 116 500 minecraft:blackstone
setblock 464 115 466 minecraft:polished_blackstone_bricks
fill 464 115 467 464 115 470 minecraft:blackstone
setblock 464 115 471 minecraft:polished_blackstone_bricks
fill 464 115 472 464 118 472 minecraft:blackstone
setblock 464 115 476 minecraft:polished_blackstone_bricks
fill 464 115 477 464 118 477 minecraft:blackstone
setblock 464 115 481 minecraft:polished_blackstone_bricks
fill 464 115 482 464 118 482 minecraft:blackstone
setblock 464 115 486 minecraft:polished_blackstone_bricks
fill 464 115 487 464 118 487 minecraft:blackstone
setblock 464 115 491 minecraft:polished_blackstone_bricks
fill 464 115 492 464 118 492 minecraft:blackstone
setblock 464 115 496 minecraft:polished_blackstone_bricks
fill 464 115 497 464 118 497 minecraft:blackstone
setblock 464 115 501 minecraft:polished_blackstone_bricks
fill 464 115 502 464 117 503 minecraft:blackstone
setblock 424 116 465 minecraft:polished_blackstone_bricks
fill 424 116 466 424 119 466 minecraft:blackstone
setblock 424 116 470 minecraft:polished_blackstone_bricks
fill 424 116 471 424 116 474 minecraft:blackstone
setblock 424 116 475 minecraft:polished_blackstone_bricks
fill 424 116 476 424 119 476 minecraft:blackstone
setblock 424 116 480 minecraft:polished_blackstone_bricks
fill 424 116 481 424 119 481 minecraft:blackstone
setblock 424 116 485 minecraft:polished_blackstone_bricks
fill 424 116 486 424 119 486 minecraft:blackstone
setblock 424 116 490 minecraft:polished_blackstone_bricks
fill 424 116 491 424 119 491 minecraft:blackstone
setblock 424 116 495 minecraft:polished_blackstone_bricks
fill 424 116 496 424 119 496 minecraft:blackstone
setblock 424 116 500 minecraft:polished_blackstone_bricks
fill 424 116 501 425 118 501 minecraft:blackstone
setblock 424 116 504 minecraft:blackstone
setblock 425 116 464 minecraft:polished_blackstone_bricks
fill 425 116 465 426 118 465 minecraft:blackstone
setblock 425 116 469 minecraft:polished_blackstone_bricks
fill 425 116 470 425 119 470 minecraft:blackstone
setblock 425 116 474 minecraft:polished_blackstone_bricks
fill 425 116 475 425 119 475 minecraft:blackstone
setblock 425 116 478 minecraft:blackstone
setblock 425 116 479 minecraft:polished_blackstone_bricks
fill 425 116 480 426 118 480 minecraft:blackstone
setblock 425 116 483 minecraft:blackstone
setblock 425 116 494 minecraft:polished_blackstone_bricks
fill 425 116 495 425 119 495 minecraft:blackstone
setblock 425 116 498 minecraft:blackstone
setblock 425 116 499 minecraft:polished_blackstone_bricks
fill 425 116 500 425 119 500 minecraft:blackstone
setblock 425 116 504 minecraft:polished_blackstone_bricks
fill 426 116 464 426 119 464 minecraft:blackstone
fill 426 116 469 426 118 469 minecraft:blackstone
setblock 426 116 473 minecraft:polished_blackstone_bricks
fill 426 116 474 426 119 474 minecraft:blackstone
setblock 426 116 478 minecraft:polished_blackstone_bricks
fill 426 116 479 426 119 479 minecraft:blackstone
fill 426 116 504 428 117 504 minecraft:blackstone
setblock 427 116 472 minecraft:polished_blackstone_bricks
fill 427 116 473 427 117 473 minecraft:blackstone
setblock 430 116 464 minecraft:polished_blackstone_bricks
fill 437 116 504 437 118 504 minecraft:blackstone
fill 438 116 464 439 116 464 minecraft:blackstone
fill 439 116 503 440 116 503 minecraft:blackstone
setblock 440 116 464 minecraft:polished_blackstone_bricks
setblock 440 116 504 minecraft:polished_blackstone_bricks
fill 441 116 464 444 116 464 minecraft:blackstone
setblock 441 116 502 minecraft:blackstone
setblock 441 116 503 minecraft:polished_blackstone_bricks
fill 441 116 504 444 116 504 minecraft:blackstone
setblock 442 116 502 minecraft:polished_blackstone_bricks
fill 442 116 503 442 119 503 minecraft:blackstone
setblock 443 116 501 minecraft:polished_blackstone_bricks
fill 443 116 502 446 116 502 minecraft:blackstone
fill 444 116 501 445 118 501 minecraft:blackstone
setblock 445 116 464 minecraft:polished_blackstone_bricks
setblock 445 116 504 minecraft:polished_blackstone_bricks
fill 446 116 464 446 119 464 minecraft:blackstone
setblock 446 116 503 minecraft:polished_blackstone_bricks
fill 446 116 504 446 119 504 minecraft:blackstone
setblock 447 116 502 minecraft:polished_blackstone_bricks
fill 447 116 503 447 119 503 minecraft:blackstone
fill 449 116 503 449 117 503 minecraft:blackstone
setblock 450 116 504 minecraft:polished_blackstone_bricks
setblock 462 116 472 minecraft:polished_blackstone_bricks
fill 462 116 473 462 119 473 minecraft:blackstone
setblock 462 116 476 minecraft:blackstone
setblock 462 116 477 minecraft:polished_blackstone_bricks
fill 462 116 478 462 119 478 minecraft:blackstone
fill 462 116 480 462 116 481 minecraft:blackstone
setblock 462 116 482 minecraft:polished_blackstone_bricks
setblock 462 116 492 minecraft:polished_blackstone_bricks
fill 462 116 493 462 119 493 minecraft:blackstone
setblock 462 116 497 minecraft:polished_blackstone_bricks
fill 462 116 498 462 119 498 minecraft:blackstone
fill 463 116 469 463 116 470 minecraft:blackstone
setblock 463 116 471 minecraft:polished_blackstone_bricks
fill 463 116 472 463 119 472 minecraft:blackstone
setblock 463 116 476 minecraft:polished_blackstone_bricks
fill 463 116 477 463 119 477 minecraft:blackstone
setblock 463 116 481 minecraft:polished_blackstone_bricks
fill 463 116 482 463 119 482 minecraft:blackstone
setblock 463 116 486 minecraft:polished_blackstone_bricks
fill 463 116 487 463 119 487 minecraft:blackstone
setblock 463 116 491 minecraft:polished_blackstone_bricks
fill 463 116 492 463 119 492 minecraft:blackstone
setblock 463 116 496 minecraft:polished_blackstone_bricks
fill 463 116 497 463 119 497 minecraft:blackstone
setblock 463 116 501 minecraft:polished_blackstone_bricks
fill 463 116 504 464 116 504 minecraft:blackstone
setblock 464 116 465 minecraft:polished_blackstone_bricks
fill 464 116 466 464 116 469 minecraft:blackstone
setblock 464 116 470 minecraft:polished_blackstone_bricks
fill 464 116 471 464 119 471 minecraft:blackstone
setblock 464 116 475 minecraft:polished_blackstone_bricks
fill 464 116 476 464 119 476 minecraft:blackstone
setblock 464 116 480 minecraft:polished_blackstone_bricks
fill 464 116 481 464 119 481 minecraft:blackstone
setblock 464 116 485 minecraft:polished_blackstone_bricks
fill 464 116 486 464 119 486 minecraft:blackstone
setblock 464 116 490 minecraft:polished_blackstone_bricks
fill 464 116 491 464 119 491 minecraft:blackstone
setblock 464 116 495 minecraft:polished_blackstone_bricks
fill 464 116 496 464 119 496 minecraft:blackstone
setblock 464 116 500 minecraft:polished_blackstone_bricks
fill 464 116 501 464 119 501 minecraft:blackstone
setblock 424 117 464 minecraft:polished_blackstone_bricks
fill 424 117 465 424 120 465 minecraft:blackstone
setblock 424 117 469 minecraft:polished_blackstone_bricks
fill 424 117 470 424 117 473 minecraft:blackstone
setblock 424 117 474 minecraft:polished_blackstone_bricks
fill 424 117 475 424 120 475 minecraft:blackstone
setblock 424 117 479 minecraft:polished_blackstone_bricks
fill 424 117 480 424 120 480 minecraft:blackstone
setblock 424 117 484 minecraft:polished_blackstone_bricks
fill 424 117 485 424 120 485 minecraft:blackstone
setblock 424 117 489 minecraft:polished_blackstone_bricks
fill 424 117 490 424 120 490 minecraft:blackstone
setblock 424 117 494 minecraft:polished_blackstone_bricks
fill 424 117 495 424 120 495 minecraft:blackstone
setblock 424 117 499 minecraft:polished_blackstone_bricks
fill 424 117 500 424 120 500 minecraft:blackstone
setblock 424 117 504 minecraft:polished_blackstone_bricks
fill 425 117 464 425 120 464 minecraft:blackstone
setblock 425 117 468 minecraft:polished_blackstone_bricks
fill 425 117 469 425 120 469 minecraft:blackstone
setblock 425 117 473 minecraft:polished_blackstone_bricks
fill 425 117 474 425 120 474 minecraft:blackstone
setblock 425 117 478 minecraft:polished_blackstone_bricks
fill 425 117 479 425 120 479 minecraft:blackstone
setblock 425 117 483 minecraft:polished_blackstone_bricks
setblock 425 117 493 minecraft:polished_blackstone_bricks
fill 425 117 494 425 118 494 minecraft:blackstone
setblock 425 117 498 minecraft:polished_blackstone_bricks
fill 425 117 499 425 120 499 minecraft:blackstone
setblock 425 117 502 minecraft:blackstone
fill 425 117 504 425 120 504 minecraft:blackstone
setblock 426 117 472 minecraft:polished_blackstone_bricks
fill 426 117 473 426 120 473 minecraft:blackstone
setblock 426 117 477 minecraft:polished_blackstone_bricks
fill 426 117 478 426 120 478 minecraft:blackstone
setblock 427 117 465 minecraft:blackstone
setblock 427 117 476 minecraft:polished_blackstone_bricks
setblock 428 117 464 minecraft:blackstone
setblock 429 117 464 minecraft:polished_blackstone_bricks
setblock 429 117 504 minecraft:polished_blackstone_bricks
fill 430 117 464 431 119 464 minecraft:blackstone
setblock 434 117 504 minecraft:polished_blackstone_bricks
fill 435 117 504 436 119 504 minecraft:blackstone
fill 436 117 464 438 117 464 minecraft:blackstone
fill 437 117 503 439 117 503 minecraft:blackstone
setblock 438 117 504 minecraft:blackstone
setblock 439 117 464 minecraft:polished_blackstone_bricks
fill 439 117 502 440 117 502 minecraft:blackstone
setblock 439 117 504 minecraft:polished_blackstone_bricks
fill 440 117 464 443 117 464 minecraft:blackstone
setblock 440 117 503 minecraft:polished_blackstone_bricks
fill 440 117 504 443 117 504 minecraft:blackstone
fill 441 117 465 442 117 465 minecraft:blackstone
setblock 441 117 501 minecraft:blackstone
setblock 441 117 502 minecraft:polished_blackstone_bricks
fill 441 117 503 441 120 503 minecraft:blackstone
setblock 442 117 501 minecraft:polished_blackstone_bricks
fill 442 117 502 445 117 502 minecraft:blackstone
setblock 443 117 465 minecraft:polished_blackstone_bricks
fill 443 117 501 443 120 501 minecraft:blackstone
setblock 444 117 464 minecraft:polished_blackstone_bricks
setblock 444 117 504 minecraft:polished_blackstone_bricks
fill 445 117 464 445 120 464 minecraft:blackstone
setblock 445 117 503 minecraft:polished_blackstone_bricks
fill 445 117 504 445 120 504 minecraft:blackstone
setblock 446 117 501 minecraft:blackstone
setblock 446 117 502 minecraft:polished_blackstone_bricks
fill 446 117 503 446 120 503 minecraft:blackstone
fill 447 117 502 448 119 502 minecraft:blackstone
setblock 449 117 504 minecraft:polished_blackstone_bricks
fill 450 117 504 451 119 504 minecraft:blackstone
fill 458 117 477 461 117 477 minecraft:polished_blackstone_bricks
fill 460 117 504 463 117 504 minecraft:blackstone
fill 461 117 475 461 117 476 minecraft:blackstone
fill 461 117 478 461 119 479 minecraft:blackstone
setblock 462 117 471 minecraft:polished_blackstone_bricks
fill 462 117 472 462 120 472 minecraft:blackstone
setblock 462 117 476 minecraft:polished_blackstone_bricks
fill 462 117 477 462 120 477 minecraft:blackstone
setblock 462 117 480 minecraft:blackstone
setblock 462 117 481 minecraft:polished_blackstone_bricks
fill 462 117 482 462 118 484 minecraft:blackstone
setblock 462 117 491 minecraft:polished_blackstone_bricks
fill 462 117 492 462 119 492 minecraft:blackstone
setblock 462 117 495 minecraft:blackstone
setblock 462 117 496 minecraft:polished_blackstone_bricks
fill 462 117 497 462 120 497 minecraft:blackstone
fill 462 117 499 462 117 500 minecraft:blackstone
setblock 463 117 464 minecraft:blackstone
setblock 463 117 469 minecraft:blackstone
setblock 463 117 470 minecraft:polished_blackstone_bricks
fill 463 117 471 463 120 471 minecraft:blackstone
setblock 463 117 475 minecraft:polished_blackstone_bricks
fill 463 117 476 463 120 476 minecraft:blackstone
setblock 463 117 480 minecraft:polished_blackstone_bricks
fill 463 117 481 463 120 481 minecraft:blackstone
setblock 463 117 484 minecraft:blackstone
setblock 463 117 485 minecraft:polished_blackstone_bricks
fill 463 117 486 463 120 486 minecraft:blackstone
setblock 463 117 490 minecraft:polished_blackstone_bricks
fill 463 117 491 463 120 491 minecraft:blackstone
setblock 463 117 495 minecraft:polished_blackstone_bricks
fill 463 117 496 463 120 496 minecraft:blackstone
setblock 463 117 500 minecraft:polished_blackstone_bricks
fill 463 117 501 463 119 502 minecraft:blackstone
setblock 464 117 464 minecraft:polished_blackstone_bricks
fill 464 117 465 464 117 468 minecraft:blackstone
setblock 464 117 469 minecraft:polished_blackstone_bricks
fill 464 117 470 464 120 470 minecraft:blackstone
setblock 464 117 474 minecraft:polished_blackstone_bricks
fill 464 117 475 464 120 475 minecraft:blackstone
setblock 464 117 479 minecraft:polished_blackstone_bricks
fill 464 117 480 464 120 480 minecraft:blackstone
setblock 464 117 484 minecraft:polished_blackstone_bricks
fill 464 117 485 464 120 485 minecraft:blackstone
setblock 464 117 489 minecraft:polished_blackstone_bricks
fill 464 117 490 464 120 490 minecraft:blackstone
setblock 464 117 494 minecraft:polished_blackstone_bricks
fill 464 117 495 464 120 495 minecraft:blackstone
setblock 464 117 499 minecraft:polished_blackstone_bricks
fill 464 117 500 464 120 500 minecraft:blackstone
setblock 464 117 504 minecraft:polished_blackstone_bricks
fill 424 118 464 424 121 464 minecraft:blackstone
setblock 424 118 468 minecraft:polished_blackstone_bricks
fill 424 118 469 424 118 472 minecraft:blackstone
setblock 424 118 473 minecraft:polished_blackstone_bricks
fill 424 118 474 424 121 474 minecraft:blackstone
setblock 424 118 478 minecraft:polished_blackstone_bricks
fill 424 118 479 424 121 479 minecraft:blackstone
setblock 424 118 483 minecraft:polished_blackstone_bricks
fill 424 118 484 425 120 484 minecraft:blackstone
setblock 424 118 488 minecraft:polished_blackstone_bricks
fill 424 118 489 424 120 489 minecraft:blackstone
setblock 424 118 493 minecraft:polished_blackstone_bricks
fill 424 118 494 424 121 494 minecraft:blackstone
setblock 424 118 498 minecraft:polished_blackstone_bricks
fill 424 118 499 424 121 499 minecraft:blackstone
setblock 424 118 502 minecraft:blackstone
setblock 424 118 503 minecraft:polished_blackstone_bricks
fill 424 118 504 424 121 504 minecraft:blackstone
setblock 425 118 467 minecraft:polished_blackstone_bricks
fill 425 118 468 425 121 468 minecraft:blackstone
setblock 425 118 472 minecraft:polished_blackstone_bricks
fill 425 118 473 425 121 473 minecraft:blackstone
setblock 425 118 477 minecraft:polished_blackstone_bricks
fill 425 118 478 425 121 478 minecraft:blackstone
setblock 425 118 482 minecraft:polished_blackstone_bricks
fill 425 118 483 425 121 483 minecraft:blackstone
setblock 425 118 497 minecraft:polished_blackstone_bricks
fill 425 118 498 425 121 498 minecraft:blackstone
setblock 425 118 502 minecraft:polished_blackstone_bricks
fill 425 118 503 427 119 503 minecraft:blackstone
setblock 426 118 466 minecraft:light[level=11]
setblock 426 118 471 minecraft:polished_blackstone_bricks
fill 426 118 472 426 120 472 minecraft:blackstone
setblock 426 118 476 minecraft:polished_blackstone_bricks
fill 426 118 477 426 121 477 minecraft:blackstone
setblock 426 118 481 minecraft:polished_blackstone_bricks
setblock 426 118 482 minecraft:light[level=11]
setblock 426 118 490 minecraft:light[level=11]
setblock 426 118 498 minecraft:light[level=11]
fill 426 118 504 427 118 504 minecraft:blackstone
setblock 427 118 465 minecraft:polished_blackstone_bricks
setblock 427 118 475 minecraft:polished_blackstone_bricks
setblock 427 118 476 minecraft:blackstone
setblock 428 118 464 minecraft:polished_blackstone_bricks
setblock 428 118 504 minecraft:polished_blackstone_bricks
fill 429 118 464 429 121 464 minecraft:blackstone
fill 429 118 504 432 118 504 minecraft:blackstone
setblock 432 118 464 minecraft:blackstone
setblock 433 118 464 minecraft:polished_blackstone_bricks
setblock 433 118 504 minecraft:polished_blackstone_bricks
fill 434 118 464 437 118 464 minecraft:blackstone
setblock 434 118 466 minecraft:light[level=11]
setblock 434 118 474 minecraft:light[level=11]
setblock 434 118 482 minecraft:light[level=11]
setblock 434 118 490 minecraft:light[level=11]
setblock 434 118 498 minecraft:light[level=11]
fill 434 118 504 434 121 504 minecraft:blackstone
fill 435 118 503 438 118 503 minecraft:blackstone
fill 437 118 502 439 118 502 minecraft:blackstone
setblock 438 118 464 minecraft:polished_blackstone_bricks
setblock 438 118 504 minecraft:polished_blackstone_bricks
fill 439 118 464 442 118 464 minecraft:blackstone
fill 439 118 501 440 118 501 minecraft:blackstone
setblock 439 118 503 minecraft:polished_blackstone_bricks
fill 439 118 504 442 118 504 minecraft:blackstone
fill 440 118 465 441 118 465 minecraft:blackstone
setblock 440 118 502 minecraft:polished_blackstone_bricks
fill 440 118 503 440 121 503 minecraft:blackstone
setblock 441 118 501 minecraft:polished_blackstone_bricks
fill 441 118 502 444 118 502 minecraft:blackstone
setblock 442 118 465 minecraft:polished_blackstone_bricks
setblock 442 118 466 minecraft:light[level=11]
setblock 442 118 474 minecraft:light[level=11]
setblock 442 118 482 minecraft:light[level=11]
setblock 442 118 490 minecraft:light[level=11]
setblock 442 118 498 minecraft:light[level=11]
setblock 442 118 500 minecraft:polished_blackstone_bricks
fill 442 118 501 442 121 501 minecraft:blackstone
setblock 443 118 464 minecraft:polished_blackstone_bricks
fill 443 118 465 443 120 465 minecraft:blackstone
fill 443 118 500 444 120 500 minecraft:blackstone
setblock 443 118 504 minecraft:polished_blackstone_bricks
fill 444 118 464 444 121 464 minecraft:blackstone
setblock 444 118 503 minecraft:polished_blackstone_bricks
fill 444 118 504 444 121 504 minecraft:blackstone
setblock 445 118 502 minecraft:polished_blackstone_bricks
fill 445 118 503 445 121 503 minecraft:blackstone
setblock 446 118 501 minecraft:polished_blackstone_bricks
fill 446 118 502 446 121 502 minecraft:blackstone
fill 447 118 501 447 119 501 minecraft:blackstone
setblock 448 118 504 minecraft:polished_blackstone_bricks
setblock 449 118 503 minecraft:polished_blackstone_bricks
fill 449 118 504 449 121 504 minecraft:blackstone
setblock 450 118 466 minecraft:light[level=11]
setblock 450 118 474 minecraft:light[level=11]
setblock 450 118 482 minecraft:light[level=11]
setblock 450 118 490 minecraft:light[level=11]
setblock 450 118 498 minecraft:light[level=11]
fill 450 118 503 450 121 503 minecraft:blackstone
setblock 458 118 466 minecraft:light[level=11]
setblock 458 118 474 minecraft:light[level=11]
fill 458 118 477 460 121 477 minecraft:polished_blackstone_bricks
setblock 458 118 482 minecraft:light[level=11]
setblock 458 118 490 minecraft:light[level=11]
setblock 458 118 498 minecraft:light[level=11]
setblock 458 118 504 minecraft:polished_blackstone_bricks
fill 459 118 504 462 118 504 minecraft:blackstone
fill 460 118 503 463 118 503 minecraft:blackstone
fill 461 118 464 462 118 464 minecraft:blackstone
fill 461 118 474 461 118 475 minecraft:blackstone
setblock 461 118 476 minecraft:polished_blackstone_bricks
fill 461 118 477 461 121 477 minecraft:blackstone
setblock 461 118 480 minecraft:blackstone
setblock 461 118 481 minecraft:polished_blackstone_bricks
fill 462 118 471 462 120 471 minecraft:blackstone
setblock 462 118 475 minecraft:polished_blackstone_bricks
fill 462 118 476 462 121 476 minecraft:blackstone
setblock 462 118 480 minecraft:polished_blackstone_bricks
fill 462 118 481 462 121 481 minecraft:blackstone
setblock 462 118 485 minecraft:polished_blackstone_bricks
fill 462 118 486 462 121 486 minecraft:blackstone
setblock 462 118 491 minecraft:blackstone
setblock 462 118 495 minecraft:polished_blackstone_bricks
fill 462 118 496 462 121 496 minecraft:blackstone
setblock 462 118 499 minecraft:blackstone
setblock 462 118 500 minecraft:polished_blackstone_bricks
fill 462 118 501 462 121 501 minecraft:blackstone
setblock 463 118 464 minecraft:polished_blackstone_bricks
setblock 463 118 468 minecraft:blackstone
setblock 463 118 469 minecraft:polished_blackstone_bricks
fill 463 118 470 463 121 470 minecraft:blackstone
setblock 463 118 474 minecraft:polished_blackstone_bricks
fill 463 118 475 463 121 475 minecraft:blackstone
setblock 463 118 479 minecraft:polished_blackstone_bricks
fill 463 118 480 463 121 480 minecraft:blackstone
setblock 463 118 484 minecraft:polished_blackstone_bricks
fill 463 118 485 463 121 485 minecraft:blackstone
setblock 463 118 489 minecraft:polished_blackstone_bricks
fill 463 118 490 463 121 490 minecraft:blackstone
setblock 463 118 494 minecraft:polished_blackstone_bricks
fill 463 118 495 463 121 495 minecraft:blackstone
setblock 463 118 499 minecraft:polished_blackstone_bricks
fill 463 118 500 463 121 500 minecraft:blackstone
setblock 463 118 504 minecraft:polished_blackstone_bricks
fill 464 118 464 464 118 467 minecraft:blackstone
setblock 464 118 468 minecraft:polished_blackstone_bricks
fill 464 118 469 464 121 469 minecraft:blackstone
setblock 464 118 473 minecraft:polished_blackstone_bricks
fill 464 118 474 464 121 474 minecraft:blackstone
setblock 464 118 478 minecraft:polished_blackstone_bricks
fill 464 118 479 464 121 479 minecraft:blackstone
setblock 464 118 483 minecraft:polished_blackstone_bricks
fill 464 118 484 464 121 484 minecraft:blackstone
setblock 464 118 488 minecraft:polished_blackstone_bricks
fill 464 118 489 464 121 489 minecraft:blackstone
setblock 464 118 493 minecraft:polished_blackstone_bricks
fill 464 118 494 464 121 494 minecraft:blackstone
setblock 464 118 498 minecraft:polished_blackstone_bricks
fill 464 118 499 464 121 499 minecraft:blackstone
setblock 464 118 502 minecraft:blackstone
setblock 464 118 503 minecraft:polished_blackstone_bricks
fill 464 118 504 464 121 504 minecraft:blackstone
setblock 424 119 467 minecraft:polished_blackstone_bricks
fill 424 119 468 424 119 471 minecraft:blackstone
setblock 424 119 472 minecraft:polished_blackstone_bricks
fill 424 119 473 424 122 473 minecraft:blackstone
setblock 424 119 477 minecraft:polished_blackstone_bricks
fill 424 119 478 424 122 478 minecraft:blackstone
setblock 424 119 482 minecraft:polished_blackstone_bricks
fill 424 119 483 424 122 483 minecraft:blackstone
setblock 424 119 487 minecraft:polished_blackstone_bricks
fill 424 119 488 424 120 488 minecraft:blackstone
setblock 424 119 492 minecraft:polished_blackstone_bricks
fill 424 119 493 424 121 493 minecraft:blackstone
setblock 424 119 497 minecraft:polished_blackstone_bricks
fill 424 119 498 424 122 498 minecraft:blackstone
setblock 424 119 501 minecraft:blackstone
setblock 424 119 502 minecraft:polished_blackstone_bricks
fill 424 119 503 424 122 503 minecraft:blackstone
setblock 425 119 465 minecraft:blackstone
setblock 425 119 466 minecraft:polished_blackstone_bricks
fill 425 119 467 425 122 467 minecraft:blackstone
setblock 425 119 471 minecraft:polished_blackstone_bricks
fill 425 119 472 425 122 472 minecraft:blackstone
setblock 425 119 476 minecraft:polished_blackstone_bricks
fill 425 119 477 425 122 477 minecraft:blackstone
setblock 425 119 480 minecraft:blackstone
setblock 425 119 481 minecraft:polished_blackstone_bricks
fill 425 119 482 425 122 482 minecraft:blackstone
setblock 425 119 496 minecraft:polished_blackstone_bricks
fill 425 119 497 425 121 497 minecraft:blackstone
setblock 425 119 501 minecraft:polished_blackstone_bricks
fill 425 119 502 425 122 502 minecraft:blackstone
setblock 426 119 465 minecraft:polished_blackstone_bricks
setblock 426 119 470 minecraft:polished_blackstone_bricks
setblock 426 119 471 minecraft:blackstone
setblock 426 119 475 minecraft:polished_blackstone_bricks
fill 426 119 476 426 121 476 minecraft:blackstone
setblock 426 119 480 minecraft:polished_blackstone_bricks
fill 426 119 481 426 120 481 minecraft:blackstone
setblock 426 119 504 minecraft:blackstone
setblock 427 119 464 minecraft:polished_blackstone_bricks
fill 427 119 465 427 120 465 minecraft:blackstone
setblock 427 119 504 minecraft:polished_blackstone_bricks
fill 428 119 464 428 122 464 minecraft:blackstone
setblock 428 119 503 minecraft:polished_blackstone_bricks
fill 428 119 504 431 119 504 minecraft:blackstone
setblock 432 119 464 minecraft:polished_blackstone_bricks
setblock 432 119 504 minecraft:polished_blackstone_bricks
fill 433 119 464 436 119 464 minecraft:blackstone
fill 433 119 504 433 122 504 minecraft:blackstone
fill 434 119 503 437 119 503 minecraft:blackstone
fill 436 119 502 438 119 502 minecraft:blackstone
setblock 437 119 464 minecraft:polished_blackstone_bricks
setblock 437 119 504 minecraft:polished_blackstone_bricks
fill 438 119 464 440 119 465 minecraft:blackstone
fill 438 119 501 439 119 501 minecraft:blackstone
setblock 438 119 503 minecraft:polished_blackstone_bricks
fill 438 119 504 441 119 504 minecraft:blackstone
setblock 439 119 502 minecraft:polished_blackstone_bricks
fill 439 119 503 439 122 503 minecraft:blackstone
setblock 440 119 501 minecraft:polished_blackstone_bricks
fill 440 119 502 443 119 502 minecraft:blackstone
setblock 441 119 464 minecraft:blackstone
setblock 441 119 465 minecraft:polished_blackstone_bricks
setblock 441 119 500 minecraft:polished_blackstone_bricks
fill 441 119 501 441 122 501 minecraft:blackstone
setblock 442 119 464 minecraft:polished_blackstone_bricks
fill 442 119 465 442 122 465 minecraft:blackstone
fill 442 119 500 442 122 500 minecraft:blackstone
setblock 442 119 504 minecraft:polished_blackstone_bricks
fill 443 119 464 443 122 464 minecraft:blackstone
setblock 443 119 503 minecraft:polished_blackstone_bricks
fill 443 119 504 443 122 504 minecraft:blackstone
setblock 444 119 501 minecraft:blackstone
setblock 444 119 502 minecraft:polished_blackstone_bricks
fill 444 119 503 444 122 503 minecraft:blackstone
setblock 445 119 501 minecraft:polished_blackstone_bricks
fill 445 119 502 445 122 502 minecraft:blackstone
fill 446 119 501 446 121 501 minecraft:blackstone
setblock 447 119 504 minecraft:polished_blackstone_bricks
setblock 448 119 503 minecraft:polished_blackstone_bricks
fill 448 119 504 448 122 504 minecraft:blackstone
fill 449 119 503 449 122 503 minecraft:blackstone
setblock 452 119 504 minecraft:polished_blackstone_bricks
fill 455 119 504 456 119 504 minecraft:blackstone
setblock 457 119 504 minecraft:polished_blackstone_bricks
setblock 458 119 503 minecraft:polished_blackstone_bricks
fill 458 119 504 461 119 504 minecraft:blackstone
fill 459 119 503 462 119 503 minecraft:blackstone
fill 460 119 464 461 119 464 minecraft:blackstone
setblock 461 119 474 minecraft:blackstone
setblock 461 119 475 minecraft:polished_blackstone_bricks
fill 461 119 476 461 122 476 minecraft:blackstone
setblock 461 119 480 minecraft:polished_blackstone_bricks
fill 461 119 481 461 120 483 minecraft:blackstone
setblock 462 119 464 minecraft:polished_blackstone_bricks
setblock 462 119 474 minecraft:polished_blackstone_bricks
fill 462 119 475 462 122 475 minecraft:blackstone
setblock 462 119 479 minecraft:polished_blackstone_bricks
fill 462 119 480 462 122 480 minecraft:blackstone
fill 462 119 482 462 119 483 minecraft:blackstone
setblock 462 119 484 minecraft:polished_blackstone_bricks
fill 462 119 485 462 122 485 minecraft:blackstone
fill 462 119 487 462 120 487 minecraft:blackstone
setblock 462 119 494 minecraft:polished_blackstone_bricks
fill 462 119 495 462 120 495 minecraft:blackstone
setblock 462 119 499 minecraft:polished_blackstone_bricks
fill 462 119 500 462 122 500 minecraft:blackstone
setblock 462 119 504 minecraft:polished_blackstone_bricks
fill 463 119 464 464 121 464 minecraft:blackstone
setblock 463 119 468 minecraft:polished_blackstone_bricks
fill 463 119 469 463 121 469 minecraft:blackstone
setblock 463 119 473 minecraft:polished_blackstone_bricks
fill 463 119 474 463 122 474 minecraft:blackstone
setblock 463 119 478 minecraft:polished_blackstone_bricks
fill 463 119 479 463 122 479 minecraft:blackstone
setblock 463 119 483 minecraft:polished_blackstone_bricks
fill 463 119 484 463 122 484 minecraft:blackstone
setblock 463 119 488 minecraft:polished_blackstone_bricks
fill 463 119 489 463 121 489 minecraft:blackstone
setblock 463 119 493 minecraft:polished_blackstone_bricks
fill 463 119 494 463 121 494 minecraft:blackstone
setblock 463 119 498 minecraft:polished_blackstone_bricks
fill 463 119 499 463 122 499 minecraft:blackstone
setblock 463 119 503 minecraft:polished_blackstone_bricks
fill 463 119 504 463 122 504 minecraft:blackstone
fill 464 119 465 464 119 466 minecraft:blackstone
setblock 464 119 467 minecraft:polished_blackstone_bricks
fill 464 119 468 464 122 468 minecraft:blackstone
setblock 464 119 472 minecraft:polished_blackstone_bricks
fill 464 119 473 464 122 473 minecraft:blackstone
setblock 464 119 477 minecraft:polished_blackstone_bricks
fill 464 119 478 464 122 478 minecraft:blackstone
setblock 464 119 482 minecraft:polished_blackstone_bricks
schedule function dropper:buildpart/117_4 1t
