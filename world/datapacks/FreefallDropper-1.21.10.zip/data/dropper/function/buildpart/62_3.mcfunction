fill 94 172 283 94 173 284 minecraft:red_concrete
fill 94 172 285 94 173 286 minecraft:white_concrete
fill 94 172 287 94 173 287 minecraft:red_concrete
fill 94 172 288 94 177 288 minecraft:shroomlight
fill 94 172 289 94 173 290 minecraft:white_concrete
fill 94 172 291 94 173 292 minecraft:red_concrete
fill 94 172 293 94 173 294 minecraft:white_concrete
fill 94 172 295 94 173 295 minecraft:red_concrete
fill 94 172 296 94 177 296 minecraft:shroomlight
fill 94 172 297 94 173 298 minecraft:white_concrete
fill 94 172 299 94 173 300 minecraft:red_concrete
fill 94 172 301 94 173 302 minecraft:white_concrete
fill 94 172 303 94 173 303 minecraft:red_concrete
fill 94 172 304 94 177 304 minecraft:shroomlight
fill 94 172 305 94 173 306 minecraft:white_concrete
fill 94 172 307 94 173 308 minecraft:red_concrete
fill 94 172 309 94 173 310 minecraft:white_concrete
fill 94 172 311 94 173 311 minecraft:red_concrete
fill 94 172 312 94 177 312 minecraft:shroomlight
fill 94 172 313 94 173 314 minecraft:white_concrete
fill 94 172 315 94 173 316 minecraft:red_concrete
fill 95 172 275 95 173 275 minecraft:red_concrete
fill 95 172 317 95 173 317 minecraft:red_concrete
fill 96 172 275 97 173 275 minecraft:white_concrete
fill 96 172 317 96 173 317 minecraft:white_concrete
fill 97 172 317 97 177 317 minecraft:shroomlight
fill 98 172 275 99 173 275 minecraft:red_concrete
fill 98 172 317 99 173 317 minecraft:red_concrete
fill 100 172 275 100 173 275 minecraft:white_concrete
fill 100 172 317 101 173 317 minecraft:white_concrete
fill 101 172 275 101 177 275 minecraft:shroomlight
fill 102 172 275 103 173 275 minecraft:red_concrete
fill 102 172 317 103 173 317 minecraft:red_concrete
fill 104 172 275 105 173 275 minecraft:white_concrete
fill 104 172 317 104 173 317 minecraft:white_concrete
fill 105 172 317 105 177 317 minecraft:shroomlight
fill 106 172 275 107 173 275 minecraft:red_concrete
fill 106 172 317 107 173 317 minecraft:red_concrete
fill 108 172 275 108 173 275 minecraft:white_concrete
fill 108 172 317 109 173 317 minecraft:white_concrete
fill 109 172 275 109 177 275 minecraft:shroomlight
fill 110 172 275 111 173 275 minecraft:red_concrete
fill 110 172 317 111 173 317 minecraft:red_concrete
fill 112 172 275 113 173 275 minecraft:white_concrete
fill 112 172 317 112 173 317 minecraft:white_concrete
fill 113 172 317 113 177 317 minecraft:shroomlight
fill 114 172 275 115 173 275 minecraft:red_concrete
fill 114 172 317 115 173 317 minecraft:red_concrete
fill 116 172 275 116 173 275 minecraft:white_concrete
fill 116 172 317 117 173 317 minecraft:white_concrete
fill 117 172 275 117 177 275 minecraft:shroomlight
fill 118 172 275 119 173 275 minecraft:red_concrete
fill 118 172 317 119 173 317 minecraft:red_concrete
fill 120 172 275 121 173 275 minecraft:white_concrete
fill 120 172 317 120 173 317 minecraft:white_concrete
fill 121 172 317 121 177 317 minecraft:shroomlight
fill 122 172 275 123 173 275 minecraft:red_concrete
fill 122 172 317 123 173 317 minecraft:red_concrete
fill 124 172 275 124 173 275 minecraft:white_concrete
fill 124 172 317 125 173 317 minecraft:white_concrete
fill 125 172 275 125 177 275 minecraft:shroomlight
fill 126 172 275 127 173 275 minecraft:red_concrete
fill 126 172 317 127 173 317 minecraft:red_concrete
fill 128 172 275 129 173 275 minecraft:white_concrete
fill 128 172 317 128 173 317 minecraft:white_concrete
fill 129 172 317 129 177 317 minecraft:shroomlight
fill 130 172 275 131 173 275 minecraft:red_concrete
fill 130 172 317 131 173 317 minecraft:red_concrete
fill 132 172 275 132 173 275 minecraft:white_concrete
fill 132 172 317 133 173 317 minecraft:white_concrete
fill 133 172 275 133 177 275 minecraft:shroomlight
fill 134 172 275 135 173 275 minecraft:red_concrete
fill 134 172 317 135 173 317 minecraft:red_concrete
fill 136 172 276 136 173 276 minecraft:red_concrete
fill 136 172 277 136 173 278 minecraft:white_concrete
fill 136 172 279 136 173 279 minecraft:red_concrete
fill 136 172 280 136 177 280 minecraft:shroomlight
fill 136 172 281 136 173 282 minecraft:white_concrete
fill 136 172 283 136 173 284 minecraft:red_concrete
fill 136 172 285 136 173 286 minecraft:white_concrete
fill 136 172 287 136 173 287 minecraft:red_concrete
fill 136 172 288 136 177 288 minecraft:shroomlight
fill 136 172 289 136 173 290 minecraft:white_concrete
fill 136 172 291 136 173 292 minecraft:red_concrete
fill 136 172 293 136 173 294 minecraft:white_concrete
fill 136 172 295 136 173 295 minecraft:red_concrete
fill 136 172 296 136 177 296 minecraft:shroomlight
fill 136 172 297 136 173 298 minecraft:white_concrete
fill 136 172 299 136 173 300 minecraft:red_concrete
fill 136 172 301 136 173 302 minecraft:white_concrete
fill 136 172 303 136 173 303 minecraft:red_concrete
fill 136 172 304 136 177 304 minecraft:shroomlight
fill 136 172 305 136 173 306 minecraft:white_concrete
fill 136 172 307 136 173 308 minecraft:red_concrete
fill 136 172 309 136 173 310 minecraft:white_concrete
fill 136 172 311 136 173 311 minecraft:red_concrete
fill 136 172 312 136 177 312 minecraft:shroomlight
fill 136 172 313 136 173 314 minecraft:white_concrete
fill 136 172 315 136 173 316 minecraft:red_concrete
fill 136 172 317 136 173 317 minecraft:white_concrete
fill 110 173 277 110 181 277 minecraft:iron_block
fill 111 173 277 111 173 279 minecraft:red_terracotta
fill 112 173 277 113 173 277 minecraft:red_terracotta
fill 112 173 279 113 173 279 minecraft:red_terracotta
setblock 113 173 278 minecraft:red_terracotta
fill 94 174 275 94 175 276 minecraft:white_concrete
fill 94 174 277 94 175 278 minecraft:red_concrete
fill 94 174 279 94 175 279 minecraft:white_concrete
fill 94 174 281 94 175 282 minecraft:red_concrete
fill 94 174 283 94 175 284 minecraft:white_concrete
fill 94 174 285 94 175 286 minecraft:red_concrete
fill 94 174 287 94 175 287 minecraft:white_concrete
fill 94 174 289 94 175 290 minecraft:red_concrete
fill 94 174 291 94 175 292 minecraft:white_concrete
fill 94 174 293 94 175 294 minecraft:red_concrete
fill 94 174 295 94 175 295 minecraft:white_concrete
fill 94 174 297 94 175 298 minecraft:red_concrete
fill 94 174 299 94 175 300 minecraft:white_concrete
fill 94 174 301 94 175 302 minecraft:red_concrete
fill 94 174 303 94 175 303 minecraft:white_concrete
fill 94 174 305 94 175 306 minecraft:red_concrete
fill 94 174 307 94 175 308 minecraft:white_concrete
fill 94 174 309 94 175 310 minecraft:red_concrete
fill 94 174 311 94 175 311 minecraft:white_concrete
fill 94 174 313 94 175 314 minecraft:red_concrete
fill 94 174 315 94 175 316 minecraft:white_concrete
fill 95 174 275 95 175 275 minecraft:white_concrete
fill 95 174 317 95 175 317 minecraft:white_concrete
fill 96 174 275 97 175 275 minecraft:red_concrete
fill 96 174 317 96 175 317 minecraft:red_concrete
fill 98 174 275 99 175 275 minecraft:white_concrete
fill 98 174 317 99 175 317 minecraft:white_concrete
fill 100 174 275 100 175 275 minecraft:red_concrete
fill 100 174 317 101 175 317 minecraft:red_concrete
fill 102 174 275 103 175 275 minecraft:white_concrete
fill 102 174 317 103 175 317 minecraft:white_concrete
fill 104 174 275 105 175 275 minecraft:red_concrete
fill 104 174 317 104 175 317 minecraft:red_concrete
fill 106 174 275 107 175 275 minecraft:white_concrete
fill 106 174 317 107 175 317 minecraft:white_concrete
fill 108 174 275 108 175 275 minecraft:red_concrete
fill 108 174 317 109 175 317 minecraft:red_concrete
fill 110 174 275 111 175 275 minecraft:white_concrete
fill 110 174 317 111 175 317 minecraft:white_concrete
fill 111 174 277 111 177 279 minecraft:iron_block
fill 112 174 275 113 175 275 minecraft:red_concrete
fill 112 174 277 112 177 277 minecraft:iron_block
fill 112 174 279 112 177 279 minecraft:iron_block
fill 112 174 317 112 175 317 minecraft:red_concrete
fill 114 174 275 115 175 275 minecraft:white_concrete
fill 114 174 317 115 175 317 minecraft:white_concrete
fill 116 174 275 116 175 275 minecraft:red_concrete
fill 116 174 317 117 175 317 minecraft:red_concrete
fill 118 174 275 119 175 275 minecraft:white_concrete
fill 118 174 317 119 175 317 minecraft:white_concrete
fill 120 174 275 121 175 275 minecraft:red_concrete
fill 120 174 317 120 175 317 minecraft:red_concrete
fill 122 174 275 123 175 275 minecraft:white_concrete
fill 122 174 317 123 175 317 minecraft:white_concrete
fill 123 174 306 123 175 306 minecraft:yellow_wool
fill 124 174 275 124 175 275 minecraft:red_concrete
fill 124 174 317 125 175 317 minecraft:red_concrete
fill 126 174 275 127 175 275 minecraft:white_concrete
fill 126 174 317 127 175 317 minecraft:white_concrete
fill 128 174 275 129 175 275 minecraft:red_concrete
fill 128 174 317 128 175 317 minecraft:red_concrete
fill 130 174 275 131 175 275 minecraft:white_concrete
fill 130 174 317 131 175 317 minecraft:white_concrete
fill 132 174 275 132 175 275 minecraft:red_concrete
fill 132 174 317 133 175 317 minecraft:red_concrete
fill 134 174 275 135 175 275 minecraft:white_concrete
fill 134 174 317 135 175 317 minecraft:white_concrete
fill 136 174 276 136 175 276 minecraft:white_concrete
fill 136 174 277 136 175 278 minecraft:red_concrete
fill 136 174 279 136 175 279 minecraft:white_concrete
fill 136 174 281 136 175 282 minecraft:red_concrete
fill 136 174 283 136 175 284 minecraft:white_concrete
fill 136 174 285 136 175 286 minecraft:red_concrete
fill 136 174 287 136 175 287 minecraft:white_concrete
fill 136 174 289 136 175 290 minecraft:red_concrete
fill 136 174 291 136 175 292 minecraft:white_concrete
fill 136 174 293 136 175 294 minecraft:red_concrete
fill 136 174 295 136 175 295 minecraft:white_concrete
fill 136 174 297 136 175 298 minecraft:red_concrete
fill 136 174 299 136 175 300 minecraft:white_concrete
fill 136 174 301 136 175 302 minecraft:red_concrete
fill 136 174 303 136 175 303 minecraft:white_concrete
fill 136 174 305 136 175 306 minecraft:red_concrete
fill 136 174 307 136 175 308 minecraft:white_concrete
fill 136 174 309 136 175 310 minecraft:red_concrete
fill 136 174 311 136 175 311 minecraft:white_concrete
fill 136 174 313 136 175 314 minecraft:red_concrete
fill 136 174 315 136 175 316 minecraft:white_concrete
fill 136 174 317 136 175 317 minecraft:red_concrete
fill 105 175 309 109 176 313 minecraft:brown_terracotta
fill 107 175 314 107 175 315 minecraft:brown_terracotta
fill 109 175 277 109 175 279 minecraft:red_terracotta
fill 110 175 276 111 175 276 minecraft:red_terracotta
fill 110 175 280 112 175 280 minecraft:red_terracotta
fill 113 175 277 113 175 279 minecraft:red_terracotta
fill 131 175 297 131 175 299 minecraft:red_terracotta
setblock 131 175 306 minecraft:red_terracotta
setblock 131 175 308 minecraft:red_terracotta
fill 132 175 297 133 175 297 minecraft:red_terracotta
fill 132 175 299 133 175 299 minecraft:red_terracotta
setblock 133 175 298 minecraft:red_terracotta
setblock 133 175 306 minecraft:red_terracotta
setblock 133 175 308 minecraft:red_terracotta
fill 94 176 275 94 177 276 minecraft:red_concrete
fill 94 176 277 94 177 278 minecraft:white_concrete
fill 94 176 279 94 177 279 minecraft:red_concrete
fill 94 176 281 94 177 282 minecraft:white_concrete
fill 94 176 283 94 177 284 minecraft:red_concrete
fill 94 176 285 94 177 286 minecraft:white_concrete
fill 94 176 287 94 177 287 minecraft:red_concrete
fill 94 176 289 94 177 290 minecraft:white_concrete
fill 94 176 291 94 177 292 minecraft:red_concrete
fill 94 176 293 94 177 294 minecraft:white_concrete
fill 94 176 295 94 177 295 minecraft:red_concrete
fill 94 176 297 94 177 298 minecraft:white_concrete
fill 94 176 299 94 177 300 minecraft:red_concrete
fill 94 176 301 94 177 302 minecraft:white_concrete
fill 94 176 303 94 177 303 minecraft:red_concrete
fill 94 176 305 94 177 306 minecraft:white_concrete
fill 94 176 307 94 177 308 minecraft:red_concrete
fill 94 176 309 94 177 310 minecraft:white_concrete
fill 94 176 311 94 177 311 minecraft:red_concrete
fill 94 176 313 94 177 314 minecraft:white_concrete
fill 94 176 315 94 177 316 minecraft:red_concrete
fill 95 176 275 95 177 275 minecraft:red_concrete
fill 95 176 317 95 177 317 minecraft:red_concrete
fill 96 176 275 97 177 275 minecraft:white_concrete
fill 96 176 317 96 177 317 minecraft:white_concrete
setblock 97 176 278 minecraft:light[level=12]
setblock 97 176 285 minecraft:light[level=12]
setblock 97 176 292 minecraft:light[level=12]
setblock 97 176 299 minecraft:light[level=12]
setblock 97 176 306 minecraft:light[level=12]
setblock 97 176 313 minecraft:light[level=12]
fill 98 176 275 99 177 275 minecraft:red_concrete
fill 98 176 317 99 177 317 minecraft:red_concrete
fill 100 176 275 100 177 275 minecraft:white_concrete
fill 100 176 317 101 177 317 minecraft:white_concrete
fill 102 176 275 103 177 275 minecraft:red_concrete
fill 102 176 317 103 177 317 minecraft:red_concrete
fill 104 176 275 105 177 275 minecraft:white_concrete
setblock 104 176 278 minecraft:light[level=12]
setblock 104 176 285 minecraft:light[level=12]
setblock 104 176 292 minecraft:light[level=12]
setblock 104 176 299 minecraft:light[level=12]
setblock 104 176 306 minecraft:light[level=12]
setblock 104 176 313 minecraft:light[level=12]
fill 104 176 317 104 177 317 minecraft:white_concrete
fill 106 176 275 107 177 275 minecraft:red_concrete
fill 106 176 317 107 177 317 minecraft:red_concrete
fill 108 176 275 108 177 275 minecraft:white_concrete
fill 108 176 317 109 177 317 minecraft:white_concrete
fill 110 176 275 111 177 275 minecraft:red_concrete
fill 110 176 317 111 177 317 minecraft:red_concrete
setblock 111 176 285 minecraft:light[level=12]
setblock 111 176 292 minecraft:light[level=12]
setblock 111 176 299 minecraft:light[level=12]
setblock 111 176 306 minecraft:light[level=12]
setblock 111 176 313 minecraft:light[level=12]
fill 112 176 275 113 177 275 minecraft:white_concrete
fill 112 176 317 112 177 317 minecraft:white_concrete
fill 114 176 275 115 177 275 minecraft:red_concrete
fill 114 176 317 115 177 317 minecraft:red_concrete
fill 116 176 275 116 177 275 minecraft:white_concrete
fill 116 176 317 117 177 317 minecraft:white_concrete
fill 118 176 275 119 177 275 minecraft:red_concrete
setblock 118 176 278 minecraft:light[level=12]
setblock 118 176 285 minecraft:light[level=12]
setblock 118 176 299 minecraft:light[level=12]
setblock 118 176 306 minecraft:light[level=12]
setblock 118 176 313 minecraft:light[level=12]
fill 118 176 317 119 177 317 minecraft:red_concrete
fill 120 176 275 121 177 275 minecraft:white_concrete
fill 120 176 317 120 177 317 minecraft:white_concrete
fill 122 176 275 123 177 275 minecraft:red_concrete
fill 122 176 317 123 177 317 minecraft:red_concrete
fill 124 176 275 124 177 275 minecraft:white_concrete
fill 124 176 317 125 177 317 minecraft:white_concrete
setblock 125 176 285 minecraft:light[level=12]
setblock 125 176 292 minecraft:light[level=12]
setblock 125 176 299 minecraft:light[level=12]
setblock 125 176 306 minecraft:light[level=12]
setblock 125 176 313 minecraft:light[level=12]
fill 126 176 275 127 177 275 minecraft:red_concrete
fill 126 176 317 127 177 317 minecraft:red_concrete
fill 128 176 275 129 177 275 minecraft:white_concrete
fill 128 176 317 128 177 317 minecraft:white_concrete
fill 130 176 275 131 177 275 minecraft:red_concrete
fill 130 176 317 131 177 317 minecraft:red_concrete
fill 132 176 275 132 177 275 minecraft:white_concrete
setblock 132 176 278 minecraft:light[level=12]
setblock 132 176 285 minecraft:light[level=12]
setblock 132 176 292 minecraft:light[level=12]
setblock 132 176 299 minecraft:light[level=12]
setblock 132 176 313 minecraft:light[level=12]
fill 132 176 317 133 177 317 minecraft:white_concrete
fill 134 176 275 135 177 275 minecraft:red_concrete
fill 134 176 317 135 177 317 minecraft:red_concrete
fill 136 176 276 136 177 276 minecraft:red_concrete
fill 136 176 277 136 177 278 minecraft:white_concrete
fill 136 176 279 136 177 279 minecraft:red_concrete
fill 136 176 281 136 177 282 minecraft:white_concrete
fill 136 176 283 136 177 284 minecraft:red_concrete
fill 136 176 285 136 177 286 minecraft:white_concrete
fill 136 176 287 136 177 287 minecraft:red_concrete
fill 136 176 289 136 177 290 minecraft:white_concrete
fill 136 176 291 136 177 292 minecraft:red_concrete
fill 136 176 293 136 177 294 minecraft:white_concrete
fill 136 176 295 136 177 295 minecraft:red_concrete
fill 136 176 297 136 177 298 minecraft:white_concrete
fill 136 176 299 136 177 300 minecraft:red_concrete
fill 136 176 301 136 177 302 minecraft:white_concrete
fill 136 176 303 136 177 303 minecraft:red_concrete
fill 136 176 305 136 177 306 minecraft:white_concrete
fill 136 176 307 136 177 308 minecraft:red_concrete
fill 136 176 309 136 177 310 minecraft:white_concrete
fill 136 176 311 136 177 311 minecraft:red_concrete
fill 136 176 313 136 177 314 minecraft:white_concrete
fill 136 176 315 136 177 316 minecraft:red_concrete
fill 136 176 317 136 177 317 minecraft:white_concrete
fill 107 177 311 107 180 311 minecraft:red_terracotta
fill 94 178 275 94 179 276 minecraft:white_concrete
fill 94 178 277 94 179 278 minecraft:red_concrete
fill 94 178 279 94 179 280 minecraft:white_concrete
fill 94 178 281 94 179 282 minecraft:red_concrete
fill 94 178 283 94 179 284 minecraft:white_concrete
fill 94 178 285 94 179 286 minecraft:red_concrete
fill 94 178 287 94 179 288 minecraft:white_concrete
fill 94 178 289 94 179 290 minecraft:red_concrete
fill 94 178 291 94 179 292 minecraft:white_concrete
fill 94 178 293 94 179 294 minecraft:red_concrete
fill 94 178 295 94 179 296 minecraft:white_concrete
fill 94 178 297 94 179 298 minecraft:red_concrete
fill 94 178 299 94 179 300 minecraft:white_concrete
fill 94 178 301 94 179 302 minecraft:red_concrete
fill 94 178 303 94 179 304 minecraft:white_concrete
fill 94 178 305 94 179 306 minecraft:red_concrete
fill 94 178 307 94 179 308 minecraft:white_concrete
fill 94 178 309 94 179 310 minecraft:red_concrete
fill 94 178 311 94 179 312 minecraft:white_concrete
fill 94 178 313 94 179 314 minecraft:red_concrete
fill 94 178 315 94 179 316 minecraft:white_concrete
fill 95 178 275 95 179 275 minecraft:white_concrete
fill 95 178 317 95 179 317 minecraft:white_concrete
fill 96 178 275 97 179 275 minecraft:red_concrete
fill 96 178 317 97 179 317 minecraft:red_concrete
setblock 97 178 278 minecraft:light[level=15]
setblock 97 178 286 minecraft:light[level=15]
setblock 97 178 294 minecraft:light[level=15]
setblock 97 178 302 minecraft:light[level=15]
setblock 97 178 310 minecraft:light[level=15]
fill 98 178 275 99 179 275 minecraft:white_concrete
fill 98 178 317 99 179 317 minecraft:white_concrete
fill 100 178 275 101 179 275 minecraft:red_concrete
fill 100 178 317 101 179 317 minecraft:red_concrete
fill 102 178 275 103 179 275 minecraft:white_concrete
fill 102 178 317 103 179 317 minecraft:white_concrete
fill 104 178 275 105 179 275 minecraft:red_concrete
fill 104 178 317 105 179 317 minecraft:red_concrete
setblock 105 178 278 minecraft:light[level=15]
setblock 105 178 286 minecraft:light[level=15]
setblock 105 178 294 minecraft:light[level=15]
setblock 105 178 302 minecraft:light[level=15]
setblock 105 178 310 minecraft:light[level=15]
fill 106 178 275 107 179 275 minecraft:white_concrete
fill 106 178 317 107 179 317 minecraft:white_concrete
fill 108 178 275 109 179 275 minecraft:red_concrete
fill 108 178 317 109 179 317 minecraft:red_concrete
fill 110 178 275 111 179 275 minecraft:white_concrete
fill 110 178 317 111 179 317 minecraft:white_concrete
fill 111 178 277 111 178 279 minecraft:red_terracotta
fill 112 178 275 113 179 275 minecraft:red_concrete
fill 112 178 277 113 178 277 minecraft:red_terracotta
fill 112 178 279 113 178 279 minecraft:red_terracotta
fill 112 178 317 113 179 317 minecraft:red_concrete
setblock 113 178 278 minecraft:red_terracotta
setblock 113 178 286 minecraft:light[level=15]
setblock 113 178 294 minecraft:light[level=15]
setblock 113 178 302 minecraft:light[level=15]
setblock 113 178 310 minecraft:light[level=15]
fill 114 178 275 115 179 275 minecraft:white_concrete
fill 114 178 317 115 179 317 minecraft:white_concrete
fill 116 178 275 117 179 275 minecraft:red_concrete
fill 116 178 317 117 179 317 minecraft:red_concrete
fill 118 178 275 119 179 275 minecraft:white_concrete
fill 118 178 317 119 179 317 minecraft:white_concrete
fill 120 178 275 121 179 275 minecraft:red_concrete
fill 120 178 317 121 179 317 minecraft:red_concrete
setblock 121 178 278 minecraft:light[level=15]
setblock 121 178 286 minecraft:light[level=15]
setblock 121 178 294 minecraft:light[level=15]
setblock 121 178 302 minecraft:light[level=15]
setblock 121 178 310 minecraft:light[level=15]
fill 122 178 275 123 179 275 minecraft:white_concrete
fill 122 178 317 123 179 317 minecraft:white_concrete
fill 124 178 275 125 179 275 minecraft:red_concrete
fill 124 178 317 125 179 317 minecraft:red_concrete
fill 126 178 275 127 179 275 minecraft:white_concrete
fill 126 178 317 127 179 317 minecraft:white_concrete
fill 128 178 275 129 179 275 minecraft:red_concrete
fill 128 178 317 129 179 317 minecraft:red_concrete
setblock 129 178 278 minecraft:light[level=15]
setblock 129 178 286 minecraft:light[level=15]
setblock 129 178 294 minecraft:light[level=15]
setblock 129 178 302 minecraft:light[level=15]
setblock 129 178 310 minecraft:light[level=15]
fill 130 178 275 131 179 275 minecraft:white_concrete
fill 130 178 317 131 179 317 minecraft:white_concrete
fill 132 178 275 133 179 275 minecraft:red_concrete
fill 132 178 317 133 179 317 minecraft:red_concrete
fill 134 178 275 135 179 275 minecraft:white_concrete
fill 134 178 317 135 179 317 minecraft:white_concrete
fill 136 178 276 136 179 276 minecraft:white_concrete
fill 136 178 277 136 179 278 minecraft:red_concrete
fill 136 178 279 136 179 280 minecraft:white_concrete
fill 136 178 281 136 179 282 minecraft:red_concrete
fill 136 178 283 136 179 284 minecraft:white_concrete
fill 136 178 285 136 179 286 minecraft:red_concrete
fill 136 178 287 136 179 288 minecraft:white_concrete
fill 136 178 289 136 179 290 minecraft:red_concrete
fill 136 178 291 136 179 292 minecraft:white_concrete
fill 136 178 293 136 179 294 minecraft:red_concrete
fill 136 178 295 136 179 296 minecraft:white_concrete
fill 136 178 297 136 179 298 minecraft:red_concrete
fill 136 178 299 136 179 300 minecraft:white_concrete
fill 136 178 301 136 179 302 minecraft:red_concrete
fill 136 178 303 136 179 304 minecraft:white_concrete
fill 136 178 305 136 179 306 minecraft:red_concrete
fill 136 178 307 136 179 308 minecraft:white_concrete
fill 136 178 309 136 179 310 minecraft:red_concrete
fill 136 178 311 136 179 312 minecraft:white_concrete
fill 136 178 313 136 179 314 minecraft:red_concrete
fill 136 178 315 136 179 316 minecraft:white_concrete
fill 136 178 317 136 179 317 minecraft:red_concrete
fill 111 179 277 111 181 279 minecraft:iron_block
fill 112 179 277 112 181 277 minecraft:iron_block
fill 112 179 279 112 182 279 minecraft:iron_block
fill 94 180 275 94 181 276 minecraft:red_concrete
fill 94 180 277 94 181 278 minecraft:white_concrete
fill 94 180 279 94 181 280 minecraft:red_concrete
fill 94 180 281 94 181 282 minecraft:white_concrete
fill 94 180 283 94 181 284 minecraft:red_concrete
fill 94 180 285 94 181 286 minecraft:white_concrete
fill 94 180 287 94 181 288 minecraft:red_concrete
fill 94 180 289 94 181 290 minecraft:white_concrete
fill 94 180 291 94 181 292 minecraft:red_concrete
fill 94 180 293 94 181 294 minecraft:white_concrete
fill 94 180 295 94 181 296 minecraft:red_concrete
fill 94 180 297 94 181 298 minecraft:white_concrete
fill 94 180 299 94 181 300 minecraft:red_concrete
fill 94 180 301 94 181 302 minecraft:white_concrete
fill 94 180 303 94 181 304 minecraft:red_concrete
fill 94 180 305 94 181 306 minecraft:white_concrete
fill 94 180 307 94 181 308 minecraft:red_concrete
fill 94 180 309 94 181 310 minecraft:white_concrete
fill 94 180 311 94 181 312 minecraft:red_concrete
fill 94 180 313 94 181 314 minecraft:white_concrete
fill 94 180 315 94 181 316 minecraft:red_concrete
fill 95 180 275 95 181 275 minecraft:red_concrete
fill 95 180 317 95 181 317 minecraft:red_concrete
fill 96 180 275 97 181 275 minecraft:white_concrete
fill 96 180 317 97 181 317 minecraft:white_concrete
fill 98 180 275 99 181 275 minecraft:red_concrete
fill 98 180 317 99 181 317 minecraft:red_concrete
fill 100 180 275 101 181 275 minecraft:white_concrete
fill 100 180 317 101 181 317 minecraft:white_concrete
fill 102 180 275 103 181 275 minecraft:red_concrete
fill 102 180 317 103 181 317 minecraft:red_concrete
fill 104 180 275 105 181 275 minecraft:white_concrete
fill 104 180 317 105 181 317 minecraft:white_concrete
fill 106 180 275 107 181 275 minecraft:red_concrete
fill 106 180 317 107 181 317 minecraft:red_concrete
fill 108 180 275 109 181 275 minecraft:white_concrete
fill 108 180 317 109 181 317 minecraft:white_concrete
fill 110 180 275 111 181 275 minecraft:red_concrete
fill 110 180 317 111 181 317 minecraft:red_concrete
fill 112 180 275 113 181 275 minecraft:white_concrete
fill 112 180 317 113 181 317 minecraft:white_concrete
fill 114 180 275 115 181 275 minecraft:red_concrete
fill 114 180 317 115 181 317 minecraft:red_concrete
fill 115 180 309 119 181 313 minecraft:brown_terracotta
fill 116 180 275 117 181 275 minecraft:white_concrete
fill 116 180 317 117 181 317 minecraft:white_concrete
fill 117 180 314 117 180 315 minecraft:brown_terracotta
fill 118 180 275 119 181 275 minecraft:red_concrete
fill 118 180 317 119 181 317 minecraft:red_concrete
fill 120 180 275 121 181 275 minecraft:white_concrete
fill 120 180 317 121 181 317 minecraft:white_concrete
fill 122 180 275 123 181 275 minecraft:red_concrete
fill 122 180 317 123 181 317 minecraft:red_concrete
fill 124 180 275 125 181 275 minecraft:white_concrete
fill 124 180 317 125 181 317 minecraft:white_concrete
fill 126 180 275 127 181 275 minecraft:red_concrete
fill 126 180 317 127 181 317 minecraft:red_concrete
fill 128 180 275 129 181 275 minecraft:white_concrete
fill 128 180 317 129 181 317 minecraft:white_concrete
fill 130 180 275 131 181 275 minecraft:red_concrete
fill 130 180 317 131 181 317 minecraft:red_concrete
fill 132 180 275 133 181 275 minecraft:white_concrete
fill 132 180 317 133 181 317 minecraft:white_concrete
fill 134 180 275 135 181 275 minecraft:red_concrete
fill 134 180 317 135 181 317 minecraft:red_concrete
fill 136 180 276 136 181 276 minecraft:red_concrete
fill 136 180 277 136 181 278 minecraft:white_concrete
fill 136 180 279 136 181 280 minecraft:red_concrete
fill 136 180 281 136 181 282 minecraft:white_concrete
fill 136 180 283 136 181 284 minecraft:red_concrete
fill 136 180 285 136 181 286 minecraft:white_concrete
fill 136 180 287 136 181 288 minecraft:red_concrete
fill 136 180 289 136 181 290 minecraft:white_concrete
fill 136 180 291 136 181 292 minecraft:red_concrete
fill 136 180 293 136 181 294 minecraft:white_concrete
fill 136 180 295 136 181 296 minecraft:red_concrete
fill 136 180 297 136 181 298 minecraft:white_concrete
fill 136 180 299 136 181 300 minecraft:red_concrete
fill 136 180 301 136 181 302 minecraft:white_concrete
fill 136 180 303 136 181 304 minecraft:red_concrete
fill 136 180 305 136 181 306 minecraft:white_concrete
fill 136 180 307 136 181 308 minecraft:red_concrete
fill 136 180 309 136 181 310 minecraft:white_concrete
fill 136 180 311 136 181 312 minecraft:red_concrete
fill 136 180 313 136 181 314 minecraft:white_concrete
fill 136 180 315 136 181 316 minecraft:red_concrete
fill 136 180 317 136 181 317 minecraft:white_concrete
fill 96 181 300 97 181 301 minecraft:brown_terracotta
fill 105 181 311 109 184 311 minecraft:yellow_concrete
fill 106 181 310 108 184 310 minecraft:yellow_concrete
fill 106 181 312 108 184 312 minecraft:yellow_concrete
fill 107 181 309 107 184 309 minecraft:yellow_concrete
fill 107 181 313 107 184 313 minecraft:yellow_concrete
fill 109 181 277 109 181 279 minecraft:red_terracotta
fill 110 181 276 111 183 276 minecraft:red_terracotta
fill 110 181 280 112 181 280 minecraft:red_terracotta
fill 113 181 277 113 181 279 minecraft:red_terracotta
fill 131 181 297 131 181 299 minecraft:red_terracotta
setblock 131 181 306 minecraft:red_terracotta
setblock 131 181 308 minecraft:red_terracotta
fill 132 181 297 133 181 297 minecraft:red_terracotta
fill 132 181 299 133 181 299 minecraft:red_terracotta
setblock 133 181 298 minecraft:red_terracotta
setblock 133 181 306 minecraft:red_terracotta
setblock 133 181 308 minecraft:red_terracotta
fill 94 182 275 94 183 276 minecraft:white_concrete
fill 94 182 277 94 183 278 minecraft:red_concrete
fill 94 182 279 94 183 280 minecraft:white_concrete
fill 94 182 281 94 183 282 minecraft:red_concrete
fill 94 182 283 94 183 284 minecraft:white_concrete
fill 94 182 285 94 183 286 minecraft:red_concrete
fill 94 182 287 94 183 288 minecraft:white_concrete
fill 94 182 289 94 183 290 minecraft:red_concrete
fill 94 182 291 94 183 292 minecraft:white_concrete
fill 94 182 293 94 183 294 minecraft:red_concrete
fill 94 182 295 94 183 296 minecraft:white_concrete
fill 94 182 297 94 183 298 minecraft:red_concrete
fill 94 182 299 94 183 300 minecraft:white_concrete
fill 94 182 301 94 183 302 minecraft:red_concrete
fill 94 182 303 94 183 304 minecraft:white_concrete
fill 94 182 305 94 183 306 minecraft:red_concrete
fill 94 182 307 94 183 308 minecraft:white_concrete
fill 94 182 309 94 183 310 minecraft:red_concrete
fill 94 182 311 94 183 312 minecraft:white_concrete
fill 94 182 313 94 183 314 minecraft:red_concrete
fill 94 182 315 94 183 316 minecraft:white_concrete
fill 95 182 275 95 183 275 minecraft:white_concrete
fill 95 182 276 95 183 281 minecraft:red_terracotta
fill 95 182 284 96 182 289 minecraft:red_terracotta
fill 95 182 292 96 182 297 minecraft:red_terracotta
fill 95 182 300 96 182 305 minecraft:red_terracotta
fill 95 182 308 96 182 313 minecraft:red_terracotta
fill 95 182 316 100 183 316 minecraft:red_terracotta
fill 95 182 317 95 183 317 minecraft:white_concrete
fill 96 182 275 97 183 275 minecraft:red_concrete
fill 96 182 277 96 182 283 minecraft:red_terracotta
fill 96 182 290 96 182 291 minecraft:red_terracotta
fill 96 182 298 96 182 299 minecraft:red_terracotta
fill 96 182 306 96 182 307 minecraft:red_terracotta
fill 96 182 314 96 182 315 minecraft:red_terracotta
fill 96 182 317 97 183 317 minecraft:red_concrete
fill 97 182 277 134 182 277 minecraft:red_terracotta
setblock 97 182 278 minecraft:light[level=12]
setblock 97 182 285 minecraft:light[level=12]
setblock 97 182 292 minecraft:light[level=12]
setblock 97 182 299 minecraft:light[level=12]
fill 97 182 300 97 182 301 minecraft:brown_terracotta
setblock 97 182 306 minecraft:light[level=12]
setblock 97 182 313 minecraft:light[level=12]
fill 97 182 315 135 182 315 minecraft:red_terracotta
fill 98 182 275 99 183 275 minecraft:white_concrete
fill 98 182 276 103 183 276 minecraft:red_terracotta
fill 98 182 317 99 183 317 minecraft:white_concrete
fill 100 182 275 101 183 275 minecraft:red_concrete
fill 100 182 317 101 183 317 minecraft:red_concrete
fill 102 182 275 103 183 275 minecraft:white_concrete
fill 102 182 317 103 183 317 minecraft:white_concrete
fill 103 182 316 108 183 316 minecraft:red_terracotta
fill 104 182 275 105 183 275 minecraft:red_concrete
setblock 104 182 278 minecraft:light[level=12]
setblock 104 182 285 minecraft:light[level=12]
setblock 104 182 292 minecraft:light[level=12]
setblock 104 182 299 minecraft:light[level=12]
setblock 104 182 306 minecraft:light[level=12]
setblock 104 182 313 minecraft:light[level=12]
fill 104 182 317 105 183 317 minecraft:red_concrete
fill 105 182 310 105 183 310 minecraft:yellow_concrete
fill 105 182 312 105 183 312 minecraft:yellow_concrete
fill 106 182 275 107 183 275 minecraft:white_concrete
fill 106 182 276 109 183 276 minecraft:red_terracotta
fill 106 182 309 106 183 309 minecraft:yellow_concrete
fill 106 182 313 106 183 313 minecraft:yellow_concrete
fill 106 182 317 107 183 317 minecraft:white_concrete
fill 108 182 275 109 183 275 minecraft:red_concrete
fill 108 182 309 108 183 309 minecraft:yellow_concrete
fill 108 182 313 108 183 313 minecraft:yellow_concrete
fill 108 182 317 109 183 317 minecraft:red_concrete
fill 109 182 310 109 183 310 minecraft:yellow_concrete
fill 109 182 312 109 183 312 minecraft:yellow_concrete
fill 110 182 275 111 183 275 minecraft:white_concrete
fill 110 182 317 111 183 317 minecraft:white_concrete
fill 111 182 278 111 182 279 minecraft:iron_block
setblock 111 182 285 minecraft:light[level=12]
setblock 111 182 292 minecraft:light[level=12]
setblock 111 182 299 minecraft:light[level=12]
setblock 111 182 306 minecraft:light[level=12]
setblock 111 182 313 minecraft:light[level=12]
fill 111 182 316 116 183 316 minecraft:red_terracotta
fill 112 182 275 113 183 275 minecraft:red_concrete
fill 112 182 317 113 183 317 minecraft:red_concrete
fill 114 182 275 115 183 275 minecraft:white_concrete
fill 114 182 276 119 183 276 minecraft:red_terracotta
fill 114 182 317 115 183 317 minecraft:white_concrete
fill 116 182 275 117 183 275 minecraft:red_concrete
fill 116 182 317 117 183 317 minecraft:red_concrete
fill 117 182 311 117 185 311 minecraft:red_terracotta
fill 118 182 275 119 183 275 minecraft:white_concrete
setblock 118 182 278 minecraft:light[level=12]
setblock 118 182 285 minecraft:light[level=12]
setblock 118 182 299 minecraft:light[level=12]
setblock 118 182 306 minecraft:light[level=12]
setblock 118 182 313 minecraft:light[level=12]
fill 118 182 317 119 183 317 minecraft:white_concrete
fill 119 182 316 124 183 316 minecraft:red_terracotta
fill 120 182 275 121 183 275 minecraft:red_concrete
fill 120 182 317 121 183 317 minecraft:red_concrete
fill 122 182 275 123 183 275 minecraft:white_concrete
fill 122 182 276 127 183 276 minecraft:red_terracotta
fill 122 182 317 123 183 317 minecraft:white_concrete
fill 124 182 275 125 183 275 minecraft:red_concrete
fill 124 182 317 125 183 317 minecraft:red_concrete
setblock 125 182 285 minecraft:light[level=12]
setblock 125 182 292 minecraft:light[level=12]
setblock 125 182 299 minecraft:light[level=12]
setblock 125 182 306 minecraft:light[level=12]
setblock 125 182 313 minecraft:light[level=12]
fill 126 182 275 127 183 275 minecraft:white_concrete
fill 126 182 317 127 183 317 minecraft:white_concrete
fill 127 182 316 132 183 316 minecraft:red_terracotta
fill 128 182 275 129 183 275 minecraft:red_concrete
fill 128 182 317 129 183 317 minecraft:red_concrete
fill 130 182 275 131 183 275 minecraft:white_concrete
fill 130 182 276 135 183 276 minecraft:red_terracotta
fill 130 182 317 131 183 317 minecraft:white_concrete
fill 132 182 275 133 183 275 minecraft:red_concrete
setblock 132 182 278 minecraft:light[level=12]
setblock 132 182 285 minecraft:light[level=12]
setblock 132 182 292 minecraft:light[level=12]
setblock 132 182 299 minecraft:light[level=12]
setblock 132 182 313 minecraft:light[level=12]
fill 132 182 317 133 183 317 minecraft:red_concrete
fill 134 182 275 135 183 275 minecraft:white_concrete
fill 134 182 278 134 182 314 minecraft:red_terracotta
fill 134 182 317 135 183 317 minecraft:white_concrete
fill 135 182 279 135 183 284 minecraft:red_terracotta
fill 135 182 287 135 183 292 minecraft:red_terracotta
fill 135 182 295 135 183 300 minecraft:red_terracotta
fill 135 182 303 135 183 308 minecraft:red_terracotta
fill 135 182 311 135 183 314 minecraft:red_terracotta
fill 135 182 316 135 183 316 minecraft:red_terracotta
fill 136 182 276 136 183 276 minecraft:white_concrete
fill 136 182 277 136 183 278 minecraft:red_concrete
fill 136 182 279 136 183 280 minecraft:white_concrete
fill 136 182 281 136 183 282 minecraft:red_concrete
fill 136 182 283 136 183 284 minecraft:white_concrete
fill 136 182 285 136 183 286 minecraft:red_concrete
fill 136 182 287 136 183 288 minecraft:white_concrete
fill 136 182 289 136 183 290 minecraft:red_concrete
fill 136 182 291 136 183 292 minecraft:white_concrete
fill 136 182 293 136 183 294 minecraft:red_concrete
fill 136 182 295 136 183 296 minecraft:white_concrete
fill 136 182 297 136 183 298 minecraft:red_concrete
fill 136 182 299 136 183 300 minecraft:white_concrete
fill 136 182 301 136 183 302 minecraft:red_concrete
fill 136 182 303 136 183 304 minecraft:white_concrete
fill 136 182 305 136 183 306 minecraft:red_concrete
fill 136 182 307 136 183 308 minecraft:white_concrete
fill 136 182 309 136 183 310 minecraft:red_concrete
fill 136 182 311 136 183 312 minecraft:white_concrete
fill 136 182 313 136 183 314 minecraft:red_concrete
fill 136 182 315 136 183 316 minecraft:white_concrete
fill 136 182 317 136 183 317 minecraft:red_concrete
fill 95 183 284 95 183 289 minecraft:red_terracotta
fill 95 183 292 95 183 297 minecraft:red_terracotta
fill 95 183 300 95 183 305 minecraft:red_terracotta
fill 95 183 308 95 183 313 minecraft:red_terracotta
fill 101 183 293 101 184 293 minecraft:red_concrete
fill 110 183 277 110 195 277 minecraft:iron_block
fill 111 183 277 111 183 279 minecraft:red_terracotta
fill 112 183 277 113 183 277 minecraft:red_terracotta
fill 112 183 279 113 183 279 minecraft:red_terracotta
setblock 113 183 278 minecraft:red_terracotta
fill 114 183 277 114 184 278 minecraft:red_concrete
setblock 135 183 315 minecraft:red_terracotta
fill 94 184 275 94 185 276 minecraft:red_concrete
fill 94 184 277 94 185 278 minecraft:white_concrete
fill 94 184 279 94 185 280 minecraft:red_concrete
fill 94 184 281 94 185 282 minecraft:white_concrete
fill 94 184 283 94 185 284 minecraft:red_concrete
fill 94 184 285 94 185 286 minecraft:white_concrete
fill 94 184 287 94 185 288 minecraft:red_concrete
fill 94 184 289 94 185 290 minecraft:white_concrete
fill 94 184 291 94 185 292 minecraft:red_concrete
fill 94 184 293 94 185 294 minecraft:white_concrete
fill 94 184 295 94 185 296 minecraft:red_concrete
fill 94 184 297 94 185 298 minecraft:white_concrete
fill 94 184 299 94 185 300 minecraft:red_concrete
fill 94 184 301 94 185 302 minecraft:white_concrete
fill 94 184 303 94 185 304 minecraft:red_concrete
fill 94 184 305 94 185 306 minecraft:white_concrete
fill 94 184 307 94 185 308 minecraft:red_concrete
fill 94 184 309 94 185 310 minecraft:white_concrete
fill 94 184 311 94 185 312 minecraft:red_concrete
fill 94 184 313 94 185 314 minecraft:white_concrete
fill 94 184 315 94 185 316 minecraft:red_concrete
fill 95 184 275 95 185 275 minecraft:red_concrete
fill 95 184 317 95 185 317 minecraft:red_concrete
fill 96 184 275 97 185 275 minecraft:white_concrete
fill 96 184 317 97 185 317 minecraft:white_concrete
fill 98 184 275 99 185 275 minecraft:red_concrete
fill 98 184 317 99 185 317 minecraft:red_concrete
fill 100 184 275 101 185 275 minecraft:white_concrete
fill 100 184 317 101 185 317 minecraft:white_concrete
fill 102 184 275 103 185 275 minecraft:red_concrete
fill 102 184 317 103 185 317 minecraft:red_concrete
fill 104 184 275 105 185 275 minecraft:white_concrete
fill 104 184 317 105 185 317 minecraft:white_concrete
fill 106 184 275 107 185 275 minecraft:red_concrete
fill 106 184 317 107 185 317 minecraft:red_concrete
fill 108 184 275 109 185 275 minecraft:white_concrete
fill 108 184 317 109 185 317 minecraft:white_concrete
fill 110 184 275 111 185 275 minecraft:red_concrete
fill 110 184 317 111 185 317 minecraft:red_concrete
fill 111 184 277 111 187 279 minecraft:iron_block
fill 112 184 275 113 185 275 minecraft:white_concrete
fill 112 184 277 112 187 277 minecraft:iron_block
fill 112 184 279 112 187 279 minecraft:iron_block
fill 112 184 317 113 185 317 minecraft:white_concrete
fill 113 184 277 113 184 278 minecraft:red_concrete
fill 114 184 275 115 185 275 minecraft:red_concrete
fill 114 184 317 115 185 317 minecraft:red_concrete
fill 116 184 275 117 185 275 minecraft:white_concrete
fill 116 184 317 117 185 317 minecraft:white_concrete
fill 118 184 275 119 185 275 minecraft:red_concrete
fill 118 184 317 119 185 317 minecraft:red_concrete
fill 120 184 275 121 185 275 minecraft:white_concrete
fill 120 184 317 121 185 317 minecraft:white_concrete
fill 122 184 275 123 185 275 minecraft:red_concrete
fill 122 184 317 123 185 317 minecraft:red_concrete
fill 124 184 275 125 185 275 minecraft:white_concrete
fill 124 184 317 125 185 317 minecraft:white_concrete
fill 126 184 275 127 185 275 minecraft:red_concrete
fill 126 184 317 127 185 317 minecraft:red_concrete
fill 128 184 275 129 185 275 minecraft:white_concrete
fill 128 184 317 129 185 317 minecraft:white_concrete
fill 130 184 275 131 185 275 minecraft:red_concrete
fill 130 184 317 131 185 317 minecraft:red_concrete
fill 132 184 275 133 185 275 minecraft:white_concrete
fill 132 184 317 133 185 317 minecraft:white_concrete
fill 134 184 275 135 185 275 minecraft:red_concrete
fill 134 184 317 135 185 317 minecraft:red_concrete
fill 136 184 276 136 185 276 minecraft:red_concrete
fill 136 184 277 136 185 278 minecraft:white_concrete
fill 136 184 279 136 185 280 minecraft:red_concrete
fill 136 184 281 136 185 282 minecraft:white_concrete
fill 136 184 283 136 185 284 minecraft:red_concrete
fill 136 184 285 136 185 286 minecraft:white_concrete
fill 136 184 287 136 185 288 minecraft:red_concrete
fill 136 184 289 136 185 290 minecraft:white_concrete
fill 136 184 291 136 185 292 minecraft:red_concrete
fill 136 184 293 136 185 294 minecraft:white_concrete
fill 136 184 295 136 185 296 minecraft:red_concrete
fill 136 184 297 136 185 298 minecraft:white_concrete
fill 136 184 299 136 185 300 minecraft:red_concrete
fill 136 184 301 136 185 302 minecraft:white_concrete
fill 136 184 303 136 185 304 minecraft:red_concrete
fill 136 184 305 136 185 306 minecraft:white_concrete
fill 136 184 307 136 185 308 minecraft:red_concrete
fill 136 184 309 136 185 310 minecraft:white_concrete
fill 136 184 311 136 185 312 minecraft:red_concrete
fill 136 184 313 136 185 314 minecraft:white_concrete
fill 136 184 315 136 185 316 minecraft:red_concrete
fill 136 184 317 136 185 317 minecraft:white_concrete
setblock 107 185 311 minecraft:yellow_concrete
fill 94 186 275 94 187 276 minecraft:white_concrete
fill 94 186 277 94 187 278 minecraft:red_concrete
fill 94 186 279 94 187 279 minecraft:white_concrete
fill 94 186 280 94 191 280 minecraft:shroomlight
fill 94 186 281 94 187 282 minecraft:red_concrete
fill 94 186 283 94 187 284 minecraft:white_concrete
fill 94 186 285 94 187 286 minecraft:red_concrete
fill 94 186 287 94 187 287 minecraft:white_concrete
fill 94 186 288 94 191 288 minecraft:shroomlight
fill 94 186 289 94 187 290 minecraft:red_concrete
fill 94 186 291 94 187 292 minecraft:white_concrete
fill 94 186 293 94 187 294 minecraft:red_concrete
fill 94 186 295 94 187 295 minecraft:white_concrete
fill 94 186 296 94 191 296 minecraft:shroomlight
fill 94 186 297 94 187 298 minecraft:red_concrete
fill 94 186 299 94 187 300 minecraft:white_concrete
fill 94 186 301 94 187 302 minecraft:red_concrete
fill 94 186 303 94 187 303 minecraft:white_concrete
fill 94 186 304 94 191 304 minecraft:shroomlight
fill 94 186 305 94 187 306 minecraft:red_concrete
fill 94 186 307 94 187 308 minecraft:white_concrete
fill 94 186 309 94 187 310 minecraft:red_concrete
fill 94 186 311 94 187 311 minecraft:white_concrete
fill 94 186 312 94 191 312 minecraft:shroomlight
fill 94 186 313 94 187 314 minecraft:red_concrete
fill 94 186 315 94 187 316 minecraft:white_concrete
fill 95 186 275 95 187 275 minecraft:white_concrete
fill 95 186 317 95 187 317 minecraft:white_concrete
fill 96 186 275 97 187 275 minecraft:red_concrete
fill 96 186 317 96 187 317 minecraft:red_concrete
setblock 97 186 278 minecraft:light[level=15]
setblock 97 186 286 minecraft:light[level=15]
setblock 97 186 294 minecraft:light[level=15]
setblock 97 186 302 minecraft:light[level=15]
setblock 97 186 310 minecraft:light[level=15]
fill 97 186 317 97 191 317 minecraft:shroomlight
fill 98 186 275 99 187 275 minecraft:white_concrete
fill 98 186 317 99 187 317 minecraft:white_concrete
fill 100 186 275 100 187 275 minecraft:red_concrete
fill 100 186 317 101 187 317 minecraft:red_concrete
fill 101 186 275 101 191 275 minecraft:shroomlight
fill 102 186 275 103 187 275 minecraft:white_concrete
fill 102 186 317 103 187 317 minecraft:white_concrete
fill 104 186 275 105 187 275 minecraft:red_concrete
fill 104 186 317 104 187 317 minecraft:red_concrete
setblock 105 186 278 minecraft:light[level=15]
setblock 105 186 286 minecraft:light[level=15]
setblock 105 186 294 minecraft:light[level=15]
setblock 105 186 302 minecraft:light[level=15]
setblock 105 186 310 minecraft:light[level=15]
fill 105 186 317 105 191 317 minecraft:shroomlight
fill 106 186 275 107 187 275 minecraft:white_concrete
fill 106 186 317 107 187 317 minecraft:white_concrete
fill 108 186 275 108 187 275 minecraft:red_concrete
fill 108 186 283 110 187 283 minecraft:green_concrete
fill 108 186 317 109 187 317 minecraft:red_concrete
fill 109 186 275 109 191 275 minecraft:shroomlight
fill 109 186 282 110 187 282 minecraft:green_concrete
fill 110 186 275 111 187 275 minecraft:white_concrete
fill 110 186 317 111 187 317 minecraft:white_concrete
fill 112 186 275 113 187 275 minecraft:red_concrete
fill 112 186 317 112 187 317 minecraft:red_concrete
setblock 113 186 278 minecraft:light[level=15]
setblock 113 186 286 minecraft:light[level=15]
setblock 113 186 294 minecraft:light[level=15]
setblock 113 186 302 minecraft:light[level=15]
setblock 113 186 310 minecraft:light[level=15]
fill 113 186 317 113 191 317 minecraft:shroomlight
fill 114 186 275 115 187 275 minecraft:white_concrete
fill 114 186 317 115 187 317 minecraft:white_concrete
fill 115 186 311 119 189 311 minecraft:yellow_concrete
fill 116 186 275 116 187 275 minecraft:red_concrete
fill 116 186 310 118 189 310 minecraft:yellow_concrete
fill 116 186 312 118 189 312 minecraft:yellow_concrete
fill 116 186 317 117 187 317 minecraft:red_concrete
fill 117 186 275 117 191 275 minecraft:shroomlight
fill 117 186 309 117 189 309 minecraft:yellow_concrete
fill 117 186 313 117 189 313 minecraft:yellow_concrete
fill 118 186 275 119 187 275 minecraft:white_concrete
fill 118 186 317 119 187 317 minecraft:white_concrete
fill 120 186 275 121 187 275 minecraft:red_concrete
fill 120 186 317 120 187 317 minecraft:red_concrete
setblock 121 186 278 minecraft:light[level=15]
setblock 121 186 286 minecraft:light[level=15]
setblock 121 186 294 minecraft:light[level=15]
setblock 121 186 302 minecraft:light[level=15]
setblock 121 186 310 minecraft:light[level=15]
fill 121 186 317 121 191 317 minecraft:shroomlight
fill 122 186 275 123 187 275 minecraft:white_concrete
fill 122 186 317 123 187 317 minecraft:white_concrete
fill 124 186 275 124 187 275 minecraft:red_concrete
fill 124 186 317 125 187 317 minecraft:red_concrete
fill 125 186 275 125 191 275 minecraft:shroomlight
fill 126 186 275 127 187 275 minecraft:white_concrete
fill 126 186 317 127 187 317 minecraft:white_concrete
fill 128 186 275 129 187 275 minecraft:red_concrete
fill 128 186 317 128 187 317 minecraft:red_concrete
setblock 129 186 278 minecraft:light[level=15]
setblock 129 186 286 minecraft:light[level=15]
setblock 129 186 294 minecraft:light[level=15]
setblock 129 186 302 minecraft:light[level=15]
setblock 129 186 310 minecraft:light[level=15]
fill 129 186 317 129 191 317 minecraft:shroomlight
fill 130 186 275 131 187 275 minecraft:white_concrete
fill 130 186 317 131 187 317 minecraft:white_concrete
fill 132 186 275 132 187 275 minecraft:red_concrete
fill 132 186 317 133 187 317 minecraft:red_concrete
fill 133 186 275 133 191 275 minecraft:shroomlight
fill 134 186 275 135 187 275 minecraft:white_concrete
fill 134 186 317 135 187 317 minecraft:white_concrete
fill 136 186 276 136 187 276 minecraft:white_concrete
fill 136 186 277 136 187 278 minecraft:red_concrete
fill 136 186 279 136 187 279 minecraft:white_concrete
fill 136 186 280 136 191 280 minecraft:shroomlight
fill 136 186 281 136 187 282 minecraft:red_concrete
fill 136 186 283 136 187 284 minecraft:white_concrete
fill 136 186 285 136 187 286 minecraft:red_concrete
fill 136 186 287 136 187 287 minecraft:white_concrete
fill 136 186 288 136 191 288 minecraft:shroomlight
fill 136 186 289 136 187 290 minecraft:red_concrete
fill 136 186 291 136 187 292 minecraft:white_concrete
fill 136 186 293 136 187 294 minecraft:red_concrete
fill 136 186 295 136 187 295 minecraft:white_concrete
fill 136 186 296 136 191 296 minecraft:shroomlight
fill 136 186 297 136 187 298 minecraft:red_concrete
fill 136 186 299 136 187 300 minecraft:white_concrete
fill 136 186 301 136 187 302 minecraft:red_concrete
fill 136 186 303 136 187 303 minecraft:white_concrete
fill 136 186 304 136 191 304 minecraft:shroomlight
fill 136 186 305 136 187 306 minecraft:red_concrete
fill 136 186 307 136 187 308 minecraft:white_concrete
fill 136 186 309 136 187 310 minecraft:red_concrete
fill 136 186 311 136 187 311 minecraft:white_concrete
fill 136 186 312 136 191 312 minecraft:shroomlight
fill 136 186 313 136 187 314 minecraft:red_concrete
fill 136 186 315 136 187 316 minecraft:white_concrete
fill 136 186 317 136 187 317 minecraft:red_concrete
fill 109 187 277 109 187 279 minecraft:red_terracotta
fill 110 187 276 111 187 276 minecraft:red_terracotta
fill 110 187 280 112 187 280 minecraft:red_terracotta
fill 113 187 277 113 188 279 minecraft:red_terracotta
fill 115 187 310 115 188 310 minecraft:yellow_concrete
fill 115 187 312 115 188 312 minecraft:yellow_concrete
fill 116 187 309 116 188 309 minecraft:yellow_concrete
fill 116 187 313 116 188 313 minecraft:yellow_concrete
fill 118 187 309 118 188 309 minecraft:yellow_concrete
fill 118 187 313 118 188 313 minecraft:yellow_concrete
fill 119 187 310 119 188 310 minecraft:yellow_concrete
fill 119 187 312 119 188 312 minecraft:yellow_concrete
fill 131 187 297 131 187 299 minecraft:red_terracotta
setblock 131 187 306 minecraft:red_terracotta
setblock 131 187 308 minecraft:red_terracotta
fill 132 187 297 133 187 297 minecraft:red_terracotta
fill 132 187 299 133 187 299 minecraft:red_terracotta
setblock 133 187 298 minecraft:red_terracotta
setblock 133 187 306 minecraft:red_terracotta
setblock 133 187 308 minecraft:red_terracotta
fill 94 188 275 94 189 276 minecraft:red_concrete
fill 94 188 277 94 189 278 minecraft:white_concrete
fill 94 188 279 94 189 279 minecraft:red_concrete
fill 94 188 281 94 189 282 minecraft:white_concrete
fill 94 188 283 94 189 284 minecraft:red_concrete
fill 94 188 285 94 189 286 minecraft:white_concrete
fill 94 188 287 94 189 287 minecraft:red_concrete
fill 94 188 289 94 189 290 minecraft:white_concrete
fill 94 188 291 94 189 292 minecraft:red_concrete
fill 94 188 293 94 189 294 minecraft:white_concrete
fill 94 188 295 94 189 295 minecraft:red_concrete
fill 94 188 297 94 189 298 minecraft:white_concrete
fill 94 188 299 94 189 300 minecraft:red_concrete
fill 94 188 301 94 189 302 minecraft:white_concrete
fill 94 188 303 94 189 303 minecraft:red_concrete
fill 94 188 305 94 189 306 minecraft:white_concrete
fill 94 188 307 94 189 308 minecraft:red_concrete
fill 94 188 309 94 189 310 minecraft:white_concrete
fill 94 188 311 94 189 311 minecraft:red_concrete
fill 94 188 313 94 189 314 minecraft:white_concrete
fill 94 188 315 94 189 316 minecraft:red_concrete
fill 95 188 275 95 189 275 minecraft:red_concrete
fill 95 188 317 95 189 317 minecraft:red_concrete
fill 96 188 275 97 189 275 minecraft:white_concrete
fill 96 188 317 96 189 317 minecraft:white_concrete
setblock 97 188 278 minecraft:light[level=12]
setblock 97 188 285 minecraft:light[level=12]
setblock 97 188 292 minecraft:light[level=12]
setblock 97 188 299 minecraft:light[level=12]
setblock 97 188 306 minecraft:light[level=12]
setblock 97 188 313 minecraft:light[level=12]
fill 98 188 275 99 189 275 minecraft:red_concrete
fill 98 188 317 99 189 317 minecraft:red_concrete
fill 100 188 275 100 189 275 minecraft:white_concrete
fill 100 188 317 101 189 317 minecraft:white_concrete
fill 102 188 275 103 189 275 minecraft:red_concrete
fill 102 188 317 103 189 317 minecraft:red_concrete
fill 104 188 275 105 189 275 minecraft:white_concrete
setblock 104 188 278 minecraft:light[level=12]
setblock 104 188 285 minecraft:light[level=12]
setblock 104 188 292 minecraft:light[level=12]
setblock 104 188 299 minecraft:light[level=12]
setblock 104 188 306 minecraft:light[level=12]
setblock 104 188 313 minecraft:light[level=12]
fill 104 188 317 104 189 317 minecraft:white_concrete
fill 106 188 275 107 189 275 minecraft:red_concrete
fill 106 188 317 107 189 317 minecraft:red_concrete
fill 108 188 275 108 189 275 minecraft:white_concrete
fill 108 188 317 109 189 317 minecraft:white_concrete
fill 110 188 275 111 189 275 minecraft:red_concrete
fill 110 188 317 111 189 317 minecraft:red_concrete
fill 111 188 277 111 188 279 minecraft:red_terracotta
setblock 111 188 285 minecraft:light[level=12]
setblock 111 188 292 minecraft:light[level=12]
setblock 111 188 299 minecraft:light[level=12]
setblock 111 188 306 minecraft:light[level=12]
setblock 111 188 313 minecraft:light[level=12]
fill 112 188 275 113 189 275 minecraft:white_concrete
setblock 112 188 277 minecraft:red_terracotta
setblock 112 188 279 minecraft:red_terracotta
fill 112 188 317 112 189 317 minecraft:white_concrete
fill 114 188 275 115 189 275 minecraft:red_concrete
fill 114 188 317 115 189 317 minecraft:red_concrete
fill 116 188 275 116 189 275 minecraft:white_concrete
fill 116 188 317 117 189 317 minecraft:white_concrete
fill 118 188 275 119 189 275 minecraft:red_concrete
setblock 118 188 278 minecraft:light[level=12]
setblock 118 188 285 minecraft:light[level=12]
setblock 118 188 299 minecraft:light[level=12]
setblock 118 188 306 minecraft:light[level=12]
fill 118 188 317 119 189 317 minecraft:red_concrete
fill 120 188 275 121 189 275 minecraft:white_concrete
fill 120 188 317 120 189 317 minecraft:white_concrete
fill 122 188 275 123 189 275 minecraft:red_concrete
fill 122 188 317 123 189 317 minecraft:red_concrete
fill 124 188 275 124 189 275 minecraft:white_concrete
fill 124 188 317 125 189 317 minecraft:white_concrete
setblock 125 188 285 minecraft:light[level=12]
setblock 125 188 292 minecraft:light[level=12]
setblock 125 188 299 minecraft:light[level=12]
setblock 125 188 306 minecraft:light[level=12]
setblock 125 188 313 minecraft:light[level=12]
fill 126 188 275 127 189 275 minecraft:red_concrete
fill 126 188 317 127 189 317 minecraft:red_concrete
fill 128 188 275 129 189 275 minecraft:white_concrete
fill 128 188 317 128 189 317 minecraft:white_concrete
fill 130 188 275 131 189 275 minecraft:red_concrete
fill 130 188 317 131 189 317 minecraft:red_concrete
fill 132 188 275 132 189 275 minecraft:white_concrete
setblock 132 188 278 minecraft:light[level=12]
setblock 132 188 285 minecraft:light[level=12]
setblock 132 188 292 minecraft:light[level=12]
setblock 132 188 299 minecraft:light[level=12]
setblock 132 188 313 minecraft:light[level=12]
fill 132 188 317 133 189 317 minecraft:white_concrete
fill 134 188 275 135 189 275 minecraft:red_concrete
fill 134 188 317 135 189 317 minecraft:red_concrete
fill 136 188 276 136 189 276 minecraft:red_concrete
fill 136 188 277 136 189 278 minecraft:white_concrete
fill 136 188 279 136 189 279 minecraft:red_concrete
fill 136 188 281 136 189 282 minecraft:white_concrete
fill 136 188 283 136 189 284 minecraft:red_concrete
fill 136 188 285 136 189 286 minecraft:white_concrete
fill 136 188 287 136 189 287 minecraft:red_concrete
fill 136 188 289 136 189 290 minecraft:white_concrete
fill 136 188 291 136 189 292 minecraft:red_concrete
fill 136 188 293 136 189 294 minecraft:white_concrete
fill 136 188 295 136 189 295 minecraft:red_concrete
fill 136 188 297 136 189 298 minecraft:white_concrete
fill 136 188 299 136 189 300 minecraft:red_concrete
fill 136 188 301 136 189 302 minecraft:white_concrete
fill 136 188 303 136 189 303 minecraft:red_concrete
fill 136 188 305 136 189 306 minecraft:white_concrete
fill 136 188 307 136 189 308 minecraft:red_concrete
fill 136 188 309 136 189 310 minecraft:white_concrete
fill 136 188 311 136 189 311 minecraft:red_concrete
fill 136 188 313 136 189 314 minecraft:white_concrete
fill 136 188 315 136 189 316 minecraft:red_concrete
fill 136 188 317 136 189 317 minecraft:white_concrete
fill 111 189 277 111 192 279 minecraft:iron_block
fill 112 189 277 112 192 277 minecraft:iron_block
fill 112 189 279 112 192 279 minecraft:iron_block
fill 94 190 275 94 191 276 minecraft:white_concrete
fill 94 190 277 94 191 278 minecraft:red_concrete
fill 94 190 279 94 191 279 minecraft:white_concrete
fill 94 190 281 94 191 282 minecraft:red_concrete
fill 94 190 283 94 191 284 minecraft:white_concrete
fill 94 190 285 94 191 286 minecraft:red_concrete
fill 94 190 287 94 191 287 minecraft:white_concrete
fill 94 190 289 94 191 290 minecraft:red_concrete
fill 94 190 291 94 191 292 minecraft:white_concrete
fill 94 190 293 94 191 294 minecraft:red_concrete
fill 94 190 295 94 191 295 minecraft:white_concrete
fill 94 190 297 94 191 298 minecraft:red_concrete
fill 94 190 299 94 191 300 minecraft:white_concrete
fill 94 190 301 94 191 302 minecraft:red_concrete
fill 94 190 303 94 191 303 minecraft:white_concrete
fill 94 190 305 94 191 306 minecraft:red_concrete
fill 94 190 307 94 191 308 minecraft:white_concrete
fill 94 190 309 94 191 310 minecraft:red_concrete
fill 94 190 311 94 191 311 minecraft:white_concrete
fill 94 190 313 94 191 314 minecraft:red_concrete
fill 94 190 315 94 191 316 minecraft:white_concrete
fill 95 190 275 95 191 275 minecraft:white_concrete
fill 95 190 317 95 191 317 minecraft:white_concrete
fill 96 190 275 97 191 275 minecraft:red_concrete
fill 96 190 317 96 191 317 minecraft:red_concrete
fill 98 190 275 99 191 275 minecraft:white_concrete
fill 98 190 317 99 191 317 minecraft:white_concrete
fill 100 190 275 100 191 275 minecraft:red_concrete
fill 100 190 317 101 191 317 minecraft:red_concrete
fill 102 190 275 103 191 275 minecraft:white_concrete
fill 102 190 317 103 191 317 minecraft:white_concrete
fill 104 190 275 105 191 275 minecraft:red_concrete
fill 104 190 317 104 191 317 minecraft:red_concrete
fill 106 190 275 107 191 275 minecraft:white_concrete
fill 106 190 317 107 191 317 minecraft:white_concrete
fill 108 190 275 108 191 275 minecraft:red_concrete
fill 108 190 317 109 191 317 minecraft:red_concrete
fill 110 190 275 111 191 275 minecraft:white_concrete
fill 110 190 317 111 191 317 minecraft:white_concrete
fill 112 190 275 113 191 275 minecraft:red_concrete
fill 112 190 317 112 191 317 minecraft:red_concrete
fill 114 190 275 115 191 275 minecraft:white_concrete
fill 114 190 317 115 191 317 minecraft:white_concrete
fill 116 190 275 116 191 275 minecraft:red_concrete
fill 116 190 317 117 191 317 minecraft:red_concrete
setblock 117 190 311 minecraft:yellow_concrete
fill 118 190 275 119 191 275 minecraft:white_concrete
fill 118 190 317 119 191 317 minecraft:white_concrete
fill 120 190 275 121 191 275 minecraft:red_concrete
fill 120 190 317 120 191 317 minecraft:red_concrete
fill 122 190 275 123 191 275 minecraft:white_concrete
fill 122 190 317 123 191 317 minecraft:white_concrete
fill 124 190 275 124 191 275 minecraft:red_concrete
fill 124 190 317 125 191 317 minecraft:red_concrete
fill 126 190 275 127 191 275 minecraft:white_concrete
fill 126 190 317 127 191 317 minecraft:white_concrete
fill 128 190 275 129 191 275 minecraft:red_concrete
fill 128 190 317 128 191 317 minecraft:red_concrete
fill 130 190 275 131 191 275 minecraft:white_concrete
fill 130 190 317 131 191 317 minecraft:white_concrete
fill 132 190 275 132 191 275 minecraft:red_concrete
fill 132 190 317 133 191 317 minecraft:red_concrete
fill 134 190 275 135 191 275 minecraft:white_concrete
fill 134 190 317 135 191 317 minecraft:white_concrete
fill 136 190 276 136 191 276 minecraft:white_concrete
fill 136 190 277 136 191 278 minecraft:red_concrete
fill 136 190 279 136 191 279 minecraft:white_concrete
fill 136 190 281 136 191 282 minecraft:red_concrete
fill 136 190 283 136 191 284 minecraft:white_concrete
fill 136 190 285 136 191 286 minecraft:red_concrete
fill 136 190 287 136 191 287 minecraft:white_concrete
fill 136 190 289 136 191 290 minecraft:red_concrete
fill 136 190 291 136 191 292 minecraft:white_concrete
fill 136 190 293 136 191 294 minecraft:red_concrete
fill 136 190 295 136 191 295 minecraft:white_concrete
fill 136 190 297 136 191 298 minecraft:red_concrete
fill 136 190 299 136 191 300 minecraft:white_concrete
fill 136 190 301 136 191 302 minecraft:red_concrete
fill 136 190 303 136 191 303 minecraft:white_concrete
fill 136 190 305 136 191 306 minecraft:red_concrete
fill 136 190 307 136 191 308 minecraft:white_concrete
fill 136 190 309 136 191 310 minecraft:red_concrete
fill 136 190 311 136 191 311 minecraft:white_concrete
fill 136 190 313 136 191 314 minecraft:red_concrete
fill 136 190 315 136 191 316 minecraft:white_concrete
fill 136 190 317 136 191 317 minecraft:red_concrete
fill 94 192 275 94 193 276 minecraft:red_concrete
fill 94 192 277 94 193 278 minecraft:white_concrete
fill 94 192 279 94 193 280 minecraft:red_concrete
fill 94 192 281 94 193 282 minecraft:white_concrete
fill 94 192 283 94 193 284 minecraft:red_concrete
fill 94 192 285 94 193 286 minecraft:white_concrete
fill 94 192 287 94 193 288 minecraft:red_concrete
fill 94 192 289 94 193 290 minecraft:white_concrete
fill 94 192 291 94 193 292 minecraft:red_concrete
fill 94 192 293 94 193 294 minecraft:white_concrete
fill 94 192 295 94 193 296 minecraft:red_concrete
fill 94 192 297 94 193 298 minecraft:white_concrete
fill 94 192 299 94 193 300 minecraft:red_concrete
fill 94 192 301 94 193 302 minecraft:white_concrete
fill 94 192 303 94 193 304 minecraft:red_concrete
fill 94 192 305 94 193 306 minecraft:white_concrete
fill 94 192 307 94 193 308 minecraft:red_concrete
fill 94 192 309 94 193 310 minecraft:white_concrete
fill 94 192 311 94 193 312 minecraft:red_concrete
fill 94 192 313 94 193 314 minecraft:white_concrete
fill 94 192 315 94 193 316 minecraft:red_concrete
fill 95 192 275 95 193 275 minecraft:red_concrete
fill 95 192 317 95 193 317 minecraft:red_concrete
fill 96 192 275 97 193 275 minecraft:white_concrete
fill 96 192 317 97 193 317 minecraft:white_concrete
fill 98 192 275 99 193 275 minecraft:red_concrete
fill 98 192 317 99 193 317 minecraft:red_concrete
fill 100 192 275 101 193 275 minecraft:white_concrete
fill 100 192 317 101 193 317 minecraft:white_concrete
fill 102 192 275 103 193 275 minecraft:red_concrete
fill 102 192 317 103 193 317 minecraft:red_concrete
fill 104 192 275 105 193 275 minecraft:white_concrete
fill 104 192 317 105 193 317 minecraft:white_concrete
fill 106 192 275 107 193 275 minecraft:red_concrete
fill 106 192 317 107 193 317 minecraft:red_concrete
fill 108 192 275 109 193 275 minecraft:white_concrete
fill 108 192 317 109 193 317 minecraft:white_concrete
fill 110 192 275 111 193 275 minecraft:red_concrete
fill 110 192 317 111 193 317 minecraft:red_concrete
fill 112 192 275 113 193 275 minecraft:white_concrete
fill 112 192 317 113 193 317 minecraft:white_concrete
fill 114 192 275 115 193 275 minecraft:red_concrete
fill 114 192 317 115 193 317 minecraft:red_concrete
fill 116 192 275 117 193 275 minecraft:white_concrete
fill 116 192 317 117 193 317 minecraft:white_concrete
fill 118 192 275 119 193 275 minecraft:red_concrete
fill 118 192 317 119 193 317 minecraft:red_concrete
fill 120 192 275 121 193 275 minecraft:white_concrete
fill 120 192 317 121 193 317 minecraft:white_concrete
fill 122 192 275 123 193 275 minecraft:red_concrete
fill 122 192 317 123 193 317 minecraft:red_concrete
fill 124 192 275 125 193 275 minecraft:white_concrete
fill 124 192 317 125 193 317 minecraft:white_concrete
fill 126 192 275 127 193 275 minecraft:red_concrete
fill 126 192 317 127 193 317 minecraft:red_concrete
fill 128 192 275 129 193 275 minecraft:white_concrete
fill 128 192 317 129 193 317 minecraft:white_concrete
fill 130 192 275 131 193 275 minecraft:red_concrete
fill 130 192 317 131 193 317 minecraft:red_concrete
fill 132 192 275 133 193 275 minecraft:white_concrete
fill 132 192 317 133 193 317 minecraft:white_concrete
fill 134 192 275 135 193 275 minecraft:red_concrete
fill 134 192 317 135 193 317 minecraft:red_concrete
fill 136 192 276 136 193 276 minecraft:red_concrete
fill 136 192 277 136 193 278 minecraft:white_concrete
fill 136 192 279 136 193 280 minecraft:red_concrete
fill 136 192 281 136 193 282 minecraft:white_concrete
fill 136 192 283 136 193 284 minecraft:red_concrete
fill 136 192 285 136 193 286 minecraft:white_concrete
fill 136 192 287 136 193 288 minecraft:red_concrete
fill 136 192 289 136 193 290 minecraft:white_concrete
fill 136 192 291 136 193 292 minecraft:red_concrete
fill 136 192 293 136 193 294 minecraft:white_concrete
fill 136 192 295 136 193 296 minecraft:red_concrete
fill 136 192 297 136 193 298 minecraft:white_concrete
fill 136 192 299 136 193 300 minecraft:red_concrete
fill 136 192 301 136 193 302 minecraft:white_concrete
fill 136 192 303 136 193 304 minecraft:red_concrete
fill 136 192 305 136 193 306 minecraft:white_concrete
fill 136 192 307 136 193 308 minecraft:red_concrete
fill 136 192 309 136 193 310 minecraft:white_concrete
fill 136 192 311 136 193 312 minecraft:red_concrete
fill 136 192 313 136 193 314 minecraft:white_concrete
fill 136 192 315 136 193 316 minecraft:red_concrete
fill 136 192 317 136 193 317 minecraft:white_concrete
fill 109 193 277 109 193 279 minecraft:red_terracotta
fill 110 193 276 111 193 276 minecraft:red_terracotta
fill 110 193 280 112 193 280 minecraft:red_terracotta
fill 111 193 277 111 193 279 minecraft:red_terracotta
fill 112 193 277 113 193 277 minecraft:red_terracotta
fill 112 193 279 113 193 279 minecraft:red_terracotta
setblock 113 193 278 minecraft:red_terracotta
fill 131 193 297 131 193 299 minecraft:red_terracotta
setblock 131 193 306 minecraft:red_terracotta
setblock 131 193 308 minecraft:red_terracotta
fill 132 193 297 133 193 297 minecraft:red_terracotta
fill 132 193 299 133 193 299 minecraft:red_terracotta
setblock 133 193 298 minecraft:red_terracotta
setblock 133 193 306 minecraft:red_terracotta
setblock 133 193 308 minecraft:red_terracotta
fill 94 194 275 94 195 276 minecraft:white_concrete
fill 94 194 277 94 195 278 minecraft:red_concrete
fill 94 194 279 94 195 280 minecraft:white_concrete
fill 94 194 281 94 195 282 minecraft:red_concrete
fill 94 194 283 94 195 284 minecraft:white_concrete
fill 94 194 285 94 195 286 minecraft:red_concrete
fill 94 194 287 94 195 288 minecraft:white_concrete
fill 94 194 289 94 195 290 minecraft:red_concrete
fill 94 194 291 94 195 292 minecraft:white_concrete
fill 94 194 293 94 195 294 minecraft:red_concrete
fill 94 194 295 94 195 296 minecraft:white_concrete
fill 94 194 297 94 195 298 minecraft:red_concrete
fill 94 194 299 94 195 300 minecraft:white_concrete
fill 94 194 301 94 195 302 minecraft:red_concrete
fill 94 194 303 94 195 304 minecraft:white_concrete
fill 94 194 305 94 195 306 minecraft:red_concrete
fill 94 194 307 94 195 308 minecraft:white_concrete
fill 94 194 309 94 195 310 minecraft:red_concrete
fill 94 194 311 94 195 312 minecraft:white_concrete
fill 94 194 313 94 195 314 minecraft:red_concrete
fill 94 194 315 94 195 316 minecraft:white_concrete
fill 95 194 275 95 195 275 minecraft:white_concrete
fill 95 194 317 95 195 317 minecraft:white_concrete
fill 96 194 275 97 195 275 minecraft:red_concrete
fill 96 194 317 97 195 317 minecraft:red_concrete
setblock 97 194 278 minecraft:light[level=15]
setblock 97 194 285 minecraft:light[level=12]
setblock 97 194 286 minecraft:light[level=15]
setblock 97 194 292 minecraft:light[level=12]
setblock 97 194 294 minecraft:light[level=15]
setblock 97 194 299 minecraft:light[level=12]
setblock 97 194 302 minecraft:light[level=15]
setblock 97 194 306 minecraft:light[level=12]
setblock 97 194 310 minecraft:light[level=15]
setblock 97 194 313 minecraft:light[level=12]
fill 98 194 275 99 195 275 minecraft:white_concrete
fill 98 194 317 99 195 317 minecraft:white_concrete
fill 100 194 275 101 195 275 minecraft:red_concrete
fill 100 194 317 101 195 317 minecraft:red_concrete
fill 102 194 275 103 195 275 minecraft:white_concrete
fill 102 194 317 103 195 317 minecraft:white_concrete
fill 104 194 275 105 195 275 minecraft:red_concrete
setblock 104 194 278 minecraft:light[level=12]
setblock 104 194 285 minecraft:light[level=12]
setblock 104 194 292 minecraft:light[level=12]
setblock 104 194 299 minecraft:light[level=12]
setblock 104 194 306 minecraft:light[level=12]
setblock 104 194 313 minecraft:light[level=12]
fill 104 194 317 105 195 317 minecraft:red_concrete
setblock 105 194 278 minecraft:light[level=15]
setblock 105 194 286 minecraft:light[level=15]
setblock 105 194 294 minecraft:light[level=15]
setblock 105 194 302 minecraft:light[level=15]
setblock 105 194 310 minecraft:light[level=15]
fill 106 194 275 107 195 275 minecraft:white_concrete
fill 106 194 317 107 195 317 minecraft:white_concrete
fill 108 194 275 109 195 275 minecraft:red_concrete
fill 108 194 317 109 195 317 minecraft:red_concrete
fill 110 194 275 111 195 275 minecraft:white_concrete
fill 110 194 317 111 195 317 minecraft:white_concrete
fill 111 194 277 111 195 279 minecraft:iron_block
setblock 111 194 285 minecraft:light[level=12]
setblock 111 194 292 minecraft:light[level=12]
setblock 111 194 299 minecraft:light[level=12]
setblock 111 194 306 minecraft:light[level=12]
setblock 111 194 313 minecraft:light[level=12]
fill 112 194 275 113 195 275 minecraft:red_concrete
fill 112 194 277 112 195 277 minecraft:iron_block
fill 112 194 279 112 197 279 minecraft:iron_block
fill 112 194 317 113 195 317 minecraft:red_concrete
setblock 113 194 278 minecraft:light[level=15]
setblock 113 194 286 minecraft:light[level=15]
setblock 113 194 294 minecraft:light[level=15]
setblock 113 194 302 minecraft:light[level=15]
setblock 113 194 310 minecraft:light[level=15]
fill 114 194 275 115 195 275 minecraft:white_concrete
fill 114 194 317 115 195 317 minecraft:white_concrete
fill 116 194 275 117 195 275 minecraft:red_concrete
fill 116 194 317 117 195 317 minecraft:red_concrete
fill 118 194 275 119 195 275 minecraft:white_concrete
setblock 118 194 278 minecraft:light[level=12]
setblock 118 194 285 minecraft:light[level=12]
setblock 118 194 299 minecraft:light[level=12]
setblock 118 194 306 minecraft:light[level=12]
setblock 118 194 313 minecraft:light[level=12]
fill 118 194 317 119 195 317 minecraft:white_concrete
fill 120 194 275 121 195 275 minecraft:red_concrete
fill 120 194 317 121 195 317 minecraft:red_concrete
setblock 121 194 278 minecraft:light[level=15]
setblock 121 194 286 minecraft:light[level=15]
setblock 121 194 294 minecraft:light[level=15]
setblock 121 194 302 minecraft:light[level=15]
setblock 121 194 310 minecraft:light[level=15]
fill 122 194 275 123 195 275 minecraft:white_concrete
fill 122 194 317 123 195 317 minecraft:white_concrete
fill 124 194 275 125 195 275 minecraft:red_concrete
fill 124 194 317 125 195 317 minecraft:red_concrete
setblock 125 194 285 minecraft:light[level=12]
setblock 125 194 292 minecraft:light[level=12]
setblock 125 194 299 minecraft:light[level=12]
setblock 125 194 306 minecraft:light[level=12]
setblock 125 194 313 minecraft:light[level=12]
fill 126 194 275 127 195 275 minecraft:white_concrete
fill 126 194 317 127 195 317 minecraft:white_concrete
fill 128 194 275 129 195 275 minecraft:red_concrete
fill 128 194 317 129 195 317 minecraft:red_concrete
setblock 129 194 278 minecraft:light[level=15]
setblock 129 194 286 minecraft:light[level=15]
setblock 129 194 294 minecraft:light[level=15]
setblock 129 194 302 minecraft:light[level=15]
setblock 129 194 310 minecraft:light[level=15]
fill 130 194 275 131 195 275 minecraft:white_concrete
fill 130 194 317 131 195 317 minecraft:white_concrete
fill 132 194 275 133 195 275 minecraft:red_concrete
setblock 132 194 278 minecraft:light[level=12]
setblock 132 194 285 minecraft:light[level=12]
setblock 132 194 292 minecraft:light[level=12]
setblock 132 194 299 minecraft:light[level=12]
setblock 132 194 313 minecraft:light[level=12]
fill 132 194 317 133 195 317 minecraft:red_concrete
fill 134 194 275 135 195 275 minecraft:white_concrete
fill 134 194 317 135 195 317 minecraft:white_concrete
fill 136 194 276 136 195 276 minecraft:white_concrete
fill 136 194 277 136 195 278 minecraft:red_concrete
fill 136 194 279 136 195 280 minecraft:white_concrete
fill 136 194 281 136 195 282 minecraft:red_concrete
fill 136 194 283 136 195 284 minecraft:white_concrete
fill 136 194 285 136 195 286 minecraft:red_concrete
fill 136 194 287 136 195 288 minecraft:white_concrete
fill 136 194 289 136 195 290 minecraft:red_concrete
fill 136 194 291 136 195 292 minecraft:white_concrete
fill 136 194 293 136 195 294 minecraft:red_concrete
fill 136 194 295 136 195 296 minecraft:white_concrete
fill 136 194 297 136 195 298 minecraft:red_concrete
fill 136 194 299 136 195 300 minecraft:white_concrete
fill 136 194 301 136 195 302 minecraft:red_concrete
fill 136 194 303 136 195 304 minecraft:white_concrete
fill 136 194 305 136 195 306 minecraft:red_concrete
fill 136 194 307 136 195 308 minecraft:white_concrete
fill 136 194 309 136 195 310 minecraft:red_concrete
fill 136 194 311 136 195 312 minecraft:white_concrete
fill 136 194 313 136 195 314 minecraft:red_concrete
fill 136 194 315 136 195 316 minecraft:white_concrete
fill 136 194 317 136 195 317 minecraft:red_concrete
fill 94 196 275 94 197 276 minecraft:red_concrete
fill 94 196 277 94 197 278 minecraft:white_concrete
fill 94 196 279 94 197 280 minecraft:red_concrete
fill 94 196 281 94 197 282 minecraft:white_concrete
fill 94 196 283 94 197 284 minecraft:red_concrete
fill 94 196 285 94 197 286 minecraft:white_concrete
fill 94 196 287 94 197 288 minecraft:red_concrete
fill 94 196 289 94 197 290 minecraft:white_concrete
fill 94 196 291 94 197 292 minecraft:red_concrete
fill 94 196 293 94 197 294 minecraft:white_concrete
fill 94 196 295 94 197 296 minecraft:red_concrete
fill 94 196 297 94 197 298 minecraft:white_concrete
fill 94 196 299 94 197 300 minecraft:red_concrete
fill 94 196 301 94 197 302 minecraft:white_concrete
fill 94 196 303 94 197 304 minecraft:red_concrete
fill 94 196 305 94 197 306 minecraft:white_concrete
fill 94 196 307 94 197 308 minecraft:red_concrete
fill 94 196 309 94 197 310 minecraft:white_concrete
fill 94 196 311 94 197 312 minecraft:red_concrete
fill 94 196 313 94 197 314 minecraft:white_concrete
fill 94 196 315 94 197 316 minecraft:red_concrete
fill 95 196 275 95 197 275 minecraft:red_concrete
fill 95 196 276 95 197 281 minecraft:red_terracotta
fill 95 196 284 96 196 289 minecraft:red_terracotta
fill 95 196 292 96 196 297 minecraft:red_terracotta
fill 95 196 300 96 196 305 minecraft:red_terracotta
fill 95 196 308 96 196 313 minecraft:red_terracotta
fill 95 196 316 100 197 316 minecraft:red_terracotta
fill 95 196 317 95 197 317 minecraft:red_concrete
fill 96 196 275 97 197 275 minecraft:white_concrete
fill 96 196 277 96 196 283 minecraft:red_terracotta
fill 96 196 290 96 196 291 minecraft:red_terracotta
fill 96 196 298 96 196 299 minecraft:red_terracotta
fill 96 196 306 96 196 307 minecraft:red_terracotta
fill 96 196 314 96 196 315 minecraft:red_terracotta
fill 96 196 317 97 197 317 minecraft:white_concrete
fill 97 196 277 134 196 277 minecraft:red_terracotta
fill 97 196 315 135 196 315 minecraft:red_terracotta
fill 98 196 275 99 197 275 minecraft:red_concrete
fill 98 196 276 103 197 276 minecraft:red_terracotta
fill 98 196 317 99 197 317 minecraft:red_concrete
fill 100 196 275 101 197 275 minecraft:white_concrete
fill 100 196 317 101 197 317 minecraft:white_concrete
fill 102 196 275 103 197 275 minecraft:red_concrete
fill 102 196 317 103 197 317 minecraft:red_concrete
fill 103 196 316 108 197 316 minecraft:red_terracotta
fill 104 196 275 105 197 275 minecraft:white_concrete
fill 104 196 317 105 197 317 minecraft:white_concrete
fill 106 196 275 107 197 275 minecraft:red_concrete
fill 106 196 276 111 197 276 minecraft:red_terracotta
fill 106 196 317 107 197 317 minecraft:red_concrete
fill 108 196 275 109 197 275 minecraft:white_concrete
fill 108 196 317 109 197 317 minecraft:white_concrete
fill 110 196 275 111 197 275 minecraft:red_concrete
fill 110 196 317 111 197 317 minecraft:red_concrete
fill 111 196 278 111 197 279 minecraft:iron_block
fill 111 196 316 116 197 316 minecraft:red_terracotta
fill 112 196 275 113 197 275 minecraft:white_concrete
fill 112 196 317 113 197 317 minecraft:white_concrete
fill 114 196 275 115 197 275 minecraft:red_concrete
fill 114 196 276 119 197 276 minecraft:red_terracotta
fill 114 196 317 115 197 317 minecraft:red_concrete
fill 116 196 275 117 197 275 minecraft:white_concrete
fill 116 196 317 117 197 317 minecraft:white_concrete
fill 118 196 275 119 197 275 minecraft:red_concrete
fill 118 196 317 119 197 317 minecraft:red_concrete
fill 119 196 316 124 197 316 minecraft:red_terracotta
fill 120 196 275 121 197 275 minecraft:white_concrete
fill 120 196 317 121 197 317 minecraft:white_concrete
fill 122 196 275 123 197 275 minecraft:red_concrete
fill 122 196 276 127 197 276 minecraft:red_terracotta
fill 122 196 317 123 197 317 minecraft:red_concrete
fill 124 196 275 125 197 275 minecraft:white_concrete
fill 124 196 317 125 197 317 minecraft:white_concrete
fill 126 196 275 127 197 275 minecraft:red_concrete
fill 126 196 317 127 197 317 minecraft:red_concrete
fill 127 196 316 132 197 316 minecraft:red_terracotta
fill 128 196 275 129 197 275 minecraft:white_concrete
fill 128 196 317 129 197 317 minecraft:white_concrete
fill 130 196 275 131 197 275 minecraft:red_concrete
fill 130 196 276 135 197 276 minecraft:red_terracotta
fill 130 196 317 131 197 317 minecraft:red_concrete
fill 132 196 275 133 197 275 minecraft:white_concrete
fill 132 196 317 133 197 317 minecraft:white_concrete
fill 134 196 275 135 197 275 minecraft:red_concrete
fill 134 196 278 134 196 314 minecraft:red_terracotta
fill 134 196 317 135 197 317 minecraft:red_concrete
fill 135 196 279 135 197 284 minecraft:red_terracotta
fill 135 196 287 135 197 292 minecraft:red_terracotta
fill 135 196 295 135 197 300 minecraft:red_terracotta
fill 135 196 303 135 197 308 minecraft:red_terracotta
fill 135 196 311 135 197 314 minecraft:red_terracotta
fill 135 196 316 135 197 316 minecraft:red_terracotta
fill 136 196 276 136 197 276 minecraft:red_concrete
fill 136 196 277 136 197 278 minecraft:white_concrete
fill 136 196 279 136 197 280 minecraft:red_concrete
fill 136 196 281 136 197 282 minecraft:white_concrete
fill 136 196 283 136 197 284 minecraft:red_concrete
fill 136 196 285 136 197 286 minecraft:white_concrete
fill 136 196 287 136 197 288 minecraft:red_concrete
fill 136 196 289 136 197 290 minecraft:white_concrete
fill 136 196 291 136 197 292 minecraft:red_concrete
fill 136 196 293 136 197 294 minecraft:white_concrete
fill 136 196 295 136 197 296 minecraft:red_concrete
fill 136 196 297 136 197 298 minecraft:white_concrete
fill 136 196 299 136 197 300 minecraft:red_concrete
fill 136 196 301 136 197 302 minecraft:white_concrete
fill 136 196 303 136 197 304 minecraft:red_concrete
fill 136 196 305 136 197 306 minecraft:white_concrete
fill 136 196 307 136 197 308 minecraft:red_concrete
fill 136 196 309 136 197 310 minecraft:white_concrete
fill 136 196 311 136 197 312 minecraft:red_concrete
fill 136 196 313 136 197 314 minecraft:white_concrete
fill 136 196 315 136 197 316 minecraft:red_concrete
fill 136 196 317 136 197 317 minecraft:white_concrete
fill 95 197 284 95 197 289 minecraft:red_terracotta
fill 95 197 292 95 197 297 minecraft:red_terracotta
fill 95 197 300 95 197 305 minecraft:red_terracotta
fill 95 197 308 95 197 313 minecraft:red_terracotta
fill 110 197 277 112 197 277 minecraft:iron_block
setblock 135 197 315 minecraft:red_terracotta
fill 94 198 275 94 199 276 minecraft:white_concrete
fill 94 198 277 94 199 278 minecraft:red_concrete
fill 94 198 279 94 199 280 minecraft:white_concrete
fill 94 198 281 94 199 282 minecraft:red_concrete
fill 94 198 283 94 199 284 minecraft:white_concrete
fill 94 198 285 94 199 286 minecraft:red_concrete
fill 94 198 287 94 199 288 minecraft:white_concrete
fill 94 198 289 94 199 290 minecraft:red_concrete
fill 94 198 291 94 199 292 minecraft:white_concrete
fill 94 198 293 94 199 294 minecraft:red_concrete
fill 94 198 295 94 199 296 minecraft:white_concrete
fill 94 198 297 94 199 298 minecraft:red_concrete
fill 94 198 299 94 199 300 minecraft:white_concrete
fill 94 198 301 94 199 302 minecraft:red_concrete
fill 94 198 303 94 199 304 minecraft:white_concrete
fill 94 198 305 94 199 306 minecraft:red_concrete
fill 94 198 307 94 199 308 minecraft:white_concrete
fill 94 198 309 94 199 310 minecraft:red_concrete
fill 94 198 311 94 199 312 minecraft:white_concrete
fill 94 198 313 94 199 314 minecraft:red_concrete
fill 94 198 315 94 199 316 minecraft:white_concrete
fill 95 198 275 95 199 275 minecraft:white_concrete
fill 95 198 317 95 199 317 minecraft:white_concrete
fill 96 198 275 97 199 275 minecraft:red_concrete
fill 96 198 317 97 199 317 minecraft:red_concrete
fill 98 198 275 99 199 275 minecraft:white_concrete
fill 98 198 317 99 199 317 minecraft:white_concrete
fill 100 198 275 101 199 275 minecraft:red_concrete
fill 100 198 317 101 199 317 minecraft:red_concrete
fill 102 198 275 103 199 275 minecraft:white_concrete
fill 102 198 317 103 199 317 minecraft:white_concrete
fill 104 198 275 105 199 275 minecraft:red_concrete
fill 104 198 317 105 199 317 minecraft:red_concrete
fill 106 198 275 107 199 275 minecraft:white_concrete
fill 106 198 317 107 199 317 minecraft:white_concrete
fill 108 198 275 109 199 275 minecraft:red_concrete
fill 108 198 317 109 199 317 minecraft:red_concrete
fill 110 198 275 111 199 275 minecraft:white_concrete
fill 110 198 277 110 209 277 minecraft:iron_block
fill 110 198 317 111 199 317 minecraft:white_concrete
fill 111 198 277 111 198 279 minecraft:red_terracotta
fill 112 198 275 113 199 275 minecraft:red_concrete
fill 112 198 277 113 198 277 minecraft:red_terracotta
fill 112 198 279 113 198 279 minecraft:red_terracotta
fill 112 198 317 113 199 317 minecraft:red_concrete
fill 113 198 278 113 199 278 minecraft:red_terracotta
fill 114 198 275 115 199 275 minecraft:white_concrete
fill 114 198 317 115 199 317 minecraft:white_concrete
fill 116 198 275 117 199 275 minecraft:red_concrete
fill 116 198 317 117 199 317 minecraft:red_concrete
fill 118 198 275 119 199 275 minecraft:white_concrete
fill 118 198 317 119 199 317 minecraft:white_concrete
fill 120 198 275 121 199 275 minecraft:red_concrete
fill 120 198 317 121 199 317 minecraft:red_concrete
fill 122 198 275 123 199 275 minecraft:white_concrete
fill 122 198 317 123 199 317 minecraft:white_concrete
fill 124 198 275 125 199 275 minecraft:red_concrete
fill 124 198 317 125 199 317 minecraft:red_concrete
fill 126 198 275 127 199 275 minecraft:white_concrete
fill 126 198 317 127 199 317 minecraft:white_concrete
fill 128 198 275 129 199 275 minecraft:red_concrete
fill 128 198 317 129 199 317 minecraft:red_concrete
fill 130 198 275 131 199 275 minecraft:white_concrete
fill 130 198 317 131 199 317 minecraft:white_concrete
fill 132 198 275 133 199 275 minecraft:red_concrete
fill 132 198 317 133 199 317 minecraft:red_concrete
fill 134 198 275 135 199 275 minecraft:white_concrete
fill 134 198 317 135 199 317 minecraft:white_concrete
fill 136 198 276 136 199 276 minecraft:white_concrete
fill 136 198 277 136 199 278 minecraft:red_concrete
fill 136 198 279 136 199 280 minecraft:white_concrete
fill 136 198 281 136 199 282 minecraft:red_concrete
fill 136 198 283 136 199 284 minecraft:white_concrete
fill 136 198 285 136 199 286 minecraft:red_concrete
fill 136 198 287 136 199 288 minecraft:white_concrete
fill 136 198 289 136 199 290 minecraft:red_concrete
fill 136 198 291 136 199 292 minecraft:white_concrete
fill 136 198 293 136 199 294 minecraft:red_concrete
fill 136 198 295 136 199 296 minecraft:white_concrete
fill 136 198 297 136 199 298 minecraft:red_concrete
fill 136 198 299 136 199 300 minecraft:white_concrete
fill 136 198 301 136 199 302 minecraft:red_concrete
fill 136 198 303 136 199 304 minecraft:white_concrete
fill 136 198 305 136 199 306 minecraft:red_concrete
fill 136 198 307 136 199 308 minecraft:white_concrete
fill 136 198 309 136 199 310 minecraft:red_concrete
fill 136 198 311 136 199 312 minecraft:white_concrete
fill 136 198 313 136 199 314 minecraft:red_concrete
fill 136 198 315 136 199 316 minecraft:white_concrete
fill 136 198 317 136 199 317 minecraft:red_concrete
fill 109 199 277 109 199 279 minecraft:red_terracotta
fill 110 199 276 111 199 276 minecraft:red_terracotta
fill 110 199 280 112 199 280 minecraft:red_terracotta
fill 111 199 277 111 202 279 minecraft:iron_block
fill 112 199 277 112 202 277 minecraft:iron_block
fill 112 199 279 112 202 279 minecraft:iron_block
setblock 113 199 277 minecraft:red_terracotta
setblock 113 199 279 minecraft:red_terracotta
fill 131 199 297 131 199 299 minecraft:red_terracotta
setblock 131 199 306 minecraft:red_terracotta
setblock 131 199 308 minecraft:red_terracotta
fill 132 199 297 133 199 297 minecraft:red_terracotta
fill 132 199 299 133 199 299 minecraft:red_terracotta
setblock 133 199 298 minecraft:red_terracotta
setblock 133 199 306 minecraft:red_terracotta
setblock 133 199 308 minecraft:red_terracotta
fill 94 200 275 94 201 276 minecraft:red_concrete
fill 94 200 277 94 201 278 minecraft:white_concrete
fill 94 200 279 94 201 279 minecraft:red_concrete
fill 94 200 280 94 205 280 minecraft:shroomlight
fill 94 200 281 94 201 282 minecraft:white_concrete
fill 94 200 283 94 201 284 minecraft:red_concrete
fill 94 200 285 94 201 286 minecraft:white_concrete
fill 94 200 287 94 201 287 minecraft:red_concrete
fill 94 200 288 94 205 288 minecraft:shroomlight
fill 94 200 289 94 201 290 minecraft:white_concrete
fill 94 200 291 94 201 292 minecraft:red_concrete
fill 94 200 293 94 201 294 minecraft:white_concrete
fill 94 200 295 94 201 295 minecraft:red_concrete
fill 94 200 296 94 205 296 minecraft:shroomlight
fill 94 200 297 94 201 298 minecraft:white_concrete
fill 94 200 299 94 201 300 minecraft:red_concrete
fill 94 200 301 94 201 302 minecraft:white_concrete
fill 94 200 303 94 201 303 minecraft:red_concrete
fill 94 200 304 94 205 304 minecraft:shroomlight
fill 94 200 305 94 201 306 minecraft:white_concrete
fill 94 200 307 94 201 308 minecraft:red_concrete
fill 94 200 309 94 201 310 minecraft:white_concrete
fill 94 200 311 94 201 311 minecraft:red_concrete
fill 94 200 312 94 205 312 minecraft:shroomlight
fill 94 200 313 94 201 314 minecraft:white_concrete
fill 94 200 315 94 201 316 minecraft:red_concrete
fill 95 200 275 95 201 275 minecraft:red_concrete
fill 95 200 317 95 201 317 minecraft:red_concrete
fill 96 200 275 97 201 275 minecraft:white_concrete
fill 96 200 317 96 201 317 minecraft:white_concrete
setblock 97 200 278 minecraft:light[level=12]
setblock 97 200 285 minecraft:light[level=12]
setblock 97 200 292 minecraft:light[level=12]
setblock 97 200 299 minecraft:light[level=12]
setblock 97 200 306 minecraft:light[level=12]
setblock 97 200 313 minecraft:light[level=12]
fill 97 200 317 97 205 317 minecraft:shroomlight
fill 98 200 275 99 201 275 minecraft:red_concrete
fill 98 200 317 99 201 317 minecraft:red_concrete
fill 100 200 275 100 201 275 minecraft:white_concrete
fill 100 200 317 101 201 317 minecraft:white_concrete
fill 101 200 275 101 205 275 minecraft:shroomlight
fill 102 200 275 103 201 275 minecraft:red_concrete
fill 102 200 317 103 201 317 minecraft:red_concrete
fill 104 200 275 105 201 275 minecraft:white_concrete
setblock 104 200 278 minecraft:light[level=12]
setblock 104 200 285 minecraft:light[level=12]
setblock 104 200 292 minecraft:light[level=12]
setblock 104 200 299 minecraft:light[level=12]
setblock 104 200 306 minecraft:light[level=12]
setblock 104 200 313 minecraft:light[level=12]
fill 104 200 317 104 201 317 minecraft:white_concrete
fill 105 200 317 105 205 317 minecraft:shroomlight
fill 106 200 275 107 201 275 minecraft:red_concrete
fill 106 200 317 107 201 317 minecraft:red_concrete
fill 108 200 275 108 201 275 minecraft:white_concrete
fill 108 200 317 109 201 317 minecraft:white_concrete
fill 109 200 275 109 205 275 minecraft:shroomlight
fill 110 200 275 111 201 275 minecraft:red_concrete
fill 110 200 317 111 201 317 minecraft:red_concrete
setblock 111 200 285 minecraft:light[level=12]
setblock 111 200 292 minecraft:light[level=12]
setblock 111 200 299 minecraft:light[level=12]
setblock 111 200 306 minecraft:light[level=12]
setblock 111 200 313 minecraft:light[level=12]
fill 112 200 275 113 201 275 minecraft:white_concrete
fill 112 200 317 112 201 317 minecraft:white_concrete
fill 113 200 317 113 205 317 minecraft:shroomlight
fill 114 200 275 115 201 275 minecraft:red_concrete
fill 114 200 317 115 201 317 minecraft:red_concrete
fill 116 200 275 116 201 275 minecraft:white_concrete
fill 116 200 317 117 201 317 minecraft:white_concrete
fill 117 200 275 117 205 275 minecraft:shroomlight
fill 118 200 275 119 201 275 minecraft:red_concrete
setblock 118 200 278 minecraft:light[level=12]
setblock 118 200 285 minecraft:light[level=12]
setblock 118 200 299 minecraft:light[level=12]
setblock 118 200 306 minecraft:light[level=12]
setblock 118 200 313 minecraft:light[level=12]
fill 118 200 317 119 201 317 minecraft:red_concrete
fill 120 200 275 121 201 275 minecraft:white_concrete
fill 120 200 317 120 201 317 minecraft:white_concrete
fill 121 200 317 121 205 317 minecraft:shroomlight
fill 122 200 275 123 201 275 minecraft:red_concrete
fill 122 200 317 123 201 317 minecraft:red_concrete
fill 124 200 275 124 201 275 minecraft:white_concrete
fill 124 200 317 125 201 317 minecraft:white_concrete
fill 125 200 275 125 205 275 minecraft:shroomlight
setblock 125 200 285 minecraft:light[level=12]
setblock 125 200 292 minecraft:light[level=12]
setblock 125 200 299 minecraft:light[level=12]
setblock 125 200 306 minecraft:light[level=12]
setblock 125 200 313 minecraft:light[level=12]
fill 126 200 275 127 201 275 minecraft:red_concrete
fill 126 200 317 127 201 317 minecraft:red_concrete
fill 128 200 275 129 201 275 minecraft:white_concrete
fill 128 200 317 128 201 317 minecraft:white_concrete
fill 129 200 317 129 205 317 minecraft:shroomlight
fill 130 200 275 131 201 275 minecraft:red_concrete
fill 130 200 317 131 201 317 minecraft:red_concrete
fill 132 200 275 132 201 275 minecraft:white_concrete
setblock 132 200 278 minecraft:light[level=12]
setblock 132 200 285 minecraft:light[level=12]
setblock 132 200 292 minecraft:light[level=12]
setblock 132 200 299 minecraft:light[level=12]
setblock 132 200 313 minecraft:light[level=12]
fill 132 200 317 133 201 317 minecraft:white_concrete
fill 133 200 275 133 205 275 minecraft:shroomlight
fill 134 200 275 135 201 275 minecraft:red_concrete
fill 134 200 317 135 201 317 minecraft:red_concrete
fill 136 200 276 136 201 276 minecraft:red_concrete
fill 136 200 277 136 201 278 minecraft:white_concrete
fill 136 200 279 136 201 279 minecraft:red_concrete
fill 136 200 280 136 205 280 minecraft:shroomlight
fill 136 200 281 136 201 282 minecraft:white_concrete
fill 136 200 283 136 201 284 minecraft:red_concrete
fill 136 200 285 136 201 286 minecraft:white_concrete
fill 136 200 287 136 201 287 minecraft:red_concrete
fill 136 200 288 136 205 288 minecraft:shroomlight
fill 136 200 289 136 201 290 minecraft:white_concrete
fill 136 200 291 136 201 292 minecraft:red_concrete
fill 136 200 293 136 201 294 minecraft:white_concrete
fill 136 200 295 136 201 295 minecraft:red_concrete
fill 136 200 296 136 205 296 minecraft:shroomlight
fill 136 200 297 136 201 298 minecraft:white_concrete
fill 136 200 299 136 201 300 minecraft:red_concrete
fill 136 200 301 136 201 302 minecraft:white_concrete
fill 136 200 303 136 201 303 minecraft:red_concrete
fill 136 200 304 136 205 304 minecraft:shroomlight
fill 136 200 305 136 201 306 minecraft:white_concrete
fill 136 200 307 136 201 308 minecraft:red_concrete
fill 136 200 309 136 201 310 minecraft:white_concrete
fill 136 200 311 136 201 311 minecraft:red_concrete
fill 136 200 312 136 205 312 minecraft:shroomlight
fill 136 200 313 136 201 314 minecraft:white_concrete
fill 136 200 315 136 201 316 minecraft:red_concrete
fill 136 200 317 136 201 317 minecraft:white_concrete
fill 113 201 284 115 202 284 minecraft:red_concrete
fill 114 201 283 114 202 283 minecraft:red_concrete
fill 114 201 285 114 202 285 minecraft:red_concrete
fill 94 202 275 94 203 276 minecraft:white_concrete
fill 94 202 277 94 203 278 minecraft:red_concrete
fill 94 202 279 94 203 279 minecraft:white_concrete
fill 94 202 281 94 203 282 minecraft:red_concrete
fill 94 202 283 94 203 284 minecraft:white_concrete
fill 94 202 285 94 203 286 minecraft:red_concrete
fill 94 202 287 94 203 287 minecraft:white_concrete
fill 94 202 289 94 203 290 minecraft:red_concrete
fill 94 202 291 94 203 292 minecraft:white_concrete
fill 94 202 293 94 203 294 minecraft:red_concrete
fill 94 202 295 94 203 295 minecraft:white_concrete
fill 94 202 297 94 203 298 minecraft:red_concrete
fill 94 202 299 94 203 300 minecraft:white_concrete
fill 94 202 301 94 203 302 minecraft:red_concrete
fill 94 202 303 94 203 303 minecraft:white_concrete
fill 94 202 305 94 203 306 minecraft:red_concrete
fill 94 202 307 94 203 308 minecraft:white_concrete
fill 94 202 309 94 203 310 minecraft:red_concrete
fill 94 202 311 94 203 311 minecraft:white_concrete
fill 94 202 313 94 203 314 minecraft:red_concrete
fill 94 202 315 94 203 316 minecraft:white_concrete
fill 95 202 275 95 203 275 minecraft:white_concrete
fill 95 202 317 95 203 317 minecraft:white_concrete
fill 96 202 275 97 203 275 minecraft:red_concrete
fill 96 202 317 96 203 317 minecraft:red_concrete
setblock 97 202 278 minecraft:light[level=15]
setblock 97 202 286 minecraft:light[level=15]
setblock 97 202 294 minecraft:light[level=15]
setblock 97 202 302 minecraft:light[level=15]
setblock 97 202 310 minecraft:light[level=15]
fill 98 202 275 99 203 275 minecraft:white_concrete
fill 98 202 317 99 203 317 minecraft:white_concrete
fill 100 202 275 100 203 275 minecraft:red_concrete
fill 100 202 317 101 203 317 minecraft:red_concrete
fill 102 202 275 103 203 275 minecraft:white_concrete
fill 102 202 317 103 203 317 minecraft:white_concrete
fill 104 202 275 105 203 275 minecraft:red_concrete
fill 104 202 317 104 203 317 minecraft:red_concrete
setblock 105 202 278 minecraft:light[level=15]
setblock 105 202 286 minecraft:light[level=15]
setblock 105 202 294 minecraft:light[level=15]
setblock 105 202 302 minecraft:light[level=15]
setblock 105 202 310 minecraft:light[level=15]
fill 106 202 275 107 203 275 minecraft:white_concrete
fill 106 202 317 107 203 317 minecraft:white_concrete
fill 108 202 275 108 203 275 minecraft:red_concrete
fill 108 202 317 109 203 317 minecraft:red_concrete
fill 110 202 275 111 203 275 minecraft:white_concrete
fill 110 202 317 111 203 317 minecraft:white_concrete
fill 112 202 275 113 203 275 minecraft:red_concrete
fill 112 202 317 112 203 317 minecraft:red_concrete
setblock 113 202 278 minecraft:light[level=15]
setblock 113 202 286 minecraft:light[level=15]
setblock 113 202 294 minecraft:light[level=15]
setblock 113 202 302 minecraft:light[level=15]
setblock 113 202 310 minecraft:light[level=15]
fill 114 202 275 115 203 275 minecraft:white_concrete
fill 114 202 317 115 203 317 minecraft:white_concrete
fill 116 202 275 116 203 275 minecraft:red_concrete
fill 116 202 317 117 203 317 minecraft:red_concrete
fill 118 202 275 119 203 275 minecraft:white_concrete
fill 118 202 317 119 203 317 minecraft:white_concrete
fill 120 202 275 121 203 275 minecraft:red_concrete
fill 120 202 317 120 203 317 minecraft:red_concrete
setblock 121 202 278 minecraft:light[level=15]
setblock 121 202 286 minecraft:light[level=15]
setblock 121 202 294 minecraft:light[level=15]
setblock 121 202 302 minecraft:light[level=15]
setblock 121 202 310 minecraft:light[level=15]
fill 122 202 275 123 203 275 minecraft:white_concrete
fill 122 202 317 123 203 317 minecraft:white_concrete
fill 124 202 275 124 203 275 minecraft:red_concrete
fill 124 202 317 125 203 317 minecraft:red_concrete
fill 126 202 275 127 203 275 minecraft:white_concrete
fill 126 202 317 127 203 317 minecraft:white_concrete
fill 128 202 275 129 203 275 minecraft:red_concrete
fill 128 202 317 128 203 317 minecraft:red_concrete
setblock 129 202 278 minecraft:light[level=15]
setblock 129 202 286 minecraft:light[level=15]
setblock 129 202 294 minecraft:light[level=15]
setblock 129 202 302 minecraft:light[level=15]
setblock 129 202 310 minecraft:light[level=15]
fill 130 202 275 131 203 275 minecraft:white_concrete
fill 130 202 317 131 203 317 minecraft:white_concrete
fill 132 202 275 132 203 275 minecraft:red_concrete
fill 132 202 317 133 203 317 minecraft:red_concrete
fill 134 202 275 135 203 275 minecraft:white_concrete
fill 134 202 317 135 203 317 minecraft:white_concrete
fill 136 202 276 136 203 276 minecraft:white_concrete
fill 136 202 277 136 203 278 minecraft:red_concrete
fill 136 202 279 136 203 279 minecraft:white_concrete
fill 136 202 281 136 203 282 minecraft:red_concrete
fill 136 202 283 136 203 284 minecraft:white_concrete
fill 136 202 285 136 203 286 minecraft:red_concrete
fill 136 202 287 136 203 287 minecraft:white_concrete
fill 136 202 289 136 203 290 minecraft:red_concrete
fill 136 202 291 136 203 292 minecraft:white_concrete
fill 136 202 293 136 203 294 minecraft:red_concrete
fill 136 202 295 136 203 295 minecraft:white_concrete
fill 136 202 297 136 203 298 minecraft:red_concrete
fill 136 202 299 136 203 300 minecraft:white_concrete
fill 136 202 301 136 203 302 minecraft:red_concrete
fill 136 202 303 136 203 303 minecraft:white_concrete
fill 136 202 305 136 203 306 minecraft:red_concrete
fill 136 202 307 136 203 308 minecraft:white_concrete
fill 136 202 309 136 203 310 minecraft:red_concrete
fill 136 202 311 136 203 311 minecraft:white_concrete
fill 136 202 313 136 203 314 minecraft:red_concrete
fill 136 202 315 136 203 316 minecraft:white_concrete
fill 136 202 317 136 203 317 minecraft:red_concrete
fill 111 203 277 111 203 279 minecraft:red_terracotta
fill 112 203 277 113 203 277 minecraft:red_terracotta
fill 112 203 279 113 203 279 minecraft:red_terracotta
setblock 113 203 278 minecraft:red_terracotta
fill 94 204 275 94 205 276 minecraft:red_concrete
fill 94 204 277 94 205 278 minecraft:white_concrete
fill 94 204 279 94 205 279 minecraft:red_concrete
fill 94 204 281 94 205 282 minecraft:white_concrete
fill 94 204 283 94 205 284 minecraft:red_concrete
setblock 94 204 285 minecraft:iron_block
fill 94 204 286 94 205 286 minecraft:white_concrete
fill 94 204 287 94 205 287 minecraft:red_concrete
fill 94 204 289 94 205 290 minecraft:white_concrete
fill 94 204 291 94 205 292 minecraft:red_concrete
fill 94 204 293 94 205 294 minecraft:white_concrete
fill 94 204 295 94 205 295 minecraft:red_concrete
fill 94 204 297 94 205 298 minecraft:white_concrete
fill 94 204 299 94 205 300 minecraft:red_concrete
fill 94 204 301 94 205 302 minecraft:white_concrete
fill 94 204 303 94 205 303 minecraft:red_concrete
fill 94 204 305 94 205 306 minecraft:white_concrete
fill 94 204 307 94 205 308 minecraft:red_concrete
fill 94 204 309 94 205 310 minecraft:white_concrete
fill 94 204 311 94 205 311 minecraft:red_concrete
fill 94 204 313 94 205 314 minecraft:white_concrete
fill 94 204 315 94 205 316 minecraft:red_concrete
fill 95 204 275 95 205 275 minecraft:red_concrete
setblock 95 204 284 minecraft:iron_block
fill 95 204 285 97 204 285 minecraft:black_concrete
setblock 95 204 286 minecraft:iron_block
fill 95 204 317 95 205 317 minecraft:red_concrete
fill 96 204 275 97 205 275 minecraft:white_concrete
setblock 96 204 283 minecraft:iron_block
setblock 96 204 284 minecraft:black_concrete
setblock 96 204 286 minecraft:black_concrete
setblock 96 204 287 minecraft:iron_block
fill 96 204 317 96 205 317 minecraft:white_concrete
setblock 97 204 284 minecraft:iron_block
setblock 97 204 286 minecraft:iron_block
fill 98 204 275 99 205 275 minecraft:red_concrete
setblock 98 204 285 minecraft:iron_block
fill 98 204 317 99 205 317 minecraft:red_concrete
fill 100 204 275 100 205 275 minecraft:white_concrete
fill 100 204 317 101 205 317 minecraft:white_concrete
fill 102 204 275 103 205 275 minecraft:red_concrete
fill 102 204 317 103 205 317 minecraft:red_concrete
fill 104 204 275 105 205 275 minecraft:white_concrete
fill 104 204 317 104 205 317 minecraft:white_concrete
fill 106 204 275 107 205 275 minecraft:red_concrete
fill 106 204 317 107 205 317 minecraft:red_concrete
fill 108 204 275 108 205 275 minecraft:white_concrete
fill 108 204 317 109 205 317 minecraft:white_concrete
fill 110 204 275 111 205 275 minecraft:red_concrete
fill 110 204 317 111 205 317 minecraft:red_concrete
fill 111 204 277 111 207 279 minecraft:iron_block
fill 112 204 275 113 205 275 minecraft:white_concrete
fill 112 204 277 112 207 277 minecraft:iron_block
fill 112 204 279 112 207 279 minecraft:iron_block
fill 112 204 317 112 205 317 minecraft:white_concrete
fill 114 204 275 115 205 275 minecraft:red_concrete
fill 114 204 317 115 205 317 minecraft:red_concrete
fill 116 204 275 116 205 275 minecraft:white_concrete
fill 116 204 317 117 205 317 minecraft:white_concrete
fill 118 204 275 119 205 275 minecraft:red_concrete
fill 118 204 317 119 205 317 minecraft:red_concrete
fill 120 204 275 121 205 275 minecraft:white_concrete
fill 120 204 317 120 205 317 minecraft:white_concrete
fill 122 204 275 123 205 275 minecraft:red_concrete
fill 122 204 317 123 205 317 minecraft:red_concrete
fill 124 204 275 124 205 275 minecraft:white_concrete
fill 124 204 317 125 205 317 minecraft:white_concrete
fill 126 204 275 127 205 275 minecraft:red_concrete
fill 126 204 317 127 205 317 minecraft:red_concrete
fill 128 204 275 129 205 275 minecraft:white_concrete
fill 128 204 317 128 205 317 minecraft:white_concrete
fill 130 204 275 131 205 275 minecraft:red_concrete
fill 130 204 317 131 205 317 minecraft:red_concrete
fill 132 204 275 132 205 275 minecraft:white_concrete
fill 132 204 317 133 205 317 minecraft:white_concrete
fill 134 204 275 135 205 275 minecraft:red_concrete
fill 134 204 317 135 205 317 minecraft:red_concrete
fill 136 204 276 136 205 276 minecraft:red_concrete
fill 136 204 277 136 205 278 minecraft:white_concrete
fill 136 204 279 136 205 279 minecraft:red_concrete
fill 136 204 281 136 205 282 minecraft:white_concrete
fill 136 204 283 136 205 284 minecraft:red_concrete
fill 136 204 285 136 205 286 minecraft:white_concrete
fill 136 204 287 136 205 287 minecraft:red_concrete
fill 136 204 289 136 205 290 minecraft:white_concrete
fill 136 204 291 136 205 292 minecraft:red_concrete
fill 136 204 293 136 205 294 minecraft:white_concrete
fill 136 204 295 136 205 295 minecraft:red_concrete
fill 136 204 297 136 205 298 minecraft:white_concrete
fill 136 204 299 136 205 300 minecraft:red_concrete
fill 136 204 301 136 205 302 minecraft:white_concrete
fill 136 204 303 136 205 303 minecraft:red_concrete
fill 136 204 305 136 205 306 minecraft:white_concrete
fill 136 204 307 136 205 308 minecraft:red_concrete
fill 136 204 309 136 205 310 minecraft:white_concrete
fill 136 204 311 136 205 311 minecraft:red_concrete
fill 136 204 313 136 205 314 minecraft:white_concrete
fill 136 204 315 136 205 316 minecraft:red_concrete
fill 136 204 317 136 205 317 minecraft:white_concrete
setblock 94 205 285 minecraft:white_concrete
fill 104 205 286 106 206 286 minecraft:green_concrete
fill 105 205 285 106 206 285 minecraft:green_concrete
fill 105 205 287 105 206 287 minecraft:green_concrete
fill 109 205 277 109 205 279 minecraft:red_terracotta
fill 110 205 276 111 205 276 minecraft:red_terracotta
fill 110 205 280 112 205 280 minecraft:red_terracotta
fill 113 205 277 113 205 279 minecraft:red_terracotta
fill 131 205 297 131 205 299 minecraft:red_terracotta
setblock 131 205 306 minecraft:red_terracotta
setblock 131 205 308 minecraft:red_terracotta
fill 132 205 297 133 205 297 minecraft:red_terracotta
fill 132 205 299 133 205 299 minecraft:red_terracotta
setblock 133 205 298 minecraft:red_terracotta
setblock 133 205 306 minecraft:red_terracotta
setblock 133 205 308 minecraft:red_terracotta
fill 94 206 275 94 207 276 minecraft:white_concrete
fill 94 206 277 94 207 278 minecraft:red_concrete
fill 94 206 279 94 207 280 minecraft:white_concrete
fill 94 206 281 94 207 282 minecraft:red_concrete
fill 94 206 283 94 207 284 minecraft:white_concrete
fill 94 206 285 94 207 286 minecraft:red_concrete
fill 94 206 287 94 207 288 minecraft:white_concrete
fill 94 206 289 94 207 290 minecraft:red_concrete
fill 94 206 291 94 207 292 minecraft:white_concrete
fill 94 206 293 94 207 294 minecraft:red_concrete
fill 94 206 295 94 207 296 minecraft:white_concrete
fill 94 206 297 94 207 298 minecraft:red_concrete
fill 94 206 299 94 207 300 minecraft:white_concrete
fill 94 206 301 94 207 302 minecraft:red_concrete
fill 94 206 303 94 207 304 minecraft:white_concrete
fill 94 206 305 94 207 306 minecraft:red_concrete
fill 94 206 307 94 207 308 minecraft:white_concrete
fill 94 206 309 94 207 310 minecraft:red_concrete
fill 94 206 311 94 207 312 minecraft:white_concrete
fill 94 206 313 94 207 314 minecraft:red_concrete
fill 94 206 315 94 207 316 minecraft:white_concrete
fill 95 206 275 95 207 275 minecraft:white_concrete
fill 95 206 317 95 207 317 minecraft:white_concrete
fill 96 206 275 97 207 275 minecraft:red_concrete
fill 96 206 317 97 207 317 minecraft:red_concrete
setblock 97 206 278 minecraft:light[level=12]
setblock 97 206 285 minecraft:light[level=12]
setblock 97 206 292 minecraft:light[level=12]
setblock 97 206 299 minecraft:light[level=12]
setblock 97 206 306 minecraft:light[level=12]
setblock 97 206 313 minecraft:light[level=12]
fill 98 206 275 99 207 275 minecraft:white_concrete
fill 98 206 317 99 207 317 minecraft:white_concrete
fill 100 206 275 101 207 275 minecraft:red_concrete
fill 100 206 317 101 207 317 minecraft:red_concrete
fill 102 206 275 103 207 275 minecraft:white_concrete
fill 102 206 317 103 207 317 minecraft:white_concrete
fill 104 206 275 105 207 275 minecraft:red_concrete
setblock 104 206 278 minecraft:light[level=12]
setblock 104 206 285 minecraft:light[level=12]
setblock 104 206 292 minecraft:light[level=12]
setblock 104 206 299 minecraft:light[level=12]
setblock 104 206 306 minecraft:light[level=12]
setblock 104 206 313 minecraft:light[level=12]
fill 104 206 317 105 207 317 minecraft:red_concrete
fill 106 206 275 107 207 275 minecraft:white_concrete
fill 106 206 317 107 207 317 minecraft:white_concrete
fill 108 206 275 109 207 275 minecraft:red_concrete
fill 108 206 317 109 207 317 minecraft:red_concrete
fill 110 206 275 111 207 275 minecraft:white_concrete
fill 110 206 317 111 207 317 minecraft:white_concrete
setblock 111 206 285 minecraft:light[level=12]
setblock 111 206 292 minecraft:light[level=12]
setblock 111 206 299 minecraft:light[level=12]
setblock 111 206 306 minecraft:light[level=12]
setblock 111 206 313 minecraft:light[level=12]
fill 112 206 275 113 207 275 minecraft:red_concrete
fill 112 206 317 113 207 317 minecraft:red_concrete
fill 114 206 275 115 207 275 minecraft:white_concrete
fill 114 206 317 115 207 317 minecraft:white_concrete
fill 116 206 275 117 207 275 minecraft:red_concrete
fill 116 206 317 117 207 317 minecraft:red_concrete
fill 118 206 275 119 207 275 minecraft:white_concrete
setblock 118 206 278 minecraft:light[level=12]
setblock 118 206 285 minecraft:light[level=12]
setblock 118 206 299 minecraft:light[level=12]
setblock 118 206 306 minecraft:light[level=12]
setblock 118 206 313 minecraft:light[level=12]
fill 118 206 317 119 207 317 minecraft:white_concrete
fill 120 206 275 121 207 275 minecraft:red_concrete
fill 120 206 317 121 207 317 minecraft:red_concrete
fill 122 206 275 123 207 275 minecraft:white_concrete
fill 122 206 317 123 207 317 minecraft:white_concrete
fill 124 206 275 125 207 275 minecraft:red_concrete
fill 124 206 317 125 207 317 minecraft:red_concrete
setblock 125 206 285 minecraft:light[level=12]
setblock 125 206 292 minecraft:light[level=12]
setblock 125 206 299 minecraft:light[level=12]
setblock 125 206 306 minecraft:light[level=12]
setblock 125 206 313 minecraft:light[level=12]
fill 126 206 275 127 207 275 minecraft:white_concrete
fill 126 206 317 127 207 317 minecraft:white_concrete
fill 128 206 275 129 207 275 minecraft:red_concrete
fill 128 206 317 129 207 317 minecraft:red_concrete
fill 130 206 275 131 207 275 minecraft:white_concrete
fill 130 206 317 131 207 317 minecraft:white_concrete
fill 132 206 275 133 207 275 minecraft:red_concrete
setblock 132 206 278 minecraft:light[level=12]
setblock 132 206 285 minecraft:light[level=12]
setblock 132 206 292 minecraft:light[level=12]
setblock 132 206 299 minecraft:light[level=12]
setblock 132 206 313 minecraft:light[level=12]
fill 132 206 317 133 207 317 minecraft:red_concrete
fill 134 206 275 135 207 275 minecraft:white_concrete
fill 134 206 317 135 207 317 minecraft:white_concrete
fill 136 206 276 136 207 276 minecraft:white_concrete
fill 136 206 277 136 207 278 minecraft:red_concrete
fill 136 206 279 136 207 280 minecraft:white_concrete
fill 136 206 281 136 207 282 minecraft:red_concrete
fill 136 206 283 136 207 284 minecraft:white_concrete
fill 136 206 285 136 207 286 minecraft:red_concrete
fill 136 206 287 136 207 288 minecraft:white_concrete
fill 136 206 289 136 207 290 minecraft:red_concrete
fill 136 206 291 136 207 292 minecraft:white_concrete
fill 136 206 293 136 207 294 minecraft:red_concrete
fill 136 206 295 136 207 296 minecraft:white_concrete
fill 136 206 297 136 207 298 minecraft:red_concrete
fill 136 206 299 136 207 300 minecraft:white_concrete
fill 136 206 301 136 207 302 minecraft:red_concrete
fill 136 206 303 136 207 304 minecraft:white_concrete
fill 136 206 305 136 207 306 minecraft:red_concrete
fill 136 206 307 136 207 308 minecraft:white_concrete
fill 136 206 309 136 207 310 minecraft:red_concrete
fill 136 206 311 136 207 312 minecraft:white_concrete
fill 136 206 313 136 207 314 minecraft:red_concrete
fill 136 206 315 136 207 316 minecraft:white_concrete
fill 136 206 317 136 207 317 minecraft:red_concrete
fill 94 208 275 94 209 276 minecraft:red_concrete
fill 94 208 277 94 209 278 minecraft:white_concrete
fill 94 208 279 94 209 280 minecraft:red_concrete
fill 94 208 281 94 209 282 minecraft:white_concrete
fill 94 208 283 94 209 284 minecraft:red_concrete
fill 94 208 285 94 209 286 minecraft:white_concrete
fill 94 208 287 94 209 288 minecraft:red_concrete
fill 94 208 289 94 209 290 minecraft:white_concrete
fill 94 208 291 94 209 292 minecraft:red_concrete
fill 94 208 293 94 209 294 minecraft:white_concrete
fill 94 208 295 94 209 296 minecraft:red_concrete
fill 94 208 297 94 209 298 minecraft:white_concrete
fill 94 208 299 94 209 300 minecraft:red_concrete
fill 94 208 301 94 209 302 minecraft:white_concrete
fill 94 208 303 94 209 304 minecraft:red_concrete
fill 94 208 305 94 209 306 minecraft:white_concrete
fill 94 208 307 94 209 308 minecraft:red_concrete
fill 94 208 309 94 209 310 minecraft:white_concrete
fill 94 208 311 94 209 312 minecraft:red_concrete
fill 94 208 313 94 209 314 minecraft:white_concrete
fill 94 208 315 94 209 316 minecraft:red_concrete
fill 95 208 275 95 209 275 minecraft:red_concrete
fill 95 208 317 95 209 317 minecraft:red_concrete
fill 96 208 275 97 209 275 minecraft:white_concrete
fill 96 208 317 97 209 317 minecraft:white_concrete
fill 98 208 275 99 209 275 minecraft:red_concrete
fill 98 208 317 99 209 317 minecraft:red_concrete
fill 100 208 275 101 209 275 minecraft:white_concrete
fill 100 208 317 101 209 317 minecraft:white_concrete
fill 102 208 275 103 209 275 minecraft:red_concrete
fill 102 208 317 103 209 317 minecraft:red_concrete
fill 104 208 275 105 209 275 minecraft:white_concrete
fill 104 208 317 105 209 317 minecraft:white_concrete
fill 106 208 275 107 209 275 minecraft:red_concrete
fill 106 208 317 107 209 317 minecraft:red_concrete
fill 108 208 275 109 209 275 minecraft:white_concrete
fill 108 208 317 109 209 317 minecraft:white_concrete
fill 110 208 275 111 209 275 minecraft:red_concrete
fill 110 208 317 111 209 317 minecraft:red_concrete
fill 111 208 277 111 208 279 minecraft:red_terracotta
fill 112 208 275 113 209 275 minecraft:white_concrete
fill 112 208 277 113 208 277 minecraft:red_terracotta
fill 112 208 279 113 208 279 minecraft:red_terracotta
fill 112 208 317 113 209 317 minecraft:white_concrete
setblock 113 208 278 minecraft:red_terracotta
fill 114 208 275 115 209 275 minecraft:red_concrete
fill 114 208 317 115 209 317 minecraft:red_concrete
fill 116 208 275 117 209 275 minecraft:white_concrete
fill 116 208 317 117 209 317 minecraft:white_concrete
fill 118 208 275 119 209 275 minecraft:red_concrete
fill 118 208 317 119 209 317 minecraft:red_concrete
fill 120 208 275 121 209 275 minecraft:white_concrete
fill 120 208 317 121 209 317 minecraft:white_concrete
fill 122 208 275 123 209 275 minecraft:red_concrete
fill 122 208 317 123 209 317 minecraft:red_concrete
fill 124 208 275 125 209 275 minecraft:white_concrete
fill 124 208 317 125 209 317 minecraft:white_concrete
fill 126 208 275 127 209 275 minecraft:red_concrete
fill 126 208 317 127 209 317 minecraft:red_concrete
fill 128 208 275 129 209 275 minecraft:white_concrete
fill 128 208 317 129 209 317 minecraft:white_concrete
fill 130 208 275 131 209 275 minecraft:red_concrete
fill 130 208 317 131 209 317 minecraft:red_concrete
fill 132 208 275 133 209 275 minecraft:white_concrete
fill 132 208 317 133 209 317 minecraft:white_concrete
fill 134 208 275 135 209 275 minecraft:red_concrete
fill 134 208 307 135 209 307 minecraft:iron_block
fill 134 208 317 135 209 317 minecraft:red_concrete
fill 136 208 276 136 209 276 minecraft:red_concrete
fill 136 208 277 136 209 278 minecraft:white_concrete
fill 136 208 279 136 209 280 minecraft:red_concrete
fill 136 208 281 136 209 282 minecraft:white_concrete
fill 136 208 283 136 209 284 minecraft:red_concrete
fill 136 208 285 136 209 286 minecraft:white_concrete
fill 136 208 287 136 209 288 minecraft:red_concrete
fill 136 208 289 136 209 290 minecraft:white_concrete
fill 136 208 291 136 209 292 minecraft:red_concrete
fill 136 208 293 136 209 294 minecraft:white_concrete
fill 136 208 295 136 209 296 minecraft:red_concrete
fill 136 208 297 136 209 298 minecraft:white_concrete
fill 136 208 299 136 209 300 minecraft:red_concrete
fill 136 208 301 136 209 302 minecraft:white_concrete
fill 136 208 303 136 209 304 minecraft:red_concrete
fill 136 208 305 136 209 306 minecraft:white_concrete
fill 136 208 307 136 209 308 minecraft:red_concrete
fill 136 208 309 136 209 310 minecraft:white_concrete
fill 136 208 311 136 209 312 minecraft:red_concrete
fill 136 208 313 136 209 314 minecraft:white_concrete
fill 136 208 315 136 209 316 minecraft:red_concrete
fill 136 208 317 136 209 317 minecraft:white_concrete
fill 106 209 312 107 210 313 minecraft:red_concrete
fill 108 209 313 108 210 313 minecraft:red_concrete
fill 111 209 277 111 209 279 minecraft:iron_block
setblock 112 209 277 minecraft:iron_block
fill 112 209 279 112 212 279 minecraft:iron_block
setblock 130 209 307 minecraft:shroomlight
fill 94 210 275 94 211 276 minecraft:white_concrete
fill 94 210 277 94 211 278 minecraft:red_concrete
fill 94 210 279 94 211 280 minecraft:white_concrete
fill 94 210 281 94 211 282 minecraft:red_concrete
fill 94 210 283 94 211 284 minecraft:white_concrete
fill 94 210 285 94 211 286 minecraft:red_concrete
fill 94 210 287 94 211 288 minecraft:white_concrete
fill 94 210 289 94 211 290 minecraft:red_concrete
fill 94 210 291 94 211 292 minecraft:white_concrete
fill 94 210 293 94 211 294 minecraft:red_concrete
fill 94 210 295 94 211 296 minecraft:white_concrete
fill 94 210 297 94 211 298 minecraft:red_concrete
fill 94 210 299 94 211 300 minecraft:white_concrete
fill 94 210 301 94 211 302 minecraft:red_concrete
fill 94 210 303 94 211 304 minecraft:white_concrete
fill 94 210 305 94 211 306 minecraft:red_concrete
fill 94 210 307 94 211 308 minecraft:white_concrete
fill 94 210 309 94 211 310 minecraft:red_concrete
fill 94 210 311 94 211 312 minecraft:white_concrete
fill 94 210 313 94 211 314 minecraft:red_concrete
fill 94 210 315 94 211 316 minecraft:white_concrete
fill 95 210 275 95 211 275 minecraft:white_concrete
fill 95 210 276 95 211 281 minecraft:red_terracotta
fill 95 210 284 96 210 289 minecraft:red_terracotta
fill 95 210 292 96 210 297 minecraft:red_terracotta
fill 95 210 300 96 210 305 minecraft:red_terracotta
fill 95 210 308 96 210 313 minecraft:red_terracotta
fill 95 210 316 100 211 316 minecraft:red_terracotta
fill 95 210 317 95 211 317 minecraft:white_concrete
fill 96 210 275 97 211 275 minecraft:red_concrete
fill 96 210 277 96 210 283 minecraft:red_terracotta
fill 96 210 290 96 210 291 minecraft:red_terracotta
fill 96 210 298 96 210 299 minecraft:red_terracotta
fill 96 210 306 96 210 307 minecraft:red_terracotta
fill 96 210 314 96 210 315 minecraft:red_terracotta
fill 96 210 317 97 211 317 minecraft:red_concrete
fill 97 210 277 134 210 277 minecraft:red_terracotta
setblock 97 210 278 minecraft:light[level=15]
setblock 97 210 286 minecraft:light[level=15]
setblock 97 210 294 minecraft:light[level=15]
setblock 97 210 302 minecraft:light[level=15]
setblock 97 210 310 minecraft:light[level=15]
fill 97 210 315 135 210 315 minecraft:red_terracotta
fill 98 210 275 99 211 275 minecraft:white_concrete
fill 98 210 276 103 211 276 minecraft:red_terracotta
fill 98 210 317 99 211 317 minecraft:white_concrete
fill 100 210 275 101 211 275 minecraft:red_concrete
fill 100 210 317 101 211 317 minecraft:red_concrete
fill 102 210 275 103 211 275 minecraft:white_concrete
fill 102 210 317 103 211 317 minecraft:white_concrete
fill 103 210 316 108 211 316 minecraft:red_terracotta
fill 104 210 275 105 211 275 minecraft:red_concrete
fill 104 210 317 105 211 317 minecraft:red_concrete
setblock 105 210 278 minecraft:light[level=15]
setblock 105 210 286 minecraft:light[level=15]
setblock 105 210 294 minecraft:light[level=15]
setblock 105 210 302 minecraft:light[level=15]
setblock 105 210 310 minecraft:light[level=15]
fill 106 210 275 107 211 275 minecraft:white_concrete
fill 106 210 276 111 211 276 minecraft:red_terracotta
fill 106 210 317 107 211 317 minecraft:white_concrete
fill 108 210 275 109 211 275 minecraft:red_concrete
fill 108 210 317 109 211 317 minecraft:red_concrete
fill 110 210 275 111 211 275 minecraft:white_concrete
fill 110 210 317 111 211 317 minecraft:white_concrete
fill 111 210 278 111 212 279 minecraft:iron_block
fill 111 210 316 116 211 316 minecraft:red_terracotta
fill 112 210 275 113 211 275 minecraft:red_concrete
fill 112 210 317 113 211 317 minecraft:red_concrete
setblock 113 210 278 minecraft:light[level=15]
setblock 113 210 286 minecraft:light[level=15]
setblock 113 210 294 minecraft:light[level=15]
setblock 113 210 302 minecraft:light[level=15]
setblock 113 210 310 minecraft:light[level=15]
fill 114 210 275 115 211 275 minecraft:white_concrete
fill 114 210 276 119 211 276 minecraft:red_terracotta
fill 114 210 317 115 211 317 minecraft:white_concrete
fill 116 210 275 117 211 275 minecraft:red_concrete
fill 116 210 317 117 211 317 minecraft:red_concrete
fill 118 210 275 119 211 275 minecraft:white_concrete
fill 118 210 317 119 211 317 minecraft:white_concrete
fill 119 210 316 124 211 316 minecraft:red_terracotta
fill 120 210 275 121 211 275 minecraft:red_concrete
fill 120 210 317 121 211 317 minecraft:red_concrete
setblock 121 210 278 minecraft:light[level=15]
setblock 121 210 286 minecraft:light[level=15]
setblock 121 210 294 minecraft:light[level=15]
setblock 121 210 302 minecraft:light[level=15]
setblock 121 210 310 minecraft:light[level=15]
fill 122 210 275 123 211 275 minecraft:white_concrete
fill 122 210 276 127 211 276 minecraft:red_terracotta
fill 122 210 317 123 211 317 minecraft:white_concrete
fill 124 210 275 125 211 275 minecraft:red_concrete
fill 124 210 317 125 211 317 minecraft:red_concrete
fill 126 210 275 127 211 275 minecraft:white_concrete
fill 126 210 317 127 211 317 minecraft:white_concrete
fill 127 210 316 132 211 316 minecraft:red_terracotta
fill 128 210 275 129 211 275 minecraft:red_concrete
fill 128 210 317 129 211 317 minecraft:red_concrete
setblock 129 210 278 minecraft:light[level=15]
setblock 129 210 286 minecraft:light[level=15]
setblock 129 210 294 minecraft:light[level=15]
setblock 129 210 302 minecraft:light[level=15]
setblock 129 210 310 minecraft:light[level=15]
fill 130 210 275 131 211 275 minecraft:white_concrete
fill 130 210 276 135 211 276 minecraft:red_terracotta
fill 130 210 317 131 211 317 minecraft:white_concrete
fill 132 210 275 133 211 275 minecraft:red_concrete
fill 132 210 317 133 211 317 minecraft:red_concrete
fill 134 210 275 135 211 275 minecraft:white_concrete
fill 134 210 278 134 210 314 minecraft:red_terracotta
fill 134 210 317 135 211 317 minecraft:white_concrete
fill 135 210 279 135 211 284 minecraft:red_terracotta
fill 135 210 287 135 211 292 minecraft:red_terracotta
fill 135 210 295 135 211 300 minecraft:red_terracotta
fill 135 210 303 135 211 308 minecraft:red_terracotta
fill 135 210 311 135 211 314 minecraft:red_terracotta
fill 135 210 316 135 211 316 minecraft:red_terracotta
fill 136 210 276 136 211 276 minecraft:white_concrete
fill 136 210 277 136 211 278 minecraft:red_concrete
fill 136 210 279 136 211 280 minecraft:white_concrete
fill 136 210 281 136 211 282 minecraft:red_concrete
fill 136 210 283 136 211 284 minecraft:white_concrete
fill 136 210 285 136 211 286 minecraft:red_concrete
fill 136 210 287 136 211 288 minecraft:white_concrete
fill 136 210 289 136 211 290 minecraft:red_concrete
fill 136 210 291 136 211 292 minecraft:white_concrete
fill 136 210 293 136 211 294 minecraft:red_concrete
fill 136 210 295 136 211 296 minecraft:white_concrete
fill 136 210 297 136 211 298 minecraft:red_concrete
fill 136 210 299 136 211 300 minecraft:white_concrete
fill 136 210 301 136 211 302 minecraft:red_concrete
fill 136 210 303 136 211 304 minecraft:white_concrete
fill 136 210 305 136 211 306 minecraft:red_concrete
fill 136 210 307 136 211 308 minecraft:white_concrete
fill 136 210 309 136 211 310 minecraft:red_concrete
fill 136 210 311 136 211 312 minecraft:white_concrete
fill 136 210 313 136 211 314 minecraft:red_concrete
fill 136 210 315 136 211 316 minecraft:white_concrete
fill 136 210 317 136 211 317 minecraft:red_concrete
fill 95 211 284 95 211 289 minecraft:red_terracotta
fill 95 211 292 95 211 297 minecraft:red_terracotta
fill 95 211 300 95 211 305 minecraft:red_terracotta
fill 95 211 308 95 211 313 minecraft:red_terracotta
fill 109 211 277 109 211 279 minecraft:red_terracotta
fill 110 211 277 112 212 277 minecraft:iron_block
fill 110 211 280 112 211 280 minecraft:red_terracotta
fill 113 211 277 113 211 279 minecraft:red_terracotta
fill 131 211 297 131 211 299 minecraft:red_terracotta
setblock 131 211 306 minecraft:red_terracotta
setblock 131 211 308 minecraft:red_terracotta
fill 132 211 297 133 211 297 minecraft:red_terracotta
fill 132 211 299 133 211 299 minecraft:red_terracotta
setblock 133 211 298 minecraft:red_terracotta
setblock 133 211 306 minecraft:red_terracotta
setblock 133 211 308 minecraft:red_terracotta
setblock 135 211 315 minecraft:red_terracotta
fill 94 212 275 94 213 276 minecraft:red_concrete
fill 94 212 277 94 213 278 minecraft:white_concrete
fill 94 212 279 94 213 280 minecraft:red_concrete
fill 94 212 281 94 213 282 minecraft:white_concrete
fill 94 212 283 94 213 284 minecraft:red_concrete
fill 94 212 285 94 213 286 minecraft:white_concrete
fill 94 212 287 94 213 288 minecraft:red_concrete
fill 94 212 289 94 213 290 minecraft:white_concrete
fill 94 212 291 94 213 292 minecraft:red_concrete
fill 94 212 293 94 213 294 minecraft:white_concrete
fill 94 212 295 94 213 296 minecraft:red_concrete
fill 94 212 297 94 213 298 minecraft:white_concrete
fill 94 212 299 94 213 300 minecraft:red_concrete
fill 94 212 301 94 213 302 minecraft:white_concrete
fill 94 212 303 94 213 304 minecraft:red_concrete
fill 94 212 305 94 213 306 minecraft:white_concrete
fill 94 212 307 94 213 308 minecraft:red_concrete
fill 94 212 309 94 213 310 minecraft:white_concrete
fill 94 212 311 94 213 312 minecraft:red_concrete
fill 94 212 313 94 213 314 minecraft:white_concrete
fill 94 212 315 94 213 316 minecraft:red_concrete
fill 95 212 275 95 213 275 minecraft:red_concrete
fill 95 212 317 95 213 317 minecraft:red_concrete
fill 96 212 275 97 213 275 minecraft:white_concrete
fill 96 212 317 97 213 317 minecraft:white_concrete
setblock 97 212 278 minecraft:light[level=12]
setblock 97 212 285 minecraft:light[level=12]
setblock 97 212 292 minecraft:light[level=12]
setblock 97 212 299 minecraft:light[level=12]
setblock 97 212 306 minecraft:light[level=12]
setblock 97 212 313 minecraft:light[level=12]
fill 98 212 275 99 213 275 minecraft:red_concrete
fill 98 212 317 99 213 317 minecraft:red_concrete
fill 100 212 275 101 213 275 minecraft:white_concrete
fill 100 212 317 101 213 317 minecraft:white_concrete
fill 102 212 275 103 213 275 minecraft:red_concrete
fill 102 212 317 103 213 317 minecraft:red_concrete
fill 104 212 275 105 213 275 minecraft:white_concrete
setblock 104 212 278 minecraft:light[level=12]
setblock 104 212 285 minecraft:light[level=12]
setblock 104 212 292 minecraft:light[level=12]
setblock 104 212 299 minecraft:light[level=12]
setblock 104 212 306 minecraft:light[level=12]
setblock 104 212 313 minecraft:light[level=12]
fill 104 212 317 105 213 317 minecraft:white_concrete
fill 106 212 275 107 213 275 minecraft:red_concrete
fill 106 212 317 107 213 317 minecraft:red_concrete
fill 108 212 275 109 213 275 minecraft:white_concrete
fill 108 212 317 109 213 317 minecraft:white_concrete
fill 110 212 275 111 213 275 minecraft:red_concrete
fill 110 212 317 111 213 317 minecraft:red_concrete
setblock 111 212 285 minecraft:light[level=12]
setblock 111 212 292 minecraft:light[level=12]
setblock 111 212 299 minecraft:light[level=12]
setblock 111 212 306 minecraft:light[level=12]
setblock 111 212 313 minecraft:light[level=12]
fill 112 212 275 113 213 275 minecraft:white_concrete
fill 112 212 317 113 213 317 minecraft:white_concrete
fill 114 212 275 115 213 275 minecraft:red_concrete
fill 114 212 317 115 213 317 minecraft:red_concrete
fill 116 212 275 117 213 275 minecraft:white_concrete
fill 116 212 317 117 213 317 minecraft:white_concrete
fill 118 212 275 119 213 275 minecraft:red_concrete
setblock 118 212 278 minecraft:light[level=12]
setblock 118 212 285 minecraft:light[level=12]
setblock 118 212 299 minecraft:light[level=12]
setblock 118 212 306 minecraft:light[level=12]
setblock 118 212 313 minecraft:light[level=12]
fill 118 212 317 119 213 317 minecraft:red_concrete
fill 120 212 275 121 213 275 minecraft:white_concrete
fill 120 212 317 121 213 317 minecraft:white_concrete
fill 122 212 275 123 213 275 minecraft:red_concrete
fill 122 212 317 123 213 317 minecraft:red_concrete
fill 124 212 275 125 213 275 minecraft:white_concrete
fill 124 212 317 125 213 317 minecraft:white_concrete
setblock 125 212 285 minecraft:light[level=12]
setblock 125 212 292 minecraft:light[level=12]
setblock 125 212 299 minecraft:light[level=12]
setblock 125 212 306 minecraft:light[level=12]
setblock 125 212 313 minecraft:light[level=12]
fill 126 212 275 127 213 275 minecraft:red_concrete
fill 126 212 317 127 213 317 minecraft:red_concrete
fill 128 212 275 129 213 275 minecraft:white_concrete
fill 128 212 317 129 213 317 minecraft:white_concrete
fill 130 212 275 131 213 275 minecraft:red_concrete
fill 130 212 317 131 213 317 minecraft:red_concrete
fill 132 212 275 133 213 275 minecraft:white_concrete
setblock 132 212 278 minecraft:light[level=12]
setblock 132 212 285 minecraft:light[level=12]
setblock 132 212 292 minecraft:light[level=12]
setblock 132 212 299 minecraft:light[level=12]
setblock 132 212 313 minecraft:light[level=12]
fill 132 212 317 133 213 317 minecraft:white_concrete
fill 134 212 275 135 213 275 minecraft:red_concrete
fill 134 212 317 135 213 317 minecraft:red_concrete
fill 136 212 276 136 213 276 minecraft:red_concrete
fill 136 212 277 136 213 278 minecraft:white_concrete
fill 136 212 279 136 213 280 minecraft:red_concrete
fill 136 212 281 136 213 282 minecraft:white_concrete
fill 136 212 283 136 213 284 minecraft:red_concrete
fill 136 212 285 136 213 286 minecraft:white_concrete
fill 136 212 287 136 213 288 minecraft:red_concrete
fill 136 212 289 136 213 290 minecraft:white_concrete
fill 136 212 291 136 213 292 minecraft:red_concrete
fill 136 212 293 136 213 294 minecraft:white_concrete
fill 136 212 295 136 213 296 minecraft:red_concrete
fill 136 212 297 136 213 298 minecraft:white_concrete
fill 136 212 299 136 213 300 minecraft:red_concrete
fill 136 212 301 136 213 302 minecraft:white_concrete
fill 136 212 303 136 213 304 minecraft:red_concrete
fill 136 212 305 136 213 306 minecraft:white_concrete
fill 136 212 307 136 213 308 minecraft:red_concrete
fill 136 212 309 136 213 310 minecraft:white_concrete
fill 136 212 311 136 213 312 minecraft:red_concrete
fill 136 212 313 136 213 314 minecraft:white_concrete
fill 136 212 315 136 213 316 minecraft:red_concrete
fill 136 212 317 136 213 317 minecraft:white_concrete
fill 100 213 289 100 214 289 minecraft:red_concrete
fill 110 213 277 110 219 277 minecraft:iron_block
schedule function dropper:buildpart/62_4 1t
