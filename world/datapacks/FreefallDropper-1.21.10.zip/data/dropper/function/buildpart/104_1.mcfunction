fill 390 179 437 390 182 437 minecraft:bone_block
fill 393 179 435 393 182 435 minecraft:bone_block
fill 396 179 435 396 182 435 minecraft:bone_block
fill 396 179 437 396 182 437 minecraft:bone_block
fill 399 179 435 399 182 435 minecraft:bone_block
fill 399 179 437 399 182 437 minecraft:bone_block
fill 402 179 435 402 182 435 minecraft:bone_block
fill 402 179 437 403 182 437 minecraft:bone_block
fill 403 179 434 403 181 434 minecraft:bone_block
fill 403 179 436 403 183 436 minecraft:bone_block
fill 404 179 433 404 181 433 minecraft:bone_block
fill 404 179 439 404 181 439 minecraft:bone_block
fill 406 179 440 406 180 440 minecraft:bone_block
fill 407 179 433 408 182 433 minecraft:bone_block
fill 408 179 439 408 182 439 minecraft:bone_block
fill 409 179 435 409 183 435 minecraft:bone_block
fill 409 179 437 409 183 437 minecraft:bone_block
fill 378 180 426 378 185 428 minecraft:bone_block
fill 378 180 438 378 185 440 minecraft:bone_block
fill 378 180 450 378 185 452 minecraft:bone_block
fill 384 180 431 384 181 431 minecraft:bone_block
fill 384 180 441 384 181 441 minecraft:bone_block
fill 384 180 456 386 185 456 minecraft:bone_block
fill 387 180 431 387 181 431 minecraft:bone_block
fill 387 180 441 387 181 441 minecraft:bone_block
fill 388 180 418 390 185 418 minecraft:bone_block
fill 390 180 431 390 181 431 minecraft:bone_block
fill 390 180 441 390 181 441 minecraft:bone_block
fill 393 180 431 393 181 431 minecraft:bone_block
fill 393 180 441 393 181 441 minecraft:bone_block
fill 396 180 431 396 181 431 minecraft:bone_block
fill 396 180 441 396 181 441 minecraft:bone_block
fill 396 180 456 398 185 456 minecraft:bone_block
fill 399 180 431 399 181 431 minecraft:bone_block
fill 399 180 441 399 181 441 minecraft:bone_block
fill 400 180 418 402 185 418 minecraft:bone_block
fill 402 180 431 402 181 431 minecraft:bone_block
fill 402 180 441 402 181 441 minecraft:bone_block
fill 403 180 438 403 182 438 minecraft:bone_block
fill 405 180 432 407 181 432 minecraft:bone_block
setblock 407 180 440 minecraft:bone_block
fill 408 180 456 410 185 456 minecraft:bone_block
fill 409 180 434 409 182 434 minecraft:bone_block
fill 409 180 438 409 182 438 minecraft:bone_block
fill 412 180 418 414 185 418 minecraft:bone_block
fill 416 180 426 416 185 428 minecraft:bone_block
fill 416 180 438 416 185 440 minecraft:bone_block
fill 416 180 450 416 185 452 minecraft:bone_block
fill 384 181 432 384 182 432 minecraft:bone_block
fill 384 181 440 384 182 440 minecraft:bone_block
fill 387 181 432 387 182 432 minecraft:bone_block
fill 387 181 440 387 182 440 minecraft:bone_block
fill 390 181 432 390 182 432 minecraft:bone_block
fill 390 181 440 390 182 440 minecraft:bone_block
fill 393 181 432 393 182 432 minecraft:bone_block
fill 393 181 440 393 182 440 minecraft:bone_block
fill 396 181 432 396 182 432 minecraft:bone_block
fill 396 181 440 396 182 440 minecraft:bone_block
fill 399 181 432 399 182 432 minecraft:bone_block
fill 399 181 440 399 182 440 minecraft:bone_block
fill 402 181 432 402 182 432 minecraft:bone_block
fill 402 181 436 402 183 436 minecraft:bone_block
fill 402 181 440 402 182 440 minecraft:bone_block
setblock 379 182 419 minecraft:light[level=12]
setblock 379 182 427 minecraft:light[level=12]
setblock 379 182 435 minecraft:light[level=12]
setblock 379 182 443 minecraft:light[level=12]
setblock 379 182 451 minecraft:light[level=12]
fill 382 182 436 392 183 436 minecraft:bone_block
fill 384 182 433 384 182 434 minecraft:bone_block
fill 384 182 438 384 182 439 minecraft:bone_block
setblock 387 182 419 minecraft:light[level=12]
setblock 387 182 427 minecraft:light[level=12]
fill 387 182 433 387 182 434 minecraft:bone_block
fill 387 182 438 387 182 439 minecraft:bone_block
setblock 387 182 443 minecraft:light[level=12]
setblock 387 182 451 minecraft:light[level=12]
fill 390 182 433 390 182 434 minecraft:bone_block
fill 390 182 438 390 182 439 minecraft:bone_block
fill 393 182 433 393 182 434 minecraft:bone_block
setblock 393 182 439 minecraft:bone_block
setblock 395 182 419 minecraft:light[level=12]
setblock 395 182 427 minecraft:light[level=12]
setblock 395 182 435 minecraft:light[level=12]
fill 395 182 436 401 183 436 minecraft:bone_block
setblock 395 182 443 minecraft:light[level=12]
setblock 395 182 451 minecraft:light[level=12]
fill 396 182 433 396 182 434 minecraft:bone_block
fill 396 182 438 396 182 439 minecraft:bone_block
fill 399 182 433 399 182 434 minecraft:bone_block
fill 399 182 438 399 182 439 minecraft:bone_block
fill 402 182 433 402 182 434 minecraft:bone_block
fill 402 182 438 402 182 439 minecraft:bone_block
setblock 403 182 419 minecraft:light[level=12]
setblock 403 182 427 minecraft:light[level=12]
setblock 403 182 443 minecraft:light[level=12]
setblock 403 182 451 minecraft:light[level=12]
setblock 411 182 419 minecraft:light[level=12]
setblock 411 182 427 minecraft:light[level=12]
setblock 411 182 435 minecraft:light[level=12]
setblock 411 182 443 minecraft:light[level=12]
setblock 411 182 451 minecraft:light[level=12]
setblock 403 183 437 minecraft:bone_block
fill 405 183 434 408 183 434 minecraft:bone_block
fill 404 184 436 407 184 436 minecraft:bone_block
setblock 405 184 435 minecraft:bone_block
fill 405 184 437 406 184 437 minecraft:bone_block
fill 407 184 435 408 184 435 minecraft:bone_block
fill 410 184 420 410 184 422 minecraft:polished_blackstone
setblock 411 184 419 minecraft:polished_blackstone
fill 411 184 423 413 184 423 minecraft:polished_blackstone
fill 413 184 419 414 184 419 minecraft:polished_blackstone
fill 414 184 420 414 184 422 minecraft:polished_blackstone
fill 377 185 420 377 185 425 minecraft:polished_blackstone
fill 377 185 432 377 185 437 minecraft:polished_blackstone
fill 377 185 444 377 185 449 minecraft:polished_blackstone
fill 377 185 456 377 185 457 minecraft:polished_blackstone
fill 378 185 457 381 185 457 minecraft:polished_blackstone
fill 381 185 417 386 185 417 minecraft:polished_blackstone
fill 388 185 457 393 185 457 minecraft:polished_blackstone
fill 393 185 417 398 185 417 minecraft:polished_blackstone
fill 400 185 457 405 185 457 minecraft:polished_blackstone
fill 405 185 417 410 185 417 minecraft:polished_blackstone
fill 412 185 457 417 185 457 minecraft:polished_blackstone
fill 417 185 417 417 185 422 minecraft:polished_blackstone
fill 417 185 429 417 185 434 minecraft:polished_blackstone
fill 417 185 441 417 185 446 minecraft:polished_blackstone
fill 417 185 453 417 185 456 minecraft:polished_blackstone
fill 376 186 422 376 191 425 minecraft:shroomlight
fill 376 186 434 376 191 437 minecraft:shroomlight
fill 376 186 446 376 191 449 minecraft:shroomlight
fill 376 186 458 379 191 458 minecraft:shroomlight
fill 383 186 416 386 191 416 minecraft:shroomlight
fill 388 186 458 391 191 458 minecraft:shroomlight
fill 395 186 416 398 191 416 minecraft:shroomlight
fill 400 186 458 403 191 458 minecraft:shroomlight
fill 407 186 416 410 191 416 minecraft:shroomlight
fill 412 186 458 415 191 458 minecraft:shroomlight
fill 418 186 417 418 191 420 minecraft:shroomlight
fill 418 186 429 418 191 432 minecraft:shroomlight
fill 418 186 441 418 191 444 minecraft:shroomlight
fill 418 186 453 418 191 456 minecraft:shroomlight
setblock 379 190 419 minecraft:light[level=12]
setblock 379 190 427 minecraft:light[level=12]
setblock 379 190 435 minecraft:light[level=12]
setblock 379 190 443 minecraft:light[level=12]
setblock 379 190 451 minecraft:light[level=12]
setblock 387 190 419 minecraft:light[level=12]
setblock 387 190 427 minecraft:light[level=12]
setblock 387 190 435 minecraft:light[level=12]
setblock 387 190 443 minecraft:light[level=12]
setblock 387 190 451 minecraft:light[level=12]
setblock 395 190 419 minecraft:light[level=12]
setblock 395 190 427 minecraft:light[level=12]
setblock 395 190 435 minecraft:light[level=12]
setblock 395 190 443 minecraft:light[level=12]
setblock 395 190 451 minecraft:light[level=12]
setblock 403 190 419 minecraft:light[level=12]
setblock 403 190 427 minecraft:light[level=12]
setblock 403 190 435 minecraft:light[level=12]
setblock 403 190 443 minecraft:light[level=12]
setblock 403 190 451 minecraft:light[level=12]
setblock 411 190 419 minecraft:light[level=12]
setblock 411 190 427 minecraft:light[level=12]
setblock 411 190 435 minecraft:light[level=12]
setblock 411 190 443 minecraft:light[level=12]
setblock 411 190 451 minecraft:light[level=12]
fill 376 192 422 376 205 422 minecraft:deepslate_tiles
fill 376 192 423 376 192 424 minecraft:shroomlight
fill 376 192 425 376 205 425 minecraft:deepslate_tiles
fill 376 192 434 376 205 434 minecraft:deepslate_tiles
fill 376 192 435 376 192 436 minecraft:shroomlight
fill 376 192 437 376 205 437 minecraft:deepslate_tiles
fill 376 192 446 376 205 446 minecraft:deepslate_tiles
fill 376 192 447 376 192 448 minecraft:shroomlight
fill 376 192 449 376 205 449 minecraft:deepslate_tiles
fill 376 192 458 376 205 458 minecraft:deepslate_tiles
fill 377 192 458 378 192 458 minecraft:shroomlight
fill 379 192 458 379 205 458 minecraft:deepslate_tiles
fill 383 192 416 383 205 416 minecraft:deepslate_tiles
fill 384 192 416 385 192 416 minecraft:shroomlight
fill 386 192 416 386 205 416 minecraft:deepslate_tiles
fill 388 192 458 388 205 458 minecraft:deepslate_tiles
fill 389 192 458 390 192 458 minecraft:shroomlight
fill 391 192 458 391 205 458 minecraft:deepslate_tiles
fill 395 192 416 395 205 416 minecraft:deepslate_tiles
fill 396 192 416 397 192 416 minecraft:shroomlight
fill 398 192 416 398 205 416 minecraft:deepslate_tiles
fill 400 192 458 400 205 458 minecraft:deepslate_tiles
fill 401 192 458 402 192 458 minecraft:shroomlight
fill 403 192 458 403 205 458 minecraft:deepslate_tiles
fill 407 192 416 407 205 416 minecraft:deepslate_tiles
fill 408 192 416 409 192 416 minecraft:shroomlight
fill 410 192 416 410 205 416 minecraft:deepslate_tiles
fill 410 192 420 410 192 422 minecraft:polished_blackstone
setblock 411 192 419 minecraft:polished_blackstone
fill 411 192 423 413 192 423 minecraft:polished_blackstone
fill 412 192 458 412 205 458 minecraft:deepslate_tiles
fill 413 192 419 414 192 419 minecraft:polished_blackstone
fill 413 192 458 414 192 458 minecraft:shroomlight
fill 414 192 420 414 192 422 minecraft:polished_blackstone
fill 415 192 458 415 205 458 minecraft:deepslate_tiles
fill 418 192 417 418 205 417 minecraft:deepslate_tiles
fill 418 192 418 418 192 419 minecraft:shroomlight
fill 418 192 420 418 205 420 minecraft:deepslate_tiles
fill 418 192 429 418 205 429 minecraft:deepslate_tiles
fill 418 192 430 418 192 431 minecraft:shroomlight
fill 418 192 432 418 205 432 minecraft:deepslate_tiles
fill 418 192 441 418 205 441 minecraft:deepslate_tiles
fill 418 192 442 418 192 443 minecraft:shroomlight
fill 418 192 444 418 205 444 minecraft:deepslate_tiles
fill 418 192 453 418 205 453 minecraft:deepslate_tiles
fill 418 192 454 418 192 455 minecraft:shroomlight
fill 418 192 456 418 205 456 minecraft:deepslate_tiles
fill 376 193 423 376 205 424 minecraft:deepslate_tiles
fill 376 193 435 376 205 436 minecraft:deepslate_tiles
fill 376 193 447 376 205 448 minecraft:deepslate_tiles
fill 377 193 458 378 205 458 minecraft:deepslate_tiles
fill 384 193 416 385 205 416 minecraft:deepslate_tiles
fill 389 193 458 390 205 458 minecraft:deepslate_tiles
fill 396 193 416 397 205 416 minecraft:deepslate_tiles
fill 401 193 458 402 205 458 minecraft:deepslate_tiles
fill 408 193 416 409 205 416 minecraft:deepslate_tiles
fill 413 193 458 414 205 458 minecraft:deepslate_tiles
fill 418 193 418 418 205 419 minecraft:deepslate_tiles
fill 418 193 430 418 205 431 minecraft:deepslate_tiles
fill 418 193 442 418 205 443 minecraft:deepslate_tiles
fill 418 193 454 418 205 455 minecraft:deepslate_tiles
setblock 379 198 419 minecraft:light[level=12]
setblock 379 198 427 minecraft:light[level=12]
setblock 379 198 435 minecraft:light[level=12]
setblock 379 198 443 minecraft:light[level=12]
setblock 379 198 451 minecraft:light[level=12]
setblock 387 198 419 minecraft:light[level=12]
setblock 387 198 427 minecraft:light[level=12]
setblock 387 198 435 minecraft:light[level=12]
setblock 387 198 443 minecraft:light[level=12]
setblock 387 198 451 minecraft:light[level=12]
setblock 395 198 419 minecraft:light[level=12]
setblock 395 198 427 minecraft:light[level=12]
setblock 395 198 435 minecraft:light[level=12]
setblock 395 198 443 minecraft:light[level=12]
setblock 395 198 451 minecraft:light[level=12]
setblock 403 198 419 minecraft:light[level=12]
setblock 403 198 427 minecraft:light[level=12]
setblock 403 198 435 minecraft:light[level=12]
setblock 403 198 443 minecraft:light[level=12]
setblock 403 198 451 minecraft:light[level=12]
setblock 411 198 419 minecraft:light[level=12]
setblock 411 198 427 minecraft:light[level=12]
setblock 411 198 435 minecraft:light[level=12]
setblock 411 198 443 minecraft:light[level=12]
setblock 411 198 451 minecraft:light[level=12]
fill 378 200 426 378 205 428 minecraft:bone_block
fill 378 200 438 378 205 440 minecraft:bone_block
fill 378 200 450 378 205 452 minecraft:bone_block
fill 384 200 456 386 205 456 minecraft:bone_block
fill 388 200 418 390 205 418 minecraft:bone_block
fill 396 200 456 398 205 456 minecraft:bone_block
fill 400 200 418 402 205 418 minecraft:bone_block
fill 408 200 456 410 205 456 minecraft:bone_block
fill 410 200 420 410 200 422 minecraft:polished_blackstone
setblock 411 200 419 minecraft:polished_blackstone
fill 411 200 423 413 200 423 minecraft:polished_blackstone
fill 412 200 418 414 205 418 minecraft:bone_block
fill 413 200 419 414 200 419 minecraft:polished_blackstone
fill 414 200 420 414 200 422 minecraft:polished_blackstone
fill 416 200 426 416 205 428 minecraft:bone_block
fill 416 200 438 416 205 440 minecraft:bone_block
fill 416 200 450 416 205 452 minecraft:bone_block
fill 377 205 420 377 205 425 minecraft:polished_blackstone
fill 377 205 432 377 205 437 minecraft:polished_blackstone
fill 377 205 444 377 205 449 minecraft:polished_blackstone
fill 377 205 456 377 205 457 minecraft:polished_blackstone
fill 378 205 457 381 205 457 minecraft:polished_blackstone
fill 381 205 417 386 205 417 minecraft:polished_blackstone
fill 388 205 457 393 205 457 minecraft:polished_blackstone
fill 393 205 417 398 205 417 minecraft:polished_blackstone
fill 400 205 457 405 205 457 minecraft:polished_blackstone
fill 405 205 417 410 205 417 minecraft:polished_blackstone
fill 412 205 457 417 205 457 minecraft:polished_blackstone
fill 417 205 417 417 205 422 minecraft:polished_blackstone
fill 417 205 429 417 205 434 minecraft:polished_blackstone
fill 417 205 441 417 205 446 minecraft:polished_blackstone
fill 417 205 453 417 205 456 minecraft:polished_blackstone
fill 376 206 416 376 210 416 minecraft:deepslate_tiles
setblock 376 206 417 minecraft:polished_blackstone
fill 376 206 418 376 209 420 minecraft:deepslate_tiles
fill 376 206 421 376 207 421 minecraft:polished_blackstone
fill 376 206 422 376 211 425 minecraft:shroomlight
setblock 376 206 433 minecraft:polished_blackstone
fill 376 206 434 376 211 437 minecraft:shroomlight
setblock 376 206 441 minecraft:polished_blackstone
fill 376 206 442 376 206 445 minecraft:deepslate_tiles
fill 376 206 446 376 211 449 minecraft:shroomlight
fill 376 206 455 376 209 455 minecraft:deepslate_tiles
setblock 376 206 456 minecraft:polished_blackstone
fill 376 206 458 379 211 458 minecraft:shroomlight
setblock 379 206 419 minecraft:light[level=12]
setblock 379 206 427 minecraft:light[level=12]
setblock 379 206 435 minecraft:light[level=12]
setblock 379 206 443 minecraft:light[level=12]
setblock 379 206 451 minecraft:light[level=12]
fill 380 206 458 380 209 458 minecraft:deepslate_tiles
setblock 381 206 458 minecraft:polished_blackstone
fill 383 206 416 386 211 416 minecraft:shroomlight
setblock 383 206 458 minecraft:polished_blackstone
fill 384 206 458 384 209 458 minecraft:deepslate_tiles
setblock 385 206 458 minecraft:polished_blackstone
fill 386 206 458 386 209 458 minecraft:deepslate_tiles
fill 387 206 416 389 209 416 minecraft:deepslate_tiles
setblock 387 206 419 minecraft:light[level=12]
setblock 387 206 427 minecraft:light[level=12]
setblock 387 206 435 minecraft:light[level=12]
setblock 387 206 443 minecraft:light[level=12]
setblock 387 206 451 minecraft:light[level=12]
fill 388 206 458 391 211 458 minecraft:shroomlight
setblock 390 206 416 minecraft:polished_blackstone
fill 391 206 416 392 209 416 minecraft:deepslate_tiles
fill 392 206 458 392 207 458 minecraft:deepslate_tiles
setblock 393 206 458 minecraft:polished_blackstone
fill 394 206 458 396 207 458 minecraft:deepslate_tiles
fill 395 206 416 398 211 416 minecraft:shroomlight
setblock 395 206 419 minecraft:light[level=12]
setblock 395 206 427 minecraft:light[level=12]
setblock 395 206 435 minecraft:light[level=12]
setblock 395 206 443 minecraft:light[level=12]
setblock 395 206 451 minecraft:light[level=12]
fill 400 206 458 403 211 458 minecraft:shroomlight
setblock 403 206 419 minecraft:light[level=12]
setblock 403 206 427 minecraft:light[level=12]
setblock 403 206 435 minecraft:light[level=12]
setblock 403 206 443 minecraft:light[level=12]
setblock 403 206 451 minecraft:light[level=12]
fill 407 206 416 410 211 416 minecraft:shroomlight
fill 409 206 458 409 209 458 minecraft:deepslate_tiles
setblock 410 206 458 minecraft:polished_blackstone
setblock 411 206 419 minecraft:light[level=12]
setblock 411 206 427 minecraft:light[level=12]
setblock 411 206 435 minecraft:light[level=12]
setblock 411 206 443 minecraft:light[level=12]
setblock 411 206 451 minecraft:light[level=12]
fill 412 206 458 415 211 458 minecraft:shroomlight
fill 418 206 416 418 207 416 minecraft:polished_blackstone
fill 418 206 417 418 211 420 minecraft:shroomlight
fill 418 206 429 418 211 432 minecraft:shroomlight
fill 418 206 441 418 211 444 minecraft:shroomlight
fill 418 206 449 418 209 449 minecraft:deepslate_tiles
fill 418 206 450 418 206 451 minecraft:polished_blackstone
fill 418 206 453 418 211 456 minecraft:shroomlight
setblock 418 206 458 minecraft:polished_blackstone
fill 376 207 417 376 209 417 minecraft:deepslate_tiles
fill 376 207 433 376 209 433 minecraft:deepslate_tiles
fill 376 207 441 376 209 441 minecraft:deepslate_tiles
setblock 376 207 442 minecraft:polished_blackstone
fill 376 207 443 376 207 445 minecraft:deepslate_tiles
fill 376 207 456 376 209 456 minecraft:deepslate_tiles
setblock 377 207 416 minecraft:polished_blackstone
setblock 380 207 416 minecraft:polished_blackstone
fill 381 207 416 381 209 416 minecraft:deepslate_tiles
fill 381 207 458 381 209 458 minecraft:deepslate_tiles
fill 383 207 458 383 209 458 minecraft:deepslate_tiles
fill 385 207 458 385 209 458 minecraft:deepslate_tiles
fill 390 207 416 390 209 416 minecraft:deepslate_tiles
fill 393 207 458 393 209 458 minecraft:deepslate_tiles
fill 400 207 416 400 209 416 minecraft:deepslate_tiles
setblock 401 207 416 minecraft:polished_blackstone
fill 410 207 458 410 209 458 minecraft:deepslate_tiles
setblock 413 207 416 minecraft:polished_blackstone
setblock 416 207 458 minecraft:polished_blackstone
fill 418 207 437 418 209 438 minecraft:deepslate_tiles
setblock 418 207 439 minecraft:polished_blackstone
fill 418 207 440 418 209 440 minecraft:deepslate_tiles
setblock 418 207 448 minecraft:polished_blackstone
setblock 418 207 450 minecraft:polished_blackstone
fill 418 207 451 418 209 451 minecraft:deepslate_tiles
fill 418 207 458 418 209 458 minecraft:deepslate_tiles
fill 376 208 421 376 209 421 minecraft:deepslate_tiles
setblock 376 208 426 minecraft:polished_blackstone
fill 376 208 427 376 209 430 minecraft:deepslate_tiles
fill 376 208 431 376 208 432 minecraft:polished_blackstone
fill 376 208 442 376 209 444 minecraft:deepslate_tiles
setblock 376 208 445 minecraft:polished_blackstone
fill 376 208 450 376 210 450 minecraft:deepslate_tiles
setblock 376 208 451 minecraft:polished_blackstone
fill 376 208 452 376 209 454 minecraft:deepslate_tiles
setblock 376 208 457 minecraft:polished_blackstone
fill 377 208 416 377 209 416 minecraft:deepslate_tiles
setblock 379 208 416 minecraft:polished_blackstone
fill 380 208 416 380 209 416 minecraft:deepslate_tiles
setblock 382 208 416 minecraft:polished_blackstone
setblock 392 208 458 minecraft:polished_blackstone
fill 394 208 458 394 209 458 minecraft:deepslate_tiles
setblock 395 208 458 minecraft:polished_blackstone
fill 396 208 458 396 209 458 minecraft:deepslate_tiles
fill 398 208 458 398 209 458 minecraft:deepslate_tiles
setblock 399 208 458 minecraft:polished_blackstone
fill 401 208 416 401 209 416 minecraft:deepslate_tiles
fill 403 208 416 404 209 416 minecraft:deepslate_tiles
setblock 405 208 416 minecraft:polished_blackstone
fill 406 208 416 406 209 416 minecraft:deepslate_tiles
setblock 407 208 458 minecraft:polished_blackstone
fill 408 208 458 408 209 458 minecraft:deepslate_tiles
fill 410 208 420 410 208 422 minecraft:polished_blackstone
setblock 411 208 419 minecraft:polished_blackstone
fill 411 208 423 413 208 423 minecraft:polished_blackstone
fill 413 208 416 413 209 416 minecraft:deepslate_tiles
fill 413 208 419 414 208 419 minecraft:polished_blackstone
fill 414 208 420 414 208 422 minecraft:polished_blackstone
fill 416 208 458 416 209 458 minecraft:deepslate_tiles
fill 418 208 416 418 209 416 minecraft:deepslate_tiles
fill 418 208 439 418 209 439 minecraft:deepslate_tiles
fill 418 208 448 418 209 448 minecraft:deepslate_tiles
fill 418 208 450 418 209 450 minecraft:deepslate_tiles
setblock 418 208 457 minecraft:polished_blackstone
setblock 376 209 426 minecraft:deepslate_tiles
fill 376 209 431 376 209 432 minecraft:deepslate_tiles
fill 376 209 445 376 210 445 minecraft:deepslate_tiles
setblock 376 209 451 minecraft:deepslate_tiles
setblock 376 209 457 minecraft:deepslate_tiles
setblock 379 209 416 minecraft:deepslate_tiles
setblock 382 209 416 minecraft:deepslate_tiles
setblock 392 209 458 minecraft:deepslate_tiles
fill 395 209 458 395 210 458 minecraft:deepslate_tiles
setblock 399 209 458 minecraft:deepslate_tiles
fill 405 209 416 405 210 416 minecraft:deepslate_tiles
setblock 407 209 458 minecraft:deepslate_tiles
setblock 418 209 457 minecraft:deepslate_tiles
fill 376 210 417 376 210 421 minecraft:polished_blackstone
fill 376 210 426 376 307 427 minecraft:polished_blackstone
setblock 376 210 428 minecraft:deepslate_tiles
fill 376 210 429 376 307 429 minecraft:polished_blackstone
fill 376 210 430 376 210 431 minecraft:deepslate_tiles
fill 376 210 432 376 307 433 minecraft:polished_blackstone
fill 376 210 439 376 231 444 minecraft:polished_blackstone
fill 376 210 451 376 307 452 minecraft:polished_blackstone
setblock 376 210 453 minecraft:deepslate_tiles
fill 376 210 454 376 307 457 minecraft:polished_blackstone
fill 377 210 416 382 211 416 minecraft:polished_blackstone
fill 380 210 458 387 210 458 minecraft:polished_blackstone
fill 387 210 416 388 210 416 minecraft:deepslate_tiles
fill 389 210 416 394 211 416 minecraft:polished_blackstone
fill 392 210 458 394 210 458 minecraft:polished_blackstone
fill 396 210 458 399 211 458 minecraft:polished_blackstone
fill 399 210 416 402 211 416 minecraft:polished_blackstone
setblock 403 210 416 minecraft:deepslate_tiles
fill 404 210 416 404 307 416 minecraft:polished_blackstone
fill 404 210 458 405 307 458 minecraft:polished_blackstone
fill 406 210 416 406 307 416 minecraft:polished_blackstone
fill 406 210 458 406 211 458 minecraft:deepslate_tiles
fill 407 210 458 411 210 458 minecraft:polished_blackstone
fill 411 210 416 415 211 416 minecraft:polished_blackstone
setblock 416 210 416 minecraft:deepslate_tiles
fill 416 210 458 418 211 458 minecraft:polished_blackstone
fill 417 210 416 418 210 416 minecraft:polished_blackstone
fill 418 210 421 418 210 424 minecraft:polished_blackstone
fill 418 210 425 418 211 425 minecraft:deepslate_tiles
fill 418 210 426 418 210 427 minecraft:polished_blackstone
fill 418 210 433 418 307 440 minecraft:polished_blackstone
fill 418 210 446 418 210 452 minecraft:polished_blackstone
fill 418 210 457 418 307 457 minecraft:polished_blackstone
fill 376 211 416 376 211 417 minecraft:polished_blackstone
setblock 376 211 418 minecraft:deepslate_tiles
fill 376 211 419 376 307 421 minecraft:polished_blackstone
fill 376 211 428 376 307 428 minecraft:polished_blackstone
fill 376 211 430 376 307 431 minecraft:polished_blackstone
setblock 376 211 438 minecraft:polished_blackstone
fill 376 211 445 376 307 445 minecraft:polished_blackstone
fill 376 211 450 376 307 450 minecraft:polished_blackstone
fill 376 211 453 376 307 453 minecraft:polished_blackstone
fill 380 211 458 383 211 458 minecraft:polished_blackstone
setblock 384 211 458 minecraft:deepslate_tiles
fill 385 211 458 387 307 458 minecraft:polished_blackstone
fill 387 211 416 388 307 416 minecraft:polished_blackstone
fill 392 211 458 392 307 458 minecraft:polished_blackstone
setblock 393 211 458 minecraft:deepslate_tiles
fill 394 211 458 395 307 458 minecraft:polished_blackstone
fill 403 211 416 403 307 416 minecraft:polished_blackstone
setblock 405 211 416 minecraft:polished_blackstone
setblock 407 211 458 minecraft:deepslate_tiles
fill 408 211 458 411 307 458 minecraft:polished_blackstone
fill 416 211 416 417 307 416 minecraft:polished_blackstone
setblock 418 211 416 minecraft:deepslate_tiles
fill 418 211 421 418 211 423 minecraft:polished_blackstone
setblock 418 211 424 minecraft:deepslate_tiles
setblock 418 211 426 minecraft:deepslate_tiles
fill 418 211 427 418 307 428 minecraft:polished_blackstone
fill 418 211 445 418 307 451 minecraft:polished_blackstone
setblock 418 211 452 minecraft:deepslate_tiles
fill 376 212 416 381 307 416 minecraft:polished_blackstone
setblock 376 212 417 minecraft:deepslate_tiles
fill 376 212 418 376 307 418 minecraft:polished_blackstone
fill 376 212 422 376 225 422 minecraft:polished_blackstone
fill 376 212 423 376 212 424 minecraft:shroomlight
fill 376 212 425 376 225 425 minecraft:polished_blackstone
fill 376 212 434 376 225 434 minecraft:polished_blackstone
fill 376 212 435 376 212 436 minecraft:shroomlight
fill 376 212 437 376 225 437 minecraft:polished_blackstone
setblock 376 212 438 minecraft:deepslate_tiles
fill 376 212 446 376 225 446 minecraft:polished_blackstone
fill 376 212 447 376 212 448 minecraft:shroomlight
fill 376 212 449 376 225 449 minecraft:polished_blackstone
fill 376 212 458 376 225 458 minecraft:polished_blackstone
fill 377 212 458 378 212 458 minecraft:shroomlight
fill 379 212 458 379 225 458 minecraft:polished_blackstone
setblock 380 212 458 minecraft:deepslate_tiles
fill 381 212 458 384 307 458 minecraft:polished_blackstone
setblock 382 212 416 minecraft:deepslate_tiles
fill 383 212 416 383 225 416 minecraft:polished_blackstone
fill 384 212 416 385 212 416 minecraft:shroomlight
fill 386 212 416 386 225 416 minecraft:polished_blackstone
fill 388 212 458 388 225 458 minecraft:polished_blackstone
fill 389 212 416 390 307 416 minecraft:polished_blackstone
fill 389 212 458 390 212 458 minecraft:shroomlight
setblock 391 212 416 minecraft:deepslate_tiles
fill 391 212 458 391 225 458 minecraft:polished_blackstone
fill 392 212 416 395 225 416 minecraft:polished_blackstone
fill 393 212 458 393 307 458 minecraft:polished_blackstone
fill 396 212 416 397 212 416 minecraft:shroomlight
fill 396 212 458 396 307 458 minecraft:polished_blackstone
setblock 397 212 458 minecraft:deepslate_tiles
fill 398 212 416 399 225 416 minecraft:polished_blackstone
fill 398 212 458 400 225 458 minecraft:polished_blackstone
setblock 400 212 416 minecraft:deepslate_tiles
fill 401 212 416 402 307 416 minecraft:polished_blackstone
fill 401 212 458 402 212 458 minecraft:shroomlight
fill 403 212 458 403 225 458 minecraft:polished_blackstone
setblock 405 212 416 minecraft:deepslate_tiles
fill 406 212 458 407 307 458 minecraft:polished_blackstone
fill 407 212 416 407 225 416 minecraft:polished_blackstone
fill 408 212 416 409 212 416 minecraft:shroomlight
fill 410 212 416 411 225 416 minecraft:polished_blackstone
setblock 412 212 416 minecraft:deepslate_tiles
fill 412 212 458 412 225 458 minecraft:polished_blackstone
fill 413 212 416 415 307 416 minecraft:polished_blackstone
fill 413 212 458 414 212 458 minecraft:shroomlight
fill 415 212 458 416 225 458 minecraft:polished_blackstone
setblock 417 212 458 minecraft:deepslate_tiles
fill 418 212 416 418 225 417 minecraft:polished_blackstone
fill 418 212 418 418 212 419 minecraft:shroomlight
fill 418 212 420 418 225 422 minecraft:polished_blackstone
setblock 418 212 423 minecraft:deepslate_tiles
fill 418 212 424 418 307 426 minecraft:polished_blackstone
fill 418 212 429 418 225 429 minecraft:polished_blackstone
fill 418 212 430 418 212 431 minecraft:shroomlight
fill 418 212 432 418 225 432 minecraft:polished_blackstone
fill 418 212 441 418 225 441 minecraft:polished_blackstone
fill 418 212 442 418 212 443 minecraft:shroomlight
fill 418 212 444 418 225 444 minecraft:polished_blackstone
fill 418 212 452 418 225 453 minecraft:polished_blackstone
fill 418 212 454 418 212 455 minecraft:shroomlight
fill 418 212 456 418 225 456 minecraft:polished_blackstone
fill 418 212 458 418 307 458 minecraft:polished_blackstone
fill 376 213 417 376 307 417 minecraft:polished_blackstone
fill 376 213 423 376 225 424 minecraft:polished_blackstone
fill 376 213 435 376 225 436 minecraft:polished_blackstone
fill 376 213 438 376 231 438 minecraft:polished_blackstone
fill 376 213 447 376 225 448 minecraft:polished_blackstone
fill 377 213 458 378 225 458 minecraft:polished_blackstone
fill 380 213 458 380 307 458 minecraft:polished_blackstone
fill 382 213 416 382 307 416 minecraft:polished_blackstone
fill 384 213 416 385 225 416 minecraft:polished_blackstone
fill 389 213 458 390 225 458 minecraft:polished_blackstone
fill 391 213 416 391 307 416 minecraft:polished_blackstone
fill 396 213 416 397 225 416 minecraft:polished_blackstone
fill 397 213 458 397 307 458 minecraft:polished_blackstone
fill 400 213 416 400 307 416 minecraft:polished_blackstone
fill 401 213 458 402 225 458 minecraft:polished_blackstone
fill 405 213 416 405 307 416 minecraft:polished_blackstone
fill 408 213 416 409 225 416 minecraft:polished_blackstone
fill 408 213 417 410 214 417 minecraft:bone_block
fill 408 213 456 410 214 456 minecraft:bone_block
fill 410 213 457 410 214 457 minecraft:bone_block
fill 412 213 416 412 307 416 minecraft:polished_blackstone
fill 413 213 458 414 225 458 minecraft:polished_blackstone
fill 417 213 458 417 307 458 minecraft:polished_blackstone
fill 418 213 418 418 225 419 minecraft:polished_blackstone
fill 418 213 423 418 307 423 minecraft:polished_blackstone
fill 418 213 430 418 225 431 minecraft:polished_blackstone
fill 418 213 442 418 225 443 minecraft:polished_blackstone
fill 418 213 454 418 225 455 minecraft:polished_blackstone
setblock 379 214 419 minecraft:light[level=12]
setblock 379 214 427 minecraft:light[level=12]
setblock 379 214 435 minecraft:light[level=12]
setblock 379 214 443 minecraft:light[level=12]
setblock 379 214 451 minecraft:light[level=12]
setblock 387 214 419 minecraft:light[level=12]
setblock 387 214 427 minecraft:light[level=12]
setblock 387 214 435 minecraft:light[level=12]
setblock 387 214 443 minecraft:light[level=12]
setblock 387 214 451 minecraft:light[level=12]
setblock 395 214 419 minecraft:light[level=12]
setblock 395 214 427 minecraft:light[level=12]
setblock 395 214 435 minecraft:light[level=12]
setblock 395 214 443 minecraft:light[level=12]
setblock 395 214 451 minecraft:light[level=12]
setblock 403 214 419 minecraft:light[level=12]
setblock 403 214 427 minecraft:light[level=12]
setblock 403 214 435 minecraft:light[level=12]
setblock 403 214 443 minecraft:light[level=12]
setblock 403 214 451 minecraft:light[level=12]
fill 408 214 418 410 215 418 minecraft:bone_block
fill 408 214 455 410 215 455 minecraft:bone_block
fill 409 214 419 409 216 419 minecraft:bone_block
fill 409 214 454 409 216 454 minecraft:bone_block
setblock 411 214 419 minecraft:light[level=12]
setblock 411 214 427 minecraft:light[level=12]
setblock 411 214 435 minecraft:light[level=12]
setblock 411 214 443 minecraft:light[level=12]
setblock 411 214 451 minecraft:light[level=12]
fill 408 215 419 408 216 419 minecraft:bone_block
fill 408 215 454 408 216 454 minecraft:bone_block
setblock 409 215 417 minecraft:bone_block
fill 409 215 420 409 217 420 minecraft:bone_block
fill 409 215 453 409 217 453 minecraft:bone_block
setblock 409 215 456 minecraft:bone_block
fill 410 215 419 410 216 419 minecraft:bone_block
fill 410 215 454 410 216 454 minecraft:bone_block
fill 408 216 420 408 217 421 minecraft:bone_block
fill 408 216 452 408 217 453 minecraft:bone_block
setblock 409 216 417 minecraft:white_concrete
setblock 409 216 418 minecraft:bone_block
fill 409 216 421 410 217 421 minecraft:bone_block
fill 409 216 452 410 217 452 minecraft:bone_block
setblock 409 216 455 minecraft:bone_block
setblock 409 216 456 minecraft:white_concrete
fill 410 216 420 410 217 420 minecraft:bone_block
setblock 410 216 422 minecraft:polished_blackstone
fill 410 216 453 410 217 453 minecraft:bone_block
setblock 411 216 419 minecraft:polished_blackstone
fill 411 216 423 413 216 423 minecraft:polished_blackstone
fill 413 216 419 414 216 419 minecraft:polished_blackstone
fill 414 216 420 414 216 422 minecraft:polished_blackstone
fill 408 217 422 410 218 422 minecraft:bone_block
fill 408 217 451 410 218 451 minecraft:bone_block
setblock 409 217 419 minecraft:white_concrete
fill 409 217 423 409 219 423 minecraft:bone_block
fill 409 217 450 409 219 450 minecraft:bone_block
setblock 409 217 454 minecraft:white_concrete
fill 408 218 423 408 219 423 minecraft:bone_block
fill 408 218 450 408 219 450 minecraft:bone_block
setblock 409 218 420 minecraft:white_concrete
setblock 409 218 421 minecraft:bone_block
fill 409 218 424 409 220 424 minecraft:bone_block
fill 409 218 449 409 220 449 minecraft:bone_block
setblock 409 218 452 minecraft:bone_block
setblock 409 218 453 minecraft:white_concrete
fill 410 218 423 410 219 423 minecraft:bone_block
fill 410 218 450 410 219 450 minecraft:bone_block
fill 408 219 424 408 219 425 minecraft:bone_block
fill 408 219 448 408 219 449 minecraft:bone_block
setblock 409 219 421 minecraft:white_concrete
setblock 409 219 422 minecraft:bone_block
fill 409 219 425 409 221 426 minecraft:bone_block
fill 409 219 447 409 221 448 minecraft:bone_block
setblock 409 219 451 minecraft:bone_block
setblock 409 219 452 minecraft:white_concrete
fill 410 219 424 410 219 425 minecraft:bone_block
fill 410 219 448 410 219 449 minecraft:bone_block
fill 378 220 426 378 225 428 minecraft:bone_block
fill 378 220 438 378 225 440 minecraft:bone_block
fill 378 220 450 378 225 452 minecraft:bone_block
fill 384 220 456 386 225 456 minecraft:bone_block
fill 388 220 418 390 225 418 minecraft:bone_block
fill 396 220 456 398 225 456 minecraft:bone_block
fill 400 220 418 402 225 418 minecraft:bone_block
fill 408 220 425 408 220 427 minecraft:bone_block
fill 408 220 446 408 220 448 minecraft:bone_block
fill 408 220 456 410 225 456 minecraft:bone_block
fill 409 220 422 409 220 423 minecraft:white_concrete
fill 409 220 427 409 222 428 minecraft:bone_block
fill 409 220 445 409 222 446 minecraft:bone_block
fill 409 220 450 409 220 451 minecraft:white_concrete
fill 410 220 425 410 220 427 minecraft:bone_block
fill 410 220 446 410 220 448 minecraft:bone_block
fill 412 220 418 414 225 418 minecraft:bone_block
fill 416 220 426 416 225 428 minecraft:bone_block
fill 416 220 438 416 225 440 minecraft:bone_block
fill 416 220 450 416 225 452 minecraft:bone_block
fill 408 221 426 408 221 429 minecraft:bone_block
fill 408 221 444 408 221 447 minecraft:bone_block
setblock 409 221 424 minecraft:white_concrete
fill 409 221 429 409 223 430 minecraft:bone_block
fill 409 221 443 409 223 444 minecraft:bone_block
setblock 409 221 449 minecraft:white_concrete
fill 410 221 426 410 221 429 minecraft:bone_block
fill 410 221 444 410 221 447 minecraft:bone_block
setblock 379 222 419 minecraft:light[level=12]
setblock 379 222 427 minecraft:light[level=12]
setblock 379 222 435 minecraft:light[level=12]
setblock 379 222 443 minecraft:light[level=12]
setblock 379 222 451 minecraft:light[level=12]
setblock 387 222 419 minecraft:light[level=12]
setblock 387 222 427 minecraft:light[level=12]
setblock 387 222 435 minecraft:light[level=12]
setblock 387 222 443 minecraft:light[level=12]
setblock 387 222 451 minecraft:light[level=12]
setblock 395 222 419 minecraft:light[level=12]
setblock 395 222 427 minecraft:light[level=12]
setblock 395 222 435 minecraft:light[level=12]
setblock 395 222 443 minecraft:light[level=12]
setblock 395 222 451 minecraft:light[level=12]
setblock 403 222 419 minecraft:light[level=12]
setblock 403 222 427 minecraft:light[level=12]
setblock 403 222 435 minecraft:light[level=12]
setblock 403 222 443 minecraft:light[level=12]
setblock 403 222 451 minecraft:light[level=12]
fill 408 222 428 408 222 432 minecraft:bone_block
fill 408 222 441 408 222 445 minecraft:bone_block
setblock 409 222 426 minecraft:white_concrete
fill 409 222 431 409 223 442 minecraft:bone_block
setblock 409 222 447 minecraft:white_concrete
fill 410 222 424 414 223 427 minecraft:polished_blackstone
fill 410 222 428 410 222 432 minecraft:bone_block
fill 410 222 441 410 222 445 minecraft:bone_block
setblock 411 222 419 minecraft:light[level=12]
fill 411 222 428 414 223 428 minecraft:polished_blackstone
setblock 411 222 435 minecraft:light[level=12]
setblock 411 222 443 minecraft:light[level=12]
setblock 411 222 451 minecraft:light[level=12]
setblock 415 222 426 minecraft:polished_blackstone
fill 408 223 431 408 223 442 minecraft:bone_block
fill 409 223 427 409 223 428 minecraft:white_concrete
fill 409 223 445 409 223 446 minecraft:white_concrete
setblock 410 223 428 minecraft:polished_blackstone
fill 410 223 431 410 223 442 minecraft:bone_block
fill 408 224 434 410 224 439 minecraft:bone_block
fill 409 224 430 409 224 431 minecraft:white_concrete
fill 409 224 432 409 224 433 minecraft:bone_block
fill 409 224 440 409 224 441 minecraft:bone_block
fill 409 224 442 409 224 443 minecraft:white_concrete
fill 410 224 420 410 224 422 minecraft:polished_blackstone
setblock 411 224 419 minecraft:polished_blackstone
fill 411 224 423 413 224 423 minecraft:polished_blackstone
fill 411 224 426 413 226 426 minecraft:white_concrete
fill 412 224 425 412 226 425 minecraft:white_concrete
fill 412 224 427 412 226 427 minecraft:white_concrete
fill 413 224 419 414 224 419 minecraft:polished_blackstone
fill 414 224 420 414 224 422 minecraft:polished_blackstone
fill 377 225 420 377 225 425 minecraft:polished_blackstone
fill 377 225 432 377 225 437 minecraft:polished_blackstone
fill 377 225 444 377 225 449 minecraft:polished_blackstone
fill 377 225 456 377 225 457 minecraft:polished_blackstone
fill 378 225 457 381 225 457 minecraft:polished_blackstone
fill 381 225 417 386 225 417 minecraft:polished_blackstone
fill 388 225 457 393 225 457 minecraft:polished_blackstone
fill 393 225 417 398 225 417 minecraft:polished_blackstone
fill 400 225 457 405 225 457 minecraft:polished_blackstone
fill 405 225 417 410 225 417 minecraft:polished_blackstone
fill 409 225 433 409 225 440 minecraft:white_concrete
fill 410 225 420 410 226 421 minecraft:white_concrete
fill 411 225 419 411 226 419 minecraft:white_concrete
fill 412 225 423 412 226 423 minecraft:white_concrete
fill 412 225 457 417 225 457 minecraft:polished_blackstone
fill 413 225 419 413 226 419 minecraft:white_concrete
fill 414 225 420 414 226 422 minecraft:white_concrete
fill 417 225 417 417 225 422 minecraft:polished_blackstone
fill 417 225 429 417 225 434 minecraft:polished_blackstone
fill 417 225 441 417 225 446 minecraft:polished_blackstone
fill 417 225 453 417 225 456 minecraft:polished_blackstone
fill 376 226 422 376 226 425 minecraft:shroomlight
fill 376 226 434 376 226 437 minecraft:shroomlight
fill 376 226 446 376 226 449 minecraft:shroomlight
fill 376 226 458 379 226 458 minecraft:shroomlight
fill 383 226 416 386 226 416 minecraft:shroomlight
fill 388 226 458 391 226 458 minecraft:shroomlight
fill 392 226 416 394 307 416 minecraft:polished_blackstone
fill 395 226 416 398 226 416 minecraft:shroomlight
fill 398 226 458 399 307 458 minecraft:polished_blackstone
fill 399 226 416 399 307 416 minecraft:polished_blackstone
fill 400 226 458 403 226 458 minecraft:shroomlight
fill 407 226 416 410 226 416 minecraft:shroomlight
fill 411 226 416 411 307 416 minecraft:polished_blackstone
fill 412 226 458 415 226 458 minecraft:shroomlight
fill 416 226 458 416 307 458 minecraft:polished_blackstone
fill 418 226 416 418 307 416 minecraft:polished_blackstone
fill 418 226 417 418 226 420 minecraft:shroomlight
fill 418 226 421 418 307 422 minecraft:polished_blackstone
fill 418 226 429 418 226 432 minecraft:shroomlight
fill 418 226 441 418 226 444 minecraft:shroomlight
fill 418 226 452 418 307 452 minecraft:polished_blackstone
fill 418 226 453 418 226 456 minecraft:shroomlight
fill 376 227 422 376 245 425 minecraft:polished_blackstone
fill 376 227 434 376 231 437 minecraft:polished_blackstone
fill 376 227 446 376 245 449 minecraft:polished_blackstone
fill 376 227 458 379 245 458 minecraft:polished_blackstone
fill 383 227 416 386 245 416 minecraft:polished_blackstone
fill 388 227 458 391 245 458 minecraft:polished_blackstone
fill 395 227 416 398 245 416 minecraft:polished_blackstone
fill 400 227 458 403 245 458 minecraft:polished_blackstone
fill 407 227 416 410 245 416 minecraft:polished_blackstone
fill 412 227 458 415 245 458 minecraft:polished_blackstone
fill 418 227 417 418 245 420 minecraft:polished_blackstone
fill 418 227 429 418 245 432 minecraft:polished_blackstone
fill 418 227 441 418 245 444 minecraft:polished_blackstone
fill 418 227 453 418 245 456 minecraft:polished_blackstone
setblock 379 230 419 minecraft:light[level=12]
setblock 379 230 427 minecraft:light[level=12]
setblock 379 230 435 minecraft:light[level=12]
setblock 379 230 443 minecraft:light[level=12]
setblock 379 230 451 minecraft:light[level=12]
setblock 387 230 419 minecraft:light[level=12]
setblock 387 230 427 minecraft:light[level=12]
setblock 387 230 435 minecraft:light[level=12]
setblock 387 230 443 minecraft:light[level=12]
setblock 387 230 451 minecraft:light[level=12]
setblock 395 230 419 minecraft:light[level=12]
setblock 395 230 427 minecraft:light[level=12]
setblock 395 230 435 minecraft:light[level=12]
setblock 395 230 443 minecraft:light[level=12]
setblock 395 230 451 minecraft:light[level=12]
setblock 403 230 419 minecraft:light[level=12]
setblock 403 230 427 minecraft:light[level=12]
setblock 403 230 435 minecraft:light[level=12]
setblock 403 230 443 minecraft:light[level=12]
setblock 403 230 451 minecraft:light[level=12]
setblock 411 230 419 minecraft:light[level=12]
setblock 411 230 427 minecraft:light[level=12]
setblock 411 230 435 minecraft:light[level=12]
setblock 411 230 443 minecraft:light[level=12]
setblock 411 230 451 minecraft:light[level=12]
fill 376 232 434 376 245 435 minecraft:polished_blackstone
fill 376 232 436 391 232 440 minecraft:bone_block
fill 376 232 441 376 307 444 minecraft:polished_blackstone
fill 392 232 420 392 232 437 minecraft:bone_block
fill 392 232 439 392 232 456 minecraft:bone_block
fill 393 232 420 393 232 436 minecraft:bone_block
fill 393 232 440 393 232 456 minecraft:bone_block
fill 394 232 420 396 232 435 minecraft:bone_block
fill 394 232 441 396 232 456 minecraft:bone_block
fill 395 232 436 412 232 436 minecraft:bone_block
fill 395 232 440 412 232 440 minecraft:bone_block
fill 396 232 437 412 232 437 minecraft:bone_block
fill 396 232 439 412 232 439 minecraft:bone_block
fill 397 232 438 412 232 438 minecraft:bone_block
fill 376 233 436 391 233 436 minecraft:polished_blackstone
fill 376 233 437 390 233 439 minecraft:bone_block
fill 376 233 440 391 233 440 minecraft:polished_blackstone
fill 377 233 417 391 233 435 minecraft:deepslate_tiles
fill 377 233 441 391 233 457 minecraft:deepslate_tiles
fill 391 233 437 391 233 439 minecraft:shroomlight
fill 392 233 417 417 233 419 minecraft:deepslate_tiles
fill 392 233 420 392 233 435 minecraft:polished_blackstone
fill 392 233 436 392 233 437 minecraft:shroomlight
fill 392 233 439 392 233 440 minecraft:shroomlight
fill 392 233 441 392 233 456 minecraft:polished_blackstone
fill 392 233 457 417 233 457 minecraft:deepslate_tiles
fill 393 233 420 395 233 434 minecraft:bone_block
fill 393 233 435 393 233 436 minecraft:shroomlight
fill 393 233 440 393 233 441 minecraft:shroomlight
fill 393 233 442 395 233 456 minecraft:bone_block
fill 394 233 435 395 233 435 minecraft:shroomlight
fill 394 233 441 395 233 441 minecraft:shroomlight
fill 395 233 436 396 233 436 minecraft:shroomlight
fill 395 233 440 396 233 440 minecraft:shroomlight
fill 396 233 420 396 233 435 minecraft:polished_blackstone
fill 396 233 437 397 233 437 minecraft:shroomlight
fill 396 233 439 397 233 439 minecraft:shroomlight
fill 396 233 441 396 233 456 minecraft:polished_blackstone
fill 397 233 420 417 233 435 minecraft:deepslate_tiles
fill 397 233 436 412 233 436 minecraft:polished_blackstone
setblock 397 233 438 minecraft:shroomlight
fill 397 233 440 412 233 440 minecraft:polished_blackstone
fill 397 233 441 417 233 456 minecraft:deepslate_tiles
fill 398 233 437 412 233 439 minecraft:bone_block
fill 413 233 436 417 233 440 minecraft:deepslate_tiles
fill 376 234 436 376 245 440 minecraft:polished_blackstone
fill 377 237 417 379 273 417 minecraft:bone_block
fill 377 237 427 377 273 429 minecraft:bone_block
fill 377 237 439 377 273 441 minecraft:bone_block
fill 377 237 451 377 273 453 minecraft:bone_block
fill 383 237 457 385 273 457 minecraft:bone_block
fill 389 237 417 391 273 417 minecraft:bone_block
fill 395 237 457 397 273 457 minecraft:bone_block
fill 401 237 417 403 273 417 minecraft:bone_block
fill 407 237 457 409 273 457 minecraft:bone_block
fill 413 237 417 415 273 417 minecraft:bone_block
fill 417 237 425 417 273 427 minecraft:bone_block
fill 417 237 437 417 273 439 minecraft:bone_block
fill 417 237 449 417 273 451 minecraft:bone_block
setblock 379 238 419 minecraft:light[level=12]
setblock 379 238 427 minecraft:light[level=12]
setblock 379 238 435 minecraft:light[level=12]
setblock 379 238 443 minecraft:light[level=12]
setblock 379 238 451 minecraft:light[level=12]
setblock 387 238 419 minecraft:light[level=12]
setblock 387 238 427 minecraft:light[level=12]
setblock 387 238 435 minecraft:light[level=12]
setblock 387 238 443 minecraft:light[level=12]
setblock 387 238 451 minecraft:light[level=12]
setblock 395 238 419 minecraft:light[level=12]
setblock 395 238 427 minecraft:light[level=12]
setblock 395 238 435 minecraft:light[level=12]
setblock 395 238 443 minecraft:light[level=12]
setblock 395 238 451 minecraft:light[level=12]
setblock 403 238 419 minecraft:light[level=12]
setblock 403 238 427 minecraft:light[level=12]
setblock 403 238 435 minecraft:light[level=12]
setblock 403 238 443 minecraft:light[level=12]
setblock 403 238 451 minecraft:light[level=12]
setblock 411 238 419 minecraft:light[level=12]
setblock 411 238 427 minecraft:light[level=12]
setblock 411 238 435 minecraft:light[level=12]
setblock 411 238 443 minecraft:light[level=12]
setblock 411 238 451 minecraft:light[level=12]
fill 378 240 426 378 245 428 minecraft:bone_block
fill 378 240 438 378 245 440 minecraft:bone_block
fill 378 240 450 378 245 452 minecraft:bone_block
fill 384 240 456 386 245 456 minecraft:bone_block
fill 388 240 418 390 245 418 minecraft:bone_block
fill 396 240 456 398 245 456 minecraft:bone_block
fill 400 240 418 402 245 418 minecraft:bone_block
fill 408 240 456 410 245 456 minecraft:bone_block
fill 412 240 418 414 245 418 minecraft:bone_block
fill 416 240 426 416 245 428 minecraft:bone_block
fill 416 240 438 416 245 440 minecraft:bone_block
fill 416 240 450 416 245 452 minecraft:bone_block
fill 378 241 422 378 250 422 minecraft:black_wool
fill 378 242 420 378 250 421 minecraft:black_wool
fill 378 242 423 378 250 424 minecraft:black_wool
fill 377 245 420 377 245 425 minecraft:polished_blackstone
fill 377 245 432 377 245 437 minecraft:polished_blackstone
fill 377 245 444 377 245 449 minecraft:polished_blackstone
fill 377 245 456 377 245 457 minecraft:polished_blackstone
fill 378 245 457 381 245 457 minecraft:polished_blackstone
fill 381 245 417 386 245 417 minecraft:polished_blackstone
fill 388 245 457 393 245 457 minecraft:polished_blackstone
fill 393 245 417 398 245 417 minecraft:polished_blackstone
fill 400 245 457 405 245 457 minecraft:polished_blackstone
fill 405 245 417 410 245 417 minecraft:polished_blackstone
fill 412 245 457 417 245 457 minecraft:polished_blackstone
fill 417 245 417 417 245 422 minecraft:polished_blackstone
fill 417 245 429 417 245 434 minecraft:polished_blackstone
fill 417 245 441 417 245 446 minecraft:polished_blackstone
fill 417 245 453 417 245 456 minecraft:polished_blackstone
fill 376 246 422 376 251 425 minecraft:shroomlight
fill 376 246 434 376 251 437 minecraft:shroomlight
fill 376 246 438 376 307 440 minecraft:polished_blackstone
fill 376 246 446 376 251 449 minecraft:shroomlight
fill 376 246 458 379 251 458 minecraft:shroomlight
setblock 379 246 419 minecraft:light[level=12]
setblock 379 246 427 minecraft:light[level=12]
setblock 379 246 435 minecraft:light[level=12]
setblock 379 246 443 minecraft:light[level=12]
setblock 379 246 451 minecraft:light[level=12]
fill 383 246 416 386 251 416 minecraft:shroomlight
setblock 387 246 419 minecraft:light[level=12]
setblock 387 246 427 minecraft:light[level=12]
setblock 387 246 435 minecraft:light[level=12]
setblock 387 246 443 minecraft:light[level=12]
setblock 387 246 451 minecraft:light[level=12]
fill 388 246 458 391 251 458 minecraft:shroomlight
fill 395 246 416 398 251 416 minecraft:shroomlight
setblock 395 246 419 minecraft:light[level=12]
setblock 395 246 427 minecraft:light[level=12]
setblock 395 246 435 minecraft:light[level=12]
setblock 395 246 443 minecraft:light[level=12]
setblock 395 246 451 minecraft:light[level=12]
fill 400 246 458 403 251 458 minecraft:shroomlight
setblock 403 246 419 minecraft:light[level=12]
setblock 403 246 427 minecraft:light[level=12]
setblock 403 246 435 minecraft:light[level=12]
setblock 403 246 443 minecraft:light[level=12]
setblock 403 246 451 minecraft:light[level=12]
fill 407 246 416 410 251 416 minecraft:shroomlight
setblock 411 246 419 minecraft:light[level=12]
setblock 411 246 427 minecraft:light[level=12]
setblock 411 246 435 minecraft:light[level=12]
setblock 411 246 443 minecraft:light[level=12]
setblock 411 246 451 minecraft:light[level=12]
fill 412 246 458 415 251 458 minecraft:shroomlight
fill 418 246 417 418 251 420 minecraft:shroomlight
fill 418 246 429 418 251 432 minecraft:shroomlight
fill 418 246 441 418 251 444 minecraft:shroomlight
fill 418 246 453 418 251 456 minecraft:shroomlight
fill 399 249 418 399 262 418 minecraft:black_wool
fill 397 250 418 398 262 418 minecraft:black_wool
fill 400 250 418 401 259 418 minecraft:black_wool
fill 378 251 419 378 252 425 minecraft:iron_bars
fill 376 252 422 376 265 422 minecraft:polished_blackstone
fill 376 252 423 376 252 424 minecraft:shroomlight
fill 376 252 425 376 265 425 minecraft:polished_blackstone
fill 376 252 434 376 265 434 minecraft:polished_blackstone
fill 376 252 435 376 252 436 minecraft:shroomlight
fill 376 252 437 376 265 437 minecraft:polished_blackstone
fill 376 252 446 376 265 446 minecraft:polished_blackstone
fill 376 252 447 376 252 448 minecraft:shroomlight
fill 376 252 449 376 265 449 minecraft:polished_blackstone
fill 376 252 458 376 265 458 minecraft:polished_blackstone
fill 377 252 458 378 252 458 minecraft:shroomlight
fill 379 252 458 379 265 458 minecraft:polished_blackstone
fill 383 252 416 383 265 416 minecraft:polished_blackstone
fill 384 252 416 385 252 416 minecraft:shroomlight
fill 386 252 416 386 265 416 minecraft:polished_blackstone
fill 388 252 458 388 265 458 minecraft:polished_blackstone
fill 389 252 458 390 252 458 minecraft:shroomlight
fill 391 252 458 391 265 458 minecraft:polished_blackstone
fill 395 252 416 395 265 416 minecraft:polished_blackstone
fill 396 252 416 397 252 416 minecraft:shroomlight
fill 398 252 416 398 265 416 minecraft:polished_blackstone
fill 400 252 458 400 265 458 minecraft:polished_blackstone
fill 401 252 458 402 252 458 minecraft:shroomlight
fill 403 252 458 403 265 458 minecraft:polished_blackstone
fill 407 252 416 407 265 416 minecraft:polished_blackstone
fill 408 252 416 409 252 416 minecraft:shroomlight
fill 410 252 416 410 265 416 minecraft:polished_blackstone
fill 412 252 458 412 265 458 minecraft:polished_blackstone
fill 413 252 458 414 252 458 minecraft:shroomlight
fill 415 252 458 415 265 458 minecraft:polished_blackstone
fill 418 252 417 418 265 417 minecraft:polished_blackstone
fill 418 252 418 418 252 419 minecraft:shroomlight
fill 418 252 420 418 265 420 minecraft:polished_blackstone
fill 418 252 429 418 265 429 minecraft:polished_blackstone
fill 418 252 430 418 252 431 minecraft:shroomlight
fill 418 252 432 418 265 432 minecraft:polished_blackstone
fill 418 252 441 418 265 441 minecraft:polished_blackstone
fill 418 252 442 418 252 443 minecraft:shroomlight
fill 418 252 444 418 265 444 minecraft:polished_blackstone
fill 418 252 453 418 265 453 minecraft:polished_blackstone
fill 418 252 454 418 252 455 minecraft:shroomlight
fill 418 252 456 418 265 456 minecraft:polished_blackstone
fill 376 253 423 376 265 424 minecraft:polished_blackstone
fill 376 253 435 376 265 436 minecraft:polished_blackstone
fill 376 253 447 376 265 448 minecraft:polished_blackstone
fill 377 253 458 378 265 458 minecraft:polished_blackstone
fill 384 253 416 385 265 416 minecraft:polished_blackstone
fill 389 253 458 390 265 458 minecraft:polished_blackstone
fill 396 253 416 397 265 416 minecraft:polished_blackstone
fill 401 253 458 402 265 458 minecraft:polished_blackstone
fill 408 253 416 409 265 416 minecraft:polished_blackstone
fill 413 253 458 414 265 458 minecraft:polished_blackstone
fill 418 253 418 418 265 419 minecraft:polished_blackstone
fill 418 253 430 418 265 431 minecraft:polished_blackstone
fill 418 253 442 418 265 443 minecraft:polished_blackstone
fill 418 253 454 418 265 455 minecraft:polished_blackstone
setblock 379 254 419 minecraft:light[level=12]
setblock 379 254 427 minecraft:light[level=12]
setblock 379 254 435 minecraft:light[level=12]
setblock 379 254 443 minecraft:light[level=12]
setblock 379 254 451 minecraft:light[level=12]
setblock 387 254 419 minecraft:light[level=12]
setblock 387 254 427 minecraft:light[level=12]
setblock 387 254 435 minecraft:light[level=12]
setblock 387 254 443 minecraft:light[level=12]
setblock 387 254 451 minecraft:light[level=12]
setblock 395 254 419 minecraft:light[level=12]
setblock 395 254 427 minecraft:light[level=12]
setblock 395 254 443 minecraft:light[level=12]
setblock 395 254 451 minecraft:light[level=12]
setblock 403 254 419 minecraft:light[level=12]
setblock 403 254 427 minecraft:light[level=12]
setblock 403 254 435 minecraft:light[level=12]
setblock 403 254 443 minecraft:light[level=12]
setblock 403 254 451 minecraft:light[level=12]
setblock 411 254 419 minecraft:light[level=12]
setblock 411 254 427 minecraft:light[level=12]
setblock 411 254 435 minecraft:light[level=12]
setblock 411 254 443 minecraft:light[level=12]
setblock 411 254 451 minecraft:light[level=12]
fill 377 259 449 383 259 449 minecraft:polished_blackstone
fill 379 259 447 383 260 448 minecraft:polished_blackstone
fill 379 259 450 383 260 451 minecraft:polished_blackstone
fill 378 260 426 378 265 428 minecraft:bone_block
fill 378 260 438 378 265 440 minecraft:bone_block
fill 378 260 450 378 265 452 minecraft:bone_block
fill 379 260 449 383 260 449 minecraft:polished_blackstone
fill 384 260 456 386 265 456 minecraft:bone_block
fill 388 260 418 390 265 418 minecraft:bone_block
fill 396 260 456 398 265 456 minecraft:bone_block
fill 400 260 418 402 265 418 minecraft:bone_block
fill 408 260 456 410 265 456 minecraft:bone_block
fill 412 260 418 414 265 418 minecraft:bone_block
fill 416 260 426 416 265 428 minecraft:bone_block
fill 416 260 438 416 265 440 minecraft:bone_block
fill 416 260 450 416 265 452 minecraft:bone_block
fill 377 261 448 379 262 448 minecraft:bone_block
fill 377 261 450 377 262 450 minecraft:bone_block
fill 378 261 449 378 262 449 minecraft:bone_block
fill 379 261 450 379 262 450 minecraft:bone_block
setblock 379 262 419 minecraft:light[level=12]
setblock 379 262 427 minecraft:light[level=12]
setblock 379 262 435 minecraft:light[level=12]
setblock 379 262 443 minecraft:light[level=12]
fill 379 262 449 380 263 449 minecraft:bone_block
setblock 379 262 451 minecraft:light[level=12]
setblock 387 262 419 minecraft:light[level=12]
setblock 387 262 427 minecraft:light[level=12]
setblock 387 262 435 minecraft:light[level=12]
setblock 387 262 443 minecraft:light[level=12]
setblock 387 262 451 minecraft:light[level=12]
setblock 395 262 419 minecraft:light[level=12]
setblock 395 262 427 minecraft:light[level=12]
setblock 395 262 443 minecraft:light[level=12]
setblock 395 262 451 minecraft:light[level=12]
setblock 403 262 419 minecraft:light[level=12]
setblock 403 262 427 minecraft:light[level=12]
setblock 403 262 435 minecraft:light[level=12]
setblock 403 262 443 minecraft:light[level=12]
setblock 403 262 451 minecraft:light[level=12]
setblock 411 262 419 minecraft:light[level=12]
setblock 411 262 427 minecraft:light[level=12]
setblock 411 262 435 minecraft:light[level=12]
setblock 411 262 443 minecraft:light[level=12]
setblock 411 262 451 minecraft:light[level=12]
fill 381 263 449 381 264 449 minecraft:bone_block
fill 396 263 418 399 264 418 minecraft:iron_bars
fill 382 264 449 383 265 449 minecraft:bone_block
fill 377 265 420 377 265 425 minecraft:polished_blackstone
fill 377 265 432 377 265 437 minecraft:polished_blackstone
fill 377 265 444 377 265 449 minecraft:polished_blackstone
fill 377 265 456 377 265 457 minecraft:polished_blackstone
fill 378 265 457 381 265 457 minecraft:polished_blackstone
fill 381 265 417 386 265 417 minecraft:polished_blackstone
fill 383 265 448 385 266 448 minecraft:bone_block
fill 383 265 450 385 266 450 minecraft:bone_block
fill 384 265 449 384 266 449 minecraft:bone_block
fill 388 265 457 393 265 457 minecraft:polished_blackstone
fill 393 265 417 398 265 417 minecraft:polished_blackstone
fill 400 265 457 405 265 457 minecraft:polished_blackstone
fill 405 265 417 410 265 417 minecraft:polished_blackstone
fill 412 265 457 417 265 457 minecraft:polished_blackstone
fill 417 265 417 417 265 422 minecraft:polished_blackstone
fill 417 265 429 417 265 434 minecraft:polished_blackstone
fill 417 265 441 417 265 446 minecraft:polished_blackstone
fill 417 265 453 417 265 456 minecraft:polished_blackstone
fill 376 266 422 376 271 425 minecraft:shroomlight
fill 376 266 434 376 271 437 minecraft:shroomlight
fill 376 266 446 376 271 449 minecraft:shroomlight
fill 376 266 458 379 271 458 minecraft:shroomlight
fill 383 266 416 386 271 416 minecraft:shroomlight
fill 388 266 458 391 271 458 minecraft:shroomlight
fill 395 266 416 398 271 416 minecraft:shroomlight
fill 400 266 458 403 271 458 minecraft:shroomlight
fill 407 266 416 410 271 416 minecraft:shroomlight
fill 412 266 458 415 271 458 minecraft:shroomlight
fill 418 266 417 418 271 420 minecraft:shroomlight
fill 418 266 429 418 271 432 minecraft:shroomlight
fill 418 266 441 418 271 444 minecraft:shroomlight
fill 418 266 453 418 271 456 minecraft:shroomlight
setblock 379 270 419 minecraft:light[level=12]
setblock 379 270 427 minecraft:light[level=12]
setblock 379 270 435 minecraft:light[level=12]
setblock 379 270 443 minecraft:light[level=12]
setblock 379 270 451 minecraft:light[level=12]
setblock 387 270 419 minecraft:light[level=12]
setblock 387 270 427 minecraft:light[level=12]
setblock 387 270 435 minecraft:light[level=12]
setblock 387 270 443 minecraft:light[level=12]
setblock 387 270 451 minecraft:light[level=12]
setblock 395 270 419 minecraft:light[level=12]
setblock 395 270 427 minecraft:light[level=12]
setblock 395 270 443 minecraft:light[level=12]
setblock 395 270 451 minecraft:light[level=12]
setblock 403 270 419 minecraft:light[level=12]
setblock 403 270 427 minecraft:light[level=12]
setblock 403 270 435 minecraft:light[level=12]
setblock 403 270 443 minecraft:light[level=12]
setblock 403 270 451 minecraft:light[level=12]
setblock 411 270 419 minecraft:light[level=12]
setblock 411 270 427 minecraft:light[level=12]
setblock 411 270 435 minecraft:light[level=12]
setblock 411 270 443 minecraft:light[level=12]
setblock 411 270 451 minecraft:light[level=12]
fill 376 272 422 376 285 422 minecraft:polished_blackstone
fill 376 272 423 376 272 424 minecraft:shroomlight
fill 376 272 425 376 285 425 minecraft:polished_blackstone
fill 376 272 434 376 285 434 minecraft:polished_blackstone
fill 376 272 435 376 272 436 minecraft:shroomlight
fill 376 272 437 376 285 437 minecraft:polished_blackstone
fill 376 272 446 376 285 446 minecraft:polished_blackstone
fill 376 272 447 376 272 448 minecraft:shroomlight
fill 376 272 449 376 285 449 minecraft:polished_blackstone
fill 376 272 458 376 285 458 minecraft:polished_blackstone
fill 377 272 458 378 272 458 minecraft:shroomlight
fill 379 272 458 379 285 458 minecraft:polished_blackstone
fill 383 272 416 383 285 416 minecraft:polished_blackstone
fill 384 272 416 385 272 416 minecraft:shroomlight
fill 386 272 416 386 285 416 minecraft:polished_blackstone
fill 388 272 458 388 285 458 minecraft:polished_blackstone
fill 389 272 458 390 272 458 minecraft:shroomlight
fill 391 272 458 391 285 458 minecraft:polished_blackstone
fill 395 272 416 395 285 416 minecraft:polished_blackstone
fill 396 272 416 397 272 416 minecraft:shroomlight
fill 398 272 416 398 285 416 minecraft:polished_blackstone
fill 400 272 458 400 285 458 minecraft:polished_blackstone
fill 401 272 458 402 272 458 minecraft:shroomlight
fill 403 272 458 403 285 458 minecraft:polished_blackstone
fill 407 272 416 407 285 416 minecraft:polished_blackstone
fill 408 272 416 409 272 416 minecraft:shroomlight
fill 410 272 416 410 285 416 minecraft:polished_blackstone
fill 412 272 458 412 285 458 minecraft:polished_blackstone
fill 413 272 458 414 272 458 minecraft:shroomlight
fill 415 272 458 415 285 458 minecraft:polished_blackstone
fill 418 272 417 418 285 417 minecraft:polished_blackstone
fill 418 272 418 418 272 419 minecraft:shroomlight
fill 418 272 420 418 285 420 minecraft:polished_blackstone
fill 418 272 429 418 285 429 minecraft:polished_blackstone
fill 418 272 430 418 272 431 minecraft:shroomlight
fill 418 272 432 418 285 432 minecraft:polished_blackstone
fill 418 272 441 418 285 441 minecraft:polished_blackstone
fill 418 272 442 418 272 443 minecraft:shroomlight
fill 418 272 444 418 285 444 minecraft:polished_blackstone
fill 418 272 453 418 285 453 minecraft:polished_blackstone
fill 418 272 454 418 272 455 minecraft:shroomlight
fill 418 272 456 418 285 456 minecraft:polished_blackstone
fill 376 273 423 376 285 424 minecraft:polished_blackstone
fill 376 273 435 376 285 436 minecraft:polished_blackstone
fill 376 273 447 376 285 448 minecraft:polished_blackstone
fill 377 273 458 378 285 458 minecraft:polished_blackstone
fill 384 273 416 385 285 416 minecraft:polished_blackstone
fill 389 273 458 390 285 458 minecraft:polished_blackstone
fill 396 273 416 397 285 416 minecraft:polished_blackstone
fill 401 273 458 402 285 458 minecraft:polished_blackstone
fill 408 273 416 409 285 416 minecraft:polished_blackstone
fill 413 273 458 414 285 458 minecraft:polished_blackstone
fill 418 273 418 418 285 419 minecraft:polished_blackstone
fill 418 273 430 418 285 431 minecraft:polished_blackstone
fill 418 273 442 418 285 443 minecraft:polished_blackstone
fill 418 273 454 418 285 455 minecraft:polished_blackstone
setblock 379 278 419 minecraft:light[level=12]
setblock 379 278 427 minecraft:light[level=12]
setblock 379 278 435 minecraft:light[level=12]
setblock 379 278 443 minecraft:light[level=12]
setblock 379 278 451 minecraft:light[level=12]
setblock 387 278 419 minecraft:light[level=12]
setblock 387 278 427 minecraft:light[level=12]
setblock 387 278 435 minecraft:light[level=12]
setblock 387 278 443 minecraft:light[level=12]
setblock 387 278 451 minecraft:light[level=12]
setblock 395 278 419 minecraft:light[level=12]
setblock 395 278 427 minecraft:light[level=12]
setblock 395 278 443 minecraft:light[level=12]
setblock 395 278 451 minecraft:light[level=12]
setblock 403 278 419 minecraft:light[level=12]
setblock 403 278 427 minecraft:light[level=12]
setblock 403 278 435 minecraft:light[level=12]
setblock 403 278 443 minecraft:light[level=12]
setblock 403 278 451 minecraft:light[level=12]
setblock 411 278 419 minecraft:light[level=12]
setblock 411 278 427 minecraft:light[level=12]
setblock 411 278 435 minecraft:light[level=12]
setblock 411 278 443 minecraft:light[level=12]
setblock 411 278 451 minecraft:light[level=12]
fill 380 279 435 392 279 435 minecraft:red_stained_glass
fill 383 279 428 385 280 428 minecraft:red_stained_glass
fill 383 279 434 392 279 434 minecraft:red_stained_glass
fill 383 279 436 392 279 436 minecraft:red_stained_glass
fill 383 279 442 385 280 442 minecraft:red_stained_glass
fill 384 279 429 387 280 429 minecraft:red_stained_glass
fill 384 279 441 387 280 441 minecraft:red_stained_glass
fill 385 279 430 389 279 430 minecraft:red_stained_glass
fill 385 279 440 389 279 440 minecraft:red_stained_glass
fill 386 279 431 404 279 431 minecraft:red_stained_glass
fill 386 279 439 404 279 439 minecraft:red_stained_glass
fill 387 279 432 403 279 432 minecraft:red_stained_glass
fill 387 279 438 403 279 438 minecraft:red_stained_glass
fill 388 279 423 388 280 425 minecraft:red_stained_glass
fill 388 279 445 388 280 447 minecraft:red_stained_glass
fill 389 279 424 389 280 427 minecraft:red_stained_glass
fill 389 279 433 393 279 433 minecraft:red_stained_glass
fill 389 279 437 393 279 437 minecraft:red_stained_glass
fill 389 279 443 389 280 446 minecraft:red_stained_glass
fill 390 279 425 390 279 429 minecraft:red_stained_glass
fill 390 279 441 390 279 445 minecraft:red_stained_glass
fill 391 279 426 391 279 430 minecraft:red_stained_glass
fill 391 279 440 391 279 444 minecraft:red_stained_glass
fill 392 279 427 392 279 430 minecraft:red_stained_glass
fill 392 279 440 392 279 443 minecraft:red_stained_glass
fill 393 279 429 399 279 430 minecraft:red_stained_glass
fill 393 279 440 399 279 441 minecraft:red_stained_glass
fill 394 279 423 396 279 428 minecraft:red_stained_glass
fill 394 279 442 396 279 447 minecraft:red_stained_glass
fill 395 279 420 395 280 422 minecraft:red_stained_glass
fill 395 279 448 395 280 450 minecraft:red_stained_glass
fill 397 279 433 401 279 433 minecraft:red_stained_glass
fill 397 279 437 401 279 437 minecraft:red_stained_glass
fill 398 279 427 400 279 428 minecraft:red_stained_glass
fill 398 279 434 407 279 436 minecraft:red_stained_glass
fill 398 279 442 400 279 443 minecraft:red_stained_glass
fill 399 279 426 401 280 426 minecraft:red_stained_glass
fill 399 279 444 401 280 444 minecraft:red_stained_glass
fill 400 279 425 402 280 425 minecraft:red_stained_glass
fill 400 279 429 400 280 429 minecraft:red_stained_glass
fill 400 279 441 400 280 441 minecraft:red_stained_glass
fill 400 279 445 402 280 445 minecraft:red_stained_glass
fill 401 279 424 402 280 424 minecraft:red_stained_glass
fill 401 279 427 401 280 427 minecraft:red_stained_glass
fill 401 279 430 405 279 430 minecraft:red_stained_glass
fill 401 279 440 405 279 440 minecraft:red_stained_glass
fill 401 279 443 401 280 443 minecraft:red_stained_glass
fill 401 279 446 402 280 446 minecraft:red_stained_glass
fill 402 279 423 402 280 423 minecraft:red_stained_glass
fill 402 279 447 402 280 447 minecraft:red_stained_glass
fill 403 279 429 406 280 429 minecraft:red_stained_glass
fill 403 279 441 406 280 441 minecraft:red_stained_glass
fill 405 279 428 407 280 428 minecraft:red_stained_glass
fill 405 279 442 407 280 442 minecraft:red_stained_glass
fill 408 279 435 410 280 435 minecraft:red_stained_glass
fill 377 280 417 379 280 457 minecraft:polished_blackstone
fill 380 280 417 382 280 434 minecraft:polished_blackstone
fill 380 280 435 384 280 435 minecraft:red_stained_glass
fill 380 280 436 382 280 457 minecraft:polished_blackstone
fill 383 280 417 387 280 427 minecraft:polished_blackstone
fill 383 280 429 383 280 433 minecraft:polished_blackstone
fill 383 280 434 387 280 434 minecraft:red_stained_glass
fill 383 280 436 387 280 436 minecraft:red_stained_glass
fill 383 280 437 383 280 441 minecraft:polished_blackstone
fill 383 280 443 387 280 457 minecraft:polished_blackstone
fill 384 280 430 384 280 433 minecraft:polished_blackstone
fill 384 280 437 384 280 440 minecraft:polished_blackstone
fill 385 280 430 386 280 430 minecraft:red_stained_glass
fill 385 280 431 385 280 433 minecraft:polished_blackstone
fill 385 280 435 390 280 435 minecraft:purple_stained_glass
fill 385 280 437 385 280 439 minecraft:polished_blackstone
fill 385 280 440 386 280 440 minecraft:red_stained_glass
fill 386 280 428 389 280 428 minecraft:polished_blackstone
setblock 386 280 431 minecraft:red_stained_glass
fill 386 280 432 386 280 433 minecraft:polished_blackstone
fill 386 280 437 386 280 438 minecraft:polished_blackstone
setblock 386 280 439 minecraft:red_stained_glass
fill 386 280 442 389 280 442 minecraft:polished_blackstone
fill 387 280 430 387 280 431 minecraft:purple_stained_glass
setblock 387 280 432 minecraft:red_stained_glass
fill 387 280 433 388 280 433 minecraft:polished_blackstone
fill 387 280 437 388 280 437 minecraft:polished_blackstone
setblock 387 280 438 minecraft:red_stained_glass
fill 387 280 439 387 280 440 minecraft:purple_stained_glass
fill 388 280 417 394 280 422 minecraft:polished_blackstone
fill 388 280 426 388 280 427 minecraft:polished_blackstone
fill 388 280 429 389 280 429 minecraft:polished_blackstone
fill 388 280 430 389 280 430 minecraft:red_stained_glass
fill 388 280 431 390 280 432 minecraft:purple_stained_glass
fill 388 280 434 391 280 434 minecraft:purple_stained_glass
fill 388 280 436 391 280 436 minecraft:purple_stained_glass
fill 388 280 438 390 280 439 minecraft:purple_stained_glass
fill 388 280 440 389 280 440 minecraft:red_stained_glass
fill 388 280 441 389 280 441 minecraft:polished_blackstone
fill 388 280 443 388 280 444 minecraft:polished_blackstone
fill 388 280 448 394 280 457 minecraft:polished_blackstone
fill 389 280 423 393 280 423 minecraft:polished_blackstone
setblock 389 280 433 minecraft:red_stained_glass
setblock 389 280 437 minecraft:red_stained_glass
fill 389 280 447 393 280 447 minecraft:polished_blackstone
fill 390 280 424 393 280 424 minecraft:polished_blackstone
fill 390 280 425 390 280 426 minecraft:red_stained_glass
fill 390 280 427 391 280 427 minecraft:purple_stained_glass
fill 390 280 428 390 280 429 minecraft:red_stained_glass
setblock 390 280 430 minecraft:polished_blackstone
fill 390 280 433 391 280 433 minecraft:purple_stained_glass
fill 390 280 437 391 280 437 minecraft:purple_stained_glass
setblock 390 280 440 minecraft:polished_blackstone
fill 390 280 441 390 280 442 minecraft:red_stained_glass
fill 390 280 443 391 280 443 minecraft:purple_stained_glass
fill 390 280 444 390 280 445 minecraft:red_stained_glass
fill 390 280 446 393 280 446 minecraft:polished_blackstone
fill 391 280 425 393 280 425 minecraft:polished_blackstone
setblock 391 280 426 minecraft:red_stained_glass
fill 391 280 428 392 280 430 minecraft:purple_stained_glass
setblock 391 280 431 minecraft:red_stained_glass
fill 391 280 432 392 280 432 minecraft:purple_stained_glass
setblock 391 280 435 minecraft:bone_block
fill 391 280 438 392 280 438 minecraft:purple_stained_glass
setblock 391 280 439 minecraft:red_stained_glass
fill 391 280 440 392 280 442 minecraft:purple_stained_glass
setblock 391 280 444 minecraft:red_stained_glass
fill 391 280 445 393 280 445 minecraft:polished_blackstone
fill 392 280 426 393 280 426 minecraft:polished_blackstone
setblock 392 280 427 minecraft:red_stained_glass
fill 392 280 431 394 280 431 minecraft:purple_stained_glass
fill 392 280 433 392 280 437 minecraft:shroomlight
fill 392 280 439 394 280 439 minecraft:purple_stained_glass
setblock 392 280 443 minecraft:red_stained_glass
fill 392 280 444 393 280 444 minecraft:polished_blackstone
fill 393 280 427 393 280 428 minecraft:polished_blackstone
setblock 393 280 429 minecraft:red_stained_glass
fill 393 280 430 399 280 430 minecraft:purple_stained_glass
fill 393 280 432 393 280 433 minecraft:shroomlight
fill 393 280 437 393 280 438 minecraft:shroomlight
fill 393 280 440 399 280 440 minecraft:purple_stained_glass
setblock 393 280 441 minecraft:red_stained_glass
fill 393 280 442 393 280 443 minecraft:polished_blackstone
fill 394 280 423 394 280 427 minecraft:red_stained_glass
fill 394 280 428 396 280 429 minecraft:purple_stained_glass
fill 394 280 432 397 280 432 minecraft:shroomlight
fill 394 280 438 397 280 438 minecraft:shroomlight
fill 394 280 441 396 280 442 minecraft:purple_stained_glass
fill 394 280 443 394 280 447 minecraft:red_stained_glass
fill 395 280 417 417 280 419 minecraft:polished_blackstone
fill 395 280 423 396 280 424 minecraft:red_stained_glass
fill 395 280 425 395 280 427 minecraft:purple_stained_glass
setblock 395 280 431 minecraft:bone_block
setblock 395 280 439 minecraft:bone_block
fill 395 280 443 395 280 445 minecraft:purple_stained_glass
fill 395 280 446 396 280 447 minecraft:red_stained_glass
fill 395 280 451 417 280 457 minecraft:polished_blackstone
fill 396 280 420 417 280 422 minecraft:polished_blackstone
fill 396 280 425 396 280 427 minecraft:red_stained_glass
fill 396 280 431 398 280 431 minecraft:purple_stained_glass
fill 396 280 439 398 280 439 minecraft:purple_stained_glass
fill 396 280 443 396 280 445 minecraft:red_stained_glass
fill 396 280 448 417 280 450 minecraft:polished_blackstone
fill 397 280 423 397 280 428 minecraft:polished_blackstone
setblock 397 280 429 minecraft:red_stained_glass
fill 397 280 433 398 280 433 minecraft:shroomlight
fill 397 280 437 398 280 437 minecraft:shroomlight
setblock 397 280 441 minecraft:red_stained_glass
fill 397 280 442 397 280 447 minecraft:polished_blackstone
fill 398 280 423 398 280 426 minecraft:polished_blackstone
setblock 398 280 427 minecraft:red_stained_glass
fill 398 280 428 399 280 429 minecraft:purple_stained_glass
fill 398 280 432 402 280 432 minecraft:purple_stained_glass
fill 398 280 434 398 280 436 minecraft:shroomlight
fill 398 280 438 402 280 438 minecraft:purple_stained_glass
fill 398 280 441 399 280 442 minecraft:purple_stained_glass
setblock 398 280 443 minecraft:red_stained_glass
fill 398 280 444 398 280 447 minecraft:polished_blackstone
fill 399 280 423 399 280 425 minecraft:polished_blackstone
fill 399 280 427 400 280 427 minecraft:purple_stained_glass
setblock 399 280 431 minecraft:red_stained_glass
fill 399 280 433 400 280 434 minecraft:purple_stained_glass
setblock 399 280 435 minecraft:bone_block
fill 399 280 436 400 280 437 minecraft:purple_stained_glass
setblock 399 280 439 minecraft:red_stained_glass
fill 399 280 443 400 280 443 minecraft:purple_stained_glass
fill 399 280 445 399 280 447 minecraft:polished_blackstone
fill 400 280 423 400 280 424 minecraft:polished_blackstone
setblock 400 280 428 minecraft:red_stained_glass
setblock 400 280 430 minecraft:polished_blackstone
fill 400 280 431 403 280 431 minecraft:purple_stained_glass
fill 400 280 435 405 280 435 minecraft:purple_stained_glass
fill 400 280 439 403 280 439 minecraft:purple_stained_glass
setblock 400 280 440 minecraft:polished_blackstone
setblock 400 280 442 minecraft:red_stained_glass
fill 400 280 446 400 280 447 minecraft:polished_blackstone
setblock 401 280 423 minecraft:polished_blackstone
fill 401 280 428 402 280 429 minecraft:polished_blackstone
fill 401 280 430 402 280 430 minecraft:red_stained_glass
setblock 401 280 433 minecraft:red_stained_glass
fill 401 280 434 402 280 434 minecraft:purple_stained_glass
fill 401 280 436 402 280 436 minecraft:purple_stained_glass
setblock 401 280 437 minecraft:red_stained_glass
fill 401 280 440 402 280 440 minecraft:red_stained_glass
fill 401 280 441 402 280 442 minecraft:polished_blackstone
setblock 401 280 447 minecraft:polished_blackstone
fill 402 280 426 417 280 427 minecraft:polished_blackstone
fill 402 280 433 417 280 433 minecraft:polished_blackstone
fill 402 280 437 417 280 437 minecraft:polished_blackstone
fill 402 280 443 417 280 444 minecraft:polished_blackstone
fill 403 280 423 417 280 425 minecraft:polished_blackstone
fill 403 280 428 404 280 428 minecraft:polished_blackstone
setblock 403 280 430 minecraft:purple_stained_glass
setblock 403 280 432 minecraft:red_stained_glass
fill 403 280 434 407 280 434 minecraft:red_stained_glass
fill 403 280 436 407 280 436 minecraft:red_stained_glass
setblock 403 280 438 minecraft:red_stained_glass
setblock 403 280 440 minecraft:purple_stained_glass
fill 403 280 442 404 280 442 minecraft:polished_blackstone
fill 403 280 445 417 280 447 minecraft:polished_blackstone
fill 404 280 430 404 280 431 minecraft:red_stained_glass
fill 404 280 432 417 280 432 minecraft:polished_blackstone
fill 404 280 438 417 280 438 minecraft:polished_blackstone
fill 404 280 439 404 280 440 minecraft:red_stained_glass
setblock 405 280 430 minecraft:red_stained_glass
fill 405 280 431 417 280 431 minecraft:polished_blackstone
fill 405 280 439 417 280 439 minecraft:polished_blackstone
setblock 405 280 440 minecraft:red_stained_glass
fill 406 280 430 417 280 430 minecraft:polished_blackstone
fill 406 280 435 407 280 435 minecraft:red_stained_glass
fill 406 280 440 417 280 440 minecraft:polished_blackstone
fill 407 280 429 417 280 429 minecraft:polished_blackstone
fill 407 280 441 417 280 441 minecraft:polished_blackstone
fill 408 280 428 417 280 428 minecraft:polished_blackstone
fill 408 280 434 417 280 434 minecraft:polished_blackstone
fill 408 280 436 417 280 436 minecraft:polished_blackstone
fill 408 280 442 417 280 442 minecraft:polished_blackstone
fill 411 280 435 417 280 435 minecraft:polished_blackstone
fill 377 284 417 379 300 417 minecraft:bone_block
fill 377 284 427 377 300 429 minecraft:bone_block
fill 377 284 439 377 300 441 minecraft:bone_block
fill 377 284 451 377 300 453 minecraft:bone_block
fill 378 284 426 378 285 428 minecraft:bone_block
fill 378 284 438 378 285 440 minecraft:bone_block
fill 378 284 450 378 285 452 minecraft:bone_block
fill 379 284 451 379 284 454 minecraft:polished_blackstone
fill 380 284 450 382 284 450 minecraft:polished_blackstone
fill 380 284 451 382 300 453 minecraft:bone_block
setblock 380 284 454 minecraft:polished_blackstone
fill 381 284 454 381 300 454 minecraft:bone_block
setblock 382 284 454 minecraft:polished_blackstone
fill 383 284 451 383 284 453 minecraft:polished_blackstone
fill 383 284 457 385 300 457 minecraft:bone_block
fill 384 284 456 386 285 456 minecraft:bone_block
fill 388 284 418 390 285 418 minecraft:bone_block
fill 389 284 417 391 300 417 minecraft:bone_block
fill 395 284 457 397 300 457 minecraft:bone_block
fill 396 284 456 398 285 456 minecraft:bone_block
fill 400 284 418 402 285 418 minecraft:bone_block
fill 401 284 417 403 300 417 minecraft:bone_block
fill 407 284 457 409 300 457 minecraft:bone_block
fill 408 284 456 410 285 456 minecraft:bone_block
setblock 411 284 421 minecraft:polished_blackstone
fill 412 284 418 414 285 418 minecraft:bone_block
setblock 412 284 420 minecraft:polished_blackstone
fill 412 284 421 415 300 422 minecraft:bone_block
fill 412 284 423 415 284 423 minecraft:polished_blackstone
fill 413 284 417 415 300 417 minecraft:bone_block
fill 413 284 419 414 284 419 minecraft:polished_blackstone
fill 413 284 420 414 300 420 minecraft:bone_block
setblock 415 284 420 minecraft:polished_blackstone
fill 415 284 444 415 290 448 minecraft:black_wool
setblock 416 284 421 minecraft:polished_blackstone
fill 416 284 426 416 285 428 minecraft:bone_block
fill 416 284 438 416 285 440 minecraft:bone_block
fill 416 284 450 416 285 452 minecraft:bone_block
fill 417 284 425 417 300 427 minecraft:bone_block
fill 417 284 437 417 300 439 minecraft:bone_block
fill 417 284 449 417 300 451 minecraft:bone_block
fill 377 285 420 377 285 425 minecraft:polished_blackstone
fill 377 285 432 377 285 437 minecraft:polished_blackstone
fill 377 285 444 377 285 449 minecraft:polished_blackstone
fill 377 285 456 377 285 457 minecraft:polished_blackstone
fill 378 285 457 381 285 457 minecraft:polished_blackstone
fill 381 285 417 386 285 417 minecraft:polished_blackstone
fill 388 285 457 393 285 457 minecraft:polished_blackstone
fill 393 285 417 398 285 417 minecraft:polished_blackstone
fill 400 285 457 405 285 457 minecraft:polished_blackstone
fill 405 285 417 410 285 417 minecraft:polished_blackstone
fill 412 285 457 417 285 457 minecraft:polished_blackstone
fill 417 285 417 417 285 422 minecraft:polished_blackstone
fill 417 285 429 417 285 434 minecraft:polished_blackstone
fill 417 285 441 417 285 446 minecraft:polished_blackstone
fill 417 285 453 417 285 456 minecraft:polished_blackstone
fill 376 286 422 376 291 425 minecraft:shroomlight
fill 376 286 434 376 291 437 minecraft:shroomlight
fill 376 286 446 376 291 449 minecraft:shroomlight
fill 376 286 458 379 291 458 minecraft:shroomlight
setblock 379 286 419 minecraft:light[level=12]
setblock 379 286 427 minecraft:light[level=12]
setblock 379 286 435 minecraft:light[level=12]
setblock 379 286 443 minecraft:light[level=12]
setblock 379 286 451 minecraft:light[level=12]
fill 383 286 416 386 291 416 minecraft:shroomlight
setblock 387 286 419 minecraft:light[level=12]
setblock 387 286 427 minecraft:light[level=12]
setblock 387 286 435 minecraft:light[level=12]
setblock 387 286 443 minecraft:light[level=12]
setblock 387 286 451 minecraft:light[level=12]
fill 388 286 458 391 291 458 minecraft:shroomlight
fill 395 286 416 398 291 416 minecraft:shroomlight
setblock 395 286 419 minecraft:light[level=12]
setblock 395 286 427 minecraft:light[level=12]
setblock 395 286 443 minecraft:light[level=12]
setblock 395 286 451 minecraft:light[level=12]
fill 400 286 458 403 291 458 minecraft:shroomlight
setblock 403 286 419 minecraft:light[level=12]
setblock 403 286 427 minecraft:light[level=12]
setblock 403 286 435 minecraft:light[level=12]
setblock 403 286 443 minecraft:light[level=12]
setblock 403 286 451 minecraft:light[level=12]
fill 407 286 416 410 291 416 minecraft:shroomlight
setblock 411 286 419 minecraft:light[level=12]
setblock 411 286 427 minecraft:light[level=12]
setblock 411 286 435 minecraft:light[level=12]
setblock 411 286 443 minecraft:light[level=12]
setblock 411 286 451 minecraft:light[level=12]
fill 412 286 458 415 291 458 minecraft:shroomlight
fill 418 286 417 418 291 420 minecraft:shroomlight
fill 418 286 429 418 291 432 minecraft:shroomlight
fill 418 286 441 418 291 444 minecraft:shroomlight
fill 418 286 453 418 291 456 minecraft:shroomlight
fill 415 291 443 415 292 449 minecraft:iron_bars
fill 376 292 422 376 307 422 minecraft:polished_blackstone
fill 376 292 423 376 292 424 minecraft:shroomlight
fill 376 292 425 376 307 425 minecraft:polished_blackstone
fill 376 292 434 376 307 434 minecraft:polished_blackstone
fill 376 292 435 376 292 436 minecraft:shroomlight
fill 376 292 437 376 307 437 minecraft:polished_blackstone
fill 376 292 446 376 307 446 minecraft:polished_blackstone
fill 376 292 447 376 292 448 minecraft:shroomlight
fill 376 292 449 376 307 449 minecraft:polished_blackstone
fill 376 292 458 376 307 458 minecraft:polished_blackstone
fill 377 292 458 378 292 458 minecraft:shroomlight
fill 379 292 451 379 292 454 minecraft:polished_blackstone
fill 379 292 458 379 307 458 minecraft:polished_blackstone
fill 380 292 450 382 292 450 minecraft:polished_blackstone
setblock 380 292 454 minecraft:polished_blackstone
setblock 382 292 454 minecraft:polished_blackstone
fill 383 292 416 383 307 416 minecraft:polished_blackstone
fill 383 292 451 383 292 453 minecraft:polished_blackstone
fill 384 292 416 385 292 416 minecraft:shroomlight
fill 386 292 416 386 307 416 minecraft:polished_blackstone
fill 388 292 458 388 307 458 minecraft:polished_blackstone
fill 389 292 458 390 292 458 minecraft:shroomlight
fill 391 292 458 391 307 458 minecraft:polished_blackstone
fill 395 292 416 395 307 416 minecraft:polished_blackstone
fill 396 292 416 397 292 416 minecraft:shroomlight
fill 398 292 416 398 307 416 minecraft:polished_blackstone
fill 400 292 458 400 307 458 minecraft:polished_blackstone
fill 401 292 458 402 292 458 minecraft:shroomlight
fill 403 292 458 403 307 458 minecraft:polished_blackstone
fill 407 292 416 407 307 416 minecraft:polished_blackstone
fill 408 292 416 409 292 416 minecraft:shroomlight
fill 410 292 416 410 307 416 minecraft:polished_blackstone
setblock 411 292 421 minecraft:polished_blackstone
setblock 412 292 420 minecraft:polished_blackstone
fill 412 292 423 415 292 423 minecraft:polished_blackstone
fill 412 292 458 412 307 458 minecraft:polished_blackstone
fill 413 292 419 414 292 419 minecraft:polished_blackstone
fill 413 292 458 414 292 458 minecraft:shroomlight
setblock 415 292 420 minecraft:polished_blackstone
fill 415 292 458 415 307 458 minecraft:polished_blackstone
setblock 416 292 421 minecraft:polished_blackstone
fill 418 292 417 418 307 417 minecraft:polished_blackstone
fill 418 292 418 418 292 419 minecraft:shroomlight
fill 418 292 420 418 307 420 minecraft:polished_blackstone
fill 418 292 429 418 307 429 minecraft:polished_blackstone
fill 418 292 430 418 292 431 minecraft:shroomlight
fill 418 292 432 418 307 432 minecraft:polished_blackstone
fill 418 292 441 418 307 441 minecraft:polished_blackstone
fill 418 292 442 418 292 443 minecraft:shroomlight
fill 418 292 444 418 307 444 minecraft:polished_blackstone
fill 418 292 453 418 307 453 minecraft:polished_blackstone
fill 418 292 454 418 292 455 minecraft:shroomlight
fill 418 292 456 418 307 456 minecraft:polished_blackstone
fill 376 293 423 376 307 424 minecraft:polished_blackstone
fill 376 293 435 376 307 436 minecraft:polished_blackstone
fill 376 293 447 376 307 448 minecraft:polished_blackstone
fill 377 293 458 378 307 458 minecraft:polished_blackstone
fill 384 293 416 385 307 416 minecraft:polished_blackstone
fill 389 293 458 390 307 458 minecraft:polished_blackstone
fill 392 293 450 396 294 454 minecraft:polished_blackstone
fill 394 293 455 394 293 456 minecraft:polished_blackstone
fill 396 293 416 397 307 416 minecraft:polished_blackstone
fill 401 293 458 402 307 458 minecraft:polished_blackstone
fill 408 293 416 409 307 416 minecraft:polished_blackstone
fill 413 293 458 414 307 458 minecraft:polished_blackstone
fill 418 293 418 418 307 419 minecraft:polished_blackstone
fill 418 293 430 418 307 431 minecraft:polished_blackstone
fill 418 293 442 418 307 443 minecraft:polished_blackstone
fill 418 293 454 418 307 455 minecraft:polished_blackstone
setblock 379 294 419 minecraft:light[level=12]
setblock 379 294 427 minecraft:light[level=12]
setblock 379 294 435 minecraft:light[level=12]
setblock 379 294 443 minecraft:light[level=12]
setblock 379 294 451 minecraft:light[level=12]
setblock 387 294 419 minecraft:light[level=12]
setblock 387 294 427 minecraft:light[level=12]
setblock 387 294 435 minecraft:light[level=12]
setblock 387 294 443 minecraft:light[level=12]
setblock 387 294 451 minecraft:light[level=12]
setblock 395 294 419 minecraft:light[level=12]
setblock 395 294 427 minecraft:light[level=12]
setblock 395 294 443 minecraft:light[level=12]
setblock 403 294 419 minecraft:light[level=12]
setblock 403 294 427 minecraft:light[level=12]
setblock 403 294 435 minecraft:light[level=12]
setblock 403 294 443 minecraft:light[level=12]
setblock 403 294 451 minecraft:light[level=12]
setblock 411 294 419 minecraft:light[level=12]
setblock 411 294 427 minecraft:light[level=12]
setblock 411 294 435 minecraft:light[level=12]
setblock 411 294 443 minecraft:light[level=12]
setblock 411 294 451 minecraft:light[level=12]
fill 390 295 451 392 296 451 minecraft:bone_block
fill 390 295 453 392 296 453 minecraft:bone_block
fill 391 295 452 391 296 452 minecraft:bone_block
fill 392 296 452 393 297 452 minecraft:bone_block
fill 394 297 452 394 298 452 minecraft:bone_block
fill 395 298 452 396 299 452 minecraft:bone_block
fill 379 299 451 379 300 453 minecraft:white_concrete
fill 380 299 454 380 300 454 minecraft:white_concrete
fill 381 299 450 381 300 450 minecraft:white_concrete
fill 382 299 454 382 300 454 minecraft:white_concrete
fill 383 299 452 383 300 453 minecraft:white_concrete
fill 396 299 451 398 300 451 minecraft:bone_block
fill 396 299 453 398 300 453 minecraft:bone_block
fill 397 299 452 397 300 452 minecraft:bone_block
fill 412 299 420 412 300 420 minecraft:white_concrete
fill 412 299 423 415 300 423 minecraft:white_concrete
fill 413 299 419 414 300 419 minecraft:white_concrete
fill 415 299 420 415 300 420 minecraft:white_concrete
fill 378 300 426 378 300 428 minecraft:bone_block
fill 378 300 438 378 300 440 minecraft:bone_block
fill 378 300 450 378 300 452 minecraft:bone_block
fill 384 300 456 386 300 456 minecraft:bone_block
fill 388 300 418 390 300 418 minecraft:bone_block
fill 396 300 456 398 300 456 minecraft:bone_block
fill 400 300 418 402 300 418 minecraft:bone_block
fill 408 300 456 410 300 456 minecraft:bone_block
fill 412 300 418 414 300 418 minecraft:bone_block
fill 416 300 426 416 300 428 minecraft:bone_block
fill 416 300 438 416 300 440 minecraft:bone_block
fill 416 300 450 416 300 452 minecraft:bone_block
setblock 379 302 419 minecraft:light[level=12]
setblock 379 302 427 minecraft:light[level=12]
setblock 379 302 435 minecraft:light[level=12]
setblock 379 302 443 minecraft:light[level=12]
setblock 379 302 451 minecraft:light[level=12]
setblock 387 302 419 minecraft:light[level=12]
setblock 387 302 427 minecraft:light[level=12]
setblock 387 302 435 minecraft:light[level=12]
setblock 387 302 443 minecraft:light[level=12]
setblock 387 302 451 minecraft:light[level=12]
setblock 395 302 419 minecraft:light[level=12]
setblock 395 302 427 minecraft:light[level=12]
setblock 395 302 435 minecraft:light[level=12]
setblock 395 302 443 minecraft:light[level=12]
setblock 395 302 451 minecraft:light[level=12]
setblock 403 302 419 minecraft:light[level=12]
setblock 403 302 427 minecraft:light[level=12]
setblock 403 302 435 minecraft:light[level=12]
setblock 403 302 443 minecraft:light[level=12]
setblock 403 302 451 minecraft:light[level=12]
setblock 411 302 419 minecraft:light[level=12]
setblock 411 302 427 minecraft:light[level=12]
setblock 411 302 435 minecraft:light[level=12]
setblock 411 302 443 minecraft:light[level=12]
setblock 411 302 451 minecraft:light[level=12]
