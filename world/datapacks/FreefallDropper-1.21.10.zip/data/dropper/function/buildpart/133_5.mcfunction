fill 48 122 574 49 124 574 minecraft:cobbled_deepslate
setblock 48 122 578 minecraft:calcite
setblock 48 122 579 minecraft:cobbled_deepslate
setblock 48 122 583 minecraft:calcite
setblock 48 122 584 minecraft:cobbled_deepslate
setblock 48 122 588 minecraft:calcite
fill 48 122 589 48 124 589 minecraft:cobbled_deepslate
setblock 48 122 593 minecraft:calcite
setblock 49 122 567 minecraft:calcite
fill 49 122 568 49 125 568 minecraft:cobbled_deepslate
setblock 49 122 572 minecraft:calcite
fill 49 122 573 49 125 573 minecraft:cobbled_deepslate
fill 50 122 567 50 123 567 minecraft:cobbled_deepslate
setblock 50 122 570 minecraft:cobbled_deepslate
setblock 56 122 559 minecraft:cobbled_deepslate
fill 56 122 598 57 122 598 minecraft:cobbled_deepslate
setblock 57 122 559 minecraft:calcite
setblock 58 122 558 minecraft:calcite
fill 58 122 559 58 124 560 minecraft:cobbled_deepslate
setblock 58 122 597 minecraft:cobbled_deepslate
setblock 58 122 598 minecraft:calcite
fill 59 122 558 59 125 558 minecraft:cobbled_deepslate
setblock 59 122 597 minecraft:calcite
fill 59 122 598 59 125 598 minecraft:cobbled_deepslate
fill 60 122 597 63 122 597 minecraft:cobbled_deepslate
setblock 61 122 560 minecraft:calcite
fill 61 122 596 63 123 596 minecraft:cobbled_deepslate
setblock 62 122 559 minecraft:calcite
fill 62 122 560 62 123 560 minecraft:cobbled_deepslate
setblock 63 122 558 minecraft:calcite
fill 63 122 559 63 125 559 minecraft:cobbled_deepslate
setblock 63 122 598 minecraft:calcite
fill 64 122 558 64 125 558 minecraft:cobbled_deepslate
setblock 64 122 597 minecraft:calcite
fill 64 122 598 64 125 598 minecraft:cobbled_deepslate
fill 65 122 597 65 125 597 minecraft:cobbled_deepslate
fill 67 122 597 67 123 597 minecraft:cobbled_deepslate
setblock 68 122 558 minecraft:calcite
setblock 68 122 598 minecraft:calcite
fill 69 122 598 72 122 598 minecraft:cobbled_deepslate
setblock 73 122 598 minecraft:calcite
fill 74 122 598 74 125 598 minecraft:cobbled_deepslate
fill 75 122 597 78 122 597 minecraft:cobbled_deepslate
setblock 77 122 558 minecraft:cobbled_deepslate
fill 77 122 596 79 122 596 minecraft:cobbled_deepslate
setblock 78 122 558 minecraft:calcite
setblock 78 122 598 minecraft:calcite
fill 79 122 558 79 125 558 minecraft:cobbled_deepslate
setblock 79 122 597 minecraft:calcite
fill 79 122 598 79 125 598 minecraft:cobbled_deepslate
setblock 80 122 596 minecraft:calcite
fill 80 122 597 80 125 597 minecraft:cobbled_deepslate
fill 81 122 596 81 125 596 minecraft:cobbled_deepslate
fill 83 122 596 83 123 596 minecraft:cobbled_deepslate
setblock 83 122 598 minecraft:calcite
setblock 84 122 597 minecraft:calcite
fill 84 122 598 84 125 598 minecraft:cobbled_deepslate
setblock 85 122 586 minecraft:calcite
setblock 85 122 587 minecraft:cobbled_deepslate
setblock 85 122 591 minecraft:calcite
setblock 86 122 570 minecraft:calcite
setblock 86 122 585 minecraft:calcite
fill 86 122 586 86 123 586 minecraft:cobbled_deepslate
setblock 86 122 590 minecraft:calcite
fill 86 122 591 86 124 591 minecraft:cobbled_deepslate
setblock 87 122 568 minecraft:cobbled_deepslate
setblock 87 122 569 minecraft:calcite
fill 87 122 570 87 125 570 minecraft:cobbled_deepslate
setblock 87 122 573 minecraft:cobbled_deepslate
setblock 87 122 574 minecraft:calcite
fill 87 122 575 87 125 575 minecraft:cobbled_deepslate
setblock 87 122 584 minecraft:calcite
fill 87 122 585 87 124 585 minecraft:cobbled_deepslate
setblock 87 122 589 minecraft:calcite
fill 87 122 590 87 125 590 minecraft:cobbled_deepslate
setblock 87 122 594 minecraft:calcite
fill 88 122 564 88 123 564 minecraft:cobbled_deepslate
setblock 88 122 568 minecraft:calcite
fill 88 122 569 88 125 569 minecraft:cobbled_deepslate
setblock 88 122 573 minecraft:calcite
fill 88 122 574 88 125 574 minecraft:cobbled_deepslate
setblock 88 122 578 minecraft:calcite
fill 88 122 579 88 125 579 minecraft:cobbled_deepslate
setblock 88 122 583 minecraft:calcite
fill 88 122 584 88 125 584 minecraft:cobbled_deepslate
setblock 88 122 588 minecraft:calcite
fill 88 122 589 88 125 589 minecraft:cobbled_deepslate
setblock 88 122 593 minecraft:calcite
fill 88 122 594 88 125 594 minecraft:cobbled_deepslate
setblock 48 123 562 minecraft:calcite
fill 48 123 563 48 124 563 minecraft:cobbled_deepslate
setblock 48 123 567 minecraft:calcite
fill 48 123 568 48 126 568 minecraft:cobbled_deepslate
setblock 48 123 572 minecraft:calcite
fill 48 123 573 48 126 573 minecraft:cobbled_deepslate
setblock 48 123 577 minecraft:calcite
setblock 48 123 578 minecraft:cobbled_deepslate
setblock 48 123 587 minecraft:calcite
fill 48 123 588 48 124 588 minecraft:cobbled_deepslate
setblock 48 123 591 minecraft:cobbled_deepslate
setblock 48 123 592 minecraft:calcite
fill 48 123 593 48 124 593 minecraft:cobbled_deepslate
setblock 49 123 566 minecraft:calcite
fill 49 123 567 49 126 567 minecraft:cobbled_deepslate
setblock 49 123 571 minecraft:calcite
fill 49 123 572 49 126 572 minecraft:cobbled_deepslate
setblock 50 123 570 minecraft:calcite
fill 50 123 571 50 124 571 minecraft:cobbled_deepslate
fill 54 123 558 54 125 558 minecraft:cobbled_deepslate
fill 55 123 598 56 123 598 minecraft:cobbled_deepslate
setblock 56 123 559 minecraft:calcite
fill 56 123 594 56 128 594 minecraft:deepslate
setblock 57 123 558 minecraft:calcite
fill 57 123 559 57 126 559 minecraft:cobbled_deepslate
setblock 57 123 597 minecraft:cobbled_deepslate
setblock 57 123 598 minecraft:calcite
fill 58 123 558 58 126 558 minecraft:cobbled_deepslate
setblock 58 123 597 minecraft:calcite
fill 58 123 598 58 126 598 minecraft:cobbled_deepslate
fill 59 123 597 62 123 597 minecraft:cobbled_deepslate
setblock 60 123 560 minecraft:calcite
fill 60 123 596 60 126 596 minecraft:cobbled_deepslate
setblock 61 123 559 minecraft:calcite
fill 61 123 560 61 124 560 minecraft:cobbled_deepslate
setblock 62 123 558 minecraft:calcite
fill 62 123 559 62 126 559 minecraft:cobbled_deepslate
setblock 62 123 598 minecraft:calcite
fill 63 123 558 63 126 558 minecraft:cobbled_deepslate
setblock 63 123 597 minecraft:calcite
fill 63 123 598 63 126 598 minecraft:cobbled_deepslate
setblock 64 123 596 minecraft:calcite
fill 64 123 597 64 126 597 minecraft:cobbled_deepslate
setblock 67 123 558 minecraft:calcite
setblock 67 123 598 minecraft:calcite
setblock 68 123 597 minecraft:calcite
fill 68 123 598 71 123 598 minecraft:cobbled_deepslate
setblock 72 123 598 minecraft:calcite
setblock 73 123 597 minecraft:calcite
fill 73 123 598 73 126 598 minecraft:cobbled_deepslate
fill 74 123 597 77 123 597 minecraft:cobbled_deepslate
fill 76 123 596 78 123 596 minecraft:cobbled_deepslate
setblock 77 123 558 minecraft:calcite
setblock 77 123 598 minecraft:calcite
fill 78 123 558 78 126 558 minecraft:cobbled_deepslate
fill 78 123 595 79 123 595 minecraft:cobbled_deepslate
setblock 78 123 597 minecraft:calcite
fill 78 123 598 78 126 598 minecraft:cobbled_deepslate
setblock 79 123 596 minecraft:calcite
fill 79 123 597 79 126 597 minecraft:cobbled_deepslate
setblock 80 123 595 minecraft:calcite
fill 80 123 596 80 126 596 minecraft:cobbled_deepslate
fill 81 123 595 81 124 595 minecraft:cobbled_deepslate
setblock 82 123 558 minecraft:calcite
setblock 82 123 598 minecraft:calcite
setblock 83 123 597 minecraft:calcite
fill 83 123 598 83 126 598 minecraft:cobbled_deepslate
fill 84 123 597 84 124 597 minecraft:cobbled_deepslate
setblock 85 123 590 minecraft:calcite
setblock 85 123 591 minecraft:cobbled_deepslate
fill 86 123 570 86 123 571 minecraft:cobbled_deepslate
setblock 86 123 589 minecraft:calcite
fill 86 123 590 86 124 590 minecraft:cobbled_deepslate
setblock 87 123 568 minecraft:calcite
fill 87 123 569 87 125 569 minecraft:cobbled_deepslate
setblock 87 123 572 minecraft:cobbled_deepslate
setblock 87 123 573 minecraft:calcite
fill 87 123 574 87 126 574 minecraft:cobbled_deepslate
fill 87 123 576 87 124 576 minecraft:cobbled_deepslate
setblock 87 123 583 minecraft:calcite
setblock 87 123 584 minecraft:cobbled_deepslate
setblock 87 123 588 minecraft:calcite
fill 87 123 589 87 125 589 minecraft:cobbled_deepslate
setblock 87 123 593 minecraft:calcite
fill 87 123 594 87 124 594 minecraft:cobbled_deepslate
setblock 88 123 567 minecraft:calcite
fill 88 123 568 88 126 568 minecraft:cobbled_deepslate
setblock 88 123 572 minecraft:calcite
fill 88 123 573 88 126 573 minecraft:cobbled_deepslate
setblock 88 123 577 minecraft:calcite
fill 88 123 578 88 126 578 minecraft:cobbled_deepslate
setblock 88 123 582 minecraft:calcite
fill 88 123 583 88 124 583 minecraft:cobbled_deepslate
setblock 88 123 587 minecraft:calcite
fill 88 123 588 88 126 588 minecraft:cobbled_deepslate
setblock 88 123 592 minecraft:calcite
fill 88 123 593 88 126 593 minecraft:cobbled_deepslate
setblock 48 124 566 minecraft:calcite
fill 48 124 567 48 127 567 minecraft:cobbled_deepslate
setblock 48 124 571 minecraft:calcite
fill 48 124 572 48 127 572 minecraft:cobbled_deepslate
setblock 48 124 576 minecraft:calcite
fill 48 124 577 48 126 577 minecraft:cobbled_deepslate
setblock 48 124 591 minecraft:calcite
setblock 48 124 592 minecraft:cobbled_deepslate
setblock 49 124 565 minecraft:calcite
fill 49 124 566 49 125 566 minecraft:cobbled_deepslate
setblock 49 124 569 minecraft:cobbled_deepslate
setblock 49 124 570 minecraft:calcite
fill 49 124 571 49 127 571 minecraft:cobbled_deepslate
setblock 50 124 569 minecraft:calcite
fill 50 124 570 50 125 570 minecraft:cobbled_deepslate
fill 53 124 558 53 126 558 minecraft:cobbled_deepslate
setblock 55 124 598 minecraft:cobbled_deepslate
setblock 56 124 558 minecraft:calcite
fill 56 124 559 56 127 559 minecraft:cobbled_deepslate
setblock 56 124 597 minecraft:cobbled_deepslate
setblock 56 124 598 minecraft:calcite
fill 57 124 558 57 127 558 minecraft:cobbled_deepslate
setblock 57 124 597 minecraft:calcite
fill 57 124 598 57 127 598 minecraft:cobbled_deepslate
setblock 58 124 596 minecraft:calcite
fill 58 124 597 61 124 597 minecraft:cobbled_deepslate
setblock 59 124 560 minecraft:calcite
fill 59 124 596 59 127 596 minecraft:cobbled_deepslate
setblock 60 124 559 minecraft:calcite
setblock 60 124 560 minecraft:cobbled_deepslate
setblock 61 124 558 minecraft:calcite
fill 61 124 559 61 127 559 minecraft:cobbled_deepslate
fill 61 124 596 62 124 596 minecraft:cobbled_deepslate
setblock 61 124 598 minecraft:calcite
fill 62 124 558 62 127 558 minecraft:cobbled_deepslate
setblock 62 124 597 minecraft:calcite
fill 62 124 598 62 127 598 minecraft:cobbled_deepslate
setblock 63 124 596 minecraft:calcite
fill 63 124 597 63 127 597 minecraft:cobbled_deepslate
fill 64 124 596 64 125 596 minecraft:cobbled_deepslate
setblock 66 124 558 minecraft:calcite
setblock 66 124 598 minecraft:calcite
setblock 67 124 558 minecraft:cobbled_deepslate
setblock 67 124 597 minecraft:calcite
fill 67 124 598 70 124 598 minecraft:cobbled_deepslate
fill 68 124 597 68 127 597 minecraft:cobbled_deepslate
setblock 71 124 597 minecraft:cobbled_deepslate
setblock 71 124 598 minecraft:calcite
setblock 72 124 597 minecraft:calcite
fill 72 124 598 72 127 598 minecraft:cobbled_deepslate
fill 73 124 597 76 124 597 minecraft:cobbled_deepslate
fill 74 124 596 77 124 596 minecraft:cobbled_deepslate
setblock 76 124 598 minecraft:calcite
fill 77 124 558 77 126 558 minecraft:cobbled_deepslate
fill 77 124 595 78 124 595 minecraft:cobbled_deepslate
setblock 77 124 597 minecraft:calcite
fill 77 124 598 77 127 598 minecraft:cobbled_deepslate
setblock 78 124 596 minecraft:calcite
fill 78 124 597 78 127 597 minecraft:cobbled_deepslate
setblock 79 124 595 minecraft:calcite
fill 79 124 596 79 127 596 minecraft:cobbled_deepslate
fill 80 124 595 80 126 595 minecraft:cobbled_deepslate
setblock 81 124 558 minecraft:calcite
setblock 81 124 598 minecraft:calcite
setblock 82 124 597 minecraft:calcite
fill 82 124 598 82 127 598 minecraft:cobbled_deepslate
setblock 83 124 596 minecraft:calcite
fill 83 124 597 83 126 597 minecraft:cobbled_deepslate
setblock 86 124 588 minecraft:calcite
setblock 86 124 589 minecraft:cobbled_deepslate
setblock 86 124 592 minecraft:cobbled_deepslate
setblock 87 124 567 minecraft:calcite
fill 87 124 568 87 125 568 minecraft:cobbled_deepslate
setblock 87 124 572 minecraft:calcite
fill 87 124 573 87 127 573 minecraft:cobbled_deepslate
setblock 87 124 587 minecraft:calcite
fill 87 124 588 87 125 588 minecraft:cobbled_deepslate
setblock 87 124 592 minecraft:calcite
fill 87 124 593 87 125 593 minecraft:cobbled_deepslate
setblock 88 124 566 minecraft:calcite
fill 88 124 567 88 126 567 minecraft:cobbled_deepslate
setblock 88 124 571 minecraft:calcite
fill 88 124 572 88 127 572 minecraft:cobbled_deepslate
setblock 88 124 576 minecraft:calcite
fill 88 124 577 88 127 577 minecraft:cobbled_deepslate
setblock 88 124 581 minecraft:calcite
setblock 88 124 582 minecraft:cobbled_deepslate
setblock 88 124 586 minecraft:calcite
fill 88 124 587 88 125 587 minecraft:cobbled_deepslate
setblock 88 124 591 minecraft:calcite
fill 88 124 592 88 127 592 minecraft:cobbled_deepslate
setblock 48 125 565 minecraft:calcite
fill 48 125 566 48 127 566 minecraft:cobbled_deepslate
setblock 48 125 570 minecraft:calcite
fill 48 125 571 48 128 571 minecraft:cobbled_deepslate
setblock 48 125 574 minecraft:cobbled_deepslate
setblock 48 125 575 minecraft:calcite
fill 48 125 576 48 128 576 minecraft:cobbled_deepslate
setblock 49 125 569 minecraft:calcite
fill 49 125 570 49 128 570 minecraft:cobbled_deepslate
setblock 49 125 574 minecraft:calcite
setblock 54 125 598 minecraft:cobbled_deepslate
setblock 55 125 558 minecraft:calcite
fill 55 125 559 55 128 559 minecraft:cobbled_deepslate
setblock 55 125 598 minecraft:calcite
fill 56 125 558 56 128 558 minecraft:cobbled_deepslate
setblock 56 125 597 minecraft:calcite
fill 56 125 598 56 128 598 minecraft:cobbled_deepslate
fill 57 125 597 60 125 597 minecraft:cobbled_deepslate
setblock 58 125 559 minecraft:cobbled_deepslate
fill 58 125 596 58 128 596 minecraft:cobbled_deepslate
setblock 59 125 559 minecraft:calcite
setblock 59 125 560 minecraft:cobbled_deepslate
setblock 60 125 558 minecraft:calcite
fill 60 125 559 60 128 559 minecraft:cobbled_deepslate
setblock 60 125 598 minecraft:calcite
fill 61 125 558 61 128 558 minecraft:cobbled_deepslate
setblock 61 125 596 minecraft:cobbled_deepslate
setblock 61 125 597 minecraft:calcite
fill 61 125 598 61 128 598 minecraft:cobbled_deepslate
setblock 62 125 596 minecraft:calcite
fill 62 125 597 62 128 597 minecraft:cobbled_deepslate
fill 63 125 596 63 127 596 minecraft:cobbled_deepslate
setblock 65 125 558 minecraft:calcite
setblock 65 125 598 minecraft:calcite
setblock 66 125 558 minecraft:cobbled_deepslate
setblock 66 125 597 minecraft:calcite
fill 66 125 598 69 125 598 minecraft:cobbled_deepslate
fill 67 125 597 67 128 597 minecraft:cobbled_deepslate
fill 69 125 597 70 125 597 minecraft:cobbled_deepslate
setblock 70 125 598 minecraft:calcite
setblock 71 125 597 minecraft:calcite
fill 71 125 598 71 128 598 minecraft:cobbled_deepslate
fill 72 125 597 75 125 597 minecraft:cobbled_deepslate
fill 74 125 596 76 125 596 minecraft:cobbled_deepslate
setblock 75 125 598 minecraft:calcite
fill 76 125 595 77 125 595 minecraft:cobbled_deepslate
setblock 76 125 597 minecraft:calcite
fill 76 125 598 76 128 598 minecraft:cobbled_deepslate
setblock 77 125 596 minecraft:calcite
fill 77 125 597 77 128 597 minecraft:cobbled_deepslate
setblock 78 125 595 minecraft:calcite
fill 78 125 596 78 128 596 minecraft:cobbled_deepslate
fill 79 125 595 79 126 595 minecraft:cobbled_deepslate
setblock 80 125 558 minecraft:calcite
setblock 80 125 598 minecraft:calcite
setblock 81 125 597 minecraft:calcite
fill 81 125 598 81 128 598 minecraft:cobbled_deepslate
setblock 82 125 596 minecraft:calcite
fill 82 125 597 82 127 597 minecraft:cobbled_deepslate
setblock 87 125 571 minecraft:calcite
fill 87 125 572 87 128 572 minecraft:cobbled_deepslate
setblock 87 125 576 minecraft:calcite
setblock 87 125 591 minecraft:calcite
setblock 87 125 592 minecraft:cobbled_deepslate
setblock 88 125 566 minecraft:cobbled_deepslate
setblock 88 125 570 minecraft:calcite
fill 88 125 571 88 128 571 minecraft:cobbled_deepslate
setblock 88 125 575 minecraft:calcite
fill 88 125 576 88 128 576 minecraft:cobbled_deepslate
setblock 88 125 585 minecraft:calcite
setblock 88 125 586 minecraft:cobbled_deepslate
setblock 88 125 590 minecraft:calcite
fill 88 125 591 88 126 591 minecraft:cobbled_deepslate
setblock 88 125 595 minecraft:calcite
setblock 48 126 565 minecraft:cobbled_deepslate
setblock 48 126 569 minecraft:calcite
fill 48 126 570 48 129 570 minecraft:cobbled_deepslate
setblock 48 126 574 minecraft:calcite
fill 48 126 575 48 129 575 minecraft:cobbled_deepslate
setblock 49 126 568 minecraft:calcite
fill 49 126 569 49 127 569 minecraft:cobbled_deepslate
setblock 49 126 573 minecraft:calcite
fill 49 126 574 49 127 574 minecraft:cobbled_deepslate
setblock 53 126 598 minecraft:cobbled_deepslate
setblock 54 126 558 minecraft:calcite
setblock 54 126 598 minecraft:calcite
fill 55 126 558 55 129 558 minecraft:cobbled_deepslate
fill 55 126 594 55 128 594 minecraft:deepslate
setblock 55 126 597 minecraft:calcite
fill 55 126 598 55 129 598 minecraft:cobbled_deepslate
fill 56 126 593 56 128 593 minecraft:deepslate
fill 56 126 595 56 128 595 minecraft:deepslate
fill 56 126 597 59 126 597 minecraft:cobbled_deepslate
fill 57 126 594 57 128 594 minecraft:deepslate
fill 57 126 596 57 129 596 minecraft:cobbled_deepslate
setblock 58 126 559 minecraft:calcite
setblock 59 126 558 minecraft:calcite
fill 59 126 559 59 129 559 minecraft:cobbled_deepslate
setblock 59 126 598 minecraft:calcite
fill 60 126 558 60 129 558 minecraft:cobbled_deepslate
setblock 60 126 597 minecraft:calcite
fill 60 126 598 60 129 598 minecraft:cobbled_deepslate
setblock 61 126 596 minecraft:calcite
fill 61 126 597 61 129 597 minecraft:cobbled_deepslate
fill 62 126 596 62 128 596 minecraft:cobbled_deepslate
setblock 64 126 558 minecraft:calcite
setblock 64 126 598 minecraft:calcite
setblock 65 126 558 minecraft:cobbled_deepslate
setblock 65 126 597 minecraft:calcite
fill 65 126 598 68 126 598 minecraft:cobbled_deepslate
fill 66 126 597 66 129 597 minecraft:cobbled_deepslate
setblock 69 126 597 minecraft:cobbled_deepslate
setblock 69 126 598 minecraft:calcite
setblock 70 126 597 minecraft:calcite
fill 70 126 598 70 129 598 minecraft:cobbled_deepslate
fill 71 126 597 74 126 597 minecraft:cobbled_deepslate
fill 73 126 596 75 126 596 minecraft:cobbled_deepslate
setblock 74 126 598 minecraft:calcite
setblock 75 126 597 minecraft:calcite
fill 75 126 598 75 129 598 minecraft:cobbled_deepslate
setblock 76 126 595 minecraft:cobbled_deepslate
setblock 76 126 596 minecraft:calcite
fill 76 126 597 76 129 597 minecraft:cobbled_deepslate
setblock 77 126 595 minecraft:calcite
fill 77 126 596 77 129 596 minecraft:cobbled_deepslate
fill 78 126 595 78 127 595 minecraft:cobbled_deepslate
setblock 79 126 558 minecraft:calcite
setblock 79 126 598 minecraft:calcite
setblock 80 126 597 minecraft:calcite
fill 80 126 598 80 129 598 minecraft:cobbled_deepslate
setblock 81 126 596 minecraft:calcite
fill 81 126 597 81 129 597 minecraft:cobbled_deepslate
setblock 84 126 598 minecraft:calcite
setblock 87 126 570 minecraft:calcite
fill 87 126 571 87 127 571 minecraft:cobbled_deepslate
setblock 87 126 575 minecraft:calcite
setblock 88 126 569 minecraft:calcite
fill 88 126 570 88 129 570 minecraft:cobbled_deepslate
setblock 88 126 574 minecraft:calcite
fill 88 126 575 88 129 575 minecraft:cobbled_deepslate
setblock 88 126 589 minecraft:calcite
setblock 88 126 590 minecraft:cobbled_deepslate
setblock 88 126 594 minecraft:calcite
setblock 48 127 568 minecraft:calcite
fill 48 127 569 48 130 569 minecraft:cobbled_deepslate
setblock 48 127 573 minecraft:calcite
fill 48 127 574 48 130 574 minecraft:cobbled_deepslate
setblock 49 127 568 minecraft:cobbled_deepslate
setblock 49 127 572 minecraft:calcite
fill 49 127 573 49 130 573 minecraft:cobbled_deepslate
setblock 52 127 558 minecraft:cobbled_deepslate
setblock 53 127 558 minecraft:calcite
setblock 53 127 598 minecraft:calcite
fill 54 127 558 54 130 558 minecraft:cobbled_deepslate
setblock 54 127 597 minecraft:calcite
fill 54 127 598 54 130 598 minecraft:cobbled_deepslate
fill 55 127 593 55 128 593 minecraft:deepslate
fill 55 127 595 55 128 595 minecraft:deepslate
fill 55 127 597 58 127 597 minecraft:cobbled_deepslate
setblock 57 127 559 minecraft:calcite
fill 57 127 593 57 128 593 minecraft:deepslate
fill 57 127 595 57 128 595 minecraft:deepslate
setblock 58 127 558 minecraft:calcite
fill 58 127 559 58 130 559 minecraft:cobbled_deepslate
setblock 58 127 598 minecraft:calcite
fill 59 127 558 59 130 558 minecraft:cobbled_deepslate
setblock 59 127 597 minecraft:calcite
fill 59 127 598 59 130 598 minecraft:cobbled_deepslate
setblock 60 127 596 minecraft:calcite
fill 60 127 597 60 130 597 minecraft:cobbled_deepslate
fill 61 127 596 61 130 596 minecraft:cobbled_deepslate
setblock 63 127 558 minecraft:calcite
setblock 63 127 598 minecraft:calcite
fill 64 127 558 64 128 558 minecraft:cobbled_deepslate
setblock 64 127 597 minecraft:calcite
fill 64 127 598 67 127 598 minecraft:cobbled_deepslate
fill 65 127 597 65 130 597 minecraft:cobbled_deepslate
setblock 68 127 598 minecraft:calcite
setblock 69 127 597 minecraft:calcite
fill 69 127 598 69 130 598 minecraft:cobbled_deepslate
fill 70 127 597 73 127 597 minecraft:cobbled_deepslate
fill 73 127 596 74 127 596 minecraft:cobbled_deepslate
setblock 73 127 598 minecraft:calcite
setblock 74 127 597 minecraft:calcite
fill 74 127 598 74 130 598 minecraft:cobbled_deepslate
setblock 75 127 596 minecraft:calcite
fill 75 127 597 75 130 597 minecraft:cobbled_deepslate
setblock 76 127 595 minecraft:calcite
fill 76 127 596 76 130 596 minecraft:cobbled_deepslate
fill 77 127 595 77 128 595 minecraft:cobbled_deepslate
setblock 78 127 598 minecraft:calcite
setblock 79 127 597 minecraft:calcite
fill 79 127 598 79 130 598 minecraft:cobbled_deepslate
setblock 80 127 596 minecraft:calcite
fill 80 127 597 80 130 597 minecraft:cobbled_deepslate
setblock 81 127 596 minecraft:cobbled_deepslate
setblock 83 127 598 minecraft:calcite
setblock 87 127 574 minecraft:calcite
fill 87 127 575 87 130 575 minecraft:cobbled_deepslate
setblock 88 127 568 minecraft:calcite
fill 88 127 569 88 129 569 minecraft:cobbled_deepslate
setblock 88 127 573 minecraft:calcite
fill 88 127 574 88 130 574 minecraft:cobbled_deepslate
setblock 88 127 578 minecraft:calcite
setblock 48 128 567 minecraft:calcite
fill 48 128 568 48 130 568 minecraft:cobbled_deepslate
setblock 48 128 572 minecraft:calcite
fill 48 128 573 48 131 573 minecraft:cobbled_deepslate
setblock 49 128 571 minecraft:calcite
fill 49 128 572 49 131 572 minecraft:cobbled_deepslate
setblock 50 128 560 minecraft:light[level=14]
setblock 50 128 568 minecraft:light[level=14]
setblock 50 128 576 minecraft:light[level=14]
setblock 50 128 584 minecraft:light[level=14]
setblock 50 128 592 minecraft:light[level=14]
setblock 52 128 558 minecraft:calcite
setblock 52 128 598 minecraft:calcite
fill 53 128 558 53 131 558 minecraft:cobbled_deepslate
fill 53 128 598 53 131 598 minecraft:cobbled_deepslate
setblock 54 128 594 minecraft:deepslate
fill 54 128 597 57 128 597 minecraft:cobbled_deepslate
setblock 56 128 559 minecraft:calcite
setblock 56 128 592 minecraft:deepslate
fill 56 128 596 56 130 596 minecraft:cobbled_deepslate
setblock 57 128 558 minecraft:calcite
fill 57 128 559 57 131 559 minecraft:cobbled_deepslate
setblock 57 128 598 minecraft:calcite
fill 58 128 558 58 131 558 minecraft:cobbled_deepslate
setblock 58 128 560 minecraft:light[level=14]
setblock 58 128 568 minecraft:light[level=14]
setblock 58 128 576 minecraft:light[level=14]
setblock 58 128 584 minecraft:light[level=14]
setblock 58 128 592 minecraft:light[level=14]
setblock 58 128 594 minecraft:deepslate
setblock 58 128 597 minecraft:calcite
fill 58 128 598 58 131 598 minecraft:cobbled_deepslate
setblock 59 128 596 minecraft:calcite
fill 59 128 597 59 131 597 minecraft:cobbled_deepslate
fill 60 128 596 60 131 596 minecraft:cobbled_deepslate
setblock 62 128 558 minecraft:calcite
setblock 62 128 598 minecraft:calcite
fill 63 128 558 63 131 558 minecraft:cobbled_deepslate
setblock 63 128 597 minecraft:calcite
fill 63 128 598 66 128 598 minecraft:cobbled_deepslate
fill 64 128 597 64 131 597 minecraft:cobbled_deepslate
setblock 66 128 560 minecraft:light[level=14]
setblock 66 128 576 minecraft:light[level=14]
setblock 66 128 584 minecraft:light[level=14]
setblock 66 128 592 minecraft:light[level=14]
setblock 67 128 598 minecraft:calcite
fill 68 128 598 68 131 598 minecraft:cobbled_deepslate
fill 69 128 597 72 128 597 minecraft:cobbled_deepslate
setblock 72 128 598 minecraft:calcite
setblock 73 128 596 minecraft:cobbled_deepslate
setblock 73 128 597 minecraft:calcite
fill 73 128 598 73 131 598 minecraft:cobbled_deepslate
setblock 74 128 560 minecraft:light[level=14]
setblock 74 128 568 minecraft:light[level=14]
setblock 74 128 576 minecraft:light[level=14]
setblock 74 128 584 minecraft:light[level=14]
setblock 74 128 592 minecraft:light[level=14]
setblock 74 128 596 minecraft:calcite
fill 74 128 597 74 131 597 minecraft:cobbled_deepslate
fill 75 128 596 75 131 596 minecraft:cobbled_deepslate
setblock 76 128 595 minecraft:cobbled_deepslate
setblock 77 128 598 minecraft:calcite
setblock 78 128 597 minecraft:calcite
fill 78 128 598 78 131 598 minecraft:cobbled_deepslate
setblock 79 128 596 minecraft:calcite
fill 79 128 597 79 131 597 minecraft:cobbled_deepslate
setblock 80 128 596 minecraft:cobbled_deepslate
setblock 82 128 560 minecraft:light[level=14]
setblock 82 128 568 minecraft:light[level=14]
setblock 82 128 576 minecraft:light[level=14]
setblock 82 128 584 minecraft:light[level=14]
setblock 82 128 592 minecraft:light[level=14]
setblock 82 128 598 minecraft:calcite
setblock 83 128 598 minecraft:cobbled_deepslate
setblock 87 128 573 minecraft:calcite
fill 87 128 574 87 131 574 minecraft:cobbled_deepslate
setblock 88 128 572 minecraft:calcite
fill 88 128 573 88 131 573 minecraft:cobbled_deepslate
setblock 88 128 577 minecraft:calcite
fill 88 128 578 88 131 578 minecraft:cobbled_deepslate
setblock 48 129 571 minecraft:calcite
fill 48 129 572 48 132 572 minecraft:cobbled_deepslate
setblock 48 129 576 minecraft:calcite
setblock 49 129 571 minecraft:cobbled_deepslate
setblock 51 129 558 minecraft:calcite
setblock 51 129 598 minecraft:calcite
fill 52 129 558 52 132 558 minecraft:cobbled_deepslate
fill 52 129 598 52 132 598 minecraft:cobbled_deepslate
fill 53 129 597 56 129 597 minecraft:cobbled_deepslate
setblock 54 129 559 minecraft:cobbled_deepslate
setblock 55 129 559 minecraft:calcite
setblock 56 129 558 minecraft:calcite
fill 56 129 559 56 132 559 minecraft:cobbled_deepslate
setblock 56 129 598 minecraft:calcite
fill 57 129 558 57 132 558 minecraft:cobbled_deepslate
setblock 57 129 597 minecraft:calcite
fill 57 129 598 57 132 598 minecraft:cobbled_deepslate
setblock 58 129 596 minecraft:calcite
fill 58 129 597 58 132 597 minecraft:cobbled_deepslate
fill 59 129 596 59 132 596 minecraft:cobbled_deepslate
setblock 60 129 559 minecraft:calcite
setblock 61 129 558 minecraft:calcite
setblock 61 129 598 minecraft:calcite
fill 62 129 558 62 132 558 minecraft:cobbled_deepslate
setblock 62 129 597 minecraft:calcite
fill 62 129 598 65 129 598 minecraft:cobbled_deepslate
fill 63 129 597 63 132 597 minecraft:cobbled_deepslate
setblock 66 129 598 minecraft:calcite
setblock 67 129 597 minecraft:calcite
fill 67 129 598 67 132 598 minecraft:cobbled_deepslate
fill 68 129 597 71 129 597 minecraft:cobbled_deepslate
setblock 71 129 598 minecraft:calcite
setblock 72 129 596 minecraft:cobbled_deepslate
setblock 72 129 597 minecraft:calcite
fill 72 129 598 72 132 598 minecraft:cobbled_deepslate
setblock 73 129 596 minecraft:calcite
fill 73 129 597 73 132 597 minecraft:cobbled_deepslate
fill 74 129 596 74 132 596 minecraft:cobbled_deepslate
setblock 76 129 598 minecraft:calcite
setblock 77 129 597 minecraft:calcite
fill 77 129 598 77 132 598 minecraft:cobbled_deepslate
setblock 78 129 596 minecraft:calcite
fill 78 129 597 78 132 597 minecraft:cobbled_deepslate
fill 79 129 596 79 130 596 minecraft:cobbled_deepslate
setblock 81 129 598 minecraft:calcite
fill 82 129 598 82 132 598 minecraft:cobbled_deepslate
fill 87 129 573 87 132 573 minecraft:cobbled_deepslate
setblock 88 129 571 minecraft:calcite
fill 88 129 572 88 132 572 minecraft:cobbled_deepslate
setblock 88 129 576 minecraft:calcite
fill 88 129 577 88 132 577 minecraft:cobbled_deepslate
setblock 48 130 570 minecraft:calcite
fill 48 130 571 48 133 571 minecraft:cobbled_deepslate
setblock 48 130 575 minecraft:calcite
fill 48 130 576 48 132 577 minecraft:cobbled_deepslate
setblock 50 130 558 minecraft:calcite
fill 51 130 558 51 133 558 minecraft:cobbled_deepslate
fill 51 130 598 51 133 598 minecraft:cobbled_deepslate
setblock 53 130 559 minecraft:cobbled_deepslate
fill 53 130 597 55 130 597 minecraft:cobbled_deepslate
setblock 54 130 559 minecraft:calcite
setblock 55 130 558 minecraft:calcite
fill 55 130 559 55 133 559 minecraft:cobbled_deepslate
fill 55 130 596 55 131 596 minecraft:cobbled_deepslate
setblock 55 130 598 minecraft:calcite
fill 56 130 558 56 133 558 minecraft:cobbled_deepslate
setblock 56 130 597 minecraft:calcite
fill 56 130 598 56 133 598 minecraft:cobbled_deepslate
setblock 57 130 596 minecraft:calcite
fill 57 130 597 57 133 597 minecraft:cobbled_deepslate
fill 58 130 596 58 133 596 minecraft:cobbled_deepslate
setblock 59 130 559 minecraft:calcite
setblock 60 130 558 minecraft:calcite
fill 60 130 559 60 133 559 minecraft:cobbled_deepslate
setblock 60 130 598 minecraft:calcite
fill 61 130 558 61 133 558 minecraft:cobbled_deepslate
setblock 61 130 597 minecraft:calcite
fill 61 130 598 64 130 598 minecraft:cobbled_deepslate
fill 62 130 597 62 133 597 minecraft:cobbled_deepslate
setblock 65 130 598 minecraft:calcite
setblock 66 130 597 minecraft:calcite
fill 66 130 598 66 133 598 minecraft:cobbled_deepslate
fill 67 130 597 70 130 597 minecraft:cobbled_deepslate
setblock 70 130 598 minecraft:calcite
setblock 71 130 597 minecraft:calcite
fill 71 130 598 71 133 598 minecraft:cobbled_deepslate
setblock 72 130 596 minecraft:calcite
fill 72 130 597 72 133 597 minecraft:cobbled_deepslate
fill 73 130 596 73 133 596 minecraft:cobbled_deepslate
setblock 74 130 558 minecraft:cobbled_deepslate
setblock 75 130 558 minecraft:calcite
setblock 75 130 598 minecraft:calcite
fill 76 130 558 77 132 558 minecraft:cobbled_deepslate
setblock 76 130 597 minecraft:calcite
fill 76 130 598 76 133 598 minecraft:cobbled_deepslate
setblock 77 130 596 minecraft:calcite
fill 77 130 597 77 133 597 minecraft:cobbled_deepslate
fill 78 130 596 78 132 596 minecraft:cobbled_deepslate
setblock 80 130 598 minecraft:calcite
fill 81 130 598 81 133 598 minecraft:cobbled_deepslate
setblock 88 130 570 minecraft:calcite
fill 88 130 571 88 133 571 minecraft:cobbled_deepslate
setblock 88 130 575 minecraft:calcite
fill 88 130 576 88 133 576 minecraft:cobbled_deepslate
setblock 88 130 579 minecraft:cobbled_deepslate
setblock 48 131 569 minecraft:calcite
fill 48 131 570 48 134 570 minecraft:cobbled_deepslate
setblock 48 131 574 minecraft:calcite
fill 48 131 575 48 134 575 minecraft:cobbled_deepslate
setblock 49 131 558 minecraft:calcite
setblock 49 131 573 minecraft:calcite
fill 49 131 574 49 134 574 minecraft:cobbled_deepslate
fill 50 131 558 50 134 558 minecraft:cobbled_deepslate
fill 50 131 598 50 134 598 minecraft:cobbled_deepslate
setblock 52 131 559 minecraft:cobbled_deepslate
fill 52 131 597 54 131 597 minecraft:cobbled_deepslate
setblock 53 131 559 minecraft:calcite
setblock 54 131 558 minecraft:calcite
fill 54 131 559 54 134 559 minecraft:cobbled_deepslate
fill 54 131 596 54 132 596 minecraft:cobbled_deepslate
setblock 54 131 598 minecraft:calcite
fill 55 131 558 55 134 558 minecraft:cobbled_deepslate
setblock 55 131 597 minecraft:calcite
fill 55 131 598 55 134 598 minecraft:cobbled_deepslate
setblock 56 131 596 minecraft:calcite
fill 56 131 597 56 134 597 minecraft:cobbled_deepslate
fill 57 131 595 59 134 595 minecraft:light_blue_stained_glass
fill 57 131 596 57 134 596 minecraft:cobbled_deepslate
setblock 58 131 559 minecraft:calcite
setblock 59 131 558 minecraft:calcite
fill 59 131 559 59 134 559 minecraft:cobbled_deepslate
setblock 59 131 598 minecraft:calcite
fill 60 131 558 60 134 558 minecraft:cobbled_deepslate
setblock 60 131 597 minecraft:calcite
fill 60 131 598 63 131 598 minecraft:cobbled_deepslate
fill 61 131 597 61 134 597 minecraft:cobbled_deepslate
setblock 64 131 598 minecraft:calcite
setblock 65 131 597 minecraft:calcite
fill 65 131 598 65 134 598 minecraft:cobbled_deepslate
fill 66 131 597 69 131 597 minecraft:cobbled_deepslate
setblock 69 131 598 minecraft:calcite
setblock 70 131 597 minecraft:calcite
fill 70 131 598 70 134 598 minecraft:cobbled_deepslate
setblock 71 131 596 minecraft:calcite
fill 71 131 597 71 134 597 minecraft:cobbled_deepslate
fill 72 131 558 73 131 558 minecraft:cobbled_deepslate
fill 72 131 596 72 134 596 minecraft:cobbled_deepslate
setblock 74 131 558 minecraft:calcite
setblock 74 131 598 minecraft:calcite
fill 75 131 558 75 134 558 minecraft:cobbled_deepslate
setblock 75 131 597 minecraft:calcite
fill 75 131 598 75 134 598 minecraft:cobbled_deepslate
setblock 76 131 596 minecraft:calcite
fill 76 131 597 76 134 597 minecraft:cobbled_deepslate
fill 77 131 596 77 134 596 minecraft:cobbled_deepslate
setblock 78 131 558 minecraft:cobbled_deepslate
setblock 79 131 598 minecraft:calcite
setblock 80 131 597 minecraft:calcite
fill 80 131 598 80 134 598 minecraft:cobbled_deepslate
setblock 87 131 575 minecraft:calcite
fill 87 131 576 87 134 576 minecraft:cobbled_deepslate
fill 88 131 570 88 134 570 minecraft:cobbled_deepslate
setblock 88 131 574 minecraft:calcite
fill 88 131 575 88 134 575 minecraft:cobbled_deepslate
setblock 88 131 579 minecraft:calcite
fill 88 131 580 88 134 580 minecraft:cobbled_deepslate
setblock 48 132 558 minecraft:calcite
fill 48 132 559 48 134 560 minecraft:cobbled_deepslate
fill 48 132 569 48 135 569 minecraft:cobbled_deepslate
setblock 48 132 573 minecraft:calcite
fill 48 132 574 48 135 574 minecraft:cobbled_deepslate
setblock 48 132 578 minecraft:calcite
setblock 48 132 598 minecraft:calcite
fill 49 132 558 49 135 558 minecraft:cobbled_deepslate
setblock 49 132 572 minecraft:calcite
fill 49 132 573 49 135 573 minecraft:cobbled_deepslate
fill 49 132 575 49 133 575 minecraft:cobbled_deepslate
fill 49 132 598 49 135 598 minecraft:cobbled_deepslate
fill 50 132 559 51 132 559 minecraft:cobbled_deepslate
fill 51 132 597 53 132 597 minecraft:cobbled_deepslate
setblock 52 132 559 minecraft:calcite
setblock 53 132 558 minecraft:calcite
fill 53 132 559 53 135 559 minecraft:cobbled_deepslate
setblock 53 132 598 minecraft:calcite
fill 54 132 558 54 135 558 minecraft:cobbled_deepslate
fill 54 132 560 55 132 560 minecraft:cobbled_deepslate
setblock 54 132 597 minecraft:calcite
fill 54 132 598 54 135 598 minecraft:cobbled_deepslate
setblock 55 132 596 minecraft:calcite
fill 55 132 597 55 135 597 minecraft:cobbled_deepslate
setblock 56 132 560 minecraft:calcite
fill 56 132 596 56 135 596 minecraft:cobbled_deepslate
setblock 57 132 559 minecraft:calcite
fill 57 132 594 59 134 594 minecraft:light_blue_stained_glass
setblock 58 132 558 minecraft:calcite
fill 58 132 559 58 135 559 minecraft:cobbled_deepslate
setblock 58 132 598 minecraft:calcite
fill 59 132 558 59 135 558 minecraft:cobbled_deepslate
setblock 59 132 597 minecraft:calcite
fill 59 132 598 62 132 598 minecraft:cobbled_deepslate
setblock 60 132 596 minecraft:calcite
fill 60 132 597 60 135 597 minecraft:cobbled_deepslate
setblock 63 132 558 minecraft:calcite
setblock 63 132 598 minecraft:calcite
fill 64 132 558 64 135 558 minecraft:cobbled_deepslate
setblock 64 132 597 minecraft:calcite
fill 64 132 598 64 135 598 minecraft:cobbled_deepslate
fill 65 132 597 68 132 597 minecraft:cobbled_deepslate
setblock 68 132 598 minecraft:calcite
setblock 69 132 597 minecraft:calcite
fill 69 132 598 69 135 598 minecraft:cobbled_deepslate
fill 70 132 558 72 132 558 minecraft:cobbled_deepslate
setblock 70 132 596 minecraft:calcite
fill 70 132 597 70 135 597 minecraft:cobbled_deepslate
fill 71 132 596 71 135 596 minecraft:cobbled_deepslate
setblock 73 132 558 minecraft:calcite
setblock 73 132 598 minecraft:calcite
fill 74 132 558 74 135 558 minecraft:cobbled_deepslate
setblock 74 132 597 minecraft:calcite
fill 74 132 598 74 135 598 minecraft:cobbled_deepslate
setblock 75 132 596 minecraft:calcite
fill 75 132 597 75 135 597 minecraft:cobbled_deepslate
fill 76 132 596 76 135 596 minecraft:cobbled_deepslate
setblock 78 132 558 minecraft:calcite
setblock 78 132 598 minecraft:calcite
fill 79 132 558 79 135 558 minecraft:cobbled_deepslate
setblock 79 132 597 minecraft:calcite
fill 79 132 598 79 135 598 minecraft:cobbled_deepslate
fill 80 132 597 80 133 597 minecraft:cobbled_deepslate
setblock 87 132 574 minecraft:calcite
fill 87 132 575 87 135 575 minecraft:cobbled_deepslate
fill 87 132 577 87 132 578 minecraft:cobbled_deepslate
setblock 88 132 573 minecraft:calcite
fill 88 132 574 88 135 574 minecraft:cobbled_deepslate
setblock 88 132 578 minecraft:calcite
fill 88 132 579 88 135 579 minecraft:cobbled_deepslate
fill 48 133 558 48 136 558 minecraft:cobbled_deepslate
setblock 48 133 561 minecraft:cobbled_deepslate
setblock 48 133 562 minecraft:calcite
fill 48 133 563 48 136 563 minecraft:cobbled_deepslate
fill 48 133 568 48 136 568 minecraft:cobbled_deepslate
setblock 48 133 572 minecraft:calcite
fill 48 133 573 48 136 573 minecraft:cobbled_deepslate
setblock 48 133 576 minecraft:cobbled_deepslate
setblock 48 133 577 minecraft:calcite
fill 48 133 578 48 135 579 minecraft:cobbled_deepslate
setblock 48 133 596 minecraft:cobbled_deepslate
setblock 48 133 597 minecraft:calcite
fill 48 133 598 48 136 598 minecraft:cobbled_deepslate
fill 49 133 559 49 133 560 minecraft:cobbled_deepslate
fill 49 133 572 49 136 572 minecraft:cobbled_deepslate
setblock 49 133 576 minecraft:calcite
fill 49 133 577 49 136 577 minecraft:cobbled_deepslate
setblock 50 133 559 minecraft:cobbled_deepslate
fill 50 133 597 52 133 597 minecraft:cobbled_deepslate
setblock 51 133 559 minecraft:calcite
setblock 52 133 558 minecraft:calcite
fill 52 133 559 52 135 560 minecraft:cobbled_deepslate
setblock 52 133 598 minecraft:calcite
fill 53 133 558 53 136 558 minecraft:cobbled_deepslate
fill 53 133 560 54 133 560 minecraft:cobbled_deepslate
setblock 53 133 596 minecraft:cobbled_deepslate
setblock 53 133 597 minecraft:calcite
fill 53 133 598 53 136 598 minecraft:cobbled_deepslate
setblock 54 133 596 minecraft:calcite
fill 54 133 597 54 136 597 minecraft:cobbled_deepslate
setblock 55 133 560 minecraft:calcite
fill 55 133 596 55 136 596 minecraft:cobbled_deepslate
setblock 56 133 559 minecraft:calcite
fill 56 133 560 57 135 560 minecraft:cobbled_deepslate
setblock 56 133 595 minecraft:light_blue_stained_glass
setblock 57 133 558 minecraft:calcite
fill 57 133 559 57 136 559 minecraft:cobbled_deepslate
fill 57 133 593 59 134 593 minecraft:light_blue_stained_glass
setblock 57 133 598 minecraft:calcite
fill 58 133 558 58 136 558 minecraft:cobbled_deepslate
fill 58 133 592 58 134 592 minecraft:light_blue_stained_glass
setblock 58 133 597 minecraft:calcite
fill 58 133 598 61 133 598 minecraft:cobbled_deepslate
setblock 59 133 596 minecraft:calcite
fill 59 133 597 59 136 597 minecraft:cobbled_deepslate
setblock 60 133 595 minecraft:light_blue_stained_glass
fill 60 133 596 60 135 596 minecraft:cobbled_deepslate
setblock 62 133 558 minecraft:calcite
setblock 62 133 598 minecraft:calcite
fill 63 133 558 63 136 558 minecraft:cobbled_deepslate
setblock 63 133 597 minecraft:calcite
fill 63 133 598 63 136 598 minecraft:cobbled_deepslate
fill 64 133 597 67 133 597 minecraft:cobbled_deepslate
fill 65 133 558 66 133 558 minecraft:cobbled_deepslate
setblock 67 133 558 minecraft:calcite
setblock 67 133 598 minecraft:calcite
fill 68 133 558 71 133 558 minecraft:cobbled_deepslate
setblock 68 133 597 minecraft:calcite
fill 68 133 598 68 136 598 minecraft:cobbled_deepslate
setblock 69 133 596 minecraft:calcite
fill 69 133 597 69 136 597 minecraft:cobbled_deepslate
fill 70 133 596 70 136 596 minecraft:cobbled_deepslate
setblock 72 133 558 minecraft:calcite
setblock 72 133 598 minecraft:calcite
fill 73 133 558 73 136 558 minecraft:cobbled_deepslate
setblock 73 133 597 minecraft:calcite
fill 73 133 598 73 136 598 minecraft:cobbled_deepslate
setblock 74 133 596 minecraft:calcite
fill 74 133 597 74 136 597 minecraft:cobbled_deepslate
fill 75 133 596 75 136 596 minecraft:cobbled_deepslate
setblock 76 133 558 minecraft:cobbled_deepslate
setblock 77 133 558 minecraft:calcite
setblock 77 133 598 minecraft:calcite
fill 78 133 558 78 136 558 minecraft:cobbled_deepslate
setblock 78 133 597 minecraft:calcite
fill 78 133 598 78 136 598 minecraft:cobbled_deepslate
fill 79 133 597 79 135 597 minecraft:cobbled_deepslate
setblock 82 133 598 minecraft:calcite
setblock 87 133 573 minecraft:calcite
fill 87 133 574 87 136 574 minecraft:cobbled_deepslate
setblock 87 133 577 minecraft:cobbled_deepslate
setblock 87 133 578 minecraft:calcite
fill 87 133 579 87 136 579 minecraft:cobbled_deepslate
fill 88 133 569 88 135 569 minecraft:cobbled_deepslate
setblock 88 133 572 minecraft:calcite
fill 88 133 573 88 136 573 minecraft:cobbled_deepslate
setblock 88 133 577 minecraft:calcite
fill 88 133 578 88 136 578 minecraft:cobbled_deepslate
setblock 88 133 581 minecraft:cobbled_deepslate
setblock 88 133 582 minecraft:calcite
setblock 48 134 561 minecraft:calcite
fill 48 134 562 49 136 562 minecraft:cobbled_deepslate
fill 48 134 564 48 134 565 minecraft:cobbled_deepslate
setblock 48 134 566 minecraft:calcite
fill 48 134 567 48 137 567 minecraft:cobbled_deepslate
setblock 48 134 571 minecraft:calcite
fill 48 134 572 48 137 572 minecraft:cobbled_deepslate
setblock 48 134 576 minecraft:calcite
fill 48 134 577 48 137 577 minecraft:cobbled_deepslate
setblock 48 134 580 minecraft:cobbled_deepslate
setblock 48 134 581 minecraft:calcite
setblock 48 134 595 minecraft:cobbled_deepslate
setblock 48 134 596 minecraft:calcite
fill 48 134 597 51 134 597 minecraft:cobbled_deepslate
setblock 49 134 559 minecraft:cobbled_deepslate
setblock 49 134 560 minecraft:calcite
fill 49 134 561 49 137 561 minecraft:cobbled_deepslate
fill 49 134 563 49 135 563 minecraft:cobbled_deepslate
fill 49 134 571 49 137 571 minecraft:cobbled_deepslate
setblock 49 134 575 minecraft:calcite
fill 49 134 576 49 137 576 minecraft:cobbled_deepslate
fill 49 134 578 49 135 578 minecraft:cobbled_deepslate
setblock 50 134 559 minecraft:calcite
fill 50 134 560 51 136 560 minecraft:cobbled_deepslate
setblock 51 134 558 minecraft:calcite
fill 51 134 559 51 137 559 minecraft:cobbled_deepslate
setblock 51 134 598 minecraft:calcite
fill 52 134 558 52 137 558 minecraft:cobbled_deepslate
setblock 52 134 596 minecraft:cobbled_deepslate
setblock 52 134 597 minecraft:calcite
fill 52 134 598 52 137 598 minecraft:cobbled_deepslate
setblock 53 134 560 minecraft:cobbled_deepslate
setblock 53 134 596 minecraft:calcite
fill 53 134 597 53 137 597 minecraft:cobbled_deepslate
setblock 54 134 560 minecraft:calcite
fill 54 134 596 54 137 596 minecraft:cobbled_deepslate
setblock 55 134 559 minecraft:calcite
fill 55 134 560 55 137 560 minecraft:cobbled_deepslate
setblock 56 134 558 minecraft:calcite
fill 56 134 559 56 137 559 minecraft:cobbled_deepslate
setblock 56 134 598 minecraft:calcite
fill 57 134 558 57 137 558 minecraft:cobbled_deepslate
setblock 57 134 597 minecraft:calcite
fill 57 134 598 60 134 598 minecraft:cobbled_deepslate
setblock 58 134 560 minecraft:cobbled_deepslate
setblock 58 134 591 minecraft:light_blue_stained_glass
setblock 58 134 596 minecraft:calcite
fill 58 134 597 58 137 597 minecraft:cobbled_deepslate
fill 59 134 596 59 136 596 minecraft:cobbled_deepslate
setblock 60 134 559 minecraft:calcite
setblock 61 134 558 minecraft:calcite
fill 61 134 559 61 137 559 minecraft:cobbled_deepslate
setblock 61 134 598 minecraft:calcite
fill 62 134 558 62 137 558 minecraft:cobbled_deepslate
setblock 62 134 597 minecraft:calcite
fill 62 134 598 62 137 598 minecraft:cobbled_deepslate
fill 63 134 597 66 134 597 minecraft:cobbled_deepslate
setblock 65 134 558 minecraft:cobbled_deepslate
setblock 66 134 558 minecraft:calcite
setblock 66 134 598 minecraft:calcite
fill 67 134 558 70 134 558 minecraft:cobbled_deepslate
setblock 67 134 597 minecraft:calcite
fill 67 134 598 67 137 598 minecraft:cobbled_deepslate
setblock 68 134 596 minecraft:calcite
fill 68 134 597 68 137 597 minecraft:cobbled_deepslate
fill 69 134 596 69 137 596 minecraft:cobbled_deepslate
setblock 71 134 558 minecraft:calcite
setblock 71 134 598 minecraft:calcite
fill 72 134 558 72 136 559 minecraft:cobbled_deepslate
setblock 72 134 597 minecraft:calcite
fill 72 134 598 72 137 598 minecraft:cobbled_deepslate
fill 73 134 559 74 134 559 minecraft:cobbled_deepslate
setblock 73 134 596 minecraft:calcite
fill 73 134 597 73 137 597 minecraft:cobbled_deepslate
fill 74 134 596 74 137 596 minecraft:cobbled_deepslate
setblock 75 134 559 minecraft:calcite
setblock 76 134 558 minecraft:calcite
fill 76 134 559 76 137 559 minecraft:cobbled_deepslate
setblock 76 134 598 minecraft:calcite
fill 77 134 558 77 137 558 minecraft:cobbled_deepslate
setblock 77 134 597 minecraft:calcite
fill 77 134 598 77 137 598 minecraft:cobbled_deepslate
fill 78 134 597 78 137 597 minecraft:cobbled_deepslate
setblock 80 134 558 minecraft:cobbled_deepslate
setblock 81 134 598 minecraft:calcite
fill 82 134 598 82 136 598 minecraft:cobbled_deepslate
fill 87 134 558 88 136 558 minecraft:cobbled_deepslate
setblock 87 134 572 minecraft:calcite
fill 87 134 573 87 137 573 minecraft:cobbled_deepslate
setblock 87 134 577 minecraft:calcite
fill 87 134 578 87 137 578 minecraft:cobbled_deepslate
fill 87 134 580 87 135 580 minecraft:cobbled_deepslate
fill 88 134 559 88 134 560 minecraft:cobbled_deepslate
setblock 88 134 561 minecraft:calcite
fill 88 134 568 88 136 568 minecraft:cobbled_deepslate
setblock 88 134 571 minecraft:calcite
fill 88 134 572 88 137 572 minecraft:cobbled_deepslate
setblock 88 134 576 minecraft:calcite
fill 88 134 577 88 137 577 minecraft:cobbled_deepslate
setblock 88 134 581 minecraft:calcite
fill 88 134 582 88 136 583 minecraft:cobbled_deepslate
fill 88 134 597 88 136 598 minecraft:cobbled_deepslate
setblock 48 135 559 minecraft:cobbled_deepslate
setblock 48 135 560 minecraft:calcite
fill 48 135 561 48 138 561 minecraft:cobbled_deepslate
setblock 48 135 564 minecraft:cobbled_deepslate
setblock 48 135 565 minecraft:calcite
fill 48 135 566 48 138 566 minecraft:cobbled_deepslate
setblock 48 135 570 minecraft:calcite
fill 48 135 571 48 138 571 minecraft:cobbled_deepslate
setblock 48 135 575 minecraft:calcite
fill 48 135 576 48 138 576 minecraft:cobbled_deepslate
setblock 48 135 580 minecraft:calcite
fill 48 135 581 48 137 582 minecraft:cobbled_deepslate
setblock 48 135 594 minecraft:cobbled_deepslate
setblock 48 135 595 minecraft:calcite
fill 48 135 596 49 136 597 minecraft:cobbled_deepslate
setblock 49 135 559 minecraft:calcite
fill 49 135 560 49 138 560 minecraft:cobbled_deepslate
setblock 49 135 564 minecraft:calcite
fill 49 135 565 49 138 565 minecraft:cobbled_deepslate
fill 49 135 570 49 138 570 minecraft:cobbled_deepslate
setblock 49 135 574 minecraft:calcite
fill 49 135 575 49 138 575 minecraft:cobbled_deepslate
setblock 49 135 579 minecraft:calcite
fill 49 135 580 49 138 580 minecraft:cobbled_deepslate
setblock 50 135 558 minecraft:calcite
fill 50 135 559 50 138 559 minecraft:cobbled_deepslate
fill 50 135 561 50 135 562 minecraft:cobbled_deepslate
fill 50 135 576 50 136 576 minecraft:cobbled_deepslate
setblock 50 135 597 minecraft:cobbled_deepslate
setblock 50 135 598 minecraft:calcite
fill 51 135 558 51 138 558 minecraft:cobbled_deepslate
setblock 51 135 596 minecraft:cobbled_deepslate
setblock 51 135 597 minecraft:calcite
fill 51 135 598 51 138 598 minecraft:cobbled_deepslate
setblock 52 135 561 minecraft:calcite
setblock 52 135 596 minecraft:calcite
fill 52 135 597 52 138 597 minecraft:cobbled_deepslate
setblock 53 135 560 minecraft:calcite
fill 53 135 561 54 137 561 minecraft:cobbled_deepslate
fill 53 135 596 53 138 596 minecraft:cobbled_deepslate
setblock 54 135 559 minecraft:calcite
fill 54 135 560 54 138 560 minecraft:cobbled_deepslate
setblock 55 135 558 minecraft:calcite
fill 55 135 559 55 138 559 minecraft:cobbled_deepslate
setblock 55 135 598 minecraft:calcite
fill 56 135 558 56 138 558 minecraft:cobbled_deepslate
setblock 56 135 597 minecraft:calcite
fill 56 135 598 59 135 598 minecraft:cobbled_deepslate
setblock 57 135 596 minecraft:calcite
fill 57 135 597 57 138 597 minecraft:cobbled_deepslate
setblock 58 135 560 minecraft:calcite
fill 58 135 596 58 137 596 minecraft:cobbled_deepslate
setblock 59 135 559 minecraft:calcite
setblock 60 135 558 minecraft:calcite
fill 60 135 559 60 138 559 minecraft:cobbled_deepslate
setblock 60 135 598 minecraft:calcite
fill 61 135 558 61 138 558 minecraft:cobbled_deepslate
setblock 61 135 597 minecraft:calcite
fill 61 135 598 61 138 598 minecraft:cobbled_deepslate
fill 62 135 559 62 136 559 minecraft:cobbled_deepslate
fill 62 135 597 65 135 597 minecraft:cobbled_deepslate
setblock 65 135 558 minecraft:calcite
setblock 65 135 598 minecraft:calcite
fill 66 135 558 69 135 558 minecraft:cobbled_deepslate
setblock 66 135 597 minecraft:calcite
fill 66 135 598 66 138 598 minecraft:cobbled_deepslate
fill 67 135 597 67 138 597 minecraft:cobbled_deepslate
fill 68 135 596 68 138 596 minecraft:cobbled_deepslate
setblock 69 135 559 minecraft:calcite
setblock 70 135 558 minecraft:calcite
fill 70 135 559 71 137 559 minecraft:cobbled_deepslate
setblock 70 135 598 minecraft:calcite
fill 71 135 558 71 138 558 minecraft:cobbled_deepslate
setblock 71 135 597 minecraft:calcite
fill 71 135 598 71 138 598 minecraft:cobbled_deepslate
setblock 72 135 596 minecraft:calcite
fill 72 135 597 72 138 597 minecraft:cobbled_deepslate
setblock 73 135 559 minecraft:cobbled_deepslate
fill 73 135 596 73 138 596 minecraft:cobbled_deepslate
setblock 74 135 559 minecraft:calcite
setblock 75 135 558 minecraft:calcite
fill 75 135 559 75 138 559 minecraft:cobbled_deepslate
setblock 75 135 598 minecraft:calcite
fill 76 135 558 76 138 558 minecraft:cobbled_deepslate
setblock 76 135 597 minecraft:calcite
fill 76 135 598 76 138 598 minecraft:cobbled_deepslate
fill 77 135 559 77 136 559 minecraft:cobbled_deepslate
setblock 77 135 596 minecraft:calcite
fill 77 135 597 77 138 597 minecraft:cobbled_deepslate
setblock 80 135 558 minecraft:calcite
setblock 80 135 598 minecraft:calcite
fill 81 135 558 81 138 558 minecraft:cobbled_deepslate
fill 81 135 598 81 137 598 minecraft:cobbled_deepslate
setblock 85 135 558 minecraft:calcite
fill 86 135 558 86 138 558 minecraft:cobbled_deepslate
setblock 86 135 576 minecraft:cobbled_deepslate
setblock 86 135 577 minecraft:calcite
fill 86 135 578 86 138 578 minecraft:cobbled_deepslate
fill 87 135 572 87 138 572 minecraft:cobbled_deepslate
setblock 87 135 576 minecraft:calcite
fill 87 135 577 87 138 577 minecraft:cobbled_deepslate
setblock 87 135 581 minecraft:calcite
fill 87 135 598 87 137 598 minecraft:cobbled_deepslate
setblock 88 135 559 minecraft:cobbled_deepslate
setblock 88 135 560 minecraft:calcite
fill 88 135 561 88 135 564 minecraft:cobbled_deepslate
setblock 88 135 565 minecraft:calcite
fill 88 135 566 88 137 567 minecraft:cobbled_deepslate
setblock 88 135 570 minecraft:calcite
fill 88 135 571 88 138 571 minecraft:cobbled_deepslate
setblock 88 135 575 minecraft:calcite
fill 88 135 576 88 138 576 minecraft:cobbled_deepslate
setblock 88 135 580 minecraft:calcite
fill 88 135 581 88 138 581 minecraft:cobbled_deepslate
setblock 88 135 584 minecraft:cobbled_deepslate
fill 88 135 596 88 138 596 minecraft:cobbled_deepslate
setblock 48 136 559 minecraft:calcite
fill 48 136 560 48 139 560 minecraft:cobbled_deepslate
setblock 48 136 564 minecraft:calcite
fill 48 136 565 48 139 565 minecraft:cobbled_deepslate
setblock 48 136 569 minecraft:calcite
fill 48 136 570 48 139 570 minecraft:cobbled_deepslate
setblock 48 136 574 minecraft:calcite
fill 48 136 575 48 139 575 minecraft:cobbled_deepslate
setblock 48 136 578 minecraft:cobbled_deepslate
setblock 48 136 579 minecraft:calcite
fill 48 136 580 48 139 580 minecraft:cobbled_deepslate
setblock 48 136 583 minecraft:cobbled_deepslate
setblock 48 136 594 minecraft:calcite
fill 48 136 595 49 138 595 minecraft:cobbled_deepslate
setblock 49 136 558 minecraft:calcite
fill 49 136 559 49 139 559 minecraft:cobbled_deepslate
setblock 49 136 563 minecraft:calcite
fill 49 136 564 50 138 564 minecraft:cobbled_deepslate
fill 49 136 566 49 136 567 minecraft:cobbled_deepslate
setblock 49 136 568 minecraft:calcite
fill 49 136 569 49 139 569 minecraft:cobbled_deepslate
setblock 49 136 573 minecraft:calcite
fill 49 136 574 49 139 574 minecraft:cobbled_deepslate
setblock 49 136 578 minecraft:calcite
fill 49 136 579 49 139 579 minecraft:cobbled_deepslate
fill 49 136 581 49 137 581 minecraft:cobbled_deepslate
setblock 49 136 598 minecraft:calcite
fill 50 136 558 50 139 558 minecraft:cobbled_deepslate
setblock 50 136 561 minecraft:cobbled_deepslate
setblock 50 136 562 minecraft:calcite
fill 50 136 563 50 139 563 minecraft:cobbled_deepslate
setblock 50 136 568 minecraft:light[level=14]
setblock 50 136 575 minecraft:cobbled_deepslate
setblock 50 136 577 minecraft:calcite
fill 50 136 578 50 138 578 minecraft:cobbled_deepslate
setblock 50 136 584 minecraft:light[level=14]
setblock 50 136 592 minecraft:light[level=14]
setblock 50 136 597 minecraft:calcite
fill 50 136 598 50 139 598 minecraft:cobbled_deepslate
setblock 51 136 561 minecraft:calcite
setblock 51 136 596 minecraft:calcite
fill 51 136 597 51 139 597 minecraft:cobbled_deepslate
setblock 52 136 559 minecraft:cobbled_deepslate
setblock 52 136 560 minecraft:calcite
fill 52 136 561 52 139 561 minecraft:cobbled_deepslate
fill 52 136 596 52 139 596 minecraft:cobbled_deepslate
setblock 53 136 559 minecraft:calcite
fill 53 136 560 53 139 560 minecraft:cobbled_deepslate
setblock 54 136 558 minecraft:calcite
fill 54 136 559 54 139 559 minecraft:cobbled_deepslate
setblock 54 136 598 minecraft:calcite
fill 55 136 558 55 139 558 minecraft:cobbled_deepslate
setblock 55 136 561 minecraft:cobbled_deepslate
setblock 55 136 597 minecraft:calcite
fill 55 136 598 58 136 598 minecraft:cobbled_deepslate
setblock 56 136 560 minecraft:cobbled_deepslate
setblock 56 136 596 minecraft:calcite
fill 56 136 597 56 139 597 minecraft:cobbled_deepslate
setblock 57 136 560 minecraft:calcite
fill 57 136 596 57 138 596 minecraft:cobbled_deepslate
setblock 58 136 559 minecraft:calcite
fill 58 136 560 58 138 560 minecraft:cobbled_deepslate
setblock 58 136 568 minecraft:light[level=14]
setblock 58 136 576 minecraft:light[level=14]
setblock 58 136 584 minecraft:light[level=14]
setblock 58 136 592 minecraft:light[level=14]
setblock 59 136 558 minecraft:calcite
fill 59 136 559 59 139 559 minecraft:cobbled_deepslate
setblock 59 136 598 minecraft:calcite
fill 60 136 558 60 139 558 minecraft:cobbled_deepslate
setblock 60 136 597 minecraft:calcite
fill 60 136 598 60 139 598 minecraft:cobbled_deepslate
fill 61 136 597 64 136 597 minecraft:cobbled_deepslate
setblock 64 136 558 minecraft:calcite
setblock 64 136 598 minecraft:calcite
fill 65 136 558 68 136 558 minecraft:cobbled_deepslate
setblock 65 136 597 minecraft:calcite
fill 65 136 598 65 139 598 minecraft:cobbled_deepslate
setblock 66 136 560 minecraft:light[level=14]
setblock 66 136 576 minecraft:light[level=14]
setblock 66 136 584 minecraft:light[level=14]
setblock 66 136 592 minecraft:light[level=14]
fill 66 136 597 66 139 597 minecraft:cobbled_deepslate
setblock 67 136 559 minecraft:cobbled_deepslate
fill 67 136 596 67 137 596 minecraft:cobbled_deepslate
setblock 68 136 559 minecraft:calcite
setblock 69 136 558 minecraft:calcite
fill 69 136 559 69 139 559 minecraft:cobbled_deepslate
setblock 69 136 598 minecraft:calcite
fill 70 136 558 70 139 558 minecraft:cobbled_deepslate
setblock 70 136 597 minecraft:calcite
fill 70 136 598 70 139 598 minecraft:cobbled_deepslate
setblock 71 136 596 minecraft:calcite
fill 71 136 597 71 139 597 minecraft:cobbled_deepslate
fill 72 136 596 72 139 596 minecraft:cobbled_deepslate
setblock 73 136 559 minecraft:calcite
setblock 74 136 558 minecraft:calcite
fill 74 136 559 74 139 559 minecraft:cobbled_deepslate
setblock 74 136 560 minecraft:light[level=14]
setblock 74 136 568 minecraft:light[level=14]
setblock 74 136 576 minecraft:light[level=14]
setblock 74 136 584 minecraft:light[level=14]
setblock 74 136 592 minecraft:light[level=14]
setblock 74 136 598 minecraft:calcite
fill 75 136 558 75 139 558 minecraft:cobbled_deepslate
setblock 75 136 597 minecraft:calcite
fill 75 136 598 75 139 598 minecraft:cobbled_deepslate
setblock 76 136 596 minecraft:calcite
fill 76 136 597 76 138 597 minecraft:cobbled_deepslate
setblock 79 136 558 minecraft:calcite
setblock 79 136 598 minecraft:calcite
fill 80 136 558 80 139 558 minecraft:cobbled_deepslate
fill 80 136 598 80 137 598 minecraft:cobbled_deepslate
fill 82 136 558 83 136 558 minecraft:cobbled_deepslate
setblock 82 136 560 minecraft:light[level=14]
setblock 82 136 568 minecraft:light[level=14]
setblock 82 136 576 minecraft:light[level=14]
setblock 82 136 584 minecraft:light[level=14]
setblock 82 136 592 minecraft:light[level=14]
setblock 84 136 558 minecraft:calcite
fill 85 136 558 85 139 558 minecraft:cobbled_deepslate
setblock 86 136 576 minecraft:calcite
fill 86 136 577 86 139 577 minecraft:cobbled_deepslate
fill 86 136 579 86 137 579 minecraft:cobbled_deepslate
fill 86 136 598 86 138 598 minecraft:cobbled_deepslate
setblock 87 136 559 minecraft:cobbled_deepslate
setblock 87 136 560 minecraft:calcite
fill 87 136 571 87 139 571 minecraft:cobbled_deepslate
setblock 87 136 575 minecraft:calcite
fill 87 136 576 87 139 576 minecraft:cobbled_deepslate
setblock 87 136 580 minecraft:calcite
fill 87 136 581 87 138 582 minecraft:cobbled_deepslate
setblock 88 136 559 minecraft:calcite
fill 88 136 560 88 136 563 minecraft:cobbled_deepslate
setblock 88 136 564 minecraft:calcite
fill 88 136 565 88 139 565 minecraft:cobbled_deepslate
setblock 88 136 569 minecraft:calcite
fill 88 136 570 88 139 570 minecraft:cobbled_deepslate
setblock 88 136 574 minecraft:calcite
fill 88 136 575 88 139 575 minecraft:cobbled_deepslate
setblock 88 136 579 minecraft:calcite
fill 88 136 580 88 139 580 minecraft:cobbled_deepslate
setblock 88 136 584 minecraft:calcite
fill 88 136 585 88 139 585 minecraft:cobbled_deepslate
setblock 48 137 558 minecraft:calcite
fill 48 137 559 48 140 559 minecraft:cobbled_deepslate
setblock 48 137 562 minecraft:cobbled_deepslate
setblock 48 137 563 minecraft:calcite
fill 48 137 564 48 140 564 minecraft:cobbled_deepslate
setblock 48 137 568 minecraft:calcite
fill 48 137 569 48 140 569 minecraft:cobbled_deepslate
setblock 48 137 573 minecraft:calcite
fill 48 137 574 48 140 574 minecraft:cobbled_deepslate
setblock 48 137 578 minecraft:calcite
fill 48 137 579 48 140 579 minecraft:cobbled_deepslate
setblock 48 137 583 minecraft:calcite
fill 48 137 584 48 139 585 minecraft:cobbled_deepslate
fill 48 137 594 48 140 594 minecraft:cobbled_deepslate
fill 48 137 596 48 137 597 minecraft:cobbled_deepslate
setblock 48 137 598 minecraft:calcite
fill 49 137 558 49 140 558 minecraft:cobbled_deepslate
setblock 49 137 562 minecraft:calcite
fill 49 137 563 49 140 563 minecraft:cobbled_deepslate
setblock 49 137 566 minecraft:cobbled_deepslate
setblock 49 137 567 minecraft:calcite
fill 49 137 568 49 140 568 minecraft:cobbled_deepslate
setblock 49 137 572 minecraft:calcite
fill 49 137 573 49 139 573 minecraft:cobbled_deepslate
setblock 49 137 577 minecraft:calcite
fill 49 137 578 49 140 578 minecraft:cobbled_deepslate
setblock 49 137 582 minecraft:calcite
fill 49 137 583 49 140 583 minecraft:cobbled_deepslate
setblock 49 137 596 minecraft:cobbled_deepslate
setblock 49 137 597 minecraft:calcite
fill 49 137 598 49 140 598 minecraft:cobbled_deepslate
setblock 50 137 560 minecraft:cobbled_deepslate
setblock 50 137 561 minecraft:calcite
fill 50 137 562 51 139 562 minecraft:cobbled_deepslate
setblock 50 137 565 minecraft:cobbled_deepslate
setblock 50 137 576 minecraft:calcite
fill 50 137 577 50 138 577 minecraft:cobbled_deepslate
fill 50 137 579 50 137 580 minecraft:cobbled_deepslate
setblock 50 137 596 minecraft:calcite
fill 50 137 597 50 140 597 minecraft:cobbled_deepslate
setblock 51 137 560 minecraft:calcite
fill 51 137 561 51 140 561 minecraft:cobbled_deepslate
fill 51 137 596 51 139 596 minecraft:cobbled_deepslate
setblock 52 137 559 minecraft:calcite
fill 52 137 560 52 140 560 minecraft:cobbled_deepslate
setblock 53 137 558 minecraft:calcite
fill 53 137 559 53 140 559 minecraft:cobbled_deepslate
setblock 53 137 598 minecraft:calcite
fill 54 137 558 54 140 558 minecraft:cobbled_deepslate
setblock 54 137 597 minecraft:calcite
fill 54 137 598 57 137 598 minecraft:cobbled_deepslate
setblock 55 137 561 minecraft:calcite
setblock 55 137 596 minecraft:calcite
fill 55 137 597 55 140 597 minecraft:cobbled_deepslate
setblock 56 137 560 minecraft:calcite
fill 56 137 596 56 138 596 minecraft:cobbled_deepslate
setblock 57 137 559 minecraft:calcite
fill 57 137 560 57 140 560 minecraft:cobbled_deepslate
setblock 58 137 558 minecraft:calcite
fill 58 137 559 58 140 559 minecraft:cobbled_deepslate
setblock 58 137 598 minecraft:calcite
fill 59 137 558 59 140 558 minecraft:cobbled_deepslate
setblock 59 137 597 minecraft:calcite
fill 59 137 598 59 140 598 minecraft:cobbled_deepslate
fill 60 137 597 63 137 597 minecraft:cobbled_deepslate
setblock 62 137 559 minecraft:calcite
setblock 63 137 558 minecraft:calcite
fill 63 137 559 63 138 559 minecraft:cobbled_deepslate
setblock 63 137 598 minecraft:calcite
fill 64 137 558 67 137 558 minecraft:cobbled_deepslate
setblock 64 137 597 minecraft:calcite
fill 64 137 598 64 140 598 minecraft:cobbled_deepslate
fill 65 137 559 66 137 559 minecraft:cobbled_deepslate
fill 65 137 597 65 140 597 minecraft:cobbled_deepslate
setblock 67 137 559 minecraft:calcite
setblock 68 137 558 minecraft:calcite
fill 68 137 559 68 140 559 minecraft:cobbled_deepslate
setblock 68 137 598 minecraft:calcite
fill 69 137 558 69 140 558 minecraft:cobbled_deepslate
setblock 69 137 597 minecraft:calcite
fill 69 137 598 69 140 598 minecraft:cobbled_deepslate
setblock 70 137 596 minecraft:calcite
fill 70 137 597 70 140 597 minecraft:cobbled_deepslate
fill 71 137 596 71 139 596 minecraft:cobbled_deepslate
setblock 72 137 558 minecraft:cobbled_deepslate
setblock 72 137 559 minecraft:calcite
setblock 73 137 558 minecraft:calcite
fill 73 137 559 73 140 559 minecraft:cobbled_deepslate
setblock 73 137 598 minecraft:calcite
fill 74 137 558 74 140 558 minecraft:cobbled_deepslate
setblock 74 137 597 minecraft:calcite
fill 74 137 598 74 140 598 minecraft:cobbled_deepslate
setblock 75 137 596 minecraft:calcite
fill 75 137 597 75 139 597 minecraft:cobbled_deepslate
setblock 77 137 559 minecraft:calcite
setblock 78 137 558 minecraft:calcite
setblock 78 137 559 minecraft:cobbled_deepslate
setblock 78 137 598 minecraft:calcite
fill 79 137 558 79 140 558 minecraft:cobbled_deepslate
fill 79 137 598 79 138 598 minecraft:cobbled_deepslate
setblock 82 137 558 minecraft:cobbled_deepslate
setblock 83 137 558 minecraft:calcite
fill 84 137 558 84 140 558 minecraft:cobbled_deepslate
setblock 86 137 559 minecraft:cobbled_deepslate
fill 86 137 576 86 138 576 minecraft:cobbled_deepslate
setblock 86 137 580 minecraft:calcite
setblock 87 137 558 minecraft:cobbled_deepslate
setblock 87 137 559 minecraft:calcite
fill 87 137 560 87 137 563 minecraft:cobbled_deepslate
setblock 87 137 564 minecraft:calcite
setblock 87 137 574 minecraft:calcite
fill 87 137 575 87 140 575 minecraft:cobbled_deepslate
setblock 87 137 579 minecraft:calcite
fill 87 137 580 87 140 580 minecraft:cobbled_deepslate
setblock 87 137 583 minecraft:cobbled_deepslate
setblock 88 137 558 minecraft:calcite
fill 88 137 559 88 137 562 minecraft:cobbled_deepslate
setblock 88 137 563 minecraft:calcite
fill 88 137 564 88 140 564 minecraft:cobbled_deepslate
setblock 88 137 568 minecraft:calcite
fill 88 137 569 88 140 569 minecraft:cobbled_deepslate
setblock 88 137 573 minecraft:calcite
fill 88 137 574 88 140 574 minecraft:cobbled_deepslate
setblock 88 137 578 minecraft:calcite
fill 88 137 579 88 140 579 minecraft:cobbled_deepslate
setblock 88 137 582 minecraft:cobbled_deepslate
setblock 88 137 583 minecraft:calcite
fill 88 137 584 88 140 584 minecraft:cobbled_deepslate
fill 88 137 586 88 138 586 minecraft:cobbled_deepslate
setblock 88 137 597 minecraft:cobbled_deepslate
setblock 88 137 598 minecraft:calcite
fill 48 138 558 48 141 558 minecraft:cobbled_deepslate
setblock 48 138 562 minecraft:calcite
fill 48 138 563 48 141 563 minecraft:cobbled_deepslate
setblock 48 138 567 minecraft:calcite
fill 48 138 568 48 141 568 minecraft:cobbled_deepslate
setblock 48 138 572 minecraft:calcite
fill 48 138 573 48 141 573 minecraft:cobbled_deepslate
setblock 48 138 577 minecraft:calcite
fill 48 138 578 48 141 578 minecraft:cobbled_deepslate
setblock 48 138 581 minecraft:cobbled_deepslate
setblock 48 138 582 minecraft:calcite
fill 48 138 583 48 141 583 minecraft:cobbled_deepslate
setblock 48 138 586 minecraft:cobbled_deepslate
fill 48 138 593 48 139 593 minecraft:cobbled_deepslate
setblock 48 138 596 minecraft:cobbled_deepslate
setblock 48 138 597 minecraft:calcite
fill 48 138 598 48 141 598 minecraft:cobbled_deepslate
setblock 49 138 561 minecraft:calcite
fill 49 138 562 49 141 562 minecraft:cobbled_deepslate
setblock 49 138 566 minecraft:calcite
fill 49 138 567 49 141 567 minecraft:cobbled_deepslate
setblock 49 138 571 minecraft:calcite
setblock 49 138 572 minecraft:cobbled_deepslate
setblock 49 138 576 minecraft:calcite
fill 49 138 577 49 140 577 minecraft:cobbled_deepslate
setblock 49 138 581 minecraft:calcite
fill 49 138 582 49 141 582 minecraft:cobbled_deepslate
fill 49 138 584 49 139 584 minecraft:cobbled_deepslate
setblock 49 138 596 minecraft:calcite
fill 49 138 597 49 141 597 minecraft:cobbled_deepslate
setblock 50 138 560 minecraft:calcite
fill 50 138 561 50 141 561 minecraft:cobbled_deepslate
setblock 50 138 565 minecraft:calcite
fill 50 138 566 50 141 566 minecraft:cobbled_deepslate
setblock 50 138 579 minecraft:cobbled_deepslate
setblock 50 138 580 minecraft:calcite
fill 50 138 581 50 139 581 minecraft:cobbled_deepslate
setblock 50 138 596 minecraft:cobbled_deepslate
setblock 51 138 559 minecraft:calcite
fill 51 138 560 51 141 560 minecraft:cobbled_deepslate
setblock 51 138 563 minecraft:cobbled_deepslate
setblock 52 138 558 minecraft:calcite
fill 52 138 559 52 141 559 minecraft:cobbled_deepslate
setblock 52 138 598 minecraft:calcite
fill 53 138 558 53 141 558 minecraft:cobbled_deepslate
setblock 53 138 561 minecraft:cobbled_deepslate
setblock 53 138 597 minecraft:calcite
fill 53 138 598 56 138 598 minecraft:cobbled_deepslate
setblock 54 138 561 minecraft:calcite
setblock 54 138 596 minecraft:calcite
fill 54 138 597 54 141 597 minecraft:cobbled_deepslate
setblock 55 138 560 minecraft:calcite
fill 55 138 561 55 139 561 minecraft:cobbled_deepslate
fill 55 138 596 55 139 596 minecraft:cobbled_deepslate
setblock 56 138 559 minecraft:calcite
fill 56 138 560 56 140 560 minecraft:cobbled_deepslate
setblock 57 138 558 minecraft:calcite
fill 57 138 559 57 141 559 minecraft:cobbled_deepslate
setblock 57 138 598 minecraft:calcite
fill 58 138 558 58 141 558 minecraft:cobbled_deepslate
setblock 58 138 597 minecraft:calcite
fill 58 138 598 58 141 598 minecraft:cobbled_deepslate
fill 59 138 597 62 138 597 minecraft:cobbled_deepslate
setblock 61 138 559 minecraft:calcite
setblock 62 138 558 minecraft:calcite
setblock 62 138 559 minecraft:cobbled_deepslate
setblock 62 138 598 minecraft:calcite
fill 63 138 558 66 138 558 minecraft:cobbled_deepslate
setblock 63 138 597 minecraft:calcite
fill 63 138 598 63 141 598 minecraft:cobbled_deepslate
fill 64 138 559 65 138 559 minecraft:cobbled_deepslate
fill 64 138 597 64 139 597 minecraft:cobbled_deepslate
setblock 66 138 559 minecraft:calcite
setblock 67 138 558 minecraft:calcite
fill 67 138 559 67 141 559 minecraft:cobbled_deepslate
setblock 67 138 598 minecraft:calcite
fill 68 138 558 68 141 558 minecraft:cobbled_deepslate
setblock 68 138 597 minecraft:calcite
fill 68 138 598 68 141 598 minecraft:cobbled_deepslate
setblock 69 138 596 minecraft:calcite
fill 69 138 597 69 141 597 minecraft:cobbled_deepslate
setblock 70 138 559 minecraft:cobbled_deepslate
fill 70 138 596 70 139 596 minecraft:cobbled_deepslate
setblock 71 138 559 minecraft:calcite
fill 71 138 560 73 138 560 minecraft:cobbled_deepslate
setblock 72 138 558 minecraft:calcite
fill 72 138 559 72 141 559 minecraft:cobbled_deepslate
setblock 72 138 598 minecraft:calcite
fill 73 138 558 73 141 558 minecraft:cobbled_deepslate
setblock 73 138 597 minecraft:calcite
fill 73 138 598 73 141 598 minecraft:cobbled_deepslate
setblock 74 138 596 minecraft:calcite
fill 74 138 597 74 140 597 minecraft:cobbled_deepslate
setblock 76 138 559 minecraft:calcite
setblock 77 138 558 minecraft:calcite
fill 77 138 559 77 139 559 minecraft:cobbled_deepslate
setblock 77 138 598 minecraft:calcite
fill 78 138 558 78 140 558 minecraft:cobbled_deepslate
fill 78 138 598 78 139 598 minecraft:cobbled_deepslate
setblock 82 138 558 minecraft:calcite
fill 83 138 558 83 141 558 minecraft:cobbled_deepslate
setblock 85 138 559 minecraft:cobbled_deepslate
setblock 86 138 559 minecraft:calcite
setblock 86 138 579 minecraft:calcite
fill 86 138 580 86 140 581 minecraft:cobbled_deepslate
setblock 87 138 558 minecraft:calcite
fill 87 138 559 87 138 562 minecraft:cobbled_deepslate
setblock 87 138 563 minecraft:calcite
fill 87 138 564 87 139 566 minecraft:cobbled_deepslate
fill 87 138 570 87 140 570 minecraft:cobbled_deepslate
setblock 87 138 573 minecraft:calcite
fill 87 138 574 87 141 574 minecraft:cobbled_deepslate
setblock 87 138 578 minecraft:calcite
fill 87 138 579 87 141 579 minecraft:cobbled_deepslate
setblock 87 138 583 minecraft:calcite
fill 87 138 584 87 141 584 minecraft:cobbled_deepslate
setblock 87 138 598 minecraft:calcite
fill 88 138 558 88 138 561 minecraft:cobbled_deepslate
setblock 88 138 562 minecraft:calcite
fill 88 138 563 88 141 563 minecraft:cobbled_deepslate
setblock 88 138 566 minecraft:cobbled_deepslate
setblock 88 138 567 minecraft:calcite
fill 88 138 568 88 141 568 minecraft:cobbled_deepslate
setblock 88 138 572 minecraft:calcite
fill 88 138 573 88 141 573 minecraft:cobbled_deepslate
setblock 88 138 577 minecraft:calcite
fill 88 138 578 88 141 578 minecraft:cobbled_deepslate
setblock 88 138 582 minecraft:calcite
fill 88 138 583 88 141 583 minecraft:cobbled_deepslate
setblock 88 138 587 minecraft:calcite
setblock 88 138 597 minecraft:calcite
fill 88 138 598 88 141 598 minecraft:cobbled_deepslate
setblock 48 139 561 minecraft:calcite
fill 48 139 562 48 142 562 minecraft:cobbled_deepslate
setblock 48 139 566 minecraft:calcite
fill 48 139 567 48 142 567 minecraft:cobbled_deepslate
setblock 48 139 571 minecraft:calcite
fill 48 139 572 48 142 572 minecraft:cobbled_deepslate
setblock 48 139 576 minecraft:calcite
fill 48 139 577 48 142 577 minecraft:cobbled_deepslate
setblock 48 139 581 minecraft:calcite
fill 48 139 582 48 142 582 minecraft:cobbled_deepslate
setblock 48 139 586 minecraft:calcite
fill 48 139 587 48 142 587 minecraft:cobbled_deepslate
setblock 48 139 595 minecraft:cobbled_deepslate
setblock 48 139 596 minecraft:calcite
fill 48 139 597 48 142 597 minecraft:cobbled_deepslate
setblock 49 139 560 minecraft:calcite
fill 49 139 561 49 142 561 minecraft:cobbled_deepslate
setblock 49 139 564 minecraft:cobbled_deepslate
setblock 49 139 565 minecraft:calcite
fill 49 139 566 49 142 566 minecraft:cobbled_deepslate
setblock 49 139 575 minecraft:calcite
fill 49 139 576 49 140 576 minecraft:cobbled_deepslate
setblock 49 139 580 minecraft:calcite
fill 49 139 581 49 142 581 minecraft:cobbled_deepslate
setblock 49 139 595 minecraft:calcite
fill 49 139 596 49 141 596 minecraft:cobbled_deepslate
setblock 50 139 559 minecraft:calcite
fill 50 139 560 50 142 560 minecraft:cobbled_deepslate
setblock 50 139 564 minecraft:calcite
fill 50 139 565 50 142 565 minecraft:cobbled_deepslate
setblock 50 139 579 minecraft:calcite
setblock 50 139 580 minecraft:cobbled_deepslate
setblock 51 139 558 minecraft:calcite
fill 51 139 559 51 142 559 minecraft:cobbled_deepslate
setblock 51 139 563 minecraft:calcite
setblock 51 139 598 minecraft:calcite
fill 52 139 558 52 142 558 minecraft:cobbled_deepslate
setblock 52 139 597 minecraft:calcite
fill 52 139 598 55 139 598 minecraft:cobbled_deepslate
setblock 53 139 561 minecraft:calcite
setblock 53 139 596 minecraft:calcite
fill 53 139 597 53 142 597 minecraft:cobbled_deepslate
setblock 54 139 560 minecraft:calcite
fill 54 139 561 54 140 561 minecraft:cobbled_deepslate
setblock 54 139 596 minecraft:cobbled_deepslate
setblock 55 139 559 minecraft:calcite
fill 55 139 560 55 141 560 minecraft:cobbled_deepslate
setblock 56 139 558 minecraft:calcite
fill 56 139 559 56 142 559 minecraft:cobbled_deepslate
setblock 56 139 598 minecraft:calcite
fill 57 139 558 57 142 558 minecraft:cobbled_deepslate
setblock 57 139 597 minecraft:calcite
fill 57 139 598 57 142 598 minecraft:cobbled_deepslate
fill 58 139 597 61 139 597 minecraft:cobbled_deepslate
setblock 60 139 559 minecraft:calcite
setblock 61 139 558 minecraft:calcite
setblock 61 139 559 minecraft:cobbled_deepslate
setblock 61 139 598 minecraft:calcite
fill 62 139 558 65 139 558 minecraft:cobbled_deepslate
setblock 62 139 597 minecraft:calcite
fill 62 139 598 62 142 598 minecraft:cobbled_deepslate
setblock 63 139 597 minecraft:cobbled_deepslate
setblock 65 139 559 minecraft:calcite
setblock 66 139 558 minecraft:calcite
fill 66 139 559 66 141 559 minecraft:cobbled_deepslate
setblock 66 139 598 minecraft:calcite
fill 67 139 558 67 142 558 minecraft:cobbled_deepslate
setblock 67 139 597 minecraft:calcite
fill 67 139 598 67 142 598 minecraft:cobbled_deepslate
fill 68 139 597 68 141 597 minecraft:cobbled_deepslate
setblock 69 139 596 minecraft:cobbled_deepslate
setblock 70 139 559 minecraft:calcite
setblock 71 139 558 minecraft:calcite
fill 71 139 559 71 139 560 minecraft:cobbled_deepslate
setblock 71 139 598 minecraft:calcite
fill 72 139 558 72 142 558 minecraft:cobbled_deepslate
setblock 72 139 560 minecraft:cobbled_deepslate
setblock 72 139 597 minecraft:calcite
fill 72 139 598 72 142 598 minecraft:cobbled_deepslate
fill 73 139 597 73 140 597 minecraft:cobbled_deepslate
setblock 75 139 559 minecraft:calcite
setblock 76 139 558 minecraft:calcite
setblock 76 139 559 minecraft:cobbled_deepslate
setblock 76 139 598 minecraft:calcite
fill 77 139 558 77 141 558 minecraft:cobbled_deepslate
setblock 77 139 598 minecraft:cobbled_deepslate
setblock 81 139 558 minecraft:calcite
fill 82 139 558 82 140 558 minecraft:cobbled_deepslate
setblock 85 139 559 minecraft:calcite
setblock 86 139 558 minecraft:calcite
fill 86 139 559 88 140 559 minecraft:cobbled_deepslate
setblock 86 139 578 minecraft:calcite
fill 86 139 579 86 140 579 minecraft:cobbled_deepslate
setblock 86 139 598 minecraft:calcite
fill 87 139 558 88 141 558 minecraft:cobbled_deepslate
fill 87 139 560 87 139 561 minecraft:cobbled_deepslate
setblock 87 139 562 minecraft:calcite
fill 87 139 563 87 142 563 minecraft:cobbled_deepslate
setblock 87 139 567 minecraft:calcite
fill 87 139 568 87 141 569 minecraft:cobbled_deepslate
setblock 87 139 572 minecraft:calcite
fill 87 139 573 87 140 573 minecraft:cobbled_deepslate
setblock 87 139 577 minecraft:calcite
fill 87 139 578 87 142 578 minecraft:cobbled_deepslate
setblock 87 139 581 minecraft:cobbled_deepslate
setblock 87 139 582 minecraft:calcite
fill 87 139 583 87 142 583 minecraft:cobbled_deepslate
fill 87 139 598 87 141 598 minecraft:cobbled_deepslate
setblock 88 139 560 minecraft:cobbled_deepslate
setblock 88 139 561 minecraft:calcite
fill 88 139 562 88 142 562 minecraft:cobbled_deepslate
setblock 88 139 566 minecraft:calcite
fill 88 139 567 88 142 567 minecraft:cobbled_deepslate
setblock 88 139 571 minecraft:calcite
fill 88 139 572 88 142 572 minecraft:cobbled_deepslate
setblock 88 139 576 minecraft:calcite
fill 88 139 577 88 142 577 minecraft:cobbled_deepslate
setblock 88 139 581 minecraft:calcite
fill 88 139 582 88 142 582 minecraft:cobbled_deepslate
setblock 88 139 586 minecraft:calcite
fill 88 139 587 88 142 587 minecraft:cobbled_deepslate
setblock 88 139 596 minecraft:calcite
fill 88 139 597 88 141 597 minecraft:cobbled_deepslate
setblock 48 140 560 minecraft:calcite
fill 48 140 561 48 143 561 minecraft:cobbled_deepslate
setblock 48 140 565 minecraft:calcite
fill 48 140 566 48 143 566 minecraft:cobbled_deepslate
setblock 48 140 570 minecraft:calcite
fill 48 140 571 48 143 571 minecraft:cobbled_deepslate
setblock 48 140 575 minecraft:calcite
fill 48 140 576 48 142 576 minecraft:cobbled_deepslate
setblock 48 140 580 minecraft:calcite
fill 48 140 581 48 143 581 minecraft:cobbled_deepslate
setblock 48 140 584 minecraft:cobbled_deepslate
setblock 48 140 585 minecraft:calcite
fill 48 140 586 48 143 586 minecraft:cobbled_deepslate
fill 48 140 588 48 141 588 minecraft:cobbled_deepslate
setblock 48 140 595 minecraft:calcite
fill 48 140 596 48 143 596 minecraft:cobbled_deepslate
setblock 49 140 559 minecraft:calcite
fill 49 140 560 49 143 560 minecraft:cobbled_deepslate
setblock 49 140 564 minecraft:calcite
fill 49 140 565 49 143 565 minecraft:cobbled_deepslate
setblock 49 140 569 minecraft:calcite
setblock 49 140 579 minecraft:calcite
fill 49 140 580 49 142 580 minecraft:cobbled_deepslate
setblock 49 140 584 minecraft:calcite
fill 49 140 585 49 143 585 minecraft:cobbled_deepslate
setblock 50 140 558 minecraft:calcite
fill 50 140 559 50 143 559 minecraft:cobbled_deepslate
setblock 50 140 562 minecraft:cobbled_deepslate
setblock 50 140 563 minecraft:calcite
fill 50 140 564 50 143 564 minecraft:cobbled_deepslate
setblock 50 140 598 minecraft:calcite
fill 51 140 558 51 143 558 minecraft:cobbled_deepslate
setblock 51 140 562 minecraft:calcite
fill 51 140 563 51 141 563 minecraft:cobbled_deepslate
setblock 51 140 597 minecraft:calcite
fill 51 140 598 54 140 598 minecraft:cobbled_deepslate
setblock 52 140 561 minecraft:calcite
fill 52 140 597 52 143 597 minecraft:cobbled_deepslate
setblock 53 140 560 minecraft:calcite
fill 53 140 561 53 141 561 minecraft:cobbled_deepslate
setblock 54 140 559 minecraft:calcite
fill 54 140 560 54 142 560 minecraft:cobbled_deepslate
setblock 55 140 558 minecraft:calcite
fill 55 140 559 55 143 559 minecraft:cobbled_deepslate
setblock 55 140 598 minecraft:calcite
fill 56 140 558 56 143 558 minecraft:cobbled_deepslate
setblock 56 140 597 minecraft:calcite
fill 56 140 598 56 143 598 minecraft:cobbled_deepslate
fill 57 140 597 58 140 597 minecraft:cobbled_deepslate
setblock 59 140 559 minecraft:calcite
setblock 60 140 558 minecraft:calcite
setblock 60 140 559 minecraft:cobbled_deepslate
setblock 60 140 598 minecraft:calcite
fill 61 140 558 64 140 558 minecraft:cobbled_deepslate
fill 61 140 598 61 142 598 minecraft:cobbled_deepslate
setblock 65 140 558 minecraft:calcite
setblock 65 140 559 minecraft:cobbled_deepslate
setblock 65 140 598 minecraft:calcite
fill 66 140 558 66 143 558 minecraft:cobbled_deepslate
setblock 66 140 597 minecraft:calcite
fill 66 140 598 66 143 598 minecraft:cobbled_deepslate
fill 67 140 597 67 141 597 minecraft:cobbled_deepslate
setblock 69 140 559 minecraft:calcite
setblock 70 140 558 minecraft:calcite
fill 70 140 559 71 142 559 minecraft:cobbled_deepslate
setblock 70 140 598 minecraft:calcite
fill 71 140 558 71 143 558 minecraft:cobbled_deepslate
setblock 71 140 597 minecraft:calcite
fill 71 140 598 71 143 598 minecraft:cobbled_deepslate
fill 72 140 597 72 141 597 minecraft:cobbled_deepslate
setblock 74 140 559 minecraft:calcite
setblock 75 140 558 minecraft:calcite
setblock 75 140 559 minecraft:cobbled_deepslate
setblock 75 140 598 minecraft:calcite
fill 76 140 558 76 141 558 minecraft:cobbled_deepslate
setblock 76 140 598 minecraft:cobbled_deepslate
setblock 80 140 558 minecraft:calcite
setblock 81 140 558 minecraft:cobbled_deepslate
setblock 85 140 558 minecraft:calcite
fill 85 140 559 85 143 559 minecraft:cobbled_deepslate
fill 86 140 558 86 143 558 minecraft:cobbled_deepslate
fill 86 140 560 86 140 561 minecraft:cobbled_deepslate
setblock 86 140 562 minecraft:calcite
setblock 87 140 560 minecraft:cobbled_deepslate
setblock 87 140 561 minecraft:calcite
fill 87 140 562 87 143 562 minecraft:cobbled_deepslate
fill 87 140 564 87 140 565 minecraft:cobbled_deepslate
setblock 87 140 566 minecraft:calcite
fill 87 140 567 87 143 567 minecraft:cobbled_deepslate
setblock 87 140 571 minecraft:calcite
setblock 87 140 572 minecraft:cobbled_deepslate
setblock 87 140 576 minecraft:calcite
fill 87 140 577 87 142 577 minecraft:cobbled_deepslate
setblock 87 140 581 minecraft:calcite
fill 87 140 582 87 143 582 minecraft:cobbled_deepslate
setblock 87 140 585 minecraft:cobbled_deepslate
setblock 88 140 560 minecraft:calcite
fill 88 140 561 88 143 561 minecraft:cobbled_deepslate
setblock 88 140 565 minecraft:calcite
fill 88 140 566 88 143 566 minecraft:cobbled_deepslate
setblock 88 140 570 minecraft:calcite
fill 88 140 571 88 143 571 minecraft:cobbled_deepslate
setblock 88 140 575 minecraft:calcite
fill 88 140 576 88 143 576 minecraft:cobbled_deepslate
setblock 88 140 580 minecraft:calcite
fill 88 140 581 88 143 581 minecraft:cobbled_deepslate
setblock 88 140 585 minecraft:calcite
fill 88 140 586 88 143 586 minecraft:cobbled_deepslate
setblock 48 141 559 minecraft:calcite
fill 48 141 560 48 144 560 minecraft:cobbled_deepslate
setblock 48 141 564 minecraft:calcite
fill 48 141 565 48 144 565 minecraft:cobbled_deepslate
setblock 48 141 569 minecraft:calcite
fill 48 141 570 48 144 570 minecraft:cobbled_deepslate
setblock 48 141 574 minecraft:calcite
fill 48 141 575 48 142 575 minecraft:cobbled_deepslate
setblock 48 141 579 minecraft:calcite
fill 48 141 580 48 144 580 minecraft:cobbled_deepslate
setblock 48 141 584 minecraft:calcite
fill 48 141 585 48 144 585 minecraft:cobbled_deepslate
setblock 48 141 589 minecraft:calcite
setblock 48 141 594 minecraft:calcite
fill 48 141 595 48 144 595 minecraft:cobbled_deepslate
setblock 49 141 558 minecraft:calcite
fill 49 141 559 49 144 559 minecraft:cobbled_deepslate
setblock 49 141 563 minecraft:calcite
fill 49 141 564 49 144 564 minecraft:cobbled_deepslate
setblock 49 141 568 minecraft:calcite
setblock 49 141 578 minecraft:calcite
setblock 49 141 579 minecraft:cobbled_deepslate
setblock 49 141 583 minecraft:calcite
fill 49 141 584 49 144 584 minecraft:cobbled_deepslate
fill 49 141 586 49 142 586 minecraft:cobbled_deepslate
setblock 49 141 598 minecraft:calcite
fill 50 141 558 50 144 558 minecraft:cobbled_deepslate
setblock 50 141 562 minecraft:calcite
fill 50 141 563 50 144 563 minecraft:cobbled_deepslate
setblock 50 141 597 minecraft:calcite
fill 50 141 598 53 141 598 minecraft:cobbled_deepslate
setblock 51 141 561 minecraft:calcite
fill 51 141 562 51 142 562 minecraft:cobbled_deepslate
fill 51 141 597 51 143 597 minecraft:cobbled_deepslate
setblock 52 141 560 minecraft:calcite
fill 52 141 561 52 142 561 minecraft:cobbled_deepslate
setblock 53 141 559 minecraft:calcite
fill 53 141 560 53 143 560 minecraft:cobbled_deepslate
setblock 54 141 558 minecraft:calcite
fill 54 141 559 54 144 559 minecraft:cobbled_deepslate
setblock 54 141 598 minecraft:calcite
fill 55 141 558 55 144 558 minecraft:cobbled_deepslate
setblock 55 141 597 minecraft:calcite
fill 55 141 598 55 144 598 minecraft:cobbled_deepslate
setblock 56 141 597 minecraft:cobbled_deepslate
setblock 58 141 559 minecraft:calcite
setblock 59 141 558 minecraft:calcite
setblock 59 141 598 minecraft:calcite
fill 60 141 558 63 141 558 minecraft:cobbled_deepslate
fill 60 141 598 60 142 598 minecraft:cobbled_deepslate
setblock 64 141 558 minecraft:calcite
setblock 64 141 598 minecraft:calcite
fill 65 141 558 65 144 558 minecraft:cobbled_deepslate
fill 65 141 598 65 144 598 minecraft:cobbled_deepslate
setblock 66 141 597 minecraft:cobbled_deepslate
setblock 68 141 559 minecraft:calcite
setblock 69 141 558 minecraft:calcite
fill 69 141 559 69 142 559 minecraft:cobbled_deepslate
setblock 69 141 598 minecraft:calcite
fill 70 141 558 70 144 558 minecraft:cobbled_deepslate
setblock 70 141 597 minecraft:calcite
fill 70 141 598 70 144 598 minecraft:cobbled_deepslate
setblock 71 141 597 minecraft:cobbled_deepslate
setblock 73 141 559 minecraft:calcite
setblock 74 141 558 minecraft:calcite
setblock 74 141 559 minecraft:cobbled_deepslate
setblock 74 141 598 minecraft:calcite
fill 75 141 558 75 142 558 minecraft:cobbled_deepslate
setblock 75 141 598 minecraft:cobbled_deepslate
setblock 84 141 558 minecraft:calcite
fill 85 141 558 85 144 558 minecraft:cobbled_deepslate
fill 86 141 559 86 141 560 minecraft:cobbled_deepslate
setblock 86 141 561 minecraft:calcite
fill 86 141 562 86 143 563 minecraft:cobbled_deepslate
setblock 87 141 559 minecraft:cobbled_deepslate
setblock 87 141 560 minecraft:calcite
fill 87 141 561 87 144 561 minecraft:cobbled_deepslate
setblock 87 141 564 minecraft:cobbled_deepslate
setblock 87 141 565 minecraft:calcite
fill 87 141 566 87 144 566 minecraft:cobbled_deepslate
setblock 87 141 570 minecraft:calcite
setblock 87 141 575 minecraft:calcite
fill 87 141 576 87 142 576 minecraft:cobbled_deepslate
setblock 87 141 580 minecraft:calcite
fill 87 141 581 87 144 581 minecraft:cobbled_deepslate
setblock 87 141 585 minecraft:calcite
setblock 88 141 559 minecraft:calcite
fill 88 141 560 88 144 560 minecraft:cobbled_deepslate
setblock 88 141 564 minecraft:calcite
fill 88 141 565 88 144 565 minecraft:cobbled_deepslate
setblock 88 141 569 minecraft:calcite
fill 88 141 570 88 144 570 minecraft:cobbled_deepslate
setblock 88 141 574 minecraft:calcite
fill 88 141 575 88 144 575 minecraft:cobbled_deepslate
setblock 88 141 579 minecraft:calcite
fill 88 141 580 88 144 580 minecraft:cobbled_deepslate
setblock 88 141 584 minecraft:calcite
fill 88 141 585 88 144 585 minecraft:cobbled_deepslate
setblock 88 141 588 minecraft:cobbled_deepslate
setblock 48 142 558 minecraft:calcite
fill 48 142 559 48 145 559 minecraft:cobbled_deepslate
setblock 48 142 563 minecraft:calcite
fill 48 142 564 48 145 564 minecraft:cobbled_deepslate
setblock 48 142 568 minecraft:calcite
fill 48 142 569 48 145 569 minecraft:cobbled_deepslate
setblock 48 142 578 minecraft:calcite
fill 48 142 579 48 144 579 minecraft:cobbled_deepslate
setblock 48 142 583 minecraft:calcite
fill 48 142 584 48 145 584 minecraft:cobbled_deepslate
setblock 48 142 588 minecraft:calcite
fill 48 142 589 48 144 590 minecraft:cobbled_deepslate
fill 48 142 594 48 145 594 minecraft:cobbled_deepslate
setblock 48 142 598 minecraft:calcite
fill 49 142 558 49 145 558 minecraft:cobbled_deepslate
setblock 49 142 562 minecraft:calcite
fill 49 142 563 49 145 563 minecraft:cobbled_deepslate
setblock 49 142 567 minecraft:calcite
fill 49 142 568 49 145 568 minecraft:cobbled_deepslate
setblock 49 142 582 minecraft:calcite
fill 49 142 583 49 145 583 minecraft:cobbled_deepslate
setblock 49 142 597 minecraft:calcite
fill 49 142 598 52 142 598 minecraft:cobbled_deepslate
setblock 50 142 561 minecraft:calcite
fill 50 142 562 50 145 562 minecraft:cobbled_deepslate
fill 50 142 597 50 143 597 minecraft:cobbled_deepslate
setblock 51 142 560 minecraft:calcite
setblock 51 142 561 minecraft:cobbled_deepslate
setblock 52 142 559 minecraft:calcite
fill 52 142 560 52 144 560 minecraft:cobbled_deepslate
setblock 53 142 558 minecraft:calcite
fill 53 142 559 53 145 559 minecraft:cobbled_deepslate
setblock 53 142 598 minecraft:calcite
fill 54 142 558 54 145 558 minecraft:cobbled_deepslate
setblock 54 142 597 minecraft:calcite
fill 54 142 598 54 145 598 minecraft:cobbled_deepslate
setblock 57 142 559 minecraft:calcite
setblock 58 142 558 minecraft:calcite
setblock 58 142 598 minecraft:calcite
fill 59 142 558 62 142 558 minecraft:cobbled_deepslate
setblock 59 142 598 minecraft:cobbled_deepslate
setblock 63 142 558 minecraft:calcite
setblock 63 142 598 minecraft:calcite
fill 64 142 558 64 143 558 minecraft:cobbled_deepslate
fill 64 142 598 64 143 598 minecraft:cobbled_deepslate
setblock 67 142 559 minecraft:calcite
setblock 68 142 558 minecraft:calcite
setblock 68 142 559 minecraft:cobbled_deepslate
setblock 68 142 598 minecraft:calcite
fill 69 142 558 69 145 558 minecraft:cobbled_deepslate
fill 69 142 598 69 145 598 minecraft:cobbled_deepslate
setblock 72 142 559 minecraft:calcite
setblock 73 142 558 minecraft:calcite
setblock 73 142 598 minecraft:calcite
setblock 74 142 558 minecraft:cobbled_deepslate
setblock 83 142 558 minecraft:calcite
fill 84 142 558 84 145 558 minecraft:cobbled_deepslate
setblock 86 142 559 minecraft:cobbled_deepslate
setblock 86 142 560 minecraft:calcite
fill 86 142 561 86 145 561 minecraft:cobbled_deepslate
setblock 86 142 564 minecraft:cobbled_deepslate
setblock 87 142 558 minecraft:cobbled_deepslate
setblock 87 142 559 minecraft:calcite
fill 87 142 560 87 145 560 minecraft:cobbled_deepslate
setblock 87 142 564 minecraft:calcite
fill 87 142 565 87 145 565 minecraft:cobbled_deepslate
setblock 87 142 568 minecraft:cobbled_deepslate
setblock 87 142 569 minecraft:calcite
fill 87 142 570 87 145 570 minecraft:cobbled_deepslate
setblock 87 142 579 minecraft:calcite
fill 87 142 580 87 144 580 minecraft:cobbled_deepslate
setblock 87 142 584 minecraft:calcite
fill 87 142 585 87 145 585 minecraft:cobbled_deepslate
setblock 88 142 558 minecraft:calcite
fill 88 142 559 88 145 559 minecraft:cobbled_deepslate
setblock 88 142 563 minecraft:calcite
fill 88 142 564 88 145 564 minecraft:cobbled_deepslate
setblock 88 142 568 minecraft:calcite
fill 88 142 569 88 145 569 minecraft:cobbled_deepslate
setblock 88 142 573 minecraft:calcite
fill 88 142 574 88 145 574 minecraft:cobbled_deepslate
setblock 88 142 578 minecraft:calcite
fill 88 142 579 88 145 579 minecraft:cobbled_deepslate
setblock 88 142 583 minecraft:calcite
fill 88 142 584 88 145 584 minecraft:cobbled_deepslate
setblock 88 142 588 minecraft:calcite
setblock 88 142 598 minecraft:calcite
fill 48 143 558 48 146 558 minecraft:cobbled_deepslate
setblock 48 143 562 minecraft:calcite
fill 48 143 563 48 146 563 minecraft:cobbled_deepslate
setblock 48 143 567 minecraft:calcite
fill 48 143 568 48 146 568 minecraft:cobbled_deepslate
setblock 48 143 577 minecraft:calcite
setblock 48 143 578 minecraft:cobbled_deepslate
setblock 48 143 582 minecraft:calcite
fill 48 143 583 48 146 583 minecraft:cobbled_deepslate
setblock 48 143 587 minecraft:calcite
fill 48 143 588 48 146 588 minecraft:cobbled_deepslate
setblock 48 143 591 minecraft:cobbled_deepslate
setblock 48 143 597 minecraft:calcite
fill 48 143 598 51 143 598 minecraft:cobbled_deepslate
setblock 49 143 561 minecraft:calcite
fill 49 143 562 49 146 562 minecraft:cobbled_deepslate
setblock 49 143 566 minecraft:calcite
fill 49 143 567 49 146 567 minecraft:cobbled_deepslate
setblock 49 143 581 minecraft:calcite
setblock 49 143 582 minecraft:cobbled_deepslate
setblock 49 143 586 minecraft:calcite
fill 49 143 587 49 146 587 minecraft:cobbled_deepslate
setblock 49 143 597 minecraft:cobbled_deepslate
setblock 50 143 560 minecraft:calcite
fill 50 143 561 50 146 561 minecraft:cobbled_deepslate
setblock 50 143 565 minecraft:calcite
setblock 51 143 559 minecraft:calcite
fill 51 143 560 51 145 560 minecraft:cobbled_deepslate
setblock 52 143 558 minecraft:calcite
fill 52 143 559 52 146 559 minecraft:cobbled_deepslate
setblock 52 143 598 minecraft:calcite
fill 53 143 558 53 146 558 minecraft:cobbled_deepslate
fill 53 143 598 53 146 598 minecraft:cobbled_deepslate
setblock 57 143 558 minecraft:calcite
setblock 58 143 558 minecraft:cobbled_deepslate
setblock 67 143 558 minecraft:calcite
setblock 67 143 598 minecraft:calcite
fill 68 143 558 68 146 558 minecraft:cobbled_deepslate
fill 68 143 598 68 146 598 minecraft:cobbled_deepslate
setblock 72 143 558 minecraft:calcite
setblock 73 143 558 minecraft:cobbled_deepslate
setblock 86 143 559 minecraft:calcite
fill 86 143 560 86 146 560 minecraft:cobbled_deepslate
setblock 86 143 564 minecraft:calcite
fill 86 143 565 86 146 565 minecraft:cobbled_deepslate
setblock 87 143 558 minecraft:calcite
fill 87 143 559 87 146 559 minecraft:cobbled_deepslate
setblock 87 143 563 minecraft:calcite
fill 87 143 564 87 146 564 minecraft:cobbled_deepslate
setblock 87 143 568 minecraft:calcite
fill 87 143 569 87 146 569 minecraft:cobbled_deepslate
setblock 87 143 578 minecraft:calcite
setblock 87 143 579 minecraft:cobbled_deepslate
setblock 87 143 583 minecraft:calcite
fill 87 143 584 87 146 584 minecraft:cobbled_deepslate
fill 88 143 558 88 146 558 minecraft:cobbled_deepslate
setblock 88 143 562 minecraft:calcite
fill 88 143 563 88 146 563 minecraft:cobbled_deepslate
setblock 88 143 567 minecraft:calcite
fill 88 143 568 88 146 568 minecraft:cobbled_deepslate
setblock 88 143 572 minecraft:calcite
fill 88 143 573 88 146 573 minecraft:cobbled_deepslate
setblock 88 143 577 minecraft:calcite
fill 88 143 578 88 146 578 minecraft:cobbled_deepslate
setblock 88 143 582 minecraft:calcite
fill 88 143 583 88 146 583 minecraft:cobbled_deepslate
setblock 88 143 587 minecraft:calcite
fill 88 143 588 88 146 588 minecraft:cobbled_deepslate
setblock 88 143 598 minecraft:cobbled_deepslate
setblock 48 144 561 minecraft:calcite
fill 48 144 562 48 147 562 minecraft:cobbled_deepslate
setblock 48 144 566 minecraft:calcite
fill 48 144 567 48 147 567 minecraft:cobbled_deepslate
setblock 48 144 571 minecraft:calcite
setblock 48 144 581 minecraft:calcite
fill 48 144 582 48 147 582 minecraft:cobbled_deepslate
setblock 48 144 586 minecraft:calcite
fill 48 144 587 48 147 587 minecraft:cobbled_deepslate
setblock 48 144 591 minecraft:calcite
fill 48 144 592 48 146 593 minecraft:cobbled_deepslate
setblock 48 144 596 minecraft:calcite
fill 48 144 597 48 146 598 minecraft:cobbled_deepslate
setblock 49 144 560 minecraft:calcite
fill 49 144 561 49 147 561 minecraft:cobbled_deepslate
setblock 49 144 565 minecraft:calcite
fill 49 144 566 49 147 566 minecraft:cobbled_deepslate
setblock 49 144 585 minecraft:calcite
fill 49 144 586 49 147 586 minecraft:cobbled_deepslate
fill 49 144 588 49 145 588 minecraft:cobbled_deepslate
fill 49 144 598 50 144 598 minecraft:cobbled_deepslate
setblock 50 144 559 minecraft:calcite
fill 50 144 560 50 146 560 minecraft:cobbled_deepslate
setblock 50 144 564 minecraft:calcite
fill 50 144 565 50 147 565 minecraft:cobbled_deepslate
setblock 50 144 568 minecraft:light[level=14]
setblock 50 144 576 minecraft:light[level=14]
setblock 50 144 584 minecraft:light[level=14]
setblock 50 144 592 minecraft:light[level=14]
setblock 51 144 558 minecraft:calcite
fill 51 144 559 51 147 559 minecraft:cobbled_deepslate
setblock 51 144 598 minecraft:calcite
fill 52 144 558 52 147 558 minecraft:cobbled_deepslate
fill 52 144 598 52 147 598 minecraft:cobbled_deepslate
setblock 56 144 558 minecraft:calcite
setblock 58 144 560 minecraft:light[level=14]
setblock 58 144 568 minecraft:light[level=14]
setblock 58 144 576 minecraft:light[level=14]
setblock 58 144 584 minecraft:light[level=14]
setblock 58 144 592 minecraft:light[level=14]
setblock 66 144 558 minecraft:calcite
setblock 66 144 560 minecraft:light[level=14]
setblock 66 144 576 minecraft:light[level=14]
setblock 66 144 584 minecraft:light[level=14]
setblock 66 144 592 minecraft:light[level=14]
setblock 66 144 598 minecraft:calcite
fill 67 144 558 67 146 558 minecraft:cobbled_deepslate
fill 67 144 598 67 147 598 minecraft:cobbled_deepslate
setblock 71 144 558 minecraft:calcite
setblock 74 144 560 minecraft:light[level=14]
setblock 74 144 568 minecraft:light[level=14]
setblock 74 144 576 minecraft:light[level=14]
setblock 74 144 584 minecraft:light[level=14]
setblock 74 144 592 minecraft:light[level=14]
setblock 82 144 560 minecraft:light[level=14]
setblock 82 144 568 minecraft:light[level=14]
setblock 82 144 576 minecraft:light[level=14]
setblock 82 144 584 minecraft:light[level=14]
setblock 82 144 592 minecraft:light[level=14]
setblock 85 144 559 minecraft:calcite
setblock 86 144 558 minecraft:calcite
fill 86 144 559 86 147 559 minecraft:cobbled_deepslate
setblock 86 144 562 minecraft:cobbled_deepslate
setblock 86 144 563 minecraft:calcite
fill 86 144 564 86 147 564 minecraft:cobbled_deepslate
fill 86 144 566 86 144 567 minecraft:cobbled_deepslate
fill 87 144 558 87 147 558 minecraft:cobbled_deepslate
setblock 87 144 562 minecraft:calcite
fill 87 144 563 87 147 563 minecraft:cobbled_deepslate
setblock 87 144 567 minecraft:calcite
fill 87 144 568 87 147 568 minecraft:cobbled_deepslate
setblock 87 144 582 minecraft:calcite
fill 87 144 583 87 147 583 minecraft:cobbled_deepslate
setblock 88 144 561 minecraft:calcite
fill 88 144 562 88 147 562 minecraft:cobbled_deepslate
setblock 88 144 566 minecraft:calcite
fill 88 144 567 88 147 567 minecraft:cobbled_deepslate
setblock 88 144 571 minecraft:calcite
fill 88 144 572 88 147 572 minecraft:cobbled_deepslate
setblock 88 144 576 minecraft:calcite
fill 88 144 577 88 147 577 minecraft:cobbled_deepslate
setblock 88 144 581 minecraft:calcite
fill 88 144 582 88 147 582 minecraft:cobbled_deepslate
setblock 88 144 586 minecraft:calcite
fill 88 144 587 88 147 587 minecraft:cobbled_deepslate
fill 88 144 589 88 145 589 minecraft:cobbled_deepslate
setblock 48 145 560 minecraft:calcite
fill 48 145 561 48 148 561 minecraft:cobbled_deepslate
setblock 48 145 565 minecraft:calcite
fill 48 145 566 48 148 566 minecraft:cobbled_deepslate
setblock 48 145 570 minecraft:calcite
fill 48 145 571 48 148 571 minecraft:cobbled_deepslate
setblock 48 145 580 minecraft:calcite
fill 48 145 581 48 148 581 minecraft:cobbled_deepslate
setblock 48 145 585 minecraft:calcite
fill 48 145 586 48 148 586 minecraft:cobbled_deepslate
setblock 48 145 589 minecraft:cobbled_deepslate
setblock 48 145 590 minecraft:calcite
fill 48 145 591 48 148 591 minecraft:cobbled_deepslate
setblock 48 145 595 minecraft:calcite
fill 48 145 596 48 148 596 minecraft:cobbled_deepslate
setblock 49 145 559 minecraft:calcite
fill 49 145 560 49 148 560 minecraft:cobbled_deepslate
setblock 49 145 564 minecraft:calcite
fill 49 145 565 49 148 565 minecraft:cobbled_deepslate
setblock 49 145 584 minecraft:calcite
fill 49 145 585 49 148 585 minecraft:cobbled_deepslate
setblock 49 145 589 minecraft:calcite
setblock 49 145 598 minecraft:cobbled_deepslate
setblock 50 145 558 minecraft:calcite
fill 50 145 559 50 148 559 minecraft:cobbled_deepslate
setblock 50 145 563 minecraft:calcite
fill 50 145 564 50 148 564 minecraft:cobbled_deepslate
setblock 50 145 598 minecraft:calcite
fill 51 145 558 51 148 558 minecraft:cobbled_deepslate
fill 51 145 598 51 148 598 minecraft:cobbled_deepslate
setblock 55 145 558 minecraft:calcite
setblock 65 145 598 minecraft:calcite
setblock 66 145 558 minecraft:cobbled_deepslate
fill 66 145 598 66 148 598 minecraft:cobbled_deepslate
setblock 70 145 558 minecraft:calcite
setblock 85 145 558 minecraft:calcite
fill 85 145 559 85 148 559 minecraft:cobbled_deepslate
fill 86 145 558 86 148 558 minecraft:cobbled_deepslate
setblock 86 145 562 minecraft:calcite
fill 86 145 563 86 148 563 minecraft:cobbled_deepslate
setblock 86 145 566 minecraft:cobbled_deepslate
setblock 86 145 567 minecraft:calcite
fill 86 145 568 86 148 568 minecraft:cobbled_deepslate
setblock 87 145 561 minecraft:calcite
fill 87 145 562 87 148 562 minecraft:cobbled_deepslate
setblock 87 145 566 minecraft:calcite
fill 87 145 567 87 148 567 minecraft:cobbled_deepslate
setblock 87 145 571 minecraft:calcite
setblock 87 145 581 minecraft:calcite
fill 87 145 582 87 147 582 minecraft:cobbled_deepslate
setblock 87 145 586 minecraft:calcite
setblock 88 145 560 minecraft:calcite
fill 88 145 561 88 148 561 minecraft:cobbled_deepslate
setblock 88 145 565 minecraft:calcite
fill 88 145 566 88 148 566 minecraft:cobbled_deepslate
setblock 88 145 570 minecraft:calcite
fill 88 145 571 88 148 571 minecraft:cobbled_deepslate
setblock 88 145 575 minecraft:calcite
fill 88 145 576 88 148 576 minecraft:cobbled_deepslate
setblock 88 145 580 minecraft:calcite
fill 88 145 581 88 148 581 minecraft:cobbled_deepslate
setblock 88 145 585 minecraft:calcite
fill 88 145 586 88 148 586 minecraft:cobbled_deepslate
setblock 88 145 590 minecraft:calcite
setblock 48 146 559 minecraft:calcite
fill 48 146 560 48 149 560 minecraft:cobbled_deepslate
setblock 48 146 564 minecraft:calcite
fill 48 146 565 48 149 565 minecraft:cobbled_deepslate
setblock 48 146 569 minecraft:calcite
fill 48 146 570 48 149 570 minecraft:cobbled_deepslate
fill 48 146 580 48 147 580 minecraft:cobbled_deepslate
setblock 48 146 584 minecraft:calcite
fill 48 146 585 48 149 585 minecraft:cobbled_deepslate
setblock 48 146 589 minecraft:calcite
fill 48 146 590 49 148 590 minecraft:cobbled_deepslate
setblock 48 146 594 minecraft:calcite
fill 48 146 595 48 149 595 minecraft:cobbled_deepslate
setblock 49 146 558 minecraft:calcite
fill 49 146 559 49 149 559 minecraft:cobbled_deepslate
setblock 49 146 563 minecraft:calcite
fill 49 146 564 49 149 564 minecraft:cobbled_deepslate
setblock 49 146 568 minecraft:calcite
setblock 49 146 583 minecraft:calcite
fill 49 146 584 49 149 584 minecraft:cobbled_deepslate
setblock 49 146 588 minecraft:calcite
fill 49 146 589 49 149 589 minecraft:cobbled_deepslate
fill 49 146 591 49 147 591 minecraft:cobbled_deepslate
setblock 49 146 598 minecraft:calcite
fill 50 146 558 50 149 558 minecraft:cobbled_deepslate
setblock 50 146 562 minecraft:calcite
fill 50 146 563 50 148 563 minecraft:cobbled_deepslate
fill 50 146 598 50 149 598 minecraft:cobbled_deepslate
setblock 54 146 558 minecraft:calcite
fill 65 146 598 65 149 598 minecraft:cobbled_deepslate
setblock 83 146 558 minecraft:cobbled_deepslate
setblock 84 146 558 minecraft:calcite
fill 84 146 559 84 149 559 minecraft:cobbled_deepslate
fill 85 146 558 85 149 558 minecraft:cobbled_deepslate
setblock 86 146 561 minecraft:calcite
fill 86 146 562 86 149 562 minecraft:cobbled_deepslate
setblock 86 146 566 minecraft:calcite
fill 86 146 567 86 149 567 minecraft:cobbled_deepslate
fill 86 146 569 86 147 569 minecraft:cobbled_deepslate
setblock 87 146 560 minecraft:calcite
fill 87 146 561 87 149 561 minecraft:cobbled_deepslate
setblock 87 146 565 minecraft:calcite
fill 87 146 566 87 149 566 minecraft:cobbled_deepslate
setblock 87 146 570 minecraft:calcite
fill 87 146 571 87 148 572 minecraft:cobbled_deepslate
setblock 87 146 585 minecraft:calcite
fill 87 146 586 87 148 587 minecraft:cobbled_deepslate
setblock 88 146 559 minecraft:calcite
fill 88 146 560 88 149 560 minecraft:cobbled_deepslate
setblock 88 146 564 minecraft:calcite
fill 88 146 565 88 149 565 minecraft:cobbled_deepslate
setblock 88 146 569 minecraft:calcite
fill 88 146 570 88 149 570 minecraft:cobbled_deepslate
setblock 88 146 574 minecraft:calcite
fill 88 146 575 88 149 575 minecraft:cobbled_deepslate
setblock 88 146 579 minecraft:calcite
fill 88 146 580 88 149 580 minecraft:cobbled_deepslate
setblock 88 146 584 minecraft:calcite
fill 88 146 585 88 149 585 minecraft:cobbled_deepslate
setblock 88 146 589 minecraft:calcite
fill 88 146 590 88 148 591 minecraft:cobbled_deepslate
setblock 48 147 558 minecraft:calcite
fill 48 147 559 48 150 559 minecraft:cobbled_deepslate
setblock 48 147 563 minecraft:calcite
fill 48 147 564 48 150 564 minecraft:cobbled_deepslate
setblock 48 147 568 minecraft:calcite
fill 48 147 569 49 149 569 minecraft:cobbled_deepslate
setblock 48 147 572 minecraft:cobbled_deepslate
setblock 48 147 583 minecraft:calcite
fill 48 147 584 48 150 584 minecraft:cobbled_deepslate
setblock 48 147 588 minecraft:calcite
fill 48 147 589 48 150 589 minecraft:cobbled_deepslate
setblock 48 147 592 minecraft:cobbled_deepslate
setblock 48 147 593 minecraft:calcite
fill 48 147 594 49 149 594 minecraft:cobbled_deepslate
setblock 48 147 597 minecraft:cobbled_deepslate
setblock 48 147 598 minecraft:calcite
fill 49 147 558 49 150 558 minecraft:cobbled_deepslate
setblock 49 147 562 minecraft:calcite
fill 49 147 563 49 150 563 minecraft:cobbled_deepslate
setblock 49 147 567 minecraft:calcite
fill 49 147 568 49 150 568 minecraft:cobbled_deepslate
setblock 49 147 587 minecraft:calcite
fill 49 147 588 49 150 588 minecraft:cobbled_deepslate
setblock 49 147 592 minecraft:calcite
fill 49 147 593 49 150 593 minecraft:cobbled_deepslate
fill 49 147 598 49 150 598 minecraft:cobbled_deepslate
setblock 50 147 561 minecraft:calcite
fill 50 147 562 50 148 562 minecraft:cobbled_deepslate
setblock 53 147 558 minecraft:calcite
setblock 53 147 598 minecraft:calcite
fill 64 147 598 64 150 598 minecraft:cobbled_deepslate
setblock 83 147 558 minecraft:calcite
fill 84 147 558 84 150 558 minecraft:cobbled_deepslate
setblock 85 147 560 minecraft:cobbled_deepslate
fill 85 147 563 85 147 565 minecraft:cobbled_deepslate
setblock 85 147 566 minecraft:calcite
setblock 86 147 560 minecraft:calcite
fill 86 147 561 86 150 561 minecraft:cobbled_deepslate
setblock 86 147 565 minecraft:calcite
fill 86 147 566 86 150 566 minecraft:cobbled_deepslate
setblock 86 147 570 minecraft:calcite
setblock 87 147 559 minecraft:calcite
fill 87 147 560 87 150 560 minecraft:cobbled_deepslate
setblock 87 147 564 minecraft:calcite
fill 87 147 565 87 150 565 minecraft:cobbled_deepslate
setblock 87 147 569 minecraft:calcite
fill 87 147 570 87 150 570 minecraft:cobbled_deepslate
setblock 87 147 573 minecraft:cobbled_deepslate
setblock 87 147 584 minecraft:calcite
fill 87 147 585 87 150 585 minecraft:cobbled_deepslate
setblock 87 147 588 minecraft:cobbled_deepslate
setblock 87 147 589 minecraft:calcite
setblock 88 147 558 minecraft:calcite
fill 88 147 559 88 150 559 minecraft:cobbled_deepslate
setblock 88 147 563 minecraft:calcite
fill 88 147 564 88 150 564 minecraft:cobbled_deepslate
setblock 88 147 568 minecraft:calcite
fill 88 147 569 88 150 569 minecraft:cobbled_deepslate
setblock 88 147 573 minecraft:calcite
fill 88 147 574 88 150 574 minecraft:cobbled_deepslate
setblock 88 147 578 minecraft:calcite
fill 88 147 579 88 150 579 minecraft:cobbled_deepslate
setblock 88 147 583 minecraft:calcite
fill 88 147 584 88 150 584 minecraft:cobbled_deepslate
setblock 88 147 588 minecraft:calcite
fill 88 147 589 88 150 589 minecraft:cobbled_deepslate
setblock 88 147 592 minecraft:cobbled_deepslate
setblock 88 147 593 minecraft:calcite
setblock 88 147 598 minecraft:calcite
fill 48 148 558 48 151 558 minecraft:cobbled_deepslate
setblock 48 148 562 minecraft:calcite
fill 48 148 563 48 151 563 minecraft:cobbled_deepslate
setblock 48 148 567 minecraft:calcite
fill 48 148 568 48 151 568 minecraft:cobbled_deepslate
setblock 48 148 572 minecraft:calcite
fill 48 148 573 48 151 573 minecraft:cobbled_deepslate
setblock 48 148 582 minecraft:calcite
fill 48 148 583 48 151 583 minecraft:cobbled_deepslate
setblock 48 148 587 minecraft:calcite
fill 48 148 588 48 151 588 minecraft:cobbled_deepslate
setblock 48 148 592 minecraft:calcite
fill 48 148 593 48 151 593 minecraft:cobbled_deepslate
setblock 48 148 597 minecraft:calcite
fill 48 148 598 48 151 598 minecraft:cobbled_deepslate
setblock 49 148 561 minecraft:calcite
fill 49 148 562 49 151 562 minecraft:cobbled_deepslate
setblock 49 148 566 minecraft:calcite
fill 49 148 567 49 151 567 minecraft:cobbled_deepslate
setblock 49 148 586 minecraft:calcite
fill 49 148 587 49 151 587 minecraft:cobbled_deepslate
setblock 49 148 591 minecraft:calcite
fill 49 148 592 49 151 592 minecraft:cobbled_deepslate
setblock 49 148 595 minecraft:cobbled_deepslate
setblock 49 148 596 minecraft:calcite
fill 49 148 597 49 151 597 minecraft:cobbled_deepslate
setblock 50 148 565 minecraft:calcite
setblock 50 148 589 minecraft:cobbled_deepslate
setblock 51 148 559 minecraft:calcite
setblock 52 148 558 minecraft:calcite
setblock 52 148 598 minecraft:calcite
fill 53 148 598 53 151 598 minecraft:cobbled_deepslate
fill 61 148 566 62 148 570 minecraft:diamond_block
fill 62 148 565 68 148 565 minecraft:diamond_block
fill 62 148 571 67 148 571 minecraft:diamond_block
fill 63 148 564 67 148 564 minecraft:diamond_block
fill 63 148 566 63 150 566 minecraft:diamond_block
fill 63 148 570 68 148 570 minecraft:diamond_block
fill 63 148 598 63 151 598 minecraft:cobbled_deepslate
fill 64 148 572 65 148 572 minecraft:diamond_block
fill 67 148 566 68 148 569 minecraft:diamond_block
setblock 67 148 598 minecraft:calcite
fill 68 148 598 68 151 598 minecraft:cobbled_deepslate
setblock 69 148 568 minecraft:diamond_block
setblock 82 148 558 minecraft:calcite
fill 83 148 558 83 150 559 minecraft:cobbled_deepslate
setblock 85 148 560 minecraft:calcite
fill 85 148 562 85 148 564 minecraft:cobbled_deepslate
setblock 85 148 565 minecraft:calcite
fill 85 148 566 85 149 568 minecraft:cobbled_deepslate
setblock 86 148 559 minecraft:calcite
fill 86 148 560 86 151 560 minecraft:cobbled_deepslate
setblock 86 148 564 minecraft:calcite
fill 86 148 565 86 151 565 minecraft:cobbled_deepslate
setblock 86 148 569 minecraft:calcite
fill 86 148 570 86 150 571 minecraft:cobbled_deepslate
setblock 86 148 598 minecraft:cobbled_deepslate
setblock 87 148 558 minecraft:calcite
fill 87 148 559 87 151 559 minecraft:cobbled_deepslate
setblock 87 148 563 minecraft:calcite
fill 87 148 564 87 151 564 minecraft:cobbled_deepslate
setblock 87 148 568 minecraft:calcite
fill 87 148 569 87 151 569 minecraft:cobbled_deepslate
setblock 87 148 573 minecraft:calcite
fill 87 148 574 87 151 574 minecraft:cobbled_deepslate
setblock 87 148 583 minecraft:calcite
fill 87 148 584 87 151 584 minecraft:cobbled_deepslate
setblock 87 148 588 minecraft:calcite
fill 87 148 589 87 149 591 minecraft:cobbled_deepslate
setblock 87 148 598 minecraft:calcite
fill 88 148 558 88 151 558 minecraft:cobbled_deepslate
setblock 88 148 562 minecraft:calcite
fill 88 148 563 88 151 563 minecraft:cobbled_deepslate
setblock 88 148 567 minecraft:calcite
fill 88 148 568 88 151 568 minecraft:cobbled_deepslate
setblock 88 148 572 minecraft:calcite
fill 88 148 573 88 151 573 minecraft:cobbled_deepslate
setblock 88 148 577 minecraft:calcite
fill 88 148 578 88 151 578 minecraft:cobbled_deepslate
setblock 88 148 582 minecraft:calcite
fill 88 148 583 88 151 583 minecraft:cobbled_deepslate
setblock 88 148 587 minecraft:calcite
fill 88 148 588 88 151 588 minecraft:cobbled_deepslate
setblock 88 148 592 minecraft:calcite
fill 88 148 593 88 148 596 minecraft:cobbled_deepslate
setblock 88 148 597 minecraft:calcite
fill 88 148 598 88 151 598 minecraft:cobbled_deepslate
setblock 48 149 561 minecraft:calcite
fill 48 149 562 48 151 562 minecraft:cobbled_deepslate
setblock 48 149 566 minecraft:calcite
fill 48 149 567 48 151 567 minecraft:cobbled_deepslate
setblock 48 149 571 minecraft:calcite
fill 48 149 572 48 151 572 minecraft:cobbled_deepslate
setblock 48 149 581 minecraft:calcite
fill 48 149 582 48 151 582 minecraft:cobbled_deepslate
setblock 48 149 586 minecraft:calcite
fill 48 149 587 48 151 587 minecraft:cobbled_deepslate
setblock 48 149 590 minecraft:cobbled_deepslate
setblock 48 149 591 minecraft:calcite
fill 48 149 592 48 151 592 minecraft:cobbled_deepslate
setblock 48 149 596 minecraft:calcite
fill 48 149 597 48 151 597 minecraft:cobbled_deepslate
setblock 49 149 560 minecraft:calcite
fill 49 149 561 49 151 561 minecraft:cobbled_deepslate
setblock 49 149 565 minecraft:calcite
fill 49 149 566 49 151 566 minecraft:cobbled_deepslate
setblock 49 149 570 minecraft:calcite
setblock 49 149 585 minecraft:calcite
fill 49 149 586 49 151 586 minecraft:cobbled_deepslate
setblock 49 149 590 minecraft:calcite
fill 49 149 591 50 151 591 minecraft:cobbled_deepslate
setblock 49 149 595 minecraft:calcite
fill 49 149 596 49 151 596 minecraft:cobbled_deepslate
setblock 50 149 559 minecraft:calcite
setblock 50 149 564 minecraft:calcite
setblock 50 149 565 minecraft:cobbled_deepslate
fill 50 149 587 50 149 588 minecraft:cobbled_deepslate
setblock 50 149 589 minecraft:calcite
fill 50 149 590 50 151 590 minecraft:cobbled_deepslate
fill 50 149 597 50 150 597 minecraft:cobbled_deepslate
setblock 51 149 558 minecraft:calcite
setblock 51 149 598 minecraft:calcite
fill 52 149 558 52 150 558 minecraft:cobbled_deepslate
fill 52 149 598 52 151 598 minecraft:cobbled_deepslate
fill 61 149 567 62 149 568 minecraft:diamond_block
setblock 61 149 598 minecraft:calcite
setblock 62 149 566 minecraft:diamond_block
fill 62 149 569 62 149 570 minecraft:diamond_block
fill 62 149 598 62 151 598 minecraft:cobbled_deepslate
fill 63 149 565 67 149 565 minecraft:diamond_block
fill 63 149 570 67 149 570 minecraft:diamond_block
fill 64 149 571 66 149 571 minecraft:diamond_block
setblock 65 149 558 minecraft:cobbled_deepslate
setblock 65 149 564 minecraft:diamond_block
setblock 66 149 558 minecraft:calcite
setblock 66 149 598 minecraft:calcite
fill 67 149 566 67 150 569 minecraft:diamond_block
fill 67 149 598 67 151 598 minecraft:cobbled_deepslate
fill 68 149 567 68 149 569 minecraft:diamond_block
fill 82 149 558 82 151 558 minecraft:cobbled_deepslate
setblock 84 149 560 minecraft:calcite
setblock 85 149 559 minecraft:calcite
fill 85 149 560 85 151 560 minecraft:cobbled_deepslate
fill 85 149 562 85 149 563 minecraft:cobbled_deepslate
setblock 85 149 564 minecraft:calcite
fill 85 149 565 85 151 565 minecraft:cobbled_deepslate
setblock 85 149 569 minecraft:calcite
fill 85 149 570 85 151 570 minecraft:cobbled_deepslate
setblock 85 149 598 minecraft:cobbled_deepslate
setblock 86 149 558 minecraft:calcite
fill 86 149 559 86 151 559 minecraft:cobbled_deepslate
setblock 86 149 563 minecraft:calcite
fill 86 149 564 86 151 564 minecraft:cobbled_deepslate
setblock 86 149 568 minecraft:calcite
fill 86 149 569 86 151 569 minecraft:cobbled_deepslate
setblock 86 149 572 minecraft:cobbled_deepslate
setblock 86 149 598 minecraft:calcite
fill 87 149 558 87 151 558 minecraft:cobbled_deepslate
setblock 87 149 562 minecraft:calcite
fill 87 149 563 87 151 563 minecraft:cobbled_deepslate
setblock 87 149 567 minecraft:calcite
fill 87 149 568 87 151 568 minecraft:cobbled_deepslate
setblock 87 149 571 minecraft:cobbled_deepslate
setblock 87 149 572 minecraft:calcite
fill 87 149 573 87 151 573 minecraft:cobbled_deepslate
fill 87 149 583 87 150 583 minecraft:cobbled_deepslate
setblock 87 149 586 minecraft:cobbled_deepslate
setblock 87 149 587 minecraft:calcite
fill 87 149 588 87 151 588 minecraft:cobbled_deepslate
setblock 87 149 592 minecraft:calcite
fill 87 149 593 88 151 593 minecraft:cobbled_deepslate
fill 87 149 598 87 151 598 minecraft:cobbled_deepslate
setblock 88 149 561 minecraft:calcite
fill 88 149 562 88 151 562 minecraft:cobbled_deepslate
setblock 88 149 566 minecraft:calcite
fill 88 149 567 88 151 567 minecraft:cobbled_deepslate
setblock 88 149 571 minecraft:calcite
fill 88 149 572 88 151 572 minecraft:cobbled_deepslate
setblock 88 149 576 minecraft:calcite
fill 88 149 577 88 151 577 minecraft:cobbled_deepslate
setblock 88 149 581 minecraft:calcite
fill 88 149 582 88 151 582 minecraft:cobbled_deepslate
setblock 88 149 586 minecraft:calcite
fill 88 149 587 88 151 587 minecraft:cobbled_deepslate
setblock 88 149 590 minecraft:cobbled_deepslate
setblock 88 149 591 minecraft:calcite
fill 88 149 592 88 151 592 minecraft:cobbled_deepslate
fill 88 149 594 88 149 595 minecraft:cobbled_deepslate
setblock 88 149 596 minecraft:calcite
fill 88 149 597 88 151 597 minecraft:cobbled_deepslate
setblock 48 150 560 minecraft:calcite
fill 48 150 561 48 151 561 minecraft:cobbled_deepslate
setblock 48 150 565 minecraft:calcite
fill 48 150 566 48 151 566 minecraft:cobbled_deepslate
setblock 48 150 569 minecraft:cobbled_deepslate
setblock 48 150 570 minecraft:calcite
fill 48 150 571 48 151 571 minecraft:cobbled_deepslate
setblock 48 150 574 minecraft:cobbled_deepslate
fill 48 150 581 48 151 581 minecraft:cobbled_deepslate
setblock 48 150 585 minecraft:calcite
fill 48 150 586 48 151 586 minecraft:cobbled_deepslate
setblock 48 150 590 minecraft:calcite
fill 48 150 591 48 151 591 minecraft:cobbled_deepslate
setblock 48 150 594 minecraft:cobbled_deepslate
setblock 48 150 595 minecraft:calcite
fill 48 150 596 48 151 596 minecraft:cobbled_deepslate
setblock 49 150 559 minecraft:calcite
fill 49 150 560 49 151 560 minecraft:cobbled_deepslate
setblock 49 150 564 minecraft:calcite
fill 49 150 565 49 151 565 minecraft:cobbled_deepslate
setblock 49 150 569 minecraft:calcite
fill 49 150 570 49 151 570 minecraft:cobbled_deepslate
setblock 49 150 584 minecraft:calcite
fill 49 150 585 49 151 585 minecraft:cobbled_deepslate
setblock 49 150 589 minecraft:calcite
fill 49 150 590 49 151 590 minecraft:cobbled_deepslate
setblock 49 150 594 minecraft:calcite
fill 49 150 595 49 151 595 minecraft:cobbled_deepslate
setblock 50 150 558 minecraft:calcite
setblock 50 150 559 minecraft:cobbled_deepslate
setblock 50 150 587 minecraft:cobbled_deepslate
setblock 50 150 588 minecraft:calcite
schedule function dropper:buildpart/133_6 1t
